// ================================================================
// Open Account — BOM وسندات الإنتاج (محدث مع التنبيهات والحالة الجزئية)
// ================================================================
var bomRecipes = [];
var productionDocs = [];

// ✅ فلاتر التاريخ لسندات الإنتاج
var _productionFilterFrom = '';
var _productionFilterTo = '';
var PROD_FILTER_FROM_KEY = 'oa_production_filter_from';
var PROD_FILTER_TO_KEY = 'oa_production_filter_to';
// ================================================================
// ===== دوال فلاتر الإنتاج =====
// ================================================================

function _prodLoadFilters() {
    try {
        _productionFilterFrom = localStorage.getItem(PROD_FILTER_FROM_KEY) || '';
        _productionFilterTo = localStorage.getItem(PROD_FILTER_TO_KEY) || '';
    } catch (e) {
        _productionFilterFrom = '';
        _productionFilterTo = '';
    }

    var fromEl = document.getElementById('productionFrom');
    var toEl = document.getElementById('productionTo');
    if (fromEl) fromEl.value = _productionFilterFrom;
    if (toEl) toEl.value = _productionFilterTo;
}

function _prodSaveFilters() {
    var fromEl = document.getElementById('productionFrom');
    var toEl = document.getElementById('productionTo');
    if (fromEl) _productionFilterFrom = fromEl.value || '';
    if (toEl) _productionFilterTo = toEl.value || '';
    try {
        localStorage.setItem(PROD_FILTER_FROM_KEY, _productionFilterFrom);
        localStorage.setItem(PROD_FILTER_TO_KEY, _productionFilterTo);
    } catch (e) {}
}

function _prodClearFilters() {
    _productionFilterFrom = '';
    _productionFilterTo = '';
    var fromEl = document.getElementById('productionFrom');
    var toEl = document.getElementById('productionTo');
    if (fromEl) fromEl.value = '';
    if (toEl) toEl.value = '';
    try {
        localStorage.removeItem(PROD_FILTER_FROM_KEY);
        localStorage.removeItem(PROD_FILTER_TO_KEY);
    } catch (e) {}
    renderProduction();
}

function _prodBindFilterInputs() {
    var fromEl = document.getElementById('productionFrom');
    var toEl = document.getElementById('productionTo');

    if (fromEl && !fromEl._oaBound) {
        fromEl._oaBound = true;
        fromEl.addEventListener('change', _prodSaveFilters);
    }
    if (toEl && !toEl._oaBound) {
        toEl._oaBound = true;
        toEl.addEventListener('change', _prodSaveFilters);
    }
}

function loadProductionData() {
    bomRecipes = Storage.get(STORAGE_KEYS.BOM_RECIPES, []);
    productionDocs = Storage.get(STORAGE_KEYS.PRODUCTIONS, []);
    if (!Array.isArray(bomRecipes)) bomRecipes = [];
    if (!Array.isArray(productionDocs)) productionDocs = [];
}
function saveProductionData() {
    Storage.set(STORAGE_KEYS.BOM_RECIPES, bomRecipes);
    Storage.set(STORAGE_KEYS.PRODUCTIONS, productionDocs);
}
function productionBaseUnit(product) { return product && (product.baseUnit || product.unit) || 'وحدة'; }
function productionFactor(product, unitName) {
    if (!product || !unitName || unitName === productionBaseUnit(product)) return 1;
    var unit = (product.units || []).find(function(item) { return item.name === unitName; });
    return unit ? (Number(unit.factor) || 1) : 1;
}
function getBomForProduct(productId) { return bomRecipes.find(function(recipe) { return recipe.productId === productId; }); }

function openBomModal(recipe) {
    recipe = recipe || null;
    var finished = products.filter(function(p) { return (p.type || 'finished') === 'finished'; });
    var raw = products.filter(function(p) { return (p.type || 'finished') === 'raw'; });
    if (!finished.length || !raw.length) return showToast('أضف منتجاً تاماً ومادة خاماً أولاً', 'error');
    var selectedProduct = recipe ? recipe.productId : finished[0].id;
    var body = '<div class="form-field"><label>المنتج التام</label><select id="bomProduct">';
    finished.forEach(function(p) { body += '<option value="' + p.id + '"' + (p.id === selectedProduct ? ' selected' : '') + '>' + esc(p.name) + '</option>'; });
    body += '</select></div><div class="form-field"><label>كمية المنتج الناتجة لكل دفعة</label><input id="bomOutputQty" type="number" min="0.000001" step="0.000001" value="' + (recipe ? recipe.outputQty : 1) + '"></div>' +
        '<div class="section-label"><span>المواد الخام</span></div><div class="add-item-row"><select id="bomRawSelect"><option value="">— اختر مادة خام —</option>';
    raw.forEach(function(p) { body += '<option value="' + p.id + '">' + esc(p.name) + '</option>'; });
    body += '</select><select id="bomRawUnit"><option value="">الوحدة</option></select><input id="bomRawQty" type="number" min="0.000001" step="0.000001" value="1" placeholder="الكمية"><button class="btn btn-add" onclick="addBomItem()">+</button></div>' +
        '<div class="items-list" id="bomItemsList"><div class="empty-items">لا توجد مواد مضافة</div></div>';
    window._editingBomItems = recipe ? (recipe.items || []).map(function(item) { return Object.assign({}, item); }) : [];
    Modal.open({ id: 'bomModal', title: recipe ? 'تعديل وصفة BOM' : 'وصفة BOM جديدة', size: 'large', body: body,
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'bomModal\')">إلغاء</button><button class="btn btn-primary" onclick="saveBom()">حفظ الوصفة</button>',
        onOpen: function(modalEl) { populateBomUnits(); renderBomItems(); modalEl.querySelector('#bomRawSelect').addEventListener('change', populateBomUnits); }
    });
}
function populateBomUnits() {
    var select = document.getElementById('bomRawSelect'), unitEl = document.getElementById('bomRawUnit');
    if (!select || !unitEl) return;
    var product = products.find(function(p) { return p.id === select.value; });
    var units = product && Array.isArray(product.units) && product.units.length ? product.units : [{ name: productionBaseUnit(product), factor: 1 }];
    unitEl.innerHTML = units.map(function(unit) { return '<option value="' + esc(unit.name) + '">' + esc(unit.name) + ' (×' + (unit.factor || 1) + ')</option>'; }).join('');
}
function addBomItem() {
    var productId = document.getElementById('bomRawSelect').value;
    var unit = document.getElementById('bomRawUnit').value || '';
    var qty = Number(document.getElementById('bomRawQty').value) || 0;
    var product = products.find(function(p) { return p.id === productId; });
    if (!product || qty <= 0) return showToast('اختر مادة وأدخل كمية صحيحة', 'error');
    var existing = window._editingBomItems.find(function(item) { return item.productId === productId; });
    if (existing) { existing.qty += qty; existing.unit = unit || existing.unit; existing.factor = productionFactor(product, existing.unit); }
    else window._editingBomItems.push({ productId: productId, name: product.name, qty: qty, unit: unit || productionBaseUnit(product), factor: productionFactor(product, unit) });
    renderBomItems();
}
function renderBomItems() {
    var container = document.getElementById('bomItemsList');
    if (!container) return;
    if (!window._editingBomItems.length) { container.innerHTML = '<div class="empty-items">لا توجد مواد مضافة</div>'; return; }
    container.innerHTML = window._editingBomItems.map(function(item, index) { return '<div class="item-row"><span>' + esc(item.name) + '</span><span>' + item.qty + ' ' + esc(item.unit || '') + '</span><button onclick="window._editingBomItems.splice(' + index + ',1);renderBomItems()">×</button></div>'; }).join('');
}
function saveBom() {
    var productId = document.getElementById('bomProduct').value;
    var outputQty = Number(document.getElementById('bomOutputQty').value) || 0;
    if (!productId || outputQty <= 0 || !window._editingBomItems.length) return showToast('أكمل بيانات الوصفة والمواد الخام', 'error');
    var existing = bomRecipes.find(function(item) { return item.productId === productId; });
    var recipe = { id: existing ? existing.id : generateId(), productId: productId, outputQty: outputQty, items: window._editingBomItems, updatedAt: new Date().toISOString() };
    if (existing) bomRecipes[bomRecipes.indexOf(existing)] = recipe; else bomRecipes.push(recipe);
    saveProductionData(); closeModal('bomModal'); renderProduction(); showToast('تم حفظ وصفة BOM', 'success');
}
function deleteBom(id) {
    var recipe = bomRecipes.find(function(item) { return item.id === id; });
    if (!recipe) return showToast('وصفة BOM غير موجودة', 'error');
    var used = productionDocs.some(function(doc) { return doc.recipeId === id; });
    if (used) return showToast('لا يمكن حذف وصفة استُخدمت في سند إنتاج سابق', 'error');
    if (typeof confirm === 'function' && !confirm('هل تريد حذف وصفة BOM هذه؟')) return;
    bomRecipes = bomRecipes.filter(function(item) { return item.id !== id; });
    saveProductionData();
    renderProduction();
    showToast('تم حذف وصفة BOM', 'success');
}
function calculateProductionAvailability(recipe) {
    if (!recipe || !recipe.items.length) return 0;
    var possibleBatches = Infinity;
    recipe.items.forEach(function(item) { var product = products.find(function(p) { return p.id === item.productId; }); var availableBase = (parseFloat(product && product.quantity) || 0); var requiredBasePerBatch = (Number(item.qty) || 0) * productionFactor(product, item.unit); possibleBatches = Math.min(possibleBatches, requiredBasePerBatch > 0 ? availableBase / requiredBasePerBatch : 0); });
    return isFinite(possibleBatches) ? Math.max(0, Math.floor(possibleBatches * 1000000) / 1000000) : 0;
}
function openProductionModal() {
    var recipes = bomRecipes.filter(function(recipe) { return products.some(function(p) { return p.id === recipe.productId; }); });
    if (!recipes.length) return showToast('أنشئ وصفة BOM أولاً', 'error');
    var body = '<div class="form-row"><div class="form-field"><label>الوصفة</label><select id="productionBom">';
    recipes.forEach(function(recipe) { var p = products.find(function(x) { return x.id === recipe.productId; }); body += '<option value="' + recipe.id + '">' + esc(p.name) + ' — ناتج ' + recipe.outputQty + '</option>'; });
    body += '</select></div><div class="form-field"><label>التاريخ</label><input id="productionDate" type="date" value="' + todayISO() + '"></div></div><div class="form-field"><label>عدد الدفعات</label><input id="productionBatches" type="number" min="0.000001" step="0.000001" value="1"></div><div class="info-message" id="productionAvailability" style="text-align:right;line-height:1.8;"></div><div class="form-field"><label>ملاحظة</label><input id="productionNote" type="text" placeholder="ملاحظة اختيارية"></div>';
    Modal.open({ id: 'productionModal', title: 'سند إنتاج جديد', size: 'normal', body: body, footer: '<button class="btn btn-cancel" onclick="closeModal(\'productionModal\')">إلغاء</button><button class="btn btn-success" onclick="saveProduction()">حفظ سند الإنتاج</button>', onOpen: function(modalEl) { var update = function() { var r = bomRecipes.find(function(x) { return x.id === document.getElementById('productionBom').value; }); var batches = Number(document.getElementById('productionBatches').value) || 0; var available = calculateProductionAvailability(r); document.getElementById('productionAvailability').textContent = 'المتاح للإنتاج: ' + available + ' دفعة — الناتج المتوقع: ' + (r ? r.outputQty * batches : 0); }; modalEl.querySelector('#productionBom').addEventListener('change', update); modalEl.querySelector('#productionBatches').addEventListener('input', update); update(); }});
}
function saveProduction() {
    var recipe = bomRecipes.find(function(item) { return item.id === document.getElementById('productionBom').value; });
    var batches = Number(document.getElementById('productionBatches').value) || 0;
    var date = document.getElementById('productionDate').value || todayISO(), note = document.getElementById('productionNote').value.trim();
    if (!recipe || batches <= 0) return showToast('أدخل عدد دفعات صحيح', 'error');
    if (batches > calculateProductionAvailability(recipe) + 0.0000001) return showToast('المواد الخام غير كافية لهذه الكمية', 'error');
    var finished = products.find(function(p) { return p.id === recipe.productId; });
    if (!finished) return showToast('المنتج التام غير موجود', 'error');
    var docId = generateDocNumber('PROD'), inputs = [], outputs = [];
    
    var productionCost = typeof calculateProductionCost === 'function' ? calculateProductionCost(recipe, batches) : { total: 0, unit: 0, known: false, costPartial: false, missingCostItems: [] };
    
    // ✅ NEW: حفظ snapshot لحالة المنتج التام قبل الإنتاج (لإلغاء صحيح)
    var prevAvgCost = parseFloat(finished.avgCost);
    if (!isFinite(prevAvgCost) || prevAvgCost < 0) prevAvgCost = null;
    var prevQuantity = parseFloat(finished.quantity) || 0;
    
    recipe.items.forEach(function(item) {
    var raw = products.find(function(p) { return p.id === item.productId; });
    var factor = productionFactor(raw, item.unit);
    var baseQty = (Number(item.qty) || 0) * batches * factor;
    var displayQty = Number(item.qty || 0) * batches;
    raw.quantity = (parseFloat(raw.quantity) || 0) - baseQty;
    inputs.push({ productId: raw.id, name: raw.name, qty: displayQty, unit: item.unit || productionBaseUnit(raw), baseQty: baseQty, factor: factor });

    // ✅ إصلاح: price = متوسط التكلفة الفعلي (بدل سعر البيع)
    var rawUnitCost = (typeof getProductAverageCost === 'function')
        ? (getProductAverageCost(raw) || 0)
        : (parseFloat(raw.price) || 0);

    stockMovements.push({
        id: generateId(),
        date: date,
        type: 'out',
        docType: 'سند إنتاج',
        docId: docId,
        productId: raw.id,
        productName: raw.name,
        qty: baseQty,
        displayQty: displayQty,
        unit: productionBaseUnit(raw),
        price: rawUnitCost,
        currency: raw.currency || 'YER',
        note: note,
        createdAt: new Date().toISOString()
    });
});
    var outputQty = (Number(recipe.outputQty) || 0) * batches;
    
    // تحديث متوسط التكلفة للمنتج التام طالما توفرت تكلفة إجمالية أكبر من الصفر
    // تحديث متوسط التكلفة للمنتج التام مع تمرير العملة وسعر الصرف
    if (productionCost.total > 0 && typeof applyWeightedAverageCost === 'function') {
        var productionCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
        var productionRate = (typeof getCurrentExchangeRateSnapshot === 'function')
            ? getCurrentExchangeRateSnapshot(productionCurrency)
            : 1;
        applyWeightedAverageCost(finished, outputQty, productionCost.unit, productionCurrency, productionRate);
    }
    
    finished.quantity = (parseFloat(finished.quantity) || 0) + outputQty;
outputs.push({ productId: finished.id, name: finished.name, qty: outputQty, unit: productionBaseUnit(finished), unitCost: productionCost.unit });

// ✅ إصلاح: price = تكلفة الإنتاج الفعلية (بدل سعر البيع)
stockMovements.push({
    id: generateId(),
    date: date,
    type: 'in',
    docType: 'سند إنتاج',
    docId: docId,
    productId: finished.id,
    productName: finished.name,
    qty: outputQty,
    price: productionCost.unit || 0,
    currency: finished.currency || 'YER',
    note: note,
    createdAt: new Date().toISOString()
});
    
    productionDocs.push({ 
        id: docId, 
        date: date, 
        recipeId: recipe.id, 
        productId: finished.id, 
        productName: finished.name, 
        batches: batches, 
        outputQty: outputQty, 
        productionCost: productionCost.total,
        currency: typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER',
        exchangeRate: typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER') : 1,
        costKnown: productionCost.known, 
        costPartial: productionCost.costPartial, 
        missingCostItems: productionCost.missingCostItems, 
        unitCost: productionCost.unit, 
        inputs: inputs, 
        outputs: outputs, 
        note: note, 
        // ✅ NEW: snapshot للحالة قبل الإنتاج
        prevAvgCost: prevAvgCost,
        prevQuantity: prevQuantity,
        createdAt: new Date().toISOString() 
    });
    
    saveProducts(); saveStockMovements(); saveProductionData(); if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation(); closeModal('productionModal'); renderInventory(); renderProduction(); if (typeof updateDashboard === 'function') updateDashboard(); showToast('تم حفظ سند الإنتاج ' + docId, 'success');
}

// ================================================================
// ===== إلغاء سند الإنتاج =====
// ================================================================

function cancelProduction(id) {
    var doc = productionDocs.find(function(item) { return item.id === id; });
    if (!doc) {
        showToast('سند الإنتاج غير موجود', 'error');
        return;
    }
    if (doc.cancelled === true || doc.documentStatus === 'cancelled') {
        showToast('السند ملغى مسبقاً', 'info');
        return;
    }

    Modal.confirm({
        title: 'تأكيد إلغاء سند الإنتاج',
        message:
            'سيتم:\n' +
            '• عكس المواد الخام (إرجاعها للمخزون)\n' +
            '• سحب المنتج التام من المخزون\n' +
            '• إنشاء قيد عكسي\n' +
            '• الاحتفاظ بالسند في السجل\n\n' +
            'السند: ' + doc.id + '\n' +
            'المنتج: ' + doc.productName + '\n' +
            'الكمية: ' + doc.outputQty + '\n\n' +
            'هل تريد المتابعة؟',
        confirmText: 'إلغاء السند',
        cancelText: 'تراجع',
        confirmColor: 'danger',
        onConfirm: function() {
            // ===== 1. عكس المخزون: المواد ترجع =====
            (doc.inputs || []).forEach(function(input) {
                var raw = products.find(function(p) { return p.id === input.productId; });
                if (raw) {
                    var baseQty = parseFloat(input.baseQty) || 0;
                    raw.quantity = (parseFloat(raw.quantity) || 0) + baseQty;
                }
            });

            // ===== 2. فحص كفاية المنتج التام قبل السحب =====
            var finished = products.find(function(p) { return p.id === doc.productId; });
            if (!finished) {
                showToast('المنتج التام غير موجود', 'error');
                return;
            }
            var currentFinishedQty = parseFloat(finished.quantity) || 0;
            var outputQty = parseFloat(doc.outputQty) || 0;
            if (currentFinishedQty < outputQty) {
                showToast(
                    'لا يمكن إلغاء السند — جزء من المنتج تم استخدامه/بيعه.\n' +
                    'المطلوب سحبه: ' + outputQty +
                    ' | المتاح حالياً: ' + currentFinishedQty,
                    'error',
                    8000
                );
                return;
            }
            finished.quantity = currentFinishedQty - outputQty;

            // ===== 3. ✅ NEW: استعادة avgCost للحالة قبل الإنتاج =====
            // إذا كان السند يحتوي على snapshot، نستخدمه لاستعادة avgCost
            if (doc.prevAvgCost !== undefined && doc.prevAvgCost !== null) {
                finished.avgCost = doc.prevAvgCost;
                // إذا كان avgCost السابق null، نُعيده null
                if (doc.prevAvgCost === null) {
                    finished.avgCost = null;
                }
            } else {
                // fallback: حساب avgCost عكسي بسيط
                // avgCost_prev = (avgCost_current × qty_current_before_cancel - unitCost_production × outputQty) / prevQuantity
                var currentAvgCost = parseFloat(finished.avgCost) || 0;
                var prevQty = parseFloat(doc.prevQuantity) || 0;
                var unitCost = parseFloat(doc.unitCost) || 0;
                if (prevQty > 0) {
                    var prevTotal = (currentAvgCost * currentFinishedQty) - (unitCost * outputQty);
                    finished.avgCost = prevTotal / prevQty;
                }
            }

            // ===== 4. وسم السند كملغى =====
            doc.cancelled = true;
            doc.documentStatus = 'cancelled';
            doc.cancelledAt = new Date().toISOString();
            doc.cancelReason = 'إلغاء يدوي من المستخدم';

            // ===== 5. تسجيل حركات مخزون عكسية =====
            (doc.inputs || []).forEach(function(input) {
                var raw = products.find(function(p) { return p.id === input.productId; });
                stockMovements.push({
                    id: generateId(),
                    date: todayISO(),
                    type: 'in',
                    docType: 'إلغاء سند إنتاج',
                    docId: doc.id,
                    productId: input.productId,
                    productName: input.name,
                    qty: parseFloat(input.baseQty) || 0,
                    unit: productionBaseUnit(raw),
                    note: 'إلغاء سند الإنتاج ' + doc.id,
                    createdAt: new Date().toISOString()
                });
            });

            if (finished) {
                stockMovements.push({
                    id: generateId(),
                    date: todayISO(),
                    type: 'out',
                    docType: 'إلغاء سند إنتاج',
                    docId: doc.id,
                    productId: finished.id,
                    productName: finished.name,
                    qty: parseFloat(doc.outputQty) || 0,
                    unit: productionBaseUnit(finished),
                    note: 'إلغاء سند الإنتاج ' + doc.id,
                    createdAt: new Date().toISOString()
                });
            }

            // ===== 6. الحفظ =====
            saveProducts();
            saveStockMovements();
            saveProductionData();

            // ===== 7. إعادة توليد القيود =====
            if (typeof syncJournalAfterMutation === 'function') {
                syncJournalAfterMutation();
            }

            // ===== 8. مزامنة الشاشات =====
            if (typeof oaRefreshRelated === 'function') {
                oaRefreshRelated('delete');
            } else {
                renderProduction();
                if (typeof renderInventory === 'function') renderInventory();
                if (typeof updateDashboard === 'function') updateDashboard();
            }

            showToast('تم إلغاء سند الإنتاج ' + doc.id, 'success');
        }
    });
}

// ================================================================
// ===== طباعة سند إنتاج (القالب الجديد) =====
// ================================================================

function printProductionDocument(id) {
    var doc = productionDocs.find(function(item) { return item.id === id; });
    if (!doc) {
        if (typeof showToast === 'function') showToast('سند الإنتاج غير موجود', 'error');
        return;
    }

    // الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // الحمولة
    var payload = {
        type: 'production_order',
        doc: doc,
        settings: settings,
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/production-voucher.html';
    window.location.href = url;
}

function renderProduction() {
    var bomBody = document.getElementById('bomTableBody'), prodBody = document.getElementById('productionTableBody');
    if (bomBody) bomBody.innerHTML = bomRecipes.length ? bomRecipes.map(function(r, i) { var p = products.find(function(x) { return x.id === r.productId; }); return '<tr><td>' + (i + 1) + '</td><td>' + esc(p ? p.name : '-') + '</td><td>' + r.outputQty + '</td><td>' + r.items.length + '</td><td style="white-space:nowrap;"><button class="btn-view" style="margin-left:4px;" onclick="openBomModal(bomRecipes[' + i + '])">تعديل</button><button class="btn-delete" onclick="deleteBom(\'' + r.id + '\')" title="حذف">حذف</button></td></tr>'; }).join('') : '<tr><td colspan="5" class="empty-cell">لا توجد وصفات</td></tr>';
    
 if (prodBody) {
    // ✅ تطبيق فلتر التاريخ
    var filteredDocs = productionDocs.slice();
    if (_productionFilterFrom) {
        filteredDocs = filteredDocs.filter(function(d) {
            return d.date >= _productionFilterFrom;
        });
    }
    if (_productionFilterTo) {
        filteredDocs = filteredDocs.filter(function(d) {
            return d.date <= _productionFilterTo;
        });
    }

    // ترتيب — الأحدث أولاً
    filteredDocs = filteredDocs.sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });

    prodBody.innerHTML = filteredDocs.length ? filteredDocs.map(function(d, i) { 
            var statusBadge = d.costPartial 
                ? '<span style="color: #e67e22; font-weight: bold;" title="بعض المواد الخام بلا تكلفة معروفة">⚠️ جزئية</span>' 
                : '<span style="color: #27ae60; font-weight: bold;">✅ كاملة</span>';
            var isCancelled = d.cancelled === true || d.documentStatus === 'cancelled';
            var rowStyle = isCancelled ? 'opacity:0.5;text-decoration:line-through;' : '';
            var cancelBadge = isCancelled ? ' <span style="background:#888;color:#fff;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;">ملغى</span>' : '';
          var cancelBtn = isCancelled ? '' : '<button class="text-action-btn btn-delete" onclick="cancelProduction(\'' + d.id + '\')">إلغاء</button>';
return '<tr style="' + rowStyle + '"><td>' + (i + 1) + '</td><td>' + esc(d.id) + cancelBadge + '</td><td>' + esc(d.date) + '</td><td>' + esc(d.productName) + '</td><td>' + d.outputQty + '</td><td style="white-space:nowrap;"><button class="text-action-btn btn-view" onclick="printProductionDocument(\'' + d.id + '\')">عرض / PDF</button>' + cancelBtn + '</td></tr>';
        }).join('') :'<tr><td colspan="6" class="empty-cell">لا توجد سندات إنتاج في هذه الفترة</td></tr>';
    }
}

function initProduction() {
    loadProductionData();
    _prodLoadFilters();
    _prodBindFilterInputs();
    renderProduction();
}

// ================================================================
// ===== Migration: إصلاح حركات الإنتاج القديمة =====
// ================================================================

/**
 * إصلاح سعر (price) في حركات الإنتاج القديمة
 * يُشغَّل مرة واحدة بعد إصلاح production.js
 *
 * المنطق:
 * - كل سند إنتاج قديم له unitCost محفوظ
 * - حركة "in" للمنتج التام يجب أن يكون price = unitCost
 * - حركة "out" للمواد الخام يجب أن يكون price = avgCost للمادة
 *
 * @returns {object} { fixed, skipped, details }
 */
function migrateOldProductionMovements() {
    if (typeof productionDocs === 'undefined' || !Array.isArray(productionDocs)) {
        console.warn('[OA] migrateOldProductionMovements: productionDocs غير معرّف');
        return { fixed: 0, skipped: 0, details: [] };
    }
    if (typeof stockMovements === 'undefined' || !Array.isArray(stockMovements)) {
        console.warn('[OA] migrateOldProductionMovements: stockMovements غير معرّف');
        return { fixed: 0, skipped: 0, details: [] };
    }

    var fixed = 0;
    var skipped = 0;
    var details = [];

    productionDocs.forEach(function(doc) {
        // تجاهل السندات الملغاة
        if (doc.cancelled === true || doc.documentStatus === 'cancelled') {
            skipped++;
            return;
        }

        // ===== 1. إصلاح حركة إدخال المنتج التام =====
        var correctFinishedPrice = parseFloat(doc.unitCost) || 0;
        if (correctFinishedPrice > 0) {
            stockMovements.forEach(function(m) {
                if (m.docId !== doc.id) return;
                if (m.productId !== doc.productId) return;
                if (m.type !== 'in') return;
                if (m.docType !== 'سند إنتاج') return;

                var oldPrice = parseFloat(m.price) || 0;
                if (Math.abs(oldPrice - correctFinishedPrice) > 0.001) {
                    m.price = correctFinishedPrice;
                    fixed++;
                    details.push({
                        docId: doc.id,
                        product: m.productName,
                        type: 'in',
                        oldPrice: oldPrice,
                        newPrice: correctFinishedPrice
                    });
                    console.log('[OA] إصلاح سعر إدخال: ' + m.productName + ' — ' + oldPrice.toFixed(2) + ' → ' + correctFinishedPrice.toFixed(2));
                }
            });
        }

        // ===== 2. إصلاح حركات إخراج المواد الخام =====
        (doc.inputs || []).forEach(function(input) {
            var rawProduct = (typeof products !== 'undefined' && Array.isArray(products))
                ? products.find(function(p) { return p.id === input.productId; })
                : null;
            if (!rawProduct) return;

            // avgCost الحالي (بعد ترحيل الشراءات)
            var correctRawPrice = (typeof getProductAverageCost === 'function')
                ? (getProductAverageCost(rawProduct) || 0)
                : (parseFloat(rawProduct.price) || 0);
            if (correctRawPrice <= 0) return;

            stockMovements.forEach(function(m) {
                if (m.docId !== doc.id) return;
                if (m.productId !== input.productId) return;
                if (m.type !== 'out') return;
                if (m.docType !== 'سند إنتاج') return;

                var oldPrice = parseFloat(m.price) || 0;
                if (Math.abs(oldPrice - correctRawPrice) > 0.001) {
                    m.price = correctRawPrice;
                    fixed++;
                    details.push({
                        docId: doc.id,
                        product: m.productName,
                        type: 'out',
                        oldPrice: oldPrice,
                        newPrice: correctRawPrice
                    });
                    console.log('[OA] إصلاح سعر إخراج: ' + m.productName + ' — ' + oldPrice.toFixed(2) + ' → ' + correctRawPrice.toFixed(2));
                }
            });
        });
    });

    if (fixed > 0 && typeof saveStockMovements === 'function') {
        saveStockMovements();
    }

    console.log('[OA] ✅ إصلاح حركات الإنتاج: ' + fixed + ' مُصحّح، ' + skipped + ' متجاهل');

    return {
        fixed: fixed,
        skipped: skipped,
        details: details
    };
}
// ضمان الوصول من onclick
window._prodClearFilters = _prodClearFilters;

