// ================================================================
// Open Account — نظام محاسبي
// الملف: customers.js
// الوصف: إدارة العملاء
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var customers = [];


// ================================================================
// ===== 2. تحميل وحفظ العملاء =====
// ================================================================

/**
 * تحميل العملاء من LocalStorage
 */
function loadCustomers() {
    customers = Storage.get(STORAGE_KEYS.CUSTOMERS, []);
    if (!Array.isArray(customers)) customers = [];
}


/**
 * حفظ العملاء في LocalStorage
 */
function saveCustomers() {
    Storage.set(STORAGE_KEYS.CUSTOMERS, customers);
}


// ================================================================
// ===== 3. عرض جدول العملاء =====
// ================================================================

/**
 * عرض العملاء في الجدول
 */
function renderCustomers() {
    var tbody = document.getElementById('custTableBody');
    if (!tbody) return;
    
    var searchEl = document.getElementById('custSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';
    
    var filtered = customers;
    if (search) {
        filtered = customers.filter(function(c) {
            return String(c.name || '').toLowerCase().indexOf(search) !== -1 ||
                   String(c.phone || '').indexOf(search) !== -1;
        });
    }
    
    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-cell">لا يوجد عملاء</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function(c, i) {
            html += '<tr>' +
                '<td>' + (i + 1) + '</td>' +
                '<td>' + esc(c.name) + '</td>' +
                '<td>' + esc(c.phone || '-') + '</td>' +
                '<td>' + esc(c.address || '-') + '</td>' +
                '<td>' +
                    '<button class="btn-edit" onclick="editCustomer(\'' + c.id + '\')" title="تعديل">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>' +
                    '</button>' +
                    '<button class="btn-delete" onclick="deleteCustomer(\'' + c.id + '\')" title="حذف">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
                    '</button>' +
                '</td>' +
            '</tr>';
        });
        tbody.innerHTML = html;
    }
    
    updateCustomersStats();
}


// ================================================================
// ===== 4. إحصائيات العملاء =====
// ================================================================

/**
 * تحديث إحصائيات العملاء
 */
function updateCustomersStats() {
    setText('dashCustomers', customers.length);
    setText('custTotalCount', customers.length);

    // ✅ توحيد المصدر: قراءة رصيد العملاء من القيود
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var totalDue = 0;

    if (typeof AccountingBalance !== 'undefined') {
        var ab = AccountingBalance.inBaseCurrency('1100');
        totalDue = ab.balance;
    }

    var displayValue = formatAmountWithCommas(Math.abs(totalDue)) + ' ' + base;
    if (totalDue < -0.01) {
        displayValue += ' (دائن)';
    } else if (totalDue <= 0.01) {
        displayValue = '0.00 ' + base;
    }

    setText('custDueAmount', displayValue);
}


// ================================================================
// ===== 5. نافذة إضافة/تعديل عميل =====
// ================================================================

/**
 * فتح نافذة إضافة/تعديل عميل
 * @param {object} data - بيانات العميل (للتعديل)
 */
function openCustModal(data) {
    var isEdit = data && data.id;
    
    var bodyHTML = 
        '<input type="hidden" id="custEditId" value="' + (isEdit ? data.id : '') + '">' +
        
        '<div class="form-field">' +
            '<label>اسم العميل</label>' +
            '<input type="text" id="custName" placeholder="أدخل اسم العميل" value="' + (isEdit ? esc(data.name) : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>رقم الهاتف</label>' +
            '<input type="tel" id="custPhone" placeholder="7xxxxxxxx" value="' + (isEdit ? esc(data.phone || '') : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>البريد الإلكتروني (اختياري)</label>' +
            '<input type="email" id="custEmail" placeholder="example@email.com" value="' + (isEdit ? esc(data.email || '') : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>العنوان (اختياري)</label>' +
            '<input type="text" id="custAddress" placeholder="المدينة - المنطقة" value="' + (isEdit ? esc(data.address || '') : '') + '">' +
        '</div>';
    
    var footerHTML = 
        '<button class="btn btn-cancel" onclick="closeModal(\'custModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="saveCustomer()">حفظ</button>';
    
    Modal.open({
        id: 'custModal',
        title: isEdit ? 'تعديل عميل' : 'إضافة عميل جديد',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            setTimeout(function() {
                var nameInput = modalEl.querySelector('#custName');
                if (nameInput) nameInput.focus();
            }, 200);
        }
    });
}


// ================================================================
// ===== 6. تعديل عميل =====
// ================================================================

/**
 * فتح نافذة تعديل عميل
 * @param {string} id - معرف العميل
 */
function editCustomer(id) {
    var customer = customers.find(function(c) { return c.id === id; });
    if (customer) {
        openCustModal(customer);
    }
}


// ================================================================
// ===== 7. حفظ عميل =====
// ================================================================

/**
 * حفظ عميل (إضافة أو تعديل)
 */
function saveCustomer() {
    var idEl = document.getElementById('custEditId');
    var nameEl = document.getElementById('custName');
    var phoneEl = document.getElementById('custPhone');
    var emailEl = document.getElementById('custEmail');
    var addrEl = document.getElementById('custAddress');
    
    var id = idEl ? idEl.value : '';
    var name = nameEl ? nameEl.value.trim() : '';
    var phone = phoneEl ? phoneEl.value.trim() : '';
    var email = emailEl ? emailEl.value.trim() : '';
    var address = addrEl ? addrEl.value.trim() : '';
    
    if (!name) {
        showToast('يرجى إدخال اسم العميل', 'error');
        return;
    }
    
    if (id) {
        // تعديل
        var index = customers.findIndex(function(c) { return c.id === id; });
        if (index !== -1) {
            customers[index] = {
                id: id,
                name: name,
                phone: phone,
                email: email,
                address: address
            };
        }
        showToast('تم تعديل العميل', 'success');
    } else {
        // إضافة
        customers.push({
            id: generateId(),
            name: name,
            phone: phone,
            email: email,
            address: address
        });
        showToast('تم إضافة العميل', 'success');
    }
    
    saveCustomers();
    closeModal('custModal');
    renderCustomers();
}


// ================================================================
// ===== 8. حذف عميل =====
// ================================================================

/**
 * حذف عميل مع تأكيد
 * @param {string} id - معرف العميل
 */
function deleteCustomer(id) {
    var customer = customers.find(function(c) { return c.id === id; });
    if (!customer) return;
    
    Modal.confirm({
        title: 'تأكيد الحذف',
        message: 'هل أنت متأكد من حذف العميل "' + customer.name + '"؟',
        confirmText: 'حذف',
        cancelText: 'إلغاء',
        confirmColor: 'danger',
        onConfirm: function() {
            customers = customers.filter(function(c) { return c.id !== id; });
            saveCustomers();
            renderCustomers();
            showToast('تم حذف العميل', 'success');
        }
    });
}


// ================================================================
// ===== 9. تهيئة العملاء =====
// ================================================================

/**
 * تهيئة نظام العملاء
 */
function initCustomers() {
    loadCustomers();
    renderCustomers();
    
    var searchEl = document.getElementById('custSearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderCustomers, 300));
    }
    
    console.log('Customers: ' + customers.length + ' عميل');
}


// ================================================================
// ===== END OF CUSTOMERS.JS =====
// ================================================================