// ================================================================
// Open Account — نظام محاسبي
// الملف: expenses.js
// الوصف: إدارة المصاريف مع الأرشفة وسندات الصرف التلقائية
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var expenses = [];
var showArchivedExpenses = false;
var _currentExpenseToDelete = null;

// ✅ وضع الأرشفة الموحد
var _archiveExpensesMode = false;
var _selectedExpensesForArchive = {};


// أنواع المصاريف
var EXPENSE_TYPES = [
    'إيجار', 'كهرباء', 'ماء', 'إنترنت', 'هاتف', 'رواتب',
    'صيانة', 'نقل وتوصيل', 'قرطاسية', 'دعاية وإعلان',
    'ضيافة', 'زكاة', 'مصاريف بنكية', 'أخرى'
];


// ================================================================
// ===== 2. تحميل وحفظ المصاريف =====
// ================================================================

function loadExpenses() {
    expenses = Storage.get(STORAGE_KEYS.EXPENSES, []);
    if (!Array.isArray(expenses)) expenses = [];
}


function saveExpenses() {
    Storage.set(STORAGE_KEYS.EXPENSES, expenses);
}


// ================================================================
// ===== 3. عرض جدول المصاريف =====
// ================================================================

function renderExpenses() {
    var tbody = document.getElementById('expTableBody');
    if (!tbody) return;
    
    var searchEl = document.getElementById('expSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';
    
    // ✅ فلترة المؤرشفة
    var filtered = expenses.filter(function(e) {
        if (e.cancelled) return false;
        if (showArchivedExpenses) return e.archived === true;
        return !e.archived;
    });
    
    // البحث
    if (search) {
        filtered = filtered.filter(function(e) {
            return String(e.type || '').toLowerCase().indexOf(search) !== -1 ||
                   String(e.note || '').toLowerCase().indexOf(search) !== -1 ||
                   String(e.recipient || '').toLowerCase().indexOf(search) !== -1;
        });
    }
    
    // ترتيب حسب التاريخ (تنازلي)
    filtered = filtered.slice().sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });
    
    if (!filtered.length) {
        var emptyMsg = showArchivedExpenses ? 'لا توجد مصاريف مؤرشفة' : 'لا توجد مصاريف';
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">' + emptyMsg + '</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function(e, i) {
            // ✅ checkbox في وضع الأرشفة
            var firstCell = (i + 1);
            if (_archiveExpensesMode && !showArchivedExpenses) {
                var checked = _selectedExpensesForArchive[e.id] ? 'checked' : '';
                firstCell = '<input type="checkbox" class="exp-archive-cb" data-id="' + e.id + '" ' + checked + ' onchange="onExpensesArchiveCheckboxChange(this)">';
            }

            var actionsHtml = '';
            
            if (e.archived) {
                actionsHtml = 
                    '<button class="btn-view" onclick="restoreExpense(\'' + e.id + '\')" title="استرجاع">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>' +
                    '</button>' +
                    '<button class="btn-delete" onclick="permanentDeleteExpense(\'' + e.id + '\')" title="حذف نهائي">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
                    '</button>';
          } else if (!_archiveExpensesMode) {
    actionsHtml = 
        '<button class="btn-view" onclick="viewExpense(\'' + e.id + '\')" title="معاينة">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
        '</button>' +
        '<button class="btn-edit" onclick="editExpense(\'' + e.id + '\')" title="تعديل">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>' +
        '</button>' +
        '<button class="btn-delete" onclick="deleteExpense(\'' + e.id + '\')" title="حذف/أرشفة">' +
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
        '</button>';
}
else {
                // في وضع الأرشفة — فقط عرض
                actionsHtml = '';
            }
            
            html += '<tr>' +
                '<td>' + firstCell + '</td>' +
                '<td>' + formatDate(e.date) + '</td>' +
                '<td>' + esc(e.type || '-') + '</td>' +
                '<td>' + formatCurrency(e.amount, e.currency) + '</td>' +
                '<td>' + esc(e.recipient || e.note || '-') + '</td>' +
                '<td>' + actionsHtml + '</td>' +
            '</tr>';
        });
        tbody.innerHTML = html;
    }
    
    // ✅ شريط أدوات الأرشفة
    _renderExpensesArchiveToolbar();
    
    updateExpensesStats();
}

// ✅ شريط أدوات الأرشفة
function _renderExpensesArchiveToolbar() {
    var bar = document.getElementById('expensesArchiveBar');
    if (!bar) return;

    if (!_archiveExpensesMode) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    var count = Object.keys(_selectedExpensesForArchive).length;
    bar.style.display = 'flex';
    bar.innerHTML =
        '<button class="btn btn-secondary" onclick="toggleSelectAllExpenses()" style="flex:1;font-size:12px;">' +
            (_allActiveExpensesSelected() ? 'إلغاء الكل' : 'تحديد الكل') +
        '</button>' +
        '<button class="btn btn-warning" onclick="confirmArchiveExpenses()" style="flex:1;font-size:12px;" ' + (count === 0 ? 'disabled' : '') + '>' +
            'أرشفة المحدد (' + count + ')' +
        '</button>' +
        '<button class="btn btn-cancel" onclick="toggleArchiveExpensesMode()" style="flex:1;font-size:12px;">' +
            'إلغاء' +
        '</button>';
}

function _allActiveExpensesSelected() {
    var active = expenses.filter(function(e) { return !e.cancelled && !e.archived; });
    if (!active.length) return false;
    return active.every(function(e) { return _selectedExpensesForArchive[e.id]; });
}

// ✅ دوال الأرشفة الموحدة
function toggleArchiveExpensesMode() {
    _archiveExpensesMode = !_archiveExpensesMode;
    _selectedExpensesForArchive = {};
    if (_archiveExpensesMode) showArchivedExpenses = false;
    _updateArchivedBtnLabel();
    renderExpenses();
}

function toggleSelectAllExpenses() {
    var active = expenses.filter(function(e) { return !e.cancelled && !e.archived; });
    if (_allActiveExpensesSelected()) {
        _selectedExpensesForArchive = {};
    } else {
        active.forEach(function(e) { _selectedExpensesForArchive[e.id] = true; });
    }
    renderExpenses();
}

function onExpensesArchiveCheckboxChange(cb) {
    var id = cb.getAttribute('data-id');
    if (cb.checked) _selectedExpensesForArchive[id] = true;
    else delete _selectedExpensesForArchive[id];
    _renderExpensesArchiveToolbar();
}

function confirmArchiveExpenses() {
    var ids = Object.keys(_selectedExpensesForArchive);
    if (!ids.length) { showToast('لم تحدد أي مصروف', 'warning'); return; }
    if (!confirm('سيتم أرشفة ' + ids.length + ' مصروف.\nستُخفى من العرض — لا تُحذف.\n\nمتابعة؟')) return;

    var count = 0;
    expenses.forEach(function(e) {
        if (_selectedExpensesForArchive[e.id]) {
            e.archived = true;
            e.archivedAt = new Date().toISOString();
            // ✅ أرشفة سند الصرف المرتبط
            if (e.paymentId && typeof payments !== 'undefined') {
                var p = payments.find(function(pp) { return pp.id === e.paymentId; });
                if (p) {
                    p.archived = true;
                    p.archivedAt = new Date().toISOString();
                }
            }
            count++;
        }
    });
    if (typeof savePayments === 'function') savePayments();

    saveExpenses();
    _archiveExpensesMode = false;
    _selectedExpensesForArchive = {};
    _updateArchivedBtnLabel();
    renderExpenses();
    if (typeof renderPayments === 'function') renderPayments();
    showToast('تمت أرشفة ' + count + ' مصروف', 'success');
}

function _updateArchivedBtnLabel() {
    var btn = document.getElementById('btnArchived');
    if (!btn) return;
    if (showArchivedExpenses) {
        btn.innerHTML = '<span>عرض النشطة</span>';
        btn.style.background = '#1a7a4a';
    } else {
        btn.innerHTML = '<span>عرض المؤرشفة</span>';
        btn.style.background = '#7a7a7a';
    }
}


// ================================================================
// ===== 4. إحصائيات المصاريف =====
// ================================================================

function updateExpensesStats() {
    // الإجماليات تُعرض منفصلة حسب العملة حتى لا يتم جمع YER وSAR كأنهما وحدة واحدة.
    var totals = {};
    var monthTotals = {};
    var now = new Date();
    var currentMonth = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');

    expenses.forEach(function(e) {
        if (e.archived) return;
        if (e.cancelled) return;        
        var amount = parseFloat(e.amount) || 0;
        var c = e.currency || 'YER';
        totals[c] = (totals[c] || 0) + amount;
        if (e.date && e.date.indexOf(currentMonth) === 0) {
            monthTotals[c] = (monthTotals[c] || 0) + amount;
        }
    });

    var formatMulti = function(obj) {
        if (typeof _formatMultiCurrency === 'function') return _formatMultiCurrency(obj);
        var parts = [];
        ['YER', 'SAR', 'USD'].forEach(function(c) {
            if (obj[c]) parts.push(formatAmountWithCommas(obj[c]) + ' ' + c);
        });
        return parts.length ? parts.join(' | ') : '0.00';
    };

    setText('expTotal', formatMulti(totals));
    setText('expMonthTotal', formatMulti(monthTotals));
    setText('expCount', expenses.filter(function(e) { return !e.archived; }).length);

    // تحديث لوحة التحكم إن كانت متاحة.
    if (typeof updateDashboard === 'function') updateDashboard();
}


// ================================================================
// ===== 5. نافذة إضافة/تعديل مصروف =====
// ================================================================

function openExpenseModal(data) {
    var isEdit = data && data.id;
    
    var bodyHTML = _buildExpenseFormHTML(data, isEdit);
    
    var footerHTML = 
        '<button class="btn btn-cancel" onclick="closeModal(\'expModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="saveExpense()">حفظ</button>';
    
    Modal.open({
        id: 'expModal',
        title: isEdit ? 'تعديل مصروف' : 'إضافة مصروف جديد',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            var dateEl = modalEl.querySelector('#expDate');
            if (dateEl && !isEdit) dateEl.value = todayISO();
            var currencyEl = modalEl.querySelector('#expCurrency');
            if (currencyEl && !isEdit) {
                currencyEl.value = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
            }
            if (currencyEl && isEdit && data.currency) currencyEl.value = data.currency;
        }
    });
}


function _buildExpenseFormHTML(data, isEdit) {
    // بناء خيارات الأنواع
    var typeOptions = '';
    EXPENSE_TYPES.forEach(function(t) {
        var selected = isEdit && data.type === t ? ' selected' : '';
        typeOptions += '<option value="' + t + '"' + selected + '>' + t + '</option>';
    });
    
    return '' +
        '<input type="hidden" id="expEditId" value="' + (isEdit ? data.id : '') + '">' +
        
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="expDate" value="' + (isEdit ? data.date : '') + '">' +
            '</div>' +
            '<div class="form-field">' +
                '<label>المبلغ</label>' +
                '<input type="number" id="expAmount" placeholder="0.00" step="0.01" min="0" value="' + (isEdit ? data.amount : '') + '">' +
            '</div>' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>العملة</label>' +
            '<select id="expCurrency" class="currency-select">' +
                '<option value="YER">ريال يمني</option>' +
                '<option value="SAR">ريال سعودي</option>' +
                '<option value="USD">دولار أمريكي</option>' +
            '</select>' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>النوع</label>' +
            '<select id="expType">' + typeOptions + '</select>' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>المستلم (اختياري)</label>' +
            '<input type="text" id="expRecipient" placeholder="اسم المستلم أو الجهة" value="' + (isEdit ? esc(data.recipient || '') : '') + '">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>ملاحظة (اختياري)</label>' +
            '<input type="text" id="expNote" placeholder="تفاصيل إضافية" value="' + (isEdit ? esc(data.note || '') : '') + '">' +
        '</div>';
}


// ================================================================
// ===== 6. تعديل مصروف =====
// ================================================================

function editExpense(id) {
    var exp = expenses.find(function(e) { return e.id === id; });
    if (exp) {
        openExpenseModal(exp);
        
        // تعيين العملة بعد فتح النافذة
        setTimeout(function() {
            var currencyEl = document.getElementById('expCurrency');
            if (currencyEl && exp.currency) {
                currencyEl.value = exp.currency;
            }
        }, 200);
    }
}


// ================================================================
// ===== 7. حفظ مصروف =====
// ================================================================

function saveExpense() {
    var idEl = document.getElementById('expEditId');
    var dateEl = document.getElementById('expDate');
    var typeEl = document.getElementById('expType');
    var amountEl = document.getElementById('expAmount');
    var currencyEl = document.getElementById('expCurrency');
    var recipientEl = document.getElementById('expRecipient');
    var noteEl = document.getElementById('expNote');
    
    var id = idEl ? idEl.value : '';
    var date = dateEl ? dateEl.value : '';
    var type = typeEl ? typeEl.value : 'أخرى';
    var amount = parseFloat(amountEl ? amountEl.value : 0) || 0;
    var currency = currencyEl ? currencyEl.value : ((typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER');
    var recipient = recipientEl ? recipientEl.value.trim() : '';
    var note = noteEl ? noteEl.value.trim() : '';
    
// التحقق
if (!date) {
    showToast('يرجى اختيار التاريخ', 'error');
    return;
}
if (amount <= 0) {
    showToast('يرجى إدخال مبلغ صحيح', 'error');
    return;
}

// ============================================================
// التحقق من رصيد الصندوق (المصروف دائماً نقدي)
// ============================================================
if (typeof checkSufficientBalance === 'function') {
    if (id) {
        // عند التعديل: نتحقق من الرصيد + المبلغ القديم (لأن القديم سيُلغى)
        var oldExp = expenses.find(function(e) { return e.id === id; });
        var oldAmount = oldExp ? (parseFloat(oldExp.amount) || 0) : 0;
        var oldCur = oldExp ? (oldExp.currency || 'YER') : 'YER';
        var sameCurrency = (oldCur === currency);
        var netNeeded = sameCurrency ? (amount - oldAmount) : amount;
        if (netNeeded > 0) {
            var balanceCheck = checkSufficientBalance('cashbox', currency, netNeeded);
            if (!balanceCheck.ok) {
                showToast('رصيد الصندوق غير كافٍ', 'error');
                return;
            }
        }
    } else {
        // عند الإضافة: نتحقق من الرصيد مباشرة
        var balanceCheck = checkSufficientBalance('cashbox', currency, amount);
        if (!balanceCheck.ok) {
            showToast('رصيد الصندوق غير كافٍ', 'error');
            return;
        }
    }
}

if (id) {
        // تعديل
        var index = expenses.findIndex(function(e) { return e.id === id; });
        if (index !== -1) {
      
            var oldPaymentId = expenses[index].paymentId;
            var oldCurrency = expenses[index].currency || 'YER';
            var oldExchangeRate = parseFloat(expenses[index].exchangeRate) || 0;
            
            expenses[index].date = date;
            expenses[index].type = type;
            expenses[index].amount = amount;
            expenses[index].currency = currency;
            expenses[index].exchangeRate = (oldCurrency === currency && oldExchangeRate > 0) ? oldExchangeRate : ((typeof getCurrentExchangeRateSnapshot === 'function') ? getCurrentExchangeRateSnapshot(currency) : 1);
            expenses[index].recipient = recipient;
            expenses[index].note = note;
            
            // تحديث سند الصرف المرتبط
            if (oldPaymentId && typeof payments !== 'undefined') {
                var pIndex = payments.findIndex(function(p) { return p.id === oldPaymentId; });
                if (pIndex !== -1) {
                    payments[pIndex].amount = amount;
                    payments[pIndex].currency = currency;
                    payments[pIndex].exchangeRate = (typeof getCurrentExchangeRateSnapshot === 'function') ? getCurrentExchangeRateSnapshot(currency) : 1;
                    payments[pIndex].date = date;
                    payments[pIndex].supplierName = type;
                    payments[pIndex].note = 'مصروف: ' + (note || type);
                    payments[pIndex].invoiceTotal = amount;
                }
                if (typeof savePayments === 'function') savePayments();
            }
        }
        showToast('تم تعديل المصروف', 'success');
    } else {
        // إضافة
        var expenseId = generateId();
        var paymentId = generateId();
        
        expenses.push({
            id: expenseId,
            date: date,
            type: type,
            amount: amount,
            currency: currency,
            exchangeRate: (typeof getCurrentExchangeRateSnapshot === 'function') ? getCurrentExchangeRateSnapshot(currency) : 1,
            recipient: recipient,
            note: note,
            paymentId: paymentId
        });
        
        // إنشاء سند صرف تلقائي
        if (typeof payments !== 'undefined' && Array.isArray(payments)) {
            payments.push({
                id: paymentId,
                invoiceId: '-',
                supplierId: 'expense_' + expenseId,
                supplierName: type,
                amount: amount,
                currency: currency,
                exchangeRate: (typeof getCurrentExchangeRateSnapshot === 'function') ? getCurrentExchangeRateSnapshot(currency) : 1,
                date: date,
                method: 'نقدي',
                note: 'مصروف: ' + (note || type) + (recipient ? ' | المستلم: ' + recipient : ''),
                invoiceTotal: amount,
                paidBefore: 0,
                remainingAfter: 0,
                status: 'مدفوع بالكامل',
                isExpense: true,
                expenseId: expenseId,
                expenseType: type,
                recipient: recipient
            });
            
            if (typeof savePayments === 'function') savePayments();
        }
        
        showToast('تم إضافة المصروف وإنشاء سند الصرف', 'success');
    }
    
        saveExpenses();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
    closeModal('expModal');

    // ✅ مزامنة مركزية
  // ✅ استدعاء مباشر دائماً — لضمان تحديث الجدول
renderExpenses();
if (typeof renderPayments === 'function') renderPayments();
if (typeof updateDashboard === 'function') updateDashboard();

// ✅ مزامنة إضافية (إن كانت متاحة)
if (typeof oaRefreshRelated === 'function') {
    oaRefreshRelated('expense');
}
}


// ================================================================
// ===== 8. حذف مصروف (نافذة اختيار) =====
// ================================================================

function deleteExpense(id) {
    var exp = expenses.find(function(e) { return e.id === id; });
    if (!exp) return;
    
    _currentExpenseToDelete = id;
    
    var bodyHTML = 
        '<div class="info-boxes">' +
            '<div class="info-box"><span>النوع:</span><span>' + esc(exp.type) + '</span></div>' +
            '<div class="info-box"><span>المبلغ:</span><span>' + formatCurrency(exp.amount, exp.currency) + '</span></div>' +
            '<div class="info-box"><span>التاريخ:</span><span>' + formatDate(exp.date) + '</span></div>' +
            (exp.recipient ? '<div class="info-box"><span>المستلم:</span><span>' + esc(exp.recipient) + '</span></div>' : '') +
        '</div>' +
        
        '<div class="section-label" style="margin-top:14px;">' +
            '<span>اختر الإجراء</span>' +
        '</div>' +
        
        '<button class="delete-choice-btn delete" onclick="confirmDeleteExpense(\'delete\')">' +
            'حذف نهائي (لا يمكن الاسترجاع)' +
        '</button>' +
        
        '<button class="delete-choice-btn archive" onclick="confirmDeleteExpense(\'archive\')">' +
            'أرشفة (يمكن استرجاع لاحقاً)' +
        '</button>';
    
    var footerHTML = '<button class="btn btn-cancel" onclick="closeModal(\'deleteExpenseModal\')">إلغاء</button>';
    
    Modal.open({
        id: 'deleteExpenseModal',
        title: 'ماذا تريد أن تفعل؟',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML
    });
}
// ================================================================
// ===== 8-b. إلغاء مصروف (بدل الحذف) =====
// ================================================================

function cancelExpense(id, reason) {
    var exp = expenses.find(function(e) {
        return e.id === id;
    });

    if (!exp) return false;

    if (exp.cancelled === true) {
        showToast('المصروف ملغى مسبقاً', 'info');
        return false;
    }
  
    var now = new Date().toISOString();
    var cancelReason = reason || 'إلغاء المصروف';

    exp.cancelled = true;
    exp.documentStatus = 'cancelled';
    exp.cancelledAt = now;
    exp.cancelReason = cancelReason;

    if (exp.paymentId && typeof payments !== 'undefined') {
        var payment = payments.find(function(p) {
            return p.id === exp.paymentId;
        });

        if (payment) {
            payment.cancelled = true;
            payment.documentStatus = 'cancelled';
            payment.sourceStatus = 'cancelled';
            payment.cancelledAt = now;
            payment.cancelReason = cancelReason + ' — المصروف ' + exp.id;
            if (typeof savePayments === 'function') {
                savePayments();
            }
        }
    }

    saveExpenses();

    if (typeof syncJournalAfterMutation === 'function') {
        syncJournalAfterMutation();
    }

    if (typeof oaRefreshRelated === 'function') {
        oaRefreshRelated('expense');
    } else {
        renderExpenses();
        if (typeof renderPayments === 'function') {
            renderPayments();
        }
        if (typeof updateDashboard === 'function') {
            updateDashboard();
        }
    }

    return true;
}



// ================================================================
// ===== 9. تأكيد الحذف/الأرشفة =====
// ================================================================

function confirmDeleteExpense(action) {
    if (!_currentExpenseToDelete) return;
    
    var exp = expenses.find(function(e) { return e.id === _currentExpenseToDelete; });
    if (!exp) return;
    
    if (action === 'delete') {
    var cancelled = cancelExpense(
        _currentExpenseToDelete,
        'إلغاء المصروف من شاشة المصاريف'
    );

    if (cancelled) {
        showToast('تم إلغاء المصروف وإنشاء الأثر العكسي', 'success');
    }

    _currentExpenseToDelete = null;
    closeModal('deleteExpenseModal');
    return;

    } else if (action === 'archive') {
        // أرشفة
        var index = expenses.findIndex(function(e) { return e.id === _currentExpenseToDelete; });
        if (index !== -1) {
            expenses[index].archived = true;
            expenses[index].archivedAt = new Date().toISOString();
        }
        
        // أرشفة سند الصرف المرتبط
        if (exp.paymentId && typeof payments !== 'undefined') {
            var p = payments.find(function(pp) { return pp.id === exp.paymentId; });
            if (p) {
                p.archived = true;
                p.archivedAt = new Date().toISOString();
            }
            if (typeof savePayments === 'function') savePayments();
        }
        
        showToast('تم الأرشفة (المصروف + سند الصرف)', 'success');
    }
    
    _currentExpenseToDelete = null;
    closeModal('deleteExpenseModal');
    saveExpenses();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

    // ✅ مزامنة مركزية
   // ✅ استدعاء مباشر دائماً — لضمان تحديث الجدول
renderExpenses();
if (typeof renderPayments === 'function') renderPayments();
if (typeof updateDashboard === 'function') updateDashboard();

// ✅ مزامنة إضافية (إن كانت متاحة)
if (typeof oaRefreshRelated === 'function') {
    oaRefreshRelated('expense');
}
}


// ================================================================
// ===== 10. استرجاع مصروف مؤرشف =====
// ================================================================

function restoreExpense(id) {
    var exp = expenses.find(function(e) { return e.id === id; });
    if (!exp) return;
    
    exp.archived = false;
    delete exp.archivedAt;
    
    // استرجاع سند الصرف المرتبط
    if (exp.paymentId && typeof payments !== 'undefined') {
        var p = payments.find(function(pp) { return pp.id === exp.paymentId; });
        if (p) {
            p.archived = false;
            delete p.archivedAt;
        }
        if (typeof savePayments === 'function') savePayments();
    }
    
    saveExpenses();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

    // ✅ مزامنة مركزية
  // ✅ استدعاء مباشر دائماً — لضمان تحديث الجدول
renderExpenses();
if (typeof renderPayments === 'function') renderPayments();
if (typeof updateDashboard === 'function') updateDashboard();

// ✅ مزامنة إضافية (إن كانت متاحة)
if (typeof oaRefreshRelated === 'function') {
    oaRefreshRelated('expense');
}

    showToast('تم استرجاع المصروف', 'success');
}


// ================================================================
// ===== 11. حذف نهائي من المؤرشفة =====
// ================================================================

function permanentDeleteExpense(id) {
    var exp = expenses.find(function(e) {
        return e.id === id;
    });

    if (!exp) return;

    Modal.confirm({
        title: 'إلغاء المصروف',
        message: 'سيتم إلغاء المصروف وإنشاء أثر عكسي، دون حذف السجل. هل تريد المتابعة؟',
        confirmText: 'إلغاء المصروف',
        cancelText: 'رجوع',
        confirmColor: 'danger',
        onConfirm: function() {
            var cancelled = cancelExpense(
                id,
                'إلغاء مصروف مؤرشف'
            );

            if (cancelled) {
                showToast('تم إلغاء المصروف مع الحفاظ على السجل', 'success');
            }
        }
    });
}

// ================================================================
// ===== 12. تبديل عرض المؤرشفة =====
// ================================================================

function toggleArchivedExpenses() {
    showArchivedExpenses = !showArchivedExpenses;
    _archiveExpensesMode = false;
    _selectedExpensesForArchive = {};
    _updateArchivedBtnLabel();
    renderExpenses();
    showToast(showArchivedExpenses ? 'عرض المؤرشفة' : 'عرض النشطة', 'info');
}
    



// ================================================================
// ===== 13. تهيئة المصاريف =====
// ================================================================

function initExpenses() {
    loadExpenses();
    renderExpenses();
    
    var searchEl = document.getElementById('expSearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderExpenses, 300));
    }
    
    console.log('Expenses: ' + expenses.length + ' مصروف');
}

// ================================================================
// ===== 12-b. معاينة مصروف (تفتح القالب الجديد) =====
// ================================================================

function viewExpense(id) {
    var exp = expenses.find(function(e) { return e.id === id; });
    if (!exp) {
        showToast('المصروف غير موجود', 'error');
        return;
    }

    if (typeof printIndividualDocument !== 'function') {
        showToast('دالة الطباعة غير متاحة', 'error');
        return;
    }

    // استخدم نفس المسار الموحّد
    printIndividualDocument('expenses', id);
}

// ================================================================
// ===== 14. طباعة تقرير المصاريف (القالب الجديد) =====
// ================================================================

function printExpensesReport() {
    // 1. فلترة المصاريف — كل النشطة
    var list = expenses.filter(function(e) {
        return !e.cancelled && !e.archived;
    });

    // 2. ترتيب — الأحدث أولاً
    list = list.slice().sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });

    // 3. بناء الصفوف
    var rows = list.map(function(e) {
        return {
            date: e.date || '—',
            type: e.type || '—',
            recipient: e.recipient || '—',
            note: e.note || '—',
            amount: e.amount || 0,
            currency: e.currency || 'SAR'
        };
    });

    // 4. الإعدادات
    var settings = (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined')
        ? (Storage.get(STORAGE_KEYS.SETTINGS, {}) || {})
        : {};

    // 5. العملة الموحدة
    var currency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

    // 6. حفظ الحمولة
    var payload = {
        type: 'expenses_report',
        rows: rows,
        settings: settings,
        meta: {
            from: '—',
            to: '—',
            currency: currency
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 7. فتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/expenses-report.html';
    window.location.href = url;
}
// ================================================================
// ===== END OF EXPENSES.JS =====
// ================================================================
