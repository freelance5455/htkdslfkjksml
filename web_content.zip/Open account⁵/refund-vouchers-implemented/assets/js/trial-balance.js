// ================================================================
// Open Account — ميزان المراجعة
// الملف: trial-balance.js
// النسخة: v3 — نظيفة كاملة
// ================================================================

var ACCOUNTS_TB = {
    '1000': { name: 'الصندوق', type: 'أصول' },
    '1010': { name: 'البنك', type: 'أصول' },
    '1100': { name: 'العملاء', type: 'أصول' },
    '1200': { name: 'المخزون', type: 'أصول' },
    '2000': { name: 'الموردين', type: 'خصوم' },
    '3000': { name: 'رأس المال', type: 'حقوق' },
    '4000': { name: 'إيرادات المبيعات', type: 'إيرادات' },
    '4100': { name: 'إيرادات أخرى', type: 'إيرادات' },
    '5000': { name: 'تكلفة المبيعات', type: 'مصاريف' },
    '6000': { name: 'المصاريف', type: 'مصاريف' }
};


// ================================================================
// ===== 1. بناء بيانات الميزان =====
// ================================================================

function _tbBuildData(from, to, currencyFilter) {
    // تحميل القيود مباشرة من Storage
    var entries = Storage.get('oa_journal_entries', []);
    if (!Array.isArray(entries)) entries = [];

    var balances = {};
    Object.keys(ACCOUNTS_TB).forEach(function(code) {
        balances[code] = { debit: 0, credit: 0 };
    });

    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';

    entries.forEach(function(e) {
        if (from && e.date < from) return;
        if (to && e.date > to) return;
        if (currencyFilter && e.currency !== currencyFilter) return;

        var needsConversion = !currencyFilter && e.currency && e.currency !== baseCurrency;

        (e.lines || []).forEach(function(l) {
            var code = l.accountCode;
            if (!code) return;

            if (!balances[code]) {
                balances[code] = { debit: 0, credit: 0 };
                if (!ACCOUNTS_TB[code]) {
                    ACCOUNTS_TB[code] = { name: l.accountName || '-', type: 'أخرى' };
                }
            }

            var d = (l.debitBase !== undefined && !currencyFilter) ? (parseFloat(l.debitBase) || 0) : (parseFloat(l.debit) || 0);
            var c = (l.creditBase !== undefined && !currencyFilter) ? (parseFloat(l.creditBase) || 0) : (parseFloat(l.credit) || 0);

            if (needsConversion && l.debitBase === undefined && typeof getEquivalent === 'function') {
                d = (typeof getEquivalentAtRate === 'function') ? getEquivalentAtRate(d, e.currency, e.exchangeRate) : getEquivalent(d, e.currency);
                c = (typeof getEquivalentAtRate === 'function') ? getEquivalentAtRate(c, e.currency, e.exchangeRate) : getEquivalent(c, e.currency);
            }

            balances[code].debit += d;
            balances[code].credit += c;
        });
    });

    var rows = [];
    var totalDebit = 0;
    var totalCredit = 0;

    Object.keys(ACCOUNTS_TB).sort().forEach(function(code) {
        var b = balances[code];
        if (!b) return;
        if (b.debit === 0 && b.credit === 0) return;

        totalDebit += b.debit;
        totalCredit += b.credit;

        rows.push({
            code: code,
            name: ACCOUNTS_TB[code].name,
            type: ACCOUNTS_TB[code].type,
            debit: b.debit,
            credit: b.credit
        });
    });

    return {
        rows: rows,
        totalDebit: totalDebit,
        totalCredit: totalCredit,
        diff: Math.abs(totalDebit - totalCredit),
        currency: currencyFilter || baseCurrency
    };
}


// ================================================================
// ===== 2. عرض الملخص (تنبيه العملة الموحّدة) =====
// ================================================================

function _updateTBSummary(data, currencyFilter, baseCurrency) {
    var summaryEl = document.getElementById('tbSummary');
    if (!summaryEl) return;

    // عملة محددة → لا تنبيه
    if (currencyFilter) {
        summaryEl.innerHTML = '';
        return;
    }

    // كل العملات → تنبيه بصيغة موحّدة
    var baseName = (typeof getCurrencyName === 'function')
        ? getCurrencyName(baseCurrency)
        : baseCurrency;

    var ratesText = (typeof formatExchangeRates === 'function')
        ? formatExchangeRates(baseCurrency)
        : '—';

    summaryEl.innerHTML =
        '<div class="info-message" style="text-align:right;line-height:1.8;margin-bottom:12px;background:rgba(31,111,235,0.08);border-color:rgba(31,111,235,0.3);">' +
            '<strong style="color:var(--color-blue);">ℹ️ ميزان موحّد</strong><br>' +
            'الأرقام المعروضة هي <strong>مجموع جميع العملات</strong> محوّلة إلى العملة المرجعية (' + esc(baseName) + ').<br>' +
            'سعر الصرف المستخدم: <strong>' + esc(ratesText) + '</strong><br>' +
            '<small style="color:var(--color-text-3);">للمراجعة الدقيقة، اختر عملة محددة من القائمة.</small>' +
        '</div>';
}

// ================================================================
// ===== 3. عرض الميزان =====
// ================================================================

function renderTrialBalance() {
    var tbody = document.getElementById('tbTableBody');
    if (!tbody) return;

    var fromEl = document.getElementById('tbFrom');
    var toEl = document.getElementById('tbTo');
    var currencyEl = document.getElementById('tbCurrency');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';
    var currency = currencyEl ? currencyEl.value : '';

    var data = _tbBuildData(from, to, currency);
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';

    // عرض الملخص (تنبيه "كل العملات")
    _updateTBSummary(data, currency, baseCurrency);

    // حالة فارغة
    if (!data.rows.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty-cell">لا توجد قيود في الفترة المحددة</td></tr>';
        setText('tbTotalDebit', '0');
        setText('tbTotalCredit', '0');
        setText('tbStatus', '—');
        setText('tbCount', '0');
        return;
    }

    // بناء الجدول
    var html = '';
    data.rows.forEach(function(r, i) {
        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td style="font-family:monospace;">' + esc(r.code) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(r.name) + '</td>' +
            '<td style="color:var(--color-red);">' + (r.debit > 0 ? formatAmountWithCommas(r.debit) : '—') + '</td>' +
            '<td style="color:var(--color-green);">' + (r.credit > 0 ? formatAmountWithCommas(r.credit) : '—') + '</td>' +
        '</tr>';
    });

    // صف الإجماليات
    html += '<tr class="total-row">' +
        '<td colspan="3" style="text-align:right;padding-right:12px;font-weight:800;">الإجماليات</td>' +
        '<td style="color:var(--color-red);font-weight:800;">' + formatAmountWithCommas(data.totalDebit) + '</td>' +
        '<td style="color:var(--color-green);font-weight:800;">' + formatAmountWithCommas(data.totalCredit) + '</td>' +
    '</tr>';

    tbody.innerHTML = html;

    // الإحصائيات
    setText('tbTotalDebit', formatAmountWithCommas(data.totalDebit));
    setText('tbTotalCredit', formatAmountWithCommas(data.totalCredit));
    setText('tbCount', data.rows.length);

    // الحالة (متوازن / غير متوازن)
    var statusEl = document.getElementById('tbStatus');
    if (statusEl) {
        if (data.diff < 0.01) {
            statusEl.textContent = '✅ متوازن';
            statusEl.style.color = 'var(--color-green)';
        } else {
            statusEl.textContent = '⚠ فرق ' + formatAmountWithCommas(data.diff);
            statusEl.style.color = 'var(--color-red)';
        }
    }
}


// ================================================================
// ===== 4. تصدير PDF =====
// ================================================================

function exportTrialBalancePDF() {
    var table = document.querySelector('#section-trial-balance .data-table');
    if (!table) return showToast('لا يوجد جدول لعرضه', 'error');

    var from = (document.getElementById('tbFrom') || {}).value || '';
    var to = (document.getElementById('tbTo') || {}).value || '';

    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';

    var html = '<div class="doc-wrapper">' +
        '<div class="doc-header"><div class="company-name">' + esc(companyName) + '</div></div>' +
        '<div class="doc-title">ميزان المراجعة</div>' +
        '<div class="doc-meta-grid">' +
            '<div><strong>من:</strong> ' + (from || 'البداية') + '</div>' +
            '<div><strong>إلى:</strong> ' + (to || 'اليوم') + '</div>' +
            '<div><strong>تاريخ الإصدار:</strong> ' + todayISO() + '</div>' +
        '</div>' +
        table.outerHTML +
        '<div class="doc-footer">ميزان المراجعة<small>هذا المستند معتمد رقمياً</small></div>' +
    '</div>';

    Modal.open({
        id: 'tbPrintModal',
        title: 'معاينة ميزان المراجعة',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'tbPrintModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
    });
}


// ================================================================
// ===== 5. التهيئة =====
// ================================================================

function initTrialBalance() {
    var fromEl = document.getElementById('tbFrom');
    var toEl = document.getElementById('tbTo');

    // افتراضي: بداية الشهر الحالي
    if (fromEl && !fromEl.value) {
        var d = new Date();
        d.setDate(1);
        fromEl.value = d.toISOString().split('T')[0];
    }

    // افتراضي: اليوم
    if (toEl && !toEl.value) {
        toEl.value = new Date().toISOString().split('T')[0];
    }

    // الربط
    if (fromEl) fromEl.addEventListener('change', renderTrialBalance);
    if (toEl) toEl.addEventListener('change', renderTrialBalance);

    var currencyEl = document.getElementById('tbCurrency');
    if (currencyEl) currencyEl.addEventListener('change', renderTrialBalance);

    renderTrialBalance();
    console.log('Trial Balance: initialized');
}

// ================================================================
// ===== 6. طباعة ميزان المراجعة (القالب الجديد) =====
// ================================================================

function printTrialBalance() {
    // 1. اقرأ الفلاتر
    var fromEl = document.getElementById('tbFrom');
    var toEl = document.getElementById('tbTo');
    var currencyEl = document.getElementById('tbCurrency');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';
    var currency = currencyEl ? currencyEl.value : '';

    // 2. اقرأ بيانات الميزان
    var data = _tbBuildData(from, to, currency);

    if (!data.rows.length) {
        if (typeof showToast === 'function') showToast('لا توجد بيانات في الفترة المحددة', 'error');
        return;
    }

    // 3. اقرأ الجدول من الصفحة
    var tbody = document.getElementById('tbTableBody');
    if (!tbody) {
        if (typeof showToast === 'function') showToast('الجدول غير موجود', 'error');
        return;
    }
    var table = tbody.closest('table');
    if (!table) {
        if (typeof showToast === 'function') showToast('الجدول غير موجود', 'error');
        return;
    }

    // 4. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 5. اسم العملة
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var currencyLabel = currency || (baseCurrency + ' (موحّد)');

    // 6. حفظ الحمولة
    var payload = {
        type: 'trial_balance',
        tableHtml: table.outerHTML,
        settings: settings,
        meta: {
            from: from || '—',
            to: to || '—',
            currency: currencyLabel,
            totalDebit: (typeof formatAmountWithCommas === 'function') ? formatAmountWithCommas(data.totalDebit) : data.totalDebit,
            totalCredit: (typeof formatAmountWithCommas === 'function') ? formatAmountWithCommas(data.totalCredit) : data.totalCredit,
            isBalanced: data.diff < 0.01,
            diff: (typeof formatAmountWithCommas === 'function') ? formatAmountWithCommas(data.diff) : data.diff,
            count: data.rows.length
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 7. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/trial-balance-report.html';
    window.location.href = url;
}
// ================================================================
// ===== END OF TRIAL-BALANCE.JS =====
// ================================================================