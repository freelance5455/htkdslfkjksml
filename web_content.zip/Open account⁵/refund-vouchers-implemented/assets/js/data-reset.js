// ================================================================
// Open Account — تصفير البيانات المالية + الحماية
// الملف: data-reset.js
// الإصدار: 3.0 — احترافي
// ================================================================


// ================================================================
// ===== 1. الثوابت والإعدادات =====
// ================================================================

// مفاتيح البيانات المالية (قابلة للحذف)
var _RESET_GROUPS = [
    {
        id: 'sales_invoices',
        label: 'فواتير البيع',
        keys: ['oa_sales_invoices'],
        related: ['journal_entries', 'stock_movements'],
        defaultChecked: true
    },
    {
        id: 'purchase_invoices',
        label: 'فواتير الشراء',
        keys: ['oa_purchase_invoices'],
        related: ['journal_entries', 'stock_movements'],
        defaultChecked: true
    },
    {
        id: 'receipts',
        label: 'سندات القبض',
        keys: ['oa_receipts'],
        related: ['journal_entries'],
        defaultChecked: true
    },
    {
        id: 'payments',
        label: 'سندات الصرف',
        keys: ['oa_payments'],
        related: ['journal_entries'],
        defaultChecked: true
    },
    {
        id: 'expenses',
        label: 'المصاريف',
        keys: ['oa_expenses'],
        related: ['journal_entries'],
        defaultChecked: true
    },
    {
        id: 'returns',
        label: 'المرتجعات',
        keys: ['oa_returns'],
        related: ['journal_entries', 'stock_movements'],
        defaultChecked: true
    },
    {
        id: 'transfers',
        label: 'التحويلات',
        keys: ['oa_transfers'],
        related: ['journal_entries'],
        defaultChecked: true
    },
    {
        id: 'direct_transactions',
        label: 'الحركات المباشرة',
        keys: ['oa_direct_transactions'],
        related: ['journal_entries'],
        defaultChecked: true
    },
    {
        id: 'stock_movements',
        label: 'حركات المخزون',
        keys: ['oa_stock_movements'],
        related: [],
        affectsStock: true,
        defaultChecked: true
    },
        {
        id: 'journal_entries',
        label: 'قيود اليومية',
        keys: ['oa_journal_entries'],
        related: [],
        protectedKey: true,
        defaultChecked: true
    },
    {
        id: 'cycle_opening',
        label: 'الرصيد الافتتاحي (دورة محاسبية)',
        keys: ['oa_cycle_opening_balances', 'oa_cycle_state', 'oa_cycle_archive_log'],
        related: [],
        defaultChecked: true
    },
    {
    id: 'production_docs',
    label: 'سندات الإنتاج',
    keys: ['oa_production_docs'],
    related: ['journal_entries', 'stock_movements'],
    defaultChecked: false,
    affectsStock: true
}
];

// مفاتيح لا تُمسح أبداً
var _PRESERVED_KEYS = [
    'oa_settings',
    'oa_ai_settings',
    'oa_exchange_rates',
    'oa_theme',
    'oa_active_tab',
    'oa_journal_counter',  // ← مهم: العدّاد لا يُمسح
    'oa_products',
    'oa_customers',
    'oa_suppliers'
];

// مفاتيح الأمان
var _PIN_KEY = 'oa_security_pin';
var _PIN_SALT = 'oa_2026_reset_v3';
var _PIN_MAX_ATTEMPTS = 3;
var _PIN_LOCK_MS = 30000;
var _pinState = { attempts: 0, lockedUntil: 0 };


// ================================================================
// ===== 2. PIN — إدارة الرقم السري =====
// ================================================================

function _pinHash(pin) {
    var s = _PIN_SALT + '::' + pin + '::' + _PIN_SALT;
    try { return btoa(s); } catch (e) { return s; }
}

function _pinExists() {
    return localStorage.getItem(_PIN_KEY) !== null;
}

function _pinSet(pin) {
    if (!/^\d{4}$/.test(pin)) return false;
    localStorage.setItem(_PIN_KEY, _pinHash(pin));
    return true;
}

function _pinVerify(pin) {
    if (!_pinExists()) return false;
    return localStorage.getItem(_PIN_KEY) === _pinHash(pin);
}

function _pinRemove() {
    localStorage.removeItem(_PIN_KEY);
    _pinState.attempts = 0;
    _pinState.lockedUntil = 0;
}

function _pinIsLocked() {
    return Date.now() < _pinState.lockedUntil;
}

function _pinRemainingLock() {
    return Math.max(0, Math.ceil((_pinState.lockedUntil - Date.now()) / 1000));
}


// ================================================================
// ===== 3. SVG ICONS — أيقونات احترافية =====
// ================================================================

function _svg(name, size) {
    var s = size || 16;
    var icons = {
        'lock': '<path d="M19 11H5a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7a2 2 0 0 0-2-2z"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
        'unlock': '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
        'shield': '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'warning': '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
        'trash': '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
        'check': '<polyline points="20 6 9 17 4 12"/>',
        'x': '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
        'refresh': '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
        'clock': '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>'
    };
    return '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;flex-shrink:0;">' + (icons[name] || '') + '</svg>';
}


// ================================================================
// ===== 4. قسم الأمان في الإعدادات =====
// ================================================================

function renderSecuritySection() {
    var el = document.getElementById('securitySectionBody');
    if (!el) return;
    
    var html = '';
    
    if (_pinExists()) {
        html += 
            '<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:rgba(0,214,143,0.08);border:1px solid rgba(0,214,143,0.3);border-radius:10px;margin-bottom:12px;text-align:right;">' +
                '<span style="color:var(--color-green);font-weight:700;flex:1;">الرقم السري مُعيَّن</span>' +
                '<span style="color:var(--color-green);">' + _svg('check', 20) + '</span>' +
            '</div>' +
            '<div style="display:flex;gap:8px;">' +
                '<button class="btn btn-secondary" onclick="openChangePinModal()" style="flex:1;min-height:42px;">' +
                    _svg('refresh', 16) + ' <span>تغيير الرقم</span>' +
                '</button>' +
                '<button class="btn btn-danger" onclick="confirmRemovePin()" style="flex:1;min-height:42px;">' +
                    _svg('trash', 16) + ' <span>حذف الرقم</span>' +
                '</button>' +
            '</div>';
    } else {
        html += 
            '<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;background:rgba(247,147,30,0.08);border:1px solid rgba(247,147,30,0.3);border-radius:10px;margin-bottom:12px;text-align:right;">' +
                '<span style="color:var(--color-gold);font-weight:700;flex:1;">لا يوجد رقم سري</span>' +
                '<span style="color:var(--color-gold);">' + _svg('warning', 20) + '</span>' +
            '</div>' +
            '<div style="font-size:12px;color:var(--color-text-2);text-align:right;line-height:1.7;margin-bottom:12px;">' +
                'بعد تعيين الرقم، سيُطلب منك عند كل تصفير للبيانات المالية. هذا يحمي من الحذف الخاطئ.' +
            '</div>' +
            '<button class="btn btn-primary" onclick="openSetPinModal()" style="width:100%;min-height:44px;">' +
                _svg('lock', 16) + ' <span>تعيين رقم سري</span>' +
            '</button>';
    }
    
    el.innerHTML = html;
}


// ================================================================
// ===== 5. نافذة تعيين PIN =====
// ================================================================

function openSetPinModal() {
    var body = 
        '<div style="text-align:right;">' +
            '<div class="form-field">' +
                '<label>أدخل رقماً من 4 أرقام</label>' +
                '<input type="password" id="pinInput1" maxlength="4" inputmode="numeric" pattern="[0-9]*" placeholder="••••" style="text-align:center;font-size:22px;letter-spacing:12px;font-weight:700;padding:14px;">' +
            '</div>' +
            '<div class="form-field">' +
                '<label>أعد إدخال الرقم</label>' +
                '<input type="password" id="pinInput2" maxlength="4" inputmode="numeric" pattern="[0-9]*" placeholder="••••" style="text-align:center;font-size:22px;letter-spacing:12px;font-weight:700;padding:14px;">' +
            '</div>' +
            '<div id="pinErrorMsg" style="color:var(--color-red);font-size:12px;text-align:center;margin-top:8px;min-height:18px;"></div>' +
        '</div>';
    
    var footer = 
        '<button class="btn btn-cancel" onclick="closeModal(\'pinSetModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="savePinFromModal()">حفظ</button>';
    
    Modal.open({
        id: 'pinSetModal',
        title: 'تعيين رقم سري',
        size: 'normal',
        body: body,
        footer: footer,
        onOpen: function(m) {
            setTimeout(function() {
                var i = m.querySelector('#pinInput1');
                if (i) i.focus();
            }, 200);
        }
    });
}

function savePinFromModal() {
    var i1 = document.getElementById('pinInput1');
    var i2 = document.getElementById('pinInput2');
    var err = document.getElementById('pinErrorMsg');
    var p1 = i1 ? i1.value.trim() : '';
    var p2 = i2 ? i2.value.trim() : '';
    
    if (!/^\d{4}$/.test(p1)) {
        if (err) err.textContent = 'الرقم يجب أن يكون 4 أرقام';
        return;
    }
    if (p1 !== p2) {
        if (err) err.textContent = 'الرقمان غير متطابقين';
        return;
    }
    
    _pinSet(p1);
    closeModal('pinSetModal');
    renderSecuritySection();
    showToast('تم تعيين الرقم السري', 'success');
}

function openChangePinModal() {
    _openPinPrompt({
        title: 'الرقم الحالي',
        message: 'أدخل الرقم السري الحالي',
        onSuccess: function() { setTimeout(openSetPinModal, 300); }
    });
}

function confirmRemovePin() {
    _openPinPrompt({
        title: 'تأكيد الحذف',
        message: 'أدخل الرقم السري لحذفه',
        onSuccess: function() {
            _pinRemove();
            renderSecuritySection();
            showToast('تم حذف الرقم السري', 'success');
        }
    });
}


// ================================================================
// ===== 6. نافذة طلب PIN =====
// ================================================================

function _openPinPrompt(opts) {
    opts = opts || {};
    var title = opts.title || 'تأكيد';
    var message = opts.message || 'أدخل الرقم السري';
    var onSuccess = opts.onSuccess || function() {};
    
    if (_pinIsLocked()) {
        var sec = _pinRemainingLock();
        showToast('الرقم مُقفل مؤقتاً — انتظر ' + sec + ' ثانية', 'error');
        return;
    }
    
    if (!_pinExists()) {
        showToast('يجب تعيين رقم سري أولاً', 'warning');
        return;
    }
    
    var body = 
        '<div style="text-align:right;">' +
            '<div style="font-size:13px;color:var(--color-text-2);text-align:center;margin-bottom:14px;">' + message + '</div>' +
            '<div class="form-field">' +
                '<input type="password" id="pinPromptInput" maxlength="4" inputmode="numeric" pattern="[0-9]*" placeholder="••••" style="text-align:center;font-size:24px;letter-spacing:14px;font-weight:700;padding:16px;">' +
            '</div>' +
            '<div id="pinPromptError" style="color:var(--color-red);font-size:12px;text-align:center;margin-top:8px;min-height:18px;"></div>' +
        '</div>';
    
    var footer = 
        '<button class="btn btn-cancel" onclick="closeModal(\'pinPromptModal\')">إلغاء</button>' +
        '<button class="btn btn-primary" onclick="submitPinPrompt()">تأكيد</button>';
    
    Modal.open({
        id: 'pinPromptModal',
        title: title,
        size: 'normal',
        body: body,
        footer: footer,
        onOpen: function(m) {
            setTimeout(function() {
                var i = m.querySelector('#pinPromptInput');
                if (i) {
                    i.focus();
                    i.addEventListener('keypress', function(e) {
                        if (e.key === 'Enter') submitPinPrompt();
                    });
                }
            }, 200);
        }
    });
    
    window._pinPromptCallback = onSuccess;
}

function submitPinPrompt() {
    var input = document.getElementById('pinPromptInput');
    var err = document.getElementById('pinPromptError');
    var pin = input ? input.value.trim() : '';
    
    if (!/^\d{4}$/.test(pin)) {
        if (err) err.textContent = 'الرقم يجب أن يكون 4 أرقام';
        return;
    }
    
    if (_pinVerify(pin)) {
        _pinState.attempts = 0;
        closeModal('pinPromptModal');
        var cb = window._pinPromptCallback;
        window._pinPromptCallback = null;
        if (typeof cb === 'function') cb();
    } else {
        _pinState.attempts++;
        if (_pinState.attempts >= _PIN_MAX_ATTEMPTS) {
            _pinState.lockedUntil = Date.now() + _PIN_LOCK_MS;
            _pinState.attempts = 0;
            if (err) err.textContent = '3 محاولات خاطئة — مُقفل 30 ثانية';
            if (input) input.value = '';
            setTimeout(function() { closeModal('pinPromptModal'); }, 2000);
        } else {
            var left = _PIN_MAX_ATTEMPTS - _pinState.attempts;
            if (err) err.textContent = 'رقم خاطئ — متبقي ' + left + ' محاولة';
            if (input) input.value = '';
        }
    }
}


// ================================================================
// ===== 7. نافذة اختيار البيانات =====
// ================================================================

function openDataResetModal() {
    if (!_pinExists()) {
        showToast('عيّن رقم سري أولاً في قسم الأمان', 'warning');
        var sec = document.getElementById('securitySectionBody');
        if (sec) sec.scrollIntoView({ behavior: 'smooth', block: 'center' });
        return;
    }
    
    _openPinPrompt({
        title: 'تأكيد التصفير',
        message: 'لتصفير البيانات، أدخل الرقم السري',
        onSuccess: function() {
            setTimeout(_showDataPickerModal, 300);
        }
    });
}


function _showDataPickerModal() {
    // احسب السجلات
    var counts = {};
    var totalRecords = 0;
    var hasAnyData = false;
    
    _RESET_GROUPS.forEach(function(g) {
        var n = 0;
        g.keys.forEach(function(k) {
            try {
                var arr = JSON.parse(localStorage.getItem(k) || '[]');
                if (Array.isArray(arr)) n += arr.length;
            } catch (e) {}
        });
        counts[g.id] = n;
        totalRecords += n;
        if (n > 0) hasAnyData = true;
    });
    
    if (!hasAnyData) {
        showToast('لا توجد بيانات مالية لتصفيرها', 'info');
        return;
    }
    
    // ابنِ الواجهة
    var listHTML = '';
    _RESET_GROUPS.forEach(function(g) {
        var n = counts[g.id];
        var disabled = n === 0;
        var checked = !disabled && g.defaultChecked;
        
        listHTML += 
            '<label class="data-reset-item" style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,0.06);cursor:' + (disabled ? 'not-allowed' : 'pointer') + ';opacity:' + (disabled ? '0.45' : '1') + ';">' +
                '<input type="checkbox" class="data-reset-cb" data-group="' + g.id + '" ' + (checked ? 'checked' : '') + ' ' + (disabled ? 'disabled' : '') + ' style="width:20px;height:20px;cursor:' + (disabled ? 'not-allowed' : 'pointer') + ';flex-shrink:0;">' +
                '<span style="flex:1;text-align:right;font-size:13px;font-weight:600;">' + g.label + '</span>' +
                '<span style="color:' + (n > 0 ? 'var(--color-red)' : 'var(--color-text-3)') + ';font-weight:700;font-size:13px;min-width:40px;text-align:left;">' + n + '</span>' +
            '</label>';
    });
    
    var body = 
        '<div style="text-align:right;">' +
            '<div style="background:rgba(255,71,87,0.08);border:1px solid rgba(255,71,87,0.3);border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:var(--color-text-2);line-height:1.6;">' +
                'اختر البيانات المالية التي تريد تصفيرها. القيود المرتبطة تُحدَّد تلقائياً.' +
            '</div>' +
            
            '<div style="display:flex;gap:6px;margin-bottom:10px;">' +
                '<button class="btn btn-secondary" onclick="_pickAllData(true)" style="flex:1;font-size:11px;padding:8px;">تحديد الكل</button>' +
                '<button class="btn btn-secondary" onclick="_pickAllData(false)" style="flex:1;font-size:11px;padding:8px;">إلغاء الكل</button>' +
            '</div>' +
            
            '<div style="max-height:340px;overflow-y:auto;border:1px solid var(--color-border);border-radius:10px;background:rgba(0,0,0,0.15);">' +
                listHTML +
            '</div>' +
            
            '<div id="dataPickerSummary" style="margin-top:12px;padding:10px 14px;background:rgba(0,212,255,0.06);border:1px solid rgba(0,212,255,0.2);border-radius:8px;font-size:13px;text-align:right;">' +
                '<strong>العدد المحدَّد:</strong> <span id="dataPickerCount">0</span> سجل' +
            '</div>' +
            
            '<label style="display:flex;align-items:center;gap:10px;padding:12px;background:rgba(255,255,255,0.03);border-radius:8px;cursor:pointer;text-align:right;margin-top:12px;">' +
                '<input type="checkbox" id="resetDataBackup" checked style="width:18px;height:18px;cursor:pointer;">' +
                '<span style="font-size:12px;">أخذ نسخة احتياطية قبل التصفير (موصى به)</span>' +
            '</label>' +
        '</div>';
    
    var footer = 
        '<button class="btn btn-cancel" onclick="closeModal(\'dataResetModal\')">إلغاء</button>' +
        '<button class="btn btn-danger" id="dataResetConfirmBtn" onclick="executeDataReset()">' +
            _svg('trash', 14) + ' <span id="dataResetConfirmText">تصفير المحدد</span>' +
        '</button>';
    
    Modal.open({
        id: 'dataResetModal',
        title: 'تصفير البيانات المالية',
        size: 'large',
        body: body,
        footer: footer,
        onOpen: function(m) {
            // اربط الأحداث
            m.querySelectorAll('.data-reset-cb').forEach(function(cb) {
                cb.addEventListener('change', _onDataPickChange);
            });
            // حدّد القيم الأولية
            setTimeout(_recalcDataPicker, 50);
        }
    });
}


function _onDataPickChange(e) {
    var cb = e.target;
    var groupId = cb.getAttribute('data-group');
    var group = _RESET_GROUPS.find(function(g) { return g.id === groupId; });
    if (!group) return;
    
    // لو ألغى "قيود اليومية" وهناك مستند محدد → أعد تحديدها
    if (groupId === 'journal_entries' && !cb.checked) {
        var anyDoc = _RESET_GROUPS.some(function(g) {
            if (g.id === 'journal_entries' || g.id === 'stock_movements') return false;
            var el = document.querySelector('.data-reset-cb[data-group="' + g.id + '"]');
            return el && el.checked;
        });
        if (anyDoc) {
            cb.checked = true;
            showToast('لا يمكن إلغاء القيود مع وجود مستندات محدّدة', 'warning');
            return;
        }
    }
    
    // ربط تلقائي: لو حدّد مستنداً → حدّد قيوده المرتبطة
    if (cb.checked && group.related && group.related.length) {
        group.related.forEach(function(relatedId) {
            var rEl = document.querySelector('.data-reset-cb[data-group="' + relatedId + '"]');
            if (rEl && !rEl.checked && !rEl.disabled) {
                rEl.checked = true;
            }
        });
    }
    
    _recalcDataPicker();
}


function _pickAllData(checked) {
    document.querySelectorAll('.data-reset-cb').forEach(function(cb) {
        if (!cb.disabled) cb.checked = checked;
    });
    _recalcDataPicker();
}

function _recalcDataPicker() {
    setTimeout(function() {
        var selectedCount = 0;
        _RESET_GROUPS.forEach(function(g) {
            var cb = document.querySelector('.data-reset-cb[data-group="' + g.id + '"]');
            if (!cb || !cb.checked) return;
            g.keys.forEach(function(k) {
                try {
                    var arr = JSON.parse(localStorage.getItem(k) || '[]');
                    if (Array.isArray(arr)) selectedCount += arr.length;
                } catch (e) {}
            });
        });
        var cntEl = document.getElementById('dataPickerCount');
        if (cntEl) cntEl.textContent = selectedCount;
        var btnEl = document.getElementById('dataResetConfirmBtn');
        var txtEl = document.getElementById('dataResetConfirmText');
        if (selectedCount === 0) {
            if (btnEl) btnEl.disabled = true;
            if (txtEl) txtEl.textContent = 'لا يوجد محدد';
        } else {
            if (btnEl) btnEl.disabled = false;
            if (txtEl) txtEl.textContent = 'تصفير المحدد (' + selectedCount + ')';
        }
    }, 10);
}


// ================================================================
// ===== 8. تنفيذ التصفير =====
// ================================================================

function executeDataReset() {
    // اجمع المفاتيح المحدّدة
    var keysToClear = [];
    var affectedStock = false;
    
    _RESET_GROUPS.forEach(function(g) {
        var cb = document.querySelector('.data-reset-cb[data-group="' + g.id + '"]');
        if (!cb || !cb.checked) return;
        
        g.keys.forEach(function(k) {
            if (keysToClear.indexOf(k) === -1) keysToClear.push(k);
        });
        
        if (g.affectsStock) affectedStock = true;
    });
    
    if (keysToClear.length === 0) {
        showToast('لم تحدد أي بيانات', 'warning');
        return;
    }
    
    // نسخة احتياطية
    var bkEl = document.getElementById('resetDataBackup');
    if (bkEl && bkEl.checked) {
        try { _createBackup(); }
        catch (e) {
            if (!confirm('فشل النسخة الاحتياطية. المتابعة بدونها؟')) return;
        }
    }
    
    // امسح
    var cleared = 0;
    keysToClear.forEach(function(key) {
        // لا تمسح المفاتيح المحفوظة
        if (_PRESERVED_KEYS.indexOf(key) !== -1) return;
        try {
            if (localStorage.getItem(key) !== null) {
                localStorage.removeItem(key);
                cleared++;
            }
        } catch (e) { console.error('فشل مسح:', key, e); }
    });
    
    // صفّر كميات المنتجات إذا "حركات المخزون" محدّدة
  if (affectedStock) {
    try {
        var products = JSON.parse(localStorage.getItem('oa_products') || '[]');
        var movements = JSON.parse(localStorage.getItem('oa_stock_movements') || '[]');
        
        if (Array.isArray(products) && products.length > 0) {
            // ✅ إعادة حساب quantity من الحركات المتبقية
            products.forEach(function(p) {
                var qty = 0;
                movements.forEach(function(m) {
                    if (m.productId !== p.id) return;
                    var mq = parseFloat(m.qty) || 0;
                    if (m.type === 'in') qty += mq;
                    else if (m.type === 'out') qty -= mq;
                });
                p.quantity = qty;
                
                // ✅ إعادة حساب avgCost من الحركات المتبقية
                if (p.type === 'finished') {
                    var totalQty = 0;
                    var totalValue = 0;
                    movements.forEach(function(m) {
                        if (m.productId !== p.id) return;
                        if (m.docType === 'رصيد افتتاحي') return;
                        if (!m.docType || m.docType === '-') return;
                        if (m.type === 'in') {
                            var mq = parseFloat(m.qty) || 0;
                            var mp = parseFloat(m.price) || 0;
                            totalQty += mq;
                            totalValue += mq * mp;
                        }
                    });
                    p.avgCost = totalQty > 0 ? (totalValue / totalQty) : null;
                }
            });
            localStorage.setItem('oa_products', JSON.stringify(products));
        }
    } catch (e) { console.error('فشل تصفير المنتجات:', e); }
}
    
    closeModal('dataResetModal');
    showToast('تم تصفير ' + cleared + ' مجموعة — جاري التحديث...', 'success');
    
    setTimeout(function() { location.reload(); }, 1200);
}


// ================================================================
// ===== 9. النسخة الاحتياطية =====
// ================================================================

function _createBackup() {
    var backup = {
        _meta: {
            app: 'Open Account',
            date: new Date().toISOString(),
            reason: 'before-partial-reset',
            version: '3.0'
        }
    };
    
    Object.keys(localStorage).forEach(function(k) {
        if (k.indexOf('oa_') === 0) {
            backup[k] = localStorage.getItem(k);
        }
    });
    
    var dataStr = JSON.stringify(backup, null, 2);
    var blob = new Blob([dataStr], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'open-account-backup-' + new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + '.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return true;
}


// ================================================================
// ===== 10. تصدير الدوال =====
// ================================================================

window.openDataResetModal = openDataResetModal;
window.executeDataReset = executeDataReset;
window.openSetPinModal = openSetPinModal;
window.openChangePinModal = openChangePinModal;
window.confirmRemovePin = confirmRemovePin;
window.savePinFromModal = savePinFromModal;
window.submitPinPrompt = submitPinPrompt;
window.renderSecuritySection = renderSecuritySection;
window._pickAllData = _pickAllData;
window._onDataPickChange = _onDataPickChange;
window._recalcDataPicker = _recalcDataPicker;


// ================================================================
// ===== 11. التهيئة عند التحميل =====
// ================================================================

function _initSecuritySection() {
    var retries = 0;
    function attempt() {
        retries++;
        var el = document.getElementById('securitySectionBody');
        if (el && typeof renderSecuritySection === 'function') {
            renderSecuritySection();
        } else if (retries < 10) {
            setTimeout(attempt, 300);
        }
    }
    attempt();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _initSecuritySection);
} else {
    _initSecuritySection();
}


// ================================================================
// ===== END OF data-reset.js =====
// ================================================================