// ================================================================
// توليد صوت نقرة WAV → Base64
// ================================================================
(function () {
    'use strict';

    // ============================================================
    // توليد WAV من معاملات الصوت
    // ============================================================
    function generateClickWav(options) {
        options = options || {};
        var sampleRate = options.sampleRate || 22050; // 22050 Hz (صغير)
        var durationMs = options.durationMs || 40;      // 40ms
        var frequency = options.frequency || 1200;      // 1200 Hz
        var endFrequency = options.endFrequency || 700; // 700 Hz
        var amplitude = options.amplitude || 0.5;       // 0.5 (50%)

        var numSamples = Math.floor(sampleRate * durationMs / 1000);
        var samples = new Float32Array(numSamples);

        // توليد الموجة (sine) مع تغيير تدريجي في التردد
        var phase = 0;
        for (var i = 0; i < numSamples; i++) {
            var t = i / numSamples;
            // تردد ينخفض من frequency إلى endFrequency
            var currentFreq = frequency + (endFrequency - frequency) * t;
            phase += 2 * Math.PI * currentFreq / sampleRate;

            // مغلف صوتي (attack-decay)
            var envelope;
            if (t < 0.1) {
                // attack سريع
                envelope = t / 0.1;
            } else {
                // decay
                envelope = Math.exp(-(t - 0.1) * 8);
            }

            samples[i] = Math.sin(phase) * amplitude * envelope;
        }

        // تحويل إلى 16-bit PCM
        var buffer = new ArrayBuffer(44 + numSamples * 2);
        var view = new DataView(buffer);

        // WAV header
        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + numSamples * 2, true);
        writeString(view, 8, 'WAVE');
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true);       // PCM
        view.setUint16(22, 1, true);       // Mono
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * 2, true);
        view.setUint16(32, 2, true);       // Block align
        view.setUint16(34, 16, true);      // Bits per sample
        writeString(view, 36, 'data');
        view.setUint32(40, numSamples * 2, true);

        // كتابة العينات
        var offset = 44;
        for (var j = 0; j < numSamples; j++) {
            var s = Math.max(-1, Math.min(1, samples[j]));
            var intSample = s < 0 ? s * 0x8000 : s * 0x7FFF;
            view.setInt16(offset, intSample, true);
            offset += 2;
        }

        return buffer;
    }

    function writeString(view, offset, str) {
        for (var i = 0; i < str.length; i++) {
            view.setUint8(offset + i, str.charCodeAt(i));
        }
    }

    // ============================================================
    // تحويل ArrayBuffer إلى Base64
    // ============================================================
    function arrayBufferToBase64(buffer) {
        var binary = '';
        var bytes = new Uint8Array(buffer);
        var len = bytes.byteLength;
        for (var i = 0; i < len; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    }

    // ============================================================
    // تشغيل التوليد
    // ============================================================
    function run() {
        var wavBuffer = generateClickWav();
        var base64 = arrayBufferToBase64(wavBuffer);
        var dataUri = 'data:audio/wav;base64,' + base64;

        var sizeKB = (base64.length / 1024).toFixed(2);

        // عرض النتيجة
        var out = [];
        out.push('✅ تم توليد الصوت');
        out.push('الحجم: ' + sizeKB + ' KB');
        out.push('');
        out.push('انسخ النص التالي:');
        out.push('');

        // عرض في modal
        var html = '<div style="padding:12px;">' +
            '<div style="background:rgba(0,214,143,0.15);border:1px solid rgba(0,214,143,0.4);border-radius:8px;padding:12px;margin-bottom:12px;">' +
                '<div style="color:#00d68f;font-weight:700;font-size:13px;">✅ تم توليد الصوت</div>' +
                '<div style="font-size:11px;color:#aaa;margin-top:4px;">' +
                    'الحجم: ' + sizeKB + ' KB' +
                '</div>' +
            '</div>' +
            '<div style="font-size:12px;color:#fff;margin-bottom:6px;">📋 النص (انسخه كاملاً):</div>' +
            '<textarea id="soundBase64" readonly style="width:100%;height:200px;font-size:9px;font-family:monospace;direction:ltr;padding:6px;background:#0d0d0d;color:#ccc;border:1px solid #333;border-radius:4px;resize:none;box-sizing:border-box;">' + dataUri + '</textarea>' +
            '<button id="copySoundBtn" style="margin-top:8px;padding:10px;width:100%;background:#28a745;color:#fff;border:none;border-radius:6px;font-weight:700;">📋 تحديد الكل + نسخ</button>' +
            '<div style="margin-top:12px;padding:10px;background:rgba(255,193,7,0.1);border:1px solid rgba(255,193,7,0.3);border-radius:6px;font-size:11px;color:#ffc107;">' +
                '<strong>💡 الخطوة التالية:</strong><br>' +
                '1. انسخ النص أعلاه<br>' +
                '2. الصقه في sounds.js (سنُعطيك الكود)' +
            '</div>' +
        '</div>';

        if (typeof Modal !== 'undefined' && Modal.open) {
            Modal.open({
                id: 'soundGenModal',
                title: 'توليد صوت النقرة',
                size: 'large',
                body: html,
                footer: '<button class="btn btn-cancel" onclick="closeModal(\'soundGenModal\')">إغلاق</button>',
                onOpen: function(modalEl) {
                    var btn = modalEl.querySelector('#copySoundBtn');
                    var ta = modalEl.querySelector('#soundBase64');
                    if (btn && ta) {
                        btn.addEventListener('click', function() {
                            ta.focus();
                            ta.select();
                            ta.setSelectionRange(0, 999999);
                            var ok = false;
                            try { ok = document.execCommand('copy'); } catch (e) {}
                            if (ok) {
                                btn.style.background = '#155724';
                                btn.textContent = '✅ تم النسخ';
                            } else {
                                alert('اضغط مطولاً على النص → تحديد الكل → نسخ');
                            }
                        });
                    }
                }
            });
        } else {
            // عرض في console
            console.log(dataUri);
            alert('النص في console (انسخه)\n\nالحجم: ' + sizeKB + ' KB');
        }
    }

    window.addEventListener('load', function () {
        setTimeout(run, 1500);
    });

    // إتاحة عامة
    window.OA_GENERATE_SOUND = run;
})();