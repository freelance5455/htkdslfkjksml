// ================================================================
// Open Account — قواعد التدقيق المتقدمة
// الملف: audit-rules.js
// المرحلة: 1 — 7 فحوصات عالية الثقة
// ================================================================

(function () {
    'use strict';

    // ============================================================
    // 1. أدوات مساعدة
    // ============================================================

    function _num(v) {
        var n = parseFloat(v);
        return isFinite(n) ? n : 0;
    }

    function _text(v) {
        return (v === null || v === undefined) ? '' : String(v).trim();
    }

    function _isPosted(entry) {
        if (!entry) return false;
        if (entry.cancelled === true) return false;
        if (entry.documentStatus === 'cancelled') return false;
        if (entry.status === 'ملغاة') return false;
        return true;
    }

    // ============================================================
    // 2. الفحص 1: توازن القيود المرحلة
    // ============================================================

    function _checkJournalBalance() {
        var results = [];
        var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
            ? journalEntries : [];

        entries.forEach(function (entry) {
            if (!_isPosted(entry)) return;

            // 1) التوازن بالعملة الأصلية
            var debitOrig = 0, creditOrig = 0;
            (entry.lines || []).forEach(function (l) {
                debitOrig += _num(l.debit);
                creditOrig += _num(l.credit);
            });
            var diffOrig = Math.abs(debitOrig - creditOrig);

            if (diffOrig > 0.01) {
                results.push({
                    type: 'error',
                    code: 'JOURNAL_ENTRY_UNBALANCED_ORIGINAL',
                    title: 'قيد غير متوازن بالعملة الأصلية',
                    description: 'القيد: ' + _text(entry.id) + ' | النوع: ' + _text(entry.type),
                    details: 'المدين: ' + debitOrig.toFixed(2) + ' | الدائن: ' + creditOrig.toFixed(2) + ' | الفرق: ' + diffOrig.toFixed(2),
                    referenceId: entry.referenceId,
                    entryId: entry.id,
                    currency: entry.currency
                });
            }

            // 2) التوازن بالعملة الأساسية
            var debitBase = 0, creditBase = 0;
            var hasBase = false;
            (entry.lines || []).forEach(function (l) {
                if (l.debitBase !== undefined && l.debitBase !== null) hasBase = true;
                if (l.creditBase !== undefined && l.creditBase !== null) hasBase = true;
                debitBase += _num(l.debitBase !== undefined ? l.debitBase : l.debit);
                creditBase += _num(l.creditBase !== undefined ? l.creditBase : l.credit);
            });
            var diffBase = Math.abs(debitBase - creditBase);

            if (diffBase > 0.01) {
                results.push({
                    type: 'error',
                    code: 'JOURNAL_ENTRY_UNBALANCED_BASE',
                    title: 'قيد غير متوازن بالعملة الأساسية',
                    description: 'القيد: ' + _text(entry.id) + ' | النوع: ' + _text(entry.type),
                    details: 'المدين: ' + debitBase.toFixed(2) + ' | الدائن: ' + creditBase.toFixed(2) + ' | الفرق: ' + diffBase.toFixed(2),
                    referenceId: entry.referenceId,
                    entryId: entry.id,
                    currency: entry.currency
                });
            }
        });

        return results;
    }

    // ============================================================
    // 3. الفحص 2: سلامة مراجع القيود
    // ============================================================

    function _checkReferenceIntegrity() {
        var results = [];
        var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
            ? journalEntries : [];

        // خريطة: referenceType → مصدر
        var sourceMap = {
            'sales_invoice':        function (id) { return (typeof salesInvoices !== 'undefined') && salesInvoices.some(function (x) { return x && x.id === id; }); },
            'purchase_invoice':     function (id) { return (typeof purchaseInvoices !== 'undefined') && purchaseInvoices.some(function (x) { return x && x.id === id; }); },
            'receipt':              function (id) { return (typeof receipts !== 'undefined') && receipts.some(function (x) { return x && x.id === id; }); },
            'supplier_refund':      function (id) { return (typeof receipts !== 'undefined') && receipts.some(function (x) { return x && x.id === id; }); },
            'payment':              function (id) { return (typeof payments !== 'undefined') && payments.some(function (x) { return x && x.id === id; }); },
            'customer_refund':      function (id) { return (typeof payments !== 'undefined') && payments.some(function (x) { return x && x.id === id; }); },
            'expense':              function (id) { return (typeof payments !== 'undefined') && payments.some(function (x) { return x && x.id === id; }); },
            'transfer':             function (id) { return (typeof transfers !== 'undefined') && transfers.some(function (x) { return x && (x.id === id || x.number === id); }); },
            'production':           function (id) { return (typeof productionDocs !== 'undefined') && productionDocs.some(function (x) { return x && x.id === id; }); },
            'return_sale':          function (id) { return (typeof returnsDocs !== 'undefined') && returnsDocs.some(function (x) { return x && x.id === id; }); },
            'return_purchase':      function (id) { return (typeof returnsDocs !== 'undefined') && returnsDocs.some(function (x) { return x && x.id === id; }); },
            'direct':               function (id) { return (typeof directTransactions !== 'undefined') && directTransactions.some(function (x) { return x && x.id === id; }); }
        };

        // الأنواع التي لا تحتاج مرجع
        var allowedNoRef = ['direct', 'transfer'];

        entries.forEach(function (entry) {
            if (!_isPosted(entry)) return;

            var refId = _text(entry.referenceId);
            var refType = _text(entry.referenceType);
            var type = _text(entry.type);

            // 1) قيد بدون مرجع (مسموح لبعض الأنواع)
            if (!refId) {
                // القيود العكسية — لها reversalOf بدلاً من referenceId
                if (entry.reversalOf) return;

                if (allowedNoRef.indexOf(type) === -1 && allowedNoRef.indexOf(refType) === -1) {
                    results.push({
                        type: 'warning',
                        code: 'JOURNAL_MISSING_REFERENCE',
                        title: 'قيد بدون مرجع',
                        description: 'القيد: ' + _text(entry.id) + ' | النوع: ' + type,
                        details: 'لا يحتوي referenceId — قد يكون قيداً قديماً أو تسوية',
                        entryId: entry.id
                    });
                }
                return;
            }

            // 2) مرجع يشير إلى مستند غير موجود
            var checker = sourceMap[refType];
            if (!checker) {
                // نوع مرجع غير معروف
                results.push({
                    type: 'info',
                    code: 'JOURNAL_UNKNOWN_REFERENCE_TYPE',
                    title: 'نوع مرجع غير معروف',
                    description: 'القيد: ' + _text(entry.id) + ' | النوع: ' + refType,
                    details: 'referenceType: ' + refType + ' — لا يوجد فاحص له',
                    entryId: entry.id,
                    referenceId: refId
                });
                return;
            }

            if (!checker(refId)) {
                results.push({
                    type: 'error',
                    code: 'JOURNAL_BROKEN_REFERENCE',
                    title: 'مرجع مكسور',
                    description: 'القيد: ' + _text(entry.id) + ' | النوع: ' + type,
                    details: 'referenceType: ' + refType + ' | referenceId: ' + refId + ' — لا يوجد مستند مطابق',
                    entryId: entry.id,
                    referenceId: refId
                });
            }
        });

        return results;
    }

    // ============================================================
    // 4. الفحص 3: القيود المكررة
    // ============================================================

    function _checkDuplicateEntries() {
        var results = [];
        var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
            ? journalEntries : [];

        // الأنواع المسموح بتعددها لنفس المرجع
        var multiAllowedTypes = [
            'sales_invoice',        // قيد واحد
            'purchase_invoice',     // قيد واحد
            'receipt',              // قيد واحد
            'payment',              // قيد واحد
            'expense',              // قيد واحد
            'production',           // قيد واحد
            'return_sale',          // قيد واحد
            'return_purchase',      // قيد واحد
            'direct',               // قيد واحد
            'transfer'              // قيد واحد
        ];

        // مفتاح: type + referenceId
        var seen = {};

        entries.forEach(function (entry) {
            if (!_isPosted(entry)) return;

            var type = _text(entry.type);
            var refId = _text(entry.referenceId);

            if (!type || !refId) return;

            // تجاهل القيود العكسية
            if (entry.reversalOf) return;

            // تجاهل الأنواع التي تسمح بالتعدد
            if (multiAllowedTypes.indexOf(type) === -1) return;

            var key = type + '|' + refId;

            if (seen[key]) {
                results.push({
                    type: 'error',
                    code: 'JOURNAL_DUPLICATE_ENTRY',
                    title: 'قيد مكرر',
                    description: 'النوع: ' + type + ' | المرجع: ' + refId,
                    details: 'القيد الأول: ' + seen[key] + ' | القيد الثاني: ' + entry.id,
                    entryId: entry.id,
                    referenceId: refId
                });
            } else {
                seen[key] = entry.id;
            }
        });

        return results;
    }

    // ============================================================
    // 5. الفحص 4: توافق حالة المستند مع القيد
    // ============================================================

    function _checkDocumentStatus() {
        var results = [];

        // 1) فواتير البيع الملغاة
        if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
            salesInvoices.forEach(function (inv) {
                if (!inv) return;
                var isCancelled = inv.cancelled === true || inv.documentStatus === 'cancelled' || inv.status === 'ملغاة';
                if (!isCancelled) return;

                // هل يوجد قيد عكسي؟
                var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
                    ? journalEntries : [];
                var hasReversal = entries.some(function (e) {
                    return e && e.reversalOf === inv.id && e.type === 'invoice_cancellation';
                });

                if (!hasReversal) {
                    results.push({
                        type: 'error',
                        code: 'CANCELLED_INVOICE_NO_REVERSAL',
                        title: 'فاتورة بيع ملغاة بدون قيد عكسي',
                        description: 'الفاتورة: ' + _text(inv.id),
                        details: 'الحالة: ملغاة | لا يوجد قيد إلغاء',
                        referenceId: inv.id
                    });
                }
            });
        }

        // 2) فواتير الشراء الملغاة
        if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
            purchaseInvoices.forEach(function (inv) {
                if (!inv) return;
                var isCancelled = inv.cancelled === true || inv.documentStatus === 'cancelled' || inv.status === 'ملغاة';
                if (!isCancelled) return;

                var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
                    ? journalEntries : [];
                var hasReversal = entries.some(function (e) {
                    return e && e.reversalOf === inv.id && e.type === 'invoice_cancellation';
                });

                if (!hasReversal) {
                    results.push({
                        type: 'error',
                        code: 'CANCELLED_PURCHASE_NO_REVERSAL',
                        title: 'فاتورة شراء ملغاة بدون قيد عكسي',
                        description: 'الفاتورة: ' + _text(inv.id),
                        details: 'الحالة: ملغاة | لا يوجد قيد إلغاء',
                        referenceId: inv.id
                    });
                }
            });
        }

        return results;
    }

    // ============================================================
    // 6. الفحص 5: القيد العكسي للمستندات الملغاة
    // ============================================================

    function _checkReversalEntries() {
        var results = [];
        var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
            ? journalEntries : [];

        // ابحث عن القيود العكسية
        entries.forEach(function (entry) {
            if (!entry.reversalOf) return;
            if (!_isPosted(entry)) return;

            // القيد الأصلي
            var originalId = entry.reversalOf;
            var original = entries.find(function (e) {
                return e && e.id === originalId;
            });

            if (!original) {
                results.push({
                    type: 'warning',
                    code: 'REVERSAL_NO_ORIGINAL',
                    title: 'قيد عكسي بدون قيد أصلي',
                    description: 'القيد العكسي: ' + _text(entry.id),
                    details: 'reversalOf: ' + originalId + ' — القيد الأصلي غير موجود',
                    entryId: entry.id
                });
                return;
            }

            // مقارنة الإجماليات
            var origDebit = 0, origCredit = 0;
            (original.lines || []).forEach(function (l) {
                origDebit += _num(l.debit);
                origCredit += _num(l.credit);
            });

            var revDebit = 0, revCredit = 0;
            (entry.lines || []).forEach(function (l) {
                revDebit += _num(l.debit);
                revCredit += _num(l.credit);
            });

            var diff = Math.abs(origDebit - revCredit) + Math.abs(origCredit - revDebit);
            if (diff > 0.01) {
                results.push({
                    type: 'error',
                    code: 'REVERSAL_NOT_MATCHING',
                    title: 'القيد العكسي لا يطابق الأصلي',
                    description: 'الأصلي: ' + originalId + ' | العكسي: ' + entry.id,
                    details: 'الأصلي — مدين: ' + origDebit.toFixed(2) + ' | دائن: ' + origCredit.toFixed(2) +
                             ' || العكسي — مدين: ' + revDebit.toFixed(2) + ' | دائن: ' + revCredit.toFixed(2),
                    entryId: entry.id
                });
            }
        });

        return results;
    }

    // ============================================================
    // 7. الفحص 6: الحركات بلا مصدر
    // ============================================================

    function _checkOrphanMovements() {
        var results = [];
        var movements = (typeof stockMovements !== 'undefined' && Array.isArray(stockMovements))
            ? stockMovements : [];

        // الأنواع المشروعة (لا تحتاج مصدر)
        var allowedTypes = [
            'رصيد افتتاحي',
            '-',  // بلا نوع
            ''
        ];

        movements.forEach(function (m) {
            if (!m) return;

            var docType = _text(m.docType);
            var docId = _text(m.docId);

            // إذا كان النوع مشروعاً — تخطى
            if (allowedTypes.indexOf(docType) !== -1) return;

            // إذا لا يوجد docId — تخطى (حركة قديمة)
            if (!docId || docId === '-') {
                results.push({
                    type: 'warning',
                    code: 'STOCK_MOVEMENT_NO_DOC',
                    title: 'حركة مخزنية بدون مستند',
                    description: 'الحركة: ' + _text(m.id) + ' | المنتج: ' + _text(m.productName),
                    details: 'docType: ' + docType + ' | docId: ' + docId + ' | الكمية: ' + m.qty,
                    entryId: m.id
                });
            }
        });

        return results;
    }

    // ============================================================
    // 8. الفحص 7: سلامة أسعار الصرف
    // ============================================================

    function _checkExchangeRates() {
    var results = [];
    var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
        ? journalEntries : [];
    var baseCur = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var baseRate = (typeof getRate === 'function') ? (getRate(baseCur) || 1) : 1;

    entries.forEach(function (entry) {
        if (!_isPosted(entry)) return;

        var currency = _text(entry.currency);
        if (!currency) return;
        if (currency === baseCur) return; // لا فحص للعملة الأساسية

        // سعر الصرف
        var rate = _num(entry.exchangeRate);
        if (rate <= 0) {
            results.push({
                type: 'error',
                code: 'EXCHANGE_RATE_INVALID',
                title: 'سعر صرف غير صالح',
                description: 'القيد: ' + _text(entry.id) + ' | العملة: ' + currency,
                details: 'exchangeRate: ' + entry.exchangeRate,
                entryId: entry.id,
                currency: currency
            });
            return;
        }

        // ✅ عامل التحويل الصحيح
        var conversionFactor = (baseRate > 0) ? (rate / baseRate) : 1;

        // التحقق من debitBase/creditBase
        (entry.lines || []).forEach(function (l, idx) {
            var dOrig = _num(l.debit);
            var cOrig = _num(l.credit);

            // ✅ فحص debitBase
            if (dOrig > 0 && l.debitBase !== undefined && l.debitBase !== null) {
                var expectedD = dOrig * conversionFactor;
                var actualD = _num(l.debitBase);
                var diffD = Math.abs(expectedD - actualD);
                var thresholdD = Math.max(expectedD, 0.01) * 0.01;

                if (diffD > 0.01 && diffD > thresholdD) {
                    results.push({
                        type: 'warning',
                        code: 'DEBIT_BASE_MISMATCH',
                        title: 'debitBase لا يطابق debit × conversionFactor',
                        description: 'القيد: ' + _text(entry.id) + ' | السطر: ' + (idx + 1),
                        details: 'debit: ' + dOrig + ' | rate: ' + rate + ' | baseRate: ' + baseRate +
                                 ' | expected: ' + expectedD.toFixed(2) + ' | actual: ' + actualD.toFixed(2),
                        entryId: entry.id
                    });
                }
            }

            // ✅ فحص creditBase
            if (cOrig > 0 && l.creditBase !== undefined && l.creditBase !== null) {
                var expectedC = cOrig * conversionFactor;
                var actualC = _num(l.creditBase);
                var diffC = Math.abs(expectedC - actualC);
                var thresholdC = Math.max(expectedC, 0.01) * 0.01;

                if (diffC > 0.01 && diffC > thresholdC) {
                    results.push({
                        type: 'warning',
                        code: 'CREDIT_BASE_MISMATCH',
                        title: 'creditBase لا يطابق credit × conversionFactor',
                        description: 'القيد: ' + _text(entry.id) + ' | السطر: ' + (idx + 1),
                        details: 'credit: ' + cOrig + ' | rate: ' + rate + ' | baseRate: ' + baseRate +
                                 ' | expected: ' + expectedC.toFixed(2) + ' | actual: ' + actualC.toFixed(2),
                        entryId: entry.id
                    });
                }
            }
        });
    });

    return results;
}

    // ============================================================
    // 9. جدول AUDIT_RULES
    // ============================================================

    var AUDIT_RULES = [
        {
            id: 'JOURNAL_BALANCE',
            title: 'توازن القيود المرحلة',
            severity: 'error',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkJournalBalance
        },
        {
            id: 'REFERENCE_INTEGRITY',
            title: 'سلامة مراجع القيود',
            severity: 'error',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkReferenceIntegrity
        },
        {
            id: 'DUPLICATE_ENTRIES',
            title: 'القيود المكررة',
            severity: 'error',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkDuplicateEntries
        },
        {
            id: 'DOCUMENT_STATUS',
            title: 'توافق حالة المستند مع القيد',
            severity: 'error',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkDocumentStatus
        },
        {
            id: 'REVERSAL_ENTRIES',
            title: 'القيد العكسي للمستندات الملغاة',
            severity: 'error',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkReversalEntries
        },
        {
            id: 'ORPHAN_MOVEMENTS',
            title: 'الحركات بلا مصدر',
            severity: 'warning',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkOrphanMovements
        },
        {
            id: 'EXCHANGE_RATES',
            title: 'سلامة أسعار الصرف',
            severity: 'error',
            phase: 1,
            enabled: true,
            canAutoFix: false,
            run: _checkExchangeRates
        }
    ];

    // ============================================================
    // 10. المحرك المركزي
    // ============================================================

    function runRuleBasedAudit(options) {
        options = options || {};
        var phase = options.phase || 1;
        var results = [];

        AUDIT_RULES.forEach(function (rule) {
            if (!rule.enabled) return;
            if (rule.phase !== phase) return;

            try {
                var ruleResults = rule.run();
                if (Array.isArray(ruleResults)) {
                    ruleResults.forEach(function (r) {
                        r.ruleId = rule.id;
                        results.push(r);
                    });
                }
            } catch (e) {
                results.push({
                    type: 'error',
                    code: 'AUDIT_RULE_FAILED',
                    title: 'فشل الفحص: ' + rule.title,
                    description: 'الفحص: ' + rule.id,
                    details: e.message || String(e),
                    ruleId: rule.id
                });
            }
        });

        return results;
    }

    // ============================================================
    // 11. التصدير
    // ============================================================

    window.AUDIT_RULES = AUDIT_RULES;
    window.runRuleBasedAudit = runRuleBasedAudit;

    console.log('[OA] ✅ audit-rules.js جاهز — ' + AUDIT_RULES.length + ' قاعدة');

})();