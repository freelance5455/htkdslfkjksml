// ================================================================
// Open Account — نظام محاسبي
// الملف: exchange.js
// الوصف: أسعار الصرف والتحويل بين العملات
// ================================================================


// ================================================================
// ===== 1. أسعار الصرف =====
// ================================================================

/**
 * أسعار الصرف مقابل الريال اليمني (YER)
 * 
 * - SAR: كم ريال يمني يساوي 1 ريال سعودي
 * - USD: كم ريال يمني يساوي 1 دولار أمريكي
 * - YER: دائماً = 1
 * 
 * القيم الافتراضية:
 *   1 SAR = 530 YER
 *   1 USD = 2,014 YER  (محسوب من 3.8 × 530)
 */
var exchangeRates = {
    YER: 1,        // الريال اليمني (الأساس)
    SAR: 530,      // القيمة الافتراضية (يمكن تعديلها)
    USD: 2014      // يُحسب تلقائياً

};


// ================================================================
// ===== 2. ثابت الدولار/السعودي =====
// ================================================================

/**
 * سعر ثابت: 1 دولار أمريكي = 3.8 ريال سعودي
 * يمكن تعديله من الإعدادات
 */
var USD_TO_SAR = 3.8;


// ================================================================
// ===== 3. الحصول على سعر الصرف =====
// ================================================================

/**
 * الحصول على سعر صرف عملة مقابل العملة الأساسية
 * @param {string} code - رمز العملة
 * @returns {number}
 */
function getRate(code) {
    if (!code) return 1;
    var rate = exchangeRates[code];
    return (typeof rate === 'number' && rate > 0) ? rate : 1;
}


/**
 * الحصول على سعر صرف الدولار مقابل السعودي
 * @returns {number}
 */
function getUSDToSARRate() {
    return USD_TO_SAR;
}


// ================================================================
// ===== 4. التحويل بين العملات =====
// ================================================================

/**
 * تحويل مبلغ من عملة إلى أخرى
 * @param {number} amount - المبلغ
 * @param {string} fromCurrency - من عملة
 * @param {string} toCurrency - إلى عملة (اختياري، افتراضي: العملة الأساسية)
 * @returns {number}
 */
function convertCurrency(amount, fromCurrency, toCurrency) {
    var from = fromCurrency || 'YER';
    var to = toCurrency || (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER');
    
    // إذا نفس العملة
    if (from === to) {
        return parseFloat(amount) || 0;
    }
    
    // الحصول على أسعار الصرف
    var fromRate = getRate(from);
    var toRate = getRate(to);
    
    // التحويل: من العملة → العملة الأساسية → العملة المطلوبة
    var amountInBase = (parseFloat(amount) || 0) * fromRate;
    var result = amountInBase / toRate;
    
    return result;
}


/**
 * الحصول على المعادل بالعملة الأساسية
 * @param {number} amount
 * @param {string} currency
 * @returns {number}
 */
function getEquivalent(amount, currency) {
    var base = typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER';
    return convertCurrency(amount, currency, base);
}

/** تحويل مبلغ باستخدام سعر صرف محفوظ وقت العملية. */
function getEquivalentAtRate(amount, currency, rateSnapshot) {
    var n = parseFloat(amount) || 0;
    var c = currency || 'YER';
    var base = typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER';
    if (c === base) return n;
    var rate = parseFloat(rateSnapshot);
    if (!(rate > 0)) return getEquivalent(n, c);
    // rateSnapshot = قيمة 1 من العملة إلى YER، ثم نصل للعملة الأساسية الحالية.
    var baseRate = getRate(base);
    return (n * rate) / (baseRate || 1);
}

function getCurrentExchangeRateSnapshot(currency) {
    var c = currency || 'YER';
    return typeof getRate === 'function' ? getRate(c) : 1;
}


// ================================================================
// ===== 5. تحديث أسعار الصرف =====
// ================================================================

/**
 * تحديث سعر صرف عملة
 * @param {string} code - رمز العملة (SAR أو YER)
 * @param {number} rate - السعر الجديد
 */
function setExchangeRate(code, rate) {
    var newRate = parseFloat(rate);
    
    if (isNaN(newRate) || newRate <= 0) {
        return false;
    }
    
    if (code === 'SAR') {
        // تحديث سعر السعودي
        exchangeRates.SAR = newRate;
        
        // حساب الدولار تلقائياً
        exchangeRates.USD = newRate * USD_TO_SAR;
    } 
    else if (code === 'YER') {
        // اليمني هو الأساس
        exchangeRates.YER = 1;
        
        // إعادة حساب السعودي والدولار
        // (YER هو الأساس دائماً، لذا لا يوجد حساب آخر)
    }
    else if (code === 'USD') {
        // تحديث الدولار مباشرة
        exchangeRates.USD = newRate;
        
        // حساب السعودي عكسياً
        // لكن الطريقة المفضلة: تعديل السعودي فقط
    }
    
    return true;
}


/**
 * تحديث سعر الدولار مقابل السعودي
 * @param {number} rate - السعر الجديد (افتراضي: 3.8)
 */
function setUSDToSARRate(rate) {
    var newRate = parseFloat(rate);
    
    if (isNaN(newRate) || newRate <= 0) {
        return false;
    }
    
    USD_TO_SAR = newRate;
    
    // إعادة حساب الدولار مقابل اليمني
    exchangeRates.USD = exchangeRates.SAR * USD_TO_SAR;
    
    return true;
}


// ================================================================
// ===== 6. حفظ وتحميل أسعار الصرف =====
// ================================================================

/**
 * حفظ أسعار الصرف في LocalStorage
 */
function saveExchangeRates() {
    // قراءة القيم من الحقول
    var sarRateEl = document.getElementById('sarRate');
    var usdToSarEl = document.getElementById('usdToSarRate');
    
    // حفظ القيم الحالية
    if (sarRateEl) {
        var sarRate = parseFloat(sarRateEl.value);
        if (!isNaN(sarRate) && sarRate > 0) {
            exchangeRates.SAR = sarRate;
        }
    }
    
    if (usdToSarEl) {
        var usdToSar = parseFloat(usdToSarEl.value);
        if (!isNaN(usdToSar) && usdToSar > 0) {
            USD_TO_SAR = usdToSar;
        }
    }
    
    // إعادة حساب الدولار
    exchangeRates.USD = exchangeRates.SAR * USD_TO_SAR;
    
    // حفظ في LocalStorage
    try {
        var data = {
            rates: {
                YER: 1,
                SAR: exchangeRates.SAR,
                USD: exchangeRates.USD
            },
            usdToSar: USD_TO_SAR
        };
        localStorage.setItem('oa_exchange_rates', JSON.stringify(data));
        console.log('Exchange saved:', data);
    } catch(e) {
        console.error('Save failed:', e);
    }
    
    updateUSDDisplay();
    
    if (typeof showToast === 'function') {
        showToast('تم حفظ أسعار الصرف', 'success');
    }
}


/**
 * تحميل أسعار الصرف من LocalStorage
 */
function loadExchangeRates() {
    try {
        var json = localStorage.getItem('oa_exchange_rates');
        
        if (!json) {
            console.log('Exchange: no saved rates');
            return;
        }
        
        var data = JSON.parse(json);
        
        if (data && data.rates) {
            if (typeof data.rates.SAR === 'number' && data.rates.SAR > 0) {
                exchangeRates.SAR = data.rates.SAR;
            }
            if (typeof data.rates.USD === 'number' && data.rates.USD > 0) {
                exchangeRates.USD = data.rates.USD;
            }
        }
        
        if (data && typeof data.usdToSar === 'number' && data.usdToSar > 0) {
            USD_TO_SAR = data.usdToSar;
        }
        
        console.log('Exchange loaded: SAR =', exchangeRates.SAR);
    } catch(e) {
        console.error('Load failed:', e);
    }
}


// ================================================================
// ===== 7. مزامنة حقول الإعدادات =====
// ================================================================

/**
 * قراءة القيم من حقول الإعدادات وتحديث أسعار الصرف
 */
function applyExchangeRatesFromSettings() {
    // قراءة سعر السعودي
    var sarRateEl = document.getElementById('sarRate');
    if (sarRateEl) {
        var sarRate = parseFloat(sarRateEl.value);
        if (!isNaN(sarRate) && sarRate > 0) {
            exchangeRates.SAR = sarRate;
            exchangeRates.USD = sarRate * USD_TO_SAR;
        }
    }
    
    // حفظ
    saveExchangeRates();
}

/**
 * تعبئة حقول الإعدادات بأسعار الصرف الحالية
 */
function populateExchangeRateFields() {

    // سعر السعودي
    var sarRateEl = document.getElementById('sarRate');
    if (sarRateEl) {
        sarRateEl.value = exchangeRates.SAR || '';
    }
    
    // سعر الدولار مقابل السعودي
    var usdToSarEl = document.getElementById('usdToSarRate');
    if (usdToSarEl) {
        usdToSarEl.value = USD_TO_SAR || '';
    }
    
    // العملة الأساسية
    var baseCurrEl = document.getElementById('baseCurrencySelect');
    if (baseCurrEl && typeof getBaseCurrency === 'function') {
        baseCurrEl.value = getBaseCurrency();
    }
    
    // اسم العملة الأساسية
    var baseNameEl = document.getElementById('baseCurrencyName');
    if (baseNameEl && typeof getCurrencyName === 'function') {
        baseNameEl.textContent = getCurrencyName(getBaseCurrency());
    }
    
    // تحديث عرض الدولار باليمني
    updateUSDDisplay();
}


/**
 * تحديث عرض سعر الدولار باليمني (تلقائي)
 */
function updateUSDDisplay() {
    var displayEl = document.getElementById('usdInYerDisplay');
    if (!displayEl) return;
    
    var sarRate = parseFloat(exchangeRates.SAR) || 0;
    var usdToSar = parseFloat(USD_TO_SAR) || 0;
    var usdInYer = sarRate * usdToSar;
    
    if (typeof formatAmountWithCommas === 'function') {
        displayEl.textContent = formatAmountWithCommas(usdInYer) + ' ر.ي';
    } else {
        displayEl.textContent = usdInYer.toFixed(2) + ' ر.ي';
    }
}


// ================================================================
// ===== 8. تهيئة نظام الصرف =====
// ================================================================

/**
 * تهيئة نظام أسعار الصرف
 */
function initExchange() {
    // تحميل الأسعار المحفوظة
    loadExchangeRates();
    
    // تعبئة حقول الإعدادات
    populateExchangeRateFields();
    
    console.log('Exchange: SAR = ' + exchangeRates.SAR + ' YER, USD = ' + exchangeRates.USD.toFixed(2) + ' YER');
}
// ================================================================
// ===== 9. التحقق من رصيد الحساب =====
// ================================================================

/**
 * حساب رصيد حساب (صندوق أو بنك) بعملة محددة
 * @param {string} accountType - 'cashbox' أو 'bank'
 * @param {string} currency - رمز العملة
 * @returns {number}
 */
function getAccountBalanceByCurrency(accountType, currency) {
    var balance = 0;
    var c = currency || 'YER';
    var acc = accountType || 'cashbox';

    // 1. الحركات المباشرة
    if (typeof directTransactions !== 'undefined' && Array.isArray(directTransactions)) {	
        directTransactions.forEach(function(t) {
        	if (!_reportIsActive(t)) return;
            if (t.account !== acc) return;
            if ((t.currency || 'YER') !== c) return;
            if (t.direction === 'in') balance += parseFloat(t.amount) || 0;
            else balance -= parseFloat(t.amount) || 0;
        });
    }

    // 2. سندات القبض (للصندوق: نقدي فقط | للبنك: تحويل/بطاقة)
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
        	if (!_reportIsActive(r)) return;     
            var m = r.method || 'نقدي';
            var isCash = (m === 'نقدي');
            var isBank = (m === 'تحويل بنكي' || m === 'بطاقة');
            if (acc === 'cashbox' && !isCash) return;
            if (acc === 'bank' && !isBank) return;
            if ((r.currency || 'YER') !== c) return;
            balance += parseFloat(r.amount) || 0;
        });
    }

    // 3. سندات الصرف
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.archived) return;
            if (!_reportIsActive(p)) return;           
            var m = p.method || 'نقدي';
            var isCash = (m === 'نقدي');
            var isBank = (m === 'تحويل بنكي' || m === 'بطاقة');
            if (acc === 'cashbox' && !isCash) return;
            if (acc === 'bank' && !isBank) return;
            if ((p.currency || 'YER') !== c) return;
            balance -= parseFloat(p.amount) || 0;
        });
    }

    // 4. التحويلات
    if (typeof transfers !== 'undefined' && Array.isArray(transfers)) {
        transfers.forEach(function(t) {
            if (t.status === 'cancelled') return;
            if (!_reportIsActive(t)) return;
            if (t.from && t.from.accountType === acc && (t.from.currency || 'YER') === c) {
                balance -= parseFloat(t.from.amount) || 0;
            }
            if (t.to && t.to.accountType === acc && (t.to.currency || 'YER') === c) {
                balance += parseFloat(t.to.amount) || 0;
            }
        });
    }

    // 5. الرصيد الافتتاحي
    if (typeof Storage !== 'undefined') {
        var cycleOpening = Storage.get('oa_cycle_opening_balances', null);
        if (cycleOpening && cycleOpening.accounts && cycleOpening.accounts[acc]) {
            balance += parseFloat(cycleOpening.accounts[acc][c]) || 0;
        }
    }

    return balance;
}


/**
 * التحقق من كفاية الرصيد — يُعيد true إن كان كافياً
 */
/**
 * التحقق من كفاية الرصيد — بنفس عملة العملية
 */
function checkSufficientBalance(accountType, currency, amount) {
    var needed = parseFloat(amount) || 0;
    var entryCurrency = currency || (
        typeof getBaseCurrency === 'function'
            ? getBaseCurrency()
            : 'SAR'
    );

    var balance = 0;

    if (typeof getAccountBalanceByCurrency === 'function') {
        balance = getAccountBalanceByCurrency(
            accountType,
            entryCurrency
        );
    }

    var EPSILON = 0.0001;

    if (needed <= balance + EPSILON) {
        return {
            ok: true,
            balance: balance,
            needed: needed,
            currency: entryCurrency
        };
    }

    return {
        ok: false,
        balance: balance,
        needed: needed,
        short: needed - balance,
        currency: entryCurrency,
        accountLabel: accountType === 'bank' ? 'البنك' : 'الصندوق',
        message:
            'لا يوجد رصيد كافٍ. المطلوب: ' +
            needed.toFixed(2) + ' ' + entryCurrency +
            '، المتاح: ' +
            balance.toFixed(2) + ' ' + entryCurrency +
            '. يرجى تحويل المبلغ من عملة أخرى أولاً.'
    };
}