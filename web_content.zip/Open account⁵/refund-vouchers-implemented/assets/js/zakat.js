// ================================================================
// Open Account — تقرير الزكاة (v2 — متعدد العملات)
// ================================================================

function _zakatValue(v) {
    return parseFloat(v) || 0;
}

function _zakatConvert(amount, currency) {
    var c = currency || 'YER';
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    if (c === base) return _zakatValue(amount);
    var rate = (typeof getCurrentExchangeRateSnapshot === 'function')
        ? getCurrentExchangeRateSnapshot(c)
        : (typeof getRate === 'function' ? getRate(c) : 1);
    var baseRate = (typeof getRate === 'function') ? getRate(base) : 1;
    return (_zakatValue(amount) * rate) / (baseRate || 1);
}

function calculateZakat() {
    try {
        var rateEl = document.getElementById('zakatRate');
        var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
        var rate = (_zakatValue(rateEl ? rateEl.value : 2.5) || 2.5) / 100;

        // المواد الخام + المنتجات التامة (محوّلة للعملة الأساسية)
        var raw = 0, finished = 0;
        if (typeof products !== 'undefined' && Array.isArray(products)) {
            var baseCur = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

products.forEach(function (p) {
    var cost = _zakatValue(
        p.avgCost != null ? p.avgCost :
        (p.averageCost != null ? p.averageCost :
        (p.cost != null ? p.cost : p.price))
    );
    var v = _zakatValue(p.quantity) * cost;

    // ✅ استخدام costCurrency (وليس p.currency)
    var costCur = p.costCurrency || p.currency || baseCur;

    var converted;
    if (costCur === baseCur) {
        converted = v;
    } else {
        converted = _zakatConvert(v, costCur);
    }

    if ((p.type || 'finished') === 'raw') raw += converted;
    else finished += converted;
});
        }

        // الصندوق
        var cash = 0;
        if (typeof getCashboxTransactions === 'function') {
            (getCashboxTransactions() || []).forEach(function (x) {
                var v = x.type === 'in' ? _zakatValue(x.amount) : -_zakatValue(x.amount);
                cash += _zakatConvert(v, x.currency || 'YER');
            });
        }

        // البنك
        var bank = 0;
        if (typeof getBankTransactions === 'function') {
            (getBankTransactions() || []).forEach(function (x) {
                var v = x.type === 'in' ? _zakatValue(x.amount) : -_zakatValue(x.amount);
                bank += _zakatConvert(v, x.currency || 'YER');
            });
        }

        // الذمم
        var receivables = 0;
        if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
            salesInvoices.forEach(function (i) {
                receivables += _zakatConvert(_zakatValue(i.total), i.currency || 'YER');
            });
        }
        if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
            receipts.forEach(function (r) {
                receivables -= _zakatConvert(_zakatValue(r.amount), r.currency || 'YER');
            });
        }

        var total = Math.max(0, cash + bank + raw + finished + Math.max(0, receivables));
        var zakat = total * rate;

        var out = {
            cash: cash,
            bank: bank,
            raw: raw,
            finished: finished,
            receivables: Math.max(0, receivables),
            total: total,
            zakat: zakat,
            currency: baseCurrency,
            rate: rate
        };

        var b = document.getElementById('zakatResult');
        if (b) {
            var currencyLabel = (typeof getCurrencyName === 'function') ? getCurrencyName(baseCurrency) : baseCurrency;
            var html = '';

            // ترويسة العملة
            html += '<div style="text-align:center;padding:10px;margin-bottom:12px;background:rgba(0,212,255,0.08);border:1px solid rgba(0,212,255,0.25);border-radius:10px;font-size:13px;color:var(--color-text-2);">';
            html += 'العملة المستخدمة: <strong style="color:var(--color-blue);">' + currencyLabel + '</strong>';
            html += '</div>';

            html += '<div class="info-boxes">';

            // الصندوق
            var cashCls = cash < 0 ? ' style="color:var(--color-red);"' : '';
            html += '<div class="info-box"><span>الصندوق</span><strong' + cashCls + '>' + formatCurrency(cash, baseCurrency) + '</strong></div>';

            // البنك
            var bankCls = bank < 0 ? ' style="color:var(--color-red);"' : '';
            html += '<div class="info-box"><span>البنك</span><strong' + bankCls + '>' + formatCurrency(bank, baseCurrency) + '</strong></div>';

            html += '<div class="info-box"><span>المواد الخام</span><strong>' + formatCurrency(raw, baseCurrency) + '</strong></div>';
            html += '<div class="info-box"><span>المنتجات التامة</span><strong>' + formatCurrency(finished, baseCurrency) + '</strong></div>';
            html += '<div class="info-box"><span>العملاء المرجو تحصيلهم</span><strong>' + formatCurrency(Math.max(0, receivables), baseCurrency) + '</strong></div>';
            html += '<div class="info-box"><span>وعاء الزكاة</span><strong>' + formatCurrency(total, baseCurrency) + '</strong></div>';
            html += '<div class="info-box" style="background:linear-gradient(135deg,rgba(0,214,143,0.15),rgba(0,168,107,0.08));border:2px solid rgba(0,214,143,0.4);">';
            html += '<span style="font-size:14px;">الزكاة التقديرية (' + (rate * 100).toFixed(2) + '%)</span>';
            html += '<strong style="font-size:20px;color:var(--color-green);">' + formatCurrency(zakat, baseCurrency) + '</strong>';
            html += '</div>';

            html += '</div>';
            html += '<p class="form-hint">الحساب تقديري للتنظيم، وتقييم المخزون والخصوم يحتاج اعتماد المستخدم أو المحاسب المختص.</p>';

            b.innerHTML = html;
        }

        return out;
    } catch (e) {
        console.error('Zakat error:', e);
        if (typeof showToast === 'function') showToast('خطأ في حساب الزكاة: ' + e.message, 'error');
        return null;
    }
}

function initZakat() {
    var r = document.getElementById('zakatRate');
    if (r && !r.value) r.value = '2.5';
}
// ================================================================
// ===== طباعة حساب الزكاة (القالب الجديد) =====
// ================================================================

function printZakatReport() {
    // 1. تأكد أن الحساب قد تم تنفيذه
    if (typeof calculateZakat === 'function') {
        try { calculateZakat(); } catch(e) { /* تجاهل */ }
    }

    // 2. اقرأ النتائج من zakatResult
    var resultEl = document.getElementById('zakatResult');
    if (!resultEl) {
        if (typeof showToast === 'function') showToast('لا توجد نتائج زكاة', 'error');
        return;
    }

    // 3. استخرج المعلومات من البطاقات
    var infoBoxes = resultEl.querySelectorAll('.info-box');
    var items = [];
    var zakatBase = 0;
    var zakatAmount = 0;

    infoBoxes.forEach(function(box) {
        var label = box.querySelector('span');
        var valueEl = box.querySelector('strong');
        if (!label || !valueEl) return;

        var labelText = label.textContent.trim();
        var valueText = valueEl.textContent.trim();

        // استخرج الرقم
        var num = parseFloat(valueText.replace(/[^0-9.]/g, '')) || 0;

        if (labelText.indexOf('وعاء الزكاة') !== -1) {
            zakatBase = num;
            return; // لا نُضيفه للقائمة — يُعرض منفصلاً
        }
        if (labelText.indexOf('الزكاة التقديرية') !== -1) {
            zakatAmount = num;
            return; // يُعرض في البطاقة البارزة
        }

        // بنود عادية
        items.push({ label: labelText, value: num });
    });

    // 4. العملة والنسبة
    var currencySelect = document.getElementById('zakatCurrency');
    var rateInput = document.getElementById('zakatRate');

    var currency = currencySelect ? currencySelect.value : 'SAR';
    var currencyName = currency;
    if (currencySelect && currencySelect.options.length > 0) {
        var opt = currencySelect.querySelector('option[value="' + currency + '"]');
        if (opt) currencyName = opt.textContent.trim();
    }

    var rate = rateInput ? rateInput.value : '2.5';

    // 5. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 6. الحمولة
    var payload = {
        type: 'zakat_report',
        items: items,
        settings: settings,
        meta: {
            currency: currency,
            currencyName: currencyName,
            rate: rate,
            date: new Date().toISOString().split('T')[0],
            zakatBase: zakatBase,
            zakatAmount: zakatAmount
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 7. افتح القالب
    var base = window.location.href.replace(/\/[^^\/]*$/, '/');
    var url = base + 'templates/zakat-report.html';
    window.location.href = url;
}