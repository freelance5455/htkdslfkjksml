// ================================================================
// Open Account — نظام محاسبي
// الملف: bank.js — v3 (رصيد أساسي + تفصيل عملات)
// ================================================================

var bankFrom = '';
var bankTo = '';


// ================================================================
// ===== 1. جمع حركات البنك =====
// ================================================================

function getBankTransactions() {
    var transactions = [];

    if (typeof getDirectAccountTransactions === 'function') {
        transactions = transactions.concat(getDirectAccountTransactions('bank'));
    }
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
        	if (r.cancelled || r.documentStatus === 'cancelled') return;
            var method = r.method || 'نقدي';
            if (method === 'تحويل بنكي' || method === 'بطاقة') {
                transactions.push({
                    date: r.date,
                    type: 'in',
                    desc: 'إيداع من ' + (r.customerName || '-') + ' (' + method + ')',
                    invoiceRef: r.invoiceId || '-',
                    amount: parseFloat(r.amount) || 0,
                    currency: r.currency || 'YER',
                    method: method,
                    id: r.id
                });
            }
        });
    }

    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.archived) return;
            if (p.cancelled || p.documentStatus === 'cancelled') return;
            var method = p.method || 'نقدي';
            if (method !== 'تحويل بنكي' && method !== 'بطاقة') return;

            var desc = p.isExpense
                ? 'مصروف: ' + (p.supplierName || p.expenseType || '-') + ' (' + method + ')'
                : 'دفع إلى ' + (p.supplierName || '-') + ' (' + method + ')';

            transactions.push({
                date: p.date,
                type: 'out',
                desc: desc,
                invoiceRef: p.invoiceId || '-',
                amount: parseFloat(p.amount) || 0,
                currency: p.currency || 'YER',
                method: method,
                id: p.id
            });
        });
    }

    if (typeof transfers !== 'undefined' && Array.isArray(transfers)) {
        transfers.forEach(function(t) {
            if (t.status === 'cancelled') return;
            if (t.from && t.from.accountType === 'bank') {
                transactions.push({
                    date: t.date,
                    type: 'out',
                    desc: 'تحويل إلى ' + (typeof getTransferAccountLabel === 'function' ? getTransferAccountLabel(t.to.accountType) : '-'),
                    invoiceRef: t.number,
                    amount: parseFloat(t.from.amount) || 0,
                    currency: t.from.currency || 'YER',
                    id: t.number
                });
            }
            if (t.to && t.to.accountType === 'bank') {
                transactions.push({
                    date: t.date,
                    type: 'in',
                    desc: 'تحويل من ' + (typeof getTransferAccountLabel === 'function' ? getTransferAccountLabel(t.from.accountType) : '-'),
                    invoiceRef: t.number,
                    amount: parseFloat(t.to.amount) || 0,
                    currency: t.to.currency || 'YER',
                    id: t.number
                });
            }
        });
    }

    transactions.sort(function(a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
    });

    return transactions;
}


// ================================================================
// ===== 2. حساب الإجمالي بالعملة الأساسية =====
// ================================================================

function _bankComputeBaseTotal(balances) {
    if (!balances) return 0;
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var total = 0;
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var amount = parseFloat(balances[c]) || 0;
        if (amount === 0) return;
        if (c === base) {
            total += amount;
        } else {
            var rate = (typeof getCurrentExchangeRateSnapshot === 'function')
                ? getCurrentExchangeRateSnapshot(c)
                : (typeof getRate === 'function' ? getRate(c) : 1);
            var baseRate = (typeof getRate === 'function') ? getRate(base) : 1;
            total += (amount * rate) / (baseRate || 1);
        }
    });
    return total;
}

function _formatBankMultiCurrencyBalance(balances, includeZero) {
    if (!balances) return '0.00';
    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var totalBase = _bankComputeBaseTotal(balances);
    var hasAny = false;
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if ((parseFloat(balances[c]) || 0) !== 0) hasAny = true;
    });
    if (!hasAny && !includeZero) return '0.00 ' + base;
    return formatAmountWithCommas(totalBase) + ' ' + base;
}

function _formatBankMultiCurrencyBalanceHTML(balances) {
    if (!balances) return '<span>0.00</span>';

    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var totalBase = _bankComputeBaseTotal(balances);

    var primaryColor = totalBase >= 0 ? 'var(--color-green)' : 'var(--color-red)';
    var html = '<div style="font-weight:800;color:' + primaryColor + ';font-size:14px;">' +
                   formatAmountWithCommas(totalBase) + ' ' + base +
               '</div>';

    var details = [];
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var amount = parseFloat(balances[c]) || 0;
        if (amount !== 0) {
            var color = amount > 0 ? 'var(--color-green)' : 'var(--color-red)';
            details.push('<span style="color:' + color + ';font-weight:600;font-size:11px;">' +
                         formatAmountWithCommas(amount) + ' ' + c + '</span>');
        }
    });

    if (details.length > 1) {
        html += '<div style="font-size:10px;color:var(--color-text-3);margin-top:2px;">' +
                    '(' + details.join(' + ') + ')' +
                '</div>';
    } else if (details.length === 1) {
        html += '<div style="font-size:10px;color:var(--color-text-3);margin-top:2px;">' +
                    details[0] +
                '</div>';
    }

    return html;
}


// ================================================================
// ===== 3. عرض شاشة البنك =====
// ================================================================

function renderBank() {
    var tbody = document.getElementById('bankTableBody');
    if (!tbody) return;

    var fromEl = document.getElementById('bankFrom');
    var toEl = document.getElementById('bankTo');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    bankFrom = from;
    bankTo = to;

    var allTransactions = getBankTransactions();

    var filtered = allTransactions.filter(function(t) {
        if (from && t.date < from) return false;
        if (to && t.date > to) return false;
        return true;
    });

    var balances = {};
    var totalIn = {};
    var totalOut = {};
    var openingBalances = {};

    if (from) {
        allTransactions.forEach(function(t) {
            if (t.date < from) {
                var c = t.currency || 'YER';
                openingBalances[c] = (openingBalances[c] || 0);
                if (t.type === 'in') openingBalances[c] += t.amount;
                else openingBalances[c] -= t.amount;
            }
        });
    }

    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if (openingBalances[c]) balances[c] = openingBalances[c];
    });

    filtered.forEach(function(t) {
        var c = t.currency || 'YER';
        if (!balances[c]) balances[c] = 0;
        if (!totalIn[c]) totalIn[c] = 0;
        if (!totalOut[c]) totalOut[c] = 0;

        if (t.type === 'in') {
            balances[c] += t.amount;
            totalIn[c] += t.amount;
        } else {
            balances[c] -= t.amount;
            totalOut[c] += t.amount;
        }
    });

    var html = '';

    if (from) {
        var openingParts = [];
        ['YER', 'SAR', 'USD'].forEach(function(c) {
            if (openingBalances[c]) {
                var color = openingBalances[c] > 0 ? 'var(--color-green)' : 'var(--color-red)';
                openingParts.push('<span style="color:' + color + ';font-weight:700;">' +
                                  formatAmountWithCommas(openingBalances[c]) + ' ' + c + '</span>');
            }
        });

        if (openingParts.length) {
            html += '<tr style="background:rgba(0,212,255,0.08);font-weight:bold;">' +
                '<td>—</td>' +
                '<td>—</td>' +
                '<td style="text-align:right;padding-right:12px;">رصيد أول المدة</td>' +
                '<td>—</td>' +
                '<td>—</td>' +
                '<td>' + openingParts.join(' | ') + '</td>' +
            '</tr>';
        }
    }

    var runningBalances = {};
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if (openingBalances[c]) runningBalances[c] = openingBalances[c];
    });

    filtered.forEach(function(t, i) {
        var c = t.currency || 'YER';

        if (!runningBalances[c]) runningBalances[c] = 0;
        if (t.type === 'in') runningBalances[c] += t.amount;
        else runningBalances[c] -= t.amount;

        var inAmount = t.type === 'in'
            ? '<span style="color:var(--color-green);font-weight:600;">' + formatAmountWithCommas(t.amount) + ' ' + c + '</span>'
            : '—';
        var outAmount = t.type === 'out'
            ? '<span style="color:var(--color-red);font-weight:600;">' + formatAmountWithCommas(t.amount) + ' ' + c + '</span>'
            : '—';

        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + formatDate(t.date) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(t.desc) + '</td>' +
            '<td>' + inAmount + '</td>' +
            '<td>' + outAmount + '</td>' +
            '<td style="font-weight:700;">' + _formatBankMultiCurrencyBalanceHTML(runningBalances) + '</td>' +
        '</tr>';
    });

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">لا توجد حركات بنكية في هذه الفترة</td></tr>';
    } else {
        tbody.innerHTML = html;
    }

    setText('bankBalance', _formatBankMultiCurrencyBalance(balances));
    setText('bankTotalIn', _formatBankMultiCurrencyBalance(totalIn));
    setText('bankTotalOut', _formatBankMultiCurrencyBalance(totalOut));

    var dateEl = document.getElementById('bankDate');
    if (dateEl) dateEl.textContent = todayArabic();
}


// ================================================================
// ===== 4. تهيئة البنك =====
// ================================================================

function initBank() {
    var fromEl = document.getElementById('bankFrom');
    var toEl = document.getElementById('bankTo');

    if (fromEl && !fromEl.value) fromEl.value = firstDayOfMonthISO();
    if (toEl && !toEl.value) toEl.value = todayISO();

    var refreshBtn = document.getElementById('bankRefresh');
    if (refreshBtn) refreshBtn.addEventListener('click', renderBank);

    renderBank();
    console.log('Bank: initialized');
}
// ================================================================
// ===== طباعة كشف البنك (القالب الجديد) =====
// ================================================================

function printBankStatement() {
    var fromEl = document.getElementById('bankFrom');
    var toEl = document.getElementById('bankTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    var tbody = document.getElementById('bankTableBody');
    if (!tbody) {
        if (typeof showToast === 'function') showToast('لم يتم العثور على جدول البنك', 'error');
        return;
    }

    var table = tbody.closest('table');
    if (!table) {
        if (typeof showToast === 'function') showToast('الجدول غير موجود', 'error');
        return;
    }

    var tableHtml = table.outerHTML;
    var count = tbody.querySelectorAll('tr').length;

    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    var payload = {
        type: 'bank_statement',
        tableHtml: tableHtml,
        settings: settings,
        meta: {
            from: from || '—',
            to: to || '—',
            count: count
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/bank-statement.html';
    window.location.href = url;
}


// ================================================================
// ===== END OF BANK.JS =====
// ================================================================