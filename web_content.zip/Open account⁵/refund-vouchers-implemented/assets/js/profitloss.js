// ================================================================
// Open Account — نظام محاسبي
// الملف: profitloss.js
// الوصف: قائمة الأرباح والخسائر (قائمة الدخل المبسطة)
// النسخة: v2 — مع العملة الأساسية والتحذيرات
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var profitlossFrom = '';
var profitlossTo = '';

// ================================================================
// ===== 1-b. دوال تجميع القيود =====
// ================================================================

function _plJournalEntriesInPeriod(from, to) {
    var entries = [];
    if (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries) && journalEntries.length > 0) {
        entries = journalEntries;
    } else if (typeof Storage !== 'undefined' && typeof JOURNAL_KEY !== 'undefined') {
        // fallback: اقرأ من Storage مباشرة
        entries = Storage.get(JOURNAL_KEY, []);
        if (!Array.isArray(entries)) entries = [];
    }
    
    return entries.filter(function(entry) {
        if (entry.status && entry.status !== 'posted') return false;
        var date = String(entry.date || '');
        if (from && date < from) return false;
        if (to && date > to) return false;
        return true;
    });
}

function _pAccountNet(entries, accountCode) {
    var total = 0;
    entries.forEach(function(entry) {
        (entry.lines || []).forEach(function(line) {
            if (line.accountCode !== accountCode) return;
            var debitBase = line.debitBase !== undefined
                ? parseFloat(line.debitBase) || 0
                : parseFloat(line.debit) || 0;
            var creditBase = line.creditBase !== undefined
                ? parseFloat(line.creditBase) || 0
                : parseFloat(line.credit) || 0;
            total += debitBase - creditBase;
        });
    });
    return total;
}

function _pAccountCreditNet(entries, accountCode) {
    var total = 0;
    entries.forEach(function(entry) {
        (entry.lines || []).forEach(function(line) {
            if (line.accountCode !== accountCode) return;
            var debitBase = line.debitBase !== undefined
                ? parseFloat(line.debitBase) || 0
                : parseFloat(line.debit) || 0;
            var creditBase = line.creditBase !== undefined
                ? parseFloat(line.creditBase) || 0
                : parseFloat(line.credit) || 0;
            total += creditBase - debitBase;
        });
    });
    return total;
}


// ================================================================
// ===== 2. حساب الأرباح والخسائر =====
// ================================================================

/**
 * حساب قائمة الدخل للفترة المحددة
 * جميع الأرقام بالعملة الأساسية
 */
function calculateProfitLoss(from, to) {
    var baseCurrency = getBaseCurrency();

    var cogsRepair = typeof recalculateIncompleteSalesCOGS === 'function'
        ? recalculateIncompleteSalesCOGS()
        : { repaired: 0, missing: [], estimated: 0 };

    var result = {
        baseCurrency: baseCurrency,

        // الإيرادات
        salesTotal: 0,
        salesReturnsTotal: 0,
        salesCount: 0,

        // تكلفة البضاعة المباعة
        cogsTotal: 0,
        cogsKnown: true,
        cogsEstimated: false,
        cogsMissingCount: 0,
        cogsMissing: cogsRepair.missing || [],

        // المشتريات الفعلية
        purchasesTotal: 0,
        purchaseReturnsTotal: 0,
        purchaseCount: 0,

        // إجمالي الربح
        grossProfit: 0,

        // المصاريف
        expensesTotal: 0,
        expensesCount: 0,

        // صافي الربح
        netProfit: 0,
          // صافي الربح
netProfit: 0,

// فروقات العملة (4200 + 7000)
fxGains: 0,
fxLosses: 0,
netFx: 0,
        // القبض والصرف
        receiptsTotal: 0,
        paymentsTotal: 0,
        cashFlow: 0,

        // الذمم
        receivables: 0,
        payables: 0,

        // تفصيل بالعملات (للعرض التفصيلي)
        salesByCurrency: {},
        receiptsByCurrency: {},
        paymentsByCurrency: {},
        expensesByCurrency: {},
        otherRevenueTotal: 0
    };

    // ===== 1. المبيعات =====
    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
        salesInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function(inv) {
            var date = inv.date || '';
            if (from && date < from) return;
            if (to && date > to) return;

            var total = parseFloat(inv.total) || 0;
            var c = inv.currency || 'YER';

            // تفصيل بالعملة
            result.salesByCurrency[c] = (result.salesByCurrency[c] || 0) + total;

            // تحويل للعملة الأساسية
            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                ? getEquivalentAtRate(total, c, inv.exchangeRate)
                : total;

            result.salesTotal += converted;
            result.salesCount++;
        });
    }

    // ===== 1.5. مردودات المبيعات =====
if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
    returnsDocs.forEach(function(ret) {
        if (ret.kind !== 'sale') return;
        if (ret.cancelled === true || ret.documentStatus === 'cancelled') return;
            var date = ret.date || '';
            if (from && date < from) return;
            if (to && date > to) return;
            var amount = parseFloat(ret.amount) || 0;
            var c = ret.currency || 'YER';
            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function') ? getEquivalentAtRate(amount, c, ret.exchangeRate) : amount;
            result.salesTotal -= converted;
            result.salesReturnsTotal += converted;
        });
    }

    // ===== 2. المشتريات =====
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
        purchaseInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function(inv) {
            var date = inv.date || '';
            if (from && date < from) return;
            if (to && date > to) return;

            var total = parseFloat(inv.total) || 0;
            var c = inv.currency || 'YER';

            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                ? getEquivalentAtRate(total, c, inv.exchangeRate)
                : total;

            result.purchasesTotal += converted;
            result.purchaseCount++;
        });
    }

  // ===== 2.5. مردودات المشتريات =====
if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
    returnsDocs.forEach(function(ret) {
        if (ret.kind !== 'purchase') return;
        if (ret.cancelled === true || ret.documentStatus === 'cancelled') return;
            var date = ret.date || '';
            if (from && date < from) return;
            if (to && date > to) return;
            var amount = parseFloat(ret.amount) || 0;
            var c = ret.currency || 'YER';
            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function') ? getEquivalentAtRate(amount, c, ret.exchangeRate) : amount;
            result.purchasesTotal -= converted;
            result.purchaseReturnsTotal += converted;
        });
    }

    // ===== 3. COGS =====
    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
        salesInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function(inv) {
            var date = inv.date || '';
            if (from && date < from) return;
            if (to && date > to) return;

            if (inv.cogsKnown !== true) {
                result.cogsKnown = false;
                result.cogsMissingCount++;
                return;
            }

            if (inv.cogsEstimated) result.cogsEstimated = true;

            var cogs = parseFloat(inv.cogsTotal) || 0;
            var c = inv.currency || 'YER';

            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                ? getEquivalentAtRate(cogs, c, inv.exchangeRate)
                : cogs;

            result.cogsTotal += converted;
        });
    }

  // خصم تكلفة البضاعة التي عادت للمخزون بسبب مرتجعات المبيعات
if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
    returnsDocs.forEach(function(ret) {
        if (ret.kind !== 'sale') return;
        if (ret.cancelled === true || ret.documentStatus === 'cancelled') return;
            var date = ret.date || '';
            if (from && date < from) return;
            if (to && date > to) return;
            var cogs = parseFloat(ret.cogsAmount) || 0;
            var c = ret.currency || 'YER';
            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function') ? getEquivalentAtRate(cogs, c, ret.exchangeRate) : cogs;
            result.cogsTotal -= converted;
        });
    }

    // ===== 4. المصاريف =====
    if (typeof expenses !== 'undefined' && Array.isArray(expenses)) {
        expenses.forEach(function(e) {
            if (e.archived) return;
            if (e.cancelled === true || e.documentStatus === 'cancelled') return;

            var date = e.date || '';
            if (from && date < from) return;
            if (to && date > to) return;

            var amount = parseFloat(e.amount) || 0;
            var c = e.currency || 'YER';

            result.expensesByCurrency[c] = (result.expensesByCurrency[c] || 0) + amount;

            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                ? getEquivalentAtRate(amount, c, e.exchangeRate)
                : amount;

            result.expensesTotal += converted;
            result.expensesCount++;
        });
    }

    // ===== 5. سندات القبض =====
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
        	if (r.cancelled === true || r.documentStatus === 'cancelled' || r.sourceStatus === 'cancelled') return;
            var date = r.date || '';
            if (from && date < from) return;
            if (to && date > to) return;

            var amount = parseFloat(r.amount) || 0;
            var c = r.currency || 'YER';

            result.receiptsByCurrency[c] = (result.receiptsByCurrency[c] || 0) + amount;

            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                ? getEquivalentAtRate(amount, c, r.exchangeRate)
                : amount;

            result.receiptsTotal += converted;
        });
    }

    // ===== 6. سندات الصرف =====
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.archived) return;
             if (p.cancelled === true || p.documentStatus === 'cancelled' || p.sourceStatus === 'cancelled') return;
            var date = p.date || '';
            if (from && date < from) return;
            if (to && date > to) return;

            var amount = parseFloat(p.amount) || 0;
            var c = p.currency || 'YER';

            result.paymentsByCurrency[c] = (result.paymentsByCurrency[c] || 0) + amount;

            var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                ? getEquivalentAtRate(amount, c, p.exchangeRate)
                : amount;

            result.paymentsTotal += converted;
        });
    }

    // ===== 7. الإيرادات الأخرى =====
    if (typeof directTransactions !== 'undefined' && Array.isArray(directTransactions)) {
        directTransactions.forEach(function(d) {
            if (d.direction !== 'in') return;
            var date = d.date || '';
            if (from && date < from) return;
            if (to && date > to) return;
            if (d.type !== 'بيع مستهلكات / خردة' && d.type !== 'إيرادات متنوعة') return;
            var amount = parseFloat(d.amount) || 0, c = d.currency || 'YER';
            result.otherRevenueTotal += (c !== baseCurrency && typeof getEquivalentAtRate === 'function') ? getEquivalentAtRate(amount, c, d.exchangeRate) : amount;
        });
    }
// ===== 7-b. الحساب الرسمي من القيود =====
var officialEntries = _plJournalEntriesInPeriod(from, to);
var officialSales = _pAccountCreditNet(officialEntries, '4000');
var officialSalesReturns = _pAccountNet(officialEntries, '4010');
var officialCOGS = _pAccountNet(officialEntries, '5000');
var officialExpenses = _pAccountNet(officialEntries, '6000');
var officialOtherRevenue = _pAccountCreditNet(officialEntries, '4100');
var officialFXGains = _pAccountCreditNet(officialEntries, '4200');
var officialFXLosses = _pAccountNet(officialEntries, '7000');

result.salesTotal = officialSales - officialSalesReturns;
result.salesReturnsTotal = officialSalesReturns;
result.cogsTotal = officialCOGS;
result.expensesTotal = officialExpenses;
result.otherRevenueTotal = officialOtherRevenue;
result.fxGains = officialFXGains;
result.fxLosses = officialFXLosses;
result.netFx = officialFXGains - officialFXLosses;


    // ===== 8. الحسابات =====
    result.grossProfit = result.cogsKnown
        ? result.salesTotal - result.cogsTotal
        : null;

    result.netProfit = result.grossProfit === null
    ? null
    : result.grossProfit + result.otherRevenueTotal + result.netFx - result.expensesTotal;

    result.cashFlow = result.receiptsTotal - result.paymentsTotal;

    // ===== 8. الذمم (غير مرتبطة بالفترة) =====
    // ===== 8. الذمم (من المصدر الموحد getInvoiceOutstanding) =====

    // ===== الذمم: لك عند العملاء =====
    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)
        && typeof getInvoiceOutstanding === 'function') {
        salesInvoices
            .filter(function(inv){ return inv.status !== 'ملغاة' && !inv.cancelled; })
            .forEach(function(inv) {
                var o = getInvoiceOutstanding(inv.id, 'sale');
                if (!o || o.outstanding <= 0.01) return;

                var c = inv.currency || 'YER';
                var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                    ? getEquivalentAtRate(o.outstanding, c, inv.exchangeRate)
                    : o.outstanding;

                result.receivables += converted;
            });
    }

    // ===== الذمم: عليك للموردين =====
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)
        && typeof getInvoiceOutstanding === 'function') {
        purchaseInvoices
            .filter(function(inv){ return inv.status !== 'ملغاة' && !inv.cancelled; })
            .forEach(function(inv) {
                var o = getInvoiceOutstanding(inv.id, 'purchase');
                if (!o || o.outstanding <= 0.01) return;

                var c = inv.currency || 'YER';
                var converted = (c !== baseCurrency && typeof getEquivalentAtRate === 'function')
                    ? getEquivalentAtRate(o.outstanding, c, inv.exchangeRate)
                    : o.outstanding;

                result.payables += converted;
            });
    }

    return result;
}


// ================================================================
// ===== 3. عرض شاشة الأرباح والخسائر =====
// ================================================================

function renderProfitLoss() {
    var fromEl = document.getElementById('profitlossFrom');
    var toEl = document.getElementById('profitlossTo');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    profitlossFrom = from;
    profitlossTo = to;

    var data = calculateProfitLoss(from, to);
    var baseCurrency = data.baseCurrency;

    // ===== بطاقات الإحصائيات =====
    setText('plSales', formatAmountWithCommas(data.salesTotal));
    setText('plPurchases', formatAmountWithCommas(data.purchasesTotal));
    setText('plGrossProfit', data.grossProfit === null ? 'غير مكتمل' : formatAmountWithCommas(data.grossProfit));
    setText('plCogs', data.cogsKnown
        ? (data.cogsEstimated ? '⚠ ' + formatAmountWithCommas(data.cogsTotal) : formatAmountWithCommas(data.cogsTotal))
        : 'غير مكتمل');
    setText('plExpenses', formatAmountWithCommas(data.expensesTotal));
    setText('plNetProfit', data.netProfit === null ? 'غير مكتمل' : formatAmountWithCommas(data.netProfit));
    setText('plCashFlow', formatAmountWithCommas(data.cashFlow));
    setText('plReceivables', formatAmountWithCommas(data.receivables));
    setText('plPayables', formatAmountWithCommas(data.payables));

    // ===== الألوان =====
    var grossEl = document.getElementById('plGrossProfit');
    if (grossEl) grossEl.style.color = data.grossProfit === null
        ? 'var(--color-text)'
        : (data.grossProfit >= 0 ? 'var(--color-green)' : 'var(--color-red)');

    var netEl = document.getElementById('plNetProfit');
    if (netEl) netEl.style.color = data.netProfit === null
        ? 'var(--color-text)'
        : (data.netProfit >= 0 ? 'var(--color-green)' : 'var(--color-red)');

    var cashFlowEl = document.getElementById('plCashFlow');
    if (cashFlowEl) cashFlowEl.style.color = data.cashFlow >= 0 ? 'var(--color-green)' : 'var(--color-red)';

    // ===== جدول قائمة الدخل =====
    _renderPLStatement(data, baseCurrency);

    // ===== تاريخ =====
    var dateEl = document.getElementById('profitlossDate');
    if (dateEl) dateEl.textContent = todayArabic();
}


// ================================================================
// ===== 4. بناء قائمة الدخل التفصيلية =====
// ================================================================

function _renderPLStatement(data, currency) {
    var container = document.getElementById('plStatement');
    if (!container) return;

    // ===== التحذيرات =====
    var warningHtml = '';
    if (!data.cogsKnown) {
        warningHtml = '<div class="info-message" style="margin-bottom:12px;text-align:right;line-height:1.8;border-color:var(--color-red);background:rgba(255,71,87,0.08);">' +
            '<strong style="color:var(--color-red);">⚠ حساب COGS غير مكتمل.</strong><br>' +
            'الفواتير بلا تكلفة: ' + data.cogsMissingCount +
            (data.cogsMissing.length ? '<br>الأرقام: ' + data.cogsMissing.slice(0, 5).map(function(x) { return esc(x.id); }).join('، ') + (data.cogsMissing.length > 5 ? ' و' + (data.cogsMissing.length - 5) + ' أخرى' : '') : '') +
            '<br>لا يتم تخمين التكلفة، لذلك يبقى الربح غير مكتمل.' +
        '</div>';
    } else if (data.cogsEstimated) {
        warningHtml = '<div class="info-message" style="margin-bottom:12px;text-align:right;line-height:1.8;border-color:var(--color-gold);background:rgba(247,147,30,0.08);">' +
            '<strong style="color:var(--color-gold);">⚠ بعض الفواتير تستخدم تكلفة تقديرية.</strong><br>' +
            'التقدير يعتمد على 70% من سعر البيع للمنتجات التي لا توجد لها تكلفة محددة.<br>' +
            'للدقة الكاملة، أدخل التكلفة اليدوية من شاشة المنتجات.' +
        '</div>';
    } else {
        warningHtml = '<div class="info-message" style="margin-bottom:12px;text-align:right;line-height:1.8;border-color:var(--color-green);background:rgba(0,214,143,0.08);">' +
            '<strong style="color:var(--color-green);">✅ تم استخدام COGS من التكاليف الفعلية.</strong>' +
        '</div>';
    }

    // ===== العملات المستخدمة =====
    var usedCurrencies = {};
    ['salesByCurrency', 'receiptsByCurrency', 'paymentsByCurrency', 'expensesByCurrency'].forEach(function(k) {
        if (data[k]) {
            Object.keys(data[k]).forEach(function(c) {
                if (Math.abs(data[k][c]) > 0.0001) usedCurrencies[c] = true;
            });
        }
    });
    var currencyKeys = Object.keys(usedCurrencies);

    var currenciesHtml = '';
    if (currencyKeys.length > 1) {
        currenciesHtml = '<div class="pl-section">' +
            '<div class="pl-section-title">تفصيل بالعملات الأصلية</div>';

        currencyKeys.forEach(function(c) {
            var sales = (data.salesByCurrency[c] || 0);
            var receipts = (data.receiptsByCurrency[c] || 0);
            var payments = (data.paymentsByCurrency[c] || 0);
            var expenses = (data.expensesByCurrency[c] || 0);

            if (sales || receipts || payments || expenses) {
                currenciesHtml += '<div class="pl-row"><span>' + c + ' — مبيعات</span><span>' + formatCurrency(sales, c) + '</span></div>';
                if (receipts) currenciesHtml += '<div class="pl-row"><span>' + c + ' — قبض</span><span style="color:var(--color-green);">' + formatCurrency(receipts, c) + '</span></div>';
                if (payments) currenciesHtml += '<div class="pl-row"><span>' + c + ' — صرف</span><span style="color:var(--color-red);">' + formatCurrency(payments, c) + '</span></div>';
                if (expenses) currenciesHtml += '<div class="pl-row"><span>' + c + ' — مصاريف</span><span style="color:var(--color-red);">' + formatCurrency(expenses, c) + '</span></div>';
            }
        });

        currenciesHtml += '</div>';
    }

    var html = warningHtml +
        '<div class="pl-section">' +
            '<div class="pl-section-title">الإيرادات</div>' +
            '<div class="pl-row">' +
                '<span>المبيعات (' + data.salesCount + ' فاتورة)</span>' +
                '<span>' + formatCurrency(data.salesTotal, currency) + '</span>' +
            '</div>' +
            '<div class="pl-row total">' +
                '<span>إجمالي الإيرادات</span>' +
                '<span>' + formatCurrency(data.salesTotal, currency) + '</span>' +
            '</div>' +
        '</div>' +

        '<div class="pl-section">' +
            '<div class="pl-section-title">تكلفة البضاعة المباعة COGS</div>' +
            '<div class="pl-row">' +
                '<span>التكلفة المحسوبة من فواتير البيع</span>' +
                '<span>' + (data.cogsKnown ? (data.cogsEstimated ? '⚠ ' : '') + formatCurrency(data.cogsTotal, currency) : 'غير مكتمل') + '</span>' +
            '</div>' +
            '<div class="pl-row">' +
                '<span>المشتريات خلال الفترة (' + data.purchaseCount + ' فاتورة)</span>' +
                '<span>' + formatCurrency(data.purchasesTotal, currency) + '</span>' +
            '</div>' +
        '</div>' +

        '<div class="pl-section highlight">' +
            '<div class="pl-row big">' +
                '<span>مجمل الربح <small>(المبيعات − COGS)</small></span>' +
                '<span style="color:var(--color-text);">' +
                    (data.grossProfit === null ? 'غير مكتمل' : formatCurrency(data.grossProfit, currency)) +
                '</span>' +
            '</div>' +
        '</div>' +

      '<div class="pl-section">' +
    '<div class="pl-section-title">المصاريف التشغيلية</div>' +
    '<div class="pl-row">' +
        '<span>المصاريف (' + data.expensesCount + ' بند)</span>' +
        '<span>' + formatCurrency(data.expensesTotal, currency) + '</span>' +
    '</div>' +
    '<div class="pl-row total">' +
        '<span>إجمالي المصاريف</span>' +
        '<span>' + formatCurrency(data.expensesTotal, currency) + '</span>' +
    '</div>' +
'</div>' +

// ===== فروقات العملة (4200 + 7000) =====
((data.fxGains || data.fxLosses) ?
    '<div class="pl-section">' +
        '<div class="pl-section-title">فروقات العملة</div>' +
        (data.fxGains ?
            '<div class="pl-row">' +
                '<span>أرباح فروقات العملة</span>' +
                '<span style="color:var(--color-green);">' + formatCurrency(data.fxGains, currency) + '</span>' +
            '</div>' : '') +
        (data.fxLosses ?
            '<div class="pl-row">' +
                '<span>خسائر فروقات العملة</span>' +
                '<span style="color:var(--color-red);">' + formatCurrency(data.fxLosses, currency) + '</span>' +
            '</div>' : '') +
        '<div class="pl-row total">' +
            '<span>صافي فروقات العملة</span>' +
            '<span style="color:' + ((data.netFx || 0) >= 0 ? 'var(--color-green)' : 'var(--color-red)') + ';">' +
                formatCurrency(data.netFx || 0, currency) +
            '</span>' +
        '</div>' +
    '</div>' 
    : '') +

'<div class="pl-section highlight">' +
    '<div class="pl-row big">' +
        '<span>صافي الربح المحاسبي</span>' +
        '<span style="color:var(--text-color);">' +
            (data.netProfit === null ? 'غير مكتمل' : formatCurrency(data.netProfit, currency)) +
        '</span>' +
    '</div>' +
'</div>' +

      '<div class="pl-section">' +
    '<div class="pl-section-title">صافي التدفق النقدي</div>' +
    '<div class="pl-row big">' +
        '<span>صافي التدفق</span>' +
        '<span class="' + (data.cashFlow >= 0 ? 'balance-positive' : 'balance-negative') + '">' +
            formatCurrency(data.cashFlow, currency) +
        '</span>' +
    '</div>' +
    '<div style="text-align:center;padding:10px;margin-top:8px;background:rgba(0,212,255,0.06);border-radius:8px;font-size:11px;color:var(--color-text-3);">' +
        '💡 للتفاصيل الكاملة والتدفقات الداخلة والخارجة، افتح:<br>' +
        '<strong style="color:var(--color-blue);">التقارير ← التدفق النقدي</strong>' +
    '</div>' +
'</div>' +

        '<div class="pl-section">' +
            '<div class="pl-section-title">الذمم</div>' +
            '<div class="pl-row">' +
                '<span>لك عند العملاء</span>' +
                '<span style="color:var(--color-green);">' + formatCurrency(data.receivables, currency) + '</span>' +
            '</div>' +
            '<div class="pl-row">' +
                '<span>عليك للموردين</span>' +
                '<span style="color:var(--color-red);">' + formatCurrency(data.payables, currency) + '</span>' +
            '</div>' +
        '</div>' +

        currenciesHtml;

    container.innerHTML = html;
}


// ================================================================
// ===== 5. تهيئة =====
// ================================================================

function initProfitLoss() {
    var fromEl = document.getElementById('profitlossFrom');
    var toEl = document.getElementById('profitlossTo');

    if (fromEl && !fromEl.value) fromEl.value = firstDayOfMonthISO();
    if (toEl && !toEl.value) toEl.value = todayISO();

    var refreshBtn = document.getElementById('profitlossRefresh');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', renderProfitLoss);
    }

    renderProfitLoss();

    console.log('ProfitLoss: initialized');
}

// ================================================================
// ===== 6. طباعة تقرير الأرباح والخسائر (القالب الجديد) =====
// ================================================================

function printProfitLoss() {
    // 1. اقرأ الفلاتر
    var fromEl = document.getElementById('profitlossFrom');
    var toEl = document.getElementById('profitlossTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    // 2. احسب البيانات
    var data = calculateProfitLoss(from, to);

    // 3. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 4. الحمولة
    var payload = {
        type: 'profitloss_report',
        data: data,
        settings: settings,
        meta: {
            from: from || 'البداية',
            to: to || 'اليوم',
            currency: data.baseCurrency || 'SAR'
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 5. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/profitloss-report.html';
    window.location.href = url;
}
// ================================================================
// ===== END OF PROFITLOSS.JS =====
// ================================================================