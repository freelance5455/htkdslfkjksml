// ================================================================
// Open Account — المرتجعات (v5 — دعم زر التحصيل لمرتجعات المشتريات)
// الفاتورة الأصلية لا تُعدَّل — يُنشأ سند مرتجع جديد
// ================================================================

var returnsDocs = [];
var currentReturnsFilter = 'sale';

var _archiveReturnsMode = false;
var _showArchivedReturns = false;
var _selectedReturnsForArchive = {};


// ================================================================
// تحميل وحفظ
// ================================================================

function loadReturns() {
    returnsDocs = Storage.get(STORAGE_KEYS.RETURNS, []);
    if (!Array.isArray(returnsDocs)) returnsDocs = [];
}

function saveReturns() {
    Storage.set(STORAGE_KEYS.RETURNS, returnsDocs);
}


// ================================================================
// عرض جدول المرتجعات
// ================================================================

function renderReturns() {
    var b = document.getElementById('returnsTableBody');
    if (!b) return;

    var filtered = returnsDocs.filter(function(x) {
        return x.kind === currentReturnsFilter;
    });

    filtered = filtered.filter(function(x) {
        if (_showArchivedReturns) return x.archived === true;
        return x.archived !== true;
    });

    if (!filtered.length) {
        var msg = currentReturnsFilter === 'sale'
            ? (_showArchivedReturns ? 'لا توجد مرتجعات مبيعات مؤرشفة' : 'لا توجد مرتجعات مبيعات')
            : (_showArchivedReturns ? 'لا توجد مرتجعات مشتريات مؤرشفة' : 'لا توجد مرتجعات مشتريات');
        b.innerHTML = '<tr><td colspan="9" class="empty-cell">' + msg + '</td></tr>';
        _renderReturnsArchiveToolbar();
        return;
    }

    b.innerHTML = filtered.slice().reverse().map(function(x, i) {
        var _isCancelled = x.cancelled === true || x.documentStatus === 'cancelled';
        var _rowStyle = _isCancelled ? 'opacity:0.5;text-decoration:line-through;' : '';
        var _statusBadge = _isCancelled
            ? ' <span style="background:#888;color:#fff;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;">ملغى</span>'
            : '';

        var firstCell = (i + 1);
        if (_archiveReturnsMode && !_showArchivedReturns && !_isCancelled) {
            var checked = _selectedReturnsForArchive[x.id] ? 'checked' : '';
            firstCell = '<input type="checkbox" class="ret-archive-cb" data-id="' + x.id + '" ' + checked + ' onchange="onReturnsArchiveCheckboxChange(this)">';
        }

        var actionsHtml = '';
        if (_showArchivedReturns) {
            actionsHtml =
                '<button class="btn-edit" onclick="restoreReturn(\'' + x.id + '\')" title="استرجاع">' +
                    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>' +
                '</button>';
        } else if (!_archiveReturnsMode) {
            actionsHtml =
                '<button class="btn-view" onclick="viewReturn(\'' + x.id + '\')" title="معاينة">' +
                    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;">' +
                        '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>' +
                        '<circle cx="12" cy="12" r="3"/>' +
                    '</svg>' +
                '</button>';

            // زر التحصيل — لمرتجعات المشتريات النشطة فقط
            if (!_isCancelled && x.kind === 'purchase') {
                var _hasRefund = (typeof receipts !== 'undefined')
                    && receipts.some(function(r) {
                        return r
                            && r.receiptType === 'supplier_refund'
                            && r.returnId === x.id
                            && !r.cancelled
                            && r.documentStatus !== 'cancelled';
                    });
                if (!_hasRefund) {
                    actionsHtml +=
                        '<button class="btn-primary" onclick="event.stopPropagation();_openRefundForReturn(\'' + x.id + '\')" title="تحصيل" style="width:32px;height:32px;border-radius:8px;background:#1f6feb;color:#fff;border:none;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;padding:0;margin:0 4px;font-size:14px;">💰</button>';
                }
            }

            if (!_isCancelled) {
                actionsHtml +=
                    '<button class="btn-delete" onclick="cancelReturn(\'' + x.id + '\')" title="إلغاء المرتجع">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px;">' +
                            '<path d="M18 6L6 18M6 6l12 12"/>' +
                        '</svg>' +
                    '</button>';
            }
        }

        // سند الرد المرتبط — تحقق مزدوج
        var refundCell = '—';
        var linkedRefundId = null;
        var linkedRefundKind = null;

        // 1. رد لعميل (مباشر — تحقق مزدوج)
        if (x.refundPaymentId && typeof payments !== 'undefined') {
            var candidatePay = payments.find(function(p) {
                return p && p.id === x.refundPaymentId;
            });
            if (candidatePay
                && candidatePay.paymentType === 'customer_refund'
                && candidatePay.returnId === x.id
                && candidatePay.cancelled !== true
                && candidatePay.documentStatus !== 'cancelled') {
                linkedRefundId = candidatePay.id;
                linkedRefundKind = 'payment';
            }
        }

        // 2. تحصيل من مورد (مباشر — تحقق مزدوج)
        if (!linkedRefundId && x.refundReceiptId && typeof receipts !== 'undefined') {
            var candidateRec = receipts.find(function(rec) {
                return rec && rec.id === x.refundReceiptId;
            });
            if (candidateRec
                && candidateRec.receiptType === 'supplier_refund'
                && candidateRec.returnId === x.id
                && candidateRec.cancelled !== true
                && candidateRec.documentStatus !== 'cancelled') {
                linkedRefundId = candidateRec.id;
                linkedRefundKind = 'receipt';
            }
        }

        // 3. البحث الاحتياطي — فقط إذا كان returnId مطابقاً
        if (!linkedRefundId) {
            if (x.kind === 'sale' && typeof payments !== 'undefined') {
                var rp = payments.find(function(p) {
                    return p
                        && p.paymentType === 'customer_refund'
                        && p.returnId === x.id
                        && p.cancelled !== true
                        && p.documentStatus !== 'cancelled';
                });
                if (rp) { linkedRefundId = rp.id; linkedRefundKind = 'payment'; }
            } else if (x.kind === 'purchase' && typeof receipts !== 'undefined') {
                var rr = receipts.find(function(rec) {
                    return rec
                        && rec.receiptType === 'supplier_refund'
                        && rec.returnId === x.id
                        && rec.cancelled !== true
                        && rec.documentStatus !== 'cancelled';
                });
                if (rr) { linkedRefundId = rr.id; linkedRefundKind = 'receipt'; }
            }
        }

        if (linkedRefundId) {
            refundCell = '<a href="javascript:void(0)" onclick="event.stopPropagation();_openLinkedRefund(\'' + esc(linkedRefundId) + '\',\'' + linkedRefundKind + '\')" style="color:var(--color-blue);font-weight:700;text-decoration:underline;">' + esc(linkedRefundId) + ' ↗</a>';
        }

        return '<tr style="' + _rowStyle + '">' +
            '<td>' + firstCell + '</td>' +
            '<td>' + formatDate(x.date) + '</td>' +
            '<td><strong style="font-size:10px;letter-spacing:-0.5px;" title="' + esc(x.id) + '">' +
                esc(String(x.id).replace(/^RET-/, '')) + _statusBadge +
            '</strong></td>' +
            '<td>' + esc(x.invoiceId) + '</td>' +
            '<td>' + esc(x.productName) + '</td>' +
            '<td>' + x.qty + '</td>' +
            '<td>' + formatCurrency(x.amount, x.currency) + '</td>' +
            '<td>' + refundCell + '</td>' +
            '<td>' + actionsHtml + '</td>' +
        '</tr>';
    }).join('');

    _renderReturnsArchiveToolbar();
}


// ================================================================
// شريط أدوات الأرشفة
// ================================================================

function _renderReturnsArchiveToolbar() {
    var bar = document.getElementById('returnsArchiveBar');
    if (!bar) return;

    if (!_archiveReturnsMode) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    var count = Object.keys(_selectedReturnsForArchive).length;
    bar.style.display = 'flex';
    bar.innerHTML =
        '<button class="btn btn-secondary" onclick="toggleSelectAllReturns()" style="flex:1;font-size:12px;">' +
            (_allActiveReturnsSelected() ? 'إلغاء الكل' : 'تحديد الكل') +
        '</button>' +
        '<button class="btn btn-warning" onclick="confirmArchiveReturns()" style="flex:1;font-size:12px;" ' + (count === 0 ? 'disabled' : '') + '>' +
            'أرشفة المحدد (' + count + ')' +
        '</button>' +
        '<button class="btn btn-cancel" onclick="toggleArchiveReturnsMode()" style="flex:1;font-size:12px;">' +
            'إلغاء' +
        '</button>';
}

function _allActiveReturnsSelected() {
    var active = returnsDocs.filter(function(r) {
        return r.kind === currentReturnsFilter && !r.cancelled && r.documentStatus !== 'cancelled' && !r.archived;
    });
    if (!active.length) return false;
    return active.every(function(r) { return _selectedReturnsForArchive[r.id]; });
}

function toggleArchiveReturnsMode() {
    _archiveReturnsMode = !_archiveReturnsMode;
    _selectedReturnsForArchive = {};
    if (_archiveReturnsMode) _showArchivedReturns = false;
    renderReturns();
}

function toggleShowArchivedReturns() {
    _showArchivedReturns = !_showArchivedReturns;
    _archiveReturnsMode = false;
    _selectedReturnsForArchive = {};
    renderReturns();
}

function onReturnsArchiveCheckboxChange(cb) {
    var id = cb.getAttribute('data-id');
    if (cb.checked) _selectedReturnsForArchive[id] = true;
    else delete _selectedReturnsForArchive[id];
    _renderReturnsArchiveToolbar();
}

function toggleSelectAllReturns() {
    var active = returnsDocs.filter(function(r) {
        return r.kind === currentReturnsFilter && !r.cancelled && r.documentStatus !== 'cancelled' && !r.archived;
    });
    if (_allActiveReturnsSelected()) {
        _selectedReturnsForArchive = {};
    } else {
        active.forEach(function(r) { _selectedReturnsForArchive[r.id] = true; });
    }
    renderReturns();
}

function confirmArchiveReturns() {
    var ids = Object.keys(_selectedReturnsForArchive);
    if (!ids.length) { showToast('لم تحدد أي مرتجع', 'warning'); return; }
    if (!confirm('سيتم أرشفة ' + ids.length + ' مرتجع.\nستُخفى من العرض — لا تُحذف.\n\nمتابعة؟')) return;

    var count = 0;
    returnsDocs.forEach(function(r) {
        if (_selectedReturnsForArchive[r.id]) {
            r.archived = true;
            r.archivedAt = new Date().toISOString();
            count++;
        }
    });

    saveReturns();
    _archiveReturnsMode = false;
    _selectedReturnsForArchive = {};
    renderReturns();
    showToast('تمت أرشفة ' + count + ' مرتجع', 'success');
}

function restoreReturn(id) {
    var r = returnsDocs.find(function(x) { return x.id === id; });
    if (!r) return;
    r.archived = false;
    delete r.archivedAt;
    saveReturns();
    renderReturns();
    showToast('تم استرجاع المرتجع', 'success');
}


// ================================================================
// فتح نافذة المرتجع
// ================================================================

function openReturnModal(kind) {
    currentReturnsFilter = kind;
    renderReturns();

    var tabSale = document.getElementById('returnsTabSale');
    var tabPurchase = document.getElementById('returnsTabPurchase');
    if (tabSale) {
        if (kind === 'sale') tabSale.classList.add('active-tab');
        else tabSale.classList.remove('active-tab');
    }
    if (tabPurchase) {
        if (kind === 'purchase') tabPurchase.classList.add('active-tab');
        else tabPurchase.classList.remove('active-tab');
    }

    var invoices = kind === 'sale' ? salesInvoices : purchaseInvoices;
    if (!invoices || !invoices.length) return showToast('لا توجد فواتير متاحة', 'error');

    var opts = invoices.map(function(i) {
        var party = kind === 'sale' ? i.customerName : i.supplierName;
        return '<option value="' + i.id + '">' + esc(i.id) + ' — ' + esc(party || '-') + '</option>';
    }).join('');

    Modal.open({
        id: 'returnModal',
        title: kind === 'sale' ? 'مرتجع مبيعات' : 'مرتجع مشتريات',
        body:
            '<input type="hidden" id="returnKind" value="' + kind + '">' +
            '<div class="form-field"><label>الفاتورة الأصلية</label>' +
                '<select id="returnInvoice">' + opts + '</select>' +
            '</div>' +
            '<div class="form-field"><label>المنتج</label>' +
                '<select id="returnProduct"></select>' +
            '</div>' +
            '<div class="form-field"><label>الكمية المرتجعة</label>' +
                '<input type="number" id="returnQty" min="0.000001" step="0.000001">' +
            '</div>' +
            '<div class="form-field"><label>ملاحظة</label>' +
                '<input id="returnNote">' +
            '</div>',
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'returnModal\')">إلغاء</button>' +
            '<button class="btn btn-primary" onclick="saveReturn()">حفظ المرتجع</button>',
        onOpen: function() {
            document.getElementById('returnInvoice').onchange = populateReturnProducts;
            populateReturnProducts();
        }
    });
}


// ================================================================
// ملء قائمة المنتجات
// ================================================================

function populateReturnProducts() {
    var kind = document.getElementById('returnKind').value;
    var id = document.getElementById('returnInvoice').value;
    var inv = (kind === 'sale' ? salesInvoices : purchaseInvoices).find(function(x) { return x.id === id; });
    var s = document.getElementById('returnProduct');
    if (!s || !inv) return;

    var sHTML = (inv.items || []).map(function(i) {
        var prevReturns = returnsDocs
            .filter(function(r) { return r.invoiceId === id && r.productId === i.productId && _reportIsActive(r); })
            .reduce(function(sum, r) { return sum + (parseFloat(r.qty) || 0); }, 0);

        var available = (parseFloat(i.qty) || 0) - prevReturns;

        return '<option value="' + i.productId + '" data-available="' + available + '">' +
            esc(i.productName || i.name || i.productId) +
            ' — المتاح للإرجاع: ' + available +
        '</option>';
    }).join('');

    s.innerHTML = sHTML;
}
// ================================================================
// حفظ المرتجع (تحقق + تأكيد)
// ================================================================

function saveReturn() {
    var kind = document.getElementById('returnKind').value;
    var id = document.getElementById('returnInvoice').value;
    var pid = document.getElementById('returnProduct').value;
    var qty = parseFloat(document.getElementById('returnQty').value) || 0;
    var note = document.getElementById('returnNote').value.trim();

    var invoices = kind === 'sale' ? salesInvoices : purchaseInvoices;
    var inv = invoices.find(function(x) { return x.id === id; });

    if (!inv) return showToast('الفاتورة غير موجودة', 'error');
    if (!_reportIsActive(inv)) return showToast('لا يمكن إرجاع فاتورة ملغاة', 'error');
    var item = (inv.items || []).find(function(x) { return x.productId === pid; });
    if (!item) return showToast('المنتج غير موجود في الفاتورة', 'error');
    if (qty <= 0) return showToast('الكمية غير صحيحة', 'error');

    var previousReturns = returnsDocs
        .filter(function(r) { return r.invoiceId === id && r.productId === pid && _reportIsActive(r); })
        .reduce(function(s, r) { return s + (parseFloat(r.qty) || 0); }, 0);

    var originalQty = parseFloat(item.qty) || 0;
    var remainingQty = originalQty - previousReturns;

    if (qty > remainingQty + 0.0000001) {
        return showToast('الكمية تتجاوز المتاح (' + remainingQty + ')', 'error');
    }

    var p = products.find(function(x) { return x.id === pid; });
    if (!p) return showToast('المنتج غير موجود', 'error');

    if (kind === 'purchase') {
        var currentStock = parseFloat(p.quantity) || 0;
        if (qty > currentStock + 0.0000001) {
            return showToast(
                'لا يمكن إرجاع ' + qty + ' — المخزون الحالي ' + currentStock + ' فقط.\n' +
                'قد تكون الكمية استُهلكت في الإنتاج أو البيع.',
                'error', 8000
            );
        }
    }

    var partyLabel = kind === 'sale' ? 'العميل' : 'المورد';
    var partyName = kind === 'sale' ? (inv.customerName || '-') : (inv.supplierName || '-');
    var productName = item.productName || item.name || p.name || pid;
    var currency = inv.currency || 'YER';

    var unitPricePreview = parseFloat(item.price) || 0;
    var previewAmount = unitPricePreview * qty;

    var summaryText =
        'الفاتورة: ' + id + '\n' +
        partyLabel + ': ' + partyName + '\n' +
        'المنتج: ' + productName + '\n' +
        'الكمية المرتجعة: ' + qty + '\n' +
        'القيمة التقديرية: ' + formatAmountWithCommas(previewAmount) + ' ' + currency + '\n\n' +
        '⚠️ سيتم:\n' +
        '1. تسجيل سند مرتجع جديد\n' +
        '2. تعديل المخزون\n' +
        '3. إعادة توليد القيود\n\n' +
        'هل تريد المتابعة؟';

    Modal.confirm({
        title: 'تأكيد المرتجع',
        message: summaryText,
        confirmText: 'تنفيذ',
        cancelText: 'إلغاء',
        confirmColor: 'primary',
        onConfirm: function() {
            _executeReturn(kind, id, pid, qty, note, inv, item, p);
        }
    });
}


// ================================================================
// تنفيذ المرتجع (المنطق الفعلي)
// ================================================================

function _executeReturn(kind, id, pid, qty, note, inv, item, p) {
    try {
        // 1. تعديل المخزون
        p.quantity = (parseFloat(p.quantity) || 0) + (kind === 'sale' ? qty : -qty);
        if (typeof saveProducts === 'function') saveProducts();

        // 2. حساب قيمة المرتجع
        var unitPrice = parseFloat(item.price) || 0;
        var invSubtotal = parseFloat(inv.subtotal) || 0;
        var originalQty = parseFloat(item.qty) || 0;
        var lineBaseTotal = unitPrice * originalQty;
        var allocatedDiscount = invSubtotal > 0
            ? ((parseFloat(inv.discount) || 0) * (lineBaseTotal / invSubtotal))
            : 0;
        var netUnitPrice = originalQty > 0
            ? ((lineBaseTotal - allocatedDiscount) / originalQty)
            : unitPrice;
        var amount = netUnitPrice * qty;

        // 3. تسجيل المستند
        var returnId = 'RET-' + Date.now().toString(36).toUpperCase();

        var doc = {
            id: returnId,
            date: todayISO(),
            kind: kind,
            invoiceId: id,
            invoiceRef: id,
            productId: pid,
            productName: item.productName || item.name || p.name,
            qty: qty,
            originalQty: originalQty,
            unitPrice: netUnitPrice,
            amount: amount,
            currency: inv.currency || 'YER',
            exchangeRate: inv.exchangeRate || 1,
            partyId: kind === 'sale' ? inv.customerId : inv.supplierId,
            partyName: kind === 'sale' ? inv.customerName : inv.supplierName,
            note: note,
            cogsAmount: 0,
            documentStatus: 'active'
        };

        if (kind === 'sale' && item.cogsUnitCost) {
            doc.cogsAmount = (parseFloat(item.cogsUnitCost) || 0) * qty;
        }

        returnsDocs.push(doc);
        saveReturns();

        // 3-b. تحديث الفاتورة الأصلية
        var totalReturnedForInvoice = returnsDocs
            .filter(function(r) {
                return r.invoiceId === id
                    && r.kind === kind
                    && r.cancelled !== true
                    && r.documentStatus !== 'cancelled';
            })
            .reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);

        var invoiceTotalForReturn = parseFloat(inv.total) || 0;

        inv.returnedAmount = totalReturnedForInvoice;
        inv.returnStatus = (invoiceTotalForReturn > 0 && totalReturnedForInvoice >= invoiceTotalForReturn - 0.01)
            ? 'full'
            : 'partial';

        if (kind === 'sale' && typeof saveSalesInvoices === 'function') {
            saveSalesInvoices();
        }
        if (kind === 'purchase' && typeof savePurchaseInvoices === 'function') {
            savePurchaseInvoices();
        }

        // 4. تسجيل حركة المخزون
        if (typeof stockMovements !== 'undefined' && typeof saveStockMovements === 'function') {
            stockMovements.push({
                id: generateId(),
                docId: doc.id,
                docType: kind === 'sale' ? 'مرتجع مبيعات' : 'مرتجع مشتريات',
                date: doc.date,
                productId: pid,
                productName: doc.productName,
                type: kind === 'sale' ? 'in' : 'out',
                qty: qty,
                unit: p.baseUnit || p.unit || 'وحدة',
                price: parseFloat(item.price) || 0,
                currency: inv.currency || 'SAR',
                note: 'مرتجع من الفاتورة ' + id
            });
            saveStockMovements();
        }

        // 5. إعادة توليد القيود
        if (typeof generateAllJournalEntries === 'function') {
            try { generateAllJournalEntries(); } catch (e) {
                console.warn('Journal regen failed:', e);
            }
        }

        closeModal('returnModal');

        // 6. تحديث الواجهات
        if (typeof oaRefreshRelated === 'function') {
            oaRefreshRelated('return');
        } else {
            renderReturns();
            if (typeof renderInventory === 'function') renderInventory();
            if (typeof renderSalesInvoices === 'function') renderSalesInvoices();
            if (typeof renderPurchaseInvoices === 'function') renderPurchaseInvoices();
            if (typeof renderCustomers === 'function') renderCustomers();
            if (typeof renderSuppliers === 'function') renderSuppliers();
            if (typeof renderSupplierLedger === 'function') renderSupplierLedger();
            if (typeof renderCustomerLedger === 'function') renderCustomerLedger();
            if (typeof renderJournal === 'function') renderJournal();
            if (typeof renderTrialBalance === 'function') renderTrialBalance();
            if (typeof renderGeneralLedger === 'function') renderGeneralLedger();
            if (typeof updateDashboard === 'function') updateDashboard();
        }

        showToast('تم تسجيل المرتجع ' + returnId + ' — الفاتورة الأصلية لم تتغير', 'success');

    } catch (e) {
        console.error('Return execution error:', e);
        showToast('خطأ في تنفيذ المرتجع: ' + e.message, 'error');
    }
}


// ================================================================
// إلغاء المرتجع
// ================================================================

function cancelReturn(id) {
    var ret = returnsDocs.find(function(r) { return r.id === id; });
    if (!ret) {
        showToast('المرتجع غير موجود', 'error');
        return;
    }
    if (ret.cancelled === true || ret.documentStatus === 'cancelled') {
        showToast('المرتجع ملغى مسبقاً', 'info');
        return;
    }

    Modal.confirm({
        title: 'تأكيد إلغاء المرتجع',
        message:
            'سيتم:\n' +
            '• وسم المرتجع كـ "ملغى"\n' +
            '• عكس تأثير المخزون\n' +
            '• إنشاء قيد عكسي\n\n' +
            'المرتجع: ' + ret.id + '\n' +
            'المنتج: ' + ret.productName + '\n' +
            'الكمية: ' + ret.qty + '\n\n' +
            'هل تريد المتابعة؟',
        confirmText: 'إلغاء المرتجع',
        cancelText: 'تراجع',
        confirmColor: 'danger',
        onConfirm: function() {
            var p = products.find(function(x) { return x.id === ret.productId; });
            if (!p) {
                showToast('المنتج غير موجود', 'error');
                return;
            }

            var currentQty = parseFloat(p.quantity) || 0;
            var retQty = parseFloat(ret.qty) || 0;

            if (ret.kind === 'sale') {
                if (currentQty < retQty) {
                    showToast(
                        'لا يمكن إلغاء المرتجع — المخزون غير كافٍ.\n' +
                        'المطلوب: ' + retQty + ' | المتاح: ' + currentQty,
                        'error', 8000
                    );
                    return;
                }
            }

            ret.cancelled = true;
            ret.documentStatus = 'cancelled';
            ret.cancelledAt = new Date().toISOString();
            ret.cancelReason = 'إلغاء يدوي من المستخدم';

            if (ret.kind === 'sale') {
                p.quantity = currentQty - retQty;
            } else {
                p.quantity = currentQty + retQty;
            }
            if (typeof saveProducts === 'function') saveProducts();

            var reversalMovementId = null;
            if (typeof stockMovements !== 'undefined' && typeof saveStockMovements === 'function') {
                reversalMovementId = generateId();
                stockMovements.push({
                    id: reversalMovementId,
                    docId: ret.id,
                    date: todayISO(),
                    productId: ret.productId,
                    productName: ret.productName,
                    type: ret.kind === 'sale' ? 'out' : 'in',
                    qty: retQty,
                    unit: p.baseUnit || p.unit || 'وحدة',
                    note: 'إلغاء المرتجع ' + ret.id,
                    reversalOf: ret.id,
                    isReversal: true
                });
                saveStockMovements();
            }

            ret.reversalMovementId = reversalMovementId;
            saveReturns();

            if (typeof generateAllJournalEntries === 'function') {
                try { generateAllJournalEntries(); } catch (e) {
                    console.warn('Journal regen failed:', e);
                }
            }

            if (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries)) {
                var reversalEntry = journalEntries.find(function(e) {
                    return e.reversalOf === ret.id
                        && e.type === 'return_' + ret.kind + '_cancellation';
                });
                if (reversalEntry) {
                    ret.reversalEntryId = reversalEntry.id;
                }
            }

            ret.reversalStatus = (ret.reversalMovementId && ret.reversalEntryId) ? 'full' : 'partial';
            ret.fullyReversed = (ret.reversalStatus === 'full');
            saveReturns();

            if (typeof oaRefreshRelated === 'function') {
                oaRefreshRelated('return');
            } else {
                renderReturns();
                if (typeof renderInventory === 'function') renderInventory();
                if (typeof updateDashboard === 'function') updateDashboard();
            }

            showToast('تم إلغاء المرتجع ' + ret.id, 'success');
        }
    });
}


// ================================================================
// التهيئة
// ================================================================

function initReturns() {
    loadReturns();
    renderReturns();

    var tabSale = document.getElementById('returnsTabSale');
    var tabPurchase = document.getElementById('returnsTabPurchase');
    if (tabSale) tabSale.classList.add('active-tab');
    if (tabPurchase) tabPurchase.classList.remove('active-tab');
}


// ================================================================
// معاينة مرتجع
// ================================================================

function viewReturn(id) {
    var ret = returnsDocs.find(function(r) { return r.id === id; });
    if (!ret) {
        showToast('المرتجع غير موجود', 'error');
        return;
    }
    _openReturnTemplate(id);
}


// ================================================================
// فتح قالب المرتجع
// ================================================================

function _openReturnTemplate(id) {
    var ret = returnsDocs.find(function(r) { return r.id === id; });
    if (!ret) {
        showToast('المرتجع غير موجود', 'error');
        return;
    }

    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    var sameGroup = returnsDocs.filter(function(r) {
        return r.invoiceId === ret.invoiceId && r.date === ret.date;
    });

    var items = sameGroup.map(function(r) {
        var product = null;
        if (typeof products !== 'undefined' && Array.isArray(products)) {
            product = products.find(function(p) { return p.id === r.productId; });
        }
        return {
            productName: r.productName || '—',
            unit: (product && (product.baseUnit || product.unit)) || 'وحدة',
            originalQty: r.originalQty || 0,
            qty: r.qty || 0,
            unitPrice: r.unitPrice || 0,
            amount: r.amount || 0
        };
    });

    var totalReturn = sameGroup.reduce(function(s, r) {
        return s + (parseFloat(r.amount) || 0);
    }, 0);

    var originalTotal = 0;
    if (ret.kind === 'sale' && typeof salesInvoices !== 'undefined') {
        var inv = salesInvoices.find(function(x) { return x.id === ret.invoiceId; });
        if (inv) originalTotal = parseFloat(inv.total) || 0;
    } else if (ret.kind === 'purchase' && typeof purchaseInvoices !== 'undefined') {
        var inv = purchaseInvoices.find(function(x) { return x.id === ret.invoiceId; });
        if (inv) originalTotal = parseFloat(inv.total) || 0;
    }

    var party = null;
    if (ret.kind === 'sale' && typeof customers !== 'undefined') {
        party = customers.find(function(c) { return c.id === ret.partyId; }) || null;
    } else if (ret.kind === 'purchase' && typeof suppliers !== 'undefined') {
        party = suppliers.find(function(s) { return s.id === ret.partyId; }) || null;
    }

    // ✅ بيانات سند الرد — تحقق مزدوج
    var linkedRefund = null;
    var linkedRefundType = null;

    // 1. رد لعميل (مباشر)
    if (ret.refundPaymentId && typeof payments !== 'undefined') {
        var candidatePay = payments.find(function(p) {
            return p && p.id === ret.refundPaymentId;
        });
        if (candidatePay
            && candidatePay.paymentType === 'customer_refund'
            && candidatePay.returnId === ret.id
            && candidatePay.cancelled !== true
            && candidatePay.documentStatus !== 'cancelled') {
            linkedRefund = candidatePay;
            linkedRefundType = 'customer_refund';
        }
    }

    // 2. تحصيل من مورد (مباشر)
    if (!linkedRefund && ret.refundReceiptId && typeof receipts !== 'undefined') {
        var candidateRec = receipts.find(function(rec) {
            return rec && rec.id === ret.refundReceiptId;
        });
        if (candidateRec
            && candidateRec.receiptType === 'supplier_refund'
            && candidateRec.returnId === ret.id
            && candidateRec.cancelled !== true
            && candidateRec.documentStatus !== 'cancelled') {
            linkedRefund = candidateRec;
            linkedRefundType = 'supplier_refund';
        }
    }

    // 3. البحث الاحتياطي
    if (!linkedRefund) {
        if (ret.kind === 'sale' && typeof payments !== 'undefined') {
            linkedRefund = payments.find(function(p) {
                return p
                    && p.paymentType === 'customer_refund'
                    && p.returnId === ret.id
                    && p.cancelled !== true
                    && p.documentStatus !== 'cancelled';
            }) || null;
            if (linkedRefund) linkedRefundType = 'customer_refund';
        } else if (ret.kind === 'purchase' && typeof receipts !== 'undefined') {
            linkedRefund = receipts.find(function(rec) {
                return rec
                    && rec.receiptType === 'supplier_refund'
                    && rec.returnId === ret.id
                    && rec.cancelled !== true
                    && rec.documentStatus !== 'cancelled';
            }) || null;
            if (linkedRefund) linkedRefundType = 'supplier_refund';
        }
    }

    var payload = {
        type: 'returns',
        doc: ret,
        settings: settings,
        items: items,
        party: party,
        linkedRefund: linkedRefund,
        linkedRefundType: linkedRefundType,
        meta: {
            totalReturn: totalReturn,
            originalTotal: originalTotal
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/return-voucher.html';
    localStorage.setItem('oa_return_url', window.location.href);
    window.location.href = url;
}


// ================================================================
// فتح سند الرد المرتبط
// ================================================================

function _openLinkedRefund(id, kind) {
    if (!id) return;
    kind = kind || 'payment';

    var tab = (kind === 'receipt') ? 'receipts' : 'payments';
    var type = (kind === 'receipt') ? 'receipt' : 'payment';

    try {
        localStorage.setItem('oa_pending_open_doc', JSON.stringify({
            type: type,
            id: id,
            tab: tab,
            timestamp: new Date().toISOString()
        }));
    } catch (e) {}

    if (typeof switchTab === 'function') switchTab(tab);

    setTimeout(function() {
        if (kind === 'receipt') {
            if (typeof viewReceipt === 'function') viewReceipt(id);
            else if (typeof printIndividualDocument === 'function') printIndividualDocument('receipts', id);
        } else {
            if (typeof viewPayment === 'function') viewPayment(id);
            else if (typeof printIndividualDocument === 'function') printIndividualDocument('payments', id);
        }
    }, 500);
}


// ================================================================
// فتح نموذج تحصيل لمرتجع مشتريات
// ================================================================

function _openRefundForReturn(returnId) {
    if (!returnId) return;

    var ret = (typeof returnsDocs !== 'undefined')
        ? returnsDocs.find(function(r) { return r.id === returnId; })
        : null;
    if (!ret) { showToast('المرتجع غير موجود', 'error'); return; }
    if (ret.kind !== 'purchase') { showToast('هذا الزر لمرتجعات المشتريات فقط', 'error'); return; }
    if (ret.cancelled || ret.documentStatus === 'cancelled') { showToast('لا يمكن التحصيل لمرتجع ملغى', 'error'); return; }

    if (typeof _calculateAvailableRefundForReturn !== 'function') {
        showToast('دالة حساب المتاح غير محمّلة', 'error');
        return;
    }
    var calc = _calculateAvailableRefundForReturn(ret);
    if (!calc.ok) {
        showToast('لا يمكن التحصيل: ' + (calc.reason || 'خطأ'), 'error');
        return;
    }
    if (calc.available <= 0.01) {
        showToast(
            'لا يوجد مبلغ متاح للتحصيل من هذا المرتجع.\n' +
            'المتاح: ' + formatAmountWithCommas(calc.available),
            'error', 6000
        );
        return;
    }

    if (typeof openReceiptModal !== 'function') {
        showToast('نموذج السندات غير محمّل', 'error');
        return;
    }
    openReceiptModal();

    setTimeout(function() {
        var typeEl = document.getElementById('receiptType');
        if (typeEl) {
            typeEl.value = 'supplier_refund';
            if (typeof _onReceiptTypeChange === 'function') _onReceiptTypeChange();
        }

        setTimeout(function() {
            var supplierEl = document.getElementById('receiptSupplier');
            if (supplierEl && ret.partyId) {
                supplierEl.value = ret.partyId;
            }
            var returnEl = document.getElementById('receiptSourceReturn');
            if (returnEl) {
                returnEl.value = ret.id;
            }
            if (typeof updateSupplierRefundInfo === 'function') {
                updateSupplierRefundInfo();
            }
            var amountEl = document.getElementById('receiptAmount');
            if (amountEl) {
                amountEl.value = calc.available.toFixed(2);
            }
        }, 200);
    }, 200);
}


// ================================================================
// ===== END OF RETURNS.JS =====
// ================================================================