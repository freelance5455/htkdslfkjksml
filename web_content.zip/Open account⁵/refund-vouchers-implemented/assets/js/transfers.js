// ================================================================
// Open Account — التحويلات الداخلية
// الوصف: نقل الأموال بين الصندوق والبنك أو بين عملتين
// ================================================================

var transfers = [];

function loadTransfers() {
    transfers = Storage.get(STORAGE_KEYS.TRANSFERS, []);
    if (!Array.isArray(transfers)) transfers = [];
}

function saveTransfers() {
    Storage.set(STORAGE_KEYS.TRANSFERS, transfers);
}

function getTransferAccountLabel(type) {
    return type === 'cashbox' ? 'الصندوق' : 'البنك';
}

function getAccountBalance(type, currency) {
    var list = type === 'cashbox'
        ? (typeof getCashboxTransactions === 'function' ? getCashboxTransactions() : [])
        : (typeof getBankTransactions === 'function' ? getBankTransactions() : []);
    return list.reduce(function(total, item) {
        if ((item.currency || 'YER') !== currency) return total;
        return total + (item.type === 'in' ? item.amount : -item.amount);
    }, 0);
}

function openTransferModal(context) {
    var fromType = context === 'bank' ? 'bank' : 'cashbox';
    var toType = fromType === 'cashbox' ? 'bank' : 'cashbox';
    var fromLabel = getTransferAccountLabel(fromType);
    var toLabel = getTransferAccountLabel(toType);

    var body =
        '<div class="info-message" style="text-align:right;line-height:1.8;margin-bottom:12px;">' +
            'التحويل الداخلي لا يؤثر على كشوف العملاء أو الموردين أو الفواتير أو المخزون.' +
        '</div>' +
        '<div class="form-row">' +
            '<div class="form-field"><label>من</label><select id="transferFromType">' +
                '<option value="' + fromType + '">' + fromLabel + '</option>' +
                '<option value="' + toType + '">' + toLabel + '</option>' +
            '</select></div>' +
            '<div class="form-field"><label>إلى</label><select id="transferToType">' +
                '<option value="' + toType + '">' + toLabel + '</option>' +
                '<option value="' + fromType + '">' + fromLabel + '</option>' +
            '</select></div>' +
        '</div>' +
        '<div class="form-row">' +
            '<div class="form-field"><label>عملة المصدر</label><select id="transferFromCurrency">' +
                '<option value="YER">YER</option><option value="SAR">SAR</option><option value="USD">USD</option>' +
            '</select></div>' +
            '<div class="form-field"><label>المبلغ المصدر</label><input id="transferFromAmount" type="number" min="0.000001" step="0.000001" placeholder="0.00"></div>' +
        '</div>' +
        '<div class="form-row">' +
            '<div class="form-field"><label>عملة الوجهة</label><select id="transferToCurrency">' +
                '<option value="YER">YER</option><option value="SAR">SAR</option><option value="USD">USD</option>' +
            '</select></div>' +
            '<div class="form-field"><label>سعر الصرف (1 من = كم من إلى)</label><input id="transferRate" type="number" min="0.000001" step="0.000001" value="1"></div>' +
        '</div>' +
        '<div class="form-field"><label>المبلغ المستلم</label><input id="transferToAmount" type="number" min="0.000001" step="0.000001" placeholder="يُحسب تلقائياً"></div>' +
        '<div class="form-row"><div class="form-field"><label>التاريخ</label><input id="transferDate" type="date" value="' + todayISO() + '"></div>' +
        '<div class="form-field"><label>ملاحظة</label><input id="transferNote" type="text" placeholder="إيداع نقدي، سحب..." ></div></div>';

    Modal.open({
        id: 'transferModal',
        title: 'تحويل داخلي',
        size: 'normal',
        body: body,
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'transferModal\')">إلغاء</button>' +
                '<button class="btn btn-primary" onclick="saveTransfer()">حفظ التحويل</button>',
        onOpen: function(modalEl) {
            var fromCurrency = modalEl.querySelector('#transferFromCurrency');
            var toCurrency = modalEl.querySelector('#transferToCurrency');
            var amount = modalEl.querySelector('#transferFromAmount');
            var rate = modalEl.querySelector('#transferRate');
            var output = modalEl.querySelector('#transferToAmount');
            function recalculate() {
                var source = parseFloat(amount.value) || 0;
                var exchange = parseFloat(rate.value) || 0;
                output.value = source && exchange ? (source * exchange).toFixed(6).replace(/0+$/, '').replace(/\.$/, '') : '';
            }
            fromCurrency.addEventListener('change', function() {
                if (fromCurrency.value === toCurrency.value) rate.value = '1';
                recalculate();
            });
            toCurrency.addEventListener('change', function() {
                if (fromCurrency.value === toCurrency.value) rate.value = '1';
                recalculate();
            });
            amount.addEventListener('input', recalculate);
            rate.addEventListener('input', recalculate);
        }
    });
}

function saveTransfer() {
    var fromType = document.getElementById('transferFromType').value;
    var toType = document.getElementById('transferToType').value;
    var fromCurrency = document.getElementById('transferFromCurrency').value;
    var toCurrency = document.getElementById('transferToCurrency').value;
    var fromAmount = parseFloat(document.getElementById('transferFromAmount').value) || 0;
    var rate = parseFloat(document.getElementById('transferRate').value) || 0;
    var toAmount = parseFloat(document.getElementById('transferToAmount').value) || 0;
    var date = document.getElementById('transferDate').value || todayISO();
    var note = document.getElementById('transferNote').value.trim();

    if (fromType === toType && fromCurrency === toCurrency) {
        showToast('لا يمكن التحويل إلى الحساب نفسه وبالعملة نفسها', 'error');
        return;
    }
    if (fromAmount <= 0 || rate <= 0 || toAmount <= 0) {
        showToast('أدخل مبلغاً وسعر صرف صحيحين', 'error');
        return;
    }
    if (fromCurrency === toCurrency) {
        rate = 1;
        toAmount = fromAmount;
    }
    var available = getAccountBalance(fromType, fromCurrency);
    if (fromAmount > available + 0.0000001) {
        showToast('الرصيد المتاح في المصدر: ' + formatAmountWithCommas(available) + ' ' + fromCurrency, 'error');
        return;
    }

    var number = 'TRF-' + String(Date.now()).slice(-8);
    var transfer = {
        id: generateId(), number: number, type: fromCurrency === toCurrency ? 'internal_transfer' : 'currency_transfer',
        from: { accountType: fromType, accountId: fromType + '_main', currency: fromCurrency, amount: fromAmount, exchangeRate: typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(fromCurrency) : 1 },
        to: { accountType: toType, accountId: toType + '_main', currency: toCurrency, amount: toAmount, exchangeRate: typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(toCurrency) : 1 },
        exchangeRate: { fromCurrency: fromCurrency, toCurrency: toCurrency, rate: rate },
        date: date, note: note, status: 'posted', createdAt: new Date().toISOString()
    };
    transfers.push(transfer);
    saveTransfers();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
    closeModal('transferModal');
    if (typeof renderCashbox === 'function') renderCashbox();
    if (typeof renderBank === 'function') renderBank();
    if (typeof updateDashboard === 'function') updateDashboard();
    showToast('تم حفظ التحويل ' + number, 'success');
}

function initTransfers() {
    loadTransfers();
}
