/* ================================================================
   Open Account — سودوكو
   الملف: sudoku.js
   الوصف: لعبة سودوكو بحفظ تلقائي
   ================================================================ */

(function() {
    'use strict';

    var STORAGE_KEY = 'oa_sudoku_state';
    var SIZE = 9;
    var BOX = 3;

    var _state = null;
    var _selectedCell = null;

    // ===== دوال مساعدة =====
    function _deepCopy(arr) {
        return JSON.parse(JSON.stringify(arr));
    }

    // ===== توليد حل كامل عشوائي =====
    function _generateSolution() {
        var grid = [];
        for (var i = 0; i < SIZE; i++) {
            grid.push(new Array(SIZE).fill(0));
        }

        function isValid(grid, row, col, num) {
            // الصف
            for (var c = 0; c < SIZE; c++) {
                if (grid[row][c] === num) return false;
            }
            // العمود
            for (var r = 0; r < SIZE; r++) {
                if (grid[r][col] === num) return false;
            }
            // المربع 3×3
            var boxRow = Math.floor(row / BOX) * BOX;
            var boxCol = Math.floor(col / BOX) * BOX;
            for (var rr = boxRow; rr < boxRow + BOX; rr++) {
                for (var cc = boxCol; cc < boxCol + BOX; cc++) {
                    if (grid[rr][cc] === num) return false;
                }
            }
            return true;
        }

        function fill(grid) {
            for (var row = 0; row < SIZE; row++) {
                for (var col = 0; col < SIZE; col++) {
                    if (grid[row][col] === 0) {
                        var nums = [1,2,3,4,5,6,7,8,9].sort(function() { return Math.random() - 0.5; });
                        for (var i = 0; i < nums.length; i++) {
                            var num = nums[i];
                            if (isValid(grid, row, col, num)) {
                                grid[row][col] = num;
                                if (fill(grid)) return true;
                                grid[row][col] = 0;
                            }
                        }
                        return false;
                    }
                }
            }
            return true;
        }

        fill(grid);
        return grid;
    }

    // ===== إزالة أرقام حسب المستوى =====
    function _puzzleFromSolution(solution, level) {
        var puzzle = _deepCopy(solution);
        var removed = { easy: 35, medium: 45, hard: 55 }[level] || 45;
        var positions = [];
        for (var r = 0; r < SIZE; r++) {
            for (var c = 0; c < SIZE; c++) {
                positions.push([r, c]);
            }
        }
        positions.sort(function() { return Math.random() - 0.5; });
        for (var i = 0; i < removed && i < positions.length; i++) {
            var pos = positions[i];
            puzzle[pos[0]][pos[1]] = 0;
        }
        return puzzle;
    }

    // ===== تحويل الشبكة إلى مصفوفة مُسطَّحة =====
    function _flatten(grid) {
        var flat = [];
        for (var r = 0; r < SIZE; r++) {
            for (var c = 0; c < SIZE; c++) {
                flat.push(grid[r][c]);
            }
        }
        return flat;
    }

    function _unflatten(flat) {
        var grid = [];
        for (var r = 0; r < SIZE; r++) {
            grid.push(flat.slice(r * SIZE, r * SIZE + SIZE));
        }
        return grid;
    }

    // ===== فحص الخطأ =====
    function _hasConflict(grid, row, col) {
        var num = grid[row][col];
        if (!num) return false;
        for (var i = 0; i < SIZE; i++) {
            if (i !== col && grid[row][i] === num) return true;
            if (i !== row && grid[i][col] === num) return true;
        }
        var boxRow = Math.floor(row / BOX) * BOX;
        var boxCol = Math.floor(col / BOX) * BOX;
        for (var rr = boxRow; rr < boxRow + BOX; rr++) {
            for (var cc = boxCol; cc < boxCol + BOX; cc++) {
                if ((rr !== row || cc !== col) && grid[rr][cc] === num) return true;
            }
        }
        return false;
    }

    // ===== إكمال الحل =====
    function _solve(grid) {
        for (var row = 0; row < SIZE; row++) {
            for (var col = 0; col < SIZE; col++) {
                if (grid[row][col] === 0) {
                    for (var num = 1; num <= 9; num++) {
                        if (!_hasConflict(grid, row, col) || true) {
                            // فحص صحة
                            var ok = true;
                            for (var c = 0; c < SIZE; c++) if (grid[row][c] === num) { ok = false; break; }
                            if (ok) for (var r = 0; r < SIZE; r++) if (grid[r][col] === num) { ok = false; break; }
                            if (ok) {
                                var boxRow = Math.floor(row / BOX) * BOX;
                                var boxCol = Math.floor(col / BOX) * BOX;
                                for (var rr = boxRow; rr < boxRow + BOX && ok; rr++) {
                                    for (var cc = boxCol; cc < boxCol + BOX; cc++) {
                                        if (grid[rr][cc] === num) { ok = false; break; }
                                    }
                                }
                            }
                            if (ok) {
                                grid[row][col] = num;
                                if (_solve(grid)) return true;
                                grid[row][col] = 0;
                            }
                        }
                    }
                    return false;
                }
            }
        }
        return true;
    }

    // ===== التحقق من الحل الكامل =====
    function _isComplete(grid) {
        for (var r = 0; r < SIZE; r++) {
            for (var c = 0; c < SIZE; c++) {
                if (grid[r][c] === 0 || _hasConflict(grid, r, c)) return false;
            }
        }
        return true;
    }

    // ===== حفظ الحالة =====
    function _saveState() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(_state));
        } catch(e) { /* تجاهل */ }
    }

    // ===== قراءة الحالة =====
    function _loadState() {
        try {
            var raw = localStorage.getItem(STORAGE_KEY);
            if (!raw) return null;
            var s = JSON.parse(raw);
            if (!s || !s.puzzle || !s.solution) return null;
            return s;
        } catch(e) { return null; }
    }

    // ===== حذف الحالة =====
    function _clearState() {
        try { localStorage.removeItem(STORAGE_KEY); } catch(e) {}
    }

    // ===== بدء لعبة جديدة =====
    function _newGame(level) {
        var solution = _generateSolution();
        var puzzle = _puzzleFromSolution(solution, level);
        _state = {
            level: level,
            puzzle: _flatten(puzzle),
            solution: _flatten(solution),
            user: _flatten(puzzle),
            given: puzzle.map(function(row) {
                return row.map(function(v) { return v !== 0; });
            }),
            createdAt: new Date().toISOString()
        };
        _state.given = [];
        for (var i = 0; i < SIZE * SIZE; i++) {
            _state.given.push(_state.puzzle[i] !== 0);
        }
        _selectedCell = null;
        _saveState();
        _render();
    }

    // ===== كتابة رقم =====
    function _writeNumber(num) {
        if (!_state || _selectedCell === null) return;
        var idx = _selectedCell;
        if (_state.given[idx]) return;
        _state.user[idx] = num;
        _saveState();
        _render();
        if (_isComplete(_unflatten(_state.user))) {
            _showWin();
        }
    }

    // ===== مسح خانة =====
    function _eraseCell() {
        if (!_state || _selectedCell === null) return;
        var idx = _selectedCell;
        if (_state.given[idx]) return;
        _state.user[idx] = 0;
        _saveState();
        _render();
    }

    // ===== تحقق =====
    function _check() {
    if (!_state) return;
    var user = _unflatten(_state.user);
    var solution = _unflatten(_state.solution);
    var conflicts = 0;
    var wrongVsSolution = 0;
    var empty = 0;

    for (var r = 0; r < SIZE; r++) {
        for (var c = 0; c < SIZE; c++) {
            if (user[r][c] === 0) {
                empty++;
                continue;
            }
            // فحص التعارض (صف/عمود/مربع)
            if (_hasConflict(user, r, c)) {
                conflicts++;
            }
            // فحص ضد الحل الصحيح
            if (user[r][c] !== solution[r][c]) {
                wrongVsSolution++;
            }
        }
    }

    var statusEl = document.getElementById('sudokuStatus');
    if (!statusEl) return;

    if (empty > 0) {
        statusEl.textContent = '⚠ اللغز غير مكتمل (' + empty + ' خانة فارغة) — لا يمكن التحقق';
        statusEl.className = 'sudoku-status error-msg';
        return;
    }

    // مكتمل — فحص شامل
    if (conflicts === 0 && wrongVsSolution === 0) {
        statusEl.textContent = '🎉 ممتاز! الحل صحيح 100%';
        statusEl.className = 'sudoku-status win';
    } else {
        statusEl.textContent = '❌ ' + (conflicts + wrongVsSolution) + ' خطأ (تعارضات: ' + conflicts + ' | أخطاء صامتة: ' + wrongVsSolution + ')';
        statusEl.className = 'sudoku-status error-msg';
    }
}

    // ===== حل كامل =====
    function _solveAll() {
        if (!_state) return;
        _state.user = _state.solution.slice();
        _saveState();
        _render();
        _showWin();
    }

    // ===== إظهار الفوز =====
    function _showWin() {
        var statusEl = document.getElementById('sudokuStatus');
        if (statusEl) {
            statusEl.textContent = '🎉 مبروك! أكملت اللغز';
            statusEl.className = 'sudoku-status win';
        }
    }

    // ===== رسم الشبكة =====
    function _render() {
        var boardEl = document.getElementById('sudokuBoard');
        if (!boardEl) return;
        if (!_state) {
            boardEl.innerHTML = '';
            return;
        }

        var user = _unflatten(_state.user);
        var html = '';

        for (var i = 0; i < SIZE * SIZE; i++) {
            var r = Math.floor(i / SIZE);
            var c = i % SIZE;
            var val = user[r][c];
            var isGiven = _state.given[i];
            var isSelected = (_selectedCell === i);
            var isConflict = false;
if (!isGiven && val !== 0) {
    var solution = _unflatten(_state.solution);
    if (_hasConflict(user, r, c) || val !== solution[r][c]) {
        isConflict = true;
    }
}

            var cls = 'sudoku-cell';
            if (isGiven) cls += ' given';
            else if (val !== 0) cls += ' user-input';
            if (isConflict) cls += ' error';
            if (isSelected) cls += ' selected';

            html += '<div class="' + cls + '" data-idx="' + i + '">' +
                (val !== 0 ? val : '') +
            '</div>';
        }

        boardEl.innerHTML = html;

        // ربط الأحداث
        var cells = boardEl.querySelectorAll('.sudoku-cell');
        cells.forEach(function(cell) {
            cell.addEventListener('click', function() {
                var idx = parseInt(this.getAttribute('data-idx'), 10);
                _selectedCell = idx;
                _render();
            });
        });

        // تحديث الأزرار
        var padBtns = document.querySelectorAll('.sudoku-pad button[data-num]');
        padBtns.forEach(function(btn) {
            btn.disabled = (_selectedCell === null);
        });
    }

    // ===== التهيئة =====
    function _initUI() {
        var container = document.getElementById('sudokuContainer');
        if (!container) return;

        var html = '' +
            '<div class="sudoku-wrapper">' +
                '<div class="sudoku-toolbar">' +
                    '<select id="sudokuLevel">' +
                        '<option value="easy">سهل</option>' +
                        '<option value="medium" selected>متوسط</option>' +
                        '<option value="hard">صعب</option>' +
                    '</select>' +
                    '<button id="sudokuNewBtn">لعبة جديدة</button>' +
                    '<button id="sudokuCheckBtn" class="secondary">تحقق</button>' +
                    '<button id="sudokuSolveBtn" class="secondary">حل</button>' +
                '</div>' +
                '<div class="sudoku-status" id="sudokuStatus">اضغط على خانة ثم اختر رقماً</div>' +
                '<div class="sudoku-board" id="sudokuBoard"></div>' +
                '<div class="sudoku-pad" id="sudokuPad">' +
                    '<button data-num="1">1</button>' +
                    '<button data-num="2">2</button>' +
                    '<button data-num="3">3</button>' +
                    '<button data-num="4">4</button>' +
                    '<button data-num="5">5</button>' +
                    '<button data-num="6">6</button>' +
                    '<button data-num="7">7</button>' +
                    '<button data-num="8">8</button>' +
                    '<button data-num="9">9</button>' +
                '</div>' +
              '<div class="sudoku-erase-row">' +
    '<button id="sudokuEraseBtn" class="erase-btn">مسح الخانة</button>' +
'</div>' +
            '</div>';

        container.innerHTML = html;

        // ربط الأحداث
        document.getElementById('sudokuNewBtn').addEventListener('click', function() {
            var lvl = document.getElementById('sudokuLevel').value;
            if (confirm('بدء لعبة جديدة؟ ستفقد تقدمك الحالي.')) {
                _newGame(lvl);
            }
        });

        document.getElementById('sudokuCheckBtn').addEventListener('click', _check);
        document.getElementById('sudokuSolveBtn').addEventListener('click', function() {
            if (confirm('حل اللعبة كاملة؟')) _solveAll();
        });
        document.getElementById('sudokuEraseBtn').addEventListener('click', _eraseCell);

        document.getElementById('sudokuPad').addEventListener('click', function(e) {
            var btn = e.target.closest('button[data-num]');
            if (!btn) return;
            _writeNumber(parseInt(btn.getAttribute('data-num'), 10));
        });
    }

    // ===== التهيئة عند فتح التبويب =====
    function initSudoku() {
        _initUI();

        // اقرأ الحالة السابقة
        var saved = _loadState();
        if (saved) {
            _state = saved;
        } else {
            _newGame('medium');
        }

        _render();
        console.log('Sudoku: initialized');
    }

    // تصدير
    window.initSudoku = initSudoku;

})();