// ================================================================
// Open Account — نظام محاسبي
// الملف: currency.js
// الوصف: إدارة العملات (تعريف، تنسيق، رموز)
// ================================================================


// ================================================================
// ===== 1. تعريف العملات المتاحة =====
// ================================================================

const CURRENCIES = {
    YER: {
        code: 'YER',
        name: 'ريال يمني',
        shortName: 'ريال',
        symbol: 'ر.ي',
        position: 'after'    // الرمز بعد الرقم
    },
    SAR: {
        code: 'SAR',
        name: 'ريال سعودي',
        shortName: 'ريال',
        symbol: 'ر.س',
        position: 'after'
    },
    USD: {
        code: 'USD',
        name: 'دولار أمريكي',
        shortName: 'دولار',
        symbol: '$',
        position: 'before'   // الرمز قبل الرقم
    }
};


// ================================================================
// ===== 2. العملة الأساسية =====
// ================================================================

// العملة الأساسية الافتراضية (يمكن تغييرها من الإعدادات)
var baseCurrency = 'YER';


/**
 * تعيين العملة الأساسية
 * @param {string} code - رمز العملة (YER, SAR, USD)
 */
function setBaseCurrency(code) {
    if (CURRENCIES[code]) {
        baseCurrency = code;
        if (typeof enforceReferenceCurrency === 'function') enforceReferenceCurrency();
    }
}


/**
 * الحصول على العملة الأساسية
 * @returns {string}
 */
function getBaseCurrency() {
    return baseCurrency;
}


// ================================================================
// ===== 3. الحصول على بيانات العملة =====
// ================================================================

/**
 * الحصول على كائن العملة الكامل
 * @param {string} code - رمز العملة (اختياري، افتراضي: العملة الأساسية)
 * @returns {object}
 */
function getCurrency(code) {
    var c = code || baseCurrency;
    return CURRENCIES[c] || CURRENCIES[baseCurrency];
}


/**
 * الحصول على اسم العملة الكامل
 * @param {string} code
 * @returns {string}
 */
function getCurrencyName(code) {
    var currency = getCurrency(code);
    return currency ? currency.name : '';
}


/**
 * الحصول على الاسم المختصر للعملة
 * @param {string} code
 * @returns {string}
 */
function getCurrencyShortName(code) {
    var currency = getCurrency(code);
    return currency ? currency.shortName : '';
}


/**
 * الحصول على رمز العملة
 * @param {string} code
 * @returns {string}
 */
function getCurrencySymbol(code) {
    var currency = getCurrency(code);
    return currency ? currency.symbol : '';
}


// ================================================================
// ===== 4. تنسيق المبالغ =====
// ================================================================

/**
 * تنسيق رقم فقط (بدون عملة)
 * @param {any} value - القيمة
 * @param {number} decimals - عدد الخانات العشرية (افتراضي: 2)
 * @returns {string}
 */
function formatAmount(value, decimals) {
    var d = decimals !== undefined ? decimals : 2;
    var num = parseFloat(value);
    if (isNaN(num)) num = 0;
    return num.toFixed(d);
}


/**
 * تنسيق رقم مع فواصل الآلاف
 * مثال: 1234567.89 → 1,234,567.89
 * @param {any} value - القيمة
 * @param {number} decimals - عدد الخانات العشرية (افتراضي: 2)
 * @returns {string}
 */
function formatAmountWithCommas(value, decimals) {
    var d = decimals !== undefined ? decimals : 2;
    var num = parseFloat(value);
    if (isNaN(num)) num = 0;
    var fixed = num.toFixed(d);
    var parts = fixed.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
}


/**
 * تنسيق مبلغ مع رمز العملة
 * @param {any} value - القيمة
 * @param {string} currencyCode - رمز العملة (اختياري)
 * @param {boolean} showSymbol - عرض الرمز (افتراضي: true)
 * @returns {string}
 */
function formatCurrency(value, currencyCode, showSymbol) {
    var code = currencyCode || baseCurrency;
    var currency = getCurrency(code);
    var show = showSymbol !== undefined ? showSymbol : true;
    
    var amount = formatAmountWithCommas(value);
    
    if (!show || !currency) {
        return amount;
    }
    
    if (currency.position === 'before') {
        return currency.symbol + ' ' + amount;
    } else {
        return amount + ' ' + currency.symbol;
    }
}


/**
 * تنسيق مبلغ مع اسم العملة الكامل
 * @param {any} value - القيمة
 * @param {string} currencyCode
 * @returns {string}
 */
function formatCurrencyFull(value, currencyCode) {
    var code = currencyCode || baseCurrency;
    var currency = getCurrency(code);
    var amount = formatAmountWithCommas(value);
    
    if (!currency) {
        return amount;
    }
    
    return amount + ' ' + currency.name;
}


// ================================================================
// ===== 5. الحصول على قائمة العملات =====
// ================================================================

/**
 * الحصول على قائمة كل العملات (للتعبئة في القوائم)
 * @returns {array}
 */
function getCurrenciesList() {
    var list = [];
    for (var code in CURRENCIES) {
        if (CURRENCIES.hasOwnProperty(code)) {
            list.push(CURRENCIES[code]);
        }
    }
    return list;
}


/**
 * التحقق من صحة رمز العملة
 * @param {string} code
 * @returns {boolean}
 */
function isValidCurrency(code) {
    return CURRENCIES.hasOwnProperty(code);
}


// ================================================================
// ===== 6. تعبئة القوائم المنسدلة =====
// ================================================================

/**
 * تعبئة قوائم العملات في الصفحة
 * يبحث عن كل عنصر بـ class="currency-select"
 */
function populateCurrencySelects() {
    var selects = document.querySelectorAll('.currency-select');
    
    selects.forEach(function(select) {
        var currentVal = select.value;
        select.innerHTML = '';
        
        for (var code in CURRENCIES) {
            if (CURRENCIES.hasOwnProperty(code)) {
                var option = document.createElement('option');
                option.value = code;
                option.textContent = CURRENCIES[code].name;
                select.appendChild(option);
            }
        }
        
        // استعادة القيمة السابقة أو اختيار الأساسية
        if (currentVal && CURRENCIES[currentVal]) {
            select.value = currentVal;
        } else {
            select.value = baseCurrency;
        }
    });
}

function enforceReferenceCurrency() {
    document.querySelectorAll('.currency-select').forEach(function(select) {
        // ← لا تفرض شيئاً داخل النوافذ المنبثقة (Modals)
        if (select.closest && select.closest('.modal-overlay')) return;
        select.value = baseCurrency;
        select.disabled = true;
        select.setAttribute('data-reference-currency', baseCurrency);
    });
}


// ================================================================
// ===== 7. تهيئة العملات =====
// ================================================================

/**
 * تهيئة نظام العملات
 */
function initCurrency() {
    // قراءة العملة الأساسية المحفوظة
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        var settings = Storage.get(STORAGE_KEYS.SETTINGS, null);
        if (settings && settings.baseCurrency && CURRENCIES[settings.baseCurrency]) {
            baseCurrency = settings.baseCurrency;
        }
    }
    
    // تعبئة القوائم
    populateCurrencySelects();
    enforceReferenceCurrency();
    if (!window._referenceCurrencyObserver) {
        window._referenceCurrencyObserver = new MutationObserver(function() { enforceReferenceCurrency(); });
        window._referenceCurrencyObserver.observe(document.body, { childList: true, subtree: true });
    }
    
    console.log('Currency: العملة الأساسية = ' + getCurrencyName(baseCurrency));
}
// ================================================================
// ===== دالة مساعدة: عرض المبالغ بالعملة الأساسية =====
// ================================================================

/**
 * عرض مبلغ محوّل إلى العملة الأساسية
 * @param {any} value - القيمة الأصلية
 * @param {string} currency - عملة القيمة الأصلية
 * @returns {string}
 */
function displayAmount(value, currency) {
    var amount = parseFloat(value) || 0;
    var fromCurr = currency || getBaseCurrency();
    var baseCurr = getBaseCurrency();
    
    if (fromCurr !== baseCurr && typeof getEquivalent === 'function') {
        amount = getEquivalent(amount, fromCurr);
    }
    
    return formatCurrency(amount, baseCurr);
}
// ================================================================
// ===== 8. تنسيق أسعار الصرف (صيغة سهلة) =====
// ================================================================

/**
 * إرجاع صيغة سعر الصرف السهلة
 * القاعدة: 1 وحدة من العملة الأقوى = X وحدة من العملة الأضعف
 * 
 * أمثلة:
 * - 1 SAR = 530 YER
 * - 1 USD = 3.8 SAR
 * - 1 USD = 2014 YER
 * 
 * @param {string} baseCurrency - العملة المرجعية الحالية
 * @returns {string} - نص وصفي
 */
function formatExchangeRates(baseCurrency) {
    var base = baseCurrency || getBaseCurrency();
    
    // قراءة الأسعار الحالية
    var sarRate = 530;
    var usdToSarRate = 3.8;
    var usdRate = 2014;
    
    if (typeof exchangeRates !== 'undefined') {
        sarRate = parseFloat(exchangeRates.SAR) || 530;
        usdRate = parseFloat(exchangeRates.USD) || 2014;
    }
    if (typeof USD_TO_SAR !== 'undefined') {
        usdToSarRate = parseFloat(USD_TO_SAR) || 3.8;
    }
    
    var parts = [];
    
    if (base === 'YER') {
        // 1 SAR = X YER
        parts.push('1 SAR = ' + formatAmountWithCommas(sarRate, 2) + ' YER');
        // 1 USD = Y YER
        parts.push('1 USD = ' + formatAmountWithCommas(usdRate, 2) + ' YER');
    } else if (base === 'SAR') {
        // 1 SAR = X YER
        parts.push('1 SAR = ' + formatAmountWithCommas(sarRate, 2) + ' YER');
        // 1 USD = Y SAR
        parts.push('1 USD = ' + formatAmountWithCommas(usdToSarRate, 2) + ' SAR');
    } else if (base === 'USD') {
        // 1 USD = X SAR
        parts.push('1 USD = ' + formatAmountWithCommas(usdToSarRate, 2) + ' SAR');
        // 1 USD = Y YER
        parts.push('1 USD = ' + formatAmountWithCommas(usdRate, 2) + ' YER');
    }
    
    return parts.join(' | ');
}


// ================================================================
// ===== END OF CURRENCY.JS =====
// ================================================================
