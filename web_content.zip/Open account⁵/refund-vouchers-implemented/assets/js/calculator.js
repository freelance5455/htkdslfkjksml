// ================================================================
// Open Account — الآلة الحاسبة الاحترافية
// الملف: calculator.js
// النسخة: v2.0 — مع الذاكرة، الأقواس، الجذر، السجل
// ================================================================

var _calcState = {
    display: '0',              // النص المعروض
    previous: null,            // القيمة السابقة
    operator: null,            // العملية الحالية
    waitingForOperand: false,  // هل ننتظر إدخال رقم جديد؟
    memory: 0,                 // الذاكرة
    hasMemory: false,          // هل هناك قيمة في الذاكرة؟
    history: [],               // السجل (آخر 20)
    openParens: 0              // عدد الأقواس المفتوحة
};

// ================================================================
// 1. فتح النافذة
// ================================================================

function openCalculator() {
    _calcState.display = '0';
    _calcState.previous = null;
    _calcState.operator = null;
    _calcState.waitingForOperand = false;
    _calcState.openParens = 0;
    // الذاكرة والسجل يبقيان

        Modal.open({
        id: 'calculatorModal',
        title: 'الآلة الحاسبة',
        size: 'fullscreen',
        body: _buildCalculatorHTML(),
        footer: '',
        onOpen: function (modalEl) {
            _calcBindButtons(modalEl);
            _calcUpdateDisplay();
        }
    });
}
// ================================================================
// إدارة الصوت
// ================================================================

var SOUND_KEY = 'oa_calc_sound';
var _calcAudioCtx = null;

function _calcSoundEnabled() {
    try {
        return localStorage.getItem(SOUND_KEY) !== 'off';
    } catch (e) {
        return true;
    }
}

function _calcSetSound(enabled) {
    try {
        localStorage.setItem(SOUND_KEY, enabled ? 'on' : 'off');
    } catch (e) {}
}

/**
 * إعادة استخدام AudioContext — يُنشأ مرة واحدة
 */
function _calcGetAudioCtx() {
    if (_calcAudioCtx) return _calcAudioCtx;
    try {
        _calcAudioCtx = new (window.AudioContext || window.webkitAudioContext)();
    } catch (e) {
        _calcAudioCtx = null;
    }
    return _calcAudioCtx;
}

function _calcBeep() {
    if (!_calcSoundEnabled()) return;

    var ctx = _calcGetAudioCtx();
    if (!ctx) return;

    try {
        // استئناف السياق إن كان معطّلاً (سياسة المتصفح)
        if (ctx.state === 'suspended') {
            ctx.resume();
        }

        var now = ctx.currentTime;

        // مذبذبان — للحصول على نقرة أوضح
        var osc1 = ctx.createOscillator();
        var osc2 = ctx.createOscillator();
        var gain = ctx.createGain();

        osc1.type = 'square';
        osc1.frequency.value = 900;

        osc2.type = 'sine';
        osc2.frequency.value = 1400;

        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.exponentialRampToValueAtTime(0.08, now + 0.008);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc1.stop(now + 0.07);
        osc2.stop(now + 0.07);
    } catch (e) {}
}

/**
 * تفعيل AudioContext عند أول تفاعل
 */
function _calcUnlockAudio() {
    var ctx = _calcGetAudioCtx();
    if (ctx && ctx.state === 'suspended') {
        ctx.resume();
    }
}

function _calcToggleSound() {
    var current = _calcSoundEnabled();
    _calcSetSound(!current);
    _calcUpdateSoundButton();
    _calcUnlockAudio();
    _calcBeep();
}

function _calcUpdateSoundButton() {
    var btn = document.getElementById('calcSoundBtn');
    if (!btn) return;

    var enabled = _calcSoundEnabled();
    btn.className = 'calc-sound-btn ' + (enabled ? 'sound-on' : 'sound-off');
    btn.title = enabled ? 'كتم الصوت' : 'تشغيل الصوت';

    // النص الداخلي
    var label = btn.querySelector('.calc-sound-label');
    if (label) {
        label.textContent = enabled ? 'الصوت' : 'مكتوم';
    }

    // الأيقونة — تتغير حسب الحالة
    var icon = btn.querySelector('svg');
    if (icon) {
        if (enabled) {
            icon.innerHTML = 
                '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>' +
                '<path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>' +
                '<path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>';
        } else {
            icon.innerHTML = 
                '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>' +
                '<line x1="23" y1="9" x2="17" y2="15"/>' +
                '<line x1="17" y1="9" x2="23" y2="15"/>';
        }
    }
}
// ================================================================
// 2. بناء HTML الأزرار
// ================================================================

function _buildCalculatorHTML() {
    // [المفتاح, النوع, الصفوف الممتدة (اختياري)]
    var keys = [
        // الصف 1: مسح، أقواس، نسبة، قسمة
        ['AC', 'clear', ''],
        ['(', 'paren', ''],
        [')', 'paren', ''],
        ['%', 'percent', ''],
        ['÷', 'op', ''],

        // الصف 2: 7-8-9 + √ + ×
        ['7', 'num', ''],
        ['8', 'num', ''],
        ['9', 'num', ''],
        ['√', 'func-sqrt', ''],
        ['×', 'op', ''],

        // الصف 3: 4-5-6 + x² + −
        ['4', 'num', ''],
        ['5', 'num', ''],
        ['6', 'num', ''],
        ['x²', 'func-sq', ''],
        ['−', 'op', ''],

        // الصف 4: 1-2-3 + 1/x + +
        ['1', 'num', ''],
        ['2', 'num', ''],
        ['3', 'num', ''],
        ['1/x', 'func-inv', ''],
        ['+', 'op', ''],

        // الصف 5: 0, ., ⌫, = (يمتد عمودين)
        ['0', 'num', ''],
        ['.', 'num', ''],
        ['⌫', 'back', ''],
        ['=', 'eq', 'span-2'],

        // الصف 6: ذاكرة
        ['MC', 'mem-mc', ''],
        ['MR', 'mem-mr', ''],
        ['M+', 'mem-add', ''],
        ['M−', 'mem-sub', ''],
        ['M↓', 'mem-show', '']
    ];

    var buttonsHtml = keys.map(function (k) {
        var key = k[0];
        var type = k[1];
        var span = k[2] || '';

        var cls = 'calc-key calc-' + type;
        if (span === 'span-2') cls += ' calc-span-2';

        return '<button type="button" class="' + cls + '" ' +
               'data-key="' + esc(key) + '" ' +
               'data-type="' + type + '">' +
               esc(key) +
               '</button>';
    }).join('');

    var soundEnabled = _calcSoundEnabled();
var soundIcon = soundEnabled
    ? '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>' +
      '<path d="M15.54 8.46a5 5 0 0 1 0 7.07"/>' +
      '<path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>'
    : '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/>' +
      '<line x1="23" y1="9" x2="17" y2="15"/>' +
      '<line x1="17" y1="9" x2="23" y2="15"/>';

var soundBtn = 
    '<button type="button" class="calc-sound-btn ' + 
    (soundEnabled ? 'sound-on' : 'sound-off') + 
    '" id="calcSoundBtn" onclick="_calcToggleSound()" ' +
    'title="' + (soundEnabled ? 'كتم الصوت' : 'تشغيل الصوت') + '">' +
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ' +
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
            soundIcon +
        '</svg>' +
        '<span class="calc-sound-label">' + 
            (soundEnabled ? 'الصوت' : 'مكتوم') + 
        '</span>' +
    '</button>';

return '' +
    '<div class="calc-wrapper" dir="ltr">' +
        soundBtn +
        '<div class="calc-display">' +
            '<div class="calc-expression" id="calcExpression"></div>' +
            '<div class="calc-result" id="calcDisplay">0</div>' +
            '<div class="calc-memory-badge" id="calcMemoryBadge" style="display:none;">M</div>' +
        '</div>' +
        '<div class="calc-history" id="calcHistory">' +
            (_calcState.history.length ? _renderCalcHistory() : '<div class="calc-history-empty">لا يوجد سجل</div>') +
        '</div>' +
        '<div class="calc-keys" id="calcKeys">' + buttonsHtml + '</div>' +
    '</div>';
}

// ================================================================
// 3. ربط الأزرار
// ================================================================

function _calcBindButtons(modalEl) {
    var wrapper = modalEl.querySelector('.calc-wrapper');
    if (!wrapper) return;

    wrapper.addEventListener('click', function (e) {
        var t = e.target;
        var btn = null;
        while (t && t !== wrapper) {
            if (t.classList && t.classList.contains('calc-key')) { btn = t; break; }
            t = t.parentNode;
        }
        if (!btn) return;

        var key = btn.getAttribute('data-key');
        var type = btn.getAttribute('data-type');
        if (!key || !type) return;

        e.preventDefault();
        _calcPress(key, type);
    });
}

// ================================================================
// 4. عرض السجل
// ================================================================

function _renderCalcHistory() {
    return _calcState.history.slice(-5).reverse().map(function (h) {
        return '<div class="calc-history-item">' + esc(h) + '</div>';
    }).join('');
}

// ================================================================
// 5. تحديث الشاشة
// ================================================================

function _calcUpdateDisplay() {
    var d = document.getElementById('calcDisplay');
    var e = document.getElementById('calcExpression');
    var m = document.getElementById('calcMemoryBadge');
    var h = document.getElementById('calcHistory');

    if (d) d.textContent = _calcState.display;

    if (e) {
        var expr = '';
        if (_calcState.previous !== null && _calcState.operator) {
            expr = _calcState.previous + ' ' + _calcState.operator;
        }
        e.textContent = expr;
    }

    if (m) {
        m.style.display = _calcState.hasMemory ? 'block' : 'none';
        if (_calcState.hasMemory) {
            m.textContent = 'M: ' + _formatCalcNumber(_calcState.memory);
        }
    }

    if (h) {
        if (_calcState.history.length) {
            // زر مسح السجل — صغير في أعلى السجل
            var clearBtn = '<button type="button" class="calc-history-clear" ' +
                           'onclick="_calcClearHistory()" ' +
                           'title="مسح السجل">✕</button>';
            h.innerHTML = clearBtn + _renderCalcHistory();
        } else {
            h.innerHTML = '<div class="calc-history-empty">لا يوجد سجل</div>';
        }
    }
}

// ================================================================
// 6. معالجة الأزرار
// ================================================================


 function _calcPress(key, type) {

    // ✅ فتح AudioContext عند أول ضغطة (سياسة المتصفح)
    _calcUnlockAudio();
    // ✅ تشغيل صوت النقرة
    _calcBeep();

    // ===== أرقام =====
    if (type === 'num') {
        if (key === '.' && _calcState.display.indexOf('.') !== -1) return;

        if (_calcState.waitingForOperand) {
            _calcState.display = (key === '.') ? '0.' : key;
            _calcState.waitingForOperand = false;
        } else {
            if (_calcState.display === '0' && key !== '.') _calcState.display = key;
            else _calcState.display += key;
        }
    }

    // ===== عمليات ثنائية =====
    else if (type === 'op') {
        if (_calcState.operator && !_calcState.waitingForOperand) _calcCompute(false);
        _calcState.previous = _calcState.display;
        _calcState.operator = key;
        _calcState.waitingForOperand = true;
    }

    // ===== يساوي =====
    else if (type === 'eq') {
        _calcCompute(true);
    }

    // ===== نسبة مئوية =====
    else if (type === 'percent') {
        var current = parseFloat(_calcState.display);
        if (_calcState.previous !== null && _calcState.operator) {
            // مثلاً: 100 + 10% = 110
            var prev = parseFloat(_calcState.previous);
            var pctValue = (prev * current) / 100;
            _calcState.display = _formatCalcNumber(pctValue);
        } else {
            // بدون سياق: 50% = 0.5
            _calcState.display = _formatCalcNumber(current / 100);
        }
    }

    // ===== AC =====
    else if (type === 'clear') {
        _calcState.display = '0';
        _calcState.previous = null;
        _calcState.operator = null;
        _calcState.waitingForOperand = false;
        _calcState.openParens = 0;
    }

    // ===== ⌫ =====
    else if (type === 'back') {
        if (_calcState.waitingForOperand) return;
        _calcState.display = _calcState.display.length > 1
            ? _calcState.display.slice(0, -1)
            : '0';
    }

    // ===== أقواس =====
    else if (type === 'paren') {
        if (key === '(') {
            _calcState.openParens++;
            if (_calcState.waitingForOperand) {
                _calcState.display = '(';
                _calcState.waitingForOperand = false;
            } else {
                _calcState.display += '(';
            }
        } else if (key === ')') {
            if (_calcState.openParens > 0) {
                _calcState.openParens--;
                _calcState.display += ')';
                _calcState.waitingForOperand = true;
            }
        }
    }

    // ===== √ =====
    else if (type === 'func-sqrt') {
        var v = parseFloat(_calcState.display);
        if (v < 0) { _calcState.display = 'خطأ'; }
        else { _calcState.display = _formatCalcNumber(Math.sqrt(v)); }
        _calcState.waitingForOperand = true;
    }

    // ===== x² =====
    else if (type === 'func-sq') {
        var v2 = parseFloat(_calcState.display);
        _calcState.display = _formatCalcNumber(v2 * v2);
        _calcState.waitingForOperand = true;
    }

    // ===== 1/x =====
    else if (type === 'func-inv') {
        var v3 = parseFloat(_calcState.display);
        if (v3 === 0) { _calcState.display = 'خطأ'; }
        else { _calcState.display = _formatCalcNumber(1 / v3); }
        _calcState.waitingForOperand = true;
    }

    // ===== الذاكرة =====
    else if (type === 'mem-mc') {
        _calcState.memory = 0;
        _calcState.hasMemory = false;
    }
    else if (type === 'mem-mr') {
        if (_calcState.hasMemory) {
            _calcState.display = _formatCalcNumber(_calcState.memory);
            _calcState.waitingForOperand = true;
        }
    }
    else if (type === 'mem-add') {
        _calcState.memory += parseFloat(_calcState.display) || 0;
        _calcState.hasMemory = true;
        _calcState.waitingForOperand = true;
    }
    else if (type === 'mem-sub') {
        _calcState.memory -= parseFloat(_calcState.display) || 0;
        _calcState.hasMemory = true;
        _calcState.waitingForOperand = true;
    }
    else if (type === 'mem-show') {
        if (typeof showToast === 'function') {
            showToast('الذاكرة: ' + _formatCalcNumber(_calcState.memory), 'info', 3000);
        }
    }

    _calcUpdateDisplay();
}

// ================================================================
// 7. الحساب
// ================================================================

function _calcCompute(isEquals) {
    var a = parseFloat(_calcState.previous);
    var b = parseFloat(_calcState.display);
    if (!isFinite(a) || !isFinite(b)) return;

    var result = 0;
    switch (_calcState.operator) {
        case '+': result = a + b; break;
        case '−': result = a - b; break;
        case '×': result = a * b; break;
        case '÷': result = b === 0 ? NaN : a / b; break;
        default: return;
    }

    if (!isFinite(result)) {
        _calcState.display = 'خطأ';
        _calcState.previous = null;
        _calcState.operator = null;
        _calcState.waitingForOperand = true;
        return;
    }

    var display = _formatCalcNumber(result);

    if (isEquals) {
        var entry = _calcState.previous + ' ' + _calcState.operator + ' ' +
                    _calcState.display + ' = ' + display;
        _calcState.history.push(entry);
        if (_calcState.history.length > 20) _calcState.history.shift();
        _calcState.previous = null;
        _calcState.operator = null;
    } else {
        _calcState.previous = display;
    }

    _calcState.display = display;
    _calcState.waitingForOperand = true;
}

// ================================================================
// 8. تنسيق الأرقام
// ================================================================

function _formatCalcNumber(n) {
    if (!isFinite(n)) return 'خطأ';
    if (Number.isInteger(n)) return String(n);
    var s = n.toFixed(8).replace(/\.?0+$/, '');
    return s;
}

// ================================================================
// 9. مسح السجل
// ================================================================

function _calcClearHistory() {
    _calcState.history = [];
    _calcUpdateDisplay();
}

// ================================================================
// 10. التهيئة
// ================================================================

function initCalculator() {
    var b = document.getElementById('btnCalculator');
    if (b) {
        var newB = b.cloneNode(true);
        b.parentNode.replaceChild(newB, b);
        newB.addEventListener('click', openCalculator);
    }
}

// ================================================================
// قائمة الأدوات المنسدلة
// ================================================================

function initToolsMenu() {
    var btn = document.getElementById('btnToolsMenu');
    var menu = document.getElementById('toolsMenu');
    if (!btn || !menu) return;

    var newBtn = btn.cloneNode(true);
    btn.parentNode.replaceChild(newBtn, btn);
    newBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        menu.classList.toggle('active');
    });

    document.addEventListener('click', function (e) {
        if (menu.classList.contains('active') &&
            !menu.contains(e.target) &&
            !newBtn.contains(e.target)) {
            menu.classList.remove('active');
        }
    });

    menu.querySelectorAll('.tools-menu-item').forEach(function (item) {
        item.addEventListener('click', function () {
            menu.classList.remove('active');
        });
    });
}

document.addEventListener('DOMContentLoaded', initToolsMenu);

// الواجهة العامة للصوت
window._calcToggleSound = _calcToggleSound;


