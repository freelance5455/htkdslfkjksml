// ================================================================
// Open Account — نظام محاسبي
// الملف: toast.js
// الوصف: عرض رسائل التنبيه (Toast Notifications)
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var _toastTimeout = null;
var _toastDuration = 3000; // مدة ظهور الرسالة (مللي ثانية)


// ================================================================
// ===== 2. أيقونات SVG =====
// ================================================================

var TOAST_ICONS = {
    success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>',
    
    error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
    
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
    
    warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
};


// ================================================================
// ===== 3. الدالة الرئيسية =====
// ================================================================

/**
 * عرض رسالة تنبيه
 * @param {string} message - نص الرسالة
 * @param {string} type - النوع: 'success' | 'error' | 'info' | 'warning'
 * @param {number} duration - المدة بالمللي ثانية (اختياري)
 */
function showToast(message, type, duration) {
    // النوع الافتراضي
    var toastType = type || 'success';
    
    // المدة
    var toastDuration = duration !== undefined ? duration : _toastDuration;
    
    // الحصول على العناصر
    var toast = document.getElementById('toast');
    var toastMessage = document.getElementById('toastMessage');
    var toastIcon = toast ? toast.querySelector('.toast-icon') : null;
    
    // إذا لم توجد الحاوية، أنشئها ديناميكياً
    if (!toast) {
        createToastContainer();
        toast = document.getElementById('toast');
        toastMessage = document.getElementById('toastMessage');
        toastIcon = toast ? toast.querySelector('.toast-icon') : null;
    }
    
    if (!toast || !toastMessage) return;
    
    // تعيين الرسالة
    toastMessage.textContent = message || 'تم بنجاح';
    
    // إزالة الأنواع السابقة
    toast.classList.remove('error', 'info', 'warning');
    
    // تعيين النوع
    if (toastType === 'error') {
        toast.classList.add('error');
    } else if (toastType === 'info') {
        toast.classList.add('info');
    } else if (toastType === 'warning') {
        toast.classList.add('warning');
    }
    
    // تعيين الأيقونة
    if (toastIcon) {
        var iconSvg = TOAST_ICONS[toastType] || TOAST_ICONS.success;
        toastIcon.innerHTML = iconSvg;
    }
    
    // إظهار الرسالة
    toast.classList.add('show');
    
    // إخفاء بعد المدة المحددة
    clearTimeout(_toastTimeout);
    _toastTimeout = setTimeout(function() {
        toast.classList.remove('show');
    }, toastDuration);
}


// ================================================================
// ===== 4. إنشاء حاوية Toast ديناميكياً =====
// ================================================================

/**
 * إنشاء حاوية Toast إذا لم تكن موجودة
 */
function createToastContainer() {
    if (document.getElementById('toast')) return;
    
    var toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    
    toast.innerHTML = 
        '<div class="toast-icon"></div>' +
        '<div class="toast-message" id="toastMessage">تم بنجاح</div>';
    
    document.body.appendChild(toast);
}


// ================================================================
// ===== 5. اختصارات =====
// ================================================================

/**
 * رسالة نجاح
 * @param {string} message
 * @param {number} duration
 */
function toastSuccess(message, duration) {
    showToast(message, 'success', duration);
}


/**
 * رسالة خطأ
 * @param {string} message
 * @param {number} duration
 */
function toastError(message, duration) {
    showToast(message, 'error', duration);
}


/**
 * رسالة معلومات
 * @param {string} message
 * @param {number} duration
 */
function toastInfo(message, duration) {
    showToast(message, 'info', duration);
}


/**
 * رسالة تحذير
 * @param {string} message
 * @param {number} duration
 */
function toastWarning(message, duration) {
    showToast(message, 'warning', duration);
}


// ================================================================
// ===== END OF TOAST.JS =====
// ================================================================