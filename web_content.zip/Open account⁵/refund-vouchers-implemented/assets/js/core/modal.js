// ================================================================
// Open Account — نظام محاسبي
// الملف: modal.js
// الوصف: نظام موحد لإدارة النوافذ المنبثقة
// ================================================================


// ================================================================
// ===== 1. الكائن الرئيسي =====
// ================================================================

const Modal = {
    
    // الحاوية الرئيسية
    _container: null,
    
    // قائمة النوافذ المفتوحة حالياً
    _openModals: [],
    
    
    // ============================================================
    // ===== 2. تهيئة الحاوية =====
    // ============================================================
    
    /**
     * تهيئة حاوية النوافذ
     */
    init: function() {
        this._container = document.getElementById('modalContainer');
        
        if (!this._container) {
            this._container = document.createElement('div');
            this._container.id = 'modalContainer';
            document.body.appendChild(this._container);
        }
    },
    
    
    // ============================================================
    // ===== 3. فتح نافذة جديدة =====
    // ============================================================
    
    /**
     * فتح نافذة منبثقة
     * @param {object} config - إعدادات النافذة
     *   - id: معرف فريد للنافذة
     *   - title: العنوان
     *   - size: 'normal' | 'large'
     *   - body: محتوى HTML الجسم
     *   - footer: أزرار التذييل (HTML)
     *   - onOpen: دالة تُستدعى بعد الفتح
     *   - onClose: دالة تُستدعى بعد الإغلاق
     */
    open: function(config) {
        if (!this._container) this.init();
        
        var id = config.id || 'modal_' + Date.now();
        var title = config.title || '';
        var size = config.size || 'normal';
        var body = config.body || '';
        var footer = config.footer || '';
        
        // منع التكرار
        if (document.getElementById(id)) {
            return;
        }
        
        // بناء HTML النافذة
        var html = this._buildHTML({
            id: id,
            title: title,
            size: size,
            body: body,
            footer: footer
        });
        
        // إضافة إلى الحاوية
        this._container.insertAdjacentHTML('beforeend', html);
        
        // الحصول على العنصر
        var modalEl = document.getElementById(id);
        
        // ربط الأحداث
        this._bindEvents(modalEl, config);
        
        // إظهار النافذة (مع تأخير بسيط لتفعيل الحركة)
        requestAnimationFrame(function() {
            modalEl.classList.add('active');
        });
        
        // إضافة إلى قائمة المفتوحة
        this._openModals.push(id);
        
        // قفل التمرير في الصفحة
        document.body.style.overflow = 'hidden';
        
        // استدعاء onOpen
        if (typeof config.onOpen === 'function') {
            setTimeout(function() {
                config.onOpen(modalEl);
            }, 100);
        }
        
        return id;
    },
    
    
    // ============================================================
    // ===== 4. بناء HTML النافذة =====
    // ============================================================
    
    _buildHTML: function(config) {
        var sizeClass = config.size === 'large' ? ' large' : '';
        
        var headerHTML = 
            '<div class="modal-header">' +
                '<h2>' + esc(config.title) + '</h2>' +
                '<button class="modal-close" data-modal-close="' + config.id + '" title="إغلاق">×</button>' +
            '</div>';
        
        var bodyHTML = 
            '<div class="modal-body">' +
                config.body +
            '</div>';
        
        var footerHTML = '';
        if (config.footer) {
            footerHTML = 
                '<div class="modal-footer">' +
                    config.footer +
                '</div>';
        }
        
        return '' +
            '<div class="modal-overlay" id="' + config.id + '" data-modal="' + config.id + '">' +
                '<div class="modal-box' + sizeClass + '">' +
                    headerHTML +
                    bodyHTML +
                    footerHTML +
                '</div>' +
            '</div>';
    },
    
    
    // ============================================================
    // ===== 5. ربط الأحداث =====
    // ============================================================
    
    _bindEvents: function(modalEl, config) {
        var self = this;
        
        // زر الإغلاق
        var closeBtn = modalEl.querySelector('.modal-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                self.close(config.id);
            });
        }
        
        // الضغط على الخلفية
        modalEl.addEventListener('click', function(e) {
            if (e.target === modalEl) {
                self.close(config.id);
            }
        });
        
        // زر Escape
        var escHandler = function(e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                self.close(config.id);
                document.removeEventListener('keydown', escHandler);
            }
        };
        document.addEventListener('keydown', escHandler);
    },
    
    
    // ============================================================
    // ===== 6. إغلاق نافذة =====
    // ============================================================
    
    /**
     * إغلاق نافذة بمعرفها
     * @param {string} id - معرف النافذة
     */
    close: function(id) {
        var modalEl = document.getElementById(id);
        if (!modalEl) return;
        
        // إخفاء النافذة
        modalEl.classList.remove('active');
        
        // إزالة من القائمة
        var index = this._openModals.indexOf(id);
        if (index !== -1) {
            this._openModals.splice(index, 1);
        }
        
        // إزالة من DOM بعد انتهاء الحركة
        setTimeout(function() {
            if (modalEl.parentNode) {
                modalEl.parentNode.removeChild(modalEl);
            }
        }, 300);
        
        // إلغاء قفل التمرير إذا لم تبق نوافذ
        if (this._openModals.length === 0) {
            document.body.style.overflow = '';
        }
    },
    
    
    // ============================================================
    // ===== 7. إغلاق جميع النوافذ =====
    // ============================================================
    
    closeAll: function() {
        var self = this;
        var ids = this._openModals.slice();
        ids.forEach(function(id) {
            self.close(id);
        });
    },
    
    
    // ============================================================
    // ===== 8. نافذة تأكيد جاهزة =====
    // ============================================================
    
    /**
     * نافذة تأكيد سريعة
     * @param {object} options
     *   - title: العنوان
     *   - message: الرسالة
     *   - confirmText: نص زر التأكيد
     *   - cancelText: نص زر الإلغاء
     *   - confirmColor: 'danger' | 'primary' | 'warning' | 'success'
     *   - onConfirm: دالة تُستدعى عند التأكيد
     *   - onCancel: دالة تُستدعى عند الإلغاء (اختياري)
     */
    confirm: function(options) {
        var id = 'confirm_' + Date.now();
        
        var confirmColor = options.confirmColor || 'danger';
        var confirmText = options.confirmText || 'تأكيد';
        var cancelText = options.cancelText || 'إلغاء';
        
        var footer = 
            '<button class="btn btn-cancel" data-confirm-action="cancel">' + esc(cancelText) + '</button>' +
            '<button class="btn btn-' + confirmColor + '" data-confirm-action="confirm">' + esc(confirmText) + '</button>';
        
        var body = 
            '<div style="text-align:center;padding:12px 0;">' +
                '<p style="font-size:14px;color:var(--color-text);line-height:1.6;">' + 
                    esc(options.message || 'هل أنت متأكد؟') + 
                '</p>' +
            '</div>';
        
        var self = this;
        
        this.open({
            id: id,
            title: options.title || 'تأكيد',
            size: 'normal',
            body: body,
            footer: footer,
            onOpen: function(modalEl) {
                // ربط أزرار التأكيد
                var confirmBtn = modalEl.querySelector('[data-confirm-action="confirm"]');
                var cancelBtn = modalEl.querySelector('[data-confirm-action="cancel"]');
                
                if (confirmBtn) {
                    confirmBtn.addEventListener('click', function() {
                        self.close(id);
                        if (typeof options.onConfirm === 'function') {
                            setTimeout(options.onConfirm, 200);
                        }
                    });
                }
                
                if (cancelBtn) {
                    cancelBtn.addEventListener('click', function() {
                        self.close(id);
                        if (typeof options.onCancel === 'function') {
                            setTimeout(options.onCancel, 200);
                        }
                    });
                }
            }
        });
        
        return id;
    }
};


// ================================================================
// ===== دوال مساعدة للاختصار =====
// ================================================================

/**
 * فتح نافذة
 */
function openModal(config) {
    return Modal.open(config);
}

/**
 * إغلاق نافذة
 */
function closeModal(id) {
    Modal.close(id);
}

/**
 * إغلاق جميع النوافذ
 */
function closeAllModals() {
    Modal.closeAll();
}

/**
 * نافذة تأكيد سريعة
 */
function confirmModal(options) {
    return Modal.confirm(options);
}


// ================================================================
// ===== END OF MODAL.JS =====
// ================================================================