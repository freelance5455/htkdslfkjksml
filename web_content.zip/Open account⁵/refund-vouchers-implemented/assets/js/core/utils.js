// ================================================================
// Open Account — نظام محاسبي
// الملف: utils.js
// الوصف: دوال مساعدة عامة (توليد IDs، تنسيق الأرقام، الأمان، التواريخ)
// ================================================================


// ================================================================
// ===== 1. توليد معرفات فريدة =====
// ================================================================

/**
 * توليد معرف فريد
 * الصيغة: 4 أرقام + حرفان (مثال: 1234AB)
 * @returns {string}
 */
function generateId() {
    var num = Math.floor(1000 + Math.random() * 9000);
    var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    var letters = '';
    letters += chars.charAt(Math.floor(Math.random() * chars.length));
    letters += chars.charAt(Math.floor(Math.random() * chars.length));
    return num + letters;
}


/**
 * توليد رقم مستند تسلسلي
 * @param {string} prefix - البادئة (مثل: SI, PI, RCP, PAY)
 * @returns {string}
 */
function generateDocNumber(prefix) {
    var timestamp = Date.now().toString(36).toUpperCase();
    return prefix + '-' + timestamp;
}


// ================================================================
// ===== 2. الحماية من XSS =====
// ================================================================

/**
 * حماية النصوص من HTML Injection
 * @param {any} str - النص
 * @returns {string} - النص الآمن
 */
function esc(str) {
    if (str === null || str === undefined) return '';
    return String(str).replace(/[&<>"']/g, function(c) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[c] || c;
    });
}


// ================================================================
// ===== 3. تنسيق الأرقام =====
// ================================================================

/**
 * تنسيق رقم بفاصلة عشرية
 * @param {number} num - الرقم
 * @param {number} decimals - عدد الخانات العشرية (افتراضي: 2)
 * @returns {string}
 */
function formatNumber(num, decimals) {
    if (isNaN(num) || num === null || num === undefined) return '0.00';
    var d = decimals !== undefined ? decimals : 2;
    return Number(num).toFixed(d);
}


/**
 * تنسيق رقم مع فواصل الآلاف
 * مثال: 1234567.89 → 1,234,567.89
 * @param {number} num - الرقم
 * @param {number} decimals - عدد الخانات العشرية (افتراضي: 2)
 * @returns {string}
 */
function formatMoney(num, decimals) {
    if (isNaN(num) || num === null || num === undefined) return '0.00';
    var d = decimals !== undefined ? decimals : 2;
    var fixed = Number(num).toFixed(d);
    var parts = fixed.split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return parts.join('.');
}


/**
 * تحويل رقم إلى رقم صحيح أو عشري
 * @param {any} value - القيمة
 * @returns {number}
 */
function toNumber(value) {
    var n = parseFloat(value);
    return isNaN(n) ? 0 : n;
}


/**
 * تحويل إلى رقم صحيح
 * @param {any} value - القيمة
 * @returns {number}
 */
function toInt(value) {
    var n = parseInt(value);
    return isNaN(n) ? 0 : n;
}


// ================================================================
// ===== 4. تنسيق التواريخ =====
// ================================================================

/**
 * الحصول على تاريخ اليوم بصيغة YYYY-MM-DD
 * @returns {string}
 */
function todayISO() {
    return new Date().toISOString().split('T')[0];
}


/**
 * تنسيق التاريخ للعرض (كما هو)
 * @param {string} dateStr - التاريخ
 * @returns {string}
 */
function formatDate(dateStr) {
    if (!dateStr) return '-';
    return dateStr;
}


/**
 * عرض تاريخ اليوم بالعربية
 * @returns {string}
 */
function todayArabic() {
    var now = new Date();
    try {
        return now.toLocaleDateString('ar-EG', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    } catch (e) {
        return now.toLocaleDateString('ar');
    }
}


/**
 * الحصول على أول يوم من الشهر الحالي
 * @returns {string} - YYYY-MM-DD
 */
function firstDayOfMonthISO() {
    var d = new Date();
    d.setDate(1);
    return d.toISOString().split('T')[0];
}


// ================================================================
// ===== 5. التحقق من صحة البيانات =====
// ================================================================

/**
 * التحقق من أن النص غير فارغ
 * @param {string} str
 * @returns {boolean}
 */
function isNotEmpty(str) {
    return str !== null && str !== undefined && String(str).trim().length > 0;
}


/**
 * التحقق من رقم صحيح موجب
 * @param {any} value
 * @returns {boolean}
 */
function isPositive(value) {
    var n = parseFloat(value);
    return !isNaN(n) && n > 0;
}


// ================================================================
// ===== 6. دوال DOM مساعدة =====
// ================================================================

/**
 * تعيين نص لعنصر
 * @param {string} id - معرف العنصر
 * @param {any} value - القيمة
 */
function setText(id, value) {
    var el = document.getElementById(id);
    if (el) el.textContent = value;
}


/**
 * الحصول على قيمة عنصر
 * @param {string} id - معرف العنصر
 * @returns {string}
 */
function getValue(id) {
    var el = document.getElementById(id);
    return el ? el.value : '';
}


/**
 * تعيين قيمة لعنصر
 * @param {string} id - معرف العنصر
 * @param {any} value - القيمة
 */
function setValue(id, value) {
    var el = document.getElementById(id);
    if (el) el.value = value !== undefined && value !== null ? value : '';
}


/**
 * البحث عن عنصر بالمعرف
 * @param {string} id
 * @returns {HTMLElement|null}
 */
function $(id) {
    return document.getElementById(id);
}


/**
 * البحث عن عناصر بـ CSS selector
 * @param {string} selector
 * @returns {NodeList}
 */
function $$(selector) {
    return document.querySelectorAll(selector);
}


// ================================================================
// ===== 7. دوال مصفوفات =====
// ================================================================

/**
 * ترتيب مصفوفة حسب تاريخ (تنازلي)
 * @param {array} arr - المصفوفة
 * @param {string} field - اسم حقل التاريخ (افتراضي: date)
 * @returns {array}
 */
function sortByDateDesc(arr, field) {
    var f = field || 'date';
    return arr.slice().sort(function(a, b) {
        return String(b[f] || '').localeCompare(String(a[f] || ''));
    });
}


/**
 * ترتيب مصفوفة حسب تاريخ (تصاعدي)
 * @param {array} arr
 * @param {string} field
 * @returns {array}
 */
function sortByDateAsc(arr, field) {
    var f = field || 'date';
    return arr.slice().sort(function(a, b) {
        return String(a[f] || '').localeCompare(String(b[f] || ''));
    });
}


/**
 * البحث في مصفوفة بحقول محددة
 * @param {array} arr - المصفوفة
 * @param {string} query - نص البحث
 * @param {array} fields - الحقول
 * @returns {array}
 */
function filterArray(arr, query, fields) {
    if (!query) return arr.slice();
    var q = String(query).toLowerCase().trim();
    return arr.filter(function(item) {
        return fields.some(function(field) {
            var val = item[field];
            if (val === null || val === undefined) return false;
            return String(val).toLowerCase().indexOf(q) !== -1;
        });
    });
}


// ================================================================
// ===== 8. دوال تأخير =====
// ================================================================

/**
 * تأخير تنفيذ دالة (debounce)
 * مفيد للبحث أثناء الكتابة
 * @param {function} func - الدالة
 * @param {number} wait - الوقت بالمللي ثانية
 * @returns {function}
 */
function debounce(func, wait) {
    var timeout;
    return function() {
        var context = this;
        var args = arguments;
        clearTimeout(timeout);
        timeout = setTimeout(function() {
            func.apply(context, args);
        }, wait);
    };
}

// ================================================================
// ===== 8.5 طباعة المستندات الفردية كنص قابل للبحث =====
// ================================================================

function printIndividualDocument(type, id) {
    var canonicalMap = {
        sales: { list: typeof salesInvoices !== 'undefined' ? salesInvoices : [], builder: typeof _buildSalesInvoiceView === 'function' ? _buildSalesInvoiceView : null, title: 'فاتورة بيع' },
        purchases: { list: typeof purchaseInvoices !== 'undefined' ? purchaseInvoices : [], builder: typeof _buildPurchaseInvoiceView === 'function' ? _buildPurchaseInvoiceView : null, title: 'فاتورة شراء' },
        receipts: { list: typeof receipts !== 'undefined' ? receipts : [], builder: typeof _buildReceiptView === 'function' ? _buildReceiptView : null, title: 'سند قبض' },
        payments: { list: typeof payments !== 'undefined' ? payments : [], builder: typeof _buildPaymentView === 'function' ? _buildPaymentView : null, title: 'سند صرف' }
    };
    var canonical = canonicalMap[type];
    if (canonical && canonical.builder) {
        var canonicalDoc = canonical.list.find(function(item) { return item.id === id; });
        if (!canonicalDoc) return showToast('المستند غير موجود', 'error');
        Modal.open({
            id: 'individualPrintModal', title: 'معاينة ' + canonical.title, size: 'large',
            body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + canonical.builder(canonicalDoc) + '</div>',
            footer: '<button class="btn btn-cancel" onclick="closeModal(\'individualPrintModal\')">إغلاق</button>' +
                    '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
        });
        return;
    }
    var source;
    var title;
    var meta = [];
    var columns = [];
    var rows = [];
    var totals = [];
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};

    if (type === 'sales') {
        source = (salesInvoices || []).find(function(item) { return item.id === id; });
        title = 'فاتورة بيع';
        if (!source) return showToast('الفاتورة غير موجودة', 'error');
        meta = [['رقم الفاتورة', source.id], ['العميل', source.customerName], ['التاريخ', source.date], ['النوع', source.type], ['الحالة', source.status], ['العملة', source.currency || 'YER']];
        columns = ['#', 'المنتج', 'الكمية', 'السعر', 'الإجمالي'];
        (source.items || []).forEach(function(item, index) { var displayQty = item.inputQty !== undefined ? item.inputQty + ' ' + (item.inputUnit || item.baseUnit || 'وحدة') : item.qty; var displayPrice = item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price; rows.push([index + 1, item.name, displayQty, displayPrice, (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0)]); });
        totals = [['الإجمالي قبل الخصم', source.subtotal !== undefined ? source.subtotal : source.total, source.currency || 'YER'], ['الخصم', source.discount || 0, source.currency || 'YER'], ['الإجمالي النهائي', source.total, source.currency || 'YER']];
    } else if (type === 'purchases') {
        source = (purchaseInvoices || []).find(function(item) { return item.id === id; });
        title = 'فاتورة شراء';
        if (!source) return showToast('الفاتورة غير موجودة', 'error');
        meta = [['رقم الفاتورة', source.id], ['رقم فاتورة المورد', source.supplierInvoiceNumber || '-'], ['المورد', source.supplierName], ['التاريخ', source.date], ['النوع', source.type], ['الحالة', source.status], ['العملة', source.currency || 'YER']];
        columns = ['#', 'المنتج', 'الكمية', 'السعر', 'الإجمالي'];
        (source.items || []).forEach(function(item, index) { var displayQty = item.inputQty !== undefined ? item.inputQty + ' ' + (item.inputUnit || item.baseUnit || 'وحدة') : item.qty; var displayPrice = item.inputUnitPrice !== undefined ? item.inputUnitPrice : item.price; rows.push([index + 1, item.name, displayQty, displayPrice, (parseFloat(item.price) || 0) * (parseFloat(item.qty) || 0)]); });
        totals = [['الإجمالي قبل الخصم', source.subtotal !== undefined ? source.subtotal : source.total, source.currency || 'YER'], ['الخصم', source.discount || 0, source.currency || 'YER'], ['الإجمالي النهائي', source.total, source.currency || 'YER']];
    } else if (type === 'receipts') {
        source = (receipts || []).find(function(item) { return item.id === id; });
        title = 'سند قبض';
        if (!source) return showToast('السند غير موجود', 'error');
        meta = [['رقم السند', source.id], ['العميل', source.customerName], ['الفاتورة', source.invoiceId], ['التاريخ', source.date], ['طريقة الدفع', source.method], ['الحالة', source.status], ['العملة', source.currency || 'YER']];
        columns = ['البيان', 'المبلغ'];
        rows = [['قيمة الفاتورة', source.invoiceTotal || 0], ['المدفوع سابقاً', source.paidBefore || 0], ['المبلغ المدفوع', source.amount || 0], ['المتبقي', source.remainingAfter || 0]];
        totals = [['المبلغ المدفوع', source.amount || 0, source.currency || 'YER']];
    } else if (type === 'payments') {
        source = (payments || []).find(function(item) { return item.id === id; });
        title = 'سند صرف';
        if (!source) return showToast('السند غير موجود', 'error');
        meta = [['رقم السند', source.id], ['المورد', source.supplierName], ['الفاتورة', source.invoiceId], ['التاريخ', source.date], ['طريقة الدفع', source.method], ['الحالة', source.status], ['العملة', source.currency || 'YER']];
        columns = ['البيان', 'المبلغ'];
        rows = [['قيمة الفاتورة', source.invoiceTotal || 0], ['المدفوع سابقاً', source.paidBefore || 0], ['المبلغ المدفوع', source.amount || 0], ['المتبقي', source.remainingAfter || 0]];
        totals = [['المبلغ المدفوع', source.amount || 0, source.currency || 'YER']];
    } else {
        showToast('نوع المستند غير مدعوم', 'error');
        return;
    }

    var payload = {
        version: 1,
        title: title,
        company: { name: settings.name || 'Open Account', address: settings.address || '', phone: settings.phone || '' },
        meta: meta,
        columns: columns,
        rows: rows,
        totals: totals,
        note: source.note || '',
        createdAt: new Date().toISOString()
    };
    try {
        localStorage.setItem('oa_print_payload', JSON.stringify(payload));
        var printWindow = window.open('print.html', '_blank');
        if (!printWindow) showToast('تعذر فتح صفحة الطباعة؛ اسمح بفتح النوافذ المنبثقة', 'error');
    } catch (error) {
        console.error('Document print error:', error);
        showToast('تعذر تجهيز المستند للطباعة', 'error');
    }
}

function printHtmlDocument(title, html, meta) {
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    try {
        localStorage.setItem('oa_print_payload', JSON.stringify({
            version: 2,
            title: title || 'تقرير',
            company: { name: settings.name || 'Open Account', address: settings.address || '', phone: settings.phone || '' },
            meta: meta || [],
            html: html || '',
            createdAt: new Date().toISOString()
        }));
        var printWindow = window.open('print.html', '_blank');
        if (!printWindow) showToast('تعذر فتح صفحة الطباعة؛ اسمح بالنوافذ المنبثقة', 'error');
    } catch (error) {
        console.error('HTML print error:', error);
        showToast('تعذر تجهيز التقرير للطباعة', 'error');
    }
}

function printTableReport(title, tableId, meta) {
    var table = document.getElementById(tableId);
    if (!table) return showToast('لم يتم العثور على جدول التقرير', 'error');
    var source = table.closest ? table.closest('table') : table.parentNode;
    printHtmlDocument(title, source ? source.outerHTML : table.outerHTML, meta || []);
}

// ================================================================
// ===== 9. طباعة المستند الحالي (PDF A4 حقيقي) =====
// ================================================================

async function _printCurrentDoc() {
    try {
        // 1. ابحث عن doc-wrapper في أي نافذة
        var content = null;
        var bodies = document.querySelectorAll('.modal-body');

        for (var i = 0; i < bodies.length; i++) {
            var wrapper = bodies[i].querySelector('.doc-wrapper');
            if (wrapper) {
                content = wrapper;
                break;
            }
        }

        if (!content) {
            var allWrappers = document.querySelectorAll('.doc-wrapper');
            if (allWrappers.length > 0) {
                content = allWrappers[allWrappers.length - 1];
            }
        }

        if (!content) {
            if (typeof showToast === 'function') {
                showToast('لم يتم العثور على المستند', 'error');
            }
            return;
        }

        // 2. اقرأ عنوان المستند
        var titleEl = content.querySelector('.doc-title');
        var title = titleEl ? titleEl.textContent.trim() : 'مستند';

        // 3. استدعِ printHtmlDocument — الموجود في الملف نفسه
        //    وهو يستخدم print.html
        printHtmlDocument(title, content.outerHTML, []);

    } catch (e) {
        console.error('Print error:', e);
        if (typeof showToast === 'function') {
            showToast('خطأ: ' + e.message, 'error');
        }
    }
}

// ================================================================
// ===== 10. دوال PDF (تُستدعى من onclick مباشرة) =====
// ================================================================

var _currentPdfUrl = null;
var _currentPdfName = 'document.pdf';

function _showPdfOptions(pdfUrl, fileName) {
    _currentPdfUrl = pdfUrl;
    _currentPdfName = fileName;
    
    try {
        if (typeof closeModal === 'function') {
            closeModal('slPrintModal');
            closeModal('clPrintModal');
        }
    } catch(e) {}
    
    setTimeout(function() {
        var bodyHTML = 
            '<div style="text-align:center;padding:10px 0;">' +
                '<div style="background:rgba(0,214,143,0.1);border:1px solid rgba(0,214,143,0.3);border-radius:8px;padding:12px;margin-bottom:16px;">' +
                    '<div style="font-size:14px;color:var(--color-green);font-weight:700;margin-bottom:4px;">تم إنشاء PDF</div>' +
                    '<div style="font-size:11px;color:var(--color-text-2);">' + esc(fileName) + '</div>' +
                '</div>' +
                
                '<div style="display:flex;flex-direction:column;gap:10px;">' +
                    '<button type="button" class="btn btn-primary" onclick="_pdfOpen()" style="padding:14px;font-size:14px;cursor:pointer;">' +
                        'فتح PDF' +
                    '</button>' +
                    '<button type="button" class="btn btn-success" onclick="_pdfShare()" style="padding:14px;font-size:14px;cursor:pointer;">' +
                        'مشاركة / حفظ' +
                    '</button>' +
                    '<button type="button" class="btn btn-cancel" onclick="_pdfDownload()" style="padding:14px;font-size:14px;cursor:pointer;">' +
                        'تنزيل مباشر' +
                    '</button>' +
                '</div>' +
                
                '<div style="margin-top:16px;padding:10px;background:rgba(0,212,255,0.1);border-radius:6px;font-size:11px;color:var(--color-text-2);text-align:right;">' +
                    '<strong>ملاحظة:</strong> اختر "مشاركة / حفظ" لحفظ الـ PDF في الملفات أو إرساله.' +
                '</div>' +
            '</div>';
        
        Modal.open({
            id: 'pdfOptionsModal',
            title: 'خيارات PDF',
            size: 'normal',
            body: bodyHTML,
            footer: '<button class="btn btn-cancel" onclick="closeModal(\'pdfOptionsModal\')">إغلاق</button>'
        });
    }, 300);
}

function _pdfOpen() {
    if (!_currentPdfUrl) {
        showToast('لا يوجد PDF', 'error');
        return;
    }
    
    try {
        var parts = _currentPdfUrl.split(',');
        var mime = parts[0].match(/:(.*?);/)[1];
        var binary = atob(parts[1]);
        var array = [];
        for (var i = 0; i < binary.length; i++) {
            array.push(binary.charCodeAt(i));
        }
        var blob = new Blob([new Uint8Array(array)], { type: mime });
        var blobUrl = URL.createObjectURL(blob);
        
        console.log('PDF Blob size:', blob.size);
        
        var bodyHTML = 
            '<div style="width:100%;">' +
                '<iframe ' +
                    'src="' + blobUrl + '" ' +
                    'style="width:100%;height:70vh;border:1px solid var(--color-border);border-radius:8px;background:#fff;" ' +
                '></iframe>' +
                '<div style="margin-top:12px;padding:10px;background:rgba(0,212,255,0.1);border-radius:6px;font-size:11px;color:var(--color-text-2);text-align:right;">' +
                    '<strong>ملاحظة:</strong> إذا لم يظهر PDF، استخدم "تنزيل مباشر" أو "مشاركة".' +
                '</div>' +
            '</div>';
        
        Modal.open({
            id: 'pdfViewModal',
            title: 'معاينة PDF',
            size: 'large',
            body: bodyHTML,
            footer: 
                '<button class="btn btn-cancel" onclick="closeModal(\'pdfViewModal\')">إغلاق</button>' +
                '<button class="btn btn-success" onclick="_pdfDownload()">تنزيل</button>' +
                '<button class="btn btn-primary" onclick="_pdfShare()">مشاركة</button>'
        });
        
    } catch(err) {
        console.error('Open failed:', err);
        showToast('تعذّر عرض PDF: ' + err.message, 'error');
    }
}

function _pdfShare() {
    if (!_currentPdfUrl) {
        showToast('لا يوجد PDF', 'error');
        return;
    }
    
    if (!navigator.share) {
        showToast('المشاركة غير مدعومة — استخدم "تنزيل مباشر"', 'info');
        _pdfDownload();
        return;
    }
    
    try {
        // تحويل Base64 إلى Blob
        var parts = _currentPdfUrl.split(',');
        var mime = parts[0].match(/:(.*?);/)[1];
        var binary = atob(parts[1]);
        var array = [];
        for (var i = 0; i < binary.length; i++) {
            array.push(binary.charCodeAt(i));
        }
        var blob = new Blob([new Uint8Array(array)], { type: mime });
        var file = new File([blob], _currentPdfName, { type: 'application/pdf' });
        
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            navigator.share({
                files: [file],
                title: 'كشف حساب',
                text: 'كشف حساب PDF'
            }).then(function() {
                showToast('تمت المشاركة', 'success');
            }).catch(function(err) {
                if (err.name !== 'AbortError') {
                    console.error('Share failed:', err);
                    showToast('تعذّر المشاركة', 'error');
                }
            });
        } else {
            showToast('المشاركة غير مدعومة لهذا النوع', 'info');
        }
        
    } catch(err) {
        console.error('Share failed:', err);
        showToast('تعذّر المشاركة: ' + err.message, 'error');
    }
}


function _pdfDownload() {
    if (!_currentPdfUrl) {
        showToast('لا يوجد PDF', 'error');
        return;
    }
    
    try {
        // تحويل Base64 إلى Blob
        var parts = _currentPdfUrl.split(',');
        var mime = parts[0].match(/:(.*?);/)[1];
        var binary = atob(parts[1]);
        var array = [];
        for (var i = 0; i < binary.length; i++) {
            array.push(binary.charCodeAt(i));
        }
        var blob = new Blob([new Uint8Array(array)], { type: mime });
        var blobUrl = URL.createObjectURL(blob);
        
        var a = document.createElement('a');
        a.href = blobUrl;
        a.download = _currentPdfName;
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        setTimeout(function() {
            URL.revokeObjectURL(blobUrl);
        }, 30000);
        
        showToast('جاري التنزيل...', 'success');
        
    } catch(err) {
        console.error('Download failed:', err);
        showToast('تعذّر التنزيل: ' + err.message, 'error');
    }
}



function openTablePrintModal(title, tableId, meta) {
    var table = document.getElementById(tableId);
    if (!table) return showToast('لم يتم العثور على جدول التقرير', 'error');
    var source = table.closest ? table.closest('table') : table.parentNode;
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var metaHtml = '';
    (meta || []).forEach(function(item) {
        metaHtml += '<div><strong>' + esc(item[0]) + ':</strong> ' + esc(item[1]) + '</div>';
    });
    var html = '<div class="doc-wrapper">' +
        '<div class="doc-header"><div class="company-name">' + esc(settings.name || 'Open Account') + '</div><div class="company-info">' + esc(settings.address || '') + '</div></div>' +
        '<div class="doc-title">' + esc(title || 'تقرير') + '</div>' +
        (metaHtml ? '<div class="doc-meta-grid">' + metaHtml + '</div>' : '') +
        (source ? source.outerHTML : table.outerHTML) +
        '<div class="doc-footer">تقرير معتمد رقمياً<small>تم إنشاؤه بواسطة Open Account</small></div>' +
        '</div>';
    Modal.open({
        id: 'tablePrintModal', title: 'معاينة ' + (title || 'التقرير'), size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'tablePrintModal\')">إغلاق</button>' +
                '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
    });
}

// ================================================================
// ===== END OF UTILS.JS =====
// ================================================================


// حفظ نسخة مستقلة من فاتورة محددة بصيغة JSON — للاحتفاظ والمشاركة دون تغيير سجل التطبيق
function saveInvoiceFile(kind, id) {
    var list = kind === 'purchase' ? (typeof purchaseInvoices !== 'undefined' ? purchaseInvoices : []) : (typeof salesInvoices !== 'undefined' ? salesInvoices : []);
    var invoice = list.find(function(x){ return x.id === id; });
    if (!invoice) { if (typeof showToast === 'function') showToast('الفاتورة غير موجودة','error'); return; }
    var payload = {version:'Open Account invoice 1.0', exportedAt:new Date().toISOString(), type:kind, invoice:invoice};
    var json = JSON.stringify(payload, null, 2);
    var name = (kind === 'purchase' ? 'فاتورة-شراء-' : 'فاتورة-بيع-') + String(invoice.id).replace(/[^\w\-]+/g,'_') + '.json';
    var blob = new Blob([json], {type:'application/json;charset=utf-8'});
    var file = new File([blob], name, {type:'application/json'});
    if (navigator.share && (!navigator.canShare || navigator.canShare({files:[file]}))) {
        navigator.share({files:[file], title:'حفظ الفاتورة', text:'نسخة محفوظة من الفاتورة '+invoice.id}).then(function(){ if(typeof showToast==='function')showToast('تم حفظ الفاتورة','success'); }).catch(function(e){if(e.name!=='AbortError')_downloadInvoiceFile(blob,name);});
    } else _downloadInvoiceFile(blob,name);
}
function _downloadInvoiceFile(blob,name){var a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(function(){URL.revokeObjectURL(a.href);},1000);if(typeof showToast==='function')showToast('تم تنزيل نسخة الفاتورة','success');}


// ================================================================
// فحص نشاط مستند (موحّد لكل التقارير والملفات)
// ================================================================
function _reportIsActive(row) {
    if (!row) return false;
    if (row.cancelled === true) return false;
    if (row.documentStatus === 'cancelled') return false;
    if (row.status === 'ملغاة') return false;
    return true;
}