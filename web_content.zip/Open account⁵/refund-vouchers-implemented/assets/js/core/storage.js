// ================================================================
// Open Account — نظام محاسبي
// الملف: storage.js
// الوصف: إدارة التخزين المحلي (LocalStorage)
// ================================================================


// ================================================================
// ===== 1. المفاتيح المستخدمة =====
// ================================================================

const STORAGE_KEYS = {
    // البيانات الأساسية
    PRODUCTS: 'oa_products',
    CUSTOMERS: 'oa_customers',
    SUPPLIERS: 'oa_suppliers',
    
    // الفواتير
    SALES: 'oa_sales_invoices',
    PURCHASES: 'oa_purchase_invoices',
    
    // السندات
    RECEIPTS: 'oa_receipts',
    PAYMENTS: 'oa_payments',
    
    // المصاريف
    EXPENSES: 'oa_expenses',
    
    // المستودع (جديد)
	STOCK_MOVEMENTS: 'oa_stock_movements',

	// التحويلات الداخلية
	TRANSFERS: 'oa_transfers',
	DIRECT_TRANSACTIONS: 'oa_direct_transactions',
	RETURNS: 'oa_returns',
	AI_SETTINGS: 'oa_ai_settings',
	BOM_RECIPES: 'oa_bom_recipes',
	PRODUCTIONS: 'oa_production_docs',
    
    // الإعدادات
    SETTINGS: 'oa_settings',
    EXCHANGE_RATES: 'oa_exchange_rates',
    
    // الحالة
    ACTIVE_TAB: 'oa_active_tab',
    THEME: 'oa_theme'
};


// ================================================================
// ===== 2. واجهة التخزين =====
// ================================================================

const Storage = {
    
    /**
     * حفظ بيانات في LocalStorage
     */
    set: function(key, value) {
        try {
            const json = JSON.stringify(value);
            localStorage.setItem(key, json);
            return true;
        } catch (e) {
            console.error('Storage.set error:', e);
            return false;
        }
    },
    
    
    /**
     * قراءة بيانات من LocalStorage
     */
    get: function(key, defaultValue) {
        try {
            const json = localStorage.getItem(key);
            if (json === null) return defaultValue !== undefined ? defaultValue : null;
            return JSON.parse(json);
        } catch (e) {
            console.error('Storage.get error:', e);
            return defaultValue !== undefined ? defaultValue : null;
        }
    },
    
    
    /**
     * حذف مفتاح من LocalStorage
     */
    remove: function(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.error('Storage.remove error:', e);
        }
    },
    
    
    /**
     * حذف جميع البيانات
     */
    clear: function() {
        try {
            localStorage.clear();
        } catch (e) {
            console.error('Storage.clear error:', e);
        }
    },
    
    
    /**
     * التحقق من وجود مفتاح
     */
    has: function(key) {
        return localStorage.getItem(key) !== null;
    },
    
    
    /**
     * الحصول على حجم البيانات المخزنة
     */
    size: function() {
        let total = 0;
        try {
            for (let key in localStorage) {
                if (localStorage.hasOwnProperty(key)) {
                    total += localStorage[key].length + key.length;
                }
            }
        } catch (e) {
            console.error('Storage.size error:', e);
        }
        return total;
    }
};


// ================================================================
// ===== 3. دوال مساعدة =====
// ================================================================

function saveArray(key, data) {
    return Storage.set(key, Array.isArray(data) ? data : []);
}


function loadArray(key) {
    const data = Storage.get(key, []);
    return Array.isArray(data) ? data : [];
}


// ================================================================
// ===== END OF STORAGE.JS =====
// ================================================================
