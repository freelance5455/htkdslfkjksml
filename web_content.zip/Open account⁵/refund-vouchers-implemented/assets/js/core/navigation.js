// ================================================================
// Open Account — نظام محاسبي
// الملف: navigation.js
// الوصف: التنقل بين التبويبات والشاشات
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var _currentTab = 'dashboard';


// ================================================================
// ===== 2. التبديل بين التبويبات =====
// ================================================================

/**
 * التبديل إلى تبويب معين
 * @param {string} tabId - معرف التبويب (بدون كلمة section-)
 */
function switchTab(tabId) {
    if (!tabId) return;
    
    // حفظ التبويب الحالي
    _currentTab = tabId;
    
    // إخفاء جميع الأقسام
    var sections = document.querySelectorAll('.section');
    sections.forEach(function(section) {
        section.classList.remove('active');
    });
    
    // إزالة التفعيل من جميع التبويبات
    var tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(function(tab) {
        tab.classList.remove('active');
    });
    
    // إظهار القسم المطلوب
    var targetSection = document.getElementById('section-' + tabId);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // تفعيل التبويب
    var targetTab = document.querySelector('.tab-btn[data-tab="' + tabId + '"]');
    if (targetTab) {
        targetTab.classList.add('active');
        
        // تمرير التبويب إلى الرؤية
        targetTab.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
            inline: 'center'
        });
    }
    
    // حفظ التبويب في LocalStorage
    if (typeof Storage !== 'undefined') {
        Storage.set(STORAGE_KEYS.ACTIVE_TAB, tabId);
    }
    
    // استدعاء دالة التحديث الخاصة بالتبويب (إذا وجدت)
    _onTabChange(tabId);
    
    // إغلاق لوحة الإعدادات إذا كانت مفتوحة
    var settingsPanel = document.getElementById('settingsPanel');
    if (settingsPanel && settingsPanel.classList.contains('active')) {
        settingsPanel.classList.remove('active');
    }
    
    // إغلاق جميع النوافذ المنبثقة
    if (typeof Modal !== 'undefined' && Modal._openModals.length > 0) {
        Modal.closeAll();
    }
    
    // العودة إلى أعلى الصفحة
    window.scrollTo({ top: 0, behavior: 'smooth' });
}


/**
 * استدعاء دالة التحديث الخاصة بالتبويب
 * @param {string} tabId
 */
function _onTabChange(tabId) {
    // هنا سيتم استدعاء دوال التحديث لكل شاشة
    // سنضيفها لاحقاً عند بناء كل شاشة
    
    switch (tabId) {
        case 'dashboard':
            if (typeof updateDashboard === 'function') updateDashboard();
            break;
        case 'inventory':
            if (typeof renderInventory === 'function') renderInventory();
            break;
        case 'production':
            if (typeof renderProduction === 'function') renderProduction();
            break;
        case 'customers':
            if (typeof renderCustomers === 'function') renderCustomers();
            break;
        case 'suppliers':
            if (typeof renderSuppliers === 'function') renderSuppliers();
            break;
        case 'sales':
            if (typeof renderSalesInvoices === 'function') renderSalesInvoices();
            break;
        case 'purchases':
            if (typeof renderPurchaseInvoices === 'function') renderPurchaseInvoices();
            break;
        case 'receipts':
            if (typeof renderReceipts === 'function') renderReceipts();
            break;
        case 'payments':
            if (typeof renderPayments === 'function') renderPayments();
            break;
        case 'expenses':
            if (typeof renderExpenses === 'function') renderExpenses();
            break;
        case 'cashbox':
            if (typeof renderCashbox === 'function') renderCashbox();
            break;
        case 'bank':
            if (typeof renderBank === 'function') renderBank();
            break;
        case 'direct-transactions':
            if (typeof renderDirectTransactions === 'function') renderDirectTransactions();
            break;
        case 'returns':
            if (typeof renderReturns === 'function') renderReturns();
            break;
        case 'zakat':
            if (typeof calculateZakat === 'function') calculateZakat();
            break;
        case 'profitloss':
            if (typeof renderProfitLoss === 'function') renderProfitLoss();
            break;
        case 'customer-ledger':
            if (typeof renderCustomerLedger === 'function') renderCustomerLedger();
            break;
        case 'supplier-ledger':
            if (typeof renderSupplierLedger === 'function') renderSupplierLedger();
            break;
        case 'reports':
            if (typeof renderReports === 'function') renderReports();
            break;
            case 'journal':
    if (typeof initJournal === 'function') initJournal();
    break;
    
    case 'trial-balance':
    if (typeof initTrialBalance === 'function') initTrialBalance();
    break;
    
    case 'general-ledger':
    if (typeof initGeneralLedger === 'function') initGeneralLedger();
    break;
    
    case 'audit':
    if (typeof initAudit === 'function') initAudit();
    break;
    
        case 'archive':
            if (typeof renderArchive === 'function') renderArchive();
            break;
        case 'archive-import':
            if (typeof initArchiveRestore === 'function') initArchiveRestore();
            break;
        case 'sudoku':
            if (typeof initSudoku === 'function') initSudoku();
            break;
            case 'notes':
    if (typeof initNotes === 'function') initNotes();
    break;
    }
}
// ================================================================
// ===== 3. تهيئة التنقل =====
// ================================================================

/**
 * تهيئة مستمعي أحداث التبويبات
 */
function initNavigation() {
    var tabs = document.querySelectorAll('.tab-btn');
    
    tabs.forEach(function(tab) {
        tab.addEventListener('click', function() {
            var tabId = this.getAttribute('data-tab');
            if (tabId) {
                switchTab(tabId);
            }
        });
    });
    
    // استرجاع التبويب المحفوظ
    var savedTab = null;
    if (typeof Storage !== 'undefined') {
        savedTab = Storage.get(STORAGE_KEYS.ACTIVE_TAB, null);
    }
    
    if (savedTab) {
        switchTab(savedTab);
    }
}


/**
 * الحصول على التبويب الحالي
 * @returns {string}
 */
function getCurrentTab() {
    return _currentTab;
}


// ================================================================
// ===== 4. لوحة الإعدادات =====
// ================================================================

/**
 * تبديل ظهور لوحة الإعدادات
 */
function toggleSettings() {
    var panel = document.getElementById('settingsPanel');
    if (!panel) return;
    
    if (panel.classList.contains('active')) {
        panel.classList.remove('active');
    } else {
        panel.classList.add('active');
        
        // تحديث حقول الإعدادات
        if (typeof applySettings === 'function') {
            applySettings();
        }
    }
}


/**
 * إغلاق لوحة الإعدادات
 */
function closeSettings() {
    var panel = document.getElementById('settingsPanel');
    if (panel) {
        panel.classList.remove('active');
    }
}


// ================================================================
// ===== 5. زر Escape (اختصار) =====
// ================================================================

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' || e.keyCode === 27) {
        // إغلاق لوحة الإعدادات
        closeSettings();
    }
});


// ================================================================
// ===== END OF NAVIGATION.JS =====
// ================================================================
