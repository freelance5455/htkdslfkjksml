// ================================================================
// Open Account — نظام محاسبي
// الملف: costing.js
// الوصف: متوسط التكلفة المرجح و COGS
// النسخة: v2 — مع نظام هجين (يدوي + مرجح + تقدير)
// ================================================================

// ================================================================
// ===== 1. الحصول على تكلفة المنتج (النظام الهجين) =====
// ================================================================

/**
 * الحصول على تكلفة الوحدة للمنتج
 * الترتيب:
 *   1. avgCost يدوي (إذا كان > 0)
 *   2. purchasePrice من فواتير الشراء (إذا كان > 0)
 *   3. price × 0.7 (تقدير احتياطي)
 *
 * @param {object} product - المنتج
 * @returns {number|null} - التكلفة أو null إن استحالت
 */
function getProductAverageCost(product) {
    if (!product) return null;

    // ===== 1. حساب من الحركات الحقيقية (أولوية قصوى) =====
    if (typeof stockMovements !== 'undefined' && Array.isArray(stockMovements)) {
        var realMovements = stockMovements.filter(function(m) {
            if (m.productId !== product.id) return false;
            if (m.docType === 'رصيد افتتاحي') return false;
            if (!m.docType || m.docType === '-') return false;
            return true;
        });

        if (realMovements.length > 0) {
            var totalQty = 0;
            var totalValue = 0;
            realMovements.forEach(function(m) {
                var qty = parseFloat(m.qty) || 0;
                var price = parseFloat(m.price) || 0;
                if (m.type === 'in') {
                    totalQty += qty;
                    totalValue += qty * price;
                }
            });
            if (totalQty > 0 && totalValue > 0) {
                return totalValue / totalQty;
            }
        }
    }

    // ===== 2. تكلفة يدوية (احتياطي) =====
    var manualCost = parseFloat(product.avgCost);
    if (isFinite(manualCost) && manualCost > 0) {
        return manualCost;
    }

    // ===== 3. سعر الشراء =====
    var purchaseCost = parseFloat(product.purchasePrice);
    if (isFinite(purchaseCost) && purchaseCost > 0) {
        return purchaseCost;
    }

    // ===== 4. Fallback: تقدير من سعر البيع =====
    var productType = product.type || product.productType || 'raw';
    var salePrice = parseFloat(product.price);
    if (isFinite(salePrice) && salePrice > 0) {
        if (productType === 'raw') {
            return salePrice;
        }
        return salePrice * 0.7;
    }

    return null;
}


// ================================================================
// ===== 2. تفاصيل التكلفة (للتقارير والتحذيرات) =====
// ================================================================

/**
 * الحصول على معلومات كاملة عن تكلفة منتج
 * @param {object} product
 * @returns {object} { cost, source, isEstimated }
 */
function getCostInfo(product) {
    if (!product) {
        return { cost: null, source: 'missing', isEstimated: false };
    }

    // 1. يدوي
    var manualCost = parseFloat(product.avgCost);
    if (isFinite(manualCost) && manualCost > 0) {
        return { cost: manualCost, source: 'manual', isEstimated: false };
    }

    // 2. سعر الشراء
    var purchaseCost = parseFloat(product.purchasePrice);
    if (isFinite(purchaseCost) && purchaseCost > 0) {
        return { cost: purchaseCost, source: 'purchase', isEstimated: false };
    }

    // 3. تقدير
    var productType = product.type || product.productType || 'raw';
    var salePrice = parseFloat(product.price);
    if (isFinite(salePrice) && salePrice > 0) {
        if (productType === 'raw') {
            return { cost: salePrice, source: 'estimated_raw', isEstimated: true };
        }
        return { cost: salePrice * 0.7, source: 'estimated_finished', isEstimated: true };
    }

    return { cost: null, source: 'missing', isEstimated: false };
}


/**
 * هل التكلفة تقديرية؟
 */
function isCostEstimated(product) {
    return getCostInfo(product).isEstimated;
}


// ================================================================
// ===== 3. تكلفة الشراء (مع الخصم) =====
// ================================================================

/**
 * حساب سعر الوحدة الصافي بعد توزيع الخصم
 * @param {object} item - بند الفاتورة
 * @param {number} subtotal - الإجمالي قبل الخصم
 * @param {number} discount - الخصم
 * @returns {number}
 */
function getPurchaseNetUnitCost(item, subtotal, discount) {
    var price = parseFloat(item.price) || 0;
    var factor = subtotal > 0 ? Math.max(0, 1 - (discount || 0) / subtotal) : 1;
    return price * factor;
}


// ================================================================
// ===== 4. متوسط التكلفة المرجح =====
// ================================================================

/**
 * تطبيق متوسط التكلفة المرجح على منتج
 * @param {object} product - المنتج
 * @param {number} quantity - الكمية المُضافة
 * @param {number} unitCost - تكلفة الوحدة الجديدة
 */
function applyWeightedAverageCost(product, quantity, unitCost, currency, exchangeRate) {
    if (!product || quantity <= 0 || !isFinite(unitCost)) return;

    var baseCurrency = typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'SAR';
    var entryCurrency = currency || product.currency || baseCurrency;
    var rate = parseFloat(exchangeRate);
    if (!isFinite(rate) || rate <= 0) {
        rate = (typeof getCurrentExchangeRateSnapshot === 'function')
            ? getCurrentExchangeRateSnapshot(entryCurrency)
            : 1;
    }

    // تحويل unitCost الجديدة إلى العملة الأساسية
    var unitCostBase = unitCost;
    if (entryCurrency !== baseCurrency) {
        if (typeof getEquivalentAtRate === 'function') {
            unitCostBase = getEquivalentAtRate(unitCost, entryCurrency, rate);
        } else if (typeof getEquivalent === 'function') {
            unitCostBase = getEquivalent(unitCost, entryCurrency);
        }
    }

    // تحويل avgCost القديمة إلى العملة الأساسية
    // ✅ oldQty من الحركات الحقيقية (بلا وهمية)
var oldQty = 0;
if (typeof stockMovements !== 'undefined' && Array.isArray(stockMovements)) {
    stockMovements.forEach(function(m) {
        if (m.productId !== product.id) return;
        if (m.docType === 'رصيد افتتاحي') return;
        if (!m.docType || m.docType === '-') return;
        var q = parseFloat(m.qty) || 0;
        if (m.type === 'in') oldQty += q;
        else if (m.type === 'out') oldQty -= q;
    });
}
if (oldQty < 0) oldQty = 0;
if (oldQty === 0) oldQty = parseFloat(product.quantity) || 0; // fallback
    var oldCost = getProductAverageCost(product);
    if (oldCost === null || !isFinite(oldCost)) {
        oldCost = unitCostBase;
    } else {
        var oldCurrency = product.costCurrency || product.currency || baseCurrency;
        if (oldCurrency !== baseCurrency && typeof getEquivalent === 'function') {
            oldCost = getEquivalent(oldCost, oldCurrency);
        }
    }

    var denominator = oldQty + quantity;
    var newAvgCost = denominator > 0
        ? ((oldQty * oldCost) + (quantity * unitCostBase)) / denominator
        : unitCostBase;

    product.avgCost = newAvgCost;
    product.costCurrency = baseCurrency;
    product.costUpdatedAt = new Date().toISOString();
}


// ================================================================
// ===== 5. تكلفة الإنتاج (BOM) =====
// ================================================================

/**
 * حساب تكلفة سند إنتاج بناءً على وصفة BOM
 * @param {object} recipe - الوصفة
 * @param {number} batches - عدد الدفعات
 * @returns {object}
 */
function calculateProductionCost(recipe, batches) {
    var total = 0, known = true, partial = false;
    var missingItems = [];
    var estimatedItems = [];

    (recipe && recipe.items || []).forEach(function (item) {
        var raw = products.find(function (p) { return p.id === item.productId; });
        var costInfo = getCostInfo(raw);

        if (costInfo.cost === null) {
            known = false;
            partial = true;
            if (raw && raw.name) missingItems.push(raw.name);
            else missingItems.push('مادة غير معروفة');
        } else {
            if (costInfo.isEstimated) {
                estimatedItems.push(raw ? raw.name : '-');
            }
            var factor = typeof productionFactor === 'function'
                ? productionFactor(raw, item.unit)
                : 1;
            total += costInfo.cost * (Number(item.qty) || 0) * factor * batches;
        }
    });

    var hasAnyCost = total > 0;

    return {
        total: total,
        unit: (recipe && recipe.outputQty * batches > 0) ? total / (recipe.outputQty * batches) : 0,
        known: hasAnyCost,
        costPartial: partial && hasAnyCost,
        costEstimated: estimatedItems.length > 0,
        estimatedItems: estimatedItems,
        missingCostItems: missingItems
    };
}


// ================================================================
// ===== 6. حساب COGS لفاتورة بيع =====
// ================================================================

/**
 * حساب تكلفة البضاعة المباعة
 * @param {array} items - بنود الفاتورة
 * @returns {object} { total, known, isEstimated, details }
 */
function calculateSaleCOGS(items) {
    var total = 0;
    var known = false;
    var isEstimated = false;
    var details = [];

    (items || []).forEach(function (item) {
        // الأولوية: التكلفة التاريخية المخزّنة في البند
        var historicalCost = parseFloat(item.cogsUnitCost);
        var unitCost = null;
        var source = null;

        if (isFinite(historicalCost) && historicalCost > 0) {
            unitCost = historicalCost;
            source = 'historical';
        } else {
            // الاحتياطي: التكلفة الحالية من بطاقة المنتج
            var product = products.find(function (p) { return p.id === item.productId; });
            var costInfo = getCostInfo(product);

            if (costInfo.cost === null) {
                details.push({
                    productId: item.productId,
                    name: item.name || (product && product.name) || '-',
                    reason: 'لا توجد تكلفة'
                });
                return;
            }
            unitCost = costInfo.cost;
            source = costInfo.source;
            if (costInfo.isEstimated) isEstimated = true;
        }

        known = true;

        var qty = parseFloat(item.qty) || 0;
        total += unitCost * qty;

        details.push({
            productId: item.productId,
            name: item.name || '-',
            cost: unitCost,
            qty: qty,
            source: source
        });
    });

    return {
        total: total,
        known: known,
        isEstimated: isEstimated,
        details: details
    };
}


// ================================================================
// ===== 7. إعادة حساب COGS للفواتير القديمة =====
// ================================================================

/**
 * إعادة حساب COGS لكل الفواتير التي لا تحتوي عليه
 * @returns {object} { repaired, missing, estimated }
 */
function recalculateIncompleteSalesCOGS() {
    if (typeof salesInvoices === 'undefined' || !Array.isArray(salesInvoices) || typeof products === 'undefined') {
        return { repaired: 0, missing: [], estimated: 0 };
    }

    var repaired = 0;
    var estimated = 0;
    var missing = [];

    salesInvoices.forEach(function (invoice) {
        // إذا كانت الفاتورة لديها COGS محسوب حديثاً، لا نُعيد
        if (invoice.cogsKnown === true && !invoice.cogsEstimated) return;

        var result = calculateSaleCOGS(invoice.items || []);
        invoice.cogsDetails = result.details;

        if (result.known) {
            invoice.cogsTotal = result.total;
            invoice.cogsKnown = true;
            invoice.cogsEstimated = result.isEstimated;
            invoice.cogsRecalculated = true;
            repaired++;
            if (result.isEstimated) estimated++;
        } else {
            invoice.cogsKnown = false;
            invoice.cogsEstimated = false;
            missing.push({
                id: invoice.id,
                date: invoice.date,
                products: result.details
            });
        }
    });

    if (repaired > 0 && typeof saveSalesInvoices === 'function') {
        saveSalesInvoices();
    }

    return { repaired: repaired, missing: missing, estimated: estimated };
}


// ================================================================
// ===== 8. إحصائيات التكلفة (للتقارير) =====
// ================================================================

/**
 * إحصاء المنتجات حسب مصدر التكلفة
 * @returns {object} { manual, purchase, estimated, missing, total }
 */
function getCostStats() {
    var stats = { manual: 0, purchase: 0, estimated: 0, missing: 0, total: 0 };

    if (typeof products === 'undefined' || !Array.isArray(products)) return stats;

    products.forEach(function (p) {
        stats.total++;
        var info = getCostInfo(p);
        if (info.source === 'manual') stats.manual++;
        else if (info.source === 'purchase') stats.purchase++;
        else if (info.source === 'estimated_raw' || info.source === 'estimated_finished') stats.estimated++;
        else stats.missing++;
    });

    return stats;
}


// ================================================================
// ===== 9. نص مساعد للعرض =====
// ================================================================

/**
 * الحصول على نص وصفي لمصدر التكلفة
 * @param {string} source
 * @returns {string}
 */
function getCostSourceLabel(source) {
    switch (source) {
        case 'manual': return 'يدوي';
        case 'purchase': return 'من فاتورة شراء';
        case 'estimated_raw': return 'تقديري (مادة خام)';
        case 'estimated_finished': return 'تقديري (منتج تام)';
        case 'missing': return 'غير محدد';
        default: return source || '-';
    }
}


/**
 * لون التحذير حسب المصدر
 */
function getCostSourceColor(source) {
    switch (source) {
        case 'manual': return 'var(--color-green)';
        case 'purchase': return 'var(--color-blue)';
        case 'estimated_raw':
        case 'estimated_finished': return 'var(--color-gold)';
        case 'missing': return 'var(--color-red)';
        default: return 'var(--color-text-2)';
    }
}

// ================================================================
// ===== 10. حساب قيمة تكلفة المنتج بالعملة الأساسية =====
// ================================================================

/**
 * حساب قيمة تكلفة المنتج بالعملة الأساسية
 * يعتمد على avgCost (أو purchasePrice كاحتياطي)
 * يحوّل من costCurrency إلى العملة الأساسية
 *
 * @param {object} product
 * @returns {number} القيمة بالعملة الأساسية
 */
function getProductCostValueBase(product) {
    if (!product) return 0;

    var cost = parseFloat(product.avgCost);
    if (!isFinite(cost) || cost < 0) cost = parseFloat(product.purchasePrice);
    if (!isFinite(cost) || cost < 0) cost = 0;
    if (cost <= 0) return 0;

    var qty = parseFloat(product.quantity) || 0;
    if (qty <= 0) return 0;

    var value = cost * qty;

    // ===== تحويل إلى العملة الأساسية =====
    var baseCur = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var costCur = product.costCurrency || product.currency || baseCur;

    if (costCur !== baseCur && typeof getEquivalent === 'function') {
        value = getEquivalent(value, costCur);
    }

    return value;
}

// ================================================================
// ===== 11. إصلاح شامل لـ avgCost (يُشغَّل مرة واحدة) =====
// ================================================================

/**
 * إعادة حساب avgCost لكل المنتجات من الحركات الحقيقية
 * يُشغَّل يدوياً مرة واحدة بعد إصلاح costing.js
 *
 * @returns {object} { fixed, unchanged, errors }
 */
function fixAllProductAvgCosts() {
    if (typeof products === 'undefined' || !Array.isArray(products)) {
        console.warn('[OA] fixAllProductAvgCosts: products غير معرّف');
        return { fixed: 0, unchanged: 0, errors: 0 };
    }

    var fixed = 0;
    var unchanged = 0;
    var errors = 0;
    var details = [];

    products.forEach(function(p) {
        try {
            var oldCost = parseFloat(p.avgCost);
            if (!isFinite(oldCost)) oldCost = 0;

            // احسب التكلفة الجديدة من الحركات الحقيقية
            var newCost = null;
            if (typeof stockMovements !== 'undefined' && Array.isArray(stockMovements)) {
                var realMovements = stockMovements.filter(function(m) {
                    if (m.productId !== p.id) return false;
                    if (m.docType === 'رصيد افتتاحي') return false;
                    if (!m.docType || m.docType === '-') return false;
                    return true;
                });

                if (realMovements.length > 0) {
                    var totalQty = 0;
                    var totalValue = 0;
                    realMovements.forEach(function(m) {
                        var qty = parseFloat(m.qty) || 0;
                        var price = parseFloat(m.price) || 0;
                        if (m.type === 'in') {
                            totalQty += qty;
                            totalValue += qty * price;
                        }
                    });
                    if (totalQty > 0 && totalValue > 0) {
                        newCost = totalValue / totalQty;
                    }
                }
            }

            // إذا لم نجد حركات حقيقية → احتفظ بالتكلفة الحالية
            if (newCost === null) {
                // fallback: استخدم getProductAverageCost العادية
                newCost = getProductAverageCost(p);
                if (newCost === null || !isFinite(newCost)) {
                    unchanged++;
                    return;
                }
            }

            // إذا كان الفرق كبيراً → حدّث
            if (Math.abs(oldCost - newCost) > 0.001) {
                p.avgCost = newCost;
                p.costUpdatedAt = new Date().toISOString();
                fixed++;
                details.push({
                    name: p.name,
                    old: oldCost,
                    new: newCost
                });
                console.log('[OA] تصحيح avgCost: ' + p.name + ' — ' + oldCost.toFixed(2) + ' → ' + newCost.toFixed(2));
            } else {
                unchanged++;
            }
        } catch (e) {
            errors++;
            console.error('[OA] خطأ في تصحيح ' + p.name + ':', e.message);
        }
    });

    if (fixed > 0 && typeof saveProducts === 'function') {
        saveProducts();
    }

    console.log('[OA] ✅ إصلاح avgCost: ' + fixed + ' مُصحّح، ' + unchanged + ' بلا تغيير، ' + errors + ' أخطاء');

    return {
        fixed: fixed,
        unchanged: unchanged,
        errors: errors,
        details: details
    };
}

// ================================================================
// ===== END OF FIX FUNCTION =====
// ================================================================
// ================================================================
// ===== END OF COSTING.JS =====
// ================================================================