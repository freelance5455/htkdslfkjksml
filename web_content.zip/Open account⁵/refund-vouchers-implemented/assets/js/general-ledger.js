// ================================================================
// Open Account — الأستاذ العام (General Ledger)
// الملف: general-ledger.js
// النسخة: v3 — مع تنبيه التحويل + صيغة أسعار موحّدة
// ================================================================

var ACCOUNTS_GL = {
    '1000': { name: 'الصندوق', type: 'أصول' },
    '1010': { name: 'البنك', type: 'أصول' },
    '1100': { name: 'العملاء', type: 'أصول' },
    '1200': { name: 'المخزون', type: 'أصول' },
    '2000': { name: 'الموردين', type: 'خصوم' },
    '3000': { name: 'رأس المال', type: 'حقوق' },
    '4000': { name: 'إيرادات المبيعات', type: 'إيرادات' },
    '4100': { name: 'إيرادات أخرى', type: 'إيرادات' },
    '5000': { name: 'تكلفة المبيعات', type: 'مصاريف' },
    '6000': { name: 'المصاريف', type: 'مصاريف' }
};
// ================================================================
// ===== 0. استخراج رقم القيد =====
// ================================================================

function _glExtractEntryNumber(entryId) {
    var m = String(entryId || '').match(/(\d+)/);
    return m ? parseInt(m[1], 10) : 0;
}

// ================================================================
// ===== 1. اكتشاف ديناميكي للحسابات =====
// ================================================================

function _glDiscoverAccounts() {
    var discovered = {};
    Object.keys(ACCOUNTS_GL).forEach(function(code) {
        discovered[code] = {
            name: ACCOUNTS_GL[code].name,
            type: ACCOUNTS_GL[code].type
        };
    });

    var entries = Storage.get('oa_journal_entries', []);
if (typeof showToast === 'function') {
    showToast('GL: ' + entries.length + ' قيد', 'info', 15000);
}
    if (!Array.isArray(entries)) entries = [];

    entries.forEach(function(e) {
        (e.lines || []).forEach(function(l) {
            if (!l.accountCode) return;
            if (!discovered[l.accountCode]) {
                discovered[l.accountCode] = {
                    name: l.accountName || l.accountCode,
                    type: 'أخرى'
                };
            }
        });
    });

    return discovered;
}


// ================================================================
// ===== 2. ملء قائمة الحسابات =====
// ================================================================

function _glPopulateAccounts() {
    var selectEl = document.getElementById('glAccount');
    if (!selectEl) return;

    var accounts = _glDiscoverAccounts();
    var codes = Object.keys(accounts).sort();

    var html = '<option value="">— اختر حساباً —</option>';
    codes.forEach(function(code) {
        var acc = accounts[code];
        html += '<option value="' + esc(code) + '">' +
                esc(code) + ' — ' + esc(acc.name) +
                ' (' + esc(acc.type) + ')' +
                '</option>';
    });

    selectEl.innerHTML = html;
}


// ================================================================
// ===== 3. بناء بيانات الأستاذ =====
// ================================================================

function _glBuildRows(accountCode, from, to, currencyFilter) {
    var entries = Storage.get('oa_journal_entries', []);
    if (!Array.isArray(entries)) entries = [];

    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var isUnified = !currencyFilter; // "كل العملات" = موحّد

    var rows = [];

    entries.forEach(function(e) {
        if (from && e.date < from) return;
        if (to && e.date > to) return;
        if (currencyFilter && e.currency !== currencyFilter) return;

        (e.lines || []).forEach(function(l) {
            if (l.accountCode !== accountCode) return;

            var d = parseFloat(l.debit) || 0;
            var c = parseFloat(l.credit) || 0;

            // عند "كل العملات" → حوّل للعملة الأساسية
            if (isUnified && e.currency && e.currency !== baseCurrency) {
                if (typeof getEquivalent === 'function') {
                    d = getEquivalentAtRate(d, e.currency, e.exchangeRate);
                    c = getEquivalentAtRate(c, e.currency, e.exchangeRate);
                }
            }

                rows.push({
            entryId: e.id,
            date: e.date,
            createdAt: e.createdAt || '',
            description: e.description,
            originalCurrency: e.currency || 'YER',
            debit: d,
            credit: c
        });
    });
});

    // ترتيب زمني: التاريخ → رقم القيد (العداد المتسلسل)
rows.sort(function(a, b) {
    var d = String(a.date || '').localeCompare(String(b.date || ''));
    if (d !== 0) return d;

    var na = _glExtractEntryNumber(a.entryId);
    var nb = _glExtractEntryNumber(b.entryId);
    return na - nb;
});

    // الرصيد التراكمي
    var runningBalance = 0;
    rows.forEach(function(r) {
        runningBalance += r.debit - r.credit;
        r.balance = runningBalance;
    });

    return rows;
}


// ================================================================
// ===== 4. عرض الأستاذ العام =====
// ================================================================

function renderGeneralLedger() {
    var tbody = document.getElementById('glTableBody');
    if (!tbody) return;

    var accountEl = document.getElementById('glAccount');
    var currencyEl = document.getElementById('glCurrency');
    var fromEl = document.getElementById('glFrom');
    var toEl = document.getElementById('glTo');

    var accountCode = accountEl ? accountEl.value : '';
    var currency = currencyEl ? currencyEl.value : '';
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    var isUnified = !currency;
    var displayCurrency = isUnified ? baseCurrency : currency;

    // ===== عرض التنبيه عند "كل العملات" =====
    _updateGLSummary(accountCode, currency, baseCurrency);

    // ===== لا يوجد حساب مختار =====
    if (!accountCode) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">اختر حساباً لعرض الحركات</td></tr>';
        setText('glTotalDebit', '0');
        setText('glTotalCredit', '0');
        setText('glFinalBalance', '0');
        setText('glCount', '0');
        return;
    }

    var rows = _glBuildRows(accountCode, from, to, currency);

    if (!rows.length) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-cell">لا توجد حركات لهذا الحساب في الفترة المحددة</td></tr>';
        setText('glTotalDebit', '0');
        setText('glTotalCredit', '0');
        setText('glFinalBalance', '0');
        setText('glCount', '0');
        return;
    }

    var html = '';
    var totalDebit = 0;
    var totalCredit = 0;

    rows.forEach(function(r, i) {
        totalDebit += r.debit;
        totalCredit += r.credit;

        var balanceColor = r.balance > 0 ? 'var(--color-red)' :
                           r.balance < 0 ? 'var(--color-green)' :
                           'var(--color-text)';

        var balanceLabel = r.balance > 0 ? 'مدين' :
                           r.balance < 0 ? 'دائن' : '';

        html += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td style="font-family:monospace;font-size:11px;">' + esc(r.entryId) + '</td>' +
            '<td>' + formatDate(r.date) + '</td>' +
            '<td style="text-align:right;padding-right:12px;font-size:12px;">' + esc(r.description) + '</td>' +
            '<td style="color:var(--color-red);">' + (r.debit > 0 ? formatAmountWithCommas(r.debit) : '—') + '</td>' +
            '<td style="color:var(--color-green);">' + (r.credit > 0 ? formatAmountWithCommas(r.credit) : '—') + '</td>' +
            '<td style="font-weight:700;color:' + balanceColor + ';">' +
                formatAmountWithCommas(Math.abs(r.balance)) +
                (balanceLabel ? ' <small style="opacity:0.6;">(' + balanceLabel + ')</small>' : '') +
            '</td>' +
        '</tr>';
    });

    var finalBalance = totalDebit - totalCredit;
    html += '<tr class="total-row">' +
        '<td colspan="4" style="text-align:right;padding-right:12px;font-weight:800;">الإجماليات (' + esc(displayCurrency) + ')</td>' +
        '<td style="color:var(--color-red);font-weight:800;">' + formatAmountWithCommas(totalDebit) + '</td>' +
        '<td style="color:var(--color-green);font-weight:800;">' + formatAmountWithCommas(totalCredit) + '</td>' +
        '<td style="font-weight:800;">' + formatAmountWithCommas(Math.abs(finalBalance)) +
            (finalBalance !== 0 ? ' <small style="opacity:0.6;">(' + (finalBalance > 0 ? 'مدين' : 'دائن') + ')</small>' : '') +
        '</td>' +
    '</tr>';

    tbody.innerHTML = html;

    setText('glTotalDebit', formatAmountWithCommas(totalDebit));
    setText('glTotalCredit', formatAmountWithCommas(totalCredit));
    setText('glFinalBalance', formatAmountWithCommas(Math.abs(finalBalance)) +
        (finalBalance !== 0 ? ' (' + (finalBalance > 0 ? 'مدين' : 'دائن') + ')' : ''));
    setText('glCount', rows.length);
}


// ================================================================
// ===== 5. الملخص والتنبيه =====
// ================================================================

function _updateGLSummary(accountCode, currencyFilter, baseCurrency) {
    var summaryEl = document.getElementById('glSummary');
    if (!summaryEl) return;

    // لا تنبيه إذا لم يُختَر حساب
    if (!accountCode) {
        summaryEl.innerHTML = '';
        return;
    }

    var accounts = _glDiscoverAccounts();
    var account = accounts[accountCode] || { name: accountCode, type: '—' };

    // إذا اختار عملة محددة → لا تنبيه (معلومات فقط)
    if (currencyFilter) {
        summaryEl.innerHTML =
            '<div class="info-message" style="text-align:right;line-height:1.8;margin-bottom:12px;">' +
                '<strong style="color:var(--color-blue);">📋 ' + esc(accountCode) + ' — ' + esc(account.name) + '</strong><br>' +
                'النوع: ' + esc(account.type) + ' | العملة: ' + esc(currencyFilter) +
            '</div>';
        return;
    }

    // "كل العملات" → تنبيه
    var ratesText = (typeof formatExchangeRates === 'function')
        ? formatExchangeRates(baseCurrency)
        : '—';

    var baseName = (typeof getCurrencyName === 'function')
        ? getCurrencyName(baseCurrency)
        : baseCurrency;

    summaryEl.innerHTML =
        '<div class="info-message" style="text-align:right;line-height:1.8;margin-bottom:12px;background:rgba(31,111,235,0.08);border-color:rgba(31,111,235,0.3);">' +
            '<strong style="color:var(--color-blue);">ℹ️ ميزان موحّد — ' + esc(accountCode) + ' ' + esc(account.name) + '</strong><br>' +
            'الأرقام المعروضة هي <strong>مجموع جميع العملات</strong> محوّلة إلى العملة المرجعية (' + esc(baseName) + ').<br>' +
            'سعر الصرف المستخدم: <strong>' + esc(ratesText) + '</strong><br>' +
            '<small style="color:var(--color-text-3);">للمراجعة الدقيقة، اختر عملة محددة من القائمة.</small>' +
        '</div>';
}


// ================================================================
// ===== 6. تصدير PDF =====
// ================================================================

function exportGeneralLedgerPDF() {
    var table = document.querySelector('#section-general-ledger .data-table');
    if (!table) return showToast('لا يوجد جدول لعرضه', 'error');

    var accountEl = document.getElementById('glAccount');
    var accountCode = accountEl ? accountEl.value : '';

    if (!accountCode) {
        return showToast('اختر حساباً أولاً', 'error');
    }

    var accounts = _glDiscoverAccounts();
    var account = accounts[accountCode] || { name: accountCode, type: '—' };

    var from = (document.getElementById('glFrom') || {}).value || '';
    var to = (document.getElementById('glTo') || {}).value || '';

    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';

    var html = '<div class="doc-wrapper">' +
        '<div class="doc-header"><div class="company-name">' + esc(companyName) + '</div></div>' +
        '<div class="doc-title">الأستاذ العام</div>' +
        '<div class="doc-meta-grid">' +
            '<div><strong>الحساب:</strong> ' + esc(accountCode) + ' — ' + esc(account.name) + '</div>' +
            '<div><strong>النوع:</strong> ' + esc(account.type) + '</div>' +
            '<div><strong>من:</strong> ' + (from || 'البداية') + '</div>' +
            '<div><strong>إلى:</strong> ' + (to || 'اليوم') + '</div>' +
            '<div><strong>تاريخ الإصدار:</strong> ' + todayISO() + '</div>' +
        '</div>' +
        table.outerHTML +
        '<div class="doc-footer">الأستاذ العام<small>هذا المستند معتمد رقمياً</small></div>' +
    '</div>';

    Modal.open({
        id: 'glPrintModal',
        title: 'معاينة الأستاذ العام',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'glPrintModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
    });
}


// ================================================================
// ===== 7. التهيئة =====
// ================================================================

function initGeneralLedger() {
    _glPopulateAccounts();

    var fromEl = document.getElementById('glFrom');
    var toEl = document.getElementById('glTo');

    if (fromEl && !fromEl.value) {
        var d = new Date();
        d.setDate(1);
        fromEl.value = d.toISOString().split('T')[0];
    }
    if (toEl && !toEl.value) {
        toEl.value = new Date().toISOString().split('T')[0];
    }

    var accountEl = document.getElementById('glAccount');
    if (accountEl) accountEl.addEventListener('change', renderGeneralLedger);

    var currencyEl = document.getElementById('glCurrency');
    if (currencyEl) currencyEl.addEventListener('change', renderGeneralLedger);

    if (fromEl) fromEl.addEventListener('change', renderGeneralLedger);
    if (toEl) toEl.addEventListener('change', renderGeneralLedger);

    renderGeneralLedger();
    console.log('General Ledger: initialized with ' + Object.keys(_glDiscoverAccounts()).length + ' accounts');
}

// ================================================================
// ===== طباعة الأستاذ العام (القالب الجديد) =====
// ================================================================

function printGeneralLedger() {
    // 1. اقرأ الفلاتر
    var accEl = document.getElementById('glAccount');
    var curEl = document.getElementById('glCurrency');
    var fromEl = document.getElementById('glFrom');
    var toEl = document.getElementById('glTo');

    var accountCode = accEl ? accEl.value : '';
    var currency = curEl ? curEl.value : '';
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    if (!accountCode) {
        if (typeof showToast === 'function') showToast('اختر حساباً أولاً', 'error');
        return;
    }

    // 2. اقرأ الجدول من الصفحة
    var tbody = document.getElementById('glTableBody');
    if (!tbody) {
        if (typeof showToast === 'function') showToast('الجدول غير موجود', 'error');
        return;
    }
    var table = tbody.closest('table');
    if (!table) {
        if (typeof showToast === 'function') showToast('الجدول غير موجود', 'error');
        return;
    }

    // 3. عدد الصفوف
    var count = tbody.querySelectorAll('tr').length;

    // 4. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 5. اسم الحساب
    var accountLabel = accountCode;
    if (accEl && accEl.options && accEl.selectedIndex >= 0) {
        accountLabel = accEl.options[accEl.selectedIndex].textContent;
    }

    // 6. اقرأ الإجماليات من العناصر
    function getText(id) {
        var el = document.getElementById(id);
        return el ? el.textContent.trim() : '—';
    }

    var totalDebit = getText('glTotalDebit');
    var totalCredit = getText('glTotalCredit');
    var finalBalance = getText('glFinalBalance');

    // 7. حفظ الحمولة
    var payload = {
        type: 'general_ledger',
        tableHtml: table.outerHTML,
        settings: settings,
        meta: {
            accountLabel: accountLabel,
            currency: currency || '—',
            from: from || 'البداية',
            to: to || 'اليوم',
            totalDebit: totalDebit,
            totalCredit: totalCredit,
            finalBalance: finalBalance,
            count: count
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 8. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/general-ledger-report.html';
    window.location.href = url;
}
// ================================================================
// ===== END OF GENERAL-LEDGER.JS =====
// ================================================================