// ================================================================
// Open Account — نظام محاسبي
// الملف: receipts.js
// الوصف: سندات القبض (التحصيل من العملاء والموردين)
// النسخة: v3 — دعم ربط تحصيل المورد بمرتجع المشتريات
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var receipts = [];
var _archiveReceiptsMode = false;
var _showArchivedReceipts = false;
var _selectedReceiptsForArchive = {};


// ================================================================
// ===== 2. تحميل وحفظ السندات =====
// ================================================================

function loadReceipts() {
    receipts = Storage.get(STORAGE_KEYS.RECEIPTS, []);
    if (!Array.isArray(receipts)) receipts = [];
}

function saveReceipts() {
    Storage.set(STORAGE_KEYS.RECEIPTS, receipts);
}


// ================================================================
// ===== 3. عرض جدول سندات القبض =====
// ================================================================

function renderReceipts() {
    var tbody = document.getElementById('recTableBody');
    if (!tbody) return;

    var searchEl = document.getElementById('recSearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';

    var filtered = receipts.filter(function(r) {
        if (_showArchivedReceipts) return r.archived === true;
        return r.archived !== true;
    });

    if (search) {
        filtered = filtered.filter(function(r) {
            return String(r.customerName || '').toLowerCase().indexOf(search) !== -1
                || String(r.supplierName || '').toLowerCase().indexOf(search) !== -1
                || String(r.invoiceId || '').indexOf(search) !== -1
                || String(r.id || '').indexOf(search) !== -1;
        });
    }

    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">'
            + (_showArchivedReceipts ? 'لا توجد سندات مؤرشفة' : 'لا توجد سندات')
            + '</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function(r, i) {
            var _isCancelled = r.cancelled || r.documentStatus === 'cancelled';
            var _rowStyle = _isCancelled ? 'opacity:0.5;text-decoration:line-through;' : '';

            var _isAuto = !r.journalEntryId && r.invoiceId && r.invoiceId !== '-'
                && r.receiptType !== 'supplier_refund';

            var _statusBadge = '';
            if (_isCancelled) {
                _statusBadge += ' <span style="background:#888;color:#fff;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;">ملغى</span>';
            }
            if (_isAuto) {
                _statusBadge += ' <span style="background:#d4a017;color:#fff;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;" title="سند تلقائي من فاتورة نقدية">🔒 تلقائي</span>';
            }

            var firstCell = (i + 1);
            if (_archiveReceiptsMode && !_showArchivedReceipts && !_isCancelled) {
                var checked = _selectedReceiptsForArchive[r.id] ? 'checked' : '';
                firstCell = '<input type="checkbox" class="rec-archive-cb" data-id="' + r.id + '" ' + checked + ' onchange="onReceiptsArchiveCheckboxChange(this)">';
            }

            var actionsHtml = '';
            if (_showArchivedReceipts) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewReceipt(\'' + r.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    '<button class="btn-edit" onclick="restoreReceipt(\'' + r.id + '\')" title="استرجاع" style="margin-right:4px;">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>' +
                    '</button>';
            } else if (!_archiveReceiptsMode) {
                var deleteBtn = '';
                if (!_isCancelled) {
                    if (_isAuto) {
                        deleteBtn = '<button class="btn-delete" disabled title="سند تلقائي — يُحذف من الفاتورة" style="opacity:0.3;cursor:not-allowed;">' +
                            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
                        '</button>';
                    } else {
                        deleteBtn = '<button class="btn-delete" onclick="deleteReceipt(\'' + r.id + '\')" title="إلغاء">' +
                            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
                        '</button>';
                    }
                }
                actionsHtml =
                    '<button class="btn-view" onclick="viewReceipt(\'' + r.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    deleteBtn;
            }

            var partyLabel = r.supplierName || r.customerName || '-';

            html += '<tr style="' + _rowStyle + '">' +
                '<td>' + firstCell + '</td>' +
                '<td>' + esc(partyLabel) + _statusBadge + '</td>' +
                '<td>' + esc(r.invoiceId || '-') + '</td>' +
                '<td>' + formatCurrency(r.amount, r.currency) + '</td>' +
                '<td>' + formatDate(r.date) + '</td>' +
                '<td>' + actionsHtml + '</td>' +
            '</tr>';
        });
        tbody.innerHTML = html;
    }

    _renderReceiptsArchiveToolbar();
    updateReceiptsStats();
}


// ================================================================
// ===== 3-b. شريط أدوات الأرشفة =====
// ================================================================

function _renderReceiptsArchiveToolbar() {
    var bar = document.getElementById('receiptsArchiveBar');
    if (!bar) return;

    if (!_archiveReceiptsMode) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    var count = Object.keys(_selectedReceiptsForArchive).length;
    bar.style.display = 'flex';
    bar.innerHTML =
        '<button class="btn btn-secondary" onclick="toggleSelectAllReceipts()" style="flex:1;font-size:12px;">' +
            (_allActiveReceiptsSelected() ? 'إلغاء الكل' : 'تحديد الكل') +
        '</button>' +
        '<button class="btn btn-warning" onclick="confirmArchiveReceipts()" style="flex:1;font-size:12px;" ' + (count === 0 ? 'disabled' : '') + '>' +
            'أرشفة المحدد (' + count + ')' +
        '</button>' +
        '<button class="btn btn-cancel" onclick="toggleArchiveReceiptsMode()" style="flex:1;font-size:12px;">' +
            'إلغاء' +
        '</button>';
}

function _allActiveReceiptsSelected() {
    var active = receipts.filter(function(r) {
        return !r.cancelled && r.documentStatus !== 'cancelled' && !r.archived;
    });
    if (!active.length) return false;
    return active.every(function(r) { return _selectedReceiptsForArchive[r.id]; });
}

function toggleArchiveReceiptsMode() {
    _archiveReceiptsMode = !_archiveReceiptsMode;
    _selectedReceiptsForArchive = {};
    if (_archiveReceiptsMode) _showArchivedReceipts = false;
    renderReceipts();
}

function toggleShowArchivedReceipts() {
    _showArchivedReceipts = !_showArchivedReceipts;
    _archiveReceiptsMode = false;
    _selectedReceiptsForArchive = {};
    renderReceipts();
}

function onReceiptsArchiveCheckboxChange(cb) {
    var id = cb.getAttribute('data-id');
    if (cb.checked) _selectedReceiptsForArchive[id] = true;
    else delete _selectedReceiptsForArchive[id];
    _renderReceiptsArchiveToolbar();
}

function toggleSelectAllReceipts() {
    var active = receipts.filter(function(r) {
        return !r.cancelled && r.documentStatus !== 'cancelled' && !r.archived;
    });
    if (_allActiveReceiptsSelected()) {
        _selectedReceiptsForArchive = {};
    } else {
        active.forEach(function(r) { _selectedReceiptsForArchive[r.id] = true; });
    }
    renderReceipts();
}

function confirmArchiveReceipts() {
    var ids = Object.keys(_selectedReceiptsForArchive);
    if (!ids.length) { showToast('لم تحدد أي سند', 'warning'); return; }
    if (!confirm('سيتم أرشفة ' + ids.length + ' سند.\nستُخفى من العرض — لا تُحذف.\n\nمتابعة؟')) return;

    var count = 0;
    receipts.forEach(function(r) {
        if (_selectedReceiptsForArchive[r.id]) {
            r.archived = true;
            r.archivedAt = new Date().toISOString();
            count++;
        }
    });

    saveReceipts();
    _archiveReceiptsMode = false;
    _selectedReceiptsForArchive = {};
    renderReceipts();
    showToast('تمت أرشفة ' + count + ' سند', 'success');
}

function restoreReceipt(id) {
    var r = receipts.find(function(x) { return x.id === id; });
    if (!r) return;
    r.archived = false;
    delete r.archivedAt;
    saveReceipts();
    renderReceipts();
    showToast('تم استرجاع السند', 'success');
}


// ================================================================
// ===== 4. إحصائيات سندات القبض =====
// ================================================================

function updateReceiptsStats() {
    setText('recCount', receipts.length);

    var totals = {};
    receipts.forEach(function(r) {
        var c = r.currency || 'YER';
        totals[c] = (totals[c] || 0) + (parseFloat(r.amount) || 0);
    });

    var parts = [];
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if (totals[c]) parts.push(formatAmountWithCommas(totals[c]) + ' ' + c);
    });

    setText('recTotal', parts.length ? parts.join(' | ') : '0');
}

// ================================================================
// ===== 5. نافذة سند قبض جديد =====
// ================================================================

function openReceiptModal() {
    if (!customers || customers.length === 0) {
        showToast('يرجى إضافة عميل أولاً', 'error');
        return;
    }

    var bodyHTML = _buildReceiptFormHTML();

    var footerHTML =
        '<button class="btn btn-cancel" onclick="closeModal(\'receiptModal\')">إلغاء</button>' +
        '<button class="btn btn-success" onclick="saveReceipt()">حفظ</button>';

    Modal.open({
        id: 'receiptModal',
        title: 'سند قبض جديد',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            _populateReceiptCustomers();
            _onReceiptTypeChange();

            var dateEl = modalEl.querySelector('#receiptDate');
            if (dateEl) dateEl.value = todayISO();
            var dateRefundEl = modalEl.querySelector('#receiptDateRefund');
            if (dateRefundEl) dateRefundEl.value = todayISO();
        }
    });
}


function _buildReceiptFormHTML() {
    return '' +
        '<div class="form-field"><label>نوع السند</label>' +
        '<select id="receiptType" onchange="_onReceiptTypeChange()">' +
        '<option value="customer_receipt">سند قبض من عميل</option>' +
        '<option value="supplier_refund">تحصيل من مورد</option>' +
        '</select></div>' +

        '<div id="receiptCustomerBlock">' +
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>العميل</label>' +
                '<select id="receiptCustomer" onchange="loadCustomerInvoices()">' +
                    '<option value="">— اختر عميل —</option>' +
                '</select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="receiptDate">' +
            '</div>' +
        '</div>' +
        '<div class="form-field">' +
            '<label>الفاتورة</label>' +
            '<select id="receiptInvoice" onchange="updateReceiptInfo()">' +
                '<option value="">— اختر فاتورة —</option>' +
            '</select>' +
        '</div>' +
        '</div>' +

        '<div id="receiptRefundBlock" style="display:none;">' +
            '<div class="form-row">' +
                '<div class="form-field">' +
                    '<label>المورد</label>' +
                    '<select id="receiptSupplier"></select>' +
                '</div>' +
                '<div class="form-field">' +
                    '<label>التاريخ</label>' +
                    '<input type="date" id="receiptDateRefund">' +
                '</div>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>سند الصرف الأصلي (اختياري)</label>' +
                '<select id="receiptSourcePayment" onchange="updateSupplierRefundInfo()"></select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>مرتجع مشتريات (اختياري)</label>' +
                '<select id="receiptSourceReturn" onchange="updateSupplierRefundInfo()">' +
                    '<option value="">— بدون مرتجع —</option>' +
                '</select>' +
            '</div>' +
        '</div>' +

        '<div class="form-field">' +
            '<label>طريقة الدفع</label>' +
            '<select id="receiptMethod">' +
                '<option>نقدي</option>' +
                '<option>تحويل بنكي</option>' +
                '<option>بطاقة</option>' +
            '</select>' +
        '</div>' +

        '<div class="form-field">' +
            '<label>المبلغ المدفوع</label>' +
            '<input type="number" id="receiptAmount" placeholder="0.00" step="0.01" min="0">' +
        '</div>' +

        '<div class="form-field">' +
            '<label>ملاحظة (اختياري)</label>' +
            '<input type="text" id="receiptNote" placeholder="ملاحظة">' +
        '</div>' +

        '<div class="info-boxes">' +
            '<div class="info-box">' +
                '<span>قيمة الفاتورة / المرتجع</span>' +
                '<strong id="receiptInvoiceTotal">0.00</strong>' +
            '</div>' +
            '<div class="info-box">' +
                '<span>المتبقي</span>' +
                '<strong id="receiptRemaining">0.00</strong>' +
            '</div>' +
        '</div>';
}


function _onReceiptTypeChange() {
    var type = (document.getElementById('receiptType') || {}).value || 'customer_receipt';
    var customerBlock = document.getElementById('receiptCustomerBlock');
    var refundBlock = document.getElementById('receiptRefundBlock');

    if (customerBlock) customerBlock.style.display = type === 'supplier_refund' ? 'none' : '';
    if (refundBlock) refundBlock.style.display = type === 'supplier_refund' ? '' : 'none';

    if (type === 'supplier_refund') {
        _populateSupplierRefundSuppliers();
        _populateSupplierRefundPayments();
        _populateSupplierRefundReturns();
    }
}


function _populateReceiptCustomers() {
    var selectEl = document.getElementById('receiptCustomer');
    if (!selectEl) return;

    var html = '<option value="">— اختر عميل —</option>';
    customers.forEach(function(c) {
        html += '<option value="' + c.id + '">' + esc(c.name) + '</option>';
    });
    selectEl.innerHTML = html;
}


function _populateSupplierRefundSuppliers() {
    var el = document.getElementById('receiptSupplier');
    if (!el) return;
    el.innerHTML = '<option value="">— اختر مورد —</option>' +
        (typeof suppliers !== 'undefined'
            ? suppliers.map(function(s) {
                return '<option value="' + s.id + '">' + esc(s.name) + '</option>';
            }).join('')
            : '');
}


function _populateSupplierRefundPayments() {
    var el = document.getElementById('receiptSourcePayment');
    if (!el) return;
    el.innerHTML = '<option value="">— بدون سند صرف —</option>' +
        (typeof payments !== 'undefined'
            ? payments.filter(function(p) {
                return !p.cancelled
                    && p.documentStatus !== 'cancelled'
                    && !p.isExpense
                    && p.supplierId;
            }).map(function(p) {
                return '<option value="' + p.id + '">' + esc(p.id) + ' | ' +
                    esc(p.supplierName || '-') + ' | ' +
                    formatCurrency(p.amount, p.currency) + '</option>';
            }).join('')
            : '');
}


function _populateSupplierRefundReturns() {
    var el = document.getElementById('receiptSourceReturn');
    if (!el) return;
    el.innerHTML = '<option value="">— بدون مرتجع —</option>' +
        (typeof returnsDocs !== 'undefined'
            ? returnsDocs.filter(function(r) {
                return r.kind === 'purchase'
                    && r.documentStatus === 'active'
                    && !r.cancelled;
            }).map(function(r) {
                return '<option value="' + r.id + '">' + esc(r.id) + ' | ' +
                    esc(r.partyName || '-') + ' | ' +
                    formatCurrency(r.amount, r.currency) + '</option>';
            }).join('')
            : '');
}


// ================================================================
// ===== 6. حساب المبلغ المتاح للاسترداد (دالة مشتركة) =====
// ================================================================

function _calculateAvailableRefundForReturn(ret) {
    if (!ret || ret.kind !== 'purchase') {
        return { ok: false, reason: 'ليس مرتجع مشتريات', available: 0 };
    }
    if (ret.cancelled || ret.documentStatus === 'cancelled') {
        return { ok: false, reason: 'مرتجع ملغى', available: 0 };
    }

    var inv = (typeof purchaseInvoices !== 'undefined')
        ? purchaseInvoices.find(function(x) { return x.id === ret.invoiceId; })
        : null;
    if (!inv) {
        return { ok: false, reason: 'الفاتورة غير موجودة', available: 0 };
    }

    var invoiceCurrency = inv.currency || 'SAR';
    if (ret.currency && ret.currency !== invoiceCurrency) {
        return { ok: false, reason: 'عملة المرتجع لا تطابق الفاتورة', available: 0 };
    }

    var totalPaid = (typeof payments !== 'undefined')
        ? payments.filter(function(p) {
            return p
                && p.invoiceId === inv.id
                && !p.isExpense
                && !p.cancelled
                && p.documentStatus !== 'cancelled';
        }).reduce(function(s, p) { return s + (parseFloat(p.amount) || 0); }, 0)
        : 0;

    var totalReturnsOnInvoice = (typeof returnsDocs !== 'undefined')
        ? returnsDocs.filter(function(r) {
            return r
                && r.invoiceId === inv.id
                && r.kind === 'purchase'
                && !r.cancelled
                && r.documentStatus !== 'cancelled';
        }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0)
        : 0;

    var totalRefundedOnInvoice = (typeof receipts !== 'undefined')
        ? receipts.filter(function(r) {
            return r
                && r.receiptType === 'supplier_refund'
                && r.sourceInvoiceId === inv.id
                && !r.cancelled
                && r.documentStatus !== 'cancelled';
        }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0)
        : 0;

    var invoiceTotal = parseFloat(inv.total) || 0;
    var netObligation = invoiceTotal - totalReturnsOnInvoice;
    var availableCashOnInvoice = totalPaid - netObligation - totalRefundedOnInvoice;

    var totalRefundedOnThisReturn = (typeof receipts !== 'undefined')
        ? receipts.filter(function(r) {
            return r
                && r.receiptType === 'supplier_refund'
                && r.returnId === ret.id
                && !r.cancelled
                && r.documentStatus !== 'cancelled';
        }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0)
        : 0;

    var remainingOnThisReturn = (parseFloat(ret.amount) || 0) - totalRefundedOnThisReturn;

    var available = Math.max(0, Math.min(availableCashOnInvoice, remainingOnThisReturn));

    return {
        ok: true,
        available: available,
        currency: invoiceCurrency,
        totalPaid: totalPaid,
        totalReturnsOnInvoice: totalReturnsOnInvoice,
        totalRefundedOnInvoice: totalRefundedOnInvoice,
        netObligation: netObligation,
        availableCashOnInvoice: availableCashOnInvoice,
        totalRefundedOnThisReturn: totalRefundedOnThisReturn,
        remainingOnThisReturn: remainingOnThisReturn
    };
}


// ================================================================
// ===== 7. تحديث معلومات السند =====
// ================================================================

function updateSupplierRefundInfo() {
    var sourcePaymentId = (document.getElementById('receiptSourcePayment') || {}).value;
    var sourceReturnId = (document.getElementById('receiptSourceReturn') || {}).value;
    var totalEl = document.getElementById('receiptInvoiceTotal');
    var remainEl = document.getElementById('receiptRemaining');
    var amountEl = document.getElementById('receiptAmount');

    // حالة 1: اختيار مرتجع
    if (sourceReturnId && typeof returnsDocs !== 'undefined') {
        var ret = returnsDocs.find(function(x) { return x.id === sourceReturnId; });
        if (ret && ret.kind === 'purchase') {
            var calc = _calculateAvailableRefundForReturn(ret);
            if (!calc.ok) {
                if (totalEl) totalEl.textContent = formatCurrency(ret.amount, ret.currency);
                if (remainEl) {
                    remainEl.textContent = formatCurrency(0, ret.currency);
                    remainEl.style.color = 'var(--color-red)';
                }
                if (amountEl) amountEl.value = '0.00';
                return;
            }
            if (totalEl) totalEl.textContent = formatCurrency(ret.amount, ret.currency);
            if (remainEl) {
                remainEl.textContent = formatCurrency(calc.available, ret.currency);
                remainEl.style.color = calc.available > 0.01 ? 'var(--color-red)' : 'var(--color-green)';
            }
            if (amountEl) amountEl.value = calc.available.toFixed(2);
            return;
        }
    }

    // حالة 2: اختيار سند صرف
    if (sourcePaymentId && typeof payments !== 'undefined') {
        var p = payments.find(function(x) { return x.id === sourcePaymentId; });
        if (p) {
            var amount = parseFloat(p.amount) || 0;
            var used = receipts.filter(function(r) {
                return r.receiptType === 'supplier_refund'
                    && r.sourcePaymentId === sourcePaymentId
                    && !r.cancelled
                    && r.documentStatus !== 'cancelled';
            }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);
            var remain = Math.max(0, amount - used);
            if (totalEl) totalEl.textContent = formatCurrency(amount, p.currency);
            if (remainEl) {
                remainEl.textContent = formatCurrency(remain, p.currency);
                remainEl.style.color = remain > 0.01 ? 'var(--color-red)' : 'var(--color-green)';
            }
            if (amountEl) amountEl.value = remain.toFixed(2);
            return;
        }
    }

    // حالة 3: لا اختيار
    if (totalEl) totalEl.textContent = '0.00';
    if (remainEl) remainEl.textContent = '0.00';
    if (amountEl) amountEl.value = '';
}


// ================================================================
// ===== 8. تحميل فواتير العميل =====
// ================================================================

function loadCustomerInvoices() {
    var custEl = document.getElementById('receiptCustomer');
    var invEl = document.getElementById('receiptInvoice');
    if (!custEl || !invEl) return;

    var customerId = custEl.value;
    invEl.innerHTML = '<option value="">— اختر فاتورة —</option>';

    if (!customerId) { updateReceiptInfo(); return; }

    var unpaidInvoices = salesInvoices.filter(function(inv) {
        return inv.customerId === customerId
            && inv.status !== 'مسدد'
            && inv.status !== 'ملغاة'
            && !inv.cancelled;
    });

    if (!unpaidInvoices.length) {
        invEl.innerHTML = '<option value="">لا توجد فواتير غير مسددة</option>';
        updateReceiptInfo();
        return;
    }

    var html = '<option value="">— اختر فاتورة —</option>';
    unpaidInvoices.forEach(function(inv) {
        var outstanding = (typeof getInvoiceOutstanding === 'function')
            ? getInvoiceOutstanding(inv.id, 'sale') : null;
        var paid, remaining;
        if (outstanding) {
            paid = outstanding.totalPaid || 0;
            remaining = outstanding.outstanding || 0;
        } else {
            paid = receipts.filter(function(r) {
                return r.invoiceId === inv.id && !r.cancelled && r.documentStatus !== 'cancelled';
            }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);
            remaining = (parseFloat(inv.total) || 0) - paid;
        }
        html += '<option value="' + inv.id + '" ' +
            'data-total="' + inv.total + '" ' +
            'data-paid="' + paid + '" ' +
            'data-remaining="' + remaining + '" ' +
            'data-currency="' + (inv.currency || 'YER') + '">' +
            esc(inv.id) + ' | متبقي ' + formatAmountWithCommas(remaining) +
            '</option>';
    });
    invEl.innerHTML = html;
    updateReceiptInfo();
}


// ================================================================
// ===== 9. تحديث معلومات سند القبض من عميل =====
// ================================================================

function updateReceiptInfo() {
    var invEl = document.getElementById('receiptInvoice');
    var totalEl = document.getElementById('receiptInvoiceTotal');
    var remainEl = document.getElementById('receiptRemaining');
    var amountEl = document.getElementById('receiptAmount');
    if (!invEl) return;

    var selected = invEl.options[invEl.selectedIndex];
    if (!selected || !selected.value) {
        if (totalEl) totalEl.textContent = '0.00';
        if (remainEl) remainEl.textContent = '0.00';
        if (amountEl) amountEl.value = '';
        return;
    }

    var total = parseFloat(selected.dataset.total) || 0;
    var remaining = parseFloat(selected.dataset.remaining) || 0;

    if (totalEl) totalEl.textContent = formatAmountWithCommas(total);
    if (remainEl) {
        remainEl.textContent = formatAmountWithCommas(remaining);
        remainEl.style.color = remaining > 0 ? 'var(--color-red)' : 'var(--color-green)';
    }
    if (amountEl && remaining > 0) amountEl.value = remaining.toFixed(2);
}


// ================================================================
// ===== 10. حفظ سند القبض =====
// ================================================================

function saveReceipt() {
    var custEl = document.getElementById('receiptCustomer');
    var dateEl = document.getElementById('receiptDate');
    var dateRefundEl = document.getElementById('receiptDateRefund');
    var invEl = document.getElementById('receiptInvoice');
    var methodEl = document.getElementById('receiptMethod');
    var amountEl = document.getElementById('receiptAmount');
    var noteEl = document.getElementById('receiptNote');

    var customerId = custEl ? custEl.value : '';
    var invoiceId = invEl ? invEl.value : '';
    var method = methodEl ? methodEl.value : 'نقدي';
    var amount = parseFloat(amountEl ? amountEl.value : 0) || 0;
    var note = noteEl ? noteEl.value.trim() : '';
    var receiptType = (document.getElementById('receiptType') || {}).value || 'customer_receipt';

    // ╔══════════════════════════════════════════════════════════╗
    // ║  فرع supplier_refund                                      ║
    // ╚══════════════════════════════════════════════════════════╝
    if (receiptType === 'supplier_refund') {
        var supplierId = (document.getElementById('receiptSupplier') || {}).value || '';
        var sourcePaymentId = (document.getElementById('receiptSourcePayment') || {}).value || '';
        var sourceReturnId = (document.getElementById('receiptSourceReturn') || {}).value || '';
        var date = dateRefundEl ? dateRefundEl.value : todayISO();

        if (!supplierId) { showToast('يرجى اختيار المورد', 'error'); return; }
        if (!date) { showToast('يرجى اختيار التاريخ', 'error'); return; }
        if (amount <= 0) { showToast('يرجى إدخال مبلغ صحيح', 'error'); return; }

        var account = (method === 'تحويل بنكي' || method === 'بطاقة') ? 'bank' : 'cashbox';

        // ─── حالة أ: مرتبط بمرتجع ───
        if (sourceReturnId) {
            var ret = returnsDocs.find(function(x) { return x.id === sourceReturnId; });
            if (!ret) { showToast('المرتجع غير موجود', 'error'); return; }
            if (ret.kind !== 'purchase') { showToast('المرتجع ليس من نوع مشتريات', 'error'); return; }
            if (ret.cancelled || ret.documentStatus === 'cancelled') { showToast('المرتجع ملغى', 'error'); return; }
            if (ret.partyId !== supplierId) { showToast('المورد لا يطابق مورد المرتجع', 'error'); return; }

            var calc = _calculateAvailableRefundForReturn(ret);
            if (!calc.ok) { showToast(calc.reason, 'error'); return; }
            if (amount > calc.available + 0.01) {
                showToast(
                    'المبلغ يتجاوز المتاح للاسترداد.\n' +
                    'المطلوب: ' + formatAmountWithCommas(amount) + '\n' +
                    'المتاح: ' + formatAmountWithCommas(calc.available),
                    'error', 8000
                );
                return;
            }

            if (typeof checkSufficientBalance === 'function') {
                var bc = checkSufficientBalance(account, ret.currency, amount);
                if (!bc.ok) { showToast('رصيد ' + bc.accountLabel + ' غير كافٍ', 'error'); return; }
            }

            var supplier = suppliers.find(function(s) { return s.id === supplierId; });
            var refund = {
                id: generateId(),
                receiptType: 'supplier_refund',
                settlementType: 'supplier_refund',
                invoiceId: '-',
                supplierId: supplierId,
                supplierName: supplier ? supplier.name : (ret.partyName || '-'),
                sourcePaymentId: null,
                sourceInvoiceId: ret.invoiceId,
                sourceReturnId: ret.id,
                returnId: ret.id,
                amount: amount,
                currency: ret.currency || 'SAR',
                exchangeRate: ret.exchangeRate || 1,
                account: account,
                method: method,
                date: date,
                note: note || ('تحصيل مقابل مرتجع ' + ret.id),
                documentStatus: 'posted',
                cancelled: false,
                status: 'تم التحصيل'
            };
            receipts.push(refund);

            // ربط مزدوج
            ret.refundReceiptId = refund.id;

            saveReceipts();
            if (typeof saveReturns === 'function') saveReturns();
            if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

            closeModal('receiptModal');
            if (typeof oaRefreshRelated === 'function') oaRefreshRelated('receipt');
            else { renderReceipts(); if (typeof updateDashboard === 'function') updateDashboard(); }

            showToast('تم حفظ تحصيل المرتجع ' + ret.id, 'success');
            return;
        }

        // ─── حالة ب: مرتبط بسند صرف (السلوك القديم) ───
        if (!sourcePaymentId) { showToast('اختر سند الصرف الأصلي أو المرتجع', 'error'); return; }
        var sourcePayment = payments.find(function(p) { return p.id === sourcePaymentId; });
        if (!sourcePayment) { showToast('سند الصرف غير موجود', 'error'); return; }
        if (sourcePayment.supplierId !== supplierId) { showToast('سند الصرف لا يخص المورد المختار', 'error'); return; }

        var used = receipts.filter(function(r) {
            return r.receiptType === 'supplier_refund'
                && r.sourcePaymentId === sourcePaymentId
                && !r.cancelled
                && r.documentStatus !== 'cancelled';
        }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);

        var available = (parseFloat(sourcePayment.amount) || 0) - used;
        if (amount > available + 0.01) {
            showToast('مبلغ التحصيل يتجاوز الرصيد المتاح', 'error');
            return;
        }

        var supplier2 = suppliers.find(function(s) { return s.id === supplierId; });
        var refund2 = {
            id: generateId(),
            receiptType: 'supplier_refund',
            settlementType: 'supplier_refund',
            invoiceId: '-',
            supplierId: supplierId,
            supplierName: supplier2 ? supplier2.name : (sourcePayment.supplierName || '-'),
            sourcePaymentId: sourcePaymentId,
            sourceInvoiceId: sourcePayment.invoiceId || '-',
            amount: amount,
            currency: sourcePayment.currency || 'YER',
            exchangeRate: sourcePayment.exchangeRate || 1,
            account: account,
            method: method,
            date: date,
            note: note || 'تحصيل مبلغ من مورد',
            documentStatus: 'posted',
            cancelled: false,
            status: 'تم التحصيل'
        };
        receipts.push(refund2);
        sourcePayment.refundReceiptId = refund2.id;
        saveReceipts();
        if (typeof savePayments === 'function') savePayments();
        if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
        closeModal('receiptModal');
        if (typeof oaRefreshRelated === 'function') oaRefreshRelated('receipt');
        else { renderReceipts(); if (typeof updateDashboard === 'function') updateDashboard(); }
        showToast('تم حفظ تحصيل المبلغ من المورد', 'success');
        return;
    }

    // ╔══════════════════════════════════════════════════════════╗
    // ║  فرع customer_receipt (السلوك الأصلي)                     ║
    // ╚══════════════════════════════════════════════════════════╝
    var date2 = dateEl ? dateEl.value : '';
    if (!customerId) { showToast('يرجى اختيار العميل', 'error'); return; }
    if (!date2) { showToast('يرجى اختيار التاريخ', 'error'); return; }
    if (!invoiceId) { showToast('يرجى اختيار الفاتورة', 'error'); return; }
    if (amount <= 0) { showToast('يرجى إدخال مبلغ صحيح', 'error'); return; }

    var customer = customers.find(function(c) { return c.id === customerId; });
    var invoice = salesInvoices.find(function(inv) { return inv.id === invoiceId; });
    if (!invoice) { showToast('الفاتورة غير موجودة', 'error'); return; }

    var outstanding = (typeof getInvoiceOutstanding === 'function')
        ? getInvoiceOutstanding(invoiceId, 'sale') : null;
    var paid, remaining;
    if (outstanding) {
        paid = outstanding.totalPaid || 0;
        remaining = outstanding.outstanding || 0;
    } else {
        paid = receipts.filter(function(r) {
            return r.invoiceId === invoiceId && !r.cancelled && r.documentStatus !== 'cancelled';
        }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);
        remaining = (parseFloat(invoice.total) || 0) - paid;
    }

    if (amount > remaining) {
        showToast('المبلغ أكبر من المتبقي (' + formatAmountWithCommas(remaining) + ')', 'error');
        return;
    }

    var newReceipt = {
        id: generateId(),
        invoiceId: invoiceId,
        customerId: customerId,
        customerName: customer ? customer.name : '-',
        amount: amount,
        currency: invoice.currency || 'YER',
        exchangeRate: invoice.exchangeRate || (typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(invoice.currency || 'YER') : 1),
        date: date2,
        method: method,
        note: note,
        invoiceTotal: invoice.total,
        paidBefore: paid,
        remainingAfter: remaining - amount,
        status: amount >= remaining ? 'مدفوع بالكامل' : 'دفع جزئي'
    };
    receipts.push(newReceipt);

    var updated = (typeof getInvoiceOutstanding === 'function')
        ? getInvoiceOutstanding(invoiceId, 'sale') : null;
    if (updated) {
        invoice.status = updated.statusLabel;
        var simplifiedPayment = 'unpaid';
        if (updated.derivedStatus === 'paid' || updated.derivedStatus === 'fully_returned') {
            simplifiedPayment = 'paid';
        } else if (updated.derivedStatus === 'partial'
                || updated.derivedStatus === 'overpaid'
                || updated.derivedStatus === 'partially_returned') {
            simplifiedPayment = 'partial';
        }
        invoice.paymentStatus = simplifiedPayment;
        invoice.returnStatus = updated.returnedRatio >= 0.9999
            ? 'full'
            : (updated.returnedRatio > 0 ? 'partial' : 'none');
    } else {
        var totalPaid = paid + amount;
        invoice.status = totalPaid >= (parseFloat(invoice.total) || 0) ? 'مسدد' : 'دفع جزئي';
    }

    saveReceipts();
    saveSalesInvoices();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
    closeModal('receiptModal');
    if (typeof oaRefreshRelated === 'function') oaRefreshRelated('receipt');
    else { renderReceipts(); renderSalesInvoices(); if (typeof updateDashboard === 'function') updateDashboard(); }
    showToast('تم حفظ سند القبض', 'success');
}


// ================================================================
// ===== 11. عرض سند القبض =====
// ================================================================

function viewReceipt(id) {
    var receipt = receipts.find(function(r) { return r.id === id; });
    if (!receipt) { showToast('السند غير موجود', 'error'); return; }
    var html = _buildReceiptView(receipt);
    Modal.open({
        id: 'receiptViewModal',
        title: 'تفاصيل سند القبض',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'receiptViewModal\')">إغلاق</button>' +
                '<button class="btn btn-primary" onclick="printIndividualDocument(\'receipts\', \'' + receipt.id + '\')">طباعة / حفظ PDF</button>'
    });
}


function _buildReceiptView(r) {
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';
    var companyAddress = settings.address || '';
    var companyPhone = settings.phone || '';
    var isRefund = r.receiptType === 'supplier_refund';
    var partyLabel = isRefund ? 'المورد' : 'العميل';
    var partyName = isRefund ? (r.supplierName || '-') : (r.customerName || '-');
    var title = isRefund ? 'سند تحصيل من مورد' : 'سند قبض';

    return '' +
        '<div class="doc-wrapper">' +
            '<div class="doc-header">' +
                '<div class="company-name">' + esc(companyName) + '</div>' +
                '<div class="company-info">' + esc(companyAddress) +
                    (companyPhone ? ' | هاتف: ' + esc(companyPhone) : '') + '</div>' +
            '</div>' +
            '<div class="doc-title">' + title + '</div>' +
            '<div class="doc-meta-grid">' +
                '<div><strong>رقم السند:</strong> ' + esc(r.id) + '</div>' +
                '<div><strong>التاريخ:</strong> ' + esc(r.date) + '</div>' +
                '<div><strong>الفاتورة:</strong> ' + esc(r.sourceInvoiceId || r.invoiceId || '-') + '</div>' +
                '<div><strong>' + partyLabel + ':</strong> ' + esc(partyName) + '</div>' +
                (isRefund && r.returnId ? '<div><strong>المرتجع:</strong> ' + esc(r.returnId) + '</div>' : '') +
                '<div><strong>طريقة الدفع:</strong> ' + esc(r.method) + '</div>' +
                '<div><strong>الحالة:</strong> ' +
                    (r.cancelled || r.documentStatus === 'cancelled'
                        ? '<span class="status-badge status-cancelled">ملغى</span>'
                        : '<span class="status-badge status-paid">' + esc(r.status || '') + '</span>') +
                '</div>' +
                (r.note ? '<div style="grid-column:span 2;"><strong>ملاحظة:</strong> ' + esc(r.note) + '</div>' : '') +
            '</div>' +
            '<div class="doc-amount-box">' +
                '<div class="amount-row" style="font-weight:bold;font-size:16px;">' +
                    '<span>المبلغ:</span>' +
                    '<span style="color:#1a7a4a;">' + formatCurrency(r.amount || 0, r.currency) + '</span>' +
                '</div>' +
            '</div>' +
            '<div class="doc-footer">شكراً لتعاملكم معنا<small>هذا المستند معتمد رقمياً</small></div>' +
        '</div>';
}


// ================================================================
// ===== 12. حذف سند القبض =====
// ================================================================

function deleteReceipt(id) {
    var receipt = receipts.find(function(r) { return r.id === id; });
    if (!receipt) return;

    if (receipt.cancelled || receipt.documentStatus === 'cancelled') {
        showToast('السند ملغى بالفعل — لا يمكن حذفه', 'info');
        return;
    }

    if (receipt.invoiceId && receipt.invoiceId !== '-') {
        var linkedInvoice = salesInvoices.find(function(inv) { return inv.id === receipt.invoiceId; });
        if (linkedInvoice) {
            var isAuto = receipt.note && receipt.note.indexOf('دفع نقدي') !== -1;
            if (isAuto) {
                showToast(
                    'هذا سند تلقائي مرتبط بفاتورة بيع نقدية (' + linkedInvoice.id + ').\n' +
                    'لا يمكن حذفه مباشرة — لإلغائه، ألغِ الفاتورة المرتبطة.',
                    'error', 8000
                );
                return;
            }
        }
    }

    Modal.confirm({
        title: 'تأكيد إلغاء السند',
        message:
            'لا يمكن حذف السند نهائياً (حسب قواعد النظام المحاسبي).\n\n' +
            'سيتم:\n' +
            '• وسم السند كـ "ملغى"\n' +
            '• الاحتفاظ به في السجل للتدقيق\n' +
            '• تحديث حالة الفاتورة المرتبطة\n\n' +
            'السند: ' + receipt.id + '\n' +
            'المبلغ: ' + formatCurrency(receipt.amount, receipt.currency) + '\n\n' +
            'هل تريد المتابعة؟',
        confirmText: 'إلغاء السند',
        cancelText: 'تراجع',
        confirmColor: 'warning',
        onConfirm: function() {
            receipt.cancelled = true;
            receipt.cancelledAt = new Date().toISOString();
            receipt.cancelReason = 'إلغاء يدوي من المستخدم';
            receipt.documentStatus = 'cancelled';
            receipt.sourceStatus = 'cancelled';
            saveReceipts();

            if (receipt.invoiceId && receipt.invoiceId !== '-') {
                var invoice = salesInvoices.find(function(inv) { return inv.id === receipt.invoiceId; });
                if (invoice) {
                    var outstanding = (typeof getInvoiceOutstanding === 'function')
                        ? getInvoiceOutstanding(receipt.invoiceId, 'sale') : null;
                    if (outstanding) {
                        if (outstanding.derivedStatus === 'paid' || outstanding.derivedStatus === 'fully_returned') {
                            invoice.status = 'مسدد';
                        } else if (outstanding.derivedStatus === 'partial'
                                || outstanding.derivedStatus === 'overpaid'
                                || outstanding.derivedStatus === 'partially_returned') {
                            invoice.status = 'دفع جزئي';
                        } else {
                            invoice.status = 'غير مسدد';
                        }
                    } else {
                        var totalPaid = receipts.filter(function(r) {
                            return r.invoiceId === receipt.invoiceId && !r.cancelled && r.documentStatus !== 'cancelled';
                        }).reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);
                        if (totalPaid >= (parseFloat(invoice.total) || 0)) {
                            invoice.status = 'مسدد';
                        } else if (totalPaid > 0) {
                            invoice.status = 'دفع جزئي';
                        } else {
                            invoice.status = 'غير مسدد';
                        }
                    }
                    saveSalesInvoices();
                }
            }

            if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
            if (typeof oaRefreshRelated === 'function') oaRefreshRelated('receipt');
            else { renderReceipts(); renderSalesInvoices(); if (typeof updateDashboard === 'function') updateDashboard(); }
            showToast('تم إلغاء السند — يمكن مراجعته في السجل', 'success');
        }
    });
}


// ================================================================
// ===== 13. تهيئة سندات القبض =====
// ================================================================

function initReceipts() {
    loadReceipts();
    renderReceipts();

    var searchEl = document.getElementById('recSearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderReceipts, 300));
    }

    console.log('Receipts: ' + receipts.length + ' سند');
}


// ================================================================
// ===== END OF RECEIPTS.JS =====
// ================================================================