// ================================================================
// Open Account — السكرتير التنفيذي (نسخة عالمية)
// الملف: ai-agent-universal.js
// يدعم: Gemini + OpenAI-compatible (Groq, OpenAI, OpenRouter, Cerebras)
// ================================================================

var aiConversation = [];

var AI_DEFAULT_ENDPOINT = 'https://api.groq.com/openai/v1';
var AI_DEFAULT_MODEL = 'openai/gpt-oss-120b';
var AI_TIMEOUT_MS = 60000;
var AI_MAX_ROUNDS = 6;

var AI_DEFAULT_SYSTEM = 'أنت السكرتير التنفيذي لتطبيق Open Account المحاسبي. ' +
    'دورك: البحث والقراءة والتحليل والإجابة المباشرة. ' +
    'صلاحياتك: قراءة فقط — لا تنفّذ أي عملية كتابة أو تعديل أو حذف. ' +

    '=== قواعد صارمة للدقة === ' +
    '1. الأرقام والعملات: كل مبلغ يجب أن يُعرض بعملته. ' +
    '   - إذا كان المبلغ بالدولار، اكتب: "50 USD" وليس "50". ' +
    '   - إذا كان بالريال السعودي، اكتب: "50 SAR". ' +
    '   - حقل debit/credit = العملة الأصلية. ' +
    '   - حقل debitBase/creditBase = العملة الأساسية. ' +
    '   - عند عرض قيد: اعرض العملة الأصلية أولاً، ثم الأساسية بين قوسين. ' +
    '2. لا تخلط بين مبالغ بعملات مختلفة. ' +
    '3. عند عرض قيد: اذكر العملة بوضوح. ' +

    '=== قواعد البحث === ' +
    '4. عند البحث عن قيد فاتورة: ' +
    '   - ابحث بـ referenceId = رقم الفاتورة. ' +
    '   - ابحث بـ referenceType = نوع المستند. ' +
    '   - لا تحكم بعدم وجود القيد حتى تفحص referenceId و referenceType معاً. ' +
    '5. عند البحث عن مستند: ' +
    '   - اعرض بياناته الكاملة (التاريخ، الطرف، المبلغ، العملة، الحالة). ' +

    '=== قواعد التحليل === ' +
    '6. عند السؤال "هل هناك أخطاء": ' +
    '   - افحص كل الفواتير والسندات. ' +
    '   - تحقق من وجود قيد لكل مستند. ' +
    '   - اعرض النتيجة مع المستندات المحددة. ' +
    '7. عند اكتشاف "مشكلة": ' +
    '   - تحقق منها مرة ثانية قبل الإعلان. ' +
    '   - اذكر المستند ورقمه وتاريخه. ' +

    '=== قواعد السلوك === ' +
    '8. عند تصحيح خطأ: ' +
    '   - اعترف بالخطأ بوضوح. ' +
    '   - اشرح سبب الخطأ. ' +
    '   - اعرض الإجابة الصحيحة فوراً. ' +
    '   - لا ترفض الاستمرار في المحادثة. ' +
    '9. لا تقل "لا أستطيع" — استخدم الأدوات المتاحة. ' +
    '10. لا تختلق بيانات — إذا لم تجد، قل "لم أجد". ' +
    '11. لا تختصر — اعرض كل البيانات المطلوبة. ' +
    '12. أجب بالعربية الفصحى المبسطة. ' +

    '=== قواعد خاصة === ' +
    '13. عند السؤال "كم الزكاة": أجب بالرقم فقط، ثم اعرض التفاصيل إن طُلب. ' +
    '14. عند السؤال عن سبب مشكلة: اشرح السبب مع المستند/القيد. ' +
    '15. عند السؤال عن توقع: استخدم السجلات التاريخية. ' +
    '16. عند التنبيهات: أذكرها استباقياً عند السؤال عن الوضع العام. ' +

    '=== أمثلة === ' +
    'سؤال: كم عدد العملاء؟ ' +
    'جواب: 5 عملاء. ' +
    '' +
    'سؤال: ما قيمة قيد فاتورة 5073PJ؟ ' +
    'جواب: قيد JE-001312 — العملة: SAR — مدين: 50 SAR (صندوق)، 35 SAR (COGS) — دائن: 50 SAR (إيرادات)، 35 SAR (مخزون). ' +
    '' +
    'سؤال: هل القيود متوازنة؟ ' +
    'جواب: نعم، كل القيود متوازنة (إجمالي المدين = إجمالي الدائن). ' +
    '' +
    'سؤال: أنا أرى أن القيد 50 دولار وليس 50 ريال. ' +
    'جواب: شكراً للتصحيح. عند مراجعة القيد JE-001326، العملة الأصلية USD. المبلغ 50 USD (≈ 190 SAR). سأتحقق من ذلك في المرات القادمة. ' +
    '' +
    'سؤال: أحضر لي قائمة الفواتير بدون قيود. ' +
    'جواب: (يفحص) جميع الفواتير مرتبطة بقيودها. لا توجد فواتير بدون قيود.';

// ================================================================
// ===== 1. الإعدادات =====
// ================================================================

function getAISettings() {
    var s = Storage.get(STORAGE_KEYS.AI_SETTINGS, {}) || {};
    return {
        apiKey: s.apiKey || '',
        endpoint: (s.endpoint || AI_DEFAULT_ENDPOINT).trim(),
        model: (s.model || AI_DEFAULT_MODEL).trim(),
        shareData: s.shareData === true,
        requestConfirm: s.requestConfirm !== false
    };
}

function _aiDetectProvider(endpoint) {
    var ep = String(endpoint || '').toLowerCase();
    if (ep.indexOf('generativelanguage.googleapis.com') !== -1) return 'gemini';
    if (ep.indexOf('groq.com') !== -1) return 'groq';
    if (ep.indexOf('openai.com') !== -1) return 'openai';
    if (ep.indexOf('openrouter.ai') !== -1) return 'openrouter';
    if (ep.indexOf('cerebras.ai') !== -1) return 'cerebras';
    if (ep.indexOf('together') !== -1) return 'together';
    return 'openai';
}

function saveAISettings() {
    var endpointEl = document.getElementById('aiEndpoint');
    var modelEl = document.getElementById('aiModel');
    var keyEl = document.getElementById('aiApiKey');
    var shareEl = document.getElementById('aiShareData');
    var confirmEl = document.getElementById('aiConfirm');
    var s = {
        apiKey: (keyEl || {}).value || '',
        endpoint: ((endpointEl || {}).value || AI_DEFAULT_ENDPOINT).trim(),
        model: ((modelEl || {}).value || AI_DEFAULT_MODEL).trim(),
        shareData: (shareEl || {}).checked === true,
        requestConfirm: (confirmEl || {}).checked !== false
    };
    Storage.set(STORAGE_KEYS.AI_SETTINGS, s);
    if (typeof showToast === 'function') showToast('تم حفظ الإعدادات', 'success');
}

function openAISettings() {
    var s = getAISettings();
    var provider = _aiDetectProvider(s.endpoint);
    var providerLabels = {
        gemini: 'Google Gemini',
        groq: 'Groq',
        openai: 'OpenAI',
        openrouter: 'OpenRouter',
        cerebras: 'Cerebras',
        together: 'Together AI'
    };
    var body =
        '<div class="ai-warning">المفتاح يُحفظ في LocalStorage على هذا الجهاز فقط.</div>' +
        '<div class="form-field"><label>مفتاح API</label>' +
            '<input type="password" id="aiApiKey" value="' + esc(s.apiKey) + '" autocomplete="off" placeholder="أدخل المفتاح"></div>' +
        '<div class="form-field"><label>رابط API</label>' +
            '<input id="aiEndpoint" value="' + esc(s.endpoint) + '" placeholder="https://api.groq.com/openai/v1"></div>' +
        '<div class="form-field"><label>النموذج</label>' +
            '<input id="aiModel" value="' + esc(s.model) + '" placeholder="openai/gpt-oss-120b"></div>' +
        '<div style="padding:8px 12px;background:rgba(0,212,255,0.08);border:1px solid rgba(0,212,255,0.25);border-radius:8px;margin-top:8px;font-size:12px;">' +
            'المزود المكتشف: <strong>' + (providerLabels[provider] || provider) + '</strong>' +
        '</div>' +
        '<label class="ai-check" style="display:flex;align-items:center;gap:10px;margin-top:14px;padding:12px;background:rgba(0,212,255,0.06);border:1px solid rgba(0,212,255,0.25);border-radius:10px;cursor:pointer;">' +
            '<input type="checkbox" id="aiShareData" ' + (s.shareData ? 'checked' : '') + ' style="width:20px;height:20px;cursor:pointer;">' +
            '<span style="color:var(--color-text);font-size:13px;">إرسال سجلات التطبيق للتحليل</span></label>' +
        '<label class="ai-check" style="display:flex;align-items:center;gap:10px;margin-top:10px;padding:12px;background:rgba(0,214,143,0.06);border:1px solid rgba(0,214,143,0.25);border-radius:10px;cursor:pointer;">' +
            '<input type="checkbox" id="aiConfirm" ' + (s.requestConfirm ? 'checked' : '') + ' style="width:20px;height:20px;cursor:pointer;">' +
            '<span style="color:var(--color-text);font-size:13px;">طلب تأكيد قبل العمليات المالية</span></label>';

    Modal.open({
        id: 'aiSettingsModal',
        title: 'إعدادات السكرتير التنفيذي',
        size: 'normal',
        body: body,
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'aiSettingsModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" onclick="saveAISettings();closeModal(\'aiSettingsModal\')">حفظ</button>'
    });
}

// ================================================================
// ===== 2. لقطة بيانات التطبيق =====
// ================================================================

function _aiDataSnapshot() {
    try {
        var out = { generatedAt: new Date().toISOString(), counts: {} };
        var map = {
            products: products, customers: customers, suppliers: suppliers,
            salesInvoices: salesInvoices, purchaseInvoices: purchaseInvoices,
            receipts: receipts, payments: payments, expenses: expenses
        };
        Object.keys(map).forEach(function (k) {
            var v = map[k];
            if (!Array.isArray(v)) v = [];
            out.counts[k] = v.length;
            out[k] = v.slice(-30);
        });
        return out;
    } catch (e) {
        return { error: 'خطأ في قراءة البيانات' };
    }
}

// ================================================================
// ===== 3. صيغ الأدوات =====
// ================================================================

function _aiGetRawTools() {
    if (typeof aiGetToolDefinitions !== 'function') return [];
    return aiGetToolDefinitions();
}

function _aiToolsOpenAIFormat() {
    var defs = _aiGetRawTools();
    var result = [];
    defs.forEach(function (t) {
        result.push({
            type: 'function',
            function: {
                name: t.function.name,
                description: t.function.description,
                parameters: t.function.parameters || { type: 'object', properties: {} }
            }
        });
    });
    return result;
}

function _aiToolsGeminiFormat() {
    var defs = _aiGetRawTools();
    var decls = [];
    defs.forEach(function (t) {
        decls.push({
            name: t.function.name,
            description: t.function.description,
            parameters: t.function.parameters || { type: 'object', properties: {} }
        });
    });
    return [{ functionDeclarations: decls }];
}

// ================================================================
// ===== 4. بناء الـ payload =====
// ================================================================

function _aiPayloadGemini(shareData) {
    var s = getAISettings();
    var system = AI_DEFAULT_SYSTEM;
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    system = system + ' العملة الأساسية: ' + baseCurrency + '.';
    if (shareData) {
        system = system + ' سياق التطبيق: ' + JSON.stringify(_aiDataSnapshot());
    }

    var contents = [];
    var slice = aiConversation.slice(-20);
    slice.forEach(function (m) {
        if (!m || !m.role) return;
        var role = (m.role === 'assistant') ? 'model' : m.role;
        var parts = m.parts || [{ text: m.content || '' }];
        contents.push({ role: role, parts: parts });
    });

    var payload = {
        systemInstruction: { parts: [{ text: system }] },
        contents: contents,
        generationConfig: { temperature: 0.2, maxOutputTokens: 4096 }
    };

    var tools = _aiToolsGeminiFormat();
    if (tools && tools.length > 0) {
        payload.tools = tools;
    }

    return payload;
}

function _aiPayloadOpenAI(shareData) {
    var s = getAISettings();
    var system = AI_DEFAULT_SYSTEM;
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';
    system = system + ' العملة الأساسية: ' + baseCurrency + '.';
    if (shareData) {
        system = system + ' سياق التطبيق: ' + JSON.stringify(_aiDataSnapshot());
    }

    var messages = [];
    messages.push({ role: 'system', content: system });

    var slice = aiConversation.slice(-20);
    slice.forEach(function (m) {
        if (!m || !m.role) return;
        if (m.role === 'user' || m.role === 'assistant' || m.role === 'tool') {
            messages.push(m);
        }
    });

    var payload = {
        model: s.model,
        messages: messages,
        temperature: 0.2,
        max_tokens: 4096
    };

    var tools = _aiToolsOpenAIFormat();
    if (tools && tools.length > 0) {
        payload.tools = tools;
        payload.tool_choice = 'auto';
    }

    return payload;
}

// ================================================================
// ===== 5. بناء الرابط =====
// ================================================================

function _aiBuildUrl(provider, settings) {
    var s = settings;
    var base = (s.endpoint || AI_DEFAULT_ENDPOINT).replace(/\/+$/, '');
    if (provider === 'gemini') {
        if (base.indexOf(':generateContent') >= 0) {
            return base + (base.indexOf('?') >= 0 ? '&' : '?') + 'key=' + encodeURIComponent(s.apiKey);
        }
        return base + '/models/' + encodeURIComponent(s.model) + ':generateContent?key=' + encodeURIComponent(s.apiKey);
    }
    if (base.indexOf('/chat/completions') === -1) {
        return base + '/chat/completions';
    }
    return base;
}

// ================================================================
// ===== 6. الاتصال الموحّد =====
// ================================================================

async function _aiCall(payload, provider) {
    var s = getAISettings();
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, AI_TIMEOUT_MS);
    try {
        var headers = { 'Content-Type': 'application/json' };
        if (provider !== 'gemini') {
            headers['Authorization'] = 'Bearer ' + s.apiKey;
        }
        var url = _aiBuildUrl(provider, s);
        var res = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(payload),
            signal: controller.signal
        });
        var data = null;
        try { data = await res.json(); } catch (e) { data = null; }
        if (!res.ok) {
            var errMsg = 'فشل الاتصال (' + res.status + ')';
            if (data && data.error) {
                if (typeof data.error === 'string') errMsg = data.error;
                else if (data.error.message) errMsg = data.error.message;
            }
            throw new Error(errMsg);
        }
        return data;
    } finally {
        clearTimeout(timer);
    }
}

// ================================================================
// ===== 7. استخراج الرد =====
// ================================================================

function _aiExtractResponse(data, provider) {
    if (provider === 'gemini') {
        var cand = data.candidates && data.candidates[0];
        if (!cand || !cand.content) return { text: null, toolCalls: [], raw: null };
        var parts = cand.content.parts || [];
        var text = '';
        var toolCalls = [];
        parts.forEach(function (p) {
            if (p.text) text += p.text;
            if (p.functionCall) {
                toolCalls.push({
                    id: 'gem_' + Date.now() + '_' + toolCalls.length,
                    name: p.functionCall.name,
                    args: p.functionCall.args || {}
                });
            }
        });
        return { text: text.trim() || null, toolCalls: toolCalls, raw: cand.content };
    }

    var msg = data.choices && data.choices[0] && data.choices[0].message;
    if (!msg) return { text: null, toolCalls: [], raw: null };
    var oaiToolCalls = [];
    if (msg.tool_calls) {
        msg.tool_calls.forEach(function (tc) {
            var args = {};
            try { args = tc.function && tc.function.arguments ? JSON.parse(tc.function.arguments) : {}; }
            catch (e) { args = {}; }
            oaiToolCalls.push({
                id: tc.id,
                name: tc.function && tc.function.name,
                args: args
            });
        });
    }
    return { text: (msg.content || '').trim() || null, toolCalls: oaiToolCalls, raw: msg };
}

// ================================================================
// ===== 8. نافذة تأكيد =====
// ================================================================

function _aiConfirmDialog(title, summaryHtml) {
    return new Promise(function (resolve) {
        var modalId = 'aiConfirm_' + Date.now();
        var resolved = false;
        function finish(v) {
            if (resolved) return;
            resolved = true;
            resolve(v);
        }
        Modal.open({
            id: modalId,
            title: title || 'تأكيد التنفيذ',
            size: 'normal',
            body: '<div style="padding:4px;">' + (summaryHtml || '') + '</div>',
            footer:
                '<button class="btn btn-cancel" id="' + modalId + '_cancel">إلغاء</button>' +
                '<button class="btn btn-success" id="' + modalId + '_confirm">تنفيذ</button>',
            onOpen: function (el) {
                var confirmBtn = el.querySelector('#' + modalId + '_confirm');
                var cancelBtn = el.querySelector('#' + modalId + '_cancel');
                if (confirmBtn) confirmBtn.addEventListener('click', function () {
                    finish(true);
                    Modal.close(modalId);
                });
                if (cancelBtn) cancelBtn.addEventListener('click', function () {
                    finish(false);
                    Modal.close(modalId);
                });
                var observer = new MutationObserver(function () {
                    if (!document.getElementById(modalId)) {
                        observer.disconnect();
                        finish(false);
                    }
                });
                observer.observe(document.body, { childList: true, subtree: true });
            }
        });
    });
}

// ================================================================
// ===== 9. تنفيذ أداة =====
// ================================================================

async function _aiHandleFunctionCall(name, args, requestConfirm) {
    args = args || {};
    var preview;
    try { preview = aiPreviewTool(name, args); }
    catch (e) { return { ok: false, message: 'خطأ في المعاينة: ' + (e.message || e) }; }
    if (!preview.ok) return { ok: false, message: preview.message };

    if (preview.requiresConfirm === false) {
        try { return aiExecuteTool(name, args); }
        catch (e) { return { ok: false, message: 'خطأ: ' + (e.message || e) }; }
    }

    var approved = true;
    if (requestConfirm) {
        approved = await _aiConfirmDialog(preview.title || 'تأكيد', preview.summary);
    }
    if (!approved) return { ok: false, message: 'ألغى المالك تنفيذ العملية.' };

    try {
        if (typeof preview.onConfirm === 'function') return preview.onConfirm();
        return aiExecuteTool(name, args);
    } catch (e) {
        return { ok: false, message: 'خطأ في التنفيذ: ' + (e.message || e) };
    }
}

// ================================================================
// ===== 10. إضافة الأدوار للمحادثة =====
// ================================================================

function _aiAppendAssistantGemini(rawContent) {
    var parts = (rawContent && rawContent.parts) ? rawContent.parts : [];
    aiConversation.push({ role: 'model', parts: parts });
}

function _aiAppendAssistantOpenAI(rawMsg) {
    var msg = { role: 'assistant', content: rawMsg.content || null };
    if (rawMsg.tool_calls) msg.tool_calls = rawMsg.tool_calls;
    aiConversation.push(msg);
}

function _aiAppendToolResultGemini(name, result) {
    aiConversation.push({
        role: 'user',
        parts: [{
            functionResponse: {
                name: name,
                response: result || { ok: false, message: 'لا نتيجة' }
            }
        }]
    });
}

function _aiAppendToolResultOpenAI(toolCallId, name, result) {
    aiConversation.push({
        role: 'tool',
        tool_call_id: toolCallId,
        name: name,
        content: JSON.stringify(result || { ok: false, message: 'لا نتيجة' })
    });
}

// ================================================================
// ===== 11. دورة المحادثة =====
// ================================================================

async function _aiRunConversation(shareData, requestConfirm) {
    var s = getAISettings();
    var provider = _aiDetectProvider(s.endpoint);
    var finalText = '';
    var lastToolMessage = '';
    var toolCallMade = false;

    for (var round = 0; round < AI_MAX_ROUNDS; round++) {
        var payload;
        if (provider === 'gemini') payload = _aiPayloadGemini(shareData);
        else payload = _aiPayloadOpenAI(shareData);

        var data;
        try {
            data = await _aiCall(payload, provider);
        } catch (e) {
            if (lastToolMessage) return lastToolMessage;
            throw e;
        }

        var response = _aiExtractResponse(data, provider);
        var toolCalls = response.toolCalls || [];
        var textContent = response.text || '';

        // حالة 1: استدعى أدوات
        if (toolCalls.length > 0) {
            toolCallMade = true;

            if (provider === 'gemini') {
                _aiAppendAssistantGemini(response.raw);
            } else {
                _aiAppendAssistantOpenAI(response.raw);
            }

            for (var i = 0; i < toolCalls.length; i++) {
                var tc = toolCalls[i];
                var result = await _aiHandleFunctionCall(tc.name, tc.args || {}, requestConfirm);
                if (result && result.message) {
                    if (result.ok) lastToolMessage = result.message;
                    else lastToolMessage = 'تعذر التنفيذ: ' + result.message;
                }
                if (provider === 'gemini') {
                    _aiAppendToolResultGemini(tc.name, result);
                } else {
                    _aiAppendToolResultOpenAI(tc.id, tc.name, result);
                }
            }
            continue;
        }

        // حالة 2: رد نصي في الجولة الأولى بدون أدوات
        if (!toolCallMade && round === 0 && textContent) {
            aiConversation.push({ role: 'assistant', content: textContent });
            aiConversation.push({
                role: 'user',
                content: 'يجب استدعاء أداة. أعد المحاولة باستدعاء أداة مناسبة.'
            });
            continue;
        }

        // حالة 3: رد نصي نهائي
        finalText = textContent;
        if (finalText) {
            aiConversation.push({ role: 'assistant', content: finalText });
        }
        break;
    }

    if (!toolCallMade && !lastToolMessage) {
        return 'لم أتمكن من تنفيذ الطلب. أعد صياغته بوضوح.';
    }
    return finalText || lastToolMessage || 'تم تنفيذ الأمر.';
}

// ================================================================
// ===== 12. الواجهة =====
// ================================================================

function openAIAgent() {
    // ✅ استرجاع المحادثة المحفوظة
    _aiLoadHistory();
    
    var body = '';
    body += '<div class="ai-chat" id="aiChat">';
    if (!aiConversation || aiConversation.length === 0) {
        body += '<div class="ai-empty">مرحباً. أنا سكرتيرك التنفيذي — أُنفّذ أوامرك المحاسبية بأدوات التطبيق.</div>';
    }
    body += '</div>';
    body += '<div class="ai-compose">';
    body += '<textarea id="aiPrompt" rows="3" placeholder="اكتب أمرك المحاسبي هنا..."></textarea>';
    body += '</div>';

    Modal.open({
        id: 'aiAgentModal',
        title: 'السكرتير التنفيذي',
        size: 'large',
        body: body,
        footer:
            '<button class="btn btn-secondary" onclick="openAISettings()">الإعدادات</button>' +
            '<button class="btn btn-secondary" onclick="_aiClearConversation()">محادثة جديدة</button>' +
            '<button class="btn btn-cancel" onclick="closeModal(\'aiAgentModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" id="aiSendBtn" onclick="sendAIMessage()">إرسال</button>',
        onOpen: function () {
            // ✅ عرض الرسائل السابقة
            if (aiConversation && aiConversation.length > 0) {
                aiConversation.forEach(function(msg) {
                    if (!msg || !msg.role) return;
                    if (msg.role === 'user' && msg.content) {
                        _aiRender('user', msg.content);
                    } else if (msg.role === 'assistant' && msg.content) {
                        _aiRender('assistant', msg.content);
                    }
                });
            }
            
            var p = document.getElementById('aiPrompt');
            if (p) p.focus();
        }
    });
}

// ✅ مسح المحادثة (يدوي)
function _aiClearConversation() {
    aiConversation = [];
    try { Storage.remove('oa_ai_history'); } catch (e) {}
    
    var chat = document.getElementById('aiChat');
    if (chat) {
        chat.innerHTML = '<div class="ai-empty">محادثة جديدة — كيف أخدمك؟</div>';
    }
    
    if (typeof showToast === 'function') showToast('محادثة جديدة', 'info');
}

// ✅ حفظ المحادثة (آخر 20 رسالة)
function _aiSaveHistory() {
    try {
        // ✅ حفظ الرسائل النصية فقط — بدون functionCall/functionResponse
        var textOnly = aiConversation.filter(function(m) {
            if (!m || !m.role) return false;
            // رسالة model بـ functionCall فقط — تجاهل
            if (m.role === 'model' && m.parts) {
                var hasOnlyFunctionCall = m.parts.every(function(p) {
                    return p.functionCall && !p.text;
                });
                if (hasOnlyFunctionCall) return false;
            }
            // رسالة user بـ functionResponse فقط — تجاهل
            if (m.role === 'user' && m.parts) {
                var hasOnlyFunctionResponse = m.parts.every(function(p) {
                    return p.functionResponse && !p.text;
                });
                if (hasOnlyFunctionResponse) return false;
            }
            return true;
        });
        
        var slice = textOnly.slice(-20);
        Storage.set('oa_ai_history', slice);
    } catch (e) {
        console.warn('AI history save failed:', e);
    }
}

// ✅ استرجاع المحادثة
function _aiLoadHistory() {
    try {
        var h = Storage.get('oa_ai_history', []);
        if (Array.isArray(h) && h.length > 0) {
            // ✅ فلترة احتياطية — إزالة functionCall/functionResponse
            var textOnly = h.filter(function(m) {
                if (!m || !m.role) return false;
                // رسالة model بـ functionCall فقط
                if (m.role === 'model' && m.parts) {
                    var hasOnlyFunctionCall = m.parts.every(function(p) {
                        return p.functionCall && !p.text;
                    });
                    if (hasOnlyFunctionCall) return false;
                }
                // رسالة user بـ functionResponse فقط
                if (m.role === 'user' && m.parts) {
                    var hasOnlyFunctionResponse = m.parts.every(function(p) {
                        return p.functionResponse && !p.text;
                    });
                    if (hasOnlyFunctionResponse) return false;
                }
                return true;
            });
            aiConversation = textOnly.slice(-20);
        }
    } catch (e) {
        // تجاهل
    }
}

function _aiRender(role, text) {
    var c = document.getElementById('aiChat');
    if (!c) return;
    var empty = c.querySelector('.ai-empty');
    if (empty) empty.remove();
    var div = document.createElement('div');
    div.className = 'ai-message ' + (role === 'user' ? 'ai-user' : 'ai-assistant');
    div.textContent = text || '';
    c.appendChild(div);
    c.scrollTop = c.scrollHeight;
}

// ================================================================
// ===== 13. الإرسال =====
// ================================================================

async function sendAIMessage() {
    var p = document.getElementById('aiPrompt');
    var text = p && p.value.trim();
    var s = getAISettings();

  if (!text) return;
if (!s.apiKey) {
    openAISettings();
    if (typeof showToast === 'function') showToast('أدخل مفتاح API أولاً', 'error');
    return;
}

// ✅ لا نمسح المحادثة — نحتفظ بالسياق

_aiRender('user', text);
aiConversation.push({ role: 'user', content: text });
p.value = '';

    var btn = document.getElementById('aiSendBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'جارٍ التنفيذ...'; }

    try {
        var answer = await _aiRunConversation(s.shareData, s.requestConfirm);
        _aiRender('assistant', answer);
    } catch (e) {
        var msg = e && e.message ? e.message : String(e);
        if (msg.indexOf('aborted') !== -1 || msg.indexOf('AbortError') !== -1) {
            msg = 'انتهت مهلة الاتصال.';
        }
        _aiRender('assistant', 'تعذر تنفيذ الطلب: ' + msg);
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = 'إرسال'; }
        
        // ✅ حفظ المحادثة في Storage
        _aiSaveHistory();
    }
}

// ================================================================
// ===== 14. التهيئة =====
// ================================================================

function initAIAgentUniversal() {
    var b = document.getElementById('btnAIAgent');
    if (b) {
        var newB = b.cloneNode(true);
        b.parentNode.replaceChild(newB, b);
        newB.addEventListener('click', openAIAgent);
    }
}

// ================================================================
// ===== END OF ai-agent-universal.js =====
// ================================================================



