// ================================================================
// Open Account — نظام محاسبي
// الملف: dashboard.js
// الوصف: لوحة التحكم الرئيسية
// النسخة: v3 — مع مصدر موحد لحساب الرصيد
// ================================================================


// ================================================================
// ===== 1. حساب الإحصائيات =====
// ================================================================

function calculateDashboardStats() {
    var stats = {
        productsCount: 0,
        inventoryValue: {},
        lowStockCount: 0,
        cashBalances: {},
        bankBalances: {},
        receivables: {},
        payables: {},
        receivablesFromSuppliers: {},
        payablesToCustomers: {},
        monthSales: {},
        monthPurchases: {},
        monthExpenses: {},
        customersCount: 0,
        suppliersCount: 0,
        salesCount: 0,
        purchasesCount: 0
    };

    // ===== 1. المخزون =====
    if (typeof products !== 'undefined' && Array.isArray(products)) {
    stats.productsCount = products.length;

    var baseCur = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

    products.forEach(function(p) {
        var value = (typeof getProductCostValueBase === 'function')
            ? getProductCostValueBase(p)
            : 0;

        stats.inventoryValue[baseCur] = (stats.inventoryValue[baseCur] || 0) + value;

        var qty = parseFloat(p.quantity) || 0;
        if (qty < 5) stats.lowStockCount++;
    });
}

    // ===== 2. العملاء والموردين =====
    if (typeof customers !== 'undefined' && Array.isArray(customers)) {
        stats.customersCount = customers.length;
    }
    if (typeof suppliers !== 'undefined' && Array.isArray(suppliers)) {
        stats.suppliersCount = suppliers.length;
    }

    // ===== 3. الشهر الحالي =====
    var now = new Date();
    var currentMonth = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');

// ===== 4. المبيعات =====
if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
    stats.salesCount = salesInvoices.length;

    // ===== جمع الصافي لكل عميل (supplierId + currency) =====
  // ✅ توحيد المصدر: الرصيد الإجمالي للعملاء من القيود
// (بدل الحساب اليدوي الذي يستثني customer_refund)
salesInvoices
    .filter(function(inv){ return inv.status !== 'ملغاة' && !inv.cancelled; })
    .forEach(function(inv) {
        var c = inv.currency || 'YER';

        // ===== إجمالي مبيعات الشهر (يبقى كما هو) =====
        if (inv.date && inv.date.indexOf(currentMonth) === 0) {
            var gross = parseFloat(inv.total) || 0;
            stats.monthSales[c] = (stats.monthSales[c] || 0) + gross;
        }
    });

// ===== الرصيد الموحّد لحساب 1100 (العملاء) =====
if (typeof AccountingBalance !== 'undefined') {
    var baseCur = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var ab = AccountingBalance.inBaseCurrency('1100');
    var net = ab.balance;
    // موجب = مدين (لك عند العملاء)، سالب = دائن (عليك للعملاء)
    if (net > 0.01) {
        stats.receivables[baseCur] = net;
    } else if (net < -0.01) {
        stats.payablesToCustomers[baseCur] = Math.abs(net);
    }
}

    // ===== أرصدة العملاء الدائنة من الفواتير الملغاة =====
    // سندات القبض النشطة على فاتورة ملغاة تبقى التزامًا للعميل.
    var cancelledInvoiceCredits = {};
    var customerRefunds = {};
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(rec) {
            if (!_reportIsActive(rec) || !rec.invoiceId || rec.receiptType === 'supplier_refund') return;
            var linkedInvoice = salesInvoices.find(function(inv) { return inv.id === rec.invoiceId; });
            if (!linkedInvoice || !(linkedInvoice.status === 'ملغاة' || linkedInvoice.cancelled)) return;
            var currency = rec.currency || linkedInvoice.currency || 'YER';
            var key = (rec.customerId || linkedInvoice.customerId || 'unknown') + '|' + currency;
            cancelledInvoiceCredits[key] = (cancelledInvoiceCredits[key] || 0) + (parseFloat(rec.amount) || 0);
        });
    }
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(pay) {
            if (!_reportIsActive(pay) || pay.paymentType !== 'customer_refund') return;
            var currency = pay.currency || 'YER';
            var key = (pay.customerId || 'unknown') + '|' + currency;
            customerRefunds[key] = (customerRefunds[key] || 0) + (parseFloat(pay.amount) || 0);
        });
    }
    Object.keys(cancelledInvoiceCredits).forEach(function(key) {
        var payable = cancelledInvoiceCredits[key] - (customerRefunds[key] || 0);
        var currency = key.split('|')[1];
        if (payable > 0.01) {
            stats.payablesToCustomers[currency] = (stats.payablesToCustomers[currency] || 0) + payable;
        }
    });

    // ===== خصم مرتجعات المبيعات من مبيعات الشهر =====
    if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        returnsDocs.forEach(function(ret) {
            if (!_reportIsActive(ret)) return;
            if (ret.kind !== 'sale') return;
            if (!(ret.date && ret.date.indexOf(currentMonth) === 0)) return;
            var c = ret.currency || 'YER';
            stats.monthSales[c] = (stats.monthSales[c] || 0) - (parseFloat(ret.amount) || 0);
        });
    }
}

// ===== 5. المشتريات =====
if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
    stats.purchasesCount = purchaseInvoices.length;

    // ===== جمع الصافي لكل مورد =====
    var supplierNet = {};

    purchaseInvoices
        .filter(function(inv){ return inv.status !== 'ملغاة' && !inv.cancelled; })
        .forEach(function(inv) {
            var c = inv.currency || 'YER';

            // ===== صافي لكل مورد =====
            if (typeof getInvoiceOutstanding === 'function') {
                var o = getInvoiceOutstanding(inv.id, 'purchase');
                if (o) {
                    var key = (inv.supplierId || 'unknown') + '|' + c;
                    supplierNet[key] = (supplierNet[key] || 0) + o.outstanding;
                }
            }

            // ===== إجمالي مشتريات الشهر =====
            if (inv.date && inv.date.indexOf(currentMonth) === 0) {
                var gross = parseFloat(inv.total) || 0;
                stats.monthPurchases[c] = (stats.monthPurchases[c] || 0) + gross;
            }
        });

    // ===== تصنيف الصافي حسب الإشارة =====
    // ===== تحصيلات الموردين (supplier_refund) =====
var supplierRefunds = {};
if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
    receipts.forEach(function(rec) {
        if (!_reportIsActive(rec)) return;
        if (rec.receiptType !== 'supplier_refund') return;
        var c = rec.currency || 'YER';
        var key = (rec.supplierId || 'unknown') + '|' + c;
        supplierRefunds[key] = (supplierRefunds[key] || 0) + (parseFloat(rec.amount) || 0);
    });
}

// ===== دمج supplierNet + supplierRefunds =====
var allSupplierKeys = {};
Object.keys(supplierNet).forEach(function(k) { allSupplierKeys[k] = true; });
Object.keys(supplierRefunds).forEach(function(k) { allSupplierKeys[k] = true; });

Object.keys(allSupplierKeys).forEach(function(key) {
    var net = supplierNet[key] || 0;
    var refund = supplierRefunds[key] || 0;
    var adjustedNet = net + refund;
    var c = key.split('|')[1];

    if (adjustedNet > 0.01) {
        stats.payables[c] = (stats.payables[c] || 0) + adjustedNet;
    } else if (adjustedNet < -0.01) {
        stats.receivablesFromSuppliers[c] = 
            (stats.receivablesFromSuppliers[c] || 0) + Math.abs(adjustedNet);
    }
});

    // ===== خصم مرتجعات المشتريات =====
    if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        returnsDocs.forEach(function(ret) {
            if (!_reportIsActive(ret)) return;
            if (ret.kind !== 'purchase') return;
            if (!(ret.date && ret.date.indexOf(currentMonth) === 0)) return;
            var c = ret.currency || 'YER';
            stats.monthPurchases[c] = (stats.monthPurchases[c] || 0) - (parseFloat(ret.amount) || 0);
        });
    }
}

    // ===== 6. المصاريف =====
    if (typeof expenses !== 'undefined' && Array.isArray(expenses)) {
        expenses.forEach(function(e) {
            if (e.archived) return;
            if (!_reportIsActive(e)) return;
            var amount = parseFloat(e.amount) || 0;
            var c = e.currency || 'YER';

            if (e.date && e.date.indexOf(currentMonth) === 0) {
                stats.monthExpenses[c] = (stats.monthExpenses[c] || 0) + amount;
            }
        });
    }

// ===== 7. الصندوق والبنك — من المصدر الموحد =====
if (typeof getAccountBalanceByCurrency === 'function') {
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var cashBal = getAccountBalanceByCurrency('cashbox', c);
        if (cashBal !== 0) stats.cashBalances[c] = cashBal;
        
        var bankBal = getAccountBalanceByCurrency('bank', c);
        if (bankBal !== 0) stats.bankBalances[c] = bankBal;
    });
} else {
    // احتياطي: الطريقة القديمة
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(r) {
            if (!_reportIsActive(r)) return;
            var amount = parseFloat(r.amount) || 0;
            var c = r.currency || 'YER';
            var method = r.method || 'نقدي';
            if (method === 'نقدي') {
                stats.cashBalances[c] = (stats.cashBalances[c] || 0) + amount;
            } else {
                stats.bankBalances[c] = (stats.bankBalances[c] || 0) + amount;
            }
        });
    }
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.archived) return;
            if (!_reportIsActive(p)) return;
            var amount = parseFloat(p.amount) || 0;
            var c = p.currency || 'YER';
            var method = p.method || 'نقدي';
            if (method === 'نقدي') {
                stats.cashBalances[c] = (stats.cashBalances[c] || 0) - amount;
            } else {
                stats.bankBalances[c] = (stats.bankBalances[c] || 0) - amount;
            }
        });
    }
}

    return stats;
}


/**
 * تكلفة المنتج لقيمة المخزون
 */
function _getProductInventoryCost(p) {
    var type = p.type || p.productType || 'raw';

    if (type === 'raw') {
        var rawPrice = parseFloat(p.price);
        if (isFinite(rawPrice) && rawPrice > 0) return rawPrice;
    }

    var avgCost = parseFloat(p.avgCost);
    if (isFinite(avgCost) && avgCost > 0) return avgCost;

    var purchasePrice = parseFloat(p.purchasePrice);
    if (isFinite(purchasePrice) && purchasePrice > 0) return purchasePrice;

    var price = parseFloat(p.price);
    if (isFinite(price) && price > 0) return price;

    return 0;
}


// ================================================================
// ===== 2. جمع آخر النشاطات =====
// ================================================================

function getRecentActivities(limit) {
    var activities = [];
    var max = limit || 10;

    if (typeof salesInvoices !== 'undefined') {
        salesInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function(inv) {
            activities.push({
                date: inv.date,
                type: 'sale',
                icon: 'sale',
                title: 'فاتورة بيع',
                desc: inv.customerName || '-',
                amount: parseFloat(inv.total) || 0,
                currency: inv.currency || 'YER',
                ref: inv.id
            });
        });
    }

    if (typeof purchaseInvoices !== 'undefined') {
        purchaseInvoices.filter(function(inv){return inv.status !== 'ملغاة' && !inv.cancelled;}).forEach(function(inv) {
            activities.push({
                date: inv.date,
                type: 'purchase',
                icon: 'purchase',
                title: 'فاتورة شراء',
                desc: inv.supplierName || '-',
                amount: parseFloat(inv.total) || 0,
                currency: inv.currency || 'YER',
                ref: inv.id
            });
        });
    }

    if (typeof receipts !== 'undefined') {
        receipts.forEach(function(r) {
            if (!_reportIsActive(r)) return;
            activities.push({
                date: r.date,
                type: 'receipt',
                icon: 'receipt',
                title: 'سند قبض',
                desc: r.customerName || '-',
                amount: parseFloat(r.amount) || 0,
                currency: r.currency || 'YER',
                ref: r.id
            });
        });
    }

    if (typeof payments !== 'undefined') {
        payments.forEach(function(p) {
            if (p.archived) return;
            if (!_reportIsActive(p)) return;
            activities.push({
                date: p.date,
                type: 'payment',
                icon: 'payment',
                title: p.isExpense ? 'مصروف' : 'سند صرف',
                desc: p.supplierName || '-',
                amount: parseFloat(p.amount) || 0,
                currency: p.currency || 'YER',
                ref: p.id
            });
        });
    }

    activities.sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });

    return activities.slice(0, max);
}


// ================================================================
// ===== 3. عرض لوحة التحكم =====
// ================================================================

function updateDashboard() {
    var stats = calculateDashboardStats();

    setText('dashCashBalance', _formatMultiCurrency(stats.cashBalances));
    setText('dashBankBalance', _formatMultiCurrency(stats.bankBalances));
    setText('dashInventoryValue', _formatMultiCurrency(stats.inventoryValue));
    setText('dashMonthSales', _formatMultiCurrency(stats.monthSales));

    setText('dashReceivables', _formatMultiCurrency(stats.receivables));
setText('dashPayables', _formatMultiCurrency(stats.payables));
setText('dashMonthExpenses', _formatMultiCurrency(stats.monthExpenses));
setText('dashMonthPurchases', _formatMultiCurrency(stats.monthPurchases));

// ===== البطاقات الجديدة — الرصيد المدين =====
setText('dashReceivablesFromSuppliers', _formatMultiCurrency(stats.receivablesFromSuppliers));
setText('dashPayablesToCustomers', _formatMultiCurrency(stats.payablesToCustomers));

    setText('dashProducts', stats.productsCount);
    setText('dashCustomers', stats.customersCount);
    setText('dashSuppliers', stats.suppliersCount);
    setText('dashSalesCount', stats.salesCount);
    setText('dashPurchasesCount', stats.purchasesCount);
    setText('dashLowStock', stats.lowStockCount);

    renderRecentActivities();

    var dateEl = document.getElementById('currentDate');
    if (dateEl) dateEl.textContent = todayArabic();
}


function _formatMultiCurrency(obj) {
    if (!obj || Object.keys(obj).length === 0) return '0.00';

    var base = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';
    var total = 0;
    var details = [];

    ['YER', 'SAR', 'USD'].forEach(function(c) {
        var amount = parseFloat(obj[c]) || 0;
        if (amount === 0) return;

        // بناء تفاصيل (للعرض الصغير)
        details.push(formatAmountWithCommas(amount) + ' ' + c);

        // تحويل إلى العملة الأساسية
        if (c === base) {
            total += amount;
        } else {
            var rate = (typeof getCurrentExchangeRateSnapshot === 'function')
                ? getCurrentExchangeRateSnapshot(c)
                : (typeof getRate === 'function' ? getRate(c) : 1);
            var baseRate = (typeof getRate === 'function') ? getRate(base) : 1;
            total += (amount * rate) / (baseRate || 1);
        }
    });

    if (!details.length) return '0.00 ' + base;

    // رقم أساسي (دائماً)
    return formatAmountWithCommas(total) + ' ' + base;
}


// ================================================================
// ===== 4. عرض النشاطات الأخيرة =====
// ================================================================

function renderRecentActivities() {
    var container = document.getElementById('dashActivityList');
    if (!container) return;

    var activities = getRecentActivities(10);

    if (!activities.length) {
        container.innerHTML =
            '<div class="empty-state">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">' +
                    '<circle cx="12" cy="12" r="10"/>' +
                    '<line x1="12" y1="8" x2="12" y2="12"/>' +
                    '<line x1="12" y1="16" x2="12.01" y2="16"/>' +
                '</svg>' +
                '<p>لا توجد نشاطات بعد</p>' +
                '<span>ابدأ بإضافة فاتورة أو سند</span>' +
            '</div>';
        return;
    }

    var html = '';
    activities.forEach(function(a) {
        var color = _activityColor(a.type);
        var sign = _activitySign(a.type);

        html += '<div class="activity-item">' +
            '<div class="activity-badge" style="background:' + color + '20; color:' + color + ';">' +
                _activityIcon(a.icon) +
            '</div>' +
            '<div class="activity-info">' +
                '<div class="activity-title">' + esc(a.title) + '</div>' +
                '<div class="activity-desc">' + esc(a.desc) + ' • ' + formatDate(a.date) + '</div>' +
            '</div>' +
            '<div class="activity-amount" style="color:' + color + ';">' +
                sign + ' ' + formatAmountWithCommas(a.amount) + ' ' + (a.currency || '') +
            '</div>' +
        '</div>';
    });

    container.innerHTML = html;
}


function _activityColor(type) {
    switch (type) {
        case 'sale':     return 'var(--color-green)';
        case 'purchase': return 'var(--color-red)';
        case 'receipt':  return 'var(--color-blue)';
        case 'payment':  return 'var(--color-gold)';
        default:         return 'var(--color-text-2)';
    }
}


function _activitySign(type) {
    switch (type) {
        case 'sale':     return '+';
        case 'receipt':  return '+';
        case 'purchase': return '-';
        case 'payment':  return '-';
        default:         return '';
    }
}


function _activityIcon(type) {
    switch (type) {
        case 'sale':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>';
        case 'purchase':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><line x1="9" y1="15" x2="15" y2="15"/></svg>';
        case 'receipt':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>';
        case 'payment':
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>';
        default:
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>';
    }
}


// ================================================================
// ===== 5. تهيئة لوحة التحكم =====
// ================================================================

function initDashboard() {
    updateDashboard();
    console.log('Dashboard: initialized');
}


// ================================================================
// ===== END OF DASHBOARD.JS =====
// ================================================================