// ================================================================
// Open Account — مدير تحديث الشاشات
// الملف: refresh-manager.js (نسخة نهائية)
// الغرض: تحديث كل الشاشات المرتبطة بعد أي عملية
// ================================================================

(function () {
    'use strict';

    // ============================================================
    // خريطة: نوع العملية → دوال التحديث المطلوبة
    // أسماء الدوال مؤكدة من ملفات المشروع الفعلية
    // ============================================================
    var REFRESH_MAP = {

        // ===== فاتورة بيع =====
        sale: [
            'renderSalesInvoices',
            'renderInventory',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderCustomerLedger',
            'renderReports',
            'renderProfitLoss'
        ],

        // ===== فاتورة شراء =====
        purchase: [
            'renderPurchaseInvoices',
            'renderInventory',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderSupplierLedger',
            'renderReports',
            'renderProfitLoss'
        ],

        // ===== سند قبض =====
        receipt: [
            'renderReceipts',
            'renderSalesInvoices',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderCustomerLedger',
            'renderGeneralLedger',
            'renderReports'
        ],

        // ===== سند صرف =====
        payment: [
            'renderPayments',
            'renderPurchaseInvoices',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderSupplierLedger',
            'renderGeneralLedger',
            'renderReports'
        ],

        // ===== مصروف =====
        expense: [
            'renderExpenses',
            'updateDashboard',
            'renderCashbox',
            'renderProfitLoss',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderReports'
        ],

        // ===== مرتجع =====
        // ===== مرتجع =====
            return: [
            'renderReturns',
            'renderSalesInvoices',
            'renderPurchaseInvoices',
            'renderInventory',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderCustomerLedger',
            'renderSupplierLedger',
            'renderReports',
            'renderProfitLoss'
        ],

        // ===== حركة مباشرة =====
        direct: [
            'renderDirectTransactions',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderReports'
        ],

        // ===== تحويل داخلي =====
        transfer: [
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderReports'
        ],

        // ===== حذف/إلغاء — كل شيء =====
        delete: [
            'renderSalesInvoices',
            'renderPurchaseInvoices',
           'renderReturns',
            'renderReceipts',
            'renderPayments',
            'renderExpenses',
            'renderDirectTransactions',
            'renderInventory',
            'updateDashboard',
            'renderCashbox',
            'renderBank',
            'renderJournal',
            'renderTrialBalance',
            'renderGeneralLedger',
            'renderCustomerLedger',
            'renderSupplierLedger',
            'renderReports',
            'renderProfitLoss'
        ],

        // ===== تغييرات بسيطة =====
        product: ['renderInventory', 'updateDashboard'],
        customer: ['renderCustomers', 'updateDashboard', 'renderCustomerLedger'],
        supplier: ['renderSuppliers', 'updateDashboard', 'renderSupplierLedger']
    };

    // ============================================================
    // تنفيذ التحديث
    // ============================================================
    function refreshRelated(type) {
        var list = REFRESH_MAP[type];
        if (!list) {
            console.warn('[OA] نوع غير معروف:', type);
            return;
        }

        var success = [], missing = [], failed = [];

        list.forEach(function (fnName) {
            if (typeof window[fnName] === 'function') {
                try {
                    window[fnName]();
                    success.push(fnName);
                } catch (e) {
                    failed.push(fnName);
                    console.error('[OA] فشل ' + fnName + ':', e);
                }
            } else {
                missing.push(fnName);
            }
        });

        console.log(
            '[OA] ✅ تحديث "' + type + '" — ' +
            success.length + ' نجحت، ' +
            missing.length + ' غير موجودة، ' +
            failed.length + ' فشلت'
        );
        if (missing.length) console.log('  غير موجودة:', missing.join(', '));
        if (failed.length) console.warn('  فشلت:', failed.join(', '));
    }

    // ============================================================
    // تحديث شامل
    // ============================================================
    function refreshAll() {
        var all = [];
        Object.keys(REFRESH_MAP).forEach(function (k) {
            REFRESH_MAP[k].forEach(function (n) {
                if (all.indexOf(n) === -1) all.push(n);
            });
        });
        all.forEach(function (fnName) {
            if (typeof window[fnName] === 'function') {
                try { window[fnName](); } catch (e) {}
            }
        });
        console.log('[OA] ✅ تحديث شامل (' + all.length + ' دالة)');
    }

    // ============================================================
    // تصدير للنافذة
    // ============================================================
    window.oaRefreshRelated = refreshRelated;
    window.oaRefreshAll = refreshAll;

    console.log('[OA] ✅ refresh-manager جاهز');
})();