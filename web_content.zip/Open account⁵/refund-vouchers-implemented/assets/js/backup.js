// ================================================================
// Open Account — نسخ احتياطي متكامل
// الملف: backup.js
// البيئة: Chrome (يدعم IndexedDB + a.download + share)
// ================================================================

(function () {
    'use strict';

    var DB_NAME = 'open-account-backups';
    var STORE_NAME = 'snapshots';
    var MAX_SNAPSHOTS = 24;
    var DB_VERSION = 1;
    var _db = null;
    var _timer = null;
    var _pendingSave = false;
    
    // ============================================================
// إعدادات الحفظ التلقائي
// ============================================================
var BACKUP_SETTINGS_KEY = 'oa_backup_settings';
var DEFAULT_SETTINGS = {
    frequency: 'manual',      // daily | weekly | monthly | manual
    lastAutoBackup: null,
    nextAutoBackup: null
};
var _autoCheckTimer = null;

// ============================================================
// 0. مفاتيح حرجة — إلزامية في كل نسخة
//    (غير مذكورة في STORAGE_KEYS — نضيفها يدوياً)
// ============================================================
var CRITICAL_KEYS = [
    'oa_journal_entries',    // 🔴 مصدر الحقيقة (قرار المحاسب)
    'oa_journal_counter',    // 🔴 لضمان تسلسل أرقام القيود
    'oa_periods'             // 🟡 الفترات المحاسبية (حالة الإغلاق)
];

// ============================================================
// 0.b إعدادات الحفظ التلقائي
// ============================================================

function readSettings() {
    try {
        var raw = localStorage.getItem(BACKUP_SETTINGS_KEY);
        if (!raw) return Object.assign({}, DEFAULT_SETTINGS);
        var parsed = JSON.parse(raw);
        return Object.assign({}, DEFAULT_SETTINGS, parsed);
    } catch (e) {
        return Object.assign({}, DEFAULT_SETTINGS);
    }
}

function writeSettings(settings) {
    try {
        localStorage.setItem(BACKUP_SETTINGS_KEY, JSON.stringify(settings));
        return true;
    } catch (e) {
        return false;
    }
}

function setFrequency(freq) {
    var valid = ['daily', 'weekly', 'monthly', 'manual'];
    if (valid.indexOf(freq) === -1) return false;

    var settings = readSettings();
    settings.frequency = freq;

    if (freq === 'manual') {
        settings.nextAutoBackup = null;
    } else {
        var now = new Date();
        settings.nextAutoBackup = computeNextBackup(now, freq).toISOString();
    }

    writeSettings(settings);
    return true;
}

function computeNextBackup(fromDate, freq) {
    var next = new Date(fromDate.getTime());
    if (freq === 'daily') {
        next.setDate(next.getDate() + 1);
    } else if (freq === 'weekly') {
        next.setDate(next.getDate() + 7);
    } else if (freq === 'monthly') {
        next.setMonth(next.getMonth() + 1);
    }
    return next;
}

function getFrequencyLabel(freq) {
    if (freq === 'daily') return 'يومي';
    if (freq === 'weekly') return 'أسبوعي';
    if (freq === 'monthly') return 'شهري';
    return 'يدوي فقط';
}


    // ============================================================
    // 1. فتح IndexedDB
    // ============================================================

    function openDB() {
        return new Promise(function (resolve, reject) {
            if (_db) return resolve(_db);

            var req = indexedDB.open(DB_NAME, DB_VERSION);

            req.onupgradeneeded = function (e) {
                var db = e.target.result;
                if (!db.objectStoreNames.contains(STORE_NAME)) {
                    var store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
                    store.createIndex('createdAt', 'createdAt', { unique: false });
                }
            };

            req.onsuccess = function (e) {
                _db = e.target.result;
                resolve(_db);
            };

            req.onerror = function (e) {
                reject(e.target.error);
            };
        });
    }

    // ============================================================
    // 2. جمع البيانات
    // ============================================================

    function collectData() {
    var data = {};
    
    // 1) المفاتيح من STORAGE_KEYS (كما هو)
    if (typeof STORAGE_KEYS !== 'undefined') {
        Object.keys(STORAGE_KEYS).forEach(function (key) {
            var storageKey = STORAGE_KEYS[key];
            if (storageKey === 'oa_ai_settings') return;
            try {
                var value = Storage.get(storageKey, null);
                if (value !== null) data[storageKey] = value;
            } catch (e) {}
        });
    }
    
    // 2) المفاتيح الحرجة — إلزامية (غير مذكورة في STORAGE_KEYS)
    CRITICAL_KEYS.forEach(function (storageKey) {
        if (data[storageKey] !== undefined) return;
        try {
            var value = Storage.get(storageKey, null);
            if (value !== null) {
                data[storageKey] = value;
            } else {
                console.warn('[OA-Backup] ⚠️ مفتاح حرج مفقود:', storageKey);
            }
        } catch (e) {
            console.warn('[OA-Backup] خطأ في قراءة:', storageKey, e.message);
        }
    });
    
    return data;
}

    // ============================================================
    // 3. إنشاء snapshot
    // ============================================================

    function createSnapshot(trigger) {
        var data = collectData();
        var json = JSON.stringify(data);
        
        // إحصائيات
        var counts = {};
        Object.keys(data).forEach(function (k) {
            if (Array.isArray(data[k])) {
                counts[k] = data[k].length;
            }
        });

        // checksum بسيط (djb2)
        var hash = 5381;
        for (var i = 0; i < json.length; i++) {
            hash = ((hash << 5) + hash) + json.charCodeAt(i);
            hash = hash & hash;
        }

        return {
            id: 'snap-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9),
            createdAt: new Date().toISOString(),
            trigger: trigger || 'auto',
            schemaVersion: '1.0',
            size: json.length,
            checksum: (hash >>> 0).toString(16),
            counts: counts,
            data: data
        };
    }

    // ============================================================
    // 4. حفظ snapshot
    // ============================================================

    function saveSnapshot(trigger) {
        return openDB().then(function (db) {
            var snapshot = createSnapshot(trigger);
            
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(STORE_NAME, 'readwrite');
                var store = tx.objectStore(STORE_NAME);
                store.add(snapshot);

                tx.oncomplete = function () {
                    pruneOldSnapshots().then(function () {
                        resolve(snapshot);
                    }).catch(function () {
                        resolve(snapshot); // حفظ نجح حتى لو التنظيف فشل
                    });
                };

                tx.onerror = function (e) {
                    reject(e.target.error);
                };
            });
        });
    }

    // ============================================================
    // 5. حذف النسخ القديمة
    // ============================================================

    function pruneOldSnapshots() {
        return openDB().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(STORE_NAME, 'readwrite');
                var store = tx.objectStore(STORE_NAME);
                var index = store.index('createdAt');
                var req = index.getAll();

                req.onsuccess = function () {
                    var all = req.result || [];
                    if (all.length <= MAX_SNAPSHOTS) {
                        resolve();
                        return;
                    }

                    // ترتيب تصاعدي (الأقدم أولاً)
                    all.sort(function (a, b) {
                        return a.createdAt.localeCompare(b.createdAt);
                    });

                    var toDelete = all.slice(0, all.length - MAX_SNAPSHOTS);
                    toDelete.forEach(function (snap) {
                        store.delete(snap.id);
                    });

                    tx.oncomplete = function () {
                        console.log('[OA-Backup] حُذفت ' + toDelete.length + ' نسخة قديمة');
                        resolve();
                    };
                };

                req.onerror = function (e) {
                    reject(e.target.error);
                };
            });
        });
    }

    // ============================================================
    // 6. قراءة النسخ
    // ============================================================

    function listSnapshots() {
        return openDB().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(STORE_NAME, 'readonly');
                var store = tx.objectStore(STORE_NAME);
                var req = store.getAll();

                req.onsuccess = function () {
                    var all = req.result || [];
                    all.sort(function (a, b) {
                        return b.createdAt.localeCompare(a.createdAt);
                    });
                    resolve(all);
                };

                req.onerror = function (e) {
                    reject(e.target.error);
                };
            });
        });
    }

    // ============================================================
    // 7. تصدير ملف
    // ============================================================

    function exportToFile() {
        var snapshot = createSnapshot('manual-export');
        var wrapper = {
            format: 'open-account-backup',
            schemaVersion: snapshot.schemaVersion,
            createdAt: snapshot.createdAt,
            checksum: snapshot.checksum,
            counts: snapshot.counts,
            data: snapshot.data
        };

        var json = JSON.stringify(wrapper, null, 2);
        var fileName = 'open-account-backup-' + 
                       new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + 
                       '.json';

        try {
            var blob = new Blob([json], { type: 'application/json;charset=utf-8' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            setTimeout(function () { URL.revokeObjectURL(url); }, 2000);

            if (typeof showToast === 'function') {
                showToast('تم تنزيل: ' + fileName, 'success', 5000);
            }
            return true;
        } catch (e) {
            if (typeof showToast === 'function') {
                showToast('فشل التصدير: ' + e.message, 'error');
            }
            return false;
        }
    }

    // ============================================================
    // 8. مشاركة (navigator.share)
    // ============================================================

    function shareSnapshot() {
        var snapshot = createSnapshot('manual-share');
        var wrapper = {
            format: 'open-account-backup',
            schemaVersion: snapshot.schemaVersion,
            createdAt: snapshot.createdAt,
            checksum: snapshot.checksum,
            data: snapshot.data
        };

        var json = JSON.stringify(wrapper, null, 2);
        var fileName = 'open-account-backup-' + 
                       new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-') + 
                       '.json';

        try {
            var blob = new Blob([json], { type: 'application/json' });
            var file = new File([blob], fileName, { type: 'application/json' });

            if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
                navigator.share({
                    files: [file],
                    title: 'نسخة احتياطية — Open Account',
                    text: 'احفظ الملف في مكان آمن'
                }).then(function () {
                    if (typeof showToast === 'function') showToast('تمت المشاركة', 'success');
                }).catch(function (err) {
                    if (err.name !== 'AbortError') {
                        if (typeof showToast === 'function') showToast('فشلت المشاركة — جرّب التنزيل', 'error');
                    }
                });
            } else {
                if (typeof showToast === 'function') showToast('المشاركة غير متاحة — استخدم التنزيل', 'info');
            }
        } catch (e) {
            if (typeof showToast === 'function') showToast('خطأ: ' + e.message, 'error');
        }
    }

    // ============================================================
    // 9. استرجاع snapshot
    // ============================================================

    function restoreSnapshot(id) {
        return openDB().then(function (db) {
            return new Promise(function (resolve, reject) {
                var tx = db.transaction(STORE_NAME, 'readonly');
                var store = tx.objectStore(STORE_NAME);
                var req = store.get(id);

                req.onsuccess = function () {
                    var snap = req.result;
                    if (!snap) {
                        reject(new Error('النسخة غير موجودة'));
                        return;
                    }

                    var date = new Date(snap.createdAt).toLocaleString('ar-SA');
                    
                    if (!confirm(
                        'استرجاع النسخة من: ' + date + '\n' +
                        'الحجم: ' + (snap.size / 1024).toFixed(1) + ' KB\n' +
                        'عدد السجلات: ' + JSON.stringify(snap.counts) + '\n\n' +
                        '⚠️ البيانات الحالية ستُستبدل.\n' +
                        'هل تريد المتابعة؟'
                    )) {
                        resolve(false);
                        return;
                    }

                    try {
                        // نسخة أمان قبل الاسترجاع
                        saveSnapshot('before-restore');

                        // تطبيق البيانات
                        Object.keys(snap.data).forEach(function (key) {
                            localStorage.setItem(key, JSON.stringify(snap.data[key]));
                        });

                        if (typeof showToast === 'function') {
                            showToast('تمت الاستعادة — إعادة التحميل...', 'success');
                        }
                        setTimeout(function () { location.reload(); }, 1500);
                        resolve(true);
                    } catch (e) {
                        if (typeof showToast === 'function') showToast('فشل الاسترجاع: ' + e.message, 'error');
                        reject(e);
                    }
                };

                req.onerror = function (e) {
                    reject(e.target.error);
                };
            });
        });
    }

    // ============================================================
    // 10. عرض UI النسخ
    // ============================================================

  function showBackupsUI() {
    var settings = readSettings();
    var freq = settings.frequency;
    var lastAuto = settings.lastAutoBackup
        ? new Date(settings.lastAutoBackup).toLocaleString('ar-SA')
        : 'لا يوجد';
    var nextAuto = settings.nextAutoBackup
        ? new Date(settings.nextAutoBackup).toLocaleString('ar-SA')
        : '—';

    function radioRow(value, label) {
        var checked = (freq === value) ? 'checked' : '';
        return '<label style="display:flex;align-items:center;gap:8px;padding:8px 10px;margin:4px 0;background:rgba(0,0,0,0.03);border-radius:6px;cursor:pointer;font-size:13px;">' +
            '<input type="radio" name="backupFrequency" value="' + value + '" ' + checked +
            ' onchange="OABackup.setFrequency(\'' + value + '\');setTimeout(function(){OABackup.show();},150);" ' +
            'style="width:16px;height:16px;cursor:pointer;">' +
            '<span style="font-weight:600;">' + label + '</span>' +
        '</label>';
    }

    var settingsHtml = '';
    settingsHtml += '<div style="padding:12px;margin-bottom:14px;background:rgba(245,197,66,0.08);border:1px solid rgba(245,197,66,0.35);border-radius:10px;text-align:right;">';
    settingsHtml += '<div style="font-size:13px;font-weight:700;margin-bottom:10px;">إعدادات الحفظ التلقائي</div>';
    settingsHtml += radioRow('daily', 'يومي');
    settingsHtml += radioRow('weekly', 'أسبوعي');
    settingsHtml += radioRow('monthly', 'شهري');
    settingsHtml += radioRow('manual', 'يدوي فقط');
    settingsHtml += '<div style="margin-top:10px;padding-top:10px;border-top:1px dashed rgba(0,0,0,0.15);font-size:11px;">';
    settingsHtml += '<div style="margin-bottom:4px;"><strong>آخر حفظ تلقائي:</strong> ' + lastAuto + '</div>';
    settingsHtml += '<div><strong>الحفظ التالي:</strong> ' + nextAuto + '</div>';
    settingsHtml += '</div>';
    settingsHtml += '</div>';

    listSnapshots().then(function (snapshots) {
        var html = '<div style="padding:12px;text-align:right;">';
        html += settingsHtml;

        if (!snapshots.length) {
            html += '<div class="info-message">لا توجد نسخ تلقائية</div>';
        } else {
            html += '<div style="margin-bottom:12px;font-size:12px;color:var(--color-text-3);">' +
                    snapshots.length + ' نسخة (الأحدث أولاً)</div>';

            snapshots.forEach(function (snap) {
                var date = new Date(snap.createdAt).toLocaleString('ar-SA');
                var sizeKB = (snap.size / 1024).toFixed(1);

                html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px;background:rgba(0,212,255,0.08);border:1px solid rgba(0,212,255,0.2);border-radius:8px;margin-bottom:8px;gap:8px;flex-wrap:wrap;">';

                html += '<div style="font-size:12px;text-align:right;flex:1;">';
                html += '<div style="font-weight:700;">' + date + '</div>';
                html += '<div style="font-size:10px;color:var(--color-text-3);">' + snap.trigger + ' | ' + sizeKB + ' KB</div>';
                html += '</div>';

                html += '<button onclick="OABackup.restore(\'' + snap.id + '\')" style="font-size:12px;font-weight:700;padding:8px 16px;background:#1f6feb !important;color:#ffffff !important;border:none;border-radius:6px;cursor:pointer;">استرجاع</button>';

                html += '</div>';
            });
        }

        html += '<div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap;">';
        html += '<button onclick="OABackup.saveNow()" style="flex:1;min-width:100px;padding:10px 14px;font-size:13px;font-weight:700;background:#f5c542 !important;color:#0a0e1a !important;border:none;border-radius:8px;cursor:pointer;">حفظ الآن</button>';
        html += '<button onclick="OABackup.export()" style="flex:1;min-width:100px;padding:10px 14px;font-size:13px;font-weight:700;background:#1f6feb !important;color:#ffffff !important;border:none;border-radius:8px;cursor:pointer;">تنزيل ملف</button>';
        html += '<button onclick="OABackup.share()" style="flex:1;min-width:100px;padding:10px 14px;font-size:13px;font-weight:700;background:#28a745 !important;color:#ffffff !important;border:none;border-radius:8px;cursor:pointer;">مشاركة</button>';
        html += '</div>';

        html += '</div>';

        if (typeof Modal !== 'undefined' && Modal.open) {
            Modal.open({
                id: 'autoBackupModal',
                title: 'النسخ الاحتياطية',
                size: 'large',
                body: html,
                footer: '<button class="btn btn-cancel" onclick="closeModal(\'autoBackupModal\')">إغلاق</button>'
            });
        }
    }).catch(function (e) {
        if (typeof showToast === 'function') showToast('خطأ: ' + e.message, 'error');
    });
}

// ============================================================
// 10.b الفحص الدوري للحفظ التلقائي
// ============================================================

function checkAutoBackup() {
    var settings = readSettings();
    if (settings.frequency === 'manual') return;

    var now = new Date();
    var next = settings.nextAutoBackup ? new Date(settings.nextAutoBackup) : null;

    if (!next || now >= next) {
        // حان وقت الحفظ
        console.log('[OA-Backup] حان وقت الحفظ التلقائي — الفترة:', settings.frequency);
        try {
            exportToFile();
            settings.lastAutoBackup = now.toISOString();
            settings.nextAutoBackup = computeNextBackup(now, settings.frequency).toISOString();
            writeSettings(settings);
        } catch (e) {
            console.warn('[OA-Backup] فشل الحفظ التلقائي:', e.message);
        }
    }
}

function startAutoCheck() {
    if (_autoCheckTimer) clearInterval(_autoCheckTimer);
    // فحص كل ساعة
    _autoCheckTimer = setInterval(checkAutoBackup, 60 * 60 * 1000);
    // فحص أولي بعد 30 ثانية من التشغيل
    setTimeout(checkAutoBackup, 30 * 1000);
    console.log('[OA-Backup] الفحص الدوري مُفعّل');
}


    // ============================================================
    // 11. حفظ تلقائي
    // ============================================================

    function autoSave(trigger) {
        if (_pendingSave) return;
        _pendingSave = true;

        setTimeout(function () {
            saveSnapshot(trigger).then(function (snap) {
                console.log('[OA-Backup] ✅ نسخة محفوظة:', snap.id);
            }).catch(function (e) {
                console.warn('[OA-Backup] ❌ فشل:', e.message);
            }).finally(function () {
                _pendingSave = false;
            });
        }, 5000); // تأخير 5 ثواني لتجميع العمليات
    }

    function startAutoBackup() {
    // نسخة عند البدء (إذا آخر نسخة أقدم من 6 ساعات)
    listSnapshots().then(function (snaps) {
        var last = snaps[0];
        if (!last) {
            saveSnapshot('startup');
            return;
        }
        var age = Date.now() - new Date(last.createdAt).getTime();
        if (age > 6 * 60 * 60 * 1000) {
            saveSnapshot('startup');
        }
    }).catch(function () {
        saveSnapshot('startup');
    });

    // جدولة كل 6 ساعات (الحفظ في IndexedDB)
    if (_timer) clearInterval(_timer);
    _timer = setInterval(function () {
        saveSnapshot('interval-6h');
    }, 6 * 60 * 60 * 1000);

    // بدء الفحص الدوري للحفظ التلقائي في ملفات
    startAutoCheck();

    console.log('[OA-Backup] التلقائي مُفعّل');
}


// ============================================================
// 11.b استيراد نسخة من ملف JSON
// ============================================================

function importFromFile(file) {
    if (!file) {
        if (typeof showToast === 'function') showToast('لم يتم اختيار ملف', 'error');
        return;
    }

    var reader = new FileReader();

    reader.onload = function (e) {
        var content = e.target.result;
        var parsed;

        try {
            parsed = JSON.parse(content);
        } catch (err) {
            if (typeof showToast === 'function') showToast('الملف غير صالح - ليس JSON', 'error');
            return;
        }

        if (parsed.format !== 'open-account-backup') {
            if (typeof showToast === 'function') showToast('هذا ليس ملف نسخة احتياطية من Open Account', 'error');
            return;
        }

        if (!parsed.data || typeof parsed.data !== 'object') {
            if (typeof showToast === 'function') showToast('الملف لا يحتوي على بيانات صالحة', 'error');
            return;
        }

        var keys = Object.keys(parsed.data);
        var created = parsed.createdAt ? new Date(parsed.createdAt).toLocaleString('ar-SA') : 'غير معروف';

        var summary = '';
        keys.forEach(function (k) {
            var v = parsed.data[k];
            if (Array.isArray(v)) {
                summary += '\n  - ' + k + ': ' + v.length + ' سجل';
            } else {
                summary += '\n  - ' + k + ': قيمة';
            }
        });

        if (!confirm(
            'استيراد نسخة احتياطية\n\n' +
            'التاريخ: ' + created + '\n' +
            'عدد المفاتيح: ' + keys.length + '\n' +
            'المحتوى:' + summary + '\n\n' +
            'تحذير: البيانات الحالية ستُستبدل بالكامل.\n' +
            'هل تريد المتابعة؟'
        )) {
            return;
        }

        saveSnapshot('before-import');

        try {
            keys.forEach(function (k) {
                localStorage.setItem(k, JSON.stringify(parsed.data[k]));
            });

            if (typeof showToast === 'function') {
                showToast('تم الاستيراد بنجاح - إعادة التحميل...', 'success', 4000);
            }

            setTimeout(function () {
                location.reload();
            }, 1500);

        } catch (err) {
            if (typeof showToast === 'function') {
                showToast('فشل الاستيراد: ' + err.message, 'error', 6000);
            }
        }
    };

    reader.onerror = function () {
        if (typeof showToast === 'function') showToast('فشل قراءة الملف', 'error');
    };

    reader.readAsText(file);
}


    // ============================================================
    // 12. واجهة عامة
    // ============================================================
// ============================================================
// 14. استيراد نسخة من ملف JSON
// ============================================================

function importFromFile(file) {
    if (!file) {
        if (typeof showToast === 'function') showToast('لم يتم اختيار ملف', 'error');
        return;
    }

    var reader = new FileReader();

    reader.onload = function (e) {
        var content = e.target.result;
        var parsed;

        try {
            parsed = JSON.parse(content);
        } catch (err) {
            if (typeof showToast === 'function') showToast('الملف غير صالح - ليس JSON', 'error');
            return;
        }

        // التحقق من الصيغة
        if (parsed.format !== 'open-account-backup') {
            if (typeof showToast === 'function') showToast('هذا ليس ملف نسخة احتياطية من Open Account', 'error');
            return;
        }

        if (!parsed.data || typeof parsed.data !== 'object') {
            if (typeof showToast === 'function') showToast('الملف لا يحتوي على بيانات صالحة', 'error');
            return;
        }

        // ملخص المحتوى
        var summary = '';
        var keys = Object.keys(parsed.data);
        keys.forEach(function (k) {
            var v = parsed.data[k];
            if (Array.isArray(v)) {
                summary += '\n  • ' + k + ': ' + v.length + ' سجل';
            } else {
                summary += '\n  • ' + k + ': قيمة';
            }
        });

        var created = parsed.createdAt ? new Date(parsed.createdAt).toLocaleString('ar-SA') : 'غير معروف';

        if (!confirm(
            'استيراد نسخة احتياطية\n\n' +
            'التاريخ: ' + created + '\n' +
            'عدد المفاتيح: ' + keys.length + '\n' +
            'المحتوى:' + summary + '\n\n' +
            'تحذير: البيانات الحالية ستُستبدل بالكامل.\n' +
            'هل تريد المتابعة؟'
        )) {
            return;
        }

        // حفظ نسخة أمان قبل الاستيراد
        saveSnapshot('before-import');

        // تطبيق البيانات
        try {
            // حذف المفاتيح القديمة المرتبطة بالنسخة
            keys.forEach(function (k) {
                localStorage.removeItem(k);
            });

            // كتابة البيانات الجديدة
            keys.forEach(function (k) {
                localStorage.setItem(k, JSON.stringify(parsed.data[k]));
            });

            if (typeof showToast === 'function') {
                showToast('تم الاستيراد بنجاح - إعادة التحميل...', 'success', 4000);
            }

            setTimeout(function () {
                location.reload();
            }, 1500);

        } catch (err) {
            if (typeof showToast === 'function') {
                showToast('فشل الاستيراد: ' + err.message, 'error', 6000);
            }
        }
    };

    reader.onerror = function () {
        if (typeof showToast === 'function') showToast('فشل قراءة الملف', 'error');
    };

    reader.readAsText(file);
}
    window.OABackup = {
    saveNow: function () {
        saveSnapshot('manual').then(function (snap) {
            if (typeof showToast === 'function') showToast('تم حفظ نسخة', 'success');
        }).catch(function (e) {
            if (typeof showToast === 'function') showToast('فشل: ' + e.message, 'error');
        });
    },
    // ✅ جديد: دالة عامة ترجع الـ snapshot
    create: function (trigger) {
        return saveSnapshot(trigger || 'manual');
    },
    export: exportToFile,
    share: shareSnapshot,
    list: listSnapshots,
    restore: restoreSnapshot,
    show: showBackupsUI,
    autoSave: autoSave,
    start: startAutoBackup
};

      
window.OABackup.import = importFromFile;

window.OABackup.getSettings = readSettings;
window.OABackup.setFrequency = function (freq) {
    var ok = setFrequency(freq);
    if (ok && typeof showToast === 'function') {
        showToast('تم حفظ الإعداد — الفترة: ' + getFrequencyLabel(freq), 'success');
    }
    return ok;
};
window.OABackup.getFrequencyLabel = getFrequencyLabel;
    // ============================================================
    // 13. بدء
    // ============================================================

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            setTimeout(startAutoBackup, 3000);
        });
    } else {
        setTimeout(startAutoBackup, 3000);
    }

})();