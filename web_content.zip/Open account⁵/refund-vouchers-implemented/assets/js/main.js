// ================================================================
// Open Account — نظام محاسبي
// الملف: main.js
// الوصف: نقطة البداية — تهيئة التطبيق
// ================================================================


// ================================================================
// ===== 1. نقطة البداية =====
// ================================================================

function init() {
    console.log('Open Account — جاري التهيئة...');
    
    // 1. تهيئة نظام النوافذ
    if (typeof Modal !== 'undefined') {
        Modal.init();
    }
    
    // 2. تهيئة العملات
    if (typeof initCurrency === 'function') {
        initCurrency();
    }
    
    // 3. تهيئة أسعار الصرف
    if (typeof initExchange === 'function') {
        initExchange();
    }
    
    // 4. تهيئة التنقل
    if (typeof initNavigation === 'function') {
        initNavigation();
    }
    
    // 5. تهيئة المستودع
    if (typeof initInventory === 'function') {
        initInventory();
    }

    // 5.5 تهيئة BOM وسندات الإنتاج
    if (typeof initProduction === 'function') {
        initProduction();
    }
    
    // 6. تهيئة العملاء
    if (typeof initCustomers === 'function') {
        initCustomers();
    }
    
    // 7. تهيئة الموردين
    if (typeof initSuppliers === 'function') {
        initSuppliers();
    }
    
    // 8. تهيئة فواتير البيع
    if (typeof initSales === 'function') {
        initSales();
    }
    
    // 9. تهيئة فواتير الشراء
    if (typeof initPurchases === 'function') {
        initPurchases();
    }
    
    // 10. تهيئة سندات القبض
    if (typeof initReceipts === 'function') {
        initReceipts();
    }
    
    // 11. تهيئة سندات الصرف
    if (typeof initPayments === 'function') {
        initPayments();
    }
    
    // 12. تهيئة المصاريف
    if (typeof initExpenses === 'function') {
        initExpenses();
    }
    
    // 13. تهيئة الصندوق
    if (typeof initCashbox === 'function') {
        initCashbox();
    }
    
    // 14. تهيئة البنك
    if (typeof initBank === 'function') {
        initBank();
    }

    // 14.5 تهيئة التحويلات الداخلية
    if (typeof initTransfers === 'function') {
        initTransfers();
        if (typeof renderCashbox === 'function') renderCashbox();
        if (typeof renderBank === 'function') renderBank();
    }

    if (typeof initDirectTransactions === 'function') initDirectTransactions();
    // تحميل القيود المحاسبية (بدون إعادة توليد)
if (typeof loadJournal === 'function') {
    loadJournal();
    console.log('Journal storage loaded: ' + journalEntries.length + ' entries');
}
    if (typeof initReturns === 'function') initReturns();
    // ترحيل returnStatus للفواتير القديمة
if (typeof migrateReturnStatus === 'function') {
    var migrated = migrateReturnStatus();
    if (migrated > 0) {
        console.log('Return status migrated for ' + migrated + ' invoices');
    }
}
    if (typeof initZakat === 'function') initZakat();
    if (typeof renderCashbox === 'function') renderCashbox();
    if (typeof renderBank === 'function') renderBank();
    
    // 15. تهيئة الأرباح والخسائر
    if (typeof initProfitLoss === 'function') {
        initProfitLoss();
    }
 
    // 16. تهيئة لوحة التحكم
    if (typeof initDashboard === 'function') {
        initDashboard();
    }
    
    // 17. تهيئة كشف حساب الموردين
    if (typeof initSupplierLedger === 'function') {
        initSupplierLedger();
    }
    
    // 18. تهيئة كشف حساب العملاء
    if (typeof initCustomerLedger === 'function') {
        initCustomerLedger();
    }

    // تهيئة الأرشيف الخارجي فقط
    if (typeof initArchive === 'function') {
        initArchive();
    }
    if (typeof initAIAgentUniversal === 'function') initAIAgentUniversal();
else if (typeof initAIAgent === 'function') initAIAgent();
    if (typeof initCalculator === 'function') initCalculator();
    if (typeof initClock === 'function') initClock();
if (typeof initToolsMenu === 'function') initToolsMenu();
    
    // 19. ربط أزرار الرأس
    _bindHeaderButtons();
    
    // 20. ربط حقول الإعدادات
    _bindSettingsFields();
    
    // 21. تحديث التاريخ
    _updateDates();
    
    console.log('Open Account — جاهز');

}


// ================================================================
// ===== 2. ربط أزرار الرأس =====
// ================================================================

function _bindHeaderButtons() {
    var btnTheme = document.getElementById('btnTheme');
    if (btnTheme) {
        btnTheme.addEventListener('click', function() {
            toggleTheme();
        });
    }
    
    var btnBackup = document.getElementById('btnBackup');
    if (btnBackup) {
        btnBackup.addEventListener('click', function() {
            exportBackup();
        });
    }

    var backupImportFile = document.getElementById('backupImportFile');
if (backupImportFile) {
    backupImportFile.addEventListener('change', importBackupFile);
}
    
    var btnSettings = document.getElementById('btnSettings');
    if (btnSettings) {
        btnSettings.addEventListener('click', function() {
            toggleSettings();
        });
    }
}


// ================================================================
// ===== 3. تبديل المظهر =====
// ================================================================

function toggleTheme() {
    var body = document.body;
    var current = body.classList.contains('light-theme') ? 'light' : (body.classList.contains('amber-theme') ? 'amber' : 'dark');
    var next = current === 'dark' ? 'light' : (current === 'light' ? 'amber' : 'dark');
    body.classList.remove('light-theme', 'amber-theme', 'purple-theme');
    if (next === 'light') body.classList.add('light-theme');
    if (next === 'amber') body.classList.add('amber-theme');
    if (typeof Storage !== 'undefined') Storage.set(STORAGE_KEYS.THEME, next);
    if (typeof showToast === 'function') showToast(next === 'dark' ? 'تم تفعيل الوضع الداكن' : (next === 'light' ? 'تم تفعيل الوضع الفاتح الرمادي' : 'تم تفعيل الوضع الفاتح الأصفر'), 'info');
}


// ================================================================
// ===== 4. النسخ الاحتياطي =====
// ================================================================

function exportBackup() {
    try {
        var backup = {
            version: '1.0',
            exportedAt: new Date().toISOString(),
            data: {}
        };
        
        if (typeof STORAGE_KEYS !== 'undefined') {
            Object.keys(STORAGE_KEYS).forEach(function(key) {
                var storageKey = STORAGE_KEYS[key];
                if (storageKey === 'oa_ai_settings') return;
                var value = Storage.get(storageKey, null);
                if (value !== null) {
                    backup.data[storageKey] = value;
                }
            });
        }
        
        // إضافة أسعار الصرف
        try {
            var rates = localStorage.getItem('oa_exchange_rates');
            if (rates) {
                backup.data['oa_exchange_rates'] = JSON.parse(rates);
            }
        } catch(e) {}
        
        var json = JSON.stringify(backup, null, 2);
        var fileName = 'open-account-backup-' + todayISO() + '.json';
        
        // محاولة المشاركة (تعمل على الهاتف)
        if (navigator.share) {
            var blob = new Blob([json], { type: 'application/json' });
            var file = new File([blob], fileName, { type: 'application/json' });
            
            if (navigator.canShare && navigator.canShare({ files: [file] })) {
                navigator.share({
                    files: [file],
                    title: 'نسخة احتياطية',
                    text: 'اختر "حفظ في الملفات" أو أي تطبيق'
                }).then(function() {
                    showToast('تم حفظ النسخة', 'success');
                }).catch(function(err) {
                    if (err.name !== 'AbortError') {
                        console.error('Share failed:', err);
                        _showBackupFallback(json, fileName);
                    }
                });
            } else {
                _showBackupFallback(json, fileName);
            }
        } else {
            _showBackupFallback(json, fileName);
        }
        
    } catch (e) {
        console.error('Backup error:', e);
        showToast('خطأ: ' + e.message, 'error');
    }
}


function _showBackupFallback(json, fileName) {
    var bodyHTML = 
        '<div style="background:rgba(0,214,143,0.1);border:1px solid rgba(0,214,143,0.3);border-radius:8px;padding:12px;margin-bottom:12px;">' +
            '<div style="font-size:12px;color:var(--color-green);font-weight:700;">النسخة جاهزة</div>' +
            '<div style="font-size:11px;color:var(--color-text-2);">' +
                'الملف: ' + esc(fileName) + '<br>' +
                'الحجم: ' + (json.length / 1024).toFixed(2) + ' KB' +
            '</div>' +
        '</div>' +

        '<div style="display:flex;gap:8px;margin-top:8px;flex-direction:column;">' +
            '<button class="btn btn-success" id="btnShareBackup" style="width:100%;min-height:46px;">📤 مشاركة الملف</button>' +
            '<div style="display:flex;gap:8px;">' +
                '<button class="btn btn-primary" id="btnCopyPart1" style="flex:1;min-height:46px;font-size:11px;">📋 نسخ الجزء 1</button>' +
                '<button class="btn btn-primary" id="btnCopyPart2" style="flex:1;min-height:46px;font-size:11px;">📋 نسخ الجزء 2</button>' +
            '</div>' +
            '<button class="btn btn-secondary" id="btnCopyBackup" style="width:100%;min-height:46px;font-size:11px;">📋 نسخ الكل (للحجم الصغير)</button>' +
        '</div>' +

        '<div class="form-field" style="margin-top:12px;">' +
            '<label>النص الكامل (للمراجعة)</label>' +
            '<textarea id="backupText" readonly style="width:100%;height:200px;font-size:10px;font-family:monospace;direction:ltr;padding:8px;background:rgba(0,0,0,0.3);border:1px solid var(--color-border);border-radius:6px;color:var(--color-text);resize:none;">' + esc(json) + '</textarea>' +
        '</div>' +

        '<div style="margin-top:12px;padding:10px;background:rgba(0,212,255,0.1);border-radius:6px;font-size:11px;color:var(--color-text-2);">' +
            '<strong>طريقة الحفظ:</strong><br>' +
            '• <strong>📤 مشاركة الملف</strong> — الأفضل (يفتح نظام المشاركة).<br>' +
            '• أو <strong>📋 نسخ الجزء 1</strong> + <strong>📋 نسخ الجزء 2</strong> — الصقهما في تطبيق ملاحظات وحفظهما كملف <code>.json</code>. ' +
            'الأول يعطي البداية، الثاني يعطي النهاية — اجمعهما معاً.' +
        '</div>';

    Modal.open({
        id: 'backupModal',
        title: 'النسخة الاحتياطية',
        size: 'large',
        body: bodyHTML,
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'backupModal\')">إغلاق</button>',
        onOpen: function(modalEl) {
            var btnShare = modalEl.querySelector('#btnShareBackup');
            var btnCopy = modalEl.querySelector('#btnCopyBackup');
            var btnPart1 = modalEl.querySelector('#btnCopyPart1');
            var btnPart2 = modalEl.querySelector('#btnCopyPart2');
            var textarea = modalEl.querySelector('#backupText');

       // ===== مشاركة الملف =====
if (btnShare) {
    btnShare.addEventListener('click', function() {
        try {
            var blob = new Blob([json], { type: 'application/json;charset=utf-8' });
            var file = new File([blob], fileName, { type: 'application/json' });

            if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
                navigator.share({
                    files: [file],
                    title: 'نسخة احتياطية — Open Account',
                    text: 'احفظ الملف في مكان آمن'
                }).then(function() {
                    showToast('تم الحفظ', 'success');
                }).catch(function(err) {
                    if (err.name !== 'AbortError') {
                        showToast('فشل: ' + err.message + ' — استخدم نسخ الجزء 1 و 2', 'error', 8000);
                    }
                });
            } else {
                showToast('المشاركة غير متاحة — استخدم نسخ الجزء 1 و 2', 'info', 8000);
            }
        } catch(e) {
            showToast('فشل: ' + e.message + ' — استخدم نسخ الأجزاء', 'error', 8000);
        }
    });
}

            // ===== نسخ الكل =====
            if (btnCopy) {
                btnCopy.addEventListener('click', function() {
                    if (textarea) {
                        textarea.select();
                        textarea.setSelectionRange(0, 999999);
                        try {
                            document.execCommand('copy');
                            showToast('تم نسخ النص الكامل', 'success');
                        } catch(e) {
                            showToast('انسخ يدوياً', 'info');
                        }
                    }
                });
            }

            // ===== نسخ الجزء 1 =====
            if (btnPart1) {
                btnPart1.addEventListener('click', function() {
                    var half = Math.ceil(json.length / 2);
                    var part = json.substring(0, half);
                    _copyToClipboard(part, 'تم نسخ الجزء 1 (' + Math.ceil(half/1024) + ' KB)');
                });
            }

            // ===== نسخ الجزء 2 =====
            if (btnPart2) {
                btnPart2.addEventListener('click', function() {
                    var half = Math.ceil(json.length / 2);
                    var part = json.substring(half);
                    _copyToClipboard(part, 'تم نسخ الجزء 2 (' + Math.ceil((json.length - half)/1024) + ' KB)');
                });
            }
        }
    });
}


// ================================================================
// ===== دالة مساعدة — نسخ نص إلى الحافظة =====
// ================================================================

function _copyToClipboard(text, successMsg) {
    var temp = document.createElement('textarea');
    temp.value = text;
    temp.style.position = 'fixed';
    temp.style.left = '-9999px';
    document.body.appendChild(temp);
    temp.select();
    temp.setSelectionRange(0, 999999);
    try {
        document.execCommand('copy');
        showToast(successMsg || 'تم النسخ', 'success', 5000);
    } catch(e) {
        showToast('انسخ يدوياً', 'info');
    }
    document.body.removeChild(temp);
}


// ================================================================
// ===== 5. ربط حقول الإعدادات =====
// ================================================================
function _bindSettingsFields() {
    var textFields = ['companyName', 'companyAddress', 'companyPhone', 'companyEmail'];
    
    textFields.forEach(function(id) {
        var el = document.getElementById(id);
        if (el) {
            el.addEventListener('change', function() {
                saveCompanySettings();
            });
        }
    });
    
    var baseCurrEl = document.getElementById('baseCurrencySelect');
    if (baseCurrEl) {
        baseCurrEl.addEventListener('change', function() {
            if (typeof setBaseCurrency === 'function') {
                setBaseCurrency(this.value);
            }
            if (typeof saveExchangeRates === 'function') {
                saveExchangeRates();
            }
            saveCompanySettings();
        });
    }
    
    var sarRateEl = document.getElementById('sarRate');
    if (sarRateEl) {
        sarRateEl.addEventListener('change', function() {
            if (typeof saveExchangeRates === 'function') {
                saveExchangeRates();
            }
        });
        
        sarRateEl.addEventListener('input', function() {
            var sarRate = parseFloat(this.value) || 0;
            var usdToSar = typeof USD_TO_SAR !== 'undefined' ? USD_TO_SAR : 3.8;
            var usdInYer = sarRate * usdToSar;
            
            var displayEl = document.getElementById('usdInYerDisplay');
            if (displayEl && typeof formatAmountWithCommas === 'function') {
                displayEl.textContent = formatAmountWithCommas(usdInYer) + ' ر.ي';
            }
        });
    }
    
    var usdToSarEl = document.getElementById('usdToSarRate');
    if (usdToSarEl) {
        usdToSarEl.addEventListener('change', function() {
            if (typeof saveExchangeRates === 'function') {
                saveExchangeRates();
            }
        });
        
        usdToSarEl.addEventListener('input', function() {
            var usdToSar = parseFloat(this.value) || 0;
            var sarRate = (typeof exchangeRates !== 'undefined' && exchangeRates.SAR) ? exchangeRates.SAR : 530;
            var usdInYer = sarRate * usdToSar;
            
            var displayEl = document.getElementById('usdInYerDisplay');
            if (displayEl && typeof formatAmountWithCommas === 'function') {
                displayEl.textContent = formatAmountWithCommas(usdInYer) + ' ر.ي';
            }
        });
    }
}





// ================================================================
// ===== 6. حفظ إعدادات المؤسسة =====
// ================================================================

function saveCompanySettings() {
    var settings = {
        name: getValue('companyName'),
        address: getValue('companyAddress'),
        phone: getValue('companyPhone'),
        email: getValue('companyEmail'),
        baseCurrency: getValue('baseCurrencySelect') || (typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER')
    };
    
    var existing = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var merged = Object.assign({}, existing, settings);
    
    Storage.set(STORAGE_KEYS.SETTINGS, merged);
}


// ================================================================
// ===== 7. تحميل الإعدادات =====
// ================================================================

function loadSettings() {
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, null);
    
    if (settings) {
        setValue('companyName', settings.name || '');
        setValue('companyAddress', settings.address || '');
        setValue('companyPhone', settings.phone || '');
        setValue('companyEmail', settings.email || '');
        if (settings.baseCurrency && typeof setBaseCurrency === 'function') setBaseCurrency(settings.baseCurrency);
        setValue('baseCurrencySelect', settings.baseCurrency || 'YER');
    }
}


// ================================================================
// ===== 8. تحديث التواريخ =====
// ================================================================

function _updateDates() {
    var dateStr = todayArabic();
    
    var currentDateEl = document.getElementById('currentDate');
    if (currentDateEl) currentDateEl.textContent = dateStr;
    
    var cashboxDateEl = document.getElementById('cashboxDate');
    if (cashboxDateEl) cashboxDateEl.textContent = dateStr;
    
    var bankDateEl = document.getElementById('bankDate');
    if (bankDateEl) bankDateEl.textContent = dateStr;
}


// ================================================================
// ===== 9. استرجاع المظهر المحفوظ =====
// ================================================================

function _restoreTheme() {
    var savedTheme = Storage.get(STORAGE_KEYS.THEME, 'dark');
    if (['dark', 'light', 'amber'].indexOf(savedTheme) < 0) savedTheme = 'dark';
    document.body.classList.remove('light-theme', 'amber-theme', 'purple-theme');
    if (savedTheme === 'light') document.body.classList.add('light-theme');
    if (savedTheme === 'amber') document.body.classList.add('amber-theme');
}
// ================================================================
// ===== refreshAllDisplays: إعادة عرض كل شيء =====
// ================================================================

function refreshAllDisplays() {
    if (typeof updateDashboard === 'function') updateDashboard();
    if (typeof renderInventory === 'function') renderInventory();
    if (typeof renderCustomers === 'function') renderCustomers();
    if (typeof renderSuppliers === 'function') renderSuppliers();
    if (typeof renderSalesInvoices === 'function') renderSalesInvoices();
    if (typeof renderPurchaseInvoices === 'function') renderPurchaseInvoices();
    if (typeof renderReceipts === 'function') renderReceipts();
    if (typeof renderPayments === 'function') renderPayments();
    if (typeof renderExpenses === 'function') renderExpenses();
    if (typeof renderCashbox === 'function') renderCashbox();
    if (typeof renderBank === 'function') renderBank();
    if (typeof renderProfitLoss === 'function') renderProfitLoss();
    
    if (typeof showToast === 'function') {
        showToast('تم تحديث العملة الأساسية', 'success');
    }
}

// ================================================================
// ===== 10. ربط الأحداث عند تحميل الصفحة =====
// ================================================================

document.addEventListener('DOMContentLoaded', function() {
    _restoreTheme();
    loadSettings();
    init();
});


// استيراد نسخة احتياطية كاملة — لا يستورد إعدادات مفتاح Gemini
function importBackupFile(event) {
    var input = event && event.target;
    var file = input && input.files && input.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function(e) {
        try {
            var backup = JSON.parse(e.target.result);
            if (!backup || typeof backup !== 'object' || !backup.data || typeof backup.data !== 'object') throw new Error('البنية ليست نسخة Open Account صالحة');
            var allowed = {};
            Object.keys(STORAGE_KEYS || {}).forEach(function(k) { allowed[STORAGE_KEYS[k]] = true; });
            delete allowed.oa_ai_settings;
            var entries = Object.keys(backup.data).filter(function(k) { return allowed[k]; });
            if (!entries.length) throw new Error('لا توجد بيانات معروفة داخل الملف');
            var invalid = entries.some(function(k) { var v = backup.data[k]; return v === undefined || typeof v === 'function'; });
            if (invalid) throw new Error('توجد بيانات غير صالحة داخل الملف');
            var ok = window.confirm('سيتم استبدال البيانات الحالية بالنسخة المختارة. تأكد من وجود نسخة احتياطية حالية قبل المتابعة. هل تريد الاستمرار؟');
            if (!ok) return;
            entries.forEach(function(k) { localStorage.setItem(k, JSON.stringify(backup.data[k])); });
            showToast('تم استيراد النسخة بنجاح، سيتم إعادة تشغيل التطبيق', 'success');
            setTimeout(function() { window.location.reload(); }, 900);
        } catch (err) {
            showToast('فشل الاستيراد: ' + err.message, 'error');
        } finally {
            if (input) input.value = '';
        }
    };
    reader.onerror = function() { showToast('تعذر قراءة ملف النسخة الاحتياطية', 'error'); if (input) input.value = ''; };
    reader.readAsText(file);
}


// ================================================================
// ===== تنزيل ملف عبر data URL (بديل أوسع توافقاً) =====
// ================================================================

function _downloadViaDataURL(text, filename) {
    try {
        // تشفير النص إلى Base64 (يدعم Unicode)
        var encoded = btoa(unescape(encodeURIComponent(text)));
        var dataUrl = 'data:application/json;charset=utf-8;base64,' + encoded;
        
        // محاولة 1: رابط مباشر
        var a = document.createElement('a');
        a.href = dataUrl;
        a.download = filename;
        a.rel = 'noopener';
        a.style.display = 'none';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        showToast('تم التنزيل — تحقق من مجلد Downloads', 'success', 5000);
    } catch(e) {
        // محاولة 2: فتح الرابط مباشرة
        try {
            window.location.href = dataUrl;
            showToast('جارٍ التنزيل...', 'info');
        } catch(e2) {
            showToast('فشل التنزيل: ' + e2.message, 'error', 8000);
        }
    }
}
// ================================================================
// ===== فتح مستند معلَّق (من القيود) =====
// ================================================================

function _openPendingDocument() {
    var raw = null;
    try {
        raw = localStorage.getItem('oa_pending_open_doc');
    } catch (e) { return; }

    if (!raw) return;

    var pending = null;
    try {
        pending = JSON.parse(raw);
    } catch (e) {
        localStorage.removeItem('oa_pending_open_doc');
        return;
    }

    // تحقق من الصلاحية (خلال 60 ثانية)
    if (!pending || !pending.timestamp) {
        localStorage.removeItem('oa_pending_open_doc');
        return;
    }

    var age = Date.now() - new Date(pending.timestamp).getTime();
    if (age > 60000) {
        localStorage.removeItem('oa_pending_open_doc');
        return;
    }

    // احذف المرجع حتى لا يُنفَّذ مرة أخرى
    localStorage.removeItem('oa_pending_open_doc');

    // بعد تحميل النظام → انتقل للتبويب → افتح المستند
    setTimeout(function() {
        // 1. انتقل للتبويب
        if (pending.tab && typeof switchTab === 'function') {
            switchTab(pending.tab);
        }

        // 2. بعد فتح التبويب → افتح المستند
        setTimeout(function() {
            _openDocumentByType(pending.type, pending.id);
        }, 500);
    }, 300);
}

function _openDocumentByType(type, id) {
    if (!type || !id) return;

    // ابحث عن دالة المعاينة المناسبة
    var openerMap = {
        'sales_invoice': function() {
            if (typeof viewSalesInvoice === 'function') viewSalesInvoice(id);
            else if (typeof printIndividualDocument === 'function') printIndividualDocument('sales', id);
        },
        'purchase_invoice': function() {
            if (typeof viewPurchaseInvoice === 'function') viewPurchaseInvoice(id);
            else if (typeof printIndividualDocument === 'function') printIndividualDocument('purchases', id);
        },
        'receipt': function() {
            if (typeof printIndividualDocument === 'function') printIndividualDocument('receipts', id);
        },
        'payment': function() {
            if (typeof printIndividualDocument === 'function') printIndividualDocument('payments', id);
        },
        'expense': function() {
            if (typeof viewExpense === 'function') viewExpense(id);
        },
        'return_sale': function() {
            if (typeof viewReturn === 'function') viewReturn(id);
        },
        'return_purchase': function() {
            if (typeof viewReturn === 'function') viewReturn(id);
        },
        'production': function() {
            if (typeof printProductionDocument === 'function') printProductionDocument(id);
        }
    };

    var opener = openerMap[type];
    if (opener) {
        try {
            opener();
        } catch (e) {
            console.warn('Open pending doc failed:', e);
        }
    } else {
        if (typeof showToast === 'function') {
            showToast('تعذّر فتح المستند: ' + type + ' #' + id, 'info');
        }
    }
}

// نفّذ عند تحميل النظام
window.addEventListener('load', function() {
    setTimeout(_openPendingDocument, 1000);
});