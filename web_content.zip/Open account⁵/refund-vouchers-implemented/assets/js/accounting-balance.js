// ================================================================
// Open Account — الطبقة المحاسبية الموحدة
// الملف: accounting-balance.js
// الغرض: مصدر وحيد لحساب أرصدة الحسابات من القيود
// ================================================================

(function () {
    'use strict';

    // ============================================================
    // مساعدات داخلية
    // ============================================================

    function _num(v) {
        var n = parseFloat(v);
        return isFinite(n) ? n : 0;
    }

    /**
     * هل القيد مرحّل (غير ملغى بكل أشكاله)؟
     */
    function _isPosted(entry) {
        if (!entry) return false;
        if (entry.cancelled === true) return false;
        if (entry.documentStatus === 'cancelled') return false;
        if (entry.sourceStatus === 'cancelled') return false;
        if (entry.status === 'ملغاة') return false;
        return true;
    }

    /**
     * الحصول على القيمة بالعملة الأصلية (debit / credit)
     */
    function _originalDebit(line) {
        return _num(line.debit);
    }

    function _originalCredit(line) {
        return _num(line.credit);
    }

    /**
     * الحصول على القيمة بالعملة الأساسية
     * أولوية: debitBase / creditBase
     * احتياطي: debit / credit (بدون تحويل)
     */
    function _baseDebit(line) {
        if (line.debitBase !== undefined && line.debitBase !== null) {
            return _num(line.debitBase);
        }
        return _num(line.debit);
    }

    function _baseCredit(line) {
        if (line.creditBase !== undefined && line.creditBase !== null) {
            return _num(line.creditBase);
        }
        return _num(line.credit);
    }

    /**
     * تطابق العملة
     */
    function _matchesCurrency(entry, line, currency) {
        if (!currency) return true;

        // 1) العملة على مستوى السطر
        if (line && line.currency) {
            return line.currency === currency;
        }

        // 2) العملة على مستوى القيد
        if (entry && entry.currency) {
            return entry.currency === currency;
        }

        // 3) افتراضي: اعتبارها بالعملة الأساسية
        var baseCur = (typeof getBaseCurrency === 'function')
            ? getBaseCurrency()
            : 'SAR';
        return baseCur === currency;
    }

    /**
     * تطابق التواريخ
     */
    function _matchesDate(entry, fromDate, toDate) {
        var d = entry.date || '';
        if (fromDate && d < fromDate) return false;
        if (toDate && d > toDate) return false;
        return true;
    }

    // ============================================================
    // الواجهة العامة
    // ============================================================

    var AccountingBalance = {

        /**
         * رصيد حساب بعملة محددة (القيم بالعملة الأصلية للسطر)
         * @param {string} accountCode
         * @param {string} currency
         * @param {object} options { fromDate, toDate }
         * @returns {object} { debit, credit, balance, direction }
         */
        byCurrency: function (accountCode, currency, options) {
            options = options || {};
            var fromDate = options.fromDate || '';
            var toDate = options.toDate || '';

            var debit = 0;
            var credit = 0;

            var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
                ? journalEntries
                : [];

            entries.forEach(function (entry) {
                if (!_isPosted(entry)) return;
                if (!_matchesDate(entry, fromDate, toDate)) return;

                (entry.lines || []).forEach(function (line) {
                    if (line.accountCode !== accountCode) return;
                    if (!_matchesCurrency(entry, line, currency)) return;

                    debit += _originalDebit(line);
                    credit += _originalCredit(line);
                });
            });

            var balance = debit - credit;
            return {
                debit: debit,
                credit: credit,
                balance: balance,
                direction: balance > 0.005 ? 'debit'
                         : balance < -0.005 ? 'credit'
                         : 'zero'
            };
        },

        /**
         * رصيد حساب بالعملة الأساسية (القيم بالـ debitBase / creditBase)
         * @param {string} accountCode
         * @param {object} options { fromDate, toDate }
         * @returns {object} { debit, credit, balance, direction }
         */
        inBaseCurrency: function (accountCode, options) {
            options = options || {};
            var fromDate = options.fromDate || '';
            var toDate = options.toDate || '';

            var debit = 0;
            var credit = 0;

            var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
                ? journalEntries
                : [];

            entries.forEach(function (entry) {
                if (!_isPosted(entry)) return;
                if (!_matchesDate(entry, fromDate, toDate)) return;

                (entry.lines || []).forEach(function (line) {
                    if (line.accountCode !== accountCode) return;

                    debit += _baseDebit(line);
                    credit += _baseCredit(line);
                });
            });

            var balance = debit - credit;
            return {
                debit: debit,
                credit: credit,
                balance: balance,
                direction: balance > 0.005 ? 'debit'
                         : balance < -0.005 ? 'credit'
                         : 'zero'
            };
        },

        /**
         * أرصدة حساب بكل العملات
         * @param {string} accountCode
         * @param {object} options { fromDate, toDate }
         * @returns {object} { SAR: {...}, USD: {...}, YER: {...} }
         */
        allCurrencies: function (accountCode, options) {
            options = options || {};

            var result = {};
            var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
                ? journalEntries
                : [];

            var baseCur = (typeof getBaseCurrency === 'function')
                ? getBaseCurrency()
                : 'SAR';

            entries.forEach(function (entry) {
                if (!_isPosted(entry)) return;
                if (!_matchesDate(entry, options.fromDate || '', options.toDate || '')) return;

                (entry.lines || []).forEach(function (line) {
                    if (line.accountCode !== accountCode) return;

                    // تحديد عملة السطر
                    var cur = (line && line.currency) || entry.currency || baseCur;

                    if (!result[cur]) {
                        result[cur] = { debit: 0, credit: 0, balance: 0, direction: 'zero' };
                    }

                    result[cur].debit += _originalDebit(line);
                    result[cur].credit += _originalCredit(line);
                });
            });

            // حساب الرصيد والاتجاه لكل عملة
            Object.keys(result).forEach(function (cur) {
                var r = result[cur];
                r.balance = r.debit - r.credit;
                r.direction = r.balance > 0.005 ? 'debit'
                            : r.balance < -0.005 ? 'credit'
                            : 'zero';
            });

            return result;
        },

        /**
         * إجمالي الرصيد بعملة محددة (بما فيها تحويل العملات)
         * للاستخدام في checkSufficientBalance
         */
        byCurrencyWithConversion: function (accountCode, currency, options) {
            options = options || {};
            var baseCur = (typeof getBaseCurrency === 'function')
                ? getBaseCurrency()
                : 'SAR';

            var balance = 0;
            var entries = (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries))
                ? journalEntries
                : [];

            entries.forEach(function (entry) {
                if (!_isPosted(entry)) return;
                if (!_matchesDate(entry, options.fromDate || '', options.toDate || '')) return;

                (entry.lines || []).forEach(function (line) {
                    if (line.accountCode !== accountCode) return;

                    var lineCur = (line && line.currency) || entry.currency || baseCur;
                    var d = _originalDebit(line);
                    var c = _originalCredit(line);

                    // تحويل إلى العملة المطلوبة
                    if (lineCur !== currency && typeof getEquivalent === 'function') {
                        d = getEquivalent(d, lineCur);
                        c = getEquivalent(c, lineCur);
                    }

                    balance += (d - c);
                });
            });

            return {
                balance: balance,
                direction: balance > 0.005 ? 'debit'
                         : balance < -0.005 ? 'credit'
                         : 'zero'
            };
        }
    };

    // ============================================================
    // تصدير
    // ============================================================

    window.AccountingBalance = AccountingBalance;

    console.log('[OA] ✅ accounting-balance.js جاهز');

})();

