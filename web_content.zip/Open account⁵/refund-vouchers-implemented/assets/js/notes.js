/* ================================================================
   Open Account — دفتر الملاحظات
   الملف: notes.js
   الوصف: دفتر ملاحظات متعدد الصفحات مع ألوان وترقيم وقفل
   النسخة: v3 — إعادة بناء نظيفة
   ================================================================ */

(function() {
    'use strict';

    var STORAGE_KEY = 'oa_notes_pages';
    var FONT_KEY = 'oa_notes_font_size';
    var ACTIVE_KEY = 'oa_notes_active_page';
    var GUTTER_KEY = 'oa_notes_gutter_enabled';

    var FONT_SIZES = [14, 18, 22, 28, 36, 48];
    var FONT_LABELS = ['صغير', 'عادي', 'كبير', 'كبير جداً', 'ضخم', 'ضخم جداً'];
    var DEFAULT_FONT_INDEX = 2;

    var COLORS = [
        { name: 'أسود', value: '#000000' },
        { name: 'أحمر', value: '#c0392b' },
        { name: 'أزرق', value: '#1f6feb' },
        { name: 'أخضر', value: '#1a7a4a' },
        { name: 'برتقالي', value: '#d68910' },
        { name: 'بنفسجي', value: '#8e44ad' },
        { name: 'رمادي', value: '#666666' },
        { name: 'بني', value: '#8b4513' }
    ];

    var _pages = [];
    var _activeId = null;
    var _saveTimer = null;
    var _isDirty = false;
    var _savedSelection = null;

    // ================================================================
    // ===== أدوات مساعدة =====
    // ================================================================

    function _genId() {
        return 'N-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
    }

    function _load() {
        try {
            var raw = Storage.get(STORAGE_KEY, []);
            _pages = Array.isArray(raw) ? raw : [];
        } catch (e) { _pages = []; }

        try { _activeId = localStorage.getItem(ACTIVE_KEY) || null; } catch (e) { _activeId = null; }

        if (!_pages.length) return;
        if (!_activeId || !_pages.find(function(p) { return p.id === _activeId; })) {
            _activeId = _pages[0].id;
        }
    }

    function _save() {
        try {
            Storage.set(STORAGE_KEY, _pages);
            localStorage.setItem(ACTIVE_KEY, _activeId || '');
        } catch (e) {}
    }

    function _getActivePage() {
        return _pages.find(function(p) { return p.id === _activeId; }) || null;
    }

    function _getFontIndex() {
        try {
            var idx = parseInt(localStorage.getItem(FONT_KEY), 10);
            if (isNaN(idx) || idx < 0 || idx >= FONT_SIZES.length) return DEFAULT_FONT_INDEX;
            return idx;
        } catch (e) { return DEFAULT_FONT_INDEX; }
    }

    function _setFontIndex(idx) {
        if (idx < 0) idx = 0;
        if (idx >= FONT_SIZES.length) idx = FONT_SIZES.length - 1;
        try { localStorage.setItem(FONT_KEY, idx); } catch (e) {}
        _applyFont();
    }

    function _gutterEnabled() {
        try { return localStorage.getItem(GUTTER_KEY) === 'true'; } catch (e) { return false; }
    }

    function _setGutter(enabled) {
        try { localStorage.setItem(GUTTER_KEY, enabled ? 'true' : 'false'); } catch (e) {}
    }

    function _esc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // ================================================================
    // ===== التحديد =====
    // ================================================================

    function _saveSelection() {
        var sel = window.getSelection();
        if (!sel || sel.rangeCount === 0) return null;
        var range = sel.getRangeAt(0);
        var editor = document.getElementById('notesEditor');
        if (!editor) return null;
        if (!editor.contains(range.startContainer) || !editor.contains(range.endContainer)) return null;
        _savedSelection = range.cloneRange();
        return _savedSelection;
    }

    function _restoreSelection() {
        if (!_savedSelection) return false;
        try {
            var sel = window.getSelection();
            sel.removeAllRanges();
            sel.addRange(_savedSelection);
            return true;
        } catch (e) {
            return false;
        }
    }

    // ================================================================
    // ===== بناء الواجهة =====
    // ================================================================

    function _buildUI() {
        var container = document.getElementById('notesContainer');
        if (!container) return;

        var html = '' +
            '<div class="notes-wrapper">' +
                '<div class="notes-pages-bar" id="notesPagesBar"></div>' +
                '<div class="notes-toolbar" id="notesToolbar">' +
                    '<div class="notes-tool-group">' +
                        '<button class="notes-color-btn" id="notesColorBtn" title="لون النص" style="position:relative;">' +
                            'A' +
                            '<div class="notes-color-menu" id="notesColorMenu"></div>' +
                        '</button>' +
                    '</div>' +
                    '<div class="notes-tool-group">' +
                        '<button data-cmd="bold" title="عريض"><b>B</b></button>' +
                        '<button data-cmd="italic" title="مائل"><i>I</i></button>' +
                        '<button data-cmd="underline" title="تسطير"><u>U</u></button>' +
                        '<button data-cmd="hiliteColor" data-value="#fff3a0" title="تمييز">🖍</button>' +
                    '</div>' +
                    '<div class="notes-tool-group">' +
                        '<button data-cmd="insertUnorderedList" title="نقاط">•</button>' +
                        '<button data-cmd="insertOrderedList" title="ترقيم">1.</button>' +
                        '<button data-cmd="insertHorizontalRule" title="خط فاصل">—</button>' +
                    '</div>' +
                    '<div class="notes-tool-group">' +
                        '<button data-action="fontDown" title="تصغير" class="small">A−</button>' +
                        '<span class="notes-font-label" id="notesFontLabel">كبير</span>' +
                        '<button data-action="fontUp" title="تكبير" class="small">A+</button>' +
                    '</div>' +
                    '<div class="notes-tool-group">' +
                        '<button data-action="toggleGutter" id="notesGutterBtn" title="ترقيم السطور">#</button>' +
                    '</div>' +
                    '<div class="notes-tool-group">' +
                        '<button data-action="find" title="بحث">🔍</button>' +
                    '</div>' +
                '</div>' +

                '<div class="notes-page-header">' +
                    '<input type="text" class="notes-page-title-input" id="notesPageTitle" placeholder="عنوان الصفحة (اختياري)">' +
                    '<div class="notes-page-dates" id="notesPageDates">—</div>' +
                '</div>' +

                '<button class="notes-lock-btn" id="notesLockBtn" title="افتح لوحة المفاتيح">🔒</button>' +

                '<div class="notes-editor-wrap">' +
                    '<div class="notes-gutter hidden" id="notesGutter"></div>' +
                    '<div class="notes-editor" id="notesEditor" contenteditable="true" inputmode="none" spellcheck="false" tabindex="0"></div>' +
                '</div>' +

                '<div class="notes-footer">' +
                    '<div class="notes-footer-stats" id="notesFooterStats">' +
                        '<span>الأسطر: 0</span>' +
                        '<span>الكلمات: 0</span>' +
                        '<span>الحروف: 0</span>' +
                        '<span id="notesSaveStatus">✓ محفوظ</span>' +
                    '</div>' +
                    '<div class="notes-footer-actions">' +
                        '<button onclick="OANotes.togglePin()" id="notesPinBtn">📌 تثبيت</button>' +
                        '<button onclick="OANotes.print()">🖨 طباعة</button>' +
                        '<button onclick="OANotes.deleteActivePage()" class="danger">🗑 حذف</button>' +
                    '</div>' +
                '</div>' +
            '</div>';

        container.innerHTML = html;

        _bindEvents();
        _renderColorMenu();
        _renderPagesBar();
        _loadActivePage();
        _applyFont();
        _updateGutterVisibility();
        _updatePinButton();
        _updateLockButton(true);
    }

    function _bindEvents() {
        var titleEl = document.getElementById('notesPageTitle');
        if (titleEl) {
            titleEl.addEventListener('input', function() {
                var p = _getActivePage();
                if (!p) return;
                p.title = titleEl.value;
                _isDirty = true;
                _markDirty();
                _scheduleSave();
                _renderPagesBar();
            });
        }

        var editor = document.getElementById('notesEditor');
        if (editor) {
            editor.addEventListener('input', function() {
                var p = _getActivePage();
                if (!p) return;
                p.content = editor.innerHTML;
                p.updatedAt = new Date().toISOString();
                _isDirty = true;
                _markDirty();
                _scheduleSave();
                _updateStats();
                _updateGutter();
            });

            editor.addEventListener('keyup', _updateGutter);
            editor.addEventListener('click', _updateGutter);
            editor.addEventListener('mouseup', _saveSelection);
            editor.addEventListener('keyup', _saveSelection);

            editor.addEventListener('paste', function(e) {
                e.preventDefault();
                var text = (e.clipboardData || window.clipboardData).getData('text/plain');
                document.execCommand('insertText', false, text);
            });

            editor.addEventListener('scroll', function() {
                var gutter = document.getElementById('notesGutter');
                if (gutter) gutter.scrollTop = editor.scrollTop;
            });
        }

        // ===== Toolbar — event delegation =====
        var toolbar = document.getElementById('notesToolbar');
        if (toolbar) {
            toolbar.addEventListener('mousedown', function(e) {
                var btn = e.target.closest('button');
                if (!btn) return;
                e.preventDefault();
            });

            toolbar.addEventListener('click', function(e) {
                var btn = e.target.closest('button');
                if (!btn) return;

                if (btn.id === 'notesColorBtn') {
                    var menu = document.getElementById('notesColorMenu');
                    if (menu) menu.classList.toggle('open');
                    return;
                }

                var cmd = btn.getAttribute('data-cmd');
                if (cmd) {
                    var value = btn.getAttribute('data-value') || null;
                    _execFormat(cmd, value);
                    return;
                }

                var action = btn.getAttribute('data-action');
                if (action) {
                    if (action === 'fontUp') _setFontIndex(_getFontIndex() + 1);
                    else if (action === 'fontDown') _setFontIndex(_getFontIndex() - 1);
                    else if (action === 'toggleGutter') {
                        _setGutter(!_gutterEnabled());
                        _updateGutterVisibility();
                        _updateGutter();
                    }
                    else if (action === 'find') _findText();
                }
            });
        }

        // ===== قائمة الألوان =====
        var colorMenu = document.getElementById('notesColorMenu');
        if (colorMenu) {
            colorMenu.addEventListener('mousedown', function(e) {
                if (e.target.classList.contains('notes-color-swatch')) {
                    e.preventDefault();
                }
            });
            colorMenu.addEventListener('click', function(e) {
                var sw = e.target.closest('.notes-color-swatch');
                if (!sw) return;
                var color = sw.getAttribute('data-color');
                if (color) _applyColor(color);
            });
        }

        document.addEventListener('click', function(e) {
            var menu = document.getElementById('notesColorMenu');
            var btn = document.getElementById('notesColorBtn');
            if (menu && btn && !menu.contains(e.target) && !btn.contains(e.target)) {
                menu.classList.remove('open');
            }
        });

        // ===== زر القفل =====
        var lockBtn = document.getElementById('notesLockBtn');
        if (lockBtn) {
            lockBtn.addEventListener('click', function(e) {
                e.preventDefault();
                OANotes.toggleLock();
            });
        }

        // تحذير عند الخروج
        window.addEventListener('beforeunload', function(e) {
            if (_isDirty) {
                e.preventDefault();
                e.returnValue = '';
            }
        });
    }

    // ================================================================
    // ===== التنسيق =====
    // ================================================================

    function _execFormat(command, value) {
        var editor = document.getElementById('notesEditor');
        if (!editor) return;

        var sel = window.getSelection();
        if (!sel || sel.rangeCount === 0 || sel.toString().length === 0) {
            _restoreSelection();
        }

        try {
            document.execCommand(command, false, value || null);
        } catch (e) {
            console.warn('execCommand failed:', e);
        }

        _saveSelection();

        var p = _getActivePage();
        if (p) {
            p.content = editor.innerHTML;
            p.updatedAt = new Date().toISOString();
            _isDirty = true;
            _markDirty();
            _scheduleSave();
        }
    }

    function _applyColor(color) {
        var editor = document.getElementById('notesEditor');
        if (!editor) return;

        var sel = window.getSelection();
        if (!sel || sel.rangeCount === 0 || sel.toString().length === 0) {
            _restoreSelection();
        }

        try {
            document.execCommand('foreColor', false, color);
        } catch (e) {}

        var menu = document.getElementById('notesColorMenu');
        if (menu) menu.classList.remove('open');

        _saveSelection();

        var p = _getActivePage();
        if (p) {
            p.content = editor.innerHTML;
            p.updatedAt = new Date().toISOString();
            _isDirty = true;
            _markDirty();
            _scheduleSave();
        }
    }

    // ================================================================
    // ===== قفل/فتح لوحة المفاتيح =====
    // ================================================================

    function _setLocked(locked) {
        var editor = document.getElementById('notesEditor');
        if (!editor) return;

        if (locked) {
            editor.setAttribute('inputmode', 'none');
            editor.blur();
        } else {
            editor.removeAttribute('inputmode');
            editor.setAttribute('inputmode', 'text');
            editor.focus();

            try {
                var range = document.createRange();
                range.selectNodeContents(editor);
                range.collapse(false);
                var sel = window.getSelection();
                sel.removeAllRanges();
                sel.addRange(range);
            } catch (e) {}
        }

        _updateLockButton(locked);
    }

    function _updateLockButton(locked) {
        var btn = document.getElementById('notesLockBtn');
        if (!btn) return;

        if (locked) {
            btn.textContent = '🔒';
            btn.title = 'افتح لوحة المفاتيح';
            btn.classList.add('locked');
        } else {
            btn.textContent = '🔓';
            btn.title = 'أغلق لوحة المفاتيح';
            btn.classList.remove('locked');
        }
    }

    // ================================================================
    // ===== ترقيم السطور =====
    // ================================================================

    function _updateGutterVisibility() {
        var gutter = document.getElementById('notesGutter');
        var editor = document.getElementById('notesEditor');
        if (!gutter || !editor) return;

        if (_gutterEnabled()) {
            gutter.classList.remove('hidden');
            editor.classList.add('has-gutter');
        } else {
            gutter.classList.add('hidden');
            editor.classList.remove('has-gutter');
        }

        var btn = document.getElementById('notesGutterBtn');
        if (btn) btn.classList.toggle('active', _gutterEnabled());
    }

    function _updateGutter() {
        var editor = document.getElementById('notesEditor');
        var gutter = document.getElementById('notesGutter');
        if (!editor || !gutter) return;
        if (!_gutterEnabled()) return;

        var text = editor.innerText || '';
        var lineCount = text.split('\n').length;
        if (lineCount < 1) lineCount = 1;

        var html = '';
        for (var i = 1; i <= lineCount; i++) {
            html += '<div class="notes-line-num">' + i + '</div>';
        }
        gutter.innerHTML = html;
        gutter.scrollTop = editor.scrollTop;
    }

    // ================================================================
    // ===== حجم الخط =====
    // ================================================================

    function _applyFont() {
        var editor = document.getElementById('notesEditor');
        var label = document.getElementById('notesFontLabel');
        if (!editor) return;

        var idx = _getFontIndex();
        editor.style.fontSize = FONT_SIZES[idx] + 'px';

        if (label) {
            label.textContent = FONT_LABELS[idx];
        }
    }

    // ================================================================
    // ===== الألوان =====
    // ================================================================

    function _renderColorMenu() {
        var menu = document.getElementById('notesColorMenu');
        if (!menu) return;

        var html = '';
        COLORS.forEach(function(c) {
            html += '<div class="notes-color-swatch" data-color="' + c.value + '" style="background:' + c.value + '" title="' + c.name + '"></div>';
        });
        menu.innerHTML = html;
    }

    // ================================================================
    // ===== الصفحات =====
    // ================================================================

    function _renderPagesBar() {
        var bar = document.getElementById('notesPagesBar');
        if (!bar) return;

        if (!_pages.length) {
            bar.innerHTML = '<button class="notes-add-btn" onclick="OANotes.createPage()">+ صفحة جديدة</button>';
            return;
        }

        var sorted = _pages.slice().sort(function(a, b) {
            if (a.pinned && !b.pinned) return -1;
            if (!a.pinned && b.pinned) return 1;
            return String(b.updatedAt || b.createdAt).localeCompare(String(a.updatedAt || a.createdAt));
        });

        var html = '';
        sorted.forEach(function(p) {
            var isActive = p.id === _activeId;
            var title = p.title || 'بدون عنوان';
            var pin = p.pinned ? '<span class="pin-icon">📌</span>' : '';
            html += '<div class="notes-page-tab' + (isActive ? ' active' : '') + '" onclick="OANotes.selectPage(\'' + p.id + '\')">' +
                pin + '<span>' + _esc(title).substring(0, 20) + '</span>' +
                '<button class="close-tab" onclick="event.stopPropagation();OANotes.deletePage(\'' + p.id + '\')" title="حذف">×</button>' +
            '</div>';
        });
        html += '<button class="notes-add-btn" onclick="OANotes.createPage()">+ صفحة جديدة</button>';
        bar.innerHTML = html;
    }

    function _loadActivePage() {
        var p = _getActivePage();
        if (!p) {
            _showEmptyState();
            return;
        }

        _hideEmptyState();

        var titleEl = document.getElementById('notesPageTitle');
        if (titleEl) titleEl.value = p.title || '';

        var editor = document.getElementById('notesEditor');
        if (editor) {
            editor.innerHTML = p.content || '';
            _isDirty = false;
        }

        _setLocked(true);
        _updateDates();
        _updateStats();
        _updateGutter();
        _updatePinButton();
    }

    function _showEmptyState() {
        var container = document.getElementById('notesContainer');
        if (!container) return;
        container.innerHTML =
            '<div class="notes-wrapper">' +
                '<div class="notes-empty">' +
                    '<div class="notes-empty-icon">📒</div>' +
                    '<div>لا توجد صفحات بعد</div>' +
                    '<button class="notes-empty-btn" onclick="OANotes.createPage()">+ إنشاء صفحة جديدة</button>' +
                '</div>' +
            '</div>';
    }

    function _hideEmptyState() {
        if (!document.getElementById('notesEditor')) {
            _buildUI();
        }
    }

    // ================================================================
    // ===== التواريخ والإحصائيات =====
    // ================================================================

    function _updateDates() {
        var p = _getActivePage();
        if (!p) return;
        var el = document.getElementById('notesPageDates');
        if (!el) return;

        var created = _formatDate(p.createdAt);
        var updated = _formatDate(p.updatedAt);

        if (updated && updated !== created) {
            el.innerHTML = 'أُنشئت: ' + created + '<br>آخر تعديل: ' + updated;
        } else {
            el.innerHTML = 'أُنشئت: ' + created;
        }
    }

    function _formatDate(iso) {
        if (!iso) return '—';
        try {
            var d = new Date(iso);
            var pad = function(n) { return n < 10 ? '0' + n : n; };
            return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) +
                ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
        } catch (e) { return '—'; }
    }

    function _updateStats() {
        var editor = document.getElementById('notesEditor');
        if (!editor) return;

        var text = editor.innerText || '';
        var lines = text.split('\n').filter(function(l) { return l.trim().length > 0; }).length;
        var words = text.trim().split(/\s+/).filter(function(w) { return w.length > 0; }).length;
        var charsNoSpaces = text.replace(/\s/g, '').length;

        var el = document.getElementById('notesFooterStats');
        if (el) {
            var statusHtml = '';
            if (_isDirty) {
                statusHtml = '<span class="notes-dirty-indicator"></span> غير محفوظ';
            } else {
                statusHtml = '✓ محفوظ';
            }
            el.innerHTML =
                '<span>الأسطر: ' + lines + '</span>' +
                '<span>الكلمات: ' + words + '</span>' +
                '<span>الحروف: ' + charsNoSpaces + '</span>' +
                '<span id="notesSaveStatus">' + statusHtml + '</span>';
        }
    }

    // ================================================================
    // ===== الحفظ التلقائي =====
    // ================================================================

    function _scheduleSave() {
        if (_saveTimer) clearTimeout(_saveTimer);
        _saveTimer = setTimeout(function() {
            _saveNow();
        }, 1000);
    }

    function _saveNow() {
        var p = _getActivePage();
        if (!p) return;

        p.updatedAt = new Date().toISOString();
        _save();
        _isDirty = false;
        _updateStats();
        _updateDates();
    }

    function _markDirty() {
        _updateStats();
    }

    // ================================================================
    // ===== عمليات مساعدة =====
    // ================================================================

    function _togglePin() {
        var p = _getActivePage();
        if (!p) return;
        p.pinned = !p.pinned;
        p.updatedAt = new Date().toISOString();
        _save();
        _renderPagesBar();
        _updatePinButton();
        if (typeof showToast === 'function') {
            showToast(p.pinned ? 'تم التثبيت' : 'تم إلغاء التثبيت', 'info');
        }
    }

    function _updatePinButton() {
        var p = _getActivePage();
        var btn = document.getElementById('notesPinBtn');
        if (!btn) return;
        btn.textContent = p && p.pinned ? '📌 مثبّت' : '📌 تثبيت';
    }

    function _findText() {
        var editor = document.getElementById('notesEditor');
        if (!editor) return;
        var query = prompt('ابحث عن:');
        if (!query) return;
        var text = editor.innerText || '';
        var count = 0;
        var pos = 0;
        while ((pos = text.indexOf(query, pos)) !== -1) {
            count++;
            pos += query.length;
        }
        if (typeof showToast === 'function') {
            showToast(count > 0 ? 'عدد مرات الظهور: ' + count : 'لم يُعثر على النص', count > 0 ? 'info' : 'warning');
        }
    }

    // ================================================================
    // ===== الواجهة العامة =====
    // ================================================================

    window.OANotes = {

        createPage: function() {
            var now = new Date().toISOString();
            var page = {
                id: _genId(),
                title: '',
                content: '',
                createdAt: now,
                updatedAt: now,
                pinned: false
            };
            _pages.push(page);
            _activeId = page.id;
            _save();
            _renderPagesBar();
            _loadActivePage();
        },

        selectPage: function(id) {
            if (_isDirty) _saveNow();
            _activeId = id;
            _save();
            _renderPagesBar();
            _loadActivePage();
        },

        deletePage: function(id) {
            id = id || _activeId;
            var p = _pages.find(function(x) { return x.id === id; });
            if (!p) return;
            var title = p.title || 'بدون عنوان';
            if (!confirm('حذف الصفحة "' + title + '"؟')) return;

            _pages = _pages.filter(function(x) { return x.id !== id; });
            if (_pages.length) {
                _activeId = _pages[0].id;
            } else {
                _activeId = null;
            }
            _save();
            if (_pages.length) {
                _renderPagesBar();
                _loadActivePage();
            } else {
                _showEmptyState();
            }
            if (typeof showToast === 'function') showToast('تم حذف الصفحة', 'success');
        },

        toggleLock: function() {
            var editor = document.getElementById('notesEditor');
            if (!editor) return;
            var isLocked = editor.getAttribute('inputmode') === 'none';
            _setLocked(!isLocked);
        },

        togglePin: function() {
            _togglePin();
        },

        print: function() {
            var editor = document.getElementById('notesEditor');
            var title = document.getElementById('notesPageTitle');
            if (!editor) return;

            var pageTitle = (title && title.value) ? title.value : 'ملاحظات';
            var content = editor.innerHTML;

            var win = window.open('', '_blank');
            if (!win) {
                alert('تعذر فتح نافذة الطباعة');
                return;
            }
            win.document.write(
                '<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>' +
                _esc(pageTitle) + '</title><style>' +
                'body{font-family:Cairo,Tahoma,sans-serif;direction:rtl;padding:20px;font-size:14px;line-height:1.7;}' +
                'h1{font-size:20px;border-bottom:2px solid #d4a017;padding-bottom:8px;}' +
                'hr{border:none;border-top:2px solid #d4a017;margin:16px 0;}' +
                '</style></head><body>' +
                '<h1>' + _esc(pageTitle) + '</h1>' + content +
                '</body></html>'
            );
            win.document.close();
            setTimeout(function() { win.print(); }, 500);
        },

        deleteActivePage: function() {
            OANotes.deletePage(_activeId);
        }
    };

    // ================================================================
    // ===== التهيئة =====
    // ================================================================

    function initNotes() {
        _load();

        if (_pages.length) {
            _buildUI();
        } else {
            _showEmptyState();
        }

        console.log('Notes: initialized — pages:', _pages.length);
    }

    window.initNotes = initNotes;

})();