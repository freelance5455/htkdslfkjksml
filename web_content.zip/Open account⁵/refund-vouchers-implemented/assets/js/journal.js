// ================================================================
// Open Account — دفتر اليومية (Journal)
// الملف: journal.js
// النسخة: v2 — مع إصلاحات الترقيم والتوليد التلقائي
// ================================================================


// ================================================================
// ===== 1. شجرة الحسابات =====
// ================================================================

var ACCOUNTS = {
    '1000': { name: 'الصندوق', type: 'asset' },
    '1010': { name: 'البنك', type: 'asset' },
    '1100': { name: 'العملاء', type: 'asset' },
    '1200': { name: 'المخزون', type: 'asset' },
    '2000': { name: 'الموردين', type: 'liability' },
    '3000': { name: 'رأس المال', type: 'equity' },
    '4000': { name: 'إيرادات المبيعات', type: 'revenue' },
    '4010': { name: 'مردودات المبيعات', type: 'contra_revenue' },
    '4100': { name: 'إيرادات أخرى', type: 'revenue' },
    '4200': { name: 'أرباح فروقات العملة', type: 'revenue' },
    '7000': { name: 'خسائر فروقات العملة', type: 'expense' },
    '5000': { name: 'تكلفة المبيعات COGS', type: 'expense' },
    '6000': { name: 'المصاريف', type: 'expense' }
};

var JOURNAL_KEY = 'oa_journal_entries';
var JOURNAL_COUNTER_KEY = 'oa_journal_counter';

var journalEntries = [];


// ================================================================
// ===== 2. تحميل وحفظ =====
// ================================================================

function loadJournal() {
    journalEntries = Storage.get(JOURNAL_KEY, []);
    if (!Array.isArray(journalEntries)) journalEntries = [];
}

function saveJournal() {
    Storage.set(JOURNAL_KEY, journalEntries);
}


// ================================================================
// ===== 3. توليد رقم قيد تسلسلي =====
// ================================================================

function _generateJournalNumber() {
    var counter = parseInt(Storage.get(JOURNAL_COUNTER_KEY, '0')) || 0;
    counter++;
    Storage.set(JOURNAL_COUNTER_KEY, counter);
    return 'JE-' + String(counter).padStart(6, '0');
}


// ================================================================
// ===== 4. بناء قيد =====
// ================================================================

function _buildEntry(type, referenceId, date, description, currency, lines, exchangeRate, metadata) {
    metadata = metadata || {};

    var cleanLines = (lines || []).filter(function(l) {
        return (parseFloat(l.debit) || 0) > 0 || (parseFloat(l.credit) || 0) > 0;
    });

    if (cleanLines.length < 2) return null;

    var entryCurrency = currency || 'YER';
    var rate = parseFloat(exchangeRate) > 0
        ? parseFloat(exchangeRate)
        : (typeof getCurrentExchangeRateSnapshot === 'function'
            ? getCurrentExchangeRateSnapshot(entryCurrency)
            : 1);

    var baseCurrency = typeof getBaseCurrency === 'function'
        ? getBaseCurrency()
        : 'YER';
    var baseRate = typeof getRate === 'function' ? (getRate(baseCurrency) || 1) : 1;
    var factor = (entryCurrency !== baseCurrency && baseRate > 0) ? rate / baseRate : 1;

    return {
        id: _generateJournalNumber(),
        type: type,
        referenceId: referenceId,
        referenceType: metadata.referenceType || type,
        reversalOf: metadata.reversalOf || null,
        reversalEntryId: metadata.reversalEntryId || null,
        date: date,
        description: description,
        currency: entryCurrency,
        exchangeRate: rate,
        lines: cleanLines.map(function(l) {
            var d = parseFloat(l.debit) || 0;
            var c = parseFloat(l.credit) || 0;
            return Object.assign({}, l, {
                // لا نعيد حساب القيمة التاريخية إن كانت محفوظة بالفعل.
                debitBase: l.debitBase !== undefined && l.debitBase !== null
                    ? parseFloat(l.debitBase) || 0
                    : d * factor,
                creditBase: l.creditBase !== undefined && l.creditBase !== null
                    ? parseFloat(l.creditBase) || 0
                    : c * factor
            });
        }),
        createdAt: new Date().toISOString(),
        status: 'posted'
    };
}


// ================================================================
// ===== 5. حذف القيود المرتبطة بمستند =====
// ================================================================

function _removeEntriesByRef(referenceId) {
    if (!referenceId) return 0;
    var before = journalEntries.length;
    journalEntries = journalEntries.filter(function(e) {
        return e.referenceId !== referenceId;
    });
    var removed = before - journalEntries.length;
    if (removed > 0) saveJournal();
    return removed;
}


// ================================================================
// ===== 6. قيود فاتورة بيع =====
// ================================================================

function _entryFromSalesInvoice(inv) {
    if (!inv || !inv.total) return null;
    var currency = inv.currency || 'YER';
    var total = parseFloat(inv.total) || 0;
    if (total <= 0) return null;

    var lines = [];
    if (inv.type === 'نقدي') {
        lines.push({ accountCode: '1000', accountName: ACCOUNTS['1000'].name, debit: total, credit: 0 });
    } else {
        lines.push({ accountCode: '1100', accountName: ACCOUNTS['1100'].name, debit: total, credit: 0 });
    }
    lines.push({ accountCode: '4000', accountName: ACCOUNTS['4000'].name, debit: 0, credit: total });

    var cogs = parseFloat(inv.cogsTotal) || 0;
    if (inv.cogsKnown && cogs > 0) {
        lines.push({ accountCode: '5000', accountName: ACCOUNTS['5000'].name, debit: cogs, credit: 0 });
        lines.push({ accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: 0, credit: cogs });
    }

    return _buildEntry('sales_invoice', inv.id, inv.date,
        'فاتورة بيع — ' + (inv.customerName || ''), currency, lines, inv.exchangeRate,
        { referenceType: 'sales_invoice' });
}


// ================================================================
// ===== 7. قيود فاتورة شراء =====
// ================================================================

function _entryFromPurchaseInvoice(inv) {
    if (!inv || !inv.total) return null;
    var currency = inv.currency || 'YER';
    var total = parseFloat(inv.total) || 0;
    if (total <= 0) return null;

    var lines = [
        { accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: total, credit: 0 }
    ];
    if (inv.type === 'نقدي') {
        lines.push({ accountCode: '1000', accountName: ACCOUNTS['1000'].name, debit: 0, credit: total });
    } else {
        lines.push({ accountCode: '2000', accountName: ACCOUNTS['2000'].name, debit: 0, credit: total });
    }

    return _buildEntry('purchase_invoice', inv.id, inv.date,
        'فاتورة شراء — ' + (inv.supplierName || ''), currency, lines, inv.exchangeRate,
        { referenceType: 'purchase_invoice' });
}


// ================================================================
// ===== 8. قيد إلغاء فاتورة =====
// ================================================================

function _entryFromInvoiceCancellation(inv) {
    if (!inv || !inv.total) return null;
    var isCancelled = inv.cancelled === true || inv.status === 'ملغاة';
    if (!isCancelled) return null;
    var _kind = inv.kind || (inv.customerId ? 'sale' : 'purchase');
    var currency = inv.currency || 'YER';
    var total = parseFloat(inv.total) || 0;
    if (total <= 0) return null;

    var lines = [];
    if (_kind === 'sale') {
        if (inv.type === 'نقدي') {
            lines.push({ accountCode: '4000', accountName: ACCOUNTS['4000'].name, debit: total, credit: 0 });
            lines.push({ accountCode: '1000', accountName: ACCOUNTS['1000'].name, debit: 0, credit: total });
        } else {
            lines.push({ accountCode: '4000', accountName: ACCOUNTS['4000'].name, debit: total, credit: 0 });
            lines.push({ accountCode: '1100', accountName: ACCOUNTS['1100'].name, debit: 0, credit: total });
        }
        var cogs = parseFloat(inv.cogsTotal) || 0;
        if (inv.cogsKnown && cogs > 0) {
            lines.push({ accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: cogs, credit: 0 });
            lines.push({ accountCode: '5000', accountName: ACCOUNTS['5000'].name, debit: 0, credit: cogs });
        }
  } else if (_kind === 'purchase') {
    if (inv.type === 'نقدي') {
        // عكس شراء نقدي: مدين صندوق / دائن مخزون
        lines.push({ accountCode: '1000', accountName: ACCOUNTS['1000'].name, debit: total, credit: 0 });
        lines.push({ accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: 0, credit: total });
    } else {
        // عكس شراء آجل: مدين موردين / دائن مخزون
        lines.push({ accountCode: '2000', accountName: ACCOUNTS['2000'].name, debit: total, credit: 0 });
        lines.push({ accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: 0, credit: total });
    }
} else {
        return null;
    }

    return _buildEntry('invoice_cancellation', 'cancel:' + _kind + ':' + inv.id, 
    (inv.cancelledAt || inv.date || '').substring(0, 10),
    'إلغاء فاتورة ' + (_kind === 'sale' ? 'بيع' : 'شراء') + ' — ' + inv.id + (inv.cancelReason ? ' — ' + inv.cancelReason : ''),
    currency, lines, inv.exchangeRate, {
        referenceType: 'invoice_cancellation',
        reversalOf: inv.id
    });
}


// ================================================================
// ===== 8. قيود سند قبض =====
// ================================================================

function _entryFromReceipt(rec) {
    if (!rec || !rec.amount) return null;

    if (rec.receiptType === 'supplier_refund') {
        var refundCurrency = rec.currency || 'YER';
        var refundAmount = parseFloat(rec.amount) || 0;
        if (refundAmount <= 0) return null;
        var refundAcc = rec.account === 'bank' || rec.method === 'تحويل بنكي' || rec.method === 'بطاقة' ? '1010' : '1000';
        return _buildEntry('supplier_refund', rec.id, rec.date,
            'تحصيل مبلغ من مورد — ' + (rec.supplierName || ''), refundCurrency, [
                { accountCode: refundAcc, accountName: ACCOUNTS[refundAcc].name, debit: refundAmount, credit: 0 },
                { accountCode: '2000', accountName: ACCOUNTS['2000'].name, debit: 0, credit: refundAmount }
            ], rec.exchangeRate, { referenceType: 'supplier_refund' });
    }
    if (rec.invoiceId && typeof salesInvoices !== 'undefined') {
        var linkedSale = salesInvoices.find(function(inv) { return inv.id === rec.invoiceId; });
        if (linkedSale && linkedSale.type === 'نقدي') return null; // الفاتورة النقدية نفسها أثبتت الصندوق
    }
    var currency = rec.currency || 'YER';
    var amount = parseFloat(rec.amount) || 0;
    if (amount <= 0) return null;

    var accCode = '1000';
    if (rec.method === 'تحويل بنكي' || rec.method === 'بطاقة') accCode = '1010';

    var lines = [
        { accountCode: accCode, accountName: ACCOUNTS[accCode].name, debit: amount, credit: 0 },
        { accountCode: '1100', accountName: ACCOUNTS['1100'].name, debit: 0, credit: amount }
    ];

    return _buildEntry('receipt', rec.id, rec.date,
        'سند قبض — ' + (rec.customerName || ''), currency, lines, rec.exchangeRate,
        { referenceType: 'receipt' });
}

// ================================================================
// ===== 8-b. قيود إلغاء سند القبض =====
// ================================================================

function _entryFromReceiptCancellation(rec) {
    if (!rec || !rec.amount) return null;

    if (
        !rec.cancelled &&
        rec.documentStatus !== 'cancelled' &&
        rec.sourceStatus !== 'cancelled'
    ) {
        return null;
    }

    // إذا كان السند التلقائي ناتجاً عن فاتورة بيع نقدية،
    // فإن إلغاء الفاتورة نفسها يعكس أثر الصندوق والمخزون.
    // لا ننشئ قيد إلغاء ثانياً للسند التلقائي حتى لا يتضاعف الأثر.
    if (
        rec.invoiceId &&
        typeof salesInvoices !== 'undefined'
    ) {
        var linkedSale = salesInvoices.find(function(inv) {
            return inv.id === rec.invoiceId;
        });

        if (linkedSale && linkedSale.type === 'نقدي') {
            return null;
        }
    }

    var currency = rec.currency || 'YER';
    var amount = parseFloat(rec.amount) || 0;
    if (amount <= 0) return null;

    var accCode = '1000';
    if (rec.method === 'تحويل بنكي' || rec.method === 'بطاقة') accCode = '1010';

    // عكس سند قبض:
    // Dr العملاء
    // Cr الصندوق/البنك
    var lines = [
        { 
            accountCode: '1100', 
            accountName: ACCOUNTS['1100'].name, 
            debit: amount, 
            credit: 0 
        },
        { 
            accountCode: accCode, 
            accountName: ACCOUNTS[accCode].name, 
            debit: 0, 
            credit: amount 
        }
    ];

    return _buildEntry(
        'receipt_cancellation',
        'cancel:receipt:' + rec.id,
        (rec.cancelledAt || rec.date || '').substring(0, 10),
        'إلغاء سند قبض — ' + rec.id +
            (rec.cancelReason ? ' — ' + rec.cancelReason : ''),
        currency,
        lines,
        rec.exchangeRate,
        {
            referenceType: 'receipt_cancellation',
            reversalOf: rec.id
        }
    );
}


// ================================================================
// ===== 9. قيود سند صرف =====
// ================================================================

function _entryFromPayment(pay) {
    if (!pay || !pay.amount) return null;

    if (pay.paymentType === 'customer_refund') {
        var refundCurrency = pay.currency || 'YER';
        var refundAmount = parseFloat(pay.amount) || 0;
        if (refundAmount <= 0) return null;
        var refundAcc = pay.account === 'bank' || pay.method === 'تحويل بنكي' || pay.method === 'بطاقة' ? '1010' : '1000';
        return _buildEntry('customer_refund', pay.id, pay.date,
            'رد مبلغ لعميل — ' + (pay.customerName || ''), refundCurrency, [
                { accountCode: '1100', accountName: ACCOUNTS['1100'].name, debit: refundAmount, credit: 0 },
                { accountCode: refundAcc, accountName: ACCOUNTS[refundAcc].name, debit: 0, credit: refundAmount }
            ], pay.exchangeRate, { referenceType: 'customer_refund' });
    }

    if (pay.invoiceId && typeof purchaseInvoices !== 'undefined' && !pay.isExpense) {
        var linkedPurchase = purchaseInvoices.find(function(inv) { return inv.id === pay.invoiceId; });
        if (linkedPurchase && linkedPurchase.type === 'نقدي') return null; // الفاتورة النقدية نفسها أثبتت الصندوق
    }
    var currency = pay.currency || 'YER';
    var amount = parseFloat(pay.amount) || 0;
    if (amount <= 0) return null;

    var accCode = '1000';
    if (pay.method === 'تحويل بنكي' || pay.method === 'بطاقة') accCode = '1010';

    var lines;
    if (pay.isExpense) {
        lines = [
            { accountCode: '6000', accountName: ACCOUNTS['6000'].name, debit: amount, credit: 0 },
            { accountCode: accCode, accountName: ACCOUNTS[accCode].name, debit: 0, credit: amount }
        ];
    } else {
        lines = [
            { accountCode: '2000', accountName: ACCOUNTS['2000'].name, debit: amount, credit: 0 },
            { accountCode: accCode, accountName: ACCOUNTS[accCode].name, debit: 0, credit: amount }
        ];
    }

    return _buildEntry(pay.isExpense ? 'expense' : 'payment', pay.id, pay.date,
        pay.isExpense ? ('مصروف — ' + (pay.expenseType || '')) : ('سند صرف — ' + (pay.supplierName || '')),
        currency, lines, pay.exchangeRate,
        { referenceType: pay.isExpense ? 'expense' : 'payment' });
}


// ================================================================
// ===== 9-b. قيود إلغاء سند الصرف =====
// ================================================================

function _entryFromPaymentCancellation(pay) {
    if (!pay || !pay.amount) return null;

    if (
        !pay.cancelled &&
        pay.documentStatus !== 'cancelled' &&
        pay.sourceStatus !== 'cancelled'
    ) {
        return null;
    }

    // إذا كان السند التلقائي ناتجاً عن فاتورة شراء نقدية،
    // فإن إلغاء الفاتورة نفسها يعكس أثر الصندوق والمخزون.
    // لا ننشئ قيد إلغاء ثانياً للسند التلقائي حتى لا يتضاعف الأثر.
    if (
        pay.invoiceId &&
        typeof purchaseInvoices !== 'undefined' &&
        !pay.isExpense
    ) {
        var linkedPurchase = purchaseInvoices.find(function(inv) {
            return inv.id === pay.invoiceId;
        });

        if (linkedPurchase && linkedPurchase.type === 'نقدي') {
            return null;
        }
    }

    var currency = pay.currency || 'YER';
    var amount = parseFloat(pay.amount) || 0;

    if (amount <= 0) return null;

    var accCode = '1000';

    if (
        pay.method === 'تحويل بنكي' ||
        pay.method === 'بطاقة'
    ) {
        accCode = '1010';
    }

    var lines;

    if (pay.isExpense) {
        // عكس المصروف:
        lines = [
            {
                accountCode: accCode,
                accountName: ACCOUNTS[accCode].name,
                debit: amount,
                credit: 0
            },
            {
                accountCode: '6000',
                accountName: ACCOUNTS['6000'].name,
                debit: 0,
                credit: amount
            }
        ];
    } else {
        // عكس سند صرف للمورد:
        lines = [
            {
                accountCode: accCode,
                accountName: ACCOUNTS[accCode].name,
                debit: amount,
                credit: 0
            },
            {
                accountCode: '2000',
                accountName: ACCOUNTS['2000'].name,
                debit: 0,
                credit: amount
            }
        ];
    }

    return _buildEntry(
    'payment_cancellation',
    'cancel:payment:' + pay.id,
        (pay.cancelledAt || pay.date || '').substring(0, 10),
        (pay.isExpense
            ? 'إلغاء مصروف — '
            : 'إلغاء سند صرف — '
        ) + pay.id +
        (
            pay.cancelReason
                ? ' — ' + pay.cancelReason
                : ''
        ),
        currency,
        lines,
        pay.exchangeRate,
        {
            referenceType: 'payment_cancellation',
            reversalOf: pay.id
        }
    );
}

// ================================================================
// ===== 10. قيود تحويل =====
// ================================================================

function _entryFromTransfer(t) {
    if (!t || t.status === 'cancelled') return null;
    var fromType = t.from && t.from.accountType;
    var toType = t.to && t.to.accountType;
    var fromAmount = parseFloat(t.from && t.from.amount) || 0;
    var toAmount = parseFloat(t.to && t.to.amount) || 0;
    if (fromAmount <= 0 || toAmount <= 0) return null;

    var fromCurrency = (t.from && t.from.currency) || 'YER';
    var toCurrency = (t.to && t.to.currency) || 'YER';
    var fromRate = parseFloat(t.from && t.from.exchangeRate) || (typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(fromCurrency) : 1);
    var toRate = parseFloat(t.to && t.to.exchangeRate) || (typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(toCurrency) : 1);
    var base = typeof getBaseCurrency === 'function' ? getBaseCurrency() : 'YER';
    var baseRate = typeof getRate === 'function' ? getRate(base) : 1;
    var fromBase = fromAmount * fromRate / (baseRate || 1);
    var toBase = toAmount * toRate / (baseRate || 1);
    if (!(fromBase > 0) || !(toBase > 0)) return null;

    var fromAcc = fromType === 'cashbox' ? '1000' : '1010';
    var toAcc = toType === 'cashbox' ? '1000' : '1010';
    var lines = [
        { accountCode: toAcc, accountName: ACCOUNTS[toAcc].name, debit: toBase, credit: 0 },
        { accountCode: fromAcc, accountName: ACCOUNTS[fromAcc].name, debit: 0, credit: fromBase }
    ];
    var difference = toBase - fromBase;
    if (Math.abs(difference) > 0.000001) {
        if (difference < 0) lines.push({ accountCode: '7000', accountName: ACCOUNTS['7000'].name, debit: -difference, credit: 0 });
        else lines.push({ accountCode: '4200', accountName: ACCOUNTS['4200'].name, debit: 0, credit: difference });
    }
    return _buildEntry('transfer', t.id || t.number, t.date,
        'تحويل داخلي ' + (t.number || ''), base, lines, 1);
}


// ================================================================
// ===== 11. قيود حركة مباشرة =====
// ================================================================

function _entryFromDirect(d) {
    if (!d || !d.amount) return null;

    var currency = d.currency || 'YER';
    var amount = parseFloat(d.amount) || 0;
    if (amount <= 0) return null;

    var accountCode = d.account === 'bank' ? '1010' : '1000';
    var accountName = ACCOUNTS[accountCode].name;

    var direction = d.direction || 'in'; // افتراضي: إيداع
    var type = d.type || 'رأس المال';

    var lines = [];

    // ===== تحديد الحساب المقابل حسب النوع =====
    var counterAccountCode = '3000'; // رأس المال (افتراضي)
    var counterAccountName = ACCOUNTS['3000'].name;

    if (type === 'رأس المال' || type === 'رصيد أول المدة' || type === 'تمويل من المالك' || type === 'إيداع مباشر آخر') {
        counterAccountCode = '3000';
        counterAccountName = ACCOUNTS['3000'].name;
    } else if (type === 'قرض مستلم' || type === 'سداد قرض') {
        counterAccountCode = '2000';
        counterAccountName = ACCOUNTS['2000'].name;
    } else if (type === 'بيع مستهلكات / خردة' || type === 'إيرادات متنوعة') {
        counterAccountCode = '4100';
        counterAccountName = ACCOUNTS['4100'].name;
    } else if (type === 'سحب شخصي' || type === 'سحب متنوع') {
        counterAccountCode = '3000';
        counterAccountName = ACCOUNTS['3000'].name;
    }

    // ===== بناء القيد حسب الاتجاه =====
    if (direction === 'in') {
        // إيداع: مدين الصندوق/البنك، دائن الحساب المقابل
        lines = [
            { accountCode: accountCode, accountName: accountName, debit: amount, credit: 0 },
            { accountCode: counterAccountCode, accountName: counterAccountName, debit: 0, credit: amount }
        ];
    } else {
        // سحب: مدين الحساب المقابل، دائن الصندوق/البنك
        lines = [
            { accountCode: counterAccountCode, accountName: counterAccountName, debit: amount, credit: 0 },
            { accountCode: accountCode, accountName: accountName, debit: 0, credit: amount }
        ];
    }

    var typeLabel = direction === 'in' ? 'إيداع' : 'سحب';

    return _buildEntry(
        'direct',
        d.id,
        d.date,
        typeLabel + ': ' + type + (d.note ? ' — ' + d.note : ''),
        currency,
        lines,
        d.exchangeRate
    );
}


// ================================================================
// ===== 12. قيود تسويات المخزون اليدوية =====
// ================================================================
function _entryFromStockAdjustment(m) {
    if (!m || !m.docType || !m.qty) return null;
    var allowed = ['سند إدخال (بدون فاتورة)', 'سند إخراج (استخدام داخلي)', 'سند إتلاف', 'عينة (للتسويق)'];
    if (allowed.indexOf(m.docType) === -1) return null;
    var p = typeof products !== 'undefined' ? products.find(function(x) { return x.id === m.productId; }) : null;
    var unitCost = (typeof getProductAverageCost === 'function' ? getProductAverageCost(p) : parseFloat(m.price)) || 0;
    var amount = (parseFloat(m.qty) || 0) * unitCost;
    if (!(amount > 0)) return null;
    // ✅ القيمة محسوبة بالـ SAR — العملة الأساسية
var currency = 'SAR';
    var rate = m.exchangeRate || (typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(currency) : 1);
    if (m.type === 'in') {
        return _buildEntry('stock_adjustment_in', m.id, m.date, 'تسوية مخزون — ' + m.docType, currency, [
            { accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: amount, credit: 0 },
            { accountCode: '3000', accountName: ACCOUNTS['3000'].name, debit: 0, credit: amount }
        ], rate);
    }
    return _buildEntry('stock_adjustment_out', m.id, m.date, 'تسوية مخزون — ' + m.docType, currency, [
        { accountCode: '6000', accountName: ACCOUNTS['6000'].name, debit: amount, credit: 0 },
        { accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: 0, credit: amount }
    ], rate);
}

// ================================================================
// ===== 12. قيود المرتجعات =====
// ================================================================
function _entryFromReturn(ret) {
    if (!ret || !ret.amount || !ret.invoiceId) return null;
    if (ret.cancelled === true || ret.documentStatus === 'cancelled') return null;
    var amount = parseFloat(ret.amount) || 0;
    if (amount <= 0) return null;
    var currency = ret.currency || 'YER';
    var inv = ret.kind === 'sale'
        ? (typeof salesInvoices !== 'undefined' ? salesInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null)
        : (typeof purchaseInvoices !== 'undefined' ? purchaseInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null);
    if (!inv) return null;
    // ✅ قرار المحاسب 05: المرتجع يُسجَّل دائماً على حساب الطرف
var settlement = ret.kind === 'sale' ? '1100' : '2000';
    var lines;
    if (ret.kind === 'sale') {
        lines = [
            { accountCode: '4010', accountName: ACCOUNTS['4010'].name, debit: amount, credit: 0 },
            { accountCode: settlement, accountName: ACCOUNTS[settlement].name, debit: 0, credit: amount }
        ];
        var returnCogs = parseFloat(ret.cogsAmount) || 0;
        if (returnCogs > 0) {
            lines.push({ accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: returnCogs, credit: 0 });
            lines.push({ accountCode: '5000', accountName: ACCOUNTS['5000'].name, debit: 0, credit: returnCogs });
        }
    } else {
        lines = [
            { accountCode: settlement, accountName: ACCOUNTS[settlement].name, debit: amount, credit: 0 },
            { accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: 0, credit: amount }
        ];
    }
    return _buildEntry('return_' + ret.kind, ret.id, ret.date,
        (ret.kind === 'sale' ? 'مرتجع مبيعات — ' : 'مرتجع مشتريات — ') + ret.invoiceId,
        currency, lines, ret.exchangeRate,
        { referenceType: 'return_' + ret.kind });
}


function _entryFromReturnCancellation(ret) {
    if (!ret || !ret.amount || !ret.invoiceId) return null;
    if (ret.cancelled !== true && ret.documentStatus !== 'cancelled') return null;

    var amount = parseFloat(ret.amount) || 0;
    if (amount <= 0) return null;

    var currency = ret.currency || 'YER';
    var inv = ret.kind === 'sale'
        ? (typeof salesInvoices !== 'undefined' ? salesInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null)
        : (typeof purchaseInvoices !== 'undefined' ? purchaseInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null);
    if (!inv) return null;

    // ✅ قرار المحاسب 05: المرتجع يُسجَّل دائماً على حساب الطرف
    var settlement = ret.kind === 'sale' ? '1100' : '2000';
    var lines;

    if (ret.kind === 'sale') {
        // عكس مرتجع المبيعات: مدين الصندوق/العملاء، دائن مردودات المبيعات.
        lines = [
            { accountCode: settlement, accountName: ACCOUNTS[settlement].name, debit: amount, credit: 0 },
            { accountCode: '4010', accountName: ACCOUNTS['4010'].name, debit: 0, credit: amount }
        ];

        var returnCogs = parseFloat(ret.cogsAmount) || 0;
        if (returnCogs > 0) {
            // عكس إعادة المخزون: مدين COGS، دائن المخزون.
            lines.push({ accountCode: '5000', accountName: ACCOUNTS['5000'].name, debit: returnCogs, credit: 0 });
            lines.push({ accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: 0, credit: returnCogs });
        }
    } else {
        // عكس مرتجع الشراء: مدين المخزون، دائن الصندوق/الموردين.
        lines = [
            { accountCode: '1200', accountName: ACCOUNTS['1200'].name, debit: amount, credit: 0 },
            { accountCode: settlement, accountName: ACCOUNTS[settlement].name, debit: 0, credit: amount }
        ];
    }

    return _buildEntry(
        'return_' + ret.kind + '_cancellation',
        'cancel:return:' + ret.id,
        (ret.cancelledAt || ret.date || '').substring(0, 10),
        (ret.kind === 'sale' ? 'إلغاء مرتجع مبيعات — ' : 'إلغاء مرتجع مشتريات — ') + ret.id,
        currency,
        lines,
        ret.exchangeRate,
        {
            referenceType: 'return_' + ret.kind + '_cancellation',
            reversalOf: ret.id
        }
    );
}

// ================================================================
// ===== 12. قيود سند إنتاج =====
// ================================================================

function _entryFromProduction(doc) {
    if (!doc || !doc.productionCost) return null;
    // لا نُنشئ قيد لسند إنتاج ملغى
    if (doc.cancelled === true || doc.documentStatus === 'cancelled') return null;
    var cost = parseFloat(doc.productionCost) || 0;
    if (cost <= 0) return null;

    var lines = [
        { accountCode: '1200', accountName: ACCOUNTS['1200'].name + ' (منتج تام)', debit: cost, credit: 0 },
        { accountCode: '1200', accountName: ACCOUNTS['1200'].name + ' (مواد خام)', debit: 0, credit: cost }
    ];

    return _buildEntry('production', doc.id, doc.date,
        'سند إنتاج — ' + (doc.productName || ''), doc.currency || 'YER', lines, doc.exchangeRate);
}

// ================================================================
// ===== 12-b. قيود إلغاء سند الإنتاج =====
// ================================================================

function _entryFromProductionCancellation(doc) {
    if (!doc || !doc.productionCost) return null;
    
    // نُنشئ القيد العكسي فقط إذا كان السند ملغى
    if (doc.cancelled !== true && doc.documentStatus !== 'cancelled') return null;
    
    var cost = parseFloat(doc.productionCost) || 0;
    if (cost <= 0) return null;

    // عكس قيد الإنتاج الأصلي:
    // الأصلي: مدين مخزون (منتج تام) / دائن مخزون (مواد خام)
    // العكسي: مدين مخزون (مواد خام) / دائن مخزون (منتج تام)
    var lines = [
        { 
            accountCode: '1200', 
            accountName: ACCOUNTS['1200'].name + ' (مواد خام)', 
            debit: cost, 
            credit: 0 
        },
        { 
            accountCode: '1200', 
            accountName: ACCOUNTS['1200'].name + ' (منتج تام)', 
            debit: 0, 
            credit: cost 
        }
    ];

    return _buildEntry(
        'production_cancellation',
        'cancel:production:' + doc.id,
        (doc.cancelledAt || doc.date || '').substring(0, 10),
        'إلغاء سند إنتاج — ' + (doc.productName || ''),
        doc.currency || 'YER',
        lines,
        doc.exchangeRate,
        {
            referenceType: 'production_cancellation',
            reversalOf: doc.id
        }
    );
}


// ================================================================
// ===== 13. توليد كل القيود =====
// ================================================================

function generateAllJournalEntries() {
    var previousEntries = Array.isArray(journalEntries) ? journalEntries.slice() : [];
    var previousByKey = {};

    previousEntries.forEach(function(oldEntry) {
        previousByKey[String(oldEntry.type || '') + '|' + String(oldEntry.referenceId || '')] = oldEntry;
    });

    // لا نحذف القيود السابقة؛ القيد المرحّل سجل تاريخي.
    var rebuiltEntries = previousEntries.slice();

    function addEntry(entry) {
        if (!entry) return;
        var key = String(entry.type || '') + '|' + String(entry.referenceId || '');
        if (previousByKey[key]) {
            // نحتفظ بالقيد التاريخي، ونستكمل الحقول الوصفية فقط.
            var historicalEntry = previousByKey[key];
            if (!historicalEntry.referenceType && entry.referenceType) {
                historicalEntry.referenceType = entry.referenceType;
            }
            if (!historicalEntry.reversalOf && entry.reversalOf) {
                historicalEntry.reversalOf = entry.reversalOf;
            }
            if (!historicalEntry.reversalEntryId) {
                historicalEntry.reversalEntryId = entry.reversalEntryId || null;
            }
            return;
        }
        rebuiltEntries.push(entry);
    }

    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
        salesInvoices.forEach(function(inv) { addEntry(_entryFromSalesInvoice(inv)); });
        salesInvoices.forEach(function(inv) { addEntry(_entryFromInvoiceCancellation(Object.assign({ kind: 'sale' }, inv))); });
    }
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
        purchaseInvoices.forEach(function(inv) { addEntry(_entryFromPurchaseInvoice(inv)); });
        purchaseInvoices.forEach(function(inv) { addEntry(_entryFromInvoiceCancellation(Object.assign({ kind: 'purchase' }, inv))); });
    }
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(rec) {
            addEntry(_entryFromReceipt(rec));
            addEntry(_entryFromReceiptCancellation(rec));
        });
    }
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(pay) {
            if (pay.archived) return;
            addEntry(_entryFromPayment(pay));
            addEntry(_entryFromPaymentCancellation(pay));
        });
    }
    if (typeof transfers !== 'undefined' && Array.isArray(transfers)) {
        transfers.forEach(function(transfer) { addEntry(_entryFromTransfer(transfer)); });
    }
    if (typeof directTransactions !== 'undefined' && Array.isArray(directTransactions)) {
        directTransactions.forEach(function(transaction) { addEntry(_entryFromDirect(transaction)); });
    }
if (typeof productionDocs !== 'undefined' && Array.isArray(productionDocs)) {
    productionDocs.forEach(function(doc) { 
        addEntry(_entryFromProduction(doc)); 
        addEntry(_entryFromProductionCancellation(doc));
    });
}
    if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        returnsDocs.forEach(function(ret) {
            addEntry(_entryFromReturn(ret));
            addEntry(_entryFromReturnCancellation(ret));
        });
    }
    if (typeof stockMovements !== 'undefined' && Array.isArray(stockMovements)) {
        stockMovements.forEach(function(movement) { addEntry(_entryFromStockAdjustment(movement)); });
    }

    journalEntries = rebuiltEntries;
    journalEntries.sort(function(a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
    });

    linkJournalEntriesToDocuments();
    saveJournal();
    return journalEntries.length;
}


function linkJournalEntriesToDocuments() {
    var entries = Array.isArray(journalEntries) ? journalEntries : [];

    function findOriginalEntry(referenceId, referenceType) {
        return entries.find(function(entry) {
            return entry.referenceId === referenceId &&
                (!referenceType || entry.referenceType === referenceType) &&
                !entry.reversalOf;
        });
    }

    function findReversalEntry(originalId, cancellationType) {
        return entries.find(function(entry) {
            return entry.reversalOf === originalId &&
                (!cancellationType || entry.type === cancellationType);
        });
    }

    function linkDocument(documentObject, originalType, cancellationType, saveFunction) {
        if (!documentObject || !documentObject.id) return;

        var originalEntry = findOriginalEntry(documentObject.id, originalType);
        var reversalEntry = findReversalEntry(documentObject.id, cancellationType);

        if (originalEntry) {
            documentObject.journalEntryId = originalEntry.id;
            originalEntry.reversalEntryId = reversalEntry ? reversalEntry.id : null;
        }
        documentObject.reversalEntryId = reversalEntry ? reversalEntry.id : null;

        if (typeof saveFunction === 'function') saveFunction();
    }

    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)) {
        salesInvoices.forEach(function(invoice) {
            linkDocument(invoice, 'sales_invoice', 'invoice_cancellation',
                typeof saveSalesInvoices === 'function' ? saveSalesInvoices : null);
        });
    }
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
        purchaseInvoices.forEach(function(invoice) {
            linkDocument(invoice, 'purchase_invoice', 'invoice_cancellation',
                typeof savePurchaseInvoices === 'function' ? savePurchaseInvoices : null);
        });
    }
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
        receipts.forEach(function(receipt) {
            var receiptType = receipt.receiptType === 'supplier_refund' ? 'supplier_refund' : 'receipt';
            linkDocument(receipt, receiptType, 'receipt_cancellation',
                typeof saveReceipts === 'function' ? saveReceipts : null);
        });
    }
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(payment) {
            var paymentType = payment.paymentType === 'customer_refund'
                ? 'customer_refund'
                : (payment.isExpense ? 'expense' : 'payment');
            linkDocument(payment, paymentType, 'payment_cancellation',
                typeof savePayments === 'function' ? savePayments : null);
        });
    }
    if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        returnsDocs.forEach(function(ret) {
            linkDocument(ret, 'return_' + ret.kind, 'return_' + ret.kind + '_cancellation',
                typeof saveReturns === 'function' ? saveReturns : null);
        });
    }
}

// ================================================================
// ===== 14. إعادة توليد (مع تأكيد) =====
// ================================================================

function regenerateAllJournalEntries() {
    if (!confirm('سيتم إعادة توليد كل القيود من المستندات.\nالقيود القديمة ستُحذف.\n\nهل أنت متأكد؟')) return;

    var count = generateAllJournalEntries();
    showToast('تم توليد ' + count + ' قيد', 'success');
    renderJournal();
}


// ================================================================
// ===== 15. تصفير العداد وإعادة الترقيم =====
// ================================================================

function resetJournalCounter() {
    if (!confirm('سيتم تصفير عداد أرقام القيود وإعادة ترقيم القيود الحالية.\n\nهل أنت متأكد؟')) return;

    Storage.set(JOURNAL_COUNTER_KEY, 0);

    journalEntries.forEach(function(e) {
        e.id = _generateJournalNumber();
    });

    saveJournal();
    renderJournal();
    showToast('تم تصفير العداد وإعادة الترقيم', 'success');
}


// ================================================================
// ===== 16. عرض القيود =====
// ================================================================

// ================================================================
// ===== 16. عرض القيود (بطاقات) =====
// ================================================================

function renderJournal() {
    var container = document.getElementById('journalTableBody');
    if (!container) return;
// ✅ وضع العرض: آخر 20 قيد (افتراضي) أو الكل
if (typeof _journalShowAll === 'undefined') {
    window._journalShowAll = false;
}
    // القيود تُولّد عند التهيئة أو بعد كل تعديل، ولا نعيد توليدها أثناء العرض.

    var fromEl = document.getElementById('journalFrom');
    var toEl = document.getElementById('journalTo');
    var typeEl = document.getElementById('journalFilterType');
    var currencyEl = document.getElementById('journalFilterCurrency');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';
    var filterType = typeEl ? typeEl.value : '';
    var filterCurrency = currencyEl ? currencyEl.value : '';

    var filtered = journalEntries.filter(function(e) {
    if (from && e.date < from) return false;
    if (to && e.date > to) return false;
    if (filterType && e.type !== filterType) return false;
    if (filterCurrency && e.currency !== filterCurrency) return false;
    return true;
});

filtered.sort(function(a, b) {
    return String(b.date || '').localeCompare(String(a.date || ''));
});

// ✅ عرض آخر 20 قيد (افتراضي) أو الكل
var totalCount = filtered.length;
// ✅ slice إذا كان الفلتر على القيم الافتراضية (أول الشهر → اليوم)
var defaultFrom = (typeof firstDayOfMonthISO === 'function') ? firstDayOfMonthISO() : '';
var defaultTo = (typeof todayISO === 'function') ? todayISO() : '';
var isDefaultFilter = (!from || from === defaultFrom) && (!to || to === defaultTo);

if (!window._journalShowAll && isDefaultFilter && !filterType && !filterCurrency) {
    filtered = filtered.slice(0, 20);
}

    if (!filtered.length) {
        container.innerHTML = '<div class="empty-cell" style="padding:30px;text-align:center;color:var(--color-text-3);">لا توجد قيود في الفترة المحددة</div>';
        _updateJournalStats();
        return;
    }

    var html = '';
    
    // ✅ شريط حالة العرض + زر "عرض الكل"
    if (totalCount > 20 && !from && !to && !filterType && !filterCurrency) {
        html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 12px;background:rgba(0,212,255,0.08);border:1px solid rgba(0,212,255,0.25);border-radius:8px;margin-bottom:10px;gap:8px;flex-wrap:wrap;">' +
            '<span style="font-size:12px;color:var(--color-text-2);">' +
                (window._journalShowAll
                    ? 'عرض كل القيود (' + totalCount + ')'
                    : 'عرض آخر 20 قيد (من أصل ' + totalCount + ')') +
            '</span>' +
            '<button class="btn btn-secondary" onclick="toggleJournalShowAll()" style="font-size:11px;padding:6px 12px;">' +
                (window._journalShowAll ? 'عرض آخر 20' : 'عرض الكل') +
            '</button>' +
        '</div>';
    }

html += '<div style="display:flex;flex-direction:column;gap:14px;padding:12px;">';

var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'YER';

filtered.forEach(function(e, idx) {
    var entryDebit = 0, entryCredit = 0;
    (e.lines || []).forEach(function(l) {
        entryDebit += parseFloat(l.debit) || 0;
        entryCredit += parseFloat(l.credit) || 0;
    });

    var entryCurrency = e.currency || 'YER';
    var needsConversion = (entryCurrency !== baseCurrency);

        // بطاقة القيد
        html += '<div class="journal-card" style="background:var(--color-surface);border:1px solid var(--color-border);border-radius:10px;overflow:hidden;">';

     // رأس البطاقة
        html += '<div style="background:linear-gradient(135deg, #1f6feb, #1454aa);color:#fff;padding:10px 12px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">' +
            '<div style="display:flex;align-items:center;gap:10px;">' +
                '<span style="font-weight:800;font-size:14px;">' + esc(e.id) + '</span>' +
                '<span style="font-size:11px;opacity:0.85;">' + formatDate(e.date) + '</span>' +
            '</div>' +
            '<div style="display:flex;align-items:center;gap:8px;">' +
                '<span style="background:rgba(255,255,255,0.2);padding:3px 8px;border-radius:12px;font-size:11px;">' + esc(e.currency) + '</span>' +
                '<span style="background:rgba(255,255,255,0.15);padding:3px 8px;border-radius:12px;font-size:11px;">' + esc(_journalTypeLabel(e.type)) + '</span>' +
               '<button class="btn-view" onclick="viewJournalEntry(\'' + e.id + '\')" title="معاينة" style="width:32px;height:32px;border-radius:8px;background:#ffffff;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;">' +
    '<svg viewBox="0 0 24 24" fill="none" style="width:18px;height:18px;" stroke="#1f6feb">' +
        '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" stroke="#1f6feb" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' +
        '<circle cx="12" cy="12" r="3" stroke="#1f6feb" stroke-width="2"/>' +
    '</svg>' +
'</button>' +
            '</div>' +
        '</div>';

        // البيان
        html += '<div style="padding:10px 12px;background:rgba(255,255,255,0.03);border-bottom:1px solid var(--color-border);">' +
            '<div style="font-size:13px;color:var(--color-text);text-align:right;">' + esc(e.description) + '</div>' +
        '</div>';

        // السطور
        html += '<div style="padding:0;">';

        (e.lines || []).forEach(function(l) {
            var isDebit = (parseFloat(l.debit) || 0) > 0;
            var amount = isDebit ? (parseFloat(l.debit) || 0) : (parseFloat(l.credit) || 0);

            html += '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 12px;border-bottom:1px solid rgba(255,255,255,0.04);gap:8px;">' +
                '<div style="text-align:right;flex:1;min-width:0;">' +
                    '<div style="font-size:13px;font-weight:700;color:var(--color-text);">' +
                        esc(l.accountName || '-') +
                    '</div>' +
                    '<div style="font-size:10px;color:var(--color-text-3);font-family:monospace;">' +
                        esc(l.accountCode || '-') +
                    '</div>' +
                '</div>' +
                 '<div style="text-align:left;flex-shrink:0;">' +
        '<div style="font-size:10px;color:' + (isDebit ? 'var(--color-red)' : 'var(--color-green)') + ';opacity:0.7;">' +
            (isDebit ? 'مدين' : 'دائن') +
        '</div>' +
        '<div style="font-size:13px;font-weight:800;color:' + (isDebit ? 'var(--color-red)' : 'var(--color-green)') + ';">' +
            formatAmountWithCommas(amount) +
        '</div>' +
        (needsConversion && (
            (isDebit && l.debitBase !== undefined && Math.abs(l.debitBase - amount) > 0.0001) ||
            (!isDebit && l.creditBase !== undefined && Math.abs(l.creditBase - amount) > 0.0001)
        ) ?
            '<div style="font-size:10px;color:var(--color-text-3);font-weight:600;">' +
                '≈ ' + formatAmountWithCommas(isDebit ? (l.debitBase || 0) : (l.creditBase || 0)) + ' ' + baseCurrency +
            '</div>'
        : '') +
    '</div>' +
'</div>';
        });

        html += '</div>';

        // تذييل البطاقة: الإجماليات
        html += '<div style="padding:8px 12px;background:rgba(0,0,0,0.15);display:flex;justify-content:space-between;font-size:12px;font-weight:700;">' +
            '<div style="display:flex;gap:14px;">' +
                '<span style="color:var(--color-text-2);">مدين: <span style="color:var(--color-red);">' + formatAmountWithCommas(entryDebit) + '</span></span>' +
                '<span style="color:var(--color-text-2);">دائن: <span style="color:var(--color-green);">' + formatAmountWithCommas(entryCredit) + '</span></span>' +
            '</div>' +
            '<div style="color:' + (Math.abs(entryDebit - entryCredit) < 0.01 ? 'var(--color-green)' : 'var(--color-red)') + ';">' +
                (Math.abs(entryDebit - entryCredit) < 0.01 ? '✅ متوازن' : '⚠ غير متوازن') +
            '</div>' +
        '</div>';

        html += '</div>'; // نهاية البطاقة
    });

    html += '</div>';

    container.innerHTML = html;
    _updateJournalStats();
}

// ================================================================
// ===== 17. إحصائيات =====
// ================================================================

function _updateJournalStats() {
    var fromEl = document.getElementById('journalFrom');
    var toEl = document.getElementById('journalTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    var filtered = journalEntries.filter(function(e) {
        if (from && e.date < from) return false;
        if (to && e.date > to) return false;
        return true;
    });

    var sumDebit = 0, sumCredit = 0;
filtered.forEach(function(e) {
    (e.lines || []).forEach(function(l) {
        // ✅ استخدام القيمة بالعملة الأساسية (تاريخية)
        // إذا لم تكن موجودة → fallback للقيمة الأصلية
        var debitBase = (l.debitBase !== undefined && l.debitBase !== null)
            ? parseFloat(l.debitBase) || 0
            : parseFloat(l.debit) || 0;
        var creditBase = (l.creditBase !== undefined && l.creditBase !== null)
            ? parseFloat(l.creditBase) || 0
            : parseFloat(l.credit) || 0;
        
        sumDebit += debitBase;
        sumCredit += creditBase;
    });
});

    setText('journalCount', filtered.length);
    setText('journalTotalDebit', formatAmountWithCommas(sumDebit));
    setText('journalTotalCredit', formatAmountWithCommas(sumCredit));

    var balanceEl = document.getElementById('journalBalance');
    if (balanceEl) {
        var diff = Math.abs(sumDebit - sumCredit);
        if (diff < 0.01) {
            balanceEl.textContent = '✅ متوازن';
            balanceEl.style.color = 'var(--color-green)';
        } else {
            balanceEl.textContent = '⚠ فرق ' + formatAmountWithCommas(diff);
            balanceEl.style.color = 'var(--color-red)';
        }
    }
}


// ================================================================
// ===== 18. تسمية النوع =====
// ================================================================

function _journalTypeLabel(type) {
    var map = {
        'sales_invoice': 'فاتورة بيع',
        'purchase_invoice': 'فاتورة شراء',
        'invoice_cancellation': 'إلغاء فاتورة',
        'receipt': 'سند قبض',
        'receipt_cancellation': 'إلغاء سند قبض',
        'payment': 'سند صرف',
        'payment_cancellation': 'إلغاء سند صرف',
          'expense': 'مصروف',
        'expense': 'مصروف',
        'transfer': 'تحويل داخلي',
        'production': 'سند إنتاج',
        'production_cancellation': 'إلغاء سند إنتاج',
        'return_sale': 'مرتجع مبيعات',
        'return_sale_cancellation': 'إلغاء مرتجع مبيعات',
        'return_purchase': 'مرتجع مشتريات',
        'return_purchase_cancellation': 'إلغاء مرتجع مشتريات',
        'stock_adjustment_in': 'تسوية مخزون (إدخال)',
        'stock_adjustment_out': 'تسوية مخزون (إخراج)',
        'direct': 'حركة مباشرة'
    };
    return map[type] || type || '-';
}

// ================================================================
// ===== 19. تصدير PDF =====
// ================================================================

function exportJournalPDF() {
    var tbody = document.getElementById('journalTableBody');
    if (!tbody) return showToast('لا يوجد شيء لعرضه', 'error');

    // التحقق من وجود قيود فعلاً
    var fromEl = document.getElementById('journalFrom');
    var toEl = document.getElementById('journalTo');
    var typeEl = document.getElementById('journalFilterType');
    var currencyEl = document.getElementById('journalFilterCurrency');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';
    var filterType = typeEl ? typeEl.value : '';
    var filterCurrency = currencyEl ? currencyEl.value : '';

    var filtered = (typeof journalEntries !== 'undefined' ? journalEntries : []).filter(function(e) {
        if (from && e.date < from) return false;
        if (to && e.date > to) return false;
        if (filterType && e.type !== filterType) return false;
        if (filterCurrency && e.currency !== filterCurrency) return false;
        return true;
    });

    if (!filtered.length) {
        return showToast('لا توجد قيود في الفترة المحددة', 'error');
    }

    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';

    // ===== بناء جدول PDF =====
    var tableHtml = '<table class="doc-table" style="width:100%;border-collapse:collapse;font-size:11px;">';
    tableHtml += '<thead><tr>' +
        '<th>#</th>' +
        '<th>رقم القيد</th>' +
        '<th>التاريخ</th>' +
        '<th>النوع</th>' +
        '<th>البيان</th>' +
        '<th>العملة</th>' +
        '<th>مدين</th>' +
        '<th>دائن</th>' +
    '</tr></thead><tbody>';

    var totalDebit = 0;
    var totalCredit = 0;

    filtered.forEach(function(e, idx) {
        var entryDebit = 0;
        var entryCredit = 0;
        (e.lines || []).forEach(function(l) {
            entryDebit += parseFloat(l.debit) || 0;
            entryCredit += parseFloat(l.credit) || 0;
        });
        totalDebit += entryDebit;
        totalCredit += entryCredit;

        // صف رأس القيد
        tableHtml += '<tr style="background:#eef4fb;font-weight:700;">' +
            '<td>' + (idx + 1) + '</td>' +
            '<td>' + esc(e.id) + '</td>' +
            '<td>' + esc(e.date) + '</td>' +
            '<td>' + esc(_journalTypeLabel(e.type)) + '</td>' +
            '<td style="text-align:right;">' + esc(e.description) + '</td>' +
            '<td>' + esc(e.currency) + '</td>' +
            '<td style="color:#c0392b;">' + formatAmountWithCommas(entryDebit) + '</td>' +
            '<td style="color:#27ae60;">' + formatAmountWithCommas(entryCredit) + '</td>' +
        '</tr>';

        // صفوف الحسابات
        (e.lines || []).forEach(function(l) {
            var debitText = (parseFloat(l.debit) > 0) ? formatAmountWithCommas(l.debit) : '—';
            var creditText = (parseFloat(l.credit) > 0) ? formatAmountWithCommas(l.credit) : '—';
            tableHtml += '<tr style="font-size:10px;">' +
                '<td></td>' +
                '<td style="font-family:monospace;">' + esc(l.accountCode || '') + '</td>' +
                '<td colspan="3" style="text-align:right;padding-right:14px;">' + esc(l.accountName || '') + '</td>' +
                '<td></td>' +
                '<td>' + debitText + '</td>' +
                '<td>' + creditText + '</td>' +
            '</tr>';
        });
    });

    tableHtml += '<tr style="background:#f0f2f5;font-weight:800;border-top:2px solid #1a1a2e;">' +
        '<td colspan="6" style="text-align:right;padding-right:12px;">الإجماليات</td>' +
        '<td style="color:#c0392b;">' + formatAmountWithCommas(totalDebit) + '</td>' +
        '<td style="color:#27ae60;">' + formatAmountWithCommas(totalCredit) + '</td>' +
    '</tr>';

    tableHtml += '</tbody></table>';

    // ===== بناء المستند =====
    var metaHtml = '<div class="doc-meta-grid">' +
        '<div><strong>من:</strong> ' + (from || 'البداية') + '</div>' +
        '<div><strong>إلى:</strong> ' + (to || 'اليوم') + '</div>' +
        '<div><strong>عدد القيود:</strong> ' + filtered.length + '</div>' +
        '<div><strong>تاريخ الإصدار:</strong> ' + todayISO() + '</div>' +
    '</div>';

    var html = '<div class="doc-wrapper">' +
        '<div class="doc-header"><div class="company-name">' + esc(companyName) + '</div></div>' +
        '<div class="doc-title">دفتر اليومية</div>' +
        metaHtml +
        tableHtml +
        '<div class="doc-footer">دفتر يومية — قيود مزدوجة<small>هذا المستند معتمد رقمياً</small></div>' +
    '</div>';

    Modal.open({
        id: 'journalPrintModal',
        title: 'معاينة دفتر اليومية',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer:
            '<button class="btn btn-cancel" onclick="closeModal(\'journalPrintModal\')">إغلاق</button>' +
            '<button class="btn btn-primary" onclick="_printCurrentDoc()">طباعة / PDF</button>'
    });
}


// ================================================================
// ===== 20. تهيئة =====
// ================================================================

function syncJournalAfterMutation() {
    try {
        if (typeof generateAllJournalEntries === 'function') {
            generateAllJournalEntries();
            if (typeof renderJournal === 'function') renderJournal();
        }
        if (typeof updateDashboard === 'function') updateDashboard();
        if (typeof updateTrialBalance === 'function') updateTrialBalance();
        if (typeof renderGeneralLedger === 'function') renderGeneralLedger();
    } catch (e) { console.error('Journal sync error:', e); }
}

function auditAccountingIntegrity() {
    var entries = typeof journalEntries !== 'undefined'
        ? journalEntries
        : Storage.get(JOURNAL_KEY, []);
    var issues = [];
    var totalDebit = 0;
    var totalCredit = 0;
    var tolerance = 0.000001;

    (entries || []).forEach(function(entry) {
        var debitBaseTotal = 0;
        var creditBaseTotal = 0;
        var debitTotal = 0;
        var creditTotal = 0;

        (entry.lines || []).forEach(function(line) {
            var debit = parseFloat(line.debit) || 0;
            var credit = parseFloat(line.credit) || 0;
            var debitBase = line.debitBase !== undefined ? (parseFloat(line.debitBase) || 0) : debit;
            var creditBase = line.creditBase !== undefined ? (parseFloat(line.creditBase) || 0) : credit;

            debitTotal += debit;
            creditTotal += credit;
            debitBaseTotal += debitBase;
            creditBaseTotal += creditBase;

            if (debit > 0 && credit > 0) {
                issues.push('سطر يحتوي مدينًا ودائنًا معًا: ' + entry.id + ' / ' + (line.accountCode || '-'));
            }
        });

        totalDebit += debitBaseTotal;
        totalCredit += creditBaseTotal;

        if (Math.abs(debitTotal - creditTotal) > tolerance) {
            issues.push('قيد غير متوازن بالعملة الأصلية: ' + entry.id + ' — المدين: ' + debitTotal + ' — الدائن: ' + creditTotal);
        }
        if (Math.abs(debitBaseTotal - creditBaseTotal) > tolerance) {
            issues.push('قيد غير متوازن بالعملة الأساسية: ' + entry.id + ' — المدين الأساسي: ' + debitBaseTotal + ' — الدائن الأساسي: ' + creditBaseTotal);
        }
        if (!entry.referenceId) issues.push('القيد بلا referenceId: ' + entry.id);
        if (!entry.referenceType) issues.push('القيد بلا referenceType: ' + entry.id);
    });

    // فحوص مستندات التسوية: المصدر، النوع، وعدم التكرار
    var refundSources = {};
    if (typeof payments !== 'undefined' && Array.isArray(payments)) payments.forEach(function(pay) {
        if (pay.paymentType !== 'customer_refund' || pay.cancelled || pay.documentStatus === 'cancelled') return;
        if (pay.invoiceId !== '-') issues.push('رد عميل يجب أن يحمل invoiceId = -: ' + pay.id);
        if (!pay.customerId || !pay.sourceReceiptId) issues.push('رد عميل بلا عميل أو سند قبض أصلي: ' + pay.id);
        var key = 'customer|' + pay.sourceReceiptId;
        refundSources[key] = (refundSources[key] || 0) + (parseFloat(pay.amount) || 0);
    });
    if (typeof receipts !== 'undefined' && Array.isArray(receipts)) receipts.forEach(function(rec) {
        if (rec.receiptType !== 'supplier_refund' || rec.cancelled || rec.documentStatus === 'cancelled') return;
        if (rec.invoiceId !== '-') issues.push('تحصيل مورد يجب أن يحمل invoiceId = -: ' + rec.id);
        if (!rec.supplierId || !rec.sourcePaymentId) issues.push('تحصيل مورد بلا مورد أو سند صرف أصلي: ' + rec.id);
        var key = 'supplier|' + rec.sourcePaymentId;
        refundSources[key] = (refundSources[key] || 0) + (parseFloat(rec.amount) || 0);
    });

    return {
        ok: issues.length === 0,
        issues: issues,
        totalDebit: totalDebit,
        totalCredit: totalCredit,
        entries: (entries || []).length
    };
}

function initJournal() {
    loadJournal();
    if (typeof generateAllJournalEntries === 'function') generateAllJournalEntries();

    var fromEl = document.getElementById('journalFrom');
    var toEl = document.getElementById('journalTo');

    // استعادة القيم المحفوظة (إن وُجدت)
    var savedFrom = localStorage.getItem('oa_journal_filter_from') || '';
    var savedTo = localStorage.getItem('oa_journal_filter_to') || '';
    var savedType = localStorage.getItem('oa_journal_filter_type') || '';
    var savedCurrency = localStorage.getItem('oa_journal_filter_currency') || '';

    if (fromEl) fromEl.value = savedFrom;
    if (toEl) toEl.value = savedTo;

    var typeEl = document.getElementById('journalFilterType');
    var currencyEl = document.getElementById('journalFilterCurrency');
    if (typeEl) typeEl.value = savedType;
    if (currencyEl) currencyEl.value = savedCurrency;

    // حفظ القيم عند التغيير
    if (fromEl && !fromEl._oaBound) {
        fromEl._oaBound = true;
        fromEl.addEventListener('change', function() {
            localStorage.setItem('oa_journal_filter_from', fromEl.value || '');
        });
    }
    if (toEl && !toEl._oaBound) {
        toEl._oaBound = true;
        toEl.addEventListener('change', function() {
            localStorage.setItem('oa_journal_filter_to', toEl.value || '');
        });
    }
    if (typeEl && !typeEl._oaBound) {
        typeEl._oaBound = true;
        typeEl.addEventListener('change', function() {
            localStorage.setItem('oa_journal_filter_type', typeEl.value || '');
        });
    }
    if (currencyEl && !currencyEl._oaBound) {
        currencyEl._oaBound = true;
        currencyEl.addEventListener('change', function() {
            localStorage.setItem('oa_journal_filter_currency', currencyEl.value || '');
        });
    }

    renderJournal();
    console.log('Journal: initialized with ' + journalEntries.length + ' entries');
}
// ================================================================
// ===== 21. مصدر الحقيقة الموحّد — الرصيد المستحق =====
// ================================================================

/**
 * الرصيد المستحق الحقيقي لفاتورة
 * = إجمالي الفاتورة − المرتجعات النشطة − المدفوعات النشطة
 */
function getInvoiceOutstanding(invoiceId, kind) {
    kind = kind || 'purchase';

    var invoiceList = (kind === 'sale')
        ? (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices) ? salesInvoices : [])
        : (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices) ? purchaseInvoices : []);

    var inv = invoiceList.find(function(x) { return x && x.id === invoiceId; });
    if (!inv) return null;

    var invoiceTotal = parseFloat(inv.total) || 0;
    var currency = inv.currency || 'SAR';

    // ===== المرتجعات النشطة =====
    var returnsList = (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs))
        ? returnsDocs.filter(function(r) {
            return r
                && r.invoiceId === invoiceId
                && r.kind === kind
                && r.cancelled !== true
                && r.documentStatus !== 'cancelled';
        })
        : [];

    var totalReturns = returnsList.reduce(function(s, r) {
        return s + (parseFloat(r.amount) || 0);
    }, 0);

    // ===== المدفوعات النشطة =====
    var paymentList = (kind === 'sale')
        ? (typeof receipts !== 'undefined' && Array.isArray(receipts) ? receipts : [])
        : (typeof payments !== 'undefined' && Array.isArray(payments) ? payments : []);

    var allPayments = paymentList.filter(function(p) {
        return p
            && p.invoiceId === invoiceId
            && !p.isExpense
            && p.paymentType !== 'customer_refund'
            && p.receiptType !== 'supplier_refund'
            && p.cancelled !== true
            && p.documentStatus !== 'cancelled'
            && p.sourceStatus !== 'cancelled';
    });

    var totalPaid = allPayments.reduce(function(s, p) {
        return s + (parseFloat(p.amount) || 0);
    }, 0);

    // ===== الحساب الصافي =====
    var netAmount = invoiceTotal - totalReturns;
    var outstanding = netAmount - totalPaid;

    var returnedRatio = invoiceTotal > 0 ? (totalReturns / invoiceTotal) : 0;
    var paidRatio = netAmount > 0 ? (totalPaid / netAmount) : 0;

    // ===== الحالة المشتقة =====
    var derivedStatus;
    if (returnedRatio >= 0.9999) {
        derivedStatus = 'fully_returned';
    } else if (outstanding < -0.01) {
        derivedStatus = 'overpaid';
    } else if (outstanding <= 0.01 && netAmount > 0 && totalPaid >= netAmount - 0.01) {
        derivedStatus = 'paid';
    } else if (totalPaid > 0 && outstanding > 0.01) {
        derivedStatus = 'partial';
    } else if (totalReturns > 0 && totalPaid === 0) {
        derivedStatus = 'partially_returned';
    } else {
        derivedStatus = 'unpaid';
    }

        var maxAllowedPayment = Math.max(0, outstanding);

    // ===== تمييز اتجاه الرصيد (مدين / صفر / دائن) =====
    var customerDebt = outstanding > 0.01 ? outstanding : 0;
    var customerCredit = outstanding < -0.01 ? Math.abs(outstanding) : 0;
    var direction = outstanding > 0.01 ? 'debit'
                  : outstanding < -0.01 ? 'credit'
                  : 'zero';

    var statusLabel = {
        'unpaid': 'غير مدفوعة',
        'partial': 'دفع جزئي',
        'paid': 'مدفوعة بالكامل',
        'partially_returned': 'مرتجع جزئي',
        'fully_returned': 'مرتجع كامل',
        'overpaid': 'رصيد دائن للعميل — مبلغ مستحق للعميل'
    }[derivedStatus] || derivedStatus;

    return {
        invoiceId: invoiceId,
        kind: kind,
        currency: currency,
        invoiceTotal: invoiceTotal,
        totalReturns: totalReturns,
        totalPaid: totalPaid,
        netAmount: netAmount,
        outstanding: outstanding,
        // حقول التمييز الجديدة
        customerDebt: customerDebt,
        customerCredit: customerCredit,
        direction: direction,
        returnedRatio: returnedRatio,
        paidRatio: paidRatio,
        derivedStatus: derivedStatus,
        statusLabel: statusLabel,
        maxAllowedPayment: maxAllowedPayment,
        returnsCount: returnsList.length,
        paymentsCount: allPayments.length,
        invoice: inv,
        returns: returnsList,
        payments: allPayments
    };
}


function getInvoiceOutstandingAmount(invoiceId, kind) {
    var o = getInvoiceOutstanding(invoiceId, kind);
    return o ? o.outstanding : 0;
}


// ================================================================
// ===== 22. تحديث returnStatus للفواتير القديمة (ترحيل) =====
// ================================================================

function migrateReturnStatus() {
    var updated = 0;

    // ===== 1. فواتير الشراء =====
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)
        && typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        
        purchaseInvoices.forEach(function(inv) {
            var totalReturned = returnsDocs
                .filter(function(r) {
                    return r.invoiceId === inv.id 
                        && r.kind === 'purchase'
                        && r.cancelled !== true 
                        && r.documentStatus !== 'cancelled';
                })
                .reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);

            var invTotal = parseFloat(inv.total) || 0;
            
            if (totalReturned > 0) {
                var newStatus = (invTotal > 0 && totalReturned >= invTotal - 0.01) ? 'full' : 'partial';
                if (inv.returnStatus !== newStatus || inv.returnedAmount !== totalReturned) {
                    inv.returnStatus = newStatus;
                    inv.returnedAmount = totalReturned;
                    updated++;
                }
            }
        });

        if (updated > 0 && typeof savePurchaseInvoices === 'function') {
            savePurchaseInvoices();
        }
    }

    // ===== 2. فواتير البيع =====
    if (typeof salesInvoices !== 'undefined' && Array.isArray(salesInvoices)
        && typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        
        salesInvoices.forEach(function(inv) {
            var totalReturned = returnsDocs
                .filter(function(r) {
                    return r.invoiceId === inv.id 
                        && r.kind === 'sale'
                        && r.cancelled !== true 
                        && r.documentStatus !== 'cancelled';
                })
                .reduce(function(s, r) { return s + (parseFloat(r.amount) || 0); }, 0);

            var invTotal = parseFloat(inv.total) || 0;
            
            if (totalReturned > 0) {
                var newStatus = (invTotal > 0 && totalReturned >= invTotal - 0.01) ? 'full' : 'partial';
                if (inv.returnStatus !== newStatus || inv.returnedAmount !== totalReturned) {
                    inv.returnStatus = newStatus;
                    inv.returnedAmount = totalReturned;
                    updated++;
                }
            }
        });

        if (updated > 0 && typeof saveSalesInvoices === 'function') {
            saveSalesInvoices();
        }
    }

    return updated;
   
}

// ✅ تبديل عرض القيود (20 / الكل)
function toggleJournalShowAll() {
    window._journalShowAll = !window._journalShowAll;
    renderJournal();
}

// ================================================================
// ===== 22. طباعة دفتر اليومية (القالب الجديد) =====
// ================================================================

function printJournalStatement() {
    // 1. اقرأ الفلاتر
    var fromEl = document.getElementById('journalFrom');
    var toEl = document.getElementById('journalTo');
    var typeEl = document.getElementById('journalFilterType');
    var currencyEl = document.getElementById('journalFilterCurrency');

    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';
    var filterType = typeEl ? typeEl.value : '';
    var filterCurrency = currencyEl ? currencyEl.value : '';

    // 2. فلترة القيود
    var filtered = journalEntries.filter(function(e) {
        if (from && e.date < from) return false;
        if (to && e.date > to) return false;
        if (filterType && e.type !== filterType) return false;
        if (filterCurrency && e.currency !== filterCurrency) return false;
        return true;
    });

    if (!filtered.length) {
        if (typeof showToast === 'function') showToast('لا توجد قيود في الفترة المحددة', 'error');
        return;
    }

    // 3. ترتيب — الأحدث أولاً
    filtered.sort(function(a, b) {
        return String(b.date || '').localeCompare(String(a.date || ''));
    });

    // 4. الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // 5. العملة الأساسية
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

    // 6. حفظ الحمولة
    var payload = {
        type: 'journal_report',
        entries: filtered,
        settings: settings,
        meta: {
            from: from || '—',
            to: to || '—',
            typeLabel: filterType ? _journalTypeLabel(filterType) : 'الكل',
            currencyLabel: filterCurrency || 'الكل',
            baseCurrency: baseCurrency
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // 7. افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/journal-report-v2.html';
    window.location.href = url;
}
// ================================================================
// ===== معاينة قيد فردي =====
// ================================================================

function viewJournalEntry(entryId) {
    if (!entryId) return;

    // ابحث عن القيد
    var entry = null;
    if (typeof journalEntries !== 'undefined' && Array.isArray(journalEntries)) {
        entry = journalEntries.find(function(e) { return e.id === entryId; });
    }
    if (!entry) {
        if (typeof showToast === 'function') showToast('القيد غير موجود', 'error');
        return;
    }

    // الإعدادات
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // العملة الأساسية
    var baseCurrency = (typeof getBaseCurrency === 'function') ? getBaseCurrency() : 'SAR';

    // الحمولة
    var payload = {
        type: 'journal_entry',
        doc: entry,
        settings: settings,
        meta: {
            baseCurrency: baseCurrency
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

       // احفظ المرجع لإمكانية العودة للمستند المصدر
    try {
        localStorage.setItem('oa_journal_return_url', window.location.href);
    } catch (e) {}

    // افتح القالب
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/journal-entry-report.html';
    window.location.href = url;
}
// ================================================================
// ===== END OF JOURNAL.JS =====
// ================================================================