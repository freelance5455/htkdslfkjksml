// ================================================================
// Open Account — نظام محاسبي
// الملف: supplier-ledger.js
// الوصف: كشف حساب الموردين
// النسخة: v2 — مع الرصيد التراكمي
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var _slCurrentSupplier = '';
var _slCurrentCurrency = 'YER';


// ================================================================
// ===== 2. جمع حركات المورد =====
// ================================================================

function getSupplierTransactions(supplierId, currency, from, to) {
    var transactions = [];

    // ===== 1. فواتير الشراء (مدين — عندنا للمورد) =====
    if (typeof purchaseInvoices !== 'undefined' && Array.isArray(purchaseInvoices)) {
        purchaseInvoices.forEach(function(inv) {
            if (inv.supplierId !== supplierId) return;
            var c = inv.currency || 'YER';
            if (c !== currency) return;
            if (from && inv.date < from) return;
            if (to && inv.date > to) return;

            transactions.push({
                date: inv.date,
                type: 'invoice',
                desc: 'فاتورة شراء — ' + (inv.supplierInvoiceNumber && inv.supplierInvoiceNumber !== '-' ? inv.supplierInvoiceNumber : inv.id),
                debit: parseFloat(inv.total) || 0,
                credit: 0
            });
        });
    }

    // ===== 1-b. عكس الفواتير الملغاة (دائن للمورد) =====
    purchaseInvoices.forEach(function(inv) {
        if (!(inv.status === 'ملغاة' || inv.cancelled) || inv.supplierId !== supplierId) return;
        var c = inv.currency || 'YER';
        if (c !== currency) return;
        var d = inv.cancelledAt ? inv.cancelledAt.slice(0,10) : inv.date;
        if (from && d < from) return;
        if (to && d > to) return;
        transactions.push({date:d,type:'cancellation',desc:'إلغاء فاتورة شراء — '+inv.id,debit:0,credit:parseFloat(inv.total)||0});
    });

    // ===== 2. مردودات المشتريات (دائن للمورد في الفاتورة الآجلة) =====
    if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        returnsDocs.forEach(function(ret) {
            if (ret.kind !== 'purchase' || !ret.invoiceId) return;
            var inv = (typeof purchaseInvoices !== 'undefined') ? purchaseInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null;
            if (!inv || inv.supplierId !== supplierId || inv.type === 'نقدي') return;
            var c = ret.currency || inv.currency || 'YER';
            if (c !== currency) return;
            if (from && ret.date < from) return;
            if (to && ret.date > to) return;
            transactions.push({
                date: ret.date,
                type: 'return',
                desc: 'مرتجع مشتريات — ' + ret.invoiceId,
                debit: 0,
                credit: parseFloat(ret.amount) || 0
            });
        });
    }

    // ===== 3. سندات الصرف (دائن — سددنا) =====
    if (typeof payments !== 'undefined' && Array.isArray(payments)) {
        payments.forEach(function(p) {
            if (p.archived) return;
            if (p.cancelled || p.documentStatus === 'cancelled') return;
            if (p.isExpense) return;
            if (p.supplierId !== supplierId) return;
            var c = p.currency || 'YER';
            if (c !== currency) return;
            if (from && p.date < from) return;
            if (to && p.date > to) return;

            transactions.push({
                date: p.date,
                type: 'payment',
                desc: 'سند صرف — ' + (p.method || 'نقدي'),
                debit: 0,
                credit: parseFloat(p.amount) || 0
            });
        });
    }

    // ترتيب حسب التاريخ
    // ===== 4. تحصيل من مورد (supplier_refund — مدين، يخفض الدين) =====
if (typeof receipts !== 'undefined' && Array.isArray(receipts)) {
    receipts.forEach(function(r) {
        if (r.receiptType !== 'supplier_refund' || r.supplierId !== supplierId) return;
        if (r.cancelled || r.documentStatus === 'cancelled') return;
        if ((r.currency || 'YER') !== currency) return;
        if (from && r.date < from) return;
        if (to && r.date > to) return;
        transactions.push({
            date: r.date,
            type: 'supplier_refund',
            desc: 'تحصيل من المورد — ' + (r.sourcePaymentId || r.id),
            debit: parseFloat(r.amount) || 0,   // ← ✅ استلام → يخفض الدين
            credit: 0
        });
    });
}

    transactions.sort(function(a, b) {
        return String(a.date || '').localeCompare(String(b.date || ''));
    });

    return transactions;
}


// ================================================================
// ===== 3. حساب الرصيد الافتتاحي =====
// ================================================================

function getSupplierOpeningBalance(supplierId, currency, from) {
    if (!from) return 0;

    var opening = 0;

    // دورة مغلقة (رصيد مرحّل)
    var cycleOpening = typeof Storage !== 'undefined' ? Storage.get('oa_cycle_opening_balances', null) : null;
    if (cycleOpening && cycleOpening.suppliers && cycleOpening.suppliers[supplierId] && cycleOpening.suppliers[supplierId].currencies) {
        opening += parseFloat(cycleOpening.suppliers[supplierId].currencies[currency]) || 0;
    }

    // فواتير الشراء قبل from
    if (typeof purchaseInvoices !== 'undefined') {
        purchaseInvoices.forEach(function(inv) {
            if (inv.supplierId !== supplierId) return;
            if ((inv.currency || 'YER') !== currency) return;
            if (inv.date >= from) return;
            opening += parseFloat(inv.total) || 0;
        });
    }

    // عكس الفواتير الملغاة قبل from
    purchaseInvoices.forEach(function(inv) {
        if (!(inv.status === 'ملغاة' || inv.cancelled) || inv.supplierId !== supplierId) return;
        if ((inv.currency || 'YER') !== currency) return;
        var d = inv.cancelledAt ? inv.cancelledAt.slice(0,10) : inv.date;
        if (d < from) opening -= parseFloat(inv.total) || 0;
    });

    // مردودات الشراء الآجل قبل from
    if (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs)) {
        returnsDocs.forEach(function(ret) {
            if (ret.kind !== 'purchase') return;
            var inv = (typeof purchaseInvoices !== 'undefined') ? purchaseInvoices.find(function(x) { return x.id === ret.invoiceId; }) : null;
            if (!inv || inv.supplierId !== supplierId || inv.type === 'نقدي') return;
            if ((ret.currency || inv.currency || 'YER') !== currency) return;
            if (ret.date >= from) return;
            opening -= parseFloat(ret.amount) || 0;
        });
    }

    // سندات الصرف قبل from
    if (typeof payments !== 'undefined') {
        payments.forEach(function(p) {
            if (p.archived) return;
            if (p.cancelled || p.documentStatus === 'cancelled') return;
            if (p.isExpense) return;
            if (p.supplierId !== supplierId) return;
            if ((p.currency || 'YER') !== currency) return;
            if (p.date >= from) return;
            opening -= parseFloat(p.amount) || 0;
        });
    }

    if (typeof receipts !== 'undefined') receipts.forEach(function(r) {
    if (r.receiptType !== 'supplier_refund' || r.supplierId !== supplierId || r.cancelled || r.documentStatus === 'cancelled') return;
    if ((r.currency || 'YER') !== currency || r.date >= from) return;
    opening += parseFloat(r.amount) || 0;   // ← ✅ استلام → يزيد الرصيد المدين
});

    return opening;
}


// ================================================================
// ===== 4. عملات المورد =====
// ================================================================

function getSupplierCurrencies(supplierId) {
    var currencies = {};

    if (typeof purchaseInvoices !== 'undefined') {
        purchaseInvoices.forEach(function(inv) {
            if (inv.supplierId !== supplierId) return;
            var c = inv.currency || 'YER';
            currencies[c] = (currencies[c] || 0) + 1;
        });
    }

    if (typeof payments !== 'undefined') {
        payments.forEach(function(p) {
            if (p.archived || p.isExpense) return;
            if (p.supplierId !== supplierId) return;
            var c = p.currency || 'YER';
            currencies[c] = (currencies[c] || 0) + 1;
        });
    }

    return Object.keys(currencies);
}


// ================================================================
// ===== 5. عرض الشاشة =====
// ================================================================

function renderSupplierLedger() {
    var supplierSelect = document.getElementById('slSupplier');
    var currencySelect = document.getElementById('slCurrency');
    var tbody = document.getElementById('slTableBody');

    if (!supplierSelect || !tbody) return;

    // ملء قائمة الموردين
    if (!supplierSelect.options.length || supplierSelect.options.length <= 1) {
        var html = '<option value="">— اختر مورد —</option>';
        if (typeof suppliers !== 'undefined') {
            suppliers.forEach(function(s) {
                html += '<option value="' + s.id + '">' + esc(s.name) + '</option>';
            });
        }
        supplierSelect.innerHTML = html;
    }

    var supplierId = supplierSelect.value;

    if (!supplierId) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">اختر مورداً لعرض الكشف</td></tr>';
        var summaryEl = document.getElementById('slSummary');
        if (summaryEl) summaryEl.innerHTML = '';
        return;
    }

    // ملء قائمة العملات
    var currencies = getSupplierCurrencies(supplierId);
    if (!currencies.length) currencies = ['YER'];

    var curHtml = '';
    currencies.forEach(function(c) {
        curHtml += '<option value="' + c + '">' + c + '</option>';
    });
    currencySelect.innerHTML = curHtml;

    if (_slCurrentCurrency && currencies.indexOf(_slCurrentCurrency) !== -1) {
        currencySelect.value = _slCurrentCurrency;
    } else {
        _slCurrentCurrency = currencies[0];
        currencySelect.value = _slCurrentCurrency;
    }

    var currency = currencySelect.value;
    _slCurrentSupplier = supplierId;

    var fromEl = document.getElementById('slFrom');
    var toEl = document.getElementById('slTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    var opening = getSupplierOpeningBalance(supplierId, currency, from);
    var transactions = getSupplierTransactions(supplierId, currency, from, to);

    var html2 = '';
    var balance = opening;
    var totalDebit = 0;
    var totalCredit = 0;

    // ===== صف رصيد أول المدة =====
    html2 += '<tr style="background:rgba(255,107,53,0.08);font-weight:bold;">' +
        '<td>—</td><td>—</td>' +
        '<td style="text-align:right;padding-right:12px;">رصيد أول المدة</td>' +
        '<td>—</td><td>—</td>' +
        '<td style="color:' + (opening > 0 ? 'var(--color-red)' : opening < 0 ? 'var(--color-green)' : 'var(--color-text)') + ';font-weight:700;">' +
            formatAmountWithCommas(opening) +
        '</td>' +
    '</tr>';

    // ===== الحركات =====
    transactions.forEach(function(t, i) {
        balance += t.debit - t.credit;
        totalDebit += t.debit;
        totalCredit += t.credit;

        var debitText = t.debit > 0 ? formatAmountWithCommas(t.debit) : '—';
        var creditText = t.credit > 0 ? formatAmountWithCommas(t.credit) : '—';

        var balanceColor = balance > 0 ? 'var(--color-red)' : balance < 0 ? 'var(--color-green)' : 'var(--color-text)';
        var balanceLabel = balance > 0 ? 'عليك' : balance < 0 ? 'لك' : '';

        html2 += '<tr>' +
            '<td>' + (i + 1) + '</td>' +
            '<td>' + formatDate(t.date) + '</td>' +
            '<td style="text-align:right;padding-right:12px;">' + esc(t.desc) + '</td>' +
            '<td style="color:var(--color-red);">' + debitText + '</td>' +
            '<td style="color:var(--color-green);">' + creditText + '</td>' +
            '<td style="font-weight:700;color:' + balanceColor + ';">' +
                formatAmountWithCommas(Math.abs(balance)) +
                (balanceLabel ? ' <small style="opacity:0.6;">(' + balanceLabel + ')</small>' : '') +
            '</td>' +
        '</tr>';
    });

    tbody.innerHTML = html2;

    // ===== الملخص =====
    var summary = document.getElementById('slSummary');
    if (summary) {
        var statusText = '';
        if (balance > 0) {
            statusText = 'عليك للمورد: ' + formatAmountWithCommas(balance) + ' ' + currency;
        } else if (balance < 0) {
            statusText = 'لك عند المورد: ' + formatAmountWithCommas(Math.abs(balance)) + ' ' + currency;
        } else {
            statusText = 'الرصيد صفر — مطابق';
        }

        summary.innerHTML =
            '<div class="info-boxes" style="grid-template-columns:1fr 1fr;">' +
                '<div class="info-box"><span>إجمالي المدين</span><strong>' + formatAmountWithCommas(totalDebit) + ' ' + currency + '</strong></div>' +
                '<div class="info-box"><span>إجمالي الدائن</span><strong>' + formatAmountWithCommas(totalCredit) + ' ' + currency + '</strong></div>' +
                '<div class="info-box" style="grid-column:span 2;"><span>الرصيد الختامي</span><strong>' + statusText + '</strong></div>' +
            '</div>';
    }

    var dateEl = document.getElementById('slDate');
    if (dateEl) dateEl.textContent = todayArabic();
}

// ================================================================
// ===== 6. الطباعة (القالب الجديد) =====
// ================================================================

function printSupplierLedger() {
    var supplierId = _slCurrentSupplier;
    if (!supplierId) { showToast('اختر مورداً أولاً', 'error'); return; }

    var supplier = suppliers.find(function(s) { return s.id === supplierId; });
    if (!supplier) { showToast('المورد غير موجود', 'error'); return; }

    var currencySelect = document.getElementById('slCurrency');
    var currency = currencySelect ? currencySelect.value : 'YER';

    var fromEl = document.getElementById('slFrom');
    var toEl = document.getElementById('slTo');
    var from = fromEl ? fromEl.value : '';
    var to = toEl ? toEl.value : '';

    // ===== اقرأ الجدول من الصفحة =====
    var tbody = document.getElementById('slTableBody');
    if (!tbody) { showToast('الجدول غير موجود', 'error'); return; }
    var table = tbody.closest('table');
    if (!table) { showToast('الجدول غير موجود', 'error'); return; }

    var count = tbody.querySelectorAll('tr').length;

    // ===== اقرأ الإجماليات =====
    var totalDebit = '—';
    var totalCredit = '—';
    var finalBalance = '—';
    try {
        var opening = getSupplierOpeningBalance(supplierId, currency, from);
        var transactions = getSupplierTransactions(supplierId, currency, from, to);
        var bal = opening;
        var tDebit = 0, tCredit = 0;
        transactions.forEach(function(t) {
            bal += t.debit - t.credit;
            tDebit += t.debit;
            tCredit += t.credit;
        });
        totalDebit = formatAmountWithCommas(tDebit) + ' ' + currency;
        totalCredit = formatAmountWithCommas(tCredit) + ' ' + currency;
        var absBal = Math.abs(bal);
        var label = bal > 0 ? 'عليك للمورد' : (bal < 0 ? 'لك عند المورد' : 'الرصيد صفر');
        finalBalance = formatAmountWithCommas(absBal) + ' ' + currency + ' (' + label + ')';
    } catch(e) { /* تجاهل */ }

    // ===== الإعدادات =====
    var settings = {};
    if (typeof Storage !== 'undefined' && typeof STORAGE_KEYS !== 'undefined') {
        settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    }

    // ===== الحمولة =====
    var payload = {
        type: 'supplier_ledger',
        tableHtml: table.outerHTML,
        settings: settings,
        meta: {
            supplierName: supplier.name || '—',
            currency: currency,
            from: from || 'البداية',
            to: to || 'اليوم',
            totalDebit: totalDebit,
            totalCredit: totalCredit,
            finalBalance: finalBalance,
            count: count
        },
        createdAt: new Date().toISOString()
    };
    localStorage.setItem('oa_template_payload', JSON.stringify(payload));

    // ===== افتح القالب =====
    var base = window.location.href.replace(/\/[^\/]*$/, '/');
    var url = base + 'templates/supplier-ledger-report.html';
    window.location.href = url;
}


// ================================================================
// ===== 7. تهيئة =====
// ================================================================

function initSupplierLedger() {
    var supplierSelect = document.getElementById('slSupplier');
    if (supplierSelect) {
        supplierSelect.addEventListener('change', function() {
            _slCurrentCurrency = '';
            renderSupplierLedger();
        });
    }

    var currencySelect = document.getElementById('slCurrency');
    if (currencySelect) {
        currencySelect.addEventListener('change', function() {
            _slCurrentCurrency = this.value;
            renderSupplierLedger();
        });
    }

    var refreshBtn = document.getElementById('slRefresh');
    if (refreshBtn) refreshBtn.addEventListener('click', renderSupplierLedger);

    var printBtn = document.getElementById('slPrint');
    if (printBtn) printBtn.addEventListener('click', printSupplierLedger);

    var fromEl = document.getElementById('slFrom');
    var toEl = document.getElementById('slTo');
    if (fromEl && !fromEl.value) fromEl.value = firstDayOfMonthISO();
    if (toEl && !toEl.value) toEl.value = todayISO();

    renderSupplierLedger();
    console.log('Supplier Ledger: initialized');
}


// ================================================================
// ===== END OF SUPPLIER-LEDGER.JS =====
// ================================================================