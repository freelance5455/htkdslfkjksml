// ================================================================
// Open Account — نظام محاسبي
// الملف: payments.js
// الوصف: سندات الصرف (الدفع للموردين)
// ================================================================


// ================================================================
// ===== 1. المتغيرات العامة =====
// ================================================================

var payments = [];
// ✅ وضع الأرشفة
var _archivePaymentsMode = false;
var _showArchivedPayments = false;
var _selectedPaymentsForArchive = {};


// ================================================================
// ===== 2. تحميل وحفظ السندات =====
// ================================================================

function loadPayments() {
    payments = Storage.get(STORAGE_KEYS.PAYMENTS, []);
    if (!Array.isArray(payments)) payments = [];
}


function savePayments() {
    Storage.set(STORAGE_KEYS.PAYMENTS, payments);
}


// ================================================================
// ===== 3. عرض جدول سندات الصرف =====
// ================================================================

function renderPayments() {
    var tbody = document.getElementById('payTableBody');
    if (!tbody) return;
    
    var searchEl = document.getElementById('paySearch');
    var search = searchEl ? searchEl.value.toLowerCase().trim() : '';
    
    // ✅ فلترة المؤرشفة
    var filtered = payments.filter(function(p) {
        if (_showArchivedPayments) return p.archived === true;
        return p.archived !== true;
    });
    
  if (search) {
    filtered = filtered.filter(function(p) {
        var partyName = p.customerName || p.supplierName || p.expenseType || '';
        return String(partyName).toLowerCase().indexOf(search) !== -1 ||
               String(p.invoiceId || '').indexOf(search) !== -1 ||
               String(p.id || '').indexOf(search) !== -1;
    });
}
    
    if (!filtered.length) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-cell">' +
            (_showArchivedPayments ? 'لا توجد سندات مؤرشفة' : 'لا توجد سندات') +
            '</td></tr>';
    } else {
        var html = '';
        filtered.forEach(function(p, i) {
            var _isCancelled = p.cancelled || p.documentStatus === 'cancelled';
            var _rowStyle = _isCancelled ? 'opacity:0.5;text-decoration:line-through;' : '';
            var _statusBadge = _isCancelled 
                ? ' <span style="background:#888;color:#fff;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;">ملغى</span>' 
                : '';

            // ✅ checkbox في وضع الأرشفة
            var firstCell = (i + 1);
            if (_archivePaymentsMode && !_showArchivedPayments && !_isCancelled) {
                var checked = _selectedPaymentsForArchive[p.id] ? 'checked' : '';
                firstCell = '<input type="checkbox" class="pay-archive-cb" data-id="' + p.id + '" ' + checked + ' onchange="onPaymentsArchiveCheckboxChange(this)">';
            }

            // ✅ أزرار الإجراءات
            var actionsHtml = '';
            if (_showArchivedPayments) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewPayment(\'' + p.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    '<button class="btn-edit" onclick="restorePayment(\'' + p.id + '\')" title="استرجاع" style="margin-right:4px;">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg>' +
                    '</button>';
            } else if (!_archivePaymentsMode) {
                actionsHtml =
                    '<button class="btn-view" onclick="viewPayment(\'' + p.id + '\')" title="عرض">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>' +
                    '</button>' +
                    (_isCancelled ? '' : '<button class="btn-delete" onclick="deletePayment(\'' + p.id + '\')" title="حذف">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
                    '</button>');
            }

            // ✅ تحديد الطرف الصحيح
var partyLabel = '';
if (p.paymentType === 'customer_refund') {
    partyLabel = p.customerName || '—';
} else if (p.isExpense) {
    partyLabel = p.expenseType || p.supplierName || 'مصروف';
} else {
    partyLabel = p.supplierName || '—';
}

// ✅ عرض نوع السند
var typeBadge = '';
if (p.paymentType === 'customer_refund') {
    typeBadge = ' <span style="background:#eef6fb;color:#1f6feb;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;">رد لعميل</span>';
} else if (p.isExpense) {
    typeBadge = ' <span style="background:#fdf6e3;color:#a67c0e;font-size:10px;padding:2px 6px;border-radius:8px;font-weight:700;">مصروف</span>';
}

html += '<tr style="' + _rowStyle + '">' +
    '<td>' + firstCell + '</td>' +
    '<td>' + esc(partyLabel) + _statusBadge + typeBadge + '</td>' +
    '<td>' + esc(p.invoiceId || '-') + '</td>' +
    '<td>' + formatCurrency(p.amount, p.currency) + '</td>' +
    '<td>' + formatDate(p.date) + '</td>' +
    '<td>' + actionsHtml + '</td>' +
'</tr>';
        });
        tbody.innerHTML = html;
    }
    
    // ✅ شريط أدوات الأرشفة
    _renderPaymentsArchiveToolbar();
    
    updatePaymentsStats();
}

// ✅ شريط أدوات الأرشفة
function _renderPaymentsArchiveToolbar() {
    var bar = document.getElementById('paymentsArchiveBar');
    if (!bar) return;

    if (!_archivePaymentsMode) {
        bar.style.display = 'none';
        bar.innerHTML = '';
        return;
    }

    var count = Object.keys(_selectedPaymentsForArchive).length;
    bar.style.display = 'flex';
    bar.innerHTML =
        '<button class="btn btn-secondary" onclick="toggleSelectAllPayments()" style="flex:1;font-size:12px;">' +
            (_allActivePaymentsSelected() ? 'إلغاء الكل' : 'تحديد الكل') +
        '</button>' +
        '<button class="btn btn-warning" onclick="confirmArchivePayments()" style="flex:1;font-size:12px;" ' + (count === 0 ? 'disabled' : '') + '>' +
            'أرشفة المحدد (' + count + ')' +
        '</button>' +
        '<button class="btn btn-cancel" onclick="toggleArchivePaymentsMode()" style="flex:1;font-size:12px;">' +
            'إلغاء' +
        '</button>';
}

function _allActivePaymentsSelected() {
    var active = payments.filter(function(p) { 
        return !p.cancelled && p.documentStatus !== 'cancelled' && !p.archived; 
    });
    if (!active.length) return false;
    return active.every(function(p) { return _selectedPaymentsForArchive[p.id]; });
}

// ✅ دوال الأرشفة
function toggleArchivePaymentsMode() {
    _archivePaymentsMode = !_archivePaymentsMode;
    _selectedPaymentsForArchive = {};
    if (_archivePaymentsMode) _showArchivedPayments = false;
    renderPayments();
}

function toggleShowArchivedPayments() {
    _showArchivedPayments = !_showArchivedPayments;
    _archivePaymentsMode = false;
    _selectedPaymentsForArchive = {};
    renderPayments();
}

function onPaymentsArchiveCheckboxChange(cb) {
    var id = cb.getAttribute('data-id');
    if (cb.checked) _selectedPaymentsForArchive[id] = true;
    else delete _selectedPaymentsForArchive[id];
    _renderPaymentsArchiveToolbar();
}

function toggleSelectAllPayments() {
    var active = payments.filter(function(p) { 
        return !p.cancelled && p.documentStatus !== 'cancelled' && !p.archived; 
    });
    if (_allActivePaymentsSelected()) {
        _selectedPaymentsForArchive = {};
    } else {
        active.forEach(function(p) { _selectedPaymentsForArchive[p.id] = true; });
    }
    renderPayments();
}

function confirmArchivePayments() {
    var ids = Object.keys(_selectedPaymentsForArchive);
    if (!ids.length) { showToast('لم تحدد أي سند', 'warning'); return; }
    if (!confirm('سيتم أرشفة ' + ids.length + ' سند.\nستُخفى من العرض — لا تُحذف.\n\nمتابعة؟')) return;

    var count = 0;
    payments.forEach(function(p) {
        if (_selectedPaymentsForArchive[p.id]) {
            p.archived = true;
            p.archivedAt = new Date().toISOString();
            count++;
        }
    });

    savePayments();
    _archivePaymentsMode = false;
    _selectedPaymentsForArchive = {};
    renderPayments();
    showToast('تمت أرشفة ' + count + ' سند', 'success');
}

function restorePayment(id) {
    var p = payments.find(function(x) { return x.id === id; });
    if (!p) return;
    p.archived = false;
    delete p.archivedAt;
    savePayments();
    renderPayments();
    showToast('تم استرجاع السند', 'success');
}
 

// ================================================================
// ===== 4. إحصائيات سندات الصرف =====
// ================================================================

function updatePaymentsStats() {
    var active = payments.filter(function(p) { return !p.archived; });
    setText('payCount', active.length);
    
    var totals = {};
    active.forEach(function(p) {
        var c = p.currency || 'YER';
        totals[c] = (totals[c] || 0) + (parseFloat(p.amount) || 0);
    });
    
    var parts = [];
    ['YER', 'SAR', 'USD'].forEach(function(c) {
        if (totals[c]) parts.push(formatAmountWithCommas(totals[c]) + ' ' + c);
    });
    
    setText('payTotal', parts.length ? parts.join(' | ') : '0');
}


// ================================================================
// ===== 5. نافذة سند صرف جديد =====
// ================================================================

function openPaymentModal() {
    if (!suppliers || suppliers.length === 0) {
        showToast('يرجى إضافة مورد أولاً', 'error');
        return;
    }
    
    var bodyHTML = _buildPaymentFormHTML();
    
    var footerHTML = 
        '<button class="btn btn-cancel" onclick="closeModal(\'paymentModal\')">إلغاء</button>' +
        '<button class="btn btn-warning" onclick="savePayment()">حفظ</button>';
    
    Modal.open({
        id: 'paymentModal',
        title: 'سند صرف جديد',
        size: 'normal',
        body: bodyHTML,
        footer: footerHTML,
        onOpen: function(modalEl) {
            _populatePaymentSuppliers();
            _onPaymentTypeChange();
            
            var dateEl = modalEl.querySelector('#paymentDate');
            if (dateEl) dateEl.value = todayISO();
        }
    });
}


function _buildPaymentFormHTML() {
    return '' +
        '<div class="form-field"><label>نوع السند</label>' +
        '<select id="paymentType" onchange="_onPaymentTypeChange()">' +
        '<option value="supplier_payment">سند صرف لمورد</option>' +
        '<option value="customer_refund">رد مبلغ لعميل</option>' +
        '</select></div>' +
        '<div id="paymentSupplierBlock">' +
        '<div class="form-row">' +
            '<div class="form-field">' +
                '<label>المورد</label>' +
                '<select id="paymentSupplier" onchange="loadSupplierInvoices()">' +
                    '<option value="">— اختر مورد —</option>' +
                '</select>' +
            '</div>' +
            '<div class="form-field">' +
                '<label>التاريخ</label>' +
                '<input type="date" id="paymentDate">' +
            '</div>' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>الفاتورة</label>' +
            '<select id="paymentInvoice" onchange="updatePaymentInfo()">' +
                '<option value="">— اختر فاتورة —</option>' +
            '</select>' +
        '</div>' +
        '</div>' +
        '<div id="paymentRefundBlock" style="display:none;">' +
            '<div class="form-field"><label>العميل</label><select id="paymentCustomer"></select></div>' +
            '<div class="form-field"><label>سند القبض الأصلي</label><select id="paymentSourceReceipt" onchange="updatePaymentRefundInfo()"></select></div>' +
        '</div>' +
        '<div class="form-field">' +
            '<label>طريقة الدفع</label>' +
            '<select id="paymentMethod">' +
                '<option>نقدي</option>' +
                '<option>تحويل بنكي</option>' +
                '<option>بطاقة</option>' +
            '</select>' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>المبلغ المدفوع</label>' +
            '<input type="number" id="paymentAmount" placeholder="0.00" step="0.01" min="0">' +
        '</div>' +
        
        '<div class="form-field">' +
            '<label>ملاحظة (اختياري)</label>' +
            '<input type="text" id="paymentNote" placeholder="ملاحظة">' +
        '</div>' +
        
        '<div class="info-boxes">' +
            '<div class="info-box">' +
                '<span>قيمة الفاتورة</span>' +
                '<strong id="paymentInvoiceTotal">0.00</strong>' +
            '</div>' +
            '<div class="info-box">' +
                '<span>المتبقي</span>' +
                '<strong id="paymentRemaining">0.00</strong>' +
            '</div>' +
        '</div>';
}


function _onPaymentTypeChange() {
    var type = (document.getElementById('paymentType') || {}).value || 'supplier_payment';
    var supplierBlock = document.getElementById('paymentSupplierBlock');
    var refundBlock = document.getElementById('paymentRefundBlock');
    if (supplierBlock) supplierBlock.style.display = type === 'customer_refund' ? 'none' : '';
    if (refundBlock) refundBlock.style.display = type === 'customer_refund' ? '' : 'none';
    if (type === 'customer_refund') {
        _populatePaymentRefundCustomers();
        _populatePaymentRefundReceipts();
    }
}

function _populatePaymentRefundCustomers() {
    var el = document.getElementById('paymentCustomer');
    if (!el) return;
    el.innerHTML = '<option value="">— اختر عميل —</option>' +
        (typeof customers !== 'undefined' ? customers.map(function(c) { return '<option value="' + c.id + '">' + esc(c.name) + '</option>'; }).join('') : '');
}

function _populatePaymentRefundReceipts() {
    var el = document.getElementById('paymentSourceReceipt');
    if (!el) return;
    el.innerHTML = '<option value="">— اختر سند قبض —</option>' +
        (typeof receipts !== 'undefined' ? receipts.filter(function(r) {
            return !r.cancelled && r.documentStatus !== 'cancelled' && r.customerId;
        }).map(function(r) {
            return '<option value="' + r.id + '">' + esc(r.id) + ' | ' + esc(r.customerName || '-') + ' | ' + formatCurrency(r.amount, r.currency) + '</option>';
        }).join('') : '');
}

function updatePaymentRefundInfo() {
    var id = (document.getElementById('paymentSourceReceipt') || {}).value;
    var r = typeof receipts !== 'undefined' ? receipts.find(function(x) { return x.id === id; }) : null;
    var amount = r ? (parseFloat(r.amount) || 0) : 0;
    var used = typeof payments !== 'undefined' ? payments.filter(function(p) {
        return p.paymentType === 'customer_refund' && p.sourceReceiptId === id && !p.cancelled && p.documentStatus !== 'cancelled';
    }).reduce(function(s, p) { return s + (parseFloat(p.amount) || 0); }, 0) : 0;
    var totalEl = document.getElementById('paymentInvoiceTotal');
    var remainEl = document.getElementById('paymentRemaining');
    if (totalEl) totalEl.textContent = r ? formatCurrency(amount, r.currency) : '0.00';
    if (remainEl) remainEl.textContent = r ? formatCurrency(Math.max(0, amount - used), r.currency) : '0.00';
    var amountEl = document.getElementById('paymentAmount');
    if (amountEl) amountEl.value = r ? Math.max(0, amount - used).toFixed(2) : '';
}

function _populatePaymentSuppliers() {
    var selectEl = document.getElementById('paymentSupplier');
    if (!selectEl) return;
    
    var html = '<option value="">— اختر مورد —</option>';
    suppliers.forEach(function(s) {
        html += '<option value="' + s.id + '">' + esc(s.name) + '</option>';
    });
    selectEl.innerHTML = html;
}


// ================================================================
// ===== 6. تحميل فواتير المورد =====
// ================================================================

function loadSupplierInvoices() {
    var supEl = document.getElementById('paymentSupplier');
    var invEl = document.getElementById('paymentInvoice');
    
    if (!supEl || !invEl) return;
    
    var supplierId = supEl.value;
    
    invEl.innerHTML = '<option value="">— اختر فاتورة —</option>';
    
    if (!supplierId) {
        updatePaymentInfo();
        return;
    }
    
        // ===== فواتير المورد المتاحة للسداد =====
    // استخدام المصدر الموحد getInvoiceOutstanding
    var unpaidInvoices = [];
    
    purchaseInvoices.forEach(function(inv) {
        if (inv.supplierId !== supplierId) return;
        if (inv.cancelled || inv.status === 'ملغاة') return;
        
        // المصدر الموحد
        var o = (typeof getInvoiceOutstanding === 'function')
            ? getInvoiceOutstanding(inv.id, 'purchase')
            : null;
        
        if (!o) return;
        
        // استبعاد الفواتير التي لا مستحق لها
        if (o.outstanding <= 0.01) return;
        
        unpaidInvoices.push({
            invoice: inv,
            outstanding: o
        });
    });
    
    if (!unpaidInvoices.length) {
        invEl.innerHTML = '<option value="">لا توجد فواتير متاحة للسداد</option>';
        updatePaymentInfo();
        return;
    }
    
    var html = '<option value="">— اختر فاتورة —</option>';
    unpaidInvoices.forEach(function(entry) {
        var inv = entry.invoice;
        var o = entry.outstanding;
        
        // بيانات مساعدة لـ updatePaymentInfo
        var statusHint = '';
        if (o.totalReturns > 0) {
            statusHint = ' | مرتجع ' + formatAmountWithCommas(o.totalReturns);
        }
        
        html += '<option value="' + inv.id + '" ' +
                'data-total="' + o.invoiceTotal + '" ' +
                'data-returns="' + o.totalReturns + '" ' +
                'data-paid="' + o.totalPaid + '" ' +
                'data-remaining="' + o.outstanding + '" ' +
                'data-currency="' + (inv.currency || 'SAR') + '">' +
                esc(inv.id) + ' | متبقي ' + formatAmountWithCommas(o.outstanding) + statusHint +
                '</option>';
    });
    invEl.innerHTML = html;
    
    updatePaymentInfo();
}
// ================================================================
// ===== 7. تحديث معلومات السند =====
// ================================================================

function updatePaymentInfo() {
    var invEl = document.getElementById('paymentInvoice');
    var totalEl = document.getElementById('paymentInvoiceTotal');
    var remainEl = document.getElementById('paymentRemaining');
    var amountEl = document.getElementById('paymentAmount');
    
    if (!invEl) return;
    
    var selected = invEl.options[invEl.selectedIndex];
    
    if (!selected || !selected.value) {
        if (totalEl) totalEl.textContent = '0.00';
        if (remainEl) remainEl.textContent = '0.00';
        if (amountEl) amountEl.value = '';
        return;
    }
    
    var total = parseFloat(selected.dataset.total) || 0;
    var returns = parseFloat(selected.dataset.returns) || 0;
    var paid = parseFloat(selected.dataset.paid) || 0;
    var remaining = parseFloat(selected.dataset.remaining) || 0;
    
    if (totalEl) {
        var totalText = formatAmountWithCommas(total);
        if (returns > 0) {
            totalText += ' (مرتجع: ' + formatAmountWithCommas(returns) + ')';
        }
        totalEl.textContent = totalText;
    }
    
    if (remainEl) {
        remainEl.textContent = formatAmountWithCommas(remaining);
        remainEl.style.color = remaining > 0.01 
            ? 'var(--color-red)' 
            : 'var(--color-green)';
    }
    
    if (amountEl) {
        if (remaining > 0.01) {
            amountEl.value = remaining.toFixed(2);
        } else {
            amountEl.value = '';
        }
    }
}


// ================================================================
// ===== 8. حفظ سند الصرف =====
// ================================================================

function savePayment() {
    var supEl = document.getElementById('paymentSupplier');
    var dateEl = document.getElementById('paymentDate');
    var invEl = document.getElementById('paymentInvoice');
    var methodEl = document.getElementById('paymentMethod');
    var amountEl = document.getElementById('paymentAmount');
    var noteEl = document.getElementById('paymentNote');
    
    var supplierId = supEl ? supEl.value : '';
    var date = dateEl ? dateEl.value : '';
    var invoiceId = invEl ? invEl.value : '';
    var method = methodEl ? methodEl.value : 'نقدي';
    var amount = parseFloat(amountEl ? amountEl.value : 0) || 0;
    var note = noteEl ? noteEl.value.trim() : '';
    var paymentType = (document.getElementById('paymentType') || {}).value || 'supplier_payment';
    var payAccount = (method === 'تحويل بنكي' || method === 'بطاقة') ? 'bank' : 'cashbox';

    if (paymentType === 'customer_refund') {
        var customerId = (document.getElementById('paymentCustomer') || {}).value || '';
        var sourceReceiptId = (document.getElementById('paymentSourceReceipt') || {}).value || '';
        var sourceReceipt = typeof receipts !== 'undefined' ? receipts.find(function(r) { return r.id === sourceReceiptId; }) : null;
       if (!customerId || !sourceReceiptId || !sourceReceipt) { showToast('اختر العميل وسند القبض الأصلي', 'error'); return; }
if (sourceReceipt.customerId !== customerId) { showToast('سند القبض لا يخص العميل المختار', 'error'); return; }
// ✅ فحص صحيح محاسبياً: يعتمد على إجمالي المرتجعات وليس سند القبض
var sourceInvoiceId = sourceReceipt.invoiceId || '-';

// إجمالي المرتجعات النشطة على الفاتورة المرتبطة
var linkedReturns = (typeof returnsDocs !== 'undefined' && Array.isArray(returnsDocs))
    ? returnsDocs.filter(function(r) {
        return r.kind === 'sale'
            && r.invoiceId === sourceInvoiceId
            && r.cancelled !== true
            && r.documentStatus !== 'cancelled';
    })
    : [];
var totalReturns = linkedReturns.reduce(function(s, r) {
    return s + (parseFloat(r.amount) || 0);
}, 0);

// الردود السابقة (بلا حذف الملغى)
var alreadyRefunded = payments.filter(function(p) {
    return p.paymentType === 'customer_refund'
        && p.sourceInvoiceId === sourceInvoiceId
        && !p.cancelled
        && p.documentStatus !== 'cancelled';
}).reduce(function(s, p) {
    return s + (parseFloat(p.amount) || 0);
}, 0);

// المتاح للرد = إجمالي المرتجعات − الردود السابقة
var availableRefund = totalReturns - alreadyRefunded;

if (!date) { showToast('يرجى اختيار التاريخ', 'error'); return; }

if (amount <= 0) {
    showToast('يرجى إدخال مبلغ صحيح', 'error');
    return;
}

if (availableRefund <= 0.01) {
    showToast(
        'لا يوجد مبلغ متاح للرد.\n' +
        'إجمالي المرتجعات: ' + formatAmountWithCommas(totalReturns) + ' ' + (sourceReceipt.currency || '') + '\n' +
        'الردود السابقة: ' + formatAmountWithCommas(alreadyRefunded) + ' ' + (sourceReceipt.currency || ''),
        'error',
        10000
    );
    return;
}

if (amount > availableRefund + 0.01) {
    showToast(
        'المبلغ يتجاوز المتاح للرد.\n' +
        'المطلوب: ' + formatAmountWithCommas(amount) + ' ' + (sourceReceipt.currency || '') + '\n' +
        'المتاح: ' + formatAmountWithCommas(availableRefund) + ' ' + (sourceReceipt.currency || '') + '\n' +
        'المرتجعات: ' + formatAmountWithCommas(totalReturns) + ' | الردود السابقة: ' + formatAmountWithCommas(alreadyRefunded),
        'error',
        12000
    );
    return;
}
        if (typeof checkSufficientBalance === 'function') { var bc = checkSufficientBalance(payAccount, sourceReceipt.currency || 'YER', amount); if (!bc.ok) { showToast('رصيد ' + bc.accountLabel + ' غير كافٍ', 'error'); return; } }
        var customer = typeof customers !== 'undefined' ? customers.find(function(c) { return c.id === customerId; }) : null;
        var refund = {
    id: generateId(),
    paymentType: 'customer_refund',
    settlementType: 'customer_refund',
    invoiceId: '-',
    customerId: customerId,
    customerName: customer ? customer.name : (sourceReceipt.customerName || '-'),
    sourceReceiptId: sourceReceiptId,
    sourceInvoiceId: sourceReceipt.invoiceId || '-',
    amount: amount,
    currency: sourceReceipt.currency || 'YER',
    exchangeRate: sourceReceipt.exchangeRate || 1,
    account: payAccount,
    method: method,
    date: date,
    note: note || 'رد مبلغ لعميل',
    documentStatus: 'posted',
    cancelled: false,
    status: 'تم الرد',
    totalReturnsAtCreation: totalReturns  // ← إضافة
};
        payments.push(refund);
        sourceReceipt.refundPaymentId = refund.id;
        savePayments(); if (typeof saveReceipts === 'function') saveReceipts();
        if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();
        closeModal('paymentModal'); if (typeof oaRefreshRelated === 'function') oaRefreshRelated('payment'); else { renderPayments(); if (typeof updateDashboard === 'function') updateDashboard(); }
        showToast('تم حفظ رد المبلغ', 'success'); return;
    }
    
    if (!supplierId) { showToast('يرجى اختيار المورد', 'error'); return; }
    if (!date) { showToast('يرجى اختيار التاريخ', 'error'); return; }

    if (!invoiceId) { showToast('يرجى اختيار الفاتورة', 'error'); return; }
    if (amount <= 0) { showToast('يرجى إدخال مبلغ صحيح', 'error'); return; }
    
var supplier = suppliers.find(function(s) { return s.id === supplierId; });
var invoice = purchaseInvoices.find(function(inv) { return inv.id === invoiceId; });

if (!invoice) { showToast('الفاتورة غير موجودة', 'error'); return; }

// ============================================================
// فحص الرصيد عبر المصدر الموحد getInvoiceOutstanding
// ============================================================
if (typeof getInvoiceOutstanding !== 'function') {
    showToast('دالة الرصيد الموحّد غير متوفرة', 'error');
    return;
}

var outstanding = getInvoiceOutstanding(invoiceId, 'purchase');
if (!outstanding) {
    showToast('تعذر حساب رصيد الفاتورة', 'error');
    return;
}

var remaining = outstanding.outstanding;
var paid = outstanding.totalPaid;

// ===== منع السداد إذا لا يوجد مستحق =====
if (remaining <= 0.01) {
    var reason = remaining < -0.01
        ? 'الفاتورة بها زيادة سداد (' + formatAmountWithCommas(Math.abs(remaining)) + ' ' + outstanding.currency + ')'
        : 'الفاتورة مسددة بالكامل';
    
    showToast(
        'لا يمكن السداد.\n' + reason + '\n' +
        'الرصيد المستحق: ' + formatAmountWithCommas(remaining) + ' ' + outstanding.currency,
        'error',
        10000
    );
    return;
}

// ===== منع تجاوز الرصيد =====
if (amount > remaining + 0.01) {
    showToast(
        'المبلغ يتجاوز الرصيد المستحق.\n' +
        'المطلوب: ' + formatAmountWithCommas(amount) + ' ' + outstanding.currency + '\n' +
        'المتاح: ' + formatAmountWithCommas(remaining) + ' ' + outstanding.currency,
        'error',
        10000
    );
    return;
}

// ============================================================
// التحقق من رصيد الحساب (نقدي: الصندوق | تحويل/بطاقة: البنك)
// ============================================================
var payAccount = (method === 'تحويل بنكي' || method === 'بطاقة') ? 'bank' : 'cashbox';
if (typeof checkSufficientBalance === 'function') {
    var payCur = invoice.currency || 'YER';
    var balanceCheck = checkSufficientBalance(payAccount, payCur, amount);
    if (!balanceCheck.ok) {
        showToast('رصيد ' + balanceCheck.accountLabel + ' غير كافٍ', 'error');
        return;
    }
}

// إنشاء السند
var newPayment = {
        id: generateId(),
        invoiceId: invoiceId,
        supplierId: supplierId,
        supplierName: supplier ? supplier.name : '-',
        amount: amount,
        currency: invoice.currency || 'YER',
        exchangeRate: invoice.exchangeRate || (typeof getCurrentExchangeRateSnapshot === 'function' ? getCurrentExchangeRateSnapshot(invoice.currency || 'YER') : 1),
        date: date,
        method: method,
        note: note,
        invoiceTotal: invoice.total,
        paidBefore: paid,
        remainingAfter: remaining - amount,
        status: amount >= remaining ? 'مدفوع بالكامل' : 'دفع جزئي'
    };
    
    payments.push(newPayment);
    
// ============================================================
// تحديث حالة الفاتورة بناءً على المصدر الموحد
// ============================================================
var updated = getInvoiceOutstanding(invoiceId, 'purchase');
if (updated) {
    invoice.status = updated.statusLabel;
    
    // تبسيط paymentStatus إلى 3 قيم فقط
    var simplifiedPayment = 'unpaid';
    if (updated.derivedStatus === 'paid' || updated.derivedStatus === 'fully_returned') {
        simplifiedPayment = 'paid';
    } else if (updated.derivedStatus === 'partial' 
            || updated.derivedStatus === 'overpaid' 
            || updated.derivedStatus === 'partially_returned') {
        simplifiedPayment = 'partial';
    }
    invoice.paymentStatus = simplifiedPayment;
    
    // returnStatus
    invoice.returnStatus = updated.returnedRatio >= 0.9999 
        ? 'full' 
        : (updated.returnedRatio > 0 ? 'partial' : 'none');
} else {
    invoice.status = 'دفع جزئي';
}
    
      savePayments();
    savePurchaseInvoices();
    if (typeof syncJournalAfterMutation === 'function') syncJournalAfterMutation();

    closeModal('paymentModal');

    // ✅ مزامنة مركزية — تحدّث كل الشاشات المرتبطة
    if (typeof oaRefreshRelated === 'function') {
        oaRefreshRelated('payment');
    } else {
        renderPayments();
        renderPurchaseInvoices();
        if (typeof updateDashboard === 'function') updateDashboard();
    }

    showToast('تم حفظ سند الصرف', 'success');
}


// ================================================================
// ===== 9. عرض سند الصرف =====
// ================================================================

function viewPayment(id) {
    var payment = payments.find(function(p) { return p.id === id; });
    if (!payment) {
        showToast('السند غير موجود', 'error');
        return;
    }
    
    var html = _buildPaymentView(payment);
    
    Modal.open({
        id: 'paymentViewModal',
        title: 'تفاصيل سند الصرف',
        size: 'large',
        body: '<div style="background:#fff;padding:16px;border-radius:8px;">' + html + '</div>',
        footer: '<button class="btn btn-cancel" onclick="closeModal(\'paymentViewModal\')">إغلاق</button>' +
                '<button class="btn btn-primary" onclick="printIndividualDocument(\'payments\', \'' + payment.id + '\')">طباعة / حفظ PDF</button>'
    });
}


function _buildPaymentView(p) {
    var settings = Storage.get(STORAGE_KEYS.SETTINGS, {}) || {};
    var companyName = settings.name || 'Open Account';
    var companyAddress = settings.address || '';
    var companyPhone = settings.phone || '';
    
    return '' +
        '<div class="doc-wrapper">' +
            '<div class="doc-header">' +
                '<div class="company-name">' + esc(companyName) + '</div>' +
                '<div class="company-info">' +
                    esc(companyAddress) +
                    (companyPhone ? ' | هاتف: ' + esc(companyPhone) : '') +
                '</div>' +
            '</div>' +
            
            '<div class="doc-title">سند صرف</div>' +
            
            '<div class="doc-meta-grid">' +
                '<div><strong>رقم السند:</strong> ' + esc(p.id) + '</div>' +
                '<div><strong>التاريخ:</strong> ' + esc(p.date) + '</div>' +
                '<div><strong>الفاتورة:</strong> ' + esc(p.invoiceId) + '</div>' +
                '<div><strong>المورد:</strong> ' + esc(p.supplierName) + '</div>' +
                '<div><strong>طريقة الدفع:</strong> ' + esc(p.method) + '</div>' +
                 '<div><strong>الحالة:</strong> ' +
    (p.cancelled || p.documentStatus === 'cancelled' 
        ? '<span class="status-badge status-cancelled">ملغى</span>' 
        : '<span class="status-badge status-paid">' + esc(p.status) + '</span>') +
'</div>' +
                (p.note ? '<div style="grid-column:span 2;"><strong>ملاحظة:</strong> ' + esc(p.note) + '</div>' : '') +
            '</div>' +
            
            '<div class="doc-amount-box">' +
                '<div class="amount-row"><span>قيمة الفاتورة:</span><span>' + formatCurrency(p.invoiceTotal || 0, p.currency) + '</span></div>' +
                '<div class="amount-row"><span>المدفوع سابقاً:</span><span>' + formatCurrency(p.paidBefore || 0, p.currency) + '</span></div>' +
                '<div class="amount-row" style="font-weight:bold;font-size:16px;border-top:2px solid #1a1a2e;padding-top:8px;margin-top:4px;">' +
                    '<span>المبلغ المدفوع:</span>' +
                    '<span style="color:#1a7a4a;">' + formatCurrency(p.amount || 0, p.currency) + '</span>' +
                '</div>' +
                '<div class="amount-row"><span>المتبقي:</span>' +
                    '<span class="' + ((p.remainingAfter || 0) > 0 ? 'balance-negative' : 'balance-positive') + '">' +
                        formatCurrency(p.remainingAfter || 0, p.currency) +
                    '</span>' +
                '</div>' +
            '</div>' +
            
            '<div class="doc-footer">' +
                'شكراً لتعاملكم معنا' +
                '<small>هذا المستند معتمد رقمياً</small>' +
            '</div>' +
        '</div>';
}


// ================================================================
// ===== 10. حذف سند الصرف =====
// ================================================================

function deletePayment(id) {
    var payment = payments.find(function(p) { return p.id === id; });
    if (!payment) return;
    
    // ✅ السندات الملغاة: لا حذف
    if (payment.cancelled || payment.documentStatus === 'cancelled') {
        showToast('السند ملغى بالفعل — لا يمكن حذفه', 'info');
        return;
    }    
    // ✅ السندات التلقائية (المرتبطة بفاتورة نقدية): لا حذف
    if (payment.invoiceId && payment.invoiceId !== '-') {
        var linkedInvoice = purchaseInvoices.find(function(inv) { 
            return inv.id === payment.invoiceId; 
        });
        
        if (linkedInvoice) {
            // تحقق: هل السند تلقائي؟
            var isAuto = payment.note && payment.note.indexOf('دفع نقدي') !== -1;
            
            if (isAuto) {
                showToast(
                    'هذا سند تلقائي مرتبط بفاتورة شراء نقدية (' + linkedInvoice.id + ').\n' +
                    'لا يمكن حذفه مباشرة — لإلغائه، ألغِ الفاتورة المرتبطة.',
                    'error',
                    8000
                );
                return;
            }
        }
    }
    
    // ✅ السند اليدوي: تحويل الحذف إلى إلغاء (بدون حذف فعلي)
    Modal.confirm({
        title: 'تأكيد إلغاء السند',
        message: 
            'لا يمكن حذف السند نهائياً (حسب قواعد النظام المحاسبي).\n\n' +
            'سيتم:\n' +
            '• وسم السند كـ "ملغى"\n' +
            '• الاحتفاظ به في السجل للتدقيق\n' +
            '• تحديث حالة الفاتورة المرتبطة\n\n' +
            'السند: ' + payment.id + '\n' +
            'المبلغ: ' + formatCurrency(payment.amount, payment.currency) + '\n\n' +
            'هل تريد المتابعة؟',
        confirmText: 'إلغاء السند',
        cancelText: 'تراجع',
        confirmColor: 'warning',
        onConfirm: function() {
            // ✅ وسم السند كملغى (بدل الحذف)
            payment.cancelled = true;
            payment.cancelledAt = new Date().toISOString();
            payment.cancelReason = 'إلغاء يدوي من المستخدم';
            payment.documentStatus = 'cancelled';
            payment.sourceStatus = 'cancelled';
            
            savePayments();
            
            // تحديث الفاتورة المرتبطة (إن وُجدت)
            if (payment.invoiceId && payment.invoiceId !== '-') {
                var invoice = purchaseInvoices.find(function(inv) { 
                    return inv.id === payment.invoiceId; 
                });
                
                if (invoice) {
                    // حساب المدفوع من السندات النشطة فقط
                    var totalPaid = payments.filter(function(p) {
                        return p.invoiceId === payment.invoiceId && 
                               !p.isExpense && 
                               !p.cancelled &&
                               p.documentStatus !== 'cancelled';
                    }).reduce(function(s, p) {
                        return s + (parseFloat(p.amount) || 0);
                    }, 0);
                    
                    if (totalPaid >= (parseFloat(invoice.total) || 0)) {
                        invoice.status = 'مسدد';
                    } else if (totalPaid > 0) {
                        invoice.status = 'دفع جزئي';
                    } else {
                        invoice.status = 'غير مسدد';
                    }
                    
                    savePurchaseInvoices();
                }
            }
            // ✅ إلغاء المصروف المرتبط (إن وُجد)
if (payment.isExpense && payment.expenseId) {
    var linkedExpense = expenses.find(function(e) { 
        return e.id === payment.expenseId; 
    });
    if (linkedExpense && !linkedExpense.archived && !linkedExpense.cancelled) {
        linkedExpense.cancelled = true;
        linkedExpense.cancelledAt = new Date().toISOString();
        linkedExpense.cancelReason = 'ملغى بموجب إلغاء سند الصرف ' + payment.id;
        if (typeof saveExpenses === 'function') saveExpenses();
    }
}

            // قيد عكسي
            if (typeof syncJournalAfterMutation === 'function') {
                syncJournalAfterMutation();
            }
            
            // مزامنة مركزية
            if (typeof oaRefreshRelated === 'function') {
                oaRefreshRelated('payment');
            } else {
                renderPayments();
                renderPurchaseInvoices();
                if (typeof updateDashboard === 'function') updateDashboard();
            }
            
            showToast('تم إلغاء السند — يمكن مراجعته في السجل', 'success');
        }
    });
}


// ================================================================
// ===== 11. تهيئة سندات الصرف =====
// ================================================================

function initPayments() {
    loadPayments();
    renderPayments();
    
    var searchEl = document.getElementById('paySearch');
    if (searchEl) {
        searchEl.addEventListener('input', debounce(renderPayments, 300));
    }
    
    console.log('Payments: ' + payments.length + ' سند');
}


// ================================================================
// ===== END OF PAYMENTS.JS =====
// ================================================================
