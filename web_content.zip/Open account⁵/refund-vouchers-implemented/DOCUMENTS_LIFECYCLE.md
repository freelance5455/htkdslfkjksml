markdown
# Open Account — دورة حياة المستندات

> ملف مكمل لـ `ARCHITECTURE.md`.
> يحدد حالات كل مستند، الانتقالات المسموحة والممنوعة، والعلاقات بين المستندات.
> هذا الملف مرجع رسمي — لا يُعدّل إلا بمراجعة محاسبية.

---

## 📌 الفهرس

1. المبادئ الأساسية
2. حالات الفاتورة
3. حالات السند
4. حالات المرتجع
5. علاقات المستندات
6. قواعد الإلغاء
7. قواعد الاسترجاع
8. العملات والدفع
9. دورة الإنتاج
10. المصفوفة النهائية

---

## 0. المبادئ الأساسية

### 0.1 مبدأ عدم الحذف

> **"لا يجوز حذف فاتورة أو سند أو قيد محاسبي بعد ترحيله."**

- المسودة (draft): يمكن إبطالها/تعديلها
- المرحّلة (posted): تُلغى بقيد عكسي

### 0.2 عملية الإلغاء
الفاتورة الأصلية تبقى محفوظة
↓
تتحول إلى cancelled
↓
إنشاء قيد عكسي كامل للفاتورة
↓
عكس حركة المخزون
↓
عكس أثر العميل/المورد
↓
معالجة السندات المرتبطة:

السند التلقائي (نقدي) → يُلغى

السند اليدوي (فعلي) → يبقى نشطاً

text

### 0.3 نموذج 3 أبعاد

بدل: `status: "partial_paid"`

نستخدم:
- `documentStatus`: draft | posted | cancelled
- `paymentStatus`: unpaid | partial | paid
- `returnStatus`: none | partial | full

### 0.4 السند المالي الحقيقي

سند القبض/الصرف اليدوي يمثل **واقعة مالية حقيقية**. لا يُلغى بسبب إلغاء الفاتورة اللاحق.

**النتيجة:**

- الفاتورة تُلغى
- السند **يبقى نشطاً**
- العميل/المورد يظهر بـ**رصيد دائن**
- عند رد المال فعلاً → يُنشأ سند مستقل

---

## 1. حالات الفاتورة

### 1.1 الأبعاد الثلاثة

**documentStatus:**
| القيمة | الوصف |
|--------|-------|
| draft | مسودة |
| posted | مرحّلة |
| cancelled | ملغاة |

**paymentStatus:**
| القيمة | الوصف |
|--------|-------|
| unpaid | غير مسددة |
| partial | جزئي |
| paid | كلي |

**returnStatus:**
| القيمة | الوصف |
|--------|-------|
| none | لا مرتجعات |
| partial | جزئي |
| full | كلي |

### 1.2 الانتقالات المسموحة
draft → posted
posted → cancelled
draft → cancelled
cancelled → ❌ نهائية

text

### 1.3 الانتقالات الممنوعة

- cancelled → posted
- cancelled → paid
- paid → draft
- draft → paid
- draft → partial_returned

### 1.4 الحقول الإلزامية

```javascript
{
    id: "INV-XXX",
    type: "sales" | "purchase",
    date: "2026-10-05",
    currency: "SAR",
    exchangeRate: 1,
    exchangeRateDate: "2026-10-05",
    subtotal: 1000,
    discount: 0,
    total: 1000,
    documentStatus: "posted",
    paymentStatus: "unpaid",
    returnStatus: "none",
    cancelled: false,
    cancelledAt: null,
    cancelReason: null,
    cancelledBy: null,
    journalEntryId: "JE-XXX",
    reversalEntryId: null,
    linkedReceiptIds: [],
    linkedPaymentIds: [],
    linkedReturnIds: []
}
1.5 قاعدة الإلغاء
الشرط	الإجراء
draft	إبطال (حذف)
posted + لا سندات + لا مرتجعات	إلغاء بسيط
posted + سند تلقائي	إلغاء + عكس السند التلقائي
posted + سند يدوي	إلغاء — السند يبقى
posted + مرتجعات	معالجة المرتجعات أولاً
cancelled	ممنوع
2. حالات السند
2.1 الأنواع
النوع	الرمز	الاستخدام
سند قبض	receipt	تحصيل من عميل
سند صرف	payment	دفع لمورد
مصروف	expense	دفع مصروف (isExpense: true)
2.2 الأبعاد الثلاثة
documentStatus: draft | posted | cancelled

linkStatus:

القيمة	الوصف
standalone	سند مستقل
linked	مرتبط بفاتورة
sourceStatus:

القيمة	الوصف
active	الفاتورة نشطة
cancelled	الفاتورة ملغاة
n/a	لا ارتباط
2.3 الحقول الإلزامية
javascript
{
    id: "REC-XXX" | "PAY-XXX",
    kind: "receipt" | "payment",
    date: "2026-10-05",
    amount: 500,
    currency: "SAR",
    exchangeRate: 1,
    exchangeRateDate: "2026-10-05",
    documentStatus: "posted",
    linkStatus: "linked" | "standalone",
    sourceStatus: "active" | "cancelled" | "n/a",
    sourceType: "sales_invoice" | "purchase_invoice" | null,
    sourceId: "INV-XXX" | null,
    sourceInvoiceId: "INV-XXX" | null,
    method: "نقدي" | "تحويل بنكي" | "بطاقة",
    customerId: "CUST-XXX" | null,
    customerName: "أحمد" | null,
    supplierId: "SUP-XXX" | null,
    supplierName: "مورد" | null,
    note: "",
    isExpense: false,
    expenseId: "EXP-XXX" | null,
    expenseType: null,
    cancelled: false,
    cancelledAt: null,
    cancelReason: null,
    journalEntryId: "JE-XXX",
    reversalEntryId: null
}
2.4 القيود المحاسبية
سند قبض نقدي:

text
مدين: الصندوق (1000)
دائن: العملاء (1100)
سند قبض بنكي:

text
مدين: البنك (1010)
دائن: العملاء (1100)
سند صرف نقدي:

text
مدين: الموردين (2000)
دائن: الصندوق (1000)
سند صرف بنكي:

text
مدين: الموردين (2000)
دائن: البنك (1010)
سند مصروف:

text
مدين: المصاريف (6000)
دائن: الصندوق/البنك (1000/1010)
3. حالات المرتجع
3.1 الفرق بين المرتجع والإلغاء
العنصر	الإلغاء	المرتجع
السبب	خطأ	إعادة فعلية
الفاتورة الأصلية	ملغاة	تبقى نشطة
المستند	قيد عكسي	سند مستقل
النطاق	كامل	جزئي أو كامل
القاعدة:

"الفاتورة الخاطئة → إلغاء. الفاتورة الصحيحة + إعادة → مرتجع."

3.2 الأنواع
النوع	الرمز
مرتجع مبيعات	sale_return
مرتجع مشتريات	purchase_return
3.3 الأبعاد الثلاثة
documentStatus: draft | posted | cancelled

returnScope:

القيمة	الوصف
partial	جزئي
full	كامل
settlementStatus:

القيمة	الوصف
pending	لم تُسوّ
settled	تمت
n/a	لا تحتاج
3.4 الحقول الإلزامية
javascript
{
    id: "RET-XXX",
    kind: "sale_return" | "purchase_return",
    date: "2026-10-05",
    documentStatus: "posted",
    returnScope: "partial" | "full",
    settlementStatus: "pending" | "settled" | "n/a",
    originalInvoiceId: "INV-XXX",
    originalInvoiceType: "sales_invoice" | "purchase_invoice",
    originalInvoiceDate: "2026-10-01",
    items: [
        {
            productId: "P001",
            productName: "منتج",
            returnedQty: 2,
            originalQty: 10,
            unit: "قطعة",
            returnUnitPrice: 100,
            returnCOGS: 60,
            lineTotal: 200
        }
    ],
    totalReturned: 200,
    totalCOGS: 120,
    currency: "SAR",
    exchangeRate: 1,
    exchangeRateDate: "2026-10-05",
    settlementMethod: "cash_refund" | "bank_refund" | "reduce_debt" | "credit_note",
    settlementDate: null,
    settlementReferenceId: null,
    partyId: "CUST-001" | "SUP-001",
    partyName: "أحمد" | "مورد",
    cancelled: false,
    cancelledAt: null,
    cancelReason: null,
    journalEntryId: "JE-XXX",
    reversalEntryId: null,
    linkedPaymentId: null,
    linkedReceiptId: null,
    note: ""
}
3.5 طرق التسوية
مرتجع مبيعات:

الطريقة	القيد	سند؟
cash_refund	مدين: مردودات / دائن: الصندوق	سند صرف
bank_refund	مدين: مردودات / دائن: البنك	سند صرف
reduce_debt	مدين: مردودات / دائن: العملاء	لا
credit_note	مدين: مردودات / دائن: العملاء	لا
مرتجع مشتريات:

الطريقة	القيد	سند؟
cash_received	مدين: الصندوق / دائن: المخزون	سند قبض
bank_received	مدين: البنك / دائن: المخزون	سند قبض
reduce_debt	مدين: الموردين / دائن: المخزون	لا
3.6 القيود
مرتجع مبيعات:

text
مدين: مردودات المبيعات (4010)   lineTotal
دائن: العملاء/الصندوق (1100/1000)        lineTotal

مدين: المخزون (1200)            returnCOGS
دائن: COGS (5000)                       returnCOGS
مرتجع مشتريات:

text
مدين: الموردين/الصندوق (2000/1000)  lineTotal
دائن: المخزون (1200)                     lineTotal
3.7 قاعدة returnCOGS
المصادر بالترتيب:

cogsUnitCost من الفاتورة الأصلية

avgCost التاريخي

تقديري (مع وسم estimated)

القاعدة:

"لا تستخدم تكلفة المخزون الحالية للمرتجعات."

3.8 منع المرتجع المزدوج
javascript
var previousReturns = returnsDocs
    .filter(r => 
        r.originalInvoiceId === invoiceId && 
        r.documentStatus !== 'cancelled' &&
        r.items.some(i => i.productId === productId)
    )
    .reduce((sum, r) => {
        var item = r.items.find(i => i.productId === productId);
        return sum + (item ? item.returnedQty : 0);
    }, 0);

var available = originalQty - previousReturns;
if (newQty > available) throw new Error('تجاوز المتاح: ' + available);
4. علاقات المستندات
4.1 حقول الربط الموحدة
الحقل	الوصف
sourceType	نوع المصدر
sourceId	معرّف المصدر
sourceInvoiceId	الفاتورة الأصلية
reversalOf	القيد الأصلي (في العكسي)
reversalEntryId	القيد العكسي (في الأصلي)
originalInvoiceId	الفاتورة الأصلية (في المرتجع)
linkedReceiptIds	مصفوفة السندات
linkedPaymentIds	مصفوفة سندات الصرف
linkedReturnIds	مصفوفة المرتجعات
4.2 جدول العلاقات
المستند	الحقل	الغرض
فاتورة	journalEntryId	ربط بالقيد
فاتورة	reversalEntryId	ربط بقيد الإلغاء
فاتورة	linkedReceiptIds	سندات التحصيل
فاتورة	linkedPaymentIds	سندات الدفع
فاتورة	linkedReturnIds	المرتجعات
سند	journalEntryId	ربط بالقيد
سند	sourceInvoiceId	الفاتورة المرتبطة
قيد	referenceId	المستند المصدر
قيد	referenceType	نوع المصدر
قيد	reversalOf	القيد الأصلي
مرتجع	originalInvoiceId	الفاتورة الأصلية
مرتجع	journalEntryId	قيد المرتجع
4.3 أنواع sourceType
text
sales_invoice | purchase_invoice | receipt | payment | expense
sale_return | purchase_return | transfer | direct | production | stock_adjustment
4.4 أنواع referenceType
text
sales_invoice | purchase_invoice | receipt | payment | expense
return_sale | return_purchase | invoice_cancellation
transfer | direct | production
stock_adjustment_in | stock_adjustment_out
5. قواعد الإلغاء
5.1 المبدأ
"الإلغاء = عكس كامل للآثار + الحفاظ على السجل"

5.2 شروط الإلغاء
Checklist:

المستند ليس ملغى

المستند مرحّل

لا مرتجعات نشطة

الكميات كافية للمخزون

السندات التلقائية قابلة للعكس (إن وُجدت)

السندات اليدوية تبقى نشطة (لا تحتاج عكساً)

المستخدم موافق

السبب مسجّل

5.3 خطوات الإلغاء
التحقق

التحقق من المخزون

عكس المخزون

إنشاء قيد عكسي

تحديث القيد الأصلي (reversalEntryId)

معالجة السندات (التلقائي يُلغى، اليدوي يبقى)

تحديث الفاتورة (cancelled)

الحفظ

تحديث الشاشات

5.4 القيود العكسية
إلغاء فاتورة بيع نقدية:

text
مدين: إيرادات المبيعات (4000)   total
دائن: الصندوق (1000)                    total

مدين: المخزون (1200)            cogs
دائن: COGS (5000)                       cogs
إلغاء فاتورة بيع آجلة:

text
مدين: إيرادات المبيعات (4000)   total
دائن: العملاء (1100)                    total

مدين: المخزون (1200)            cogs
دائن: COGS (5000)                       cogs
إلغاء فاتورة شراء نقدية:

text
مدين: الصندوق (1000)            total
دائن: المخزون (1200)                    total
إلغاء فاتورة شراء آجلة:

text
مدين: الموردين (2000)           total
دائن: المخزون (1200)                    total
5.5 معالجة السندات
أ) عند إلغاء فاتورة نقدية (سند تلقائي):

documentStatus → 'cancelled'

sourceStatus → 'cancelled'

cancelReason = "ملغى بموجب إلغاء الفاتورة النقدية XXX"

إنشاء قيد عكسي للسند

ربط القيد العكسي

ب) عند إلغاء فاتورة آجلة مدفوعة (سند يدوي):

لا يُلغى السند — يبقى نشطاً

لا يُنشأ قيد عكسي للسند

العميل يظهر بـرصيد دائن (مبلغ مستحق له)

عند رد المال → يُنشأ سند صرف مستقل

مدين: العملاء

دائن: الصندوق/البنك

audit يُظهر "رصيد دائن لعميل" كمعلومة

ج) عند إلغاء فاتورة آجلة غير مدفوعة:

لا يوجد سند

لا معالجة إضافية

5.6 العلاقة المتبادلة
text
الأصلي: { reversalEntryId: "JE-000002" }
العكسي: { reversalOf: "JE-000001" }
6. قواعد الاسترجاع
6.1 المبدأ
"الاسترجاع ≠ الإلغاء"

6.2 خطوات الاسترجاع
التحقق

حساب الكميات (available = original - previousReturns)

حساب التكاليف (returnCOGS)

تعديل المخزون

إنشاء قيد المرتجع (أساسي + COGS)

إنشاء سند الرد (إن اختير)

تحديث الفاتورة (returnStatus + linkedReturnIds)

الحفظ

تحديث الشاشات

6.3 تحديث returnStatus
javascript
var totalReturned = returnsDocs
    .filter(r => r.originalInvoiceId === invoiceId && r.documentStatus !== 'cancelled')
    .reduce((sum, r) => sum + r.totalReturned, 0);

if (totalReturned >= invoice.total) {
    invoice.returnStatus = 'full';
} else if (totalReturned > 0) {
    invoice.returnStatus = 'partial';
} else {
    invoice.returnStatus = 'none';
}
6.4 إلغاء المرتجع
عكس القيد الأساسي

عكس قيد المخزون

إلغاء سند الرد (إن وُجد)

تحديث الفاتورة (returnStatus)

وسم المرتجع كملغى

لا حذف

7. العملات والدفع
7.1 المبدأ
"لا نُعيد تقييم العملية التاريخية بسعر الصرف الحالي."

7.2 الحقول الإلزامية
javascript
{
    currency: "SAR",
    exchangeRate: 1,
    exchangeRateDate: "2026-10-05",
    baseCurrency: "SAR",
    total: 1000,
    totalBase: 1000
}
7.3 في القيود
javascript
{
    debit: 50000,      // العملة الأصلية
    debitBase: 100,    // العملة الأساسية
    credit: 0,
    creditBase: 0
}
7.4 فروقات العملة عند السداد
مثال:

text
فاتورة: 50,000 YER (سعر 500) = 100 SAR
السداد: سعر 550 → 90.91 SAR
الفرق: 9.09 SAR
القيد:

text
مدين: الموردين (2000)          50,000 YER (100 SAR)
دائن: الصندوق (1000)                   50,000 YER (90.91 SAR)
دائن: أرباح فروقات العملة (4200)       9.09 SAR
7.5 حسابات فروقات العملة
4200: أرباح فروقات العملة (revenue)

7000: خسائر فروقات العملة (expense)

تدخل في:

netProfit ✅

grossProfit ❌

8. دورة الإنتاج
8.1 المبدأ
"دورة الإنتاج = تحويل خام → منتج تام"

8.2 أنواع المخزون
raw: مادة خام (تُستهلك في الإنتاج)

finished: منتج تام (يُباع)

8.3 وصفة الإنتاج (BOM)
javascript
{
    id: "BOM-XXX",
    productId: "P-FINISHED-XXX",
    productName: "منتج تام",
    outputQty: 1,
    outputUnit: "قطعة",
    materials: [
        {
            materialId: "P-RAW-XXX",
            qty: 5,
            unit: "كجم",
            wastagePercent: 0
        }
    ],
    additionalCosts: {
        labor: 0,
        overhead: 0,
        other: 0
    }
}
8.4 سند الإنتاج
javascript
{
    id: "PRD-XXX",
    date: "2026-10-05",
    documentStatus: "posted",
    bomId: "BOM-XXX",
    bomProductId: "P-FINISHED-XXX",
    outputQty: 10,
    totalOutputQty: 10,
    consumedMaterials: [
        {
            materialId: "P-RAW-XXX",
            requiredQty: 50,
            actualQty: 50,
            unitCost: 10,
            totalCost: 500
        }
    ],
    laborCost: 0,
    overheadCost: 0,
    otherCost: 0,
    totalMaterialCost: 600,
    totalProductionCost: 600,
    unitProductionCost: 60,
    journalEntryId: "JE-XXX",
    stockMovementsIn: [],
    stockMovementsOut: [],
    cancelled: false
}
8.5 القيد
text
مدين: المخزون - منتج تام (1200)    totalProductionCost
دائن: المخزون - مواد خام (1200)              totalProductionCost
8.6 خطوات التنفيذ
التحقق (BOM + خام متوفر)

حساب الكميات

حساب التكاليف

استهلاك الخام

إضافة المنتج التام

إنشاء القيد

الحفظ

8.7 إلغاء سند الإنتاج
مسودة: إبطال بسيط

مرحّل + لم يُبَع المنتج: عكس كامل

مرحّل + بِيع المنتج: ممنوع (فحص المخزون)

9. المصفوفة النهائية
9.1 مصفوفة الفاتورة
documentStatus	paymentStatus	returnStatus	مسموح؟
draft	unpaid	none	✅
posted	unpaid	none	✅
posted	partial	none	✅
posted	paid	none	✅
posted	unpaid	partial	✅
posted	partial	partial	✅
posted	paid	partial	✅
posted	paid	full	✅
cancelled	-	-	✅ (نهائي)
9.2 مصفوفة السند
documentStatus	linkStatus	sourceStatus
draft	standalone	n/a
draft	linked	active
posted	standalone	n/a
posted	linked	active
posted	linked	cancelled
cancelled	-	-
9.3 مصفوفة المرتجع
documentStatus	returnScope	settlementStatus
draft	partial	pending
draft	full	pending
posted	partial	pending
posted	partial	settled
posted	full	settled
cancelled	-	-
9.4 الممنوعات
cancelled → أي انتقال

draft → paid مباشرة

paid → draft

مرتجع لفاتورة ملغاة

سند لفاتورة ملغاة

إلغاء سند مالي يدوي تلقائياً بسبب إلغاء فاتورة

10. قواعد إلزامية شاملة
كل عملية → قيد في journalEntries

كل قيد → referenceId + referenceType

لا حذف — فقط حالات

العلاقة المتبادلة للأصل والعكس

المصفوفات للعلاقات المتعددة

returnCOGS إلزامي للمرتجعات

exchangeRate محفوظ لكل عملية بعملة

التقارير الرسمية من القيود

لا إعادة تقييم للعمليات التاريخية

حماية Audit Trail

السند المالي اليدوي لا يُلغى بسبب إلغاء الفاتورة

الرصيد السالب = رصيد دائن للعميل/لنا عند المورد

آخر تحديث: 2026-10-08
الإصدار: v2.0
الحالة: معتمد — متوافق مع القاعدة المحاسبية الجديدة

text

---

## 📋 خطوات التنفيذ

### 1) `ARCHITECTURE.md`

- افتح الملف
- احذف كل شيء
- الصق النسخة الجديدة
- احفظ

### 2) `DOCUMENTS_LIFECYCLE.md`

- افتح الملف
- احذف كل شيء
- الصق النسخة الجديدة
- احفظ

---

## 📊 ملخص التغييرات

| # | الملف | الإصدار القديم | الإصدار الجديد |
|---|-------|----------------|-----------------|
| 1 | `ARCHITECTURE.md` | v1.0 | **v2.0** |
| 2 | `DOCUMENTS_LIFECYCLE.md` | v1.0 | **v2.0** |

**التغييرات الجوهرية:**

- ✅ إضافة مبدأ "السند المالي الحقيقي لا يُلغى"
- ✅ تفصيل معالجة السندات (تلقائي vs يدوي)
- ✅ تحديث شروط الإلغاء
- ✅ تحديث المصفوفات
- ✅ إضافة قواعد إلزامية جديدة

*


=================================================
# خلل بنيوي في تقييم المخزون وإلغاء سند الإنتاج

## الحالة
موثّق — الإصلاح البنيوي مؤجل.

## المشكلات المكتشفة

1. حركات الإنتاج في stockMovements تسجّل price من سعر المنتج،
   وليس من تكلفة المخزون الفعلية.

2. حركات إلغاء الإنتاج لا تتضمن بيانات تكلفة كافية
   لإعادة بناء متوسط التكلفة.

3. applyWeightedAverageCost() تعتمد على حالة المنتج الحالية،
   وقد يؤدي إلغاء الإنتاج دون استعادة صحيحة إلى تراكم الخطأ.

4. generateAllJournalEntries() تحتفظ بالقيود التاريخية،
   لكن الكود لا ينشئ قيداً عكسياً عند إلغاء سند الإنتاج.

5. لا يمكن ضمان مطابقة المخزون مع حساب 1200
   بمجرد إعادة ضبط avgCost وحده.

## الإجراء المؤقت
- الاحتفاظ بنسخة احتياطية كاملة من بيانات الاختبار.
- توثيق فرق المخزون الحالي (22.89 SAR) وعدم اعتباره مطابقة ناجحة.
- تنفيذ التصفير بعد الموافقة.
- عدم اعتماد النظام للاستخدام الفعلي قبل إكمال الإصلاح البنيوي.

## الإصلاح المطلوب
- توحيد تسجيل تكلفة المخزون في حركاته.
- إنشاء قيود عكسية صحيحة عند إلغاء الإنتاج.
- إعادة تقييم المخزون وفق الحركات المعتمدة.
- اختبار الإنتاج والإلغاء مع الحالات المعقدة.
- مطابقة المخزون مع 1200 وميزان المراجعة.