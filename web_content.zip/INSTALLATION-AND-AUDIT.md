# ANONYMOUX STUDIOS 2.4.0 — Installation & Operations

## 1. Hosting requirements

- PHP 8.x
- PDO with `pdo_sqlite` (or PDO MySQL with InnoDB)
- OpenSSL
- cURL
- PHP sessions
- HTTPS enabled
- Writable private `storage/` directory

No Node.js, Composer runtime, Docker, cron or background worker is required.

## 2. Deploy

1. Back up the current site, database (`storage/workspace.sqlite` if SQLite), uploaded media and private configuration.
2. Extract the complete ZIP into the document root or a subdirectory.
3. Preserve `.htaccess` and `storage/.htaccess`. Do not make `storage/` publicly readable.
4. The ZIP already includes a generated private `config.local.php` containing a cryptographically random 256-bit encryption key. No manual encryption-key setup is needed to start the application.
5. Keep `config.local.php` private and back it up securely. Do not regenerate or replace its key after storing encrypted API/payment credentials. If you have an existing deployment with encrypted credentials, preserve its original `config.local.php` rather than overwriting it with this build's file.
6. Add your Decart/Magic Hour credentials to the private configuration or their admin settings as required by your existing workspaces.
7. Confirm the PHP extensions and writable storage permissions.
8. Open the application. Additive schema creation is performed by the application. If your process manages migrations manually, run only the SQL file matching your database driver under `migrations/`.

## 3. First administrator

- With no administrator in the users table, the first successfully inserted account becomes `admin`.
- All later registrations become `member`; request parameters and frontend fields cannot override this.
- Existing administrator accounts are not overwritten.
- For recovery, use the hosting control panel terminal/CLI:
  `php tools-recover-admin.php account@example.com`
- The recovery script refuses web requests. Run it only from a trusted hosting CLI and remove it if your operational policy requires.

## 4. Configure Flutterwave

1. Sign in as administrator and open Admin → Payments.
2. Set the Flutterwave public key, secret key and webhook secret hash. Secret fields are encrypted using the configured application encryption secret and are write-only.
3. Choose the matching test/live mode and currency. NGN is supported.
4. Create one or more credit packages. Price is entered in major currency units; the stored amount is normalized to minor units (kobo for NGN).
5. Keep the gateway disabled until test credentials are configured.
6. Use **Test Flutterwave connection** to check server-to-provider authentication.
7. Configure the Flutterwave webhook URL as `https://your-domain.example/api/flutterwave-webhook.php` (include any deployment subdirectory).
8. Set the same webhook secret hash in Flutterwave and in Admin → Payments.
9. Run a provider test payment in Flutterwave's test environment. Confirm the payment order, transaction ledger and user's wallet before enabling live mode.

The redirect is not trusted to award credits. The server independently verifies transaction status, reference, amount and currency. The webhook signature is checked before the same server-side verification path is used. Duplicate notifications do not award duplicate credits.

## 5. Audit and verification documents

- `SOURCE-AUDIT-REPORT-2.4.0.md`
- `FILE-CLEANUP-REPORT-2.4.0.md`
- `TEST-AND-VERIFICATION-REPORT-2.4.0.md`

The reports clearly distinguish static checks from untested database/provider/hosting behavior.
