#!/system/bin/sh
# C13_disable_hw_overlays — disable hw overlays
# Disable HW overlays so SurfaceFlinger uses the GPU compositor — usually smoother when the GPU is under-utilised.
MODULE_ID="C13_disable_hw_overlays"
. "$(dirname "$0")/../lib/core.sh"
vcg_init
apply() {
    vcg_apply_or_skip C13_ENABLED || return 0
    vcg_put global overlay_disable_forced_hw 1
}
revert() {
    vcg_restore_setting global overlay_disable_forced_hw
}
case "${1:-apply}" in apply) apply ;; revert) revert ;; *) exit 1 ;; esac
