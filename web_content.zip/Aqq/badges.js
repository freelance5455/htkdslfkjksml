// badges.js — Badges de CONTAGEM na navegação do BookErth
// - home:      nº de publicações novas (mostra "+5" quando há mais de 5)
// - biblioteca:nº de livros novos (mostra "+5" quando há mais de 5)
// - aulas:     nº de aulas novas
// - clubes:    nº de atualizações novas (clubes + posts + chat)
// - sino:      notificações por ler (votos, comentários, atualizações...)
//
// Uso: basta incluir <script type="module" src="js/badges.js"></script> antes de </body>.
// Os links/botões devem ter o atributo data-badge="home|biblioteca|aulas|clubes|sino".

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getFirestore, collection, query, orderBy, limit, onSnapshot, where
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAz5VJZ-8L-zJsM44n-jiyzNb6-3IrHlfA",
  authDomain: "socialnob.firebaseapp.com",
  projectId: "socialnob",
  storageBucket: "socialnob.firebasestorage.app",
  messagingSenderId: "344519611677",
  appId: "1:344519611677:web:8360c1317a30d0e67f7df4",
  measurementId: "G-LV7VH1HKCS"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const LS_KEY = 'be_badges_v2';

// ---------- persistência da "última visita" ----------
function getSeen() {
  try { return JSON.parse(localStorage.getItem(LS_KEY) || '{}'); } catch (e) { return {}; }
}
function setSeen(key, ts) {
  const d = getSeen(); d[key] = ts;
  localStorage.setItem(LS_KEY, JSON.stringify(d));
}
export function markSeenNow(key) {
  setSeen(key, Date.now());
  setBadge(key, '');
}

function getTs(f) {
  if (!f) return 0;
  if (f.toMillis) return f.toMillis();
  const d = new Date(f);
  return isNaN(d) ? 0 : d.getTime();
}

// ---------- formato do número ----------
function fmtCount(n, plus5) {
  if (n <= 0) return '';
  if (plus5 && n > 5) return '+5';
  return n > 99 ? '99+' : String(n);
}

// ---------- pinta o badge em TODOS os elementos com esse data-badge ----------
function setBadge(key, text) {
  document.querySelectorAll('[data-badge="' + key + '"]').forEach(el => {
    let b = el.querySelector('.nav-badge');
    if (!b) {
      b = document.createElement('span');
      b.className = 'nav-badge';
      el.appendChild(b);
    }
    if (text) { b.textContent = text; b.style.display = 'flex'; }
    else b.style.display = 'none';
  });
}

// ---------- contagem genérica: docs novos desde a última visita ----------
function listenNew(key, col, plus5) {
  onSnapshot(
    query(collection(db, col), orderBy('criadoEm', 'desc'), limit(60)),
    snap => {
      const seen = getSeen()[key] || 0;
      let n = 0;
      snap.forEach(d => {
        const ts = getTs(d.data().criadoEm || d.data().createdAt);
        if (ts > seen) n++;
      });
      setBadge(key, fmtCount(n, plus5));
    },
    err => console.log('Badge ' + key + ':', err.message)
  );
}

// ---------- clubes: soma de clubes + posts + chat ----------
function listenClubUpdates() {
  const state = { clubes: 0, posts: 0, chat: 0 };
  const paint = () => {
    const seen = getSeen().clubes || 0;
    void seen;
    setBadge('clubes', fmtCount(state.clubes + state.posts + state.chat, false));
  };
  const counter = snap => {
    const seen = getSeen().clubes || 0;
    let n = 0;
    snap.forEach(d => { if (getTs(d.data().criadoEm) > seen) n++; });
    return n;
  };
  onSnapshot(query(collection(db, 'clubes'), orderBy('criadoEm', 'desc'), limit(60)),
    s => { state.clubes = counter(s); paint(); }, e => console.log('Badge clubes:', e.message));
  onSnapshot(query(collection(db, 'clubePosts'), orderBy('criadoEm', 'desc'), limit(60)),
    s => { state.posts = counter(s); paint(); }, e => console.log('Badge clubePosts:', e.message));
  onSnapshot(query(collection(db, 'clubeChat'), orderBy('criadoEm', 'desc'), limit(60)),
    s => { state.chat = counter(s); paint(); }, e => console.log('Badge clubeChat:', e.message));
}

// ---------- sino: notificações por ler ----------
function listenSino(uid) {
  onSnapshot(
    query(collection(db, 'notificacoes'), where('destinatario', '==', uid)),
    snap => {
      let n = 0;
      snap.forEach(d => { if (d.data().lida === false) n++; });
      setBadge('sino', fmtCount(n, false));
    },
    err => console.log('Badge sino:', err.message)
  );
}

// ---------- init ----------
export function initBadges() {
  onAuthStateChanged(auth, user => {
    if (!user) return;
    listenNew('home', 'posts', true);
    listenNew('biblioteca', 'livros', true);
    listenNew('aulas', 'aulas', false);
    listenClubUpdates();
    listenSino(user.uid);
  });
}

initBadges();

// Ao clicar num item do menu: marca como "visto" e limpa o badge
document.addEventListener('click', e => {
  const link = e.target.closest('[data-badge]');
  if (!link) return;
  const key = link.dataset.badge;
  if (!key) return;
  setSeen(key, Date.now());
  setBadge(key, '');
});
