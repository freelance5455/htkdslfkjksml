
// ============================================
// BOOCKERTH - UTILITÁRIOS E SEGURANÇA
// ============================================

/**
 * Sanitiza input para prevenir XSS
 * @param {string} str - String a sanitizar
 * @returns {string} - String segura
 */
export function sanitizeInput(str) {
  if (typeof str !== 'string') return '';
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/**
 * Escapa HTML para exibição segura
 */
export function escapeHtml(text) {
  if (typeof text !== 'string') return '';
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

/**
 * Valida email
 */
export function isValidEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(String(email).toLowerCase());
}

/**
 * Valida senha (mínimo 6 caracteres)
 */
export function isValidPassword(password) {
  return typeof password === 'string' && password.length >= 6;
}

/**
 * Valida nome (mínimo 2 caracteres)
 */
export function isValidName(name) {
  return typeof name === 'string' && name.trim().length >= 2;
}

/**
 * Valida username (3-30 caracteres, alfanumérico e underscore)
 */
export function isValidUsername(username) {
  const re = /^[a-zA-Z0-9_]{3,30}$/;
  return re.test(String(username));
}

/**
 * Gera username a partir do nome
 */
export function generateUsername(fullName) {
  const base = fullName.toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]/g, '_')
    .replace(/_+/g, '_')
    .replace(/^_|_$/g, '');
  return base.substring(0, 20);
}

/**
 * Conta palavras num texto
 */
export function countWords(text) {
  return text.trim().split(/\s+/).filter(w => w.length > 0).length;
}

/**
 * Trunca texto
 */
export function truncateText(text, maxLength = 100) {
  if (text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
}

/**
 * Formata timestamp relativo
 */
export function timeAgo(date) {
  const now = new Date();
  const diff = Math.floor((now - date) / 1000);

  if (diff < 60) return 'Agora mesmo';
  if (diff < 3600) return `Há ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `Há ${Math.floor(diff / 3600)} h`;
  if (diff < 604800) return `Há ${Math.floor(diff / 86400)} d`;
  return date.toLocaleDateString('pt-PT');
}

/**
 * Rate limiting simples (proteção contra brute force)
 */
export class RateLimiter {
  constructor(key, maxAttempts = 5, windowMs = 60000) {
    this.key = `rate_limit_${key}`;
    this.maxAttempts = maxAttempts;
    this.windowMs = windowMs;
  }

  canProceed() {
    const now = Date.now();
    const data = JSON.parse(localStorage.getItem(this.key) || '{"attempts":0,"firstAttempt":0}');

    if (now - data.firstAttempt > this.windowMs) {
      data.attempts = 0;
      data.firstAttempt = now;
    }

    if (data.attempts >= this.maxAttempts) {
      const waitSeconds = Math.ceil((data.firstAttempt + this.windowMs - now) / 1000);
      return { allowed: false, waitSeconds };
    }

    data.attempts++;
    localStorage.setItem(this.key, JSON.stringify(data));
    return { allowed: true };
  }

  reset() {
    localStorage.removeItem(this.key);
  }
}

/**
 * Toast notification
 */
export function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = {
    info: 'ℹ️',
    success: '✅',
    error: '❌',
    warning: '⚠️'
  };

  toast.innerHTML = `<span>${icons[type] || icons.info}</span> <span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

/**
 * Mostra/esconde spinner num botão
 */
export function setButtonLoading(btn, loading) {
  const originalText = btn.dataset.originalText || btn.innerHTML;
  if (loading) {
    btn.dataset.originalText = originalText;
    btn.innerHTML = '<span class="spinner"></span> Aguarde...';
    btn.disabled = true;
  } else {
    btn.innerHTML = originalText;
    btn.disabled = false;
  }
}

/**
 * Validação de formulário em tempo real
 */
export function setupRealtimeValidation(input, validator, errorMsg) {
  const group = input.closest('.input-group');
  const errorEl = group.querySelector('.error-msg') || document.createElement('span');

  if (!group.querySelector('.error-msg')) {
    errorEl.className = 'error-msg';
    group.appendChild(errorEl);
  }

  input.addEventListener('blur', () => {
    const isValid = validator(input.value);
    if (!isValid && input.value) {
      group.classList.add('has-error');
      errorEl.textContent = errorMsg;
    } else {
      group.classList.remove('has-error');
    }
  });

  input.addEventListener('input', () => {
    if (group.classList.contains('has-error')) {
      const isValid = validator(input.value);
      if (isValid) {
        group.classList.remove('has-error');
      }
    }
  });
}

/**
 * Gera ID único seguro
 */
export function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
}

/**
 * Verifica se é primeira visita ao perfil
 */
export function isFirstProfileVisit() {
  return !localStorage.getItem('boockerth_profile_seen');
}

export function markProfileVisited() {
  localStorage.setItem('boockerth_profile_seen', 'true');
}

/**
 * Armazena escola selecionada temporariamente
 */
export function setTempSchool(school) {
  sessionStorage.setItem('boockerth_temp_school', JSON.stringify(school));
}

export function getTempSchool() {
  const data = sessionStorage.getItem('boockerth_temp_school');
  return data ? JSON.parse(data) : null;
}

export function clearTempSchool() {
  sessionStorage.removeItem('boockerth_temp_school');
}
