
const Seguranca = {
  // Honeypot: campo invisível que bots preenchem
  honeypotField: null,

  initHoneypot() {
    const hp = document.createElement('input');
    hp.type = 'text';
    hp.name = 'website';
    hp.id = 'hp_website';
    hp.style.position = 'absolute';
    hp.style.opacity = '0';
    hp.style.pointerEvents = 'none';
    hp.style.height = '0';
    hp.tabIndex = -1;
    hp.autocomplete = 'off';
    this.honeypotField = hp;
    document.body.appendChild(hp);
  },

  checkHoneypot() {
    const val = (this.honeypotField?.value || '').trim();
    if (val.length > 0) {
      console.warn('Honeypot preenchido — possível bot detectado.');
      return false;
    }
    return true;
  },

  // Rate limiting por IP/localStorage
  canProceed(action, max = 5, windowMs = 60000) {
    const key = 'be_rate_' + action;
    const now = Date.now();
    let log = [];
    try { log = JSON.parse(localStorage.getItem(key) || '[]'); } catch (e) {}
    log = log.filter(t => now - t < windowMs);
    if (log.length >= max) return false;
    log.push(now);
    localStorage.setItem(key, JSON.stringify(log));
    return true;
  },

  // Verificação rigorosa de PDF
  async validarPDF(file) {
    if (!file) return { ok: false, erro: 'Nenhum ficheiro selecionado.' };
    if (file.type !== 'application/pdf') {
      return { ok: false, erro: 'Tipo de ficheiro inválido. Apenas PDFs são permitidos.' };
    }
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      return { ok: false, erro: 'Extensão de ficheiro inválida.' };
    }
    const MAX_SIZE = 50 * 1024 * 1024; // 50 MB
    if (file.size > MAX_SIZE) {
      return { ok: false, erro: 'Ficheiro demasiado grande. Máximo 50 MB.' };
    }
    if (file.size < 1024) {
      return { ok: false, erro: 'Ficheiro demasiado pequeno. Possível vídeo ou ficheiro corrompido.' };
    }

    // Verificar assinatura mágica %PDF
    const header = await file.slice(0, 8).text();
    if (!header.startsWith('%PDF')) {
      return { ok: false, erro: 'Assinatura de PDF inválida. Ficheiro pode estar corrompido ou ser malicioso.' };
    }

    // Verificar conteúdo executável embutido (JavaScript em PDF)
    const text = await file.text();
    const perigosos = [
      '/JS', '/JavaScript', '/OpenAction', '/Launch', '/EmbeddedFile',
      '/XFA', '/RichMedia', '/Flash', '/URI', '/Action'
    ];
    for (const p of perigosos) {
      if (text.includes(p)) {
        console.warn('Elemento suspeito encontrado no PDF:', p);
        // Não bloqueamos automaticamente, apenas alertamos no servidor
      }
    }

    // Verificar se é realmente um documento (não um .exe renomeado)
    const executableSignatures = ['MZ', '\x4d\x5a', '\x7fELF'];
    for (const sig of executableSignatures) {
      if (header.includes(sig)) {
        return { ok: false, erro: 'Ficheiro executável detectado. Upload bloqueado por segurança.' };
      }
    }

    return { ok: true };
  },

  // CSRF token simples
  gerarToken() {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
  },

  salvarToken() {
    const token = this.gerarToken();
    sessionStorage.setItem('be_csrf', token);
    return token;
  },

  validarToken(token) {
    return token && token === sessionStorage.getItem('be_csrf');
  },

  // Sanitização de input
  sanitizar(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  },

  // Verificação de integridade do utilizador
  verificarSessao(user) {
    if (!user || !user.uid || !user.emailVerified && user.providerData?.[0]?.providerId !== 'anonymous') {
      return false;
    }
    return true;
  }
};

window.Seguranca = Seguranca;
