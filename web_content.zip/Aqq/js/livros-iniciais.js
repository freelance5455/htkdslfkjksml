// Livros iniciais da biblioteca curada (BookErth).
// Lista vazia por agora: os 12 clássicos foram removidos porque não têm
// PDF associado (sem mediaUrl não há capa, leitura nem download).
// Para voltar a adicionar um livro aqui, cada entrada precisa de um
// "mediaUrl" com o link Cloudinary real do PDF, por exemplo:
// { id: 'init-republica', titulo: 'A República', autor: 'Platão',
//   categoria: 'Filosofia', preco: 0, rating: 4.9, capaUrl: '', mediaUrl: 'https://res.cloudinary.com/.../a-republica.pdf' }
window.LIVROS_INICIAIS = [];
