
// ============================================
// BOOCKERTH - ALGORITMO DE REPUTAÇÃO
// ============================================
// Cada post: +1 ponto
// Cada voto: +5 pontos  
// Cada comentário: +2 pontos
// ============================================

import { db, collection, query, where, getDocs } from './firebase-config.js';

/**
 * Calcula a reputação de um utilizador em tempo real
 * @param {string} userId - UID do utilizador
 * @returns {Promise<Object>} - Objeto com pontos e detalhes
 */
export async function calcularReputacao(userId) {
  try {
    // Contar posts do utilizador
    const postsQuery = query(
      collection(db, 'posts'),
      where('authorId', '==', userId)
    );
    const postsSnap = await getDocs(postsQuery);
    const postsCount = postsSnap.size;
    const postsPoints = postsCount * 1;

    // Contar votos recebidos nos posts do utilizador
    let votosCount = 0;
    const postsIds = postsSnap.docs.map(d => d.id);

    if (postsIds.length > 0) {
      // Firestore limita IN a 10 valores, processamos em batches
      const batchSize = 10;
      for (let i = 0; i < postsIds.length; i += batchSize) {
        const batch = postsIds.slice(i, i + batchSize);
        const votosQuery = query(
          collection(db, 'votos'),
          where('targetId', 'in', batch)
        );
        const votosSnap = await getDocs(votosQuery);
        votosCount += votosSnap.size;
      }
    }
    const votosPoints = votosCount * 5;

    // Contar comentários recebidos nos posts do utilizador
    let comentariosCount = 0;
    if (postsIds.length > 0) {
      const batchSize = 10;
      for (let i = 0; i < postsIds.length; i += batchSize) {
        const batch = postsIds.slice(i, i + batchSize);
        const comentariosQuery = query(
          collection(db, 'comentarios'),
          where('postId', 'in', batch)
        );
        const comentariosSnap = await getDocs(comentariosQuery);
        comentariosCount += comentariosSnap.size;
      }
    }
    const comentariosPoints = comentariosCount * 2;

    // Total
    const totalPoints = postsPoints + votosPoints + comentariosPoints;

    // Determinar nível de reputação
    let nivel = 'Novato';
    let cor = '#9b59b6';

    if (totalPoints >= 500) { nivel = 'Lenda'; cor = '#e74c3c'; }
    else if (totalPoints >= 300) { nivel = 'Mestre'; cor = '#f39c12'; }
    else if (totalPoints >= 150) { nivel = 'Especialista'; cor = '#27ae60'; }
    else if (totalPoints >= 75) { nivel = 'Contribuidor'; cor = '#3498db'; }
    else if (totalPoints >= 25) { nivel = 'Ativo'; cor = '#9b59b6'; }

    return {
      total: totalPoints,
      nivel,
      cor,
      detalhes: {
        posts: { count: postsCount, points: postsPoints },
        votos: { count: votosCount, points: votosPoints },
        comentarios: { count: comentariosCount, points: comentariosPoints }
      }
    };
  } catch (error) {
    console.error('Erro ao calcular reputação:', error);
    return {
      total: 0,
      nivel: 'Novato',
      cor: '#9b59b6',
      detalhes: { posts: { count: 0, points: 0 }, votos: { count: 0, points: 0 }, comentarios: { count: 0, points: 0 } }
    };
  }
}

/**
 * Atualiza a reputação no documento do utilizador
 * @param {string} userId - UID do utilizador
 */
export async function atualizarReputacaoUsuario(userId) {
  try {
    const { doc, updateDoc, getDoc } = await import('./firebase-config.js');
    const reputacao = await calcularReputacao(userId);

    const userRef = doc(db, 'usuarios', userId);
    const userSnap = await getDoc(userRef);

    if (userSnap.exists()) {
      await updateDoc(userRef, {
        reputacao: reputacao.total,
        reputacaoNivel: reputacao.nivel,
        reputacaoAtualizada: new Date()
      });
    }

    return reputacao;
  } catch (error) {
    console.error('Erro ao atualizar reputação do utilizador:', error);
    throw error;
  }
}

/**
 * Listener em tempo real para atualizações de reputação
 * @param {string} userId - UID do utilizador
 * @param {Function} callback - Função chamada quando a reputação muda
 * @returns {Function} - Função para cancelar o listener
 */
export function onReputacaoChange(userId, callback) {
  // Atualiza a cada 30 segundos (Firestore não suporta agregações em tempo real eficientemente)
  const interval = setInterval(async () => {
    const rep = await calcularReputacao(userId);
    callback(rep);
  }, 30000);

  // Primeira chamada imediata
  calcularReputacao(userId).then(callback);

  return () => clearInterval(interval);
}
