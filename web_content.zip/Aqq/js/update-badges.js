/**
 * BookErth - Badges de Atualizações
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore, collection, query, where, onSnapshot } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAz5VJZ-8L-zJsM44n-jiyzNb6-3IrHlfA",
  authDomain: "socialnob.firebaseapp.com",
  projectId: "socialnob",
  storageBucket: "socialnob.firebasestorage.app",
  messagingSenderId: "344519611677",
  appId: "1:344519611677:web:8360c1317a30d0e67f7df4",
  measurementId: "G-LV7VH1HKCS"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

class UpdateBadges {
  constructor() {
    this.badges = { correio: document.getElementById('badgeCorreio'), colegas: document.getElementById('badgeColegas'), notificacoes: document.getElementById('badgeNotificacoes') };
    this.unsubscribers = [];
  }
  init(user) {
    if (!user) return;
    this.listenCorreio(user.uid);
    this.listenColegas(user.uid);
    this.listenNotificacoes(user.uid);
  }
  updateBadge(element, count) {
    if (!element) return;
    if (count > 0) { element.textContent = count > 99 ? '99+' : count; element.classList.remove('hidden'); element.style.animation = 'none'; element.offsetHeight; element.style.animation = 'pulse 0.4s ease'; }
    else { element.classList.add('hidden'); }
  }
  listenCorreio(uid) {
    const q = query(collection(db, 'cartas'), where('destinatarioId', '==', uid), where('lida', '==', false));
    const unsub = onSnapshot(q, (snap) => { this.updateBadge(this.badges.correio, snap.size); });
    this.unsubscribers.push(unsub);
  }
  listenColegas(uid) {
    const q = query(collection(db, 'conexoes'), where('destinatarioId', '==', uid), where('estado', '==', 'pendente'));
    const unsub = onSnapshot(q, (snap) => { this.updateBadge(this.badges.colegas, snap.size); });
    this.unsubscribers.push(unsub);
  }
  listenNotificacoes(uid) {
    const q = query(collection(db, 'notificacoes'), where('destinatario', '==', uid), where('lida', '==', false));
    const unsub = onSnapshot(q, (snap) => {
      if (this.badges.notificacoes) this.updateBadge(this.badges.notificacoes, snap.size);
      document.title = snap.size > 0 ? `(${snap.size}) BookErth` : 'BookErth';
    });
    this.unsubscribers.push(unsub);
  }
  destroy() { this.unsubscribers.forEach(unsub => unsub()); this.unsubscribers = []; }
}

const badges = new UpdateBadges();
onAuthStateChanged(auth, (user) => { if (user) badges.init(user); });
export { UpdateBadges };
