/*!
 * webview-permissoes.js  v1.0
 * ------------------------------------------------------------------
 * Plugin leve para páginas que correm em WebView dentro de um APK.
 *
 * O que faz:
 *  1) Pede as permissões necessárias (fotos/ficheiros e, opcionalmente,
 *     câmara) APENAS NA PRIMEIRA VEZ que o utilizador tenta escolher um
 *     ficheiro. Depois disso nunca mais pergunta.
 *  2) Funciona sozinho: intercepta <input type="file"> (cliques diretos,
 *     <label> e input.click() por JS), pede a permissão e reabre o seletor.
 *  3) Torna o seletor mais fiável em WebView (inputs criados por JS ficam
 *     ligados ao documento até o utilizador escolher ou cancelar).
 *  4) Expõe window.WVPermissoes com funções auxiliares.
 *
 * Fora de um APK (navegador normal) não faz nada.
 *
 * Suporta (se existirem no APK):
 *   - Capacitor  (plugins Camera / Filesystem)
 *   - Cordova    (cordova-plugin-android-permissions)
 *   - Ponte própria: WVPermissoes.config.ponteNativa = function (tipo) {...}
 *   - WebView simples: pedido de câmara via getUserMedia (o app tem de o permitir)
 * ------------------------------------------------------------------
 */
(function (global) {
  'use strict';

  if (global.WVPermissoes || !global.HTMLInputElement) return;

  var CONFIG = {
    chave: 'wvperm_pedido_v1',   // marca "já pedi" no localStorage
    camera: true,                // false = nunca pedir câmara
    ponteNativa: null            // function (tipo) -> Promise; para APKs com ponte própria
  };

  var doc = global.document;
  var ua = (global.navigator && global.navigator.userAgent) || '';
  var origClick = global.HTMLInputElement.prototype.click;
  var emCurso = null;
  var memoria = false;

  /* ---------------------------- estado ---------------------------- */

  function jaPediu() {
    if (memoria) return true;
    try { return global.localStorage.getItem(CONFIG.chave) === '1'; } catch (e) { return false; }
  }

  function marcarPedido() {
    memoria = true;
    try { global.localStorage.setItem(CONFIG.chave, '1'); } catch (e) {}
  }

  /* ------------------------- deteção de ambiente ------------------------- */

  function capacitorNativo() {
    var c = global.Capacitor;
    if (!c) return null;
    try {
      var nativo = typeof c.isNativePlatform === 'function'
        ? c.isNativePlatform()
        : (typeof c.getPlatform === 'function' && c.getPlatform() !== 'web');
      return nativo ? c : null;
    } catch (e) { return null; }
  }

  function cordovaPermissoes() {
    return (global.cordova && global.cordova.plugins && global.cordova.plugins.permissions) || null;
  }

  function emApp() {
    if (capacitorNativo() || global.cordova || typeof CONFIG.ponteNativa === 'function') return true;
    return /Android/i.test(ua) && (/; wv\)/i.test(ua) || /Version\/[\d.]+.*Chrome/i.test(ua));
  }

  function precisaPedir() {
    return !jaPediu() && emApp();
  }

  /* ----------------------- pedidos de permissão ----------------------- */

  function tentar(fn) {
    return new Promise(function (resolve) {
      try {
        Promise.resolve(fn()).then(function () { resolve(true); }, function () { resolve(false); });
      } catch (e) { resolve(false); }
    });
  }

  function pedirCapacitor(cap, imagem) {
    var P = cap.Plugins || {};
    var tarefas = [];

    if (P.Camera && typeof P.Camera.requestPermissions === 'function') {
      tarefas.push(tentar(function () {
        return P.Camera.requestPermissions({ permissions: CONFIG.camera ? ['camera', 'photos'] : ['photos'] });
      }));
    }
    if (P.Filesystem && typeof P.Filesystem.requestPermissions === 'function') {
      tarefas.push(tentar(function () { return P.Filesystem.requestPermissions(); }));
    }
    if (!tarefas.length) return pedirWeb(imagem);

    return Promise.all(tarefas).then(function () { return { feito: true }; });
  }

  function pedirCordova(perm) {
    var lista = [
      'android.permission.READ_MEDIA_IMAGES',
      'android.permission.READ_EXTERNAL_STORAGE'
    ];
    if (CONFIG.camera) lista.push('android.permission.CAMERA');

    return new Promise(function (resolve) {
      try {
        perm.requestPermissions(
          lista,
          function () { resolve({ feito: true }); },
          function () { resolve({ feito: true }); }
        );
      } catch (e) { resolve({ feito: false }); }
    });
  }

  function pedirWeb(imagem) {
    var md = global.navigator && global.navigator.mediaDevices;
    if (!(imagem && CONFIG.camera && md && typeof md.getUserMedia === 'function')) {
      return Promise.resolve({ feito: false });
    }
    return md.getUserMedia({ video: true }).then(
      function (stream) {
        try { stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
        return { feito: true };
      },
      function () { return { feito: true }; }
    );
  }

  function pedirNativo(tipo) {
    var imagem = tipo === 'imagem';

    if (typeof CONFIG.ponteNativa === 'function') {
      return tentar(function () { return CONFIG.ponteNativa(tipo); })
        .then(function () { return { feito: true }; });
    }
    var cap = capacitorNativo();
    if (cap) return pedirCapacitor(cap, imagem);

    var cp = cordovaPermissoes();
    if (cp) return pedirCordova(cp);

    return pedirWeb(imagem);
  }

  // Pede uma única vez. Chamadas seguintes resolvem logo.
  function garantir(tipo) {
    if (jaPediu() || !emApp()) return Promise.resolve({ feito: false, jaPedido: jaPediu() });
    if (emCurso) return emCurso;

    emCurso = pedirNativo(tipo)
      .then(function (r) { if (r && r.feito) marcarPedido(); return r; },
            function () { return { feito: false }; })
      .then(function (r) { emCurso = null; return r; });

    return emCurso;
  }

  /* ---------------------- abrir o seletor de ficheiros ---------------------- */

  function tipoDe(input) {
    var a = (input.accept || '').toLowerCase();
    return (a && a.indexOf('image') === -1) ? 'documento' : 'imagem';
  }

  function temGesto() {
    var u = global.navigator && global.navigator.userActivation;
    return u ? !!u.isActive : true;
  }

  function aviso(texto) {
    try {
      var d = doc.createElement('div');
      d.setAttribute('role', 'status');
      d.textContent = texto;
      d.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);' +
        'max-width:88%;padding:12px 16px;background:#111;color:#fff;border-radius:10px;' +
        'font:14px/1.4 -apple-system,"Segoe UI",Roboto,sans-serif;text-align:center;' +
        'z-index:2147483647;box-shadow:0 4px 16px rgba(0,0,0,.3)';
      (doc.body || doc.documentElement).appendChild(d);
      setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 3500);
    } catch (e) {}
  }

  // Inputs criados por JS (ex.: document.createElement('input')) podem ser
  // "coletados" pelo WebView antes do 'change'. Ficam ligados ao DOM até ao fim.
  function prender(input) {
    if (input.isConnected) return;
    input.style.display = 'none';
    (doc.body || doc.documentElement).appendChild(input);
    var soltar = function () {
      setTimeout(function () { if (input.parentNode) input.parentNode.removeChild(input); }, 1000);
    };
    input.addEventListener('change', soltar, { once: true });
    input.addEventListener('cancel', soltar, { once: true });
  }

  function abrir(input) {
    if (!temGesto()) {
      aviso('Permissão registada. Toca de novo para escolher o ficheiro.');
      return;
    }
    prender(input);
    input.__wvLiberar = true;
    try { origClick.call(input); } finally { input.__wvLiberar = false; }
  }

  function gate(input) {
    if (emCurso) return;
    garantir(tipoDe(input)).then(function () { abrir(input); });
  }

  // input.click() feito por JS (inclui inputs ainda não ligados ao DOM)
  global.HTMLInputElement.prototype.click = function () {
    if (this.type !== 'file') return origClick.apply(this, arguments);
    if (!this.__wvLiberar && precisaPedir()) { gate(this); return; }
    prender(this);
    return origClick.apply(this, arguments);
  };

  // Toque direto no input ou através de <label>
  doc.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || t.tagName !== 'INPUT' || t.type !== 'file') return;
    if (t.__wvLiberar || !precisaPedir()) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    gate(t);
  }, true);

  /* ------------------------------ API pública ------------------------------ */

  function escolherFicheiro(op) {
    op = op || {};
    return new Promise(function (resolve) {
      var i = doc.createElement('input');
      i.type = 'file';
      i.accept = op.accept || '*/*';
      if (op.multiple) i.multiple = true;
      i.addEventListener('change', function () {
        var lista = Array.prototype.slice.call(i.files || []);
        resolve(op.multiple ? lista : (lista[0] || null));
      });
      i.addEventListener('cancel', function () { resolve(op.multiple ? [] : null); });
      i.click();
    });
  }

  global.WVPermissoes = {
    config: CONFIG,
    // Pede as permissões (só na primeira vez). tipo: 'imagem' | 'documento'
    pedir: function (tipo) { return garantir(tipo === 'documento' ? 'documento' : 'imagem'); },
    jaPediu: jaPediu,
    // Limpa a marca (útil para testes)
    resetar: function () {
      memoria = false;
      try { global.localStorage.removeItem(CONFIG.chave); } catch (e) {}
    },
    // Abre o seletor e devolve File (ou lista se multiple:true); null se cancelar
    escolherFicheiro: escolherFicheiro
  };

})(window);
