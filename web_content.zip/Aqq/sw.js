/* =========================================================================
   BookErth — Service Worker
   Estratégia:
   - App shell (HTML/CSS/JS/ícones): cache-first, com atualização em fundo
   - Imagens/media (Cloudinary): stale-while-revalidate + limite de tamanho
   - Leituras à API (Firebase/Cloudinary, só GET): stale-while-revalidate
   - Navegação (documentos): network-first com fallback para cache e offline.html
   - Escritas (POST/PUT/PATCH/DELETE) para Firebase/Cloudinary: nunca cacheadas;
     se falharem por estar offline, entram numa fila (outbox) em IndexedDB e
     são reenviadas automaticamente quando a ligação voltar (Background Sync,
     com fallback manual via mensagem 'sync-outbox')
   ========================================================================= */

const SW_VERSION = 'v4';
const STATIC_CACHE = `bookerth-static-${SW_VERSION}`;
const IMAGE_CACHE = `bookerth-images-${SW_VERSION}`;
const API_CACHE = `bookerth-api-${SW_VERSION}`;
const CURRENT_CACHES = [STATIC_CACHE, IMAGE_CACHE, API_CACHE];

const OFFLINE_URL = '/offline.html';
const FALLBACK_DOCUMENT = '/home.html';

const IMAGE_CACHE_LIMIT = 150;   // nº máx. de imagens guardadas
const API_CACHE_LIMIT = 80;      // nº máx. de respostas de API guardadas

const STATIC_ASSETS = [
  '/', '/index.html', '/login.html', '/cadastro.html', '/correio.html', '/home.html',
  '/publicar.html', '/momentos.html', '/colegas.html', '/perfil.html', '/chat.html', '/apresentacao.html',
  OFFLINE_URL,
  '/style.css', '/not.js', '/ia-assistant.js', '/cloudinary-upload.js',
  '/js/reputation.js', '/js/update-badges.js',
  '/assets/logo.png', '/assets/avatar1.png', '/assets/home.png', '/assets/momentos.png',
  '/assets/publicar.png', '/assets/correio.png', '/assets/colegas.png'
];

const CACHEABLE_HOSTS = ['firebase', 'firebaseio', 'googleapis', 'cloudinary'];

/* -------------------------------------------------------------------------
   Outbox (IndexedDB) — fila de pedidos de escrita falhados por estar offline
   ------------------------------------------------------------------------- */
const DB_NAME = 'bookerth-outbox';
const STORE_NAME = 'requests';

function openOutboxDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id', autoIncrement: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function queueRequest(request) {
  try {
    const body = ['GET', 'HEAD'].includes(request.method) ? null : await request.clone().arrayBuffer();
    const entry = {
      url: request.url,
      method: request.method,
      headers: Array.from(request.headers.entries()),
      body,
      timestamp: Date.now()
    };
    const db = await openOutboxDB();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).add(entry);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    notifyClients({ type: 'outbox-queued', url: request.url });
  } catch (err) {
    // se nem sequer conseguirmos guardar na fila, não há mais nada a fazer
  }
}

async function replayOutbox() {
  let db;
  try {
    db = await openOutboxDB();
  } catch {
    return;
  }
  const entries = await new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const req = tx.objectStore(STORE_NAME).getAll();
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

  for (const entry of entries) {
    try {
      const response = await fetch(entry.url, {
        method: entry.method,
        headers: entry.headers,
        body: entry.body || undefined
      });
      if (response.ok) {
        const delDb = await openOutboxDB();
        await new Promise((resolve, reject) => {
          const tx = delDb.transaction(STORE_NAME, 'readwrite');
          tx.objectStore(STORE_NAME).delete(entry.id);
          tx.oncomplete = resolve;
          tx.onerror = () => reject(tx.error);
        });
        notifyClients({ type: 'outbox-sent', url: entry.url });
      }
    } catch {
      // ainda offline ou o pedido voltou a falhar — mantém-se na fila
      break;
    }
  }
}

function notifyClients(message) {
  self.clients.matchAll({ type: 'window' }).then((clientList) => {
    clientList.forEach((client) => client.postMessage(message));
  });
}

/* -------------------------------------------------------------------------
   Utilitário: limitar o tamanho de uma cache (política FIFO simples)
   ------------------------------------------------------------------------- */
async function trimCache(cacheName, maxEntries) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  if (keys.length > maxEntries) {
    await cache.delete(keys[0]);
    await trimCache(cacheName, maxEntries);
  }
}

/* -------------------------------------------------------------------------
   Install
   ------------------------------------------------------------------------- */
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => cache.addAll(STATIC_ASSETS))
      .then(() => self.skipWaiting())
  );
});

/* -------------------------------------------------------------------------
   Activate
   ------------------------------------------------------------------------- */
self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      const cacheNames = await caches.keys();
      await Promise.all(
        cacheNames
          .filter((name) => !CURRENT_CACHES.includes(name))
          .map((name) => caches.delete(name))
      );
      if (self.registration.navigationPreload) {
        await self.registration.navigationPreload.enable();
      }
      await self.clients.claim();
    })()
  );
});

/* -------------------------------------------------------------------------
   Fetch
   ------------------------------------------------------------------------- */
self.addEventListener('fetch', (event) => {
  const { request } = event;

  // Só tratamos GET/HEAD para leitura; escritas têm tratamento próprio abaixo
  if (request.method === 'GET') {
    const url = new URL(request.url);

    // Navegação (carregar uma página / SPA route)
    if (request.mode === 'navigate' || request.destination === 'document') {
      event.respondWith(handleNavigation(event, request));
      return;
    }

    // Imagens (locais ou do Cloudinary)
    if (request.destination === 'image') {
      event.respondWith(staleWhileRevalidate(request, IMAGE_CACHE, IMAGE_CACHE_LIMIT));
      return;
    }

    // CSS / JS / fontes locais
    if (['style', 'script', 'font'].includes(request.destination)) {
      event.respondWith(cacheFirst(request, STATIC_CACHE));
      return;
    }

    // Leituras a Firebase/Google APIs/Cloudinary (ex: getDoc via REST, tokens, etc.)
    if (CACHEABLE_HOSTS.some((h) => url.hostname.includes(h))) {
      event.respondWith(staleWhileRevalidate(request, API_CACHE, API_CACHE_LIMIT));
      return;
    }

    // Resto: tenta rede, cai para cache se existir
    event.respondWith(
      fetch(request).catch(() => caches.match(request))
    );
    return;
  }

  // Escritas (POST/PUT/PATCH/DELETE) para Firebase/Cloudinary:
  // nunca cachear a resposta; se a rede falhar, guardar na fila (outbox)
  const url = new URL(request.url);
  if (CACHEABLE_HOSTS.some((h) => url.hostname.includes(h))) {
    event.respondWith(
      fetch(request.clone()).catch(async () => {
        await queueRequest(request);
        return new Response(
          JSON.stringify({ queued: true, offline: true }),
          { status: 202, headers: { 'Content-Type': 'application/json' } }
        );
      })
    );
  }
  // outros métodos/hosts seguem o comportamento normal do browser
});

async function handleNavigation(event, request) {
  try {
    const preloadResponse = await event.preloadResponse;
    if (preloadResponse) {
      cachePut(STATIC_CACHE, request, preloadResponse.clone());
      return preloadResponse;
    }
    const networkResponse = await fetch(request);
    if (networkResponse && networkResponse.ok) {
      cachePut(STATIC_CACHE, request, networkResponse.clone());
    }
    return networkResponse;
  } catch {
    const cached = await caches.match(request);
    if (cached) return cached;
    const fallback = await caches.match(FALLBACK_DOCUMENT);
    return fallback || caches.match(OFFLINE_URL);
  }
}

async function cacheFirst(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const response = await fetch(request);
    if (response.ok) cachePut(cacheName, request, response.clone());
    return response;
  } catch {
    return cached; // undefined se nunca esteve em cache
  }
}

async function staleWhileRevalidate(request, cacheName, limit) {
  const cache = await caches.open(cacheName);
  const cached = await cache.match(request);

  const networkFetch = fetch(request)
    .then((response) => {
      if (response && response.ok) {
        cache.put(request, response.clone());
        trimCache(cacheName, limit);
      }
      return response;
    })
    .catch(() => cached);

  return cached || networkFetch;
}

function cachePut(cacheName, request, response) {
  if (!response || !response.ok) return;
  caches.open(cacheName).then((cache) => cache.put(request, response));
}

/* -------------------------------------------------------------------------
   Background Sync — reenvia a fila assim que a ligação volta
   ------------------------------------------------------------------------- */
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-outbox') {
    event.waitUntil(replayOutbox());
  }
});

/* -------------------------------------------------------------------------
   Push notifications
   ------------------------------------------------------------------------- */
self.addEventListener('push', (event) => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'BookErth — Nova carta';
  const options = {
    body: data.body || 'Alguém escreveu-te no BookErth.',
    icon: 'assets/logo.png',
    badge: 'assets/logo.png',
    tag: data.tag || 'bookerth-push',
    data: data.data || {},
    requireInteraction: false,
    vibrate: [100, 50, 100]
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || 'correio.html';
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(url) && 'focus' in client) return client.focus();
      }
      if (clients.openWindow) return clients.openWindow(url);
    })
  );
});

/* -------------------------------------------------------------------------
   Mensagens vindas das páginas
   ------------------------------------------------------------------------- */
self.addEventListener('message', (event) => {
  if (event.data === 'prefetch') {
    caches.open(STATIC_CACHE).then((cache) =>
      cache.addAll(['/perfil.html', '/publicar.html', '/chat.html'])
    );
  }
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
  if (event.data === 'sync-outbox') {
    // fallback para browsers sem Background Sync API
    replayOutbox();
  }
});
