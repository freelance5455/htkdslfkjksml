# CGD V117 — Socle 1.2 : règles de calendrier des compétitions

## Règles confirmées
- Coupe des Clubs : pendant la saison régulière, chaque jeudi du mois lunaire, jusqu'à la finale.
- Un jour complet d'intervalle entre les compétitions ordinaires.
- L'AGD organise les deux compétitions galactiques : Coupe Intergalactique des galaxies et Intergalactique des Clubs. Toutes deux se jouent après la fin officielle de la saison régulière FGD, aux dates distinctes de son propre calendrier.
- Les deux compétitions intergalactiques sont des exceptions de période et ne doivent pas être replacées dans le calendrier ordinaire.

## Modifications techniques
- Suppression des anciennes dates fixes « mois 8, jours 6 à 30 » de la Coupe des Clubs.
- Ajout de `src/competition-calendar.js`.
- Les rencontres de Coupe des Clubs portent la règle récurrente `every-lunar-thursday` et attendent une date officielle tant que les jeudis lunaires ne sont pas fournis.
- `setOfficialLunarThursdays` injecte les jeudis du calendrier lunaire et met à jour les tours déjà créés.
- `setOfficialIntergalacticDate` enregistre une date AGD pour chacune des deux compétitions, après enregistrement de la date de fin de saison régulière FGD.
- `validateCompetitionSpacing` contrôle l'existence d'un jour complet entre les dates d'événements ordinaires. Il travaille sur des événements de compétition (une entrée par session), pas sur chaque match individuel.
- Les métadonnées du calendrier ont été ajoutées à l'état de carrière et aux migrations des sauvegardes antérieures.

## Éléments encore nécessaires pour l'exécution réelle
- Le calendrier lunaire officiel de la saison, avec les jeudis et leurs correspondances de jours de carrière.
- La date officielle de fin de saison régulière FGD et les deux dates AGD.
- Le calendrier central doit ensuite faire avancer la date de carrière et déclencher automatiquement les sessions correspondantes. Les fonctions de réception des dates sont prêtes, mais le moteur d'avancement temporel global n'est pas encore développé.

## Principe de fiabilité
Aucune date de calendrier lunaire, FGD ou AGD n'est fabriquée. Tant qu'une date officielle n'est pas fournie, elle reste explicitement en attente.


Correction institutionnelle issue de la clarification de l'utilisateur : la Coupe Intergalactique des galaxies relève de l'AGD, comme l'Intergalactique des Clubs. La FGD organise les championnats et les coupes des clubs.
