# 政治博弈卡牌 Android 封装项目

本项目将原 HTML5 游戏放入 Android WebView 容器，保留 JavaScript 游戏逻辑。

## 生成 APK
1. 在电脑安装 Android Studio（官方渠道）。
2. 解压本项目 ZIP，Android Studio 选择 Open，打开此目录。
3. 等待 Gradle Sync；若提示安装 SDK Platform 35 / Build Tools，请按提示安装。
4. 菜单 Build > Build Bundle(s) / APK(s) > Build APK(s)。
5. APK 通常生成在 `app/build/outputs/apk/debug/app-debug.apk`。

## 说明
- 游戏文件位于 `app/src/main/assets/index.html`。
- 游戏内联网查询的肖像等内容需要网络。
- 这是可编译项目骨架，不是已经编译、签名或测试安装的 APK；需在 Android Studio/Android SDK 环境编译。
- 可进一步增加启动页、横竖屏适配、离线图片缓存、存档迁移及正式签名。


## 本次改造
- 历史模式新增简单/标准/困难，难度通过 AI 初始费用、护盾及初始手牌调整。
- 中央军委整肃剧本换为具名角色阵容，人物图鉴可按指定百科条目查询肖像，并加入简介。
- 删除旧曲目“出山（伴奏）”。
- 新曲目默认曲目1/2/3已压缩并嵌入 HTML：大厅自动使用曲目1或2，对局使用曲目3，循环播放。
- 音频编码为单声道 22.05kHz 48kbps，游戏文件离线包含曲目。
