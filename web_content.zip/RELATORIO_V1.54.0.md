# Relatório estatístico — v1.54.0

**Método:** 10.000 partidas por cenário (60.000 no total), sorteios independentes do motor Poisson. Escalações sintéticas com 17 atletas e overalls próximos ao valor-base do cenário; estrelas fixadas conforme o cenário. Mandante é sempre a equipe A. “Goleada” definida como diferença de pelo menos 3 gols. “Zebra” no cenário 5x1 é vitória da equipe inferior.

**Resultados medidos nesta execução:**

```text
5v1 {"W":73.6,"D":17.1,"L":9.3,"avgGoals":3,"blowouts":28.8,"upsets":9.3,"top":["2-0:13.2%","1-0:11.7%","3-0:10.4%","2-1:9.5%","1-1:8.3%","3-1:6.6%","4-0:5.7%","0-0:4.7%"]}
4v2 {"W":58.9,"D":22.5,"L":18.6,"avgGoals":2.68,"blowouts":17.3,"upsets":18.6,"top":["1-0:11.8%","2-0:11.4%","1-1:10.3%","2-1:9.9%","0-0:7.2%","3-0:6.6%","0-1:6.2%","3-1:6.0%"]}
3v3 {"W":43.3,"D":26.2,"L":30.5,"avgGoals":2.55,"blowouts":11.7,"upsets":0,"top":["1-1:12.3%","1-0:11.6%","0-1:9.0%","2-1:8.5%","0-0:7.9%","2-0:7.5%","1-2:7.1%","2-2:5.1%"]}
2v2 {"W":43,"D":27.6,"L":29.4,"avgGoals":2.49,"blowouts":11.1,"upsets":0,"top":["1-1:13.6%","1-0:11.4%","0-1:8.8%","2-1:8.7%","0-0:8.3%","2-0:8.2%","1-2:7.1%","0-2:5.0%"]}
same stars different OVR {"W":61.4,"D":22.2,"L":16.5,"avgGoals":2.71,"blowouts":18.7,"upsets":0,"top":["1-0:12.2%","2-0:11.6%","1-1:10.8%","2-1:9.8%","3-0:7.8%","0-0:6.3%","3-1:6.1%","0-1:5.7%"]}
different stars same OVR {"W":52.8,"D":24.9,"L":22.3,"avgGoals":2.59,"blowouts":13.6,"upsets":22.3,"top":["1-0:12.5%","1-1:11.9%","2-0:9.7%","2-1:9.4%","0-1:7.5%","0-0:7.4%","1-2:5.3%","3-1:5.3%"]}

```

**Limitações:** os testes isolam o motor probabilístico e não carregam todos os elencos reais do jogo; não medem substituições reais de cada clube nem comportamento de temporadas completas. O motor usa os dados de posição/overall disponíveis no elenco em tempo de jogo. Uma validação manual no navegador e em Android ainda é necessária.
