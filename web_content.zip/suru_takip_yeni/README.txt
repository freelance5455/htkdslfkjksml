SÜRÜ TAKİP - ANDROID TELEFON İÇİN ÇEVRİM DIŞI WEB UYGULAMASI

DOSYALAR
- index.html: Uygulamanın kendisi.

ÖNEMLİ
Bu paket şu an APK değildir. Android telefonunda Chrome veya Brave ile açılabilen bir web uygulamasıdır. Kayıtlar kullanılan tarayıcının yerel depolamasında saklanır. Tarayıcı verilerini temizlemek veya uygulamayı başka tarayıcıda açmak kayıtları kaybettirebilir. Düzenli olarak JSON yedeği indirip güvenli bir yere kaydet.

KURULUM
1. ZIP dosyasını telefona indir ve dosya yöneticisiyle çıkart.
2. suru_takip_yeni klasöründeki index.html dosyasını Chrome veya Brave ile aç.
3. Uygulama açılmazsa HTML dosyasını tarayıcıdan açmayı destekleyen bir dosya görüntüleyici kullan; daha güvenilir kullanım için dosyayı bir web barındırma alanına yüklemek gerekir.
4. Ana ekrana ekleme seçeneği görünürse tarayıcının menüsünden “Ana ekrana ekle” seçebilirsin.
5. Yedekleme sekmesinden düzenli JSON yedeği indir.

ÖZELLİKLER
- Hayvan sayısı kayıt sayısına göre otomatik hesaplanır ve 0'dan başlar.
- Küpe, ad, cinsiyet, ırk, doğum tarihi, kilo, anne bağlantısı, durum, aşı, fotoğraf ve notlar.
- Hayvan düzenleme ve silme.
- Kilo ölçüm geçmişi kaydı.
- Tekiz, ikiz, üçüz veya dört kuzu doğum kaydı; her kuzu için ayrı kayıt, doğum kilosu ve emme durumu.
- JSON yedeği indirme ve yedekten geri yükleme.

SINIRLAMALAR
- Çevrim içi/bulut senkronizasyonu bu pakette yoktur; bunun için sunucu veya güvenli bir bulut veri tabanı ve hesap sistemi gerekir.
- Telefon değişimi veya tarayıcı verilerini silme öncesinde yedek almak gerekir.
- Bu ilk yeniden oluşturulmuş sürüm test edilmeden “tamamen hatasız” olarak değerlendirilemez.
