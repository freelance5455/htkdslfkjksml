"""اختبارات مستوى الـ API: FastAPI الحقيقي مع شبكة وهمية بدل الخدمات السحابية.

تحتاج: pip install -r requirements-dev.txt   ثم:   pytest
"""
import pytest

pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

import providers as P  # noqa: E402
from main import create_app  # noqa: E402

TOKEN = "t" * 32
AUTH = {"X-DINO-TOKEN": TOKEN}


def client(handler, **env_overrides):
    """يبني التطبيق من متغيرات بيئة كما يحدث في التشغيل الحقيقي."""
    env = {"CHAT_PROVIDER": "anthropic", "CHAT_API_KEY": "SECRET-KEY",
           "IMAGE_PROVIDER": "stability", "IMAGE_API_KEY": "SECRET-KEY", "DINO_API_TOKEN": TOKEN}
    env.update(env_overrides)
    app = create_app(P.load_settings(env), transport=httpx.MockTransport(handler))
    return TestClient(app)


def anthropic_ok(request):
    return httpx.Response(200, json={"content": [{"type": "text", "text": "أهلاً بك"}]})


def test_chat_anthropic_success_and_request_shape():
    seen = {}

    def handler(request):
        seen["url"] = str(request.url)
        seen["key"] = request.headers.get("x-api-key")
        seen["body"] = request.read()
        return anthropic_ok(request)

    r = client(handler).post("/api/chat", json={"message": "مرحبا", "history": []}, headers=AUTH)
    assert r.status_code == 200
    assert r.json()["reply"] == "أهلاً بك"
    assert seen["url"] == "https://api.anthropic.com/v1/messages"
    assert seen["key"] == "SECRET-KEY"


def test_history_with_consecutive_user_messages_is_normalized():
    import json

    def handler(request):
        roles = [m["role"] for m in json.loads(request.read())["messages"]]
        assert roles == ["user", "assistant", "user"], roles
        return anthropic_ok(request)

    history = [{"role": "user", "content": "a"}, {"role": "user", "content": "b"},
               {"role": "assistant", "content": "c"}]
    r = client(handler).post("/api/chat", json={"message": "d", "history": history}, headers=AUTH)
    assert r.status_code == 200


def test_token_required():
    c = client(anthropic_ok)
    assert c.post("/api/chat", json={"message": "x"}).status_code == 401
    assert c.post("/api/chat", json={"message": "x"}, headers={"X-DINO-TOKEN": "wrong"}).status_code == 401


def test_health_details_only_with_token():
    c = client(anthropic_ok)
    anon = c.get("/health").json()
    assert anon["authorized"] is False and "chat_model" not in anon
    full = c.get("/health", headers=AUTH).json()
    assert full["authorized"] is True and full["chat_ready"] is True and full["image_ready"] is True
    assert "SECRET-KEY" not in str(full)


def test_upstream_401_becomes_502_without_leaking_key():
    def handler(request):
        return httpx.Response(401, json={"error": {"message": "bad key SECRET-KEY"}})

    r = client(handler).post("/api/chat", json={"message": "x"}, headers=AUTH)
    assert r.status_code == 502
    assert "SECRET-KEY" not in r.text and "CHAT_API_KEY" in r.json()["detail"]


def test_connect_error_is_503():
    def handler(request):
        raise httpx.ConnectError("down")

    assert client(handler).post("/api/chat", json={"message": "x"}, headers=AUTH).status_code == 503


def test_chat_not_configured_returns_503_with_reason():
    r = client(anthropic_ok, CHAT_API_KEY="").post("/api/chat", json={"message": "x"}, headers=AUTH)
    assert r.status_code == 503 and "CHAT_API_KEY" in r.json()["detail"]


def test_image_stability_multipart_and_base64_result():
    seen = {}

    def handler(request):
        seen["ctype"] = request.headers["content-type"]
        seen["accept"] = request.headers["accept"]
        return httpx.Response(200, headers={"content-type": "image/png"}, content=b"\x89PNGfake")

    r = client(handler).post("/api/images/generate", json={"prompt": "قطة", "width": 768, "height": 512}, headers=AUTH)
    assert r.status_code == 200
    import base64
    assert base64.b64decode(r.json()["image_data"]) == b"\x89PNGfake"
    assert seen["ctype"].startswith("multipart/form-data") and seen["accept"] == "image/*"


def test_rate_limit():
    c = client(anthropic_ok, CHAT_RATE_PER_MINUTE="1")
    assert c.post("/api/chat", json={"message": "x"}, headers=AUTH).status_code == 200
    r = c.post("/api/chat", json={"message": "x"}, headers=AUTH)
    assert r.status_code == 429 and "Retry-After" in r.headers


def test_cloud_without_token_refuses_to_start():
    with pytest.raises(RuntimeError):
        create_app(P.load_settings({"CHAT_PROVIDER": "anthropic", "CHAT_API_KEY": "k"}))
