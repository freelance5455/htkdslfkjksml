import base64
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import providers as P  # noqa: E402


def settings(**kw):
    return P.Settings(**kw)


class LoadSettingsTests(unittest.TestCase):
    def test_defaults_are_local_and_backward_compatible(self):
        s = P.load_settings({"OLLAMA_URL": "http://box:11434/", "OLLAMA_MODEL": "m", "SD_API_URL": "http://sd:7860/"})
        self.assertEqual((s.chat_provider, s.chat_base_url, s.chat_model), ("ollama", "http://box:11434", "m"))
        self.assertEqual((s.image_provider, s.image_base_url), ("sd_webui", "http://sd:7860"))
        self.assertIsNone(s.security_problem())

    def test_anthropic_defaults(self):
        s = P.load_settings({"CHAT_PROVIDER": "claude", "CHAT_API_KEY": "k"})
        self.assertEqual(s.chat_provider, "anthropic")
        self.assertEqual(s.chat_base_url, "https://api.anthropic.com")
        self.assertEqual(s.chat_model, "claude-sonnet-5-5")

    def test_gemini_preset_and_required_model(self):
        s = P.load_settings({"CHAT_PROVIDER": "gemini", "CHAT_API_KEY": "k"})
        self.assertEqual(s.chat_provider, "openai_compatible")
        self.assertEqual(s.chat_base_url, "https://generativelanguage.googleapis.com/v1beta/openai")
        self.assertIn("CHAT_MODEL", s.chat_problem())  # لا نخمّن اسم النموذج
        s2 = P.load_settings({"CHAT_PROVIDER": "gemini", "CHAT_API_KEY": "k", "CHAT_MODEL": "x"})
        self.assertIsNone(s2.chat_problem())

    def test_openai_compatible_custom_base_and_legacy_key_name(self):
        s = P.load_settings({"CHAT_PROVIDER": "openai", "OPENAI_API_KEY": "k", "CHAT_MODEL": "m",
                             "CHAT_BASE_URL": "https://example.com/v1/"})
        self.assertEqual(s.chat_base_url, "https://example.com/v1")
        self.assertEqual(s.chat_api_key, "k")

    def test_missing_key_is_reported_not_raised(self):
        s = P.load_settings({"CHAT_PROVIDER": "anthropic"})
        self.assertIn("CHAT_API_KEY", s.chat_problem())
        self.assertFalse(s.describe()["chat_ready"])

    def test_unknown_providers_raise(self):
        with self.assertRaises(P.ConfigError):
            P.load_settings({"CHAT_PROVIDER": "nope"})
        with self.assertRaises(P.ConfigError):
            P.load_settings({"IMAGE_PROVIDER": "nope"})

    def test_bad_numbers_raise(self):
        with self.assertRaises(P.ConfigError):
            P.load_settings({"CHAT_MAX_TOKENS": "abc"})
        with self.assertRaises(P.ConfigError):
            P.load_settings({"MAX_HISTORY_CHARS": "5"})

    def test_blank_values_fall_back_to_defaults(self):
        s = P.load_settings({"CHAT_PROVIDER": "", "CHAT_MODEL": "  ", "CORS_ORIGINS": ""})
        self.assertEqual(s.chat_provider, "ollama")
        self.assertEqual(s.cors_origins, ("*",))

    def test_image_providers(self):
        s = P.load_settings({"IMAGE_PROVIDER": "stability", "STABILITY_API_KEY": "k"})
        self.assertEqual((s.image_model, s.image_base_url), ("core", "https://api.stability.ai"))
        self.assertIsNone(s.image_problem())
        o = P.load_settings({"IMAGE_PROVIDER": "openai", "OPENAI_API_KEY": "k"})
        self.assertEqual(o.image_model, "gpt-image-1-mini")
        bad = P.load_settings({"IMAGE_PROVIDER": "stability", "IMAGE_API_KEY": "k", "IMAGE_MODEL": "banana"})
        self.assertIn("IMAGE_MODEL", bad.image_problem())
        off = P.load_settings({"IMAGE_PROVIDER": "none"})
        self.assertFalse(off.describe()["image_ready"])


class SecurityTests(unittest.TestCase):
    def test_cloud_requires_token(self):
        s = settings(chat_provider="anthropic", chat_api_key="k")
        self.assertIn("DINO_API_TOKEN", s.security_problem())

    def test_cloud_image_only_also_requires_token(self):
        s = settings(image_provider="stability", image_api_key="k")
        self.assertIsNotNone(s.security_problem())

    def test_short_token_rejected_long_ok(self):
        self.assertIn("قصير", settings(chat_provider="anthropic", dino_token="1234").security_problem())
        self.assertIsNone(settings(chat_provider="anthropic", dino_token="x" * 32).security_problem())

    def test_explicit_opt_out(self):
        self.assertIsNone(settings(chat_provider="anthropic", allow_no_token=True).security_problem())

    def test_local_engines_need_no_token(self):
        self.assertIsNone(settings().security_problem())


class PrepareMessagesTests(unittest.TestCase):
    def test_merges_consecutive_same_role(self):
        out = P.prepare_messages([{"role": "user", "content": "a"}, {"role": "user", "content": "b"}], "c", 10000)
        self.assertEqual(out, [{"role": "user", "content": "a\n\nb\n\nc"}])

    def test_drops_leading_assistant_and_alternates(self):
        hist = [{"role": "assistant", "content": "x"}, {"role": "user", "content": "q"},
                {"role": "assistant", "content": "r"}]
        out = P.prepare_messages(hist, "next", 10000)
        self.assertEqual([m["role"] for m in out], ["user", "assistant", "user"])

    def test_budget_trims_oldest_but_keeps_last(self):
        hist = [{"role": "user", "content": "a" * 50}, {"role": "assistant", "content": "b" * 50},
                {"role": "user", "content": "c" * 50}, {"role": "assistant", "content": "d" * 50}]
        out = P.prepare_messages(hist, "last", 120)
        self.assertEqual(out[-1]["content"], "last")
        self.assertEqual(out[0]["role"], "user")
        self.assertLessEqual(sum(len(m["content"]) for m in out), 120 + 50)  # أول رسالة تتجاوز الحد تُحذف

    def test_oversized_last_message_still_kept(self):
        out = P.prepare_messages([], "z" * 500, 100)
        self.assertEqual(len(out), 1)

    def test_whitespace_only_message_rejected(self):
        with self.assertRaises(P.ProviderError) as ctx:
            P.prepare_messages([], "   \n ", 1000)
        self.assertEqual(ctx.exception.status_code, 422)

    def test_empty_history_entries_ignored(self):
        out = P.prepare_messages([{"role": "user", "content": " "}], "hi", 1000)
        self.assertEqual(out, [{"role": "user", "content": "hi"}])


class ChatRequestTests(unittest.TestCase):
    msgs = [{"role": "user", "content": "hi"}]

    def test_openai_compatible(self):
        s = settings(chat_provider="openai_compatible", chat_base_url="https://x/v1", chat_api_key="KEY", chat_model="m")
        r = P.build_chat_request(s, "SYS", self.msgs)
        self.assertEqual(r.url, "https://x/v1/chat/completions")
        self.assertEqual(r.headers, {"Authorization": "Bearer KEY"})
        self.assertEqual(r.json_body["messages"][0], {"role": "system", "content": "SYS"})
        self.assertEqual(r.json_body["messages"][1:], self.msgs)
        self.assertNotIn("max_tokens", r.json_body)  # الخدمات الحديثة ترفضه أحياناً

    def test_anthropic(self):
        s = settings(chat_provider="anthropic", chat_base_url="https://api.anthropic.com", chat_api_key="KEY",
                     chat_model="claude-sonnet-5-5", chat_max_tokens=777)
        r = P.build_chat_request(s, "SYS", self.msgs)
        self.assertEqual(r.url, "https://api.anthropic.com/v1/messages")
        self.assertEqual(r.headers["x-api-key"], "KEY")
        self.assertEqual(r.headers["anthropic-version"], "2023-06-01")
        self.assertEqual(r.json_body["system"], "SYS")
        self.assertEqual(r.json_body["max_tokens"], 777)
        self.assertEqual(r.json_body["messages"], self.msgs)  # لا رسالة system داخل messages

    def test_ollama(self):
        s = settings()
        r = P.build_chat_request(s, "SYS", self.msgs)
        self.assertEqual(r.url, "http://127.0.0.1:11434/api/chat")
        self.assertIs(r.json_body["stream"], False)


class ChatResponseTests(unittest.TestCase):
    def test_openai_string(self):
        s = settings(chat_provider="openai_compatible")
        self.assertEqual(P.parse_chat_response(s, {"choices": [{"message": {"content": " مرحبا "}}]}), "مرحبا")

    def test_openai_parts_list(self):
        s = settings(chat_provider="openai_compatible")
        data = {"choices": [{"message": {"content": [{"type": "text", "text": "a"}, {"type": "text", "text": "b"}]}}]}
        self.assertEqual(P.parse_chat_response(s, data), "ab")

    def test_openai_null_content(self):
        s = settings(chat_provider="openai_compatible")
        with self.assertRaises(P.ProviderError):
            P.parse_chat_response(s, {"choices": [{"message": {"content": None}}]})

    def test_anthropic_blocks(self):
        s = settings(chat_provider="anthropic")
        data = {"content": [{"type": "thinking", "thinking": "x"}, {"type": "text", "text": "one"},
                            {"type": "text", "text": " two"}]}
        self.assertEqual(P.parse_chat_response(s, data), "one two")

    def test_ollama_and_think_stripping(self):
        s = settings()
        data = {"message": {"content": "<think>\nسر\n</think>\nالجواب"}}
        self.assertEqual(P.parse_chat_response(s, data), "الجواب")

    def test_malformed_raises_502(self):
        for prov in ("ollama", "anthropic", "openai_compatible"):
            with self.assertRaises(P.ProviderError) as ctx:
                P.parse_chat_response(settings(chat_provider=prov), {"unexpected": 1})
            self.assertEqual(ctx.exception.status_code, 502)

    def test_only_think_block_is_empty_error(self):
        with self.assertRaises(P.ProviderError):
            P.parse_chat_response(settings(), {"message": {"content": "<think>x</think>"}})


class ImageTests(unittest.TestCase):
    def test_size_mapping(self):
        self.assertEqual(P.openai_image_size(512, 512), "1024x1024")
        self.assertEqual(P.openai_image_size(768, 512), "1536x1024")
        self.assertEqual(P.openai_image_size(512, 768), "1024x1536")
        self.assertEqual(P.stability_aspect_ratio(512, 512), "1:1")
        self.assertEqual(P.stability_aspect_ratio(768, 512), "3:2")
        self.assertEqual(P.stability_aspect_ratio(512, 768), "2:3")
        self.assertEqual(P.stability_aspect_ratio(1024, 256), "21:9")

    def test_openai_request(self):
        s = settings(image_provider="openai", image_base_url="https://api.openai.com/v1", image_api_key="K",
                     image_model="gpt-image-1-mini", image_quality="low")
        r = P.build_image_request(s, "cat", 768, 512)
        self.assertEqual(r.url, "https://api.openai.com/v1/images/generations")
        self.assertEqual(r.json_body, {"model": "gpt-image-1-mini", "prompt": "cat", "size": "1536x1024",
                                       "n": 1, "quality": "low"})
        self.assertNotIn("response_format", r.json_body)  # نماذج gpt-image ترفضه

    def test_openai_request_without_quality(self):
        s = settings(image_provider="openai", image_api_key="K", image_model="m", image_base_url="https://h/v1")
        self.assertNotIn("quality", P.build_image_request(s, "p", 512, 512).json_body)

    def test_stability_core_and_ultra_and_sd3(self):
        base = dict(image_provider="stability", image_base_url="https://api.stability.ai", image_api_key="K")
        core = P.build_image_request(settings(image_model="core", **base), "p", 512, 768)
        self.assertEqual(core.url, "https://api.stability.ai/v2beta/stable-image/generate/core")
        self.assertEqual(core.form, {"prompt": "p", "aspect_ratio": "2:3", "output_format": "png"})
        self.assertEqual(core.headers, {"Authorization": "Bearer K", "Accept": "image/*"})
        self.assertIsNone(core.json_body)
        ultra = P.build_image_request(settings(image_model="ultra", **base), "p", 512, 512)
        self.assertTrue(ultra.url.endswith("/generate/ultra"))
        sd3 = P.build_image_request(settings(image_model="sd3.5-large", **base), "p", 512, 512)
        self.assertTrue(sd3.url.endswith("/generate/sd3"))
        self.assertEqual(sd3.form["model"], "sd3.5-large")

    def test_a1111_request(self):
        r = P.build_image_request(settings(), "p", 768, 512)
        self.assertEqual(r.url, "http://127.0.0.1:7860/sdapi/v1/txt2img")
        self.assertEqual((r.json_body["width"], r.json_body["height"]), (768, 512))

    def test_parse_raw_image_bytes(self):
        out = P.parse_image_response(settings(image_provider="stability"), "image/png", b"\x89PNGdata")
        self.assertEqual(base64.b64decode(out), b"\x89PNGdata")

    def test_parse_json_variants(self):
        j = lambda d: json.dumps(d).encode()  # noqa: E731
        self.assertEqual(P.parse_image_response(settings(image_provider="openai"), "application/json",
                                                j({"data": [{"b64_json": "QUJD"}]})), "QUJD")
        self.assertEqual(P.parse_image_response(settings(image_provider="stability"), "application/json; charset=utf-8",
                                                j({"image": "QUJD"})), "QUJD")
        self.assertEqual(P.parse_image_response(settings(), "application/json", j({"images": ["QUJD"]})), "QUJD")

    def test_parse_strips_data_url_prefix(self):
        out = P.parse_image_response(settings(), "application/json", json.dumps({"images": ["data:image/png;base64,QUJD"]}).encode())
        self.assertEqual(out, "QUJD")

    def test_parse_failures_raise_502(self):
        cases = [
            (settings(image_provider="openai"), b'{"data":[{"url":"https://x"}]}'),  # رابط بدل base64
            (settings(), b"<html>oops</html>"),
            (settings(), b'{"images": []}'),
            (settings(), b'{"images": [123]}'),
        ]
        for s, body in cases:
            with self.assertRaises(P.ProviderError) as ctx:
                P.parse_image_response(s, "application/json", body)
            self.assertEqual(ctx.exception.status_code, 502)


class UpstreamErrorTests(unittest.TestCase):
    def test_status_mapping(self):
        m = lambda st, body=None, kind="chat": P.map_upstream_error(st, body, kind)  # noqa: E731
        self.assertEqual(m(400, {"error": {"message": "bad size"}}).status_code, 400)
        self.assertIn("bad size", m(400, {"error": {"message": "bad size"}}).detail)
        self.assertEqual(m(401).status_code, 502)
        self.assertIn("CHAT_API_KEY", m(401).detail)
        self.assertIn("IMAGE_API_KEY", m(401, kind="image").detail)
        self.assertIn("رصيد", m(402).detail)
        self.assertEqual(m(429).status_code, 429)
        self.assertEqual(m(503).status_code, 502)
        self.assertEqual(m(404).status_code, 502)

    def test_secrets_redacted_and_length_capped(self):
        err = P.map_upstream_error(400, {"error": {"message": "bad key SECRET123 " + "x" * 500}}, "chat", ("SECRET123",))
        self.assertNotIn("SECRET123", err.detail)
        self.assertLess(len(err.detail), 400)

    def test_error_shapes(self):
        stability = {"id": "1", "name": "content_moderation", "errors": ["flagged by filter"]}
        self.assertIn("flagged by filter", P.map_upstream_error(403, stability, "image").detail)
        self.assertIn("plain text", P.map_upstream_error(400, "plain text", "chat").detail)
        self.assertIn("boom", P.map_upstream_error(400, {"message": "boom"}, "chat").detail)

    def test_401_never_echoes_upstream_text(self):
        err = P.map_upstream_error(401, {"error": {"message": "Incorrect API key: sk-abcd"}}, "chat")
        self.assertNotIn("sk-abcd", err.detail)


class RateLimiterTests(unittest.TestCase):
    def test_window(self):
        t = [0.0]
        rl = P.RateLimiter(2, 60, clock=lambda: t[0])
        self.assertTrue(rl.allow())
        t[0] = 10
        self.assertTrue(rl.allow())
        self.assertFalse(rl.allow())
        self.assertEqual(rl.retry_after(), 50)
        t[0] = 60
        self.assertTrue(rl.allow())  # خرج أول طلب من النافذة
        self.assertFalse(rl.allow())

    def test_zero_disables(self):
        rl = P.RateLimiter(0)
        self.assertTrue(all(rl.allow() for _ in range(100)))


if __name__ == "__main__":
    unittest.main()
