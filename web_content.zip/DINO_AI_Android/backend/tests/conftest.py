import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# يمنع ملف .env الحقيقي من التأثير على الاختبارات (load_dotenv لا يستبدل المتغيرات الموجودة)
for key, value in {
    "CHAT_PROVIDER": "ollama",
    "IMAGE_PROVIDER": "none",
    "DINO_API_TOKEN": "",
    "DINO_ALLOW_NO_TOKEN": "true",
}.items():
    os.environ[key] = value
