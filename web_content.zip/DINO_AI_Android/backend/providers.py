"""DINO AI — منطق مزوّدي الذكاء الاصطناعي.

هذا الملف يحتوي دوالاً نقية فقط: قراءة الإعدادات، تنسيق الرسائل، بناء طلبات
HTTP وتحليل الردود وتحويل أخطاء المزوّد إلى رسائل عربية. لا يعتمد على FastAPI
ولا httpx، وmain.py هو الذي ينفّذ الطلبات فعلياً. هذا الفصل يجعل المنطق قابلاً
للاختبار دون إنترنت.
"""
from __future__ import annotations

import base64
import json
import math
import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Mapping

VERSION = "1.1.0"


class ConfigError(ValueError):
    """قيمة غير صالحة في متغيرات البيئة."""


class ProviderError(Exception):
    """خطأ يُحوَّل إلى استجابة HTTP برسالة عربية."""

    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(detail)
        self.status_code = status_code
        self.detail = detail


@dataclass(frozen=True)
class HttpRequest:
    url: str
    headers: dict[str, str]
    json_body: dict[str, Any] | None = None
    form: dict[str, str] | None = None  # حقول multipart/form-data


# ---------------------------------------------------------------- الإعدادات

CHAT_ALIASES = {
    "ollama": "ollama",
    "openai": "openai_compatible",
    "openai_compatible": "openai_compatible",
    "compatible": "openai_compatible",
    "gemini": "openai_compatible",
    "anthropic": "anthropic",
    "claude": "anthropic",
}
# عناوين جاهزة لبعض الأسماء المختصرة (يمكن تجاوزها بـ CHAT_BASE_URL)
CHAT_PRESET_BASE = {
    "gemini": "https://generativelanguage.googleapis.com/v1beta/openai",
}
IMAGE_ALIASES = {
    "sd_webui": "sd_webui",
    "a1111": "sd_webui",
    "automatic1111": "sd_webui",
    "local": "sd_webui",
    "stability": "stability",
    "stabilityai": "stability",
    "openai": "openai",
    "none": "none",
    "off": "none",
    "disabled": "none",
}
CLOUD_CHAT = {"openai_compatible", "anthropic"}
CLOUD_IMAGE = {"openai", "stability"}

PROVIDER_LABELS = {
    "ollama": "Ollama",
    "openai_compatible": "خدمة المحادثة",
    "anthropic": "Anthropic",
    "sd_webui": "Stable Diffusion المحلي",
    "stability": "Stability AI",
    "openai": "OpenAI للصور",
}

MIN_TOKEN_LENGTH = 16


@dataclass(frozen=True)
class Settings:
    chat_provider: str = "ollama"
    chat_base_url: str = "http://127.0.0.1:11434"
    chat_api_key: str = ""
    chat_model: str = "qwen3:4b"
    chat_max_tokens: int = 1024
    image_provider: str = "sd_webui"
    image_base_url: str = "http://127.0.0.1:7860"
    image_api_key: str = ""
    image_model: str = ""
    image_quality: str = ""
    dino_token: str = ""
    allow_no_token: bool = False
    max_history_chars: int = 24000
    chat_rate_per_min: int = 30
    image_rate_per_min: int = 6
    cors_origins: tuple[str, ...] = ("*",)

    # ---- حالة الجاهزية

    def chat_problem(self) -> str | None:
        if self.chat_provider in CLOUD_CHAT and not self.chat_api_key:
            return "مفتاح المحادثة غير مضبوط. ضع CHAT_API_KEY في إعدادات الخادم."
        if not self.chat_model:
            return "اسم نموذج المحادثة غير مضبوط. ضع CHAT_MODEL في إعدادات الخادم."
        return None

    def image_problem(self) -> str | None:
        if self.image_provider == "none":
            return "إنشاء الصور معطّل في إعدادات الخادم."
        if self.image_provider in CLOUD_IMAGE and not self.image_api_key:
            return "مفتاح الصور غير مضبوط. ضع IMAGE_API_KEY في إعدادات الخادم."
        if self.image_provider == "openai" and not self.image_model:
            return "اسم نموذج الصور غير مضبوط. ضع IMAGE_MODEL في إعدادات الخادم."
        if self.image_provider == "stability":
            model = self.image_model.lower()
            if model not in ("core", "ultra") and not model.startswith("sd3"):
                return "IMAGE_MODEL غير مدعوم مع Stability. استخدم core أو ultra أو اسم نموذج يبدأ بـ sd3."
        return None

    def security_problem(self) -> str | None:
        """عند استخدام مفاتيح مدفوعة يجب ألا يكون الخادم مفتوحاً للجميع."""
        uses_paid_keys = self.chat_provider in CLOUD_CHAT or self.image_provider in CLOUD_IMAGE
        if not uses_paid_keys or self.allow_no_token:
            return None
        if not self.dino_token:
            return (
                "أنت تستخدم خدمة سحابية بمفتاح خاص بك، وبدون DINO_API_TOKEN يستطيع أي شخص يعرف عنوان "
                "الخادم استهلاك رصيدك. ولّد رمزاً بالأمر: "
                "python -c \"import secrets; print(secrets.token_urlsafe(32))\" "
                "ثم ضعه في DINO_API_TOKEN (وللتجربة المحلية فقط يمكنك ضبط DINO_ALLOW_NO_TOKEN=true)."
            )
        if len(self.dino_token) < MIN_TOKEN_LENGTH:
            return f"DINO_API_TOKEN قصير جداً. استخدم {MIN_TOKEN_LENGTH} حرفاً على الأقل."
        return None

    def describe(self) -> dict[str, Any]:
        chat_problem = self.chat_problem()
        image_problem = self.image_problem()
        return {
            "chat_provider": self.chat_provider,
            "chat_model": self.chat_model,
            "chat_ready": chat_problem is None,
            "chat_problem": chat_problem or "",
            "image_provider": self.image_provider,
            "image_model": self.image_model,
            "image_ready": image_problem is None,
            "image_problem": image_problem or "",
            # للتوافق مع النسخة 1.0
            "image_engine_configured": image_problem is None,
        }


def _get(env: Mapping[str, str], *names: str, default: str = "") -> str:
    for name in names:
        value = env.get(name)
        if value is not None and value.strip():
            return value.strip()
    return default


def _int(env: Mapping[str, str], name: str, default: int, minimum: int) -> int:
    raw = _get(env, name)
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        raise ConfigError(f"{name} يجب أن يكون رقماً صحيحاً.") from None
    if value < minimum:
        raise ConfigError(f"{name} يجب ألا يقل عن {minimum}.")
    return value


def _truthy(value: str) -> bool:
    return value.strip().lower() in {"1", "true", "yes", "on", "نعم"}


def load_settings(env: Mapping[str, str]) -> Settings:
    # --- المحادثة
    raw_chat = _get(env, "CHAT_PROVIDER", default="ollama").lower()
    chat_provider = CHAT_ALIASES.get(raw_chat)
    if chat_provider is None:
        raise ConfigError(
            f"CHAT_PROVIDER غير معروف: {raw_chat}. القيم المتاحة: ollama, openai_compatible, anthropic, gemini."
        )
    if chat_provider == "ollama":
        chat_base = _get(env, "CHAT_BASE_URL", "OLLAMA_URL", default="http://127.0.0.1:11434")
        chat_model = _get(env, "CHAT_MODEL", "OLLAMA_MODEL", default="qwen3:4b")
        chat_key = ""
    elif chat_provider == "anthropic":
        chat_base = _get(env, "CHAT_BASE_URL", default="https://api.anthropic.com")
        chat_model = _get(env, "CHAT_MODEL", default="claude-sonnet-5-5")
        chat_key = _get(env, "CHAT_API_KEY", "ANTHROPIC_API_KEY")
    else:
        chat_base = _get(
            env, "CHAT_BASE_URL", default=CHAT_PRESET_BASE.get(raw_chat, "https://api.openai.com/v1")
        )
        chat_model = _get(env, "CHAT_MODEL")  # لا نخمّن اسم النموذج: يختلف بين الخدمات ويتغير
        chat_key = _get(env, "CHAT_API_KEY", "OPENAI_API_KEY")

    # --- الصور
    raw_image = _get(env, "IMAGE_PROVIDER", default="sd_webui").lower()
    image_provider = IMAGE_ALIASES.get(raw_image)
    if image_provider is None:
        raise ConfigError(
            f"IMAGE_PROVIDER غير معروف: {raw_image}. القيم المتاحة: sd_webui, stability, openai, none."
        )
    if image_provider == "stability":
        image_base = _get(env, "IMAGE_BASE_URL", default="https://api.stability.ai")
        image_model = _get(env, "IMAGE_MODEL", default="core")
        image_key = _get(env, "IMAGE_API_KEY", "STABILITY_API_KEY")
    elif image_provider == "openai":
        image_base = _get(env, "IMAGE_BASE_URL", default="https://api.openai.com/v1")
        image_model = _get(env, "IMAGE_MODEL", default="gpt-image-1-mini")
        image_key = _get(env, "IMAGE_API_KEY", "OPENAI_API_KEY")
    else:
        image_base = _get(env, "IMAGE_BASE_URL", "SD_API_URL", default="http://127.0.0.1:7860")
        image_model = ""
        image_key = ""

    return Settings(
        chat_provider=chat_provider,
        chat_base_url=chat_base.rstrip("/"),
        chat_api_key=chat_key,
        chat_model=chat_model,
        chat_max_tokens=_int(env, "CHAT_MAX_TOKENS", 1024, 16),
        image_provider=image_provider,
        image_base_url=image_base.rstrip("/"),
        image_api_key=image_key,
        image_model=image_model,
        image_quality=_get(env, "IMAGE_QUALITY").lower(),
        dino_token=_get(env, "DINO_API_TOKEN"),
        allow_no_token=_truthy(_get(env, "DINO_ALLOW_NO_TOKEN")),
        max_history_chars=_int(env, "MAX_HISTORY_CHARS", 24000, 1000),
        chat_rate_per_min=_int(env, "CHAT_RATE_PER_MINUTE", 30, 0),
        image_rate_per_min=_int(env, "IMAGE_RATE_PER_MINUTE", 6, 0),
        cors_origins=tuple(x.strip() for x in _get(env, "CORS_ORIGINS", default="*").split(",") if x.strip())
        or ("*",),
    )


# ------------------------------------------------------------------ المحادثة

SYSTEM_PROMPT = (
    "You are DINO AI, a helpful, honest, multilingual assistant. "
    "Answer naturally in the user's language. Explain uncertainty and never claim "
    "to have performed actions you did not perform. Do not reveal secrets. "
    "Use clear formatting and practical examples when useful."
)

_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)


def prepare_messages(history: list[dict[str, str]], message: str, max_chars: int) -> list[dict[str, str]]:
    """يجهّز الرسائل لتقبلها كل الخدمات.

    - يدمج الرسائل المتتالية من الدور نفسه (تحدث عند فشل طلب سابق؛ بعض الخدمات ترفضها).
    - يحذف أي رد مساعد في أول القائمة (يجب أن تبدأ المحادثة برسالة مستخدم).
    - يقصّ الأقدم أولاً حتى يتّسع السياق في max_chars، وتبقى الرسالة الأخيرة دائماً.
    """
    merged: list[dict[str, str]] = []
    for item in [*history, {"role": "user", "content": message}]:
        text = (item.get("content") or "").strip()
        if not text:
            continue
        role = item["role"]
        if merged and merged[-1]["role"] == role:
            merged[-1]["content"] += "\n\n" + text
        else:
            merged.append({"role": role, "content": text})

    kept: list[dict[str, str]] = []
    total = 0
    for item in reversed(merged):
        total += len(item["content"])
        if kept and total > max_chars:
            break
        kept.append(item)
    kept.reverse()
    while kept and kept[0]["role"] != "user":
        kept.pop(0)
    if not kept or kept[-1]["role"] != "user":
        raise ProviderError(422, "الرسالة فارغة.")
    return kept


def build_chat_request(s: Settings, system: str, messages: list[dict[str, str]]) -> HttpRequest:
    if s.chat_provider == "ollama":
        return HttpRequest(
            f"{s.chat_base_url}/api/chat",
            {},
            {"model": s.chat_model, "messages": [{"role": "system", "content": system}, *messages], "stream": False},
        )
    if s.chat_provider == "anthropic":
        return HttpRequest(
            f"{s.chat_base_url}/v1/messages",
            {"x-api-key": s.chat_api_key, "anthropic-version": "2023-06-01"},
            {"model": s.chat_model, "max_tokens": s.chat_max_tokens, "system": system, "messages": messages},
        )
    return HttpRequest(
        f"{s.chat_base_url}/chat/completions",
        {"Authorization": f"Bearer {s.chat_api_key}"},
        {"model": s.chat_model, "messages": [{"role": "system", "content": system}, *messages]},
    )


def _text_from_parts(parts: Any) -> str:
    if isinstance(parts, str):
        return parts
    if isinstance(parts, list):
        return "".join(
            p.get("text", "") if isinstance(p, dict) and p.get("type", "text") == "text" else ""
            for p in parts
        )
    return ""


def parse_chat_response(s: Settings, data: Any) -> str:
    try:
        if s.chat_provider == "ollama":
            text = _text_from_parts(data["message"]["content"])
        elif s.chat_provider == "anthropic":
            text = _text_from_parts(data["content"])
        else:
            text = _text_from_parts(data["choices"][0]["message"]["content"])
    except (KeyError, IndexError, TypeError, AttributeError):
        raise ProviderError(502, "استجابة المحادثة غير صالحة.") from None
    text = _THINK_RE.sub("", text).strip()
    if not text:
        raise ProviderError(502, "النموذج لم يرجع إجابة. جرّب صياغة أخرى للسؤال.")
    return text


# -------------------------------------------------------------------- الصور

_STABILITY_RATIOS = {
    "21:9": 21 / 9, "16:9": 16 / 9, "3:2": 3 / 2, "5:4": 5 / 4, "1:1": 1.0,
    "4:5": 4 / 5, "2:3": 2 / 3, "9:16": 9 / 16, "9:21": 9 / 21,
}


def openai_image_size(width: int, height: int) -> str:
    """نماذج gpt-image تقبل ثلاثة أحجام ثابتة؛ نختار الأقرب بالاتجاه."""
    if width > height:
        return "1536x1024"
    if height > width:
        return "1024x1536"
    return "1024x1024"


def stability_aspect_ratio(width: int, height: int) -> str:
    ratio = width / height
    return min(_STABILITY_RATIOS, key=lambda k: abs(math.log(ratio / _STABILITY_RATIOS[k])))


def build_image_request(s: Settings, prompt: str, width: int, height: int) -> HttpRequest:
    if s.image_provider == "openai":
        body: dict[str, Any] = {
            "model": s.image_model,
            "prompt": prompt,
            "size": openai_image_size(width, height),
            "n": 1,
        }
        if s.image_quality:
            body["quality"] = s.image_quality
        return HttpRequest(
            f"{s.image_base_url}/images/generations", {"Authorization": f"Bearer {s.image_api_key}"}, body
        )
    if s.image_provider == "stability":
        model = s.image_model.lower()
        form = {
            "prompt": prompt,
            "aspect_ratio": stability_aspect_ratio(width, height),
            "output_format": "png",
        }
        if model == "ultra":
            endpoint = "ultra"
        elif model == "core":
            endpoint = "core"
        else:
            endpoint = "sd3"
            form["model"] = s.image_model
        return HttpRequest(
            f"{s.image_base_url}/v2beta/stable-image/generate/{endpoint}",
            {"Authorization": f"Bearer {s.image_api_key}", "Accept": "image/*"},
            None,
            form,
        )
    return HttpRequest(
        f"{s.image_base_url}/sdapi/v1/txt2img",
        {},
        {"prompt": prompt, "width": width, "height": height, "steps": 24, "cfg_scale": 6.5, "batch_size": 1},
    )


def parse_image_response(s: Settings, content_type: str, content: bytes) -> str:
    """يعيد الصورة كنص base64 (بدون بادئة data:)."""
    ctype = (content_type or "").split(";")[0].strip().lower()
    if ctype.startswith("image/"):
        if not content:
            raise ProviderError(502, "محرك الصور لم يرجع صورة صالحة.")
        return base64.b64encode(content).decode("ascii")
    try:
        data = json.loads(content)
        if s.image_provider == "openai":
            image = data["data"][0]["b64_json"]
        elif s.image_provider == "stability":
            image = data["image"]
        else:
            image = data["images"][0]
    except (ValueError, KeyError, IndexError, TypeError, AttributeError):
        raise ProviderError(502, "استجابة محرك الصور غير صالحة.") from None
    if not isinstance(image, str) or not image:
        raise ProviderError(502, "محرك الصور لم يرجع صورة صالحة.")
    if image.startswith("data:") and "," in image:
        image = image.split(",", 1)[1]
    return image


# ------------------------------------------------------------ أخطاء المزوّد

def _upstream_text(body: Any, secrets: tuple[str, ...]) -> str:
    text = ""
    if isinstance(body, dict):
        err = body.get("error")
        if isinstance(err, dict):
            text = str(err.get("message") or err.get("type") or "")
        elif isinstance(err, str):
            text = err
        elif isinstance(body.get("errors"), list):
            text = "؛ ".join(str(x) for x in body["errors"])
        else:
            text = str(body.get("message") or body.get("detail") or "")
    elif isinstance(body, str):
        text = body
    for secret in secrets:
        if secret:
            text = text.replace(secret, "***")
    return " ".join(text.split())[:200]


def map_upstream_error(status: int, body: Any, kind: str, secrets: tuple[str, ...] = ()) -> ProviderError:
    """يحوّل فشل المزوّد إلى رسالة عربية. kind: chat أو image."""
    key_var = "CHAT_API_KEY" if kind == "chat" else "IMAGE_API_KEY"
    msg = _upstream_text(body, secrets)
    suffix = f" ({msg})" if msg else ""
    if status in (400, 422):
        return ProviderError(400, f"رفضت الخدمة الطلب، وقد يكون السبب سياسة المحتوى أو إعداداً غير مدعوم{suffix}")
    if status == 401:
        return ProviderError(502, f"مفتاح الخدمة لدى الخادم غير صحيح أو منتهي. راجع {key_var}.")
    if status == 402:
        return ProviderError(502, "رصيد حسابك لدى الخدمة غير كافٍ. اشحن الرصيد ثم أعد المحاولة.")
    if status == 403:
        return ProviderError(502, f"رفضت الخدمة الوصول أو حجبت المحتوى. قد يتطلب حسابك توثيقاً أو صلاحية لهذا النموذج{suffix}")
    if status == 404:
        return ProviderError(502, f"النموذج أو العنوان غير موجود لدى الخدمة. راجع اسم النموذج والعنوان في إعدادات الخادم{suffix}")
    if status == 429:
        return ProviderError(429, "تجاوزت حد الاستخدام أو الحصة المسموحة لدى الخدمة. انتظر قليلاً ثم أعد المحاولة.")
    if status >= 500:
        return ProviderError(502, f"الخدمة تواجه مشكلة مؤقتة (الحالة {status}). أعد المحاولة بعد قليل.")
    return ProviderError(502, f"الخدمة أعادت الحالة {status}{suffix}")


# ------------------------------------------------------------- تحديد المعدل

class RateLimiter:
    """حد بسيط للطلبات في الدقيقة داخل ذاكرة العملية (يحمي رصيدك من الاستنزاف)."""

    def __init__(self, limit: int, window: float = 60.0, clock: Callable[[], float] = time.monotonic) -> None:
        self.limit = limit
        self.window = window
        self.clock = clock
        self._hits: deque[float] = deque()

    def allow(self) -> bool:
        if self.limit <= 0:
            return True
        now = self.clock()
        while self._hits and now - self._hits[0] >= self.window:
            self._hits.popleft()
        if len(self._hits) >= self.limit:
            return False
        self._hits.append(now)
        return True

    def retry_after(self) -> int:
        if not self._hits:
            return 1
        return max(1, math.ceil(self.window - (self.clock() - self._hits[0])))
