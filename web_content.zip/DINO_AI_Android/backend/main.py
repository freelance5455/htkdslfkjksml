"""DINO AI API — خادم FastAPI يربط التطبيق بخدمات الذكاء الاصطناعي.

المحادثة:  ollama (محلي) | anthropic | openai_compatible (OpenAI, Gemini, وأي خدمة متوافقة)
الصور:     sd_webui (محلي) | stability | openai | none
الإعداد كله من متغيرات البيئة أو ملف .env (انظر .env.example).
"""
import hmac
import logging
import os

import httpx
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Literal

import providers as P

load_dotenv()
log = logging.getLogger("dino")


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(min_length=1, max_length=12000)


class ChatRequest(BaseModel):
    message: str = Field(min_length=1, max_length=12000)
    history: list[ChatMessage] = Field(default_factory=list, max_length=24)


class ImageRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    width: int = Field(default=512, ge=256, le=1024)
    height: int = Field(default=512, ge=256, le=1024)


def create_app(settings: P.Settings | None = None, transport: httpx.AsyncBaseTransport | None = None) -> FastAPI:
    """transport اختياري ويُستخدم في الاختبارات لاستبدال الشبكة الحقيقية."""
    s = settings or P.load_settings(os.environ)
    problem = s.security_problem()
    if problem:
        raise RuntimeError(problem)

    secrets = (s.chat_api_key, s.image_api_key, s.dino_token)
    # عند وجود رمز وصول نخفي صفحات التوثيق التلقائية حتى لا تُعرض هيكلة الخادم علناً
    hide_docs = bool(s.dino_token)
    app = FastAPI(
        title="DINO AI API",
        version=P.VERSION,
        description="Private API for the DINO AI Android app",
        docs_url=None if hide_docs else "/docs",
        redoc_url=None,
        openapi_url=None if hide_docs else "/openapi.json",
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(s.cors_origins),
        allow_credentials=False,
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type", "X-DINO-TOKEN"],
    )

    chat_limiter = P.RateLimiter(s.chat_rate_per_min)
    image_limiter = P.RateLimiter(s.image_rate_per_min)

    def token_ok(value: str | None) -> bool:
        if not s.dino_token:
            return True
        return hmac.compare_digest((value or "").encode("utf-8"), s.dino_token.encode("utf-8"))

    async def verify_token(x_dino_token: str | None = Header(default=None)):
        if not token_ok(x_dino_token):
            raise HTTPException(status_code=401, detail="رمز الوصول غير صحيح.")

    def limit(limiter: P.RateLimiter):
        async def dependency():
            if not limiter.allow():
                raise HTTPException(
                    status_code=429,
                    detail="طلبات كثيرة في وقت قصير. انتظر قليلاً ثم أعد المحاولة.",
                    headers={"Retry-After": str(limiter.retry_after())},
                )
        return dependency

    @app.exception_handler(P.ProviderError)
    async def provider_error_handler(_request, exc: P.ProviderError):
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

    async def send(upstream: P.HttpRequest, timeout: float, kind: str) -> httpx.Response:
        provider = s.chat_provider if kind == "chat" else s.image_provider
        label = P.PROVIDER_LABELS[provider]
        is_local = provider in ("ollama", "sd_webui")
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout, connect=10.0), transport=transport) as client:
                kwargs: dict = {"headers": upstream.headers}
                if upstream.json_body is not None:
                    kwargs["json"] = upstream.json_body
                if upstream.form is not None:
                    kwargs["files"] = {k: (None, v) for k, v in upstream.form.items()}
                resp = await client.post(upstream.url, **kwargs)
        except httpx.TimeoutException:
            raise P.ProviderError(504, f"انتهت مهلة الانتظار من {label}.") from None
        except httpx.ConnectError:
            hint = "شغّل الخدمة وتأكد من عنوانها." if is_local else "تحقق من اتصال الخادم بالإنترنت."
            raise P.ProviderError(503, f"تعذر الوصول إلى {label}. {hint}") from None
        except httpx.HTTPError:
            raise P.ProviderError(502, f"حدث خطأ في الاتصال مع {label}.") from None
        if resp.is_success:
            return resp
        try:
            body = resp.json()
        except ValueError:
            body = resp.text
        error = P.map_upstream_error(resp.status_code, body, kind, secrets)
        log.warning("%s upstream failed: provider=%s status=%s", kind, provider, resp.status_code)
        raise error

    @app.get("/health")
    async def health(x_dino_token: str | None = Header(default=None)):
        authorized = token_ok(x_dino_token)
        info: dict = {
            "ok": True,
            "service": "DINO AI",
            "version": P.VERSION,
            "auth_required": bool(s.dino_token),
            "authorized": authorized,
        }
        if authorized:  # تفاصيل الإعداد لا تُعرض إلا لمن يملك الرمز
            info.update(s.describe())
        return info

    @app.post("/api/chat", dependencies=[Depends(verify_token), Depends(limit(chat_limiter))])
    async def chat(req: ChatRequest):
        not_ready = s.chat_problem()
        if not_ready:
            raise HTTPException(status_code=503, detail=not_ready)
        messages = P.prepare_messages([m.model_dump() for m in req.history], req.message, s.max_history_chars)
        resp = await send(P.build_chat_request(s, P.SYSTEM_PROMPT, messages), 180.0, "chat")
        try:
            data = resp.json()
        except ValueError:
            raise P.ProviderError(502, "استجابة المحادثة غير صالحة.") from None
        return {"reply": P.parse_chat_response(s, data), "model": s.chat_model, "provider": s.chat_provider}

    @app.post("/api/images/generate", dependencies=[Depends(verify_token), Depends(limit(image_limiter))])
    async def generate_image(req: ImageRequest):
        not_ready = s.image_problem()
        if not_ready:
            raise HTTPException(status_code=503, detail=not_ready)
        upstream = P.build_image_request(s, req.prompt, req.width, req.height)
        resp = await send(upstream, 300.0, "image")
        image = P.parse_image_response(s, resp.headers.get("content-type", ""), resp.content)
        return {"image_data": image, "format": "png", "provider": s.image_provider}

    chat_state = "جاهزة" if s.chat_problem() is None else "غير جاهزة: " + (s.chat_problem() or "")
    image_state = "جاهزة" if s.image_problem() is None else "غير جاهزة: " + (s.image_problem() or "")
    log.warning("DINO AI %s | المحادثة [%s] %s | الصور [%s] %s", P.VERSION, s.chat_provider, chat_state, s.image_provider, image_state)
    return app


app = create_app()
