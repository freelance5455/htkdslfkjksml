package com.example.calculatorpro

import com.example.calculatorpro.currency.*
import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal
import java.time.LocalDate

class CurrencyCoreTests {
    private fun table(vararg p: Pair<String, String>) = RateTable("2026-11-08", p.associate { it.first to BigDecimal(it.second) }, "test", 0L)
    private val t = table("INR" to "83.5", "EUR" to "0.9", "JPY" to "150", "KWD" to "0.31")

    @Test fun directAndInverseRates() {
        assertEquals(0, BigDecimal("83.5").compareTo(Money.rate(t, "USD", "INR")))
        assertEquals("0.011976", Money.fmtRate(Money.rate(t, "INR", "USD")!!).take(8))
        assertFalse(Money.viaUsd("USD", "INR"))
    }
    @Test fun crossRateThroughUsd() {
        val r = Money.rate(t, "INR", "EUR")!!            // 0.9 / 83.5
        assertTrue(Money.viaUsd("INR", "EUR"))
        assertEquals("0.010778", Money.fmtRate(r).take(8))
    }
    @Test fun missingCurrencyGivesNoRate() { assertNull(Money.rate(t, "INR", "ZZZ")) }
    @Test fun roundingFollowsCurrencyDecimals() {
        assertEquals("11.98", Money.convert(BigDecimal("1000"), Money.rate(t, "INR", "USD")!!, 2).toPlainString())
        assertEquals("150", Money.convert(BigDecimal.ONE, Money.rate(t, "USD", "JPY")!!, 0).toPlainString())
        assertEquals("0.310", Money.convert(BigDecimal.ONE, Money.rate(t, "USD", "KWD")!!, 3).toPlainString())
        assertEquals(2, Catalog.byCode["INR"]!!.digits); assertEquals(0, Catalog.byCode["JPY"]!!.digits); assertEquals(3, Catalog.byCode["KWD"]!!.digits)
    }
    @Test fun percentChange() {
        assertEquals("10.00", Money.pct(BigDecimal(100), BigDecimal(110))!!.toPlainString())
        assertEquals("-50.00", Money.pct(BigDecimal(200), BigDecimal(100))!!.toPlainString())
        assertNull(Money.pct(BigDecimal.ZERO, BigDecimal.ONE))
    }
    @Test fun noBinaryFloatDrift() {
        assertEquals("0.30", Money.convert(BigDecimal("0.1"), BigDecimal("3"), 2).toPlainString())
        assertEquals("0.30", Money.convert(BigDecimal("0.2"), BigDecimal("1.5"), 2).toPlainString())
    }
    @Test fun parseAmount() {
        assertEquals(0, BigDecimal("1234.5").compareTo(Money.parseAmount("1,234.5")))
        assertNull(Money.parseAmount("abc")); assertNull(Money.parseAmount("-5"))
    }

    @Test fun catalogHasWorldCurrencies() {
        assertTrue(Catalog.all.size > 150)
        val inr = Catalog.byCode["INR"]!!
        assertTrue(inr.countries.any { it.name == "India" }); assertEquals("🇮🇳", inr.flag)
        val eur = Catalog.byCode["EUR"]!!
        assertTrue(eur.countries.size > 10); assertEquals("🇪🇺", eur.flag)       // many countries share one currency
        assertTrue(Catalog.byCode["USD"]!!.countries.size > 3)
    }
    @Test fun searchByCountryNameCodeAndSymbol() {
        val all = Catalog.all
        assertTrue(Catalog.search(all, "India").any { it.code == "INR" })
        assertTrue(Catalog.search(all, "Dollar").size > 5)
        assertEquals("USD", Catalog.search(all, "usd").first().code)
        assertTrue(Catalog.search(all, "Pound").any { it.code == "GBP" })
        assertTrue(Catalog.search(all, "Nepal").any { it.code == "NPR" })
    }
    @Test fun flagFromCountryCode() { assertEquals("🇯🇵", flagOf("JP")); assertEquals("🌐", flagOf("")) }

    @Test fun parseProviderTable() {
        val sb = StringBuilder("{\"date\":\"2026-11-08\",\"usd\":{")
        for (i in 0 until 25) sb.append("\"c$i\":${i + 1}.5,")
        sb.append("\"inr\":83.5}}")
        val tb = parseTable(sb.toString(), "x", 1L)
        assertEquals("2026-11-08", tb.date); assertEquals(0, BigDecimal("83.5").compareTo(tb.rates["INR"]))
    }
    @Test(expected = Exception::class) fun rejectsTinyOrBrokenResponse() { parseTable("{\"date\":\"2026-11-08\",\"usd\":{\"inr\":83.5}}", "x", 1L) }

    @Test fun downsampleKeepsEndsAndSize() {
        val l = (0 until 1000).map { Pt(LocalDate.of(2020, 1, 1).plusDays(it.toLong()), BigDecimal(it)) }
        val d = downsample(l, 300)
        assertEquals(300, d.size); assertEquals(l.first(), d.first()); assertEquals(l.last(), d.last())
    }
}
