package com.example.calculatorpro

import com.example.calculatorpro.floating.FloatCalcLogic
import org.junit.Assert.*
import org.junit.Test

class FloatCalcLogicTest {
    private fun run(vararg keys: String): FloatCalcLogic = FloatCalcLogic().also { l -> keys.forEach { l.key(it) } }

    @Test fun addition() { assertEquals("8", run("5", "+", "3", "=").expr) }
    @Test fun subtraction() { assertEquals("2", run("5", "−", "3", "=").expr) }
    @Test fun multiplication() { assertEquals("1000", run("2", "5", "0", "×", "4", "=").expr) }
    @Test fun division() { assertEquals("100", run("5", "0", "0", "÷", "5", "=").expr) }
    @Test fun percentage() { assertEquals("0.5", run("5", "0", "%", "=").expr) }
    @Test fun decimal() { assertEquals("4", run("2", ".", "5", "+", "1", ".", "5", "=").expr) }
    @Test fun decimalNeedsLeadingZero() { assertEquals("0.", run(".").expr); assertEquals("0.5", run(".", "5").expr) }
    @Test fun onlyOneDecimalPoint() { assertEquals("1.5", run("1", ".", ".", "5").expr) }
    @Test fun clear() { assertEquals("", run("1", "2", "AC").expr) }
    @Test fun backspace() { assertEquals("1", run("1", "2", "⌫").expr); assertEquals("", run("⌫").expr) }
    @Test fun doubleZero() { assertEquals("500", run("5", "00").expr); assertEquals("0", run("00").expr); assertEquals("5000", run("5", "00", "0").expr) }
    @Test fun noLeadingZeros() { assertEquals("5", run("0", "5").expr) }
    @Test fun operatorReplacesOperator() { assertEquals("5×", run("5", "+", "×").expr) }
    @Test fun leadingMinusAllowed() { assertEquals("−5", run("−", "5").expr); assertEquals("", run("+").expr) }
    @Test fun divideByZeroShowsErrorAndKeepsExpression() {
        val l = run("5", "÷", "0", "=")
        assertEquals("Cannot divide by zero", l.error); assertEquals("5÷0", l.expr)
    }
    @Test fun incompleteExpressionIsInvalid() { val l = run("5", "+", "="); assertEquals("Invalid expression", l.error) }
    @Test fun resultCanBeContinuedWithAnOperator() { assertEquals("12", run("5", "+", "3", "=", "+", "4", "=").expr) }
    @Test fun digitAfterEqualsStartsNew() { assertEquals("7", run("5", "+", "3", "=", "7").expr) }
    @Test fun livePreview() { assertEquals("8", run("5", "+", "3").preview); assertEquals("", run("5").preview) }
    @Test fun noFloatingPointNoise() { assertEquals("0.3", run("0", ".", "1", "+", "0", ".", "2", "=").expr) }
    @Test fun longAddition() {
        val l = FloatCalcLogic(); "25+5+2+6+9".forEach { c -> l.key(if (c == '+') "+" else c.toString()) }; l.key("=")
        assertEquals("47", l.expr)
    }
}
