package com.example.calculatorpro

import com.example.calculatorpro.calc.Evaluator
import com.example.calculatorpro.data.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate
import java.time.ZoneId

class CoreTests {
    private fun calc(s: String, deg: Boolean = true) = Evaluator.format(Evaluator.eval(s, deg))
    private val zone = ZoneId.of("Asia/Kolkata")
    private fun ms(d: LocalDate, h: Int, m: Int) = d.atTime(h, m).atZone(zone).toInstant().toEpochMilli()

    @Test fun basicMath() {
        assertEquals("1000", calc("250×4")); assertEquals("100", calc("500÷5"))
        assertEquals("0.3", calc("0.1+0.2")); assertEquals("-5", calc("−5")); assertEquals("540", calc("45×12"))
        assertEquals("0.5", calc("50%")); assertEquals("-4", calc("−2^2")); assertEquals("6", calc("3!"))
    }
    @Test fun scientific() {
        assertEquals("1", calc("sin(90)")); assertEquals("0", calc("cos(90)")); assertEquals("3", calc("√9"))
        assertEquals("2", calc("log(100)")); assertEquals("6.28318530718", calc("2π"))
    }
    @Test(expected = ArithmeticException::class) fun divideByZero() { calc("5÷0") }
    @Test(expected = IllegalArgumentException::class) fun incomplete() { calc("5+") }
    @Test(expected = IllegalArgumentException::class) fun unbalanced() { calc("(5+2") }

    @Test fun customRangeIncludesWholeEndDay() {
        val f = Filters(date = DateF.CUSTOM, customFrom = LocalDate.of(2026, 10, 1), customTo = LocalDate.of(2026, 10, 15))
        val (a, b) = dateRange(f, LocalDate.of(2026, 10, 25), zone)
        assertTrue(ms(LocalDate.of(2026, 10, 15), 23, 59) in a until b)
        assertTrue(ms(LocalDate.of(2026, 10, 1), 0, 0) in a until b)
        assertFalse(ms(LocalDate.of(2026, 10, 16), 0, 0) in a until b)
        assertFalse(ms(LocalDate.of(2026, 9, 30), 23, 59) in a until b)
    }
    @Test fun lastMonthAcrossYearBoundary() {
        val sp = dateSpan(Filters(date = DateF.LAST_MONTH), LocalDate.of(2027, 1, 10))!!
        assertEquals(LocalDate.of(2026, 12, 1), sp.first); assertEquals(LocalDate.of(2027, 1, 1), sp.second)
    }
    @Test fun nightWrapsMidnight() {
        val f = Filters(time = TimeF.NIGHT); val d = LocalDate.of(2026, 10, 25)
        assertTrue(matchesTime(ms(d, 23, 30), f, zone)); assertTrue(matchesTime(ms(d, 4, 59), f, zone))
        assertFalse(matchesTime(ms(d, 5, 0), f, zone)); assertFalse(matchesTime(ms(d, 12, 0), f, zone))
    }
    @Test fun customTimeWindowInclusive() {
        val f = Filters(time = TimeF.CUSTOM, timeFrom = 14 * 60, timeTo = 17 * 60); val d = LocalDate.of(2026, 10, 24)
        assertTrue(matchesTime(ms(d, 14, 0), f, zone)); assertTrue(matchesTime(ms(d, 17, 0), f, zone))
        assertFalse(matchesTime(ms(d, 13, 59), f, zone)); assertFalse(matchesTime(ms(d, 17, 1), f, zone))
    }
}
