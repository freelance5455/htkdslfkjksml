package com.example.calculatorpro.data

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "history", indices = [Index(value = ["timestamp"])])
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val expression: String,
    val result: String,          // plain, re-parsable, e.g. "1000" or "-2.5"
    val resultValue: Double,     // numeric value, used for numeric sorting
    val timestamp: Long,         // epoch millis; local date/time are derived from it at display time
    val calculatorMode: String   // "BASIC" | "SCIENTIFIC"
)

@Dao
interface HistoryDao {
    // REPLACE + explicit id lets "Undo" restore a deleted row with its original id.
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(e: HistoryEntity): Long

    // sort: 0 newest, 1 oldest, 2 largest result, 3 smallest result. instr() avoids LIKE wildcard issues with "%".
    @Query(
        """SELECT * FROM history
           WHERE timestamp >= :fromTs AND timestamp < :toTs
             AND (:q = '' OR instr(expression, :q) > 0 OR instr(result, :q) > 0)
           ORDER BY CASE WHEN :sort = 2 THEN resultValue END DESC,
                    CASE WHEN :sort = 3 THEN resultValue END ASC,
                    CASE WHEN :sort = 1 THEN timestamp END ASC,
                    timestamp DESC"""
    )
    fun observe(fromTs: Long, toTs: Long, q: String, sort: Int): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history") suspend fun all(): List<HistoryEntity>
    @Query("SELECT id FROM history") suspend fun allIds(): List<Long>
    @Query("SELECT id FROM history WHERE timestamp >= :fromTs AND timestamp < :toTs") suspend fun idsInRange(fromTs: Long, toTs: Long): List<Long>
    @Query("SELECT id FROM history WHERE timestamp < :cutoff") suspend fun idsOlderThan(cutoff: Long): List<Long>
    @Query("SELECT COUNT(*) FROM history") fun count(): Flow<Int>
    @Query("SELECT MAX(timestamp) FROM history") fun latest(): Flow<Long?>
    @Delete suspend fun delete(e: HistoryEntity)
    @Query("DELETE FROM history WHERE id IN (:ids)") suspend fun deleteByIds(ids: List<Long>)
    @Query("DELETE FROM history") suspend fun deleteAll()
    @Query("DELETE FROM history WHERE timestamp >= :fromTs AND timestamp < :toTs") suspend fun deleteRange(fromTs: Long, toTs: Long)
    @Query("DELETE FROM history WHERE timestamp < :cutoff") suspend fun deleteOlderThan(cutoff: Long)
}

@Database(entities = [HistoryEntity::class], version = 1, exportSchema = true)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): HistoryDao

    companion object {
        // Add Migration(1, 2) etc. here when the schema changes. Never use fallbackToDestructiveMigration:
        // it would silently wipe the user's history.
        private val MIGRATIONS: Array<Migration> = arrayOf()

        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "calculator_pro.db")
                .addMigrations(*MIGRATIONS)
                .build().also { inst = it }
        }
    }
}
