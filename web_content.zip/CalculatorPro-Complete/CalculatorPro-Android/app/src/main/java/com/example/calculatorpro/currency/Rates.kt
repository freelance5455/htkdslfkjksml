package com.example.calculatorpro.currency

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.math.BigDecimal
import java.net.HttpURLConnection
import java.net.URL
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** [rates]: UPPERCASE code -> units of that currency per 1 USD, exactly as published by the provider for [date]. */
data class RateTable(val date: String, val rates: Map<String, BigDecimal>, val provider: String, val fetchedAt: Long)
enum class Freshness { FRESH, CACHED }
data class Loaded(val table: RateTable, val freshness: Freshness, val note: String?)
data class Pt(val date: LocalDate, val v: BigDecimal)
data class Series(val pts: List<Pt>, val provider: String, val note: String?)

val PROVIDER_FLOOR: LocalDate = LocalDate.of(2024, 3, 2)   // first day published by currency-api

fun parseTable(body: String, provider: String, fetchedAt: Long): RateTable {
    val root = JSONObject(body)
    val usd = root.getJSONObject("usd")
    val m = HashMap<String, BigDecimal>()
    usd.keys().forEach { k -> usd.optString(k).toBigDecimalOrNull()?.let { if (it.signum() > 0) m[k.uppercase()] = it } }
    if (m.size < 20) throw IOException("Unexpected response from provider")
    return RateTable(root.getString("date"), m, provider, fetchedAt)
}

object Http {
    fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000; c.readTimeout = 15000; c.requestMethod = "GET"
            if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }
}

/**
 * Provider: currency-api (fawazahmed0, CC0): daily, indicative mid-market rates for 200+ currencies. NOT real time.
 * Mirrors: jsDelivr CDN, then Cloudflare Pages. Charts for longer periods use ECB reference rates (Frankfurter)
 * when the pair is covered, because currency-api history only starts on 2024-03-02.
 */
class RateRepo(private val dao: CurrencyDao) {
    private val ttl = 6 * 3600_000L   // provider updates daily; no need to hit it more often than this

    private fun urls(d: String) = listOf(
        "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@$d/v1/currencies/usd.min.json",
        "https://$d.currency-api.pages.dev/v1/currencies/usd.json"
    )

    private fun fetch(d: String): Pair<RateTable, String> {
        var last: Exception? = null
        for (u in urls(d)) {
            try {
                val body = Http.get(u)
                val host = URL(u).host
                return parseTable(body, "currency-api via $host", System.currentTimeMillis()) to body
            } catch (e: Exception) { last = e }
        }
        throw last ?: IOException("No response")
    }

    private suspend fun cached(key: String): RateTable? =
        dao.getRate(key)?.let { runCatching { parseTable(it.json, it.provider, it.fetchedAt) }.getOrNull() }

    suspend fun latest(force: Boolean): Result<Loaded> = withContext(Dispatchers.IO) {
        val old = cached("latest")
        if (!force && old != null && System.currentTimeMillis() - old.fetchedAt < ttl)
            return@withContext Result.success(Loaded(old, Freshness.FRESH, null))
        try {
            val (t, body) = fetch("latest")
            dao.putRate(RateRow("latest", body, t.provider, t.fetchedAt))
            Result.success(Loaded(t, Freshness.FRESH, null))
        } catch (e: Exception) {
            if (old != null) Result.success(Loaded(old, Freshness.CACHED, "Can't reach the rate provider. Showing saved rates, which may be outdated."))
            else Result.failure(e)
        }
    }

    /** Rates published for one calendar day; null if the provider has none (or we are offline without a cache). */
    suspend fun onDate(date: LocalDate): RateTable? = withContext(Dispatchers.IO) {
        if (date.isBefore(PROVIDER_FLOOR)) return@withContext null
        val key = date.toString()
        cached(key)?.let { return@withContext it }
        try {
            val (t, body) = fetch(key)
            dao.putRate(RateRow(key, body, t.provider, t.fetchedAt))
            t
        } catch (e: Exception) { null }
    }

    private fun frankfurter(from: String, to: String, start: LocalDate, end: LocalDate): List<Pt>? = try {
        if (from == to) null else {
            val rates = JSONObject(Http.get("https://api.frankfurter.dev/v1/$start..$end?base=$from&symbols=$to")).getJSONObject("rates")
            val out = ArrayList<Pt>()
            rates.keys().forEach { d -> rates.getJSONObject(d).optString(to).toBigDecimalOrNull()?.let { out.add(Pt(LocalDate.parse(d), it)) } }
            out.sortBy { it.date }
            downsample(out, 300)
        }
    } catch (e: Exception) { null }

    /** Real data only. Dense ECB series if the pair is covered; otherwise real daily snapshots from currency-api. */
    suspend fun series(from: String, to: String, start: LocalDate, end: LocalDate): Series = withContext(Dispatchers.IO) {
        frankfurter(from, to, start, end)?.let { if (it.size >= 2) return@withContext Series(it, "ECB reference rates via Frankfurter", null) }
        val s = if (start.isBefore(PROVIDER_FLOOR)) PROVIDER_FLOOR else start
        val days = ChronoUnit.DAYS.between(s, end).toInt().coerceAtLeast(1)
        val n = minOf(days + 1, 30)
        val dates = (0 until n).map { s.plusDays((days.toLong() * it) / (n - 1).coerceAtLeast(1)) }.distinct()
        val sem = Semaphore(6)
        val tables = coroutineScope { dates.map { d -> async { sem.withPermit { onDate(d) } } }.awaitAll() }
        val pts = tables.filterNotNull().mapNotNull { t -> Money.rate(t, from, to)?.let { Pt(LocalDate.parse(t.date), it) } }
            .distinctBy { it.date }.sortedBy { it.date }
        val note = when {
            start.isBefore(PROVIDER_FLOOR) -> "Not enough older data for this pair: this provider's history starts on $PROVIDER_FLOOR."
            pts.size < dates.size -> "Some days were unavailable from the provider, so they are not shown."
            else -> null
        }
        Series(pts, "currency-api (daily snapshots)", note)
    }
}

fun downsample(list: List<Pt>, max: Int): List<Pt> {
    if (list.size <= max) return list
    return (0 until max).map { list[(it.toLong() * (list.size - 1) / (max - 1)).toInt()] }
}
