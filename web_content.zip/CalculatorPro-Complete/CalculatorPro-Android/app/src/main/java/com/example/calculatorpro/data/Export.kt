package com.example.calculatorpro.data

import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** Everything here runs only after an explicit user tap, and always goes through the Android share sheet. */
object Export {
    private fun q(x: String) = "\"" + x.replace("\"", "\"\"") + "\""

    fun csv(list: List<HistoryEntity>): String {
        val d = DateTimeFormatter.ISO_LOCAL_DATE
        val t = DateTimeFormatter.ofPattern("HH:mm:ss")
        val sb = StringBuilder("\uFEFF")   // BOM so Excel shows × and ÷ correctly
        sb.append("Date,Time,Expression,Result,Mode,TimestampMs\r\n")
        list.forEach { e ->
            val z = Fmt.at(e.timestamp)
            sb.append(q(z.format(d))).append(',').append(q(z.format(t))).append(',')
                .append(q(e.expression)).append(',').append(q(e.result)).append(',')
                .append(q(if (e.calculatorMode == "SCIENTIFIC") "Scientific" else "Basic")).append(',')
                .append(e.timestamp).append("\r\n")
        }
        return sb.toString()
    }

    fun entryText(e: HistoryEntity, s: AppSettings): String {
        val z = Fmt.at(e.timestamp)
        return "Calculation: ${e.expression}\nResult: ${Fmt.num(e.result)}\n" +
            "Date: ${Fmt.date(z.toLocalDate(), s)}\nTime: ${Fmt.time(z.toLocalTime(), s)}"
    }

    fun summary(list: List<HistoryEntity>, s: AppSettings): String {
        val sb = StringBuilder("Calculator Pro history (${list.size})\n\n")
        list.forEach { e -> sb.append(Fmt.dateTime(e.timestamp, s)).append(" — ").append(e.expression)
            .append(" = ").append(Fmt.num(e.result)).append('\n') }
        return sb.toString().trimEnd()
    }

    fun shareText(ctx: Context, text: String) {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
        ctx.startActivity(Intent.createChooser(i, "Share"))
    }

    fun shareCsv(ctx: Context, list: List<HistoryEntity>) {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))
        val f = File(dir, "calculator_history_$stamp.csv")
        f.writeText(csv(list), Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Calculator history")
            clipData = ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Export history"))
    }
}
