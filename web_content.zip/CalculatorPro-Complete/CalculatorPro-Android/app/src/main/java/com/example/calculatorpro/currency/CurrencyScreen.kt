package com.example.calculatorpro.currency

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculatorpro.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import kotlin.math.roundToInt

private val TABS = listOf("Convert", "Compare all", "Compare multi", "Historical", "Chart", "Favorites", "History")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyScreen(vm: CurrencyViewModel, settings: AppSettings, startTab: Int, onBack: () -> Unit) {
    var tab by rememberSaveable { mutableIntStateOf(startTab) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.refresh(false) }   // respects the 6 h cache window, so no needless calls
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("Currency exchange") },
                navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                actions = { IconButton({ vm.refresh(true) }, enabled = !vm.loading) { Icon(Icons.Default.Refresh, "Refresh rates") } }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            Banner(vm, settings)
            if (vm.loaded == null && tab != 6) NoRates(vm)
            else when (tab) {
                0 -> ConvertTab(vm, settings)
                1 -> CompareAllTab(vm)
                2 -> MultiTab(vm)
                3 -> HistoricalTab(vm, settings)
                4 -> ChartTab(vm)
                5 -> FavoritesTab(vm)
                else -> ConversionHistoryTab(vm, settings, snackbar) { tab = 0 }
            }
        }
    }
}

@Composable
private fun Banner(vm: CurrencyViewModel, s: AppSettings) {
    if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
    val l = vm.loaded
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        if (l != null) {
            val cached = l.freshness == Freshness.CACHED
            Text(
                (if (cached) "OFFLINE / OUTDATED · saved rates" else "Latest daily rates") +
                    " · rates dated ${l.table.date} · fetched ${Fmt.dateTime(l.table.fetchedAt, s)}",
                style = MaterialTheme.typography.labelMedium, color = if (cached) cs.error else cs.onSurfaceVariant
            )
            Text("Source: ${l.table.provider}. Daily indicative mid-market rates, not real-time and not bank rates.",
                style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
        }
        vm.error?.let { Text(it, style = MaterialTheme.typography.labelMedium, color = cs.error) }
    }
}

@Composable
private fun NoRates(vm: CurrencyViewModel) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        if (vm.loading) CircularProgressIndicator() else {
            Text("No exchange rates available yet.", style = MaterialTheme.typography.titleMedium)
            Text("Rates are never invented. Connect to the internet once; after that they are cached for offline use.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            Button({ vm.refresh(true) }) { Text("Retry") }
        }
    }
}

private fun copyText(ctx: android.content.Context, t: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Currency", t))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

/* ---------------------------------------------------------------- picker + info */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CurrencyPicker(vm: CurrencyViewModel, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val all = vm.supported
    val shown = Catalog.search(all, q)
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)) {
        Column(Modifier.fillMaxHeight(0.92f)) {
            OutlinedTextField(
                q, { q = it }, singleLine = true, shape = RoundedCornerShape(28.dp),
                placeholder = { Text("Search country, currency, code or symbol") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
            )
            LazyColumn(Modifier.weight(1f)) {
                if (q.isBlank()) {
                    val fav = vm.favorites.mapNotNull { Catalog.byCode[it] }.filter { it in all }
                    val rec = vm.recents.mapNotNull { Catalog.byCode[it] }.filter { it in all }
                    if (fav.isNotEmpty()) { item { PickerHeader("Favorites") }; items(fav, key = { "f" + it.code }) { PickerRow(it, vm, onPick) } }
                    if (rec.isNotEmpty()) { item { PickerHeader("Recent") }; items(rec, key = { "r" + it.code }) { PickerRow(it, vm, onPick) } }
                    item { PickerHeader("All currencies (${all.size})") }
                }
                items(shown, key = { "a" + it.code }) { PickerRow(it, vm, onPick) }
                if (shown.isEmpty()) item { Text("No currency matches “$q”.", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
private fun PickerHeader(t: String) =
    Text(t, Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)

@Composable
private fun PickerRow(c: Cur, vm: CurrencyViewModel, onPick: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onPick(c.code) }.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(c.flag, fontSize = 28.sp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("${c.code} · ${c.name}  ${c.symbol}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(c.countryLine, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        IconButton({ vm.toggleFav(c.code) }) {
            Icon(if (c.code in vm.favorites) Icons.Default.Star else Icons.Default.StarBorder, "Favorite")
        }
    }
}

@Composable
private fun InfoDialog(c: Cur, vm: CurrencyViewModel, s: AppSettings, onDismiss: () -> Unit) {
    val l = vm.loaded
    val per = l?.let { Money.rate(it.table, "USD", c.code) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${c.flag}  ${c.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("OFFICIAL CURRENCY INFORMATION", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text("Code: ${c.code}\nSymbol: ${c.symbol}\nDecimal places: ${c.digits}\nUsed in: ${c.countryLine}")
                Text("EXCHANGE RATE INFORMATION", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                if (per != null && l != null) Text("1 USD = ${Money.fmtRate(per)} ${c.code}\nRates dated ${l.table.date}\nFetched ${Fmt.dateTime(l.table.fetchedAt, s)}")
                else Text("No rate available from the provider.")
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("Close") } }
    )
}

/* ---------------------------------------------------------------- 1. convert */

@Composable
private fun PanelCard(label: String, cur: Cur?, code: String, onPick: () -> Unit, onInfo: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onPick).padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(cur?.flag ?: "🌐", fontSize = 34.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("$code · ${cur?.name ?: ""}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(cur?.countryLine ?: "", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onInfo) { Icon(Icons.Default.Info, "Currency info") }
                Icon(Icons.Default.ArrowDropDown, null)
            }
            content()
        }
    }
}

@Composable
private fun ConvertTab(vm: CurrencyViewModel, s: AppSettings) {
    val ctx = LocalContext.current
    val l = vm.loaded ?: return
    var picker by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<Cur?>(null) }
    val fromC = Catalog.byCode[vm.from]; val toC = Catalog.byCode[vm.to]
    val amt = Money.parseAmount(vm.amount)
    val rate = Money.rate(l.table, vm.from, vm.to)
    val result = if (amt != null && rate != null && toC != null) Money.convert(amt, rate, toC.digits) else null

    LaunchedEffect(vm.from, vm.to, vm.amount, l.table.date, l.freshness) {   // save once the user stops typing
        delay(1500)
        if (amt != null && rate != null && result != null) vm.saveLatest(amt, rate, result)
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        PanelCard("FROM", fromC, vm.from, { picker = "from" }, { info = fromC }) {
            OutlinedTextField(
                vm.amount, { vm.setAmount(it) }, label = { Text("Amount") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), textStyle = MaterialTheme.typography.headlineSmall,
                isError = vm.amount.isNotEmpty() && amt == null
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            TextButton({ vm.setAmount("") }) { Text("Clear") }
            FilledTonalIconButton({ vm.swap() }) { Icon(Icons.Default.SwapVert, "Swap currencies") }
            TextButton({ result?.let { copyText(ctx, it.toPlainString() + " " + vm.to) } }, enabled = result != null) { Text("Copy result") }
        }
        PanelCard("TO", toC, vm.to, { picker = "to" }, { info = toC }) {
            Text(result?.let { Money.fmt(it, toC!!.digits) + " " + (toC.symbol) } ?: "—", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        if (rate != null) {
            Text("1 ${vm.from} = ${Money.fmtRate(rate)} ${vm.to}", style = MaterialTheme.typography.titleMedium)
            if (Money.viaUsd(vm.from, vm.to)) Text("Cross rate calculated via USD: ${vm.from} → USD → ${vm.to}", color = MaterialTheme.colorScheme.tertiary)
            Text("Rates dated ${l.table.date} · " + if (l.freshness == Freshness.FRESH) "latest daily" else "CACHED, may be outdated",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else Text("The provider has no rate for ${vm.from} → ${vm.to}.", color = MaterialTheme.colorScheme.error)
        val quick = (vm.favorites + vm.recents).distinct().take(12)
        if (quick.isNotEmpty()) {
            Text("Quick pick (sets TO)", style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(quick) { c -> AssistChip({ vm.setTo(c) }, label = { Text((Catalog.byCode[c]?.flag ?: "") + " " + c) }) }
            }
        }
    }
    picker?.let { which -> CurrencyPicker(vm, { if (which == "from") vm.setFrom(it) else vm.setTo(it); picker = null }, { picker = null }) }
    info?.let { InfoDialog(it, vm, s) { info = null } }
}

/* ---------------------------------------------------------------- 2. compare all */

private enum class CmpSort(val label: String) { COUNTRY("Country A–Z"), NAME("Currency name"), HIGH("Highest rate"), LOW("Lowest rate") }

@Composable
private fun CompareAllTab(vm: CurrencyViewModel) {
    val l = vm.loaded ?: return
    var base by rememberSaveable { mutableStateOf(vm.from) }
    var amountText by rememberSaveable { mutableStateOf("1") }
    var q by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(CmpSort.COUNTRY) }
    var picking by remember { mutableStateOf(false) }
    val amt = Money.parseAmount(amountText)
    val rows = remember(base, amt, l.table, q, sort) {
        val list = Catalog.search(vm.supported.filter { it.code != base }, q).mapNotNull { c -> Money.rate(l.table, base, c.code)?.let { c to it } }
        when (sort) {
            CmpSort.COUNTRY -> list.sortedBy { it.first.firstCountry }
            CmpSort.NAME -> list.sortedBy { it.first.name }
            CmpSort.HIGH -> list.sortedByDescending { it.second }
            CmpSort.LOW -> list.sortedBy { it.second }
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp, 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ picking = true }) { Text((Catalog.byCode[base]?.flag ?: "") + " " + base) }
            OutlinedTextField(amountText, { amountText = it.filter { c -> c.isDigit() || c == '.' }.take(20) }, label = { Text("Amount") }, singleLine = true,
                modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        }
        OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text("Filter: country, currency, code") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        LazyRow(contentPadding = PaddingValues(16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(CmpSort.entries.toList()) { s -> FilterChip(sort == s, { sort = s }, label = { Text(s.label) }) }
        }
        Text("${rows.size} currencies", Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.labelMedium)
        LazyColumn(Modifier.weight(1f)) {
            items(rows, key = { it.first.code }) { (c, r) ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c.flag, fontSize = 26.sp); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${c.firstCountry}" + if (c.countries.size > 1) " +${c.countries.size - 1}" else "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${c.code} · 1 $base = ${Money.fmtRate(r)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(amt?.let { Money.fmt(Money.convert(it, r, c.digits), c.digits) } ?: "—", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
    if (picking) CurrencyPicker(vm, { base = it; picking = false }, { picking = false })
}

/* ---------------------------------------------------------------- 3. compare multiple */

@Composable
private fun MultiTab(vm: CurrencyViewModel) {
    val l = vm.loaded ?: return
    var amountText by rememberSaveable { mutableStateOf("1") }
    var pick by remember { mutableStateOf<String?>(null) }
    val amt = Money.parseAmount(amountText)
    val base = vm.multiBase
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ pick = "base" }) { Text("Base: " + (Catalog.byCode[base]?.flag ?: "") + " " + base) }
            OutlinedTextField(amountText, { amountText = it.filter { c -> c.isDigit() || c == '.' }.take(20) }, label = { Text("Amount") }, singleLine = true,
                modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Text("Currency", Modifier.weight(1.2f), style = MaterialTheme.typography.labelMedium)
            Text("Rate", Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
            Text("Amount", Modifier.weight(1.2f), style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.width(40.dp))
        }
        HorizontalDivider()
        (listOf(base) + vm.multi.filter { it != base }).forEach { code ->
            val c = Catalog.byCode[code]; val r = Money.rate(l.table, base, code)
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text((c?.flag ?: "") + " " + code, Modifier.weight(1.2f), fontWeight = FontWeight.SemiBold)
                Text(r?.let { Money.fmtRate(it) } ?: "n/a", Modifier.weight(1f))
                Text(if (amt != null && r != null && c != null) Money.fmt(Money.convert(amt, r, c.digits), c.digits) else "—", Modifier.weight(1.2f))
                if (code == base) Spacer(Modifier.width(40.dp)) else IconButton({ vm.removeMulti(code) }, Modifier.width(40.dp)) { Icon(Icons.Default.Close, "Remove $code") }
            }
        }
        Button({ pick = "add" }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add currency") }
    }
    pick?.let { w -> CurrencyPicker(vm, { if (w == "base") vm.setMultiBase(it) else vm.addMulti(it); pick = null }, { pick = null }) }
}

/* ---------------------------------------------------------------- 4. historical */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HistoricalTab(vm: CurrencyViewModel, s: AppSettings) {
    var range by rememberSaveable { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<Pair<LocalDate, LocalDate>?>(null) }
    var sel by remember { mutableIntStateOf(-1) }
    val toC = Catalog.byCode[vm.to]
    LaunchedEffect(Unit) { vm.clearSeries() }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${vm.amount} ${vm.from} → ${vm.to}  (change currencies and amount on the Convert tab)", style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(!range, { range = false }, label = { Text("Single date") })
            FilterChip(range, { range = true }, label = { Text("Date range") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!range) {
                OutlinedButton({ vm.lookupDate(LocalDate.now().minusDays(1)) }) { Text("Previous day") }
                OutlinedButton({ vm.lookupDate(LocalDate.now()) }) { Text("Today / latest") }
            }
            Button({ showPicker = true }) { Text(if (range) "Pick range" else "Pick date") }
        }
        Text("Provider history starts on $PROVIDER_FLOOR for most currencies.", style = MaterialTheme.typography.labelSmall)
        if (vm.histLoading || vm.seriesLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.histMsg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        vm.hist?.takeIf { !range }?.let { h ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("HISTORICAL RATE · not the current rate", style = MaterialTheme.typography.labelMedium)
                    Text("Rate date: ${h.tableDate}" + if (h.tableDate != h.requested.toString()) "  (requested ${h.requested})" else "", fontWeight = FontWeight.SemiBold)
                    Text("1 ${vm.from} = ${Money.fmtRate(h.rate)} ${vm.to}", style = MaterialTheme.typography.titleMedium)
                    Text("${vm.amount} ${vm.from} = ${Money.fmt(h.converted, toC?.digits ?: 2)} ${vm.to}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    h.dayChangePct?.let { Text("Change vs previous day: ${signed(it)}%") } ?: Text("Previous-day rate not available.")
                    h.vsLatestPct?.let { Text("Change from then to latest: ${signed(it)}%") }
                    Text("Source: ${h.provider}", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        vm.series?.takeIf { range }?.let { sr -> SeriesCard(sr, sel, { sel = it }, vm) }
    }
    if (showPicker) {
        val floorMs = PROVIDER_FLOOR.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val rule = object : SelectableDates {
            override fun isSelectableDate(utcTimeMillis: Long): Boolean {
                val d = Instant.ofEpochMilli(utcTimeMillis).atZone(ZoneOffset.UTC).toLocalDate()
                return utcTimeMillis >= floorMs && !d.isAfter(LocalDate.now())
            }
        }
        if (!range) {
            val st = rememberDatePickerState(selectableDates = rule)
            DatePickerDialog({ showPicker = false },
                confirmButton = { TextButton(enabled = st.selectedDateMillis != null, onClick = {
                    showPicker = false; vm.lookupDate(Instant.ofEpochMilli(st.selectedDateMillis!!).atZone(ZoneOffset.UTC).toLocalDate()) }) { Text("Convert") } },
                dismissButton = { TextButton({ showPicker = false }) { Text("Cancel") } }) { DatePicker(st) }
        } else {
            val st = rememberDateRangePickerState(selectableDates = rule)
            DatePickerDialog({ showPicker = false },
                confirmButton = { TextButton(enabled = st.selectedStartDateMillis != null, onClick = {
                    showPicker = false
                    val a = Instant.ofEpochMilli(st.selectedStartDateMillis!!).atZone(ZoneOffset.UTC).toLocalDate()
                    val b = st.selectedEndDateMillis?.let { Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate() } ?: a
                    picked = a to b; sel = -1; vm.loadSeries(a, b) }) { Text("Show") } },
                dismissButton = { TextButton({ showPicker = false }) { Text("Cancel") } }) { DateRangePicker(st, Modifier.height(500.dp)) }
        }
    }
}

private fun signed(v: BigDecimal) = (if (v.signum() > 0) "+" else "") + v.toPlainString()

/* ---------------------------------------------------------------- 5. chart */

@Composable
private fun SeriesCard(sr: Series, sel: Int, onSel: (Int) -> Unit, vm: CurrencyViewModel) {
    if (sr.pts.size < 2) { Text("Not enough real data points for this pair and period." + (sr.note?.let { "\n$it" } ?: ""), color = MaterialTheme.colorScheme.error); return }
    val i = if (sel in sr.pts.indices) sel else sr.pts.lastIndex
    val p = sr.pts[i]; val first = sr.pts.first(); val last = sr.pts.last()
    val hi = sr.pts.maxOf { it.v }; val lo = sr.pts.minOf { it.v }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("${p.date}: 1 ${vm.from} = ${Money.fmtRate(p.v)} ${vm.to}", fontWeight = FontWeight.SemiBold)
            LineChart(sr.pts, Modifier.fillMaxWidth().height(200.dp), i, onSel)
            val ch = Money.pct(first.v, last.v)
            Text("${first.date} → ${last.date}: " + (ch?.let { (if (it.signum() >= 0) "▲ " else "▼ ") + signed(it) + "%" } ?: "—"), fontWeight = FontWeight.Bold,
                color = if (ch != null && ch.signum() < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            Text("High ${Money.fmtRate(hi)} · Low ${Money.fmtRate(lo)} · ${sr.pts.size} real data points", style = MaterialTheme.typography.bodySmall)
            Text("Source: ${sr.provider}", style = MaterialTheme.typography.labelSmall)
            sr.note?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error) }
        }
    }
}

@Composable
private fun LineChart(pts: List<Pt>, modifier: Modifier, selected: Int, onSelect: (Int) -> Unit) {
    val color = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant
    val vals = remember(pts) { pts.map { it.v.toFloat() } }   // floats are for drawing only
    val mn = vals.min(); val mx = vals.max()
    Canvas(
        modifier
            .pointerInput(pts) { detectTapGestures { o -> onSelect(((o.x / size.width) * (pts.size - 1)).roundToInt().coerceIn(0, pts.size - 1)) } }
            .pointerInput(pts) { detectDragGestures { ch, _ -> onSelect(((ch.position.x / size.width) * (pts.size - 1)).roundToInt().coerceIn(0, pts.size - 1)) } }
    ) {
        val w = size.width; val h = size.height
        val span = if (mx - mn > 0f) mx - mn else 1f
        fun x(i: Int) = w * i / (vals.size - 1)
        fun y(v: Float) = h - (v - mn) / span * (h * 0.9f) - h * 0.05f
        for (k in 0..3) drawLine(grid, Offset(0f, h * k / 3), Offset(w, h * k / 3), 1f)
        val path = Path()
        vals.forEachIndexed { i, v -> if (i == 0) path.moveTo(x(i), y(v)) else path.lineTo(x(i), y(v)) }
        drawPath(path, color, style = Stroke(width = 4f))
        if (selected in vals.indices) {
            drawLine(color.copy(alpha = 0.4f), Offset(x(selected), 0f), Offset(x(selected), h), 2f)
            drawCircle(color, 10f, Offset(x(selected), y(vals[selected])))
        }
    }
}

@Composable
private fun ChartTab(vm: CurrencyViewModel) {
    val ctx = LocalContext.current
    var period by rememberSaveable { mutableIntStateOf(1) }
    var sel by remember { mutableIntStateOf(-1) }
    val periods = listOf("1D", "7D", "1M", "3M", "6M", "1Y", "5Y", "Max")
    fun load(p: Int) {
        val end = LocalDate.now()
        val start = when (p) { 1 -> end.minusDays(7); 2 -> end.minusMonths(1); 3 -> end.minusMonths(3); 4 -> end.minusMonths(6)
            5 -> end.minusYears(1); 6 -> end.minusYears(5); else -> LocalDate.of(1999, 1, 4) }
        sel = -1; vm.loadSeries(start, end)
    }
    LaunchedEffect(vm.from, vm.to, period) { if (period != 0) load(period) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("${Catalog.byCode[vm.from]?.flag ?: ""} ${vm.from} → ${Catalog.byCode[vm.to]?.flag ?: ""} ${vm.to}", style = MaterialTheme.typography.titleLarge)
        Text("Change the pair on the Convert tab.", style = MaterialTheme.typography.labelSmall)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(periods.indices.toList()) { i ->
                FilterChip(period == i, {
                    if (i == 0) Toast.makeText(ctx, "1 day: providers publish daily rates only, so there is no intraday data to chart.", Toast.LENGTH_LONG).show() else period = i
                }, label = { Text(periods[i]) })
            }
        }
        if (vm.from == vm.to) Text("Pick two different currencies.")
        if (vm.seriesLoading) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.series?.let { SeriesCard(it, sel, { s -> sel = s }, vm) }
        Text("Charts show only real published rates. 5Y/Max use ECB history (about 30 major currencies, back to 1999); other pairs are limited to $PROVIDER_FLOOR onward.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/* ---------------------------------------------------------------- 6. favourites */

@Composable
private fun FavoritesTab(vm: CurrencyViewModel) {
    var adding by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button({ adding = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add favorite") }
        if (vm.favorites.isEmpty()) Text("No favorites yet. Star any currency in the picker, or add one here.", Modifier.padding(top = 16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn {
            items(vm.favorites, key = { it }) { code ->
                val c = Catalog.byCode[code]
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(c?.flag ?: "🌐", fontSize = 26.sp); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) { Text("$code · ${c?.name ?: ""}", fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(c?.countryLine ?: "", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    IconButton({ vm.moveFav(code, -1) }) { Icon(Icons.Default.KeyboardArrowUp, "Move up") }
                    IconButton({ vm.moveFav(code, 1) }) { Icon(Icons.Default.KeyboardArrowDown, "Move down") }
                    IconButton({ vm.toggleFav(code) }) { Icon(Icons.Default.Delete, "Remove") }
                }
            }
        }
    }
    if (adding) CurrencyPicker(vm, { if (it !in vm.favorites) vm.toggleFav(it); adding = false }, { adding = false })
}

/* ---------------------------------------------------------------- 7. conversion history */

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConversionHistoryTab(vm: CurrencyViewModel, s: AppSettings, snackbar: SnackbarHostState, onRepeat: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val raw by vm.conversions.collectAsState()
    val f by vm.filters.collectAsState()
    val list = raw ?: emptyList()
    var confirm by remember { mutableStateOf<String?>(null) }
    var query by rememberSaveable { mutableStateOf(f.query) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            OutlinedTextField(query, { query = it; vm.editFilters { x -> x.copy(query = it) } }, singleLine = true, shape = RoundedCornerShape(28.dp),
                placeholder = { Text("Search currency code or amount") }, leadingIcon = { Icon(Icons.Default.Search, null) },
                modifier = Modifier.fillMaxWidth().padding(16.dp, 8.dp))
        }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(DateF.entries.filter { it != DateF.CUSTOM }) { d -> FilterChip(f.date == d, { vm.editFilters { it.copy(date = d) } }, label = { Text(d.label) }) }
            }
        }
        item {
            LazyRow(contentPadding = PaddingValues(16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TimeF.entries.filter { it != TimeF.CUSTOM }) { t -> FilterChip(f.time == t, { vm.editFilters { it.copy(time = t) } }, label = { Text(t.label) }) }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ if (list.isEmpty()) Toast.makeText(ctx, "Nothing to export", Toast.LENGTH_SHORT).show() else vm.exportCsv(ctx, list) }) { Text("Export CSV") }
                if (f.date != DateF.ALL) OutlinedButton({ confirm = "range" }) { Text("Clear range") }
                OutlinedButton({ confirm = "all" }) { Text("Clear all") }
            }
        }
        if (raw != null && list.isEmpty()) item { Text("No currency conversions here yet. Conversions are saved automatically after you stop typing.", Modifier.padding(32.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        var cur = ""
        list.forEach { e ->
            val z = Fmt.at(e.timestamp); val day = z.toLocalDate()
            if (day.toString() != cur) { cur = day.toString(); item(key = "h$cur") { Text(Fmt.dayLabel(day, s).uppercase() + "  " + Fmt.date(day, s), Modifier.padding(20.dp, 12.dp, 20.dp, 4.dp), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) } }
            item(key = e.id) {
                var menu by remember { mutableStateOf(false) }
                val digits = Catalog.byCode[e.toCode]?.digits ?: 2
                Row(Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceContainerLow).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("${e.amount} ${e.fromCode} → ${Money.fmt(BigDecimal(e.result), digits)} ${e.toCode}", fontWeight = FontWeight.SemiBold)
                        Text("1 ${e.fromCode} = ${Money.fmtRate(BigDecimal(e.rate))} ${e.toCode} · " + (if (e.kind == "HISTORICAL") "HISTORICAL ${e.rateDate}" else "rates ${e.rateDate}") +
                            (if (e.freshness == "CACHED") " · CACHED" else "") + (if (e.viaUsd) " · via USD" else ""), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(e.provider, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(Fmt.time(z.toLocalTime(), s), style = MaterialTheme.typography.labelLarge)
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Actions") }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem({ Text("Repeat conversion") }, { menu = false; vm.repeat(e); onRepeat() })
                            DropdownMenuItem({ Text("Copy result") }, { menu = false; copyText(ctx, e.result + " " + e.toCode) })
                            DropdownMenuItem({ Text("Delete") }, { menu = false; vm.delete(e)
                                scope.launch { snackbar.currentSnackbarData?.dismiss(); if (snackbar.showSnackbar("Conversion deleted", "Undo") == SnackbarResult.ActionPerformed) vm.restore(e) } })
                        }
                    }
                }
            }
        }
    }
    confirm?.let { c ->
        AlertDialog(onDismissRequest = { confirm = null },
            title = { Text(if (c == "all") "Clear all conversions?" else "Clear this date range?") },
            text = { Text(if (c == "all") "All saved currency conversions will be permanently deleted." else "Every conversion from ${Fmt.spanLabel(f, s)} will be permanently deleted.") },
            confirmButton = { TextButton({ if (c == "all") vm.clearAll() else vm.clearRange(); confirm = null }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancel") } })
    }
}

@Composable
private fun Modifier.background(MaterialTheme.colorScheme.surfaceContainerLow): Modifier = this.then(Modifier.background(MaterialTheme.colorScheme.surfaceContainerLow))
