package com.example.calculatorpro

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.calculatorpro.currency.CurrencyScreen
import com.example.calculatorpro.currency.CurrencyViewModel

enum class Screen { CALC, HISTORY, SETTINGS, CURRENCY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val vm: MainViewModel = viewModel()
                    App(vm)
                }
            }
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App(vm: MainViewModel) {
    val user by vm.user.collectAsState()
    if (vm.cloud && user == null) LoginScreen(vm) else MainFlow(vm)   // sign-in is mandatory; the session is kept until the user logs out
}

@Composable
fun MainFlow(vm: MainViewModel) {
    val cvm: CurrencyViewModel = viewModel()
    var screen by rememberSaveable { mutableStateOf(Screen.CALC) }
    var currencyFrom by rememberSaveable { mutableStateOf(Screen.CALC) }
    var currencyTab by rememberSaveable { mutableIntStateOf(0) }
    BackHandler(screen == Screen.SETTINGS) { screen = Screen.HISTORY }
    BackHandler(screen == Screen.HISTORY) { screen = Screen.CALC }
    BackHandler(screen == Screen.CURRENCY) { screen = currencyFrom }
    when (screen) {
        Screen.CALC -> CalculatorScreen(
            vm, onHistory = { screen = Screen.HISTORY },
            onCurrency = { currencyTab = 0; currencyFrom = Screen.CALC; screen = Screen.CURRENCY }
        )
        Screen.HISTORY -> HistoryScreen(
            vm, onBack = { screen = Screen.CALC }, onSettings = { screen = Screen.SETTINGS },
            onCurrencyHistory = { currencyTab = 6; currencyFrom = Screen.HISTORY; screen = Screen.CURRENCY }
        )
        Screen.SETTINGS -> SettingsScreen(vm, onBack = { screen = Screen.HISTORY })
        Screen.CURRENCY -> CurrencyScreen(cvm, vm.settings, currencyTab) { screen = currencyFrom }
    }
}
