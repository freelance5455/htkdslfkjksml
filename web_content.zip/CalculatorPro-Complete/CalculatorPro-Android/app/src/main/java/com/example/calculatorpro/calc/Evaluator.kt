package com.example.calculatorpro.calc

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

object Evaluator {
    /** Throws ArithmeticException (math error) or IllegalArgumentException (bad/incomplete expression). */
    fun eval(src: String, degrees: Boolean): Double {
        val v = Parser(src, degrees).run()
        if (v.isNaN() || v.isInfinite()) throw ArithmeticException("Invalid result")
        return v
    }

    /** Plain, re-parsable string with 12 significant digits ("0.1+0.2" -> "0.3"). */
    fun format(v: Double): String {
        if (v == 0.0) return "0"
        val bd = BigDecimal(v).round(MathContext(12)).stripTrailingZeros()
        val a = abs(v)
        return if (a >= 1e15 || a < 1e-9) bd.toString() else bd.toPlainString()
    }

    private class Parser(src: String, val deg: Boolean) {
        private val s = src.replace(" ", "")
        private var i = 0
        private fun fail(): Nothing = throw IllegalArgumentException("Invalid expression")
        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        private fun peekAt(o: Int): Char = if (i + o < s.length) s[i + o] else '\u0000'

        fun run(): Double {
            if (s.isEmpty()) fail()
            val v = expr()
            if (i < s.length) fail()
            return v
        }

        private fun expr(): Double {
            var v = term()
            while (true) {
                when (peek()) {
                    '+' -> { i++; v += term() }
                    '-', '−' -> { i++; v -= term() }
                    else -> return v
                }
            }
        }

        private fun term(): Double {
            var v = unary()
            while (true) {
                val c = peek()
                when {
                    c == '×' || c == '*' -> { i++; v *= unary() }
                    c == '÷' || c == '/' -> {
                        i++
                        val d = unary()
                        if (d == 0.0) throw ArithmeticException("Cannot divide by zero")
                        v /= d
                    }
                    c == '(' || c == 'π' || c == '√' || c.isLetter() -> v *= unary() // implicit multiplication
                    else -> return v
                }
            }
        }

        private fun unary(): Double = when (peek()) {
            '-', '−' -> { i++; -unary() }
            '+' -> { i++; unary() }
            else -> power()
        }

        private fun power(): Double {
            val b = postfix()
            if (peek() == '^') { i++; return b.pow(unary()) }
            return b
        }

        private fun postfix(): Double {
            var v = primary()
            while (true) {
                when (peek()) {
                    '!' -> { i++; v = factorial(v) }
                    '%' -> { i++; v /= 100.0 }
                    else -> return v
                }
            }
        }

        private fun primary(): Double {
            val c = peek()
            return when {
                c.isDigit() || c == '.' -> number()
                c == '(' -> {
                    i++
                    val v = expr()
                    if (peek() != ')') fail()
                    i++
                    v
                }
                c == 'π' -> { i++; PI }
                c == '√' -> {
                    i++
                    val a = primary()
                    if (a < 0) throw ArithmeticException("Invalid input")
                    sqrt(a)
                }
                c.isLetter() -> ident()
                else -> fail()
            }
        }

        private fun number(): Double {
            val st = i
            while (peek().isDigit() || peek() == '.') i++
            val p1 = peekAt(1)
            if (peek() == 'E' && (p1.isDigit() || ((p1 == '+' || p1 == '-') && peekAt(2).isDigit()))) {
                i += 2
                while (peek().isDigit()) i++
            }
            return s.substring(st, i).toDoubleOrNull() ?: fail()
        }

        private fun rad(a: Double) = if (deg) Math.toRadians(a) else a
        private fun clean(x: Double) = if (abs(x) < 1e-12) 0.0 else x

        private fun ident(): Double {
            val st = i
            while (peek().isLetter()) i++
            val name = s.substring(st, i)
            if (name == "e") return E
            if (peek() != '(') fail()
            i++
            val a = expr()
            if (peek() != ')') fail()
            i++
            return when (name) {
                "sin" -> clean(sin(rad(a)))
                "cos" -> clean(cos(rad(a)))
                "tan" -> {
                    if (deg && ((a % 180.0) + 180.0) % 180.0 == 90.0) throw ArithmeticException("Undefined")
                    clean(tan(rad(a)))
                }
                "ln" -> { if (a <= 0) throw ArithmeticException("Invalid input"); ln(a) }
                "log" -> { if (a <= 0) throw ArithmeticException("Invalid input"); log10(a) }
                "sqrt" -> { if (a < 0) throw ArithmeticException("Invalid input"); sqrt(a) }
                else -> fail()
            }
        }

        private fun factorial(v: Double): Double {
            if (v < 0 || v != floor(v) || v > 170) throw ArithmeticException("Invalid input")
            var r = 1.0
            for (k in 2..v.toInt()) r *= k
            return r
        }
    }
}
