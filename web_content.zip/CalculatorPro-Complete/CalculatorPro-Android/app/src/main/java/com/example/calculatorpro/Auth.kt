package com.example.calculatorpro

import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.calculatorpro.data.HistoryEntity
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.tasks.await

/**
 * Sign-in. Google (Gmail) uses the full "Sign in with Google" account chooser (works even when the phone has
 * never authorised this app). Email + password is a backup that needs no SHA-1 / OAuth setup.
 * Both end in a Firebase user, so history is stored under the same users/{uid}/history path.
 */
class AuthRepo(private val enabled: Boolean) {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val _user = MutableStateFlow<FirebaseUser?>(if (enabled) FirebaseAuth.getInstance().currentUser else null)
    val user: StateFlow<FirebaseUser?> = _user

    init { if (enabled) auth.addAuthStateListener { _user.value = it.currentUser } }

    /** Returns null on success, otherwise a message to show. [activityCtx] must be an Activity context. */
    suspend fun signIn(activityCtx: Context): String? {
        return try {
            val idRes = activityCtx.resources.getIdentifier("default_web_client_id", "string", activityCtx.packageName)
            if (idRes == 0) return "Google sign-in is not configured (google-services.json missing). Use Email & password or add the file."
            val option = GetSignInWithGoogleOption.Builder(activityCtx.getString(idRes)).build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val cred = CredentialManager.create(activityCtx).getCredential(activityCtx, request).credential
            if (cred is CustomCredential && cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
                null
            } else "Unsupported sign-in method."
        } catch (e: GetCredentialCancellationException) {
            "Sign-in cancelled."
        } catch (e: NoCredentialException) {
            "No Google account found on this phone. Add a Gmail account in Settings → Accounts and try again."
        } catch (e: GetCredentialException) {
            "Google sign-in is not set up correctly for this build. Usually the SHA-1 is missing in Firebase, or google-services.json is old. " +
                "Meanwhile you can use Email & password below.\n[${e.type}] ${e.message ?: ""}"
        } catch (e: FirebaseNetworkException) {
            "No internet connection."
        } catch (e: Exception) {
            e.message ?: "Sign-in failed."
        }
    }

    suspend fun emailAuth(email: String, password: String, create: Boolean): String? {
        return try {
            if (create) auth.createUserWithEmailAndPassword(email, password).await()
            else auth.signInWithEmailAndPassword(email, password).await()
            null
        } catch (e: FirebaseAuthWeakPasswordException) {
            "Password must be at least 6 characters."
        } catch (e: FirebaseAuthUserCollisionException) {
            "This email already has an account. Tap Log in."
        } catch (e: FirebaseAuthInvalidUserException) {
            "No account with this email. Tap Create account."
        } catch (e: FirebaseAuthInvalidCredentialsException) {
            "Wrong email or password. (If you have no account yet, tap Create account.)"
        } catch (e: FirebaseNetworkException) {
            "No internet connection."
        } catch (e: Exception) {
            e.message ?: "Failed."
        }
    }

    suspend fun signOut(ctx: Context) {
        if (enabled) auth.signOut()
        runCatching { CredentialManager.create(ctx).clearCredentialState(ClearCredentialStateRequest()) }
    }
}

fun HistoryEntity.toMap(): Map<String, Any> = mapOf(
    "expression" to expression, "result" to result, "resultValue" to resultValue,
    "timestamp" to timestamp, "calculatorMode" to calculatorMode
)

fun DocumentSnapshot.toEntity(): HistoryEntity? {
    val id = id.toLongOrNull() ?: return null
    return HistoryEntity(
        id = id,
        expression = getString("expression") ?: return null,
        result = getString("result") ?: return null,
        resultValue = getDouble("resultValue") ?: 0.0,
        timestamp = getLong("timestamp") ?: return null,
        calculatorMode = getString("calculatorMode") ?: "BASIC"
    )
}
