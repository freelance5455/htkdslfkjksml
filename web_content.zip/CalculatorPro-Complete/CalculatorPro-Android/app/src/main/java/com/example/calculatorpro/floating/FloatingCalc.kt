package com.example.calculatorpro.floating

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat

/**
 * Entry points for the floating calculator.
 * Flow: button -> permission granted? start : explain (dialog) -> Android "Display over other apps" screen ->
 * back in the app -> MainActivity.onResume() -> starts automatically if allowed, otherwise says so.
 */
object FloatingCalc {
    private var pending = false

    fun canDraw(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    /** Call only when [canDraw] is true. Starts the overlay service and returns to the app underneath. */
    fun start(ctx: Context) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingCalcService::class.java))
        (ctx as? Activity)?.moveTaskToBack(true)
    }

    fun openPermissionSettings(ctx: Context) {
        pending = true
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
    }

    fun resumeIfPending(activity: Activity) {
        if (!pending) return
        pending = false
        if (canDraw(activity)) start(activity)
        else Toast.makeText(
            activity, "Permission was not granted, so the floating calculator can't open. You can allow it later with the floating-window button.",
            Toast.LENGTH_LONG
        ).show()
    }
}
