package com.example.calculatorpro

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun LoginScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var email by rememberSaveable { mutableStateOf("") }
    var pw by remember { mutableStateOf("") }
    fun go(block: suspend () -> String?) { busy = true; msg = null; scope.launch { msg = block(); busy = false } }
    fun emailFlow(create: Boolean) {
        val e = email.trim()
        when {
            !android.util.Patterns.EMAIL_ADDRESS.matcher(e).matches() -> msg = "Enter a valid email address."
            pw.length < 6 -> msg = "Password must be at least 6 characters."
            else -> go { vm.emailAuth(e, pw, create) }
        }
    }
    val mut = MaterialTheme.colorScheme.onSurfaceVariant
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Calculator Pro", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "Sign in once to start. You stay signed in, so the calculator opens instantly any time, even offline. Log out and sign in again with the same account to get all your history back.",
            textAlign = TextAlign.Center, color = mut
        )
        Spacer(Modifier.height(24.dp))
        Button(enabled = !busy, modifier = Modifier.fillMaxWidth(), onClick = { go { vm.signIn(ctx) } }) {
            Text(if (busy) "Please wait…" else "Continue with Google (Gmail)")
        }
        Spacer(Modifier.height(16.dp))
        Text("— or use email & password —", style = MaterialTheme.typography.labelMedium, color = mut)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            email, { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            pw, { pw = it }, label = { Text("Password (min 6 characters)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ emailFlow(false) }, Modifier.weight(1f), enabled = !busy) { Text("Log in") }
            OutlinedButton({ emailFlow(true) }, Modifier.weight(1f), enabled = !busy) { Text("Create account") }
        }
        msg?.let { Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium) }
        Spacer(Modifier.height(16.dp))
        Text(
            "Your history is stored in your own private cloud space, so it survives logout and a new phone.",
            style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, color = mut
        )
    }
}
