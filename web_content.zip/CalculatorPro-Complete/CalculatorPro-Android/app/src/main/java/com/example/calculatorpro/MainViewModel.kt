package com.example.calculatorpro

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.calculatorpro.calc.Evaluator
import com.example.calculatorpro.data.*
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull
import java.time.LocalDate
import java.time.ZoneId

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    val settings = AppSettings(app)

    // ---------- calculator state ----------
    var expression by mutableStateOf("")
        private set
    var preview by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var scientific by mutableStateOf(false)
        private set
    var degrees by mutableStateOf(true)
        private set
    private var justEvaluated = false

    private val ops = "+−×÷^"
    private val functions = listOf("sin(", "cos(", "tan(", "ln(", "log(", "√(")
    private fun endsOperand(c: Char?) = c != null && (c.isDigit() || c == ')' || c == 'π' || c == 'e' || c == '!' || c == '%')

    fun toggleMode() { scientific = !scientific }
    fun toggleAngle() { degrees = !degrees; refreshPreview() }

    fun input(tok: String) {
        error = null
        val isOp = tok.length == 1 && tok[0] in ops
        val isPostfix = tok == "%" || tok == "!"
        if (justEvaluated && !isOp && !isPostfix) expression = ""   // typing after "=" starts a new calculation
        justEvaluated = false
        var e = expression
        val last = e.lastOrNull()
        when {
            tok == "." -> {
                val seg = e.takeLastWhile { it.isDigit() || it == '.' }
                if ('.' in seg) return
                e += if (seg.isEmpty()) (if (endsOperand(last)) "×0." else "0.") else "."
            }
            tok.length == 1 && tok[0].isDigit() -> {
                val seg = e.takeLastWhile { it.isDigit() || it == '.' }
                if (seg == "0") { if (tok == "0") return; e = e.dropLast(1) }   // no leading zeros: "05" -> "5", "00" -> "0"
                else if (last == ')' || last == 'π' || last == 'e' || last == '!' || last == '%') e += "×"
                e += tok
            }
            isOp -> {
                if (e.isEmpty()) { if (tok == "−") e = "−" else return }
                else if (last != null && last in "+−×÷^") {
                    e = if (tok == "−" && last in "×÷^") e + tok else e.dropLast(1) + tok
                } else if (last == '(') { if (tok == "−") e += tok else return }
                else e += tok
            }
            isPostfix -> { if (!endsOperand(last)) return; e += tok }
            tok == ")" -> {
                if (e.count { it == '(' } <= e.count { it == ')' } || !endsOperand(last)) return
                e += tok
            }
            else -> { if (endsOperand(last)) e += "×"; e += tok }   // "(", constants, functions
        }
        expression = e
        refreshPreview()
    }

    fun paren() {
        val e = expression
        val open = e.count { it == '(' }; val close = e.count { it == ')' }
        if (!justEvaluated && open > close && endsOperand(e.lastOrNull())) input(")") else input("(")
    }

    fun backspace() {
        error = null
        justEvaluated = false
        val e = expression
        if (e.isEmpty()) return
        val f = functions.firstOrNull { e.endsWith(it) }
        expression = if (f != null) e.dropLast(f.length) else e.dropLast(1)
        refreshPreview()
    }

    fun clear() { expression = ""; preview = ""; error = null; justEvaluated = false }

    private fun autoClose(e: String): String {
        val n = e.count { it == '(' } - e.count { it == ')' }
        return if (n > 0) e + ")".repeat(n) else e
    }

    private fun refreshPreview() {
        preview = try {
            val e = autoClose(expression)
            if (e.all { it.isDigit() || it == '.' }) "" else Fmt.num(Evaluator.format(Evaluator.eval(e, degrees)))
        } catch (ex: Exception) { "" }
    }

    /** "=" — only valid, complete calculations are stored. */
    fun calculate() {
        if (expression.isEmpty()) return
        val expr = autoClose(expression)
        try {
            val res = Evaluator.format(Evaluator.eval(expr, degrees))
            val trivial = Regex("^[−-]?[0-9.]+$").matches(expr)   // just a number, nothing was calculated
            expression = res; preview = ""; error = null; justEvaluated = true
            if (!trivial && settings.autoSave) {
                val entry = HistoryEntity(
                    id = newId(), expression = expr, result = res, resultValue = res.toDouble(),
                    timestamp = System.currentTimeMillis(),
                    calculatorMode = if (scientific) "SCIENTIFIC" else "BASIC"
                )
                viewModelScope.launch { dao.insert(entry); cloudSet(entry) }
            }
        } catch (ex: ArithmeticException) {
            error = ex.message ?: "Math error"
        } catch (ex: Exception) {
            error = "Invalid expression"
        }
    }

    // ---------- reuse from history ----------
    fun reuseExpression(e: HistoryEntity) {
        scientific = scientific || e.calculatorMode == "SCIENTIFIC"
        expression = e.expression; justEvaluated = false; error = null; refreshPreview()
    }
    fun reuseResult(e: HistoryEntity) {
        expression = e.result; justEvaluated = true; error = null; preview = ""
    }
    fun recalc(e: HistoryEntity) { reuseExpression(e); calculate() }   // stores a NEW entry with the current time

    // ---------- history state ----------
    private val _filters = MutableStateFlow(Filters(sort = settings.defaultSort))
    val filters: StateFlow<Filters> = _filters.asStateFlow()
    private val clock = MutableStateFlow(0L)

    @OptIn(ExperimentalCoroutinesApi::class)
    val items: StateFlow<List<HistoryEntity>?> = combine(_filters, clock) { f, _ -> f }
        .flatMapLatest { f ->
            val zone = ZoneId.systemDefault()
            val (from, to) = dateRange(f, LocalDate.now(zone), zone)
            dao.observe(from, to, f.query.trim().replace(",", ""), f.sort)
                .map { l -> if (f.time == TimeF.ANY) l else l.filter { matchesTime(it.timestamp, f, zone) } }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val total: StateFlow<Int> = dao.count().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val latest: StateFlow<Long?> = dao.latest().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun editFilters(t: (Filters) -> Filters) { _filters.update(t) }
    fun resetFilters() { _filters.update { Filters(sort = it.sort) } }
    fun refreshClock() { clock.value = System.currentTimeMillis() }   // re-evaluates "Today" etc. after midnight
    fun setDefaultSort(i: Int) { settings.updateDefaultSort(i); _filters.update { it.copy(sort = i) } }

    fun delete(e: HistoryEntity) { viewModelScope.launch { dao.delete(e); cloudDelete(listOf(e.id)) } }
    fun restore(e: HistoryEntity) { viewModelScope.launch { dao.insert(e); cloudSet(e) } }
    fun deleteIds(ids: Collection<Long>) {
        viewModelScope.launch { ids.chunked(500).forEach { dao.deleteByIds(it) }; cloudDelete(ids) }
    }
    fun clearAll() { viewModelScope.launch { val ids = dao.allIds(); dao.deleteAll(); cloudDelete(ids) } }
    fun clearRange() {
        val f = _filters.value
        if (f.date == DateF.ALL) return   // safety: never wipe everything via the "range" action
        val zone = ZoneId.systemDefault()
        val (a, b) = dateRange(f, LocalDate.now(zone), zone)
        viewModelScope.launch { val ids = dao.idsInRange(a, b); dao.deleteRange(a, b); cloudDelete(ids) }
    }

    /** Only runs if the user explicitly chose a retention period. */
    fun applyRetention() {
        val days = settings.retentionDays
        if (days <= 0) return
        val zone = ZoneId.systemDefault()
        val cutoff = LocalDate.now(zone).minusDays(days.toLong()).atStartOfDay(zone).toInstant().toEpochMilli()
        viewModelScope.launch { val ids = dao.idsOlderThan(cutoff); dao.deleteOlderThan(cutoff); cloudDelete(ids) }
    }

    // ---------- Google account + cloud sync ----------
    // Signed in: Firestore (users/{uid}/history) is the source of truth, Room is the local cache.
    // Log out: the local copy is wiped; signing in again with the same account restores everything.
    val cloud: Boolean = FirebaseApp.getApps(app).isNotEmpty()   // false in a build without google-services.json
    private val authRepo = AuthRepo(cloud)
    val user: StateFlow<FirebaseUser?> = authRepo.user
    private val fs by lazy { FirebaseFirestore.getInstance() }
    private var listener: ListenerRegistration? = null

    private fun uid(): String? = authRepo.user.value?.uid
    private fun col(uid: String) = fs.collection("users").document(uid).collection("history")
    private fun newId(): Long = System.currentTimeMillis() * 1000 + (0..999).random()

    private fun cloudSet(e: HistoryEntity) { uid()?.let { col(it).document(e.id.toString()).set(e.toMap()) } }   // queued offline automatically
    private fun cloudDelete(ids: Collection<Long>) {
        val u = uid() ?: return
        ids.chunked(400).forEach { chunk ->
            val b = fs.batch(); chunk.forEach { b.delete(col(u).document(it.toString())) }; b.commit()
        }
    }

    private fun startSync(uid: String) {
        listener?.remove()
        viewModelScope.launch {   // entries made before signing in are added to the account
            dao.all().chunked(400).forEach { chunk ->
                val b = fs.batch(); chunk.forEach { b.set(col(uid).document(it.id.toString()), it.toMap()) }
                runCatching { b.commit().await() }
            }
        }
        listener = col(uid).addSnapshotListener { snap, _ ->
            if (snap == null) return@addSnapshotListener
            viewModelScope.launch {
                snap.documentChanges.forEach { ch ->
                    if (ch.type == DocumentChange.Type.REMOVED) ch.document.id.toLongOrNull()?.let { dao.deleteByIds(listOf(it)) }
                    else ch.document.toEntity()?.let { dao.insert(it) }
                }
                applyRetention()
            }
        }
    }
    private fun stopSync() { listener?.remove(); listener = null }

    suspend fun signIn(activityCtx: Context): String? = authRepo.signIn(activityCtx)
    suspend fun emailAuth(email: String, pw: String, create: Boolean): String? = authRepo.emailAuth(email, pw, create)

    /** Returns false if some entries are not uploaded yet (unless [force]). */
    suspend fun logout(force: Boolean): Boolean {
        if (!force && uid() != null) {
            val synced = withTimeoutOrNull(5000) { fs.waitForPendingWrites().await(); true }
            if (synced == null) return false
        }
        stopSync()
        dao.deleteAll()   // local cache only; the cloud copy stays
        authRepo.signOut(getApplication())
        settings.updateGuest(false)
        return true
    }

    init {
        applyRetention()
        viewModelScope.launch { authRepo.user.collect { u -> if (u != null) startSync(u.uid) else stopSync() } }
    }
}
