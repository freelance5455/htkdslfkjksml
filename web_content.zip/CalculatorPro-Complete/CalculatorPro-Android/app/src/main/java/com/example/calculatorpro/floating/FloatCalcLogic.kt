package com.example.calculatorpro.floating

import com.example.calculatorpro.calc.Evaluator

/** Key handling for the floating calculator. Pure Kotlin (no Android classes), so it is covered by unit tests. */
class FloatCalcLogic {
    var expr = ""
        private set
    var preview = ""
        private set
    var error: String? = null
        private set
    private var justEval = false

    fun key(k: String) {
        error = null
        when (k) {
            "AC" -> { expr = ""; justEval = false }
            "⌫" -> { justEval = false; expr = expr.dropLast(1) }
            "=" -> calculate()
            "00" -> { digit("0"); digit("0") }
            "+", "−", "×", "÷" -> op(k)
            "%" -> percent()
            "." -> dot()
            else -> if (k.length == 1 && k[0].isDigit()) digit(k)
        }
        preview = computePreview()
    }

    private fun digit(d: String) {
        if (justEval) { expr = ""; justEval = false }       // typing after "=" starts a new calculation
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (seg == "0") { if (d == "0") return; expr = expr.dropLast(1) }   // no leading zeros
        else if (expr.lastOrNull() == '%') expr += "×"
        expr += d
    }

    private fun dot() {
        if (justEval) { expr = ""; justEval = false }
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if ('.' in seg) return
        expr += if (seg.isEmpty()) "0." else "."
    }

    private fun op(o: String) {
        justEval = false                                     // an operator continues from the result
        val last = expr.lastOrNull()
        when {
            expr.isEmpty() -> { if (o == "−") expr = "−" }
            expr == "−" -> {}
            last != null && last in "+−×÷" -> expr = if (o == "−" && last in "×÷") expr + o else expr.dropLast(1) + o
            else -> expr += o
        }
    }

    private fun percent() {
        if (expr.lastOrNull()?.let { it.isDigit() || it == '%' } == true) { justEval = false; expr += "%" }
    }

    private fun calculate() {
        if (expr.isEmpty()) return
        try {
            expr = Evaluator.format(Evaluator.eval(expr, true)); justEval = true
        } catch (ex: ArithmeticException) { error = ex.message ?: "Math error" }
        catch (ex: Exception) { error = "Invalid expression" }
    }

    private fun computePreview(): String =
        if (error != null || expr.isEmpty() || expr.all { it.isDigit() || it == '.' }) ""
        else runCatching { Evaluator.format(Evaluator.eval(expr, true)) }.getOrDefault("")
}
