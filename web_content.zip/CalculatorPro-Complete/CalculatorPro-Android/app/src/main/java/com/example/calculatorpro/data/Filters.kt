package com.example.calculatorpro.data

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

enum class DateF(val label: String) {
    ALL("All history"), TODAY("Today"), YESTERDAY("Yesterday"), LAST7("Last 7 days"),
    LAST30("Last 30 days"), THIS_MONTH("This month"), LAST_MONTH("Last month"), CUSTOM("Custom range")
}

/** Minutes of day, both ends inclusive. NIGHT wraps past midnight. */
enum class TimeF(val label: String, val startMin: Int, val endMin: Int) {
    ANY("Any time", 0, 1439), MORNING("Morning", 300, 719), AFTERNOON("Afternoon", 720, 1019),
    EVENING("Evening", 1020, 1259), NIGHT("Night", 1260, 299), CUSTOM("Custom time", 0, 0)
}

data class Filters(
    val date: DateF = DateF.ALL,
    val customFrom: LocalDate? = null,
    val customTo: LocalDate? = null,
    val time: TimeF = TimeF.ANY,
    val timeFrom: Int = 0,
    val timeTo: Int = 1439,
    val query: String = "",
    val sort: Int = 0
)

/** (first day inclusive, last day EXCLUSIVE) or null for "no date limit". */
fun dateSpan(f: Filters, today: LocalDate): Pair<LocalDate, LocalDate>? = when (f.date) {
    DateF.ALL -> null
    DateF.TODAY -> today to today.plusDays(1)
    DateF.YESTERDAY -> today.minusDays(1) to today
    DateF.LAST7 -> today.minusDays(6) to today.plusDays(1)
    DateF.LAST30 -> today.minusDays(29) to today.plusDays(1)
    DateF.THIS_MONTH -> today.withDayOfMonth(1) to today.plusDays(1)
    DateF.LAST_MONTH -> { val first = today.withDayOfMonth(1); first.minusMonths(1) to first }
    DateF.CUSTOM -> f.customFrom?.let { a ->
        val b = f.customTo ?: a
        minOf(a, b) to maxOf(a, b).plusDays(1)   // selected end date is included
    }
}

/** Epoch-millis [from, to). Uses start-of-day in the device zone, so DST / month / year boundaries are exact. */
fun dateRange(f: Filters, today: LocalDate, zone: ZoneId): Pair<Long, Long> {
    val sp = dateSpan(f, today) ?: return Long.MIN_VALUE to Long.MAX_VALUE
    return sp.first.atStartOfDay(zone).toInstant().toEpochMilli() to
        sp.second.atStartOfDay(zone).toInstant().toEpochMilli()
}

fun timeBounds(f: Filters): Pair<Int, Int> =
    if (f.time == TimeF.CUSTOM) f.timeFrom to f.timeTo else f.time.startMin to f.time.endMin

fun matchesTime(ts: Long, f: Filters, zone: ZoneId): Boolean {
    if (f.time == TimeF.ANY) return true
    val t = Instant.ofEpochMilli(ts).atZone(zone).toLocalTime()
    val m = t.hour * 60 + t.minute
    val (a, b) = timeBounds(f)
    return if (a <= b) m in a..b else (m >= a || m <= b)
}
