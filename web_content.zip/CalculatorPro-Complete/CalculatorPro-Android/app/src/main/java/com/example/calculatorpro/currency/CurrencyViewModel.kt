package com.example.calculatorpro.currency

import android.app.Application
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.calculatorpro.data.DateF
import com.example.calculatorpro.data.Filters
import com.example.calculatorpro.data.TimeF
import com.example.calculatorpro.data.dateRange
import com.example.calculatorpro.data.matchesTime
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.math.BigDecimal
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Currency
import java.util.Locale

data class HistResult(
    val requested: LocalDate, val tableDate: String, val rate: BigDecimal, val converted: BigDecimal,
    val prevRate: BigDecimal?, val dayChangePct: BigDecimal?, val vsLatestPct: BigDecimal?, val provider: String
)

class CurrencyViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = CurrencyDb.get(app).dao()
    private val repo = RateRepo(dao)
    private val sp = app.getSharedPreferences("currency_prefs", Context.MODE_PRIVATE)

    // ---------- rates ----------
    var loaded by mutableStateOf<Loaded?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun refresh(force: Boolean) {
        if (loading) return
        loading = true
        viewModelScope.launch {
            repo.latest(force).fold(
                onSuccess = { loaded = it; error = it.note },
                onFailure = { if (loaded == null) error = "Couldn't load exchange rates (${it.message ?: "network error"}). Check your internet and tap Retry." else error = "Refresh failed: ${it.message}" }
            )
            loading = false
        }
    }

    /** Currencies the platform knows (ISO 4217) AND the provider has a rate for. */
    val supported: List<Cur>
        get() { val l = loaded ?: return emptyList(); return Catalog.all.filter { it.code == "USD" || l.table.rates.containsKey(it.code) } }

    // ---------- converter + favourites ----------
    private fun deviceCurrency(): String = runCatching { Currency.getInstance(Locale.getDefault()).currencyCode }.getOrDefault("USD")
    var from by mutableStateOf(sp.getString("from", null) ?: deviceCurrency())
        private set
    var to by mutableStateOf(sp.getString("to", null) ?: if (deviceCurrency() == "USD") "EUR" else "USD")
        private set
    var amount by mutableStateOf(sp.getString("amount", "1") ?: "1")
        private set
    var favorites by mutableStateOf(list("fav"))
        private set
    var recents by mutableStateOf(list("recent"))
        private set
    var multi by mutableStateOf(list("multi").ifEmpty { listOf("USD", "EUR", "GBP", "JPY", "CNY", "INR") })
        private set
    var multiBase by mutableStateOf(sp.getString("multiBase", null) ?: "INR")
        private set

    private fun list(k: String) = (sp.getString(k, "") ?: "").split(",").filter { it.isNotBlank() }
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    private fun touch(code: String) { recents = (listOf(code) + recents.filter { it != code }).take(8); put("recent", recents.joinToString(",")) }
    fun setFrom(c: String) { from = c; put("from", c); touch(c) }
    fun setTo(c: String) { to = c; put("to", c); touch(c) }
    fun swap() { val f = from; from = to; to = f; put("from", from); put("to", to) }
    fun setAmount(t: String) { amount = t.filter { it.isDigit() || it == '.' || it == ',' }.take(24); put("amount", amount) }
    fun toggleFav(c: String) { favorites = if (c in favorites) favorites - c else favorites + c; put("fav", favorites.joinToString(",")) }
    fun moveFav(c: String, d: Int) {
        val i = favorites.indexOf(c); val j = i + d
        if (i < 0 || j !in favorites.indices) return
        favorites = favorites.toMutableList().also { val t = it[i]; it[i] = it[j]; it[j] = t }
        put("fav", favorites.joinToString(","))
    }
    fun addMulti(c: String) { if (c !in multi) { multi = multi + c; put("multi", multi.joinToString(",")) } }
    fun removeMulti(c: String) { multi = multi - c; put("multi", multi.joinToString(",")) }
    fun setMultiBase(c: String) { multiBase = c; put("multiBase", c) }

    // ---------- conversion history (auto-saved after the user stops typing) ----------
    private var lastSig = ""
    fun saveLatest(amountBd: BigDecimal, rate: BigDecimal, result: BigDecimal) {
        val l = loaded ?: return
        val sig = "$from|$to|${amountBd.toPlainString()}|${l.table.date}|${l.freshness}"
        if (amountBd.signum() == 0 || sig == lastSig) return
        lastSig = sig
        insert("LATEST", l.table.date, l.table.provider, l.table.fetchedAt, l.freshness.name, from, to, amountBd, result, rate)
    }

    private fun insert(kind: String, rateDate: String, provider: String, fetchedAt: Long, fresh: String, f: String, t: String, a: BigDecimal, r: BigDecimal, rate: BigDecimal) {
        val e = ConversionEntity(
            fromCode = f, toCode = t, amount = a.toPlainString(), result = r.toPlainString(), rate = rate.toPlainString(),
            provider = provider, rateDate = rateDate, fetchedAt = fetchedAt, kind = kind, freshness = fresh,
            viaUsd = Money.viaUsd(f, t), timestamp = System.currentTimeMillis()
        )
        viewModelScope.launch { dao.insert(e) }
    }

    private val _filters = MutableStateFlow(Filters())
    val filters: StateFlow<Filters> = _filters.asStateFlow()
    fun editFilters(t: (Filters) -> Filters) { _filters.update(t) }

    @OptIn(ExperimentalCoroutinesApi::class)
    val conversions: StateFlow<List<ConversionEntity>?> = _filters.flatMapLatest { f ->
        val zone = ZoneId.systemDefault()
        val (a, b) = dateRange(f, LocalDate.now(zone), zone)
        dao.observe(a, b, f.query.trim().uppercase()).map { l -> if (f.time == TimeF.ANY) l else l.filter { matchesTime(it.timestamp, f, zone) } }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    fun delete(e: ConversionEntity) { viewModelScope.launch { dao.delete(e) } }
    fun restore(e: ConversionEntity) { viewModelScope.launch { dao.restore(e) } }
    fun clearAll() { viewModelScope.launch { dao.deleteAll() } }
    fun clearRange() {
        val f = _filters.value
        if (f.date == DateF.ALL) return
        val zone = ZoneId.systemDefault()
        val (a, b) = dateRange(f, LocalDate.now(zone), zone)
        viewModelScope.launch { dao.deleteRange(a, b) }
    }
    fun repeat(e: ConversionEntity) { from = e.fromCode; to = e.toCode; amount = e.amount; put("from", from); put("to", to); put("amount", amount) }

    fun exportCsv(ctx: Context, list: List<ConversionEntity>) {
        val d = DateTimeFormatter.ISO_LOCAL_DATE; val t = DateTimeFormatter.ofPattern("HH:mm:ss")
        fun q(x: String) = "\"" + x.replace("\"", "\"\"") + "\""
        val sb = StringBuilder("\uFEFFDate,Time,From,Amount,To,Result,Rate,RateDate,Provider,Kind,Status,ViaUSD\r\n")
        list.forEach { e ->
            val z = java.time.Instant.ofEpochMilli(e.timestamp).atZone(ZoneId.systemDefault())
            sb.append(listOf(z.format(d), z.format(t), e.fromCode, e.amount, e.toCode, e.result, e.rate, e.rateDate, e.provider,
                e.kind, if (e.freshness == "CACHED") "cached" else "latest", e.viaUsd.toString()).joinToString(",") { q(it) }).append("\r\n")
        }
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val f = File(dir, "currency_history_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"))}.csv")
        f.writeText(sb.toString(), Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); clipData = android.content.ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Export conversion history"))
    }

    // ---------- historical lookup ----------
    var hist by mutableStateOf<HistResult?>(null)
        private set
    var histMsg by mutableStateOf<String?>(null)
        private set
    var histLoading by mutableStateOf(false)
        private set

    fun lookupDate(date: LocalDate) {
        val amt = Money.parseAmount(amount); val toC = Catalog.byCode[to]
        if (amt == null || toC == null) { histMsg = "Enter a valid amount first."; return }
        histLoading = true; histMsg = null; hist = null
        viewModelScope.launch {
            val t = repo.onDate(date)
            val r = t?.let { Money.rate(it, from, to) }
            if (t == null || r == null) {
                histMsg = if (date.isBefore(PROVIDER_FLOOR)) "The provider has no data before $PROVIDER_FLOOR."
                else "No rate available for $from → $to on $date (offline, or the provider has no data for that day)."
            } else {
                val prev = repo.onDate(date.minusDays(1))?.let { Money.rate(it, from, to) }
                val latest = loaded?.table?.let { Money.rate(it, from, to) }
                val res = Money.convert(amt, r, toC.digits)
                hist = HistResult(date, t.date, r, res, prev, prev?.let { Money.pct(it, r) }, latest?.let { Money.pct(r, it) }, t.provider)
                insert("HISTORICAL", t.date, t.provider, t.fetchedAt, "FRESH", from, to, amt, res, r)
            }
            histLoading = false
        }
    }

    // ---------- charts / ranges ----------
    var series by mutableStateOf<Series?>(null)
        private set
    var seriesLoading by mutableStateOf(false)
        private set

    fun loadSeries(start: LocalDate, end: LocalDate) {
        if (from == to) { series = null; return }
        seriesLoading = true
        viewModelScope.launch { series = repo.series(from, to, start, end); seriesLoading = false }
    }
    fun clearSeries() { series = null }

    init { refresh(false) }
}
