package com.example.calculatorpro.currency

import java.util.Currency
import java.util.Locale

data class Country(val iso: String, val name: String) { val flag: String get() = flagOf(iso) }

fun flagOf(iso: String): String {
    if (iso.length != 2) return "🌐"
    val a = iso[0].uppercaseChar(); val b = iso[1].uppercaseChar()
    return String(Character.toChars(0x1F1E6 + (a - 'A'))) + String(Character.toChars(0x1F1E6 + (b - 'A')))
}

data class Cur(val code: String, val name: String, val symbol: String, val digits: Int, val countries: List<Country>) {
    val flag: String get() = if (code == "EUR") "🇪🇺" else countries.firstOrNull()?.flag ?: "🌐"
    val firstCountry: String get() = countries.firstOrNull()?.name ?: name
    val countryLine: String get() = if (countries.isEmpty()) "—" else countries.joinToString(", ") { it.name }
}

/**
 * ISO 4217 data comes from the Android/Java platform (java.util.Currency + Locale), which the OS keeps updated:
 * codes, English names, symbols, decimal precision, and country <-> currency links (several countries can share
 * one currency, e.g. EUR, XOF). Nothing is hand-typed. The platform lists one official currency per country.
 */
object Catalog {
    val all: List<Cur> by lazy {
        val byCode = HashMap<String, MutableList<Country>>()
        for (cc in Locale.getISOCountries()) {
            val loc = Locale.Builder().setRegion(cc).build()
            val cur = runCatching { Currency.getInstance(loc) }.getOrNull() ?: continue
            byCode.getOrPut(cur.currencyCode) { mutableListOf() }.add(Country(cc, loc.getDisplayCountry(Locale.ENGLISH)))
        }
        Currency.getAvailableCurrencies()
            .filter { it.defaultFractionDigits >= 0 }          // drops pseudo-currencies (XXX, XTS, metals)
            .map { c ->
                val countries = byCode[c.currencyCode].orEmpty().sortedBy { it.name }
                val home = Locale.forLanguageTag("und-" + (countries.firstOrNull()?.iso ?: "US"))
                Cur(c.currencyCode, c.getDisplayName(Locale.ENGLISH), c.getSymbol(home), c.defaultFractionDigits, countries)
            }
            .sortedBy { it.name }
    }
    val byCode: Map<String, Cur> by lazy { all.associateBy { it.code } }

    /** Matches country name, currency name, code or symbol (case-insensitive). */
    fun search(list: List<Cur>, q: String): List<Cur> {
        val t = q.trim().lowercase()
        if (t.isEmpty()) return list
        return list.filter {
            it.code.lowercase().contains(t) || it.name.lowercase().contains(t) || it.symbol.lowercase().contains(t) ||
                it.countries.any { c -> c.name.lowercase().contains(t) }
        }.sortedBy { if (it.code.lowercase() == t) 0 else 1 }
    }
}
