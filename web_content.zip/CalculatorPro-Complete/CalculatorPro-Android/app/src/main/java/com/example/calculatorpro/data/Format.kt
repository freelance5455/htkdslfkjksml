package com.example.calculatorpro.data

import java.text.NumberFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

object Fmt {
    val zone: ZoneId get() = ZoneId.systemDefault()
    fun at(ts: Long): ZonedDateTime = java.time.Instant.ofEpochMilli(ts).atZone(zone)

    fun dateWith(style: Int, d: LocalDate): String = when (style) {
        1 -> d.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
        2 -> d.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"))
        3 -> d.format(DateTimeFormatter.ISO_LOCAL_DATE)
        else -> d.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG).withLocale(Locale.getDefault()))
    }
    fun date(d: LocalDate, s: AppSettings) = dateWith(s.dateStyle, d)
    fun time(t: LocalTime, s: AppSettings): String =
        t.format(DateTimeFormatter.ofPattern(if (s.use24h) "HH:mm" else "h:mm a", Locale.getDefault()))
    fun minutes(m: Int, s: AppSettings) = time(LocalTime.of(m / 60, m % 60), s)
    fun dateTime(ts: Long, s: AppSettings): String {
        val z = at(ts)
        return date(z.toLocalDate(), s) + ", " + time(z.toLocalTime(), s)
    }
    fun dayLabel(d: LocalDate, s: AppSettings): String {
        val today = LocalDate.now(zone)
        return when (d) { today -> "Today"; today.minusDays(1) -> "Yesterday"; else -> date(d, s) }
    }
    fun spanLabel(f: Filters, s: AppSettings): String {
        val sp = dateSpan(f, LocalDate.now(zone)) ?: return "All history"
        val last = sp.second.minusDays(1)
        return if (sp.first == last) date(sp.first, s) else date(sp.first, s) + " – " + date(last, s)
    }
    fun num(plain: String): String {
        if (plain.contains('E')) return plain
        val bd = plain.toBigDecimalOrNull() ?: return plain
        val nf = NumberFormat.getNumberInstance(Locale.getDefault()).apply { maximumFractionDigits = 15 }
        return nf.format(bd)
    }
    fun modeName(mode: String) = if (mode == "SCIENTIFIC") "Scientific Calculator" else "Basic Calculator"
}
