package com.example.calculatorpro.currency

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import java.text.NumberFormat

/** All money maths uses BigDecimal. Doubles are only used to draw charts. */
object Money {
    private val MC = MathContext(20)

    /** Units of [to] per 1 [from]. The table is USD-based, so any non-USD pair is a cross rate through USD. */
    fun rate(t: RateTable, from: String, to: String): BigDecimal? {
        if (from == to) return BigDecimal.ONE
        val f = if (from == "USD") BigDecimal.ONE else t.rates[from] ?: return null
        val x = if (to == "USD") BigDecimal.ONE else t.rates[to] ?: return null
        return x.divide(f, MC)
    }
    fun viaUsd(from: String, to: String) = from != to && from != "USD" && to != "USD"

    fun convert(amount: BigDecimal, rate: BigDecimal, digits: Int): BigDecimal =
        amount.multiply(rate).setScale(digits, RoundingMode.HALF_UP)

    fun parseAmount(s: String): BigDecimal? = s.trim().replace(",", "").toBigDecimalOrNull()?.takeIf { it.signum() >= 0 }

    fun fmt(v: BigDecimal, digits: Int): String =
        NumberFormat.getNumberInstance().apply { minimumFractionDigits = digits; maximumFractionDigits = digits }.format(v)

    fun fmtRate(v: BigDecimal): String = v.round(MathContext(8)).stripTrailingZeros().toPlainString()

    /** Percentage change from [a] to [b], 2 decimals, or null if [a] is zero. */
    fun pct(a: BigDecimal, b: BigDecimal): BigDecimal? =
        if (a.signum() == 0) null else b.subtract(a).divide(a, MC).multiply(BigDecimal(100)).setScale(2, RoundingMode.HALF_UP)
}
