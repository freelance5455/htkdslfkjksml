package com.example.calculatorpro.floating

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.calculatorpro.MainActivity
import com.example.calculatorpro.calc.Evaluator
import kotlin.math.abs
import kotlin.math.min

/** Starts the floating calculator. Needs the "Display over other apps" permission (asked once). */
object FloatingCalc {
    fun start(ctx: Context) {
        if (!Settings.canDrawOverlays(ctx)) {
            Toast.makeText(ctx, "Allow “Display over other apps” for Calculator Pro, then tap the floating-window button again.", Toast.LENGTH_LONG).show()
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
            return
        }
        ContextCompat.startForegroundService(ctx, Intent(ctx, FloatingCalcService::class.java))
        (ctx as? Activity)?.moveTaskToBack(true)   // go back to the other app; the calculator floats above it
    }
}

/**
 * Floating calculator window (same idea as the system floating window in the reference video):
 *   top row:  ⤢ open the full app   – shrink to a small bubble   ▬ drag handle (move the window)   ✕ close
 *   bottom-right dot: drag to resize; the whole calculator scales together (keys, text, display)
 * It stays above other apps, does not take keyboard focus, and is a quick calculator (no history).
 */
class FloatingCalcService : Service() {
    private var wm: WindowManager? = null
    private var root: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var content: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var tvExpr: TextView
    private lateinit var tvPrev: TextView
    private val keyViews = mutableListOf<TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private var expr = ""
    private var justEval = false
    private var err: String? = null
    private var collapsed = false
    private var savedW = 0
    private var savedH = 0
    private val baseW = 260   // dp
    private val baseH = 380   // dp  (the window keeps this shape while you resize)
    private var held = false
    private val repeater = object : Runnable {
        override fun run() { held = true; onKey("⌫"); handler.postDelayed(this, 70) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
        if (root == null) show()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        root?.let { runCatching { wm?.removeView(it) } }
        root = null
        super.onDestroy()
    }

    private fun notification(): Notification {
        val ch = "floating_calc"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "Floating calculator", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingCalcService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Floating calculator is on")
            .setContentText("Tap to open the app")
            .setContentIntent(open).addAction(0, "Close", stop).setOngoing(true).build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, r: Float = 1000f) = GradientDrawable().apply { setColor(color); cornerRadius = r }   // 1000 = fully round

    private fun show() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else 2002   // 2002 = TYPE_PHONE
        val p = WindowManager.LayoutParams(
            dp(baseW), dp(baseH), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START; p.x = dp(24); p.y = dp(120)
        lp = p

        val frame = FrameLayout(this).apply { background = shape(0xF21A1D24.toInt(), dp(22).toFloat()) }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(2)) }

        // ---- top row: ⤢  –  ▬(drag)  ✕
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(ctrl("⤢") { openApp() }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(8) })
        bar.addView(ctrl("–") { setCollapsed(true) }, LinearLayout.LayoutParams(dp(28), dp(28)))
        val dragArea = FrameLayout(this)
        dragArea.addView(View(this).apply { background = shape(0x99FFFFFF.toInt(), dp(3).toFloat()) }, FrameLayout.LayoutParams(dp(44), dp(4), Gravity.CENTER))
        bar.addView(dragArea, LinearLayout.LayoutParams(0, dp(28), 1f))
        bar.addView(ctrl("✕") { stopSelf() }, LinearLayout.LayoutParams(dp(28), dp(28)))
        enableDrag(dragArea)
        content.addView(bar)

        tvExpr = TextView(this).apply {
            setTextColor(Color.WHITE); gravity = Gravity.END or Gravity.BOTTOM; maxLines = 2
            ellipsize = TextUtils.TruncateAt.START; text = "0"
        }
        tvPrev = TextView(this).apply { setTextColor(0xFF9AA4B4.toInt()); gravity = Gravity.END; maxLines = 1; textSize = 15f }
        content.addView(tvExpr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.1f))
        content.addView(tvPrev, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"), listOf("7", "8", "9", "×"), listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"), listOf("00", "0", ".", "=")
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows.forEach { r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { label ->
                val cell = FrameLayout(this)
                cell.addView(makeKey(label), FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        content.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 4f))

        // ---- bottom-right dot = resize (the whole calculator scales)
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        val dot = View(this).apply { background = shape(0xCCFFFFFF.toInt()) }
        footer.addView(dot, LinearLayout.LayoutParams(dp(16), dp(16)).apply { setMargins(0, dp(3), dp(4), dp(3)) })
        enableResize(footer)
        content.addView(footer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(22)))

        // ---- the small bubble shown after "–"
        bubble = TextView(this).apply { text = "="; setTextColor(0xFF0B1B3F.toInt()); textSize = 22f; gravity = Gravity.CENTER; visibility = View.GONE }
        enableDrag(bubble) { setCollapsed(false) }

        frame.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(bubble, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = frame
        w.addView(frame, p)
        applySizes()
        refresh()
    }

    private fun ctrl(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label; setTextColor(0xFFDDE3EC.toInt()); textSize = 14f; gravity = Gravity.CENTER
            background = shape(0xFF3A3F4A.toInt()); setOnClickListener { onClick() }
        }

    private fun makeKey(label: String): TextView {
        val bg = when (label) {
            "AC", "⌫" -> 0xFF4A3516
            "%", "÷", "×", "−", "+" -> 0xFF1E3A6E
            "=" -> 0xFF5B8CFF
            else -> 0xFF2B303B
        }.toInt()
        val fg = when (label) {
            "%", "÷", "×", "−", "+" -> 0xFFCFE0FF
            "=" -> 0xFF0B1B3F
            "AC", "⌫" -> 0xFFFFD9A6
            else -> 0xFFEEF1F6
        }.toInt()
        val tv = TextView(this).apply {
            text = label; tag = label; setTextColor(fg); gravity = Gravity.CENTER; isClickable = true
            background = shape(bg, if (label == "=") dp(22).toFloat() else 1000f)   // round keys; only "=" is a rounded rectangle
        }
        tv.setOnClickListener {
            if (label == "⌫" && held) { held = false }   // the long press already deleted
            else { tv.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onKey(label) }
        }
        if (label == "⌫") {   // hold backspace = fast delete
            tv.setOnTouchListener { _, ev ->
                when (ev.action) {
                    MotionEvent.ACTION_DOWN -> { held = false; handler.postDelayed(repeater, 420) }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(repeater)
                }
                false
            }
        }
        keyViews.add(tv)
        return tv
    }

    // ---------- calculator logic ----------
    private fun onKey(k: String) {
        err = null
        when (k) {
            "AC" -> { expr = ""; justEval = false }
            "⌫" -> { justEval = false; expr = expr.dropLast(1) }
            "=" -> calc()
            "00" -> { digit("0"); digit("0") }
            "+", "−", "×", "÷" -> op(k)
            "%" -> if (expr.lastOrNull()?.let { it.isDigit() || it == '%' } == true) { justEval = false; expr += "%" }
            "." -> dot()
            else -> digit(k)
        }
        refresh()
    }

    private fun digit(d: String) {
        if (justEval) { expr = ""; justEval = false }
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if (seg == "0") { if (d == "0") return; expr = expr.dropLast(1) }   // no leading zeros
        else if (expr.lastOrNull() == '%') expr += "×"
        expr += d
    }

    private fun dot() {
        if (justEval) { expr = ""; justEval = false }
        val seg = expr.takeLastWhile { it.isDigit() || it == '.' }
        if ('.' in seg) return
        expr += if (seg.isEmpty()) "0." else "."
    }

    private fun op(o: String) {
        justEval = false
        val last = expr.lastOrNull()
        when {
            expr.isEmpty() -> { if (o == "−") expr = "−" }
            expr == "−" -> {}
            last != null && last in "+−×÷" -> expr = if (o == "−" && last in "×÷") expr + o else expr.dropLast(1) + o
            else -> expr += o
        }
    }

    private fun calc() {
        if (expr.isEmpty()) return
        try {
            expr = Evaluator.format(Evaluator.eval(expr, true)); justEval = true
        } catch (ex: ArithmeticException) { err = ex.message ?: "Math error" }
        catch (ex: Exception) { err = "Invalid expression" }
    }

    private fun refresh() {
        tvExpr.text = expr.ifEmpty { "0" }
        tvPrev.text = err ?: if (expr.isEmpty() || expr.all { it.isDigit() || it == '.' }) ""
            else runCatching { Evaluator.format(Evaluator.eval(expr, true)) }.getOrDefault("")
        tvPrev.setTextColor(if (err != null) 0xFFFF8A80.toInt() else 0xFF9AA4B4.toInt())
    }

    // ---------- window: move / resize / shrink ----------
    /** Scales everything with the window: round keys, key text and the display text. */
    private fun applySizes() {
        val p = lp ?: return
        val gridH = (p.height - dp(8 + 2 + 28 + 22 + 20)) * 4f / 5.1f
        val cellW = (p.width - dp(16)) / 4f
        val cellH = gridH / 5f
        val side = (min(cellW, cellH) - dp(6)).toInt().coerceAtLeast(dp(20))
        val textPx = side * 0.38f
        keyViews.forEach { k ->
            val wide = k.tag == "="
            k.layoutParams = FrameLayout.LayoutParams(if (wide) (cellW - dp(6)).toInt() else side, side, Gravity.CENTER)
            k.setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx)
        }
        tvExpr.setTextSize(TypedValue.COMPLEX_UNIT_PX, (p.width / 9f).coerceIn(dp(16).toFloat(), dp(44).toFloat()))
    }

    private fun setCollapsed(c: Boolean) {
        val p = lp ?: return
        val r = root ?: return
        if (c == collapsed) return
        collapsed = c
        if (c) {
            savedW = p.width; savedH = p.height
            content.visibility = View.GONE; bubble.visibility = View.VISIBLE
            r.background = shape(0xFF5B8CFF.toInt())
            p.width = dp(52); p.height = dp(52)
        } else {
            content.visibility = View.VISIBLE; bubble.visibility = View.GONE
            r.background = shape(0xF21A1D24.toInt(), dp(22).toFloat())
            p.width = savedW; p.height = savedH
        }
        wm?.updateViewLayout(r, p)
    }

    private fun openApp() {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        stopSelf()
    }

    private fun enableDrag(v: View, onTap: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            val dm = resources.displayMetrics
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        p.x = (ox + dx.toInt()).coerceIn(-p.width + dp(60), dm.widthPixels - dp(60))   // never lose the window off-screen
                        p.y = (oy + dy.toInt()).coerceIn(0, dm.heightPixels - dp(60))
                        root?.let { wm?.updateViewLayout(it, p) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun enableResize(v: View) {
        var sx = 0f; var sy = 0f; var ow = 0
        val ratio = baseH.toFloat() / baseW
        v.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            val dm = resources.displayMetrics
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ow = p.width }
                MotionEvent.ACTION_MOVE -> {
                    val grow = ((e.rawX - sx) + (e.rawY - sy) / ratio) / 2f   // drag the corner; the shape stays the same
                    p.width = (ow + grow.toInt()).coerceIn(dp(140), min(dm.widthPixels, (dm.heightPixels / ratio).toInt()))
                    p.height = (p.width * ratio).toInt()
                    root?.let { wm?.updateViewLayout(it, p) }
                    applySizes()
                }
            }
            true
        }
    }

    companion object {
        private const val ACTION_STOP = "com.example.calculatorpro.floating.STOP"
        private const val NOTIF_ID = 1001
    }
}
