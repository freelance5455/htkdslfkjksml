package com.example.calculatorpro.floating

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.calculatorpro.MainActivity
import kotlin.math.abs
import kotlin.math.min

private const val G_EXPAND = 0
private const val G_CONTRACT = 1
private const val G_MINUS = 2
private const val G_CLOSE = 3

/** Round grey button with a drawn icon, like the reference control bar. */
private class GlyphView(ctx: Context, var kind: Int) : View(ctx) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3A3B3F.toInt() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawCircle(w / 2, h / 2, min(w, h) / 2, disc)
        stroke.strokeWidth = w * 0.075f
        when (kind) {
            G_MINUS -> c.drawLine(w * .30f, h * .5f, w * .70f, h * .5f, stroke)
            G_CLOSE -> { c.drawLine(w * .32f, h * .32f, w * .68f, h * .68f, stroke); c.drawLine(w * .68f, h * .32f, w * .32f, h * .68f, stroke) }
            G_EXPAND -> {   // two arrows pointing outwards (top-left and bottom-right)
                c.drawLine(w * .34f, h * .34f, w * .66f, h * .66f, stroke)
                c.drawLine(w * .34f, h * .34f, w * .34f, h * .52f, stroke); c.drawLine(w * .34f, h * .34f, w * .52f, h * .34f, stroke)
                c.drawLine(w * .66f, h * .66f, w * .66f, h * .48f, stroke); c.drawLine(w * .66f, h * .66f, w * .48f, h * .66f, stroke)
            }
            else -> {       // G_CONTRACT: two arrows pointing inwards
                c.drawLine(w * .28f, h * .28f, w * .46f, h * .46f, stroke)
                c.drawLine(w * .46f, h * .28f, w * .46f, h * .46f, stroke); c.drawLine(w * .28f, h * .46f, w * .46f, h * .46f, stroke)
                c.drawLine(w * .72f, h * .72f, w * .54f, h * .54f, stroke)
                c.drawLine(w * .54f, h * .72f, w * .54f, h * .54f, stroke); c.drawLine(w * .72f, h * .54f, w * .54f, h * .54f, stroke)
            }
        }
    }
}

/**
 * Floating calculator window above other apps (WindowManager + SYSTEM_ALERT_WINDOW, kept alive by a foreground service).
 *
 *   [expand] [minimize]        ▬ drag handle        [close]
 *
 * expand   : compact <-> expanded (large); the calculation is kept. Double-tap the handle to cycle small / medium / large.
 * minimize : turns the window into a small bubble; tap the bubble to restore.
 * handle   : drag the window anywhere (it can never be pushed fully off-screen).
 * close    : removes the window and stops the service. Nothing saved (history, settings) is touched.
 * corner dot (bottom-right): drag to resize smoothly; keys, text and display scale together.
 * Rotation: the window is re-fitted to the new screen. It does not take keyboard focus.
 */
class FloatingCalcService : Service() {
    private var wm: WindowManager? = null
    private var root: FrameLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private lateinit var content: LinearLayout
    private lateinit var bar: FrameLayout
    private lateinit var left: LinearLayout
    private lateinit var btnExpand: GlyphView
    private lateinit var btnMin: GlyphView
    private lateinit var btnClose: GlyphView
    private lateinit var handleView: View
    private lateinit var gap: View
    private lateinit var bubble: TextView
    private lateinit var tvExpr: TextView
    private lateinit var tvPrev: TextView
    private val keyViews = mutableListOf<TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private val logic = FloatCalcLogic()
    private var collapsed = false
    private var savedW = 0
    private var compactW = 0
    private var sizeAnim: ValueAnimator? = null
    private val ratio = 380f / 260f   // height / width: the window keeps this shape
    private var held = false
    private val repeater = object : Runnable {
        override fun run() { held = true; onKey("⌫"); handler.postDelayed(this, 70) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val n = notification()
        if (Build.VERSION.SDK_INT >= 34) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)
        if (root == null) show()
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {   // rotation / fold / split screen
        super.onConfigurationChanged(newConfig)
        val p = lp ?: return
        if (!collapsed) { p.width = p.width.coerceIn(minW(), maxW()); p.height = (p.width * ratio).toInt() }
        clamp(p)
        root?.let { wm?.updateViewLayout(it, p) }
        applySizes()
    }

    override fun onDestroy() {   // release everything: animator, callbacks, window
        sizeAnim?.cancel(); sizeAnim = null
        handler.removeCallbacksAndMessages(null)
        root?.let { runCatching { wm?.removeView(it) } }
        root = null; wm = null; lp = null
        keyViews.clear()
        super.onDestroy()
    }

    private fun notification(): Notification {
        val ch = "floating_calc"
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(ch, "Floating calculator", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingCalcService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, ch)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Floating calculator is on")
            .setContentText("Tap to open the app")
            .setContentIntent(open).addAction(0, "Close", stop).setOngoing(true).build()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun minW() = dp(140)
    private fun maxW(): Int {
        val dm = resources.displayMetrics
        return min(dm.widthPixels - dp(16), (dm.heightPixels * 0.9f / ratio).toInt()).coerceAtLeast(minW())
    }
    private fun shape(color: Int, r: Float = 1000f, strokeColor: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = r; if (strokeColor != 0) setStroke(dp(1), strokeColor)
    }

    private fun show() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else 2002   // 2002 = TYPE_PHONE
        val startW = dp(260).coerceIn(minW(), maxW())
        val p = WindowManager.LayoutParams(
            startW, (startW * ratio).toInt(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START; p.x = dp(24); p.y = dp(120)
        lp = p
        compactW = startW

        val frame = FrameLayout(this).apply { background = windowBg() }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(2)) }

        // ---- control bar: [expand] [minimize]  ▬  [close]
        bar = FrameLayout(this)
        btnExpand = GlyphView(this, G_EXPAND).also { it.setOnClickListener { toggleExpanded() } }
        btnMin = GlyphView(this, G_MINUS).also { it.setOnClickListener { setCollapsed(true) } }
        btnClose = GlyphView(this, G_CLOSE).also { it.setOnClickListener { stopSelf() } }
        gap = View(this)
        left = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        left.addView(btnExpand, LinearLayout.LayoutParams(dp(28), dp(28)))
        left.addView(gap, LinearLayout.LayoutParams(dp(16), 1))
        left.addView(btnMin, LinearLayout.LayoutParams(dp(28), dp(28)))
        handleView = View(this).apply { background = shape(0xFFF2F2F2.toInt(), dp(3).toFloat()) }
        bar.addView(left, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(handleView, FrameLayout.LayoutParams(dp(36), dp(3), Gravity.CENTER))
        bar.addView(btnClose, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.END or Gravity.CENTER_VERTICAL))
        enableDrag(bar, doubleTap = { cycleSize() })   // empty parts of the bar + the handle drag the window
        content.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(32)))

        tvExpr = TextView(this).apply {
            setTextColor(Color.WHITE); gravity = Gravity.END or Gravity.BOTTOM; maxLines = 2
            ellipsize = TextUtils.TruncateAt.START; text = "0"
        }
        tvPrev = TextView(this).apply { setTextColor(0xFF9AA4B4.toInt()); gravity = Gravity.END; maxLines = 1; textSize = 15f }
        content.addView(tvExpr, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.1f))
        content.addView(tvPrev, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"), listOf("7", "8", "9", "×"), listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"), listOf("00", "0", ".", "=")
        )
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        rows.forEach { r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { label ->
                val cell = FrameLayout(this)
                cell.addView(makeKey(label), FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
                row.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            grid.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        content.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 4f))

        // bottom-right dot = resize
        val footer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        footer.addView(View(this).apply { background = shape(0xCCFFFFFF.toInt()) }, LinearLayout.LayoutParams(dp(16), dp(16)).apply { setMargins(0, dp(3), dp(4), dp(3)) })
        enableResize(footer)
        content.addView(footer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(22)))

        bubble = TextView(this).apply { text = "="; setTextColor(0xFF0B1B3F.toInt()); textSize = 22f; gravity = Gravity.CENTER; visibility = View.GONE }
        enableDrag(bubble, onTap = { setCollapsed(false) })

        frame.addView(content, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(bubble, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = frame
        w.addView(frame, p)
        applySizes()
        refresh()
        frame.alpha = 0f; frame.scaleX = 0.92f; frame.scaleY = 0.92f      // small fade/scale-in
        frame.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).start()
    }

    private fun windowBg() = shape(0xF2141518.toInt(), dp(24).toFloat(), 0x22FFFFFF)

    private fun makeKey(label: String): TextView {
        val bg = when (label) {
            "AC", "⌫" -> 0xFF4A3516
            "%", "÷", "×", "−", "+" -> 0xFF1E3A6E
            "=" -> 0xFF5B8CFF
            else -> 0xFF2B303B
        }.toInt()
        val fg = when (label) {
            "%", "÷", "×", "−", "+" -> 0xFFCFE0FF
            "=" -> 0xFF0B1B3F
            "AC", "⌫" -> 0xFFFFD9A6
            else -> 0xFFEEF1F6
        }.toInt()
        val tv = TextView(this).apply {
            text = label; tag = label; setTextColor(fg); gravity = Gravity.CENTER; isClickable = true
            background = shape(bg, if (label == "=") dp(22).toFloat() else 1000f)   // round keys; only "=" is a rounded rectangle
        }
        tv.setOnClickListener {
            if (label == "⌫" && held) { held = false }   // the long press already deleted
            else { tv.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onKey(label) }
        }
        tv.setOnTouchListener { v, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(60).start()   // press feedback
                    if (label == "⌫") { held = false; handler.postDelayed(repeater, 420) }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                    if (label == "⌫") handler.removeCallbacks(repeater)
                }
            }
            false
        }
        keyViews.add(tv)
        return tv
    }

    private fun onKey(k: String) { logic.key(k); refresh() }

    private fun refresh() {
        tvExpr.text = logic.expr.ifEmpty { "0" }
        tvPrev.text = logic.error ?: logic.preview
        tvPrev.setTextColor(if (logic.error != null) 0xFFFF8A80.toInt() else 0xFF9AA4B4.toInt())
    }

    // ---------- layout that scales with the window ----------
    /** Control bar, round keys, key text and display text all follow the window width, so nothing overlaps at any size. */
    private fun applySizes() {
        val p = lp ?: return
        val d = (p.width * 0.085f).toInt().coerceIn(dp(22), dp(34))   // proportions of the reference bar
        val barH = d + dp(6)
        fun lpBtn(v: View) { v.layoutParams = (v.layoutParams as ViewGroup.LayoutParams).also { it.width = d; it.height = d } }
        lpBtn(btnExpand); lpBtn(btnMin); lpBtn(btnClose)
        (gap.layoutParams as ViewGroup.LayoutParams).width = (p.width * 0.06f).toInt()
        gap.requestLayout()
        handleView.layoutParams = FrameLayout.LayoutParams((p.width * 0.13f).toInt().coerceAtLeast(dp(26)), dp(3), Gravity.CENTER)
        bar.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, barH)

        val gridH = (p.height - dp(8 + 2 + 22 + 20) - barH) * 4f / 5.1f
        val cellW = (p.width - dp(16)) / 4f
        val cellH = gridH / 5f
        val side = (min(cellW, cellH) - dp(6)).toInt().coerceAtLeast(dp(20))
        val textPx = side * 0.38f
        keyViews.forEach { k ->
            val wide = k.tag == "="
            k.layoutParams = FrameLayout.LayoutParams(if (wide) (cellW - dp(6)).toInt() else side, side, Gravity.CENTER)
            k.setTextSize(TypedValue.COMPLEX_UNIT_PX, textPx)
        }
        tvExpr.setTextSize(TypedValue.COMPLEX_UNIT_PX, (p.width / 9f).coerceIn(dp(16).toFloat(), dp(44).toFloat()))
        val kind = if (isExpanded()) G_CONTRACT else G_EXPAND
        if (btnExpand.kind != kind) { btnExpand.kind = kind }
        btnExpand.invalidate(); btnMin.invalidate(); btnClose.invalidate()
    }

    private fun isExpanded() = (lp?.width ?: 0) >= maxW() * 0.95f

    private fun clamp(p: WindowManager.LayoutParams) {   // keep at least a grabbable part of the window on screen
        val dm = resources.displayMetrics
        p.x = p.x.coerceIn(-p.width + dp(60), dm.widthPixels - dp(60))
        p.y = p.y.coerceIn(0, dm.heightPixels - dp(60))
    }

    private fun applyWidth(w: Int) {
        val p = lp ?: return
        p.width = w; p.height = (w * ratio).toInt()
        clamp(p)
        root?.let { wm?.updateViewLayout(it, p) }
        applySizes()
    }

    private fun setWidth(target: Int, animate: Boolean = true) {
        val p = lp ?: return
        if (collapsed) return
        val t = target.coerceIn(minW(), maxW())
        sizeAnim?.cancel()
        if (!animate) { applyWidth(t); return }
        sizeAnim = ValueAnimator.ofInt(p.width, t).apply {
            duration = 180
            addUpdateListener { applyWidth(it.animatedValue as Int) }
            start()
        }
    }

    /** Expand button: compact <-> expanded. The calculation stays as it is. */
    private fun toggleExpanded() {
        val p = lp ?: return
        if (isExpanded()) setWidth(if (compactW in minW() until maxW()) compactW else dp(260))
        else { compactW = p.width; setWidth(maxW()) }
    }

    /** Double-tap on the handle: small -> medium -> large -> small. */
    private fun cycleSize() {
        val p = lp ?: return
        val steps = listOf(190, 260, 340).map { dp(it).coerceIn(minW(), maxW()) }
        val next = steps.firstOrNull { it > p.width + dp(6) } ?: steps.first()
        compactW = next
        setWidth(next)
    }

    private fun setCollapsed(c: Boolean) {
        val p = lp ?: return
        val r = root ?: return
        if (c == collapsed) return
        sizeAnim?.cancel()
        collapsed = c
        if (c) {
            savedW = p.width
            content.visibility = View.GONE; bubble.visibility = View.VISIBLE
            r.background = shape(0xFF5B8CFF.toInt())
            p.width = dp(52); p.height = dp(52)
        } else {
            content.visibility = View.VISIBLE; bubble.visibility = View.GONE
            r.background = windowBg()
            p.width = savedW.coerceIn(minW(), maxW()); p.height = (p.width * ratio).toInt()
        }
        clamp(p)
        wm?.updateViewLayout(r, p)
        applySizes()
        r.scaleX = 0.85f; r.scaleY = 0.85f
        r.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
    }

    private fun enableDrag(v: View, onTap: (() -> Unit)? = null, doubleTap: (() -> Unit)? = null) {
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean { doubleTap?.invoke(); return doubleTap != null }
        })
        v.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            if (doubleTap != null) gd.onTouchEvent(e)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    if (moved) {
                        p.x = ox + dx.toInt(); p.y = oy + dy.toInt()
                        clamp(p)
                        root?.let { wm?.updateViewLayout(it, p) }
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) onTap?.invoke()
            }
            true
        }
    }

    private fun enableResize(v: View) {
        var sx = 0f; var sy = 0f; var ow = 0
        v.setOnTouchListener { _, e ->
            val p = lp ?: return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ow = p.width; sizeAnim?.cancel() }
                MotionEvent.ACTION_MOVE -> {
                    val grow = ((e.rawX - sx) + (e.rawY - sy) / ratio) / 2f   // drag the corner; the shape stays the same
                    applyWidth((ow + grow.toInt()).coerceIn(minW(), maxW()))
                }
                MotionEvent.ACTION_UP -> if (!isExpanded()) compactW = p.width
            }
            true
        }
    }

    companion object {
        private const val ACTION_STOP = "com.example.calculatorpro.floating.STOP"
        private const val NOTIF_ID = 1001
    }
}
