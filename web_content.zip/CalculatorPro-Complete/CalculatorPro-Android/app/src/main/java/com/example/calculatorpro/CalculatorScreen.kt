package com.example.calculatorpro

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculatorpro.calc.Evaluator
import com.example.calculatorpro.data.Fmt
import com.example.calculatorpro.floating.FloatingCalc
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** type: 0 digit, 1 operator, 2 equals, 3 utility; weight > 1 = wide key; holdRepeat = keeps firing while held (backspace). */
private class K(val label: String, val type: Int, val weight: Float = 1f, val holdRepeat: Boolean = false, val act: () -> Unit)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(vm: MainViewModel, onHistory: () -> Unit, onCurrency: () -> Unit) {
    val ctx = LocalContext.current
    var tape by remember { mutableStateOf(false) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calculator Pro", fontWeight = FontWeight.SemiBold, maxLines = 1) },
                actions = {
                    FilterChip(
                        selected = vm.scientific, onClick = { vm.toggleMode() },
                        label = { Text(if (vm.scientific) "Scientific" else "Basic") }
                    )
                    IconButton(onClick = { FloatingCalc.start(ctx) }) { Icon(Icons.Default.PictureInPictureAlt, contentDescription = "Floating calculator") }
                    IconButton(onClick = onCurrency) { Icon(Icons.Default.CurrencyExchange, contentDescription = "Currency exchange") }
                    IconButton(onClick = onHistory) { Icon(Icons.Default.History, contentDescription = "History") }
                }
            )
        }
    ) { pad ->
        BoxWithConstraints(Modifier.padding(pad).fillMaxSize()) {
            // Round keys: the circle size is whatever fits the screen width AND height (phone / small screen / landscape).
            val rowW = maxWidth - 24.dp
            val rows = if (vm.scientific) 9 else 6
            val units = 6f + (if (vm.scientific) 3 * 0.72f else 0f)
            val sideByW = (rowW - 8.dp * 3) / 4
            val sideByH = (maxHeight - 150.dp - 8.dp * (rows - 1)) / units
            val side = minOf(sideByW, sideByH).coerceIn(36.dp, 96.dp)
            Column(Modifier.fillMaxSize()) {
                Display(vm, Modifier.weight(1f).fillMaxWidth()) { tape = true }
                Keypad(vm, side, rowW)
            }
        }
    }
    if (tape) TapeSheet(vm.expression, vm.degrees) { tape = false }
}

/** The expression scrolls (newest at the bottom, swipe up to see the start) and "Full calculation" opens the whole list. */
@Composable
private fun Display(vm: MainViewModel, modifier: Modifier, onExpand: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val scroll = rememberScrollState()
    LaunchedEffect(vm.expression) { scroll.scrollTo(scroll.maxValue) }
    Box(modifier) {
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 8.dp), horizontalAlignment = Alignment.End) {
            if (!vm.settings.autoSave) {
                Text("History saving is off — new calculations won't be stored.", style = MaterialTheme.typography.labelMedium, color = cs.error)
                Spacer(Modifier.height(8.dp))
            }
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.BottomEnd) {
                Column(Modifier.verticalScroll(scroll)) {
                    val n = vm.expression.length
                    val size = when { n <= 10 -> 52.sp; n <= 16 -> 40.sp; n <= 24 -> 32.sp; n <= 60 -> 26.sp; else -> 20.sp }
                    Text(
                        vm.expression.ifEmpty { "0" }, fontSize = size, textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth(),
                        color = if (vm.expression.isEmpty()) cs.onSurfaceVariant else cs.onSurface
                    )
                }
            }
            Text(
                vm.error ?: vm.preview, style = MaterialTheme.typography.titleLarge,
                color = if (vm.error != null) cs.error else cs.onSurfaceVariant,
                modifier = Modifier.heightIn(min = 32.dp), maxLines = 1
            )
        }
        if (vm.expression.isNotEmpty()) {
            TextButton(onClick = onExpand, modifier = Modifier.align(Alignment.TopStart).padding(start = 8.dp)) {
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = null)
                Text("Full calculation")
            }
        }
    }
}

private fun closeParens(e: String): String {
    val n = e.count { it == '(' } - e.count { it == ')' }
    return if (n > 0) e + ")".repeat(n) else e
}

/** Drop-down list of every entry with the running total after each one. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TapeSheet(expr: String, deg: Boolean, onDismiss: () -> Unit) {
    val rows = remember(expr, deg) {
        var pre = ""
        Regex("[+−×÷^]?[^+−×÷^]+").findAll(expr).map { it.value }.toList().map { t ->
            pre += t
            t to runCatching { Fmt.num(Evaluator.format(Evaluator.eval(closeParens(pre), deg))) }.getOrDefault("")
        }
    }
    val state = rememberLazyListState()
    LaunchedEffect(rows.size) { if (rows.isNotEmpty()) state.scrollToItem(rows.lastIndex) }
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxHeight(0.8f).padding(horizontal = 20.dp)) {
            Text("Full calculation · ${rows.size} ${if (rows.size == 1) "entry" else "entries"}", style = MaterialTheme.typography.titleMedium)
            Text("Right side: running total after each entry", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            LazyColumn(state = state, modifier = Modifier.weight(1f)) {
                items(rows) { (term, total) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(term, style = MaterialTheme.typography.bodyLarge)
                        Text(total, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun Keypad(vm: MainViewModel, side: Dp, rowW: Dp) {
    val sci = listOf(
        listOf(K("sin", 3) { vm.input("sin(") }, K("cos", 3) { vm.input("cos(") }, K("tan", 3) { vm.input("tan(") },
            K(if (vm.degrees) "DEG" else "RAD", 3) { vm.toggleAngle() }),
        listOf(K("ln", 3) { vm.input("ln(") }, K("log", 3) { vm.input("log(") }, K("√", 3) { vm.input("√(") }, K("^", 1) { vm.input("^") }),
        listOf(K("π", 3) { vm.input("π") }, K("e", 3) { vm.input("e") }, K("!", 3) { vm.input("!") }, K("(", 3) { vm.input("(") })
    )
    val basic = listOf(
        listOf(K("AC", 3) { vm.clear() }, K("⌫", 3, holdRepeat = true) { vm.backspace() }, K("%", 1) { vm.input("%") }, K("÷", 1) { vm.input("÷") }),
        listOf(K("7", 0) { vm.input("7") }, K("8", 0) { vm.input("8") }, K("9", 0) { vm.input("9") }, K("×", 1) { vm.input("×") }),
        listOf(K("4", 0) { vm.input("4") }, K("5", 0) { vm.input("5") }, K("6", 0) { vm.input("6") }, K("−", 1) { vm.input("−") }),
        listOf(K("1", 0) { vm.input("1") }, K("2", 0) { vm.input("2") }, K("3", 0) { vm.input("3") }, K("+", 1) { vm.input("+") }),
        listOf(K("00", 0) { repeat(2) { vm.input("0") } }, K("0", 0) { vm.input("0") }, K("000", 0) { repeat(3) { vm.input("0") } }, K(".", 0) { vm.input(".") }),
        listOf(K("( )", 0) { vm.paren() }, K("=", 2, 3f) { vm.calculate() })
    )
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (vm.scientific) sci.forEach { KeyRow(it, side, rowW, 0.72f, small = true) }
        basic.forEach { KeyRow(it, side, rowW, 1f, small = false) }
    }
}

/** Round keys sit on a 4-column grid; the wide "=" key is the only rectangle. */
@Composable
private fun KeyRow(keys: List<K>, side: Dp, rowW: Dp, scale: Float, small: Boolean) {
    val d = side * scale
    val gapX = (rowW - side * 4) / 3
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gapX)) {
        keys.forEach { k ->
            if (k.weight > 1f) CalcKey(k, Modifier.weight(1f).height(d), small, RoundedCornerShape(26.dp))
            else Box(Modifier.size(side, d), contentAlignment = Alignment.Center) { CalcKey(k, Modifier.size(d), small, CircleShape) }
        }
    }
}

@Composable
private fun CalcKey(k: K, modifier: Modifier, small: Boolean, shape: Shape) {
    val cs = MaterialTheme.colorScheme
    val haptic = LocalHapticFeedback.current
    val (bg, fg) = when (k.type) {
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        2 -> cs.primary to cs.onPrimary
        3 -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.surfaceContainerHighest to cs.onSurface
    }
    val tap: () -> Unit = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); k.act() }
    val label: @Composable () -> Unit = {
        Box(contentAlignment = Alignment.Center) {
            Text(k.label, fontSize = if (small) 16.sp else 22.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
    if (k.holdRepeat) {
        // fires on touch-down (no delay) and keeps repeating while held
        val scope = rememberCoroutineScope()
        Surface(
            modifier = modifier.pointerInput(Unit) {
                detectTapGestures(onPress = {
                    tap()
                    val job = scope.launch { delay(400); while (true) { tap(); delay(70) } }
                    tryAwaitRelease()
                    job.cancel()
                })
            },
            shape = shape, color = bg, contentColor = fg, content = label
        )
    } else {
        Surface(onClick = tap, modifier = modifier, shape = shape, color = bg, contentColor = fg, content = label)
    }
}
