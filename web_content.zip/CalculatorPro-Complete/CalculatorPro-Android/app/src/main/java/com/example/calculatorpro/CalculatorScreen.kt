package com.example.calculatorpro

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CurrencyExchange
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class K(val label: String, val type: Int, val weight: Float = 1f, val act: () -> Unit)   // type: 0 digit, 1 operator, 2 equals, 3 utility

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(vm: MainViewModel, onHistory: () -> Unit, onCurrency: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Calculator Pro", fontWeight = FontWeight.SemiBold) },
                actions = {
                    FilterChip(
                        selected = vm.scientific, onClick = { vm.toggleMode() },
                        label = { Text(if (vm.scientific) "Scientific" else "Basic") }
                    )
                    Spacer(Modifier.width(4.dp))
                    IconButton(onClick = onCurrency) { Icon(Icons.Default.CurrencyExchange, contentDescription = "Currency exchange") }
                    IconButton(onClick = onHistory) { Icon(Icons.Default.History, contentDescription = "History") }
                }
            )
        }
    ) { pad ->
        BoxWithConstraints(Modifier.padding(pad).fillMaxSize()) {
            val rows = if (vm.scientific) 9 else 6
            val keyH = ((maxHeight - 150.dp) / rows).coerceIn(38.dp, 68.dp)   // adapts to phone / small screen / landscape
            Column(Modifier.fillMaxSize()) {
                Display(vm, Modifier.weight(1f).fillMaxWidth())
                Keypad(vm, keyH)
            }
        }
    }
}

@Composable
private fun Display(vm: MainViewModel, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    Column(
        modifier.padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.Bottom, horizontalAlignment = Alignment.End
    ) {
        if (!vm.settings.autoSave) {
            Text("History saving is off — new calculations won't be stored.", style = MaterialTheme.typography.labelMedium, color = cs.error)
            Spacer(Modifier.height(8.dp))
        }
        val n = vm.expression.length
        val size = when { n <= 10 -> 52.sp; n <= 16 -> 40.sp; n <= 24 -> 32.sp; else -> 24.sp }
        Text(
            vm.expression.ifEmpty { "0" }, fontSize = size, maxLines = 3, textAlign = TextAlign.End,
            color = if (vm.expression.isEmpty()) cs.onSurfaceVariant else cs.onSurface
        )
        Text(
            vm.error ?: vm.preview, style = MaterialTheme.typography.titleLarge,
            color = if (vm.error != null) cs.error else cs.onSurfaceVariant,
            modifier = Modifier.heightIn(min = 32.dp), maxLines = 1
        )
    }
}

@Composable
private fun Keypad(vm: MainViewModel, keyH: Dp) {
    val sci = listOf(
        listOf(K("sin", 3) { vm.input("sin(") }, K("cos", 3) { vm.input("cos(") }, K("tan", 3) { vm.input("tan(") },
            K(if (vm.degrees) "DEG" else "RAD", 3) { vm.toggleAngle() }),
        listOf(K("ln", 3) { vm.input("ln(") }, K("log", 3) { vm.input("log(") }, K("√", 3) { vm.input("√(") }, K("^", 1) { vm.input("^") }),
        listOf(K("π", 3) { vm.input("π") }, K("e", 3) { vm.input("e") }, K("!", 3) { vm.input("!") }, K("(", 3) { vm.input("(") })
    )
    val basic = listOf(
        listOf(K("AC", 3) { vm.clear() }, K("⌫", 3) { vm.backspace() }, K("%", 1) { vm.input("%") }, K("÷", 1) { vm.input("÷") }),
        listOf(K("7", 0) { vm.input("7") }, K("8", 0) { vm.input("8") }, K("9", 0) { vm.input("9") }, K("×", 1) { vm.input("×") }),
        listOf(K("4", 0) { vm.input("4") }, K("5", 0) { vm.input("5") }, K("6", 0) { vm.input("6") }, K("−", 1) { vm.input("−") }),
        listOf(K("1", 0) { vm.input("1") }, K("2", 0) { vm.input("2") }, K("3", 0) { vm.input("3") }, K("+", 1) { vm.input("+") }),
        listOf(K("00", 0) { repeat(2) { vm.input("0") } }, K("0", 0) { vm.input("0") }, K("000", 0) { repeat(3) { vm.input("0") } }, K(".", 0) { vm.input(".") }),
        listOf(K("( )", 0) { vm.paren() }, K("=", 2, 3f) { vm.calculate() })
    )
    Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (vm.scientific) sci.forEach { KeyRow(it, keyH * 0.75f, small = true) }
        basic.forEach { KeyRow(it, keyH, small = false) }
    }
}

@Composable
private fun KeyRow(keys: List<K>, h: Dp, small: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        keys.forEach { CalcKey(it, Modifier.weight(it.weight).height(h), small) }
    }
}

@Composable
private fun CalcKey(k: K, modifier: Modifier, small: Boolean) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (k.type) {
        1 -> cs.secondaryContainer to cs.onSecondaryContainer
        2 -> cs.primary to cs.onPrimary
        3 -> cs.tertiaryContainer to cs.onTertiaryContainer
        else -> cs.surfaceContainerHighest to cs.onSurface
    }
    Surface(onClick = k.act, modifier = modifier, shape = RoundedCornerShape(20.dp), color = bg, contentColor = fg) {
        androidx.compose.foundation.layout.Box(contentAlignment = Alignment.Center) {
            Text(k.label, fontSize = if (small) 16.sp else 24.sp, fontWeight = FontWeight.Medium)
        }
    }
}
