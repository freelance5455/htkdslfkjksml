package com.example.calculatorpro

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.calculatorpro.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneOffset

private sealed interface Confirm {
    data class Bulk(val ids: Set<Long>) : Confirm
    data object All : Confirm
    data object Range : Confirm
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun HistoryScreen(vm: MainViewModel, onBack: () -> Unit, onSettings: () -> Unit, onCurrencyHistory: () -> Unit = {}) {
    val ctx = LocalContext.current
    val s = vm.settings
    val raw by vm.items.collectAsState()
    val f by vm.filters.collectAsState()
    val total by vm.total.collectAsState()
    val latest by vm.latest.collectAsState()
    val list = raw ?: emptyList()

    var selected by remember { mutableStateOf(setOf<Long>()) }
    var detail by remember { mutableStateOf<HistoryEntity?>(null) }
    var confirm by remember { mutableStateOf<Confirm?>(null) }
    var showRange by remember { mutableStateOf(false) }
    var timeStep by remember { mutableIntStateOf(0) }
    var tmpFrom by remember { mutableIntStateOf(0) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf(f.query) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val selecting = selected.isNotEmpty()

    LaunchedEffect(Unit) { vm.refreshClock() }
    LaunchedEffect(f.query) { if (query != f.query) query = f.query }
    LaunchedEffect(raw) {
        if (selected.isNotEmpty()) { val ids = list.map { it.id }.toSet(); selected = selected.filter { it in ids }.toSet() }
    }
    BackHandler(selecting) { selected = emptySet() }

    fun toast(m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()
    fun copy(text: String) {
        ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("Calculator Pro", text))
        toast("Copied")
    }
    fun deleteOne(e: HistoryEntity) {
        vm.delete(e)
        scope.launch {
            snackbar.currentSnackbarData?.dismiss()
            val r = snackbar.showSnackbar("Entry deleted", actionLabel = "Undo", duration = SnackbarDuration.Long)
            if (r == SnackbarResult.ActionPerformed) vm.restore(e)
        }
    }
    val target = if (selecting) list.filter { it.id in selected } else list
    fun exportCsv() { if (target.isEmpty()) toast("Nothing to export") else Export.shareCsv(ctx, target) }
    fun shareSummary() { if (target.isEmpty()) toast("Nothing to share") else Export.shareText(ctx, Export.summary(target, s)) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            if (selecting) {
                TopAppBar(
                    title = { Text("${selected.size} selected") },
                    navigationIcon = { IconButton({ selected = emptySet() }) { Icon(Icons.Default.Close, "Cancel selection") } },
                    actions = {
                        IconButton({ selected = list.map { it.id }.toSet() }) { Icon(Icons.Default.SelectAll, "Select all") }
                        IconButton({ shareSummary() }) { Icon(Icons.Default.Share, "Share summary") }
                        IconButton({ exportCsv() }) { Icon(Icons.Default.Download, "Export CSV") }
                        IconButton({ confirm = Confirm.Bulk(selected) }) { Icon(Icons.Default.Delete, "Delete selected") }
                    }
                )
            } else {
                TopAppBar(
                    title = { Text("History") },
                    navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back to calculator") } },
                    actions = {
                        Box {
                            IconButton({ sortMenu = true }) { Icon(Icons.AutoMirrored.Filled.Sort, "Sort") }
                            DropdownMenu(sortMenu, { sortMenu = false }) {
                                SORT_LABELS.forEachIndexed { i, l ->
                                    DropdownMenuItem(
                                        text = { Text(l) },
                                        leadingIcon = { if (f.sort == i) Icon(Icons.Default.Check, null) },
                                        onClick = { vm.editFilters { it.copy(sort = i) }; sortMenu = false }
                                    )
                                }
                            }
                        }
                        Box {
                            IconButton({ moreMenu = true }) { Icon(Icons.Default.MoreVert, "More") }
                            DropdownMenu(moreMenu, { moreMenu = false }) {
                                DropdownMenuItem({ Text("Export CSV (current view)") }, { moreMenu = false; exportCsv() })
                                DropdownMenuItem({ Text("Share summary (current view)") }, { moreMenu = false; shareSummary() })
                                if (f.date != DateF.ALL)
                                    DropdownMenuItem({ Text("Clear this date range…") }, { moreMenu = false; confirm = Confirm.Range })
                                DropdownMenuItem({ Text("Clear all history…") }, { moreMenu = false; confirm = Confirm.All })
                                DropdownMenuItem({ Text("Currency conversion history") }, { moreMenu = false; onCurrencyHistory() })
                                DropdownMenuItem({ Text("History settings") }, { moreMenu = false; onSettings() })
                            }
                        }
                    }
                )
            }
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
            item { SummaryCard(list, total, latest, f, s) }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { q -> query = q; vm.editFilters { it.copy(query = q) } },
                    singleLine = true, shape = RoundedCornerShape(28.dp),
                    placeholder = { Text("Search expression or result") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (query.isNotEmpty()) IconButton({ query = ""; vm.editFilters { it.copy(query = "") } }) { Icon(Icons.Default.Close, "Clear search") }
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                )
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(DateF.entries.toList()) { d ->
                        FilterChip(
                            selected = f.date == d,
                            onClick = { if (d == DateF.CUSTOM) showRange = true else vm.editFilters { it.copy(date = d) } },
                            label = { Text(if (d == DateF.CUSTOM && f.date == DateF.CUSTOM && f.customFrom != null) Fmt.spanLabel(f, s) else d.label) },
                            leadingIcon = if (d == DateF.CUSTOM) ({ Icon(Icons.Default.CalendarMonth, null, Modifier.size(18.dp)) }) else null
                        )
                    }
                }
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(TimeF.entries.toList()) { t ->
                        FilterChip(
                            selected = f.time == t,
                            onClick = { if (t == TimeF.CUSTOM) timeStep = 1 else vm.editFilters { it.copy(time = t) } },
                            label = { Text(t.label) },
                            leadingIcon = if (t == TimeF.CUSTOM) ({ Icon(Icons.Default.Schedule, null, Modifier.size(18.dp)) }) else null
                        )
                    }
                }
            }
            if (f.time != TimeF.ANY) item {
                val (a, b) = timeBounds(f)
                Text("${Fmt.minutes(a, s)} – ${Fmt.minutes(b, s)}", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp))
            }
            item {
                Text("Sorted: " + SORT_LABELS[f.sort], style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
            }

            when {
                raw == null -> item { Box(Modifier.fillMaxWidth().padding(48.dp), Alignment.Center) { CircularProgressIndicator() } }
                list.isEmpty() -> item { EmptyState(total == 0) { vm.resetFilters() } }
                else -> {
                    val rowFor: @Composable (HistoryEntity, Boolean) -> Unit = { e, showDate ->
                        HistoryRow(
                            e, s, showDate, e.id in selected, selecting,
                            onClick = { if (selecting) selected = if (e.id in selected) selected - e.id else selected + e.id else detail = e },
                            onLong = { selected = selected + e.id },
                            onCopyExpr = { copy(e.expression) },
                            onCopyResult = { copy(e.result) },
                            onRecalc = { vm.recalc(e); onBack() },
                            onDelete = { deleteOne(e) }
                        )
                    }
                    if (f.sort <= 1) {
                        list.groupBy { Fmt.at(it.timestamp).toLocalDate() }.forEach { (day, es) ->
                            item(key = "h$day") {
                                Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
                                    Text(Fmt.dayLabel(day, s).uppercase(), style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    val lbl = Fmt.dayLabel(day, s)
                                    if (lbl == "Today" || lbl == "Yesterday") {
                                        Spacer(Modifier.width(8.dp))
                                        Text(Fmt.date(day, s), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                            items(es, key = { it.id }) { e -> rowFor(e, false) }
                        }
                    } else {
                        items(list, key = { it.id }) { e -> rowFor(e, true) }
                    }
                }
            }
        }
    }

    // ---------- dialogs & sheets ----------
    if (showRange) RangeDialog(f.customFrom, f.customTo, { showRange = false }) { a, b ->
        vm.editFilters { it.copy(date = DateF.CUSTOM, customFrom = a, customTo = b) }; showRange = false
    }
    if (timeStep == 1) TimeDialog("Start time", f.timeFrom, s.use24h, { timeStep = 0 }) { tmpFrom = it; timeStep = 2 }
    if (timeStep == 2) TimeDialog("End time", f.timeTo, s.use24h, { timeStep = 0 }) { end ->
        vm.editFilters { it.copy(time = TimeF.CUSTOM, timeFrom = tmpFrom, timeTo = end) }; timeStep = 0
    }

    detail?.let { e ->
        ModalBottomSheet(onDismissRequest = { detail = null }) {
            Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${Fmt.modeName(e.calculatorMode)} · ${Fmt.dateTime(e.timestamp, s)}", style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(e.expression, style = MaterialTheme.typography.headlineSmall)
                Text("= " + Fmt.num(e.result), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ vm.reuseExpression(e); detail = null; onBack() }) { Text("Use expression") }
                    Button({ vm.reuseResult(e); detail = null; onBack() }) { Text("Use result") }
                    FilledTonalButton({ vm.recalc(e); detail = null; onBack() }) { Text("Recalculate") }
                    OutlinedButton({ copy(e.expression) }) { Text("Copy expression") }
                    OutlinedButton({ copy(e.result) }) { Text("Copy result") }
                    OutlinedButton({ copy(Export.entryText(e, s)) }) { Text("Copy with date & time") }
                    OutlinedButton({ Export.shareText(ctx, Export.entryText(e, s)) }) { Text("Share") }
                    TextButton({ deleteOne(e); detail = null }, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
                }
            }
        }
    }

    confirm?.let { c ->
        val (title, text, action) = when (c) {
            is Confirm.Bulk -> Triple("Delete ${c.ids.size} calculations?", "This can't be undone.", { vm.deleteIds(c.ids); selected = emptySet() })
            Confirm.All -> Triple("Clear all history?", "All $total saved calculations will be permanently deleted.", { vm.clearAll(); selected = emptySet() })
            Confirm.Range -> Triple("Clear this date range?", "Every calculation from ${Fmt.spanLabel(f, s)} will be permanently deleted.", { vm.clearRange(); selected = emptySet() })
        }
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(title) }, text = { Text(text) },
            confirmButton = { TextButton({ action(); confirm = null }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ confirm = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SummaryCard(list: List<HistoryEntity>, total: Int, latest: Long?, f: Filters, s: AppSettings) {
    val cs = MaterialTheme.colorScheme
    Card(Modifier.padding(16.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = cs.primaryContainer)) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("Total saved", total.toString(), null)
                Stat("In this view", list.size.toString(), null)
                val z = latest?.let { Fmt.at(it) }
                Stat("Most recent", z?.let { Fmt.time(it.toLocalTime(), s) } ?: "—", z?.let { Fmt.dayLabel(it.toLocalDate(), s) })
            }
            if (f.date != DateF.ALL) Text("Range: " + Fmt.spanLabel(f, s), style = MaterialTheme.typography.labelMedium)
            Text("Basic ${list.count { it.calculatorMode != "SCIENTIFIC" }} · Scientific ${list.count { it.calculatorMode == "SCIENTIFIC" }}",
                style = MaterialTheme.typography.labelMedium, modifier = Modifier.alpha(0.8f))
        }
    }
}

@Composable
private fun Stat(label: String, value: String, sub: String?) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, modifier = Modifier.alpha(0.8f))
        Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (sub != null) Text(sub, style = MaterialTheme.typography.labelSmall, modifier = Modifier.alpha(0.8f))
    }
}

@Composable
private fun EmptyState(noHistoryAtAll: Boolean, onReset: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(40.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(Icons.Default.History, null, Modifier.size(64.dp).alpha(0.4f))
        Text(if (noHistoryAtAll) "No calculations yet" else "No matching calculations", style = MaterialTheme.typography.titleMedium)
        Text(
            if (noHistoryAtAll) "Completed calculations are saved here automatically."
            else "Try a different search, date or time filter.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (!noHistoryAtAll) TextButton(onReset) { Text("Reset filters") }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HistoryRow(
    e: HistoryEntity, s: AppSettings, showDate: Boolean, selected: Boolean, selecting: Boolean,
    onClick: () -> Unit, onLong: () -> Unit, onCopyExpr: () -> Unit, onCopyResult: () -> Unit,
    onRecalc: () -> Unit, onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    val z = Fmt.at(e.timestamp)
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) cs.primaryContainer else cs.surfaceContainerLow)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(start = 16.dp, top = 12.dp, bottom = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selecting) { Checkbox(checked = selected, onCheckedChange = null); Spacer(Modifier.width(12.dp)) }
        Column(Modifier.weight(1f)) {
            Text(e.expression, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("= " + Fmt.num(e.result), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Column(Modifier.padding(start = 8.dp), horizontalAlignment = Alignment.End) {
            Text(Fmt.time(z.toLocalTime(), s), style = MaterialTheme.typography.labelLarge)
            if (showDate) Text(Fmt.date(z.toLocalDate(), s), style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
            if (e.calculatorMode == "SCIENTIFIC") Text("SCI", style = MaterialTheme.typography.labelSmall, color = cs.primary)
        }
        if (!selecting) {
            Box {
                IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, "Entry actions") }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem({ Text("Copy expression") }, { menu = false; onCopyExpr() }, leadingIcon = { Icon(Icons.Default.ContentCopy, null) })
                    DropdownMenuItem({ Text("Copy result") }, { menu = false; onCopyResult() }, leadingIcon = { Icon(Icons.Default.ContentCopy, null) })
                    DropdownMenuItem({ Text("Recalculate") }, { menu = false; onRecalc() }, leadingIcon = { Icon(Icons.Default.Replay, null) })
                    DropdownMenuItem({ Text("Delete this entry") }, { menu = false; onDelete() }, leadingIcon = { Icon(Icons.Default.Delete, null) })
                }
            }
        } else Spacer(Modifier.width(12.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RangeDialog(from: LocalDate?, to: LocalDate?, onDismiss: () -> Unit, onOk: (LocalDate, LocalDate) -> Unit) {
    fun ms(d: LocalDate?) = d?.atStartOfDay(ZoneOffset.UTC)?.toInstant()?.toEpochMilli()
    fun day(ms: Long) = java.time.Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()   // picker values are UTC midnight
    val st = rememberDateRangePickerState(initialSelectedStartDateMillis = ms(from), initialSelectedEndDateMillis = ms(to))
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(enabled = st.selectedStartDateMillis != null, onClick = {
                val a = day(st.selectedStartDateMillis!!)
                val b = st.selectedEndDateMillis?.let { day(it) } ?: a
                onOk(a, b)
            }) { Text("Apply") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    ) { DateRangePicker(state = st, modifier = Modifier.height(500.dp)) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimeDialog(title: String, initMin: Int, is24h: Boolean, onDismiss: () -> Unit, onOk: (Int) -> Unit) {
    val st = rememberTimePickerState(initMin / 60, initMin % 60, is24h)
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) }, text = { TimePicker(state = st) },
        confirmButton = { TextButton({ onOk(st.hour * 60 + st.minute) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}
