package com.example.calculatorpro.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

val SORT_LABELS = listOf("Newest first", "Oldest first", "Largest result first", "Smallest result first")
val RETENTION_DAYS = listOf(0, 30, 90, 365)
val RETENTION_LABELS = listOf("Keep forever", "30 days", "90 days", "1 year")

class AppSettings(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("calculator_pro_settings", Context.MODE_PRIVATE)

    var autoSave by mutableStateOf(sp.getBoolean("autoSave", true))
        private set
    var defaultSort by mutableStateOf(sp.getInt("defaultSort", 0))
        private set
    var use24h by mutableStateOf(sp.getBoolean("use24h", android.text.format.DateFormat.is24HourFormat(ctx)))
        private set
    var dateStyle by mutableStateOf(sp.getInt("dateStyle", 0))   // 0 = system locale, 1 dd/MM/yyyy, 2 MM/dd/yyyy, 3 ISO
        private set
    var retentionDays by mutableStateOf(sp.getInt("retentionDays", 0)) // 0 = keep forever (default)
        private set
    var guest by mutableStateOf(sp.getBoolean("guest", false))
        private set

    fun updateGuest(v: Boolean) { guest = v; sp.edit().putBoolean("guest", v).apply() }
    fun updateAutoSave(v: Boolean) { autoSave = v; sp.edit().putBoolean("autoSave", v).apply() }
    fun updateDefaultSort(v: Int) { defaultSort = v; sp.edit().putInt("defaultSort", v).apply() }
    fun updateUse24h(v: Boolean) { use24h = v; sp.edit().putBoolean("use24h", v).apply() }
    fun updateDateStyle(v: Int) { dateStyle = v; sp.edit().putInt("dateStyle", v).apply() }
    fun updateRetention(v: Int) { retentionDays = v; sp.edit().putInt("retentionDays", v).apply() }
}
