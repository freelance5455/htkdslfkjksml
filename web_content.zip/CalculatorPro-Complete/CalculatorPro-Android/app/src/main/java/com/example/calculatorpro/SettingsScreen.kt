package com.example.calculatorpro

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.calculatorpro.data.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: MainViewModel, onBack: () -> Unit) {
    val s = vm.settings
    val total by vm.total.collectAsState()
    var confirmClear by remember { mutableStateOf(false) }
    var pendingRetention by remember { mutableStateOf<Int?>(null) }
    val today = LocalDate.now()
    val scope = rememberCoroutineScope()
    val userState by vm.user.collectAsState()
    val u = userState
    var logoutAsk by remember { mutableStateOf(false) }
    var forceAsk by remember { mutableStateOf(false) }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text("History settings") },
            navigationIcon = { IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
        )
    }) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!vm.cloud) {
                        Text("Cloud sync is off in this test build", style = MaterialTheme.typography.titleMedium)
                        Text("History is stored only on this device. Add google-services.json and rebuild to enable Google / email login and cloud history.", style = MaterialTheme.typography.bodySmall)
                    } else if (u != null) {
                        Text("Signed in", style = MaterialTheme.typography.labelMedium)
                        Text(u.email ?: u.displayName ?: "Account", style = MaterialTheme.typography.titleMedium)
                        Text("Your history is synced to this account. After logging out, sign in again with the same account to get all of it back.", style = MaterialTheme.typography.bodySmall)
                        OutlinedButton({ logoutAsk = true }) { Text("Log out") }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            SwitchRow(
                "Save history automatically",
                if (s.autoSave) "Every completed calculation is saved."
                else "OFF — new calculations will NOT be stored. Existing history is kept.",
                s.autoSave
            ) { s.updateAutoSave(it) }
            DropdownRow("Default sorting", SORT_LABELS[s.defaultSort], SORT_LABELS) { vm.setDefaultSort(it) }
            SwitchRow("24-hour time", "Now: " + Fmt.time(LocalTime.now(), s), s.use24h) { s.updateUse24h(it) }
            DropdownRow("Date format", Fmt.dateWith(s.dateStyle, today), (0..3).map { Fmt.dateWith(it, today) }) { s.updateDateStyle(it) }
            DropdownRow(
                "Keep history for",
                RETENTION_LABELS[RETENTION_DAYS.indexOf(s.retentionDays).coerceAtLeast(0)], RETENTION_LABELS
            ) { i -> val d = RETENTION_DAYS[i]; if (d == 0) s.updateRetention(0) else pendingRetention = d }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) { Text("Clear all saved history ($total)") }
            Spacer(Modifier.height(12.dp))
            Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)) {
                Text(
                    if (u != null) "Privacy: while signed in, your history is stored on this device and in your own private cloud space (only your account can read it). No tracking or ads. Nothing is exported or shared unless you tap Share or Export."
                    else "Privacy: your history is stored only on this device. No tracking. Nothing is exported or shared unless you tap Share or Export.",
                    style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(16.dp)
                )
            }
        }
    }

    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false },
        title = { Text("Clear all history?") },
        text = { Text("All $total saved calculations will be permanently deleted" + (if (u != null) " from this phone and your account." else ".")) },
        confirmButton = { TextButton({ vm.clearAll(); confirmClear = false }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } }
    )
    if (logoutAsk) AlertDialog(
        onDismissRequest = { logoutAsk = false },
        title = { Text("Log out?") },
        text = { Text("Your history stays saved in your account. This phone's copy is removed. Sign in again with the same account to get everything back.") },
        confirmButton = { TextButton({ logoutAsk = false; scope.launch { if (!vm.logout(false)) forceAsk = true } }) { Text("Log out") } },
        dismissButton = { TextButton({ logoutAsk = false }) { Text("Cancel") } }
    )
    if (forceAsk) AlertDialog(
        onDismissRequest = { forceAsk = false },
        title = { Text("Some entries aren't synced yet") },
        text = { Text("Connect to the internet and try again. If you log out now, entries that were not uploaded will be lost.") },
        confirmButton = { TextButton({ forceAsk = false; scope.launch { vm.logout(true) } }) { Text("Log out anyway", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton({ forceAsk = false }) { Text("Cancel") } }
    )
    pendingRetention?.let { d ->
        AlertDialog(
            onDismissRequest = { pendingRetention = null },
            title = { Text("Enable auto-delete?") },
            text = { Text("Calculations older than $d days will be permanently deleted automatically. Older history is only removed because you chose this.") },
            confirmButton = { TextButton({ s.updateRetention(d); vm.applyRetention(); pendingRetention = null }) { Text("Enable") } },
            dismissButton = { TextButton({ pendingRetention = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) }, supportingContent = { Text(sub) },
        trailingContent = { Switch(checked, onChange) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable { onChange(!checked) }
    )
}

@Composable
private fun DropdownRow(title: String, value: String, options: List<String>, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        ListItem(
            headlineContent = { Text(title) }, supportingContent = { Text(value) },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
            modifier = Modifier.clickable { open = true }
        )
        DropdownMenu(open, { open = false }) {
            options.forEachIndexed { i, o -> DropdownMenuItem({ Text(o) }, { onPick(i); open = false }) }
        }
    }
}
