package com.example.calculatorpro.currency

import android.content.Context
import androidx.room.*
import androidx.room.migration.Migration
import kotlinx.coroutines.flow.Flow

/** Cached provider tables: key "latest" or "YYYY-MM-DD". Past dates never change, so they are cached for good. */
@Entity(tableName = "rate_cache")
data class RateRow(@PrimaryKey val cacheKey: String, val json: String, val provider: String, val fetchedAt: Long)

@Entity(tableName = "conversions", indices = [Index(value = ["timestamp"])])
data class ConversionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromCode: String, val toCode: String,
    val amount: String, val result: String, val rate: String,
    val provider: String, val rateDate: String, val fetchedAt: Long,
    val kind: String,        // LATEST | HISTORICAL
    val freshness: String,   // FRESH | CACHED
    val viaUsd: Boolean,
    val timestamp: Long      // when the user converted (epoch millis, shown in local time)
)

@Dao
interface CurrencyDao {
    @Query("SELECT * FROM rate_cache WHERE cacheKey = :k") suspend fun getRate(k: String): RateRow?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putRate(r: RateRow)

    @Insert suspend fun insert(c: ConversionEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun restore(c: ConversionEntity)

    @Query(
        """SELECT * FROM conversions
           WHERE timestamp >= :fromTs AND timestamp < :toTs
             AND (:q = '' OR instr(upper(fromCode), :q) > 0 OR instr(upper(toCode), :q) > 0
                  OR instr(amount, :q) > 0 OR instr(result, :q) > 0)
           ORDER BY timestamp DESC"""
    )
    fun observe(fromTs: Long, toTs: Long, q: String): Flow<List<ConversionEntity>>

    @Delete suspend fun delete(c: ConversionEntity)
    @Query("DELETE FROM conversions") suspend fun deleteAll()
    @Query("DELETE FROM conversions WHERE timestamp >= :fromTs AND timestamp < :toTs") suspend fun deleteRange(fromTs: Long, toTs: Long)
}

/** Separate database: currency data can never interfere with the calculator history database. */
@Database(entities = [RateRow::class, ConversionEntity::class], version = 1, exportSchema = true)
abstract class CurrencyDb : RoomDatabase() {
    abstract fun dao(): CurrencyDao

    companion object {
        // Add Migration(1, 2) here when the schema changes. Never use destructive fallback.
        private val MIGRATIONS: Array<Migration> = arrayOf()
        @Volatile private var inst: CurrencyDb? = null
        fun get(ctx: Context): CurrencyDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, CurrencyDb::class.java, "currency.db")
                .addMigrations(*MIGRATIONS).build().also { inst = it }
        }
    }
}
