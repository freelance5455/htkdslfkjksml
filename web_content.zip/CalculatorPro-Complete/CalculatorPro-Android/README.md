# Calculator Pro (Kotlin + Jetpack Compose + Room)

Contents: calculator (Basic/Scientific), history with filters/search/sort/export, optional Google/email login with
cloud history, and a worldwide currency exchange system.

## Easiest way to test: "test build" (no Firebase needed)
If `app/google-services.json` does NOT exist, the app builds and runs fully local: no login screen, calculator, history
and currency exchange all work. (Currency needs internet for rates; they are cached afterwards.)

### Option A: Android Studio (computer)
Open this folder in Android Studio, let Gradle sync (use Gradle 8.9 if asked), press Run, or Build > Build APK(s).
APK: app/build/outputs/apk/debug/app-debug.apk

### Option B: free cloud build with GitHub Actions
1. Create a GitHub repository and upload this whole folder (including the hidden `.github` folder).
2. Repository > Actions > "Build APK" > Run workflow.
3. When it finishes, open the run and download the artifact "CalculatorPro-debug-apk" (a zip containing app-debug.apk).
4. Copy the APK to your phone, allow "Install unknown apps", install.

## Turn on login + cloud history (optional)
Needs `app/google-services.json` (GitHub: add its text as repository secret GOOGLE_SERVICES_JSON).
1. console.firebase.google.com -> new project -> add Android app `com.example.calculatorpro`.
2. Authentication -> Sign-in method -> enable **Email/Password** (works immediately) and **Google** (needs your debug SHA-1:
   run `gradle signingReport`, add it under Project settings -> your Android app, then download a fresh google-services.json).
3. Firestore Database -> create -> Rules:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{db}/documents {
    match /users/{uid}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
With the file present, login is mandatory, the session is kept, history is stored in Room and Firestore, a log out wipes the
phone copy, and signing in again with the same account restores everything.

## Worldwide currency exchange
Open from the calculator toolbar (currency icon) or History -> menu -> "Currency conversion history".
Tabs: Convert, Compare all, Compare multi, Historical, Chart, Favorites, History.
- Catalogue: ISO 4217 from the Android platform (java.util.Currency + Locale): codes, names, symbols, decimals,
  countries sharing a currency, flags. The platform lists ONE official currency per country.
- Rates: currency-api (fawazahmed0, CC0): 200+ currencies, DAILY indicative mid-market rates, no key, jsDelivr +
  Cloudflare Pages mirrors. Not real time. Cached in Room (currency.db); shown as OUTDATED when stale/offline.
- Cross rates are computed through USD and flagged "via USD". Missing pairs are reported, never invented.
- Charts: ECB reference rates via Frankfurter (v1, deprecated but working) for about 30 major currencies, back to 1999;
  other pairs use real daily snapshots only from 2024-03-02. No 1D chart (daily data only).
- All money maths is BigDecimal, rounded per currency decimals. Doubles are only used to draw the chart.
- Conversions are saved automatically 1.5 s after you stop typing, in a separate table.
- Not included: Unit Converter, GST and EMI calculators (they were never built in this project).

## Tests
`gradle test` runs CoreTests (parser, date/time filters) and CurrencyCoreTests (maths, cross rates, rounding, catalogue, search).
