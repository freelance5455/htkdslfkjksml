(function(){
  const key='vennRubik.expert';
  const legacyKey='mindOrbit.vennRubik.expert';

  window.VennRubikStorage={
    load(){
      try{
        const value=localStorage.getItem(key)||localStorage.getItem(legacyKey);
        if(!value)return null;

        const state=JSON.parse(value);
        if(!localStorage.getItem(key)){
          localStorage.setItem(key,value);
          localStorage.removeItem(legacyKey);
        }
        return state;
      }catch(error){
        return null;
      }
    },
    save(state){
      try{
        localStorage.setItem(key,JSON.stringify(state));
      }catch(error){}
    },
    clear(){
      try{
        localStorage.removeItem(key);
      }catch(error){}
    }
  };
})();
