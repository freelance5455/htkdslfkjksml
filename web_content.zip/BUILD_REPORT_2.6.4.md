# Anonymoux Studios 2.6.4 — Image, Realtime, Voice Clone & Agent Patch

## Applied changes

- Image Studio default price is now 20 ANON credits per generation. A one-time runtime migration upgrades a stored legacy default of 10 to 20 while preserving other Admin-selected values.
- Realtime Studio default price is now 10 ANON credits per provider-billed active second. The app forces server-signaled Decart sessions for this flow, stores the provider's billed seconds, charges with a unique idempotent ledger reference, and records unpaid measured usage for retry after wallet top-up. A browser timer is never used as a billing source. If Decart does not return billed seconds, the app does not estimate a charge.
- Voice cloning now charges the configured clone price before provider model creation. Confirmed failures are refunded idempotently; uncertain provider outcomes remain marked for review rather than silently granting an unpaid clone.
- AI Agent session starts are serialized in the browser to avoid duplicate provider sessions. Incomplete provider session IDs are rejected before local persistence. Agent credits-per-USD defaults to zero for new installs until Admin explicitly enables conversion; measured provider usage reconciliation remains in place.
- Admin workspace price saving now uses the appropriate SQLite/MySQL upsert syntax.
- Pricing and workspace implementation notes updated.

## Verification performed

- PHP syntax: all PHP files passed `php -l`.
- JavaScript syntax: `assets/app.js`, `assets/agent-chat.js`, and `assets/voice-studio.js` passed `node --check`.
- All existing `tests/*check.py` scripts passed.
- SQLite wallet reservation/refund contract tests passed using the Python SQLite test harness.
- ZIP archive integrity checked after packaging.

## Not tested in this build environment

- PHP PDO SQLite runtime integration: this build container's PHP CLI does not have the PDO SQLite extension enabled.
- Live Decart session creation/deletion and whether the production API returns `billed_seconds` in the response for the configured account.
- Live Fish Audio voice cloning, AI Agent voice/chat sessions, and provider usage settlement.
- Deployment behavior on the user's InfinityFree account.

Before production use, back up the live database, `storage/`, and private configuration. Preserve `config.local.php` and provider credentials when uploading. Verify the first Realtime session with a small controlled duration and inspect the resulting wallet ledger and `realtime_credit_usage` row.
