BOUBA SERVICES — VERSION ENRICHIE BS 3.0

Application mobile-first pour les services informatiques, réseaux et sécurité électronique.
Ouvrir index.html pour aperçu local (certaines fonctions PWA nécessitent HTTPS).
Consulter GUIDE_APK_ANDROID.txt pour l'installation et la préparation Android.
Cette archive ZIP n'est pas un fichier APK.
