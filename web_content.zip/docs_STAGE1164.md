# CPLS Stage 1164 — Read-Only ERC-20 Contract Interface

- Network: Ethereum Sepolia, Chain ID 11155111.
- Contract address intentionally remains empty until the real Sepolia deployment is verified.
- Added a native read-only CPLS ERC-20 interface boundary.
- Supported read methods: `balanceOf(address)`, `decimals()`, `name()`, `symbol()`.
- The app only prepares standard `eth_call` payloads; it does not sign or broadcast transactions.
- Transfer, approve, mint, burn and admin capabilities are explicitly unavailable in this stage.
- WebView receives capability/state only and never receives a private key or seed.
- No mainnet fallback is permitted.
- This stage does not claim a live Sepolia contract call because the environment does not provide a verified deployed CPLS address/network test.

## Security boundary
The contract address must be filled only after an independently verified Sepolia deployment. A wallet address supplied to `balanceOf` is validated as a 20-byte EVM address. Arbitrary RPC methods are not exposed by this interface.
