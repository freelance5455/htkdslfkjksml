# Number Connect – APK

## Obtenir l'APK (sans rien installer)

1. Créez un dépôt GitHub (gratuit) et envoyez-y tout le contenu de ce dossier,
   y compris le dossier caché `.github`.
   (Si `.github` n'est pas envoyé : « Add file » > « Create new file », nom
   `.github/workflows/build-apk.yml`, puis collez le contenu du fichier.)
2. Onglet **Actions** > **Build APK** > **Run workflow**.
3. Après 3 à 5 minutes, ouvrez l'exécution terminée et téléchargez
   **Number-Connect-apk** (un zip contenant `app-debug.apk`).
4. Copiez l'APK sur le téléphone, ouvrez-le et autorisez l'installation
   depuis des sources inconnues.

## Modifier le jeu
Éditez `www/index.html`, puis relancez le workflow.

## Compiler en local (Android Studio)
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android
