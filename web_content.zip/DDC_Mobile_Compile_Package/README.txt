DDC SMART CLASSIFIER - ANDROID STUDIO PROJECT

This is a WebView-based Android app project with a colorful mobile interface and an in-app Gemini API Key Settings panel. The API key is entered by the user and stored in the app's local WebView storage on that device; it is not hard-coded into the HTML source.

API KEY SETUP
1. On your phone or in the app, open Google AI Studio: https://aistudio.google.com/app/apikey
2. Sign in and create an API key, subject to Google's terms and availability. Keep it private.
3. Open DDC Smart Classifier, paste the key in Gemini API Key Settings, and tap Save API Key on This Device.
4. Internet access is required for AI classification.

SECURITY NOTE
This is a local-device convenience, not a secure server-side secret store. A determined user or a compromised device may be able to access an API key stored in app/web storage. Do not distribute a public APK with your personal key saved inside it. For a public/shared deployment, use a secure backend that holds the key server-side and applies quotas/authentication.

BUILD APK
1. Install Android Studio on a computer.
2. Extract this ZIP and open the DDC_Android_App folder in Android Studio.
3. Install the Android SDK requested by Gradle and allow Gradle sync.
4. Select Build > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

This package contains source code, not a compiled APK. This environment does not have Android SDK or Gradle installed, so an APK could not be compiled and tested here.
