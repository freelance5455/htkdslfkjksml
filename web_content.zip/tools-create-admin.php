<?php
declare(strict_types=1);
/**
 * One-time administrator provisioning. CLI only; never expose this endpoint over HTTP.
 * Usage: ANONYMOUX_ADMIN_PASSWORD='strong-password' php tools-create-admin.php admin@example.com "Admin Name"
 * If the environment variable is omitted, enter the password on STDIN.
 */
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found\n"); }
require_once __DIR__ . '/app/auth.php';
$email = strtolower(trim((string)($argv[1] ?? '')));
$name = trim((string)($argv[2] ?? ''));
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $name === '' || strlen($name) > 100) {
    fwrite(STDERR, "Usage: ANONYMOUX_ADMIN_PASSWORD='...' php tools-create-admin.php admin@example.com \"Admin Name\"\n");
    exit(2);
}
$password = (string)(getenv('ANONYMOUX_ADMIN_PASSWORD') ?: '');
if ($password === '') {
    fwrite(STDOUT, "Administrator password (input is visible): ");
    $password = trim((string)fgets(STDIN));
}
if (strlen($password) < 12 || strlen($password) > 200) {
    fwrite(STDERR, "Password must be between 12 and 200 characters.\n");
    exit(2);
}
auth_schema();
$pdo = db();
$sqlite = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
try {
    if ($sqlite) $pdo->exec('BEGIN IMMEDIATE'); else $pdo->beginTransaction();
    $lock = $pdo->prepare('SELECT id FROM admin_bootstrap_lock WHERE id=1' . ($sqlite ? '' : ' FOR UPDATE'));
    $lock->execute();
    $count = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn();
    if ($count > 0) throw new RuntimeException('An administrator already exists. Use tools-recover-admin.php only for a verified account recovery.');
    $q = $pdo->prepare('INSERT INTO users(name,email,password_hash,role,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
    $now = now_sql();
    $q->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), 'admin', 'active', $now, $now]);
    if ($sqlite) $pdo->exec('COMMIT'); else $pdo->commit();
    fwrite(STDOUT, "Administrator account created for {$email}. Sign in through the normal login page.\n");
} catch (Throwable $e) {
    if ($sqlite) { try { $pdo->exec('ROLLBACK'); } catch (Throwable $ignored) {} }
    elseif ($pdo->inTransaction()) $pdo->rollBack();
    fwrite(STDERR, $e->getMessage() . "\n");
    exit(1);
}
