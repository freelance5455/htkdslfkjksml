# PDF Viewer – Android Project

**Create By Nirbhay Rajput**

यह Android Studio source project है। इसमें PDF चुनने के लिए Android file picker, PDF.js आधारित reader, page navigation, zoom, rotate, recent list, favorites, dark mode और share UI शामिल हैं।

## APK कैसे बनाएँ
1. Android Studio में इस folder को Open करें।
2. Gradle sync पूरा होने दें (Android Gradle Plugin 8.7.3 और SDK 35 चाहिए)।
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)` चुनें।
4. APK `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

## महत्वपूर्ण सीमाएँ
- इस runtime में Android SDK/Gradle उपलब्ध नहीं था, इसलिए यहाँ APK compile नहीं किया जा सका। यह Android Studio में build होने वाला source project है, तैयार APK नहीं।
- PDF.js CDN से लोड होता है; पहली बार PDF render करने के लिए इंटरनेट चाहिए। पूरी तरह offline reader के लिए PDF.js files को assets में bundle करना होगा।
- Merge/split/compress/translate/password protection, OCR और multi-page scan जैसे बड़े tools अभी इस MVP में implement नहीं हैं। UI/reader आधार तैयार है; इन्हें अलग-अलग tested modules के रूप में जोड़ना होगा।
- Logo के लिए exact user-provided image इस build workspace में उपलब्ध नहीं थी। `app/src/main/assets/` में आपकी original logo image `logo.png` के नाम से रखने के बाद header/splash/icon में जोड़ें; generic logo से replace नहीं किया गया है।
