# v1.62.27 — Troféus nas Ligas

- Exibe os arquivos de troféus já presentes no jogo nas telas das competições correspondentes: Série A, Série B, Sub-20 e Premier League.
- A tela da Série C recebeu espaço próprio para o troféu, mas o pacote-base não continha uma imagem oficial da Série C; o jogo informa isso claramente e não reutiliza uma taça de outra competição.
- A exibição é local, sem depender de internet.
- Nenhuma regra de competição, tabela, calendário, elenco, ID de clube ou save foi alterada.
