package com.zingo.app;

import android.Manifest;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean alarmMode = false;       // true while this screen is shown because an alarm is ringing
    private boolean wasLocked = false;       // phone was locked when the alarm screen came up
    private boolean waitingNotif = false;    // notification permission dialog is open

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        applyAlarmFlags(getIntent());                                  // before the window is shown
        setBars(AlarmStore.prefs(this).getBoolean("bars_light", true));

        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.WHITE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("window.checkNative&&checkNative()", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            waitingNotif = true;
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        waitingNotif = false;
    }

    private void toastFa(String t) {
        android.widget.Toast.makeText(this, t, android.widget.Toast.LENGTH_LONG).show();
    }

    /**
     * Opens the settings page of the first missing alarm permission (overlay -> full-screen -> battery).
     * Automatically each of them is asked only once; the button in Settings asks again every time.
     */
    private boolean nextPermission(boolean manual) {
        android.content.SharedPreferences pr = AlarmStore.prefs(this);
        try {
            if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this) && (manual || !pr.getBoolean("ask_overlay", false))) {
                pr.edit().putBoolean("ask_overlay", true).apply();
                toastFa("۱) «نمایش روی سایر برنامه‌ها» رو برای Zingo روشن کن");
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                return true;
            }
            if (Build.VERSION.SDK_INT >= 34) {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (!nm.canUseFullScreenIntent() && (manual || !pr.getBoolean("ask_fsi", false))) {
                    pr.edit().putBoolean("ask_fsi", true).apply();
                    toastFa("۲) «اعلان تمام‌صفحه» رو برای Zingo روشن کن");
                    startActivity(new Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", Uri.parse("package:" + getPackageName())));
                    return true;
                }
            }
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (Build.VERSION.SDK_INT >= 23 && !pm.isIgnoringBatteryOptimizations(getPackageName()) && (manual || !pr.getBoolean("ask_bat", false))) {
                pr.edit().putBoolean("ask_bat", true).apply();
                toastFa("۳) «اجازه بده» رو بزن تا باتری آلارم رو نبنده");
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                return true;
            }
        } catch (Exception ignored) {
        }
        if (manual) toastFa("✅ همه اجازه‌ها داده شده");
        return false;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        applyAlarmFlags(intent);
        if (webView != null) webView.evaluateJavascript("window.checkNative&&checkNative()", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!waitingNotif && !AlarmService.isRinging()) nextPermission(false);   // one by one, each asked once
        if (webView != null) webView.evaluateJavascript("window.checkNative&&checkNative()", null);
    }

    /** Show over the lock screen and switch the screen on while an alarm is ringing. */
    private void applyAlarmFlags(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("zingo_alarm", false) || !AlarmService.isRinging()) return;
        KeyguardManager km = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        wasLocked = km != null && km.isKeyguardLocked();
        alarmMode = true;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void clearAlarmFlags() {
        if (!alarmMode) return;
        alarmMode = false;
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(false);
            setTurnScreenOn(false);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                    | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                    | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (wasLocked) moveTaskToBack(true);                          // back to the lock screen
        wasLocked = false;
    }

    private void setBars(boolean light) {
        int c = light ? android.graphics.Color.WHITE : android.graphics.Color.rgb(14, 10, 36);
        getWindow().setStatusBarColor(c);
        getWindow().setNavigationBarColor(c);
        if (Build.VERSION.SDK_INT >= 23) {
            int f = getWindow().getDecorView().getSystemUiVisibility();
            f = light ? (f | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            if (Build.VERSION.SDK_INT >= 26)
                f = light ? (f | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR) : (f & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
            getWindow().getDecorView().setSystemUiVisibility(f);
        }
    }

    /** Functions the web page can call as Android.xxx(...) */
    public class Bridge {
        @JavascriptInterface
        public boolean isNative() {
            return true;
        }

        @JavascriptInterface
        public void setSchedule(String json) {
            AlarmStore.setSchedule(getApplicationContext(), json);
        }

        @JavascriptInterface
        public String getRinging() {
            String r = AlarmService.ringingJson;
            return r == null ? "" : r;
        }

        @JavascriptInterface
        public void stopAlarm() {
            AlarmService.ringingJson = null;
            AlarmStore.clearRinging(getApplicationContext());
            Intent i = new Intent(getApplicationContext(), AlarmService.class);
            i.setAction(AlarmService.ACTION_STOP);
            getApplicationContext().startService(i);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    clearAlarmFlags();
                }
            });
        }

        @JavascriptInterface
        public void stopSound() {
            AlarmService.silence(getApplicationContext());
        }

        @JavascriptInterface
        public String takeFired() {
            return AlarmStore.takeFired(getApplicationContext());
        }

        @JavascriptInterface
        public void ackFired(String id) {
            AlarmStore.ackFired(getApplicationContext(), id);
        }

        @JavascriptInterface
        public void setBars(final boolean light) {
            AlarmStore.prefs(getApplicationContext()).edit().putBoolean("bars_light", light).apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MainActivity.this.setBars(light);
                }
            });
        }

        @JavascriptInterface
        public void openAlarmSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    nextPermission(true);
                }
            });
        }

        @JavascriptInterface
        public void openBatterySettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    nextPermission(true);
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (AlarmService.isRinging()) return;                          // the alarm must be solved / stopped first
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
