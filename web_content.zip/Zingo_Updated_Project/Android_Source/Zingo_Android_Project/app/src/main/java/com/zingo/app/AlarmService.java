package com.zingo.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import org.json.JSONObject;

/**
 * Plays the alarm sound on the ALARM audio stream, vibrates, and raises a full-screen
 * notification so the alarm screen appears over the lock screen (like the phone's clock app).
 */
public class AlarmService extends Service {
    static final String CHANNEL = "zingo_alarm_v1";
    static final int NOTIF_ID = 4242;
    static final String ACTION_STOP = "com.zingo.app.STOP";

    /** JSON of the alarm that is ringing right now (null = silent). Read by the web page. */
    public static volatile String ringingJson = null;

    private MediaPlayer player;
    private PowerManager.WakeLock wakeLock;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;
    private int savedVolume = -1;
    private float vol = 1f;

    public static boolean isRinging() {
        return ringingJson != null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopRinging();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && "com.zingo.app.SILENCE".equals(intent.getAction())) {
            releasePlayerOnly();                                // web page plays a custom sound itself
            return START_NOT_STICKY;
        }
        String json = intent != null ? intent.getStringExtra("ev") : null;
        if (json == null) {
            return START_NOT_STICKY;
        }
        try {
            JSONObject ev = new JSONObject(json);
            ringingJson = json;
            ensureChannel();
            startForeground(NOTIF_ID, buildNotification(ev));
            startRinging(ev);
            // Works directly when the app is already on screen; otherwise the full-screen notification does it.
            try {
                startActivity(activityIntent());
            } catch (Exception ignored) {
            }
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private Intent activityIntent() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra("zingo_alarm", true);
        return i;
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Zingo alarms", NotificationManager.IMPORTANCE_HIGH);
                ch.setSound(null, null);                      // sound is played by this service on the alarm stream
                ch.enableVibration(false);
                ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                ch.setBypassDnd(true);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private Notification buildNotification(JSONObject ev) {
        PendingIntent pi = PendingIntent.getActivity(this, 1, activityIntent(),
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        String label = ev.optString("label", "");
        String title = label.length() > 0 ? label : "Zingo ⏰";
        String text = ev.optBoolean("plan") || ev.optInt("plan", 0) == 1 ? "📌" : ("timer".equals(ev.optString("k")) ? "⏱" : "⏰ " + ev.optString("time", ""));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        return b.build();
    }

    private void startRinging(JSONObject ev) {
        releasePlayerOnly();
        String key = ev.optString("sound", "bell");
        boolean soft = ev.optInt("plan", 0) == 1;
        boolean brain = "brain".equals(key);
        int res = getResources().getIdentifier("zingo_" + key, "raw", getPackageName());
        if (res == 0) res = getResources().getIdentifier("zingo_bell", "raw", getPackageName());

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (wakeLock == null || !wakeLock.isHeld()) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zingo:alarm");
            wakeLock.acquire(12 * 60 * 1000L);
        }

        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        try {
            // the "brain" alarm is meant to be unbearable: use the full alarm volume while it rings
            if (brain && savedVolume < 0) {
                savedVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM);
                audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
            }
        } catch (Exception ignored) {
        }

        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            player = new MediaPlayer();
            player.setAudioAttributes(attrs);
            AssetFileDescriptor afd = getResources().openRawResourceFd(res);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.setLooping(true);
            player.prepare();
            boolean ramp = ev.optInt("ramp", 1) == 1 && !soft && !"timer".equals(ev.optString("k"));
            vol = ramp ? (brain ? 0.6f : 0.3f) : 1f;
            player.setVolume(vol, vol);
            player.start();
            if (ramp) rampUp();
        } catch (Exception ignored) {
        }

        if (ev.optInt("vib", 1) == 1 && !soft) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] pat = brain ? new long[]{0, 300, 100, 300, 100, 300, 100, 900, 150}
                               : new long[]{0, 400, 150, 400, 700};
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createWaveform(pat, 0),
                            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
                } else {
                    v.vibrate(pat, 0);
                }
            } catch (Exception ignored) {
            }
        }

        handler.removeCallbacksAndMessages(null);
        // give up after a while, like the normal clock app (soft reminders / timers: 2 min, alarms: 10 min)
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopRinging();
                stopForeground(true);
                stopSelf();
            }
        }, soft || "timer".equals(ev.optString("k")) ? 120000L : 600000L);
    }

    private void rampUp() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (player == null) return;
                vol = Math.min(1f, vol + 0.07f);
                try {
                    player.setVolume(vol, vol);
                } catch (Exception ignored) {
                }
                if (vol < 1f) handler.postDelayed(this, 2000);
            }
        }, 2000);
    }

    private void releasePlayerOnly() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
    }

    private void stopRinging() {
        ringingJson = null;
        handler.removeCallbacksAndMessages(null);
        releasePlayerOnly();
        try {
            ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).cancel();
        } catch (Exception ignored) {
        }
        try {
            if (savedVolume >= 0 && audio != null) audio.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0);
        } catch (Exception ignored) {
        }
        savedVolume = -1;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
    }

    /** Only the sound stops (used when the web page wants to play a custom sound file itself). */
    public static void silence(Context c) {
        Intent i = new Intent(c, AlarmService.class);
        i.setAction("com.zingo.app.SILENCE");
        c.startService(i);
    }

    @Override
    public void onDestroy() {
        stopRinging();
        super.onDestroy();
    }
}
