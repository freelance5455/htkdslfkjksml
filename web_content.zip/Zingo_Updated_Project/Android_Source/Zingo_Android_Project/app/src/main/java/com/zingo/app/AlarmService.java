package com.zingo.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.audiofx.LoudnessEnhancer;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

import org.json.JSONObject;

/**
 * Plays the alarm on the ALARM audio stream, vibrates, wakes the screen and raises a full-screen
 * notification so the alarm screen appears over the lock screen.
 * The alarm only ends when the web page calls Android.stopAlarm() (after the user solved / dismissed it)
 * or after the safety timeout. Closing the app from the recents list does NOT stop it.
 */
public class AlarmService extends Service {
    static final String CHANNEL = "zingo_alarm_v1";
    static final int NOTIF_ID = 4242;
    static final int NOTIF_ID_REPOST = 4243;
    static final String ACTION_STOP = "com.zingo.app.STOP";
    static final String ACTION_SILENCE = "com.zingo.app.SILENCE";

    /** JSON of the alarm that is ringing right now (null = silent). Read by the web page. */
    public static volatile String ringingJson = null;

    private MediaPlayer player;
    private LoudnessEnhancer enhancer;
    private PowerManager.WakeLock wakeLock, screenLock;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audio;
    private int savedVolume = -1;
    private float vol = 1f;
    private boolean brain = false;
    private boolean loud = false;            // every real alarm / timer rings at full alarm volume (soft plan reminders don't)

    public static boolean isRinging() {
        return ringingJson != null;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopRinging();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null && ACTION_SILENCE.equals(intent.getAction())) {
            releasePlayerOnly();                                // web page plays a custom sound itself
            return START_NOT_STICKY;
        }
        String json = intent != null ? intent.getStringExtra("ev") : null;
        if (json == null) {
            // restarted by the system after the process was killed: continue the alarm that was ringing
            json = AlarmStore.prefs(this).getString("ringing", null);
            if (json == null) {
                stopSelf();
                return START_NOT_STICKY;
            }
        }
        try {
            JSONObject ev = new JSONObject(json);
            boolean already = json.equals(ringingJson) && player != null;
            ringingJson = json;
            AlarmStore.prefs(this).edit().putString("ringing", json).apply();
            ensureChannel();
            startForeground(NOTIF_ID, buildNotification(ev));
            if (!already) {
                startRinging(ev);
            }
            wakeScreen();
            // Works directly when the app is already on screen; otherwise the full-screen notification does it.
            try {
                startActivity(activityIntent());
            } catch (Exception ignored) {
            }
        } catch (Exception e) {
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;                                    // come back if the system kills us while ringing
    }

    /** The user swiped the app away from the recents list: keep ringing, bring the alarm back. */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (isRinging()) {
            try {
                // 1) in case the whole process gets killed: wake up again in ~1.5 s
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                PendingIntent showPi = PendingIntent.getActivity(this, 7, new Intent(this, MainActivity.class), AlarmStore.flags());
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 1500, showPi),
                        AlarmStore.firePi(this, "resume"));
            } catch (Exception ignored) {
            }
            try {
                // 2) show the alarm screen again (full-screen notification + direct start)
                ensureChannel();
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                nm.notify(NOTIF_ID_REPOST, buildNotification(new JSONObject(ringingJson)));
                wakeScreen();
                startActivity(activityIntent());
            } catch (Exception ignored) {
            }
        }
        super.onTaskRemoved(rootIntent);
    }

    private Intent activityIntent() {
        Intent i = new Intent(this, MainActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        i.putExtra("zingo_alarm", true);
        return i;
    }

    private void ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CHANNEL) == null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL, "Zingo alarms", NotificationManager.IMPORTANCE_HIGH);
                ch.setSound(null, null);                      // sound is played by this service on the alarm stream
                ch.enableVibration(false);
                ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
                ch.setBypassDnd(true);
                nm.createNotificationChannel(ch);
            }
        }
    }

    private Notification buildNotification(JSONObject ev) {
        PendingIntent pi = PendingIntent.getActivity(this, 1, activityIntent(),
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        String label = ev.optString("label", "");
        String title = label.length() > 0 ? label : "Zingo ⏰";
        String text = ev.optInt("plan", 0) == 1 ? "📌" : ("timer".equals(ev.optString("k")) ? "⏱" : "⏰ " + ev.optString("time", ""));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setOngoing(true)
                .setAutoCancel(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setContentIntent(pi)
                .setFullScreenIntent(pi, true);
        if (Build.VERSION.SDK_INT < 26) b.setPriority(Notification.PRIORITY_MAX);
        return b.build();
    }

    /** Turn the screen on even if the full-screen notification is delayed or blocked. */
    @SuppressWarnings("deprecation")
    private void wakeScreen() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (screenLock != null && screenLock.isHeld()) screenLock.release();
            screenLock = pm.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE, "zingo:screen");
            screenLock.acquire(20000L);
        } catch (Exception ignored) {
        }
    }

    private void maxAlarmVolume() {
        try {
            if (audio == null) return;
            if (savedVolume < 0) savedVolume = audio.getStreamVolume(AudioManager.STREAM_ALARM);
            audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
        } catch (Exception ignored) {
        }
    }

    private void startRinging(final JSONObject ev) {
        releasePlayerOnly();
        String key = ev.optString("sound", "bell");
        final boolean soft = ev.optInt("plan", 0) == 1;
        brain = "brain".equals(key);
        loud = !soft;
        int res = getResources().getIdentifier("zingo_" + key, "raw", getPackageName());
        if (res == 0) res = getResources().getIdentifier("zingo_bell", "raw", getPackageName());

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (wakeLock == null || !wakeLock.isHeld()) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "zingo:alarm");
            wakeLock.acquire(12 * 60 * 1000L);
        }

        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (loud) maxAlarmVolume();                               // alarms always ring at full alarm volume, even if the phone is set quiet

        try {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build();
            player = new MediaPlayer();
            player.setAudioAttributes(attrs);
            AssetFileDescriptor afd = getResources().openRawResourceFd(res);
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            player.setLooping(true);
            player.prepare();
            boolean ramp = ev.optInt("ramp", 1) == 1 && !soft && !brain && !"timer".equals(ev.optString("k"));
            vol = ramp ? 0.8f : 1f;                          // gradual volume starts already loud
            player.setVolume(vol, vol);
            if (loud) {
                try {                                             // boost beyond the normal maximum (brain +15 dB, others +7 dB)
                    enhancer = new LoudnessEnhancer(player.getAudioSessionId());
                    enhancer.setTargetGain(brain ? 1500 : 700);
                    enhancer.setEnabled(true);
                } catch (Exception ignored) {
                }
            }
            player.start();
            if (ramp) rampUp();
        } catch (Exception ignored) {
        }

        if (ev.optInt("vib", 1) == 1 && !soft) {
            Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            long[] pat = brain ? new long[]{0, 300, 100, 300, 100, 300, 100, 900, 150}
                               : new long[]{0, 400, 150, 400, 700};
            try {
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createWaveform(pat, 0),
                            new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
                } else {
                    v.vibrate(pat, 0);
                }
            } catch (Exception ignored) {
            }
        }

        handler.removeCallbacksAndMessages(null);
        if (loud) keepLoud();
        keepResumeArmed();
        // safety timeout like the normal clock app (soft reminders / timers: 2 min, alarms: 10 min)
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                stopRinging();
                stopForeground(true);
                stopSelf();
            }
        }, soft || "timer".equals(ev.optString("k")) ? 120000L : 600000L);
    }

    /** Alarm: if someone turns the volume down, put it back up. */
    private void keepLoud() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isRinging() || !loud) return;
                try {
                    if (audio != null && audio.getStreamVolume(AudioManager.STREAM_ALARM) < audio.getStreamMaxVolume(AudioManager.STREAM_ALARM)) {
                        audio.setStreamVolume(AudioManager.STREAM_ALARM, audio.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0);
                    }
                } catch (Exception ignored) {
                }
                handler.postDelayed(this, 1500);
            }
        }, 1500);
    }

    private void rampUp() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (player == null) return;
                vol = Math.min(1f, vol + 0.1f);
                try {
                    player.setVolume(vol, vol);
                } catch (Exception ignored) {
                }
                if (vol < 1f) handler.postDelayed(this, 1000);
            }
        }, 1000);
    }

    /**
     * While ringing, keep a "resume" wake-up armed a few seconds ahead. If the system kills the whole app
     * (swipe from recents on some phones), the wake-up brings the alarm back within seconds.
     */
    private void keepResumeArmed() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (!isRinging()) return;
                try {
                    AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                    PendingIntent showPi = PendingIntent.getActivity(AlarmService.this, 7, new Intent(AlarmService.this, MainActivity.class), AlarmStore.flags());
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(System.currentTimeMillis() + 5000, showPi),
                            AlarmStore.firePi(AlarmService.this, "resume"));
                } catch (Exception ignored) {
                }
                handler.postDelayed(this, 3000);
            }
        });
    }

    private void releasePlayerOnly() {
        if (enhancer != null) {
            try {
                enhancer.release();
            } catch (Exception ignored) {
            }
            enhancer = null;
        }
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            player.release();
            player = null;
        }
    }

    /** Real end of the alarm (dismissed or timed out). */
    private void stopRinging() {
        ringingJson = null;
        brain = false;
        loud = false;
        handler.removeCallbacksAndMessages(null);
        releaseAll();
        AlarmStore.clearRinging(this);
    }

    private void releaseAll() {
        releasePlayerOnly();
        try {
            ((Vibrator) getSystemService(Context.VIBRATOR_SERVICE)).cancel();
        } catch (Exception ignored) {
        }
        try {
            if (savedVolume >= 0 && audio != null) audio.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0);
        } catch (Exception ignored) {
        }
        savedVolume = -1;
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        wakeLock = null;
        if (screenLock != null && screenLock.isHeld()) screenLock.release();
        screenLock = null;
    }

    /** Only the sound stops (used when the web page wants to play a custom sound file itself). */
    public static void silence(Context c) {
        Intent i = new Intent(c, AlarmService.class);
        i.setAction(ACTION_SILENCE);
        c.startService(i);
    }

    @Override
    public void onDestroy() {
        // NOTE: do not clear the "ringing" state here - if the system destroys us while ringing we want to be restarted
        handler.removeCallbacksAndMessages(null);
        releaseAll();
        super.onDestroy();
    }
}
