package com.zingo.app;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Keeps the alarm schedule (sent from the web page) and registers it with AlarmManager. */
public class AlarmStore {
    static final String PREFS = "zingo_native";
    static final String ACTION = "com.zingo.app.ALARM";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static int flags() {
        return PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    }

    static PendingIntent firePi(Context c, String id) {
        Intent i = new Intent(c, AlarmReceiver.class);
        i.setAction(ACTION);
        i.setData(Uri.parse("zingo://alarm/" + id));
        i.putExtra("id", id);
        return PendingIntent.getBroadcast(c, id.hashCode(), i, flags());
    }

    /** Replace the whole schedule with the list sent from JS. */
    public static synchronized void setSchedule(Context c, String json) {
        try {
            cancelAll(c);
            JSONArray arr = new JSONArray(json);
            JSONArray ids = new JSONArray();
            SharedPreferences.Editor ed = prefs(c).edit();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject ev = arr.getJSONObject(i);
                String id = ev.getString("id");
                ids.put(id);
                ed.putString("ev_" + id, ev.toString());
            }
            ed.putString("ids", ids.toString()).apply();
            for (int i = 0; i < arr.length(); i++) schedule(c, arr.getJSONObject(i));
        } catch (Exception ignored) {
        }
    }

    static void cancelAll(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            JSONArray ids = new JSONArray(prefs(c).getString("ids", "[]"));
            SharedPreferences.Editor ed = prefs(c).edit();
            for (int i = 0; i < ids.length(); i++) {
                String id = ids.getString(i);
                am.cancel(firePi(c, id));
                ed.remove("ev_" + id);
            }
            ed.putString("ids", "[]").apply();
        } catch (Exception ignored) {
        }
    }

    static void schedule(Context c, JSONObject ev) {
        try {
            long at = ev.getLong("at");
            if (at < System.currentTimeMillis() - 60000) return;       // too old
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi = firePi(c, ev.getString("id"));
            if ("plan".equals(ev.optString("k"))) {
                try {
                    if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                    else am.setExact(AlarmManager.RTC_WAKEUP, at, pi);
                } catch (SecurityException e) {
                    am.set(AlarmManager.RTC_WAKEUP, at, pi);
                }
            } else {
                Intent show = new Intent(c, MainActivity.class);
                PendingIntent showPi = PendingIntent.getActivity(c, 7, show, flags());
                am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showPi), pi);
            }
        } catch (Exception ignored) {
        }
    }

    /** After boot / app update: register everything again. */
    public static void rescheduleAll(Context c) {
        try {
            JSONArray ids = new JSONArray(prefs(c).getString("ids", "[]"));
            for (int i = 0; i < ids.length(); i++) {
                String id = ids.getString(i);
                String s = prefs(c).getString("ev_" + id, null);
                if (s == null) continue;
                JSONObject ev = new JSONObject(s);
                if (ev.getLong("at") < System.currentTimeMillis() - 60000) {
                    if (!advance(c, ev)) continue;
                }
                schedule(c, ev);
            }
        } catch (Exception ignored) {
        }
    }

    /** For repeating alarms: compute the next occurrence and store it. Returns false for one-shot alarms. */
    static boolean advance(Context c, JSONObject ev) {
        try {
            if (!"alarm".equals(ev.optString("k"))) return false;
            JSONArray days = ev.optJSONArray("days");
            if (days == null || days.length() == 0) return false;
            String[] hm = ev.getString("time").split(":");
            int h = Integer.parseInt(hm[0]), m = Integer.parseInt(hm[1]);
            long now = System.currentTimeMillis() + 1000;
            for (int k = 0; k < 8; k++) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DAY_OF_YEAR, k);
                cal.set(Calendar.HOUR_OF_DAY, h);
                cal.set(Calendar.MINUTE, m);
                cal.set(Calendar.SECOND, 0);
                cal.set(Calendar.MILLISECOND, 0);
                int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;            // JS getDay(): 0 = Sunday
                boolean ok = false;
                for (int j = 0; j < days.length(); j++) if (days.getInt(j) == dow) ok = true;
                if (ok && cal.getTimeInMillis() > now) {
                    ev.put("at", cal.getTimeInMillis());
                    prefs(c).edit().putString("ev_" + ev.getString("id"), ev.toString()).apply();
                    return true;
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    // ---- one-shot alarms that fired while the web page was not running ----
    static synchronized void addFired(Context c, String aid) {
        try {
            JSONArray a = new JSONArray(prefs(c).getString("fired", "[]"));
            for (int i = 0; i < a.length(); i++) if (aid.equals(a.getString(i))) return;
            a.put(aid);
            prefs(c).edit().putString("fired", a.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static synchronized void ackFired(Context c, String aid) {
        try {
            JSONArray a = new JSONArray(prefs(c).getString("fired", "[]")), n = new JSONArray();
            for (int i = 0; i < a.length(); i++) if (!aid.equals(a.getString(i))) n.put(a.getString(i));
            prefs(c).edit().putString("fired", n.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static synchronized String takeFired(Context c) {
        String s = prefs(c).getString("fired", "[]");
        prefs(c).edit().putString("fired", "[]").apply();
        return s;
    }
}
