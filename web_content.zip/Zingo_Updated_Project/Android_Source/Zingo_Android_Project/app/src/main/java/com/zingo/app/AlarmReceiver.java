package com.zingo.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import org.json.JSONObject;

/** Fires when AlarmManager says it is time. Starts the ringing service. */
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            String id = intent.getStringExtra("id");
            if (id == null) return;
            String json = AlarmStore.prefs(ctx).getString("ev_" + id, null);
            if (json == null) return;
            JSONObject ev = new JSONObject(json);

            if ("alarm".equals(ev.optString("k"))) {
                // repeating -> register the next day now; one-shot -> remember that it fired
                if (!AlarmStore.advance(ctx, ev)) {
                    AlarmStore.addFired(ctx, String.valueOf(ev.opt("aid")));
                    AlarmStore.prefs(ctx).edit().remove("ev_" + id).apply();
                } else {
                    AlarmStore.schedule(ctx, ev);
                }
            } else {
                AlarmStore.prefs(ctx).edit().remove("ev_" + id).apply();
            }

            Intent s = new Intent(ctx, AlarmService.class);
            s.putExtra("ev", json);                                    // payload of THIS ring
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(s);
            else ctx.startService(s);
        } catch (Exception ignored) {
        }
    }
}
