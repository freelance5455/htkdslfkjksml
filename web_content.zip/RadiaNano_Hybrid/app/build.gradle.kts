plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.radianano.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.radianano.app"
        minSdk = 23
        targetSdk = 28
        versionCode = 5
        versionName = "1.5"
    }
}

dependencies {
    implementation("com.github.mik3y:usb-serial-for-android:3.8.1")
}
