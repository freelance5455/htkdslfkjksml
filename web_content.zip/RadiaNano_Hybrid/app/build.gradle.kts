plugins {
    id("com.android.application")
}

android {
    namespace = "com.radianano.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.radianano.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 9
        versionName = "2.3"
    }
}

dependencies {
    implementation("com.github.mik3y:usb-serial-for-android:3.8.1")
}
