package com.radianano.app

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var webView: WebView
    private var port: UsbSerialPort? = null
    @Volatile private var connected = false
    private val worker = Executors.newSingleThreadExecutor()
    private val permissionAction = "com.radianano.app.USB_PERMISSION"
    private val buffer = StringBuilder()

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != permissionAction) return
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                openDevice(device)
            } else {
                sendStatus("USB permission denied")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val filter = IntentFilter(permissionAction)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(permissionReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(permissionReceiver, filter)
        }

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(webView)

        // Load the bundled HTML directly from app/src/main/assets/index.html.
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun connectUsb() { runOnUiThread { findAndConnect() } }

        @JavascriptInterface
        fun disconnectUsb() { runOnUiThread { closePort(); sendStatus("Disconnected") } }
    }

    private fun findAndConnect() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            sendStatus("No USB serial device found. Check OTG cable and Arduino.")
            return
        }
        val device = drivers[0].device
        if (!usbManager.hasPermission(device)) {
            val permissionIntent = PendingIntent.getBroadcast(
                this, 0, Intent(permissionAction).setPackage(packageName),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            usbManager.requestPermission(device, permissionIntent)
        } else {
            openDevice(device)
        }
    }

    private fun openDevice(device: UsbDevice) {
        try {
            closePort()
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
                ?: throw IOException("No compatible USB serial driver")
            val connection = usbManager.openDevice(device) ?: throw IOException("Cannot open USB device")
            val serialPort = driver.ports.firstOrNull() ?: throw IOException("No serial port found")
            serialPort.open(connection)
            serialPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = serialPort
            connected = true
            sendStatus("Connected · USB Serial · 9600 baud")
            worker.execute { readLoop(serialPort) }
        } catch (error: Exception) {
            sendStatus("Connection error: ${error.message ?: "unknown error"}")
            closePort()
        }
    }

    private fun readLoop(serialPort: UsbSerialPort) {
        val bytes = ByteArray(256)
        while (connected && port === serialPort) {
            try {
                val count = serialPort.read(bytes, 1000)
                if (count > 0) {
                    val chunk = String(bytes, 0, count, Charsets.UTF_8)
                    runOnUiThread { consume(chunk) }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    sendStatus("Serial disconnected: ${error.message ?: "read error"}")
                    closePort()
                }
                break
            }
        }
    }

    private fun consume(chunk: String) {
        for (character in chunk) {
            if (character == '\n' || character == '\r') {
                val line = buffer.toString().trim()
                buffer.clear()
                if (line.isNotEmpty()) {
                    val safeLine = org.json.JSONObject.quote(line)
                    webView.evaluateJavascript("onSerialLine($safeLine)", null)
                }
            } else if (buffer.length < 200) {
                buffer.append(character)
            }
        }
    }

    private fun sendStatus(message: String) {
        if (::webView.isInitialized) {
            val safeMessage = org.json.JSONObject.quote(message)
            webView.evaluateJavascript("onStatus($safeMessage)", null)
        }
    }

    private fun closePort() {
        connected = false
        try { port?.close() } catch (_: Exception) { }
        port = null
    }

    override fun onDestroy() {
        closePort()
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) { }
        worker.shutdownNow()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
