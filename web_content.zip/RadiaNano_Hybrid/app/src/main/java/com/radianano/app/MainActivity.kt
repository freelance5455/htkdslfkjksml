package com.radianano.app

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.Manifest
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException
import java.util.concurrent.Executors
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var usbManager: UsbManager
    private lateinit var webView: WebView
    private var port: UsbSerialPort? = null
    @Volatile private var baudRate: Int = 9600
    @Volatile private var connected = false
    private val worker = Executors.newSingleThreadExecutor()
    private val permissionAction = "com.radianano.app.USB_PERMISSION"
    private val buffer = StringBuilder()
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bleScanner: BluetoothLeScanner? = null
    private var bleGatt: BluetoothGatt? = null
    private var bleNotifyCharacteristic: BluetoothGattCharacteristic? = null
    private var bleWriteCharacteristic: BluetoothGattCharacteristic? = null
    private var bleProbeOnly = false
    private var bleSelectedAddress: String? = null
    private val bleDevices = linkedMapOf<String, BluetoothDevice>()
    private val bleDeviceNames = linkedMapOf<String, String>()
    private val bleDeviceRssi = linkedMapOf<String, Int>()
    private val classicDevices = linkedMapOf<String, BluetoothDevice>()
    private val classicNames = linkedMapOf<String, String>()
    private val classicReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    @Suppress("DEPRECATION")
                    val device = intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE) ?: return
                    val name = try { device.name } catch (_: SecurityException) { null }
                    classicDevices[device.address] = device
                    classicNames[device.address] = name?.takeIf { it.isNotBlank() } ?: "Thiết bị Classic không tên"
                    publishBleDevices()
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    publishBleDevices()
                    webView.post { webView.evaluateJavascript("onBleScanFinished(${bleDevices.size + classicDevices.size})", null) }
                }
            }
        }
    }
    private val bleBuffer = StringBuilder()
    private val bleScanHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val bleScanStop = Runnable {
        stopBleScan()
        publishBleDevices()
        val total = bleDevices.size + classicDevices.keys.count { !bleDevices.containsKey(it) }
        webView.post { webView.evaluateJavascript("onBleScanFinished($total)", null) }
        if (total == 0) sendStatus("Không tìm thấy thiết bị. Kiểm tra quyền Thiết bị ở gần/Vị trí, bật Bluetooth và nhấn Làm mới.")
        else sendStatus("Đã tìm thấy $total thiết bị Bluetooth (BLE + Classic).")
    }
    private val uartServiceIds = listOf(UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e"), UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb"))
    private val uartNotifyIds = listOf(UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e"), UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb"))
    private val cccdId = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != permissionAction) return
            val device: UsbDevice? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            }
            if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false) && device != null) {
                openDevice(device)
            } else {
                sendStatus("USB permission denied")
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        bluetoothAdapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
        val classicFilter = IntentFilter().apply { addAction(BluetoothDevice.ACTION_FOUND); addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(classicReceiver, classicFilter, RECEIVER_EXPORTED) else { @Suppress("DEPRECATION") registerReceiver(classicReceiver, classicFilter) }
        val filter = IntentFilter(permissionAction)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(permissionReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(permissionReceiver, filter)
        }

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        setContentView(webView)

        // Load the bundled HTML directly from app/src/main/assets/index.html.
        webView.loadUrl("file:///android_asset/index.html")

        // If a Nano-compatible USB serial device is already attached, request access automatically.
        val attached = intent?.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
        if (intent?.action == UsbManager.ACTION_USB_DEVICE_ATTACHED && attached != null) {
            requestDevicePermission(attached)
        } else {
            findAndConnect()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == UsbManager.ACTION_USB_DEVICE_ATTACHED) {
            @Suppress("DEPRECATION")
            val device = intent.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
            if (device != null) requestDevicePermission(device)
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface
        fun connectUsb() { runOnUiThread { findAndConnect() } }

        @JavascriptInterface
        fun disconnectUsb() { runOnUiThread { closePort(); sendStatus("Disconnected") } }

        @JavascriptInterface
        fun setBaudRate(value: Int) {
            if (value in listOf(9600, 57600, 115200, 230400)) baudRate = value
        }

        @JavascriptInterface
        fun isConnected(): Boolean = connected

        @JavascriptInterface
        fun scanBle() { runOnUiThread { startBleScan() } }
        @JavascriptInterface
        fun stopBleScanFromJs() { runOnUiThread { stopBleScan() } }
        @JavascriptInterface
        fun inspectBle(address: String) { runOnUiThread { inspectBleDevice(address) } }
        @JavascriptInterface
        fun connectBle(address: String) { runOnUiThread { connectBleDevice(address) } }
        @JavascriptInterface
        fun disconnectBle() { runOnUiThread { closeBleGatt(); sendStatus("BLE disconnected") } }
        @JavascriptInterface
        fun writeUsb(text: String) { runOnUiThread { writeUsbLine(text) } }
        @JavascriptInterface
        fun writeBle(text: String) { runOnUiThread { writeBleLine(text) } }
        @JavascriptInterface
        fun vibrateAlert() {
            runOnUiThread { vibrateDevice() }
        }
    }

    private fun hasBlePermissions(): Boolean {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        return needed.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun startBleScan() {
        if (!hasBlePermissions()) {
            val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            sendStatus("Cần cấp quyền Bluetooth để quét. Hãy chọn Cho phép.")
            requestPermissions(needed, 7401)
            return
        }
        val adapter = bluetoothAdapter
        if (adapter == null) { sendStatus("Điện thoại không hỗ trợ Bluetooth."); return }
        if (!adapter.isEnabled) { sendStatus("Bluetooth đang tắt. Hãy bật Bluetooth rồi quét lại."); return }
        try {
            stopBleScan()
            bleDevices.clear()
            bleDeviceNames.clear()
            bleDeviceRssi.clear()
            classicDevices.clear()
            classicNames.clear()
            try {
                for (device in adapter.bondedDevices) {
                    try {
                        classicDevices[device.address] = device
                        classicNames[device.address] = device.name?.takeIf { it.isNotBlank() } ?: "Thiết bị Bluetooth đã ghép đôi"
                    } catch (_: SecurityException) { }
                }
                if (adapter.isDiscovering) adapter.cancelDiscovery()
                val discoveryStarted = adapter.startDiscovery()
                if (!discoveryStarted) sendStatus("Android không bắt đầu được quét Bluetooth Classic. Kiểm tra quyền Thiết bị ở gần và thử Làm mới.")
            } catch (e: Exception) { sendStatus("Không quét được Bluetooth Classic: ${e.message}") }
            webView.evaluateJavascript("onBleScanStarted()", null)
            publishBleDevices()
            bleScanner = adapter.bluetoothLeScanner
            val scanner = bleScanner
            if (scanner == null) { sendStatus("Không khởi tạo được BLE scanner. Hãy bật/tắt Bluetooth rồi thử lại."); return }
            scanner.startScan(null, ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), bleScanCallback)
            sendStatus("Đang quét BLE trong tối đa 12 giây…")
            bleScanHandler.postDelayed(bleScanStop, 12000)
        } catch (e: SecurityException) { stopBleScan(); sendStatus("Thiếu quyền BLE: ${e.message}") }
        catch (e: Exception) { stopBleScan(); sendStatus("Lỗi quét BLE: ${e.message}") }
    }

    @Suppress("DEPRECATION")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7401) {
            if (hasBlePermissions()) startBleScan()
            else sendStatus("Bạn chưa cấp đủ quyền Bluetooth. Vào Cài đặt ứng dụng > Quyền và cho phép Bluetooth/Thiết bị ở gần.")
        }
    }

    private val bleScanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            bleDevices[device.address] = device
            val advertisedName = try { result.scanRecord?.deviceName } catch (_: Exception) { null }
            val bondedName = try { device.name } catch (_: Exception) { null }
            bleDeviceNames[device.address] = advertisedName?.takeIf { it.isNotBlank() } ?: bondedName?.takeIf { it.isNotBlank() } ?: "Thiết bị BLE không tên"
            bleDeviceRssi[device.address] = result.rssi
            publishBleDevices()
        }
        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            for (result in results) onScanResult(ScanSettings.CALLBACK_TYPE_ALL_MATCHES, result)
        }
        override fun onScanFailed(errorCode: Int) {
            bleScanHandler.removeCallbacks(bleScanStop)
            stopBleScan()
            publishBleDevices()
            sendStatus("Android không thể quét BLE (mã lỗi $errorCode). Hãy bật Bluetooth, cấp quyền Thiết bị ở gần và thử lại.")
        }
    }

    private fun stopBleScan() {
        bleScanHandler.removeCallbacks(bleScanStop)
        try { bleScanner?.stopScan(bleScanCallback) } catch (_: Exception) { }
        try { bluetoothAdapter?.cancelDiscovery() } catch (_: Exception) { }
        bleScanner = null
    }

    private fun publishBleDevices() {
        if (!::webView.isInitialized) return
        val array = JSONArray()
        for ((address, _) in bleDevices) {
            val name = bleDeviceNames[address] ?: "Thiết bị BLE không tên"
            val rssi = bleDeviceRssi[address] ?: 0
            array.put(JSONObject().put("name", name).put("address", address).put("rssi", rssi).put("transport", "BLE"))
        }
        for ((address, _) in classicDevices) {
            val name = classicNames[address] ?: "Thiết bị Classic"
            if (!bleDevices.containsKey(address)) array.put(JSONObject().put("name", name).put("address", address).put("rssi", JSONObject.NULL).put("transport", "CLASSIC"))
        }
        webView.evaluateJavascript("onBleDevices(${JSONObject.quote(array.toString())})", null)
    }

    private fun inspectBleDevice(address: String) {
        if (!hasBlePermissions()) { startBleScan(); return }
        try {
            stopBleScan(); closeBleGatt()
            val device = bluetoothAdapter?.getRemoteDevice(address) ?: throw IOException("BLE device not found")
            bleProbeOnly = true; bleSelectedAddress = address
            sendStatus("Đang đối chiếu dịch vụ Bluetooth…")
            bleGatt = if (Build.VERSION.SDK_INT >= 23) device.connectGatt(this, false, bleGattCallback, BluetoothDevice.TRANSPORT_LE) else device.connectGatt(this, false, bleGattCallback)
        } catch (e: Exception) { bleProbeOnly = false; sendStatus("BLE check error: ${e.message}") }
    }

    private fun connectBleDevice(address: String) {
        bleProbeOnly = false; bleSelectedAddress = address
        if (!hasBlePermissions()) { startBleScan(); return }
        try {
            stopBleScan()
            val device = bluetoothAdapter?.getRemoteDevice(address) ?: throw IOException("BLE device not found")
            closeBleGatt()
            sendStatus("Connecting BLE: $address…")
            bleGatt = if (Build.VERSION.SDK_INT >= 23) device.connectGatt(this, false, bleGattCallback, BluetoothDevice.TRANSPORT_LE) else device.connectGatt(this, false, bleGattCallback)
        } catch (e: Exception) { sendStatus("BLE connection error: ${e.message}") }
    }

    private val bleGattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                if (bleProbeOnly) { bleProbeOnly = false; webView.post { webView.evaluateJavascript("onBleCheckResult(false, 'Không đọc được dịch vụ Bluetooth (GATT $status)')", null) } }
                sendStatus("BLE GATT error: $status"); closeBleGatt(); return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                sendStatus("BLE connected · discovering UART services")
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                sendStatus("BLE disconnected"); closeBleGatt()
            }
        }
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) { sendStatus("BLE service discovery failed"); return }
            var notify: BluetoothGattCharacteristic? = null
            var write: BluetoothGattCharacteristic? = null
            for (serviceId in uartServiceIds) {
                val service = gatt.getService(serviceId) ?: continue
                val chars = service.characteristics
                notify = chars.firstOrNull { (it.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 }
                write = chars.firstOrNull { (it.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0 }
                if (notify != null || write != null) break
            }
            if (bleProbeOnly) {
                val compatible = notify != null && write != null
                bleProbeOnly = false
                val detail = if (compatible) "Đúng chuẩn BLE UART: có RX Notify và TX Write" else "Không phù hợp: thiếu đặc tính RX Notify hoặc TX Write"
                webView.post { webView.evaluateJavascript("onBleCheckResult($compatible, ${JSONObject.quote(detail)})", null) }
                closeBleGatt()
                sendStatus(if (compatible) "Đối chiếu BLE thành công" else "Đối chiếu BLE không phù hợp")
                return
            }
            if (notify == null && write == null) {
                sendStatus("BLE connected, but UART characteristics not found"); return
            }
            bleNotifyCharacteristic = notify
            bleWriteCharacteristic = write
            if (notify == null) { sendStatus("BLE UART write-only: cannot receive ACK; sync unavailable"); return }
            val enabled = gatt.setCharacteristicNotification(notify, true)
            val descriptor = notify.getDescriptor(cccdId)
            if (descriptor != null) {
                if (Build.VERSION.SDK_INT >= 33) gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                else { @Suppress("DEPRECATION") descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; @Suppress("DEPRECATION") gatt.writeDescriptor(descriptor) }
            } else if (enabled) sendStatus(if (write != null) "BLE UART ready · RX/TX" else "BLE UART receive-only · no TX")
        }
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            consumeBle(characteristic.value ?: return)
        }
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            consumeBle(value)
        }
        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            sendStatus(if (status == BluetoothGatt.GATT_SUCCESS) if (bleWriteCharacteristic != null) "BLE UART ready · RX/TX" else "BLE UART receive-only · no TX" else "BLE notification setup failed: $status")
        }
    }

    private fun consumeBle(bytes: ByteArray) {
        val chunk = String(bytes, Charsets.UTF_8)
        runOnUiThread {
            for (ch in chunk) {
                if (ch == '\n' || ch == '\r') {
                    val line = bleBuffer.toString().trim(); bleBuffer.clear()
                    if (line.isNotEmpty()) {
                        val safe = JSONObject.quote(line)
                        webView.evaluateJavascript("onSerialLine($safe)", null)
                    }
                } else if (bleBuffer.length < 200) bleBuffer.append(ch)
            }
        }
    }

    private fun closeBleGatt() {
        val old = bleGatt
        bleGatt = null
        bleNotifyCharacteristic = null; bleWriteCharacteristic = null; bleBuffer.clear()
        try { old?.disconnect() } catch (_: Exception) { }
        try { old?.close() } catch (_: Exception) { }
    }


    private fun writeUsbLine(text: String) {
        val active = port
        if (!connected || active == null) { sendStatus("USB send failed: not connected"); return }
        worker.execute {
            try { active.write((text.trim() + "\n").toByteArray(Charsets.UTF_8), 2000) }
            catch (e: Exception) { runOnUiThread { sendStatus("USB send failed: ${e.message}") } }
        }
    }

    private fun writeBleLine(text: String) {
        val gatt = bleGatt
        val characteristic = bleWriteCharacteristic
        if (gatt == null || characteristic == null) { sendStatus("BLE send failed: TX characteristic unavailable"); return }
        try {
            val bytes = (text.trim() + "\n").toByteArray(Charsets.UTF_8)
            val writeType = if ((characteristic.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            val ok = if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeCharacteristic(characteristic, bytes, writeType) == BluetoothStatusCodes.SUCCESS
            } else {
                @Suppress("DEPRECATION") characteristic.writeType = writeType
                @Suppress("DEPRECATION") characteristic.value = bytes
                @Suppress("DEPRECATION") gatt.writeCharacteristic(characteristic)
            }
            if (!ok) sendStatus("BLE send failed: GATT rejected write")
        } catch (e: Exception) { sendStatus("BLE send failed: ${e.message}") }
    }

    private fun vibrateDevice() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                val manager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                val vibrator = manager.defaultVibrator
                if (vibrator.hasVibrator()) vibrator.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (vibrator.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 250, 120, 250), -1)
                    ) else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(longArrayOf(0, 250, 120, 250), -1)
                    }
                }
            }
        } catch (_: Exception) { }
    }

    private fun requestDevicePermission(device: UsbDevice) {
        if (usbManager.hasPermission(device)) {
            openDevice(device)
            return
        }
        val permissionIntent = PendingIntent.getBroadcast(
            this, device.deviceId,
            Intent(permissionAction).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        usbManager.requestPermission(device, permissionIntent)
    }

    private fun findAndConnect() {
        val drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager)
        if (drivers.isEmpty()) {
            sendStatus("No USB serial device found. Check OTG cable and Arduino.")
            return
        }
        val device = drivers[0].device
        requestDevicePermission(device)
    }

    private fun openDevice(device: UsbDevice) {
        try {
            closePort()
            val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
                ?: throw IOException("No compatible USB serial driver")
            val connection = usbManager.openDevice(device) ?: throw IOException("Cannot open USB device")
            val serialPort = driver.ports.firstOrNull() ?: throw IOException("No serial port found")
            serialPort.open(connection)
            serialPort.setParameters(baudRate, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            port = serialPort
            connected = true
            sendStatus("Connected · USB Serial · ${baudRate} baud")
            worker.execute { readLoop(serialPort) }
        } catch (error: Exception) {
            sendStatus("Connection error: ${error.message ?: "unknown error"}")
            closePort()
        }
    }

    private fun readLoop(serialPort: UsbSerialPort) {
        val bytes = ByteArray(256)
        while (connected && port === serialPort) {
            try {
                val count = serialPort.read(bytes, 1000)
                if (count > 0) {
                    val chunk = String(bytes, 0, count, Charsets.UTF_8)
                    runOnUiThread { consume(chunk) }
                }
            } catch (error: Exception) {
                runOnUiThread {
                    sendStatus("Serial disconnected: ${error.message ?: "read error"}")
                    closePort()
                }
                break
            }
        }
    }

    private fun consume(chunk: String) {
        for (character in chunk) {
            if (character == '\n' || character == '\r') {
                val line = buffer.toString().trim()
                buffer.clear()
                if (line.isNotEmpty()) {
                    val safeLine = org.json.JSONObject.quote(line)
                    webView.evaluateJavascript("onSerialLine($safeLine)", null)
                }
            } else if (buffer.length < 200) {
                buffer.append(character)
            }
        }
    }

    private fun sendStatus(message: String) {
        if (::webView.isInitialized) {
            val safeMessage = org.json.JSONObject.quote(message)
            webView.evaluateJavascript("onStatus($safeMessage)", null)
        }
    }

    private fun closePort() {
        connected = false
        try { port?.close() } catch (_: Exception) { }
        port = null
    }

    override fun onDestroy() {
        closePort()
        stopBleScan(); closeBleGatt()
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) { }
        worker.shutdownNow()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
