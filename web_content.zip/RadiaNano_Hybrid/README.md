# RadiaNano Hybrid Android App

RadiaNano uses an HTML/CSS/JavaScript interface inside Android WebView and a small native Android USB bridge for real USB OTG serial communication.

## Features
- HTML-based Vietnamese interface
- Arduino USB OTG connection through Android USB Host
- USB Serial at 9600 baud, 8 data bits, no parity, 1 stop bit
- Reads `CPM:<number>`, `PULSE:<number>`, and plain integer CPM lines
- Live CPM, accumulated pulse count, connection status, and a 100-line log
- Does not display calibrated dose rate unless calibration is implemented

## Important
This is **not** a standalone HTML page and cannot be converted correctly by a generic HTML-to-APK website. The Android USB bridge is required to access USB Serial. Build this Android project to produce the APK.

## Build
Use the included GitHub Actions workflow (`.github/workflows/build-apk.yml`) or Android Studio with JDK 17 and Android SDK 35.
