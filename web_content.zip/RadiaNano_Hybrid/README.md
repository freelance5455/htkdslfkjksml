# RadiaNano Hybrid — Enhanced UI

RadiaNano is an Android WebView application with a native USB-serial bridge for Arduino-compatible radiation counters.

## Features
- Polished dark instrument-panel interface
- Live CPM display
- Total pulse counter display
- Peak CPM for the current app session
- Recent CPM trend chart
- Serial data console
- USB OTG serial connection at 9600 baud, 8-N-1
- No uncalibrated µSv/h conversion

## Serial input format
Send newline-terminated UTF-8 lines in one of these formats:

```text
CPM:12
PULSE:345
```

A line containing only an integer is also interpreted as CPM.

## Build
Open this project in Android Studio or upload it to a GitHub repository and run the workflow at `.github/workflows/build-apk.yml`.

The project has not been compiled or tested on physical hardware in this delivery. USB compatibility depends on the Arduino USB interface, OTG adapter, and device permissions.


## Premium 1.3 — CPM timeline
- Adds a timestamp to every valid CPM reading received from the Arduino.
- Displays a time-based CPM chart with 1-minute, 5-minute, 15-minute, 1-hour, and full-session ranges.
- Shows average CPM, peak CPM in the selected chart range, sample count, last update time, and elapsed session time.
- Keeps up to 5,000 CPM samples in memory during the current app session.
- The chart records a point whenever a `CPM:<number>` line or a plain integer line is received. `PULSE:<number>` updates the total pulse counter.


## WebView asset loading
This version loads the bundled page directly from `file:///android_asset/index.html` to avoid the `appassets.androidplatform.net` asset-loader route that failed on some builds. JavaScript bridge functionality remains enabled for the USB serial bridge.
