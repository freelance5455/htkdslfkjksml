# RadiaNano Hybrid — Enhanced UI

RadiaNano is an Android WebView application with a native USB-serial bridge for Arduino-compatible radiation counters.

## Features
- Polished dark instrument-panel interface
- Live CPM display
- Total pulse counter display
- Peak CPM for the current app session
- Recent CPM trend chart
- Serial data console
- USB OTG serial connection at 9600 baud, 8-N-1
- No uncalibrated µSv/h conversion

## Serial input format
Send newline-terminated UTF-8 lines in one of these formats:

```text
CPM:12
PULSE:345
```

A line containing only an integer is also interpreted as CPM.

## Build
Open this project in Android Studio or upload it to a GitHub repository and run the workflow at `.github/workflows/build-apk.yml`.

The project has not been compiled or tested on physical hardware in this delivery. USB compatibility depends on the Arduino USB interface, OTG adapter, and device permissions.


## Premium 1.3 — CPM timeline
- Adds a timestamp to every valid CPM reading received from the Arduino.
- Displays a time-based CPM chart with 1-minute, 5-minute, 15-minute, 1-hour, and full-session ranges.
- Shows average CPM, peak CPM in the selected chart range, sample count, last update time, and elapsed session time.
- Keeps up to 5,000 CPM samples in memory during the current app session.
- The chart records a point whenever a `CPM:<number>` line or a plain integer line is received. `PULSE:<number>` updates the total pulse counter.


## WebView asset loading
This version loads the bundled page directly from `file:///android_asset/index.html` to avoid the `appassets.androidplatform.net` asset-loader route that failed on some builds. JavaScript bridge functionality remains enabled for the USB serial bridge.

## Version 1.5 performance and alerts
- USB serial driver probing scans connected devices; USB attach intent requests permission automatically.
- Serial baud rates available: 9600 (default for compatibility), 57600, 115200, 230400. The Arduino sketch must use the same `Serial.begin(...)` baud rate.
- CPM threshold vibration alert is configurable in the UI. The threshold is CPM, not a calibrated dose-rate value.
- Canvas chart rendering is scheduled with `requestAnimationFrame` and uses device-pixel-ratio scaling.
- Android-side changes cannot increase the Nano's pulse-counting interrupt rate. The Arduino sketch and detector front-end determine that limit; high pulse rates require a matching optimized firmware and electrical signal conditioning.


## Version 1.7 — measurement workflow expansion
- Adds optional CPM-to-µSv/h estimate using a user-entered calibration factor (CPM per µSv/h). Dose output remains hidden until a positive factor is supplied.
- Integrates estimated dose over time using trapezoidal integration between successive CPM samples; resets dose integration when calibration is changed.
- Adds estimated dose-rate alarm, alongside the existing CPM alarm.
- Persists up to 5,000 timestamped CPM samples and settings in WebView local storage; restores the chart history on launch.
- Exports measurement history as CSV and diagnostic console as TXT; supports clearing stored history.
- Demo samples are tagged as simulated in the exported history.

### Important hardware limits
This build does not implement gamma spectroscopy, isotope identification, energy calibration, GPS dose mapping, or RadiaCode BLE protocol. The current Arduino/Geiger interface supplies CPM and total pulses only; it has no pulse-height/energy channel data. Those RadiaCode functions require compatible detector hardware, firmware and a validated protocol. The CPM-to-dose factor is user-supplied and is not a factory calibration. Do not use this estimate for safety-critical decisions.

## Version 2.3 — Native USB + BLE and verified configuration sync
- Native Android USB serial transmit bridge (`writeUsb`) added; configuration writes are newline-terminated UTF-8 and sent on the serial worker thread.
- BLE GATT scans devices, lets the user select a device in the app list, discovers Nordic UART / HM-10 characteristics by properties, enables notifications, and separately discovers a writable TX characteristic.
- Native BLE transmit bridge (`writeBle`) added. Devices without a writable characteristic or notification channel are reported as limited and cannot claim two-way sync.
- Configuration sync sends JSON `SET_CONFIG` with a sequence number and waits up to 8 seconds for a matching `CONFIG_ACK`. UI reports success only when `type=CONFIG_ACK`, matching `seq`, and `ok=true`; timeout, rejection, or transport errors are reported as failures.

### ESP32 configuration protocol
Send one newline-terminated JSON object:

```json
{"type":"SET_CONFIG","seq":1,"baudRate":9600,"alarmCpm":300,"calibrationCpmPerUSv":0,"doseAlarmUSv":0,"protocol":1}
```

The ESP32 firmware must validate and apply the settings, then reply on the same transport:

```json
{"type":"CONFIG_ACK","seq":1,"ok":true}
```

On rejection, return `{"type":"CONFIG_ACK","seq":1,"ok":false,"error":"reason"}`. The firmware must preserve the received sequence number. A successful serial write alone is not proof that settings were applied.

### Build / validation status
The source has been statically updated. JavaScript syntax and ZIP integrity are checked during packaging. This environment does not have the Android SDK/Gradle build environment configured, so an APK build and real USB/BLE hardware test are not claimed. ESP32 firmware compatibility depends on implementing the protocol above.
