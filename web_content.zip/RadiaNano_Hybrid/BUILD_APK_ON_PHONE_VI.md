# Cách build APK bằng điện thoại

1. Giải nén `RadiaNano_Hybrid_HTML_USB.zip`.
2. Tạo một repository GitHub mới.
3. Tải toàn bộ nội dung thư mục `RadiaNano_Hybrid` lên repository (giữ nguyên cấu trúc thư mục, bao gồm thư mục `.github`).
4. Mở tab **Actions**.
5. Chọn workflow **Build RadiaNano APK**.
6. Nhấn **Run workflow** và chờ hoàn tất.
7. Mở lần chạy thành công, kéo xuống **Artifacts**, tải `RadiaNano-APK`.
8. Giải nén artifact ZIP để lấy `app-debug.apk`, sau đó cài trên điện thoại.

Giao diện ứng dụng dùng HTML/CSS/JavaScript trong Android WebView. Kết nối Arduino USB OTG được xử lý bởi cầu nối Android native; không thể giữ chức năng USB Serial nếu chỉ đưa riêng file HTML vào một website HTML-to-APK thông thường.

Lưu ý: Bản dự án chưa được build và kiểm thử thực tế. Nếu Actions báo lỗi, gửi ảnh phần log lỗi để xử lý.


Bản Premium 1.2 có biểu đồ CPM theo thời gian. Để biểu đồ chạy, Arduino cần gửi định kỳ các dòng `CPM:12` (mỗi phút hoặc theo chu kỳ bạn chọn). Dòng `PULSE:345` chỉ cập nhật tổng số xung.
