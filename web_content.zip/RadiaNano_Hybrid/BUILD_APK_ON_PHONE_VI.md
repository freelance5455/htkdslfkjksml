# Build RadiaNano APK trên điện thoại

Dự án này dùng giao diện HTML trong Android WebView và cầu nối Android native để giữ kết nối Arduino qua USB OTG. Không thể chỉ tải riêng `index.html` lên website HTML-to-APK thông thường vì website đó không có cầu nối USB Serial.

## Cách build đơn giản
1. Giải nén ZIP dự án.
2. Tải toàn bộ thư mục dự án lên một GitHub repository mới.
3. Mở tab **Actions** của repository.
4. Chọn workflow **Build RadiaNano APK**.
5. Nhấn **Run workflow** và chờ hoàn tất.
6. Mở lần chạy thành công, kéo xuống **Artifacts**, tải `RadiaNano-APK`.
7. Giải nén artifact để lấy `app-debug.apk`, sau đó cài trên OPPO Reno4.

## Dữ liệu Arduino
Arduino phải gửi từng dòng kết thúc bằng newline, ví dụ:

```text
CPM:12
PULSE:345
```

Hoặc một số nguyên trên một dòng để cập nhật CPM.

Thông số serial: 9600 baud, 8 data bits, no parity, 1 stop bit.
