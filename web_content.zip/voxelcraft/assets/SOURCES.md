# Asset notes

The SVG pixel textures included in this folder are original project-local assets generated for this prototype. Models are generated from box geometry at runtime in `app.js`.

An open-source voxel-game texture reference for a future asset replacement is the Luanti/Minetest Game repository:
- Repository: https://github.com/luanti-org/minetest_game
- Texture directory: https://github.com/luanti-org/minetest_game/tree/master/mods/default/textures

Do not assume every file in a third-party repository has identical licensing. Before redistributing replacement textures or models, inspect the specific asset's license and required attribution. Direct network downloads were unavailable in the build environment, so the repository's binary assets have not been copied into this ZIP.
