# Models

The player, companion, trees, and simple mobs are assembled from block meshes by `app.js` at runtime. This keeps the prototype lightweight and avoids a dependency on a specific rigged-model format. The style is original voxel/block art; no proprietary Minecraft model files are included.
