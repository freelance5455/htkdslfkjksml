// language: JavaScript, file: app.js, runtime: browser ES modules, target: Android Chrome + desktop
import * as THREE from 'three';

const $ = (id) => document.getElementById(id);
const STORAGE_WORLDS = 'voxelcraft.worlds.v1';
const STORAGE_SETTINGS = 'voxelcraft.settings.v1';
const WORLD_LIMIT = 5000;
const CHUNK = 16;
const MAX_Y = 18;
const STACK_MAX = 64;
const SLOT_COUNT = 27;
const BLOCKS = {
  grass: { id: 1, label: 'Трава', texture: 'grass', place: true },
  dirt: { id: 2, label: 'Земля', texture: 'dirt', place: true },
  stone: { id: 3, label: 'Камень', texture: 'stone', place: true },
  wood: { id: 4, label: 'Бревно', texture: 'wood', place: true },
  leaves: { id: 5, label: 'Листва', texture: 'leaves', place: true },
  coal_ore: { id: 6, label: 'Угольная руда', texture: 'coal_ore', place: true },
  iron_ore: { id: 7, label: 'Железная руда', texture: 'iron_ore', place: true },
  sand: { id: 8, label: 'Песок', texture: 'sand', place: true },
  bedrock: { id: 9, label: 'Бедрок', texture: 'bedrock', place: true },
  crafting_table: { id: 10, label: 'Верстак', texture: 'crafting_table', place: true },
  planks: { id: 11, label: 'Доски', texture: 'planks', place: true },
};
const ID_TO_BLOCK = Object.fromEntries(Object.entries(BLOCKS).map(([key, val]) => [val.id, key]));
const ITEMS = {
  grass: { label: 'Трава', texture: 'grass', block: 'grass' }, dirt: { label: 'Земля', texture: 'dirt', block: 'dirt' },
  stone: { label: 'Камень', texture: 'stone', block: 'stone' }, wood: { label: 'Бревно', texture: 'wood', block: 'wood' },
  leaves: { label: 'Листва', texture: 'leaves', block: 'leaves' }, coal_ore: { label: 'Угольная руда', texture: 'coal_ore', block: 'coal_ore' },
  iron_ore: { label: 'Железная руда', texture: 'iron_ore', block: 'iron_ore' }, sand: { label: 'Песок', texture: 'sand', block: 'sand' },
  crafting_table: { label: 'Верстак', texture: 'crafting_table', block: 'crafting_table' }, planks: { label: 'Доски', texture: 'planks', block: 'planks' },
  wooden_pickaxe: { label: 'Деревянная кирка', texture: 'wooden_pickaxe' }, wooden_axe: { label: 'Деревянный топор', texture: 'wooden_axe' },
  stick: { label: 'Палка', texture: 'stick' }, coal: { label: 'Уголь', texture: 'coal' }, iron_ingot: { label: 'Железный слиток', texture: 'iron_ingot' },
};
const RECIPES = {
  planks: { label: 'Доски ×4', takes: { wood: 1 }, gives: { planks: 4 } },
  sticks: { label: 'Палки ×4', takes: { planks: 2 }, gives: { stick: 4 } },
  crafting_table: { label: 'Верстак ×1', takes: { planks: 4 }, gives: { crafting_table: 1 } },
  wooden_pickaxe: { label: 'Деревянная кирка', takes: { planks: 3, stick: 2 }, gives: { wooden_pickaxe: 1 } },
  wooden_axe: { label: 'Деревянный топор', takes: { planks: 3, stick: 2 }, gives: { wooden_axe: 1 } },
};
const AI_SYSTEM_PROMPT = `Ты — управляемый ИИ-напарник внутри браузерной voxel-игры в духе Minecraft 1.8. Ты реально существуешь в текущем загруженном мире как блочный персонаж Стив. Твоя задача — понимать сообщения игрока и выполнять игровые поручения. Ты видишь переданный снимок состояния: координаты обоих игроков, режимы, сложность, здоровье, активный предмет, содержимое собственного инвентаря и инвентаря игрока, доступные рецепты и недавний чат. Используй историю чата, не забывай ранее поставленные задачи. Не выдумывай предметы, координаты, успешные действия или ресурсы: действие считается успешным только после отчёта исполнителя. Планируй шаги последовательно. Стак ограничен 64 предметами, инвентарь каждого — 27 ячеек. В режиме выживания проверяй ресурсы до крафта; в креативе расхода материалов нет. Если не хватает ресурсов, добывай их; можно скрафтить кирку/топор, верстак, доски и палки. После добычи по просьбе игрока найди его, подойди и передай предметы. Не заявляй, что уже передал вещь до фактического выполнения действия. Для команды «добудь 1000 дерева» можешь добыть столько, сколько реально помещается в инвентарь, затем передать доступное и честно сообщить остаток. Для игровых действий верни ТОЛЬКО валидный JSON без Markdown: {"say":"краткая реплика игроку","actions":[{"type":"search","target":"wood"}]}. Поддерживаемые действия: search(target: wood|stone|coal_ore|iron_ore|player); mine(target: block/item id, count: integer); craft(target: recipe id, count: integer); move_to_player; follow_player; give_to_player(target: item id, count: integer); take_from_player(target: item id, count: integer); attack(target: mob); stop. Действия выполняются исполнителем по порядку, а не тобой напрямую. Избегай слишком длинного плана: обычно 2–8 действий за ответ. Для общего разговора верни пустой actions. Цели и ID пиши латиницей из списка предметов. Для «дерево» используй wood. Для игрока используй player. Примеры: добыть дерево: search wood, mine wood 5; сделать топор: craft planks 4, craft stick 4, craft wooden_axe 1; передать дерево: move_to_player, give_to_player wood 64. Всегда сверяй план с контекстом.`;

let renderer, scene, camera, worldRoot, playerModel, buddyModel, handModel, handTool;
let activeWorld = null;
let settings = { renderDistance: 3, sensitivity: .75, volume: 40, fov: 75, soundEnabled: true, vibration: true, geminiModel: 'gemini-3.8-flash', geminiKey: '' };
let player = { x: 0, y: 8, z: 0, yaw: 0, pitch: 0, velY: 0, health: 10, hunger: 10 };
let inventory = makeInventory();
let buddyInventory = makeInventory();
let chunks = new Map();
let blockCache = new Map();
let chunkMeshes = [];
let dirtyChunks = new Set();
let currentChunk = '';
let chunkLoading = false;
let raycaster = new THREE.Raycaster();
let texLoader = new THREE.TextureLoader();
let materials = {};
let running = false;
let lastFrame = 0;
let lastAutoSave = 0;
let keys = new Set();
let joystick = { x: 0, y: 0, pointer: null };
let lookPointer = null;
let lastLook = { x: 0, y: 0 };
let buddyGoal = null;
let buddyFollow = false;
let buddyFoundTarget = null;
let mobs = [];
let selectedSlot = 0;
let chatHistory = [];
let toastTimer = 0;
let audioContext = null;
let worldActionBusy = false;
let thirdPerson = false;
let settingsReturn = 'main-menu';
const isTouch = matchMedia('(pointer: coarse)').matches || innerWidth < 850;
if (isTouch) document.body.classList.add('touch-mode');

function makeInventory() { return Array.from({ length: SLOT_COUNT }, () => null); }
function cloneInventory(inv) { return Array.from({ length: SLOT_COUNT }, (_, i) => inv?.[i] ? { id: inv[i].id, count: inv[i].count } : null); }
function key3(x, y, z) { return `${x},${y},${z}`; }
function chunkKey(cx, cz) { return `${cx},${cz}`; }
function chunkCoord(v) { return Math.floor(v / CHUNK); }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function seeded(seed, x, z) { const n = Math.sin((x * 127.1 + z * 311.7 + seed * 74.7) * .0137) * 43758.5453; return n - Math.floor(n); }
function terrainHeight(x, z) {
  const s = activeWorld?.seed ?? 4317;
  const wave = Math.sin(x * .055 + s * .001) * 1.25 + Math.cos(z * .061 - s * .002) * 1.15 + Math.sin((x + z) * .021) * 1.35;
  return clamp(Math.floor(5 + wave + seeded(s, Math.floor(x / 3), Math.floor(z / 3)) * 2.6), 3, 11);
}
function treeAt(x, z) { return seeded(activeWorld?.seed ?? 4317, x, z) > .977 && terrainHeight(x, z) >= 5; }
function generatedBlock(x, y, z) {
  if (y < 0 || y > MAX_Y || Math.abs(x) >= WORLD_LIMIT || Math.abs(z) >= WORLD_LIMIT) return 0;
  if (y === 0) return BLOCKS.bedrock.id;
  const height = terrainHeight(x, z);
  if (y <= height) {
    if (y === height) return height <= 4 ? BLOCKS.sand.id : BLOCKS.grass.id;
    if (y >= height - 2) return height <= 4 ? BLOCKS.sand.id : BLOCKS.dirt.id;
    const r = seeded(activeWorld?.seed ?? 4317, x * 5 + y * 17, z * 7 - y * 3);
    if (y >= 2 && r > .991) return BLOCKS.iron_ore.id;
    if (y >= 2 && r > .966) return BLOCKS.coal_ore.id;
    return BLOCKS.stone.id;
  }
  const localTree = treeAt(x, z);
  if (localTree && y > height && y <= height + 4) return BLOCKS.wood.id;
  for (let dx = -2; dx <= 2; dx++) {
    for (let dz = -2; dz <= 2; dz++) {
      const tx = x + dx, tz = z + dz;
      if (!treeAt(tx, tz)) continue;
      const th = terrainHeight(tx, tz);
      const dy = y - (th + 4);
      if (dy >= -1 && dy <= 1 && Math.abs(dx) + Math.abs(dz) <= 3 && !(dx === 0 && dz === 0 && y <= th + 4)) return BLOCKS.leaves.id;
    }
  }
  return 0;
}
function getBlockAt(x, y, z) {
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  if (!activeWorld) return 0;
  const k = key3(x, y, z);
  if (Object.prototype.hasOwnProperty.call(activeWorld.edits || {}, k)) return activeWorld.edits[k] || 0;
  if (blockCache.has(k)) return blockCache.get(k);
  const value = generatedBlock(x, y, z);
  blockCache.set(k, value);
  return value;
}
function setBlockAt(x, y, z, blockId) {
  x = Math.floor(x); y = Math.floor(y); z = Math.floor(z);
  if (!activeWorld || y <= 0 || y > MAX_Y) return false;
  const k = key3(x, y, z);
  activeWorld.edits ||= {};
  activeWorld.edits[k] = blockId;
  for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) blockCache.delete(key3(x + dx, y + dy, z + dz));
  const cx = chunkCoord(x), cz = chunkCoord(z);
  dirtyChunks.add(chunkKey(cx, cz));
  if (x % CHUNK === 0) dirtyChunks.add(chunkKey(cx - 1, cz));
  if (x % CHUNK === CHUNK - 1) dirtyChunks.add(chunkKey(cx + 1, cz));
  if (z % CHUNK === 0) dirtyChunks.add(chunkKey(cx, cz - 1));
  if (z % CHUNK === CHUNK - 1) dirtyChunks.add(chunkKey(cx, cz + 1));
  return true;
}
function topSurface(x, z) {
  const x0 = Math.floor(x), z0 = Math.floor(z);
  let h = terrainHeight(x0, z0);
  for (let y = MAX_Y; y > h; y--) {
    const b = getBlockAt(x0, y, z0);
    if (b && b !== BLOCKS.leaves.id) { h = y; break; }
  }
  return h + 1;
}

function createMaterials() {
  for (const [name, definition] of Object.entries(BLOCKS)) {
    const tex = texLoader.load(`assets/textures/${definition.texture}.svg`);
    tex.magFilter = THREE.NearestFilter;
    tex.minFilter = THREE.NearestFilter;
    tex.colorSpace = THREE.SRGBColorSpace;
    materials[definition.id] = new THREE.MeshLambertMaterial({ map: tex, side: THREE.DoubleSide });
  }
}
const FACES = [
  { n: [1,0,0], v: [[1,0,0],[1,0,1],[1,1,1],[1,1,0]] },
  { n: [-1,0,0], v: [[0,0,1],[0,0,0],[0,1,0],[0,1,1]] },
  { n: [0,1,0], v: [[0,1,0],[1,1,0],[1,1,1],[0,1,1]] },
  { n: [0,-1,0], v: [[0,0,1],[1,0,1],[1,0,0],[0,0,0]] },
  { n: [0,0,1], v: [[1,0,1],[0,0,1],[0,1,1],[1,1,1]] },
  { n: [0,0,-1], v: [[0,0,0],[1,0,0],[1,1,0],[0,1,0]] },
];
function buildChunk(cx, cz) {
  const group = new THREE.Group();
  group.name = `chunk:${cx},${cz}`;
  const buffers = new Map();
  const ensureBuffer = (id) => { if (!buffers.has(id)) buffers.set(id, { p: [], n: [], uv: [], idx: [] }); return buffers.get(id); };
  const emitFace = (id, x, y, z, face) => {
    const b = ensureBuffer(id); const start = b.p.length / 3;
    for (let i = 0; i < 4; i++) {
      const v = face.v[i]; b.p.push(x + v[0], y + v[1], z + v[2]);
      b.n.push(...face.n);
      b.uv.push(i === 1 || i === 2 ? 1 : 0, i >= 2 ? 1 : 0);
    }
    b.idx.push(start, start + 1, start + 2, start, start + 2, start + 3);
  };
  const minX = cx * CHUNK, minZ = cz * CHUNK;
  for (let x = minX; x < minX + CHUNK; x++) {
    for (let z = minZ; z < minZ + CHUNK; z++) {
      const h = terrainHeight(x, z);
      for (let y = 0; y <= MAX_Y; y++) {
        const id = getBlockAt(x, y, z);
        if (!id) continue;
        // Flat terrain columns are solid; only faces against air become triangles.
        for (const face of FACES) {
          if (!getBlockAt(x + face.n[0], y + face.n[1], z + face.n[2])) emitFace(id, x, y, z, face);
        }
      }
      // 'h' is read intentionally; it ensures the deterministic terrain height is cached for this column.
      void h;
    }
  }
  for (const [id, b] of buffers) {
    if (!b.p.length) continue;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(b.p, 3));
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(b.n, 3));
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(b.uv, 2));
    geometry.setIndex(b.idx);
    geometry.computeBoundingSphere();
    const mesh = new THREE.Mesh(geometry, materials[id] || materials[BLOCKS.stone.id]);
    mesh.userData = { chunkKey: chunkKey(cx, cz), blockId: id };
    mesh.frustumCulled = true;
    group.add(mesh);
  }
  return group;
}
function addChunk(cx, cz) {
  const k = chunkKey(cx, cz);
  if (chunks.has(k)) return;
  const group = buildChunk(cx, cz);
  group.position.set(0, 0, 0);
  worldRoot.add(group);
  chunks.set(k, group);
  group.traverse(obj => { if (obj.isMesh) chunkMeshes.push(obj); });
}
function removeChunk(k) {
  const group = chunks.get(k); if (!group) return;
  worldRoot.remove(group);
  group.traverse(obj => { if (obj.isMesh) { chunkMeshes = chunkMeshes.filter(m => m !== obj); obj.geometry.dispose(); } });
  chunks.delete(k);
}
function rebuildChunk(k) {
  const [cx, cz] = k.split(',').map(Number);
  removeChunk(k); addChunk(cx, cz); dirtyChunks.delete(k);
}
async function loadVisibleChunks(force = false) {
  if (chunkLoading || !activeWorld || !worldRoot) return;
  chunkLoading = true;
  const pcx = chunkCoord(player.x), pcz = chunkCoord(player.z);
  const wanted = [];
  const r = settings.renderDistance;
  for (let dx = -r; dx <= r; dx++) for (let dz = -r; dz <= r; dz++) wanted.push({ cx: pcx + dx, cz: pcz + dz, d: dx * dx + dz * dz });
  wanted.sort((a, b) => a.d - b.d);
  const keep = new Set(wanted.map(c => chunkKey(c.cx, c.cz)));
  for (const k of [...chunks.keys()]) if (!keep.has(k)) removeChunk(k);
  let built = 0;
  try {
    for (const c of wanted) {
      const k = chunkKey(c.cx, c.cz);
      if (!chunks.has(k)) { addChunk(c.cx, c.cz); built++; if (built % 2 === 0) await sleep(0); }
    }
    if (!force) showToast('Чанки загружены');
  } finally { chunkLoading = false; }
}
function initRenderer() {
  if (renderer) return;
  renderer = new THREE.WebGLRenderer({ canvas: $('game-canvas'), antialias: !isTouch, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, isTouch ? 1.35 : 1.8));
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = false;
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x88c5e8);
  scene.fog = new THREE.Fog(0x88c5e8, 28, settings.renderDistance * CHUNK * 1.45);
  camera = new THREE.PerspectiveCamera(settings.fov, innerWidth / innerHeight, .08, 350);
  camera.rotation.order = 'YXZ';
  scene.add(new THREE.HemisphereLight(0xe3f2ff, 0x63513b, 2.0));
  const sun = new THREE.DirectionalLight(0xfff3d6, 2.4); sun.position.set(-55, 90, 35); scene.add(sun);
  worldRoot = new THREE.Group(); scene.add(worldRoot);
  createMaterials();
  camera.add(new THREE.AmbientLight(0xffffff, .55));
  // A visible blocky first-person sleeve and hand anchor the held-item view.
  handModel = new THREE.Group();
  const sleeve = new THREE.Mesh(new THREE.BoxGeometry(.22,.40,.22), new THREE.MeshLambertMaterial({ color: 0x3456a3 }));
  sleeve.position.set(.46,-.39,-.70); handModel.add(sleeve);
  const hand = new THREE.Mesh(new THREE.BoxGeometry(.18,.18,.20), new THREE.MeshLambertMaterial({ color: 0xc99569 }));
  hand.position.set(.46,-.19,-.72); handModel.add(hand);
  handTool = new THREE.Mesh(new THREE.BoxGeometry(.18,.18,.18), new THREE.MeshLambertMaterial({ color: 0xa87a46 }));
  handTool.position.set(.51,-.12,-.94); handModel.add(handTool);
  camera.add(handModel); scene.add(camera);
  window.addEventListener('resize', resizeRenderer);
}
function resizeRenderer() {
  if (!renderer || !camera) return;
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
  if (document.body.classList.contains('touch-mode')) renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.35));
}
function makeCharacter(options = {}) {
  const root = new THREE.Group();
  const mat = (color) => new THREE.MeshLambertMaterial({ color });
  const skin = mat(options.skin || 0xc58f64), shirt = mat(options.shirt || 0x3478ad), pants = mat(options.pants || 0x303b78), hair = mat(options.hair || 0x493022);
  const addBox = (w,h,d,y,m,x=0,z=0) => { const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m); mesh.position.set(x,y,z); root.add(mesh); return mesh; };
  addBox(.7,.72,.62,1.55,skin);
  addBox(.72,.22,.64,1.99,hair);
  addBox(.48,.36,.04,1.51,mat(0xeeeece),0,.005,-.325);
  addBox(.11,.13,.05,1.51,mat(0x26352b),-.13,.005,-.354); addBox(.11,.13,.05,1.51,mat(0x26352b),.13,.005,-.354);
  addBox(.78,.86,.38,.82,shirt);
  const lArm = addBox(.25,.82,.30,.86,shirt,-.52,0); const rArm = addBox(.25,.82,.30,.86,shirt,.52,0);
  addBox(.31,.72,.34,.04,pants,-.21,0); addBox(.31,.72,.34,.04,pants,.21,0);
  addBox(.25,.22,.3,.46,skin,-.52,0); addBox(.25,.22,.3,.46,skin,.52,0);
  root.userData.arm = rArm;
  return root;
}
function createMobs() {
  for (const m of mobs) scene.remove(m.model);
  mobs = [];
  if (!activeWorld?.mobs) return;
  for (let i = 0; i < 3; i++) {
    const model = makeCharacter({ skin: 0x62874a, shirt: 0x4f7f43, pants: 0x455e38, hair: 0x37482d });
    model.scale.set(.92,.92,.92);
    const angle = i * 2.094 + .5; const distance = 10 + i * 3;
    const x = player.x + Math.cos(angle) * distance, z = player.z + Math.sin(angle) * distance;
    model.position.set(x, terrainHeight(x,z) + 1, z); scene.add(model);
    mobs.push({ model, x, z, health: 3, phase: i * 2 });
  }
}
function saveCurrentWorld(show = false) {
  if (!activeWorld) return;
  activeWorld.player = { x: player.x, y: player.y, z: player.z, yaw: player.yaw, pitch: player.pitch, health: player.health, hunger: player.hunger };
  activeWorld.inventory = cloneInventory(inventory);
  activeWorld.buddyInventory = cloneInventory(buddyInventory);
  if (buddyModel) activeWorld.buddy = { x: buddyModel.position.x, y: buddyModel.position.y, z: buddyModel.position.z };
  activeWorld.chatHistory = chatHistory.slice(-12);
  activeWorld.savedAt = Date.now();
  try {
    const worlds = readWorlds();
    const idx = worlds.findIndex(w => w.id === activeWorld.id);
    if (idx >= 0) worlds[idx] = activeWorld; else worlds.push(activeWorld);
    localStorage.setItem(STORAGE_WORLDS, JSON.stringify(worlds));
    if (show) showToast('Мир сохранён');
  } catch (err) { showToast('Не удалось сохранить: память браузера заполнена'); console.error(err); }
}
function readWorlds() { try { return JSON.parse(localStorage.getItem(STORAGE_WORLDS) || '[]'); } catch { return []; } }
function createWorldObject() {
  return {
    id: `world_${Date.now()}_${Math.random().toString(36).slice(2,7)}`,
    name: $('new-world-name').value.trim() || 'Новый мир', seed: Math.floor(Math.random() * 2_000_000_000),
    mode: $('player-mode').value, buddyEnabled: $('buddy-enabled').value === 'yes', buddyMode: $('buddy-mode').value,
    difficulty: $('difficulty').value, mobs: $('mobs-enabled').value === 'yes', cheats: $('cheats-enabled').value === 'yes',
    width: 10000, depth: 10000, createdAt: Date.now(), savedAt: Date.now(), edits: {},
  };
}
function setupWorld(world) {
  activeWorld = world;
  activeWorld.edits ||= {};
  player = { x: 0, z: 0, y: terrainHeight(0,0) + 1, yaw: 0, pitch: 0, velY: 0, health: 10, hunger: 10, ...(world.player || {}) };
  inventory = world.inventory ? cloneInventory(world.inventory) : makeInventory();
  buddyInventory = world.buddyInventory ? cloneInventory(world.buddyInventory) : makeInventory();
  if (!world.inventory) {
    addItem(inventory, 'grass', 32); addItem(inventory, 'dirt', 32); addItem(inventory, 'wood', 8); addItem(inventory, 'wooden_pickaxe', 1); addItem(inventory, 'crafting_table', 1); addItem(inventory, 'stick', 4);
    if (world.mode === 'creative') { for (const id of Object.keys(ITEMS)) addItem(inventory, id, 64); }
  }
  if (!world.buddyInventory && world.buddyEnabled) { addItem(buddyInventory, 'wood', 3); addItem(buddyInventory, 'dirt', 16); }
  selectedSlot = 0; blockCache.clear(); chunks.clear(); chunkMeshes = []; dirtyChunks.clear(); currentChunk = '';
  if (worldRoot) { while (worldRoot.children.length) { const c = worldRoot.children[0]; worldRoot.remove(c); c.traverse(o=>{if(o.isMesh)o.geometry.dispose();}); } }
  if (buddyModel) { scene.remove(buddyModel); buddyModel = null; }
  if (playerModel) { scene.remove(playerModel); playerModel = null; }
  thirdPerson = false;
  playerModel = makeCharacter({ shirt: 0x3456a3, pants: 0x303b78, hair: 0x493022 });
  playerModel.visible = false; scene.add(playerModel);
  if (world.buddyEnabled) {
    buddyModel = makeCharacter(); const b = world.buddy || { x: player.x + 3, z: player.z + 2 };
    buddyModel.position.set(b.x, terrainHeight(b.x,b.z)+1, b.z); scene.add(buddyModel);
  }
  createMobs();
  chatHistory = Array.isArray(world.chatHistory) ? world.chatHistory.slice(-12) : [];
  $('world-label').textContent = world.name;
  $('hud').classList.remove('hidden');
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  $('inventory-screen').classList.add('hidden'); $('chat-panel').classList.add('hidden');
  running = true; updateHotbar(); updateStatus();
}
async function startWorld(world) {
  initRenderer(); $('loading').classList.remove('hidden');
  setupWorld(world);
  camera.position.set(player.x, player.y + 1.62, player.z);
  camera.rotation.set(player.pitch, player.yaw, 0, 'YXZ');
  scene.fog.far = settings.renderDistance * CHUNK * 1.45;
  try { await loadVisibleChunks(true); } finally { $('loading').classList.add('hidden'); }
  $('chat-log').innerHTML = '';
  addChatLine('Система', `${world.name}: мир загружен. Команды можно писать в чат.`, 'system-line');
  if (world.buddyEnabled) addChatLine('ИИ-друг', settings.geminiKey ? 'я на месте. скажи, что добыть или куда идти.' : 'я на месте. Для Gemini открой Настройки и добавь API-ключ; базовые команды работают и без ключа.', 'system-line');
  if (renderer && !lastFrame) animate(0);
  saveCurrentWorld(false);
}
function showMenu(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  if (id) $(id).classList.remove('hidden');
  if (id !== null) $('hud').classList.add('hidden');
  $('inventory-screen').classList.add('hidden'); $('chat-panel').classList.add('hidden');
  if (id === 'world-menu') renderWorldList();
}
function renderWorldList() {
  const box = $('world-list'); const worlds = readWorlds().sort((a,b)=>(b.savedAt||0)-(a.savedAt||0)); box.innerHTML = '';
  if (!worlds.length) { box.innerHTML = '<div class="system-line muted">Сохранённых миров пока нет. Создай первый мир.</div>'; return; }
  for (const world of worlds) {
    const item = document.createElement('div'); item.className = 'world-entry';
    const icon = document.createElement('div'); icon.className = 'world-icon';
    const info = document.createElement('div'); info.className = 'world-info';
    const date = new Date(world.savedAt || world.createdAt || Date.now()).toLocaleString('ru-RU');
    info.innerHTML = `<strong></strong><small></small>`; info.querySelector('strong').textContent = world.name;
    info.querySelector('small').textContent = `${world.mode === 'creative' ? 'Креатив' : 'Выживание'} · ${date} · ${Object.keys(world.edits || {}).length} изменений`;
    const load = document.createElement('button'); load.textContent = 'Играть'; load.addEventListener('click', () => startWorld(world));
    const del = document.createElement('button'); del.textContent = '×'; del.title = 'Удалить мир'; del.className = 'delete-world'; del.addEventListener('click', () => { if (confirm(`Удалить мир «${world.name}»?`)) { localStorage.setItem(STORAGE_WORLDS, JSON.stringify(readWorlds().filter(w=>w.id!==world.id))); renderWorldList(); } });
    item.append(icon, info, load, del); box.append(item);
  }
}
function loadSettings() {
  try { settings = { ...settings, ...JSON.parse(localStorage.getItem(STORAGE_SETTINGS) || '{}') }; } catch {}
  $('render-distance').value = settings.renderDistance; $('sensitivity').value = settings.sensitivity; $('sound-volume').value = settings.volume; $('fov').value = settings.fov;
  $('gemini-model').value = settings.geminiModel; $('gemini-key').value = settings.geminiKey;
  $('sound-enabled').checked = settings.soundEnabled; $('vibration-enabled').checked = settings.vibration;
  updateSettingLabels();
}
function updateSettingLabels() { $('render-value').textContent = $('render-distance').value; $('sensitivity-value').textContent = Number($('sensitivity').value).toFixed(2); $('sound-value').textContent = `${$('sound-volume').value}%`; $('fov-value').textContent = `${$('fov').value}°`; }
function saveSettings() {
  settings = { renderDistance: Number($('render-distance').value), sensitivity: Number($('sensitivity').value), volume: Number($('sound-volume').value), fov: Number($('fov').value), geminiModel: $('gemini-model').value.trim() || 'gemini-3.8-flash', geminiKey: $('gemini-key').value.trim(), soundEnabled: $('sound-enabled').checked, vibration: $('vibration-enabled').checked };
  localStorage.setItem(STORAGE_SETTINGS, JSON.stringify(settings));
  if (camera) { camera.fov = settings.fov; camera.updateProjectionMatrix(); }
  if (scene?.fog) scene.fog.far = settings.renderDistance * CHUNK * 1.45;
  if (activeWorld) loadVisibleChunks(true);
  showToast('Настройки сохранены'); showMenu(settingsReturn);
}
function addItem(inv, id, count = 1) {
  let left = Math.max(0, Math.floor(count)); if (!ITEMS[id] || left === 0) return left;
  for (let i = 0; i < inv.length && left > 0; i++) if (inv[i]?.id === id && inv[i].count < STACK_MAX) { const put = Math.min(left, STACK_MAX - inv[i].count); inv[i].count += put; left -= put; }
  for (let i = 0; i < inv.length && left > 0; i++) if (!inv[i]) { const put = Math.min(left, STACK_MAX); inv[i] = { id, count: put }; left -= put; }
  return left;
}
function countItem(inv, id) { return inv.reduce((n, slot) => n + (slot?.id === id ? slot.count : 0), 0); }
function removeItem(inv, id, count = 1) {
  if (countItem(inv, id) < count) return false;
  let left = count;
  for (let i = inv.length - 1; i >= 0 && left > 0; i--) if (inv[i]?.id === id) { const take = Math.min(left, inv[i].count); inv[i].count -= take; left -= take; if (inv[i].count <= 0) inv[i] = null; }
  return true;
}
function invSummary(inv) { const list = []; for (const s of inv) if (s) list.push(`${s.id}×${s.count}`); return list.length ? list.join(', ') : 'пусто'; }
function selectedItem() { return inventory[selectedSlot]; }
function updateHotbar() {
  const bar = $('hotbar'); bar.innerHTML = '';
  for (let i = 0; i < 9; i++) {
    const s = inventory[i]; const slot = document.createElement('button'); slot.className = `slot ${i === selectedSlot ? 'selected' : ''} ${s ? '' : 'empty'}`; slot.setAttribute('aria-label', s ? ITEMS[s.id]?.label || s.id : `Пустая ячейка ${i + 1}`);
    if (s) { const img = document.createElement('img'); img.src = `assets/textures/${ITEMS[s.id]?.texture || 'stone'}.svg`; img.alt = ''; slot.append(img); if (s.count > 1) { const count = document.createElement('span'); count.className = 'slot-count'; count.textContent = s.count; slot.append(count); } }
    slot.addEventListener('click', () => { selectedSlot = i; updateHotbar(); }); bar.append(slot);
  }
  if (handTool && selectedItem()) { const id = selectedItem().id; handTool.visible = ['wooden_pickaxe','wooden_axe','stick'].includes(id); handTool.material.color.set(id === 'wooden_axe' || id === 'wooden_pickaxe' ? 0xc0c2bd : 0xa87946); }
}
function updateStatus() { $('health').textContent = Array.from({length:10},(_,i)=>i<player.health?'♥':'♡').join(' '); $('food').textContent = Array.from({length:10},(_,i)=>i<player.hunger?'●':'○').join(' '); $('coords').textContent = `X ${Math.floor(player.x)} · Y ${Math.floor(player.y)} · Z ${Math.floor(player.z)}`; }
function drawInventory() {
  const grid = $('inventory-grid'); grid.innerHTML = '';
  for (let i = 0; i < inventory.length; i++) {
    const s = inventory[i]; const slot = document.createElement('button'); slot.className = `slot ${s ? '' : 'empty'}`; slot.title = s ? `${ITEMS[s.id]?.label || s.id} ×${s.count}` : 'Пусто';
    if (s) { const img=document.createElement('img'); img.src=`assets/textures/${ITEMS[s.id]?.texture || 'stone'}.svg`; img.alt=''; slot.append(img); const count=document.createElement('span'); count.className='slot-count'; count.textContent=s.count; slot.append(count); }
    slot.addEventListener('click',()=>{ if (i < 9) selectedSlot=i; else if (s) { const firstEmpty=inventory.findIndex((s,j)=>j<9&&!s); const target=firstEmpty>=0?firstEmpty:selectedSlot; inventory[target]=s; inventory[i]=null; selectedSlot=target; } drawInventory(); updateHotbar(); saveCurrentWorld(false); });
    grid.append(slot);
  }
}
function canCraft(recipe, inv = inventory) { const mode = inv === buddyInventory ? activeWorld?.buddyMode : activeWorld?.mode; return Object.entries(recipe.takes).every(([id,n]) => countItem(inv,id) >= n) || mode === 'creative'; }
function craftItem(recipeId, inv = inventory, count = 1, silent = false) {
  const recipe = RECIPES[recipeId]; if (!recipe) return false;
  count = clamp(Math.floor(count || 1), 1, 64);
  const craftingMode = inv === buddyInventory ? activeWorld?.buddyMode : activeWorld?.mode;
  if (craftingMode !== 'creative') {
    for (const [id,n] of Object.entries(recipe.takes)) if (countItem(inv,id) < n * count) { if (!silent) showToast(`Не хватает: ${ITEMS[id]?.label || id} ×${n*count}`); return false; }
    for (const [id,n] of Object.entries(recipe.takes)) removeItem(inv,id,n*count);
  }
  let left = 0; for (const [id,n] of Object.entries(recipe.gives)) left += addItem(inv,id,n*count);
  if (!silent) { if (left) showToast('В инвентаре нет места'); else { showToast(`Создано: ${recipe.label}`); playSound(500,.07); } }
  if (inv === inventory) { updateHotbar(); drawInventory(); saveCurrentWorld(false); }
  return left === 0;
}
function openInventory() { if (!activeWorld) return; $('inventory-screen').classList.remove('hidden'); $('chat-panel').classList.add('hidden'); drawInventory(); }
function closeInventory() { $('inventory-screen').classList.add('hidden'); }
function showToast(text, ms = 2200) { const box=$('toast'); box.textContent=text; box.classList.remove('hidden'); clearTimeout(toastTimer); toastTimer=setTimeout(()=>box.classList.add('hidden'),ms); }
function addChatLine(name, text, cls = '') { const line=document.createElement('div'); line.className=`chat-line ${cls}`; const strong=document.createElement('strong'); strong.textContent=`${name}: `; line.append(strong,document.createTextNode(text)); $('chat-log').append(line); $('chat-log').scrollTop=$('chat-log').scrollHeight; }
function playSound(freq = 260, seconds = .055) {
  if (!settings.soundEnabled || settings.volume <= 0) return;
  try { audioContext ||= new (window.AudioContext || window.webkitAudioContext)(); const osc=audioContext.createOscillator(), gain=audioContext.createGain(); osc.type='square'; osc.frequency.value=freq; gain.gain.value=(settings.volume/100)*.04; osc.connect(gain); gain.connect(audioContext.destination); osc.start(); gain.gain.exponentialRampToValueAtTime(.0001,audioContext.currentTime+seconds); osc.stop(audioContext.currentTime+seconds); } catch {}
}
function vibrate(ms = 20) { if (settings.vibration && navigator.vibrate) navigator.vibrate(ms); }
function findTargetBlock(maxDist = 6) {
  if (!camera || !chunkMeshes.length) return null;
  raycaster.setFromCamera(new THREE.Vector2(0,0), camera);
  const hits=raycaster.intersectObjects(chunkMeshes,false).filter(h=>h.distance<=maxDist);
  if (!hits.length) return null;
  const h=hits[0]; const normal=h.face?.normal || new THREE.Vector3(0,1,0);
  const p=h.point.clone().sub(normal.clone().multiplyScalar(.012));
  return { hit:h, normal, x:Math.floor(p.x), y:Math.floor(p.y), z:Math.floor(p.z), place:{x:Math.floor(h.point.x+normal.x*.012),y:Math.floor(h.point.y+normal.y*.012),z:Math.floor(h.point.z+normal.z*.012)} };
}
function blockToItem(id) { const k=ID_TO_BLOCK[id]; if (!k) return null; if (k==='coal_ore') return 'coal'; if (k==='iron_ore') return 'iron_ingot'; if (k==='bedrock' && !activeWorld?.cheats) return null; return k; }
function mineAt(x, y, z, byBuddy = false) {
  const id = getBlockAt(x,y,z); if (!id || id===BLOCKS.bedrock.id) return false;
  setBlockAt(x,y,z,0);
  const inv = byBuddy ? buddyInventory : inventory;
  const miningMode = byBuddy ? activeWorld.buddyMode : activeWorld.mode;
  if (miningMode !== 'creative') {
    const item=blockToItem(id);
    if (item) { const left=addItem(inv,item,1); if (left) showToast(`${byBuddy?'У друга':'В инвентаре'} нет места`); }
  }
  playSound(id===BLOCKS.stone.id||id===BLOCKS.coal_ore.id?160:330,.07); vibrate(13);
  if (!byBuddy) { updateHotbar(); updateStatus(); }
  return true;
}
function breakTarget() {
  const target=findTargetBlock();
  // Compare the mob and block hit distances so a mob in front of terrain can actually be hit.
  raycaster.setFromCamera(new THREE.Vector2(0,0),camera);
  const mobMeshes=[]; for (const m of mobs) m.model.traverse(o=>{if(o.isMesh)mobMeshes.push(o);});
  const mobHit=raycaster.intersectObjects(mobMeshes,false).find(h=>h.distance<4);
  if (mobHit && (!target || mobHit.distance < target.hit.distance)) {
    const mob=mobs.find(m=>m.model===mobHit.object.parent || m.model.getObjectById(mobHit.object.id));
    if (mob) { mob.health--; if (mob.health<=0) { scene.remove(mob.model); mobs=mobs.filter(x=>x!==mob); addItem(inventory,'coal',1); showToast('Моб побеждён'); } playSound(110,.09); updateHotbar(); saveCurrentWorld(false); return; }
  }
  if (target) {
    if (mineAt(target.x,target.y,target.z,false)) { updateHotbar(); saveCurrentWorld(false); }
  }
}
function placeTarget() {
  const target=findTargetBlock(); if (!target) return showToast('Нет блока перед прицелом');
  const item=selectedItem(); if (!item) return showToast('Выбери блок на панели');
  const block=ITEMS[item.id]?.block;
  if (!block || !BLOCKS[block]) return showToast('Этот предмет нельзя поставить');
  const p=target.place;
  if (p.y<=0 || p.y>MAX_Y) return;
  if (Math.abs(p.x-player.x)<.7 && Math.abs(p.z-player.z)<.7 && p.y < player.y+1.8 && p.y+1>player.y) return showToast('Нельзя поставить блок внутри себя');
  setBlockAt(p.x,p.y,p.z,BLOCKS[block].id);
  if (activeWorld.mode!=='creative') { item.count--; if (item.count<=0) inventory[selectedSlot]=null; }
  updateHotbar(); playSound(420,.04); saveCurrentWorld(false);
}

function findNearbyBlock(target, originX, originZ, radius = 26, preferredY = null) {
  const x0=Math.floor(originX), z0=Math.floor(originZ);
  for (let r=0; r<=radius; r++) {
    let best=null, bestD=Infinity;
    for (let x=x0-r; x<=x0+r; x++) for (let z=z0-r; z<=z0+r; z++) {
      if (r>0 && Math.max(Math.abs(x-x0),Math.abs(z-z0)) !== r) continue;
      const top=terrainHeight(x,z);
      for(let y=Math.max(1,top-3);y<=Math.min(MAX_Y,top+5);y++) {
        const id=getBlockAt(x,y,z); const name=ID_TO_BLOCK[id];
        const matched = target==='wood'||target==='tree' ? name==='wood' : target==='stone' ? name==='stone' : target==='coal_ore' ? name==='coal_ore' : target==='iron_ore' ? name==='iron_ore' : target==='dirt' ? name==='dirt' : target==='grass' ? name==='grass' : target==='sand' ? name==='sand' : target==='leaves' ? name==='leaves' : false;
        if (!matched) continue;
        const d=(x-originX)**2+(z-originZ)**2+(preferredY==null?0:(y-preferredY)**2*.5);
        if(d<bestD){bestD=d;best={x,y,z,id,distance:Math.sqrt(d)};}
      }
    }
    if(best) return best;
  }
  return null;
}
function updateBuddyPosition() {
  if (!buddyModel || !activeWorld?.buddyEnabled) return;
  const dt = Math.min(.06, (performance.now() - (updateBuddyPosition.last || performance.now())) / 1000); updateBuddyPosition.last=performance.now();
  const b=buddyModel.position;
  if (buddyFollow && !buddyGoal) buddyGoal={x:player.x+Math.sin(player.yaw)*1.8,z:player.z-Math.cos(player.yaw)*1.8};
  if (buddyGoal) {
    const dx=buddyGoal.x-b.x, dz=buddyGoal.z-b.z, d=Math.hypot(dx,dz);
    if(d>.25){ const step=Math.min(d,2.7*dt); b.x+=dx/d*step; b.z+=dz/d*step; buddyModel.rotation.y=Math.atan2(-dx,-dz); const arm=buddyModel.userData.arm; if(arm) arm.rotation.x=Math.sin(performance.now()*.015)*.15; }
    else { buddyGoal=null; if (!buddyFollow) buddyModel.position.y=topSurface(b.x,b.z); }
  }
  b.y=topSurface(b.x,b.z);
}
function updateMobPositions(dt, time) {
  for (const mob of mobs) {
    mob.phase += dt;
    const dx=player.x-mob.x,dz=player.z-mob.z,d=Math.hypot(dx,dz);
    if(d<9 && d>1.8){ mob.x+=dx/d*dt*.65; mob.z+=dz/d*dt*.65; mob.model.rotation.y=Math.atan2(-dx,-dz); }
    else if(d<=1.8 && Math.sin(time/700+mob.phase)>0.96){ player.health=Math.max(0,player.health-1); updateStatus(); }
    mob.model.position.set(mob.x,topSurface(mob.x,mob.z),mob.z);
    mob.model.children[5] && (mob.model.children[5].rotation.x=Math.sin(time*.006+mob.phase)*.25);
  }
}
function updateMovement(dt) {
  const over = !$('inventory-screen').classList.contains('hidden') || !$('chat-panel').classList.contains('hidden') || !$('pause-menu').classList.contains('hidden') || !$('main-menu').classList.contains('hidden') || !$('world-menu').classList.contains('hidden') || !$('settings-menu').classList.contains('hidden') || !$('create-menu').classList.contains('hidden');
  if (over) return;
  const f=(keys.has('KeyW')||keys.has('ArrowUp')?1:0)-(keys.has('KeyS')||keys.has('ArrowDown')?1:0) - joystick.y;
  const str=(keys.has('KeyD')||keys.has('ArrowRight')?1:0)-(keys.has('KeyA')||keys.has('ArrowLeft')?1:0) + joystick.x;
  let forward=clamp(f,-1,1), side=clamp(str,-1,1); const len=Math.hypot(forward,side); if(len>1){forward/=len;side/=len;}
  const speed=keys.has('ShiftLeft')?6:4.3;
  const dx=(-Math.sin(player.yaw)*forward+Math.cos(player.yaw)*side)*speed*dt;
  const dz=(-Math.cos(player.yaw)*forward-Math.sin(player.yaw)*side)*speed*dt;
  const nx=clamp(player.x+dx,-WORLD_LIMIT+1,WORLD_LIMIT-1), nz=clamp(player.z+dz,-WORLD_LIMIT+1,WORLD_LIMIT-1);
  player.x=nx; player.z=nz;
  const ground=topSurface(player.x,player.z);
  if(keys.has('Space') && Math.abs(player.y-ground)<.12){player.velY=7.2;keys.delete('Space');}
  player.velY-=18*dt; player.y+=player.velY*dt;
  if(player.y<=ground){player.y=ground;player.velY=0;}
  if (thirdPerson && playerModel) {
    playerModel.visible = true;
    playerModel.position.set(player.x, topSurface(player.x, player.z), player.z);
    playerModel.rotation.y = player.yaw;
    camera.position.set(player.x + Math.sin(player.yaw) * 4.5, player.y + 2.8, player.z + Math.cos(player.yaw) * 4.5);
    camera.lookAt(player.x, player.y + 1.35, player.z);
    if (handModel) handModel.visible = false;
  } else {
    if (playerModel) playerModel.visible = false;
    camera.position.set(player.x,player.y+1.62,player.z);
    camera.rotation.set(player.pitch,player.yaw,0,'YXZ');
    if (handModel) handModel.visible = true;
  }
  $('coords').textContent=`X ${Math.floor(player.x)} · Y ${Math.floor(player.y)} · Z ${Math.floor(player.z)}`;
  if(player.health<=0){player.health=10;player.x=0;player.z=0;player.y=topSurface(0,0);showToast('Ты возродился на точке появления');}
}
function animate(time) {
  requestAnimationFrame(animate);
  if(!renderer||!scene||!camera)return;
  const dt=Math.min(.05,(time-(lastFrame||time))/1000);lastFrame=time;
  if(running&&activeWorld){
    updateMovement(dt); updateBuddyPosition(); updateMobPositions(dt,time);
    const c=chunkKey(chunkCoord(player.x),chunkCoord(player.z));
    if(c!==currentChunk){currentChunk=c; loadVisibleChunks();}
    if(dirtyChunks.size && !chunkLoading){rebuildChunk(dirtyChunks.values().next().value);}
    if(time-lastAutoSave>15000){saveCurrentWorld(false);lastAutoSave=time;}
    if (playerModel) playerModel.position.set(player.x,player.y,player.z);
  }
  renderer.render(scene,camera);
}

function findItemId(text) {
  const s=String(text||'').toLowerCase().replaceAll('ё','е').trim();
  if (Object.prototype.hasOwnProperty.call(ITEMS, s)) return s;
  const aliases={wood:['wood','дерев','бревн','бревно'],grass:['grass','трава'],dirt:['dirt','земл'],stone:['stone','камень'],leaves:['leaves','лист'],coal_ore:['coal_ore','угольная руда','руду угл'],iron_ore:['iron_ore','железная руда'],planks:['planks','доск'],stick:['stick','палк'],crafting_table:['crafting_table','верстак'],wooden_pickaxe:['wooden_pickaxe','кирк'],wooden_axe:['wooden_axe','топор'],coal:['уголь','coal'],iron_ingot:['слиток','iron_ingot'],sand:['песок','sand']};
  for(const [id,terms] of Object.entries(aliases))if(terms.some(t=>s.includes(t)))return id;
  return s;
}
function parseOfflineActions(message) {
  const text=message.toLowerCase().replaceAll('ё','е');
  const n=Number((text.match(/\b(\d{1,4})\b/)||[])[1]||5);
  if(/инвентар|что у тебя|что есть/.test(text))return {say:`мой инвентарь: ${invSummary(buddyInventory)}`,actions:[]};
  if(/следуй|за мной|follow/.test(text))return {say:'иду за тобой.',actions:[{type:'follow_player'}]};
  if(/найди меня|иди ко мне|подойди ко мне/.test(text))return {say:'сейчас подойду.',actions:[{type:'search',target:'player'},{type:'move_to_player'}]};
  if(/стоп|остановись|стой/.test(text))return {say:'остановился.',actions:[{type:'stop'}]};
  if(/дай|скинь|передай/.test(text)){const item=/wooden_axe|топор/.test(text)?'wooden_axe':/wooden_pickaxe|кирк/.test(text)?'wooden_pickaxe':/доск|planks/.test(text)?'planks':/палк|stick/.test(text)?'stick':/уголь|coal/.test(text)?'coal':'wood';return {say:`проверю, сколько ${item} могу передать.`,actions:[{type:'move_to_player'},{type:'give_to_player',target:item,count:n}]};}
  if(/забери у меня|возьми у меня|я даю/.test(text))return {say:'подойду и заберу предметы.',actions:[{type:'move_to_player'},{type:'take_from_player',target:findItemId(text),count:n}]};
  if(/скрафт|сделай|создай|craft/.test(text)){
    const recipe=/топор|axe/.test(text)?'wooden_axe':/кирк|pickaxe/.test(text)?'wooden_pickaxe':/верстак|table/.test(text)?'crafting_table':/палк|stick/.test(text)?'sticks':/доск|planks/.test(text)?'planks':null;
    if(recipe)return {say:'проверю ресурсы и сделаю.',actions:[{type:'craft',target:recipe,count:1}]};
  }
  if(/добуд|собер|найди|сломай|break|mine/.test(text)){
    const target=/кам|stone/.test(text)?'stone':/желез|iron/.test(text)?'iron_ore':/уголь|coal/.test(text)?'coal_ore':'wood';
    return {say:`ищу ${target} и начинаю добычу.`,actions:[{type:'search',target},{type:'mine',target,count:n} ]};
  }
  return {say:'понял. напиши, что добыть, что скрафтить, попроси идти за тобой или передать предметы. Для свободного диалога укажи Gemini API key в настройках.',actions:[]};
}
function actionLine(action) {
  const target=action.target||'';
  if(action.type==='search')return `Search ${target}`;
  if(action.type==='mine')return `Break ${target} ${action.count||1}`;
  if(action.type==='craft')return `craft ${target} ${action.count||1}`;
  if(action.type==='move_to_player')return 'Walk to player';
  if(action.type==='follow_player')return 'Follow player';
  if(action.type==='give_to_player')return `Give player ${target} ${action.count||64}`;
  if(action.type==='take_from_player')return `Take player ${target} ${action.count||1}`;
  if(action.type==='attack')return `Attack ${target}`;
  if(action.type==='stop')return 'Stop';
  return `${action.type} ${target}`.trim();
}
function contextForAI() {
  const buddyPos=buddyModel?{x:Math.floor(buddyModel.position.x),y:Math.floor(buddyModel.position.y),z:Math.floor(buddyModel.position.z)}:null;
  return `CURRENT GAME STATE (fresh snapshot):
World: ${activeWorld.name}; world bounds X/Z -5000..4999; generated on demand by 16x16 chunks; seed ${activeWorld.seed}.
Player mode: ${activeWorld.mode}; buddy mode: ${activeWorld.buddyMode}; difficulty: ${activeWorld.difficulty}; mobs: ${activeWorld.mobs}; cheats: ${activeWorld.cheats}.
Player position: ${JSON.stringify({x:Math.floor(player.x),y:Math.floor(player.y),z:Math.floor(player.z)})}; HP ${player.health}/10; hunger ${player.hunger}/10; inventory: ${invSummary(inventory)}.
Buddy enabled: ${activeWorld.buddyEnabled}; buddy position: ${JSON.stringify(buddyPos)}; buddy inventory: ${invSummary(buddyInventory)}.
Stack size maximum 64; inventory slots 27. Recipes: ${Object.keys(RECIPES).map(k=>`${k} takes ${JSON.stringify(RECIPES[k].takes)} gives ${JSON.stringify(RECIPES[k].gives)}`).join('; ')}.
Recent chat in this room is included as messages. Respond to the latest player message and use these actual state values. Do not claim an action has happened until execution returns its result.`;
}
async function askGemini(message) {
  if(!activeWorld?.buddyEnabled){addChatLine('Система','В этом мире нет ИИ-друга. Создай мир с напарником или включи его в настройках мира.','system-line');return;}
  if(!settings.geminiKey){chatHistory.push({role:'user',text:message});const result=parseOfflineActions(message); await processAIResult(result); return;}
  addChatLine('ИИ-друг','думаю над задачей…','system-line');
  const contents=[];
  for(const entry of chatHistory.slice(-12)) contents.push({role:entry.role==='assistant'?'model':'user',parts:[{text:entry.text}]});
  contents.push({role:'user',parts:[{text:`${contextForAI()}\n\nLATEST PLAYER MESSAGE:\n${message}\n\nReturn strict JSON only: {"say":"string","actions":[{"type":"search|mine|craft|move_to_player|follow_player|give_to_player|take_from_player|attack|stop","target":"id","count":number}]}`}]});
  const model=(settings.geminiModel||'gemini-3.8-flash').replace(/^models\//,'');
  try{
    const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{
      method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':settings.geminiKey},
      body:JSON.stringify({systemInstruction:{parts:[{text:AI_SYSTEM_PROMPT}]},contents,generationConfig:{temperature:.25,responseMimeType:'application/json'}})
    });
    const data=await response.json();
    if(!response.ok)throw new Error(data?.error?.message||`Gemini API HTTP ${response.status}`);
    const raw=(data.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('').trim();
    let result;
    try { const clean=raw.replace(/^```(?:json)?\s*/i,'').replace(/\s*```$/,''); result=JSON.parse(clean); }
    catch { result={say:raw||'Ответ пустой.',actions:[]}; }
    chatHistory.push({role:'user',text:message}); chatHistory=chatHistory.slice(-12);
    await processAIResult(result);
  }catch(err){
    addChatLine('ИИ-друг',`Gemini API: ${err.message}`,'system-line');
    addChatLine('Система','Проверь ключ, доступ к API и имя модели в настройках.','system-line');
  }
}
async function processAIResult(result) {
  if(result.say)addChatLine('ИИ-друг',String(result.say));
  const actions=Array.isArray(result.actions)?result.actions.slice(0,8):[];
  if(!actions.length){if(result.say)chatHistory.push({role:'assistant',text:String(result.say)});chatHistory=chatHistory.slice(-12);saveCurrentWorld(false);return;}
  worldActionBusy=true;
  const outcomes=[];
  for(const action of actions){
    addChatLine('Действие',actionLine(action),'action-line');
    try { const outcome=await executeBuddyAction(action); outcomes.push(`${actionLine(action)} → ${outcome}`); addChatLine('Результат',outcome,'system-line'); }
    catch(e){ outcomes.push(`${actionLine(action)} → ошибка: ${e.message}`); addChatLine('Результат',`не выполнено: ${e.message}`,'system-line');}
    updateHotbar(); await sleep(80);
  }
  worldActionBusy=false; saveCurrentWorld(false);
  chatHistory.push({role:'assistant',text:[String(result.say||''),...outcomes].filter(Boolean).join('\n')});
  chatHistory=chatHistory.slice(-12);
}
async function walkBuddyTo(x,z) {
  if(!buddyModel)return;
  buddyFollow=false; buddyGoal={x,z};
  let ticks=0;
  while(buddyGoal && ticks++<280){ updateBuddyPosition(); await sleep(40); }
  buddyGoal=null;
}
async function executeBuddyAction(action) {
  const target=String(action.target||'').toLowerCase(); const count=clamp(Math.floor(Number(action.count)||1),1,1000);
  if(action.type==='search'){
    if(target==='player'){ buddyFoundTarget={x:player.x,z:player.z}; return `игрок найден: X ${Math.floor(player.x)}, Z ${Math.floor(player.z)}`; }
    const origin=buddyModel?.position||player; const found=findNearbyBlock(target,origin.x,origin.z,28);
    if(!found)return `${target}: поблизости не найдено. Попробую искать в другом месте.`;
    buddyFoundTarget=found; return `найден ${target} в X ${found.x}, Y ${found.y}, Z ${found.z}`;
  }
  if(action.type==='mine'){
    let mined=0, wanted=target==='tree'?'wood':target;
    if(!ITEMS[wanted] && wanted==='wooden_axe')wanted='wood';
    const map={wood:'wood',stone:'stone',coal_ore:'coal_ore',iron_ore:'iron_ore',dirt:'dirt',grass:'grass',sand:'sand',leaves:'leaves'};
    wanted=map[wanted]||wanted;
    for(let i=0;i<count;i++){
      if(!buddyModel)break;
      let found=findNearbyBlock(wanted,buddyModel.position.x,buddyModel.position.z,30);
      if(!found)found=findNearbyBlock(wanted,buddyModel.position.x,buddyModel.position.z,80);
      if(!found)break;
      if(Math.hypot(found.x-buddyModel.position.x,found.z-buddyModel.position.z)>2.4) await walkBuddyTo(found.x+.5,found.z+.5);
      if(mineAt(found.x,found.y,found.z,true))mined++;
      if(i%8===7) await sleep(50);
      if(countItem(buddyInventory,wanted)>=STACK_MAX*27)break;
    }
    return `добыто ${mined} блоков ${wanted}${mined<count?'; рядом больше не найдено или инвентарь заполнен':''}. Инвентарь: ${invSummary(buddyInventory)}`;
  }
  if(action.type==='craft'){
    const recipeId=target in RECIPES?target:(target.includes('axe')?'wooden_axe':target.includes('pickaxe')?'wooden_pickaxe':target.includes('table')?'crafting_table':target.includes('stick')?'sticks':target.includes('plank')?'planks':null);
    if(!recipeId)return `не знаю рецепт ${target}`;
    let made=0; for(let i=0;i<count;i++){if(craftItem(recipeId,buddyInventory,1,true))made++;else break;}
    return made?`скрафчено ${recipeId} ×${made}. Инвентарь: ${invSummary(buddyInventory)}`:`не хватило ресурсов для ${recipeId}. Есть: ${invSummary(buddyInventory)}`;
  }
  if(action.type==='move_to_player'){
    if(!buddyModel)return 'напарник отключён'; await walkBuddyTo(player.x+Math.sin(player.yaw)*1.7,player.z-Math.cos(player.yaw)*1.7); return 'подошёл к игроку';
  }
  if(action.type==='follow_player') { buddyFollow=true; buddyGoal=null; return 'следую за игроком'; }
  if(action.type==='stop') { buddyFollow=false; buddyGoal=null; return 'остановился'; }
  if(action.type==='give_to_player'){
    if(!buddyModel)return 'напарник отключён'; if(Math.hypot(buddyModel.position.x-player.x,buddyModel.position.z-player.z)>3)await walkBuddyTo(player.x+Math.sin(player.yaw)*1.7,player.z-Math.cos(player.yaw)*1.7);
    const id=findItemId(target); const available=countItem(buddyInventory,id); const amount=Math.min(count,available); if(!amount)return `у меня нет ${id}`;
    removeItem(buddyInventory,id,amount); const left=addItem(inventory,id,amount); if(left)addItem(buddyInventory,id,left); const transferred=amount-left; return transferred?`передал игроку ${id} ×${transferred}. У меня осталось: ${invSummary(buddyInventory)}`:'в инвентаре игрока нет места';
  }
  if(action.type==='take_from_player'){
    if(!buddyModel)return 'напарник отключён'; if(Math.hypot(buddyModel.position.x-player.x,buddyModel.position.z-player.z)>3)await walkBuddyTo(player.x+Math.sin(player.yaw)*1.7,player.z-Math.cos(player.yaw)*1.7);
    const id=findItemId(target),amount=Math.min(count,countItem(inventory,id)); if(!amount)return `у игрока нет ${id}`;
    removeItem(inventory,id,amount); const left=addItem(buddyInventory,id,amount); if(left)addItem(inventory,id,left); updateHotbar(); return left<amount?`забрал ${id} ×${amount-left}`:'у меня нет места';
  }
  if(action.type==='attack'){
    const mob=mobs[0]; if(!mob)return 'поблизости нет мобов'; await walkBuddyTo(mob.x+1,mob.z+1); mob.health-=1; if(mob.health<=0){scene.remove(mob.model);mobs=mobs.filter(m=>m!==mob);} return 'атаковал моба';
  }
  return `неизвестное действие: ${action.type}`;
}

function wireEvents() {
  $('play-open').addEventListener('click',()=>showMenu('world-menu'));
  $('settings-open').addEventListener('click',()=>{settingsReturn='main-menu';showMenu('settings-menu');});
  $('fullscreen-menu').addEventListener('click',toggleFullscreen);
  $('exit-btn').addEventListener('click',()=>showToast('В браузере можно закрыть вкладку или вернуться на главный экран.'));
  $('create-open').addEventListener('click',()=>showMenu('create-menu'));
  $('create-world-btn').addEventListener('click',()=>{const w=createWorldObject();const worlds=readWorlds();worlds.push(w);localStorage.setItem(STORAGE_WORLDS,JSON.stringify(worlds));startWorld(w);});
  document.querySelectorAll('[data-back]').forEach(b=>b.addEventListener('click',()=>showMenu(b.dataset.back)));
  $('render-distance').addEventListener('input',updateSettingLabels); $('sensitivity').addEventListener('input',updateSettingLabels); $('sound-volume').addEventListener('input',updateSettingLabels); $('fov').addEventListener('input',updateSettingLabels);
  $('settings-save').addEventListener('click',saveSettings);
  $('toggle-key').addEventListener('click',()=>{$('gemini-key').type=$('gemini-key').type==='password'?'text':'password';$('toggle-key').textContent=$('gemini-key').type==='password'?'Показать ключ':'Скрыть ключ';});
  $('pause-open').addEventListener('click',()=>{saveCurrentWorld(false);showMenu('pause-menu');});
  $('resume-btn').addEventListener('click',()=>{document.querySelectorAll('.screen').forEach(s=>s.classList.add('hidden'));$('hud').classList.remove('hidden');});
  $('pause-settings').addEventListener('click',()=>{settingsReturn='pause-menu';showMenu('settings-menu');});
  $('save-menu-btn').addEventListener('click',()=>saveCurrentWorld(true));
  $('quit-world-btn').addEventListener('click',()=>{saveCurrentWorld(false);running=false;activeWorld=null;chunks.clear();chunkMeshes=[];showMenu('main-menu');});
  $('inventory-open').addEventListener('click',openInventory);
  $('chat-open').addEventListener('click',()=>{ $('chat-panel').classList.toggle('hidden'); if(!$('chat-panel').classList.contains('hidden')) setTimeout(()=>$('chat-input').focus(),40); });
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>$(b.dataset.close).classList.add('hidden')));
  $('craft-planks').addEventListener('click',()=>craftItem('planks'));
  $('craft-sticks').addEventListener('click',()=>craftItem('sticks'));
  $('craft-table').addEventListener('click',()=>craftItem('crafting_table'));
  $('craft-pickaxe').addEventListener('click',()=>craftItem('wooden_pickaxe'));
  $('craft-axe').addEventListener('click',()=>craftItem('wooden_axe'));
  $('chat-form').addEventListener('submit',async e=>{e.preventDefault();const input=$('chat-input');const msg=input.value.trim();if(!msg)return;input.value='';addChatLine('Ты',msg);if(activeWorld?.buddyEnabled)await askGemini(msg);else addChatLine('Система','Сообщение в локальном чате отправлено. В этом мире ИИ-друг выключен.','system-line');});
  document.querySelectorAll('[data-chat]').forEach(b=>b.addEventListener('click',()=>{$('chat-input').value=b.dataset.chat;$('chat-form').requestSubmit();}));
  $('mine-btn').addEventListener('pointerdown',e=>{e.preventDefault();breakTarget();}); $('place-btn').addEventListener('pointerdown',e=>{e.preventDefault();placeTarget();});
  $('hit-btn').addEventListener('pointerdown',e=>{e.preventDefault();breakTarget();}); $('jump-btn').addEventListener('pointerdown',e=>{e.preventDefault();keys.add('Space');}); $('jump-btn').addEventListener('pointerup',()=>keys.delete('Space'));
  $('game-canvas').addEventListener('contextmenu',e=>e.preventDefault());
  $('game-canvas').addEventListener('pointerdown',e=>{
    if(!activeWorld||isTouch)return;
    if(e.button===0){ if(document.pointerLockElement!==$('game-canvas')){$('game-canvas').requestPointerLock?.();return;} breakTarget(); }
    if(e.button===2)placeTarget();
  });
  document.addEventListener('pointerlockchange',()=>{});
  document.addEventListener('mousemove',e=>{if(document.pointerLockElement===$('game-canvas')){player.yaw-=e.movementX*.0025*settings.sensitivity;player.pitch=clamp(player.pitch-e.movementY*.0025*settings.sensitivity,-1.48,1.48);}});
  document.addEventListener('keydown',e=>{
    if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();
    keys.add(e.code);
    if(e.repeat)return;
    if(e.code==='KeyE'&&activeWorld){$('inventory-screen').classList.contains('hidden')?openInventory():closeInventory();}
    if(e.code==='KeyT'&&activeWorld){$('chat-panel').classList.remove('hidden');$('chat-input').focus();}
    if(e.code==='F5'&&activeWorld){thirdPerson=!thirdPerson;showToast(thirdPerson?'Вид от третьего лица':'Вид от первого лица');}
    if(e.code==='Escape'&&activeWorld){if(!$('inventory-screen').classList.contains('hidden'))closeInventory();else if(!$('chat-panel').classList.contains('hidden'))$('chat-panel').classList.add('hidden');else if($('pause-menu').classList.contains('hidden')){$('pause-menu').classList.remove('hidden');}else $('pause-menu').classList.add('hidden');}
    if(/^Digit[1-9]$/.test(e.code)){selectedSlot=Number(e.code.slice(5))-1;updateHotbar();}
  });
  document.addEventListener('keyup',e=>keys.delete(e.code));
  const joyZone=$('joystick-zone'),base=$('joystick-base'),knob=$('joystick-knob');
  joyZone.addEventListener('pointerdown',e=>{if(!activeWorld)return; e.preventDefault();joystick.pointer=e.pointerId;joyZone.setPointerCapture?.(e.pointerId);const r=joyZone.getBoundingClientRect();const bx=clamp(e.clientX-r.left,58,r.width-58),by=clamp(e.clientY-r.top,58,r.height-58);base.style.left=`${bx-56}px`;base.style.top=`${by-56}px`;base.style.bottom='auto';updateJoy(e);});
  joyZone.addEventListener('pointermove',e=>{if(joystick.pointer===e.pointerId){e.preventDefault();updateJoy(e);}});
  const stopJoy=e=>{if(joystick.pointer===e.pointerId){joystick.pointer=null;joystick.x=0;joystick.y=0;knob.style.transform='translate(0,0)';}};
  joyZone.addEventListener('pointerup',stopJoy);joyZone.addEventListener('pointercancel',stopJoy);
  function updateJoy(e){const r=base.getBoundingClientRect();const dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),max=34,d=Math.hypot(dx,dy),scale=d>max?max/d:1;const x=dx*scale,y=dy*scale;knob.style.transform=`translate(${x}px,${y}px)`;joystick.x=x/max;joystick.y=y/max;}
  const look=$('look-zone');look.addEventListener('pointerdown',e=>{if(!activeWorld)return;lookPointer=e.pointerId;lastLook={x:e.clientX,y:e.clientY};look.setPointerCapture?.(e.pointerId);});
  look.addEventListener('pointermove',e=>{if(lookPointer!==e.pointerId)return;const dx=e.clientX-lastLook.x,dy=e.clientY-lastLook.y;lastLook={x:e.clientX,y:e.clientY};player.yaw-=dx*.005*settings.sensitivity;player.pitch=clamp(player.pitch-dy*.005*settings.sensitivity,-1.48,1.48);});
  const stopLook=e=>{if(lookPointer===e.pointerId)lookPointer=null;};look.addEventListener('pointerup',stopLook);look.addEventListener('pointercancel',stopLook);
  window.addEventListener('beforeunload',()=>saveCurrentWorld(false));
}
function toggleFullscreen() { const el=document.documentElement; if(!document.fullscreenElement)el.requestFullscreen?.().catch(()=>showToast('Полноэкранный режим не поддерживается браузером'));else document.exitFullscreen?.(); }

loadSettings(); wireEvents();
// Keep the menu visible until a world is explicitly selected or created.
showMenu('main-menu');
