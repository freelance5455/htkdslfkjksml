#!/data/data/com.termux/files/usr/bin/bash
# Run inside the extracted project directory in Termux.
cd "$(dirname "$0")"
printf 'Open http://127.0.0.1:8000 in your Android browser.\n'
python -m http.server 8000 --bind 127.0.0.1
