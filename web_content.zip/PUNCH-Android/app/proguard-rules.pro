# PUNCH release rules. WebView loads the packaged local HTML; no custom shrinking rules are required yet.
