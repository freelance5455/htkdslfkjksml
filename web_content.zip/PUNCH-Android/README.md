# PUNCH Android — first real app project

This project packages the supplied PUNCH v8 HTML app as a native Android application shell and uses the supplied PUNCH logo for branding.

## What is already included
- PUNCH v8 HTML packaged inside the APK for offline use.
- PUNCH logo as launch/splash artwork and app icon source.
- Android permissions for local networking and nearby Wi‑Fi.
- WebView JavaScript + DOM storage + IndexedDB support.
- WebView media permission handling.
- The WebView is not deliberately reloaded when the screen is locked/unlocked.

## Important
This is the **first Android conversion**, not the final native networking rewrite. The existing HTML still contains the current direct WebRTC host/client design. A true multi-phone automatic-reconnect layer should be implemented natively next rather than pretending the old browser connection is permanent.

## Build in Android Studio
1. Install the current Android Studio.
2. Open this `PUNCH-Android` folder.
3. Let Gradle sync and install any requested Android SDK components.
4. Select a physical Android phone with USB debugging enabled.
5. Press Run.
6. Android Studio will install PUNCH on the phone.

## APK
After a successful build, Android Studio can generate a debug APK from:
`app/build/outputs/apk/debug/app-debug.apk`

## Next engineering pass
- Replace the single-peer WebRTC path with a native local-network session manager.
- Store the connection identity and trusted devices natively.
- Reconnect automatically when both phones return to the same local network.
- Support multiple simultaneous connected phones.
- Keep media in a proper native database/files area rather than relying on large browser data URLs.
- Add background/foreground-service handling where Android permits it for the desired live connection behavior.
