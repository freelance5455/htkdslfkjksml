# JARVIS ULTIMATE 2.0 (FIXED)

Native Android (Java), no third-party libraries, no paid APIs.
Gradle 8.13, Android Gradle Plugin 8.11.0, JDK 17, compileSdk 35, targetSdk 34, minSdk 24.

## Build on your phone (AndroidIDE - recommended)
1. Install AndroidIDE and finish setup (JDK 17 + Android SDK, platform 35 + build-tools 35).
2. Unzip JARVIS_ULTIMATE_2.0_FIXED.zip.
3. AndroidIDE -> Open saved project -> select the folder -> wait for Gradle sync -> Build -> Run.
   APK: app/build/outputs/apk/debug/app-debug.apk

## Terminal build (Termux or similar)
    sh gradlew assembleDebug
The first run downloads gradle-wrapper.jar (the jar is not bundled), then Gradle 8.13.
Needs JDK 17 and ANDROID_HOME pointing to an SDK with platform 35.

## Voice commands (English)
- open youtube / instagram / telegram / whatsapp / <any installed app>
- play <song>, search <thing> on youtube, youtube search <thing>, or tap YT VOICE SEARCH
- flashlight on / off (or the FLASH button)
- time, date, battery, joke, help, stop, search <anything> (Google in browser)

## Notes
- Mic permission is asked on first mic tap; if blocked, the app opens Settings for you.
- Flashlight needs no permission. FLASH: BUSY means another app is using the camera.
- Voice recognition uses the phone's speech service (Google app); some phones need internet.
- Recognition and spoken replies use English (en-US).
- Status: not compiled or run in the environment that produced this zip - see build notes in chat.
