package com.jarvis.ultimate;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * JARVIS ULTIMATE 2.0 - voice/text assistant. 100% on-device Android APIs, no paid services.
 */
public class MainActivity extends Activity {

    private static final int REQ_AUDIO = 101;
    private static final int REQ_VOICE_DIALOG = 102;
    private static final String RECOGNITION_LANG = "en-US";
    private static final int CYAN = 0xFF00E5FF;
    private static final int WHITE_BLUE = 0xFFE0F7FA;
    private static final int DIM = 0xFF5FA8B3;

    // name key, display name, web fallback URL, package names...
    private static final String[][] KNOWN_APPS = {
            {"youtube", "YouTube", "https://www.youtube.com", "com.google.android.youtube"},
            {"instagram", "Instagram", "https://www.instagram.com", "com.instagram.android"},
            {"telegram", "Telegram", "https://web.telegram.org", "org.telegram.messenger", "org.telegram.messenger.web"},
            {"whatsapp", "WhatsApp", "https://web.whatsapp.com", "com.whatsapp", "com.whatsapp.w4b"}
    };

    private static final String[] JOKES = {
            "Why do programmers prefer dark mode? Because light attracts bugs.",
            "I would tell you a UDP joke, but you might not get it.",
            "There are ten kinds of people: those who understand binary, and those who don't.",
            "My battery and I have a lot in common. We both run out of energy by evening.",
            "A SQL query walks into a bar, walks up to two tables and asks: can I join you?"
    };

    private static final Pattern YT_BARE = Pattern.compile(
            "^(?:open\\s+)?(?:youtube\\s+search|search\\s+(?:on\\s+|in\\s+)?youtube|youtube\\s+voice\\s+search)$");
    private static final Pattern YT_ON = Pattern.compile(
            "(?:search|find|play|watch|look up)\\s+(?:for\\s+)?(.+?)\\s+(?:on|in)\\s+youtube");
    private static final Pattern YT_SEARCH = Pattern.compile(
            "(?:youtube\\s+and\\s+search(?:\\s+for)?|youtube\\s+search(?:\\s+for)?"
                    + "|search\\s+(?:on\\s+|in\\s+)?youtube(?:\\s+for)?)\\s+(.+)");
    private static final Pattern YT_PLAY = Pattern.compile("^play\\s+(.+)");
    private static final Pattern YT_PREFIX = Pattern.compile("^youtube\\s+(.+)$");
    private static final Pattern OPEN = Pattern.compile(
            "^(?:open|launch|start|run)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$");
    private static final Pattern WEB = Pattern.compile("^(?:google|search for|search|look up)\\s+(.+)");

    private View root;
    private ArcReactorView reactor;
    private TextView status;
    private TextView logView;
    private ScrollView logScroll;
    private EditText input;
    private Button btnTorch;
    private ImageButton btnMic;
    private ObjectAnimator micPulse;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean listenAfterSpeak = false;
    private boolean pendingYoutube = false;
    private boolean listening = false;
    private SpeechRecognizer recognizer;

    private CameraManager camMgr;
    private String torchId;
    private boolean torchOn = false;
    private boolean torchBusy = false;

    private final SpannableStringBuilder logText = new SpannableStringBuilder();
    private final Random random = new Random();

    private final CameraManager.TorchCallback torchCallback = new CameraManager.TorchCallback() {
        @Override
        public void onTorchModeChanged(String cameraId, boolean enabled) {
            if (cameraId.equals(torchId)) {
                torchOn = enabled;
                torchBusy = false;
                runOnUiThread(() -> btnTorch.setText(enabled ? "FLASH: ON" : "FLASH: OFF"));
            }
        }

        @Override
        public void onTorchModeUnavailable(String cameraId) {
            if (cameraId.equals(torchId)) {
                torchBusy = true;
                runOnUiThread(() -> btnTorch.setText("FLASH: BUSY"));
            }
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        reactor = findViewById(R.id.reactor);
        status = findViewById(R.id.status);
        logView = findViewById(R.id.log);
        logScroll = findViewById(R.id.logScroll);
        input = findViewById(R.id.input);
        btnTorch = findViewById(R.id.btnTorch);
        btnMic = findViewById(R.id.btnMic);

        setupButtons();
        initTorch();
        initTts();

        // Intro animation
        root.setAlpha(0f);
        root.animate().alpha(1f).setDuration(700).start();
        reactor.setScaleX(0.6f);
        reactor.setScaleY(0.6f);
        reactor.animate().scaleX(1f).scaleY(1f).setDuration(900)
                .setInterpolator(new OvershootInterpolator(1.2f)).start();

        appendLog("SYSTEM   ", "Boot sequence complete.", DIM);
        setStatus("STANDBY");
    }

    @Override
    protected void onStop() {
        super.onStop();
        listenAfterSpeak = false;
        if (listening) {
            cancelListening();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (micPulse != null) micPulse.cancel();
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        if (camMgr != null) {
            try {
                camMgr.unregisterTorchCallback(torchCallback);
            } catch (Exception ignored) {
            }
        }
    }

    // ------------------------------------------------------------------ UI setup

    private void setupButtons() {
        findViewById(R.id.btnYoutube).setOnClickListener(v -> handle("open youtube"));
        findViewById(R.id.btnInstagram).setOnClickListener(v -> handle("open instagram"));
        findViewById(R.id.btnTelegram).setOnClickListener(v -> handle("open telegram"));
        findViewById(R.id.btnWhatsapp).setOnClickListener(v -> handle("open whatsapp"));
        btnTorch.setOnClickListener(v -> handle("toggle flashlight"));
        findViewById(R.id.btnSearch).setOnClickListener(v -> askYoutubeQuery());
        findViewById(R.id.btnApps).setOnClickListener(v -> showApps());
        findViewById(R.id.btnSend).setOnClickListener(v -> submitText());
        btnMic.setOnClickListener(v -> {
            if (listening) {
                cancelListening();
            } else {
                startListening();
            }
        });

        input.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                submitText();
                return true;
            }
            return false;
        });

        int[] ids = {R.id.btnYoutube, R.id.btnInstagram, R.id.btnTelegram, R.id.btnWhatsapp,
                R.id.btnTorch, R.id.btnSearch, R.id.btnApps, R.id.btnSend, R.id.btnMic};
        for (int id : ids) {
            addPressAnim(findViewById(id));
        }

        micPulse = ObjectAnimator.ofPropertyValuesHolder(btnMic,
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.18f),
                PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.18f));
        micPulse.setDuration(550);
        micPulse.setRepeatCount(ObjectAnimator.INFINITE);
        micPulse.setRepeatMode(ObjectAnimator.REVERSE);
    }

    @SuppressLint("ClickableViewAccessibility")
    private void addPressAnim(View v) {
        v.setOnTouchListener((view, ev) -> {
            int a = ev.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            }
            return false;
        });
    }

    private void submitText() {
        String t = input.getText().toString().trim();
        if (t.isEmpty()) return;
        input.setText("");
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
        handle(t);
    }

    private void setStatus(String s) {
        status.setText(s);
        status.setAlpha(0.3f);
        status.animate().alpha(1f).setDuration(250).start();
    }

    private void appendLog(String who, String msg, int color) {
        int start = logText.length();
        logText.append(who).append(msg).append("\n\n");
        logText.setSpan(new ForegroundColorSpan(color), start, start + who.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if (logText.length() > 8000) {
            logText.delete(0, 3000);
        }
        logView.setText(logText);
        logView.setAlpha(0.5f);
        logView.animate().alpha(1f).setDuration(250).start();
        logScroll.post(() -> logScroll.fullScroll(View.FOCUS_DOWN));
    }

    private void setListeningUi(boolean on) {
        listening = on;
        reactor.setActive(on);
        if (on) {
            setStatus("LISTENING...");
            if (!micPulse.isStarted()) micPulse.start();
        } else {
            micPulse.cancel();
            btnMic.setScaleX(1f);
            btnMic.setScaleY(1f);
            reactor.setLevel(0f);
        }
    }

    // ------------------------------------------------------------------ text to speech

    private void initTts() {
        tts = new TextToSpeech(this, st -> {
            if (st != TextToSpeech.SUCCESS || tts == null) {
                runOnUiThread(() -> setStatus("VOICE OUTPUT UNAVAILABLE"));
                return;
            }
            int r = tts.setLanguage(Locale.US);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.getDefault());
            }
            tts.setPitch(0.8f);
            tts.setSpeechRate(0.95f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                    runOnUiThread(() -> reactor.setActive(true));
                }

                @Override
                public void onDone(String utteranceId) {
                    runOnUiThread(() -> speechFinished());
                }

                @Override
                @SuppressWarnings("deprecation")
                public void onError(String utteranceId) {
                    runOnUiThread(() -> speechFinished());
                }
            });
            ttsReady = true;
            runOnUiThread(this::greet);
        });
    }

    private void speechFinished() {
        reactor.setActive(listening);
        if (listenAfterSpeak) {
            listenAfterSpeak = false;
            startListening();
        }
    }

    private void greet() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String part = h < 12 ? "Good morning" : (h < 18 ? "Good afternoon" : "Good evening");
        say(part + ". Jarvis online. How can I help you?");
    }

    private void say(String text) {
        appendLog("JARVIS   ", text, CYAN);
        speak(text);
    }

    private void speak(String text) {
        if (ttsReady && tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-" + System.nanoTime());
        }
    }

    private void sayThenListen(String text) {
        appendLog("JARVIS   ", text, CYAN);
        if (ttsReady && tts != null) {
            listenAfterSpeak = true;
            speak(text);
        } else {
            startListening();
        }
    }

    // ------------------------------------------------------------------ speech recognition

    private void startListening() {
        listenAfterSpeak = false;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
            return;
        }
        if (tts != null) tts.stop();

        Intent i = buildRecognizerIntent();

        if (recognizer == null) {
            recognizer = createRecognizer();
        }
        if (recognizer == null) {
            // Fallback: system voice dialog, if any speech app exists.
            try {
                startActivityForResult(i, REQ_VOICE_DIALOG);
            } catch (Exception e) {
                say("Speech recognition is not available on this phone. Install or enable the Google app, "
                        + "or type commands instead.");
            }
            return;
        }

        try {
            recognizer.startListening(i);
            setListeningUi(true);
        } catch (Exception e) {
            destroyRecognizer();
            setListeningUi(false);
            setStatus("VOICE ERROR - TAP THE MIC AGAIN");
        }
    }

    private Intent buildRecognizerIntent() {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, RECOGNITION_LANG);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, RECOGNITION_LANG);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L);
        i.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 800L);
        return i;
    }

    private SpeechRecognizer createRecognizer() {
        SpeechRecognizer r = null;
        try {
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                r = SpeechRecognizer.createSpeechRecognizer(this);
            } else if (Build.VERSION.SDK_INT >= 33
                    && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                r = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            }
        } catch (Exception e) {
            r = null;
        }
        if (r != null) {
            r.setRecognitionListener(recognitionListener);
        }
        return r;
    }

    private void destroyRecognizer() {
        if (recognizer != null) {
            try {
                recognizer.destroy();
            } catch (Exception ignored) {
            }
            recognizer = null;
        }
    }

    private void cancelListening() {
        if (recognizer != null) {
            try {
                recognizer.cancel();
            } catch (Exception ignored) {
            }
        }
        setListeningUi(false);
        setStatus("STANDBY");
    }

    private final RecognitionListener recognitionListener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
            setStatus("LISTENING...");
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
            reactor.setLevel((rmsdB + 2f) / 12f);
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
            setStatus("PROCESSING...");
        }

        @Override
        public void onError(int error) {
            setListeningUi(false);
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    setStatus("DIDN'T CATCH THAT - TAP THE MIC");
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    setStatus("MICROPHONE PERMISSION NEEDED");
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                case SpeechRecognizer.ERROR_SERVER:
                    setStatus("VOICE NEEDS INTERNET ON THIS PHONE");
                    break;
                case SpeechRecognizer.ERROR_AUDIO:
                    setStatus("MICROPHONE BUSY OR UNAVAILABLE");
                    break;
                case SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED:
                case SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE:
                    setStatus("ENGLISH VOICE PACK MISSING - CHECK GOOGLE APP VOICE SETTINGS");
                    break;
                case SpeechRecognizer.ERROR_TOO_MANY_REQUESTS:
                    setStatus("VOICE ENGINE BUSY - WAIT A MOMENT");
                    break;
                default:
                    // ERROR_CLIENT, RECOGNIZER_BUSY, SERVER_DISCONNECTED...: rebuild the recognizer.
                    destroyRecognizer();
                    setStatus("VOICE ENGINE RESET - TAP THE MIC AGAIN");
                    break;
            }
        }

        @Override
        public void onResults(Bundle results) {
            setListeningUi(false);
            ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            String best = pickBest(r);
            if (best != null) {
                handle(best);
            } else {
                setStatus("DIDN'T CATCH THAT - TAP THE MIC");
            }
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            ArrayList<String> r = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (r != null && !r.isEmpty() && !r.get(0).isEmpty()) {
                status.setText("> " + r.get(0));
            }
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_AUDIO || grantResults.length == 0) return;
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            say("Microphone permission is blocked. Opening settings. Please allow Microphone, then come back.");
            try {
                Intent st = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.fromParts("package", getPackageName(), null));
                st.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(st);
            } catch (Exception ignored) {
            }
        } else {
            say("I need microphone permission to hear you. You can still type commands.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_VOICE_DIALOG && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) {
                handle(r.get(0));
            }
        }
    }

    // ------------------------------------------------------------------ command engine

    private void handle(String raw) {
        if (raw == null) return;
        String shown = raw.trim();
        if (shown.isEmpty()) return;
        appendLog("YOU      ", shown, WHITE_BLUE);

        String l = shown.toLowerCase(Locale.ROOT)
                .replaceAll("[.!?,]+$", "").trim().replaceAll("\\s+", " ");
        l = l.replaceFirst("^(?:hey |ok |okay )?jarvis[ ,]*", "")
                .replaceFirst("^please ", "").replaceFirst(" please$", "").trim();

        if (l.isEmpty()) {
            say("Yes? I'm listening.");
            return;
        }

        // Follow-up to "what should I search on YouTube?"
        if (pendingYoutube) {
            pendingYoutube = false;
            if (l.equals("cancel") || l.equals("never mind") || l.equals("nevermind")) {
                say("Cancelled.");
            } else {
                youtubeSearch(l);
            }
            return;
        }

        // Flashlight
        if (l.contains("flashlight") || l.contains("flash light") || l.contains("torch")) {
            if (l.matches(".*\\b(off|disable|close)\\b.*")) {
                setTorch(false);
            } else if (l.matches(".*\\b(on|enable|start)\\b.*")) {
                setTorch(true);
            } else {
                setTorch(!torchOn);
            }
            return;
        }

        // YouTube voice search
        if (YT_BARE.matcher(l).find()) {
            askYoutubeQuery();
            return;
        }
        String q = extractYoutubeQuery(l);
        if (q != null) {
            youtubeSearch(q);
            return;
        }

        // Open apps
        Matcher m = OPEN.matcher(l);
        if (m.find()) {
            openApp(m.group(1).trim());
            return;
        }
        if (findKnown(l) != null && l.length() <= 12) {
            openApp(l);
            return;
        }

        // Web search
        m = WEB.matcher(l);
        if (m.find()) {
            String term = m.group(1).trim();
            say("Searching the web for " + term + ".");
            openUrl("https://www.google.com/search?q=" + Uri.encode(term));
            return;
        }

        // Info
        if (l.contains("time")) {
            say("It is " + new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date()) + ".");
        } else if (l.contains("date") || l.contains("today") || l.contains("what day")) {
            say("Today is " + new SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(new Date()) + ".");
        } else if (l.contains("battery")) {
            say(batteryText());
        } else if (l.contains("joke")) {
            say(JOKES[random.nextInt(JOKES.length)]);
        } else if (l.matches(".*\\b(who are you|your name)\\b.*")) {
            say("I am Jarvis Ultimate two point zero, your personal assistant, running entirely on your phone.");
        } else if (l.matches("^(hello|hi|hey|yo|good morning|good evening|good afternoon)\\b.*")) {
            say("Hello! What can I do for you?");
        } else if (l.contains("thank")) {
            say("Always at your service.");
        } else if (l.matches("^(stop|quiet|silence|shut up|be quiet)$")) {
            if (tts != null) tts.stop();
            appendLog("JARVIS   ", "Silenced.", CYAN);
        } else if (l.contains("help") || l.contains("what can you do")) {
            say("I can open YouTube, Instagram, Telegram, WhatsApp or any installed app. "
                    + "Say play, followed by a song, to search YouTube. "
                    + "I can control the flashlight, and tell you the time, date and battery level.");
        } else {
            say("Sorry, I didn't understand that. Say help to hear what I can do.");
        }
    }

    private String extractYoutubeQuery(String l) {
        Matcher m = YT_ON.matcher(l);
        if (m.find()) return cleanQuery(m.group(1));
        m = YT_SEARCH.matcher(l);
        if (m.find()) return cleanQuery(m.group(1));
        m = YT_PLAY.matcher(l);
        if (m.find()) return cleanQuery(m.group(1));
        m = YT_PREFIX.matcher(l);
        if (m.find()) {
            String rest = m.group(1).trim();
            if (!rest.equals("app") && !rest.equals("application")) return cleanQuery(rest);
        }
        return null;
    }

    private String cleanQuery(String q) {
        String s = q.trim()
                .replaceFirst("^(?:for|me|some)\\s+", "")
                .replaceFirst("\\s+(?:on|in)\\s+youtube$", "")
                .replaceFirst("\\s+please$", "")
                .trim();
        return s.isEmpty() ? null : s;
    }

    /** Speech engines return several guesses; prefer the first one that looks like a command. */
    private String pickBest(List<String> candidates) {
        if (candidates == null || candidates.isEmpty()) return null;
        for (String c : candidates) {
            if (c != null && looksLikeCommand(c)) return c;
        }
        String first = candidates.get(0);
        return (first == null || first.trim().isEmpty()) ? null : first;
    }

    private boolean looksLikeCommand(String s) {
        String l = s.toLowerCase(Locale.ROOT).trim();
        return l.matches("^(?:(?:hey |ok |okay )?jarvis[ ,]*)?(?:please )?"
                + "(?:open|launch|start|run|play|search|google|look up|youtube|stop|help|hello|hi|hey|thank).*")
                || l.matches(".*\\b(flashlight|flash light|torch|battery|time|date|joke|who are you|your name"
                + "|youtube|instagram|telegram|whatsapp)\\b.*");
    }

    private String batteryText() {
        Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (b == null) return "I couldn't read the battery level.";
        int level = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        int st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        if (level < 0 || scale <= 0) return "I couldn't read the battery level.";
        int pct = Math.round(level * 100f / scale);
        boolean charging = st == BatteryManager.BATTERY_STATUS_CHARGING
                || st == BatteryManager.BATTERY_STATUS_FULL;
        return "Battery is at " + pct + " percent" + (charging ? " and charging." : ".");
    }

    // ------------------------------------------------------------------ apps & web

    private String[] findKnown(String name) {
        String n = name.replace(" ", "");
        if (n.isEmpty()) return null;
        for (String[] k : KNOWN_APPS) {
            if (n.equals(k[0]) || (n.length() >= 5 && k[0].startsWith(n))) return k;
        }
        return null;
    }

    private void openApp(String name) {
        String[] k = findKnown(name);
        if (k != null) {
            for (int i = 3; i < k.length; i++) {
                if (launchPackage(k[i])) {
                    say("Opening " + k[1] + ".");
                    return;
                }
            }
            say(k[1] + " is not installed. Opening it in your browser.");
            openUrl(k[2]);
            return;
        }

        ResolveInfo ri = findInstalledApp(name);
        if (ri != null) {
            String label = ri.loadLabel(getPackageManager()).toString();
            if (launchPackage(ri.activityInfo.packageName)) {
                say("Opening " + label + ".");
                return;
            }
        }
        say("I couldn't find an app called " + name + ".");
    }

    private boolean launchPackage(String pkg) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private List<ResolveInfo> launchables() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = new ArrayList<>(pm.queryIntentActivities(main, 0));
        Collections.sort(list, new ResolveInfo.DisplayNameComparator(pm));
        return list;
    }

    private ResolveInfo findInstalledApp(String name) {
        String n = name.toLowerCase(Locale.ROOT).trim();
        PackageManager pm = getPackageManager();
        ResolveInfo startsWith = null;
        ResolveInfo contains = null;
        ResolveInfo reverse = null;
        for (ResolveInfo ri : launchables()) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            if (label.equals(n)) return ri;
            if (startsWith == null && label.startsWith(n)) startsWith = ri;
            if (contains == null && label.contains(n)) contains = ri;
            if (reverse == null && label.length() >= 3 && n.contains(label)) reverse = ri;
        }
        if (startsWith != null) return startsWith;
        if (contains != null) return contains;
        return reverse;
    }

    private void showApps() {
        final PackageManager pm = getPackageManager();
        final List<ResolveInfo> apps = launchables();
        final String[] names = new String[apps.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = apps.get(i).loadLabel(pm).toString();
        }
        new AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                .setTitle("INSTALLED APPS")
                .setItems(names, (d, which) -> {
                    if (launchPackage(apps.get(which).activityInfo.packageName)) {
                        say("Opening " + names[which] + ".");
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private void openUrl(String url) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(i);
        } catch (Exception e) {
            say("I couldn't find a browser to open that.");
        }
    }

    private void askYoutubeQuery() {
        pendingYoutube = true;
        sayThenListen("What would you like to search on YouTube?");
    }

    private void youtubeSearch(String query) {
        say("Searching YouTube for " + query + ".");
        String url = "https://www.youtube.com/results?search_query=" + Uri.encode(query);

        // 1) Deep link straight into the YouTube app's search results.
        Intent app = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        app.setPackage("com.google.android.youtube");
        app.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(app);
            return;
        } catch (Exception ignored) {
        }

        // 2) YouTube's own search action.
        Intent search = new Intent(Intent.ACTION_SEARCH);
        search.setPackage("com.google.android.youtube");
        search.putExtra(SearchManager.QUERY, query);
        search.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(search);
            return;
        } catch (Exception ignored) {
        }

        // 3) Browser.
        openUrl(url);
    }

    // ------------------------------------------------------------------ flashlight

    private void initTorch() {
        camMgr = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        if (camMgr == null) return;
        try {
            String fallback = null;
            for (String id : camMgr.getCameraIdList()) {
                CameraCharacteristics cc = camMgr.getCameraCharacteristics(id);
                Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                if (flash == null || !flash) continue;
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    torchId = id;
                    break;
                }
                if (fallback == null) fallback = id;
            }
            if (torchId == null) torchId = fallback;
            if (torchId != null) {
                camMgr.registerTorchCallback(torchCallback, null);
            }
        } catch (CameraAccessException | RuntimeException e) {
            torchId = null;
        }
    }

    private void setTorch(boolean on) {
        if (camMgr == null || torchId == null) {
            say("This phone has no flashlight that I can control.");
            return;
        }
        if (torchBusy) {
            say("The camera is in use by another app, so I can't reach the flashlight right now.");
            return;
        }
        try {
            camMgr.setTorchMode(torchId, on);
            say(on ? "Flashlight on." : "Flashlight off.");
        } catch (CameraAccessException e) {
            int reason = e.getReason();
            if (reason == CameraAccessException.CAMERA_IN_USE
                    || reason == CameraAccessException.MAX_CAMERAS_IN_USE) {
                say("The camera is in use by another app, so I can't reach the flashlight right now.");
            } else {
                say("I couldn't control the flashlight.");
            }
        } catch (RuntimeException e) {
            say("I couldn't control the flashlight.");
        }
    }
}
