(function () {
  // ---------- सेव डेटा ----------
  const def = { coins: 0, up: { hp: 0, dmg: 0, spd: 0, coin: 0 }, own: [0], ch: 0, day: {} };
  let S;
  try { S = Object.assign({}, def, JSON.parse(localStorage.getItem('jsMeta') || '{}')); }
  catch (e) { S = Object.assign({}, def); }
  S.up = Object.assign({}, def.up, S.up);
  const today = new Date().toDateString();
  if (S.day.d !== today) S.day = { d: today, kills: 0, bosses: 0, wave: 0, done: [false, false, false] };
  const D = S.day;
  const save = () => { try { localStorage.setItem('jsMeta', JSON.stringify(S)); } catch (e) {} };

  const CH = [
    { n: 'सैनिक', ic: '🪖', d: 'संतुलित किरदार, हेलमेट के साथ', cost: 0, col: '#f2e3b8', hp: 0, spd: 1, dmg: 0, rate: 1 },
    { n: 'फुर्तीला', ic: '⚡', d: 'चाल +25%, हेल्थ 80, लाल पट्टी', cost: 400, col: '#7fd1ff', hp: -20, spd: 1.25, dmg: 0, rate: 1 },
    { n: 'टैंक', ic: '🛡️', d: 'हेल्थ 160, चाल -10%, मोटा कवच', cost: 700, col: '#c98a5b', hp: 60, spd: 0.9, dmg: 0, rate: 1 },
    { n: 'निशानेबाज़', ic: '🎯', d: 'गोली ताक़त +1, फ़ायर 20% धीमा, लेज़र', cost: 1000, col: '#d96ad6', hp: 0, spd: 1, dmg: 1, rate: 1.2 }
  ];
  const UP = [
    { k: 'hp', n: 'शुरुआती हेल्थ', d: 'हर स्तर +10 हेल्थ', max: 10, base: 50 },
    { k: 'dmg', n: 'शुरुआती ताक़त', d: 'हर स्तर +0.25 नुक़सान', max: 4, base: 120 },
    { k: 'spd', n: 'शुरुआती चाल', d: 'हर स्तर +4% रफ़्तार', max: 5, base: 80 },
    { k: 'coin', n: 'सिक्का बोनस', d: 'हर स्तर +20% सिक्के', max: 5, base: 100 }
  ];
  const M = [
    { k: 'kills', t: 'आज 150 दुश्मन मारो', n: 150, r: 60 },
    { k: 'bosses', t: 'आज 2 बॉस मारो', n: 2, r: 80 },
    { k: 'wave', t: 'किसी खेल में लहर 15 तक पहुँचो', n: 15, r: 100 }
  ];

  let run = { coins: 0, kills: 0, bosses: 0, bc: 0, bk: 0, bb: 0, revived: false };

  // ---------- नक्शे (हर 5 लहर पर बदलते हैं) ----------
  const TH = [
    { name: 'बर्फ़ीला मैदान', bg: '#8fb0c4', dot: 'rgba(255,255,255,.18)', pat: 'rgba(255,255,255,.13)', dark: false, pn: '24,52,74', accent: '#2f7fc4', ink: '#ffffff', vg: 0.22 },
    { name: 'घना जंगल', bg: '#4c6b3a', dot: 'rgba(0,0,0,.08)', pat: 'rgba(0,0,0,.07)', dark: false, pn: '31,48,27', accent: '#e8643c', ink: '#fff7e0', vg: 0.25 },
    { name: 'रेगिस्तान', bg: '#a88a52', dot: 'rgba(0,0,0,.07)', pat: 'rgba(255,230,170,.20)', dark: false, pn: '62,44,20', accent: '#c4572b', ink: '#fff3d6', vg: 0.25 },
    { name: 'पहाड़ी', bg: '#7a7f86', dot: 'rgba(0,0,0,.07)', pat: 'rgba(0,0,0,.08)', dark: false, pn: '38,42,48', accent: '#b8691c', ink: '#f2f2f2', vg: 0.25 },
    { name: 'ज्वालामुखी', bg: '#3a2f2c', dot: 'rgba(255,255,255,.05)', pat: 'rgba(0,0,0,.25)', dark: true, pn: '40,20,16', accent: '#ff5a2e', ink: '#ffe9d6', vg: 0.4 },
    { name: 'रात का जंगल', bg: '#1f3d44', dot: 'rgba(255,255,255,.05)', pat: 'rgba(0,0,0,.20)', dark: true, pn: '8,26,32', accent: '#1fa385', ink: '#e6fff6', vg: 0.4 }
  ];
  const themeIdx = w => Math.floor((Math.max(1, w) - 1) / 5) % TH.length;
  const themeCss = document.createElement('style');
  document.head.appendChild(themeCss);
  let lastIdx = -1;
  function applyTheme(i) {
    const t = TH[i];
    themeCss.textContent =
      ':root{--pnr:' + t.pn + ';--acc:' + t.accent + ';--ink:' + t.ink + '}' +
      '#stick{border-color:var(--ink)}#knob{background:var(--ink)}' +
      '#fire{background:var(--acc);border-color:var(--ink);color:var(--ink)}#fire:active{filter:brightness(.8)}' +
      '#start{background:var(--acc);color:var(--ink)}' +
      '#overlay{background:rgba(var(--pnr),.88);color:var(--ink)}' +
      '#shop{background:rgb(var(--pnr));color:var(--ink)}#shop button{background:var(--acc);color:var(--ink)}';
  }

  // ---------- स्क्रीन के हिस्से और नया HUD ----------
  const css = document.createElement('style');
  css.textContent = `
  #hud{color:var(--ink);text-shadow:0 1px 3px rgba(0,0,0,.55)}
  #hud::before{content:"";position:absolute;left:-12px;right:-12px;top:-12px;height:116px;background:linear-gradient(rgba(var(--pnr),.7),rgba(var(--pnr),0));z-index:-1;pointer-events:none}
  #left{width:210px}
  #hpWrap{position:relative;height:22px;border:2px solid var(--ink);border-radius:12px;background:rgba(0,0,0,.45);box-shadow:0 2px 6px rgba(0,0,0,.35)}
  #hp{border-radius:10px;background:linear-gradient(180deg,rgba(255,255,255,.35),rgba(255,255,255,0) 55%),var(--acc)}
  #hpWrap::after{content:"❤";position:absolute;left:7px;top:50%;transform:translateY(-50%);font-size:11px;text-shadow:none}
  #wave{align-self:flex-start;padding:3px 12px;border-radius:999px;background:rgba(var(--pnr),.75);border:1.5px solid var(--ink);font-size:15px;box-shadow:0 2px 6px rgba(0,0,0,.3)}
  #right{align-items:flex-end;gap:3px}
  #score{padding:2px 12px;border-radius:12px;background:rgba(var(--pnr),.75);border:1.5px solid var(--ink);font-size:22px;font-weight:800;box-shadow:0 2px 6px rgba(0,0,0,.3)}
  #best{font-size:13px;opacity:.9;padding-right:4px}
  #btns{top:78px;gap:8px}
  .ib{width:40px;height:40px;font-size:17px;background:rgba(var(--pnr),.7);border:1.5px solid var(--ink);color:var(--ink);box-shadow:0 2px 6px rgba(0,0,0,.3);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}
  .ib:active{transform:scale(.92)}
  #coinHud{position:fixed;top:76px;left:12px;padding:3px 12px;border-radius:999px;background:rgba(0,0,0,.4);color:#ffd85c;font-weight:800;font-size:16px;pointer-events:none}
  div[style*="top:92px"],div[style*="top: 92px"]{top:110px !important;padding:3px 12px;border-radius:999px;background:rgba(0,0,0,.4)}
  div[style*="top:92px"]:empty,div[style*="top: 92px"]:empty{display:none}
  #shop{position:fixed;inset:0;z-index:30;display:none;overflow-y:auto;padding:18px}
  #shop h2{margin:6px 0 10px;font-size:24px}#shop h3{margin:18px 0 4px}
  #shop .row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;margin:8px 0;border:2px solid currentColor;border-radius:12px;background:rgba(255,255,255,.06)}
  #shop small{display:block;opacity:.8;margin-top:2px}
  #shop button{padding:9px 14px;border:0;border-radius:10px;font-weight:800;font-size:15px}
  #shop button:disabled{opacity:.45}
  .mbtn{padding:12px 24px;border:0;border-radius:12px;background:#3b8ee0;color:#fff7e0;font-size:17px;font-weight:800}
  #infoEl{font-size:15px;line-height:1.7;max-width:340px}
  #overlay{overflow-y:auto}`;
  document.head.appendChild(css);

  const coinHud = document.createElement('div'); coinHud.id = 'coinHud';
  const infoEl = document.createElement('div'); infoEl.id = 'infoEl';
  const reviveBtn = document.createElement('button'); reviveBtn.className = 'mbtn'; reviveBtn.style.display = 'none';
  reviveBtn.style.background = '#3fae5a';
  const shopBtn = document.createElement('button'); shopBtn.className = 'mbtn'; shopBtn.textContent = '🛒 दुकान';
  const shop = document.createElement('div'); shop.id = 'shop';
  document.body.append(coinHud, shop);
  msgEl.after(infoEl); startBtn.before(reviveBtn); startBtn.after(shopBtn);

  const hud = () => { coinHud.textContent = '🪙 ' + (S.coins + run.coins - run.bc); };
  const info = () => {
    infoEl.innerHTML = '🪙 ' + S.coins + ' सिक्के<br>' +
      M.map((m, i) => (D.done[i] ? '✅ ' : '⬜ ') + m.t + ' (' + Math.min(D[m.k], m.n) + '/' + m.n + ')').join('<br>');
    hud();
  };

  // ---------- दुकान ----------
  function render() {
    let h = '<h2>दुकान · 🪙 ' + S.coins + '</h2><h3>स्थायी अपग्रेड</h3>';
    UP.forEach(u => {
      const l = S.up[u.k], c = u.base * (l + 1), mx = l >= u.max;
      h += `<div class="row"><div>${u.n} (${l}/${u.max})<small>${u.d}</small></div>
        <button data-u="${u.k}" ${mx || S.coins < c ? 'disabled' : ''}>${mx ? 'पूरा' : '🪙 ' + c}</button></div>`;
    });
    h += '<h3>किरदार</h3>';
    CH.forEach((c, i) => {
      const own = S.own.includes(i), sel = S.ch === i;
      h += `<div class="row"><div><span style="color:${c.col}">●</span> ${c.ic} ${c.n}<small>${c.d}</small></div>
        <button data-c="${i}" ${sel || (!own && S.coins < c.cost) ? 'disabled' : ''}>${sel ? 'चुना हुआ' : own ? 'चुनें' : '🪙 ' + c.cost}</button></div>`;
    });
    h += '<button id="shopClose" style="margin:16px 0 30px;width:100%;background:#3b8ee0;color:#fff">वापस जाएँ</button>';
    shop.innerHTML = h;
  }
  shopBtn.addEventListener('click', () => { render(); shop.style.display = 'block'; });
  shop.addEventListener('click', e => {
    const b = e.target.closest('button');
    if (!b) return;
    if (b.id === 'shopClose') { shop.style.display = 'none'; info(); return; }
    if (b.dataset.u) {
      const u = UP.find(x => x.k === b.dataset.u), l = S.up[u.k], c = u.base * (l + 1);
      if (l < u.max && S.coins >= c) { S.coins -= c; S.up[u.k]++; }
    } else if (b.dataset.c !== undefined) {
      const i = +b.dataset.c, c = CH[i];
      if (S.own.includes(i)) S.ch = i;
      else if (S.coins >= c.cost) { S.coins -= c.cost; S.own.push(i); S.ch = i; }
    }
    save(); render();
  });

  // ---------- गेम से जोड़ना ----------
  const _reset = reset;
  reset = function () {
    _reset();
    const c = CH[S.ch];
    p.maxHp = 100 + c.hp + S.up.hp * 10; p.hp = p.maxHp;
    p.speedMul = c.spd * (1 + 0.04 * S.up.spd);
    p.dmg = 1 + c.dmg + 0.25 * S.up.dmg;
    p.rateMul = c.rate;
    run = { coins: 0, kills: 0, bosses: 0, bc: 0, bk: 0, bb: 0, revived: false };
    reviveBtn.style.display = 'none';
    lastIdx = themeIdx(wave);
    applyTheme(lastIdx);
    updateHud();
  };

  const _uh = updateHud;
  updateHud = function () { _uh(); hud(); };

  const _drop = dropItem;
  dropItem = function (x, y, always) {
    run.kills++;
    let c = 1 + (wave > 10 ? 1 : 0);
    if (always) { run.bosses++; c = 25 + wave; }
    run.coins += Math.round(c * (1 + 0.2 * S.up.coin));
    hud();
    _drop(x, y, always);
  };

  function bank() {
    S.coins += run.coins - run.bc; run.bc = run.coins;
    D.kills += run.kills - run.bk; run.bk = run.kills;
    D.bosses += run.bosses - run.bb; run.bb = run.bosses;
    D.wave = Math.max(D.wave, wave);
    let b = 0;
    M.forEach((m, i) => { if (!D.done[i] && D[m.k] >= m.n) { D.done[i] = true; S.coins += m.r; b += m.r; } });
    save();
    return b;
  }

  const _over = gameOver;
  gameOver = function () {
    _over();
    const gain = run.coins - run.bc, bonus = bank();
    msgEl.textContent += ' · 🪙 +' + gain + (bonus ? ' · मिशन बोनस +' + bonus : '');
    if (!run.revived) {
      reviveBtn.textContent = '▶ विज्ञापन देखकर दोबारा ज़िंदा हों';
      reviveBtn.disabled = false;
      reviveBtn.style.display = 'block';
    }
    info();
  };

  const _pause = pauseGame;
  pauseGame = function () { _pause(); reviveBtn.style.display = 'none'; info(); };

  // नमूना विज्ञापन: असली विज्ञापन ऐप बनाते समय (चरण 3) जुड़ेंगे
  reviveBtn.addEventListener('click', () => {
    let t = 5;
    reviveBtn.disabled = true;
    reviveBtn.textContent = 'नमूना विज्ञापन… ' + t;
    const iv = setInterval(() => {
      t--;
      if (t <= 0) { clearInterval(iv); revive(); }
      else reviveBtn.textContent = 'नमूना विज्ञापन… ' + t;
    }, 1000);
  });
  function revive() {
    run.revived = true;
    p.hp = p.maxHp * 0.6; p.hurt = 2;
    ebullets = [];
    enemies = enemies.filter(e => e.type === 'boss' || Math.hypot(e.x - p.x, e.y - p.y) > 220);
    reviveBtn.style.display = 'none';
    overlay.classList.add('hidden');
    running = true; paused = false; last = performance.now();
    updateHud();
    requestAnimationFrame(loop);
  }

  // ---------- ग्राफ़िक्स: मदद करने वाले फ़ंक्शन ----------
  let decos = null, amb = null, patches = [];
  const seeded = seed => { let s = seed; return () => (s = (s * 9301 + 49297) % 233280) / 233280; };
  const circ = (x, y, r, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); };
  const ell = (x, y, rx, ry, col) => { ctx.fillStyle = col; ctx.beginPath(); ctx.ellipse(x, y, rx, ry, 0, 0, 7); ctx.fill(); };
  const tri = (x, y, w, h) => { ctx.beginPath(); ctx.moveTo(x, y - h); ctx.lineTo(x + w, y); ctx.lineTo(x - w, y); ctx.closePath(); ctx.fill(); };
  const poly = (x, y, s, pts) => {
    ctx.beginPath();
    pts.forEach((q, i) => { const px = x + q[0] * s, py = y + q[1] * s; if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
    ctx.closePath(); ctx.fill();
  };
  const ROCK = [[-1, .3], [-.8, -.4], [-.2, -.9], [.5, -.7], [1, -.1], [.8, .5], [-.2, .6]];
  const GEM = [[0, -1], [.5, 0], [0, .8], [-.5, 0]];
  const shadow = (x, y, r) => ell(x, y + r * 0.8, r, r * 0.45, 'rgba(0,0,0,.22)');

  function mkDecos() {
    decos = [];
    const r = seeded(W * 7 + H);
    for (let i = 0; i < 24; i++) decos.push({ x: r() * W, y: r() * H, s: 10 + r() * 16, t: r() < 0.65 ? 0 : 1, v: r() });
    patches = [];
    const q = seeded(W * 5 + H * 3);
    for (let i = 0; i < 10; i++) patches.push({ x: q() * W, y: q() * H, rx: 60 + q() * 120, ry: 40 + q() * 80, a: q() * 3 });
    decos.w = W; decos.h = H;
  }
  function mkAmb() {
    amb = [];
    const r = seeded(W * 3 + H);
    for (let i = 0; i < 30; i++) amb.push({ x: r() * W, y: r() * H, ph: r() * 6.28, sp: 20 + r() * 40, sz: 1.5 + r() * 2.5 });
    amb.w = W; amb.h = H;
  }

  // ---------- हर नक्शे की सजावट ----------
  function drawDeco(d, idx, tm) {
    const x = d.x, y = d.y, s = d.s;
    if (idx === 0) { // बर्फ़ीला: चीड़ और बर्फ़ के ढेर
      if (d.t === 0) {
        ctx.fillStyle = '#5a4630'; ctx.fillRect(x - 2, y, 4, s * 0.35);
        for (let i = 0; i < 3; i++) {
          const w = s * (1 - i * 0.22), yy = y - i * s * 0.5;
          ctx.fillStyle = '#3f6b5e'; tri(x, yy, w, s * 0.85);
          ctx.fillStyle = '#f4fbff'; tri(x, yy - s * 0.3, w * 0.65, s * 0.55);
        }
      } else { ell(x, y + 3, s * 1.1, s * 0.5, 'rgba(70,100,125,.45)'); ell(x, y, s, s * 0.55, '#f4fbff'); }
    } else if (idx === 1) { // जंगल: पेड़ और झाड़ियाँ
      if (d.t === 0) {
        ell(x + s * 0.2, y + s * 0.5, s, s * 0.5, 'rgba(0,0,0,.18)');
        circ(x, y - s * 0.1, s, '#2f4a2a');
        circ(x - s * 0.25, y - s * 0.35, s * 0.62, '#3f6a34');
        circ(x + s * 0.3, y - s * 0.1, s * 0.35, '#365c2e');
      } else {
        ell(x, y, s * 0.9, s * 0.55, '#2f4a2a');
        circ(x - s * 0.2, y - s * 0.15, s * 0.4, '#3d5c30');
        if (d.v > 0.5) { circ(x + s * 0.3, y, 2.2, '#d94a4a'); circ(x - s * 0.45, y + 3, 2.2, '#d94a4a'); }
      }
    } else if (idx === 2) { // रेगिस्तान: कैक्टस और रेत के टीले
      if (d.t === 0) {
        ctx.lineCap = 'round'; ctx.lineJoin = 'round';
        ctx.strokeStyle = '#5f8a46'; ctx.lineWidth = s * 0.42;
        ctx.beginPath();
        ctx.moveTo(x, y); ctx.lineTo(x, y - s * 1.3);
        ctx.moveTo(x, y - s * 0.55); ctx.lineTo(x - s * 0.55, y - s * 0.55); ctx.lineTo(x - s * 0.55, y - s * 0.95);
        ctx.moveTo(x, y - s * 0.8); ctx.lineTo(x + s * 0.5, y - s * 0.8); ctx.lineTo(x + s * 0.5, y - s * 1.1);
        ctx.stroke();
        ctx.strokeStyle = 'rgba(255,255,255,.18)'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x - 2, y - 2); ctx.lineTo(x - 2, y - s * 1.2); ctx.stroke();
        ctx.lineCap = 'butt';
      } else { ell(x, y + 3, s * 1.2, s * 0.45, 'rgba(120,85,40,.35)'); ell(x, y, s * 1.1, s * 0.4, '#c3a56e'); }
    } else if (idx === 3) { // पहाड़ी: चट्टानें और कंकड़
      if (d.t === 0) {
        ctx.fillStyle = 'rgba(0,0,0,.2)'; poly(x + s * 0.2, y + s * 0.25, s * 1.05, ROCK);
        ctx.fillStyle = '#8c929a'; poly(x, y, s, ROCK);
        ctx.fillStyle = '#a9afb7'; poly(x - s * 0.15, y - s * 0.15, s * 0.6, ROCK);
      } else {
        circ(x, y, s * 0.3, '#6a7078'); circ(x + s * 0.5, y + s * 0.15, s * 0.2, '#7f858d'); circ(x - s * 0.4, y + s * 0.2, s * 0.22, '#6a7078');
      }
    } else if (idx === 4) { // ज्वालामुखी: दहकता लावा
      const pu = 0.7 + 0.3 * Math.sin(tm * 2 + d.v * 6);
      if (d.t === 0) {
        ell(x, y, s * 1.5, s * 0.95, 'rgba(255,90,30,' + (0.18 * pu) + ')');
        ell(x, y, s * 1.1, s * 0.7, '#2a1a16');
        ell(x, y, s * 0.9, s * 0.55, 'rgba(255,90,30,' + pu + ')');
        ell(x, y, s * 0.5, s * 0.3, '#ffc860');
      } else {
        ctx.fillStyle = '#2a1f1c'; poly(x, y, s * 0.8, ROCK);
        ctx.strokeStyle = 'rgba(255,110,40,' + pu + ')'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x - s * 0.4, y); ctx.lineTo(x, y - s * 0.2); ctx.lineTo(x + s * 0.4, y + s * 0.1); ctx.stroke();
      }
    } else { // रात का जंगल: चमकते मशरूम और क्रिस्टल
      const pu = 0.6 + 0.4 * Math.sin(tm * 1.6 + d.v * 6);
      if (d.t === 0) {
        circ(x, y - s * 0.3, s * 1.5, 'rgba(60,220,190,' + (0.1 * pu) + ')');
        ctx.fillStyle = '#c9f2e8'; ctx.fillRect(x - 2.5, y - s * 0.3, 5, s * 0.8);
        ell(x, y - s * 0.4, s * 0.85, s * 0.5, '#1fa385');
        circ(x - s * 0.25, y - s * 0.5, 2.5, '#c9fff0'); circ(x + s * 0.3, y - s * 0.35, 2, '#c9fff0');
      } else {
        circ(x, y, s * 1.1, 'rgba(90,180,255,' + (0.12 * pu) + ')');
        ctx.fillStyle = '#5fb8e8'; poly(x, y, s * 0.6, GEM);
        ctx.fillStyle = 'rgba(255,255,255,.5)'; poly(x - s * 0.05, y - s * 0.1, s * 0.3, GEM);
      }
    }
  }

  // ---------- हर नक्शे का मौसम/इफ़ेक्ट ----------
  function drawAmb(idx, tm) {
    if (!amb || amb.w !== W || amb.h !== H) mkAmb();
    const n = idx === 3 ? 6 : 30;
    for (let i = 0; i < n; i++) {
      const a = amb[i];
      if (idx === 0) { // बर्फ़ गिरती है
        const y = (a.y + tm * a.sp) % H, x = a.x + Math.sin(tm + a.ph) * 14;
        circ(x, y, a.sz, 'rgba(255,255,255,.8)');
      } else if (idx === 1) { // पत्ते झड़ते हैं
        const y = (a.y + tm * a.sp * 0.6) % H, x = a.x + Math.sin(tm * 0.8 + a.ph) * 30;
        ctx.save(); ctx.translate(x, y); ctx.rotate(tm + a.ph);
        ell(0, 0, a.sz * 2.2, a.sz * 1.1, ['#d8a53a', '#c9622a', '#8fae3e'][i % 3]);
        ctx.restore();
      } else if (idx === 2) { // रेत की आँधी की लकीरें
        const x = (a.x + tm * a.sp * 3) % (W + 60) - 30, y = a.y + Math.sin(tm + a.ph) * 6;
        ctx.strokeStyle = 'rgba(250,230,180,.35)'; ctx.lineWidth = 1.5;
        ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - 14 - a.sz * 6, y); ctx.stroke();
      } else if (idx === 3) { // बादल/कोहरा सरकता है
        const x = ((a.x + tm * a.sp * 0.4) % (W + 300)) - 150;
        ell(x, a.y, 150 + a.sz * 20, 40 + a.sz * 8, 'rgba(255,255,255,.08)');
      } else if (idx === 4) { // चिंगारियाँ ऊपर उठती हैं
        const y = (((a.y - tm * a.sp) % H) + H) % H, x = a.x + Math.sin(tm * 1.5 + a.ph) * 10;
        ctx.fillStyle = 'rgba(255,140,60,.85)'; ctx.fillRect(x, y, a.sz, a.sz);
      } else { // जुगनू
        const x = a.x + Math.sin(tm * 0.5 + a.ph) * 30, y = a.y + Math.cos(tm * 0.4 + a.ph) * 20;
        circ(x, y, a.sz, 'rgba(216,255,122,' + (0.35 + 0.35 * Math.sin(tm * 2 + a.ph)) + ')');
      }
    }
  }

  let vg = null, vgKey = '';
  function vignette(th) {
    const key = W + 'x' + H + ':' + th.vg;
    if (key !== vgKey) {
      vg = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.max(W, H) * 0.78);
      vg.addColorStop(0, 'rgba(0,0,0,0)');
      vg.addColorStop(1, 'rgba(0,0,0,' + th.vg + ')');
      vgKey = key;
    }
    ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
  }

  // ---------- किरदार: हर एक अलग दिखता है ----------
  function drawPlayer(ch) {
    const id = S.ch, r = p.r, dx = p.dx, dy = p.dy, ang = Math.atan2(dy, dx);
    const gl = r + [12, 12, 10, 24][id], gw = [6, 5, 9, 4][id];
    const tx = p.x + dx * gl, ty = p.y + dy * gl;
    shadow(p.x, p.y, r);
    if (id === 3) { // लेज़र
      ctx.strokeStyle = 'rgba(255,60,60,.4)'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(tx, ty); ctx.lineTo(tx + dx * 150, ty + dy * 150); ctx.stroke();
      circ(tx + dx * 150, ty + dy * 150, 2.5, 'rgba(255,80,80,.7)');
    }
    ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = gw;
    ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(tx, ty); ctx.stroke();
    if (p.flash > 0) circ(tx + dx * 4, ty + dy * 4, 8, '#fff3a0');
    if (p.spdT > 0) { ctx.strokeStyle = '#3b8ee0'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(p.x, p.y, r + 5, 0, 7); ctx.stroke(); }
    if (id === 1) { // गति की लकीरें
      ctx.strokeStyle = 'rgba(255,255,255,.4)'; ctx.lineWidth = 2;
      for (const o of [-6, 6]) {
        ctx.beginPath();
        ctx.moveTo(p.x - dx * (r + 2) - dy * o, p.y - dy * (r + 2) + dx * o);
        ctx.lineTo(p.x - dx * (r + 14) - dy * o, p.y - dy * (r + 14) + dx * o);
        ctx.stroke();
      }
    }
    if (id === 2) { ctx.strokeStyle = '#6b6b73'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(p.x, p.y, r + 2, 0, 7); ctx.stroke(); }
    const hurt = p.hurt > 0 && Math.floor(p.hurt * 20) % 2;
    circ(p.x, p.y, r, hurt ? '#ffffff' : ch.col);
    ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(p.x, p.y, r, 0, 7); ctx.stroke();
    if (id === 0) { // हेलमेट
      circ(p.x, p.y, r * 0.75, hurt ? '#fff' : '#5b6b3a');
      ctx.strokeStyle = '#1d2412'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(p.x, p.y, r * 0.75, ang - 0.75, ang + 0.75); ctx.stroke();
    } else if (id === 1) { // लाल पट्टी
      ctx.strokeStyle = '#e03c3c'; ctx.lineWidth = 4;
      ctx.beginPath(); ctx.arc(p.x, p.y, r * 0.62, 0, 7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(p.x - dx * r * 0.6, p.y - dy * r * 0.6);
      ctx.lineTo(p.x - dx * (r + 9) + dy * 4, p.y - dy * (r + 9) - dx * 4); ctx.stroke();
      circ(p.x + dx * 7, p.y + dy * 7, 3.2, '#2b2b2b');
    } else if (id === 2) { // कंधे का कवच
      for (const sg of [-1, 1]) circ(p.x - dy * r * 0.95 * sg, p.y + dx * r * 0.95 * sg, r * 0.33, '#4a4a52');
      circ(p.x + dx * 6, p.y + dy * 6, 3.5, '#2b2b2b');
    } else { // निशानेबाज़ की टोपी
      circ(p.x, p.y, r * 0.7, hurt ? '#fff' : '#7a2f78');
      ctx.strokeStyle = '#4d1a4b'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(p.x, p.y, r * 0.7, ang - 1.1, ang + 1.1); ctx.stroke();
      circ(p.x + dx * 7, p.y + dy * 7, 3, '#ffd1ff');
    }
  }

  // ---------- पूरी ड्रॉइंग ----------
  draw = function () {
    if (!decos || decos.w !== W || decos.h !== H) mkDecos();
    const idx = themeIdx(wave), th = TH[idx], ch = CH[S.ch], tm = performance.now() / 1000;
    if (idx !== lastIdx) {
      lastIdx = idx;
      applyTheme(idx);
      if (running) note('नया नक्शा: ' + th.name);
    }
    ctx.save();
    if (shake > 0) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);
    ctx.fillStyle = th.bg; ctx.fillRect(-20, -20, W + 40, H + 40);
    ctx.fillStyle = th.pat;
    for (const q of patches) { ctx.beginPath(); ctx.ellipse(q.x, q.y, q.rx, q.ry, q.a, 0, 7); ctx.fill(); }
    ctx.fillStyle = th.dot;
    for (let x = 20; x < W; x += 60) for (let y = 20; y < H; y += 60) ctx.fillRect(x, y, 4, 4);
    for (const d of decos) drawDeco(d, idx, tm);

    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = 'bold 16px sans-serif';
    for (const d of drops) {
      if (d.life < 3 && Math.floor(d.life * 6) % 2) continue;
      circ(d.x, d.y, 14, DROPS[d.kind].col);
      ctx.strokeStyle = '#fff7e0'; ctx.lineWidth = 2; ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.fillText(DROPS[d.kind].t, d.x, d.y + 1);
    }

    for (const e of enemies) {
      shadow(e.x, e.y, e.r);
      const base = e.type === 'boss' && th.dark ? '#6a4a5a' : TYPES[e.type].col;
      circ(e.x, e.y, e.r, e.state === 'wind' && Math.floor(e.wt * 14) % 2 ? '#ffffff' : base);
      ctx.strokeStyle = th.dark ? 'rgba(255,255,255,.5)' : 'rgba(0,0,0,.35)'; ctx.lineWidth = 2; ctx.stroke();
      const a = Math.atan2(p.y - e.y, p.x - e.x), ex = Math.cos(a), ey = Math.sin(a);
      if (e.type === 'shooter') {
        ctx.strokeStyle = '#12303f'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + ex * (e.r + 7), e.y + ey * (e.r + 7)); ctx.stroke();
      }
      for (const sg of [-1, 1]) {
        const ox = e.x + ex * e.r * 0.35 - ey * e.r * 0.3 * sg, oy = e.y + ey * e.r * 0.35 + ex * e.r * 0.3 * sg;
        circ(ox, oy, e.r * 0.2, '#fff');
        circ(ox + ex * e.r * 0.06, oy + ey * e.r * 0.06, e.r * 0.1, '#111');
      }
      if (e.max > 4) {
        ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(e.x - e.r, e.y - e.r - 10, e.r * 2, 5);
        ctx.fillStyle = '#e8643c'; ctx.fillRect(e.x - e.r, e.y - e.r - 10, e.r * 2 * Math.max(0, e.hp / e.max), 5);
      }
    }

    for (const b of ebullets) {
      circ(b.x, b.y, 10, 'rgba(255,122,60,.35)');
      circ(b.x, b.y, 6, '#ff7a3c');
      ctx.strokeStyle = '#7a1f0a'; ctx.lineWidth = 2; ctx.stroke();
    }
    ctx.strokeStyle = 'rgba(255,216,92,.5)'; ctx.lineWidth = 3;
    for (const b of bullets) { ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x - b.vx * 0.03, b.y - b.vy * 0.03); ctx.stroke(); }
    for (const b of bullets) circ(b.x, b.y, 4, '#ffd85c');

    for (const q of parts) {
      ctx.globalAlpha = Math.max(0, q.life / q.max);
      ctx.fillStyle = q.col; ctx.fillRect(q.x - q.r / 2, q.y - q.r / 2, q.r, q.r);
    }
    ctx.globalAlpha = 1;

    drawPlayer(ch);
    drawAmb(idx, tm);
    ctx.restore();
    vignette(th);

    if (bannerT > 0 && !choosing) {
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(255,247,224,' + Math.min(1, bannerT) + ')';
      ctx.font = 'bold 40px sans-serif';
      ctx.fillText('लहर ' + wave + (wave % 5 === 0 ? ' · बॉस आ रहा है!' : ''), W / 2, H / 3);
    }
  };

  reset(); draw(); info();
})();