KOR ሞባይል አፕ — መጫኛ መመሪያ

1. ZIP ፋይሉን Extract/Unzip ያድርጉ።
2. ፋይሉን HTTPS ያለው ድረ-ገጽ ላይ ያስቀምጡ።
3. በAndroid Chrome ይክፈቱት።
4. Chrome ሜኑ → Install app ወይም Add to Home screen ይጫኑ።

ማስታወሻ፦ ይህ ZIP የአፕ ምንጭ ኮድ ነው፤ APK አይደለም። APK ለመስራት Android Studio/Capacitor ያስፈልጋል።
መረጃዎች በዚያ ሞባይል ብራውዘር Local Storage ይቀመጣሉ፤ በሌላ ስልክ በራስ-ሰር አይመሳሰሉም።
Labour ID በእጅ ይገባል፤ አይፈጠርም/አይቀየርም። EM ወይም EF ቅድመ ቃል የGender መለያ ነው።


Calendar: The app now accepts and displays Ethiopian calendar dates (DD/MM/YYYY E.C.) and Ethiopian months beginning with Meskerem. Dates are stored internally in Gregorian ISO format for compatibility.
