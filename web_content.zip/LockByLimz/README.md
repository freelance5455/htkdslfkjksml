# Lock by Limz — Android project

Project Android Studio untuk membuat APK Lock by Limz.

## Fitur
- Fullscreen immersive (status/navigation bar disembunyikan saat aplikasi fokus)
- Video default Catbox: `https://files.catbox.moe/4wn66v.mp4`
- Tombol Mulai mengaktifkan pemutaran video dan suara
- Pilih video dari galeri; pilihan disimpan lokal dengan IndexedDB
- PIN demo: `1234`
- Kunci Lagi untuk kembali ke layar PIN
- Menjaga layar tetap menyala saat aplikasi terbuka

## Membuat APK
1. Instal Android Studio versi terbaru dan Android SDK Platform 35.
2. Ekstrak ZIP ini.
3. Android Studio → **Open** → pilih folder `LockByLimz` (folder yang berisi `settings.gradle.kts`).
4. Tunggu Gradle Sync selesai. Jika diminta, gunakan JDK 17.
5. Pilih **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
7. Pindahkan APK ke HP, buka, dan izinkan instalasi dari sumber tersebut bila Android meminta.

## Agar tetap di aplikasi (Screen Pinning)
1. Di HP buka Setelan dan cari **Sematkan aplikasi / App pinning / Screen pinning**.
2. Aktifkan dan aktifkan permintaan PIN saat melepas sematan jika tersedia.
3. Buka Lock by Limz.
4. Buka layar aplikasi terbaru (Recent Apps), tekan ikon aplikasi, lalu pilih **Sematkan / Pin**.
5. Ikuti instruksi Android untuk melepas sematan. Nama menu dan gesture berbeda tergantung merek HP.

## Batasan keamanan
Ini adalah layar kunci aplikasi/kiosk sederhana, bukan pengganti lockscreen Android dan bukan kiosk device-owner. HTML/WebView tidak dapat memblokir tombol Power, mematikan sistem navigasi secara permanen, atau menjamin aplikasi tidak bisa ditutup. Untuk kiosk terkunci penuh diperlukan perangkat yang dikelola (Android Enterprise/device owner) dan konfigurasi Lock Task Mode. Jangan gunakan PIN demo `1234` untuk melindungi data pribadi atau uang.

## Mengubah PIN
Buka `app/src/main/assets/index.html`, ubah `const PIN='1234'` menjadi PIN pilihan (empat digit), lalu build ulang APK.
