# ÉcoPilote : créer l'APK Android

## Pourquoi pas un simple « site vers APK » ?
Un emballage WebView ne gère pas la **commande vocale** ni le **scanner de cartes**. Utilisez une **TWA** (Trusted Web Activity), basée sur Chrome : tout fonctionne.

## Étapes
1. **Hébergez ce dossier en HTTPS** (obligatoire) : Firebase Hosting, Netlify ou GitHub Pages. Le fichier principal est `index.html`.
2. Ouvrez https://www.pwabuilder.com, collez l'adresse de votre site, touchez **Start**. Les trois cases manifeste / service worker / sécurité doivent être vertes.
3. Touchez **Package for stores** → **Android** → renseignez : nom « ÉcoPilote », identifiant de paquet (ex. `com.yelecompagnie.ecopilote`), puis **Generate**.
4. Vous recevez un `.apk` (test) et un `.aab` (Play Store) avec la **clé de signature** : **gardez-la précieusement**.
5. Pour supprimer la barre d'adresse dans l'app, ajoutez le fichier `assetlinks.json` fourni par PWABuilder dans `/.well-known/` de votre site.
6. Play Store : compte développeur Google Play (paiement unique), envoi du `.aab`, fiche, politique de confidentialité (le texte « Mentions légales » de l'app est un modèle à faire valider).

## Avant de publier
- Vérifiez la politique de Google Play sur les paiements d'abonnements.
- Renseignez `DEFAULT_DB_URL`, `FB_KEY` et `AI_PROXY` en haut du script de `index.html`.
- Dans Firebase > Authentication > Paramètres > Domaines autorisés : ajoutez le domaine de votre site.
