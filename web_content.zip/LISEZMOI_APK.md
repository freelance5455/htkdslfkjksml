# ÉcoPilote v15 : créer l'APK Android

## Important : utilisez une TWA, pas un simple « site vers APK »
Beaucoup d'outils « site web vers APK » emballent la page dans une **WebView** limitée. Dans ce cas :
- WhatsApp, l'e-mail et les SMS ne s'ouvrent pas ;
- le choix de fichiers et de photos ne marche pas ;
- la commande vocale et le scanner de cartes sont bloqués.

Une **TWA** (Trusted Web Activity) utilise Chrome : tout fonctionne. Faites votre APK avec **PWABuilder**.

## Étapes
1. Décompressez ce ZIP et mettez les fichiers en ligne en **HTTPS**, à la racine d'une adresse
   (Netlify, Cloudflare Pages, Firebase Hosting, GitHub Pages avec un site « utilisateur »).
2. Avant l'envoi, ouvrez `index.html` dans un éditeur de texte et vérifiez en haut du script :
   `DEFAULT_DB_URL`, `FB_KEY` (déjà remplis si vous avez gardé votre version) et `AI_PROXY` (adresse de votre serveur IA, facultatif).
3. Allez sur **pwabuilder.com**, collez l'adresse du site, touchez **Start**.
4. **Package for stores → Google Play (Android)**. Identifiant de paquet conseillé : `com.yelecompagnie.ecopilote`.
   Laissez la clé de signature sur **New**.
5. Téléchargez le ZIP de PWABuilder : `.apk` (test), `.aab` (Play Store), la **clé de signature** et ses mots de passe.
   Sauvegardez la clé à deux endroits : sans elle, plus de mise à jour possible.
6. Placez le fichier `assetlinks.json` fourni par PWABuilder dans le dossier `/.well-known/` de votre site, puis remettez le site en ligne.
   Sans lui, une barre d'adresse s'affiche dans l'application.
7. Installez le `.apk` sur un téléphone et testez : connexion, WhatsApp, e-mail, import de fichier, import de photo, commande vocale, scanner.
8. Play Store : compte développeur Google Play, envoi du `.aab`, fiche, captures, politique de confidentialité.
   Après le premier envoi, ajoutez aussi l'empreinte de signature de Google à `assetlinks.json`.

## À chaque nouvelle version de l'application
Remplacez les fichiers sur votre site : l'APK (TWA) se met à jour tout seul. Il ne faut refaire l'APK que si l'adresse du site change.

## Rappels
- Le générateur de codes d'abonnement (`GenerateurCodes_PRIVE.html`) n'est PAS dans ce ZIP : ne le mettez jamais en ligne.
- Importer un fichier Excel ou lire une photo sans IA demande internet (bibliothèques chargées en ligne). Le CSV marche sans internet.
