-- سوقنا V15 — Supabase database setup
-- Run this entire file once in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  email text,
  phone text,
  region text,
  city text,
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.ads (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text not null,
  subcategory text,
  price numeric,
  currency text,
  city text,
  region text,
  details text,
  contact text,
  image_url text,
  status text not null default 'active' check (status in ('active','sold','hidden','deleted')),
  is_wholesale boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.favorites (
  user_id uuid not null references auth.users(id) on delete cascade,
  ad_id uuid not null references public.ads(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, ad_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references auth.users(id) on delete cascade,
  receiver_id uuid references auth.users(id) on delete set null,
  ad_id uuid references public.ads(id) on delete set null,
  body text not null,
  created_at timestamptz not null default now(),
  read_at timestamptz
);

create table if not exists public.requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  category text,
  city text,
  region text,
  details text,
  status text not null default 'open' check (status in ('open','closed')),
  created_at timestamptz not null default now()
);

create table if not exists public.workers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  service text not null,
  description text,
  city text,
  region text,
  price numeric,
  currency text,
  contact text,
  status text not null default 'active' check (status in ('active','paused')),
  created_at timestamptz not null default now()
);

create table if not exists public.deliveries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  from_city text not null,
  to_city text not null,
  price numeric,
  currency text,
  details text,
  contact text,
  status text not null default 'active' check (status in ('active','paused')),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text,
  type text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists ads_created_at_idx on public.ads(created_at desc);
create index if not exists ads_category_idx on public.ads(category);
create index if not exists ads_city_idx on public.ads(city);
create index if not exists ads_seller_idx on public.ads(seller_id);
create index if not exists messages_sender_idx on public.messages(sender_id);
create index if not exists messages_receiver_idx on public.messages(receiver_id);

alter table public.profiles enable row level security;
alter table public.ads enable row level security;
alter table public.favorites enable row level security;
alter table public.messages enable row level security;
alter table public.requests enable row level security;
alter table public.workers enable row level security;
alter table public.deliveries enable row level security;
alter table public.notifications enable row level security;

-- Profiles
 drop policy if exists profiles_select_self on public.profiles;
create policy profiles_select_self on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists profiles_insert_self on public.profiles;
create policy profiles_insert_self on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists profiles_update_self on public.profiles;
create policy profiles_update_self on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

-- Ads: everyone can browse active ads; signed-in users manage their own.
drop policy if exists ads_public_read on public.ads;
create policy ads_public_read on public.ads for select to anon, authenticated using (status = 'active' or seller_id = auth.uid());
drop policy if exists ads_insert_owner on public.ads;
create policy ads_insert_owner on public.ads for insert to authenticated with check (seller_id = auth.uid());
drop policy if exists ads_update_owner on public.ads;
create policy ads_update_owner on public.ads for update to authenticated using (seller_id = auth.uid()) with check (seller_id = auth.uid());
drop policy if exists ads_delete_owner on public.ads;
create policy ads_delete_owner on public.ads for delete to authenticated using (seller_id = auth.uid());

-- Favorites
drop policy if exists favorites_owner on public.favorites;
create policy favorites_owner on public.favorites for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Messages: only participants can read/write their own messages.
drop policy if exists messages_select_participants on public.messages;
create policy messages_select_participants on public.messages for select to authenticated using (sender_id = auth.uid() or receiver_id = auth.uid());
drop policy if exists messages_insert_sender on public.messages;
create policy messages_insert_sender on public.messages for insert to authenticated with check (sender_id = auth.uid());
drop policy if exists messages_update_participants on public.messages;
create policy messages_update_participants on public.messages for update to authenticated using (sender_id = auth.uid() or receiver_id = auth.uid()) with check (sender_id = auth.uid() or receiver_id = auth.uid());

-- Requests / workers / deliveries
drop policy if exists requests_public_read on public.requests;
create policy requests_public_read on public.requests for select to anon, authenticated using (status = 'open' or user_id = auth.uid());
drop policy if exists requests_owner_all on public.requests;
create policy requests_owner_all on public.requests for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists workers_public_read on public.workers;
create policy workers_public_read on public.workers for select to anon, authenticated using (status = 'active' or user_id = auth.uid());
drop policy if exists workers_owner_all on public.workers;
create policy workers_owner_all on public.workers for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists deliveries_public_read on public.deliveries;
create policy deliveries_public_read on public.deliveries for select to anon, authenticated using (status = 'active' or user_id = auth.uid());
drop policy if exists deliveries_owner_all on public.deliveries;
create policy deliveries_owner_all on public.deliveries for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Notifications
drop policy if exists notifications_owner on public.notifications;
create policy notifications_owner on public.notifications for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Storage bucket for ad images.
insert into storage.buckets (id, name, public)
values ('ad-images','ad-images',true)
on conflict (id) do update set public = true;

drop policy if exists ad_images_public_read on storage.objects;
create policy ad_images_public_read on storage.objects for select to public using (bucket_id = 'ad-images');
drop policy if exists ad_images_auth_insert on storage.objects;
create policy ad_images_auth_insert on storage.objects for insert to authenticated with check (bucket_id = 'ad-images');
drop policy if exists ad_images_owner_update on storage.objects;
create policy ad_images_owner_update on storage.objects for update to authenticated using (bucket_id = 'ad-images' and owner_id = auth.uid()::text);
drop policy if exists ad_images_owner_delete on storage.objects;
create policy ad_images_owner_delete on storage.objects for delete to authenticated using (bucket_id = 'ad-images' and owner_id = auth.uid()::text);

-- Optional profile trigger for new Auth users.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, display_name, email)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name','مستخدم سوقنا'), new.email)
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Realtime for chat/notifications (safe if already enabled).
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.notifications;
