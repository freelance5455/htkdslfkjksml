'use strict';
const C=document.getElementById('c'),X=C.getContext('2d'),W=960,H=540;
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v)),rnd=(a,b)=>a+Math.random()*(b-a),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
let S=Object.assign({vol:.6,gfx:1,dz:.2},JSON.parse(localStorage.fs_set||'{}'));const ss=()=>localStorage.fs_set=JSON.stringify(S);
function fit(){const s=Math.min(innerWidth/W,innerHeight/H);C.style.width=W*s+'px';C.style.height=H*s+'px';C.style.margin=(innerHeight-H*s)/2+'px 0 0 '+(innerWidth-W*s)/2+'px'}
onresize=fit;fit();
// ---- звук
let AC;function snd(f,d,t='square',v=.2){if(S.vol<=0)return;try{AC=AC||new AudioContext();const o=AC.createOscillator(),g=AC.createGain();o.type=t;o.frequency.value=f;g.gain.value=v*S.vol;g.gain.exponentialRampToValueAtTime(.001,AC.currentTime+d);o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}}
// ---- ввод
let pe={},I={},pb=[],px=0,py=0,usePad=false,tc=false;const tj={id:null,ox:0,oy:0,dx:0,dy:0},tr={id:null,ox:0,oy:0,dx:0,dy:0};let tid=null;const K={},M={x:480,y:270,d:0,m:0};
onkeydown=e=>{tc=false;if(!e.repeat)pe[e.code]=1;K[e.code]=1;usePad=false;if(/Arrow|Space|Tab/.test(e.code))e.preventDefault()};onkeyup=e=>K[e.code]=0;
C.onmousemove=e=>{const r=C.getBoundingClientRect();M.x=(e.clientX-r.left)*W/r.width;M.y=(e.clientY-r.top)*H/r.height;M.m=1;usePad=false;tc=false};
C.onmousedown=e=>{const r=C.getBoundingClientRect();M.x=(e.clientX-r.left)*W/r.width;M.y=(e.clientY-r.top)*H/r.height;usePad=false;tc=false;if(ig&&sc=='play'&&M.x>880&&M.y<60){pe.KeyP=1;return}M.d=1;pe.click=1;try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}};onmouseup=()=>M.d=0;
// ---- сенсорное управление
const toC=t=>{const r=C.getBoundingClientRect();return[(t.clientX-r.left)*W/r.width,(t.clientY-r.top)*H/r.height]};
function tvec(st,x,y){const dx=(x-st.ox)/60,dy=(y-st.oy)/60,l=Math.hypot(dx,dy)||1,m=Math.min(1,l);st.dx=dx/l*m;st.dy=dy/l*m}
function tstart(e){e.preventDefault();tc=true;usePad=false;try{screen.orientation.lock('landscape').catch(()=>{})}catch(_){}
 for(const t of e.changedTouches){const[x,y]=toC(t);
  if(menuList()){M.x=x;M.y=y;M.m=1;pe.click=1;continue}
  if(x>880&&y<60){pe.KeyP=1;continue}
  if(Math.hypot(x-880,y-430)<48){tid=t.identifier;pe.KeyE=1;K.TouchAct=1;continue}
  if(Math.hypot(x-790,y-480)<38){pe.KeyF=1;continue}
  const st=x<W/2?tj:tr;if(st.id==null){Object.assign(st,{id:t.identifier,ox:x,oy:y,dx:0,dy:0})}}}
function tmove(e){e.preventDefault();for(const t of e.changedTouches){const[x,y]=toC(t);for(const st of[tj,tr])if(st.id===t.identifier)tvec(st,x,y)}}
function tend(e){e.preventDefault();for(const t of e.changedTouches){for(const st of[tj,tr])if(st.id===t.identifier){st.id=null;st.dx=st.dy=0}if(t.identifier===tid){tid=null;K.TouchAct=0}}}
C.addEventListener('touchstart',tstart,{passive:false});C.addEventListener('touchmove',tmove,{passive:false});C.addEventListener('touchend',tend,{passive:false});C.addEventListener('touchcancel',tend,{passive:false});
function poll(){
 const g=[...(navigator.getGamepads?navigator.getGamepads():[])].find(x=>x&&x.connected),b=i=>!!(g&&g.buttons[i]&&g.buttons[i].pressed),ed=i=>b(i)&&!pb[i],ax=i=>g?g.axes[i]||0:0,dz=v=>Math.abs(v)>S.dz?v:0;
 let mx=(K.KeyD||K.ArrowRight?1:0)-(K.KeyA||K.ArrowLeft?1:0)+dz(ax(0))+tj.dx,my=(K.KeyS||K.ArrowDown?1:0)-(K.KeyW||K.ArrowUp?1:0)+dz(ax(1))+tj.dy;
 if(b(14))mx--;if(b(15))mx++;if(b(12))my--;if(b(13))my++;const l=Math.hypot(mx,my);if(l>1){mx/=l;my/=l}
 const rx=ax(2)||tr.dx,ry=ax(3)||tr.dy;
 I={mx,my,rx,ry,pad:Math.hypot(rx,ry)>.35,shoot:M.d||K.Space||b(7)||b(5),act:K.KeyE||b(0)||K.TouchAct,actP:pe.KeyE||ed(0),leash:pe.KeyF||ed(2),pause:pe.Escape||pe.KeyP||ed(9),
  up:pe.ArrowUp||pe.KeyW||ed(12)||(ax(1)<-.6&&py>=-.6),down:pe.ArrowDown||pe.KeyS||ed(13)||(ax(1)>.6&&py<=.6),
  left:pe.ArrowLeft||pe.KeyA||ed(14)||(ax(0)<-.6&&px>=-.6),right:pe.ArrowRight||pe.KeyD||ed(15)||(ax(0)>.6&&px<=.6),ok:pe.Enter||pe.Space||ed(0),bk:pe.Escape||ed(1)};
 if(tr.id!=null&&I.pad)I.shoot=true;
 if(g&&(I.pad||g.buttons.some(x=>x.pressed)))usePad=true;
 px=ax(0);py=ax(1);pb=g?g.buttons.map(x=>x.pressed):[];
}
// ---- состояние
const BED={x:790,y:190},dk=()=>{const h=gt/60;return h<5?.6:h<7?.6*(7-h)/2:h<19?0:h<21?.6*(h-19)/2:.6};
const RW=[['🐄','Корова'],['🐇','Кролик'],['🐔','Курица'],['🐈','Кот'],['🐕','Собака']],DOOR={x:160,y:215},need=()=>5+level*3;
let DT=0,BG,VG,pend=null,lastSc='',ma=0;const ba=[];
let gt=480,zz=null,sc='menu',back='menu',sel=0,ig=false,ins=false,P,cows=[],ans=[],wolves=[],bul=[],truck=null,lv=null,money=0,buckets=0,level=1,xp=0,tm=8,wt=25,gcd=0,msg='',msgT=0,hint='',T=0,cam={x:0,y:0};
const tufts=[],demo=[];for(let i=0;i<260;i++)tufts.push([rnd(0,2000),rnd(0,700)]);
function mkCow(x,y){return{v:Math.random(),x,y,milk:30,hp:100,f:1,follow:0,t:Math.random()*6,tx:x,ty:y,w:0,mv:0}}
for(let i=0;i<5;i++){const c=mkCow(rnd(-100,950),rnd(300,520));c.sp=rnd(25,45);demo.push(c)}
function start(){P={x:160,y:260,hp:100,a:0,mt:0,sl:0};wolves=[];bul=[];truck=null;tm=8;wt=25;lv=null;ins=false;ig=true;sc='play'}
function newGame(){gt=480;level=1;xp=0;money=0;buckets=0;cows=[0,1,2].map(i=>mkCow(150+i*130,330+(i%2)*70));ans=[];start()}
function save(){localStorage.fs_save=JSON.stringify({gt,level,xp,money,buckets,cows:cows.map(c=>({x:c.x,y:c.y,milk:c.milk,hp:c.hp})),ans:ans.map(a=>({k:a.k,x:a.x,y:a.y}))})}
function load(){const d=JSON.parse(localStorage.fs_save);gt=d.gt??480;level=d.level;xp=d.xp;money=d.money;buckets=d.buckets;cows=d.cows.map(c=>Object.assign(mkCow(0,0),c));ans=d.ans.map(a=>Object.assign({tx:a.x,ty:a.y,w:0,f:1},a));start()}
onbeforeunload=()=>{if(ig)save()};
const hasSave=()=>!!localStorage.fs_save,toSet=()=>{back=sc;sc='set';sel=0};
function menuList(){
 if(sc=='menu')return[{t:hasSave()?'Продолжить':'Играть',f:()=>hasSave()?load():newGame()},...(hasSave()?[{t:'Новая игра',f:newGame}]:[]),{t:'Настройки',f:toSet}];
 if(sc=='pause')return[{t:'Продолжить',f:()=>sc='play'},{t:'Настройки',f:toSet},{t:'В главное меню (сохранить)',f:()=>{save();ig=false;sc='menu';sel=0}}];
 if(sc=='set')return[{t:'Громкость: '+Math.round(S.vol*100)+'%',adj:d=>S.vol=clamp(+(S.vol+d*.1).toFixed(1),0,1)},{t:'Графика: '+['Низкая','Высокая'][S.gfx],adj:()=>S.gfx^=1},
  {t:'Мёртвая зона стика: '+S.dz.toFixed(2),adj:d=>S.dz=clamp(+(S.dz+d*.05).toFixed(2),.05,.5)},{t:'Управление (схема)',f:()=>{sc='ctl';sel=0}},{t:'Назад',f:()=>{sc=back;sel=0}}];
 if(sc=='ctl')return[{t:'Назад',f:()=>{sc='set';sel=0}}];
 return null}
function navMenu(L){
 if(sc!=lastSc){lastSc=sc;ma=0;ba.length=0;pend=null}ma+=DT;
 const y0=sc=='ctl'?400:190,hit=i=>M.y>y0+i*58&&M.y<y0+i*58+46&&M.x>280&&M.x<680;
 L.forEach((_,i)=>{const a=ba[i]||(ba[i]={h:0,p:0});a.h+=((i==sel?1:0)-a.h)*Math.min(1,DT*12);a.p=Math.max(0,a.p-DT*3.5)});
 if(pend){pend.t-=DT;if(pend.t<=0){const it=pend.it;pend=null;if(it.f)it.f();else if(it.adj){it.adj(1);ss()}}return}
 if(M.m){M.m=0;const i=L.findIndex((_,i)=>hit(i));if(i>=0)sel=i}
 sel=clamp(sel,0,L.length-1);if(I.up)sel=(sel+L.length-1)%L.length;if(I.down)sel=(sel+1)%L.length;
 const it=L[sel];if(I.left&&it.adj){it.adj(-1);ss();snd(400,.05);ba[sel].p=.6}if(I.right&&it.adj){it.adj(1);ss();snd(500,.05);ba[sel].p=.6}
 if(I.ok||(pe.click&&hit(sel))){snd(600,.08);ba[sel].p=1;pend={it,t:.16}}
 else if(I.bk){if(sc=='set')sc=back;else if(sc=='ctl')sc='set';else if(sc=='pause')sc='play';sel=0}}
function wander(o,dt,sp,x0,x1,y0,y1){o.w-=dt;if(o.w<=0){o.w=rnd(1,4);o.tx=clamp(o.x+rnd(-80,80),x0,x1);o.ty=clamp(o.y+rnd(-50,50),y0,y1);if(Math.random()<.3){o.tx=o.x;o.ty=o.y}}
 const dx=o.tx-o.x,dy=o.ty-o.y,d=Math.hypot(dx,dy);o.mv=d>4;if(o.mv){o.x+=dx/d*sp*dt;o.y+=dy/d*sp*dt;o.f=dx>=0?1:-1}}
// ---- обновление
function upd(dt){
 DT=dt;T+=dt;demo.forEach(c=>{c.x+=c.sp*dt;if(c.x>1060)c.x=-100;c.t+=dt*7;c.mv=1;c.f=1});if(msgT>0)msgT-=dt;
 const L=menuList();if(L)return navMenu(L);
 if(I.pause){sc='pause';sel=0;return}
 if(zz){zz.t+=dt;if(zz.t>1.5&&!zz.d){zz.d=1;gt=420;P.hp=100;cows.forEach(c=>c.milk=Math.min(60,c.milk+30));wolves=[];bul=[];wt=25;msg='Доброе утро!';msgT=3}if(zz.t>3.5)zz=null;return}
 if(lv){lv.t+=dt;if(lv.t>5)lv=null;return}
 if(xp>=need()){xp-=need();level++;const r=RW[(level-2)%5];if(r[0]=='🐄')cows.push(mkCow(300,400));else ans.push({k:r[0],x:rnd(200,280),y:300,tx:240,ty:300,w:0,f:1});lv={t:0,L:level,r};snd(523,.4,'triangle');return}
 const h=ins;gt=(gt+dt*2)%1440;P.ph=(P.ph||0)+((I.mx||I.my)?dt*10:0);let nx=P.x+I.mx*150*dt,ny=P.y+I.my*150*dt;
 if(h){nx=clamp(nx,50,910);ny=clamp(ny,190,500)}else{nx=clamp(nx,10,1990);ny=clamp(ny,40,690);
  if(!(ny>285&&ny<395)&&nx>990&&nx<1010)nx=P.x<=1000?990:1010;if(nx>50&&nx<270&&ny<215)ny=215}
 P.x=nx;P.y=ny;cam.x=h?0:clamp(P.x-W/2,0,2000-W);cam.y=h?0:clamp(P.y-H/2,0,700-H);
 if(I.pad)P.a=Math.atan2(I.ry,I.rx);else if(!usePad&&!tc)P.a=Math.atan2(M.y-(P.y-cam.y-22),M.x-(P.x-cam.x));
 gcd-=dt;P.hp=Math.min(100,P.hp+dt*2);
 const k=usePad?'A':tc?'✋':'E';let hn='',mk=0;
 if(h){if(dist(P,{x:480,y:520})<70){hn=k+': выйти из дома';if(I.actP){ins=false;P.x=160;P.y=245;snd(300,.1)}}else if(dist(P,BED)<80){const ok=gt>=1320||gt<300;hn=ok?k+': лечь спать':'Спать можно после 22:00';if(ok&&I.actP){zz={t:0};snd(200,.4,'sine')}}else hn='Вёдра с молоком лежат на полке'}
 else{
  if(truck&&truck.st==1&&Math.abs(P.x-truck.x)<120&&Math.abs(P.y-truck.y)<70){
   hn=buckets?'Удерживайте '+k+': продать молоко':'Нет вёдер с молоком';
   if(buckets&&I.act){P.sl+=dt;if(P.sl>.25){P.sl=0;buckets--;money+=12;xp++;snd(700,.12,'triangle')}}}
  else{let c=null,bd=60;for(const o of cows){const d=dist(o,P);if(d<bd){bd=d;c=o}}
   if(c){hn=(c.milk>=30?(buckets<10?'Удерживайте '+k+': доить':'Инвентарь полон'):'Корова ещё не готова')+' · '+(usePad?'X':tc?'🔗':'F')+': '+(c.follow?'отпустить':'вести');
    if(c.milk>=30&&buckets<10&&I.act){mk=1;P.mt+=dt;if(P.mt>=1.2){P.mt=0;c.milk-=30;buckets++;snd(300,.15,'sine')}}
    if(I.leash){c.follow^=1;snd(450,.08)}}
   else if(dist(P,DOOR)<60){hn=k+': войти в дом';if(I.actP){ins=true;cows.forEach(o=>o.follow=0);P.x=480;P.y=440;snd(250,.1)}}}
  if(I.shoot&&gcd<=0&&!mk){gcd=.35;bul.push({x:P.x,y:P.y-22,vx:Math.cos(P.a)*720,vy:Math.sin(P.a)*720,l:.9});snd(180,.1,'sawtooth',.25)}
  for(const c of cows){const z=c.x>1000;c.milk=Math.min(60,c.milk+dt*(z?9:3));
   if(c.follow){const d=dist(c,P);c.mv=d>75;if(c.mv){c.x+=(P.x-c.x)/d*125*dt;c.y+=(P.y-c.y)/d*125*dt;c.f=P.x>=c.x?1:-1}}
   else wander(c,dt,40,z?1030:20,z?1980:970,z?30:240,z?680:570);if(c.mv)c.t+=dt*8}
  for(const a of ans)wander(a,dt,a.k=='🐕'?60:35,20,970,240,570);
  wt-=dt*(1+dk()*2);if(wt<=0){wt=Math.max(7,24-level*1.5);const e=Math.random()<.7;wolves.push({x:e?1990:rnd(1000,1990),y:e?rnd(40,680):40,hp:3,f:-1,t:0,h:0})}
  for(const w of wolves){w.t+=dt*8;w.h-=dt;let tg=null,bd=1e9;for(const c of cows){const d=dist(w,c);if(d<bd){bd=d;tg=c}}
   if(!tg||dist(w,P)<200){tg=P;bd=dist(w,P)}
   if(bd>26){w.x+=(tg.x-w.x)/bd*88*dt;w.y+=(tg.y-w.y)/bd*88*dt;w.f=tg.x>=w.x?1:-1}else if(tg===P)P.hp-=dt*16;else tg.hp-=dt*18;
   for(const a of ans)if(a.k=='🐕'&&dist(a,w)<90)w.hp-=dt*.6}
  for(const b of bul){b.x+=b.vx*dt;b.y+=b.vy*dt;b.l-=dt;for(const w of wolves)if(b.l>0&&Math.hypot(b.x-w.x,b.y-(w.y-18))<22){w.hp--;w.h=.15;b.l=0;snd(120,.1,'sawtooth')}}
  bul=bul.filter(b=>b.l>0);let n=wolves.length;wolves=wolves.filter(w=>w.hp>0);money+=5*(n-wolves.length);
  n=cows.length;cows=cows.filter(c=>c.hp>0);if(cows.length<n){msg='Волки задрали корову!';msgT=3}
  if(!cows.length){cows.push(mkCow(300,400));msg='Соседи подарили вам корову';msgT=3}
  if(P.hp<=0){P.hp=100;buckets>>=1;P.x=160;P.y=245;msg='Волки вас прогнали, часть молока потеряна';msgT=3}
  tm-=dt;if(!truck&&tm<=0&&gt>=360&&gt<1320){truck={x:-140,y:645,st:0,w:35};tm=20}
  if(truck){if(truck.st==0){truck.x+=140*dt;if(truck.x>=420){truck.x=420;truck.st=1}}else if(truck.st==1){truck.w-=dt;if(truck.w<=0)truck.st=2}else{truck.x-=170*dt;if(truck.x<-220)truck=null}}
 }
 if(!mk)P.mt=0;if(!I.act)P.sl=0;hint=hn}
// ---- рисование
const el=(x,y,a,b,c)=>{X.fillStyle=c;X.beginPath();X.ellipse(x,y,a,b,0,0,7);X.fill()};
function bkt(x,y,s,f){X.fillStyle=f?'#8aa':'rgba(255,255,255,.15)';X.beginPath();X.moveTo(x-9*s,y-10*s);X.lineTo(x+9*s,y-10*s);X.lineTo(x+7*s,y+9*s);X.lineTo(x-7*s,y+9*s);X.fill();if(f)el(x,y-10*s,9*s,3*s,'#fff')}
function dCow(c){const v=c.v||0,sp=v>.5?'#6b3f1d':'#222';X.save();X.translate(c.x,c.y);X.scale(c.f,1);if(S.gfx)el(0,0,29,7,'rgba(0,0,0,.25)');
 const s=Math.sin(c.t)*4;[-17,-9,9,17].forEach((o,i)=>{const lx=o-2+(i%2?s:-s);X.fillStyle=i<2?'#c9c9cf':'#e6e6ea';X.fillRect(lx,-14,5,12);X.fillStyle='#2b2b2b';X.fillRect(lx-.5,-3,6,3)});
 X.strokeStyle='#d8d8dc';X.lineWidth=3;X.beginPath();X.moveTo(-26,-32);X.quadraticCurveTo(-34,-24,-31,-12);X.stroke();el(-31,-11,3,4,sp);
 let g=X.createLinearGradient(0,-40,0,-12);g.addColorStop(0,'#fff');g.addColorStop(.6,'#ececf0');g.addColorStop(1,'#b9bac2');el(0,-26,27,14,g);
 X.save();X.beginPath();X.ellipse(0,-26,27,14,0,0,7);X.clip();el(-10+v*4,-31,9,6,sp);el(7,-20-v*3,7,6,sp);el(-20,-22,6,5,sp);X.restore();
 el(4,-13,6,4,'#f4a9b4');g=X.createLinearGradient(0,-44,0,-26);g.addColorStop(0,'#fff');g.addColorStop(1,'#d5d5da');el(27,-35,10,8.5,g);el(35,-31,6,4.5,'#f2a5b0');el(36,-31,1,1.2,'#a55');
 el(22,-41,4,2.5,sp);X.fillStyle='#efe6c8';X.fillRect(22,-47,2,5);X.fillRect(29,-47,2,5);el(30,-37,2,2,'#fff');el(30.5,-37,1.1,1.3,'#111');X.restore();
 X.textAlign='center';X.font='18px serif';X.fillStyle='#000';if(c.milk>=30)X.fillText('🥛',c.x,c.y-52);if(c.follow)X.fillText('🔗',c.x-20,c.y-52);
 if(c.hp<100){X.fillStyle='#400';X.fillRect(c.x-20,c.y-66,40,5);X.fillStyle='#e33';X.fillRect(c.x-20,c.y-66,40*c.hp/100,5)}}
function dEmo(o,ch,sz){X.save();X.translate(o.x,o.y);if(S.gfx)el(0,2,sz*.45,5,'rgba(0,0,0,.2)');X.scale(o.f>0?-1:1,1);X.font=sz+'px serif';X.textAlign='center';X.fillStyle='#000';X.fillText(ch,0,0);X.restore()}
function dPl(){const f=Math.cos(P.a)>=0?1:-1,mv=I.mx||I.my,sw=mv?Math.sin(P.ph||0)*6:0;X.save();X.translate(P.x,P.y);if(S.gfx)el(0,0,15,5,'rgba(0,0,0,.2)');
 X.lineCap='round';X.strokeStyle='#2f4d8a';X.lineWidth=6;for(const q of[-1,1]){X.beginPath();X.moveTo(q*3,-18);X.lineTo(q*3+q*sw,-3);X.stroke();el(q*3+q*sw+f*2,-1,4,2.5,'#3a2a1a')}
 X.fillStyle='#c0392b';X.fillRect(-9,-40,18,24);X.fillStyle='#2f4d8a';X.fillRect(-9,-28,18,12);X.fillRect(-6,-40,3,12);X.fillRect(3,-40,3,12);
 X.fillStyle='#6b3f1d';X.fillRect(-9,-28,18,2);
 el(0,-49,8.5,9,'#f1c9a0');el(-f*5,-52,5,5,'#5a3a1a');el(f*3.5,-49,1.5,1.5,'#222');el(f*2,-45,3,1,'#c77');
 el(0,-56,15,4,'#e0b84c');el(0,-59,8.5,5.5,'#e8c65a');X.fillStyle='#a33';X.fillRect(-8,-58,16,2);
 X.translate(0,-33);X.rotate(P.a);if(f<0)X.scale(1,-1);
 X.fillStyle='#6b3f1d';X.fillRect(2,-2.5,13,5);X.fillStyle='#333';X.fillRect(14,-2,19,3.5);
 X.strokeStyle='#c0392b';X.lineWidth=5;X.beginPath();X.moveTo(0,0);X.lineTo(8,1);X.moveTo(0,0);X.lineTo(17,2);X.stroke();el(8,1,3,3,'#f1c9a0');el(18,2,3,3,'#f1c9a0');X.restore()}
function mkBG(){BG=document.createElement('canvas');BG.width=2000;BG.height=700;const c=BG.getContext('2d'),R=(a,b)=>a+Math.random()*(b-a);
 let g=c.createLinearGradient(0,0,0,700);g.addColorStop(0,'#4d9636');g.addColorStop(1,'#5ca63e');c.fillStyle=g;c.fillRect(0,0,1000,700);
 g=c.createLinearGradient(0,0,0,700);g.addColorStop(0,'#6cb848');g.addColorStop(1,'#58a83c');c.fillStyle=g;c.fillRect(1000,0,1000,700);
 for(let i=0;i<500;i++){const x=R(0,2000),y=R(0,700),r=R(25,90),d=Math.random()<.5,q=c.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,d?'rgba(20,70,20,.12)':'rgba(190,230,110,.12)');q.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=q;c.fillRect(x-r,y-r,2*r,2*r)}
 for(let i=0;i<24000;i++){const x=R(0,2000),y=R(0,700);if(y>598&&x<1000)continue;c.strokeStyle='hsl('+R(80,112)+','+R(40,62)+'%,'+R(20,44)+'%)';c.lineWidth=R(.8,1.6);c.beginPath();c.moveTo(x,y);c.lineTo(x+R(-3,3),y-R(4,10));c.stroke()}
 const dirt=(x,y,rx,ry,n)=>{for(let i=0;i<n;i++){const a=R(0,6.28),d=Math.sqrt(Math.random());c.fillStyle='hsla('+R(28,38)+',35%,'+R(32,48)+'%,.45)';c.beginPath();c.arc(x+Math.cos(a)*rx*d,y+Math.sin(a)*ry*d,R(3,8),0,7);c.fill()}};
 dirt(160,250,34,55,260);dirt(500,338,340,24,700);dirt(1005,340,55,55,200);
 for(let i=0;i<700;i++){const x=Math.random()<.75?R(1000,2000):R(0,1000),y=R(0,700);if(y>600&&x<1000)continue;c.fillStyle=['#fff','#ffe14d','#d68cff','#ff8fa8'][i%4];c.beginPath();c.arc(x,y,R(1.4,2.4),0,7);c.fill();c.fillStyle='#e8a020';c.fillRect(x-.5,y-.5,1,1)}
 g=c.createLinearGradient(0,598,0,700);g.addColorStop(0,'#8a7b64');g.addColorStop(.5,'#9d8f78');g.addColorStop(1,'#85775f');c.fillStyle=g;c.fillRect(0,600,1000,100);
 for(let i=0;i<3500;i++){c.fillStyle='hsla(35,10%,'+R(30,70)+'%,.6)';c.fillRect(R(0,1000),R(600,700),R(1,3),R(1,2.5))}
 c.fillStyle='rgba(60,45,30,.18)';c.fillRect(0,632,1000,9);c.fillRect(0,660,1000,9);g=c.createLinearGradient(0,590,0,606);g.addColorStop(0,'rgba(90,70,40,0)');g.addColorStop(1,'rgba(90,70,40,.5)');c.fillStyle=g;c.fillRect(0,590,1000,16);
 const ell=(x,y,a,b,f)=>{c.fillStyle=f;c.beginPath();c.ellipse(x,y,a,b,0,0,7);c.fill()};
 for(let i=0;i<14;i++){const x=R(1050,1950),y=R(60,660),r=R(6,14);ell(x+3,y+4,r+2,r*.6,'rgba(0,0,0,.25)');const q=c.createRadialGradient(x-r*.3,y-r*.3,1,x,y,r);q.addColorStop(0,'#c4c4c0');q.addColorStop(1,'#6e6e6a');ell(x,y,r,r*.7,q)}
 // тропа к дому, корыто, сено
 c.fillStyle='#5b3b1c';rr(c,570,130,110,28,5);c.fill();ell(625,142,48,8,'#4f8fc4');ell(615,140,20,3,'rgba(255,255,255,.35)');
 ell(860,158,44,10,'rgba(0,0,0,.25)');for(let i=0;i<260;i++){c.strokeStyle='hsl('+R(42,52)+',70%,'+R(45,65)+'%)';c.lineWidth=1.5;c.beginPath();const a=R(0,6.28),d=R(0,38);c.moveTo(860+Math.cos(a)*d,140+Math.sin(a)*d*.55);c.lineTo(860+Math.cos(a)*d+R(-6,6),140+Math.sin(a)*d*.55-R(4,12));c.stroke()}
 // забор
 for(const[a,b]of[[0,284],[394,700]])for(const x of[995,1001]){const q=c.createLinearGradient(x,0,x+4,0);q.addColorStop(0,'#c79a64');q.addColorStop(1,'#6e4d2b');c.fillStyle='rgba(0,0,0,.2)';c.fillRect(x+3,a+3,4,b-a);c.fillStyle=q;c.fillRect(x,a,4,b-a)}
 const post=(y,w)=>{c.fillStyle='rgba(0,0,0,.28)';c.fillRect(1000-w/2+3,y+3,w,w);const q=c.createLinearGradient(1000-w/2,y,1000+w/2,y+w);q.addColorStop(0,'#d2a46c');q.addColorStop(1,'#7a5530');c.fillStyle=q;c.fillRect(1000-w/2,y,w,w)};
 for(let y=0;y<700;y+=50)if(y<270||y>400)post(y,11);post(272,16);post(392,16);
 c.fillStyle='#5b3b1c';c.fillRect(912,350,6,26);c.fillStyle='#b98a52';rr(c,850,318,120,34,5);c.fill();c.strokeStyle='#5b3b1c';c.lineWidth=2;c.stroke();c.fillStyle='#3a2410';c.font='bold 18px sans-serif';c.textAlign='center';c.fillText('Пастбище →',910,341);
 // дом
 ell(165,205,128,12,'rgba(0,0,0,.28)');c.fillStyle='#8d8a83';c.fillRect(55,188,210,14);
 g=c.createLinearGradient(0,80,0,192);g.addColorStop(0,'#c8895a');g.addColorStop(1,'#a8703f');c.fillStyle=g;c.fillRect(60,80,200,110);
 c.strokeStyle='rgba(60,30,10,.35)';c.lineWidth=1;for(let y=88;y<190;y+=9){c.beginPath();c.moveTo(60,y);c.lineTo(260,y);c.stroke()}for(let i=0;i<40;i++){c.fillStyle='rgba(60,30,10,.2)';c.fillRect(R(60,250),R(80,188),R(4,14),1)}
 c.save();c.beginPath();c.moveTo(42,84);c.lineTo(160,18);c.lineTo(278,84);c.closePath();c.clip();
 for(let y=20,j=0;y<86;y+=7,j++)for(let x=30+(j%2)*6;x<290;x+=12){c.fillStyle='hsl(5,'+R(45,55)+'%,'+R(30,38)+'%)';rr(c,x,y,11,8,2);c.fill();c.strokeStyle='rgba(0,0,0,.3)';c.lineWidth=.8;c.stroke()}
 g=c.createLinearGradient(40,0,280,0);g.addColorStop(0,'rgba(255,255,255,.12)');g.addColorStop(1,'rgba(0,0,0,.3)');c.fillStyle=g;c.fillRect(30,10,260,80);c.restore();c.fillStyle='rgba(0,0,0,.3)';c.fillRect(42,84,236,5);
 c.fillStyle='#8c4a3a';c.fillRect(212,26,22,38);c.strokeStyle='rgba(0,0,0,.3)';for(let y=32;y<64;y+=6){c.beginPath();c.moveTo(212,y);c.lineTo(234,y);c.stroke()}c.fillStyle='#4a4a4a';c.fillRect(209,22,28,6);
 for(const x of[72,202]){c.fillStyle='#f3ead8';rr(c,x,100,46,42,3);c.fill();g=c.createLinearGradient(x,104,x+40,138);g.addColorStop(0,'#cfeaff');g.addColorStop(1,'#5f9fd0');c.fillStyle=g;c.fillRect(x+5,105,36,32);c.fillStyle='rgba(255,255,255,.35)';c.beginPath();c.moveTo(x+5,137);c.lineTo(x+22,105);c.lineTo(x+32,105);c.lineTo(x+15,137);c.fill();c.fillStyle='#f3ead8';c.fillRect(x+21,105,3,32);c.fillRect(x+5,119,36,3);c.fillStyle='#6b3f1d';c.fillRect(x-2,142,50,8);for(let i=0;i<6;i++)ell(x+4+i*8,141,3,3,['#f55','#fd5','#f9c'][i%3])}
 g=c.createLinearGradient(143,0,177,0);g.addColorStop(0,'#7a4e28');g.addColorStop(1,'#5a3818');c.fillStyle=g;c.fillRect(143,146,34,44);c.strokeStyle='rgba(0,0,0,.35)';c.lineWidth=1.5;c.strokeRect(148,151,10,16);c.strokeRect(162,151,10,16);c.strokeRect(148,172,24,14);ell(171,172,2.5,2.5,'#e8c040');c.fillStyle='#9a9a94';c.fillRect(138,190,44,8);
 // деревья
 const tree=(x,y,s)=>{ell(x,y,38*s,11*s,'rgba(0,0,0,.28)');c.fillStyle='#5a3a1c';c.fillRect(x-5*s,y-34*s,10*s,34*s);for(const[ox,oy,r]of[[0,-62,34],[-24,-46,26],[24,-46,26],[-12,-80,24],[14,-78,24]]){const q=c.createRadialGradient(x+ox*s-8,y+oy*s-8,2,x+ox*s,y+oy*s,r*s);q.addColorStop(0,'#5fb04a');q.addColorStop(1,'#245f22');ell(x+ox*s,y+oy*s,r*s,r*s,q)}};
 [[330,40,1],[420,34,.9],[780,44,1.05],[945,36,.9],[1200,50,1.1],[1600,44,1],[1900,60,1.1],[1110,665,1],[1750,672,1.1],[1380,650,.95]].forEach(a=>tree(...a));
}
function dWorld(cx,cy,cl,al,wl,pl){
 X.save();X.translate(-cx,-cy);if(!BG)mkBG();X.drawImage(BG,0,0);
 if(truck){const t=truck;X.save();X.translate(t.x,t.y);el(0,2,80,8,'rgba(0,0,0,.3)');
  let g=X.createLinearGradient(0,-62,0,-10);g.addColorStop(0,'#fff');g.addColorStop(.5,'#dde6ee');g.addColorStop(1,'#8e9ba8');X.fillStyle=g;rr(X,-72,-62,94,52,9);X.fill();X.strokeStyle='#7a8794';X.lineWidth=1.5;X.stroke();
  g=X.createLinearGradient(0,-46,0,-8);g.addColorStop(0,'#e8453c');g.addColorStop(1,'#9c1f1a');X.fillStyle=g;rr(X,22,-46,46,38,7);X.fill();
  g=X.createLinearGradient(0,-42,0,-28);g.addColorStop(0,'#cfeaff');g.addColorStop(1,'#6fa6d3');X.fillStyle=g;rr(X,44,-42,20,15,3);X.fill();
  el(67,-17,3,4,'#fff3b0');X.fillStyle='#333';X.fillRect(60,-11,10,5);
  [-48,-22,42].forEach(o=>{el(o,-8,11,11,'#1b1b1b');el(o,-8,5.5,5.5,'#aab');el(o,-8,2,2,'#556')});
  X.fillStyle='#2b7bbf';X.font='bold 16px sans-serif';X.textAlign='center';X.fillText('МОЛОКО',-26,-30);el(-26,-47,5,6,'#2b7bbf');
  if(t.st==1){X.fillStyle='#fff';X.strokeStyle='#000';X.lineWidth=3;X.strokeText('⏱ '+Math.ceil(t.w),0,-74);X.fillText('⏱ '+Math.ceil(t.w),0,-74)}X.restore()}
 const e=[];cl.forEach(c=>e.push([c.y,()=>dCow(c)]));al.forEach(a=>e.push([a.y,()=>dEmo(a,a.k,26)]));wl.forEach(w=>e.push([w.y,()=>{dEmo(w,'🐺',38);if(w.hp<3){X.fillStyle='#e33';X.fillRect(w.x-15,w.y-48,10*w.hp,4)}}]));if(pl)e.push([pl.y,dPl]);e.sort((a,b)=>a[0]-b[0]).forEach(v=>v[1]());
 X.fillStyle='#fe5';bul.forEach(b=>{X.beginPath();X.arc(b.x,b.y,3,0,7);X.fill()});X.restore()}
function dHouse(){X.fillStyle='#b88a58';X.fillRect(0,0,W,H);X.fillStyle='#e0cfae';X.fillRect(0,0,W,170);X.fillStyle=dk()>.3?'#1a2850':'#8cd';X.fillRect(80,40,120,80);X.strokeStyle='#654';X.lineWidth=6;X.strokeRect(80,40,120,80);
 X.fillStyle='#6b3f1d';X.fillRect(695,55,190,115);X.fillStyle='#a44';X.fillRect(700,60,180,100);X.fillStyle='#fff';X.fillRect(705,68,48,84);X.fillStyle='#c66';X.fillRect(760,60,120,100);X.fillStyle='#5a3a1a';X.fillRect(430,505,100,35);
 X.fillStyle='rgba(60,40,20,.88)';X.fillRect(250,200,460,150);X.fillStyle='#fff';X.font='bold 20px sans-serif';X.textAlign='center';X.fillText('Инвентарь: вёдра с молоком '+buckets+'/10',480,230);
 for(let i=0;i<10;i++)bkt(290+(i%5)*95,270+(i>4?60:0),1.6,i<buckets);dPl()}
const rr=(c,x,y,w,h,r)=>{c.beginPath();c.moveTo(x+r,y);c.arcTo(x+w,y,x+w,y+h,r);c.arcTo(x+w,y+h,x,y+h,r);c.arcTo(x,y+h,x,y,r);c.arcTo(x,y,x+w,y,r);c.closePath()};
function vig(){if(!VG){VG=document.createElement('canvas');VG.width=W;VG.height=H;const c=VG.getContext('2d'),g=c.createRadialGradient(480,270,260,480,270,620);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.35)');c.fillStyle=g;c.fillRect(0,0,W,H)}X.drawImage(VG,0,0)}
function dTitle(){const cx=480,cy=108;X.save();X.globalCompositeOperation='lighter';
 let g=X.createRadialGradient(cx,cy,10,cx,cy,260);g.addColorStop(0,'rgba(255,200,90,'+(.35+.1*Math.sin(T*2))+')');g.addColorStop(1,'rgba(255,200,90,0)');X.fillStyle=g;X.fillRect(0,0,W,300);
 X.translate(cx,cy);X.rotate(T*.12);for(let i=0;i<14;i++){X.rotate(Math.PI*2/14);const l=340+Math.sin(T*1.5+i*1.7)*70,a=.1+.07*Math.sin(T*2+i);g=X.createLinearGradient(0,0,l,0);g.addColorStop(0,'rgba(255,230,140,'+a*2.4+')');g.addColorStop(1,'rgba(255,230,140,0)');X.fillStyle=g;X.beginPath();X.moveTo(0,0);X.lineTo(l,-20);X.lineTo(l,20);X.closePath();X.fill()}X.restore();
 X.save();X.translate(cx,cy+6);const q=1+.03*Math.sin(T*2);X.scale(q,q);X.font='bold 68px Georgia,serif';X.textBaseline='middle';X.textAlign='center';X.lineJoin='round';
 const tx='Моя ферма',ws=[...tx].map(ch=>X.measureText(ch).width),tw=ws.reduce((a,b)=>a+b,0);let x=-tw/2;
 for(let i=0;i<tx.length;i++){X.save();X.translate(x+ws[i]/2,Math.sin(T*2.4+i*.6)*6);X.rotate(Math.sin(T*1.8+i)*.04);
  X.shadowColor='rgba(255,190,60,.9)';X.shadowBlur=16+8*Math.sin(T*2);X.lineWidth=9;X.strokeStyle='#4a2a0a';X.strokeText(tx[i],0,0);X.shadowBlur=0;
  g=X.createLinearGradient(0,-34,0,34);g.addColorStop(0,'#fff6c8');g.addColorStop(.5,'#ffc933');g.addColorStop(1,'#e07a10');X.fillStyle=g;X.fillText(tx[i],0,0);
  X.fillStyle='rgba(255,255,255,'+Math.pow(Math.max(0,Math.sin(T*3-i*.7)),6)*.85+')';X.fillText(tx[i],0,0);X.restore();x+=ws[i]}
 X.restore();
 for(let i=0;i<12;i++){const t=T*.6+i*.52,x=cx+Math.cos(t*1.7+i)*270,y=cy+Math.sin(t*2.3+i*2)*50,s=Math.max(0,Math.sin(T*3+i*1.9))*9;if(s<.5)continue;X.fillStyle='rgba(255,250,210,.9)';X.beginPath();X.moveTo(x,y-s);X.lineTo(x+s*.25,y-s*.25);X.lineTo(x+s,y);X.lineTo(x+s*.25,y+s*.25);X.lineTo(x,y+s);X.lineTo(x-s*.25,y+s*.25);X.lineTo(x-s,y);X.lineTo(x-s*.25,y-s*.25);X.fill()}}
function dMenu(L){let g=X.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(10,20,40,.45)');g.addColorStop(1,'rgba(0,0,0,.65)');X.fillStyle=g;X.fillRect(0,0,W,H);
 if(sc=='menu')dTitle();else{X.textAlign='center';X.fillStyle='#fff';X.font='bold 52px sans-serif';X.fillText({pause:'Пауза',set:'Настройки',ctl:'Управление'}[sc],480,110)}
 X.textAlign='center';if(sc=='ctl'){X.fillStyle='#fff';X.font='18px sans-serif';['Клавиатура и мышь:','WASD / стрелки — ходьба · мышь — прицел · ЛКМ / Пробел — выстрел','E (удерживать) — доить, продавать молоко · E — войти/выйти из дома · спать — у кровати после 22:00','F — вести корову / отпустить на пастбище · Esc / ☰ — меню','Сенсор: левый палец — ходьба, правый — прицел и стрельба, ✋ и 🔗 — действия','Геймпад: левый стик — ходьба · правый стик — прицел · RT / RB — выстрел','A — доить / продавать / дом · X — вести корову · Start — меню · D-pad, A, B — навигация'].forEach((t,i)=>X.fillText(t,480,160+i*34))}
 const y0=sc=='ctl'?400:190;
 L.forEach((it,i)=>{const a=ba[i]||{h:0,p:0},k=clamp(ma*1.6-i*.2,0,1),e=1-Math.pow(1-k,3),sc2=1+.06*a.h-.1*a.p;
  X.save();X.globalAlpha=e;X.translate(480,y0+i*58+23+(1-e)*30);X.scale(sc2,sc2);
  X.shadowColor='rgba(0,0,0,.45)';X.shadowBlur=10+12*a.h;X.shadowOffsetY=4-3*a.p;
  g=X.createLinearGradient(0,-23,0,23);if(a.h>.5){g.addColorStop(0,'#ffe08a');g.addColorStop(1,'#f0a020')}else{g.addColorStop(0,'#fdfdf6');g.addColorStop(1,'#cfd6c2')}
  X.fillStyle=g;rr(X,-200,-23,400,46,14);X.fill();X.shadowColor='transparent';X.strokeStyle='rgba(255,255,255,.8)';X.lineWidth=2;X.stroke();
  if(a.p>0){X.save();rr(X,-200,-23,400,46,14);X.clip();const r=(1-a.p)*260;X.fillStyle='rgba(255,255,255,'+a.p*.6+')';X.beginPath();X.arc(0,0,r,0,7);X.fill();X.restore()}
  X.fillStyle='#3a2a10';X.font='bold 22px sans-serif';X.textBaseline='middle';X.fillText(it.t,0,1);
  if(it.adj&&a.h>.5){const o=Math.sin(T*6)*3;X.fillText('◀',-180-o,1);X.fillText('▶',180+o,1)}X.restore()})}
function clock(){const hh=Math.floor(gt/60),mm=Math.floor(gt%60);X.fillStyle='rgba(0,0,0,.5)';X.fillRect(410,10,140,34);X.fillStyle='#fff';X.font='bold 20px sans-serif';X.textAlign='center';X.fillText((hh<6||hh>=20?'🌙 ':'☀️ ')+String(hh).padStart(2,'0')+':'+String(mm).padStart(2,'0'),480,34)}
function dZz(){const t=zz.t,a=clamp(t<1.5?t/1.5:t<2.5?1:3.5-t,0,1);X.fillStyle='rgba(0,0,0,'+a+')';X.fillRect(0,0,W,H);X.globalAlpha=a;X.textAlign='center';X.fillStyle='#fff';X.font='bold 48px sans-serif';X.fillText('💤 '+(t<2?'Спокойной ночи…':'Новое утро'),480,280);X.globalAlpha=1}
function hud(){clock();X.fillStyle='rgba(0,0,0,.5)';X.fillRect(885,10,55,45);X.fillStyle='#fff';X.font='30px sans-serif';X.textAlign='center';X.fillText('☰',912,43);if(tc)dTouch();
 X.fillStyle='rgba(0,0,0,.5)';X.fillRect(10,10,230,74);X.fillStyle='#fff';X.font='bold 18px sans-serif';X.textAlign='left';X.fillText('Уровень '+level,20,32);X.fillText('💰 '+money,150,32);
 X.fillStyle='#333';X.fillRect(20,42,210,10);X.fillRect(20,62,210,10);X.fillStyle='#4cf';X.fillRect(20,42,210*Math.min(1,xp/need()),10);X.fillStyle='#e44';X.fillRect(20,62,210*P.hp/100,10);
 for(let i=0;i<10;i++){X.fillStyle='rgba(0,0,0,.5)';X.fillRect(250+i*46,H-56,42,42);bkt(271+i*46,H-35,1,i<buckets)}
 X.textAlign='center';X.font='bold 20px sans-serif';X.lineWidth=4;X.strokeStyle='#000';
 if(hint){X.strokeText(hint,480,H-70);X.fillStyle='#fff';X.fillText(hint,480,H-70)}
 if(msgT>0){X.strokeText(msg,480,76);X.fillStyle='#fd5';X.fillText(msg,480,76)}
 if(P.mt>0){X.fillStyle='#000';X.fillRect(430,H-110,100,8);X.fillStyle='#fff';X.fillRect(430,H-110,100*P.mt/1.2,8)}
 if(sc=='play'&&!ins&&(usePad||tc||!tc)){const r=(usePad||tc)?{x:P.x+Math.cos(P.a)*100-cam.x,y:P.y-22+Math.sin(P.a)*100-cam.y}:M;X.strokeStyle='#fff';X.lineWidth=2;X.beginPath();X.arc(r.x,r.y,10,0,7);X.moveTo(r.x-15,r.y);X.lineTo(r.x+15,r.y);X.moveTo(r.x,r.y-15);X.lineTo(r.x,r.y+15);X.stroke()}}
function dTouch(){const c=(x,y,r,t)=>{X.fillStyle='rgba(255,255,255,.25)';X.beginPath();X.arc(x,y,r,0,7);X.fill();X.strokeStyle='rgba(255,255,255,.7)';X.lineWidth=3;X.stroke();if(t){X.font=r*.8+'px serif';X.textAlign='center';X.fillStyle='#000';X.fillText(t,x,y+r*.28)}};
 c(880,430,45,'✋');c(790,480,36,'🔗');
 for(const[st,ix,iy]of[[tj,110,420],[tr,0,0]]){if(st.id!=null){c(st.ox,st.oy,60);c(st.ox+st.dx*60,st.oy+st.dy*60,26)}else if(ix)c(ix,iy,60)}}
function dLv(){const t=lv.t,a=clamp(t<1.5?t/1.5:t<3.5?1:(5-t)/1.5,0,1);X.fillStyle='rgba(0,0,0,'+.95*a+')';X.fillRect(0,0,W,H);X.globalAlpha=a;X.textAlign='center';X.fillStyle='#ffd34d';X.font='bold 72px sans-serif';X.fillText('Уровень '+lv.L,480,240);X.fillStyle='#fff';X.font='32px sans-serif';X.fillText('Награда: '+lv.r[0]+' '+lv.r[1],480,310);X.globalAlpha=1}
function draw(){
 if(ig){if(ins)dHouse();else dWorld(cam.x,cam.y,cows,ans,wolves,P);X.fillStyle='rgba(8,12,50,'+dk()*(ins?.5:1)+')';X.fillRect(0,0,W,H);if(!ins&&dk()>.15){X.fillStyle='rgba(255,205,110,'+dk()*.8+')';X.fillRect(77-cam.x,105-cam.y,36,32);X.fillRect(207-cam.x,105-cam.y,36,32)}if(S.gfx)vig();hud()}else{dWorld(40,60,demo,[],[],null);if(S.gfx)vig()}
 const L=menuList();if(L)dMenu(L);if(lv)dLv();if(zz)dZz()}
let last=0;function loop(ts){const dt=clamp((ts-last)/1000||0,0,.05);last=ts;poll();upd(dt);draw();pe={};requestAnimationFrame(loop)}
requestAnimationFrame(loop);
