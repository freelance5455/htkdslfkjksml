(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.SaleDomain = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const EPSILON = 1e-9;
  const messages = {
    EMPTY_CART: 'سبد فروش خالی است.',
    REQUIRED_FIELDS: 'غرفه، شماره فروش و تاریخ الزامی است.',
    INVALID_PAYMENT_SOURCE: 'منبع دریافت انتخاب‌شده معتبر نیست.',
    INVALID_PAYMENT_AMOUNT: 'مبلغ هر ردیف دریافت باید عدد صحیح و مثبت بر حسب ریال باشد.',
    PAYMENT_EXCEEDS_TOTAL: 'جمع مبالغ تسویه از مبلغ فروش بیشتر است.',
    POS_REFERENCE_REQUIRED: 'برای هر دریافت کارتخوان، کد پیگیری الزامی است.',
    INVALID_RECEIPT: 'مبلغ رسید باید عدد صحیح و غیرمنفی بر حسب ریال باشد.',
    INVALID_DAY: 'تاریخ فروش معتبر نیست.',
    PRODUCT_NOT_FOUND: 'یکی از کالاهای سبد در فهرست کالاها وجود ندارد.',
    PRODUCT_NOT_ASSIGNED: 'یکی از کالاها به غرفه انتخاب‌شده تخصیص ندارد.',
    PRODUCT_BLOCKED: 'قیمت یا وضعیت یکی از کالاها نیازمند تأیید حسابدار است.',
    INVALID_QUANTITY: 'تعداد یکی از اقلام معتبر نیست.',
    STOCK_RECORD_MISSING: 'برای یکی از کالاها در این غرفه رکورد موجودی وجود ندارد.',
    UNKNOWN_STOCK: 'موجودی یکی از کالاها نامشخص است؛ تا زمان ثبت شمارش معتبر، فروش آن مجاز نیست.',
    INVALID_STOCK: 'اطلاعات موجودی یا گردش قبلی معتبر نیست؛ ابتدا مغایرت انبار بررسی شود.',
    INSUFFICIENT_STOCK: 'تعداد فروش از موجودی قابل فروش بیشتر است.',
    POS_NOT_ASSIGNED: 'کارتخوان انتخاب‌شده به غرفه انتخابی تخصیص ندارد.',
    DUPLICATE_TRACKING: 'این کد پیگیری برای همین کارتخوان و تاریخ قبلاً ثبت شده است.',
    UNKNOWN_STOCK: 'موجودی نامشخص است؛ ابتدا شمارش معتبر ثبت شود.',
    INVALID_MOVEMENT: 'نوع یا مقدار گردش موجودی معتبر نیست.',
    INVALID_REFERENCE: 'شرح و شماره مستند گردش الزامی است.',
    RETURN_EXCEEDS_SOLD: 'مقدار برگشت از مقدار فروش‌رفته و برگشت‌های قبلی بیشتر است.',
    SALE_NOT_FOUND: 'فاکتور فروش مبنای برگشت پیدا نشد.',
    INVALID_TRANSFER: 'مبدأ و مقصد انتقال باید معتبر باشند.',
    INVALID_PURCHASE: 'اطلاعات رسید خرید کامل یا معتبر نیست.'
  };

  function failure(code, details) {
    return { ok: false, code, message: messages[code] || 'اطلاعات فروش معتبر نیست.', details: details || null };
  }

  function getCurrentStock(stock) {
    if (!stock) return null;
    const hasOpening = !(stock.openingQty === null || stock.openingQty === undefined || stock.openingQty === '');
    const opening = hasOpening ? Number(stock.openingQty) : null;
    if (hasOpening && (!Number.isFinite(opening) || opening < 0)) return null;
    let balance = opening;
    let known = hasOpening;
    const ordered = (Array.isArray(stock.movements) ? stock.movements : []).map((movement, index) => ({ movement, index }));
    ordered.sort((a, b) => {
      const ta = Date.parse(a.movement && a.movement.at || '');
      const tb = Date.parse(b.movement && b.movement.at || '');
      if (Number.isFinite(ta) && Number.isFinite(tb) && ta !== tb) return ta - tb;
      if (Number.isFinite(ta) !== Number.isFinite(tb)) return Number.isFinite(ta) ? -1 : 1;
      return a.index - b.index;
    });
    for (const { movement } of ordered) {
      if (movement && movement.type === 'COUNT') {
        const counted = Number(movement.countedQty);
        if (!Number.isFinite(counted) || counted < 0) return null;
        balance = counted; known = true; continue;
      }
      const delta = Number(movement && movement.delta);
      if (!Number.isFinite(delta)) return null;
      if (!known) continue; // Historical movements before the first verified count cannot establish a balance.
      balance += delta;
    }
    return known && Number.isFinite(balance) ? balance : null;
  }

  function prepareSale(input) {
    const {
      boothCode, boothName, boothHolderName, posCode, day, trackingCode, receiptAmount,
      payments: requestedPayments, cart, products, posTerminals, stockRecords,
      existingSales, userCode, createdAt, id
    } = input || {};

    if (!Array.isArray(cart) || cart.length === 0) return failure('EMPTY_CART');
    if (!boothCode || !day || !id) return failure('REQUIRED_FIELDS');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(day))) return failure('INVALID_DAY');
    const parsedDay = new Date(`${day}T00:00:00Z`);
    if (Number.isNaN(parsedDay.getTime()) || parsedDay.toISOString().slice(0, 10) !== day) return failure('INVALID_DAY');

    const productMap = new Map((products || []).map(p => [String(p.key), p]));
    const stockMap = new Map((stockRecords || []).map(s => [String(s.productKey), s]));
    const quantities = new Map();

    for (const item of cart) {
      const key = String(item && item.productKey || '');
      const qty = Number(item && item.qty);
      if (!key || !Number.isFinite(qty) || qty <= 0) return failure('INVALID_QUANTITY');
      const product = productMap.get(key);
      if (!product) return failure('PRODUCT_NOT_FOUND');
      if (!Array.isArray(product.assignedStalls) || !product.assignedStalls.includes(boothCode)) return failure('PRODUCT_NOT_ASSIGNED');
      const price = Number(product.price);
      if (product.saleBlocked || product.priceConflict || !Number.isFinite(price) || price <= 0) return failure('PRODUCT_BLOCKED');
      if (product.unit === 'کیلوگرم') {
        if (Math.abs(qty * 100 - Math.round(qty * 100)) > EPSILON) return failure('INVALID_QUANTITY');
      } else if (!Number.isInteger(qty)) {
        return failure('INVALID_QUANTITY');
      }
      quantities.set(key, (quantities.get(key) || 0) + qty);
    }

    const lines = [];
    const stockUpdates = [];
    let expectedAmount = 0;
    for (const [productKey, qty] of quantities) {
      const product = productMap.get(productKey);
      const stock = stockMap.get(productKey);
      if (!stock) return failure('STOCK_RECORD_MISSING', { productKey });
      if (stock.boothCode !== boothCode || stock.productKey !== productKey) return failure('STOCK_RECORD_MISSING', { productKey });
      const current = getCurrentStock(stock);
      if (current === null) {
        if (stock.openingQty === null || stock.openingQty === undefined || stock.openingQty === '') return failure('UNKNOWN_STOCK', { productKey });
        return failure('INVALID_STOCK', { productKey });
      }
      if (current < -EPSILON) return failure('INVALID_STOCK', { productKey, current });
      if (qty - current > EPSILON) return failure('INSUFFICIENT_STOCK', { productKey, requested: qty, available: Math.max(0, current) });

      const lineTotal = Math.round(Number(product.price) * qty);
      if (!Number.isSafeInteger(lineTotal) || lineTotal < 0) return failure('INVALID_RECEIPT', { productKey });
      expectedAmount += lineTotal;
      lines.push({ productKey: product.key, code: product.code, name: product.name, qty, unit: product.unit, unitPrice: Number(product.price), lineTotal });
      const movement = {
        id: `${id}:${productKey}`, delta: -qty, at: createdAt, type: 'SALE',
        stockId: stock.id || `${boothCode}::${productKey}`, boothCode,
        reason: 'فروش', saleId: id, productKey
      };
      stockUpdates.push({ ...stock, movements: [...(Array.isArray(stock.movements) ? stock.movements : []), movement] });
    }

    if (!Number.isSafeInteger(expectedAmount)) return failure('INVALID_RECEIPT');

    // Legacy sales (single POS receipt) are normalized to the new multi-source structure.
    let rawPayments = requestedPayments;
    if (!Array.isArray(rawPayments)) {
      const legacyAmount = Number(receiptAmount);
      if (!Number.isSafeInteger(legacyAmount) || legacyAmount < 0) return failure('INVALID_RECEIPT');
      rawPayments = legacyAmount > 0 ? [{ type: 'POS', amount: legacyAmount, posCode, trackingCode }] : [];
    }

    const normalizedPayments = [];
    const localReferences = new Set();
    let totalReceived = 0;
    for (const raw of rawPayments) {
      const type = String(raw && raw.type || '').toUpperCase();
      const amount = Number(raw && raw.amount);
      if (!['POS', 'CASH', 'PERSONNEL'].includes(type)) return failure('INVALID_PAYMENT_SOURCE');
      if (!Number.isSafeInteger(amount) || amount <= 0) return failure('INVALID_PAYMENT_AMOUNT');
      const payment = { type, amount };
      if (type === 'POS') {
        const paymentPos = String(raw.posCode || '').trim();
        const reference = String(raw.trackingCode || '').trim();
        const terminal = (posTerminals || []).find(p => String(p.code) === paymentPos);
        if (!terminal || terminal.boothCode !== boothCode) return failure('POS_NOT_ASSIGNED');
        if (!reference) return failure('POS_REFERENCE_REQUIRED');
        const refKey = `${day}::${paymentPos}::${reference}`;
        if (localReferences.has(refKey)) return failure('DUPLICATE_TRACKING');
        localReferences.add(refKey);
        payment.posCode = paymentPos;
        payment.trackingCode = reference;
      } else if (type === 'PERSONNEL') {
        payment.personnelName = String(raw.personnelName || '').trim();
        if (payment.personnelName.length > 100) return failure('INVALID_PAYMENT_SOURCE');
      } else {
        payment.note = String(raw.note || '').trim().slice(0, 160);
      }
      totalReceived += amount;
      if (!Number.isSafeInteger(totalReceived)) return failure('INVALID_RECEIPT');
      normalizedPayments.push(payment);
    }

    const duplicate = (existingSales || []).some(s => {
      if (s.day !== day) return false;
      const oldPayments = Array.isArray(s.payments) ? s.payments : (s.posCode && s.trackingCode ? [{ type: 'POS', posCode: s.posCode, trackingCode: s.trackingCode }] : []);
      return oldPayments.some(p => p.type === 'POS' && localReferences.has(`${day}::${p.posCode}::${String(p.trackingCode || '').trim()}`));
    });
    if (duplicate) return failure('DUPLICATE_TRACKING');
    if (totalReceived > expectedAmount) return failure('PAYMENT_EXCEEDS_TOTAL', { expectedAmount, totalReceived });

    const outstandingAmount = expectedAmount - totalReceived;
    const owner = String(boothHolderName || boothName || boothCode).trim();
    const firstPosPayment = normalizedPayments.find(p => p.type === 'POS');
    const difference = totalReceived - expectedAmount;
    const sale = {
      id, boothCode, boothName: boothName || boothCode, boothHolderName: owner,
      posCode: firstPosPayment?.posCode || 'NON_POS', day, createdAt,
      trackingCode: firstPosPayment?.trackingCode || '',
      payments: normalizedPayments,
      receiptAmount: totalReceived,
      totalReceived,
      expectedAmount,
      outstandingAmount,
      receivableAccountName: outstandingAmount > 0 ? owner : null,
      settlementStatus: outstandingAmount === 0 ? 'PAID' : totalReceived > 0 ? 'PARTIAL' : 'UNPAID',
      difference,
      status: Array.isArray(requestedPayments) ? 'MATCH' : (difference === 0 ? 'MATCH' : 'MISMATCH'),
      lines,
      createdBy: userCode
    };
    return { ok: true, sale, stockUpdates };
  }


  function validEffectiveAt(value) {
    if (typeof value !== 'string' || Number.isNaN(Date.parse(value))) return false;
    return /^\d{4}-\d{2}-\d{2}T/.test(value);
  }

  function prepareInventoryMovement(input) {
    const { id, boothCode, productKey, stock, product, type, qty, at, reason, reference, userCode } = input || {};
    if (!id || !boothCode || !productKey || !stock || stock.boothCode !== boothCode || stock.productKey !== productKey || !product) return failure('STOCK_RECORD_MISSING', { productKey });
    if (!Array.isArray(product.assignedStalls) || !product.assignedStalls.includes(boothCode)) return failure('PRODUCT_NOT_ASSIGNED', { productKey });
    if (!['COUNT', 'IN', 'OUT', 'ADJUST_UP', 'ADJUST_DOWN'].includes(type) || !validEffectiveAt(at)) return failure('INVALID_MOVEMENT');
    if (!String(reason || '').trim() || !String(reference || '').trim()) return failure('INVALID_REFERENCE');
    const quantity = Number(qty);
    if (!Number.isFinite(quantity) || quantity < 0 || (type !== 'COUNT' && quantity <= 0)) return failure('INVALID_MOVEMENT');
    if (product.unit === 'کیلوگرم') {
      if (Math.abs(quantity * 100 - Math.round(quantity * 100)) > EPSILON) return failure('INVALID_QUANTITY');
    } else if (!Number.isInteger(quantity)) return failure('INVALID_QUANTITY');
    const current = getCurrentStock(stock);
    if (type !== 'COUNT' && current === null) return failure('UNKNOWN_STOCK', { productKey });
    if (current !== null && current < -EPSILON) return failure('INVALID_STOCK', { current });
    const delta = type === 'IN' || type === 'ADJUST_UP' ? quantity : type === 'OUT' || type === 'ADJUST_DOWN' ? -quantity : 0;
    if (type !== 'COUNT' && current + delta < -EPSILON) return failure('INSUFFICIENT_STOCK', { requested: quantity, available: Math.max(0, current + (delta < 0 ? -delta : 0)) });
    const movement = {
      id, stockId: stock.id || `${boothCode}::${productKey}`, boothCode, productKey,
      type, qty: quantity, delta, countedQty: type === 'COUNT' ? quantity : undefined,
      at, reason: String(reason).trim(), reference: String(reference).trim(), createdBy: userCode || null
    };
    const updated = { ...stock, movements: [...(Array.isArray(stock.movements) ? stock.movements : []), movement] };
    return { ok: true, movement, stock: updated, balance: getCurrentStock(updated) };
  }

  function prepareSaleReturn(input) {
    const { id, sale, stockRecords, priorReturns, items, at, userCode, reason } = input || {};
    if (!sale || !sale.id) return failure('SALE_NOT_FOUND');
    if (!id || !validEffectiveAt(at) || !String(reason || '').trim() || !Array.isArray(items) || !items.length) return failure('INVALID_MOVEMENT');
    const stockMap = new Map((stockRecords || []).map(s => [String(s.productKey), s]));
    const soldMap = new Map();
    for (const line of (sale.lines || [])) soldMap.set(String(line.productKey), (soldMap.get(String(line.productKey)) || 0) + Number(line.qty));
    const returnedMap = new Map();
    for (const prior of (priorReturns || [])) {
      if (String(prior.sourceSaleId) !== String(sale.id) || prior.type !== 'SALE_RETURN') continue;
      const key = String(prior.productKey);
      returnedMap.set(key, (returnedMap.get(key) || 0) + Number(prior.qty));
    }
    const requested = new Map();
    for (const item of items) {
      const key = String(item && item.productKey || '');
      const qty = Number(item && item.qty);
      if (!key || !Number.isFinite(qty) || qty <= 0) return failure('INVALID_QUANTITY');
      requested.set(key, (requested.get(key) || 0) + qty);
    }
    const stockUpdates = [], ledgerMovements = [], returnLines = [];
    let returnedAmount = 0;
    for (const [key, qty] of requested) {
      const sold = soldMap.get(key) || 0;
      const already = returnedMap.get(key) || 0;
      if (sold <= 0 || already + qty - sold > EPSILON) return failure('RETURN_EXCEEDS_SOLD', { productKey: key, sold, alreadyReturned: already, requested: qty });
      const stock = stockMap.get(key);
      if (!stock || stock.boothCode !== sale.boothCode) return failure('STOCK_RECORD_MISSING', { productKey: key });
      const current = getCurrentStock(stock);
      if (current === null) return failure('UNKNOWN_STOCK', { productKey: key });
      const sourceLine = (sale.lines || []).find(line => String(line.productKey) === key);
      if (sourceLine.unit === 'کیلوگرم') {
        if (Math.abs(qty * 100 - Math.round(qty * 100)) > EPSILON) return failure('INVALID_QUANTITY');
      } else if (!Number.isInteger(qty)) return failure('INVALID_QUANTITY');
      const unitPrice = Number(sourceLine.unitPrice);
      if (!Number.isFinite(unitPrice) || unitPrice < 0) return failure('INVALID_RECEIPT');
      const lineAmount = Math.round(unitPrice * qty);
      returnedAmount += lineAmount;
      const movement = {
        id: `${id}:${key}`, stockId: stock.id || `${sale.boothCode}::${key}`,
        boothCode: sale.boothCode, productKey: key, type: 'SALE_RETURN', qty, delta: qty,
        at, reason: String(reason).trim(), returnId: id, sourceSaleId: sale.id,
        createdBy: userCode || null
      };
      stockUpdates.push({ ...stock, movements: [...(Array.isArray(stock.movements) ? stock.movements : []), movement] });
      ledgerMovements.push(movement);
      returnLines.push({ productKey: key, qty, unitPrice, lineAmount, name: sourceLine.name, unit: sourceLine.unit });
    }
    if (!Number.isSafeInteger(returnedAmount)) return failure('INVALID_RECEIPT');
    return { ok: true, returnRecord: { id, type: 'SALE_RETURN', sourceSaleId: sale.id, boothCode: sale.boothCode, at, reason: String(reason).trim(), items: returnLines, returnedAmount, createdBy: userCode || null }, stockUpdates, ledgerMovements };
  }

  function prepareInventoryTransfer(input) {
    const {
      id, transferId, product, fromBoothCode, toBoothCode,
      sourceStock, destinationStock, qty, at, reference, reason, userCode
    } = input || {};
    if (!id || !transferId || !fromBoothCode || !toBoothCode || fromBoothCode === toBoothCode) return failure('INVALID_TRANSFER');
    if (!sourceStock || sourceStock.boothCode !== fromBoothCode || !destinationStock || destinationStock.boothCode !== toBoothCode || !product) {
      return failure('STOCK_RECORD_MISSING', { fromBoothCode, toBoothCode });
    }
    if (sourceStock.productKey !== product.key || destinationStock.productKey !== product.key) return failure('STOCK_RECORD_MISSING', { productKey: product.key });
    if (!Array.isArray(product.assignedStalls) || !product.assignedStalls.includes(fromBoothCode) || !product.assignedStalls.includes(toBoothCode)) {
      return failure('PRODUCT_NOT_ASSIGNED', { productKey: product.key, fromBoothCode, toBoothCode });
    }
    if (!validEffectiveAt(at) || !String(reference || '').trim() || !String(reason || '').trim()) return failure('INVALID_REFERENCE');
    const quantity = Number(qty);
    if (!Number.isFinite(quantity) || quantity <= 0) return failure('INVALID_MOVEMENT');
    if (product.unit === 'کیلوگرم') {
      if (Math.abs(quantity * 100 - Math.round(quantity * 100)) > EPSILON) return failure('INVALID_QUANTITY');
    } else if (!Number.isInteger(quantity)) return failure('INVALID_QUANTITY');

    const sourceBalance = getCurrentStock(sourceStock);
    const destinationBalance = getCurrentStock(destinationStock);
    if (sourceBalance === null || destinationBalance === null) return failure('UNKNOWN_STOCK', { fromBoothCode, toBoothCode, productKey: product.key });
    if (sourceBalance < -EPSILON || destinationBalance < -EPSILON) return failure('INVALID_STOCK', { sourceBalance, destinationBalance });
    if (quantity - sourceBalance > EPSILON) return failure('INSUFFICIENT_STOCK', { requested: quantity, available: Math.max(0, sourceBalance) });

    const cleanReason = String(reason).trim();
    const cleanReference = String(reference).trim();
    const common = {
      transferId, productKey: product.key, qty: quantity, at,
      reason: cleanReason, reference: cleanReference, createdBy: userCode || null
    };
    const outbound = {
      ...common, id: `${transferId}:OUT`, stockId: sourceStock.id || `${fromBoothCode}::${product.key}`,
      boothCode: fromBoothCode, type: 'TRANSFER_OUT', delta: -quantity, transferSide: 'OUT',
      peerBoothCode: toBoothCode
    };
    const inbound = {
      ...common, id: `${transferId}:IN`, stockId: destinationStock.id || `${toBoothCode}::${product.key}`,
      boothCode: toBoothCode, type: 'TRANSFER_IN', delta: quantity, transferSide: 'IN',
      peerBoothCode: fromBoothCode
    };
    const updatedSource = { ...sourceStock, movements: [...(Array.isArray(sourceStock.movements) ? sourceStock.movements : []), outbound] };
    const updatedDestination = { ...destinationStock, movements: [...(Array.isArray(destinationStock.movements) ? destinationStock.movements : []), inbound] };
    return {
      ok: true,
      transferRecord: {
        id: transferId, productKey: product.key, fromBoothCode, toBoothCode,
        qty: quantity, at, reference: cleanReference, reason: cleanReason, createdBy: userCode || null
      },
      movements: [outbound, inbound],
      sourceStock: updatedSource,
      destinationStock: updatedDestination,
      sourceBalance: getCurrentStock(updatedSource),
      destinationBalance: getCurrentStock(updatedDestination)
    };
  }

  function prepareCentralPurchase(input) {
    const { id, invoiceNo, supplier, day, items, stockRecords, products, userCode, createdAt } = input || {};
    if (!id || !String(invoiceNo || '').trim() || !String(supplier || '').trim() || !/^\d{4}-\d{2}-\d{2}$/.test(String(day || '')) || !Array.isArray(items) || !items.length) return failure('INVALID_PURCHASE');
    const productMap = new Map((products || []).map(p => [String(p.key), p]));
    const stockMap = new Map((stockRecords || []).map(s => [String(s.productKey), s]));
    const totals = new Map();
    for (const item of items) {
      const key = String(item.productKey || ''), qty = Number(item.qty), product = productMap.get(key);
      if (!product || !Number.isFinite(qty) || qty <= 0) return failure('INVALID_QUANTITY');
      if (product.unit === 'کیلوگرم' ? Math.abs(qty * 100 - Math.round(qty * 100)) > EPSILON : !Number.isInteger(qty)) return failure('INVALID_QUANTITY');
      totals.set(key, (totals.get(key) || 0) + qty);
    }
    const stockUpdates = [], lines = [];
    for (const [productKey, qty] of totals) {
      const product = productMap.get(productKey);
      const stock = stockMap.get(productKey) || { id: `CENTRAL::${productKey}`, boothCode: 'CENTRAL', productKey, openingQty: 0, movements: [] };
      if (stock.boothCode !== 'CENTRAL' || stock.productKey !== productKey) return failure('STOCK_RECORD_MISSING');
      const movement = { id: `${id}:${productKey}`, stockId: stock.id, boothCode: 'CENTRAL', productKey, type: 'PURCHASE_IN', qty, delta: qty, at: createdAt, reference: String(invoiceNo).trim(), purchaseId: id, reason: `رسید خرید از ${String(supplier).trim()}`, createdBy: userCode || null };
      const updated = { ...stock, movements: [...(stock.movements || []), movement] };
      stockUpdates.push(updated); lines.push({ productKey, name: product.name, code: product.code, unit: product.unit, qty });
    }
    return { ok: true, purchase: { id, invoiceNo: String(invoiceNo).trim(), supplier: String(supplier).trim(), day, lines, createdAt, createdBy: userCode || null }, stockUpdates };
  }

  function prepareCentralTransfer(input) {
    const { id, product, sourceStock, destinationStock, toBoothCode, qty, at, reference, reason, userCode } = input || {};
    if (!id || !toBoothCode || toBoothCode === 'CENTRAL' || !product || !sourceStock || sourceStock.boothCode !== 'CENTRAL' || sourceStock.productKey !== product.key || !destinationStock || destinationStock.boothCode !== toBoothCode || destinationStock.productKey !== product.key) return failure('INVALID_TRANSFER');
    if (!Array.isArray(product.assignedStalls) || !product.assignedStalls.includes(toBoothCode)) return failure('PRODUCT_NOT_ASSIGNED');
    if (!validEffectiveAt(at) || !String(reference || '').trim() || !String(reason || '').trim()) return failure('INVALID_REFERENCE');
    const quantity = Number(qty);
    if (!Number.isFinite(quantity) || quantity <= 0) return failure('INVALID_MOVEMENT');
    if (product.unit === 'کیلوگرم' ? Math.abs(quantity * 100 - Math.round(quantity * 100)) > EPSILON : !Number.isInteger(quantity)) return failure('INVALID_QUANTITY');
    const sourceBalance = getCurrentStock(sourceStock), destinationBalance = getCurrentStock(destinationStock);
    if (sourceBalance === null || destinationBalance === null) return failure('UNKNOWN_STOCK');
    if (quantity - sourceBalance > EPSILON) return failure('INSUFFICIENT_STOCK', { requested: quantity, available: sourceBalance });
    const common = { transferId: id, productKey: product.key, qty: quantity, at, reference: String(reference).trim(), reason: String(reason).trim(), createdBy: userCode || null };
    const outbound = { ...common, id: `${id}:OUT`, stockId: sourceStock.id, boothCode: 'CENTRAL', type: 'WAREHOUSE_TRANSFER_OUT', delta: -quantity, peerBoothCode: toBoothCode };
    const inbound = { ...common, id: `${id}:IN`, stockId: destinationStock.id, boothCode: toBoothCode, type: 'WAREHOUSE_TRANSFER_IN', delta: quantity, peerBoothCode: 'CENTRAL' };
    const updatedSource = { ...sourceStock, movements: [...(sourceStock.movements || []), outbound] };
    const updatedDestination = { ...destinationStock, movements: [...(destinationStock.movements || []), inbound] };
    return { ok: true, movements: [outbound, inbound], sourceStock: updatedSource, destinationStock: updatedDestination, sourceBalance: getCurrentStock(updatedSource), destinationBalance: getCurrentStock(updatedDestination), transfer: { id, from: 'CENTRAL', to: toBoothCode, productKey: product.key, qty: quantity, at, reference: String(reference).trim(), reason: String(reason).trim(), createdBy: userCode || null } };
  }

  function buildProductCardex(input) {
    const { stock, ledgerRecords, fromAt, toAt } = input || {};
    if (!stock) return { openingBalance: null, closingBalance: null, rows: [], isKnown: false };
    const stockId = String(stock.id || stock.stockKey || `${stock.boothCode}::${stock.productKey}`);
    const merged = new Map();
    for (const movement of (Array.isArray(stock.movements) ? stock.movements : [])) {
      if (movement && movement.id) merged.set(String(movement.id), movement);
    }
    for (const movement of (Array.isArray(ledgerRecords) ? ledgerRecords : [])) {
      if (!movement || !movement.id || String(movement.stockId || '') !== stockId) continue;
      if (!merged.has(String(movement.id))) merged.set(String(movement.id), movement);
    }
    const movements = [...merged.values()].filter(m => Number.isFinite(Date.parse(m.at || '')));
    movements.sort((a, b) => {
      const diff = Date.parse(a.at) - Date.parse(b.at);
      return diff || String(a.id).localeCompare(String(b.id));
    });
    const fromTime = fromAt ? Date.parse(fromAt) : -Infinity;
    const toTime = toAt ? Date.parse(toAt) : Infinity;
    let balance = stock.openingQty === null || stock.openingQty === undefined || stock.openingQty === '' ? null : Number(stock.openingQty);
    if (balance !== null && (!Number.isFinite(balance) || balance < 0)) balance = null;
    let openingBalance = null;
    let openingCaptured = false;
    const rows = [];
    for (const movement of movements) {
      const time = Date.parse(movement.at);
      if (time > toTime) break;
      const before = balance;
      if (movement.type === 'COUNT') {
        const counted = Number(movement.countedQty ?? movement.qty);
        balance = Number.isFinite(counted) && counted >= 0 ? counted : null;
      } else {
        const delta = Number(movement.delta);
        if (balance !== null && Number.isFinite(delta)) balance += delta;
      }
      if (time < fromTime) continue;
      if (!openingCaptured) { openingBalance = before; openingCaptured = true; }
      const delta = Number(movement.delta);
      const safeDelta = Number.isFinite(delta) ? delta : 0;
      rows.push({
        ...movement,
        opening: before,
        inbound: movement.type === 'COUNT' ? 0 : Math.max(0, safeDelta),
        outbound: movement.type === 'COUNT' ? 0 : Math.max(0, -safeDelta),
        countedQty: movement.type === 'COUNT' ? Number(movement.countedQty ?? movement.qty) : null,
        balance
      });
    }
    if (!openingCaptured) {
      openingBalance = balance;
    }
    return { stockId, openingBalance, closingBalance: balance, rows, isKnown: balance !== null };
  }

  function auditInventoryLedger(stockRecords, ledgerRecords) {
    const ledger = new Map((ledgerRecords || []).map(m => [String(m.id), m]));
    const embedded = new Map();
    const findings = [];
    for (const stock of (stockRecords || [])) {
      for (const movement of (stock.movements || [])) {
        if (!movement || !movement.type || movement.type === 'SALE' && !movement.stockId) continue;
        embedded.set(String(movement.id), { movement, stockId: String(stock.id || stock.stockKey) });
        const mirror = ledger.get(String(movement.id));
        if (!mirror) findings.push({ code: 'MISSING_LEDGER_RECORD', movementId: movement.id, stockId: String(stock.id || stock.stockKey), type: movement.type });
        else if (String(mirror.stockId) !== String(stock.id || stock.stockKey) || Number(mirror.delta) !== Number(movement.delta) || String(mirror.type) !== String(movement.type)) findings.push({ code: 'LEDGER_MISMATCH', movementId: movement.id, stockId: String(stock.id || stock.stockKey) });
      }
    }
    for (const record of (ledgerRecords || [])) {
      if (!embedded.has(String(record.id))) findings.push({ code: 'ORPHAN_LEDGER_RECORD', movementId: record.id, stockId: record.stockId || null, type: record.type });
    }
    const transfers = new Map();
    for (const movement of (ledgerRecords || [])) {
      if (!movement.transferId) continue;
      const key = String(movement.transferId);
      if (!transfers.has(key)) transfers.set(key, []);
      transfers.get(key).push(movement);
    }
    for (const [transferId, pair] of transfers) {
      const outs = pair.filter(m => m.type === 'TRANSFER_OUT' && m.transferSide === 'OUT');
      const ins = pair.filter(m => m.type === 'TRANSFER_IN' && m.transferSide === 'IN');
      if (pair.length !== 2 || outs.length !== 1 || ins.length !== 1) {
        findings.push({ code: 'TRANSFER_PAIR_INCOMPLETE', transferId, movementIds: pair.map(m => m.id) });
        continue;
      }
      if (Math.abs(Number(outs[0].delta) + Number(ins[0].delta)) > EPSILON || Number(outs[0].qty) !== Number(ins[0].qty) || String(outs[0].productKey) !== String(ins[0].productKey)) {
        findings.push({ code: 'TRANSFER_PAIR_MISMATCH', transferId, movementIds: pair.map(m => m.id) });
      }
    }
    return { movementCount: embedded.size, ledgerCount: (ledgerRecords || []).length, issueCount: findings.length, findings: findings.slice(0, 100) };
  }

  function auditSalesInventory(sales, stockRecords) {
    const stockMap = new Map((stockRecords || []).map(stock => [String(stock.id || stock.stockKey), stock]));
    const findings = [];
    let lineCount = 0;
    let okLines = 0;
    for (const sale of (sales || [])) {
      for (const line of (sale.lines || [])) {
        lineCount += 1;
        const stockId = `${sale.boothCode}::${line.productKey}`;
        const stock = stockMap.get(stockId);
        if (!stock) {
          findings.push({ code: 'MISSING_STOCK_RECORD', saleId: sale.id, boothCode: sale.boothCode, productKey: line.productKey, productName: line.name });
          continue;
        }
        const related = (Array.isArray(stock.movements) ? stock.movements : []).filter(m => m.saleId === sale.id);
        const expectedDelta = -Number(line.qty);
        if (!related.length) {
          findings.push({ code: 'MISSING_STOCK_MOVEMENT', saleId: sale.id, boothCode: sale.boothCode, productKey: line.productKey, productName: line.name, expectedDelta });
          continue;
        }
        const actualDelta = related.reduce((sum, m) => sum + Number(m.delta), 0);
        if (!Number.isFinite(actualDelta) || Math.abs(actualDelta - expectedDelta) > EPSILON) {
          findings.push({ code: 'STOCK_MOVEMENT_MISMATCH', saleId: sale.id, boothCode: sale.boothCode, productKey: line.productKey, productName: line.name, expectedDelta, actualDelta });
          continue;
        }
        okLines += 1;
      }
    }
    return {
      salesCount: (sales || []).length,
      lineCount,
      okLines,
      issueCount: findings.length,
      missingStockRecords: findings.filter(x => x.code === 'MISSING_STOCK_RECORD').length,
      missingMovements: findings.filter(x => x.code === 'MISSING_STOCK_MOVEMENT').length,
      mismatchedMovements: findings.filter(x => x.code === 'STOCK_MOVEMENT_MISMATCH').length,
      findings: findings.slice(0, 100)
    };
  }

  return { prepareSale, getCurrentStock, auditSalesInventory, prepareInventoryMovement, prepareSaleReturn, prepareInventoryTransfer, prepareCentralPurchase, prepareCentralTransfer, buildProductCardex, auditInventoryLedger, messages };
});
