package com.hasanjassim.followup;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.*;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class MainActivity extends AppCompatActivity {
    WebView web;
    static final int REQ_NOTIF=1001, REQ_SAVE_FILE=2001, REQ_OPEN_FILE=2002;
    ValueCallback<Uri[]> fileChooserCallback;
    byte[] pendingFileBytes;
    String pendingMime="application/octet-stream";

    @Override public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main); web=findViewById(R.id.web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setDefaultTextEncodingName("UTF-8");
        web.setWebViewClient(new WebViewClient(){
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error){
                super.onReceivedError(view, request, error);
                if (request != null && request.isForMainFrame()) {
                    String failed = request.getUrl() == null ? "غير معروف" : request.getUrl().toString();
                    String desc = error == null ? "خطأ غير معروف" : String.valueOf(error.getDescription());
                    showLoadError(failed, desc);
                }
            }
            @Override public void onReceivedError(WebView view, int errorCode, String description, String failingUrl){
                super.onReceivedError(view, errorCode, description, failingUrl);
                if (Build.VERSION.SDK_INT < 23) showLoadError(failingUrl, description);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
                Uri uri=request.getUrl();
                if(uri!=null && ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))){
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception ignored) { }
                    return true;
                }
                return false;
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){
                Uri uri=Uri.parse(url);
                if(uri!=null && ("https".equalsIgnoreCase(uri.getScheme()) || "http".equalsIgnoreCase(uri.getScheme()))){
                    try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception ignored) { }
                    return true;
                }
                return false;
            }
        });
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(fileChooserCallback!=null)fileChooserCallback.onReceiveValue(null);
                fileChooserCallback=callback;
                try{Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("application/json");pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(pick,REQ_OPEN_FILE);return true;}
                catch(Exception e){fileChooserCallback=null;return false;}
            }
        });
        web.addJavascriptInterface(new AndroidBridge(this),"AndroidApp");
        // Load the bundled page through AssetManager and loadDataWithBaseURL. This avoids
        // WebView's generic "Web page not available" screen when asset URL resolution fails.
        loadBundledPage();
        if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
        NotificationHelper.createChannels(this);
        // Keep the requested daily summaries scheduled even on a fresh install.
        ReminderScheduler.scheduleDaily(this,9,0,"ملخص مواعيد اليوم","موعد اليوم");
        ReminderScheduler.scheduleDaily(this,19,0,"ملخص مواعيد الغد","مواعيد الغد");
    }

    private void loadBundledPage(){
        try (InputStream in = getAssets().open("index.html")) {
            // Confirm the HTML asset is packaged, then use Android's standard asset URL.
            in.close();
            web.loadUrl("file:///android_asset/index.html");
        } catch (Exception e) {
            showLoadError("file:///android_asset/index.html", e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage()));
        }
    }

    private void showLoadError(String failedUrl, String description){
        String safeUrl = android.text.TextUtils.htmlEncode(String.valueOf(failedUrl));
        String safeDescription = android.text.TextUtils.htmlEncode(String.valueOf(description));
        String html = "<!doctype html><html lang='ar' dir='rtl'><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'><body style='font-family:sans-serif;padding:24px;color:#18243a;background:#fff'><h2>تعذر تحميل واجهة إنجاز</h2><p>لم يتم تحميل الصفحة الرئيسية داخل التطبيق.</p><p><b>العنوان:</b><br><code style='overflow-wrap:anywhere'>"+safeUrl+"</code></p><p><b>تفاصيل الخطأ:</b><br>"+safeDescription+"</p><p>تحقق من وجود الملف app/src/main/assets/index.html داخل المشروع، ثم أعد بناء APK وتثبيته.</p></body></html>";
        runOnUiThread(() -> web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null));
    }

    public void openExactAlarmSettings(){ if(Build.VERSION.SDK_INT>=31){ try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:"+getPackageName())));}catch(Exception ignored){} } }

    public class AndroidBridge {
        Context c; AndroidBridge(Context c){this.c=c;}
        @JavascriptInterface public String getSavedAppointments(){ return getSharedPreferences("data",0).getString("appointments","[]"); }
        @JavascriptInterface public void scheduleReminder(String json){ try{ ReminderScheduler.schedule(c,new JSONObject(json)); }catch(Exception ignored){} }
        @JavascriptInterface public void cancelReminder(String id){ ReminderScheduler.cancel(c,id); }
        @JavascriptInterface public void syncAppointments(String json){
            try {
                JSONArray appointments=new JSONArray(json); JSONArray reminders=new JSONArray();
                for(int i=0;i<appointments.length();i++){
                    JSONObject a=appointments.getJSONObject(i); JSONArray rs=a.optJSONArray("reminders"); if(rs==null)continue;
                    for(int j=0;j<rs.length();j++){
                        JSONObject r=rs.getJSONObject(j); long at=r.optLong("at",0); if(at<=System.currentTimeMillis())continue;
                        JSONObject normalized=new JSONObject(); String id=r.optString("id",a.optString("id")+"_"+j);
                        normalized.put("id",id); normalized.put("at",at); normalized.put("title","🔔 "+a.optString("name","موعد"));
                        normalized.put("body",r.optString("label","حان وقت التنبيه")+" — "+a.optString("date","")+" "+a.optString("time",""));
                        normalized.put("type",r.optString("type","both")); reminders.put(normalized);
                    }
                }
                android.content.SharedPreferences prefs=getSharedPreferences("data",0);
                String old=prefs.getString("reminders","[]"), next=reminders.toString();
                JSONArray previous;
                try { previous=new JSONArray(old); } catch(Exception malformed){ previous=new JSONArray(); }
                prefs.edit().putString("appointments",json).putString("reminders",next).apply();
                // Reconcile every sync so edits/deletes and previously missed alarms are repaired.
                for(int i=0;i<previous.length();i++) ReminderScheduler.cancel(c,previous.getJSONObject(i).optString("id",""));
                for(int i=0;i<reminders.length();i++) ReminderScheduler.schedule(c,reminders.getJSONObject(i));
            } catch(Exception ignored) { getSharedPreferences("data",0).edit().putString("appointments",json).apply(); }
        }
        @JavascriptInterface public void requestExactAlarmPermission(){ openExactAlarmSettings(); }
        @JavascriptInterface public void openExternal(String url){ try { Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url)); startActivity(i); } catch(Exception e){ runOnUiThread(()->Toast.makeText(MainActivity.this,"تعذر فتح الرابط. تحقق من تثبيت واتساب أو الاتصال بالإنترنت.",Toast.LENGTH_LONG).show()); } }
        @JavascriptInterface public void scheduleDailySummaries(){ ReminderScheduler.scheduleDaily(c,9,0,"ملخص مواعيد اليوم","موعد اليوم"); ReminderScheduler.scheduleDaily(c,19,0,"ملخص مواعيد الغد","مواعيد الغد"); }
        @JavascriptInterface public void cancelAllReminders(){ ReminderScheduler.cancelAll(c); }
        @JavascriptInterface public void saveFile(String name,String mime,String base64){
            try { pendingFileBytes=android.util.Base64.decode(base64,android.util.Base64.DEFAULT); pendingMime=mime;
                runOnUiThread(()->{Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType(mime==null||mime.isEmpty()?"application/octet-stream":mime);intent.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(intent,REQ_SAVE_FILE);});
            } catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"تعذر تجهيز الملف للحفظ",Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void printHtml(String html){ runOnUiThread(()->startHtmlPrint(html)); }
    }

    private void startHtmlPrint(String html){
        try {
            WebView printView=new WebView(this); printView.getSettings().setJavaScriptEnabled(false);
            printView.setWebViewClient(new WebViewClient(){
                @Override public void onPageFinished(WebView view,String url){
                    PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                    String jobName="تقرير المواعيد";
                    pm.print(jobName,view.createPrintDocumentAdapter(jobName),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("report","Report",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
                }
            });
            printView.loadDataWithBaseURL("file:///android_asset/",html,"text/HTML","UTF-8",null);
        } catch(Exception e){Toast.makeText(this,"تعذر فتح نافذة الطباعة",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_OPEN_FILE){
            if(fileChooserCallback!=null){Uri[] result=(resultCode==RESULT_OK && data!=null && data.getData()!=null)?new Uri[]{data.getData()}:null;fileChooserCallback.onReceiveValue(result);fileChooserCallback=null;}
            return;
        }
        if(requestCode==REQ_SAVE_FILE){
            try {
                if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingFileBytes!=null){
                    try(OutputStream out=getContentResolver().openOutputStream(data.getData())){ if(out!=null){out.write(pendingFileBytes);out.flush();Toast.makeText(this,"تم حفظ الملف بنجاح",Toast.LENGTH_LONG).show();} else Toast.makeText(this,"تعذر فتح الملف للحفظ",Toast.LENGTH_LONG).show(); }
                }
            } catch(Exception e){Toast.makeText(this,"تعذر حفظ الملف",Toast.LENGTH_LONG).show();}
            finally{pendingFileBytes=null;}
        }
    }
}
