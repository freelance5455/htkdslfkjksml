package com.hasanjassim.followup;
import android.content.*;import org.json.*;import java.text.*;import java.util.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");String title=i.getStringExtra("title");String body=i.getStringExtra("body");String type=i.getStringExtra("type");
  if(i.getBooleanExtra("daily",false)){ body=buildSummary(c,i.getIntExtra("hour",9)==19); }
  NotificationHelper.show(c,title,body,type,id==null?System.currentTimeMillis()>Integer.MAX_VALUE?1:(int)System.currentTimeMillis():Math.abs(id.hashCode())); }
 private String buildSummary(Context c,boolean tomorrow){try{String s=c.getSharedPreferences("data",0).getString("appointments","[]");JSONArray a=new JSONArray(s);Calendar now=Calendar.getInstance();if(tomorrow)now.add(Calendar.DATE,1);String d=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(now.getTime());StringBuilder b=new StringBuilder();int n=0;for(int j=0;j<a.length();j++){JSONObject x=a.getJSONObject(j);if(d.equals(x.optString("date"))){n++;b.append("• ").append(x.optString("time")).append(" — ").append(x.optString("name")).append("\n");}}return n==0?"لا توجد مواعيد.":b.toString();}catch(Exception e){return "تعذر قراءة المواعيد.";}}
}
