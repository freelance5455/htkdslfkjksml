package com.hasanjassim.followup;
import android.app.*;import android.content.*;import android.os.Build;import androidx.core.app.NotificationCompat;
public class NotificationHelper {
 public static final String SOUND="rem_sound", POPUP="rem_popup", BOTH="rem_both", SUMMARY="daily_summary";
 public static void createChannels(Context c){ if(Build.VERSION.SDK_INT<26)return; NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  n.createNotificationChannel(new NotificationChannel(SOUND,"تنبيه صوتي",NotificationManager.IMPORTANCE_DEFAULT));
  NotificationChannel popup=new NotificationChannel(POPUP,"رسالة منبثقة",NotificationManager.IMPORTANCE_HIGH);popup.setSound(null,null);n.createNotificationChannel(popup);
  n.createNotificationChannel(new NotificationChannel(BOTH,"صوت + رسالة منبثقة",NotificationManager.IMPORTANCE_HIGH));
  n.createNotificationChannel(new NotificationChannel(SUMMARY,"الملخصات اليومية",NotificationManager.IMPORTANCE_HIGH));
 }
 public static void show(Context c,String title,String body,String type,int id){ createChannels(c); String ch=type.equals("popup")?POPUP:type.equals("both")?BOTH:SOUND;
  NotificationCompat.Builder b=new NotificationCompat.Builder(c,ch).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setAutoCancel(true).setPriority(type.equals("sound")?NotificationCompat.PRIORITY_DEFAULT:NotificationCompat.PRIORITY_HIGH);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build()); }
}
