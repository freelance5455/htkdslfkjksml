package com.hasanjassim.followup;
import android.app.*;import android.content.*;import android.os.*;import org.json.*;import java.util.*;
public class ReminderScheduler {
 static int code(String id){int v=id==null?1:id.hashCode(); return v==Integer.MIN_VALUE?1:Math.max(1,Math.abs(v));}
 public static void schedule(Context c, JSONObject o)throws Exception{ String id=o.getString("id"); long at=o.getLong("at"); Intent i=new Intent(c,ReminderReceiver.class); i.putExtra("id",id);i.putExtra("title",o.optString("title","موعد"));i.putExtra("body",o.optString("body","حان وقت التنبيه"));i.putExtra("type",o.optString("type","both"));
  PendingIntent p=PendingIntent.getBroadcast(c,code(id),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  if(at<=System.currentTimeMillis()){a.cancel(p);return;}
  try {
   if(Build.VERSION.SDK_INT>=31 && !a.canScheduleExactAlarms()){ a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p); }
   else if(Build.VERSION.SDK_INT>=23){ a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p); }
   else a.setExact(AlarmManager.RTC_WAKEUP,at,p);
  } catch(SecurityException ex){a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,p);}
 }
 public static void cancel(Context c,String id){Intent i=new Intent(c,ReminderReceiver.class); PendingIntent p=PendingIntent.getBroadcast(c,code(id),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE); if(p!=null)((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(p);}
 public static void cancelAll(Context c){
  try { JSONArray a=new JSONArray(c.getSharedPreferences("data",0).getString("reminders","[]"));
   for(int i=0;i<a.length();i++)cancel(c,a.getJSONObject(i).optString("id",""));
   c.getSharedPreferences("data",0).edit().putString("reminders","[]").apply();
  } catch(Exception ignored) {}
 }
 public static void scheduleDaily(Context c,int h,int m,String title,String prefix){ Calendar x=Calendar.getInstance();x.set(Calendar.HOUR_OF_DAY,h);x.set(Calendar.MINUTE,m);x.set(Calendar.SECOND,0);x.set(Calendar.MILLISECOND,0);if(x.getTimeInMillis()<=System.currentTimeMillis())x.add(Calendar.DATE,1); String id="daily_"+h; Intent i=new Intent(c,ReminderReceiver.class);i.putExtra("id",id);i.putExtra("title",title);i.putExtra("body",prefix);i.putExtra("type","both");i.putExtra("daily",true);i.putExtra("hour",h);i.putExtra("minute",m); PendingIntent p=PendingIntent.getBroadcast(c,code(id),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);try { a.setInexactRepeating(AlarmManager.RTC_WAKEUP,x.getTimeInMillis(),AlarmManager.INTERVAL_DAY,p); }
  catch(SecurityException ignored) { a.set(AlarmManager.RTC_WAKEUP,x.getTimeInMillis(),p); }}
}
