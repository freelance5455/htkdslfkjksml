package com.hasanjassim.followup;
import android.content.*;import org.json.*;
public class BootReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
  try {
   String s=c.getSharedPreferences("data",0).getString("reminders","[]"); JSONArray a=new JSONArray(s);
   for(int j=0;j<a.length();j++){JSONObject r=a.getJSONObject(j);if(r.optLong("at",0)>System.currentTimeMillis())ReminderScheduler.schedule(c,r);}
   ReminderScheduler.scheduleDaily(c,9,0,"ملخص مواعيد اليوم","موعد اليوم");
   ReminderScheduler.scheduleDaily(c,19,0,"ملخص مواعيد الغد","مواعيد الغد");
  }catch(Exception ignored){}
 }
}
