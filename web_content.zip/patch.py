from pathlib import Path
import re
p=Path('/tmp/flowtask/app/src/main/assets/web/index.html')
s=p.read_text()
# Dashboard: remove requested labels/cards and split enrolled vs active students.
pattern=r"teacherHome = function\(\)\{.*?\n\};"
replacement="""teacherHome = function(){
  const totalStudents=S.students.length;
  const activeStudents=S.students.filter(st=>(st.status||'Ativo')==='Ativo'&&!st.accessBlocked&&!st.blocked).length;
  const individualCount=S.students.filter(st=>st.modality==='Individual').length;
  const due=S.invoices.filter(x=>x.status!=='Pago').reduce((a,x)=>a+Number(x.amount||0),0);
  return `<div class=\"hero\"><h1>Visão geral</h1><p>Controle suas turmas, conteúdos, alunos e financeiro.</p></div><div class=\"grid3\"><div class=\"card stat\"><div class=\"label\">TOTAL DE ALUNOS MATRICULADOS</div><div class=\"value\">${totalStudents}</div></div><div class=\"card stat\"><div class=\"label\">ALUNOS ATIVOS</div><div class=\"value\">${activeStudents}</div></div><div class=\"card stat\"><div class=\"label\">TURMAS</div><div class=\"value\">${S.classes.length}</div></div><div class=\"card stat\"><div class=\"label\">ALUNOS NA MODALIDADE INDIVIDUAL</div><div class=\"value\">${individualCount}</div><span class=\"muted\">matrículas individuais</span></div><div class=\"card stat\"><div class=\"label\">A RECEBER</div><div class=\"value\">${money(due)}</div><span class=\"muted\">pendente/atrasado</span></div></div><div class=\"section grid\"><div class=\"card\"><h2>Ações rápidas</h2><div class=\"chips\"><button class=\"btn\" onclick=\"modal('addStudent')\">+ Adicionar aluno</button><button class=\"btn\" onclick=\"modal('class')\">+ Nova turma</button><button class=\"btn alt\" onclick=\"modal('lesson')\">+ Nova aula</button><button class=\"btn alt\" onclick=\"modal('material')\">+ Material</button><button class=\"btn alt\" onclick=\"modal('exercise')\">+ Exercício</button><button class=\"btn alt\" onclick=\"modal('live')\">+ Aula ao vivo</button><button class=\"btn purple\" onclick=\"modal('invoice')\">Pix / cobrança</button></div></div><div class=\"card\"><h2>Últimos lançamentos</h2>${S.invoices.slice(-3).reverse().map(i=>`<div class=\"item\"><b>${esc(i.student)}</b><br><span class=\"muted\">${money(i.amount)} · ${esc(i.status)}</span></div>`).join('')||'<div class=\"empty\">Nenhuma cobrança.</div>'}</div></div><div class=\"card section\"><div class=\"row\"><div><h2>Entregas dos alunos</h2><p class=\"muted\">Speaking, Listening e demais atividades enviadas.</p></div><button class=\"btn alt\" onclick=\"go('entregas')\">Ver entregas</button></div>${S.submissions.length?S.submissions.slice(-3).reverse().map(s=>`<div class=\"item row\"><span><b>${esc(s.studentName)}</b> · ${esc(s.exerciseTitle)}<br><small class=\"muted\">${esc(s.type)} · ${new Date(s.createdAt).toLocaleString('pt-BR')}</small></span><span class=\"badge\">Recebida</span></div>`).join(''):'<div class=\"empty\">Nenhuma entrega recebida ainda.</div>'}</div>`;
};"""
s2,n=re.subn(pattern,replacement,s,count=1,flags=re.S)
if n!=1: raise SystemExit(f'teacherHome replace count {n}')
s=s2
# Keep monthly launch reliable for one student or every student in a selected class.
old="createInvoice=function(){const amount=Number(document.getElementById('am')?.value),due=document.getElementById('dt')?.value,selected=document.getElementById('st')?.value;if(!(amount>0)){alert('Informe um valor válido.');return}const classId=document.getElementById('invoiceClass')?.value;let targets=classId?S.students.filter(st=>st.classId===classId):S.students.filter(st=>st.id===selected);if(!targets.length){alert('Não há alunos cadastrados para esta seleção.');return}targets.forEach(st=>S.invoices.push({id:uid(),student:st.name,studentEmail:st.email,studentId:st.id,classId:st.classId,amount,due,status:'Pendente',pix:'00020126580014BR.GOV.BCB.PIX0136flowspace-'+uid()}));save();close();render();alert(`Mensalidade lançada para ${targets.length} aluno(s).`)};"
new="""createInvoice=function(){
  const amount=Number(document.getElementById('am')?.value),due=document.getElementById('dt')?.value,selected=document.getElementById('st')?.value||'',classId=document.getElementById('invoiceClass')?.value||'';
  if(!(amount>0)){alert('Informe um valor válido.');return;}
  let targets=classId?S.students.filter(st=>String(st.classId)===String(classId)&&st.modality!=='Individual'):S.students.filter(st=>String(st.id)===String(selected));
  if(!targets.length){alert('Não há alunos cadastrados para esta seleção.');return;}
  targets.forEach(st=>S.invoices.push({id:uid(),student:st.name,studentEmail:st.email,studentId:st.id,classId:st.classId||null,amount,due:due||'',status:'Pendente',pix:'00020126580014BR.GOV.BCB.PIX0136flowspace-'+uid()}));
  save();close();render();alert(`Mensalidade lançada para ${targets.length} aluno(s).`);
};"""
if old not in s: raise SystemExit('createInvoice original not found')
s=s.replace(old,new,1)
# Ensure all existing delete action types are handled, including complementary material and linked data.
# Replace the final effective handler, keeping its existing confirmations and related-data cleanup.
start=s.rfind('deleteData = function(type,id){')
if start<0: raise SystemExit('final deleteData not found')
end=s.find('\n};',start)
if end<0: raise SystemExit('final deleteData terminator not found')
end+=3
newdel="""deleteData = function(type,id){
  const map={class:'classes',student:'students',lesson:'lessons',live:'live',material:'materials',exercise:'exercises',invoice:'invoices',research:'researchMaterials'};
  const key=map[type],arr=key?S[key]:null;
  if(!Array.isArray(arr)){alert('Não foi possível localizar este item para exclusão.');return;}
  const idx=arr.findIndex(x=>String(x.id)===String(id));
  if(idx<0){alert('Este item não foi encontrado ou já foi excluído.');return;}
  const removed=arr[idx];
  if(type==='student'){
    if(!confirm(`Excluir definitivamente ${removed.name}? Os dados do aluno, acesso de login e cobranças vinculadas serão removidos deste dispositivo.`))return;
    S.students.splice(idx,1);
    S.users=(S.users||[]).filter(u=>String(u.id)!==String(removed.id)&&String(u.email||'').toLowerCase()!==String(removed.email||'').toLowerCase());
    S.invoices=(S.invoices||[]).filter(i=>String(i.studentId||'')!==String(removed.id)&&String(i.studentEmail||'').toLowerCase()!==String(removed.email||'').toLowerCase());
    S.submissions=(S.submissions||[]).filter(x=>String(x.studentId||'')!==String(removed.id)&&String(x.studentEmail||'').toLowerCase()!==String(removed.email||'').toLowerCase());
    save();close();render();return;
  }
  if(!confirm(`Deseja realmente excluir ${type==='class'?'esta turma':type==='invoice'?'esta mensalidade':type==='research'?'este material complementar':type==='lesson'?'esta aula gravada':type==='live'?'esta aula ao vivo':type==='material'?'este material':type==='exercise'?'este exercício':'este item'}?`))return;
  arr.splice(idx,1);
  if(type==='class'){
    S.events=(S.events||[]).filter(e=>String(e.classId)!==String(id));
    S.students.forEach(st=>{if(String(st.classId)===String(id)){st.classId=null;if(st.modality!=='Individual'){st.modality='Individual';st.accessCode=st.accessCode||('IND-'+Math.random().toString(36).slice(2,6).toUpperCase());}}});
    (S.users||[]).forEach(u=>{if(String(u.classId)===String(id)){u.classId=null;u.classCode='';}});
  }
  if(type==='exercise'){
    S.submissions=(S.submissions||[]).filter(x=>String(x.exerciseId)!==String(id));
    if(S.progress?.exerciseStatus)delete S.progress.exerciseStatus[id];
  }
  save();close();render();
};"""
s=s[:start]+newdel+s[end:]
p.write_text(s)
print('patched',p,'bytes',len(s))
