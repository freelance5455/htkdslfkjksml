const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
const N=18,C=20;let snake,food,dir,next,score,timer,running=false;
const scoreEl=document.getElementById('score'),bestEl=document.getElementById('best'),overlay=document.getElementById('overlay');
let best=Number(localStorage.getItem('viborita-best')||0);bestEl.textContent=best;
function reset(){snake=[{x:8,y:9},{x:7,y:9},{x:6,y:9}];dir={x:1,y:0};next={...dir};score=0;scoreEl.textContent=0;placeFood();draw()}
function placeFood(){do{food={x:Math.floor(Math.random()*N),y:Math.floor(Math.random()*N)}}while(snake.some(p=>p.x===food.x&&p.y===food.y))}
function draw(){ctx.fillStyle='#172e23';ctx.fillRect(0,0,360,360);ctx.strokeStyle='#254333';ctx.lineWidth=1;for(let i=0;i<=N;i++){ctx.beginPath();ctx.moveTo(i*C,0);ctx.lineTo(i*C,360);ctx.stroke();ctx.beginPath();ctx.moveTo(0,i*C);ctx.lineTo(360,i*C);ctx.stroke()}
ctx.font='18px sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('🍎',food.x*C+C/2,food.y*C+C/2);
snake.forEach((p,i)=>{ctx.fillStyle=i===0?'#c6ef78':'#70c66b';ctx.beginPath();ctx.roundRect(p.x*C+1,p.y*C+1,C-2,C-2,6);ctx.fill();if(i===0){ctx.fillStyle='#17301e';ctx.fillRect(p.x*C+5,p.y*C+6,3,3);ctx.fillRect(p.x*C+12,p.y*C+6,3,3)}})}
function end(){running=false;clearInterval(timer);overlay.style.display='flex';overlay.querySelector('h1').textContent='¡Fin del juego!';overlay.querySelector('p').textContent='Hiciste '+score+' puntos. ¡Inténtalo otra vez!';document.getElementById('start').textContent='VOLVER A JUGAR'}
function tick(){dir=next;const head={x:snake[0].x+dir.x,y:snake[0].y+dir.y};if(head.x<0||head.x>=N||head.y<0||head.y>=N||snake.some((p,i)=>i>0&&p.x===head.x&&p.y===head.y)){end();return}snake.unshift(head);if(head.x===food.x&&head.y===food.y){score+=10;scoreEl.textContent=score;if(score>best){best=score;bestEl.textContent=best;localStorage.setItem('viborita-best',best)}placeFood()}else snake.pop();draw()}
function start(){clearInterval(timer);reset();overlay.style.display='none';running=true;timer=setInterval(tick,145)}
function change(d){if(!running)return;const map={up:{x:0,y:-1},down:{x:0,y:1},left:{x:-1,y:0},right:{x:1,y:0}};const v=map[d];if(v&&!(v.x===-dir.x&&v.y===-dir.y))next=v}
document.getElementById('start').addEventListener('click',start);document.getElementById('again').addEventListener('click',start);
document.querySelectorAll('[data-dir]').forEach(b=>b.addEventListener('click',()=>change(b.dataset.dir)));
document.addEventListener('keydown',e=>{const m={ArrowUp:'up',w:'up',ArrowDown:'down',s:'down',ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right'};if(m[e.key]){e.preventDefault();change(m[e.key])}});
let touch=null;canvas.addEventListener('touchstart',e=>{touch={x:e.touches[0].clientX,y:e.touches[0].clientY}},{passive:true});canvas.addEventListener('touchend',e=>{if(!touch)return;const dx=e.changedTouches[0].clientX-touch.x,dy=e.changedTouches[0].clientY-touch.y;if(Math.max(Math.abs(dx),Math.abs(dy))>18)change(Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up'));touch=null},{passive:true});
reset();
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./sw.js').catch(()=>{});
