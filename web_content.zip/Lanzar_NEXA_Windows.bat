@echo off
title NEXA Safety - Red de Seguridad Estudiantil
echo Iniciando NEXA Safety en ventana independiente de escritorio...
start msedge --app="%~dp0index.html" || start chrome --app="%~dp0index.html" || start "%~dp0index.html"
exit
