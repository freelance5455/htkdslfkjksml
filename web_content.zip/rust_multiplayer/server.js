const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');

const PORT = process.env.PORT || 8080;
const MAX_PLAYERS = 5;
const players = new Map();
let nextId = 1;

const server = http.createServer((req, res) => {
  let file = req.url === '/' ? '/index.html' : req.url;
  file = path.join(__dirname, file);
  if (!file.startsWith(__dirname)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    const ext = path.extname(file);
    const type = ext === '.html' ? 'text/html; charset=utf-8' : 'text/plain';
    res.writeHead(200, {'Content-Type': type}); res.end(data);
  });
});

const wss = new WebSocket.Server({ server });
function broadcast(obj, except) {
  const msg = JSON.stringify(obj);
  for (const p of players.values()) {
    if (p.ws !== except && p.ws.readyState === WebSocket.OPEN) p.ws.send(msg);
  }
}

wss.on('connection', ws => {
  if (players.size >= MAX_PLAYERS) {
    ws.send(JSON.stringify({type:'full'}));
    return ws.close();
  }
  const id = String(nextId++);
  const player = { id, ws, name: 'Гравець ' + id, x:0, z:5, ry:0 };
  players.set(id, player);
  const list = [...players.values()].map(({id,name,x,z,ry}) => ({id,name,x,z,ry}));
  ws.send(JSON.stringify({type:'welcome', id, players:list, max:MAX_PLAYERS}));
  broadcast({type:'join', player:{id,name:player.name,x:0,z:5,ry:0}}, ws);

  ws.on('message', raw => {
    let m; try { m=JSON.parse(raw); } catch { return; }
    if (m.type === 'update') {
      player.x = Number(m.x)||0; player.z=Number(m.z)||0; player.ry=Number(m.ry)||0;
      if (typeof m.name === 'string') player.name=m.name.slice(0,16) || player.name;
      broadcast({type:'update', player:{id:player.id,name:player.name,x:player.x,z:player.z,ry:player.ry}}, ws);
    }
  });
  ws.on('close', () => { players.delete(id); broadcast({type:'leave', id}); });
});

server.listen(PORT, () => console.log(`Rust multiplayer server: http://localhost:${PORT}`));
