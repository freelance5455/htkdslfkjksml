MATTAI CALCULATION — Mattai only

This version contains ONLY:
1. Mattai calculation: measurements/area, quantity, buying cost, sales rate, diesel, editable person expenses, net profit/loss.
2. Separate daily Balance Sheet: opening cash/bank, cash/bank sales receipts, other income, Mattai purchase payments, other expenses, cash-to-bank deposit, bank-to-cash withdrawal, closing cash, closing bank and total closing balance.

Both sections have independent date, save history and PDF output. Data is saved in the browser on this device.
Android PDF: tap Save PDF, then choose Save as PDF in the print dialog.
Install: host these files on HTTPS, open in Chrome, menu > Install app / Add to Home screen.
This is an installable PWA, not a native APK.
Balance Sheet is a cash/bank book-style daily balance summary, not a statutory accounting balance sheet.


Update: Balance Sheet includes two-partner 50/50 profit sharing. Enter profit manually or use 'Mattai Calculation-லிருந்து லாபம் எடு'.

Update: Each partner has separate Cash In and Cash Out entries. These are included in business cash closing balance. Net partner cash = Cash In - Cash Out. 50/50 profit sharing remains separate.
