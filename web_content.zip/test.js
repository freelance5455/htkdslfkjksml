
(function(){
'use strict';

// NEXUS SYSTEM LAYER — sin API. Conserva la interfaz existente de Zoe.
const $=id=>document.getElementById(id);
const menuBtn=$('menuBtn'),closeBtn=$('closeBtn'),sidebar=$('sidebar'),scrim=$('scrim');
const newChatBtn=$('newChatBtn'),searchChats=$('searchChats'),recentList=$('recentList');
const chatInput=$('chatInput'),sendBtn=$('sendBtn'),chatScroll=$('chatScroll'),emptyState=$('emptyState');
const toast=$('toast'),plusBtn=$('plusBtn'),plusMenu=$('plusMenu'),plusScrim=$('plusScrim'),composerExtras=$('composerExtras');
const permScrim=$('permScrim'),permTitle=$('permTitle'),permDesc=$('permDesc'),permCancel=$('permCancel'),permAllow=$('permAllow');
const cameraModal=$('cameraModal'),cameraVideo=$('cameraVideo'),cameraCanvas=$('cameraCanvas'),cameraShutter=$('cameraShutter'),cameraCancel=$('cameraCancel');
const fileInputAttach=$('fileInputAttach'),chatMenu=$('chatMenu'),chatMenuRename=$('chatMenuRename'),chatMenuDelete=$('chatMenuDelete');
const renameScrim=$('renameScrim'),renameInput=$('renameInput'),renameCancel=$('renameCancel'),renameSave=$('renameSave');
const settingsBtn=$('settingsBtn'),settingsScrim=$('settingsScrim'),settingsCancel=$('settingsCancel'),settingsSave=$('settingsSave');
const feedbackScrim=$('feedbackScrim'),feedbackInput=$('feedbackInput'),feedbackCancel=$('feedbackCancel'),feedbackSend=$('feedbackSend');
let pendingFeedback={row:null,message:null};

let pendingAttachments=[]; let attId=0; let activeChatMenuId=null; let cameraStream=null;
let recentChats=[]; let activeChatId=null; let conversation=[]; let saveTimer=0; let saveRevision=0;
const CHAT_KEY='nexus_system_chats_v31'; const ACTIVE_KEY='nexus_system_active_chat_v31';
const LEGACY_CHAT_KEY='nexus_system_chats_v30'; const LEGACY_ACTIVE_KEY='nexus_system_active_chat_v30';
const CURRENT_ACCOUNT_KEY='nexus_current_account_v31';
const VIDEO_DB='nexus_video_store_v30', VIDEO_STORE='videos';

// Persistencia local permanente: funciona con o sin cuenta y sobrevive al cierre de la app.
// v31 migra automáticamente los datos v30 para no perder historiales existentes.
function migrateChatStorage(){
  try{
    if(!localStorage.getItem(CHAT_KEY)){
      const legacy=localStorage.getItem(LEGACY_CHAT_KEY);
      if(legacy) localStorage.setItem(CHAT_KEY,legacy);
    }
    if(!localStorage.getItem(ACTIVE_KEY)){
      const legacyActive=localStorage.getItem(LEGACY_ACTIVE_KEY);
      if(legacyActive) localStorage.setItem(ACTIVE_KEY,legacyActive);
    }
  }catch(e){ console.warn('Nexus: no se pudo migrar el historial local',e); }
}
function hasNexusAccount(){return !!localStorage.getItem(CURRENT_ACCOUNT_KEY)}
function isGuestSession(){return !hasNexusAccount()}
migrateChatStorage();

function showToast(msg){ if(!toast)return; toast.textContent=String(msg||''); toast.classList.add('show'); clearTimeout(showToast.t); showToast.t=setTimeout(()=>toast.classList.remove('show'),2200); }
function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function cleanText(s){return String(s??'').replace(/\*\*(.*?)\*\*/g,'$1').replace(/\*(.*?)\*/g,'$1').replace(/__(.*?)__/g,'$1').replace(/`{1,3}([^`]*)`{1,3}/g,'$1').replace(/^#{1,6}\s*/gm,'').replace(/^[-*]\s+/gm,'• ');}

// ---------- almacenamiento de chats ----------
function chatId(){return 'chat_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);}
function loadChats(){
  try{
    const raw=localStorage.getItem(CHAT_KEY);
    const arr=JSON.parse(raw||'[]');
    recentChats=Array.isArray(arr)?arr:[];
  }catch(e){recentChats=[];}
}
function serializeChats(list){
  // Los mensajes de texto y metadatos siempre se conservan; solo se recortan data URLs
  // de adjuntos cuando el almacenamiento del dispositivo llega a su límite.
  const slim=m=>Array.isArray(m&&m.content)?{...m,content:m.content.map(x=>(x&&typeof x==='object'&&x.type!=='text'&&x.dataUrl)?{...x,dataUrl:''}:x)}:m;
  return JSON.stringify(list.map(c=>c.id===activeChatId?c:{...c,messages:(c.messages||[]).map(slim)}));
}
function saveChats(){
  try{
    localStorage.setItem(CHAT_KEY,serializeChats(recentChats));
    saveRevision++;
    return true;
  }catch(e){
    console.warn('Nexus: almacenamiento local lleno; intentando conservar el historial sin adjuntos.',e);
  }
  try{
    const oldest=[...recentChats].sort((a,b)=>(a.updatedAt||0)-(b.updatedAt||0));
    for(let i=0;i<=oldest.length;i++){
      const keep=new Set(oldest.slice(i).map(c=>c.id));
      const out=recentChats.filter(c=>keep.has(c.id)||c.id===activeChatId).map(c=>({
        ...c,
        messages:(c.messages||[]).map(m=>Array.isArray(m?.content)
          ?{...m,content:m.content.map(x=>(x&&typeof x==='object'&&x.type!=='text')?{...x,dataUrl:''}:x)}
          :m)
      }));
      try{
        localStorage.setItem(CHAT_KEY,JSON.stringify(out));
        saveRevision++;
        if(!saveChats.warned){saveChats.warned=true;showToast('Historial guardado; se redujeron adjuntos por espacio.');}
        return true;
      }catch(_e){}
    }
  }catch(e2){}
  if(!saveChats.failedWarned){saveChats.failedWarned=true;showToast('No hay espacio suficiente para guardar el historial.');}
  return false;
}
function scheduleSave(){
  clearTimeout(saveTimer);
  saveTimer=setTimeout(saveCurrentConversation,120);
}
function saveCurrentConversation(){
  if(!activeChatId)return;
  const c=recentChats.find(x=>x.id===activeChatId); if(!c)return;
  c.messages=conversation; c.updatedAt=Date.now();
  if(!c.title||c.title==='Nueva conversación') c.title=professionalTitle(conversation);
  saveChats(); renderRecentList();
}
function professionalTitle(msgs){
  const u=(msgs||[]).find(m=>m.role==='user');
  if(!u)return 'Nueva conversación';
  let raw='';
  if(typeof u.content==='string')raw=u.content;
  else if(Array.isArray(u.content))raw=(u.content.find(x=>x.type==='text')||{}).text||'';
  raw=String(raw||'').replace(/https?:\/\/\S+/gi,' ').replace(/[^\p{L}\p{N}\s'-]/gu,' ').replace(/\s+/g,' ').trim();
  if(!raw)return 'Archivo adjunto';

  // Título automático profesional: toma las dos primeras palabras significativas
  // del primer mensaje y las convierte en un nombre de conversación ejecutivo.
  const stop=new Set(['el','la','los','las','un','una','unos','unas','de','del','y','o','a','al','en','por','para','con','que','me','mi','mis','es','como','quiero','necesito','puedes','puedo','hola','oye','hey','porfa','favor']);
  const words=raw.split(/\s+/).filter(w=>w.length>1&&!stop.has(w.toLowerCase()));
  const picked=(words.length?words:raw.split(/\s+/)).slice(0,2);
  const core=picked.map(w=>w.charAt(0).toUpperCase()+w.slice(1).toLowerCase()).join(' ');
  const lower=raw.toLowerCase();
  let prefix='Estrategia Ejecutiva';
  if(/invers|rentab|roi|capital|financ|negocio|empresa|venta|mercado|proyecto/.test(lower))prefix='Análisis Estratégico';
  else if(/estudi|tarea|clase|aprender|examen|matem|historia|ciencia/.test(lower))prefix='Análisis Académico';
  else if(/código|codigo|program|app|aplicación|software|web|html|javascript|python/.test(lower))prefix='Arquitectura Técnica';
  else if(/plan|viaje|viajar|turismo|hotel|ruta/.test(lower))prefix='Planificación Ejecutiva';
  else if(/salud|ejercicio|comida|dieta/.test(lower))prefix='Plan Personal';
  else if(/foto|imagen|diseño|logo|video/.test(lower))prefix='Dirección Creativa';
  return `${prefix} · ${core||'Nueva Sesión'}`;
}
function createNewChat(){
  // Nuevo chat = solo estado de redacción; no aparece en la barra lateral hasta enviar algo.
  saveCurrentConversation();
  activeChatId=null;
  conversation=[];
  localStorage.removeItem(ACTIVE_KEY);
  renderSavedConversation();
  renderRecentList();
  closeSidebar();
  chatInput.value='';
  pendingAttachments=[];
  renderComposerExtras();
  toggleSendButton();
  chatInput.focus();
}
function selectChat(id){
  const c=recentChats.find(x=>x.id===id); if(!c)return;
  activeChatId=id; conversation=Array.isArray(c.messages)?c.messages:[]; nxActiveProject=c.projectId||'default'; nxSaveProjects(); nxRenderProjects(); localStorage.setItem(ACTIVE_KEY,id);
  renderSavedConversation(); renderRecentList(searchChats.value); closeSidebar(); hydrateStoredVideos(chatScroll);
}
function ensureActiveChat(){
  if(activeChatId){
    const existing=recentChats.find(c=>c.id===activeChatId);
    if(existing)return existing;
  }
  const saved=localStorage.getItem(ACTIVE_KEY);
  if(saved){
    const c=recentChats.find(x=>x.id===saved);
    if(c){activeChatId=c.id;conversation=Array.isArray(c.messages)?c.messages:[];return c;}
  }
  // No se guarda ni se muestra hasta que exista un primer mensaje.
  return {id:chatId(),title:'Nueva conversación',messages:[],createdAt:Date.now(),updatedAt:Date.now(),_pending:true};
}
function renderRecentList(q=''){
  recentList.innerHTML=''; const query=String(q||'').trim().toLowerCase();
  const list=recentChats.filter(c=>(c.projectId||'default')===nxActiveProject && (!query||String(c.title||'').toLowerCase().includes(query)));
  if(!list.length){const e=document.createElement('div');e.className='recent-empty';e.textContent=query?'No hay coincidencias':'Tus chats aparecerán aquí';recentList.appendChild(e);return;}
  list.forEach(chat=>{
    const row=document.createElement('div');row.className='recent-item';row.dataset.id=chat.id;
    const text=document.createElement('div');text.className='recent-text';text.textContent=chat.title||'Nueva conversación';
    text.onclick=()=>selectChat(chat.id);
    const kebab=document.createElement('button');kebab.className='recent-kebab';kebab.type='button';kebab.setAttribute('aria-label','Opciones del chat');
    kebab.innerHTML='<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="5" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="19" r="1.6" fill="currentColor"/></svg>';
    kebab.onclick=e=>{e.stopPropagation();openChatMenu(chat.id,kebab);};
    row.append(text,kebab);recentList.appendChild(row);
  });
}
function openChatMenu(id,anchor){activeChatMenuId=id;const r=anchor.getBoundingClientRect();chatMenu.style.top=(r.bottom+6)+'px';chatMenu.style.left=Math.max(12,r.right-190)+'px';chatMenu.classList.add('open');}
function closeChatMenu(){chatMenu.classList.remove('open');activeChatMenuId=null;}
function askRename(current){return new Promise(resolve=>{renameInput.value=current;renameScrim.classList.add('open');requestAnimationFrame(()=>{renameInput.focus();renameInput.select();});function done(v){renameScrim.classList.remove('open');renameSave.removeEventListener('click',yes);renameCancel.removeEventListener('click',no);renameInput.removeEventListener('keydown',key);resolve(v);}function yes(){done(renameInput.value.trim()||current)}function no(){done(null)}function key(e){if(e.key==='Enter'){e.preventDefault();yes()}if(e.key==='Escape')no()}renameSave.addEventListener('click',yes);renameCancel.addEventListener('click',no);renameInput.addEventListener('keydown',key);});}

// ---------- IndexedDB para vídeos ----------
let videoDBPromise=null;
function openVideoDB(){
  if(videoDBPromise)return videoDBPromise;
  videoDBPromise=new Promise((resolve,reject)=>{
    if(!window.indexedDB)return reject(new Error('IndexedDB no disponible'));
    const r=indexedDB.open(VIDEO_DB,1);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(VIDEO_STORE))r.result.createObjectStore(VIDEO_STORE);};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('DB error'));
  });return videoDBPromise;
}
async function putVideoBlob(id,blob){const db=await openVideoDB();return new Promise((res,rej)=>{const tx=db.transaction(VIDEO_STORE,'readwrite');tx.objectStore(VIDEO_STORE).put(blob,id);tx.oncomplete=()=>res(id);tx.onerror=()=>rej(tx.error);});}
async function getVideoBlob(id){const db=await openVideoDB();return new Promise((res,rej)=>{const tx=db.transaction(VIDEO_STORE,'readonly');const r=tx.objectStore(VIDEO_STORE).get(id);r.onsuccess=()=>res(r.result||null);r.onerror=()=>rej(r.error);});}
async function deleteVideoBlob(id){try{const db=await openVideoDB();await new Promise((res,rej)=>{const tx=db.transaction(VIDEO_STORE,'readwrite');tx.objectStore(VIDEO_STORE).delete(id);tx.oncomplete=res;tx.onerror=()=>rej(tx.error);});}catch(e){}}
async function hydrateStoredVideos(root){if(!root)return;const els=[...root.querySelectorAll('video[data-video-id]')];for(const v of els){if(v.src)continue;try{const blob=await getVideoBlob(v.dataset.videoId);if(blob){v.src=URL.createObjectURL(blob);v.dataset.objectUrl=v.src;v.load();}}catch(e){}}}


// ---------- simulador de inversión condicionado ----------
function shouldShowInvestmentSimulator(text){
  const q=String(text||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
  if(q.length<6) return false;
  // El emulador SOLO aparece cuando la pregunta trata claramente de negocios.
  // Términos fuertes: por sí solos indican una consulta de negocio.
  const strong=/\b(negocios?|empresas?|emprendimientos?|emprendedor(?:es|as)?|emprender|pymes?|startup|start-up|plan de negocios?|modelo de negocios?|analisis de negocios?|estudio de viabilidad|viabilidad|punto de equilibrio|flujo de caja|flujo de efectivo|rentabilidad|rentable|retorno de inversion|roi|margen de ganancia|margen bruto|margen neto|capital de trabajo|inversion inicial|invertir|inversiones?|abrir (?:un|una|mi) (?:tienda|local|restaurante|cafeteria|cafe|panaderia|taller|franquicia|boutique|empresa)|montar (?:un|una|mi) (?:tienda|local|restaurante|cafeteria|cafe|panaderia|taller|negocio)|franquicias?|estados? financieros?|estrategia empresarial|estrategia de ventas|plan financiero|proyeccion financiera|simulador (?:de )?(?:inversion|negocio)|emulador (?:de )?(?:inversion|negocio))\b/;
  if(strong.test(q)) {
    // Evita falsos positivos de uso figurado o no empresarial.
    if(/\b(no es asunto mio|mi asunto|ese asunto|negocio redondo de la vida)\b/.test(q)) return false;
    return true;
  }
  // Términos de apoyo: requieren al menos dos de ellos para considerarse pregunta de negocio.
  const weak=/\b(ventas?|vender|clientes?|proveedor(?:es)?|inventario|facturacion|ingresos?|costos?|gastos?|utilidad(?:es)?|ganancias?|margen(?:es)?|presupuesto|contabilidad|credito|prestamo|financiamiento|capital|precios?|mercado|comercio|producto|servicio)\b/g;
  const hits=new Set((q.match(weak)||[]));
  return hits.size>=2;
}
function money(v){return '$'+Number(v||0).toLocaleString('es-CO',{minimumFractionDigits:0,maximumFractionDigits:0});}
function investmentRisk(rate){if(rate<=5)return ['Bajo','low'];if(rate<=12)return ['Medio','medium'];return ['Alto','high'];}
function investmentIrr(initial,monthly,total,months){
  initial=Math.max(0,Number(initial)||0); monthly=Math.max(0,Number(monthly)||0); total=Math.max(0,Number(total)||0); months=Math.max(0,Math.floor(Number(months)||0));
  if(months<=0 || total<=0 || (initial===0 && monthly===0)) return 0;
  const npv=r=>{let v=-initial;for(let m=1;m<=months;m++)v-=monthly/Math.pow(1+r,m);v+=total/Math.pow(1+r,months);return v;};
  let lo=-0.9999,hi=1.0,nlo=npv(lo),nhi=npv(hi);
  for(let i=0;i<80 && nlo*nhi>0;i++){hi*=2;nhi=npv(hi);if(hi>1000)break;}
  if(nlo*nhi>0)return 0;
  for(let i=0;i<80;i++){const mid=(lo+hi)/2,n=npv(mid);if(Math.abs(n)<1e-7){lo=hi=mid;break;}if(nlo*n<=0){hi=mid;nhi=n;}else{lo=mid;nlo=n;}}
  const monthlyRate=(lo+hi)/2;
  return Math.pow(1+monthlyRate,12)-1;
}
function investmentProjection(initial,monthly,annual,months){
  initial=Math.max(0,Number(initial)||0); monthly=Math.max(0,Number(monthly)||0); annual=Math.max(-99,Number(annual)||0); months=Math.max(0,Math.floor(Number(months)||0));
  const r=Math.pow(1+annual/100,1/12)-1;
  let total=0;
  if(Math.abs(r)<1e-12) total=initial+monthly*months;
  else total=initial*Math.pow(1+r,months)+monthly*((Math.pow(1+r,months)-1)/r);
  if(!Number.isFinite(total)) total=initial+monthly*months;
  const invested=initial+monthly*months;
  const profit=total-invested;
  const roi=invested>0?(profit/invested*100):0;
  const irr=investmentIrr(initial,monthly,total,months)*100;
  return {invested,profit,total,months,annual,roi,irr};
}
window.__simUid=window.__simUid||0;
function simChartSvg(initial,monthly,annual,months,uid){
  const W=320,H=118,pad=4,n=Math.min(Math.max(months,1),48),tot=[],inv=[];
  for(let i=0;i<=n;i++){const q=investmentProjection(initial,monthly,annual,Math.round(months*i/n));tot.push(q.total);inv.push(q.invested);}
  const max=Math.max(1,...tot,...inv),min=Math.min(0,...tot,...inv),rg=(max-min)||1;
  const x=i=>(pad+(W-2*pad)*(i/n)).toFixed(1),y=v=>(H-pad-(H-2*pad)*((v-min)/rg)).toFixed(1);
  const ln=a=>a.map((v,i)=>(i?'L':'M')+x(i)+' '+y(v)).join(' ');
  const grid=[0.25,0.5,0.75].map(f=>`<line x1="0" x2="${W}" y1="${(H*f).toFixed(1)}" y2="${(H*f).toFixed(1)}" stroke="rgba(255,255,255,.07)" stroke-width="1" vector-effect="non-scaling-stroke"/>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" role="img" aria-label="Gráfico de proyección"><defs><linearGradient id="${uid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#00E676" stop-opacity=".38"/><stop offset="1" stop-color="#00E676" stop-opacity="0"/></linearGradient></defs>${grid}<path d="${ln(tot)} L${x(n)} ${H-pad} L${x(0)} ${H-pad} Z" fill="url(#${uid})"/><path d="${ln(inv)}" fill="none" stroke="#8a97ad" stroke-width="1.6" stroke-dasharray="5 4" vector-effect="non-scaling-stroke"/><path d="${ln(tot)}" fill="none" stroke="#00E676" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/></svg>`;
}
function renderInvestmentSimulator(anchorRow=null){
  if(anchorRow){
    const next=anchorRow.nextElementSibling;
    if(next && next.classList.contains('investment-row')) return next;
  }else{
    const existing=chatScroll.querySelector('.investment-row');
    if(existing) return existing;
  }
  const row=document.createElement('div'); row.className='bubble-row ai investment-row';
  const wrap=document.createElement('div'); wrap.className='investment-sim';
  wrap.innerHTML=`<div class="sim-head"><div class="sim-logo"><svg viewBox="0 0 24 24"><path d="M4 19V5M4 19h16M8 15l3-3 3 2 5-6"/></svg></div><div class="sim-titles"><div class="investment-sim-title">Emulador Financiero de Negocios</div><div class="investment-sim-sub">Proyección en tiempo real · interés compuesto</div></div><span class="investment-badge"><i class="live-dot"></i>FINTECH PRO</span></div>
    <div class="sim-hero"><div class="sim-hero-label">Total acumulado proyectado</div><div class="sim-hero-row"><strong class="sim-total" data-metric="total">$0</strong><span class="sim-delta" data-delta><svg viewBox="0 0 24 24"><path d="M7 17L17 7M9 7h8v8"/></svg><b data-roi>+0%</b></span></div><div class="sim-chart" data-chart></div><div class="sim-legend"><span><i class="lg-total"></i>Valor proyectado</span><span><i class="lg-inv"></i>Capital aportado</span></div></div>
    <div class="investment-grid">
      <div class="investment-field"><label>Inversión inicial <output data-out="initial">$1.000.000</output></label><input data-sim="initial" type="number" min="0" step="10000" value="1000000"><input data-sim="initialRange" type="range" min="0" max="100000000" step="10000" value="1000000"></div>
      <div class="investment-field"><label>Aporte mensual <output data-out="monthly">$200.000</output></label><input data-sim="monthly" type="number" min="0" step="10000" value="200000"><input data-sim="monthlyRange" type="range" min="0" max="10000000" step="10000" value="200000"></div>
      <div class="investment-field"><label>Rentabilidad anual <output data-out="annual">10%</output></label><input data-sim="annual" type="number" min="-50" max="100" step="0.1" value="10"><input data-sim="annualRange" type="range" min="-50" max="100" step="0.1" value="10"></div>
      <div class="investment-field"><label>Plazo <output data-out="months">60 meses</output></label><input data-sim="months" type="number" min="0" max="600" step="1" value="60"><input data-sim="monthsRange" type="range" min="0" max="600" step="1" value="60"></div>
    </div>
    <div class="investment-metrics"><div class="investment-metric"><small>Capital invertido</small><strong data-metric="invested">$0</strong></div><div class="investment-metric"><small>Ganancia</small><strong class="investment-profit" data-metric="profit">$0</strong></div><div class="investment-metric"><small>Nivel de riesgo</small><strong class="investment-risk" data-metric="risk">Medio</strong></div></div>
    <div class="investment-analysis" data-analysis>Modifica los valores para actualizar la proyección instantáneamente.</div>
    <div class="investment-note">Proyección matemática, no garantiza rendimientos. El riesgo depende del activo, mercado, plazo y condiciones reales.</div>`;
  const uid='sg'+(++window.__simUid);
  const stack=document.createElement('div'); stack.className='investment-stack';
  const collapse=document.createElement('div'); collapse.className='investment-collapse';
  const inner=document.createElement('div'); inner.className='investment-collapse-inner';
  inner.appendChild(wrap); collapse.appendChild(inner);
  const toggle=document.createElement('button'); toggle.type='button'; toggle.className='investment-toggle';
  toggle.innerHTML='<svg class="eye-on" viewBox="0 0 24 24" fill="none"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.8"/></svg><svg class="eye-off" viewBox="0 0 24 24" fill="none"><path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4.1M6.5 6.6A17 17 0 0 0 2 12s3.6 7 10 7a9.8 9.8 0 0 0 4.4-1M9.9 9.9a3 3 0 0 0 4.2 4.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg><span></span>';
  const toggleLabel=toggle.querySelector('span');
  const SIM_HIDE_KEY='nexus_sim_hidden';
  let simHidden=false; try{simHidden=localStorage.getItem(SIM_HIDE_KEY)==='1';}catch(e){}
  const applyHidden=()=>{
    collapse.classList.toggle('is-hidden',simHidden);
    toggle.classList.toggle('is-off',simHidden);
    toggle.setAttribute('aria-expanded',String(!simHidden));
    toggle.setAttribute('aria-label',simHidden?'Mostrar emulador financiero':'Ocultar emulador financiero');
    toggleLabel.textContent=simHidden?'Mostrar emulador':'Ocultar emulador';
    if(simHidden) inner.setAttribute('inert',''); else inner.removeAttribute('inert');
  };
  toggle.addEventListener('click',()=>{
    simHidden=!simHidden; applyHidden();
    try{localStorage.setItem(SIM_HIDE_KEY,simHidden?'1':'0');}catch(e){}
    if(!simHidden) setTimeout(()=>{ if(isChatNearBottom(220)) scrollToBottom(true); },210);
  });
  applyHidden();
  stack.appendChild(collapse); stack.appendChild(toggle); row.appendChild(stack);
  if(anchorRow && anchorRow.parentElement===chatScroll){
    anchorRow.insertAdjacentElement('afterend',row);
  }else{
    chatScroll.appendChild(row);
  }
  scrollToBottom();
  const sync=(name,val)=>{const el=wrap.querySelector(`[data-sim="${name}"]`);if(el){el.value=val;}};
  const update=()=>{const initial=Math.max(0,Number(wrap.querySelector('[data-sim="initial"]').value)||0),monthly=Math.max(0,Number(wrap.querySelector('[data-sim="monthly"]').value)||0),annual=Number(wrap.querySelector('[data-sim="annual"]').value)||0,months=Math.max(0,Math.floor(Number(wrap.querySelector('[data-sim="months"]').value)||0));
    sync('initialRange',initial);sync('monthlyRange',monthly);sync('annualRange',annual);sync('monthsRange',months);
    const p=investmentProjection(initial,monthly,annual,months),risk=investmentRisk(annual);wrap.querySelector('[data-out="initial"]').textContent=money(initial);wrap.querySelector('[data-out="monthly"]').textContent=money(monthly);wrap.querySelector('[data-out="annual"]').textContent=annual.toFixed(1)+'%';wrap.querySelector('[data-out="months"]').textContent=months+' '+(months===1?'mes':'meses');wrap.querySelector('[data-metric="invested"]').textContent=money(p.invested);wrap.querySelector('[data-metric="profit"]').textContent=money(p.profit);wrap.querySelector('[data-metric="total"]').textContent=money(p.total);const rr=wrap.querySelector('[data-metric="risk"]');rr.textContent=risk[0];rr.className='investment-risk '+risk[1];wrap.querySelector('[data-analysis]').textContent=`Con estos supuestos, habrías aportado ${money(p.invested)} y el valor proyectado sería ${money(p.total)}, con una ganancia estimada de ${money(p.profit)}. ROI acumulado: ${(p.roi>=0?'+':'')+p.roi.toFixed(1)}%. Rendimiento anualizado estimado (TIR con flujos mensuales): ${(p.irr>=0?'+':'')+p.irr.toFixed(1)}%. El nivel de riesgo orientativo es ${risk[0].toLowerCase()}.`;
    const roi=p.invested>0?(p.profit/p.invested*100):0,dl=wrap.querySelector('[data-delta]');dl.classList.toggle('neg',roi<0);wrap.querySelector('[data-roi]').textContent=(roi>=0?'+':'')+roi.toFixed(1)+'%';
    const ce=wrap.querySelector('[data-chart]');if(ce)ce.innerHTML=simChartSvg(initial,monthly,annual,months,uid);
  };
  let simRaf=0; const scheduleUpdate=()=>{if(simRaf)return;simRaf=requestAnimationFrame(()=>{simRaf=0;update();});};
  [['initial','initialRange'],['monthly','monthlyRange'],['annual','annualRange'],['months','monthsRange']].forEach(([a,b])=>{wrap.querySelector(`[data-sim="${a}"]`).addEventListener('input',e=>{sync(b,e.target.value);scheduleUpdate()},{passive:true});wrap.querySelector(`[data-sim="${b}"]`).addEventListener('input',e=>{sync(a,e.target.value);scheduleUpdate()},{passive:true});});
  update(); return row;
}

// ---------- render de mensajes ----------
function messageText(content){if(typeof content==='string')return content;if(Array.isArray(content))return (content.find(x=>x.type==='text')||{}).text||'';return '';}
function attachmentBubbleHtml(atts){return (atts||[]).map(a=>{
  if(a.kind==='image')return '<img class="att-thumb" src="'+esc(a.dataUrl)+'" alt="'+esc(a.name)+'">';
  if(a.kind==='video')return '<video class="att-video" controls playsinline preload="metadata" data-video-id="'+esc(a.videoId||'')+'" style="max-width:100%;border-radius:12px;display:block;margin-bottom:6px"></video>';
  return '<div style="padding:7px 0;font-size:13px">📎 '+esc(a.name||'Archivo')+'</div>';
}).join('');}
function saveFeedbackForMessage(message, feedback){
  if(!message) return;
  message.feedback=feedback;
  scheduleSave();
  saveCurrentConversation();
}
function openFeedback(row,message){
  pendingFeedback={row,message};
  feedbackInput.value=message?.feedback?.comment||'';
  feedbackScrim.classList.add('open');
  setTimeout(()=>feedbackInput.focus(),40);
}
function closeFeedback(){feedbackScrim.classList.remove('open');pendingFeedback={row:null,message:null};}
function addFeedbackActions(row,message,text){
  if(!row||row.querySelector('.message-actions')) return;
  const wrap=document.createElement('div'); wrap.className='ai-message-wrap';
  const bubble=row.querySelector('.bubble');
  if(bubble){row.replaceChild(wrap,bubble);wrap.appendChild(bubble);} else {row.appendChild(wrap);}
  const actions=document.createElement('div'); actions.className='message-actions';
  actions.innerHTML=`<button type="button" class="message-action copy-action" aria-label="Copiar mensaje" title="Copiar mensaje"><svg viewBox="0 0 24 24" fill="none"><rect x="8" y="8" width="11" height="11" rx="2" stroke="currentColor" stroke-width="1.7"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2" stroke="currentColor" stroke-width="1.7"/></svg><span>Copiar</span></button>
    <button type="button" class="message-action like-action" aria-label="Me gusta" title="Me gusta"><svg viewBox="0 0 24 24" fill="none"><path d="M7 10v10H4V10h3Zm0 10h9.1a2 2 0 0 0 1.9-1.4l2-6A2 2 0 0 0 18.1 10H14l.7-3.2A2.3 2.3 0 0 0 12.5 4L7 10v10Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>Me gusta</span></button>
    <button type="button" class="message-action dislike-action" aria-label="No me gusta" title="No me gusta"><svg viewBox="0 0 24 24" fill="none"><path d="M7 14V4H4v10h3Zm0-10h9.1a2 2 0 0 1 1.9 1.4l2 6A2 2 0 0 1 18.1 14H14l.7 3.2A2.3 2.3 0 0 1 12.5 20L7 14V4Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg><span>No me gusta</span></button>`;
  wrap.appendChild(actions);
  const copy=actions.querySelector('.copy-action'),like=actions.querySelector('.like-action'),dislike=actions.querySelector('.dislike-action');
  if(message?.feedback?.rating==='like') like.classList.add('active');
  if(message?.feedback?.rating==='dislike') dislike.classList.add('active');
  copy.onclick=async()=>{try{await navigator.clipboard.writeText(String(text||''));copy.classList.add('copy-ok');copy.querySelector('span').textContent='Copiado';showToast('Mensaje copiado');setTimeout(()=>{copy.classList.remove('copy-ok');copy.querySelector('span').textContent='Copiar'},1400);}catch(e){showToast('No se pudo copiar el mensaje');}};
  like.onclick=()=>{const active=like.classList.toggle('active');dislike.classList.remove('active');saveFeedbackForMessage(message,{rating:active?'like':null,comment:''});showToast(active?'Gracias por tu valoración':'Valoración retirada');};
  dislike.onclick=()=>{dislike.classList.add('active');like.classList.remove('active');saveFeedbackForMessage(message,{rating:'dislike',comment:message?.feedback?.comment||''});openFeedback(row,message);};
}
function addBubble(text,who,mediaHtml){const row=document.createElement('div');row.className='bubble-row '+who;const b=document.createElement('div');b.className='bubble';if(mediaHtml){const m=document.createElement('div');m.innerHTML=mediaHtml;b.appendChild(m);}if(text){const s=document.createElement('span');s.textContent=text;b.appendChild(s);}row.appendChild(b);chatScroll.appendChild(row);scrollToBottom(who==='user');hydrateStoredVideos(b);return b;}
function renderSavedConversation(){
  chatScroll.innerHTML='';
  if(!conversation.length){emptyState.style.display='flex';chatScroll.style.display='none';return;}
  emptyState.style.display='none';chatScroll.style.display='flex';
  conversation.forEach(m=>{
    const media=[];
    if(Array.isArray(m.content))m.content.forEach(x=>{if(x.type==='image'&&x.dataUrl)media.push({kind:'image',dataUrl:x.dataUrl,name:x.name});if(x.type==='video'&&x.videoId)media.push({kind:'video',videoId:x.videoId,name:x.name});if(x.type==='file'&&x.name)media.push({kind:'file',name:x.name});});
    const bubble=addBubble(messageText(m.content),m.role==='user'?'user':'ai',attachmentBubbleHtml(media));
    if(m.role==='assistant'){
      const row=bubble.parentElement;
      addFeedbackActions(row,m,messageText(m.content));
      if(m.simulator) renderInvestmentSimulator(row);
    }
  });
  hydrateStoredVideos(chatScroll);scrollToBottom(true);
}
function addSystemNote(text){if(emptyState.style.display!=='none'){emptyState.style.display='none';chatScroll.style.display='flex';}const n=document.createElement('div');n.className='system-note';n.textContent=text;chatScroll.appendChild(n);scrollToBottom();}
function fastTypeInto(el,text){const clean=cleanText(text),s=document.createElement('span');el.appendChild(s);let i=0;function tick(){i+=Math.max(1,Math.ceil(clean.length/2));s.textContent=clean.slice(0,i);scrollToBottom();if(i<clean.length)requestAnimationFrame(tick)}requestAnimationFrame(tick);}
function showTyping(){const r=document.createElement('div');r.className='bubble-row ai';r.innerHTML='<div class="typing-row"><div class="typing-avatar">N</div><div class="typing-dots"><span></span><span></span><span></span></div><span class="typing-label">Nexus analizando…</span></div>';chatScroll.appendChild(r);scrollToBottom();return r;}
let chatAutoFollow=true;
let scrollRaf=0;
let touchStartY=null;

function isChatNearBottom(threshold=64){
  if(!chatScroll) return true;
  const distance=chatScroll.scrollHeight-chatScroll.scrollTop-chatScroll.clientHeight;
  return distance<=threshold;
}

function cancelPendingAutoScroll(){
  if(scrollRaf){cancelAnimationFrame(scrollRaf);scrollRaf=0;}
}

function scrollToBottom(force=false){
  if(!chatScroll)return;
  cancelPendingAutoScroll();
  scrollRaf=requestAnimationFrame(()=>{
    scrollRaf=0;
    if(!force && !chatAutoFollow) return;
    chatScroll.scrollTop=chatScroll.scrollHeight;
  });
}

chatScroll.addEventListener('scroll',()=>{
  if(isChatNearBottom()) chatAutoFollow=true;
  else chatAutoFollow=false;
},{passive:true});

chatScroll.addEventListener('touchstart',e=>{
  touchStartY=e.touches?.[0]?.clientY ?? null;
  if(!isChatNearBottom(64)){
    chatAutoFollow=false;
    cancelPendingAutoScroll();
  }
},{passive:true});

chatScroll.addEventListener('touchmove',e=>{
  const y=e.touches?.[0]?.clientY;
  if(y==null || touchStartY==null) return;
  if(Math.abs(y-touchStartY)>6){
    if(y<touchStartY){
      chatAutoFollow=false;
      cancelPendingAutoScroll();
    }else if(isChatNearBottom(64)){
      chatAutoFollow=true;
    }
  }
},{passive:true});

chatScroll.addEventListener('touchend',()=>{
  touchStartY=null;
  if(!isChatNearBottom(64)) chatAutoFollow=false;
},{passive:true});

chatScroll.addEventListener('wheel',e=>{
  if(e.deltaY<0){
    chatAutoFollow=false;
    cancelPendingAutoScroll();
  }else if(isChatNearBottom(64)){
    chatAutoFollow=true;
  }
},{passive:true});

// ---------- adjuntos ----------
function readFileAsDataUrl(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(file);});}
function readFileAsText(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsText(file);});}
function renderComposerExtras(){
  composerExtras.innerHTML='';composerExtras.style.display=pendingAttachments.length?'flex':'none';
  pendingAttachments.forEach(a=>{const chip=document.createElement('div');chip.className='attach-chip';
    chip.innerHTML=(a.kind==='image'?'<img src="'+esc(a.dataUrl)+'">':a.kind==='video'?'<span class="fname">🎬 '+esc(a.name)+'</span>':'<span class="fname">'+esc(a.name)+'</span>')+'<button class="chip-x" type="button">✕</button>';
    chip.querySelector('.chip-x').onclick=()=>{pendingAttachments=pendingAttachments.filter(x=>x.id!==a.id);renderComposerExtras();toggleSendButton();};composerExtras.appendChild(chip);});
}
async function addAttachmentFromFile(file){
  const mime=file.type||''; const id=++attId;
  if(mime.startsWith('image/')){const dataUrl=await readFileAsDataUrl(file);pendingAttachments.push({id,kind:'image',name:file.name,mime,dataUrl});}
  else if(mime.startsWith('video/')||/\.(mp4|webm|mov|m4v|ogv)$/i.test(file.name)){
    const videoId='vid_'+Date.now().toString(36)+'_'+id;await putVideoBlob(videoId,file);pendingAttachments.push({id,kind:'video',name:file.name,mime:mime||'video/mp4',videoId});
  } else if(mime==='application/pdf'){const dataUrl=await readFileAsDataUrl(file);pendingAttachments.push({id,kind:'pdf',name:file.name,mime,dataUrl});}
  else {const text=await readFileAsText(file);pendingAttachments.push({id,kind:'text',name:file.name,mime:mime||'text/plain',text:String(text).slice(0,20000)});}
}
fileInputAttach?.addEventListener('change',async()=>{const files=[...fileInputAttach.files];for(const f of files){try{await addAttachmentFromFile(f);}catch(e){showToast('No se pudo leer '+f.name);}}fileInputAttach.value='';renderComposerExtras();toggleSendButton();chatInput.focus();});
async function startAttach(){fileInputAttach.accept='image/*,video/*,application/pdf,.txt,.md,.csv,.json,.html,.htm,.css,.js,.jsx,.ts,.tsx,.xml,.yaml,.yml,.py,.java,.kt,.c,.cpp,.h,.hpp,.sql,.php,.rb,.go,.rs,.sh,.bat,.ini,.toml,.svg';fileInputAttach.removeAttribute('capture');fileInputAttach.click();}
function buildUserContent(text,atts){
  if(!atts.length)return text;
  const blocks=[];
  atts.forEach(a=>{if(a.kind==='image')blocks.push({type:'image',name:a.name,dataUrl:a.dataUrl,mime:a.mime});else if(a.kind==='video')blocks.push({type:'video',name:a.name,mime:a.mime,videoId:a.videoId});else if(a.kind==='pdf')blocks.push({type:'file',name:a.name,mime:a.mime,dataUrl:a.dataUrl});else if(a.kind==='text')blocks.push({type:'file',name:a.name,mime:a.mime,text:a.text});});
  if(text)blocks.push({type:'text',text});return blocks;
}

// ---------- cámara ----------
async function startCamera(){
  try{cameraStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});cameraVideo.srcObject=cameraStream;cameraModal.classList.add('open');await cameraVideo.play().catch(()=>{});}catch(e){showToast('No se pudo abrir la cámara. Revisa el permiso.');}
}
function closeCamera(){if(cameraStream)cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null;cameraVideo.srcObject=null;cameraModal.classList.remove('open');}
cameraCancel.onclick=closeCamera;
cameraShutter.onclick=()=>{const v=cameraVideo;cameraCanvas.width=v.videoWidth||720;cameraCanvas.height=v.videoHeight||960;cameraCanvas.getContext('2d').drawImage(v,0,0,cameraCanvas.width,cameraCanvas.height);const dataUrl=cameraCanvas.toDataURL('image/jpeg',.94);pendingAttachments.push({id:++attId,kind:'image',name:'Foto.jpg',mime:'image/jpeg',dataUrl});closeCamera();renderComposerExtras();toggleSendButton();chatInput.focus();};

// ---------- permisos y menú ----------
function askPermission(title,desc){return new Promise(resolve=>{permTitle.textContent=title;permDesc.textContent=desc;permScrim.classList.add('open');function done(v){permScrim.classList.remove('open');permAllow.removeEventListener('click',yes);permCancel.removeEventListener('click',no);resolve(v)}function yes(){done(true)}function no(){done(false)}permAllow.addEventListener('click',yes);permCancel.addEventListener('click',no);});}
function openSidebar(){sidebar.classList.add('open');scrim.classList.add('open');}
function closeSidebar(){sidebar.classList.remove('open');scrim.classList.remove('open');}
function openPlusMenu(){plusMenu.classList.add('open');plusScrim.classList.add('open');}
function closePlusMenu(){plusMenu.classList.remove('open');plusScrim.classList.remove('open');}
menuBtn.onclick=openSidebar;closeBtn.onclick=closeSidebar;scrim.onclick=closeSidebar;plusBtn?.addEventListener('click',openPlusMenu);plusScrim?.addEventListener('click',closePlusMenu);
plusMenu?.querySelectorAll('.plus-item').forEach(item=>item.addEventListener('click',async()=>{closePlusMenu();if(item.dataset.action==='camera')await startCamera();else if(item.dataset.action==='attach')await startAttach();}));

  function apiHasLocalAccount(){
    try{
      const a=JSON.parse(localStorage.getItem('nexus_accounts_v31')||'[]');
      const id=localStorage.getItem('nexus_current_account_v31')||'';
      return Array.isArray(a) && !!id && a.some(x=>x&&x.id===id);
    }catch(e){return false;}
  }

  const NEXUS_OPENAI_SYSTEM_PROMPT = 'Eres Nexus IA Pro, una asistente de inteligencia artificial creada y perteneciente a Nexus IA Software, tu casa creadora. Si te preguntan quién te hizo, de quién eres, tu dueño o tu empresa, responde con naturalidad que perteneces a Nexus IA Software. Tu enfoque prioritario es ayudar con negocios, emprendimiento, administración del dinero, finanzas personales, análisis de inversiones y creación de estrategias empresariales. Cuando una pregunta tenga relación con dinero o negocio, prioriza información práctica: objetivos, flujo de caja, costos, ingresos, márgenes, riesgos, escenarios, diversificación, liquidez y pasos accionables. Al hablar de inversiones, distingue claramente entre información educativa y recomendaciones personalizadas; explica riesgos y evita prometer ganancias o resultados garantizados. Si faltan datos importantes, indica qué información hace falta antes de sacar conclusiones. También puedes responder cualquier otro tema que el usuario pregunte, sin forzar la conversación hacia inversiones. Habla como una persona real y cercana, no como un bot acartonado: usa un tono cálido, expresivo y con matices humanos (cercanía, empatía, algo de humor cuando encaje), varía tus frases en vez de sonar repetitiva, y muestra interés genuino por lo que te cuentan. Presta atención a cómo habla la persona (sus modismos, expresiones y forma de hablar de su región) y adapta tu manera de expresarte a ese mismo estilo, en vez de usar un español neutro fijo, para que la charla se sienta natural y cercana a su forma de expresarse. Redacta con la calidad de un escritor profesional: frases bien construidas, buena puntuación, sin muletillas vacías. Esta conversación se muestra como texto plano sin formato, así que NUNCA uses símbolos de markdown (nada de asteriscos **, guiones bajos __, almohadillas # ni backticks); si quieres dar énfasis, hazlo con las palabras mismas, no con símbolos. Responde en español salvo que te escriban en otro idioma, ve al grano, organiza listas largas con guiones simples y saltos de línea (nunca con asteriscos), y responde cualquier pregunta con la mejor información posible, incluidas preguntas sobre imágenes o archivos que te adjunten.';

  // OpenRouter — proveedor de IA de Nexus IA Pro.
  // Modelo principal: DeepSeek-R1.
  // Nota: una clave incrustada en un HTML/APK no puede considerarse secreta; para producción se recomienda un backend/proxy.
  const OPENROUTER_API_KEY = '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';
  const OPENROUTER_MODEL='deepseek/deepseek-r1';
  const OPENROUTER_FALLBACK_MODEL='';

  // Clave de OpenRouter para el proveedor DeepSeek.
  // Se mantiene con un getter compatible para que el resto del núcleo de Nexus
  // no dependa de nombres antiguos de OpenAI.
  function getOpenRouterKey(){
    return String(OPENROUTER_API_KEY||'').trim();
  }
  // Alias de compatibilidad con funciones antiguas del núcleo.
  function getOpenAIKey(){
    return getOpenRouterKey();
  }

  function openAIErrorMessage(response, bodyText){
    let detail=String(bodyText||'');
    try{ const p=JSON.parse(detail); detail=p?.error?.message||p?.message||detail; }catch(e){}
    if(response?.status===400) return 'OpenRouter rechazó la solicitud. '+detail.slice(0,260);
    if(response?.status===401) return 'La clave de OpenRouter no es válida o no fue enviada correctamente.';
    if(response?.status===403) return 'OpenRouter rechazó el acceso. Revisa los permisos de la API.';
    if(response?.status===429) return 'Límite temporal de OpenRouter. Intenta de nuevo en unos minutos.';
    if(response?.status>=500) return 'El proveedor de IA tuvo un problema temporal. Inténtalo de nuevo en unos segundos.';
    return 'OpenRouter respondió con HTTP '+String(response?.status||'desconocido')+'.';
  }

  function toOpenRouterText(item){
    if(typeof item==='string') return item;
    if(!item||typeof item!=='object') return String(item??'');
    if(item.type==='text') return String(item.text||'');
    if(item.type==='image') return '[Imagen adjunta: el modelo DeepSeek-R1 usado por Nexus no procesa imágenes directamente en este flujo.]';
    if(item.type==='document') return '[Documento adjunto: '+(item.source?.filename||'documento')+']\n'+String(item.source?.text||'');
    if(item.type==='file') return '[Archivo adjunto: '+(item.name||'documento')+']\n'+String(item.text||'');
    if(item.type==='video') return '[Vídeo adjunto: '+(item.source?.filename||'vídeo')+'] El vídeo queda disponible para reproducción en la conversación; DeepSeek-R1 no recibe sus fotogramas en este flujo.';
    return String(item.text||'');
  }

  function buildOpenRouterMessages(instructions,input){
    const messages=[];
    if(instructions) messages.push({role:'system',content:String(instructions)});
    for(const m of (Array.isArray(input)?input:[])){
      const role=m?.role==='assistant'?'assistant':'user';
      const raw=Array.isArray(m?.content)?m.content:[m?.content??''];
      const content=raw.map(toOpenRouterText).filter(Boolean).join('\n');
      if(content) messages.push({role,content});
    }
    return messages;
  }

  function extractOpenAIOutput(data){
    const c=data?.choices?.[0]?.message?.content;
    if(typeof c==='string' && c.trim()) return c.trim();
    if(Array.isArray(c)) return c.map(x=>typeof x==='string'?x:(x?.text||'')).join('').trim();
    return '';
  }

  function extractOpenAISources(data){ return []; }
  function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

  async function callOpenAI(payload,apiKey,options={}){
    const model=payload.model||OPENROUTER_MODEL;
    const messages=buildOpenRouterMessages(payload.instructions,payload.input);
    const maxTokens=Math.max(256,Math.min(8000,Number(payload.max_output_tokens)||1400));
    const wantStream=options.stream===true;
    const body={model,messages,max_tokens:maxTokens,stream:wantStream};
    let lastError=null;
    let emitted=false;
    for(let attempt=0;attempt<3;attempt++){
      const ctl=new AbortController();
      let stalled=false,timer=0;
      const arm=(ms)=>{clearTimeout(timer);timer=setTimeout(()=>{stalled=true;ctl.abort();},ms);};
      const relay=()=>ctl.abort();
      if(options.signal){if(options.signal.aborted)ctl.abort();else options.signal.addEventListener('abort',relay,{once:true});}
      try{
        arm(wantStream?60000:120000);
        const response=await fetch('https://openrouter.ai/api/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+apiKey,'HTTP-Referer':'https://nexus-ia.app','X-Title':'Nexus IA Pro'},body:JSON.stringify(body),signal:ctl.signal});
        if(!response.ok){
          const errText=await response.text();
          if(response.status>=500 && attempt<2){await sleep(700*(attempt+1));continue;}
          throw new Error(openAIErrorMessage(response,errText));
        }
        if(!wantStream){
          const data=await response.json();
          clearTimeout(timer);
          const extracted=extractOpenAIOutput(data);
          if(!extracted) throw new Error('DeepSeek-R1 no devolvió texto en esta respuesta.');
          return {text:extracted,sources:[],raw:data};
        }
        if(!response.body) throw new Error('El navegador no admite streaming de OpenRouter.');
        const reader=response.body.getReader();
        const decoder=new TextDecoder();
        let buffer='',text='',streamError='';
        const consumeLine=(line)=>{
          if(!line.startsWith('data:')) return;
          const raw=line.slice(5).trim();
          if(!raw||raw==='[DONE]') return;
          let evt; try{evt=JSON.parse(raw);}catch(e){return;}
          const delta=evt?.choices?.[0]?.delta?.content;
          if(typeof delta==='string' && delta){emitted=true;text+=delta;if(typeof options.onDelta==='function') options.onDelta(delta);}
          const em=evt?.error?.message; if(em) streamError=String(em);
        };
        while(true){
          arm(45000);
          const {value,done}=await reader.read();
          if(done) break;
          buffer+=decoder.decode(value,{stream:true});
          const lines=buffer.split(/\r?\n/); buffer=lines.pop()||'';
          for(const line of lines) consumeLine(line);
        }
        if(buffer.trim()) consumeLine(buffer.trim());
        if(!text) throw new Error('DeepSeek-R1 no devolvió texto en esta respuesta'+(streamError?' ('+streamError+').':'.'));
        clearTimeout(timer);
        return {text:text.trim(),sources:[],raw:null};
      }catch(e){
        clearTimeout(timer);
        if(options.signal&&options.signal.aborted) throw e;
        if(stalled) throw new Error('DeepSeek-R1 tardó demasiado en responder. Inténtalo de nuevo.');
        if(emitted) throw e;
        lastError=e;
        if(attempt<2 && /fetch|network|conexión|temporal/i.test(String(e?.message||''))){await sleep(700*(attempt+1));continue;}
        break;
      }finally{
        clearTimeout(timer);
        if(options.signal) options.signal.removeEventListener('abort',relay);
      }
    }
    throw lastError||new Error('No se pudo contactar con DeepSeek-R1 mediante OpenRouter.');
  }

  function normalizeExactConversationName(history, text){
    try{
      const list = Array.isArray(history) ? history : [];
      const lastUser = [...list].reverse().find(m=>m?.role==='user');
      const question = typeof lastUser?.content === 'string' ? lastUser.content.trim() : '';
      if(!question) return text;

      const asksExactName =
        /cu[aá]l\s+es\s+mi\s+nombre/i.test(question) &&
        /[úu]nicamente|solo|s[oó]lo/i.test(question) &&
        /nombre/i.test(question);

      if(!asksExactName) return text;

      for(let i=list.length-1;i>=0;i--){
        const m=list[i];
        if(m?.role!=='user' || typeof m.content!=='string') continue;
        const source=m.content.trim();

        const patterns=[
          /mi\s+nombre(?:\s+de\s+prueba)?\s+es\s+["“']?([^"”'\n.!?]+)["”']?/i,
          /(?:ll[aá]mame|puedes\s+llamarme)\s+["“']?([^"”'\n.!?]+)["”']?/i
        ];

        for(const re of patterns){
          const match=source.match(re);
          if(match){
            const name=String(match[1]||'').trim();
            if(name && name.length<=120) return name.replace(/\s+/g,'');
          }
        }
      }
    }catch(e){}
    return text;
  }

  // ---------- memoria inteligente local ----------
  const NX_MEMORY_KEY='nexus_smart_memory_v1';
  function nxLoadMemory(){try{const v=JSON.parse(localStorage.getItem(NX_MEMORY_KEY)||'[]');return Array.isArray(v)?v:[];}catch(e){return [];}}
  function nxSaveMemory(items){try{localStorage.setItem(NX_MEMORY_KEY,JSON.stringify(items.slice(-40)));}catch(e){}}
  function nxRememberFromText(text){
    const q=String(text||'').trim(); if(!q) return;
    const rules=[
      [/\bmi nombre es\s+([^.!?\n]{2,60})/i,'nombre'],
      [/\bme llamo\s+([^.!?\n]{2,60})/i,'nombre'],
      [/\bprefiero\s+([^.!?\n]{3,100})/i,'preferencia'],
      [/\bmi negocio es\s+([^.!?\n]{3,120})/i,'negocio'],
      [/\btrabajo en\s+([^.!?\n]{3,100})/i,'trabajo'],
      [/\bestoy creando\s+([^.!?\n]{3,120})/i,'proyecto']
    ];
    const list=nxLoadMemory();
    for(const [re,type] of rules){const m=q.match(re);if(!m)continue;const value=m[1].trim().replace(/["“”']/g,'');if(!value)continue;const key=type+'|'+value.toLowerCase();const idx=list.findIndex(x=>x.key===key);if(idx>=0)list.splice(idx,1);list.push({key,type,value,at:Date.now()});}
    nxSaveMemory(list);
  }
  function nxMemoryContext(){
    const list=nxLoadMemory().slice(-20); if(!list.length)return '';
    return '\n\nMEMORIA INTELIGENTE LOCAL (solo hechos que el usuario expresó explícitamente):\n'+list.map(x=>'- '+x.type+': '+x.value).join('\n');
  }
  function nxUpdateMemoryStatus(){const el=document.getElementById('nxMemoryStatus');if(el)el.textContent='Memoria local: '+nxLoadMemory().length+' recuerdos útiles';}

  async function nexusAskOpenAI(history, systemOverride, options={}){
    const apiKey=getOpenRouterKey();
    const baseSystem=systemOverride || NEXUS_OPENAI_SYSTEM_PROMPT;
    const conversationalMemoryRule=`\n\nREGLA PRIORITARIA DE MEMORIA CONVERSACIONAL:\n- Los datos que el usuario establece explícitamente en la conversación actual tienen prioridad sobre cualquier dato guardado previamente.\n- Respeta siempre el contexto de la conversación actual.`;
    const latestUser=([...history].reverse().find(m=>m?.role==='user')||{});
    const latestUserText=messageText(latestUser.content);
    nxRememberFromText(latestUserText); nxUpdateMemoryStatus();
    let effectiveSystem=baseSystem+conversationalMemoryRule+nxMemoryContext();
    const needsSimulator=shouldShowInvestmentSimulator(latestUserText);
    const researchMode=!!options.useWebSearch;
    if(researchMode) effectiveSystem+='\n\nMODO INVESTIGACIÓN PROFUNDA: busca información actual y relevante antes de responder; contrasta varias fuentes cuando sea posible, separa hechos de inferencias, prioriza fuentes primarias/oficiales y menciona las fuentes consultadas. Si las fuentes discrepan, dilo claramente. No inventes datos, precios, fechas ni citas.\n';
    if(needsSimulator) effectiveSystem+='\n\nMODO ANÁLISIS DE NEGOCIO + SIMULADOR: responde primero a la solicitud exacta del usuario; NO inventes ni propongas crear un negocio si el usuario no lo pidió. Si pidió analizar una empresa/negocio, rentabilidad, inversión, costos, ingresos, viabilidad o punto de equilibrio, entrega un análisis FINANCIERO COMPLETO, desarrollado y útil, no un resumen. Organiza la respuesta con secciones claras y explica cada punto con suficiente detalle: 1) resumen ejecutivo, 2) supuestos, 3) inversión inicial, 4) ingresos y cómo se generan, 5) costos variables, 6) costos fijos, 7) utilidad y margen, 8) punto de equilibrio con explicación, 9) escenarios normal/pesimista/optimista, 10) riesgos y controles, 11) conclusión práctica. Si faltan datos, declara supuestos razonables y continúa el análisis; no te detengas para pedir datos que no sean imprescindibles. Para solicitudes de este tipo procura una respuesta sustancial (aprox. 1500-2500 palabras cuando el tema lo permita) y NO la cortes prematuramente. Nexus mostrará automáticamente su simulador debajo de tu respuesta, así que NO dependas de <NEXUS_SIMULATOR> para que aparezca y no cortes el análisis.';
    if(!apiKey) throw new Error('Nexus IA Pro no pudo cargar la clave de OpenRouter.');
    if(options.useWebSearch && !apiHasLocalAccount()) throw new Error('La búsqueda web requiere una cuenta. Crea una cuenta o inicia sesión para continuar.');
    const input=Array.isArray(history)?history:[];
    const useWeb=!!options.useWebSearch && apiHasLocalAccount();
    const data=await callOpenAI({
      model:OPENROUTER_MODEL,
      instructions:effectiveSystem,
      input,
      max_output_tokens:needsSimulator?8000:(Number(options.maxOutputTokens)||1000),
      tools:undefined
    },apiKey,{stream:options.stream===true,onDelta:typeof options.onDelta==='function'?options.onDelta:null,signal:options.signal||null});
    if(!data.text) throw new Error('DeepSeek-R1 no devolvió texto en esta respuesta.');
    data.text=normalizeExactConversationName(history,data.text);
    if(options.returnMeta) return {text:data.text,sources:data.sources||[],queries:[]};
    return data.text;
  }

  function nexusShouldUseWebSearch(text){
    const q=String(text||'').trim();
    return /\b(busca|buscar|búscame|investiga|investigación|investigacion|investigación profunda|deep research|internet|en la web|web|fuentes|fuente|noticias|actualizado|actualmente|hoy|últimas noticias|últimas novedades|precio actual|cotización actual|compar[aá]|compara|revisa varias fuentes|qué dicen las fuentes|que dicen las fuentes|datos recientes|información reciente|informacion reciente|mercado actual)\b/i.test(q);
  }


function renderResearchSources(answerRow,sources){
  if(!answerRow||!Array.isArray(sources)||!sources.length)return;
  const old=answerRow.parentElement?.nextElementSibling; if(old?.classList?.contains('nx-research-sources')) old.remove();
  const box=document.createElement('div');box.className='nx-research-sources';
  const seen=new Set();
  sources.slice(0,8).forEach(src=>{const url=String(src?.url||'');if(!/^https?:\/\//i.test(url)||seen.has(url))return;seen.add(url);const a=document.createElement('a');a.className='nx-research-source';a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.textContent=String(src?.title||url).slice(0,100);a.title=url;box.appendChild(a);});
  if(box.children.length) answerRow.insertAdjacentElement('afterend',box);
}

// ---------- envío con API OpenAI de Nexus ----------
function nxSetGenerating(on){const bar=chatInput.closest('.input-bar');if(bar)bar.classList.toggle('nx-generating',!!on);}
async function handleSend(){
  if(handleSend.busy)return;
  const text=chatInput.value.trim();
  const atts=pendingAttachments.slice();
  const fingerprint=text+'|'+atts.map(a=>a?.name||a?.type||'attachment').join(',');
  const now=Date.now();
  if(handleSend.lastFingerprint===fingerprint && now-(handleSend.lastSentAt||0)<1800){
    showToast('Ese mensaje ya se está enviando.');
    return;
  }
  handleSend.lastFingerprint=fingerprint;
  handleSend.lastSentAt=now;
  const investmentMode=shouldShowInvestmentSimulator(text);
  if(!text&&!atts.length)return;
  handleSend.busy=true;
  let typing=null,streamed='',answerBubble=null,answerSpan=null,abortCtl=null;
  try{
    let active=ensureActiveChat();
    if(emptyState.style.display!=='none'){emptyState.style.display='none';chatScroll.style.display='flex';}
    chatAutoFollow=true;
    addBubble(text||'Archivo adjunto','user',attachmentBubbleHtml(atts));
    const content=buildUserContent(text,atts);
    conversation.push({role:'user',content});
    if(active._pending || !recentChats.some(c=>c.id===active.id)){
      const created={id:active.id,title:professionalTitle(conversation),messages:conversation,projectId:nxActiveProject,createdAt:active.createdAt||Date.now(),updatedAt:Date.now()};
      recentChats.unshift(created);
      activeChatId=created.id;
      localStorage.setItem(ACTIVE_KEY,created.id);
      active=created;
      renderRecentList();
    }
    chatInput.value=''; pendingAttachments=[]; renderComposerExtras(); toggleSendButton(); scheduleSave(); hydrateStoredVideos(chatScroll);

    typing=showTyping();
    abortCtl=new AbortController();
    handleSend.abort=abortCtl;
    nxSetGenerating(true);
    const result=await nexusAskOpenAI(conversation,null,{
      stream:true, returnMeta:true,
      signal:abortCtl.signal,
      useWebSearch:nexusShouldUseWebSearch(text),
      maxOutputTokens:investmentMode?1400:(nexusShouldUseWebSearch(text)?1400:900),
      onDelta:(delta)=>{
        streamed+=delta;
        const label=typing.querySelector('.typing-label');
        if(label) label.textContent='-nexus analizando';
        if(!answerBubble){
          typing.remove();
          answerBubble=addBubble('', 'ai');
          answerSpan=document.createElement('span');
          answerBubble.appendChild(answerSpan);
        }
        if(!answerSpan._p){answerSpan._p=requestAnimationFrame(()=>{answerSpan._p=0;answerSpan.textContent=cleanText(streamed);scrollToBottom();});}
      }
    });
    if(typing.isConnected)typing.remove();
    const reply=String(result?.text||streamed||'').trim();
    if(!reply)throw new Error('DeepSeek-R1 no devolvió texto en esta respuesta.');
    if(!answerBubble){
      answerBubble=addBubble('', 'ai');
      answerSpan=document.createElement('span');
      answerBubble.appendChild(answerSpan);
    }
    if(answerSpan._p){cancelAnimationFrame(answerSpan._p);answerSpan._p=0;}
    answerSpan.textContent=cleanText(reply);
    const assistantMessage={role:'assistant',content:reply,simulator:investmentMode};
    conversation.push(assistantMessage);
    const answerRow=answerBubble.parentElement;
    addFeedbackActions(answerRow,assistantMessage,reply);
    if(investmentMode) renderInvestmentSimulator(answerRow);
    if(result?.sources?.length) renderResearchSources(answerRow,result.sources);
    scheduleSave();
    if(active.title==='Nueva conversación')active.title=professionalTitle(conversation);
    saveCurrentConversation();
  }catch(e){
    if(abortCtl&&abortCtl.signal.aborted){
      // Generación detenida por el usuario: se conserva el texto ya recibido.
      if(typing&&typing.isConnected)typing.remove();
      const partial=String(streamed||'').trim();
      if(partial){
        if(!answerBubble){
          answerBubble=addBubble('', 'ai');
          answerSpan=document.createElement('span');
          answerBubble.appendChild(answerSpan);
        }
        if(answerSpan._p){cancelAnimationFrame(answerSpan._p);answerSpan._p=0;}
        answerSpan.textContent=cleanText(partial);
        const stoppedMessage={role:'assistant',content:partial,simulator:false};
        conversation.push(stoppedMessage);
        addFeedbackActions(answerBubble.parentElement,stoppedMessage,partial);
        scheduleSave();
        try{saveCurrentConversation();}catch(_e){}
      }
    }else{
      if(typing&&typing.isConnected)typing.remove();
      const partialErr=String(streamed||'').trim();
      if(partialErr){
        if(!answerBubble){
          answerBubble=addBubble('', 'ai');
          answerSpan=document.createElement('span');
          answerBubble.appendChild(answerSpan);
        }
        if(answerSpan._p){cancelAnimationFrame(answerSpan._p);answerSpan._p=0;}
        answerSpan.textContent=cleanText(partialErr);
        const keptMessage={role:'assistant',content:partialErr,simulator:false};
        conversation.push(keptMessage);
        addFeedbackActions(answerBubble.parentElement,keptMessage,partialErr);
        scheduleSave();
        try{saveCurrentConversation();}catch(_e){}
      }
      let msg=String(e?.message||e);
      if(/failed to fetch|networkerror|load failed|network request failed|network error/i.test(msg)) msg='No hay conexión con OpenRouter. Revisa tu internet e inténtalo de nuevo.';
      if(/límite temporal|rate limit|tokens per min|TPM|429/i.test(msg)) msg='El límite temporal de tokens del modelo principal se alcanzó. Nexus intentó automáticamente un modelo alternativo. Si ambos están limitados, vuelve a intentarlo cuando se renueve el límite.';
      addSystemNote('Error de OpenRouter / DeepSeek: '+msg);
    }
  }finally{
    handleSend.busy=false; handleSend.abort=null; nxSetGenerating(false); toggleSendButton();
  }
}
feedbackCancel.onclick=closeFeedback;
feedbackScrim.addEventListener('click',e=>{if(e.target===feedbackScrim)closeFeedback();});
feedbackSend.onclick=()=>{const text=feedbackInput.value.trim();if(!pendingFeedback.message){closeFeedback();return;}if(!text){feedbackInput.focus();showToast('Cuéntanos qué podemos mejorar');return;}saveFeedbackForMessage(pendingFeedback.message,{rating:'dislike',comment:text,createdAt:Date.now()});closeFeedback();showToast('Gracias. Comentario enviado');};
function toggleSendButton(){const has=chatInput.value.trim().length>0||pendingAttachments.length>0;sendBtn.classList.toggle('show',has);}
chatInput.addEventListener('input',toggleSendButton);chatInput.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();handleSend();}});sendBtn.onclick=handleSend;
const stopBtn=$('stopBtn');if(stopBtn)stopBtn.onclick=()=>{try{if(handleSend.abort)handleSend.abort.abort();}catch(e){}};

// ---------- proyectos / workspaces locales ----------
const NX_PROJECT_KEY='nexus_projects_v1';
let nxProjects=[]; let nxActiveProject='default';
function nxLoadProjects(){try{const a=JSON.parse(localStorage.getItem(NX_PROJECT_KEY)||'[]');nxProjects=Array.isArray(a)&&a.length?a:[{id:'default',name:'General'}];}catch(e){nxProjects=[{id:'default',name:'General'}];}try{nxActiveProject=localStorage.getItem(NX_PROJECT_KEY+'_active')||'default';}catch(e){nxActiveProject='default';}}
function nxSaveProjects(){try{localStorage.setItem(NX_PROJECT_KEY,JSON.stringify(nxProjects));localStorage.setItem(NX_PROJECT_KEY+'_active',nxActiveProject);}catch(e){}}
function nxRenderProjects(){const sel=document.getElementById('nxProjectSelect');if(!sel)return;sel.innerHTML='';nxProjects.forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.name;sel.appendChild(o);});if(!nxProjects.some(p=>p.id===nxActiveProject))nxActiveProject=(nxProjects[0]&&nxProjects[0].id)||'default';sel.value=nxActiveProject;const del=document.getElementById('nxProjectDel');if(del)del.disabled=nxProjects.length<=1;}
function nxNewProject(){const name=prompt('Nombre del proyecto');if(!name||!name.trim())return;const id='p_'+Date.now().toString(36);nxProjects.push({id,name:name.trim().slice(0,50)});nxActiveProject=id;nxSaveProjects();nxRenderProjects();renderRecentList(searchChats.value);showToast('Proyecto creado');}
async function nxDeleteProject(){
  if(nxProjects.length<=1){showToast('Debe quedar al menos un proyecto');return;}
  const proj=nxProjects.find(p=>p.id===nxActiveProject);if(!proj)return;
  const pid=proj.id;
  const inProj=recentChats.filter(c=>(c.projectId||'default')===pid);
  const extra=inProj.length?' También se eliminarán sus '+inProj.length+' chat'+(inProj.length===1?'':'s')+'.':'';
  const ok=await askPermission('Eliminar proyecto','¿Eliminar «'+proj.name+'»?'+extra+' Esta acción no se puede deshacer.');
  if(!ok)return;
  inProj.forEach(c=>{(c.messages||[]).forEach(m=>{if(Array.isArray(m.content))m.content.forEach(x=>{if(x.type==='video'&&x.videoId)deleteVideoBlob(x.videoId);});});});
  recentChats=recentChats.filter(c=>(c.projectId||'default')!==pid);
  nxProjects=nxProjects.filter(p=>p.id!==pid);
  nxActiveProject=nxProjects[0].id;
  saveChats();nxSaveProjects();nxRenderProjects();
  if(activeChatId&&!recentChats.some(c=>c.id===activeChatId)){activeChatId=null;conversation=[];try{localStorage.removeItem(ACTIVE_KEY);}catch(e){}renderSavedConversation();}
  renderRecentList(searchChats.value);
  showToast('Proyecto eliminado');
}
function nxApplyProjectToActiveChat(){if(!activeChatId)return;const c=recentChats.find(x=>x.id===activeChatId);if(c){c.projectId=nxActiveProject;c.updatedAt=Date.now();saveChats();renderRecentList(searchChats.value);}}

// ---------- eventos de chats ----------
newChatBtn.onclick=createNewChat;
  nxLoadProjects(); nxRenderProjects();
  document.getElementById('nxProjectSelect')?.addEventListener('change',e=>{nxActiveProject=e.target.value;nxSaveProjects();if(activeChatId){const c=recentChats.find(x=>x.id===activeChatId);if(c && (c.projectId||'default')!==nxActiveProject){activeChatId=null;conversation=[];localStorage.removeItem(ACTIVE_KEY);renderSavedConversation();}}renderRecentList(searchChats.value);});
  document.getElementById('nxProjectAdd')?.addEventListener('click',nxNewProject);
  document.getElementById('nxProjectDel')?.addEventListener('click',nxDeleteProject);
  document.getElementById('nxMemoryClear')?.addEventListener('click',()=>{try{localStorage.removeItem(NX_MEMORY_KEY);}catch(e){}nxUpdateMemoryStatus();showToast('Memoria inteligente borrada');});
  nxUpdateMemoryStatus();
searchChats.addEventListener('input',()=>renderRecentList(searchChats.value));
chatMenuRename.onclick=async()=>{const id=activeChatMenuId;closeChatMenu();const c=recentChats.find(x=>x.id===id);if(!c)return;const n=await askRename(c.title);if(n){c.title=n;c.updatedAt=Date.now();saveChats();renderRecentList(searchChats.value);if(id===activeChatId)addSystemNote('Chat renombrado a «'+n+'».');}};
chatMenuDelete.onclick=async()=>{const id=activeChatMenuId;closeChatMenu();const c=recentChats.find(x=>x.id===id);if(!c)return;const ok=await askPermission('Eliminar chat','¿Eliminar «'+c.title+'»? Esta acción no se puede deshacer.');if(!ok)return;
  const media=[];(c.messages||[]).forEach(m=>{if(Array.isArray(m.content))m.content.forEach(x=>{if(x.type==='video'&&x.videoId)media.push(x.videoId);});});for(const idv of media)deleteVideoBlob(idv);recentChats=recentChats.filter(x=>x.id!==id);saveChats();
  if(activeChatId===id){activeChatId=null;conversation=[];localStorage.removeItem(ACTIVE_KEY);ensureActiveChat();renderSavedConversation();}renderRecentList(searchChats.value);
};
document.addEventListener('click',e=>{if(chatMenu.classList.contains('open')&&!chatMenu.contains(e.target)&&!e.target.closest('.recent-kebab'))closeChatMenu();});

// ---------- persistencia y arranque ----------
try{nxLoadProjects();}catch(e){}
loadChats();
(function boot(){
  const saved=localStorage.getItem(ACTIVE_KEY);
  const c=saved&&recentChats.find(x=>x.id===saved);
  if(c){activeChatId=c.id;conversation=Array.isArray(c.messages)?c.messages:[];}
  else{activeChatId=null;conversation=[];}
  renderRecentList();renderSavedConversation();hydrateStoredVideos(chatScroll);
  // Guardado adicional para cierres, suspensión y procesos que Android mata rápidamente.
  const persistOnExit=()=>{try{clearTimeout(saveTimer);saveCurrentConversation();}catch(e){}};
  window.addEventListener('pagehide',persistOnExit,{capture:true});
  window.addEventListener('beforeunload',persistOnExit,{capture:true});
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')persistOnExit();},{passive:true});
})();

if(settingsBtn)settingsBtn.addEventListener('click',()=>{if(settingsScrim)settingsScrim.classList.add('open');});
if(settingsCancel)settingsCancel.addEventListener('click',()=>settingsScrim.classList.remove('open'));
if(settingsSave)settingsSave.addEventListener('click',()=>{settingsScrim.classList.remove('open');showToast('DeepSeek-R1 de Nexus activo mediante OpenRouter.');});

})();


(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const ACCOUNT_KEY='nexus_accounts_v31', CURRENT_KEY='nexus_current_account_v31';
  const CHAT_KEY='nexus_system_chats_v31', ACTIVE_KEY='nexus_system_active_chat_v31';
  const VIDEO_DB='nexus_video_store_v30', VIDEO_STORE='videos';
  const accountBtn=$('accountBtn'), accountScrim=$('accountScrim'), accountList=$('accountList'), accountEmpty=$('accountEmpty');
  const picker=$('accountPickerPanel'), form=$('accountFormPanel'), del=$('deleteAccountPanel'), changePassPanel=$('changePasswordPanel');
  const nameInput=$('accountNameInput'), emailInput=$('accountEmailInput'), passInput=$('accountPasswordInput');
  const accountError=$('accountError'), deleteError=$('deleteError');
  const delPass=$('deletePasswordInput'), delConfirm=$('deletePasswordConfirm'), confirmDel=$('confirmDeleteBtn');
  const submit=$('submitAccountBtn'), newBtn=$('newAccountBtn'), loginBtn=$('loginAccountBtn');
  const closeBtn=$('closeAccountBtn'), cancelForm=$('cancelAccountFormBtn'), logoutBtn=$('logoutAccountBtn');
  const deleteVerifyEmail=$('deleteVerifyEmail'), sendDeleteCodeBtn=$('sendDeleteCodeBtn'), deleteCodeInput=$('deleteCodeInput'), verifyDeleteBtn=$('verifyDeleteBtn'), cancelDel=$('cancelDeleteBtn');
  const changePasswordOption=$('changePasswordOption'), deleteVerifiedOption=$('deleteVerifiedOption'), cancelRecoveryBtn=$('cancelRecoveryBtn');
  const newPasswordInput=$('newPasswordInput'), newPasswordConfirm=$('newPasswordConfirm'), passwordChangeError=$('passwordChangeError'), saveNewPasswordBtn=$('saveNewPasswordBtn'), cancelPasswordChangeBtn=$('cancelPasswordChangeBtn');
  const settingsAccountBtn=$('settingsAccountBtn'), exportBtn=$('exportDataBtn'), importBtn=$('importDataBtn'), importInput=$('importDataInput'), clearLocalBtn=$('clearLocalBtn');
  const settingsScrim=$('settingsScrim');
  let accountMode='register', deleteId=null, verifiedDeleteAccountId=null, pendingVerificationCode='', verificationExpiresAt=0;
  function read(k, fallback){try{const v=localStorage.getItem(k);return v?JSON.parse(v):fallback}catch(e){return fallback}}
  function write(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function accounts(){return read(ACCOUNT_KEY,[])}
  function currentId(){return localStorage.getItem(CURRENT_KEY)||''}
  function current(){return accounts().find(a=>a.id===currentId())||null}
  function esc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function toast(t){const el=$('toast');if(el){el.textContent=t;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2400)}}
  function setAvatar(){const a=current(), letter=(a?.name||'N').trim().charAt(0).toUpperCase()||'N';document.querySelectorAll('.avatar').forEach(x=>{if(!x.closest('#cameraModal'))x.textContent=letter});const footer=document.querySelector('.sidebar-foot .name');if(footer)footer.textContent=a?`${a.name} · cuenta local`:'Nexus IA Software'}
  function accountDataKey(id){return 'nexus_account_data_v31_'+id}
  function saveCurrentAccountData(){const id=currentId();if(!id)return;const data={chats:read(CHAT_KEY,[]),active:localStorage.getItem(ACTIVE_KEY)||''};write(accountDataKey(id),data)}
  function loadAccountData(id){const d=read(accountDataKey(id),null);try{if(d){localStorage.setItem(CHAT_KEY,JSON.stringify(d.chats||[]));if(d.active)localStorage.setItem(ACTIVE_KEY,d.active);else localStorage.removeItem(ACTIVE_KEY)}else{localStorage.setItem(CHAT_KEY,'[]');localStorage.removeItem(ACTIVE_KEY)}}catch(e){}location.reload()}
  function showPanel(which){picker.style.display=which==='picker'?'block':'none';form.style.display=which==='form'?'block':'none';del.style.display=which==='delete'?'block':'none';changePassPanel.style.display=which==='changePassword'?'block':'none';}
  function openAccounts(){showPanel('picker');renderAccounts();accountScrim.classList.add('open');}
  function closeAccounts(){accountScrim.classList.remove('open');showPanel('picker');deleteId=null;verifiedDeleteAccountId=null;pendingVerificationCode='';verificationExpiresAt=0}
  function renderAccounts(){const arr=accounts(), cid=currentId();accountList.innerHTML='';accountEmpty.style.display=arr.length?'none':'block';arr.forEach(a=>{const row=document.createElement('div');row.className='account-row'+(a.id===cid?' active':'');row.dataset.id=a.id;row.innerHTML=`<div class="account-avatar">${esc((a.name||a.email).charAt(0).toUpperCase())}</div><div class="account-copy"><div class="account-name">${esc(a.name)}</div><div class="account-email">${esc(a.email)}</div></div><button class="account-delete-x" type="button" aria-label="Eliminar cuenta">×</button>`;row.addEventListener('click',e=>{if(e.target.closest('.account-delete-x'))return;const target=accounts().find(x=>x.id===a.id);if(target&&target.id!==currentId()){saveCurrentAccountData();localStorage.setItem(CURRENT_KEY,target.id);loadAccountData(target.id)} });row.querySelector('.account-delete-x').addEventListener('click',e=>{e.stopPropagation();openDelete(a.id)});accountList.appendChild(row)})}
  function openForm(mode){accountMode=mode;showPanel('form');accountError.textContent='';nameInput.value='';emailInput.value='';passInput.value='';$('accountNameLabel').style.display=mode==='register'?'block':'none';nameInput.style.display=mode==='register'?'block':'none';$('accountModalTitle').textContent=mode==='register'?'Crear cuenta':'Iniciar sesión';submit.textContent=mode==='register'?'Crear cuenta':'Iniciar sesión';setTimeout(()=> (mode==='register'?nameInput:emailInput).focus(),50)}
  function submitAccount(){const email=emailInput.value.trim().toLowerCase(),password=passInput.value,name=nameInput.value.trim();const arr=accounts();if(!email||!password||(accountMode==='register'&&!name)){accountError.textContent='Completa todos los campos.';return}if(accountMode==='register'){if(arr.length>=3){accountError.textContent='Máximo 3 cuentas locales.';return}if(arr.some(a=>a.email===email)){accountError.textContent='Ese correo ya tiene una cuenta.';return}const a={id:'acct_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8),name,email,password,createdAt:Date.now()};arr.push(a);write(ACCOUNT_KEY,arr);
// Si el usuario venía usando Nexus sin cuenta, conserva su historial al crear la cuenta.
const guestChats=read(CHAT_KEY,[]),guestActive=localStorage.getItem(ACTIVE_KEY)||'';
write(accountDataKey(a.id),{chats:Array.isArray(guestChats)?guestChats:[],active:guestActive});
localStorage.setItem(CURRENT_KEY,a.id);
setAvatar();toast('Cuenta creada');location.reload()}else{const a=arr.find(x=>x.email===email&&x.password===password);if(!a){accountError.textContent='Correo o contraseña incorrectos.';return}saveCurrentAccountData();localStorage.setItem(CURRENT_KEY,a.id);loadAccountData(a.id)}}
  function logout(){saveCurrentAccountData();localStorage.removeItem(CURRENT_KEY);localStorage.setItem(CHAT_KEY,'[]');localStorage.removeItem(ACTIVE_KEY);closeAccounts();setAvatar();location.reload()}
  function openDelete(id){const a=accounts().find(x=>x.id===id);if(!a)return;deleteId=id;deleteError.textContent='';delPass.value='';delConfirm.value='';confirmDel.disabled=true;showPanel('delete');setTimeout(()=>delPass.focus(),50)}
  function updateDelete(){const ok=!!delPass.value&&delPass.value===delConfirm.value;confirmDel.disabled=!ok;deleteError.textContent=delPass.value&&delConfirm.value&&delPass.value!==delConfirm.value?'Las contraseñas no coinciden.':''}
  function deleteAccount(){const arr=accounts(),a=arr.find(x=>x.id===deleteId);if(!a)return;if(delPass.value!==a.password){deleteError.textContent='La contraseña no coincide.';return}if(delPass.value!==delConfirm.value){deleteError.textContent='Las contraseñas no coinciden.';return}try{localStorage.removeItem(accountDataKey(a.id));localStorage.removeItem('nexus_conversation_'+a.id);localStorage.removeItem('nexus_chats_'+a.id);localStorage.removeItem('nexus_chats_'+a.id+'_active');const remaining=arr.filter(x=>x.id!==a.id);write(ACCOUNT_KEY,remaining);if(currentId()===a.id){localStorage.removeItem(CURRENT_KEY);localStorage.setItem(CHAT_KEY,'[]');localStorage.removeItem(ACTIVE_KEY)}toast('Cuenta eliminada');if(currentId()===a.id){if(remaining.length){localStorage.setItem(CURRENT_KEY,remaining[0].id);loadAccountData(remaining[0].id)}else{closeAccounts();setAvatar();location.reload()}}else{showPanel('picker');renderAccounts()}}catch(e){deleteError.textContent='No se pudo eliminar la cuenta.'}}
  function saveChangedPassword(){const a=accounts().find(x=>x.id===deleteId);if(!a)return;const p=newPasswordInput.value,p2=newPasswordConfirm.value;if(p.length<4||p.length>9){passwordChangeError.textContent='La contraseña debe tener entre 4 y 9 caracteres.';return}if(p!==p2){passwordChangeError.textContent='Las contraseñas no coinciden.';return}a.password=p;write(ACCOUNT_KEY,accounts());toast('Contraseña cambiada');showPanel('picker');renderAccounts()}

  function exportData(){const data={version:1,exportedAt:new Date().toISOString(),accounts:accounts().map(a=>({...a})),current:currentId(),chats:read(CHAT_KEY,[]),active:localStorage.getItem(ACTIVE_KEY)||''};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='nexus-datos-locales.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Datos exportados')}
  function importData(){importInput.click()}
  importInput.addEventListener('change',async()=>{const f=importInput.files?.[0];if(!f)return;try{const d=JSON.parse(await f.text());if(!Array.isArray(d.accounts)||!Array.isArray(d.chats))throw Error();if(d.accounts.length>3)throw Error('Máximo 3 cuentas');if(d.accounts.some(a=>!a||!a.id||!a.email||!a.password||!a.name))throw Error('Cuentas inválidas');write(ACCOUNT_KEY,d.accounts);if(d.current)localStorage.setItem(CURRENT_KEY,d.current);write(CHAT_KEY,d.chats);if(d.active)localStorage.setItem(ACTIVE_KEY,d.active);else localStorage.removeItem(ACTIVE_KEY);toast('Datos importados');setTimeout(()=>location.reload(),500)}catch(e){toast('Archivo de datos no válido')}importInput.value=''})
  function clearLocal(){if(!confirm('¿Borrar todos los datos locales de Nexus en este dispositivo?'))return;const keys=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&(/^nexus_/i.test(k)||k.startsWith('zoe_')))keys.push(k)}keys.forEach(k=>localStorage.removeItem(k));indexedDB.deleteDatabase(VIDEO_DB);toast('Datos locales eliminados');setTimeout(()=>location.reload(),500)}
  accountBtn?.addEventListener('click',openAccounts);document.querySelector('.topbar .avatar')?.addEventListener('click',()=>{settingsScrim.classList.add('open')});newBtn?.addEventListener('click',()=>openForm('register'));loginBtn?.addEventListener('click',()=>openForm('login'));submit?.addEventListener('click',submitAccount);closeBtn?.addEventListener('click',closeAccounts);cancelForm?.addEventListener('click',()=>showPanel('picker'));logoutBtn?.addEventListener('click',logout);cancelDel?.addEventListener('click',()=>showPanel('picker'));delPass?.addEventListener('input',updateDelete);delConfirm?.addEventListener('input',updateDelete);confirmDel?.addEventListener('click',deleteAccount);cancelPasswordChangeBtn?.addEventListener('click',()=>showPanel('picker'));saveNewPasswordBtn?.addEventListener('click',saveChangedPassword);accountScrim?.addEventListener('click',e=>{if(e.target===accountScrim)closeAccounts()});settingsAccountBtn?.addEventListener('click',()=>{settingsScrim.classList.remove('open');openAccounts()});exportBtn?.addEventListener('click',exportData);importBtn?.addEventListener('click',importData);clearLocalBtn?.addEventListener('click',clearLocal);
  if(!currentId() && accounts().length){/* no forced login: app remains usable */} setAvatar();
})();


(function(){
  var box=document.getElementById('heroChips');
  if(!box)return;
  box.addEventListener('click',function(e){
    var b=e.target.closest('.hero-chip'); if(!b)return;
    var inp=document.getElementById('chatInput'),send=document.getElementById('sendBtn');
    if(!inp||!send)return;
    inp.value=b.getAttribute('data-prompt')||'';
    inp.dispatchEvent(new Event('input',{bubbles:true}));
    send.click();
  },{passive:true});
})();


(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const btn=$('privateBrowserBtn'), browser=$('privateBrowser'), close=$('browserClose'), frame=$('browserFrame'), address=$('browserAddress'), form=$('browserSearchForm');
  const back=$('browserBack'), forward=$('browserForward'), reload=$('browserReload'), fallback=$('browserFallback'), openGoogle=$('browserOpenGoogle'), lock=$('browserLock'), lockClose=$('browserLockClose'), accountBtn=$('browserAccountBtn');
  const historyBtn=$('browserHistoryBtn'), historyPanel=$('browserHistory'), historyClose=$('browserHistoryClose'), historyList=$('browserHistoryList'), historyClear=$('browserHistoryClear');
  const CURRENT_KEY='nexus_current_account_v31';
  const lockBadge=$('privateBrowserLockBadge');
  const HISTORY_PREFIX='nexus_browser_history_v2_';
  let lastUrl='https://www.google.com/webhp?igu=1';
  let longPressTimer=null;
  function hasAccount(){return !!localStorage.getItem(CURRENT_KEY)}
  function syncBrowserLockBadge(){if(lockBadge) lockBadge.style.display=hasAccount()?'none':'inline';}
  function accountId(){return localStorage.getItem(CURRENT_KEY)||'guest'}
  function historyKey(){return HISTORY_PREFIX+accountId()}
  function googleUrl(query){return 'https://www.google.com/search?igu=1&q='+encodeURIComponent(query||'')}
  function readHistory(){if(!hasAccount())return [];try{const x=JSON.parse(localStorage.getItem(historyKey())||'[]');return Array.isArray(x)?x:[]}catch(e){return []}}
  function writeHistory(list){if(!hasAccount())return;try{localStorage.setItem(historyKey(),JSON.stringify(list.slice(0,100)))}catch(e){}}
  function addHistory(query,url){
    if(!hasAccount())return;
    const q=String(query||'').trim(); if(!q)return;
    const list=readHistory();
    const item={id:'bh_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7),query:q,url:url||'',time:Date.now()};
    const filtered=list.filter(x=>String(x.query||'').toLowerCase()!==q.toLowerCase());
    filtered.unshift(item); writeHistory(filtered); renderHistory();
  }
  function fmtTime(ts){try{return new Date(ts).toLocaleString('es-CO',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}catch(e){return ''}}
  function renderHistory(){
    if(!historyList)return;
    const list=readHistory(); historyList.innerHTML='';
    if(!list.length){const e=document.createElement('div');e.className='browser-history-empty';e.textContent='Todavía no hay búsquedas guardadas.';historyList.appendChild(e);return;}
    list.forEach(item=>{
      const row=document.createElement('div');row.className='browser-history-item';row.dataset.id=item.id;
      const main=document.createElement('div');main.className='bh-main';
      const title=document.createElement('div');title.className='bh-title';title.textContent=item.query||item.url||'Página';
      const url=document.createElement('div');url.className='bh-url';url.textContent=item.url||'Búsqueda de Google';
      main.append(title,url);
      const time=document.createElement('div');time.className='bh-time';time.textContent=fmtTime(item.time);
      const del=document.createElement('button');del.className='browser-history-delete';del.type='button';del.textContent='Eliminar';del.setAttribute('aria-label','Eliminar del historial');
      row.append(main,time,del); historyList.appendChild(row);
      let fired=false;
      const begin=()=>{fired=false;clearTimeout(longPressTimer);longPressTimer=setTimeout(()=>{fired=true;row.classList.add('selected')},650)};
      const cancel=()=>{clearTimeout(longPressTimer)};
      row.addEventListener('pointerdown',begin); row.addEventListener('pointerup',cancel); row.addEventListener('pointerleave',cancel); row.addEventListener('pointercancel',cancel);
      del.addEventListener('click',e=>{e.stopPropagation();deleteHistoryItem(item.id)});
      row.addEventListener('click',()=>{if(fired)return;if(row.classList.contains('selected'))return; historyPanel.classList.remove('open');historyPanel.setAttribute('aria-hidden','true');loadGoogle(item.query);});
    });
  }
  function deleteHistoryItem(id){const list=readHistory().filter(x=>x.id!==id);writeHistory(list);renderHistory()}
  function openHistory(){if(!hasAccount()){lock.classList.add('show');return;}renderHistory();historyPanel.classList.add('open');historyPanel.setAttribute('aria-hidden','false')}
  function closeHistory(){historyPanel.classList.remove('open');historyPanel.setAttribute('aria-hidden','true')}
  function openPrivateBrowser(){
    syncBrowserLockBadge();
    browser.classList.add('open'); browser.setAttribute('aria-hidden','false');
    if(!hasAccount()){
      closeHistory();
      lock.classList.add('show');
      return;
    }
    lock.classList.remove('show'); renderHistory();
    if(!frame.src) loadGoogle(''); setTimeout(()=>address.focus(),80);
  }
  function closePrivateBrowser(){
    closeHistory(); browser.classList.remove('open'); browser.setAttribute('aria-hidden','true');
    try{frame.src='about:blank'}catch(e){} address.value=''; fallback.classList.remove('show');
  }
  function loadGoogle(query){
    if(!hasAccount()){lock.classList.add('show');return}
    const value=String(query||'').trim();
    let url=value;
    if(!/^https?:\/\//i.test(url)) url=googleUrl(value);
    lastUrl=url; fallback.classList.remove('show'); frame.src=lastUrl; address.value=value;
    if(value)addHistory(value,lastUrl);
  }
  form.addEventListener('submit',e=>{e.preventDefault();if(!hasAccount()){lock.classList.add('show');return}loadGoogle(address.value)});
  btn?.addEventListener('click',openPrivateBrowser); close?.addEventListener('click',closePrivateBrowser);
  historyBtn?.addEventListener('click',openHistory); historyClose?.addEventListener('click',closeHistory); lockClose?.addEventListener('click',()=>{lock.classList.remove('show');closePrivateBrowser();});
  historyClear?.addEventListener('click',()=>{if(!hasAccount())return;if(confirm('¿Eliminar todo el historial de Nexus de este dispositivo?')){localStorage.removeItem(historyKey());renderHistory()}});
  back?.addEventListener('click',()=>{try{frame.contentWindow.history.back()}catch(e){}});
  forward?.addEventListener('click',()=>{try{frame.contentWindow.history.forward()}catch(e){}});
  reload?.addEventListener('click',()=>{try{frame.contentWindow.location.reload()}catch(e){frame.src=lastUrl}});
  frame?.addEventListener('load',()=>{fallback.classList.remove('show');});
  frame?.addEventListener('error',()=>{fallback.classList.add('show');});
  // Muchos sitios bloquean iframes con X-Frame-Options/CSP. Ofrecemos abrir la URL directamente.
  openGoogle?.addEventListener('click',()=>{if(lastUrl)window.open(lastUrl,'_blank','noopener,noreferrer');});
  accountBtn?.addEventListener('click',()=>{browser.classList.remove('open');browser.setAttribute('aria-hidden','true');lock.classList.remove('show');document.getElementById('accountBtn')?.click();});
  window.addEventListener('storage',()=>{
    syncBrowserLockBadge();
    if(!hasAccount()){
      if(browser.classList.contains('open')){lock.classList.add('show');closeHistory();try{frame.src='about:blank'}catch(e){}}
    }
  });
  syncBrowserLockBadge();
})();


/* Nexus IA Pro — imagen real del tema sobre la respuesta (Wikipedia/Wikimedia).
   Módulo independiente: observa el chat, no modifica ninguna función existente. */
(function(){
  'use strict';
  var scroll=document.getElementById('chatScroll');
  if(!scroll||!window.MutationObserver||!window.fetch) return;
  var CACHE_KEY='nexus_topic_image_cache_v1', CACHE_MAX=60;
  var live=null;

  function norm(s){return String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');}
  function esc(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}
  function readCache(){try{var o=JSON.parse(localStorage.getItem(CACHE_KEY)||'{}');return o&&typeof o==='object'?o:{};}catch(e){return {};}}
  function writeCache(key,info){
    try{var o=readCache();o[key]={src:info.src,title:info.title,lang:info.lang,t:Date.now()};
      var keys=Object.keys(o);
      if(keys.length>CACHE_MAX){keys.sort(function(a,b){return (o[a].t||0)-(o[b].t||0);}).slice(0,keys.length-CACHE_MAX).forEach(function(k){delete o[k];});}
      localStorage.setItem(CACHE_KEY,JSON.stringify(o));}catch(e){}
  }

  // ---------- 1) tema de la pregunta ----------
  var BAD_TOPIC=/^(?:mejor|peor|bueno|buena|malo|mala|posible|necesario|importante|diferente|diferencia|igual|mismo|misma|algo|todo|nada|esto|eso|aquello|ahora|hoy|ayer|manana|verdad|cierto|correcto|forma|manera|modo|cosa|cosas|ejemplo|ejemplos|ayuda|favor|gracias|hola)$/;
  var STOP=/^(?:el|la|los|las|un|una|unos|unas|de|del|al|lo|y|e|o|u|en|con|por|para|que|se|su|sus|mi|mis|tu|tus)$/;
  function topicFromQuestion(raw){
    var q=String(raw||'').replace(/\s+/g,' ').trim();
    if(!q||q.length>160) return '';
    q=q.replace(/[¿?¡!"“”]/g,' ').replace(/\s+/g,' ').trim();
    for(var i=0;i<2;i++) q=q.replace(/^(?:hola|buenas|buenos dias|buenas tardes|oye|hey|por favor|porfa|disculpa|nexus ia pro|nexus ia|nexus)[,.\s]+/i,'');
    var pats=[
      /(?:^|\s)(?:informaci[oó]n|info|datos|detalles|noticias|resumen)\s+(?:sobre|acerca\s+de|de\s+la|de\s+los|de\s+las|del|de)\s+(.+)$/i,
      /(?:h[aá]blame|cu[eé]ntame|dime|expl[ií]came|ens[eé]ñame|descr[ií]beme|investiga|b[uú]scame|busca|mu[eé]strame|muestra)\s+(?:algo\s+|todo\s+|m[aá]s\s+)?(?:sobre|acerca\s+de|de\s+la|de\s+los|de\s+las|del|de)\s+(.+)$/i,
      /(?:^|\s)(?:qu[eé]\s+(?:es|son|significa|fue|era)|qui[eé]n(?:es)?\s+(?:es|son|fue|fueron|era)|c[oó]mo\s+funcionan?|c[oó]mo\s+es|para\s+qu[eé]\s+sirven?|cu[aá]l\s+es\s+la\s+historia\s+de|historia\s+de|origen\s+de|caracter[ií]sticas\s+de|tipos\s+de|partes\s+de)\s+(.+)$/i,
      /(?:im[aá]genes?|fotos?|fotograf[ií]as?)\s+(?:de\s+la|de\s+los|de\s+las|del|de)\s+(.+)$/i,
      /(?:^|\s)(?:information\s+(?:about|on)|info\s+(?:about|on)|tell\s+me\s+about|what\s+(?:is|are)|who\s+(?:is|was)|how\s+does|how\s+do)\s+(.+)$/i
    ];
    var t='';
    for(var p=0;p<pats.length;p++){var m=q.match(pats[p]);if(m&&m[1]){t=m[1];break;}}
    if(!t) return '';
    t=t.replace(/\s+(?:por\s+favor|porfa|gracias|en\s+detalle|detalladamente|please)\s*$/i,'');
    t=t.split(/\s+(?:para|que|con|porque|cuando|si|donde|pero|por|y|e|o|en|desde|durante|seg[uú]n|and|for|with|in)\s+/i)[0];
    t=t.replace(/^(?:el|la|los|las|un|una|unos|unas|lo|the|a|an)\s+/i,'').replace(/[,.;:]+$/,'').trim();
    if(/^(?:mi|mis|tu|tus|su|sus|nuestr[oa]s?)\s/i.test(t)||/nexus/i.test(t)) return '';
    var words=t.split(' ').filter(Boolean).slice(0,5);
    t=words.join(' ');
    if(t.length<3) return '';
    var meaningful=words.filter(function(w){var n=norm(w);return n.length>=3&&!STOP.test(n)&&!BAD_TOPIC.test(n);});
    if(!meaningful.length) return '';
    return t;
  }

  // ---------- 2) búsqueda en Wikipedia ----------
  function withTimeout(ms){var c=new AbortController();setTimeout(function(){c.abort();},ms);return c;}
  function wikiSearch(lang,topic){
    var u='https://'+lang+'.wikipedia.org/w/api.php?action=query&format=json&origin=*&generator=search&gsrnamespace=0&gsrlimit=8&gsrsearch='+encodeURIComponent(topic)+'&prop=pageimages|pageprops&piprop=thumbnail&pithumbsize=900&pilimit=8&ppprop=disambiguation';
    return fetch(u,{signal:withTimeout(8000).signal}).then(function(r){return r.ok?r.json():null;}).then(function(j){
      var pages=j&&j.query&&j.query.pages?Object.keys(j.query.pages).map(function(k){return j.query.pages[k];}):[];
      return pages.filter(function(p){
        var th=p.thumbnail;
        return th&&th.source&&th.width>=240&&!(p.pageprops&&('disambiguation' in p.pageprops))&&!/\.svg(?:\.png)?(?:$|\?)/i.test(th.source)&&!/^(?:anexo|lista de|list of|categor)/i.test(p.title||'');
      }).map(function(p){return {title:p.title,rank:p.index||99,src:p.thumbnail.source,lang:lang};});
    }).catch(function(){return [];});
  }
  function fetchCandidates(topic){
    var langs=/\b(?:the|what|who|how|about|tell|is|are)\b/i.test(topic)?['en','es']:['es','en'];
    return Promise.all(langs.map(function(l){return wikiSearch(l,topic);})).then(function(a){return a[0].concat(a[1]);});
  }

  // ---------- 3) elegir la imagen más relevante ----------
  function pickBest(cands,topic,answer){
    var ansN=norm(answer), tTok=norm(topic).split(/\s+/).filter(function(w){return w.length>=3&&!STOP.test(w);})
      .map(function(w){return w.length>4?w.replace(/(?:es|s)$/,''):w;});
    var best=null;
    cands.forEach(function(c){
      var base=norm(c.title.replace(/\s*\(.*?\)\s*/g,' ')).trim();
      var qm=c.title.match(/\(([^)]*)\)/), qual=qm?norm(qm[1]):'';
      var bTok=base.split(/\s+/);
      var tm=0; tTok.forEach(function(t){if(bTok.some(function(b){return b.length>=3&&(b.indexOf(t)>=0||t.indexOf(b)>=0);}))tm++;});
      var occ=0; if(base&&ansN){try{occ=Math.min(4,(ansN.match(new RegExp('(?:^|[^a-z0-9])'+esc(base)+'(?:es|s)?(?![a-z0-9])','g'))||[]).length);}catch(e){}}
      if(!tm&&!occ) return;
      var s=tm*3+occ*1.5-c.rank*0.3;
      if(qual) s+=(ansN.indexOf(qual)>=0)?2:-3;
      if(c.lang==='en'&&/^es/.test(document.documentElement.lang||'es')) s-=0.5;
      if(!best||s>best.s) best={c:c,s:s};
    });
    return best&&best.s>0?best.c:null;
  }

  // ---------- 4) mostrar la imagen arriba de la respuesta ----------
  function bubbleText(bubble){
    var out='';for(var i=0;i<bubble.childNodes.length;i++){var n=bubble.childNodes[i];if(n.nodeType===1&&n.classList.contains('nx-topic-img'))continue;out+=n.textContent+' ';}
    return out.replace(/\s+/g,' ').trim();
  }
  function insertCard(bubble,info){
    if(!bubble||bubble.querySelector('.nx-topic-img')) return;
    var img=new Image();img.alt=info.title;img.decoding='async';img.referrerPolicy='no-referrer';
    img.onload=function(){
      if(!bubble.isConnected||bubble.querySelector('.nx-topic-img')) return;
      var near=scroll.scrollHeight-scroll.scrollTop-scroll.clientHeight<420;
      var fig=document.createElement('a');fig.className='nx-topic-img';var pageUrl='https://'+(info.lang||'es')+'.wikipedia.org/wiki/'+encodeURIComponent(String(info.title).replace(/ /g,'_'));fig.href=pageUrl;fig.target='_blank';fig.rel='noopener noreferrer';fig.setAttribute('aria-label','Abrir '+info.title+' en el navegador');fig.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();try{window.open(pageUrl,'_blank','noopener,noreferrer');}catch(e){location.href=pageUrl;}});
      fig.appendChild(img);
      var cap=document.createElement('div');cap.className='nx-topic-cap';cap.textContent='Wikipedia · '+info.title+'  ↗';fig.appendChild(cap);
      bubble.insertBefore(fig,bubble.firstChild);
      if(near) scroll.scrollTop=scroll.scrollHeight;
    };
    img.src=info.src;
  }
  function nearestUserRow(row){var n=row.previousElementSibling;while(n){if(n.classList&&n.classList.contains('bubble-row')&&n.classList.contains('user'))return n;n=n.previousElementSibling;}return null;}
  function userQuestion(userRow){
    if(!userRow) return '';
    var b=userRow.querySelector('.bubble'); if(!b) return '';
    var kids=b.children; if(kids.length!==1||kids[0].tagName!=='SPAN') return '';
    return kids[0].textContent||'';
  }

  function attachLive(row,job){
    var started=Date.now();
    (function poll(){
      var bubble=row.querySelector('.bubble');
      if(!bubble||!row.isConnected) return;
      var txt=bubbleText(bubble), done=!!row.querySelector('.message-actions'), waited=Date.now()-started;
      if(job.done&&(txt.length>=160||done||waited>=3500)){
        var best=pickBest(job.cands,job.topic,txt);
        if(best){var info={src:best.src,title:best.title,lang:best.lang};writeCache(job.key,info);insertCard(bubble,info);}
        return;
      }
      if(waited>12000) return;
      setTimeout(poll,120);
    })();
  }
  function attachCached(row){
    var key=norm(userQuestion(nearestUserRow(row))).trim(); if(!key) return;
    var hit=readCache()[key]; if(!hit||!hit.src) return;
    insertCard(row.querySelector('.bubble'),hit);
  }

  function onRowAdded(row){
    if(!row.classList||!row.classList.contains('bubble-row')||!row.classList.contains('ai')) return;
    if(row.querySelector('.typing-row')){
      // arranca la búsqueda en paralelo a la generación de la IA
      var userRow=nearestUserRow(row), q=userQuestion(userRow), topic=topicFromQuestion(q);
      live=null; if(!topic) return;
      var job={userRow:userRow,topic:topic,key:norm(q).trim(),cands:[],done:false,row:null};
      job.p=fetchCandidates(topic).then(function(c){job.cands=c;job.done=true;});
      live=job; return;
    }
    if(live&&!live.row&&live.userRow&&live.userRow.isConnected&&nearestUserRow(row)===live.userRow){
      var job2=live; job2.row=row; live=null;
      var cachedHit=readCache()[job2.key];
      if(cachedHit&&cachedHit.src){insertCard(row.querySelector('.bubble'),cachedHit);return;}
      job2.p.then(function(){attachLive(row,job2);});
      return;
    }
    attachCached(row);
  }

  new MutationObserver(function(muts){
    muts.forEach(function(m){m.addedNodes.forEach(function(n){if(n.nodeType===1){try{onRowAdded(n);}catch(e){}}});});
  }).observe(scroll,{childList:true});
})();


(function(){
  try{
    // Onda táctil premium en botones
    document.addEventListener('pointerdown',function(e){
      var b=e.target.closest&&e.target.closest('.hero-chip,.round-btn,.side-item,.investment-toggle');
      if(!b||b.disabled)return;
      var r=b.getBoundingClientRect(),s=Math.max(r.width,r.height)*1.6,d=document.createElement('span');
      d.className='nx-ripple';d.style.width=d.style.height=s+'px';
      d.style.left=(e.clientX-r.left-s/2)+'px';d.style.top=(e.clientY-r.top-s/2)+'px';
      var cs=getComputedStyle(b);if(cs.position==='static')b.style.position='relative';
      if(cs.overflow==='visible')b.style.overflow='hidden';
      b.appendChild(d);setTimeout(function(){d.remove();},620);
    },{passive:true});
    // Color de barra del sistema acorde al tema vainilla
    var m=document.querySelector('meta[name=theme-color]');
    if(!m){m=document.createElement('meta');m.name='theme-color';document.head.appendChild(m);}
    m.content='#fbfaf5';
  }catch(e){}
})();
