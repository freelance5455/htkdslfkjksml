const $ = (selector) => document.querySelector(selector);
const form = $('#clue-form');
const dnaField = $('#dna-clue');
const favoriteField = $('#favorite-clue');
const resultCard = $('#result-card');
const resultTitle = $('#result-title');
const resultCopy = $('#result-copy');
const feedback = $('#result-feedback');
const againButton = $('#again-button');

const archetypes = [
  ['a cozy little daydreamer', 'You collect tiny joys, make excellent snack choices, and probably have a favorite mug.'],
  ['a curious chaos-pilot', 'You follow interesting questions, take the scenic route, and make a side quest out of everything.'],
  ['a soft-hearted world-builder', 'You turn ordinary things into stories and always leave room for one more little idea.'],
  ['a sunshine-powered oddball', 'You bring big energy, unexpected facts, and a suspiciously good playlist wherever you go.'],
  ['a low-key legend', 'You notice the details, know what you like, and make doing your own thing look easy.']
];
const nextLikes = [
  'a tiny collection of colorful rocks', 'a late-night snack experiment', 'a playlist for a very specific mood',
  'a cozy little game with a secret ending', 'a day trip with absolutely no schedule', 'a very small pet with a very big name',
  'making something just to see if you can', 'a themed mug that is slightly too specific'
];
function hash(text) {
  let value = 2166136261;
  for (const char of text) value = Math.imul(value ^ char.charCodeAt(0), 16777619);
  return value >>> 0;
}
function makeGuess(dna, favorite) {
  const seed = hash((dna + '|' + favorite).toLowerCase());
  const vibe = archetypes[seed % archetypes.length];
  const extraLike = nextLikes[Math.floor(seed / 11) % nextLikes.length];
  const clue = dna.toLowerCase();
  let flavor = 'a little sparkle';
  if (/moon|star|space|cosmic|planet|alien/.test(clue)) flavor = 'cosmic curiosity';
  else if (/honey|cake|cookie|sugar|candy|chocolate/.test(clue)) flavor = 'sweet-tooth energy';
  else if (/chaos|lightning|fire|storm|wild/.test(clue)) flavor = 'chaotic-good energy';
  else if (/moss|leaf|forest|ocean|rain|earth/.test(clue)) flavor = 'nature-loving energy';
  else if (/music|rhythm|beat|song|sound/.test(clue)) flavor = 'soundtrack-main-character energy';
  return { vibe: vibe[0], description: vibe[1], flavor, favorite: favorite.trim(), extraLike };
}
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const dna = dnaField.value.trim();
  const favorite = favoriteField.value.trim();
  if (!dna || !favorite) return;
  const guess = makeGuess(dna, favorite);
  resultTitle.textContent = 'You are ' + guess.vibe + '.';
  resultCopy.textContent = 'Those imaginary DNA clues are giving ' + guess.flavor + '. Your favorite thing is ' + guess.favorite + ', and I bet your next little obsession will be ' + guess.extraLike + '. ' + guess.description;
  resultCard.classList.add('has-result');
  feedback.hidden = false;
  againButton.hidden = false;
  resultCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
});
feedback.addEventListener('click', (event) => {
  const button = event.target.closest('[data-feedback]');
  if (!button) return;
  feedback.innerHTML = button.dataset.feedback === 'yes'
    ? '<span>Vibe check: passed.</span><b class="feedback-note">The crystal ball says you are extremely fun.</b>'
    : '<span>Vibe check: delightfully wrong.</span><b class="feedback-note">The crystal ball needs a snack and another clue.</b>';
});
againButton.addEventListener('click', () => {
  form.reset();
  feedback.hidden = true;
  feedback.innerHTML = '<span>Did I get it?</span><button type="button" data-feedback="yes">Yep</button><button type="button" data-feedback="no">Not even close</button>';
  againButton.hidden = true;
  resultCard.classList.remove('has-result');
  resultTitle.innerHTML = 'Your mystery<br>is still a mystery.';
  resultCopy.textContent = 'Drop in two clues and let this extremely unqualified machine take a guess.';
  dnaField.focus();
});
