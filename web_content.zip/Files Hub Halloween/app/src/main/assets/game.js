(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const selectScreen = $("selectScreen"), gameScreen = $("gameScreen");
  const canvas = $("gameCanvas"), ctx = canvas.getContext("2d");
  const WORLD = { w: 1500, h: 1050 };
  const ZOOM = 0.7;
  let currentMap = "original";
  const halloweenArt = {
    statue: new Image(), ghost1: new Image(), ghost2: new Image(), pumpkin: new Image()
  };
  halloweenArt.statue.src = "assets/decoration/halloween-statue.png";
  halloweenArt.ghost1.src = "assets/decoration/halloween-ghost-1.png";
  halloweenArt.ghost2.src = "assets/decoration/halloween-ghost-2.png";
  halloweenArt.pumpkin.src = "assets/decoration/halloween-pumpkin.png";
  let halloweenDecor = [];
 
  const MATCH_SECONDS = 240;
  const killers = [
    {name:"Stab", size:72, key:"stab", image:"assets/characters/killer-stab.png", desc:"Um perseguidor veloz que pressiona os Survivors.", hp:160, speed:120, sprint:200, stamina:100, damage:20, cooldown:.99, range:40, hitboxSize:30, color:"#e44755", role:"VELOCISTA"},
    {name:"JJ", size:71, key:"jj", image:"assets/characters/killer-jj.png", desc:"Resistente, com bastante vida e stamina.", hp:200, speed:117, sprint:185, stamina:150, damage:25, cooldown:.99, range:40, hitboxSize:45, color:"#72dc61", role:"RESISTENTE"},
    {name:"H4ck4r", size:73, key:"hacker", image:"assets/characters/killer-hacker.png", desc:"Imprevisível: cada M1 pode causar dano diferente.", hp:175, speed:114, sprint:180, stamina:115, damages:[20,24,28,22,30], cooldown:.99, range:50, hitboxSize:32, color:"#53c8d4", role:"IMPREVISÍVEL"},
    {name:"Sixer", size:80, key:"sixer", image:"assets/characters/killer-sixer.png", desc:"O mais resistente, com uma reserva enorme de stamina.", hp:220, speed:125, sprint:178, stamina:180, damage:28, cooldown:.99, range:62, hitboxSize:58, color:"#e44755", role:"TANQUE"},
    {name:"Wesley", size:70, key:"wesley", image:"assets/characters/killer-wesley.png", desc:"Corre muito rápido, mas tem pouca stamina e vida.", hp:140, speed:110, sprint:210, stamina:85, damage:26.3, cooldown:.83, range:28, hitboxSize:40, color:"#a68aff", role:"ALTA VELOCIDADE"},
    {name:"Skeleton", size:76, key:"skeleton", image:"assets/characters/killer-skeleton.png", desc:"A própria Morte, atacando com uma foice invisível.", hp:175, speed:127, sprint:200, stamina:210, damage:22, cooldown:.99, range:48, hitboxSize:42, color:"#d8d2c5", role:"A MORTE"}
  ];
  const killerImages = killers.map(k => { const img = new Image(); img.src = k.image; return img; });
  const survivorImages = {
    "Dummy": "assets/characters/survivor-dummy.png",
    "Palhaço": "assets/characters/survivor-palhaço.png",
    "Healer": "assets/characters/survivor-healer.png",
    "cowardlypuncher": "assets/characters/survivor-cowardlypuncher.png",
    "GhostGirl": "assets/characters/survivor-ghostgirl.png"
  };
  const survivorImageCache = {};
  Object.entries(survivorImages).forEach(([name,src]) => { const img = new Image(); img.src = src; survivorImageCache[name] = img; });
  const skeletonImage = new Image(); skeletonImage.src = "assets/characters/killer-skeleton.png";
  const survivorNames = Object.keys(survivorImages);
  const SURVIVORS_PER_MATCH = 6;
  const survivorStats = {
    "Dummy": {hp:100,speed:145,sprint:165,stamina:100},
    "Palhaço": {hp:90,speed:140,sprint:165,stamina:100},
    "Healer": {hp:80,speed:138,sprint:157,stamina:110},
    "GhostGirl": {hp:100,speed:145,sprint:165,stamina:108},
    "cowardlypuncher": {hp:115,speed:135,sprint:168,stamina:90}
  };
  const killerPrices = {Stab:0, JJ:750, H4ck4r:1170, Sixer:1750, Wesley:1000, Skeleton:2100};
  const survivorPrices = {Dummy:0, "Palhaço":450, Healer:500, cowardlypuncher:650, GhostGirl:500};
  const loadSet = key => { try { return new Set(JSON.parse(localStorage.getItem(key)||"[]")); } catch { return new Set(); } };
  let money = Math.max(0, Number(localStorage.getItem("filesHubMoney")||0));
  const ownedKillers = loadSet("filesHubOwnedKillers"); ownedKillers.add("Stab");
  const ownedSurvivors = loadSet("filesHubOwnedSurvivors"); ownedSurvivors.add("Dummy");
  function saveEconomy(){localStorage.setItem("filesHubMoney",String(money));localStorage.setItem("filesHubOwnedKillers",JSON.stringify([...ownedKillers]));localStorage.setItem("filesHubOwnedSurvivors",JSON.stringify([...ownedSurvivors]));}
  function updateMoneyUI(){["menuMoney","gameMoney"].forEach(id=>{const el=$(id);if(el)el.textContent=`💰 ${money} Dinheiro`;});}
  function addMoney(amount, reason="") { if(!amount)return;money+=amount;saveEconomy();updateMoneyUI();showToast(`+${amount} Dinheiro${reason?` • ${reason}`:""}`); }
  function ownsCharacter(name, killerMode){return (killerMode?ownedKillers:ownedSurvivors).has(name);}
  function purchaseOrSelect(name, killerMode, index){
    const owned=killerMode?ownedKillers:ownedSurvivors, prices=killerMode?killerPrices:survivorPrices, price=prices[name]||0;
    if(!owned.has(name)){
      if(money<price){showToast(`Dinheiro insuficiente! Faltam ${price-money}.`);return false;}
      money-=price;owned.add(name);saveEconomy();updateMoneyUI();showToast(`${name} comprado!`);
    }
    if(killerMode)selected=index;else selectedSurvivor=name;
    buildSelection();updateMoneyUI();return true;
  }
  let selected = 0, running = false, ended = false, lastTime = 0, elapsed = 0, timeLeft = MATCH_SECONDS, lastSurvivorMinuteStarted = false;
  let gameMode="killer", selectedSurvivor="Palhaço", playerSurvivor=null, aiAttackCooldown=0, aiAttackDelay=0, aiHitbox=null, killerPath=[], killerPathIndex=0, killerPathTimer=0, aiM1FreezeTimer=0;
  let killer = null, survivors = [], obstacles = [], particles = [], keys = new Set(), attackCooldown = 0, attackFlash = 0, attackDelay = 0, activeHitbox = null, camera = {x:0,y:0}, toastTimer = 0;
  const stabDash = { cooldown:0, phase:"", timer:0, traveled:0, x:1, y:0, trail:0 };
  const wesleyDash = { cooldown:0, phase:"", timer:0, traveled:0, x:1, y:0, trail:0, hitIds:new Set(), maxDistance:437, speed:680 };
  const hackerHand = {
    cooldown:0, phase:"", x:0, y:0, dirX:1, dirY:0,
    traveled:0, range:780, speed:578, returnSpeed:780, targetId:null, hit:false
  };
  const jjBlast = { cooldown:0, phase:"", timer:0, radius:155, explosionTimer:0 };
  const sixerH1 = { cooldown:0, phase:"", timer:0, traveled:0, dirX:1, dirY:0, targetId:null, hitCount:0, hitTimer:0, hitboxTimer:0, dashDistance:1000, dashSpeed:700 };
  const sixerH2 = { cooldown:0, phase:"", timer:0, dirX:1, dirY:0, traveled:0, waveX:0, waveY:0, waveRadius:34, hitIds:new Set(), jumpY:0 };
  const skeletonH1 = {cooldown:0, phase:"", timer:0, dirX:1, dirY:0, targetId:null, hitIds:new Set(), hitboxTime:0, dashTravel:0};
  const skeletonH2 = {cooldown:0, phase:"", timer:0, x:0, y:0, dirX:1, dirY:0, traveled:0, hitIds:new Set()};
  let skeletonSlowTimer=0, skeletonH2SlowTimer=0, skeletonImmobilized=0, skeletonAbilityLockout=0;
  let dpr = 1, viewW = 800, viewH = 500;
  const touch = {x:0,y:0,sprint:false,attack:false};
  let joyActive = false, joyCenter = {x:0,y:0};
  const HITBOX_TURN_DELAY = 0.12;
  const clamp = (v,a,b)=>Math.max(a,Math.min(b,v));
  const dist = (a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
  const rand = (a,b)=>a+Math.random()*(b-a);
  
  function touchesSurvivor(s, x, y, attackRadius = 0) {
  return s.alive &&
    Math.hypot(s.x - x, s.y - y) <= s.r + attackRadius;
}

  function silhouetteSVG(index, accent) {
    const shapes = [
      '<path class="body" d="M28 40 L20 62 L25 95 L17 126 L39 126 L43 91 L48 91 L53 126 L75 126 L66 93 L72 61 L62 40 Z"/><path class="body" d="M27 17 Q45 1 63 17 L66 40 L24 40 Z"/><path class="detail" d="M28 25 L40 29 L34 34 Z M51 29 L62 25 L56 34 Z"/><path class="detail" d="M43 40 L48 40 L46 64 Z"/><path class="body" d="M22 47 L5 76 L14 82 L32 60 M65 47 L84 71 L77 79 L59 61"/>',
      '<path class="body" d="M23 39 L15 65 L23 98 L18 126 L42 126 L46 93 L51 93 L58 126 L81 126 L68 92 L74 64 L65 39 Z"/><path class="body" d="M25 18 Q44 4 65 18 L67 41 L23 41 Z"/><path class="detail" d="M29 28 L39 29 L34 34 Z M51 29 L61 28 L56 34 Z"/><path class="body" d="M23 45 L2 70 L11 80 L34 59 M66 45 L86 72 L77 81 L58 60"/><path class="detail" d="M42 45 L49 45 L47 70 Z"/>',
      '<path class="body" d="M31 39 L24 63 L29 96 L24 125 L42 125 L46 91 L51 91 L57 125 L75 125 L65 94 L69 63 L62 39 Z"/><path class="body" d="M28 17 L64 17 L67 41 L24 41 Z"/><path class="detail" d="M29 25 L61 25 L61 30 L29 30 Z M34 34 L56 34 L56 37 L34 37 Z"/><path class="body" d="M25 46 L7 71 L13 77 L34 59 M64 46 L83 70 L77 77 L57 59"/>',
      '<path class="body" d="M27 41 L19 66 L25 96 L19 125 L40 125 L45 92 L50 92 L55 125 L76 125 L67 94 L72 64 L63 41 Z"/><path class="body" d="M29 15 Q45 7 62 15 L67 41 L24 41 Z"/><path class="detail" d="M29 24 L42 30 L33 34 Z M61 24 L48 30 L57 34 Z"/><path class="detail" d="M40 40 L52 40 L46 57 Z"/><path class="body" d="M24 46 L7 75 L15 81 L35 59 M65 46 L83 72 L75 80 L58 59"/>',
      '<path class="body" d="M27 40 L18 64 L26 98 L21 125 L43 125 L46 91 L51 91 L58 125 L78 125 L67 94 L73 63 L63 40 Z"/><path class="body" d="M26 17 Q45 2 64 17 L67 41 L23 41 Z"/><path class="detail" d="M29 26 L41 29 L34 35 Z M51 29 L62 26 L56 35 Z"/><path class="detail" d="M39 39 L52 39 L46 58 Z"/><path class="body" d="M23 46 L5 70 L14 81 L34 60 M66 46 L84 72 L76 81 L58 60"/>'
    ];
    return `<svg class="silhouette" viewBox="0 0 90 135" aria-hidden="true"><style>.body{fill:#0b0d12;stroke:${accent};stroke-width:2.4;stroke-linejoin:round}.detail{fill:${accent}}</style>${shapes[index]}</svg>`;
  }

  function buildSelection() {
    const grid = $("killerGrid"); grid.innerHTML = "";
    killers.forEach((k,i)=>{
      const card = document.createElement("button");
      const owned=ownedKillers.has(k.name),price=killerPrices[k.name]||0;
      card.className = "killer-card" + (i===selected?" selected":"") + (!owned?" locked":"");
      card.innerHTML = `<div class="killer-art ${k.key}-art"><span class="initial">0${i+1}</span><img class="killer-card-image" src="${k.image}" alt="Visual de ${k.name}"><span class="card-check">✓</span></div><div class="card-copy"><h3>${k.name}</h3><p>${k.desc}</p><div class="card-stat"><span>${k.role}</span><span>${owned?(price===0?"GRÁTIS":"DESBLOQUEADO"):`🔒 ${price} Dinheiro`}</span></div></div>`;
      card.addEventListener("click",()=>{if(purchaseOrSelect(k.name,true,i)){buildSelection();updateSelectedInfo();}});
      grid.appendChild(card);
    });
    updateSelectedInfo();
  }
  function setGameMode(mode){
    gameMode=mode;
    const killerMode=mode==="killer";
    $("killerModeButton").classList.toggle("active",killerMode);$("survivorModeButton").classList.toggle("active",!killerMode);
    $("selectionTitle").textContent=killerMode?"Selecione um Killer":"Selecione um Survivor";
    $("selectedEyebrow").textContent=killerMode?"KILLER SELECIONADO":"SURVIVOR SELECIONADO";
    $("startButton").innerHTML=killerMode?'INICIAR PARTIDA <span>▶</span>':'JOGAR COMO SURVIVOR <span>▶</span>';
    const grid=$("killerGrid");grid.innerHTML="";
    const list=killerMode?killers:survivorNames.map(name=>({name,key:name,image:survivorImages[name],desc:"Survivor jogável",hp:(survivorStats[name]||{hp:100}).hp,speed:(survivorStats[name]||{speed:145}).speed,sprint:(survivorStats[name]||{sprint:165}).sprint,stamina:(survivorStats[name]||{stamina:100}).stamina,color:"#58d39b",size:60}));
    list.forEach((item,i)=>{const card=document.createElement("button");card.type="button";const owned=ownsCharacter(item.name,killerMode),price=(killerMode?killerPrices:survivorPrices)[item.name]||0;card.className="killer-card"+((killerMode?i===selected:item.name===selectedSurvivor)?" selected":"")+(!owned?" locked":"");card.innerHTML=`<div class="killer-art ${item.key}-art"><img class="killer-card-image" src="${item.image}" alt="${item.name}"><span class="card-check">✓</span></div><div class="card-copy"><h3>${item.name}</h3><p>${item.desc}</p><div class="card-stat"><span>${owned?(price===0?"GRÁTIS":"DESBLOQUEADO"):"BLOQUEADO"}</span><span>${owned?"✓":`🔒 ${price} Dinheiro`}</span></div></div>`;card.addEventListener("click",()=>{if(killerMode){if(purchaseOrSelect(item.name,true,i))updateSelectedInfo();}else{if(purchaseOrSelect(item.name,false,i)){setGameMode("survivor");updateSurvivorSelectionInfo();}}});grid.appendChild(card);});
    if(killerMode)updateSelectedInfo();else updateSurvivorSelectionInfo();updateMoneyUI();
  }
  function updateSurvivorSelectionInfo(){const name=selectedSurvivor,st=survivorStats[name]||{hp:100,speed:145,sprint:165,stamina:100};$("selectedName").textContent=name;$("selectedDescription").textContent=`HP ${st.hp} • Speed ${st.speed} • Sprint ${st.sprint} • Stamina ${st.stamina}`;$("selectedInitial").textContent="";$("selectedPortrait").className="selected-portrait";$("selectedPortrait").style.backgroundImage=`url("${survivorImages[name]}")`;}
  function updateSelectedInfo(){
    const k=killers[selected];
    $("selectedName").textContent=k.name;
    $("selectedDescription").textContent=`${k.desc} HP ${k.hp} • Speed ${k.speed} • Sprint ${k.sprint} • Stamina ${k.stamina}`;
    $("selectedInitial").textContent="";
    $("selectedPortrait").className=`selected-portrait ${k.key}-art`;
    $("selectedPortrait").style.backgroundImage=`url("${k.image}")`;
  }
  function resizeCanvas(){
    const rect=canvas.getBoundingClientRect();
    dpr=Math.min(window.devicePixelRatio||1,2);
    viewW=Math.max(320,rect.width); viewH=Math.max(280,rect.height);
    canvas.width=Math.floor(viewW*dpr);canvas.height=Math.floor(viewH*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  
  function chooseMap(){
    const roll = Math.random();
    currentMap = roll < 1/3 ? "original" : roll < 2/3 ? "estacao" : "halloween";
    WORLD.w = currentMap === "halloween" ? 1800 : 1500;
    WORLD.h = currentMap === "halloween" ? 1300 : 1050;
    halloweenDecor = [];
    if(currentMap === "halloween"){
      halloweenDecor.push({type:"statue",x:WORLD.w/2,y:WORLD.h/2,w:140,h:180});
      const pumpkins = [[270,210],[430,280],[690,180],[1090,230],[1460,210],[260,540],[470,820],[720,1030],[1080,1000],[1450,810],[1570,490],[930,390],[360,1100],[1390,1110]];
      pumpkins.forEach(([x,y],i)=>halloweenDecor.push({type:"pumpkin",x,y,w:52+(i%3)*6,h:52+(i%3)*6}));
      const ghosts = [[330,420,0],[570,610,1],[780,330,0],[1030,600,1],[1290,380,0],[1500,650,1],[540,960,0],[1200,970,1]];
      ghosts.forEach(([x,y,v],i)=>halloweenDecor.push({type:v===0?"ghost1":"ghost2",x,y,w:64,h:78,phase:i*1.7,baseY:y}));
    }
  }
  
  
function makeObstacles(){
  obstacles=[];

  // Bordas do mapa
  obstacles.push(
    {x:0,y:0,w:WORLD.w,h:35},
    {x:0,y:WORLD.h-35,w:WORLD.w,h:35},
    {x:0,y:0,w:35,h:WORLD.h},
    {x:WORLD.w-35,y:0,w:35,h:WORLD.h}
  );

  let blocks;

  if(currentMap === "halloween") {
    // Passagens e corredores sinuosos com uma praça central livre para a estátua.
    blocks = [
      [130,150,280,52],[350,202,52,145],[520,125,52,230],[610,180,220,52],
      [900,130,52,190],[1030,210,270,52],[1320,160,52,180],[1450,280,190,52],
      [140,400,52,220],[250,500,240,52],[540,390,52,180],[660,470,210,52],
      [940,390,52,190],[1060,510,230,52],[1350,440,52,200],[1480,590,190,52],
      [150,760,250,52],[430,690,52,190],[540,810,220,52],[820,720,52,180],
      [930,840,250,52],[1230,740,52,190],[1350,900,230,52],[600,1080,220,52]
    ];
  }else if(currentMap === "estacao"){
    // A Estação do Fim: laboratórios e salas de pesquisa
    // Mapa 2: Estação do Fim. Layout em zigue-zague, com salas
    // deslocadas e corredores alternados para não repetir o mapa original.
    blocks=[
      [110,150,300,58], [180,208,58,150], [330,265,250,58],
      [500,110,58,155], [690,125,300,58], [925,183,58,170],
      [1080,245,240,58], [1260,303,58,130],
      [100,430,240,58], [282,488,58,170], [390,570,250,58],
      [600,390,58,180], [720,360,240,58], [900,418,58,190],
      [1010,570,300,58], [1180,628,58,140],
      [100,730,300,58], [350,788,58,125], [500,850,250,58],
      [760,700,58,150], [820,790,250,58], [1010,850,58,90],
      [620,560,150,48], [70,300,48,90]
    ];
  }else{
    // Mapa original
    blocks=[
      [220,170,170,65],[510,105,70,175],
      [770,170,210,58],[1110,125,150,75],
      [120,400,85,180],[330,365,220,60],
      [670,360,95,180],[910,390,185,65],
      [1160,420,160,155],[250,690,180,70],
      [520,650,75,175],[800,690,210,65],
      [1110,760,190,65],[410,885,170,55],
      [920,900,90,80]
    ];
  }

  blocks.forEach(([x,y,w,h])=>{
    obstacles.push({x,y,w,h});
  });
}

  function collides(x,y,r){
    return obstacles.some(o=>x+r>o.x&&x-r<o.x+o.w&&y+r>o.y&&y-r<o.y+o.h);
  }
  function hasLineOfSight(a,b){
    const dx=b.x-a.x,dy=b.y-a.y,distance=Math.hypot(dx,dy);
    const steps=Math.max(1,Math.ceil(distance/12));
    for(let i=1;i<steps;i++){
      const t=i/steps;
      if(collides(a.x+dx*t,a.y+dy*t,2))return false;
    }
    return true;
  }
  
  
function survivorCollides(x, y, r = 16) {
  // Hitbox física independente do tamanho visual do Survivor.
  return collides(x, y, Math.min(r, 12));
}

  
  
function moveEntity(e, dx, dy, r) {
    const isSurvivor = survivors.includes(e);
    // Não altere e.r/e.size: eles controlam o desenho. Só a colisão usa hitboxR.
    const hitbox = isSurvivor ? (e.hitboxR || 12) : r;

    if (!collides(e.x + dx, e.y, hitbox)) e.x += dx;
    if (!collides(e.x, e.y + dy, hitbox)) e.y += dy;

    e.x = clamp(e.x, hitbox, WORLD.w - hitbox);
    e.y = clamp(e.y, hitbox, WORLD.h - hitbox);
}

  
  
function resolveKillerSurvivorCollision() {
  if (!killer) return;

  for (const s of survivors) {
    if (!s.alive) continue;

    const dx = s.x - killer.x;
    const dy = s.y - killer.y;
    const distance = Math.hypot(dx, dy);
    const minDistance = killer.r + s.r;

    if (distance < minDistance) {
      const angle = distance > 0
        ? Math.atan2(dy, dx)
        : Math.random() * Math.PI * 2;

      const overlap = minDistance - distance;
      const pushX = Math.cos(angle) * overlap;
      const pushY = Math.sin(angle) * overlap;

      const newSX = s.x + pushX;
      const newSY = s.y + pushY;

      if (!collides(newSX, s.y, s.r)) s.x = newSX;
      if (!collides(s.x, newSY, s.r)) s.y = newSY;
    }
  }
}

  
  // Se uma habilidade ou uma posição inválida deixar alguém dentro de um bloco,
  // procura uma posição livre próxima e desloca o personagem para fora.
  function pushOutOfWall(e,r){
    if(!e||!Number.isFinite(e.x)||!Number.isFinite(e.y)||!collides(e.x,e.y,r))return false;
    const startX=e.x,startY=e.y;
    const maxDistance=325,step=5;
    for(let distance=step;distance<=maxDistance;distance+=step){
      for(let i=0;i<32;i++){
        const angle=(Math.PI*2*i)/32;
        const x=clamp(startX+Math.cos(angle)*distance,r,WORLD.w-r);
        const y=clamp(startY+Math.sin(angle)*distance,r,WORLD.h-r);
        if(!collides(x,y,r)){
          e.x=x;e.y=y;
          return true;
        }
      }
    }
    // Plano de segurança: procura uma posição livre em uma grade pelo mapa.
    let nearest=null,nearestDistance=Infinity;
    for(let y=r+35;y<WORLD.h-r-35;y+=20){
      for(let x=r+35;x<WORLD.w-r-35;x+=20){
        const d=Math.hypot(x-startX,y-startY);
        if(d<nearestDistance&&!collides(x,y,r)){nearest={x,y};nearestDistance=d;}
      }
    }
    if(nearest){e.x=nearest.x;e.y=nearest.y;return true;}
    return false;
  }
  function recoverEntitiesFromWalls(){
    if(killer)pushOutOfWall(killer,killer.r);
    for(const s of survivors){if(s.alive)pushOutOfWall(s,s.hitboxR||12);}
  }
  // A* em uma grade invisível: os Survivors planejam um caminho pelos corredores
  // e consideram a hitbox deles, não apenas o centro do personagem.
  const PATH_CELL=35;
  function findSurvivorPath(s, goalX, goalY){
    const cols=Math.ceil(WORLD.w/PATH_CELL), rows=Math.ceil(WORLD.h/PATH_CELL);
    const toCell=(x,y)=>({x:clamp(Math.floor(x/PATH_CELL),0,cols-1),y:clamp(Math.floor(y/PATH_CELL),0,rows-1)});
    const start=toCell(s.x,s.y), goal=toCell(goalX,goalY);
    const key=(x,y)=>y*cols+x;
    const blocked=new Uint8Array(cols*rows);
    for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){
      const cx=x*PATH_CELL+PATH_CELL/2, cy=y*PATH_CELL+PATH_CELL/2;
      if(collides(cx,cy,(s.hitboxR||12)+5))blocked[key(x,y)]=1;
    }
    blocked[key(start.x,start.y)]=0;
    // Se o ponto-alvo caiu dentro de um obstáculo, procura a célula livre mais próxima.
    if(blocked[key(goal.x,goal.y)]){
      let best=null,bd=Infinity;
      for(let y=0;y<rows;y++)for(let x=0;x<cols;x++)if(!blocked[key(x,y)]){
        const dd=(x-goal.x)**2+(y-goal.y)**2;if(dd<bd){bd=dd;best={x,y};}
      }
      if(best){goal.x=best.x;goal.y=best.y;}
    }
    const startK=key(start.x,start.y),goalK=key(goal.x,goal.y);
    const open=[{x:start.x,y:start.y,g:0,f:Math.abs(goal.x-start.x)+Math.abs(goal.y-start.y)}];
    const came=new Int32Array(cols*rows);came.fill(-1);
    const costs=new Float32Array(cols*rows);costs.fill(Infinity);costs[startK]=0;
    const closed=new Uint8Array(cols*rows);
    const dirs=[[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
    let found=false, iterations=0;
    while(open.length&&iterations++<cols*rows*3){
      let bi=0;for(let i=1;i<open.length;i++)if(open[i].f<open[bi].f)bi=i;
      const cur=open.splice(bi,1)[0], ck=key(cur.x,cur.y);
      if(closed[ck])continue;closed[ck]=1;
      if(ck===goalK){found=true;break;}
      for(const [dx,dy] of dirs){
        const nx=cur.x+dx,ny=cur.y+dy;if(nx<0||ny<0||nx>=cols||ny>=rows)continue;
        const nk=key(nx,ny);if(blocked[nk]||closed[nk])continue;
        // Impede cortar diagonalmente pela quina de dois obstáculos.
        if(dx&&dy&&(blocked[key(cur.x+dx,cur.y)]||blocked[key(cur.x,cur.y+dy)]))continue;
        const ng=costs[ck]+(dx&&dy?1.414:1);
        if(ng<costs[nk]){costs[nk]=ng;came[nk]=ck;const h=Math.hypot(goal.x-nx,goal.y-ny);open.push({x:nx,y:ny,g:ng,f:ng+h});}
      }
    }
    if(!found)return [];
    const path=[];let at=goalK;
    while(at!==startK&&at>=0){path.push({x:(at%cols)*PATH_CELL+PATH_CELL/2,y:Math.floor(at/cols)*PATH_CELL+PATH_CELL/2});at=came[at];}
    path.reverse();return path;
  }
  function setSurvivorGoal(s,x,y){
    s.goalX=clamp(x,105,WORLD.w-105);s.goalY=clamp(y,105,WORLD.h-105);
    s.goalX=clamp(x,180,WORLD.w-180);s.goalY=clamp(y,180,WORLD.h-180);
    s.path=findSurvivorPath(s,s.goalX,s.goalY);s.pathIndex=0;s.pathTimer=.55;
  }
  function spawnSurvivor(i, chosenName=null){
    let x,y,tries=0;
    do{x=rand(100,WORLD.w-100);y=rand(100,WORLD.h-100);tries++}while((collides(x,y,12)||(killer&&Math.hypot(x-killer.x,y-killer.y)<300))&&tries<100);
    const name=chosenName || survivorNames[i];
    const stats=survivorStats[name] || {hp:100,speed:rand(145,165),sprint:165,stamina:100};
    const survivorSpeed=stats.speed;
    return {
  id: i,
  name,
  x,
  y,
  size: 60,
  get r() { return this.size / 2; },hp:stats.hp,maxHp:stats.hp,speed:survivorSpeed,baseSpeed:survivorSpeed,sprintSpeed:stats.sprint,baseSprintSpeed:stats.sprint,stamina:stats.stamina,maxStamina:stats.stamina,staminaExhausted:false,speedBoost:0,dodgeTimer:0,alive:true,angle:0,think:rand(.1,.8),wander:rand(0,Math.PI*2),hurt:0,panic:0,stuck:0,lastX:x,lastY:y,goalX:x,goalY:y,path:[],pathIndex:0,pathTimer:0,skill1Cd:0,skill2Cd:0,clownTimer:0,healerTimer:0,ghostTimer:0,defenseTimer:0,punchTimer:0,actionLockTimer:0,healBuffTimer:0,damageReductionTimer:0,hitIds:new Set()};
  }
  function survivorTakesDamage(s,amount){
    // A defesa do CowardlyPuncher bloqueia qualquer dano recebido, inclusive habilidades.
    if(s && s.defenseTimer>0){
      s.defenseTimer=0;
      if(s.defenseBaseSpeed){s.speed=s.defenseBaseSpeed;s.defenseBaseSpeed=0;}
      killer.stunTimer=Math.max(killer.stunTimer||0,.65);
      if(s.isPlayer&&gameMode==="survivor")addMoney(4,"defesa acertada");
      const push=Math.atan2(killer.y-s.y,killer.x-s.x);
      if(gameMode==="survivor")moveEntity(killer,Math.cos(push)*65,Math.sin(push)*65,killer.r);
      showToast("Ataque bloqueado pela defesa!");
      return false;
    }
    s.hp-=amount;s.speedBoost=.55;s.panic=2.5;return true;
  }
  function updateSurvivorSkillButtons(){
    const s=playerSurvivor; const mode=gameMode==="survivor"&&!!s;
    const b1=$("skillTouch"),b2=$("skill2Touch");
    if(!mode){return;}
    const labels={"Palhaço":["H1<br>CONFETE"],"Healer":["H1<br>CURA"],"cowardlypuncher":["H1<br>DEFESA","H2<br>SOCO"],"GhostGirl":["H1<br>INVISÍVEL"],"Dummy":["H1<br>SEM HABILIDADE"]};
    const arr=labels[s.name]||["H1<br>HABILIDADE"];
    b1.innerHTML=arr[0];b1.classList.remove("hidden");
    if(arr[1]){b2.innerHTML=arr[1];b2.classList.remove("hidden");}else b2.classList.add("hidden");
    b1.classList.toggle("cooldown",s.skill1Cd>0);b2.classList.toggle("cooldown",s.skill2Cd>0);
  }
  function activateSurvivorSkill(slot, s=playerSurvivor){
    if(!s||!s.alive)return;
    if(!s.isPlayer){s.angle=Math.atan2(killer.y-s.y,killer.x-s.x);}
    if(slot===1&&s.skill1Cd>0||slot===2&&s.skill2Cd>0)return;
    const near=Math.hypot(killer.x-s.x,killer.y-s.y);
    if(s.name==="Palhaço"&&slot===1){s.actionLockTimer=.4;s.clownTimer=.65;s.clownDelay=.2;s.skill1Cd=17;s.hitIds=new Set();s.clownHitbox={angle:s.angle||0,range:88,width:72,hit:false};skillSpark(s.x,s.y,"#ffcc47",18,170);showToast("Palhaço: Confete!");}
    else if(s.name==="Healer"&&slot===1){if(s.isPlayer&&gameMode==="survivor")addMoney(1,"habilidade da Healer");s.healerTimer=4;s.skill1Cd=20;skillSpark(s.x,s.y,"#53f28c",18,140);showToast("Healer: área de cura!");}
    else if(s.name==="cowardlypuncher"&&slot===1){s.defenseTimer=1;s.defenseBaseSpeed=s.speed;s.speed=Math.max(20,s.speed-100);s.skill1Cd=18;skillSpark(s.x,s.y,"#4bbcff",14,100);showToast("CowardlyPuncher: defesa!");}
    else if(s.name==="cowardlypuncher"&&slot===2){s.actionLockTimer=.35;s.punchTimer=.52;s.punchDelay=.35;s.skill2Cd=13;s.hitIds=new Set();s.punchHitbox={angle:s.angle||0,range:76,width:62,hit:false};showToast("CowardlyPuncher: preparando soco!");}
    else if(s.name==="GhostGirl"&&slot===1){if(s.isPlayer&&gameMode==="survivor"&&near<=180)addMoney(3,"GhostGirl escapando da perseguição");s.ghostTimer=2.45;s.skill1Cd=15;skillSpark(s.x,s.y,"#b6a7ff",16,130);showToast("GhostGirl: invisibilidade!");}
    else if(s.name==="Dummy"){showToast("Dummy não tem habilidades.");}
  }
  function updateSurvivorAbilities(dt){
    for(const s of survivors){
      if(!s.alive)continue;
      s.skill1Cd=Math.max(0,(s.skill1Cd||0)-dt);s.skill2Cd=Math.max(0,(s.skill2Cd||0)-dt);
      s.actionLockTimer=Math.max(0,(s.actionLockTimer||0)-dt);s.clownTimer=Math.max(0,(s.clownTimer||0)-dt);s.clownDelay=Math.max(0,(s.clownDelay||0)-dt);s.punchDelay=Math.max(0,(s.punchDelay||0)-dt);s.healerTimer=Math.max(0,(s.healerTimer||0)-dt);s.ghostTimer=Math.max(0,(s.ghostTimer||0)-dt);const wasDefending=s.defenseTimer>0;s.defenseTimer=Math.max(0,(s.defenseTimer||0)-dt);if(wasDefending&&s.defenseTimer<=0&&s.defenseBaseSpeed){s.speed=s.defenseBaseSpeed;s.defenseBaseSpeed=0;}s.punchTimer=Math.max(0,(s.punchTimer||0)-dt);s.healBuffTimer=Math.max(0,(s.healBuffTimer||0)-dt);s.damageReductionTimer=Math.max(0,(s.damageReductionTimer||0)-dt);
      // Healer's field benefits every Survivor who enters it, including the Healer.
      for(const h of survivors){if(h.alive&&h.healerTimer>0&&dist(s,h)<105){s.hp=Math.min(s.maxHp,s.hp+2*dt);s.healBuffTimer=.2;s.damageReductionTimer=.2;s.speed=s.baseSpeed+50;s.sprintSpeed=(s.baseSprintSpeed||s.sprintSpeed)+50;}}
      if(s.healBuffTimer<=0){s.sprintSpeed=s.baseSprintSpeed||s.sprintSpeed;s.speed=s.baseSpeed+(s.speedBoost>0?90:0);}
      // Habilidades ofensivas usam hitbox retangular à frente, ligeiramente sobreposta ao próprio personagem.
      const hitSkillBox=(skill,delay)=>{
        if(!skill||delay>0||!skill.range||skill.hit)return false;
        const a=skill.angle,ux=Math.cos(a),uy=Math.sin(a),cx=s.x+ux*(skill.range/2-8),cy=s.y+uy*(skill.range/2-8);
        const rx=killer.x-cx,ry=killer.y-cy,along=rx*ux+ry*uy,across=-rx*uy+ry*ux;
        if(along>=-killer.r&&along<=skill.range/2+killer.r&&Math.abs(across)<=skill.width/2+killer.r){skill.hit=true;return true;}
        return false;
      };
      if(s.name==="Palhaço"&&s.clownTimer>0&&hitSkillBox(s.clownHitbox,s.clownDelay)){if(s.isPlayer&&gameMode==="survivor")addMoney(5,"habilidade acertada");s.hitIds.add("killer");aiM1FreezeTimer=Math.max(aiM1FreezeTimer,1.35);killer.stunTimer=Math.max(killer.stunTimer||0,1.35);burst(killer.x,killer.y,"#ffcf4a",22);showToast("Killer atordoado pelo Palhaço!");}
      if(s.name==="cowardlypuncher"&&s.punchTimer>0&&hitSkillBox(s.punchHitbox,s.punchDelay)){s.hitIds.add("killer");killer.stunTimer=Math.max(killer.stunTimer||0,1.2);killer.hp=Math.max(0,killer.hp-20);burst(killer.x,killer.y,"#8bdcff",16);s.punchTimer=0;showToast("Soco acertou: -20 HP!");}
      // Bots choose abilities when the Killer approaches or allies need healing.
      if(!s.isPlayer){
        const d=dist(s,killer);const hurtAlly=survivors.some(a=>a.alive&&a.hp<a.maxHp-8&&dist(a,s)<100);
        if(s.name==="Palhaço"&&d<85&&s.skill1Cd<=0)activateSurvivorSkill(1,s);
        if(s.name==="Healer"&&(hurtAlly||d<170)&&s.skill1Cd<=0)activateSurvivorSkill(1,s);
        if(s.name==="cowardlypuncher"&&d<75&&s.skill1Cd<=0)activateSurvivorSkill(1,s);
        if(s.name==="cowardlypuncher"&&d<65&&s.skill2Cd<=0)activateSurvivorSkill(2,s);
        if(s.name==="GhostGirl"&&d<180&&s.skill1Cd<=0)activateSurvivorSkill(1,s);
      }
    }
    updateSurvivorSkillButtons();
  }
  function nearEntity(a,b,r){return Math.hypot(a.x-b.x,a.y-b.y)<=r;}
  function startSurvivorGame(){
    const k=killers[Math.floor(Math.random()*killers.length)];
    selected=killers.indexOf(k);playerSurvivor=null;survivors=[];killer={x:WORLD.w/2,y:WORLD.h/2,r:17,size:k.size,hp:k.hp,maxHp:k.hp,speed:k.speed,sprintSpeed:k.sprint,angle:0,facingX:-1,facingY:0,facing:0,stamina:k.stamina,maxStamina:k.stamina,staminaExhausted:false};
    chooseMap();makeObstacles();
    const pool=[...survivorNames].filter(n=>n!==selectedSurvivor).sort(()=>Math.random()-.5).slice(0,4);const names=[selectedSurvivor,...pool];
    names.forEach((name,i)=>{const s=spawnSurvivor(i,name);s.isPlayer=i===0;if(i===0){s.x=WORLD.w/2-220;s.y=WORLD.h/2;playerSurvivor=s;}survivors.push(s);});
    killer.x=WORLD.w/2+150;killer.y=WORLD.h/2+100;
    aiAttackCooldown=0;aiAttackDelay=0;aiHitbox=null;killerPath=[];killerPathIndex=0;killerPathTimer=0;aiM1FreezeTimer=0;particles=[];elapsed=0;timeLeft=MATCH_SECONDS;lastSurvivorMinuteStarted=false;attackCooldown=0;attackFlash=0;attackDelay=0;activeHitbox=null;touch.sprint=false;keys.clear();running=true;ended=false;lastTime=performance.now();
    $("hudRoleLabel").textContent="KILLER INIMIGO";$("hudKillerName").textContent=k.name;$("hudInitial").textContent="";$("hudPortrait").className=`hud-portrait ${k.key}-art`;$("hudPortrait").style.backgroundImage=`url("${k.image}")`;
    $("killerHealthBar").style.width="100%";$("killerHealthText").textContent=`${k.hp} / ${k.hp}`;$("objectiveText").textContent="Sobreviva até o tempo acabar";$("timer").textContent="04:00";$("endOverlay").classList.add("hidden");$("toast").classList.add("hidden");$("skillTouch").classList.remove("hidden");$("skill2Touch").classList.add("hidden");$("attackTouch").classList.add("hidden");
    selectScreen.classList.add("hidden");gameScreen.classList.remove("hidden");resizeCanvas();updateSurvivorHud();updateSurvivorSkillButtons();showToast(`${selectedSurvivor}: sobreviva ao ${k.name}!`);requestAnimationFrame(loop);
  }
  function updateSurvivorMode(dt){
    if(!playerSurvivor||!playerSurvivor.alive){finish(false,"Você foi eliminado pelo Killer.");return;}
    const k=killers[selected];elapsed+=dt;timeLeft=Math.max(0,MATCH_SECONDS-elapsed);updateSurvivorAbilities(dt);
    updateStabDash(dt);updateWesleyDash(dt);updateHackerHand(dt);updateJJBlast(dt);updateSixerH1(dt);updateSixerH2(dt);updateSkeletonH1(dt);updateSkeletonH2(dt);
    aiAttackCooldown=Math.max(0,aiAttackCooldown-dt);aiAttackDelay=Math.max(0,aiAttackDelay-dt);aiM1FreezeTimer=Math.max(0,aiM1FreezeTimer-dt);
    let dx=(keys.has("d")||keys.has("arrowright")?1:0)-(keys.has("a")||keys.has("arrowleft")?1:0)+touch.x,dy=(keys.has("s")||keys.has("arrowdown")?1:0)-(keys.has("w")||keys.has("arrowup")?1:0)+touch.y;let m=Math.hypot(dx,dy);if(m>1){dx/=m;dy/=m;}
    playerSurvivor.speedBoost=Math.max(0,(playerSurvivor.speedBoost||0)-dt);playerSurvivor.speed=playerSurvivor.baseSpeed+(playerSurvivor.speedBoost>0?90:0);const sprintRequested=(keys.has("shift")||touch.sprint)&&m>.1;if(playerSurvivor.staminaExhausted&&playerSurvivor.stamina>=playerSurvivor.maxStamina)playerSurvivor.staminaExhausted=false;const sprint=sprintRequested&&!playerSurvivor.staminaExhausted&&playerSurvivor.stamina>0;const sp=sprint?playerSurvivor.sprintSpeed:playerSurvivor.speed;if(sprint){playerSurvivor.stamina=Math.max(0,playerSurvivor.stamina-28*dt);if(playerSurvivor.stamina<=0)playerSurvivor.staminaExhausted=true;}else playerSurvivor.stamina=Math.min(playerSurvivor.maxStamina,playerSurvivor.stamina+19*dt);if(m>.1){playerSurvivor.angle=Math.atan2(dy,dx);if(!(playerSurvivor.actionLockTimer>0||(sixerH1.phase==="combo"&&sixerH1.targetId===playerSurvivor.id)))moveEntity(playerSurvivor,dx*sp*dt,dy*sp*dt,playerSurvivor.r);}
    // Os outros quatro Survivors seguem o comportamento de fuga já existente.
    survivors.forEach(s=>{if(s===playerSurvivor||!s.alive)return;s.think-=dt;s.hurt=Math.max(0,s.hurt-dt);s.panic=Math.max(0,s.panic-dt);s.pathTimer-=dt;const d=dist(s,killer);if(s.think<=0||d<220||s.pathTimer<=0||!s.path.length||s.pathIndex>=s.path.length){const a=Math.atan2(s.y-killer.y,s.x-killer.x);let chosen=false;for(let attempt=0;attempt<8&&!chosen;attempt++){const ang=a+rand(-.8,.8),len=rand(220,360);setSurvivorGoal(s,s.x+Math.cos(ang)*len,s.y+Math.sin(ang)*len);chosen=s.path.length>0;}s.think=rand(.45,.8);}let wp=s.path[s.pathIndex];if(wp&&Math.hypot(wp.x-s.x,wp.y-s.y)<18){s.pathIndex++;wp=s.path[s.pathIndex];}let ax=wp?wp.x-s.x:s.goalX-s.x,ay=wp?wp.y-s.y:s.goalY-s.y,am=Math.hypot(ax,ay);s.aiM1Stun=Math.max(0,(s.aiM1Stun||0)-dt);if(am>5&&s.aiM1Stun<=0&&!(s.actionLockTimer>0)){const ox=s.x,oy=s.y;moveEntity(s,ax/am*s.speed*dt,ay/am*s.speed*dt,s.r);if(Math.hypot(s.x-ox,s.y-oy)<.1){s.path=[];s.pathTimer=0;}}});
    // Killer escolhe qualquer Survivor vivo, troca de foco quando encontra outro alvo visível e corre ao avistá-lo.
    const targets=survivors.filter(s=>s.alive);if(!targets.length){finish(true,"Todos os Survivors foram eliminados.");return;}
    const perceivedTargets=targets.filter(s=>!(s.name==="GhostGirl"&&s.ghostTimer>0));
    const visibleTargets=perceivedTargets.filter(s=>hasLineOfSight(killer,s));
    let target;
    if(visibleTargets.length){
      // Prioriza alvos que consegue ver, mas pode mudar para outro Survivor visível mais próximo.
      target=visibleTargets.reduce((a,b)=>dist(a,killer)<dist(b,killer)?a:b);
    }else{
      // Se ninguém estiver visível, procura o Survivor vivo mais próximo usando o caminho ao redor das paredes.
      if(!perceivedTargets.length){target=null;}else{target=perceivedTargets.reduce((a,b)=>dist(a,killer)<dist(b,killer)?a:b);}
    }
    const ghostOnly= !target;
    if(ghostOnly){
      // Sem alvos percebidos: a GhostGirl invisível não é seguida; o Killer fica sem alvo por enquanto.
      target={x:killer.x,y:killer.y,alive:false};
      killerPathTimer=0;
    }
    const seesTarget=!ghostOnly&&visibleTargets.includes(target);
    let tx=target.x-killer.x,ty=target.y-killer.y,d=Math.hypot(tx,ty);
    // O Killer controlado pela IA também usa suas habilidades no modo Survivor.
    if(seesTarget&&d>0){
      killer.angle=Math.atan2(ty,tx);
      // Bots podem ajustar a direção durante a preparação, mas não caminham até iniciar o dash.
      const aimX=tx/d, aimY=ty/d;
      if(selected===0&&stabDash.phase==="prepare"){stabDash.x=aimX;stabDash.y=aimY;}
      if(selected===4&&wesleyDash.phase==="prepare"){wesleyDash.x=aimX;wesleyDash.y=aimY;}
      if(selected===3&&sixerH1.phase==="prepare"){sixerH1.dirX=aimX;sixerH1.dirY=aimY;}
      if(selected===0&&d>80&&d<420&&stabDash.cooldown<=0&&!stabDash.phase)activateStabDash();
      else if(selected===1&&d<210&&jjBlast.cooldown<=0&&!jjBlast.phase)activateJJBlast();
      else if(selected===3&&d<190&&sixerH1.cooldown<=0&&!sixerH1.phase)activateSixerH1();
      else if(selected===3&&d<130&&sixerH2.cooldown<=0&&!sixerH2.phase)activateSixerH2();
      else if(selected===4&&d>65&&d<350&&wesleyDash.cooldown<=0&&!wesleyDash.phase)activateWesleyDash();
      else if(selected===5&&d<150&&skeletonH1.cooldown<=0&&!skeletonH1.phase)activateSkeletonH1(true);
      else if(selected===5&&d>80&&d<380&&skeletonH2.cooldown<=0&&!skeletonH2.phase&&skeletonAbilityLockout<=0)activateSkeletonH2();
    }
    if(killer.staminaExhausted){
      // Esgotado: não corre e recupera no ritmo normal.
      killer.stamina=Math.min(killer.maxStamina,killer.stamina+19*dt);
      if(killer.stamina>=killer.maxStamina)killer.staminaExhausted=false;
    }else if(seesTarget&&d>k.range+target.r-2&&killer.stamina>0){
      killer.stamina=Math.max(0,killer.stamina-28*dt);
      if(killer.stamina<=0)killer.staminaExhausted=true;
    }else{
      killer.stamina=Math.min(killer.maxStamina,killer.stamina+19*dt);
    }
    killer.stunTimer=Math.max(0,(killer.stunTimer||0)-dt);if(d>0){killer.angle=Math.atan2(ty,tx);killer.facingX=tx/d;killer.facingY=ty/d;
      if(aiM1FreezeTimer>0||killer.stunTimer>0){ /* Atordoado: não se move. */ }
      else if(d>k.range+target.r-2){
        const dashPreparing=(selected===0&&stabDash.phase==="prepare")||(selected===4&&wesleyDash.phase==="prepare")||(selected===3&&sixerH1.phase==="prepare");
        if(dashPreparing){ /* Imóvel durante a preparação, mas continua virando para o alvo. */ }
        else {
        killerPathTimer-=dt;
        if(killerPathTimer<=0||!killerPath.length||killerPathIndex>=killerPath.length){killerPath=findSurvivorPath(killer,target.x,target.y);killerPathIndex=0;killerPathTimer=.25;}
        let wp=killerPath[killerPathIndex];if(wp&&Math.hypot(wp.x-killer.x,wp.y-killer.y)<18){killerPathIndex++;wp=killerPath[killerPathIndex];}
        let mx=wp?wp.x-killer.x:tx,my=wp?wp.y-killer.y:ty,mm=Math.hypot(mx,my)||1;
        const chaseBase=seesTarget&&killer.stamina>0&&!killer.staminaExhausted?k.sprint:k.speed;
        const chaseSpeed=chaseBase-(selected===5&&skeletonSlowTimer>0?75:0)-(selected===5&&skeletonH2SlowTimer>0?30:0);
        moveEntity(killer,mx/mm*chaseSpeed*dt,my/mm*chaseSpeed*dt,killer.r);
        }
      }else if(aiAttackCooldown<=0&&!(selected===5&&skeletonAbilityLockout>0)){aiAttackCooldown=k.cooldown;aiAttackDelay=.15;aiHitbox={targetId:target.id,angle:killer.angle,damage:k.damages?k.damages[Math.floor(Math.random()*k.damages.length)]:k.damage,range:k.range,size:k.hitboxSize,visible:0,hitIds:new Set()};}
    }
    if(aiHitbox&&aiAttackDelay<=0){if(aiHitbox.visible===0)aiHitbox.visible=.25;aiHitbox.visible-=dt;const ux=Math.cos(aiHitbox.angle),uy=Math.sin(aiHitbox.angle),cx=killer.x+ux*(killer.r+aiHitbox.range/2-8),cy=killer.y+uy*(killer.r+aiHitbox.range/2-8);for(const s of survivors){if(!s.alive||aiHitbox.hitIds.has(s.id))continue;if(s.name==="GhostGirl"&&s.ghostTimer>0)continue;if(s.defenseTimer>0){if(s.isPlayer&&gameMode==="survivor")addMoney(4,"defesa acertada");aiHitbox.hitIds.add(s.id);s.defenseTimer=0;killer.stunTimer=Math.max(killer.stunTimer||0,.65);const push=Math.atan2(killer.y-s.y,killer.x-s.x);moveEntity(killer,Math.cos(push)*65,Math.sin(push)*65,killer.r);showToast("Ataque bloqueado!");continue;}const rx=s.x-cx,ry=s.y-cy,along=rx*ux+ry*uy,across=-rx*uy+ry*ux;if(along>=-s.r&&along<=aiHitbox.range/2+s.r&&Math.abs(across)<=aiHitbox.size/2+s.r){aiHitbox.hitIds.add(s.id);s.hp-=aiHitbox.damage*(s.damageReductionTimer>0?.82:1);s.hurt=.25;aiM1FreezeTimer=1.35;burst(s.x,s.y,k.color,8);showToast(`${s.name}: -${aiHitbox.damage} HP`);if(s.hp<=0){s.hp=0;s.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");showToast(`${s.name} foi eliminado!`);}updateSurvivorHud();} }if(aiHitbox.visible<=0)aiHitbox=null;}
    if(!lastSurvivorMinuteStarted&&survivors.filter(s=>s.alive).length===1){lastSurvivorMinuteStarted=true;elapsed=MATCH_SECONDS-60;timeLeft=60;if(gameMode==="killer")addMoney(7,"entrou na LMS");showToast("ÚLTIMO SURVIVOR! 1 minuto restante!");}
    if(timeLeft<=0){finish(true,"Você sobreviveu até o fim!");return;}$("timer").textContent=`${String(Math.floor(timeLeft/60)).padStart(2,"0")}:${String(Math.floor(timeLeft%60)).padStart(2,"0")}`;$("killerHealthBar").style.width=`${clamp(playerSurvivor.hp/playerSurvivor.maxHp*100,0,100)}%`;$("killerHealthText").textContent=`${Math.ceil(playerSurvivor.hp)} / ${playerSurvivor.maxHp}`;camera.x=clamp(playerSurvivor.x-viewW/(2*ZOOM),0,WORLD.w-viewW/ZOOM);camera.y=clamp(playerSurvivor.y-viewH/(2*ZOOM),0,WORLD.h-viewH/ZOOM);if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$("toast").classList.add("hidden");}
  }
  function startGame(){
    if(gameMode==="survivor"){startSurvivorGame();return;}
    playerSurvivor=null;
    const k=killers[selected];
    $("skillTouch").classList.toggle("hidden",selected!==0&&selected!==1&&selected!==2&&selected!==3&&selected!==4&&selected!==5);
    $("skillTouch").innerHTML=selected===1?"H1<br>BLAST":selected===2?"H1<br>BRAÇO":selected===3?"H1<br>INVESTIDA":selected===4?"H1<br>INVESTIDA":"H1<br>SHADOW";
    $("skill2Touch").classList.toggle("hidden",selected!==3&&selected!==5);
    if(selected===5){$("skillTouch").innerHTML="H1<br>CAPTURA";$("skill2Touch").innerHTML="H2<br>SOMBRA";}
    stabDash.cooldown=0;stabDash.phase="";stabDash.timer=0;stabDash.traveled=0;stabDash.trail=0;
    Object.assign(wesleyDash,{cooldown:0,phase:"",timer:0,traveled:0,x:Math.cos(killer?.angle||0),y:Math.sin(killer?.angle||0),trail:0,hitIds:new Set()});
    hackerHand.cooldown=0;hackerHand.phase="";hackerHand.traveled=0;hackerHand.targetId=null;hackerHand.hit=false;
    jjBlast.cooldown=0;jjBlast.phase="";jjBlast.timer=0;jjBlast.explosionTimer=0;
    Object.assign(sixerH1,{cooldown:0,phase:"",timer:0,traveled:0,targetId:null,hitCount:0,hitTimer:0,hitboxTimer:0});
    Object.assign(sixerH2,{cooldown:0,phase:"",timer:0,traveled:0,waveX:0,waveY:0,hitIds:new Set(),jumpY:0});
    Object.assign(skeletonH1,{cooldown:0,phase:"",timer:0,dirX:Math.cos(killer?.angle||0),dirY:Math.sin(killer?.angle||0),targetId:null,hitIds:new Set(),hitboxTime:0,dashTravel:0});
    Object.assign(skeletonH2,{cooldown:0,phase:"",timer:0,x:0,y:0,dirX:1,dirY:0,traveled:0,hitIds:new Set()});skeletonSlowTimer=0;skeletonH2SlowTimer=0;skeletonImmobilized=0;skeletonAbilityLockout=0;
    killer={x:WORLD.w/2,y:WORLD.h/2,r:17,size:k.size,hp:k.hp,maxHp:k.hp,speed:k.speed,sprintSpeed:k.sprint,angle:-Math.PI/2,facingX:0,facingY:-1,facing:0,stamina:k.stamina,maxStamina:k.stamina,staminaExhausted:false,attackRange:k.range,damage:k.damage};
    // Cada partida tem somente 6 Survivors; os personagens são sorteados sem repetição.
    const matchSurvivors = [...survivorNames].sort(() => Math.random() - 0.5).slice(0, SURVIVORS_PER_MATCH);
    survivors=[];
    matchSurvivors.forEach((name,i)=>survivors.push(spawnSurvivor(i,name)));
    particles=[];elapsed=0;timeLeft=MATCH_SECONDS;lastSurvivorMinuteStarted=false;attackCooldown=0;attackFlash=0;attackDelay=0;activeHitbox=null;touch.sprint=false;$("sprintTouch").classList.remove("active");$("sprintTouch").setAttribute("aria-pressed","false");running=true;ended=false;lastTime=performance.now();
    chooseMap();
    makeObstacles();
    // Ensure spawn after obstacles are created.
    killer.x=WORLD.w/2;killer.y=WORLD.h/2;
    if(collides(killer.x,killer.y,killer.r)){killer.x=100;killer.y=100;}
    survivors.forEach((s,i)=>{if(collides(s.x,s.y,s.r)){s.x=100+i*35;s.y=100;}});
    $("hudKillerName").textContent=k.name;$("hudInitial").textContent="";$("hudPortrait").className=`hud-portrait ${k.key}-art`;$("hudPortrait").style.backgroundImage=`url("${k.image}")`;
    $("killerHealthBar").style.width="100%";$("killerHealthText").textContent=`${killer.hp} / ${killer.maxHp}`;
    $("timer").textContent="04:00";$("objectiveText").textContent="Elimine todos os sobreviventes";
    $("endOverlay").classList.add("hidden");$("toast").classList.add("hidden");
    selectScreen.classList.add("hidden");gameScreen.classList.remove("hidden");
    resizeCanvas();updateSurvivorHud();showToast(`${k.name}: caçada iniciada!`);requestAnimationFrame(loop);
  }
  function updateSurvivorHud(){
    const alive=survivors.filter(s=>s.alive).length;
    $("survivorCount").textContent=alive;
    $("survivorPips").innerHTML=survivors.map(s=>`<span class="survivor-pip ${s.alive?"":"dead"}"></span>`).join("");
  }
  function showToast(message){const t=$("toast");t.textContent=message;t.classList.remove("hidden");toastTimer=1.8;}
  function doAttack(){
    if(!running||ended||attackCooldown>0||(selected===5&&skeletonAbilityLockout>0))return;
    const k=killers[selected];
    attackCooldown=k.cooldown;attackDelay=.15;attackFlash=0;
    activeHitbox={x:0,y:0,angle:killer.angle,targetAngle:killer.angle,size:k.hitboxSize,range:k.range,damage:k.damages? k.damages[Math.floor(Math.random()*k.damages.length)] : k.damage,hitIds:new Set(),visible:0};
    showToast(`${k.name}: ataque!`);
  }
  function burst(x,y,color,n){for(let i=0;i<n;i++){const a=rand(0,Math.PI*2),v=rand(35,160);particles.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:Math.min(1,rand(.2,.65)),max:Math.min(1,.65),color,size:rand(2,5)});}}
  // Partículas estilizadas para habilidades: pequenos brilhos e rastros.
  function skillSpark(x,y,color,n=8,speed=120){
    for(let i=0;i<n;i++){
      const a=rand(0,Math.PI*2),v=rand(speed*.25,speed);
      particles.push({x:x+rand(-8,8),y:y+rand(-8,8),vx:Math.cos(a)*v,vy:Math.sin(a)*v,life:Math.min(1,rand(.3,.8)),max:Math.min(1,.8),color,size:rand(2,6),glow:true});
    }
  }
  function activateStabDash(){
    if(!running||ended||selected!==0||stabDash.cooldown>0||stabDash.phase)return;
    // A preparação dura 1 segundo e permite ajustar a direção antes do dash.
    const angle=killer.angle||0;
    stabDash.x=Math.cos(angle);stabDash.y=Math.sin(angle);
    stabDash.phase="prepare";stabDash.timer=1;stabDash.traveled=0;stabDash.trail=0;
    stabDash.cooldown=17;
    showToast("STAB: Shadow Dash carregando...");
  }
  function activateWesleyDash(){
    if(!running||ended||selected!==4||wesleyDash.cooldown>0||wesleyDash.phase)return;
    const angle=killer.angle||0;
    wesleyDash.x=Math.cos(angle);wesleyDash.y=Math.sin(angle);
    wesleyDash.phase="prepare";wesleyDash.timer=.45;wesleyDash.traveled=0;wesleyDash.trail=0;wesleyDash.hitIds=new Set();
    wesleyDash.cooldown=15;
    showToast("Wesley: Investida Brutal carregando!");
  }
  
function activateHackerHand(){
  if(!running || ended || selected !== 2) return;

  // Se o braço estiver puxando um Survivor, solta imediatamente.
  // Isso funciona mesmo durante o cooldown.
  if(hackerHand.phase === "pulling" && hackerHand.targetId !== null){
    const target = survivors.find(
      s => s.id === hackerHand.targetId && s.alive
    );

    hackerHand.phase = "returning";
    hackerHand.targetId = null;

    if(target){
      showToast(`${target.name} foi solto pelo H4ck4r!`);
    }else{
      showToast("H4ck4r: braço retornando!");
    }

    return;
  }

  // Se não estiver puxando ninguém, respeita o cooldown normal.
  if(hackerHand.cooldown > 0 || hackerHand.phase) return;

  const angle = killer.angle || 0;
  hackerHand.dirX = Math.cos(angle);
  hackerHand.dirY = Math.sin(angle);
  hackerHand.x = killer.x;
  hackerHand.y = killer.y;
  hackerHand.traveled = 0;
  hackerHand.targetId = null;
  hackerHand.hit = false;
  hackerHand.phase = "outbound";
  hackerHand.cooldown = 13;

  burst(killer.x, killer.y, "#53c8d4", 8);
  showToast("H4ck4r: Braço Robótico lançado!");
}

  function activateJJBlast(){
    if(!running||ended||selected!==1||jjBlast.cooldown>0||jjBlast.phase)return;
    jjBlast.phase="charge";jjBlast.timer=2;jjBlast.explosionTimer=0;jjBlast.cooldown=14;
    burst(killer.x,killer.y,"#ff2020",10);
    showToast("JJ: sobrecarga iniciada!");
  }
  function updateJJBlast(dt){
    jjBlast.cooldown=Math.max(0,jjBlast.cooldown-dt);
    if(jjBlast.explosionTimer>0)jjBlast.explosionTimer=Math.max(0,jjBlast.explosionTimer-dt);
    if(selected!==1||jjBlast.phase!=="charge")return;
    jjBlast.timer-=dt;
    if(jjBlast.timer>0)return;
    jjBlast.phase="";jjBlast.explosionTimer=.35;
    burst(killer.x,killer.y,"#ff2020",45);
    for(const s of survivors){
      if(!s.alive)continue;
      const dx=s.x-killer.x,dy=s.y-killer.y,distance=Math.hypot(dx,dy);
      // A explosão ignora paredes e outros obstáculos.
      if(distance<=jjBlast.radius+s.r){
        survivorTakesDamage(s,37);s.hurt=.5;
        const length=distance||1,pushDistance=95;
        const tx=s.x+dx/length*pushDistance,ty=s.y+dy/length*pushDistance;
        if(!collides(tx,s.y,s.r))s.x=tx;
        if(!collides(s.x,ty,s.r))s.y=ty;
        burst(s.x,s.y,"#ff3030",12);showToast(`${s.name}: -37 HP (Sobrecarga do JJ)`);
        if(s.hp<=0){s.hp=0;s.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(s.x,s.y,"#e44755",18);showToast(`${s.name} foi eliminado!`);}
      }
    }
    updateSurvivorHud();
  }

  function updateHackerHand(dt){
    hackerHand.cooldown=Math.max(0,hackerHand.cooldown-dt);
    if(selected!==2||!hackerHand.phase)return;
    const step=(hackerHand.phase==="returning"?hackerHand.returnSpeed:hackerHand.speed)*dt;
    if(hackerHand.phase==="outbound"){
      const travel=Math.min(step,hackerHand.range-hackerHand.traveled);
      const steps=Math.max(1,Math.ceil(travel/5));
      for(let i=0;i<steps;i++){
        const sx=hackerHand.dirX*travel/steps,sy=hackerHand.dirY*travel/steps;
        const nx=hackerHand.x+sx,ny=hackerHand.y+sy;
        // O braço robótico atravessa paredes e obstáculos durante o percurso.
        hackerHand.x=nx;hackerHand.y=ny;hackerHand.traveled+=Math.hypot(sx,sy);
        // Ao tocar a borda interna da arena, o braço começa a voltar automaticamente.
        if(hackerHand.x<=35||hackerHand.x>=WORLD.w-35||hackerHand.y<=35||hackerHand.y>=WORLD.h-35){
          hackerHand.phase="returning";hackerHand.targetId=null;break;
        }
        const target=survivors.find(s=>s.alive&&Math.hypot(s.x-hackerHand.x,s.y-hackerHand.y)<=s.r+13);
        if(target){
          if(!survivorTakesDamage(target,15)){hackerHand.phase="returning";hackerHand.targetId=null;break;}target.hurt=.5;target.panic=2.5;
          burst(target.x,target.y,"#53c8d4",14);
          showToast(`${target.name}: -15 HP (Braço Robótico)`);
          if(target.hp<=0){target.hp=0;target.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(target.x,target.y,"#e44755",18);showToast(`${target.name} foi eliminado!`);updateSurvivorHud();hackerHand.phase="returning";break;}
          hackerHand.targetId=target.id;hackerHand.phase="pulling";break;
        }
        if(hackerHand.traveled>=hackerHand.range){hackerHand.phase="returning";break;}
      }
    }else if(hackerHand.phase==="pulling"){
      const target=survivors.find(s=>s.id===hackerHand.targetId&&s.alive);
      if(!target){hackerHand.phase="returning";hackerHand.targetId=null;return;}
      const dx=killer.x-target.x,dy=killer.y-target.y,distance=Math.hypot(dx,dy);
      const pull=Math.min(step,Math.max(0,distance-killer.r-target.r-3));
      if(distance<=killer.r+target.r+4){
        hackerHand.phase="returning";hackerHand.targetId=null;
      }else{
        // O survivor fica preso à mão durante o puxão, sem poder se mover por conta própria.
        target.x+=dx/(distance||1)*pull;target.y+=dy/(distance||1)*pull;
        hackerHand.x=target.x;hackerHand.y=target.y;
        if(pull<=0.01){hackerHand.phase="returning";hackerHand.targetId=null;}
      }
    }else if(hackerHand.phase==="returning"){
      const dx=killer.x-hackerHand.x,dy=killer.y-hackerHand.y,distance=Math.hypot(dx,dy);
      if(distance<=step+ killer.r){
        hackerHand.x=killer.x;hackerHand.y=killer.y;hackerHand.phase="";hackerHand.targetId=null;
        burst(killer.x,killer.y,"#53c8d4",7);showToast("H4ck4r: braço recolhido.");
      }else{
        hackerHand.x+=dx/(distance||1)*step;hackerHand.y+=dy/(distance||1)*step;
      }
    }
  }

  function activateSkeletonH1(fromAI=false){
    if(!running||ended||selected!==5||skeletonH1.cooldown>0||skeletonH1.phase)return;
    Object.assign(skeletonH1,{phase:"capture",timer:3.78,dirX:Math.cos(killer.angle),dirY:Math.sin(killer.angle),targetId:null,hitIds:new Set(),hitboxTime:4,dashTravel:0});
    skeletonH1.cooldown=28;skeletonSlowTimer=4;skeletonH2SlowTimer=Math.max(skeletonH2SlowTimer,0);skeletonAbilityLockout=4;burst(killer.x,killer.y,"#f4f4f4",12);showToast("Skeleton: lentidão e habilidades bloqueadas por 4 segundos!");
  }
  function updateSkeletonH1(dt){
    skeletonH1.cooldown=Math.max(0,skeletonH1.cooldown-dt);skeletonH1.hitboxTime=Math.max(0,skeletonH1.hitboxTime-dt);
    if(selected!==5||!skeletonH1.phase)return;
    if(skeletonH1.phase==="capture"){
      skeletonH1.timer-=dt;
      if(!skeletonH1.targetId){
        for(const s of survivors){if(!s.alive||skeletonH1.hitIds.has(s.id))continue;
          if(Math.hypot(s.x-killer.x,s.y-killer.y)<=killer.r+s.r+25){
            skeletonH1.targetId=s.id;skeletonH1.hitIds.add(s.id);survivorTakesDamage(s,10);s.hurt=.3;s.panic=2;
            s.x=killer.x+skeletonH1.dirX*(killer.r+s.r-3);s.y=killer.y+skeletonH1.dirY*(killer.r+s.r-3);burst(s.x,s.y,"#eeeeee",12);showToast(`${s.name}: agarrado! -10 HP`);if(s.hp<=0){s.hp=0;s.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");updateSurvivorHud();skeletonH1.targetId=null;}break;
          }
        }
      }
      const target=survivors.find(s=>s.id===skeletonH1.targetId&&s.alive);
      if(target){target.x=killer.x+skeletonH1.dirX*(killer.r+target.r-3);target.y=killer.y+skeletonH1.dirY*(killer.r+target.r-3);target.hurt=Math.max(target.hurt,0.01);}
      if(skeletonH1.timer<=0){skeletonH1.phase="dash";skeletonH1.timer=.48;skeletonH1.dashTravel=0;burst(killer.x,killer.y,"#eeeeee",14);skillSpark(killer.x,killer.y,"#d8f3ff",18,150);}
    }else if(skeletonH1.phase==="dash"){
      const step=Math.min(390*dt,190-skeletonH1.dashTravel);const nx=killer.x+skeletonH1.dirX*step,ny=killer.y+skeletonH1.dirY*step;
      if(!collides(nx,ny,killer.r)){killer.x=clamp(nx,killer.r,WORLD.w-killer.r);killer.y=clamp(ny,killer.r,WORLD.h-killer.r);skeletonH1.dashTravel+=step;}
      const target=survivors.find(s=>s.id===skeletonH1.targetId&&s.alive);
      if(target){target.x=killer.x+skeletonH1.dirX*(killer.r+target.r+3);target.y=killer.y+skeletonH1.dirY*(killer.r+target.r+3);}
      skeletonH1.timer-=dt;
      if(skeletonH1.timer<=0||skeletonH1.dashTravel>=190){
        if(target){survivorTakesDamage(target,37);target.hurt=.6;const px=target.x+skeletonH1.dirX*145,py=target.y+skeletonH1.dirY*145;if(!collides(px,target.y,target.r))target.x=clamp(px,target.r,WORLD.w-target.r);if(!collides(target.x,py,target.r))target.y=clamp(py,target.r,WORLD.h-target.r);burst(target.x,target.y,"#f4f4f4",20);showToast(`${target.name}: -37 HP, arremessado!`);if(target.hp<=0){target.hp=0;target.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");showToast(`${target.name} foi eliminado!`);}updateSurvivorHud();}
        skeletonH1.phase="";skeletonH1.targetId=null;
      }
    }
  }
  function activateSkeletonH2(){
    if(!running||ended||selected!==5||skeletonAbilityLockout>0||skeletonH2.cooldown>0||skeletonH2.phase)return;
    skeletonH2.phase="projectile";skeletonH2.timer=1;skeletonH2.x=killer.x+Math.cos(killer.angle)*(killer.r+12);skeletonH2.y=killer.y+Math.sin(killer.angle)*(killer.r+12);skeletonH2.dirX=Math.cos(killer.angle);skeletonH2.dirY=Math.sin(killer.angle);skeletonH2.traveled=0;skeletonH2.hitIds=new Set();skeletonH2.cooldown=16;
    burst(killer.x,killer.y,"#17131f",8);skillSpark(killer.x,killer.y,"#9d79d8",18,190);showToast("Skeleton: Sombra Negra!");
  }
  function updateSkeletonH2(dt){
    skeletonH2.cooldown=Math.max(0,skeletonH2.cooldown-dt);skeletonSlowTimer=Math.max(0,skeletonSlowTimer-dt);skeletonH2SlowTimer=Math.max(0,skeletonH2SlowTimer-dt);skeletonImmobilized=Math.max(0,skeletonImmobilized-dt);skeletonAbilityLockout=Math.max(0,skeletonAbilityLockout-dt);
    if(selected!==5||skeletonH2.phase!=="projectile")return;
    const step=1150*dt;skeletonH2.x+=skeletonH2.dirX*step;skeletonH2.y+=skeletonH2.dirY*step;skeletonH2.traveled+=step;skeletonH2.timer-=dt;
    for(const s of survivors){if(!s.alive||skeletonH2.hitIds.has(s.id))continue;if(Math.hypot(s.x-skeletonH2.x,s.y-skeletonH2.y)<=s.r+15){
      skeletonH2.hitIds.add(s.id);skeletonImmobilized=.53;s.hurt=.53;
      const px=s.x-skeletonH2.dirX*48,py=s.y-skeletonH2.dirY*48;if(!collides(px,s.y,s.r))s.x=clamp(px,s.r,WORLD.w-s.r);if(!collides(s.x,py,s.r))s.y=clamp(py,s.r,WORLD.h-s.r);
      skeletonH2SlowTimer=.64;burst(s.x,s.y,"#17131f",14);skillSpark(s.x,s.y,"#9d79d8",16,170);showToast(`${s.name}: atingido pela Sombra Negra!`);
    }}
    if(skeletonH2.timer<=0||skeletonH2.traveled>1320)skeletonH2.phase="";
  }

  function updateStabDash(dt){
    if(selected!==0)return;
    stabDash.cooldown=Math.max(0,stabDash.cooldown-dt);
    if(!stabDash.phase)return;
    stabDash.trail=Math.max(0,stabDash.trail-dt);
    if(stabDash.phase==="prepare"){
      // Durante o segundo de preparação, a mira acompanha o controle direcional.
      let ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
      let ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
      if(Math.hypot(ax,ay)>.15){const a=Math.atan2(ay,ax);stabDash.x=Math.cos(a);stabDash.y=Math.sin(a);killer.angle=a;}
      stabDash.timer-=dt;
      if(stabDash.timer<=0){stabDash.phase="dash";stabDash.timer=1.0;burst(killer.x,killer.y,"#ff9d32",10);}
      return;
    }
    if(stabDash.phase!=="dash")return;
    const step=Math.min(500*dt,400-stabDash.traveled);
    const steps=Math.max(1,Math.ceil(step/4));
    for(let i=0;i<steps;i++){
      const sx=stabDash.x*step/steps,sy=stabDash.y*step/steps;
      const nx=killer.x+sx,ny=killer.y+sy;
      if(collides(nx,ny,killer.r)){
        stabDash.phase="";stabDash.timer=0;burst(killer.x,killer.y,"#ff9d32",7);break;
      }
      killer.x=clamp(nx,killer.r,WORLD.w-killer.r);killer.y=clamp(ny,killer.r,WORLD.h-killer.r);
      stabDash.traveled+=Math.hypot(sx,sy);stabDash.trail=.12;
      // A hitbox acompanha a ponta do Stab durante toda a investida.
      const hitboxX=killer.x+stabDash.x*(killer.r+13);
      const hitboxY=killer.y+stabDash.y*(killer.r+13);
      for(const s of survivors){
        if(!s.alive)continue;
        if(touchesSurvivor(s, hitboxX, hitboxY, 9)){
          survivorTakesDamage(s,34);s.hurt=.35;
          // Empurrão leve na direção da investida, sem atravessar paredes.
          const push=18,px=s.x+stabDash.x*push,py=s.y+stabDash.y*push;
          if(!collides(px,s.y,s.r))s.x=px;
          if(!collides(s.x,py,s.r))s.y=py;
          burst(s.x,s.y,"#ff9d32",14);showToast(`${s.name}: -34 HP (Shadow Dash)`);
          if(s.hp<=0){s.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(s.x,s.y,"#e44755",18);showToast(`${s.name} foi eliminado!`);}
          updateSurvivorHud();stabDash.phase="";stabDash.timer=0;break;
        }
      }
      if(!stabDash.phase)break;
      if(stabDash.traveled>=400){stabDash.phase="";stabDash.timer=0;break;}
    }
    stabDash.timer-=dt;
    if(stabDash.timer<=0){stabDash.phase="";stabDash.timer=0;}
  }

  function updateWesleyDash(dt){
    if(selected!==4)return;
    wesleyDash.cooldown=Math.max(0,wesleyDash.cooldown-dt);
    if(!wesleyDash.phase)return;
    wesleyDash.trail=Math.max(0,wesleyDash.trail-dt);
    if(wesleyDash.phase==="prepare"){
      // During the short wind-up the player may adjust the aim.
      const ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
      const ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
      if(Math.hypot(ax,ay)>.15){const a=Math.atan2(ay,ax);wesleyDash.x=Math.cos(a);wesleyDash.y=Math.sin(a);killer.angle=a;}
      wesleyDash.timer-=dt;
      if(wesleyDash.timer<=0){wesleyDash.phase="dash";wesleyDash.timer=.5;burst(killer.x,killer.y,"#a68aff",10);}
      return;
    }
    if(wesleyDash.phase!=="dash")return;
    // Almost-perfect steering while dashing: direction follows input smoothly.
    let ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
    let ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
    if(Math.hypot(ax,ay)>.15){const mag=Math.hypot(ax,ay);ax/=mag;ay/=mag;const tx=ax,ty=ay;wesleyDash.x=wesleyDash.x*.05+tx*.95;wesleyDash.y=wesleyDash.y*.05+ty*.95;const m=Math.hypot(wesleyDash.x,wesleyDash.y)||1;wesleyDash.x/=m;wesleyDash.y/=m;}
    killer.angle=Math.atan2(wesleyDash.y,wesleyDash.x);
    const step=Math.min(wesleyDash.speed*dt,wesleyDash.maxDistance-wesleyDash.traveled);
    const steps=Math.max(1,Math.ceil(step/4));
    for(let i=0;i<steps;i++){
      const sx=wesleyDash.x*step/steps,sy=wesleyDash.y*step/steps,nx=killer.x+sx,ny=killer.y+sy;
      if(collides(nx,ny,killer.r)){wesleyDash.phase="";wesleyDash.timer=0;burst(killer.x,killer.y,"#a68aff",8);break;}
      killer.x=clamp(nx,killer.r,WORLD.w-killer.r);killer.y=clamp(ny,killer.r,WORLD.h-killer.r);
      wesleyDash.traveled+=Math.hypot(sx,sy);wesleyDash.trail=.1;
      // Visible hitbox is the outlined capsule/rectangle just ahead of Wesley.
      const hx=killer.x+wesleyDash.x*(killer.r+18),hy=killer.y+wesleyDash.y*(killer.r+18);
      for(const target of survivors){if(!target.alive||wesleyDash.hitIds.has(target.id))continue;
        if(touchesSurvivor(target, hx, hy, 12)){
          wesleyDash.hitIds.add(target.id);if(!survivorTakesDamage(target,30)){wesleyDash.phase="";wesleyDash.timer=0;break;}target.hurt=.35;target.panic=2;
          const push=100,px=target.x+wesleyDash.x*push,py=target.y+wesleyDash.y*push;
          if(!collides(px,target.y,target.r))target.x=px;
          if(!collides(target.x,py,target.r))target.y=py;
          burst(target.x,target.y,"#a68aff",15);skillSpark(target.x,target.y,"#d5c7ff",18,180);showToast(`${target.name}: -30 HP (Investida Brutal)`);
          if(target.hp<=0){target.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(target.x,target.y,"#a68aff",18);showToast(`${target.name} foi eliminado!`);}
          updateSurvivorHud();wesleyDash.phase="";wesleyDash.timer=0;break;
        }
      }
      if(!wesleyDash.phase)break;
      if(wesleyDash.traveled>=wesleyDash.maxDistance){wesleyDash.phase="";wesleyDash.timer=0;break;}
    }
    wesleyDash.timer-=dt;if(wesleyDash.timer<=0){wesleyDash.phase="";wesleyDash.timer=0;}
  }

  function activateSixerH1(){
    if(!running||ended||selected!==3||sixerH1.cooldown>0||sixerH1.phase)return;
    const angle=killer.angle||0;
    sixerH1.dirX=Math.cos(angle);sixerH1.dirY=Math.sin(angle);
    sixerH1.phase="prepare";sixerH1.timer=1;sixerH1.traveled=0;sixerH1.targetId=null;sixerH1.hitCount=0;sixerH1.hitTimer=0;sixerH1.hitboxTimer=0;sixerH1.cooldown=18;
    burst(killer.x,killer.y,"#ff263f",10);showToast("Sixer: Investida Multigolpe carregando!");
  }
  function activateSixerH2(){
    if(!running||ended||selected!==3||sixerH2.cooldown>0||sixerH2.phase)return;
    const angle=killer.angle||0;
    sixerH2.dirX=Math.cos(angle);sixerH2.dirY=Math.sin(angle);
    sixerH2.phase="jump";sixerH2.timer=.45;sixerH2.traveled=0;sixerH2.waveX=killer.x;sixerH2.waveY=killer.y;sixerH2.hitIds=new Set();sixerH2.jumpY=0;sixerH2.cooldown=15;
    burst(killer.x,killer.y,"#ff6633",8);showToast("Sixer: salto de impacto!");
  }
  function updateSixerH1(dt){
    sixerH1.cooldown=Math.max(0,sixerH1.cooldown-dt);
    if(selected!==3||!sixerH1.phase)return;
    if(sixerH1.phase==="prepare"){
      // Durante o segundo de mira, o Sixer pode virar sem sair do lugar.
      // A linha vermelha usa esta direção, então acompanha cada mudança de direção.
      let aimX=0,aimY=0;
      if(keys.has("w")||keys.has("arrowup"))aimY--;
      if(keys.has("s")||keys.has("arrowdown"))aimY++;
      if(keys.has("a")||keys.has("arrowleft"))aimX--;
      if(keys.has("d")||keys.has("arrowright"))aimX++;
      aimX+=touch.x;aimY+=touch.y;
      const aimMag=Math.hypot(aimX,aimY);
      if(aimMag>.1){
        aimX/=aimMag;aimY/=aimMag;
        sixerH1.dirX=aimX;sixerH1.dirY=aimY;
        killer.angle=Math.atan2(aimY,aimX);killer.facingX=aimX;killer.facingY=aimY;
      }
      sixerH1.timer-=dt;
      if(sixerH1.timer<=0){sixerH1.phase="dash";sixerH1.timer=1000/sixerH1.dashSpeed;burst(killer.x,killer.y,"#ff263f",12);}
      return;
    }
    if(sixerH1.phase==="dash"){
      // Pequeno controle direcional durante o dash, sem permitir curvas bruscas.
      let ix=0,iy=0;
      if(keys.has("w")||keys.has("arrowup"))iy--;
      if(keys.has("s")||keys.has("arrowdown"))iy++;
      if(keys.has("a")||keys.has("arrowleft"))ix--;
      if(keys.has("d")||keys.has("arrowright"))ix++;
      ix+=touch.x;iy+=touch.y;
      const im=Math.hypot(ix,iy);
      if(im>.1){ix/=im;iy/=im;const steer=.16;let nx=sixerH1.dirX+ix*steer*dt*3,ny=sixerH1.dirY+iy*steer*dt*3,nm=Math.hypot(nx,ny)||1;sixerH1.dirX=nx/nm;sixerH1.dirY=ny/nm;}
      const step=Math.min(sixerH1.dashSpeed*dt,sixerH1.dashDistance-sixerH1.traveled);
      const sx=sixerH1.dirX*step,sy=sixerH1.dirY*step;
      // Durante a investida ignoramos collides()/moveEntity(): paredes e blocos
      // do cenário não interrompem nem desviam o dash. Só os limites externos do mapa valem.
      killer.x=clamp(killer.x+sx,35+killer.r,WORLD.w-35-killer.r);
      killer.y=clamp(killer.y+sy,35+killer.r,WORLD.h-35-killer.r);
      sixerH1.traveled+=step;sixerH1.hitboxTimer=.08;
      for(const target of survivors){
        if(!target.alive)continue;
        if(touchesSurvivor(target, killer.x, killer.y, killer.r + 17)){
          sixerH1.phase="combo";sixerH1.targetId=target.id;sixerH1.hitCount=0;sixerH1.hitTimer=.05;
          showToast(`${target.name}: preso na Investida Multigolpe!`);break;
        }
      }
      if(sixerH1.phase==="dash"&&sixerH1.traveled>=sixerH1.dashDistance){sixerH1.phase="";burst(killer.x,killer.y,"#ff263f",12);}
      return;
    }
    if(sixerH1.phase==="combo"){
      const target=survivors.find(s=>s.id===sixerH1.targetId&&s.alive);
      if(!target){sixerH1.phase="";return;}
      sixerH1.hitTimer-=dt;
      if(sixerH1.hitTimer<=0){
        sixerH1.hitCount++;sixerH1.hitboxTimer=.20;if(!survivorTakesDamage(target,10)){sixerH1.phase="";return;}target.hurt=.25;target.panic=1.5;
        burst(target.x,target.y,"#ff263f",8);skillSpark(target.x,target.y,"#ff7a9b",10,150);showToast(`${target.name}: -10 HP (${sixerH1.hitCount}/4)`);
        if(target.hp<=0){target.hp=0;target.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(target.x,target.y,"#e44755",18);showToast(`${target.name} foi eliminado!`);updateSurvivorHud();sixerH1.phase="";return;}
        if(sixerH1.hitCount>=4){
          const px=target.x+sixerH1.dirX*95,py=target.y+sixerH1.dirY*95;
          if(!collides(px,target.y,target.r))target.x=clamp(px,target.r,WORLD.w-target.r);
          if(!collides(target.x,py,target.r))target.y=clamp(py,target.r,WORLD.h-target.r);
          target.hurt=.5;target.panic=2;burst(target.x,target.y,"#ff763f",18);sixerH1.phase="";sixerH1.targetId=null;showToast(`${target.name} foi empurrado!`);
        }else sixerH1.hitTimer=.24;
        updateSurvivorHud();
      }
    }
    sixerH1.hitboxTimer=Math.max(0,sixerH1.hitboxTimer-dt);
  }
  function updateSixerH2(dt){
    sixerH2.cooldown=Math.max(0,sixerH2.cooldown-dt);
    if(selected!==3||!sixerH2.phase)return;
    if(sixerH2.phase==="jump"){
      sixerH2.timer-=dt;sixerH2.jumpY=Math.sin((.45-sixerH2.timer)/.45*Math.PI)*24;
      if(sixerH2.timer<=0){sixerH2.phase="wave";sixerH2.traveled=0;sixerH2.waveX=killer.x;sixerH2.waveY=killer.y;burst(killer.x,killer.y,"#ff6633",20);}
      return;
    }
    if(sixerH2.phase==="wave"){
      // Durante a onda, o Sixer pode curvar para os dois lados usando o controle direcional.
      let ax=(keys.has("a")||keys.has("arrowleft")?-1:0)+(keys.has("d")||keys.has("arrowright")?1:0)+touch.x;
      let ay=(keys.has("w")||keys.has("arrowup")?-1:0)+(keys.has("s")||keys.has("arrowdown")?1:0)+touch.y;
      const inputMag=Math.hypot(ax,ay);
      if(inputMag>.2){ax/=inputMag;ay/=inputMag;const steer=.9;let nx=sixerH2.dirX*(1-steer)+ax*steer,ny=sixerH2.dirY*(1-steer)+ay*steer,nm=Math.hypot(nx,ny)||1;sixerH2.dirX=nx/nm;sixerH2.dirY=ny/nm;}
      const step=Math.min(325*dt,700-sixerH2.traveled);sixerH2.waveX+=sixerH2.dirX*step;sixerH2.waveY+=sixerH2.dirY*step;sixerH2.traveled+=step;
      // A onda pode acertar o mesmo Survivor novamente se sair do alcance e voltar a tocá-lo.
      for(const target of survivors){
        if(!target.alive) { sixerH2.hitIds.delete(target.id); continue; }
        const touching=Math.hypot(target.x-sixerH2.waveX,target.y-sixerH2.waveY)<=target.r+sixerH2.waveRadius;
        if(!touching){sixerH2.hitIds.delete(target.id);continue;}
        if(sixerH2.hitIds.has(target.id))continue;
        if(touching){
          sixerH2.hitIds.add(target.id);if(!survivorTakesDamage(target,20))continue;target.hurt=.35;target.panic=2;
          burst(target.x,target.y,"#ff6633",12);skillSpark(target.x,target.y,"#ffc078",16,180);showToast(`${target.name}: -20 HP (Onda de Impacto)`);
          if(target.hp<=0){target.hp=0;target.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(target.x,target.y,"#e44755",18);showToast(`${target.name} foi eliminado!`);}
          updateSurvivorHud();
        }
      }
      if(sixerH2.traveled>=700){sixerH2.phase="";sixerH2.jumpY=0;}
    }
  }

  function update(dt){
    if(!running||ended)return;
    if(gameMode==="survivor"){updateSurvivorMode(dt);return;}
    recoverEntitiesFromWalls();
    resolveKillerSurvivorCollision();
    // O stun do Killer controlado pelo jogador dura o tempo definido pela habilidade.
    killer.stunTimer=Math.max(0,(killer.stunTimer||0)-dt);
    updateSurvivorAbilities(dt);
    elapsed+=dt;timeLeft=Math.max(0,MATCH_SECONDS-elapsed);
    attackCooldown=Math.max(0,attackCooldown-dt);
    updateStabDash(dt);
    updateWesleyDash(dt);
    updateHackerHand(dt);
    updateJJBlast(dt);
    updateSixerH1(dt);
    updateSixerH2(dt);
    updateSkeletonH1(dt);
    updateSkeletonH2(dt);
    if(attackDelay>0){
      attackDelay=Math.max(0,attackDelay-dt);
      if(attackDelay===0&&activeHitbox){activeHitbox.visible=.25;attackFlash=.25;}
    }
    if(activeHitbox){
      // A hitbox gira com um pequeno atraso suave, durante a preparação e a janela ativa.
      activeHitbox.targetAngle=killer.angle;
      const angleDiff=Math.atan2(
        Math.sin(activeHitbox.targetAngle-activeHitbox.angle),
        Math.cos(activeHitbox.targetAngle-activeHitbox.angle)
      );
      const turnAlpha=1-Math.exp(-dt/HITBOX_TURN_DELAY);
      activeHitbox.angle+=angleDiff*turnAlpha;

      if(activeHitbox.visible>0){
        activeHitbox.visible=Math.max(0,activeHitbox.visible-dt);
        const a=activeHitbox.angle, ux=Math.cos(a), uy=Math.sin(a);
        const cx=killer.x+ux*(killer.r+activeHitbox.range/2-8),
      cy=killer.y+uy*(killer.r+activeHitbox.range/2-8);
        const halfL=activeHitbox.range/2, halfW=activeHitbox.size/2;
        for(const s of survivors){if(!s.alive||activeHitbox.hitIds.has(s.id)||(s.name==="GhostGirl"&&s.ghostTimer>0))continue;
          const rx=s.x-cx, ry=s.y-cy, along=rx*ux+ry*uy, across=-rx*uy+ry*ux;
          if(along>=-s.r&&along<=halfL+s.r&&Math.abs(across)<=halfW+s.r){
            activeHitbox.hitIds.add(s.id);
            if(s.defenseTimer>0){survivorTakesDamage(s,activeHitbox.damage);}
            else {survivorTakesDamage(s,activeHitbox.damage);s.hurt=.25;
              burst(s.x,s.y,killers[selected].color,10);showToast(`${s.name}: -${activeHitbox.damage} HP`);
              if(s.hp<=0){s.alive=false;if(gameMode==="killer")addMoney(2,"eliminou um Survivor");burst(s.x,s.y,"#e44755",18);showToast(`${s.name} foi eliminado!`);}
            }
            updateSurvivorHud();
          }
        }
      }
      if(activeHitbox.visible<=0&&attackDelay<=0)activeHitbox=null;
    }
    attackFlash=Math.max(0,attackFlash-dt);
    if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$("toast").classList.add("hidden");}
    const k=killers[selected];
    let dx=0,dy=0;
    if(keys.has("w")||keys.has("arrowup"))dy--;
    if(keys.has("s")||keys.has("arrowdown"))dy++;
    if(keys.has("a")||keys.has("arrowleft"))dx--;
    if(keys.has("d")||keys.has("arrowright"))dx++;
    dx+=touch.x;dy+=touch.y;
    const mag=Math.hypot(dx,dy);if(mag>1){dx/=mag;dy/=mag;}
    const stabBusy=selected===0&&!!stabDash.phase;
    const wesleyBusy=selected===4&&!!wesleyDash.phase;
    const hackerBusy=selected===2&&!!hackerHand.phase;
    // JJ pode andar normalmente enquanto a explosão carrega.
    const jjBusy=false;
    const sixerBusy=selected===3&&["prepare","dash","combo"].includes(sixerH1.phase);
    const sixerH2Busy=selected===3&&sixerH2.phase==="jump";
    const skeletonBusy=selected===5&&skeletonH1.phase==="dash";
    const abilityBusy=stabBusy||wesleyBusy||hackerBusy||jjBusy||sixerBusy||sixerH2Busy||skeletonBusy;
    // Ao zerar a stamina, a corrida fica bloqueada até recuperar a barra completa.
    if(killer.staminaExhausted&&killer.stamina>=killer.maxStamina)killer.staminaExhausted=false;
    const sprint=!abilityBusy&&!killer.staminaExhausted&&(keys.has("shift")||touch.sprint)&&killer.stamina>0&&mag>.1;
    const speed=(sprint?k.sprint:k.speed)-(selected===5&&skeletonSlowTimer>0?75:0)-(selected===5&&skeletonH2SlowTimer>0?30:0);
    if(sprint){
      killer.stamina=Math.max(0,killer.stamina-28*dt);
      if(killer.stamina<=0)killer.staminaExhausted=true;
    }else killer.stamina=Math.min(killer.maxStamina,killer.stamina+19*dt);
    if(mag>.1&&!abilityBusy&&(killer.stunTimer||0)<=0){killer.angle=Math.atan2(dy,dx);killer.facingX=dx; killer.facingY=dy; killer.facing=dx<0?0:1;moveEntity(killer,dx*speed*dt,dy*speed*dt,killer.r);}
    survivors.forEach(s=>{
      if(!s.alive)return;
      s.think-=dt;s.hurt=Math.max(0,s.hurt-dt);s.panic=Math.max(0,s.panic-dt);
      s.speedBoost=Math.max(0,(s.speedBoost||0)-dt);
      s.dodgeTimer=Math.max(0,(s.dodgeTimer||0)-dt);
      s.speed=s.baseSpeed+(s.speedBoost>0?90:0);
      // Os Survivors nem sempre percebem uma habilidade: às vezes reagem e mudam de rota.
      let dangerX=killer.x,dangerY=killer.y,dangerRadius=0,abilityThreat=false;
      if(selected===1&&jjBlast.phase==="charge"){dangerRadius=jjBlast.radius+70;abilityThreat=true;}
      if(selected===0&&stabDash.phase==="prepare"){dangerRadius=250;abilityThreat=true;}
      if(selected===4&&wesleyDash.phase==="prepare"){dangerRadius=220;abilityThreat=true;}
      if(selected===3&&sixerH1.phase==="prepare"){dangerRadius=260;abilityThreat=true;}
      if(selected===2&&hackerHand.phase==="outbound"){dangerX=hackerHand.x;dangerY=hackerHand.y;dangerRadius=95;abilityThreat=true;}
      if(abilityThreat&&Math.hypot(s.x-dangerX,s.y-dangerY)<dangerRadius&&s.dodgeTimer<=0&&Math.random()<.42){
        s.dodgeTimer=1.1;s.panic= Math.max(s.panic,1.5);
        const away=Math.atan2(s.y-dangerY,s.x-dangerX)+rand(-.9,.9);
        setSurvivorGoal(s,s.x+Math.cos(away)*rand(220,340),s.y+Math.sin(away)*rand(220,340));
      }
      if(selected===3&&sixerH1.phase==="combo"&&sixerH1.targetId===s.id){s.angle=Math.atan2(-sixerH1.dirY,-sixerH1.dirX);return;}
      if(selected===2&&hackerHand.phase==="pulling"&&hackerHand.targetId===s.id){
        s.angle=Math.atan2(killer.y-s.y,killer.x-s.x);
        if(Math.hypot(s.x-killer.x,s.y-killer.y)<=killer.r+s.r+4){hackerHand.phase="returning";hackerHand.targetId=null;}
        return;
      }
      if(skeletonImmobilized>0){s.hurt=Math.max(s.hurt,0.01);return;}
      const d=dist(s,killer);let ax=0,ay=0;
      s.pathTimer-=dt;
      const fleeing=d<270||s.panic>0;
      // Escolhe um destino, então usa o caminho calculado para contornar blocos.
      if(fleeing){
        if(s.pathTimer<=0||!s.path.length||s.pathIndex>=s.path.length){
          const a=Math.atan2(s.y-killer.y,s.x-killer.x);
          const fleeDistance=rand(260,390);
          setSurvivorGoal(s,s.x+Math.cos(a)*fleeDistance+rand(-100,100),s.y+Math.sin(a)*fleeDistance+rand(-100,100));
        }
      }else if(s.think<=0||s.pathTimer<=0||!s.path.length||s.pathIndex>=s.path.length){
        s.think=rand(.7,1.5);
        // Tenta destinos aleatórios que sejam acessíveis em vez de andar reto contra uma parede.
        let chosen=false;
        for(let attempt=0;attempt<7&&!chosen;attempt++){
          const a=rand(0,Math.PI*2),len=rand(150,330);
          const gx=clamp(s.x+Math.cos(a)*len,180,WORLD.w-180),gy=clamp(s.y+Math.sin(a)*len,180,WORLD.h-180);
          setSurvivorGoal(s,gx,gy);chosen=s.path.length>0;
        }
      }
      // Recalcula periodicamente para reagir ao movimento do killer e a mudanças no caminho.
      if(s.pathTimer<=0&&s.goalX!=null)setSurvivorGoal(s,s.goalX,s.goalY);
      let waypoint=s.path[s.pathIndex];
      if(waypoint&&Math.hypot(waypoint.x-s.x,waypoint.y-s.y)<19){s.pathIndex++;waypoint=s.path[s.pathIndex];}
      if(waypoint){ax=waypoint.x-s.x;ay=waypoint.y-s.y;}
      else if(fleeing){const a=Math.atan2(s.y-killer.y,s.x-killer.x);ax=Math.cos(a);ay=Math.sin(a);}
      else {ax=Math.cos(s.wander);ay=Math.sin(s.wander);}
      // Proteção extra: se a próxima etapa estiver bloqueada, planeja uma rota nova.
      const norm=Math.hypot(ax,ay)||1;ax/=norm;ay/=norm;
      const step=Math.max(3,s.speed*dt*2.2);
      if(collides(s.x+ax*step,s.y+ay*step,s.r)){
        const oldGoalX=s.goalX,oldGoalY=s.goalY;
        s.path=[];s.pathIndex=0;s.pathTimer=0;
        if(oldGoalX!=null)setSurvivorGoal(s,oldGoalX,oldGoalY);
        waypoint=s.path[s.pathIndex];
        if(waypoint){ax=waypoint.x-s.x;ay=waypoint.y-s.y;const n=Math.hypot(ax,ay)||1;ax/=n;ay/=n;}
      }
      const oldX=s.x,oldY=s.y;
      moveEntity(s,ax*s.speed*dt,ay*s.speed*dt,s.r);
      if(Math.hypot(s.x-oldX,s.y-oldY)<.2){
        s.stuck+=dt;
        // Se ficar preso junto a um canto/obstáculo, abandona o destino antigo e
        // procura uma nova rota válida em vez de insistir na mesma parede.
        if(s.stuck>.7){
          s.path=[];s.pathIndex=0;s.pathTimer=0;s.think=0;
          let rerouted=false;
          for(let attempt=0;attempt<14&&!rerouted;attempt++){
            const a=rand(0,Math.PI*2),len=rand(220,430);
            const gx=clamp(s.x+Math.cos(a)*len,180,WORLD.w-180);
            const gy=clamp(s.y+Math.sin(a)*len,180,WORLD.h-180);
            setSurvivorGoal(s,gx,gy);
            rerouted=s.path.length>0;
          }
          // Último recurso: escolhe uma direção local livre para sair do canto.
          if(!rerouted){
            const escapes=[[-1,0],[1,0],[0,-1],[0,1],[-.7,-.7],[.7,-.7],[-.7,.7],[.7,.7]];
            for(const [ex,ey] of escapes){
              if(!collides(s.x+ex*32,s.y+ey*32,s.r)){
                s.goalX=clamp(s.x+ex*180,180,WORLD.w-180);s.goalY=clamp(s.y+ey*180,180,WORLD.h-180);
                s.path=findSurvivorPath(s,s.goalX,s.goalY);s.pathIndex=0;s.pathTimer=.5;break;
              }
            }
          }
          s.stuck=0;
        }
      }else s.stuck=0;
      s.angle=Math.atan2(ay,ax);
      // Encostar em um Survivor não causa dano ao Killer. O Killer só perde HP por ataques dos Survivors.
    });
    particles.forEach(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.96;p.vy*=.96;p.life-=dt;});
    particles=particles.filter(p=>p.life>0);
    camera.x = clamp(
  killer.x - viewW / (2 * ZOOM),
  0,
  WORLD.w - viewW / ZOOM
);

camera.y = clamp(
  killer.y - viewH / (2 * ZOOM),
  0,
  WORLD.h - viewH / ZOOM
);
    if(!lastSurvivorMinuteStarted&&survivors.filter(s=>s.alive).length===1){lastSurvivorMinuteStarted=true;elapsed=MATCH_SECONDS-60;timeLeft=60;if(gameMode==="killer")addMoney(7,"entrou na LMS");showToast("ÚLTIMO SURVIVOR! 1 minuto restante!");}
    $("timer").textContent=`${Math.floor(timeLeft/60).toString().padStart(2,"0")}:${Math.floor(timeLeft%60).toString().padStart(2,"0")}`;
    $("killerHealthBar").style.width=`${clamp(killer.hp/killer.maxHp*100,0,100)}%`;
    $("killerHealthText").textContent=`${Math.ceil(killer.hp)} / ${killer.maxHp}`;
    if(timeLeft<=0)finish(false,"O tempo acabou antes de você eliminar todos os sobreviventes.");
    checkEnd();
  }
  function checkEnd(){if(!running||ended)return;if(survivors.every(s=>!s.alive))finish(true,"Todos os sobreviventes foram eliminados.");}
  function finish(won,description){
    if(ended)return;ended=true;running=false;
    if(won){if(gameMode==="killer")addMoney(15,"venceu a partida");else addMoney(17,"venceu a partida");}
    $("endTitle").textContent=won?"CAÇADA CONCLUÍDA":"OS SOBREVIVENTES ESCAPARAM";
    $("endDescription").textContent=description;
    $("endOverlay").classList.remove("hidden");
  }
  
function drawFloor(){
  if(currentMap === "halloween"){
    const g=ctx.createLinearGradient(0,0,WORLD.w,WORLD.h);
    g.addColorStop(0,"#25113f");g.addColorStop(.48,"#35105c");g.addColorStop(1,"#160c2c");
    ctx.fillStyle=g;ctx.fillRect(0,0,WORLD.w,WORLD.h);
    // Névoa violeta, círculos rúnicos e caminhos de pedra roxa.
    for(let i=0;i<34;i++){const x=randStatic(i+90,45,WORLD.w-45),y=randStatic(i+170,45,WORLD.h-45);ctx.globalAlpha=.06+randStatic(i+210,0,.08);ctx.fillStyle=i%2?"#b45cff":"#6f42bc";ctx.beginPath();ctx.ellipse(x,y,randStatic(i+270,35,100),randStatic(i+330,20,65),i*.17,0,Math.PI*2);ctx.fill();}
    ctx.globalAlpha=1;ctx.strokeStyle="#b66cff24";ctx.lineWidth=2;
    for(let x=60;x<WORLD.w;x+=90){ctx.beginPath();ctx.moveTo(x,40);ctx.lineTo(x,WORLD.h-40);ctx.stroke();}
    for(let y=60;y<WORLD.h;y+=90){ctx.beginPath();ctx.moveTo(40,y);ctx.lineTo(WORLD.w-40,y);ctx.stroke();}
    ctx.strokeStyle="#b96bff";ctx.globalAlpha=.45;ctx.lineWidth=4;ctx.strokeRect(35,35,WORLD.w-70,WORLD.h-70);ctx.globalAlpha=1;
    // Praça central roxa para destacar a estátua criada pelo jogador.
    ctx.fillStyle="#10091c88";ctx.beginPath();ctx.ellipse(WORLD.w/2,WORLD.h/2,175,145,0,0,Math.PI*2);ctx.fill();
    ctx.strokeStyle="#c477ff";ctx.globalAlpha=.6;ctx.lineWidth=4;ctx.beginPath();ctx.ellipse(WORLD.w/2,WORLD.h/2,170,140,0,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=1;
  }else if(currentMap === "estacao"){
    // Chão industrial da Estação do Fim
    ctx.fillStyle = "#182126";
    ctx.fillRect(0,0,WORLD.w,WORLD.h);

    // Placas metálicas no piso
    ctx.strokeStyle = "#a4b6bd12";
    ctx.lineWidth = 2;

    for(let x=35;x<WORLD.w;x+=100){
      ctx.beginPath();
      ctx.moveTo(x,35);
      ctx.lineTo(x,WORLD.h-35);
      ctx.stroke();
    }

    for(let y=35;y<WORLD.h;y+=100){
      ctx.beginPath();
      ctx.moveTo(35,y);
      ctx.lineTo(WORLD.w-35,y);
      ctx.stroke();
    }

    // Manchas de ferrugem e sujeira
    for(let i=0;i<48;i++){
      const x=(i*317+83)%WORLD.w;
      const y=(i*191+57)%WORLD.h;

      ctx.fillStyle=i%2 ? "#59664a22" : "#74452b30";
      ctx.beginPath();
      ctx.ellipse(
        x,y,
        randStatic(i,18,55),
        randStatic(i+1,10,32),
        i*.2,0,Math.PI*2
      );
      ctx.fill();
    }

    // Linhas de segurança amarelas
    ctx.strokeStyle = "#b8a34b55";
    ctx.lineWidth = 4;
    ctx.setLineDash([18,12]);

    ctx.strokeRect(55,55,WORLD.w-110,WORLD.h-110);

    ctx.setLineDash([]);

    // Contorno industrial
    ctx.strokeStyle = "#56666c";
    ctx.lineWidth = 3;
    ctx.strokeRect(35,35,WORLD.w-70,WORLD.h-70);

  }else{
    // Chão original, preservado
    ctx.fillStyle="#111820";
    ctx.fillRect(0,0,WORLD.w,WORLD.h);

    ctx.strokeStyle="#ffffff08";
    ctx.lineWidth=1;

    for(let x=35;x<WORLD.w;x+=50){
      ctx.beginPath();
      ctx.moveTo(x,35);
      ctx.lineTo(x,WORLD.h-35);
      ctx.stroke();
    }

    for(let y=35;y<WORLD.h;y+=50){
      ctx.beginPath();
      ctx.moveTo(35,y);
      ctx.lineTo(WORLD.w-35,y);
      ctx.stroke();
    }

    // Manchas de concreto úmido
    for(let i=0;i<40;i++){
      const x=(i*317+83)%WORLD.w;
      const y=(i*191+57)%WORLD.h;

      ctx.fillStyle=i%2?"#25302c22":"#5c343015";
      ctx.beginPath();
      ctx.ellipse(
        x,y,
        randStatic(i,15,48),
        randStatic(i+1,9,28),
        i*.2,0,Math.PI*2
      );
      ctx.fill();
    }

    ctx.strokeStyle="#38434b";
    ctx.lineWidth=3;
    ctx.strokeRect(35,35,WORLD.w-70,WORLD.h-70);
  }
}

  function randStatic(n,a,b){const x=Math.sin(n*127.1)*43758.5453;return a+(x-Math.floor(x))*(b-a);}
  
function drawObstacle(o){
    // Sombra
    ctx.fillStyle="#0008";
    ctx.fillRect(o.x+5,o.y+7,o.w,o.h);

    // Corpo do obstáculo
    const g=ctx.createLinearGradient(
      o.x,o.y,o.x+o.w,o.y+o.h
    );

    if(currentMap === "estacao"){
      g.addColorStop(0,"#35464b");
      g.addColorStop(1,"#19262c");
    }else if(currentMap === "halloween"){
      g.addColorStop(0,"#542477");g.addColorStop(1,"#211234");
    }else{
      g.addColorStop(0,"#343b43");
      g.addColorStop(1,"#1b222b");
    }

    ctx.fillStyle=g;
    ctx.fillRect(o.x,o.y,o.w,o.h);

    // Contorno
    ctx.strokeStyle=currentMap === "estacao" ? "#75888a" : currentMap === "halloween" ? "#a86be0" : "#59616b";

    ctx.lineWidth=2;
    ctx.strokeRect(o.x+1,o.y+1,o.w-2,o.h-2);

    // Faixa superior metálica
    ctx.strokeStyle="#ffffff0c";
    ctx.beginPath();
    ctx.moveTo(o.x+8,o.y+8);
    ctx.lineTo(o.x+o.w-8,o.y+8);
    ctx.stroke();

    if(currentMap === "estacao"){
      // Pequenos detalhes de segurança
      ctx.fillStyle="#c5a84b";
      ctx.fillRect(o.x+8,o.y+o.h-7,Math.min(o.w-16,35),3);

      // Painel luminoso de emergência
      ctx.fillStyle="#d34b43";
      ctx.fillRect(o.x+o.w-15,o.y+10,5,5);
    }
}
  function drawPerson(e,type,color,label,hp,maxHp,angle){
    const size = e.size || (e.r * 2);
    ctx.save();
    ctx.translate(e.x,e.y);
    if(type==="killer"){
      const img=killerImages[selected];
      if(img&&img.complete&&img.naturalWidth){
        // Os sprites apontam para cima quando angle = -PI/2.
        ctx.save();
        ctx.rotate((Number.isFinite(angle)?angle:-Math.PI/2)+Math.PI/2);
        ctx.drawImage(img,-size/2,-size/2,size,size);
        ctx.restore();
      }else{
        ctx.fillStyle=color;ctx.beginPath();ctx.arc(0,0,e.r,0,Math.PI*2);ctx.fill();
        ctx.save();ctx.rotate(Number.isFinite(angle)?angle:0);ctx.fillStyle="#fff";
        ctx.beginPath();ctx.moveTo(e.r+5,0);ctx.lineTo(e.r-2,-5);ctx.lineTo(e.r-2,5);ctx.closePath();ctx.fill();ctx.restore();
      }
    }else{
  // Imagem do Survivor, dimensionada por e.size.
  const survivorImage = survivorImageCache[e.name] || survivorImageCache["Davi"];
  if (survivorImage && survivorImage.complete && survivorImage.naturalWidth > 0) {
    ctx.drawImage(
      survivorImage,
      -size / 2,
      -size / 2,
      size,
      size
    );
  } else {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.arc(0, 0, e.r, 0, Math.PI * 2);
    ctx.fill();
  }
      // Indicador de direção para mostrar para onde cada Survivor está virado.
      ctx.save();ctx.rotate(Number.isFinite(angle)?angle:0);ctx.fillStyle="#d5f7e5";
      ctx.beginPath();ctx.moveTo(e.r+4,0);ctx.lineTo(e.r-3,-4);ctx.lineTo(e.r-3,4);ctx.closePath();ctx.fill();ctx.restore();
      ctx.fillStyle="#0008";ctx.fillRect(-16,-e.r-12,32,4);ctx.fillStyle="#58d39b";ctx.fillRect(-16,-e.r-12,32*clamp(hp/maxHp,0,1),4);
    }
    ctx.restore();
    ctx.font=type==="killer"?"bold 11px Inter":"10px Inter";ctx.textAlign="center";ctx.fillStyle=type==="killer"?"#fff":"#c5e5d5";
    ctx.fillText(label,e.x,e.y-size/2-7);
  }
  function drawHalloweenDecor(){
    halloweenDecor.forEach((d,i)=>{
      const bob=d.type.startsWith("ghost")?Math.sin(elapsed*2.2+(d.phase||0))*9:0;
      const img=halloweenArt[d.type];
      if(img&&img.complete&&img.naturalWidth>0){ctx.save();if(d.type.startsWith("ghost"))ctx.globalAlpha=.72;ctx.drawImage(img,d.x-d.w/2,d.y-d.h/2+bob,d.w,d.h);ctx.restore();return;}
      if(d.type==="pumpkin"){
        ctx.save();ctx.translate(d.x,d.y);ctx.shadowColor="#ff7a19";ctx.shadowBlur=13;ctx.fillStyle="#f47718";ctx.strokeStyle="#ffb04a";ctx.lineWidth=2;
        ctx.beginPath();ctx.ellipse(0,2,d.w*.43,d.h*.38,0,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.beginPath();ctx.ellipse(-d.w*.2,2,d.w*.2,d.h*.36,0,0,Math.PI*2);ctx.ellipse(d.w*.2,2,d.w*.2,d.h*.36,0,0,Math.PI*2);ctx.stroke();ctx.shadowBlur=0;ctx.fillStyle="#362047";ctx.beginPath();ctx.moveTo(-8,-1);ctx.lineTo(-3,7);ctx.lineTo(-11,7);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(5,-1);ctx.lineTo(10,7);ctx.lineTo(2,7);ctx.closePath();ctx.fill();ctx.beginPath();ctx.moveTo(-7,13);ctx.quadraticCurveTo(0,8,8,13);ctx.strokeStyle="#362047";ctx.stroke();ctx.fillStyle="#4fa34b";ctx.fillRect(-2,-d.h*.48,5,9);ctx.restore();
      }else if(d.type.startsWith("ghost")){
        ctx.save();ctx.translate(d.x,d.y+bob);ctx.globalAlpha=.75;ctx.shadowColor=d.type==="ghost1"?"#b8a0ff":"#7bf7ff";ctx.shadowBlur=18;ctx.fillStyle=d.type==="ghost1"?"#c5aaff":"#8cf4ff";ctx.beginPath();ctx.moveTo(-d.w*.35,-d.h*.1);ctx.quadraticCurveTo(-d.w*.48,-d.h*.55,0,-d.h*.48);ctx.quadraticCurveTo(d.w*.45,-d.h*.45,d.w*.35,-d.h*.08);ctx.lineTo(d.w*.35,d.h*.4);ctx.lineTo(d.w*.12,d.h*.25);ctx.lineTo(0,d.h*.42);ctx.lineTo(-d.w*.14,d.h*.25);ctx.lineTo(-d.w*.35,d.h*.4);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.fillStyle="#24123d";ctx.beginPath();ctx.ellipse(-7,-2,3,5,0,0,Math.PI*2);ctx.ellipse(7,-2,3,5,0,0,Math.PI*2);ctx.fill();ctx.restore();
      }else if(d.type==="statue"){
        // Placeholder ornament only: keep the center clear for the user's own statue image.
        ctx.save();ctx.translate(d.x,d.y);ctx.strokeStyle="#d2a0ff";ctx.shadowColor="#a85bff";ctx.shadowBlur=22;ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,55,65,20,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle="#8c54c9";ctx.globalAlpha=.3;ctx.beginPath();ctx.ellipse(0,55,55,14,0,0,Math.PI*2);ctx.fill();ctx.restore();
      }
    });
  }

  function render(){
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,viewW,viewH);

ctx.save();
ctx.scale(ZOOM, ZOOM);
ctx.translate(-camera.x, -camera.y);
    drawFloor();if(currentMap === "halloween")drawHalloweenDecor();obstacles.forEach(drawObstacle);
    
    if(currentMap === "estacao"){
      const signs = [
        {x:270,y:105,text:"LABORATORIO"},
        {x:720,y:115,text:"PESQUISA"},
        {x:1200,y:120,text:"ARQUIVO"},
        {x:390,y:345,text:"SALA DO GERADOR"},
        {x:820,y:390,text:"CONTROLE"},
        {x:290,y:635,text:"ESTUFA"},
        {x:770,y:655,text:"MANUTENCAO"},
        {x:1190,y:700,text:"HELIPONTO"}
      ];

      signs.forEach(sign=>{
        ctx.fillStyle="#071015cc";
        ctx.fillRect(sign.x-75,sign.y-17,150,30);

        ctx.strokeStyle="#82969a";
        ctx.lineWidth=1;
        ctx.strokeRect(sign.x-75,sign.y-17,150,30);

        ctx.fillStyle="#d6e2df";
        ctx.font="bold 11px monospace";
        ctx.textAlign="center";
        ctx.textBaseline="middle";
        ctx.fillText(sign.text,sign.x,sign.y-2);
      });

      ctx.textBaseline="alphabetic";
    }

    // Hitbox quadrada à frente do Killer, visível por 0,25 s após o delay de 0,15 s.
    if(activeHitbox&&activeHitbox.visible>0){
      const a=activeHitbox.angle, range=activeHitbox.range, size=activeHitbox.size;
      ctx.save();ctx.translate(killer.x,killer.y);ctx.rotate(a);
      ctx.fillStyle="#ff2020a0";ctx.strokeStyle="#ff3939";ctx.lineWidth=2;
      ctx.fillRect(killer.r, -size/2, range, size);ctx.strokeRect(killer.r, -size/2, range, size);ctx.restore();
    }
    if(selected===0&&stabDash.phase){
      ctx.save();ctx.translate(killer.x,killer.y);
      if(stabDash.phase==="prepare"){
        const pulse=.75+Math.sin(elapsed*28)*.18;ctx.strokeStyle="#ff9d32";ctx.lineWidth=3;ctx.globalAlpha=.85;
        ctx.beginPath();ctx.arc(0,0,killer.r+8*pulse,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=.95;ctx.strokeStyle="#ffb347";ctx.lineWidth=4;
        ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(stabDash.x*400,stabDash.y*400);ctx.stroke();
        ctx.globalAlpha=.16;ctx.fillStyle="#ff9d32";ctx.beginPath();ctx.arc(0,0,killer.r+8,0,Math.PI*2);ctx.fill();
      }else{
        ctx.rotate(Math.atan2(stabDash.y,stabDash.x));
        ctx.globalAlpha=.34;ctx.fillStyle="#ff9d32";ctx.strokeStyle="#ffd09a";ctx.lineWidth=3;
        ctx.fillRect(killer.r-2,-killer.r*.72,58,killer.r*1.44);ctx.strokeRect(killer.r-2,-killer.r*.72,58,killer.r*1.44);
      }
      ctx.restore();
    }
    if(selected===1&&(jjBlast.phase==="charge"||jjBlast.explosionTimer>0)){
      ctx.save();ctx.translate(killer.x,killer.y);
      if(jjBlast.phase==="charge"){
        const progress=1-jjBlast.timer/2;
        const blinking=jjBlast.timer<.6&&Math.floor(elapsed*14)%2===0;
        ctx.globalAlpha=blinking?.95:.15+progress*.5;ctx.fillStyle="#ff1010";
        ctx.beginPath();ctx.arc(0,0,jjBlast.radius,0,Math.PI*2);ctx.fill();
        ctx.globalAlpha=.5+progress*.5;ctx.strokeStyle="#ff3030";ctx.lineWidth=3+progress*3;
        ctx.beginPath();ctx.arc(0,0,jjBlast.radius,0,Math.PI*2);ctx.stroke();
      }
      if(jjBlast.explosionTimer>0){
        const progress=1-jjBlast.explosionTimer/.35;
        ctx.globalAlpha=jjBlast.explosionTimer/.35;ctx.fillStyle="#ff2020";
        ctx.beginPath();ctx.arc(0,0,jjBlast.radius*(.65+progress*.35),0,Math.PI*2);ctx.fill();
        ctx.strokeStyle="#ff7777";ctx.lineWidth=5;ctx.beginPath();
        ctx.arc(0,0,jjBlast.radius*(.65+progress*.35),0,Math.PI*2);ctx.stroke();
      }
      ctx.restore();
    }
    if(selected===2&&hackerHand.phase){
      ctx.save();
      ctx.strokeStyle="#53c8d4";ctx.lineWidth=9;ctx.lineCap="round";ctx.globalAlpha=.9;
      ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(hackerHand.x,hackerHand.y);ctx.stroke();
      ctx.strokeStyle="#b8fbff";ctx.lineWidth=3;ctx.globalAlpha=.95;
      ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(hackerHand.x,hackerHand.y);ctx.stroke();
      ctx.translate(hackerHand.x,hackerHand.y);ctx.rotate(Math.atan2(hackerHand.dirY,hackerHand.dirX));
      ctx.fillStyle="#263b45";ctx.strokeStyle="#7af0ff";ctx.lineWidth=3;
      ctx.beginPath();ctx.arc(0,0,13,0,Math.PI*2);ctx.fill();ctx.stroke();
      ctx.beginPath();ctx.moveTo(4,-7);ctx.lineTo(19,-12);ctx.lineTo(22,-7);ctx.moveTo(4,7);ctx.lineTo(19,12);ctx.lineTo(22,7);ctx.stroke();
      ctx.restore();
    }
    if(selected===4&&wesleyDash.phase){
      ctx.save();ctx.translate(killer.x,killer.y);
      if(wesleyDash.phase==="prepare"){
        ctx.strokeStyle="#bda7ff";ctx.lineWidth=4;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(wesleyDash.x*260,wesleyDash.y*260);ctx.stroke();
        ctx.fillStyle="#a68aff";ctx.globalAlpha=.2;ctx.beginPath();ctx.arc(0,0,killer.r+8,0,Math.PI*2);ctx.fill();
      }else{
        ctx.rotate(Math.atan2(wesleyDash.y,wesleyDash.x));ctx.globalAlpha=.38;ctx.fillStyle="#a68aff";ctx.strokeStyle="#e0d7ff";ctx.lineWidth=3;
        ctx.fillRect(killer.r-2,-killer.r*.78,48,killer.r*1.56);ctx.strokeRect(killer.r-2,-killer.r*.78,48,killer.r*1.56);
      }
      ctx.restore();
    }
    if(selected===3&&sixerH1.phase){
      ctx.save();
      if(sixerH1.phase==="prepare"){
        ctx.strokeStyle="#ff263f";ctx.lineWidth=4;ctx.globalAlpha=.9;ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(killer.x+sixerH1.dirX*330,killer.y+sixerH1.dirY*330);ctx.stroke();
        ctx.fillStyle="#ff263f";ctx.globalAlpha=.12;ctx.beginPath();ctx.arc(killer.x,killer.y, killer.r+13,0,Math.PI*2);ctx.fill();
      }else if(sixerH1.phase==="dash"){
        const hx=killer.x+sixerH1.dirX*20,hy=killer.y+sixerH1.dirY*20;ctx.translate(hx,hy);ctx.rotate(Math.atan2(sixerH1.dirY,sixerH1.dirX));
        ctx.fillStyle="#ff263f88";ctx.strokeStyle="#ff344d";ctx.lineWidth=3;ctx.fillRect(-8,-31,75,62);ctx.strokeRect(-8,-31,75,62);
      }else if(sixerH1.phase==="combo"&&sixerH1.hitboxTimer>0){
        const target=survivors.find(s=>s.id===sixerH1.targetId&&s.alive);if(target){ctx.fillStyle="#ff263fa8";ctx.strokeStyle="#ffb0b8";ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(target.x,target.y,30,22,Math.atan2(sixerH1.dirY,sixerH1.dirX),0,Math.PI*2);ctx.fill();ctx.stroke();}
      }
      ctx.restore();
    }
    if(selected===3&&sixerH2.phase){
      ctx.save();
      if(sixerH2.phase==="jump"){
        ctx.globalAlpha=.45;ctx.strokeStyle="#ff6633";ctx.lineWidth=4;ctx.beginPath();ctx.ellipse(killer.x,killer.y+12, killer.r+8,killer.r*.55+8,0,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=.7;ctx.fillStyle="#ff6633";ctx.beginPath();ctx.arc(killer.x,killer.y-sixerH2.jumpY,killer.r*.72,0,Math.PI*2);ctx.fill();
      }else if(sixerH2.phase==="wave"){
        ctx.globalAlpha=.36;ctx.fillStyle="#ff6633";ctx.beginPath();ctx.arc(sixerH2.waveX,sixerH2.waveY,sixerH2.waveRadius,0,Math.PI*2);ctx.fill();
        ctx.globalAlpha=.95;ctx.strokeStyle="#ffb078";ctx.lineWidth=4;ctx.beginPath();ctx.arc(sixerH2.waveX,sixerH2.waveY,sixerH2.waveRadius,0,Math.PI*2);ctx.stroke();
        ctx.globalAlpha=.65;ctx.strokeStyle="#ff6633";ctx.lineWidth=2;ctx.beginPath();ctx.arc(sixerH2.waveX,sixerH2.waveY,sixerH2.waveRadius+9,0,Math.PI*2);ctx.stroke();
      }
      ctx.restore();
    }
    if(selected===5&&skeletonH1.phase){
      ctx.save();ctx.globalAlpha=.72;ctx.strokeStyle="#ffffff";ctx.fillStyle="#ffffff";ctx.lineWidth=3;
      if(skeletonH1.phase==="capture"&&skeletonH1.hitboxTime>0){ctx.beginPath();ctx.arc(killer.x,killer.y,killer.r+25,0,Math.PI*2);ctx.fillStyle="#ffffff22";ctx.fill();ctx.stroke();}
      if(skeletonH1.phase==="dash"){ctx.beginPath();ctx.moveTo(killer.x,killer.y);ctx.lineTo(killer.x+skeletonH1.dirX*90,killer.y+skeletonH1.dirY*90);ctx.stroke();}
      ctx.restore();
    }
    if(selected===5&&skeletonH2.phase==="projectile"){
      ctx.save();ctx.globalAlpha=.78;ctx.fillStyle="#17131f";ctx.strokeStyle="#62566f";ctx.lineWidth=3;ctx.beginPath();ctx.arc(skeletonH2.x,skeletonH2.y,17,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.globalAlpha=.35;ctx.beginPath();ctx.arc(skeletonH2.x,skeletonH2.y,26,0,Math.PI*2);ctx.fill();ctx.restore();
    }
    // Auras pulsantes e discretas enquanto habilidades de Killer estão ativas.
    const auraColor = selected===0&&stabDash.phase ? "#ff9d32" : selected===1&&(jjBlast.phase==="charge"||jjBlast.explosionTimer>0) ? "#ff263f" : selected===2&&hackerHand.phase ? "#53c8d4" : selected===4&&wesleyDash.phase ? "#a68aff" : selected===5&&skeletonH1.phase ? "#e9e9ff" : selected===5&&skeletonH2.phase==="projectile" ? "#9d79d8" : selected===3&&(sixerH1.phase||sixerH2.phase) ? "#ff6633" : null;
    if(auraColor&&killer){ctx.save();ctx.globalCompositeOperation="lighter";ctx.globalAlpha=.18+.12*Math.sin(elapsed*16);ctx.strokeStyle=auraColor;ctx.lineWidth=5;ctx.beginPath();ctx.arc(killer.x,killer.y,killer.r+12+Math.sin(elapsed*12)*4,0,Math.PI*2);ctx.stroke();ctx.globalAlpha=.08;ctx.fillStyle=auraColor;ctx.beginPath();ctx.arc(killer.x,killer.y,killer.r+10,0,Math.PI*2);ctx.fill();ctx.restore();}
    survivors.forEach(s=>{if(!s.alive)return;
      if(s.healerTimer>0){ctx.save();ctx.globalAlpha=.18;ctx.fillStyle="#40ff8a";ctx.strokeStyle="#71ffad";ctx.lineWidth=3;ctx.beginPath();ctx.arc(s.x,s.y,105,0,Math.PI*2);ctx.fill();ctx.globalAlpha=.65;ctx.stroke();ctx.restore();}
      if(s.defenseTimer>0){ctx.save();ctx.globalAlpha=.55;ctx.fillStyle="#4bbcff";ctx.strokeStyle="#a4e8ff";ctx.lineWidth=3;ctx.beginPath();ctx.arc(s.x,s.y,39,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.restore();}
      if(s.clownTimer>0&&s.clownHitbox){ctx.save();const h=s.clownHitbox;ctx.translate(s.x,s.y);ctx.rotate(h.angle);ctx.globalAlpha=.30;ctx.fillStyle="#ffd24b";ctx.fillRect(-8,-h.width/2,h.range,h.width);ctx.globalAlpha=.95;ctx.strokeStyle="#ffd24b";ctx.lineWidth=3;ctx.strokeRect(-8,-h.width/2,h.range,h.width);for(let i=0;i<12;i++){const px=randStatic(i,4,h.range-4),py=randStatic(i+20,-h.width/2,h.width/2);ctx.fillStyle=["#ff4f87","#ffe45b","#59e7ff","#b78cff"][i%4];ctx.fillRect(px,py,4,4);}ctx.restore();}
      if(s.punchTimer>0&&s.punchHitbox){ctx.save();const h=s.punchHitbox;ctx.translate(s.x,s.y);ctx.rotate(h.angle);ctx.globalAlpha=.30;ctx.fillStyle="#35bfff";ctx.fillRect(-8,-h.width/2,h.range,h.width);ctx.globalAlpha=.95;ctx.strokeStyle="#8bdcff";ctx.lineWidth=4;ctx.strokeRect(-8,-h.width/2,h.range,h.width);ctx.strokeStyle="#e6faff";ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(h.range-10,-h.width/2+5);ctx.lineTo(h.range+4,0);ctx.lineTo(h.range-10,h.width/2-5);ctx.stroke();ctx.restore();}
      ctx.save();if(s.name==="GhostGirl"&&s.ghostTimer>0)ctx.globalAlpha=(gameMode==="killer"?0:.38);drawPerson(s,"survivor","#58d39b",s.name,s.hp,s.maxHp,s.angle);ctx.restore();
    });
    drawPerson(killer,"killer",killers[selected].color,killers[selected].name,killer.hp,killer.maxHp,killer.angle);
    particles.forEach(p=>{ctx.globalAlpha=clamp(p.life/p.max,0,1);if(p.glow){ctx.shadowColor=p.color;ctx.shadowBlur=12;}ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;});ctx.globalAlpha=1;
    ctx.restore();
    // stamina bar at the bottom of the arena.
    const barW=Math.min(180,viewW*.4),bx=(viewW-barW)/2,by=viewH-18;
    ctx.fillStyle="#0009";ctx.fillRect(bx-2,by-2,barW+4,9);ctx.fillStyle="#303440";ctx.fillRect(bx,by,barW,5);
    const staminaEntity=gameMode==="survivor"&&playerSurvivor?playerSurvivor:killer;
    ctx.fillStyle="#6fc8ed";ctx.fillRect(bx,by,barW*(staminaEntity.stamina/staminaEntity.maxStamina),5);
    ctx.fillStyle="#c3cbd8";ctx.font="9px Inter";ctx.textAlign="center";ctx.fillText("STAMINA",viewW/2,by-5);
    if(selected===0){
      const ready=stabDash.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready?"#ff6674":"#d0d4dc";
      ctx.fillText(`Q • SHADOW DASH ${ready?"PRONTO":stabDash.cooldown.toFixed(1)+"s"}`,viewW-12,22);
    }else if(selected===1){
      const ready=jjBlast.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready?"#ff6674":"#d0d4dc";
      ctx.fillText(`E • SOBRECARGA ${ready?"PRONTO":jjBlast.cooldown.toFixed(1)+"s"}`,viewW-12,22);
    }else if(selected===2){
      const ready=hackerHand.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready?"#65e8f5":"#d0d4dc";
      ctx.fillText(`E • BRAÇO ROBÓTICO ${ready?"PRONTO":hackerHand.cooldown.toFixed(1)+"s"}`,viewW-12,22);
        }else if(selected===3){
      const ready1=sixerH1.cooldown<=0,ready2=sixerH2.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";
      ctx.fillStyle=ready1?"#ff6674":"#d0d4dc";ctx.fillText(`Q • INVESTIDA ${ready1?"PRONTA":sixerH1.cooldown.toFixed(1)+"s"}`,viewW-12,22);
      ctx.fillStyle=ready2?"#ff9a66":"#d0d4dc";ctx.fillText(`E • IMPACTO ${ready2?"PRONTO":sixerH2.cooldown.toFixed(1)+"s"}`,viewW-12,39);
    }else if(selected===5){
      const ready1=skeletonH1.cooldown<=0,ready2=skeletonH2.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";ctx.fillStyle=ready1?"#ffffff":"#d0d4dc";ctx.fillText(`Q • H1 CAPTURA ${ready1?"PRONTA":skeletonH1.cooldown.toFixed(1)+"s"}`,viewW-12,22);ctx.fillStyle=ready2?"#8b7b9d":"#d0d4dc";ctx.fillText(`E • H2 SOMBRA NEGRA ${ready2?"PRONTA":skeletonH2.cooldown.toFixed(1)+"s"}`,viewW-12,39);
    }else if(selected===4){
      const ready=wesleyDash.cooldown<=0;ctx.textAlign="right";ctx.font="bold 11px Inter";ctx.fillStyle=ready?"#c4b5fd":"#d0d4dc";ctx.fillText(`Q • INVESTIDA BRUTAL ${ready?"PRONTA":wesleyDash.cooldown.toFixed(1)+"s"}`,viewW-12,22);
    }
  }
  function loop(now){
    if(!running)return;
    const dt=Math.min((now-lastTime)/1000,.035);lastTime=now;
    update(dt);render();
    if(running)requestAnimationFrame(loop);
  }
  function goMenu(){running=false;ended=false;gameScreen.classList.add("hidden");selectScreen.classList.remove("hidden");$("attackTouch").classList.remove("hidden");setGameMode(gameMode);}
  $("killerModeButton").addEventListener("click",()=>setGameMode("killer"));
  $("survivorModeButton").addEventListener("click",()=>setGameMode("survivor"));
  $("startButton").addEventListener("click",startGame);
  $("restartButton").addEventListener("click",startGame);
  $("menuButton").addEventListener("click",goMenu);
  $("backButton").addEventListener("click",goMenu);
  window.addEventListener("resize",()=>{if(!gameScreen.classList.contains("hidden"))resizeCanvas();});
  window.addEventListener("keydown",e=>{
    const key=e.key.toLowerCase();
    if(["arrowup","arrowdown","arrowleft","arrowright"," "].includes(key))e.preventDefault();
    keys.add(key);
    if(key===" "&&!e.repeat)doAttack();
    if(key==="q"&&!e.repeat&&gameMode==="survivor"){activateSurvivorSkill(1);}
    else if(key==="q"&&!e.repeat){if(selected===0)activateStabDash();else if(selected===3)activateSixerH1();else if(selected===4)activateWesleyDash();else if(selected===5)activateSkeletonH1();}
    if(key==="e"&&!e.repeat&&gameMode==="survivor"){activateSurvivorSkill(2);}
    else if(key==="e"&&!e.repeat){if(selected===1)activateJJBlast();else if(selected===2)activateHackerHand();else if(selected===3)activateSixerH2();else if(selected===5)activateSkeletonH2();}
  });
  window.addEventListener("keyup",e=>keys.delete(e.key.toLowerCase()));
  window.addEventListener("blur",()=>keys.clear());
  $("attackTouch").addEventListener("pointerdown",e=>{e.preventDefault();doAttack();});
  $("skillTouch").addEventListener("pointerdown",e=>{
    e.preventDefault();
    if(gameMode==="survivor"){activateSurvivorSkill(1);return;}
    if(selected===0)activateStabDash();
    else if(selected===1)activateJJBlast();
    else if(selected===2)activateHackerHand();
    else if(selected===3)activateSixerH1();
    else if(selected===4)activateWesleyDash();else if(selected===5)activateSkeletonH1();
  });
  $("skill2Touch").addEventListener("pointerdown",e=>{e.preventDefault();if(gameMode==="survivor"){activateSurvivorSkill(2);return;}if(selected===3)activateSixerH2();else if(selected===5)activateSkeletonH2();});
  $("sprintTouch").addEventListener("pointerdown",e=>{
    e.preventDefault();
    touch.sprint=!touch.sprint; // Toque para ativar, outro toque para desativar.
    $("sprintTouch").classList.toggle("active",touch.sprint);
    $("sprintTouch").setAttribute("aria-pressed",String(touch.sprint));
  });
  const joystick=$("joystick"),stick=$("stick");
  joystick.addEventListener("pointerdown",e=>{joyActive=true;joystick.setPointerCapture(e.pointerId);const r=joystick.getBoundingClientRect();joyCenter={x:r.left+r.width/2,y:r.top+r.height/2};updateJoy(e);});
  joystick.addEventListener("pointermove",e=>{if(joyActive)updateJoy(e);});
  function updateJoy(e){const dx=e.clientX-joyCenter.x,dy=e.clientY-joyCenter.y,len=Math.hypot(dx,dy),max=25,scale=len>max?max/len:1;touch.x=dx*scale/max;touch.y=dy*scale/max;stick.style.left=`${25+dx*scale}px`;stick.style.top=`${25+dy*scale}px`;}
  function resetJoy(){joyActive=false;touch.x=0;touch.y=0;stick.style.left="25px";stick.style.top="25px";}
  ["pointerup","pointercancel","lostpointercapture"].forEach(ev=>joystick.addEventListener(ev,resetJoy));
  buildSelection();
  setGameMode("killer");updateMoneyUI();
})();