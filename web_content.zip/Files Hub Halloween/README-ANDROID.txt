ASYM 2D Android Base (WebView)
==============================

Esta é uma base de projeto Android Studio para empacotar a versão mais recente disponível do ASYM 2D, baseada no arquivo ASYM2D_Killer_Stun_Parado.zip (23/10/2026). Os arquivos HTML, CSS, JavaScript e imagens foram copiados para app/src/main/assets, mantendo o jogo web e a correção de stun dessa versão-base.

IMPORTANTE
- Este arquivo é um projeto-fonte Android Studio, não um APK compilado.
- Para gerar o APK, abra a pasta ASYM2D_Android no Android Studio.
- Aguarde o Gradle Sync e, se necessário, instale o Android SDK Platform 35 e o Android Gradle Plugin compatível.
- Use Build > Build Bundle(s) / APK(s) > Build APK(s).
- O APK de debug normalmente aparece em app/build/outputs/apk/debug/app-debug.apk.

Estrutura principal
- app/src/main/java/com/asym2d/game/MainActivity.java: abre o jogo em uma WebView em tela cheia.
- app/src/main/assets/index.html: página inicial do jogo.
- app/src/main/assets/style.css: interface e estilos.
- app/src/main/assets/game.js: lógica do jogo.
- app/src/main/assets/assets/: imagens do jogo.

Requisitos configurados
- minSdk 23 (Android 6.0 ou superior)
- compileSdk 35
- orientação paisagem

Observação: a base foi montada a partir do ZIP mais recente identificado no histórico como ASYM2D_Killer_Stun_Parado.zip. O jogo não foi executado em um emulador nem o APK foi compilado nesta sessão.
