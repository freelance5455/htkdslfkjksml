# CPLS V2 — Stage 1138

## Candle Gap Integrity
- Adds non-destructive gap statistics for generated Futures candles.
- Detects abnormal time gaps without fabricating missing candles.
- Reports the largest detected gap in the Futures status message.
- Preserves the existing LBank transport, OHLC merge, viewport, zoom/pan and live continuity behavior.

Source ZIP stage only; APK build not performed.
