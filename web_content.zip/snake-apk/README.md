# Snake: final package

A finished game with nothing external: one `index.html`, a manifest, an offline cache and icons.

## What is inside
- `www/` the game itself (open `www/index.html` in any browser to play)
- `assets/` icon and splash sources for the Android build
- `capacitor.config.json`, `package.json` the wrapper that turns `www/` into an Android app

## Build the APK (Capacitor)
You need Node.js and Android Studio installed on a computer.

```
npm install
npx cap add android
npm run icons        # makes every Android icon and splash size from assets/
npx cap sync android
npx cap open android
```
In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The file lands in
`android/app/build/outputs/apk/debug/`. Copy it to your phone and open it
(allow "install unknown apps" when asked).

Before you publish anywhere: change `appId` in `capacitor.config.json` (it is `com.subway.snake`
as a placeholder) and sign a release build.

## No computer? Other routes
- **PWA route:** upload the contents of `www/` to any https host (GitHub Pages works), open it in
  Chrome on your phone and choose "Install app". It then runs full screen and offline.
- **APK from a PWA:** paste that https address into PWABuilder (pwabuilder.com) and download an Android package.

## Notes
- Best scores and settings use `localStorage`. Capacitor keeps it between launches.
- Sound is generated in code, so there are no audio files to ship.
- The game is portrait only and plays with swipes.
