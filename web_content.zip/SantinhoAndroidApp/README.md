# Santinho — Inteligência Financeira

Projeto Android do aplicativo **Santinho — Inteligência Financeira**, criado por **Nilson Junior**.

## Versão limpa para compartilhamento
Esta versão inicia sem transações, carteira de investimentos, recorrências ou histórico patrimonial pré-cadastrados. Cada usuário começa com seus próprios dados.

O app usa o HTML local em `app/src/main/assets/index.html`.

## Gerar APK
Abra a pasta no Android Studio e use:

**Build → Build APK(s)**

## Gerar AAB para publicação
Use:

**Build → Generate Signed Bundle / APK → Android App Bundle**
