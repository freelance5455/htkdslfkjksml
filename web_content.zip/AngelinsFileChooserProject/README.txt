ANGELINS APP - PROJECTO COM SELETOR NATIVO DE FICHEIROS

Este projeto usa WebView com WebChromeClient.onShowFileChooser para permitir que os campos de ficheiro HTML abram o seletor nativo do Android.

Coloque/abra esta pasta num ambiente Android/Gradle compatível e compile o APK.
A página está em app/src/main/assets/index.html.
