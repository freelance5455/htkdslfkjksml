# SONIK — Local Prototype Starter

A responsive, no-ad music discovery / creator-streaming interface prototype.

## Run it
- Extract the ZIP.
- Open `index.html` in a modern browser, or serve the folder with any simple static web server.
- On Android, extract the ZIP and open `index.html` in Chrome (a local file manager may be needed).

## Working in this prototype
- Responsive Discover, Explore/Search, Library, Upload, Creator Studio, Trust & Copyright, and Settings views.
- Shared player controls with simulated playback for seeded sample tracks. There is no bundled commercial music.
- Likes, listening history, playlists, profile name, local upload metadata, and notice/report forms persist in the browser's localStorage.
- Local data export and reset.
- Uploads are marked Pending review and are not published. Audio files are not sent to a server.

## Not implemented / not production-ready
- Real audio assets for seeded tracks; player timeline is simulated unless a safe audio file URL is deliberately added by a developer.
- Real authentication, database, object storage, secure signed URLs, transcoding, CDN, rate limiting, abuse prevention, admin authorization, or multi-device sync.
- Actual audio fingerprinting / rights-recognition provider integration.
- Delivery of reports, takedown notices, or counter-notices to a legal agent; all are saved locally only.
- Real moderation, legal verification, royalty accounting, payouts, analytics, or app-store certification.

## Production checklist
1. Set up Supabase Auth/PostgreSQL/Storage (or equivalent), server-side authorization, migrations, and row-level security.
2. Keep uploads private in quarantine; validate type, size, checksum and scan; transcode with a server-side job; publish only after rights and moderation approval.
3. Integrate rights-recognition provider only with valid credentials and tested coverage; use matches as review signals, not legal verdicts.
4. Implement auditable human review, takedown/counter-notice workflows, repeat-infringer policy, evidence retention, account appeals and playback/CDN revocation.
5. Have qualified counsel review Terms, Privacy, Copyright Policy, agent designation/registration, local laws and launch jurisdictions.
6. Implement app-store UGC reporting/blocking/moderation requirements and test security, accessibility, performance and data deletion.

This starter is a product prototype, not legal advice or a claim of copyright compliance.

## Update: searchable song examples
The prototype now includes two searchable song entries:
- **El Bosla Da3et · البوصلة ضاعت** — Marwan Moussa
- **Kan Lak Maaya · كان لك معايا** — Cairokee

Selecting either track opens an embedded YouTube player for the surfaced official artist upload. Playback depends on internet access and YouTube allowing the embed in your browser/region. The recordings are played by YouTube; SONIK does not host the copyrighted audio. Use the YouTube controls inside the player window. Other sample tracks remain UI demos unless you attach audio you own or are licensed to use.

## Offline audio saving

Track cards include **Save offline**. This stores a direct audio file in browser IndexedDB when the source permits fetching it, so it can be replayed offline in the same browser. YouTube video embeds cannot be downloaded by SONIK; use authorized direct audio files or music you have permission to store. Browser storage can be cleared by the user or the operating system.
