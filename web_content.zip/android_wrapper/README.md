# Android WebView wrapper

1. Deploy the Flask web app first and obtain its HTTPS URL.
2. Replace `https://YOUR-DEPLOYED-SITE.example` in `app/src/main/java/com/vetri/ai/MainActivity.kt`.
3. Open this `android_wrapper` folder in Android Studio on a computer.
4. Let Gradle sync, then choose Build > Build APK(s).
5. Install the generated debug APK on your Android device.

This wrapper loads the hosted website. It does not contain your OpenAI API key and does not run the Python server itself.
