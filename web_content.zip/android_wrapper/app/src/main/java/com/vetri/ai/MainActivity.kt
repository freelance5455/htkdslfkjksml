package com.vetri.ai

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)

        // Replace this with your deployed HTTPS URL before building the APK.
        val appUrl = "https://YOUR-DEPLOYED-SITE.example"
        if (appUrl.contains("YOUR-DEPLOYED-SITE")) {
            Toast.makeText(this, "Set your deployed Vetri AI URL in MainActivity.kt first.", Toast.LENGTH_LONG).show()
        } else {
            webView.loadUrl(appUrl)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
