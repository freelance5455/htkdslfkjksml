# MR KHORASANI Finance — Android APK Wrapper

این پوشه یک پروژه Android Studio آماده برای بسته‌بندی نسخه build‌شده MR KHORASANI Finance است.

نکات فنی:
- Application ID: `com.mrkhrasani.finance`
- Version: `1.0.0`
- Minimum Android: API 24
- Target/Compile SDK: 35
- داده‌های حالت Offline در storage خود WebView نگهداری می‌شوند.
- منطق مالی از build موجود پروژه استفاده می‌کند و دوباره‌نویسی نشده است.

### ساخت APK روی Android Studio
پروژه را باز کنید و از مسیر **Build > Build APK(s)**، نسخه Debug را بسازید.

برای Release، باید با keystore مالک سامانه امضا شود.

### ساخت خودکار با GitHub Actions
فایل `.github/workflows/android-debug.yml` برای ساخت `app-debug.apk` در یک runner لینوکس آماده شده است.

### نکته درباره APK فعلی
در محیط اجرایی این گفتگو Android SDK/Build Tools و Gradle نصب نبودند و دسترسی مستقیم به مخزن‌های دانلود باینری نیز ممکن نبود؛ بنابراین به‌جای ساختن یک فایل APK صوری یا ناقص، پروژه Android واقعی و قابل build آماده شده است.
