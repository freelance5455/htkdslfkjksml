# CPLS V2 — Stage 1128

## Futures chart precision and mobile stability
- Hardened automatic price-axis padding for very small and very large price ranges.
- Kept the live-price line inside a readable dynamic range instead of letting it collapse the chart scale.
- Normalized price-grid tick generation.
- Cleared stale candle selection when switching timeframe.
- Added mobile tooltip height clamping to keep candle details inside the chart viewport.
- Preserved Stage 1127 zoom, pan, candle selection and REST Futures feed.
- No undocumented Futures WebSocket subscription was introduced.
