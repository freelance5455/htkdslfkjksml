package com.meuorcamento.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.Context;
import android.view.Window;
import android.webkit.*;
import android.widget.Toast;
import android.hardware.biometrics.BiometricPrompt;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import java.security.KeyStore;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class MainActivity extends Activity {
  WebView web;
  Executor executor;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    executor = Executors.newSingleThreadExecutor();
    web = new WebView(this);
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setMediaPlaybackRequiresUserGesture(true);
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new NativeBridge(this), "AndroidNative");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
  }

  private SecretKey getOrCreateKey() throws Exception {
    KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
    ks.load(null);
    String alias = "MeuOrcamentoBiometricKeyV4";
    if (!ks.containsAlias(alias)) {
      KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
      kg.init(new KeyGenParameterSpec.Builder(alias,
          KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
          .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
          .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
          .setUserAuthenticationRequired(true)
          .build());
      kg.generateKey();
    }
    return (SecretKey) ks.getKey(alias, null);
  }

  public void biometric() {
    if (Build.VERSION.SDK_INT < 28) {
      toast("Biometria requer Android 9 ou superior.");
      return;
    }
    try {
      SecretKey key = getOrCreateKey();
      Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
      cipher.init(Cipher.ENCRYPT_MODE, key);
      BiometricPrompt prompt = new BiometricPrompt.Builder(this)
          .setTitle("Meu Orçamento")
          .setSubtitle("Desbloquear aplicativo")
          .setDescription("Confirme sua identidade usando a biometria cadastrada neste aparelho.")
          .setNegativeButton("Usar PIN", executor, (d, w) -> {})
          .build();
      prompt.authenticate(new BiometricPrompt.CryptoObject(cipher), executor,
          new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r) {
              runOnUiThread(() -> web.evaluateJavascript("window.onNativeBiometric(true)", null));
            }
            @Override public void onAuthenticationFailed() {
              runOnUiThread(() -> web.evaluateJavascript("window.onNativeBiometric(false)", null));
            }
            @Override public void onAuthenticationError(int code, CharSequence msg) {
              runOnUiThread(() -> web.evaluateJavascript("window.onNativeBiometric(false)", null));
            }
          });
    } catch (Exception e) {
      toast("Biometria indisponível. Cadastre uma digital ou rosto nas configurações do Android.");
      runOnUiThread(() -> web.evaluateJavascript("window.onNativeBiometric(false)", null));
    }
  }

  void toast(String x) {
    runOnUiThread(() -> Toast.makeText(this, x, Toast.LENGTH_LONG).show());
  }

  public class NativeBridge {
    Context c;
    NativeBridge(Context x) { c = x; }
    @JavascriptInterface public void authenticateBiometric() { biometric(); }
    @JavascriptInterface public boolean isBiometricAvailable() {
      return Build.VERSION.SDK_INT >= 28;
    }
    @JavascriptInterface public void setSecureFlag(boolean on) {
      runOnUiThread(() -> {
        if (on) getWindow().addFlags(WindowManagerFlag.SECURE);
        else getWindow().clearFlags(WindowManagerFlag.SECURE);
      });
    }
  }

  static class WindowManagerFlag { static final int SECURE = 8192; }

  @Override public void onBackPressed() {
    if (web.canGoBack()) web.goBack(); else super.onBackPressed();
  }

  @Override protected void onDestroy() {
    if (executor instanceof java.util.concurrent.ExecutorService) {
      ((java.util.concurrent.ExecutorService) executor).shutdownNow();
    }
    super.onDestroy();
  }
}
