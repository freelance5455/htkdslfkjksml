# Meu Orçamento v4 — APK Android nativo único

Esta versão elimina a necessidade de um segundo “APK nativo”. A biometria é chamada diretamente pelo próprio aplicativo Android usando a API de biometria do sistema e Android Keystore.

## O que instalar
Somente o APK gerado deste projeto. Não existe aplicativo auxiliar de biometria.

## Gerar pelo celular
1. Extraia este ZIP.
2. Abra a pasta `MeuOrcamento` em um IDE Android para celular (por exemplo, AndroidIDE).
3. Aguarde a sincronização do Gradle.
4. Gere o APK de debug pelo menu de Build.
5. Instale o APK no aparelho.

O projeto usa Android Gradle Plugin 8.7.3, compile/target SDK 35 e mínimo Android 9 (API 28). O IDE pode precisar baixar componentes do Android/Gradle na primeira compilação.

## Biometria
- Abra Configurações dentro do Meu Orçamento.
- Toque em “Ativar biometria”.
- O Android exibirá a tela real de autenticação biométrica.
- Depois de ativada, a biometria será solicitada ao iniciar o app.
- O PIN do aplicativo continua sendo o fallback.
- A digital/rosto não é armazenada pelo app.

## Segurança
A chave usada para a autenticação é mantida no Android Keystore. A proteção contra captura de tela usa FLAG_SECURE. Os dados financeiros permanecem locais no WebView.

## Conteúdo
Inclui cartões, compras parceladas/recorrentes, orçamento por categoria, metas, calendário, análise mensal, visão futura de 60 dias, backup normal, backup criptografado, CSV, relatório para PDF, PIN, biometria e modo escuro.
