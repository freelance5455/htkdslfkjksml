MI BOLSILLO — aplicación web móvil
==================================
Incluye:
- Inicio con saldo total y cuentas separadas (banco / efectivo).
- Ingresos, gastos, retiro del banco a efectivo.
- Registro de sueldo, bonos y próximo sueldo.
- Deudas con pagos parciales e historial.
- Préstamos realizados y recibidos, con cobros/devoluciones y pagos.
- Ahorros, meta de ahorro e historial.
- Universidad: presupuesto semanal y mensual, pasajes, desayuno y otros; gastos universitarios con cuenta y fecha; historial y progreso.
- Historial de movimientos y reportes por categoría.
- Exportación de respaldo en JSON y configuración.

Cómo usar:
1. Extrae el ZIP.
2. Abre index.html en un navegador moderno para probarlo.
3. Para APK, importa el archivo/carpeta en tu herramienta de WebView o empaquetado web.

Importante:
- Este paquete contiene la app web, no un APK compilado.
- Los datos se guardan en el almacenamiento local del navegador/dispositivo.
- No se conecta a cuentas bancarias ni mueve dinero real. Registra manualmente tus operaciones.
- Exporta un respaldo periódicamente para proteger tus datos.
