TUITION MANAGER PRO — FRESH MINT & EMERALD GREEN BUILD

Default student profiles:
1. Sahid — LKG — 2:00 PM — 24-class monthly target — ₹2,000 monthly fee
2. Ayeman — UKG — 4:00 PM — 24-class monthly target — ₹2,300 monthly fee
3. Mim & Arifa — Class 7 & 9 · Maths — 6:00 PM — 24-class monthly target — ₹3,000 monthly fee
Mim & Arifa is ONE combined profile, not two separate students.

WORKING PAGES
- Home: today's attendance summary and quick attendance buttons.
- Students: search, add, edit and delete profiles; each profile has its own target and monthly fee.
- Calendar: monthly calendar, select any date, view/mark attendance for that date. Colored dots show attendance states.
- Reports: monthly class counts, student-wise target progress, CSV export.
- Fees & Accounts: record cash/online payments, calculate paid and outstanding balance for the selected month.
- More: JSON backup/restore, CSV export and clear app data.

HOW TO RUN
1. Extract the ZIP.
2. Open index.html in Chrome.
3. Use the bottom navigation.

DATA & LIMITATIONS
- App data is saved in browser localStorage on this device.
- Export JSON backups regularly. Browser data clearing can erase app data.
- No cloud sync, login, push notifications, or multi-device sync in this build.
- Monthly target progress counts classes marked Attended in the selected calendar month.
- Monthly fee balance is calculated from payments recorded during the selected month.
- This is a mobile-friendly web app; it is not an Android APK.

VISUAL THEME
- Soft mint green background (#C8F8E5)
- Emerald green primary buttons (#10C981)
- Pale mint cards (#E8F8F1)
- White surfaces and soft grey-green page background
- Deep green-charcoal text
