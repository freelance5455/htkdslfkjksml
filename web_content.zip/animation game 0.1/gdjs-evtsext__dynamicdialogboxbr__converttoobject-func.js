
if (typeof gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject !== "undefined") {
  gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject = {};
gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.idToCallbackMap = new Map();


gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.userFunc0x152bfe0 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
const Name = eventsFunctionContext.getArgument("NameCharacter");
const Text = eventsFunctionContext.getArgument("Message");
const Action = eventsFunctionContext.getArgument("ActionName");

const ActionName = Action ? Action : "0";

eventsFunctionContext.returnValue = JSON.stringify({ Name, Text, ActionName });
};
gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.userFunc0x152bfe0(runtimeScene, eventsFunctionContext);

}


};gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12735452);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.func = function(runtimeScene, NameCharacter, Message, ActionName, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("DynamicDialogBoxBR"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("DynamicDialogBoxBR"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "NameCharacter") return NameCharacter;
if (argName === "Message") return Message;
if (argName === "ActionName") return ActionName;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.eventsList1(runtimeScene, eventsFunctionContext);


return "" + eventsFunctionContext.returnValue;
}

gdjs.evtsExt__DynamicDialogBoxBR__ConvertToObject.registeredGdjsCallbacks = [];