
if (typeof gdjs.evtsExt__DynamicDialogBoxBR__IsStarted !== "undefined") {
  gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__DynamicDialogBoxBR__IsStarted = {};
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.idToCallbackMap = new Map();


gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"), "reopen");
}
{eventsFunctionContext.returnValue = true;}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "notReopen";
if (isConditionTrue_0) {
{gdjs.evtTools.storage.deleteElementFromJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"));
}
{eventsFunctionContext.returnValue = true;}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "reopen";
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = !(gdjs.evtTools.storage.elementExistsInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName")));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "0";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"));
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList1(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.writeStringInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"), "open");
}
{eventsFunctionContext.returnValue = true;}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "open";
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "notReopen";
if (isConditionTrue_0) {
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR"));
}
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().get("__DynamicDialogBoxBR"));
}
{eventsFunctionContext.returnValue = false;}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = !(gdjs.evtTools.storage.elementExistsInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName")));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "0";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"));
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Reopen"), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Reopen"), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList5(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "reopen";
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.deleteElementFromJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"));
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save")) == "open";
}
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"), "notReopen");
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Reopen"), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList7(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Reopen"), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList8(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR"));
}
{gdjs.evtTools.variable.variableClearChildren(runtimeScene.getGame().getVariables().get("__DynamicDialogBoxBR"));
}
{eventsFunctionContext.returnValue = false;}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.readStringFromJSONFile("SaveDynamicDialogBox", "" + eventsFunctionContext.getArgument("DialogName"), runtimeScene, runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Save"));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Start"), true);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Start"), false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList9(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Name")) == "" + eventsFunctionContext.getArgument("DialogName");
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList10(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.func = function(runtimeScene, DialogName, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("DynamicDialogBoxBR"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("DynamicDialogBoxBR"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "DialogName") return DialogName;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.eventsList11(runtimeScene, eventsFunctionContext);


return !!eventsFunctionContext.returnValue;
}

gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.registeredGdjsCallbacks = [];