gdjs.vilareijoCode = {};
gdjs.vilareijoCode.localVariables = [];
gdjs.vilareijoCode.idToCallbackMap = new Map();
gdjs.vilareijoCode.GDAsphalt026ABlockObjects1= [];
gdjs.vilareijoCode.GDAsphalt026ABlockObjects2= [];
gdjs.vilareijoCode.GDAsphalt026ABlockObjects3= [];
gdjs.vilareijoCode.GDAsphalt026ABlockObjects4= [];
gdjs.vilareijoCode.GDdylanObjects1= [];
gdjs.vilareijoCode.GDdylanObjects2= [];
gdjs.vilareijoCode.GDdylanObjects3= [];
gdjs.vilareijoCode.GDdylanObjects4= [];
gdjs.vilareijoCode.GDhitbox_9595danoObjects1= [];
gdjs.vilareijoCode.GDhitbox_9595danoObjects2= [];
gdjs.vilareijoCode.GDhitbox_9595danoObjects3= [];
gdjs.vilareijoCode.GDhitbox_9595danoObjects4= [];
gdjs.vilareijoCode.GDinimigoObjects1= [];
gdjs.vilareijoCode.GDinimigoObjects2= [];
gdjs.vilareijoCode.GDinimigoObjects3= [];
gdjs.vilareijoCode.GDinimigoObjects4= [];
gdjs.vilareijoCode.GDNewSprite2Objects1= [];
gdjs.vilareijoCode.GDNewSprite2Objects2= [];
gdjs.vilareijoCode.GDNewSprite2Objects3= [];
gdjs.vilareijoCode.GDNewSprite2Objects4= [];
gdjs.vilareijoCode.GDTextoMoedasObjects1= [];
gdjs.vilareijoCode.GDTextoMoedasObjects2= [];
gdjs.vilareijoCode.GDTextoMoedasObjects3= [];
gdjs.vilareijoCode.GDTextoMoedasObjects4= [];
gdjs.vilareijoCode.GDRedFlatBarObjects1= [];
gdjs.vilareijoCode.GDRedFlatBarObjects2= [];
gdjs.vilareijoCode.GDRedFlatBarObjects3= [];
gdjs.vilareijoCode.GDRedFlatBarObjects4= [];
gdjs.vilareijoCode.GDNewSpriteObjects1= [];
gdjs.vilareijoCode.GDNewSpriteObjects2= [];
gdjs.vilareijoCode.GDNewSpriteObjects3= [];
gdjs.vilareijoCode.GDNewSpriteObjects4= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects1= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects2= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects3= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects4= [];
gdjs.vilareijoCode.GDA_9595buttonObjects1= [];
gdjs.vilareijoCode.GDA_9595buttonObjects2= [];
gdjs.vilareijoCode.GDA_9595buttonObjects3= [];
gdjs.vilareijoCode.GDA_9595buttonObjects4= [];
gdjs.vilareijoCode.GDBlank_9595buttonObjects1= [];
gdjs.vilareijoCode.GDBlank_9595buttonObjects2= [];
gdjs.vilareijoCode.GDBlank_9595buttonObjects3= [];
gdjs.vilareijoCode.GDBlank_9595buttonObjects4= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects1= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects2= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects3= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects4= [];
gdjs.vilareijoCode.GDB_9595buttonObjects1= [];
gdjs.vilareijoCode.GDB_9595buttonObjects2= [];
gdjs.vilareijoCode.GDB_9595buttonObjects3= [];
gdjs.vilareijoCode.GDB_9595buttonObjects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects4= [];
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDClose_9595buttonObjects1= [];
gdjs.vilareijoCode.GDClose_9595buttonObjects2= [];
gdjs.vilareijoCode.GDClose_9595buttonObjects3= [];
gdjs.vilareijoCode.GDClose_9595buttonObjects4= [];
gdjs.vilareijoCode.GDCheck_9595buttonObjects1= [];
gdjs.vilareijoCode.GDCheck_9595buttonObjects2= [];
gdjs.vilareijoCode.GDCheck_9595buttonObjects3= [];
gdjs.vilareijoCode.GDCheck_9595buttonObjects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects4= [];
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595upObjects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595upObjects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595upObjects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595upObjects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects4= [];
gdjs.vilareijoCode.GDGear_9595buttonObjects1= [];
gdjs.vilareijoCode.GDGear_9595buttonObjects2= [];
gdjs.vilareijoCode.GDGear_9595buttonObjects3= [];
gdjs.vilareijoCode.GDGear_9595buttonObjects4= [];
gdjs.vilareijoCode.GDD_9595padObjects1= [];
gdjs.vilareijoCode.GDD_9595padObjects2= [];
gdjs.vilareijoCode.GDD_9595padObjects3= [];
gdjs.vilareijoCode.GDD_9595padObjects4= [];
gdjs.vilareijoCode.GDExpand_9595buttonObjects1= [];
gdjs.vilareijoCode.GDExpand_9595buttonObjects2= [];
gdjs.vilareijoCode.GDExpand_9595buttonObjects3= [];
gdjs.vilareijoCode.GDExpand_9595buttonObjects4= [];
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects1= [];
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects2= [];
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects3= [];
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects4= [];
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDL_9595buttonObjects1= [];
gdjs.vilareijoCode.GDL_9595buttonObjects2= [];
gdjs.vilareijoCode.GDL_9595buttonObjects3= [];
gdjs.vilareijoCode.GDL_9595buttonObjects4= [];
gdjs.vilareijoCode.GDLaunch_9595buttonObjects1= [];
gdjs.vilareijoCode.GDLaunch_9595buttonObjects2= [];
gdjs.vilareijoCode.GDLaunch_9595buttonObjects3= [];
gdjs.vilareijoCode.GDLaunch_9595buttonObjects4= [];
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDKey_9595buttonObjects1= [];
gdjs.vilareijoCode.GDKey_9595buttonObjects2= [];
gdjs.vilareijoCode.GDKey_9595buttonObjects3= [];
gdjs.vilareijoCode.GDKey_9595buttonObjects4= [];
gdjs.vilareijoCode.GDMusic_9595buttonObjects1= [];
gdjs.vilareijoCode.GDMusic_9595buttonObjects2= [];
gdjs.vilareijoCode.GDMusic_9595buttonObjects3= [];
gdjs.vilareijoCode.GDMusic_9595buttonObjects4= [];
gdjs.vilareijoCode.GDPause_9595buttonObjects1= [];
gdjs.vilareijoCode.GDPause_9595buttonObjects2= [];
gdjs.vilareijoCode.GDPause_9595buttonObjects3= [];
gdjs.vilareijoCode.GDPause_9595buttonObjects4= [];
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects1= [];
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects2= [];
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects3= [];
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects4= [];
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects1= [];
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects2= [];
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects3= [];
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects4= [];
gdjs.vilareijoCode.GDPlay_9595buttonObjects1= [];
gdjs.vilareijoCode.GDPlay_9595buttonObjects2= [];
gdjs.vilareijoCode.GDPlay_9595buttonObjects3= [];
gdjs.vilareijoCode.GDPlay_9595buttonObjects4= [];
gdjs.vilareijoCode.GDR_9595buttonObjects1= [];
gdjs.vilareijoCode.GDR_9595buttonObjects2= [];
gdjs.vilareijoCode.GDR_9595buttonObjects3= [];
gdjs.vilareijoCode.GDR_9595buttonObjects4= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects1= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects2= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects3= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects4= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects1= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects2= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects3= [];
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects4= [];
gdjs.vilareijoCode.GDSave_9595buttonObjects1= [];
gdjs.vilareijoCode.GDSave_9595buttonObjects2= [];
gdjs.vilareijoCode.GDSave_9595buttonObjects3= [];
gdjs.vilareijoCode.GDSave_9595buttonObjects4= [];
gdjs.vilareijoCode.GDSearch_9595buttonObjects1= [];
gdjs.vilareijoCode.GDSearch_9595buttonObjects2= [];
gdjs.vilareijoCode.GDSearch_9595buttonObjects3= [];
gdjs.vilareijoCode.GDSearch_9595buttonObjects4= [];
gdjs.vilareijoCode.GDSelect_9595buttonObjects1= [];
gdjs.vilareijoCode.GDSelect_9595buttonObjects2= [];
gdjs.vilareijoCode.GDSelect_9595buttonObjects3= [];
gdjs.vilareijoCode.GDSelect_9595buttonObjects4= [];
gdjs.vilareijoCode.GDRound_9595joystickObjects1= [];
gdjs.vilareijoCode.GDRound_9595joystickObjects2= [];
gdjs.vilareijoCode.GDRound_9595joystickObjects3= [];
gdjs.vilareijoCode.GDRound_9595joystickObjects4= [];
gdjs.vilareijoCode.GDSound_9595buttonObjects1= [];
gdjs.vilareijoCode.GDSound_9595buttonObjects2= [];
gdjs.vilareijoCode.GDSound_9595buttonObjects3= [];
gdjs.vilareijoCode.GDSound_9595buttonObjects4= [];
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects1= [];
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects2= [];
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects3= [];
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects4= [];
gdjs.vilareijoCode.GDSquare_9595joystickObjects1= [];
gdjs.vilareijoCode.GDSquare_9595joystickObjects2= [];
gdjs.vilareijoCode.GDSquare_9595joystickObjects3= [];
gdjs.vilareijoCode.GDSquare_9595joystickObjects4= [];
gdjs.vilareijoCode.GDStar_9595buttonObjects1= [];
gdjs.vilareijoCode.GDStar_9595buttonObjects2= [];
gdjs.vilareijoCode.GDStar_9595buttonObjects3= [];
gdjs.vilareijoCode.GDStar_9595buttonObjects4= [];
gdjs.vilareijoCode.GDStart_9595buttonObjects1= [];
gdjs.vilareijoCode.GDStart_9595buttonObjects2= [];
gdjs.vilareijoCode.GDStart_9595buttonObjects3= [];
gdjs.vilareijoCode.GDStart_9595buttonObjects4= [];
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDTool_9595buttonObjects1= [];
gdjs.vilareijoCode.GDTool_9595buttonObjects2= [];
gdjs.vilareijoCode.GDTool_9595buttonObjects3= [];
gdjs.vilareijoCode.GDTool_9595buttonObjects4= [];
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1= [];
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects2= [];
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects3= [];
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects4= [];
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDX_9595buttonObjects1= [];
gdjs.vilareijoCode.GDX_9595buttonObjects2= [];
gdjs.vilareijoCode.GDX_9595buttonObjects3= [];
gdjs.vilareijoCode.GDX_9595buttonObjects4= [];
gdjs.vilareijoCode.GDA_9595button2Objects1= [];
gdjs.vilareijoCode.GDA_9595button2Objects2= [];
gdjs.vilareijoCode.GDA_9595button2Objects3= [];
gdjs.vilareijoCode.GDA_9595button2Objects4= [];
gdjs.vilareijoCode.GDY_9595buttonObjects1= [];
gdjs.vilareijoCode.GDY_9595buttonObjects2= [];
gdjs.vilareijoCode.GDY_9595buttonObjects3= [];
gdjs.vilareijoCode.GDY_9595buttonObjects4= [];
gdjs.vilareijoCode.GDB_9595button2Objects1= [];
gdjs.vilareijoCode.GDB_9595button2Objects2= [];
gdjs.vilareijoCode.GDB_9595button2Objects3= [];
gdjs.vilareijoCode.GDB_9595button2Objects4= [];
gdjs.vilareijoCode.GDBlank_9595button2Objects1= [];
gdjs.vilareijoCode.GDBlank_9595button2Objects2= [];
gdjs.vilareijoCode.GDBlank_9595button2Objects3= [];
gdjs.vilareijoCode.GDBlank_9595button2Objects4= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects1= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects2= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects3= [];
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects4= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects1= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects2= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects3= [];
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects4= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects1= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects2= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects3= [];
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects4= [];
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects1= [];
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects2= [];
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects3= [];
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects4= [];
gdjs.vilareijoCode.GDClose_9595button2Objects1= [];
gdjs.vilareijoCode.GDClose_9595button2Objects2= [];
gdjs.vilareijoCode.GDClose_9595button2Objects3= [];
gdjs.vilareijoCode.GDClose_9595button2Objects4= [];
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects1= [];
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects2= [];
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects3= [];
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects4= [];
gdjs.vilareijoCode.GDCheck_9595button2Objects1= [];
gdjs.vilareijoCode.GDCheck_9595button2Objects2= [];
gdjs.vilareijoCode.GDCheck_9595button2Objects3= [];
gdjs.vilareijoCode.GDCheck_9595button2Objects4= [];
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects1= [];
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects2= [];
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects3= [];
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects4= [];
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1= [];
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects2= [];
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects3= [];
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects4= [];
gdjs.vilareijoCode.GDamy_9595npcObjects1= [];
gdjs.vilareijoCode.GDamy_9595npcObjects2= [];
gdjs.vilareijoCode.GDamy_9595npcObjects3= [];
gdjs.vilareijoCode.GDamy_9595npcObjects4= [];
gdjs.vilareijoCode.GDendObjects1= [];
gdjs.vilareijoCode.GDendObjects2= [];
gdjs.vilareijoCode.GDendObjects3= [];
gdjs.vilareijoCode.GDendObjects4= [];
gdjs.vilareijoCode.GDNewSprite3Objects1= [];
gdjs.vilareijoCode.GDNewSprite3Objects2= [];
gdjs.vilareijoCode.GDNewSprite3Objects3= [];
gdjs.vilareijoCode.GDNewSprite3Objects4= [];
gdjs.vilareijoCode.GDjObjects1= [];
gdjs.vilareijoCode.GDjObjects2= [];
gdjs.vilareijoCode.GDjObjects3= [];
gdjs.vilareijoCode.GDjObjects4= [];
gdjs.vilareijoCode.GDcol_9595canoObjects1= [];
gdjs.vilareijoCode.GDcol_9595canoObjects2= [];
gdjs.vilareijoCode.GDcol_9595canoObjects3= [];
gdjs.vilareijoCode.GDcol_9595canoObjects4= [];
gdjs.vilareijoCode.GDmarcadorObjects1= [];
gdjs.vilareijoCode.GDmarcadorObjects2= [];
gdjs.vilareijoCode.GDmarcadorObjects3= [];
gdjs.vilareijoCode.GDmarcadorObjects4= [];
gdjs.vilareijoCode.GDsonic_9595npcObjects1= [];
gdjs.vilareijoCode.GDsonic_9595npcObjects2= [];
gdjs.vilareijoCode.GDsonic_9595npcObjects3= [];
gdjs.vilareijoCode.GDsonic_9595npcObjects4= [];
gdjs.vilareijoCode.GDmonica_9595npcObjects1= [];
gdjs.vilareijoCode.GDmonica_9595npcObjects2= [];
gdjs.vilareijoCode.GDmonica_9595npcObjects3= [];
gdjs.vilareijoCode.GDmonica_9595npcObjects4= [];
gdjs.vilareijoCode.GDNewSprite4Objects1= [];
gdjs.vilareijoCode.GDNewSprite4Objects2= [];
gdjs.vilareijoCode.GDNewSprite4Objects3= [];
gdjs.vilareijoCode.GDNewSprite4Objects4= [];
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects1= [];
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects2= [];
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects3= [];
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects4= [];


gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDamy_95959595npcObjects1Objects = Hashtable.newFrom({"amy_npc": gdjs.vilareijoCode.GDamy_9595npcObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDendObjects1Objects = Hashtable.newFrom({"end": gdjs.vilareijoCode.GDendObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDjObjects1Objects = Hashtable.newFrom({"j": gdjs.vilareijoCode.GDjObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDjObjects1Objects = Hashtable.newFrom({"j": gdjs.vilareijoCode.GDjObjects1});
gdjs.vilareijoCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.vilareijoCode.GDdylanObjects2, gdjs.vilareijoCode.GDdylanObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects3.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects3[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects3[k] = gdjs.vilareijoCode.GDdylanObjects3[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects3 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects3.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects3[i].getBehavior("Animation").setAnimationName("andando");
}
}
}

}


{

/* Reuse gdjs.vilareijoCode.GDdylanObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( !(gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects2 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Animation").setAnimationName("parado");
}
}
}

}


};gdjs.vilareijoCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.vilareijoCode.GDdylanObjects1, gdjs.vilareijoCode.GDdylanObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects2 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Animation").setAnimationName("andando");
}
}
}

}


{

/* Reuse gdjs.vilareijoCode.GDdylanObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects1.length;i<l;++i) {
    if ( !(gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects1[k] = gdjs.vilareijoCode.GDdylanObjects1[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects1 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("Animation").setAnimationName("parado");
}
}
}

}


};gdjs.vilareijoCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getVariableBoolean(gdjs.vilareijoCode.GDdylanObjects2[i].getVariables().getFromIndex(0), false, false) ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.vilareijoCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects2 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Animation").setAnimationName("pula");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects2 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Animation").setAnimationName("cai");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects1.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects1[k] = gdjs.vilareijoCode.GDdylanObjects1[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.vilareijoCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.vilareijoCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
}

}


};gdjs.vilareijoCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.vilareijoCode.GDdylanObjects1, gdjs.vilareijoCode.GDdylanObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getAnimationFrame() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16299828);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Stone_hit2.ogg", false, 100, 1);
}
}

}


{

gdjs.copyArray(gdjs.vilareijoCode.GDdylanObjects1, gdjs.vilareijoCode.GDdylanObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getAnimationFrame() == 5 ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16300652);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Stone_hit2.ogg", false, 100, 1);
}
}

}


{

/* Reuse gdjs.vilareijoCode.GDdylanObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects1.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects1[i].getAnimationFrame() == 8 ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects1[k] = gdjs.vilareijoCode.GDdylanObjects1[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16301508);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Stone_hit2.ogg", false, 100, 1);
}
}

}


};gdjs.vilareijoCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Animation").getAnimationName() == "pula" ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects2[k] = gdjs.vilareijoCode.GDdylanObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16298404);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "bestuploadsever67aryan-jump-sound-531048.mp3", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects1.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("Animation").getAnimationName() == "andando" ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects1[k] = gdjs.vilareijoCode.GDdylanObjects1[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.vilareijoCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDinimigoObjects1Objects = Hashtable.newFrom({"inimigo": gdjs.vilareijoCode.GDinimigoObjects1});
gdjs.vilareijoCode.asyncCallback16303676 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.vilareijoCode.localVariables);
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.vilareijoCode.GDRedFlatBarObjects2);
gdjs.copyArray(asyncObjectsList.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);

{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].setColor("255;255;255");
}
}
{for(var i = 0, len = gdjs.vilareijoCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDRedFlatBarObjects2[i].SetValue(gdjs.vilareijoCode.GDRedFlatBarObjects2[i].Value(null) - (1), null);
}
}
gdjs.vilareijoCode.localVariables.length = 0;
}
gdjs.vilareijoCode.idToCallbackMap.set(16303676, gdjs.vilareijoCode.asyncCallback16303676);
gdjs.vilareijoCode.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.vilareijoCode.localVariables);
for (const obj of gdjs.vilareijoCode.GDdylanObjects1) asyncObjectsList.addObject("dylan", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.0), (runtimeScene) => (gdjs.vilareijoCode.asyncCallback16303676(runtimeScene, asyncObjectsList)), 16303676, asyncObjectsList);
}
}

}


};gdjs.vilareijoCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
gdjs.copyArray(runtimeScene.getObjects("inimigo"), gdjs.vilareijoCode.GDinimigoObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDinimigoObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDdylanObjects1.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDdylanObjects1[k] = gdjs.vilareijoCode.GDdylanObjects1[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDdylanObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16302380);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects1 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("Health").Hit(1, false, false, null);
}
}
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects1[i].setColor("255;0;0");
}
}

{ //Subevents
gdjs.vilareijoCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects2Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects2});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDNewSprite2Objects2Objects = Hashtable.newFrom({"NewSprite2": gdjs.vilareijoCode.GDNewSprite2Objects2});
gdjs.vilareijoCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NewSprite2"), gdjs.vilareijoCode.GDNewSprite2Objects2);
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects2Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDNewSprite2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDNewSprite2Objects2 */
{for(var i = 0, len = gdjs.vilareijoCode.GDNewSprite2Objects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDNewSprite2Objects2[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(0).add(1);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TextoMoedas"), gdjs.vilareijoCode.GDTextoMoedasObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDTextoMoedasObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDTextoMoedasObjects1[i].getBehavior("Text").setText("Moedas: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}
}

}


};gdjs.vilareijoCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("D_pad_right"), gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2[k] = gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").simulateRightKey();
}
}
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Flippable").flipX(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("D_pad_left"), gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2[k] = gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects2);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects2.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects2[i].getBehavior("Flippable").flipX(true);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Top_arrow_button"), gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1[k] = gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}
}

}


};gdjs.vilareijoCode.eventsList10 = function(runtimeScene) {

};gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDmarcadorObjects1Objects = Hashtable.newFrom({"marcador": gdjs.vilareijoCode.GDmarcadorObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects = Hashtable.newFrom({"dylan": gdjs.vilareijoCode.GDdylanObjects1});
gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDNewSprite4Objects1Objects = Hashtable.newFrom({"NewSprite4": gdjs.vilareijoCode.GDNewSprite4Objects1});
gdjs.vilareijoCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("amy_npc"), gdjs.vilareijoCode.GDamy_9595npcObjects1);
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDamy_95959595npcObjects1Objects, 10, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}
if (isConditionTrue_0) {
{gdjs.evtsExt__DynamicDialogBoxBR__AddMessage.func(runtimeScene, "amy_npc", "?", "0", null);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
gdjs.copyArray(runtimeScene.getObjects("end"), gdjs.vilareijoCode.GDendObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDendObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "vilareijo", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
gdjs.copyArray(runtimeScene.getObjects("j"), gdjs.vilareijoCode.GDjObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDjObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Asphalt026ABlock2"), gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1[i].getBehavior("Platform").changePlatformType("Platform");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
gdjs.copyArray(runtimeScene.getObjects("j"), gdjs.vilareijoCode.GDjObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDjObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Asphalt026ABlock2"), gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1[i].getBehavior("Platform").changePlatformType("Jumpthru");
}
}
}

}


{


gdjs.vilareijoCode.eventsList2(runtimeScene);
}


{


gdjs.vilareijoCode.eventsList3(runtimeScene);
}


{


gdjs.vilareijoCode.eventsList5(runtimeScene);
}


{


gdjs.vilareijoCode.eventsList7(runtimeScene);
}


{


gdjs.vilareijoCode.eventsList8(runtimeScene);
}


{


gdjs.vilareijoCode.eventsList9(runtimeScene);
}


{


gdjs.vilareijoCode.eventsList10(runtimeScene);
}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "3 - Monster Town (Remaster).mp3", false, 50, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("hitbox_dano"), gdjs.vilareijoCode.GDhitbox_9595danoObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDhitbox_9595danoObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDhitbox_9595danoObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("col_cano"), gdjs.vilareijoCode.GDcol_9595canoObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDcol_9595canoObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDcol_9595canoObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("j"), gdjs.vilareijoCode.GDjObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDjObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDjObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("marcador"), gdjs.vilareijoCode.GDmarcadorObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDmarcadorObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDmarcadorObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);
gdjs.copyArray(runtimeScene.getObjects("marcador"), gdjs.vilareijoCode.GDmarcadorObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDmarcadorObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.vilareijoCode.GDdylanObjects1 */
{for(var i = 0, len = gdjs.vilareijoCode.GDdylanObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDdylanObjects1[i].setPosition(-80,-57);
}
}
{gdjs.evtTools.camera.setCameraX(runtimeScene, -80, "", 0);
}
{gdjs.evtTools.camera.setCameraY(runtimeScene, -57, "", 0);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite4"), gdjs.vilareijoCode.GDNewSprite4Objects1);
gdjs.copyArray(runtimeScene.getObjects("dylan"), gdjs.vilareijoCode.GDdylanObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDdylanObjects1Objects, gdjs.vilareijoCode.mapOfGDgdjs_9546vilareijoCode_9546GDNewSprite4Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Asphalt026ABlock3"), gdjs.vilareijoCode.GDAsphalt026ABlock3Objects1);
/* Reuse gdjs.vilareijoCode.GDNewSprite4Objects1 */
{for(var i = 0, len = gdjs.vilareijoCode.GDNewSprite4Objects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDNewSprite4Objects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getGame().getVariables().getFromIndex(0).add(50);
}
{gdjs.evtTools.sound.playSound(runtimeScene, "coin.wav", false, 500, 1);
}
{for(var i = 0, len = gdjs.vilareijoCode.GDAsphalt026ABlock3Objects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDAsphalt026ABlock3Objects1[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("TextoMoedas"), gdjs.vilareijoCode.GDTextoMoedasObjects1);
{for(var i = 0, len = gdjs.vilareijoCode.GDTextoMoedasObjects1.length ;i < len;++i) {
    gdjs.vilareijoCode.GDTextoMoedasObjects1[i].getBehavior("Text").setText("Moedas: " + gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 100);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}
}

}


};

gdjs.vilareijoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.vilareijoCode.GDAsphalt026ABlockObjects1.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlockObjects2.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlockObjects3.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlockObjects4.length = 0;
gdjs.vilareijoCode.GDdylanObjects1.length = 0;
gdjs.vilareijoCode.GDdylanObjects2.length = 0;
gdjs.vilareijoCode.GDdylanObjects3.length = 0;
gdjs.vilareijoCode.GDdylanObjects4.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects1.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects2.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects3.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects4.length = 0;
gdjs.vilareijoCode.GDinimigoObjects1.length = 0;
gdjs.vilareijoCode.GDinimigoObjects2.length = 0;
gdjs.vilareijoCode.GDinimigoObjects3.length = 0;
gdjs.vilareijoCode.GDinimigoObjects4.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects1.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects2.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects3.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects4.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects1.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects2.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects3.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects4.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects1.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects2.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects3.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects4.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects1.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects2.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects3.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects4.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects4.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects4.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects4.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects1.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects2.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects3.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects4.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects1.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects2.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects3.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects4.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects1.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects2.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects3.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects4.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects1.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects2.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects3.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects4.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects1.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects2.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects3.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects4.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects4.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects2.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects3.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects4.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects1.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects2.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects3.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects4.length = 0;
gdjs.vilareijoCode.GDendObjects1.length = 0;
gdjs.vilareijoCode.GDendObjects2.length = 0;
gdjs.vilareijoCode.GDendObjects3.length = 0;
gdjs.vilareijoCode.GDendObjects4.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects1.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects2.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects3.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects4.length = 0;
gdjs.vilareijoCode.GDjObjects1.length = 0;
gdjs.vilareijoCode.GDjObjects2.length = 0;
gdjs.vilareijoCode.GDjObjects3.length = 0;
gdjs.vilareijoCode.GDjObjects4.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects1.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects2.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects3.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects4.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects1.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects2.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects3.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects4.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects1.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects2.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects3.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects4.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects1.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects2.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects3.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects4.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects1.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects2.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects3.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects4.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects1.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects2.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects3.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects4.length = 0;

gdjs.vilareijoCode.eventsList11(runtimeScene);
gdjs.vilareijoCode.GDAsphalt026ABlockObjects1.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlockObjects2.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlockObjects3.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlockObjects4.length = 0;
gdjs.vilareijoCode.GDdylanObjects1.length = 0;
gdjs.vilareijoCode.GDdylanObjects2.length = 0;
gdjs.vilareijoCode.GDdylanObjects3.length = 0;
gdjs.vilareijoCode.GDdylanObjects4.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects1.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects2.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects3.length = 0;
gdjs.vilareijoCode.GDhitbox_9595danoObjects4.length = 0;
gdjs.vilareijoCode.GDinimigoObjects1.length = 0;
gdjs.vilareijoCode.GDinimigoObjects2.length = 0;
gdjs.vilareijoCode.GDinimigoObjects3.length = 0;
gdjs.vilareijoCode.GDinimigoObjects4.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects1.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects2.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects3.length = 0;
gdjs.vilareijoCode.GDNewSprite2Objects4.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects1.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects2.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects3.length = 0;
gdjs.vilareijoCode.GDTextoMoedasObjects4.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects1.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects2.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects3.length = 0;
gdjs.vilareijoCode.GDRedFlatBarObjects4.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects1.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects2.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects3.length = 0;
gdjs.vilareijoCode.GDNewSpriteObjects4.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDA_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBlank_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDB_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595largeObjects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDClose_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595leftObjects4.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottomObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595upObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595rightObjects4.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDGear_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects1.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects2.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects3.length = 0;
gdjs.vilareijoCode.GDD_9595padObjects4.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDExpand_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDFire_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDLeft_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDLaunch_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDL_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDLaunch_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDKey_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDKey_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDMusic_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDPause_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDRight_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDPause_9595large_9595button_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDPlay_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDR_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects1.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects2.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects3.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outer_9595plainObjects4.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects1.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects2.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects3.length = 0;
gdjs.vilareijoCode.GDRound_9595joystick_9595outerObjects4.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSave_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSearch_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSelect_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects1.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects2.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects3.length = 0;
gdjs.vilareijoCode.GDRound_9595joystickObjects4.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDSound_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects1.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects2.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects3.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystick_9595outerObjects4.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects1.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects2.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects3.length = 0;
gdjs.vilareijoCode.GDSquare_9595joystickObjects4.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDStar_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDStart_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDStar_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDTool_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDTop_9595arrow_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDTarget_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDX_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDA_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDY_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDB_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDBlank_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects1.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects2.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects3.length = 0;
gdjs.vilareijoCode.GDBottom_9595arrow_9595round_9595buttonObjects4.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDCar_9595pedal_9595round_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDBurger_9595menu_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595round_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDClose_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDClose_9595round_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595bottom2Objects4.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects1.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects2.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects3.length = 0;
gdjs.vilareijoCode.GDCheck_9595button2Objects4.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects1.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects2.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects3.length = 0;
gdjs.vilareijoCode.GDD_9595pad_9595large2Objects4.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects1.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects2.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects3.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock2Objects4.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects1.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects2.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects3.length = 0;
gdjs.vilareijoCode.GDamy_9595npcObjects4.length = 0;
gdjs.vilareijoCode.GDendObjects1.length = 0;
gdjs.vilareijoCode.GDendObjects2.length = 0;
gdjs.vilareijoCode.GDendObjects3.length = 0;
gdjs.vilareijoCode.GDendObjects4.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects1.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects2.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects3.length = 0;
gdjs.vilareijoCode.GDNewSprite3Objects4.length = 0;
gdjs.vilareijoCode.GDjObjects1.length = 0;
gdjs.vilareijoCode.GDjObjects2.length = 0;
gdjs.vilareijoCode.GDjObjects3.length = 0;
gdjs.vilareijoCode.GDjObjects4.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects1.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects2.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects3.length = 0;
gdjs.vilareijoCode.GDcol_9595canoObjects4.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects1.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects2.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects3.length = 0;
gdjs.vilareijoCode.GDmarcadorObjects4.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects1.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects2.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects3.length = 0;
gdjs.vilareijoCode.GDsonic_9595npcObjects4.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects1.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects2.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects3.length = 0;
gdjs.vilareijoCode.GDmonica_9595npcObjects4.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects1.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects2.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects3.length = 0;
gdjs.vilareijoCode.GDNewSprite4Objects4.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects1.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects2.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects3.length = 0;
gdjs.vilareijoCode.GDAsphalt026ABlock3Objects4.length = 0;


return;

}

gdjs['vilareijoCode'] = gdjs.vilareijoCode;
