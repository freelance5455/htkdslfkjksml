
if (typeof gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject !== "undefined") {
  gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject = {};
gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.idToCallbackMap = new Map();


gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.userFunc0xb1a050 = function GDJSInlineCode(runtimeScene, eventsFunctionContext) {
"use strict";
const Name = eventsFunctionContext.getArgument("NameCharacter");
const Text = eventsFunctionContext.getArgument("Message");
const Action = eventsFunctionContext.getArgument("ActionName");
const Choices = eventsFunctionContext.getArgument("Choices");

let Buttons = new Array();
const ActionName = Action ? Action : "0";

Choices.toString().split(";").forEach(function (value, index) {
    Buttons.push({
        Text: value.replace(/^\w/, (c) => c.toUpperCase()),
        Value: value.toLowerCase()
    });
})

Buttons.sort().reverse();

eventsFunctionContext.returnValue = JSON.stringify({ Name, Text, ActionName, Buttons });
};
gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.userFunc0xb1a050(runtimeScene, eventsFunctionContext);

}


};gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(11996260);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.func = function(runtimeScene, NameCharacter, Message, ActionName, Choices, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("DynamicDialogBoxBR"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("DynamicDialogBoxBR"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "NameCharacter") return NameCharacter;
if (argName === "Message") return Message;
if (argName === "ActionName") return ActionName;
if (argName === "Choices") return Choices;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.eventsList1(runtimeScene, eventsFunctionContext);


return "" + eventsFunctionContext.returnValue;
}

gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.registeredGdjsCallbacks = [];