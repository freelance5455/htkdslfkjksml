
if (typeof gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices !== "undefined") {
  gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices = {};
gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices.idToCallbackMap = new Map();


gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(22113468);
}
if (isConditionTrue_0) {
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtsExt__DynamicDialogBoxBR__ConvertChoicesToObject.func(runtimeScene, "" + eventsFunctionContext.getArgument("NameCharacter"), "" + eventsFunctionContext.getArgument("Message"), "" + eventsFunctionContext.getArgument("ActionName"), "" + eventsFunctionContext.getArgument("Choices"), eventsFunctionContext), runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message"));
}
{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getGame().getVariables().get("__DynamicDialogBoxBR").getChild("Object").getChild("Messages"), runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message"));
}
}

}


};

gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices.func = function(runtimeScene, NameCharacter, Message, ActionName, Choices, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("DynamicDialogBoxBR"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("DynamicDialogBoxBR"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "NameCharacter") return NameCharacter;
if (argName === "Message") return Message;
if (argName === "ActionName") return ActionName;
if (argName === "Choices") return Choices;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices.eventsList0(runtimeScene, eventsFunctionContext);


return;
}

gdjs.evtsExt__DynamicDialogBoxBR__AddMessageChoices.registeredGdjsCallbacks = [];