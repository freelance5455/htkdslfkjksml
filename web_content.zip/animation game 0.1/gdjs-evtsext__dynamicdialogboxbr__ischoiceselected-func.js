
if (typeof gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected !== "undefined") {
  gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected = {};
gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected.idToCallbackMap = new Map();


gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
{eventsFunctionContext.returnValue = false;}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceStarted.func(runtimeScene, "" + eventsFunctionContext.getArgument("ActionName"), eventsFunctionContext);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.string.toLowerCase("" + eventsFunctionContext.getArgument("ChoiceSelected")) == gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Choose"), true);
}
}
if (isConditionTrue_0) {
{eventsFunctionContext.returnValue = true;}
}

}


};

gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected.func = function(runtimeScene, ChoiceSelected, ActionName, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
},
  _objectArraysMap: {
},
  _behaviorNamesMap: {
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("DynamicDialogBoxBR"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("DynamicDialogBoxBR"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "ChoiceSelected") return ChoiceSelected;
if (argName === "ActionName") return ActionName;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};


gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected.eventsList0(runtimeScene, eventsFunctionContext);


return !!eventsFunctionContext.returnValue;
}

gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceSelected.registeredGdjsCallbacks = [];