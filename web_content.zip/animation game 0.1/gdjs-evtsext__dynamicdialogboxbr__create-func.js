
if (typeof gdjs.evtsExt__DynamicDialogBoxBR__Create !== "undefined") {
  gdjs.evtsExt__DynamicDialogBoxBR__Create.registeredGdjsCallbacks.forEach(callback =>
    gdjs._unregisterCallback(callback)
  );
}

gdjs.evtsExt__DynamicDialogBoxBR__Create = {};
gdjs.evtsExt__DynamicDialogBoxBR__Create.idToCallbackMap = new Map();
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects1= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects2= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects7= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects8= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects1= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects2= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects6= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects7= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects8= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects1= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects7= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects8= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects1= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects4= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects7= [];
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects8= [];


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.network.jsonToVariableStructure(gdjs.evtTools.network.variableStructureToJSON(runtimeScene.getGame().getVariables().get("__DynamicDialogBoxBR").getChild("Object").getChild("Messages")), runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Messages"));
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Current").getChild("Id").setNumber(0);
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin").setNumber((Number(eventsFunctionContext.getArgument("Margin")) || 0));
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding").setNumber((Number(eventsFunctionContext.getArgument("Padding")) || 0));
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ShowMessage"), true);
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("LastMessage"), false);
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ChangeMessageWithChoice"), false);
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("TimeChangeMessage").setNumber((Number(eventsFunctionContext.getArgument("TimeChangeMessage")) || 0));
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList1 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(14920852);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "__DynamicDialogBoxBR_ChangeMessage");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "__DynamicDialogBoxBR_TimeWithoutChange");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(22050940);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList0(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDBackgroundObjects4Objects = Hashtable.newFrom({"Background": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList2 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(9792844);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDBackgroundObjects4Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[i].getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Id")).setString("Overlay");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[i].setOpacity((Number(eventsFunctionContext.getArgument("OvelayOpacity")) || 0));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[i].setColor("" + eventsFunctionContext.getArgument("OverlayColor"));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[i].setZOrder(1000);
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Background"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Id")) == "Overlay" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setPosition(gdjs.evtTools.camera.getCameraRotation(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")),gdjs.evtTools.camera.getCameraRotation(runtimeScene, "", 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setHeight(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setWidth(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDBackgroundObjects3Objects = Hashtable.newFrom({"Background": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList3 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4);

{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Width").setNumber((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[0].getWidth()));
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Height").setNumber((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4[0].getHeight()));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ("" + eventsFunctionContext.getArgument("DialogPosition") == "Bottom");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y").setNumber((gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Height"))) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ("" + eventsFunctionContext.getArgument("DialogPosition") == "Middle");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y").setNumber((gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2) - ((Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) / 2));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ("" + eventsFunctionContext.getArgument("DialogPosition") == "Top");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3 */
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X").setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) + ((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) - (Number(eventsFunctionContext.getArgument("DialogWidth")) || 0)) / 2));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDImagesObjects4Objects = Hashtable.newFrom({"Images": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList4 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[i].setSize(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Height")) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) * 2), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Height")) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) * 2));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList5 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].setSize((Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) + ((Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) / 2), (Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) + ((Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) / 2));
}
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) - (Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) + ((Number(eventsFunctionContext.getArgument("DialogHeight")) || 0) / 2));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList6 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("AvatarModel")) == "Portrait");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList4(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("AvatarModel")) == "Bust");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList5(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList7 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(22382148);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDImagesObjects4Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")).setString("Avatar");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].setZOrder(1002);
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "Avatar" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList6(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDMessagesObjects4Objects = Hashtable.newFrom({"Messages": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList8 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("AvatarModel")) == "Portrait");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4);

gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setX((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + (( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[0].getWidth()) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) * 2)));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("AvatarModel")) == "Bust");
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3 */
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + (( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[0].getWidth()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList9 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) - 0 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowAvatar");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "Avatar" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList8(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList10 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(22561700);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDMessagesObjects4Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")).setString("CharacterName");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setCharacterSize((Number(eventsFunctionContext.getArgument("FontSizeNameCharacter")) || 0));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setColor("" + eventsFunctionContext.getArgument("CharacterNameColor"));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setZOrder(1003);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setBold(true);
}
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("CharacterName").getChild("Height").setNumber((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[0].getHeight()));
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")) == "CharacterName" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList9(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDMessagesObjects3Objects = Hashtable.newFrom({"Messages": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList11 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("AvatarModel")) == "Portrait");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5);

gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + (( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[0].getWidth()) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) * 2));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].setWrappingWidth(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].getWrappingWidth() - ((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[0].getWidth()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin"))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("AvatarModel")) == "Bust");
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4 */
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + (( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[0].getWidth()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setWrappingWidth(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getWrappingWidth() - ((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[0].getWidth())));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList12 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setY(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getY() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("CharacterName").getChild("Height")) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")) / 2)));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList13 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setY(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setX(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setWrappingWidth(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Width")) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) * 2));
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowAvatar");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "Avatar" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList11(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowName");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList12(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDMessagesObjects3Objects = Hashtable.newFrom({"Messages": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList14 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("AutoChangeMessage");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !eventsFunctionContext.getArgument("AutoChangeMessage");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("MessageKeyPress")) != "0");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(23265420);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("MessageKeyPress").setString(gdjs.evtsExt__DynamicDialogBoxBR__ReplaceString.func(runtimeScene, "" + eventsFunctionContext.getArgument("MessageKeyPress"), "" + eventsFunctionContext.getArgument("KeyChangeMessage"), eventsFunctionContext));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("MessageKeyPress")) == "0");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(17851868);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("MessageKeyPress").setString("PRESS " + gdjs.evtTools.string.toUpperCase("" + eventsFunctionContext.getArgument("KeyChangeMessage")) + "!");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("MessageFinalKeyPress")) != "0");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(13612876);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("MessageFinalKeyPress").setString(gdjs.evtsExt__DynamicDialogBoxBR__ReplaceString.func(runtimeScene, "" + eventsFunctionContext.getArgument("MessageFinalKeyPress"), "" + eventsFunctionContext.getArgument("KeyChangeMessage"), eventsFunctionContext));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (("" + eventsFunctionContext.getArgument("MessageFinalKeyPress")) == "0");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(17905924);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("MessageFinalKeyPress").setString("PRESS " + gdjs.evtTools.string.toUpperCase("" + eventsFunctionContext.getArgument("KeyChangeMessage")) + " TO END!");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("MessageKeyPress")));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Current").getChild("Id")) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Messages")));
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].hide(false);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("MessageFinalKeyPress")));
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].setPosition((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Width"))) - (gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getWidth()) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")),(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Height"))) - (gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getHeight()) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")));
}
}
}

}


{

gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length;i<l;++i) {
    if ( !(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("MessagesBehavior")).isPlaying("FadeIn")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getOpacity() == 0 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4[i].getBehavior(eventsFunctionContext.getBehaviorName("MessagesBehavior")).addObjectOpacityTween("FadeIn", 255, runtimeScene.getGame().getNamedEasingsManager().resolve("linear", "DynamicDialogBoxBR"), 1400, false);
}
}
}

}


{

/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length;i<l;++i) {
    if ( !(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("MessagesBehavior")).isPlaying("FadeOut")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getOpacity() == 255 ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("LastMessage"), false);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getBehavior(eventsFunctionContext.getBehaviorName("MessagesBehavior")).addObjectOpacityTween("FadeOut", 0, runtimeScene.getGame().getNamedEasingsManager().resolve("linear", "DynamicDialogBoxBR"), 1400, false);
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDButtonsObjects5Objects = Hashtable.newFrom({"Buttons": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5});
gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDButtonsObjects6Objects = Hashtable.newFrom({"Buttons": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList15 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6);

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Choose"), true);
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected").setString((gdjs.RuntimeObject.getVariableString(((gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[0].getVariables()).get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected"))));
}
}

}


{

gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDButtonsObjects6Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "FrameSelect" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList16 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = ("" + eventsFunctionContext.getArgument("DialogPosition") == "Top");
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].setPosition((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Width"))) - (gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].getWidth()),(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Height"))) + (gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].getHeight()) - ((gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].getHeight()) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id"))) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id"))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = ("" + eventsFunctionContext.getArgument("DialogPosition") == "Middle");
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = ("" + eventsFunctionContext.getArgument("DialogPosition") == "Bottom");
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].setPosition((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("X")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Width"))) - (gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].getWidth()),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Y")) - (gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].getHeight()) - ((gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6[i].getHeight()) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id"))) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id"))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
/* Unknown instruction - skipped. */if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(13359292);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList15(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList17 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(23306028);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDButtonsObjects5Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{/* Unknown instruction - skipped. */}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].setZOrder(1006);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Id")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected")).setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Value")));
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Buttons"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].getVariableNumber(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList16(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDImagesObjects3Objects = Hashtable.newFrom({"Images": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList18 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(17142436);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame").sub((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Buttons")) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id"))));
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList19 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(21523548);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame").add((gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Buttons")) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id"))));
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList20 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Buttons"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[i].getVariableNumber(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3 */
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3);

{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].setSize((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[0].getWidth()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")), (( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[0].getHeight()) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].setPosition((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[0].getX()) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")) / 2),(( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[0].getY()) - (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Padding")) / 2));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList18(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")) < (gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Buttons")) - 1);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList19(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList21 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(17142156);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Choose"), false);
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected").setString(gdjs.evtTools.variable.getFirstVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Buttons")));
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame").setNumber(0);
}
}

}


{


const keyIteratorReference4 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id");
const valueIteratorReference4 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button");
const iterableReference4 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Buttons");
if(!iterableReference4.isPrimitive()) {
for(
    const iteratorKey4 in 
    iterableReference4.getType() === "structure"
      ? iterableReference4.getAllChildren()
      : iterableReference4.getType() === "array"
        ? iterableReference4.getAllChildrenArray()
        : []
) {
    if(iterableReference4.getType() === "structure")
        keyIteratorReference4.setString(iteratorKey4);
    else if(iterableReference4.getType() === "array")
        keyIteratorReference4.setNumber(iteratorKey4);
    const structureChildVariable4 = iterableReference4.getChild(iteratorKey4)
    valueIteratorReference4.castTo(structureChildVariable4.getType())
    if(structureChildVariable4.isPrimitive()) {
        valueIteratorReference4.setValue(structureChildVariable4.getValue());
    } else if (structureChildVariable4.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference4.replaceChildren(structureChildVariable4.getAllChildren());
    } else if (structureChildVariable4.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference4.replaceChildrenArray(structureChildVariable4.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{

{ //Subevents: 
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList17(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12939396);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDImagesObjects3Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].setZOrder(1007);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].setAnimationName("SelectFrame");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].setOpacity(85);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")).setString("FrameSelect");
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "FrameSelect" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList20(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList22 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowOverlay");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList2(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Background"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Id")) == "Overlay" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !eventsFunctionContext.getArgument("ShowOverlay");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(13450188);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(13962036);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDBackgroundObjects3Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Id")).setString("Background");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setZOrder(1001);
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Background"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Id")) == "Background" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setWidth((Number(eventsFunctionContext.getArgument("DialogWidth")) || 0) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Config").getChild("Margin")) * 2);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3[i].setHeight((Number(eventsFunctionContext.getArgument("DialogHeight")) || 0));
}
}

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList3(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowAvatar");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList7(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "Avatar" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !eventsFunctionContext.getArgument("ShowAvatar");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(22439516);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowName");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList10(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")) == "CharacterName" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !eventsFunctionContext.getArgument("ShowName");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(11906900);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(12732092);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDMessagesObjects3Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")).setString("Message");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setCharacterSize((Number(eventsFunctionContext.getArgument("FontSizeMessage")) || 0));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setColor("" + eventsFunctionContext.getArgument("MessageColor"));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setZOrder(1004);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setWrapping(true);
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")) == "Message" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList13(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(18975092);
}
if (isConditionTrue_0) {
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDMessagesObjects3Objects, 0, 0, "" + eventsFunctionContext.getArgument("DialogLayer"));
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].returnVariable(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")).setString("KeyPress");
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setCharacterSize((Number(eventsFunctionContext.getArgument("FontSizeKeyPress")) || 0));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setColor("" + eventsFunctionContext.getArgument("MessageKeyPressColor"));
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].setZOrder(1005);
}
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("KeyPress").getChild("Height").setNumber((( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length === 0 ) ? 0 :gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[0].getHeight()));
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")) == "KeyPress" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList14(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceStarted.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name")), eventsFunctionContext);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList21(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList23 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "" + eventsFunctionContext.getArgument("KeyChangeMessage")));
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "__DynamicDialogBoxBR_TimeWithoutChange") >= ((Number(eventsFunctionContext.getArgument("TimeChangeMessage")) || 0) * 4);
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("keyNotPressedTime"), true);
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("TimeChangeMessage").setNumber(((Number(eventsFunctionContext.getArgument("TimeChangeMessage")) || 0) * gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Messages"))));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ChangeMessageWithChoice"), true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "" + eventsFunctionContext.getArgument("KeyChangeMessage"));
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(14698924);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("keyNotPressedTime"), false);
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ShowMessage"), true);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "__DynamicDialogBoxBR_TimeWithoutChange");
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDButtonsObjects3Objects = Hashtable.newFrom({"Buttons": gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3});
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList24 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3);

{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Choose"), true);
}
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected").setString((gdjs.RuntimeObject.getVariableString(((gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[0].getVariables()).get("__DynamicDialogBoxBR").getChild("Button").getChild("Selected"))));
}
}

}


{

gdjs.copyArray(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2, gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(eventsFunctionContext, gdjs.evtsExt__DynamicDialogBoxBR__Create.mapOfGDgdjs_9546evtsExt_9595_9595DynamicDialogBoxBR_9595_9595Create_9546GDButtonsObjects3Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3[i].deleteFromScene(runtimeScene);
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "FrameSelect" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList25 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Buttons"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2[i].getVariableNumber(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2[i].getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Button").getChild("Frame")) ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList24(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList26 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = !eventsFunctionContext.getArgument("AutoChangeMessage");
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("LastMessage"), true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList23(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "" + eventsFunctionContext.getArgument("KeyChangeMessage"));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(10750156);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList25(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList27 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "__DynamicDialogBoxBR_ChangeMessage") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("TimeChangeMessage"));
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ShowMessage"), true);
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList28 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = !!eventsFunctionContext.getArgument("AutoChangeMessage");
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("keyNotPressedTime"), true);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList27(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList29 = function(runtimeScene, eventsFunctionContext) {

};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList30 = function(runtimeScene, eventsFunctionContext) {

{


const valueIteratorReference8 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Add").getChild("Button");
const iterableReference8 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message").getChild("Buttons");
if(!iterableReference8.isPrimitive()) {
for(
    const iteratorKey8 in 
    iterableReference8.getType() === "structure"
      ? iterableReference8.getAllChildren()
      : iterableReference8.getType() === "array"
        ? iterableReference8.getAllChildrenArray()
        : []
) {
    const structureChildVariable8 = iterableReference8.getChild(iteratorKey8)
    valueIteratorReference8.castTo(structureChildVariable8.getType())
    if(structureChildVariable8.isPrimitive()) {
        valueIteratorReference8.setValue(structureChildVariable8.getValue());
    } else if (structureChildVariable8.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference8.replaceChildren(structureChildVariable8.getAllChildren());
    } else if (structureChildVariable8.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference8.replaceChildrenArray(structureChildVariable8.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{
{gdjs.evtTools.variable.variablePushCopy(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Buttons"), runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Add").getChild("Button"));
}
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList31 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.variableChildExists(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message"), "Buttons");
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Start"), true);
}

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList30(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.storage.elementExistsInJSONFile("ActionDynamicDialogBox", gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name"))));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.writeStringInJSONFile("ActionDynamicDialogBox", gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name")), "start");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.storage.elementExistsInJSONFile("ActionDynamicDialogBox", gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name")));
if (isConditionTrue_0) {
{gdjs.evtTools.storage.readStringFromJSONFile("ActionDynamicDialogBox", gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name")), runtimeScene, runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Storage").getChild("Action"));
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = eventsFunctionContext.getOnceTriggers().triggerOnce(22670292);
}
if (isConditionTrue_0) {
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ShowMessage"), false);
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList32 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message").getChild("ActionName")) != "0";
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name").setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message").getChild("ActionName")));
}

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList31(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6[i].getVariables().get("__DynamicDialogBoxBR").getChild("Image").getChild("Id")) == "Avatar" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowAvatar");
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6[i].setAnimationName(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message").getChild("Name")));
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")) == "CharacterName" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !!eventsFunctionContext.getArgument("ShowName");
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[i].setOpacity(0);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[i].getBehavior(eventsFunctionContext.getBehaviorName("MessagesBehavior")).addObjectOpacityTween("FadeIn", 255, runtimeScene.getGame().getNamedEasingsManager().resolve("easeFromTo", "DynamicDialogBoxBR"), 250, false);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message").getChild("Name")));
}
}
}

}


{

gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Text").getChild("Id")) == "Message" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].setOpacity(0);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].getBehavior(eventsFunctionContext.getBehaviorName("MessagesBehavior")).addObjectOpacityTween("FadeIn", 255, runtimeScene.getGame().getNamedEasingsManager().resolve("easeFromTo", "DynamicDialogBoxBR"), 500, false);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message").getChild("Text")));
}
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList33 = function(runtimeScene, eventsFunctionContext) {

{

gdjs.copyArray(eventsFunctionContext.getObjects("Background"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Current").getChild("Id")) == gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5.length;i<l;++i) {
    if ( gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5[i].getVariableString(gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5[i].getVariables().get("__DynamicDialogBoxBR").getChild("Background").getChild("Id")) == "Background" ) {
        isConditionTrue_0 = true;
        gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5[k] = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5[i];
        ++k;
    }
}
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5 */
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5[i].hide(false);
}
}

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList32(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList34 = function(runtimeScene, eventsFunctionContext) {

{


const keyIteratorReference4 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Id");
const valueIteratorReference4 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Message");
const iterableReference4 = runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Messages");
if(!iterableReference4.isPrimitive()) {
for(
    const iteratorKey4 in 
    iterableReference4.getType() === "structure"
      ? iterableReference4.getAllChildren()
      : iterableReference4.getType() === "array"
        ? iterableReference4.getAllChildrenArray()
        : []
) {
    if(iterableReference4.getType() === "structure")
        keyIteratorReference4.setString(iteratorKey4);
    else if(iterableReference4.getType() === "array")
        keyIteratorReference4.setNumber(iteratorKey4);
    const structureChildVariable4 = iterableReference4.getChild(iteratorKey4)
    valueIteratorReference4.castTo(structureChildVariable4.getType())
    if(structureChildVariable4.isPrimitive()) {
        valueIteratorReference4.setValue(structureChildVariable4.getValue());
    } else if (structureChildVariable4.getType() === "structure") {
        // Structures are passed by reference like JS objects
        valueIteratorReference4.replaceChildren(structureChildVariable4.getAllChildren());
    } else if (structureChildVariable4.getType() === "array") {
        // Arrays are passed by reference like JS objects
        valueIteratorReference4.replaceChildrenArray(structureChildVariable4.getAllChildrenArray());
    } else console.warn("Cannot identify type: ", type);

let isConditionTrue_0 = false;
if (true)
{

{ //Subevents: 
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList33(runtimeScene, eventsFunctionContext);} //Subevents end.
}
}
}

}


{


let isConditionTrue_0 = false;
{
{runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Current").getChild("Id").add(1);
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ShowMessage"), false);
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ChangeMessageWithChoice"), false);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "__DynamicDialogBoxBR_ChangeMessage");
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList35 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("ShowMessage"), true);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__DynamicDialogBoxBR__IsChoiceStarted.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name")), eventsFunctionContext));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__DynamicDialogBoxBR__IsActionStarted.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Action").getChild("Name")), eventsFunctionContext));
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList34(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList36 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Current").getChild("Id")) == gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Messages")));
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "__DynamicDialogBoxBR_ChangeMessage");
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("LastMessage"), true);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Current").getChild("Id")) > gdjs.evtTools.variable.getVariableChildCount(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Messages")));
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("LastMessage"), true);
}
if (isConditionTrue_0) {
gdjs.copyArray(eventsFunctionContext.getObjects("Background"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Images"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Messages"), gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects1);
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects1.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects1.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects1[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects1.length ;i < len;++i) {
    gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "__DynamicDialogBoxBR_TimeWithoutChange");
}
{gdjs.evtTools.runtimeScene.removeTimer(runtimeScene, "__DynamicDialogBoxBR_ChangeMessage");
}
{gdjs.evtTools.variable.setVariableBoolean(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Start"), false);
}
}

}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList37 = function(runtimeScene, eventsFunctionContext) {

{


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList1(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList22(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList26(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList28(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList35(runtimeScene, eventsFunctionContext);
}


{


gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList36(runtimeScene, eventsFunctionContext);
}


};gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList38 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__DynamicDialogBoxBR__IsStarted.func(runtimeScene, gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().get("__DynamicDialogBoxBR").getChild("Name")), eventsFunctionContext);
if (isConditionTrue_0) {

{ //Subevents
gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList37(runtimeScene, eventsFunctionContext);} //End of subevents
}

}


};

gdjs.evtsExt__DynamicDialogBoxBR__Create.func = function(runtimeScene, DialogLayer, Messages, MessagesBehavior, Background, Images, Buttons, AutoChangeMessage, TimeChangeMessage, DialogWidth, DialogHeight, DialogPosition, KeyChangeMessage, MessageKeyPress, MessageFinalKeyPress, Margin, Padding, ShowOverlay, OverlayColor, OvelayOpacity, ShowName, ShowAvatar, AvatarModel, CharacterNameColor, FontSizeNameCharacter, MessageColor, FontSizeMessage, MessageKeyPressColor, FontSizeKeyPress, parentEventsFunctionContext) {
let scopeInstanceContainer = null;
var eventsFunctionContext = {
  _objectsMap: {
"Messages": Messages
, "Background": Background
, "Images": Images
, "Buttons": Buttons
},
  _objectArraysMap: {
"Messages": gdjs.objectsListsToArray(Messages)
, "Background": gdjs.objectsListsToArray(Background)
, "Images": gdjs.objectsListsToArray(Images)
, "Buttons": gdjs.objectsListsToArray(Buttons)
},
  _behaviorNamesMap: {
"MessagesBehavior": MessagesBehavior
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("DynamicDialogBoxBR"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("DynamicDialogBoxBR"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
if (argName === "DialogLayer") return DialogLayer;
if (argName === "AutoChangeMessage") return AutoChangeMessage;
if (argName === "TimeChangeMessage") return TimeChangeMessage;
if (argName === "DialogWidth") return DialogWidth;
if (argName === "DialogHeight") return DialogHeight;
if (argName === "DialogPosition") return DialogPosition;
if (argName === "KeyChangeMessage") return KeyChangeMessage;
if (argName === "MessageKeyPress") return MessageKeyPress;
if (argName === "MessageFinalKeyPress") return MessageFinalKeyPress;
if (argName === "Margin") return Margin;
if (argName === "Padding") return Padding;
if (argName === "ShowOverlay") return ShowOverlay;
if (argName === "OverlayColor") return OverlayColor;
if (argName === "OvelayOpacity") return OvelayOpacity;
if (argName === "ShowName") return ShowName;
if (argName === "ShowAvatar") return ShowAvatar;
if (argName === "AvatarModel") return AvatarModel;
if (argName === "CharacterNameColor") return CharacterNameColor;
if (argName === "FontSizeNameCharacter") return FontSizeNameCharacter;
if (argName === "MessageColor") return MessageColor;
if (argName === "FontSizeMessage") return FontSizeMessage;
if (argName === "MessageKeyPressColor") return MessageKeyPressColor;
if (argName === "FontSizeKeyPress") return FontSizeKeyPress;
    return "";
  },
  getOnceTriggers: function() { return runtimeScene.getOnceTriggers(); }
};

gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects8.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects8.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects8.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects8.length = 0;

gdjs.evtsExt__DynamicDialogBoxBR__Create.eventsList38(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDMessagesObjects8.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDBackgroundObjects8.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDImagesObjects8.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects1.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects2.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects3.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects4.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects5.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects6.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects7.length = 0;
gdjs.evtsExt__DynamicDialogBoxBR__Create.GDButtonsObjects8.length = 0;


return;
}

gdjs.evtsExt__DynamicDialogBoxBR__Create.registeredGdjsCallbacks = [];