/* THE SAME DAY — 17
   Dependency-free HTML5 build: Canvas + Web Audio + localStorage.
   Designed to import into browser/web IDEs without a package manager.
*/
const canvas=document.getElementById("game"),ctx=canvas.getContext("2d");
let W=innerWidth,H=innerHeight,DPR=Math.min(devicePixelRatio||1,2);
function resize(){W=innerWidth;H=innerHeight;canvas.width=W*DPR;canvas.height=H*DPR;ctx.setTransform(DPR,0,0,DPR,0,0)}
addEventListener("resize",resize);resize();

const phases=[
["THE FIRST DREAM","PAZÍFICA"],["THE INFINITE SCHOOL","PUZZLE DIFÍCIL"],["THE BLUE BEDROOM","PAZÍFICA"],
["THE WATCHER","ENTIDADE PASSIVA"],["THE ENDLESS MALL","PUZZLE DIFÍCIL"],["CLOUD GARDEN","PAZÍFICA"],
["THE RED HALL","ENTIDADE AGRESSIVA"],["THE TEACHER'S ROOM","ENTIDADE PASSIVA"],["THE CLOCK DIMENSION","PUZZLE DIFÍCIL"],
["THE SUNSET BEACH","PAZÍFICA"],["THE EMPTY SUPERMARKET","ENTIDADE AGRESSIVA"],["THE FACELESS CLASS","ENTIDADE PASSIVA"],
["THE UPSIDE DOWN HOUSE","PUZZLE DIFÍCIL"],["THE ENDLESS PLAYGROUND","PAZÍFICA"],["THE BLACK SKY","ENTIDADE AGRESSIVA"],
["THE MEMORY ROOM","ENTIDADE PASSIVA"],["REMEMBER ME","ENTIDADE AGRESSIVA E FINAL"]
];
const palettes=[
["#72b9ff","#bde7ff","#76c78e"],["#8c7cff","#f2a5ff","#25203d"],["#b4d8ff","#e7cfff","#8a8be8"],
["#7e5f88","#a36c7c","#18101e"],["#e0a3d2","#5d68bb","#17132b"],["#9be7e1","#e8d4ff","#69a875"],
["#7b0014","#ff4b55","#160006"],["#7773a7","#d6c7e8","#262036"],["#d0a2ff","#28315c","#090b1e"],
["#ff9f64","#ffe0a7","#75b8d8"],["#a0c6b7","#f1e7b5","#263e3b"],["#d8d5d2","#9aa3ad","#20242b"],
["#c6b1ff","#6d6eaa","#25203e"],["#ffb6d8","#ffd6f2","#6d8bd1"],["#11111d","#2f2d53","#09090d"],
["#e7d3b6","#756c86","#25212e"],["#ffffff","#d8d5ff","#171329"]
];
let keys={},touch={x:0,y:0,run:false},state={
 screen:"menu",phase:0,unlocked:0,progress:[],started:false,
 x:.5,y:.5,stamina:1,objective:"",msgTimer:0,dead:false,fade:0,
 cycle:0, puzzle:null, enemy:null, phaseTime:0, interaction:null, audio:null
};
try{let s=JSON.parse(localStorage.sameDay17||"{}");state.unlocked=s.unlocked||0;state.progress=s.progress||[];}catch{}
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.key==="Escape"){togglePause()}});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);
function save(){localStorage.sameDay17=JSON.stringify({unlocked:state.unlocked,progress:state.progress})}
function ui(id,t){document.getElementById(id).textContent=t}
function showPanel(title,body){ui("panelTitle",title);ui("panelBody",body);document.getElementById("panel").classList.remove("hidden")}
function closePanel(){document.getElementById("panel").classList.add("hidden")}
document.getElementById("panelClose").onclick=closePanel;
function menu(){state.screen="menu";["pause","panel"].forEach(x=>document.getElementById(x).classList.add("hidden"));document.getElementById("menu").classList.remove("hidden")}
document.getElementById("newGame").onclick=()=>{state.unlocked=0;state.progress=[];save();startIntro()}
document.getElementById("continueGame").onclick=()=>{if(state.unlocked>=0)startPhase(Math.max(0,state.unlocked))}
document.getElementById("selectPhase").onclick=()=>{let list=phases.map((p,i)=>`${String(i+1).padStart(2,"0")} — ${p[0]} ${i<=state.unlocked?"✓":"🔒"}`).join("\n");showPanel("SELECIONAR FASE",list+"\n\nUse os números 1–9 para selecionar durante este painel.");state.screen="panel"}
document.getElementById("settings").onclick=()=>showPanel("CONFIGURAÇÕES","Sensibilidade: padrão\nÁudio: Web Audio procedural\nControles: WASD / setas / E / Shift / Esc\n\nO jogo não depende de serviços externos.")
document.getElementById("credits").onclick=()=>showPanel("CRÉDITOS","THE SAME DAY — 17\nConceito: psicológico / dreamcore / liminal\nBuild: HTML5 Canvas, JavaScript, CSS, Web Audio API\nReferência visual do protagonista: imagem fornecida pelo jogador.")
document.getElementById("resume").onclick=()=>togglePause();
document.getElementById("restart").onclick=()=>{document.getElementById("pause").classList.add("hidden");startPhase(state.phase)}
document.getElementById("backMenu").onclick=menu;

function startIntro(){state.phase=-1;state.screen="game";document.getElementById("menu").classList.add("hidden");introStep=0;state.phaseTime=0;introNext=0;playTone(220,.2)}
let introStep=0,introNext=0;
const introTexts=[
["07:00","Você acorda alegre. A manhã parece normal."],["07:20","Arrumar a cama. Escovar os dentes. Se preparar."],
["08:00","Caminho para a escola. Rostos familiares. Risadas."],["12:30","A escola termina. Você vai trabalhar."],
["13:10","Mercado. Prateleiras. Produtos. Um turno comum."],["18:40","Expediente encerrado. Você volta para casa."],
["20:10","Jantar. Silêncio confortável. A televisão ao fundo."],["23:30","Você deita. Fecha os olhos."],
["—","A chuva começa.\n\nVOCÊ JÁ ESTEVE AQUI."]
];
function updateIntro(dt){state.phaseTime+=dt;if(state.phaseTime>3.4){state.phaseTime=0;introStep++;playTone(120+introStep*20,.12)}
 if(introStep>=introTexts.length){startPhase(0);return}}
function drawIntro(){ctx.fillStyle="#0c0b14";ctx.fillRect(0,0,W,H);let t=introTexts[Math.min(introStep,introTexts.length-1)];ctx.textAlign="center";ctx.fillStyle="#fff";ctx.font="18px Georgia";ctx.fillText(t[0],W/2,H*.38);ctx.font="24px Georgia";let lines=t[1].split("\n");lines.forEach((s,i)=>ctx.fillText(s,W/2,H*.48+i*34));ctx.fillStyle="rgba(255,255,255,.35)";ctx.font="11px Georgia";ctx.fillText("O DIA PARECE NORMAL.",W/2,H*.84)}

function startPhase(i){if(i<0||i>16)return;if(i>state.unlocked)return;state.phase=i;state.screen="game";state.phaseTime=0;state.x=.5;state.y=.78;state.stamina=1;state.dead=false;state.fade=0;state.msgTimer=0;state.cycle=0;state.puzzle=makePuzzle(i);state.enemy=makeEnemy(i);state.objective=objectiveFor(i);document.querySelectorAll(".screen").forEach(x=>x.classList.add("hidden"));state.started=true;playTone(150+i*8,.18)}
function objectiveFor(i){return [
"Encontre 3 objetos familiares e abra a casa.",
"Alterne DIA / TARDE / NOITE e descubra a sequência.",
"Encontre 4 lembranças da infância.",
"Observe o Watcher e complete o padrão sem erros.",
"Descubra os símbolos e encontre a saída.",
"Explore o jardim e encontre as flores-luz.",
"Corra. Encontre a porta antes que o corredor feche.",
"Organize os objetos escolares seguindo as pistas.",
"Manipule os relógios na ordem correta.",
"Encontre as lembranças na praia e aceite que é um sonho.",
"Encontre a saída do supermercado infinito.",
"Identifique os intrusos entre os rostos sem face.",
"Reorganize a casa invertida para alcançar a porta.",
"Explore o parque e encontre a última pista.",
"Corra pela cidade enquanto o céu desaba.",
"Reconstrua a sequência da rotina inicial.",
"Fuja. A porta branca é a única saída."
][i]}
function makePuzzle(i){let p={count:0,need:[3,3,4,4,3,4,3,4,4,4,5,4,5,4,4,5,6][i],order:[],found:0,errors:0,solved:false,period:0};
 if(i===1)p.order=["DIA","TARDE","NOITE"];
 if(i===4)p.order=[2,4,1,3]; if(i===8)p.order=[1,3,2,4]; if(i===12)p.order=[3,1,4,2,5]; if(i===15)p.order=["ACORDAR","ESCOLA","MERCADO","CASA","DORMIR"];
 if(i===16)p.order=["MEMÓRIA","CULPA","PROMESSA","PORTA","QUARTO","EU"];
 return p}
function makeEnemy(i){if(![3,6,7,10,11,14,15,16].includes(i))return null;return {active:[6,10,14,16].includes(i),x:.5,y:.18,phase:0,speed:.08+(i*.003),rage:0}}
function complete(){if(state.progress.indexOf(state.phase)<0)state.progress.push(state.phase);state.unlocked=Math.max(state.unlocked,Math.min(16,state.phase+1));save();state.fade=1;setTimeout(()=>{if(state.phase===16){finale();}else{startPhase(state.phase+1)}},900)}
function finale(){state.screen="ending";document.getElementById("death").style.display="flex";document.getElementById("death").innerHTML='<div style="text-align:center">EU DISSE PARA VOCÊ NÃO ESQUECER.<br><br><span style="font-size:18px;opacity:.65">THE SAME DAY NEVER ENDS.</span></div>';setTimeout(()=>document.getElementById("death").style.display="none",7000)}

function interact(){if(state.screen!=="game"||state.phase<0||state.dead)return;
 let p=state.puzzle;
 if(state.phase===1){p.period=(p.period+1)%3;state.msgTimer=2;playTone(280+p.period*80,.12);if(p.period===2)p.found++;if(p.found>=3)complete();return}
 if(state.phase===16){if(p.found<p.need){p.found++;state.msgTimer=2;playTone(180+p.found*30,.1);if(p.found>=p.need)complete()}return}
 if([3,7,11,15].includes(state.phase)){let correct=(Math.random()>.23);if(correct){p.found++;state.msgTimer=1;playTone(420,.08)}else{p.errors++;state.msgTimer=2;playTone(70,.35);if(p.errors>=3&&state.enemy){kill("VOCÊ OLHOU PARA O LUGAR ERRADO.")}}if(p.found>=p.need)complete();return}
 if([6,10,14].includes(state.phase)){p.found++;playTone(300,.08);if(p.found>=p.need)complete();return}
 p.found++;playTone(260+p.found*20,.08);if(p.found>=p.need)complete();
}
addEventListener("keydown",e=>{if(e.key.toLowerCase()==="e")interact()});
document.getElementById("touchInteract").onclick=interact;
function togglePause(){if(!state.started||state.screen==="ending")return;if(state.screen==="game"){state.screen="pause";document.getElementById("pause").classList.remove("hidden")}else if(state.screen==="pause"){state.screen="game";document.getElementById("pause").classList.add("hidden")}}

function kill(reason){if(state.dead)return;state.dead=true;playTone(55,.8);const d=document.getElementById("death");d.textContent=reason||"VOCÊ MORREU.";d.style.display="flex";setTimeout(()=>{d.style.display="none";startPhase(state.phase)},1800)}
function move(dt){let dx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0)+touch.x,dy=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0)+touch.y;let mag=Math.hypot(dx,dy)||1;dx/=mag;dy/=mag;let run=keys.shift||touch.run;let sp=(run?.24:.12);if(run){state.stamina=Math.max(0,state.stamina-dt*.22);if(state.stamina<=0)sp=.08}else state.stamina=Math.min(1,state.stamina+dt*.12);state.x=Math.max(.03,Math.min(.97,state.x+dx*dt*sp));state.y=Math.max(.05,Math.min(.95,state.y+dy*dt*sp))}
function enemyUpdate(dt){let e=state.enemy;if(!e||!e.active)return;e.phase+=dt;let dx=state.x-e.x,dy=state.y-e.y,d=Math.hypot(dx,dy)||1;e.x+=dx/d*dt*e.speed;e.y+=dy/d*dt*e.speed;if(d<.09)kill("NÃO HÁ PARA ONDE IR.");if(state.phase===16&&Math.random()<dt*.14)showWhisper()}
function showWhisper(){const words=["LEMBRE-SE DE NÓS.","VOCÊ NÃO PODE FUGIR.","SOFRA!","OLHE PARA MIM.","VOCÊ PROMETEU.","VOLTE.","LEMBRE-SE DE MIM."];ui("message",words[Math.floor(Math.random()*words.length)]);document.getElementById("message").style.opacity=1;state.msgTimer=1.1}
function playTone(freq,dur){try{if(!state.audio)state.audio=new (AudioContext||webkitAudioContext)();let o=state.audio.createOscillator(),g=state.audio.createGain();o.type="sine";o.frequency.value=freq;g.gain.value=.025;o.connect(g);g.connect(state.audio.destination);o.start();g.gain.exponentialRampToValueAtTime(.0001,state.audio.currentTime+dur);o.stop(state.audio.currentTime+dur)}catch{}}

function worldColor(i){let p=palettes[i];let g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,p[0]);g.addColorStop(.55,p[1]);g.addColorStop(1,p[2]);return g}
function drawWorld(){let i=state.phase;ctx.fillStyle=worldColor(i);ctx.fillRect(0,0,W,H);let horizon=H*.55;
 // surreal background
 ctx.globalAlpha=.18;for(let n=0;n<16;n++){let x=(n*137+i*71)%W,y=(n*83+i*29)%horizon;ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(x,y,12+(n%4)*8,0,Math.PI*2);ctx.fill()}
 ctx.globalAlpha=1;
 if(i===0)field(); else if(i===1)school(); else if(i===2)bedroom(); else if(i===3)city(); else if(i===4)mall(); else if(i===5)garden(); else if(i===6)redhall(); else if(i===7)classroom(); else if(i===8)clock(); else if(i===9)beach(); else if(i===10)market(); else if(i===11)faceless(); else if(i===12)house(); else if(i===13)playground(); else if(i===14)blacksky(); else if(i===15)memory(); else finalWorld();
 player(); if(state.enemy&&state.enemy.active)enemyDraw();
}
function ground(c="#557f58"){ctx.fillStyle=c;ctx.fillRect(0,H*.56,W,H*.44)}
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(x,y,w,h)}
function text(s,x,y,size=18,a=1){ctx.globalAlpha=a;ctx.fillStyle="#fff";ctx.font=size+"px Georgia";ctx.fillText(s,x,y);ctx.globalAlpha=1}
function field(){ground("#5eae77");for(let x=0;x<W;x+=80){ctx.strokeStyle="rgba(255,255,255,.18)";ctx.beginPath();ctx.moveTo(x,H);ctx.lineTo(W/2+(x-W/2)*.18,H*.56);ctx.stroke()}rect(W*.72,H*.34,W*.16,H*.23,"#eee4d2");rect(W*.75,H*.42,W*.1,H*.15,"#8b6c87");text("A CASA",W*.75,H*.34,14,.55)}
function school(){ground("#7d6c9e");for(let x=0;x<W;x+=120)rect(x,H*.23,95,H*.33,x%240?"#e7c6d9":"#9fd3e7");for(let x=40;x<W;x+=140)rect(x,H*.28,55,25,"#2b233d");text(["DIA","TARDE","NOITE"][state.puzzle.period],W*.5,H*.16,24,.8)}
function bedroom(){ground("#8d86bd");for(let n=0;n<7;n++){let x=(n*160)%W;ctx.fillStyle="#f4e7ff";ctx.beginPath();ctx.arc(x,H*.43,48,0,Math.PI*2);ctx.fill()}rect(W*.43,H*.31,W*.15,H*.18,"#d9b7ef");}
function city(){ground("#7a627e");for(let x=0;x<W;x+=100){let h=90+(x*7)%190;rect(x,H*.56-h,70,h,"#33263d");rect(x+18,H*.56-h+25,15,15,"#ffd0a0");}}
function mall(){ground("#6d6790");for(let x=30;x<W;x+=130){rect(x,H*.2,90,H*.36,"#cfa8d0");rect(x+18,H*.28,55,40,"#f4d9ed")}rect(W*.47,H*.15,45,H*.4,"#e5e5ff")}
function garden(){ground("#69a875");for(let x=40;x<W;x+=100){ctx.fillStyle="#f8c8e8";ctx.beginPath();ctx.arc(x,H*.49,26,0,Math.PI*2);ctx.fill();rect(x-4,H*.49,8,H*.15,"#4f7f55")}}
function redhall(){rect(0,H*.18,W,H*.38,"#7b0014");for(let x=0;x<W;x+=100){rect(x,H*.18,4,H*.38,"#ff5564")}}
function classroom(){ground("#8d7f99");for(let x=60;x<W;x+=120){ctx.fillStyle="#222";ctx.beginPath();ctx.arc(x,H*.42,26,0,Math.PI*2);ctx.fill();rect(x-25,H*.45,50,70,"#4a4260")}}
function clock(){ground("#30355d");for(let x=80;x<W;x+=170){ctx.strokeStyle="#ddd";ctx.lineWidth=5;ctx.beginPath();ctx.arc(x,H*.35,60,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(x,H*.35);ctx.lineTo(x,H*.29);ctx.stroke();}}
function beach(){ground("#e2cda9");rect(0,H*.48,W,H*.18,"#70b7d1");ctx.fillStyle="#ff9f64";ctx.beginPath();ctx.arc(W*.78,H*.25,65,0,Math.PI*2);ctx.fill();for(let x=30;x<W;x+=180)rect(x,H*.37,100,55,"#eee3d5")}
function market(){ground("#a2b8ac");for(let x=30;x<W;x+=120){rect(x,H*.22,75,H*.32,"#cdd6cc");rect(x+10,H*.3,55,12,"#df8897");rect(x+10,H*.37,55,12,"#8aa6df")}}
function faceless(){ground("#9b9fa9");for(let x=40;x<W;x+=105){ctx.fillStyle="#eee";ctx.beginPath();ctx.arc(x,H*.4,23,0,Math.PI*2);ctx.fill();rect(x-22,H*.44,44,75,"#4d5260")}}
function house(){ground("#5c5a86");for(let n=0;n<8;n++){let x=80+n*120;rect(x,H*.25,70,70,"#d4bce8");rect(x+20,H*.14,30,110,"#a99ccc")}}
function playground(){ground("#7d8fd1");for(let x=50;x<W;x+=180){ctx.strokeStyle="#fff";ctx.lineWidth=8;ctx.beginPath();ctx.moveTo(x,H*.25);ctx.lineTo(x+60,H*.5);ctx.stroke();ctx.strokeStyle="#f4a6c6";ctx.beginPath();ctx.arc(x+30,H*.28,35,0,Math.PI);ctx.stroke()}}
function blacksky(){ground("#2f2d53");for(let x=20;x<W;x+=130){rect(x,H*.22,80,H*.34,"#11111d");rect(x+25,H*.3,14,20,"#ffd9a6");}}
function memory(){ground("#756c86");rect(W*.1,H*.25,W*.2,H*.25,"#d9c7b0");rect(W*.4,H*.25,W*.2,H*.25,"#8e82b5");rect(W*.7,H*.25,W*.2,H*.25,"#c6d2c8");}
function finalWorld(){ground("#171329");for(let n=0;n<14;n++){let x=(n*143)%W,y=.22+((n*47)%36)/100;rect(x,y*H,100,Math.max(30,H*(.62-y)),"#34304e")}rect(W*.82,H*.28,70,190,"#fff");text("SAÍDA",W*.825,H*.26,12,.8)}

function player(){let px=state.x*W,py=state.y*H;ctx.save();ctx.translate(px,py);ctx.fillStyle="#16151b";ctx.beginPath();ctx.arc(0,-25,17,0,Math.PI*2);ctx.fill();ctx.fillStyle="#202027";ctx.fillRect(-18,-8,36,58);ctx.fillStyle="#b8c0d0";ctx.fillRect(-13,-25,10,6);ctx.fillRect(3,-25,10,6);ctx.restore()}
function enemyDraw(){let e=state.enemy,ex=e.x*W,ey=e.y*H;ctx.save();ctx.translate(ex,ey);let pulse=1+Math.sin(e.phase*7)*.08;ctx.scale(pulse,pulse);ctx.fillStyle=state.phase===16?"#090909":"#160008";ctx.beginPath();ctx.arc(0,0,30,0,Math.PI*2);ctx.fill();ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(-9,-4,4,0,Math.PI*2);ctx.arc(9,-4,4,0,Math.PI*2);ctx.fill();ctx.restore()}

function update(dt){if(state.screen==="intro"){updateIntro(dt);return}if(state.screen!=="game"||state.dead)return;state.phaseTime+=dt;move(dt);enemyUpdate(dt);if(state.msgTimer>0){state.msgTimer-=dt;if(state.msgTimer<=0){document.getElementById("message").style.opacity=0}}
 if(state.phase===16&&state.phaseTime>35){showWhisper()}
 if(state.phase===6||state.phase===10||state.phase===14){if(state.phaseTime>70)kill("O LUGAR SE FECHOU SOBRE VOCÊ.")}
 ui("phaseLabel",`FASE ${String(state.phase+1).padStart(2,"0")} · ${phases[state.phase][0]}`);
 ui("objective",state.objective);
 ui("interaction",`[ E ]  interagir    ·    energia ${(state.stamina*100|0)}%`);
}
function draw(){ctx.clearRect(0,0,W,H);if(state.phase===-1)drawIntro();else if(state.screen==="game")drawWorld();else if(state.screen==="ending"){}}
let last=performance.now();function loop(t){let dt=Math.min(.05,(t-last)/1000);last=t;update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);

// touch joystick
const stick=document.getElementById("stick"),knob=stick.querySelector(".knob");let dragging=false;
stick.addEventListener("pointerdown",e=>{dragging=true;stick.setPointerCapture(e.pointerId);setStick(e)})
stick.addEventListener("pointermove",e=>{if(dragging)setStick(e)})
stick.addEventListener("pointerup",()=>{dragging=false;touch.x=touch.y=0;knob.style.transform=""})
function setStick(e){let r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=e.clientX-cx,dy=e.clientY-cy,m=Math.hypot(dx,dy)||1,max=34;if(m>max){dx=dx/m*max;dy=dy/m*max}touch.x=dx/max*.9;touch.y=dy/max*.9;knob.style.transform=`translate(${dx}px,${dy}px)`}
document.getElementById("touchRun").onpointerdown=()=>touch.run=true;document.getElementById("touchRun").onpointerup=()=>touch.run=false;

// phase select number keys from menu/panel
addEventListener("keydown",e=>{if(state.screen==="panel"&&/^[1-9]$/.test(e.key)){let n=+e.key-1;if(n<=state.unlocked){closePanel();startPhase(n)}}});
