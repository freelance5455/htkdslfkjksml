Runtime compacto em game.js: input, progressão, puzzles, entidades, áudio, UI e renderização Canvas.
