# THE SAME DAY — 17

Build jogável e autocontido em HTML5 Canvas + JavaScript + CSS, sem dependências externas.

## Compatibilidade / NanoIDE
Não encontrei documentação pública confiável que defina um formato proprietário de projeto chamado "NanoIDE". Para não inventar APIs ou bibliotecas, este pacote usa apenas tecnologias web padrão. Ele pode ser aberto em qualquer ambiente que aceite um projeto HTML/JavaScript, e o `index.html` é o ponto de entrada.

Se o seu NanoIDE exigir uma estrutura específica, abra/importa a pasta `THE_SAME_DAY_17` e selecione `index.html` como entrada. Se ele exigir um formato próprio, use `NANOIDE_IMPORT.md` para adaptar o ponto de entrada.

## Execução
1. Abra `index.html`.
2. Clique em NOVO JOGO.
3. Desktop: WASD/setas, Shift para correr, E para interagir, Esc para pausar.
4. Mobile: joystick virtual, RUN e E.

## Salvamento
O progresso é salvo no `localStorage` do navegador.

## Conteúdo
- Introdução jogável do ciclo cotidiano.
- 17 fases, na ordem pedida.
- 5 fases pacíficas.
- 4 puzzles difíceis.
- 4 fases com entidades passivas.
- 4 fases com entidades agressivas.
- Menus, pausa, checkpoints simples, morte/reinício e final.
- Atmosferas, distorções e áudio procedural via Web Audio API.
- Arte procedural dreamcore/liminal em Canvas.
- Foto fornecida usada como referência/asset de protagonista em `assets/characters/protagonist_reference.jpg`.

## Nota de escopo
Este é um jogo web funcional completo em termos de fluxo e sistemas, mas não pretende simular a escala de uma produção 3D AAA. Os cenários são gerados proceduralmente no Canvas para manter o ZIP leve, editável e sem dependências externas.
