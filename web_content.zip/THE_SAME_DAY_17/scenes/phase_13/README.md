# Phase 13 — THE UPSIDE DOWN HOUSE
Categoria: PUZZLE DIFÍCIL
Runtime: `../../game.js`.
