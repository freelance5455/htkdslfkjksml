# Phase 06 — CLOUD GARDEN
Categoria: PAZÍFICA
Runtime: `../../game.js`.
