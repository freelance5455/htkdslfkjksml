# Phase 09 — THE CLOCK DIMENSION
Categoria: PUZZLE DIFÍCIL
Runtime: `../../game.js`.
