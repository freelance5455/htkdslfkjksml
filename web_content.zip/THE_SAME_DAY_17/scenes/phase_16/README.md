# Phase 16 — THE MEMORY ROOM
Categoria: ENTIDADE PASSIVA
Runtime: `../../game.js`.
