# Phase 03 — THE BLUE BEDROOM
Categoria: PAZÍFICA
Runtime: `../../game.js`.
