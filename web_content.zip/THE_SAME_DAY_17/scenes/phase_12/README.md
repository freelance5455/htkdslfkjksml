# Phase 12 — THE FACELESS CLASS
Categoria: ENTIDADE PASSIVA
Runtime: `../../game.js`.
