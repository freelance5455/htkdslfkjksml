# Phase 02 — THE INFINITE SCHOOL
Categoria: PUZZLE DIFÍCIL
Runtime: `../../game.js`.
