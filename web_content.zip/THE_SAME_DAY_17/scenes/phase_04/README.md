# Phase 04 — THE WATCHER
Categoria: ENTIDADE PASSIVA
Runtime: `../../game.js`.
