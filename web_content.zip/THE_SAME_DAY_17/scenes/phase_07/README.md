# Phase 07 — THE RED HALL
Categoria: ENTIDADE AGRESSIVA
Runtime: `../../game.js`.
