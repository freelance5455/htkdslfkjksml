# Phase 11 — THE EMPTY SUPERMARKET
Categoria: ENTIDADE AGRESSIVA
Runtime: `../../game.js`.
