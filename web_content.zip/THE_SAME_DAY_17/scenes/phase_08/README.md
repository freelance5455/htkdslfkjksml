# Phase 08 — THE TEACHER'S ROOM
Categoria: ENTIDADE PASSIVA
Runtime: `../../game.js`.
