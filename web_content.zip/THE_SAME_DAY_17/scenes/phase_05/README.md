# Phase 05 — THE ENDLESS MALL
Categoria: PUZZLE DIFÍCIL
Runtime: `../../game.js`.
