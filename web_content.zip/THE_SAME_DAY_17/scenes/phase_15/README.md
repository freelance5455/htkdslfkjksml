# Phase 15 — THE BLACK SKY
Categoria: ENTIDADE AGRESSIVA
Runtime: `../../game.js`.
