# NANOIDE_IMPORT.md

## Estratégia segura
Como não há documentação pública confiável sobre um formato proprietário "NanoIDE", este projeto evita APIs específicas e usa a plataforma Web padrão.

Entrada:
- `index.html`

Arquivos:
- `style.css`
- `game.js`
- `assets/characters/protagonist_reference.jpg`

Não há `npm install`, servidor obrigatório ou CDN.

Se o NanoIDE tiver um template "HTML/JavaScript", importe a pasta inteira.
Se houver um campo "Main/Entry HTML", aponte para `index.html`.
