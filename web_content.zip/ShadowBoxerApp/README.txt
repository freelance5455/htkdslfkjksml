SHADOW BOXER 3D - Android project (always landscape)

1. Install Android Studio (free) and choose File > Open, then pick this ShadowBoxerApp folder.
2. Let it sync (it downloads Gradle and the Android SDK parts it needs, so it needs internet once).
3. Build > Build Bundle(s) / APK(s) > Build APK(s). The APK appears in app/build/outputs/apk/debug/.
4. Copy the APK to your phone and install it (allow "install unknown apps" if asked).

Landscape is locked in app/src/main/AndroidManifest.xml with android:screenOrientation="sensorLandscape"
(landscape in both directions). The game itself is app/src/main/assets/index.html.
To update the game later, replace that file with a new shadow-boxer-3d.html and rebuild.
