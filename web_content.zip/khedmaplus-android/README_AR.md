# Khedma Plus — Android

هذا هو مشروع Android المبني على نسخة Khedma Plus الحالية.

## البناء
1. ثبّت Node.js وAndroid Studio/Android SDK.
2. داخل مجلد المشروع:
   - `npm install`
   - `npx cap add android`
   - `npx cap sync android`
   - `npx cap open android`
3. من Android Studio أنشئ APK.

## ملاحظات مهمة
- لا تضع Supabase `service_role` داخل التطبيق.
- مشروع Supabase يحتاج URL + anon/publishable key فقط داخل التطبيق.
- نظام النقاط في النسخة الحالية: طلب نقاط → حساب السعر → صورة إثبات الدفع → موافقة الإدارة → إضافة النقاط.
- سعر النقطة حاليًا 50 دج كما هو في النموذج الحالي.
