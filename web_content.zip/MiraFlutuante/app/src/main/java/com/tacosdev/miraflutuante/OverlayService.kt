package com.tacosdev.miraflutuante

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var crosshair: CrosshairView? = null
    private var bubble: TextView? = null
    private var crossParams: WindowManager.LayoutParams? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var expanded = false
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); activeService = this }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (Build.VERSION.SDK_INT >= 26) {
            val channel=NotificationChannel("crosshair_overlay","Mira flutuante",NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
            val n=Notification.Builder(this,"crosshair_overlay").setContentTitle("Mira Flutuante ativa").setContentText("Toque na bolinha para controlar ou desativar").setSmallIcon(android.R.drawable.ic_menu_compass).build()
            startForeground(41,n)
        }
        if (Settings.canDrawOverlays(this)) showOverlay()
        return START_STICKY
    }
    private fun params(type:Int, w:Int, h:Int, gravity:Int=Gravity.TOP or Gravity.START)=WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,PixelFormat.TRANSLUCENT).apply { this.gravity=gravity }
    private fun showOverlay() {
        if (crosshair != null) return
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        crosshair=CrosshairView(this)
        crossParams=params(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,Gravity.TOP or Gravity.START).apply { flags=flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE }
        wm.addView(crosshair,crossParams)
        bubble=TextView(this).apply { text="⊙"; textSize=24f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); background=GradientDrawable().apply { shape=GradientDrawable.OVAL; setColor(Color.rgb(32,91,190)); setStroke(2,Color.WHITE) }; setOnClickListener { expanded=!expanded; text=if(expanded) "×" else "⊙"; if(expanded) showControls() else hideControls() } }
        bubbleParams=params(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,dp(52),dp(52)).apply { x=dp(16); y=dp(160) }
        bubble?.setOnTouchListener(object:View.OnTouchListener { var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(v:View,e:android.view.MotionEvent):Boolean { when(e.action){MotionEvent.ACTION_DOWN->{sx=e.rawX;sy=e.rawY;ox=bubbleParams!!.x;oy=bubbleParams!!.y;moved=false;return true};MotionEvent.ACTION_MOVE->{val dx=(e.rawX-sx).toInt();val dy=(e.rawY-sy).toInt();if(kotlin.math.abs(dx)+kotlin.math.abs(dy)>8)moved=true;bubbleParams!!.x=ox+dx;bubbleParams!!.y=oy+dy;wm.updateViewLayout(bubble,bubbleParams);return true};MotionEvent.ACTION_UP->{if(!moved){expanded=!expanded;if(expanded)showControls()else hideControls();bubble?.text=if(expanded)"×" else "⊙"};return true}};return false }
        })
        wm.addView(bubble,bubbleParams)
    }
    private var controls: TextView?=null
    private fun showControls(){ if(controls!=null)return; controls=TextView(this).apply { text="MIRA: TOQUE AQUI PARA ESCONDER\nFOV: ${fovSize}px\nToque para alternar mira"; textSize=12f; setTextColor(Color.WHITE); setPadding(dp(12),dp(10),dp(12),dp(10)); background=GradientDrawable().apply{cornerRadius=dp(12).toFloat();setColor(0xEE111827.toInt());setStroke(dp(1),Color.WHITE)}; setOnClickListener { showDot=!showDot; refresh(this@OverlayService); text=if(showDot)"MIRA ATIVA\nToque para ocultar ponto" else "PONTO OCULTO\nToque para mostrar ponto" } }; val p=params(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,dp(190),WindowManager.LayoutParams.WRAP_CONTENT).apply{x=dp(72);y=dp(160)}; wm.addView(controls,p) }
    private fun hideControls(){controls?.let{try{wm.removeView(it)}catch(_:Exception){}};controls=null}
    private fun updateControlText(){
        controls?.text = if (showDot) "MIRA FLUTUANTE\nFOV: ${fovSize}px\nToque aqui para ocultar o ponto" else "PONTO OCULTO\nFOV: ${fovSize}px\nToque aqui para mostrar o ponto"
    }
    override fun onDestroy(){ activeService = null; hideControls(); try{crosshair?.let{wm.removeView(it)};bubble?.let{wm.removeView(it)}}catch(_:Exception){};crosshair=null;bubble=null;stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy() }
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    class CrosshairView(c:Context):View(c){ private val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(2).toFloat();color=Color.WHITE;setShadowLayer(dp(2).toFloat(),0f,0f,Color.BLACK)}; private val dot=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.FILL;color=Color.RED}; private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt(); override fun onDraw(canvas:Canvas){super.onDraw(canvas);val x=width/2f;val y=height/2f;if(showFov)canvas.drawCircle(x,y,dp(fovSize).toFloat(),p); if(showDot){canvas.drawCircle(x,y,dp(3).toFloat(),dot); val q=Paint(p).apply{color=Color.WHITE;strokeWidth=dp(1).toFloat()};canvas.drawCircle(x,y,dp(8).toFloat(),q)} } }
    companion object { const val ACTION_START="start";const val ACTION_STOP="stop"; var fovSize=100;var showFov=true;var showDot=true
        @Volatile private var activeService: OverlayService? = null
        fun refresh(c:Context){
            val active = activeService
            if (active != null) {
                active.crosshair?.invalidate()
                active.updateControlText()
            } else {
                val intent = Intent(c,OverlayService::class.java).setAction(ACTION_START)
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(intent) else c.startService(intent)
            }
        } }
}
