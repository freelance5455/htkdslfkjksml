package com.tacosdev.miraflutuante

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11,18,32); window.navigationBarColor = Color.rgb(11,18,32)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,28,24,24); setBackgroundColor(Color.rgb(11,18,32)) }
        fun label(s:String, size:Float=16f)=TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE) }
        root.addView(label("MIRA FLUTUANTE", 25f))
        root.addView(label("Mira visual + círculo FOV", 15f).apply { setTextColor(Color.LTGRAY); setPadding(0,4,0,20) })
        status = label("Status: sobreposição desativada").apply { setPadding(0,0,0,14) }; root.addView(status)
        val permission = Button(this).apply { text="1. Permitir exibir sobre outros apps"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else Toast.makeText(this@MainActivity,"Permissão já concedida",Toast.LENGTH_SHORT).show() } }; root.addView(permission, match())
        root.addView(label("Tamanho do FOV",16f).apply { setPadding(0,18,0,0) })
        val seek = SeekBar(this).apply { max=240; progress=100 }; root.addView(seek, match())
        root.addView(label("Tamanho: 100 px",14f).apply { tag="sizeLabel" })
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?, p:Int, from:Boolean) { val v=(p+30).coerceAtMost(270); findViewById<View>(android.R.id.content).rootView.let { (root.getChildAt(6) as TextView).text="Tamanho: $v px" }; OverlayService.fovSize=v; OverlayService.refresh(this@MainActivity) }; override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} })
        val showFov = Switch(this).apply { text="Mostrar círculo FOV"; setTextColor(Color.WHITE); isChecked=true; setPadding(0,8,0,8); setOnCheckedChangeListener { _, checked -> OverlayService.showFov=checked; OverlayService.refresh(this@MainActivity) } }; root.addView(showFov)
        val showDot = Switch(this).apply { text="Mostrar ponto central"; setTextColor(Color.WHITE); isChecked=true; setPadding(0,8,0,8); setOnCheckedChangeListener { _, checked -> OverlayService.showDot=checked; OverlayService.refresh(this@MainActivity) } }; root.addView(showDot)
        val start = Button(this).apply { text="2. ATIVAR MIRA FLUTUANTE"; setOnClickListener { if (!Settings.canDrawOverlays(this@MainActivity)) { Toast.makeText(this@MainActivity,"Primeiro permita exibir sobre outros apps",Toast.LENGTH_LONG).show(); return@setOnClickListener }; val i=Intent(this@MainActivity,OverlayService::class.java).setAction(OverlayService.ACTION_START); if (Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i); status.text="Status: mira ativada — pode sair do app" } }; root.addView(start, match())
        val stop = Button(this).apply { text="DESATIVAR E REMOVER DA TELA"; setOnClickListener { stopService(Intent(this@MainActivity,OverlayService::class.java)); status.text="Status: sobreposição desativada" } }; root.addView(stop, match())
        root.addView(label("A mira é apenas visual; não altera a assistência de mira do jogo.",12f).apply { setTextColor(Color.LTGRAY); setPadding(0,18,0,0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun match() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin=6 }
    override fun onResume() { super.onResume(); if (::status.isInitialized && Settings.canDrawOverlays(this)) status.text="Status: permissão de sobreposição disponível" }
}
