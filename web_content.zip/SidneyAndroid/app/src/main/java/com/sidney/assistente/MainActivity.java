package com.sidney.assistente;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 7001;
    private static final int REQ_SPEECH = 7002;
    private WebView web;
    private TextToSpeech tts;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("sidney", MODE_PRIVATE);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        tts = new TextToSpeech(this, status -> { if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("pt","BR")); });
    }

    public class Bridge {
        @JavascriptInterface public String getApiKey() { return prefs.getString("api_key", ""); }
        @JavascriptInterface public boolean hasApiKey() { return !getApiKey().trim().isEmpty(); }
        @JavascriptInterface public void saveApiKey(String key) { prefs.edit().putString("api_key", key == null ? "" : key).apply(); }

        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> { if (tts != null) { tts.stop(); tts.setLanguage(new Locale("pt","BR")); tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sidney"); } });
        }
        @JavascriptInterface public void stopSpeaking() { runOnUiThread(() -> { if (tts != null) tts.stop(); }); }

        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO); return;
                }
                try {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR");
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o Sidney");
                    startActivityForResult(i, REQ_SPEECH);
                } catch (Exception e) { toast("Reconhecimento de voz indisponível neste aparelho."); }
            });
        }

        @JavascriptInterface public void askAI(String contentsJson, String system) {
            final String key = getApiKey().trim();
            if (key.isEmpty()) { jsError("Configure a chave da IA no aplicativo."); return; }
            new Thread(() -> {
                try {
                    URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent");
                    HttpURLConnection c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000);
                    c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key); c.setDoOutput(true);
                    JSONObject body = new JSONObject();
                    body.put("systemInstruction", new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
                    body.put("contents", new JSONArray(contentsJson));
                    body.put("generationConfig", new JSONObject().put("temperature", .4).put("maxOutputTokens", 700));
                    try(OutputStream os = c.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                    int code = c.getResponseCode();
                    BufferedReader br = new BufferedReader(new InputStreamReader(code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder out = new StringBuilder(); String line; while((line=br.readLine())!=null) out.append(line);
                    JSONObject res = new JSONObject(out.toString());
                    if (code >= 400) throw new Exception(res.optJSONObject("error") != null ? res.getJSONObject("error").optString("message", "Erro na IA") : "Erro HTTP " + code);
                    JSONArray parts = res.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts");
                    String answer = parts.getJSONObject(0).optString("text", "").trim();
                    if(answer.isEmpty()) throw new Exception("A IA não retornou texto.");
                    jsSuccess(answer);
                } catch(Exception e) { jsError(e.getMessage() == null ? "Erro ao consultar a IA." : e.getMessage()); }
            }).start();
        }
    }

    private void jsSuccess(String text) { String js = "javascript:finishAI(" + JSONObject.quote(text) + ")"; runOnUiThread(() -> web.evaluateJavascript(js, null)); }
    private void jsError(String text) { String js = "javascript:aiError(" + JSONObject.quote(text) + ")"; runOnUiThread(() -> web.evaluateJavascript(js, null)); }
    private void toast(String s) { runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show()); }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQ_SPEECH) {
            String text = "";
            if(resultCode == RESULT_OK && data != null) {
                ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if(r != null && !r.isEmpty()) text = r.get(0);
            }
            web.evaluateJavascript("javascript:androidVoiceResult(" + JSONObject.quote(text) + ")", null);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if(requestCode == REQ_AUDIO && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) ((Bridge) new Bridge()).startVoice();
    }

    @Override protected void onDestroy() { if(tts != null){ tts.stop(); tts.shutdown(); } if(web != null) web.destroy(); super.onDestroy(); }
}
