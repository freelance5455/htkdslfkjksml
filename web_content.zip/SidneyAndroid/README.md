# Sidney — seu assistente virtual (Android)

Projeto Android baseado no HTML corrigido do S.I.D. Fácil.

## Recursos
- WebView com a interface neon do Sidney.
- Voz nativa do Android (TextToSpeech).
- Reconhecimento de voz nativo.
- Integração com Gemini usando a chave configurada no próprio app.
- Espaços reservados para publicidade/monetização.
- Memória local da conversa.

## Como gerar o APK
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Use **Build > Build APK(s)**.
4. Instale o APK de `app/build/outputs/apk/debug/app-debug.apk` no Android.

O ambiente desta sessão não possui Android SDK/Gradle instalados, portanto o APK compilado não pôde ser produzido aqui.
