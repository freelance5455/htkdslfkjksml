LOUIS CBE ANALYZER - FULL (15 features, multi-school, 6 roles)

Two ways to run it. Same app, same features.

A) index.html (works immediately, no setup)
   Open it in Chrome or host it. Data is saved in that browser only.
   System administrator password: the default I gave you in chat. Change it on first login.
   Backup/restore: Admin > Backup.

B) AppsScript_Deploy (shared data for all teachers, all devices)
   1. Create a Google Sheet > Extensions > Apps Script.
   2. Paste Code.gs. Add an HTML file named exactly Index and paste Index.html.
   3. Run setup once and approve permissions.
   4. Deploy > New deployment > Web app > Execute as Me > Anyone.
   5. Open the link ending in /exec (never the /dev link, never the local file).
   This mode encrypts marks and phone numbers with a key only the script can read.

Limits: no automatic SMS/email sending (results open your own SMS/Gmail app);
index.html mode has no server-side encryption; not a compiled .apk
(host index.html, then pwabuilder.com > Android).
