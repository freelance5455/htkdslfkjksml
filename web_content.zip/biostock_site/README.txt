BIOSTOCK – Gestion du stock biomédical

Pour tester : ouvrez index.html dans Chrome, Edge ou Firefox.
Pour publier et obtenir une adresse internet : déposez index.html sur un hébergement statique HTTPS (par exemple Netlify, GitHub Pages ou un hébergement web classique). Le site sera alors accessible depuis Android et ordinateur.

Fonctions : tableau de bord, dispositifs médicaux, pièces de rechange, consommables/accessoires, mouvements, pannes, nouveaux appareils, maintenance, commandes, réformes, fournisseurs, observations, recherche, ajout/modification/suppression, export CSV, sauvegarde/restauration JSON et impression PDF.

Important : cette première version stocke les données localement dans le navigateur. Elles ne sont pas partagées entre plusieurs appareils et peuvent être perdues si les données du navigateur sont effacées. Exportez régulièrement le fichier JSON. Pour accès multi-utilisateurs, connexion et synchronisation cloud, il faudra connecter une base de données et héberger le service.
