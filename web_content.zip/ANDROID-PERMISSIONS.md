# Permissões Android

A gravação usa `navigator.mediaDevices.getUserMedia({ audio: true })`. O WebView solicita permissão em tempo de execução. Se o Android Studio gerar um manifesto sem a permissão de microfone, adicione dentro de `<manifest>` em `android/app/src/main/AndroidManifest.xml`:

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
```

O app salva arquivos em Documentos pelo plugin Capacitor Filesystem e abre o compartilhamento nativo pelo Capacitor Share.
