import { defineConfig } from 'vite';
// base './' lets the build run from any folder / static host
export default defineConfig({ base: './', build: { chunkSizeWarningLimit: 900 } });
