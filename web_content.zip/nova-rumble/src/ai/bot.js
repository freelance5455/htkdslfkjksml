// A bot: same hitboxes, weapons, loot, zone and damage rules as the player, plus a brain.
// States: drop (plane/fall/chute), loot, zone, patrol, detect, chase, attack, cover, heal, flee, revive, downed.
// Perception is honest: 90 degree view cone + close-range awareness, line of sight, and hearing of shots/footsteps. No wall-hacks.
import * as THREE from 'three';
import { buildCharacter } from '../game/characterModel.js';
import { buildGun } from '../game/weaponModel.js';
import { headCenter, entityScale } from '../game/hitbox.js';
import { step, unstick } from '../game/mover.js';
import { WEAPONS } from '../data/weapons.js';
import { DIFFICULTY, SIGHT, WEAPON_RANK } from '../data/bots.js';

const rank = id => WEAPON_RANK[id] || 0, gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.5, dirFrom = (y, p) => new THREE.Vector3(-Math.sin(y) * Math.cos(p), Math.sin(p), -Math.cos(y) * Math.cos(p));
const angDiff = (a, b) => { let d = a - b; while (d > Math.PI) d -= 6.2832; while (d < -Math.PI) d += 6.2832; return d; };
const tmp = new THREE.Vector3(), tmp2 = new THREE.Vector3();

// Bot inventory with the same interface the loot manager uses for the player (pickupWeapon / addAmmo).
class BotWeapons {
  reset() { this.slots = [null, null]; this.cur = -1; this.mags = {}; for (const k in this.reserve) this.reserve[k] = 0; this.cd = 0; this.reloadT = 0; this.bloom = 0; }
  constructor() { this.slots = [null, null]; this.cur = -1; this.mags = {}; this.reserve = { AR: 0, SMG: 0, SNP: 0, SHT: 0, PST: 0 }; this.cd = 0; this.reloadT = 0; this.bloom = 0; }
  get id() { return this.cur < 0 ? 'fist' : (this.slots[this.cur] || 'fist'); }
  get w() { return WEAPONS[this.id]; }
  get mag() { return this.mags[this.id] || 0; }
  get ammoLeft() { return this.w.ammo ? this.reserve[this.w.ammo] : 0; }
  pickupWeapon(id) {
    const w = WEAPONS[id]; if (this.slots.includes(id)) { this.reserve[w.ammo] += w.mag; return 'dup'; }
    const slot = !this.slots[0] ? 0 : !this.slots[1] ? 1 : (rank(this.slots[0]) <= rank(this.slots[1]) ? 0 : 1), old = this.slots[slot];
    this.slots[slot] = id; this.mags[id] = w.mag; this.pickBest(); return old;
  }
  wants(id) { return !this.slots.includes(id) && (!this.slots[0] || !this.slots[1] || rank(id) > Math.min(rank(this.slots[0]), rank(this.slots[1]))); }
  addAmmo(t, n) { this.reserve[t] += n; }
  pickBest() { let b = -1, br = -1; this.slots.forEach((s, i) => { if (s && rank(s) > br && (this.mags[s] > 0 || this.reserve[WEAPONS[s].ammo] > 0)) { b = i; br = rank(s); } }); this.cur = b; }
}

export class Bot {
  constructor(match, id, name, def, team, level) {
    this.match = match; this.world = match.world; this.id = id; this.name = name; this.team = team; this.levelName = level; this.diff = DIFFICULTY[level];
    this.isPlayer = false; this.pos = new THREE.Vector3(); this.vel = new THREE.Vector3(); this.grounded = true; this.stance = 'stand'; this.height = 1.9;
    this.hp = 200; this.maxHp = 200; this.armor = 0; this.helmet = 0; this.items = { medkit: 0, grenade: 0, gloo: 0 }; this.backpack = 0; this.weapons = new BotWeapons();
    this.alive = true; this.downed = false; this.kills = 0; this.yaw = Math.random() * 6.28; this.pitch = 0; this.state = 'drop'; this.air = 'plane'; this.inPlane = true;
    this.path = []; this.dest = null; this.needPath = false; this.thinkT = Math.random() * 0.3; this.enemy = null; this.seen = null; this.reactT = 0; this.aimHead = false; this.heard = null; this.lastNoiseT = 0;
    this.strafeDir = 1; this.strafeT = 0; this.stuckT = 0; this.sideT = 0; this.healT = 0; this.reviveT = 0; this.lootTarget = null; this.bad = new Set(); this.coverPt = null; this.hurtT = -9; this.lastAttacker = null; this.burstT = 0;
    this.protectT = 0; this.money = 0; this.offX = (Math.random() - 0.5) * 20; this.offZ = (Math.random() - 0.5) * 20; this.speed = 0; this.walkPhase = 0; this.deadT = 0; this.rendered = false; this.lodAcc = 0; this.gunId = null; this.fireHold = 0; this.stepT = Math.random();
    // model
    this.root = new THREE.Group(); this.yawG = new THREE.Group(); this.tilt = new THREE.Group(); this.char = buildCharacter(def); this.char.group.traverse(o => { if (o.isMesh && !o.material.side) o.castShadow = true; });
    this.tilt.add(this.char.group); this.yawG.add(this.tilt); this.root.add(this.yawG);
    this.canopy = new THREE.Group(); const dome = new THREE.Mesh(new THREE.SphereGeometry(2.7, 10, 6, 0, 6.2832, 0, Math.PI / 2), new THREE.MeshToonMaterial({ color: 0xff6bd6, side: THREE.DoubleSide })); dome.position.y = 3.4; this.canopy.add(dome); this.canopy.visible = false; this.root.add(this.canopy);
  }
  get hidden() { return this.inPlane; }
  nameTag() {                                                       // green name above teammates only
    const c = document.createElement('canvas'); c.width = 256; c.height = 48; const g = c.getContext('2d'); g.fillStyle = 'rgba(20,8,46,.7)'; g.fillRect(0, 4, 256, 40); g.fillStyle = '#4ade80'; g.font = 'bold 26px Arial'; g.textAlign = 'center'; g.fillText(this.name, 128, 34);
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false })); s.scale.set(2.4, 0.45, 1); s.position.y = 2.7; this.root.add(s);
  }
  setRendered(on) { if (on === this.rendered) return; this.rendered = on; on ? this.match.scene.add(this.root) : this.match.scene.remove(this.root); }
  get eye() { return tmp2.set(this.pos.x, this.pos.y + (this.stance === 'stand' ? 1.55 : 1.1), this.pos.z); }

  // ---- damage ----------------------------------------------------------------------------------------------
  takeHit(dmg, part, head, shooter) {
    if (!this.alive || this.inPlane || this.protectT > 0) return false;
    this.hp -= dmg; this.hurtT = this.match.t; this.lastAttacker = shooter || null;
    if (shooter && shooter.pos) { this.heard = { x: shooter.pos.x + gauss() * 6, z: shooter.pos.z + gauss() * 6, t: this.match.t }; if (!this.enemy) this.reactT = Math.max(this.reactT, this.diff.react * 0.5); }   // we know roughly where it came from
    if (this.hp > 0) return false;
    if (!this.downed && this.match.canDown(this)) { this.downed = true; this.hp = 100; this.state = 'downed'; this.path = []; this.enemy = null; return false; }
    this.die(shooter, head); return true;
  }
  resetForRound(p, yaw) {                                           // new round / respawn in team modes
    this.pos.set(p.x, p.y || 0, p.z); this.vel.set(0, 0, 0); this.hp = this.maxHp; this.alive = true; this.downed = false; this.state = 'patrol'; this.air = null; this.inPlane = false; this.path = []; this.dest = null; this.needPath = false;
    this.enemy = null; this.seen = null; this.heard = null; this.lootTarget = null; this.coverPt = null; this.healT = 0; this.reviveT = 0; this.stance = 'stand'; this.yaw = yaw; this.pitch = 0; this.deadT = 0; this.grounded = true; this.thinkT = Math.random() * 0.6;
    this.tilt.rotation.x = 0; this.tilt.scale.y = 1; this.tilt.position.y = 0; this.canopy.visible = false; this.bad.clear(); this.lodAcc = 0; this.stuckT = 0; this.weapons.cd = 0; this.weapons.reloadT = 0;
  }
  revive() { this.downed = false; this.hp = 80; this.state = 'patrol'; this.stance = 'stand'; }
  die(killer, head) {
    this.alive = false; this.downed = false; this.deadT = 0; this.state = 'dead'; this.hp = 0; this.match.onKill(this, killer, head); this.match.dropLoot(this);
  }

  // ---- perception ----------------------------------------------------------------------------------------------
  sightRange() { return Math.min(SIGHT.maxRange, (this.weapons.w.range || 10) + 25); }
  perceive() {
    const m = this.match, range = this.sightRange(), eye = this.eye.clone(); let best = null, bd = 1e9;
    for (const e of m.nearEnemies(this, range)) {
      tmp.set(e.pos.x - this.pos.x, 0, e.pos.z - this.pos.z); const dist = tmp.length(); if (dist > range) continue;
      const bearing = Math.atan2(-tmp.x, -tmp.z);
      if (dist > SIGHT.close && Math.abs(angDiff(bearing, this.yaw)) > SIGHT.fov / 2) continue;               // outside the view cone
      const tp = tmp2.set(e.pos.x, e.pos.y + 1.25 * entityScale(e), e.pos.z), dir = tp.clone().sub(eye), len = dir.length(); dir.divideScalar(len);
      if (this.world.raycast(eye, dir, len - 0.5) < len - 0.7) continue;                                         // wall / ground in the way
      const score = dist + (e.downed ? 60 : 0); if (score < bd) { bd = score; best = e; }
    }
    if (best) {
      if (this.enemy !== best) { this.enemy = best; this.reactT = this.diff.react * (0.75 + Math.random() * 0.5); this.aimHead = Math.random() < this.diff.head; }
      this.seen = { x: best.pos.x, z: best.pos.z, t: m.t }; if (m.teamSize > 1) m.shareEnemy(this, best);          // squad AI: tell teammates where the enemy is
    } else if (this.enemy && m.t - (this.seen ? this.seen.t : -99) > 3) this.enemy = null;
    this.visible = !!best;
    for (const n of m.noises) {                                                                                  // hearing: shots and footsteps
      if (n.t <= this.lastNoiseT || n.owner === this || n.team === this.team) continue; if (Math.hypot(n.x - this.pos.x, n.z - this.pos.z) < n.r) this.heard = { x: n.x + gauss() * 5, z: n.z + gauss() * 5, t: n.t };
    }
    this.lastNoiseT = m.t;
  }

  // ---- decisions (every ~0.25 s) ----------------------------------------------------------------------------------
  think() {
    const m = this.match, d = this.diff, now = m.t, W = this.weapons; if (this.downed) { this.state = 'downed'; return; }
    this.perceive(); const hpf = this.hp / this.maxHp, recent = this.seen && now - this.seen.t < 2.5;
    // an unarmed bot looks for a weapon first and only fist-fights when someone is right next to it
    const armed = m.fistsOnly || W.slots.some(id => id && (W.mags[id] > 0 || W.reserve[WEAPONS[id].ammo] > 0)), close = this.enemy && this.visible && Math.hypot(this.enemy.pos.x - this.pos.x, this.enemy.pos.z - this.pos.z) < 3.5;
    if (!W.w || (W.cur < 0 && W.slots.some(Boolean))) W.pickBest();
    if (this.state === 'heal' && this.healT > 0) { if (this.visible) { this.healT = 0; this.state = 'cover'; } else return; }        // interrupted by an enemy
    if ((this.visible || recent) && (armed || close)) {
      if (hpf < 0.25 && (this.items.medkit === 0 || hpf < 0.12)) return this.setState('flee');
      if (hpf < 0.55 && (this.hurtT > now - 4) && Math.random() < d.cover) return this.goCover();
      const dist = this.enemy ? Math.hypot(this.enemy.pos.x - this.pos.x, this.enemy.pos.z - this.pos.z) : 99, eff = Math.max(8, W.w.range * 0.7);
      if (this.visible && this.items.grenade > 0 && dist > 12 && dist < 35 && Math.random() < d.grenade * 0.3) m.throwGrenade(this, this.enemy.pos);
      if (this.visible && this.items.gloo > 0 && this.hurtT > now - 1.5 && Math.random() < d.gloo * 0.4) m.placeGloo(this, this.enemy.pos.x - this.pos.x, this.enemy.pos.z - this.pos.z);
      return this.setState(this.visible && dist < eff ? 'attack' : 'chase', recent && !this.visible ? this.seen : this.enemy && this.enemy.pos);
    }
    if (armed && this.heard && now - this.heard.t < 8) { if (this.state !== 'detect') this.setState('detect', this.heard); return; }
    if (this.items.medkit > 0 && hpf < 0.6 && this.state !== 'heal') { this.healT = 3; return this.setState('heal'); }
    const mate = m.downedMate(this); if (mate) return this.setState('revive', mate.pos);
    const z = m.zone; if (z && !this.air) {
      if (!z.inside(this.pos.x, this.pos.z)) { if (this.state === 'zone' && (this.path.length || this.needPath)) return; return this.setState('zone', this.zonePoint(false)); }
      if (z.showNext && Math.hypot(this.pos.x - z.nx, this.pos.z - z.nz) > z.nr * 0.9 && !this.lootTarget) { if (this.state === 'zone' && (this.path.length || this.needPath)) return; return this.setState('zone', this.zonePoint(true)); }
    }
    const lead = m.leaderOf(this);                                  // squad AI: stay near the team leader
    if (lead && m.followLeader !== false && !lead.air && Math.hypot(lead.pos.x - this.pos.x, lead.pos.z - this.pos.z) > 30) { if (this.state === 'follow' && (this.path.length || this.needPath)) return; return this.setState('follow', { x: lead.pos.x + this.offX * 0.5, z: lead.pos.z + this.offZ * 0.5 }); }
    const item = !m.loot ? null : (this.lootTarget && this.lootTarget.active) ? this.lootTarget : m.loot.pickFor(this);
    if (item) { this.lootTarget = item; return this.setState('loot', item); }
    if (this.state !== 'patrol' || !this.path.length) this.setState('patrol', m.patrolPoint ? m.patrolPoint(this) : this.zonePoint(true, 60));
  }
  zonePoint(next, spread = 0.6) {
    const z = this.match.zone, cx = next && z.showNext ? z.nx : z.cur.x, cz = next && z.showNext ? z.nz : z.cur.z, r = (next && z.showNext ? z.nr : z.cur.r) * spread, a = Math.random() * 6.28, d = Math.sqrt(Math.random()) * Math.min(r, 80);
    return { x: cx + Math.cos(a) * d, z: cz + Math.sin(a) * d };
  }
  setState(s, target) {
    if (s !== this.state) { this.state = s; this.path = []; this.dest = null; this.tries = 0; }
    if (target && s !== 'attack' && s !== 'heal') { const d = this.dest; if (!d || Math.hypot(d.x - (target.x ?? target.pos.x), d.z - (target.z ?? target.pos.z)) > 6 || !this.path.length) this.goTo(target); }
  }
  goTo(t) { this.dest = t.kind ? { x: t.x, z: t.z, item: t } : { x: t.x, z: t.z }; this.needPath = true; this.stuckT = 0; }
  goCover() {                                                       // hide behind something that blocks the enemy's line of sight
    const e = this.enemy || this.seen; if (!e) return this.setState('flee'); const ex = e.pos ? e.pos.x : e.x, ez = e.pos ? e.pos.z : e.z, eye = new THREE.Vector3(ex, this.pos.y + 1.4, ez);
    for (let i = 0; i < 10; i++) {
      const a = Math.random() * 6.28, r = 4 + Math.random() * 8, x = this.pos.x + Math.cos(a) * r, z = this.pos.z + Math.sin(a) * r; if (!this.match.nav.isFree(x, z)) continue;
      const to = new THREE.Vector3(x, this.pos.y + 1.2, z).sub(eye), len = to.length(); to.divideScalar(len);
      if (this.world.raycast(eye, to, len) < len - 0.5) { this.state = 'cover'; this.coverPt = { x, z }; this.goTo({ x, z }); return; }
    }
    this.setState('flee');
  }
  // building routes: bots enter through the door and use the stairs (the grid keeps them out of walls)
  routeWaypoints(item) {
    const B = item.b !== undefined ? this.world.buildings[item.b] : null; if (!B) return null; const w = [B.doorOut, B.doorIn];
    for (let f = 0; f < (item.f || 0); f++) { const s = B.stairs[f]; if (!s) break; w.push(s.bottom, s.top, s.exit); } w.push({ x: item.x, z: item.z }); return w;
  }
  leaveWaypoints() {                                                // walk back down and out if we are inside a building
    const B = this.world.buildingAt(this.pos.x, this.pos.z); if (!B) return [];
    const f = Math.max(0, Math.round((this.pos.y - B.base) / 3.2)), w = []; for (let k = f - 1; k >= 0; k--) { const s = B.stairs[k]; if (s) w.push(s.exit, s.top, s.bottom); } w.push(B.doorIn, B.doorOut); return w;
  }
  computePath() {
    const d = this.dest; if (!d) return; this.needPath = false; const leave = this.leaveWaypoints(); let tail = [];
    let target = { x: d.x, z: d.z }; if (d.item) { const r = this.routeWaypoints(d.item); if (r) { target = r[0]; tail = r.slice(1); } }
    const from = leave.length ? leave[leave.length - 1] : this.pos, nav = this.match.nav.find(from.x, from.z, target.x, target.z);
    if (!nav) { this.fail(); return; }
    this.path = [...leave, ...nav, ...(tail.length ? [target] : []), ...tail];
  }
  fail() { if (this.dest && this.dest.item) this.bad.add(this.dest.item); this.lootTarget = null; this.path = []; this.dest = null; this.state = 'patrol'; this.thinkT = 0.1; }

  // ---- acting every frame -------------------------------------------------------------------------------------------
  update(dt, time) {
    const m = this.match;
    if (!this.alive) { this.deadT += dt; if (this.rendered) { this.tilt.rotation.x += (-1.5 - this.tilt.rotation.x) * Math.min(1, dt * 6); if (this.deadT > 6) this.setRendered(false); } return; }
    if (this.state === 'drop') return this.updateDrop(dt);
    this.protectT = Math.max(0, this.protectT - dt); const near = m.distToPlayer(this); this.setRendered(near < 175);
    this.lodAcc += dt; if (near > 220 && this.lodAcc < 0.1) return; const adt = this.lodAcc; this.lodAcc = 0;    // far bots update at 10 Hz
    this.thinkT -= adt; if (this.thinkT <= 0) { this.thinkT = this.diff.think * (0.8 + Math.random() * 0.4); this.think(); }
    const W = this.weapons; W.cd = Math.max(0, W.cd - adt); W.bloom = Math.max(0, W.bloom - adt * 0.9);
    if (W.reloadT > 0 && (W.reloadT -= adt) <= 0) { W.reloadT = 0; const w = W.w, take = Math.min(w.mag - W.mag, W.reserve[w.ammo]); W.mags[W.id] += take; W.reserve[w.ammo] -= take; }
    if (this.needPath && m.takePathBudget()) this.computePath();
    if (this.downed) { this.stance = 'prone'; this.hp -= 3 * adt; if (this.hp <= 0) this.die(this.lastAttacker, false); this.move(adt, 0, 0); this.animate(adt, time); return; }
    this.act(adt); this.animate(adt, time);
  }
  act(dt) {
    const m = this.match, W = this.weapons, d = this.diff; let wx = 0, wz = 0, sp = 0, aimPt = null, crouch = false;
    const follow = (speed) => {                                     // walk along the waypoint list
      while (this.path.length) { const p = this.path[0], dx = p.x - this.pos.x, dz = p.z - this.pos.z, dist = Math.hypot(dx, dz); if (dist < (this.path.length > 1 ? 1.3 : 0.9)) { this.path.shift(); continue; } wx = dx / dist * speed; wz = dz / dist * speed; sp = speed; return true; }
      return false;
    };
    switch (this.state) {
      case 'attack': case 'chase': {
        const e = this.enemy; if (e && this.visible && e.alive) {
          const dx = e.pos.x - this.pos.x, dz = e.pos.z - this.pos.z, dist = Math.hypot(dx, dz), eff = Math.max(8, W.w.range * 0.7); aimPt = (this.aimHead ? headCenter(e, tmp) : tmp.set(e.pos.x, e.pos.y + 1.2 * entityScale(e), e.pos.z)).clone();
          if (this.state === 'attack') {                              // strafe sideways, keep distance
            this.strafeT -= dt; if (this.strafeT <= 0) { this.strafeT = 0.7 + Math.random() * 1.2; this.strafeDir = Math.random() < 0.5 ? -1 : 1; if (Math.random() < d.cover * 0.5) this.stance = this.stance === 'crouch' ? 'stand' : 'crouch'; }
            const melee = W.w.type === 'melee', ux = dx / dist, uz = dz / dist, fwd = melee ? (dist > 1.5 ? 1 : 0) : dist > eff * 0.8 ? 1 : dist < 7 && W.w.type !== 'shotgun' ? -1 : 0, s = melee ? 6 : this.stance === 'crouch' ? 2.2 : 3.4, side = melee ? 0.2 : 0.8;
            wx = (-uz * this.strafeDir * side + ux * fwd) * s; wz = (ux * this.strafeDir * side + uz * fwd) * s; sp = s; crouch = this.stance === 'crouch';
          } else { if (this.path.length === 0 && !this.needPath) this.goTo(e.pos); follow(W.w.type === 'melee' ? 7.4 : 5.5); }
        } else if (this.seen && !this.path.length && !this.needPath) this.goTo(this.seen); else follow(5.5);
        break;
      }
      case 'cover': if (!follow(7)) { crouch = true; this.stance = 'crouch'; const hpf = this.hp / this.maxHp; if (this.items.medkit > 0 && hpf < 0.7 && !this.visible) { this.healT = 3; this.state = 'heal'; } else if (W.mag < W.w.mag * 0.5) this.startReload(); else if (!this.visible) this.state = 'patrol'; } break;
      case 'heal': crouch = true; this.stance = 'crouch'; this.healT -= dt; if (this.healT <= 0) { this.hp = Math.min(this.maxHp, this.hp + 100); this.items.medkit--; this.state = 'patrol'; this.stance = 'stand'; } break;
      case 'flee': { const e = this.seen; if (!this.path.length && !this.needPath && e) { const a = Math.atan2(this.pos.z - e.z, this.pos.x - e.x); this.goTo({ x: this.pos.x + Math.cos(a) * 40, z: this.pos.z + Math.sin(a) * 40 }); } if (!follow(7.4) && !this.needPath) this.state = 'patrol'; if (this.hp / this.maxHp > 0.4 || (this.items.medkit > 0 && !this.visible)) this.state = 'patrol'; break; }
      case 'revive': { const mate = this.match.downedMate(this); if (!mate) { this.state = 'patrol'; break; } const dist = Math.hypot(mate.pos.x - this.pos.x, mate.pos.z - this.pos.z);
        if (dist < 1.9) { crouch = true; this.reviveT += dt; this.facePoint(mate.pos, dt); if (this.reviveT >= 4) { mate.revive(); this.reviveT = 0; this.state = 'patrol'; } } else { this.reviveT = 0; follow(6.5); } break; }
      case 'loot': {
        const it = this.lootTarget; if (!it || !it.active) { this.lootTarget = null; this.state = 'patrol'; break; }
        if (Math.hypot(it.x - this.pos.x, it.z - this.pos.z) < 1.4 && Math.abs(it.y - this.pos.y) < 2.5) { m.loot.takeFor(it, this); this.lootTarget = null; this.path = []; W.pickBest(); this.thinkT = 0; break; }
        if (!follow(it.kind === 'crate' ? 6.5 : 6) && !this.needPath) { if (++this.tries > 3) { this.tries = 0; this.fail(); } else this.goTo(it); }
        break;
      }
      default: if (!follow(this.state === 'zone' ? 7.4 : this.state === 'follow' ? 6.2 : 4.6)) { if (this.state === 'detect') { this.state = 'patrol'; this.heard = null; } this.sp = 0; }
    }
    // reload when empty / idle, then shoot
    if (W.cur >= 0 && W.w.type !== 'melee' && W.reloadT <= 0 && (W.mag <= 0 || (!this.visible && W.mag < W.w.mag * 0.5 && !this.heard)) && W.reserve[W.w.ammo] > 0) this.startReload();
    if (W.mag <= 0 && W.reserve[W.w.ammo || 'AR'] <= 0 && W.cur >= 0) W.pickBest();
    if (aimPt) { this.aim(aimPt, dt); this.reactT -= dt; this.tryFire(dt, aimPt); }
    else if (this.state === 'detect' && this.heard) this.facePointXZ(this.heard.x, this.heard.z, dt); else if (sp > 0.1) this.faceDir(wx, wz, dt);
    if (this.state !== 'attack' && this.state !== 'cover' && this.state !== 'heal') this.stance = this.stance === 'prone' ? 'stand' : (this.state === 'revive' && crouch ? 'crouch' : 'stand');
    this.move(dt, wx, wz);
  }
  move(dt, wx, wz) {
    const wet = this.world.heightAt(this.pos.x, this.pos.z) < -0.2; if (wet) { wx *= 0.55; wz *= 0.55; } if (this.downed) { wx *= 0.3; wz *= 0.3; }
    this.height = this.stance === 'stand' ? 1.9 : this.stance === 'crouch' ? 1.3 : 0.6;
    step(this.world, this, dt, wx, wz, this.stuckT > 1.0); this.speed = Math.hypot(this.vel.x, this.vel.z);
    const want = Math.hypot(wx, wz);
    if (want > 1 && this.speed < want * 0.35) { this.stuckT += dt; if (this.stuckT > 0.5 && this.stuckT < 1.0) this.sideT = 0.5; } else this.stuckT = Math.max(0, this.stuckT - dt * 2);
    if (this.stuckT > 3 && this.path.length) { this.stuckT = 0; this.needPath = true; if (this.state === 'loot') { this.fail(); } }
  }
  // ---- aiming and shooting ------------------------------------------------------------------------------------------
  faceDir(dx, dz, dt) { this.turnTo(Math.atan2(-dx, -dz), 0, dt, 9); }
  facePoint(p, dt) { this.facePointXZ(p.x, p.z, dt); }
  facePointXZ(x, z, dt) { this.turnTo(Math.atan2(-(x - this.pos.x), -(z - this.pos.z)), 0, dt, 8); }
  turnTo(yaw, pitch, dt, rate) { const d = angDiff(yaw, this.yaw), r = rate * dt; this.yaw += Math.max(-r, Math.min(r, d)); this.pitch += Math.max(-r, Math.min(r, pitch - this.pitch)); }
  aim(p, dt) {
    const e = this.eye, dx = p.x - e.x, dy = p.y - e.y, dz = p.z - e.z, h = Math.hypot(dx, dz);
    this.turnTo(Math.atan2(-dx, -dz), Math.atan2(dy, h), dt, this.diff.turn); this.aimErr = Math.abs(angDiff(Math.atan2(-dx, -dz), this.yaw)) + Math.abs(Math.atan2(dy, h) - this.pitch);
  }
  startReload() { const W = this.weapons; if (W.reloadT > 0 || W.w.type === 'melee') return; W.reloadT = W.w.reload; }
  tryFire(dt, aimPt) {
    const W = this.weapons, w = W.w, d = this.diff; if (this.reactT > 0 || W.reloadT > 0 || W.cd > 0 || this.aimErr > 0.11) return;
    if (w.type === 'melee') { if (Math.hypot(aimPt.x - this.pos.x, aimPt.z - this.pos.z) < 2) { W.cd = 60 / w.rpm; this.match.melee(this, this.enemy); } return; }
    if (W.mag <= 0) { return; }
    if (d.burst) { this.burstT -= dt; if (this.burstT < -0.6) this.burstT = 0.5; if (this.burstT <= 0) return; }                  // easy bots shoot in bursts
    W.mags[W.id]--; W.cd = 60 / w.rpm * (1 + (d.burst ? 0.3 : 0)); W.bloom = Math.min(1, W.bloom + w.bloom);
    const moving = this.speed > 1 ? 1.25 : 1, err = d.aim * moving * (1 + W.bloom) + w.spread * 0.4, o = this.eye.clone();
    const base = dirFrom(this.yaw + gauss() * err, this.pitch + gauss() * err);
    this.match.shoot(this, o, base, w);
  }
  // ---- plane / skydive / parachute (simple kinematics) ----------------------------------------------------------------
  updateDrop(dt) {
    const m = this.match, pl = m.plane, T = this.follow ? { x: this.follow.pos.x + this.offX, z: this.follow.pos.z + this.offZ } : this.target;
    if (this.air === 'plane') {
      if (!pl || pl.done || pl.t >= this.jumpAt) { this.startFall(); return; } this.pos.set(pl.pos.x, pl.pos.y, pl.pos.z); return;
    }
    const dx = T.x - this.pos.x, dz = T.z - this.pos.z, dist = Math.hypot(dx, dz) || 1, ground = this.world.heightAt(this.pos.x, this.pos.z), alt = this.pos.y - ground;
    if (this.air === 'fall') { const s = Math.min(28, dist * 1.5); this.pos.x += dx / dist * s * dt; this.pos.z += dz / dist * s * dt; this.pos.y -= 50 * dt; if (alt < 105) { this.air = 'chute'; this.canopy.visible = true; } }
    else { const s = Math.min(13, dist * 1.2); this.pos.x += dx / dist * s * dt; this.pos.z += dz / dist * s * dt; this.pos.y -= 6.5 * dt; }
    this.yaw = Math.atan2(-dx, -dz); this.root.position.copy(this.pos); this.yawG.rotation.y = this.yaw + Math.PI; this.tilt.rotation.x = this.air === 'fall' ? 1.35 : 0;
    this.setRendered(m.distToPlayer(this) < 320);
    const g = this.world.heightAt(this.pos.x, this.pos.z);
    if (this.pos.y <= g + 0.05) { this.pos.y = g; this.air = null; this.state = 'loot'; this.canopy.visible = false; this.vel.set(0, 0, 0); this.grounded = true; this.tilt.rotation.x = 0; unstick(this.world, this); this.thinkT = Math.random() * 0.8; }
  }
  startFall() { this.air = 'fall'; this.inPlane = false; this.root.position.copy(this.pos); }

  // ---- visuals ---------------------------------------------------------------------------------------------------------
  animate(dt, time) {
    if (!this.rendered) return; const P = this.char.parts, W = this.weapons;
    if (this.gunId !== W.id) {                                       // swap the gun model in the hand
      this.gunId = W.id; if (this.holder) { P.armR.remove(this.holder); this.holder = null; }
      if (W.id !== 'fist') { const h = new THREE.Group(), gun = buildGun(W.id); h.rotation.x = Math.PI / 2; h.position.set(0, -0.62, 0.02); h.add(gun); P.armR.add(h); this.holder = h; }
    }
    this.root.position.set(this.pos.x, this.pos.y, this.pos.z); this.yawG.rotation.y = this.yaw + Math.PI;
    const ty = this.stance === 'crouch' ? 0.72 : 1, tx = this.stance === 'prone' ? 1.38 : 0, k = Math.min(1, dt * 12);
    this.tilt.scale.y += (ty - this.tilt.scale.y) * k; this.tilt.rotation.x += (tx - this.tilt.rotation.x) * k; this.tilt.position.y += ((this.stance === 'prone' ? 0.32 : 0) - this.tilt.position.y) * k;
    this.walkPhase += this.speed * dt * 2.1; const amt = Math.min(1, this.speed / 4);
    if (this.speed > 0.3 && this.grounded) { const sw = Math.sin(this.walkPhase) * 0.9 * amt; P.legL.rotation.x = sw; P.legR.rotation.x = -sw; P.armL.rotation.x = -sw * 0.8; P.armR.rotation.x = sw * 0.8; P.armL.rotation.z = 0.12; P.armR.rotation.z = -0.12; }
    else { P.legL.rotation.x *= 0.8; P.legR.rotation.x *= 0.8; this.char.update(time); }
    if (W.id !== 'fist') { const low = this.state === 'zone' || this.state === 'flee' || this.state === 'loot'; P.armR.rotation.x = low ? -0.7 : -1.45; P.armR.rotation.z = -0.05; P.armL.rotation.x = low ? -0.7 : -1.3; P.armL.rotation.z = low ? 0.2 : 0.5; }
  }
}
