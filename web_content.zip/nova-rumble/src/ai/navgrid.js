// Grid A* for bots (5 m cells over the whole map). Pure logic, no three.js.
// Walls/trees/buildings block cells; river cells cost more (wading); deep sea is blocked. Buildings are sealed on purpose:
// bots enter them through explicit door/stair waypoints (see bot.js), not through the grid.
export class NavGrid {
  constructor(half = 500, cell = 5) {
    this.half = half; this.cell = cell; this.n = Math.ceil(2 * half / cell); const N = this.n * this.n;
    this.blocked = new Uint8Array(N); this.wet = new Uint8Array(N); this.g = new Float32Array(N); this.from = new Int32Array(N); this.seen = new Int32Array(N); this.closed = new Int32Array(N); this.sid = 0;
  }
  cx(x) { return Math.floor((x + this.half) / this.cell); }
  center(i) { return { x: (i % this.n + 0.5) * this.cell - this.half, z: (Math.floor(i / this.n) + 0.5) * this.cell - this.half }; }
  inGrid(ix, iz) { return ix >= 0 && iz >= 0 && ix < this.n && iz < this.n; }
  isFree(x, z) { const ix = this.cx(x), iz = this.cx(z); return this.inGrid(ix, iz) && !this.blocked[iz * this.n + ix]; }
  build(colliders, heightAt) {
    const n = this.n, c = this.cell;
    for (let iz = 0; iz < n; iz++) for (let ix = 0; ix < n; ix++) { const h = heightAt((ix + 0.5) * c - this.half, (iz + 0.5) * c - this.half), i = iz * n + ix; if (h < -1.4) this.blocked[i] = 1; else if (h < -0.2) this.wet[i] = 1; }
    for (const k of colliders) {
      const gh = heightAt((k.minX + k.maxX) / 2, (k.minZ + k.maxZ) / 2); if (k.maxY - gh < 1.2 || k.minY - gh > 1.0) continue;       // slabs/roofs do not block walking
      const x0 = Math.max(0, this.cx(k.minX - 0.6)), x1 = Math.min(n - 1, this.cx(k.maxX + 0.6)), z0 = Math.max(0, this.cx(k.minZ - 0.6)), z1 = Math.min(n - 1, this.cx(k.maxZ + 0.6));
      for (let iz = z0; iz <= z1; iz++) for (let ix = x0; ix <= x1; ix++) this.blocked[iz * n + ix] = 1;
    }
  }
  snap(ix, iz) {                                                  // nearest free cell index around (ix,iz) or -1
    const n = this.n; if (this.inGrid(ix, iz) && !this.blocked[iz * n + ix]) return iz * n + ix;
    for (let r = 1; r <= 5; r++) { let best = -1, bd = 1e9; for (let dz = -r; dz <= r; dz++) for (let dx = -r; dx <= r; dx++) { if (Math.max(Math.abs(dx), Math.abs(dz)) !== r) continue; const x = ix + dx, z = iz + dz; if (this.inGrid(x, z) && !this.blocked[z * n + x] && dx * dx + dz * dz < bd) { bd = dx * dx + dz * dz; best = z * n + x; } } if (best >= 0) return best; }
    return -1;
  }
  los(x0, z0, x1, z1) {                                           // straight walk possible? (samples every 1.5 m, 1 m to each side)
    const dx = x1 - x0, dz = z1 - z0, len = Math.hypot(dx, dz), steps = Math.ceil(len / 1.5); if (!len) return true; const px = -dz / len, pz = dx / len;
    for (let s = 0; s <= steps; s++) { const t = s / steps, x = x0 + dx * t, z = z0 + dz * t; if (!this.isFree(x, z) || !this.isFree(x + px, z + pz) || !this.isFree(x - px, z - pz)) return false; }
    return true;
  }
  // returns [{x,z}, ...] ending at the goal (or the nearest free cell centre if the goal is blocked), or null
  find(x0, z0, x1, z1, maxExp = 12000) {
    const n = this.n, s = this.snap(this.cx(x0), this.cx(z0)), g = this.snap(this.cx(x1), this.cx(z1)); if (s < 0 || g < 0) return null;
    const goalExact = !this.blocked[this.cx(z1) * n + this.cx(x1)] && this.inGrid(this.cx(x1), this.cx(z1)), gc = this.center(g);
    if (s === g) return [goalExact ? { x: x1, z: z1 } : gc];
    const id = ++this.sid, gx = g % n, gz = Math.floor(g / n), H = [], F = [];
    const push = (i, f) => { let k = H.length; H.push(i); F.push(f); while (k > 0) { const p = (k - 1) >> 1; if (F[p] <= F[k]) break; [H[p], H[k]] = [H[k], H[p]]; [F[p], F[k]] = [F[k], F[p]]; k = p; } };
    const pop = () => { const top = H[0], li = H.pop(), lf = F.pop(); if (H.length) { H[0] = li; F[0] = lf; let k = 0; for (;;) { let l = 2 * k + 1, r = l + 1, m = k; if (l < H.length && F[l] < F[m]) m = l; if (r < H.length && F[r] < F[m]) m = r; if (m === k) break; [H[m], H[k]] = [H[k], H[m]]; [F[m], F[k]] = [F[k], F[m]]; k = m; } } return top; };
    this.g[s] = 0; this.seen[s] = id; this.from[s] = -1; push(s, 0); let exp = 0, found = false;
    while (H.length && exp++ < maxExp) {
      const cur = pop(); if (this.closed[cur] === id) continue; this.closed[cur] = id; if (cur === g) { found = true; break; }
      const cx = cur % n, cz = (cur / n) | 0;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dz) continue; const x = cx + dx, z = cz + dz; if (x < 0 || z < 0 || x >= n || z >= n) continue; const ni = z * n + x; if (this.blocked[ni] || this.closed[ni] === id) continue;
        if (dx && dz && (this.blocked[cz * n + x] || this.blocked[z * n + cx])) continue;                  // no cutting corners
        const ng = this.g[cur] + (dx && dz ? 1.414 : 1) * (this.wet[ni] ? 3 : 1);
        if (this.seen[ni] !== id || ng < this.g[ni]) { this.seen[ni] = id; this.g[ni] = ng; this.from[ni] = cur; const ex = Math.abs(x - gx), ez = Math.abs(z - gz); push(ni, ng + (ex + ez) + (1.414 - 2) * Math.min(ex, ez)); }
      }
    }
    if (!found) return null;
    const cells = []; for (let i = g; i >= 0; i = this.from[i]) cells.push(this.center(i)); cells.reverse(); cells[0] = { x: x0, z: z0 };
    if (goalExact) cells[cells.length - 1] = { x: x1, z: z1 };
    const out = []; let i = 0;                                                                                // string pulling: skip waypoints that can be walked past
    while (i < cells.length - 1) { let j = cells.length - 1; while (j > i + 1 && !this.los(cells[i].x, cells[i].z, cells[j].x, cells[j].z)) j--; out.push(cells[j]); i = j; }
    return out;
  }
}
