// localStorage save system: coins, owned characters, settings, rank, stats.
import { DEFAULT_SAVE } from '../data/config.js';
const KEY = 'nova_rumble_save_v1';
const clone = (o) => JSON.parse(JSON.stringify(o));
const newId = () => String(Math.floor(1e9 + Math.random() * 9e9));
function merge(base, extra) {            // deep merge so new fields survive old saves
  for (const k in extra) {
    if (extra[k] && typeof extra[k] === 'object' && !Array.isArray(extra[k])) base[k] = merge(base[k] || {}, extra[k]);
    else base[k] = extra[k];
  }
  return base;
}
function load() {
  let d = clone(DEFAULT_SAVE);
  try { const raw = localStorage.getItem(KEY); if (raw) d = merge(d, JSON.parse(raw)); } catch (e) { console.warn('save load failed', e); }
  if (!d.id) d.id = newId();
  return d;
}
export const store = {
  data: load(),
  save() { try { localStorage.setItem(KEY, JSON.stringify(this.data)); } catch (e) {} },
  reset() { this.data = clone(DEFAULT_SAVE); this.data.id = newId(); this.save(); }
};
