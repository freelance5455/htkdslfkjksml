// Unified input: keyboard + mouse (PC) and values written by the touch HUD (mobile).
// Game code only reads this object, never raw events.
export class Input {
  constructor() {
    this.stick = { x: 0, y: 0 };      // movement, -1..1 (y>0 = forward)
    this.look = { x: 0, y: 0 };       // accumulated look delta in pixels since last frame
    this.fire = false; this.fireTouch = false; this.fireKey = false;
    this.sprintHeld = false; this.sprintToggle = false;   // touch sprint button toggles; Shift holds
    this.jumpHeld = false;
    this.aimPx = 0;                    // FIRE-drag headshot lift in pixels (0..80)
    this.pressed = new Set();         // one-shot actions: jump crouch prone reload swap scope medkit grenade gloo backpack
    this.keys = new Set(); this.locked = false;
    this.enabled = true;
    this._bind();
  }
  press(a) { if (this.enabled) this.pressed.add(a); }
  consume(a) { return this.pressed.delete(a); }
  // Drag on the FIRE button: sideways = camera yaw. Upward drag first raises the crosshair toward head height
  // (80 px = full lift = ~0.45 m); drag beyond that (or downward past zero) turns into normal camera pitch.
  addFireDrag(dx, dy) {
    this.look.x += dx; let a = this.aimPx - dy, over = 0;
    if (a > 80) { over = a - 80; a = 80; } else if (a < 0) { over = a; a = 0; }
    this.aimPx = a; this.look.y -= over;
  }
  addLook(dx, dy) { this.look.x += dx; this.look.y += dy; }
  takeLook() { const l = { x: this.look.x, y: this.look.y }; this.look.x = this.look.y = 0; return l; }
  clearAll() { this.stick.x = this.stick.y = 0; this.fireTouch = this.fireKey = this.fire = false; this.jumpHeld = false; this.keys.clear(); this.pressed.clear(); this.look.x = this.look.y = 0; }

  // Combined movement vector (touch stick + WASD)
  getMove() {
    let x = this.stick.x, y = this.stick.y; const k = this.keys;
    if (k.has('KeyW')) y += 1; if (k.has('KeyS')) y -= 1; if (k.has('KeyD')) x += 1; if (k.has('KeyA')) x -= 1;
    const m = Math.hypot(x, y); if (m > 1) { x /= m; y /= m; } return { x, y };
  }
  _bind() {
    const map = { Space: 'jump', KeyC: 'crouch', KeyZ: 'prone', KeyR: 'reload', KeyQ: 'swap', KeyG: 'grenade', KeyV: 'gloo', KeyB: 'backpack', KeyE: 'interact', KeyM: 'map', KeyL: 'debugZone', Digit1: 'medkit', KeyT: 'scope', KeyJ: 'debugHurt', KeyK: 'debugKill', Escape: 'pause' };
    window.addEventListener('keydown', e => {
      if (!this.enabled || e.repeat) return; this.keys.add(e.code);
      if (map[e.code]) { this.press(map[e.code]); if (e.code === 'Space') this.jumpHeld = true; e.preventDefault(); }
      if (e.code === 'ShiftLeft') this.sprintHeld = true;
    });
    window.addEventListener('keyup', e => {
      this.keys.delete(e.code); if (e.code === 'Space') this.jumpHeld = false; if (e.code === 'ShiftLeft') this.sprintHeld = false;
    });
    // PC mouse: click the game to lock the pointer; mouse = look, left = fire, right = scope
    document.addEventListener('pointerlockchange', () => { this.locked = !!document.pointerLockElement; if (!this.locked) this.fireKey = false; });
    document.addEventListener('mousemove', e => { if (this.locked && this.enabled) this.addLook(e.movementX, e.movementY); });
    document.addEventListener('mousedown', e => { if (!this.locked || !this.enabled) return; if (e.button === 0) this.fireKey = true; if (e.button === 2) this.press('scope'); });
    document.addEventListener('mouseup', e => { if (e.button === 0) this.fireKey = false; });
    document.addEventListener('contextmenu', e => { if (this.locked) e.preventDefault(); });
    window.addEventListener('blur', () => this.clearAll());
  }
  update() { this.fire = this.fireTouch || this.fireKey || (this.keys.has('KeyF')); }
}
