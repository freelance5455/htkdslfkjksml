// Ranked ladder: Bronze..Grandmaster, 3 sub-tiers each (III -> II -> I), 100 points per step.
import { RANK_TIERS } from '../data/config.js';
const ROMAN = ['', 'I', 'II', 'III'];
export const rankLabel = r => RANK_TIERS[r.tier].toUpperCase() + ' ' + ROMAN[r.sub];
export function applyRank(rank, delta) {
  const old = { ...rank }, max = RANK_TIERS.length * 300 - 1; let total = rank.tier * 300 + (3 - rank.sub) * 100 + rank.points + delta; total = Math.max(0, Math.min(max, total));
  const tier = Math.floor(total / 300), rem = total % 300; return { old, now: { tier, sub: 3 - Math.floor(rem / 100), points: rem % 100 }, delta: total - (old.tier * 300 + (3 - old.sub) * 100 + old.points) };
}
