// Entry point: Login -> Loading -> Lobby
import './style.css';
import { store } from './core/store.js';
import { audio } from './audio/audio.js';
import { getCharacter } from './data/characters.js';
import { LobbyScene } from './game/lobbyScene.js';
import { showLogin } from './ui/login.js';
import { showLoading } from './ui/loading.js';
import { showLobby } from './ui/lobby.js';
import { GameScene } from './game/gameScene.js';
import { resolveMode } from './data/modes.js';

const ui = document.getElementById('ui');
let lobby3d = null, game = null;

function toLobby() {
  if (!lobby3d) lobby3d = new LobbyScene(document.getElementById('bg3d'));
  lobby3d.setCharacter(getCharacter(store.data.selected));
  lobby3d.start();
  audio.init(); audio.startMusic();
  showLobby(ui, lobby3d, toLogin, toMatch);
}
// Battle Royale modes load the big map; everything else opens the Training Ground for now
function toMatch() {
  lobby3d.stop(); document.getElementById('bg3d').style.display = 'none'; audio.stopMusic();
  if (!game) game = new GameScene(document.getElementById('game3d'));
  const cfg = resolveMode(store.data.mode, store.data.custom);                      // br | team (CS Rank, Lone Wolf, TDM, Custom) | training
  game.start(ui, getCharacter(store.data.selected), () => { game.stop(); toLobby(); }, cfg.kind, cfg.kind === 'team' ? cfg : null);
}
function toLoading() { if (lobby3d) lobby3d.stop(); showLoading(ui, toLobby); }
function toLogin() { if (lobby3d) lobby3d.stop(); document.getElementById('bg3d').style.display = 'none'; showLogin(ui, toLoading); }

// A returning logged-in player still needs one tap so the browser allows audio
if (store.data.loggedIn) {
  ui.innerHTML = '<div class="screen login"><div class="logo">NOVA<span>RUMBLE</span></div><button class="btn start" id="tap">TAP TO PLAY</button></div>';
  document.getElementById('tap').onclick = () => { audio.init(); audio.click(); toLoading(); };
} else toLogin();
