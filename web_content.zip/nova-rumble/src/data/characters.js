// Character definitions. Phase 1 ships 4; Phase 7 expands this to 20.
// hair.style: 'spike' | 'bob' | 'cap' | 'bun' | 'mohawk'
export const CHARACTERS = [
  { id:'rookie', name:'Pip',   price:0,    passive:'None (starter)',   skin:0xffc9a0, hair:{style:'spike', color:0xffd23f}, top:0x8a3ffc, bottom:0x2b2d6e, shoes:0xff9f1c, accent:0x22d3ee, width:1.0 },
  { id:'blaze',  name:'Blaze', price:2500, passive:'+5% sprint speed', skin:0xe0a070, hair:{style:'mohawk',color:0xff4d2e}, top:0xff7a1a, bottom:0x222222, shoes:0xffffff, accent:0xffd23f, width:1.1 },
  { id:'luna',   name:'Luna',  price:4000, passive:'Heal 8% faster',   skin:0xf6d3c0, hair:{style:'bun',   color:0x6a2cff}, top:0x22d3ee, bottom:0x5b21b6, shoes:0xffd23f, accent:0xff6bd6, width:0.9 },
  { id:'bolt',   name:'Bolt',  price:6000, passive:'Reload 6% faster', skin:0x8d5a3b, hair:{style:'cap',   color:0xffd23f}, top:0x15c5a5, bottom:0x1a1a3a, shoes:0xff4d2e, accent:0xffffff, width:1.05 }
];
export const getCharacter = (id) => CHARACTERS.find(c => c.id === id) || CHARACTERS[0];
