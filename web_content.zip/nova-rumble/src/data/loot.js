// Loot tables (pure data + dice). Rarity: 0 white, 1 green, 2 blue, 3 purple, 4 gold (airdrop only).
export const RARITY_COLORS = [0xffffff, 0x4ade80, 0x38bdf8, 0xa855f7, 0xffc933];
const ammo = t => ({ kind: 'ammo', id: t });
export const BY_RARITY = [
  [ammo('AR'), ammo('SMG'), ammo('PST'), ammo('SHT'), ammo('SNP'), { kind: 'weapon', id: 'pistol' }, { kind: 'gloo' }, ammo('AR'), ammo('SMG')],
  [{ kind: 'weapon', id: 'smg' }, { kind: 'weapon', id: 'shotgun' }, { kind: 'armor', level: 1 }, { kind: 'helmet', level: 1 }, { kind: 'medkit' }, { kind: 'backpack', level: 1 }, { kind: 'medkit' }],
  [{ kind: 'weapon', id: 'ar' }, { kind: 'armor', level: 2 }, { kind: 'helmet', level: 2 }, { kind: 'grenade' }, { kind: 'backpack', level: 2 }, { kind: 'weapon', id: 'ar' }],
  [{ kind: 'weapon', id: 'sniper' }, { kind: 'armor', level: 3 }, { kind: 'helmet', level: 3 }, { kind: 'backpack', level: 3 }]
];
export const TIERS = { low: [60, 30, 9, 1], normal: [50, 32, 14, 4], hot: [28, 34, 27, 11] };   // weights per rarity
export function rarityOf(it) {
  if (it.kind === 'weapon') return { pistol: 0, smg: 1, shotgun: 1, ar: 2, sniper: 3 }[it.id];
  if (it.kind === 'armor' || it.kind === 'helmet' || it.kind === 'backpack') return it.level;
  if (it.kind === 'medkit') return 1; if (it.kind === 'grenade') return 2; return 0;
}
export function roll(rng, tier = 'normal', minRarity = 0) {
  const w = TIERS[tier]; let tot = 0; for (let i = minRarity; i < 4; i++) tot += w[i];
  let r = rng() * tot, k = minRarity; for (; k < 3; k++) { if (r < w[k]) break; r -= w[k]; }
  const list = BY_RARITY[k]; return { ...list[Math.floor(rng() * list.length)] };
}
// Airdrop crate: always strong
export function airdropLoot(rng) {
  const ar = BY_RARITY[0][0].id;
  return [{ kind: 'weapon', id: rng() < 0.5 ? 'sniper' : 'ar' }, { kind: 'armor', level: 3 }, { kind: 'helmet', level: 3 }, { kind: 'medkit' }, { kind: 'medkit' }, { kind: 'grenade' }, { kind: 'ammo', id: 'AR' }, { kind: 'ammo', id: 'SNP' }];
}
export const CAPS = { medkit: [2, 4, 6, 9], grenade: [2, 3, 4, 6], gloo: [2, 4, 6, 8] };   // carry limit by backpack level 0-3
