// ===== Bermuda-style big map data (original names). All numbers are metres; x = east, z = south, map is 1000 x 1000 centred on 0,0. =====
export const MAP = { seed: 7, half: 500, riverW: 26, seaZ: 445, waterY: -0.35 };

// Locations: flat building areas (r = flattened radius). `type` picks the generator in bigWorld.js.
export const LOCATIONS = [
  { id: 'maple',  name: 'Maplebrook',        x: 150,  z: -60,  r: 75, type: 'town' },
  { id: 'gear',   name: 'Gearhaven Factory', x: -250, z: -200, r: 85, type: 'factory' },
  { id: 'volt',   name: 'Voltpoint Power',   x: 260,  z: -300, r: 75, type: 'power' },
  { id: 'sunny',  name: 'Sunny Acres Farm',  x: -260, z: 150,  r: 95, type: 'farm' },
  { id: 'harbor', name: 'Rustwood Harbour',  x: 60,   z: 410,  r: 90, type: 'harbor' },
  { id: 'pine',   name: 'Pinecrest',         x: -80,  z: -330, r: 65, type: 'village' },
  { id: 'sky',    name: 'Skyline Heights',   x: 330,  z: 130,  r: 65, type: 'hill' },
  { id: 'market', name: 'Crossroads Market', x: 40,   z: 120,  r: 50, type: 'market' }
];
// Gaussian hills: x, z, radius, height
export const HILLS = [[330, 130, 110, 15], [-150, -60, 90, 8], [-380, -340, 120, 12], [420, -120, 100, 9], [200, 300, 80, 7], [-420, 60, 90, 8]];
// Wheat fields: x, z, width, depth
export const FIELDS = [[-330, 60, 110, 80], [-190, 230, 110, 70], [-350, 210, 80, 90], [-200, 70, 70, 60], [250, 215, 100, 80], [100, -200, 90, 70]];
export const ROAD_LINKS = [['maple', 'market'], ['market', 'harbor'], ['market', 'sky'], ['maple', 'volt'], ['maple', 'pine'], ['pine', 'gear'], ['gear', 'sunny'], ['sunny', 'market']];

// Safe zone: 7 phases. appear = seconds before the next circle is shown, hold = seconds it is shown before shrinking,
// shrink = seconds the circle takes to close, r = radius of the NEXT circle, dmg = storm damage per second outside.
export const ZONE = {
  startRadius: 720,
  phases: [
    { appear: 60, hold: 40, shrink: 60, r: 400, dmg: 1 }, { appear: 40, hold: 40, shrink: 45, r: 270, dmg: 2 },
    { appear: 30, hold: 35, shrink: 40, r: 170, dmg: 4 }, { appear: 25, hold: 30, shrink: 35, r: 100, dmg: 6 },
    { appear: 20, hold: 25, shrink: 30, r: 55, dmg: 9 },  { appear: 15, hold: 20, shrink: 25, r: 25, dmg: 14 },
    { appear: 10, hold: 15, shrink: 20, r: 8, dmg: 22 }
  ]
};
export const AIRDROP = { first: 95, every: 110, count: 5 };         // seconds after the match starts
export const PLANE = { speed: 48, alt: 230 };
