// ===== Global game data (tweak freely) =====
export const GAME = { name: 'NOVA RUMBLE', version: 'v0.6.0 (Phase 6)' };

export const TIPS = [
  'Drag up while holding FIRE to lift your crosshair to head height.',
  'Land away from the plane line for a calmer start.',
  'Helmets reduce headshot damage. Loot one early!',
  'Gloo walls give instant cover. Use them while healing.',
  'Stay inside the safe zone. The purple storm hurts!',
  'Listen for footsteps. Crouching makes you quieter.',
  'Airdrops carry the best loot, but everyone will come for them.'
];

// All modes are free. "phase" = the build phase that makes them playable.
export const MODES = [
  { id: 'br_solo',  name: 'Battle Royale - Solo',  icon: '🪂', desc: '50 players. Last one standing wins.', phase: 5 },
  { id: 'br_duo',   name: 'Battle Royale - Duo',   icon: '👫', desc: 'Team of 2 with a bot teammate.',        phase: 5 },
  { id: 'br_squad', name: 'Battle Royale - Squad', icon: '👥', desc: 'Team of 4 with bot teammates.',        phase: 5 },
  { id: 'bermuda',  name: 'Bermuda',               icon: '🏝️', desc: 'The large classic map.',               phase: 5 },
  { id: 'cs_rank',  name: 'CS Rank 4v4',           icon: '🏅', desc: 'Buy rounds. First to 4 wins. Ranked.', phase: 6 },
  { id: 'cs_rank2', name: 'CS Rank 2v2',           icon: '🥈', desc: 'Small-team buy rounds. Ranked.',       phase: 6 },
  { id: 'lone_wolf',  name: 'Lone Wolf 1v1',       icon: '🐺', desc: 'Duel with gloo walls. First to 3.',    phase: 6 },
  { id: 'lone_wolf2', name: 'Lone Wolf 2v2',       icon: '🐾', desc: '2v2 duels on a small arena.',          phase: 6 },
  { id: 'tdm',      name: 'Team Deathmatch',       icon: '⚔️', desc: 'First team to 40 kills. Respawns.',    phase: 6 },
  { id: 'custom',   name: 'Custom Room',           icon: '🛠️', desc: 'Any team size 1v1 to 8v8, rules, map.', phase: 6 },
  { id: 'training', name: 'Training Ground',       icon: '🎯', desc: 'Practise aiming on dummies.',           phase: 3 }
];

export const RANK_TIERS = ['Bronze','Silver','Gold','Platinum','Diamond','Heroic','Grandmaster'];

export const DEFAULT_SAVE = {
  loggedIn: false, name: 'Player', id: '', level: 1, xp: 0,
  coins: 1500, gems: 50,
  rank: { tier: 0, sub: 3, points: 0 },       // Bronze III
  owned: ['rookie'], selected: 'rookie', mode: 'br_solo', custom: { type: 'cs', a: 4, b: 4, map: 'yard', weapons: 'any', difficulty: 'normal', rounds: 4, killTarget: 40, roundTime: 100, money: 800, gloo: true },
  settings: { graphics: 'medium', master: 0.8, music: 0.5, sfx: 0.8, autoFire: false, autoPickup: false, botDifficulty: 'normal', assist: 0.25, sens: { camera: 1, aim: 1, scope: 0.6 } },
  stats: { matches: 0, wins: 0, kills: 0, deaths: 0, headshots: 0, shots: 0 }
};

// Movement + camera tuning (metres, seconds). Tweak here.
export const MOVE = {
  walk: 4.6, sprint: 7.4, crouch: 2.6, prone: 1.3,
  gravity: 22, jump: 7.8, radius: 0.35,
  height: { stand: 1.9, crouch: 1.3, prone: 0.6 },     // collision height per stance
  pivot:  { stand: 1.65, crouch: 1.2, prone: 0.7 },    // camera look-at height per stance
  stepWalk: 0.5,      // auto step-up while walking (stairs, kerbs)
  climbMax: 1.3,      // obstacles up to this height can be climbed by pressing JUMP into them
  fallSafe: 14,       // landing speed (m/s) below this is harmless (~9 m fall)
  fallDmg: 7,         // damage per m/s above the safe speed
  maxHp: 200
};
export const CAM = { fov: 65, dist: 4.2, scopedDist: 1.6, shoulder: 0.55, pitchMin: -0.85, pitchMax: 1.15, lookSpeed: 0.0042 };
export const SCOPES = [ { name: 'OFF', zoom: 1 }, { name: 'RED DOT', zoom: 1.25 }, { name: '2x', zoom: 2 }, { name: '4x', zoom: 4 }, { name: '8x', zoom: 8 } ];
