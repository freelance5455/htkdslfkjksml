// ===== Team modes: CS Rank (Clash Squad), Lone Wolf, Team Deathmatch, Custom Room =====
export const SHOP = {
  weapons: { pistol: 150, smg: 500, shotgun: 600, ar: 900, sniper: 1100 },
  armor: [0, 200, 400, 700], helmet: [0, 150, 300, 500], medkit: 200, grenade: 250, gloo: 150, ammo: 100
};
export const WEAPON_RULES = { any: ['pistol', 'smg', 'shotgun', 'ar', 'sniper'], pistols: ['pistol'], smgs: ['smg'], shotguns: ['shotgun'], snipers: ['sniper'], fists: [] };
export const WEAPON_RULE_LABELS = { any: 'All weapons', pistols: 'Pistols only', smgs: 'SMGs only', shotguns: 'Shotguns only', snipers: 'Snipers only', fists: 'Fists only' };
export const TYPE_LABELS = { cs: 'Clash Squad (buy rounds)', wolf: 'Lone Wolf (duel rounds, gloo walls)', tdm: 'Team Deathmatch' };
export const ECONOMY = { win: 1000, lose: 700, kill: 200, cap: 9000, buyTime: 20 };

const BASE = { map: 'yard', weapons: 'any', gloo: true, rounds: 4, roundTime: 100, money: 800, killTarget: 40, timeLimit: 420, respawn: 4, ranked: false };
export const MODE_CFG = {
  cs_rank:    { ...BASE, type: 'cs', a: 4, b: 4, ranked: true, label: 'CS Rank 4v4' },
  cs_rank2:   { ...BASE, type: 'cs', a: 2, b: 2, ranked: true, label: 'CS Rank 2v2' },
  lone_wolf:  { ...BASE, type: 'wolf', a: 1, b: 1, rounds: 3, roundTime: 75, map: 'wolf', label: 'Lone Wolf 1v1' },
  lone_wolf2: { ...BASE, type: 'wolf', a: 2, b: 2, rounds: 3, roundTime: 75, map: 'wolf', label: 'Lone Wolf 2v2' },
  tdm:        { ...BASE, type: 'tdm', a: 4, b: 4, label: 'Team Deathmatch 4v4' }
};
export const CUSTOM_DEFAULT = { type: 'cs', a: 4, b: 4, map: 'yard', weapons: 'any', difficulty: 'normal', rounds: 4, killTarget: 40, roundTime: 100, money: 800, gloo: true };
export const CUSTOM_PRESETS = [[1, 1], [2, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [8, 8]];

// what kind of match does this lobby mode start?  -> { kind: 'br' | 'training' | 'team', ... }
export function resolveMode(id, custom) {
  if (['br_solo', 'br_duo', 'br_squad', 'bermuda'].includes(id)) return { kind: 'br' };
  if (MODE_CFG[id]) return { kind: 'team', ...MODE_CFG[id] };
  if (id === 'custom') { const c = { ...CUSTOM_DEFAULT, ...(custom || {}) }; return { kind: 'team', ...BASE, ...c, ranked: false, label: `Custom ${c.a}v${c.b}` }; }
  return { kind: 'training' };
}
