// ===== Weapon + armour data (tweak freely) =====
// damage = per bullet/pellet, rpm = rounds per minute, range = metres (damage falls to `falloff` x at max range)
// spread = base cone half-angle (rad), moveSpread = extra while moving, bloom = spread growth per shot
// recoil.v = camera kick up per shot (rad), recoil.h = sideways kick, recoil.pat = left/right pattern (cycles)
export const AMMO_TYPES = ['AR', 'SMG', 'SNP', 'SHT', 'PST'];
export const WEAPONS = {
  fist:    { id: 'fist', name: 'Fist', type: 'melee', damage: 14, rpm: 150, range: 1.9, mag: 0, ammo: null, reload: 0, spread: 0, moveSpread: 0, bloom: 0, falloff: 1, pellets: 1, recoil: { v: 0, h: 0, pat: [0] }, color: 0xffc9a0 },
  pistol:  { id: 'pistol', name: 'Pop-9', type: 'pistol', damage: 20, rpm: 380, range: 45, mag: 12, ammo: 'PST', reload: 1.4, spread: 0.010, moveSpread: 0.020, bloom: 0.10, falloff: 0.6, pellets: 1, recoil: { v: 0.013, h: 0.004, pat: [0, .5, -.5, .3] }, color: 0x22d3ee },
  smg:     { id: 'smg', name: 'Rattle-X', type: 'smg', damage: 16, rpm: 800, range: 45, mag: 30, ammo: 'SMG', reload: 1.9, spread: 0.016, moveSpread: 0.020, bloom: 0.05, falloff: 0.55, pellets: 1, recoil: { v: 0.0055, h: 0.003, pat: [0, .6, -.4, .8, -.7, .3, -.5, .5] }, color: 0xffd23f },
  ar:      { id: 'ar', name: 'Striker-R', type: 'ar', damage: 23, rpm: 600, range: 85, mag: 30, ammo: 'AR', reload: 2.2, spread: 0.012, moveSpread: 0.024, bloom: 0.06, falloff: 0.6, pellets: 1, recoil: { v: 0.0070, h: 0.0028, pat: [0, .4, -.3, .6, -.5, .2, -.6, .3] }, color: 0x8a3ffc },
  shotgun: { id: 'shotgun', name: 'Boomer-12', type: 'shotgun', damage: 9, rpm: 72, range: 28, mag: 6, ammo: 'SHT', reload: 2.6, spread: 0.055, moveSpread: 0.03, bloom: 0, falloff: 0.25, pellets: 8, recoil: { v: 0.05, h: 0.01, pat: [0, .5, -.5] }, color: 0xff8a1f },
  sniper:  { id: 'sniper', name: 'Longshot', type: 'sniper', damage: 78, rpm: 46, range: 220, mag: 5, ammo: 'SNP', reload: 3.0, spread: 0.002, moveSpread: 0.03, bloom: 0, falloff: 0.9, pellets: 1, hip: 4, recoil: { v: 0.055, h: 0.006, pat: [0, .5, -.5] }, color: 0xff6bd6 }
};
export const AMMO_PICKUP = { AR: 60, SMG: 90, SNP: 10, SHT: 12, PST: 36 };
export const HEAD_MULT = 2.0, TORSO_MULT = 1.0, LIMB_MULT = 0.75;
export const HELMET_REDUCE = [0, 0.25, 0.40, 0.55];   // headshot damage reduction by helmet level 0-3
export const ARMOR_REDUCE  = [0, 0.15, 0.25, 0.35];   // body damage reduction by armour level 0-3
export const LEVEL_COLORS = [0xffffff, 0x4ade80, 0x38bdf8, 0xa855f7];
