// ===== Bot tuning (all numbers in one place) =====
// react = seconds before a newly spotted enemy gets shot at, aim = random aim error (radians, per shot),
// head = chance the bot aims for the head, turn = max turn speed (rad/s), cover/grenade = how often it uses them (0..1),
// think = seconds between decisions, burst = fires in short bursts (Easy)
export const DIFFICULTY = {
  easy:   { react: 0.90, aim: 0.055, head: 0.04, turn: 3.2,  cover: 0.0, grenade: 0.0,  think: 0.35, burst: true,  gloo: 0 },
  normal: { react: 0.60, aim: 0.030, head: 0.12, turn: 4.6,  cover: 0.3, grenade: 0.10, think: 0.25, burst: false, gloo: 0 },
  hard:   { react: 0.40, aim: 0.018, head: 0.22, turn: 7.0,  cover: 0.7, grenade: 0.30, think: 0.20, burst: false, gloo: 0.4 },
  pro:    { react: 0.25, aim: 0.010, head: 0.35, turn: 10.0, cover: 1.0, grenade: 0.50, think: 0.15, burst: false, gloo: 0.8 }
};
export const DIFFICULTY_LABELS = { easy: 'Easy', normal: 'Normal', hard: 'Hard', pro: 'Pro' };
export const SIGHT = { fov: Math.PI / 2, close: 7, maxRange: 120 };      // 90 degree view cone, 7 m "I feel someone behind me" radius
export const WEAPON_RANK = { fist: 0, pistol: 1, shotgun: 2, sniper: 3, smg: 3.2, ar: 4 };      // which gun a bot prefers
export const NOISE_RADIUS = { pistol: 60, smg: 70, ar: 90, shotgun: 80, sniper: 130, fist: 8 };
const A = ['Sparky', 'Pixel', 'Waffles', 'Turbo', 'Mochi', 'Zippy', 'Biscuit', 'Nacho', 'Pickles', 'Bubbles', 'Rocket', 'Noodle', 'Ziggy', 'Pancake', 'Gizmo', 'Fuzzy', 'Jelly', 'Comet', 'Doodle', 'Peanut', 'Cosmo', 'Taco', 'Blobby', 'Muffin', 'Rumble'];
const B = ['Fox', 'Panda', 'Ninja', 'Robo', 'Wizard', 'Tiger', 'Yeti', 'Pirate', 'Cactus', 'Ghost', 'Knight', 'Otter', 'Dino', 'Bandit', 'Racer', 'Rider', 'Gnome', 'Viking', 'Shark', 'Hero'];
export function botName(rng, used) {                                     // unique cartoon names like "TurboOtter42"
  for (let i = 0; i < 30; i++) { const n = A[Math.floor(rng() * A.length)] + B[Math.floor(rng() * B.length)] + (rng() < 0.5 ? Math.floor(rng() * 99) : ''); if (!used.has(n)) { used.add(n); return n; } }
  return 'Bot' + used.size;
}
