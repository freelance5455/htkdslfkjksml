// In-match HUD (DOM + two small canvases). Touch controls write into the shared Input object.
import { MOVE, SCOPES } from '../data/config.js';
import { audio } from '../audio/audio.js';
import { openModal } from './modal.js';
import { store } from '../core/store.js';
import { CAPS } from '../data/loot.js';

const AMMO = [['AR', 90], ['SMG', 120], ['SNP', 20], ['SHT', 16], ['PST', 48]];
export class Hud {
  constructor(root, input, world, onLeave) {
    this.root = root; this.input = input; this.world = world; this.onLeave = onLeave; this.marker = null; this.fps = 60; this.alive = 50; this.kills = 0;
    root.innerHTML = `
    <div class="hud">
      <div class="look" id="look"></div>
      <div class="mini"><canvas id="mm" width="260" height="260"></canvas></div>
      <div class="netinfo">📶 <span id="hping">32</span> ms · <span id="hfps">60</span> FPS</div>
      <div class="minibtns"><button class="hb sm" id="bMarker">📍</button><button class="hb sm" id="bChat">💬</button><button class="hb sm" id="bMap">🗺</button><button class="hb sm" id="bBuy" style="display:none">🛒</button></div>
      <div class="compass"><canvas id="cp" width="640" height="56"></canvas><div class="zmsg" id="zmsg"></div></div>
      <div class="counts"><span>👥 <b id="alive">50</b></span><span>☠ <b id="kills">0</b></span><button class="hb sm" id="bGear">⚙️</button></div>
      <div class="wslots"><div class="ws" id="ws0">🔫<small>-</small></div><div class="ws" id="ws1">🔫<small>-</small></div><div class="ws" id="ws2">✊<small>FIST</small></div>
        <div class="ammo"><b id="ammoTxt">-- / --</b><button class="hb sm" id="bReload">⟳</button></div></div>
      <div class="ammoinv">${AMMO.map(a => `<div class="chip"><small>${a[0]}</small><b>${a[1]}</b></div>`).join('')}</div>
      <div class="killfeed" id="kf"></div>
      <div class="cross" id="cross"></div>
      <div class="hdir" id="hdir"><i></i></div><div class="dropmsg" id="dropmsg"></div><div class="banner" id="banner"></div><div class="storm" id="storm"><span>You are in the storm! Move to the safe zone</span></div>
      <div class="bigmap" id="bigmap"><canvas id="bm"></canvas><button class="btn x" id="bmx">✕</button></div>
      <div class="hitmark" id="hit"></div>
      <button class="hb pick" id="bPick"></button>
      <div class="hint" id="hint">Your HP has decreased. Use a recovery item!</div>
      <div class="streak" id="streak"></div>
      <div class="dmgflash" id="flash"></div>
      <div class="heal" id="heal"><i></i><span>Using medkit...</span></div>
      <div class="hpwrap"><div class="gear">🛡<small id="arm">0</small></div><div class="gear">⛑<small id="hel">0</small></div>
        <div class="hpbar"><i id="hpfill"></i><b id="hptxt">200/200</b></div></div>
      <div class="joy" id="joy"><i id="knob"></i></div>
      <button class="hb round sprint" id="bSprint">SPRINT</button>
      <button class="hb round gloo" id="bGloo">🧊<small id="cGloo">4</small></button>
      <button class="hb round bag" id="bBag">🎒</button>
      <button class="hb round med" id="bMed">➕<small id="cMed">3</small></button>
      <button class="hb round gren" id="bGren">💣<small id="cGren">3</small></button>
      <button class="hb round fire" id="bFire">FIRE</button>
      <button class="hb round scope" id="bScope">🎯<small id="scopeTxt">OFF</small></button>
      <button class="hb round jump" id="bJump">⤒</button>
      <button class="hb round crouch" id="bCrouch">⤓</button>
      <button class="hb round prone" id="bProne">▁</button>
      <button class="hb round swap" id="bSwap">⇄</button>
    </div>`;
    const $ = id => root.querySelector('#' + id); this.$ = $;
    this.mm = $('mm').getContext('2d'); this.cp = $('cp').getContext('2d');
    this._bindTouch(); this._bindButtons();
    this.pingT = setInterval(() => { const p = $('hping'); if (p) { p.textContent = 28 + Math.floor(Math.random() * 20); $('hfps').textContent = Math.round(this.fps); } }, 1000);
  }
  destroy() { clearInterval(this.pingT); this.root.innerHTML = ''; }

  // ---- touch wiring -----------------------------------------------------------
  _bindTouch() {
    const inp = this.input, $ = this.$;
    // 1) camera drag anywhere on the free screen area (pointer lock on PC)
    const look = $('look'); let lp = null, lx = 0, ly = 0;
    look.style.touchAction = 'none';
    look.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse') { look.requestPointerLock?.(); return; }
      lp = e.pointerId; lx = e.clientX; ly = e.clientY; look.setPointerCapture(lp);
    });
    look.addEventListener('pointermove', e => { if (e.pointerId === lp) { inp.addLook(e.clientX - lx, e.clientY - ly); lx = e.clientX; ly = e.clientY; } });
    const end = e => { if (e.pointerId === lp) lp = null; }; look.addEventListener('pointerup', end); look.addEventListener('pointercancel', end);

    // 2) floating-style joystick (fixed base, 55 px travel)
    const joy = $('joy'), knob = $('knob'); let jp = null;
    const setStick = e => {
      const r = joy.getBoundingClientRect(), cx = r.left + r.width / 2, cy = r.top + r.height / 2, R = r.width / 2;
      let dx = e.clientX - cx, dy = e.clientY - cy; const m = Math.hypot(dx, dy); if (m > R) { dx = dx / m * R; dy = dy / m * R; }
      knob.style.transform = `translate(${dx}px,${dy}px)`; inp.stick.x = dx / R; inp.stick.y = -dy / R;
    };
    joy.addEventListener('pointerdown', e => { jp = e.pointerId; joy.setPointerCapture(jp); setStick(e); });
    joy.addEventListener('pointermove', e => { if (e.pointerId === jp) setStick(e); });
    const jend = e => { if (e.pointerId === jp) { jp = null; knob.style.transform = ''; inp.stick.x = inp.stick.y = 0; } };
    joy.addEventListener('pointerup', jend); joy.addEventListener('pointercancel', jend);

    // 3) FIRE button: holds fire AND its drag also rotates the camera (thumb never leaves the button).
    //    Dragging up raises the crosshair; Phase 3 adds the head-height mapping on top of this.
    const fire = $('bFire'); let fp = null, fx = 0, fy = 0;
    fire.addEventListener('pointerdown', e => { fp = e.pointerId; fire.setPointerCapture(fp); fx = e.clientX; fy = e.clientY; inp.fireTouch = true; fire.classList.add('on'); });
    fire.addEventListener('pointermove', e => { if (e.pointerId === fp) { inp.addFireDrag(e.clientX - fx, e.clientY - fy); fx = e.clientX; fy = e.clientY; } });
    const fend = e => { if (e.pointerId === fp) { fp = null; inp.fireTouch = false; fire.classList.remove('on'); } };
    fire.addEventListener('pointerup', fend); fire.addEventListener('pointercancel', fend);
    // jump also tracks "held" so holding it into a low obstacle climbs it
    const jb = $('bJump'); jb.addEventListener('pointerdown', () => inp.jumpHeld = true); ['pointerup', 'pointercancel', 'pointerleave'].forEach(t => jb.addEventListener(t, () => inp.jumpHeld = false));
  }
  _bindButtons() {
    const inp = this.input, $ = this.$;
    const tap = (id, fn) => $(id).addEventListener('pointerdown', e => { e.stopPropagation(); audio.init(); fn(); });
    tap('bJump', () => inp.press('jump')); tap('bCrouch', () => inp.press('crouch')); tap('bProne', () => inp.press('prone'));
    tap('bScope', () => inp.press('scope')); tap('bMed', () => inp.press('medkit')); tap('bGloo', () => inp.press('gloo')); tap('bGren', () => inp.press('grenade'));
    tap('bSprint', () => { inp.sprintToggle = !inp.sprintToggle; });
    tap('bReload', () => inp.press('reload')); tap('bPick', () => inp.press('interact'));
    tap('bSwap', () => inp.press('swap'));
    tap('bChat', () => this.toast('Squad chat arrives in Phase 5'));
    tap('bBag', () => { const p = this.player; if (!p) return; const C = CAPS, L = p.backpack; openModal('BACKPACK', `<p>🎒 Backpack Lv.${L}</p><p>🩹 Medkits <b>${p.items.medkit}/${C.medkit[L]}</b></p><p>💣 Grenades <b>${p.items.grenade}/${C.grenade[L]}</b></p><p>🧊 Gloo walls <b>${p.items.gloo}/${C.gloo[L]}</b></p><p>🛡 Armour Lv.${p.armor} &nbsp; ⛑ Helmet Lv.${p.helmet}</p><p class="soon">A bigger backpack lets you carry more items.</p>`); });
    tap('bMarker', () => { const p = this.player; if (!p) return; const f = p.forward; this.marker = { x: p.pos.x + f.x * 30, z: p.pos.z + f.z * 30 }; audio.click(); this.toast('Marker placed'); });
    tap('bBuy', () => { if (this.match && this.match.phase === 'buy') this.openBuy(this.match); else this.toast('You can only buy during the buy phase'); });
    tap('bGear', () => this.openPause()); tap('bMap', () => this.toggleMap()); tap('bmx', () => this.toggleMap());
    if (!this.world.mapImg) $('bMap').style.display = 'none';
  }
  openPause() {
    const s = store.data.settings; this.input.clearAll(); document.exitPointerLock?.();
    openModal('PAUSED', `
      <label class="row">Camera sens <input type="range" min="0.3" max="2" step="0.05" data-k="camera" value="${s.sens.camera}"></label>
      <label class="row">Scope sens <input type="range" min="0.2" max="1.5" step="0.05" data-k="scope" value="${s.sens.scope}"></label>
      <label class="row">Head-lock assist <input type="range" min="0" max="1" step="0.05" data-s="assist" value="${s.assist}"></label>
      <label class="row">Auto-fire (shoots when aiming at an enemy) <input type="checkbox" id="af" ${s.autoFire ? 'checked' : ''}></label>
      <label class="row">Auto-pickup weapons <input type="checkbox" id="ap" ${s.autoPickup ? 'checked' : ''}></label>
      <button class="btn start sm" data-close>RESUME</button> <button class="btn guest" id="leave">Leave match</button>`,
      el => {
        el.querySelectorAll('input[type=range]').forEach(r => r.oninput = () => { if (r.dataset.s) s[r.dataset.s] = +r.value; else s.sens[r.dataset.k] = +r.value; store.save(); });
        el.querySelector('#af').onchange = e => { s.autoFire = e.target.checked; store.save(); };
        el.querySelector('#ap').onchange = e => { s.autoPickup = e.target.checked; store.save(); };
        el.querySelector('#leave').onclick = () => { el.remove(); this.onLeave(); };
      });
  }

  // ---- called by the game --------------------------------------------------------
  toast(t) { const d = document.createElement('div'); d.className = 'toast'; d.textContent = t; this.root.appendChild(d); setTimeout(() => d.remove(), 2200); }
  killFeed(a, b, head) { const kf = this.$('kf'), r = document.createElement('div'); r.innerHTML = `<b>${a}</b> ${head ? '💀' : '✖'} ${b}`; if (a === 'You') r.style.background = 'rgba(34,197,94,.75)'; if (b === 'You') r.style.background = 'rgba(239,68,68,.8)'; kf.prepend(r); setTimeout(() => r.remove(), 5000); while (kf.children.length > 4) kf.lastChild.remove();
    if (a === 'You') { this.kills++; this.$('kills').textContent = this.kills; audio.tone(1400, 0.15, 'square', 0.15, null, 0, 700); }
    if (!this.world.match) { this.alive = Math.max(1, this.alive - 1); this.$('alive').textContent = this.alive; } }
  streak(n) { const s = this.$('streak'); s.textContent = 'x' + n; s.classList.remove('pop'); void s.offsetWidth; s.classList.add('pop'); }
  damageNumber(x, y, text, color = '#fff') { const d = document.createElement('div'); d.className = 'dnum'; d.textContent = text; d.style.cssText = `left:${x}px;top:${y}px;color:${color}`; this.root.appendChild(d); setTimeout(() => d.remove(), 900); }
  flashDamage() { const f = this.$('flash'); f.classList.remove('on'); void f.offsetWidth; f.classList.add('on'); }
  setScope(name) { this.$('scopeTxt').textContent = name; this.$('cross').classList.toggle('scoped', name !== 'OFF'); }
  setHeal(p, label = 'Using medkit...') { const h = this.$('heal'); if (p === null) h.style.display = 'none'; else { h.style.display = 'block'; h.firstChild.style.width = Math.round(p * 100) + '%'; if (h.lastChild.textContent !== label) h.lastChild.textContent = label; } }
  hitDir(a) { const e = this.$('hdir'); e.style.transform = `rotate(${a}rad)`; e.classList.remove('on'); void e.offsetWidth; e.classList.add('on'); }           // red arrow toward whoever shot you
  update_buttons(p) {                                          // cheap, only touches DOM when values change
    this.player = p; const $ = this.$, set = (id, v) => { const e = $(id); if (e.textContent !== String(v)) e.textContent = v; };
    set('cMed', p.items.medkit); set('cGren', p.items.grenade); set('cGloo', p.items.gloo);
    $('bCrouch').classList.toggle('on', p.stance === 'crouch'); $('bProne').classList.toggle('on', p.stance === 'prone');
    $('bSprint').classList.toggle('on', p.sprinting);
  }

  showBuyButton(on) { this.$('bBuy').style.display = on ? 'flex' : 'none'; }
  openBuy(match) {                                                 // CS Rank buy menu: weapons, armour, helmets, items
    this.match = match; if (this.buyEl) return; const d = document.createElement('div'); d.className = 'buy'; this.buyEl = d;
    d.innerHTML = '<div class="buyhead"><b>BUY MENU</b><span id="money"></span><button class="btn x" id="buyx">✕</button></div><div class="buygrid" id="buygrid"></div><div class="buynote">Gear you buy is kept if you survive the round. Kills earn $200.</div>';
    this.root.appendChild(d); d.querySelector('#buyx').onclick = () => this.closeBuy(); this._renderBuy();
  }
  _renderBuy() {
    if (!this.buyEl || !this.player) return; const p = this.player, m = this.match; this.buyEl.querySelector('#money').textContent = '$' + p.money;
    const g = this.buyEl.querySelector('#buygrid'); g.innerHTML = m.shopList(p).map(i => `<button class="btn shopitem ${i.status}" data-k="${i.key}"><b>${i.label}</b><small>$${i.price}</small><em>${i.status === 'owned' ? 'OWNED' : i.status === 'poor' ? 'NO CASH' : i.status === 'blocked' ? 'N/A' : 'BUY'}</em></button>`).join('');
    g.querySelectorAll('.shopitem').forEach(b => b.onclick = () => { if (m.purchase(p, b.dataset.k)) audio.pickup(); else audio.back(); this._renderBuy(); });
  }
  closeBuy() { if (this.buyEl) { this.buyEl.remove(); this.buyEl = null; } }
  setDrop(t) { const e = this.$('dropmsg'); e.style.display = t ? 'block' : 'none'; if (t) e.textContent = t; }
  setStorm(on) { this.$('storm').style.opacity = on ? 1 : 0; }
  setAlive(n) { if (n !== this.alive) { this.alive = n; this.$('alive').textContent = n; } }
  banner(t, ms = 3500) { const b = this.$('banner'); b.textContent = t; b.classList.add('on'); clearTimeout(this._bt); this._bt = setTimeout(() => b.classList.remove('on'), ms); }
  toggleMap() {
    if (!this.world.mapImg) return; this.bigOpen = !this.bigOpen; const el = this.$('bigmap'), cv = this.$('bm'); el.style.display = this.bigOpen ? 'flex' : 'none';
    const S = Math.floor(Math.min(innerWidth, innerHeight) * 0.88); cv.width = cv.height = S; cv.style.width = cv.style.height = S + 'px'; this.input.clearAll();
  }
  showResult(o) {                                       // victory / defeat screen
    this.input.clearAll(); document.exitPointerLock?.(); const d = document.createElement('div'); d.className = 'result ' + (o.win ? 'win' : 'lose');
    d.innerHTML = `<div class="rbanner">${o.title}</div><div class="rsub">${o.sub || ''}</div><div class="rstats">${o.rows.map(r => `<div><span>${r[0]}</span><b>${r[1]}</b></div>`).join('')}</div><div class="rbtns"><button class="btn start sm" id="rAgain">PLAY AGAIN</button><button class="btn guest" id="rLobby">LOBBY</button></div>`;
    this.root.appendChild(d); d.querySelector('#rAgain').onclick = () => { audio.click(); o.onAgain(); }; d.querySelector('#rLobby').onclick = () => { audio.back(); o.onLobby(); };
  }
  // white = body, red = headshot, big red = kill
  hitMarker(kind) { const h = this.$('hit'); h.className = 'hitmark'; void h.offsetWidth; h.className = 'hitmark ' + kind; }
  setPickup(text) { const b = this.$('bPick'); b.style.display = text ? 'flex' : 'none'; if (text && b.textContent !== text) b.textContent = text; }
  damageNumberAt(v3, text, color, big) {            // project a world position to the screen
    if (!this.camera) return; const v = v3.clone().project(this.camera); if (v.z > 1) return;
    this.damageNumber((v.x * 0.5 + 0.5) * innerWidth, (-v.y * 0.5 + 0.5) * innerHeight, text, color);
    const n = this.root.lastChild; if (n && big) n.style.fontSize = '5.2vh';
  }
  setWeaponUI(p) {
    const W = p.weapons, $ = this.$, w = W.weapon;
    for (let i = 0; i < 3; i++) { const el = $('ws' + i), id = i === 2 ? 'fist' : W.slots[i]; el.classList.toggle('sel', W.cur === i); const t = i === 2 ? 'FIST' : id ? W.slots[i] && w ? this._short(id) : '' : '-'; if (el.lastChild.textContent !== t) el.lastChild.textContent = t; }
    const txt = w.type === 'melee' ? '-- / --' : W.reloading ? 'RELOAD ' + Math.round((1 - W.reloadT / w.reload) * 100) + '%' : W.mag + ' / ' + W.reserveAmmo;
    if ($('ammoTxt').textContent !== txt) $('ammoTxt').textContent = txt;
  }
  _short(id) { return { pistol: 'POP-9', smg: 'RATTLE', ar: 'STRIKER', shotgun: 'BOOMER', sniper: 'LONG' }[id] || id; }

  _overlays(c, X, Z, zone, sc) {                          // plane path + airdrop markers (shared by minimap and big map)
    if (zone.plane) { const pl = zone.plane; c.strokeStyle = '#ff6bd6'; c.lineWidth = 3 * sc; c.setLineDash([10, 8]); c.beginPath(); c.moveTo(X(pl.ax), Z(pl.az)); c.lineTo(X(pl.bx), Z(pl.bz)); c.stroke(); c.setLineDash([]); c.fillStyle = '#ff6bd6'; c.beginPath(); c.arc(X(pl.x), Z(pl.z), 8 * sc, 0, 7); c.fill(); }
    for (const t of zone.mates || []) { c.fillStyle = t.downed ? '#ef4444' : '#4ade80'; c.strokeStyle = '#14082e'; c.lineWidth = 2; c.beginPath(); c.arc(X(t.x), Z(t.z), 6 * sc, 0, 7); c.fill(); c.stroke(); }          // teammates
    for (const d of zone.drops || []) { c.fillStyle = '#ff3b3b'; c.strokeStyle = '#fff'; c.lineWidth = 2; c.save(); c.translate(X(d.x), Z(d.z)); c.rotate(0.785); c.fillRect(-7 * sc, -7 * sc, 14 * sc, 14 * sc); c.strokeRect(-7 * sc, -7 * sc, 14 * sc, 14 * sc); c.restore(); }
  }
  _bigMap(p, zone) {
    if (!this.bigOpen) return; const cv = this.$('bm'), c = cv.getContext('2d'), S = cv.width, w = this.world, H = w.mapHalf || 500, k = S / (2 * H), X = x => (x + H) * k, Z = z => (z + H) * k;
    c.clearRect(0, 0, S, S); c.drawImage(w.mapImg, 0, 0, S, S);
    c.lineWidth = 3; c.strokeStyle = '#fff'; c.beginPath(); c.arc(X(zone.cx), Z(zone.cz), zone.r * k, 0, 7); c.stroke();
    if (zone.showNext !== false) { c.strokeStyle = '#22d3ee'; c.setLineDash([8, 6]); c.beginPath(); c.arc(X(zone.nx), Z(zone.nz), zone.nr * k, 0, 7); c.stroke(); c.setLineDash([]); }
    c.font = 'italic 900 ' + Math.round(S / 40) + 'px Arial'; c.textAlign = 'center'; c.lineWidth = 4; for (const l of w.locations) { c.strokeStyle = '#14082e'; c.strokeText(l.name, X(l.x), Z(l.z)); c.fillStyle = '#ffd23f'; c.fillText(l.name, X(l.x), Z(l.z)); }
    this._overlays(c, X, Z, zone, 1.6); if (this.marker) { c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(X(this.marker.x), Z(this.marker.z), 9, 0, 7); c.fill(); }
    c.save(); c.translate(X(p.pos.x), Z(p.pos.z)); c.rotate(-p.yaw); c.fillStyle = '#22d3ee'; c.strokeStyle = '#14082e'; c.lineWidth = 3; c.beginPath(); c.moveTo(0, -16); c.lineTo(11, 11); c.lineTo(0, 6); c.lineTo(-11, 11); c.closePath(); c.fill(); c.stroke(); c.restore();
  }

  update(p, zone, dt, time) {
    this.fps += (1 / Math.max(dt, 0.001) - this.fps) * 0.05;
    const $ = this.$; $('hpfill').style.width = (p.hp / MOVE.maxHp * 100) + '%'; $('hptxt').textContent = Math.ceil(p.hp) + '/' + MOVE.maxHp;
    $('hpfill').style.background = p.hp < 70 ? '#ef4444' : '#4ade80'; $('arm').textContent = p.armor; $('hel').textContent = p.helmet;
    $('hint').style.opacity = p.hp < MOVE.maxHp * 0.5 && p.healT <= 0 ? 1 : 0;
    // crosshair: size = bullet spread, vertical offset = headshot drag lift (both converted to screen pixels)
    const W = p.weapons, half = innerHeight / 2, tf = Math.tan(p.camera.fov * Math.PI / 360);
    $('cross').style.setProperty('--sp', (Math.min(90, Math.tan(W.spread) / tf * half) + 5).toFixed(1) + 'px');
    $('cross').style.setProperty('--dy', (-Math.tan(W.aimAngle) / tf * half).toFixed(1) + 'px'); this.setWeaponUI(p);
    if (this.buyEl && this.match && this.match.phase !== 'buy') this.closeBuy();
    $('zmsg').textContent = zone.msg; this._compass(p); this._minimap(p, zone); this._bigMap(p, zone);
  }
  _compass(p) {
    const c = this.cp, W = 640, H = 56; c.clearRect(0, 0, W, H);
    const heading = ((-p.yaw * 180 / Math.PI) % 360 + 360) % 360, span = 120, ppd = W / span;
    c.fillStyle = 'rgba(20,8,46,.7)'; c.fillRect(0, 0, W, 36); c.textAlign = 'center'; c.textBaseline = 'middle'; c.font = 'italic 900 22px Arial Black, Arial';
    const names = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SW', 270: 'W', 315: 'NW' };
    for (let a = Math.floor((heading - span / 2) / 15) * 15; a <= heading + span / 2; a += 15) {
      const x = W / 2 + (a - heading) * ppd, n = ((a % 360) + 360) % 360;
      if (names[n] !== undefined) { c.fillStyle = n === 0 ? '#ff5252' : '#ffd23f'; c.fillText(names[n], x, 18); } else { c.fillStyle = '#fff'; c.fillRect(x - 1, 12, 2, 12); }
    }
    c.fillStyle = '#22d3ee'; c.beginPath(); c.moveTo(W / 2 - 8, 38); c.lineTo(W / 2 + 8, 38); c.lineTo(W / 2, 50); c.fill();
    c.fillStyle = '#fff'; c.font = '900 16px Arial'; c.fillText(Math.round(heading) + '°', W / 2 + 34, 46);
  }
  _minimap(p, zone) {
    const c = this.mm, S = 260, w = this.world, H = w.mapHalf || 500, R = w.mapImg ? Math.min(130, H * 0.8) : 52, k = S / 2 / R;       // shows a 52 m radius around the player, north up
    c.clearRect(0, 0, S, S); c.save(); c.beginPath(); c.arc(S / 2, S / 2, S / 2 - 2, 0, 7); c.clip();
    c.fillStyle = w.mapImg ? '#3bb9f0' : '#2f7d4a'; c.fillRect(0, 0, S, S);
    const X = x => S / 2 + (x - p.pos.x) * k, Z = z => S / 2 + (z - p.pos.z) * k;
    if (w.mapImg) {                                                         // big map: crop the pre-rendered terrain image around the player
      const m = w.mapPxPerM, sx = Math.max(0, (p.pos.x - R + H) * m), sy = Math.max(0, (p.pos.z - R + H) * m), ex = Math.min(w.mapImg.width, (p.pos.x + R + H) * m), ey = Math.min(w.mapImg.height, (p.pos.z + R + H) * m);
      if (ex > sx && ey > sy) c.drawImage(w.mapImg, sx, sy, ex - sx, ey - sy, X(sx / m - H), Z(sy / m - H), (ex - sx) / m * k, (ey - sy) / m * k);
    } else {
      c.fillStyle = '#c9b27a'; c.fillRect(X(-4), 0, 8 * k, S);                              // road
      c.fillStyle = 'rgba(255,255,255,.55)'; for (const b of w.colliders) if (b.mesh) c.fillRect(X(b.minX), Z(b.minZ), (b.maxX - b.minX) * k, (b.maxZ - b.minZ) * k);
    }
    c.lineWidth = 3; c.strokeStyle = '#fff'; c.beginPath(); c.arc(X(zone.cx), Z(zone.cz), zone.r * k, 0, 7); c.stroke();            // current safe zone
    if (zone.showNext !== false) { c.strokeStyle = '#22d3ee'; c.setLineDash([8, 6]); c.beginPath(); c.arc(X(zone.nx), Z(zone.nz), zone.nr * k, 0, 7); c.stroke(); c.setLineDash([]); }
    this._overlays(c, X, Z, zone, 1); // next zone
    c.font = 'italic 900 16px Arial'; c.textAlign = 'center'; c.fillStyle = '#ffd23f'; for (const l of w.locations) c.fillText(l.name, X(l.x), Z(l.z));
    if (this.marker) { c.fillStyle = '#ffd23f'; c.beginPath(); c.arc(X(this.marker.x), Z(this.marker.z), 7, 0, 7); c.fill(); }
    c.translate(S / 2, S / 2); c.rotate(-p.yaw); c.fillStyle = '#22d3ee'; c.strokeStyle = '#14082e'; c.lineWidth = 3;   // player arrow
    c.beginPath(); c.moveTo(0, -14); c.lineTo(10, 10); c.lineTo(0, 5); c.lineTo(-10, 10); c.closePath(); c.fill(); c.stroke(); c.restore();
  }
}
