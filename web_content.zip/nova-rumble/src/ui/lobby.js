// Lobby UI overlay (HTML) on top of the 3D lobby scene.
import { MODES, RANK_TIERS } from '../data/config.js';
import { DIFFICULTY_LABELS } from '../data/bots.js';
import { resolveMode, CUSTOM_DEFAULT, CUSTOM_PRESETS, WEAPON_RULE_LABELS, TYPE_LABELS } from '../data/modes.js';
import { store } from '../core/store.js';
import { audio } from '../audio/audio.js';
import { openModal, toast } from './modal.js';

const ROMAN = ['', 'I', 'II', 'III'];
const LEFT_MENU = [
  { k: 'Character', i: '🧑‍🚀', phase: 7 }, { k: 'Vault', i: '🎒', phase: 7 },
  { k: 'Weapon', i: '🔫', phase: 3, isNew: true }, { k: 'Season', i: '🎖️', phase: 7 }, { k: 'Tasks', i: '📋', phase: 7 }
];

export function showLobby(root, scene, onLogout, onStart) {
  const d = store.data;
  root.innerHTML = `
  <div class="screen lobby">
    <div class="tl"><div class="avatar" id="avatar">${d.name[0].toUpperCase()}</div>
      <div class="pinfo"><b id="pname">${d.name}</b><small>Lv.${d.level} &nbsp;<span class="rank">${RANK_TIERS[d.rank.tier].toUpperCase()} ${ROMAN[d.rank.sub]}</span></small></div></div>
    <div class="top-mid">
      <div class="cur">🪙 <b id="coins">${d.coins.toLocaleString()}</b><button class="btn plus" data-soon="Shop|7">+</button></div>
      <div class="cur">💎 <b>${d.gems}</b><button class="btn plus" data-soon="Shop|7">+</button></div></div>
    <div class="top-right">
      <button class="btn ic" data-soon="Achievements|7">🏆</button><button class="btn ic" data-soon="Friends|8">👥</button>
      <button class="btn ic" data-soon="Mail|8">✉️</button><button class="btn ic" id="settings">⚙️</button>
      <div class="sys"><span id="batt">🔋 --</span> <span id="ping">📶 -- ms</span></div></div>
    <div class="left-menu">${LEFT_MENU.map(m => `<button class="btn side" data-soon="${m.k}|${m.phase}"><span>${m.i}</span>${m.k}${m.isNew ? '<em>NEW</em>' : ''}</button>`).join('')}</div>
    <div class="br">
      <button class="btn mode" id="modeBtn"></button>
      <button class="btn invite" data-soon="Invite|8">➕ Invite</button>
      <button class="btn start" id="start">START</button></div>
  </div>`;

  const modeBtn = root.querySelector('#modeBtn');
  const refreshMode = () => { const m = MODES.find(x => x.id === d.mode) || MODES[0]; modeBtn.innerHTML = `<small>MODE</small>${m.icon} ${m.name}${m.id === 'custom' && d.custom ? ' ' + d.custom.a + 'v' + d.custom.b : ''}`; };
  refreshMode();

  // Placeholder panels for features built in later phases
  root.querySelectorAll('[data-soon]').forEach(b => b.onclick = () => {
    audio.click(); const [name, ph] = b.dataset.soon.split('|');
    openModal(name, `<p class="soon">🚧 <b>${name}</b> arrives in <b>Phase ${ph}</b>.</p>`);
  });

  // Mode selector popup (all modes are free)
  modeBtn.onclick = () => {
    audio.click();
    openModal('SELECT MODE', `<div class="modes">${MODES.map(m => `<button class="btn modeopt ${m.id === d.mode ? 'sel' : ''}" data-id="${m.id}"><span>${m.icon}</span><b>${m.name}</b><small>${m.desc}</small><em>FREE</em></button>`).join('')}<div class="diff">Bots: ${Object.keys(DIFFICULTY_LABELS).map(k => `<button class="btn ${d.settings.botDifficulty === k ? 'sel' : ''}" data-d="${k}">${DIFFICULTY_LABELS[k]}</button>`).join('')}</div></div>`,
      el => { el.querySelectorAll('.modeopt').forEach(o => o.onclick = () => { d.mode = o.dataset.id; store.save(); refreshMode(); audio.click(); el.remove(); if (d.mode === 'custom') openCustomRoom(d, refreshMode); });
        el.querySelectorAll('[data-d]').forEach(b => b.onclick = () => { d.settings.botDifficulty = b.dataset.d; store.save(); audio.click(); el.querySelectorAll('[data-d]').forEach(x => x.classList.toggle('sel', x === b)); }); });
  };

  // Settings (Phase 1: sound sliders + logout; full settings in Phase 8)
  root.querySelector('#settings').onclick = () => {
    audio.click(); const s = d.settings;
    openModal('SETTINGS', `
      <label class="row">Master <input type="range" min="0" max="1" step="0.05" data-k="master" value="${s.master}"></label>
      <label class="row">Music <input type="range" min="0" max="1" step="0.05" data-k="music" value="${s.music}"></label>
      <label class="row">Effects <input type="range" min="0" max="1" step="0.05" data-k="sfx" value="${s.sfx}"></label>
      <button class="btn guest" id="logout">Log out</button>`,
      el => {
        el.querySelectorAll('input[type=range]').forEach(r => r.oninput = () => { s[r.dataset.k] = +r.value; audio.applySettings(); store.save(); });
        el.querySelector('#logout').onclick = () => { store.data.loggedIn = false; store.save(); audio.stopMusic(); el.remove(); onLogout(); };
      });
  };

  // START: fake matchmaking queue that fills with bots (real match arrives in Phase 5)
  root.querySelector('#start').onclick = () => {
    audio.start(); const m = MODES.find(x => x.id === d.mode), cfg = resolveMode(d.mode, d.custom), total = cfg.kind === 'team' ? cfg.a + cfg.b : cfg.kind === 'br' ? 50 : 1;
    const el = openModal('MATCHMAKING', `<div class="mm"><div class="spin"></div><b>${m.name}</b><div id="mmc">Players 1/${total}</div><small>Bots fill empty slots</small></div>`);
    let n = 1; const t = setInterval(() => {
      n = Math.min(total, n + 1 + Math.floor(Math.random() * Math.max(2, total / 8))); const c = el.querySelector('#mmc'); if (!c) return clearInterval(t);
      c.textContent = `Players ${n}/${total}`;
      if (n >= total) { clearInterval(t); c.innerHTML = cfg.kind === 'training' ? 'Ready! Entering the Training Ground...' : cfg.kind === 'br' ? 'Ready! Boarding the plane...' : `Ready! ${cfg.label} - loading the arena...`; setTimeout(() => { el.remove(); onStart(); }, 900); }
    }, 300);
  };

  // Battery + fake ping indicators
  navigator.getBattery?.().then(b => { const u = () => root.querySelector('#batt').textContent = `🔋 ${Math.round(b.level * 100)}%`; u(); b.onlevelchange = u; }).catch(() => {});
  const pingT = setInterval(() => { const p = root.querySelector('#ping'); if (!p) return clearInterval(pingT); p.textContent = `📶 ${30 + Math.floor(Math.random() * 25)} ms`; }, 2000);
}

// Custom Room: team layout (any A v B from 1v1 to 8v8), game type, map, weapon rules, bot difficulty and room settings. Bots fill every other slot.
function openCustomRoom(d, onSave) {
  const c = { ...CUSTOM_DEFAULT, ...(d.custom || {}) }, opt = (v, cur, label) => `<option value="${v}" ${String(v) === String(cur) ? 'selected' : ''}>${label ?? v}</option>`, nums = (a, b, cur) => Array.from({ length: b - a + 1 }, (_, i) => opt(a + i, cur)).join('');
  const el = openModal('CUSTOM ROOM', `<div class="cfg">
    <label class="wide">Game type<select id="c-type">${Object.keys(TYPE_LABELS).map(k => opt(k, c.type, TYPE_LABELS[k])).join('')}</select></label>
    <label>Your team (you + bots)<select id="c-a">${nums(1, 8, c.a)}</select></label><label>Enemy team (bots)<select id="c-b">${nums(1, 8, c.b)}</select></label>
    <div class="wide presets">Quick layout: ${CUSTOM_PRESETS.map(p => `<button class="btn" data-p="${p[0]},${p[1]}">${p[0]}v${p[1]}</button>`).join('')}</div>
    <label>Map<select id="c-map">${opt('yard', c.map, 'Container Yard (200 m)')}${opt('wolf', c.map, 'Compact Arena (100 m)')}</select></label>
    <label>Weapon rules<select id="c-weapons">${Object.keys(WEAPON_RULE_LABELS).map(k => opt(k, c.weapons, WEAPON_RULE_LABELS[k])).join('')}</select></label>
    <label>Bot difficulty<select id="c-diff">${Object.keys(DIFFICULTY_LABELS).map(k => opt(k, c.difficulty, DIFFICULTY_LABELS[k])).join('')}</select></label>
    <label>Rounds to win<select id="c-rounds">${nums(2, 7, c.rounds)}</select></label>
    <label>TDM kill target<select id="c-kills">${[20, 30, 40, 60, 80, 100].map(v => opt(v, c.killTarget)).join('')}</select></label>
    <label>Round time (s)<select id="c-time">${[60, 90, 100, 120, 150].map(v => opt(v, c.roundTime)).join('')}</select></label>
    <label>Start money<select id="c-money">${[500, 800, 1500, 3000, 6000].map(v => opt(v, c.money, '$' + v)).join('')}</select></label>
    <label>Gloo walls<select id="c-gloo">${opt('1', c.gloo ? '1' : '0', 'On')}${opt('0', c.gloo ? '1' : '0', 'Off')}</select></label>
    <button class="btn start sm wide" id="c-save">SAVE ROOM</button></div>`);
  const $ = id => el.querySelector('#' + id);
  el.querySelectorAll('[data-p]').forEach(b => b.onclick = () => { const [a, bb] = b.dataset.p.split(','); $('c-a').value = a; $('c-b').value = bb; audio.click(); });
  $('c-save').onclick = () => {
    d.custom = { type: $('c-type').value, a: +$('c-a').value, b: +$('c-b').value, map: $('c-map').value, weapons: $('c-weapons').value, difficulty: $('c-diff').value, rounds: +$('c-rounds').value, killTarget: +$('c-kills').value, roundTime: +$('c-time').value, money: +$('c-money').value, gloo: $('c-gloo').value === '1' };
    store.save(); audio.click(); el.remove(); onSave();
  };
}
