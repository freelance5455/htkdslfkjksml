// Tiny modal + toast helpers shared by all screens.
import { audio } from '../audio/audio.js';
export function openModal(title, html, onMount) {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<div class="panel"><div class="panel-head"><span>${title}</span><button class="btn x" data-close>✕</button></div><div class="panel-body">${html}</div></div>`;
  m.addEventListener('click', e => { if (e.target === m || e.target.dataset.close !== undefined) { audio.back(); m.remove(); } });
  document.getElementById('ui').appendChild(m); if (onMount) onMount(m); return m;
}
export function toast(msg) {
  const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
  document.getElementById('ui').appendChild(t); setTimeout(() => t.remove(), 2400);
}
