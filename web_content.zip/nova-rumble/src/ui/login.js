// Login screen: fake/local sign-in. Terms + age checkboxes are required.
import { GAME } from '../data/config.js';
import { store } from '../core/store.js';
import { audio } from '../audio/audio.js';
import { toast } from './modal.js';

export function showLogin(root, onDone) {
  root.innerHTML = `
  <div class="screen login">
    <div class="logo">NOVA<span>RUMBLE</span></div>
    <div class="login-card">
      <button class="btn google" data-p="Google">G &nbsp;Sign in with Google</button>
      <button class="btn facebook" data-p="Facebook">f &nbsp;Sign in with Facebook</button>
      <button class="btn guest" data-p="Guest">Guest</button>
      <label class="chk"><input type="checkbox" id="terms"> I agree to the Terms of Service and Privacy Policy</label>
      <label class="chk"><input type="checkbox" id="age"> I am over the age of majority</label>
    </div>
    <div class="ver">${GAME.version}</div>
  </div>`;
  root.querySelectorAll('[data-p]').forEach(b => b.onclick = () => {
    audio.init(); audio.click();
    if (!root.querySelector('#terms').checked || !root.querySelector('#age').checked) { toast('Please accept both checkboxes to continue'); return; }
    const p = b.dataset.p;                                  // local/fake login: only stores a name
    store.data.loggedIn = true; store.data.provider = p;
    if (!store.data.name || store.data.name === 'Player') store.data.name = p === 'Guest' ? 'Guest' + store.data.id.slice(-4) : p + 'Hero' + store.data.id.slice(-3);
    store.save(); onDone();
  });
}
