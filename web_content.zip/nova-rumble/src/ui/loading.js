// Loading screen: logo, progress bar, random tips, animated cartoon runner (pure CSS).
import { TIPS } from '../data/config.js';
export function showLoading(root, onDone) {
  root.innerHTML = `
  <div class="screen loading">
    <div class="logo small">NOVA<span>RUMBLE</span></div>
    <div class="runner"><i class="hd"></i><i class="bd"></i><i class="ar"></i><i class="lg l1"></i><i class="lg l2"></i></div>
    <div class="tip" id="tip"></div>
    <div class="bar"><div id="fill"></div></div><div class="pct" id="pct">0%</div>
  </div>`;
  const tip = root.querySelector('#tip'), fill = root.querySelector('#fill'), pct = root.querySelector('#pct');
  const showTip = () => tip.textContent = '💡 ' + TIPS[Math.floor(Math.random() * TIPS.length)];
  showTip(); const tipTimer = setInterval(showTip, 1800);
  let p = 0;                                                   // fake but smooth progress
  const timer = setInterval(() => {
    p = Math.min(100, p + 2 + Math.random() * 5);
    fill.style.width = p + '%'; pct.textContent = Math.floor(p) + '%';
    if (p >= 100) { clearInterval(timer); clearInterval(tipTimer); setTimeout(onDone, 250); }
  }, 90);
}
