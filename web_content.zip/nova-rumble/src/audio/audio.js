// Procedural Web Audio: UI sounds + a simple synth lobby loop. No audio files needed.
import { store } from '../core/store.js';
let ctx, master, musicGain, sfxGain, musicTimer = null, step = 0;

export const audio = {
  init() {                                     // must be called from a user gesture
    if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    master = ctx.createGain(); musicGain = ctx.createGain(); sfxGain = ctx.createGain();
    musicGain.connect(master); sfxGain.connect(master); master.connect(ctx.destination);
    this.applySettings();
  },
  applySettings() {
    if (!ctx) return; const s = store.data.settings;
    master.gain.value = s.master; musicGain.gain.value = s.music * 0.35; sfxGain.gain.value = s.sfx;
  },
  tone(freq, dur = 0.1, type = 'square', vol = 0.2, bus = null, when = 0, slideTo = null) {
    if (!ctx) return; bus = bus || sfxGain; const t = ctx.currentTime + when;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(bus); o.start(t); o.stop(t + dur + 0.02);
  },
  click() { this.tone(660, 0.07, 'square', 0.15, null, 0, 990); },
  back()  { this.tone(520, 0.08, 'square', 0.15, null, 0, 300); },
  start() { [392, 523, 659, 784].forEach((f, i) => this.tone(f, 0.14, 'sawtooth', 0.18, null, i * 0.08)); },
  // ---- Phase 3 sounds ----
  noise(dur, freq, vol = 0.3, when = 0) {                 // filtered white-noise burst (gun "crack")
    if (!ctx) return; if (!this._nb) { this._nb = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate); const d = this._nb.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1; }
    const t = ctx.currentTime + when, src = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    src.buffer = this._nb; f.type = 'lowpass'; f.frequency.value = freq; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(f); f.connect(g); g.connect(sfxGain); src.start(t); src.stop(t + dur + 0.02);
  },
  // each weapon has its own noise colour, length and thump
  gun(id, vol = 1) {
    const P = { pistol: [2600, .09, 240, .35], smg: [3400, .06, 280, .3], ar: [1900, .12, 160, .4], shotgun: [900, .28, 90, .6], sniper: [600, .45, 70, .6] }[id] || [2000, .1, 150, .3];
    this.noise(P[1], P[0], P[3] * vol); this.tone(P[2], P[1] + .05, 'sawtooth', .25 * vol, null, 0, 40);
  },
  reload() { this.tone(320, .05, 'square', .12); this.tone(240, .06, 'square', .12, null, .35); this.tone(480, .06, 'square', .14, null, .9); },
  empty() { this.tone(1300, .03, 'square', .12); },
  hit() { this.tone(900, .06, 'square', .18, null, 0, 500); },
  headshot() { this.tone(1760, .3, 'sine', .3); this.tone(2637, .35, 'sine', .22); this.tone(3520, .4, 'triangle', .1); },   // the "ding"
  kill() { this.tone(220, .22, 'square', .25, null, 0, 70); this.tone(880, .12, 'sine', .2, null, .05); },
  pickup() { this.tone(700, .06, 'square', .15); this.tone(1050, .1, 'square', .15, null, .06); },
  // 8-step bass + arpeggio loop, ~108 BPM
  startMusic() {
    if (!ctx || musicTimer) return;
    const bass = [110, 110, 165, 110, 147, 147, 165, 196], arp = [440, 523, 659, 784, 659, 523, 587, 698];
    musicTimer = setInterval(() => {
      const i = step++ % 8;
      this.tone(bass[i], 0.28, 'triangle', 0.5, musicGain);
      this.tone(arp[i], 0.16, 'square', 0.12, musicGain);
    }, 277);
  },
  stopMusic() { clearInterval(musicTimer); musicTimer = null; }
};
