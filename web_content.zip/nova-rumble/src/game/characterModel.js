// Procedural low-poly cartoon character: toon shading + black back-face outlines.
import * as THREE from 'three';

// 3-step gradient gives the cel-shaded look
const gradient = (() => {
  const t = new THREE.DataTexture(new Uint8Array([80, 165, 255]), 3, 1, THREE.RedFormat);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t;
})();
export const toon = (color) => new THREE.MeshToonMaterial({ color, gradientMap: gradient });
const OUTLINE = new THREE.MeshBasicMaterial({ color: 0x14081f, side: THREE.BackSide });

export function outline(mesh, s = 1.09) { const o = new THREE.Mesh(mesh.geometry, OUTLINE); o.scale.setScalar(s); mesh.add(o); }
function mk(geo, color, parent, x = 0, y = 0, z = 0, ol = true) {
  const m = new THREE.Mesh(geo, toon(color)); m.position.set(x, y, z);
  if (ol) outline(m); parent.add(m); return m;
}
function pivot(parent, x, y, z = 0) { const p = new THREE.Group(); p.position.set(x, y, z); parent.add(p); return p; }

function addHair(head, h) {
  const cap = () => mk(new THREE.SphereGeometry(0.35, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.55), h.color, head, 0, 0.02, -0.02);
  switch (h.style) {
    case 'spike':  cap(); for (let i = 0; i < 5; i++) { const a = (i - 2) * 0.5; const c = mk(new THREE.ConeGeometry(0.1, 0.34, 6), h.color, head, Math.sin(a) * 0.26, 0.4 + Math.cos(a) * 0.05, 0); c.rotation.z = -a * 0.7; } break;
    case 'mohawk': cap(); for (let i = 0; i < 5; i++) mk(new THREE.BoxGeometry(0.09, 0.2 + (i % 2) * 0.1, 0.12), h.color, head, 0, 0.36, -0.2 + i * 0.1); break;
    case 'bun':    cap(); mk(new THREE.SphereGeometry(0.15, 12, 8), h.color, head, 0, 0.45, -0.1); mk(new THREE.BoxGeometry(0.66, 0.3, 0.1), h.color, head, 0, 0.1, -0.3); break;
    case 'cap':    cap(); mk(new THREE.BoxGeometry(0.46, 0.06, 0.3), h.color, head, 0, 0.12, 0.38); break;
    default:       cap(); mk(new THREE.BoxGeometry(0.7, 0.4, 0.12), h.color, head, 0, 0.0, -0.3);
  }
}

// returns { group, update(timeSeconds) } with a gentle idle animation
export function buildCharacter(def) {
  const group = new THREE.Group(), body = pivot(group, 0, 0);
  body.scale.x = def.width;                                   // different silhouettes via width

  const legL = pivot(body, -0.16, 0.8), legR = pivot(body, 0.16, 0.8);
  [legL, legR].forEach(l => {
    mk(new THREE.CapsuleGeometry(0.12, 0.5, 4, 10), def.bottom, l, 0, -0.36);
    mk(new THREE.BoxGeometry(0.28, 0.14, 0.4), def.shoes, l, 0, -0.72, 0.06);
  });
  mk(new THREE.CapsuleGeometry(0.28, 0.4, 4, 12), def.top, body, 0, 1.2);        // torso
  mk(new THREE.BoxGeometry(0.58, 0.1, 0.5), def.accent, body, 0, 0.98, 0, false);   // belt
  mk(new THREE.BoxGeometry(0.4, 0.55, 0.2), def.accent, body, 0, 1.25, -0.3);       // backpack

  const armL = pivot(body, -0.4, 1.5), armR = pivot(body, 0.4, 1.5);
  [armL, armR].forEach(a => {
    mk(new THREE.CapsuleGeometry(0.095, 0.44, 4, 8), def.top, a, 0, -0.3);
    mk(new THREE.SphereGeometry(0.11, 10, 8), def.skin, a, 0, -0.64);               // hand
  });

  const head = pivot(body, 0, 1.97);
  mk(new THREE.SphereGeometry(0.33, 20, 14), def.skin, head);
  [-0.12, 0.12].forEach(x => {
    mk(new THREE.SphereGeometry(0.075, 10, 8), 0xffffff, head, x, 0.02, 0.28, false);
    mk(new THREE.SphereGeometry(0.04, 8, 6), 0x1a1030, head, x, 0.02, 0.34, false);
  });
  mk(new THREE.BoxGeometry(0.12, 0.025, 0.02), 0xb04a3a, head, 0, -0.14, 0.32, false); // mouth
  addHair(head, def.hair);

  const update = (t) => {
    body.position.y = Math.sin(t * 2) * 0.012;
    armL.rotation.z = 0.12 + Math.sin(t * 2) * 0.04;
    armR.rotation.z = -0.12 - Math.sin(t * 2 + 1) * 0.04;
    armR.rotation.x = Math.sin(t * 0.7) > 0.92 ? -1.2 : 0;   // occasional wave
    head.rotation.y = Math.sin(t * 0.8) * 0.25;
    head.rotation.z = Math.sin(t * 1.3) * 0.04;
  };
  return { group, update, parts: { body, legL, legR, armL, armR, head } };
}
