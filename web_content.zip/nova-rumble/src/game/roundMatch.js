// Team-mode match: CS Rank (Clash Squad), Lone Wolf, Team Deathmatch and Custom Room. Team A = you + bot teammates, team B = bots.
//  'cs'   : buy phase (money) -> fight -> round end, first team to `rounds` round wins. A shrinking circle ends stalled rounds.
//  'wolf' : same rounds but no shop: everyone gets the same random weapon + gloo walls. Small arena.
//  'tdm'  : first team to `killTarget` kills (or most kills when time runs out). Instant respawns with spawn protection.
import { BaseMatch } from './baseMatch.js';
import { Bot } from '../ai/bot.js';
import { CHARACTERS } from '../data/characters.js';
import { botName } from '../data/bots.js';
import { WEAPONS } from '../data/weapons.js';
import { SHOP, WEAPON_RULES, ECONOMY } from '../data/modes.js';

class SuddenZone {                                           // same interface as the battle royale Zone, so bots avoid it too
  constructor(R0) { this.R0 = R0; this.t = 0; this.cur = { x: 0, z: 0, r: R0 }; this.showNext = false; this.nx = 0; this.nz = 0; this.nr = 10; this.dmg = 8; }
  inside(x, z) { return Math.hypot(x - this.cur.x, z - this.cur.z) <= this.cur.r; }
  update(dt) { this.t += dt; this.cur.r = this.R0 + (10 - this.R0) * Math.min(1, this.t / 36); }
}
const SHORT = { pistol: 'Pop-9', smg: 'Rattle-X', shotgun: 'Boomer-12', ar: 'Striker-R', sniper: 'Longshot' };

export class RoundMatch extends BaseMatch {
  constructor(o) {
    const c = o.cfg; super({ ...o, half: o.world.mapHalf, cell: 2.5 });
    this.cfg = c; this.type = c.type; this.score = [0, 0]; this.round = 0; this.phase = 'init'; this.phaseT = 0; this.fightT = 0; this.msg = ''; this.ended = false; this.respawns = []; this.lastWinner = -1;
    this.rules = WEAPON_RULES[c.weapons || 'any']; this.fistsOnly = this.rules.length === 0; this.followLeader = false; this.downing = false; this.teamSize = Math.max(c.a, c.b);
    this.player.money = c.money; this.spawnBots(c, o.difficulty || 'normal'); this.begin();
  }
  spawnBots(c, level) {
    const used = new Set(['You']); let id = 0;
    for (const [team, n] of [[0, c.a - 1], [1, c.b]]) for (let i = 0; i < n; i++) {
      const b = new Bot(this, id++, botName(this.rng, used), CHARACTERS[Math.floor(this.rng() * CHARACTERS.length)], team, level);
      if (this.type === 'wolf') b.diff = { ...b.diff, gloo: Math.max(b.diff.gloo, 0.35) };                  // lone wolf bots use gloo walls
      b.state = 'patrol'; b.air = null; b.inPlane = false; b.money = c.money; this.bots.push(b); this.entities.push(b); if (team === 0) b.nameTag();
    }
  }
  slots() { const idx = [0, 0], n = [this.cfg.a, this.cfg.b]; return this.entities.map(e => ({ e, ...this.world.spawnFor(e.team, idx[e.team]++, n[e.team]) })); }
  alive(team) { let n = 0; for (const e of this.entities) if (e.team === team && e.alive) n++; return n; }
  aliveText() { return this.alive(0) + ' v ' + this.alive(1); }
  patrolPoint(b) { const H = this.world.mapHalf, z = (b.team === 0 ? -1 : 1) * H * (0.25 + this.rng() * 0.5); return { x: (this.rng() - 0.5) * H * 1.5, z }; }   // push toward the enemy half
  spectateTarget() { return this.entities.find(e => e.alive && e.team === 0) || this.entities.find(e => e.alive) || null; }

  // ---- loadouts and shop ------------------------------------------------------------------------------------------------------------------
  give(e, id, mags = 2) { const w = WEAPONS[id]; e.weapons.pickupWeapon(id); e.weapons.addAmmo(w.ammo, w.mag * mags); if (e.weapons.pickBest) e.weapons.pickBest(); }
  giveLoadout(e) {
    e.weapons.reset ? e.weapons.reset() : e.weapons.clear(); e.armor = 0; e.helmet = 0; e.items = { medkit: 0, grenade: 0, gloo: 0 }; const r = this.rules, pick = a => a[Math.floor(this.rng() * a.length)];
    if (this.type === 'cs') { if (r.length) this.give(e, r.includes('pistol') ? 'pistol' : r[0]); }
    else if (this.type === 'wolf') { const pri = this.wolfWeapon; if (pri) this.give(e, pri, 4); if (r.includes('pistol') && pri !== 'pistol') this.give(e, 'pistol', 3); e.items.gloo = this.cfg.gloo ? 5 : 0; e.items.medkit = 1; }
    else { const big = r.filter(x => x !== 'pistol'), pri = big.length ? pick(big) : r[0]; if (pri) this.give(e, pri, 6); if (r.includes('pistol') && pri !== 'pistol') this.give(e, 'pistol', 4); e.armor = 1; e.helmet = 1; e.items.medkit = 1; e.items.grenade = 1; e.items.gloo = this.cfg.gloo ? 2 : 0; }
  }
  shopList(e) {                                                  // what the buy menu shows for this player
    const list = [], st = (price, owned, blocked) => blocked ? 'blocked' : owned ? 'owned' : e.money < price ? 'poor' : 'ok';
    for (const id of this.rules) list.push({ key: 'w:' + id, label: SHORT[id], price: SHOP.weapons[id], status: st(SHOP.weapons[id], e.weapons.slots.includes(id)) });
    for (let l = 1; l <= 3; l++) list.push({ key: 'a:' + l, label: 'Armour Lv.' + l, price: SHOP.armor[l], status: st(SHOP.armor[l], e.armor >= l) });
    for (let l = 1; l <= 3; l++) list.push({ key: 'h:' + l, label: 'Helmet Lv.' + l, price: SHOP.helmet[l], status: st(SHOP.helmet[l], e.helmet >= l) });
    list.push({ key: 'medkit', label: 'Medkit', price: SHOP.medkit, status: st(SHOP.medkit, e.items.medkit >= 4) }, { key: 'grenade', label: 'Grenade', price: SHOP.grenade, status: st(SHOP.grenade, e.items.grenade >= 4) });
    if (this.cfg.gloo) list.push({ key: 'gloo', label: 'Gloo wall', price: SHOP.gloo, status: st(SHOP.gloo, e.items.gloo >= 6) }); list.push({ key: 'ammo', label: 'Ammo refill', price: SHOP.ammo, status: st(SHOP.ammo, false, e.weapons.slots.every(s => !s)) });
    return list;
  }
  purchase(e, key) {
    const it = this.shopList(e).find(x => x.key === key); if (!it || it.status !== 'ok') return false; const [k, v] = key.split(':');
    if (k === 'w') this.give(e, v); else if (k === 'a') e.armor = +v; else if (k === 'h') e.helmet = +v; else if (key === 'medkit') e.items.medkit++; else if (key === 'grenade') e.items.grenade++; else if (key === 'gloo') e.items.gloo++;
    else if (key === 'ammo') for (const s of e.weapons.slots) if (s) e.weapons.addAmmo(WEAPONS[s].ammo, WEAPONS[s].mag);
    e.money -= it.price; return true;
  }
  botBuy(b) {                                                    // bots spend their money on the best affordable gear
    const hard = b.levelName === 'hard' || b.levelName === 'pro', order = hard ? ['sniper', 'ar', 'shotgun', 'smg', 'pistol'] : ['ar', 'shotgun', 'smg', 'pistol'];
    for (const id of order) if (this.rules.includes(id) && b.weapons.wants(id) && b.money >= SHOP.weapons[id]) { this.purchase(b, 'w:' + id); break; }
    if (b.money >= SHOP.ammo && b.weapons.slots.some(s => s && b.weapons.reserve[WEAPONS[s].ammo] < WEAPONS[s].mag)) this.purchase(b, 'ammo');
    for (let l = 3; l >= 1; l--) if (b.armor < l && b.money >= SHOP.armor[l]) { this.purchase(b, 'a:' + l); break; }
    for (let l = 3; l >= 1; l--) if (b.helmet < l && b.money >= SHOP.helmet[l]) { this.purchase(b, 'h:' + l); break; }
    if (b.money >= SHOP.medkit && b.items.medkit < 1) this.purchase(b, 'medkit'); if (hard && b.money >= SHOP.grenade) this.purchase(b, 'grenade'); if (this.cfg.gloo && hard && b.money >= SHOP.gloo) this.purchase(b, 'gloo');
  }

  // ---- flow ----------------------------------------------------------------------------------------------------------------------------------------
  begin() { this.type === 'tdm' ? this.startTdm() : this.startRound(); }
  place(first) {                                                 // put everyone on their spawn pads, reset health, give gear
    for (const s of this.slots()) { const e = s.e; e.resetForRound(s, s.yaw); if (first || e.needGear) this.giveLoadout(e); e.needGear = false; e.protectT = 0; }
  }
  startRound() {
    const c = this.cfg, first = this.round === 0; this.round++; this.zone = null; this.sudden = null; this.fightT = 0; this.respawns.length = 0; this.noises.length = 0;
    if (this.type === 'wolf') { const pool = this.rules.filter(x => x !== 'pistol'); this.wolfWeapon = pool.length ? pool[Math.floor(this.rng() * pool.length)] : this.rules[0]; for (const e of this.entities) e.needGear = true; }
    if (!first) for (const e of this.entities) e.money = Math.min(ECONOMY.cap, (e.money || 0) + (e.team === this.lastWinner ? ECONOMY.win : ECONOMY.lose));
    this.place(first); this.player.frozen = true; this.phase = c.type === 'cs' ? 'buy' : 'count'; this.phaseT = c.type === 'cs' ? ECONOMY.buyTime : 4;
    for (const b of this.bots) b.buyAt = 1 + this.rng() * 8;
    this.hud.banner(`ROUND ${this.round}  -  ${this.score[0]} : ${this.score[1]}`, 3000); if (c.type === 'cs') { this.hud.showBuyButton(true); this.hud.openBuy(this); } else this.hud.showBuyButton(false);
  }
  beginFight() { this.phase = 'fight'; this.fightT = 0; this.player.frozen = false; this.hud.closeBuy(); this.hud.banner('FIGHT!', 1500); }
  endRound(win) {
    this.phase = 'end'; this.phaseT = 4; this.lastWinner = win; if (win >= 0) this.score[win]++; for (const e of this.entities) e.needGear = !e.alive || this.type === 'wolf';
    this.hud.banner(win === 0 ? 'ROUND WON!' : win === 1 ? 'ROUND LOST' : 'DRAW', 3500); this.hud.closeBuy(); this.player.frozen = true;
    if (this.score[0] >= this.cfg.rounds || this.score[1] >= this.cfg.rounds) { this.ended = true; setTimeout(() => this.onEnd && this.onEnd(this.score[0] > this.score[1]), 2200); }
  }
  checkRound() {
    const a = this.alive(0), b = this.alive(1);
    if (a === 0 || b === 0) return this.endRound(a === 0 && b === 0 ? -1 : a === 0 ? 1 : 0);
    if (this.fightT >= this.cfg.roundTime) { const hp = t => this.entities.reduce((s, e) => s + (e.team === t && e.alive ? e.hp : 0), 0); this.endRound(a !== b ? (a > b ? 0 : 1) : hp(0) !== hp(1) ? (hp(0) > hp(1) ? 0 : 1) : (this.rng() < 0.5 ? 0 : 1)); }
  }
  startTdm() { this.phase = 'fight'; this.round = 1; this.fightT = 0; this.place(true); this.player.frozen = false; this.hud.showBuyButton(false); this.hud.banner(`First to ${this.cfg.killTarget} kills!`, 3000); }
  afterKill(victim, killer) {
    if (killer && killer !== victim && killer.team !== victim.team) { killer.money = Math.min(ECONOMY.cap, (killer.money || 0) + ECONOMY.kill); if (this.type === 'tdm') this.score[killer.team]++; }
    if (this.type === 'tdm' && !this.ended) {
      this.respawns.push({ e: victim, t: this.t + this.cfg.respawn }); const [a, b] = this.score, T = this.cfg.killTarget;
      if (a >= T || b >= T) { this.ended = true; setTimeout(() => this.onEnd && this.onEnd(a > b), 1500); }
    }
  }
  respawn(e) { const n = [this.cfg.a, this.cfg.b][e.team], s = this.world.spawnFor(e.team, Math.floor(this.rng() * n), n); e.resetForRound({ x: s.x + (this.rng() - 0.5) * 6, y: 0, z: s.z }, s.yaw); this.giveLoadout(e); e.protectT = 2; }

  update(dt, time) {
    if (this.ended && this.type !== 'tdm') { this.t += dt; return; }
    this.phaseT -= dt;
    if (this.phase === 'buy' || this.phase === 'count') {
      const elapsed = ECONOMY.buyTime - this.phaseT; for (const b of this.bots) if (b.buyAt != null && elapsed >= b.buyAt) { if (this.type === 'cs') this.botBuy(b); b.buyAt = null; }
      this.msg = (this.phase === 'buy' ? 'BUY PHASE ' : 'ROUND STARTS IN ') + Math.max(0, Math.ceil(this.phaseT)); if (this.phaseT <= 0) this.beginFight(); this.t += dt; return;
    }
    if (this.phase === 'end') { this.msg = 'ROUND OVER'; this.t += dt; if (this.phaseT <= 0 && !this.ended) this.startRound(); return; }
    super.update(dt, time); this.fightT += dt;
    if (this.type === 'tdm') {
      const left = Math.max(0, this.cfg.timeLimit - this.fightT); this.msg = `TDM  ${this.score[0]} : ${this.score[1]}  -  ${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, '0')}`;
      for (let i = this.respawns.length - 1; i >= 0; i--) if (this.t >= this.respawns[i].t) { this.respawn(this.respawns[i].e); this.respawns.splice(i, 1); }
      if (!this.ended && left <= 0) { this.ended = true; this.onEnd && this.onEnd(this.score[0] > this.score[1]); } return;
    }
    const left = Math.max(0, this.cfg.roundTime - this.fightT); this.msg = `ROUND ${this.round}   ${this.score[0]} : ${this.score[1]}   ${Math.floor(left / 60)}:${String(Math.floor(left % 60)).padStart(2, '0')}`;
    if (!this.zone && left <= 40) { this.zone = new SuddenZone(this.world.mapHalf * 0.9); this.hud.banner('The circle is closing!', 2500); }
    if (this.zone) { this.zone.update(dt); this.zoneT = (this.zoneT || 0) + dt; if (this.zoneT >= 1) { this.zoneT -= 1; for (const e of this.entities) if (e.alive && !this.zone.inside(e.pos.x, e.pos.z)) e.takeHit(this.zone.dmg, 'torso', false, null); } }
    this.checkRound();
  }
}
