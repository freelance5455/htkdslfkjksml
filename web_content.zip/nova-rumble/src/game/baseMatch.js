// Shared match logic for EVERY mode: entities (you + bots), teams, spatial hash, noise, bullets, grenades, gloo walls, kills.
// BrMatch (battle royale) and RoundMatch (CS Rank, Lone Wolf, Team Deathmatch, Custom) extend this.
import * as THREE from 'three';
import { NavGrid } from '../ai/navgrid.js';
import { NOISE_RADIUS } from '../data/bots.js';
import { ARMOR_REDUCE } from '../data/weapons.js';
import { rayVsEntity } from './hitbox.js';
import { calcDamage } from './damage.js';
import { toon } from './characterModel.js';
import { audio } from '../audio/audio.js';

const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) / 0.5;
export class BaseMatch {
  constructor(o) {
    Object.assign(this, { scene: o.scene, world: o.world, loot: o.loot || null, hud: o.hud, player: o.player, zone: o.zone || null, plane: o.plane || null, rng: o.rng, teamSize: o.teamSize || 1, onEnd: o.onEnd });
    this.downing = false; this.followLeader = true; this.fistsOnly = false;          // downed/revive (squads), bots follow their leader, fists-only rule
    this.t = 0; this.noises = []; this.bots = []; this.entities = [this.player]; this.hash = new Map(); this.pathBudget = 1; this.grenades = []; this.walls = []; this.booms = [];
    this.player.team = 0; this.player.name = 'You'; this.player.isPlayer = true; this.world.match = this; this.world.targets = this.bots;
    this.nav = new NavGrid(o.half || 500, o.cell || 5); this.nav.build(this.world.colliders, (x, z) => this.world.heightAt(x, z));
    this.tracers = Array.from({ length: 24 }, () => { const m = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 1), new THREE.MeshBasicMaterial({ color: 0xffb36b, transparent: true })); m.visible = false; this.scene.add(m); return { m, t: 0 }; }); this.ti = 0;
  }
  // ---- queries -------------------------------------------------------------------------------------------------------------
  distToPlayer(b) { return Math.hypot(b.pos.x - this.player.pos.x, b.pos.z - this.player.pos.z); }
  takePathBudget() { if (this.pathBudget > 0) { this.pathBudget--; return true; } return false; }
  rebuildHash() { this.hash.clear(); for (const e of this.entities) { if (!e.alive || e.hidden || e.air) continue; const k = this._k(e.pos.x, e.pos.z); let a = this.hash.get(k); if (!a) this.hash.set(k, a = []); a.push(e); } }
  _k(x, z) { return (Math.floor(x / 40) + 50) * 200 + Math.floor(z / 40) + 50; }
  nearEnemies(b, r) {
    const out = [], c = Math.ceil(r / 40), cx = Math.floor(b.pos.x / 40), cz = Math.floor(b.pos.z / 40);
    for (let ix = cx - c; ix <= cx + c; ix++) for (let iz = cz - c; iz <= cz + c; iz++) { const a = this.hash.get((ix + 50) * 200 + iz + 50); if (a) for (const e of a) if (e.team !== b.team) out.push(e); }
    return out;
  }
  aliveCount() { let n = 0; for (const e of this.entities) if (e.alive) n++; return n; }
  canDown(e) { return this.downing && this.entities.some(m => m !== e && m.team === e.team && m.alive && !m.downed); }
  downedMate(b) { let best = null, bd = 60; for (const e of this.entities) if (e !== b && e.team === b.team && e.alive && e.downed) { const d = Math.hypot(e.pos.x - b.pos.x, e.pos.z - b.pos.z); if (d < bd) { bd = d; best = e; } } return best; }
  leaderOf(b) {                                                       // team 0 follows you; other squads follow their first living member
    if (this.teamSize < 2) return null; if (b.team === 0) return this.player.alive && !this.player.downed ? this.player : null;
    for (const e of this.bots) if (e.team === b.team && e.alive && !e.downed) return e === b ? null : e; return null;
  }
  shareEnemy(b, enemy) { for (const t of this.bots) if (t !== b && t.team === b.team && t.alive && !t.downed && !t.enemy && Math.hypot(t.pos.x - b.pos.x, t.pos.z - b.pos.z) < 80) t.heard = { x: enemy.pos.x, z: enemy.pos.z, t: this.t }; }
  aliveTeams() { const t = new Set(); for (const e of this.entities) if (e.alive) t.add(e.team); return t.size; }
  startRevive(p) {                                                    // player taps PICK UP next to a downed teammate
    let best = null, bd = 3.2; for (const e of this.entities) if (e !== p && e.team === p.team && e.alive && e.downed) { const d = Math.hypot(e.pos.x - p.pos.x, e.pos.z - p.pos.z); if (d < bd) { bd = d; best = e; } }
    if (!best) return false; p.reviving = { target: best, t: 0 }; return true;
  }
  nearDownedMate(p) { for (const e of this.entities) if (e !== p && e.team === p.team && e.alive && e.downed && Math.hypot(e.pos.x - p.pos.x, e.pos.z - p.pos.z) < 3.2) return e; return null; }
  mates() { return this.entities.filter(e => e !== this.player && e.team === this.player.team && e.alive).map(e => ({ x: e.pos.x, z: e.pos.z, downed: e.downed })); }

  // ---- combat -------------------------------------------------------------------------------------------------------------------
  shoot(shooter, o, dir, w) {
    const pp = this.player.pos, dist = Math.hypot(shooter.pos.x - pp.x, shooter.pos.z - pp.z), vol = Math.max(0, 1 - dist / 170);
    if (vol > 0.04) audio.gun(w.id, vol * 0.8);
    this.noises.push({ x: shooter.pos.x, z: shooter.pos.z, r: NOISE_RADIUS[w.id] || 60, team: shooter.team, owner: shooter, t: this.t });
    for (let i = 0; i < w.pellets; i++) {
      let d = dir; if (w.pellets > 1) { d = dir.clone(); d.x += gauss() * w.spread * 0.7; d.y += gauss() * w.spread * 0.7; d.z += gauss() * w.spread * 0.7; d.normalize(); }
      this.bulletTrace(shooter, o, d, w, dist < 160);
    }
  }
  bulletTrace(shooter, o, d, w, draw) {
    const maxT = w.range + 5; let best = this.world.raycast(o, d, maxT), hit = null;
    for (const e of this.entities) {
      if (!e.alive || e === shooter || e.team === shooter.team || e.hidden || e.air) continue;
      const dx = e.pos.x - o.x, dy = e.pos.y + 1 - o.y, dz = e.pos.z - o.z, t = dx * d.x + dy * d.y + dz * d.z; if (t < 0 || t > best + 2) continue; if (dx * dx + dy * dy + dz * dz - t * t > 6) continue;
      const h = rayVsEntity(o, d, best, e); if (h && h.t < best) { best = h.t; hit = { e, part: h.part }; }
    }
    if (draw) this.tracer(o.clone().addScaledVector(d, 0.8), o.clone().addScaledVector(d, best));
    if (hit) { const r = calcDamage(w.damage, hit.part, shooter.pos.distanceTo(hit.e.pos), w, hit.e.armor, hit.e.helmet); hit.e.takeHit(r.dmg, hit.part, r.head, shooter); }
  }
  melee(b, t) { if (t && t.alive && Math.hypot(t.pos.x - b.pos.x, t.pos.z - b.pos.z) < 2.3) t.takeHit(14, 'torso', false, b); }
  tracer(a, b) { const t = this.tracers[this.ti++ % this.tracers.length], len = a.distanceTo(b); if (len < 1) return; t.m.position.copy(a).lerp(b, 0.5); t.m.scale.z = len; t.m.lookAt(b); t.m.visible = true; t.t = 0.07; }
  explosion(pos, owner, r, dmg) {
    this.noises.push({ x: pos.x, z: pos.z, r: 70, team: owner ? owner.team : -1, owner, t: this.t });
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.8, 10, 8), new THREE.MeshBasicMaterial({ color: 0xffb02e, transparent: true, opacity: 0.8 })); m.position.copy(pos); this.scene.add(m); this.booms.push({ m, t: 0 });
    const dp = Math.hypot(pos.x - this.player.pos.x, pos.z - this.player.pos.z); if (dp < 120) audio.tone(90, 0.5, 'sawtooth', 0.35 * (1 - dp / 120), null, 0, 35);
    for (const e of this.entities) {
      if (!e.alive || e.air || e.hidden) continue; if (owner && e.team === owner.team && e !== owner) continue;
      const d = Math.hypot(e.pos.x - pos.x, e.pos.y + 1 - pos.y, e.pos.z - pos.z); if (d > r) continue;
      let k = dmg * (1 - d / r) * (1 - ARMOR_REDUCE[e.armor || 0]); if (e === owner) k *= 0.5; e.takeHit(Math.max(1, Math.round(k)), 'torso', false, owner);
    }
  }
  throwGrenade(owner, to) {
    const from = new THREE.Vector3(owner.pos.x, owner.pos.y + 1.5, owner.pos.z), T = 1.3, g = 20, tgt = new THREE.Vector3(to.x + gauss() * 3, to.y ?? this.world.heightAt(to.x, to.z), to.z + gauss() * 3);
    const v = tgt.clone().sub(from).divideScalar(T); v.y += 0.5 * g * T; owner.items.grenade--;
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), toon(0x333a4d)); this.scene.add(m); m.position.copy(from); this.grenades.push({ m, v, t: T, owner });
  }
  placeGloo(owner, dx, dz) {                                          // instant ice wall between us and the enemy
    if (owner.items.gloo <= 0) return; owner.items.gloo--; const len = Math.hypot(dx, dz) || 1, fx = dx / len, fz = dz / len, x = owner.pos.x + fx * 2.2, z = owner.pos.z + fz * 2.2, alongX = Math.abs(fz) > Math.abs(fx), w = alongX ? 3.2 : 0.4, d = alongX ? 0.4 : 3.2, h = 2.4, y = owner.pos.y;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshToonMaterial({ color: 0x7ee7ff, transparent: true, opacity: 0.8 })); mesh.position.set(x, y + h / 2, z); mesh.scale.y = 0.05; this.scene.add(mesh);
    this.walls.push({ mesh, col: this.world.addCollider(x - w / 2, x + w / 2, y, y + h, z - d / 2, z + d / 2), t: 0 });
  }
  dropLoot(b) {}                                                      // battle royale overrides: eliminated players leave a loot box
  onKill(victim, killer, head) {
    this.hud.killFeed(killer ? (killer.isPlayer ? 'You' : killer.name) : 'The Storm', victim.isPlayer ? 'You' : victim.name, head);
    if (killer && killer !== victim) { if (killer.isPlayer) killer.addKill(victim.name, head); else killer.kills++; }
    this.afterKill(victim, killer);
  }
  afterKill(victim, killer) {}

  // ---- per frame (shared part) ------------------------------------------------------------------------------------------------------
  update(dt, time) {
    this.t += dt; this.pathBudget = 1; this.rebuildHash();
    for (const b of this.bots) b.update(dt, time);
    while (this.noises.length && this.t - this.noises[0].t > 2.5) this.noises.shift();
    this.footT = (this.footT ?? 0) - dt; if (this.footT <= 0) { this.footT = 0.6; for (const e of this.entities) { if (!e.alive || e.air || e.hidden || e.downed) continue; const sp = e.speed; if (sp > 5 && e.stance === 'stand') this.noises.push({ x: e.pos.x, z: e.pos.z, r: 24, team: e.team, owner: e, t: this.t }); else if (sp > 2 && e.stance === 'stand') this.noises.push({ x: e.pos.x, z: e.pos.z, r: 11, team: e.team, owner: e, t: this.t }); } }
    for (const t of this.tracers) if (t.m.visible) { t.t -= dt; t.m.material.opacity = Math.max(0, t.t / 0.07); if (t.t <= 0) t.m.visible = false; }
    for (let i = this.grenades.length - 1; i >= 0; i--) { const g = this.grenades[i]; g.t -= dt; g.v.y -= 20 * dt; g.m.position.addScaledVector(g.v, dt); if (g.t <= 0) { this.explosion(g.m.position.clone(), g.owner, 6, 90); this.scene.remove(g.m); this.grenades.splice(i, 1); } }
    for (let i = this.booms.length - 1; i >= 0; i--) { const b = this.booms[i]; b.t += dt; const k = b.t / 0.45; b.m.scale.setScalar(1 + k * 6); b.m.material.opacity = 0.8 * (1 - k); if (k >= 1) { this.scene.remove(b.m); this.booms.splice(i, 1); } }
    for (let i = this.walls.length - 1; i >= 0; i--) { const w = this.walls[i]; w.t += dt; w.mesh.scale.y = Math.min(1, w.mesh.scale.y + dt * 5); if (w.t > 20) { this.world.removeCollider(w.col); this.scene.remove(w.mesh); this.walls.splice(i, 1); } }
  }
}
