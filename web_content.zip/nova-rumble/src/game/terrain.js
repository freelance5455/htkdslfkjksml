// Pure terrain math (no three.js): height, river, colours, roads. Shared by the mesh, the minimap image and the physics.
import { MAP, LOCATIONS, HILLS, FIELDS, ROAD_LINKS } from '../data/map.js';
const sm = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
export const riverX = z => -140 + 90 * Math.sin(z / 240 + 1);
export const riverDist = (x, z) => Math.abs(x - riverX(z));

function raw(x, z) {                                  // rolling land + gaussian hills
  let h = 1.2 * Math.sin(x / 70) * Math.cos(z / 90) + 0.8 * Math.sin((x + z) / 37) + 0.6;
  for (const [hx, hz, r, H] of HILLS) { const s = r / 2.2, d2 = (x - hx) ** 2 + (z - hz) ** 2; h += H * Math.exp(-d2 / (2 * s * s)); }
  return h;
}
const FLAT = LOCATIONS.map(L => (L.type === 'hill' ? raw(L.x, L.z) : 0.25));
export function heightAt(x, z) {
  let h = raw(x, z);
  for (let i = 0; i < LOCATIONS.length; i++) {        // flatten building areas
    const L = LOCATIONS[i], d = Math.hypot(x - L.x, z - L.z); if (d > L.r * 1.3) continue;
    const f = sm(L.r * 0.75, L.r * 1.3, d); h = FLAT[i] + (h - FLAT[i]) * f;
  }
  const t = 1 - sm(6, MAP.riverW * 0.5 + 14, riverDist(x, z)); h = h * (1 - t) + (-1.15) * t;   // river bed
  const e = Math.max(Math.abs(x), Math.abs(z)) - 495; if (e > 0) h -= e * 0.07;                   // slope into the sea at the edges
  h -= sm(440, 480, z) * 3.5;                                                                     // southern sea
  return h;
}
export const inWater = (x, z) => heightAt(x, z) < MAP.waterY + 0.05;

const C = { grass1: [0.36, 0.78, 0.42], grass2: [0.31, 0.72, 0.38], sand: [0.84, 0.77, 0.55], wheat1: [0.93, 0.78, 0.28], wheat2: [0.86, 0.7, 0.24], rock: [0.62, 0.52, 0.4], dirt: [0.6, 0.45, 0.3] };
export function inField(x, z) { for (const [fx, fz, w, d] of FIELDS) if (Math.abs(x - fx) < w / 2 && Math.abs(z - fz) < d / 2) return true; return false; }
export function colorAt(x, z, h) {
  if (h < MAP.waterY + 0.6) return C.sand;
  if (inField(x, z)) return (Math.floor(x / 5) + Math.floor(z / 5)) % 2 ? C.wheat1 : C.wheat2;
  if (h > 11) return C.rock; if (h > 8.5) return C.dirt;
  return (Math.sin(x / 23) * Math.cos(z / 19) > 0.2) ? C.grass2 : C.grass1;
}

// Road polylines (curved links between locations) built from a seeded rng so the map is always the same.
export function buildRoads(rng) {
  const roads = [];
  for (const [a, b] of ROAD_LINKS) {
    const A = LOCATIONS.find(l => l.id === a), B = LOCATIONS.find(l => l.id === b), dx = B.x - A.x, dz = B.z - A.z, len = Math.hypot(dx, dz);
    const off = (rng() - 0.5) * len * 0.25, mx = (A.x + B.x) / 2 - dz / len * off, mz = (A.z + B.z) / 2 + dx / len * off, pts = [];
    for (let i = 0; i <= 16; i++) { const t = i / 16, u = 1 - t; pts.push([u * u * A.x + 2 * u * t * mx + t * t * B.x, u * u * A.z + 2 * u * t * mz + t * t * B.z]); }
    roads.push(pts);
  }
  return roads;
}
export function nearRoad(roads, x, z, dist) {
  for (const r of roads) for (let i = 0; i < r.length - 1; i++) {
    const [x1, z1] = r[i], [x2, z2] = r[i + 1], vx = x2 - x1, vz = z2 - z1, t = Math.max(0, Math.min(1, ((x - x1) * vx + (z - z1) * vz) / (vx * vx + vz * vz)));
    if (Math.hypot(x - (x1 + vx * t), z - (z1 + vz * t)) < dist) return true;
  }
  return false;
}
export function mulberry(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
