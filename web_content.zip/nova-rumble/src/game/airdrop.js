// Plane (used for the match start and for airdrop fly-overs) and the airdrop crate with parachute + red smoke.
import * as THREE from 'three';
import { toon, outline } from './characterModel.js';

export function buildPlane() {
  const g = new THREE.Group(), b = (geo, c, x, y, z) => { const m = new THREE.Mesh(geo, toon(c)); m.position.set(x, y, z); outline(m, 1.06); g.add(m); return m; };
  const body = b(new THREE.CapsuleGeometry(1.5, 8, 4, 10), 0x8a3ffc, 0, 0, 0); body.rotation.x = Math.PI / 2;
  b(new THREE.BoxGeometry(18, 0.35, 3.2), 0xffd23f, 0, 0.3, 0.5); b(new THREE.BoxGeometry(6, 0.3, 1.8), 0xffd23f, 0, 0.3, -5); b(new THREE.BoxGeometry(0.35, 2.6, 2), 0xff8a1f, 0, 1.4, -5);
  b(new THREE.SphereGeometry(1.1, 10, 8), 0x22d3ee, 0, 0.9, 1.8);
  g.prop = b(new THREE.BoxGeometry(4.2, 0.25, 0.25), 0xffffff, 0, 0, 5.4); g.scale.setScalar(1.7); return g;
}
export class Plane {
  constructor(scene, start, end, speed, alt) {
    this.scene = scene; this.a = start; this.b = end; this.speed = speed; this.alt = alt; this.len = Math.hypot(end.x - start.x, end.z - start.z); this.t = 0; this.done = false;
    this.dir = { x: (end.x - start.x) / this.len, z: (end.z - start.z) / this.len }; this.pos = new THREE.Vector3(start.x, alt, start.z);
    this.group = buildPlane(); this.group.rotation.y = Math.atan2(this.dir.x, this.dir.z); scene.add(this.group); this.group.position.copy(this.pos);
  }
  update(dt) {
    this.t += this.speed * dt; const k = Math.min(1, this.t / this.len); this.pos.set(this.a.x + (this.b.x - this.a.x) * k, this.alt, this.a.z + (this.b.z - this.a.z) * k);
    this.group.position.copy(this.pos); this.group.prop.rotation.z += dt * 40; this.done = k >= 1;
  }
  remove() { this.scene.remove(this.group); }
}

// Falls by parachute, lands, then waits to be opened (the loot manager owns the pickup logic). Red smoke marks it.
export class Airdrop {
  constructor(world, x, z, y0) {
    this.world = world; this.scene = world.scene; this.x = x; this.z = z; this.ground = world.heightAt(x, z) + 0.7; this.y = y0; this.landed = false; this.opened = false; this.t = 0;
    this.g = new THREE.Group(); const crate = new THREE.Mesh(new THREE.BoxGeometry(1.8, 1.4, 1.8), toon(0x7c3aed)); outline(crate, 1.06); this.g.add(crate);
    const band = new THREE.Mesh(new THREE.BoxGeometry(1.86, 0.3, 1.86), toon(0xffc933)); this.g.add(band);
    this.chute = new THREE.Group(); const dome = new THREE.Mesh(new THREE.SphereGeometry(3.4, 14, 8, 0, 6.2832, 0, Math.PI / 2), new THREE.MeshToonMaterial({ color: 0xff3b3b, side: THREE.DoubleSide })); dome.position.y = 5.5; this.chute.add(dome);
    const pts = []; for (let i = 0; i < 4; i++) { const a = i * 1.5708 + 0.78; pts.push(new THREE.Vector3(Math.cos(a) * 3.3, 5.5, Math.sin(a) * 3.3), new THREE.Vector3(Math.cos(a) * 0.7, 0.7, Math.sin(a) * 0.7)); }
    this.chute.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(pts), new THREE.LineBasicMaterial({ color: 0xffffff }))); this.g.add(this.chute);
    this.g.position.set(x, y0, z); this.scene.add(this.g);
    this.smoke = Array.from({ length: 12 }, (_, i) => { const m = new THREE.Mesh(new THREE.SphereGeometry(1, 6, 5), new THREE.MeshBasicMaterial({ color: 0xff2d2d, transparent: true, opacity: 0.6, depthWrite: false })); m.userData.ph = i / 12; this.scene.add(m); return m; });
  }
  update(dt) {
    this.t += dt;
    if (!this.landed) { this.y -= 8 * dt; if (this.y <= this.ground) { this.y = this.ground; this.landed = true; this.chute.visible = false; } this.g.position.y = this.y; this.g.rotation.z = Math.sin(this.t * 1.5) * 0.06; }
    const base = Math.max(this.y, this.ground);
    for (const m of this.smoke) {                           // rising red smoke column (stays after landing so it can be followed)
      const p = (this.t * 0.12 + m.userData.ph) % 1; m.position.set(this.x + Math.sin(p * 9 + m.userData.ph * 20) * 1.2, base + p * 70, this.z + Math.cos(p * 7) * 1.2); m.scale.setScalar(1 + p * 5); m.material.opacity = 0.6 * (1 - p) * (this.opened ? 0.3 : 1);
    }
  }
  open() { this.opened = true; this.g.visible = false; }
  dispose() { this.scene.remove(this.g); this.smoke.forEach(m => this.scene.remove(m)); }
}
