// Training dummies: they stand or strafe so you can practise aiming and headshots. (Real bot AI arrives in Phase 5.)
// Every enemy exposes the same interface the weapon system needs: pos, stance, alive, armor, helmet, name, takeHit().
import * as THREE from 'three';
import { buildCharacter } from './characterModel.js';
import { CHARACTERS } from '../data/characters.js';

const SETUP = [   // x, z, helmet, armor, strafe amplitude (0 = stand still), name
  [-6, -16, 0, 0, 0, 'Bob'], [6, -20, 1, 0, 4, 'Dot'], [0, -30, 2, 1, 0, 'Rex'],
  [-14, -40, 3, 2, 5, 'Mo'], [14, -52, 0, 0, 0, 'Zed'], [0, -85, 1, 0, 0, 'Pam'], [22, 8, 0, 0, 6, 'Fizz']
];
export class Target {
  constructor(scene, x, z, helmet, armor, amp, name, i) {
    this.scene = scene; this.home = new THREE.Vector3(x, 0, z); this.pos = this.home.clone(); this.stance = 'stand';
    this.helmet = helmet; this.armor = armor; this.amp = amp; this.name = name; this.maxHp = 120; this.hp = 120; this.alive = true; this.deadT = 0; this.phase = i * 1.7;
    const def = { ...CHARACTERS[(i % 3) + 1], top: [0xff4d2e, 0x15c5a5, 0xffd23f][i % 3] };       // enemy colours differ from the player
    this.model = buildCharacter(def); this.root = new THREE.Group(); this.root.add(this.model.group); scene.add(this.root);
    this.model.group.traverse(o => { if (o.isMesh && !o.material.side) o.castShadow = true; });
    this.bar = document.createElement('canvas'); this.bar.width = 160; this.bar.height = 40;
    this.sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(this.bar), transparent: true, depthTest: false }));
    this.sprite.scale.set(1.5, 0.375, 1); this.sprite.position.y = 2.75; this.root.add(this.sprite); this._drawBar();
  }
  _drawBar() {
    const g = this.bar.getContext('2d'); g.clearRect(0, 0, 160, 40); g.fillStyle = '#0009'; g.fillRect(0, 14, 160, 22);
    g.fillStyle = this.hp / this.maxHp > 0.4 ? '#4ade80' : '#ef4444'; g.fillRect(3, 17, 154 * Math.max(0, this.hp) / this.maxHp, 16);
    g.fillStyle = '#fff'; g.font = 'bold 14px Arial'; g.textAlign = 'center'; g.fillText(`${this.name}  🛡${this.armor} ⛑${this.helmet}`, 80, 11);
    this.sprite.material.map.needsUpdate = true;
  }
  // returns true if this hit killed the target
  takeHit(dmg) {
    if (!this.alive) return false; this.hp -= dmg; this._drawBar();
    if (this.hp <= 0) { this.alive = false; this.deadT = 0; this.sprite.visible = false; return true; }
    return false;
  }
  update(dt, time, player) {
    if (!this.alive) {                                                    // fall over, then respawn after 4 s
      this.deadT += dt; this.model.group.rotation.x = Math.min(1.5, this.deadT * 4) * -1; this.root.position.y = 0.25;
      if (this.deadT > 4) { this.alive = true; this.hp = this.maxHp; this.model.group.rotation.x = 0; this.root.position.y = 0; this.sprite.visible = true; this._drawBar(); }
      return;
    }
    const P = this.model.parts;
    if (this.amp > 0) {                                                   // strafe left/right
      const nx = this.home.x + Math.sin(time * 0.7 + this.phase) * this.amp, vx = (nx - this.pos.x) / Math.max(dt, 1e-3); this.pos.x = nx;
      const sw = Math.sin(time * 9) * 0.7; P.legL.rotation.x = sw; P.legR.rotation.x = -sw;
    } else this.model.update(time);
    this.root.position.x = this.pos.x; this.root.position.z = this.pos.z;
    const dx = player.pos.x - this.pos.x, dz = player.pos.z - this.pos.z; this.root.rotation.y = Math.atan2(dx, dz);   // face the player
  }
}
export class TargetManager {
  constructor(world) {
    this.list = []; world.targets = this.list;
    SETUP.forEach((s, i) => this.list.push(new Target(world.scene, s[0], s[1], s[2], s[3], s[4], s[5], i)));
  }
  update(dt, time, player) { for (const t of this.list) t.update(dt, time, player); }
}
