// One place for the damage formula (used by the player now, by bots in Phase 5).
import { HEAD_MULT, TORSO_MULT, LIMB_MULT, HELMET_REDUCE, ARMOR_REDUCE } from '../data/weapons.js';
export function calcDamage(base, part, dist, w, armor = 0, helmet = 0) {
  const head = part === 'head';
  let d = base * (head ? HEAD_MULT : part === 'torso' ? TORSO_MULT : LIMB_MULT);
  const half = w.range * 0.5;                                       // full damage up to half range, then linear falloff
  if (dist > half) d *= 1 - (1 - w.falloff) * Math.min(1, (dist - half) / half);
  d *= 1 - (head ? HELMET_REDUCE[helmet] : ARMOR_REDUCE[armor]);
  return { dmg: Math.max(1, Math.round(d)), head };
}
