// Walking physics for bots (same rules as the player: steps up to 0.5 m, climb low obstacles, slopes, gravity). No three.js.
export const MV = { gravity: 22, radius: 0.35, step: 0.5, climb: 1.3, jump: 7.8 };
export function groundAt(world, x, z, feetY) {
  let g = world.heightAt(x, z); const r = MV.radius * 0.6;
  for (const b of world.nearColliders(x, z, r + 0.2)) if (x > b.minX - r && x < b.maxX + r && z > b.minZ - r && z < b.maxZ + r && b.maxY <= feetY + MV.step + 0.001 && b.maxY > g) g = b.maxY;
  return g;
}
export function tryMove(world, e, dx, dz, climb) {
  if (!dx && !dz) return true; const p = e.pos, h = e.height || 1.9, nx = p.x + dx, nz = p.z + dz, r = MV.radius;
  for (const b of world.nearColliders(nx, nz, r + 0.2)) {
    if (nx > b.minX - r && nx < b.maxX + r && nz > b.minZ - r && nz < b.maxZ + r) {
      if (p.y + h <= b.minY + 0.01 || p.y >= b.maxY - 0.01) continue; const rise = b.maxY - p.y;
      if (rise <= MV.step) continue; if (rise <= MV.climb && climb) { p.y = b.maxY; e.vel.y = 0; continue; } return false;
    }
  }
  p.x = nx; p.z = nz; return true;
}
// advance one frame toward the wish velocity (wx,wz). Sets e.blocked when a wall stopped us.
export function step(world, e, dt, wx, wz, climb = false) {
  const a = Math.min(1, dt * (e.grounded ? 10 : 3)); e.vel.x += (wx - e.vel.x) * a; e.vel.z += (wz - e.vel.z) * a;
  const ok1 = tryMove(world, e, e.vel.x * dt, 0, climb), ok2 = tryMove(world, e, 0, e.vel.z * dt, climb); e.blocked = !(ok1 && ok2);
  const prev = e.pos.y; e.vel.y -= MV.gravity * dt; e.pos.y += e.vel.y * dt; const g = groundAt(world, e.pos.x, e.pos.z, prev);
  if (e.pos.y <= g) { e.pos.y = g; e.vel.y = 0; e.grounded = true; } else if (e.grounded && e.vel.y <= 0 && e.pos.y - g < 0.45) { e.pos.y = g; e.vel.y = 0; } else e.grounded = false;
}
export function unstick(world, e) {                              // after landing: slide out of walls/props if we ended up inside one
  const inside = (x, z) => world.nearColliders(x, z, 1).some(b => x > b.minX - MV.radius && x < b.maxX + MV.radius && z > b.minZ - MV.radius && z < b.maxZ + MV.radius && e.pos.y + 1.5 > b.minY && e.pos.y < b.maxY - 0.3);
  if (!inside(e.pos.x, e.pos.z)) return;
  for (let r = 1; r <= 10; r += 1) for (let a = 0; a < 12; a++) { const x = e.pos.x + Math.cos(a * 0.5236) * r, z = e.pos.z + Math.sin(a * 0.5236) * r; if (!inside(x, z)) { e.pos.x = x; e.pos.z = z; e.pos.y = groundAt(world, x, z, e.pos.y + 3); return; } }
}
