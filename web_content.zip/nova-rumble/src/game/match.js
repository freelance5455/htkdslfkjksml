// Battle royale match: 49 bots drop with you, the zone shrinks, last team standing wins. Extends the shared BaseMatch.
import * as THREE from 'three';
import { BaseMatch } from './baseMatch.js';
import { Bot } from '../ai/bot.js';
import { CHARACTERS } from '../data/characters.js';
import { botName } from '../data/bots.js';
import { LOCATIONS } from '../data/map.js';
import { WEAPONS } from '../data/weapons.js';

export class BrMatch extends BaseMatch {
  constructor(o) {
    super({ ...o, half: 500, cell: 5 }); this.downing = this.teamSize > 1; this.ended = false; this.playerJumped = false; this.stormT = 0;
    this.spawnBots(o.botCount ?? 49, o.difficulty || 'normal');
  }
  spawnBots(count, level) {
    const used = new Set(['You']), size = this.teamSize; let team = 0, inTeam = 1;                          // player is on team 0
    for (let i = 0; i < count; i++) {
      if (inTeam >= size) { team++; inTeam = 0; } inTeam++;
      const b = new Bot(this, i, botName(this.rng, used), CHARACTERS[Math.floor(this.rng() * CHARACTERS.length)], team, level); this.bots.push(b); this.entities.push(b);
      b.target = null; this.planDrop(b); if (team === 0) { b.nameTag(); b.follow = this.player; b.offX = (this.rng() - 0.5) * 24; b.offZ = (this.rng() - 0.5) * 24; b.jumpAt = 1e9; }
    }
  }
  planDrop(b) {                                                       // pick a landing area the plane line can reach, jump when close
    const pl = this.plane, a = pl.a, dx = pl.dir.x, dz = pl.dir.z, rng = this.rng, c = [];
    for (const L of LOCATIONS) { const px = L.x - a.x, pz = L.z - a.z; if (Math.abs(px * -dz + pz * dx) < 190) c.push({ x: L.x + (rng() - 0.5) * L.r, z: L.z + (rng() - 0.5) * L.r }); }
    let T; if (c.length && rng() < 0.8) T = c[Math.floor(rng() * c.length)]; else { const k = 150 + rng() * (pl.len - 300), off = (rng() - 0.5) * 260; T = { x: a.x + dx * k - dz * off, z: a.z + dz * k + dx * off }; }
    b.target = { x: Math.max(-470, Math.min(470, T.x)), z: Math.max(-470, Math.min(470, T.z)) }; const along = (b.target.x - a.x) * dx + (b.target.z - a.z) * dz; b.jumpAt = Math.max(30, Math.min(pl.len - 60, along - 60 - rng() * 90));
  }

  dropLoot(b) {                                                       // an eliminated player leaves a loot box
    const s = [], W = b.weapons; W.slots.forEach(id => id && s.push({ kind: 'weapon', id })); if (b.armor) s.push({ kind: 'armor', level: b.armor }); if (b.helmet) s.push({ kind: 'helmet', level: b.helmet });
    for (let i = 0; i < Math.min(2, b.items.medkit); i++) s.push({ kind: 'medkit' }); if (b.items.grenade) s.push({ kind: 'grenade' }); const prim = W.slots.find(Boolean); if (prim) s.push({ kind: 'ammo', id: WEAPONS[prim].ammo });
    if (s.length) this.loot.addBox(b.pos.x, this.world.heightAt(b.pos.x, b.pos.z) + 0.1 + (b.pos.y - this.world.heightAt(b.pos.x, b.pos.z) > 2 ? b.pos.y - this.world.heightAt(b.pos.x, b.pos.z) : 0), b.pos.z, s);
  }
  afterKill() { this.checkEnd(); }
  checkEnd() {
    if (this.ended) return; const teams = new Set(); for (const e of this.entities) if (e.alive) teams.add(e.team);
    if (teams.size <= 1) { this.ended = true; this.onEnd && this.onEnd(teams.has(0)); }
  }

  update(dt, time) {
    const pl = this.plane;
    if (!this.playerJumped && this.player.air !== 'plane') {                      // teammates jump right after you
      this.playerJumped = true; for (const b of this.bots) if (b.team === 0 && b.state === 'drop' && b.air === 'plane') b.jumpAt = pl ? pl.t + 0.3 + this.rng() * 1.5 : 0;
    }
    super.update(dt, time);
    this.stormT += dt; if (this.stormT >= 1) { this.stormT -= 1; for (const b of this.bots) if (b.alive && !b.air && !this.zone.inside(b.pos.x, b.pos.z)) b.takeHit(this.zone.dmg, 'torso', false, null); }
  }
}
