// Loot on the big map: every loot point holds an item or a crate, drawn with instanced meshes (a few draw calls for hundreds of items).
// Tap PICK UP / press E to take weapons, armour, helmets, backpacks and items. Ammo is picked up automatically.
import * as THREE from 'three';
import { roll, rarityOf, RARITY_COLORS, CAPS } from '../data/loot.js';
import { WEAPON_RANK } from '../data/bots.js';
import { WEAPONS, AMMO_PICKUP } from '../data/weapons.js';
import { audio } from '../audio/audio.js';
import { mulberry } from './terrain.js';

export class LootManager {
  constructor(world, hud, seed) {
    this.world = world; this.hud = hud; this.rng = mulberry(seed + 99); this.items = []; this.near = null; this.dirty = true;
    const cap = world.lootPoints.length + 500, scene = world.scene;
    this.boxes = new THREE.InstancedMesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), new THREE.MeshToonMaterial({ color: 0xffffff }), cap);
    this.beams = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2, 5), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false }), cap);
    this.crates = new THREE.InstancedMesh(new THREE.BoxGeometry(1.1, 0.9, 1.1), new THREE.MeshToonMaterial({ color: 0xffffff }), cap);
    [this.boxes, this.beams, this.crates].forEach(m => { m.frustumCulled = false; m.count = 0; scene.add(m); });
    this.free = []; this.cap = cap; this.used = 0; this._m = new THREE.Matrix4(); this._q = new THREE.Quaternion(); this._c = new THREE.Color();
    for (const p of world.lootPoints) p.crate ? this.addCrate(p.x, p.y, p.z, p.tier) : this.addItem(roll(this.rng, p.tier), p.x, p.y, p.z, undefined, { b: p.b, f: p.f, skip: p.skip });
  }
  _slot() { if (this.free.length) return this.free.pop(); if (this.used >= this.cap) return -1; this.used++; for (const m of [this.boxes, this.beams, this.crates]) m.count = this.used; return this.used - 1; }
  _hide(i) { this._m.makeScale(0, 0, 0); this.boxes.setMatrixAt(i, this._m); this.beams.setMatrixAt(i, this._m); this.crates.setMatrixAt(i, this._m); }
  _place(it, t = 0) {
    const i = it.i, v = new THREE.Vector3(it.x, it.y, it.z);
    if (it.crate) { this._m.compose(v.setY(it.y + 0.45), this._q, new THREE.Vector3(1, 1, 1)); this.crates.setMatrixAt(i, this._m); this._m.makeScale(0, 0, 0); this.boxes.setMatrixAt(i, this._m); this.beams.setMatrixAt(i, this._m); }
    else {
      this._q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), t * 1.6 + i); this._m.compose(v.setY(it.y + 0.55 + Math.sin(t * 2 + i) * 0.08), this._q, new THREE.Vector3(1, 1, 1)); this.boxes.setMatrixAt(i, this._m);
      this._q.identity(); this._m.compose(new THREE.Vector3(it.x, it.y + 1.7, it.z), this._q, new THREE.Vector3(1, 1, 1)); this.beams.setMatrixAt(i, this._m); this._m.makeScale(0, 0, 0); this.crates.setMatrixAt(i, this._m);
    }
    this.dirty = true;
  }
  addItem(spec, x, y, z, forceRarity, meta) {
    const i = this._slot(); if (i < 0) return null; const it = { ...spec, ...meta, x, y, z, i, active: true, rar: forceRarity ?? rarityOf(spec) };
    this.boxes.setColorAt(i, this._c.setHex(RARITY_COLORS[it.rar])); this.beams.setColorAt(i, this._c); this.boxes.instanceColor.needsUpdate = this.beams.instanceColor.needsUpdate = true;
    this.items.push(it); this._place(it); return it;
  }
  addCrate(x, y, z, tier, contents, color = 0xc98b4b) {
    const i = this._slot(); if (i < 0) return null; const it = { kind: 'crate', tier, contents, x, y, z, i, active: true, crate: true, rar: 1 }; this.crates.setColorAt(i, this._c.setHex(color)); this.crates.instanceColor.needsUpdate = true; this.items.push(it); this._place(it); return it;
  }
  addBox(x, y, z, contents) { return this.addCrate(x, y, z, 'normal', contents, 0x6d28d9); }          // eliminated players leave a purple loot box
  scatter(specs, x, y, z, forceRarity) {                         // spill a list of items around a point (opened crates, death boxes, airdrops)
    specs.forEach((s, i) => { const a = i / specs.length * 6.28 + 0.4, d = 0.9 + (i % 2) * 0.6; this.addItem(s, x + Math.cos(a) * d, this.world.heightAt(x + Math.cos(a) * d, z + Math.sin(a) * d) + 0.1, z + Math.sin(a) * d, forceRarity); });
  }
  addAirdrop(x, y, z, ref) { const it = { kind: 'airdrop', x, y, z, i: -1, active: true, ref, rar: 4 }; this.items.push(it); return it; }

  name(it) {
    switch (it.kind) {
      case 'weapon': return WEAPONS[it.id].name; case 'ammo': return it.id + ' ammo +' + AMMO_PICKUP[it.id]; case 'armor': return 'Armour Lv.' + it.level; case 'helmet': return 'Helmet Lv.' + it.level;
      case 'backpack': return 'Backpack Lv.' + it.level; case 'medkit': return 'Medkit'; case 'grenade': return 'Grenade'; case 'gloo': return 'Gloo wall'; case 'crate': return 'Open loot crate'; case 'airdrop': return 'Open airdrop';
    } return it.kind;
  }
  update(dt, p, time) {
    let near = null, nd = 2.6; const px = p.pos.x, pz = p.pos.z, py = p.pos.y;
    for (const it of this.items) {
      if (!it.active) continue; const dx = it.x - px, dz = it.z - pz, d2 = dx * dx + dz * dz; if (d2 > 3600) continue;
      if (it.i >= 0 && !it.crate) this._place(it, time);
      if (Math.abs(it.y - py) > 2.6) continue; const d = Math.sqrt(d2);
      if (it.kind === 'ammo' && d < 1.4 && !p.air) { this._take(it, p); continue; }
      if (it.kind !== 'ammo' && d < nd && !p.air) { near = it; nd = d; }
    }
    this.near = near; this.hud.setPickup(near ? 'PICK UP: ' + this.name(near) : null);
    if (near && p.settings.autoPickup && near.kind !== 'crate' && near.kind !== 'airdrop') this.interact(p);
    if (this.dirty) { this.boxes.instanceMatrix.needsUpdate = this.beams.instanceMatrix.needsUpdate = this.crates.instanceMatrix.needsUpdate = true; this.dirty = false; }
  }
  interact(p) { if (this.near) this._take(this.near, p); }
  _remove(it) { it.active = false; if (it.i >= 0) { this._hide(it.i); this.free.push(it.i); this.dirty = true; } const k = this.items.indexOf(it); if (k >= 0) this.items.splice(k, 1); }
  takeFor(it, bot) { if (it.active) this._take(it, bot, true); }
  _take(it, p, silent = false) {
    const W = p.weapons, h = silent ? { toast() {} } : this.hud; let ok = true;
    switch (it.kind) {
      case 'crate': this._remove(it); this.scatter(it.contents || [roll(this.rng, it.tier, 1), roll(this.rng, it.tier, 0), roll(this.rng, it.tier, 0)], it.x, it.y, it.z); if (!silent) audio.pickup(); return;
      case 'airdrop': it.ref.open(); this._remove(it); audio.kill(); return;
      case 'weapon': { const d = W.pickupWeapon(it.id); if (d && d !== 'dup') this.addItem({ kind: 'weapon', id: d }, p.pos.x + 1, this.world.heightAt(p.pos.x + 1, p.pos.z) + 0.1, p.pos.z); break; }
      case 'ammo': W.addAmmo(it.id, AMMO_PICKUP[it.id]); h.toast(`+${AMMO_PICKUP[it.id]} ${it.id} ammo`); break;
      case 'armor': if (it.level <= p.armor) { h.toast('You already have better armour'); ok = false; } else { p.armor = it.level; h.toast('Armour Lv.' + it.level); } break;
      case 'helmet': if (it.level <= p.helmet) { h.toast('You already have a better helmet'); ok = false; } else { p.helmet = it.level; h.toast('Helmet Lv.' + it.level); } break;
      case 'backpack': if (it.level <= p.backpack) { h.toast('You already have a bigger backpack'); ok = false; } else { p.backpack = it.level; h.toast('Backpack Lv.' + it.level + ' (carry more items)'); } break;
      default: { const cap = CAPS[it.kind][p.backpack]; if (p.items[it.kind] >= cap) { h.toast('Backpack full'); ok = false; } else { p.items[it.kind]++; h.toast('+1 ' + this.name(it)); } }
    }
    if (ok) { if (!silent) audio.pickup(); this._remove(it); }
  }
  // ---- bots: what is worth walking to? ----
  value(bot, it) {
    const W = bot.weapons;
    switch (it.kind) {
      case 'weapon': { if (!W.wants(it.id)) return 0; const a = W.slots.filter(Boolean); return a.length === 0 ? 120 : 30 + 8 * (WEAPON_RANK[it.id] - Math.min(...a.map(s => WEAPON_RANK[s]))); }
      case 'ammo': { const prim = W.slots.find(Boolean); return prim && WEAPONS[prim].ammo === it.id && W.reserve[it.id] < WEAPONS[prim].mag * 3 ? 40 : 0; }
      case 'armor': return it.level > bot.armor ? 30 * it.level : 0; case 'helmet': return it.level > bot.helmet ? 30 * it.level : 0;
      case 'medkit': return bot.items.medkit < CAPS.medkit[bot.backpack] ? 25 : 0; case 'grenade': return bot.items.grenade < CAPS.grenade[bot.backpack] ? 10 : 0;
      case 'gloo': return bot.diff.gloo > 0 && bot.items.gloo < CAPS.gloo[bot.backpack] ? 8 : 0; case 'backpack': return it.level > bot.backpack ? 15 : 0; case 'crate': return 35;
    } return 0;
  }
  pickFor(bot) {
    const hasGun = bot.weapons.slots.some(Boolean), R = hasGun ? 90 : 150; let best = null, bs = 0.5;
    for (const it of this.items) {
      if (!it.active || it.skip || it.kind === 'airdrop' || bot.bad.has(it)) continue; const dx = it.x - bot.pos.x, dz = it.z - bot.pos.z, d2 = dx * dx + dz * dz; if (d2 > R * R) continue;
      if (it.b === undefined && it.y - this.world.heightAt(it.x, it.z) > 1.2) continue;                      // out of reach outdoors (roofs, props)
      const v = this.value(bot, it); if (v <= 0) continue; const s = v - Math.sqrt(d2) * 0.35; if (s > bs) { bs = s; best = it; }
    }
    return best;
  }
}
