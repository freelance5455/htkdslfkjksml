// Uniform grid for AABB colliders: fast "what is near me" queries and ray casts (no three.js, easy to test).
export function slab(c, o, d, maxT) {                    // ray vs box -> entry distance or Infinity
  let t0 = 0, t1 = maxT;
  for (const [ro, rd, lo, hi] of [[o.x, d.x, c.minX, c.maxX], [o.y, d.y, c.minY, c.maxY], [o.z, d.z, c.minZ, c.maxZ]]) {
    if (Math.abs(rd) < 1e-9) { if (ro < lo || ro > hi) return Infinity; continue; }
    let a = (lo - ro) / rd, b = (hi - ro) / rd; if (a > b) { const t = a; a = b; b = t; }
    if (a > t0) t0 = a; if (b < t1) t1 = b; if (t0 > t1) return Infinity;
  }
  return t0;
}
export class SpatialGrid {
  constructor(cell = 16) { this.cell = cell; this.map = new Map(); this.big = []; this.stamp = 0; }
  key(ix, iz) { return (ix + 2048) * 4096 + (iz + 2048); }
  _cells(c, fn) {
    const s = this.cell, x0 = Math.floor(c.minX / s), x1 = Math.floor(c.maxX / s), z0 = Math.floor(c.minZ / s), z1 = Math.floor(c.maxZ / s);
    for (let ix = x0; ix <= x1; ix++) for (let iz = z0; iz <= z1; iz++) fn(this.key(ix, iz));
  }
  insert(c) {
    if (c.maxX - c.minX > 150 || c.maxZ - c.minZ > 150) { this.big.push(c); return; }   // huge walls: always tested
    this._cells(c, k => { let a = this.map.get(k); if (!a) this.map.set(k, a = []); a.push(c); });
  }
  remove(c) {
    const i = this.big.indexOf(c); if (i >= 0) { this.big.splice(i, 1); return; }
    this._cells(c, k => { const a = this.map.get(k); if (a) { const j = a.indexOf(c); if (j >= 0) a.splice(j, 1); } });
  }
  near(x, z, r) {                                         // every collider whose cells overlap the square around (x,z)
    const out = this.big.slice(), s = this.cell, st = ++this.stamp;
    for (let ix = Math.floor((x - r) / s); ix <= Math.floor((x + r) / s); ix++) for (let iz = Math.floor((z - r) / s); iz <= Math.floor((z + r) / s); iz++) {
      const a = this.map.get(this.key(ix, iz)); if (!a) continue;
      for (const c of a) if (c.stamp !== st) { c.stamp = st; out.push(c); }
    }
    return out;
  }
  // nearest collider hit along the ray (Amanatides-Woo walk over the XZ cells), or maxT if none
  raycast(o, d, maxT) {
    let best = maxT; for (const c of this.big) { const t = slab(c, o, d, best); if (t < best) best = t; }
    const s = this.cell, st = ++this.stamp; let ix = Math.floor(o.x / s), iz = Math.floor(o.z / s);
    const sx = Math.sign(d.x), sz = Math.sign(d.z), dX = d.x !== 0 ? s / Math.abs(d.x) : Infinity, dZ = d.z !== 0 ? s / Math.abs(d.z) : Infinity;
    let tX = d.x !== 0 ? ((sx > 0 ? (ix + 1) * s : ix * s) - o.x) / d.x : Infinity, tZ = d.z !== 0 ? ((sz > 0 ? (iz + 1) * s : iz * s) - o.z) / d.z : Infinity;
    for (let n = 0; n < 400; n++) {
      const a = this.map.get(this.key(ix, iz));
      if (a) for (const c of a) if (c.stamp !== st) { c.stamp = st; const t = slab(c, o, d, best); if (t < best) best = t; }
      const t = Math.min(tX, tZ); if (t >= best || t === Infinity) break;       // nothing nearer can be found in later cells
      if (tX < tZ) { ix += sx; tX += dX; } else { iz += sz; tZ += dZ; }
    }
    return best;
  }
}
