// Procedural low-poly guns. Built along +Z (barrel direction); `muzzle` marks the tip.
import * as THREE from 'three';
import { toon, outline } from './characterModel.js';
import { WEAPONS } from '../data/weapons.js';

export function buildGun(id) {
  const g = new THREE.Group(), c = WEAPONS[id].color, dark = 0x2a2540, light = 0xdddddd;
  const b = (w, h, l, x, y, z, col, ol = true) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, l), toon(col)); m.position.set(x, y, z); if (ol) outline(m, 1.18); g.add(m); return m; };
  let len = 0.4;
  switch (id) {
    case 'pistol':  b(.06, .07, .26, 0, 0, .13, c); b(.05, .13, .06, 0, -.09, .04, dark); len = .27; break;
    case 'smg':     b(.07, .09, .38, 0, 0, .19, c); b(.05, .17, .06, 0, -.12, .17, dark); b(.04, .04, .1, 0, .01, .42, dark); len = .47; break;
    case 'ar':      b(.07, .1, .52, 0, 0, .26, c); b(.03, .03, .2, 0, .01, .62, dark); b(.06, .19, .07, 0, -.13, .24, dark); b(.06, .1, .18, 0, -.01, -.1, dark); len = .72; break;
    case 'shotgun': b(.07, .08, .66, 0, 0, .33, c); b(.09, .07, .18, 0, -.05, .45, dark); b(.06, .1, .2, 0, -.01, -.1, dark); len = .68; break;
    case 'sniper':  b(.06, .09, .9, 0, 0, .45, c); b(.05, .07, .26, 0, .09, .4, light); b(.025, .025, .2, 0, .01, .98, dark); b(.06, .1, .22, 0, -.01, -.12, dark); len = 1.08; break;
    default: b(.06, .06, .3, 0, 0, .15, c);
  }
  const mz = new THREE.Object3D(); mz.position.set(0, 0.02, len); g.add(mz); g.muzzle = mz;
  g.traverse(o => { if (o.isMesh) o.castShadow = false; });
  return g;
}
