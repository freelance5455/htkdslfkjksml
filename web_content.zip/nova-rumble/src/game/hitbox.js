// Hitboxes: head (sphere), torso, arms, legs (boxes). Works for any entity with {pos, stance}.
import * as THREE from 'three';
const tmp = new THREE.Vector3();
export const entityScale = e => e.stance === 'crouch' ? 0.72 : e.stance === 'prone' ? 0.35 : 1;
export const headCenter = (e, out) => out.set(e.pos.x, e.pos.y + 1.97 * entityScale(e), e.pos.z);

function slab(o, d, b, maxT) {            // ray vs AABB, returns entry distance or -1
  let t0 = 0, t1 = maxT;
  for (const [k, lo, hi] of [['x', b[0], b[1]], ['y', b[2], b[3]], ['z', b[4], b[5]]]) {
    const ro = o[k], rd = d[k];
    if (Math.abs(rd) < 1e-8) { if (ro < lo || ro > hi) return -1; continue; }
    let a = (lo - ro) / rd, c = (hi - ro) / rd; if (a > c) { const t = a; a = c; c = t; }
    if (a > t0) t0 = a; if (c < t1) t1 = c; if (t0 > t1) return -1;
  }
  return t0;
}
// returns { t, part } for the nearest hit closer than maxT, or null
export function rayVsEntity(o, d, maxT, e) {
  const s = entityScale(e), w = e.stance === 'prone' ? 1.5 : 1, x = e.pos.x, y = e.pos.y, z = e.pos.z;
  let best = maxT, part = null;
  const c = headCenter(e, tmp), ox = o.x - c.x, oy = o.y - c.y, oz = o.z - c.z, r = 0.31;
  const bq = ox * d.x + oy * d.y + oz * d.z, cq = ox * ox + oy * oy + oz * oz - r * r, disc = bq * bq - cq;
  if (disc >= 0) { const t = -bq - Math.sqrt(disc); if (t >= 0 && t < best) { best = t; part = 'head'; } }
  const boxes = [
    ['torso', x - 0.30 * w, x + 0.30 * w, y + 0.75 * s, y + 1.68 * s, z - 0.28 * w, z + 0.28 * w],
    ['arm',   x - 0.56 * w, x - 0.30 * w, y + 0.85 * s, y + 1.55 * s, z - 0.18, z + 0.18],
    ['arm',   x + 0.30 * w, x + 0.56 * w, y + 0.85 * s, y + 1.55 * s, z - 0.18, z + 0.18],
    ['leg',   x - 0.30 * w, x + 0.30 * w, y, y + 0.78 * s, z - 0.22, z + 0.22]
  ];
  for (const b of boxes) { const t = slab(o, d, b.slice(1), best); if (t >= 0 && t < best) { best = t; part = b[0]; } }
  return part ? { t: best, part } : null;
}
