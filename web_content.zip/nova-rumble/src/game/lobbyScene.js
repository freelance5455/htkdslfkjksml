// 3D lobby: sci-fi room, big window with city + purple trophy, spotlight platform, selected character.
import * as THREE from 'three';
import { buildCharacter, toon } from './characterModel.js';

function windowTexture() {                       // painted sunset skyline for the big window
  const c = document.createElement('canvas'); c.width = 512; c.height = 256; const g = c.getContext('2d');
  const sky = g.createLinearGradient(0, 0, 0, 256);
  sky.addColorStop(0, '#2a0f6b'); sky.addColorStop(0.55, '#c13cff'); sky.addColorStop(1, '#ff9a3c');
  g.fillStyle = sky; g.fillRect(0, 0, 512, 256);
  g.fillStyle = '#ffe9a8'; g.beginPath(); g.arc(380, 150, 38, 0, 7); g.fill();
  for (let i = 0; i < 40; i++) { g.fillStyle = 'rgba(255,255,255,.8)'; g.fillRect(Math.random() * 512, Math.random() * 110, 2, 2); }
  g.fillStyle = '#1b0a45';
  for (let x = 0; x < 512; x += 28) { const h = 40 + Math.random() * 90; g.fillRect(x, 256 - h, 24, h); }
  g.fillStyle = '#22d3ee';
  for (let i = 0; i < 70; i++) g.fillRect(Math.random() * 512, 160 + Math.random() * 96, 3, 3);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

function makeTrophy() {
  const g = new THREE.Group();
  const cup = new THREE.LatheGeometry([[0, 0], [0.5, 0.05], [0.12, 0.4], [0.1, 1.0], [0.55, 1.5], [0.7, 2.3], [0.62, 2.3], [0, 2.0]]
    .map(p => new THREE.Vector2(p[0], p[1])), 20);
  const m = new THREE.Mesh(cup, new THREE.MeshStandardMaterial({ color: 0x9b4dff, metalness: 0.6, roughness: 0.25, emissive: 0x2a0a66 }));
  g.add(m);
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.8, 0.3, 6), new THREE.MeshStandardMaterial({ color: 0xffc933, metalness: 0.8, roughness: 0.3 }));
  base.position.y = -0.15; g.add(base);
  const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.3), new THREE.MeshStandardMaterial({ color: 0xffe066, emissive: 0xaa7700 }));
  star.position.y = 2.9; star.name = 'star'; g.add(star);
  return g;
}

export class LobbyScene {
  constructor(canvas) {
    this.canvas = canvas; this.clock = new THREE.Clock(); this.running = false; this.char = null; this.spin = 0;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.scene = new THREE.Scene(); this.scene.background = new THREE.Color(0x14082e);
    this.scene.fog = new THREE.Fog(0x14082e, 9, 22);
    this.camera = new THREE.PerspectiveCamera(36, 1, 0.1, 60);
    this.camera.position.set(0.4, 1.7, 6.2); this.camera.lookAt(0, 1.25, 0);

    this.scene.add(new THREE.HemisphereLight(0xb9a0ff, 0x2a1450, 1.1));
    const spot = new THREE.SpotLight(0xffffff, 90, 12, 0.5, 0.6, 1.5); spot.position.set(0, 7, 2); spot.target.position.set(0, 1, 0);
    this.scene.add(spot, spot.target);
    const rim = new THREE.PointLight(0x22d3ee, 18, 10); rim.position.set(-3, 2.5, -2); this.scene.add(rim);

    // floor, platform + glow ring, spotlight cone
    const floor = new THREE.Mesh(new THREE.CircleGeometry(14, 40), new THREE.MeshStandardMaterial({ color: 0x1d0e44, roughness: 0.3, metalness: 0.5 }));
    floor.rotation.x = -Math.PI / 2; floor.position.y = -0.2; this.scene.add(floor);
    const plat = new THREE.Mesh(new THREE.CylinderGeometry(1.5, 1.7, 0.25, 32), toon(0x4a1fb5)); plat.position.y = -0.12; this.scene.add(plat);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(1.52, 0.04, 8, 48), new THREE.MeshBasicMaterial({ color: 0x22d3ee }));
    ring.rotation.x = Math.PI / 2; ring.position.y = 0.02; this.scene.add(ring); this.ring = ring;
    const cone = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 1.5, 6, 24, 1, true),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.08, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending }));
    cone.position.y = 3; this.scene.add(cone);

    // big window wall with frame
    const win = new THREE.Mesh(new THREE.PlaneGeometry(14, 6.5), new THREE.MeshBasicMaterial({ map: windowTexture() }));
    win.position.set(0, 3.2, -6); this.scene.add(win);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x2c1670, metalness: 0.7, roughness: 0.3 });
    for (let i = -3; i <= 3; i++) { const b = new THREE.Mesh(new THREE.BoxGeometry(0.14, 6.6, 0.2), frameMat); b.position.set(i * 2.3, 3.2, -5.95); this.scene.add(b); }
    const bar = new THREE.Mesh(new THREE.BoxGeometry(14.2, 0.14, 0.2), frameMat); bar.position.set(0, 3.2, -5.94); this.scene.add(bar);

    // purple trophy in the window area
    this.trophy = makeTrophy(); this.trophy.position.set(3.4, 0, -3.6); this.trophy.scale.setScalar(0.9); this.scene.add(this.trophy);
    const tl = new THREE.PointLight(0xb06bff, 25, 7); tl.position.set(3.0, 3, -2.6); this.scene.add(tl);

    // drag to rotate the character
    let down = false, lx = 0;
    canvas.addEventListener('pointerdown', e => { down = true; lx = e.clientX; });
    window.addEventListener('pointerup', () => { down = false; });
    window.addEventListener('pointermove', e => { if (down) { this.spin += (e.clientX - lx) * 0.012; lx = e.clientX; } });
    window.addEventListener('resize', () => this.resize()); this.resize();
  }
  resize() {
    const w = window.innerWidth, h = window.innerHeight;
    this.renderer.setSize(w, h, false); this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
  }
  setCharacter(def) {
    if (this.char) { this.scene.remove(this.char.group); this.char.group.traverse(o => { if (o.material && o.material !== undefined && !o.material.isMeshBasicMaterial) o.material.dispose?.(); }); }
    this.char = buildCharacter(def); this.char.group.scale.setScalar(1.05); this.scene.add(this.char.group);
    this.spin = 0.35;
  }
  start() { if (this.running) return; this.running = true; this.clock.start(); this.canvas.style.display = 'block'; this.loop(); }
  stop() { this.running = false; }
  loop = () => {
    if (!this.running) return; requestAnimationFrame(this.loop);
    const t = this.clock.getElapsedTime();
    if (this.char) { this.char.update(t); this.char.group.rotation.y += (this.spin - this.char.group.rotation.y) * 0.12; }
    this.trophy.rotation.y = t * 0.6; const s = this.trophy.getObjectByName('star'); if (s) { s.rotation.y = t * 2; s.position.y = 2.9 + Math.sin(t * 2) * 0.08; }
    this.ring.material.color.setHSL(0.5 + Math.sin(t) * 0.05, 0.9, 0.55);
    this.renderer.render(this.scene, this.camera);
  };
}
