// Armory: weapons, ammo and gear to pick up (tap PICK UP / press E; ammo is collected automatically).
// Phase 4 will reuse this for map loot, loot crates and death drops.
import * as THREE from 'three';
import { toon, outline } from './characterModel.js';
import { buildGun } from './weaponModel.js';
import { WEAPONS, AMMO_PICKUP, LEVEL_COLORS } from '../data/weapons.js';
import { audio } from '../audio/audio.js';

function label(text, color = '#ffd23f') {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64; const g = c.getContext('2d');
  g.fillStyle = 'rgba(20,8,46,.8)'; g.fillRect(0, 8, 256, 48); g.fillStyle = color; g.font = 'italic 900 26px Arial Black, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, 128, 34);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true })); s.scale.set(1.8, 0.45, 1); return s;
}
export class PickupManager {
  constructor(world, hud) {
    this.world = world; this.hud = hud; this.scene = world.scene; this.items = []; this.near = null;
    world.sign(0, -1, 'Armory', '#22d3ee');
    ['pistol', 'smg', 'ar', 'shotgun', 'sniper'].forEach((id, i) => this.add({ kind: 'weapon', id, x: -8 + i * 4, z: -3.5 }));
    ['AR', 'SMG', 'SNP', 'SHT', 'PST'].forEach((id, i) => this.add({ kind: 'ammo', id, x: -8 + i * 4, z: -7 }));
    [1, 2, 3].forEach((l, i) => { this.add({ kind: 'armor', level: l, x: -10 + i * 4, z: -10.5 }); this.add({ kind: 'helmet', level: l, x: 2 + i * 4, z: -10.5 }); });
  }
  _name(it) { return it.kind === 'weapon' ? WEAPONS[it.id].name : it.kind === 'ammo' ? it.id + ' ammo +' + AMMO_PICKUP[it.id] : (it.kind === 'armor' ? 'Armour' : 'Helmet') + ' Lv.' + it.level; }
  add(it) {
    it.g = new THREE.Group(); it.g.position.set(it.x, 0, it.z);
    const col = it.level ? LEVEL_COLORS[it.level] : it.kind === 'weapon' ? WEAPONS[it.id].color : 0xffd23f;
    const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.8, 0.15, 14), toon(col)); ped.position.y = 0.08; it.g.add(ped);
    const body = new THREE.Group(); body.position.y = 1.1; it.body = body; it.g.add(body);
    if (it.kind === 'weapon') { const gun = buildGun(it.id); gun.scale.setScalar(1.8); gun.position.z = -0.6; body.add(gun); }
    else if (it.kind === 'ammo') { const m = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.4, 0.4), toon(0xffd23f)); outline(m, 1.1); body.add(m); }
    else if (it.kind === 'armor') { const m = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.7, 0.3), toon(col)); outline(m, 1.1); body.add(m); }
    else { const m = new THREE.Mesh(new THREE.SphereGeometry(0.34, 12, 8, 0, 6.28, 0, 1.9), toon(col)); outline(m, 1.1); body.add(m); }
    const l = label(this._name(it), '#ffffff'); l.position.y = 2.2; it.g.add(l); this.scene.add(it.g); it.active = true; it.respawn = 0; this.items.push(it);
  }
  drop(id, x, z) { this.add({ kind: 'weapon', id, x: x + 1.2, z, temp: true }); }

  update(dt, player, time) {
    let near = null, nd = 2.4;
    for (const it of this.items) {
      if (!it.active) { if (!it.temp && (it.respawn -= dt) <= 0) { it.active = true; it.g.visible = true; } continue; }   // armory restocks after 15 s
      it.body.rotation.y = time * 1.5; it.body.position.y = 1.1 + Math.sin(time * 2 + it.x) * 0.08;
      const d = Math.hypot(it.x - player.pos.x, it.z - player.pos.z);
      if (it.kind === 'ammo' && d < 1.4) { this._take(it, player); continue; }
      if (it.kind !== 'ammo' && d < nd) { near = it; nd = d; }
    }
    this.near = near; this.hud.setPickup(near ? 'PICK UP: ' + this._name(near) : null);
    if (near && player.settings.autoPickup) this.interact(player);
  }
  interact(player) { if (this.near) this._take(this.near, player); }
  _take(it, player) {
    const W = player.weapons; audio.pickup();
    if (it.kind === 'weapon') { const dropped = W.pickupWeapon(it.id); if (dropped && dropped !== 'dup') this.drop(dropped, player.pos.x, player.pos.z); }
    else if (it.kind === 'ammo') { W.addAmmo(it.id, AMMO_PICKUP[it.id]); this.hud.toast(`+${AMMO_PICKUP[it.id]} ${it.id} ammo`); }
    else if (it.kind === 'armor') { player.armor = Math.max(player.armor, it.level); this.hud.toast('Armour Lv.' + it.level); }
    else { player.helmet = Math.max(player.helmet, it.level); this.hud.toast('Helmet Lv.' + it.level); }
    it.active = false; it.g.visible = false; it.respawn = 15;
    if (it.temp) { this.scene.remove(it.g); this.items.splice(this.items.indexOf(it), 1); }
  }
}
