// Player controller: movement, stances, collision, climbing, fall damage, third-person camera, items.
import * as THREE from 'three';
import { buildCharacter, toon, outline } from './characterModel.js';
import { MOVE, CAM, SCOPES } from '../data/config.js';
import { audio } from '../audio/audio.js';
import { WeaponSystem } from './weapons.js';

const RADIUS = MOVE.radius;
export class Player {
  constructor(def, world, input, hud, camera, settings) {
    this.world = world; this.input = input; this.hud = hud; this.camera = camera; this.settings = settings;
    this.pos = world.spawn.clone(); this.vel = new THREE.Vector3(); this.grounded = true; this.lift = 0;
    this.stance = 'stand'; this.hp = MOVE.maxHp; this.armor = 0; this.helmet = 0;
    this.yaw = 0; this.pitch = 0.12; this.scopeIdx = 0; this.camDist = CAM.dist; this.pivotY = MOVE.pivot.stand;
    this.facing = 0; this.walkPhase = 0; this.speed = 0; this.punchT = 0; this.kills = 0; this.streak = 0; this.streakT = 0;
    this.items = { medkit: 3, grenade: 3, gloo: 4 }; this.healT = 0; this.glooCd = 0; this.sprinting = false;
    this.grenades = []; this.walls = [];

    // hierarchy: root(position) > yawGroup(facing) > tilt(stance) > model
    this.root = new THREE.Group(); this.yawG = new THREE.Group(); this.tilt = new THREE.Group();
    this.char = buildCharacter(def); this.char.group.scale.setScalar(1.0);
    this.char.group.traverse(o => { if (o.isMesh && o.material !== undefined && !o.material.side) o.castShadow = true; });
    this.tilt.add(this.char.group); this.yawG.add(this.tilt); this.root.add(this.yawG); world.scene.add(this.root);
    this.weapons = new WeaponSystem(this, world, hud);        // slots, ammo, shooting (needs the model's hand)
    this.air = null; this.plane = null; this.backpack = 0; this.stats = { damage: 0, headshots: 0 }; this.dead = false; this.onDeath = null; this.onJump = null;
    this.protectT = 0; this.frozen = false; this.money = 0; this.team = 0; this.name = 'You'; this.isPlayer = true; this.downed = false; this.reviving = null; this.lastHitBy = null;
    // parachute canopy (only visible while gliding)
    this.canopy = new THREE.Group(); const dome = new THREE.Mesh(new THREE.SphereGeometry(2.7, 14, 8, 0, 6.2832, 0, Math.PI / 2), new THREE.MeshToonMaterial({ color: 0xffd23f, side: THREE.DoubleSide })); dome.position.y = 3.4; dome.scale.y = 0.8; this.canopy.add(dome);
    const rim = new THREE.Mesh(new THREE.TorusGeometry(2.7, 0.1, 6, 20), toon(0x8a3ffc)); rim.rotation.x = Math.PI / 2; rim.position.y = 3.4; this.canopy.add(rim);
    const lp = []; for (let i = 0; i < 4; i++) { const a = i * 1.5708 + 0.78; lp.push(new THREE.Vector3(Math.cos(a) * 2.6, 3.4, Math.sin(a) * 2.6), new THREE.Vector3(Math.cos(a) * 0.25, 1.7, 0)); }
    this.canopy.add(new THREE.LineSegments(new THREE.BufferGeometry().setFromPoints(lp), new THREE.LineBasicMaterial({ color: 0xffffff }))); this.canopy.visible = false; this.root.add(this.canopy);
  }

  get height() { return MOVE.height[this.stance]; }
  get zoom() { return SCOPES[this.scopeIdx].zoom; }
  get alive() { return !this.dead; }
  get hidden() { return this.air === 'plane'; }                         // bots can't see you while you are still in the plane
  get forward() { return new THREE.Vector3(-Math.sin(this.yaw), 0, -Math.cos(this.yaw)); }

  // ---- damage / respawn -----------------------------------------------------
  // called by bots' bullets and grenades (damage already reduced by armour / helmet by the shooter)
  takeHit(dmg, part, head, shooter) {
    if (this.dead || this.air || this.protectT > 0) return false; this.lastHitBy = shooter || null; this.damage(dmg, head);
    if (shooter && shooter.pos) this.hud.hitDir(Math.atan2(-(shooter.pos.x - this.pos.x), -(shooter.pos.z - this.pos.z)) - this.yaw);
    return this.dead;
  }
  resetForRound(p, yaw) {                                           // team modes: new round / respawn
    this.dead = false; this.downed = false; this.air = null; this.pos.set(p.x, p.y || 0, p.z); this.vel.set(0, 0, 0); this.hp = MOVE.maxHp; this.stance = 'stand'; this.yaw = yaw; this.pitch = 0.12; this.healT = 0; this.reviving = null;
    this.grounded = true; this.lift = 0; this.root.visible = true; this.protectT = 0; this.scopeIdx = 0; this.canopy.visible = false; this.facing = yaw + Math.PI; this.tilt.rotation.x = 0; this.tilt.scale.y = 1; this.tilt.position.y = 0; this.hud.setHeal(null); this.hud.setScope('OFF');
  }
  spectate(t, dt) {                                                 // after you are out: watch a living player, drag to orbit
    const inp = this.input, l = inp.takeLook(), k = CAM.lookSpeed * this.settings.sens.camera; this.yaw -= l.x * k; this.pitch = THREE.MathUtils.clamp(this.pitch - l.y * k, -0.8, 1.0); inp.pressed.clear(); this.root.visible = false;
    const cy = Math.cos(this.yaw), sy = Math.sin(this.yaw), cp = Math.cos(this.pitch), sp = Math.sin(this.pitch), fwd = new THREE.Vector3(-sy * cp, sp, -cy * cp), pivot = new THREE.Vector3(t.pos.x, t.pos.y + 1.6, t.pos.z), back = fwd.clone().negate();
    const dist = Math.max(0.5, Math.min(5, this.world.raycast(pivot, back, 5.3) - 0.3)); this.camera.position.copy(pivot).addScaledVector(back, dist); this.camera.rotation.order = 'YXZ'; this.camera.rotation.set(this.pitch, this.yaw, 0); this.hud.update_buttons(this);
  }
  revive() { this.downed = false; this.hp = 80; this.stance = 'stand'; this.hud.toast('You were revived!'); }
  damage(n, headshot = false) {
    if (this.dead) return; this.hp = Math.max(0, this.hp - n); this.hud.flashDamage(); this.reviving = null; this.hud.setHeal(null);
    if (this.hp <= 0) {
      if (!this.downed && this.world.match && this.world.match.canDown(this)) { this.downed = true; this.hp = 100; this.healT = 0; this.stance = 'prone'; this.hud.toast('You are down! A teammate can revive you'); }   // squads: knocked down, not out
      else this.die();
    }
  }
  die() {
    if (this.onDeath) { this.dead = true; this.downed = false; if (this.world.match) this.world.match.onKill(this, this.lastHitBy, false); this.hud.toast('Eliminated'); this.onDeath(); return; }     // battle royale: game over
    this.hud.toast('You fell! Respawning...'); audio.back();
    this.pos.copy(this.world.spawn); this.vel.set(0, 0, 0); this.hp = MOVE.maxHp; this.stance = 'stand'; this.healT = 0;
  }
  addKill(victim = 'Training Bot', head = false) {            // called by the weapon system and the debug key
    this.kills++; this.streak++; this.streakT = 6; if (!this.world.match) this.hud.killFeed('You', victim, head);        // in a match the match manager prints the feed
    if (this.streak >= 2) this.hud.streak(this.streak);
  }

  // ---- main update ----------------------------------------------------------
  update(dt, time) {
    this.protectT = Math.max(0, this.protectT - dt); if (this.dead) return; if (this.air) return this._air(dt, time);
    const inp = this.input;
    this._handleActions(dt);
    if (this.downed) { this.stance = 'prone'; this.hp -= 3 * dt; if (this.hp <= 0) { this.hp = 0; this.downed = false; this.die(); return; } }      // bleeding out
    // look
    const l = inp.takeLook(), s = this.settings.sens, scoped = this.scopeIdx > 0;
    const k = CAM.lookSpeed * s.camera * (scoped ? s.scope / this.zoom * 1.4 : 1);
    this.yaw -= l.x * k; this.pitch = THREE.MathUtils.clamp(this.pitch - l.y * k, CAM.pitchMin, CAM.pitchMax);

    // movement
    const m = inp.getMove(); if (this.frozen) { m.x = m.y = 0; } if (this.reviving) { m.x = m.y = 0; const r = this.reviving, t = r.target;      // reviving a teammate: stand still for 4 s
      if (!t.alive || !t.downed || Math.hypot(t.pos.x - this.pos.x, t.pos.z - this.pos.z) > 3.2) { this.reviving = null; this.hud.setHeal(null); }
      else { r.t += dt; this.hud.setHeal(r.t / 4, 'Reviving ' + t.name + '...'); if (r.t >= 4) { t.revive(); this.reviving = null; this.hud.setHeal(null); } } }
    const moving = Math.hypot(m.x, m.y) > 0.05;
    if (!moving) inp.sprintToggle = false;                                  // touch sprint auto-cancels when you let go
    const wet = !this.world.flat && this.world.heightAt(this.pos.x, this.pos.z) < -0.2;      // wading through the river slows you down
    const wantSprint = !wet && (inp.sprintHeld || inp.sprintToggle) && moving && m.y > -0.2 && this.stance === 'stand' && !scoped && this.healT <= 0;
    this.sprinting = wantSprint;
    let sp = wantSprint ? MOVE.sprint : MOVE[this.stance === 'stand' ? 'walk' : this.stance];
    if (this.healT > 0) sp *= 0.5; if (scoped) sp *= 0.7; if (wet) sp *= 0.55; if (this.downed) sp *= 0.35;
    const f = this.forward, rgt = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw));
    const wx = (f.x * m.y + rgt.x * m.x) * sp, wz = (f.z * m.y + rgt.z * m.x) * sp;
    const a = Math.min(1, dt * (this.grounded ? 12 : 3));
    this.vel.x += (wx - this.vel.x) * a; this.vel.z += (wz - this.vel.z) * a;
    this._tryMove(this.vel.x * dt, 0); this._tryMove(0, this.vel.z * dt);

    // vertical: gravity, ground (boxes/steps), fall damage
    this.vel.y -= MOVE.gravity * dt; const prevY = this.pos.y; this.pos.y += this.vel.y * dt;
    const g = this._groundAt(this.pos.x, this.pos.z, prevY);
    if (this.pos.y <= g) {
      const impact = -this.vel.y;
      if (impact > MOVE.fallSafe) { const dmg = Math.round((impact - MOVE.fallSafe) * MOVE.fallDmg); this.damage(dmg); this.hud.damageNumber(innerWidth / 2, innerHeight * 0.45, '-' + dmg, '#ff5252'); audio.tone(120, 0.25, 'sawtooth', 0.3, null, 0, 50); }
      else if (impact > 6) audio.tone(160, 0.07, 'triangle', 0.15, null, 0, 90);   // soft landing thud
      if (g - prevY > 0.05 && g - prevY < 0.6) this.lift -= g - prevY;     // smooth stair step-ups
      this.pos.y = g; this.vel.y = 0; this.grounded = true;
    } else if (this.grounded && this.vel.y <= 0 && this.pos.y - g < 0.4 && !this.input.jumpHeld) { this.pos.y = g; this.vel.y = 0; }   // walking down slopes
    else this.grounded = (this.pos.y - g) < 0.03 && this.vel.y <= 0;
    this.lift += (0 - this.lift) * Math.min(1, dt * 14);

    this.speed = Math.hypot(this.vel.x, this.vel.z);
    this._animate(dt, time, moving, scoped);
    this._camera(dt, scoped);
    if (!this.downed && !this.frozen) this.weapons.update(dt);                // after the camera so bullets use this frame's aim
    this._updateItems(dt);
    if (this.streakT > 0 && (this.streakT -= dt) <= 0) this.streak = 0;
  }

  // ---- one-shot actions (buttons / keys) -----------------------------------------
  _handleActions(dt) {
    const inp = this.input;
    if (this.downed || this.frozen) { inp.pressed.clear(); this.hud.update_buttons(this); return; }                           // knocked down: no actions
    if (inp.consume('jump')) {
      if (this.stance !== 'stand') this.stance = 'stand';                  // jump while crouched/prone stands up
      else if (this.grounded) { this.vel.y = MOVE.jump; this.grounded = false; audio.tone(300, 0.08, 'triangle', 0.12, null, 0, 520); }
    }
    if (inp.consume('crouch')) this.stance = this.stance === 'crouch' ? 'stand' : 'crouch';
    if (inp.consume('prone'))  this.stance = this.stance === 'prone' ? 'stand' : 'prone';
    if (inp.consume('scope'))  { this.scopeIdx = (this.scopeIdx + 1) % SCOPES.length; audio.click(); this.hud.setScope(SCOPES[this.scopeIdx].name); }
    if (inp.consume('reload')) this.weapons.reload();
    if (inp.consume('swap')) this.weapons.swap();
    if (inp.consume('interact')) { if (!(this.world.match && this.world.match.startRevive(this))) this.world.pickups?.interact(this); }
    if (inp.consume('medkit')) this.useMedkit();
    if (inp.consume('gloo'))   this.placeGloo();
    if (inp.consume('grenade')) this.throwGrenade();
    if (inp.consume('debugHurt')) { this.damage(40); this.hud.damageNumber(innerWidth / 2, innerHeight * 0.4, '-40', '#ff5252'); }
    if (inp.consume('debugKill')) this.addKill();
    this.hud.update_buttons(this);
  }

  useMedkit() {
    if (this.healT > 0) return;
    if (this.items.medkit <= 0) return this.hud.toast('No medkits left');
    if (this.hp >= MOVE.maxHp) return this.hud.toast('HP is already full');
    this.healT = 2.0; this.items.medkit--; audio.tone(500, 0.3, 'sine', 0.15, null, 0, 800);
  }
  placeGloo() {                                                            // instant ice wall in front of the player
    if (this.glooCd > 0 || this.items.gloo <= 0) return;
    this.glooCd = 1.2; this.items.gloo--; audio.tone(900, 0.15, 'triangle', 0.2, null, 0, 300);
    const f = this.forward, x = this.pos.x + f.x * 2.4, z = this.pos.z + f.z * 2.4, alongX = Math.abs(f.z) > Math.abs(f.x);
    const w = alongX ? 3.2 : 0.4, d = alongX ? 0.4 : 3.2, h = 2.4;
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), new THREE.MeshToonMaterial({ color: 0x7ee7ff, transparent: true, opacity: 0.8 }));
    mesh.position.set(x, this.pos.y + h / 2, z); mesh.scale.y = 0.05; mesh.castShadow = true;
    mesh.add(new THREE.Mesh(new THREE.BoxGeometry(w + 0.08, h + 0.08, d + 0.08), new THREE.MeshBasicMaterial({ color: 0x0e7490, side: THREE.BackSide })));
    this.world.scene.add(mesh);
    const col = this.world.addCollider(x - w / 2, x + w / 2, this.pos.y, this.pos.y + h, z - d / 2, z + d / 2);
    this.walls.push({ mesh, col, t: 0, life: 25 });
  }
  throwGrenade() {
    if (this.items.grenade <= 0) return; this.items.grenade--;
    const dir = new THREE.Vector3(-Math.sin(this.yaw) * Math.cos(this.pitch), Math.sin(this.pitch) + 0.35, -Math.cos(this.yaw) * Math.cos(this.pitch)).normalize();
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), toon(0x333a4d)); outline(mesh, 1.2); this.world.scene.add(mesh);
    mesh.position.copy(this.pos).add(new THREE.Vector3(0, 1.5, 0));
    this.grenades.push({ mesh, v: dir.multiplyScalar(14), t: 2.2 }); audio.tone(250, 0.1, 'triangle', 0.15, null, 0, 150);
  }
  _updateItems(dt) {
    if (this.glooCd > 0) this.glooCd -= dt;
    if (this.healT > 0) {                                                   // medkit channel: heal +100 HP after 2 s
      this.healT -= dt; this.hud.setHeal(1 - this.healT / 2);
      if (this.healT <= 0) { this.hp = Math.min(MOVE.maxHp, this.hp + 100); this.hud.setHeal(null); audio.tone(660, 0.25, 'sine', 0.2, null, 0, 990); }
    }
    for (let i = this.walls.length - 1; i >= 0; i--) {                       // gloo walls pop up, then melt after 25 s
      const w = this.walls[i]; w.t += dt; w.mesh.scale.y = Math.min(1, w.mesh.scale.y + dt * 5);
      if (w.t > w.life) { this.world.removeCollider(w.col); this.world.scene.remove(w.mesh); this.walls.splice(i, 1); }
    }
    for (let i = this.grenades.length - 1; i >= 0; i--) {                    // simple bouncing grenade, visual blast only (damage = Phase 3)
      const g = this.grenades[i]; g.t -= dt; g.v.y -= 20 * dt; g.mesh.position.addScaledVector(g.v, dt);
      if (g.mesh.position.y < 0.14) { g.mesh.position.y = 0.14; g.v.y *= -0.4; g.v.x *= 0.7; g.v.z *= 0.7; }
      if (g.t <= 0) { this._boom(g.mesh.position); this.world.scene.remove(g.mesh); this.grenades.splice(i, 1); }
    }
    for (let i = (this.fx || []).length - 1; i >= 0; i--) {
      const e = this.fx[i]; e.t += dt; const k = e.t / 0.45; e.mesh.scale.setScalar(1 + k * 6); e.mesh.material.opacity = 0.8 * (1 - k);
      if (k >= 1) { this.world.scene.remove(e.mesh); this.fx.splice(i, 1); }
    }
  }
  _boom(p) {
    (this.fx = this.fx || []).push({ t: 0, mesh: Object.assign(new THREE.Mesh(new THREE.SphereGeometry(0.8, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffb02e, transparent: true, opacity: 0.8 })), {}) });
    const e = this.fx[this.fx.length - 1]; e.mesh.position.copy(p); this.world.scene.add(e.mesh);
    audio.tone(90, 0.5, 'sawtooth', 0.35, null, 0, 35);
    if (this.world.match) this.world.match.explosion(p, this, 6, 90);                  // damages bots (and you!)
    else for (const t of this.world.targets) if (t.alive) { const d = Math.hypot(t.pos.x - p.x, t.pos.z - p.z); if (d < 6 && t.takeHit(Math.round(90 * (1 - d / 6)), 'torso', false, this)) this.addKill(t.name, false); }
  }

  // ---- plane, skydive, parachute ------------------------------------------------------------------
  startPlane(plane) { this.air = 'plane'; this.plane = plane; this.yaw = Math.atan2(-plane.dir.x, -plane.dir.z) + 0.0; this.pitch = -0.25; this.hud.setDrop('TAP JUMP TO LEAVE THE PLANE'); }
  jumpFromPlane() {
    if (this.air !== 'plane') return; const pl = this.plane; this.air = 'freefall'; this.pitch = -0.55; this.vel.set(pl.dir.x * 20, -4, pl.dir.z * 20); this.plane = null;
    audio.tone(500, 0.3, 'sawtooth', 0.2, null, 0, 120); if (this.onJump) this.onJump();
  }
  _openChute(auto) { this.air = 'chute'; this.hud.toast(auto ? 'Parachute opened automatically' : 'Parachute open'); audio.tone(200, 0.35, 'triangle', 0.25, null, 0, 700); }
  _land(g) {
    const chute = this.air === 'chute'; this.air = null; this.pos.y = g; if (chute) this.vel.set(0, 0, 0); this.grounded = false; this.canopy.visible = false; this.hud.setDrop(null); this.pitch = 0.12;
    if (chute) this.hud.toast('Landed! Find a weapon and loot up');
  }
  _air(dt, time) {
    const inp = this.input; inp.jumpHeld = false; const l = inp.takeLook(), k = CAM.lookSpeed * this.settings.sens.camera;
    this.yaw -= l.x * k; this.pitch = THREE.MathUtils.clamp(this.pitch - l.y * k, -1.25, 0.7); const jump = inp.consume('jump'); inp.pressed.clear();
    if (this.air === 'plane') {
      this.pos.copy(this.plane.pos); this.vel.set(this.plane.dir.x * this.plane.speed, 0, this.plane.dir.z * this.plane.speed); if (jump) this.jumpFromPlane();
    } else {
      const m = inp.getMove(), f = this.forward, r = new THREE.Vector3(Math.cos(this.yaw), 0, -Math.sin(this.yaw)), chute = this.air === 'chute', dive = Math.max(0, m.y);
      const hs = chute ? 13 : (m.y > 0 ? 30 : 14), tx = (f.x * m.y + r.x * m.x) * hs, tz = (f.z * m.y + r.z * m.x) * hs, ty = chute ? -6.5 : -(46 + 14 * dive);
      const a = Math.min(1, dt * (chute ? 1.6 : 2.2)); this.vel.x += (tx - this.vel.x) * a; this.vel.z += (tz - this.vel.z) * a; this.vel.y += (ty - this.vel.y) * Math.min(1, dt * 2.2);
      this._tryMove(this.vel.x * dt, 0); this._tryMove(0, this.vel.z * dt); this.pos.y += this.vel.y * dt;
      const g = this._groundAt(this.pos.x, this.pos.z, this.pos.y + 0.5), alt = this.pos.y - g;
      if (this.air === 'freefall') { this.hud.setDrop(`ALT ${Math.max(0, Math.round(alt))} m  -  TAP JUMP TO OPEN PARACHUTE`); if ((jump && alt > 12) || alt < 95) this._openChute(!jump); }
      else this.hud.setDrop(`ALT ${Math.max(0, Math.round(alt))} m  -  steer to your landing spot`);
      if (this.pos.y <= g + 0.02) this._land(g);
    }
    this.speed = Math.hypot(this.vel.x, this.vel.z); this._animate(dt, time, false, false); this._camera(dt, false); this.hud.update_buttons(this);
  }

  // ---- collision -----------------------------------------------------------------
  _tryMove(dx, dz) {
    if (!dx && !dz) return; const p = this.pos, h = this.height, nx = p.x + dx, nz = p.z + dz;
    for (const b of this.world.nearColliders(nx, nz, RADIUS + 0.2)) {
      if (nx > b.minX - RADIUS && nx < b.maxX + RADIUS && nz > b.minZ - RADIUS && nz < b.maxZ + RADIUS) {
        if (p.y + h <= b.minY + 0.01 || p.y >= b.maxY - 0.01) continue;     // we are fully below or standing on it
        const rise = b.maxY - p.y;
        if (rise <= MOVE.stepWalk) continue;                                // small step: ground check lifts us
        if (rise <= MOVE.climbMax && this.input.jumpHeld) {                 // climb low obstacle: JUMP into it
          this.lift -= rise; p.y = b.maxY; this.vel.y = 0; audio.tone(220, 0.12, 'triangle', 0.12, null, 0, 440); continue;
        }
        return false;                                                       // blocked
      }
    }
    p.x = nx; p.z = nz; return true;
  }
  _groundAt(x, z, feetY) {
    let g = this.world.heightAt(x, z), r = RADIUS * 0.6;                    // terrain first, then crates / roofs / steps
    for (const b of this.world.nearColliders(x, z, r + 0.2))
      if (x > b.minX - r && x < b.maxX + r && z > b.minZ - r && z < b.maxZ + r && b.maxY <= feetY + MOVE.stepWalk + 0.001 && b.maxY > g) g = b.maxY;
    return g;
  }

  // ---- visuals -----------------------------------------------------------------------
  _animate(dt, time, moving, scoped) {
    this.root.position.set(this.pos.x, this.pos.y + this.lift, this.pos.z);
    if (this.air === 'freefall' || this.air === 'chute') {                         // skydive (belly down, arms out) or parachute (arms up)
      const P = this.char.parts, ch = this.air === 'chute', k = Math.min(1, dt * 8); this.canopy.visible = ch; this.facing = this.yaw + Math.PI; this.yawG.rotation.y = this.facing;
      this.tilt.rotation.x += ((ch ? 0 : 1.35) - this.tilt.rotation.x) * k; this.tilt.scale.y = 1; this.tilt.position.y += ((ch ? 0 : 0.2) - this.tilt.position.y) * k;
      P.armL.rotation.x = P.armR.rotation.x = ch ? -2.9 : -0.3; P.armL.rotation.z = ch ? 0.25 : -1.3; P.armR.rotation.z = ch ? -0.25 : 1.3; P.legL.rotation.x = ch ? 0.1 : -0.2; P.legR.rotation.x = ch ? -0.1 : 0.2; return;
    }
    this.canopy.visible = false;
    const P = this.char.parts, stance = this.stance, aiming = scoped || this.input.fire;
    // face camera direction when aiming/firing, else move direction
    let target = this.facing;
    if (aiming) target = this.yaw + Math.PI; else if (this.speed > 0.4) target = Math.atan2(this.vel.x, this.vel.z);
    let d = target - this.facing; d = Math.atan2(Math.sin(d), Math.cos(d)); this.facing += d * Math.min(1, dt * 12);
    this.yawG.rotation.y = this.facing;
    // stance pose
    const ty = stance === 'crouch' ? 0.72 : 1, tx = stance === 'prone' ? 1.38 : 0;
    this.tilt.scale.y += (ty - this.tilt.scale.y) * Math.min(1, dt * 14);
    this.tilt.rotation.x += (tx - this.tilt.rotation.x) * Math.min(1, dt * 12);
    this.tilt.position.y += ((stance === 'prone' ? 0.32 : 0) - this.tilt.position.y) * Math.min(1, dt * 12);
    // walk cycle (legs/arms swing), idle otherwise
    this.walkPhase += this.speed * dt * 2.1; const amt = Math.min(1, this.speed / 4);
    if (this.speed > 0.3 && this.grounded) {
      const sw = Math.sin(this.walkPhase) * 0.9 * amt;
      P.legL.rotation.x = sw; P.legR.rotation.x = -sw; P.armL.rotation.x = -sw * 0.8; P.armR.rotation.x = sw * 0.8; P.armL.rotation.z = 0.12; P.armR.rotation.z = -0.12;
    } else if (!this.grounded) { P.legL.rotation.x = -0.5; P.legR.rotation.x = 0.4; P.armL.rotation.z = 0.9; P.armR.rotation.z = -0.9; }
    else { P.legL.rotation.x *= 0.8; P.legR.rotation.x *= 0.8; P.armL.rotation.x *= 0.8; this.char.update(time); }
    this.weapons.applyPose(P, dt);                                // arms: gun pose, reload, recoil, punches
  }
  _camera(dt, scoped) {
    const cam = this.camera, st = this.stance;
    const air = !!this.air; this.pivotY += ((air ? 0.9 : MOVE.pivot[st]) - this.pivotY) * Math.min(1, dt * 8);
    const wantDist = air ? (this.air === 'plane' ? 26 : 9) : scoped ? CAM.scopedDist : CAM.dist; this.camDist += (wantDist - this.camDist) * Math.min(1, dt * 10);
    const cy = Math.cos(this.yaw), sy = Math.sin(this.yaw), cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    const fwd = new THREE.Vector3(-sy * cp, sp, -cy * cp), right = new THREE.Vector3(cy, 0, -sy);
    const pivot = new THREE.Vector3(this.pos.x, this.pos.y + this.lift + this.pivotY, this.pos.z).addScaledVector(right, air ? 0 : CAM.shoulder);
    // pull the camera in if a wall is between us and the desired position
    const back = fwd.clone().negate(); const hit = this.world.raycast(pivot, back, this.camDist + 0.3);
    const dist = Math.max(0.4, Math.min(this.camDist, hit - 0.3));
    cam.position.copy(pivot).addScaledVector(back, dist); cam.position.y = Math.max(0.25, cam.position.y);
    cam.rotation.order = 'YXZ'; cam.rotation.set(this.pitch, this.yaw, 0);
    const targetFov = 2 * Math.atan(Math.tan(CAM.fov * Math.PI / 360) / this.zoom) * 180 / Math.PI;
    if (Math.abs(cam.fov - targetFov) > 0.05) { cam.fov += (targetFov - cam.fov) * Math.min(1, dt * 10); cam.updateProjectionMatrix(); }
    // hide the model when the camera is almost inside it (scoped close-up / prone against a wall)
    this.root.visible = dist > 0.8 && this.air !== 'plane';
  }
}
