// Safe zone logic (pure numbers, no three.js). 7 phases: wait -> next circle appears -> hold -> shrink -> repeat.
import { ZONE } from '../data/map.js';
const fmt = s => { s = Math.max(0, Math.ceil(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
export class Zone {
  constructor(rng, half = 500) {
    this.rng = rng; this.cx = 0; this.cz = 0; this.r = ZONE.startRadius; this.nx = 0; this.nz = 0; this.nr = this.r;
    this.phase = 0; this.stage = 'appear'; this.t = 0; this.showNext = false; this.msg = ''; this.events = []; this.over = false;
    this.cur = { x: 0, z: 0, r: this.r };           // interpolated circle used for damage / visuals / minimap
  }
  get dmg() { return ZONE.phases[Math.min(this.phase, ZONE.phases.length - 1)].dmg; }
  inside(x, z) { return Math.hypot(x - this.cur.x, z - this.cur.z) <= this.cur.r; }
  skip(sec) { this.update(sec); }                    // debug helper
  update(dt) {
    const P = ZONE.phases[this.phase]; if (!P) return; this.t += dt;
    if (this.stage === 'appear') {
      this.msg = 'Safe Zone will appear in ' + fmt(P.appear - this.t);
      if (this.t >= P.appear) {                      // reveal the next circle, always fully inside the current one
        this.nr = P.r; const maxOff = Math.max(0, this.r - this.nr) * 0.85, a = this.rng() * 6.2832, d = this.rng() * maxOff;
        this.nx = this.cx + Math.cos(a) * d; this.nz = this.cz + Math.sin(a) * d; this.showNext = true; this.stage = 'hold'; this.t = 0; this.events.push('shown');
      }
    } else if (this.stage === 'hold') {
      this.msg = 'Safe Zone will shrink in ' + fmt(P.hold - this.t);
      if (this.t >= P.hold) { this.stage = 'shrink'; this.t = 0; this.events.push('shrinking'); }
    } else if (this.stage === 'shrink') {
      const k = Math.min(1, this.t / P.shrink); this.msg = 'Safe Zone is now shrinking';
      this.cur = { x: this.cx + (this.nx - this.cx) * k, z: this.cz + (this.nz - this.cz) * k, r: this.r + (this.nr - this.r) * k };
      if (k >= 1) {
        this.cx = this.nx; this.cz = this.nz; this.r = this.nr; this.cur = { x: this.cx, z: this.cz, r: this.r }; this.phase++; this.t = 0; this.showNext = false;
        if (this.phase >= ZONE.phases.length) { this.stage = 'final'; this.over = true; this.msg = 'Final Safe Zone'; this.events.push('final'); } else this.stage = 'appear';
      }
    }
    if (this.stage !== 'shrink') this.cur = { x: this.cx, z: this.cz, r: this.r };
  }
  takeEvents() { const e = this.events; this.events = []; return e; }
}
