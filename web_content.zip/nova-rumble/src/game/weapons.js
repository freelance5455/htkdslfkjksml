// Weapon system: slots, ammo, reload, spread/bloom, recoil, hitscan shooting, headshot drag + assist, auto-fire, FX.
import * as THREE from 'three';
import { WEAPONS } from '../data/weapons.js';
import { MOVE } from '../data/config.js';
import { buildGun } from './weaponModel.js';
import { rayVsEntity, headCenter } from './hitbox.js';
import { calcDamage } from './damage.js';
import { audio } from '../audio/audio.js';

const HEAD_RANGE = 0.45;                 // metres between body-centre height and head height
const DRAG_PX = 80;                      // vertical drag that gives the full 0.45 m lift
const dirFrom = (yaw, pitch) => new THREE.Vector3(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
const tmp = new THREE.Vector3();

export class WeaponSystem {
  constructor(player, world, hud) {
    this.p = player; this.world = world; this.hud = hud; this.scene = world.scene;
    this.slots = ['ar', 'pistol']; this.cur = 0; this.mags = { ar: 30, pistol: 12 };
    this.reserve = { AR: 120, SMG: 0, SNP: 0, SHT: 0, PST: 48 };
    this.cd = 0; this.reloadT = 0; this.swapT = 0; this.bloom = 0; this.recoilIdx = 0; this.recoilAcc = 0; this.sinceFire = 9;
    this.spread = 0.01; this.aimAngle = 0; this.kick = 0; this.punchT = 0; this.holder = null; this.muzzle = null; this.flashT = 0; this.hits = new Map();
    // pooled FX (no allocations while shooting)
    this.tracers = Array.from({ length: 24 }, () => { const m = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.03, 1), new THREE.MeshBasicMaterial({ color: 0xfff2a0, transparent: true })); m.visible = false; this.scene.add(m); return { m, t: 0 }; });
    this.sparks = Array.from({ length: 20 }, () => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.12, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffe08a, transparent: true })); m.visible = false; this.scene.add(m); return { m, t: 0 }; });
    this.ti = 0; this.si = 0;
    this.flash = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffd35a, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending })); this.flash.visible = false;
    this._equip();
  }
  get id() { return this.cur === 2 ? 'fist' : (this.slots[this.cur] || 'fist'); }
  get weapon() { return WEAPONS[this.id]; }
  get mag() { return this.mags[this.id] ?? 0; }
  get reserveAmmo() { const w = this.weapon; return w.ammo ? this.reserve[w.ammo] : 0; }
  get reloading() { return this.reloadT > 0; }

  // ---- inventory --------------------------------------------------------------------
  _equip() {                                           // rebuild the gun in the right hand
    const arm = this.p.char.parts.armR;
    if (this.holder) { arm.remove(this.holder); this.holder = null; this.muzzle = null; }
    if (this.id !== 'fist') {
      const h = new THREE.Group(), gun = buildGun(this.id); h.rotation.x = Math.PI / 2; h.position.set(0, -0.62, 0.02); h.add(gun);
      arm.add(h); this.holder = h; this.muzzle = gun.muzzle; gun.muzzle.add(this.flash);
    }
    this.hud.toast(this.weapon.name);
  }
  swap() {
    let n = this.cur; for (let i = 0; i < 3; i++) { n = (n + 1) % 3; if (n === 2 || this.slots[n]) break; }
    if (n === this.cur) return; this.cur = n; this.reloadT = 0; this.swapT = 0.35; this.cd = 0.2; audio.click(); this._equip();
  }
  // Called by pickups. Returns the id of a weapon that had to be dropped (or null).
  pickupWeapon(id) {
    if (this.slots.includes(id)) { const w = WEAPONS[id]; this.reserve[w.ammo] += w.mag; return 'dup'; }
    let slot = this.slots[0] ? (this.slots[1] ? (this.cur < 2 ? this.cur : 0) : 1) : 0, dropped = this.slots[slot];
    this.slots[slot] = id; this.mags[id] = WEAPONS[id].mag; this.cur = slot; this.reloadT = 0; this._equip(); return dropped;
  }
  addAmmo(type, n) { this.reserve[type] += n; }
  clear() {                                            // battle royale start: bare fists, no ammo
    this.slots = [null, null]; this.cur = 2; this.mags = {}; for (const k in this.reserve) this.reserve[k] = 0; this.reloadT = 0; this._equip();
  }

  reload() {
    const w = this.weapon; if (w.type === 'melee' || this.reloading) return;
    if (this.mag >= w.mag) return this.hud.toast('Magazine full');
    if (this.reserve[w.ammo] <= 0) return this.hud.toast('No ' + w.ammo + ' ammo!');
    this.reloadT = w.reload; audio.reload();
  }
  _finishReload() {
    const w = this.weapon, take = Math.min(w.mag - this.mag, this.reserve[w.ammo]); this.mags[this.id] += take; this.reserve[w.ammo] -= take;
  }

  // ---- per-frame --------------------------------------------------------------------
  update(dt) {
    const p = this.p, inp = p.input, w = this.weapon, scoped = p.scopeIdx > 0;
    this.cd = Math.max(0, this.cd - dt); this.swapT -= dt; this.sinceFire += dt; this.kick *= Math.exp(-dt * 14); this.bloom = Math.max(0, this.bloom - dt * 0.9);
    // headshot lift: FIRE-drag pixels -> angle that raises the bullet ~0.45 m at the target distance
    if (!inp.fire) inp.aimPx *= Math.exp(-dt * 9);
    const lift = THREE.MathUtils.clamp(inp.aimPx / DRAG_PX, 0, 1), D = this._targetDistance();
    this.aimAngle = Math.atan2(HEAD_RANGE * lift, D);
    // spread: moving/airborne widen it, crouch/prone/scope tighten it, bloom grows while firing
    let s = w.spread + w.moveSpread * Math.min(1, p.speed / MOVE.walk) + (p.grounded ? 0 : w.moveSpread * 2);
    if (p.stance === 'crouch') s *= 0.75; else if (p.stance === 'prone') s *= 0.5;
    if (scoped) s *= 0.5; else if (w.hip) s *= w.hip;
    this.spread = s * (1 + this.bloom * 1.2);

    if (this.reloadT > 0 && (this.reloadT -= dt) <= 0) this._finishReload();
    let want = inp.fire;
    if (!want && p.settings.autoFire && w.type !== 'melee' && !this.reloading && this._onTarget(w)) want = true;   // auto-fire when aiming at an enemy
    if (want && this.cd <= 0 && this.swapT <= 0 && !this.reloading) this._shoot(w);
    if (this.mag <= 0 && w.type !== 'melee' && !this.reloading && this.reserve[w.ammo] > 0 && this.cd <= 0) this.reload();

    // recoil recovery: after a short pause 70% of the camera kick settles back down
    if (this.sinceFire > 0.12 && this.recoilAcc > 0) { const a = Math.min(this.recoilAcc, dt * 0.5); p.pitch -= a * 0.7; this.recoilAcc -= a; if (this.recoilAcc < 1e-4) this.recoilIdx = 0; }
    this._fx(dt);
  }

  // distance used to convert the head lift (metres) into an angle: nearest enemy near the crosshair, else 15 m
  _targetDistance() {
    const p = this.p, o = p.camera.position, d = dirFrom(p.yaw, p.pitch); let best = Infinity;
    for (const t of this.world.targets) {
      if (!t.alive || t.hidden || t.team === this.p.team) continue; tmp.set(t.pos.x, t.pos.y + 1.2, t.pos.z).sub(o); const len = tmp.length();
      if (len > 1 && len < 150 && tmp.normalize().dot(d) > 0.985) best = Math.min(best, len);
    }
    return best === Infinity ? 15 : best;
  }
  _onTarget(w) {
    const p = this.p, o = p.camera.position, d = dirFrom(p.yaw, p.pitch + this.aimAngle), maxT = w.range + 4.5;
    let best = this.world.raycast(o, d, maxT);
    for (const t of this.world.targets) if (t.alive && !t.hidden && t.team !== this.p.team && rayVsEntity(o, d, best, t)) return true;
    return false;
  }

  _shoot(w) {
    const p = this.p; this.sinceFire = 0; this.cd = 60 / w.rpm;
    if (w.type === 'melee') return this._melee(w);
    if (this.mag <= 0) { audio.empty(); this.cd = 0.3; return this.reload(); }
    this.mags[this.id]--; this.bloom = Math.min(1, this.bloom + w.bloom); audio.gun(this.id);
    const o = p.camera.position.clone(), base = dirFrom(p.yaw, p.pitch + this.aimAngle);
    this._assist(o, base, w);
    this.hits.clear(); const mz = this._muzzlePos();
    for (let i = 0; i < w.pellets; i++) this._trace(o, this._spreadDir(base, this.spread), w.range + 4.5, w, mz);
    this._feedback();
    // recoil kicks the camera up (that is also the "natural" crosshair rise) and wobbles sideways by the weapon's pattern
    const r = w.recoil, kv = r.v * (0.85 + Math.random() * 0.3) * (p.scopeIdx > 0 ? 0.7 : 1); p.pitch = Math.min(1.15, p.pitch + kv); this.recoilAcc += kv;
    p.yaw += r.pat[this.recoilIdx++ % r.pat.length] * r.h; this.kick = 1; this.flashT = 0.05; if (this.flash) this.flash.visible = true;
  }
  _melee(w) {
    const p = this.p, o = p.pos.clone(); o.y += 1.3; const d = dirFrom(p.yaw, Math.max(-0.2, Math.min(0.2, p.pitch)));
    this.punchT = 0.18; audio.tone(200, 0.06, 'triangle', 0.1, null, 0, 90); this.hits.clear();
    this._trace(o, d, w.range, w, null, true); this._feedback();
  }
  // gently pull the aim toward a nearby head (low strength, settings.assist 0..1)
  _assist(o, dir, w) {
    const k = this.p.settings.assist; if (!(k > 0)) return; const cone = 0.09; let best = null, bestA = cone;
    for (const t of this.world.targets) {
      if (!t.alive || t.hidden || t.team === this.p.team) continue; headCenter(t, tmp).sub(o); const len = tmp.length(); if (len > w.range) continue;
      const a = Math.acos(Math.min(1, tmp.normalize().dot(dir))); if (a < bestA) { bestA = a; best = tmp.clone(); }
    }
    if (best) dir.lerp(best, k * 0.35 * (1 - bestA / cone)).normalize();
  }
  _spreadDir(dir, ang) {
    const r = Math.random() * ang, th = Math.random() * 6.2832, side = new THREE.Vector3().crossVectors(dir, new THREE.Vector3(0, 1, 0)).normalize(), up = new THREE.Vector3().crossVectors(side, dir);
    return dir.clone().addScaledVector(side, Math.cos(th) * Math.tan(r)).addScaledVector(up, Math.sin(th) * Math.tan(r)).normalize();
  }
  _muzzlePos() { const v = new THREE.Vector3(); if (this.muzzle) this.muzzle.getWorldPosition(v); else v.copy(this.p.pos).add(new THREE.Vector3(0, 1.3, 0)); return v; }

  // one bullet/pellet: nearest of (world obstacle, any enemy hitbox)
  _trace(o, d, maxT, w, muzzle, melee = false) {
    let best = melee ? maxT : this.world.raycast(o, d, maxT), hit = null;
    for (const t of this.world.targets) {
      if (!t.alive || t.hidden || t.team === this.p.team) continue; const h = rayVsEntity(o, d, best, t); if (h && h.t < best) { best = h.t; hit = { t, part: h.part }; }
    }
    const end = o.clone().addScaledVector(d, best);
    if (!melee) this._tracer(muzzle || o, end);
    if (hit) {
      const dist = this.p.pos.distanceTo(end), r = calcDamage(w.damage, hit.part, dist, w, hit.t.armor, hit.t.helmet);
      const e = this.hits.get(hit.t) || { dmg: 0, head: false, kill: false }; e.dmg += r.dmg; e.head = e.head || r.head;
      if (hit.t.takeHit(r.dmg, hit.part, r.head, this.p)) e.kill = true; this.hits.set(hit.t, e); this._spark(end, r.head ? 0xff4d4d : 0xffffff);
    } else if (best < maxT) this._spark(end, 0xffe08a);
  }
  _feedback() {                                        // markers, sounds, damage numbers, kills (once per shot, not per pellet)
    let kill = false, head = false;
    for (const [t, e] of this.hits) {
      this.hud.damageNumberAt(tmp.set(t.pos.x, t.pos.y + 2.4, t.pos.z), '-' + e.dmg, e.head ? '#ff3b3b' : '#ffffff', e.head);
      kill = kill || e.kill; head = head || e.head; this.p.stats.damage += e.dmg; if (e.head) this.p.stats.headshots++;
      if (e.kill && !this.world.match) this.p.addKill(t.name, e.head);          // in a match the match manager credits kills
    }
    if (!this.hits.size) return;
    this.hud.hitMarker(kill ? 'kill' : head ? 'head' : 'body');
    if (kill) audio.kill(); else if (head) audio.headshot(); else audio.hit();
  }

  // ---- FX + arm pose ------------------------------------------------------------------
  _tracer(a, b) {
    const t = this.tracers[this.ti++ % this.tracers.length], len = a.distanceTo(b); if (len < 0.5) return;
    t.m.position.copy(a).lerp(b, 0.5); t.m.scale.z = len; t.m.lookAt(b); t.m.visible = true; t.m.material.opacity = 1; t.t = 0.08;
  }
  _spark(pt, color) { const s = this.sparks[this.si++ % this.sparks.length]; s.m.position.copy(pt); s.m.material.color.setHex(color); s.m.scale.setScalar(1); s.m.visible = true; s.t = 0.15; }
  _fx(dt) {
    for (const t of this.tracers) if (t.m.visible) { t.t -= dt; t.m.material.opacity = Math.max(0, t.t / 0.08); if (t.t <= 0) t.m.visible = false; }
    for (const s of this.sparks) if (s.m.visible) { s.t -= dt; s.m.scale.setScalar(1 + (0.15 - s.t) * 8); s.m.material.opacity = Math.max(0, s.t / 0.15); if (s.t <= 0) s.m.visible = false; }
    if (this.flashT > 0 && (this.flashT -= dt) <= 0) this.flash.visible = false;
  }
  applyPose(P, dt) {                                   // overrides arm animation while armed / punching
    const p = this.p;
    if (this.id === 'fist') {
      if (this.punchT > 0) { this.punchT -= dt; P.armR.rotation.x = -1.5 * Math.sin(Math.max(0, this.punchT) / 0.18 * Math.PI); }
      return;
    }
    const low = p.sprinting || this.swapT > 0, rel = this.reloading;
    const rx = low ? -0.7 : -1.45 + this.kick * 0.12, lx = low ? -0.7 : rel ? -0.9 + Math.sin(performance.now() / 120) * 0.15 : -1.3;
    P.armR.rotation.x = rx; P.armR.rotation.z = -0.05; P.armL.rotation.x = lx; P.armL.rotation.z = low ? 0.2 : 0.5;
  }
}
