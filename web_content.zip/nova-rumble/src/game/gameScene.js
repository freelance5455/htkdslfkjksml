// Match scene. Two modes share the same player/HUD/weapons:
//  'training' = the small Training Ground sandbox (dummies + armory)
//  'br'       = the big map: plane -> skydive -> parachute -> loot -> shrinking safe zone -> airdrops (bots arrive in Phase 5)
import * as THREE from 'three';
import { store } from '../core/store.js';
import { Input } from '../core/input.js';
import { World } from './world.js';
import { BigWorld } from './bigWorld.js';
import { Player } from './player.js';
import { Hud } from '../ui/hud.js';
import { TargetManager } from './targets.js';
import { PickupManager } from './pickups.js';
import { LootManager } from './lootManager.js';
import { Plane, Airdrop } from './airdrop.js';
import { Zone } from './zone.js';
import { BrMatch } from './match.js';
import { RoundMatch } from './roundMatch.js';
import { applyRank, rankLabel } from '../core/rank.js';
import { mulberry } from './terrain.js';
import { airdropLoot } from '../data/loot.js';
import { CAM } from '../data/config.js';
import { MAP, ZONE, AIRDROP, PLANE } from '../data/map.js';
import { audio } from '../audio/audio.js';

const QUALITY = { low: { pr: 1, shadow: 0 }, medium: { pr: 1.5, shadow: 1024 }, high: { pr: 2, shadow: 2048 } };

export class GameScene {
  constructor(canvas) {
    this.canvas = canvas; this.input = new Input(); this.input.enabled = false; this.running = false; this.clock = new THREE.Clock();
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true }); this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    window.addEventListener('resize', () => this.resize());
  }
  resize() { const w = innerWidth, h = innerHeight; this.renderer.setSize(w, h, false); if (this.camera) { this.camera.aspect = w / h; this.camera.updateProjectionMatrix(); } }

  start(uiRoot, def, onLeave, mode = 'training', cfg = null) {          // mode: 'training' | 'br' | 'team' (cfg = CS Rank / Lone Wolf / TDM / Custom settings)
    Object.assign(this, { uiRoot, def, onLeave, mode, cfg, ended: false }); this.running = true; this.canvas.style.display = 'block';
    if (mode === 'br' || mode === 'team') {                           // generating the big map takes a moment: show a loader first
      uiRoot.innerHTML = '<div class="screen loading"><div class="logo small">NOVA<span>RUMBLE</span></div><div class="runner"><i class="hd"></i><i class="bd"></i><i class="ar"></i><i class="lg l1"></i><i class="lg l2"></i></div><div class="tip">Generating the island...</div></div>';
      setTimeout(() => { if (this.running) this._build(); }, 60);
    } else this._build();
  }

  _build() {
    const br = this.mode === 'br', team = this.mode === 'team', q = QUALITY[store.data.settings.graphics] || QUALITY.medium;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, q.pr)); this.renderer.shadowMap.enabled = q.shadow > 0;
    const scene = this.scene = new THREE.Scene(); scene.background = new THREE.Color(0x8fe3ff); scene.fog = br ? new THREE.Fog(0x9fe8ff, 170, 560) : team ? new THREE.Fog(0x9fe8ff, 110, 330) : new THREE.Fog(0x8fe3ff, 60, 170);
    this.camera = new THREE.PerspectiveCamera(CAM.fov, innerWidth / innerHeight, 0.1, br ? 900 : 500);
    scene.add(new THREE.HemisphereLight(0xffffff, 0x6aa86a, 1.25));
    const sun = this.sun = new THREE.DirectionalLight(0xfff1cc, 2.2); sun.position.set(30, 50, 20);
    if (q.shadow) { sun.castShadow = true; sun.shadow.mapSize.set(q.shadow, q.shadow); const c = sun.shadow.camera; c.left = c.bottom = -30; c.right = c.top = 30; c.near = 1; c.far = 140; sun.shadow.bias = -0.0005; }
    scene.add(sun, sun.target);

    this.world = br ? new BigWorld(scene) : team ? new BigWorld(scene, { arena: this.cfg.map === 'wolf' ? 'wolf' : 'yard' }) : new World(scene);
    this.hud = new Hud(this.uiRoot, this.input, this.world, this.onLeave); this.hud.camera = this.camera;
    if (br) this._setupBR(); else if (team) this._setupTeam(); else this._setupTraining();
    this.input.enabled = true; this.input.clearAll(); this.time = 0; this.matchT = 0; this.resize(); this.clock.start(); this.loop();
  }

  // ---- Training Ground ------------------------------------------------------------------------------------
  _setupTraining() {
    this.targets = new TargetManager(this.world);
    this.world.pickups = this.pickups = new PickupManager(this.world, this.hud);
    this.player = new Player(this.def, this.world, this.input, this.hud, this.camera, store.data.settings);
    this.zone = { cx: 0, cz: 0, r: 85, nx: 0, nz: 0, nr: 55, t: 0, wait: 32, shrink: 25, msg: '' }; this._nextZone();
    this.hud.toast('Training Ground: WASD / stick to move');
  }
  _nextZone() { const z = this.zone, a = Math.random() * 6.28, d = Math.random() * 25; z.nx = z.cx + Math.cos(a) * d; z.nz = z.cz + Math.sin(a) * d; z.nr = Math.max(20, z.r * 0.65); z.t = 0; }
  _updateTrainingZone(dt) {                                           // demo zone only (no damage)
    const z = this.zone; z.t += dt;
    if (z.t < z.wait) z.msg = `Safe Zone will appear in 00:${String(Math.ceil(z.wait - z.t)).padStart(2, '0')}`;
    else { z.msg = 'Safe Zone is now shrinking'; if ((z.t - z.wait) / z.shrink >= 1) { z.cx = z.nx; z.cz = z.nz; z.r = z.nr; if (z.r <= 21) { z.r = 85; z.cx = z.cz = 0; } this._nextZone(); } }
    const k = z.t > z.wait ? Math.min(1, (z.t - z.wait) / z.shrink) : 0;
    return { msg: z.msg, cx: z.cx + (z.nx - z.cx) * k, cz: z.cz + (z.nz - z.cz) * k, r: z.r + (z.nr - z.r) * k, nx: z.nx, nz: z.nz, nr: z.nr };
  }

  // ---- Team modes: CS Rank, Lone Wolf, Team Deathmatch, Custom Room ----------------------------------------------------------------------------
  _setupTeam() {
    const cfg = this.cfg, w = this.world; this.rng = mulberry((Date.now() & 0xffffff) + 7);
    this.player = new Player(this.def, w, this.input, this.hud, this.camera, store.data.settings); this.hud.player = this.player;
    this.player.onDeath = () => { this.hud.banner(cfg.type === 'tdm' ? 'You were eliminated - respawning...' : 'You are out! Spectating your team', 3000); };
    const cyl = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 120, 48, 1, true), new THREE.MeshBasicMaterial({ color: 0x8a3ffc, transparent: true, opacity: 0.3, side: THREE.DoubleSide, depthWrite: false, fog: false })); cyl.position.y = 40; cyl.visible = false; this.scene.add(cyl); this.storm = cyl;
    this.match = new RoundMatch({ scene: this.scene, world: w, hud: this.hud, player: this.player, rng: this.rng, cfg, difficulty: cfg.difficulty || store.data.settings.botDifficulty, onEnd: win => this._finishTeam(win) });
    this.stormT = 0;
  }
  _updateTeam(dt, time) {
    const m = this.match, p = this.player;
    if (!this.ended) { m.update(dt, time); p.update(dt, time); }
    if (p.dead) { const t = m.spectateTarget(); if (t) p.spectate(t, dt); }
    if (m.zone && !p.dead && !this.ended) { this.stormT += dt; if (this.stormT >= 1) { this.stormT -= 1; if (!m.zone.inside(p.pos.x, p.pos.z)) { p.lastHitBy = null; p.damage(m.zone.dmg); } } }
    this.storm.visible = !!m.zone; if (m.zone) { const c = m.zone.cur; this.storm.position.set(c.x, 40, c.z); this.storm.scale.set(c.r, 1, c.r); }
    this.hud.setStorm(!!m.zone && !p.dead && !m.zone.inside(p.pos.x, p.pos.z)); this.hud.setAlive(m.aliveText());
    const r = m.zone ? m.zone.cur.r : 999; return { msg: m.msg, cx: m.zone ? m.zone.cur.x : 0, cz: m.zone ? m.zone.cur.z : 0, r, nx: 0, nz: 0, nr: 0, showNext: false, mates: m.mates() };
  }
  _finishTeam(win) {
    if (this.ended && this.endedShown) return; this.ended = true; this.endedShown = true; this.input.enabled = false; this.input.clearAll(); this.hud.closeBuy();
    const m = this.match, cfg = this.cfg, p = this.player, s = store.data, sec = Math.round(this.matchT), [sa, sb] = m.score, ranked = cfg.ranked;
    let rankRow = null; if (ranked) { const d = win ? Math.min(35, 20 + p.kills * 2 + Math.max(0, sa - sb) * 2) : -Math.min(25, Math.max(8, 10 + sb * 2 - sa)); const r = applyRank(s.rank, d); s.rank = r.now; rankRow = (r.delta >= 0 ? '+' : '') + r.delta + ' RP'; }
    const coins = Math.round(30 + p.kills * 12 + (win ? 80 : 20) + sec / 12), xp = Math.round(40 + p.kills * 20 + (win ? 100 : 30)); s.coins += coins; s.xp += xp; s.level = 1 + Math.floor(s.xp / 300);
    s.stats.matches++; s.stats.kills += p.kills; s.stats.headshots += p.stats.headshots; if (win) s.stats.wins++; else s.stats.deaths++; store.save();
    const rows = [[cfg.type === 'tdm' ? 'Kills' : 'Rounds', sa + ' : ' + sb], ['Your kills', p.kills], ['Damage', p.stats.damage], ['Headshots', p.stats.headshots], ['XP / Coins', '+' + xp + ' / +' + coins]]; if (rankRow) rows.push(['Rank', rankRow + '  (' + rankLabel(s.rank) + ')']);
    this.hud.showResult({ win, title: win ? 'VICTORY' : 'DEFEAT', sub: cfg.label + (win ? ' - well played!' : ' - try again!'), rows, onLobby: () => this.onLeave(), onAgain: () => this.restart() });
  }

  // ---- Battle royale (solo practice drop) -----------------------------------------------------------------
  _setupBR() {
    const w = this.world, scene = this.scene; this.rng = mulberry((Date.now() & 0xffffff) + 1);
    this.loot = new LootManager(w, this.hud, MAP.seed); w.pickups = this.loot;
    this.player = new Player(this.def, w, this.input, this.hud, this.camera, store.data.settings);
    const p = this.player; p.items = { medkit: 0, grenade: 0, gloo: 0 }; p.weapons.clear(); p.onDeath = () => this._finish(false); p.onJump = () => this.hud.banner('Jumped! Dive with the stick, tap JUMP to open the parachute', 4000);
    this.zone = new Zone(this.rng); this.stormT = 0; this.finalT = 0; this.drops = []; this.dropPlanes = []; this.dropsMade = 0; this.nextDrop = AIRDROP.first; this.hud.setAlive(1);
    // random flight line across the island
    const th = this.rng() * 6.2832, d = { x: Math.cos(th), z: Math.sin(th) }, off = (this.rng() - 0.5) * 320, perp = { x: -d.z, z: d.x }, L = 600;
    this.plane = new Plane(scene, { x: -d.x * L + perp.x * off, z: -d.z * L + perp.z * off }, { x: d.x * L + perp.x * off, z: d.z * L + perp.z * off }, PLANE.speed, PLANE.alt);
    p.startPlane(this.plane); this.hud.banner('Choose your landing spot on the map (M). Tap JUMP to drop!', 4500);
    // storm wall (purple) and the next-circle light curtain
    const cyl = (color, op) => { const m = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 260, 64, 1, true), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: op, side: THREE.DoubleSide, depthWrite: false, fog: false })); m.position.y = 90; scene.add(m); return m; };
    this.storm = cyl(0x8a3ffc, 0.3); this.nextWall = cyl(0xffffff, 0.14); this.nextWall.visible = false;
    // the other players: 49 bots (teams of 1, 2 or 4 depending on the mode), all with the same rules as you
    const mode = store.data.mode, size = mode === 'br_squad' ? 4 : mode === 'br_duo' ? 2 : 1;
    this.match = new BrMatch({ scene, world: w, loot: this.loot, hud: this.hud, player: p, zone: this.zone, plane: this.plane, rng: this.rng, teamSize: size, difficulty: store.data.settings.botDifficulty, onEnd: win => { if (win) this._finish(true); } });
    this.hud.setAlive(this.match.aliveCount());
  }
  _spawnAirdrop() {                                                    // a plane flies over the target, the crate is released as it passes
    const z = this.zone.cur, a = this.rng() * 6.2832, d = Math.sqrt(this.rng()) * z.r * 0.6; let x = z.x + Math.cos(a) * d, zz = z.z + Math.sin(a) * d;
    x = Math.max(-420, Math.min(420, x)); zz = Math.max(-420, Math.min(420, zz));
    for (let i = 0; i < 20 && this.world.heightAt(x, zz) < 0.2; i++) { x += (this.rng() - 0.5) * 80; zz += (this.rng() - 0.5) * 80; }       // not in the water
    const th = this.rng() * 6.2832, dx = Math.cos(th), dz = Math.sin(th), plane = new Plane(this.scene, { x: x - dx * 500, z: zz - dz * 500 }, { x: x + dx * 500, z: zz + dz * 500 }, PLANE.speed * 1.2, PLANE.alt + 40);
    this.dropPlanes.push({ plane, x, z: zz, released: false }); this.dropsMade++; this.nextDrop += AIRDROP.every;
    this.hud.banner('AIRDROP incoming! Follow the red smoke', 4000); [0, 0.25, 0.5].forEach(t => audio.tone(660, 0.18, 'square', 0.25, null, t));
  }
  _updateBR(dt, time) {
    const p = this.player, z = this.zone;
    if (this.plane) {
      this.plane.update(dt); if (this.plane.done) { if (p.air === 'plane') p.jumpFromPlane(); this.plane.remove(); this.plane = null; }
    } else z.update(dt);                                              // the zone clock starts once everyone has jumped
    if (this.input.consume('debugZone')) z.update(15);                // debug: L skips 15 s of zone time
    for (const e of z.takeEvents()) {
      if (e === 'shown') { this.hud.banner('The next Safe Zone is marked on the map', 3500); audio.tone(880, 0.2, 'square', 0.25); }
      else if (e === 'shrinking') { this.hud.banner('Safe Zone is now shrinking!', 3000); audio.tone(440, 0.4, 'sawtooth', 0.25, null, 0, 220); }
      else if (e === 'final') this.hud.banner('Final zone! Survive!', 4000);
    }
    const c = z.cur; this.storm.position.set(c.x, 90, c.z); this.storm.scale.set(c.r, 1, c.r); this.storm.material.opacity = 0.26 + Math.sin(time * 2) * 0.05;
    this.nextWall.visible = z.showNext; if (z.showNext) { this.nextWall.position.set(z.nx, 90, z.nz); this.nextWall.scale.set(z.nr, 1, z.nr); }
    this.match.update(dt, time);
    // storm damage
    const out = !z.inside(p.pos.x, p.pos.z) && !p.air; this.hud.setStorm(out);
    if (out) { this.stormT += dt; if (this.stormT >= 1) { this.stormT -= 1; p.lastHitBy = null; p.damage(z.dmg); this.hud.damageNumber(innerWidth / 2, innerHeight * 0.4, '-' + z.dmg, '#c084fc'); audio.tone(150, 0.15, 'sawtooth', 0.2, null, 0, 90); } } else this.stormT = 0;
    // airdrops
    if (this.dropsMade < AIRDROP.count && this.matchT >= this.nextDrop && !this.plane) this._spawnAirdrop();
    for (let i = this.dropPlanes.length - 1; i >= 0; i--) {
      const d = this.dropPlanes[i]; d.plane.update(dt);
      if (!d.released && d.plane.t >= 500) { d.released = true; const a = new Airdrop(this.world, d.x, d.z, d.plane.alt - 4); a.item = this.loot.addAirdrop(d.x, a.ground, d.z, { open: () => this._openAirdrop(a) }); a.item.active = false; this.drops.push(a); }
      if (d.plane.done) { d.plane.remove(); this.dropPlanes.splice(i, 1); }
    }
    for (const a of this.drops) { a.update(dt); if (a.landed && !a.armed && !a.opened) { a.armed = true; a.item.active = true; } }       // can only be opened after landing
    this.loot.update(dt, p, time); this.hud.setAlive(this.match.aliveCount());
    const mate = p.air || p.downed ? null : this.match.nearDownedMate(p); if (mate && !this.loot.near) this.hud.setPickup('REVIVE ' + mate.name);          // tap to revive a downed teammate
  }
  _openAirdrop(a) {
    a.open(); this.loot.scatter(airdropLoot(this.rng), a.x, a.ground, a.z, 4); this.hud.banner('Airdrop opened!', 2000);
    setTimeout(() => { const i = this.drops.indexOf(a); if (i >= 0) { a.dispose(); this.drops.splice(i, 1); } }, 25000);
  }
  _brState() {
    const z = this.zone, c = z.cur, pl = this.plane; this.dropMarks = this.drops.filter(a => !a.opened).map(a => ({ x: a.x, z: a.z })).concat(this.dropPlanes.map(d => ({ x: d.x, z: d.z })));
    return { mates: this.match.mates(), msg: pl ? 'Safe Zone will appear after the jump' : z.msg, cx: c.x, cz: c.z, r: c.r, nx: z.nx, nz: z.nz, nr: z.nr, showNext: z.showNext, drops: this.dropMarks,
      plane: pl ? { ax: pl.a.x, az: pl.a.z, bx: pl.b.x, bz: pl.b.z, x: pl.pos.x, z: pl.pos.z } : null };
  }

  // ---- end of match -----------------------------------------------------------------------------------------------
  _finish(win) {
    if (this.ended) return; this.ended = true; this.input.enabled = false; this.input.clearAll();
    const p = this.player, s = store.data, sec = Math.round(this.matchT), min = sec / 60, rank = win ? 1 : this.match.aliveTeams() + 1;
    const coins = Math.round(20 + p.kills * 15 + min * 6 + Math.max(0, 50 - rank) * 1.2 + (win ? 100 : 0)), xp = Math.round(30 + p.kills * 25 + min * 10 + Math.max(0, 50 - rank) * 2 + (win ? 150 : 0));
    s.coins += coins; s.xp += xp; s.level = 1 + Math.floor(s.xp / 300); s.stats.matches++; s.stats.kills += p.kills; s.stats.headshots += p.stats.headshots; if (win) s.stats.wins++; else s.stats.deaths++; store.save();
    this.hud.showResult({
      win, title: win ? 'CHAMPION!' : 'ELIMINATED', sub: win ? 'Last one standing!' : 'You finished #' + rank + '. Better luck next drop!',
      rows: [['Rank', '#' + rank], ['Kills', p.kills], ['Damage', p.stats.damage], ['Headshots', p.stats.headshots], ['Survived', Math.floor(sec / 60) + 'm ' + (sec % 60) + 's'], ['XP / Coins', '+' + xp + ' / +' + coins]],
      onLobby: () => this.onLeave(), onAgain: () => this.restart()
    });
  }
  restart() { const a = [this.uiRoot, this.def, this.onLeave, this.mode, this.cfg]; this.stop(); this.start(...a); }

  stop() {
    this.running = false; this.input.enabled = false; this.input.clearAll(); document.exitPointerLock?.(); this.hud?.destroy(); this.canvas.style.display = 'none';
    if (this.scene) { this.scene.traverse(o => { o.geometry?.dispose(); }); this.scene = null; }
    this.hud = null; this.player = null; this.world = null;
  }

  loop = () => {
    if (!this.running || !this.scene) return; requestAnimationFrame(this.loop);
    const dt = Math.min(0.05, this.clock.getDelta()); this.time += dt; if (!this.ended) this.matchT += dt;
    this.input.update(); if (this.input.consume('pause') && !this.ended) this.hud.openPause(); if (this.input.consume('map')) this.hud.toggleMap();
    let zoneState;
    if (this.mode === 'br') {
      if (!this.ended) { this.player.update(dt, this.time); this._updateBR(dt, this.time); } else this.loot.update(dt, this.player, this.time);
      zoneState = this._brState();
    } else if (this.mode === 'team') {
      zoneState = this._updateTeam(dt, this.time);
    } else {
      this.player.update(dt, this.time); this.targets.update(dt, this.time, this.player); this.pickups.update(dt, this.player, this.time); zoneState = this._updateTrainingZone(dt);
    }
    this.hud.update(this.player, zoneState, dt, this.time);
    this.sun.target.position.copy(this.player.pos); this.sun.position.set(this.player.pos.x + 30, this.player.pos.y + 50, this.player.pos.z + 20);
    this.renderer.render(this.scene, this.camera);
  };
}
