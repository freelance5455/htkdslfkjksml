// Phase 2 test arena ("Training Ground"): crates to climb, cover walls, containers, an enterable cottage,
// a stair tower (jump off to test fall damage), trees, hay bales and in-world signs.
// Phase 4 replaces this with the big procedural map but keeps the same collider API.
import * as THREE from 'three';
import { toon } from './characterModel.js';
import { SpatialGrid, slab } from './spatial.js';

const OUTLINE = new THREE.MeshBasicMaterial({ color: 0x14082e, side: THREE.BackSide });
function rng(seed) { let s = seed; return () => (s = (s * 16807) % 2147483647) / 2147483647; }

export class World {
  constructor(scene, build = true) {
    this.scene = scene; this.colliders = []; this.half = 90; this.locations = []; this.temp = []; this.targets = [];
    this.grid = new SpatialGrid(16); this.flat = true; this.maxH = 0;      // flat = training ground, no terrain to ray-march
    this.rand = rng(42); this.group = new THREE.Group(); scene.add(this.group);
    this.spawn = new THREE.Vector3(0, 0, 8);
    if (build) { this._ground(); this._border(); this._build(); }
  }
  heightAt(x, z) { return 0; }                                           // BigWorld overrides this with the terrain
  nearColliders(x, z, r) { return this.grid.near(x, z, r); }

  // ---- helpers -------------------------------------------------------------
  // Adds a visible toon box (with a thin outline) and, if solid, a collider. (x,z) = centre, y = bottom.
  box(x, y, z, w, h, d, color, solid = true) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), toon(color));
    m.position.set(x, y + h / 2, z); m.castShadow = m.receiveShadow = true;
    m.add(new THREE.Mesh(new THREE.BoxGeometry(w + 0.1, h + 0.1, d + 0.1), OUTLINE));
    this.group.add(m);
    const c = solid ? this.addCollider(x - w / 2, x + w / 2, y, y + h, z - d / 2, z + d / 2, m) : null;
    return { mesh: m, collider: c };
  }
  addCollider(minX, maxX, minY, maxY, minZ, maxZ, mesh = null) {
    const c = { minX, maxX, minY, maxY, minZ, maxZ, mesh }; this.colliders.push(c); this.grid.insert(c); return c;
  }
  removeCollider(c) { const i = this.colliders.indexOf(c); if (i >= 0) this.colliders.splice(i, 1); this.grid.remove(c); }

  // Nearest hit along a ray: colliders (grid walk) and the ground. Used by the camera and by bullets.
  raycast(o, d, maxT) {
    let best = this.grid.raycast(o, d, maxT);
    const g = this._terrainHit(o, d, best); if (g < best) best = g; return best;
  }
  _terrainHit(o, d, maxT) {
    if (this.flat) { if (d.y < -1e-6 && o.y > 0) { const t = -o.y / d.y; if (t < maxT) return t; } return Infinity; }
    if (d.y >= 0 && o.y > this.maxH) return Infinity;
    const lim = Math.min(maxT, 450); let prev = 0;
    for (let t = 1.5; t <= lim + 1.5; t += 1.5 + t * 0.012) {
      const tt = Math.min(t, lim), x = o.x + d.x * tt, z = o.z + d.z * tt;
      if (o.y + d.y * tt < this.heightAt(x, z)) {                       // crossed below the ground: bisect for the exact point
        let lo = prev, hi = tt;
        for (let i = 0; i < 6; i++) { const m = (lo + hi) / 2; if (o.y + d.y * m < this.heightAt(o.x + d.x * m, o.z + d.z * m)) hi = m; else lo = m; }
        return hi;
      }
      prev = tt; if (tt >= lim) break;
    }
    return Infinity;
  }

  sign(x, z, text, color = '#ffd23f', scale = 1, y = 5.2) {
    const c = document.createElement('canvas'); c.width = 256; c.height = 64; const g = c.getContext('2d');
    g.fillStyle = 'rgba(20,8,46,.85)'; g.fillRect(0, 0, 256, 64); g.strokeStyle = color; g.lineWidth = 4; g.strokeRect(2, 2, 252, 60);
    g.fillStyle = color; g.font = 'italic 900 26px Arial Black, Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text.toUpperCase(), 128, 34);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true }));
    sp.scale.set(5 * scale, 1.25 * scale, 1); sp.position.set(x, y, z); this.group.add(sp);
    this.locations.push({ name: text, x, z });
  }

  // ---- terrain -------------------------------------------------------------
  _ground() {
    const g = new THREE.Mesh(new THREE.PlaneGeometry(260, 260), toon(0x56c271)); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; this.group.add(g);
    for (let i = 0; i < 26; i++) {                           // lighter / darker grass patches
      const p = new THREE.Mesh(new THREE.CircleGeometry(4 + this.rand() * 8, 14), toon(i % 2 ? 0x6bd88a : 0x3fa85f));
      p.rotation.x = -Math.PI / 2; p.position.set((this.rand() - 0.5) * 170, 0.02, (this.rand() - 0.5) * 170); this.group.add(p);
    }
    const road = new THREE.Mesh(new THREE.PlaneGeometry(8, 180), toon(0xc9b27a)); road.rotation.x = -Math.PI / 2; road.position.set(0, 0.03, 0); this.group.add(road);
  }
  _border() {                                                // glowing purple fence + invisible collision
    const h = this.half, mat = new THREE.MeshBasicMaterial({ color: 0x9b4dff, transparent: true, opacity: 0.35 });
    [[0, -h, 2 * h, 1], [0, h, 2 * h, 1], [-h, 0, 1, 2 * h], [h, 0, 1, 2 * h]].forEach(([x, z, w, d]) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 8, d), mat); m.position.set(x, 4, z); this.group.add(m);
      this.addCollider(x - w / 2, x + w / 2, 0, 40, z - d / 2, z + d / 2);
    });
  }

  // ---- props ---------------------------------------------------------------
  _build() {
    const r = this.rand, pal = [0xff8a1f, 0xffd23f, 0x22d3ee, 0xb06bff, 0xff6bd6];
    this.sign(0, 18, 'Training Ground');

    // crates (low ones can be walked up, taller ones climbed with JUMP)
    for (let i = 0; i < 22; i++) {
      const x = (r() - 0.5) * 150, z = (r() - 0.5) * 150; if (Math.hypot(x, z - 8) < 9 || Math.abs(x) < 5) continue;
      const hts = [0.45, 0.9, 1.2, 1.5][i % 4]; this.box(x, 0, z, 1.4, hts, 1.4, pal[i % pal.length]);
    }
    // cover walls: 1.1 m (climbable) and 1.8 m (not)
    [[-12, 0, 7, 1.1], [14, 6, 7, 1.8], [-18, -14, 7, 1.1], [20, -12, 6, 1.8], [8, -25, 8, 1.1]].forEach(([x, z, w, h], i) =>
      this.box(x, 0, z, i % 2 ? 0.5 : w, h, i % 2 ? w : 0.5, 0xb7a8ff));

    // Container yard
    this.sign(-45, -35, 'Container Yard', '#22d3ee');
    [[-45, -40, 0xff4d2e], [-45, -35, 0x22d3ee], [-38, -40, 0xffd23f], [-52, -30, 0x8a3ffc]].forEach(([x, z, c]) => this.box(x, 0, z, 6, 2.6, 2.4, c));
    this.box(-45, 2.6, -40, 6, 2.6, 2.4, 0xff8a1f);          // stacked container

    // Cottage (enterable): walls 0.4 thick, door gap on the +Z side, roof slab at 3 m
    this.sign(-30, 14, 'Pine Cottage', '#ff8a1f');
    const hx = -30, hz = 25, W = 10, D = 8, T = 0.4, H = 3, wall = 0xffe0b2;
    this.box(hx, 0, hz - D / 2, W, H, T, wall);                          // back
    this.box(hx - W / 2, 0, hz, T, H, D, wall); this.box(hx + W / 2, 0, hz, T, H, D, wall); // sides
    this.box(hx - 3.4, 0, hz + D / 2, 3.2, H, T, wall); this.box(hx + 3.4, 0, hz + D / 2, 3.2, H, T, wall); // front with 3.6 m door
    this.box(hx, 2.2, hz + D / 2, 3.6, 0.8, T, wall);                    // lintel
    this.box(hx, H, hz, W + 1, 0.35, D + 1, 0xc2410c);                   // roof
    this.box(hx - 2, 0, hz - 1, 2.2, 0.9, 1, 0x9b4dff); this.box(hx + 2.5, 0, hz - 2, 1.2, 1.2, 1.2, 0xffd23f); // furniture

    // Stair tower: 16 steps of 0.45 m up to a 7.2 m platform. Jump off to test fall damage.
    this.sign(40, -26, 'Stair Tower', '#ff6bd6');
    const tx = 40, tz = -38, steps = 16;
    this.box(tx, 0, tz, 7, 7.2, 7, 0x7c3aed); this.box(tx, 7.2, tz, 7.6, 0.4, 7.6, 0xffd23f, false);
    for (let i = 0; i < steps; i++) this.box(tx - 1.2, 0, tz + 3.5 + 0.9 * (steps - i) - 0.45, 2.4, 0.45 * (i + 1), 0.9, i % 2 ? 0xa78bfa : 0xc4b5fd);

    // Trees (trunk collides) and hay bales
    for (let i = 0; i < 34; i++) {
      const x = (r() - 0.5) * 160, z = (r() - 0.5) * 160; if (Math.hypot(x, z - 8) < 10 || Math.abs(x) < 6 || Math.hypot(x + 30, z - 25) < 10 || Math.hypot(x - 40, z + 38) < 12) continue;
      const t = new THREE.Group(); t.position.set(x, 0, z);
      const tr = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.38, 2.6, 7), toon(0x8b5a2b)); tr.position.y = 1.3; tr.castShadow = true; t.add(tr);
      const lf = new THREE.Mesh(new THREE.IcosahedronGeometry(1.7, 0), toon(i % 3 ? 0x2f9e57 : 0x1f8a4c)); lf.position.y = 3.6; lf.castShadow = true;
      lf.add(new THREE.Mesh(new THREE.IcosahedronGeometry(1.8, 0), OUTLINE)); t.add(lf); this.group.add(t);
      this.addCollider(x - 0.4, x + 0.4, 0, 6, z - 0.4, z + 0.4);
    }
    for (let i = 0; i < 8; i++) { const x = 22 + (i % 4) * 2.6, z = 30 + Math.floor(i / 4) * 2.6; this.box(x, 0, z, 2, 1.2, 2, 0xf4d35e); }
    this.sign(26, 28, 'Hay Farm', '#f4d35e');
  }
}
