// The big map (1 km x 1 km): terrain with hills, a river and a sea, roads, 8 named locations with enterable
// multi-floor buildings, trees, wheat fields, loot points and a pre-rendered minimap image.
// Static boxes are merged per 250 m chunk (vertex colours) so the whole map costs only a few dozen draw calls.
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { World } from './world.js';
import { toon } from './characterModel.js';
import { MAP, LOCATIONS, FIELDS } from '../data/map.js';
import { heightAt as terrainH, colorAt, buildRoads, nearRoad, mulberry } from './terrain.js';

const FH = 3.2, T = 0.35;                                   // floor height, wall thickness
const WALLS = [0xffe0b2, 0xbfe3ff, 0xffc9de, 0xd9f7be, 0xfff3a8, 0xe2d1ff, 0xffd9a0], ROOFS = [0xc2410c, 0x7c3aed, 0x0e7490, 0xbe185d, 0x15803d, 0xb45309];
const CONT = [0xff4d2e, 0x22d3ee, 0xffd23f, 0x8a3ffc, 0xff8a1f, 0x15c5a5];

export class BigWorld extends World {
  constructor(scene, opts = {}) {
    super(scene, false); this.flat = false; this.maxH = 20; this.half = 495; this.rng = mulberry(MAP.seed);
    this.batches = new Map(); this.lootPoints = []; this.footprints = []; this.buildings = []; this.locationInfo = LOCATIONS;
    this.roads = buildRoads(this.rng); this.spawn = new THREE.Vector3(0, 0, 0); this.mapHalf = 500;
    if (opts.arena) { this.buildArena(opts.arena); return; }          // small team-mode map instead of the island
    this._terrain(); this._roads(); this._border();
    for (const L of LOCATIONS) { this.sign(L.x, L.z, L.name, '#ffd23f', 2.8, this.heightAt(L.x, L.z) + 24); this[L.type] ? this[L.type](L) : 0; }
    this._trees(); this._wheat(); this._scatterLoot();
    // drop loot points that ended up inside walls, furniture or tree trunks
    this.lootPoints = this.lootPoints.filter(p => !this.nearColliders(p.x, p.z, 1.5).some(c => p.x > c.minX - 0.4 && p.x < c.maxX + 0.4 && p.z > c.minZ - 0.4 && p.z < c.maxZ + 0.4 && p.y + 0.5 > c.minY && p.y + 0.5 < c.maxY));
    this._finalize(); this._minimapImage();
  }
  heightAt(x, z) { return terrainH(x, z); }

  // ---- small team-mode maps: 'yard' = 200 x 200 dock / container yard, 'wolf' = compact 100 x 100 arena ---------------------------------------------
  // Team A spawns on the south end (facing north), team B on the north end. Containers have ramps so you can fight from the roofs.
  buildArena(kind) {
    const wolf = kind === 'wolf', H = wolf ? 50 : 100, rng = this.rng; this.mapHalf = H; this.half = H - 5; this.flat = true; this.maxH = 0; this.heightAt = () => 0; this.arenaRects = [];
    const g = new THREE.Mesh(new THREE.PlaneGeometry(H * 4, H * 4), toon(0x8f9bb0)); g.rotation.x = -Math.PI / 2; g.receiveShadow = true; this.group.add(g);
    for (let z = -H + 8; z < H - 8; z += 8) this.box(0, 0, z, 1.2, 0.04, 4, 0xffd23f, false);                  // lane markings
    this._border();
    const cont = (x, z, alongX, stack, c) => { const w = alongX ? 6 : 2.4, d = alongX ? 2.4 : 6; this.box(x, 0, z, w, 2.6, d, c); if (stack) this.box(x, 2.6, z, w, 2.6, d, CONT[Math.floor(rng() * 6)]); this.arenaRects.push({ x, z, w, d, c }); };
    const ramp = (cx, z) => { for (let k = 0; k < 6; k++) this.box(cx + 3 + 0.45 + (5 - k) * 0.9, 0, z, 0.9, 0.45 * (k + 1), 2, 0xc4b5fd); };      // 6 steps x 0.45 m up to a container roof
    const clusters = wolf ? [[-18, -14], [18, -14], [-18, 14], [18, 14]] : [[-32, -45], [32, -45], [-32, 45], [32, 45], [0, -60], [0, 60], [-64, -18], [64, -18], [-64, 18], [64, 18]];
    for (const [x, z] of clusters) { const n = wolf ? 2 : 3; for (let i = 0; i < n; i++) cont(x, z + i * 3.2, true, i === 1, CONT[Math.floor(rng() * 6)]); ramp(x, z + 3.2); }
    const homes = wolf ? [[0, 0, 10, 10]] : [[0, 0, 14, 11], [-48, -6, 18, 12], [48, 6, 18, 12]];
    for (const [x, z, W, D] of homes) { this.house(x, z, W, D, 2, 0, WALLS[Math.floor(rng() * WALLS.length)], ROOFS[Math.floor(rng() * ROOFS.length)], 'normal'); }
    const taken = [...clusters.map(c => [c[0], c[1] + 3, 12]), ...homes.map(h => [h[0], h[1], 14])];
    for (let i = 0, n = 0; n < (wolf ? 12 : 34) && i < 400; i++) {                                                                  // scattered crates as cover
      const x = (rng() - 0.5) * (H * 1.7), z = (rng() - 0.5) * (H * 1.5); if (taken.some(t => Math.hypot(x - t[0], z - t[1]) < t[2]) || Math.abs(z) > H - 22) continue;
      taken.push([x, z, 5]); n++; this.box(x, 0, z, 1.4, [0.9, 1.4, 1.2][n % 3], 1.4, CONT[n % 6]); this.arenaRects.push({ x, z, w: 1.4, d: 1.4, c: CONT[n % 6] });
    }
    for (const s of [1, -1]) this.box(0, 0, s * (H - 12), wolf ? 24 : 40, 0.05, 8, s > 0 ? 0x3b82f6 : 0xef4444, false);          // coloured spawn pads
    this._finalize(); this._arenaMapImage(H);
  }
  // spawn point for slot `i` of `n` on team 0 (south, faces north) or team 1 (north, faces south)
  spawnFor(team, i, n) { const H = this.mapHalf, sp = n > 1 ? Math.min(7, (H * 0.5) / (n - 1)) : 0; return { x: (i - (n - 1) / 2) * sp, y: 0, z: (team === 0 ? 1 : -1) * (H - 12), yaw: team === 0 ? 0 : Math.PI }; }
  _arenaMapImage(H) {
    const S = H * 4, cv = document.createElement('canvas'); cv.width = cv.height = S; const g = cv.getContext('2d'), k = 2;
    g.fillStyle = '#7c869a'; g.fillRect(0, 0, S, S); g.fillStyle = 'rgba(59,130,246,.45)'; g.fillRect((H - 20) * k, (H + H - 16) * k - 0, 40 * k, 8 * k); g.fillStyle = 'rgba(239,68,68,.45)'; g.fillRect((H - 20) * k, (H - (H - 8)) * k, 40 * k, 8 * k);
    for (const r of this.arenaRects) { g.fillStyle = '#' + r.c.toString(16).padStart(6, '0'); g.fillRect((r.x - r.w / 2 + H) * k, (r.z - r.d / 2 + H) * k, r.w * k, r.d * k); }
    g.fillStyle = '#e8e8f0'; for (const f of this.footprints) g.fillRect((f.x - f.w / 2 + H) * k, (f.z - f.d / 2 + H) * k, f.w * k, f.d * k);
    this.mapImg = cv; this.mapPxPerM = k;
  }

  // ---- batching: boxes become merged, vertex-coloured chunk meshes ----------------------------------------
  box(x, y, z, w, h, d, color, solid = true) {
    const key = Math.floor((x + 500) / 250) + ',' + Math.floor((z + 500) / 250); let B = this.batches.get(key); if (!B) this.batches.set(key, B = { g: [], o: [] });
    const g = new THREE.BoxGeometry(w, h, d); g.translate(x, y + h / 2, z); const c = new THREE.Color(color), n = g.attributes.position.count, a = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; } g.setAttribute('color', new THREE.BufferAttribute(a, 3)); B.g.push(g);
    const o = new THREE.BoxGeometry(w + 0.12, h + 0.12, d + 0.12); o.translate(x, y + h / 2, z); B.o.push(o);
    return { collider: solid ? this.addCollider(x - w / 2, x + w / 2, y, y + h, z - d / 2, z + d / 2) : null };
  }
  _finalize() {
    const mat = toon(0xffffff); mat.vertexColors = true; const omat = new THREE.MeshBasicMaterial({ color: 0x14082e, side: THREE.BackSide });
    for (const B of this.batches.values()) {
      const m = new THREE.Mesh(mergeGeometries(B.g), mat), o = new THREE.Mesh(mergeGeometries(B.o), omat); m.castShadow = m.receiveShadow = true; this.group.add(m, o); B.g.forEach(g => g.dispose()); B.o.forEach(g => g.dispose());
    }
    this.batches.clear();
  }

  // ---- terrain, water, roads --------------------------------------------------------------------------------
  _terrain() {
    const geo = new THREE.PlaneGeometry(1400, 1400, 280, 280); geo.rotateX(-Math.PI / 2); const pos = geo.attributes.position, col = new Float32Array(pos.count * 3), cache = new Map(), tmp = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i), h = terrainH(x, z); pos.setY(i, h); const c = colorAt(x, z, h);
      let l = cache.get(c); if (!l) { tmp.setRGB(c[0], c[1], c[2], THREE.SRGBColorSpace); cache.set(c, l = [tmp.r, tmp.g, tmp.b]); } col.set(l, i * 3);
    }
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3)); geo.computeVertexNormals();
    const m = toon(0xffffff); m.vertexColors = true; const t = new THREE.Mesh(geo, m); t.receiveShadow = true; this.group.add(t);
    const w = new THREE.Mesh(new THREE.PlaneGeometry(3000, 3000), new THREE.MeshToonMaterial({ color: 0x3bb9f0, transparent: true, opacity: 0.82, depthWrite: false }));
    w.rotation.x = -Math.PI / 2; w.position.y = MAP.waterY; this.group.add(w);
  }
  _roads() {
    const P = [], I = []; let n = 0;
    for (const r of this.roads) {
      const pts = []; for (let i = 0; i < r.length - 1; i++) for (let k = 0; k < 4; k++) pts.push([r[i][0] + (r[i + 1][0] - r[i][0]) * k / 4, r[i][1] + (r[i + 1][1] - r[i][1]) * k / 4]); pts.push(r[r.length - 1]);
      for (let i = 0; i < pts.length; i++) {
        const a = pts[Math.max(0, i - 1)], b = pts[Math.min(pts.length - 1, i + 1)], dx = b[0] - a[0], dz = b[1] - a[1], l = Math.hypot(dx, dz) || 1, nx = -dz / l * 3.2, nz = dx / l * 3.2, [x, z] = pts[i];
        P.push(x + nx, Math.max(terrainH(x + nx, z + nz), -0.1) + 0.07, z + nz, x - nx, Math.max(terrainH(x - nx, z - nz), -0.1) + 0.07, z - nz);
        if (i < pts.length - 1) { I.push(n, n + 1, n + 2, n + 1, n + 3, n + 2); } n += 2;
      }
    }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setIndex(I); g.computeVertexNormals();
    // ribbons of different roads are separate strips; the index list above links consecutive pairs only inside one road
    const m = new THREE.Mesh(g, new THREE.MeshToonMaterial({ color: 0xcdb67c, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 })); m.receiveShadow = true; this.group.add(m);
  }

  // ---- buildings -------------------------------------------------------------------------------------------------
  // Enterable house, any number of floors: windows (you can climb in), a door on the front, interior stairs up to the
  // roof, parapet. `face` 0..3 turns the front to +z, -z, +x, -x. Loot points are added on every floor.
  house(cx, cz, W, D, floors, face, wallC, roofC, tier = 'normal') {
    const base = this.heightAt(cx, cz) - 0.1, H = FH - 0.2, rng = this.rng;
    const tw = (lx, lz) => face === 0 ? [lx, lz] : face === 1 ? [-lx, -lz] : face === 2 ? [lz, -lx] : [-lz, lx];
    // building record for bot navigation: door waypoints outside/inside, stair waypoints per floor
    const bid = this.buildings.length, wp = (lx, lz) => { const [x, z] = tw(lx, lz); return { x: cx + x, z: cz + z }; };
    const B = { id: bid, cx, cz, base, floors, hw: (face > 1 ? D : W) / 2, hd: (face > 1 ? W : D) / 2, doorOut: wp(0, D / 2 + 5), doorIn: wp(0, D / 2 - 2.2), stairs: [] }; this.buildings.push(B);
    const put = (lx, y0, lz, w, h, d, c) => { const [x, z] = tw(lx, lz), sw = face > 1; return this.box(cx + x, base + y0, cz + z, sw ? d : w, h, sw ? w : d, c); };
    const run = (axis, fixed, len, y0, door) => {
      const seg = (a0, a1, ya, yb) => { if (a1 - a0 < 0.05) return; const m = (a0 + a1) / 2, l = a1 - a0; axis === 'x' ? put(m, y0 + ya, fixed, l, yb - ya, T, wallC) : put(fixed, y0 + ya, m, T, yb - ya, l, wallC); };
      if (door) { seg(-len / 2, -1.4, 0, H); seg(1.4, len / 2, 0, H); seg(-1.4, 1.4, 2.4, H); return; }
      seg(-len / 2, len / 2, 0, 0.9); seg(-len / 2, len / 2, 2.3, H);                                  // sill + lintel strips, pillars between windows
      const n = Math.max(1, Math.floor(len / 4)); let cur = -len / 2;
      for (let k = 0; k < n; k++) { const c = -len / 2 + (k + 0.5) * len / n; seg(cur, c - 0.8, 0.9, 2.3); cur = c + 0.8; } seg(cur, len / 2, 0.9, 2.3);
    };
    for (let f = 0; f < floors; f++) {
      const y0 = f * FH; run('x', -D / 2 + T / 2, W, y0, false); run('x', D / 2 - T / 2, W, y0, f === 0);
      run('z', -W / 2 + T / 2, D, y0, false); run('z', W / 2 - T / 2, D, y0, false);
      const side = f % 2 === 0 ? -1 : 1, sx0 = side < 0 ? -W / 2 + T : W / 2 - T - 1.8, hz0 = -D / 2 + T, hz1 = hz0 + 6.5;
      B.stairs.push({ bottom: wp(sx0 + 0.9, hz0 + 6.9), top: wp(sx0 + 0.9, hz0 + 0.5), exit: wp(side < 0 ? sx0 + 2.6 : sx0 - 0.8, hz0 + 1.2) });
      for (let k = 0; k < 8; k++) put(sx0 + 0.9, y0, hz0 + 6.4 - (k + 0.5) * 0.8, 1.8, (k + 1) * 0.4, 0.8, 0xb08968);      // 8 steps x 0.4 m = 3.2 m
      const top = f === floors - 1, sy = (f + 1) * FH - 0.2, sc = top ? roofC : 0xd8c3a5, ix0 = -W / 2 + T, ix1 = W / 2 - T, iz1 = D / 2 - T;
      const slab = (a0, a1, b0, b1) => { if (a1 - a0 > 0.05 && b1 - b0 > 0.05) put((a0 + a1) / 2, sy, (b0 + b1) / 2, a1 - a0, 0.2, b1 - b0, sc); };
      slab(ix0, sx0, hz0, iz1); slab(sx0 + 1.8, ix1, hz0, iz1); slab(sx0, sx0 + 1.8, hz1, iz1);                               // floor with a stair hole
      const lx = -side * (1.5 + rng() * (W / 2 - 3)), lz = (rng() - 0.5) * (D - 4); const [wx, wz] = tw(lx, lz);
      this.lootPoints.push({ x: cx + wx, y: base + y0 + 0.1, z: cz + wz, tier, indoor: true, b: bid, f });
      if (rng() < 0.6) { const [qx, qz] = tw(-lx * 0.8, -lz); this.lootPoints.push({ x: cx + qx, y: base + y0 + 0.1, z: cz + qz, tier, indoor: true, b: bid, f }); }
      put(-lx * 0.6, y0, lz * 0.5 + 1, 1.1, 0.9, 1.1, 0xc98b4b);                                                               // crate as cover
      if (top) { const py = sy + 0.2; put(0, py, D / 2 - 0.15, W, 1, 0.3, roofC); put(0, py, -D / 2 + 0.15, W, 1, 0.3, roofC); put(-W / 2 + 0.15, py, 0, 0.3, 1, D, roofC); put(W / 2 - 0.15, py, 0, 0.3, 1, D, roofC); }
    }
    const sw = face > 1; this.footprints.push({ x: cx, z: cz, w: sw ? D : W, d: sw ? W : D });
  }
  buildingAt(x, z) { for (const B of this.buildings) if (Math.abs(x - B.cx) < B.hw + 1.5 && Math.abs(z - B.cz) < B.hd + 1.5) return B; return null; }
  _cluster(L, pitch, floorsPool, wr, skip, tier = 'normal') {
    const rng = this.rng, R = L.r * 0.85;
    for (let gx = -R; gx <= R; gx += pitch) for (let gz = -R; gz <= R; gz += pitch) {
      if (Math.hypot(gx, gz) > R || rng() < skip) continue;
      const x = L.x + gx + (rng() - 0.5) * 5, z = L.z + gz + (rng() - 0.5) * 5, fl = floorsPool[Math.floor(rng() * floorsPool.length)], W = wr[0] + Math.floor(rng() * (wr[1] - wr[0] + 1)), D = fl > 1 ? 10 + Math.floor(rng() * 3) : 9 + Math.floor(rng() * 3);
      if (nearRoad(this.roads, x, z, Math.max(W, D) / 2 + 4)) continue;
      this.house(x, z, W, D, fl, Math.floor(rng() * 4), WALLS[Math.floor(rng() * WALLS.length)], ROOFS[Math.floor(rng() * ROOFS.length)], tier);
    }
  }
  town(L) { this._cluster(L, 26, [1, 2, 2, 3], [9, 12], 0.2); this.house(L.x + 4, L.z + 4, 10, 10, 3, 0, 0xfff3a8, 0xbe185d, 'hot'); }
  village(L) { this._cluster(L, 24, [1, 1, 2], [8, 10], 0.25); }
  market(L) { this._cluster(L, 22, [1, 2], [8, 10], 0.1); for (let i = 0; i < 10; i++) this.box(L.x + (this.rng() - 0.5) * 70, this.heightAt(L.x, L.z), L.z + (this.rng() - 0.5) * 70, 1.4, 1 + this.rng() * 0.6, 1.4, CONT[i % 6]); }
  hill(L) { this._cluster(L, 24, [2, 3], [9, 11], 0.15, 'hot'); this.house(L.x, L.z, 10, 10, 3, 1, 0xffffff, 0x0e7490, 'hot'); }

  // helper: stacks of shipping containers, used by the factory and harbour
  _containers(x0, z0, w, d, n, y) {
    for (let i = 0; i < n; i++) {
      const x = x0 + (this.rng() - 0.5) * w, z = z0 + (this.rng() - 0.5) * d, alongX = this.rng() < 0.5, c = CONT[Math.floor(this.rng() * 6)], by = y ?? this.heightAt(x, z) - 0.1;
      const cw = alongX ? 6 : 2.4, cd = alongX ? 2.4 : 6; this.box(x, by, z, cw, 2.6, cd, c); if (this.rng() < 0.4) this.box(x, by + 2.6, z, cw, 2.6, cd, CONT[Math.floor(this.rng() * 6)]);
    }
  }
  factory(L) {
    const x = L.x, z = L.z, by = this.heightAt(x, z) - 0.1, W = 44, D = 26, H = 9, wc = 0xb8c0cc;
    this.box(x, by, z - D / 2, W, H, 0.6, wc); this.box(x - W / 2, by, z - 6, 0.6, H, D - 12, wc); this.box(x - W / 2, by, z + 10, 0.6, H, 6, wc);
    this.box(x + W / 2, by, z - 6, 0.6, H, D - 12, wc); this.box(x + W / 2, by, z + 10, 0.6, H, 6, wc);
    this.box(x - 15, by, z + D / 2, 14, H, 0.6, wc); this.box(x + 15, by, z + D / 2, 14, H, 0.6, wc); this.box(x, by + 6, z + D / 2, 16, H - 6, 0.6, wc); this.box(x, by + H, z, W + 1, 0.5, D + 1, 0x6b7280);
    this.box(x + 3.5, by + 4.1, z - 9, 23, 0.4, 4, 0xffd23f); for (let k = 0; k < 10; k++) this.box(x - 16.55 + k * 0.9, by, z - 9, 0.9, 0.45 * (k + 1), 2, 0xa78bfa);   // catwalk + stairs (10 x 0.45 = 4.5 m)
    for (let i = 0; i < 6; i++) this.box(x - 14 + i * 5.5, by, z + (i % 2 ? 3 : -2), 3, 2, 3, CONT[i]);                                           // machinery as cover
    const fb = this.buildings.length; this.buildings.push({ id: fb, cx: x, cz: z, base: by, floors: 1, hw: W / 2, hd: D / 2, doorOut: { x, z: z + D / 2 + 6 }, doorIn: { x, z: z + D / 2 - 3 }, stairs: [] });
    for (let i = 0; i < 6; i++) this.lootPoints.push({ x: x - 16 + i * 6.4, y: by + 0.2, z: z + 2 + (i % 2) * 4, tier: 'hot', indoor: true, b: fb, f: 0 });
    for (let i = 0; i < 3; i++) this.lootPoints.push({ x: x - 8 + i * 8, y: by + 4.6, z: z - 9, tier: 'hot', indoor: true, skip: true });          // catwalk loot: players only                       // catwalk loot
    this._containers(x + 5, z + 40, 70, 24, 12); this._containers(x - 40, z - 5, 12, 40, 6);
    [[x - 38, z + 30], [x + 38, z + 30]].forEach(([cx, cz]) => { this.box(cx, by, cz, 1.6, 22, 1.6, 0xffd23f); this.box(cx + 10, by, cz, 1.6, 22, 1.6, 0xffd23f); this.box(cx + 5, by + 22, cz, 14, 1.4, 1.6, 0xffd23f, false); });   // cranes
    this.box(x + 30, by, z - 25, 5, 28, 5, 0xc2410c); this.box(x + 38, by, z - 25, 5, 24, 5, 0x9a3412);                                              // chimneys
  }
  power(L) {
    const x = L.x - 18, z = L.z - 8, by = this.heightAt(L.x, L.z) - 0.1;
    const pts = [[17, 0], [14, 10], [12.5, 22], [14, 34], [16, 42]].map(p => new THREE.Vector2(p[0], p[1])), tower = new THREE.Mesh(new THREE.LatheGeometry(pts, 24), new THREE.MeshToonMaterial({ color: 0xe9e4f2, side: THREE.DoubleSide }));
    tower.position.set(x, by, z); tower.castShadow = true; this.group.add(tower);
    for (let zr = -16; zr <= 16; zr += 4) { const hw = Math.sqrt(Math.max(1, 289 - zr * zr)) * 0.85; this.addCollider(x - hw, x + hw, by, by + 42, z + zr - 2, z + zr + 2); }      // solid tower
    for (let i = 0; i < 3; i++) { const p = new THREE.Mesh(new THREE.SphereGeometry(5 + i * 2, 8, 6), new THREE.MeshToonMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 })); p.position.set(x, by + 46 + i * 5, z); this.group.add(p); }
    this.house(L.x + 30, L.z + 15, 16, 12, 2, 0, 0xcfd8dc, 0x0e7490, 'hot'); this.house(L.x + 25, L.z - 28, 12, 10, 2, 1, 0xfff3a8, 0x7c3aed, 'hot'); this.house(L.x - 35, L.z + 35, 10, 10, 1, 0, 0xfdba74, 0xc2410c, 'hot');
    for (let i = 0; i < 6; i++) this.box(L.x + 5 + (i % 3) * 7, by, L.z - 5 + Math.floor(i / 3) * 8, 3, 2.4, 3, 0x94a3b8);
    for (let i = 0; i < 4; i++) { const px = L.x - 40 + i * 16, pz = L.z + 55; this.box(px, by, pz, 0.8, 20, 0.8, 0x64748b); this.box(px, by + 18, pz, 8, 0.5, 0.5, 0x64748b, false); }
  }
  farm(L) {
    const by = this.heightAt(L.x, L.z) - 0.1, rng = this.rng;
    this.house(L.x + 12, L.z - 18, 18, 13, 2, 0, 0xb91c1c, 0x7f1d1d, 'normal'); this.house(L.x - 26, L.z + 8, 10, 10, 2, 2, 0xfff3a8, 0xc2410c, 'low'); this.house(L.x - 20, L.z - 30, 9, 9, 1, 0, 0xfde68a, 0x0e7490, 'low');
    for (let i = 0; i < 3; i++) {
      const sx = L.x + 34, sz = L.z + 6 + i * 9, s = new THREE.Mesh(new THREE.CylinderGeometry(2.7, 2.7, 14, 10), new THREE.MeshToonMaterial({ color: 0xcfd8dc })); s.position.set(sx, by + 7, sz); s.castShadow = true;
      const top = new THREE.Mesh(new THREE.ConeGeometry(2.9, 2.2, 10), new THREE.MeshToonMaterial({ color: 0xb91c1c })); top.position.y = 8.1; s.add(top); this.group.add(s); this.addCollider(sx - 2.5, sx + 2.5, by, by + 14, sz - 2.5, sz + 2.5);
    }
    for (let i = 0; i < 16; i++) { const a = rng() * 6.28, d = 20 + rng() * 55, x = L.x + Math.cos(a) * d, z = L.z + Math.sin(a) * d; if (!nearRoad(this.roads, x, z, 5)) this.box(x, this.heightAt(x, z) - 0.1, z, 2.2, 1.3, 1.7, 0xf4d35e); }
  }
  harbor(L) {
    const by = this.heightAt(L.x, L.z) - 0.1, rng = this.rng;
    for (let i = 0; i < 3; i++) { const px = L.x - 45 + i * 45; this.box(px, -1.2, L.z + 47, 7, 1.7, 75, 0x8d6e63); for (let k = 0; k < 4; k++) this.lootPoints.push({ x: px + (k % 2 - 0.5) * 3, y: 0.55, z: L.z + 30 + k * 16, tier: 'hot', indoor: false, skip: true }); }
    this._containers(L.x, L.z - 25, 130, 30, 14);
    [[L.x - 22, L.z + 10], [L.x + 24, L.z + 10]].forEach(([cx, cz]) => { this.box(cx, by, cz, 2, 26, 2, 0xff8a1f); this.box(cx + 12, by, cz, 2, 26, 2, 0xff8a1f); this.box(cx + 6, by + 26, cz, 18, 1.6, 2, 0xff8a1f, false); });
    this.house(L.x - 40, L.z - 55, 30, 14, 1, 0, 0x90a4ae, 0x1d4ed8, 'hot'); this.house(L.x + 40, L.z - 55, 26, 14, 2, 0, 0xcfd8dc, 0xb91c1c, 'hot');
    this.box(L.x + 45, -1.2, L.z + 85, 4, 16, 4, 0xffffff); this.box(L.x + 45, 14.8, L.z + 85, 4.6, 2, 4.6, 0xff4d2e);                         // lighthouse
    for (let i = 0; i < 3; i++) { const bx = L.x - 22.5 + i * 45, bz = 462 + rng() * 14; this.box(bx, -1.2, bz, 5, 2, 14, 0xffffff); this.box(bx, 0.8, bz + 2, 3, 2.2, 4, CONT[i + 1]); }  // boats
  }

  // ---- nature ---------------------------------------------------------------------------------------------------------
  _trees() {
    const rng = this.rng, pos = [];
    for (let n = 0; n < 5000 && pos.length < 1400; n++) {
      const x = (rng() - 0.5) * 980, z = (rng() - 0.5) * 980, h = this.heightAt(x, z); if (h < 0.1 || h > 11) continue;
      const dens = 0.5 + 0.5 * Math.sin(x / 61) * Math.cos(z / 47); if (rng() > dens) continue;
      let bad = false; for (const L of LOCATIONS) if (Math.hypot(x - L.x, z - L.z) < L.r * (L.type === 'village' ? 0.45 : 0.95)) { bad = true; break; }
      if (bad || nearRoad(this.roads, x, z, 6)) continue; pos.push([x, h, z, 0.8 + rng() * 0.7, rng()]);
    }
    const trunk = new THREE.InstancedMesh(new THREE.CylinderGeometry(0.28, 0.38, 2.6, 6), toon(0x8b5a2b), pos.length), leaf = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1.7, 0), toon(0xffffff), pos.length),
      outl = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1.85, 0), new THREE.MeshBasicMaterial({ color: 0x14082e, side: THREE.BackSide }), pos.length), m = new THREE.Matrix4(), q = new THREE.Quaternion(), c = new THREE.Color();
    pos.forEach(([x, h, z, s, r], i) => {
      m.compose(new THREE.Vector3(x, h + 1.3 * s, z), q, new THREE.Vector3(s, s, s)); trunk.setMatrixAt(i, m);
      m.compose(new THREE.Vector3(x, h + 3.6 * s, z), q, new THREE.Vector3(s, s, s)); leaf.setMatrixAt(i, m); outl.setMatrixAt(i, m); leaf.setColorAt(i, c.setHex(r < 0.5 ? 0x2f9e57 : r < 0.85 ? 0x1f8a4c : 0x7cc24a));
      this.addCollider(x - 0.4 * s, x + 0.4 * s, h - 0.2, h + 6, z - 0.4 * s, z + 0.4 * s);
    });
    [trunk, leaf, outl].forEach(o => { o.castShadow = o !== outl; this.group.add(o); });
  }
  _wheat() {
    const pts = []; for (const [fx, fz, w, d] of FIELDS) for (let i = 0; i < w * d / 22; i++) pts.push([fx + (this.rng() - 0.5) * w, fz + (this.rng() - 0.5) * d]);
    const geo = new THREE.ConeGeometry(0.3, 1.1, 4), im = new THREE.InstancedMesh(geo, new THREE.MeshToonMaterial({ color: 0xe8b923 }), pts.length), m = new THREE.Matrix4();
    pts.forEach(([x, z], i) => { m.makeTranslation(x, this.heightAt(x, z) + 0.5, z); im.setMatrixAt(i, m); }); this.group.add(im);
  }
  _scatterLoot() {                                                // outdoor loot + crates around each location, plus sparse wilderness loot
    const rng = this.rng, inside = (x, z) => this.footprints.some(f => Math.abs(x - f.x) < f.w / 2 + 1.5 && Math.abs(z - f.z) < f.d / 2 + 1.5);
    const add = (x, z, tier) => { const h = this.heightAt(x, z); if (h < 0 || inside(x, z)) return; this.lootPoints.push({ x, y: h + 0.1, z, tier, indoor: false, crate: rng() < 0.4 }); };
    for (const L of LOCATIONS) for (let i = 0; i < 14; i++) { const a = rng() * 6.28, d = Math.sqrt(rng()) * L.r * 0.95; add(L.x + Math.cos(a) * d, L.z + Math.sin(a) * d, L.type === 'farm' ? 'low' : 'normal'); }
    for (let i = 0; i < 70; i++) add((rng() - 0.5) * 900, (rng() - 0.5) * 900, 'low');
  }

  // ---- minimap image: 500x500 (2 m per pixel) of terrain, roads and buildings ----------------------------------------------------
  _minimapImage() {
    const S = 500, cv = document.createElement('canvas'); cv.width = cv.height = S; const g = cv.getContext('2d'), img = g.createImageData(S, S);
    for (let py = 0; py < S; py++) for (let px = 0; px < S; px++) {
      const x = px * 2 - 500 + 1, z = py * 2 - 500 + 1, h = this.heightAt(x, z), c = h < MAP.waterY ? [0.3, 0.72, 0.94] : colorAt(x, z, h), i = (py * S + px) * 4;
      img.data[i] = c[0] * 255; img.data[i + 1] = c[1] * 255; img.data[i + 2] = c[2] * 255; img.data[i + 3] = 255;
    }
    g.putImageData(img, 0, 0); g.lineCap = 'round'; g.strokeStyle = '#d9c48d'; g.lineWidth = 3;
    for (const r of this.roads) { g.beginPath(); r.forEach(([x, z], i) => i ? g.lineTo((x + 500) / 2, (z + 500) / 2) : g.moveTo((x + 500) / 2, (z + 500) / 2)); g.stroke(); }
    g.fillStyle = '#e8e8f0'; for (const f of this.footprints) g.fillRect((f.x - f.w / 2 + 500) / 2, (f.z - f.d / 2 + 500) / 2, f.w / 2, f.d / 2);
    this.mapImg = cv; this.mapPxPerM = 0.5;
  }
}
