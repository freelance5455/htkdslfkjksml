# Nova Rumble (Phase 6)
Requires Node.js 18+.

    npm install
    npm run dev      # open the printed URL (phones on the same Wi-Fi can use the LAN URL)
    npm run build    # production build in /dist

Modes (lobby mode popup): Battle Royale Solo / Duo / Squad / Bermuda (50 players, big map), CS Rank 4v4 and 2v2 (ranked buy rounds),
Lone Wolf 1v1 and 2v2, Team Deathmatch, Custom Room (any team layout 1v1 .. 8v8, game type, map, weapon rules, bot difficulty, round settings)
and the Training Ground. Bot difficulty (Easy / Normal / Hard / Pro) is in the same popup.

PC controls: click the game to lock the mouse. WASD move, Shift sprint, Space jump / leave plane / open parachute, C crouch, Z prone,
mouse = look, left click / F = fire, right click or T = scope, R reload, Q swap weapon, E pick up / open crate / revive,
1 medkit, G grenade, V gloo wall, B backpack, M big map, Esc pause. Debug: J = take 40 damage, K = fake kill, L = skip 15 s of zone time.
Touch: stick = move, drag the screen = look, hold FIRE and drag UP on the button = raise crosshair to head height (80 px = ~0.45 m).
