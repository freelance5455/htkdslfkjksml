# Cleric Zombie City Android project

The app opens the self-contained game from `app/src/main/assets/index.html` in Android WebView. The Android activity stays portrait; the HTML rotates the complete game viewport 90 degrees so the game appears landscape without asking the player to rotate the phone. Touch controls are part of the rotated viewport.

## Build APK

This environment did not include the Android SDK or Gradle, so the APK cannot be compiled here. To build it on GitHub:
1. Upload this project folder's contents to a new GitHub repository.
2. Open **Actions** and run **Build APK** (or push to `main`).
3. Download the `cleric-zombie-city-apk` artifact from the workflow run. It contains `app-debug.apk`.

For local building, use Android Studio with JDK 17 and Android SDK platform 35, then run `gradle assembleDebug`.
