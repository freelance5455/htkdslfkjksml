'use strict';

/* =========================================================
   DOMINIUM AUREUM — Core Application
   ========================================================= */

const SUPABASE_URL = 'https://rkumpewjbfqgqpucgwpr.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_9QThL8aBro0ghAQmRWOpkg_4dGMBSKV';

const STORAGE_KEY = 'dominium_aureum_v1';
const SYNC_GENERATION_KEY = 'dominium_aureum_sync_generation';
const SYNC_GENERATION_FALLBACK = 'da-water-v4';
const REMOTE_RECORD_COLUMNS = 'id,cliente,fecha,hora,dia,monto,litros,tipo_uso,observaciones,recordatorio_fecha,recordatorio_hora,recordatorio_nota,completado,deleted_at,updated_at';

const SECURITY_KEY = 'dominium_aureum_security_v1';
const DEFAULT_PASSWORD = '123456';
const PASSWORD_DISABLED_KEY = 'dominium_aureum_password_disabled_v1';
const REMINDER_SOUND_KEY = 'dominium_aureum_reminder_sound_v1';

const $ = (id) => document.getElementById(id);

const state = {
  records: [],
  pendingUpserts: {},
  pendingDeletes: [],
  supabase: null,
  realtimeChannel: null,
  realtimeConnected: false,
  syncing: false,
  editingId: null,
  recognition: null,
  voiceStopping: false,
  voiceTranscript: '',
  activeReminderId: null,
  toastTimer: null,
  localStorageAvailable: true,
  unlocked: false,
  currentView: 'dashboard',
  initializedAfterUnlock: false
};

const collator = new Intl.Collator('es', { sensitivity: 'base', numeric: true });

/* -------------------- Security -------------------- */
async function hashPassword(value) {
  const bytes = new TextEncoder().encode(String(value));
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
}

async function getPasswordHash() {
  let saved = null;
  try { saved = localStorage.getItem(SECURITY_KEY); } catch {}
  if (saved) return saved;
  const initial = await hashPassword(DEFAULT_PASSWORD);
  try { localStorage.setItem(SECURITY_KEY, initial); } catch {}
  return initial;
}

async function verifyPassword(value) {
  const expected = await getPasswordHash();
  return (await hashPassword(value)) === expected;
}

function unlockApp() {
  state.unlocked = true;
  document.body.classList.remove('locked');
  $('securityOverlay').classList.add('hidden');
  $('securityOverlay').setAttribute('aria-hidden', 'true');
  $('unlockPassword').value = '';
  if (!state.initializedAfterUnlock) {
    state.initializedAfterUnlock = true;
    checkDueReminders();
  }
}

async function handleUnlock(event) {
  event.preventDefault();
  const password = $('unlockPassword').value;
  if (passwordIsDisabled() || await verifyPassword(password)) {
    unlockApp();
    showToast('Acceso concedido.');
  } else {
    $('unlockStatus').textContent = 'Contraseña incorrecta. Inténtalo nuevamente.';
    $('unlockStatus').className = 'status-line error';
    $('unlockPassword').select();
  }
}

async function changePassword(event) {
  event.preventDefault();
  const current = $('currentPassword').value;
  const next = $('newPassword').value;
  const confirm = $('confirmPassword').value;
  if (!(await verifyPassword(current))) {
    showToast('La contraseña actual no es correcta.', true);
    return;
  }
  if (!/^\d{4,}$/.test(next)) {
    showToast('La nueva contraseña debe tener como mínimo 4 dígitos.', true);
    return;
  }
  if (next !== confirm) {
    showToast('La confirmación no coincide.', true);
    return;
  }
  localStorage.setItem(SECURITY_KEY, await hashPassword(next));
  $('passwordForm').reset();
  showToast('Contraseña actualizada correctamente.');
}

function passwordIsDisabled() {
  try { return localStorage.getItem(PASSWORD_DISABLED_KEY) === '1'; } catch { return false; }
}

function setPasswordDisabled(disabled) {
  try { localStorage.setItem(PASSWORD_DISABLED_KEY, disabled ? '1' : '0'); } catch {}
  $('disablePasswordToggle').checked = disabled;
  if (disabled) {
    unlockApp();
    showToast('Contraseña desactivada.');
  } else {
    showToast('Contraseña activada. Se solicitará al volver a abrir el sistema.');
  }
}

/* -------------------- Sound & Notifications -------------------- */
function soundEnabled() {
  try { return localStorage.getItem(REMINDER_SOUND_KEY) !== '0'; } catch { return true; }
}

function playReminderSound() {
  if (!soundEnabled()) return;
  try {
    const audio = new Audio('./assets/reminder.mp3');
    audio.preload = 'auto';
    audio.volume = 0.9;
    audio.play().catch(() => {});
  } catch {}
}

async function enableNotifications() {
  if (!('Notification' in window)) {
    $('notificationStatus').textContent = 'Este navegador no admite notificaciones.';
    return;
  }
  const permission = await Notification.requestPermission();
  $('notificationStatus').textContent = permission === 'granted'
    ? 'Notificaciones activadas en este dispositivo.'
    : 'Permiso no concedido. Revisa los permisos del navegador.';
  if (permission === 'granted') showToast('Notificaciones activadas.');
}

async function sendReminderNotification(record) {
  playReminderSound();
  if ('Notification' in window && Notification.permission === 'granted') {
    const options = {
      body: `Contactar a ${record.cliente}${record.recordatorio_nota ? ' · ' + record.recordatorio_nota : ''}`,
      tag: `dominium-${record.id}`,
      renotify: false,
      data: { url: './' }
    };
    try {
      const notification = new Notification('DOMINIUM AUREUM · Recordatorio', options);
      notification.onclick = () => { window.focus(); notification.close(); };
    } catch {}
  }
}

function openSettings() {
  $('disablePasswordToggle').checked = passwordIsDisabled();
  $('reminderSoundEnabled').checked = soundEnabled();
  $('notificationStatus').textContent = ('Notification' in window)
    ? `Estado de notificaciones: ${Notification.permission}.`
    : 'Notificaciones no disponibles en este navegador.';
  openOverlay('settingsOverlay');
}

/* -------------------- Helpers -------------------- */
function localDateParts(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return {
    date: `${y}-${m}-${d}`,
    time: `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`
  };
}

function weekdaySpanish(date = new Date()) {
  return new Intl.DateTimeFormat('es-PE', { weekday: 'long' }).format(date);
}

function formatDate(dateStr) {
  if (!dateStr) return '—';
  const [y, m, d] = dateStr.split('-').map(Number);
  if (!y || !m || !d) return dateStr;
  return new Intl.DateTimeFormat('es-PE', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(y, m - 1, d));
}

function formatCurrency(value) {
  const n = Number(value || 0);
  return new Intl.NumberFormat('es-PE', { style: 'currency', currency: 'PEN', minimumFractionDigits: 2 }).format(Number.isFinite(n) ? n : 0);
}

function normalizeText(value) {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function makeId() {
  if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = Math.random() * 16 | 0;
    return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
}

function safeParse(raw) {
  try { return raw ? JSON.parse(raw) : null; } catch { return null; }
}

function requestBackgroundSync() {
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.ready.then(registration => {
    if (registration.sync && typeof registration.sync.register === 'function') {
      return registration.sync.register('dominium-sync');
    }
  }).catch(() => {});
}

function registerPeriodicRefresh() {
  if (!('serviceWorker' in navigator)) return;
  navigator.serviceWorker.ready.then(registration => {
    if (registration.periodicSync && typeof registration.periodicSync.register === 'function') {
      return registration.periodicSync.register('dominium-periodic-refresh', { minInterval: 15 * 60 * 1000 });
    }
  }).catch(() => {});
}

function persistState() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      records: state.records,
      pendingUpserts: state.pendingUpserts,
      pendingDeletes: state.pendingDeletes
    }));
    state.localStorageAvailable = true;
    requestBackgroundSync();
  } catch {
    state.localStorageAvailable = false;
  }
}

function loadState() {
  try {
    const saved = safeParse(localStorage.getItem(STORAGE_KEY));
    if (saved && typeof saved === 'object') {
      state.records = Array.isArray(saved.records) ? saved.records : [];
      state.pendingUpserts = saved.pendingUpserts && typeof saved.pendingUpserts === 'object' ? saved.pendingUpserts : {};
      state.pendingDeletes = Array.isArray(saved.pendingDeletes) ? saved.pendingDeletes : [];
    }
  } catch {
    state.localStorageAvailable = false;
  }
}

function showToast(message, isError = false) {
  const toast = $('toast');
  toast.textContent = message;
  toast.classList.toggle('error', isError);
  toast.classList.add('show');
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}

function setConnectionBadge() {
  const badge = $('connectionBadge');
  if (!navigator.onLine) {
    badge.textContent = 'SIN CONEXIÓN';
    badge.className = 'connection offline';
  } else if (Object.keys(state.pendingUpserts).length || state.pendingDeletes.length) {
    badge.textContent = 'CAMBIOS PENDIENTES';
    badge.className = 'connection pending';
  } else if (state.realtimeConnected) {
    badge.textContent = 'TIEMPO REAL';
    badge.className = 'connection';
  } else if (hasSupabaseConfig()) {
    badge.textContent = 'CONECTANDO';
    badge.className = 'connection pending';
  } else {
    badge.textContent = 'MODO LOCAL';
    badge.className = 'connection';
  }
}

function updateHeaderDate() {
  const now = new Date();
  $('todayDate').textContent = new Intl.DateTimeFormat('es-PE', { day: '2-digit', month: 'short', year: 'numeric' }).format(now).toUpperCase();
  $('todayDay').textContent = weekdaySpanish(now).toUpperCase();
}

function sortedRecords(list = state.records) {
  return [...list].sort((a, b) => collator.compare(a.cliente || '', b.cliente || ''));
}

function normalizeUsageType(value) {
  const normalized = normalizeText(value || 'indeterminado');
  return ['consumo', 'comercio', 'indeterminado'].includes(normalized) ? normalized : 'indeterminado';
}

function usageLabel(value) {
  const type = normalizeUsageType(value);
  return type === 'consumo' ? 'CONSUMO' : type === 'comercio' ? 'COMERCIO' : 'INDETERMINADO';
}

function formatLitres(value) {
  const amount = Number(value || 0);
  return `${new Intl.NumberFormat('es-PE', { maximumFractionDigits: 2 }).format(Number.isFinite(amount) ? amount : 0)} L`;
}

function frequencyLabel(position) {
  if (position === 1) return '1.er PUESTO';
  if (position === 2) return '2.º PUESTO';
  if (position === 3) return '3.er PUESTO';
  return 'FUERA DEL TOP 3';
}

/* -------------------- Frequency -------------------- */
function getCustomerFrequency() {
  const grouped = new Map();
  for (const record of state.records) {
    const key = normalizeText(record.cliente);
    if (!key) continue;
    if (!grouped.has(key)) {
      grouped.set(key, {
        key,
        cliente: String(record.cliente || 'Cliente sin nombre').trim(),
        pedidos: 0,
        montoTotal: 0,
        litrosTotal: 0,
        usos: new Set()
      });
    }
    const customer = grouped.get(key);
    customer.pedidos += 1;
    customer.montoTotal += Number(record.monto) || 0;
    customer.litrosTotal += Number(record.litros) || 0;
    customer.usos.add(normalizeUsageType(record.tipo_uso));
  }
  return [...grouped.values()]
    .sort((a, b) => b.pedidos - a.pedidos || collator.compare(a.cliente, b.cliente))
    .map((customer, index) => ({ ...customer, usos: [...customer.usos], puesto: index + 1 }));
}

function customerUsageLabel(customer) {
  const usages = [...new Set((customer.usos || []).map(normalizeUsageType))];
  if (usages.length <= 1) return usageLabel(usages[0] || 'indeterminado');
  return `MIXTO · ${usages.map(usageLabel).join(' + ')}`;
}

function calculateStats() {
  const total = state.records.reduce((sum, record) => sum + (Number(record.monto) || 0), 0);
  $('totalAmount').textContent = formatCurrency(total);
  $('recordCount').textContent = String(state.records.length);
  const totalLitres = state.records.reduce((sum, record) => sum + (Number(record.litros) || 0), 0);
  $('totalLitres').textContent = formatLitres(totalLitres);
  const ranking = getCustomerFrequency();
  const leader = ranking[0] || null;
  $('frequentClient').textContent = leader ? leader.cliente : 'Sin registros';
  $('frequentCount').textContent = leader ? `${leader.pedidos} ${leader.pedidos === 1 ? 'pedido' : 'pedidos'}` : 'Aún no hay actividad';
  $('frequentNumber').textContent = leader ? String(leader.pedidos).padStart(2, '0') : '—';
}

function createPodiumCard(customer, position) {
  const card = document.createElement('article');
  card.className = `podium-card place-${position}`;
  const place = document.createElement('div');
  place.className = 'podium-position';
  place.textContent = frequencyLabel(position);
  card.append(place);
  if (customer) {
    const name = document.createElement('div');
    name.className = 'podium-name';
    name.textContent = customer.cliente;
    const count = document.createElement('div');
    count.className = 'podium-count';
    count.textContent = `${customer.pedidos} ${customer.pedidos === 1 ? 'pedido' : 'pedidos'}`;
    const volume = document.createElement('div');
    volume.className = 'podium-volume';
    volume.textContent = `${formatLitres(customer.litrosTotal)} solicitados`;
    const usage = document.createElement('div');
    usage.className = 'podium-usage';
    usage.textContent = customerUsageLabel(customer);
    card.append(name, count, volume, usage);
  } else {
    const empty = document.createElement('div');
    empty.className = 'podium-empty';
    empty.textContent = 'Aún no hay un cliente en este puesto.';
    card.append(empty);
  }
  return card;
}

function renderFrequency() {
  const ranking = getCustomerFrequency();
  const podium = $('podiumGrid');
  const others = $('otherCustomersList');
  if (!podium || !others) return;
  $('frequencyCustomerTotal').textContent = String(ranking.length);
  $('frequencyOrderTotal').textContent = String(state.records.length);
  const totalLitres = state.records.reduce((sum, record) => sum + (Number(record.litros) || 0), 0);
  $('frequencyLitresTotal').textContent = formatLitres(totalLitres);
  $('frequencyLeader').textContent = ranking[0] ? ranking[0].cliente : 'Sin registros';
  $('otherCustomerCount').textContent = `${Math.max(0, ranking.length - 3)} ${ranking.length - 3 === 1 ? 'CLIENTE' : 'CLIENTES'}`;
  podium.replaceChildren();
  for (let position = 1; position <= 3; position++) {
    podium.append(createPodiumCard(ranking[position - 1] || null, position));
  }
  others.replaceChildren();
  const remaining = ranking.slice(3);
  if (!remaining.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    const title = document.createElement('strong');
    title.textContent = ranking.length ? 'Los tres puestos están definidos' : 'Cartera por iniciar';
    const description = document.createElement('span');
    description.textContent = ranking.length
      ? 'Cuando registres más clientes, aparecerán aquí los que estén fuera de los tres primeros puestos.'
      : 'Añade pedidos para crear automáticamente la clasificación de frecuencia.';
    empty.append(title, description);
    others.append(empty);
    return;
  }
  for (const customer of remaining) {
    const card = document.createElement('article');
    card.className = 'other-customer-card';
    const identity = document.createElement('div');
    identity.style.minWidth = '0';
    const name = document.createElement('div');
    name.className = 'other-customer-name';
    name.textContent = customer.cliente;
    const meta = document.createElement('div');
    meta.className = 'other-customer-meta';
    meta.textContent = `CLIENTE N.º ${customer.puesto} · ${customerUsageLabel(customer)}`;
    identity.append(name, meta);
    const count = document.createElement('div');
    count.className = 'other-customer-count';
    count.textContent = String(customer.pedidos);
    const unit = document.createElement('small');
    unit.textContent = customer.pedidos === 1 ? 'PEDIDO' : 'PEDIDOS';
    const volume = document.createElement('small');
    volume.textContent = formatLitres(customer.litrosTotal);
    count.append(unit, volume);
    card.append(identity, count);
    others.append(card);
  }
}

/* -------------------- Records UI -------------------- */
function createRecordCard(record, frequencyMap) {
  const card = document.createElement('article');
  card.className = 'record-card';
  const top = document.createElement('div');
  top.className = 'record-top';
  const identity = document.createElement('div');
  identity.className = 'record-identity';
  const name = document.createElement('div');
  name.className = 'record-name';
  name.textContent = record.cliente || 'Cliente sin nombre';
  identity.append(name);
  if (record.observaciones && String(record.observaciones).trim()) {
    const observations = document.createElement('div');
    observations.className = 'record-observations record-observations-inline';
    const heading = document.createElement('strong');
    heading.textContent = 'OBSERVACIONES';
    const content = document.createElement('span');
    content.textContent = String(record.observaciones).trim();
    observations.append(heading, content);
    identity.append(observations);
  }
  const side = document.createElement('div');
  side.className = 'record-side';
  const amount = document.createElement('div');
  amount.className = 'record-amount';
  amount.textContent = formatCurrency(record.monto);
  side.append(amount);
  const water = document.createElement('span');
  water.className = 'water-badge';
  water.textContent = `${formatLitres(record.litros)} · ${usageLabel(record.tipo_uso)}`;
  side.append(water);
  const customerFrequency = frequencyMap.get(normalizeText(record.cliente));
  if (customerFrequency) {
    const badge = document.createElement('span');
    badge.className = `frequency-badge${customerFrequency.puesto <= 3 ? ` rank-${customerFrequency.puesto}` : ''}`;
    badge.textContent = customerFrequency.puesto <= 3
      ? `N.º ${customerFrequency.puesto} · ${customerFrequency.pedidos} PED.`
      : `${customerFrequency.pedidos} PEDIDOS`;
    side.append(badge);
  }
  top.append(identity, side);
  card.append(top);

  if (record.recordatorio_fecha || record.recordatorio_hora) {
    const reminder = document.createElement('div');
    reminder.className = `record-reminder${record.completado ? ' done' : ''}`;
    const stateText = record.completado ? 'ACEPTADO' : 'PENDIENTE';
    reminder.textContent = `RECORDATORIO ${stateText} · ${formatDate(record.recordatorio_fecha)} · ${record.recordatorio_hora || 'Hora no definida'}${record.recordatorio_nota ? ` · ${record.recordatorio_nota}` : ''}`;
    card.append(reminder);
  }

  const lowerMeta = document.createElement('div');
  lowerMeta.className = 'record-lower-meta';
  const meta = document.createElement('div');
  meta.className = 'record-meta record-date';
  meta.textContent = `${(record.dia || '').toUpperCase()} · ${formatDate(record.fecha)} · ${record.hora || '--:--'}`;
  lowerMeta.append(meta);

  const actions = document.createElement('div');
  actions.className = 'record-actions';
  const edit = document.createElement('button');
  edit.type = 'button';
  edit.className = 'mini-btn';
  edit.textContent = 'EDITAR';
  edit.addEventListener('click', () => openEditForm(record.id));
  const remove = document.createElement('button');
  remove.type = 'button';
  remove.className = 'mini-btn danger';
  remove.textContent = 'ELIMINAR';
  remove.addEventListener('click', () => deleteRecord(record.id));
  actions.append(edit, remove);

  card.append(lowerMeta, actions);
  return card;
}

function renderRecords() {
  const container = $('recordsList');
  const query = normalizeText($('searchInput').value);
  const visible = sortedRecords().filter(record => !query || normalizeText(record.cliente).includes(query));
  const frequencyMap = new Map(getCustomerFrequency().map(customer => [customer.key, customer]));
  container.replaceChildren();
  $('visibleCount').textContent = `${visible.length} ${visible.length === 1 ? 'REGISTRO' : 'REGISTROS'}`;
  if (!visible.length) {
    const empty = document.createElement('div');
    empty.className = 'empty-state';
    const title = document.createElement('strong');
    title.textContent = query ? 'Sin coincidencias' : 'Cartera por iniciar';
    const description = document.createElement('span');
    description.textContent = query
      ? 'Prueba con otro nombre o término de búsqueda.'
      : 'Añade el primer registro para comenzar a organizar el espacio compartido.';
    empty.append(title, description);
    container.append(empty);
  } else {
    visible.forEach(record => container.append(createRecordCard(record, frequencyMap)));
  }
  calculateStats();
  renderFrequency();
  setConnectionBadge();
  checkDueReminders();
}

function setActiveViewButton(view) {
  $('homeBtn').classList.toggle('active', view === 'dashboard');
  $('frequencyBtn').classList.toggle('active', view === 'frequency');
}

function showDashboard() {
  state.currentView = 'dashboard';
  $('dashboardView').classList.remove('hidden');
  $('frequencyView').classList.add('hidden');
  setActiveViewButton('dashboard');
  $('searchInput').value = '';
  renderRecords();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showFrequency() {
  if (state.recognition) stopDictation(true, false);
  state.currentView = 'frequency';
  $('dashboardView').classList.add('hidden');
  $('frequencyView').classList.remove('hidden');
  setActiveViewButton('frequency');
  renderFrequency();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

/* -------------------- Overlays -------------------- */
function openOverlay(id) {
  $(id).classList.add('show');
  $(id).setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeOverlay(id) {
  $(id).classList.remove('show');
  $(id).setAttribute('aria-hidden', 'true');
  if (!$('formOverlay').classList.contains('show') &&
      !$('reminderOverlay').classList.contains('show') &&
      !$('settingsOverlay').classList.contains('show') &&
      !$('voiceFallbackOverlay').classList.contains('show')) {
    document.body.style.overflow = '';
  }
}

function resetForm() {
  $('recordForm').reset();
  state.editingId = null;
  $('formTitle').textContent = 'Nuevo registro';
  $('saveRecordBtn').textContent = 'GUARDAR REGISTRO';
  $('voiceFab').classList.remove('listening');
  $('voiceFab').classList.add('hidden');
  $('voiceFab').setAttribute('aria-pressed', 'false');
  $('voiceFabLabel').textContent = 'INICIAR DICTADO';
  $('voiceStatus').classList.add('hidden');
}

function openNewForm() {
  resetForm();
  $('voiceFab').classList.remove('hidden');
  openOverlay('formOverlay');
  setTimeout(() => $('clientInput').focus(), 80);
}

function openEditForm(id) {
  const record = state.records.find(item => item.id === id);
  if (!record) return;
  resetForm();
  state.editingId = id;
  $('formTitle').textContent = 'Editar registro';
  $('saveRecordBtn').textContent = 'GUARDAR CAMBIOS';
  $('clientInput').value = record.cliente || '';
  $('amountInput').value = Number(record.monto || 0).toFixed(2);
  $('litresInput').value = Number(record.litros || 0).toFixed(2);
  $('usageTypeInput').value = normalizeUsageType(record.tipo_uso);
  $('observationsInput').value = record.observaciones || '';
  $('reminderDateInput').value = record.recordatorio_fecha || '';
  $('reminderTimeInput').value = record.recordatorio_hora || '';
  $('reminderNoteInput').value = record.recordatorio_nota || '';
  openOverlay('formOverlay');
  setTimeout(() => $('clientInput').focus(), 80);
}

function markPending(record) {
  state.pendingUpserts[record.id] = { ...record, _synced: false };
  persistState();
}

function saveRecord(event) {
  event.preventDefault();
  if (state.recognition) stopDictation(false);
  const cliente = $('clientInput').value.trim();
  const monto = Number($('amountInput').value);
  const litros = Number($('litresInput').value);
  const tipoUso = normalizeUsageType($('usageTypeInput').value);
  const observaciones = $('observationsInput').value.trim();
  const reminderDate = $('reminderDateInput').value || null;
  const reminderTime = $('reminderTimeInput').value || null;
  const reminderNote = $('reminderNoteInput').value.trim();
  if (!cliente) { showToast('Escribe el nombre del cliente.', true); return; }
  if (!Number.isFinite(monto) || monto < 0) { showToast('Ingresa un monto válido.', true); return; }
  if (!Number.isFinite(litros) || litros < 0 || (!state.editingId && litros <= 0)) {
    showToast('Indica una cantidad válida de litros. Los pedidos nuevos deben ser mayores que cero.', true);
    return;
  }
  if (reminderTime && !reminderDate) {
    showToast('Para programar una hora, indica también la fecha.', true);
    return;
  }
  const now = new Date();
  const parts = localDateParts(now);
  const old = state.editingId ? state.records.find(item => item.id === state.editingId) : null;
  const record = {
    id: state.editingId || makeId(),
    cliente,
    fecha: parts.date,
    hora: parts.time,
    dia: weekdaySpanish(now),
    monto: Number(monto.toFixed(2)),
    litros: Number(litros.toFixed(2)),
    tipo_uso: tipoUso,
    observaciones: observaciones || null,
    recordatorio_fecha: reminderDate,
    recordatorio_hora: reminderTime,
    recordatorio_nota: reminderNote || null,
    completado: old && old.recordatorio_fecha === reminderDate && old.recordatorio_hora === reminderTime ? Boolean(old.completado) : false,
    updated_at: now.toISOString(),
    _synced: false
  };
  const index = state.records.findIndex(item => item.id === record.id);
  if (index >= 0) state.records[index] = record;
  else state.records.push(record);
  markPending(record);
  persistState();
  renderRecords();
  closeOverlay('formOverlay');
  resetForm();
  showToast(old ? 'Registro actualizado y guardado en este dispositivo.' : 'Registro guardado en este dispositivo.');
  if (navigator.onLine && hasSupabaseConfig()) syncNow(true);
}

function deleteRecord(id) {
  const record = state.records.find(item => item.id === id);
  if (!record) return;
  if (!window.confirm(`¿Eliminar el registro de ${record.cliente}?`)) return;
  if (!window.confirm(`Confirmación adicional: esta acción eliminará definitivamente el registro de ${record.cliente}. ¿Deseas continuar?`)) return;
  state.records = state.records.filter(item => item.id !== id);
  delete state.pendingUpserts[id];
  if (!state.pendingDeletes.includes(id)) state.pendingDeletes.push(id);
  if (state.activeReminderId === id) state.activeReminderId = null;
  persistState();
  renderRecords();
  showToast('Registro eliminado localmente. La eliminación se sincronizará al recuperar conexión.');
  if (navigator.onLine && hasSupabaseConfig()) syncNow(true);
}

/* -------------------- Reminders -------------------- */
function getDueReminders() {
  const now = localDateParts();
  const nowKey = `${now.date}T${now.time}`;
  return state.records
    .filter(r => !r.completado && r.recordatorio_fecha && r.recordatorio_hora && `${r.recordatorio_fecha}T${r.recordatorio_hora.slice(0, 5)}` <= nowKey)
    .sort((a, b) => (`${a.recordatorio_fecha}T${a.recordatorio_hora}`).localeCompare(`${b.recordatorio_fecha}T${b.recordatorio_hora}`));
}

function checkDueReminders() {
  if (!state.unlocked || $('reminderOverlay').classList.contains('show')) return;
  const due = getDueReminders();
  if (!due.length) return;
  const reminder = due[0];
  const notifiedKey = `dominium_notified_${reminder.id}_${reminder.recordatorio_fecha}_${reminder.recordatorio_hora}`;
  let alreadyNotified = false;
  try { alreadyNotified = localStorage.getItem(notifiedKey) === '1'; } catch {}
  if (!alreadyNotified) {
    sendReminderNotification(reminder);
    try { localStorage.setItem(notifiedKey, '1'); } catch {}
  }
  state.activeReminderId = reminder.id;
  $('reminderClient').textContent = reminder.cliente;
  $('reminderAmount').textContent = formatCurrency(reminder.monto);
  $('reminderDate').textContent = formatDate(reminder.recordatorio_fecha);
  $('reminderTime').textContent = reminder.recordatorio_hora || '—';
  if (reminder.recordatorio_nota) {
    $('reminderNote').textContent = `NOTA: ${reminder.recordatorio_nota}`;
    $('reminderNote').classList.remove('hidden');
  } else {
    $('reminderNote').textContent = '';
    $('reminderNote').classList.add('hidden');
  }
  openOverlay('reminderOverlay');
}

function acceptReminder() {
  const record = state.records.find(item => item.id === state.activeReminderId);
  if (record) {
    record.completado = true;
    record.updated_at = new Date().toISOString();
    record._synced = false;
    markPending(record);
    persistState();
  }
  state.activeReminderId = null;
  closeOverlay('reminderOverlay');
  renderRecords();
  if (navigator.onLine && hasSupabaseConfig()) syncNow(true);
  setTimeout(checkDueReminders, 90);
}

/* -------------------- Voice -------------------- */
function setVoiceUi(listening, message, isError = false) {
  $('voiceFab').classList.toggle('listening', listening);
  $('voiceFab').setAttribute('aria-pressed', listening ? 'true' : 'false');
  $('voiceFabLabel').textContent = listening ? 'DETENER DICTADO' : 'INICIAR DICTADO';
  $('voiceFab').setAttribute('aria-label', listening ? 'Detener dictado por voz' : 'Iniciar dictado por voz');
  $('voiceStatus').textContent = message;
  $('voiceStatus').classList.toggle('hidden', !listening);
  if (isError && message) showToast(message, true);
}

function extractVoiceFields(rawText) {
  let text = String(rawText || '').replace(/cerrar\s+dictado/ig, ' ').trim();
  let client = '';
  let amount = '';
  let litres = '';
  let usage = '';
  let reminderDate = '';
  let reminderTime = '';
  let observations = '';

  const observationsMatch = text.match(/\bobservaci[oó]n(?:es)?\b\s*(?:son|es|:|,)?\s*(.+)$/i);
  if (observationsMatch) {
    observations = observationsMatch[1].trim().replace(/[.,;]+$/, '');
    text = text.replace(observationsMatch[0], ' ');
  }

  const clientMatch = text.match(/\bcliente\s+(.+?)(?=\s+(?:monto|litros?|cantidad|tipo\s+de\s+uso|uso|para\s+consumo|para\s+comercio|consumo|comercio|indeterminado|recordatorio|pasado\s+mañana|pasado\s+manana|mañana|manana|hoy)\b|$)/i);
  if (clientMatch) {
    client = clientMatch[1].trim().replace(/[.,;]+$/, '');
    text = text.replace(clientMatch[0], ' ');
  }

  if (!clientMatch) {
    const prefix = text.replace(/^(?:agrega|añade|registra|registrar|pedido para|pedido de|el cliente)\s+/i, '')
      .match(/^([a-záéíóúñ][a-záéíóúñ' -]{1,70}?)(?=\s+(?:pidio|pidió|solicito|solicitó|quiere|necesita|por|cuesta|son|monto|\d|para|con|recordatorio)\b|$)/i);
    if (prefix) {
      client = prefix[1].trim();
      text = text.replace(prefix[0], ' ');
    }
  }

  const amountMatch = text.match(/(?:\bmonto\s*(?:de\s*)?|\bpor\s+|\bcuesta\s+|\bson\s+)?(?:soles?\s*)?(?:s\/?\.?\s*)?(\d+(?:[.,]\d{1,2})?)\s*(?:soles?)?/i);
  if (amountMatch && /(?:monto|por|cuesta|son|soles|s\/)/i.test(amountMatch[0])) {
    amount = amountMatch[1].replace(',', '.');
    text = text.replace(amountMatch[0], ' ');
  }

  const litresMatch = text.match(/\b(?:cantidad(?:\s+de)?|litros?)\s*(?:de\s*)?(\d+(?:[.,]\d+)?)\s*(?:litros?)?\b|\b(\d+(?:[.,]\d+)?)\s*litros?\b/i);
  if (litresMatch) {
    litres = String(litresMatch[1] || litresMatch[2]).replace(',', '.');
    text = text.replace(litresMatch[0], ' ');
  }

  const usageMatch = text.match(/\b(?:para\s+)?(consumo|comercio|indeterminado|comercial)\b/i);
  if (usageMatch) {
    const normalizedUsage = normalizeText(usageMatch[1]);
    usage = normalizedUsage === 'comercial' ? 'comercio' : normalizedUsage;
    text = text.replace(usageMatch[0], ' ');
  }
  text = text.replace(/\b(?:tipo\s+de\s+uso|uso)\b/ig, ' ');

  const dateMatch = text.match(/\bpasado\s+mañana\b|\bpasado\s+manana\b|\bmañana\b|\bmanana\b|\bhoy\b|\b\d{4}-\d{2}-\d{2}\b/i);
  if (dateMatch) {
    const normalizedDate = normalizeText(dateMatch[0]);
    const today = new Date();
    if (normalizedDate === 'hoy') reminderDate = localDateParts(today).date;
    else if (normalizedDate === 'manana') {
      today.setDate(today.getDate() + 1);
      reminderDate = localDateParts(today).date;
    } else if (normalizedDate === 'pasado manana') {
      today.setDate(today.getDate() + 2);
      reminderDate = localDateParts(today).date;
    } else reminderDate = dateMatch[0];
    text = text.replace(dateMatch[0], ' ');
  }

  const timeMatch = text.match(/\b(?:a\s+las?\s*)?(\d{1,2})\s*:\s*(\d{2})\b|\b(?:a\s+las?\s*)(\d{1,2})\s+(?:y\s+)?(\d{2})\b/i);
  if (timeMatch) {
    const hour = Number(timeMatch[1] || timeMatch[3]);
    const minute = Number(timeMatch[2] || timeMatch[4]);
    if (hour >= 0 && hour <= 23 && minute >= 0 && minute <= 59) {
      reminderTime = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
    }
    text = text.replace(timeMatch[0], ' ');
  }

  let note = text
    .replace(/\brecordatorio\b/ig, ' ')
    .replace(/\bcliente\b/ig, ' ')
    .replace(/\bmonto\b/ig, ' ')
    .replace(/\blitros?\b/ig, ' ')
    .replace(/\bcantidad\b/ig, ' ')
    .replace(/\b(consumo|comercio|comercial|indeterminado)\b/ig, ' ')
    .replace(/\b(tipo\s+de\s+uso|uso)\b/ig, ' ')
    .replace(/\ba\s+las?\b/ig, ' ')
    .replace(/[,:;.!?]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/cerrar\s+dictado/ig, '').trim();

  if (client) $('clientInput').value = client;
  if (amount !== '') $('amountInput').value = amount;
  if (litres !== '') $('litresInput').value = litres;
  if (usage) $('usageTypeInput').value = usage;
  if (observations) $('observationsInput').value = observations;
  if (reminderDate) $('reminderDateInput').value = reminderDate;
  if (reminderTime) $('reminderTimeInput').value = reminderTime;
  if (note && $('reminderNoteInput')) $('reminderNoteInput').value = note;

  const changes = [];
  if (client) changes.push('cliente');
  if (amount !== '') changes.push('monto');
  if (litres !== '') changes.push('litros');
  if (usage) changes.push(`uso ${usage}`);
  if (observations) changes.push('observaciones');
  if (reminderDate) changes.push('fecha');
  if (reminderTime) changes.push('hora');
  if (note) changes.push('nota');
  return { changes };
}

function runVoiceInput(rawText) {
  if (!$('formOverlay').classList.contains('show') || state.editingId || $('voiceFab').classList.contains('hidden')) {
    return { changes: [], command: false };
  }
  const text = String(rawText || '').trim();
  if (!text) return { changes: [], command: false };
  const result = extractVoiceFields(text);
  if (result.changes.length) {
    setVoiceUi(false, 'Datos reconocidos. Revisa los campos antes de guardar.');
    showToast('Dictado aplicado al formulario.');
  } else {
    setVoiceUi(false, 'No se reconocieron los datos. Inténtalo nuevamente.', true);
  }
  return result;
}

function stopDictation(processText = true, voiceCommand = false) {
  if (!state.recognition) return;
  state.voiceStopping = true;
  const recognition = state.recognition;
  try { recognition.stop(); } catch {}
  state.recognition = null;
  const transcript = state.voiceTranscript || '';
  setVoiceUi(false, voiceCommand ? 'Dictado finalizado por orden de voz.' : 'Dictado detenido.');
  if (processText && transcript) runVoiceInput(transcript);
  state.voiceTranscript = '';
  setTimeout(() => { state.voiceStopping = false; }, 250);
}

function startDictation() {
  if (!$('formOverlay').classList.contains('show') || state.editingId || $('voiceFab').classList.contains('hidden')) return;
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SpeechRecognition) {
    openOverlay('voiceFallbackOverlay');
    $('voiceFallbackText').value = '';
    setVoiceUi(false, 'Usa el micrófono del teclado del teléfono para dictar.');
    setTimeout(() => $('voiceFallbackText').focus(), 100);
    return;
  }
  if (state.recognition) return;
  let recognition;
  try {
    recognition = new SpeechRecognition();
  } catch {
    openOverlay('voiceFallbackOverlay');
    $('voiceFallbackText').focus();
    setVoiceUi(false, 'No fue posible iniciar el reconocimiento de voz. Usa el micrófono del teclado.', true);
    return;
  }
  state.recognition = recognition;
  state.voiceTranscript = '';
  state.voiceStopping = false;
  recognition.lang = 'es-PE';
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.maxAlternatives = 1;
  recognition.onstart = () => setVoiceUi(true, 'Escuchando.');
  recognition.onresult = (event) => {
    let transcript = '';
    for (let i = 0; i < event.results.length; i++) {
      if (event.results[i] && event.results[i][0]) transcript += `${event.results[i][0].transcript} `;
    }
    state.voiceTranscript = transcript.trim();
    const normalized = normalizeText(state.voiceTranscript);
    if (/\bcerrar\s+dictado\b/.test(normalized)) {
      state.voiceTranscript = state.voiceTranscript.replace(/cerrar\s+dictado/ig, ' ').trim();
      stopDictation(true, true);
    } else {
      setVoiceUi(true, state.voiceTranscript ? `Escuchando: ${state.voiceTranscript}` : 'Escuchando...');
    }
  };
  recognition.onerror = (event) => {
    const messages = {
      'not-allowed': 'Permiso de micrófono denegado. Autoriza el micrófono en los ajustes del navegador.',
      'service-not-allowed': 'El navegador bloqueó el servicio de voz. Revisa permisos y conexión.',
      'audio-capture': 'No se encontró un micrófono disponible.',
      'no-speech': 'No se detectó voz. Puedes volver a iniciar el dictado.',
      'network': 'El servicio de reconocimiento de voz requiere conexión en este navegador.',
      'aborted': 'El dictado fue cancelado.'
    };
    if (!state.voiceStopping) setVoiceUi(false, messages[event.error] || `Error de voz: ${event.error}.`, true);
    if (['not-allowed', 'service-not-allowed', 'network', 'language-not-supported'].includes(event.error)) {
      openOverlay('voiceFallbackOverlay');
    }
    state.recognition = null;
  };
  recognition.onend = () => {
    if (state.recognition === recognition) state.recognition = null;
    if (!state.voiceStopping && $('voiceFab').classList.contains('listening')) {
      setVoiceUi(false, 'El reconocimiento terminó. Puedes iniciar nuevamente.', true);
    }
  };
  try {
    recognition.start();
  } catch {
    state.recognition = null;
    openOverlay('voiceFallbackOverlay');
    setVoiceUi(false, 'No se pudo iniciar el micrófono web. Usa el micrófono del teclado.', true);
  }
}

/* -------------------- Supabase -------------------- */
function hasSupabaseConfig() {
  return /^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(SUPABASE_URL)
    && Boolean(SUPABASE_PUBLISHABLE_KEY)
    && !SUPABASE_PUBLISHABLE_KEY.includes('PEGA_AQUI');
}

function loadSupabaseLibrary() {
  return new Promise((resolve, reject) => {
    if (window.supabase && window.supabase.createClient) {
      resolve(window.supabase);
      return;
    }
    if (!navigator.onLine) {
      reject(new Error('Sin conexión a internet.'));
      return;
    }
    const existing = document.querySelector('script[data-supabase-sdk]');
    if (existing) {
      existing.addEventListener('load', () => resolve(window.supabase), { once: true });
      existing.addEventListener('error', () => reject(new Error('No se pudo cargar Supabase JS.')), { once: true });
      return;
    }
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
    script.async = true;
    script.dataset.supabaseSdk = 'true';
    script.onload = () => window.supabase ? resolve(window.supabase) : reject(new Error('La biblioteca de Supabase no está disponible.'));
    script.onerror = () => reject(new Error('No se pudo descargar @supabase/supabase-js@2.'));
    document.head.appendChild(script);
  });
}

async function ensureSupabaseReady() {
  if (state.supabase) return state.supabase;
  if (!hasSupabaseConfig()) throw new Error('Falta configurar SUPABASE_URL y SUPABASE_PUBLISHABLE_KEY en el código.');
  const lib = await loadSupabaseLibrary();
  state.supabase = lib.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
    auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false }
  });
  return state.supabase;
}

async function initializeSupabase() {
  if (!hasSupabaseConfig()) {
    $('syncStatus').textContent = 'Modo local: falta configurar la conexión interna de Supabase en el código.';
    state.realtimeConnected = false;
    setConnectionBadge();
    return;
  }
  if (!navigator.onLine) return;
  try {
    await ensureSupabaseReady();
    await subscribeToRealtime();
    await syncNow(true);
  } catch (error) {
    state.realtimeConnected = false;
    $('syncStatus').textContent = `Supabase no disponible: ${error.message || 'error de conexión'}`;
    setConnectionBadge();
  }
}

function toRemote(record) {
  return {
    id: record.id,
    cliente: record.cliente,
    fecha: record.fecha,
    hora: record.hora,
    dia: record.dia,
    monto: Number(record.monto || 0),
    litros: Number(record.litros || 0),
    tipo_uso: normalizeUsageType(record.tipo_uso),
    observaciones: record.observaciones || null,
    recordatorio_fecha: record.recordatorio_fecha || null,
    recordatorio_hora: record.recordatorio_hora || null,
    recordatorio_nota: record.recordatorio_nota || null,
    completado: Boolean(record.completado),
    deleted_at: null,
    updated_at: record.updated_at || new Date().toISOString()
  };
}

function fromRemote(row) {
  return {
    id: row.id,
    cliente: row.cliente,
    fecha: row.fecha,
    hora: String(row.hora || '').slice(0, 5),
    dia: row.dia,
    monto: Number(row.monto || 0),
    litros: Number(row.litros || 0),
    tipo_uso: normalizeUsageType(row.tipo_uso),
    observaciones: row.observaciones || null,
    recordatorio_fecha: row.recordatorio_fecha || null,
    recordatorio_hora: row.recordatorio_hora ? String(row.recordatorio_hora).slice(0, 5) : null,
    recordatorio_nota: row.recordatorio_nota || null,
    completado: Boolean(row.completado),
    deleted_at: row.deleted_at || null,
    updated_at: row.updated_at || new Date().toISOString(),
    _synced: true
  };
}

function stopRealtimeSubscription() {
  if (state.realtimeChannel && state.supabase) {
    state.supabase.removeChannel(state.realtimeChannel).catch(() => {});
  }
  state.realtimeChannel = null;
  state.realtimeConnected = false;
}

function handleRealtimeChange(payload) {
  const row = payload && payload.new && payload.new.id
    ? payload.new
    : (payload && payload.old ? payload.old : null);
  if (!row || !row.id) return;

  const local = state.records.find(item => item.id === row.id);
  const pending = state.pendingUpserts[row.id];
  const remoteTime = Date.parse(row.updated_at || '') || 0;
  const localTime = Date.parse((pending || local || {}).updated_at || '') || 0;

  if (pending && localTime >= remoteTime && payload.eventType !== 'DELETE' && !row.deleted_at) return;

  if (payload.eventType === 'DELETE' || row.deleted_at) {
    state.records = state.records.filter(item => item.id !== row.id);
    delete state.pendingUpserts[row.id];
    state.pendingDeletes = state.pendingDeletes.filter(id => id !== row.id);
  } else {
    const remote = fromRemote(row);
    const index = state.records.findIndex(item => item.id === row.id);
    if (index >= 0) state.records[index] = remote;
    else state.records.push(remote);
    delete state.pendingUpserts[row.id];
  }

  persistState();
  renderRecords();
  checkDueReminders();
  $('syncStatus').textContent = 'Cambio recibido en tiempo real desde otro dispositivo.';
  setConnectionBadge();
}

async function subscribeToRealtime() {
  if (!state.supabase || !navigator.onLine) return;
  if (state.realtimeChannel) return;

  const channel = state.supabase
    .channel('dominium-aureum-registros-compartidos')
    .on('postgres_changes', {
      event: '*', schema: 'public', table: 'registros'
    }, handleRealtimeChange);

  state.realtimeChannel = channel;
  channel.subscribe((status, error) => {
    if (status === 'SUBSCRIBED') {
      state.realtimeConnected = true;
      $('syncStatus').textContent = 'Conectado. Los cambios de este espacio se reciben en tiempo real en todos los dispositivos.';
      setConnectionBadge();
    } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
      state.realtimeConnected = false;
      $('syncStatus').textContent = `La conexión en tiempo real no está disponible (${status}). Se mantiene la sincronización manual.`;
      setConnectionBadge();
      if (error) console.warn('Supabase Realtime:', error);
    }
  });
}

async function restoreLocalDataForNewGeneration(client) {
  const { data: control, error } = await client.from('app_sync_control')
    .select('generation').eq('id', 1).single();
  if (error) throw new Error(`No se pudo verificar la versión de la base de datos. ${error.message || ''}`.trim());
  const serverGeneration = String(control && control.generation || SYNC_GENERATION_FALLBACK);
  let localGeneration = '';
  try { localGeneration = localStorage.getItem(SYNC_GENERATION_KEY) || ''; } catch {}
  if (localGeneration === serverGeneration) return;

  state.records = [];
  state.pendingUpserts = {};
  state.pendingDeletes = [];
  persistState();
  try { localStorage.setItem(SYNC_GENERATION_KEY, serverGeneration); } catch {}
  renderRecords();
}

async function syncNow(quiet = false) {
  if (state.syncing) return;
  if (!navigator.onLine) {
    $('syncStatus').textContent = 'Sin conexión. Los cambios permanecen guardados y se enviarán al recuperar internet.';
    setConnectionBadge();
    if (!quiet) showToast('Sin conexión. Se conserva todo localmente.', true);
    return;
  }
  if (!hasSupabaseConfig()) {
    $('syncStatus').textContent = 'Configura SUPABASE_URL y SUPABASE_PUBLISHABLE_KEY en el código para activar la sincronización.';
    if (!quiet) showToast('Falta configurar Supabase.', true);
    return;
  }

  state.syncing = true;
  $('syncBtn').disabled = true;
  $('syncBtnLabel').textContent = 'SYNC...';
  try {
    const client = await ensureSupabaseReady();
    await subscribeToRealtime();
    await restoreLocalDataForNewGeneration(client);
    $('syncStatus').textContent = 'Enviando cambios pendientes y conciliando el espacio compartido...';

    const deletes = [...state.pendingDeletes];
    for (const id of deletes) {
      const deletedAt = new Date().toISOString();
      const { error } = await client.from('registros')
        .update({ deleted_at: deletedAt, updated_at: deletedAt })
        .eq('id', id);
      if (error) throw error;
      state.pendingDeletes = state.pendingDeletes.filter(item => item !== id);
    }
    persistState();

    const pending = Object.values(state.pendingUpserts);
    for (const record of pending) {
      const { error } = await client.from('registros').upsert(toRemote(record), { onConflict: 'id' });
      if (error) throw error;
      delete state.pendingUpserts[record.id];
    }
    persistState();

    const { data: remoteRows, error: fetchError } = await client.from('registros')
      .select(REMOTE_RECORD_COLUMNS)
      .is('deleted_at', null);
    if (fetchError) throw fetchError;

    const remoteMap = new Map((remoteRows || []).map(row => [row.id, fromRemote(row)]));
    const localNext = [];
    for (const local of state.records) {
      if (Object.prototype.hasOwnProperty.call(state.pendingUpserts, local.id)) {
        localNext.push(local);
        continue;
      }
      const remote = remoteMap.get(local.id);
      if (remote) {
        const localTime = Date.parse(local.updated_at || 0) || 0;
        const remoteTime = Date.parse(remote.updated_at || 0) || 0;
        localNext.push(remoteTime > localTime ? remote : { ...local, _synced: true });
        remoteMap.delete(local.id);
      } else if (!local._synced) {
        localNext.push(local);
      }
    }
    for (const remote of remoteMap.values()) localNext.push(remote);
    state.records = localNext;
    persistState();
    renderRecords();

    const stamp = new Intl.DateTimeFormat('es-PE', { hour: '2-digit', minute: '2-digit' }).format(new Date());
    $('syncStatus').textContent = `Sincronización completada a las ${stamp}. Este espacio está actualizado.`;
    setConnectionBadge();
    if (!quiet) showToast('Sincronización completada.');
  } catch (error) {
    $('syncStatus').textContent = `No se pudo completar la sincronización: ${error.message || 'error desconocido'}. Los datos locales se conservaron.`;
    setConnectionBadge();
    if (!quiet) showToast('Error de sincronización. Los datos locales están intactos.', true);
  } finally {
    state.syncing = false;
    $('syncBtn').disabled = false;
    $('syncBtnLabel').textContent = 'NUBE';
  }
}

/* -------------------- Events & Init -------------------- */
function bindEvents() {
  $('unlockForm').addEventListener('submit', handleUnlock);
  $('passwordForm').addEventListener('submit', changePassword);
  $('enableNotificationsBtn').addEventListener('click', enableNotifications);
  $('testReminderSoundBtn').addEventListener('click', playReminderSound);
  $('reminderSoundEnabled').addEventListener('change', event => {
    try { localStorage.setItem(REMINDER_SOUND_KEY, event.target.checked ? '1' : '0'); } catch {}
  });
  $('disablePasswordToggle').addEventListener('change', event => setPasswordDisabled(event.target.checked));
  $('settingsBtn').addEventListener('click', openSettings);
  $('closeSettingsBtn').addEventListener('click', () => closeOverlay('settingsOverlay'));
  $('lockNowBtn').addEventListener('click', () => {
    closeOverlay('settingsOverlay');
    state.unlocked = false;
    document.body.classList.add('locked');
    $('securityOverlay').classList.remove('hidden');
    $('securityOverlay').setAttribute('aria-hidden', 'false');
    $('unlockPassword').focus();
  });
  $('newBtn').addEventListener('click', openNewForm);
  $('homeBtn').addEventListener('click', showDashboard);
  $('frequencyBtn').addEventListener('click', showFrequency);
  $('backToClientsBtn').addEventListener('click', showDashboard);
  $('closeFormBtn').addEventListener('click', () => {
    if (state.recognition) stopDictation(false);
    closeOverlay('formOverlay');
    resetForm();
  });
  $('cancelFormBtn').addEventListener('click', () => {
    if (state.recognition) stopDictation(false);
    closeOverlay('formOverlay');
    resetForm();
  });
  $('recordForm').addEventListener('submit', saveRecord);
  $('searchInput').addEventListener('input', renderRecords);
  $('voiceFab').addEventListener('click', () => {
    if (state.recognition) stopDictation(true, false);
    else startDictation();
  });
  $('processVoiceFallbackBtn').addEventListener('click', () => {
    const text = $('voiceFallbackText').value.trim();
    if (!text) { showToast('Dicta o escribe primero en el cuadro.', true); return; }
    closeOverlay('voiceFallbackOverlay');
    runVoiceInput(text);
    $('voiceFallbackText').value = '';
  });
  $('cancelVoiceFallbackBtn').addEventListener('click', () => closeOverlay('voiceFallbackOverlay'));
  $('acceptReminderBtn').addEventListener('click', acceptReminder);
  $('syncBtn').addEventListener('click', () => syncNow(false));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      if ($('reminderOverlay').classList.contains('show')) return;
      if (state.recognition) stopDictation(false);
      if ($('formOverlay').classList.contains('show')) { closeOverlay('formOverlay'); resetForm(); }
      if ($('settingsOverlay').classList.contains('show')) closeOverlay('settingsOverlay');
      if ($('voiceFallbackOverlay').classList.contains('show')) closeOverlay('voiceFallbackOverlay');
    }
  });
  window.addEventListener('online', () => {
    setConnectionBadge();
    if (hasSupabaseConfig()) initializeSupabase();
  });
  window.addEventListener('offline', () => {
    stopRealtimeSubscription();
    setConnectionBadge();
    $('syncStatus').textContent = 'Sin conexión. Los cambios se conservan localmente y se sincronizarán al volver internet.';
  });
  const resumeConnection = () => {
    if (document.visibilityState === 'hidden' || !navigator.onLine) return;
    setConnectionBadge();
    if (hasSupabaseConfig()) initializeSupabase();
    checkDueReminders();
  };
  window.addEventListener('focus', resumeConnection);
  window.addEventListener('pageshow', resumeConnection);
  document.addEventListener('visibilitychange', resumeConnection);
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', event => {
      if (event.data && event.data.type === 'DOMINIUM_SYNC_REQUEST' && navigator.onLine) {
        initializeSupabase();
      }
    });
  }
  window.addEventListener('storage', event => {
    if (event.key === STORAGE_KEY && event.newValue) {
      const incoming = safeParse(event.newValue);
      if (incoming) {
        state.records = Array.isArray(incoming.records) ? incoming.records : state.records;
        state.pendingUpserts = incoming.pendingUpserts || state.pendingUpserts;
        state.pendingDeletes = incoming.pendingDeletes || state.pendingDeletes;
        renderRecords();
      }
    }
  });
}

function initializeApp() {
  // Limpia en este dispositivo las preferencias y archivos de tonos personalizados ya eliminados.
  try {
    localStorage.removeItem('dominium_aureum_reminder_sound_mode_v1');
    localStorage.removeItem('dominium_aureum_custom_reminder_audio_v1');
    localStorage.removeItem('dominium_aureum_custom_reminder_audio_name_v1');
  } catch {}
  if (!passwordIsDisabled()) {
    document.body.classList.add('locked');
    $('securityOverlay').classList.remove('hidden');
    $('securityOverlay').setAttribute('aria-hidden', 'false');
  } else {
    $('securityOverlay').classList.add('hidden');
    $('securityOverlay').setAttribute('aria-hidden', 'true');
    state.unlocked = true;
  }
  getPasswordHash();
  loadState();
  bindEvents();
  updateHeaderDate();
  setActiveViewButton('dashboard');
  renderRecords();
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.ready.then(() => registerPeriodicRefresh()).catch(() => {});
  }
  if (navigator.onLine && hasSupabaseConfig()) initializeSupabase();
  setInterval(() => {
    updateHeaderDate();
    checkDueReminders();
  }, 15000);
}

document.addEventListener('DOMContentLoaded', initializeApp);
