# DOMINIUM AUREUM
### Dark Luxury & Future Tech · Mackenzie K. · Distribución de MK EXCLUSIF

Panel de administración exclusivo para control y seguimiento de clientes, pedidos de agua, recordatorios y sincronización multi-dispositivo.

## Características

- Diseño Dark Luxury con paleta oficial:
  - Negro Obsidiana `#0A0A0C`
  - Gris Antracita `#141418`
  - Dorado Champán `#D4AF37`
  - Oro Luminoso `#F3E5AB`
  - Blanco Marfil `#F8F9FA`
  - Gris Platino `#A0A5B1`
- Tipografía: Cormorant Garamond (títulos) + Montserrat (UI)
- Funciona como PWA instalable en móviles Android compatibles
- Service Worker con caché mejorada y modo de recuperación sin conexión
- Reintento de sincronización al recuperar internet, volver a la pestaña o reabrir la aplicación
- Compatibilidad preparada para Background Sync / Periodic Background Sync cuando el navegador y Android lo permitan
- Recepción de notificaciones push mediante Service Worker (requiere configurar un proveedor/servidor push)
- Almacenamiento local + sincronización Supabase en tiempo real
- Contraseña de acceso (hash SHA-256)
- Recordatorios con notificaciones y sonido predeterminado integrado (MP3 optimizado de 4,5 segundos)
- Dictado por voz (español Perú)
- Ranking de frecuencia de clientes
- Interfaz optimizada para móviles

## Cómo usar

1. Descomprime el ZIP y publica la carpeta `dominium-aureum` en un hosting HTTPS (por ejemplo, tu hosting actual). No abras el archivo directamente desde el administrador de archivos: Service Worker y PWA requieren HTTPS o localhost.
2. En el teléfono Android, abre la dirección HTTPS con Chrome.
3. Inicia sesión. Contraseña inicial por defecto: `123456`.
4. En Chrome, usa el menú → “Instalar aplicación” o “Añadir a pantalla de inicio”.
5. Acepta los permisos de notificaciones desde Ajustes de la aplicación. En Android, permite notificaciones y, si el fabricante restringe la actividad, configura la batería para no restringir Chrome.
6. Abre el sistema periódicamente para que se actualicen los datos y se reanuden los procesos de sincronización.

## Estructura

```
dominium-aureum/
├── index.html
├── css/styles.css
├── assets/reminder.mp3
├── js/app.js
├── sw.js              (Service Worker)
├── manifest.json
├── icons/
│   ├── icon-192.png
│   └── icon-512.png
└── README.md
```

## Notas técnicas

- La conexión Supabase ya está configurada en el código; los dispositivos que usen el mismo proyecto y espacio reciben cambios en tiempo real mientras la aplicación está conectada.
- Todos los datos se guardan primero en el dispositivo (offline-first).
- Al recuperar internet, volver a la aplicación o recuperar el foco, se intenta sincronizar automáticamente.
- Android/Chrome pueden suspender páginas web en segundo plano. Background Sync y Periodic Background Sync son capacidades opcionales y sujetas a las políticas de batería, permisos y versión del navegador.
- Una PWA dentro de un ZIP no puede arrancar por sí sola al encender el teléfono ni garantizar alarmas locales cuando Chrome está completamente cerrado.
- El Service Worker queda preparado para mostrar notificaciones push entrantes, pero para enviarlas cuando la aplicación está cerrada hace falta configurar un servicio push y sus credenciales; el proyecto actual no incluye ese servidor.
- El pie de página muestra: **Mackenzie K.** · **Distribución de MK EXCLUSIF**

---
*DOMINIUM AUREUM · Edición exclusiva*

## Base de datos Supabase

El archivo `DOMINIUM_AUREUM_RESET.sql` se entrega por separado del ZIP. Ejecútalo en el SQL Editor del proyecto Supabase para borrar las tablas anteriores de esta aplicación y recrearlas desde cero. **La operación elimina definitivamente los registros remotos existentes.** Después, vuelve a abrir la aplicación para que sincronice con la nueva generación de base de datos.
