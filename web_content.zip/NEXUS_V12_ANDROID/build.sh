#!/usr/bin/env bash
set -euo pipefail
if [ -x ./gradlew ]; then
  ./gradlew :app:assembleRelease
else
  if ! command -v gradle >/dev/null 2>&1; then
    echo 'ERRO: Gradle não encontrado. Instale Android Studio/Gradle e o Android SDK.' >&2
    exit 2
  fi
  gradle :app:assembleRelease
fi
