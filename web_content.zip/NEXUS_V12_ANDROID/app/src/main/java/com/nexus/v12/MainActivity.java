package com.nexus.v12;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.SafeBrowsingResponse;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceError;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.net.Uri;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class MainActivity extends Activity {
    private static final String ORIGIN = "https://nexus.local/";
    private static final String KEY_ALIAS = "NEXUS_V12_API_KEY";
    private static final String PREFS = "nexus_secure";
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private PermissionRequest pendingAudioRequest;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.addJavascriptInterface(new NexusBridge(this), "NexusNative");
        webView.loadDataWithBaseURL(ORIGIN, readAsset("index.html"), "text/html", "UTF-8", ORIGIN);
    }

    private String readAsset(String name) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open(name), StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) b.append(line).append('\n');
            return b.toString();
        } catch (Exception e) { return "<h1>NEXUS</h1><p>Falha ao carregar o núcleo.</p>"; }
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        webView.setBackgroundColor(0xFF0A0E17);
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !ORIGIN.equals(r.getUrl().toString()) && !r.getUrl().toString().startsWith(ORIGIN);
            }
            @Override public void onSafeBrowsingHit(WebView v, WebResourceRequest req, int threat, SafeBrowsingResponse cb) {
                cb.backToSafety(true);
            }
            @Override public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) { }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(final PermissionRequest req) {
                runOnUiThread(() -> {
                    boolean mic = false;
                    for (String r : req.getResources()) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) mic = true;
                    if (!mic) { req.deny(); return; }
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                        req.grant(req.getResources());
                    } else {
                        pendingAudioRequest = req;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1201);
                    }
                });
            }
        });
        CookieManager.getInstance().setAcceptCookie(false);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1201 && pendingAudioRequest != null) {
            PermissionRequest r = pendingAudioRequest; pendingAudioRequest = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) r.grant(r.getResources());
            else r.deny();
        }
    }

    @Override public void onDestroy() {
        executor.shutdownNow();
        if (webView != null) { webView.removeJavascriptInterface("NexusNative"); webView.destroy(); }
        super.onDestroy();
    }

    public class NexusBridge {
        private final Context ctx;
        NexusBridge(Context c) { ctx = c; }

        @JavascriptInterface public boolean hasApiKey() { return getApiKey() != null; }
        @JavascriptInterface public void setApiKey(String key) { if (key == null || key.trim().isEmpty()) clearApiKey(); else saveApiKey(key.trim()); }
        @JavascriptInterface public void clearApiKey() { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove("blob").apply(); }

        @JavascriptInterface public void askXai(final String requestJson, final String callbackId) {
            executor.execute(() -> {
                String result;
                try { result = requestXai(requestJson); }
                catch (Exception e) { result = "__ERROR__" + e.getMessage(); }
                final String js = "window.__nexusNativeResolve(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> webView.evaluateJavascript(js, null));
            });
        }

        private String requestXai(String requestJson) throws Exception {
            String key = getApiKey();
            if (key == null) throw new Exception("Chave xAI não configurada no cofre seguro.");
            JSONObject in = new JSONObject(requestJson);
            JSONArray msgs = in.getJSONArray("messages");
            JSONObject body = new JSONObject();
            body.put("model", in.optString("model", "grok-4"));
            body.put("messages", msgs);
            body.put("temperature", 0.7);

            URL u = new URL("https://api.x.ai/v1/chat/completions");
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(15000); c.setReadTimeout(90000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "Bearer " + key);
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
            int code = c.getResponseCode();
            BufferedReader r = new BufferedReader(new InputStreamReader(code >= 400 ? c.getErrorStream() : c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(); String line; while ((line = r.readLine()) != null) out.append(line);
            JSONObject data = new JSONObject(out.toString());
            if (code < 200 || code >= 300) throw new Exception(data.optJSONObject("error") != null ? data.getJSONObject("error").optString("message", "HTTP " + code) : "HTTP " + code);
            JSONArray choices = data.optJSONArray("choices");
            if (choices == null || choices.length() == 0) throw new Exception("Resposta vazia da API.");
            return choices.getJSONObject(0).getJSONObject("message").optString("content", "");
        }

        private void saveApiKey(String plain) {
            try {
                SecretKey k = getOrCreateKey();
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.ENCRYPT_MODE, k);
                byte[] ct = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
                String blob = Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
                ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("blob", blob).apply();
            } catch (Exception ignored) { }
        }
        private String getApiKey() {
            try {
                String blob = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("blob", null);
                if (blob == null) return null;
                String[] p = blob.split(":", 2);
                Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, Base64.decode(p[0], Base64.NO_WRAP)));
                return new String(cipher.doFinal(Base64.decode(p[1], Base64.NO_WRAP)), StandardCharsets.UTF_8);
            } catch (Exception e) { return null; }
        }
        private SecretKey getOrCreateKey() throws Exception {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore"); ks.load(null);
            if (ks.containsAlias(KEY_ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
            return kg.generateKey();
        }
    }
}
