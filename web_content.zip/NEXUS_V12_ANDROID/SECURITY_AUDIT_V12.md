# NEXUS V12 — auditoria de segurança

## Corrigido
1. API key: não fica mais persistida no localStorage.
2. API xAI: chamada movida para Java nativo.
3. Segredo: Android Keystore + AES-GCM.
4. WebView: file access/universal file access desligados.
5. Mixed content: NEVER_ALLOW.
6. Navegação: somente origem interna permitida.
7. Cookies: desativados.
8. Safe Browsing: habilitado quando disponível.
9. Permissão: somente INTERNET e RECORD_AUDIO no estado atual.

## Limitações honestas
- Não houve teste em hardware físico Redmi Note 14 Pro nesta execução.
- Não houve build final porque o ambiente não contém Android SDK/build-tools.
- Não declarar câmera/GPS/AR antes da implementação real evita permissões sem função.
- O segredo xAI continua sendo um segredo local do dispositivo; nenhum app cliente pode tornar uma chave de API permanente absolutamente impossível de extrair em um dispositivo comprometido.
