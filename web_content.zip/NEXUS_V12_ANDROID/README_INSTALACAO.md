# NEXUS V12 — Android

Projeto Android nativo que empacota o núcleo HTML do NEXUS em WebView com isolamento e ponte nativa mínima.

## Segurança implementada
- Conteúdo carregado em origem HTTPS sintética (`https://nexus.local/`) via `loadDataWithBaseURL`.
- `file://` e acesso universal a arquivos desativados.
- Conteúdo misto desativado.
- Safe Browsing habilitado quando disponível.
- Cookies desativados.
- Navegação externa bloqueada.
- Chave xAI removida do `localStorage`.
- Chave xAI armazenada cifrada com AES-GCM usando Android Keystore.
- Requisição xAI feita pelo código nativo, não por `fetch()` do JavaScript.
- Microfone é a única permissão sensível declarada nesta V12, porque a interface atual possui reconhecimento de voz.

## O que ainda NÃO está nesta V12
A interface-base recuperada não contém implementação real de câmera/GPS/AR/sensores. Essas permissões não foram adicionadas artificialmente ao manifesto. Elas entram somente quando o código correspondente estiver implementado e testado.

## Build
É necessário um ambiente Android com SDK/Build Tools. Este ambiente de trabalho não possui `aapt2`, `d8`, `apksigner` nem o Android SDK, então não foi possível produzir honestamente um APK assinado aqui.

Use Android Studio/Gradle ou um ambiente Android com SDK instalado para gerar:
`app/build/outputs/apk/release/app-release.apk`

Antes de distribuir, assine com uma chave sua e valide o APK.
