plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ua.k2signalhub.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ua.k2signalhub.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "3.0.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.10.0")
    implementation("androidx.webkit:webkit:1.12.1")
}
