GANADERO BRAVO - GENERAR APK DESDE EL MÓVIL

No necesitas instalar Android Studio en el móvil. Puedes compilar el APK con GitHub Actions en la nube.

PASOS
1. En el móvil, entra en github.com e inicia sesión o crea una cuenta.
2. Crea un repositorio nuevo llamado GanaderoBravoAndroid. Puedes dejarlo privado.
3. Sube el contenido de este ZIP al repositorio, manteniendo las carpetas y archivos (incluida la carpeta oculta .github/workflows).
   Consejo: descomprime el ZIP con un gestor de archivos. En GitHub web puedes usar Add file > Upload files; si no permite subir carpetas fácilmente, usa github.dev o la app/cliente Git.
4. En el repositorio, abre la pestaña Actions.
5. Si GitHub te pide habilitar Actions, acéptalo.
6. Abre “Build Ganadero Bravo APK” y pulsa “Run workflow”.
7. Cuando termine en verde, abre esa ejecución y busca “Artifacts”.
8. Descarga “Ganadero-Bravo-APK.zip” al móvil y descomprímelo. Dentro estará app-debug.apk.
9. Pulsa el APK para instalarlo. Android podría pedirte permitir instalar apps desde el navegador o gestor de archivos.

NOTAS
- El APK es una compilación de prueba (debug), adecuada para instalar manualmente, no para publicar en Google Play.
- El proyecto integra el juego HTML en una app Android WebView.
- Los temporizadores del juego pueden pausarse/retrasarse si Android pone la app en segundo plano.
- Si el flujo falla, abre la ejecución en Actions y comparte el mensaje de error para corregirlo.
