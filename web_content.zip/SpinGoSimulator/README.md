# Spin & Go Simulator (Android)

A WebView wrapper around the simulator page. The whole app is `app/src/main/assets/index.html`, so edit that file to change the simulator. It works offline and asks for no permissions.

## Build the APK

**Option A, no computer setup (GitHub):** create a new GitHub repo, upload everything in this folder (including the hidden `.github` folder), open the Actions tab, run "Build APK", then download the `SpinGoSimulator-apk` artifact. It contains `app-debug.apk`.

**Option B, Android Studio:** File > Open this folder, wait for the Gradle sync, then Build > Build APK(s). The APK lands in `app/build/outputs/apk/debug/`.

**Option C, command line:** needs JDK 17 and the Android SDK. Run `./gradlew assembleDebug`.

## Install

Copy `app-debug.apk` to your phone, open it, and allow installs from unknown sources when asked.

## Notes

- This is a debug-signed APK, fine for sideloading. Google Play needs a release signing key and targetSdk 35 in `app/build.gradle`.
- Stats are saved in the app's web storage, so clearing the app's data resets them.
