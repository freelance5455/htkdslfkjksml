दुकान वजन कैलकुलेटर Android प्रोजेक्ट

यह APK नहीं, Android Studio में APK बनाने के लिए प्रोजेक्ट सोर्स है।
APK बनाने के लिए:
1. Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें और Android Studio में DukaanCalculator फ़ोल्डर खोलें।
3. Gradle Sync पूरा होने दें।
4. Build > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगा।

ऐप HTML को Android WebView में ऑफलाइन चलाता है। इंटरनेट अनुमति शामिल नहीं है।
