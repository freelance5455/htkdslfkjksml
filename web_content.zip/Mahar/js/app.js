(()=>{
const ALPHA_CONFIG=window.ALPHA_CONFIG||{defaultCurrency:'AFN',contactEmail:'your-email@gmail.com'};
const KEY='alpha_os_v1', $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)], esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const D={theme:'dark',language:'en',currency:ALPHA_CONFIG.defaultCurrency,profile:{name:'Alpha User'},tasks:[],goals:[],habits:[],tx:[],projects:[],journal:[],wellness:{alarmTime:'06:00',alarmOn:false,routine:null}};
let S=load(), route='dashboard';
const DEFAULT_ROUTINE={
  en:[['Stretch & deep breathing',120],['Jumping jacks – 20 reps',45],['Plank hold',30],['Skipping rope',120],['Drink a glass of water',20]],
  fa:[['کشش و نفس عمیق',120],['جامپینگ جک – ۲۰ بار',45],['پلانک',30],['طناب زدن',120],['یک لیوان آب بنوش',20]],
  ps:[['غځونه او ژور ساه اخیستل',120],['جمپینګ جیک – ۲۰ ځله',45],['پلانک',30],['د پړي سره ټوپونه',120],['یو ګیلاس اوبه وڅښئ',20]],
  tr:[['Esneme ve derin nefes',120],['Jumping jack – 20 tekrar',45],['Plank',30],['İp atlama',120],['Bir bardak su iç',20]]
};
const QUOTES={
  en:['Small steps, every day, win.','You do not need more time, you need a plan.','Discipline is choosing what you want most over what you want now.','Todays effort is tomorrows ease.','Control your day before it controls you.','Progress, not perfection.','Start where you are, with what you have.'],
  fa:['قدم‌های کوچیک، هر روز، برنده می‌شن.','وقت بیشتر نمی‌خوای، یه برنامه می‌خوای.','نظم یعنی انتخاب چیزی که بیشتر می‌خوای، نه چیزی که همین الان می‌خوای.','تلاش امروز، راحتی فرداست.','قبل از اینکه روزت کنترلت کنه، تو کنترلش کن.','پیشرفت مهمه، نه کمال.','از همینجا که هستی شروع کن.'],
  ps:['کوچني ګامونه، هره ورځ، بریالي کیږي.','تاسو ته نور وخت نه، یوه پلان ته اړتیا لرئ.','نظم یعنې هغه څه غوره کړئ چې ډیر یې غواړئ.','د نن هڅه، د سبا آسانتیا ده.','مخکې له دې چې ستاسو ورځ تاسو کنترول کړي، تاسو یې کنترول کړئ.','پرمختګ مهم دی، نه کمال.','له هماغه ځایه پیل کړئ چې یاست.'],
  tr:['Kucuk adimlar, her gun, kazanir.','Daha fazla zamana degil, bir plana ihtiyacin var.','Disiplin, simdi istedigin yerine en cok istedigini secmektir.','Bugunun emegi, yarinin kolayligidir.','Gununu kontrol et, o seni kontrol etmeden.','Mukemmellik degil, ilerleme.','Bulundugun yerden, sahip olduklarinla basla.']
};
const T={en:{dashboard:'Dashboard',tasks:'Tasks',goals:'Goals',habits:'Habits',finance:'Finance',journal:'Journal',calendar:'Calendar',statistics:'Statistics',connect:'Connect Us',settings:'Settings',wellness:'Wellness',offlineReady:'Offline · local data',balance:'Balance',income:'Income',expenses:'Expenses',completion:'Task completion',today:'Today',month:'This month',recent:'Recent activity',quick:'Quick add',addTask:'Add task',addGoal:'Add goal',addHabit:'Add habit',addTx:'Add transaction',newEntry:'New entry',save:'Save',cancel:'Cancel',delete:'Delete',title:'Title',amount:'Amount',category:'Category',type:'Type',incomeType:'Income',expenseType:'Expense',date:'Date',description:'Description',language:'Language',currency:'Currency',theme:'Theme',dark:'Dark',light:'Light',backup:'Backup',restore:'Restore',reset:'Reset data',connectTitle:'Connect with Mahar',connectText:'Feedback, ideas or bug reports? Send us a message.',email:'Email',send:'Send email',noData:'Nothing here yet',progress:'Progress',streak:'day streak',mark:'Mark done',search:'Search',name:'Name',morning:'Good morning',afternoon:'Good afternoon',evening:'Good evening',vsLastMonth:'vs last month',newData:'no data last month',todayTasks:"Today's tasks",goalsOverview:'Goals overview',habitsToday:'Habits today',financeOverview:'Finance overview',expensesByCategory:'Expenses by category',quickNotes:'Quick notes',viewAll:'View all',done:'Done',allTime:'transactions - all time',morningRoutine:'Morning Routine',morningAlarm:'Morning Alarm',windDown:'Wind-down Sounds',addExercise:'Add exercise',exerciseName:'Exercise',startTimer:'Start',pauseTimer:'Pause',resetTimer:'Reset',skipExercise:'Skip',rain:'Rain',focusTone:'Focus tone',sleepTone:'Sleep tone',stopSound:'Stop',alarmHint:'Rings only while Mahar is open in your browser',allDoneMsg:'Routine complete!',upNext:'Up next',goalType:'Goal type',simpleGoal:'Simple goal',checklistGoal:'Goal with sub-tasks',addSubtask:'Add sub-task'},
fa:{dashboard:'داشبورد',tasks:'وظایف',goals:'هدف‌ها',habits:'عادت‌ها',finance:'مالی',journal:'خاطرات',calendar:'تقویم',statistics:'آمار',connect:'ارتباط با ما',settings:'تنظیمات',wellness:'سلامتی',offlineReady:'آفلاین · دادهٔ محلی',balance:'موجودی',income:'درآمد',expenses:'مصارف',completion:'درصد انجام وظایف',today:'امروز',month:'این ماه',recent:'فعالیت اخیر',quick:'افزودن سریع',addTask:'افزودن وظیفه',addGoal:'افزودن هدف',addHabit:'افزودن عادت',addTx:'افزودن تراکنش',newEntry:'نوشته جدید',save:'ذخیره',cancel:'لغو',delete:'حذف',title:'عنوان',amount:'مقدار',category:'دسته‌بندی',type:'نوع',incomeType:'درآمد',expenseType:'مصرف',date:'تاریخ',description:'توضیحات',language:'زبان',currency:'واحد پول',theme:'تم',dark:'تیره',light:'روشن',backup:'پشتیبان‌گیری',restore:'بازیابی',reset:'پاک‌کردن داده‌ها',connectTitle:'ارتباط با Mahar',connectText:'نظر، پیشنهاد یا گزارش مشکل داری؟ پیام بفرست.',email:'ایمیل',send:'ارسال ایمیل',noData:'هنوز چیزی اینجا نیست',progress:'پیشرفت',streak:'روز پشت‌سرهم',mark:'انجام شد',search:'جستجو',name:'نام',morning:'صبح بخیر',afternoon:'ظهر بخیر',evening:'شب بخیر',vsLastMonth:'نسبت به ماه قبل',newData:'ماه قبل داده‌ای نیست',todayTasks:'وظایف امروز',goalsOverview:'نمای اهداف',habitsToday:'عادت‌های امروز',financeOverview:'نمای مالی',expensesByCategory:'مصارف به تفکیک دسته',quickNotes:'یادداشت‌های سریع',viewAll:'مشاهده همه',done:'انجام شد',allTime:'تراکنش · در کل',morningRoutine:'روتین صبحگاهی',morningAlarm:'زنگ صبحگاهی',windDown:'صداهای آرامش‌بخش',addExercise:'افزودن حرکت',exerciseName:'حرکت',startTimer:'شروع',pauseTimer:'مکث',resetTimer:'ریست',skipExercise:'رد کردن',rain:'باران',focusTone:'تمرکز',sleepTone:'خواب',stopSound:'توقف',alarmHint:'فقط وقتی Mahar تو مرورگر باز باشه زنگ می‌زنه',allDoneMsg:'روتین تموم شد!',upNext:'بعدی',goalType:'نوع هدف',simpleGoal:'هدف ساده',checklistGoal:'هدف با زیرکار',addSubtask:'افزودن زیرکار'},
ps:{dashboard:'ډشبورډ',tasks:'دندې',goals:'موخې',habits:'عادتونه',finance:'مالي',journal:'یادښتونه',calendar:'کلیز',statistics:'احصایې',connect:'له موږ سره اړیکه',settings:'امستنې',wellness:'روغتیا',offlineReady:'آفلاین · محلي ډاټا',balance:'بیلانس',income:'عاید',expenses:'لګښتونه',completion:'د دندو بشپړتیا',today:'نن',month:'دا میاشت',recent:'وروستی فعالیت',quick:'چټک زیاتول',addTask:'دنده زیاتول',addGoal:'موخه زیاتول',addHabit:'عادت زیاتول',addTx:'معامله زیاتول',newEntry:'نوې یادونه',save:'ساتل',cancel:'لغوه',delete:'ړنګول',title:'سرلیک',amount:'مقدار',category:'کټګوري',type:'ډول',incomeType:'عاید',expenseType:'لګښت',date:'نېټه',description:'توضیحات',language:'ژبه',currency:'پیسې',theme:'بڼه',dark:'تیاره',light:'روښانه',backup:'بیکاپ',restore:'بیا راوستل',reset:'ډاټا پاکول',connectTitle:'له Mahar سره اړیکه',connectText:'نظر یا د ستونزې راپور لرئ؟ موږ ته پیغام واستوئ.',email:'برېښنالیک',send:'ایمیل لېږل',noData:'تر اوسه څه نشته',progress:'پرمختګ',streak:'ورځې پرله‌پسې',mark:'بشپړ شو',search:'لټون',name:'نوم',morning:'سهار مو پخیر',afternoon:'ماسپښین مو پخیر',evening:'ماښام مو پخیر',vsLastMonth:'د تیرې میاشتې پرتله',newData:'تیره میاشت ډاټا نشته',todayTasks:'د نن دندې',goalsOverview:'د موخو کتنه',habitsToday:'د نن عادتونه',financeOverview:'د مالي کتنه',expensesByCategory:'لګښتونه له مخې کټګورۍ',quickNotes:'چټک یادښتونه',viewAll:'ټول وګورئ',done:'ترسره شو',allTime:'معاملې · ټول وخت',morningRoutine:'سهارنی معمول',morningAlarm:'د سهار زنګ',windDown:'د آرامۍ غږونه',addExercise:'حرکت زیاتول',exerciseName:'حرکت',startTimer:'پیل',pauseTimer:'ودریدل',resetTimer:'بیا تنظیم',skipExercise:'تېرول',rain:'باران',focusTone:'تمرکز',sleepTone:'خوب',stopSound:'ودریدل',alarmHint:'یوازې کله چې Mahar په براوزر کې پرانیستی وي زنګ وهي',allDoneMsg:'معمول بشپړ شو!',upNext:'راتلونکی',goalType:'د موخې ډول',simpleGoal:'ساده موخه',checklistGoal:'د زیرکارونو سره موخه',addSubtask:'زیرکار زیاتول'},
tr:{dashboard:'Panel',tasks:'Gorevler',goals:'Hedefler',habits:'Aliskanliklar',finance:'Finans',journal:'Gunluk',calendar:'Takvim',statistics:'Istatistik',connect:'Bize Ulasin',settings:'Ayarlar',wellness:'Saglik',offlineReady:'Cevrimdisi - yerel veri',balance:'Bakiye',income:'Gelir',expenses:'Gider',completion:'Gorev tamamlama',today:'Bugun',month:'Bu ay',recent:'Son etkinlik',quick:'Hizli ekle',addTask:'Gorev ekle',addGoal:'Hedef ekle',addHabit:'Aliskanlik ekle',addTx:'Islem ekle',newEntry:'Yeni kayit',save:'Kaydet',cancel:'Iptal',delete:'Sil',title:'Baslik',amount:'Tutar',category:'Kategori',type:'Tur',incomeType:'Gelir',expenseType:'Gider',date:'Tarih',description:'Aciklama',language:'Dil',currency:'Para birimi',theme:'Tema',dark:'Koyu',light:'Acik',backup:'Yedekle',restore:'Geri yukle',reset:'Verileri sifirla',connectTitle:'Mahar ile iletisim',connectText:'Geri bildirim veya hata raporu gonder.',email:'E-posta',send:'E-posta gonder',noData:'Henuz bir sey yok',progress:'Ilerleme',streak:'gun serisi',mark:'Tamamlandi',search:'Ara',name:'Isim',morning:'Gunaydin',afternoon:'Iyi gunler',evening:'Iyi aksamlar',vsLastMonth:'gecen aya gore',newData:'gecen ay veri yok',todayTasks:'Bugunku gorevler',goalsOverview:'Hedeflere genel bakis',habitsToday:'Bugunku aliskanliklar',financeOverview:'Finansal genel bakis',expensesByCategory:'Kategoriye gore giderler',quickNotes:'Hizli notlar',viewAll:'Tumunu gor',done:'Tamamlandi',allTime:'islem - tum zamanlar',morningRoutine:'Sabah Rutini',morningAlarm:'Sabah Alarmi',windDown:'Sakinlestirici Sesler',addExercise:'Egzersiz ekle',exerciseName:'Egzersiz',startTimer:'Baslat',pauseTimer:'Duraklat',resetTimer:'Sifirla',skipExercise:'Atla',rain:'Yagmur',focusTone:'Odak tonu',sleepTone:'Uyku tonu',stopSound:'Durdur',alarmHint:'Yalnizca Mahar tarayicida acikken calar',allDoneMsg:'Rutin tamamlandi!',upNext:'Siradaki',goalType:'Hedef turu',simpleGoal:'Basit hedef',checklistGoal:'Alt gorevli hedef',addSubtask:'Alt gorev ekle'}};
Object.assign(T.en,{projects:'Projects',addProject:'Add project',stTodo:'Planned',stDoing:'In progress',stDone:'Completed',prev:'Back',next:'Next'});
Object.assign(T.fa,{projects:'پروژه‌ها',addProject:'پروژه جدید',stTodo:'برنامه‌ریزی‌شده',stDoing:'در حال انجام',stDone:'تکمیل‌شده',prev:'قبلی',next:'بعدی'});
Object.assign(T.ps,{projects:'پروژې',addProject:'نوې پروژه',stTodo:'پلان شوې',stDoing:'روانه',stDone:'بشپړه',prev:'مخکینی',next:'بل'});
Object.assign(T.tr,{projects:'Projeler',addProject:'Proje ekle',stTodo:'Planlandi',stDoing:'Devam ediyor',stDone:'Tamamlandi',prev:'Geri',next:'Ileri'});
function clone(x){return JSON.parse(JSON.stringify(x))}
function load(){try{return Object.assign(clone(D),JSON.parse(localStorage.getItem(KEY)||'{}'))}catch{return clone(D)}} function save(){localStorage.setItem(KEY,JSON.stringify(S));}
function t(k){return (T[S.language]||T.en)[k]||T.en[k]||k} function today(){return new Date().toISOString().slice(0,10)} function id(p){return p+'_'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function money(n){return new Intl.NumberFormat(S.language,{maximumFractionDigits:0}).format(Number(n)||0)+' '+S.currency} function totals(){let income=0,expense=0;S.tx.forEach(x=>x.type==='income'?income+=+x.amount:expense+=+x.amount);return{income,expense,balance:income-expense}}
function theme(){document.documentElement.dataset.theme=S.theme;let tb=$('#themeBtn');if(tb)tb.innerHTML=ic(S.theme==='dark'?'sun':'moon')} function setLang(){document.documentElement.lang=S.language;document.documentElement.dir=['fa','ps'].includes(S.language)?'rtl':'ltr'}
function greet(){let h=new Date().getHours();return h<12?t('morning'):h<18?t('afternoon'):t('evening')}
function monthKey(offset){let d=new Date();d.setMonth(d.getMonth()+offset);return d.toISOString().slice(0,7)}
function monthTotals(offset){let k=monthKey(offset),inc=0,exp=0;S.tx.forEach(x=>{if((x.date||'').slice(0,7)===k){if(x.type==='income')inc+=+x.amount;else exp+=+x.amount}});return{income:inc,expense:exp}}
function pct(cur,prev){if(prev===0)return cur===0?0:null;return Math.round((cur-prev)/prev*100)}
function trendHtml(p){if(p===null)return '<div class="kpi-trend"><span>'+t('newData')+'</span></div>';let up=p>=0;return '<div class="kpi-trend"><b class="'+(up?'up':'down')+'">'+ic(up?'arrowUp':'arrowDown','ic-sm')+Math.abs(p)+'%</b><span>'+t('vsLastMonth')+'</span></div>'}
function dailyQuote(){let d=new Date(),start=new Date(d.getFullYear(),0,0),diff=d-start,dayOfYear=Math.floor(diff/864e5);let list=QUOTES[S.language]||QUOTES.en;return list[dayOfYear%list.length]}
function randomQuote(){let list=QUOTES[S.language]||QUOTES.en;return list[Math.floor(Math.random()*list.length)]}
let TM={running:false,index:0,left:0,iv:null,sound:null,alarmFiredMinute:null};
let audioCtx=null,soundNodes=null;
function fmtTime(s){s=Math.max(0,Math.round(s));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')}
function ensureCtx(){if(!audioCtx)audioCtx=new (window.AudioContext||window.webkitAudioContext)();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}
function stopSoundNow(){if(soundNodes){soundNodes.forEach(function(n){try{n.stop&&n.stop()}catch(e){}});soundNodes=null}TM.sound=null}
function playRain(){stopSoundNow();let ctx=ensureCtx(),len=2*ctx.sampleRate,buf=ctx.createBuffer(1,len,ctx.sampleRate),data=buf.getChannelData(0);for(let i=0;i<len;i++)data[i]=(Math.random()*2-1)*.35;let src=ctx.createBufferSource();src.buffer=buf;src.loop=true;let f=ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=1100;let g=ctx.createGain();g.gain.value=.16;src.connect(f).connect(g).connect(ctx.destination);src.start();soundNodes=[src];TM.sound='rain'}
function playTone(freq,label){stopSoundNow();let ctx=ensureCtx(),osc=ctx.createOscillator();osc.type='sine';osc.frequency.value=freq;let g=ctx.createGain();g.gain.value=.05;osc.connect(g).connect(ctx.destination);osc.start();soundNodes=[osc];TM.sound=label}
function beep(){try{let ctx=ensureCtx(),osc=ctx.createOscillator(),g=ctx.createGain();osc.type='sine';osc.frequency.value=880;g.gain.value=.12;osc.connect(g).connect(ctx.destination);osc.start();setTimeout(function(){osc.stop()},350)}catch(e){}}
function timerTick(){let r=(S.wellness&&S.wellness.routine)||[];if(TM.index>=r.length){timerPause();return}TM.left--;if(TM.left<=0){beep();TM.index++;if(TM.index>=r.length){timerPause();showToast(t('allDoneMsg'),'sparkle');if(route==='wellness')render();return}TM.left=r[TM.index].seconds}if(route==='wellness')updateTimerDom()}
function updateTimerDom(){let r=(S.wellness&&S.wellness.routine)||[],cur=r[TM.index];let ring=$('#timerRing'),count=$('#timerCount'),label=$('#timerLabel');if(!ring||!cur)return;let C=2*Math.PI*54,p=1-TM.left/cur.seconds,off=C*(1-Math.max(0,Math.min(1,p)));ring.querySelectorAll('circle')[1].setAttribute('stroke-dashoffset',off.toFixed(1));count.textContent=fmtTime(TM.left);label.textContent=cur.title}
function timerStart(){let r=(S.wellness&&S.wellness.routine)||[];if(!r.length)return;if(TM.index>=r.length)TM.index=0;if(!TM.left)TM.left=r[TM.index].seconds;TM.running=true;clearInterval(TM.iv);TM.iv=setInterval(timerTick,1000)}
function timerPause(){TM.running=false;clearInterval(TM.iv)}
function timerReset(){timerPause();TM.index=0;let r=(S.wellness&&S.wellness.routine)||[];TM.left=r[0]?r[0].seconds:0}
function timerSkip(){let r=(S.wellness&&S.wellness.routine)||[];TM.index=Math.min(TM.index+1,r.length);TM.left=r[TM.index]?r[TM.index].seconds:0}
setInterval(function(){if(!S.wellness||!S.wellness.alarmOn)return;let now=new Date(),hhmm=String(now.getHours()).padStart(2,'0')+':'+String(now.getMinutes()).padStart(2,'0');if(hhmm===S.wellness.alarmTime&&TM.alarmFiredMinute!==hhmm){TM.alarmFiredMinute=hhmm;beep();if('Notification'in window&&Notification.permission==='granted')try{new Notification('Mahar',{body:t('morningAlarm')})}catch(e){}}},15000);
function init(){theme();setLang();document.addEventListener('click',click);document.addEventListener('submit',submit);document.addEventListener('input',input);mountIcons(document);mountMascot();render();if(location.protocol!=='file:'&&'serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(function(){})}
function mountMascot(){let fab=$('#mascotFab');if(fab)fab.innerHTML=mascotSVG('wave',40,'teen')}
function showMascotQuote(text){let b=$('#mascotBubble');if(!b)return;b.innerHTML='<b>'+esc(text)+'</b>';b.classList.add('show');clearTimeout(window.__mascotT);window.__mascotT=setTimeout(function(){b.classList.remove('show')},3600)}
function click(e){if(e.target.closest('#mascotFab')){showMascotQuote(randomQuote());return}let n=e.target.closest('[data-route]');if(n){route=n.dataset.route;$('#sidebar').classList.remove('open');render();return}if(e.target.closest('#menuBtn')){$('#sidebar').classList.toggle('open');return}if(e.target.closest('#themeBtn')){S.theme=S.theme==='dark'?'light':'dark';save();theme();return}if(e.target.closest('#searchBtn')){route='tasks';render();setTimeout(function(){var x=$('#taskSearch');if(x)x.focus()},40);return}if(e.target.closest('#profileBtn')){route='settings';render();return}let a=e.target.closest('[data-action]');if(a)act(a.dataset.action,a.dataset.id)}
function render(){setLang();$$('.nav-item').forEach(function(x){x.classList.toggle('active',x.dataset.route===route)});$$('.bottom-nav button[data-route]').forEach(function(x){x.classList.toggle('active',x.dataset.route===route)});$('#pageTitle').textContent=route==='dashboard'?(greet()+', '+(S.profile.name||'Alpha')):t(route);$('#eyebrow').textContent=new Date().toLocaleDateString(S.language,{weekday:'long',month:'long',day:'numeric'});let name=S.profile.name||'Alpha User';$('#profileName').textContent=name;let initial=(name.trim()[0]||'A').toUpperCase();$('#profileMark').textContent=initial;$('#profileBtn').textContent=initial;let f={dashboard:dashboard,tasks:tasks,goals:goals,projects:projects,habits:habits,wellness:wellness,finance:finance,journal:journal,calendar:calendar,statistics:statistics,connect:connect,settings:settings}[route];$('#content').innerHTML=f();let ls=$('#languageSelect');if(ls)ls.value=S.language;let cs=$('#currencySelect');if(cs)cs.value=S.currency;let c=$('#content');c.classList.remove('enter');void c.offsetWidth;c.classList.add('enter')}
function kpi(iconName,label,value,trend,kind){kind=kind||'';return '<div class="kpi '+kind+'"><div class="kpi-top"><div class="kpi-icon">'+ic(iconName)+'</div></div><div><p>'+label+'</p><strong>'+value+'</strong></div>'+(trend||'')+'</div>'}
function empty(){return '<div class="empty">'+ic('sparkle','ic-lg')+'<b>'+t('noData')+'</b></div>'}
function dashboard(){
  let q=totals(),done=S.tasks.filter(function(x){return x.completed}).length,rate=S.tasks.length?Math.round(done/S.tasks.length*100):0;
  let curM=monthTotals(0),prevM=monthTotals(-1),incP=pct(curM.income,prevM.income),expP=pct(curM.expense,prevM.expense);
  let quoteBanner='<div class="quote-banner">'+mascotSVG('wave',60,'teen')+'<div class="quote-bubble"><b>'+esc(dailyQuote())+'</b></div></div>';
  let kpis=kpi('wallet',t('balance'),money(q.balance),'<div class="kpi-trend"><span>'+S.tx.length+' '+t('allTime')+'</span></div>','')
    +kpi('arrowUp',t('income'),money(q.income),trendHtml(incP),'teal')
    +kpi('arrowDown',t('expenses'),money(q.expense),trendHtml(expP),'rust')
    +kpi('target',t('completion'),rate+'%','<div class="kpi-trend"><span>'+done+'/'+S.tasks.length+' '+t('tasks')+'</span></div>','plum');
  return quoteBanner+'<div class="kpi-grid">'+kpis+'</div>'+
  '<div class="bento">'+
    '<section class="panel"><div class="head"><div><h3>'+t('todayTasks')+'</h3></div><button class="ghost" data-route="tasks">'+t('viewAll')+'</button></div><div class="list">'+(S.tasks.slice(0,6).map(taskRow).join('')||empty())+'</div></section>'+
    '<section class="panel"><div class="head"><div><h3>'+t('goalsOverview')+'</h3></div><button class="ghost" data-route="goals">'+t('viewAll')+'</button></div>'+(S.goals.slice(0,4).map(goalMini).join('')||empty())+'</section>'+
    '<section class="panel"><div class="head"><div><h3>'+t('habitsToday')+'</h3></div><button class="ghost" data-route="habits">'+t('viewAll')+'</button></div><div class="list">'+(S.habits.slice(0,5).map(habitMini).join('')||empty())+'</div></section>'+
    '<section class="panel"><div class="head"><div><h3>'+t('financeOverview')+'</h3></div><button class="ghost" data-route="finance">'+t('viewAll')+'</button></div><div class="chart-wrap">'+financeChart()+'</div></section>'+
    '<section class="panel"><div class="head"><div><h3>'+t('expensesByCategory')+'</h3></div></div>'+donutSvg()+'</section>'+
    '<section class="panel"><div class="head"><div><h3>'+t('wellness')+'</h3></div><button class="ghost" data-route="wellness">'+t('viewAll')+'</button></div>'+wellnessDonut()+'</section>'+
    '<section class="panel span2"><div class="head"><div><h3>'+t('quickNotes')+'</h3></div><button class="icon-btn" data-action="addJournal" aria-label="add">'+ic('plus','ic-sm')+'</button></div>'+(S.journal.slice(-4).reverse().map(function(j){return '<div class="activity"><div><b>'+esc(j.title)+'</b><small>'+esc(j.date)+'</small></div></div>'}).join('')||empty())+'</section>'+
  '</div>';
}
function wellnessDonut(){
  ensureRoutine();
  let r=S.wellness.routine,doneCount=r.filter(function(x){return x.done}).length,total=r.length;
  if(!total)return empty();
  let p=doneCount/total,R=48,C=2*Math.PI*R,doneLen=p*C;
  let segs='<circle cx="60" cy="60" r="'+R+'" fill="none" stroke="var(--surface3)" stroke-width="15"/>'+
    (doneLen>0?'<circle cx="60" cy="60" r="'+R+'" fill="none" stroke="var(--teal)" stroke-width="15" stroke-linecap="round" stroke-dasharray="'+doneLen.toFixed(1)+' '+(C-doneLen).toFixed(1)+'" transform="rotate(-90 60 60)"/>':'');
  let legend='<div class="row"><span><i style="background:var(--teal)"></i>'+t('done')+'</span><span><b>'+doneCount+'/'+total+'</b></span></div>'+
    '<div class="row"><span><i style="background:var(--gold)"></i>'+t('morningAlarm')+'</span><span><b>'+(S.wellness.alarmOn?esc(S.wellness.alarmTime):'-')+'</b></span></div>';
  return '<div class="donut-wrap"><svg class="donut-svg" width="120" height="120" viewBox="0 0 120 120">'+segs+'<text x="60" y="66" text-anchor="middle" font-size="20" font-weight="700" fill="var(--text)" font-family="ui-monospace,monospace">'+Math.round(p*100)+'%</text></svg><div class="donut-legend">'+legend+'</div></div>';
}
function taskRow(x){return '<div class="task-row '+(x.completed?'done':'')+'"><button class="check '+(x.completed?'checked':'')+'" data-action="toggleTask" data-id="'+x.id+'">'+(x.completed?ic('check'):'')+'</button><div><b>'+esc(x.title)+'</b><small>'+esc(x.date||'')+' - '+esc(x.priority||'normal')+'</small></div><button class="more" data-action="deleteTask" data-id="'+x.id+'">'+ic('trash','ic-sm')+'</button></div>'}
function goalProgress(g){if(g.kind==='checklist'){let subs=g.subtasks||[];return subs.length?Math.round(subs.filter(function(s){return s.done}).length/subs.length*100):0}return Math.max(0,Math.min(100,+g.progress||0))}
function goalMini(g){let p=goalProgress(g);return '<div class="goal-mini"><div class="goal-icon">'+ic(g.kind==='checklist'?'list':'target')+'</div><div class="goal-body"><div class="row"><b>'+esc(g.title)+'</b><span>'+p+'%</span></div><div class="progress"><i style="width:'+p+'%"></i></div></div></div>'}
function habitStreak(h){let d=new Date(),n=0;for(let i=0;i<365;i++){let k=d.toISOString().slice(0,10);if((h.checks||{})[k])n++;else break;d.setDate(d.getDate()-1)}return n}
function habitMini(h){let c=!!(h.checks||{})[today()];return '<div class="habit-mini"><button class="check '+(c?'checked':'')+'" data-action="toggleHabit" data-id="'+h.id+'">'+(c?ic('check'):'')+'</button><div><b>'+esc(h.title)+'</b><small>'+ic('flame','ic-sm')+' '+habitStreak(h)+' '+t('streak')+'</small></div></div>'}
function financeChart(){
  let days=14,pts=[];
  for(let i=days-1;i>=0;i--){let d=new Date();d.setDate(d.getDate()-i);let k=d.toISOString().slice(0,10);let inc=S.tx.filter(function(x){return x.date===k&&x.type==='income'}).reduce(function(a,x){return a+ +x.amount},0);let exp=S.tx.filter(function(x){return x.date===k&&x.type==='expense'}).reduce(function(a,x){return a+ +x.amount},0);pts.push({inc:inc,exp:exp})}
  let max=Math.max.apply(null,[1].concat(pts.map(function(p){return Math.max(p.inc,p.exp)})));
  let W=560,H=150,step=W/((pts.length-1)||1);
  function line(key){return pts.map(function(p,i){return (i*step).toFixed(1)+','+(H-(p[key]/max*(H-24))-8).toFixed(1)}).join(' ')}
  let incLine=line('inc'),expLine=line('exp');
  let incArea='0,'+H+' '+incLine+' '+W+','+H,expArea='0,'+H+' '+expLine+' '+W+','+H;
  let sumInc=pts.reduce(function(a,p){return a+p.inc},0),sumExp=pts.reduce(function(a,p){return a+p.exp},0);
  return '<div class="chart-legend"><span><i style="background:#33e2c6"></i>'+t('income')+' <b>'+money(sumInc)+'</b></span><span><i style="background:#ff4d8f"></i>'+t('expenses')+' <b>'+money(sumExp)+'</b></span></div>'+
  '<svg class="area-svg" viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none">'+
    '<polygon points="'+expArea+'" fill="#ff4d8f" opacity=".12"/>'+
    '<polygon points="'+incArea+'" fill="#33e2c6" opacity=".14"/>'+
    '<polyline points="'+expLine+'" fill="none" stroke="#ff4d8f" stroke-width="2"/>'+
    '<polyline points="'+incLine+'" fill="none" stroke="#33e2c6" stroke-width="2"/>'+
  '</svg>';
}
function donutSvg(){
  let m={};S.tx.filter(function(x){return x.type==='expense'}).forEach(function(x){let k=x.category||'General';m[k]=(m[k]||0)+ +x.amount});
  let entries=Object.entries(m).sort(function(a,b){return b[1]-a[1]});
  if(!entries.length)return empty();
  let total=entries.reduce(function(a,e){return a+e[1]},0),palette=['#c6f24d','#33e2c6','#ff4d8f','#ff9c42','#7ea8ff','#b98cff'];
  let R=48,C=2*Math.PI*R,offset=0,segs='';
  entries.forEach(function(e,i){let k=e[0],v=e[1];let frac=v/total,len=frac*C;segs+='<circle cx="60" cy="60" r="'+R+'" fill="none" stroke="'+palette[i%palette.length]+'" stroke-width="15" stroke-dasharray="'+len.toFixed(1)+' '+(C-len).toFixed(1)+'" stroke-dashoffset="'+(-offset).toFixed(1)+'" transform="rotate(-90 60 60)"/>';offset+=len});
  let legend=entries.slice(0,6).map(function(e,i){let k=e[0],v=e[1];return '<div class="row"><span><i style="background:'+palette[i%palette.length]+'"></i>'+esc(k)+'</span><span><b>'+Math.round(v/total*100)+'%</b><small>'+money(v)+'</small></span></div>'}).join('');
  return '<div class="donut-wrap"><svg class="donut-svg" width="120" height="120" viewBox="0 0 120 120">'+segs+'</svg><div class="donut-legend">'+legend+'</div></div>';
}
function shell(body){return '<div class="page-head"><span>'+t(route)+'</span><h2>'+t(route)+'</h2></div>'+body}
function tasks(){return shell('<div class="toolbar"><input id="taskSearch" placeholder="'+t('search')+'..."><button class="primary-btn" data-action="addTask">'+ic('plus','ic-sm')+' '+t('addTask')+'</button></div><div class="panel list large" id="taskList">'+(S.tasks.length?S.tasks.map(taskRow).join(''):empty())+'</div>')}
function input(e){if(e.target.id!=='taskSearch')return;let q=e.target.value.trim().toLowerCase();let list=S.tasks.filter(function(x){return (x.title+' '+(x.priority||'')+' '+(x.date||'')).toLowerCase().includes(q)});$('#taskList').innerHTML=list.length?list.map(taskRow).join(''):empty()}

/* ---------------- goals (simple + checklist sub-tasks) ---------------- */
function subtaskRow(g,s){return '<div class="task-row" style="padding:6px 0"><button class="check '+(s.done?'checked':'')+'" data-action="toggleSubtask" data-id="'+g.id+'::'+s.id+'">'+(s.done?ic('check','ic-sm'):'')+'</button><div><b style="font-size:11.5px">'+esc(s.title)+'</b></div><button class="more" data-action="deleteSubtask" data-id="'+g.id+'::'+s.id+'">'+ic('trash','ic-sm')+'</button></div>'}
function goalCard(g){
  let p=goalProgress(g),done100=p>=100;
  let R=40,C=2*Math.PI*R,len=p/100*C;
  let ring='<svg class="goal-ring" width="88" height="88" viewBox="0 0 88 88"><circle cx="44" cy="44" r="'+R+'" fill="none" stroke="var(--surface3)" stroke-width="9"/><circle cx="44" cy="44" r="'+R+'" fill="none" stroke="'+(done100?'var(--teal)':'var(--gold)')+'" stroke-width="9" stroke-linecap="round" stroke-dasharray="'+len.toFixed(1)+' '+(C-len).toFixed(1)+'" transform="rotate(-90 44 44)"/><text x="44" y="49" text-anchor="middle" font-size="15" font-weight="700" fill="var(--text)" font-family="ui-monospace,monospace">'+p+'%</text></svg>';
  let body;
  if(g.kind==='checklist'){
    let subs=g.subtasks||[];
    body='<div class="list">'+(subs.map(function(s){return subtaskRow(g,s)}).join('')||'<small style="color:var(--muted)">'+t('noData')+'</small>')+'</div>'+
      '<form class="subtask-add" data-form="subtask" data-goal="'+g.id+'" style="display:flex;gap:6px;margin-top:8px"><input name="title" placeholder="'+t('addSubtask')+'" style="flex:1"><button class="icon-btn">'+ic('plus','ic-sm')+'</button></form>';
  } else {
    body='<input type="range" class="goal-slider" min="0" max="100" value="'+p+'" data-goal="'+g.id+'">';
  }
  return '<article class="card'+(done100?' goal-complete':'')+'"><div class="row" style="align-items:flex-start"><div><div class="habit-icon">'+ic(g.kind==='checklist'?'list':'target')+'</div><h3 style="margin-bottom:2px">'+esc(g.title)+'</h3><small style="color:var(--muted)">'+esc(g.deadline||'')+'</small></div>'+ring+'</div>'+
    '<p>'+esc(g.description||'')+'</p>'+body+
    '<div class="row" style="margin-top:12px"><small style="color:var(--muted)">'+(g.kind==='checklist'?t('checklistGoal'):t('simpleGoal'))+'</small><button class="danger" data-action="deleteGoal" data-id="'+g.id+'">'+ic('trash','ic-sm')+' '+t('delete')+'</button></div></article>';
}
function goals(){return shell('<div class="toolbar"><span></span><button class="primary-btn" data-action="addGoal">'+ic('plus','ic-sm')+' '+t('addGoal')+'</button></div><div class="cards">'+(S.goals.map(goalCard).join('')||empty())+'</div>')}

const PST=['todo','doing','done'],PLBL={todo:'stTodo',doing:'stDoing',done:'stDone'};
function projects(){let list=S.projects||[];return shell('<div class="toolbar"><span></span><button class="primary-btn" data-action="addProject">'+ic('plus','ic-sm')+' '+t('addProject')+'</button></div><div class="kanban">'+PST.map(function(st,i){let items=list.filter(function(p){return p.status===st});return '<div class="panel kcol"><h3>'+t(PLBL[st])+' <small>'+items.length+'</small></h3>'+(items.map(function(p){return '<div class="kcard"><b>'+esc(p.title)+'</b><div class="kacts">'+(i>0?'<button data-action="moveProject" data-id="'+p.id+'::-1">'+t('prev')+'</button>':'')+(i<2?'<button data-action="moveProject" data-id="'+p.id+'::1">'+t('next')+'</button>':'')+'<button class="danger" data-action="deleteProject" data-id="'+p.id+'">'+ic('trash','ic-sm')+'</button></div></div>'}).join('')||'<small class="kempty">—</small>')+'</div>'}).join('')+'</div>')}
function habits(){return shell('<div class="toolbar"><span></span><button class="primary-btn" data-action="addHabit">'+ic('plus','ic-sm')+' '+t('addHabit')+'</button></div><div class="cards">'+(S.habits.map(function(h){return '<article class="card"><div class="habit-icon">'+esc(h.icon||'\u2726')+'</div><h3>'+esc(h.title)+'</h3><p>'+esc(h.description||'')+'</p><strong class="streak">'+ic('flame','ic-sm')+habitStreak(h)+' <small>'+t('streak')+'</small></strong><button class="primary-btn full" data-action="toggleHabit" data-id="'+h.id+'">'+ic('check','ic-sm')+' '+t('mark')+'</button></article>'}).join('')||empty())+'</div>')}
function ensureRoutine(){if(!S.wellness)S.wellness={alarmTime:'06:00',alarmOn:false,routine:null};if(!S.wellness.routine){S.wellness.routine=(DEFAULT_ROUTINE[S.language]||DEFAULT_ROUTINE.en).map(function(pair){return {id:id('ex'),title:pair[0],seconds:pair[1],done:false}});save()}}
function exerciseRow(x){return '<div class="task-row '+(x.done?'done':'')+'"><button class="check '+(x.done?'checked':'')+'" data-action="toggleExercise" data-id="'+x.id+'">'+(x.done?ic('check'):'')+'</button><div><b>'+esc(x.title)+'</b><small>'+x.seconds+'s</small></div><button class="more" data-action="deleteExercise" data-id="'+x.id+'">'+ic('trash','ic-sm')+'</button></div>'}
function wellness(){
  ensureRoutine();
  let r=S.wellness.routine;
  if(!TM.running&&!TM.left&&r[TM.index])TM.left=r[TM.index].seconds;
  let idx=Math.min(TM.index,Math.max(r.length-1,0)),cur=r[idx],next=r[idx+1];
  let p=cur?Math.max(0,Math.min(1,1-TM.left/cur.seconds)):0,C=2*Math.PI*54,off=C*(1-p);
  return shell('<div class="bento">'+
    '<section class="panel"><div class="head"><div><h3>'+ic('bell','ic-sm')+' '+t('morningAlarm')+'</h3></div></div>'+
      '<div class="row" style="margin-bottom:10px"><input type="time" id="alarmTime" value="'+esc(S.wellness.alarmTime)+'" style="max-width:130px"><button class="'+(S.wellness.alarmOn?'primary-btn':'secondary')+'" data-action="toggleAlarm">'+ic(S.wellness.alarmOn?'check':'bell','ic-sm')+' '+(S.wellness.alarmOn?t('done'):t('save'))+'</button></div>'+
      '<p style="color:var(--muted);font-size:11px;margin:0">'+t('alarmHint')+'</p></section>'+
    '<section class="panel"><div class="head"><div><h3>'+ic('wave','ic-sm')+' '+t('windDown')+'</h3></div></div>'+
      '<div style="display:flex;gap:14px;align-items:center;margin-bottom:12px">'+mascotSVG('sleepy',48,'teen')+'<span style="color:var(--muted);font-size:11px">'+esc(dailyQuote())+'</span></div>'+
      '<div class="quickgrid">'+
        '<button class="'+(TM.sound==='rain'?'active-sound':'')+'" data-action="soundRain">'+ic('wave')+' '+t('rain')+'</button>'+
        '<button class="'+(TM.sound==='focus'?'active-sound':'')+'" data-action="soundFocus">'+ic('wave')+' '+t('focusTone')+'</button>'+
        '<button class="'+(TM.sound==='sleep'?'active-sound':'')+'" data-action="soundSleep">'+ic('moon')+' '+t('sleepTone')+'</button>'+
        '<button data-action="soundStop">'+ic('pause')+' '+t('stopSound')+'</button>'+
      '</div></section>'+
    '<section class="panel"><div class="head"><div><h3>'+ic('timer','ic-sm')+' '+t('morningRoutine')+'</h3></div></div>'+
      '<div style="display:flex;flex-direction:column;align-items:center;gap:10px;padding:6px 0 14px">'+
        '<svg width="132" height="132" viewBox="0 0 132 132" id="timerRing"><circle cx="66" cy="66" r="54" fill="none" stroke="var(--surface3)" stroke-width="10"/><circle cx="66" cy="66" r="54" fill="none" stroke="var(--gold)" stroke-width="10" stroke-linecap="round" stroke-dasharray="'+C.toFixed(1)+'" stroke-dashoffset="'+off.toFixed(1)+'" transform="rotate(-90 66 66)" style="transition:stroke-dashoffset .3s linear"/><text id="timerCount" x="66" y="72" text-anchor="middle" font-size="26" font-weight="700" fill="var(--text)" font-family="ui-monospace,monospace">'+(cur?fmtTime(TM.left):'--')+'</text></svg>'+
        '<b id="timerLabel" style="font-size:13px">'+(cur?esc(cur.title):t('allDoneMsg'))+'</b>'+
        (next?'<small style="color:var(--muted)">'+t('upNext')+': '+esc(next.title)+'</small>':'')+
        '<div class="row" style="gap:8px">'+
          '<button class="secondary" data-action="timerReset">'+ic('trash','ic-sm')+'</button>'+
          '<button class="primary-btn" data-action="'+(TM.running?'timerPause':'timerStart')+'">'+ic(TM.running?'pause':'play','ic-sm')+' '+(TM.running?t('pauseTimer'):t('startTimer'))+'</button>'+
          '<button class="secondary" data-action="timerSkip">'+ic('skip','ic-sm')+' '+t('skipExercise')+'</button>'+
        '</div>'+
      '</div></section>'+
  '</div>'+
  '<div class="toolbar" style="margin-top:14px"><span></span><button class="primary-btn" data-action="addExercise">'+ic('plus','ic-sm')+' '+t('addExercise')+'</button></div>'+
  '<div class="panel list large">'+(r.map(exerciseRow).join('')||empty())+'</div>');
}
function finance(){let q=totals();return shell('<div class="kpi-grid compact">'+kpi('wallet',t('balance'),money(q.balance),'','')+kpi('arrowUp',t('income'),money(q.income),'','teal')+kpi('arrowDown',t('expenses'),money(q.expense),'','rust')+'</div><div class="toolbar"><span></span><button class="primary-btn" data-action="addTx">'+ic('plus','ic-sm')+' '+t('addTx')+'</button></div><div class="panel tablewrap"><table><thead><tr><th>'+t('title')+'</th><th>'+t('type')+'</th><th>'+t('category')+'</th><th>'+t('amount')+'</th><th>'+t('date')+'</th><th></th></tr></thead><tbody>'+(S.tx.slice().reverse().map(function(x){return '<tr><td>'+esc(x.title)+'</td><td><span class="tag '+x.type+'">'+(x.type==='income'?t('incomeType'):t('expenseType'))+'</span></td><td>'+esc(x.category)+'</td><td>'+money(x.amount)+'</td><td>'+esc(x.date)+'</td><td><button class="danger" data-action="deleteTx" data-id="'+x.id+'">'+ic('trash','ic-sm')+'</button></td></tr>'}).join('')||('<tr><td colspan="6">'+empty()+'</td></tr>'))+'</tbody></table></div>')}
function journal(){return shell('<div class="toolbar"><span></span><button class="primary-btn" data-action="addJournal">'+ic('plus','ic-sm')+' '+t('newEntry')+'</button></div><div class="cards">'+(S.journal.slice().reverse().map(function(j){return '<article class="card"><small>'+esc(j.date)+'</small><h3>'+esc(j.title)+'</h3><p>'+esc(j.text)+'</p><button class="danger" data-action="deleteJournal" data-id="'+j.id+'">'+ic('trash','ic-sm')+' '+t('delete')+'</button></article>'}).join('')||empty())+'</div>')}
function calendar(){let d=new Date(),y=d.getFullYear(),m=d.getMonth(),first=new Date(y,m,1).getDay(),days=new Date(y,m+1,0).getDate(),c='';for(let i=0;i<first;i++)c+='<span></span>';for(let day=1;day<=days;day++){let k=y+'-'+String(m+1).padStart(2,'0')+'-'+String(day).padStart(2,'0'),n=S.tasks.filter(function(x){return x.date===k}).length;c+='<button class="calday '+(k===today()?'today':'')+'"><b>'+day+'</b>'+(n?'<i>'+n+'</i>':'')+'</button>'}return shell('<div class="panel calendar"><h3>'+d.toLocaleString(S.language,{month:'long',year:'numeric'})+'</h3><div class="week"><b>Sun</b><b>Mon</b><b>Tue</b><b>Wed</b><b>Thu</b><b>Fri</b><b>Sat</b></div><div class="calgrid">'+c+'</div></div>')}
function statistics(){let done=S.tasks.filter(function(x){return x.completed}).length,rate=S.tasks.length?Math.round(done/S.tasks.length*100):0,q=totals();return shell('<div class="stats"><div class="panel big"><span>'+t('tasks')+'</span><strong>'+rate+'%</strong><small>'+done+'/'+S.tasks.length+' completed</small></div><div class="panel big"><span>'+t('balance')+'</span><strong>'+money(q.balance)+'</strong><small>'+money(q.income)+' - '+money(q.expense)+'</small></div><div class="panel big"><span>'+t('goals')+'</span><strong>'+S.goals.length+'</strong><small>'+S.goals.filter(function(g){return goalProgress(g)>=100}).length+' completed</small></div><div class="panel big"><span>'+t('habits')+'</span><strong>'+S.habits.length+'</strong><small>'+S.habits.reduce(function(a,h){return a+habitStreak(h)},0)+' streak days</small></div></div><div class="panel"><h3>'+t('expensesByCategory')+'</h3>'+categoryBars()+'</div>')}
function categoryBars(){let m={};S.tx.filter(function(x){return x.type==='expense'}).forEach(function(x){m[x.category]=(m[x.category]||0)+ +x.amount});let a=Object.entries(m).sort(function(x,y){return y[1]-x[1]}),max=(a[0]&&a[0][1])||1;return a.map(function(e){return '<div class="cat"><div class="row"><b>'+esc(e[0])+'</b><span>'+money(e[1])+'</span></div><div class="progress"><i style="width:'+(e[1]/max*100)+'%"></i></div></div>'}).join('')||empty()}
function connect(){let email=ALPHA_CONFIG.contactEmail;return shell('<div class="connect"><div class="orb">A</div><div><span class="pill">Mahar</span><h2>'+t('connectTitle')+'</h2><p>'+t('connectText')+'</p><a class="email" href="mailto:'+esc(email)+'">'+ic('mail','ic-sm')+' '+esc(email)+'</a><a class="primary-btn inline" href="mailto:'+esc(email)+'?subject=Mahar%20Feedback">'+ic('mail','ic-sm')+' '+t('send')+'</a></div></div>')}
function settings(){return shell('<div class="settings"><div class="panel"><h3>'+t('name')+'</h3><form data-form="profile"><input name="name" value="'+esc(S.profile.name)+'"><button class="primary-btn">'+t('save')+'</button></form></div><div class="panel"><h3>'+t('language')+'</h3><select id="languageSelect"><option value="en">English</option><option value="fa">فارسی</option><option value="ps">پښتو</option><option value="tr">Turkce</option></select></div><div class="panel"><h3>'+t('currency')+'</h3><select id="currencySelect"><option>AFN</option><option>USD</option><option>EUR</option><option>TRY</option></select></div><div class="panel"><h3>'+t('theme')+'</h3><button class="secondary" data-action="theme">'+ic(S.theme==='dark'?'sun':'moon','ic-sm')+' '+(S.theme==='dark'?t('light'):t('dark'))+'</button></div><div class="panel"><h3>'+t('backup')+'</h3><button class="secondary" data-action="backup">'+ic('arrowDown','ic-sm')+' '+t('backup')+'</button> <button class="secondary" data-action="restore">'+ic('arrowUp','ic-sm')+' '+t('restore')+'</button><input type="file" id="restoreFile" accept=".json" hidden></div><div class="panel dangerzone"><h3>'+t('reset')+'</h3><button class="dangerbtn" data-action="reset">'+ic('trash','ic-sm')+' '+t('reset')+'</button></div></div><script>setTimeout(function(){document.getElementById("languageSelect").value="'+S.language+'";document.getElementById("currencySelect").value="'+S.currency+'"},0)<'+'/script>')}
function modal(html){$('#modal').innerHTML=html;$('#modalBackdrop').hidden=false}function close(){$('#modalBackdrop').hidden=true}
function form(title,fields,kind){modal('<div class="modalhead"><h3>'+title+'</h3><button data-close aria-label="close">'+ic('x')+'</button></div><form class="form" data-form="'+kind+'">'+fields+'<button class="primary-btn">'+t('save')+'</button></form>')}
function showToast(msg,iconName){let el=$('#toast');if(!el)return;el.innerHTML=ic(iconName||'check','ic-sm')+'<span>'+esc(msg)+'</span>';el.classList.add('show');clearTimeout(window.__alphaToastT);window.__alphaToastT=setTimeout(function(){el.classList.remove('show')},2200)}
function act(a,idv){
if(a==='close'){close();return}
if(a==='quick'){modal('<div class="modalhead"><h3>'+t('quick')+'</h3><button data-close aria-label="close">'+ic('x')+'</button></div><div class="quickgrid"><button data-action="addTask">'+ic('check')+' '+t('addTask')+'</button><button data-action="addTx">'+ic('wallet')+' '+t('addTx')+'</button><button data-action="addGoal">'+ic('target')+' '+t('addGoal')+'</button><button data-action="addHabit">'+ic('flame')+' '+t('addHabit')+'</button><button data-action="addJournal">'+ic('book')+' '+t('newEntry')+'</button></div>');return}
if(a==='addTask')return form(t('addTask'),'<label>'+t('title')+'<input name="title" required></label><label>'+t('date')+'<input name="date" type="date" value="'+today()+'"></label><label>Priority<select name="priority"><option>normal</option><option>high</option><option>low</option></select></label>','task');
if(a==='addGoal')return form(t('addGoal'),'<label>'+t('title')+'<input name="title" required></label><label>'+t('description')+'<textarea name="description"></textarea></label><label>'+t('goalType')+'<select name="kind"><option value="simple">'+t('simpleGoal')+'</option><option value="checklist">'+t('checklistGoal')+'</option></select></label><label>Deadline<input name="deadline" type="date"></label>','goal');
if(a==='addHabit')return form(t('addHabit'),'<label>'+t('title')+'<input name="title" required></label><label>'+t('description')+'<textarea name="description"></textarea></label><label>Icon<input name="icon" value="\u2726" maxlength="2"></label>','habit');
if(a==='addTx')return form(t('addTx'),'<label>'+t('title')+'<input name="title" required></label><label>'+t('amount')+'<input name="amount" type="number" min="0" required></label><label>'+t('type')+'<select name="type"><option value="expense">'+t('expenseType')+'</option><option value="income">'+t('incomeType')+'</option></select></label><label>'+t('category')+'<input name="category" value="General"></label><label>'+t('date')+'<input name="date" type="date" value="'+today()+'"></label>','tx');
if(a==='addJournal')return form(t('newEntry'),'<label>'+t('title')+'<input name="title" required></label><label>'+t('description')+'<textarea name="text" rows="7" required></textarea></label>','journal');
if(a==='addExercise')return form(t('addExercise'),'<label>'+t('exerciseName')+'<input name="title" required></label><label>'+t('exerciseName')+' (sec)<input name="seconds" type="number" min="5" value="45"></label>','exercise');
if(a==='toggleAlarm'){S.wellness.alarmOn=!S.wellness.alarmOn;if(S.wellness.alarmOn&&'Notification'in window&&Notification.permission==='default')Notification.requestPermission();showToast(t('done'),'bell')}
if(a==='toggleExercise'){let x=S.wellness.routine.find(function(x){return x.id===idv});if(x)x.done=!x.done}
if(a==='deleteExercise'){S.wellness.routine=S.wellness.routine.filter(function(x){return x.id!==idv});showToast(t('done'),'trash')}
if(a==='toggleSubtask'){let parts=idv.split('::'),g=S.goals.find(function(x){return x.id===parts[0]});let s=g&&(g.subtasks||[]).find(function(x){return x.id===parts[1]});if(s)s.done=!s.done}
if(a==='deleteSubtask'){let parts=idv.split('::'),g=S.goals.find(function(x){return x.id===parts[0]});if(g)g.subtasks=(g.subtasks||[]).filter(function(x){return x.id!==parts[1]})}
if(a==='soundRain'){playRain();render();return}
if(a==='soundFocus'){playTone(220,'focus');render();return}
if(a==='soundSleep'){playTone(110,'sleep');render();return}
if(a==='soundStop'){stopSoundNow();render();return}
if(a==='timerStart'){timerStart();render();return}
if(a==='timerPause'){timerPause();render();return}
if(a==='timerReset'){timerReset();render();return}
if(a==='timerSkip'){timerSkip();render();return}
if(a==='addProject')return form(t('addProject'),'<label>'+t('title')+'<input name="title" required></label><label>'+t('type')+'<select name="status">'+PST.map(function(k){return '<option value="'+k+'">'+t(PLBL[k])+'</option>'}).join('')+'</select></label>','project');
if(a==='moveProject'){let q=idv.split('::'),p=S.projects.find(function(x){return x.id===q[0]});if(p){let i=PST.indexOf(p.status)+(+q[1]);if(i>=0&&i<3)p.status=PST[i]}}
if(a==='deleteProject'){S.projects=S.projects.filter(function(x){return x.id!==idv});showToast(t('done'),'trash')}
if(a==='toggleTask'){let x=S.tasks.find(function(x){return x.id===idv});if(x){x.completed=!x.completed;if(x.completed)showMascotQuote(randomQuote())}}
if(a==='deleteTask'){S.tasks=S.tasks.filter(function(x){return x.id!==idv});showToast(t('done'),'trash')}
if(a==='deleteGoal'){S.goals=S.goals.filter(function(x){return x.id!==idv});showToast(t('done'),'trash')}
if(a==='toggleHabit'){let h=S.habits.find(function(x){return x.id===idv});if(h){h.checks=h.checks||{};let now=!h.checks[today()];h.checks[today()]=now;if(now)showMascotQuote(randomQuote())}}
if(a==='deleteTx'){S.tx=S.tx.filter(function(x){return x.id!==idv});showToast(t('done'),'trash')}
if(a==='deleteJournal'){S.journal=S.journal.filter(function(x){return x.id!==idv});showToast(t('done'),'trash')}
if(a==='theme'){S.theme=S.theme==='dark'?'light':'dark';theme()}
if(a==='backup'){download('alpha-backup.json',JSON.stringify({app:'Mahar',data:S},null,2),'application/json');showToast(t('done'),'arrowDown')}
if(a==='restore'){let f=$('#restoreFile');if(f)f.click()}
if(a==='reset'&&confirm('Reset all Mahar data?')){S=clone(D);showToast(t('done'),'trash')}
save();render();
}
function submit(e){
let f=e.target;if(!f.matches('form[data-form]'))return;e.preventDefault();
let d=Object.fromEntries(new FormData(f).entries());
if(f.dataset.form==='task')S.tasks.push({id:id('task'),title:d.title,date:d.date,priority:d.priority,completed:false});
if(f.dataset.form==='goal')S.goals.push({id:id('goal'),title:d.title,description:d.description,deadline:d.deadline,kind:d.kind==='checklist'?'checklist':'simple',progress:0,subtasks:[]});
if(f.dataset.form==='habit')S.habits.push({id:id('habit'),title:d.title,description:d.description,icon:d.icon||'\u2726',checks:{}});
if(f.dataset.form==='tx')S.tx.push({id:id('tx'),title:d.title,amount:+d.amount,type:d.type,category:d.category,date:d.date});
if(f.dataset.form==='journal')S.journal.push({id:id('journal'),title:d.title,text:d.text,date:today()});
if(f.dataset.form==='exercise'){ensureRoutine();S.wellness.routine.push({id:id('ex'),title:d.title,seconds:+d.seconds||45,done:false})}
if(f.dataset.form==='subtask'){let g=S.goals.find(function(x){return x.id===f.dataset.goal});if(g&&d.title){g.subtasks=g.subtasks||[];g.subtasks.push({id:id('sub'),title:d.title,done:false})}}
if(f.dataset.form==='project'){S.projects=S.projects||[];S.projects.push({id:id('proj'),title:d.title,status:d.status})}
if(f.dataset.form==='profile')S.profile.name=d.name;
save();
if(f.dataset.form==='subtask'){render();return}
close();showToast(t('done'));render();
}
function download(name,text,type){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:type}));a.download=name;a.click()}
document.addEventListener('click',function(e){if(e.target.closest('[data-close]'))close()});
document.addEventListener('input',function(e){if(e.target.matches('input.goal-slider')){let gid=e.target.dataset.goal,g=S.goals.find(function(x){return x.id===gid});if(!g)return;g.progress=+e.target.value;let card=e.target.closest('.card'),ring=card&&card.querySelector('svg.goal-ring');if(ring){let R=40,C=2*Math.PI*R,len=g.progress/100*C,circ=ring.querySelectorAll('circle')[1],txt=ring.querySelector('text');if(circ)circ.setAttribute('stroke-dasharray',len.toFixed(1)+' '+(C-len).toFixed(1));if(txt)txt.textContent=g.progress+'%'}}});
document.addEventListener('change',function(e){
if(e.target.matches('input.goal-slider')){save();return}
if(e.target.id==='languageSelect'){S.language=e.target.value;save();setLang();render()}
if(e.target.id==='currencySelect'){S.currency=e.target.value;save();render()}
if(e.target.id==='alarmTime'){S.wellness.alarmTime=e.target.value;save()}
if(e.target.id==='restoreFile'){let file=e.target.files&&e.target.files[0];if(file)file.text().then(function(x){try{let z=JSON.parse(x);if(z.data){S=z.data;save();showToast(t('done'));render()}}catch(err){alert('Invalid backup')}})}
});
window.Alpha={init:init};window.addEventListener('load',init);
})();
