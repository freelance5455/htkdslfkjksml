window.ALPHA_CONFIG={appName:'Mahar',contactEmail:'your-email@gmail.com',defaultCurrency:'AFN',defaultLanguage:'en'};
