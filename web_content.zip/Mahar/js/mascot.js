/* Mahar mascot — a small flat-illustration human character
   (head, hair, torso/clothing, arms with hands, legs with shoes).
   Two styles: 'teen' (hoodie, spiky hair with a bright streak) and
   'adult' (collared shirt, neat hair). Pure SVG shapes — no images,
   no 3D/WebGL library — so it stays tiny and fully offline. */
var __mascotUid = 0;
function mascotSVG(pose, size, style) {
  size = size || 96;
  style = style === 'adult' ? 'adult' : 'teen';
  var uid = 'm' + (++__mascotUid);
  var skin = '#e8b48a';
  var clothes, sleeveAccent, pants, shoes, hairColor, streak;
  if (style === 'adult') {
    clothes = '#3b4f56'; sleeveAccent = '#324349'; pants = '#262b30'; shoes = '#181310'; hairColor = '#241a14'; streak = null;
  } else {
    clothes = '#33e2c6'; sleeveAccent = '#22b79f'; pants = '#33414a'; shoes = '#f5f5f0'; hairColor = '#241a14'; streak = '#c6f24d';
  }

  var face, leftArm, rightArm, leftLeg, rightLeg, extra = '';

  function arm(x, y, rot, cx, cy) {
    return '<g transform="rotate(' + rot + ' ' + cx + ' ' + cy + ')">' +
      '<rect x="' + x + '" y="' + y + '" width="10" height="24" rx="5" fill="' + sleeveAccent + '" stroke="#0d1a08" stroke-width="1.6"/>' +
      '<circle cx="' + (x + 5) + '" cy="' + (y + 27) + '" r="5.5" fill="' + skin + '" stroke="#0d1a08" stroke-width="1.4"/>' +
      '</g>';
  }
  function leg(x, y, rot, cx, cy, shoeFlip) {
    return '<g transform="rotate(' + rot + ' ' + cx + ' ' + cy + ')">' +
      '<rect x="' + x + '" y="' + y + '" width="10" height="26" rx="5" fill="' + pants + '" stroke="#0d1a08" stroke-width="1.6"/>' +
      '<rect x="' + (x - (shoeFlip ? 1 : 2)) + '" y="' + (y + 24) + '" width="14" height="7" rx="3.5" fill="' + shoes + '" stroke="#0d1a08" stroke-width="1.4"/>' +
      '</g>';
  }

  if (pose === 'sleepy') {
    face = '<path d="M42 25q3 3 6 0" stroke="#0d1a08" stroke-width="2.2" fill="none" stroke-linecap="round"/>' +
           '<path d="M52 25q3 3 6 0" stroke="#0d1a08" stroke-width="2.2" fill="none" stroke-linecap="round"/>' +
           '<path d="M45 34q5 3 10 0" stroke="#0d1a08" stroke-width="2.2" fill="none" stroke-linecap="round"/>';
    leftArm  = arm(19, 56, 16, 24, 56);
    rightArm = arm(71, 56, -16, 76, 56);
    leftLeg  = leg(38, 98, 0, 43, 98);
    rightLeg = leg(51, 98, 0, 56, 98, true);
    extra = '<text x="72" y="16" font-size="12" font-weight="700" fill="' + (style === 'adult' ? '#8fb0a6' : '#33e2c6') + '" font-family="ui-monospace,monospace">z</text>' +
            '<text x="80" y="8" font-size="9" font-weight="700" fill="' + (style === 'adult' ? '#8fb0a6' : '#33e2c6') + '" font-family="ui-monospace,monospace">z</text>';
  } else if (pose === 'jump') {
    face = '<circle cx="45" cy="26" r="3" fill="#0d1a08"/><circle cx="55" cy="26" r="3" fill="#0d1a08"/>' +
           '<ellipse cx="50" cy="34" rx="4.5" ry="3.6" fill="#0d1a08"/>';
    leftArm  = arm(18, 30, -32, 23, 58);
    rightArm = arm(72, 30, 32, 77, 58);
    leftLeg  = leg(36, 96, -12, 41, 96);
    rightLeg = leg(53, 96, 12, 58, 96, true);
    extra = '<ellipse cx="50" cy="132" rx="18" ry="3.2" fill="#000" opacity=".18"/>';
  } else if (pose === 'happy') {
    face = '<circle cx="45" cy="26" r="3" fill="#0d1a08"/><circle cx="55" cy="26" r="3" fill="#0d1a08"/>' +
           '<path d="M43 33q7 6 14 0" stroke="#0d1a08" stroke-width="2.2" fill="none" stroke-linecap="round"/>';
    leftArm  = arm(19, 54, -12, 24, 54);
    rightArm = arm(71, 54, 12, 76, 54);
    leftLeg  = leg(38, 98, 0, 43, 98);
    rightLeg = leg(51, 98, 0, 56, 98, true);
  } else { /* wave (default) */
    face = '<circle cx="45" cy="26" r="3" fill="#0d1a08"/><circle cx="55" cy="26" r="3" fill="#0d1a08"/>' +
           '<path d="M44 33q6 5 12 0" stroke="#0d1a08" stroke-width="2.2" fill="none" stroke-linecap="round"/>';
    leftArm  = arm(19, 54, -10, 24, 54);
    rightArm = arm(71, 34, 48, 76, 62);
    leftLeg  = leg(38, 98, 0, 43, 98);
    rightLeg = leg(51, 98, 0, 56, 98, true);
  }

  var hair = style === 'adult'
    ? '<path d="M29 22 Q28 4 50 4 Q72 4 71 22 Q68 10 50 11 Q32 10 29 22 Z" fill="' + hairColor + '"/>'
    : '<path d="M28 23 Q29 5 36 15 Q40 0 46 14 Q50 1 54 14 Q60 0 64 15 Q71 5 72 23 Q62 11 50 13 Q38 11 28 23 Z" fill="' + hairColor + '"/>' +
      (streak ? '<path d="M46 14 Q49 2 53 13 Z" fill="' + streak + '"/>' : '');

  var collar = style === 'adult'
    ? '<path d="M42 44 L50 55 L58 44" stroke="#eef4ef" stroke-width="2.4" fill="none" stroke-linecap="round"/>'
    : '<path d="M40 45 Q50 40 60 45" stroke="' + sleeveAccent + '" stroke-width="4" fill="none" stroke-linecap="round"/>' +
      '<circle cx="50" cy="58" r="1.6" fill="' + sleeveAccent + '"/><circle cx="50" cy="65" r="1.6" fill="' + sleeveAccent + '"/>';

  return '<svg width="' + size + '" height="' + (size * 1.4) + '" viewBox="0 0 100 140" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<defs><radialGradient id="hi-' + uid + '" cx="34%" cy="18%" r="60%">' +
      '<stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset="55%" stop-color="#fff" stop-opacity="0"/>' +
    '</radialGradient></defs>' +
    (pose === 'jump' ? '' : '<ellipse cx="50" cy="132" rx="20" ry="3.5" fill="#000" opacity=".14"/>') +
    leftLeg + rightLeg +
    leftArm + rightArm +
    '<rect x="30" y="42" width="40" height="46" rx="16" fill="' + clothes + '" stroke="#0d1a08" stroke-width="2.2"/>' +
    collar +
    '<circle cx="50" cy="26" r="20" fill="' + skin + '" stroke="#0d1a08" stroke-width="2.2"/>' +
    '<circle cx="50" cy="26" r="20" fill="url(#hi-' + uid + ')"/>' +
    hair + face + extra +
    '</svg>';
}
