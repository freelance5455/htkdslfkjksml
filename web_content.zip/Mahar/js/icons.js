/* Mahar icon set — small hand-drawn line icons (SVG), no external deps, stroke=currentColor */
window.ALPHA_ICONS = {
  home: '<path d="M4 11.5 12 4l8 7.5"/><path d="M6 10v9a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1v-9"/><path d="M10 20v-6h4v6"/>',
  check: '<polyline points="4 12 9 17 20 6"/>',
  target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4.6"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/>',
  flame: '<path d="M8.6 14.7A2.6 2.6 0 0 0 11.2 12c0-1.4-.5-2-1-3-1.1-2.2-.2-4.2 2-6.2.5 2.6 2 5 4 6.6 2 1.6 2.9 3.5 2.9 5.5a7 7 0 1 1-14 0c0-1.2.4-2.3 1-3a2.6 2.6 0 0 0 2.5 2.8z"/>',
  wallet: '<path d="M3.5 7.2A2 2 0 0 1 5.5 5.2h11a2 2 0 0 1 2 2v2.2h2.2a1 1 0 0 1 1 1v6.4a2 2 0 0 1-2 2H5.5a2 2 0 0 1-2-2z"/><circle cx="16.8" cy="13.4" r="1.3" fill="currentColor" stroke="none"/>',
  book: '<path d="M4 5.8A2.3 2.3 0 0 1 6.3 3.5H12v17H6.3A2.3 2.3 0 0 1 4 18.2z"/><path d="M20 5.8a2.3 2.3 0 0 0-2.3-2.3H12v17h5.7A2.3 2.3 0 0 0 20 18.2z"/>',
  calendar: '<rect x="3.3" y="5" width="17.4" height="15.5" rx="2.2"/><path d="M3.3 9.8h17.4"/><path d="M8 3v4"/><path d="M16 3v4"/>',
  bars: '<path d="M4.5 20V11"/><path d="M12 20V4"/><path d="M19.5 20v-6.5"/>',
  mail: '<rect x="3" y="5.3" width="18" height="13.4" rx="2"/><path d="M3.4 6.5 12 13l8.6-6.5"/>',
  gear: '<circle cx="12" cy="12" r="7.2" stroke-dasharray="2.6 3.1"/><circle cx="12" cy="12" r="2.6" fill="currentColor" stroke="none"/>',
  search: '<circle cx="10.8" cy="10.8" r="6.8"/><path d="M20.2 20.2 15.6 15.6"/>',
  sun: '<circle cx="12" cy="12" r="3.6"/><path d="M12 3v2.2M12 18.8V21M4.9 4.9l1.6 1.6M17.5 17.5l1.6 1.6M3 12h2.2M18.8 12H21M4.9 19.1l1.6-1.6M17.5 6.5l1.6-1.6"/>',
  moon: '<path d="M20 14.6A8.6 8.6 0 1 1 9.4 4a7 7 0 0 0 10.6 10.6z"/>',
  menu: '<path d="M4 6.5h16M4 12h16M4 17.5h16"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  trash: '<path d="M4.5 7h15"/><path d="M9.5 7V4.3h5V7"/><path d="M6.3 7l.9 12.2a2 2 0 0 0 2 1.8h5.6a2 2 0 0 0 2-1.8L17.7 7"/>',
  arrowUp: '<path d="M7 17 17 7"/><path d="M9 7h8v8"/>',
  arrowDown: '<path d="M7 7l10 10"/><path d="M17 9v8H9"/>',
  sparkle: '<path d="M12 3.2 13.7 8 18.5 9.7l-4.8 1.7L12 16.2l-1.7-4.8L5.5 9.7 10.3 8z"/><path d="M18.7 15l.6 1.7 1.7.6-1.7.6-.6 1.7-.6-1.7-1.7-.6 1.7-.6z"/>',
  heart: '<path d="M12 20.3S3.6 14.9 3.6 8.9A4.6 4.6 0 0 1 12 6a4.6 4.6 0 0 1 8.4 2.9c0 6-8.4 11.4-8.4 11.4z"/>',
  timer: '<circle cx="12" cy="13.5" r="7.8"/><path d="M12 13.5V9"/><path d="M9.3 3.5h5.4"/><path d="M17.5 6.2l1.2-1.2"/>',
  wave: '<path d="M2 12c1.3-4.2 2.6-4.2 3.9 0s2.6 4.2 3.9 0 2.6-4.2 3.9 0 2.6-4.2 3.9 0 2.6-4.2 3.9 0"/>',
  play: '<path d="M7 5.3v13.4a1 1 0 0 0 1.5.9l10.7-6.7a1 1 0 0 0 0-1.8L8.5 4.4A1 1 0 0 0 7 5.3z" fill="currentColor" stroke="none"/>',
  pause: '<rect x="7" y="5.3" width="3.6" height="13.4" rx="1" fill="currentColor" stroke="none"/><rect x="13.4" y="5.3" width="3.6" height="13.4" rx="1" fill="currentColor" stroke="none"/>',
  skip: '<path d="M6 5.3v13.4a1 1 0 0 0 1.5.9l8.5-6.7a1 1 0 0 0 0-1.8L7.5 4.4A1 1 0 0 0 6 5.3z" fill="currentColor" stroke="none"/><rect x="17" y="5.3" width="2" height="13.4" rx="1" fill="currentColor" stroke="none"/>',
  bell: '<path d="M6 10a6 6 0 0 1 12 0c0 4.2 1.3 5.6 1.8 6.2H4.2C4.7 15.6 6 14.2 6 10z"/><path d="M9.6 19.2a2.4 2.4 0 0 0 4.8 0"/>',
  list: '<circle cx="4.5" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="4.5" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="4.5" cy="18" r="1.3" fill="currentColor" stroke="none"/><path d="M9 6h11M9 12h11M9 18h11"/>'
};
function ic(name, cls) {
  var d = window.ALPHA_ICONS[name] || '';
  return '<svg class="ic' + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>';
}
function mountIcons(root) {
  (root || document).querySelectorAll('[data-icon]').forEach(function (el) {
    el.innerHTML = ic(el.dataset.icon);
  });
}
