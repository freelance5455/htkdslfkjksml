(() => {
  'use strict';

  /* ---------- Constants ---------- */
  const LANES = [-3, 0, 3];
  const SEG = 20;
  const NSEG = 8;
  const RSPAN = SEG * NSEG;
  const PSPAN = 220;
  const CAR_HW = 0.95;
  const CAR_HL = 2.1;
  const SPAWN_Z = -170;
  const DESPAWN_Z = 14;
  const SKY = 0x7ecbff;
  const FOG = 0xbfe6ff;
  const OBS = {
    car: { hw: 0.95, d: 4.2, v: [8, 13] },
    truck: { hw: 1.15, d: 8, v: [4, 7] },
    bus: { hw: 1.15, d: 8.6, v: [3, 6] }
  };
  const OBS_COLORS = [0xffffff, 0x1e88e5, 0xfdd835, 0x8e24aa, 0x90a4ae, 0xf4511e, 0x00897b];

  const $ = (id) => document.getElementById(id);
  const rnd = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const lerp = (a, b, k) => a + (b - a) * k;

  /* ---------- Save ---------- */
  let best = 0;
  try { best = parseInt(localStorage.getItem('ecr3d_best') || '0', 10) || 0; } catch (e) { /* ignore */ }
  function saveBest(v) { try { localStorage.setItem('ecr3d_best', String(v)); } catch (e) { /* ignore */ } }

  /* ---------- Renderer & scene ---------- */
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
  renderer.setSize(window.innerWidth, window.innerHeight);
  $('game').appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(SKY);
  scene.fog = new THREE.Fog(FOG, 90, 260);

  const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 400);
  scene.add(new THREE.HemisphereLight(0xffffff, 0x3c6e2f, 0.85));
  const sun = new THREE.DirectionalLight(0xfff3d6, 0.9);
  sun.position.set(-30, 60, 20);
  scene.add(sun);

  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(350, 16, 12),
    new THREE.MeshBasicMaterial({ color: SKY, side: THREE.BackSide, fog: false })
  );
  scene.add(sky);
  const sunDisc = new THREE.Mesh(
    new THREE.SphereGeometry(10, 16, 12),
    new THREE.MeshBasicMaterial({ color: 0xfff6c9, fog: false })
  );
  sunDisc.position.set(-120, 140, -260);
  scene.add(sunDisc);

  /* ---------- Materials & geometry cache ---------- */
  const mat = (c) => new THREE.MeshLambertMaterial({ color: c });
  const basic = (c) => new THREE.MeshBasicMaterial({ color: c });
  const VMAT = {};
  const vm = (c) => VMAT[c] || (VMAT[c] = mat(c));
  const M = {
    grass: mat(0x4f9d3a),
    asph: mat(0x3a3d42),
    line: mat(0xf2f2f2),
    trunk: mat(0x6b4a2b),
    leaf: mat(0x2f7d32),
    leaf2: mat(0x43a047),
    bush: mat(0x3a8a3a),
    mtn: mat(0x5b7a68),
    mtn2: mat(0x4a6a5a),
    snow: mat(0xf5f7fa),
    cloud: mat(0xffffff),
    glass: mat(0x1d2e3d),
    tire: mat(0x1b1b1b),
    rim: mat(0xbfc5cc),
    stripe: mat(0xffffff),
    black: mat(0x111111),
    head: basic(0xfff7c2),
    tail: basic(0xff2a2a),
    shadow: new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.28, depthWrite: false })
  };

  const GEO_CTORS = {
    box: THREE.BoxGeometry,
    sphere: THREE.SphereGeometry,
    cyl: THREE.CylinderGeometry,
    cone: THREE.ConeGeometry,
    circle: THREE.CircleGeometry
  };
  const GC = {};
  function geo(type, ...args) {
    const key = type + ':' + args.join(',');
    return GC[key] || (GC[key] = new GEO_CTORS[type](...args));
  }
  function mesh(g, m, x = 0, y = 0, z = 0) {
    const o = new THREE.Mesh(g, m);
    o.position.set(x, y, z);
    return o;
  }

  /* ---------- Ground & endless road ---------- */
  scene.add(mesh(geo('box', 900, 0.2, 900), M.grass, 0, -0.12, -250));

  const road = [];
  for (let i = 0; i < NSEG; i++) {
    const g = new THREE.Group();
    g.add(mesh(geo('box', 9.2, 0.1, SEG), M.asph, 0, 0, 0));
    for (const lx of [-1.5, 1.5]) {
      for (const dz of [-7, 0, 7]) g.add(mesh(geo('box', 0.14, 0.02, 6), M.line, lx, 0.06, dz));
    }
    for (const ex of [-4.5, 4.5]) g.add(mesh(geo('box', 0.22, 0.02, SEG), M.line, ex, 0.06, 0));
    g.position.z = 10 - i * SEG;
    scene.add(g);
    road.push(g);
  }

  /* ---------- Scenery ---------- */
  function makeTree() {
    const g = new THREE.Group();
    const h = pick([3, 3.6, 4.2]);
    g.add(mesh(geo('cyl', 0.25, 0.35, h, 6), M.trunk, 0, h / 2, 0));
    g.add(mesh(geo('sphere', pick([1.8, 2.2]), 10, 8), pick([M.leaf, M.leaf2]), 0, h + 1.1, 0));
    g.add(mesh(geo('sphere', 1.3, 8, 6), pick([M.leaf, M.leaf2]), 0.9, h + 0.2, 0.5));
    return g;
  }
  function makeBush() {
    const g = new THREE.Group();
    g.add(mesh(geo('sphere', 0.9, 8, 6), M.bush, 0, 0.6, 0));
    g.add(mesh(geo('sphere', 0.7, 8, 6), M.bush, 0.8, 0.45, 0.3));
    g.add(mesh(geo('sphere', 0.6, 8, 6), M.bush, -0.7, 0.4, -0.2));
    return g;
  }
  function makeMountain() {
    const r = pick([35, 45, 55]);
    const h = pick([45, 60, 75]);
    const g = new THREE.Group();
    g.add(mesh(geo('cone', r, h, 7), pick([M.mtn, M.mtn2]), 0, h / 2, 0));
    g.add(mesh(geo('cone', r * 0.28, h * 0.28, 7), M.snow, 0, h * 0.86, 0));
    return g;
  }
  function makeCloud() {
    const g = new THREE.Group();
    g.add(mesh(geo('sphere', 4, 8, 6), M.cloud, 0, 0, 0));
    g.add(mesh(geo('sphere', 3.2, 8, 6), M.cloud, 4, -0.5, 0.5));
    g.add(mesh(geo('sphere', 3, 8, 6), M.cloud, -4, -0.4, -0.3));
    g.add(mesh(geo('sphere', 3, 8, 6), M.cloud, 1.5, 1.8, 0));
    return g;
  }

  const props = [];
  function addProp(obj, sign, xMin, xMax, y = 0, mul = 1) {
    obj.position.set(sign * rnd(xMin, xMax), y, rnd(-200, 20));
    scene.add(obj);
    props.push({ obj, sign, xMin, xMax, y, mul });
  }
  for (let i = 0; i < 22; i++) addProp(makeTree(), pick([-1, 1]), 8.5, 18, 0, 1);
  for (let i = 0; i < 26; i++) addProp(makeBush(), pick([-1, 1]), 6.5, 9.5, 0, 1);
  for (let i = 0; i < 14; i++) addProp(makeMountain(), pick([-1, 1]), 90, 170, 0, 0.12);
  for (let i = 0; i < 12; i++) addProp(makeCloud(), pick([-1, 1]), 30, 130, rnd(38, 55), 0.25);

  /* ---------- Vehicles ---------- */
  // dir: +1 faces the player (oncoming traffic), -1 faces away (player car)
  function buildVehicle(type, color, dir) {
    const g = new THREE.Group();
    const body = vm(color);
    const wheels = [];
    let W, L;

    if (type === 'car') {
      W = 1.9; L = 4.2;
      g.add(mesh(geo('box', W, 0.8, L), body, 0, 0.55, 0));
      g.add(mesh(geo('box', 1.62, 0.62, 2.1), M.glass, 0, 1.25, 0));
    } else if (type === 'truck') {
      W = 2.3; L = 8;
      g.add(mesh(geo('box', W, 2.5, 5.2), body, 0, 1.5, -1.4));
      g.add(mesh(geo('box', W, 2.0, 2.2), body, 0, 1.2, 2.9));
      g.add(mesh(geo('box', 2.0, 0.9, 0.05), M.glass, 0, 1.5, 2.9 + dir * 1.12));
    } else {
      W = 2.3; L = 8.6;
      g.add(mesh(geo('box', W, 2.9, L), body, 0, 1.6, 0));
      g.add(mesh(geo('box', 0.05, 0.9, 7.6), M.glass, -1.17, 2.1, 0));
      g.add(mesh(geo('box', 0.05, 0.9, 7.6), M.glass, 1.17, 2.1, 0));
      g.add(mesh(geo('box', 2.0, 1.2, 0.05), M.glass, 0, 2.0, dir * (L / 2 + 0.01)));
    }

    if (dir < 0) {
      g.add(mesh(geo('box', 0.45, 0.02, L * 0.92), M.stripe, 0, 0.96, 0));
      g.add(mesh(geo('box', 1.8, 0.1, 0.3), M.black, 0, 1.02, -dir * (L / 2 - 0.25)));
    }

    const frontZ = dir * (L / 2 + 0.02);
    const backZ = -dir * (L / 2 + 0.02);
    for (const sx of [-0.6, 0.6]) {
      g.add(mesh(geo('box', 0.36, 0.2, 0.05), M.head, sx, 0.7, frontZ));
      g.add(mesh(geo('box', 0.36, 0.2, 0.05), M.tail, sx, 0.7, backZ));
    }

    const zs = type === 'car' ? [-(L / 2 - 0.9), L / 2 - 0.9] : [-(L / 2 - 1.0), 0, L / 2 - 1.0];
    for (const sx of [-(W / 2 - 0.05), W / 2 - 0.05]) {
      for (const z of zs) {
        const wg = new THREE.Group();
        wg.position.set(sx, 0.45, z);
        const tire = mesh(geo('cyl', 0.45, 0.45, 0.36, 12), M.tire);
        tire.rotation.z = Math.PI / 2;
        const hub = mesh(geo('cyl', 0.24, 0.24, 0.38, 8), M.rim);
        hub.rotation.z = Math.PI / 2;
        wg.add(tire, hub);
        g.add(wg);
        wheels.push(wg);
      }
    }

    const shadow = mesh(geo('circle', 1, 16), M.shadow, 0, 0.08, 0);
    shadow.rotation.x = -Math.PI / 2;
    shadow.scale.set(W * 0.8, L * 0.6, 1);
    g.add(shadow);

    return { g, wheels };
  }

  /* ---------- Player car ---------- */
  const car = { g: null, wheels: [], x: LANES[1], lane: 1 };
  {
    const built = buildVehicle('car', 0xe53935, -1);
    car.g = built.g;
    car.wheels = built.wheels;
    scene.add(car.g);
  }

  /* ---------- Traffic ---------- */
  const vehicles = [];
  function spawnVehicle(type, lane) {
    const def = OBS[type];
    const x = LANES[lane];
    const { g } = buildVehicle(type, pick(OBS_COLORS), 1);
    g.position.set(x, 0, SPAWN_Z);
    scene.add(g);
    vehicles.push({
      g, x, z: SPAWN_Z, d: def.d, hw: def.hw,
      v: rnd(def.v[0], def.v[1]), passed: false
    });
  }
  function randomType() {
    const r = Math.random();
    return r < 0.6 ? 'car' : r < 0.85 ? 'truck' : 'bus';
  }
  function spawnPattern() {
    const lanes = [0, 1, 2].sort(() => Math.random() - 0.5);
    const twoLanes = Math.random() < 0.35 + Math.min(0.2, alive / 200);
    const count = twoLanes ? 2 : 1;
    for (let i = 0; i < count; i++) spawnVehicle(randomType(), lanes[i]);
  }

  /* ---------- Game state ---------- */
  let state = 'menu';
  let speed = 24;
  let distance = 0;
  let bonus = 0;
  let alive = 0;
  let sinceSpawn = 18;
  let nextGap = 40;
  let shake = 0;
  let lastScore = -1;
  let lastKmh = -1;
  let toastTimer = null;
  let flashTimer = null;
  let last = performance.now();

  const score = () => Math.floor(distance / 2) + bonus;

  /* ---------- Audio (synthesized with Web Audio, no files) ---------- */
  let ac = null, master = null, sfxBus = null, musicBus = null, noiseBuf = null;
  let engOsc = null, engFilter = null, engGain = null;
  let musicTimer = null, musicIdx = 0, musicNext = 0;
  let soundOn = true, musicOn = true;
  const MELODY = [220, 262, 330, 392, 330, 262, 247, 330, 392, 494, 392, 330, 262, 330, 392, 330];
  const BASS = [110, 110, 131, 131, 98, 98, 123, 123];
  const acNow = () => (ac ? ac.currentTime : 0);

  function initAudio() {
    try {
      if (!ac) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return;
        ac = new AC();
        master = ac.createGain();
        master.gain.value = 1;
        master.connect(ac.destination);
        sfxBus = ac.createGain();
        sfxBus.gain.value = soundOn ? 0.7 : 0;
        sfxBus.connect(master);
        musicBus = ac.createGain();
        musicBus.gain.value = musicOn ? 0.3 : 0;
        musicBus.connect(master);
        noiseBuf = ac.createBuffer(1, (ac.sampleRate * 0.5) | 0, ac.sampleRate);
        const d = noiseBuf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
      }
      if (ac.state === 'suspended') ac.resume();
    } catch (e) {
      ac = null;
    }
  }

  function toneAt(t, freq, dur, type, vol, slideTo, dest) {
    if (!ac) return;
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g);
    g.connect(dest || sfxBus);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  function noiseAt(t, dur, vol, freq) {
    if (!ac || !noiseBuf) return;
    const src = ac.createBufferSource();
    src.buffer = noiseBuf;
    const f = ac.createBiquadFilter();
    f.type = 'bandpass';
    f.frequency.value = freq;
    f.Q.value = 0.8;
    const g = ac.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    src.connect(f);
    f.connect(g);
    g.connect(sfxBus);
    src.start(t, Math.random() * 0.2);
    src.stop(t + dur + 0.05);
  }

  const SFX = {
    click: () => toneAt(acNow(), 900, 0.06, 'square', 0.12),
    hit: () => {
      noiseAt(acNow(), 0.8, 0.8, 300);
      toneAt(acNow(), 160, 0.6, 'sawtooth', 0.35, 30);
    },
    pass: () => {
      toneAt(acNow(), 660, 0.1, 'sine', 0.2);
      toneAt(acNow() + 0.08, 990, 0.14, 'sine', 0.2);
    },
    over: () => {
      [330, 262, 196].forEach((f, i) => toneAt(acNow() + 0.4 + i * 0.3, f, 0.45, 'triangle', 0.25));
    }
  };

  function startEngine() {
    if (!ac) return;
    if (!engOsc) {
      engOsc = ac.createOscillator();
      engOsc.type = 'sawtooth';
      engOsc.frequency.value = 60;
      engFilter = ac.createBiquadFilter();
      engFilter.type = 'lowpass';
      engFilter.frequency.value = 420;
      engGain = ac.createGain();
      engGain.gain.value = 0;
      engOsc.connect(engFilter);
      engFilter.connect(engGain);
      engGain.connect(sfxBus);
      engOsc.start();
    }
    engGain.gain.setTargetAtTime(0.05, ac.currentTime, 0.2);
  }
  function updateEngine() {
    if (!engOsc || !ac) return;
    engOsc.frequency.setTargetAtTime(50 + speed * 2.2, ac.currentTime, 0.08);
    engFilter.frequency.setTargetAtTime(300 + speed * 12, ac.currentTime, 0.1);
  }
  function stopEngine() {
    if (engGain && ac) engGain.gain.setTargetAtTime(0, ac.currentTime, 0.1);
  }

  function scheduleMusic() {
    if (!ac || !musicBus) return;
    while (musicNext < ac.currentTime + 0.4) {
      toneAt(musicNext, MELODY[musicIdx % MELODY.length], 0.18, 'triangle', 0.06, null, musicBus);
      if (musicIdx % 4 === 0) {
        toneAt(musicNext, BASS[(musicIdx >> 2) % BASS.length], 0.45, 'sine', 0.08, null, musicBus);
      }
      musicNext += 0.2;
      musicIdx++;
    }
  }
  function startMusic() {
    if (!ac || musicTimer) return;
    musicNext = Math.max(musicNext, ac.currentTime + 0.1);
    musicTimer = setInterval(scheduleMusic, 120);
  }
  function stopMusic() {
    if (musicTimer) {
      clearInterval(musicTimer);
      musicTimer = null;
    }
  }

  function toggleSound() {
    soundOn = !soundOn;
    if (sfxBus && ac) sfxBus.gain.setTargetAtTime(soundOn ? 0.7 : 0, ac.currentTime, 0.03);
    $('soundBtn').textContent = soundOn ? '🔊' : '🔇';
    $('soundBtn').classList.toggle('off', !soundOn);
  }
  function toggleMusic() {
    musicOn = !musicOn;
    if (musicBus && ac) musicBus.gain.setTargetAtTime(musicOn ? 0.3 : 0, ac.currentTime, 0.03);
    $('musicBtn').classList.toggle('off', !musicOn);
  }

  /* ---------- HUD & overlays ---------- */
  function showOverlay(name) {
    for (const n of ['menu', 'pause', 'over']) $(n).classList.toggle('hidden', n !== name);
  }

  function updateHud(force) {
    const sc = score();
    if (force || sc !== lastScore) {
      lastScore = sc;
      $('score').textContent = sc;
      $('best').textContent = Math.max(best, sc);
    }
    const kmh = Math.round(speed * 3.6);
    if (force || kmh !== lastKmh) {
      lastKmh = kmh;
      $('speed').textContent = kmh;
    }
  }

  function showToast(text) {
    const t = $('toast');
    t.textContent = text;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 700);
  }

  function flashScreen() {
    const f = $('flash');
    f.classList.add('on');
    clearTimeout(flashTimer);
    flashTimer = setTimeout(() => f.classList.remove('on'), 300);
  }

  /* ---------- Game flow ---------- */
  function clearTraffic() {
    for (const v of vehicles) scene.remove(v.g);
    vehicles.length = 0;
  }

  function resetRun() {
    clearTraffic();
    car.x = LANES[1];
    car.lane = 1;
    speed = 24;
    distance = 0;
    bonus = 0;
    alive = 0;
    sinceSpawn = 18;
    nextGap = 40;
    shake = 0;
    lastScore = -1;
    lastKmh = -1;
    updateHud(true);
  }

  function startGame() {
    initAudio();
    resetRun();
    state = 'playing';
    showOverlay(null);
    $('hud').classList.remove('hidden');
    startMusic();
    startEngine();
  }

  function pauseGame() {
    if (state !== 'playing') return;
    state = 'paused';
    stopEngine();
    stopMusic();
    showOverlay('pause');
  }

  function resumeGame() {
    if (state !== 'paused') return;
    state = 'playing';
    showOverlay(null);
    startMusic();
    startEngine();
  }

  function togglePause() {
    if (state === 'playing') pauseGame();
    else if (state === 'paused') resumeGame();
  }

  function toMenu() {
    state = 'menu';
    stopEngine();
    stopMusic();
    clearTraffic();
    $('hud').classList.add('hidden');
    $('menuBest').textContent = best;
    showOverlay('menu');
  }

  function gameOver() {
    state = 'over';
    shake = 0.9;
    flashScreen();
    SFX.hit();
    SFX.over();
    stopEngine();
    stopMusic();
    const sc = score();
    if (sc > best) {
      best = sc;
      saveBest(sc);
    }
    $('finalScore').textContent = sc;
    $('finalBest').textContent = best;
    $('menuBest').textContent = best;
    setTimeout(() => {
      if (state === 'over') {
        $('hud').classList.add('hidden');
        showOverlay('over');
      }
    }, 800);
  }

  /* ---------- Player actions ---------- */
  function moveLane(d) {
    const n = car.lane + d;
    if (n < 0 || n > 2) return;
    car.lane = n;
  }

  /* ---------- Collision ---------- */
  function hitVehicle(v) {
    if (Math.abs(car.x - v.x) >= CAR_HW + v.hw) return false;
    const zMin = v.z - v.d / 2;
    const zMax = v.z + v.d / 2;
    return zMin < CAR_HL && zMax > -CAR_HL;
  }

  /* ---------- Main update ---------- */
  function update(dt, live) {
    let s = 14;
    if (live) {
      alive += dt;
      speed = Math.min(46, 24 + alive * 0.5);
      s = speed;
      distance += speed * dt;
      sinceSpawn += speed * dt;
      if (sinceSpawn >= nextGap) {
        sinceSpawn = 0;
        nextGap = Math.max(16, 44 - alive * 0.3) * rnd(0.8, 1.2);
        spawnPattern();
      }
    }

    car.x = lerp(car.x, LANES[car.lane], Math.min(1, dt * 11));
    car.g.position.x = car.x;
    car.g.rotation.z = lerp(car.g.rotation.z, (LANES[car.lane] - car.x) * 0.06, Math.min(1, dt * 10));
    for (const w of car.wheels) w.rotation.x += (s * dt) / 0.45;

    for (const seg of road) {
      seg.position.z += s * dt;
      if (seg.position.z > 20) seg.position.z -= RSPAN;
    }
    for (const p of props) {
      p.obj.position.z += s * p.mul * dt;
      if (p.obj.position.z > 20) {
        p.obj.position.z -= PSPAN;
        p.obj.position.x = p.sign * rnd(p.xMin, p.xMax);
      }
    }

    for (let i = vehicles.length - 1; i >= 0; i--) {
      const v = vehicles[i];
      v.z += (s + v.v) * dt;
      v.g.position.z = v.z;
      if (v.z > DESPAWN_Z) {
        scene.remove(v.g);
        vehicles.splice(i, 1);
        continue;
      }
      if (live && !v.passed && v.z - v.d / 2 > CAR_HL) {
        v.passed = true;
        bonus += 50;
        SFX.pass();
        showToast('+50 PASS');
      }
      if (live && hitVehicle(v)) {
        live = false;
        gameOver();
      }
    }

    if (shake > 0) shake = Math.max(0, shake - dt * 2);
    const sh = shake * 0.35;
    const aspect = window.innerWidth / window.innerHeight;
    const baseFov = aspect < 0.8 ? 74 : 60;
    camera.fov = lerp(camera.fov, baseFov + Math.min(s, 46) * 0.08, Math.min(1, dt * 2));
    camera.updateProjectionMatrix();
    camera.position.set(car.x * 0.5 + rnd(-sh, sh), 4.2 + rnd(-sh, sh), 9.5);
    camera.lookAt(car.x * 0.8, 1.2, -14);
  }

  /* ---------- Render loop ---------- */
  function frame(t) {
    const dt = Math.min(0.05, (t - last) / 1000);
    last = t;
    if (state === 'playing') {
      update(dt, true);
      updateEngine();
      updateHud(false);
    } else if (state !== 'paused') {
      update(dt, false);
    }
    renderer.render(scene, camera);
    requestAnimationFrame(frame);
  }

  /* ---------- Input ---------- */
  document.addEventListener('pointerdown', (e) => {
    if (e.target.closest && e.target.closest('.btn')) {
      initAudio();
      SFX.click();
    }
  }, true);

  $('startBtn').addEventListener('click', startGame);
  $('resumeBtn').addEventListener('click', resumeGame);
  $('pauseRestart').addEventListener('click', startGame);
  $('pauseMenu').addEventListener('click', toMenu);
  $('overRestart').addEventListener('click', startGame);
  $('overMenu').addEventListener('click', toMenu);
  $('pauseBtn').addEventListener('click', togglePause);
  $('soundBtn').addEventListener('click', toggleSound);
  $('musicBtn').addEventListener('click', toggleMusic);

  $('leftBtn').addEventListener('pointerdown', (e) => {
    e.preventDefault();
    if (state === 'playing') moveLane(-1);
  });
  $('rightBtn').addEventListener('pointerdown', (e) => {
    e.preventDefault();
    if (state === 'playing') moveLane(1);
  });

  let sx = 0, sy = 0, swiping = false;
  window.addEventListener('touchstart', (e) => {
    if (e.target.closest && e.target.closest('button')) {
      swiping = false;
      return;
    }
    const t = e.touches[0];
    sx = t.clientX;
    sy = t.clientY;
    swiping = true;
  }, { passive: true });

  window.addEventListener('touchmove', (e) => { e.preventDefault(); }, { passive: false });

  window.addEventListener('touchend', (e) => {
    if (!swiping) return;
    swiping = false;
    if (state !== 'playing') return;
    const t = e.changedTouches[0];
    const dx = t.clientX - sx;
    const dy = t.clientY - sy;
    if (Math.abs(dx) < 30 || Math.abs(dx) < Math.abs(dy)) return;
    moveLane(dx > 0 ? 1 : -1);
  }, { passive: true });

  window.addEventListener('keydown', (e) => {
    const k = e.key;
    if (['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', ' '].includes(k)) e.preventDefault();
    if (k === 'p' || k === 'P' || k === 'Escape') { togglePause(); return; }
    if (e.repeat) return;
    if (state === 'menu' && k === 'Enter') { startGame(); return; }
    if (state === 'over' && k === 'Enter') { startGame(); return; }
    if (state !== 'playing') return;
    if (k === 'ArrowLeft' || k === 'a' || k === 'A') moveLane(-1);
    else if (k === 'ArrowRight' || k === 'd' || k === 'D') moveLane(1);
  });

  document.addEventListener('visibilitychange', () => {
    if (document.hidden && state === 'playing') pauseGame();
  });
  document.addEventListener('gesturestart', (e) => e.preventDefault());
  document.addEventListener('dblclick', (e) => e.preventDefault());

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  /* ---------- Init ---------- */
  resetRun();
  $('menuBest').textContent = best;
  showOverlay('menu');
  requestAnimationFrame(frame);
})();
