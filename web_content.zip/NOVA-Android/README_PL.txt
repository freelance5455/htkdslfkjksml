NØVA — projekt aplikacji Android

To jest projekt źródłowy Android Studio opakowujący lokalny interfejs NØVA w natywną aktywność Android WebView. Aplikacja nie wymaga połączenia z internetem do otwierania interfejsu.

JAK ZBUDOWAĆ APK
1. Zainstaluj Android Studio na komputerze.
2. Rozpakuj archiwum NOVA-Android.zip.
3. W Android Studio wybierz Open i wskaż folder NOVA-Android.
4. Poczekaj na synchronizację Gradle i instalację wymaganych Android SDK (API 35).
5. Wybierz Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug znajdziesz w app/build/outputs/apk/debug/app-debug.apk.
7. Przenieś APK na telefon i zainstaluj. Android może poprosić o zgodę na instalowanie aplikacji z danego źródła.

UWAGI
- W tym środowisku nie ma Android SDK ani Gradle, więc APK nie został tutaj skompilowany ani przetestowany na urządzeniu.
- Dane trackera zapisują się w lokalnym magazynie WebView na danym urządzeniu; odinstalowanie aplikacji może je usunąć. Eksportuj kopię zapasową.
- To wstępna wersja Android. Przed publikacją należy przetestować funkcje, dostępność, obsługę kopii danych oraz zasady targetowania SDK.
