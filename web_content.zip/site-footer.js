/* =====================================================
   QUÉ BOLÁ SHOP 🛒 — FOOTER COMPARTIDO
   Fondo azul oscuro y detalles naranjas.
   Mantiene el mismo pie de página en todas las secciones.
   ===================================================== */

(function () {
    "use strict";

    function instalarEstilos() {
        if (document.getElementById("qbSiteFooterStyles")) return;

        const style = document.createElement("style");

        style.id = "qbSiteFooterStyles";

        style.textContent = `
            /* =========================================
               CONTENEDOR PRINCIPAL DEL FOOTER
               ========================================= */

            .qb-site-footer {
                width: 100%;
                margin-top: 40px;
                background: #0f172a;
                color: #f8fafc;
                border-top: 3px solid #ff6000;
                box-shadow: 0 -4px 18px rgba(15, 23, 42, .12);
                font-family: inherit;
                box-sizing: border-box;
            }

            .qb-site-footer *,
            .qb-site-footer *::before,
            .qb-site-footer *::after {
                box-sizing: border-box;
            }

            /* =========================================
               CONTENIDO Y COLUMNAS
               ========================================= */

            .qb-site-footer-inner {
                width: min(1100px, calc(100% - 32px));
                margin: 0 auto;
                padding: 36px 0 30px;

                display: grid;

                grid-template-columns:
                    minmax(220px, 1.4fr)
                    minmax(140px, 1fr)
                    minmax(180px, 1fr);

                gap: 30px;
            }

            /* =========================================
               MARCA QUÉ BOLÁ SHOP
               ========================================= */

            .qb-site-footer-brand {
                display: inline-block;
                margin: 0 0 12px;

                color: #ffffff;

                font-size: 21px;
                font-weight: 800;

                text-decoration: none;
            }

            .qb-site-footer-brand span {
                color: #ff7a00;
            }

            /* =========================================
               DESCRIPCIÓN
               ========================================= */

            .qb-site-footer p {
                margin: 0 0 8px;

                color: #cbd5e1;

                font-size: 14px;
                line-height: 1.6;
            }

            /* =========================================
               TÍTULOS DE LAS COLUMNAS
               ========================================= */

            .qb-site-footer h2 {
                margin: 3px 0 14px;

                color: #ffffff;

                font-size: 14px;
                font-weight: 800;

                letter-spacing: .04em;
                text-transform: uppercase;
            }

            /* =========================================
               LISTA DE ENLACES
               ========================================= */

            .qb-site-footer-links {
                display: flex;
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }

            .qb-site-footer a.qb-footer-link,
            .qb-site-footer .qb-footer-text {
                color: #cbd5e1;

                font-size: 14px;
                line-height: 1.5;

                text-decoration: none;
                overflow-wrap: anywhere;
            }

            /* =========================================
               EFECTOS DE LOS ENLACES
               ========================================= */

            .qb-site-footer a.qb-footer-link:hover,
            .qb-site-footer a.qb-footer-link:focus-visible {
                color: #ff7a00;
                text-decoration: underline;
            }

            /* =========================================
               FRANJA INFERIOR Y COPYRIGHT
               ========================================= */

            .qb-site-footer-bottom {
                border-top: 1px solid #334155;
                padding: 16px;
                text-align: center;
            }

            .qb-site-footer-bottom p {
                margin: 0;

                color: #94a3b8;

                font-size: 12px;
            }

            /* =========================================
               DISEÑO PARA TELÉFONOS Y TABLETS
               ========================================= */

            @media (max-width: 700px) {

                .qb-site-footer {
                    margin-top: 28px;
                }

                .qb-site-footer-inner {
                    grid-template-columns: minmax(0, 1fr);

                    gap: 24px;

                    padding: 28px 0 24px;
                }
            }
        `;

        document.head.appendChild(style);
    }

    /* =============================================
       CREAR ENLACES
       ============================================= */

    function crearEnlace(texto, href) {
        const enlace = document.createElement("a");

        enlace.className = "qb-footer-link";
        enlace.href = href;
        enlace.textContent = texto;

        if (/^https?:\/\//i.test(href)) {
            enlace.target = "_blank";
            enlace.rel = "noopener noreferrer";
        }

        return enlace;
    }

    /* =============================================
       CREAR COLUMNAS
       ============================================= */

    function crearColumna(titulo, elementos) {
        const columna = document.createElement("section");

        const heading = document.createElement("h2");

        heading.textContent = titulo;

        columna.appendChild(heading);

        const links = document.createElement("div");

        links.className = "qb-site-footer-links";

        elementos.forEach((elemento) => {

            if (elemento.href) {

                links.appendChild(
                    crearEnlace(elemento.texto, elemento.href)
                );

            } else {

                const texto = document.createElement("span");

                texto.className = "qb-footer-text";
                texto.textContent = elemento.texto;

                links.appendChild(texto);
            }
        });

        columna.appendChild(links);

        return columna;
    }

    /* =============================================
       CREAR FOOTER COMPLETO
       ============================================= */

    function crearFooter() {

        const footer = document.createElement("footer");

        footer.className = "qb-site-footer";

        footer.setAttribute(
            "aria-label",
            "Pie de página"
        );

        /* CONTENEDOR INTERIOR */

        const inner = document.createElement("div");

        inner.className = "qb-site-footer-inner";

        /* =========================================
           COLUMNA 1: MARCA Y DESCRIPCIÓN
           ========================================= */

        const marca = document.createElement("section");

        const logo = document.createElement("a");

        logo.className = "qb-site-footer-brand";
        logo.href = "feed.html";

        logo.appendChild(
            document.createTextNode("Qué Bolá ")
        );

        const shop = document.createElement("span");

        shop.textContent = "SHOP🛒";

        logo.appendChild(shop);

        marca.appendChild(logo);

        const descripcion = document.createElement("p");

        descripcion.textContent =
            "Productos, servicios y comunidad en un solo lugar.";

        marca.appendChild(descripcion);

        inner.appendChild(marca);

        /* =========================================
           COLUMNA 2: NAVEGACIÓN
           ========================================= */

        inner.appendChild(
            crearColumna("Navegación", [
                {
                    texto: "Inicio / Feed",
                    href: "feed.html"
                },
                {
                    texto: "Tienda Oficial",
                    href: "tienda.html"
                },
                {
                    texto: "Negocios",
                    href: "negocios.html"
                },
                {
                    texto: "Servicios",
                    href: "servicios.html"
                },
                {
                    texto: "Empleo",
                    href: "empleo.html"
                },
                {
                    texto: "Ofertas de empleo",
                    href: "ofertas-empleo.html"
                },
                {
                    texto: "Empleados",
                    href: "empleados.html"
                },
                {
                    texto: "Chat",
                    href: "chat.html"
                },
                {
                    texto: "Planes y servicios",
                    href: "planes.html"
                }
            ])
        );

        /* =========================================
           COLUMNA 3: INFORMACIÓN Y CONTACTO
           ========================================= */

        inner.appendChild(
            crearColumna("Información y contacto", [
                {
                    texto: "Sobre nosotros",
                    href: "sobre-nosotros.html"
                },
                {
                    texto: "Reglas de la comunidad",
                    href: "reglas.html"
                },
                {
                    texto: "WhatsApp: +5356123351"
                },
                {
                    texto: "Facebook: Qué Bolá SHOP",
                    href: "https://www.facebook.com/profile.php?id=61592026652861",
                    externo: true
                }
            ])
        );

        footer.appendChild(inner);

        /* =========================================
           COPYRIGHT
           ========================================= */

        const bottom = document.createElement("div");

        bottom.className = "qb-site-footer-bottom";

        const copyright = document.createElement("p");

        copyright.textContent =
            "© 2026 Qué Bolá SHOP. Todos los derechos reservados.";

        bottom.appendChild(copyright);

        footer.appendChild(bottom);

        return footer;
    }

    /* =============================================
       INSTALAR EL FOOTER EN LA PÁGINA
       ============================================= */

    function iniciar() {

        instalarEstilos();

        /*
         * Sustituir únicamente los footers principales
         * de cada página.
         *
         * No se modifican los pies internos de modales
         * ni los pies de las tarjetas.
         */

        document.querySelectorAll("body > footer").forEach((footer) => {

            if (!footer.classList.contains("qb-site-footer")) {
                footer.remove();
            }

        });

        /*
         * Crear el footer compartido si todavía
         * no existe en la página.
         */

        if (!document.querySelector("body > .qb-site-footer")) {

            document.body.appendChild(
                crearFooter()
            );

        }
    }

    /* =============================================
       INICIO SEGURO
       ============================================= */

    if (document.readyState === "loading") {

        document.addEventListener(
            "DOMContentLoaded",
            iniciar,
            { once: true }
        );

    } else {

        iniciar();

    }

})();