const fs=require("fs"),f=(a,b)=>{const c=a.find(fs.existsSync);fs.copyFileSync(c,b);console.log("copiado",c)};
f(["node_modules/chart.js/dist/chart.umd.js","node_modules/chart.js/dist/chart.umd.min.js"],"www/chart.umd.js");
f(["node_modules/jszip/dist/jszip.min.js"],"www/jszip.min.js");
