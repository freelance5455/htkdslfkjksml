Elite Bakery Billing - Android project (fixed image sharing)

The previous WebView version showed "browser does not support direct image sharing".
This version adds a native Android share bridge: Share as Image opens the Android share sheet with the generated PNG attached.

Open this project in Android Studio and build the APK.
