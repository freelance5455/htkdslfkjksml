ELITE BAKERY ANDROID APP PROJECT

This is an Android Studio project wrapping the Elite Bakery billing web app.

Features:
- Elite Bakery branding
- 34 products with Wholesale/Retail prices
- Customer/shop name
- Bill history
- Paid and Pending
- WhatsApp sharing
- Android print dialog
- GST No: 32BJRPS8553B1ZX
- Contact: 9446711892 | 7025916191
- Location: Court Junction, Mavelikara

HOW TO BUILD APK:
1. Open this folder in Android Studio.
2. Let Gradle sync/download dependencies.
3. Select Build > Build App Bundle(s) / APK(s) > Build APK(s).
4. Android Studio will produce the APK under app/build/outputs/apk/debug/.

This project is a first version; the invoice can be refined further after testing on the phone.
