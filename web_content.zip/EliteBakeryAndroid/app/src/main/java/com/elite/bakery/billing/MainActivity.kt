package com.elite.bakery.billing

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.JsResult
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                android.widget.Toast.makeText(this@MainActivity, message ?: "", android.widget.Toast.LENGTH_SHORT).show()
                result?.cancel()
                return true
            }
        }
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            builtInZoomControls = false
            displayZoomControls = false
        }
        web.addJavascriptInterface(ShareBridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })
    }

    inner class ShareBridge {
        @JavascriptInterface
        fun shareImage(dataUrl: String, filename: String) {
            try {
                val comma = dataUrl.indexOf(',')
                if (comma < 0) return
                val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
                val dir = File(cacheDir, "shared_images").apply { mkdirs() }
                val file = File(dir, if (filename.endsWith(".png", true)) filename else "$filename.png")
                file.outputStream().use { it.write(bytes) }
                val uri: Uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", file)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TITLE, "${shopTitle()} Bill")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    clipData = android.content.ClipData.newRawUri("Elite Bakery Bill", uri)
                }
                // Open WhatsApp directly when it is installed; otherwise show Android's normal share sheet.
                send.setPackage("com.whatsapp")
                try {
                    startActivity(send)
                } catch (_: Exception) {
                    send.setPackage(null)
                    startActivity(Intent.createChooser(send, "Share Elite Bakery Bill"))
                }
            } catch (e: Exception) {
                runOnUiThread {
                    android.widget.Toast.makeText(this@MainActivity, "Could not share the bill image", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
        @JavascriptInterface
        fun shopTitle(): String = "Elite Bakery"
    }
}
