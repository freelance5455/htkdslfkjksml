#!/usr/bin/env python3
"""Serve My Fan A List on this Android device via Termux, bound to loopback only."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import os

ROOT = Path(__file__).resolve().parent
HOST = "127.0.0.1"
PORT = 4173


class AppHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


if __name__ == "__main__":
    os.chdir(ROOT)
    try:
        server = ThreadingHTTPServer((HOST, PORT), AppHandler)
    except OSError as error:
        raise SystemExit(
            f"Não foi possível abrir a porta {PORT}. Feche outro servidor local "
            "e tente novamente."
        ) from error

    print("My Fan A List está disponível neste telefone:")
    print(f"  http://{HOST}:{PORT}/")
    print("Abra esse endereço no Chrome. Mantenha o Termux aberto até a instalação terminar.")
    print("Este servidor aceita apenas ligações locais do próprio telefone.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServidor local encerrado.")
    finally:
        server.server_close()
