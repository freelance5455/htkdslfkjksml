// Service-worker logic simulation; does not replace an actual HTTPS Android offline-install test.
const fs=require('fs'),vm=require('vm'),path=require('path');
const root=__dirname;
const handlers={};const stores=new Map();const base='https://loonie.example/';
let online=false;
const key=x=>new URL(typeof x==='string'?x:x.url,base).href;
function cacheStore(id){
 if(!stores.has(id))stores.set(id,new Map());const map=stores.get(id);
 return {
   addAll:async files=>{for(const f of files){const file=path.resolve(root,f);if(!fs.existsSync(file)&&f!=='./')throw new Error('Missing cache asset: '+f);map.set(key(f),{ok:true,body:f,clone(){return this;}})}},
   put:async(x,val)=>{map.set(key(x),val)},
   match:async x=>map.get(key(x))||null
 };
}
const caches={open:async k=>cacheStore(k),keys:async()=>Array.from(stores.keys()),delete:async k=>stores.delete(k),match:async x=>{for(const map of stores.values()){const hit=map.get(key(x));if(hit)return hit;}return null;}};
const self={location:{origin:'https://loonie.example'},clients:{claim:async()=>{}},skipWaiting:async()=>{},addEventListener:(name,cb)=>handlers[name]=cb};
async function fetch(request){if(!online)throw Error('OFFLINE');return{ok:true,body:'NEW PAGE',clone(){return this;}};}
vm.runInNewContext(fs.readFileSync(path.join(root,'sw.js'),'utf8'),{self,caches,fetch,URL,console},{filename:'sw.js'});
(async()=>{
 let p;handlers.install({waitUntil:x=>p=x});await p;
 const c=stores.get('loonie-20261116-v13');
 if(!c||c.size<21)throw Error('Missing pre-cached core files');
 for(const file of ['./inquiry-v9.js','./inquiry-v9.css','./kingdom-v10.js','./kingdom-v10.css','./career-v11.js','./career-v11.css','./life-v12.js','./life-v12.css','./curriculum-v13.js','./academy-v13.js','./academy-v13.css'])if(!c.has(key(file)))throw Error('Missing required app asset '+file);
 const stale=stores.set('loonie-20261115-v9',new Map());
 handlers.activate({waitUntil:x=>p=x});await p;
 if(stores.has('loonie-20261115-v9'))throw Error('Old cache was not cleared');
 const get=async(request)=>{let wait;handlers.fetch({request,respondWith:x=>wait=x});return wait?await wait:null;};
 let result=await get({url:base+'curriculum-v7.js',method:'GET',mode:'cors'});
 if(!result||result.body!=='./curriculum-v7.js')throw Error('Offline v7 lesson file unavailable');
 result=await get({url:base,method:'GET',mode:'navigate'});
 if(!result||result.body!=='./index.html')throw Error('Offline navigation not served from index cache');
 online=true;
 result=await get({url:base,method:'GET',mode:'navigate'});
 if(!result||result.body!=='NEW PAGE')throw Error('Navigation not network first');
 console.log('PASS: all 21 core resources precached, old cache purged, offline lesson and navigation served, online navigation refreshed');
})().catch(e=>{console.error(e);process.exitCode=1;});
