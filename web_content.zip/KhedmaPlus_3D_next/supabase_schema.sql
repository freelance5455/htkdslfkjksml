-- Khedma Plus shared backend foundation
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key default gen_random_uuid(),
 full_name text not null,
 phone text unique not null,
 role text not null check (role in ('customer','craft','admin')),
 job text,
 password_hash text,
 points integer not null default 0 check (points >= 0),
 rating numeric(3,2) not null default 0,
 ratings_count integer not null default 0,
 verified boolean not null default false,
 suspended boolean not null default false,
 created_at timestamptz not null default now()
);
create table if not exists public.service_requests (
 id uuid primary key default gen_random_uuid(),
 customer_id uuid references public.profiles(id) on delete cascade,
 customer_phone text not null,
 customer_name text not null,
 description text not null,
 detected_trade text,
 location text,
 image_data text,
 status text not null default 'pending',
 craft_id uuid references public.profiles(id),
 craft_phone text,
 craft_name text,
 accepted_at timestamptz,
 created_at timestamptz not null default now()
);
create table if not exists public.point_requests (
 id uuid primary key default gen_random_uuid(),
 artisan_id uuid references public.profiles(id) on delete cascade,
 points_requested integer not null check (points_requested >= 150 and points_requested % 25 = 0),
 amount_dzd integer generated always as (points_requested * 10) stored,
 payment_method text not null default 'baridimob',
 receipt_data text,
 payment_ref text,
 status text not null default 'pending' check (status in ('pending','approved','rejected')),
 admin_note text,
 created_at timestamptz not null default now(),
 reviewed_at timestamptz
);
create table if not exists public.ratings (
 id uuid primary key default gen_random_uuid(),
 request_id uuid references public.service_requests(id) on delete cascade,
 customer_id uuid references public.profiles(id),
 artisan_id uuid references public.profiles(id),
 stars integer not null check (stars between 1 and 5),
 comment text,
 created_at timestamptz not null default now()
);
create table if not exists public.complaints (
 id uuid primary key default gen_random_uuid(),
 request_id uuid references public.service_requests(id) on delete set null,
 reporter_id uuid references public.profiles(id) on delete set null,
 artisan_id uuid references public.profiles(id) on delete set null,
 message text not null,
 status text not null default 'open',
 created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.service_requests enable row level security;
alter table public.point_requests enable row level security;
alter table public.ratings enable row level security;
alter table public.complaints enable row level security;

-- Temporary public-client policies for the first deployment. Tighten these after moving auth to Supabase Auth.
drop policy if exists profiles_public_read on public.profiles;
create policy profiles_public_read on public.profiles for select to anon, authenticated using (true);
drop policy if exists profiles_public_insert on public.profiles;
create policy profiles_public_insert on public.profiles for insert to anon, authenticated with check (true);
drop policy if exists profiles_public_update on public.profiles;
create policy profiles_public_update on public.profiles for update to anon, authenticated using (true) with check (true);
drop policy if exists requests_public_read on public.service_requests;
create policy requests_public_read on public.service_requests for select to anon, authenticated using (true);
drop policy if exists requests_public_insert on public.service_requests;
create policy requests_public_insert on public.service_requests for insert to anon, authenticated with check (true);
drop policy if exists requests_public_update on public.service_requests;
create policy requests_public_update on public.service_requests for update to anon, authenticated using (true) with check (true);
drop policy if exists point_public_insert on public.point_requests;
create policy point_public_insert on public.point_requests for insert to anon, authenticated with check (true);
drop policy if exists point_public_read on public.point_requests;
create policy point_public_read on public.point_requests for select to anon, authenticated using (true);
drop policy if exists rating_public_all on public.ratings;
create policy rating_public_all on public.ratings for all to anon, authenticated using (true) with check (true);
drop policy if exists complaint_public_all on public.complaints;
create policy complaint_public_all on public.complaints for all to anon, authenticated using (true) with check (true);
