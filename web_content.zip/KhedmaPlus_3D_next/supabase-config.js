// Khedma Plus - Supabase public client configuration.
// Only the publishable/anon key belongs here. Never put service_role/secret in the app.
window.KHEDMA_SUPABASE_URL = "https://dqokmwkovgmgvlcaytts.supabase.co";
window.KHEDMA_SUPABASE_ANON_KEY = "sb_publishable_w9AoWrv-zXKrAT31T0CgDg_PK8tN9je";
