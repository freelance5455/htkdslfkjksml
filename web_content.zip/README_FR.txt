# NEXORA AI — interface web mobile

## Contenu
- `index.html` : interface autonome, à la racine du ZIP.
- `backend_example/` : exemple minimal de backend Python pour le contrôle de santé et l'explication des routes à connecter.
- `.env.example` : noms des secrets à configurer côté serveur.

## Ouvrir / convertir en APK
1. Décompressez le ZIP ou importez-le directement dans votre convertisseur de site vers APK.
2. Vérifiez que `index.html` reste à la racine.
3. L'interface fonctionne en local pour la navigation et la préparation des demandes.

## Connexions IA : sécurité
Ne saisissez jamais vos clés API dans `index.html`, dans un ZIP public ou dans le stockage du navigateur.
Configurez les clés comme variables d'environnement secrètes sur un backend HTTPS que vous administrez.
Les noms prévus sont dans `backend_example/.env.example`.

Fournisseurs proposés :
- Gemini : https://aistudio.google.com/
- OpenAI : https://platform.openai.com/api-keys
- fal.ai (images et modèles vidéo) : https://fal.ai/dashboard/keys
- Runway : https://dev.runwayml.com/
- ElevenLabs (voix et musique selon accès) : https://elevenlabs.io/

Une clé ne donne pas automatiquement accès à tous les services. Certains modèles nécessitent un compte, des crédits ou un abonnement.

## Backend exemple
Le dossier `backend_example` est un squelette de démarrage, pas un moteur multimédia complet.
Il expose `/health` et `/api/chat` avec une réponse d'erreur explicite tant qu'un adaptateur fournisseur n'est pas implémenté.
Les générations d'images, vidéos, musique, manga et films ne sont donc pas prétendues fonctionnelles dans cette livraison.

## Déploiement
Déployez le backend sur un hébergement HTTPS, configurez les variables secrètes dans le tableau de bord de l'hébergeur, puis indiquez son URL dans Paramètres de l'application.
