PAGE PRO+ — VERSION APK COMPATIBLE V2
1. Décompressez ce ZIP.
2. Dans votre outil HTML → APK, choisissez index.html (ou index.htm si l'outil demande ce nom).
3. Les fichiers du dossier assets doivent rester avec le fichier HTML.
4. Cette version ne dépend d'aucun site externe pour afficher la première page.
5. Le bouton œil fonctionne : il affiche/masque le mot de passe.
