PAGE PRO+ - VERSION 4
Correction importante : les champs e-mail et mot de passe sont maintenant positionnés au-dessus de l'image et peuvent recevoir les touches du clavier.
Le bouton œil affiche/cache le mot de passe.
Importez le contenu de ce ZIP dans votre outil HTML vers APK en conservant le dossier assets.
Cette version corrige l'écran et la saisie. La connexion réelle et la création de Pages nécessitent le serveur Page Pro+.
