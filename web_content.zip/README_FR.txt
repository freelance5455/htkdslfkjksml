NOVA ULTIMATE AI — SITE WEB POUR CONVERSION EN APK

CONTENU
- index.html : page principale (à la racine du ZIP)
- style.css : design mobile et ordinateur
- app.js : navigation, chat et formulaires de création
- manifest.webmanifest : paramètres d'installation web

UTILISATION
1. Décompressez le ZIP ou importez-le dans votre convertisseur ZIP-vers-APK.
2. Le fichier index.html doit rester à la racine du site.
3. Dans NOVA, ouvrez Paramètres et saisissez l'adresse HTTPS de votre serveur.
4. Vérifiez que les routes API configurées existent réellement sur ce serveur.

ROUTES PAR DÉFAUT
POST /chat
POST /generate-image
POST /generate-video
POST /generate-manga
POST /generate-anime

FORMAT DES REQUÊTES
Chat : {"message":"Bonjour"}
Création : {"prompt":"Description", "style":"Anime"}
Les réponses attendues sont des objets JSON. Pour une image, utilisez par exemple
{"image_url":"https://..."}; pour une vidéo, {"video_url":"https://..."}.

IMPORTANT
Ce ZIP contient le site web et son interface, pas les moteurs IA. Les vraies
créations exigent un serveur avec ces routes et les fournisseurs IA correspondants.
Les clés API secrètes doivent rester sur le serveur, jamais dans le site ou l'APK.
Si « Failed to fetch » apparaît, vérifiez l'URL du serveur, CORS, HTTPS et les routes.
Aucune clé API n'est incluse. La connexion doit être configurée par le propriétaire
avec l'aide d'un adulte de confiance si un compte ou un paiement est nécessaire.
