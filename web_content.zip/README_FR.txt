BELGIA — Prototype Android installable (PWA)
============================================

CONTENU
- Interface responsive adaptée au GSM et au PC.
- Tableau de bord.
- Fiches d'entités : création et recherche.
- Import local de fichiers .txt.
- Recherche lexicale locale dans les fiches et documents.
- Stockage dans le navigateur de l'appareil.
- Manifest et service worker pour installation PWA.

IMPORTANT
Cette version est une preuve de concept, pas une application sécurisée homologuée.
N'y saisissez aucune donnée réelle, personnelle, policière, sensible, confidentielle ou secrète.
Les exemples sont fictifs. Aucune IA générative locale n'est encore intégrée : la recherche
est lexicale et fonctionne sans appel à un service externe. Les données du navigateur ne
sont pas chiffrées par cette application et peuvent être perdues si les données du site sont effacées.
L'interface charge Google Fonts lorsqu'une connexion internet est disponible; les fonctions
principales restent conçues pour fonctionner en local une fois la PWA mise en cache.

POUR TESTER SUR ANDROID
1. Décompressez ce dossier.
2. Hébergez-le sur un serveur HTTPS de confiance (par exemple un hébergement statique privé
   adapté à une démo, ou votre propre serveur). Une PWA ne s'installe généralement pas depuis
   un simple fichier index.html ouvert localement.
3. Ouvrez l'adresse HTTPS dans Chrome sur Android.
4. Menu ⋮ > Installer l'application ou Ajouter à l'écran d'accueil.
5. Utilisez uniquement les données fictives de démonstration.

POUR LE DÉVELOPPEMENT LOCAL SUR PC
Vous pouvez utiliser Python pour servir les fichiers depuis le dossier :
  python -m http.server 8000
Puis ouvrir http://localhost:8000
Cette méthode sert à tester sur le PC. Pour installer sur le GSM, l'appareil doit accéder
à un site HTTPS (ou une configuration de développement adaptée).

PROCHAINES ÉTAPES
- Vérifier l'ergonomie sur le modèle Android réel.
- Ajouter des relations explicites entre entités.
- Ajouter export/import JSON et sauvegarde contrôlée.
- Évaluer un petit modèle local (par exemple via llama.cpp/Ollama côté PC ou runtime Android),
  en fonction des performances du matériel. Une IA réellement locale sur le téléphone demandera
  une intégration supplémentaire et des tests de mémoire, vitesse et compatibilité.
- Ajouter authentification, chiffrement au repos, journal d'audit et contrôle d'accès avant
  tout usage autre que démonstratif.
