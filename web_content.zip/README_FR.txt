Page Pro+ V2 - écran d'accueil interactif

Contenu : index.html + index.htm + assets.
- Le champ e-mail est directement cliquable.
- Le champ Mot de passe est directement cliquable.
- L'œil permet d'afficher ou masquer le mot de passe; la petite barre apparaît/disparaît réellement.
- « Se connecter » est cliquable.
- « Créer votre Page Professionnelle » est cliquable.

Pour un convertisseur HTML -> APK : sélectionnez le fichier index.html (ou index.htm) avec le dossier assets conservé au même niveau.
