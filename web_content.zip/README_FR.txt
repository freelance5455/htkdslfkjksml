NEXUS UNIVERSE AI — VERSION WEB

Contenu :
- index.html : page principale (à la racine du ZIP)
- style.css : apparence mobile
- app.js : navigation, réglages et tentative de connexion au serveur

CONVERSION APK
1. Importer ce ZIP dans un convertisseur de site Web vers APK.
2. Vérifier que index.html est à la racine de l'archive.
3. Générer l'APK puis l'installer.

IMPORTANT
Cette archive fournit l'interface Web. Elle ne contient pas de moteur IA ni de générateur d'images, de vidéos ou d'audio. La connexion au cerveau IA ne fonctionnera que si un serveur compatible est configuré. Le format de requête du serveur doit correspondre à celui attendu par app.js.
Ne stocke pas de clés API secrètes dans une application distribuée. Conserve-les sur un serveur sécurisé.
