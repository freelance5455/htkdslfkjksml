NEXORA OMEGA AI ULTIMATE — VERSION 3.0
======================================

CONTENU
- Interface mobile-first, adaptée aux écrans Android.
- Écran d'accueil chat-first.
- Menu latéral ☰ avec nouvelle conversation, navigation et studios.
- Studios Anime, Vidéo, Musique, Creative Lab, Projets et Paramètres.
- Brouillons et préférences conservés localement dans le navigateur.
- Manifest PWA et service worker de base.
- Mise en page portrait/paysage et commandes tactiles.

INSTALLATION / ESSAI SUR ANDROID
1. Décompresse le ZIP dans un dossier sur ton téléphone.
2. Pour tester simplement, ouvre index.html dans un navigateur compatible.
3. Certaines fonctions PWA hors ligne nécessitent un hébergement HTTPS.
4. Pour produire un APK, il faut empaqueter le projet avec Capacitor et un environnement Android SDK. Ce ZIP n'est pas un APK.

LIMITES IMPORTANTES
- Cette version est un prototype fonctionnel d'interface et de sauvegarde locale.
- Le chat donne des réponses de démonstration, pas des réponses générées par un vrai modèle IA.
- Aucune génération réelle d'image, d'animation, de vidéo, de voix ou de musique n'est intégrée.
- Les studios enregistrent des brouillons et des storyboards textuels uniquement.
- Aucun fournisseur IA ni backend n'est connecté.
- Les fonctions avancées nécessitent un backend et des fournisseurs externes. Les clés privées doivent rester côté serveur, jamais dans app.js, index.html ou le navigateur.

STRUCTURE
index.html              Interface
style.css               Design responsive
app.js                  Navigation, chat de démonstration, sauvegarde locale
manifest.webmanifest    Métadonnées PWA
sw.js                   Cache hors ligne de base
capacitor.config.json   Configuration de départ Capacitor
backend/README_BACKEND.txt Notes d'architecture backend sécurisée

DÉVELOPPEMENT
Voir backend/README_BACKEND.txt avant toute connexion à un fournisseur IA.
