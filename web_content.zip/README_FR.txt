PAGE PRO+ — VERSION 5 (écran de connexion stabilisé)

1. Décompressez le ZIP.
2. Dans votre application HTML vers APK, choisissez le fichier index.html.
3. Gardez le dossier assets avec index.html : ne le séparez pas.
4. Générez l'APK.

Cette version garde l'écran de connexion fixe pendant la saisie et l'ouverture du clavier.
Les champs e-mail et mot de passe sont modifiables; l'icône œil affiche/cache le mot de passe.
Le bouton de connexion nécessite toujours un serveur réel Page Pro+; ce ZIP corrige l'interface, pas le serveur.
