NEXORA AI ULTIMATE — VERSION WEB POUR CONVERTISSEUR ZIP VERS APK

Ce ZIP contient un petit site web mobile :
- index.html : page principale
- style.css : apparence
- app.js : interactions de démonstration

UTILISATION
1. Dans l'application ZIP vers APK, sélectionne ce fichier ZIP.
2. Si un aperçu est proposé, vérifie que la page NEXORA s'affiche.
3. Continue dans le convertisseur en suivant ses étapes.

IMPORTANT
Cette version est une interface de démonstration. Elle ne contient aucune clé API et ne génère pas réellement d'images, de vidéos ou de musique. Les boutons de modules indiquent leur état. Le chat est une simulation locale.
Pour une vraie IA, il faudra ensuite créer un serveur sécurisé, connecter les fournisseurs IA et ajouter l'authentification. Ne place jamais une clé API secrète dans le fichier APK ou dans app.js.
