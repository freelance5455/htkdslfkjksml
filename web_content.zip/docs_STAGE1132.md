# CPLS V2 — Stage 1132

## Candle Integrity Merge
- Normalizes candle timestamps to the active timeframe bucket.
- Merges duplicate candles instead of silently dropping later OHLC updates.
- Preserves latest close while accumulating high/low/volume.
- Keeps chronological ordering and rejects older out-of-order candles.
- Builds on Stage 1131 without changing the native Futures transport.

Source ZIP stage only; APK build not performed.
