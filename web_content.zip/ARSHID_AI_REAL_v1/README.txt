ARSHID AI v1.0 — REAL AI CHAT STARTER

This project contains a real Gemini API connection through a small Node.js backend.
It is not a ready-to-install APK yet. It must be hosted on a server before the
chat page can call the AI.

IMPORTANT SECURITY
- Never paste your API key into index.html or any APK.
- Keep the key only as the server environment variable GEMINI_API_KEY.
- Do not share your key in ChatGPT, messages, screenshots, or public code.
- This starter has basic request limiting, but is not ready for a public launch.
  Add user authentication, stricter quotas, and monitoring before sharing it widely.
- Free-tier quotas and model access can change. Check the official pricing page.
- API usage on the free tier has its own data-use terms; read them before sending
  private or sensitive information.

WHAT IS INCLUDED
- Mobile-friendly chat interface
- Server-side Gemini API call
- Short conversation context
- Basic rate limiting
- No API key stored in the browser

SETUP (a parent/guardian may need to help with developer-account setup)
1. Install Node.js on a computer/server. Acode alone cannot run this backend.
2. Extract the ZIP and open the project folder in a terminal.
3. Run: npm install
4. Copy .env.example to .env.
5. Add your Gemini API key to GEMINI_API_KEY in .env.
6. Run: npm start
7. Open http://localhost:3000 in a browser on the same device/server.

DEPLOYMENT
Deploy the Node.js project to a trusted hosting provider that supports environment
variables. Add GEMINI_API_KEY in the host's server-side Environment Variables panel.
Do not commit or upload the .env file.

OFFICIAL GEMINI DOCUMENTATION
https://ai.google.dev/gemini-api/docs/get-started
https://ai.google.dev/gemini-api/docs/pricing

NEXT STEP
Once the backend is hosted, the chat UI can be wrapped in an Android app.
An APK built before the backend is configured will not have working AI chat.
