import "dotenv/config";
import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 15,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Please wait a minute and try again." }
}));

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.GEMINI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(503).json({
        error: "AI is not connected yet. The app owner must add GEMINI_API_KEY on the server."
      });
    }

    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const safeMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-12)
      .map(m => `${m.role === "user" ? "User" : "ARSHID AI"}: ${m.content.slice(0, 4000)}`);

    if (!safeMessages.length || !safeMessages.some(m => m.startsWith("User:"))) {
      return res.status(400).json({ error: "Please type a message first." });
    }

    const prompt = [
      "You are ARSHID AI, a helpful, honest, friendly AI assistant.",
      "Answer clearly. If you are unsure, say so. Do not claim to have live internet access.",
      "",
      safeMessages.join("\n\n"),
      "",
      "ARSHID AI:"
    ].join("\n");

    const upstream = await fetch("https://generativelanguage.googleapis.com/v1beta/interactions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey
      },
      body: JSON.stringify({
        model: "gemini-3.8-flash",
        input: prompt,
        store: false
      })
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("Gemini API error:", upstream.status, data?.error?.message || "Unknown error");
      return res.status(502).json({
        error: "The AI service could not complete that request. Check the server API key, model access, and usage limits."
      });
    }

    let answer = data.output_text;
    if (!answer && Array.isArray(data.steps)) {
      const parts = [];
      for (const step of data.steps) {
        if (step.type === "model_output" && Array.isArray(step.content)) {
          for (const item of step.content) {
            if (item.type === "text" && item.text) parts.push(item.text);
          }
        }
      }
      answer = parts.join("\n").trim();
    }

    if (!answer) {
      return res.status(502).json({ error: "The AI returned an empty response. Please try again." });
    }

    res.json({ reply: answer });
  } catch (err) {
    console.error("Server error:", err);
    res.status(500).json({ error: "Server error. Please try again." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`ARSHID AI running on port ${port}`));
