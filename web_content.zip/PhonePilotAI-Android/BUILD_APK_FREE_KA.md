# PhonePilot AI — APK-ის უფასოდ აწყობა

ამ პროექტს APK-ის აწყობის GitHub Actions workflow დაემატა.

1. შექმენი უფასო ანგარიში https://github.com-ზე და შექმენი ახალი repository.
2. ZIP-ის ამოღებული შიგთავსი ატვირთე repository-ის ზედა დონეზე (ამ საქაღალდის ფაილები, არა გარე საქაღალდე). დარწმუნდი, რომ `.github/workflows/build-apk.yml` ატვირთულია.
3. გახსენი repository-ის **Actions** ჩანართი და აირჩიე **Build PhonePilot AI APK**.
4. დააჭირე **Run workflow** (ან დაელოდე push-ის შემდეგ ავტომატურ გაშვებას).
5. დასრულების შემდეგ გახსენი წარმატებული run, ბოლოში **Artifacts** სექციაში ჩამოტვირთე `PhonePilotAI-debug-apk`. ZIP არტეფაქტის შიგნით იქნება `app-debug.apk`.

ეს არის debug APK ტესტირებისთვის და არა ხელმოწერილი Google Play release. პროექტის ფუნქციები ამჟამად პროტოტიპია; README-ში აღწერილია შეზღუდვები.
