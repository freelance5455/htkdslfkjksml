Retro Snake - APK build (Capacitor 8)

CLOUD BUILD (no Android Studio needed)
1. Create a free GitHub repository and upload every file from this folder.
   Keep the workflow at .github/workflows/build.yml (exact path).
2. Open the Actions tab > "Build APK" > Run workflow.
3. When it finishes, open the run, download the "retro-snake-apk" artifact,
   unzip it and install app-debug.apk (allow installs from unknown sources).

LOCAL BUILD (Node 22+, JDK 21, Android SDK)
  mkdir www && cp index.html www/
  npm install
  npx cap add android
  npx cap sync android
  cd android && ./gradlew assembleDebug
  APK: android/app/build/outputs/apk/debug/app-debug.apk

BEFORE GOOGLE PLAY
- Change appId in capacitor.config.json to a package name you own
  (com.example.* is not accepted by Play).
- Build a signed release bundle (.aab); the debug APK is for your own phone.
