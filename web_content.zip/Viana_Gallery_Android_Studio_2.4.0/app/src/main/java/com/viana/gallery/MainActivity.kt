package com.viana.gallery

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.ValueCallback
import android.webkit.WebChromeClient.FileChooserParams
import android.content.ContentValues
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties

class MainActivity : FragmentActivity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private val prefs by lazy { getSharedPreferences("viana_secure", MODE_PRIVATE) }
    @Volatile private var pickerActive = false
    @Volatile private var biometricActive = false
    @Volatile private var fileChooserActive = false
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val singleImagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        fileChooserActive = false
        fileChooserCallback?.onReceiveValue(if (uri == null) null else arrayOf(uri))
        fileChooserCallback = null
    }
    private val picker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { uris ->
        if (uris.isNotEmpty()) deliverPickedImages(uris) else pickerActive = false
    }

    override fun onStop() {
        super.onStop()
        if (::webView.isInitialized && !pickerActive && !fileChooserActive && !biometricActive) {
            runOnUiThread { webView.evaluateJavascript("window.handleNativeBackground && window.handleNativeBackground()", null) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(13, 16, 32)
        window.navigationBarColor = Color.rgb(9, 13, 24)
        ensurePinInitialized()
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(9, 13, 24))
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.settings.setSupportMultipleWindows(false)
        webView.addJavascriptInterface(VianaBridge(), "NativeViana")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                this@MainActivity.fileChooserCallback?.onReceiveValue(null)
                this@MainActivity.fileChooserCallback = filePathCallback
                fileChooserActive = true
                val accepted = fileChooserParams?.acceptTypes?.firstOrNull { it.isNotBlank() } ?: "*/*"
                singleImagePicker.launch(accepted)
                return true
            }
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                assetLoader.shouldInterceptRequest(request.url)
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.host != "appassets.androidplatform.net"
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun ensurePinInitialized() {
        if (!prefs.contains("pin_blob")) setSecureValue("pin_blob", "24")
    }

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("VianaGalleryAesKey", null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder(
            "VianaGalleryAesKey",
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build())
        return generator.generateKey()
    }

    private fun encryptString(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8))
        val out = ByteArrayOutputStream()
        out.write(cipher.iv)
        out.write(encrypted)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    private fun decryptString(value: String): String {
        val raw = Base64.decode(value, Base64.NO_WRAP)
        require(raw.size > 12) { "Invalid encrypted payload" }
        val iv = raw.copyOfRange(0, 12)
        val encrypted = raw.copyOfRange(12, raw.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(encrypted), StandardCharsets.UTF_8)
    }

    private fun setSecureValue(key: String, value: String): Boolean = try {
        prefs.edit().putString(key, encryptString(value)).commit()
    } catch (_: Exception) { false }

    private fun verifyPin(value: String): Boolean {
        return try {
            val blob = prefs.getString("pin_blob", null) ?: return false
            val expected = decryptString(blob)
            java.security.MessageDigest.isEqual(
                expected.toByteArray(StandardCharsets.UTF_8),
                value.toByteArray(StandardCharsets.UTF_8)
            )
        } catch (_: Exception) { false }
    }

    private fun authenticateBiometric() {
        biometricActive = true
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val manager = BiometricManager.from(this)
        if (manager.canAuthenticate(authenticators) != BiometricManager.BIOMETRIC_SUCCESS) {
            biometricActive = false
            runOnUiThread { webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false,'biometric_unavailable')", null) }
            return
        }
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                biometricActive = false
                webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true,'authenticated')", null)
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                biometricActive = false
                val safe = JSONObject.quote("$errorCode:$errString")
                webView.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false,$safe)", null)
            }
            override fun onAuthenticationFailed() {
                webView.evaluateJavascript("window.onBiometricAttemptFailed && window.onBiometricAttemptFailed()", null)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Viana Gallery")
            .setSubtitle("تأیید هویت برای ورود به گالری")
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }

    private fun deliverPickedImages(uris: List<Uri>) {
        Thread {
            val result = JSONArray()
            var totalBytes = 0L
            uris.take(10).forEach { uri ->
                try {
                    val mime = contentResolver.getType(uri) ?: "image/jpeg"
                    val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return@forEach
                    if (bytes.size > 12 * 1024 * 1024 || totalBytes + bytes.size > 36L * 1024 * 1024) return@forEach
                    totalBytes += bytes.size
                    val item = JSONObject()
                    item.put("name", queryDisplayName(uri) ?: "photo-${System.currentTimeMillis()}.jpg")
                    item.put("data", "data:$mime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP))
                    result.put(item)
                } catch (_: Exception) { }
            }
            pickerActive = false
            runOnUiThread {
                webView.evaluateJavascript("window.onNativeImages && window.onNativeImages(${JSONObject.quote(result.toString())})", null)
            }
        }.start()
    }

    private fun saveDataUrl(dataUrl: String, fileName: String): Boolean {
        return try {
            val comma = dataUrl.indexOf(',')
            require(dataUrl.startsWith("data:") && comma > 0)
            val header = dataUrl.substring(0, comma)
            val mime = header.substringAfter("data:").substringBefore(';').ifBlank { "image/jpeg" }
            val bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
            val safeName = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "viana-photo.jpg" }
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create download")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                    ?: throw IllegalStateException("Could not open download")
                values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null) > 0
            } else {
                val dir = getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                FileOutputStream(File(dir, safeName)).use { it.write(bytes) }
                true
            }
        } catch (_: Exception) { false }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }

    inner class VianaBridge {
        @JavascriptInterface fun verifyPin(pin: String): Boolean = this@MainActivity.verifyPin(pin)
        @JavascriptInterface fun getPinLength(): Int = try { decryptString(prefs.getString("pin_blob", null) ?: "").length } catch (_: Exception) { 2 }
        @JavascriptInterface fun isBiometricAvailable(): Boolean { val a = BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL; return BiometricManager.from(this@MainActivity).canAuthenticate(a) == BiometricManager.BIOMETRIC_SUCCESS }
        @JavascriptInterface fun setPin(pin: String): Boolean {
            if (!pin.matches(Regex("\\d{2,8}"))) return false
            return setSecureValue("pin_blob", pin)
        }
        @JavascriptInterface fun authenticateBiometric() { runOnUiThread { this@MainActivity.authenticateBiometric() } }
        @JavascriptInterface fun pickImages() { runOnUiThread { pickerActive = true; picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) } }
        @JavascriptInterface fun encryptText(value: String): String = try { encryptString(value) } catch (_: Exception) { "" }
        @JavascriptInterface fun decryptText(value: String): String = try { decryptString(value) } catch (_: Exception) { "" }
        @JavascriptInterface fun saveDataUrl(data: String, name: String): Boolean = this@MainActivity.saveDataUrl(data, name)
        @JavascriptInterface fun saveTextFile(text: String, name: String): Boolean = this@MainActivity.saveDataUrl("data:application/json;base64," + Base64.encodeToString(text.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP), name)
        @JavascriptInterface fun getDeviceInfo(): String = JSONObject().apply {
            put("manufacturer", android.os.Build.MANUFACTURER)
            put("model", android.os.Build.MODEL)
            put("android", android.os.Build.VERSION.RELEASE)
            put("sdk", android.os.Build.VERSION.SDK_INT)
            put("appVersion", BuildConfig.VERSION_NAME)
        }.toString()
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        webView.evaluateJavascript("if(window.lockApp){window.lockApp()}", null)
    }
}
