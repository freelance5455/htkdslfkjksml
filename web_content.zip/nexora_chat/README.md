# NEXORA — Connect Beyond Numbers

A mobile-friendly web chat starter with:
- Username + password registration/login (no phone number or email field)
- Password hashing with bcrypt
- Profile display name and profile photo
- Username search
- Persisted one-to-one text messages
- Image/video attachments
- Socket.IO realtime message delivery
- WebRTC voice/video call signaling prototype

## Important limits
This is a starter, not a fully production-ready messenger. It does not include password recovery, end-to-end encryption, push notifications, abuse reporting/blocking, rate limiting, a TURN relay, or a polished incoming-call flow. Calls may fail on some networks without a TURN server. Uploaded files are stored on the server disk; many hosting providers use temporary disks, so configure persistent object storage before public launch. Do not use it for sensitive/private conversations until reviewed and hardened.

## Requirements
- Node.js 20+
- PostgreSQL database
- A host that supports a long-running Node server and WebSockets (for example, a suitable Node hosting service)
- HTTPS in production (required by browser camera/microphone APIs)

## Run locally
1. Install Node.js 20+.
2. Extract this folder.
3. Copy `.env.example` to `.env`.
4. Fill in `DATABASE_URL`.
5. Generate a long random JWT secret (32+ characters) and put it in `JWT_SECRET`.
6. Install dependencies and start:
   ```bash
   npm install
   npm start
   ```
7. Open `http://localhost:3000` in your browser.

The server creates the required database tables on first start. Your PostgreSQL database user needs permission to create tables.

## Deploy overview
1. Create a PostgreSQL database with your chosen provider.
2. Deploy this folder as a Node web service from a Git repository.
3. Set environment variables: `DATABASE_URL`, `JWT_SECRET`, and if required `PGSSL=true`.
4. Use a persistent upload volume or replace local uploads with object storage (S3-compatible storage, Supabase Storage, etc.).
5. Enable HTTPS and verify WebSocket support.
6. Add request rate limiting, upload scanning, content moderation/report/block controls, logging, backups, account recovery, and privacy policy before inviting friends.

## Usernames and passwords
- Usernames: 3–24 letters, numbers, underscores; case-insensitive.
- Passwords: at least 10 characters.
- Passwords are hashed with bcrypt; plaintext passwords are never stored.
- Username-only login means forgotten passwords cannot currently be recovered. Consider adding a recovery code or optional recovery method that does not require a phone number.

## Calling notes
The included WebRTC flow is a learning prototype. It uses Google's public STUN server and has no TURN relay, no call timeout, no busy-state coordination, and only basic signaling. For dependable calls, add a TURN service, call/session IDs, accept/reject/timeout handling, candidate buffering, reconnection, and robust cleanup. Camera/microphone access requires HTTPS except on localhost.
