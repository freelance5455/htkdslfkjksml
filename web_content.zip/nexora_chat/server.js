require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const { Pool } = require("pg");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET;
if (!process.env.DATABASE_URL || !JWT_SECRET || JWT_SECRET.length < 32) {
  console.error("Set DATABASE_URL and a JWT_SECRET of at least 32 characters in .env");
  process.exit(1);
}
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: false } : undefined
});
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));
const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
app.use("/uploads", express.static(uploadDir, { maxAge: "1h" }));

const maxMb = Math.max(1, Number(process.env.MAX_UPLOAD_MB || 8));
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase().slice(0, 8);
    cb(null, crypto.randomUUID() + ext);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: maxMb * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /^(image\/(jpeg|png|webp|gif)|video\/mp4|audio\/webm|audio\/ogg)$/.test(file.mimetype);
    cb(ok ? null : new Error("Only image, MP4 video and supported audio files are allowed"), ok);
  }
});

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      username VARCHAR(24) UNIQUE NOT NULL,
      display_name VARCHAR(40) NOT NULL,
      password_hash TEXT NOT NULL,
      avatar_url TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS messages (
      id BIGSERIAL PRIMARY KEY,
      sender_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      receiver_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      body TEXT,
      media_url TEXT,
      media_type VARCHAR(30),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS messages_pair_time_idx
      ON messages (sender_id, receiver_id, created_at DESC);
  `);
}
function publicUser(u) {
  return { id: u.id, username: u.username, displayName: u.display_name, avatarUrl: u.avatar_url || null };
}
function signUser(u) {
  return jwt.sign({ id: String(u.id), username: u.username }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  try {
    if (!token) throw new Error("missing");
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Please log in again." });
  }
}
const validUsername = /^[a-zA-Z0-9_]{3,24}$/;

app.post("/api/register", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim().toLowerCase();
    const displayName = String(req.body.displayName || "").trim();
    const password = String(req.body.password || "");
    if (!validUsername.test(username)) return res.status(400).json({ error: "Username must be 3–24 letters, numbers or underscores." });
    if (displayName.length < 1 || displayName.length > 40) return res.status(400).json({ error: "Name must be 1–40 characters." });
    if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "Password must be 10–128 characters." });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users (username, display_name, password_hash) VALUES ($1,$2,$3) RETURNING *",
      [username, displayName, hash]
    );
    const u = result.rows[0];
    res.json({ token: signUser(u), user: publicUser(u) });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "That username is already taken." });
    console.error(e);
    res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/login", async (req, res) => {
  try {
    const username = String(req.body.username || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const result = await pool.query("SELECT * FROM users WHERE username=$1", [username]);
    const u = result.rows[0];
    if (!u || !(await bcrypt.compare(password, u.password_hash))) {
      return res.status(401).json({ error: "Username or password is incorrect." });
    }
    res.json({ token: signUser(u), user: publicUser(u) });
  } catch (e) {
    console.error(e); res.status(500).json({ error: "Could not log in." });
  }
});
app.get("/api/me", auth, async (req, res) => {
  const r = await pool.query("SELECT * FROM users WHERE id=$1", [req.user.id]);
  if (!r.rows[0]) return res.status(404).json({ error: "Account not found." });
  res.json({ user: publicUser(r.rows[0]) });
});
app.get("/api/users", auth, async (req, res) => {
  const q = String(req.query.q || "").trim().toLowerCase();
  if (q.length < 3) return res.json({ users: [] });
  const r = await pool.query(
    "SELECT id, username, display_name, avatar_url FROM users WHERE username LIKE $1 AND id<>$2 ORDER BY username LIMIT 20",
    [`${q.replace(/[%_\\]/g, "\\$&")}%`, req.user.id]
  );
  res.json({ users: r.rows.map(publicUser) });
});
app.patch("/api/profile", auth, upload.single("avatar"), async (req, res) => {
  try {
    const displayName = String(req.body.displayName || "").trim();
    if (!displayName || displayName.length > 40) return res.status(400).json({ error: "Name must be 1–40 characters." });
    const avatarUrl = req.file ? `/uploads/${req.file.filename}` : undefined;
    const r = avatarUrl
      ? await pool.query("UPDATE users SET display_name=$1, avatar_url=$2 WHERE id=$3 RETURNING *", [displayName, avatarUrl, req.user.id])
      : await pool.query("UPDATE users SET display_name=$1 WHERE id=$2 RETURNING *", [displayName, req.user.id]);
    res.json({ user: publicUser(r.rows[0]) });
  } catch (e) { console.error(e); res.status(500).json({ error: "Could not update profile." }); }
});
app.get("/api/messages/:username", auth, async (req, res) => {
  const other = await pool.query("SELECT id FROM users WHERE username=$1", [String(req.params.username).toLowerCase()]);
  if (!other.rows[0]) return res.status(404).json({ error: "User not found." });
  const r = await pool.query(
    `SELECT m.id, m.body, m.media_url AS "mediaUrl", m.media_type AS "mediaType",
            m.created_at AS "createdAt", su.username AS "senderUsername"
     FROM messages m JOIN users su ON su.id=m.sender_id
     WHERE (m.sender_id=$1 AND m.receiver_id=$2) OR (m.sender_id=$2 AND m.receiver_id=$1)
     ORDER BY m.created_at DESC LIMIT 100`,
    [req.user.id, other.rows[0].id]
  );
  res.json({ messages: r.rows.reverse() });
});
app.post("/api/messages/:username", auth, upload.single("file"), async (req, res) => {
  try {
    const other = await pool.query("SELECT id FROM users WHERE username=$1", [String(req.params.username).toLowerCase()]);
    if (!other.rows[0]) return res.status(404).json({ error: "User not found." });
    const body = String(req.body.body || "").trim().slice(0, 4000);
    const file = req.file;
    if (!body && !file) return res.status(400).json({ error: "Write a message or attach a file." });
    const mediaUrl = file ? `/uploads/${file.filename}` : null;
    const mediaType = file ? file.mimetype : null;
    const r = await pool.query(
      "INSERT INTO messages (sender_id, receiver_id, body, media_url, media_type) VALUES ($1,$2,$3,$4,$5) RETURNING id, body, media_url AS \"mediaUrl\", media_type AS \"mediaType\", created_at AS \"createdAt\"",
      [req.user.id, other.rows[0].id, body || null, mediaUrl, mediaType]
    );
    const message = { ...r.rows[0], senderUsername: req.user.username, receiverUsername: String(req.params.username).toLowerCase() };
    io.to(`user:${other.rows[0].id}`).emit("message:new", message);
    io.to(`user:${req.user.id}`).emit("message:new", message);
    res.json({ message });
  } catch (e) {
    console.error(e); res.status(500).json({ error: "Could not send message." });
  }
});

io.use((socket, next) => {
  try {
    const token = socket.handshake.auth && socket.handshake.auth.token;
    socket.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { next(new Error("Authentication required")); }
});
io.on("connection", socket => {
  socket.join(`user:${socket.user.id}`);
  socket.on("call:signal", async data => {
    const targetUsername = String(data && data.to || "").toLowerCase();
    const target = await pool.query("SELECT id FROM users WHERE username=$1", [targetUsername]);
    if (!target.rows[0]) return;
    io.to(`user:${target.rows[0].id}`).emit("call:signal", {
      from: socket.user.username, signal: data.signal, callType: data.callType
    });
  });
  socket.on("call:busy", data => {
    // A minimal signaling starter; the client should display incoming-call controls.
    socket.broadcast.emit("call:busy", { from: socket.user.username, to: data && data.to });
  });
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
initDb().then(() => server.listen(PORT, () => console.log(`Sunny Friends Chat running on ${PORT}`)))
  .catch(e => { console.error("Database startup failed:", e); process.exit(1); });
