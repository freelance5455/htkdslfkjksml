# PlayX demo app

## Run on Android (Acode)
1. Extract `PlayX_Source.zip`.
2. Open the `PlayX` folder in Acode.
3. Open `index.html`.
4. Use Acode Preview or open `index.html` in Chrome.

## Included
- Demo player profile
- Home dashboard
- Solo and squad tournament catalogue
- Search, filters and sorting
- Tournament details and join flow
- Demo points wallet and daily reward
- Transaction activity
- Profile editing and local persistence

## Important
This is a front-end prototype. Data is stored in the current browser using localStorage.
It has no real authentication, server, admin panel, payment, withdrawal, room credentials,
anti-cheat or authoritative tournament results. Do not use it to collect real money or
represent demo points as cash. Add a secure backend and server-side validation before launch.
