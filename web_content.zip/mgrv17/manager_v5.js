const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
let allRows=[],circleMap={},teacherProfiles={},profiles={},attendanceMap={};
let selectedTeacherKey=null;
const PERIODS_KEY='madar_manager_report_periods_v1';
function getPeriods(){try{return JSON.parse(localStorage.getItem(PERIODS_KEY)||'{}')}catch(e){return {}}}
function savePeriods(v){localStorage.setItem(PERIODS_KEY,JSON.stringify(v))}
function cutoffFor(key){const p=getPeriods()[key];return p?.currentCutoff||null}
function isInCurrentPeriod(x,key){const cut=cutoffFor(key);if(!cut)return true;const created=String(x.created_at||'');if(created)return created>=cut;return rowDate(x)>String(cut).slice(0,10)}
function isArchivedFor(x,key){return !isInCurrentPeriod(x,key)}
function closeTeacherPeriod(key){const rows=allRows.filter(x=>teacherKey(x)===key);if(!rows.length){msg('لا توجد تقارير لهذا المحفظ.');return}
  const name=teacherName(rows[0]);
  if(!confirm(`إغلاق تقارير ${name} الحالية وبدء فترة جديدة؟\n\nالتقارير القديمة لن تُحذف، وستبقى في الأرشيف.`))return;
  const periods=getPeriods(); const old=periods[key]||{};
  periods[key]={teacherName:name,currentCutoff:new Date().toISOString(),closedAt:new Date().toISOString(),history:[...(old.history||[]),...(old.currentCutoff?[{cutoff:old.currentCutoff,closedAt:old.closedAt}]:[])]};
  savePeriods(periods); msg('تم إغلاق تقارير '+name+' وبدأت فترة جديدة.',true); render();
  if(selectedTeacherKey===key) openTeacher(key);
}
function archiveRowsFor(key){return allRows.filter(x=>teacherKey(x)===key && isArchivedFor(x,key))}

function msg(t,ok=false){const e=$('msg'); if(e){e.textContent=t;e.className=ok?'ok':'error'} let n=$('toast'); if(!n){n=document.createElement('div');n.id='toast';document.body.appendChild(n)} n.textContent=t;n.className='toast '+(ok?'toast-ok':'toast-error');clearTimeout(window.__toastTimer);window.__toastTimer=setTimeout(()=>n.className='toast hidden',3500)}
function rowDate(x){return String(x.report_date||x.date||x.attendance_date||x.created_at||'').slice(0,10)}
function teacherKey(x){return x.teacher_profile_id||('name:'+String(x.teacher_name||profiles[x.teacher_id]?.full_name||profiles[x.teacher_id]?.name||x.teacher_id||'غير محدد'))}
function teacherName(x){
  if(typeof x==='string') return x;
  return String(x.teacher_name||teacherProfiles[x.teacher_profile_id]?.teacher_name||profiles[x.teacher_id]?.full_name||profiles[x.teacher_id]?.name||profiles[x.teacher_id]?.email||'محفظ غير محدد');
}
function teacherGroups(rows){const g={}; rows.forEach(x=>{const k=teacherKey(x);(g[k]??=[]).push(x)});return g}
function presentCount(x){return attendanceMap[String(x.circle_id)+'|'+rowDate(x)]?.size||0}
function filtered(){const m=$('month').value,q=$('search').value.trim().toLowerCase();return allRows.filter(x=>{const d=rowDate(x),t=teacherName(x).toLowerCase(),c=String(circleMap[x.circle_id]||'').toLowerCase(),key=teacherKey(x);return isInCurrentPeriod(x,key)&&(!m||d.startsWith(m))&&(!q||t.includes(q)||c.includes(q))})}
async function loadReports(){
  $('status').textContent='جاري تحميل التقارير...';
  $('teachersList').innerHTML='<div class="loading">جاري تحميل بيانات المحفظين والتقارير…</div>';
  $('reports').innerHTML='';
  try{
    let r=await sb.from('daily_reports').select('*').order('created_at',{ascending:false});
    if(r.error){$('status').textContent='خطأ في تحميل التقارير: '+r.error.message;$('teachersList').innerHTML='<div class="empty errorbox">تعذر تحميل التقارير من قاعدة البيانات.<br><small>'+esc(r.error.message)+'</small></div>';return}
    allRows=r.data||[]; circleMap={}; teacherProfiles={}; profiles={}; attendanceMap={};
    const cids=[...new Set(allRows.map(x=>x.circle_id).filter(Boolean))];
    const tids=[...new Set(allRows.map(x=>x.teacher_id).filter(Boolean))];
    const tpids=[...new Set(allRows.map(x=>x.teacher_profile_id).filter(Boolean))];
    if(cids.length){const c=await sb.from('circles').select('id,name').in('id',cids);if(!c.error)(c.data||[]).forEach(x=>circleMap[x.id]=x.name)}
    if(tpids.length){const p=await sb.from('teacher_profiles').select('id,teacher_name,teacher_code').in('id',tpids);if(!p.error)(p.data||[]).forEach(x=>teacherProfiles[x.id]=x)}
    if(tids.length){const p=await sb.from('profiles').select('*').in('id',tids);if(!p.error)(p.data||[]).forEach(x=>profiles[x.id]=x)}
    await loadAttendance(cids);
    render();
  }catch(e){$('status').textContent='خطأ غير متوقع';$('teachersList').innerHTML='<div class="empty errorbox">'+esc(e?.message||e)+'</div>'}
}
async function loadAttendance(cids){
  if(!cids.length)return;
  const a=await sb.from('attendance').select('*').in('circle_id',cids);
  if(a.error){$('status').textContent='تم تحميل التقارير، لكن تعذر حساب الحضور: '+a.error.message;return}
  (a.data||[]).forEach(x=>{const d=String(x.attendance_date||x.date||x.created_at||'').slice(0,10),k=String(x.circle_id)+'|'+d;if(!attendanceMap[k])attendanceMap[k]=new Set();if(String(x.status||'present').toLowerCase()!=='absent')attendanceMap[k].add(x.student_id||x.id)})
}
function durationMinutes(value){
  if(value===null||value===undefined||value==='') return 0;
  const str=String(value).trim().replace('٫','.').replace('،','.');
  if(str.includes(':')){
    const parts=str.split(':'); const h=Number(parts[0])||0; const m=Math.max(0,Math.min(59,Number(parts[1])||0)); return h*60+m;
  }
  const n=Number(str); if(!Number.isFinite(n)) return 0;
  // التطبيق يسجل 3.15 بمعنى 3 ساعات و15 دقيقة، وليس 3.15 ساعة عشرية.
  const whole=Math.trunc(n); const frac=Math.round((Math.abs(n)-whole)*100);
  if(frac>=0 && frac<=59 && /\.\d{1,2}$/.test(str)) return whole*60+frac;
  return Math.round(n*60);
}
function formatDuration(value){
  const mins=typeof value==='number' ? value : durationMinutes(value);
  const h=Math.floor(mins/60), m=mins%60;
  if(!h) return `${m} دقيقة`;
  if(!m) return `${h} ساعة`;
  return `${h} ساعة و${m} دقيقة`;
}
function render(){
  const rows=filtered(),groups=teacherGroups(rows);
  const showZero=!$('month').value&&!$('search').value.trim();
  if(showZero){for(const k of Object.keys(teacherGroups(allRows))){if(!(k in groups))groups[k]=[]}}
  $('count').textContent=rows.length;
  $('hours').textContent=formatDuration(rows.reduce((s,x)=>s+durationMinutes(x.hours),0));
  $('teachers').textContent=Object.keys(groups).length;
  $('circles').textContent=new Set(rows.map(x=>x.circle_id).filter(Boolean)).size;
  const dayAttendance={};rows.forEach(x=>{const k=teacherKey(x)+'|'+rowDate(x);dayAttendance[k]=(dayAttendance[k]||0)+presentCount(x)});
  $('students').textContent=Object.values(dayAttendance).reduce((a,b)=>a+b,0);
  $('status').textContent=rows.length?'تم تحميل '+rows.length+' تقرير':'لا توجد تقارير مطابقة';
  const ids=Object.keys(groups);
  $('teachersList').innerHTML=ids.length?ids.map(k=>{
    const rs=groups[k],source=rs[0]||allRows.find(x=>teacherKey(x)===k),hours=rs.reduce((s,x)=>s+durationMinutes(x.hours),0),circles=new Set(rs.map(x=>x.circle_id).filter(Boolean)).size,name=teacherName(source),presence=rs.reduce((s,x)=>s+presentCount(x),0);
    const hasArchive=archiveRowsFor(k).length>0; return `<article class="teacher-card"><div class="teacher-avatar">${esc(name).trim().slice(0,1)||'م'}</div><div class="teacher-main"><div class="teacher-title"><h3>${esc(name)}</h3><span class="pill">${presence} حضور</span></div><div class="teacher-stats"><span><b>${rs.length}</b> تقرير</span><span><b>${formatDuration(hours)}</b></span><span><b>${circles}</b> حلقات</span><span><b>${presence}</b> حضور</span></div><button class="primary full" data-open-teacher="${esc(k)}">فتح ملف المحفظ</button><div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap"><button type="button" class="secondary small" data-close-period="${esc(k)}">🔒 إغلاق التقارير وبدء فترة جديدة</button>${hasArchive?`<button type="button" class="ghost small" data-open-archive="${esc(k)}">📦 الأرشيف</button>`:''}</div></div></article>`
  }).join(''):'<div class="empty">لا توجد تقارير حتى الآن.</div>';
  $('reports').innerHTML=rows.length?rows.slice(0,30).map(reportRowHtml).join('')+(rows.length>30?'<div class="muted center">يتم عرض أحدث 30 تقريرًا هنا. افتح ملف المحفظ لرؤية كل تقاريره.</div>':''):'<div class="empty">لا توجد تقارير مطابقة.</div>';
  bindDynamic();
}
function reportRowHtml(x){return `<div class="report-row"><div class="report-date">${esc(rowDate(x))}</div><div class="report-info"><b>${esc(teacherName(x))}</b><span>📚 ${esc(circleMap[x.circle_id]||'غير محددة')}</span><span>⏱ ${formatDuration(x.hours)}</span><span>👥 ${presentCount(x)} حضور</span>${x.notes?`<span>📝 ${esc(x.notes)}</span>`:''}</div><button type="button" class="danger small delete-report" data-id="${esc(x.id||'')}">حذف</button></div>`}
function bindDynamic(){document.querySelectorAll('[data-open-teacher]').forEach(b=>{b.onclick=()=>openTeacher(b.dataset.openTeacher,false)});document.querySelectorAll('[data-close-period]').forEach(b=>{b.onclick=()=>closeTeacherPeriod(b.dataset.closePeriod)});document.querySelectorAll('[data-open-archive]').forEach(b=>{b.onclick=()=>openTeacher(b.dataset.openArchive,true)});}

function openTeacher(key,archive=false){
  selectedTeacherKey=key;let rows=allRows.filter(x=>teacherKey(x)===key);rows=archive?rows.filter(x=>isArchivedFor(x,key)):rows.filter(x=>isInCurrentPeriod(x,key));if(!rows.length){msg(archive?'لا توجد تقارير في الأرشيف لهذا المحفظ.':'لا توجد تقارير في الفترة الحالية لهذا المحفظ.');return;}
  const allTeacherRows=allRows.filter(x=>teacherKey(x)===key), currentCount=allTeacherRows.filter(x=>isInCurrentPeriod(x,key)).length, archiveCount=allTeacherRows.filter(x=>isArchivedFor(x,key)).length; 
  const name=teacherName(rows[0]),hours=rows.reduce((s,x)=>s+durationMinutes(x.hours),0),circles=new Set(rows.map(x=>x.circle_id).filter(Boolean)).size,days={},totalPresence=rows.reduce((s,x)=>s+presentCount(x),0);
  rows.forEach(x=>(days[rowDate(x)]??=[]).push(x));
  $('detailTitle').textContent=name;$('detailSubtitle').textContent=`${archive?'الأرشيف':'الفترة الحالية'} — ${rows.length} تقرير — ${totalPresence} حضور`;
  const periodTools=`<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"><button type="button" class="secondary small" data-detail-close="${esc(key)}">🔒 إغلاق الفترة الحالية وبدء فترة جديدة</button>${archive?`<button type="button" class="ghost small" data-detail-current="${esc(key)}">📊 العودة للفترة الحالية</button>`:(archiveCount?`<button type="button" class="ghost small" data-detail-archive="${esc(key)}">📦 عرض الأرشيف (${archiveCount})</button>`:'')}</div>`;
  
  $('detailStats').innerHTML=`<div><b>${rows.length}</b><small>التقارير</small></div><div><b>${totalPresence}</b><small>عدد الحضور</small></div><div><b>${formatDuration(hours)}</b><small>الساعات</small></div><div><b>${circles}</b><small>الحلقات</small></div>`;
  $('detailBody').innerHTML=periodTools+Object.keys(days).sort().reverse().map(d=>{const rs=days[d],h=rs.reduce((s,x)=>s+durationMinutes(x.hours),0),p=rs.reduce((s,x)=>s+presentCount(x),0);return `<section class="day-card"><div class="day-head"><div><b>📅 ${esc(d)}</b><span>${rs.length} تقرير حلقة</span></div><div class="day-total"><b>${formatDuration(h)}</b><b>${p} حضور</b></div></div><div class="day-reports">${rs.map(x=>`<div class="detail-report"><div><b>📚 ${esc(circleMap[x.circle_id]||'غير محددة')}</b><small>⏱ ${formatDuration(x.hours)} · 👥 ${presentCount(x)} حضور</small>${x.notes?`<small>📝 ${esc(x.notes)}</small>`:''}</div><button type="button" class="danger small delete-report" data-id="${esc(x.id||'')}">حذف</button></div>`).join('')}</div></section>`}).join('');
  $('detail').classList.remove('hidden');document.body.classList.add('modal-open');bindDetail();
}
function bindDetail(){}
document.addEventListener('click',async e=>{const close=e.target.closest?.('[data-detail-close]');if(close){e.preventDefault();e.stopPropagation();closeTeacherPeriod(close.dataset.detailClose);return}const cur=e.target.closest?.('[data-detail-current]');if(cur){e.preventDefault();e.stopPropagation();openTeacher(cur.dataset.detailCurrent,false);return}const arch=e.target.closest?.('[data-detail-archive]');if(arch){e.preventDefault();e.stopPropagation();openTeacher(arch.dataset.detailArchive,true);return}const b=e.target.closest?.('.delete-report');if(!b)return;e.preventDefault();e.stopPropagation();await deleteReport(b.dataset.id,!!b.closest('#detail'))})
function closeDetail(){ $('detail').classList.add('hidden');document.body.classList.remove('modal-open');selectedTeacherKey=null }
async function deleteReport(id,fromDetail=false){
  if(!id){msg('رقم التقرير غير موجود');return}
  msg('جاري حذف التقرير...');
  const r=await sb.from('daily_reports').delete().eq('id',id);
  if(r.error){msg('تعذر حذف التقرير: '+r.error.message);return}
  
  msg('تم حذف التقرير بنجاح',true);
  await loadReports();
  if(fromDetail&&selectedTeacherKey){
    const key=selectedTeacherKey;
    if(filtered().some(x=>teacherKey(x)===key)) openTeacher(key); else closeDetail();
  }
}
async function clearVisible(){
  const rows=filtered();if(!rows.length){msg('لا توجد تقارير لمسحها.');return}
  
  for(const x of rows){const r=await sb.from('daily_reports').delete().eq('id',x.id);if(r.error){msg('تعذر الحذف: '+r.error.message);return}}
  msg('تم حذف التقارير المحددة.',true);await loadReports()
}
function csv(){const rows=filtered(),head=['التاريخ','المحفظ','الحلقة','الساعات','الحضور','الملاحظات'];const lines=[head,...rows.map(x=>[rowDate(x),teacherName(x),circleMap[x.circle_id]||'',formatDuration(x.hours),presentCount(x),x.notes||''])].map(a=>a.map(v=>'"'+String(v).replaceAll('"','""')+'"').join(','));const blob=new Blob(['\uFEFF'+lines.join('\n')],{type:'text/csv;charset=utf-8'}),u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download='تقارير_المحفظين.csv';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000)}
async function login(){const email=$('email').value.trim(),password=$('password').value;if(!email||!password){msg('اكتب البريد وكلمة السر');return}msg('جاري الدخول...');const r=await sb.auth.signInWithPassword({email,password});if(r.error){msg(r.error.message);return}const u=r.data.user,p=await sb.from('profiles').select('role').eq('id',u.id).maybeSingle();if(p.error||p.data?.role!=='manager'){msg(p.error?'تعذر قراءة صلاحية الحساب: '+p.error.message:'هذا الحساب ليس حساب مدير');await sb.auth.signOut();return}$('login').classList.add('hidden');$('app').classList.remove('hidden');$('user').textContent=u.email||'المدير';await loadReports()}
async function init(){const s=await sb.auth.getSession();if(s.data?.session?.user){const u=s.data.session.user,p=await sb.from('profiles').select('role').eq('id',u.id).maybeSingle();if(!p.error&&p.data?.role==='manager'){$('login').classList.add('hidden');$('app').classList.remove('hidden');$('user').textContent=u.email||'المدير';await loadReports()}}}
$('loginBtn').onclick=login;$('refresh').onclick=loadReports;$('logout').onclick=async()=>{await sb.auth.signOut();location.reload()};$('month').onchange=render;$('search').oninput=render;$('export').onclick=csv;$('clear').onclick=clearVisible;$('closeDetail').onclick=closeDetail;$('detail').addEventListener('click',e=>{if(e.target===$('detail'))closeDetail()});init();
