const sb = supabase.createClient(CFG.url, CFG.key);
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const inr = n => '₹' + Number(n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const dt = s => new Date(s).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
function toast(m, bad) { const t = $('#toast'); t.textContent = m; t.className = 'show' + (bad ? ' bad' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => t.className = '', 3200); }
async function rpc(n, a) { const { data, error } = await sb.rpc(n, a); if (error) { toast(error.message, 1); throw error; } return data; }
async function q(p) { const { data, error } = await p; if (error) { toast(error.message, 1); throw error; } return data; }
const pub = p => p ? sb.storage.from('assets').getPublicUrl(p).data.publicUrl : '';
function sheet(h) { const s = $('#sheet'); s.innerHTML = `<div class="sh"><button class="x" aria-label="Close">×</button>${h}</div>`; s.className = 'open'; s.onclick = e => { if (e.target === s || e.target.className === 'x') s.className = ''; }; }
function cd(iso) { let d = Math.max(0, (new Date(iso) - Date.now()) / 1000 | 0); if (!d) return 'Started'; const D = d / 86400 | 0, H = d % 86400 / 3600 | 0, M = d % 3600 / 60 | 0, S = d % 60; return (D ? D + 'd ' : '') + [H, M, S].map(x => String(x).padStart(2, '0')).join(':'); }
setInterval(() => document.querySelectorAll('[data-cd]').forEach(e => e.textContent = cd(e.dataset.cd)), 1000);
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('sw.js'));
