import { db, auth } from "./firebase.js";
import { APP_CONFIG } from "./config.js";
import {
 collection, addDoc, doc, getDoc, setDoc, updateDoc, onSnapshot,
 query, where, orderBy, limit, serverTimestamp
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-firestore.js";
import {
 createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut
} from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";

export const $ = s => document.querySelector(s);
export const esc = s => String(s ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
export function phoneEmail(phone){ return phone.replace(/\D/g,"")+"@taksi.app"; }
export async function register(phone,password,data){
  const cred=await createUserWithEmailAndPassword(auth,phoneEmail(phone),password);
  await setDoc(doc(db,"users",cred.user.uid),{uid:cred.user.uid,phone,...data,createdAt:serverTimestamp()});
  return cred.user;
}
export async function login(phone,password){ return (await signInWithEmailAndPassword(auth,phoneEmail(phone),password)).user; }
export async function logout(){ await signOut(auth); location.href="index.html"; }
export async function userDoc(){ const u=auth.currentUser; return u? (await getDoc(doc(db,"users",u.uid))).data():null; }
export function money(n){ return new Intl.NumberFormat("uz-UZ").format(Math.round(Number(n)||0))+" so'm"; }
export function price(settings,km,min){
 const p=settings||{start:5000,km:3000,min:500};
 return Math.max(Number(p.minPrice)||0, Number(p.start)||0+km*(Number(p.km)||0)+min*(Number(p.minute)||0));
}
export async function getSettings(){
 const s=await getDoc(doc(db,"settings","pricing"));
 return s.exists()?s.data():{start:5000,km:3000,minute:500,minPrice:7000,commission:15};
}
export async function createOrder(data){ return (await addDoc(collection(db,"orders"),{...data,status:"searching",createdAt:serverTimestamp()})).id; }
export function watchOrder(id,cb){ return onSnapshot(doc(db,"orders",id),s=>s.exists()&&cb({id:s.id,...s.data()})); }
export async function updateOrder(id,data){ return updateDoc(doc(db,"orders",id),data); }
export { db, auth, APP_CONFIG, collection, doc, getDoc, setDoc, updateDoc, onSnapshot, query, where, orderBy, limit, serverTimestamp };
