ZABOTKER V8 - GTA V CAM (Starter Prototype)

HOW TO OPEN
1. Extract this ZIP file.
2. Open index.html in Chrome or another modern browser.
3. Tap the 01-50 camera buttons or use the action tiles.

WHAT'S INCLUDED
- Responsive game-themed interface
- 50 selectable camera buttons
- Phone, vehicle shop, fictional loadout, enter-vehicle, police alert and map demo tiles
- Keyboard/touch-friendly buttons

IMPORTANT
This is a browser UI prototype, not a full 3D GTA-style game. It does not include 3D character movement, a real vehicle system, weapons, multiplayer, or a Nigeria-wide map. A full 3D game would need to be built in an engine such as Godot or Unity, with original assets. This project is not affiliated with Rockstar Games or GTA V.
