const grid = document.getElementById('cameraGrid');
const label = document.getElementById('camLabel');
const notice = document.getElementById('notice');
let current = 1;
for (let i = 1; i <= 50; i++) {
  const button = document.createElement('button');
  button.className = 'camera-btn' + (i === 1 ? ' active' : '');
  button.textContent = String(i).padStart(2, '0');
  button.setAttribute('aria-label', `Camera ${i}`);
  button.addEventListener('click', () => setCamera(i));
  grid.appendChild(button);
}
function setCamera(number) {
  current = Math.max(1, Math.min(50, number));
  label.textContent = String(current).padStart(2, '0');
  document.querySelectorAll('.camera-btn').forEach((b, index) => b.classList.toggle('active', index + 1 === current));
  notice.textContent = `Camera ${String(current).padStart(2, '0')} selected. This starter demo previews the camera selector; 3D gameplay is not included yet.`;
}
document.getElementById('prevCam').addEventListener('click', () => setCamera(current === 1 ? 50 : current - 1));
document.getElementById('nextCam').addEventListener('click', () => setCamera(current === 50 ? 1 : current + 1));
document.querySelectorAll('.action').forEach(button => {
  button.addEventListener('click', () => {
    const action = button.dataset.action;
    const messages = {
      'WAYA': 'Phone menu opened (demo).',
      'MOTA': 'Vehicle shop selected (demo). Add vehicle models and shop logic in the next build.',
      'HARBI': 'Fictional game loadout selected (demo). No real-world weapon instructions are included.',
      'SHIGA': 'Vehicle entry selected (demo). Add a drivable vehicle system in a 3D engine.',
      'YAN SANDA': 'Police alert selected (demo). This is a fictional game event.',
      'MAP': 'Map selected (demo). The full Nigeria-wide map is not included in this starter build.'
    };
    notice.textContent = messages[action] || `${action} selected.`;
  });
});