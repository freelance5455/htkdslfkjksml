package mk.fiore.guestbook

import android.Manifest
import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import java.io.OutputStream
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private var pendingWebPermission: PermissionRequest? = null
    private var pageLoaded = false
    private var exportUri: Uri? = null
    private var exportStream: OutputStream? = null
    private val permissionCode = 441

    private val requiredPermissions: Array<String>
        get() = if (Build.VERSION.SDK_INT >= 23) arrayOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO
        ) else emptyArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersiveMode()
        createWebView()
        if (hasRuntimePermissions()) {
            loadAppPage()
        } else {
            requestRuntimePermissions()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createWebView() {
        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        // Only allow the local FIORE page to request camera and microphone.
                        val origin = request.origin
                        val isFioreOrigin = origin.scheme == "https" &&
                            origin.host == "appassets.androidplatform.net"
                        val requested = request.resources.toSet()
                        val allowed = setOf(
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE,
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE
                        )
                        val resources = request.resources.filter { it in allowed }.toTypedArray()

                        if (!isFioreOrigin || resources.isEmpty() || requested.any { it !in allowed }) {
                            request.deny()
                            return@runOnUiThread
                        }
                        if (hasRuntimePermissions()) {
                            request.grant(resources)
                        } else {
                            pendingWebPermission?.deny()
                            pendingWebPermission = request
                            requestRuntimePermissions()
                        }
                    }
                }

                override fun onPermissionRequestCanceled(request: PermissionRequest) {
                    if (pendingWebPermission == request) pendingWebPermission = null
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                    return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    // Keep the guestbook offline and inside this app.
                    return request.url.host != "appassets.androidplatform.net"
                }
            }
            addJavascriptInterface(FioreBridge(), "FioreAndroid")
        }
        setContentView(webView)
    }

    private fun loadAppPage() {
        if (pageLoaded) return
        pageLoaded = true
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun hasRuntimePermissions(): Boolean = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT < 23) {
            loadAppPage()
            return
        }
        val denied = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }.toTypedArray()
        if (denied.isEmpty()) {
            onPermissionsReady()
            return
        }
        ActivityCompat.requestPermissions(this, denied, permissionCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != permissionCode) return
        if (hasRuntimePermissions()) {
            onPermissionsReady()
        } else {
            pendingWebPermission?.deny()
            pendingWebPermission = null
            loadAppPage()
            showPermissionRationale()
        }
    }

    private fun onPermissionsReady() {
        loadAppPage()
        pendingWebPermission?.let { request ->
            val resources = request.resources.filter {
                it == PermissionRequest.RESOURCE_VIDEO_CAPTURE ||
                    it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
            }.toTypedArray()
            if (resources.isNotEmpty()) request.grant(resources) else request.deny()
            pendingWebPermission = null
        }
    }

    private fun showPermissionRationale() {
        AlertDialog.Builder(this)
            .setTitle("Потребни се дозволи")
            .setMessage("FIORE GUESTBOOK има потреба од дозвола за камера и микрофон за да снима видео-пораки. Притисни „Обиди се повторно“ или отвори Android Settings и дозволи Camera и Microphone.")
            .setPositiveButton("ОБИДИ СЕ ПОВТОРНО") { _, _ -> requestRuntimePermissions() }
            .setNegativeButton("ОТВОРИ ПОСТАВКИ") { _, _ -> openAppSettings() }
            .setNeutralButton("ПОДОЦНА", null)
            .show()
    }

    private fun openAppSettings() {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
        }
        startActivity(intent)
    }

    private fun enterImmersiveMode() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    inner class FioreBridge {
        @JavascriptInterface
        fun openAppSettings() {
            runOnUiThread { this@MainActivity.openAppSettings() }
        }

        @JavascriptInterface
        fun toggleFullscreen() {
            runOnUiThread { enterImmersiveMode() }
        }

        @JavascriptInterface
        @Synchronized
        fun beginVideoExport(filename: String, mimeType: String): Boolean {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return false
            return try {
                abortVideoExport()
                val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "Fiore-video.webm" }
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType.ifBlank { "video/webm" })
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Fiore Guestbook")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                exportUri = uri
                exportStream = contentResolver.openOutputStream(uri, "w") ?: run {
                    contentResolver.delete(uri, null, null)
                    exportUri = null
                    return false
                }
                true
            } catch (_: Exception) {
                abortVideoExport()
                false
            }
        }

        @JavascriptInterface
        @Synchronized
        fun appendVideoChunk(base64Chunk: String): Boolean {
            return try {
                val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
                exportStream?.write(bytes) ?: return false
                true
            } catch (_: Exception) {
                false
            }
        }

        @JavascriptInterface
        @Synchronized
        fun finishVideoExport(): Boolean {
            return try {
                exportStream?.flush()
                exportStream?.close()
                exportStream = null
                val uri = exportUri ?: return false
                val values = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                contentResolver.update(uri, values, null, null)
                exportUri = null
                true
            } catch (_: Exception) {
                abortVideoExport()
                false
            }
        }

        @JavascriptInterface
        @Synchronized
        fun abortVideoExport() {
            try { exportStream?.close() } catch (_: Exception) { }
            exportStream = null
            exportUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) { } }
            exportUri = null
        }
    }

    @Deprecated("Deprecated in Android API; retained for older tablet back behavior")
    override fun onBackPressed() {
        // Guest navigation is controlled by the FIORE GUESTBOOK screens.
        // An administrator can close the admin panel using its own Close button.
    }

    override fun onResume() {
        super.onResume()
        enterImmersiveMode()
        if (::webView.isInitialized && hasRuntimePermissions()) {
            pendingWebPermission?.let { req ->
                val resources = req.resources.filter {
                    it == PermissionRequest.RESOURCE_VIDEO_CAPTURE || it == PermissionRequest.RESOURCE_AUDIO_CAPTURE
                }.toTypedArray()
                if (resources.isNotEmpty()) req.grant(resources)
                pendingWebPermission = null
            }
        }
    }
}
