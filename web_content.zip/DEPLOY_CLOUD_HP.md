# MasterFlow Trading — Cloud Deploy (HP-friendly)

Target: Render Free for testing. No Termux required.

## Architecture
HP/APK -> MasterFlow backend (Render) -> Twelve Data

The Twelve Data API key is stored as a Render environment secret, not in the APK/frontend.

## Deploy backend
1. Create a GitHub repository and upload this project.
2. On Render, choose New -> Web Service and connect the GitHub repo.
3. If using the included render.yaml, use the Blueprint flow. Otherwise set:
   - Root Directory: backend
   - Build Command: pip install -r requirements.txt
   - Start Command: uvicorn main:app --host 0.0.0.0 --port $PORT
   - Health Check: /health
4. Add secret environment variable:
   TWELVEDATA_API_KEY = your Twelve Data key
5. Deploy.
6. Test: https://YOUR-SERVICE.onrender.com/health
7. Test provider: https://YOUR-SERVICE.onrender.com/provider-status

## Important
- Never commit .env or paste the key into GitHub.
- Render Free web services can spin down after 15 minutes idle and take about a minute to wake.
- Free hosting is for testing/hobby use; do not treat it as production trading infrastructure.
- MasterFlow remains analysis-only; auto-trading is disabled.
