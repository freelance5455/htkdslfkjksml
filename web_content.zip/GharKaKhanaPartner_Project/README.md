# Ghar Ka Khana Partner — Project Starter

This is a mobile-first web app starter with an original Ghar Ka Khana interface and Firebase Phone Authentication integration points. It removes third-party restaurant-platform branding.

## What is included
- Mobile number entry and Firebase SMS OTP request/verification flow
- Resend OTP button
- Restaurant name and four-step onboarding flow
- Restaurant information form
- FSSAI number and document selection UI
- Menu editor seeded with the menu items/prices discussed earlier
- Partner agreement acceptance UI (fee must be configured by the owner)
- Partner dashboard with Orders, Menu, Complaints, Reviews, Reports, Growth, Payouts, and Help Center
- Top-right three-line menu

## Important: real SMS OTP setup is not automatic
Real OTP delivery requires your own Firebase project, allowed domains, Phone Authentication enabled, and any required billing/anti-abuse configuration. Do not publish until tested on your actual domain and devices.

### Firebase setup
1. Open https://console.firebase.google.com/ and create a project owned by you.
2. Add a **Web app** in Project settings and copy its web configuration.
3. In Authentication > Sign-in method, enable **Phone**.
4. In Authentication settings, add the real hosting domain to Authorized domains.
5. Open `firebase-config.js` and replace all `YOUR_...` placeholders with the Firebase web app values.
6. Use Firebase Hosting or another HTTPS host. Phone auth may not work when opening the file directly as `content://` or `file://`.
7. Review Firebase phone-authentication limits, country settings, billing requirements, privacy policy, and consent requirements.
8. Test sending and verifying OTP on your own number before inviting partners.

The app intentionally does **not** generate or display a fake OTP. Until Firebase is configured, it explains that real SMS setup is required.

## Run locally
Because this uses browser ES modules, serve it from a local web server rather than opening `index.html` directly. For example, with Python installed:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000` in your browser. For real OTP, configure the domain in Firebase; use Firebase Hosting/HTTPS for a production test.

## Production work still required
This is a frontend project starter, not a deployed production service. Before public launch, add:
- Secure database and server-side authorization rules
- Persistent restaurant/menu data storage
- Secure document uploads and admin verification workflow
- A reviewed partner contract and actual fee schedule
- Real order, customer complaint, ratings, sales-report, payout, and support integrations
- Privacy policy, terms, deletion process, monitoring, abuse protection, and backups
- Admin approval before switching an outlet to live

Do not store customer/partner documents or financial data in browser-only state. This project does not charge a fee or connect to payment rails.


## If Continue / Verify does not respond on Android
- The buttons now show a clear message even if Firebase's module cannot load.
- Do not open `index.html` directly from Downloads (`content://`). Serve/deploy the app on an HTTPS domain.
- Replace the Firebase placeholders, enable Phone Authentication, and add the hosting domain to Authorized domains.
- The fallback message is not an OTP and does not pretend that an SMS was sent; real SMS verification works only after the Firebase setup is complete.
