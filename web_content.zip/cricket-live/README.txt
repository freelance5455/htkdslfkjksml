STUMPS - Live Cricket App

1. Open index.html in any browser (phone or computer). It works at once with DEMO data.
2. For REAL live data: get a free key at https://cricketdata.org (CricAPI),
   then tap "Demo data - tap to add key" at the top of the app and paste it.
3. Host it free on GitHub Pages / Netlify to use it on your phone as a link.

Notes
- Live scores refresh every 60 seconds (free plan = 100 calls/day, so this can run out).
- "Ball Start" + run animation: in demo it simulates balls. With a real key it plays when a refresh sees the score change (a true per-ball feed needs a paid ball-by-ball API).
- Scorecard, toss and ball-by-ball depend on your API plan. Free plans may not include ball-by-ball.
- Rankings are sample data. Replace DEMO.rank with data from a rankings provider.
- Some APIs block direct browser calls. If so, host a tiny proxy that adds the key on the server.
