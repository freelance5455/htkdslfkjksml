package com.reino.ceniza;

import android.Manifest;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebView;
import androidx.core.content.ContextCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            WebView w = getBridge().getWebView();
            w.getSettings().setMediaPlaybackRequiresUserGesture(false);
        } catch (Exception e) {}
        if (Build.VERSION.SDK_INT >= 33) {
            try { requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1); } catch (Exception e) {}
        }
        try { ContextCompat.startForegroundService(this, new Intent(this, KeepAliveService.class)); } catch (Exception e) {}
    }

    // Al pasar a segundo plano, el WebView sigue "vivo" para que la radio no se frene.
    @Override
    public void onPause() {
        super.onPause();
        try {
            WebView w = getBridge().getWebView();
            w.onResume();
            w.resumeTimers();
        } catch (Exception e) {}
    }

    @Override
    public void onDestroy() {
        try { stopService(new Intent(this, KeepAliveService.class)); } catch (Exception e) {}
        super.onDestroy();
    }
}
