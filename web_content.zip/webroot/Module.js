import { exec } from 'https://esm.sh/kernelsu';

const CONGFIG_PATH = "/data/adb/.Magic/Trigger/kernel_config.txt";
const BOOT_CONFIG_PATH = "/data/adb/.Magic/Trigger/boot_config.txt";
const TRIGGERCTL_BIN = "/data/adb/modules/Trigger/triggerctl";
const CUSTOM_MODULE_DIR = "/data/adb/.Magic/Trigger/custom_modules";
const ORIGINAL_MODEL_FILE = "/data/adb/.Magic/Trigger/original_model.txt";

// Base64 编解码
const encode = str => btoa(String.fromCharCode(...new TextEncoder().encode(str)));
const decode = base64 => {
    try {
        const binary = atob(base64.trim());
        return new TextDecoder().decode(new Uint8Array([...binary].map(c => c.charCodeAt(0))));
    } catch { return null; }
};

const shellQuote = value => `'${String(value).replace(/'/g, `'\\''`)}'`;

// 自定义提示通知
function getToastContainer() {
    if (!document.getElementById('toast-container')) {
        const container = document.createElement('div');
        container.id = 'toast-container';
        container.className = 'toast-container';
        document.body.appendChild(container);
    }
    return document.getElementById('toast-container');
}

function normalizeToastOptions(options) {
    if (typeof options === 'boolean') {
        return { type: options ? 'error' : 'success', duration: 1300 };
    }
    return {
        type: 'success',
        duration: 1300,
        actions: [],
        ...(options || {})
    };
}

export function showToast(message, options = {}) {
    const settings = normalizeToastOptions(options);
    const container = getToastContainer();
    const toast = document.createElement('div');
    toast.className = `toast ${settings.type || 'success'}${settings.actions?.length ? ' has-actions' : ''}`;

    const text = document.createElement('div');
    text.className = 'toast-message';
    text.textContent = message;
    toast.appendChild(text);

    if (settings.actions?.length) {
        const actions = document.createElement('div');
        actions.className = 'toast-actions';
        settings.actions.forEach(action => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = `toast-action ${action.variant || ''}`.trim();
            button.textContent = action.text;
            button.onclick = async () => {
                if (action.close !== false) toast.remove();
                if (action.onClick) await action.onClick();
            };
            actions.appendChild(button);
        });
        toast.appendChild(actions);
    }

    container.appendChild(toast);

    if (settings.duration > 0) {
        setTimeout(() => {
            toast.classList.add('toast-hide');
            setTimeout(() => toast.remove(), 260);
        }, settings.duration);
    }

    return toast;
}

function showConfirm(message, options = {}) {
    return new Promise(resolve => {
        const overlay = document.createElement('div');
        overlay.className = 'confirm-overlay';

        const card = document.createElement('div');
        card.className = 'confirm-card';

        const title = document.createElement('div');
        title.className = 'confirm-title';
        title.textContent = options.title || '提示';

        const body = document.createElement('div');
        body.className = 'confirm-message';
        body.textContent = message;

        const actions = document.createElement('div');
        actions.className = 'confirm-actions';

        const cancel = document.createElement('button');
        cancel.type = 'button';
        cancel.className = 'confirm-button';
        cancel.textContent = options.cancelText || '取消';

        const confirm = document.createElement('button');
        confirm.type = 'button';
        confirm.className = `confirm-button primary${options.danger ? ' danger' : ''}`;
        confirm.textContent = options.confirmText || '确定';

        const close = result => {
            overlay.remove();
            resolve(result);
        };

        cancel.onclick = () => close(false);
        confirm.onclick = () => close(true);
        overlay.onclick = event => {
            if (event.target === overlay) close(false);
        };

        actions.appendChild(cancel);
        actions.appendChild(confirm);
        card.appendChild(title);
        card.appendChild(body);
        card.appendChild(actions);
        overlay.appendChild(card);
        document.body.appendChild(overlay);
    });
}

async function rebootNow() {
    showToast('正在重启设备...', { type: 'info' });
    await exec('reboot');
}

function showRebootToast(message) {
    showToast(message, {
        type: 'success',
        duration: 0,
        actions: [
            { text: '立即重启', variant: 'primary', onClick: rebootNow },
            { text: '取消' }
        ]
    });
}

let scannedPackages = [];
let scannedScripts = [];
let currentPickerType = null;
let currentTargetInput = null;
let currentDirPath = '/data/adb';
let modalItems = [];
let modalSearchTimer = null;

let configHeaderComments = [];
let configFooterComments = [];
let bootHeaderComments = [];
let bootFooterComments = [];

const MAX_MODAL_RENDER_ITEMS = 250;
const ROW_NAME_STORAGE_KEYS = {
    config: 'trigger.visualConfig.rowNames',
    boot: 'trigger.visualBootConfig.rowNames'
};
const COLLAPSE_STORAGE_KEYS = {
    config: 'trigger.visualConfig.collapsed',
    boot: 'trigger.visualBootConfig.collapsed'
};

const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
}[char]));

function rowPageKey(page) {
    return page === 'config' ? 'config' : 'boot';
}

function getDefaultRowTitle(page, index) {
    return page === 'config' ? `自启配置项 #${index + 1}` : `开机配置项 #${index + 1}`;
}

function getRowNameStore(page) {
    try {
        return JSON.parse(localStorage.getItem(ROW_NAME_STORAGE_KEYS[rowPageKey(page)]) || '{}');
    } catch {
        return {};
    }
}

function setRowNameStore(page, store) {
    try {
        localStorage.setItem(ROW_NAME_STORAGE_KEYS[rowPageKey(page)], JSON.stringify(store));
    } catch {}
}

function getCollapseStore(page) {
    try {
        return JSON.parse(localStorage.getItem(COLLAPSE_STORAGE_KEYS[rowPageKey(page)]) || '{}');
    } catch {
        return {};
    }
}

function setCollapseStore(page, store) {
    try {
        localStorage.setItem(COLLAPSE_STORAGE_KEYS[rowPageKey(page)], JSON.stringify(store));
    } catch {}
}

// ------------------------------------------------------------
// 步骤解析（新语法：+N 前缀/后缀 sleep，! 标记 echo）
// ------------------------------------------------------------
function parseNumberAt(s, start) {
    let i = start;
    let dots = 0;
    while (i < s.length) {
        const c = s[i];
        if (c === '.') {
            if (++dots > 1) break;
            i++;
        } else if (c >= '0' && c <= '9') {
            i++;
        } else {
            break;
        }
    }
    if (i === start) return null;
    const numStr = s.slice(start, i);
    const v = Number(numStr);
    if (Number.isNaN(v) || v <= 0) return null;
    return { value: v, end: i };
}

function parseOneSegment(seg) {
    const result = { value: seg, preSleep: '', postSleep: '' };
    let rest = seg;
    let preSleep = '';

    if (rest.startsWith('+')) {
        const r = parseNumberAt(rest, 1);
        if (r) {
            preSleep = rest.slice(1, r.end);
            rest = rest.slice(r.end);
        }
    }

    if (rest.startsWith('!')) {
        result.preSleep = preSleep;
        rest = rest.slice(1);

        const plusPos = rest.lastIndexOf('+');
        if (plusPos > 0) {
            const r = parseNumberAt(rest, plusPos + 1);
            if (r && r.end === rest.length) {
                result.postSleep = rest.slice(plusPos + 1);
                rest = rest.slice(0, plusPos);
            }
        }

        result.value = rest;
    } else {
        // 没有 !，整段作为值
        result.value = seg;
        result.preSleep = '';
        result.postSleep = '';
    }

    return result;
}

function parseInputToSteps(input) {
    if (input === undefined || input === null || input === '') return [];
    return String(input).split('/').map(parseOneSegment);
}

function formatStepSegment(step) {
    const preRaw = (step?.preSleep ?? '').toString().trim();
    const postRaw = (step?.postSleep ?? '').toString().trim();
    const preNum = Number(preRaw);
    const postNum = Number(postRaw);
    const hasPre = preRaw !== '' && !Number.isNaN(preNum) && preNum > 0;
    const hasPost = postRaw !== '' && !Number.isNaN(postNum) && postNum > 0;

    const value = step?.value ?? '';
    const isEmpty = (value === '' && !hasPre && !hasPost);

    if (isEmpty) return '';

    let out = '';
    if (hasPre) out += `+${preRaw}`;
    out += `!${value}`;
    if (hasPost) out += `+${postRaw}`;
    return out;
}

function formatStepsToInput(steps) {
    if (!Array.isArray(steps) || steps.length === 0) return '';
    return steps.map(formatStepSegment).join('/');
}

// ------------------------------------------------------------
// 脚本链
// ------------------------------------------------------------
function parseScriptChain(chainStr) {
    if (!chainStr) return [];
    return chainStr.split('|').map(seg => {
        const eqPos = seg.indexOf('=');
        let script, input;
        if (eqPos < 0) {
            script = seg.trim();
            input = '';
        } else {
            script = seg.slice(0, eqPos).trim();
            input = seg.slice(eqPos + 1);
        }
        if (!script) return null;
        return { script, steps: parseInputToSteps(input) };
    }).filter(Boolean);
}

function formatScriptChain(scripts) {
    if (!Array.isArray(scripts) || scripts.length === 0) return '';
    return scripts.map(s => {
        const input = formatStepsToInput(s.steps || []);
        return `${s.script || ''}=${input}`;
    }).join('|');
}

// ------------------------------------------------------------
// key
// ------------------------------------------------------------
function getCollapseKey(page, row) {
    if (page === 'config') return row.pkg ? 'c:' + row.pkg : '';
    return row.scripts && row.scripts[0] && row.scripts[0].script
        ? 'b:' + row.scripts[0].script
        : '';
}

function getRowKey(page, row) {
    const keyPage = rowPageKey(page);
    const chain = formatScriptChain(row.scripts || []);
    if (keyPage === 'config') {
        return `${keyPage}|${row.pkg || ''}|${chain}`;
    }
    return `${keyPage}|${chain}`;
}

function hasRowIdentity(page, row) {
    const keyPage = rowPageKey(page);
    const chain = formatScriptChain(row.scripts || []);
    return keyPage === 'config'
        ? !!(row.pkg || chain)
        : !!chain;
}

function applyStoredRowNames(page, rows) {
    const store = getRowNameStore(page);
    const collapse = getCollapseStore(page);
    return rows.map(row => {
        const key = getCollapseKey(page, row);
        return {
            ...row,
            name: row.name || store[getRowKey(page, row)] || '',
            collapsed: key ? collapse[key] === true : false
        };
    });
}

function persistRowNames(page, rows) {
    const store = getRowNameStore(page);
    rows.forEach(row => {
        if (!hasRowIdentity(page, row)) return;
        const key = getRowKey(page, row);
        const name = (row.name || '').trim();
        if (name) store[key] = name;
        else delete store[key];
    });
    setRowNameStore(page, store);
}

// ------------------------------------------------------------
// 配置行解析
// ------------------------------------------------------------
function parseConfigRowLine(page, line) {
    const trimmed = line.trim();
    if (!trimmed) return null;

    const isDisabled = trimmed.startsWith('#');
    const content = isDisabled ? trimmed.slice(1).trim() : trimmed;
    if (!content) return null;

    if (page === 'config') {
        const eqPos = content.indexOf('=');
        if (eqPos < 0) return null;
        const pkg = content.slice(0, eqPos).trim();
        const chainStr = content.slice(eqPos + 1);
        if (!pkg) return null;
        const scripts = parseScriptChain(chainStr);
        if (scripts.length === 0) return null;
        if (isDisabled && !scripts.every(s => s.script.startsWith('/'))) return null;
        return { pkg, scripts, enabled: !isDisabled, name: '', collapsed: false };
    }

    const scripts = parseScriptChain(content);
    if (scripts.length === 0) return null;
    if (isDisabled && !scripts.every(s => s.script.startsWith('/'))) return null;
    return { scripts, enabled: !isDisabled, name: '', collapsed: false };
}

function formatConfigRowLine(page, row) {
    let line;
    if (page === 'config') {
        const chain = formatScriptChain(row.scripts || []);
        line = `${row.pkg || ''}=${chain}`;
    } else {
        line = formatScriptChain(row.scripts || []);
    }
    return row.enabled === false ? `# ${line}` : line;
}

// ------------------------------------------------------------
// 扫描
// ------------------------------------------------------------
export async function scanPackages() {
    try {
        const { stdout } = await exec(`pm list packages 2>/dev/null | cut -d: -f2 || pm list packages 2>/dev/null | sed 's/^package://'`);
        scannedPackages = stdout?.trim().split('\n').map(p => p.trim()).filter(Boolean).sort() || [];
    } catch {
        scannedPackages = [];
    }
}

export async function scanScripts() {
    try {
        const { stdout } = await exec(`find /data/adb/.Magic/Trigger /data/adb/modules/Trigger -type f 2>/dev/null || true`);
        const files = stdout?.trim().split('\n').filter(f => f.trim()) || [];
        scannedScripts = files.filter(f => {
            const name = f.split('/').pop();
            return !['post-fs-data.sh', 'service.sh', 'customize.sh'].includes(name);
        });
    } catch {
        scannedScripts = [];
    }
}

export async function listDirContents(path) {
    try {
        if (!path) path = '/';
        const cleanPath = path.replace(/\/+/g, '/');
        const { stdout } = await exec(`ls -1Ap ${shellQuote(cleanPath)} 2>/dev/null || true`);
        const lines = stdout?.trim().split('\n').filter(Boolean) || [];
        const items = [];

        if (cleanPath !== '/' && cleanPath !== '') {
            const parts = cleanPath.split('/').filter(Boolean);
            parts.pop();
            const parent = '/' + parts.join('/');
            items.push({ name: '.. (返回上级目录)', isDir: true, path: parent.replace(/\/+/g, '/') });
        }

        lines.forEach(line => {
            const trimmed = line.trim();
            if (!trimmed) return;
            const isDir = trimmed.endsWith('/');
            const name = isDir ? trimmed.slice(0, -1) : trimmed;

            items.push({
                name,
                isDir,
                path: (cleanPath + '/' + name).replace(/\/+/g, '/')
            });
        });
        return items;
    } catch {
        return [];
    }
}

window.openPkgPicker = async (btn) => {
    const group = btn.closest('.config-input-group');
    const input = group ? group.querySelector('.row-pkg') : null;
    if (!input) return;
    currentTargetInput = input;
    currentPickerType = 'package';

    showToast('正在获取应用包名...', { type: 'info' });
    await scanPackages();

    modalItems = scannedPackages.map(pkg => ({ name: pkg, isDir: false, value: pkg }));

    openPickerModal('选择运行应用包名', modalItems, (selectedVal) => {
        input.value = selectedVal;
        closePickerModal();
    });
};

window.openFilePicker = async (btn) => {
    const item = btn.closest('.script-item');
    const input = item ? item.querySelector('.script-path') : null;
    if (!input) return;
    currentTargetInput = input;
    currentPickerType = 'file';

    let initPath = input.value.trim();
    if (initPath) {
        initPath = initPath.substring(0, initPath.lastIndexOf('/'));
    }
    if (!initPath) {
        initPath = '/data/adb';
    }
    currentDirPath = initPath;

    await loadDirectoryInModal(currentDirPath, input);
};

async function loadDirectoryInModal(dirPath, targetInput) {
    showToast('正在读取目录...', { type: 'info' });
    const items = await listDirContents(dirPath);
    modalItems = items;

    const footerEl = document.getElementById('modal-footer-info');
    footerEl.style.display = 'block';
    footerEl.textContent = `当前目录: ${dirPath}`;

    openPickerModal('选择脚本/文件', modalItems, async (selectedVal, isDir) => {
        if (isDir) {
            currentDirPath = selectedVal;
            await loadDirectoryInModal(currentDirPath, targetInput);
        } else {
            targetInput.value = selectedVal;
            closePickerModal();
        }
    });
}

function openPickerModal(title, items, onSelectCallback) {
    const modal = document.getElementById('picker-modal');
    const titleEl = document.getElementById('modal-title');
    const searchInput = document.getElementById('modal-search-input');

    titleEl.textContent = title;
    searchInput.value = '';

    if (modalSearchTimer) {
        clearTimeout(modalSearchTimer);
        modalSearchTimer = null;
    }

    renderModalList(items, onSelectCallback);

    searchInput.oninput = (e) => {
        const query = e.target.value.trim().toLowerCase();
        if (modalSearchTimer) clearTimeout(modalSearchTimer);
        modalSearchTimer = setTimeout(() => {
            const filtered = query
                ? items.filter(item => String(item.name).toLowerCase().includes(query))
                : items;
            renderModalList(filtered, onSelectCallback);
        }, 80);
    };

    modal.style.display = 'flex';
}

function renderModalList(items, onSelectCallback) {
    const listEl = document.getElementById('modal-content-list');
    listEl.replaceChildren();

    if (items.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'empty-tip modal-empty-tip';
        empty.textContent = '没有找到匹配的项';
        listEl.appendChild(empty);
        return;
    }

    const fragment = document.createDocumentFragment();
    const visibleItems = items.slice(0, MAX_MODAL_RENDER_ITEMS);

    visibleItems.forEach(item => {
        const row = document.createElement('div');
        row.className = 'modal-item-row';

        const icon = document.createElement('span');
        icon.className = 'modal-item-icon';
        icon.textContent = item.isDir ? '📁' : (currentPickerType === 'package' ? '📱' : '📄');

        const text = document.createElement('span');
        text.className = 'modal-item-text';
        text.textContent = item.name;

        row.appendChild(icon);
        row.appendChild(text);
        row.onclick = () => {
            const val = item.isDir ? item.path : (item.value || item.path);
            onSelectCallback(val, item.isDir);
        };
        fragment.appendChild(row);
    });

    if (items.length > visibleItems.length) {
        const tip = document.createElement('div');
        tip.className = 'modal-result-tip';
        tip.textContent = `仅显示前 ${MAX_MODAL_RENDER_ITEMS} 项，请继续输入关键字缩小范围`;
        fragment.appendChild(tip);
    }

    listEl.appendChild(fragment);
}

window.closePickerModal = () => {
    const modal = document.getElementById('picker-modal');
    const searchInput = document.getElementById('modal-search-input');
    if (modalSearchTimer) {
        clearTimeout(modalSearchTimer);
        modalSearchTimer = null;
    }
    searchInput?.blur();
    modal.style.display = 'none';
    const footerEl = document.getElementById('modal-footer-info');
    footerEl.style.display = 'none';
};

// ------------------------------------------------------------
// UI 收集 / 渲染
// ------------------------------------------------------------
function collectStepsFromScriptItem(item) {
    const steps = [];
    item.querySelectorAll('.step-item').forEach(si => {
        const preEl = si.querySelector('.step-pre');
        const valEl = si.querySelector('.step-value');
        const postEl = si.querySelector('.step-post');
        steps.push({
            value: valEl ? valEl.value : '',
            preSleep: preEl ? preEl.value.trim() : '',
            postSleep: postEl ? postEl.value.trim() : ''
        });
    });
    return steps;
}

function collectScriptsFromCard(card) {
    const scripts = [];
    card.querySelectorAll('.script-item').forEach(item => {
        const pathEl = item.querySelector('.script-path');
        scripts.push({
            script: pathEl ? pathEl.value.trim() : '',
            steps: collectStepsFromScriptItem(item)
        });
    });
    return scripts;
}

function getRowsFromUI(page) {
    const normalizedPage = rowPageKey(page);
    const listId = normalizedPage === 'config' ? 'autostart-list' : 'boot-list';
    const container = document.getElementById(listId);
    if (!container) return [];

    const rowCards = container.querySelectorAll('.config-row-card');
    const rows = [];
    rowCards.forEach(card => {
        const nameInput = card.querySelector('.row-name');
        const pkgInput = card.querySelector('.row-pkg');

        const name = nameInput ? nameInput.value.trim() : '';
        const pkg = pkgInput ? pkgInput.value.trim() : '';
        const enabled = card.dataset.enabled !== 'false';
        const collapsed = card.dataset.collapsed === 'true';
        const scripts = collectScriptsFromCard(card);

        if (normalizedPage === 'config') {
            rows.push({ pkg, scripts, enabled, name, collapsed });
        } else {
            rows.push({ scripts, enabled, name, collapsed });
        }
    });
    return rows;
}

function renderStepsHtml(steps) {
    const list = Array.isArray(steps) && steps.length ? steps : [{ value: '', preSleep: '', postSleep: '' }];
    return list.map(step => `
        <div class="step-item">
            <input type="text" class="step-pre" placeholder="前s" value="${escapeHtml(step.preSleep || '')}">
            <input type="text" class="step-value" placeholder="值" value="${escapeHtml(step.value || '')}">
            <input type="text" class="step-post" placeholder="后s" value="${escapeHtml(step.postSleep || '')}">
            <button type="button" class="step-remove" onclick="removeStepRow(this)" title="删除步骤">✕</button>
        </div>
    `).join('');
}

function renderScriptItemHtml(script, scriptIndex) {
    return `
        <div class="script-item">
            <div class="script-item-header">
                <span class="script-order-badge">${scriptIndex + 1}</span>
                <input type="text" class="script-path" placeholder="/绝对路径/脚本" value="${escapeHtml(script.script || '')}">
                <button type="button" class="script-icon-btn" onclick="openFilePicker(this)" title="选择脚本">📂</button>
                <button type="button" class="script-icon-btn" onclick="moveScriptItem(this, -1)" title="上移">▲</button>
                <button type="button" class="script-icon-btn" onclick="moveScriptItem(this, 1)" title="下移">▼</button>
                <button type="button" class="script-icon-btn delete" onclick="removeScriptItem(this)" title="删除脚本">✕</button>
            </div>
            <div class="step-list">${renderStepsHtml(script.steps)}</div>
            <button type="button" class="step-add" onclick="addStepRow(this)">+ 添加步骤</button>
        </div>
    `;
}

function renderScriptsHtml(scripts) {
    const list = Array.isArray(scripts) && scripts.length ? scripts : [{ script: '', steps: [{ value: '', preSleep: '', postSleep: '' }] }];
    return list.map((s, i) => renderScriptItemHtml(s, i)).join('');
}

function renderRows(page, rows) {
    const normalizedPage = rowPageKey(page);
    const listId = normalizedPage === 'config' ? 'autostart-list' : 'boot-list';
    const container = document.getElementById(listId);
    if (!container) return;

    container.innerHTML = '';
    if (rows.length === 0) {
        container.innerHTML = `<div class="empty-tip" style="padding: 20px; font-size: 13px; opacity: 0.6; text-align: center;">暂无配置，请点击下方按钮添加</div>`;
        return;
    }

    rows.forEach((row, index) => {
        const card = document.createElement('div');
        const enabled = row.enabled !== false;
        const collapsed = row.collapsed === true;
        const defaultTitle = getDefaultRowTitle(normalizedPage, index);
        const displayTitle = (row.name || '').trim() || defaultTitle;
        const statusClass = enabled ? 'enabled' : 'disabled';
        const statusText = enabled ? '已启用' : '已禁用';
        const toggleText = enabled ? '禁用' : '启用';
        const escapedDefaultTitle = escapeHtml(defaultTitle);

        card.className = `config-row-card${enabled ? '' : ' is-disabled'}${collapsed ? ' is-collapsed' : ''}`;
        card.dataset.enabled = enabled ? 'true' : 'false';
        card.dataset.collapsed = collapsed ? 'true' : 'false';

        const headerHtml = `
                <div class="config-row-header">
                    <div class="config-row-title-wrap">
                        <button type="button" class="collapse-toggle" onclick="toggleCollapseRow('${normalizedPage}', ${index})" title="${collapsed ? '展开' : '折叠'}">${collapsed ? '▶' : '▼'}</button>
                        <span class="config-row-title" data-default-title="${escapedDefaultTitle}">${escapeHtml(displayTitle)}</span>
                        <span class="config-row-status ${statusClass}">${statusText}</span>
                    </div>
                    <div class="config-row-actions">
                        <button type="button" class="config-row-btn config-row-toggle ${statusClass}" onclick="toggleConfigRow('${normalizedPage}', ${index})">${toggleText}</button>
                        <button type="button" class="config-row-btn" onclick="moveConfigRow('${normalizedPage}', ${index}, -1)">▲</button>
                        <button type="button" class="config-row-btn" onclick="moveConfigRow('${normalizedPage}', ${index}, 1)">▼</button>
                        <button type="button" class="config-row-btn delete" onclick="deleteConfigRow('${normalizedPage}', ${index})">✕</button>
                    </div>
                </div>`;

        let bodyHtml = `
                <div class="config-row-body">
                    <div class="config-field">
                        <label>自定义名称</label>
                        <input type="text" class="row-name" placeholder="${escapedDefaultTitle}" value="${escapeHtml(row.name || '')}" oninput="updateConfigRowTitle(this)">
                    </div>`;

        if (normalizedPage === 'config') {
            bodyHtml += `
                    <div class="config-field">
                        <label>运行包名 (Package Name)</label>
                        <div class="config-input-group">
                            <input type="text" class="row-pkg" placeholder="例如：com.tencent.tmgp.dfm" value="${escapeHtml(row.pkg || '')}">
                            <button type="button" class="select-btn" onclick="openPkgPicker(this)" title="选择包名">📱</button>
                        </div>
                    </div>`;
        }

        bodyHtml += `
                    <div class="config-field">
                        <label>脚本执行链（自上而下依次启动）</label>
                        <div class="scripts-list">${renderScriptsHtml(row.scripts)}</div>
                        <button type="button" class="script-add" onclick="addScriptItem(this)">+ 添加脚本</button>
                    </div>
                </div>`;

        card.innerHTML = headerHtml + bodyHtml;
        container.appendChild(card);
    });
}

window.toggleCollapseRow = (page, index) => {
    const rows = getRowsFromUI(page);
    if (!rows[index]) return;
    rows[index].collapsed = !rows[index].collapsed;
    const key = getCollapseKey(page, rows[index]);
    if (key) {
        const store = getCollapseStore(page);
        store[key] = rows[index].collapsed;
        setCollapseStore(page, store);
    }
    renderRows(page, rows);
};

window.addScriptItem = (btn) => {
    const card = btn.closest('.config-row-card');
    const list = card?.querySelector('.scripts-list');
    if (!list) return;
    const wrapper = document.createElement('div');
    const idx = list.querySelectorAll('.script-item').length;
    wrapper.innerHTML = renderScriptItemHtml({ script: '', steps: [{ value: '', preSleep: '', postSleep: '' }] }, idx);
    const item = wrapper.firstElementChild;
    list.appendChild(item);
    renumberScripts(card);
};

window.removeScriptItem = (btn) => {
    const item = btn.closest('.script-item');
    if (!item) return;
    const card = item.closest('.config-row-card');
    item.remove();
    renumberScripts(card);
};

window.moveScriptItem = (btn, direction) => {
    const item = btn.closest('.script-item');
    if (!item) return;
    const list = item.parentElement;
    const cards = Array.from(list.querySelectorAll('.script-item'));
    const idx = cards.indexOf(item);
    const target = idx + direction;
    if (target < 0 || target >= cards.length) return;
    if (direction < 0) {
        list.insertBefore(item, cards[target]);
    } else {
        list.insertBefore(cards[target], item);
    }
    renumberScripts(item.closest('.config-row-card'));
};

function renumberScripts(card) {
    if (!card) return;
    card.querySelectorAll('.script-item').forEach((item, i) => {
        const badge = item.querySelector('.script-order-badge');
        if (badge) badge.textContent = String(i + 1);
    });
}

window.addStepRow = (btn) => {
    const item = btn.closest('.script-item');
    const list = item?.querySelector('.step-list');
    if (!list) return;
    const wrapper = document.createElement('div');
    wrapper.innerHTML = renderStepsHtml([{ value: '', preSleep: '', postSleep: '' }]);
    const stepItem = wrapper.firstElementChild;
    list.appendChild(stepItem);
};

window.removeStepRow = (btn) => {
    const item = btn.closest('.step-item');
    if (!item) return;
    item.remove();
};

export function addVisualConfigRow() {
    const rows = getRowsFromUI('config');
    rows.push({ pkg: '', scripts: [{ script: '', steps: [{ value: '', preSleep: '', postSleep: '' }] }], enabled: true, name: '', collapsed: false });
    renderRows('config', rows);
}

export function addVisualBootConfigRow() {
    const rows = getRowsFromUI('boot');
    rows.push({ scripts: [{ script: '', steps: [{ value: '', preSleep: '', postSleep: '' }] }], enabled: true, name: '', collapsed: false });
    renderRows('boot', rows);
}

function parseTextToVisualRows(page, text) {
    if (!text) {
        return { header: [], footer: [], rows: [] };
    }

    const rows = [];
    const header = [];
    const footer = [];
    let foundConfig = false;

    text.split('\n').forEach(line => {
        const row = parseConfigRowLine(page, line);
        if (row) {
            foundConfig = true;
            rows.push(row);
            return;
        }

        if (!foundConfig) header.push(line);
        else footer.push(line);
    });

    return {
        header,
        footer,
        rows: applyStoredRowNames(page, rows)
    };
}

function buildTextFromVisualRows(page, header, rows, footer) {
    persistRowNames(page, rows);
    const lines = rows.map(row => formatConfigRowLine(page, row));
    return [...header, ...lines, ...footer].join('\n');
}

window.moveConfigRow = (page, index, direction) => {
    const rows = getRowsFromUI(page);
    if (index + direction < 0 || index + direction >= rows.length) return;
    const temp = rows[index];
    rows[index] = rows[index + direction];
    rows[index + direction] = temp;
    renderRows(page, rows);
};

window.toggleConfigRow = (page, index) => {
    const rows = getRowsFromUI(page);
    if (!rows[index]) return;
    rows[index].enabled = rows[index].enabled === false;
    renderRows(page, rows);
};

window.updateConfigRowTitle = (input) => {
    const card = input.closest('.config-row-card');
    const title = card?.querySelector('.config-row-title');
    if (!title) return;
    title.textContent = input.value.trim() || title.dataset.defaultTitle || '';

    const page = card?.parentElement?.id === 'autostart-list' ? 'config' : 'boot';
    persistRowNames(page, getRowsFromUI(page));
};

window.deleteConfigRow = async (page, index) => {
    const confirmed = await showConfirm('确定要删除此项吗？', {
        confirmText: '删除',
        danger: true
    });
    if (!confirmed) return;
    const rows = getRowsFromUI(page);
    const removed = rows.splice(index, 1)[0];
    if (removed) {
        const key = getCollapseKey(page, removed);
        if (key) {
            const store = getCollapseStore(page);
            delete store[key];
            setCollapseStore(page, store);
        }
    }
    renderRows(page, rows);
};

window.addVisualConfigRow = addVisualConfigRow;
window.addVisualBootConfigRow = addVisualBootConfigRow;

export async function loadConfig(options = {}) {
    const silent = options?.silent === true;
    let text = '';
    const { stdout } = await exec(`cat "${CONGFIG_PATH}" 2>/dev/null | base64 -w 0`);
    if (stdout?.trim()) {
        const decoded = decode(stdout.trim());
        if (decoded !== null) text = decoded;
    }
    const parsed = parseTextToVisualRows('config', text);
    configHeaderComments = parsed.header;
    configFooterComments = parsed.footer;
    renderRows('config', parsed.rows);
    if (!silent) {
        if (text.trim()) showToast('自启配置加载成功');
        else showToast('自启配置为空或不存在', true);
    }
}

export async function saveConfig() {
    const rows = getRowsFromUI('config');
    const content = buildTextFromVisualRows('config', configHeaderComments, rows, configFooterComments);
    if (!content.trim()) { showToast('内容不能为空', true); return; }

    const { stdout } = await exec(`mkdir -p "$(dirname ${CONGFIG_PATH})" && echo -n "${encode(content)}" | base64 -d > "${CONGFIG_PATH}" && echo OK`);
    if (stdout?.includes('OK')) showToast('自启配置保存成功');
    else showToast('自启配置保存失败', true);
}

export async function loadBootConfig(options = {}) {
    const silent = options?.silent === true;
    let text = '';
    const { stdout } = await exec(`cat "${BOOT_CONFIG_PATH}" 2>/dev/null | base64 -w 0`);
    if (stdout?.trim()) {
        const decoded = decode(stdout.trim());
        if (decoded !== null) text = decoded;
    }
    const parsed = parseTextToVisualRows('boot', text);
    bootHeaderComments = parsed.header;
    bootFooterComments = parsed.footer;
    renderRows('boot', parsed.rows);
    if (!silent) {
        if (text.trim()) showToast('开机配置加载成功');
        else showToast('开机配置为空或不存在', true);
    }
}

export async function saveBootConfig() {
    const rows = getRowsFromUI('boot');
    const content = buildTextFromVisualRows('boot', bootHeaderComments, rows, bootFooterComments);
    if (!content.trim()) { showToast('内容不能为空', true); return; }

    const { stdout } = await exec(`mkdir -p "$(dirname ${BOOT_CONFIG_PATH})" && echo -n "${encode(content)}" | base64 -d > "${BOOT_CONFIG_PATH}" && echo OK`);
    if (stdout?.includes('OK')) showToast('开机配置保存成功');
    else showToast('开机配置保存失败', true);
}

// 设备信息
export async function getBatteryInfo() {
    try {
        const { stdout } = await exec(`dumpsys battery 2>/dev/null | grep "level:" | awk '{print $2}'`);
        return parseInt(stdout?.trim()) || 0;
    } catch {
        return 0;
    }
}

export async function getPhoneBrand() {
    try {
        const { stdout } = await exec(`getprop ro.product.brand 2>/dev/null || getprop ro.product.manufacturer`);
        return stdout?.trim() || '未知';
    } catch {
        return '未知';
    }
}

export async function getFingerprint() {
    try {
        const { stdout } = await exec(`getprop ro.build.fingerprint`);
        return stdout?.trim() || '未知';
    } catch {
        return '未知';
    }
}

export async function getSerialNumber() {
    try {
        const { stdout } = await exec(`getprop ro.serialno`);
        return stdout?.trim() || '未获取';
    } catch {
        return '未获取';
    }
}

// 自启核心
export async function getCoreStatus() {
    try {
        const { stdout } = await exec(`pgrep -f "triggerctl keep-run"`);
        return !!stdout?.trim();
    } catch {
        return false;
    }
}

export async function toggleCore(action) {
    try {
        if (action === 'stop' || action === 'restart') {
            await exec(`pkill -f "triggerctl keep-run" 2>/dev/null || true`);
            if (action === 'stop') return true;
            await new Promise(r => setTimeout(r, 500));
        }
        await exec(`chmod 755 "${TRIGGERCTL_BIN}" && nohup "${TRIGGERCTL_BIN}" keep-run >/dev/null 2>&1 &`);
        return true;
    } catch {
        return false;
    }
}

const POST_FS_DATA = "/data/adb/modules/Trigger/post-fs-data.sh";

export async function getBootStartStatus() {
    try {
        const { stdout } = await exec(`grep -A 1 "\\[BOOT_CONTROL\\]" "${POST_FS_DATA}" | tail -n 1`);
        return stdout?.trim().startsWith('#');
    } catch {
        return false;
    }
}

export async function toggleBootStart(enable) {
    try {
        if (enable) {
            await exec(`sed -i '/\\[BOOT_CONTROL\\]/{n;s/^exit 0/# exit 0/}' "${POST_FS_DATA}"`);
        } else {
            await exec(`sed -i '/\\[BOOT_CONTROL\\]/{n;s/^# exit 0/exit 0/}' "${POST_FS_DATA}"`);
        }
        return true;
    } catch {
        return false;
    }
}

export async function runQuickAction(action) {
    try {
        if (action === 'clean-cache') {
            await exec(`chmod 755 "${TRIGGERCTL_BIN}" && "${TRIGGERCTL_BIN}" clean-cache`);
            return true;
        }
        if (action === 'toggle-usb') {
            await exec(`chmod 755 "${TRIGGERCTL_BIN}" && "${TRIGGERCTL_BIN}" toggle-usb`);
            return true;
        }
        return false;
    } catch {
        return false;
    }
}

export async function getCurrentModuleName() {
    try {
        const { stdout } = await exec(`grep "^# 自定义机型模块：" /data/adb/modules/Trigger/system.prop | tail -1 | sed 's/^# 自定义机型模块：//'`);
        const moduleName = stdout?.trim();
        return moduleName || "未修改";
    } catch {
        return "未修改";
    }
}

export async function getOriginalModel() {
    try {
        const { stdout } = await exec(`cat "${ORIGINAL_MODEL_FILE}" 2>/dev/null`);
        if (stdout?.trim()) return stdout.trim();

        const { stdout: currentModel } = await exec(`getprop ro.product.model`);
        const model = currentModel?.trim() || '未知';
        if (model !== '未知') {
            await exec(`echo "${model}" > "${ORIGINAL_MODEL_FILE}"`);
        }
        return model;
    } catch {
        return '未知';
    }
}

export async function loadModuleList() {
    try {
        const moduleList = document.getElementById('module-list');
        if (!moduleList) return;

        moduleList.innerHTML = '<div class="loading-tip">扫描中...</div>';
        await exec(`mkdir -p "${CUSTOM_MODULE_DIR}"`);

        const { stdout } = await exec(`ls -1 "${CUSTOM_MODULE_DIR}"/*.zip 2>/dev/null || echo ""`);
        const files = stdout?.trim().split('\n').filter(f => f.trim()) || [];

        if (files.length === 0) {
            moduleList.innerHTML = `<div class="empty-tip">暂无可用的机型模块<br/>请放置 zip 文件至：<br/><small>${CUSTOM_MODULE_DIR}</small></div>`;
            return;
        }

        moduleList.innerHTML = '';
        files.forEach(filepath => {
            const filename = filepath.split('/').pop();
            const item = document.createElement('div');
            item.className = 'module-item';
            const name = document.createElement('div');
            name.className = 'module-item-name';
            name.textContent = `📦 ${filename}`;
            const status = document.createElement('div');
            status.className = 'module-item-status';
            status.textContent = '点击切换';
            item.appendChild(name);
            item.appendChild(status);
            item.onclick = () => applyModule(filepath, filename);
            moduleList.appendChild(item);
        });

    } catch (error) {
        console.error(error);
    }
}

export async function applyModule(zipPath, moduleName) {
    try {
        const confirmed = await showConfirm(`确定要切换到 [${moduleName}] 吗？`, {
            confirmText: '切换'
        });
        if (!confirmed) return;

        showToast('正在应用机型模块...', { type: 'info' });
        const scriptPath = "/data/adb/modules/Trigger/load_custom_modules.sh";
        const cmd = `chmod 755 ${shellQuote(scriptPath)} && ${shellQuote(scriptPath)} load ${shellQuote(zipPath)}`;
        const { stdout } = await exec(cmd);

        if (stdout?.includes('成功')) {
            showRebootToast('机型模块已应用，请重启生效');
            await updateDeviceInfo();
        } else {
            showToast('应用失败', true);
        }
    } catch (error) {
        showToast('执行失败', true);
    }
}

export async function restoreDevice() {
    try {
        const confirmed = await showConfirm('确定要还原到原始机型吗？', {
            confirmText: '还原'
        });
        if (!confirmed) return;

        showToast('正在还原机型...', { type: 'info' });
        const scriptPath = "/data/adb/modules/Trigger/load_custom_modules.sh";
        const { stdout } = await exec(`chmod 755 ${shellQuote(scriptPath)} && ${shellQuote(scriptPath)} restore`);

        if (stdout?.includes('成功')) {
            showRebootToast('机型已还原，请重启生效');
            await updateDeviceInfo();
        } else {
            showToast('还原失败', true);
        }
    } catch (error) {
        showToast('执行失败', true);
    }
}

export async function updateDeviceInfo() {
    try {
        const currentModuleName = await getCurrentModuleName();
        const originalModel = await getOriginalModel();

        const currentModelEl = document.getElementById('current-model');
        const originalModelEl = document.getElementById('original-model');

        if (currentModelEl) currentModelEl.textContent = currentModuleName;
        if (originalModelEl) originalModelEl.textContent = originalModel;
    } catch (error) {
        console.error(error);
    }
}