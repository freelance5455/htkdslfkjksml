'use strict';

const I18N = {
  en: {
    lang: 'EN',
    langName: 'English',
    ui: {
      brandSub: 'PERFORMANCE CONSOLE',
      topbarLabel: 'SYSTEM CONTROL',
      tabNonRoot: 'NON-ROOT',
      tabRoot: 'ROOT',
      tagSystem: 'SYSTEM',
      tagRoot: 'ROOT',
      titleNonRoot: 'SYSTEM MODULES',
      titleRoot: 'ROOT MODULES',
      modules: 'MODULES',
      online: 'ONLINE',
      active: 'MODULES ACTIVE',
      ready: 'SYSTEM READY',
      idle1: 'redmagic shell ready',
      idle2: 'awaiting module activation...',
      warn1: 'NON-ROOT & ROOT REQUIRED',
      warn2: 'USE AT YOUR OWN RISK',
      settings: 'SETTINGS',
      modalTitle: 'SETTINGS',
      modalLangTag: 'LANGUAGE',
      modalFoot: 'SELECT YOUR PREFERRED LANGUAGE',
      user: 'USER',
      root: 'ROOT',
      apply: 'apply module',
      reset: 'reset module',
      applied: '[OK] module applied successfully',
      resetOk: '[RESET] module set to default state'
    },
    tags: {
      DISPLAY: 'DISPLAY', RENDER: 'RENDER', BATTERY: 'BATTERY', NETWORK: 'NETWORK',
      AUDIO: 'AUDIO', SYSTEM: 'SYSTEM', POWER: 'POWER', PROCESS: 'PROCESS',
      CPU: 'CPU', GPU: 'GPU', THERMAL: 'THERMAL', STORAGE: 'STORAGE',
      MEMORY: 'MEMORY', KERNEL: 'KERNEL', INPUT: 'INPUT', GAMING: 'GAMING'
    },
    modules: {
      performance_mode: { title: 'Performance Mode', desc: 'boost cpu gpu and system for gaming' },
      aggressive_mode: { title: 'Aggressive Mode', desc: 'kill telemetry and background services' },
      performance_tuning: { title: 'Performance Tuning', desc: 'tune refresh rate vsync and gpu pipeline' },
      animations_off: { title: 'Disable Animations', desc: 'set all animation scales to zero' },
      blur_off: { title: 'Disable Window Blur', desc: 'remove blur effects to cut gpu load' },
      force_gpu: { title: 'Force GPU Rendering', desc: 'route ui drawing through gpu' },
      adaptive_battery_off: { title: 'Disable Adaptive Battery', desc: 'stop restricting background apps' },
      power_save_off: { title: 'Disable Power Save Mode', desc: 'block automatic battery saver' },
      autosync_off: { title: 'Disable Auto-Sync', desc: 'stop background account sync' },
      sounds_off: { title: 'Disable System Sounds', desc: 'kill ui clicks and notification dings' },
      haptics_off: { title: 'Disable Haptics', desc: 'turn off all vibration feedback' },
      auto_updates_off: { title: 'Disable Auto Updates', desc: 'stop ota and background play updates' },
      brightness_lock: { title: 'Lock Brightness Max', desc: 'disable auto brightness and set max' },
      doze_aggressive: { title: 'Aggressive Doze Mode', desc: 'force deep sleep on background apps' },
      net_throttle_off: { title: 'Disable Network Throttling', desc: 'remove data transfer caps and limits' },
      mobile_data_on: { title: 'Mobile Data Always Active', desc: 'keep cellular running during wifi' },
      logging_off: { title: 'Disable System Logging', desc: 'reduce logging overhead on device' },
      refresh_rate_max: { title: 'Force Max Refresh Rate', desc: 'lock display to highest available hz' },
      kill_apps: { title: 'Kill Background Apps', desc: 'force stop social and media apps' },
      cpu_governor: { title: 'CPU Performance Governor', desc: 'lock all cores to performance profile' },
      gpu_max_clock: { title: 'GPU Max Clock Lock', desc: 'pin gpu to max frequency rail' },
      gpu_governor: { title: 'GPU Performance Governor', desc: 'force performance devfreq governor' },
      thermal_off: { title: 'Disable Thermal Throttling', desc: 'stop thermal daemon from capping clocks' },
      io_scheduler: { title: 'I/O Scheduler Tuning', desc: 'set noop/deadline for lowest latency' },
      vm_tuning: { title: 'VM Memory Tuning', desc: 'aggressive vm tuning for smooth frames' },
      ksm_off: { title: 'Disable KSM', desc: 'stop kernel samepage merging overhead' },
      tcp_bbr: { title: 'TCP BBR Congestion Control', desc: 'switch to bbr for lower ping spikes' },
      cpu_cores: { title: 'CPU Core Unlock', desc: 'bring all cores online and unlocked' },
      kernel_tracing_off: { title: 'Disable Kernel Tracing', desc: 'turn off ftrace and kernel debug hooks' },
      zram_off: { title: 'Disable ZRAM Swap', desc: 'remove compressed swap overhead' },
      touch_boost: { title: 'Touch Boost Enable', desc: 'raise cpu freq on every touch input' },
      cpu_boost: { title: 'CPU Boost / Stune', desc: 'boost top-app and foreground tasks' },
      game_mode: { title: 'Game Mode Master', desc: 'enable full game booster mode flags' },
      wifi_power_off: { title: 'Disable WiFi Power Save', desc: 'keep wifi radio at full power' }
    }
  },
  id: {
    lang: 'ID',
    langName: 'Indonesia',
    ui: {
      brandSub: 'KONSOL PERFORMA',
      topbarLabel: 'KONTROL SISTEM',
      tabNonRoot: 'NON-ROOT',
      tabRoot: 'ROOT',
      tagSystem: 'SISTEM',
      tagRoot: 'ROOT',
      titleNonRoot: 'MODUL SISTEM',
      titleRoot: 'MODUL ROOT',
      modules: 'MODUL',
      online: 'AKTIF',
      active: 'MODUL AKTIF',
      ready: 'SISTEM SIAP',
      idle1: 'shell redmagic siap',
      idle2: 'menunggu aktivasi modul...',
      warn1: 'NON-ROOT & ROOT DIPERLUKAN',
      warn2: 'GUNAKAN DENGAN RISIKO SENDIRI',
      settings: 'PENGATURAN',
      modalTitle: 'PENGATURAN',
      modalLangTag: 'BAHASA',
      modalFoot: 'PILIH BAHASA YANG ANDA INGINKAN',
      user: 'PENGGUNA',
      root: 'ROOT',
      apply: 'terapkan modul',
      reset: 'reset modul',
      applied: '[OK] modul berhasil diterapkan',
      resetOk: '[RESET] modul dikembalikan ke default'
    },
    tags: {
      DISPLAY: 'TAMPILAN', RENDER: 'RENDER', BATTERY: 'BATERAI', NETWORK: 'JARINGAN',
      AUDIO: 'AUDIO', SYSTEM: 'SISTEM', POWER: 'DAYA', PROCESS: 'PROSES',
      CPU: 'CPU', GPU: 'GPU', THERMAL: 'TERMAL', STORAGE: 'PENYIMPANAN',
      MEMORY: 'MEMORI', KERNEL: 'KERNEL', INPUT: 'INPUT', GAMING: 'GAMING'
    },
    modules: {
      performance_mode: { title: 'Mode Performa', desc: 'tingkatkan cpu gpu dan sistem untuk game' },
      aggressive_mode: { title: 'Mode Agresif', desc: 'matikan telemetri dan layanan latar' },
      performance_tuning: { title: 'Penyetelan Performa', desc: 'atur refresh rate vsync dan pipeline gpu' },
      animations_off: { title: 'Nonaktifkan Animasi', desc: 'atur semua skala animasi ke nol' },
      blur_off: { title: 'Nonaktifkan Blur Jendela', desc: 'hapus efek blur untuk kurangi beban gpu' },
      force_gpu: { title: 'Paksa Rendering GPU', desc: 'arahkan gambar ui melalui gpu' },
      adaptive_battery_off: { title: 'Nonaktifkan Baterai Adaptif', desc: 'hentikan pembatasan aplikasi latar' },
      power_save_off: { title: 'Nonaktifkan Mode Hemat Daya', desc: 'blokir penghemat baterai otomatis' },
      autosync_off: { title: 'Nonaktifkan Sinkronisasi', desc: 'hentikan sinkronisasi akun latar' },
      sounds_off: { title: 'Nonaktifkan Suara Sistem', desc: 'matikan klik ui dan bunyi notifikasi' },
      haptics_off: { title: 'Nonaktifkan Haptik', desc: 'matikan semua umpan balik getaran' },
      auto_updates_off: { title: 'Nonaktifkan Pembaruan Otomatis', desc: 'hentikan ota dan pembaruan latar' },
      brightness_lock: { title: 'Kunci Kecerahan Maks', desc: 'nonaktifkan kecerahan otomatis, atur maks' },
      doze_aggressive: { title: 'Mode Doze Agresif', desc: 'paksa tidur nyenyak pada aplikasi latar' },
      net_throttle_off: { title: 'Nonaktifkan Throttling Jaringan', desc: 'hapus batas transfer data' },
      mobile_data_on: { title: 'Data Seluler Selalu Aktif', desc: 'biarkan seluler berjalan saat wifi' },
      logging_off: { title: 'Nonaktifkan Log Sistem', desc: 'kurangi beban log pada perangkat' },
      refresh_rate_max: { title: 'Paksa Refresh Rate Maks', desc: 'kunci layar ke hz tertinggi' },
      kill_apps: { title: 'Matikan Aplikasi Latar', desc: 'paksa hentikan aplikasi sosial dan media' },
      cpu_governor: { title: 'Governor Performa CPU', desc: 'kunci semua core ke profil performa' },
      gpu_max_clock: { title: 'Kunci Clock Maks GPU', desc: 'sematkan gpu ke rel frekuensi maks' },
      gpu_governor: { title: 'Governor Performa GPU', desc: 'paksa governor devfreq performa' },
      thermal_off: { title: 'Nonaktifkan Throttling Termal', desc: 'hentikan daemon termal membatasi clock' },
      io_scheduler: { title: 'Penyetelan Penjadwal I/O', desc: 'atur noop/deadline untuk latensi terendah' },
      vm_tuning: { title: 'Penyetelan Memori VM', desc: 'penyetelan vm agresif untuk frame mulus' },
      ksm_off: { title: 'Nonaktifkan KSM', desc: 'hentikan overhead penggabungan samepage' },
      tcp_bbr: { title: 'Kontrol Kongesti TCP BBR', desc: 'beralih ke bbr untuk lonjakan ping rendah' },
      cpu_cores: { title: 'Buka Kunci Core CPU', desc: 'aktifkan semua core dan buka kunci' },
      kernel_tracing_off: { title: 'Nonaktifkan Pelacakan Kernel', desc: 'matikan ftrace dan kait debug kernel' },
      zram_off: { title: 'Nonaktifkan ZRAM Swap', desc: 'hapus overhead swap terkompresi' },
      touch_boost: { title: 'Aktifkan Touch Boost', desc: 'naikkan frekuensi cpu setiap sentuhan' },
      cpu_boost: { title: 'CPU Boost / Stune', desc: 'tingkatkan tugas top-app dan foreground' },
      game_mode: { title: 'Master Mode Game', desc: 'aktifkan semua flag mode booster game' },
      wifi_power_off: { title: 'Nonaktifkan Hemat Daya WiFi', desc: 'jaga radio wifi pada daya penuh' }
    }
  },
  ja: {
    lang: 'JA',
    langName: '日本語',
    ui: {
      brandSub: 'パフォーマンスコンソール',
      topbarLabel: 'システム制御',
      tabNonRoot: '非ルート',
      tabRoot: 'ルート',
      tagSystem: 'システム',
      tagRoot: 'ルート',
      titleNonRoot: 'システムモジュール',
      titleRoot: 'ルートモジュール',
      modules: 'モジュール',
      online: 'オンライン',
      active: 'モジュール有効',
      ready: 'システム準備完了',
      idle1: 'redmagic shell ready',
      idle2: 'モジュールの有効化を待機中...',
      warn1: '非ルート & ルートが必要',
      warn2: '自己責任でご使用ください',
      settings: '設定',
      modalTitle: '設定',
      modalLangTag: '言語',
      modalFoot: 'ご希望の言語を選択してください',
      user: 'ユーザー',
      root: 'ルート',
      apply: 'モジュールを適用',
      reset: 'モジュールをリセット',
      applied: '[OK] モジュールを適用しました',
      resetOk: '[RESET] モジュールをデフォルトに戻しました'
    },
    tags: {
      DISPLAY: 'ディスプレイ', RENDER: 'レンダー', BATTERY: 'バッテリー', NETWORK: 'ネットワーク',
      AUDIO: 'オーディオ', SYSTEM: 'システム', POWER: 'パワー', PROCESS: 'プロセス',
      CPU: 'CPU', GPU: 'GPU', THERMAL: 'サーマル', STORAGE: 'ストレージ',
      MEMORY: 'メモリ', KERNEL: 'カーネル', INPUT: '入力', GAMING: 'ゲーミング'
    },
    modules: {
      performance_mode: { title: 'パフォーマンスモード', desc: 'ゲーム用にCPU・GPU・システムを強化' },
      aggressive_mode: { title: 'アグレッシブモード', desc: 'テレメトリとバックグラウンドサービスを停止' },
      performance_tuning: { title: 'パフォーマンス調整', desc: 'リフレッシュレート・vsync・GPUパイプラインを調整' },
      animations_off: { title: 'アニメーションを無効化', desc: 'すべてのアニメーションスケールをゼロに設定' },
      blur_off: { title: 'ウィンドウぼかしを無効化', desc: 'ぼかし効果を削除してGPU負荷を軽減' },
      force_gpu: { title: 'GPUレンダリングを強制', desc: 'UI描画をGPU経由に' },
      adaptive_battery_off: { title: '適応バッテリーを無効化', desc: 'バックグラウンドアプリの制限を停止' },
      power_save_off: { title: '省電力モードを無効化', desc: '自動バッテリーセーバーをブロック' },
      autosync_off: { title: '自動同期を無効化', desc: 'バックグラウンドアカウント同期を停止' },
      sounds_off: { title: 'システムサウンドを無効化', desc: 'UIクリックと通知音を停止' },
      haptics_off: { title: 'ハプティクスを無効化', desc: 'すべての振動フィードバックをオフ' },
      auto_updates_off: { title: '自動更新を無効化', desc: 'OTAとバックグラウンド更新を停止' },
      brightness_lock: { title: '明るさ最大にロック', desc: '自動明るさを無効化して最大に設定' },
      doze_aggressive: { title: '積極的Dozeモード', desc: 'バックグラウンドアプリを強制スリープ' },
      net_throttle_off: { title: 'ネットワーク制限を無効化', desc: 'データ転送の上限を削除' },
      mobile_data_on: { title: 'モバイルデータ常時有効', desc: 'WiFi中もセルラーを維持' },
      logging_off: { title: 'システムログを無効化', desc: 'デバイスのログ負荷を軽減' },
      refresh_rate_max: { title: '最大リフレッシュレートを強制', desc: 'ディスプレイを最高Hzにロック' },
      kill_apps: { title: 'バックグラウンドアプリを終了', desc: 'SNSとメディアアプリを強制停止' },
      cpu_governor: { title: 'CPUパフォーマンスガバナー', desc: 'すべてのコアをパフォーマンスにロック' },
      gpu_max_clock: { title: 'GPU最大クロックロック', desc: 'GPUを最大周波数レールに固定' },
      gpu_governor: { title: 'GPUパフォーマンスガバナー', desc: 'パフォーマンスdevfreqガバナーを強制' },
      thermal_off: { title: 'サーマルスロットリングを無効化', desc: 'サーマルデーモンのクロック制限を停止' },
      io_scheduler: { title: 'I/Oスケジューラ調整', desc: '最低レイテンシのためnoop/deadlineを設定' },
      vm_tuning: { title: 'VMメモリ調整', desc: 'スムーズなフレームのための積極的VM調整' },
      ksm_off: { title: 'KSMを無効化', desc: 'カーネル同一ページマージのオーバーヘッドを停止' },
      tcp_bbr: { title: 'TCP BBR輻輳制御', desc: 'pingスパイク低減のためBBRに切替' },
      cpu_cores: { title: 'CPUコアのロック解除', desc: 'すべてのコアをオンラインにしてロック解除' },
      kernel_tracing_off: { title: 'カーネルトレースを無効化', desc: 'ftraceとカーネルデバッグフックをオフ' },
      zram_off: { title: 'ZRAMスワップを無効化', desc: '圧縮スワップのオーバーヘッドを削除' },
      touch_boost: { title: 'タッチブーストを有効化', desc: 'タッチ入力ごとにCPU周波数を上げる' },
      cpu_boost: { title: 'CPUブースト / Stune', desc: 'トップアプリとフォアグラウンドをブースト' },
      game_mode: { title: 'ゲームモードマスター', desc: 'フルゲームブースターモードを有効化' },
      wifi_power_off: { title: 'WiFi省電力を無効化', desc: 'WiFi無線をフルパワーに維持' }
    }
  },
  fil: {
    lang: 'PH',
    langName: 'Philippines',
    ui: {
      brandSub: 'PERFORMANCE CONSOLE',
      topbarLabel: 'KONTROL NG SISTEMA',
      tabNonRoot: 'NON-ROOT',
      tabRoot: 'ROOT',
      tagSystem: 'SYSTEM',
      tagRoot: 'ROOT',
      titleNonRoot: 'SYSTEM MODULES',
      titleRoot: 'ROOT MODULES',
      modules: 'MODULES',
      online: 'ONLINE',
      active: 'MODULES ACTIVE',
      ready: 'SYSTEM READY',
      idle1: 'handa na ang redmagic shell',
      idle2: 'hinihintay ang module activation...',
      warn1: 'KAILANGAN ANG NON-ROOT & ROOT',
      warn2: 'GAMITIN SA SARILING PANGANIB',
      settings: 'SETTINGS',
      modalTitle: 'SETTINGS',
      modalLangTag: 'WIKA',
      modalFoot: 'PILIIN ANG GUSTO MONG WIKA',
      user: 'USER',
      root: 'ROOT',
      apply: 'i-apply ang module',
      reset: 'i-reset ang module',
      applied: '[OK] matagumpay na na-apply ang module',
      resetOk: '[RESET] naibalik ang module sa default'
    },
    tags: {
      DISPLAY: 'DISPLAY', RENDER: 'RENDER', BATTERY: 'BATERIYA', NETWORK: 'NETWORK',
      AUDIO: 'AUDIO', SYSTEM: 'SYSTEM', POWER: 'POWER', PROCESS: 'PROSESO',
      CPU: 'CPU', GPU: 'GPU', THERMAL: 'TERMAL', STORAGE: 'STORAGE',
      MEMORY: 'MEMORY', KERNEL: 'KERNEL', INPUT: 'INPUT', GAMING: 'GAMING'
    },
    modules: {
      performance_mode: { title: 'Performance Mode', desc: 'i-boost ang cpu gpu at system para sa gaming' },
      aggressive_mode: { title: 'Aggressive Mode', desc: 'patayin ang telemetry at background services' },
      performance_tuning: { title: 'Performance Tuning', desc: 'i-tune ang refresh rate vsync at gpu pipeline' },
      animations_off: { title: 'I-disable ang Animations', desc: 'itakda lahat ng animation scale sa zero' },
      blur_off: { title: 'I-disable ang Window Blur', desc: 'tanggalin ang blur effects para bumaba ang gpu load' },
      force_gpu: { title: 'Puwersahin ang GPU Rendering', desc: 'idaan ang ui drawing sa gpu' },
      adaptive_battery_off: { title: 'I-disable ang Adaptive Battery', desc: 'itigil ang pag-restrict sa background apps' },
      power_save_off: { title: 'I-disable ang Power Save Mode', desc: 'i-block ang automatic battery saver' },
      autosync_off: { title: 'I-disable ang Auto-Sync', desc: 'itigil ang background account sync' },
      sounds_off: { title: 'I-disable ang System Sounds', desc: 'patayin ang ui clicks at notification dings' },
      haptics_off: { title: 'I-disable ang Haptics', desc: 'patayin lahat ng vibration feedback' },
      auto_updates_off: { title: 'I-disable ang Auto Updates', desc: 'itigil ang ota at background play updates' },
      brightness_lock: { title: 'I-lock ang Brightness Max', desc: 'i-disable ang auto brightness at itakda sa max' },
      doze_aggressive: { title: 'Aggressive Doze Mode', desc: 'puwersahin ang deep sleep sa background apps' },
      net_throttle_off: { title: 'I-disable ang Network Throttling', desc: 'tanggalin ang data transfer caps at limits' },
      mobile_data_on: { title: 'Mobile Data Always Active', desc: 'panatilihing tumatakbo ang cellular habang may wifi' },
      logging_off: { title: 'I-disable ang System Logging', desc: 'bawasan ang logging overhead sa device' },
      refresh_rate_max: { title: 'Puwersahin ang Max Refresh Rate', desc: 'i-lock ang display sa pinakamataas na hz' },
      kill_apps: { title: 'Patayin ang Background Apps', desc: 'puwersahing itigil ang social at media apps' },
      cpu_governor: { title: 'CPU Performance Governor', desc: 'i-lock lahat ng cores sa performance profile' },
      gpu_max_clock: { title: 'GPU Max Clock Lock', desc: 'i-pin ang gpu sa max frequency rail' },
      gpu_governor: { title: 'GPU Performance Governor', desc: 'puwersahin ang performance devfreq governor' },
      thermal_off: { title: 'I-disable ang Thermal Throttling', desc: 'itigil ang thermal daemon sa pag-cap ng clocks' },
      io_scheduler: { title: 'I/O Scheduler Tuning', desc: 'itakda ang noop/deadline para sa pinakamababang latency' },
      vm_tuning: { title: 'VM Memory Tuning', desc: 'aggressive vm tuning para sa smooth frames' },
      ksm_off: { title: 'I-disable ang KSM', desc: 'itigil ang kernel samepage merging overhead' },
      tcp_bbr: { title: 'TCP BBR Congestion Control', desc: 'lumipat sa bbr para sa mas mababang ping spikes' },
      cpu_cores: { title: 'CPU Core Unlock', desc: 'gawing online at unlocked ang lahat ng cores' },
      kernel_tracing_off: { title: 'I-disable ang Kernel Tracing', desc: 'patayin ang ftrace at kernel debug hooks' },
      zram_off: { title: 'I-disable ang ZRAM Swap', desc: 'tanggalin ang compressed swap overhead' },
      touch_boost: { title: 'I-enable ang Touch Boost', desc: 'pataasin ang cpu freq sa bawat touch input' },
      cpu_boost: { title: 'CPU Boost / Stune', desc: 'i-boost ang top-app at foreground tasks' },
      game_mode: { title: 'Game Mode Master', desc: 'i-enable ang full game booster mode flags' },
      wifi_power_off: { title: 'I-disable ang WiFi Power Save', desc: 'panatilihing full power ang wifi radio' }
    }
  }
};

const MODULES = [
  { id: 'performance_mode', group: 'nonroot', tag: 'GAMING',
    on: `settings put global performance_mode 1
settings put global sustained_performance_mode_enabled 1
settings put global gaming_mode 1
settings put global game_turbo 1
settings put global fixed_perf_mode 1
settings put global perf_hint_enabled 1
settings put global power_save_mode_enabled 0
settings put global low_power_mode 0
settings put global power_efficiency_mode 0
settings put global thermal_throttling_enabled 0
settings put global touch_boost 1
settings put global frame_rate_boost 1
settings put global game_boost 1
settings put global background_limit 2
settings put global cached_apps_freezer enabled
settings put global app_standby_enabled 1
settings put global preload_apps 0
settings put global automatic_system_updates 0
settings put global automatic_app_updates 0
settings put global debug.hwui.use_vulkan 1
settings put global debug.hwui.renderer skiavk
settings put global force_hw_ui 1
settings put global opengl_traces 0
settings put global enable_gpu_debug 0
settings put global hwui.profiling 0`,
    off: `settings put global performance_mode 0
settings put global sustained_performance_mode_enabled 0
settings put global gaming_mode 0
settings put global game_turbo 0
settings put global fixed_perf_mode 0
settings put global perf_hint_enabled 0
settings put global power_save_mode_enabled 1
settings put global low_power_mode 0
settings put global power_efficiency_mode 1
settings put global thermal_throttling_enabled 1
settings put global touch_boost 0
settings put global frame_rate_boost 0
settings put global game_boost 0
settings put global background_limit 4
settings put global cached_apps_freezer disabled
settings put global app_standby_enabled 0
settings put global preload_apps 1
settings put global automatic_system_updates 1
settings put global automatic_app_updates 1
settings put global debug.hwui.use_vulkan 0
settings put global debug.hwui.renderer skiagl
settings put global force_hw_ui 0
settings put global opengl_traces 0
settings put global enable_gpu_debug 0
settings put global hwui.profiling 0` },
  { id: 'aggressive_mode', group: 'nonroot', tag: 'SYSTEM',
    on: `settings put global background_limit 1
settings put global background_activity_timeout 120
settings put global cached_apps_freezer enabled
settings put global app_standby_enabled 1
settings put global standby_bucket 1
settings put global idle_bucket 1
settings put global oplus_analytics 0
settings put global oplus_log_report 0
settings put global coloros_telemetry 0
settings put global smart_boost 0
settings put global atlas_engine 0
settings put global oplus_aimemory 0
settings put global cota_service 0
settings put global lfeh_service 0
settings put global pscanvas 0
settings put global cosa 0
settings put global logd.size 1M
settings put global logd.speed 0
settings put global statsd 0
settings put global dumpstate 0
settings put global bugreport 0
settings put global send_usage_stats 0
settings put global send_diagnostic_data 0
settings put global play_services_analytics 0
settings put global google_feedback 0
settings put global window_animation_scale 0.0
settings put global transition_animation_scale 0.0
settings put global animator_duration_scale 0.0
settings put global wifi_scan_interval 7200
settings put global network_quality_check 0
settings put global captive_portal_detection_enabled 0
settings put global location_mode 0
settings put global bluetooth_scan_always 0
settings put global auto_brightness 0
settings put global haptic_feedback_enabled 0
settings put global vibration_enabled 0
settings put global heads_up_notifications 0
settings put global floating_notifications 0
settings put global instant_apps 0
settings put global nearby_share 0
settings put global quick_share 0`,
    off: `settings put global background_limit 4
settings put global background_activity_timeout 1800
settings put global cached_apps_freezer disabled
settings put global app_standby_enabled 0
settings put global standby_bucket 0
settings put global idle_bucket 0
settings put global oplus_analytics 1
settings put global oplus_log_report 1
settings put global coloros_telemetry 1
settings put global smart_boost 1
settings put global atlas_engine 1
settings put global oplus_aimemory 1
settings put global cota_service 1
settings put global lfeh_service 1
settings put global pscanvas 1
settings put global cosa 1
settings put global logd.size 4M
settings put global logd.speed 1
settings put global statsd 1
settings put global dumpstate 1
settings put global bugreport 1
settings put global send_usage_stats 1
settings put global send_diagnostic_data 1
settings put global play_services_analytics 1
settings put global google_feedback 1
settings put global window_animation_scale 1.0
settings put global transition_animation_scale 1.0
settings put global animator_duration_scale 1.0
settings put global wifi_scan_interval 1800
settings put global network_quality_check 1
settings put global captive_portal_detection_enabled 1
settings put global location_mode 3
settings put global bluetooth_scan_always 1
settings put global auto_brightness 1
settings put global haptic_feedback_enabled 1
settings put global vibration_enabled 1
settings put global heads_up_notifications 1
settings put global floating_notifications 1
settings put global instant_apps 1
settings put global nearby_share 1
settings put global quick_share 1` },
  { id: 'performance_tuning', group: 'nonroot', tag: 'DISPLAY',
    on: `settings put global refresh_rate_switching 0
settings put global adaptive_refresh_rate 0
settings put system peak_refresh_rate 90.0
settings put system min_refresh_rate 90.0
settings put global display_refresh_rate 90
settings put system touch.prediction 1
settings put system touch.resample 1
settings put global debug.sf.low_latency_mode 1
settings put global debug.sf.frame_rate_switch 0
settings put global debug.sf.vsync 1
settings put global surface_finger_vsync 1
settings put global gpu_keepalive 1
settings put global gpu_power_save 0
settings put global gpu_prefer_vulkan 1
settings put global gpu_vsync 1
settings put global gpu_pacing 1
settings put global gpu_triple 1
settings put global gpu_async 1
settings put global gpu_buffer 3
settings put global gpu_fence 1
settings put global gpu_latency 0
settings put global gpu_boost 1
settings put global gpu_busy 1
settings put global gpu_overclock 0
settings put global vsync 1
settings put global triple_buffering 1
settings put global frame_pacing 1
settings put global touch_response_boost 1`,
    off: `settings put global refresh_rate_switching 1
settings put global adaptive_refresh_rate 1
settings put system peak_refresh_rate 60.0
settings put system min_refresh_rate 60.0
settings put global display_refresh_rate 60
settings put system touch.prediction 0
settings put system touch.resample 0
settings put global debug.sf.low_latency_mode 0
settings put global debug.sf.frame_rate_switch 1
settings put global debug.sf.vsync 1
settings put global surface_finger_vsync 0
settings put global gpu_keepalive 0
settings put global gpu_power_save 1
settings put global gpu_prefer_vulkan 0
settings put global gpu_vsync 1
settings put global gpu_pacing 0
settings put global gpu_triple 0
settings put global gpu_async 0
settings put global gpu_buffer 2
settings put global gpu_fence 0
settings put global gpu_latency 1
settings put global gpu_boost 0
settings put global gpu_busy 0
settings put global gpu_overclock 0
settings put global vsync 1
settings put global triple_buffering 0
settings put global frame_pacing 0
settings put global touch_response_boost 0` },
  { id: 'animations_off', group: 'nonroot', tag: 'DISPLAY',
    on: `settings put global window_animation_scale 0.0\nsettings put global transition_animation_scale 0.0\nsettings put global animator_duration_scale 0.0\nsettings put secure window_animation_scale 0.0\nsettings put secure transition_animation_scale 0.0\nsettings put secure animator_duration_scale 0.0\nsettings put system window_animation_scale 0.0\nsettings put system transition_animation_scale 0.0\nsettings put system animator_duration_scale 0.0\nsettings put global development_settings_enabled 1\necho "[ok] animations disabled"`,
    off: `settings put global window_animation_scale 1.0\nsettings put global transition_animation_scale 1.0\nsettings put global animator_duration_scale 1.0\nsettings put secure window_animation_scale 1.0\nsettings put secure transition_animation_scale 1.0\nsettings put secure animator_duration_scale 1.0\nsettings put system window_animation_scale 1.0\nsettings put system transition_animation_scale 1.0\nsettings put system animator_duration_scale 1.0\necho "[ok] animations restored"` },
  { id: 'blur_off', group: 'nonroot', tag: 'DISPLAY',
    on: `settings put global disable_window_blurs 1\nsettings put global accessibility_reduce_transparency 1\nsettings put secure accessibility_reduce_transparency 1\nsettings put system accessibility_reduce_transparency 1\nsettings put global blur_enabled 0\nsettings put system blur_enabled 0\nsettings put global window_blur_enabled 0\nsettings put system window_blur_enabled 0\nsettings put secure window_blur_enabled 0\nsettings put global reduce_transparency 1\necho "[ok] window blur disabled"`,
    off: `settings put global disable_window_blurs 0\nsettings put global accessibility_reduce_transparency 0\nsettings put secure accessibility_reduce_transparency 0\nsettings put system accessibility_reduce_transparency 0\nsettings put global blur_enabled 1\nsettings put system blur_enabled 1\nsettings put global window_blur_enabled 1\nsettings put system window_blur_enabled 1\nsettings put secure window_blur_enabled 1\nsettings put global reduce_transparency 0\necho "[ok] window blur restored"` },
  { id: 'force_gpu', group: 'nonroot', tag: 'RENDER',
    on: `settings put global force_gpu_rendering 1\nsettings put global hwui.force_hw 1\nsettings put global debug.hwui.renderer opengl\nsettings put global disable_hw_overlays 0\nsettings put global force_hw_ui 1\nsettings put global enable_gpu_debug_layers 0\nsettings put secure force_gpu_rendering 1\nsettings put system force_gpu_rendering 1\nsettings put global use_gpu_renderer 1\nsettings put global hwui_render_thread 1\necho "[ok] gpu rendering forced"`,
    off: `settings put global force_gpu_rendering 0\nsettings put global hwui.force_hw 0\nsettings put global force_hw_ui 0\nsettings put global disable_hw_overlays 1\nsettings put secure force_gpu_rendering 0\nsettings put system force_gpu_rendering 0\nsettings put global use_gpu_renderer 0\nsettings put global hwui_render_thread 0\necho "[ok] gpu rendering restored"` },
  { id: 'adaptive_battery_off', group: 'nonroot', tag: 'BATTERY',
    on: `settings put global adaptive_battery_management_enabled 0\nsettings put global app_standby_enabled 0\nsettings put global app_auto_restriction_enabled 0\nsettings put secure adaptive_battery_management_enabled 0\nsettings put system adaptive_battery_management_enabled 0\nsettings put global battery_manager_enabled 0\nsettings put global low_power 0\nsettings put global battery_saver_mode 0\nsettings put global restrict_background_apps 0\ndumpsys deviceidle disable 2>/dev/null\necho "[ok] adaptive battery disabled"`,
    off: `settings put global adaptive_battery_management_enabled 1\nsettings put global app_standby_enabled 1\nsettings put global app_auto_restriction_enabled 1\nsettings put secure adaptive_battery_management_enabled 1\nsettings put system adaptive_battery_management_enabled 1\nsettings put global battery_manager_enabled 1\nsettings put global restrict_background_apps 1\ndumpsys deviceidle enable 2>/dev/null\necho "[ok] adaptive battery restored"` },
  { id: 'power_save_off', group: 'nonroot', tag: 'BATTERY',
    on: `settings put global low_power 0\nsettings put global automatic_power_save_mode 0\nsettings put global battery_saver_mode 0\nsettings put secure battery_saver_mode 0\nsettings put system battery_saver_mode 0\nsettings put global low_power_sticky 0\nsettings put global low_power_trigger_level 0\nsettings put global power_save_mode 0\nsettings put global battery_saver_force 0\ndumpsys battery unplug 2>/dev/null\necho "[ok] power save disabled"`,
    off: `settings put global low_power 0\nsettings put global automatic_power_save_mode 1\nsettings put global battery_saver_mode 0\nsettings put secure battery_saver_mode 0\nsettings put system battery_saver_mode 0\nsettings put global low_power_sticky 0\nsettings put global power_save_mode 1\nsettings put global battery_saver_force 1\ndumpsys battery reset 2>/dev/null\necho "[ok] power save restored"` },
  { id: 'autosync_off', group: 'nonroot', tag: 'NETWORK',
    on: `settings put global auto_sync 0\nsettings put global background_data 0\nsettings put global data_saver_mode 1\nsettings put global master_sync_automatically 0\nsettings put secure master_sync_automatically 0\nsettings put system master_sync_automatically 0\nsettings put global sync_enabled 0\nsettings put global sync_automatically 0\nsettings put secure sync_automatically 0\nsettings put global data_saver_restrict_background 1\necho "[ok] auto-sync disabled"`,
    off: `settings put global auto_sync 1\nsettings put global background_data 1\nsettings put global data_saver_mode 0\nsettings put global master_sync_automatically 1\nsettings put secure master_sync_automatically 1\nsettings put system master_sync_automatically 1\nsettings put global sync_enabled 1\nsettings put global sync_automatically 1\nsettings put secure sync_automatically 1\nsettings put global data_saver_restrict_background 0\necho "[ok] auto-sync restored"` },
  { id: 'sounds_off', group: 'nonroot', tag: 'AUDIO',
    on: `settings put system sound_effects_enabled 0\nsettings put system dtmf_tone 0\nsettings put system dtmf_tone_type 0\nsettings put system touch_sounds_enabled 0\nsettings put system lock_screen_sound 0\nsettings put system charging_sounds_enabled 0\nsettings put system camera_sounds 0\nsettings put system keyclick_sounds 0\nsettings put system dock_sounds 0\nsettings put system haptic_feedback_enabled 0\nsettings put global sound_effects_enabled 0\necho "[ok] system sounds disabled"`,
    off: `settings put system sound_effects_enabled 1\nsettings put system dtmf_tone 1\nsettings put system dtmf_tone_type 0\nsettings put system touch_sounds_enabled 1\nsettings put system lock_screen_sound 1\nsettings put system charging_sounds_enabled 1\nsettings put system camera_sounds 1\nsettings put system keyclick_sounds 1\nsettings put system dock_sounds 1\nsettings put system haptic_feedback_enabled 1\nsettings put global sound_effects_enabled 1\necho "[ok] system sounds restored"` },
  { id: 'haptics_off', group: 'nonroot', tag: 'SYSTEM',
    on: `settings put system vibrate_on 0\nsettings put system haptic_feedback_enabled 0\nsettings put system vibrate_when_ringing 0\nsettings put secure haptic_feedback_enabled 0\nsettings put global haptic_feedback_enabled 0\nsettings put system vibrate_in_silent 0\nsettings put system aod_touch_vibration 0\nsettings put system vibrate_on_click 0\nsettings put system haptic_on 0\nsettings put global vibration_enabled 0\necho "[ok] haptics disabled"`,
    off: `settings put system vibrate_on 1\nsettings put system haptic_feedback_enabled 1\nsettings put system vibrate_when_ringing 1\nsettings put secure haptic_feedback_enabled 1\nsettings put global haptic_feedback_enabled 1\nsettings put system vibrate_in_silent 1\nsettings put system aod_touch_vibration 1\nsettings put system vibrate_on_click 1\nsettings put system haptic_on 1\nsettings put global vibration_enabled 1\necho "[ok] haptics restored"` },
  { id: 'auto_updates_off', group: 'nonroot', tag: 'SYSTEM',
    on: `settings put global ota_disable_automatic_update 1\nsettings put global auto_update_apps 0\nsettings put global auto_update_apps_wifi_only 0\nsettings put global play_store_auto_update 0\nsettings put global app_auto_update_enabled 0\nsettings put global system_update_auto_download 0\nsettings put global system_update_auto_install 0\nsettings put global security_update_auto 0\nsettings put global system_update_policy 0\nsettings put secure ota_disable_automatic_update 1\necho "[ok] auto updates disabled"`,
    off: `settings put global ota_disable_automatic_update 0\nsettings put global auto_update_apps 1\nsettings put global auto_update_apps_wifi_only 1\nsettings put global play_store_auto_update 1\nsettings put global app_auto_update_enabled 1\nsettings put global system_update_auto_download 1\nsettings put global system_update_auto_install 1\nsettings put global security_update_auto 1\nsettings put global system_update_policy 1\nsettings put secure ota_disable_automatic_update 0\necho "[ok] auto updates restored"` },
  { id: 'brightness_lock', group: 'nonroot', tag: 'DISPLAY',
    on: `settings put system screen_brightness_mode 0\nsettings put system adaptive_brightness 0\nsettings put secure adaptive_brightness 0\nsettings put global adaptive_brightness 0\nsettings put system auto_brightness 0\nsettings put secure auto_brightness 0\nsettings put system screen_brightness 255\nsettings put system screen_brightness_float 1.0\nsettings put global brightness_mode 0\nsettings put secure brightness_mode 0\necho "[ok] brightness locked max"`,
    off: `settings put system screen_brightness_mode 1\nsettings put system adaptive_brightness 1\nsettings put secure adaptive_brightness 1\nsettings put global adaptive_brightness 1\nsettings put system auto_brightness 1\nsettings put secure auto_brightness 1\nsettings put system screen_brightness_float 0.5\nsettings put global brightness_mode 1\nsettings put secure brightness_mode 1\necho "[ok] brightness restored"` },
  { id: 'doze_aggressive', group: 'nonroot', tag: 'POWER',
    on: `dumpsys deviceidle enable all 2>/dev/null\ndumpsys deviceidle force-idle 2>/dev/null\nsettings put global device_idle_constants inactive_to=60000,sensing_to=0,locating_to=0,idle_after_inactive_to=30000,idle_pending_to=30000,max_idle_pending_to=60000,idle_pending_factor=2.0,idle_to=300000,max_idle_to=900000,idle_factor=2.0,min_time_to_reset=60000\nsettings put secure device_idle_constants inactive_to=60000,sensing_to=0,locating_to=0,idle_after_inactive_to=30000\nsettings put system device_idle_constants inactive_to=60000,sensing_to=0,locating_to=0,idle_after_inactive_to=30000\nsettings put global doze_enabled 1\nsettings put global doze_always_on 1\nsettings put global doze_aggressive 1\nsettings put global deep_sleep_enabled 1\nsettings put global device_idle_enabled 1\nsettings put global low_power_sleep 1\necho "[ok] aggressive doze enabled"`,
    off: `dumpsys deviceidle disable 2>/dev/null\nsettings put global device_idle_constants inactive_to=1800000,sensing_to=240000,locating_to=30000,idle_after_inactive_to=1800000,idle_pending_to=300000,max_idle_pending_to=600000,idle_pending_factor=2.0,idle_to=3600000,max_idle_to=21600000,idle_factor=2.0,min_time_to_reset=10800000\nsettings delete secure device_idle_constants 2>/dev/null\nsettings delete system device_idle_constants 2>/dev/null\nsettings put global doze_always_on 0\nsettings put global doze_aggressive 0\nsettings put global deep_sleep_enabled 0\nsettings put global low_power_sleep 0\necho "[ok] aggressive doze disabled"` },
  { id: 'net_throttle_off', group: 'nonroot', tag: 'NETWORK',
    on: `settings put global tether_offload_disabled 0\nsettings put global network_recommendations_enabled 0\nsettings put global network_scoring_ui_enabled 0\nsettings put global network_avoid_bad_wifi 0\nsettings put global mobile_data_always_on 1\nsettings put global netstats_enabled 0\nsettings put global network_watchlist_enabled 0\nsettings put global data_saver_mode 0\nsettings put global restrict_background_data 0\nsettings put global background_data_restricted 0\necho "[ok] network throttling disabled"`,
    off: `settings put global tether_offload_disabled 1\nsettings put global network_recommendations_enabled 1\nsettings put global network_scoring_ui_enabled 1\nsettings put global network_avoid_bad_wifi 1\nsettings put global mobile_data_always_on 0\nsettings put global netstats_enabled 1\nsettings put global network_watchlist_enabled 1\nsettings put global data_saver_mode 0\nsettings put global restrict_background_data 1\nsettings put global background_data_restricted 1\necho "[ok] network throttling restored"` },
  { id: 'mobile_data_on', group: 'nonroot', tag: 'NETWORK',
    on: `settings put global mobile_data_always_on 1\nsettings put global mobile_data 1\nsettings put global data_saver_mode 0\nsettings put global mobile_data_always_on_roaming 1\nsettings put global enable_cellular_on_boot 1\nsettings put global cellular_data_enabled 1\nsettings put global mobile_data_enabled 1\nsettings put global prefer_mobile_data 0\nsettings put global data_roaming 1\nsvc data enable 2>/dev/null\necho "[ok] mobile data always active"`,
    off: `settings put global mobile_data_always_on 0\nsettings put global mobile_data_always_on_roaming 0\nsettings put global enable_cellular_on_boot 0\nsettings put global cellular_data_enabled 0\nsettings put global mobile_data_enabled 0\nsettings put global data_roaming 0\nsvc data disable 2>/dev/null\necho "[ok] mobile data restored"` },
  { id: 'logging_off', group: 'nonroot', tag: 'SYSTEM',
    on: `settings put global dropbox_enabled 0\nsettings put global logd_enabled 0\nsettings put global send_action_app_error 0\nsettings put global anr_show_background 0\nsettings put global bug_report_in_power_menu 0\nsettings put global take_bug_report_in_power_menu 0\nsettings put global development_settings_enabled 0\nsettings put global adb_enabled 0\nsettings put global stay_on_while_plugged_in 0\nsettings put global activity_manager_constants max_cached_processes=32\necho "[ok] system logging disabled"`,
    off: `settings put global dropbox_enabled 1\nsettings put global logd_enabled 1\nsettings put global send_action_app_error 1\nsettings put global anr_show_background 1\nsettings put global bug_report_in_power_menu 1\nsettings put global take_bug_report_in_power_menu 1\nsettings put global adb_enabled 1\nsettings put global stay_on_while_plugged_in 0\nsettings delete global activity_manager_constants 2>/dev/null\necho "[ok] system logging restored"` },
  { id: 'refresh_rate_max', group: 'nonroot', tag: 'DISPLAY',
    on: `settings put system peak_refresh_rate 165.0\nsettings put system min_refresh_rate 165.0\nsettings put secure peak_refresh_rate 165.0\nsettings put secure min_refresh_rate 165.0\nsettings put global peak_refresh_rate 165.0\nsettings put global min_refresh_rate 165.0\nsettings put system user_refresh_rate 165\nsettings put secure user_refresh_rate 165\nsettings put global user_refresh_rate 165\nsettings put global display_refresh_rate 165\necho "[ok] display locked at 165hz"`,
    off: `settings put system peak_refresh_rate 60.0\nsettings put system min_refresh_rate 60.0\nsettings put secure peak_refresh_rate 60.0\nsettings put secure min_refresh_rate 60.0\nsettings put global peak_refresh_rate 60.0\nsettings put global min_refresh_rate 60.0\nsettings put system user_refresh_rate 60\nsettings put secure user_refresh_rate 60\nsettings put global user_refresh_rate 60\nsettings put global display_refresh_rate 60\necho "[ok] display reset to 60hz"` },
  { id: 'kill_apps', group: 'nonroot', tag: 'PROCESS',
    on: `am force-stop com.facebook.katana 2>/dev/null\nam force-stop com.facebook.orca 2>/dev/null\nam force-stop com.instagram.android 2>/dev/null\nam force-stop com.whatsapp 2>/dev/null\nam force-stop com.spotify.music 2>/dev/null\nam force-stop com.netflix.mediaclient 2>/dev/null\nam force-stop com.twitter.android 2>/dev/null\nam force-stop com.snapchat.android 2>/dev/null\nam force-stop com.linkedin.android 2>/dev/null\nam force-stop com.amazon.mShop.android.shopping 2>/dev/null\nam kill-all 2>/dev/null\necho "[ok] background apps killed"`,
    off: `monkey -p com.facebook.katana 1 2>/dev/null\nmonkey -p com.facebook.orca 1 2>/dev/null\nmonkey -p com.instagram.android 1 2>/dev/null\nmonkey -p com.whatsapp 1 2>/dev/null\nmonkey -p com.spotify.music 1 2>/dev/null\nmonkey -p com.netflix.mediaclient 1 2>/dev/null\nmonkey -p com.twitter.android 1 2>/dev/null\nmonkey -p com.snapchat.android 1 2>/dev/null\nmonkey -p com.linkedin.android 1 2>/dev/null\nmonkey -p com.amazon.mShop.android.shopping 1 2>/dev/null\necho "[ok] background apps restored"` },
  { id: 'cpu_governor', group: 'root', tag: 'CPU',
    on: `for cpu in /sys/devices/system/cpu/cpu[0-9]*; do\n  gov="$cpu/cpufreq/scaling_governor"\n  [ -f "$gov" ] || continue\n  echo performance > "$gov"\ndone\nfor cpu in /sys/devices/system/cpu/cpu[0-9]*; do\n  max="$cpu/cpufreq/scaling_max_freq"\n  min="$cpu/cpufreq/scaling_min_freq"\n  [ -f "$max" ] || continue\n  cat "$max" > "$min"\ndone\necho 1 > /sys/devices/system/cpu/cpu0/online 2>/dev/null\nsetprop persist.sys.cpu.governor performance\necho "[ok] cpu governor set to performance"`,
    off: `for cpu in /sys/devices/system/cpu/cpu[0-9]*; do\n  gov="$cpu/cpufreq/scaling_governor"\n  [ -f "$gov" ] || continue\n  echo schedutil > "$gov"\ndone\nfor cpu in /sys/devices/system/cpu/cpu[0-9]*; do\n  min="$cpu/cpufreq/scaling_min_freq"\n  [ -f "$min" ] || continue\n  echo 300000 > "$min" 2>/dev/null\ndone\nsetprop persist.sys.cpu.governor schedutil\necho "[ok] cpu governor reset to schedutil"` },
  { id: 'gpu_max_clock', group: 'root', tag: 'GPU',
    on: `GPU=/sys/class/kgsl/kgsl-3d0\n[ -d "$GPU" ] || GPU=/sys/class/devfreq/kgsl-3d0\n[ -d "$GPU" ] || exit 1\nMAX=$(cat $GPU/devfreq/max_freq 2>/dev/null)\n[ -n "$MAX" ] || exit 1\necho "$MAX" > $GPU/devfreq/min_freq\necho "$MAX" > $GPU/devfreq/max_freq\necho performance > $GPU/devfreq/governor\necho 1 > $GPU/force_clk_on 2>/dev/null\necho 1 > $GPU/force_bus_on 2>/dev/null\necho 1 > $GPU/force_rail_on 2>/dev/null\necho 1 > $GPU/force_no_nap 2>/dev/null\nsetprop persist.sys.gpu.governor performance\necho "[ok] gpu locked at $MAX hz"`,
    off: `GPU=/sys/class/kgsl/kgsl-3d0\n[ -d "$GPU" ] || GPU=/sys/class/devfreq/kgsl-3d0\n[ -d "$GPU" ] || exit 1\necho 0 > $GPU/force_clk_on 2>/dev/null\necho 0 > $GPU/force_bus_on 2>/dev/null\necho 0 > $GPU/force_rail_on 2>/dev/null\necho 0 > $GPU/force_no_nap 2>/dev/null\necho msm-adreno-tz > $GPU/devfreq/governor\necho 180000000 > $GPU/devfreq/min_freq 2>/dev/null\nsetprop persist.sys.gpu.governor msm-adreno-tz\necho "[ok] gpu reset to defaults"` },
  { id: 'gpu_governor', group: 'root', tag: 'GPU',
    on: `GPU=/sys/class/kgsl/kgsl-3d0\n[ -d "$GPU" ] || GPU=/sys/class/devfreq/kgsl-3d0\n[ -d "$GPU" ] || exit 1\necho performance > $GPU/devfreq/governor\necho 1 > $GPU/force_clk_on 2>/dev/null\necho 1 > $GPU/force_rail_on 2>/dev/null\necho 1 > $GPU/force_bus_on 2>/dev/null\necho 0 > $GPU/bus_split 2>/dev/null\necho 1 > $GPU/bus_split 2>/dev/null\necho 100 > $GPU/idle_timer 2>/dev/null\necho 0 > $GPU/throttling 2>/dev/null\nsetprop persist.sys.gpu.perf 1\necho "[ok] gpu governor: performance"`,
    off: `GPU=/sys/class/kgsl/kgsl-3d0\n[ -d "$GPU" ] || GPU=/sys/class/devfreq/kgsl-3d0\n[ -d "$GPU" ] || exit 1\necho msm-adreno-tz > $GPU/devfreq/governor\necho 0 > $GPU/force_clk_on 2>/dev/null\necho 0 > $GPU/force_rail_on 2>/dev/null\necho 0 > $GPU/force_bus_on 2>/dev/null\necho 1 > $GPU/throttling 2>/dev/null\necho 64 > $GPU/idle_timer 2>/dev/null\nsetprop persist.sys.gpu.perf 0\necho "[ok] gpu governor reset"` },
  { id: 'thermal_off', group: 'root', tag: 'THERMAL',
    on: `for svc in thermald thermal-engine mi_thermald thermal_hal thermal-monitor; do\n  stop $svc 2>/dev/null\ndone\nfor zone in /sys/class/thermal/thermal_zone*; do\n  [ -d "$zone" ] || continue\n  echo disabled > $zone/mode 2>/dev/null\n  echo 0 > $zone/policy 2>/dev/null\ndone\nsetprop persist.vendor.disable.thermal.control 1\nsetprop persist.sys.thermal.disabled 1\nsetprop persist.vendor.thermal.enabled 0\nsetprop persist.sys.thermal.throttle 0\nsetprop persist.vendor.thermal.throttle 0\necho "[ok] thermal throttling disabled"`,
    off: `for svc in thermald thermal-engine mi_thermald thermal_hal thermal-monitor; do\n  start $svc 2>/dev/null\ndone\nfor zone in /sys/class/thermal/thermal_zone*; do\n  [ -d "$zone" ] || continue\n  echo enabled > $zone/mode 2>/dev/null\n  echo 1 > $zone/policy 2>/dev/null\ndone\nsetprop persist.vendor.disable.thermal.control 0\nsetprop persist.sys.thermal.disabled 0\nsetprop persist.vendor.thermal.enabled 1\nsetprop persist.sys.thermal.throttle 1\nsetprop persist.vendor.thermal.throttle 1\necho "[ok] thermal throttling restored"` },
  { id: 'io_scheduler', group: 'root', tag: 'STORAGE',
    on: `for blk in /sys/block/mmcblk*/queue /sys/block/sd*/queue /sys/block/dm-*/queue /sys/block/nvme*/queue; do\n  [ -d "$blk" ] || continue\n  echo noop > "$blk/scheduler" 2>/dev/null || echo deadline > "$blk/scheduler" 2>/dev/null\n  echo 0 > "$blk/add_random" 2>/dev/null\n  echo 0 > "$blk/iostats" 2>/dev/null\n  echo 2 > "$blk/rq_affinity" 2>/dev/null\n  echo 512 > "$blk/nr_requests" 2>/dev/null\n  echo 1 > "$blk/iosched/slice_idle" 2>/dev/null\n  echo 0 > "$blk/iosched/quantum" 2>/dev/null\n  echo 0 > "$blk/iosched/fifo_batch" 2>/dev/null\ndone\nsetprop persist.sys.io.scheduler noop\necho "[ok] io scheduler tuned"`,
    off: `for blk in /sys/block/mmcblk*/queue /sys/block/sd*/queue /sys/block/dm-*/queue /sys/block/nvme*/queue; do\n  [ -d "$blk" ] || continue\n  echo cfq > "$blk/scheduler" 2>/dev/null || echo bfq > "$blk/scheduler" 2>/dev/null\n  echo 1 > "$blk/add_random" 2>/dev/null\n  echo 1 > "$blk/iostats" 2>/dev/null\n  echo 1 > "$blk/rq_affinity" 2>/dev/null\n  echo 128 > "$blk/nr_requests" 2>/dev/null\ndone\nsetprop persist.sys.io.scheduler cfq\necho "[ok] io scheduler restored"` },
  { id: 'vm_tuning', group: 'root', tag: 'MEMORY',
    on: `echo 0 > /proc/sys/vm/swappiness\necho 100 > /proc/sys/vm/vfs_cache_pressure\necho 3000 > /proc/sys/vm/dirty_writeback_centisecs\necho 500 > /proc/sys/vm/dirty_expire_centisecs\necho 80 > /proc/sys/vm/dirty_ratio\necho 60 > /proc/sys/vm/dirty_background_ratio\necho 1 > /proc/sys/vm/overcommit_memory\necho 262144 > /proc/sys/vm/min_free_kbytes\necho 1 > /proc/sys/vm/oom_kill_allocating_task\necho 0 > /proc/sys/vm/laptop_mode\nsetprop persist.sys.vm.tuned 1\necho "[ok] vm memory tuned"`,
    off: `echo 60 > /proc/sys/vm/swappiness\necho 100 > /proc/sys/vm/vfs_cache_pressure\necho 500 > /proc/sys/vm/dirty_writeback_centisecs\necho 200 > /proc/sys/vm/dirty_expire_centisecs\necho 20 > /proc/sys/vm/dirty_ratio\necho 10 > /proc/sys/vm/dirty_background_ratio\necho 0 > /proc/sys/vm/overcommit_memory\necho 65536 > /proc/sys/vm/min_free_kbytes\necho 0 > /proc/sys/vm/oom_kill_allocating_task\necho 0 > /proc/sys/vm/laptop_mode\nsetprop persist.sys.vm.tuned 0\necho "[ok] vm memory restored"` },
  { id: 'ksm_off', group: 'root', tag: 'MEMORY',
    on: `echo 0 > /sys/kernel/mm/ksm/run\necho 0 > /sys/kernel/mm/ksm/sleep_millisecs\necho 0 > /sys/kernel/mm/ksm/pages_to_scan\necho 1 > /sys/kernel/mm/ksm/merge_across_nodes\necho 0 > /sys/kernel/mm/ksm/use_zero_pages\nsetprop persist.sys.ksm 0\nsetprop ro.config.ksm 0\necho 0 > /sys/module/kernel/parameters/ksm\nsetprop persist.sys.ksm.disabled 1\nsetprop persist.sys.ksm.enabled 0\necho "[ok] ksm disabled"`,
    off: `echo 1 > /sys/kernel/mm/ksm/run\necho 20 > /sys/kernel/mm/ksm/sleep_millisecs\necho 100 > /sys/kernel/mm/ksm/pages_to_scan\necho 1 > /sys/kernel/mm/ksm/merge_across_nodes\necho 1 > /sys/kernel/mm/ksm/use_zero_pages\nsetprop persist.sys.ksm 1\nsetprop ro.config.ksm 1\necho 1 > /sys/module/kernel/parameters/ksm\nsetprop persist.sys.ksm.disabled 0\nsetprop persist.sys.ksm.enabled 1\necho "[ok] ksm restored"` },
  { id: 'tcp_bbr', group: 'root', tag: 'NETWORK',
    on: `sysctl -w net.ipv4.tcp_congestion_control=bbr 2>/dev/null\nsysctl -w net.core.default_qdisc=fq 2>/dev/null\nsysctl -w net.ipv4.tcp_fastopen=3 2>/dev/null\nsysctl -w net.ipv4.tcp_low_latency=1 2>/dev/null\nsysctl -w net.ipv4.tcp_timestamps=0 2>/dev/null\nsysctl -w net.ipv4.tcp_sack=1 2>/dev/null\nsysctl -w net.ipv4.tcp_window_scaling=1 2>/dev/null\nsysctl -w net.core.rmem_max=26214400 2>/dev/null\nsysctl -w net.core.wmem_max=26214400 2>/dev/null\nsysctl -w net.ipv4.tcp_rmem="4096 87380 26214400" 2>/dev/null\nsysctl -w net.ipv4.tcp_wmem="4096 16384 26214400" 2>/dev/null\nsysctl -w net.ipv4.tcp_ecn=1 2>/dev/null\necho "[ok] tcp bbr enabled"`,
    off: `sysctl -w net.ipv4.tcp_congestion_control=cubic 2>/dev/null\nsysctl -w net.core.default_qdisc=pfifo_fast 2>/dev/null\nsysctl -w net.ipv4.tcp_fastopen=1 2>/dev/null\nsysctl -w net.ipv4.tcp_low_latency=0 2>/dev/null\nsysctl -w net.ipv4.tcp_timestamps=1 2>/dev/null\nsysctl -w net.core.rmem_max=2097152 2>/dev/null\nsysctl -w net.core.wmem_max=2097152 2>/dev/null\nsysctl -w net.ipv4.tcp_rmem="4096 87380 6291456" 2>/dev/null\nsysctl -w net.ipv4.tcp_wmem="4096 16384 4194304" 2>/dev/null\nsysctl -w net.ipv4.tcp_ecn=0 2>/dev/null\necho "[ok] tcp restored to cubic"` },
  { id: 'cpu_cores', group: 'root', tag: 'CPU',
    on: `for cpu in /sys/devices/system/cpu/cpu[1-9]*; do\n  online="$cpu/online"\n  [ -f "$online" ] || continue\n  echo 1 > "$online"\ndone\nfor cpu in /sys/devices/system/cpu/cpu[0-9]*; do\n  max="$cpu/cpufreq/scaling_max_freq"\n  [ -f "$max" ] || continue\n  cat "$max" > "$cpu/cpufreq/scaling_min_freq"\ndone\necho 1 > /sys/devices/system/cpu/cpu0/online 2>/dev/null\necho 0 > /sys/module/intel_pstate/parameters/no_turbo 2>/dev/null\nsetprop persist.sys.cores.lock 1\nsetprop persist.sys.cpu.cores.online 1\necho "[ok] cpu cores unlocked"`,
    off: `for cpu in /sys/devices/system/cpu/cpu[0-9]*; do\n  min="$cpu/cpufreq/scaling_min_freq"\n  [ -f "$min" ] || continue\n  echo 300000 > "$min" 2>/dev/null\ndone\nfor cpu in /sys/devices/system/cpu/cpu[1-9]*; do\n  online="$cpu/online"\n  [ -f "$online" ] || continue\n  echo 1 > "$online"\ndone\necho 1 > /sys/module/intel_pstate/parameters/no_turbo 2>/dev/null\nsetprop persist.sys.cores.lock 0\nsetprop persist.sys.cpu.cores.online 0\necho "[ok] cpu cores restored"` },
  { id: 'kernel_tracing_off', group: 'root', tag: 'KERNEL',
    on: `echo 0 > /sys/kernel/debug/tracing/tracing_on 2>/dev/null\necho 0 > /proc/sys/kernel/ftrace_enabled 2>/dev/null\necho 0 > /proc/sys/kernel/perf_event_paranoid 2>/dev/null\necho 0 > /proc/sys/kernel/sched_schedstats 2>/dev/null\necho 0 > /proc/sys/kernel/panic_on_oops 2>/dev/null\necho 0 > /proc/sys/debug/exception-trace 2>/dev/null\necho 0 > /proc/sys/kernel/printk 2>/dev/null\nsetprop debug.mtk.aee.enable 0\nsetprop persist.vendor.enable.tracing 0\nsetprop debug.atrace.tags.enableflags 0\nsetprop persist.debug.tracing 0\nsetprop persist.sys.tracing 0\necho "[ok] kernel tracing disabled"`,
    off: `echo 1 > /sys/kernel/debug/tracing/tracing_on 2>/dev/null\necho 1 > /proc/sys/kernel/ftrace_enabled 2>/dev/null\necho 2 > /proc/sys/kernel/perf_event_paranoid 2>/dev/null\necho 1 > /proc/sys/kernel/sched_schedstats 2>/dev/null\necho 1 > /proc/sys/kernel/panic_on_oops 2>/dev/null\necho 1 > /proc/sys/debug/exception-trace 2>/dev/null\necho "4 4 1 7" > /proc/sys/kernel/printk 2>/dev/null\nsetprop debug.mtk.aee.enable 1\nsetprop persist.vendor.enable.tracing 1\nsetprop persist.debug.tracing 1\nsetprop persist.sys.tracing 1\necho "[ok] kernel tracing restored"` },
  { id: 'zram_off', group: 'root', tag: 'MEMORY',
    on: `swapoff /dev/block/zram0 2>/dev/null\nswapoff /dev/block/zram1 2>/dev/null\nswapoff /dev/block/zram2 2>/dev/null\nswapoff /dev/block/zram3 2>/dev/null\necho 1 > /sys/block/zram0/reset 2>/dev/null\necho 1 > /sys/block/zram1/reset 2>/dev/null\necho 1 > /sys/block/zram2/reset 2>/dev/null\necho 1 > /sys/block/zram3/reset 2>/dev/null\nsetprop persist.sys.zram_enabled 0\nsetprop ro.config.zram 0\necho 0 > /sys/module/zswap/parameters/enabled\necho 0 > /proc/sys/vm/page-cluster\necho "[ok] zram swap disabled"`,
    off: `echo 1 > /sys/module/zswap/parameters/enabled\necho 3 > /proc/sys/vm/page-cluster\nsetprop persist.sys.zram_enabled 1\nsetprop ro.config.zram 1\nswapon /dev/block/zram0 2>/dev/null\nswapon /dev/block/zram1 2>/dev/null\nswapon /dev/block/zram2 2>/dev/null\nswapon /dev/block/zram3 2>/dev/null\necho "[ok] zram swap restored"` },
  { id: 'touch_boost', group: 'root', tag: 'INPUT',
    on: `echo 1 > /sys/module/cpu_boost/parameters/input_boost_enabled 2>/dev/null\necho 1 > /sys/module/cpu_boost/parameters/input_boost_freq 2>/dev/null\necho 1 > /proc/sys/kernel/sched_boost 2>/dev/null\necho 1 > /dev/cpu_boost 2>/dev/null\necho 1 > /sys/kernel/msm_performance/parameters/touchboost 2>/dev/null\necho 1 > /sys/module/msm_performance/parameters/touch_boost 2>/dev/null\necho 1 > /sys/devices/system/cpu/cpu_boost/parameters/input_boost_enabled 2>/dev/null\necho 1 > /sys/module/cpu_boost/parameters/boost_ms 2>/dev/null\necho 500000 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null\nsetprop persist.sys.touchboost 1\nsetprop persist.sys.boost 1\necho "[ok] touch boost enabled"`,
    off: `echo 0 > /sys/module/cpu_boost/parameters/input_boost_enabled 2>/dev/null\necho 0 > /proc/sys/kernel/sched_boost 2>/dev/null\necho 0 > /dev/cpu_boost 2>/dev/null\necho 0 > /sys/kernel/msm_performance/parameters/touchboost 2>/dev/null\necho 0 > /sys/module/msm_performance/parameters/touch_boost 2>/dev/null\necho 0 > /sys/devices/system/cpu/cpu_boost/parameters/input_boost_enabled 2>/dev/null\necho 0 > /sys/module/cpu_boost/parameters/boost_ms 2>/dev/null\necho 0 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null\nsetprop persist.sys.touchboost 0\nsetprop persist.sys.boost 0\necho "[ok] touch boost disabled"` },
  { id: 'cpu_boost', group: 'root', tag: 'CPU',
    on: `echo 1 > /sys/module/cpu_boost/parameters/input_boost_enabled 2>/dev/null\necho 1 > /proc/sys/kernel/sched_boost 2>/dev/null\necho 1 > /sys/module/cpu_boost/parameters/sched_boost_on_input 2>/dev/null\necho 1 > /sys/module/cpu_boost/parameters/boost_ms 2>/dev/null\necho 500000 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null\necho 1 > /dev/stune/top-app/schedtune.boost 2>/dev/null\necho 1 > /dev/stune/foreground/schedtune.boost 2>/dev/null\necho 1 > /dev/stune/top-app/schedtune.prefer_idle 2>/dev/null\necho 1 > /dev/stune/foreground/schedtune.prefer_idle 2>/dev/null\necho 1 > /sys/kernel/sched/features 2>/dev/null\nsetprop persist.sys.cpu.boost 1\nsetprop persist.sys.stune.boost 1\necho "[ok] cpu boost enabled"`,
    off: `echo 0 > /sys/module/cpu_boost/parameters/input_boost_enabled 2>/dev/null\necho 0 > /proc/sys/kernel/sched_boost 2>/dev/null\necho 0 > /sys/module/cpu_boost/parameters/sched_boost_on_input 2>/dev/null\necho 0 > /sys/module/cpu_boost/parameters/boost_ms 2>/dev/null\necho 0 > /sys/module/cpu_boost/parameters/input_boost_ms 2>/dev/null\necho 0 > /dev/stune/top-app/schedtune.boost 2>/dev/null\necho 0 > /dev/stune/foreground/schedtune.boost 2>/dev/null\necho 0 > /dev/stune/top-app/schedtune.prefer_idle 2>/dev/null\necho 0 > /dev/stune/foreground/schedtune.prefer_idle 2>/dev/null\nsetprop persist.sys.cpu.boost 0\nsetprop persist.sys.stune.boost 0\necho "[ok] cpu boost disabled"` },
  { id: 'game_mode', group: 'root', tag: 'GAMING',
    on: `settings put global game_mode 1\nsettings put secure game_mode 1\nsettings put system game_mode 1\nsettings put global game_mode_interruption_policy 1\nsettings put global game_dashboard_enabled 1\nsettings put global game_optimization 1\nsettings put global game_priority_mode 1\nsettings put global focus_mode 1\nsettings put global zen_mode 1\nsetprop persist.sys.game_mode 1\nsetprop persist.sys.game.optimize 1\nsetprop persist.sys.game.boost 1\nsetprop persist.vendor.game.mode 1\necho "[ok] game mode enabled"`,
    off: `settings put global game_mode 0\nsettings put secure game_mode 0\nsettings put system game_mode 0\nsettings put global game_mode_interruption_policy 0\nsettings put global game_dashboard_enabled 0\nsettings put global game_optimization 0\nsettings put global game_priority_mode 0\nsettings put global focus_mode 0\nsettings put global zen_mode 0\nsetprop persist.sys.game_mode 0\nsetprop persist.sys.game.optimize 0\nsetprop persist.sys.game.boost 0\nsetprop persist.vendor.game.mode 0\necho "[ok] game mode disabled"` },
  { id: 'wifi_power_off', group: 'root', tag: 'NETWORK',
    on: `settings put global wifi_power_save 0\nsettings put global wifi_sleep_policy 2\nsettings put global wifi_scan_always_enabled 0\nsettings put global wifi_wakeup_enabled 1\nsettings put global wifi_networks_available_notification_on 1\nsvc wifi disable 2>/dev/null\nsleep 1\nsvc wifi enable 2>/dev/null\niw dev wlan0 set power_save off 2>/dev/null\necho 0 > /sys/module/wlan/parameters/fw_power_save 2>/dev/null\nsetprop persist.sys.wifi.power_save 0\nsetprop persist.sys.wifi.full 1\necho "[ok] wifi power save disabled"`,
    off: `settings put global wifi_power_save 1\nsettings put global wifi_sleep_policy 0\nsettings put global wifi_scan_always_enabled 1\nsettings put global wifi_wakeup_enabled 0\nsvc wifi disable 2>/dev/null\nsleep 1\nsvc wifi enable 2>/dev/null\niw dev wlan0 set power_save on 2>/dev/null\necho 1 > /sys/module/wlan/parameters/fw_power_save 2>/dev/null\nsetprop persist.sys.wifi.power_save 1\nsetprop persist.sys.wifi.full 0\necho "[ok] wifi power save restored"` }
];

const STORAGE_KEY = 'redmagic.console.v4';
const MAX_LOGS = 40;

const state = new Set();
const logHistory = [];
const memoryStore = {};
let currentLang = 'en';
let storage = null;
const dom = {};

function detectStorage() {
  const key = '__rm_test_' + Date.now();
  try {
    const ls = window.localStorage;
    ls.setItem(key, '1');
    ls.removeItem(key);
    return ls;
  } catch (e) {}
  try {
    const ss = window.sessionStorage;
    ss.setItem(key, '1');
    ss.removeItem(key);
    return ss;
  } catch (e) {}
  return null;
}

function readSaved() {
  let raw = null;
  if (storage) {
    try { raw = storage.getItem(STORAGE_KEY); } catch (e) { storage = null; }
  }
  if (!raw && memoryStore[STORAGE_KEY]) raw = memoryStore[STORAGE_KEY];
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (e) { return null; }
}

function writeSaved(payload) {
  let raw;
  try { raw = JSON.stringify(payload); } catch (e) { return; }
  memoryStore[STORAGE_KEY] = raw;
  if (storage) {
    try { storage.setItem(STORAGE_KEY, raw); } catch (e) { storage = null; }
  }
}

function saveState() {
  writeSaved({
    modules: Array.from(state),
    lang: currentLang,
    logs: logHistory.slice(-MAX_LOGS)
  });
}

function restoreState() {
  const saved = readSaved();
  if (!saved || typeof saved !== 'object') return;
  if (Array.isArray(saved.modules)) {
    saved.modules.forEach(function(id) {
      const exists = MODULES.some(function(m) { return m.id === id; });
      if (exists) state.add(id);
    });
  }
  if (typeof saved.lang === 'string' && I18N[saved.lang]) {
    currentLang = saved.lang;
    document.documentElement.lang = saved.lang === 'fil' ? 'tl' : saved.lang;
  }
  if (Array.isArray(saved.logs)) {
    saved.logs.forEach(function(entry) {
      if (entry && entry.moduleId && entry.type && entry.time) {
        logHistory.push(entry);
      }
    });
  }
}

function cacheDom() {
  const ids = [
    'nonrootGrid', 'rootGrid', 'nonrootCount', 'rootCount', 'activeCount',
    'footerStatus', 'consoleOutput', 'consoleTitle', 'consoleTag', 'consolePrompt',
    'brandSub', 'tabNonRoot', 'tabRoot', 'tagSystem', 'tagRoot',
    'titleNonRoot', 'titleRoot', 'labelModules1', 'labelModules2',
    'footWarn1', 'footWarn2', 'settingsBtnLabel', 'settingsBtn',
    'settingsModal', 'settingsBackdrop', 'settingsClose', 'modalTitle',
    'modalLangTag', 'modalFootText', 'langGrid', 'topbarLabel'
  ];
  ids.forEach(function(id) {
    const el = document.getElementById(id);
    if (el) dom[id] = el;
  });
  dom.bannerImg = document.querySelector('.rm-banner-img');
  dom.bannerFallback = document.querySelector('.rm-banner-fallback');
}

function t(key) {
  const ui = I18N[currentLang] && I18N[currentLang].ui;
  return (ui && ui[key]) || key;
}

function tTag(tag) {
  const tags = I18N[currentLang] && I18N[currentLang].tags;
  return (tags && tags[tag]) || tag;
}

function tModule(id, field) {
  const mods = I18N[currentLang] && I18N[currentLang].modules;
  const m = mods && mods[id];
  return (m && m[field]) || id;
}

function timeStamp() {
  const d = new Date();
  const p = function(n) { return n < 10 ? '0' + n : '' + n; };
  return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

function buildCard(mod) {
  const card = document.createElement('div');
  card.className = 'rm-card';
  card.setAttribute('data-id', mod.id);
  if (state.has(mod.id)) card.classList.add('is-active');

  const body = document.createElement('div');
  body.className = 'rm-card-body';

  const tagEl = document.createElement('div');
  tagEl.className = 'rm-card-tag';
  tagEl.textContent = tTag(mod.tag);

  const titleEl = document.createElement('div');
  titleEl.className = 'rm-card-title';
  titleEl.textContent = tModule(mod.id, 'title');

  const descEl = document.createElement('div');
  descEl.className = 'rm-card-desc';
  descEl.textContent = tModule(mod.id, 'desc');

  body.appendChild(tagEl);
  body.appendChild(titleEl);
  body.appendChild(descEl);

  const sw = document.createElement('label');
  sw.className = 'rm-switch';

  const input = document.createElement('input');
  input.type = 'checkbox';
  input.setAttribute('data-id', mod.id);
  input.checked = state.has(mod.id);

  const track = document.createElement('span');
  track.className = 'rm-switch-track';

  const thumb = document.createElement('span');
  thumb.className = 'rm-switch-thumb';

  const lOn = document.createElement('span');
  lOn.className = 'rm-switch-label label-on';
  lOn.textContent = 'ON';

  const lOff = document.createElement('span');
  lOff.className = 'rm-switch-label label-off';
  lOff.textContent = 'OFF';

  track.appendChild(thumb);
  track.appendChild(lOn);
  track.appendChild(lOff);

  sw.appendChild(input);
  sw.appendChild(track);

  card.appendChild(body);
  card.appendChild(sw);

  return card;
}

function renderCards() {
  dom.nonrootGrid.innerHTML = '';
  dom.rootGrid.innerHTML = '';
  let nr = 0;
  let r = 0;
  MODULES.forEach(function(mod) {
    const card = buildCard(mod);
    if (mod.group === 'nonroot') {
      dom.nonrootGrid.appendChild(card);
      nr++;
    } else {
      dom.rootGrid.appendChild(card);
      r++;
    }
  });
  dom.nonrootCount.textContent = nr;
  dom.rootCount.textContent = r;
}

function renderUiText() {
  if (dom.brandSub) dom.brandSub.textContent = t('brandSub');
  if (dom.topbarLabel) dom.topbarLabel.textContent = t('topbarLabel');
  if (dom.tabNonRoot) dom.tabNonRoot.textContent = t('tabNonRoot');
  if (dom.tabRoot) dom.tabRoot.textContent = t('tabRoot');
  if (dom.tagSystem) dom.tagSystem.textContent = t('tagSystem');
  if (dom.tagRoot) dom.tagRoot.textContent = t('tagRoot');
  if (dom.titleNonRoot) dom.titleNonRoot.textContent = t('titleNonRoot');
  if (dom.titleRoot) dom.titleRoot.textContent = t('titleRoot');
  if (dom.labelModules1) dom.labelModules1.textContent = t('modules');
  if (dom.labelModules2) dom.labelModules2.textContent = t('modules');
  if (dom.footWarn1) dom.footWarn1.textContent = t('warn1');
  if (dom.footWarn2) dom.footWarn2.textContent = t('warn2');
  if (dom.settingsBtnLabel) dom.settingsBtnLabel.textContent = t('settings');
  if (dom.modalTitle) dom.modalTitle.textContent = t('modalTitle');
  if (dom.modalLangTag) dom.modalLangTag.textContent = t('modalLangTag');
  if (dom.modalFootText) dom.modalFootText.textContent = t('modalFoot');
}

function updateStatus() {
  const n = state.size;
  if (dom.activeCount) {
    dom.activeCount.textContent = n + ' ' + t('online');
    dom.activeCount.classList.toggle('is-active', n > 0);
  }
  if (dom.footerStatus) {
    dom.footerStatus.textContent = n > 0 ? n + ' ' + t('active') : t('ready');
  }
}

function buildLogEntry(entry) {
  const mod = MODULES.find(function(m) { return m.id === entry.moduleId; });
  if (!mod) return null;
  const isRoot = mod.group === 'root';
  const isOn = entry.type === 'apply';

  const wrap = document.createElement('div');
  wrap.className = 'log-entry';

  const row1 = document.createElement('div');
  row1.className = 'log-row';

  const time1 = document.createElement('span');
  time1.className = 'log-time';
  time1.textContent = '[' + entry.time + ']';

  const prompt1 = document.createElement('span');
  prompt1.className = 'log-prompt' + (isRoot ? '' : ' is-user');
  prompt1.textContent = isRoot ? '#' : '$';

  const label1 = document.createElement('span');
  label1.className = 'log-label' + (isRoot ? '' : ' is-user');
  label1.textContent = isOn ? t('apply') : t('reset');

  const text1 = document.createElement('span');
  text1.className = 'log-text';
  text1.textContent = '\u203A ' + tModule(mod.id, 'title');

  row1.appendChild(time1);
  row1.appendChild(prompt1);
  row1.appendChild(label1);
  row1.appendChild(text1);

  const row2 = document.createElement('div');
  row2.className = 'log-result' + (isOn ? '' : ' is-reset');
  row2.textContent = isOn ? t('applied') : t('resetOk');

  wrap.appendChild(row1);
  wrap.appendChild(row2);

  return wrap;
}

function renderConsole() {
  if (!dom.consoleOutput) return;
  dom.consoleOutput.innerHTML = '';

  if (logHistory.length === 0) {
    const idle = document.createElement('div');
    idle.className = 'rm-console-idle';

    const l1 = document.createElement('div');
    l1.className = 'rm-idle-line';
    const p1 = document.createElement('span');
    p1.className = 'rm-idle-prompt';
    p1.textContent = '$';
    l1.appendChild(p1);
    l1.appendChild(document.createTextNode(' ' + t('idle1')));

    const l2 = document.createElement('div');
    l2.className = 'rm-idle-line';
    const p2 = document.createElement('span');
    p2.className = 'rm-idle-prompt';
    p2.textContent = '$';
    l2.appendChild(p2);
    l2.appendChild(document.createTextNode(' ' + t('idle2')));

    idle.appendChild(l1);
    idle.appendChild(l2);
    dom.consoleOutput.appendChild(idle);
    return;
  }

  logHistory.forEach(function(entry) {
    const el = buildLogEntry(entry);
    if (el) dom.consoleOutput.appendChild(el);
  });

  dom.consoleOutput.scrollTop = dom.consoleOutput.scrollHeight;
}

function setConsolePromptFromEntry(entry) {
  if (!dom.consoleTitle) return;
  if (!entry) {
    dom.consoleTitle.textContent = 'redmagic:~$';
    dom.consoleTitle.classList.remove('is-root');
    dom.consoleTag.textContent = t('user');
    dom.consoleTag.classList.add('is-user');
    dom.consolePrompt.textContent = '$';
    dom.consolePrompt.classList.add('is-user');
    return;
  }
  const mod = MODULES.find(function(m) { return m.id === entry.moduleId; });
  if (!mod) return;
  const isRoot = mod.group === 'root';
  dom.consoleTitle.textContent = isRoot ? 'root@redmagic:~#' : 'redmagic:~$';
  dom.consoleTitle.classList.toggle('is-root', isRoot);
  dom.consoleTag.textContent = isRoot ? t('root') : t('user');
  dom.consoleTag.classList.toggle('is-user', !isRoot);
  dom.consolePrompt.textContent = isRoot ? '#' : '$';
  dom.consolePrompt.classList.toggle('is-user', !isRoot);
}

function triggerSwitchAnimation(switchEl, on) {
  switchEl.classList.remove('anim-on', 'anim-off');
  void switchEl.offsetWidth;
  switchEl.classList.add(on ? 'anim-on' : 'anim-off');
  window.setTimeout(function() {
    switchEl.classList.remove('anim-on', 'anim-off');
  }, 700);
}

function handleChange(event) {
  const target = event.target;
  if (!target) return;
  if (target.type !== 'checkbox') return;
  const id = target.getAttribute('data-id');
  if (!id) return;
  const mod = MODULES.find(function(m) { return m.id === id; });
  if (!mod) return;

  const card = target.closest('.rm-card');
  const switchEl = target.closest('.rm-switch');
  const on = target.checked;

  if (on) state.add(id);
  else state.delete(id);

  if (card) card.classList.toggle('is-active', on);
  if (switchEl) triggerSwitchAnimation(switchEl, on);

  const entry = {
    moduleId: id,
    type: on ? 'apply' : 'reset',
    time: timeStamp()
  };
  logHistory.push(entry);
  while (logHistory.length > MAX_LOGS) logHistory.shift();

  setConsolePromptFromEntry(entry);
  renderConsole();
  updateStatus();
  saveState();
}

function initTabs() {
  const tabs = document.querySelectorAll('.rm-tab');
  const panes = document.querySelectorAll('.rm-tab-pane');
  Array.prototype.forEach.call(tabs, function(tab) {
    tab.addEventListener('click', function() {
      Array.prototype.forEach.call(tabs, function(x) { x.classList.remove('is-active'); });
      Array.prototype.forEach.call(panes, function(p) { p.classList.remove('is-active'); });
      tab.classList.add('is-active');
      const target = document.getElementById(tab.getAttribute('data-target') + 'Pane');
      if (target) target.classList.add('is-active');
    });
  });
}

function buildLangGrid() {
  if (!dom.langGrid) return;
  dom.langGrid.innerHTML = '';
  const codes = ['en', 'id', 'ja', 'fil'];
  codes.forEach(function(code) {
    const info = I18N[code];
    if (!info) return;
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'rm-lang-option' + (code === currentLang ? ' is-selected' : '');
    btn.setAttribute('data-lang', code);

    const codeEl = document.createElement('div');
    codeEl.className = 'rm-lang-code';
    codeEl.textContent = info.lang;

    const nameEl = document.createElement('div');
    nameEl.className = 'rm-lang-name';
    nameEl.textContent = info.langName;

    const flagEl = document.createElement('div');
    flagEl.className = 'rm-lang-flag';
    flagEl.textContent = '/ ' + code.toUpperCase() + ' /';

    btn.appendChild(codeEl);
    btn.appendChild(nameEl);
    btn.appendChild(flagEl);

    btn.addEventListener('click', function() { setLanguage(code); });
    dom.langGrid.appendChild(btn);
  });
}

function setLanguage(code) {
  if (!I18N[code] || code === currentLang) return;
  currentLang = code;
  document.documentElement.lang = code === 'fil' ? 'tl' : code;
  renderUiText();
  renderCards();
  buildLangGrid();
  updateStatus();
  const last = logHistory.length > 0 ? logHistory[logHistory.length - 1] : null;
  setConsolePromptFromEntry(last);
  renderConsole();
  saveState();
  closeSettings();
}

function openSettings() {
  if (dom.settingsModal) dom.settingsModal.classList.add('is-open');
}

function closeSettings() {
  if (dom.settingsModal) dom.settingsModal.classList.remove('is-open');
}

function initBanner() {
  if (!dom.bannerImg) return;
  const hideFallback = function() {
    if (dom.bannerFallback) dom.bannerFallback.style.display = 'none';
  };
  if (dom.bannerImg.complete && dom.bannerImg.naturalWidth > 0) {
    hideFallback();
  } else {
    dom.bannerImg.addEventListener('load', hideFallback);
  }
  dom.bannerImg.addEventListener('error', function() {
    dom.bannerImg.style.display = 'none';
  });
}

function init() {
  storage = detectStorage();
  cacheDom();
  restoreState();
  renderUiText();
  renderCards();
  initTabs();
  buildLangGrid();
  updateStatus();
  const last = logHistory.length > 0 ? logHistory[logHistory.length - 1] : null;
  setConsolePromptFromEntry(last);
  renderConsole();
  initBanner();

  if (dom.nonrootGrid) dom.nonrootGrid.addEventListener('change', handleChange);
  if (dom.rootGrid) dom.rootGrid.addEventListener('change', handleChange);

  if (dom.settingsBtn) dom.settingsBtn.addEventListener('click', openSettings);
  if (dom.settingsClose) dom.settingsClose.addEventListener('click', closeSettings);
  if (dom.settingsBackdrop) dom.settingsBackdrop.addEventListener('click', closeSettings);

  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeSettings();
  });

  window.addEventListener('beforeunload', saveState);
  window.addEventListener('pagehide', saveState);
  document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'hidden') saveState();
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}