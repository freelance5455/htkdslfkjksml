// ============================================================
// 视口高度锁定：--app-height 与键盘检测
// 在脚本最早处执行，避免 CSS 解析时缺少变量
// ============================================================
(function initViewportHeight() {
    const docEl = document.documentElement;
    let lockedHeight = window.innerHeight;
    let lastWidth = window.innerWidth;

    function setAppHeight(h) {
        docEl.style.setProperty('--app-height', Math.round(h) + 'px');
    }

    setAppHeight(lockedHeight);

    function update() {
        const vp = window.visualViewport;
        const w = vp ? vp.width : window.innerWidth;
        const h = vp ? vp.height : window.innerHeight;

        const widthChanged = Math.abs(w - lastWidth) > 30;
        const heightShrunk = h < lockedHeight - 120;

        if (widthChanged) {
            // 屏幕旋转：重新锁定高度
            lastWidth = w;
            lockedHeight = h;
            docEl.classList.remove('keyboard-open');
            setAppHeight(lockedHeight);
        } else if (heightShrunk) {
            // 键盘弹出：锁定高度、标记状态
            docEl.classList.add('keyboard-open');
        } else {
            // 正常状态
            lockedHeight = h;
            docEl.classList.remove('keyboard-open');
            setAppHeight(lockedHeight);
        }
    }

    if (window.visualViewport) {
        window.visualViewport.addEventListener('resize', update);
    }
    window.addEventListener('resize', update);
    window.addEventListener('orientationchange', () => {
        setTimeout(() => {
            lastWidth = window.innerWidth;
            lockedHeight = window.visualViewport ? window.visualViewport.height : window.innerHeight;
            docEl.classList.remove('keyboard-open');
            setAppHeight(lockedHeight);
        }, 150);
    });
})();


// ============================================================
// 液态玻璃 WebGL 渲染引擎（仅渲染导航栏）
// ============================================================
window.LensFX = (function () {
    const canvas = document.getElementById('lens-canvas');
    const stub = {
        refresh() {}, setGradientTheme() {}, setGlassColor() {},
        setIndParams() {}, setPressing() {}, setPinchAmount() {},
        setBlur() {}, setSaturation() {}, setAnimate() {}, regenerateBackground() {}
    };
    if (!canvas) return stub;

    let gl;
    try {
        gl = canvas.getContext('webgl', { premultipliedAlpha: false, alpha: true })
            || canvas.getContext('experimental-webgl');
    } catch (e) { gl = null; }
    if (!gl) return stub;

    const MAXR = 4;
    const VS = `attribute vec2 aPos; void main(){ gl_Position = vec4(aPos, 0.0, 1.0); }`;
    const FS = `
        precision highp float;
        uniform sampler2D uBg;
        uniform vec2  uRes;
        uniform vec2  uTexScale;
        uniform vec2  uTexOffset;
        uniform int   uCount;
        uniform vec4  uRects[${MAXR}];
        uniform float uRadii[${MAXR}];
        uniform float uTypes[${MAXR}];
        uniform vec4  uGlassColor;
        uniform vec3  uIndParams;
        uniform float uPressing;
        uniform float uPinchAmount;
        uniform float uBlur;
        uniform float uSaturation;

        float sdRound(vec2 p, vec2 b, float r){
            vec2 q = abs(p) - b + r;
            return min(max(q.x,q.y),0.0) + length(max(q,0.0)) - r;
        }
        vec3 getSliderInfo() {
            for (int i = 0; i < ${MAXR}; i++) {
                if (i >= uCount) break;
                if (uTypes[i] > 0.5 && uTypes[i] < 1.5) {
                    return vec3(uRects[i].x + uRects[i].z * 0.5, uRects[i].z * 0.5, 1.0);
                }
            }
            return vec3(0.0, 0.0, 0.0);
        }
        vec2 navHalfSize(vec2 hf, float sliderCenterX, float sliderHalfW, float x) {
            if (uPressing > 0.5 && sliderHalfW > 0.0) {
                float distToSlider = abs(x - sliderCenterX);
                float pinchRange = sliderHalfW + 20.0;
                float pinch = (1.0 - smoothstep(sliderHalfW * 0.2, pinchRange, distToSlider)) * uPinchAmount;
                hf.y = max(8.0, hf.y - pinch);
            }
            return hf;
        }
        vec3 sampleBgBlur(vec2 uv, float blurPx) {
            if (blurPx < 0.5) return texture2D(uBg, clamp(uv, 0.0, 1.0)).rgb;
            vec2 texel = (blurPx / uRes) * uTexScale;
            vec3 sum = vec3(0.0);
            float wsum = 0.0;
            sum += texture2D(uBg, clamp(uv, 0.0, 1.0)).rgb * 4.0; wsum += 4.0;
            sum += texture2D(uBg, clamp(uv + vec2( texel.x, 0.0), 0.0, 1.0)).rgb * 2.0; wsum += 2.0;
            sum += texture2D(uBg, clamp(uv + vec2(-texel.x, 0.0), 0.0, 1.0)).rgb * 2.0; wsum += 2.0;
            sum += texture2D(uBg, clamp(uv + vec2( 0.0,  texel.y), 0.0, 1.0)).rgb * 2.0; wsum += 2.0;
            sum += texture2D(uBg, clamp(uv + vec2( 0.0, -texel.y), 0.0, 1.0)).rgb * 2.0; wsum += 2.0;
            vec2 dg = texel * 0.7071;
            sum += texture2D(uBg, clamp(uv + vec2( dg.x,  dg.y), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2(-dg.x,  dg.y), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2( dg.x, -dg.y), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2(-dg.x, -dg.y), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2( texel.x * 2.0, 0.0), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2(-texel.x * 2.0, 0.0), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2( 0.0,  texel.y * 2.0), 0.0, 1.0)).rgb; wsum += 1.0;
            sum += texture2D(uBg, clamp(uv + vec2( 0.0, -texel.y * 2.0), 0.0, 1.0)).rgb; wsum += 1.0;
            return sum / wsum;
        }
        vec3 applySaturation(vec3 c, float s) {
            float l = dot(c, vec3(0.2126, 0.7152, 0.0722));
            return mix(vec3(l), c, s);
        }
        vec3 getSceneColor(vec2 fragPos) {
            vec2 uv = clamp((fragPos / uRes) * uTexScale + uTexOffset, 0.0, 1.0);
            vec3 col = texture2D(uBg, uv).rgb;
            vec3 sliderInfo = getSliderInfo();
            for (int i = 0; i < ${MAXR}; i++) {
                if (i >= uCount) break;
                bool isNav = (uTypes[i] > 1.5 && uTypes[i] < 2.5);
                if (isNav && uPressing < 0.5) continue;

                if (isNav) {
                    vec4 R = uRects[i];
                    vec2 c = R.xy + R.zw * 0.5;
                    vec2 hf = R.zw * 0.5;
                    hf = navHalfSize(hf, sliderInfo.x, sliderInfo.y, fragPos.x);
                    float sd = sdRound(fragPos - c, hf, uRadii[i]);
                    if (sd < 0.0) {
                        if (uBlur > 0.5) {
                            col = applySaturation(sampleBgBlur(uv, uBlur), uSaturation);
                        }
                        col = mix(col, uGlassColor.rgb, uGlassColor.a * 0.85);
                        float edgeAlpha = smoothstep(-2.0, 0.0, sd);
                        col = mix(col, vec3(1.0), edgeAlpha * 0.15);
                    }
                }
            }
            return col;
        }
        void main(){
            vec2 frag = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y);
            vec2 dispVector = vec2(0.0);
            float currentDispersion = 0.0;
            bool insideAny = false;
            vec3 sliderInfo = getSliderInfo();
            for (int i=0; i<${MAXR}; i++){
                if (i >= uCount) break;
                vec4 R = uRects[i];
                bool isNav = (uTypes[i] > 1.5 && uTypes[i] < 2.5);
                if (isNav && uPressing < 0.5) continue;

                vec2 c = R.xy + R.zw*0.5;
                vec2 hf = R.zw*0.5;
                if (isNav) {
                    hf = navHalfSize(hf, sliderInfo.x, sliderInfo.y, frag.x);
                }
                vec2 lp = frag - c;
                float sd = sdRound(lp, hf, uRadii[i]);
                if (sd >= 0.0) continue;
                insideAny = true;
                bool isInd = (uTypes[i] > 0.5 && uTypes[i] < 1.5);
                float strength = uIndParams.x;
                float edge     = uIndParams.y;
                float dispVal  = uIndParams.z;
                float edgeDist = -sd;
                vec2 nrm = lp / hf;
                float p = 5.0;
                vec2 grad = vec2(sign(nrm.x) * pow(abs(nrm.x) + 1e-4, p-1.0), sign(nrm.y) * pow(abs(nrm.y) + 1e-4, p-1.0));
                vec2 outDir = normalize(grad + vec2(1e-6));
                if (edgeDist < edge) {
                    float t = edgeDist / edge;
                    float disp_t = (1.0 - t) * (1.0 - t) * (3.0 - 2.0*(1.0 - t));
                    dispVector = -outDir * disp_t * strength;
                    currentDispersion = dispVal;
                }
            }
            if (!insideAny) {
                gl_FragColor = vec4(getSceneColor(frag), 1.0);
                return;
            }
            vec2 baseFrag = frag + dispVector;
            vec2 offsetDir = length(dispVector) > 0.001 ? normalize(dispVector) : vec2(1.0, 0.0);
            float r = getSceneColor(baseFrag - offsetDir * currentDispersion).r;
            float g = getSceneColor(baseFrag).g;
            float b = getSceneColor(baseFrag + offsetDir * currentDispersion).b;
            gl_FragColor = vec4(r, g, b, 1.0);
        }
    `;

    function compile(type, src) {
        const sh = gl.createShader(type);
        gl.shaderSource(sh, src);
        gl.compileShader(sh);
        return sh;
    }

    const prog = gl.createProgram();
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, VS));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(prog);
    gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const aPos = gl.getAttribLocation(prog, 'aPos');
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

    const U = {
        bg: gl.getUniformLocation(prog, 'uBg'),
        res: gl.getUniformLocation(prog, 'uRes'),
        texScale: gl.getUniformLocation(prog, 'uTexScale'),
        texOffset: gl.getUniformLocation(prog, 'uTexOffset'),
        count: gl.getUniformLocation(prog, 'uCount'),
        rects: gl.getUniformLocation(prog, 'uRects'),
        radii: gl.getUniformLocation(prog, 'uRadii'),
        types: gl.getUniformLocation(prog, 'uTypes'),
        glassColor: gl.getUniformLocation(prog, 'uGlassColor'),
        indParams: gl.getUniformLocation(prog, 'uIndParams'),
        pressing: gl.getUniformLocation(prog, 'uPressing'),
        pinchAmount: gl.getUniformLocation(prog, 'uPinchAmount'),
        blur: gl.getUniformLocation(prog, 'uBlur'),
        saturation: gl.getUniformLocation(prog, 'uSaturation')
    };

    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

    let imgW = 1, imgH = 1, hasImg = false;
    let indParams = { strength: 2, edge: 24, dispersion: 3 };
    let glassColor = [0.086, 0.129, 0.243, 0.72];
    let isPressing = false;
    let pinchAmount = 4;
    let currentBlur = 22;
    let currentSat = 180;

    let bgSeed = Math.floor(Math.random() * 1000000);
    let bgIsDark = (document.documentElement.getAttribute('data-theme') || 'dark') === 'dark';

    let animateEnabled = false;
    let animateRafId = null;
    let animateStart = 0;
    let animateLastUpdate = 0;

    function makeRand(seed) {
        let s = seed;
        return function () {
            s = (s * 9301 + 49297) % 233280;
            return s / 233280;
        };
    }

    function generateBackground(isDark, timeMs) {
        const c = document.createElement('canvas');
        c.width = 1024;
        c.height = 1024;
        const ctx = c.getContext('2d');
        const rand = makeRand(bgSeed);

        const t = animateEnabled ? (timeMs - animateStart) / 1000 : 0;

        const baseHue = rand() * 360;
        const grad = ctx.createLinearGradient(0, 0, 1024, 1024);
        if (isDark) {
            const sat = 30 + rand() * 25;
            const h2 = (baseHue + 25 + rand() * 30) % 360;
            const h3 = (baseHue + 60 + rand() * 40) % 360;
            const h4 = (baseHue + 110 + rand() * 50) % 360;
            grad.addColorStop(0, `hsl(${baseHue}, ${sat}%, ${5 + rand() * 5}%)`);
            grad.addColorStop(0.35, `hsl(${h2}, ${sat + 5}%, ${9 + rand() * 5}%)`);
            grad.addColorStop(0.7, `hsl(${h3}, ${sat + 5}%, ${11 + rand() * 5}%)`);
            grad.addColorStop(1, `hsl(${h4}, ${sat}%, ${6 + rand() * 4}%)`);
        } else {
            const sat = 55 + rand() * 25;
            const h2 = (baseHue + 25 + rand() * 30) % 360;
            const h3 = (baseHue + 60 + rand() * 40) % 360;
            const h4 = (baseHue + 110 + rand() * 50) % 360;
            grad.addColorStop(0, `hsl(${baseHue}, ${sat}%, ${93 - rand() * 4}%)`);
            grad.addColorStop(0.35, `hsl(${h2}, ${sat - 5}%, ${89 - rand() * 4}%)`);
            grad.addColorStop(0.7, `hsl(${h3}, ${sat - 5}%, ${91 - rand() * 4}%)`);
            grad.addColorStop(1, `hsl(${h4}, ${sat}%, ${86 - rand() * 4}%)`);
        }
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 1024, 1024);

        const spotCount = 3 + Math.floor(rand() * 2);
        for (let i = 0; i < spotCount; i++) {
            const x = rand() * 1024;
            const y = rand() * 1024;
            const r = 320 + rand() * 420;
            const hue = (baseHue + rand() * 140 - 70 + 360) % 360;
            const light = isDark ? (10 + rand() * 15) : (86 + rand() * 10);
            const alpha = isDark ? (0.30 + rand() * 0.20) : (0.30 + rand() * 0.25);
            const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
            rg.addColorStop(0, `hsla(${hue}, 55%, ${light}%, ${alpha})`);
            rg.addColorStop(1, `hsla(${hue}, 55%, ${light}%, 0)`);
            ctx.fillStyle = rg;
            ctx.fillRect(0, 0, 1024, 1024);
        }

        const lineCount = 6 + Math.floor(rand() * 6);
        const lines = [];
        for (let i = 0; i < lineCount; i++) {
            lines.push({
                x1: rand() * 1024,
                y1: rand() * 1024,
                x2: rand() * 1024,
                y2: rand() * 1024,
                hue: (baseHue + rand() * 100 - 50 + 360) % 360,
                width: 0.6 + rand() * 1.6,
                alpha: 0.35 + rand() * 0.45
            });
        }
        lines.forEach(line => {
            const light = isDark ? (45 + rand() * 20) : (35 + rand() * 15);
            ctx.beginPath();
            ctx.moveTo(line.x1, line.y1);
            ctx.lineTo(line.x2, line.y2);
            ctx.strokeStyle = `hsla(${line.hue}, 60%, ${light}%, ${line.alpha})`;
            ctx.lineWidth = line.width;
            ctx.stroke();
        });

        const circleCount = 8 + Math.floor(rand() * 7);
        const circles = [];
        for (let i = 0; i < circleCount; i++) {
            circles.push({
                x: rand() * 1024,
                y: rand() * 1024,
                r: 60 + rand() * 440,
                hue: (baseHue + rand() * 130 - 65 + 360) % 360,
                phase: rand() * Math.PI * 2,
                satOffset: rand() * 20 - 10,
                lightOffset: rand() * 12 - 6
            });
        }
        circles.forEach(circle => {
            const pulse = animateEnabled ? (1 + 0.08 * Math.sin(t + circle.phase)) : 1;
            const r = circle.r * pulse;
            const centerLight = isDark
                ? (28 + circle.lightOffset + (animateEnabled ? 4 * Math.sin(t * 1.3 + circle.phase) : 0))
                : (70 + circle.lightOffset + (animateEnabled ? 4 * Math.sin(t * 1.3 + circle.phase) : 0));
            const edgeLight = isDark
                ? (8 + circle.lightOffset * 0.4)
                : (90 + circle.lightOffset * 0.4);
            const sat = 55 + circle.satOffset;

            const rg = ctx.createRadialGradient(circle.x, circle.y, 0, circle.x, circle.y, r);
            rg.addColorStop(0, `hsla(${circle.hue}, ${sat}%, ${centerLight}%, 0.65)`);
            rg.addColorStop(0.55, `hsla(${circle.hue}, ${sat}%, ${centerLight - 4}%, 0.42)`);
            rg.addColorStop(0.92, `hsla(${circle.hue}, ${sat}%, ${(centerLight + edgeLight) / 2}%, 0.32)`);
            rg.addColorStop(1, `hsla(${circle.hue}, ${sat}%, ${edgeLight}%, 0.05)`);
            ctx.fillStyle = rg;
            ctx.beginPath();
            ctx.arc(circle.x, circle.y, r, 0, Math.PI * 2);
            ctx.fill();
        });

        return c;
    }

    function uploadBackgroundCanvas(c) {
        imgW = c.width;
        imgH = c.height;
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
        hasImg = true;
    }

    function regenerateBackground() {
        bgSeed = Math.floor(Math.random() * 1000000);
        const c = generateBackground(bgIsDark, performance.now());
        uploadBackgroundCanvas(c);
        render();
    }

    function setGradientTheme(theme) {
        bgIsDark = theme !== 'light';
        bgSeed = Math.floor(Math.random() * 1000000);
        const c = generateBackground(bgIsDark, performance.now());
        uploadBackgroundCanvas(c);
        render();
    }

    function setTextureSource(source) {
        if (!source) return;
        if (typeof source === 'string') {
            const im = new Image();
            im.crossOrigin = 'anonymous';
            im.onload = function () {
                imgW = im.naturalWidth; imgH = im.naturalHeight;
                gl.bindTexture(gl.TEXTURE_2D, tex);
                gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, im);
                hasImg = true;
                render();
            };
            im.src = source;
        } else {
            uploadBackgroundCanvas(source);
            render();
        }
    }

    function resize() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2.0);
        const w = Math.floor(window.innerWidth * dpr);
        const h = Math.floor(window.innerHeight * dpr);
        if (canvas.width !== w || canvas.height !== h) {
            canvas.width = w;
            canvas.height = h;
            canvas.style.width = window.innerWidth + 'px';
            canvas.style.height = window.innerHeight + 'px';
        }
    }

    function parseTransformMatrix(el) {
        try {
            const st = getComputedStyle(el);
            const mat = new DOMMatrixReadOnly(st.transform);
            return { scaleX: mat.a, scaleY: mat.d };
        } catch (e) {
            return { scaleX: 1, scaleY: 1 };
        }
    }

    function collectRects() {
        const dpr = Math.min(window.devicePixelRatio || 1, 2.0);
        const out = [];
        document.querySelectorAll('.bottom-navbar, .nav-indicator').forEach(el => {
            const r = el.getBoundingClientRect();
            if (r.width < 2 || r.height < 2) return;

            const { scaleX, scaleY } = parseTransformMatrix(el);
            let type = 0.0;
            if (el.classList.contains('nav-indicator')) type = 1.0;
            else if (el.classList.contains('bottom-navbar')) type = 2.0;
            if (type === 0.0) return;

            const rawRad = parseFloat(getComputedStyle(el).borderTopLeftRadius) || 0;
            let effectiveRadius = rawRad;
            if (type === 1.0) {
                const avgScale = (Math.abs(scaleX) + Math.abs(scaleY)) / 2.0;
                effectiveRadius = rawRad * avgScale;
            }

            let rad = effectiveRadius * dpr;
            const boxW = r.width * dpr;
            const boxH = r.height * dpr;
            const maxRad = Math.min(boxW / 2.0, boxH / 2.0);
            rad = Math.min(rad, maxRad);

            out.push([r.left * dpr, r.top * dpr, boxW, boxH, rad, type]);
        });
        return out;
    }

    function render() {
        resize();
        const W = canvas.width, H = canvas.height;
        gl.viewport(0, 0, W, H);
        gl.useProgram(prog);
        let ts = [1, 1], to = [0, 0];
        if (hasImg) {
            const s = Math.max(W / imgW, H / imgH);
            const dw = imgW * s, dh = imgH * s;
            ts = [W / dw, H / dh];
            to = [-(W - dw) / 2 / dw, -(H - dh) / 2 / dh];
        }
        const rects = collectRects();
        const flat = new Float32Array(MAXR * 4);
        const radii = new Float32Array(MAXR);
        const types = new Float32Array(MAXR);
        for (let i = 0; i < rects.length; i++) {
            flat[i * 4] = rects[i][0];
            flat[i * 4 + 1] = rects[i][1];
            flat[i * 4 + 2] = rects[i][2];
            flat[i * 4 + 3] = rects[i][3];
            radii[i] = rects[i][4];
            types[i] = rects[i][5];
        }
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, tex);
        gl.uniform1i(U.bg, 0);
        gl.uniform2f(U.res, W, H);
        gl.uniform2f(U.texScale, ts[0], ts[1]);
        gl.uniform2f(U.texOffset, to[0], to[1]);
        gl.uniform1i(U.count, rects.length);
        gl.uniform4fv(U.rects, flat);
        gl.uniform1fv(U.radii, radii);
        gl.uniform1fv(U.types, types);
        gl.uniform4fv(U.glassColor, new Float32Array(glassColor));
        gl.uniform1f(U.pressing, isPressing ? 1.0 : 0.0);

        const _dpr = Math.min(window.devicePixelRatio || 1, 2.0);
        gl.uniform3f(U.indParams, indParams.strength * _dpr, indParams.edge * _dpr, indParams.dispersion * _dpr);
        gl.uniform1f(U.pinchAmount, pinchAmount * _dpr);
        gl.uniform1f(U.blur, currentBlur * _dpr);
        gl.uniform1f(U.saturation, currentSat / 100);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }

    let rafId = null, until = 0;
    function pump() {
        render();
        if (performance.now() < until) rafId = requestAnimationFrame(pump);
        else rafId = null;
    }
    function kick(ms) {
        until = Math.max(until, performance.now() + (ms || 500));
        if (!rafId) rafId = requestAnimationFrame(pump);
    }

    window.addEventListener('resize', () => kick(400));
    window.addEventListener('scroll', () => kick(200), { passive: true });

    function animateLoop(now) {
        if (!animateEnabled) {
            animateRafId = null;
            return;
        }
        if (now - animateLastUpdate > 50) {
            animateLastUpdate = now;
            const c = generateBackground(bgIsDark, now);
            uploadBackgroundCanvas(c);
            render();
        }
        animateRafId = requestAnimationFrame(animateLoop);
    }

    function setAnimate(enabled) {
        const next = !!enabled;
        if (next === animateEnabled) return;
        animateEnabled = next;
        if (next) {
            animateStart = performance.now();
            animateLastUpdate = 0;
            if (!animateRafId) animateRafId = requestAnimationFrame(animateLoop);
        } else {
            if (animateRafId) {
                cancelAnimationFrame(animateRafId);
                animateRafId = null;
            }
            const c = generateBackground(bgIsDark, performance.now());
            uploadBackgroundCanvas(c);
            render();
        }
    }

    setTextureSource(generateBackground(bgIsDark, performance.now()));

    return {
        refresh(dur) { kick(dur || 500); },
        setGradientTheme,
        regenerateBackground,
        setAnimate,
        setGlassColor(r, g, b, a) { glassColor = [r, g, b, a]; kick(500); },
        setIndParams(cfg) { indParams = Object.assign(indParams, cfg); kick(500); },
        setPressing(v) {
            const next = !!v;
            if (next !== isPressing) { isPressing = next; kick(500); }
        },
        setPinchAmount(v) {
            const next = Math.max(0, parseFloat(v) || 0);
            if (next !== pinchAmount) { pinchAmount = next; kick(500); }
        },
        setBlur(v) {
            const next = Math.max(0, parseFloat(v) || 0);
            if (next !== currentBlur) { currentBlur = next; kick(500); }
        },
        setSaturation(v) {
            const next = Math.max(0, parseFloat(v) || 100);
            if (next !== currentSat) { currentSat = next; kick(500); }
        }
    };
})();


// ============================================================
// 主题切换
// ============================================================
function updateThemeBtn() {
    const current = document.documentElement.getAttribute('data-theme');
    const icon = document.getElementById('themeIcon');
    if (icon) icon.textContent = current === 'dark' ? '☀️' : '🌙';
}

function applyGlassBgToCSS() {
    const colorInput = document.getElementById('glassBgColor');
    const alphaSlider = document.getElementById('glassBgAlphaSlider');
    if (!colorInput || !alphaSlider) return;

    const hex = colorInput.value || '#14161a';
    const alpha = parseFloat(alphaSlider.value) / 100;
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);

    document.documentElement.style.setProperty('--glass-bg', `rgba(${r}, ${g}, ${b}, ${alpha})`);

    if (window.LensFX) {
        window.LensFX.setGlassColor(r / 255, g / 255, b / 255, alpha);
    }
}

function syncGlassFromTheme() {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';

    let userSettings = null;
    try {
        const saved = localStorage.getItem('trigger.glass.settings');
        if (saved) userSettings = JSON.parse(saved);
    } catch (e) { userSettings = null; }

    const hasColorSetting = !!(userSettings && userSettings.glassBgColor !== undefined);
    const hasAlphaSetting = !!(userSettings && userSettings.glassBgAlphaSlider !== undefined);

    const colorInput = document.getElementById('glassBgColor');
    const alphaSlider = document.getElementById('glassBgAlphaSlider');

    if (colorInput && !hasColorSetting) {
        colorInput.value = isDark ? '#14161a' : '#ffffff';
    }
    if (alphaSlider && !hasAlphaSetting) {
        alphaSlider.value = 72;
        const label = document.getElementById('glassBgAlphaVal');
        if (label) label.textContent = '72%';
    }

    applyGlassBgToCSS();
}

function toggleTheme() {
    const current = document.documentElement.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    localStorage.setItem('theme', next);

    document.documentElement.style.removeProperty('--glass-bg');
    document.documentElement.style.removeProperty('--blur-val');
    document.documentElement.style.removeProperty('--saturation');

    updateThemeBtn();
    syncGlassFromTheme();

    if (window.LensFX && window.LensFX.setGradientTheme) {
        window.LensFX.setGradientTheme(next);
    }
    if (window.LensFX) window.LensFX.refresh(500);
}
window.toggleTheme = toggleTheme;

(function initTheme() {
    const saved = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', saved);
})();


// ============================================================
// 页面切换
// ============================================================
function showPage(pageName) {
    document.querySelectorAll('.page-content').forEach(page => page.classList.remove('active'));
    const targetPage = document.getElementById(`${pageName}-page`);
    if (targetPage) targetPage.classList.add('active');

    if (pageName === 'changebox') {
        window.loadModuleList?.();
    }
    if (window.LensFX) window.LensFX.refresh(400);
}

function addConfigRow(page) {
    if (page === 'config') {
        window.addVisualConfigRow?.();
    } else if (page === 'bootconfig') {
        window.addVisualBootConfigRow?.();
    }
}
window.addConfigRow = addConfigRow;


// ============================================================
// 液态玻璃底部导航栏交互
// ============================================================
const navMenu = document.getElementById('navMenu');
const navTabs = document.querySelectorAll('.nav-tab');
const indicator = document.getElementById('navIndicator');
let currentActive = document.querySelector('.nav-tab.active') || navTabs[0];
let longPressTimer = null;
let isDragging = false;
let startX = 0;
let startLeft = 0;

function updateIndicator(targetTab, animate = true) {
    if (!targetTab || !indicator || !navMenu) return;
    const menuRect = navMenu.getBoundingClientRect();
    const tabRect = targetTab.getBoundingClientRect();
    const left = tabRect.left - menuRect.left;
    const width = tabRect.width;
    indicator.style.transition = animate ? '' : 'none';
    indicator.style.transform = `translate3d(${left}px, 0, 0)`;
    indicator.style.width = `${width}px`;
    if (window.LensFX) window.LensFX.refresh(0);
}

function setActiveTab(targetTab, skipLens = false) {
    navTabs.forEach(tab => tab.classList.remove('active', 'drag-hover'));
    targetTab.classList.add('active');
    currentActive = targetTab;
    updateIndicator(targetTab, true);
    if (!skipLens && window.LensFX) window.LensFX.refresh(0);
}

function switchPage(pageName) {
    showPage(pageName);
    const tab = document.querySelector(`.nav-tab[data-page="${pageName}"]`);
    if (tab) setActiveTab(tab);
}
window.switchPage = switchPage;

function getClosestTab(clientX) {
    let closest = currentActive;
    let minDistance = Infinity;
    navTabs.forEach(tab => {
        const rect = tab.getBoundingClientRect();
        const center = rect.left + rect.width / 2;
        const dist = Math.abs(clientX - center);
        if (dist < minDistance) {
            minDistance = dist;
            closest = tab;
        }
    });
    return closest;
}

function onPointerDown(e) {
    if (e.target.closest('#themeBtn')) return;
    if (e.button !== undefined && e.button !== 0) return;
    if (!indicator || !navMenu) return;

    e.preventDefault();
    e.stopPropagation();

    startX = e.clientX;
    const menuRect = navMenu.getBoundingClientRect();
    const indRect = indicator.getBoundingClientRect();
    startLeft = indRect.left - menuRect.left;

    if (navMenu.setPointerCapture) {
        try { navMenu.setPointerCapture(e.pointerId); } catch (err) {}
    }

    longPressTimer = setTimeout(() => {
        isDragging = true;
        indicator.classList.add('dragging');
        const pressScale = getComputedStyle(document.documentElement)
            .getPropertyValue('--ind-press-scale') || '1.10';
        indicator.style.transform = `translate3d(${startLeft}px, 0, 0) scale(${pressScale.trim()})`;
        if (navigator.vibrate) navigator.vibrate(20);
        navMenu.classList.add('pressing');
        if (window.LensFX) {
            window.LensFX.setPressing(true);
            window.LensFX.refresh(0);
        }
    }, 200);

    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
}

function onPointerMove(e) {
    const deltaX = e.clientX - startX;
    if (!isDragging) {
        if (Math.abs(deltaX) > 12) clearTimeout(longPressTimer);
        return;
    }
    e.preventDefault();
    let newLeft = startLeft + deltaX;
    const maxLeft = navMenu.clientWidth - indicator.offsetWidth - 8;
    newLeft = Math.max(8, Math.min(newLeft, maxLeft));
    const pressScale = getComputedStyle(document.documentElement)
        .getPropertyValue('--ind-press-scale') || '1.10';
    indicator.style.transform = `translate3d(${newLeft}px, 0, 0) scale(${pressScale.trim()})`;

    const hoverTab = getClosestTab(e.clientX);
    navTabs.forEach(tab => tab.classList.remove('drag-hover'));
    if (hoverTab) hoverTab.classList.add('drag-hover');

    if (window.LensFX) window.LensFX.refresh(0);
}

function onPointerUp(e) {
    clearTimeout(longPressTimer);
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
    window.removeEventListener('pointercancel', onPointerUp);

    if (isDragging) {
        isDragging = false;
        indicator.classList.remove('dragging');
        navMenu.classList.remove('pressing');
        if (window.LensFX) window.LensFX.setPressing(false);

        const targetTab = getClosestTab(e.clientX);
        if (targetTab) {
            setActiveTab(targetTab);
            showPage(targetTab.dataset.page);
        }
    } else {
        const targetTab = getClosestTab(e.clientX);
        if (targetTab) {
            setActiveTab(targetTab);
            showPage(targetTab.dataset.page);
        }
    }
}

if (navMenu) {
    navMenu.addEventListener('pointerdown', onPointerDown);
    navMenu.addEventListener('contextmenu', (e) => e.preventDefault());

    navTabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            if (!isDragging) {
                setActiveTab(tab);
                showPage(tab.dataset.page);
            }
        });
        tab.addEventListener('contextmenu', (e) => e.preventDefault());
        tab.addEventListener('selectstart', (e) => e.preventDefault());
    });
}


// ============================================================
// 背景控制
// ============================================================
function handleBgAnimate(enable) {
    if (window.LensFX && window.LensFX.setAnimate) {
        window.LensFX.setAnimate(!!enable);
    }
}
window.handleBgAnimate = handleBgAnimate;

function handleBgRefresh() {
    if (window.LensFX && window.LensFX.regenerateBackground) {
        window.LensFX.regenerateBackground();
        window.showToast?.('背景已重新随机', { type: 'success' });
    }
}
window.handleBgRefresh = handleBgRefresh;


// ============================================================
// 液态玻璃设置自动保存与恢复
// ============================================================
function saveGlassSettings() {
    const ids = [
        'glassBgColor', 'glassBgAlphaSlider', 'cardBlurSlider', 'cardSatSlider',
        'indColor', 'indAlphaSlider', 'indHeightSlider', 'indRadiusSlider',
        'indPressScaleSlider', 'indStrengthSlider', 'indEdgeSlider', 'indDispSlider',
        'navYSlider', 'navPinchSlider', 'bgAnimateToggle'
    ];
    const settings = {};
    ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            settings[id] = el.type === 'checkbox' ? el.checked : el.value;
        }
    });
    localStorage.setItem('trigger.glass.settings', JSON.stringify(settings));
}

function loadGlassSettings() {
    const saved = localStorage.getItem('trigger.glass.settings');
    if (!saved) return;
    try {
        const settings = JSON.parse(saved);
        Object.keys(settings).forEach(id => {
            const el = document.getElementById(id);
            if (!el) return;
            if (el.type === 'checkbox') {
                el.checked = settings[id];
                const changeEvent = new Event('change', { bubbles: true });
                el.dispatchEvent(changeEvent);
            } else {
                el.value = settings[id];
                const inputEvent = new Event('input', { bubbles: true });
                el.dispatchEvent(inputEvent);
            }
        });
    } catch (e) {
        console.error('读取液态玻璃设置失败', e);
    }
}


// ============================================================
// 自启核心状态显示
// ============================================================
async function updateCoreUI() {
    const coreCard = document.getElementById('core-card');
    if (!coreCard) return;

    const isRunning = await window.getCoreStatus?.();
    const isBootStart = await window.getBootStartStatus?.();

    coreCard.innerHTML = `
        <div style="display: flex; flex-direction: column; width: 100%; gap: 12px;">
            <div style="display: flex; align-items: center; justify-content: space-between;">
                <div style="display: flex; flex-direction: column;">
                    <div style="font-size: 12px; opacity: 0.7;">自启核心 (triggerctl)</div>
                    <div style="font-size: 15px; font-weight: bold; color: ${isRunning ? '#81C784' : '#ff6b6b'};">
                        ${isRunning ? '● 正在运行' : '○ 已停止'}
                    </div>
                </div>
                <div style="display: flex; gap: 6px;">
                    <button class="plugin-buttons" style="width: 60px; height: 30px; margin: 0; font-size: 12px; background: ${isRunning ? '#5c6bc0' : 'var(--vp-c-button)'};" onclick="handleCoreToggle('${isRunning ? 'restart' : 'start'}')">
                        ${isRunning ? '重启' : '启动'}
                    </button>
                    <button class="plugin-buttons" style="width: 60px; height: 30px; margin: 0; font-size: 12px; background: #ff6b6b;" onclick="handleCoreToggle('stop')">
                        关闭
                    </button>
                </div>
            </div>
            <div style="display: flex; align-items: center; justify-content: space-between; padding-top: 8px; border-top: 1px solid var(--vp-c-border);">
                <div style="font-size: 13px;">开机自动启动核心</div>
                <label class="switch">
                    <input type="checkbox" ${isBootStart ? 'checked' : ''} onchange="handleBootToggle(this.checked)">
                    <span class="switch-slider"></span>
                </label>
            </div>
        </div>
    `;
}
window.updateCoreUI = updateCoreUI;

async function handleCoreToggle(action) {
    const success = await window.toggleCore?.(action);
    if (success) {
        setTimeout(updateCoreUI, 500);
    }
}
window.handleCoreToggle = handleCoreToggle;

async function handleBootToggle(enable) {
    const success = await window.toggleBootStart?.(enable);
    if (success) {
        setTimeout(updateCoreUI, 300);
    }
}
window.handleBootToggle = handleBootToggle;

async function triggerQuickAction(action) {
    const module = await import('./Module.js');
    if (action === 'clean-cache') {
        const success = await module.runQuickAction?.('clean-cache');
        if (success) {
            window.showToast?.('清理缓存已执行', { type: 'success' });
        } else {
            window.showToast?.('清理缓存失败', true);
        }
        return success;
    }
    if (action === 'toggle-usb') {
        const success = await module.runQuickAction?.('toggle-usb');
        if (success) {
            window.showToast?.('USB 调试已切换', { type: 'info' });
        } else {
            window.showToast?.('USB 调试切换失败', true);
        }
        return success;
    }
    return false;
}
window.triggerQuickAction = triggerQuickAction;


// ============================================================
// 液态玻璃控制面板绑定
// ============================================================
function bindGlassControls() {
    const glassBgColorInput = document.getElementById('glassBgColor');
    const glassBgAlphaSlider = document.getElementById('glassBgAlphaSlider');

    function updateGlassBackground() {
        if (!glassBgColorInput || !glassBgAlphaSlider) return;
        const alphaLabel = document.getElementById('glassBgAlphaVal');
        if (alphaLabel) alphaLabel.innerText = glassBgAlphaSlider.value + '%';
        applyGlassBgToCSS();
        if (window.LensFX) window.LensFX.refresh(200);
    }
    glassBgColorInput?.addEventListener('input', updateGlassBackground);
    glassBgAlphaSlider?.addEventListener('input', updateGlassBackground);

    document.getElementById('cardBlurSlider')?.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        const label = document.getElementById('cardBlurVal');
        if (label) label.innerText = val + 'px';
        document.documentElement.style.setProperty('--blur-val', val + 'px');
        if (window.LensFX) {
            window.LensFX.setBlur(val);
            window.LensFX.refresh(200);
        }
    });

    document.getElementById('cardSatSlider')?.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        const label = document.getElementById('cardSatVal');
        if (label) label.innerText = val + '%';
        document.documentElement.style.setProperty('--saturation', val + '%');
        if (window.LensFX) {
            window.LensFX.setSaturation(val);
            window.LensFX.refresh(200);
        }
    });

    const indColorInput = document.getElementById('indColor');
    const indAlphaSlider = document.getElementById('indAlphaSlider');

    function updateIndicatorColor() {
        if (!indColorInput || !indAlphaSlider) return;
        const hex = indColorInput.value;
        const alpha = indAlphaSlider.value / 100;
        const alphaLabel = document.getElementById('indAlphaVal');
        if (alphaLabel) alphaLabel.innerText = indAlphaSlider.value + '%';
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        document.documentElement.style.setProperty('--ind-bg', `rgba(${r}, ${g}, ${b}, ${alpha})`);
        document.documentElement.style.setProperty('--ind-border-color', `rgba(${r}, ${g}, ${b}, ${Math.min(alpha + 0.25, 1)})`);
        if (window.LensFX) window.LensFX.refresh(200);
    }
    indColorInput?.addEventListener('input', updateIndicatorColor);
    indAlphaSlider?.addEventListener('input', updateIndicatorColor);

    document.getElementById('indHeightSlider')?.addEventListener('input', (e) => {
        const label = document.getElementById('indHeightVal');
        if (label) label.innerText = e.target.value + 'px';
        document.documentElement.style.setProperty('--ind-height', e.target.value + 'px');
        updateIndicator(currentActive, false);
        if (window.LensFX) window.LensFX.refresh(200);
    });

    document.getElementById('indRadiusSlider')?.addEventListener('input', (e) => {
        const label = document.getElementById('indRadiusVal');
        if (label) label.innerText = e.target.value + 'px';
        document.documentElement.style.setProperty('--ind-radius', e.target.value + 'px');
        if (window.LensFX) window.LensFX.refresh(200);
    });

    document.getElementById('indPressScaleSlider')?.addEventListener('input', (e) => {
        const val = (e.target.value / 100).toFixed(2);
        const label = document.getElementById('indPressScaleVal');
        if (label) label.innerText = val + 'x';
        document.documentElement.style.setProperty('--ind-press-scale', val);
    });

    document.getElementById('indStrengthSlider')?.addEventListener('input', (e) => {
        const label = document.getElementById('indStrengthVal');
        if (label) label.innerText = e.target.value + 'px';
        if (window.LensFX) window.LensFX.setIndParams({ strength: parseFloat(e.target.value) });
    });

    document.getElementById('indEdgeSlider')?.addEventListener('input', (e) => {
        const label = document.getElementById('indEdgeVal');
        if (label) label.innerText = e.target.value + 'px';
        if (window.LensFX) window.LensFX.setIndParams({ edge: parseFloat(e.target.value) });
    });

    document.getElementById('indDispSlider')?.addEventListener('input', (e) => {
        const label = document.getElementById('indDispVal');
        if (label) label.innerText = e.target.value + 'px';
        if (window.LensFX) window.LensFX.setIndParams({ dispersion: parseFloat(e.target.value) });
    });

    document.getElementById('navYSlider')?.addEventListener('input', (e) => {
        const val = e.target.value;
        const label = document.getElementById('navYVal');
        if (label) label.innerText = val + 'px';
        document.documentElement.style.setProperty('--nav-y-offset', val + 'px');
        setTimeout(() => {
            updateIndicator(currentActive, false);
            if (window.LensFX) window.LensFX.refresh(300);
        }, 50);
    });

    document.getElementById('navPinchSlider')?.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        const label = document.getElementById('navPinchVal');
        if (label) label.innerText = val + 'px';
        if (window.LensFX) window.LensFX.setPinchAmount(val);
    });

    const saveIds = [
        'glassBgColor', 'glassBgAlphaSlider', 'cardBlurSlider', 'cardSatSlider',
        'indColor', 'indAlphaSlider', 'indHeightSlider', 'indRadiusSlider',
        'indPressScaleSlider', 'indStrengthSlider', 'indEdgeSlider', 'indDispSlider',
        'navYSlider', 'navPinchSlider'
    ];
    saveIds.forEach(id => {
        document.getElementById(id)?.addEventListener('input', saveGlassSettings);
    });
    document.getElementById('bgAnimateToggle')?.addEventListener('change', saveGlassSettings);
}


// ============================================================
// 页面加载初始化
// ============================================================
window.addEventListener('DOMContentLoaded', async () => {
    updateThemeBtn();
    syncGlassFromTheme();

    requestAnimationFrame(() => updateIndicator(currentActive, false));
    window.addEventListener('load', () => {
        setTimeout(() => updateIndicator(currentActive, false), 60);
    });
    window.addEventListener('resize', () => {
        updateIndicator(currentActive, false);
    });

    bindGlassControls();
    loadGlassSettings();

    const module = await import('./Module.js');
    const {
        loadConfig, saveConfig, loadBootConfig, saveBootConfig,
        getBatteryInfo, getPhoneBrand, getFingerprint, getSerialNumber,
        loadModuleList, applyModule, getCurrentModuleName, getOriginalModel,
        updateDeviceInfo, restoreDevice, getCoreStatus, toggleCore,
        getBootStartStatus, toggleBootStart, showToast
    } = module;

    window.loadConfig = loadConfig;
    window.saveConfig = saveConfig;
    window.loadBootConfig = loadBootConfig;
    window.saveBootConfig = saveBootConfig;
    window.loadModuleList = loadModuleList;
    window.applyModule = applyModule;
    window.getCurrentModuleName = getCurrentModuleName;
    window.getOriginalModel = getOriginalModel;
    window.restoreDevice = restoreDevice;
    window.getCoreStatus = getCoreStatus;
    window.toggleCore = toggleCore;
    window.getBootStartStatus = getBootStartStatus;
    window.toggleBootStart = toggleBootStart;
    window.showToast = showToast;

    loadConfig();
    loadBootConfig({ silent: true });
    updateDeviceInfo();
    updateCoreUI();

    try {
        const battery = await getBatteryInfo();
        const brand = await getPhoneBrand();
        const fingerprint = await getFingerprint();
        const sn = await getSerialNumber();

        const batteryCard = document.getElementById('battery-card');
        if (batteryCard) {
            batteryCard.innerHTML = `
                <div style="padding: 8px; text-align: center;">
                    <div style="font-size: 12px; margin-bottom: 4px;">电量</div>
                    <div style="width: 60px; height: 24px; background: var(--vp-c-textarea); border-radius: 4px; overflow: hidden; margin: 0 auto;">
                        <div style="height: 100%; width: ${battery}%; background: linear-gradient(90deg, #4CAF50, #8BC34A); transition: width 0.3s ease;"></div>
                    </div>
                    <div style="font-size: 12px; margin-top: 4px;">${battery}%</div>
                </div>
            `;
        }

        const brandCard = document.getElementById('brand-card');
        if (brandCard) {
            brandCard.innerHTML = `
                <div style="padding: 8px; text-align: center; overflow: hidden;">
                    <div style="font-size: 12px; margin-bottom: 4px;">品牌</div>
                    <div style="font-size: 14px; word-break: break-all;">${brand}</div>
                </div>
            `;
        }

        const fpCard = document.getElementById('fingerprint-card');
        if (fpCard) {
            fpCard.innerHTML = `
                <div style="padding: 8px; text-align: center; overflow: hidden;">
                    <div style="font-size: 12px; margin-bottom: 4px;">设备指纹</div>
                    <div style="font-size: 10px; word-break: break-all; max-height: 40px; overflow-y: auto;">${fingerprint}</div>
                </div>
            `;
        }

        const snCard = document.getElementById('sn-card');
        if (snCard) {
            snCard.innerHTML = `
                <div style="padding: 8px; text-align: center; overflow: hidden;">
                    <div style="font-size: 12px; margin-bottom: 4px;">序列号</div>
                    <div style="font-size: 10px; word-break: break-all; max-height: 40px; overflow-y: auto;">${sn}</div>
                </div>
            `;
        }
    } catch (error) {
        console.error('设备信息读取失败:', error);
    }
});