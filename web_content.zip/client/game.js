const canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");
const menu=document.getElementById("menu"),game=document.getElementById("game"),over=document.getElementById("over");
const statusEl=document.getElementById("status"),roomEl=document.getElementById("room");
let ws=null,mode="",myId=null,world={w:3600,h:2200},state=null,last=performance.now(),raf=0;
let input={angle:0,active:false,boost:false};
const joy=document.getElementById("joy"),knob=document.getElementById("joyKnob"),boost=document.getElementById("boost");

function resize(){canvas.width=innerWidth*devicePixelRatio;canvas.height=innerHeight*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0)}
addEventListener("resize",resize);resize();

function connect(url){
  statusEl.textContent="Connecting…";
  ws=new WebSocket(url);
  ws.onopen=()=>{statusEl.textContent="Connected. Waiting for opponent…";ws.send(JSON.stringify({type:"join",name:document.getElementById("name").value.trim()||"Player"}))};
  ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return}
    if(m.type==="welcome"){myId=m.id;world=m.world||world}
    if(m.type==="state"){state=m; if(game.classList.contains("hidden")){menu.classList.add("hidden");over.classList.add("hidden");game.classList.remove("hidden");last=performance.now();loop()}}
    if(m.type==="waiting"){roomEl.textContent="Room ready — share this address: "+location.origin;roomEl.classList.remove("hidden");statusEl.textContent="Waiting for Player 2…"}
    if(m.type==="error"){statusEl.textContent=m.message||"Connection error"}
    if(m.type==="result"){showResult(m)}
  };
  ws.onclose=()=>{if(!over.classList.contains("hidden"))return;statusEl.textContent="Disconnected from server."};
  ws.onerror=()=>statusEl.textContent="Could not connect. Check the IP and server.";
}
document.getElementById("hostBtn").onclick=()=>{mode="host";connect(location.origin.replace(/^http/,"ws"))};
document.getElementById("joinBtn").onclick=()=>document.getElementById("joinBox").classList.toggle("hidden");
document.getElementById("connectBtn").onclick=()=>{
  let ip=document.getElementById("server").value.trim().replace(/^https?:\/\//,"").replace(/\/$/,"");
  if(!ip)return;
  mode="join";connect("ws://"+ip+(ip.includes(":")?"":":3000"));
};
document.getElementById("again").onclick=()=>{if(ws?.readyState===1)ws.send(JSON.stringify({type:"restart"}));over.classList.add("hidden");game.classList.remove("hidden")};
document.getElementById("menuBtn").onclick=()=>location.reload();

function sendInput(){if(ws?.readyState===1)ws.send(JSON.stringify({type:"input",angle:input.angle,active:input.active,boost:input.boost}))}
setInterval(sendInput,40);

function joyMove(e){
 const r=joy.getBoundingClientRect(),x=(e.clientX-r.left)-r.width/2,y=(e.clientY-r.top)-r.height/2;
 const max=r.width*.36,d=Math.hypot(x,y),q=Math.min(1,d/max),a=Math.atan2(y,x);
 knob.style.transform=`translate(${Math.cos(a)*q*max}px,${Math.sin(a)*q*max}px)`;
 if(d>7){input.active=true;input.angle=a}
}
function joyEnd(){input.active=false;knob.style.transform="translate(0,0)"}
joy.addEventListener("pointerdown",e=>{joy.setPointerCapture(e.pointerId);joyMove(e)});
joy.addEventListener("pointermove",e=>{if(input.active)joyMove(e)});
joy.addEventListener("pointerup",joyEnd);joy.addEventListener("pointercancel",joyEnd);
boost.addEventListener("pointerdown",e=>{e.preventDefault();input.boost=true});
["pointerup","pointercancel","pointerleave"].forEach(x=>boost.addEventListener(x,()=>input.boost=false));

function drawGrid(camx,camy){
 ctx.fillStyle="#07131a";ctx.fillRect(0,0,innerWidth,innerHeight);
 const size=80,ox=(-camx)%size,oy=(-camy)%size;ctx.strokeStyle="#ffffff08";ctx.lineWidth=1;
 for(let x=ox;x<innerWidth;x+=size){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,innerHeight);ctx.stroke()}
 for(let y=oy;y<innerHeight;y+=size){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(innerWidth,y);ctx.stroke()}
 ctx.strokeStyle="#2a6575";ctx.lineWidth=6;ctx.strokeRect(-camx,-camy,world.w,world.h);
}
function drawSnake(s,camx,camy){
 if(!s.body?.length)return;ctx.lineCap="round";ctx.lineJoin="round";ctx.strokeStyle=s.color;ctx.lineWidth=s.radius*2;ctx.beginPath();
 for(let i=0;i<s.body.length;i++){let p=s.body[i],x=p.x-camx,y=p.y-camy;if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)}ctx.stroke();
 let h=s.body[0],hx=h.x-camx,hy=h.y-camy;
 ctx.fillStyle=s.color;ctx.beginPath();ctx.arc(hx,hy,s.radius+3,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(hx-5,hy-4,4,0,Math.PI*2);ctx.arc(hx+5,hy-4,4,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#17212a";ctx.beginPath();ctx.arc(hx-5,hy-4,2,0,Math.PI*2);ctx.arc(hx+5,hy-4,2,0,Math.PI*2);ctx.fill();
 ctx.fillStyle="#fff";ctx.font="bold 12px Arial";ctx.textAlign="center";ctx.fillText(s.name,hx,hy-s.radius-12);
}
function draw(){
 if(!state)return;let me=state.players.find(p=>p.id===myId)||state.players[0];let h=me?.body?.[0]||{x:world.w/2,y:world.h/2};
 let camx=h.x-innerWidth/2,camy=h.y-innerHeight/2;camx=Math.max(0,Math.min(world.w-innerWidth,camx));camy=Math.max(0,Math.min(world.h-innerHeight,camy));
 drawGrid(camx,camy);
 for(const f of state.food||[]){ctx.fillStyle=f.color;ctx.beginPath();ctx.arc(f.x-camx,f.y-camy,f.r,0,Math.PI*2);ctx.fill()}
 for(const s of state.players||[])drawSnake(s,camx,camy);
 const a=state.players?.[0],b=state.players?.[1];
 if(a){document.getElementById("p1Name").textContent=a.name;document.getElementById("p1Score").textContent=a.score}
 if(b){document.getElementById("p2Name").textContent=b.name;document.getElementById("p2Score").textContent=b.score}
 document.getElementById("myScore").textContent=me?.score||0;
}
function loop(){cancelAnimationFrame(raf);function f(){draw();raf=requestAnimationFrame(f)}raf=requestAnimationFrame(f)}
function showResult(m){over.classList.remove("hidden");game.classList.add("hidden");document.getElementById("result").textContent=m.winnerId===myId?"YOU WIN!":m.winnerId?"YOU LOSE":"DRAW";document.getElementById("final").innerHTML=(m.message||"Game finished.")+"<br><b>"+(m.scores||"")+"</b>"}

window.addEventListener("keydown",e=>{let k=e.key.toLowerCase(),a=null;if(k==="arrowup"||k==="w")a=-Math.PI/2;if(k==="arrowdown"||k==="s")a=Math.PI/2;if(k==="arrowleft"||k==="a")a=Math.PI;if(k==="arrowright"||k==="d")a=0;if(a!==null){input.angle=a;input.active=true}if(k===" ")input.boost=true});
window.addEventListener("keyup",e=>{if(["arrowup","arrowdown","arrowleft","arrowright","w","a","s","d"].includes(e.key.toLowerCase()))input.active=false;if(e.key===" ")input.boost=false});
