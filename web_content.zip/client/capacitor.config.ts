import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.aireseller.app',
  appName: 'AI Reseller',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
};

export default config;
