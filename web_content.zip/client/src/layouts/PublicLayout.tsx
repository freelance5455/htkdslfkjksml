import React from "react";
import { Link, Outlet } from "react-router-dom";

export default function PublicLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 backdrop-blur-md bg-white/60 border-b border-white/60">
        <div className="max-w-6xl mx-auto flex items-center justify-between px-4 sm:px-6 py-4">
          <Link to="/" className="font-bold text-lg tracking-tight">
            AI <span className="text-accent">Reseller</span>
          </Link>
          <nav className="hidden md:flex items-center gap-8 text-sm text-muted">
            <a href="/#features" className="hover:text-ink transition-colors">Features</a>
            <a href="/#how-it-works" className="hover:text-ink transition-colors">How It Works</a>
            <a href="/#faq" className="hover:text-ink transition-colors">FAQ</a>
          </nav>
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium text-muted hover:text-ink transition-colors">
              Log in
            </Link>
            <Link to="/signup" className="btn-primary text-sm">
              Build My Store Free
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="border-t border-white/60 bg-white/40 mt-24">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
          <div>
            <p className="font-semibold mb-3">Product</p>
            <ul className="space-y-2 text-muted">
              <li><a href="/#features" className="hover:text-ink">Features</a></li>
              <li><a href="/#how-it-works" className="hover:text-ink">How It Works</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-3">Resources</p>
            <ul className="space-y-2 text-muted">
              <li><a href="/#faq" className="hover:text-ink">FAQ</a></li>
              <li><a href="#" className="hover:text-ink">Documentation</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-3">Legal</p>
            <ul className="space-y-2 text-muted">
              <li><a href="#" className="hover:text-ink">Privacy</a></li>
              <li><a href="#" className="hover:text-ink">Terms</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-3">Contact</p>
            <ul className="space-y-2 text-muted">
              <li><a href="mailto:hello@aireseller.app" className="hover:text-ink">hello@aireseller.app</a></li>
            </ul>
          </div>
        </div>
        <p className="text-center text-xs text-muted pb-8">© {new Date().getFullYear()} AI Reseller. Your AI-powered store. Start free.</p>
      </footer>
    </div>
  );
}
