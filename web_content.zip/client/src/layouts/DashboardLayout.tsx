import React, { useState } from "react";
import { NavLink, Outlet } from "react-router-dom";

const NAV = [
  { to: "/app/dashboard", label: "Dashboard", icon: "◧" },
  { to: "/app/products", label: "Products", icon: "▤" },
  { to: "/app/product-finder", label: "Product Finder", icon: "◎" },
  { to: "/app/orders", label: "Orders", icon: "▣" },
  { to: "/app/customers", label: "Customers", icon: "◕" },
  { to: "/app/store-editor", label: "Store", icon: "◫" },
  { to: "/app/analytics", label: "Analytics", icon: "▲" },
  { to: "/app/ai-assistant", label: "AI Assistant", icon: "✦" },
  { to: "/app/settings", label: "Settings", icon: "⚙" },
];

export default function DashboardLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);

  const SidebarContent = (
    <div className="flex flex-col h-full">
      <div className="px-5 py-5 font-bold tracking-tight">
        AI <span className="text-accent">Reseller</span>
      </div>
      <nav className="flex-1 px-3 space-y-1">
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${
                isActive ? "bg-accent/10 text-accent font-medium" : "text-muted hover:bg-black/5 hover:text-ink"
              }`
            }
          >
            <span aria-hidden>{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>
      <div className="px-3 pb-5 pt-3 border-t border-black/5 space-y-1">
        <NavLink to="/app/settings" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted hover:bg-black/5 hover:text-ink">
          <span aria-hidden>◐</span> Profile
        </NavLink>
        <a href="#" className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-muted hover:bg-black/5 hover:text-ink">
          <span aria-hidden>?</span> Help
        </a>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex">
      <aside className="hidden md:flex md:w-64 flex-col glass-panel m-4 mr-0 sticky top-4 h-[calc(100vh-2rem)]">
        {SidebarContent}
      </aside>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-black/20" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-72 glass-panel rounded-none">{SidebarContent}</div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden flex items-center justify-between px-4 py-3 sticky top-0 z-30 bg-white/70 backdrop-blur-md border-b border-white/60">
          <button aria-label="Open menu" onClick={() => setMobileOpen(true)} className="text-lg">☰</button>
          <span className="font-semibold">AI Reseller</span>
          <span />
        </header>
        <main className="flex-1 p-4 sm:p-6 md:p-8 max-w-6xl w-full mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
