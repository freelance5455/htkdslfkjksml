import { useEffect, useState } from "react";

const API = "http://localhost:4000/api";
type User = { id: string; name: string; email: string; role: "STUDENT" | "ADMIN"; preferredLanguage?: string };
type Grade = { id: string; number: number; titleEn: string; titleOm: string; subjects: Subject[] };
type Subject = { id: string; nameEn: string; nameOm: string; chapters: Chapter[] };
type Chapter = { id: string; titleEn: string; titleOm: string; lessons: Lesson[] };
type Lesson = { id: string; titleEn: string; titleOm: string; videoUrl?: string | null; pdfUrl?: string | null };
const words = {
 en: { brand:"ODA Learning", subtitle:"Learn without limits.", home:"Overview", courses:"Curriculum", payments:"Payments", admin:"Admin", login:"Sign in", register:"Create account", name:"Full name", email:"Email address", password:"Password (10+ characters)", welcome:"Your learning space", start:"Explore curriculum", loading:"Loading…", signout:"Sign out", grade:"Grade", lessons:"Lessons", subjects:"Subjects", noLessons:"No lessons published yet.", loginHint:"Sign in or create a student account to track progress.", amount:"Amount (ETB)", reference:"Payment reference", submit:"Submit for review", status:"Status", students:"Students", pending:"Pending payments", approve:"Approve", reject:"Reject", curriculum:"Browse your subjects, chapters and lessons.", resources:"Learning resources", language:"Afaan Oromoo", adminOnly:"Admin controls", dashboard:"Dashboard", explanation:"Question explanations appear with lesson content once published." },
 om: { brand:"ODA Barnoota", subtitle:"Baradhu daangaa malee.", home:"Cuunfaa", courses:"Sirna barnootaa", payments:"Kaffaltii", admin:"Bulchiinsa", login:"Seeni", register:"Herrega bani", name:"Maqaa guutuu", email:"Imeelii", password:"Jecha iccitii (qubee 10+)", welcome:"Iddoo barnoota kee", start:"Sirna barnootaa ilaali", loading:"Fe'amaa jira…", signout:"Ba'i", grade:"Kutaa", lessons:"Barnoota", subjects:"Damee barnootaa", noLessons:"Barnoonni ammaaf hin maxxanfamne.", loginHint:"Guddina barnootaa hordofuuf seeni ykn herrega barataa bani.", amount:"Baay'ina (ETB)", reference:"Lakkoofsa ragaa kaffaltii", submit:"Mirkaneessaaf ergi", status:"Haala", students:"Barattoota", pending:"Kaffaltii eeggataa", approve:"Mirkaneessi", reject:"Didii", curriculum:"Damee barnootaa, boqonnaa fi barnoota ilaali.", resources:"Meeshaalee barnootaa", language:"English", adminOnly:"To'annoo bulchiinsaa", dashboard:"Daashboordii", explanation:"Ibsi gaaffii qabiyyee barnootaa waliin mul'ata yeroo maxxanfamu." }
};
export default function App() {
  const [lang, setLang] = useState<"en"|"om">("en");
  const [user, setUser] = useState<User|null>(null);
  const [view, setView] = useState("home");
  const [grades, setGrades] = useState<Grade[]>([]);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name:"", email:"", password:"" });
  const [mode, setMode] = useState<"login"|"register">("login");
  const [amount, setAmount] = useState("");
  const [reference, setReference] = useState("");
  const [adminData, setAdminData] = useState<any>(null);
  const t = words[lang];
  async function api(path:string, init:RequestInit={}) {
    const r = await fetch(API+path, { ...init, credentials:"include", headers:{ "Content-Type":"application/json", ...(init.headers||{}) } });
    const d = await r.json().catch(()=>({}));
    if (!r.ok) throw new Error(d.error || `Request failed (${r.status})`);
    return d;
  }
  async function refresh() {
    try { const d = await api("/auth/me"); setUser(d.user); } catch { setUser(null); }
    try { const d = await api("/curriculum"); setGrades(d.grades || []); } catch(e) { setNotice(e instanceof Error?e.message:"API unavailable"); }
  }
  useEffect(()=>{ refresh(); },[]);
  async function submitAuth(e:React.FormEvent) {
    e.preventDefault(); setBusy(true); setNotice("");
    try {
      const d = await api(`/auth/${mode==="login"?"login":"register"}`, { method:"POST", body:JSON.stringify({...form, language:lang}) });
      setUser(d.user); setView("dashboard"); setNotice(lang==="en"?"Welcome to ODA Learning!":"Baga gara ODA Barnoota dhuftan!");
    } catch(e) { setNotice(e instanceof Error?e.message:"Unable to sign in"); }
    finally { setBusy(false); }
  }
  async function signout(){ try { await api("/auth/logout",{method:"POST"}); } finally { setUser(null); setView("home"); } }
  async function submitPayment(e:React.FormEvent) {
    e.preventDefault();
    try { await api("/payments",{method:"POST",body:JSON.stringify({amount:Number(amount),reference})}); setNotice(lang==="en"?"Payment submitted for manual review.":"Kaffaltiin mirkaneessa harkaa eegaluuf ergame."); setAmount(""); setReference(""); }
    catch(e){setNotice(e instanceof Error?e.message:"Payment could not be submitted");}
  }
  async function loadAdmin(){
    try { const [overview,payments,users]=await Promise.all([api("/admin/overview"),api("/admin/payments"),api("/admin/users")]); setAdminData({...overview,...payments,...users}); setView("admin"); }
    catch(e){setNotice(e instanceof Error?e.message:"Admin data unavailable");}
  }
  async function reviewPayment(id:string,status:"APPROVED"|"REJECTED"){
    try { await api(`/admin/payments/${id}`,{method:"PATCH",body:JSON.stringify({status})}); await loadAdmin(); }
    catch(e){setNotice(e instanceof Error?e.message:"Unable to review payment");}
  }
  return <div className="app-shell">
    <header className="topbar"><button className="brand" onClick={()=>setView("home")}><span className="logo">O</span><span><b>{t.brand}</b><small>{t.subtitle}</small></span></button>
      <nav><button onClick={()=>setView("home")}>{t.home}</button><button onClick={()=>setView("curriculum")}>{t.courses}</button>{user&&<button onClick={()=>setView("dashboard")}>{t.dashboard}</button>}{user&&<button onClick={()=>setView("payments")}>{t.payments}</button>}{user?.role==="ADMIN"&&<button onClick={loadAdmin}>{t.admin}</button>}</nav>
      <div className="right-tools"><button className="lang" onClick={()=>setLang(lang==="en"?"om":"en")}>{t.language}</button>{user?<button className="outline" onClick={signout}>{t.signout}</button>:<button className="primary small" onClick={()=>setView("auth")}>{t.login}</button>}</div>
    </header>
    <main>
      {notice&&<div className="notice" role="status">{notice}<button onClick={()=>setNotice("")}>×</button></div>}
      {view==="home"&&<><section className="hero"><div className="hero-copy"><span className="eyebrow">ODA • DIGITAL LEARNING</span><h1>{lang==="en"?"Your next chapter starts here.":"Boqonnaan barnoota kee itti aanu as irraa jalqaba."}</h1><p>{lang==="en"?"A welcoming learning platform for lessons, resources, quizzes and progress — in English and Afaan Oromoo.":"Waltajjii barnootaa, qabeenya, gaaffilee fi guddina barnootaa Afaan Oromoo fi English keessatti."}</p><div className="actions"><button className="primary" onClick={()=>setView(user?"curriculum":"auth")}>{t.start} ↗</button><button className="outline light" onClick={()=>setView("curriculum")}>{t.courses}</button></div><div className="hero-stats"><span><b>01</b><small>{t.subjects}</small></span><span><b>02</b><small>{t.lessons}</small></span><span><b>02</b><small>Languages</small></span></div></div><div className="hero-art"><div className="orbit orbit1"></div><div className="orbit orbit2"></div><div className="book"><span>ODA</span><b>Learn.<br/>Grow.<br/>Lead.</b><small>KNOWLEDGE FOR ALL</small></div><div className="float-card fc1">✦ <b>Keep learning</b><small>One lesson at a time</small></div><div className="float-card fc2">✓ <b>Track progress</b><small>Your goals, in view</small></div></div></section><section className="section"><div><span className="eyebrow">LEARN YOUR WAY</span><h2>{lang==="en"?"Everything you need to move forward":"Waan itti fufuu barbaaddu hunda"}</h2><p className="muted">{t.curriculum}</p></div><div className="feature-grid"><article><span className="feature-icon">▤</span><h3>{t.courses}</h3><p>{lang==="en"?"Structured grades, subjects, chapters and lessons.":"Kutaa, damee, boqonnaa fi barnoota qindaa'an."}</p></article><article><span className="feature-icon">▶</span><h3>{t.resources}</h3><p>{lang==="en"?"Video and PDF resources connected to each lesson.":"Viidiyoo fi PDF barnoota waliin walqabatan."}</p></article><article><span className="feature-icon">✓</span><h3>MCQ & feedback</h3><p>{lang==="en"?"Practice questions with explanations to support understanding.":"Gaaffilee shaakalaa fi ibsa hubannoo cimsu."}</p></article></div></section></>}
      {view==="auth"&&<section className="auth-wrap"><form className="auth-card" onSubmit={submitAuth}><span className="eyebrow">ODA LEARNING ACCOUNT</span><h2>{mode==="login"?t.login:t.register}</h2><p className="muted">{t.loginHint}</p>{mode==="register"&&<label>{t.name}<input required minLength={2} maxLength={80} value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label>}<label>{t.email}<input required type="email" autoComplete="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label>{t.password}<input required type="password" minLength={mode==="register"?10:1} maxLength={128} autoComplete={mode==="login"?"current-password":"new-password"} value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></label><button className="primary full" disabled={busy}>{busy?t.loading:(mode==="login"?t.login:t.register)}</button><button type="button" className="text-button" onClick={()=>setMode(mode==="login"?"register":"login")}>{mode==="login"?"New here? Create a student account":"Already registered? Sign in"}</button></form></section>}
      {view==="curriculum"&&<section className="section page-section"><span className="eyebrow">YOUR LEARNING PATH</span><h1>{t.courses}</h1><p className="muted">{t.curriculum}</p>{grades.length===0?<div className="empty">{t.noLessons}<p>Connect the API and seed the database to display curriculum.</p></div>:grades.map(g=><article className="grade-card" key={g.id}><h2>{lang==="en"?g.titleEn:g.titleOm}</h2>{g.subjects.map(s=><div className="subject" key={s.id}><h3>{lang==="en"?s.nameEn:s.nameOm}</h3>{s.chapters.map(c=><div className="chapter" key={c.id}><b>{lang==="en"?c.titleEn:c.titleOm}</b>{c.lessons.length?c.lessons.map(l=><div className="lesson" key={l.id}><span>▶ {lang==="en"?l.titleEn:l.titleOm}</span><div>{l.videoUrl&&<a href={l.videoUrl} target="_blank" rel="noreferrer">Video</a>}{l.pdfUrl&&<a href={l.pdfUrl} target="_blank" rel="noreferrer">PDF</a>}</div></div>):<p className="muted">{t.noLessons}</p>}</div>)}</div>)}</article>)}</section>}
      {view==="dashboard"&&<section className="section page-section"><span className="eyebrow">{t.dashboard}</span><h1>{t.welcome}{user?`, ${user.name}`:""}</h1>{!user?<div className="empty"><p>{t.loginHint}</p><button className="primary" onClick={()=>setView("auth")}>{t.login}</button></div>:<div className="feature-grid"><article><span className="feature-icon">▤</span><h3>{t.courses}</h3><p>{t.curriculum}</p><button className="outline" onClick={()=>setView("curriculum")}>{t.start}</button></article><article><span className="feature-icon">◎</span><h3>{t.payments}</h3><p>Submit a payment reference for manual admin review.</p><button className="outline" onClick={()=>setView("payments")}>{t.payments}</button></article><article><span className="feature-icon">✓</span><h3>Learning progress</h3><p>{t.explanation}</p></article></div>}</section>}
      {view==="payments"&&<section className="auth-wrap"><form className="auth-card" onSubmit={submitPayment}><span className="eyebrow">PAYMENT REVIEW</span><h2>{t.payments}</h2><p className="muted">This submits a reference for manual review; it does not transfer money.</p><label>{t.amount}<input required type="number" min="1" max="10000000" value={amount} onChange={e=>setAmount(e.target.value)}/></label><label>{t.reference}<input required minLength={3} maxLength={120} value={reference} onChange={e=>setReference(e.target.value)}/></label><button className="primary full">{t.submit}</button></form></section>}
      {view==="admin"&&<section className="section page-section"><span className="eyebrow">{t.adminOnly}</span><h1>{t.admin}</h1>{adminData&&<><div className="stats-grid"><article><small>{t.students}</small><strong>{adminData.students}</strong></article><article><small>{t.pending}</small><strong>{adminData.pendingPayments}</strong></article><article><small>{t.lessons}</small><strong>{adminData.lessons}</strong></article><article><small>Questions</small><strong>{adminData.questions}</strong></article></div><h2>Payment review</h2>{(adminData.payments||[]).map((p:any)=><div className="payment-row" key={p.id}><div><b>{p.user.name}</b><small>{p.user.email} · {p.reference}</small></div><div><b>{p.amount} {p.currency}</b><small>{p.status}</small></div>{p.status==="PENDING"&&<div className="actions"><button className="primary small" onClick={()=>reviewPayment(p.id,"APPROVED")}>{t.approve}</button><button className="outline small" onClick={()=>reviewPayment(p.id,"REJECTED")}>{t.reject}</button></div>}</div>)}<h2>Student accounts</h2>{(adminData.users||[]).map((u:any)=><div className="payment-row" key={u.id}><b>{u.name}</b><span>{u.email}</span><small>{new Date(u.createdAt).toLocaleDateString()}</small></div>)}</>}</section>}
    </main><footer><b>ODA Learning</b><span>Learning with purpose · Barnoota kaayyoo qabu</span><small>© {new Date().getFullYear()} ODA Educational App</small></footer>
  </div>;
}
