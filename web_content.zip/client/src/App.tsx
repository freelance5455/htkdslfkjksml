import React, { useState } from "react";

export default function App() {
  const [text, setText] = useState("");
  const [messages, setMessages] = useState<string[]>([]);
  const [voice, setVoice] = useState(false);

  async function send() {
    if (!text.trim()) return;
    const value = text;
    setText("");
    setMessages(m => [...m, "You: " + value]);
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: {"content-type":"application/json"},
      body: JSON.stringify({message:value})
    });
    const data = await response.json();
    setMessages(m => [...m, "JARVIS: " + data.text]);
  }

  return <main className="app">
    <header className="topbar">
      <div className="brand">JARVIS</div>
      <div className="subtitle">Personal Autonomous AI Operating System</div>
    </header>

    <aside className="sidebar">
      <button>＋ New Chat</button>
      <div>All Chats</div><div>Projects</div><div>Memory</div>
      <div>Founder Mode</div><div>Tools & Skills</div>
      <div>Files & Artifacts</div><div>Automation</div>
      <div>Security & Audit</div>
    </aside>

    <section className="chat">
      {messages.map((m,i)=><article key={i}>{m}</article>)}
    </section>

    <section className="composer">
      <button title="Attach files">＋</button>
      <textarea value={text} onChange={e=>setText(e.target.value)}
        placeholder="Message JARVIS..." />
      <button title="Microphone">🎙</button>
      <button title="Voice Chat" onClick={()=>setVoice(v=>!v)}>
        {voice ? "■" : "◉"}
      </button>
      <button onClick={send}>Send</button>
    </section>
  </main>;
}
