import React, { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import { LoadingSpinner, ErrorMessage, Toast } from "../components/States";

interface Store {
  name: string;
  tagline: string | null;
  description: string | null;
  currency: string;
  slug: string;
}

export default function StoreEditor() {
  const [store, setStore] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setStore((await api.getStore()) as Store);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load your store.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!store) return;
    setSaving(true);
    try {
      await api.updateStore({
        name: store.name,
        tagline: store.tagline ?? "",
        description: store.description ?? "",
        currency: store.currency,
      });
      setToast("Store updated.");
    } catch (err) {
      setToast(err instanceof ApiError ? err.message : "Couldn't save changes.");
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <LoadingSpinner label="Loading your store…" />;
  if (error) return <ErrorMessage message={error} onRetry={load} />;
  if (!store) return null;

  return (
    <div className="space-y-5 max-w-2xl">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Store</h1>
        <a href={`/store/${store.slug}`} target="_blank" rel="noreferrer" className="btn-secondary text-sm">
          View storefront ↗
        </a>
      </div>

      <form onSubmit={handleSave} className="glass-card p-6 space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1.5">Store name</label>
          <input className="input-field" value={store.name} onChange={(e) => setStore({ ...store, name: e.target.value })} />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Tagline</label>
          <input
            className="input-field"
            placeholder="A short line under your store name"
            value={store.tagline ?? ""}
            onChange={(e) => setStore({ ...store, tagline: e.target.value })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">About / description</label>
          <textarea
            className="input-field min-h-[100px]"
            value={store.description ?? ""}
            onChange={(e) => setStore({ ...store, description: e.target.value })}
          />
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Currency</label>
          <select className="input-field" value={store.currency} onChange={(e) => setStore({ ...store, currency: e.target.value })}>
            <option value="USD">USD</option>
            <option value="EUR">EUR</option>
            <option value="GBP">GBP</option>
          </select>
        </div>
        <button type="submit" disabled={saving} className="btn-primary disabled:opacity-60">
          {saving ? "Saving…" : "Save changes"}
        </button>
      </form>

      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
    </div>
  );
}
