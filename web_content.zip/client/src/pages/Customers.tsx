import React, { useEffect, useState } from "react";
import { api } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState } from "../components/States";

interface Customer {
  id: string;
  name: string;
  email: string;
  created_at: string;
}

export default function Customers() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setCustomers((await api.getCustomers()) as Customer[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load customers.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Customers</h1>
      {loading && <LoadingSpinner label="Loading customers…" />}
      {error && <ErrorMessage message={error} onRetry={load} />}
      {!loading && !error && customers.length === 0 && (
        <EmptyState title="No customers yet" description="Customers are created automatically the first time someone places a real order." />
      )}
      {!loading && !error && customers.length > 0 && (
        <div className="glass-card divide-y divide-black/5">
          {customers.map((c) => (
            <div key={c.id} className="flex items-center justify-between p-4 text-sm">
              <div>
                <p className="font-medium">{c.name}</p>
                <p className="text-muted text-xs">{c.email}</p>
              </div>
              <span className="text-xs text-muted">Since {new Date(c.created_at).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
