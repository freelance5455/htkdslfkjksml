import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState, AiBadge } from "../components/States";

interface Analytics {
  hasData: boolean;
  totalSalesCents: number;
  orderCount: number;
  visitorCount: number;
  topProducts: { name: string; units_sold: string }[];
}
interface Order {
  id: string;
  customer_name: string | null;
  total_cents: number;
  status: string;
}

function money(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [productCount, setProductCount] = useState(0);
  const [insight, setInsight] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const [a, o, p] = await Promise.all([
        api.getAnalytics() as Promise<Analytics>,
        api.getOrders() as Promise<Order[]>,
        api.getProducts() as Promise<unknown[]>,
      ]);
      setAnalytics(a);
      setOrders(o.slice(0, 5));
      setProductCount(p.length);

      if (a.hasData) {
        try {
          const res = (await api.aiBusinessAssistant(
            `Given this store data: ${JSON.stringify(a)}, give one short, specific suggestion (one sentence) for what to feature or improve.`
          )) as { answer: string };
          setInsight(res.answer);
        } catch {
          setInsight(null); // AI not configured — just omit the insight, don't fabricate one
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load your dashboard.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  if (loading) return <LoadingSpinner label="Loading your dashboard…" />;
  if (error) return <ErrorMessage message={error} onRetry={load} />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card p-5">
          <p className="text-xs text-muted font-medium">Total sales</p>
          <p className="text-2xl font-bold mt-1">{money(analytics?.totalSalesCents ?? 0)}</p>
        </div>
        <div className="glass-card p-5">
          <p className="text-xs text-muted font-medium">Orders</p>
          <p className="text-2xl font-bold mt-1">{analytics?.orderCount ?? 0}</p>
        </div>
        <div className="glass-card p-5">
          <p className="text-xs text-muted font-medium">Products</p>
          <p className="text-2xl font-bold mt-1">{productCount}</p>
        </div>
        <div className="glass-card p-5">
          <p className="text-xs text-muted font-medium">Store visitors</p>
          <p className="text-2xl font-bold mt-1">{analytics?.visitorCount ?? 0}</p>
        </div>
      </div>

      <div className="glass-card p-6">
        <h2 className="font-semibold mb-4">Recent orders</h2>
        {orders.length === 0 ? (
          <EmptyState
            title="No orders yet"
            description="Orders will show up here as soon as your storefront gets its first sale."
          />
        ) : (
          <div className="divide-y divide-black/5">
            {orders.map((o) => (
              <div key={o.id} className="flex items-center justify-between py-3 text-sm">
                <div>
                  <p className="font-medium">#{o.id.slice(0, 8)} — {o.customer_name ?? "Guest"}</p>
                  <p className="text-muted text-xs">{money(o.total_cents)}</p>
                </div>
                <span className="badge-demo bg-indigo-50 text-accent border-indigo-100 capitalize">{o.status}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="glass-card p-6">
        <div className="flex items-center gap-2 mb-3">
          <h2 className="font-semibold">Insight</h2>
          {insight && <AiBadge />}
        </div>
        {insight ? (
          <p className="text-sm text-ink bg-indigo-50/60 rounded-xl p-4">{insight}</p>
        ) : (
          <EmptyState
            title="Not enough data yet"
            description="Once your store has real orders or visitors, insights will appear here."
            action={
              <Link to="/app/product-finder" className="btn-secondary text-sm">
                Find products to sell
              </Link>
            }
          />
        )}
      </div>
    </div>
  );
}
