import React, { useState } from "react";
import { api, ApiError } from "../services/api";
import { AiBadge } from "../components/States";

interface Message {
  role: "user" | "assistant";
  content: string;
  isError?: boolean;
}

const SUGGESTIONS = [
  "How can I improve my product page?",
  "Which products should I feature?",
  "Give me ideas for my homepage.",
];

export default function AIAssistant() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);

  async function send(question: string) {
    if (!question.trim() || sending) return;
    setMessages((m) => [...m, { role: "user", content: question }]);
    setInput("");
    setSending(true);
    try {
      const res = (await api.aiBusinessAssistant(question)) as { answer: string };
      setMessages((m) => [...m, { role: "assistant", content: res.answer }]);
    } catch (err) {
      setMessages((m) => [
        ...m,
        {
          role: "assistant",
          isError: true,
          content: err instanceof ApiError ? err.message : "Something went wrong. Please try again.",
        },
      ]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="max-w-2xl space-y-5">
      <div className="flex items-center gap-2">
        <h1 className="text-2xl font-bold">AI Assistant</h1>
        <AiBadge />
      </div>

      <div className="glass-card p-5 min-h-[300px] flex flex-col gap-3">
        {messages.length === 0 && (
          <div className="flex flex-wrap gap-2">
            {SUGGESTIONS.map((s) => (
              <button key={s} onClick={() => send(s)} className="btn-secondary text-xs">
                {s}
              </button>
            ))}
          </div>
        )}
        {messages.map((m, i) => (
          <div
            key={i}
            className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm ${
              m.role === "user"
                ? "bg-accent text-white self-end rounded-br-sm"
                : m.isError
                ? "bg-red-50 text-red-700 self-start rounded-bl-sm"
                : "bg-white self-start rounded-bl-sm shadow-sm"
            }`}
          >
            {m.content}
          </div>
        ))}
        {sending && <div className="text-sm text-muted self-start">Thinking…</div>}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="flex gap-2"
      >
        <input
          className="input-field"
          placeholder="Ask about your store…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button className="btn-primary shrink-0" disabled={sending}>Send</button>
      </form>
    </div>
  );
}
