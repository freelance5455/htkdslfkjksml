import React from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Settings() {
  const { user, store, logout } = useAuth();
  const navigate = useNavigate();

  async function handleLogout() {
    await logout();
    navigate("/");
  }

  return (
    <div className="space-y-5 max-w-2xl">
      <h1 className="text-2xl font-bold">Settings</h1>

      <div className="glass-card p-6">
        <h2 className="font-semibold mb-4">Account</h2>
        <dl className="space-y-3 text-sm">
          <div className="flex justify-between">
            <dt className="text-muted">Name</dt>
            <dd className="font-medium">{user?.name}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted">Email</dt>
            <dd className="font-medium">{user?.email}</dd>
          </div>
        </dl>
      </div>

      <div className="glass-card p-6">
        <h2 className="font-semibold mb-2">Store</h2>
        <p className="text-sm text-muted mb-3">Store name, tagline, description and currency live in the Store Editor.</p>
        <Link to="/app/store-editor" className="btn-secondary text-sm">Open Store Editor</Link>
      </div>

      <div className="glass-card p-6">
        <h2 className="font-semibold mb-2">Integrations</h2>
        <p className="text-sm text-muted">
          No payment provider or fulfillment supplier is connected. Product Finder currently pulls real
          product data from a public catalog for discovery — connecting a real supplier account or
          payment processor is a separate step, wired through the backend's <code>SupplierProvider</code> interface.
        </p>
      </div>

      <div className="glass-card p-6">
        <h2 className="font-semibold mb-2">Security</h2>
        <p className="text-sm text-muted mb-3">
          Signed in as {store ? <span className="font-medium text-ink">{store.name}</span> : "your account"}.
        </p>
        <button className="btn-secondary text-sm" onClick={handleLogout}>Log out</button>
      </div>
    </div>
  );
}
