import React, { useEffect, useState } from "react";
import { api } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState } from "../components/States";

interface AnalyticsData {
  hasData: boolean;
  totalSalesCents: number;
  orderCount: number;
  visitorCount: number;
  conversionRate: number;
  topProducts: { name: string; units_sold: string }[];
}

export default function Analytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setData((await api.getAnalytics()) as AnalyticsData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load analytics.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  if (loading) return <LoadingSpinner label="Loading analytics…" />;
  if (error) return <ErrorMessage message={error} onRetry={load} />;

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Analytics</h1>

      {!data?.hasData ? (
        <EmptyState
          title="No sales data yet"
          description="Once your storefront has real visitors and orders, your metrics will show up here."
        />
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="glass-card p-5">
              <p className="text-xs text-muted font-medium">Sales</p>
              <p className="text-2xl font-bold mt-1">${(data.totalSalesCents / 100).toFixed(2)}</p>
            </div>
            <div className="glass-card p-5">
              <p className="text-xs text-muted font-medium">Orders</p>
              <p className="text-2xl font-bold mt-1">{data.orderCount}</p>
            </div>
            <div className="glass-card p-5">
              <p className="text-xs text-muted font-medium">Visitors</p>
              <p className="text-2xl font-bold mt-1">{data.visitorCount}</p>
            </div>
            <div className="glass-card p-5">
              <p className="text-xs text-muted font-medium">Conversion rate</p>
              <p className="text-2xl font-bold mt-1">{(data.conversionRate * 100).toFixed(1)}%</p>
            </div>
          </div>

          <div className="glass-card p-6">
            <h2 className="font-semibold mb-4">Top products</h2>
            {data.topProducts.length === 0 ? (
              <p className="text-sm text-muted">No product sales recorded yet.</p>
            ) : (
              <div className="divide-y divide-black/5">
                {data.topProducts.map((p) => (
                  <div key={p.name} className="flex justify-between py-2 text-sm">
                    <span>{p.name}</span>
                    <span className="text-muted">{p.units_sold} sold</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
