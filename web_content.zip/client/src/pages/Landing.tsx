import React from "react";
import { Link } from "react-router-dom";

const FEATURES = [
  { title: "AI Store Builder", desc: "Describe your store in plain language and get a full draft — name, categories, and copy — ready to review." },
  { title: "AI Product Generator", desc: "Upload a product photo and get an editable title, description, and tags in seconds." },
  { title: "Product Discovery", desc: "Browse real product data with estimated costs and margins to plan what to sell." },
  { title: "Smart Pricing Suggestions", desc: "See suggested retail prices and estimated margins before you commit to a product." },
  { title: "Store Customization", desc: "A visual editor for your homepage sections, colors, and typography." },
  { title: "Order Management", desc: "Track orders from pending to delivered in one clean view." },
  { title: "Analytics", desc: "Real sales and visitor metrics — shown honestly, with no data until you have real activity." },
  { title: "AI Business Assistant", desc: "Ask for product-page feedback, captions, or homepage ideas, scoped to your own store." },
];

const STEPS = [
  "Tell AI what you want to sell",
  "AI builds your store",
  "Add products",
  "Customize your storefront",
  "Start selling",
];

const FAQS = [
  { q: "Is AI Reseller really free to start?", a: "Yes — creating your account and building your store with AI Reseller has no cost. Real supplier costs, shipping, and any paid AI usage beyond the free tier are separate and clearly shown wherever they apply." },
  { q: "Do I need a supplier already?", a: "No. Product Finder shows real product data from a public catalog so you can plan your store; connecting a fulfillment supplier account is a separate step." },
  { q: "Can I accept real payments today?", a: "Checkout is marked as \"coming soon\" in this MVP — we don't simulate fake successful payments." },
  { q: "Will AI make up product specs?", a: "No. The AI Product Generator only describes what's visible in your image or given information, and avoids inventing exact technical specs." },
];

export default function Landing() {
  return (
    <div>
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pt-16 sm:pt-24 pb-16 text-center">
        <div className="fade-in">
          <span className="badge-demo bg-indigo-50 text-accent border-indigo-100">✦ Free to start</span>
          <h1 className="mt-6 text-4xl sm:text-6xl font-extrabold tracking-tight text-ink">
            Build Your Online Store <span className="text-accent">With AI</span>
          </h1>
          <p className="mt-5 text-lg text-muted max-w-2xl mx-auto">
            Create, customize and manage your online store with AI — without complicated setup.
          </p>
          <div className="mt-8 flex items-center justify-center gap-4 flex-wrap">
            <Link to="/signup" className="btn-primary text-base px-6 py-3">Build My Store Free</Link>
            <a href="#features" className="btn-secondary text-base px-6 py-3">Explore Features</a>
          </div>
        </div>

        <div className="mt-16 slide-up">
          <div className="glass-card mx-auto max-w-4xl p-3 sm:p-4">
            <div className="rounded-xl bg-gradient-to-br from-indigo-50 to-white p-6 sm:p-10">
              <div className="grid grid-cols-3 gap-4 text-left">
                <div className="col-span-1 glass-card p-4 space-y-3">
                  <div className="h-2 w-16 bg-accent/30 rounded-full" />
                  <div className="h-2 w-12 bg-black/10 rounded-full" />
                  <div className="h-2 w-14 bg-black/10 rounded-full" />
                  <div className="h-2 w-10 bg-black/10 rounded-full" />
                </div>
                <div className="col-span-2 space-y-3">
                  <div className="glass-card p-4 h-24 flex items-center px-6">
                    <div className="h-3 w-40 bg-accent/40 rounded-full" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="glass-card p-4 h-20" />
                    <div className="glass-card p-4 h-20" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">Everything you need to start selling</h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {FEATURES.map((f) => (
            <div key={f.title} className="glass-card p-5 hover:shadow-lg transition-shadow">
              <h3 className="font-semibold mb-2">{f.title}</h3>
              <p className="text-sm text-muted">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="how-it-works" className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">How it works</h2>
        <ol className="space-y-4">
          {STEPS.map((s, i) => (
            <li key={s} className="glass-card p-5 flex items-center gap-4">
              <span className="h-9 w-9 shrink-0 rounded-full bg-accent text-white flex items-center justify-center font-semibold">
                {i + 1}
              </span>
              <span className="text-ink font-medium">{s}</span>
            </li>
          ))}
        </ol>
      </section>

      <section id="faq" className="max-w-3xl mx-auto px-4 sm:px-6 py-16">
        <h2 className="text-2xl sm:text-3xl font-bold text-center mb-10">Frequently asked questions</h2>
        <div className="space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="glass-card p-5 group">
              <summary className="font-medium cursor-pointer list-none flex justify-between items-center">
                {f.q}
                <span className="text-muted group-open:rotate-45 transition-transform">+</span>
              </summary>
              <p className="text-sm text-muted mt-3">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-16 text-center">
        <div className="glass-card p-10 sm:p-14">
          <h2 className="text-2xl sm:text-3xl font-bold">Your AI-powered store. Start free.</h2>
          <Link to="/signup" className="btn-primary mt-6 inline-flex text-base px-6 py-3">
            Build My Store Free
          </Link>
        </div>
      </section>
    </div>
  );
}
