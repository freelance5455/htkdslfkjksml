import { useMemo, useRef, useState } from "react";
import { trpc } from "@/lib/trpc";
import { startLogin } from "@/const";
import {
  ArrowRight,
  AtSign,
  Bell,
  Camera,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  FileAudio,
  Heart,
  ImagePlus,
  LayoutGrid,
  LogIn,
  Menu,
  MessageCircle,
  Mic,
  MoreHorizontal,
  Palette,
  Paperclip,
  Phone,
  Play,
  Plus,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  Smile,
  Sparkles,
  UserPlus,
  UserRound,
  UsersRound,
  Video,
  X,
} from "lucide-react";

type ThemeKey = "coral" | "violet" | "ocean";
type Message = { id: number; text?: string; time: string; mine?: boolean; type?: "audio" | "image"; duration?: string };
type Chat = { id: string; name: string; handle: string; initials: string; status: string; last: string; time: string; unread?: number; theme: ThemeKey; avatar: string; verified?: boolean; group?: boolean; members?: number };

const chats: Chat[] = [
  { id: "derya", name: "Derya Aksoy", handle: "@deryaak", initials: "DA", status: "Şu an aktif", last: "Kamerayı açtım, bak!", time: "21:42", unread: 3, theme: "coral", avatar: "avatar-coral", verified: true },
  { id: "studio", name: "Sohbetly Studio", handle: "@studio", initials: "SS", status: "5 kişi aktif", last: "Mert: Yeni fikir hazır ✨", time: "20:18", unread: 8, theme: "violet", avatar: "avatar-violet", group: true, members: 128 },
  { id: "mert", name: "Mert Can", handle: "@mertcan", initials: "MC", status: "Son görülme 8 dk önce", last: "Ses kaydını dinledin mi?", time: "18:06", theme: "ocean", avatar: "avatar-blue" },
  { id: "gece", name: "Gece Kuşları", handle: "@gecekuslari", initials: "GK", status: "3 kişi aktif", last: "Ece: Bugün 23:00'te oradayız", time: "17:34", theme: "violet", avatar: "avatar-ink", group: true, members: 14 },
  { id: "selin", name: "Selin Yılmaz", handle: "@seliny", initials: "SY", status: "Son görülme dün", last: "Harika görünüyorsun!", time: "Salı", theme: "coral", avatar: "avatar-lilac" },
];

const initialMessages: Record<string, Message[]> = {
  derya: [
    { id: 1, text: "Selam! Günün nasıl geçiyor?", time: "21:34" },
    { id: 2, text: "İyi gidiyor, birazdan dışarı çıkacağım. Sen?", time: "21:35", mine: true },
    { id: 3, text: "Ben de sahile indim, hava inanılmaz güzel.", time: "21:36" },
    { id: 4, type: "image", time: "21:40", mine: true },
    { id: 5, text: "Kamerayı açtım, bak!", time: "21:42" },
  ],
  studio: [{ id: 10, text: "Yeni hafta, yeni fikirler. Herkes hazır mı?", time: "20:10" }, { id: 11, text: "Mert: Yeni fikir hazır ✨", time: "20:18" }],
  mert: [{ id: 20, text: "Bugün kısa bir ses kaydı bırakacağım.", time: "18:02" }, { id: 21, type: "audio", duration: "0:18", time: "18:06" }],
  gece: [{ id: 30, text: "Bu akşam buluşuyor muyuz?", time: "17:28" }, { id: 31, text: "Ece: Bugün 23:00'te oradayız", time: "17:34" }],
  selin: [{ id: 40, text: "Geçen gün paylaştığın fotoğraf çok güzeldi.", time: "Salı" }],
};

const people = [
  { name: "Ece Karaca", handle: "@ecekaraca", initials: "EK", bio: "Kahve, tasarım ve şehir hikayeleri.", avatar: "avatar-mint" },
  { name: "Arda Şen", handle: "@ardasen", initials: "AŞ", bio: "Ürün tasarlıyor, dünyayı geziyor.", avatar: "avatar-blue" },
  { name: "İpek Aydın", handle: "@ipekayd", initials: "İA", bio: "Film notları ve küçük mutluluklar.", avatar: "avatar-coral" },
];

const themeOptions: { key: ThemeKey; label: string; colors: string }[] = [
  { key: "coral", label: "Gün batımı", colors: "#ff6b57, #ff9a76" },
  { key: "violet", label: "Mor saat", colors: "#7667f5, #c385ff" },
  { key: "ocean", label: "Okyanus", colors: "#0d9fb4, #56d7c5" },
];

function Avatar({ chat, size = "md" }: { chat: Pick<Chat, "initials" | "avatar">; size?: "sm" | "md" | "lg" | "xl" }) {
  return <div className={`avatar ${chat.avatar} avatar-${size}`} aria-hidden="true">{chat.initials}</div>;
}

function IconButton({ label, children, onClick, active = false }: { label: string; children: React.ReactNode; onClick?: () => void; active?: boolean }) {
  return <button className={`icon-button ${active ? "is-active" : ""}`} aria-label={label} title={label} onClick={onClick}>{children}</button>;
}

export default function Home() {
  const { data: user } = trpc.auth.me.useQuery();
  const [activeNav, setActiveNav] = useState("Sohbetler");
  const [activeChatId, setActiveChatId] = useState("derya");
  const [search, setSearch] = useState("");
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState(initialMessages);
  const [theme, setTheme] = useState<ThemeKey>("coral");
  const [themeOpen, setThemeOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [mobileListOpen, setMobileListOpen] = useState(false);
  const [groupModalOpen, setGroupModalOpen] = useState(false);
  const [groupName, setGroupName] = useState("");
  const [recording, setRecording] = useState(false);
  const [capturedMedia, setCapturedMedia] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const activeChat = chats.find((chat) => chat.id === activeChatId) ?? chats[0];
  const currentMessages = messages[activeChat.id] ?? [];
  const filteredChats = useMemo(() => chats.filter((chat) => `${chat.name} ${chat.handle} ${chat.last}`.toLowerCase().includes(search.toLowerCase())), [search]);

  const selectChat = (id: string) => {
    setActiveChatId(id);
    const next = chats.find((chat) => chat.id === id);
    if (next) setTheme(next.theme);
    setMobileListOpen(false);
  };

  const sendMessage = () => {
    const value = draft.trim();
    if (!value) return;
    setMessages((prev) => ({ ...prev, [activeChat.id]: [...(prev[activeChat.id] ?? []), { id: Date.now(), text: value, time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }), mine: true }] }));
    setDraft("");
  };

  const addMedia = (file?: File) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setCapturedMedia(url);
    setMessages((prev) => ({ ...prev, [activeChat.id]: [...(prev[activeChat.id] ?? []), { id: Date.now(), type: file.type.startsWith("audio") ? "audio" : "image", duration: file.type.startsWith("audio") ? "0:12" : undefined, time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }), mine: true }] }));
  };

  const toggleRecording = () => {
    setRecording((value) => !value);
    if (recording) {
      setMessages((prev) => ({ ...prev, [activeChat.id]: [...(prev[activeChat.id] ?? []), { id: Date.now(), type: "audio", duration: "0:08", time: new Date().toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }), mine: true }] }));
    }
  };

  const createGroup = () => {
    if (!groupName.trim()) return;
    setGroupModalOpen(false);
    setGroupName("");
  };

  const renderMain = () => {
    if (activeNav === "Keşfet") {
      return <section className="page-section discovery-page"><div className="page-heading"><div><span className="eyebrow">YENİ İNSANLAR</span><h1>Keşfet</h1><p>Seninle aynı frekanstaki insanları bul.</p></div><button className="ghost-button"><SlidersIcon /> Filtrele</button></div><div className="people-grid">{people.map((person) => <article className="person-card" key={person.handle}><div className="person-card-top"><div className={`avatar ${person.avatar} avatar-xl`}>{person.initials}</div><button className="more-button"><MoreHorizontal size={18} /></button></div><h3>{person.name}</h3><span className="handle">{person.handle}</span><p>{person.bio}</p><button className="outline-button" onClick={() => setActiveNav("İstekler")}><UserPlus size={16} /> Bağlantı isteği</button></article>)}</div><div className="discovery-banner"><div className="banner-orb"><Sparkles size={24} /></div><div><strong>Topluluklara göz at</strong><p>İlgi alanına göre yeni gruplar keşfet.</p></div><ArrowRight size={20} /></div></section>;
    }
    if (activeNav === "İstekler") {
      return <section className="page-section"><div className="page-heading"><div><span className="eyebrow">BAĞLANTILAR</span><h1>İstekler</h1><p>Yeni bağlantılarını burada yönet.</p></div><span className="count-badge">3 yeni</span></div><div className="requests-list">{people.map((person, index) => <article className="request-row" key={person.handle}><div className={`avatar ${person.avatar} avatar-md`}>{person.initials}</div><div className="request-copy"><strong>{person.name}</strong><span>{person.handle} · {index === 0 ? "Ortak 4 bağlantı" : "Yeni keşif"}</span></div><div className="request-actions"><button className="accept-button"><Check size={16} /> Kabul et</button><button className="reject-button"><X size={16} /></button></div></article>)}</div></section>;
    }
    if (activeNav === "Profil") {
      return <section className="page-section profile-page"><div className="profile-hero"><div className="profile-avatar-wrap"><div className="avatar avatar-coral avatar-xxl">{user?.name?.slice(0, 2).toUpperCase() ?? "SY"}</div><span className="online-dot" /></div><div className="profile-hero-copy"><span className="eyebrow">PROFİLİM</span><h1>{user?.name ?? "Selin Yılmaz"}</h1><span className="handle"><AtSign size={14} /> {user?.email?.split("@")[0] ?? "seliny"}</span><p>İnsanları, fikirleri ve iyi sohbetleri bir araya getiriyorum.</p><button className="outline-button">Profili düzenle <ArrowRight size={15} /></button></div><div className="profile-stat"><strong>24</strong><span>bağlantı</span></div><div className="profile-stat"><strong>8</strong><span>grup</span></div></div><div className="profile-panels"><article><div className="panel-title"><strong>Hakkımda</strong><button className="edit-link">Düzenle</button></div><p>Meraklı bir zihin, iyi bir playlist ve uzun yürüyüşler. Burada gerçek sohbetlerin peşindeyim.</p><div className="profile-tags"><span>tasarım</span><span>müzik</span><span>fotoğraf</span></div></article><article><div className="panel-title"><strong>Paylaşılan anlar</strong><span className="muted">12 medya</span></div><div className="media-strip"><div className="media-tile gradient-one"><Camera size={17} /></div><div className="media-tile gradient-two"><Heart size={17} /></div><div className="media-tile gradient-three"><Play size={17} /></div><div className="media-tile add-media"><Plus size={18} /></div></div></article></div></section>;
    }
    if (activeNav === "Ayarlar") {
      return <section className="page-section settings-page"><div className="page-heading"><div><span className="eyebrow">KONTROL MERKEZİ</span><h1>Ayarlar</h1><p>Sohbetly deneyimini kendine göre düzenle.</p></div></div><div className="settings-list"><button><div className="settings-icon"><Bell size={18} /></div><div><strong>Bildirimler</strong><span>Mesaj ve bağlantı uyarıları</span></div><ChevronRight size={18} /></button><button><div className="settings-icon"><ShieldCheck size={18} /></div><div><strong>Gizlilik ve güvenlik</strong><span>Kimlerin sana ulaşabileceğini seç</span></div><ChevronRight size={18} /></button><button><div className="settings-icon"><Palette size={18} /></div><div><strong>Görünüm</strong><span>Renk, yoğunluk ve yazı boyutu</span></div><ChevronRight size={18} /></button><button><div className="settings-icon"><CircleHelp size={18} /></div><div><strong>Yardım merkezi</strong><span>İhtiyacın olduğunda buradayız</span></div><ChevronRight size={18} /></button></div></section>;
    }
    return <MessagesView activeChat={activeChat} activeChatId={activeChatId} currentMessages={currentMessages} filteredChats={filteredChats} search={search} setSearch={setSearch} selectChat={selectChat} mobileListOpen={mobileListOpen} setMobileListOpen={setMobileListOpen} theme={theme} setTheme={setTheme} themeOpen={themeOpen} setThemeOpen={setThemeOpen} draft={draft} setDraft={setDraft} sendMessage={sendMessage} recording={recording} toggleRecording={toggleRecording} fileRef={fileRef} cameraRef={cameraRef} addMedia={addMedia} capturedMedia={capturedMedia} />;
  };

  return <div className={`app-shell theme-${theme}`}>
    <aside className="sidebar">
      <div className="brand-mark"><div className="brand-symbol"><MessageCircle size={18} fill="currentColor" /></div><span>sohbetly</span><span className="brand-dot" /></div>
      <div className="sidebar-label">MENÜ</div>
      <nav className="main-nav">{[["Sohbetler", MessageCircle], ["Keşfet", LayoutGrid], ["İstekler", UserPlus], ["Profil", UserRound], ["Ayarlar", Settings2]].map(([label, Icon]) => <button key={label as string} className={activeNav === label ? "active" : ""} onClick={() => setActiveNav(label as string)}><Icon size={18} /><span>{label as string}</span>{label === "İstekler" && <b className="nav-count">3</b>}</button>)}</nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-promo"><div className="promo-icon"><Sparkles size={15} /></div><strong>İyi sohbet,<br />iyi hissettirir.</strong><span>Bugün 12 kişiyle tanıştın.</span><div className="promo-progress"><i /></div></div>
      <div className="sidebar-user"><div className="avatar avatar-coral avatar-sm">{user?.name?.slice(0, 2).toUpperCase() ?? "SY"}</div><div><strong>{user?.name ?? "Selin Yılmaz"}</strong><span>{user ? "Çevrimiçi" : "Önizleme modu"}</span></div><ChevronDown size={15} /></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileListOpen((value) => !value)}><Menu size={20} /></button><div className="mobile-brand"><div className="brand-symbol"><MessageCircle size={15} fill="currentColor" /></div><span>sohbetly</span></div><div className="topbar-search"><Search size={16} /><input placeholder="Kullanıcı veya sohbet ara..." value={search} onChange={(event) => setSearch(event.target.value)} /><kbd>⌘ K</kbd></div><div className="topbar-actions"><button className="notification-button"><Bell size={18} /><i /></button>{user ? <button className="top-user" onClick={() => setProfileOpen((value) => !value)}><div className="avatar avatar-coral avatar-sm">{user.name?.slice(0, 2).toUpperCase() ?? "SY"}</div><ChevronDown size={14} /></button> : <button className="login-button" onClick={() => startLogin()}><LogIn size={15} /> Giriş yap</button>}{profileOpen && <div className="profile-menu"><strong>{user?.name ?? "Sohbetly kullanıcısı"}</strong><span>Hesabını yönet</span><button onClick={() => setActiveNav("Profil")}>Profilim <ArrowRight size={14} /></button></div>}</div></header>
      <div className="content-area">{renderMain()}</div>
    </main>
    <nav className="mobile-bottom-nav" aria-label="Mobil gezinme">{[["Sohbetler", MessageCircle], ["Keşfet", LayoutGrid], ["İstekler", UserPlus], ["Profil", UserRound]].map(([label, Icon]) => <button key={label as string} className={activeNav === label ? "active" : ""} onClick={() => setActiveNav(label as string)}><Icon size={18} /><span>{label as string}</span>{label === "İstekler" && <b>3</b>}</button>)}</nav>
    {groupModalOpen && <div className="modal-backdrop" onClick={() => setGroupModalOpen(false)}><div className="modal-card" onClick={(event) => event.stopPropagation()}><div className="modal-heading"><div><span className="eyebrow">YENİ TOPLULUK</span><h2>Grubunu kur</h2></div><IconButton label="Kapat" onClick={() => setGroupModalOpen(false)}><X size={18} /></IconButton></div><label>Grup adı<input autoFocus value={groupName} onChange={(event) => setGroupName(event.target.value)} placeholder="Örn. Pazar kahvesi" /></label><div className="invite-preview"><div className="avatar avatar-violet avatar-sm">SY</div><span>Selin ve seçtiğin bağlantılar</span><CheckCircle2 size={16} /></div><button className="primary-button full" onClick={createGroup}>Grubu oluştur <ArrowRight size={16} /></button></div></div>}
    <button className="floating-new" onClick={() => setGroupModalOpen(true)}><Plus size={17} /> Yeni grup</button>
  </div>;
}

function SlidersIcon() { return <Settings2 size={16} />; }

type MessagesViewProps = { activeChat: Chat; activeChatId: string; currentMessages: Message[]; filteredChats: Chat[]; search: string; setSearch: (value: string) => void; selectChat: (id: string) => void; mobileListOpen: boolean; setMobileListOpen: (value: boolean) => void; theme: ThemeKey; setTheme: (theme: ThemeKey) => void; themeOpen: boolean; setThemeOpen: (value: boolean) => void; draft: string; setDraft: (value: string) => void; sendMessage: () => void; recording: boolean; toggleRecording: () => void; fileRef: React.RefObject<HTMLInputElement | null>; cameraRef: React.RefObject<HTMLInputElement | null>; addMedia: (file?: File) => void; capturedMedia: string | null };

function MessagesView({ activeChat, activeChatId, currentMessages, filteredChats, search, setSearch, selectChat, mobileListOpen, setMobileListOpen, theme, setTheme, themeOpen, setThemeOpen, draft, setDraft, sendMessage, recording, toggleRecording, fileRef, cameraRef, addMedia, capturedMedia }: MessagesViewProps) {
  return <section className="messages-layout">
    <div className={`conversation-list ${mobileListOpen ? "mobile-open" : ""}`}>
      <div className="conversation-header"><div><span className="eyebrow">MESAJLAR</span><h1>Sohbetlerin</h1></div><IconButton label="Yeni sohbet"><Plus size={18} /></IconButton></div>
      <div className="conversation-tabs"><button className="selected">Tümü <span>8</span></button><button>Okunmamış <span>3</span></button></div>
      <div className="conversation-search"><Search size={15} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Sohbetlerde ara" /></div>
      <div className="chat-list">{filteredChats.map((chat) => <button key={chat.id} className={`chat-row ${chat.id === activeChatId ? "selected" : ""}`} onClick={() => selectChat(chat.id)}><div className="avatar-wrap"><Avatar chat={chat} size="md" />{chat.status.includes("aktif") && <i className="online-dot small" />}</div><div className="chat-row-copy"><div><strong>{chat.name}</strong>{chat.verified && <CheckCircle2 className="verified" size={13} />}</div><span>{chat.last}</span></div><div className="chat-row-meta"><time>{chat.time}</time>{chat.unread && <b>{chat.unread}</b>}</div></button>)}</div>
      <button className="new-group-row"><div className="add-group-icon"><UsersRound size={18} /></div><div><strong>Yeni grup sohbeti</strong><span>Birlikte konuşmaya başla</span></div><ChevronRight size={16} /></button>
      {mobileListOpen && <button className="mobile-close" onClick={() => setMobileListOpen(false)}>Sohbete dön <ArrowRight size={14} /></button>}
    </div>
    <div className={`chat-panel theme-${theme}`}>
      <header className="chat-header"><div className="chat-header-main"><Avatar chat={activeChat} size="lg" /><div><h2>{activeChat.name}{activeChat.verified && <CheckCircle2 className="verified" size={15} />}</h2><span><i className="online-dot inline" /> {activeChat.status}</span></div></div><div className="chat-header-actions"><IconButton label="Sesli ara"><Phone size={18} /></IconButton><IconButton label="Görüntülü ara"><Video size={18} /></IconButton><div className="theme-picker"><IconButton label="Sohbet temasını değiştir" active={themeOpen} onClick={() => setThemeOpen(!themeOpen)}><Palette size={18} /></IconButton>{themeOpen && <div className="theme-popover"><span>Bu sohbetin teması</span>{themeOptions.map((option) => <button key={option.key} className={theme === option.key ? "picked" : ""} onClick={() => { setTheme(option.key); setThemeOpen(false); }}><i style={{ background: `linear-gradient(135deg, ${option.colors})` }} />{option.label}{theme === option.key && <Check size={14} />}</button>)}</div>}</div><IconButton label="Daha fazla"><MoreHorizontal size={19} /></IconButton></div></header>
      <div className="chat-meta-strip"><span>{activeChat.group ? `${activeChat.members} üye` : "Bağlantıların arasında"}</span><div><ShieldCheck size={14} /> Uçtan uca şifreli</div></div>
      <div className="messages-scroll"><div className="day-divider"><span>BUGÜN</span></div><div className="message-stack">{currentMessages.map((message) => <div key={message.id} className={`message-line ${message.mine ? "mine" : ""}`}>{!message.mine && <Avatar chat={activeChat} size="sm" />}<div className="message-body">{message.type === "image" ? <div className="message-image"><div className="image-art" style={capturedMedia ? { backgroundImage: `url(${capturedMedia})` } : undefined}><Camera size={20} /></div><span>Fotoğraf</span></div> : message.type === "audio" ? <div className="audio-message"><button><Play size={13} fill="currentColor" /></button><div className="audio-wave">{Array.from({ length: 18 }).map((_, index) => <i key={index} style={{ height: `${8 + ((index * 7) % 16)}px` }} />)}</div><span>{message.duration}</span></div> : <div className="bubble">{message.text}</div>}<time>{message.time}{message.mine && <Check size={13} />}</time></div></div>)}</div><div className="typing-row"><span><i /><i /><i /></span> {activeChat.name.split(" ")[0]} yazıyor...</div></div>
      <div className="composer-wrap"><div className="composer"><div className="composer-tools"><IconButton label="Dosya ekle" onClick={() => fileRef.current?.click()}><Paperclip size={18} /></IconButton><IconButton label="Fotoğraf yükle" onClick={() => fileRef.current?.click()}><ImagePlus size={18} /></IconButton><IconButton label="Kamera aç" onClick={() => cameraRef.current?.click()}><Camera size={18} /></IconButton></div><input aria-label="Mesaj yaz" placeholder={`${activeChat.name.split(" ")[0]} için bir şeyler yaz...`} value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") sendMessage(); }} /><button className={`record-button ${recording ? "recording" : ""}`} onClick={toggleRecording} aria-label={recording ? "Kaydı durdur" : "Sesli mesaj kaydet"}>{recording ? <span className="recording-dot" /> : <Mic size={18} />}</button><button className="send-button" onClick={sendMessage} aria-label="Gönder"><Send size={17} /></button></div><div className="composer-hint"><span><Smile size={13} /> Enter ile gönder</span><span>{recording ? "Ses kaydı yapılıyor — durdurmak için mikrofona dokun" : "Sesli mesaj için mikrofona basılı tut"}</span></div></div><input ref={fileRef} className="hidden-input" type="file" accept="image/*,video/*,audio/*" onChange={(event) => addMedia(event.target.files?.[0])} /><input ref={cameraRef} className="hidden-input" type="file" accept="image/*" capture="environment" onChange={(event) => addMedia(event.target.files?.[0])} />
    </div>
    <aside className="details-panel"><div className="details-heading"><span>SOHBET DETAYI</span><IconButton label="Daha fazla"><MoreHorizontal size={17} /></IconButton></div><div className="details-profile"><Avatar chat={activeChat} size="xl" /><h3>{activeChat.name}</h3><span>{activeChat.handle}</span><p>{activeChat.group ? "İyi fikirleri paylaşmak için küçük bir alan." : "İyi sohbet, doğru anda gelen küçük bir gülümsemedir."}</p><div className="detail-actions"><button><Phone size={16} /> Ara</button><button><Video size={16} /> Video</button></div></div><div className="details-section"><div className="details-section-title"><strong>Paylaşılan medya</strong><button>Hepsini gör <ArrowRight size={13} /></button></div><div className="shared-grid"><div className="shared-card shared-a"><Camera size={15} /></div><div className="shared-card shared-b"><Heart size={15} /></div><div className="shared-card shared-c"><Play size={15} /></div></div></div><div className="details-section"><div className="details-section-title"><strong>Ortak gruplar</strong><span>2</span></div><div className="mutual-group"><div className="mini-group-icon"><UsersRound size={16} /></div><div><strong>Gece Kuşları</strong><span>14 üye</span></div><ChevronRight size={15} /></div><div className="mutual-group"><div className="mini-group-icon warm"><Sparkles size={16} /></div><div><strong>Sohbetly Studio</strong><span>128 üye</span></div><ChevronRight size={15} /></div></div><div className="privacy-note"><ShieldCheck size={15} /><span>Mesajların sadece bu sohbetteki kişiler tarafından görülebilir.</span></div></aside>
  </section>;
}
