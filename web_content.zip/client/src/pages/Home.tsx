import {
  Activity,
  AlertTriangle,
  ArrowDownToLine,
  ArrowLeft,
  ArrowRight,
  Box,
  Check,
  ChevronDown,
  CircleHelp,
  Cloud,
  Copy,
  Cpu,
  FileImage,
  Gamepad2,
  Globe2,
  HardDrive,
  ImagePlus,
  Info,
  Layers3,
  LoaderCircle,
  LockKeyhole,
  Monitor,
  Plus,
  Radio,
  Rocket,
  Server,
  Settings2,
  Shield,
  Sparkles,
  TerminalSquare,
  Trash2,
  Users,
  Wifi,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { toast } from "sonner";
import {
  createMinecraftProperties,
  createNebulaManifest,
  makeEmptyDraft,
  sampleVersions,
  trackLabels,
  type JavaTrack,
  type ServerDraft,
  type ServerSoftware,
} from "@shared/minecraft";
import { trpc } from "@/lib/trpc";

const STORAGE_KEY = "nebula.server-drafts.v1";
type View = "servers" | "builder" | "hosting";
const tracks: JavaTrack[] = ["old_alpha", "old_beta", "release", "snapshot"];
const colorChoices = [
  "#71e7ff",
  "#b794ff",
  "#8ce9bc",
  "#ffc779",
  "#ff8da8",
  "#f2f4ff",
];

function readDrafts(): ServerDraft[] {
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((entry): entry is ServerDraft =>
      Boolean(
        entry && typeof entry.id === "string" && typeof entry.name === "string"
      )
    );
  } catch {
    return [];
  }
}

function saveFile(filename: string, data: string, mimeType: string) {
  const blob = new Blob([data], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function ServerGlyph({
  iconData,
  size = "normal",
}: {
  iconData?: string | null;
  size?: "normal" | "small";
}) {
  if (iconData)
    return (
      <img
        className={`server-glyph ${size}`}
        src={iconData}
        alt="Иконка сервера"
      />
    );
  return (
    <div className={`server-glyph default ${size}`} aria-label="Иконка сервера">
      <Box size={size === "small" ? 19 : 23} strokeWidth={1.7} />
      <i />
    </div>
  );
}

function BrandMark({ small = false }: { small?: boolean }) {
  const [fallback, setFallback] = useState(false);
  return (
    <img
      className={small ? "brand-mark small" : "brand-mark"}
      src={
        fallback
          ? "/nebula-mark.svg"
          : "/manus-storage/async-images/XOT9PQqjuFuPsQ6pylQ21f/image-1.webp"
      }
      onError={() => setFallback(true)}
      alt=""
    />
  );
}

function Navigation({
  view,
  setView,
  draftCount,
  onNew,
}: {
  view: View;
  setView: (view: View) => void;
  draftCount: number;
  onNew: () => void;
}) {
  return (
    <aside className="sidebar">
      <button
        className="brand-lockup"
        onClick={() => setView("servers")}
        aria-label="Nebula — серверы"
      >
        <BrandMark />
        <span className="brand-word">
          nebula<span>.</span>
          <small>SERVER STUDIO</small>
        </span>
      </button>
      <div className="workspace-switcher">
        <div className="workspace-orb">
          <Gamepad2 size={15} />
        </div>
        <div>
          <strong>Моя вселенная</strong>
          <span>Личная мастерская</span>
        </div>
        <ChevronDown size={15} className="workspace-chevron" />
      </div>
      <div className="nav-caption">РАБОЧАЯ ОБЛАСТЬ</div>
      <nav className="side-nav" aria-label="Главная навигация">
        <button
          className={`nav-item ${view === "servers" ? "active" : ""}`}
          onClick={() => setView("servers")}
        >
          <Layers3 size={17} />
          <span>Мои серверы</span>
          <span className="nav-count">{draftCount}</span>
        </button>
        <button
          className={`nav-item ${view === "builder" ? "active" : ""}`}
          onClick={onNew}
        >
          <Plus size={17} />
          <span>Создать сервер</span>
        </button>
        <button
          className={`nav-item ${view === "hosting" ? "active" : ""}`}
          onClick={() => setView("hosting")}
        >
          <Globe2 size={17} />
          <span className="nav-label-desktop">Подключение хостинга</span>
          <span className="nav-label-mobile">Хостинг</span>
        </button>
      </nav>
      <div className="sidebar-spacer" />
      <div className="sidebar-provider-card">
        <div className="provider-card-top">
          <span className="status-dot muted" />
          <span>Игровой узел</span>
          <LockKeyhole size={13} />
        </div>
        <strong>Не подключён</strong>
        <p>Черновики готовы. Для запуска нужен настоящий серверный хост.</p>
        <button onClick={() => setView("hosting")}>
          Как подключить <ArrowRight size={13} />
        </button>
      </div>
      <div className="sidebar-footer">
        <span>NEBULA STUDIO</span>
        <span>v0.1 · Preview</span>
      </div>
    </aside>
  );
}

function Topbar({
  view,
  setView,
}: {
  view: View;
  setView: (view: View) => void;
}) {
  const title =
    view === "builder"
      ? "Конструктор"
      : view === "hosting"
        ? "Инфраструктура"
        : "Рабочая область";
  return (
    <header className="topbar">
      <div className="crumb">
        <span>Nebula</span>
        <span className="crumb-slash">/</span>
        <strong>{title}</strong>
      </div>
      <div className="topbar-right">
        <span className="hosting-pill">
          <i /> Хостинг не подключён
        </span>
        <button
          className="help-button"
          onClick={() => setView("hosting")}
          aria-label="О подключении хостинга"
        >
          <CircleHelp size={17} />
        </button>
        <div className="avatar-mark">
          <BrandMark small />
        </div>
      </div>
    </header>
  );
}

function Heading({
  eyebrow,
  title,
  text,
  action,
}: {
  eyebrow: string;
  title: string;
  text: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-heading">
      <div>
        <div className="eyebrow">
          <span />
          {eyebrow}
        </div>
        <h1>{title}</h1>
        <p>{text}</p>
      </div>
      {action}
    </div>
  );
}

function HostingNotice({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`hosting-notice ${compact ? "compact" : ""}`}>
      <span className="notice-icon">
        <AlertTriangle size={18} />
      </span>
      <div>
        <strong>Сайт пока не размещает игровые серверы</strong>
        <p>
          Настройки можно собрать и скачать. Чтобы мир действительно заработал и
          получил адрес для подключения, требуется отдельный игровой хостинг с
          TCP/UDP-портами. Сейчас он не подключён.
        </p>
      </div>
    </div>
  );
}

function ServersView({
  drafts,
  onNew,
  onEdit,
  onDelete,
}: {
  drafts: ServerDraft[];
  onNew: () => void;
  onEdit: (draft: ServerDraft) => void;
  onDelete: (draft: ServerDraft) => void;
}) {
  return (
    <div className="page-body">
      <Heading
        eyebrow="КОСМИЧЕСКАЯ КОНСОЛЬ"
        title="Твоя вселенная серверов"
        text="Собирай конфигурации для Java и Bedrock. Запуск появится после подключения игрового хостинга."
        action={
          <button className="button primary" onClick={onNew}>
            <Plus size={16} /> Новый сервер
          </button>
        }
      />
      <div className="stats-row">
        <div className="stat-card">
          <span className="stat-icon cyan">
            <Layers3 size={17} />
          </span>
          <div>
            <small>КОНФИГУРАЦИИ</small>
            <strong>{drafts.length.toString().padStart(2, "0")}</strong>
            <span>сохранено в браузере</span>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon violet">
            <Activity size={17} />
          </span>
          <div>
            <small>ЗАПУЩЕНО</small>
            <strong>00</strong>
            <span>игровой хост не подключён</span>
          </div>
        </div>
        <div className="stat-card">
          <span className="stat-icon green">
            <Wifi size={17} />
          </span>
          <div>
            <small>СОЕДИНЕНИЕ</small>
            <strong className="stat-offline">OFFLINE</strong>
            <span>нет адреса для подключения</span>
          </div>
        </div>
      </div>
      <HostingNotice compact />
      <div className="section-title-row">
        <div>
          <div className="section-kicker">ТВОЯ КОЛЛЕКЦИЯ</div>
          <h2>
            Сохранённые конфигурации <span>{drafts.length}</span>
          </h2>
        </div>
        <button className="button subtle" onClick={onNew}>
          <Plus size={15} /> Создать
        </button>
      </div>
      {drafts.length === 0 ? (
        <div className="empty-state">
          <div className="empty-orbit">
            <span />
            <span />
            <i>
              <Server size={25} />
            </i>
          </div>
          <div className="empty-kicker">ОРБИТА ПОКА СВОБОДНА</div>
          <h3>Собери первый сервер</h3>
          <p>
            Выбери Java или Bedrock, настрой версию и оформи карточку.
            Конфигурацию можно скачать и перенести на игровой хост.
          </p>
          <button className="button primary" onClick={onNew}>
            <Sparkles size={15} /> Открыть конструктор <ArrowRight size={15} />
          </button>
          <span className="empty-footnote">
            Черновики хранятся только в этом браузере
          </span>
        </div>
      ) : (
        <div className="server-list">
          {drafts.map(draft => (
            <article className="server-row" key={draft.id}>
              <ServerGlyph iconData={draft.iconData} />
              <div className="server-row-main">
                <div className="server-row-title">
                  <strong style={{ color: draft.color }}>{draft.name}</strong>
                  <span className="draft-badge">ЧЕРНОВИК</span>
                </div>
                <div className="server-row-meta">
                  <span>
                    {draft.edition === "java" ? "Java Edition" : "Bedrock / PE"}
                  </span>
                  <i />
                  {draft.version || "Версия не выбрана"}
                  <i />
                  {draft.maxPlayers} слотов
                </div>
              </div>
              <div className="server-row-status">
                <span className="status-dot muted" /> Не запущен
              </div>
              <button
                className="icon-button"
                onClick={() => onEdit(draft)}
                aria-label={`Редактировать ${draft.name}`}
              >
                <Settings2 size={17} />
              </button>
              <button
                className="icon-button danger-hover"
                onClick={() => onDelete(draft)}
                aria-label={`Удалить ${draft.name}`}
              >
                <Trash2 size={16} />
              </button>
            </article>
          ))}
        </div>
      )}
      <div className="below-fold-tip">
        <Info size={14} />
        <span>
          Без подключённого хостинга IP, мир и реальный статус сервера
          недоступны. Nebula не показывает фальшивые «онлайн»-счётчики.
        </span>
      </div>
    </div>
  );
}

function IconEditor({
  value,
  onChange,
}: {
  value: string | null;
  onChange: (data: string | null) => void;
}) {
  const [error, setError] = useState("");
  async function processFile(file?: File) {
    if (!file) return;
    setError("");
    if (!file.type.startsWith("image/")) {
      setError("Выбери файл изображения.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError("Файл должен быть меньше 8 МБ.");
      return;
    }
    try {
      const image = await createImageBitmap(file);
      const edge = Math.min(image.width, image.height);
      const canvas = document.createElement("canvas");
      canvas.width = 64;
      canvas.height = 64;
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Canvas unavailable");
      context.imageSmoothingQuality = "high";
      context.drawImage(
        image,
        (image.width - edge) / 2,
        (image.height - edge) / 2,
        edge,
        edge,
        0,
        0,
        64,
        64
      );
      onChange(canvas.toDataURL("image/png"));
      image.close();
      toast.success("Иконка обрезана по центру и уменьшена до 64×64 PNG");
    } catch {
      setError("Не удалось прочитать это изображение.");
    }
  }
  return (
    <div className="icon-editor">
      <div className="icon-editor-preview">
        <ServerGlyph iconData={value} />
      </div>
      <div className="icon-editor-actions">
        <label className="button secondary upload-button">
          <ImagePlus size={16} /> Загрузить иконку
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={event => {
              void processFile(event.target.files?.[0]);
              event.currentTarget.value = "";
            }}
          />
        </label>
        <span>PNG, JPG или WebP · будет кадрировано в квадрат 64×64</span>
        {value && (
          <button className="remove-icon" onClick={() => onChange(null)}>
            <X size={13} /> Сбросить
          </button>
        )}
        {error && <small className="field-error">{error}</small>}
      </div>
    </div>
  );
}

function BuildTypeCard({
  selected,
  title,
  caption,
  icon,
  onClick,
}: {
  selected: boolean;
  title: string;
  caption: string;
  icon: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      className={`choice-card ${selected ? "selected" : ""}`}
      onClick={onClick}
    >
      <span className="choice-icon">{icon}</span>
      <span className="choice-text">
        <strong>{title}</strong>
        <small>{caption}</small>
      </span>
      <span className="choice-radio">{selected && <i />}</span>
    </button>
  );
}

function BuilderView({
  initialDraft,
  onSave,
  onCancel,
}: {
  initialDraft: ServerDraft | null;
  onSave: (draft: ServerDraft) => void;
  onCancel: () => void;
}) {
  const [draft, setDraft] = useState<ServerDraft>(() => ({
    ...makeEmptyDraft(),
    id: initialDraft?.id ?? "",
    ...(initialDraft ?? {}),
  }));
  const [validation, setValidation] = useState("");
  const isJava = draft.edition === "java";
  const versionsQuery = trpc.minecraft.versions.useQuery(
    { track: draft.track, software: draft.software },
    { enabled: isJava, staleTime: 15 * 60 * 1000, retry: 1 }
  );
  const versionOptions = useMemo(() => {
    if (!isJava) return ["Latest stable"];
    if (versionsQuery.data?.versions?.length)
      return versionsQuery.data.versions;
    return draft.software === "forge" &&
      (draft.track === "old_alpha" || draft.track === "old_beta")
      ? []
      : sampleVersions[draft.track];
  }, [draft.software, draft.track, isJava, versionsQuery.data]);

  useEffect(() => {
    if (!isJava || !versionsQuery.data?.versions?.length) return;
    setDraft(current => {
      if (versionsQuery.data.versions.includes(current.version)) return current;
      return { ...current, version: versionsQuery.data.versions[0] };
    });
  }, [isJava, versionsQuery.data]);

  function update<K extends keyof ServerDraft>(key: K, value: ServerDraft[K]) {
    setDraft(current => ({
      ...current,
      [key]: value,
      updatedAt: new Date().toISOString(),
    }));
  }

  function setEdition(edition: ServerDraft["edition"]) {
    setDraft(current => ({
      ...current,
      edition,
      software: "vanilla",
      version: edition === "bedrock" ? "Latest stable" : "",
    }));
  }

  function save() {
    const name = draft.name.trim();
    if (name.length < 3 || name.length > 32) {
      setValidation("Название должно содержать от 3 до 32 символов.");
      return;
    }
    if (
      isJava &&
      draft.software === "forge" &&
      (draft.track === "old_alpha" || draft.track === "old_beta")
    ) {
      setValidation(
        "Для выбранной Alpha/Beta-версии нет совместимых сборок Forge."
      );
      return;
    }
    if (!draft.version.trim()) {
      setValidation("Выбери версию игры.");
      return;
    }
    if (
      isJava &&
      versionsQuery.data &&
      !versionsQuery.data.versions.includes(draft.version.trim())
    ) {
      setValidation("Выбери версию из доступного каталога совместимых сборок.");
      return;
    }
    setValidation("");
    onSave({
      ...draft,
      name,
      version: draft.version.trim(),
      updatedAt: new Date().toISOString(),
    });
  }

  function downloadConfiguration() {
    const safeName =
      draft.name
        .toLowerCase()
        .normalize("NFKD")
        .replace(/[^a-z0-9-_]+/g, "-")
        .replace(/^-|-$/g, "") || "nebula-server";
    saveFile(
      "server.properties",
      createMinecraftProperties(draft),
      "text/plain;charset=utf-8"
    );
    saveFile(
      "nebula-config.json",
      createNebulaManifest(draft),
      "application/json;charset=utf-8"
    );
    if (draft.iconData) {
      const anchor = document.createElement("a");
      anchor.href = draft.iconData;
      anchor.download = `${safeName}-server-icon.png`;
      anchor.click();
    }
    toast.success("Файлы настроек скачаны", {
      description: "Это конфигурация, не запущенный игровой сервер.",
    });
  }

  const hostingMutation = trpc.minecraft.provision.useMutation({
    onSuccess: response =>
      toast.error("Сервер не запущен", {
        description: response.message,
        duration: 7000,
      }),
    onError: () =>
      toast.error(
        "Не удалось проверить игровое размещение. Сервер не запущен."
      ),
  });

  return (
    <div className="page-body builder-page">
      <button className="back-link" onClick={onCancel}>
        <ArrowLeft size={15} /> Все серверы
      </button>
      <Heading
        eyebrow={initialDraft ? "НАСТРОЙКА КОНФИГУРАЦИИ" : "МАСТЕР СОЗДАНИЯ"}
        title={initialDraft ? "Редактировать сервер" : "Создай свой сервер"}
        text="Настрой сборку и внешний вид. Сначала сохрани конфигурацию — игровой хост не подключён."
      />
      <div className="builder-layout">
        <div className="builder-form">
          <section className="form-panel">
            <div className="panel-heading">
              <span className="step-index">01</span>
              <div>
                <h2>Выбери издание</h2>
                <p>Для Java и Bedrock нужны разные серверные сборки.</p>
              </div>
            </div>
            <div className="edition-grid">
              <BuildTypeCard
                selected={draft.edition === "java"}
                title="Java Edition"
                caption="ПК · Vanilla и Forge"
                icon={<Monitor size={18} />}
                onClick={() => setEdition("java")}
              />
              <BuildTypeCard
                selected={draft.edition === "bedrock"}
                title="Bedrock / PE"
                caption="Телефон, консоль и Windows"
                icon={<Gamepad2 size={18} />}
                onClick={() => setEdition("bedrock")}
              />
            </div>
            {isJava ? (
              <>
                <div className="subsection-label">ТИП ВЕРСИИ</div>
                <div className="track-grid">
                  {tracks.map(track => (
                    <button
                      key={track}
                      className={`track-chip ${draft.track === track ? "selected" : ""}`}
                      onClick={() =>
                        setDraft(current => ({
                          ...current,
                          track,
                          version: "",
                        }))
                      }
                    >
                      <span>{trackLabels[track]}</span>
                      <small>
                        {track === "old_alpha"
                          ? "2009–10"
                          : track === "old_beta"
                            ? "2010–11"
                            : track === "release"
                              ? "Стабильные"
                              : "Тестовые"}
                      </small>
                    </button>
                  ))}
                </div>
                <div className="field-row build-software-row">
                  <label className="field-label">Серверное ПО</label>
                  <div className="segmented-control">
                    <button
                      className={draft.software === "vanilla" ? "selected" : ""}
                      onClick={() =>
                        setDraft(current => ({
                          ...current,
                          software: "vanilla",
                          version: "",
                        }))
                      }
                    >
                      <Box size={14} /> Vanilla
                    </button>
                    <button
                      className={draft.software === "forge" ? "selected" : ""}
                      onClick={() =>
                        setDraft(current => ({
                          ...current,
                          software: "forge",
                          version: "",
                        }))
                      }
                    >
                      <Sparkles size={14} /> Forge
                    </button>
                  </div>
                </div>
                {draft.software === "forge" &&
                  (draft.track === "old_alpha" ||
                    draft.track === "old_beta") && (
                    <div className="inline-note">
                      <Info size={14} /> Forge не публикует совместимые сборки
                      для выбранной эпохи. Переключись на релиз или снапшот.
                    </div>
                  )}
                <div className="field-row version-field">
                  <label className="field-label" htmlFor="java-version">
                    Версия игры{" "}
                    <span className="source-caption">
                      {versionsQuery.isFetching
                        ? "Загружаю каталог Mojang…"
                        : versionsQuery.data?.source
                          ? `Каталог Mojang · ${versionOptions.length} версий`
                          : "Каталог временно недоступен"}
                    </span>
                  </label>
                  <input
                    id="java-version"
                    className="text-field"
                    list="java-version-options"
                    value={draft.version}
                    onChange={event => update("version", event.target.value)}
                    placeholder={versionOptions[0] ?? "Например, 1.21.4"}
                  />
                  <datalist id="java-version-options">
                    {versionOptions.map(version => (
                      <option value={version} key={version} />
                    ))}
                  </datalist>
                  {versionsQuery.isError && (
                    <small className="inline-muted">
                      Показан резервный список. Проверь совместимость выбранной
                      версии перед переносом.
                    </small>
                  )}
                  {draft.software === "forge" && !versionOptions.length && (
                    <small className="field-error">
                      Не удалось найти версию Forge для этого типа игры.
                    </small>
                  )}
                </div>
              </>
            ) : (
              <div className="bedrock-callout">
                <span className="bedrock-icon">
                  <Gamepad2 size={17} />
                </span>
                <div>
                  <strong>Bedrock Dedicated Server</strong>
                  <p>
                    Официальная выделенная сборка Bedrock. Выбор канала
                    «Последняя стабильная» нужно будет подтвердить у игрового
                    хоста.
                  </p>
                </div>
                <span className="bedrock-latest">STABLE</span>
              </div>
            )}
          </section>

          <section className="form-panel">
            <div className="panel-heading">
              <span className="step-index">02</span>
              <div>
                <h2>Визитная карточка</h2>
                <p>Так сервер будет выглядеть в списке конфигураций.</p>
              </div>
            </div>
            <div className="field-row">
              <label className="field-label" htmlFor="server-name">
                Название сервера
              </label>
              <div className="input-with-count">
                <input
                  id="server-name"
                  className="text-field"
                  value={draft.name}
                  onChange={event =>
                    update("name", event.target.value.slice(0, 32))
                  }
                  maxLength={32}
                  placeholder="Например, Orion SMP"
                />
                <span>{draft.name.length}/32</span>
              </div>
              <small className="inline-muted">От 3 до 32 символов.</small>
            </div>
            <div className="field-row color-field-row">
              <span className="field-label">Цвет названия</span>
              <div className="color-picker-line">
                <label
                  className="custom-color-wrap"
                  style={{ "--selected-color": draft.color } as CSSProperties}
                >
                  <input
                    type="color"
                    aria-label="Выбрать цвет названия"
                    value={draft.color}
                    onChange={event => update("color", event.target.value)}
                  />
                  <span>{draft.color.toUpperCase()}</span>
                </label>
                <div className="color-presets">
                  {colorChoices.map(color => (
                    <button
                      key={color}
                      className={`color-swatch ${draft.color.toLowerCase() === color ? "active" : ""}`}
                      style={{ backgroundColor: color }}
                      onClick={() => update("color", color)}
                      aria-label={`Цвет ${color}`}
                    />
                  ))}
                </div>
              </div>
              <small className="inline-muted">
                Цвет карточки применяется в Nebula; Vanilla MOTD использует
                ближайший стандартный цвет Minecraft.
              </small>
            </div>
            <div className="field-row">
              <span className="field-label">Иконка сервера</span>
              <IconEditor
                value={draft.iconData}
                onChange={iconData => update("iconData", iconData)}
              />
            </div>
          </section>

          <section className="form-panel">
            <div className="panel-heading">
              <span className="step-index">03</span>
              <div>
                <h2>Правила мира</h2>
                <p>Параметры сохраняются вместе с конфигурацией.</p>
              </div>
            </div>
            <div className="field-row slider-field">
              <div className="slider-heading">
                <label className="field-label" htmlFor="players-range">
                  Максимум игроков
                </label>
                <output>
                  {draft.maxPlayers}
                  <small> игроков</small>
                </output>
              </div>
              <input
                id="players-range"
                className="nebula-range"
                type="range"
                min="1"
                max="100"
                step="1"
                value={draft.maxPlayers}
                onChange={event =>
                  update("maxPlayers", Number(event.target.value))
                }
              />
              <div className="range-ends">
                <span>1 игрок</span>
                <span>100 игроков</span>
              </div>
            </div>
            <div className="field-row spawn-field">
              <div className="spawn-intro">
                <span className="shield-icon">
                  <Shield size={17} />
                </span>
                <div>
                  <span className="field-label">Область защиты спавна</span>
                  <small>Желаемая зона блокировки разрушения взрывами.</small>
                </div>
                <span className="dimension-preview">
                  {draft.protectionWidth} × {draft.protectionLength}
                </span>
              </div>
              <div className="dimensions-row">
                <label>
                  Ширина
                  <input
                    className="number-field"
                    type="number"
                    min="1"
                    max="100"
                    value={draft.protectionWidth}
                    onChange={event =>
                      update(
                        "protectionWidth",
                        Math.max(
                          1,
                          Math.min(100, Number(event.target.value) || 1)
                        )
                      )
                    }
                  />
                </label>
                <span className="dimension-cross">×</span>
                <label>
                  Длина
                  <input
                    className="number-field"
                    type="number"
                    min="1"
                    max="100"
                    value={draft.protectionLength}
                    onChange={event =>
                      update(
                        "protectionLength",
                        Math.max(
                          1,
                          Math.min(100, Number(event.target.value) || 1)
                        )
                      )
                    }
                  />
                </label>
                <span className="dimension-unit">блоков</span>
              </div>
              <div className="protection-warning">
                <AlertTriangle size={14} />
                <span>
                  Vanilla не гарантирует защиту от взрывов в точном
                  прямоугольнике. Для такой зоны потребуется совместимый плагин,
                  мод или addon на хосте.
                </span>
              </div>
            </div>
          </section>

          <HostingNotice compact />
          {validation && (
            <div className="validation-error">
              <AlertTriangle size={15} />
              {validation}
            </div>
          )}
          <div className="form-actions">
            <button className="button ghost" onClick={downloadConfiguration}>
              <ArrowDownToLine size={16} /> Скачать конфиг
            </button>
            <button className="button primary" onClick={save}>
              <Check size={16} /> Сохранить конфигурацию
            </button>
          </div>
          {draft.id && (
            <button
              className="launch-attempt"
              disabled={hostingMutation.isPending}
              onClick={() =>
                hostingMutation.mutate({
                  name: draft.name,
                  edition: draft.edition,
                  software: draft.software,
                  track: draft.track,
                  version: draft.version || "latest",
                  maxPlayers: draft.maxPlayers,
                  protectionWidth: draft.protectionWidth,
                  protectionLength: draft.protectionLength,
                })
              }
            >
              {hostingMutation.isPending ? (
                <LoaderCircle size={15} className="spin" />
              ) : (
                <Rocket size={15} />
              )}{" "}
              Проверить запуск на игровом хосте
            </button>
          )}
        </div>

        <aside className="builder-aside">
          <div className="preview-card">
            <div className="preview-card-top">
              <span>ПРЕДПРОСМОТР</span>
              <span className="preview-live-dot" />
              LOCAL
            </div>
            <div className="server-card-mock">
              <div className="mock-stars" />
              <div className="mock-server-glyph">
                <ServerGlyph iconData={draft.iconData} />
              </div>
              <div className="mock-server-name" style={{ color: draft.color }}>
                {draft.name || "Имя сервера"}
              </div>
              <div className="mock-server-desc">
                {draft.edition === "java"
                  ? `Java · ${draft.software === "forge" ? "Forge" : "Vanilla"}`
                  : "Bedrock / PE"}{" "}
                · {draft.version || "версия"}
              </div>
              <div className="mock-server-divider" />
              <div className="mock-status-line">
                <span className="status-dot muted" /> <span>Не запущен</span>
                <span className="mock-address">IP:PORT —</span>
              </div>
              <div className="mock-detail">
                <span>
                  <Users size={13} /> {draft.maxPlayers} слотов
                </span>
                <span>
                  <HardDrive size={13} /> {draft.protectionWidth}×
                  {draft.protectionLength}
                </span>
              </div>
            </div>
            <div className="preview-card-foot">
              <Info size={13} /> Предпросмотр не означает, что сервер запущен.
            </div>
          </div>
          <div className="quick-specs">
            <div className="quick-spec-title">ПАРАМЕТРЫ КОНФИГУРАЦИИ</div>
            <div>
              <span>Издание</span>
              <strong>
                {draft.edition === "java" ? "Java Edition" : "Bedrock / PE"}
              </strong>
            </div>
            <div>
              <span>Сборка</span>
              <strong>
                {draft.edition === "java"
                  ? `${draft.software === "forge" ? "Forge" : "Vanilla"} · ${trackLabels[draft.track]}`
                  : "Bedrock Dedicated"}
              </strong>
            </div>
            <div>
              <span>Игроки</span>
              <strong>{draft.maxPlayers}</strong>
            </div>
            <div>
              <span>Спавн</span>
              <strong>
                {draft.protectionWidth} × {draft.protectionLength} блоков
              </strong>
            </div>
          </div>
          <div className="version-source">
            <Globe2 size={14} />
            <span>
              Версии Java загружаются из официального манифеста Mojang.
            </span>
          </div>
        </aside>
      </div>
    </div>
  );
}

function HostingView() {
  return (
    <div className="page-body hosting-page">
      <Heading
        eyebrow="ИНФРАСТРУКТУРА"
        title="Нужна отдельная орбита"
        text="Nebula — панель сайта, а не игровая машина. Чтобы игроки подключались по IP:порту, нужен отдельный Minecraft-хост."
      />
      <HostingNotice />
      <div className="hosting-explainer">
        <div className="hosting-explainer-main">
          <div className="hosting-illustration">
            <div className="host-orbit orbit-one" />
            <div className="host-orbit orbit-two" />
            <div className="host-planet">
              <Server size={29} />
            </div>
            <span className="host-star star-one" />
            <span className="host-star star-two" />
            <span className="host-star star-three" />
          </div>
          <div className="eyebrow">
            <span /> ЧТО НУЖНО ДЛЯ ЗАПУСКА
          </div>
          <h2>Сайт ≠ игровой сервер</h2>
          <p>
            Веб-приложение работает по HTTP. Миры Minecraft требуют запущенной
            Java или Bedrock Dedicated программы, постоянного диска и открытых
            игровых портов — обычно TCP для Java и UDP для Bedrock. В этой
            сессии игровой узел, панель Pterodactyl и бесплатные вычислительные
            квоты не подключены.
          </p>
        </div>
        <div className="hosting-steps">
          <div className="hosting-step">
            <span>01</span>
            <div>
              <strong>Игровой узел</strong>
              <p>
                Подключи VPS или выделенный игровой хост с подходящими портами.
              </p>
            </div>
            <Cpu size={17} />
          </div>
          <div className="hosting-step">
            <span>02</span>
            <div>
              <strong>Панель размещения</strong>
              <p>
                Подготовь провайдера, например Pterodactyl, и совместимые
                Java/Bedrock сборки.
              </p>
            </div>
            <Layers3 size={17} />
          </div>
          <div className="hosting-step">
            <span>03</span>
            <div>
              <strong>Безопасная связь</strong>
              <p>
                Нужны защищённые учетные данные, авторизация пользователей и
                серверная интеграция.
              </p>
            </div>
            <LockKeyhole size={17} />
          </div>
          <div className="hosting-step">
            <span>04</span>
            <div>
              <strong>Проверенные лимиты</strong>
              <p>
                «Бесплатность» и число игроков зависят от фактической памяти,
                CPU и правил провайдера.
              </p>
            </div>
            <Radio size={17} />
          </div>
        </div>
      </div>
      <div className="hosting-footer-note">
        <Info size={15} />
        <p>
          <strong>Что уже работает:</strong> создание и сохранение черновика в
          этом браузере, каталог версий Java, редактирование иконки, экспорт
          `server.properties` и JSON. Настоящий запуск, адрес, консоль и
          управление процессом появятся только после подключения и настройки
          игрового хоста.
        </p>
      </div>
    </div>
  );
}

export default function Home() {
  const [view, setView] = useState<View>("servers");
  const [drafts, setDrafts] = useState<ServerDraft[]>(readDrafts);
  const [editingDraft, setEditingDraft] = useState<ServerDraft | null>(null);
  const hostingStatus = trpc.minecraft.hostingStatus.useQuery(undefined, {
    staleTime: 60_000,
  });

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(drafts));
    } catch {
      toast.error("Не удалось сохранить черновики в этом браузере.");
    }
  }, [drafts]);

  function newDraft() {
    setEditingDraft(null);
    setView("builder");
  }
  function editDraft(draft: ServerDraft) {
    setEditingDraft(draft);
    setView("builder");
  }
  function saveDraft(draft: ServerDraft) {
    const hasId = Boolean(draft.id);
    const id =
      draft.id || (globalThis.crypto?.randomUUID?.() ?? `srv-${Date.now()}`);
    setDrafts(current =>
      hasId
        ? current.map(item => (item.id === id ? { ...draft, id } : item))
        : [{ ...draft, id }, ...current]
    );
    setEditingDraft(null);
    setView("servers");
    toast.success(hasId ? "Конфигурация обновлена" : "Конфигурация сохранена", {
      description: "Сервер остаётся черновиком: игровой хост не подключён.",
    });
  }
  function deleteDraft(draft: ServerDraft) {
    if (!window.confirm(`Удалить черновик «${draft.name}» из этого браузера?`))
      return;
    setDrafts(current => current.filter(item => item.id !== draft.id));
    toast.success("Черновик удалён");
  }

  return (
    <div className="app-shell">
      <Navigation
        view={view}
        setView={setView}
        draftCount={drafts.length}
        onNew={newDraft}
      />
      <main className="main-column">
        <Topbar view={view} setView={setView} />
        <div className="main-scroll" key={view}>
          {view === "servers" && (
            <ServersView
              drafts={drafts}
              onNew={newDraft}
              onEdit={editDraft}
              onDelete={deleteDraft}
            />
          )}
          {view === "builder" && (
            <BuilderView
              key={editingDraft?.id ?? "new"}
              initialDraft={editingDraft}
              onSave={saveDraft}
              onCancel={() => {
                setView("servers");
                setEditingDraft(null);
              }}
            />
          )}
          {view === "hosting" && <HostingView />}
        </div>
        <footer className="app-footer">
          <span>
            NEBULA <i>✦</i> MINECRAFT SERVER STUDIO
          </span>
          <span>
            <span
              className={`status-dot ${hostingStatus.data?.connected ? "online" : "muted"}`}
            />{" "}
            {hostingStatus.data?.connected
              ? "Хост подключён"
              : "Только конфигурации · серверы не запущены"}
          </span>
        </footer>
      </main>
    </div>
  );
}
