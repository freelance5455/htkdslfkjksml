import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import {
  Activity,
  AlertTriangle,
  BarChart3,
  Check,
  CheckCircle2,
  ChevronRight,
  Clipboard,
  Clock3,
  Copy,
  Cpu,
  Database,
  Gauge,
  History,
  LayoutDashboard,
  Loader2,
  LogIn,
  Menu,
  Palette,
  RefreshCw,
  Server,
  Settings,
  ShieldCheck,
  Sparkles,
  Terminal,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";

type Section = "overview" | "history" | "themes" | "settings" | "admin";
type ThemeName = "blackBlue" | "blackViolet" | "blackRed" | "blackGreen" | "blackCyan" | "whiteBlue" | "whiteViolet" | "dark" | "light" | "custom";
type RequestStatus = "pending" | "confirmed" | "error";
type RequestRecord = { id: string; amount: number; createdAt: string; status: RequestStatus; message: string };

type ProviderHealth = { ok: boolean; label: string; latency?: number; detail?: string };

const API_BASE = "https://vip-like-api-ehd8.onrender.com";
const initialHistory: RequestRecord[] = [];
function safeStorageGet(key: string) { try { return window.localStorage.getItem(key); } catch { return null; } }
function safeStorageSet(key: string, value: string) { try { window.localStorage.setItem(key, value); } catch {} }

function formatDate(value: string) {
  return new Intl.DateTimeFormat("es-ES", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
}

function statusLabel(status: RequestStatus) {
  return status === "confirmed" ? "Confirmado" : status === "error" ? "Error" : "Pendiente";
}

function StatusPill({ status }: { status: RequestStatus }) {
  return <span className={`status-pill ${status}`}><span className="status-dot" />{statusLabel(status)}</span>;
}

export default function Home() {
  const [section, setSection] = useState<Section>("overview");
  const [mobileNav, setMobileNav] = useState(false);
  const [playerId, setPlayerId] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [notice, setNotice] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);
  const [provider, setProvider] = useState<ProviderHealth>({ ok: false, label: "Comprobando", detail: "Sincronizando con el servidor" });
  const [history, setHistory] = useState<RequestRecord[]>(() => { try { return JSON.parse(safeStorageGet("vip-like-history") || "null") || initialHistory; } catch { return initialHistory; } });
  const [theme, setTheme] = useState<ThemeName>(() => (safeStorageGet("vip-like-theme") as ThemeName) || "blackCyan");
  const [customAccent, setCustomAccent] = useState(() => safeStorageGet("vip-like-accent") || "#56e0ff");
  const [adminData, setAdminData] = useState<any>(null);
  const { user, isAuthenticated, loading: authLoading } = useAuth();

  useEffect(() => { safeStorageSet("vip-like-history", JSON.stringify(history)); }, [history]);
  useEffect(() => { safeStorageSet("vip-like-theme", theme); document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => { safeStorageSet("vip-like-accent", customAccent); document.documentElement.style.setProperty("--accent-custom", customAccent); }, [customAccent]);
  useEffect(() => { checkProvider(); }, []);

  const totalRequested = useMemo(() => history.reduce((sum, item) => sum + item.amount, 0), [history]);
  const navItems: { key: Section; label: string; icon: any; hint?: string }[] = [
    { key: "overview", label: "Command center", icon: LayoutDashboard, hint: "Inicio" },
    { key: "history", label: "Historial", icon: History, hint: `${history.length} registros` },
    { key: "themes", label: "Temas", icon: Palette, hint: "Personalizar" },
    { key: "settings", label: "Configuración", icon: Settings, hint: "Sistema" },
    { key: "admin", label: "Administración", icon: ShieldCheck, hint: "Protegido" },
  ];

  async function checkProvider() {
    const started = performance.now();
    setProvider({ ok: false, label: "Comprobando", detail: "Consultando /api/health del proveedor" });
    try {
      const response = await fetch("/api/provider-health");
      const data = await response.json();
      setProvider({ ok: Boolean(data.ok), label: data.ok ? "Online" : "Degradado", latency: Math.round(performance.now() - started), detail: data.detail || "Respuesta recibida" });
    } catch {
      setProvider({ ok: false, label: "Sin conexión", latency: Math.round(performance.now() - started), detail: "No se pudo alcanzar el proveedor" });
    }
  }

  async function generateLikes() {
    const cleanId = playerId.trim();
    if (!/^\d{6,15}$/.test(cleanId)) {
      setNotice({ type: "error", text: "Introduce un ID válido de Free Fire: solo números, entre 6 y 15 dígitos." });
      return;
    }
    setNotice(null); setIsGenerating(true); setProgress(12);
    const timer = window.setInterval(() => setProgress(value => Math.min(value + 11, 86)), 420);
    try {
      const response = await fetch("/api/likes", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ playerId: cleanId }) });
      const data = await response.json().catch(() => ({}));
      const status: RequestStatus = response.ok && data.confirmed === true ? "confirmed" : response.ok ? "pending" : "error";
      const record: RequestRecord = { id: cleanId, amount: 200, createdAt: new Date().toISOString(), status, message: data.message || (status === "pending" ? "Pendiente de proveedor autorizado" : "Solicitud procesada") };
      setHistory(current => [record, ...current.filter(item => item.id !== cleanId)].slice(0, 50));
      setNotice({ type: status === "error" ? "error" : status === "confirmed" ? "success" : "info", text: record.message });
      setPlayerId(""); setProgress(100);
      if (section !== "overview") setSection("overview");
    } catch {
      setNotice({ type: "error", text: "No se pudo conectar con el backend. Inténtalo de nuevo." });
      setHistory(current => [{ id: cleanId, amount: 200, createdAt: new Date().toISOString(), status: "error", message: "Error de conexión con el backend" }, ...current]);
    } finally { window.clearInterval(timer); window.setTimeout(() => { setIsGenerating(false); setProgress(0); }, 650); }
  }

  async function loadAdmin() {
    if (!isAuthenticated || user?.role !== "admin") return;
    try { const response = await fetch("/api/admin/stats"); if (response.ok) setAdminData(await response.json()); } catch { setAdminData(null); }
  }
  useEffect(() => { if (section === "admin") loadAdmin(); }, [section, isAuthenticated, user?.role]);

  function copyId(id: string) { navigator.clipboard?.writeText(id); setNotice({ type: "success", text: `ID ${id} copiado al portapapeles.` }); }
  function clearHistory() { setHistory([]); setNotice({ type: "info", text: "Historial local limpiado." }); }

  return <div className="app-shell">
    <div className="ambient ambient-one" /><div className="ambient ambient-two" />
    <aside className={`sidebar ${mobileNav ? "open" : ""}`}>
      <div className="brand"><div className="brand-mark"><Zap size={20} fill="currentColor" /></div><div><strong>VIP</strong><span>LIKE GENERATOR</span></div></div>
      <div className="sidebar-label">NAVEGACIÓN</div>
      <nav>{navItems.map(({ key, label, icon: Icon, hint }) => <button key={key} className={`nav-item ${section === key ? "active" : ""}`} onClick={() => { setSection(key); setMobileNav(false); }}><Icon size={18} /><span><b>{label}</b><small>{hint}</small></span>{section === key && <ChevronRight className="nav-arrow" size={16} />}</button>)}</nav>
      <div className="sidebar-spacer" />
      <div className="server-mini"><div className="server-mini-title"><span className={`pulse ${provider.ok ? "online" : ""}`} />Servidor API</div><strong>{provider.label}</strong><small>{provider.latency ? `${provider.latency}ms · ` : ""}{provider.detail}</small></div>
      <div className="sidebar-footer"><span className="mini-avatar">VL</span><span><b>VIP Workspace</b><small>v1.0.0 · Secure mode</small></span></div>
    </aside>
    {mobileNav && <button className="mobile-overlay" aria-label="Cerrar menú" onClick={() => setMobileNav(false)} />}
    <main className="main-content">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMobileNav(true)}><Menu size={20} /></button><div className="breadcrumb"><span>VIP LIKE GENERATOR</span><ChevronRight size={14} /><b>{navItems.find(item => item.key === section)?.label}</b></div><div className="top-actions"><span className="live-status"><i className={provider.ok ? "online" : ""} /> {provider.label}</span><button className="icon-btn" onClick={checkProvider} title="Comprobar conexión"><RefreshCw size={17} /></button>{isAuthenticated ? <span className="user-chip"><span className="mini-avatar">{(user?.name || "U").slice(0, 2).toUpperCase()}</span>{user?.name || "Usuario"}</span> : <button className="login-btn" onClick={startLogin}><LogIn size={16} /> Acceso admin</button>}</div></header>
      <div className="page-wrap">
        <div className="page-heading"><div><div className="eyebrow"><Sparkles size={14} /> CONTROL OPERATIVO <span>•</span> FREE FIRE</div><h1>{section === "overview" ? <>Impulsa tu presencia.<br /><em>Sin perder el control.</em></> : navItems.find(item => item.key === section)?.label}</h1><p>{section === "overview" ? "Solicita likes de forma transparente y revisa cada estado desde un solo lugar." : "Gestiona tu espacio VIP con información clara y estados verificables."}</p></div><div className="date-stamp"><Clock3 size={14} /> {new Intl.DateTimeFormat("es-ES", { weekday: "long", day: "numeric", month: "long" }).format(new Date())}</div></div>
        {notice && <div className={`notice ${notice.type}`}><span>{notice.type === "error" ? <AlertTriangle size={18} /> : notice.type === "success" ? <CheckCircle2 size={18} /> : <Activity size={18} />}</span><b>{notice.text}</b><button onClick={() => setNotice(null)}><X size={16} /></button></div>}
        {section === "overview" && <>
          <div className="stats-row"><div className="stat-card"><div className="stat-icon cyan"><Zap size={18} /></div><div><small>LIKES SOLICITADOS</small><strong>{totalRequested.toLocaleString("es-ES")}</strong><span className="trend">{history.length ? "+200 última solicitud" : "Sin solicitudes aún"}</span></div></div><div className="stat-card"><div className="stat-icon violet"><Gauge size={18} /></div><div><small>ESTADO DEL SERVICIO</small><strong>{provider.ok ? "Operativo" : "Revisar"}</strong><span className={provider.ok ? "trend" : "trend warning"}>{provider.latency ? `${provider.latency}ms de latencia` : "Esperando señal"}</span></div></div><div className="stat-card"><div className="stat-icon amber"><History size={18} /></div><div><small>SOLICITUDES TOTALES</small><strong>{history.length.toString().padStart(2, "0")}</strong><span className="trend">Registro local activo</span></div></div></div>
          <div className="dashboard-grid"><section className="generator-card panel-glow"><div className="panel-top"><div><span className="panel-kicker"><span className="live-dot" /> GENERADOR PRINCIPAL</span><h2>Activa tu cuenta <span>con precisión.</span></h2></div><div className="request-badge"><Zap size={15} /> 200 LIKES <small>por solicitud</small></div></div><div className="scan-line" /><div className="generator-body"><label htmlFor="player-id">ID DEL JUGADOR <span>OBLIGATORIO</span></label><div className="id-input-wrap"><Terminal size={19} /><input id="player-id" inputMode="numeric" value={playerId} onChange={event => setPlayerId(event.target.value.replace(/\D/g, "").slice(0, 15))} placeholder="Introduce tu ID de Free Fire" onKeyDown={event => { if (event.key === "Enter") generateLikes(); }} /><span className="input-counter">{playerId.length}/15</span></div><div className="field-helper"><span><Check size={13} /> Solo números</span><span><Check size={13} /> 6–15 dígitos</span><span><ShieldCheck size={13} /> Procesamiento seguro</span></div><button className="generate-btn" disabled={isGenerating} onClick={generateLikes}>{isGenerating ? <><Loader2 className="spin" size={18} /> Procesando solicitud...</> : <><Zap size={18} fill="currentColor" /> Generar 200 likes <ChevronRight size={18} /></>}</button>{isGenerating && <div className="progress-wrap"><div className="progress-meta"><span>Validando con el servidor</span><b>{progress}%</b></div><div className="progress-track"><div style={{ width: `${progress}%` }} /></div></div>}<p className="disclaimer"><ShieldCheck size={14} /> La entrega depende de la confirmación del proveedor autorizado. No se simulan resultados.</p></div></section>
            <aside className="side-stack"><div className="mini-panel api-panel"><div className="mini-panel-title"><span><Server size={16} /> ESTADO DE API</span><StatusPill status={provider.ok ? "confirmed" : "error"} /></div><div className="api-orbit"><div className="orbit-core"><Activity size={22} /></div><div className="orbit-ring ring-one" /><div className="orbit-ring ring-two" /></div><strong className="api-status-title">{provider.ok ? "Conexión estable" : "Conexión degradada"}</strong><p>{provider.detail || "Comprueba el estado del servidor para continuar."}</p><button className="ghost-btn" onClick={checkProvider}><RefreshCw size={15} /> Comprobar conexión</button></div><div className="mini-panel recent-panel"><div className="mini-panel-title"><span><History size={16} /> ACTIVIDAD RECIENTE</span><button className="text-btn" onClick={() => setSection("history")}>Ver todo <ChevronRight size={14} /></button></div>{history.slice(0, 3).map(item => <div className="recent-item" key={`${item.id}-${item.createdAt}`}><span className="recent-icon"><Zap size={14} /></span><span><b>ID {item.id}</b><small>{formatDate(item.createdAt)} · {item.amount} likes</small></span><StatusPill status={item.status} /></div>)}{history.length === 0 && <div className="empty-mini">Aún no hay solicitudes registradas.</div>}</div></aside>
          </div>
          <div className="bottom-grid"><div className="info-strip"><div className="info-icon"><ShieldCheck size={20} /></div><div><b>Transparencia primero</b><p>El generador refleja exactamente la respuesta de tu backend. Si el proveedor está pendiente, lo verás aquí.</p></div><ChevronRight size={18} /></div><div className="info-strip"><div className="info-icon violet-bg"><Database size={20} /></div><div><b>API conectada</b><p>{API_BASE.replace("https://", "")}<br /><span>GET /api/health · POST /api/likes</span></p></div><ExternalLinkIcon /></div></div>
        </>}
        {section === "history" && <HistorySection history={history} copyId={copyId} clearHistory={clearHistory} />}
        {section === "themes" && <ThemesSection theme={theme} setTheme={setTheme} customAccent={customAccent} setCustomAccent={setCustomAccent} />}
        {section === "settings" && <SettingsSection provider={provider} checkProvider={checkProvider} />}
        {section === "admin" && <AdminSection user={user} isAuthenticated={isAuthenticated} authLoading={authLoading} adminData={adminData} onLogin={startLogin} />}
      </div>
    </main>
  </div>;
}

function ExternalLinkIcon() { return <ChevronRight size={18} />; }
function HistorySection({ history, copyId, clearHistory }: { history: RequestRecord[]; copyId: (id: string) => void; clearHistory: () => void }) { return <section className="content-panel"><div className="section-toolbar"><div><span className="panel-kicker">REGISTRO DE ACTIVIDAD</span><h2>Historial de solicitudes</h2><p>Consulta el estado real de cada solicitud enviada al backend.</p></div><button className="danger-btn" onClick={clearHistory}><Trash2 size={15} /> Limpiar historial</button></div><div className="table-wrap"><table><thead><tr><th>ID JUGADOR</th><th>CANTIDAD</th><th>FECHA Y HORA</th><th>ESTADO</th><th>MENSAJE</th><th /></tr></thead><tbody>{history.map(item => <tr key={`${item.id}-${item.createdAt}`}><td><code>{item.id}</code></td><td><b>{item.amount}</b> likes</td><td>{formatDate(item.createdAt)}</td><td><StatusPill status={item.status} /></td><td>{item.message}</td><td><button className="table-action" onClick={() => copyId(item.id)} title="Copiar ID"><Copy size={15} /></button></td></tr>)}</tbody></table>{history.length === 0 && <div className="empty-state"><Clipboard size={28} /><b>Sin actividad todavía</b><p>Las solicitudes aparecerán aquí cuando uses el generador.</p></div>}</div></section>; }
function ThemesSection({ theme, setTheme, customAccent, setCustomAccent }: { theme: ThemeName; setTheme: (t: ThemeName) => void; customAccent: string; setCustomAccent: (v: string) => void }) { const themes: [ThemeName, string, string][] = [["blackBlue", "Negro / azul eléctrico", "#2e7dff"], ["blackViolet", "Negro / violeta", "#a78bfa"], ["blackRed", "Negro / rojo", "#ff6b7e"], ["blackGreen", "Negro / verde", "#70f0a8"], ["blackCyan", "Negro / cian", "#56e0ff"], ["whiteBlue", "Blanco / azul", "#2e7dff"], ["whiteViolet", "Blanco / violeta", "#845cff"], ["dark", "Modo oscuro", "#56e0ff"], ["light", "Modo claro", "#2e7dff"]]; return <section className="content-panel"><div className="section-toolbar"><div><span className="panel-kicker">IDENTIDAD VISUAL</span><h2>Elige tu frecuencia</h2><p>Personaliza el acento de todo el command center. Se guarda en este dispositivo.</p></div></div><div className="theme-grid">{themes.map(([key, label, color]) => <button key={key} className={`theme-option ${theme === key ? "selected" : ""}`} onClick={() => setTheme(key)}><span className="theme-preview" style={{ "--preview": color } as CSSProperties}><i /><i /><i /></span><span><b>{label}</b><small>{["whiteBlue", "whiteViolet", "light"].includes(key) ? "Modo claro" : "Modo oscuro"}</small></span>{theme === key && <CheckCircle2 size={18} />}</button>)}</div><div className={`custom-theme ${theme === "custom" ? "selected" : ""}`}><div><b>Color personalizado</b><p>Define un acento propio para el sistema de estados y acciones.</p></div><label className="color-picker"><input type="color" value={customAccent} onChange={event => { setCustomAccent(event.target.value); setTheme("custom"); }} /><span>{customAccent.toUpperCase()}</span></label></div></section>; }
function SettingsSection({ provider, checkProvider }: { provider: ProviderHealth; checkProvider: () => void }) { return <section className="content-panel settings-layout"><div className="section-toolbar"><div><span className="panel-kicker">SISTEMA</span><h2>Configuración</h2><p>Detalles operativos de VIP Like Generator.</p></div><button className="ghost-btn" onClick={checkProvider}><RefreshCw size={15} /> Comprobar conexión</button></div><div className="settings-list"><div className="setting-row"><span className="setting-icon"><Server size={18} /></span><div><b>Estado del proveedor</b><small>{provider.detail}</small></div><StatusPill status={provider.ok ? "confirmed" : "error"} /></div><div className="setting-row"><span className="setting-icon"><Activity size={18} /></span><div><b>Endpoint base</b><small>{API_BASE}</small></div><code>HTTPS</code></div><div className="setting-row"><span className="setting-icon"><Cpu size={18} /></span><div><b>Versión de aplicación</b><small>Build estable del command center</small></div><code>1.0.0</code></div><div className="setting-row"><span className="setting-icon"><ShieldCheck size={18} /></span><div><b>Modo de seguridad</b><small>Validación server-side y sin credenciales en cliente</small></div><span className="secure-label"><Check size={14} /> Activo</span></div></div></section>; }
function AdminSection({ user, isAuthenticated, authLoading, adminData, onLogin }: { user: any; isAuthenticated: boolean; authLoading: boolean; adminData: any; onLogin: () => void }) { if (authLoading) return <section className="content-panel admin-lock"><Loader2 className="spin" size={28} /><h2>Verificando acceso seguro</h2><p>Consultando tu sesión con el servidor.</p></section>; if (!isAuthenticated) return <section className="content-panel admin-lock"><div className="lock-icon"><ShieldCheck size={28} /></div><span className="panel-kicker">ÁREA RESTRINGIDA</span><h2>El panel admin requiere acceso</h2><p>Usa la autenticación segura de la plataforma. No hay contraseñas guardadas en el navegador.</p><button className="generate-btn compact" onClick={onLogin}><LogIn size={17} /> Iniciar sesión segura</button></section>; if (user?.role !== "admin") return <section className="content-panel admin-lock"><div className="lock-icon danger"><AlertTriangle size={28} /></div><span className="panel-kicker">PERMISOS INSUFICIENTES</span><h2>Tu cuenta no tiene rol admin</h2><p>El acceso está protegido por autorización server-side.</p></section>; return <section className="content-panel"><div className="section-toolbar"><div><span className="panel-kicker">ADMIN CONSOLE</span><h2>Control administrativo</h2><p>Datos agregados del servicio, sin exponer secretos.</p></div><span className="secure-label"><Check size={14} /> Autorizado</span></div><div className="admin-stats"><div><small>IDs PROCESADOS</small><strong>{adminData?.totalIds ?? "—"}</strong></div><div><small>SOLICITUDES</small><strong>{adminData?.totalRequests ?? "—"}</strong></div><div><small>SERVIDOR</small><strong>{adminData?.providerStatus ?? "—"}</strong></div></div><div className="admin-config"><div><b>Configuración del generador</b><small>Likes por solicitud</small></div><strong>200</strong><div><b>Historial general</b><small>{adminData?.recent?.length ? `${adminData.recent.length} registros recientes disponibles` : "Sin registros persistidos todavía"}</small></div></div><div className="admin-note"><BarChart3 size={18} /><span>El backend es la fuente de verdad. Los estados se muestran tal como responde el proveedor autorizado.</span></div>{adminData?.recent?.length > 0 && <div className="admin-history">{adminData.recent.slice(0, 5).map((item: any) => <div key={`${item.playerId}-${item.createdAt}`}><code>{item.playerId}</code><span>{item.amount} likes</span><StatusPill status={item.status} /></div>)}</div>}</section>; }
