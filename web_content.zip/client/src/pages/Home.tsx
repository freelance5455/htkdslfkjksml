import { useAuth } from "@/_core/hooks/useAuth";
import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";
import {
  ArrowUpRight,
  BriefcaseBusiness,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock3,
  LockKeyhole,
  ShieldCheck,
  Sparkles,
  Users,
  Wrench,
} from "lucide-react";
import { useMemo, useState } from "react";

const roleMeta: Record<string, { label: string; color: string; description: string }> = {
  owner: { label: "Owner", color: "bg-[#e9c46a]/25 text-[#8b6715] border-[#e9c46a]/40", description: "Full visibility and workspace control" },
  admin: { label: "Admin", color: "bg-[#e8dff5] text-[#65478f] border-[#c5afe7]", description: "Manage people, roles, and schedules" },
  recruiter: { label: "Recruiter", color: "bg-[#dff4ef] text-[#1c7565] border-[#a8ded2]", description: "Own the talent pipeline and onboarding" },
  technician: { label: "Technician", color: "bg-[#dcebf9] text-[#2c5d84] border-[#b3d1ea]", description: "Run field work and technical shifts" },
  trainee: { label: "Trainee", color: "bg-[#f6e8dc] text-[#995b36] border-[#e8c5a9]", description: "Follow training and assigned shifts" },
  user: { label: "Member", color: "bg-slate-100 text-slate-600 border-slate-200", description: "Workspace member" },
};

const statusMeta: Record<string, { label: string; className: string }> = {
  "in-progress": { label: "Live now", className: "bg-[#e9c46a]/20 text-[#8b6715]" },
  scheduled: { label: "Scheduled", className: "bg-slate-100 text-slate-600" },
  completed: { label: "Completed", className: "bg-[#dff4ef] text-[#1c7565]" },
};

function formatDay(value: Date | string) {
  return new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(new Date(value));
}

function formatTime(value: Date | string) {
  return new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(new Date(value));
}

function initials(name: string | null | undefined) {
  return (name || "Workspace").split(" ").map(part => part[0]).join("").slice(0, 2).toUpperCase();
}

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return <div className="min-h-screen bg-[#f5f3ee] flex items-center justify-center text-[#172d2b]"><div className="flex items-center gap-3 text-sm"><span className="h-2 w-2 rounded-full bg-[#e9a44c] animate-pulse" />Loading your workspace…</div></div>;
  }

  if (!isAuthenticated || !user) return <LoginScreen />;

  return <DashboardLayout><WorkspaceDashboard user={user} /></DashboardLayout>;
}

function LoginScreen() {
  const utils = trpc.useUtils();
  const localLogin = trpc.auth.localLogin.useMutation({ onSuccess: () => utils.auth.me.invalidate() });
  const resetRequest = trpc.auth.requestPasswordReset.useMutation();
  const [identifier, setIdentifier] = useState("");
  const [forgotOpen, setForgotOpen] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    localLogin.mutate({ identifier, password, rememberMe });
  };
  return (
    <main className="min-h-screen bg-[#f5f3ee] text-[#172d2b] overflow-hidden">
      <div className="absolute inset-0 opacity-40 [background-image:radial-gradient(#1c4740_0.7px,transparent_0.7px)] [background-size:22px_22px]" />
      <div className="relative mx-auto flex min-h-screen max-w-7xl flex-col px-6 py-6 lg:px-10">
        <header className="flex items-center justify-between border-b border-[#173d38]/10 pb-5"><div className="flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#173d38] text-[#f7e7c0]"><BriefcaseBusiness className="h-4 w-4" /></div><span className="font-display text-lg font-semibold tracking-tight">workroom<span className="text-[#d58c3d]">.</span></span></div><div className="hidden items-center gap-2 text-xs font-medium text-[#55716d] sm:flex"><LockKeyhole className="h-3.5 w-3.5" /> Private workspace</div></header>
        <section className="grid flex-1 items-center gap-16 py-12 lg:grid-cols-[1.05fr_0.95fr] lg:py-16">
          <div className="max-w-2xl"><div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#1c4740]/15 bg-white/65 px-3 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#55716d]"><Sparkles className="h-3.5 w-3.5 text-[#d58c3d]" /> Operations, in one place</div><h1 className="font-display max-w-xl text-5xl font-semibold leading-[0.98] tracking-[-0.05em] text-[#173d38] sm:text-7xl">A calmer way to run the workday.</h1><p className="mt-7 max-w-lg text-lg leading-8 text-[#55716d]">See your schedule, know your rank, and keep every role moving with one shared operating view.</p><div className="mt-10 flex items-center gap-3 text-xs text-[#71908a]"><ShieldCheck className="h-4 w-4 text-[#1c7565]" /> Sign in securely with OAuth or your local workspace account.</div></div>
          <div className="relative mx-auto w-full max-w-md lg:ml-auto"><div className="absolute -right-5 -top-8 h-24 w-24 rounded-full bg-[#e9c46a]/55 blur-2xl" /><div className="absolute -bottom-8 -left-5 h-28 w-28 rounded-full bg-[#8fc8bd]/45 blur-2xl" /><div className="relative rounded-[2rem] border border-white bg-[#173d38] p-4 shadow-[0_28px_65px_rgba(23,61,56,0.22)]"><div className="rounded-[1.35rem] bg-[#f9f7f1] p-6"><p className="text-[10px] font-semibold uppercase tracking-[0.18em] text-[#71908a]">Welcome back</p><h2 className="mt-2 font-display text-2xl font-semibold text-[#173d38]">Sign in to workroom</h2><form onSubmit={submit} className="mt-6 space-y-3"><label className="block text-xs font-semibold text-[#55716d]">Username or email<input required value={identifier} onChange={event => setIdentifier(event.target.value)} placeholder="username or you@company.com" className="mt-1.5 h-11 w-full rounded-xl border border-[#173d38]/15 bg-white px-3 text-sm text-[#173d38] outline-none focus:border-[#1c7565]" /></label><label className="block text-xs font-semibold text-[#55716d]">Password<input required type="password" minLength={8} value={password} onChange={event => setPassword(event.target.value)} placeholder="At least 8 characters" className="mt-1.5 h-11 w-full rounded-xl border border-[#173d38]/15 bg-white px-3 text-sm text-[#173d38] outline-none focus:border-[#1c7565]" /></label><label className="flex items-center gap-2 text-xs font-medium text-[#55716d]"><input type="checkbox" checked={rememberMe} onChange={event => setRememberMe(event.target.checked)} className="h-4 w-4 rounded border-[#173d38]/20 accent-[#173d38]" /> Remember me for 30 days</label>{localLogin.error && <p className="text-xs text-[#b64d4d]">Email or password is incorrect.</p>}<Button type="submit" disabled={localLogin.isPending} className="h-11 w-full rounded-xl bg-[#173d38] text-[#fffaf0] hover:bg-[#25584f]">{localLogin.isPending ? "Signing in…" : "Sign in locally"}</Button></form><button type="button" onClick={() => { setForgotOpen(value => !value); setResetSent(false); }} className="mt-3 w-full text-center text-xs font-semibold text-[#1c7565] hover:underline">Forgot password?</button>{forgotOpen && <form onSubmit={event => { event.preventDefault(); resetRequest.mutate({ identifier }, { onSuccess: () => setResetSent(true) }); }} className="mt-3 rounded-xl bg-[#e7f0ec] p-3"><p className="text-xs leading-4 text-[#55716d]">Enter your username or email. The workspace owner will review the request and reset it securely.</p><Button type="submit" disabled={resetRequest.isPending} className="mt-3 h-9 w-full rounded-lg bg-[#25584f] text-xs text-white hover:bg-[#173d38]">{resetRequest.isPending ? "Sending…" : "Request password help"}</Button>{resetSent && <p className="mt-2 text-center text-[11px] font-semibold text-[#1c7565]">Request sent. Check with your workspace owner.</p>}</form>}<div className="my-5 flex items-center gap-3 text-[10px] uppercase tracking-[0.16em] text-[#9cb3ae]"><span className="h-px flex-1 bg-[#173d38]/10" /> or <span className="h-px flex-1 bg-[#173d38]/10" /></div><Button type="button" onClick={() => startLogin()} variant="outline" className="h-11 w-full rounded-xl border-[#173d38]/15 bg-white text-[#173d38] hover:bg-[#e7f0ec]">Continue with work account <ArrowUpRight className="ml-2 h-4 w-4" /></Button><p className="mt-4 text-center text-[10px] leading-4 text-[#9cb3ae]">Local accounts are created by the workspace owner.</p></div></div></div>
        </section>
        <footer className="flex flex-col gap-2 border-t border-[#173d38]/10 pt-4 text-xs text-[#71908a] sm:flex-row sm:items-center sm:justify-between"><span>Built for teams that make things happen.</span><span className="flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5" /> Role-based access by default</span></footer>
      </div>
    </main>
  );
}

function WorkspaceDashboard({ user }: { user: NonNullable<ReturnType<typeof useAuth>["user"]> }) {
  const { data, isLoading, error } = trpc.dashboard.overview.useQuery();
  const [activeView, setActiveView] = useState<"overview" | "schedule" | "team" | "admin" | "profile">("overview");
  const viewerRole = roleMeta[user.role] ?? roleMeta.user;
  const schedules = data?.schedules ?? [];
  const team = data?.team ?? [];
  const upcoming = useMemo(() => schedules.filter(item => item.status !== "completed").slice(0, 4), [schedules]);
  const liveCount = schedules.filter(item => item.status === "in-progress").length;
  const onShiftCount = team.filter(item => item.status === "on-shift").length;
  const utils = trpc.useUtils();
  const createAccount = trpc.dashboard.createAccount.useMutation({ onSuccess: () => utils.dashboard.overview.invalidate() });
  const removeAccount = trpc.dashboard.removeAccount.useMutation({ onSuccess: () => utils.dashboard.overview.invalidate() });
  const createSchedule = trpc.dashboard.createSchedule.useMutation({ onSuccess: () => utils.dashboard.overview.invalidate() });
  const setAccountPassword = trpc.dashboard.setAccountPassword.useMutation({ onSuccess: () => utils.dashboard.overview.invalidate() });
  const { data: resetRequests = [] } = trpc.dashboard.passwordResetRequests.useQuery(undefined, { enabled: user.role === "owner" });
  const resolvePasswordReset = trpc.dashboard.resolvePasswordReset.useMutation({ onSuccess: () => utils.dashboard.passwordResetRequests.invalidate() });
  const changeMyPassword = trpc.dashboard.changeMyPassword.useMutation();
  const updateMyName = trpc.dashboard.updateMyName.useMutation({ onSuccess: async () => { await Promise.all([utils.auth.me.invalidate(), utils.dashboard.overview.invalidate()]); } });

  if (isLoading) return <DashboardLoading />;
  if (error) return <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-700">Unable to load the workspace right now. Refresh and try again.</div>;

  return (
    <div className="min-h-[calc(100vh-2rem)] bg-[#f5f3ee] px-3 py-3 text-[#173d38] sm:px-6 sm:py-5 lg:px-8">
      <div className="mx-auto max-w-[1500px]">
        <header className="flex flex-col gap-4 border-b border-[#173d38]/10 pb-6 sm:flex-row sm:items-end sm:justify-between"><div><div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#71908a]"><span className="h-2 w-2 rounded-full bg-[#d58c3d]" /> Workroom / {activeView}</div><h1 className="font-display text-3xl font-semibold tracking-[-0.04em] sm:text-4xl">Good morning, {user.name?.split(" ")[0] || "there"}.</h1><p className="mt-2 text-sm text-[#71908a]">Here’s the operational pulse for your team today.</p></div><div className="flex items-center gap-3"><div className="text-right"><div className={`hidden rounded-full border px-3 py-2 text-xs font-semibold sm:block ${viewerRole.color}`}>{viewerRole.label}</div><p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.12em] text-[#9cb3ae]">ID #{user.id}</p></div><div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#173d38] text-xs font-bold text-[#f7e7c0]">{initials(user.name)}</div></div></header>
        <nav className="mt-5 flex gap-1 overflow-x-auto rounded-xl border border-[#173d38]/10 bg-white/55 p-1"><NavButton active={activeView === "overview"} onClick={() => setActiveView("overview")} icon={<BriefcaseBusiness className="h-4 w-4" />}>Overview</NavButton><NavButton active={activeView === "schedule"} onClick={() => setActiveView("schedule")} icon={<CalendarDays className="h-4 w-4" />}>Schedule</NavButton><NavButton active={activeView === "team"} onClick={() => setActiveView("team")} icon={<Users className="h-4 w-4" />}>Team & ranks</NavButton><NavButton active={activeView === "profile"} onClick={() => setActiveView("profile")} icon={<LockKeyhole className="h-4 w-4" />}>Profile settings</NavButton>{(user.role === "owner" || user.role === "admin") && <NavButton active={activeView === "admin"} onClick={() => setActiveView("admin")} icon={<ShieldCheck className="h-4 w-4" />}>Administration</NavButton>}</nav>

        {activeView === "overview" && <><section className="mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><MetricCard icon={<Clock3 />} label="Next on deck" value={upcoming[0] ? formatTime(upcoming[0].startAt) : "—"} note={upcoming[0]?.title || "No shifts scheduled"} tone="gold" /><MetricCard icon={<CalendarDays />} label="Upcoming shifts" value={String(upcoming.length).padStart(2, "0")} note="Across the next few days" tone="mint" /><MetricCard icon={<Users />} label="On shift now" value={String(onShiftCount).padStart(2, "0")} note="People currently active" tone="lilac" /><MetricCard icon={<Wrench />} label="Live operations" value={String(liveCount).padStart(2, "0")} note="Requires attention now" tone="peach" /></section><section className="mt-6 grid gap-5 xl:grid-cols-[1.35fr_0.65fr]"><Card className="border-0 bg-white/85 shadow-[0_12px_35px_rgba(23,61,56,0.06)]"><CardHeader className="flex flex-row items-center justify-between pb-3"><div><CardTitle className="font-display text-xl text-[#173d38]">Your next shifts</CardTitle><p className="mt-1 text-xs text-[#71908a]">The next touchpoints on your rota</p></div><Button variant="ghost" className="text-xs text-[#1c7565] hover:bg-[#e7f0ec]" onClick={() => setActiveView("schedule")}>View all <ArrowUpRight className="ml-1 h-3.5 w-3.5" /></Button></CardHeader><CardContent className="space-y-2">{upcoming.map(item => <ScheduleRow key={item.id} item={item} />)}</CardContent></Card><Card className="border-0 bg-[#173d38] text-[#f9f7f1] shadow-[0_12px_35px_rgba(23,61,56,0.13)]"><CardHeader><div className="flex items-center justify-between"><CardTitle className="font-display text-xl">Your rank</CardTitle><ShieldCheck className="h-5 w-5 text-[#e9c46a]" /></div><p className="mt-1 text-xs text-[#a8c0bb]">What your role means in the room</p></CardHeader><CardContent><div className="rounded-2xl bg-white/10 p-4"><div className="flex items-center justify-between"><span className="text-xs text-[#c9dad5]">Current role</span><Badge className="border-0 bg-[#e9c46a] text-[#173d38]">{viewerRole.label}</Badge></div><p className="mt-4 font-display text-2xl font-semibold">{viewerRole.label}</p><p className="mt-2 text-xs leading-5 text-[#c9dad5]">{viewerRole.description}</p><div className="mt-5 flex items-center justify-between border-t border-white/10 pt-3 text-xs"><span className="text-[#a8c0bb]">Visibility</span><span className="font-semibold text-[#f7e7c0]">{user.role === "owner" || user.role === "admin" ? "Full team" : "Your work"}</span></div></div></CardContent></Card></section></>}
        {activeView === "schedule" && <section className="mt-6 space-y-5">{user.role === "owner" && <ScheduleManager accounts={data?.accounts ?? []} createSchedule={createSchedule} />}<Card className="border-0 bg-white/85 shadow-[0_12px_35px_rgba(23,61,56,0.06)]"><CardHeader><CardTitle className="font-display text-xl">Schedule board</CardTitle><p className="mt-1 text-xs text-[#71908a]">A shared view of shifts, briefings, and handovers.</p></CardHeader><CardContent className="space-y-2">{schedules.length === 0 ? <div className="rounded-2xl border border-dashed border-[#173d38]/15 bg-[#f5f3ee] px-5 py-10 text-center"><CalendarDays className="mx-auto h-6 w-6 text-[#9cb3ae]" /><p className="mt-3 text-sm font-semibold text-[#55716d]">No schedules yet</p><p className="mt-1 text-xs text-[#9cb3ae]">Owners can create the first shift above.</p></div> : schedules.map(item => <ScheduleRow key={item.id} item={item} detailed />)}</CardContent></Card></section>}
        {activeView === "team" && <section className="mt-6 grid gap-5 lg:grid-cols-[1fr_0.8fr]"><Card className="border-0 bg-white/85 shadow-[0_12px_35px_rgba(23,61,56,0.06)]"><CardHeader><CardTitle className="font-display text-xl">People & ranks</CardTitle><p className="mt-1 text-xs text-[#71908a]">Know who is active, and where each role sits.</p></CardHeader><CardContent className="space-y-2">{team.map(member => <TeamRow key={member.id} member={member} />)}</CardContent></Card><Card className="border-0 bg-[#e7f0ec] shadow-none"><CardHeader><CardTitle className="font-display text-xl text-[#173d38]">Role ladder</CardTitle><p className="mt-1 text-xs text-[#55716d]">A simple shared language for responsibility.</p></CardHeader><CardContent className="space-y-2">{(["owner", "admin", "recruiter", "technician", "trainee"] as const).map(role => <div key={role} className="flex items-center justify-between rounded-xl bg-white/70 px-3 py-3"><div><p className="text-sm font-semibold text-[#173d38]">{roleMeta[role].label}</p><p className="text-[11px] text-[#71908a]">{roleMeta[role].description}</p></div><span className={`rounded-full border px-2.5 py-1 text-[10px] font-semibold ${roleMeta[role].color}`}>{team.filter(member => member.role === role).length} people</span></div>)}</CardContent></Card></section>}
        {activeView === "profile" && <section className="mt-6"><ProfileSettings user={user} updateMyName={updateMyName} changeMyPassword={changeMyPassword} /></section>}
        {activeView === "admin" && (user.role === "owner" || user.role === "admin") && <section className="mt-6 space-y-5"><div><h2 className="font-display text-2xl font-semibold text-[#173d38]">Administration</h2><p className="mt-1 text-sm text-[#71908a]">Manage access, credentials, roles, and workspace accounts.</p></div>{user.role === "owner" ? <AccountManager userRole={user.role} accounts={data?.accounts ?? []} createAccount={createAccount} removeAccount={removeAccount} setAccountPassword={setAccountPassword} resetRequests={resetRequests} resolvePasswordReset={resolvePasswordReset} /> : <Card className="border-0 bg-white/85 shadow-[0_12px_35px_rgba(23,61,56,0.06)]"><CardContent className="flex items-start gap-3 p-6"><ShieldCheck className="mt-0.5 h-5 w-5 text-[#1c7565]" /><div><p className="text-sm font-semibold text-[#173d38]">Administrator access</p><p className="mt-1 text-xs leading-5 text-[#71908a]">You can review the workspace and manage operational data. Account creation and credential changes are reserved for the workspace owner.</p></div></CardContent></Card>}</section>}
        <footer className="mt-8 flex flex-col gap-2 border-t border-[#173d38]/10 pt-4 text-[11px] text-[#71908a] sm:flex-row sm:items-center sm:justify-between"><span>Signed in as <strong className="font-semibold text-[#55716d]">{user.name || "workspace member"}</strong> · ID #{user.id} · {user.email || "no email"}</span><span className="flex items-center gap-1.5"><CheckCircle2 className="h-3.5 w-3.5 text-[#1c7565]" /> Your access is managed by the workspace owner</span></footer>
      </div>
    </div>
  );
}

type AccountRole = "owner" | "admin" | "trainee" | "recruiter" | "technician" | "user";

function ProfileSettings({ user, updateMyName, changeMyPassword }: { user: { name?: string | null; email?: string | null; id: number; role: string }; updateMyName: { mutate: (input: { name: string }) => void; isPending: boolean; error: unknown; isSuccess: boolean }; changeMyPassword: { mutate: (input: { currentPassword: string; newPassword: string }) => void; isPending: boolean; error: unknown; isSuccess: boolean } }) {
  const [name, setName] = useState(user.name ?? "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const submitName = (event: React.FormEvent) => {
    event.preventDefault();
    if (name.trim() && name.trim() !== (user.name ?? "").trim()) updateMyName.mutate({ name: name.trim() });
  };
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (newPassword !== confirmPassword) return;
    changeMyPassword.mutate({ currentPassword, newPassword });
    setCurrentPassword(""); setNewPassword(""); setConfirmPassword("");
  };
  return <div className="grid gap-5 lg:grid-cols-[0.8fr_1.2fr]"><Card className="border-0 bg-[#173d38] text-[#f9f7f1] shadow-[0_12px_35px_rgba(23,61,56,0.13)]"><CardHeader><CardTitle className="font-display text-xl">Your profile</CardTitle><p className="mt-1 text-xs text-[#a8c0bb]">Your workspace identity and access level.</p></CardHeader><CardContent><form onSubmit={submitName} className="space-y-3"><label className="block text-xs font-semibold text-[#c9dad5]">Display name<input required minLength={2} maxLength={120} value={name} onChange={event => setName(event.target.value)} className="mt-1.5 h-11 w-full rounded-xl border border-white/15 bg-white/10 px-3 text-sm text-white outline-none placeholder:text-[#a8c0bb] focus:border-[#e9c46a]" /></label><div className="rounded-2xl bg-white/10 p-4"><p className="text-lg font-semibold">{name || "Workspace member"}</p><p className="mt-1 text-xs text-[#c9dad5]">{user.email || "No email"}</p><p className="mt-3 text-[10px] uppercase tracking-[0.14em] text-[#a8c0bb]">ID #{user.id} · {roleMeta[user.role]?.label ?? user.role}</p></div><Button type="submit" disabled={updateMyName.isPending || !name.trim() || name.trim() === (user.name ?? "").trim()} className="h-10 rounded-xl bg-[#e9c46a] text-[#173d38] hover:bg-[#f3d98e]">{updateMyName.isPending ? "Saving…" : "Save name"}</Button>{updateMyName.error ? <p className="text-xs text-[#f4b4a8]">Unable to save your name. Please try again.</p> : null}{updateMyName.isSuccess && <p className="text-xs font-semibold text-[#bde5d9]">Your name was updated.</p>}</form></CardContent></Card><Card className="border-0 bg-white/85 shadow-[0_12px_35px_rgba(23,61,56,0.06)]"><CardHeader><CardTitle className="font-display text-xl">Change password</CardTitle><p className="mt-1 text-xs text-[#71908a]">Use your current password to set a new one.</p></CardHeader><CardContent><form onSubmit={submit} className="max-w-md space-y-3"><input required minLength={8} type="password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} placeholder="Current password" className="h-11 w-full rounded-xl border border-[#173d38]/15 bg-white px-3 text-sm text-[#173d38] outline-none focus:border-[#1c7565]" /><input required minLength={8} type="password" value={newPassword} onChange={event => setNewPassword(event.target.value)} placeholder="New password" className="h-11 w-full rounded-xl border border-[#173d38]/15 bg-white px-3 text-sm text-[#173d38] outline-none focus:border-[#1c7565]" /><input required minLength={8} type="password" value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)} placeholder="Confirm new password" className="h-11 w-full rounded-xl border border-[#173d38]/15 bg-white px-3 text-sm text-[#173d38] outline-none focus:border-[#1c7565]" />{newPassword && confirmPassword && newPassword !== confirmPassword && <p className="text-xs text-[#b64d4d]">New passwords do not match.</p>}{changeMyPassword.error ? <p className="text-xs text-[#b64d4d]">Current password is incorrect.</p> : null}{changeMyPassword.isSuccess && <p className="text-xs font-semibold text-[#1c7565]">Password changed successfully.</p>}<Button type="submit" disabled={changeMyPassword.isPending || newPassword !== confirmPassword} className="h-11 rounded-xl bg-[#173d38] text-[#fffaf0] hover:bg-[#25584f]">{changeMyPassword.isPending ? "Saving…" : "Change password"}</Button></form></CardContent></Card></div>;
}

function ScheduleManager({ accounts, createSchedule }: { accounts: Array<{ id: number; username?: string | null; name: string; email: string; role: string }>; createSchedule: { mutate: (input: { title: string; location: string; shift: string; startAt: string; endAt: string; assigneeAccountId: number }) => void; isPending: boolean; error: unknown }; }) {
  const [title, setTitle] = useState("");
  const [location, setLocation] = useState("");
  const [shift, setShift] = useState("");
  const [startAt, setStartAt] = useState("");
  const [endAt, setEndAt] = useState("");
  const [assigneeAccountId, setAssigneeAccountId] = useState("");
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    if (!assigneeAccountId || !startAt || !endAt) return;
    createSchedule.mutate({ title, location, shift, startAt: new Date(startAt).toISOString(), endAt: new Date(endAt).toISOString(), assigneeAccountId: Number(assigneeAccountId) });
    setTitle(""); setLocation(""); setShift(""); setStartAt(""); setEndAt(""); setAssigneeAccountId("");
  };
  return <Card className="border-0 bg-[#173d38] text-[#f9f7f1] shadow-[0_12px_35px_rgba(23,61,56,0.13)]"><CardHeader><div className="flex items-center justify-between"><div><CardTitle className="font-display text-xl">Create a schedule</CardTitle><p className="mt-1 text-xs text-[#a8c0bb]">Assign a shift directly to a workspace account.</p></div><CalendarDays className="h-5 w-5 text-[#e9c46a]" /></div></CardHeader><CardContent>{accounts.length === 0 ? <div className="rounded-xl bg-white/10 px-4 py-4 text-xs text-[#c9dad5]">Create a team account first in Team & ranks, then you can assign schedules here.</div> : <form onSubmit={submit} className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3"><input required value={title} onChange={event => setTitle(event.target.value)} placeholder="Schedule title" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><input required value={location} onChange={event => setLocation(event.target.value)} placeholder="Location" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><input required value={shift} onChange={event => setShift(event.target.value)} placeholder="Shift label e.g. 09:00 — 17:00" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#a8c0bb]">Starts<input required type="datetime-local" value={startAt} onChange={event => setStartAt(event.target.value)} className="mt-1 h-10 w-full rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white outline-none focus:border-[#e9c46a]" /></label><label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#a8c0bb]">Ends<input required type="datetime-local" value={endAt} onChange={event => setEndAt(event.target.value)} className="mt-1 h-10 w-full rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white outline-none focus:border-[#e9c46a]" /></label><label className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#a8c0bb]">Assign to<select required value={assigneeAccountId} onChange={event => setAssigneeAccountId(event.target.value)} className="mt-1 h-10 w-full rounded-lg border border-white/15 bg-[#25584f] px-3 text-xs text-white outline-none"><option value="">Choose teammate</option>{accounts.map(account => <option key={account.id} value={account.id}>{account.name} · ID #{account.id}</option>)}</select></label><Button type="submit" disabled={createSchedule.isPending} className="h-10 bg-[#e9c46a] text-[#173d38] hover:bg-[#f3d887] sm:col-span-2 lg:col-span-3 lg:justify-self-start">{createSchedule.isPending ? "Creating…" : "Create and assign schedule"}</Button></form>}{createSchedule.error ? <p className="mt-3 text-xs text-[#f3b6a5]">Could not create the schedule. Check the times and assigned account.</p> : null}</CardContent></Card>;
}

function AccountManager({ userRole, accounts, createAccount, removeAccount, setAccountPassword, resetRequests, resolvePasswordReset }: { userRole: string; accounts: Array<{ id: number; username?: string | null; name: string; email: string; role: string }>; createAccount: { mutate: (input: { username: string; name: string; email: string; password: string; role: AccountRole }) => void; isPending: boolean; error: unknown }; removeAccount: { mutate: (input: { accountId: number }) => void; isPending: boolean }; setAccountPassword: { mutate: (input: { accountId: number; password: string }) => void; isPending: boolean; error: unknown }; resetRequests: Array<{ id: number; identifier: string; status: string; createdAt: Date | string }>; resolvePasswordReset: { mutate: (input: { requestId: number; accountId: number; password: string }) => void; isPending: boolean; error: unknown }; }) {
  const [username, setUsername] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [resetAccountId, setResetAccountId] = useState("");
  const [resetPassword, setResetPassword] = useState("");
  const [resolveAccountId, setResolveAccountId] = useState("");
  const [resolvePassword, setResolvePassword] = useState("");
  const [role, setRole] = useState<AccountRole>("trainee");
  if (userRole !== "owner") return null;
  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    createAccount.mutate({ username, name, email, password, role });
    setUsername(""); setName(""); setEmail(""); setPassword(""); setRole("trainee");
  };
  return <Card className="border-0 bg-[#173d38] text-[#f9f7f1] shadow-[0_12px_35px_rgba(23,61,56,0.13)]"><CardHeader><div className="flex items-center justify-between"><div><CardTitle className="font-display text-xl">Owner account desk</CardTitle><p className="mt-1 text-xs text-[#a8c0bb]">Create and remove workspace accounts.</p></div><ShieldCheck className="h-5 w-5 text-[#e9c46a]" /></div></CardHeader><CardContent><form onSubmit={submit} className="grid gap-2 sm:grid-cols-2 lg:grid-cols-[0.9fr_1fr_1fr_0.9fr_auto]"><input required minLength={3} value={username} onChange={event => setUsername(event.target.value)} onBlur={event => setUsername(event.target.value.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9._-]/g, ""))} placeholder="Username (spaces are converted)" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><input required value={name} onChange={event => setName(event.target.value)} placeholder="Full name" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><input required type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="Email address" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><input required type="password" minLength={8} value={password} onChange={event => setPassword(event.target.value)} placeholder="Temporary password" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><select value={role} onChange={event => setRole(event.target.value as AccountRole)} className="h-10 rounded-lg border border-white/15 bg-[#25584f] px-3 text-xs text-white outline-none"><option value="trainee">Trainee</option><option value="recruiter">Recruiter</option><option value="technician">Technician</option><option value="admin">Admin</option><option value="owner">Owner</option></select><Button type="submit" disabled={createAccount.isPending} className="h-10 bg-[#e9c46a] text-[#173d38] hover:bg-[#f3d887]">{createAccount.isPending ? "Adding…" : "Add account"}</Button></form>{createAccount.error ? <p className="mt-2 text-xs text-[#f3b6a5]">Could not create that account. Check that the username and email are unique and the password is at least 8 characters.</p> : null}<div className="mt-4 space-y-2">{accounts.length === 0 ? <p className="rounded-xl bg-white/10 px-3 py-3 text-xs text-[#c9dad5]">No owner-created accounts yet.</p> : accounts.map(account => <div key={account.id} className="flex items-center gap-3 rounded-xl bg-white/10 px-3 py-2.5"><div className="flex-1"><p className="text-xs font-semibold">{account.name}</p><p className="text-[10px] text-[#a8c0bb]">@{account.username || "not-set"} · ID #{account.id} · {account.email}</p></div><span className="rounded-full bg-white/10 px-2 py-1 text-[10px] text-[#c9dad5]">{roleMeta[account.role]?.label ?? account.role}</span><button type="button" disabled={removeAccount.isPending} onClick={() => removeAccount.mutate({ accountId: account.id })} className="text-[10px] font-semibold text-[#f3b6a5] hover:text-white">Remove</button></div>)}</div>{resetRequests.length > 0 && <div className="mt-5 border-t border-white/10 pt-4"><p className="text-xs font-semibold text-[#f7e7c0]">Password help requests</p><div className="mt-2 space-y-2">{resetRequests.filter(request => request.status === "pending").map(request => <div key={request.id} className="rounded-xl bg-white/10 p-3"><p className="text-xs font-semibold">{request.identifier}</p><form onSubmit={event => { event.preventDefault(); if (!resolveAccountId) return; resolvePasswordReset.mutate({ requestId: request.id, accountId: Number(resolveAccountId), password: resolvePassword }); setResolvePassword(""); }} className="mt-2 grid gap-2 sm:grid-cols-[1fr_1fr_auto]"><select required value={resolveAccountId} onChange={event => setResolveAccountId(event.target.value)} className="h-9 rounded-lg border border-white/15 bg-[#25584f] px-2 text-xs text-white outline-none"><option value="">Match account</option>{accounts.map(account => <option key={account.id} value={account.id}>{account.username ? `@${account.username}` : account.name}</option>)}</select><input required minLength={8} type="password" value={resolvePassword} onChange={event => setResolvePassword(event.target.value)} placeholder="New password" className="h-9 rounded-lg border border-white/15 bg-white/10 px-2 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><Button type="submit" disabled={resolvePasswordReset.isPending} className="h-9 bg-[#e9c46a] text-xs text-[#173d38] hover:bg-[#f3d887]">Resolve</Button></form></div>)}</div></div>}<div className="mt-5 border-t border-white/10 pt-4"><p className="text-xs font-semibold text-[#f7e7c0]">Reset a local password</p><p className="mt-1 text-[10px] text-[#a8c0bb]">Use this if a teammate cannot sign in.</p><form onSubmit={event => { event.preventDefault(); if (!resetAccountId) return; setAccountPassword.mutate({ accountId: Number(resetAccountId), password: resetPassword }); setResetPassword(""); }} className="mt-3 grid gap-2 sm:grid-cols-[1fr_1fr_auto]"><select required value={resetAccountId} onChange={event => setResetAccountId(event.target.value)} className="h-10 rounded-lg border border-white/15 bg-[#25584f] px-3 text-xs text-white outline-none"><option value="">Choose account</option>{accounts.map(account => <option key={account.id} value={account.id}>{account.username ? `@${account.username}` : account.name} · ID #{account.id}</option>)}</select><input required minLength={8} type="password" value={resetPassword} onChange={event => setResetPassword(event.target.value)} placeholder="New password" className="h-10 rounded-lg border border-white/15 bg-white/10 px-3 text-xs text-white placeholder:text-[#a8c0bb] outline-none focus:border-[#e9c46a]" /><Button type="submit" disabled={setAccountPassword.isPending} className="h-10 bg-white/15 text-white hover:bg-white/25">{setAccountPassword.isPending ? "Saving…" : "Set password"}</Button></form>{setAccountPassword.error ? <p className="mt-2 text-xs text-[#f3b6a5]">Could not set the password. Try again.</p> : null}</div></CardContent></Card>;
}

function NavButton({ active, onClick, icon, children }: { active: boolean; onClick: () => void; icon: React.ReactNode; children: React.ReactNode }) {
  return <button onClick={onClick} className={`flex items-center gap-2 whitespace-nowrap rounded-lg px-4 py-2.5 text-xs font-semibold transition-colors ${active ? "bg-[#173d38] text-[#fffaf0] shadow-sm" : "text-[#71908a] hover:bg-white hover:text-[#173d38]"}`}>{icon}{children}</button>;
}

function MetricCard({ icon, label, value, note, tone }: { icon: React.ReactNode; label: string; value: string; note: string; tone: "gold" | "mint" | "lilac" | "peach" }) {
  const tones = { gold: "bg-[#fff5d9] text-[#8b6715]", mint: "bg-[#e7f0ec] text-[#1c7565]", lilac: "bg-[#eee8f7] text-[#65478f]", peach: "bg-[#fae8dc] text-[#995b36]" };
  return <Card className="border-0 bg-white/85 shadow-[0_12px_35px_rgba(23,61,56,0.05)]"><CardContent className="p-5"><div className="flex items-start justify-between"><span className={`flex h-9 w-9 items-center justify-center rounded-xl ${tones[tone]}`}>{icon}</span><span className="text-[10px] font-semibold uppercase tracking-[0.12em] text-[#9cb3ae]">Today</span></div><p className="mt-5 font-display text-3xl font-semibold tracking-[-0.04em] text-[#173d38]">{value}</p><p className="mt-1 text-xs font-semibold text-[#55716d]">{label}</p><p className="mt-2 truncate text-[11px] text-[#9cb3ae]">{note}</p></CardContent></Card>;
}

function ScheduleRow({ item, detailed = false }: { item: { id: number; title: string; location: string; shift: string; startAt: Date | string; endAt: Date | string; status: string; assigneeName: string }; detailed?: boolean }) {
  const status = statusMeta[item.status] ?? statusMeta.scheduled;
  return <div className="group flex flex-col gap-3 rounded-2xl border border-[#173d38]/8 bg-white/65 p-4 transition-colors hover:border-[#8fc8bd] sm:flex-row sm:items-center"><div className="flex min-w-[118px] items-center gap-2"><div className={`h-2 w-2 rounded-full ${item.status === "in-progress" ? "bg-[#d58c3d]" : item.status === "completed" ? "bg-[#1c7565]" : "bg-[#9cb3ae]"}`} /><div><p className="text-xs font-semibold text-[#173d38]">{formatDay(item.startAt)}</p><p className="text-[11px] text-[#71908a]">{item.shift}</p></div></div><div className="min-w-0 flex-1"><p className="truncate text-sm font-semibold text-[#173d38]">{item.title}</p><p className="mt-1 truncate text-[11px] text-[#71908a]">{item.location} · {item.assigneeName}{detailed ? ` · ${formatTime(item.startAt)}–${formatTime(item.endAt)}` : ""}</p></div><Badge className={`w-fit border-0 text-[10px] ${status.className}`}>{status.label}</Badge><ChevronRight className="hidden h-4 w-4 text-[#b8c9c4] transition-transform group-hover:translate-x-0.5 sm:block" /></div>;
}

function TeamRow({ member }: { member: { id: number; name: string; initials: string; role: string; rank: string; status: string } }) {
  const meta = roleMeta[member.role] ?? roleMeta.user;
  return <div className="flex items-center gap-3 rounded-2xl border border-[#173d38]/8 bg-white/65 p-3"><div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#173d38] text-xs font-bold text-[#f7e7c0]">{member.initials}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><p className="truncate text-sm font-semibold text-[#173d38]">{member.name}</p><span className={`rounded-full border px-2 py-0.5 text-[10px] font-semibold ${meta.color}`}>{meta.label}</span></div><p className="mt-1 text-[11px] text-[#71908a]">{member.rank} · ID #{member.id}</p></div><span className="flex items-center gap-1.5 text-[10px] text-[#71908a]"><span className={`h-1.5 w-1.5 rounded-full ${member.status === "on-shift" ? "bg-[#d58c3d]" : member.status === "available" ? "bg-[#1c7565]" : "bg-[#b8c9c4]"}`} />{member.status === "on-shift" ? "On shift" : member.status === "available" ? "Available" : "Away"}</span></div>;
}

function DashboardLoading() {
  return <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{Array.from({ length: 4 }).map((_, index) => <div key={index} className="h-36 animate-pulse rounded-2xl bg-white/70" />)}</div>;
}
