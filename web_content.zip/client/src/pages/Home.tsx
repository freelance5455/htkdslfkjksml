import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  BarChart3,
  BookOpen,
  CalendarDays,
  Check,
  ChevronDown,
  CirclePlus,
  ClipboardList,
  FilePenLine,
  HardHat,
  Loader2,
  Phone,
  Plus,
  Printer,
  Trash2,
  UserRound,
  Users,
  X,
} from "lucide-react";
import { trpc } from "@/lib/trpc";

const formatDate = (date: Date) => {
  const year = date.getFullYear();
  const month = `${date.getMonth() + 1}`.padStart(2, "0");
  const day = `${date.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const getMonday = () => {
  const date = new Date();
  const offset = (date.getDay() + 6) % 7;
  date.setDate(date.getDate() - offset);
  return formatDate(date);
};

const today = () => formatDate(new Date());

function LoadingLine() {
  return (
    <div className="loading-line" aria-label="Loading">
      <Loader2 size={16} className="spin" /> Loading shop records…
    </div>
  );
}

function EmptyState({ title, body }: { title: string; body: string }) {
  return (
    <div className="empty-state">
      <ClipboardList size={28} strokeWidth={1.5} />
      <strong>{title}</strong>
      <span>{body}</span>
    </div>
  );
}

export default function Home() {
  const utils = trpc.useUtils();
  const [startDate, setStartDate] = useState(getMonday);
  const [endDate, setEndDate] = useState(today);
  const [customerId, setCustomerId] = useState("");
  const [receiptDate, setReceiptDate] = useState(today);
  const [quantity, setQuantity] = useState("1");
  const [note, setNote] = useState("");
  const [editingReceipt, setEditingReceipt] = useState<number | null>(null);
  const [customerDialog, setCustomerDialog] = useState<"new" | "edit" | null>(null);
  const [customerForm, setCustomerForm] = useState({ id: 0, name: "", phone: "" });

  const customersQuery = trpc.customers.list.useQuery();
  const receiptsQuery = trpc.receipts.list.useQuery({ startDate, endDate });
  const customers = customersQuery.data ?? [];
  const receipts = receiptsQuery.data ?? [];

  useEffect(() => {
    if (!customerId && customers[0]) setCustomerId(String(customers[0].id));
    if (customerId && !customers.some(customer => String(customer.id) === customerId)) {
      setCustomerId(customers[0] ? String(customers[0].id) : "");
    }
  }, [customers, customerId]);

  const totalBarrels = useMemo(() => receipts.reduce((total, receipt) => total + receipt.quantity, 0), [receipts]);
  const activeCustomerCount = useMemo(() => new Set(receipts.map(receipt => receipt.customerId)).size, [receipts]);
  const summary = useMemo(() => {
    const totals = new Map<number, number>();
    for (const receipt of receipts) totals.set(receipt.customerId, (totals.get(receipt.customerId) ?? 0) + receipt.quantity);
    return customers.map(customer => ({ ...customer, total: totals.get(customer.id) ?? 0 })).filter(customer => customer.total > 0);
  }, [customers, receipts]);

  const createReceipt = trpc.receipts.create.useMutation({
    onSuccess: async () => {
      await receiptsQuery.refetch();
      setQuantity("1");
      setNote("");
      setEditingReceipt(null);
      toast.success("Barrel receipt saved.");
    },
    onError: error => toast.error(error.message),
  });
  const updateReceipt = trpc.receipts.update.useMutation({
    onSuccess: async () => {
      await receiptsQuery.refetch();
      setQuantity("1");
      setNote("");
      setEditingReceipt(null);
      toast.success("Barrel receipt updated.");
    },
    onError: error => toast.error(error.message),
  });
  const deleteReceipt = trpc.receipts.remove.useMutation({
    onSuccess: async () => {
      await receiptsQuery.refetch();
      toast.success("Receipt removed.");
    },
    onError: error => toast.error(error.message),
  });
  const createCustomer = trpc.customers.create.useMutation({
    onSuccess: async customer => {
      await utils.customers.list.invalidate();
      if (customer) setCustomerId(String(customer.id));
      setCustomerDialog(null);
      setCustomerForm({ id: 0, name: "", phone: "" });
      toast.success("Customer added.");
    },
    onError: error => toast.error(error.message),
  });
  const updateCustomer = trpc.customers.update.useMutation({
    onSuccess: async () => {
      await utils.customers.list.invalidate();
      setCustomerDialog(null);
      toast.success("Customer details updated.");
    },
    onError: error => toast.error(error.message),
  });
  const deleteCustomer = trpc.customers.remove.useMutation({
    onSuccess: async () => {
      await utils.customers.list.invalidate();
      setCustomerId("");
      toast.success("Customer removed.");
    },
    onError: error => toast.error(error.message),
  });

  const resetReceiptForm = () => {
    setEditingReceipt(null);
    setReceiptDate(today());
    setQuantity("1");
    setNote("");
  };

  const handleReceiptSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!customerId) {
      toast.error("Add a customer before recording a receipt.");
      return;
    }
    const data = {
      customerId: Number(customerId),
      receiptDate,
      quantity: Number(quantity),
      note: note.trim() || undefined,
    };
    if (!Number.isInteger(data.quantity) || data.quantity < 1) {
      toast.error("Enter at least 1 barrel.");
      return;
    }
    if (editingReceipt) updateReceipt.mutate({ id: editingReceipt, data });
    else createReceipt.mutate(data);
  };

  const handleEditReceipt = (receipt: (typeof receipts)[number]) => {
    setEditingReceipt(receipt.id);
    setCustomerId(String(receipt.customerId));
    setReceiptDate(receipt.receiptDate);
    setQuantity(String(receipt.quantity));
    setNote(receipt.note ?? "");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const openNewCustomer = () => {
    setCustomerForm({ id: 0, name: "", phone: "" });
    setCustomerDialog("new");
  };

  const openEditCustomer = (customer: (typeof customers)[number]) => {
    setCustomerForm({ id: customer.id, name: customer.name, phone: customer.phone ?? "" });
    setCustomerDialog("edit");
  };

  const handleCustomerSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = { name: customerForm.name, phone: customerForm.phone || undefined };
    if (!data.name.trim()) {
      toast.error("Enter the customer name.");
      return;
    }
    if (customerDialog === "edit") updateCustomer.mutate({ id: customerForm.id, data });
    else createCustomer.mutate(data);
  };

  const busy = createReceipt.isPending || updateReceipt.isPending;
  const customerBusy = createCustomer.isPending || updateCustomer.isPending;
  const selectedCustomer = customers.find(customer => String(customer.id) === customerId);

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand-lockup">
            <div className="barrel-mark"><span /></div>
            <div>
              <div className="eyebrow light">SHOP LEDGER</div>
              <div className="brand-name">BarrelCount</div>
            </div>
          </div>
          <div className="shop-location"><HardHat size={17} /> Hard Chrome <span>•</span> Peshawar</div>
        </div>
      </header>

      <main className="page-wrap">
        <section className="intro-row">
          <div>
            <div className="eyebrow">DAILY RECEIVING REGISTER</div>
            <h1>Every barrel accounted for.</h1>
            <p>Record what comes in today, then share the customer totals when it is time to pay.</p>
          </div>
          <div className="period-card">
            <div className="eyebrow">REPORT PERIOD</div>
            <div className="date-range">
              <label><span>From</span><input type="date" value={startDate} onChange={event => setStartDate(event.target.value)} /></label>
              <span className="range-arrow">→</span>
              <label><span>To</span><input type="date" value={endDate} onChange={event => setEndDate(event.target.value)} /></label>
            </div>
          </div>
        </section>

        <section className="stat-strip" aria-label="Selected period totals">
          <div className="stat-cell stat-primary"><div className="stat-icon"><BarChart3 size={18} /></div><div><span>Total barrels</span><strong>{totalBarrels}</strong></div></div>
          <div className="stat-cell"><div className="stat-icon muted"><Users size={18} /></div><div><span>Customers with activity</span><strong>{activeCustomerCount}</strong></div></div>
          <div className="stat-cell"><div className="stat-icon muted"><CalendarDays size={18} /></div><div><span>Entries in this period</span><strong>{receipts.length}</strong></div></div>
        </section>

        <section className="workbench-grid">
          <div className="main-column">
            <section className="panel receive-panel">
              <div className="panel-heading">
                <div><div className="section-kicker"><CirclePlus size={16} /> RECEIVING DESK</div><h2>{editingReceipt ? "Correct a receipt" : "Record barrels received"}</h2></div>
                {editingReceipt && <button className="quiet-button" onClick={resetReceiptForm}><X size={15} /> Cancel edit</button>}
              </div>
              <form className="receipt-form" onSubmit={handleReceiptSubmit}>
                <div className="field-block wide-field">
                  <label htmlFor="customer">Customer</label>
                  <div className="select-with-action">
                    <select id="customer" value={customerId} onChange={event => setCustomerId(event.target.value)}>
                      <option value="">Select customer…</option>
                      {customers.map(customer => <option key={customer.id} value={customer.id}>{customer.name}</option>)}
                    </select>
                    <button type="button" className="icon-button" onClick={openNewCustomer} aria-label="Add customer"><Plus size={19} /></button>
                  </div>
                  {!customers.length && <span className="field-hint">Start by adding the first customer.</span>}
                </div>
                <div className="form-row">
                  <div className="field-block"><label htmlFor="receipt-date">Receipt date</label><input id="receipt-date" type="date" value={receiptDate} onChange={event => setReceiptDate(event.target.value)} /></div>
                  <div className="field-block"><label htmlFor="quantity">Barrels received</label><input id="quantity" type="number" min="1" step="1" inputMode="numeric" value={quantity} onChange={event => setQuantity(event.target.value)} /></div>
                </div>
                <div className="field-block"><label htmlFor="note">Note <span className="optional">(optional)</span></label><input id="note" type="text" placeholder="e.g. morning delivery" value={note} onChange={event => setNote(event.target.value)} /></div>
                <button className="primary-button" type="submit" disabled={busy || !selectedCustomer}><Check size={18} /> {busy ? "Saving…" : editingReceipt ? "Save correction" : "Save receipt"}</button>
              </form>
            </section>

            <section className="panel activity-panel">
              <div className="panel-heading activity-heading"><div><div className="section-kicker"><BookOpen size={16} /> DAILY ACTIVITY</div><h2>Received in this period</h2></div><span className="count-badge">{receipts.length} {receipts.length === 1 ? "entry" : "entries"}</span></div>
              {receiptsQuery.isLoading ? <LoadingLine /> : receipts.length === 0 ? <EmptyState title="No receipts in this period" body="Change the dates above or record the first delivery." /> : <div className="activity-list">
                {receipts.map(receipt => <article className="activity-row" key={receipt.id}>
                  <div className="activity-date"><strong>{new Date(`${receipt.receiptDate}T12:00:00`).toLocaleDateString("en-GB", { day: "2-digit" })}</strong><span>{new Date(`${receipt.receiptDate}T12:00:00`).toLocaleDateString("en-GB", { month: "short" })}</span></div>
                  <div className="activity-info"><strong>{receipt.customerName ?? "Unknown customer"}</strong><span>{receipt.receiptDate}{receipt.note ? `  •  ${receipt.note}` : ""}</span></div>
                  <div className="quantity-pill"><span>BARRELS</span><strong>{receipt.quantity}</strong></div>
                  <div className="row-actions"><button className="row-action" onClick={() => handleEditReceipt(receipt)} aria-label="Edit receipt"><FilePenLine size={16} /></button><button className="row-action danger" onClick={() => { if (window.confirm("Remove this barrel receipt?")) { if (editingReceipt === receipt.id) resetReceiptForm(); deleteReceipt.mutate({ id: receipt.id }); } }} aria-label="Delete receipt"><Trash2 size={16} /></button></div>
                </article>)}
              </div>}
            </section>
          </div>

          <aside className="side-column">
            <section className="panel summary-panel" id="payment-summary">
              <div className="panel-heading"><div><div className="section-kicker"><BarChart3 size={16} /> PAYMENT SUMMARY</div><h2>Who should pay what</h2></div><button className="icon-text-button print-only-hide" onClick={() => window.print()}><Printer size={15} /> Print</button></div>
              <div className="summary-period">{startDate} <span>→</span> {endDate}</div>
              {receiptsQuery.isLoading ? <LoadingLine /> : summary.length === 0 ? <EmptyState title="Nothing to total yet" body="Customer totals will appear here as you record receipts." /> : <div className="summary-list">{summary.map(customer => <div className="summary-row" key={customer.id}><div className="avatar-stamp">{customer.name.slice(0, 1).toUpperCase()}</div><div className="summary-name"><strong>{customer.name}</strong>{customer.phone && <span><Phone size={12} /> {customer.phone}</span>}</div><div className="summary-total"><strong>{customer.total}</strong><span>barrels</span></div></div>)}</div>}
              <div className="summary-footer"><span>Grand total</span><strong>{totalBarrels} barrels</strong></div>
            </section>

            <section className="panel customers-panel">
              <div className="panel-heading"><div><div className="section-kicker"><UserRound size={16} /> CUSTOMER BOOK</div><h2>Customers</h2></div><button className="icon-text-button" onClick={openNewCustomer}><Plus size={15} /> New</button></div>
              {customersQuery.isLoading ? <LoadingLine /> : customers.length === 0 ? <EmptyState title="No customers yet" body="Add a customer to start receiving barrels." /> : <div className="customer-list">{customers.map(customer => <div className="customer-row" key={customer.id}><div><strong>{customer.name}</strong>{customer.phone && <span>{customer.phone}</span>}</div><div className="customer-actions"><button className="row-action" onClick={() => openEditCustomer(customer)} aria-label={`Edit ${customer.name}`}><FilePenLine size={15} /></button><button className="row-action danger" onClick={() => { if (window.confirm(`Remove ${customer.name}? Customers with barrel history cannot be removed.`)) deleteCustomer.mutate({ id: customer.id }); }} aria-label={`Delete ${customer.name}`}><Trash2 size={15} /></button></div></div>)}</div>}
            </section>
          </aside>
        </section>

        <footer className="app-footer"><span>BarrelCount Peshawar</span><span>Keep the register close to the work.</span></footer>
      </main>

      {customerDialog && <div className="modal-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) setCustomerDialog(null); }}><div className="modal-card" role="dialog" aria-modal="true" aria-labelledby="customer-dialog-title"><div className="modal-head"><div><div className="section-kicker"><UserRound size={15} /> CUSTOMER BOOK</div><h2 id="customer-dialog-title">{customerDialog === "edit" ? "Edit customer" : "Add a customer"}</h2></div><button className="row-action" onClick={() => setCustomerDialog(null)} aria-label="Close"><X size={18} /></button></div><form onSubmit={handleCustomerSubmit} className="modal-form"><div className="field-block"><label htmlFor="customer-name">Customer name</label><input id="customer-name" autoFocus value={customerForm.name} onChange={event => setCustomerForm({ ...customerForm, name: event.target.value })} placeholder="e.g. Ahmad Steel Works" /></div><div className="field-block"><label htmlFor="customer-phone">Phone <span className="optional">(optional)</span></label><input id="customer-phone" type="tel" value={customerForm.phone} onChange={event => setCustomerForm({ ...customerForm, phone: event.target.value })} placeholder="0300 1234567" /></div><div className="modal-actions"><button type="button" className="quiet-button" onClick={() => setCustomerDialog(null)}>Cancel</button><button type="submit" className="primary-button" disabled={customerBusy}>{customerBusy ? "Saving…" : customerDialog === "edit" ? "Save customer" : "Add customer"}</button></div></form></div></div>}
    </div>
  );
}
