import { useEffect, useState } from "react";
import {
  Activity, AlertTriangle, ArrowDownRight, ArrowRight, ArrowUpRight, Bell, Check, CheckCircle2,
  ChevronRight, CircleDollarSign, Clock3, Cloud, Copy, Database, DownloadCloud, FileText, Gauge,
  LayoutDashboard, LockKeyhole, LogOut, Megaphone, Menu, MessageSquareText, Plus, Rocket,
  ScrollText, ShieldCheck, SlidersHorizontal, Smartphone, TrendingUp, UsersRound, X,
} from "lucide-react";
import {
  Area, AreaChart, Bar, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip,
  XAxis, YAxis,
} from "recharts";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const emerald = "#14836d";
const navItems = [
  { id: "overview", label: "Overview", icon: LayoutDashboard, group: "COMMAND" },
  { id: "growth", label: "Users & growth", icon: UsersRound, group: "COMMAND" },
  { id: "revenue", label: "Revenue", icon: CircleDollarSign, group: "COMMAND" },
  { id: "reliability", label: "Reliability", icon: Activity, group: "OPERATIONS" },
  { id: "support", label: "Feedback & support", icon: MessageSquareText, group: "OPERATIONS" },
  { id: "releases", label: "App releases", icon: Smartphone, group: "OPERATIONS" },
  { id: "usage", label: "Backend & cost", icon: Database, group: "OPERATIONS" },
  { id: "features", label: "Feature controls", icon: SlidersHorizontal, group: "MANAGE" },
  { id: "announcements", label: "Announcements", icon: Megaphone, group: "MANAGE" },
  { id: "team", label: "Admin team", icon: ShieldCheck, group: "MANAGE", ownerOnly: true },
  { id: "audit", label: "Audit history", icon: ScrollText, group: "MANAGE" },
] as const;

type SectionId = (typeof navItems)[number]["id"];
type Role = "owner" | "admin" | "analyst" | "support";
type RecoveryProps = { codes: string[]; onContinue: () => void };

function makeBase32Secret() {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const bytes = crypto.getRandomValues(new Uint8Array(20));
  let bits = "";
  for (const byte of bytes) bits += byte.toString(2).padStart(8, "0");
  let result = "";
  for (let i = 0; i < bits.length; i += 5) result += alphabet[parseInt(bits.slice(i, i + 5).padEnd(5, "0"), 2)];
  return result;
}
function fmt(value: number) { return new Intl.NumberFormat("en-US").format(value); }
function usd(value: number) { return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(value); }
function shortDate(value: string | Date) { return new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(new Date(value)); }
function roleName(role: Role) { return ({ owner: "Owner", admin: "Administrator", analyst: "Analyst", support: "Support" })[role]; }
function initials(name: string) { return name.split(/[ @.]+/).filter(Boolean).slice(0, 2).map(part => part[0]?.toUpperCase()).join("") || "TO"; }

function Field({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) {
  return <label className="field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>;
}
function RecoveryCodes({ codes, onContinue }: RecoveryProps) {
  const copy = async () => {
    await navigator.clipboard.writeText(codes.join("\n"));
    toast.success("Recovery codes copied. Store them somewhere private.");
  };
  return <div className="auth-card recovery-card">
    <div className="auth-brand"><span className="brand-mark">T</span><span>TO‘LOVCHI <small>OWNER CONSOLE</small></span></div>
    <div className="auth-icon"><ShieldCheck size={22} /></div>
    <p className="eyebrow">ONE-TIME VIEW</p><h1>Save your recovery codes</h1>
    <p className="auth-copy">Each code can be used once if you lose your authenticator. Store these outside this phone. They will not be shown again.</p>
    <div className="recovery-grid">{codes.map(code => <code key={code}>{code}</code>)}</div>
    <button className="button secondary full" onClick={copy}><Copy size={16} /> Copy codes</button>
    <button className="button primary full" onClick={onContinue}>I saved my codes <ArrowRight size={16} /></button>
  </div>;
}

function Enrollment({ mode, inviteToken, onComplete }: { mode: "owner" | "invite"; inviteToken?: string; onComplete: () => void }) {
  const invite = trpc.auth.invitationInfo.useQuery({ token: inviteToken ?? "" }, { enabled: mode === "invite", retry: false });
  const bootstrap = trpc.auth.bootstrap.useMutation();
  const acceptInvite = trpc.auth.acceptInvitation.useMutation();
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [setupToken, setSetupToken] = useState("");
  const [password, setPassword] = useState("");
  const [secret, setSecret] = useState("");
  const [code, setCode] = useState("");
  const [recoveryCodes, setRecoveryCodes] = useState<string[] | null>(null);
  const [error, setError] = useState("");
  const loading = bootstrap.isPending || acceptInvite.isPending;
  useEffect(() => {
    if (mode === "invite" && invite.data?.valid && invite.data.email) setEmail(invite.data.email);
  }, [mode, invite.data]);
  const startEnrollment = () => {
    if (password.length < 12) { setError("Use a password with at least 12 characters."); return; }
    setSecret(makeBase32Secret());
    setError("");
  };
  const submit = async (event: React.FormEvent) => {
    event.preventDefault(); setError("");
    try {
      const result = mode === "owner"
        ? await bootstrap.mutateAsync({ setupToken, email, displayName, password, totpSecret: secret, code })
        : await acceptInvite.mutateAsync({ token: inviteToken ?? "", email, displayName, password, totpSecret: secret, code });
      setRecoveryCodes(result.recoveryCodes);
    } catch (e) { setError(e instanceof Error ? e.message : "Enrollment could not be completed."); }
  };
  if (mode === "invite" && invite.isLoading) return <div className="auth-shell"><div className="auth-card"><Loader /></div></div>;
  if (mode === "invite" && (!invite.data?.valid || invite.isError)) return <div className="auth-shell"><div className="auth-card"><div className="auth-brand"><span className="brand-mark">T</span><span>TO‘LOVCHI <small>OWNER CONSOLE</small></span></div><h1>Invitation unavailable</h1><p className="auth-copy">This invitation may have expired or already been used. Ask the owner to create a new one.</p><a className="button secondary full" href="/">Back to sign in</a></div></div>;
  if (recoveryCodes) return <div className="auth-shell"><RecoveryCodes codes={recoveryCodes} onContinue={onComplete} /></div>;
  return <div className="auth-shell">
    <div className="auth-card enrollment-card">
      <div className="auth-brand"><span className="brand-mark">T</span><span>TO‘LOVCHI <small>OWNER CONSOLE</small></span></div>
      <div className="auth-icon"><ShieldCheck size={22} /></div>
      <p className="eyebrow">{mode === "owner" ? "FIRST-TIME SETUP" : "SECURE TEAM INVITATION"}</p>
      <h1>{mode === "owner" ? "Create the owner account" : "Set up your admin access"}</h1>
          <p className="auth-copy">{mode === "owner" ? "Create the first dashboard administrator. Two-factor authentication is required." : invite.data?.resetting ? `Your owner reset access for ${invite.data?.email}. Set a new password and enroll an authenticator before continuing.` : `This invitation is for ${invite.data?.email}. Set a password and authenticator before continuing.`}</p>
      {!secret ? <form onSubmit={event => { event.preventDefault(); startEnrollment(); }} className="auth-form">
        {mode === "owner" && <Field label="One-time setup token" hint="Use the token stored in your deployment secrets."><input required type="password" autoComplete="off" value={setupToken} onChange={e => setSetupToken(e.target.value)} /></Field>}
        <Field label="Name"><input required maxLength={120} value={displayName} onChange={e => setDisplayName(e.target.value)} /></Field>
        <Field label="Administrator email"><input required type="email" autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} disabled={mode === "invite"} /></Field>
        <Field label="Password" hint="At least 12 characters. Use a unique password."><input required type="password" minLength={12} maxLength={128} autoComplete="new-password" value={password} onChange={e => setPassword(e.target.value)} /></Field>
        <button className="button primary full" type="submit">Continue to authenticator setup <ArrowRight size={16} /></button>
      </form> : <form onSubmit={submit} className="auth-form">
        <div className="setup-steps"><span className="step done">1</span><span className="step-line" /><span className="step current">2</span><span>Authenticator app</span></div>
        <div className="secret-panel"><span>Manual setup key</span><code>{secret.match(/.{1,4}/g)?.join(" ")}</code><small>In your authenticator app, add an account manually using this key. Select time-based code (TOTP).</small></div>
        <Field label="6-digit authenticator code" hint="Enter the current code shown in your authenticator app."><input required inputMode="numeric" pattern="[0-9]{6}" maxLength={6} autoComplete="one-time-code" value={code} onChange={e => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} /></Field>
        {error && <div className="form-error">{error}</div>}
        <button className="button primary full" type="submit" disabled={loading || code.length !== 6}>{loading ? "Securing account…" : "Enable MFA & finish setup"} <ArrowRight size={16} /></button>
        <button className="text-button" type="button" onClick={() => { setSecret(""); setCode(""); setError(""); }}>Back to account details</button>
      </form>}
      {error && !secret && <div className="form-error">{error}</div>}
      <div className="auth-security-note"><LockKeyhole size={14} /><span>Authenticator secrets are encrypted at rest. Recovery codes are displayed once.</span></div>
    </div>
  </div>;
}

function Loader() { return <div className="loading-dots"><span /><span /><span /></div>; }

function Login({ onSignedIn, setupAvailable }: { onSignedIn: () => void; setupAvailable: boolean }) {
  const login = trpc.auth.login.useMutation();
  const verify = trpc.auth.verifySecondFactor.useMutation();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [challenge, setChallenge] = useState(false);
  const [recovery, setRecovery] = useState(false);
  const [error, setError] = useState("");
  const submitPassword = async (event: React.FormEvent) => {
    event.preventDefault(); setError("");
    try { await login.mutateAsync({ email, password }); setChallenge(true); }
    catch (e) { setError(e instanceof Error ? e.message : "Unable to sign in."); }
  };
  const submitCode = async (event: React.FormEvent) => {
    event.preventDefault(); setError("");
    try { await verify.mutateAsync({ code }); onSignedIn(); }
    catch (e) { setError(e instanceof Error ? e.message : "Code could not be verified."); }
  };
  return <div className="auth-shell">
    <div className="auth-card login-card">
      <div className="auth-brand"><span className="brand-mark">T</span><span>TO‘LOVCHI <small>OWNER CONSOLE</small></span></div>
      <div className="auth-icon"><LockKeyhole size={22} /></div>
      <p className="eyebrow">PRIVATE ADMIN ACCESS</p>
      <h1>{challenge ? "Verify it’s you" : "A clear view of the service."}</h1>
      <p className="auth-copy">{challenge ? "Enter the current code from your authenticator app, or use one saved recovery code." : "Sign in to manage TO‘LOVCHI operations. Personal financial records are never shown here."}</p>
      {!challenge ? <form onSubmit={submitPassword} className="auth-form">
        <Field label="Administrator email"><input required type="email" autoComplete="username" value={email} onChange={e => setEmail(e.target.value)} /></Field>
        <Field label="Password"><input required type="password" autoComplete="current-password" value={password} onChange={e => setPassword(e.target.value)} /></Field>
        {error && <div className="form-error">{error}</div>}
        <button className="button primary full" type="submit" disabled={login.isPending}>{login.isPending ? "Checking…" : "Continue"} <ArrowRight size={16} /></button>
      </form> : <form onSubmit={submitCode} className="auth-form">
        <Field label={recovery ? "One-time recovery code" : "Authenticator code"} hint={recovery ? "Each recovery code can be used once." : "Enter the current 6-digit code."}><input required autoFocus inputMode={recovery ? "text" : "numeric"} autoComplete="one-time-code" maxLength={recovery ? 40 : 6} value={code} onChange={e => setCode(recovery ? e.target.value : e.target.value.replace(/\D/g, "").slice(0, 6))} /></Field>
        {error && <div className="form-error">{error}</div>}
        <button className="button primary full" type="submit" disabled={verify.isPending}>{verify.isPending ? "Verifying…" : "Verify & sign in"} <ArrowRight size={16} /></button>
        <button className="text-button" type="button" onClick={() => { setRecovery(!recovery); setCode(""); setError(""); }}>{recovery ? "Use authenticator app instead" : "Use a recovery code"}</button>
        <button className="text-button subtle" type="button" onClick={() => { setChallenge(false); setCode(""); setPassword(""); }}>Back to password</button>
      </form>}
      {error && !challenge && setupAvailable && <a className="setup-link" href="/?setup=owner">First-time owner setup <ChevronRight size={15} /></a>}
      {!setupAvailable && !challenge && <div className="auth-security-note"><ShieldCheck size={14} /><span>First-time enrollment is available after the owner adds setup secrets to the deployment.</span></div>}
      <div className="auth-footer">Protected with two-factor verification <span>·</span> Access events are audited</div>
    </div>
    <div className="auth-privacy"><ShieldCheck size={16} /><span>Aggregate service insight. No personal debts, balances, income, zakat details or financial records.</span></div>
  </div>;
}

function DemoBanner() {
  return <div className="demo-banner"><span className="demo-pulse" /><div><strong>Demonstration data</strong><span>Live analytics, billing, crash and cloud sources are not connected yet.</span></div><span className="demo-tag">DEMO</span></div>;
}
function PageHeading({ eyebrow, title, subtitle, actions }: { eyebrow: string; title: string; subtitle: string; actions?: React.ReactNode }) {
  return <div className="page-heading"><div><p className="eyebrow">{eyebrow}</p><h1>{title}</h1><p>{subtitle}</p></div><div className="heading-actions">{actions}</div></div>;
}
function Panel({ title, subtitle, action, children, className = "" }: { title: string; subtitle?: string; action?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return <section className={`panel ${className}`}><div className="panel-head"><div><h3>{title}</h3>{subtitle && <p>{subtitle}</p>}</div>{action}</div>{children}</section>;
}
function Metric({ label, value, delta, icon: Icon, tone = "green", detail }: { label: string; value: string; delta?: string; icon: typeof UsersRound; tone?: string; detail?: string }) {
  return <article className="metric-card"><div className={`metric-icon ${tone}`}><Icon size={18} /></div><span className="metric-label">{label}</span><strong className="metric-value">{value}</strong><div className="metric-foot">{delta && <span className="positive"><ArrowUpRight size={14} />{delta}</span>}{detail && <span>{detail}</span>}</div><span className={`metric-edge ${tone}`} /></article>;
}
function ChartTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (!active || !payload?.length) return null;
  return <div className="chart-tooltip"><span>{label}</span>{payload.map(item => <div key={item.name}><i style={{ background: item.color }} />{item.name}: {fmt(item.value)}</div>)}</div>;
}
function EmptyHint({ text }: { text: string }) { return <div className="empty-hint"><span className="empty-icon"><Cloud size={19} /></span><p>{text}</p></div>; }

function Dashboard({ admin, onLogout }: { admin: { id: number; email: string; displayName: string; role: Role }; onLogout: () => void }) {
  const [section, setSection] = useState<SectionId>(admin.role === "support" ? "support" : "overview");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false);
  const [showReleaseForm, setShowReleaseForm] = useState(false);
  const [inviteResult, setInviteResult] = useState<{ link: string; email: string; role: string } | null>(null);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState<"admin" | "analyst" | "support">("analyst");
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementBody, setAnnouncementBody] = useState("");
  const [announcementStatus, setAnnouncementStatus] = useState<"draft" | "published">("draft");
  const [releaseVersion, setReleaseVersion] = useState("");
  const [releasePlatform, setReleasePlatform] = useState<"android" | "ios" | "backend">("android");
  const [releaseStatus, setReleaseStatus] = useState<"planned" | "review" | "live" | "paused">("planned");
  const [releaseNotes, setReleaseNotes] = useState("");
  const utils = trpc.useUtils();
  const overview = trpc.dashboard.overview.useQuery(undefined, { enabled: ["overview", "growth", "revenue"].includes(section), staleTime: 30_000 });
  const incidents = trpc.dashboard.incidents.useQuery(undefined, { enabled: section === "reliability", staleTime: 30_000 });
  const support = trpc.dashboard.support.useQuery(undefined, { enabled: section === "support", staleTime: 30_000 });
  const usage = trpc.dashboard.usage.useQuery(undefined, { enabled: section === "usage", staleTime: 30_000 });
  const features = trpc.configuration.listFeatures.useQuery(undefined, { enabled: section === "features" });
  const announcements = trpc.configuration.listAnnouncements.useQuery(undefined, { enabled: section === "announcements" });
  const releases = trpc.operations.listReleases.useQuery(undefined, { enabled: section === "releases" });
  const audit = trpc.audit.list.useQuery({ limit: 60 }, { enabled: section === "audit" });
  const team = trpc.team.list.useQuery(undefined, { enabled: section === "team" && (admin.role === "owner" || admin.role === "admin") });
  const invitations = trpc.team.invitations.useQuery(undefined, { enabled: section === "team" && (admin.role === "owner" || admin.role === "admin") });
  const featureMutation = trpc.configuration.setFeature.useMutation({ onSuccess: async () => { toast.success("Feature setting saved and recorded."); await utils.configuration.listFeatures.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const announcementMutation = trpc.configuration.createAnnouncement.useMutation({ onSuccess: async () => { toast.success("Announcement saved."); setShowAnnouncementForm(false); setAnnouncementTitle(""); setAnnouncementBody(""); await utils.configuration.listAnnouncements.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const releaseMutation = trpc.operations.createRelease.useMutation({ onSuccess: async () => { toast.success("Release information saved."); setShowReleaseForm(false); setReleaseVersion(""); setReleaseNotes(""); await utils.operations.listReleases.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const inviteMutation = trpc.team.invite.useMutation({ onSuccess: async result => { setInviteResult(result); setInviteEmail(""); await utils.team.list.invalidate(); await utils.team.invitations.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const roleMutation = trpc.team.changeRole.useMutation({ onSuccess: async () => { toast.success("Role updated and audited."); await utils.team.list.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const isWriter = admin.role === "owner" || admin.role === "admin";
  const availableNav = navItems.filter(item => {
    if (admin.role === "support") return item.id === "support" || item.id === "team";
    if ("ownerOnly" in item && item.ownerOnly && admin.role !== "owner" && admin.role !== "admin") return false;
    if (item.id === "support" && admin.role === "analyst") return false;
    return true;
  });
  const selected = availableNav.find(item => item.id === section);
  const today = new Intl.DateTimeFormat("en-US", { weekday: "long", month: "long", day: "numeric" }).format(new Date());
  const title = selected?.id === "team" && admin.role === "support" ? "My account" : selected?.label ?? "Overview";
  const setPage = (id: SectionId) => { setSection(id); setMobileMenu(false); };
  const handleCopyInvite = async () => {
    if (!inviteResult) return;
    const url = `${window.location.origin}${inviteResult.link}`;
    await navigator.clipboard.writeText(url); toast.success("Invitation link copied. Share it privately with the invited administrator.");
  };

  return <div className="app-frame">
    <aside className={`sidebar ${mobileMenu ? "mobile-open" : ""}`}>
      <div className="sidebar-brand"><span className="brand-mark">T</span><div><strong>TO‘LOVCHI</strong><small>SUPER ADMIN</small></div><button className="mobile-close icon-button" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={18} /></button></div>
      <div className="workspace-pill"><span className="workspace-dot" /><span>OWNER WORKSPACE</span><ChevronRight size={13} /></div>
      <nav className="main-nav" aria-label="Dashboard sections">
        {(["COMMAND", "OPERATIONS", "MANAGE"] as const).map(group => <div className="nav-group" key={group}><span className="nav-group-label">{group}</span>{availableNav.filter(item => item.group === group).map(item => { const Icon = item.icon; return <button key={item.id} className={`nav-item ${section === item.id ? "active" : ""}`} onClick={() => setPage(item.id as SectionId)}><Icon size={17} strokeWidth={1.8} /><span>{item.id === "team" && admin.role === "support" ? "My account" : item.label}</span>{item.id === "reliability" && <i className="nav-count">2</i>}</button>; })}</div>)}
      </nav>
      <div className="sidebar-bottom"><div className="privacy-tile"><ShieldCheck size={16} /><span>Privacy-first<br /><strong>Aggregate insights only</strong></span></div><div className="profile-row"><div className="avatar">{initials(admin.displayName)}</div><div className="profile-info"><strong>{admin.displayName}</strong><span>{roleName(admin.role)}</span></div><button className="icon-button logout-button" onClick={onLogout} title="Sign out" aria-label="Sign out"><LogOut size={16} /></button></div></div>
    </aside>
    {mobileMenu && <button className="mobile-scrim" onClick={() => setMobileMenu(false)} aria-label="Close navigation" />}
    <main className="main-area">
      <header className="topbar"><button className="icon-button mobile-menu-button" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={20} /></button><div className="breadcrumb"><span>TO‘LOVCHI</span><ChevronRight size={13} /><strong>{title}</strong></div><div className="topbar-right"><div className="live-status demo-indicator" role="status"><span />DEMO DATA</div><button className="icon-button notice-button" onClick={() => setPage("reliability")} aria-label="View incidents"><Bell size={18} /><i /></button><div className="top-avatar">{initials(admin.displayName)}</div></div></header>
      <div className="content-area">
        <DemoBanner />
        {section === "overview" && <Overview data={overview.data} loading={overview.isLoading} onNavigate={setPage} date={today} />}
        {section === "growth" && <Growth data={overview.data} loading={overview.isLoading} />}
        {section === "revenue" && <Revenue data={overview.data} loading={overview.isLoading} />}
        {section === "reliability" && <Reliability data={incidents.data?.items} loading={incidents.isLoading} />}
        {section === "support" && <Support data={support.data?.items} loading={support.isLoading} />}
        {section === "usage" && <Usage data={usage.data} loading={usage.isLoading} />}
        {section === "features" && <Features data={features.data} loading={features.isLoading} canEdit={isWriter} onToggle={(key, enabled) => featureMutation.mutate({ key, enabled })} pending={featureMutation.isPending} />}
        {section === "announcements" && <Announcements data={announcements.data} loading={announcements.isLoading} canEdit={isWriter} showForm={showAnnouncementForm} setShowForm={setShowAnnouncementForm} title={announcementTitle} setTitle={setAnnouncementTitle} body={announcementBody} setBody={setAnnouncementBody} status={announcementStatus} setStatus={setAnnouncementStatus} onSubmit={() => announcementMutation.mutate({ title: announcementTitle, body: announcementBody, status: announcementStatus })} pending={announcementMutation.isPending} />}
        {section === "releases" && <Releases data={releases.data?.items} mode={releases.data?.dataMode} loading={releases.isLoading} canEdit={isWriter} showForm={showReleaseForm} setShowForm={setShowReleaseForm} version={releaseVersion} setVersion={setReleaseVersion} platform={releasePlatform} setPlatform={setReleasePlatform} status={releaseStatus} setStatus={setReleaseStatus} notes={releaseNotes} setNotes={setReleaseNotes} onSubmit={() => releaseMutation.mutate({ version: releaseVersion, platform: releasePlatform, status: releaseStatus, notes: releaseNotes })} pending={releaseMutation.isPending} />}
        {section === "team" && <Team members={team.data} invites={invitations.data} role={admin.role} inviteEmail={inviteEmail} setInviteEmail={setInviteEmail} inviteRole={inviteRole} setInviteRole={setInviteRole} onInvite={() => inviteMutation.mutate({ email: inviteEmail, role: inviteRole })} pending={inviteMutation.isPending} inviteResult={inviteResult} onCopy={handleCopyInvite} onRoleChange={(adminId: number, role: "admin" | "analyst" | "support") => roleMutation.mutate({ adminId, role })} />}
        {section === "audit" && <Audit data={audit.data} loading={audit.isLoading} />}
        <footer className="app-footer"><span>TO‘LOVCHI ADMIN <i>·</i> Privacy by design</span><span>All times shown in your device timezone</span></footer>
      </div>
    </main>
    <div className="mobile-dock">{availableNav.filter(item => ["overview", "growth", "reliability", "features"].includes(item.id)).map(item => { const Icon = item.icon; return <button key={item.id} onClick={() => setPage(item.id as SectionId)} className={section === item.id ? "selected" : ""}><Icon size={19} /><span>{item.id === "reliability" ? "Ops" : item.id === "features" ? "Manage" : item.id === "growth" ? "Users" : "Home"}</span></button>; })}<button onClick={() => setMobileMenu(true)}><Menu size={19} /><span>More</span></button></div>
  </div>;
}

function Overview({ data, loading, onNavigate, date }: { data?: any; loading: boolean; onNavigate: (section: SectionId) => void; date: string }) {
  if (loading || !data) return <div className="loading-block"><Loader /></div>;
  return <>
    <PageHeading eyebrow={date.toUpperCase()} title="Your platform, at a glance." subtitle="An operational snapshot of the TO‘LOVCHI platform." actions={<button className="button secondary" onClick={() => onNavigate("growth")}><TrendingUp size={15} /> Explore growth <ChevronRight size={14} /></button>} />
    <div className="metric-grid four"><Metric label="Registered users" value={fmt(data.users.total)} delta={`${data.users.growthPercent}%`} icon={UsersRound} detail="month over month" /><Metric label="Active today" value={fmt(data.users.dau)} delta={`${fmt(data.users.mau)} MAU`} icon={Activity} tone="blue" detail="monthly active" /><Metric label="Premium subscribers" value={fmt(data.premium.subscribers)} delta={`${data.premium.changePercent}%`} icon={ShieldCheck} tone="purple" detail="active plans" /><Metric label="Revenue this month" value={usd(data.premium.monthlyRevenueUsd + data.ads.revenueMtdUsd)} delta="Premium + ads" icon={CircleDollarSign} tone="amber" detail="USD · demonstration" /></div>
    <div className="overview-grid">
      <Panel title="User growth" subtitle="New registrations · last 7 days" action={<button className="panel-link" onClick={() => onNavigate("growth")}>View growth <ArrowRight size={14} /></button>} className="chart-panel"><div className="chart-legend"><span><i className="legend-dot emerald" />Registrations</span><span className="chart-range">7 DAYS</span></div><div className="chart-wrap"><ResponsiveContainer width="100%" height={226}><AreaChart data={data.registrations} margin={{ top: 8, right: 4, left: -24, bottom: 0 }}><defs><linearGradient id="regFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={emerald} stopOpacity={0.18} /><stop offset="100%" stopColor={emerald} stopOpacity={0.01} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#e8ece9" strokeDasharray="4 5" /><XAxis dataKey="date" axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 11 }} dy={9} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 11 }} /><Tooltip content={<ChartTooltip />} /><Area type="monotone" dataKey="count" name="Registrations" stroke={emerald} strokeWidth={2.5} fill="url(#regFill)" activeDot={{ r: 5, fill: emerald }} /></AreaChart></ResponsiveContainer></div></Panel>
      <Panel title="Revenue mix" subtitle="Monthly trend · USD" action={<button className="panel-link" onClick={() => onNavigate("revenue")}>Details <ArrowRight size={14} /></button>} className="chart-panel"><div className="chart-legend"><span><i className="legend-dot emerald" />Premium</span><span><i className="legend-dot blue" />Advertising</span></div><div className="chart-wrap"><ResponsiveContainer width="100%" height={226}><ComposedChart data={data.revenueTrend} margin={{ top: 8, right: 4, left: -22, bottom: 0 }}><CartesianGrid vertical={false} stroke="#e8ece9" strokeDasharray="4 5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 11 }} dy={9} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 11 }} /><Tooltip content={<ChartTooltip />} /><Bar dataKey="premium" name="Premium" fill={emerald} radius={[4, 4, 0, 0]} barSize={14} /><Line type="monotone" dataKey="ads" name="Advertising" stroke="#7295c7" strokeWidth={2} dot={false} /></ComposedChart></ResponsiveContainer></div></Panel>
    </div>
    <div className="overview-grid lower-grid">
      <Panel title="Service health" subtitle="Illustrative sample signals · not connected" action={<button className="panel-link" onClick={() => onNavigate("reliability")}>Incident room <ArrowRight size={14} /></button>}><div className="health-list"><div className="health-row"><span className="health-check"><Check size={14} /></span><span><strong>API availability</strong><small>7-day demo window</small></span><b>99.96%</b></div><div className="health-row"><span className="health-check warning"><AlertTriangle size={14} /></span><span><strong>Open crash reports</strong><small>Demo items</small></span><b>2</b></div><div className="health-row"><span className="health-check"><MessageSquareText size={14} /></span><span><strong>Support queue</strong><small>Demo items</small></span><b>3</b></div></div></Panel>
      <Panel title="Platform signals" subtitle="A quick view of the operating footprint"><div className="signal-cards"><div><span className="signal-icon"><Database size={16} /></span><span>Backend use</span><strong>1.84M <small>requests</small></strong></div><div><span className="signal-icon violet"><Cloud size={16} /></span><span>Estimated services</span><strong>$186 <small>this month</small></strong></div><div><span className="signal-icon gold"><DownloadCloud size={16} /></span><span>Storage</span><strong>42.8 <small>GB</small></strong></div></div></Panel>
    </div>
    <div className="privacy-strip"><ShieldCheck size={16} /><span><strong>Private by design.</strong> This console shows aggregated service statistics only—never personal debts, balances, income, zakat details or financial records.</span></div>
  </>;
}

function Growth({ data, loading }: { data?: any; loading: boolean }) {
  const [period, setPeriod] = useState<"registrations" | "total">("registrations");
  if (loading || !data) return <div className="loading-block"><Loader /></div>;
  const chartData = period === "registrations"
    ? data.registrations.map((point: any) => ({ label: point.date, value: point.count }))
    : data.monthlyGrowth.map((point: any) => ({ label: point.month, value: point.users }));
  return <><PageHeading eyebrow="AUDIENCE" title="Users & growth" subtitle="Anonymized registration and activity trends." /><div className="metric-grid three"><Metric label="Total registered" value={fmt(data.users.total)} delta={`${data.users.growthPercent}%`} icon={UsersRound} /><Metric label="Daily active · DAU" value={fmt(data.users.dau)} icon={Activity} tone="blue" detail="rolling 24 hours" /><Metric label="Monthly active · MAU" value={fmt(data.users.mau)} icon={TrendingUp} tone="purple" detail="rolling 30 days" /></div><Panel title={period === "registrations" ? "New registrations" : "Total registered users"} subtitle={period === "registrations" ? "Daily sign-ups · last 7 days" : "Month-end totals · last 7 months"} action={<select className="inline-select" aria-label="Growth chart period" value={period} onChange={event => setPeriod(event.target.value as "registrations" | "total")}><option value="registrations">New · 7 days</option><option value="total">Total · 7 months</option></select>} className="large-chart"><div className="chart-legend"><span><i className="legend-dot emerald" />{period === "registrations" ? "New accounts" : "Registered accounts"}</span></div><ResponsiveContainer width="100%" height={320}><AreaChart data={chartData} margin={{ top: 12, right: 12, left: 0, bottom: 0 }}><defs><linearGradient id="growthFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={emerald} stopOpacity={0.22} /><stop offset="100%" stopColor={emerald} stopOpacity={0.01} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#e8ece9" strokeDasharray="4 5" /><XAxis dataKey="label" axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 12 }} dy={10} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 12 }} /><Tooltip content={<ChartTooltip />} /><Area type="monotone" dataKey="value" name={period === "registrations" ? "New registrations" : "Registered users"} stroke={emerald} strokeWidth={3} fill="url(#growthFill)" /></AreaChart></ResponsiveContainer></Panel><EmptyHint text="Connect an owner-controlled analytics source to replace these demonstration totals with anonymized live aggregates." /></>;
}

function Revenue({ data, loading }: { data?: any; loading: boolean }) {
  const [months, setMonths] = useState<3 | 7>(7);
  if (loading || !data) return <div className="loading-block"><Loader /></div>;
  return <><PageHeading eyebrow="MONETIZATION" title="Revenue overview" subtitle="Premium subscription and advertising performance. Values shown in USD demo data." /><div className="metric-grid three"><Metric label="Premium subscribers" value={fmt(data.premium.subscribers)} delta={`${data.premium.changePercent}%`} icon={ShieldCheck} tone="purple" /><Metric label="Premium revenue · MTD" value={usd(data.premium.monthlyRevenueUsd)} icon={CircleDollarSign} tone="green" detail="monthly subscriptions" /><Metric label="Advertising · MTD" value={usd(data.ads.revenueMtdUsd)} icon={TrendingUp} tone="blue" detail={`${fmt(data.ads.impressionsMtd)} impressions`} /></div><Panel title="Revenue trend" subtitle={`Subscription and ad revenue · last ${months} months`} action={<select className="inline-select" aria-label="Revenue chart period" value={months} onChange={event => setMonths(Number(event.target.value) as 3 | 7)}><option value={3}>Last 3 months</option><option value={7}>Last 7 months</option></select>} className="large-chart"><div className="chart-legend"><span><i className="legend-dot emerald" />Premium</span><span><i className="legend-dot blue" />Advertising</span></div><ResponsiveContainer width="100%" height={320}><ComposedChart data={data.revenueTrend.slice(-months)} margin={{ top: 12, right: 12, left: 0, bottom: 0 }}><CartesianGrid vertical={false} stroke="#e8ece9" strokeDasharray="4 5" /><XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 12 }} dy={10} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 12 }} /><Tooltip content={<ChartTooltip />} /><Bar dataKey="premium" name="Premium" fill={emerald} radius={[5, 5, 0, 0]} barSize={20} /><Bar dataKey="ads" name="Advertising" fill="#91a9cc" radius={[5, 5, 0, 0]} barSize={20} /></ComposedChart></ResponsiveContainer></Panel><div className="privacy-strip"><ShieldCheck size={16} /><span>Revenue totals are aggregated and do not include an individual customer's payment or financial history.</span></div></>;
}

function Reliability({ data, loading }: { data?: any[]; loading: boolean }) {
  const [status, setStatus] = useState("all");
  const filtered = status === "all" ? data : data?.filter(item => item.status === status);
  return <><PageHeading eyebrow="OPERATIONS · STABILITY" title="Reliability & incidents" subtitle="Crash reports are anonymized samples until an owner-controlled crash source is connected." actions={<span className="soft-status"><span />Operational overview</span>} /><div className="metric-grid three"><Metric label="Availability" value="99.96%" icon={Gauge} tone="green" detail="7-day demonstration" /><Metric label="Open incidents" value="2" icon={AlertTriangle} tone="amber" detail="1 high · 1 medium" /><Metric label="Affected sessions" value="25" icon={Activity} tone="blue" detail="sample aggregate" /></div><Panel title="Recent technical reports" subtitle="Anonymized incident summaries · DEMO" action={<select className="inline-select" aria-label="Filter incidents by status" value={status} onChange={event => setStatus(event.target.value)}><option value="all">All statuses</option><option value="investigating">Investigating</option><option value="monitoring">Monitoring</option><option value="resolved">Resolved</option></select>}><div className="table-wrap"><table><thead><tr><th>Incident</th><th>Area</th><th>Impact</th><th>Severity</th><th>Status</th><th>Reported</th></tr></thead><tbody>{loading ? <tr><td colSpan={6}>Loading…</td></tr> : filtered?.length ? filtered.map(item => <tr key={item.id}><td><strong>{item.title}</strong><small className="cell-sub">{item.id}</small></td><td>{item.category}</td><td>{item.affectedSessions} sessions</td><td><span className={`severity ${item.severity}`}>{item.severity}</span></td><td><span className={`status-pill ${item.status}`}>{item.status}</span></td><td>{shortDate(item.createdAt)}</td></tr>) : <tr><td colSpan={6}>No incident summaries match this status.</td></tr>}</tbody></table></div></Panel><EmptyHint text="Incident records contain no user names, email addresses or personal financial content. Connect crash reporting to show live anonymized summaries." /></>;
}

function Support({ data, loading }: { data?: any[]; loading: boolean }) {
  const [category, setCategory] = useState("all");
  const filtered = category === "all" ? data : data?.filter(item => item.category === category);
  return <><PageHeading eyebrow="CUSTOMER VOICE" title="Feedback & support" subtitle="A privacy-filtered queue of anonymized support topics." actions={<span className="soft-status"><MessageSquareText size={14} />4 sample items</span>} /><div className="privacy-callout"><ShieldCheck size={17} /><div><strong>Personal details stay out of this view.</strong><p>Only anonymized topics and screened summaries are shown. Messages containing debts, balances, income, zakat details or other financial records must be redacted before ingestion.</p></div></div><Panel title="Queue overview" subtitle="Sample records · no customer identifiers" action={<select className="inline-select" aria-label="Filter support by topic" value={category} onChange={event => setCategory(event.target.value)}><option value="all">All topics</option><option value="How-to">How-to</option><option value="Localization">Localization</option><option value="Subscription">Subscription</option><option value="Suggestion">Suggestion</option></select>}><div className="support-list">{loading ? <div className="skeleton-row" /> : filtered?.length ? filtered.map(item => <article className="support-row" key={item.id}><span className={`support-avatar ${item.category === "Suggestion" ? "violet" : ""}`}>{item.category === "Suggestion" ? <TrendingUp size={17} /> : <MessageSquareText size={17} />}</span><div className="support-content"><div className="support-title"><strong>{item.topic}</strong><span className={`status-pill ${item.status}`}>{item.status}</span></div><p>{item.excerpt}</p><small>{item.id} <i>·</i> {item.category} <i>·</i> {shortDate(item.receivedAt)}</small></div><ChevronRight className="support-arrow" size={17} /></article>) : <EmptyHint text="No support topics match this category." />}</div></Panel><EmptyHint text="Support examples are static demo content. Connect your own ticketing service with a redaction step before displaying customer messages." /></>;
}

function Usage({ data, loading }: { data?: any; loading: boolean }) {
  if (loading || !data) return <div className="loading-block"><Loader /></div>;
  return <><PageHeading eyebrow="INFRASTRUCTURE" title="Backend & service costs" subtitle="Usage, storage and estimated monthly service spend." actions={<span className="soft-status"><Database size={14} />{data.period} · DEMO</span>} /><div className="metric-grid four"><Metric label="API requests" value="1.84M" icon={Activity} tone="blue" detail="this month" /><Metric label="Storage consumed" value={`${data.storageGb} GB`} icon={DownloadCloud} tone="purple" detail="sample capacity" /><Metric label="Database footprint" value={`${data.databaseGb} GB`} icon={Database} tone="green" detail="estimated" /><Metric label="Estimated service cost" value={usd(data.estimatedCostUsd)} icon={CircleDollarSign} tone="amber" detail="not a provider invoice" /></div><div className="overview-grid"><Panel title="Request volume" subtitle="Daily backend requests · demonstration data" className="chart-panel"><ResponsiveContainer width="100%" height={260}><AreaChart data={data.series} margin={{ top: 12, right: 8, left: -18, bottom: 0 }}><defs><linearGradient id="usageFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#7895c3" stopOpacity={0.18} /><stop offset="100%" stopColor="#7895c3" stopOpacity={0.01} /></linearGradient></defs><CartesianGrid vertical={false} stroke="#e8ece9" strokeDasharray="4 5" /><XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 11 }} dy={8} /><YAxis axisLine={false} tickLine={false} tick={{ fill: "#89918d", fontSize: 11 }} /><Tooltip content={<ChartTooltip />} /><Area type="monotone" dataKey="requests" name="Requests" stroke="#7895c3" strokeWidth={2.5} fill="url(#usageFill)" /></AreaChart></ResponsiveContainer></Panel><Panel title="Cost estimate" subtitle="Illustrative monthly breakdown"><div className="cost-list">{data.costBreakdown.map((item: { service: string; amount: number }, index: number) => <div className="cost-row" key={item.service}><span className={`cost-dot c${index}`} /><span>{item.service}</span><strong>{usd(item.amount)}</strong></div>)}<div className="cost-total"><span>Estimated total</span><strong>{usd(data.estimatedCostUsd)}</strong></div></div><p className="small-note">This is an illustrative estimate, not an invoice or live cloud-provider reading.</p></Panel></div><EmptyHint text="Connect usage, storage and billing exports from accounts owned by you to replace these sample values." /></>;
}

function Features({ data, loading, canEdit, onToggle, pending }: { data?: any[]; loading: boolean; canEdit: boolean; onToggle: (key: string, enabled: boolean) => void; pending: boolean }) {
  return <><PageHeading eyebrow="PRODUCT CONTROLS" title="Feature configuration" subtitle="Manage the saved feature-flag register. Changes are audited." actions={<span className="soft-status"><SlidersHorizontal size={14} />Owner controlled</span>} /><div className="privacy-callout"><ShieldCheck size={17} /><div><strong>Customer-app link not connected.</strong><p>These settings are saved in the admin database. The attached customer application must read the feature-flag feed before a toggle changes behavior for app users.</p></div></div><Panel title="Feature switches" subtitle="Saved admin settings · no individual user data"><div className="feature-list">{loading ? <div className="skeleton-row" /> : data?.map(item => <div className="feature-row" key={item.key}><span className={`feature-glyph ${item.enabled ? "enabled" : ""}`}><SlidersHorizontal size={17} /></span><div className="feature-copy"><strong>{item.label}</strong><p>{item.description}</p><small>{item.updatedAt ? `Updated ${shortDate(item.updatedAt)}${item.updatedBy ? ` by ${item.updatedBy}` : ""}` : "Default setting · saved when changed"}</small></div><button className={`switch ${item.enabled ? "on" : ""}`} disabled={!canEdit || pending} onClick={() => onToggle(item.key, !item.enabled)} role="switch" aria-checked={item.enabled} aria-label={`Toggle ${item.label}`}><span /></button></div>)}</div>{!canEdit && <p className="small-note">Your role can view feature settings but cannot change them.</p>}</Panel></>;
}

function Announcements({ data, loading, canEdit, showForm, setShowForm, title, setTitle, body, setBody, status, setStatus, onSubmit, pending }: any) {
  return <><PageHeading eyebrow="COMMUNICATIONS" title="Announcements" subtitle="Draft and track announcement records; delivery to the customer app is not connected." actions={canEdit && <button className="button primary" onClick={() => setShowForm(!showForm)}><Plus size={16} />New announcement</button>} /><div className="privacy-callout"><Megaphone size={17} /><div><strong>Saved here only.</strong><p>Marking an announcement as published changes its status in this dashboard register; it does not send a message to customer devices.</p></div></div>{showForm && <Panel title="Create announcement" subtitle="Review and save a dashboard announcement record"><div className="form-grid"><Field label="Headline"><input maxLength={160} value={title} onChange={e => setTitle(e.target.value)} placeholder="A concise title" /></Field><Field label="Status"><select value={status} onChange={e => setStatus(e.target.value)}><option value="draft">Save as draft</option><option value="published">Mark as published (register only)</option></select></Field><Field label="Message"><textarea maxLength={3000} rows={4} value={body} onChange={e => setBody(e.target.value)} placeholder="Write a clear, helpful update for app users." /></Field><div className="form-actions"><button className="button secondary" onClick={() => setShowForm(false)}>Cancel</button><button className="button primary" disabled={pending || title.trim().length < 3 || body.trim().length < 5} onClick={onSubmit}>{pending ? "Saving…" : status === "published" ? "Mark published" : "Save draft"} <ArrowRight size={15} /></button></div></div></Panel>}<Panel title="Saved announcements" subtitle="Owner-managed message history">{loading ? <div className="skeleton-row" /> : !data?.length ? <EmptyHint text="No owner announcements have been saved yet." /> : <div className="announcement-list">{data.map((item: any) => <article className="announcement-row" key={item.id}><span className="announcement-icon"><Megaphone size={17} /></span><div><strong>{item.title}</strong><p>{item.body}</p><small>{item.createdBy} <i>·</i> {shortDate(item.createdAt)}</small></div><span className={`status-pill ${item.status}`}>{item.status}</span></article>)}</div>}</Panel></>;
}

function Releases({ data, mode, loading, canEdit, showForm, setShowForm, version, setVersion, platform, setPlatform, status, setStatus, notes, setNotes, onSubmit, pending }: any) {
  return <><PageHeading eyebrow="RELEASE MANAGEMENT" title="App releases" subtitle="Track version metadata and release state. This does not publish to app stores." actions={canEdit && <button className="button primary" onClick={() => setShowForm(!showForm)}><Plus size={16} />Add release</button>} /><div className="privacy-callout"><Rocket size={17} /><div><strong>Release notes are management records only.</strong><p>Google Play, Apple publishing and signing accounts remain under your ownership and are not connected here.</p></div></div>{showForm && <Panel title="Record release" subtitle="Add a version record to the admin dashboard"><div className="form-grid two-col"><Field label="Version"><input value={version} onChange={e => setVersion(e.target.value)} placeholder="e.g. 2.7.0" /></Field><Field label="Platform"><select value={platform} onChange={e => setPlatform(e.target.value)}><option value="android">Android</option><option value="ios">iOS</option><option value="backend">Backend</option></select></Field><Field label="Status"><select value={status} onChange={e => setStatus(e.target.value)}><option value="planned">Planned</option><option value="review">In review</option><option value="live">Live</option><option value="paused">Paused</option></select></Field><Field label="Release notes"><textarea rows={3} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Short release summary" /></Field><div className="form-actions"><button className="button secondary" onClick={() => setShowForm(false)}>Cancel</button><button className="button primary" disabled={pending || version.trim().length < 1 || notes.trim().length < 3} onClick={onSubmit}>{pending ? "Saving…" : "Save version"}</button></div></div></Panel>}<Panel title="Version history" subtitle={mode ?? "Release registry"}><div className="release-list">{loading ? <div className="skeleton-row" /> : data?.map((item: any) => <article className="release-row" key={item.id}><span className="release-platform">{item.platform === "android" ? <Smartphone size={18} /> : item.platform === "ios" ? <Smartphone size={18} /> : <Database size={18} />}</span><div className="release-version"><strong>{item.version}</strong><small>{item.platform} <i>·</i> {item.releaseDate ? shortDate(item.releaseDate) : "Date not set"}</small></div><p>{item.notes}</p><span className={`status-pill ${item.status}`}>{item.status}</span><span className={`source-pill ${item.source === "DEMO" ? "demo" : ""}`}>{item.source}</span></article>)}</div></Panel></>;
}

function Team({ members, invites, role, inviteEmail, setInviteEmail, inviteRole, setInviteRole, onInvite, pending, inviteResult, onCopy, onRoleChange }: any) {
  const isOwner = role === "owner";
  const canManageTeam = role === "owner" || role === "admin";
  const utils = trpc.useUtils();
  const [resetResult, setResetResult] = useState<any>(null);
  const resetMutation = trpc.team.resetAccess.useMutation({ onSuccess: async result => { setResetResult(result); await utils.team.list.invalidate(); await utils.team.invitations.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const activeMutation = trpc.team.setActive.useMutation({ onSuccess: async () => { toast.success("Account access updated."); await utils.team.list.invalidate(); await utils.audit.list.invalidate(); }, onError: error => toast.error(error.message) });
  const passwordMutation = trpc.team.changeMyPassword.useMutation({ onSuccess: () => window.location.replace("/"), onError: error => toast.error(error.message) });
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const copyResetLink = async () => { if (!resetResult) return; await navigator.clipboard.writeText(`${window.location.origin}${resetResult.link}`); toast.success("One-time access reset link copied. Share it privately with this administrator."); };
  return <><PageHeading eyebrow={canManageTeam ? "ACCESS CONTROL" : "ACCOUNT SECURITY"} title={canManageTeam ? "Admin team" : "My account"} subtitle={canManageTeam ? "Manage administrator roles, account status and recovery. Every change is audited." : "Change your own password. This ends all active sessions."} />{canManageTeam && <div className="role-summary"><div><ShieldCheck size={18} /><strong>Owner</strong><span>Full access, role management</span></div><div><Activity size={18} /><strong>Analyst</strong><span>Aggregate metrics and audit view</span></div><div><MessageSquareText size={18} /><strong>Support</strong><span>Anonymized feedback queue</span></div></div>}
    {isOwner && <Panel title="Invite an administrator" subtitle="The private invitation link expires in 7 days; share it only with the intended person."><div className="invite-form"><Field label="Admin email"><input type="email" value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} placeholder="name@example.com" /></Field><Field label="Role"><select value={inviteRole} onChange={e => setInviteRole(e.target.value)}><option value="analyst">Analyst · read-only metrics</option><option value="support">Support · filtered queue</option><option value="admin">Administrator · manage operations</option></select></Field><button className="button primary" disabled={pending || !inviteEmail.includes("@")} onClick={onInvite}>{pending ? "Creating…" : "Create invitation"} <ArrowRight size={15} /></button></div>{inviteResult && <div className="invite-result"><div><strong>Invitation created for {inviteResult.email}</strong><span>{roleName(inviteResult.role as Role)} · one-time link</span></div><button className="button secondary" onClick={onCopy}><Copy size={15} />Copy private link</button></div>}</Panel>}
    {resetResult && <Panel title="Access reset link created" subtitle="The account is suspended until its owner completes password and authenticator re-enrollment."><div className="invite-result"><div><strong>{resetResult.email}</strong><span>Expires {shortDate(resetResult.expiresAt)} · single use</span></div><button className="button secondary" onClick={copyResetLink}><Copy size={15} />Copy private reset link</button></div></Panel>}
    {canManageTeam && <Panel title="Administrators" subtitle="Suspend access to revoke all active sessions, or issue a one-time password/MFA reset link."><div className="table-wrap"><table><thead><tr><th>Person</th><th>Role</th><th>Access</th><th>Added</th><th>Last sign-in</th>{isOwner && <th>Manage</th>}</tr></thead><tbody>{members?.map((person: any) => <tr key={person.id}><td><div className="person-cell"><span className="avatar small">{initials(person.displayName)}</span><span><strong>{person.displayName}</strong><small className="cell-sub">{person.email}{person.current ? " · You" : ""}</small></span></div></td><td><span className={`role-chip ${person.role}`}>{roleName(person.role)}</span></td><td><span className={`status-pill ${person.isActive ? "live" : "paused"}`}>{person.isActive ? "Active" : "Suspended"}</span></td><td>{shortDate(person.createdAt)}</td><td>{person.lastLoginAt ? shortDate(person.lastLoginAt) : "Not yet"}</td>{isOwner && <td>{person.role !== "owner" && !person.current ? <div className="team-actions"><select className="inline-select" value={person.role} onChange={e => onRoleChange(person.id, e.target.value)}><option value="admin">Administrator</option><option value="analyst">Analyst</option><option value="support">Support</option></select><button className="button secondary" disabled={activeMutation.isPending} onClick={() => { if (window.confirm(`${person.isActive ? "Suspend" : "Restore"} ${person.email}? ${person.isActive ? "All of their active sessions will be revoked." : "They will be able to sign in again."}`)) activeMutation.mutate({ adminId: person.id, active: !person.isActive }); }}>{person.isActive ? "Suspend access" : "Restore access"}</button><button className="button secondary" disabled={resetMutation.isPending} onClick={() => { if (window.confirm(`Suspend ${person.email} and create a one-time password and authenticator reset link?`)) resetMutation.mutate({ adminId: person.id }); }}>Reset access</button></div> : <span className="small-note">Protected</span>}</td>}</tr>)}</tbody></table></div></Panel>}
    <Panel title="Change my password" subtitle="Enter your current password and choose a unique password with at least 12 characters. All active sessions will be revoked."><form className="form-grid two-col" onSubmit={event => { event.preventDefault(); passwordMutation.mutate({ currentPassword, newPassword }); }}><Field label="Current password"><input required type="password" autoComplete="current-password" value={currentPassword} onChange={event => setCurrentPassword(event.target.value)} /></Field><Field label="New password"><input required type="password" minLength={12} maxLength={128} autoComplete="new-password" value={newPassword} onChange={event => setNewPassword(event.target.value)} /></Field><div className="form-actions"><button className="button primary" disabled={passwordMutation.isPending || newPassword.length < 12}>{passwordMutation.isPending ? "Updating…" : "Change password"}</button></div></form></Panel>
    {canManageTeam && <Panel title="Pending invitations" subtitle="Invitation and access-reset links expire after 7 days and may only be used once.">{invites?.length ? invites.map((item: any) => <div className="pending-invite" key={`${item.email}-${item.createdAt}`}><span><strong>{item.email}</strong><small>{item.resetAdminId ? "Access reset" : roleName(item.role)} <i>·</i> expires {shortDate(item.expiresAt)}</small></span><span className="status-pill draft">awaiting enrollment</span></div>) : <EmptyHint text="No invitations are pending." />}</Panel>}
  </>;
}

function Audit({ data, loading }: { data?: any[]; loading: boolean }) {
  return <><PageHeading eyebrow="GOVERNANCE" title="Audit history" subtitle="A chronological record of administrative actions. Records are append-only in the dashboard." actions={<span className="soft-status"><ScrollText size={14} />{data?.length ?? 0} recent events</span>} /><div className="privacy-callout"><ShieldCheck size={17} /><div><strong>Accountability without customer financial data.</strong><p>Audit summaries record the administrator, action, affected setting and time. They do not include end-user financial records.</p></div></div><Panel title="Recent administrative activity" subtitle="Newest actions first"><div className="audit-list">{loading ? <div className="skeleton-row" /> : data?.map((item: any) => <div className="audit-row" key={item.id}><span className="audit-icon"><CheckCircle2 size={15} /></span><div className="audit-main"><strong>{item.summary}</strong><small>{item.actorEmail} <i>·</i> {item.resourceType}</small></div><span className="audit-action">{item.action}</span><time>{shortDate(item.createdAt)}</time></div>)}</div></Panel></>;
}

export default function Home() {
  const auth = trpc.auth.me.useQuery(undefined, { retry: false, staleTime: 0 });
  const setup = trpc.auth.bootstrapStatus.useQuery(undefined, { retry: false, enabled: !auth.data });
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => window.location.replace("/") });
  const query = new URLSearchParams(window.location.search);
  const inviteToken = query.get("invite");
  const isSetup = query.get("setup") === "owner";
  if (auth.isLoading || setup.isLoading) return <div className="auth-shell"><div className="auth-card"><div className="auth-brand"><span className="brand-mark">T</span><span>TO‘LOVCHI <small>OWNER CONSOLE</small></span></div><Loader /></div></div>;
  if (auth.data) return <Dashboard admin={auth.data as { id: number; email: string; displayName: string; role: Role }} onLogout={() => logout.mutate()} />;
  if (inviteToken) return <Enrollment key={inviteToken} mode="invite" inviteToken={inviteToken} onComplete={() => window.location.replace("/")} />;
  if (isSetup || (!setup.data?.initialized && setup.data?.setupAvailable)) return <Enrollment key="owner-setup" mode="owner" onComplete={() => window.location.replace("/")} />;
  return <Login setupAvailable={!!setup.data?.setupAvailable} onSignedIn={() => auth.refetch()} />;
}
