import React, { useEffect, useState } from "react";
import { api } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState } from "../components/States";

interface Order {
  id: string;
  customer_name: string | null;
  total_cents: number;
  status: string;
  created_at: string;
}

const STATUS_COLORS: Record<string, string> = {
  pending: "bg-amber-50 text-amber-800 border-amber-200",
  confirmed: "bg-blue-50 text-blue-700 border-blue-200",
  processing: "bg-indigo-50 text-accent border-indigo-200",
  shipped: "bg-purple-50 text-purple-700 border-purple-200",
  delivered: "bg-green-50 text-green-700 border-green-200",
  cancelled: "bg-red-50 text-red-700 border-red-200",
};

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setOrders((await api.getOrders()) as Order[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load orders.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-bold">Orders</h1>
      {loading && <LoadingSpinner label="Loading orders…" />}
      {error && <ErrorMessage message={error} onRetry={load} />}
      {!loading && !error && orders.length === 0 && (
        <EmptyState
          title="No orders yet"
          description="Orders placed through your storefront will appear here — checkout isn't connected yet, so there's nothing to fabricate in the meantime."
        />
      )}
      {!loading && !error && orders.length > 0 && (
        <div className="glass-card divide-y divide-black/5">
          {orders.map((o) => (
            <div key={o.id} className="flex items-center justify-between p-4">
              <div>
                <p className="font-medium text-sm">#{o.id.slice(0, 8)} — {o.customer_name ?? "Guest"}</p>
                <p className="text-xs text-muted">{new Date(o.created_at).toLocaleDateString()} · ${(o.total_cents / 100).toFixed(2)}</p>
              </div>
              <span className={`badge-demo capitalize ${STATUS_COLORS[o.status] ?? ""}`}>{o.status}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
