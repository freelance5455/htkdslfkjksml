import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, ApiError } from "../services/api";
import { LoadingSpinner, ErrorMessage } from "../components/States";

const SELL_OPTIONS = ["Fashion", "Electronics", "Beauty", "Home", "Fitness", "Accessories", "Other"];
const STYLE_OPTIONS = ["Minimal", "Premium", "Bold", "Elegant", "Modern"];

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [sells, setSells] = useState("");
  const [customers, setCustomers] = useState("");
  const [style, setStyle] = useState("");
  const [building, setBuilding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function buildStore() {
    setStep(4);
    setBuilding(true);
    setError(null);
    try {
      const prompt = `I want to sell ${sells || "general products"}. My customers are: ${
        customers || "not specified yet"
      }. Preferred store style: ${style || "Modern"}.`;
      const result = (await api.aiStoreBuilder(prompt)) as { storeNames: string[]; tagline: string };
      if (result?.storeNames?.[0]) {
        await api.updateStore({ tagline: result.tagline });
      }
      navigate("/app/dashboard");
    } catch (err) {
      setError(
        err instanceof ApiError
          ? err.message
          : "Couldn't reach the AI Store Builder. Please try again."
      );
    } finally {
      setBuilding(false);
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
      <div className="glass-card w-full max-w-lg p-8 fade-in">
        <div className="flex gap-1.5 mb-8">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className={`h-1 flex-1 rounded-full ${i <= step ? "bg-accent" : "bg-black/10"}`} />
          ))}
        </div>

        {step === 1 && (
          <div>
            <h2 className="text-xl font-bold mb-1">What do you want to sell?</h2>
            <p className="text-sm text-muted mb-5">You can change this later.</p>
            <div className="grid grid-cols-3 gap-2">
              {SELL_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => setSells(opt)}
                  className={`rounded-xl border px-3 py-3 text-sm font-medium transition-colors ${
                    sells === opt ? "border-accent bg-indigo-50 text-accent" : "border-black/10 bg-white/60 text-ink hover:bg-white"
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
            <div className="flex justify-end mt-6">
              <button className="btn-primary disabled:opacity-50" disabled={!sells} onClick={() => setStep(2)}>
                Continue
              </button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div>
            <h2 className="text-xl font-bold mb-1">Who are your customers?</h2>
            <p className="text-sm text-muted mb-5">A short description helps AI write copy that fits.</p>
            <input
              className="input-field"
              placeholder="e.g. young professionals who care about sustainability"
              value={customers}
              onChange={(e) => setCustomers(e.target.value)}
            />
            <div className="flex justify-between mt-6">
              <button className="btn-secondary" onClick={() => setStep(1)}>Back</button>
              <button className="btn-primary" onClick={() => setStep(3)}>Continue</button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            <h2 className="text-xl font-bold mb-1">What style should your store have?</h2>
            <div className="grid grid-cols-3 gap-2 mt-5">
              {STYLE_OPTIONS.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => setStyle(opt)}
                  className={`rounded-xl border px-3 py-3 text-sm font-medium transition-colors ${
                    style === opt ? "border-accent bg-indigo-50 text-accent" : "border-black/10 bg-white/60 text-ink hover:bg-white"
                  }`}
                >
                  {opt}
                </button>
              ))}
            </div>
            <div className="flex justify-between mt-6">
              <button className="btn-secondary" onClick={() => setStep(2)}>Back</button>
              <button className="btn-primary disabled:opacity-50" disabled={!style} onClick={buildStore}>
                Let AI build your store
              </button>
            </div>
          </div>
        )}

        {step === 4 && (
          <div className="text-center py-6">
            {building && <LoadingSpinner label="AI is drafting your store…" />}
            {error && (
              <div className="space-y-4">
                <ErrorMessage message={error} onRetry={buildStore} />
                <button className="btn-secondary" onClick={() => navigate("/app/dashboard")}>
                  Skip for now
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
