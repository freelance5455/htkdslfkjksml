import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState } from "../components/States";

interface StoreData {
  store: { name: string; tagline: string | null; description: string | null; currency: string };
  products: { id: string; name: string; short_description: string | null; price_cents: number }[];
}

export default function PublicStore() {
  const { slug } = useParams<{ slug: string }>();
  const [data, setData] = useState<StoreData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [cart, setCart] = useState<Record<string, number>>({});

  async function load() {
    if (!slug) return;
    setLoading(true);
    setError(null);
    try {
      setData((await api.getPublicStore(slug)) as StoreData);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Store not found.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  if (loading) return <div className="max-w-4xl mx-auto px-4 py-16"><LoadingSpinner label="Loading store…" /></div>;
  if (error || !data) return <div className="max-w-4xl mx-auto px-4 py-16"><ErrorMessage message={error ?? "Store not found."} onRetry={load} /></div>;

  const subtotalCents = Object.entries(cart).reduce((sum, [id, qty]) => {
    const p = data.products.find((x) => x.id === id);
    return sum + (p ? p.price_cents * qty : 0);
  }, 0);

  return (
    <div>
      <header className="border-b border-black/5 bg-white/60 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <span className="font-bold">{data.store.name}</span>
          <span className="text-sm text-muted">{Object.values(cart).reduce((a, b) => a + b, 0)} in cart</span>
        </div>
      </header>

      <section className="text-center py-16 px-4">
        <h1 className="text-3xl sm:text-4xl font-bold">{data.store.name}</h1>
        {data.store.tagline && <p className="text-muted mt-2">{data.store.tagline}</p>}
      </section>

      <section className="max-w-5xl mx-auto px-4 pb-16">
        {data.products.length === 0 ? (
          <EmptyState title="No products yet" description="This store hasn't published any products yet — check back soon." />
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {data.products.map((p) => (
              <div key={p.id} className="glass-card p-4">
                <div className="h-32 rounded-xl bg-black/5 mb-3" />
                <p className="font-medium text-sm">{p.name}</p>
                {p.short_description && <p className="text-xs text-muted mt-1 line-clamp-2">{p.short_description}</p>}
                <div className="flex items-center justify-between mt-3">
                  <span className="font-semibold text-sm">
                    {data.store.currency} {(p.price_cents / 100).toFixed(2)}
                  </span>
                  <button
                    className="btn-secondary text-xs"
                    onClick={() => setCart((c) => ({ ...c, [p.id]: (c[p.id] ?? 0) + 1 }))}
                  >
                    Add to cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {Object.keys(cart).length > 0 && (
          <div className="glass-card p-6 mt-8 max-w-md ml-auto">
            <h3 className="font-semibold mb-3">Your cart</h3>
            <div className="space-y-2 text-sm mb-4">
              {Object.entries(cart).map(([id, qty]) => {
                const p = data.products.find((x) => x.id === id);
                if (!p) return null;
                return (
                  <div key={id} className="flex justify-between">
                    <span>{p.name} × {qty}</span>
                    <span>{data.store.currency} {((p.price_cents * qty) / 100).toFixed(2)}</span>
                  </div>
                );
              })}
            </div>
            <div className="flex justify-between font-semibold border-t border-black/5 pt-3 mb-4">
              <span>Total</span>
              <span>{data.store.currency} {(subtotalCents / 100).toFixed(2)}</span>
            </div>
            <button disabled className="btn-primary w-full opacity-60 cursor-not-allowed">
              Checkout integration coming soon
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
