import React, { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState, Toast } from "../components/States";

interface SupplierProduct {
  id: string;
  name: string;
  category: string;
  imageUrl: string;
  supplierCostCents: number;
  suggestedPriceCents: number;
}

const CATEGORIES = ["trending", "electronics", "fashion", "beauty", "home", "fitness", "accessories"];

export default function ProductFinder() {
  const [category, setCategory] = useState("trending");
  const [query, setQuery] = useState("");
  const [products, setProducts] = useState<SupplierProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [importingId, setImportingId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setProducts((await api.getSupplierProducts(query, category)) as SupplierProduct[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load the product catalog.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  async function handleImport(p: SupplierProduct) {
    setImportingId(p.id);
    try {
      await api.importSupplierProduct(p.id);
      setToast(`"${p.name}" added to your Products as a draft.`);
    } catch (err) {
      setToast(err instanceof ApiError ? err.message : "Couldn't import product.");
    } finally {
      setImportingId(null);
    }
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">Product Finder</h1>
        <p className="text-sm text-muted mt-1">
          Real product data pulled live from a public catalog — estimated cost and margin are approximations, not a live supplier quote.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`rounded-full px-4 py-1.5 text-sm font-medium capitalize transition-colors ${
              category === c ? "bg-accent text-white" : "bg-white/60 border border-black/10 text-muted hover:bg-white"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          load();
        }}
        className="flex gap-2 max-w-md"
      >
        <input className="input-field" placeholder="Search products…" value={query} onChange={(e) => setQuery(e.target.value)} />
        <button className="btn-secondary shrink-0">Search</button>
      </form>

      {loading && <LoadingSpinner label="Searching the catalog…" />}
      {error && <ErrorMessage message={error} onRetry={load} />}
      {!loading && !error && products.length === 0 && (
        <EmptyState title="No products found" description="Try a different search term or category." />
      )}

      {!loading && !error && products.length > 0 && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((p) => {
            const margin = p.suggestedPriceCents - p.supplierCostCents;
            const marginPct = p.suggestedPriceCents > 0 ? Math.round((margin / p.suggestedPriceCents) * 100) : 0;
            return (
              <div key={p.id} className="glass-card p-4">
                <img src={p.imageUrl} alt={p.name} className="w-full h-32 object-cover rounded-xl mb-3 bg-black/5" loading="lazy" />
                <p className="font-medium text-sm line-clamp-2">{p.name}</p>
                <p className="text-xs text-muted capitalize mt-1">{p.category}</p>
                <div className="flex items-center justify-between mt-3 text-sm">
                  <span className="text-muted">Est. cost ${(p.supplierCostCents / 100).toFixed(2)}</span>
                  <span className="font-semibold">${(p.suggestedPriceCents / 100).toFixed(2)}</span>
                </div>
                <p className="text-xs text-green-700 mt-1">~{marginPct}% est. margin</p>
                <button
                  className="btn-secondary w-full mt-3 text-sm disabled:opacity-60"
                  disabled={importingId === p.id}
                  onClick={() => handleImport(p)}
                >
                  {importingId === p.id ? "Adding…" : "Add to store"}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
    </div>
  );
}
