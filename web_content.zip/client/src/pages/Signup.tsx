import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { ApiError } from "../services/api";

export default function Signup() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: "", email: "", password: "", storeName: "" });
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  function update(field: keyof typeof form) {
    return (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (form.password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }
    setSubmitting(true);
    try {
      await register(form);
      navigate("/onboarding");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-16">
      <div className="glass-card w-full max-w-md p-8 fade-in">
        <h1 className="text-2xl font-bold">Create your store</h1>
        <p className="text-sm text-muted mt-1 mb-6">Free to start — no card required.</p>
        {error && (
          <div role="alert" className="mb-4 rounded-xl bg-red-50 border border-red-100 text-red-700 text-sm px-4 py-3">
            {error}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium mb-1.5">Name</label>
            <input id="name" required className="input-field" value={form.name} onChange={update("name")} />
          </div>
          <div>
            <label htmlFor="storeName" className="block text-sm font-medium mb-1.5">Store name</label>
            <input
              id="storeName"
              required
              placeholder="e.g. Northline Goods"
              className="input-field"
              value={form.storeName}
              onChange={update("storeName")}
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium mb-1.5">Email</label>
            <input id="email" type="email" required autoComplete="email" className="input-field" value={form.email} onChange={update("email")} />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium mb-1.5">Password</label>
            <input
              id="password"
              type="password"
              required
              minLength={8}
              autoComplete="new-password"
              className="input-field"
              value={form.password}
              onChange={update("password")}
            />
            <p className="text-xs text-muted mt-1">At least 8 characters.</p>
          </div>
          <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-60">
            {submitting ? "Creating your account…" : "Create account"}
          </button>
        </form>
        <p className="text-sm text-muted text-center mt-6">
          Already have an account?{" "}
          <Link to="/login" className="text-accent font-medium">Log in</Link>
        </p>
      </div>
    </div>
  );
}
