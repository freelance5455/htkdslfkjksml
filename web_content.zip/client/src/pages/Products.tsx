import React, { useEffect, useState } from "react";
import { api, ApiError } from "../services/api";
import { LoadingSpinner, ErrorMessage, EmptyState, Modal, ConfirmDialog, Toast } from "../components/States";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price_cents: number;
  inventory: number;
  status: "draft" | "active" | "archived";
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [toDelete, setToDelete] = useState<Product | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      setProducts((await api.getProducts()) as Product[]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Couldn't load products.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleDelete() {
    if (!toDelete) return;
    try {
      await api.deleteProduct(toDelete.id);
      setProducts((p) => p.filter((x) => x.id !== toDelete.id));
      setToast("Product deleted.");
    } catch (err) {
      setToast(err instanceof ApiError ? err.message : "Couldn't delete product.");
    } finally {
      setToDelete(null);
    }
  }

  const filtered = products.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold">Products</h1>
        <button className="btn-primary" onClick={() => setShowAdd(true)}>+ Add product</button>
      </div>

      <input
        className="input-field max-w-sm"
        placeholder="Search products…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {loading && <LoadingSpinner label="Loading products…" />}
      {error && <ErrorMessage message={error} onRetry={load} />}

      {!loading && !error && filtered.length === 0 && (
        <EmptyState
          title={products.length === 0 ? "No products yet" : "No matching products"}
          description={
            products.length === 0
              ? "Add your first product, or import one from Product Finder."
              : "Try a different search term."
          }
          action={
            products.length === 0 && (
              <button className="btn-primary" onClick={() => setShowAdd(true)}>Add product</button>
            )
          }
        />
      )}

      {!loading && !error && filtered.length > 0 && (
        <div className="glass-card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-muted border-b border-black/5">
                <th className="px-5 py-3 font-medium">Name</th>
                <th className="px-5 py-3 font-medium">Price</th>
                <th className="px-5 py-3 font-medium">Inventory</th>
                <th className="px-5 py-3 font-medium">Status</th>
                <th className="px-5 py-3 font-medium sr-only">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} className="border-b border-black/5 last:border-0">
                  <td className="px-5 py-3 font-medium">{p.name}</td>
                  <td className="px-5 py-3">${(p.price_cents / 100).toFixed(2)}</td>
                  <td className="px-5 py-3">{p.inventory > 0 ? `${p.inventory} in stock` : "Out of stock"}</td>
                  <td className="px-5 py-3">
                    <span className={`badge-demo ${p.status === "active" ? "bg-green-50 text-green-700 border-green-200" : ""}`}>
                      {p.status}
                    </span>
                  </td>
                  <td className="px-5 py-3 text-right">
                    <button className="text-red-600 hover:underline" onClick={() => setToDelete(p)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <AddProductModal
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onCreated={(p) => {
          setProducts((prev) => [p, ...prev]);
          setShowAdd(false);
          setToast("Product added.");
        }}
      />

      <ConfirmDialog
        open={!!toDelete}
        title="Delete product?"
        message={`"${toDelete?.name}" will be permanently removed.`}
        onConfirm={handleDelete}
        onCancel={() => setToDelete(null)}
      />

      {toast && <Toast message={toast} onClose={() => setToast(null)} />}
    </div>
  );
}

function AddProductModal({
  open,
  onClose,
  onCreated,
}: {
  open: boolean;
  onClose: () => void;
  onCreated: (p: Product) => void;
}) {
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [inventory, setInventory] = useState("0");
  const [status, setStatus] = useState<"draft" | "active">("draft");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const priceCents = Math.round(parseFloat(price || "0") * 100);
    if (!name.trim() || Number.isNaN(priceCents)) {
      setError("Please enter a name and a valid price.");
      return;
    }
    setSubmitting(true);
    try {
      const product = (await api.createProduct({
        name,
        priceCents,
        inventory: parseInt(inventory || "0", 10),
        status,
      })) as Product;
      onCreated(product);
      setName("");
      setPrice("");
      setInventory("0");
      setStatus("draft");
    } catch (err) {
      setError(err instanceof ApiError ? err.message : "Couldn't create product.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title="Add product">
      {error && <div className="mb-3 text-sm text-red-600">{error}</div>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1.5">Product name</label>
          <input className="input-field" required value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium mb-1.5">Price (USD)</label>
            <input className="input-field" type="number" min="0" step="0.01" required value={price} onChange={(e) => setPrice(e.target.value)} />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1.5">Inventory</label>
            <input className="input-field" type="number" min="0" value={inventory} onChange={(e) => setInventory(e.target.value)} />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium mb-1.5">Status</label>
          <select className="input-field" value={status} onChange={(e) => setStatus(e.target.value as "draft" | "active")}>
            <option value="draft">Draft</option>
            <option value="active">Active</option>
          </select>
        </div>
        <button type="submit" disabled={submitting} className="btn-primary w-full disabled:opacity-60">
          {submitting ? "Saving…" : "Save product"}
        </button>
      </form>
    </Modal>
  );
}
