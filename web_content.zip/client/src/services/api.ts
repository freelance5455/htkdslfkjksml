// Thin fetch wrapper. Talks only to our own backend — never to OpenAI or
// suppliers directly, and no API keys ever live in this file or bundle.
const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

export class ApiError extends Error {}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_URL}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || body.success === false) {
    throw new ApiError(body.error || "Request failed. Please try again.");
  }
  return body.data as T;
}

export const api = {
  register: (data: { name: string; email: string; password: string; storeName: string }) =>
    request("/api/auth/register", { method: "POST", body: JSON.stringify(data) }),
  login: (data: { email: string; password: string }) =>
    request("/api/auth/login", { method: "POST", body: JSON.stringify(data) }),
  logout: () => request("/api/auth/logout", { method: "POST" }),
  me: () => request("/api/auth/me"),

  getPublicStore: (slug: string) => request(`/api/public/stores/${encodeURIComponent(slug)}`),

  getStore: () => request("/api/store"),
  updateStore: (data: Record<string, unknown>) =>
    request("/api/store", { method: "PUT", body: JSON.stringify(data) }),

  getProducts: () => request("/api/products"),
  createProduct: (data: Record<string, unknown>) =>
    request("/api/products", { method: "POST", body: JSON.stringify(data) }),
  updateProduct: (id: string, data: Record<string, unknown>) =>
    request(`/api/products/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  deleteProduct: (id: string) => request(`/api/products/${id}`, { method: "DELETE" }),

  getOrders: () => request("/api/orders"),
  getCustomers: () => request("/api/customers"),
  getAnalytics: () => request("/api/analytics"),

  getSupplierProducts: (q = "", category?: string) =>
    request(`/api/supplier/products?q=${encodeURIComponent(q)}${category ? `&category=${category}` : ""}`),
  importSupplierProduct: (supplierProductId: string) =>
    request("/api/supplier/import", { method: "POST", body: JSON.stringify({ supplierProductId }) }),

  aiStoreBuilder: (prompt: string) =>
    request("/api/ai/store-builder", { method: "POST", body: JSON.stringify({ prompt }) }),
  aiProductGenerator: (imageDescription: string) =>
    request("/api/ai/product-generator", { method: "POST", body: JSON.stringify({ imageDescription }) }),
  aiBusinessAssistant: (question: string) =>
    request("/api/ai/business-assistant", { method: "POST", body: JSON.stringify({ question }) }),
};
