import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { api } from "../services/api";

interface User {
  id: string;
  name: string;
  email: string;
}
interface Store {
  id: string;
  name: string;
  slug: string;
}

interface AuthState {
  user: User | null;
  store: Store | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: { name: string; email: string; password: string; storeName: string }) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [store, setStore] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    try {
      const data = await api.me() as { user: User; store: Store | null };
      setUser(data.user);
      setStore(data.store);
    } catch {
      setUser(null);
      setStore(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const login = useCallback(async (email: string, password: string) => {
    await api.login({ email, password });
    await refresh();
  }, [refresh]);

  const register = useCallback(
    async (data: { name: string; email: string; password: string; storeName: string }) => {
      await api.register(data);
      await refresh();
    },
    [refresh]
  );

  const logout = useCallback(async () => {
    await api.logout();
    setUser(null);
    setStore(null);
  }, []);

  return (
    <AuthContext.Provider value={{ user, store, loading, login, register, logout, refresh }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
