Realm of the Castle — Android APK project

اہم:
- یہ Android Studio project ہے، تیار APK نہیں۔
- HTML گیم app/src/main/assets/index.html میں شامل ہے۔
- Three.js اور کچھ icons انٹرنیٹ سے لوڈ ہوتے ہیں، اس لیے گیم چلانے کے لیے انٹرنیٹ ضروری ہے۔

APK بنانے کا طریقہ:
1. کمپیوٹر پر Android Studio انسٹال کریں۔
2. اس ZIP کو extract کریں اور Android Studio میں RealmCastleAndroid فولڈر کھولیں۔
3. Gradle sync مکمل ہونے دیں۔
4. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
5. APK عموماً app/build/outputs/apk/debug/app-debug.apk میں ملے گا۔

نوٹ: یہ پروجیکٹ Android SDK/Gradle کے ساتھ build ہونا چاہیے۔ اس ماحول میں Android build tools دستیاب نہ ہونے کی وجہ سے APK یہاں براہ راست compile نہیں کیا گیا۔
