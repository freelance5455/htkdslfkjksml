
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCS9aomCdqMLikF0iEipNzb3_nQEdvjGog",
  authDomain: "ahmad-ai-4b1ab.firebaseapp.com",
  projectId: "ahmad-ai-4b1ab",
  storageBucket: "ahmad-ai-4b1ab.firebasestorage.app",
  messagingSenderId: "601592443242",
  appId: "1:601592443242:web:9c36e084af189c1478b513",
  measurementId: "G-SE701JFZC7"
};

export const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
