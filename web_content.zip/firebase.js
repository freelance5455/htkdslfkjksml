
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";

import {
  getAuth,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

import {
  getDatabase,
  ref,
  onValue,
  update,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-database.js";

// Firebase project configuration
const firebaseConfig = {
  apiKey: "AIzaSyApVfjMqbJmDITYPkC1abDnNbkxEF4Z6SI",
  authDomain: "test-steerguard.firebaseapp.com",
  databaseURL: "https://test-steerguard-default-rtdb.firebaseio.com",
  projectId: "test-steerguard",
  storageBucket: "test-steerguard.firebasestorage.app",
  messagingSenderId: "634141414672",
  appId: "1:634141414672:web:56f1f1986b336e63850195",
  measurementId: "G-242294BQ5V"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Authentication
export const auth = getAuth(app);

// Realtime Database
export const db = getDatabase(app);

// Export database functions
export const dbRef = ref;
export const dbOnValue = onValue;
export const dbUpdate = update;
export const dbServerTimestamp = serverTimestamp;

// Keep login active
export async function keepSignedIn() {
  await setPersistence(auth, browserLocalPersistence);
}

// Login
export async function login(email, password) {
  await keepSignedIn();

  const result = await signInWithEmailAndPassword(
    auth,
    email,
    password
  );

  return result.user;
}

// Password reset
export async function resetPassword(email) {
  return sendPasswordResetEmail(auth, email);
}

// Logout
export async function logout() {
  return signOut(auth);
}

// Authentication state
export function watchAuth(callback) {
  return onAuthStateChanged(auth, callback);
}
