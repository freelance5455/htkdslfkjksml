// WISAL – Firebase setup. Config comes from the in-app setup box (saved on the device)
// or from the values below. These keys are NOT secret: security comes from the rules files.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { getStorage } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-storage.js";

let saved = null;
try { saved = JSON.parse(localStorage.getItem("wisal_fbcfg") || "null"); } catch (_) {}

export const firebaseConfig = saved || {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

export const isConfigured = !String(firebaseConfig.apiKey).startsWith("PASTE");

let _auth = null, _db = null, _storage = null;
if (isConfigured) {
  const app = initializeApp(firebaseConfig);
  _auth = getAuth(app); _db = getFirestore(app); _storage = getStorage(app);
}
export const auth = _auth, db = _db, storage = _storage;

export * from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
export * from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
