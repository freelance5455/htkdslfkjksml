/* ZYROX — boot.js
   كل الأوامر اللي بتشتغل أول ما الصفحة تفتح (تهيئة فايربيز، المستمعين، ...).
   بتتحمل آخر ملف عشان كل الدوال والمتغيرات من باقي الملفات تكون جاهزة. */

/* ───────── من: js/core/viewport.js ───────── */

setAppVh();

window.addEventListener('resize', setAppVh);

window.addEventListener('orientationchange', function(){ setTimeout(setAppVh, 250); });

if(window.visualViewport){
  window.visualViewport.addEventListener('resize', setAppVh);
  window.visualViewport.addEventListener('scroll', setAppVh);
}

/* دعم إضافي: بعض الويب فيوهات (لما الصفحة بتتحول لتطبيق) بتوفر VirtualKeyboard API بدل ما تحرك visualViewport لوحدها، فبنمسك ارتفاع الكيبورد منها كمان ونرفع حقل الكتابة بيه إجباريًا */
if('virtualKeyboard' in navigator){
  try{
    navigator.virtualKeyboard.overlaysContent = true;
    navigator.virtualKeyboard.addEventListener('geometrychange', function(){
      var r = navigator.virtualKeyboard.boundingRect;
      __kbExtraOffset = (r && r.height) ? Math.round(r.height) : 0;
      document.body.classList.toggle('kb-open', __kbExtraOffset > 40);
      setAppVh();
      scrollFocusedIntoView();
    });
  }catch(e){}
}

document.addEventListener('focusin', function(e){
  if(e.target && (e.target.tagName==='INPUT' || e.target.tagName==='TEXTAREA')){
    __focusedField = e.target;
    document.body.classList.add('kb-open');
    /* بنعيد الحساب أكتر من مرة بفواصل زمنية مختلفة عشان نلحق أي تطبيق مغلف بياخد وقت أطول يفتح فيه الكيبورد */
    [0,100,250,400,650,900].forEach(function(delay){
      setTimeout(function(){ setAppVh(); scrollFocusedIntoView(); }, delay);
    });
    /* لو بعد نص ثانية من فتح الكيبورد لسه مفيش أي رقم حقيقي راجع من visualViewport ولا من
       VirtualKeyboard API (يعني التطبيق المغلّف مش بيبلغ عن الكيبورد خالص)، بنفعّل رقم تخميني
       احتياطي (نسبة من ارتفاع الشاشة) ونرفع بيه حقل الكتابة إجباريًا لحد ما الكيبورد يقفل،
       وبنفضل نتابع كل شوية لو ظهر رقم حقيقي نستبدل بيه التخميني فورًا */
    if(__kbPollTimer) clearInterval(__kbPollTimer);
    var pollCount = 0;
    __kbPollTimer = setInterval(function(){
      pollCount++;
      var vv = window.visualViewport;
      var kbFromViewport = vv ? Math.max(0, window.innerHeight - vv.height - (vv.offsetTop||0)) : 0;
      var realOffset = Math.max(kbFromViewport, __kbExtraOffset);
      if(realOffset > 40){
        __heuristicOffset = 0; // فيه رقم حقيقي، مانحتاجش نخمّن
      }else if(pollCount >= 3 && __focusedField){
        __heuristicOffset = Math.max(240, Math.round(__restHeight * 0.4));
      }
      setAppVh();
      scrollFocusedIntoView();
    }, 200);
  }
}, true);

document.addEventListener('focusout', function(e){
  if(e.target && (e.target.tagName==='INPUT' || e.target.tagName==='TEXTAREA')){
    __focusedField = null;
    __kbExtraOffset = 0;
    __heuristicOffset = 0;
    if(__kbPollTimer){ clearInterval(__kbPollTimer); __kbPollTimer = null; }
    setTimeout(function(){ document.body.classList.remove('kb-open'); setAppVh(); }, 80);
  }
}, true);

/* ───────── من: js/core/firebase-init.js ───────── */

firebase.initializeApp(firebaseConfig);

var fbAuth = firebase.auth();

var rtdb = firebase.database();

var fbStorage = firebase.storage();

try{ firebase.analytics(); }catch(e){}

/* ───────── من: js/core/theme-and-update.js ───────── */

rtdb.ref('siteConfig').on('value', function(snap){
  applyThemeColors(snap.val());
});

/* ───────── من: js/core/state.js ───────── */

var appStartTime = Date.now();

/* ───────── من: js/auth/accounts.js ───────── */

setupConnectivityWatcher();

/* ───────── من: js/social/menu-and-friends.js ───────── */

document.getElementById('openMenu').addEventListener('click', function(){ document.getElementById('sideMenu').classList.add('active'); });

document.getElementById('closeMenu').addEventListener('click', function(){ document.getElementById('sideMenu').classList.remove('active'); });

/* ───────── من: js/chat/capsule-attachments-voice.js ───────── */

setInterval(function(){
  // بنراجع كل كبسولات الشات المفتوح كل شوية عشان تتفتح لوحدها لحظة ما ميعادها يجي، من غير ما المستخدم يعمل رفرش
  Object.keys(messagesCache).forEach(function(id){
    var m = messagesCache[id];
    if(m && m.type==='capsule' && m.unlockAt && Date.now()>=m.unlockAt){
      var el = document.querySelector('.msg-row[data-msg-id="'+id+'"]');
      if(el && el.dataset.capsuleLocked==='1') unlockCapsuleInPlace(id, m);
    }
  });
}, 15000);

/* ───────── من: js/chat/message-extras.js ───────── */

/* حماية إضافية: لو المستخدم سحب شريط الإشعارات/فتح تبديل التطبيقات أو الشاشة فقدت التركيز
   (وده بيحصل غالبًا لحظة محاولة أخد سكرين شوت على أغلب الأجهزة) نخفي الصورة فورًا بمجرد ما نلاحظ كده */
document.addEventListener('visibilitychange', function(){
  var modal = document.getElementById('viewOnceModal');
  if(!modal || !modal.classList.contains('active')) return;
  document.getElementById('voPrivacyShield').classList.toggle('active', document.hidden);
});

window.addEventListener('blur', function(){
  var modal = document.getElementById('viewOnceModal');
  if(modal && modal.classList.contains('active')) document.getElementById('voPrivacyShield').classList.add('active');
});

/* ───────── من: js/social/status-and-media-viewer.js ───────── */

(function(){
  var touchStartY = null;
  var modal = document.getElementById('mediaViewerModal');
  modal.addEventListener('touchstart', function(e){ touchStartY = e.touches[0].clientY; }, {passive:true});
  modal.addEventListener('touchend', function(e){
    if(touchStartY===null) return;
    var dy = e.changedTouches[0].clientY - touchStartY;
    touchStartY = null;
    if(Math.abs(dy) < 55) return; // سحبة قصيرة، تجاهلها
    if(dy < 0) mvGoTo(mvIndex+1); // سحب لفوق = التالي (زي التيك توك)
    else mvGoTo(mvIndex-1);       // سحب لتحت = اللي قبله
  }, {passive:true});
})();

/* ───────── تشغيل مستمع حالة تسجيل الدخول (بعد ما كل شيء اتحمل) ───────── */
fbAuth.onAuthStateChanged(handleAuthStateChange);
if(window.ZyroxSocialAuth) ZyroxSocialAuth.handleRedirectResult();
