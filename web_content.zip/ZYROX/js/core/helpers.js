/* ZYROX — core/helpers.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ HELPERS ============ */
function esc(s){ var d=document.createElement('div'); d.innerText = s==null?'':s; return d.innerHTML; }
function avatarLetter(name){ return (name||'؟').trim().charAt(0).toUpperCase(); }
function fmtTime(ts){ if(!ts) return ''; var d=new Date(ts); return d.toLocaleTimeString('ar-EG',{hour:'2-digit',minute:'2-digit'}); }
var BADGE_TYPES = {
  red:   { cls:'', color:'#ff2255', title:'حساب موثّق' },
  green: { cls:' badge-green', color:'#39ffb0', title:'حساب موثّق (بيزنس)' },
  blue:  { cls:' badge-blue', color:'#2b95ff', title:'حساب موثّق (مشهور)' }
};
function badgeTypeOf(val){
  if(!val) return [];
  if(val===true) return ['red'];
  if(typeof val==='string') return BADGE_TYPES[val] ? [val] : [];
  if(typeof val==='object') return Object.keys(BADGE_TYPES).filter(function(t){ return !!val[t]; });
  return [];
}
/* الإيموجيهات المميزة اللي متاحة للموثقين بس */
var VERIFIED_EMOJIS = ['👑','💎','⚡','🔥','🦋','🌟','💫','🍀','🎯','🧿','🚀','🎭'];

function verifiedBadgeHTML(val, activeColor, verifiedEmoji){
  var types = badgeTypeOf(val);
  if(!types.length) return '';
  var chosen = (activeColor && types.indexOf(activeColor)!==-1) ? activeColor : types[0];
  var cfg = BADGE_TYPES[chosen];
  var html = ' <i class="fa-solid fa-circle-check verified-badge'+cfg.cls+'" title="'+cfg.title+'" data-badge-type="'+chosen+'"></i>';
  if(verifiedEmoji && VERIFIED_EMOJIS.indexOf(verifiedEmoji)!==-1){
    html += '<span class="verified-emoji-float" title="إيموجي مميز للموثقين">'+verifiedEmoji+'</span>';
  }
  return html;
}
function nameWithBadge(name, isVerified, activeColor, verifiedEmoji){ return esc(name) + verifiedBadgeHTML(isVerified, activeColor, verifiedEmoji); }
function isCurrentUserVerified(){ return badgeTypeOf(currentProfile && currentProfile.isVerified).length>0; }
function avatarBlockHTML(name, photoURL, extraStyle){
  extraStyle = extraStyle || '';
  if(photoURL){
    return '<div class="avatar" style="'+extraStyle+'background-image:url(\''+photoURL+'\');background-size:cover;background-position:center;color:transparent">&nbsp;</div>';
  }
  return '<div class="avatar" style="'+extraStyle+'">'+esc(avatarLetter(name))+'</div>';
}
function showAuthError(msg){ var e=document.getElementById('authError'); e.textContent=msg; e.style.display='block'; document.getElementById('authSuccess').style.display='none'; }
function showAuthSuccess(msg){ var e=document.getElementById('authSuccess'); e.textContent=msg; e.style.display='block'; document.getElementById('authError').style.display='none'; }
function clearAuthMsgs(){ document.getElementById('authError').style.display='none'; document.getElementById('authSuccess').style.display='none'; }
