/* ZYROX — core/state.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ GLOBAL STATE ============ */
var currentUser = null;
var currentProfile = null;
var isOnline = true;
var currentChatId = null;
var currentChatData = null;
var messagesRef = null;
var replyingTo = null; // {id, senderName, text}
var messagesCache = {}; // id -> message data, used for message actions (delete/reply)
var userChatsRef = null;
var knownLastMsgTime = {}; // cid -> آخر وقت رسالة اتشافه، لاكتشاف الرسايل الجديدة وعمل إشعار
var chatsCache = {}; // cid -> بيانات الشات مع العداد، بتتحدث لحظيًا من غير إعادة تحميل كل حاجة من جديد (للسرعة)
var chatLiveListeners = {}; // cid -> true لو عامل listener مباشر على الشات ده
var chatLastReadListeners = {}; // cid -> true لو عامل listener على lastRead بتاع الشات ده
var supportThreadsRef = null; // أدمن: listener على كل ثريدات الدعم / يوزر عادي: listener على ثريده هو بس
var supportMessagesRef = null;
var currentSupportUid = null; // الثريد المفتوح دلوقتي في شاشة رد الأدمن
var supportThreadsCache = {}; // أدمن: uid -> بيانات الثريد
var notifInitDone = false; // عشان منعملش إشعارات لكل الشاتات القديمة أول ما التطبيق يفتح
var friendReqRef = null;
var friendsRef = null;
var mediaRecorder = null, audioChunks = [], isRecording = false;
var groupSelectedMembers = {};
var addMemberSelected = {};
var searchDebounce = null;
var friendSearchDebounce = null;
var blockedMap = {};
var friendsMap = {};
var announcementsRef = null;
var profileGiftsRef = null;
var otherPresenceRef = null;
var otherTypingRef = null;
var otherTypingCheckInterval = null;
var otherTypingTs = 0;
var lastPresenceSubtitle = '';
var myTypingLastWriteTs = 0;
var myTypingClearTimer = null;
var myTypingSessionActive = false;
var exeBalanceRef = null;
var REPORTS_TO_BAN = 60;
var BAN_HOURS = 6;
var FINCH_BAN_MINUTES = 5; // مدة الحظر الفوري لما مستخدم متعين "فنش" يبلّغ عن حد، من غير مراجعة الذكاء الاصطناعي
var AI_BAN_MINUTES = 5; // مدة الحظر التلقائي لما الذكاء الاصطناعي يكتشف محتوى مسيء/ضار
var WARNINGS_TO_BAN_NORMAL = 3;   // عدد التحذيرات اللي بتودي لحظر عضو عادي
var WARNINGS_TO_BAN_VERIFIED = 6; // الأعضاء الموثقين محصّنين أكتر: محتاجين ضعف عدد التحذيرات
var WARNING_BAN_HOURS = 6;
