  // بووت سريع: لو المستخدم دخل قبل كده على الجهاز ده، نشيل شاشة تسجيل الدخول فورًا (حتى قبل ما فايربيز يحمل) عشان مفيش أي ومضة لشاشة الدخول تاني أبدًا
  (function(){
    try{
      var hasCachedSession = Object.keys(localStorage).some(function(k){ return k.indexOf('exe_cached_profile_')===0; });
      if(hasCachedSession){
        var a = document.getElementById('authScreen'); if(a) a.style.display='none';
        var c = document.getElementById('appContainer'); if(c) c.style.display='flex';
      }
    }catch(e){}
  })();
