/* ZYROX — core/theme-and-update.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ نظام التحديث الذاتي للمنصة (Self-Update via Firebase) ============
   ⚠️ النسخة دي من الملف اتفصلت عمدًا عن نظام التحديث الذاتي: حتى لو الأدمن رفع
   تحديث جديد (appUpdate/version + appUpdate/content) وانطبق على نسخ تانية من
   نفس المشروع، النسخة دي مش هتتأثر خالص ومش هتستبدل نفسها أبدًا. لوحة تحكم
   الأدمن لرفع/إلغاء التحديثات (تحت) لسه شغالة عادي لو محتاجها تحدّث مواقع تانية. */
var APP_LOCAL_VERSION = 22;
function checkForAppUpdate(){ /* معطّلة عمدًا — الموقع ده منفصل عن التحديث الذاتي */ }

function usernameToHiddenEmail(usernameLower){ return usernameLower + "@neonchat.local"; }

/* ============ THEME COLORS (بتتطبق فورًا على الكل، حتى قبل تسجيل الدخول) ============ */
var THEME_COLOR1_DEFAULT = '#1ED760';
var THEME_COLOR2_DEFAULT = '#9146FF';
function applyThemeColors(cfg){
  cfg = cfg || {};
  var c1 = cfg.themeColor1 || THEME_COLOR1_DEFAULT;
  var c2 = cfg.themeColor2 || THEME_COLOR2_DEFAULT;
  var root = document.documentElement.style;
  root.setProperty('--neon-blue', c1);
  root.setProperty('--neon-purple', c2);
  root.setProperty('--border-purple', c2);
  root.setProperty('--success', c1);
}
