/* ZYROX — core/firebase-init.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ FIREBASE INIT ============ */
var firebaseConfig = {
  apiKey: "AIzaSyCE7eWBSALiU40tXq0Z4VOg_LGHFVuLTTg",
  authDomain: "sheref-4f53f.firebaseapp.com",
  databaseURL: "https://sheref-4f53f-default-rtdb.firebaseio.com",
  projectId: "sheref-4f53f",
  storageBucket: "sheref-4f53f.firebasestorage.app",
  messagingSenderId: "421455356336",
  appId: "1:421455356336:web:c3a71eeae6c78562ed7675",
  measurementId: "G-65J8ZJSDY2"
};
