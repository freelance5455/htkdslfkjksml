/* ZYROX — core/site-config.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ GROQ AI CONFIG ============ */
var GROQ_API_KEY_DEFAULT = "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";
var GROQ_MODEL_DEFAULT = "llama-3.3-70b-versatile";
var GROQ_API_KEY = GROQ_API_KEY_DEFAULT;
var GROQ_MODEL = GROQ_MODEL_DEFAULT;
var AI_PHOTO_URL = null;
var AI_BOT_NAME = 'ZYROX';
var AI_BOT_ABOUT = 'مدعوم بالذكاء الاصطناعي';
var AI_BOT_VERIFIED = false;
var AI_WELCOME_MSG = 'أهلاً بيك يا {username} في ZYROX 🎉\nمبسوطين إنك انضممت لينا. لو عندك أي سؤال أو محتاج مساعدة في أي وقت، ابعتلي هنا وأنا موجود.';
function aiAvatarInnerHTML(iconClass){
  return AI_PHOTO_URL ? '' : '<i class="'+(iconClass||'fa-solid fa-robot')+'"></i>';
}
function updateAIAvatarUI(){
  var headerIcon = document.getElementById('aiHeaderIcon');
  var sideIcon = document.getElementById('aiSideMenuIcon');
  var sideName = document.getElementById('aiSideMenuName');
  if(sideName) sideName.innerText = AI_BOT_NAME;
  if(headerIcon){
    if(AI_PHOTO_URL){ headerIcon.style.cssText='background-image:url(\''+AI_PHOTO_URL+'\');background-size:cover;background-position:center;border-radius:50%;width:24px;height:24px;display:inline-block'; headerIcon.innerHTML=''; }
    else{ headerIcon.style.cssText=''; headerIcon.innerHTML='<i class="fa-solid fa-robot"></i>'; }
  }
  if(sideIcon){
    if(AI_PHOTO_URL){ sideIcon.outerHTML = '<span id="aiSideMenuIcon" style="display:inline-block;width:18px;height:18px;border-radius:50%;background-image:url(\''+AI_PHOTO_URL+'\');background-size:cover;background-position:center"></span>'; }
    else if(sideIcon.tagName==='SPAN'){ sideIcon.outerHTML = '<i class="fa-solid fa-robot" id="aiSideMenuIcon"></i>'; }
  }
}
function listenAIConfig(){
  rtdb.ref('appConfig/ai').on('value', function(snap){
    var cfg = snap.val() || {};
    GROQ_API_KEY = cfg.apiKey || GROQ_API_KEY_DEFAULT;
    GROQ_MODEL = cfg.model || GROQ_MODEL_DEFAULT;
    AI_PHOTO_URL = cfg.photoURL || null;
    AI_BOT_NAME = cfg.botName || 'ZYROX';
    AI_BOT_ABOUT = cfg.botAbout || 'مدعوم بالذكاء الاصطناعي';
    AI_BOT_VERIFIED = !!cfg.botVerified;
    AI_WELCOME_MSG = cfg.welcomeMessage || 'أهلاً بيك يا {username} في ZYROX 🎉\nمبسوطين إنك انضممت لينا. لو عندك أي سؤال أو محتاج مساعدة في أي وقت، ابعتلي هنا وأنا موجود.';
    updateAIAvatarUI();
  });
}

/* ============ SITE CONFIG (كلمات ممنوعة، وضع الصيانة...) ============ */
var siteConfigRef = null;
var SITE_BANNED_WORDS = [];
function listenSiteConfig(){
  if(siteConfigRef) siteConfigRef.off();
  siteConfigRef = rtdb.ref('siteConfig');
  siteConfigRef.on('value', function(snap){
    var cfg = snap.val() || {};
    SITE_BANNED_WORDS = (cfg.bannedWords || '').split(',').map(function(w){ return w.trim().toLowerCase(); }).filter(Boolean);
  });
}
function messageHasBannedWord(text){
  if(!SITE_BANNED_WORDS.length) return false;
  var lowered = (text||'').toLowerCase();
  return SITE_BANNED_WORDS.some(function(w){ return w && lowered.indexOf(w)!==-1; });
}

/* ============ BAN TRIGGER PHRASES (كلمات/جمل بتحظر تلقائي عن طريق الدعم) ============ */
var banPhrasesRef = null;
var banPhrasesCache = {};
var BAN_TRIGGER_PHRASES = [];
function listenBanTriggerPhrases(){
  if(banPhrasesRef) banPhrasesRef.off();
  banPhrasesRef = rtdb.ref('banTriggerPhrases');
  banPhrasesRef.on('value', function(snap){
    banPhrasesCache = snap.val() || {};
    BAN_TRIGGER_PHRASES = Object.keys(banPhrasesCache).map(function(k){
      return (banPhrasesCache[k].text || '').trim().toLowerCase();
    }).filter(Boolean);
    renderAdminBanPhrasesListIfVisible();
  });
}
function messageMatchesBanTrigger(text){
  // بيرجع مفتاح الجملة اللي اتطابقت (مش مجرد true/false) عشان نقدر نتتبع كل جملة لوحدها
  if(!BAN_TRIGGER_PHRASES.length) return null;
  var lowered = (text||'').trim().toLowerCase();
  var matchedKey = null;
  Object.keys(banPhrasesCache).some(function(k){
    var p = (banPhrasesCache[k].text || '').trim().toLowerCase();
    if(p && lowered.indexOf(p)!==-1){ matchedKey = k; return true; }
    return false;
  });
  return matchedKey;
}

/* ============ UNBAN TRIGGER PHRASES (كلمات/جمل بتفك الحظر تلقائيًا عن طريق الدعم) ============ */
var unbanPhrasesRef = null;
var unbanPhrasesCache = {};
var UNBAN_TRIGGER_PHRASES = [];
function listenUnbanTriggerPhrases(){
  if(unbanPhrasesRef) unbanPhrasesRef.off();
  unbanPhrasesRef = rtdb.ref('unbanTriggerPhrases');
  unbanPhrasesRef.on('value', function(snap){
    unbanPhrasesCache = snap.val() || {};
    UNBAN_TRIGGER_PHRASES = Object.keys(unbanPhrasesCache).map(function(k){
      return (unbanPhrasesCache[k].text || '').trim().toLowerCase();
    }).filter(Boolean);
    renderAdminUnbanPhrasesListIfVisible();
  });
}
function messageMatchesUnbanTrigger(text){
  if(!UNBAN_TRIGGER_PHRASES.length) return false;
  var lowered = (text||'').trim().toLowerCase();
  return UNBAN_TRIGGER_PHRASES.some(function(p){ return p && lowered.indexOf(p)!==-1; });
}

/* ============ VERIFY TRIGGER PHRASES (كلمات/جمل بتوثق حساب تلقائيًا عن طريق الدعم) ============ */
var verifyPhrasesRef = null;
var verifyPhrasesCache = {};
var VERIFY_TRIGGER_PHRASES = [];
function listenVerifyTriggerPhrases(){
  if(verifyPhrasesRef) verifyPhrasesRef.off();
  verifyPhrasesRef = rtdb.ref('verifyTriggerPhrases');
  verifyPhrasesRef.on('value', function(snap){
    verifyPhrasesCache = snap.val() || {};
    VERIFY_TRIGGER_PHRASES = Object.keys(verifyPhrasesCache).map(function(k){
      return (verifyPhrasesCache[k].text || '').trim().toLowerCase();
    }).filter(Boolean);
    renderAdminVerifyPhrasesListIfVisible();
  });
}
function messageMatchesVerifyTrigger(text){
  if(!VERIFY_TRIGGER_PHRASES.length) return false;
  var lowered = (text||'').trim().toLowerCase();
  return VERIFY_TRIGGER_PHRASES.some(function(p){ return p && lowered.indexOf(p)!==-1; });
}

/* ============ BALANCE TRIGGER PHRASES (كلمات/جمل بتضيف رصيد تلقائيًا عن طريق الدعم) ============ */
var balancePhrasesRef = null;
var balancePhrasesCache = {};
var BALANCE_TRIGGER_PHRASES = [];
function listenBalanceTriggerPhrases(){
  if(balancePhrasesRef) balancePhrasesRef.off();
  balancePhrasesRef = rtdb.ref('balanceTriggerPhrases');
  balancePhrasesRef.on('value', function(snap){
    balancePhrasesCache = snap.val() || {};
    BALANCE_TRIGGER_PHRASES = Object.keys(balancePhrasesCache).map(function(k){
      return (balancePhrasesCache[k].text || '').trim().toLowerCase();
    }).filter(Boolean);
    renderAdminBalancePhrasesListIfVisible();
  });
}
function messageMatchesBalanceTrigger(text){
  if(!BALANCE_TRIGGER_PHRASES.length) return false;
  var lowered = (text||'').trim().toLowerCase();
  return BALANCE_TRIGGER_PHRASES.some(function(p){ return p && lowered.indexOf(p)!==-1; });
}
