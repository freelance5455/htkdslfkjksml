/* ZYROX — core/viewport.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ ارتفاع الشاشة الحقيقي (يراعي الكيبورد) — يخلي حقل الكتابة يترفع فوق الكيبورد إجباريًا حتى لو اتحوّلت الصفحة لتطبيق (WebView) ============ */
var __kbExtraOffset = 0; // اوفست إضافي جاي من VirtualKeyboard API لما الويب فيو مايكبرش/يصغّرش الـ visualViewport لوحده
var __heuristicOffset = 0; // اوفست احتياطي تخميني بيتفعّل بس لو التطبيق (WebView) رفض يبلّغ عن أي تغيير في الارتفاع خالص لما الكيبورد يفتح
var __restHeight = window.innerHeight; // آخر ارتفاع معروف للشاشة من غير ما الكيبورد يكون فاتح
function setAppVh(){
  var vv = window.visualViewport;
  var h = (vv ? vv.height : window.innerHeight);
  document.documentElement.style.setProperty('--app-vh', (h*0.01)+'px');
  /* حساب ارتفاع الكيبورد مباشرة من الفرق بين window.innerHeight و visualViewport.height —
     ده بيشتغل في أغلب الويب فيوهات حتى لو navigator.virtualKeyboard مش موجودة، وبيضمن إن
     حقل الكتابة يترفع فوق الكيبورد إجباريًا بأكتر من طريقة مع بعض (مش بس طريقة واحدة) */
  var kbFromViewport = vv ? Math.max(0, window.innerHeight - vv.height - (vv.offsetTop||0)) : 0;
  var realOffset = Math.max(kbFromViewport, __kbExtraOffset);
  if(!__focusedField) __restHeight = window.innerHeight;
  /* لو التطبيق (WebView) اللي شغالة فيه الصفحة مش بيبلّغ عن أي تغيير في الارتفاع خالص لما
     الكيبورد يفتح (شائع في تطبيقات الـ WebView المغلّفة اللي مش مظبوطة adjustResize)، بنستخدم
     __heuristicOffset كتخمين احتياطي بديل — مفعّل بس لو مفيش أي رقم حقيقي راجع من أي طريقة تانية */
  var finalOffset = realOffset > 0 ? realOffset : __heuristicOffset;
  document.documentElement.style.setProperty('--kb-extra', finalOffset+'px');
  document.body.classList.toggle('kb-open', finalOffset > 40);
}
var __focusedField = null;
var __kbPollTimer = null;
function scrollFocusedIntoView(){
  if(!__focusedField) return;
  if(__focusedField.scrollIntoView) __focusedField.scrollIntoView({block:'end', behavior:'smooth'});
  var activeMsgArea = document.getElementById('messagesArea');
  if(activeMsgArea) activeMsgArea.scrollTop = activeMsgArea.scrollHeight;
}
