/* ZYROX — moderation/reports-and-appeals.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ فحص البلاغات بالذكاء الاصطناعي ============ */
async function aiAnalyzeReportContent(sampleText){
  if(!sampleText || !sampleText.trim()) return {harmful:false, reason:''};
  try{
    var res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method:'POST',
      headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer '+GROQ_API_KEY },
      body: JSON.stringify({
        model: GROQ_MODEL,
        temperature: 0.1,
        messages: [
          {role:'system', content:'انت نظام فحص محتوى جوه تطبيق شات. هيوصلك نص كتبه أو بعت بيه مستخدم اتبلّغ عنه من مستخدم تاني. مهمتك تحدد لو النص ده فيه كلام عيب، إساءة، تحرش، تهديد، خطاب كراهية، أو أي محتوى ضار بشكل عام. رد بصيغة JSON فقط من غير أي مقدمة أو شرح، بالشكل ده بالظبط: {"harmful": true أو false, "reason": "سبب مختصر جدًا بالعربي لو harmful=true، أو نص فاضي لو false"}'},
          {role:'user', content: sampleText.slice(0, 2000)}
        ]
      })
    });
    var data = await res.json();
    var raw = (data.choices && data.choices[0]) ? data.choices[0].message.content : '';
    var cleaned = (raw||'').replace(/```json|```/g,'').trim();
    var jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    var parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : {harmful:false};
    return { harmful: !!parsed.harmful, reason: parsed.reason || '' };
  }catch(err){
    // لو فحص الذكاء الاصطناعي فشل (مثلاً أوفلاين)، منمنعش إرسال البلاغ العادي، بس منحظرش تلقائيًا
    return {harmful:false, reason:''};
  }
}

/* ============ مراجعة الحظر بالذكاء الاصطناعي (BAN APPEAL) ============
   البيانات: banAppeals/{uid} = {reason, aiReason, status:'rejected'|'approved', decidedAt}
*/
var BAN_APPEAL_COOLDOWN_MIN = 15; // لازم يستنى الوقت ده بعد الرفض قبل ما يطلب مراجعة تانية

async function aiReviewBanAppeal(banReason, appealText){
  try{
    var res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method:'POST',
      headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer '+GROQ_API_KEY },
      body: JSON.stringify({
        model: GROQ_MODEL,
        temperature: 0.1,
        messages: [
          {role:'system', content:'انت نظام مراجعة حظر حسابات جوه تطبيق شات. هيوصلك سبب حظر الحساب (لو موجود) ورسالة اعتراض كتبها صاحب الحساب المحظور بيشرح فيها ليه شايف إن الحظر ظلم. مهمتك تقيّم الاعتراض بحياد وعدل: لو الاعتراض منطقي وواضح إن الحظر غلط أو مبالغ فيه أو سوء فهم، أو السبب الأصلي ضعيف جدًا، يبقى فك الحظر. لو الاعتراض غير مقنع، أو فيه تهرب واضح من مسؤولية، أو سبب الحظر خطير (زي إساءة أو تهديد أو محتوى ضار)، متفكش الحظر. رد بصيغة JSON فقط من غير أي مقدمة، بالشكل ده بالظبط: {"unban": true أو false, "reason": "سبب مختصر جدًا بالعربي يشرح قرارك"}'},
          {role:'user', content: 'سبب الحظر: '+(banReason||'مش محدد')+'\n\nاعتراض المستخدم: '+(appealText||'').slice(0,1500)}
        ]
      })
    });
    var data = await res.json();
    var raw = (data.choices && data.choices[0]) ? data.choices[0].message.content : '';
    var cleaned = (raw||'').replace(/```json|```/g,'').trim();
    var jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    var parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : {unban:false, reason:'تعذرت المراجعة، حاول تاني لاحقًا.'};
    return { unban: !!parsed.unban, reason: parsed.reason || '' };
  }catch(err){
    return { unban:false, reason:'تعذر إتمام المراجعة دلوقتي (تأكد إنك متصل بالنت) وحاول تاني.' };
  }
}

async function renderBanAppealBox(uid, banData){
  var statusEl = document.getElementById('banAppealStatus');
  var formWrap = document.getElementById('banAppealFormWrap');
  if(!statusEl || !formWrap) return;
  statusEl.className = 'appeal-status'; statusEl.textContent='';
  formWrap.style.display='block';
  try{
    var snap = await rtdb.ref('banAppeals/'+uid).once('value');
    var appeal = snap.val();
    if(appeal && appeal.status==='rejected'){
      var elapsedMin = (Date.now() - (appeal.decidedAt||0)) / 60000;
      if(elapsedMin < BAN_APPEAL_COOLDOWN_MIN){
        var remain = Math.ceil(BAN_APPEAL_COOLDOWN_MIN - elapsedMin);
        statusEl.className = 'appeal-status rejected';
        statusEl.textContent = 'تم رفض طلب المراجعة السابق. السبب: ' + (appeal.aiReason||'—') + '. تقدر تطلب مراجعة تانية بعد ' + remain + ' دقيقة.';
        formWrap.style.display='none';
      }else{
        statusEl.className = 'appeal-status rejected';
        statusEl.textContent = 'تم رفض طلب المراجعة السابق. السبب: ' + (appeal.aiReason||'—') + '. تقدر تطلب مراجعة تانية دلوقتي.';
      }
    }
  }catch(e){ /* لو فشل تحميل حالة الطلب السابق، سيبها تعرض الفورم عادي */ }
}

window.submitBanAppeal = async function(){
  var uid = (currentUser && currentUser.uid) || (fbAuth.currentUser && fbAuth.currentUser.uid);
  if(!uid) return;
  var input = document.getElementById('banAppealReasonInput');
  var text = input.value.trim();
  if(!text){ alert('اكتب سبب اعتراضك على الحظر الأول'); return; }
  var btn = document.getElementById('banAppealSubmitBtn');
  btn.disabled = true;
  var originalHtml = btn.innerHTML;
  btn.innerHTML = 'جارٍ المراجعة... <span class="spinner"></span>';
  var statusEl = document.getElementById('banAppealStatus');
  try{
    var banSnap = await rtdb.ref('bans/'+uid).once('value');
    var banData = banSnap.val() || {};
    var result = await aiReviewBanAppeal(banData.reason, text);
    if(result.unban){
      await rtdb.ref('banAppeals/'+uid).set({ reason:text, aiReason:result.reason, status:'approved', decidedAt: firebase.database.ServerValue.TIMESTAMP });
      await rtdb.ref('bans/'+uid).remove();
      statusEl.className = 'appeal-status approved';
      statusEl.textContent = 'تمت الموافقة على طلبك وفك الحظر عن حسابك! السبب: ' + (result.reason||'');
      document.getElementById('banAppealFormWrap').style.display='none';
      setTimeout(function(){ location.reload(); }, 1800);
    }else{
      await rtdb.ref('banAppeals/'+uid).set({ reason:text, aiReason:result.reason, status:'rejected', decidedAt: firebase.database.ServerValue.TIMESTAMP });
      input.value='';
      renderBanAppealBox(uid, banData);
    }
  }catch(err){
    alert('حصل خطأ أثناء المراجعة، حاول تاني.');
  }finally{
    btn.disabled = false;
    btn.innerHTML = originalHtml;
  }
};

async function collectRecentUserMessages(chatId, uid, limit){
  if(!chatId) return '';
  try{
    var snap = await rtdb.ref('messages/'+chatId).limitToLast(40).once('value');
    if(!snap.exists()) return '';
    var obj = snap.val();
    var texts = Object.keys(obj).map(function(k){ return obj[k]; })
      .filter(function(m){ return m.senderId===uid && m.type==='text' && m.text; })
      .sort(function(a,b){ return (a.timestamp||0)-(b.timestamp||0); })
      .slice(-limit)
      .map(function(m){ return m.text; });
    return texts.join('\n');
  }catch(e){ return ''; }
}

async function applyReportOutcome(uid, reason, sampleText){
  if(await isUidAdmin(uid)){ showBlackToast('تم إرسال البلاغ، شكرًا لك.'); return; } // الأدمن محصّن بالكامل من الحظر

  // صلاحية "فنش": أي بلاغ من مستخدم متعين فنش بيحظر المُبلّغ عنه فورًا 5 دقايق من غير ما يعدي على مراجعة الذكاء الاصطناعي
  if(currentProfile && currentProfile.isFinch){
    var finchUntil = Date.now() + FINCH_BAN_MINUTES*60*1000;
    await rtdb.ref('bans/'+uid).set({ until: finchUntil, reason: 'بلاغ من مستخدم موثوق (فنش)'+(reason?(': '+reason):''), permanent:false });
    showBlackToast('تم إرسال البلاغ. تم حظر الحساب فورًا '+FINCH_BAN_MINUTES+' دقايق.');
    return;
  }

  var aiResult = await aiAnalyzeReportContent(sampleText);
  if(aiResult.harmful){
    var outcome = await issueWarningAndMaybeBan(uid, 'الذكاء الاصطناعي: '+(aiResult.reason||'محتوى مسيء أو ضار'));
    if(outcome.banned){
      showBlackToast('تم إرسال البلاغ. المستخدم ده وصل لعدد التحذيرات المسموح وتم حظره تلقائيًا '+WARNING_BAN_HOURS+' ساعات.');
    }else{
      showBlackToast('تم إرسال البلاغ. الذكاء الاصطناعي اكتشف محتوى مخالف، وتم توجيه تحذير للمستخدم ('+outcome.count+'/'+outcome.threshold+').');
    }
    return;
  }
  var repSnap = await rtdb.ref('reports/'+uid).once('value');
  var count = repSnap.exists() ? Object.keys(repSnap.val()).length : 0;
  if(count >= REPORTS_TO_BAN){
    var until = Date.now() + BAN_HOURS*60*60*1000;
    await rtdb.ref('bans/'+uid).set({ until: until, reason: 'بلاغات كتير من مستخدمين ('+count+')', permanent:false });
    showBlackToast('تم إرسال البلاغ. المستخدم ده وصل لعدد بلاغات كبير وتم حظره تلقائيًا '+BAN_HOURS+' ساعات.');
  }else{
    showBlackToast('تم إرسال البلاغ، شكرًا لك.');
  }
}

window.reportUserByUid = async function(uid){
  if(uid === currentUser.uid) return;
  var reason = prompt('اكتب سبب البلاغ (اختياري):') || '';
  try{
    await rtdb.ref('reports/'+uid+'/'+currentUser.uid).set({ reason: reason, ts: firebase.database.ServerValue.TIMESTAMP });
    var aboutSnap = await rtdb.ref('users/'+uid+'/about').once('value');
    var aboutText = aboutSnap.val() || '';
    var combined = (reason ? ('سبب البلاغ: '+reason+'\n') : '') + (aboutText ? ('نبذة المستخدم: '+aboutText) : '');
    await applyReportOutcome(uid, reason, combined);
  }catch(err){
    alert('تعذر إرسال البلاغ، حاول تاني');
  }
};

window.toggleMuteCurrentContact = async function(muted){
  var chatId = document.getElementById('upMuteToggle').getAttribute('data-chat-id');
  if(!chatId) return;
  if(muted) await rtdb.ref('chats/'+chatId+'/mutedBy/'+currentUser.uid).set(true);
  else await rtdb.ref('chats/'+chatId+'/mutedBy/'+currentUser.uid).remove();
};

window.toggleBlockCurrentChat = async function(){
  if(!currentChatData || currentChatData.type!=='direct') return;
  var otherUid = Object.keys(currentChatData.members).find(function(k){ return k!==currentUser.uid; });
  if(blockedMap[otherUid]){
    if(confirm('تلغي حظر المستخدم ده؟')) await rtdb.ref('blocked/'+currentUser.uid+'/'+otherUid).remove();
  }else{
    if(confirm('تحظر المستخدم ده؟ مش هيقدر يبعتلك رسايل')) await rtdb.ref('blocked/'+currentUser.uid+'/'+otherUid).set(true);
  }
};
