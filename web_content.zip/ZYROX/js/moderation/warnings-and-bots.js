/* ZYROX — moderation/warnings-and-bots.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

        // مدة الحظر لما العضو يوصل لعدد التحذيرات المطلوب

/* ============ نظام التحذيرات + الحظر ============
   warnings/{uid} = { count: N, list: { pushId: {reason, ts} } }
   الأدمن مش بيتحظر ولا بياخد تحذيرات خالص تحت أي ظرف.
*/
async function isUidAdmin(uid){
  try{
    var snap = await rtdb.ref('users/'+uid+'/isAdmin').once('value');
    return !!snap.val();
  }catch(e){ return false; }
}

async function issueWarningAndMaybeBan(uid, reason){
  if(await isUidAdmin(uid)) return { warned:false, banned:false }; // الأدمن محصّن بالكامل

  var uSnap = await rtdb.ref('users/'+uid).once('value');
  var u = uSnap.val() || {};
  var threshold = u.isVerified ? WARNINGS_TO_BAN_VERIFIED : WARNINGS_TO_BAN_NORMAL;

  await rtdb.ref('warnings/'+uid+'/list').push({ reason: reason||'محتوى مخالف اكتشفه الذكاء الاصطناعي', ts: firebase.database.ServerValue.TIMESTAMP });
  var countRes = await rtdb.ref('warnings/'+uid+'/count').transaction(function(c){ return (c||0)+1; });
  var newCount = (countRes && countRes.snapshot && countRes.snapshot.val()) || 1;

  if(newCount >= threshold){
    await rtdb.ref('bans/'+uid).set({
      until: Date.now() + WARNING_BAN_HOURS*60*60*1000, permanent:false,
      reason: 'وصل لعدد التحذيرات المسموح ('+newCount+'/'+threshold+') — آخر سبب: '+(reason||'محتوى مخالف')
    });
    await rtdb.ref('warnings/'+uid+'/count').set(0); // بنصفّر العداد بعد التنفيذ
    return { warned:true, banned:true, count:newCount, threshold:threshold };
  }
  return { warned:true, banned:false, count:newCount, threshold:threshold };
}
/* الأدمن الأساسي — محصّن: محدش (ولا هو نفسه) يقدر يشيل صلاحيته، يحظره، أو يحذف حسابه من لوحة الأدمن */

var GIFTS_CATALOG = [
  {key:'rose', emoji:'🌹', label:'وردة', price:10},
  {key:'teddy', emoji:'🧸', label:'دبدوب', price:25},
  {key:'candle', emoji:'🕯️', label:'شمعة', price:15},
  {key:'heart', emoji:'💝', label:'قلب', price:20},
  {key:'cake', emoji:'🎂', label:'تورتة', price:40},
  {key:'ring', emoji:'💍', label:'خاتم', price:100},
  {key:'star', emoji:'⭐', label:'نجمة', price:30},
  {key:'balloon', emoji:'🎈', label:'بالون', price:12},
  {key:'trophy', emoji:'🏆', label:'كأس', price:60}
];
/* لما المستلم يحول الهدية لـ ZYROX بياخد نسبة من سعرها (مش السعر كامل) عشان الاقتصاد يفضل متوازن */
var GIFT_CONVERT_RATIO = 0.7;
/* هدايا اتضافت بمعرفة الأدمن (بصورة أو إيموجي) — بتتحمل من الداتابيز */
var CUSTOM_GIFTS = [];
var customGiftsRef = null;
function findGiftByKey(key){
  return GIFTS_CATALOG.find(function(x){ return x.key===key; }) ||
         CUSTOM_GIFTS.find(function(x){ return x.key===key; });
}
function allGifts(){ return GIFTS_CATALOG.concat(CUSTOM_GIFTS); }
function listenCustomGifts(){
  if(customGiftsRef) customGiftsRef.off();
  customGiftsRef = rtdb.ref('customGifts');
  customGiftsRef.on('value', function(snap){
    CUSTOM_GIFTS = [];
    if(snap.exists()){
      var val = snap.val();
      Object.keys(val).forEach(function(k){
        var g = val[k];
        CUSTOM_GIFTS.push({ key:k, label:g.label, price:g.price, emoji:g.emoji||null, imageData:g.imageData||null });
      });
    }
    renderAdminGiftsList();
  });
}
function renderAdminGiftsList(){
  var el = document.getElementById('adminGiftsListEl');
  if(!el) return;
  if(CUSTOM_GIFTS.length===0){ el.innerHTML=''; return; }
  el.innerHTML = '<div class="empty-hint" style="padding:6px 2px;text-align:right">الهدايا اللي اتضافت:</div>' + CUSTOM_GIFTS.map(function(g){
    var visual = g.imageData ? '<img src="'+g.imageData+'" style="width:26px;height:26px;border-radius:6px;vertical-align:middle">' : g.emoji;
    return '<div class="settings-row"><div>'+visual+' '+esc(g.label)+' — '+g.price+' ZYROX</div><button class="small-btn danger" onclick="adminDeleteGift(\''+g.key+'\')">حذف</button></div>';
  }).join('');
}
window.adminAddGift = async function(){
  if(!currentProfile.isAdmin) return;
  var name = document.getElementById('adminGiftName').value.trim();
  var price = parseInt(document.getElementById('adminGiftPrice').value, 10);
  var emoji = document.getElementById('adminGiftEmoji').value.trim();
  var fileInput = document.getElementById('adminGiftImage');
  if(!name){ alert('اكتب اسم الهدية'); return; }
  if(!price || price<=0){ alert('اكتب سعر صحيح أكبر من صفر'); return; }
  if(!emoji && (!fileInput.files || fileInput.files.length===0)){ alert('اختار إيموجي أو ارفع صورة للهدية'); return; }
  function saveGift(imageData){
    rtdb.ref('customGifts').push({ label:name, price:price, emoji: imageData?null:(emoji||'🎁'), imageData: imageData||null }).then(function(){
      document.getElementById('adminGiftName').value='';
      document.getElementById('adminGiftPrice').value='';
      document.getElementById('adminGiftEmoji').value='';
      fileInput.value='';
      alert('تم إضافة الهدية');
    });
  }
  if(fileInput.files && fileInput.files.length>0){
    var reader = new FileReader();
    reader.onload = function(){ saveGift(reader.result); };
    reader.readAsDataURL(fileInput.files[0]);
  }else{
    saveGift(null);
  }
};
window.adminDeleteGift = async function(key){
  if(!currentProfile.isAdmin) return;
  if(!confirm('تمسح الهدية دي؟')) return;
  await rtdb.ref('customGifts/'+key).remove();
};

/* ============ نظام بوتات ZYROXBOT (بوتات المستخدمين فقط، مفيش بوت رسمي افتراضي) ============ */
var botConfigCache = {};

/* ============ START / OPEN BOT CHAT ============ */
window.startBotChat = async function(botId, botUsername){
  document.getElementById('searchResults').classList.remove('active');
  document.getElementById('searchInput').value='';
  var chatId = 'bot_'+currentUser.uid+'_'+botId;
  var snap = await rtdb.ref('chats/'+chatId).once('value');
  if(!snap.exists()){
    var members = {}; members[currentUser.uid]=true;
    await rtdb.ref('chats/'+chatId).set({
      type:'bot', botId: botId, members: members,
      createdAt: firebase.database.ServerValue.TIMESTAMP
    });
    await rtdb.ref('userChats/'+currentUser.uid+'/'+chatId).set(true);
  }
  window.openChat(chatId);
};

/* ============ BOT REPLY MATCHING ============ */
async function getBotConfig(botId){
  if(botConfigCache[botId]) return botConfigCache[botId];
  var snap = await rtdb.ref('bots/'+botId).once('value');
  var b = snap.val();
  botConfigCache[botId] = b;
  return b;
}

async function handleBotReply(text, botId){

  var b = await getBotConfig(botId);
  if(!b || b.disabled) return;
  var area = document.getElementById('messagesArea');
  var typingRow = document.createElement('div');
  typingRow.className='msg-row received'; typingRow.id='botTyping';
  typingRow.innerHTML = '<div class="msg-bubble"><i class="fa-solid fa-ellipsis fa-fade"></i> بيكتب...</div>';
  area.appendChild(typingRow); area.scrollTop = area.scrollHeight;
  var chatIdAtSend = currentChatId;
  var commands = b.commands || {};
  var lowered = text.trim().toLowerCase();
  var reply = null;
  Object.keys(commands).forEach(function(k){
    if(reply) return;
    var trig = (commands[k].trigger||'').trim().toLowerCase();
    if(!trig) return;
    if(trig.charAt(0)==='/'){
      if(lowered===trig) reply = commands[k].reply;
    }else{
      if(lowered.indexOf(trig)!==-1) reply = commands[k].reply;
    }
  });
  if(!reply) reply = b.fallback || 'مش فاهم عليك 🤖';
  var buttons = b.buttons || null;
  setTimeout(async function(){
    var typing = document.getElementById('botTyping'); if(typing) typing.remove();
    var msgPayload = { senderId:'bot:'+botId, senderName:b.name, type:'text', text:reply, timestamp: firebase.database.ServerValue.TIMESTAMP };
    if(buttons) msgPayload.buttons = buttons;
    await rtdb.ref('messages/'+chatIdAtSend).push().set(msgPayload);
    await rtdb.ref('chats/'+chatIdAtSend).update({ lastMessage: reply, lastMessageTime: firebase.database.ServerValue.TIMESTAMP });
  }, 500 + Math.random()*500);
}
