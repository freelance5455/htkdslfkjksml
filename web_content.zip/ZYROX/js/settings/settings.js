/* ZYROX — settings/settings.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ SETTINGS PANEL ============ */
window.openSettings = async function(){
  document.getElementById('sideMenu').classList.remove('active');
  // نفتح البانل فورًا، مش بعد ما نستنى الشبكة، عشان الإعدادات متفضلش "مقفولة" لو في تأخير أو خطأ في الاتصال
  document.getElementById('settingsScreen').classList.add('active');
  populateSettingsUI();
  try{
    var snap = await rtdb.ref('users/'+currentUser.uid).once('value');
    var fresh = snap.val();
    if(fresh) currentProfile = fresh;
  }catch(err){
    console.error('openSettings fetch error', err);
  }
  populateSettingsUI();
};

function populateSettingsUI(){
  if(!currentProfile) return;
  var avPrev = document.getElementById('settingsAvatarPreview');
  var heroAv = document.getElementById('heroAvatarPreview');
  if(currentProfile.photoURL){
    avPrev.innerHTML='';
    avPrev.style.cssText='background-image:url(\''+currentProfile.photoURL+'\');background-size:cover;background-position:center';
    if(heroAv){ heroAv.innerHTML=''; heroAv.style.backgroundImage="url('"+currentProfile.photoURL+"')"; }
  }else{
    avPrev.style.cssText='';
    avPrev.innerText = avatarLetter(currentProfile.displayName || currentProfile.username);
    if(heroAv){ heroAv.style.backgroundImage=''; heroAv.innerText = avatarLetter(currentProfile.displayName || currentProfile.username); }
  }
  var heroName = document.getElementById('heroDisplayName');
  if(heroName) heroName.innerHTML = nameWithBadge(currentProfile.displayName || currentProfile.username || '—', currentProfile.isVerified, currentProfile.activeBadgeColor, currentProfile.verifiedEmoji);
  var heroUser = document.getElementById('heroUsername');
  if(heroUser) heroUser.innerText = currentProfile.loginType==='phone' ? formatPhoneDisplay(currentProfile.phone||currentProfile.username) : ('@'+(currentProfile.username||''));
  var heroAbout = document.getElementById('heroAboutBubble');
  if(heroAbout) heroAbout.innerText = currentProfile.about || 'متاح حاليًا';
  document.getElementById('settingsDisplayName').value = currentProfile.displayName || currentProfile.username || '';
  document.getElementById('settingsAbout').value = currentProfile.about || '';
  if(currentProfile.loginType==='phone'){
    document.getElementById('settingsUsernameLabel').innerText = 'رقم الموبايل لتسجيل الدخول';
    document.getElementById('settingsUsernameStatic').innerText = formatPhoneDisplay(currentProfile.phone||currentProfile.username)+' (مش قابل للتغيير)';
  }else{
    document.getElementById('settingsUsernameLabel').innerText = 'اسم المستخدم لتسجيل الدخول';
    document.getElementById('settingsUsernameStatic').innerText = '@'+(currentProfile.username||'')+' (مش قابل للتغيير)';
  }
  var s = currentProfile.settings || {};
  document.getElementById('settingsLastSeen').value = s.lastSeen || 'everyone';
  document.getElementById('settingsProfilePhoto').value = s.profilePhotoPrivacy || 'everyone';
  document.getElementById('settingsAboutPrivacy').value = s.aboutPrivacy || 'everyone';
  document.getElementById('settingsGroupsAdd').value = s.groupAddPrivacy || 'everyone';
  setToggleState('toggleNotifications', s.notifications !== false);
  setToggleState('toggleSound', s.sound !== false);
  setToggleState('toggleReadReceipts', s.readReceipts !== false);
  setToggleState('toggleNotifPreview', s.notifPreview !== false);
  setToggleState('toggleAutoDownloadMedia', s.autoDownloadMedia !== false);
  setToggleState('toggleTypingIndicator', s.typingIndicator !== false);
  setToggleState('toggleLightMode', s.lightMode === true);
  applyBackgroundPreview('chatBgPreview', s.chatBackground);
  applyBackgroundPreview('appBgPreview', s.appBackground);
  renderVerifySecUI();
  renderPlatformThemePicker();
  renderMoodPicker();
}

/* ============ قسم التوثيق: لون العلامة + الإيموجي المميز ============ */
function renderVerifySecUI(){
  var lockedEl = document.getElementById('verifySecLocked');
  var contentEl = document.getElementById('verifySecContent');
  if(!lockedEl || !contentEl) return;
  var types = badgeTypeOf(currentProfile.isVerified);
  if(!types.length){
    lockedEl.style.display = 'block';
    contentEl.style.display = 'none';
    return;
  }
  lockedEl.style.display = 'none';
  contentEl.style.display = 'block';

  var activeColor = (currentProfile.activeBadgeColor && types.indexOf(currentProfile.activeBadgeColor)!==-1) ? currentProfile.activeBadgeColor : types[0];
  var colorPicker = document.getElementById('badgeColorPicker');
  colorPicker.innerHTML = Object.keys(BADGE_TYPES).map(function(type){
    var cfg = BADGE_TYPES[type];
    var owned = types.indexOf(type)!==-1;
    var isActive = owned && type===activeColor;
    return '<div class="badge-color-swatch'+(isActive?' active':'')+(owned?'':' locked')+'" style="color:'+cfg.color+'" title="'+cfg.title+(owned?'':' (مش متاح ليك)')+'" onclick="'+(owned?'saveActiveBadgeColor(\''+type+'\')':'')+'">'+
      '<i class="fa-solid fa-circle-check"></i>'+
      (owned?'':'<span class="lock-mini"><i class="fa-solid fa-lock"></i></span>')+
    '</div>';
  }).join('');

  var emojiPicker = document.getElementById('verifiedEmojiPicker');
  var activeEmoji = currentProfile.verifiedEmoji || '';
  emojiPicker.innerHTML = VERIFIED_EMOJIS.map(function(em){
    return '<div class="verified-emoji-opt'+(em===activeEmoji?' active':'')+'" onclick="saveVerifiedEmoji(\''+em+'\')">'+em+'</div>';
  }).join('');
}

window.saveActiveBadgeColor = async function(type){
  if(!BADGE_TYPES[type]) return;
  var types = badgeTypeOf(currentProfile.isVerified);
  if(types.indexOf(type)===-1) return; // مش متاح ليه
  currentProfile.activeBadgeColor = type;
  await rtdb.ref('users/'+currentUser.uid+'/activeBadgeColor').set(type);
  renderVerifySecUI();
  refreshMyProfileUI();
};

window.saveVerifiedEmoji = async function(em){
  if(!isCurrentUserVerified()) return;
  var newVal = (currentProfile.verifiedEmoji === em) ? null : em; // اضغط تاني عشان تشيله
  currentProfile.verifiedEmoji = newVal;
  await rtdb.ref('users/'+currentUser.uid+'/verifiedEmoji').set(newVal);
  renderVerifySecUI();
  refreshMyProfileUI();
};

/* ============ لون المنصة (تفضيل شخصي لكل مستخدم) ============ */
var PLATFORM_THEME_PRESETS = [
  { key:'classic', blue:'#1ED760', purple:'#9146FF' },
  { key:'violet',  blue:'#8A5CFF', purple:'#C13CFF' },
  { key:'gold',    blue:'#FFC94A', purple:'#FF7A00' },
  { key:'ocean',   blue:'#22D3EE', purple:'#2B95FF' },
  { key:'rose',    blue:'#FF5C8A', purple:'#FF2255' },
  { key:'mint',    blue:'#39FFB0', purple:'#12B886' }
];
function applyPlatformTheme(key){
  var preset = PLATFORM_THEME_PRESETS.find(function(p){ return p.key===key; }) || PLATFORM_THEME_PRESETS[0];
  document.documentElement.style.setProperty('--neon-blue', preset.blue);
  document.documentElement.style.setProperty('--neon-purple', preset.purple);
}
function renderPlatformThemePicker(){
  var el = document.getElementById('platformThemePicker');
  if(!el) return;
  var active = (currentProfile.settings && currentProfile.settings.platformTheme) || 'classic';
  el.innerHTML = PLATFORM_THEME_PRESETS.map(function(p){
    return '<div class="theme-color-swatch'+(p.key===active?' active':'')+'" style="background:linear-gradient(135deg,'+p.blue+','+p.purple+')" title="'+p.key+'" onclick="savePlatformTheme(\''+p.key+'\')"></div>';
  }).join('');
}
window.savePlatformTheme = async function(key){
  applyPlatformTheme(key);
  await saveSetting('platformTheme', key);
  renderPlatformThemePicker();
};

/* ============ هالة المزاج (ميزة حصرية) ============ */
var MOOD_OPTIONS = [
  { key:'', label:'من غير هالة', color:null },
  { key:'energetic', label:'نشيط', color:'#ff7a1a' },
  { key:'calm', label:'هادئ', color:'#2b95ff' },
  { key:'focused', label:'مركّز', color:'#9146FF' },
  { key:'party', label:'احتفال', color:'#ff4fa3' },
  { key:'busy', label:'مشغول', color:'#ff4d4d' },
  { key:'sleepy', label:'زعلان النوم', color:'#8a8a99' }
];
function applyMoodRing(elId, moodKey){
  var el = document.getElementById(elId);
  if(!el) return;
  var opt = MOOD_OPTIONS.find(function(o){ return o.key===moodKey; });
  if(opt && opt.color){
    el.dataset.mood = opt.key;
    el.style.setProperty('--mood-color', opt.color);
  }else{
    delete el.dataset.mood;
    el.style.removeProperty('--mood-color');
  }
}
function renderMoodPicker(){
  var el = document.getElementById('moodPicker');
  if(!el) return;
  var active = currentProfile.moodAura || '';
  el.innerHTML = MOOD_OPTIONS.map(function(o){
    var dotStyle = o.color ? 'background:'+o.color+';box-shadow:0 0 10px '+o.color : 'background:var(--card-bg2);display:flex;align-items:center;justify-content:center;color:var(--text-dim)';
    var dotInner = o.color ? '' : '<i class="fa-solid fa-ban" style="font-size:11px"></i>';
    return '<div class="mood-opt'+(o.key===active?' active':'')+'" onclick="saveMoodAura(\''+o.key+'\')"><div class="mood-dot" style="'+dotStyle+'">'+dotInner+'</div><span>'+o.label+'</span></div>';
  }).join('');
}
window.saveMoodAura = async function(key){
  currentProfile.moodAura = key || null;
  await rtdb.ref('users/'+currentUser.uid+'/moodAura').set(key || null);
  renderMoodPicker();
  applyMoodRing('myAvatar', key);
  applyMoodRing('headerAvatar', key);
};

function setToggleState(id, on){
  var el = document.getElementById(id);
  if(on) el.classList.add('on'); else el.classList.remove('on');
}

/* ============ الوضع الفاتح/الغامق (الغامق هو الافتراضي) ============ */
function applyColorMode(isLight){
  document.body.classList.toggle('light-mode', !!isLight);
}

/* ============ خلفيات الشات و التطبيق (من المعرض أو لون ثابت) ============ */
function applyBackgroundPreview(elId, value){
  var el = document.getElementById(elId);
  if(!el) return;
  if(value && value.indexOf('data:')===0){ el.style.backgroundImage = 'url(\''+value+'\')'; el.style.background=''; el.style.backgroundImage='url(\''+value+'\')'; el.style.backgroundSize='cover'; el.style.backgroundPosition='center'; el.innerHTML=''; }
  else if(value){ el.style.backgroundImage=''; el.style.background=value; el.innerHTML=''; }
  else{ el.style.backgroundImage=''; el.style.background='var(--card-bg2)'; el.innerHTML = elId==='chatBgPreview' ? '<i class="fa-solid fa-comment"></i>' : '<i class="fa-solid fa-mobile-screen"></i>'; }
}
function applyChatBackground(dataUrl){
  var messagesArea = document.getElementById('messagesArea');
  if(!messagesArea) return;
  if(dataUrl) messagesArea.style.backgroundImage = 'linear-gradient(rgba(0,0,0,.55),rgba(0,0,0,.55)), url(\''+dataUrl+'\')';
  else messagesArea.style.backgroundImage = '';
  messagesArea.style.backgroundSize = 'cover';
  messagesArea.style.backgroundPosition = 'center';
}
function applyAppBackground(value){
  var container = document.querySelector('.app-container');
  if(!container) return;
  if(value && value.indexOf('data:')===0){
    container.style.background = '';
    container.style.backgroundImage = 'linear-gradient(rgba(0,0,0,.6),rgba(0,0,0,.6)), url(\''+value+'\')';
    container.style.backgroundSize = 'cover';
    container.style.backgroundPosition = 'center';
    container.style.backgroundAttachment = 'fixed';
  }else if(value){
    container.style.backgroundImage = '';
    container.style.background = value;
  }else{
    container.style.backgroundImage = '';
    container.style.background = '';
  }
}
window.setAppBackgroundColor = async function(color){
  applyBackgroundPreview('appBgPreview', color);
  applyAppBackground(color);
  await saveSetting('appBackground', color);
};
window.handleBackgroundSelect = function(input, key){
  var file = input.files && input.files[0];
  if(!file) return;
  var reader = new FileReader();
  reader.onload = async function(e){
    var dataUrl = e.target.result;
    if(key==='chatBackground'){ applyBackgroundPreview('chatBgPreview', dataUrl); applyChatBackground(dataUrl); }
    else{ applyBackgroundPreview('appBgPreview', dataUrl); applyAppBackground(dataUrl); }
    await saveSetting(key, dataUrl);
  };
  reader.readAsDataURL(file);
  input.value = '';
};
window.removeBackground = async function(key){
  if(key==='chatBackground'){ applyBackgroundPreview('chatBgPreview', null); applyChatBackground(null); }
  else{ applyBackgroundPreview('appBgPreview', null); applyAppBackground(null); }
  await saveSetting(key, null);
};


window.toggleSetting = async function(key){
  var elId = 'toggle' + key.charAt(0).toUpperCase() + key.slice(1);
  var el = document.getElementById(elId);
  if(!el) return;
  var newVal = !el.classList.contains('on');
  setToggleState(elId, newVal);
  if(!currentProfile.settings) currentProfile.settings = {};
  currentProfile.settings[key] = newVal;
  if(key==='notifications' && newVal) requestNotifPermissionIfNeeded();
  if(key==='lightMode') applyColorMode(newVal);
  try{
    await rtdb.ref('users/'+currentUser.uid+'/settings/'+key).set(newVal);
  }catch(err){
    setToggleState(elId, !newVal); // ارجع للحالة القديمة لو فشل الحفظ
    alert('تعذر حفظ الإعداد، حاول تاني');
  }
};

window.saveSetting = async function(key, value){
  if(!currentProfile.settings) currentProfile.settings = {};
  currentProfile.settings[key] = value;
  try{
    await rtdb.ref('users/'+currentUser.uid+'/settings/'+key).set(value);
  }catch(err){
    alert('تعذر حفظ الإعداد، حاول تاني');
  }
};

window.saveDisplayName = async function(){
  var dn = document.getElementById('settingsDisplayName').value.trim();
  var about = document.getElementById('settingsAbout').value.trim();
  if(!dn){ alert('اكتب اسم صحيح'); return; }
  try{
    await rtdb.ref('users/'+currentUser.uid).update({displayName: dn, about: about || 'متاح حاليًا'});
    currentProfile.displayName = dn;
    currentProfile.about = about || 'متاح حاليًا';
    refreshMyProfileUI();
    alert('تم حفظ الملف الشخصي');
  }catch(err){
    alert('حصل خطأ أثناء حفظ الملف الشخصي، حاول تاني');
  }
};

window.changePassword = async function(){
  var curPass = document.getElementById('curPass').value;
  var newPass = document.getElementById('newPass').value;
  if(!curPass || !newPass) return alert('املأ الحقلين');
  if(newPass.length < 6) return alert('كلمة المرور الجديدة قصيرة جدًا');
  try{
    var cred = firebase.auth.EmailAuthProvider.credential(currentUser.email, curPass);
    await currentUser.reauthenticateWithCredential(cred);
    await currentUser.updatePassword(newPass);
    document.getElementById('curPass').value=''; document.getElementById('newPass').value='';
    alert('تم تغيير كلمة المرور بنجاح');
  }catch(err){
    alert(translateFirebaseError(err));
  }
};

window.deleteAccount = async function(){
  if(currentProfile && isProtectedAdminUser(currentProfile)){ alert('حساب الأدمن الأساسي محصّن ومينفعش يتحذف'); return; }
  if(!confirm('حذف الحساب نهائيًا؟ هتفقد كل بياناتك ومحادثاتك.')) return;
  var pass = prompt('اكتب كلمة المرور لتأكيد حذف الحساب:');
  if(!pass) return;
  try{
    var cred = firebase.auth.EmailAuthProvider.credential(currentUser.email, pass);
    await currentUser.reauthenticateWithCredential(cred);
    var uid = currentUser.uid;
    var usernameLower = currentProfile.usernameLower;
    await rtdb.ref('users/'+uid).remove();
    await rtdb.ref('usernames/'+usernameLower).remove();
    await rtdb.ref('userChats/'+uid).remove();
    await rtdb.ref('friends/'+uid).remove();
    await rtdb.ref('friendRequests/'+uid).remove();
    await rtdb.ref('blocked/'+uid).remove();
    await currentUser.delete();
  }catch(err){
    alert(translateFirebaseError(err));
  }
};
