/* ZYROX — chat/chat-window.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ START DIRECT CHAT ============ */
window.startDirectChat = async function(otherUid, otherUsername){
  document.getElementById('searchResults').classList.remove('active');
  document.getElementById('searchInput').value='';
  var ids = [currentUser.uid, otherUid].sort();
  var chatId = 'dm_'+ids[0]+'_'+ids[1];
  var snap = await rtdb.ref('chats/'+chatId).once('value');
  if(!snap.exists()){
    var memberNames = {}; memberNames[currentUser.uid]=currentProfile.displayName||currentProfile.username; memberNames[otherUid]=otherUsername;
    var members = {}; members[currentUser.uid]=true; members[otherUid]=true;
    await rtdb.ref('chats/'+chatId).set({
      type:'direct', members: members, memberNames: memberNames,
      createdAt: firebase.database.ServerValue.TIMESTAMP
    });
    await rtdb.ref('userChats/'+currentUser.uid+'/'+chatId).set(true);
    await rtdb.ref('userChats/'+otherUid+'/'+chatId).set(true);
  }
  window.openChat(chatId);
};

/* ============ AI CHAT ============ */
window.openAIChat = async function(){
  var chatId = 'ai_'+currentUser.uid;
  var snap = await rtdb.ref('chats/'+chatId).once('value');
  if(!snap.exists()){
    var members = {}; members[currentUser.uid]=true; members['ai-bot']=true;
    await rtdb.ref('chats/'+chatId).set({
      type:'ai', members: members, name:'ZYROX',
      createdAt: firebase.database.ServerValue.TIMESTAMP
    });
    await rtdb.ref('userChats/'+currentUser.uid+'/'+chatId).set(true);
  }
  window.openChat(chatId);
};

/* ============ OPEN / CLOSE CHAT ============ */
window.openChat = async function(chatId){
  clearMyTypingStatus();
  currentChatId = chatId;
  var cachedChat = chatsCache[chatId];
  currentChatData = cachedChat ? Object.assign({}, cachedChat) : null;

  document.getElementById('groupSettingsIcon').style.display='none';
  document.getElementById('blockIcon').style.display='none';
  document.getElementById('reportIcon').style.display='none';
  document.getElementById('deleteChatIcon').style.display='flex';
  document.getElementById('clearHistoryIcon').style.display='flex';
  document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer';
  var lockIconEl = document.getElementById('chatLockItemIcon');
  if(chatId !== MANDATORY_GROUP_ID){
    lockIconEl.style.display='flex';
    var isLockedNow = !!(currentProfile.lockedChats && currentProfile.lockedChats[chatId]);
    lockIconEl.innerHTML = isLockedNow ? '<i class="fa-solid fa-lock-open"></i>' : '<i class="fa-solid fa-lock"></i>';
  }else{
    lockIconEl.style.display='none';
  }

  // نفتح الشاشة فورًا ونعرض الرسايل المحفوظة على الجهاز من غير أي استنى للسيرفر
  if(currentChatData) paintChatHeaderQuick(currentChatData);
  document.getElementById('chatWindow').classList.add('active');
  listenMessages(chatId);

  if(!currentChatData){
    // أول مرة نفتح الشات ده (مفيش نسخة كاش)، لازم ننتظر السيرفر يعرّفنا نوعه
    var firstRes = await dbGetWithTimeout(rtdb.ref('chats/'+chatId), 15000);
    if(firstRes.timedOut || !firstRes.val){ document.getElementById('chatTitle').innerText = 'محادثة'; return; }
    currentChatData = Object.assign({id:chatId}, firstRes.val());
    paintChatHeaderQuick(currentChatData);
  }

  // تفاصيل إضافية (صورة/حالة الطرف التاني، بيانات البوت..) بتتحمل في الخلفية من غير ما تأخر ظهور الشات
  fillChatHeaderDetails(chatId, currentChatData);
};

function paintChatHeaderQuick(cd){
  var title, sub, isVerifiedOther=false;
  if(cd.type==='direct'){
    var otherUid = Object.keys(cd.members||{}).find(function(k){ return k!==currentUser.uid; });
    title = (cd.memberNames && cd.memberNames[otherUid]) || 'مستخدم';
    sub = 'محادثة خاصة';
    isVerifiedOther = cd.otherVerified;
    if(cd.otherPhoto){
      document.getElementById('chatAvatar').innerHTML='';
      document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer;background-image:url(\''+cd.otherPhoto+'\');background-size:cover;background-position:center';
    }else{
      document.getElementById('chatAvatar').innerHTML = esc(avatarLetter(title));
    }
    document.getElementById('blockIcon').style.display='flex';
    document.getElementById('reportIcon').style.display='flex';
  }else if(cd.type==='ai'){
    title = AI_BOT_NAME; sub = AI_BOT_ABOUT;
    isVerifiedOther = AI_BOT_VERIFIED;
    if(AI_PHOTO_URL){
      document.getElementById('chatAvatar').innerHTML='';
      document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer;background-image:url(\''+AI_PHOTO_URL+'\');background-size:cover;background-position:center';
    }else{
      document.getElementById('chatAvatar').innerHTML = '<i class="fa-solid fa-robot"></i>';
    }
  }else if(cd.type==='bot'){
    title = cd._botName || cd.name || 'بوت';
    sub = cd._botName ? 'بوت من ZYROXBOT' : 'بوت من ZYROXBOT';
    isVerifiedOther = cd._botVerified;
    if(cd._botPhoto){
      document.getElementById('chatAvatar').innerHTML='';
      document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer;background-image:url(\''+cd._botPhoto+'\');background-size:cover;background-position:center';
    }else{
      document.getElementById('chatAvatar').innerHTML = '<i class="fa-solid fa-microchip"></i>';
    }
  }else{
    title = cd.name;
    sub = Object.keys(cd.members||{}).length + ' أعضاء' + (cd.adminsOnly ? ' · الأدمن بس بيبعت' : '');
    if(cd.photoURL){
      document.getElementById('chatAvatar').innerHTML='';
      document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer;background-image:url(\''+cd.photoURL+'\');background-size:cover;background-position:center';
    }else{
      document.getElementById('chatAvatar').innerHTML = '<i class="fa-solid fa-users"></i>';
    }
    document.getElementById('groupSettingsIcon').style.display='flex';
  }
  document.getElementById('chatTitle').innerHTML = (cd.type==='direct'||cd.type==='bot'||cd.type==='ai') ? nameWithBadge(title, isVerifiedOther) : nameWithBadge(title||'', cd.isVerified);
  document.getElementById('chatSubtitle').innerText = sub||'';
  var canSendHere = true;
  if(cd.type==='group' && cd.adminsOnly){
    var iAmOwnerNow = cd.owner === currentUser.uid;
    var iAmAdminNow = !!(cd.admins && cd.admins[currentUser.uid]);
    canSendHere = iAmOwnerNow || iAmAdminNow;
  }
  document.getElementById('inputBar').style.display = canSendHere ? 'flex' : 'none';
  document.getElementById('inputBarLocked').style.display = canSendHere ? 'none' : 'flex';
  var badgeBtn = document.getElementById('badgeShareBtn');
  if(badgeBtn) badgeBtn.style.display = (cd.type==='direct' && isCurrentUserVerified()) ? 'flex' : 'none';
}

// بيحدد هل نعرض "بيكتب..." ولا نرجع لحالة الاتصال العادية، بناءً على وقت آخر إشعار كتابة وصل
// (فحص بالوقت مش بس بالحدث، عشان المؤشر يختفي لوحده لو مافيش تحديث جديد بدل ما يفضل عالق)
function updateTypingSubtitleDisplay(chatId){
  if(currentChatId!==chatId || !currentChatData || currentChatData.type!=='direct') return;
  var subtitleEl = document.getElementById('chatSubtitle');
  if(!subtitleEl) return;
  var isTypingNow = otherTypingTs && (Date.now() - otherTypingTs < 4000);
  var nextText = isTypingNow ? 'بيكتب...' : lastPresenceSubtitle;
  if(subtitleEl.innerText !== nextText) subtitleEl.innerText = nextText;
}

async function fillChatHeaderDetails(chatId, cd){
  try{
    if(cd.type==='direct'){
      var otherUid = Object.keys(cd.members).find(function(k){ return k!==currentUser.uid; });
      var oSnap = await rtdb.ref('users/'+otherUid).once('value');
      var oData = oSnap.val() || {};
      if(currentChatId!==chatId) return; // المستخدم فتح شات تاني قبل ما التفاصيل توصل
      if(oData.photoURL){
        document.getElementById('chatAvatar').innerHTML='';
        document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer;background-image:url(\''+oData.photoURL+'\');background-size:cover;background-position:center';
      }
      document.getElementById('chatTitle').innerHTML = nameWithBadge(cd.memberNames[otherUid], oData.isVerified);
      if(otherPresenceRef) otherPresenceRef.off();
      var privacy = (oData.settings && oData.settings.lastSeen) || 'everyone';
      var canSeePresence = privacy==='everyone' || (privacy==='friends' && friendsMap[otherUid]);
      if(canSeePresence){
        otherPresenceRef = rtdb.ref('presence/'+otherUid);
        otherPresenceRef.on('value', function(pSnap){
          var p = pSnap.val();
          if(currentChatData.type!=='direct') return;
          lastPresenceSubtitle = (p && p.online) ? 'متصل الآن' : fmtLastSeen(p && p.lastSeen);
          updateTypingSubtitleDisplay(chatId);
        });
      }
      if(otherTypingCheckInterval){ clearInterval(otherTypingCheckInterval); otherTypingCheckInterval=null; }
      if(otherTypingRef) otherTypingRef.off();
      otherTypingTs = 0;
      otherTypingRef = rtdb.ref('typing/'+chatId+'/'+otherUid);
      otherTypingRef.on('value', function(tSnap){
        if(currentChatId!==chatId || !currentChatData || currentChatData.type!=='direct') return;
        otherTypingTs = tSnap.val() || 0;
        updateTypingSubtitleDisplay(chatId);
      });
      // بنعمل فحص دوري بدل ما نعتمد بس على إشعار "خلاص وقف الكتابة"، عشان لو الطرف التاني قفل التاب
      // أو اتقفل عنده النت فجأة وماوصلش إشعار المسح، المؤشر يختفي لوحده بعد شوية ومايفضلش عالق
      otherTypingCheckInterval = setInterval(function(){ updateTypingSubtitleDisplay(chatId); }, 1000);
    }else if(cd.type==='bot'){
      var botSnap = await rtdb.ref('bots/'+cd.botId).once('value');
      var botData = botSnap.val() || {name:'بوت', about:'بوت من ZYROXBOT'};
      if(currentChatId!==chatId) return;
      document.getElementById('chatTitle').innerHTML = nameWithBadge(botData.name, botData.isVerified);
      document.getElementById('chatSubtitle').innerText = botData.disabled ? 'البوت متعطل حاليًا' : (botData.about || 'بوت من ZYROXBOT');
      if(botData.photoURL){
        document.getElementById('chatAvatar').innerHTML='';
        document.getElementById('chatAvatar').style.cssText='width:38px;height:38px;font-size:14px;cursor:pointer;background-image:url(\''+botData.photoURL+'\');background-size:cover;background-position:center';
      }
    }
  }catch(e){ /* أوفلاين - هنكتفي بالبيانات اللي ظهرت بالفعل */ }
}


/* حذف المحادثة من عندي بس — الطرف التاني (أو أعضاء الجروب) بتفضل المحادثة موجودة عندهم */
window.deleteCurrentChat = async function(){
  if(!currentChatId) return;
  if(currentChatId === MANDATORY_GROUP_ID){ alert('جروب ZYROX الرسمي مثبّت ومينفعش تمسحه'); return; }
  if(!confirm('تمسح المحادثة دي من عندك؟ (هتفضل موجودة عند الطرف التاني)')) return;
  var chatId = currentChatId;
  await rtdb.ref('userChats/'+currentUser.uid+'/'+chatId).remove();
  window.closeChat();
};

/* مسح سجل المحادثة (كل الرسايل) من عندي بس — الطرف التاني (أو أعضاء الجروب) بيفضل شايف الرسايل عنده */
window.clearChatHistory = async function(){
  if(!currentChatId) return;
  if(!confirm('هيتم مسح كل رسايل المحادثة دي من عندك بس (هتفضل موجودة عند الطرف التاني). الخطوة دي مش هترجع، متأكد؟')) return;
  var chatId = currentChatId;
  try{
    var snap = await rtdb.ref('messages/'+chatId).once('value');
    if(snap.exists()){
      var updates = {};
      Object.keys(snap.val()).forEach(function(mid){
        updates['messages/'+chatId+'/'+mid+'/hiddenFor/'+currentUser.uid] = true;
      });
      await rtdb.ref().update(updates);
    }
    messagesCache = {};
    document.getElementById('messagesArea').innerHTML = '<div class="empty-hint"><i class="fa-solid fa-comments"></i>ابدأ أول رسالة!</div>';
    showBlackToast('تم مسح سجل المحادثة');
  }catch(err){
    alert('تعذر مسح سجل المحادثة، حاول تاني');
  }
};

window.closeChat = function(){
  document.getElementById('chatWindow').classList.remove('active');
  if(messagesRef) messagesRef.off();
  if(otherPresenceRef) otherPresenceRef.off();
  if(otherTypingRef) otherTypingRef.off();
  if(otherTypingCheckInterval){ clearInterval(otherTypingCheckInterval); otherTypingCheckInterval=null; }
  otherTypingRef = null; otherTypingTs = 0;
  clearMyTypingStatus();
  currentChatId = null; currentChatData = null;
  document.getElementById('attachMenu').classList.remove('active');
  window.cancelReply();
};

/* ============ TYPING INDICATOR ============ */
// بنبعت وقت (timestamp) مش مجرد true/false، عشان لو الجهاز قفل الشاشة أو التاب راح بالخلفية
// ومنفعش نبعت إشعار "وقفت الكتابة" بسبب إن المتصفح بيوقف التايمرز، الطرف التاني هيعتمد على
// فرق الوقت بس وهيلاقي المؤشر بيختفي لوحده تلقائيًا (شوف updateTypingSubtitleDisplay) بدل ما يفضل عالق
window.handleTypingInput = function(){
  if(!currentChatId || !currentChatData || currentChatData.type!=='direct') return;
  if(currentProfile && currentProfile.settings && currentProfile.settings.typingIndicator===false) return;
  var text = document.getElementById('messageInput').value;
  if(myTypingClearTimer){ clearTimeout(myTypingClearTimer); myTypingClearTimer=null; }
  if(text.trim()){
    var now = Date.now();
    if(!myTypingSessionActive || (now - myTypingLastWriteTs) > 1500){
      myTypingSessionActive = true;
      myTypingLastWriteTs = now;
      var tRef = rtdb.ref('typing/'+currentChatId+'/'+currentUser.uid);
      tRef.set(firebase.database.ServerValue.TIMESTAMP);
      tRef.onDisconnect().remove();
    }
    myTypingClearTimer = setTimeout(clearMyTypingStatus, 2500);
  }else{
    clearMyTypingStatus();
  }
};
function clearMyTypingStatus(){
  if(myTypingClearTimer){ clearTimeout(myTypingClearTimer); myTypingClearTimer=null; }
  if(myTypingSessionActive){
    myTypingSessionActive = false;
    if(currentChatId) rtdb.ref('typing/'+currentChatId+'/'+currentUser.uid).remove();
  }
}

function closePanelsAbove(){ document.getElementById('attachMenu').classList.remove('active'); }
window.closePanel = function(id){ document.getElementById(id).classList.remove('active'); };

/* ============ MESSAGES ============ */
function loadCachedMessages(chatId){
  try{ return JSON.parse(localStorage.getItem('exe_msgs_'+chatId) || '[]'); }catch(e){ return []; }
}
function saveCachedMessages(chatId, list){
  try{ localStorage.setItem('exe_msgs_'+chatId, JSON.stringify(list.slice(-60))); }catch(e){}
}
function listenMessages(chatId){
  if(messagesRef) messagesRef.off();
  window.cancelReply();
  var area = document.getElementById('messagesArea');
  area.innerHTML = ''; // نمسح رسايل الشات القديم فورًا عشان مايفضلش ظاهر لما نفتح شات تاني

  // نعرض النسخة المحفوظة على الجهاز فورًا (لو موجودة) عشان الرسايل تظهر حتى وإحنا أوفلاين
  var cachedList = loadCachedMessages(chatId);
  var liveList = cachedList.slice();
  if(cachedList.length){
    cachedList.forEach(function(m){ messagesCache[m.key] = m.val; renderMessage(m.key, m.val); });
    area.scrollTop = area.scrollHeight;
  }

  messagesRef = rtdb.ref('messages/'+chatId).limitToLast(100);
  var first = !cachedList.length;
  messagesRef.on('child_added', function(snap){
    if(first){ first=false; }
    var v = snap.val();
    messagesCache[snap.key] = v;
    var already = document.querySelector('.msg-row[data-msg-id="'+snap.key+'"]');
    if(!already){ renderMessage(snap.key, v); area.scrollTop = area.scrollHeight; }
    markMessageReadIfNeeded(chatId, snap.key, v);
    markChatRead(chatId);
    var idx = -1;
    for(var i=0;i<liveList.length;i++){ if(liveList[i].key===snap.key){ idx=i; break; } }
    if(idx===-1) liveList.push({key:snap.key, val:v}); else liveList[idx] = {key:snap.key, val:v};
    saveCachedMessages(chatId, liveList);
  });
  messagesRef.on('child_changed', function(snap){
    var v = snap.val();
    messagesCache[snap.key] = v;
    var row = document.querySelector('.msg-row[data-msg-id="'+snap.key+'"]');
    var idx2 = -1;
    for(var j=0;j<liveList.length;j++){ if(liveList[j].key===snap.key){ idx2=j; break; } }
    if(idx2!==-1){ liveList[idx2] = {key:snap.key, val:v}; saveCachedMessages(chatId, liveList); }
    if(v.hiddenFor && v.hiddenFor[currentUser.uid]){
      if(row) row.remove();
      return;
    }
    if(v.deletedForEveryone){
      if(row) row.querySelector('.msg-bubble').innerHTML = '<div class="msg-deleted"><i class="fa-solid fa-ban"></i> تم حذف هذه الرسالة</div>';
      return;
    }
    var el = document.getElementById('reactions_'+snap.key);
    if(el) el.innerHTML = renderReactionsHTML(v.reactions);
    var tEl = document.getElementById('ticks_'+snap.key);
    if(tEl) tEl.outerHTML = renderTicksHTML(snap.key, v);
    markMessageReadIfNeeded(chatId, snap.key, v);
  });
  messagesRef.once('value', function(snap){ if(!snap.exists() && !cachedList.length) area.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-comments"></i>ابدأ أول رسالة!</div>'; });
  markChatRead(chatId);
}

/* ============ READ RECEIPTS ============ */
function markMessageReadIfNeeded(chatId, msgId, m){
  if(!m || m.senderId === currentUser.uid) return; // بس الرسايل الجايالي من التاني
  if(m.status === 'read') return;
  if(currentProfile.settings && currentProfile.settings.readReceipts===false) return; // مقفول من الخصوصية
  if(currentChatData && (currentChatData.type==='direct' || currentChatData.type==='group')){
    rtdb.ref('messages/'+chatId+'/'+msgId+'/status').set('read');
  }
}

var markChatReadTimers = {};
function markChatRead(chatId){
  // تحديث فوري للعداد في القائمة (من غير ما ننتظر رد السيرفر) عشان يختفي في نفس اللحظة اللي بتفتح فيها الشات
  if(chatsCache[chatId] && chatsCache[chatId]._unread){
    chatsCache[chatId]._unread = 0;
    renderChatsListFromCache();
  }
  if(markChatReadTimers[chatId]) clearTimeout(markChatReadTimers[chatId]);
  markChatReadTimers[chatId] = setTimeout(function(){
    rtdb.ref('lastRead/'+currentUser.uid+'/'+chatId).set(firebase.database.ServerValue.TIMESTAMP);
  }, 400);
}

function renderTicksHTML(id, m){
  if(!m.senderId || m.senderId !== currentUser.uid) return '';
  if(!currentChatData || (currentChatData.type!=='direct' && currentChatData.type!=='group')) return '';
  var status = m.status || 'sent';
  var cls = status==='read' ? 'msg-ticks read' : 'msg-ticks';
  var icon = status==='sent' ? '<i class="fa-solid fa-check"></i>' : '<i class="fa-solid fa-check-double"></i>';
  return '<span class="'+cls+'" id="ticks_'+id+'">'+icon+'</span>';
}

function renderReactionsHTML(reactions){
  if(!reactions) return '';
  var groups = {};
  Object.keys(reactions).forEach(function(uid){
    var r = reactions[uid];
    if(!r || !r.emoji) return;
    if(!groups[r.emoji]) groups[r.emoji] = {count:0, paidTotal:0};
    groups[r.emoji].count++;
    if(r.paid) groups[r.emoji].paidTotal += (r.amount||0);
  });
  return Object.keys(groups).map(function(e){
    var g = groups[e];
    var extra = g.paidTotal>0 ? ' <b>+'+g.paidTotal+' ZYROX</b>' : (g.count>1 ? ' '+g.count : '');
    var visual = e;
    if(e.indexOf('badge:')===0){
      var t = e.split(':')[1];
      var cfg = BADGE_TYPES[t] || BADGE_TYPES.red;
      visual = '<i class="fa-solid fa-circle-check" style="color:'+cfg.color+'"></i>';
    }
    return '<span class="reaction-chip'+(g.paidTotal>0?' paid':'')+'">'+visual+extra+'</span>';
  }).join('');
}

/* بترتب رسايل الشات حسب الوقت الفعلي (timestamp) مش حسب ترتيب وصولها، عشان لو رسالة
   وصلت متأخرة (بسبب نت بطيء، كاش قديم، أو فرق بسيط في ساعة السيرفر) تتحط في مكانها
   الصح جوه المحادثة بدل ما تتحط في الآخر وتخربط ترتيب الشات */
function insertMsgRowSorted(area, row, ts){
  row.dataset.ts = ts || 0;
  var rows = area.querySelectorAll('.msg-row');
  for(var i=rows.length-1; i>=0; i--){
    var otherTs = parseFloat(rows[i].dataset.ts) || 0;
    if(otherTs <= row.dataset.ts){
      rows[i].insertAdjacentElement('afterend', row);
      return;
    }
  }
  area.insertBefore(row, area.firstChild);
}

function renderMessage(id, m){
  var area = document.getElementById('messagesArea');
  if(area.querySelector('.empty-hint')) area.innerHTML='';
  if(m.hiddenFor && m.hiddenFor[currentUser.uid]) return; // اتمسحت لدي فقط
  var sent = m.senderId === currentUser.uid;
  var row = document.createElement('div');
  row.className = 'msg-row ' + (sent?'sent':'received');
  row.dataset.msgId = id;
  if(m.deletedForEveryone){
    row.innerHTML = '<div class="msg-bubble"><div class="msg-deleted"><i class="fa-solid fa-ban"></i> تم حذف هذه الرسالة</div></div>';
    insertMsgRowSorted(area, row, m.timestamp);
    return;
  }
  if(m.type==='sticker'){
    row.className += ' msg-row-sticker';
    row.innerHTML = '<div class="msg-bubble sticker-bubble"><div class="sticker-emoji">'+esc(m.stickerEmoji||'🙂')+'</div>'+
      '<div class="msg-time sticker-time">'+fmtTime(m.timestamp)+renderTicksHTML(id, m)+'</div></div>';
    insertMsgRowSorted(area, row, m.timestamp);
    attachSwipeToReply(row, id, m);
    return;
  }
  var inner = '';
  if(!sent && currentChatData && currentChatData.type!=='direct') inner += '<div class="msg-sender">'+esc(m.senderName||'')+'</div>';
  if(m.replyTo){
    inner += '<div class="msg-quote" onclick="scrollToMessage(\''+m.replyTo.id+'\')"><div class="mq-line"></div><div class="mq-info"><h6>'+esc(m.replyTo.senderName||'')+'</h6><p>'+esc(m.replyTo.text||'')+'</p></div></div>';
  }
  if(m.type==='text'){
    inner += esc(m.text);
  }else if(m.type==='capsule'){
    var isUnlocked = Date.now() >= m.unlockAt;
    if(isUnlocked){
      row.dataset.capsuleLocked = '0';
      inner += '<div class="capsule-msg capsule-unlock-burst"><i class="fa-solid fa-box-open"></i><div>'+esc(m.text)+'</div><div class="capsule-countdown"><i class="fa-solid fa-lock-open"></i> اتفتحت</div></div>';
    }else{
      row.dataset.capsuleLocked = '1';
      var msLeft = m.unlockAt - Date.now();
      var label = msLeft > 3600000 ? Math.ceil(msLeft/3600000)+' ساعة' : Math.ceil(msLeft/60000)+' دقيقة';
      inner += '<div class="capsule-msg" onclick="event.stopPropagation();tryOpenCapsule(\''+id+'\')"><i class="fa-solid fa-hourglass-half"></i><div>كبسولة وقت مقفولة 🔒</div><div class="capsule-countdown">هتتفتح بعد '+label+'</div></div>';
    }
  }else if(m.type==='image'){
    if(m.viewOnce){
      if(m.viewed){
        inner += '<div class="view-once-opened"><i class="fa-solid fa-eye-slash"></i><br>تم مشاهدة الصورة</div>';
      }else{
        inner += '<div class="view-once-wrap" onclick="openViewOnce(\''+id+'\',this)"><i class="fa-solid fa-eye"></i><span>صورة تُشاهد مرة واحدة</span></div>';
      }
    }else{
      inner += '<img src="'+m.mediaData+'" onclick="event.stopPropagation();openMediaViewer(\''+id+'\')">';
    }
  }else if(m.type==='gift'){
    var g = findGiftByKey(m.giftKey) || {emoji:'🎁'};
    var giftVisual = g.imageData ? '<img src="'+g.imageData+'" style="width:60px;height:60px;border-radius:10px;object-fit:cover">' : '<span class="gemoji">'+g.emoji+'</span>';
    inner += '<div class="gift-bubble">'+giftVisual+'<div class="glabel">🎁 '+esc(m.giftLabel||'هدية')+' — '+(m.giftPrice||0)+' ZYROX</div>';
    if(!sent && !m.giftResolved){
      inner += '<div style="display:flex;gap:6px;justify-content:center;margin-top:8px">'+
        '<button class="small-btn filled" onclick="resolveGift(\''+id+'\',\'keep\')">احتفظ بيها في البروفايل</button>'+
        '<button class="small-btn" onclick="resolveGift(\''+id+'\',\'convert\')">حوّلها لـ ZYROX</button>'+
      '</div>';
    }else if(m.giftResolved){
      inner += '<div class="glabel">'+(m.giftAction==='converted' ? '✅ اتحولت لرصيد ZYROX' : '✅ في البروفايل')+'</div>';
    }
    inner += '</div>';
  }else if(m.type==='badgeShare'){
    var bt = BADGE_TYPES[m.badgeType] || BADGE_TYPES.red;
    var viewerVerified = isCurrentUserVerified();
    var protectAttrs = viewerVerified ? '' : ' oncopy="return false" oncontextmenu="return false" onselectstart="return false" style="user-select:none;-webkit-user-select:none"';
    inner += '<div class="badge-share-bubble" style="text-align:center;padding:10px 6px"'+protectAttrs+'>'+
      '<i class="fa-solid fa-circle-check" style="font-size:36px;color:'+bt.color+';text-shadow:0 0 10px '+bt.color+'"></i>'+
      '<div style="font-size:12px;margin-top:6px;color:var(--text-dim)">'+esc(m.senderName||'')+' بعتلك شارة التوثيق بتاعته 🎖️</div>'+
      (viewerVerified ? '' : '<div style="font-size:10px;margin-top:4px;color:var(--warn)"><i class="fa-solid fa-lock"></i> متاحة للنسخ للموثّقين بس</div>')+
    '</div>';
  }else if(m.type==='video'){
    inner += '<div class="msg-video-wrap" onclick="event.stopPropagation();openMediaViewer(\''+id+'\')"><video playsinline preload="metadata" webkit-playsinline="true" muted src="'+m.mediaData+'"></video>'+
      '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#fff;font-size:34px;text-shadow:0 2px 8px rgba(0,0,0,.6);pointer-events:none"><i class="fa-solid fa-circle-play"></i></div>'+
      '<a class="msg-video-save" href="'+m.mediaData+'" download="video.mp4" title="حفظ الفيديو" onclick="event.stopPropagation()"><i class="fa-solid fa-download"></i></a></div>';
  }else if(m.type==='voice'){
    inner += '<audio controls src="'+m.mediaData+'"></audio>';
  }else if(m.type==='file'){
    inner += '<a class="msg-file" href="'+m.mediaData+'" download="'+esc(m.fileName||'file')+'"><i class="fa-solid fa-file"></i><span>'+esc(m.fileName||'ملف')+'</span></a>';
  }
  if(m.buttons && m.buttons.length){
    inner += '<div class="bot-btns">'+m.buttons.map(function(b){
      return '<button onclick="sendQuickCommand(\''+esc(b.command).replace(/'/g,"\\'")+'\')">'+esc(b.label)+'</button>';
    }).join('')+'</div>';
  }
  inner += '<div class="msg-time"><i class="fa-solid fa-ellipsis msg-more-trigger" onclick="openMessageActions(\''+id+'\')"></i><i class="fa-regular fa-face-smile react-trigger" onclick="openReactionPicker(\''+id+'\')"></i>'+fmtTime(m.timestamp)+renderTicksHTML(id, m)+'</div>';
  inner += '<div class="msg-reactions" id="reactions_'+id+'">'+renderReactionsHTML(m.reactions)+'</div>';
  row.innerHTML = '<div class="msg-bubble">'+inner+'</div>';
  attachSwipeToReply(row, id, m);
  insertMsgRowSorted(area, row, m.timestamp);
}

/* ============ SWIPE TO REPLY ============ */
function attachSwipeToReply(row, id, m){
  var startX=0, startY=0, dx=0, dragging=false, triggered=false;
  row.addEventListener('touchstart', function(e){
    startX = e.touches[0].clientX; startY = e.touches[0].clientY;
    dragging = true; triggered = false;
  }, {passive:true});
  row.addEventListener('touchmove', function(e){
    if(!dragging) return;
    dx = e.touches[0].clientX - startX;
    var dy = e.touches[0].clientY - startY;
    if(Math.abs(dy) > Math.abs(dx)) return; // scroll vertically, ignore
    row.classList.add('swiping');
    var clamped = Math.max(-70, Math.min(70, dx));
    row.style.transform = 'translateX('+clamped+'px)';
    if(Math.abs(clamped) > 55 && !triggered){
      triggered = true;
      if(navigator.vibrate) navigator.vibrate(15);
    }
  }, {passive:true});
  row.addEventListener('touchend', function(){
    dragging = false;
    row.classList.remove('swiping');
    row.style.transform = '';
    if(triggered) startReply(id, m);
    dx = 0;
  });
}

window.startReply = function(id, m){
  var previewText = m.type==='text' ? m.text : ({image:'📷 صورة',video:'🎥 فيديو',voice:'🎙️ رسالة صوتية',file:'📎 ملف',gift:'🎁 هدية',badgeShare:'🎖️ شارة توثيق'}[m.type] || '');
  replyingTo = { id: id, senderName: (m.senderId===currentUser.uid ? 'أنت' : (m.senderName||'مستخدم')), text: previewText };
  document.getElementById('rpName').innerText = 'الرد على ' + replyingTo.senderName;
  document.getElementById('rpText').innerText = previewText;
  document.getElementById('replyPreviewBar').style.display = 'flex';
  document.getElementById('messageInput').focus();
};

window.cancelReply = function(){
  replyingTo = null;
  document.getElementById('replyPreviewBar').style.display = 'none';
};

window.scrollToMessage = function(id){
  var el = document.querySelector('.msg-row[data-msg-id="'+id+'"]');
  if(!el) return;
  el.scrollIntoView({behavior:'smooth', block:'center'});
  el.style.outline = '1px solid var(--neon-blue)';
  setTimeout(function(){ el.style.outline=''; }, 900);
};

window.sendQuickCommand = function(cmd){
  document.getElementById('messageInput').value = cmd;
  sendTextMessage();
};

async function pushMessage(chatId, msgData){
  // ملحوظة: مبقناش بنمنع الإرسال لمجرد إن isOnline لسه معمول له تحديث متأخر (كان بيسبب فقد رسايل/هدايا
  // فعليًا متصلة بالنت لكن العلم لسه ماتغيرش). فايربيز نفسه بيخزن الكتابة محليًا ويبعتها أول ما النت يرجع.
  if(msgData.type==='text' && messageHasBannedWord(msgData.text)){
    alert('الرسالة فيها كلمة ممنوعة، غيّرها وابعتها تاني');
    return;
  }
  if(msgData.type==='text'){
    // لو هو نفسه قال جملة من جمل الباند تاني، ده بيفك القفل اللي بيمنع تكرار حظره بنفس الجملة دي
    var saidPhraseKey = messageMatchesBanTrigger(msgData.text);
    if(saidPhraseKey){
      rtdb.ref('banPhraseState/'+currentUser.uid+'/'+saidPhraseKey+'/lastUsedAt').set(firebase.database.ServerValue.TIMESTAMP);
    }
  }
  try{
    if(currentChatData && currentChatData.type==='direct'){
      var otherUid = Object.keys(currentChatData.members).find(function(k){ return k!==currentUser.uid; });
      // ملحوظة: مبقناش بنحاول نقرا قايمة الحظر الخاصة بالطرف التاني (blocked/otherUid/...) لأن ده بيانات
      // خاصة بيه، وقواعد الحماية في فايربيز غالبًا بترفض القراءة دي، وده كان بيوقف إرسال أي رسالة فردية
      // (الجروبات مش بتعمل الشيك ده فكانت شغالة عادي). دلوقتي بنكتفي بالشيك اللي عندي على حظري أنا ليه.
      if(blockedMap[otherUid]){ alert('انت حاظر المستخدم ده، لازم تلغي الحظر الأول'); return; }
    }
    if(currentChatData && currentChatData.type==='group' && currentChatData.adminsOnly){
      var iAmOwner = currentChatData.owner === currentUser.uid;
      var iAmAdmin = !!(currentChatData.admins && currentChatData.admins[currentUser.uid]);
      if(!iAmOwner && !iAmAdmin){ alert('الأدمن بس هو اللي يقدر يبعت رسايل في الجروب ده دلوقتي'); return; }
    }
    var ref = rtdb.ref('messages/'+chatId).push();
    var displayName = currentProfile.displayName || currentProfile.username;
    var payload = Object.assign({}, msgData, { senderId: currentUser.uid, senderName: displayName, timestamp: firebase.database.ServerValue.TIMESTAMP });
    if(replyingTo){ payload.replyTo = replyingTo; window.cancelReply(); }
    await ref.set(payload);
    var preview = msgData.type==='text' ? msgData.text : ({image:'📷 صورة',video:'🎥 فيديو',voice:'🎙️ رسالة صوتية',file:'📎 ملف',gift:'🎁 هدية',badgeShare:'🎖️ شارة توثيق',sticker:(msgData.stickerEmoji||'🙂')+' ملصق',capsule:'⏳ كبسولة وقت'}[msgData.type]);
    await rtdb.ref('chats/'+chatId).update({ lastMessage: preview, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastMessageId: ref.key, lastMessageSenderId: currentUser.uid });
    await rtdb.ref('userChats/'+currentUser.uid+'/'+chatId).set(true);
  }catch(err){
    alert('تعذر إرسال الرسالة، تأكد من الاتصال بالإنترنت وحاول تاني');
  }
}

window.sendTextMessage = function(){
  var input = document.getElementById('messageInput');
  var text = input.value.trim();
  if(!text || !currentChatId) return;
  if(messageHasBannedWord(text)){ alert('الرسالة فيها كلمة ممنوعة، غيّرها وابعتها تاني'); return; }
  input.value='';
  clearMyTypingStatus();
  var isAI = currentChatData.type==='ai';
  var isBot = currentChatData.type==='bot';
  var botIdAtSend = currentChatData.botId;
  pushMessage(currentChatId, {type:'text', text: text});
  if(isAI) handleAIReply(text);
  if(isBot) handleBotReply(text, botIdAtSend);
};
