/* ZYROX — chat/lock-and-notifications.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ CHAT LOCK (PIN) ============ */
function showBlackToast(msg){
  var el = document.getElementById('blackToast');
  if(!el){ alert(msg); return; }
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(window._blackToastTimer);
  window._blackToastTimer = setTimeout(function(){ el.classList.remove('show'); }, 3200);
}

/* ============ NOTIFICATIONS ============ */
function showNotifBanner(chatId, title, sub){
  var el = document.getElementById('notifBanner');
  if(!el) return;
  document.getElementById('nbTitle').textContent = title;
  document.getElementById('nbSub').textContent = sub;
  el.onclick = function(){ el.classList.remove('show'); if(chatId) window.openChat(chatId); };
  el.classList.add('show');
  clearTimeout(window._notifBannerTimer);
  window._notifBannerTimer = setTimeout(function(){ el.classList.remove('show'); }, 4200);
  if(currentProfile.settings && currentProfile.settings.sound !== false) playNotifSound();
  if('Notification' in window && Notification.permission==='granted' && document.hidden){
    // نفضّل نعرض الإشعار عن طريق الـ Service Worker (أكتر ثباتًا وقت ما الصفحة تبقى في الخلفية على الموبايل)
    if('serviceWorker' in navigator && navigator.serviceWorker.controller){
      navigator.serviceWorker.ready.then(function(reg){
        reg.showNotification(title, {body: sub, icon: 'icon.png'}).catch(function(){
          try{ new Notification(title, {body: sub}); }catch(e){}
        });
      });
    }else{
      try{ new Notification(title, {body: sub}); }catch(e){}
    }
  }
}
function playNotifSound(){
  try{
    var ctx = window._notifAudioCtx || (window._notifAudioCtx = new (window.AudioContext||window.webkitAudioContext)());
    var o = ctx.createOscillator(), g = ctx.createGain();
    o.type='sine'; o.frequency.value=880;
    g.gain.setValueAtTime(0.001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime+0.01);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime+0.22);
    o.connect(g); g.connect(ctx.destination);
    o.start(); o.stop(ctx.currentTime+0.24);
  }catch(e){}
}
function requestNotifPermissionIfNeeded(){
  if('Notification' in window && Notification.permission==='default') Notification.requestPermission();
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js').catch(function(e){ /* ملف sw.js لازم يكون مرفوع جنب صفحة الموقع */ });
  }
}

function simpleHashPin(pin){
  var hash = 0;
  for(var i=0;i<pin.length;i++){ hash = ((hash<<5) - hash) + pin.charCodeAt(i); hash |= 0; }
  return 'h' + hash;
}

function enterAppAfterUnlock(){
  document.getElementById('chatLockScreen').style.display='none';
  document.getElementById('appContainer').style.display='flex';
  document.getElementById('adminMenuItem').style.display = currentProfile.isAdmin ? 'flex' : 'none';
  refreshMyProfileUI();
  loadUserChats();
  ensureOfficialGroupMembership();
  listenFriendRequests();
  listenFriendsList();
  listenBlockedList();
  listenAnnouncements();
  listenProfileGifts();
  listenCustomGifts();
  listenAIConfig();
  listenSiteConfig();
  listenBanTriggerPhrases();
  listenUnbanTriggerPhrases();
  listenVerifyTriggerPhrases();
  listenBalanceTriggerPhrases();
  listenSavedStickers();
  setupPresence(currentUser.uid);
  listenExeBalance(currentUser.uid);
  initSupportListeners();
  handleSharedVideoDeepLink();
}

window.submitChatLockPin = function(){
  var input = document.getElementById('chatLockPinInput');
  var pin = input.value.trim();
  var errEl = document.getElementById('chatLockError');
  if(!pin){ errEl.textContent = 'اكتب الرقم السري'; return; }
  if(simpleHashPin(pin) === currentProfile.chatLock.pin){
    errEl.textContent = '';
    enterAppAfterUnlock();
  }else{
    errEl.textContent = 'الرقم غلط، جرب تاني';
    input.value=''; input.focus();
  }
};

window.toggleChatLockFeature = async function(checked){
  if(checked){
    if(!currentProfile.chatLock || !currentProfile.chatLock.pin){
      var ok = await setChatLockPinFlow();
      if(!ok){ document.getElementById('chatLockToggle').checked = false; return; }
    }else{
      await rtdb.ref('users/'+currentUser.uid+'/chatLock/enabled').set(true);
      currentProfile.chatLock.enabled = true;
    }
  }else{
    await rtdb.ref('users/'+currentUser.uid+'/chatLock/enabled').set(false);
    if(currentProfile.chatLock) currentProfile.chatLock.enabled = false;
  }
};

async function setChatLockPinFlow(){
  var pin = prompt('اكتب رقم سري من 4 إلى 8 أرقام:');
  if(pin===null) return false;
  pin = pin.trim();
  if(!/^\d{4,8}$/.test(pin)){ alert('الرقم السري لازم يكون من 4 إلى 8 أرقام بس'); return false; }
  var confirmPin = prompt('اكتب الرقم السري تاني للتأكيد:');
  if(confirmPin===null) return false;
  if(confirmPin.trim() !== pin){ alert('الرقمين مش متطابقين، حاول تاني'); return false; }
  await rtdb.ref('users/'+currentUser.uid+'/chatLock').set({ enabled:true, pin: simpleHashPin(pin) });
  currentProfile.chatLock = { enabled:true, pin: simpleHashPin(pin) };
  alert('تم تفعيل قفل الشاتات بنجاح');
  return true;
}

window.promptSetChatLockPin = async function(){
  var ok = await setChatLockPinFlow();
  if(ok){ document.getElementById('chatLockToggle').checked = true; }
};

window.disableChatLockCompletely = async function(){
  if(!currentProfile.chatLock || !currentProfile.chatLock.pin){ alert('قفل الشاتات مش مفعّل أصلاً'); return; }
  if(!confirm('متأكد إنك عايز تلغي قفل الشاتات؟ هيتشال الرقم السري خالص ومش هتحتاج تدخله تاني.')) return;
  try{
    await rtdb.ref('users/'+currentUser.uid+'/chatLock').remove();
    currentProfile.chatLock = null;
    var toggle = document.getElementById('chatLockToggle');
    if(toggle) toggle.checked = false;
    var lockIconEl = document.getElementById('chatLockItemIcon');
    if(lockIconEl){ lockIconEl.style.display='none'; lockIconEl.innerHTML = '<i class="fa-solid fa-lock"></i>'; }
    alert('تم إلغاء قفل الشاتات بنجاح');
  }catch(err){
    alert('تعذر إلغاء القفل، حاول تاني');
  }
};

/* ============ CHAT-LEVEL LOCK (اخفاء محادثة معينة وراء الرقم السري) ============ */
window.toggleCurrentChatLock = async function(){
  if(!currentChatId) return;
  if(!currentProfile.chatLock || !currentProfile.chatLock.pin){
    var ok = await setChatLockPinFlow();
    if(!ok) return;
  }
  var isLockedNow = !!(currentProfile.lockedChats && currentProfile.lockedChats[currentChatId]);
  if(!isLockedNow){
    await rtdb.ref('users/'+currentUser.uid+'/lockedChats/'+currentChatId).set(true);
    if(!currentProfile.lockedChats) currentProfile.lockedChats = {};
    currentProfile.lockedChats[currentChatId] = true;
    document.getElementById('chatLockItemIcon').innerHTML = '<i class="fa-solid fa-lock-open"></i>';
    showBlackToast('المحادثة اتقفلت، هتلاقيها بالبحث بالرقم السري بس');
    renderChatsListFromCache();
  }else{
    await rtdb.ref('users/'+currentUser.uid+'/lockedChats/'+currentChatId).remove();
    if(currentProfile.lockedChats) delete currentProfile.lockedChats[currentChatId];
    document.getElementById('chatLockItemIcon').innerHTML = '<i class="fa-solid fa-lock"></i>';
    showBlackToast('المحادثة اتفتحت وبقت ظاهرة تاني في القايمة');
    renderChatsListFromCache();
  }
};

function listenExeBalance(uid){
  if(exeBalanceRef) exeBalanceRef.off();
  exeBalanceRef = rtdb.ref('users/'+uid+'/exeCoins');
  exeBalanceRef.on('value', function(snap){
    currentProfile.exeCoins = snap.val() || 0;
    var walletEl = document.getElementById('walletBalance');
    if(walletEl) walletEl.innerText = currentProfile.exeCoins + ' ZYROX';
    updateHeaderBalanceChip();
  });
}

function updateHeaderBalanceChip(){
  var chipText = document.getElementById('headerBalanceText');
  if(chipText) chipText.innerText = (currentProfile.exeCoins||0);
  var menuChipText = document.getElementById('menuBalanceText');
  if(menuChipText) menuChipText.innerText = (currentProfile.exeCoins||0);
}

function setupPresence(uid){
  var myPresenceRef = rtdb.ref('presence/'+uid);
  rtdb.ref('.info/connected').on('value', function(snap){
    if(snap.val()===true){
      myPresenceRef.onDisconnect().set({ online:false, lastSeen: firebase.database.ServerValue.TIMESTAMP }).then(function(){
        myPresenceRef.set({ online:true, lastSeen: firebase.database.ServerValue.TIMESTAMP });
      });
    }
  });
}

function setupConnectivityWatcher(){
  var banner = document.getElementById('offlineBanner');
  var dot = document.getElementById('connStatusDot');
  var txt = document.getElementById('connStatusText');
  var offlineTimer = null;
  var pingTimer = null;
  function measureSpeed(){
    var t0 = Date.now();
    rtdb.ref('.info/serverTimeOffset').once('value').then(function(){
      var ms = Date.now() - t0;
      if(!isOnline) return;
      if(dot) dot.style.color = 'var(--neon-blue)';
      if(txt) txt.innerText = ms<300 ? 'متصل (سريع)' : (ms<1200 ? 'متصل' : 'متصل (بطيء)');
    }).catch(function(){});
  }
  function setOnlineImmediate(val){
    isOnline = val;
    if(banner) banner.style.display = val ? 'none' : 'flex';
    if(val){
      measureSpeed();
      if(pingTimer) clearInterval(pingTimer);
      pingTimer = setInterval(measureSpeed, 20000);
    }else{
      if(dot) dot.style.color = 'var(--danger)';
      if(txt) txt.innerText = 'غير متصل';
      if(pingTimer){ clearInterval(pingTimer); pingTimer=null; }
    }
  }
  function goOnline(){
    if(offlineTimer){ clearTimeout(offlineTimer); offlineTimer = null; }
    setOnlineImmediate(true);
  }
  function goOffline(){
    // منوريش شريط الأوفلاين إلا لو فضل مفصول لفترة حقيقية (مش مجرد لحظة إعادة اتصال عادية أو بداية تشغيل)
    if(offlineTimer) return;
    offlineTimer = setTimeout(function(){ offlineTimer=null; setOnlineImmediate(false); }, 3000);
  }
  isOnline = true; // نبدأ متفائلين لحد ما نتأكد فعليًا إننا أوفلاين
  rtdb.ref('.info/connected').on('value', function(snap){
    if(snap.val()===true) goOnline(); else goOffline();
  });
  window.addEventListener('offline', function(){ goOffline(); });
  window.addEventListener('online', function(){ /* هنستنى .info/connected يتأكد فعليًا قبل ما نرجع أونلاين */ });
}

function fmtLastSeen(ts){
  if(!ts) return '';
  var diffMin = Math.round((Date.now()-ts)/60000);
  if(diffMin < 1) return 'من شوية';
  if(diffMin < 60) return 'آخر ظهور من ' + diffMin + ' دقيقة';
  var d = new Date(ts);
  return 'آخر ظهور ' + d.toLocaleString('ar-EG', {hour:'2-digit', minute:'2-digit'});
}

function listenProfileGifts(){
  profileGiftsRef = rtdb.ref('users/'+currentUser.uid+'/profileGifts');
  profileGiftsRef.on('value', function(snap){
    var el = document.getElementById('myProfileGifts');
    if(!snap.exists()){ el.innerHTML=''; return; }
    var gifts = Object.values(snap.val());
    var emojis = gifts.map(function(pg){
      var g = findGiftByKey(pg.key);
      if(g && g.imageData) return '<img src="'+g.imageData+'" style="width:22px;height:22px;border-radius:5px;vertical-align:middle">';
      return g ? g.emoji : '🎁';
    });
    el.innerHTML = emojis.join(' ');
  });
}

function refreshMyProfileUI(){
  var dn = currentProfile.displayName || currentProfile.username;
  document.getElementById('myAvatar').innerHTML = currentProfile.photoURL
    ? '' : esc(avatarLetter(dn));
  document.getElementById('myAvatar').style.cssText = currentProfile.photoURL
    ? 'background-image:url(\''+currentProfile.photoURL+'\');background-size:cover;background-position:center'
    : '';
  var headerAv = document.getElementById('headerAvatar');
  if(headerAv){
    headerAv.innerHTML = currentProfile.photoURL ? '' : esc(avatarLetter(dn));
    headerAv.style.cssText = currentProfile.photoURL
      ? 'background-image:url(\''+currentProfile.photoURL+'\');background-size:cover;background-position:center'
      : '';
  }
  document.getElementById('myName').innerHTML = nameWithBadge(dn, currentProfile.isVerified, currentProfile.activeBadgeColor, currentProfile.verifiedEmoji);
  document.getElementById('myUsernameTag').innerText = (currentProfile.loginType==='phone') ? formatPhoneDisplay(currentProfile.phone||currentProfile.username) : '@'+currentProfile.username;
  document.getElementById('walletBalance').innerText = (currentProfile.exeCoins||0) + ' ZYROX'; updateHeaderBalanceChip();
  applyPlatformTheme((currentProfile.settings && currentProfile.settings.platformTheme) || 'classic');
  applyColorMode(currentProfile.settings && currentProfile.settings.lightMode === true);
  applyAppBackground(currentProfile.settings && currentProfile.settings.appBackground);
  applyChatBackground(currentProfile.settings && currentProfile.settings.chatBackground);
  applyMoodRing('myAvatar', currentProfile.moodAura);
  applyMoodRing('headerAvatar', currentProfile.moodAura);
}

/* ============ ANNOUNCEMENTS (broadcast من الأدمن) ============ */
function listenAnnouncements(){
  announcementsRef = rtdb.ref('announcements').orderByChild('ts').startAt(appStartTime);
  announcementsRef.on('child_added', function(snap){
    var a = snap.val();
    if(!a || !a.text) return;
    document.getElementById('announceText').innerText = a.text;
    document.getElementById('announceBanner').classList.add('active');
  });
}
