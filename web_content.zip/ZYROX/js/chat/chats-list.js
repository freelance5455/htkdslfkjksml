/* ZYROX — chat/chats-list.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ CHATS LIST ============ */
function loadUserChats(){
  // نعرض النسخة المحفوظة على الجهاز فورًا لحد ما بيانات السيرفر توصل (مهم وإحنا أوفلاين)
  try{
    var savedChats = JSON.parse(localStorage.getItem('exe_chats_'+currentUser.uid) || 'null');
    if(savedChats){ Object.keys(savedChats).forEach(function(cid){ chatsCache[cid] = savedChats[cid]; }); renderChatsListFromCache(); }
  }catch(e0){}

  userChatsRef = rtdb.ref('userChats/'+currentUser.uid);
  userChatsRef.on('value', async function(snap){
    var chatIds = snap.exists() ? Object.keys(snap.val()) : [];
    var pinnedMap = snap.exists() ? snap.val() : {};

    // شيل من الكاش وقفل الـ listeners الخاصة بأي شات اتشال من عند اليوزر (مسح محادثة مثلاً)
    Object.keys(chatsCache).forEach(function(cid){
      if(chatIds.indexOf(cid)===-1){ detachChatLiveListeners(cid); delete chatsCache[cid]; }
    });

    if(chatIds.length===0){
      document.getElementById('chatsList').innerHTML = '<div class="empty-hint"><i class="fa-solid fa-comment-slash"></i>مفيش شاتات لسه.. ابحث عن صديق وابدأ محادثة!</div>';
      document.getElementById('groupsList').innerHTML = '<div class="empty-hint"><i class="fa-solid fa-users-slash"></i>مفيش جروبات لسه.. أنشئ جروب جديد!</div>';
      updateChatsNavBadge(0);
      return;
    }

    // تحميل بيانات كل الشاتات على التوازي مع بعض (مش واحدة ورا التانية) عشان القائمة تظهر أسرع بكتير
    await Promise.all(chatIds.map(function(cid){ return loadSingleChatData(cid, pinnedMap); }));

    notifInitDone = true;
    renderChatsListFromCache();

    // نعمل listener مباشر على كل شات وعلى حالة القراءة بتاعته، عشان العداد يتحدث فورًا (يزيد لما توصل رسالة، ويختفي لما تتقرا) من غير ما نعيد تحميل القائمة كلها من الأول
    chatIds.forEach(function(cid){ attachChatLiveListeners(cid); });
  });
}

/* تحميل بيانات شات واحد + حساب عدد رسايله اللي لسه ما اتقرتش، وتخزينها في الكاش المحلي */
async function loadSingleChatData(cid, pinnedMap){
  var cSnap = await rtdb.ref('chats/'+cid).once('value');
  if(!cSnap.exists()) return;
  var cObj = Object.assign({id:cid}, cSnap.val());
  cObj._pinned = !!(pinnedMap[cid] && pinnedMap[cid].pinned);
  if(cObj.type==='direct'){
    var oUid = Object.keys(cObj.members).find(function(k){ return k!==currentUser.uid; });
    var oSnap = await rtdb.ref('users/'+oUid).once('value');
    var oData = oSnap.val();
    if(oData){ cObj.otherPhoto = oData.photoURL; cObj.otherVerified = oData.isVerified; }
  }else if(cObj.type==='bot'){
    var bSnap = await rtdb.ref('bots/'+cObj.botId).once('value');
    var bData = bSnap.val();
    if(bData){ cObj._botName = bData.name; cObj._botPhoto = bData.photoURL; cObj._botVerified = bData.isVerified; }
  }
  cObj._unread = 0; cObj._lastReadTs = 0;
  if((cObj.type==='direct'||cObj.type==='group') && cObj.lastMessageSenderId && cObj.lastMessageSenderId!==currentUser.uid){
    // بوصل الرسالة اللي وصلت للجهاز -> علامة استلام (صحين رمادي)
    if(cObj.lastMessageId) rtdb.ref('messages/'+cid+'/'+cObj.lastMessageId+'/status').transaction(function(cur){ return cur ? cur : 'delivered'; });
    var lrSnap = await rtdb.ref('lastRead/'+currentUser.uid+'/'+cid).once('value');
    var lastReadTs = lrSnap.val() || 0;
    cObj._lastReadTs = lastReadTs;
    if(cObj.lastMessageTime && cObj.lastMessageTime > lastReadTs){
      cObj._unread = await countUnreadMessages(cid, lastReadTs);
    }
    var prevTs = knownLastMsgTime[cid];
    if(notifInitDone && prevTs && cObj.lastMessageTime && cObj.lastMessageTime > prevTs && currentChatId !== cid){
      if(!currentProfile.settings || currentProfile.settings.notifications !== false){
        var notifTitle = cObj.type==='group' ? (cObj.name||'جروب') : ((cObj.memberNames && cObj.memberNames[cObj.lastMessageSenderId]) || 'رسالة جديدة');
        var showPreview = !currentProfile.settings || currentProfile.settings.notifPreview !== false;
        showNotifBanner(cid, notifTitle, showPreview ? (cObj.lastMessage||'') : 'رسالة جديدة');
      }
    }
    knownLastMsgTime[cid] = cObj.lastMessageTime || knownLastMsgTime[cid];
  }
  chatsCache[cid] = cObj;
}

function countUnreadMessages(cid, lastReadTs){
  return rtdb.ref('messages/'+cid).orderByChild('timestamp').startAt(lastReadTs+1).once('value').then(function(unreadSnap){
    var cnt = 0;
    unreadSnap.forEach(function(msnap){
      var mv = msnap.val();
      if(mv.senderId!==currentUser.uid && !(mv.hiddenFor && mv.hiddenFor[currentUser.uid]) && !mv.deletedForEveryone) cnt++;
    });
    return cnt;
  });
}

/* رسم قائمة الشاتات من الكاش المحلي بس (من غير أي قراءة جديدة من القاعدة) — بينادوها كل ما يتغير أي حاجة لحظيًا فتظهر فورًا وبسرعة */
var chatsFilterMode = 'all';
window.applyChatsFilter = function(mode){
  chatsFilterMode = mode;
  ['chipAll','chipUnread','chipFav'].forEach(function(id){
    var el = document.getElementById(id);
    if(el) el.classList.toggle('active', id === 'chip'+mode.charAt(0).toUpperCase()+mode.slice(1));
  });
  renderChatsListFromCache();
};

function renderChatsListFromCache(){
  var chatsListEl = document.getElementById('chatsList');
  var groupsListEl = document.getElementById('groupsList');
  if(!chatsListEl || !groupsListEl) return;
  try{ if(currentUser) localStorage.setItem('exe_chats_'+currentUser.uid, JSON.stringify(chatsCache)); }catch(eCache){}
  var lockedMap = (currentProfile && currentProfile.lockedChats) || {};
  var chatsData = Object.keys(chatsCache).filter(function(cid){ return !lockedMap[cid]; }).map(function(cid){ return chatsCache[cid]; });
  var unreadTotalForChip = chatsData.reduce(function(s,c){ return s+(c._unread||0); },0);
  var groupsTotalForChip = chatsData.filter(function(c){ return c.type==='group'; }).length;
  var chipUnreadCountEl = document.getElementById('chipUnreadCount');
  var chipGroupsCountEl = document.getElementById('chipGroupsCount');
  if(chipUnreadCountEl){ chipUnreadCountEl.style.display = unreadTotalForChip>0?'inline-block':'none'; chipUnreadCountEl.innerText = unreadTotalForChip>99?'99+':unreadTotalForChip; }
  if(chipGroupsCountEl){ chipGroupsCountEl.style.display = groupsTotalForChip>0?'inline-block':'none'; chipGroupsCountEl.innerText = groupsTotalForChip>99?'99+':groupsTotalForChip; }
  if(chatsFilterMode==='unread') chatsData = chatsData.filter(function(c){ return (c._unread||0)>0; });
  else if(chatsFilterMode==='fav') chatsData = chatsData.filter(function(c){ return !!c._pinned; });
  if(chatsData.length===0){
    chatsListEl.innerHTML = chatsFilterMode==='all' ? '<div class="empty-hint"><i class="fa-solid fa-comment-slash"></i>مفيش شاتات لسه.. ابحث عن صديق وابدأ محادثة!</div>' : '<div class="empty-hint"><i class="fa-solid fa-filter-circle-xmark"></i>مفيش شاتات هنا</div>';
    groupsListEl.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-users-slash"></i>مفيش جروبات لسه.. أنشئ جروب جديد!</div>';
    updateChatsNavBadge(unreadTotalForChip);
    return;
  }
  chatsData.sort(function(a,b){
    var oa = a.id===MANDATORY_GROUP_ID?1:0, ob = b.id===MANDATORY_GROUP_ID?1:0;
    if(oa!==ob) return ob-oa;
    var pa = a._pinned?1:0, pb = b._pinned?1:0;
    if(pa!==pb) return pb-pa;
    return (b.lastMessageTime||b.createdAt||0)-(a.lastMessageTime||a.createdAt||0);
  });

  var chatsHtml=''; var groupsHtml=''; var totalUnread=0;
  chatsData.forEach(function(c){
    var title, sub, avatarHtml, otherUid = null;
    if(c.type==='direct'){
      otherUid = Object.keys(c.members).find(function(k){ return k!==currentUser.uid; });
      title = (c.memberNames && c.memberNames[otherUid]) || 'مستخدم';
      avatarHtml = avatarBlockHTML(title, c.otherPhoto, c.otherVerified ? 'border:2px solid #ffd97a;' : '');
    }else if(c.type==='ai'){
      title = 'ZYROX'; avatarHtml = AI_PHOTO_URL ? '<div class="avatar" style="background-image:url(\''+AI_PHOTO_URL+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar"><i class="fa-solid fa-robot"></i></div>';
    }else if(c.type==='bot'){
      title = c._botName || 'بوت'; avatarHtml = c._botPhoto ? avatarBlockHTML(title, c._botPhoto, '') : '<div class="avatar"><i class="fa-solid fa-microchip"></i></div>';
    }else{
      title = c.name || 'جروب';
      var hasProtection = !!(c.protectionBot && c.protectionBot.enabled);
      if(c.photoURL){
        avatarHtml = avatarBlockHTML(title, c.photoURL, '');
      }else{
        avatarHtml = hasProtection ? '<div class="avatar" style="box-shadow:0 0 12px var(--neon-blue)"><i class="fa-solid fa-shield-halved"></i></div>' : '<div class="avatar"><i class="fa-solid fa-users"></i></div>';
      }
    }
    sub = c.lastMessage ? c.lastMessage : 'ابدأ المحادثة الآن';
    var sentTickHtml = '';
    if(c.lastMessage && (c.type==='direct'||c.type==='group') && c.lastMessageSenderId===currentUser.uid){
      sentTickHtml = '<i class="fa-solid fa-check" style="color:var(--text-dim);font-size:11px;margin-left:4px"></i>';
    }
    var nameHtml = (c.type==='direct'||c.type==='bot') ? nameWithBadge(title, c.type==='bot'?c._botVerified:c.otherVerified) : nameWithBadge(title, c.isVerified);
    if(c._pinned || c.id===MANDATORY_GROUP_ID) nameHtml = '<i class="fa-solid fa-thumbtack pin-icon"></i>' + nameHtml;
    totalUnread += (c._unread||0);
    var unreadBadgeHtml = c._unread>0 ? '<span class="item-unread-badge">'+(c._unread>99?'99+':c._unread)+'</span>' : '';
    var isSel = !!selectedChatIds[c.id];
    var checkHtml = '<div class="item-check'+(isSel?' checked':'')+'"><i class="fa-solid fa-check" style="display:'+(isSel?'block':'none')+'"></i></div>';
    var card = '<div class="item-card'+(isSel?' selected':'')+'" data-cid="'+c.id+'" data-type="'+c.type+'"'+(otherUid?' data-otheruid="'+otherUid+'"':'')+' onclick="handleChatCardClick(\''+c.id+'\')">'+
      checkHtml + avatarHtml+
      '<div class="item-info"><h4>'+nameHtml+'</h4><p>'+sentTickHtml+esc(sub)+'</p></div>'+
      '<div class="item-time-col"><div class="item-time">'+fmtTime(c.lastMessageTime)+'</div>'+unreadBadgeHtml+'</div></div>';
    chatsHtml += card;
    if(c.type==='group') groupsHtml += card;
  });
  chatsListEl.innerHTML = chatsHtml || '<div class="empty-hint"><i class="fa-solid fa-comment-slash"></i>مفيش شاتات لسه</div>';
  groupsListEl.innerHTML = groupsHtml || '<div class="empty-hint"><i class="fa-solid fa-users-slash"></i>مفيش جروبات لسه.. أنشئ جروب جديد!</div>';
  chatsListEl.classList.toggle('chat-select-mode', chatSelectMode);
  groupsListEl.classList.toggle('chat-select-mode', chatSelectMode);
  attachChatCardLongPress(chatsListEl);
  attachChatCardLongPress(groupsListEl);
  updateChatSelectBar();
  updateChatsNavBadge(unreadTotalForChip);
}

/* ============ تحديد متعدد للمحادثات (زي واتساب): ضغطة مطولة على شات بتفعّل وضع التحديد وتظهر شريط فيه تثبيت/حظر/حذف،
   وبعد كده أي ضغطة عادية على شات تاني بتضيفه للتحديد لحد ما تلغي أو تنفذ الإجراء ============ */
var chatSelectMode = false;
var selectedChatIds = {};
var chatSuppressClickUntil = 0;

function attachChatCardLongPress(listEl){
  var cards = listEl.querySelectorAll('.item-card');
  cards.forEach(function(el){
    if(el._longPressAttached) return;
    el._longPressAttached = true;
    var cid = el.getAttribute('data-cid');
    var timer = null;
    function start(){ timer = setTimeout(function(){
      chatSuppressClickUntil = Date.now() + 400;
      if(navigator.vibrate) navigator.vibrate(20);
      enterChatSelectMode(cid);
    }, 500); }
    function cancel(){ clearTimeout(timer); }
    el.addEventListener('touchstart', start, {passive:true});
    el.addEventListener('touchend', cancel);
    el.addEventListener('touchmove', cancel);
    el.addEventListener('mousedown', start);
    el.addEventListener('mouseup', cancel);
    el.addEventListener('mouseleave', cancel);
  });
}

window.handleChatCardClick = function(cid){
  if(Date.now() < chatSuppressClickUntil) return; // كانت لسه ضغطة مطولة
  if(chatSelectMode){ toggleChatSelection(cid); return; }
  openChat(cid);
};

function enterChatSelectMode(cid){
  chatSelectMode = true;
  selectedChatIds = {};
  selectedChatIds[cid] = true;
  renderChatsListFromCache();
}

function toggleChatSelection(cid){
  if(selectedChatIds[cid]) delete selectedChatIds[cid];
  else selectedChatIds[cid] = true;
  if(Object.keys(selectedChatIds).length===0){ exitChatSelectMode(); return; }
  renderChatsListFromCache();
}

window.exitChatSelectMode = function(){
  chatSelectMode = false;
  selectedChatIds = {};
  renderChatsListFromCache();
};

function updateChatSelectBar(){
  var bar = document.getElementById('chatSelectBar');
  if(!bar) return;
  var count = Object.keys(selectedChatIds).length;
  if(!chatSelectMode || count===0){ bar.style.display='none'; return; }
  bar.style.display='flex';
  var countEl = document.getElementById('chatSelectCount');
  if(countEl) countEl.innerText = count;
  var allDirect = Object.keys(selectedChatIds).every(function(cid){ return chatsCache[cid] && chatsCache[cid].type==='direct'; });
  var blockBtn = document.getElementById('chatSelectBlockBtn');
  if(blockBtn) blockBtn.style.display = allDirect ? 'inline-block' : 'none';
}

window.bulkDeleteSelectedChats = async function(){
  var ids = Object.keys(selectedChatIds);
  if(ids.length===0) return;
  if(ids.indexOf(MANDATORY_GROUP_ID)!==-1){ alert('جروب ZYROX الرسمي مثبّت ومينفعش تمسحه، شيله من التحديد.'); return; }
  if(!confirm('تمسح '+ids.length+' محادثة من عندك؟ (هتفضل موجودة عند الطرف التاني)')) return;
  try{
    var updates = {};
    ids.forEach(function(cid){ updates['userChats/'+currentUser.uid+'/'+cid] = null; });
    await rtdb.ref().update(updates);
    if(ids.indexOf(currentChatId)!==-1) window.closeChat();
    exitChatSelectMode();
  }catch(err){
    alert('تعذر حذف المحادثات، حاول تاني');
  }
};

window.bulkPinSelectedChats = async function(){
  var ids = Object.keys(selectedChatIds);
  if(ids.length===0) return;
  try{
    // لو كل المحدد مثبت بالفعل نفك تثبيته، غير كده نثبت الكل
    var allPinned = ids.every(function(cid){ return chatsCache[cid] && chatsCache[cid]._pinned; });
    var updates = {};
    ids.forEach(function(cid){ updates['userChats/'+currentUser.uid+'/'+cid+'/pinned'] = !allPinned; });
    await rtdb.ref().update(updates);
    exitChatSelectMode();
  }catch(err){
    alert('تعذر تثبيت المحادثات، حاول تاني');
  }
};

window.bulkBlockSelectedChats = async function(){
  var ids = Object.keys(selectedChatIds);
  var targets = ids.map(function(cid){
    var c = chatsCache[cid];
    if(!c || c.type!=='direct' || !c.members) return null;
    return Object.keys(c.members).find(function(k){ return k!==currentUser.uid; });
  }).filter(Boolean);
  if(targets.length===0) return;
  if(!confirm('تحظر '+targets.length+' مستخدم؟ مش هيقدروا يبعتولك رسايل')) return;
  try{
    var updates = {};
    targets.forEach(function(uid){ updates['blocked/'+currentUser.uid+'/'+uid] = true; });
    await rtdb.ref().update(updates);
    showBlackToast('تم الحظر بنجاح');
    exitChatSelectMode();
  }catch(err){
    alert('تعذر الحظر، حاول تاني');
  }
};

function updateChatsNavBadge(totalUnread){
  var navChatsBadgeEl = document.getElementById('navChatsBadge');
  if(navChatsBadgeEl){
    if(totalUnread>0){ navChatsBadgeEl.style.display='flex'; navChatsBadgeEl.innerText = totalUnread>99?'99+':totalUnread; }
    else navChatsBadgeEl.style.display='none';
  }
}

/* لحظيًا: لما رسالة جديدة توصل لأي شات موجود عندي، أو حالة القراءة بتاعتي تتغير — بنحدث العداد فورًا من غير إعادة تحميل القائمة كلها */
function attachChatLiveListeners(cid){
  if(!chatLiveListeners[cid]){
    chatLiveListeners[cid] = true;
    rtdb.ref('chats/'+cid).on('value', function(csnap){
      if(!csnap.exists() || !chatsCache[cid]) return;
      var newData = csnap.val();
      var prev = chatsCache[cid];
      var isNewMessage = newData.lastMessageId && newData.lastMessageId !== prev.lastMessageId;
      var merged = Object.assign({}, prev, newData, {id:cid, _pinned:prev._pinned, _lastReadTs:prev._lastReadTs, _unread:prev._unread});
      if(isNewMessage){
        if((merged.type==='direct'||merged.type==='group') && newData.lastMessageSenderId && newData.lastMessageSenderId!==currentUser.uid){
          if(newData.lastMessageId) rtdb.ref('messages/'+cid+'/'+newData.lastMessageId+'/status').transaction(function(cur){ return cur ? cur : 'delivered'; });
          if(currentChatId === cid){
            merged._unread = 0; // الشات مفتوح قدامي دلوقتي، هيتقرا لوحده على طول
          }else{
            merged._unread = (prev._unread||0) + 1;
            if(!currentProfile.settings || currentProfile.settings.notifications !== false){
              var notifTitle = merged.type==='group' ? (merged.name||'جروب') : ((merged.memberNames && merged.memberNames[newData.lastMessageSenderId]) || 'رسالة جديدة');
              var showPreview = !currentProfile.settings || currentProfile.settings.notifPreview !== false;
              showNotifBanner(cid, notifTitle, showPreview ? (merged.lastMessage||'') : 'رسالة جديدة');
            }
          }
          knownLastMsgTime[cid] = merged.lastMessageTime || knownLastMsgTime[cid];
        }else{
          merged._unread = 0; // أنا اللي بعت الرسالة دي
        }
      }
      chatsCache[cid] = merged;
      renderChatsListFromCache();
    });
  }
  if(!chatLastReadListeners[cid]){
    chatLastReadListeners[cid] = true;
    rtdb.ref('lastRead/'+currentUser.uid+'/'+cid).on('value', function(lrsnap){
      if(!chatsCache[cid]) return;
      var lastReadTs = lrsnap.val() || 0;
      chatsCache[cid]._lastReadTs = lastReadTs;
      if(!chatsCache[cid].lastMessageTime || chatsCache[cid].lastMessageTime <= lastReadTs){
        if(chatsCache[cid]._unread){ chatsCache[cid]._unread = 0; renderChatsListFromCache(); }
      }
    });
  }
}

function detachChatLiveListeners(cid){
  if(chatLiveListeners[cid]){ rtdb.ref('chats/'+cid).off(); delete chatLiveListeners[cid]; }
  if(chatLastReadListeners[cid]){ rtdb.ref('lastRead/'+currentUser.uid+'/'+cid).off(); delete chatLastReadListeners[cid]; }
}
