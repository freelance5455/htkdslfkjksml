/* ZYROX — chat/capsule-attachments-voice.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ كبسولة الوقت (ميزة حصرية) ============ */
window.openCapsuleModal = function(){
  document.getElementById('attachMenu').classList.remove('active');
  document.getElementById('capsuleText').value = '';
  var d = new Date(Date.now() + 60*60*1000); // افتراضيًا بعد ساعة من دلوقتي
  document.getElementById('capsuleDateTime').value = new Date(d.getTime() - d.getTimezoneOffset()*60000).toISOString().slice(0,16);
  document.getElementById('capsuleModal').classList.add('active');
};
window.sendCapsuleMessage = function(){
  var text = document.getElementById('capsuleText').value.trim();
  var dtVal = document.getElementById('capsuleDateTime').value;
  if(!text) return alert('اكتب الرسالة الأول');
  if(!dtVal) return alert('اختار ميعاد الفتح');
  var unlockAt = new Date(dtVal).getTime();
  if(!unlockAt || unlockAt <= Date.now()) return alert('لازم الميعاد يكون في المستقبل');
  if(!currentChatId) return;
  pushMessage(currentChatId, {type:'capsule', text: text, unlockAt: unlockAt});
  document.getElementById('capsuleModal').classList.remove('active');
};
function unlockCapsuleInPlace(id, m){
  var el = document.querySelector('.msg-row[data-msg-id="'+id+'"]');
  if(!el) return;
  el.dataset.capsuleLocked = '0';
  var capsuleEl = el.querySelector('.capsule-msg');
  if(capsuleEl){
    capsuleEl.outerHTML = '<div class="capsule-msg capsule-unlock-burst"><i class="fa-solid fa-box-open"></i><div>'+esc(m.text)+'</div><div class="capsule-countdown"><i class="fa-solid fa-lock-open"></i> اتفتحت الآن!</div></div>';
  }
}
window.tryOpenCapsule = function(msgId){
  var m = messagesCache[msgId];
  if(!m || m.type!=='capsule') return;
  if(Date.now() < m.unlockAt){
    var mins = Math.ceil((m.unlockAt - Date.now())/60000);
    var label = mins>=60 ? Math.ceil(mins/60)+' ساعة' : mins+' دقيقة';
    showBlackToast('الكبسولة لسه مقفولة، هتتفتح لوحدها بعد '+label);
    return;
  }
  unlockCapsuleInPlace(msgId, m);
};

/* ============ AI REPLY VIA GROQ ============ */
async function handleAIReply(userText){
  var area = document.getElementById('messagesArea');
  var typingRow = document.createElement('div');
  typingRow.className='msg-row received'; typingRow.id='aiTyping';
  typingRow.innerHTML = '<div class="msg-bubble"><i class="fa-solid fa-ellipsis fa-fade"></i> بيكتب...</div>';
  area.appendChild(typingRow); area.scrollTop = area.scrollHeight;
  var chatIdAtSend = currentChatId;
  try{
    var res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method:'POST',
      headers:{ 'Content-Type':'application/json', 'Authorization':'Bearer '+GROQ_API_KEY },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: [
          {role:'system', content:'أنت مساعد ذكي ودود اسمه "'+AI_BOT_NAME+'" جوه تطبيق شات اسمه ZYROX. رد باللهجة العربية أو الفصحى حسب أسلوب المستخدم، بإيجاز ووضوح.'},
          {role:'user', content: userText}
        ]
      })
    });
    var data = await res.json();
    var reply = (data.choices && data.choices[0]) ? data.choices[0].message.content : 'معلش، مقدرتش أرد دلوقتي.';
    var typing = document.getElementById('aiTyping'); if(typing) typing.remove();
    await rtdb.ref('messages/'+chatIdAtSend).push().set({ senderId:'ai-bot', senderName:AI_BOT_NAME, type:'text', text:reply, timestamp: firebase.database.ServerValue.TIMESTAMP });
    await rtdb.ref('chats/'+chatIdAtSend).update({ lastMessage: reply, lastMessageTime: firebase.database.ServerValue.TIMESTAMP });
  }catch(err){
    var typing2 = document.getElementById('aiTyping'); if(typing2) typing2.remove();
    await rtdb.ref('messages/'+chatIdAtSend).push().set({ senderId:'ai-bot', senderName:AI_BOT_NAME, type:'text', text:'حصل خطأ في الاتصال بالذكاء الاصطناعي، حاول تاني.', timestamp: firebase.database.ServerValue.TIMESTAMP });
  }
}

/* ============ ATTACHMENTS ============ */
window.toggleAttachMenu = function(){ document.getElementById('attachMenu').classList.toggle('active'); };
window.triggerFile = function(kind){
  document.getElementById('attachMenu').classList.remove('active');
  document.getElementById('fileInput'+kind.charAt(0).toUpperCase()+kind.slice(1)).click();
};

window.handleFileSelect = function(inputEl, kind){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value = '';
  var maxSize = kind==='image' ? 6*1024*1024 : 5*1024*1024;
  if(file.size > maxSize){ alert('الملف كبير جدًا، اختار ملف أصغر من ' + (maxSize/1024/1024) + ' ميجا'); return; }

  if(kind==='image'){
    var wantsViewOnce = confirm('تحب الصورة دي تتشاف مرة واحدة بس زي التليجرام؟\nOK = مرة واحدة وتختفي  |  إلغاء = صورة عادية');
    compressImage(file, function(dataUrl){
      pushMessage(currentChatId, {type:'image', mediaData: dataUrl, viewOnce: !!wantsViewOnce, viewed:false});
    });
  }else{
    var reader = new FileReader();
    reader.onload = function(){
      pushMessage(currentChatId, {type: kind==='video'?'video':'file', mediaData: reader.result, fileName: file.name, mimeType: file.type});
    };
    reader.readAsDataURL(file);
  }
};

function compressImage(file, cb){
  var reader = new FileReader();
  reader.onload = function(e){
    var img = new Image();
    img.onload = function(){
      var maxDim = 1000;
      var w = img.width, h = img.height;
      if(w > maxDim || h > maxDim){
        if(w > h){ h = Math.round(h * maxDim / w); w = maxDim; }
        else{ w = Math.round(w * maxDim / h); h = maxDim; }
      }
      var canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      cb(canvas.toDataURL('image/jpeg', 0.72));
    };
    img.src = e.target.result;
  };
  reader.readAsDataURL(file);
}

/* يتحقق من مدة الفيديو (بالثواني) قبل ما نقرأه كـ base64 */
function checkVideoDuration(file, maxSeconds, cb){
  var url = URL.createObjectURL(file);
  var v = document.createElement('video');
  v.preload = 'metadata';
  v.onloadedmetadata = function(){
    URL.revokeObjectURL(url);
    var dur = v.duration || 0;
    cb(dur <= maxSeconds + 0.5, dur);
  };
  v.onerror = function(){
    URL.revokeObjectURL(url);
    cb(false, 0);
  };
  v.src = url;
}

function readFileAsDataURL(file, cb){
  var reader = new FileReader();
  reader.onload = function(e){ cb(e.target.result); };
  reader.readAsDataURL(file);
}

/* ============ UPLOAD OVERLAY (شاشة تحميل مميزة أثناء رفع الفيديوهات/الألعاب) ============ */
function showUploadOverlay(title, sub){
  var el = document.getElementById('uploadOverlay');
  if(!el) return;
  document.getElementById('uploadOverlayTitle').textContent = title || 'جارٍ الرفع...';
  document.getElementById('uploadOverlaySub').textContent = sub || 'من فضلك ماتقفلش الصفحة';
  el.classList.add('active');
}
function hideUploadOverlay(){
  var el = document.getElementById('uploadOverlay');
  if(el) el.classList.remove('active');
}

/* ============ HOSTING UPLOAD (رفع ملفات المشروع إلى Firebase Storage) ============ */
var hostingSelectedFiles = { py:null, req:null };
window.openHostingUploadScreen = function(){
  document.getElementById('sideMenu').classList.remove('active');
  hostingSelectedFiles = { py:null, req:null };
  document.getElementById('hostingPyFileInput').value = '';
  document.getElementById('hostingReqFileInput').value = '';
  document.getElementById('hostingPyFileName').textContent = 'مفيش ملف مختار';
  document.getElementById('hostingReqFileName').textContent = 'مفيش ملف مختار';
  document.getElementById('hostingUploadScreen').classList.add('active');
  renderHostingMyUploads();
};
window.handleHostingFileSelect = function(input, kind){
  var file = input.files && input.files[0];
  if(!file) return;
  var maxBytes = 5*1024*1024;
  if(file.size > maxBytes){ alert('حجم الملف كبير جدًا (الحد الأقصى 5MB)'); input.value=''; return; }
  if(kind==='py' && !/\.py$/i.test(file.name)){ alert('لازم الملف يكون بامتداد .py'); input.value=''; return; }
  if(kind==='req' && !/\.txt$/i.test(file.name)){ alert('لازم الملف يكون بامتداد .txt'); input.value=''; return; }
  hostingSelectedFiles[kind] = file;
  document.getElementById(kind==='py' ? 'hostingPyFileName' : 'hostingReqFileName').textContent = file.name;
};
window.uploadHostingFiles = async function(){
  if(!currentUser){ alert('لازم تسجل دخول الأول'); return; }
  var pyFile = hostingSelectedFiles.py;
  var reqFile = hostingSelectedFiles.req;
  if(!pyFile || !reqFile){ alert('لازم تختار ملف البايثون وملف المكاتب الاتنين'); return; }
  var btn = document.getElementById('hostingUploadBtn');
  btn.disabled = true;
  showUploadOverlay('جارٍ رفع مشروعك...', 'من فضلك ماتقفلش الصفحة');
  try{
    var newRef = rtdb.ref('hostingUploads/'+currentUser.uid).push();
    var uploadId = newRef.key;
    var basePath = 'hostingUploads/'+currentUser.uid+'/'+uploadId+'/';
    var pySnap = await fbStorage.ref(basePath+pyFile.name).put(pyFile);
    var pyURL = await pySnap.ref.getDownloadURL();
    var reqSnap = await fbStorage.ref(basePath+reqFile.name).put(reqFile);
    var reqURL = await reqSnap.ref.getDownloadURL();
    await newRef.set({
      pyFileName: pyFile.name,
      pyURL: pyURL,
      reqFileName: reqFile.name,
      reqURL: reqURL,
      status: 'pending',
      uploaderUid: currentUser.uid,
      uploaderName: (currentProfile && (currentProfile.displayName||currentProfile.username)) || '',
      ts: firebase.database.ServerValue.TIMESTAMP
    });
    hideUploadOverlay();
    btn.disabled = false;
    showBlackToast('اتم رفع المشروع بنجاح');
    hostingSelectedFiles = { py:null, req:null };
    document.getElementById('hostingPyFileInput').value = '';
    document.getElementById('hostingReqFileInput').value = '';
    document.getElementById('hostingPyFileName').textContent = 'مفيش ملف مختار';
    document.getElementById('hostingReqFileName').textContent = 'مفيش ملف مختار';
    renderHostingMyUploads();
  }catch(err){
    hideUploadOverlay();
    btn.disabled = false;
    alert('تعذر رفع المشروع، حاول تاني');
  }
};
function hostingStatusLabel(status){
  if(status==='approved') return '<span style="color:var(--success)">مقبول</span>';
  if(status==='rejected') return '<span style="color:var(--danger)">مرفوض</span>';
  return '<span style="color:var(--warn)">قيد المراجعة</span>';
}
async function renderHostingMyUploads(){
  var el = document.getElementById('hostingMyUploadsList');
  if(!el || !currentUser) return;
  el.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  try{
    var snap = await rtdb.ref('hostingUploads/'+currentUser.uid).orderByChild('ts').once('value');
    var val = snap.val();
    if(!val){ el.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-cloud"></i>لسه مرفعتش أي مشروع</div>'; return; }
    var keys = Object.keys(val).reverse();
    el.innerHTML = keys.map(function(k){
      var it = val[k];
      return '<div class="admin-games-card"><div class="agc-info">'+
        '<h5>'+esc(it.pyFileName||'')+'</h5>'+
        '<p style="font-size:11px;color:var(--text-dim)">'+esc(it.reqFileName||'')+' — '+hostingStatusLabel(it.status)+'</p>'+
        '</div></div>';
    }).join('');
  }catch(err){
    el.innerHTML = '<div class="empty-hint">تعذر تحميل القائمة</div>';
  }
}

/* ============ VOICE RECORDING ============ */
window.toggleVoiceRecording = async function(){
  var micBtn = document.getElementById('micBtn');
  if(!isRecording){
    try{
      var stream = await navigator.mediaDevices.getUserMedia({audio:true});
      audioChunks = [];
      mediaRecorder = new MediaRecorder(stream);
      mediaRecorder.ondataavailable = function(e){ audioChunks.push(e.data); };
      mediaRecorder.onstop = function(){
        var blob = new Blob(audioChunks, {type:'audio/webm'});
        if(blob.size > 5*1024*1024){ alert('التسجيل طويل جدًا'); return; }
        var reader = new FileReader();
        reader.onload = function(){ pushMessage(currentChatId, {type:'voice', mediaData: reader.result}); };
        reader.readAsDataURL(blob);
        stream.getTracks().forEach(function(t){ t.stop(); });
      };
      mediaRecorder.start();
      isRecording = true;
      micBtn.classList.add('recording');
      micBtn.innerHTML = '<i class="fa-solid fa-stop"></i>';
    }catch(err){
      alert('محتاج إذن الميكروفون عشان تسجل رسالة صوتية');
    }
  }else{
    mediaRecorder.stop();
    isRecording = false;
    micBtn.classList.remove('recording');
    micBtn.innerHTML = '<i class="fa-solid fa-microphone"></i>';
  }
};
