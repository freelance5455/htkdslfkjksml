/* ZYROX — chat/message-extras.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ AVATAR UPLOAD (من المعرض) ============ */
window.handleAvatarSelect = function(inputEl){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value = '';
  if(file.size > 6*1024*1024){ alert('الصورة كبيرة، اختار صورة أصغر من 6 ميجا'); return; }
  compressImage(file, async function(dataUrl){
    try{
      await rtdb.ref('users/'+currentUser.uid+'/photoURL').set(dataUrl);
      currentProfile.photoURL = dataUrl;
      var prev = document.getElementById('settingsAvatarPreview');
      prev.innerHTML=''; prev.style.cssText='background-image:url(\''+dataUrl+'\');background-size:cover;background-position:center';
      refreshMyProfileUI();
      alert('تم تغيير الصورة');
    }catch(err){
      alert('تعذر رفع الصورة، حاول تاني');
    }
  });
};

/* ============ MESSAGE ACTIONS (حذف / رد) ============ */
var messageActionsTargetId = null;
window.openMessageActions = function(msgId){
  if(!currentChatId) return;
  messageActionsTargetId = msgId;
  var m = messagesCache[msgId];
  var isMine = m && m.senderId === currentUser.uid;
  document.getElementById('maDeleteEveryone').style.display = isMine ? 'flex' : 'none';
  document.getElementById('messageActionsModal').classList.add('active');
};

window.replyFromActions = function(){
  var id = messageActionsTargetId;
  var m = messagesCache[id];
  window.closeModal('messageActionsModal');
  if(id && m) window.startReply(id, m);
};

window.deleteMessageForMeAction = async function(){
  var id = messageActionsTargetId;
  window.closeModal('messageActionsModal');
  if(!id || !currentChatId) return;
  try{
    await rtdb.ref('messages/'+currentChatId+'/'+id+'/hiddenFor/'+currentUser.uid).set(true);
    var row = document.querySelector('.msg-row[data-msg-id="'+id+'"]');
    if(row) row.remove();
  }catch(err){
    alert('تعذر حذف الرسالة، حاول تاني');
  }
};

window.deleteMessageForEveryoneAction = async function(){
  var id = messageActionsTargetId;
  window.closeModal('messageActionsModal');
  if(!id || !currentChatId) return;
  var m = messagesCache[id];
  if(!m || m.senderId !== currentUser.uid) return;
  if(!confirm('هتمسح الرسالة دي عند الجميع؟ الخطوة دي مش هترجع')) return;
  try{
    await rtdb.ref('messages/'+currentChatId+'/'+id).update({
      deletedForEveryone: true, text:'', mediaType:null, mediaData:null, fileName:null,
      buttons:null, reactions:null, replyTo:null
    });
  }catch(err){
    alert('تعذر حذف الرسالة، حاول تاني');
  }
};

/* ============ REACTIONS (عادي وإيموجي + تفاعل مدفوع بـ ZYROX) ============ */
var reactingMsgId = null;
var QUICK_REACTIONS = ['❤️','😂','😮','😢','👍','🔥','🎉','😡'];

/* ============ STICKERS (زي التليجرام) ============ */
var STICKER_PACK = ['😂','❤️','🔥','👍','😍','😢','😮','😡','🎉','🤝','🙏','💯','😴','🤔','😎','🥳','🤩','😭','👏','💪','🌹','⭐','🎁','🤍','💔','😱','🙈','🤗','😇','🥺','😏','🤤','🐱','🐶','⚽','🎮','🍕','☕','🌙','⚡'];
var stickerActiveTab = 'all';
var savedStickersRef = null;
var savedStickersMap = {};
function listenSavedStickers(){
  if(savedStickersRef) savedStickersRef.off();
  savedStickersRef = rtdb.ref('users/'+currentUser.uid+'/savedStickers');
  savedStickersRef.on('value', function(snap){
    savedStickersMap = snap.val() || {};
    renderStickerGrid();
  });
}
window.openStickerModal = function(){
  if(!currentChatId) return;
  stickerActiveTab = 'all';
  renderStickerGrid();
  document.getElementById('stickerModal').classList.add('active');
};
window.switchStickerTab = function(tab){
  stickerActiveTab = tab;
  renderStickerGrid();
};
function renderStickerGrid(){
  var el = document.getElementById('stickerGrid');
  if(!el) return;
  var tabAll = document.getElementById('stickerTabAll');
  var tabSaved = document.getElementById('stickerTabSaved');
  if(tabAll) tabAll.style.opacity = stickerActiveTab==='all' ? '1' : '.55';
  if(tabSaved) tabSaved.style.opacity = stickerActiveTab==='saved' ? '1' : '.55';
  var list = stickerActiveTab==='saved' ? Object.keys(savedStickersMap) : STICKER_PACK;
  if(!list.length){
    el.innerHTML = '<div class="empty-hint" style="grid-column:1/-1">مفيش ملصقات محفوظة لسه</div>';
    return;
  }
  el.innerHTML = list.map(function(e){
    var isSaved = !!savedStickersMap[e];
    return '<div class="sticker-item">'+
      '<div class="sticker-emoji-big" onclick="sendStickerAndClose(\''+e+'\')">'+e+'</div>'+
      '<i class="fa-solid fa-star sticker-star'+(isSaved?' active':'')+'" onclick="toggleSavedSticker(\''+e+'\',event)"></i>'+
    '</div>';
  }).join('');
}
window.toggleSavedSticker = function(emoji, ev){
  if(ev) ev.stopPropagation();
  var ref = rtdb.ref('users/'+currentUser.uid+'/savedStickers/'+emoji);
  if(savedStickersMap[emoji]) ref.remove(); else ref.set(true);
};
window.sendStickerAndClose = function(emoji){
  if(!currentChatId) return;
  pushMessage(currentChatId, {type:'sticker', stickerEmoji: emoji});
  window.closeModal('stickerModal');
};
window.openReactionPicker = function(msgId){
  if(!currentChatId) return;
  reactingMsgId = msgId;
  var html = QUICK_REACTIONS.map(function(e){
    return '<button class="reaction-emoji-btn" onclick="applyReaction(\''+e+'\')">'+e+'</button>';
  }).join('');
  if(isCurrentUserVerified()){
    // الموثقين بس بيقدروا يتفاعلوا بشارة التوثيق نفسها، وأي لون يختاروه (مش بس لون حسابهم)
    html += ['red','green','blue'].map(function(t){
      var cfg = BADGE_TYPES[t];
      return '<button class="reaction-emoji-btn" title="'+cfg.title+'" onclick="applyReaction(\'badge:'+t+'\')"><i class="fa-solid fa-circle-check" style="color:'+cfg.color+'"></i></button>';
    }).join('');
  }
  document.getElementById('reactionEmojiGrid').innerHTML = html;
  document.getElementById('reactionModal').classList.add('active');
};

window.applyReaction = async function(emoji){
  var msgId = reactingMsgId;
  if(!msgId || !currentChatId){ window.closeModal('reactionModal'); return; }
  // الموثقين بس بيقدروا يحطوا أكتر من تفاعل على نفس الرسالة في نفس الوقت (كل تفاعل ليه مفتاح منفصل)
  var verifiedMulti = isCurrentUserVerified();
  if(!verifiedMulti) window.closeModal('reactionModal');
  var refKey = verifiedMulti ? (currentUser.uid + '__' + emoji.replace(/[.#$\[\]]/g,'_')) : currentUser.uid;
  var refR = rtdb.ref('messages/'+currentChatId+'/'+msgId+'/reactions/'+refKey);
  var snap = await refR.once('value');
  var existing = snap.val();
  if(existing && existing.paid){ if(verifiedMulti) window.closeModal('reactionModal'); alert('عندك تفاعل مدفوع على الرسالة دي، ومينفعش يتشال أو يتغير'); return; }
  if(existing && existing.emoji===emoji){
    await refR.remove();
  }else{
    await refR.set({ emoji: emoji, paid:false, uid: currentUser.uid, ts: firebase.database.ServerValue.TIMESTAMP });
  }
  if(verifiedMulti) showBlackToast('اتضاف تفاعلك، تقدر تختار كذا تفاعل مع بعض ✨');
};

window.paidReactAction = async function(){
  var msgId = reactingMsgId;
  if(!msgId || !currentChatId || !currentChatData || currentChatData.type!=='direct'){
    window.closeModal('reactionModal');
    alert('التفاعل المدفوع متاح بس في المحادثات الخاصة');
    return;
  }
  var refR = rtdb.ref('messages/'+currentChatId+'/'+msgId+'/reactions/'+currentUser.uid);
  var snap = await refR.once('value');
  if(snap.val() && snap.val().paid){ window.closeModal('reactionModal'); alert('انت أصلاً بعتّ تفاعل مدفوع على الرسالة دي'); return; }
  window.closeModal('reactionModal');
  var amountStr = prompt('اكتب قد ايه ZYROX عايز تبعت كتفاعل مدفوع (الحد الأدنى 5):');
  if(!amountStr) return;
  var amount = parseInt(amountStr, 10);
  if(!amount || amount < 5){ alert('اكتب رقم صحيح 5 أو أكتر'); return; }
  if((currentProfile.exeCoins||0) < amount){ alert('رصيدك مش كافي'); return; }
  var otherUid = Object.keys(currentChatData.members).find(function(k){ return k!==currentUser.uid; });
  var myBalRef = rtdb.ref('users/'+currentUser.uid+'/exeCoins');
  var result = await myBalRef.transaction(function(cur){
    cur = cur||0;
    if(cur < amount) return;
    return cur - amount;
  });
  if(!result.committed){ alert('رصيدك مش كافي'); return; }
  currentProfile.exeCoins = result.snapshot.val();
  document.getElementById('walletBalance').innerText = (currentProfile.exeCoins||0) + ' ZYROX'; updateHeaderBalanceChip();
  await rtdb.ref('users/'+otherUid+'/exeCoins').transaction(function(cur){ return (cur||0) + amount; });
  await refR.set({ emoji:'💎', paid:true, amount:amount, ts: firebase.database.ServerValue.TIMESTAMP });
  alert('تم إرسال تفاعل مدفوع بـ '+amount+' ZYROX، اتحولت لرصيد الطرف التاني ✅');
};

/* ============ USER PROFILE VIEW (بالضغط على صورة أي حد) ============ */
window.openUserProfile = async function(uid){
  document.getElementById('userProfileScreen').classList.add('active');
  document.getElementById('upAvatar').innerHTML = '';
  document.getElementById('upAvatar').style.cssText = 'width:120px;height:120px;font-size:44px;margin:0 auto 14px';
  document.getElementById('upName').innerText = '...';
  document.getElementById('upUsername').innerText = '';
  document.getElementById('upAbout').innerText = '';
  document.getElementById('upActionsRow').style.display = 'none';
  document.getElementById('upActionsRow').innerHTML = '';
  document.getElementById('upMuteSection').style.display = 'none';
  document.getElementById('upMediaSection').style.display = 'none';
  document.getElementById('upVideosGrid').innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  document.getElementById('upGiftsList').innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  var snap = await rtdb.ref('users/'+uid).once('value');
  var u = snap.val();
  if(!u){ document.getElementById('upName').innerText = 'مستخدم غير موجود'; document.getElementById('upGiftsList').innerHTML=''; document.getElementById('upVideosGrid').innerHTML=''; return; }
  var dn = u.displayName || u.username;
  if(u.photoURL){
    document.getElementById('upAvatar').style.cssText = 'width:120px;height:120px;font-size:44px;margin:0 auto 14px;background-image:url(\''+u.photoURL+'\');background-size:cover;background-position:center';
  }else{
    document.getElementById('upAvatar').innerHTML = esc(avatarLetter(dn));
  }
  document.getElementById('upName').innerHTML = nameWithBadge(dn, u.isVerified, u.activeBadgeColor, u.verifiedEmoji) + (u.isFinch ? ' <span class="finch-tag"><i class="fa-solid fa-shield-halved"></i> فنش</span>' : '');
  applyMoodRing('upAvatar', u.moodAura);
  document.getElementById('upUsername').innerText = u.username ? ('@'+u.username) : '';
  document.getElementById('upAbout').innerText = u.about || '';
  document.getElementById('upFollowersCount').innerText = u.followersCount || 0;
  document.getElementById('upFollowingCount').innerText = u.followingCount || 0;

  loadUserVideosForProfile(uid);

  var isSelf = uid === currentUser.uid;
  if(!isSelf){
    var ids = [currentUser.uid, uid].sort();
    var dmChatId = 'dm_'+ids[0]+'_'+ids[1];
    var isBlocked = !!blockedMap[uid];
    var followSnap = await rtdb.ref('following/'+currentUser.uid+'/'+uid).once('value');
    var isFollowing = !!followSnap.val();
    document.getElementById('upActionsRow').style.display = 'flex';
    document.getElementById('upActionsRow').innerHTML =
      '<button class="btn-neon '+(isFollowing?'':'btn-neon-fill')+'" onclick="toggleFollowUser(\''+uid+'\')"><i class="fa-solid '+(isFollowing?'fa-user-check':'fa-user-plus')+'"></i> '+(isFollowing?'متابَع':'متابعة')+'</button>'+
      '<button class="btn-neon" onclick="startDirectChat(\''+uid+'\',\''+esc(u.username)+'\');closePanel(\'userProfileScreen\')"><i class="fa-solid fa-message"></i> رسالة</button>'+
      '<button class="btn-neon '+(isBlocked?'':'btn-neon-danger')+'" onclick="toggleBlockByUid(\''+uid+'\')"><i class="fa-solid fa-ban"></i> '+(isBlocked?'إلغاء الحظر':'حظر')+'</button>'+
      '<button class="btn-neon btn-neon-danger" onclick="reportUserByUid(\''+uid+'\')"><i class="fa-solid fa-flag"></i> إبلاغ</button>';

    document.getElementById('upMuteSection').style.display = 'block';
    var muteSnap = await rtdb.ref('chats/'+dmChatId+'/mutedBy/'+currentUser.uid).once('value');
    document.getElementById('upMuteToggle').checked = !!muteSnap.val();
    document.getElementById('upMuteToggle').setAttribute('data-chat-id', dmChatId);

    document.getElementById('upMediaSection').style.display = 'block';
    var mediaGrid = document.getElementById('upMediaGrid');
    mediaGrid.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
    var msgsSnap = await rtdb.ref('messages/'+dmChatId).limitToLast(60).once('value');
    var mediaHtml = '';
    if(msgsSnap.exists()){
      var msgsObj = msgsSnap.val();
      Object.keys(msgsObj).forEach(function(mk){
        var m = msgsObj[mk];
        if(m.type==='image') mediaHtml += '<img src="'+m.mediaData+'" alt="">';
        else if(m.type==='video') mediaHtml += '<video src="'+m.mediaData+'" muted></video>';
      });
    }
    mediaGrid.innerHTML = mediaHtml || '<div class="empty-hint" style="grid-column:1/-1"><i class="fa-solid fa-image"></i>مفيش وسائط متبادلة لسه</div>';
  }

  var upGamesEl = document.getElementById('upGamesList');
  upGamesEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  try{
    var userGamesSnap = await rtdb.ref('games').orderByChild('authorId').equalTo(uid).once('value');
    var userGamesObj = userGamesSnap.exists() ? userGamesSnap.val() : {};
    var userGames = Object.keys(userGamesObj).map(function(k){ return Object.assign({id:k}, userGamesObj[k]); }).filter(function(g){ return g.status==='approved'; });
    userGames.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
    upGamesEl.innerHTML = userGames.length ? userGames.map(renderGameCardHTML).join('') : '<div class="empty-hint" style="grid-column:1/-1"><i class="fa-solid fa-gamepad"></i>لسه مفيش ألعاب منشورة</div>';
  }catch(err){
    upGamesEl.innerHTML = '<div class="empty-hint" style="grid-column:1/-1">تعذر تحميل الألعاب</div>';
  }

  var giftsSnap = await rtdb.ref('users/'+uid+'/profileGifts').once('value');
  var giftsEl = document.getElementById('upGiftsList');
  if(!giftsSnap.exists()){ giftsEl.className=''; giftsEl.innerHTML = '<div class="empty-hint">لسه مفيش هدايا في البروفايل</div>'; return; }
  var isMe = uid===currentUser.uid;
  var giftsObj = giftsSnap.val();
  giftsEl.className = 'profile-gift-showcase';
  giftsEl.innerHTML = Object.keys(giftsObj).map(function(gk){
    var pg = giftsObj[gk];
    var g = findGiftByKey(pg.key);
    var visual = (g && g.imageData) ? '<img src="'+g.imageData+'" alt="">' : (g?g.emoji:'🎁');
    var convertBtn = isMe ? '<button class="small-btn filled gconvert" onclick="convertProfileGift(\''+gk+'\',\''+pg.key+'\')">حوّلها لـ ZYROX</button>' : '';
    return '<div class="profile-gift-card"><span class="gicon">'+visual+'</span><div class="glabel">'+esc(pg.label)+'</div>'+convertBtn+'</div>';
  }).join('');
};

window.convertProfileGift = async function(giftEntryKey, giftKey){
  var g = findGiftByKey(giftKey);
  if(!g) return;
  var value = Math.round((g.price||0) * GIFT_CONVERT_RATIO);
  if(!confirm('تحويل الهدية دي لـ '+value+' ZYROX؟ الخطوة دي مش هترجع')) return;
  await rtdb.ref('users/'+currentUser.uid+'/exeCoins').transaction(function(cur){ return (cur||0) + value; });
  await rtdb.ref('users/'+currentUser.uid+'/profileGifts/'+giftEntryKey).remove();
  alert('تم التحويل، رصيدك اتزاد '+value+' ZYROX');
  window.openUserProfile(currentUser.uid);
};

/* ============ تفاعلات مميزة: بعت شارة التوثيق بتاعتك كتفاعل خاص ============ */
window.openBadgeShareModal = function(){
  if(!currentChatId || !currentChatData || currentChatData.type!=='direct'){ alert('التفاعل ده متاح بس في المحادثات الخاصة'); return; }
  var myTypes = badgeTypeOf(currentProfile.isVerified);
  if(!myTypes.length){ alert('التفاعل ده متاح بس للحسابات الموثّقة'); return; }
  if(confirm('تبعت شارة التوثيق بتاعتك كتفاعل مميز للطرف التاني؟ محدش هيقدر ينسخها إلا لو هو نفسه موثّق')){
    window.sendBadgeShare();
  }
};
window.sendBadgeShare = async function(){
  var myTypes = badgeTypeOf(currentProfile.isVerified);
  if(!myTypes.length || !currentChatId) return;
  await pushMessage(currentChatId, {type:'badgeShare', badgeType: myTypes[0]});
};

/* ============ GIFTS ============ */
window.openGiftModal = function(){
  if(!currentChatId){ alert('افتح محادثة الأول'); return; }
  if(!currentChatData || currentChatData.type!=='direct'){ alert('الهدايا متاحة بس في المحادثات الخاصة'); return; }
  document.getElementById('attachMenu').classList.remove('active');
  var myBalance = currentProfile.exeCoins||0;
  var balEl = document.getElementById('giftModalBalance'); if(balEl) balEl.innerText = myBalance;
  var grid = document.getElementById('giftGrid');
  grid.innerHTML = allGifts().map(function(g){
    var afford = myBalance >= g.price;
    var visual = g.imageData ? '<img src="'+g.imageData+'" style="width:30px;height:30px;border-radius:8px;object-fit:cover;display:block;margin:0 auto 6px">' : '<span class="gemoji">'+g.emoji+'</span>';
    return '<div class="gift-option'+(afford?'':' disabled')+'" style="'+(afford?'':'opacity:.4;cursor:not-allowed;')+'" onclick="'+(afford?('sendGift(\''+g.key+'\')'):'')+'">'+visual+'<span>'+esc(g.label)+'</span><span style="display:block;color:var(--warn);margin-top:3px">'+g.price+' ZYROX</span></div>';
  }).join('');
  document.getElementById('giftModal').classList.add('active');
};
window.sendGift = async function(key){
  var g = findGiftByKey(key);
  if(!g || !currentChatId || !currentChatData || currentChatData.type!=='direct') return;
  if((currentProfile.exeCoins||0) < g.price){ alert('رصيدك مش كافي لإرسال الهدية دي، محتاج '+g.price+' ZYROX'); return; }
  try{
    var balanceRef = rtdb.ref('users/'+currentUser.uid+'/exeCoins');
    var result = await balanceRef.transaction(function(cur){
      cur = cur||0;
      if(cur < g.price) return; // يلغي الترانزاكشن لو الرصيد اتغير وبقى مش كافي
      return cur - g.price;
    });
    if(!result.committed){ alert('رصيدك مش كافي لإرسال الهدية دي'); return; }
    currentProfile.exeCoins = result.snapshot.val();
    document.getElementById('walletBalance').innerText = (currentProfile.exeCoins||0) + ' ZYROX'; updateHeaderBalanceChip();
    window.closeModal('giftModal');
    await pushMessage(currentChatId, {type:'gift', giftKey:g.key, giftLabel:g.label, giftPrice:g.price, giftResolved:false});
  }catch(err){
    alert('تعذر إرسال الهدية، حاول تاني');
  }
};

/* المستلم يقرر: يحتفظ بالهدية في البروفايل أو يحوّلها لرصيد ZYROX */
window.resolveGift = async function(msgId, action){
  if(!currentChatId) return;
  var msgRef = rtdb.ref('messages/'+currentChatId+'/'+msgId);
  var snap = await msgRef.once('value');
  var m = snap.val();
  if(!m || m.type!=='gift' || m.giftResolved) return;
  if(m.senderId === currentUser.uid){ alert('مينفعش تتصرف في هدية بعتّها انت'); return; }
  var g = findGiftByKey(m.giftKey);
  if(action==='convert'){
    var value = Math.round((m.giftPrice||(g?g.price:0)) * GIFT_CONVERT_RATIO);
    var balanceRef = rtdb.ref('users/'+currentUser.uid+'/exeCoins');
    var result = await balanceRef.transaction(function(cur){ return (cur||0) + value; });
    currentProfile.exeCoins = result.snapshot.val();
    document.getElementById('walletBalance').innerText = (currentProfile.exeCoins||0) + ' ZYROX'; updateHeaderBalanceChip();
    await msgRef.update({ giftResolved:true, giftAction:'converted' });
    alert('تم تحويل الهدية إلى '+value+' ZYROX وإضافتها لرصيدك');
  }else{
    await rtdb.ref('users/'+currentUser.uid+'/profileGifts').push({
      key: m.giftKey, label: m.giftLabel, from: m.senderName||'', ts: firebase.database.ServerValue.TIMESTAMP
    });
    await msgRef.update({ giftResolved:true, giftAction:'kept' });
    alert('تم إضافة الهدية لبروفايلك 🎁');
  }
};

/* ============ VIEW-ONCE PHOTOS (فُل سكرين + متتفتحش تاني بعد الإغلاق) ============ */
window.openViewOnce = async function(id, el){
  try{
    var msgSnap = await rtdb.ref('messages/'+currentChatId+'/'+id).once('value');
    var m = msgSnap.val();
    if(!m || m.viewed) { alert('الصورة اتشافت قبل كده'); return; }
    // نسجّل إنها اتشافت فورًا (قبل ما تتقفل حتى) عشان محدش يقدر يفتحها تاني بأي طريقة
    await rtdb.ref('messages/'+currentChatId+'/'+id+'/viewed').set(true);
    el.outerHTML = '<div class="view-once-opened"><i class="fa-solid fa-eye-slash"></i><br>تم مشاهدة الصورة</div>';
    showViewOnceFullscreen(m.mediaData);
  }catch(err){ console.error(err); }
};

var voCloseTimer = null;
function showViewOnceFullscreen(dataUrl){
  var modal = document.getElementById('viewOnceModal');
  var img = document.getElementById('voImage');
  img.src = dataUrl;
  document.getElementById('voPrivacyShield').classList.remove('active');
  modal.classList.add('active');
  var secondsLeft = 12;
  var timerEl = document.getElementById('voTimer');
  timerEl.innerText = secondsLeft + ' ث';
  clearInterval(voCloseTimer);
  voCloseTimer = setInterval(function(){
    secondsLeft--;
    if(secondsLeft <= 0){ closeViewOnce(); return; }
    timerEl.innerText = secondsLeft + ' ث';
  }, 1000);
}
window.closeViewOnce = function(){
  clearInterval(voCloseTimer);
  voCloseTimer = null;
  var modal = document.getElementById('viewOnceModal');
  modal.classList.remove('active');
  document.getElementById('voImage').src = '';
  document.getElementById('voPrivacyShield').classList.remove('active');
};

/* ============ ZYROX WALLET ============ */
window.openWalletScreen = function(){
  document.getElementById('sideMenu').classList.remove('active');
  document.getElementById('walletBalance').innerText = (currentProfile.exeCoins||0) + ' ZYROX'; updateHeaderBalanceChip();
  document.getElementById('walletScreen').classList.add('active');
};
var DEV_USERNAMES = ['شيفو','شيفو11'];
window.contactDevForRecharge = function(){
  var listEl = document.getElementById('contactDevList');
  listEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  document.getElementById('contactDevModal').classList.add('active');
  renderContactDevList();
};
async function renderContactDevList(){
  var listEl = document.getElementById('contactDevList');
  var html = '';
  for(var i=0;i<DEV_USERNAMES.length;i++){
    var uname = DEV_USERNAMES[i];
    var idSnap = await rtdb.ref('usernames/'+uname.toLowerCase()).once('value');
    if(!idSnap.exists()) continue;
    var uid = idSnap.val();
    var uSnap = await rtdb.ref('users/'+uid).once('value');
    var u = uSnap.val();
    if(!u) continue;
    html += '<div class="item-card" onclick="startChatWithDev(\''+uid+'\',\''+esc(u.username)+'\')">'+
      avatarBlockHTML(u.displayName||u.username, u.photoURL, '')+
      '<div class="item-info"><h4>'+nameWithBadge(u.displayName||u.username, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h4><p>@'+esc(u.username)+'</p></div>'+
    '</div>';
  }
  listEl.innerHTML = html || '<div class="empty-hint">مفيش حسابات مطورين متاحة دلوقتي</div>';
}
window.startChatWithDev = function(uid, username){
  window.closeModal('contactDevModal');
  window.startDirectChat(uid, username);
};
