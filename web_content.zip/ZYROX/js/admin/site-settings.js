/* ZYROX — admin/site-settings.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ ADMIN: SITE SETTINGS ============ */
window.adminSaveSiteConfig = async function(){
  if(!currentProfile.isAdmin) return;
  var banned = document.getElementById('adminBannedWords').value.trim();
  var maintenance = document.getElementById('adminMaintenanceMode').checked;
  var allowSignups = document.getElementById('adminAllowSignups').checked;
  await rtdb.ref('siteConfig').update({ bannedWords: banned, maintenanceMode: maintenance, allowSignups: allowSignups });
  alert('اتحفظت إعدادات الموقع');
};
async function loadSiteConfigIntoAdmin(){
  var snap = await rtdb.ref('siteConfig').once('value');
  var cfg = snap.val() || {};
  var bw = document.getElementById('adminBannedWords'); if(bw) bw.value = cfg.bannedWords || '';
  var mm = document.getElementById('adminMaintenanceMode'); if(mm) mm.checked = !!cfg.maintenanceMode;
  var as = document.getElementById('adminAllowSignups'); if(as) as.checked = cfg.allowSignups!==false;
  var c1 = cfg.themeColor1 || THEME_COLOR1_DEFAULT;
  var c2 = cfg.themeColor2 || THEME_COLOR2_DEFAULT;
  var t1 = document.getElementById('adminThemeColor1'); if(t1) t1.value = c1;
  var t1h = document.getElementById('adminThemeColor1Hex'); if(t1h) t1h.value = c1;
  var t2 = document.getElementById('adminThemeColor2'); if(t2) t2.value = c2;
  var t2h = document.getElementById('adminThemeColor2Hex'); if(t2h) t2h.value = c2;
  var bg = document.getElementById('adminBalanceGrantAmount'); if(bg) bg.value = cfg.supportBalanceGrantAmount || SUPPORT_BALANCE_GRANT_DEFAULT;
}

/* ============ ADMIN: رفع تحديث المنصة (Self-Update) ============ */
async function loadAppUpdateInfoIntoAdmin(){
  var infoEl = document.getElementById('adminUpdateCurrentInfo');
  if(!infoEl) return;
  infoEl.textContent = 'جارٍ التحميل...';
  try{
    var snap = await rtdb.ref('appUpdate').once('value');
    var u = snap.val() || {};
    var remoteVersion = u.version || 0;
    var sizeKb = u.size ? Math.round(u.size/1024) : 0;
    var when = u.uploadedAt ? new Date(u.uploadedAt).toLocaleString('ar-EG') : '—';
    infoEl.innerHTML = remoteVersion ?
      ('فيه تحديث شغّال حاليًا (رقم '+remoteVersion+')'+(sizeKb?(' - '+sizeKb+' KB'):'')+'<br>آخر رفع: '+when+(u.uploadedBy?(' بواسطة '+u.uploadedBy):'')) :
      'مفيش تحديث مرفوع دلوقتي — كل المستخدمين شغّالين بنسخة الموقع الأساسية.';
  }catch(e){
    infoEl.textContent = 'تعذر تحميل بيانات التحديث الحالية.';
  }
}
window.adminResetAppUpdate = async function(){
  if(!currentProfile.isAdmin) return;
  if(!confirm('هيتم حذف آخر تحديث اترفع نهائيًا، وكل المستخدمين هيرجعوا يشتغلوا بنسخة الموقع الأساسية (نسخة '+APP_LOCAL_VERSION+') من غير أي أثر للتحديث القديم. أي تحديث جديد بعد كده هيبقى تحديث جديد تمامًا. متأكد؟')) return;
  try{
    await rtdb.ref('appUpdate').remove();
    document.getElementById('adminUpdateResetInfo').textContent = 'تم إلغاء التحديث. كل المستخدمين هيرجعوا للنسخة الأساسية أول ما يفتحوا التطبيق تاني.';
    loadAppUpdateInfoIntoAdmin();
  }catch(e){
    alert('تعذر إلغاء التحديث، حاول تاني: ' + (e && e.message ? e.message : e));
  }
};

window.adminUploadAppUpdate = async function(){
  if(!currentProfile.isAdmin) return;
  var fileInput = document.getElementById('adminUpdateFileInput');
  var btn = document.getElementById('adminUpdateUploadBtn');
  var file = fileInput && fileInput.files && fileInput.files[0];
  if(!file){ alert('اختار ملف HTML الأول'); return; }
  btn.disabled = true;
  var originalBtnHtml = btn.innerHTML;
  btn.innerHTML = '<span class="spinner"></span> جارٍ الرفع...';
  try{
    var content = await new Promise(function(resolve, reject){
      var reader = new FileReader();
      reader.onload = function(){ resolve(reader.result); };
      reader.onerror = function(){ reject(reader.error); };
      reader.readAsText(file, 'utf-8');
    });
    if(!content || content.length < 200 || content.indexOf('<html')===-1){
      alert('الملف ده مش شكله ملف HTML سليم، اتأكد منه وحاول تاني');
      return;
    }
    // رقم النسخة بقى بيتحسب تلقائيًا (آخر رقم مرفوع + 1) — مفيش داعي إن الملف نفسه
    // يحتوي على APP_LOCAL_VERSION ولا إن الأدمن يعدّل أي رقم بإيده
    var remoteSnap = await rtdb.ref('appUpdate/version').once('value');
    var remoteVersion = remoteSnap.val() || 0;
    var newVersion = Math.max(remoteVersion, APP_LOCAL_VERSION) + 1;
    if(!confirm('متأكد إنك عايز ترفع الملف ده كتحديث؟ كل المستخدمين هيشتغلوا بيه تلقائيًا بمجرد ما يفتحوا التطبيق تاني.')) return;
    await rtdb.ref('appUpdate').set({
      version: newVersion,
      content: content,
      size: content.length,
      uploadedAt: firebase.database.ServerValue.TIMESTAMP,
      uploadedBy: currentProfile.username || 'admin'
    });
    alert('تم رفع التحديث بنجاح (نسخة '+newVersion+'). كل المستخدمين هيتحوّلوا للنسخة الجديدة تلقائيًا.');
    fileInput.value = '';
    loadAppUpdateInfoIntoAdmin();
  }catch(e){
    console.error(e);
    alert('حصل خطأ أثناء رفع التحديث: ' + (e && e.message ? e.message : e));
  }finally{
    btn.disabled = false;
    btn.innerHTML = originalBtnHtml;
  }
};

/* ============ ADMIN: THEME COLORS ============ */
window.syncThemeColorFromPicker = function(key){
  var picker = document.getElementById('adminTheme'+key);
  var hex = document.getElementById('adminTheme'+key+'Hex');
  if(picker && hex) hex.value = picker.value;
};
window.syncThemeColorFromHex = function(key){
  var hex = document.getElementById('adminTheme'+key+'Hex');
  var picker = document.getElementById('adminTheme'+key);
  if(!hex || !picker) return;
  var v = hex.value.trim();
  if(/^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(v)) picker.value = v;
};
window.adminSaveThemeColors = async function(){
  if(!currentProfile.isAdmin) return;
  var hexRe = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/;
  var c1 = document.getElementById('adminThemeColor1Hex').value.trim() || THEME_COLOR1_DEFAULT;
  var c2 = document.getElementById('adminThemeColor2Hex').value.trim() || THEME_COLOR2_DEFAULT;
  if(!hexRe.test(c1) || !hexRe.test(c2)){ alert('كود اللون لازم يكون بصيغة صحيحة زي #1ED760'); return; }
  try{
    await rtdb.ref('siteConfig').update({ themeColor1: c1, themeColor2: c2 });
    alert('اتغيرت ألوان المنصة لكل المستخدمين بنجاح');
  }catch(err){
    alert('تعذر حفظ الألوان، حاول تاني');
  }
};
window.adminResetThemeColors = async function(){
  if(!currentProfile.isAdmin) return;
  if(!confirm('استرجاع الألوان الافتراضية لكل المستخدمين؟')) return;
  try{
    await rtdb.ref('siteConfig').update({ themeColor1: THEME_COLOR1_DEFAULT, themeColor2: THEME_COLOR2_DEFAULT });
    document.getElementById('adminThemeColor1').value = THEME_COLOR1_DEFAULT;
    document.getElementById('adminThemeColor1Hex').value = THEME_COLOR1_DEFAULT;
    document.getElementById('adminThemeColor2').value = THEME_COLOR2_DEFAULT;
    document.getElementById('adminThemeColor2Hex').value = THEME_COLOR2_DEFAULT;
    alert('رجعت الألوان الافتراضية');
  }catch(err){
    alert('تعذر الاسترجاع، حاول تاني');
  }
};
