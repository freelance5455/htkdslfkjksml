/* ZYROX — admin/admin-phrases-and-reset.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ ADMIN: BAN TRIGGER PHRASES ============ */
function renderAdminBanPhrasesListIfVisible(){
  var el = document.getElementById('adminBanPhrasesList');
  if(!el || !currentProfile || !currentProfile.isAdmin) return;
  var keys = Object.keys(banPhrasesCache);
  if(keys.length===0){ el.innerHTML = '<div class="empty-hint">مفيش جمل باند محفوظة</div>'; return; }
  el.innerHTML = keys.map(function(k){
    return '<div class="admin-games-card"><div class="agc-info" style="flex:1"><h5>'+esc(banPhrasesCache[k].text||'')+'</h5></div>'+
      '<div class="agc-btns"><button class="small-btn danger" onclick="adminRemoveBanPhrase(\''+k+'\')"><i class="fa-solid fa-xmark"></i></button></div></div>';
  }).join('');
}
window.adminAddBanPhrase = async function(){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('adminBanPhraseInput');
  var text = input.value.trim();
  if(!text){ alert('اكتب الكلمة أو الجملة الأول'); return; }
  try{
    await rtdb.ref('banTriggerPhrases').push({ text: text, ts: firebase.database.ServerValue.TIMESTAMP });
    input.value='';
  }catch(err){
    alert('تعذر إضافة الجملة، حاول تاني');
  }
};
window.adminRemoveBanPhrase = async function(key){
  if(!currentProfile.isAdmin) return;
  if(!confirm('تمسح الجملة دي من قائمة الباند التلقائي؟')) return;
  try{
    await rtdb.ref('banTriggerPhrases/'+key).remove();
  }catch(err){
    alert('تعذر حذف الجملة، حاول تاني');
  }
};

function renderAdminUnbanPhrasesListIfVisible(){
  var el = document.getElementById('adminUnbanPhrasesList');
  if(!el || !currentProfile || !currentProfile.isAdmin) return;
  var keys = Object.keys(unbanPhrasesCache);
  if(keys.length===0){ el.innerHTML = '<div class="empty-hint">مفيش جمل فك باند محفوظة</div>'; return; }
  el.innerHTML = keys.map(function(k){
    return '<div class="admin-games-card"><div class="agc-info" style="flex:1"><h5>'+esc(unbanPhrasesCache[k].text||'')+'</h5></div>'+
      '<div class="agc-btns"><button class="small-btn danger" onclick="adminRemoveUnbanPhrase(\''+k+'\')"><i class="fa-solid fa-xmark"></i></button></div></div>';
  }).join('');
}
window.adminAddUnbanPhrase = async function(){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('adminUnbanPhraseInput');
  var text = input.value.trim();
  if(!text){ alert('اكتب الكلمة أو الجملة الأول'); return; }
  try{
    await rtdb.ref('unbanTriggerPhrases').push({ text: text, ts: firebase.database.ServerValue.TIMESTAMP });
    input.value='';
  }catch(err){
    alert('تعذر إضافة الجملة، حاول تاني');
  }
};
window.adminRemoveUnbanPhrase = async function(key){
  if(!currentProfile.isAdmin) return;
  if(!confirm('تمسح الجملة دي من قائمة فك الباند التلقائي؟')) return;
  try{
    await rtdb.ref('unbanTriggerPhrases/'+key).remove();
  }catch(err){
    alert('تعذر حذف الجملة، حاول تاني');
  }
};

function renderAdminVerifyPhrasesListIfVisible(){
  var el = document.getElementById('adminVerifyPhrasesList');
  if(!el || !currentProfile || !currentProfile.isAdmin) return;
  var keys = Object.keys(verifyPhrasesCache);
  if(keys.length===0){ el.innerHTML = '<div class="empty-hint">مفيش جمل توثيق محفوظة</div>'; return; }
  el.innerHTML = keys.map(function(k){
    return '<div class="admin-games-card"><div class="agc-info" style="flex:1"><h5>'+esc(verifyPhrasesCache[k].text||'')+'</h5></div>'+
      '<div class="agc-btns"><button class="small-btn danger" onclick="adminRemoveVerifyPhrase(\''+k+'\')"><i class="fa-solid fa-xmark"></i></button></div></div>';
  }).join('');
}
window.adminAddVerifyPhrase = async function(){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('adminVerifyPhraseInput');
  var text = input.value.trim();
  if(!text){ alert('اكتب الكلمة أو الجملة الأول'); return; }
  try{
    await rtdb.ref('verifyTriggerPhrases').push({ text: text, ts: firebase.database.ServerValue.TIMESTAMP });
    input.value='';
  }catch(err){
    alert('تعذر إضافة الجملة، حاول تاني');
  }
};
window.adminRemoveVerifyPhrase = async function(key){
  if(!currentProfile.isAdmin) return;
  if(!confirm('تمسح الجملة دي من قائمة التوثيق التلقائي؟')) return;
  try{
    await rtdb.ref('verifyTriggerPhrases/'+key).remove();
  }catch(err){
    alert('تعذر حذف الجملة، حاول تاني');
  }
};

function renderAdminBalancePhrasesListIfVisible(){
  var el = document.getElementById('adminBalancePhrasesList');
  if(!el || !currentProfile || !currentProfile.isAdmin) return;
  var keys = Object.keys(balancePhrasesCache);
  if(keys.length===0){ el.innerHTML = '<div class="empty-hint">مفيش جمل رصيد محفوظة</div>'; return; }
  el.innerHTML = keys.map(function(k){
    return '<div class="admin-games-card"><div class="agc-info" style="flex:1"><h5>'+esc(balancePhrasesCache[k].text||'')+'</h5></div>'+
      '<div class="agc-btns"><button class="small-btn danger" onclick="adminRemoveBalancePhrase(\''+k+'\')"><i class="fa-solid fa-xmark"></i></button></div></div>';
  }).join('');
}
window.adminAddBalancePhrase = async function(){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('adminBalancePhraseInput');
  var text = input.value.trim();
  if(!text){ alert('اكتب الكلمة أو الجملة الأول'); return; }
  try{
    await rtdb.ref('balanceTriggerPhrases').push({ text: text, ts: firebase.database.ServerValue.TIMESTAMP });
    input.value='';
  }catch(err){
    alert('تعذر إضافة الجملة، حاول تاني');
  }
};
window.adminRemoveBalancePhrase = async function(key){
  if(!currentProfile.isAdmin) return;
  if(!confirm('تمسح الجملة دي من قائمة الرصيد التلقائي؟')) return;
  try{
    await rtdb.ref('balanceTriggerPhrases/'+key).remove();
  }catch(err){
    alert('تعذر حذف الجملة، حاول تاني');
  }
};
window.adminSaveBalanceGrantAmount = async function(){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('adminBalanceGrantAmount');
  var amount = parseInt(input.value, 10);
  if(!amount || amount<=0){ alert('اكتب رقم صحيح أكبر من صفر'); return; }
  try{
    await rtdb.ref('siteConfig/supportBalanceGrantAmount').set(amount);
    alert('اتحفظت قيمة الرصيد اللي هيتضاف تلقائيًا');
  }catch(err){
    alert('تعذر الحفظ، حاول تاني');
  }
};

window.adminDeleteAllGames = async function(){
  if(!currentProfile.isAdmin) return;
  if(!confirm('هيتم حذف كل الألعاب (المعروضة والمنتظرة المراجعة والمرفوضة) نهائيًا من التطبيق. الخطوة دي مش هترجع. متأكد؟')) return;
  try{
    await rtdb.ref('games').remove();
    await rtdb.ref('gamesContent').remove();
    alert('تم حذف كل الألعاب بنجاح');
    if(document.getElementById('gamesGrid')) loadGamesFeed();
    if(document.getElementById('adminGamesList')) renderAdminGamesList();
  }catch(err){
    alert('تعذر حذف الألعاب، حاول تاني');
  }
};

window.adminApproveGame = async function(gameId){
  if(!currentProfile.isAdmin) return;
  await rtdb.ref('games/'+gameId).update({ status:'approved', approvedAt: firebase.database.ServerValue.TIMESTAMP });
  showBlackToast('تمت الموافقة على اللعبة');
  renderAdminGamesList();
};

window.adminRejectGame = async function(gameId){
  if(!currentProfile.isAdmin) return;
  if(!confirm('متأكد إنك عايز ترفض اللعبة دي؟')) return;
  await rtdb.ref('games/'+gameId).update({ status:'rejected' });
  showBlackToast('تم رفض اللعبة');
  renderAdminGamesList();
};

/* ============ إعادة تعيين الموقع بالكامل (Danger Zone) ============ */
window.adminResetEntireSite = async function(){
  if(!currentProfile.isAdmin) return;
  if(!confirm('تحذير خطير: هيتم حذف كل المستخدمين والحسابات والشاتات والرسايل والمنشورات والفيديوهات والألعاب وكل بيانات الموقع نهائيًا، وهيرجع الموقع فاضي زي أول يوم. حساب الأدمن الرسمي (شيفو) بس هو اللي هيفضل موجود. الخطوة دي نهائية ومفيش رجوع فيها. متأكد؟')) return;
  var typed = prompt('اكتب الكلمة "متأكد" بالظبط عشان تأكيد الحذف الكامل النهائي:');
  if(typed !== 'متأكد'){ alert('اتلغت العملية، لازم تكتب الكلمة بالظبط.'); return; }

  var nodesToWipe = ['announcements','banAppeals','banPhraseState','banTriggerPhrases','bans','blocked','bots',
    'chats','customGifts','deletedUsers','followers','following','friendRequests','friends','games','gamesContent',
    'groupInvites','hostingUploads','lastRead','messages','postComments','posts','presence','reports','statuses',
    'supportMessages','supportThreads','typing','unbanTriggerPhrases','userChats','usernames','users',
    'verifyTriggerPhrases','warnings'];

  showUploadOverlay('جارٍ إعادة تعيين الموقع بالكامل...', 'من فضلك ماتقفلش الصفحة، العملية دي ممكن تاخد شوية وقت');
  try{
    for(var i=0;i<nodesToWipe.length;i++){
      await rtdb.ref(nodesToWipe[i]).remove();
    }
    // نعيد إنشاء حساب الأدمن الرسمي (شيفو) بس عشان الجلسة الحالية تفضل شغالة والموقع مايبقاش من غير أدمن خالص
    var meUid = currentUser.uid;
    var freshProfile = {
      username: currentProfile.username || 'شيفو',
      usernameLower: currentProfile.usernameLower || 'شيفو',
      displayName: currentProfile.displayName || 'شيفو',
      about: 'الأدمن الرسمي لـ ZYROX',
      loginType: currentProfile.loginType || 'username',
      settings: currentProfile.settings || { lastSeen:'everyone', notifications:true, sound:true, readReceipts:true,
        notifPreview:true, profilePhotoPrivacy:'everyone', aboutPrivacy:'everyone', groupAddPrivacy:'everyone',
        autoDownloadMedia:true, typingIndicator:true },
      photoURL: null, isVerified: true, isAdmin: true, exeCoins: 0,
      createdAt: firebase.database.ServerValue.TIMESTAMP
    };
    await rtdb.ref('users/'+meUid).set(freshProfile);
    await rtdb.ref('usernames/'+freshProfile.usernameLower).set(meUid);
    hideUploadOverlay();
    alert('تم تصفير الموقع بالكامل بنجاح. الموقع دلوقتي فاضي وجاهز يبدأ من جديد، وحساب الأدمن الرسمي (شيفو) لسه شغال.');
    location.reload();
  }catch(err){
    hideUploadOverlay();
    alert('حصل خطأ أثناء التصفير — ممكن يكون جزء اتمسح وجزء لأ. تأكد إن قواعد الأمان (Security Rules) في Firebase بتسمح للأدمن بالحذف من الجذر، وحاول تاني.');
  }
};
