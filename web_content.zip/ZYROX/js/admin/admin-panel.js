/* ZYROX — admin/admin-panel.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ REPORTS ============ */
window.reportCurrentChatUser = async function(){
  if(!currentChatData || currentChatData.type!=='direct') return;
  var otherUid = Object.keys(currentChatData.members).find(function(k){ return k!==currentUser.uid; });
  if(!otherUid) return;
  var reason = prompt('اكتب سبب البلاغ (اختياري):') || '';
  try{
    await rtdb.ref('reports/'+otherUid+'/'+currentUser.uid).set({ reason: reason, ts: firebase.database.ServerValue.TIMESTAMP });
    var sampleText = await collectRecentUserMessages(currentChatId, otherUid, 1); // الذكاء الاصطناعي بيشوف آخر رسالة بس، مش الشات كله
    var combined = (reason ? ('سبب البلاغ: '+reason+'\n') : '') + (sampleText ? ('رسائل المستخدم في الشات:\n'+sampleText) : '');
    await applyReportOutcome(otherUid, reason, combined);
  }catch(err){
    alert('تعذر إرسال البلاغ، حاول تاني');
  }
};

/* ============ ADMIN PANEL ============ */
window.openAdminScreen = function(){
  if(!currentProfile.isAdmin){ alert('الصفحة دي للأدمن بس'); return; }
  document.getElementById('sideMenu').classList.remove('active');
  document.getElementById('adminUserResult').innerHTML='';
  document.getElementById('adminSearchInput').value='';
  document.getElementById('adminBroadcastText').value='';
  document.getElementById('adminScreen').classList.add('active');
  renderDeletedUsersList();
  renderAdminStats();
  renderTopReports();
  populateAdminProfileSec();
  populateAdminAIConfig();
  loadSiteConfigIntoAdmin();
  loadAppUpdateInfoIntoAdmin();
  renderAdminGamesList();
  renderAdminBanPhrasesListIfVisible();
  renderAdminUnbanPhrasesListIfVisible();
  renderAdminVerifyPhrasesListIfVisible();
  renderAdminBalancePhrasesListIfVisible();
};

async function populateAdminProfileSec(){
  if(!currentProfile.isAdmin) return;
  var snap = await rtdb.ref('appConfig/ai').once('value');
  var cfg = snap.val() || {};
  document.getElementById('adminProfileName').value = cfg.botName || 'ZYROX';
  document.getElementById('adminProfileAbout').value = cfg.botAbout || 'مدعوم بالذكاء الاصطناعي';
  document.getElementById('adminProfileVerified').checked = !!cfg.botVerified;
  document.getElementById('adminProfileWelcome').value = cfg.welcomeMessage || 'أهلاً بيك يا {username} في ZYROX 🎉\nمبسوطين إنك انضممت لينا. لو عندك أي سؤال أو محتاج مساعدة في أي وقت، ابعتلي هنا وأنا موجود.';
  var preview = document.getElementById('adminProfileAvatarPreview');
  if(cfg.photoURL){
    preview.style.cssText='width:74px;height:74px;font-size:26px;background-image:url(\''+cfg.photoURL+'\');background-size:cover;background-position:center';
    preview.innerHTML='';
  }else{
    preview.style.cssText='width:74px;height:74px;font-size:26px';
    preview.innerHTML='<i class="fa-solid fa-robot"></i>';
  }
}

window.adminUploadBotPhoto = function(input){
  if(!currentProfile.isAdmin) return;
  var file = input.files && input.files[0];
  if(!file) return;
  if(file.size > 6*1024*1024){ alert('الصورة كبيرة، اختار صورة أصغر من 6 ميجا'); return; }
  readFileAsDataURL(file, async function(dataUrl){
    try{
      await rtdb.ref('appConfig/ai/photoURL').set(dataUrl);
      await rtdb.ref('appConfig/ai/updatedBy').set(currentProfile.username);
      var preview = document.getElementById('adminProfileAvatarPreview');
      preview.style.cssText='width:74px;height:74px;font-size:26px;background-image:url(\''+dataUrl+'\');background-size:cover;background-position:center';
      preview.innerHTML='';
      showBlackToast('تم تغيير الصورة بنجاح');
    }catch(err){
      alert('تعذر رفع الصورة، حاول تاني');
    }
  });
};

window.adminSaveBotProfile = async function(){
  if(!currentProfile.isAdmin) return;
  var name = document.getElementById('adminProfileName').value.trim() || 'ZYROX';
  var about = document.getElementById('adminProfileAbout').value.trim() || 'مدعوم بالذكاء الاصطناعي';
  var verified = document.getElementById('adminProfileVerified').checked;
  var welcome = document.getElementById('adminProfileWelcome').value.trim() || 'أهلاً بيك يا {username} في ZYROX 🎉';
  await rtdb.ref('appConfig/ai').update({
    botName: name, botAbout: about, botVerified: verified, welcomeMessage: welcome,
    updatedBy: currentProfile.username, updatedAt: firebase.database.ServerValue.TIMESTAMP
  });
  showBlackToast('تم حفظ البروفايل بنجاح');
};

async function populateAdminAIConfig(){
  if(!currentProfile.isAdmin) return;
  var snap = await rtdb.ref('appConfig/ai').once('value');
  var cfg = snap.val() || {};
  document.getElementById('adminAiKey').value = cfg.apiKey || GROQ_API_KEY_DEFAULT;
  document.getElementById('adminAiModel').value = cfg.model || GROQ_MODEL_DEFAULT;
}

window.adminSaveAIConfig = async function(){
  if(!currentProfile.isAdmin) return;
  var key = document.getElementById('adminAiKey').value.trim();
  var model = document.getElementById('adminAiModel').value.trim();
  if(!key || !model){ alert('اكتب المفتاح واسم الموديل'); return; }
  await rtdb.ref('appConfig/ai').update({ apiKey: key, model: model, updatedBy: currentProfile.username, updatedAt: firebase.database.ServerValue.TIMESTAMP });
  alert('تم تحديث إعدادات الذكاء الاصطناعي، وهتتطبق فورًا على كل المستخدمين 🎻');
};

window.adminResetAIConfig = async function(){
  if(!currentProfile.isAdmin) return;
  if(!confirm('هترجع إعدادات الذكاء الاصطناعي (المفتاح والموديل) للوضع الأصلي الافتراضي. متأكد؟')) return;
  await rtdb.ref('appConfig/ai').update({ apiKey: GROQ_API_KEY_DEFAULT, model: GROQ_MODEL_DEFAULT, updatedBy: currentProfile.username, updatedAt: firebase.database.ServerValue.TIMESTAMP });
  document.getElementById('adminAiKey').value = GROQ_API_KEY_DEFAULT;
  document.getElementById('adminAiModel').value = GROQ_MODEL_DEFAULT;
  showBlackToast('اترجعت إعدادات الذكاء الاصطناعي للوضع الأصلي');
};

window.renderAdminStats = async function(){
  var el = document.getElementById('adminStatsGrid');
  if(!el || !currentProfile.isAdmin) return;
  try{
    var usersSnap = await rtdb.ref('users').once('value');
    var chatsSnap = await rtdb.ref('chats').once('value');
    var bansSnap = await rtdb.ref('bans').once('value');
    var deletedSnap = await rtdb.ref('deletedUsers').once('value');
    var messagesSnap = await rtdb.ref('messages').once('value');
    var usersCount = usersSnap.exists() ? Object.keys(usersSnap.val()).length : 0;
    var messagesVal = messagesSnap.val() || {};
    var messagesCount = 0;
    Object.keys(messagesVal).forEach(function(chatId){
      messagesCount += Object.keys(messagesVal[chatId]).length;
    });
    var chatsVal = chatsSnap.val() || {};
    var directCount=0, groupCount=0;
    Object.keys(chatsVal).forEach(function(k){
      if(chatsVal[k].type==='group') groupCount++;
      else if(chatsVal[k].type==='direct') directCount++;
    });
    var bansVal = bansSnap.val() || {};
    var activeBans = Object.keys(bansVal).filter(function(uid){
      var b = bansVal[uid];
      return b.permanent || (b.until && b.until > Date.now());
    }).length;
    var deletedCount = deletedSnap.exists() ? Object.keys(deletedSnap.val()).length : 0;
    el.innerHTML =
      '<div class="admin-stat-card"><div class="num">'+usersCount+'</div><div class="lbl">إجمالي المستخدمين</div></div>'+
      '<div class="admin-stat-card"><div class="num">'+messagesCount+'</div><div class="lbl">إجمالي الرسائل</div></div>'+
      '<div class="admin-stat-card"><div class="num">'+directCount+'</div><div class="lbl">شاتات فردية</div></div>'+
      '<div class="admin-stat-card"><div class="num">'+groupCount+'</div><div class="lbl">جروبات</div></div>'+
      '<div class="admin-stat-card"><div class="num">'+activeBans+'</div><div class="lbl">حسابات محظورة حاليًا</div></div>'+
      '<div class="admin-stat-card"><div class="num">'+deletedCount+'</div><div class="lbl">حسابات محذوفة</div></div>';
  }catch(err){
    el.innerHTML = '<div class="empty-hint">تعذر تحميل الإحصائيات</div>';
  }
};

window.renderTopReports = async function(){
  var el = document.getElementById('adminTopReportsList');
  if(!el || !currentProfile.isAdmin) return;
  try{
    var repSnap = await rtdb.ref('reports').once('value');
    var repVal = repSnap.val();
    if(!repVal){ el.innerHTML = '<div class="empty-hint">مفيش بلاغات حاليًا</div>'; return; }
    var rows = Object.keys(repVal).map(function(uid){
      return { uid: uid, count: Object.keys(repVal[uid]).length };
    }).filter(function(r){ return r.count>0; })
      .sort(function(a,b){ return b.count - a.count; })
      .slice(0,5);
    if(rows.length===0){ el.innerHTML = '<div class="empty-hint">مفيش بلاغات حاليًا</div>'; return; }
    var html='';
    for(var i=0;i<rows.length;i++){
      var uSnap = await rtdb.ref('users/'+rows[i].uid).once('value');
      var u = uSnap.val();
      if(!u) continue;
      html += '<div class="item-card" onclick="adminOpenFromReports(\''+esc(u.username)+'\')">'+
        avatarBlockHTML(u.displayName||u.username, u.photoURL, '')+
        '<div class="item-info"><h4>'+nameWithBadge(u.displayName||u.username, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h4><p>@'+esc(u.username)+'</p></div>'+
        '<span class="badge-dot" style="position:static">'+rows[i].count+'</span>'+
      '</div>';
    }
    el.innerHTML = html || '<div class="empty-hint">مفيش بلاغات حاليًا</div>';
  }catch(err){
    el.innerHTML = '<div class="empty-hint">تعذر تحميل البلاغات</div>';
  }
};

window.adminDeleteAllPosts = async function(){
  if(!currentProfile.isAdmin) return;
  if(!confirm('هيتم حذف كل المنشورات وكل التعليقات عليها نهائيًا من التطبيق. الخطوة دي مش هترجع. متأكد؟')) return;
  try{
    await rtdb.ref('posts').remove();
    await rtdb.ref('postComments').remove();
    alert('تم حذف كل المنشورات بنجاح');
    if(document.getElementById('postsFeed')) loadPostsFeed(true);
    if(document.getElementById('videosFeed')) loadVideosFeed(true);
    if(document.getElementById('gamesGrid')) loadGamesFeed();
  }catch(err){
    alert('تعذر حذف المنشورات، حاول تاني');
  }
};

/* ============ رفع شهرة الفيديو: الأدمن يحط رابط الفيديو + عدد اللايكات المستهدف، وبيتضبط فورًا ============ */
window.adminBoostVideoFame = async function(){
  if(!currentProfile.isAdmin) return;
  var linkEl = document.getElementById('adminBoostVideoLink');
  var likesEl = document.getElementById('adminBoostVideoLikes');
  var linkRaw = (linkEl.value||'').trim();
  var targetRaw = (likesEl.value||'').trim();
  if(!linkRaw){ alert('حط رابط الفيديو الأول'); return; }
  var target = parseInt(targetRaw, 10);
  if(isNaN(target) || target < 0){ alert('حط عدد لايكات صحيح'); return; }
  var postId = extractVideoIdFromShareInput(linkRaw);
  if(!postId){ alert('مش قادر أفهم الرابط ده، الصق رابط المشاركة زي ما هو'); return; }
  try{
    var snap = await rtdb.ref('posts/'+postId).once('value');
    var p = snap.val();
    if(!p){ alert('الفيديو ده مش موجود'); return; }
    var likesObj = p.likes || {};
    var boostKeys = Object.keys(likesObj).filter(function(k){ return k.indexOf('boost_')===0; });
    var currentTotal = Object.keys(likesObj).length;
    var updates = {};
    if(target > currentTotal){
      var need = target - currentTotal;
      for(var i=0;i<need;i++){
        updates['posts/'+postId+'/likes/boost_'+Date.now()+'_'+i+'_'+Math.random().toString(36).slice(2,7)] = true;
      }
    }else if(target < currentTotal){
      var removeCount = currentTotal - target;
      var toRemove = boostKeys.slice(0, Math.min(removeCount, boostKeys.length));
      toRemove.forEach(function(k){ updates['posts/'+postId+'/likes/'+k] = null; });
      if(toRemove.length < removeCount){
        alert('تنبيه: مش هقدر أنزل العدد أكتر من كده لأن الباقي لايكات حقيقية من مستخدمين فعليين.');
      }
    }
    if(Object.keys(updates).length){
      await rtdb.ref().update(updates);
    }
    alert('تم! لايكات الفيديو بقت تقريبًا '+target+' فورًا.');
    linkEl.value=''; likesEl.value='';
    if(document.getElementById('videosFeed')) loadVideosFeed(true);
    if(document.getElementById('postsFeed')) loadPostsFeed(true);
  }catch(err){
    alert('حصل خطأ، حاول تاني');
  }
};

window.adminOpenFromReports = function(username){
  document.getElementById('adminSearchInput').value = username;
  window.adminSearchUser();
};

window.adminSearchUser = async function(){
  if(!currentProfile.isAdmin) return;
  var uname = document.getElementById('adminSearchInput').value.trim().toLowerCase();
  var resultEl = document.getElementById('adminUserResult');
  if(!uname){ resultEl.innerHTML=''; return; }
  resultEl.innerHTML = '<div class="loading-msg">جارٍ البحث...</div>';
  try{
    var idRes = await dbGetWithTimeout(rtdb.ref('usernames/'+uname), 22000);
    if(idRes.timedOut){ resultEl.innerHTML = '<div class="empty-hint">الاتصال بطيء أو مفيش نت، حاول تاني</div>'; return; }
    if(!idRes.val){ resultEl.innerHTML = '<div class="empty-hint">مفيش مستخدم بالاسم ده</div>'; return; }
    var uid = idRes.val;
    await renderAdminUserCard(uid);
  }catch(err){
    resultEl.innerHTML = '<div class="empty-hint">حصل خطأ في البحث</div>';
  }
};

async function renderAdminUserCard(uid){
  var resultEl = document.getElementById('adminUserResult');
  var uRes = await dbGetWithTimeout(rtdb.ref('users/'+uid), 22000);
  if(uRes.timedOut){ resultEl.innerHTML = '<div class="empty-hint">الاتصال بطيء أو مفيش نت، حاول تاني</div>'; return; }
  var u = uRes.val;
  if(!u){ resultEl.innerHTML = '<div class="empty-hint">الحساب مش موجود</div>'; return; }
  var isProtected = isProtectedAdminUser(u);
  var banSnap = await rtdb.ref('bans/'+uid).once('value');
  var ban = banSnap.val();
  var isBanned = ban && (ban.permanent || (ban.until && ban.until > Date.now()));
  var banStatusHtml = isBanned
    ? '<div class="ban-status banned"><i class="fa-solid fa-ban"></i> محظور '+(ban.permanent?'بشكل دائم':('حتى '+new Date(ban.until).toLocaleString('ar-EG')))+'</div>'
    : '<div class="ban-status ok"><i class="fa-solid fa-circle-check"></i> غير محظور</div>';
  var curBadgeTypes = badgeTypeOf(u.isVerified);
  var verifyPickerHtml = '<div class="admin-badge-row" style="margin-bottom:8px">'+
      ['red','green','blue'].map(function(t){
        var cfg = BADGE_TYPES[t];
        var active = curBadgeTypes.indexOf(t)!==-1;
        return '<button class="small-btn'+(active?' filled':'')+'" style="'+(active?('background:'+cfg.color+';border-color:'+cfg.color+';color:#08050f;'):('color:'+cfg.color+';border-color:'+cfg.color))+'" onclick="adminSetVerify(\''+uid+'\',\''+t+'\')"><i class="fa-solid fa-circle-check"></i> '+cfg.title+'</button>';
      }).join('')+
    '</div>';
  var actionsHtml = isProtected
    ? verifyPickerHtml+'<div class="admin-badge-row">'+
        '<span class="small-btn filled" style="cursor:default"><i class="fa-solid fa-shield-halved"></i> الأدمن الأساسي (محصّن)</span>'+
      '</div>'
    : verifyPickerHtml+'<div class="admin-badge-row">'+
        '<button class="small-btn'+(u.isAdmin?' filled':'')+'" onclick="adminToggleAdmin(\''+uid+'\','+(!u.isAdmin)+')">'+(u.isAdmin?'إلغاء صلاحية الأدمن':'تعيين كأدمن 🛡️')+'</button>'+
        '<button class="small-btn'+(u.isFinch?' filled':'')+'" onclick="adminToggleFinch(\''+uid+'\','+(!u.isFinch)+')">'+(u.isFinch?'إلغاء تعيين فنش':'تعيين فنش 🐦')+'</button>'+
        '<button class="small-btn'+(u.postingBanned?' filled':'danger')+'" onclick="adminTogglePostBan(\''+uid+'\','+(!u.postingBanned)+')">'+(u.postingBanned?'إلغاء حظر النشر':'حظر عن النشر 🚫')+'</button>'+
        (isBanned
          ? '<button class="small-btn" onclick="adminUnban(\''+uid+'\')">إلغاء الحظر</button>'
          : ('<button class="small-btn danger" onclick="adminBan(\''+uid+'\','+BAN_HOURS+',false)">حظر '+BAN_HOURS+' ساعات</button>'+
             '<button class="small-btn danger" onclick="adminBan(\''+uid+'\',0,true)">حظر دائم</button>'))+
        '<button class="small-btn danger" onclick="adminSoftDeleteAccount(\''+uid+'\')">حذف الحساب نهائيًا</button>'+
      '</div>';
  resultEl.innerHTML =
    '<div class="admin-user-card">'+
      '<h4>'+nameWithBadge(u.displayName||u.username, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h4>'+
      '<div class="sub">@'+esc(u.username)+' — رصيد: '+(u.exeCoins||0)+' ZYROX — بلاغات: '+'<span id="adminReportCount">...</span></div>'+
      banStatusHtml+
      '<div class="form-group" style="margin-top:10px"><label>زوّد رصيد ZYROX للمستخدم ده</label>'+
        '<div style="display:flex;gap:8px"><input id="adminExeAmount" type="number" placeholder="مثال: 100" style="flex:1">'+
        '<button class="small-btn filled" onclick="adminAddCoins(\''+uid+'\')">إضافة</button></div></div>'+
      actionsHtml+
      '<div class="empty-hint" style="padding:10px 2px;text-align:right"><i class="fa-solid fa-circle-info"></i> تغيير كلمة السر أو حذف حساب المستخدم من نظام الدخول (Firebase Auth) يحتاج صلاحيات سيرفر خاصة مش متاحة من التطبيق نفسه؛ زرار "حذف الحساب" هنا بيمسح بياناته ويمنعه من الدخول تاني.</div>'+
    '</div>';
  var repSnap = await rtdb.ref('reports/'+uid).once('value');
  var repCount = repSnap.exists() ? Object.keys(repSnap.val()).length : 0;
  var repEl = document.getElementById('adminReportCount');
  if(repEl) repEl.innerText = repCount;
}

window.adminAddCoins = async function(uid){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('adminExeAmount');
  var amount = parseInt(input.value, 10);
  if(!amount || amount<=0){ alert('اكتب رقم صحيح أكبر من صفر'); return; }
  var balanceRef = rtdb.ref('users/'+uid+'/exeCoins');
  await balanceRef.transaction(function(cur){ return (cur||0) + amount; });
  input.value = '';
  alert('تم إضافة '+amount+' ZYROX لرصيد المستخدم');
  renderAdminUserCard(uid);
};

window.adminSetVerify = async function(uid, type){
  if(!currentProfile.isAdmin) return;
  var snap = await rtdb.ref('users/'+uid+'/isVerified').once('value');
  var types = badgeTypeOf(snap.val());
  var obj = {};
  types.forEach(function(t){ obj[t] = true; });
  if(obj[type]) delete obj[type]; else obj[type] = true;
  await rtdb.ref('users/'+uid+'/isVerified').set(Object.keys(obj).length ? obj : false);
  renderAdminUserCard(uid);
};

window.adminSearchGroup = async function(){
  if(!currentProfile.isAdmin) return;
  var q = document.getElementById('adminGroupSearchInput').value.trim().toLowerCase();
  var resultEl = document.getElementById('adminGroupResult');
  if(!q){ resultEl.innerHTML=''; return; }
  resultEl.innerHTML = '<div class="loading-msg">جارٍ البحث...</div>';
  try{
    var snapRes = await dbGetWithTimeout(rtdb.ref('chats').orderByChild('type').equalTo('group'), 22000);
    if(snapRes.timedOut){ resultEl.innerHTML = '<div class="empty-hint">الاتصال بطيء أو مفيش نت، حاول تاني</div>'; return; }
    var matches = [];
    if(snapRes.val){
      Object.keys(snapRes.val).forEach(function(key){
        var g = snapRes.val[key];
        if(g.name && g.name.toLowerCase().indexOf(q)!==-1) matches.push(Object.assign({id:key}, g));
      });
    }
    if(!matches.length){ resultEl.innerHTML = '<div class="empty-hint">مفيش جروب بالاسم ده</div>'; return; }
    resultEl.innerHTML = matches.slice(0,20).map(function(g){
      return '<div class="admin-user-card">'+
        '<h4>'+nameWithBadge(g.name, g.isVerified)+'</h4>'+
        '<div class="sub">'+Object.keys(g.members||{}).length+' عضو</div>'+
        '<div class="admin-badge-row">'+
          '<button class="small-btn'+(g.isVerified?' filled':'')+'" onclick="adminToggleGroupVerify(\''+g.id+'\','+(!g.isVerified)+')">'+(g.isVerified?'إلغاء التوثيق':'توثيق الجروب ✔')+'</button>'+
        '</div>'+
      '</div>';
    }).join('');
  }catch(err){
    resultEl.innerHTML = '<div class="empty-hint">حصل خطأ في البحث</div>';
  }
};

window.adminToggleGroupVerify = async function(chatId, val){
  if(!currentProfile.isAdmin) return;
  await rtdb.ref('chats/'+chatId+'/isVerified').set(val);
  if(chatsCache[chatId]){ chatsCache[chatId].isVerified = val; renderChatsListFromCache(); }
  if(currentChatId===chatId && currentChatData){ currentChatData.isVerified = val; paintChatHeaderQuick(currentChatData); }
  adminSearchGroup();
};

window.adminToggleAdmin = async function(uid, val){
  if(!currentProfile.isAdmin) return;
  var uSnap = await rtdb.ref('users/'+uid).once('value');
  var u = uSnap.val();
  if(u && isProtectedAdminUser(u)){ alert('ده الأدمن الأساسي، مينفعش تشيل صلاحيته'); return; }
  if(val && !confirm('هتدّي صلاحيات أدمن كاملة للحساب ده. متأكد؟')) return;
  await rtdb.ref('users/'+uid+'/isAdmin').set(val);
  renderAdminUserCard(uid);
};

/* ============ تعيين "فنش": صلاحية خاصة - أي بلاغ يبعته صاحبها بيحظر المُبلّغ عنه فورًا 5 دقايق من غير مراجعة الذكاء الاصطناعي ============ */
window.adminToggleFinch = async function(uid, val){
  if(!currentProfile.isAdmin) return;
  if(val && !confirm('هتدّي صلاحية "فنش" للحساب ده — أي بلاغ يبعته هيحظر صاحب الحساب المُبلّغ عنه فورًا 5 دقايق من غير مراجعة. متأكد؟')) return;
  await rtdb.ref('users/'+uid+'/isFinch').set(val);
  renderAdminUserCard(uid);
};

window.adminTogglePostBan = async function(uid, val){
  if(!currentProfile.isAdmin) return;
  await rtdb.ref('users/'+uid+'/postingBanned').set(val);
  if(currentUser && uid === currentUser.uid) currentProfile.postingBanned = val;
  renderAdminUserCard(uid);
};

window.adminBan = async function(uid, hours, permanent){
  if(!currentProfile.isAdmin) return;
  var uSnap = await rtdb.ref('users/'+uid).once('value');
  var u = uSnap.val();
  if(u && (isProtectedAdminUser(u) || u.isAdmin)){ alert('ده حساب أدمن، مينفعش يتحظر أصلًا'); return; }
  var reason = prompt('سبب الحظر (اختياري):') || '';
  var data = permanent
    ? { permanent:true, reason: reason }
    : { until: Date.now() + hours*60*60*1000, permanent:false, reason: reason };
  await rtdb.ref('bans/'+uid).set(data);
  renderAdminUserCard(uid);
};

window.adminUnban = async function(uid){
  if(!currentProfile.isAdmin) return;
  await rtdb.ref('bans/'+uid).remove();
  await rtdb.ref('reports/'+uid).remove();
  await rtdb.ref('warnings/'+uid).remove();
  renderAdminUserCard(uid);
};

window.adminSoftDeleteAccount = async function(uid){
  if(!currentProfile.isAdmin) return;
  var uSnap0 = await rtdb.ref('users/'+uid).once('value');
  var u0 = uSnap0.val();
  if(u0 && isProtectedAdminUser(u0)){ alert('ده الأدمن الأساسي، مينفعش تحذف حسابه'); return; }
  if(!confirm('هيتم حذف الحساب ده بالكامل (بياناته، اسم المستخدم، صداقاته) ومنعه من الدخول تاني.\nهتقدر ترجعه تاني في أي وقت من قسم "الحسابات المحذوفة". متأكد؟')) return;
  var uSnap = await rtdb.ref('users/'+uid).once('value');
  var u = uSnap.val();
  if(!u){ alert('الحساب مش موجود أصلاً'); return; }
  await rtdb.ref('deletedUsers/'+uid).set({
    profile: u,
    deletedAt: firebase.database.ServerValue.TIMESTAMP,
    deletedBy: currentProfile.username
  });
  if(u.usernameLower) await rtdb.ref('usernames/'+u.usernameLower).remove();
  await rtdb.ref('users/'+uid).remove();
  await rtdb.ref('userChats/'+uid).remove();
  await rtdb.ref('friends/'+uid).remove();
  await rtdb.ref('friendRequests/'+uid).remove();
  await rtdb.ref('blocked/'+uid).remove();
  await rtdb.ref('bans/'+uid).set({ permanent:true, reason:'الحساب محذوف بواسطة الأدمن' });
  alert('تم حذف الحساب بالكامل. تقدر ترجعه من قسم "الحسابات المحذوفة" تحت.');
  document.getElementById('adminUserResult').innerHTML='';
  renderDeletedUsersList();
};

window.adminRestoreAccount = async function(uid){
  if(!currentProfile.isAdmin) return;
  var backupSnap = await rtdb.ref('deletedUsers/'+uid).once('value');
  var backup = backupSnap.val();
  if(!backup || !backup.profile){ alert('مفيش نسخة محفوظة للحساب ده'); return; }
  var p = backup.profile;
  if(p.usernameLower){
    var existing = await rtdb.ref('usernames/'+p.usernameLower).once('value');
    if(existing.exists()){ alert('اسم المستخدم "@'+p.username+'" اتاخد من حساب تاني دلوقتي، مينفعش ترجّع الحساب ده غير لو الاسم يتغير الأول'); return; }
  }
  await rtdb.ref('users/'+uid).set(p);
  if(p.usernameLower) await rtdb.ref('usernames/'+p.usernameLower).set(uid);
  await rtdb.ref('bans/'+uid).remove();
  await rtdb.ref('deletedUsers/'+uid).remove();
  alert('تم استرجاع الحساب بنجاح، ويقدر يدخل تاني عادي.');
  renderDeletedUsersList();
};

window.renderDeletedUsersList = async function(){
  var el = document.getElementById('adminDeletedList');
  if(!el || !currentProfile.isAdmin) return;
  el.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  var snap = await rtdb.ref('deletedUsers').once('value');
  var data = snap.val();
  if(!data){ el.innerHTML = '<div class="empty-hint">مفيش حسابات محذوفة حاليًا</div>'; return; }
  var html = '';
  Object.keys(data).forEach(function(uid){
    var b = data[uid];
    var p = b.profile || {};
    html += '<div class="item-card" style="cursor:default">'+
      avatarBlockHTML(p.displayName||p.username||'؟', p.photoURL, '')+
      '<div class="item-info"><h4>'+esc(p.displayName||p.username||'؟')+'</h4><p>@'+esc(p.username||'')+'</p></div>'+
      '<button class="small-btn filled" onclick="adminRestoreAccount(\''+uid+'\')">استرجاع</button>'+
    '</div>';
  });
  el.innerHTML = html;
};

window.sendBroadcast = async function(){
  if(!currentProfile.isAdmin) return;
  var text = document.getElementById('adminBroadcastText').value.trim();
  if(!text){ alert('اكتب نص الإذاعة'); return; }
  await rtdb.ref('announcements').push({ text: text, from: currentProfile.username, ts: firebase.database.ServerValue.TIMESTAMP });
  document.getElementById('adminBroadcastText').value='';
  alert('تم إرسال الإذاعة لكل الأعضاء');
};
