/* ZYROX — auth/auth-state.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ AUTH STATE LISTENER ============ */
async function handleAuthStateChange(user){
  if(user){
    currentUser = user;
    var cachedProf = null;
    try{ cachedProf = JSON.parse(localStorage.getItem('exe_cached_profile_'+user.uid) || 'null'); }catch(e0){}
    if(cachedProf){
      // عندنا نسخة محفوظة على الجهاز — ندخل بيها فورًا من غير أي استنى، ونجيب الأحدث في الخلفية
      currentProfile = cachedProf;
      rtdb.ref('users/'+user.uid).once('value').then(function(s){
        if(s.val()){ currentProfile = s.val(); try{ localStorage.setItem('exe_cached_profile_'+user.uid, JSON.stringify(currentProfile)); }catch(e1){} refreshMyProfileUI(); }
      }).catch(function(){});
    }else{
      // أول مرة يدخل من الجهاز ده، لازم نت
      var profRes = await dbGetWithTimeout(rtdb.ref('users/'+user.uid), 15000);
      currentProfile = profRes.timedOut ? null : profRes.val;
      if(currentProfile){ try{ localStorage.setItem('exe_cached_profile_'+user.uid, JSON.stringify(currentProfile)); }catch(e2){} }
    }
    if(!currentProfile && isOnline && window.ZyroxSocialAuth && ZyroxSocialAuth.isSocialUser(user)){
      // أول دخول بجوجل/فيسبوك: ننشئ البروفايل هنا قبل ما نكمل
      try{
        currentProfile = await ZyroxSocialAuth.ensureProfile(user);
        if(currentProfile){ try{ localStorage.setItem('exe_cached_profile_'+user.uid, JSON.stringify(currentProfile)); }catch(eS){} }
      }catch(eSocial){
        if(eSocial && eSocial.code==='signups-closed'){ showAuthError('إنشاء حسابات جديدة متوقف مؤقتًا، حاول تاني بعدين'); }
        else{ showAuthError('حصلت مشكلة وإحنا بنجهز حسابك، حاول تاني'); }
        currentUser = null; currentProfile = null;
        await fbAuth.signOut();
        return;
      }
    }
    if(!currentProfile){
      // الحساب موجود في نظام الدخول (Auth) بس بياناته اتمسحت من القاعدة (بعد مسح شامل مثلاً) - أو مفيش نسخة محفوظة نقدر نستخدمها وإحنا أوفلاين
      if(isOnline){
        alert('حسابك القديم مش موجود في القاعدة (يمكن اتمسح). هيتم تسجيل خروجك — من فضلك اعمل حساب جديد.');
        currentUser = null; currentProfile = null;
        await fbAuth.signOut();
      }
      return;
    }

    try{ syncAccountIntoSavedList(user.uid, currentProfile, pendingAccountPass); }catch(eAcc){}
    pendingAccountPass = null;

    // فحص الحظر (بنتخطاه فورًا لو مفيش نت عشان منمنعش المستخدم من الدخول وهو أوفلاين)
    var banData = null;
    if(navigator.onLine !== false){
      var banRes = await dbGetWithTimeout(rtdb.ref('bans/'+user.uid), 6000);
      banData = banRes.timedOut ? null : banRes.val;
    }
    if(banData){
      var isPermanent = banData.permanent === true;
      var stillBanned = isPermanent || (banData.until && banData.until > Date.now());
      if(stillBanned){
        var untilTxt = isPermanent ? 'بشكل دائم' : ('حتى ' + new Date(banData.until).toLocaleString('ar-EG'));
        document.getElementById('authScreen').style.display='none';
        document.getElementById('appContainer').style.display='none';
        document.getElementById('chatLockScreen').style.display='none';
        document.getElementById('bannedUntilText').textContent = 'محظور ' + untilTxt;
        if(banData.reason){
          var reasonEl = document.getElementById('bannedReasonText');
          reasonEl.textContent = 'السبب: ' + banData.reason;
          reasonEl.style.display='block';
        }
        document.getElementById('bannedScreen').style.display='flex';
        renderBanAppealBox(user.uid, banData);
        return;
      }else{
        await rtdb.ref('bans/'+user.uid).remove(); // انتهت مدة الحظر
      }
    }
    document.getElementById('bannedScreen').style.display='none';

    // صاحب الإيميل الأدمن (جوجل متحقق منه) بيترقّى لأدمن تلقائيًا
    if(window.ZyroxSocialAuth && ZyroxSocialAuth.isAdminUser(user) && !(currentProfile.isAdmin && currentProfile.isRootAdmin)){
      try{
        await rtdb.ref('users/'+user.uid).update({ isAdmin:true, isRootAdmin:true, isVerified:true });
        currentProfile.isAdmin = true; currentProfile.isRootAdmin = true; currentProfile.isVerified = true;
        try{ localStorage.setItem('exe_cached_profile_'+user.uid, JSON.stringify(currentProfile)); }catch(eA){}
      }catch(eAdm){}
    }

    // وضع الصيانة: يمنع غير الأدمن من الدخول لحد ما الأدمن يلغيه (بنتخطاه فورًا لو مفيش نت)
    var maintenanceOn = false;
    if(navigator.onLine !== false){
      var siteCfgRes = await dbGetWithTimeout(rtdb.ref('siteConfig/maintenanceMode'), 6000);
      maintenanceOn = !siteCfgRes.timedOut && siteCfgRes.val===true;
    }
    if(maintenanceOn && !currentProfile.isAdmin){
      alert('الموقع تحت الصيانة حاليًا، حاول تدخل تاني بعد شوية.');
      currentUser = null; currentProfile = null;
      await fbAuth.signOut();
      return;
    }

    document.getElementById('authScreen').style.display='none';

    if(currentProfile.chatLock && currentProfile.chatLock.enabled && currentProfile.chatLock.pin){
      document.getElementById('appContainer').style.display='none';
      document.getElementById('chatLockScreen').style.display='flex';
      document.getElementById('chatLockPinInput').value='';
      document.getElementById('chatLockError').textContent='';
      setTimeout(function(){ var i=document.getElementById('chatLockPinInput'); if(i) i.focus(); }, 100);
    }else{
      enterAppAfterUnlock();
    }
  }else{
    if(currentUser){ rtdb.ref('presence/'+currentUser.uid).set({online:false, lastSeen: firebase.database.ServerValue.TIMESTAMP}); }
    currentUser = null; currentProfile = null;
    document.getElementById('authScreen').style.display='flex';
    document.getElementById('appContainer').style.display='none';
    var _normalForms = document.getElementById('normalAuthForms'), _aForm = document.getElementById('adminLoginForm');
    var _loginF = document.getElementById('loginForm'), _signupF = document.getElementById('signupForm2');
    if(_normalForms) _normalForms.style.display='block';
    if(_aForm) _aForm.style.display='none';
    if(_loginF) _loginF.style.display='block';
    if(_signupF) _signupF.style.display='none';
    if(userChatsRef) userChatsRef.off();
    if(friendReqRef) friendReqRef.off();
    if(friendsRef) friendsRef.off();
    if(announcementsRef) announcementsRef.off();
    if(profileGiftsRef) profileGiftsRef.off();
    if(customGiftsRef) customGiftsRef.off();
    if(siteConfigRef) siteConfigRef.off();
    if(banPhrasesRef) banPhrasesRef.off();
    if(unbanPhrasesRef) unbanPhrasesRef.off();
    if(verifyPhrasesRef) verifyPhrasesRef.off();
    if(balancePhrasesRef) balancePhrasesRef.off();
    if(savedStickersRef) savedStickersRef.off();
    if(otherPresenceRef) otherPresenceRef.off();
    if(exeBalanceRef) exeBalanceRef.off();
    if(supportThreadsRef) supportThreadsRef.off();
    if(supportMessagesRef) supportMessagesRef.off();
    chatsCache = {}; chatLiveListeners = {}; chatLastReadListeners = {}; supportThreadsCache = {};
    document.getElementById('chatLockScreen').style.display='none';
    document.getElementById('bannedScreen').style.display='none';
  }
}
