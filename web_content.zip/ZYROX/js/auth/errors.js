/* ZYROX — auth/errors.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

function translateFirebaseError(err){
  var code = err.code || '';
  if(code.indexOf('email-already-in-use') !== -1) return 'اسم المستخدم ده متحجز بالفعل';
  if(code.indexOf('weak-password') !== -1) return 'كلمة المرور ضعيفة جدًا';
  if(code.indexOf('wrong-password') !== -1 || code.indexOf('invalid-credential') !== -1) return 'اسم المستخدم أو كلمة المرور غلط';
  if(code.indexOf('user-not-found') !== -1) return 'الحساب غير موجود';
  if(code.indexOf('too-many-requests') !== -1) return 'محاولات كتير، جرب تاني بعد شوية';
  if(code.indexOf('requires-recent-login') !== -1) return 'محتاج تسجل دخول تاني قبل ما تعمل الخطوة دي';
  if(code.indexOf('network-request-failed') !== -1) return 'مشكلة في الاتصال بالإنترنت، تأكد من الاتصال وجرب تاني';
  if(code.indexOf('invalid-verification-code') !== -1) return 'الكود اللي كتبته غلط، تأكد وجرب تاني';
  if(code.indexOf('code-expired') !== -1) return 'الكود ده منتهي، دوس إعادة الإرسال واطلب كود جديد';
  if(code.indexOf('invalid-phone-number') !== -1) return 'رقم الموبايل غير صحيح';
  if(code.indexOf('missing-phone-number') !== -1) return 'اكتب رقم الموبايل';
  if(code.indexOf('quota-exceeded') !== -1) return 'تم تجاوز الحد المسموح لإرسال الرسائل دلوقتي، حاول بعد شوية';
  if(code.indexOf('captcha-check-failed') !== -1) return 'فشل التحقق الأمني، أعد تحميل الصفحة وجرب تاني';
  if(code.indexOf('unauthorized-domain') !== -1) return 'الدومين اللي شغال عليه الموقع مش مضاف في إعدادات Firebase (Authorized domains)';
  if(code.indexOf('operation-not-allowed') !== -1) return 'خاصية الدخول بالتليفون لسه مش مفعّلة من Firebase Console (Authentication > Sign-in method > Phone)';
  if(code.indexOf('admin-restricted-operation') !== -1) return 'التسجيل بالتليفون محتاج تفعيل خطة Blaze (الدفع حسب الاستخدام) في مشروع Firebase';
  if(code.indexOf('argument-error') !== -1) return 'حصلت مشكلة في تحميل نظام التحقق الأمني (reCAPTCHA)، جرب تعمل Refresh للصفحة';
  if(code.indexOf('internal-error') !== -1) return 'خطأ داخلي من Firebase، جرب تاني وتأكد إن إعدادات المشروع مضبوطة';
  console.error('Firebase error:', err);
  return 'حصل خطأ غير متوقع (' + (code || 'unknown') + ')، حاول تاني كمان شوية';
}

window.doLogout = function(){ fbAuth.signOut(); };
