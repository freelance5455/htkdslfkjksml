/* ZYROX — auth/accounts.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ MULTI ACCOUNT SWITCHER ============ */
var pendingAccountPass = null; // كلمة السر المؤقتة بين لحظة تسجيل الدخول/الإنشاء ولحظة ما نحفظها في قايمة الحسابات
function getSavedAccounts(){ try{ return JSON.parse(localStorage.getItem('exe_saved_accounts') || '[]'); }catch(e){ return []; } }
function setSavedAccounts(list){ try{ localStorage.setItem('exe_saved_accounts', JSON.stringify(list)); }catch(e){} }
function getAccountsCap(){ var stored = parseInt(localStorage.getItem('exe_accounts_cap')||'3', 10); return stored>=4 ? 4 : 3; }
function bumpAccountsCap(isVerified){ if(!isVerified) return; if(getAccountsCap() < 4){ try{ localStorage.setItem('exe_accounts_cap','4'); }catch(e){} } }
function syncAccountIntoSavedList(uid, profile, pass){
  if(!uid || !profile) return;
  bumpAccountsCap(!!profile.isVerified);
  var list = getSavedAccounts();
  var idx = list.findIndex(function(a){ return a.uid===uid; });
  var entry = {
    uid: uid, username: profile.username, usernameLower: profile.usernameLower,
    displayName: profile.displayName || profile.username, photoURL: profile.photoURL || null,
    isVerified: !!profile.isVerified,
    passB64: pass ? btoa(unescape(encodeURIComponent(pass))) : (idx!==-1 ? list[idx].passB64 : null)
  };
  if(idx!==-1){ list[idx] = entry; setSavedAccounts(list); return; }
  if(list.length >= getAccountsCap()) return; // وصلنا للحد الأقصى، الحساب هيفضل شغال بس مش هيتحفظ في القايمة
  list.push(entry);
  setSavedAccounts(list);
}

window.openAccountsModal = function(){
  renderSavedAccountsList();
  document.getElementById('sideMenu').classList.remove('active');
  document.getElementById('accountsModal').classList.add('active');
};

function renderSavedAccountsList(){
  var el = document.getElementById('savedAccountsList');
  if(!el) return;
  var list = getSavedAccounts();
  var cap = getAccountsCap();
  var capText = document.getElementById('accountsCapText');
  if(capText) capText.textContent = 'الحسابات المحفوظة ('+list.length+'/'+cap+')';
  if(list.length===0){ el.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-users"></i>مفيش حسابات محفوظة لسه</div>'; return; }
  el.innerHTML = list.map(function(a){
    var isActive = currentUser && currentUser.uid===a.uid;
    var avatarHtml = a.photoURL
      ? '<div class="avatar" style="background-image:url(\''+a.photoURL+'\');background-size:cover;background-position:center"></div>'
      : '<div class="avatar">'+esc(avatarLetter(a.displayName||a.username))+'</div>';
    return '<div class="user-result-item" style="'+(isActive&&a.passB64?'opacity:.55':'cursor:pointer')+'" onclick="switchToSavedAccount(\''+a.uid+'\')">'+
      avatarHtml+
      '<div class="uinfo"><h5>'+nameWithBadge(a.displayName||a.username, a.isVerified)+'</h5><p>@'+esc(a.username)+(isActive?' • الحساب الحالي'+(a.passB64?'':' (اضغط لحفظ كلمة السر)'):'')+'</p></div>'+
      '<button class="small-btn danger" onclick="event.stopPropagation();removeSavedAccount(\''+a.uid+'\')" title="شيل من القايمة"><i class="fa-solid fa-xmark"></i></button>'+
    '</div>';
  }).join('');
}

window.removeSavedAccount = function(uid){
  if(!confirm('تشيل الحساب ده من قايمة التبديل بتاعتك؟ (الحساب هيفضل موجود عادي، بس مش هيبقى محفوظ هنا)')) return;
  setSavedAccounts(getSavedAccounts().filter(function(a){ return a.uid!==uid; }));
  renderSavedAccountsList();
};

window.switchToSavedAccount = async function(uid){
  var list = getSavedAccounts();
  var acc = list.find(function(a){ return a.uid===uid; });
  if(!acc) return;
  var isActive = currentUser && currentUser.uid===uid;

  if(isActive){
    if(acc.passB64) return; // متسجل ومحفوظ بالفعل، مفيش داعي لأي حاجة
    var passActive = prompt('اكتب كلمة مرور حسابك الحالي (@'+acc.username+') عشان يتسجل في قايمة التبديل ويبقى سهل ترجعله بعدين:');
    if(!passActive) return;
    try{
      var credObj = firebase.auth.EmailAuthProvider.credential(currentUser.email, passActive);
      await currentUser.reauthenticateWithCredential(credObj);
      syncAccountIntoSavedList(uid, currentProfile, passActive);
      renderSavedAccountsList();
      showBlackToast('اتحفظت كلمة السر بنجاح');
    }catch(err){
      alert(translateFirebaseError(err));
    }
    return;
  }

  var pass = null;
  if(acc.passB64){
    try{ pass = decodeURIComponent(escape(atob(acc.passB64))); }catch(e){ pass = null; }
  }
  if(!pass){
    pass = prompt('اكتب كلمة مرور حساب @'+acc.username+' عشان تقدر تبدل له (هتتحفظ في الجهاز عشان متتطلبش منك تاني):');
    if(!pass) return;
  }
  closeModal('accountsModal');
  showUploadOverlay('جارٍ تبديل الحساب...', 'بندخلك على @'+acc.username);
  try{
    pendingAccountPass = pass;
    await fbAuth.signOut();
    await fbAuth.signInWithEmailAndPassword(usernameToHiddenEmail(acc.usernameLower), pass);
    hideUploadOverlay();
  }catch(err){
    hideUploadOverlay();
    alert(translateFirebaseError(err));
  }
};

window.startAddAccount = function(){
  var cap = getAccountsCap();
  var list = getSavedAccounts();
  if(list.length >= cap){
    alert('وصلت للحد الأقصى لعدد الحسابات المحفوظة ('+cap+'). '+((currentProfile && currentProfile.isVerified) ? '' : 'وثّق حسابك عشان تقدر تحفظ لحد 4 حسابات.'));
    return;
  }
  if(!confirm('هيتم تسجيل خروجك من الحساب الحالي عشان تدخل بحساب تاني أو تعمل واحد جديد. حسابك الحالي هيفضل محفوظ في القايمة عشان ترجعله بسهولة. تكمل؟')) return;
  closeModal('accountsModal');
  fbAuth.signOut();
};

function dbGetWithTimeout(ref, timeoutMs){
  return Promise.race([
    ref.once('value').then(function(s){ return {timedOut:false, val:s.val()}; }),
    new Promise(function(resolve){ setTimeout(function(){ resolve({timedOut:true, val:undefined}); }, timeoutMs); })
  ]);
}
