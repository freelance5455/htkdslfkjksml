/* ZYROX — auth/login.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ تسجيل الدخول (يوزرنيم + باسورد) ============ */
window.doUserLogin = async function(){
  clearAuthMsgs();
  var username = document.getElementById('loginUsername2').value.trim();
  var pass = document.getElementById('loginPass2').value;
  if(!username || !pass) return showAuthError('من فضلك أدخل بياناتك بالكامل');

  var btn = document.getElementById('loginBtn2');
  btn.disabled = true; btn.innerHTML = 'جارٍ الدخول<span class="spinner"></span>';
  try{
    var usernameLower = username.toLowerCase();
    pendingAccountPass = pass;
    await fbAuth.signInWithEmailAndPassword(usernameToHiddenEmail(usernameLower), pass);
  }catch(err){
    showAuthError(translateFirebaseError(err));
  }
  btn.disabled = false; btn.innerText = 'تسجيل الدخول';
};
