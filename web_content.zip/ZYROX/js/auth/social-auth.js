/* ZYROX — auth/social-auth.js
   تسجيل الدخول بجوجل / فيسبوك + تحديد الأدمن بالإيميل (ADMIN_EMAIL في core/admin-config.js).
   بيعتمد على المتغيرات العامة: fbAuth, rtdb, firebase, showAuthError, clearAuthMsgs, translateFirebaseError. */

var ZyroxSocialAuth = (function(){

  function hasProvider(user, providerId){
    return !!(user && user.providerData && user.providerData.some(function(p){ return p && p.providerId === providerId; }));
  }

  function isSocialUser(user){
    return hasProvider(user, 'google.com') || hasProvider(user, 'facebook.com');
  }

  function providerName(user){
    if(hasProvider(user, 'google.com')) return 'google';
    if(hasProvider(user, 'facebook.com')) return 'facebook';
    return 'username';
  }

  /* الأدمن: لازم الدخول يكون بجوجل + الإيميل متحقق منه من جوجل + مطابق لـ ADMIN_EMAIL.
     فيسبوك مش بيدّي صلاحية أدمن أبدًا (إيميله مش مضمون التحقق). */
  function isAdminUser(user){
    if(!user || !user.email || !user.emailVerified) return false;
    if(!hasProvider(user, 'google.com')) return false;
    return user.email.trim().toLowerCase() === String(ADMIN_EMAIL).trim().toLowerCase();
  }

  /* ---------- اسم المستخدم التلقائي ----------
     مش بنبنيه من الإيميل عشان مايتكشفش للناس. بنستخدم الاسم لو إنجليزي، وإلا "user" + أرقام. */
  function randDigits(n){ var s=''; for(var i=0;i<n;i++) s += Math.floor(Math.random()*10); return s; }

  async function pickUsername(user, isAdmin){
    if(isAdmin){
      var adminSnap = await rtdb.ref('usernames/admin').once('value');
      if(!adminSnap.exists()) return 'admin';
    }
    var latin = String(user.displayName || '').toLowerCase().replace(/[^a-z0-9_.]/g, '');
    var base = latin.length >= 3 ? latin.slice(0, 14) : 'user';
    for(var round = 0; round < 12; round++){
      var cand = (base + randDigits(round < 6 ? 4 : 6)).slice(0, 20);
      var snap = await rtdb.ref('usernames/' + cand).once('value');
      if(!snap.exists()) return cand;
    }
    return ('u' + user.uid.toLowerCase().replace(/[^a-z0-9]/g, '')).slice(0, 18);
  }

  async function sendWelcomeMessage(uid, displayName){
    try{
      var aiCfgSnap = await rtdb.ref('appConfig/ai').once('value');
      var aiCfg = aiCfgSnap.val() || {};
      var botName = aiCfg.botName || 'ZYROX';
      var welcomeTemplate = aiCfg.welcomeMessage || 'أهلاً بيك يا {username} في ZYROX 🎉\nمبسوطين إنك انضممت لينا. لو عندك أي سؤال أو محتاج مساعدة في أي وقت، ابعتلي هنا وأنا موجود.';
      var welcomeText = welcomeTemplate.split('{username}').join(displayName);
      var welcomeChatId = 'ai_' + uid;
      var members = {}; members[uid] = true; members['ai-bot'] = true;
      await rtdb.ref('chats/' + welcomeChatId).set({
        type: 'ai', members: members, name: botName,
        lastMessage: welcomeText.split('\n')[0], lastMessageTime: firebase.database.ServerValue.TIMESTAMP,
        createdAt: firebase.database.ServerValue.TIMESTAMP
      });
      await rtdb.ref('userChats/' + uid + '/' + welcomeChatId).set(true);
      await rtdb.ref('messages/' + welcomeChatId).push().set({
        senderId: 'ai-bot', senderName: botName, type: 'text',
        text: welcomeText, timestamp: firebase.database.ServerValue.TIMESTAMP
      });
    }catch(e){ /* لو فشلت الرسالة الترحيبية منمنعش الدخول */ }
  }

  /* بيرجّع بروفايل المستخدم من القاعدة، ولو أول مرة بينشئه. */
  async function ensureProfile(user){
    var snap = await rtdb.ref('users/' + user.uid).once('value');
    if(snap.exists()) return snap.val();

    var admin = isAdminUser(user);
    if(!admin){
      var cfg = await rtdb.ref('siteConfig/allowSignups').once('value');
      if(cfg.val() === false){ var e = new Error('signups closed'); e.code = 'signups-closed'; throw e; }
    }

    var username = await pickUsername(user, admin);
    var displayName = (user.displayName || username).trim().slice(0, 30) || username;
    var profile = {
      username: username, usernameLower: username.toLowerCase(), displayName: displayName,
      loginType: providerName(user),
      about: admin ? 'الأدمن الرسمي لـ ZYROX' : 'متاح حاليًا',
      settings: { lastSeen:'everyone', notifications:true, sound:true, readReceipts:true,
                  notifPreview:true, profilePhotoPrivacy:'everyone', aboutPrivacy:'everyone', groupAddPrivacy:'everyone',
                  autoDownloadMedia:true, typingIndicator:true },
      photoURL: user.photoURL || null,
      isVerified: admin, isAdmin: admin, exeCoins: 0,
      createdAt: firebase.database.ServerValue.TIMESTAMP
    };
    if(admin) profile.isRootAdmin = true;

    await rtdb.ref('users/' + user.uid).set(profile);
    await rtdb.ref('usernames/' + profile.usernameLower).set(user.uid);
    await sendWelcomeMessage(user.uid, displayName);

    profile.createdAt = Date.now();
    return profile;
  }

  /* ---------- رسائل الأخطاء ---------- */
  function errorMessage(err){
    var code = (err && err.code) || '';
    if(code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') return 'اتقفلت نافذة الدخول قبل ما تكمل، جرب تاني';
    if(code === 'auth/account-exists-with-different-credential') return 'الإيميل ده مسجل قبل كده بطريقة دخول تانية (جوجل أو فيسبوك)، جرب الطريقة التانية';
    if(code === 'auth/operation-not-allowed') return 'طريقة الدخول دي لسه متفعلتش من إعدادات Firebase (Authentication → Sign-in method)';
    if(code === 'auth/unauthorized-domain') return 'الدومين ده مش مضاف في Firebase (Authentication → Settings → Authorized domains)';
    if(code === 'auth/popup-blocked') return 'المتصفح منع نافذة الدخول، اسمح بالنوافذ المنبثقة وجرب تاني';
    if(code === 'auth/user-disabled') return 'الحساب ده متوقف';
    if(code === 'auth/network-request-failed') return 'مشكلة في الاتصال بالإنترنت، تأكد من الاتصال وجرب تاني';
    if(typeof translateFirebaseError === 'function'){ var t = translateFirebaseError(err); if(t) return t; }
    return 'حصلت مشكلة في تسجيل الدخول، حاول تاني';
  }

  function setBusy(busy){
    ['googleLoginBtn', 'facebookLoginBtn'].forEach(function(id){
      var b = document.getElementById(id); if(b) b.disabled = !!busy;
    });
  }

  async function login(which){
    clearAuthMsgs();
    var provider;
    if(which === 'google'){
      provider = new firebase.auth.GoogleAuthProvider();
      provider.addScope('email'); provider.addScope('profile');
      provider.setCustomParameters({ prompt: 'select_account' });
    }else{
      provider = new firebase.auth.FacebookAuthProvider();
      provider.addScope('email'); provider.addScope('public_profile');
    }
    setBusy(true);
    try{
      await fbAuth.signInWithPopup(provider);
    }catch(err){
      var c = (err && err.code) || '';
      // في المتصفحات المدمجة / WebView النوافذ المنبثقة بتفشل، فبنحوّل لطريقة إعادة التوجيه
      if(c === 'auth/popup-blocked' || c === 'auth/operation-not-supported-in-this-environment' || c === 'auth/web-storage-unsupported'){
        try{ await fbAuth.signInWithRedirect(provider); return; }
        catch(err2){ err = err2; }
      }
      showAuthError(errorMessage(err));
    }
    setBusy(false);
  }

  /* نتيجة الدخول بإعادة التوجيه (لو فشلت بنعرض الخطأ؛ لو نجحت onAuthStateChanged بيكمل لوحده) */
  function handleRedirectResult(){
    try{
      fbAuth.getRedirectResult().catch(function(err){ showAuthError(errorMessage(err)); });
    }catch(e){}
  }

  return {
    isSocialUser: isSocialUser,
    isAdminUser: isAdminUser,
    ensureProfile: ensureProfile,
    login: login,
    handleRedirectResult: handleRedirectResult
  };
})();

window.ZyroxSocialAuth = ZyroxSocialAuth;
window.doSocialLogin = function(which){ return ZyroxSocialAuth.login(which); };
