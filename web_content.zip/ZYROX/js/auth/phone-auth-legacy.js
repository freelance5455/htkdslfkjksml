/* ZYROX — auth/phone-auth-legacy.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ PHONE NUMBER HELPERS ============ */
function normalizePhone(raw){ return (raw||'').replace(/[^0-9]/g,''); }
function isValidPhone(digits){ return /^[0-9]{8,15}$/.test(digits); }
function formatPhoneDisplay(digits){ return digits ? '+'+digits : ''; }

/* ============ PHONE VERIFICATION (Firebase Phone Auth) ============ */
var signupRecaptchaVerifier = null;
var signupConfirmationResult = null;
var pendingSignupProfile = null;

// بيحول الرقم المصري المحلي (01XXXXXXXXX) لصيغة دولية +20XXXXXXXXXX تناسب Firebase Phone Auth
function toE164Phone(digitsRaw){
  var digits = (digitsRaw||'').replace(/[^0-9]/g,'');
  if(!digits) return '';
  if(digits.length===11 && digits[0]==='0') return '+20'+digits.slice(1);
  if(digits.indexOf('20')===0) return '+'+digits;
  if(digits.indexOf('00')===0) return '+'+digits.slice(2);
  return '+'+digits;
}

function ensureSignupRecaptcha(){
  if(signupRecaptchaVerifier) return signupRecaptchaVerifier;
  signupRecaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container', { size: 'invisible' });
  return signupRecaptchaVerifier;
}

function resetSignupOtpFlow(){
  signupConfirmationResult = null;
  pendingSignupProfile = null;
  if(signupRecaptchaVerifier){ try{ signupRecaptchaVerifier.clear(); }catch(e){} signupRecaptchaVerifier = null; }
  var otpInput = document.getElementById('suOtpCode');
  if(otpInput) otpInput.value = '';
}

window.backToSignupStep1 = function(){
  clearAuthMsgs();
  resetSignupOtpFlow();
  document.getElementById('suStep2').style.display = 'none';
  document.getElementById('suStep1').style.display = 'block';
};

/* بيتأكد إن الصفحة متبعتة من سيرفر حقيقي (http/https) مش متفتوحة كملف مباشرة (file://)،
   لأن Phone Auth و reCAPTCHA مش بيشتغلوا خالص من غير كده */
function checkEnvSupportsPhoneAuth(){
  if(window.location.protocol === 'file:'){
    showAuthError('الصفحة مفتوحة كملف مباشرة من جهازك (file://) والتحقق بالتليفون محتاج الصفحة تتفتح من سيرفر (http/https أو localhost). استضيف الملف (مثلاً Firebase Hosting) أو شغّله بأمر: python3 -m http.server ثم افتح http://localhost:8000');
    return false;
  }
  return true;
}

/* ============ الخطوة 1: التحقق من البيانات وإرسال كود SMS ============ */
window.sendSignupOtp = async function(){
  clearAuthMsgs();
  if(!checkEnvSupportsPhoneAuth()) return;
  var displayName = document.getElementById('suDisplayName').value.trim();
  var phoneRaw = document.getElementById('suPhone').value.trim();
  var phone = normalizePhone(phoneRaw);
  var pass = document.getElementById('suPass').value;
  if(!displayName || displayName.length<2 || displayName.length>30) return showAuthError('اكتب اسمك (2-30 حرف)');
  if(!isValidPhone(phone)) return showAuthError('اكتب رقم موبايل صحيح');
  if(pass.length < 6) return showAuthError('كلمة المرور لازم تكون 6 أحرف على الأقل');

  var btn = document.getElementById('signupBtn');
  btn.disabled = true; btn.innerHTML = 'جارٍ الإرسال<span class="spinner"></span>';
  var usernameLower = phone;
  try{
    var signupsCfg = await rtdb.ref('siteConfig/allowSignups').once('value');
    if(signupsCfg.val()===false){
      showAuthError('إنشاء حسابات جديدة متوقف مؤقتًا، حاول تاني بعدين');
      btn.disabled=false; btn.innerText='إرسال كود التحقق'; return;
    }
    var existing = await rtdb.ref('usernames/'+usernameLower).once('value');
    if(existing.exists()){ showAuthError('رقم الموبايل ده متسجل بحساب قبل كده'); btn.disabled=false; btn.innerText='إرسال كود التحقق'; return; }

    var e164 = toE164Phone(phone);
    var verifier = ensureSignupRecaptcha();
    var result = await fbAuth.signInWithPhoneNumber(e164, verifier);
    signupConfirmationResult = result;
    pendingSignupProfile = { displayName: displayName, phone: phone, pass: pass, usernameLower: usernameLower };

    document.getElementById('suOtpPhoneDisplay').innerText = formatPhoneDisplay(phone);
    document.getElementById('suStep1').style.display = 'none';
    document.getElementById('suStep2').style.display = 'block';
    var otpInput = document.getElementById('suOtpCode');
    if(otpInput){ otpInput.value=''; otpInput.focus(); }
  }catch(err){
    if(signupRecaptchaVerifier){ try{ signupRecaptchaVerifier.clear(); }catch(e){} signupRecaptchaVerifier = null; }
    showAuthError(translateFirebaseError(err));
  }
  btn.disabled = false; btn.innerText = 'إرسال كود التحقق';
};

/* ============ إعادة إرسال الكود ============ */
window.resendSignupOtp = async function(){
  if(!pendingSignupProfile) return backToSignupStep1();
  clearAuthMsgs();
  if(!checkEnvSupportsPhoneAuth()) return;
  var btn = document.getElementById('resendOtpBtn');
  btn.style.pointerEvents = 'none'; btn.innerHTML = '<span class="spinner"></span> جارٍ الإرسال';
  try{
    if(signupRecaptchaVerifier){ try{ signupRecaptchaVerifier.clear(); }catch(e){} signupRecaptchaVerifier = null; }
    var verifier = ensureSignupRecaptcha();
    var e164 = toE164Phone(pendingSignupProfile.phone);
    var result = await fbAuth.signInWithPhoneNumber(e164, verifier);
    signupConfirmationResult = result;
    showAuthSuccess('تم إعادة إرسال الكود');
  }catch(err){
    showAuthError(translateFirebaseError(err));
  }
  btn.style.pointerEvents = 'auto'; btn.innerHTML = '<i class="fa-solid fa-rotate"></i> إعادة الإرسال';
};

/* ============ الخطوة 2: تأكيد الكود وإنشاء الحساب فعليًا ============ */
window.verifySignupOtp = async function(){
  clearAuthMsgs();
  var code = (document.getElementById('suOtpCode').value||'').trim();
  if(!/^[0-9]{6}$/.test(code)) return showAuthError('اكتب كود التحقق المكوّن من 6 أرقام');
  if(!signupConfirmationResult || !pendingSignupProfile){ showAuthError('انتهت صلاحية الجلسة، ابدأ التسجيل من جديد'); return backToSignupStep1(); }

  var btn = document.getElementById('verifyOtpBtn');
  btn.disabled = true; btn.innerHTML = 'جارٍ التأكيد<span class="spinner"></span>';
  var profile = pendingSignupProfile;
  try{
    var phoneCred = await signupConfirmationResult.confirm(code);

    var hiddenEmail = usernameToHiddenEmail(profile.usernameLower);
    var emailCred = firebase.auth.EmailAuthProvider.credential(hiddenEmail, profile.pass);
    var linkedResult = await phoneCred.user.linkWithCredential(emailCred);
    var uid = linkedResult.user.uid;

    pendingAccountPass = profile.pass;

    await rtdb.ref('users/'+uid).set({
      username: profile.phone, usernameLower: profile.usernameLower, displayName: profile.displayName,
      phone: profile.phone, loginType: 'phone', phoneVerified: true,
      about: 'متاح حاليًا',
      settings: { lastSeen:'everyone', notifications:true, sound:true, readReceipts:true,
                  notifPreview:true, profilePhotoPrivacy:'everyone', aboutPrivacy:'everyone', groupAddPrivacy:'everyone',
                  autoDownloadMedia:true, typingIndicator:true },
      photoURL: null, isVerified: false, isAdmin: false, exeCoins: 0,
      createdAt: firebase.database.ServerValue.TIMESTAMP
    });
    await rtdb.ref('usernames/'+profile.usernameLower).set(uid);

    // نظام الرسالة الترحيبية: أول ما يتسجل حساب جديد، يلاقي رسالة ترحيب من ZYROX في شاتاته
    try{
      var aiCfgSnap = await rtdb.ref('appConfig/ai').once('value');
      var aiCfg = aiCfgSnap.val() || {};
      var botName = aiCfg.botName || 'ZYROX';
      var welcomeTemplate = aiCfg.welcomeMessage || 'أهلاً بيك يا {username} في ZYROX 🎉\nمبسوطين إنك انضممت لينا. لو عندك أي سؤال أو محتاج مساعدة في أي وقت، ابعتلي هنا وأنا موجود.';
      var welcomeText = welcomeTemplate.split('{username}').join(profile.displayName);
      var welcomeChatId = 'ai_'+uid;
      var welcomeMembers = {}; welcomeMembers[uid]=true; welcomeMembers['ai-bot']=true;
      await rtdb.ref('chats/'+welcomeChatId).set({
        type:'ai', members: welcomeMembers, name: botName,
        lastMessage: welcomeText.split('\n')[0], lastMessageTime: firebase.database.ServerValue.TIMESTAMP,
        createdAt: firebase.database.ServerValue.TIMESTAMP
      });
      await rtdb.ref('userChats/'+uid+'/'+welcomeChatId).set(true);
      await rtdb.ref('messages/'+welcomeChatId).push().set({
        senderId:'ai-bot', senderName: botName, type:'text',
        text: welcomeText,
        timestamp: firebase.database.ServerValue.TIMESTAMP
      });
    }catch(werr){ /* لو فشلت الرسالة الترحيبية منمنعش تسجيل الحساب */ }

    showAuthSuccess('تم التحقق من رقمك وإنشاء حسابك بنجاح! جارٍ الدخول...');
    resetSignupOtpFlow();
  }catch(err){
    showAuthError(translateFirebaseError(err));
  }
  btn.disabled = false; btn.innerText = 'تأكيد الكود وإنشاء الحساب';
};

/* ============ LOGIN (بالتليفون) ============ */
window.doLogin = async function(){
  clearAuthMsgs();
  var phoneRaw = document.getElementById('loginPhone').value.trim();
  var phone = normalizePhone(phoneRaw);
  var pass = document.getElementById('loginPass').value;
  if(!isValidPhone(phone) || !pass) return showAuthError('من فضلك أدخل بياناتك بالكامل');

  var btn = document.getElementById('loginBtn');
  btn.disabled = true; btn.innerHTML = 'جارٍ الدخول<span class="spinner"></span>';
  try{
    var hiddenEmail = usernameToHiddenEmail(phone);
    pendingAccountPass = pass;
    await fbAuth.signInWithEmailAndPassword(hiddenEmail, pass);
  }catch(err){
    showAuthError(translateFirebaseError(err));
  }
  btn.disabled = false; btn.innerText = 'تسجيل الدخول';
};
