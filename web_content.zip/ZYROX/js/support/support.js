/* ZYROX — support/support.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ الدعم (SUPPORT) ============
   أي حد يكتب رسالة من هنا بتوصل للأدمن (صاحب المنصة + اللي هو معينهم أدمن). الرسايل دي منقفلة على الأدمن بس،
   محدّس (يعني ولا حتى أعضاء عاديين) بيشوفها غير الأدمن. لما الأدمن يرد على رسالة حد، الرد بيظهر لصاحب الرسالة بس
   في شات الدعم بتاعه هو، وبيبان إنه رد من فريق الدعم.
   البيانات: supportMessages/{uid}/{msgId} = {text, from:'user'|'admin', senderName, timestamp}
            supportThreads/{uid} = {userName, userPhoto, lastMessage, lastMessageTime, lastSender, unreadForAdmin, unreadForUser}
*/
var supportOwnThreadRef = null; // بيستخدمه الأدمن عشان يتابع ثريده الشخصي هو كمان (لما يتواصل مع الدعم زي أي حد)
function initSupportListeners(){
  if(supportThreadsRef) supportThreadsRef.off();
  if(supportOwnThreadRef) supportOwnThreadRef.off();
  if(currentProfile.isAdmin){
    var ownUnread = 0;
    supportThreadsRef = rtdb.ref('supportThreads');
    supportThreadsRef.on('value', function(snap){
      supportThreadsCache = snap.val() || {};
      renderSupportThreadsListIfVisible();
      syncUnifiedSupportListeners();
      var total = 0;
      Object.keys(supportThreadsCache).forEach(function(uid){ total += (supportThreadsCache[uid].unreadForAdmin||0); });
      updateSupportNavBadge(total + ownUnread);
    });
    // الأدمن كمان له ثريد شخصي مع الدعم (زي أي مستخدم عادي)، بنتابع الرسايل الجديدة اللي مش مقروءة له
    supportOwnThreadRef = rtdb.ref('supportThreads/'+currentUser.uid);
    supportOwnThreadRef.on('value', function(snap){
      var t = snap.val();
      ownUnread = (t && t.unreadForUser) || 0;
      var total = 0;
      Object.keys(supportThreadsCache).forEach(function(uid){ total += (supportThreadsCache[uid].unreadForAdmin||0); });
      updateSupportNavBadge(total + ownUnread);
    });
  }else{
    supportThreadsRef = rtdb.ref('supportThreads/'+currentUser.uid);
    supportThreadsRef.on('value', function(snap){
      var t = snap.val();
      updateSupportNavBadge((t && t.unreadForUser) || 0);
    });
  }
}

function updateSupportNavBadge(n){
  var el = document.getElementById('navSupportBadge');
  if(!el) return;
  if(n>0){ el.style.display='flex'; el.innerText = n>99?'99+':n; }
  else el.style.display='none';
}

window.loadSupportTab = function(){
  if(currentProfile.isAdmin){
    document.getElementById('supportAdminView').style.display='block';
    showSupportAdminSubview('panel');
  }else{
    document.getElementById('supportAdminView').style.display='none';
    document.getElementById('supportUserView').style.display='block';
    openOwnSupportThread();
  }
};

/* ---- الأدمن بيقدر يبدّل بين لوحة الدعم (كل الثريدات) وثريده الشخصي هو مع الدعم (زي أي حد) ---- */
window.showSupportAdminSubview = function(view){
  var panelChip = document.getElementById('supportSubTabPanelChip');
  var mineChip = document.getElementById('supportSubTabMineChip');
  var panelSub = document.getElementById('supportAdminPanelSub');
  var mineSub = document.getElementById('supportUserView');
  if(view==='mine'){
    if(panelChip) panelChip.classList.remove('active');
    if(mineChip) mineChip.classList.add('active');
    if(panelSub) panelSub.style.display='none';
    if(mineSub) mineSub.style.display='block';
    openOwnSupportThread();
  }else{
    if(mineChip) mineChip.classList.remove('active');
    if(panelChip) panelChip.classList.add('active');
    if(mineSub) mineSub.style.display='none';
    if(panelSub) panelSub.style.display='block';
    renderSupportThreadsListIfVisible();
  }
};

/* ---- يوزر عادي: ثريده الشخصي مع الدعم ---- */
function openOwnSupportThread(){
  var area = document.getElementById('supportUserMessages');
  area.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  if(supportMessagesRef) supportMessagesRef.off();
  supportMessagesRef = rtdb.ref('supportMessages/'+currentUser.uid).limitToLast(200);
  var first = true;
  supportMessagesRef.on('child_added', function(snap){
    if(first){ area.innerHTML=''; first=false; }
    renderSupportMessage(area, snap.val(), false);
    area.scrollTop = area.scrollHeight;
  });
  supportMessagesRef.once('value', function(snap){
    if(!snap.exists()) area.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-headset"></i>ابعت أي استفسار أو مشكلة وهيرد عليك فريق الدعم قريب</div>';
  });
  rtdb.ref('supportThreads/'+currentUser.uid+'/unreadForUser').set(0);
}

var SUPPORT_BAN_HOURS = 1; // مدة الحظر التلقائي عن طريق جمل الباند في الدعم
var SUPPORT_BALANCE_GRANT_DEFAULT = 100; // المبلغ الافتراضي لو الأدمن ماحددش قيمة تانية

window.sendSupportMessageAsUser = async function(){
  var input = document.getElementById('supportUserInput');
  var text = input.value.trim();
  if(!text) return;
  if(messageHasBannedWord(text)){ alert('الرسالة فيها كلمة ممنوعة، من فضلك عدّلها'); return; }
  input.value='';
  var uid = currentUser.uid;
  var senderName = currentProfile.displayName || currentProfile.username;

  // لو إحنا مستنيين منه يكتب يوزر شخص عشان نحظره أو نفك حظره (بعد ما كتب جملة الباند/فك الباند قبل كده)
  var threadSnap = await rtdb.ref('supportThreads/'+uid).once('value');
  var threadVal = threadSnap.val() || {};
  if(threadVal.awaitingBanUsername === true){
    await rtdb.ref('supportMessages/'+uid).push({
      text: text, from:'user', senderName: senderName, timestamp: firebase.database.ServerValue.TIMESTAMP
    });
    await handleBanUsernameReply(uid, text, threadVal.awaitingBanPhraseKey || null);
    return;
  }
  if(threadVal.awaitingUnbanUsername === true){
    await rtdb.ref('supportMessages/'+uid).push({
      text: text, from:'user', senderName: senderName, timestamp: firebase.database.ServerValue.TIMESTAMP
    });
    await handleUnbanUsernameReply(uid, text);
    return;
  }
  if(threadVal.awaitingVerifyUsername === true){
    await rtdb.ref('supportMessages/'+uid).push({
      text: text, from:'user', senderName: senderName, timestamp: firebase.database.ServerValue.TIMESTAMP
    });
    await handleVerifyUsernameReply(uid, text);
    return;
  }
  if(threadVal.awaitingBalanceUsername === true){
    await rtdb.ref('supportMessages/'+uid).push({
      text: text, from:'user', senderName: senderName, timestamp: firebase.database.ServerValue.TIMESTAMP
    });
    await handleBalanceUsernameReply(uid, text);
    return;
  }

  await rtdb.ref('supportMessages/'+uid).push({
    text: text, from:'user', senderName: senderName, timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update({
    userName: senderName, userPhoto: currentProfile.photoURL || null,
    lastMessage: text, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender: 'user'
  });
  incrementSupportCounter(uid, 'unreadForAdmin');

  // لو الرسالة فيها جملة من جمل الباند/فك الباند/التوثيق/الرصيد التلقائي المحفوظة، نرد تلقائي ونطلب يوزر الشخص
  var matchedBanPhraseKey = messageMatchesBanTrigger(text);
  if(matchedBanPhraseKey){
    await triggerBanFlow(uid, matchedBanPhraseKey);
  }else if(messageMatchesUnbanTrigger(text)){
    await triggerUnbanFlow(uid);
  }else if(messageMatchesVerifyTrigger(text)){
    await triggerVerifyFlow(uid);
  }else if(messageMatchesBalanceTrigger(text)){
    await triggerBalanceFlow(uid);
  }
};

/* رد تلقائي بيطلب اليوزر بعد ما اليوزر يكتب جملة باند */
async function triggerBanFlow(uid, phraseKey){
  await rtdb.ref('supportMessages/'+uid).push({
    text: 'اكتب يوزر (اسم المستخدم) الشخص اللي عايز تبلغ عنه.',
    from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update({
    lastMessage: 'اكتب يوزر الشخص اللي عايز تبلغ عنه',
    lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin',
    awaitingBanUsername: true,
    awaitingBanPhraseKey: phraseKey || null
  });
  incrementSupportCounter(uid, 'unreadForUser');
}

/* رد تلقائي بيطلب اليوزر بعد ما اليوزر يكتب جملة فك الباند */
async function triggerUnbanFlow(uid){
  await rtdb.ref('supportMessages/'+uid).push({
    text: 'اكتب يوزر (اسم المستخدم) الشخص اللي عايز تفك حظره.',
    from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update({
    lastMessage: 'اكتب يوزر الشخص اللي عايز تفك حظره',
    lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin',
    awaitingUnbanUsername: true
  });
  incrementSupportCounter(uid, 'unreadForUser');
}

/* بيستقبل اليوزر المكتوب، يدور عليه، ويحظر حسابه ساعة واحدة لو موجود -
   ولو الشخص ده اتحظر قبل كده بنفس جملة الباند دي ومقالش الجملة تاني بنفسه، ميتحظرش تاني */
async function handleBanUsernameReply(uid, usernameText, phraseKey){
  var uname = usernameText.trim().replace(/^@/,'').toLowerCase();
  var replyText;
  var clearAwaiting = true;
  try{
    var idSnap = await rtdb.ref('usernames/'+uname).once('value');
    var targetUid = idSnap.val();
    if(!targetUid){
      replyText = 'مفيش يوزر بالاسم ده، تأكد من الاسم وابعته تاني.';
      clearAwaiting = false;
    }else{
      var targetSnap = await rtdb.ref('users/'+targetUid).once('value');
      var targetUser = targetSnap.val();
      if(targetUser && (isProtectedAdminUser(targetUser) || targetUser.isAdmin)){
        replyText = 'مينفعش نحظر الحساب ده، ده حساب أدمن.';
      }else{
        var allowBan = true;
        if(phraseKey){
          var stateSnap = await rtdb.ref('banPhraseState/'+targetUid+'/'+phraseKey).once('value');
          var state = stateSnap.val() || {};
          // اتحظر قبل كده بنفس الجملة، وبعد آخر حظر مقالش الجملة تاني بنفسه => نمنع تكرار الحظر
          if(state.lastBannedAt && !(state.lastUsedAt && state.lastUsedAt > state.lastBannedAt)){
            allowBan = false;
          }
        }
        if(!allowBan){
          replyText = 'الحساب @'+uname+' اتحظر قبل كده بسبب نفس الجملة دي، ومقالش الجملة تاني بنفسه، فمش هيتحظر مرة تانية لنفس السبب.';
        }else{
          await rtdb.ref('bans/'+targetUid).set({ until: Date.now()+SUPPORT_BAN_HOURS*60*60*1000, permanent:false, reason:'حظر تلقائي عن طريق الدعم لمدة ساعة' });
          if(phraseKey) await rtdb.ref('banPhraseState/'+targetUid+'/'+phraseKey+'/lastBannedAt').set(firebase.database.ServerValue.TIMESTAMP);
          replyText = 'تم حظر الحساب @'+uname+' لمدة ساعة بنجاح.';
        }
      }
    }
  }catch(err){
    replyText = 'حصل خطأ، حاول تبعت اليوزر تاني.';
    clearAwaiting = false;
  }
  await rtdb.ref('supportMessages/'+uid).push({
    text: replyText, from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update(Object.assign({
    lastMessage: replyText, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin'
  }, clearAwaiting ? { awaitingBanUsername: false, awaitingBanPhraseKey: null } : {}));
  incrementSupportCounter(uid, 'unreadForUser');
}

/* بيستقبل اليوزر المكتوب، يدور عليه، ويفك حظره لو محظور */
async function handleUnbanUsernameReply(uid, usernameText){
  var uname = usernameText.trim().replace(/^@/,'').toLowerCase();
  var replyText;
  var clearAwaiting = true;
  try{
    var idSnap = await rtdb.ref('usernames/'+uname).once('value');
    var targetUid = idSnap.val();
    if(!targetUid){
      replyText = 'مفيش يوزر بالاسم ده، تأكد من الاسم وابعته تاني.';
      clearAwaiting = false;
    }else{
      await rtdb.ref('bans/'+targetUid).remove();
      replyText = 'تم فك الحظر عن الحساب @'+uname+' بنجاح.';
    }
  }catch(err){
    replyText = 'حصل خطأ، حاول تبعت اليوزر تاني.';
    clearAwaiting = false;
  }
  await rtdb.ref('supportMessages/'+uid).push({
    text: replyText, from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update(Object.assign({
    lastMessage: replyText, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin'
  }, clearAwaiting ? { awaitingUnbanUsername: false } : {}));
  incrementSupportCounter(uid, 'unreadForUser');
}

/* رد تلقائي بيطلب اليوزر بعد ما اليوزر يكتب جملة توثيق */
async function triggerVerifyFlow(uid){
  await rtdb.ref('supportMessages/'+uid).push({
    text: 'اكتب يوزر (اسم المستخدم) الشخص اللي عايز توثيقه.',
    from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update({
    lastMessage: 'اكتب يوزر الشخص اللي عايز توثيقه',
    lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin',
    awaitingVerifyUsername: true
  });
  incrementSupportCounter(uid, 'unreadForUser');
}

/* بيستقبل اليوزر المكتوب، يدور عليه، ويوثقه لو موجود */
async function handleVerifyUsernameReply(uid, usernameText){
  var uname = usernameText.trim().replace(/^@/,'').toLowerCase();
  var replyText;
  var clearAwaiting = true;
  try{
    var idSnap = await rtdb.ref('usernames/'+uname).once('value');
    var targetUid = idSnap.val();
    if(!targetUid){
      replyText = 'مفيش يوزر بالاسم ده، تأكد من الاسم وابعته تاني.';
      clearAwaiting = false;
    }else{
      await rtdb.ref('users/'+targetUid+'/isVerified').set({red:true});
      replyText = 'تم توثيق الحساب @'+uname+' بنجاح ✔️.';
    }
  }catch(err){
    replyText = 'حصل خطأ، حاول تبعت اليوزر تاني.';
    clearAwaiting = false;
  }
  await rtdb.ref('supportMessages/'+uid).push({
    text: replyText, from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update(Object.assign({
    lastMessage: replyText, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin'
  }, clearAwaiting ? { awaitingVerifyUsername: false } : {}));
  incrementSupportCounter(uid, 'unreadForUser');
}

/* رد تلقائي بيطلب اليوزر بعد ما اليوزر يكتب جملة الحصول على رصيد */
async function triggerBalanceFlow(uid){
  await rtdb.ref('supportMessages/'+uid).push({
    text: 'اكتب اليوزر (اسم المستخدم) اللي عايز تضيفله الرصيد.',
    from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update({
    lastMessage: 'اكتب اليوزر اللي عايز تضيفله الرصيد',
    lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin',
    awaitingBalanceUsername: true
  });
  incrementSupportCounter(uid, 'unreadForUser');
}

/* بيستقبل اليوزر المكتوب، يدور عليه، ويضيفله رصيد المبلغ المحدد من الأدمن */
async function handleBalanceUsernameReply(uid, usernameText){
  var uname = usernameText.trim().replace(/^@/,'').toLowerCase();
  var replyText;
  var clearAwaiting = true;
  try{
    var idSnap = await rtdb.ref('usernames/'+uname).once('value');
    var targetUid = idSnap.val();
    if(!targetUid){
      replyText = 'مفيش يوزر بالاسم ده، تأكد من الاسم وابعته تاني.';
      clearAwaiting = false;
    }else{
      var amtSnap = await rtdb.ref('siteConfig/supportBalanceGrantAmount').once('value');
      var amount = amtSnap.val() || SUPPORT_BALANCE_GRANT_DEFAULT;
      await rtdb.ref('users/'+targetUid+'/exeCoins').transaction(function(cur){ return (cur||0) + amount; });
      replyText = 'تم إضافة '+amount+' ZYROX لرصيد @'+uname+' بنجاح.';
    }
  }catch(err){
    replyText = 'حصل خطأ، حاول تبعت اليوزر تاني.';
    clearAwaiting = false;
  }
  await rtdb.ref('supportMessages/'+uid).push({
    text: replyText, from:'admin', senderName:'الدعم', timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update(Object.assign({
    lastMessage: replyText, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender:'admin'
  }, clearAwaiting ? { awaitingBalanceUsername: false } : {}));
  incrementSupportCounter(uid, 'unreadForUser');
}

/* ---- أدمن: قائمة كل ثريدات الدعم ---- */
function renderSupportThreadsListIfVisible(){
  var listEl = document.getElementById('supportThreadsList');
  if(!listEl || !currentProfile.isAdmin) return;
  var uids = Object.keys(supportThreadsCache);
  if(uids.length===0){ listEl.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-headset"></i>مفيش رسايل دعم لسه</div>'; return; }
  var threads = uids.map(function(uid){ return Object.assign({uid:uid}, supportThreadsCache[uid]); });
  threads.sort(function(a,b){ return (b.lastMessageTime||0)-(a.lastMessageTime||0); });
  var html = '';
  threads.forEach(function(t){
    var unread = t.unreadForAdmin||0;
    var badgeHtml = unread>0 ? '<span class="item-unread-badge">'+(unread>99?'99+':unread)+'</span>' : '';
    html += '<div class="item-card" onclick="openSupportThreadAsAdmin(\''+t.uid+'\')">'+
      avatarBlockHTML(t.userName||'مستخدم', t.userPhoto, '')+
      '<div class="item-info"><h4>'+esc(t.userName||'مستخدم')+'</h4><p>'+(t.lastSender==='admin'?'أنت: ':'')+esc(t.lastMessage||'')+'</p></div>'+
      '<div class="item-time-col"><div class="item-time">'+fmtTime(t.lastMessageTime)+'</div>'+badgeHtml+'</div></div>';
  });
  listEl.innerHTML = html;
}

window.openSupportThreadAsAdmin = function(uid){
  if(!currentProfile.isAdmin) return;
  currentSupportUid = uid;
  document.getElementById('supportChatWindow').classList.add('active');
  var t = supportThreadsCache[uid] || {};
  document.getElementById('supportChatTitle').innerText = t.userName || 'مستخدم';
  var av = document.getElementById('supportChatAvatar');
  if(t.userPhoto){
    av.innerHTML=''; av.style.cssText='width:38px;height:38px;font-size:14px;background-image:url(\''+t.userPhoto+'\');background-size:cover;background-position:center';
  }else{
    av.innerHTML = esc(avatarLetter(t.userName||'؟')); av.style.cssText='width:38px;height:38px;font-size:14px';
  }
  var area = document.getElementById('supportMessagesArea');
  area.innerHTML = '<div class="loading-msg">جارٍ تحميل الرسائل...</div>';
  if(supportMessagesRef) supportMessagesRef.off();
  supportMessagesRef = rtdb.ref('supportMessages/'+uid).limitToLast(200);
  var first = true;
  supportMessagesRef.on('child_added', function(snap){
    if(first){ area.innerHTML=''; first=false; }
    renderSupportMessage(area, snap.val(), true);
    area.scrollTop = area.scrollHeight;
  });
  supportMessagesRef.once('value', function(snap){
    if(!snap.exists()) area.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-headset"></i>مفيش رسايل لسه</div>';
  });
  rtdb.ref('supportThreads/'+uid+'/unreadForAdmin').set(0);
};

window.closeSupportChat = function(){
  document.getElementById('supportChatWindow').classList.remove('active');
  if(supportMessagesRef) supportMessagesRef.off();
  currentSupportUid = null;
};

window.sendSupportReplyAsAdmin = async function(){
  if(!currentSupportUid || !currentProfile.isAdmin) return;
  var input = document.getElementById('supportAdminReplyInput');
  var text = input.value.trim();
  if(!text) return;
  input.value='';
  await sendAdminSupportReplyTo(currentSupportUid, text);
};

/* دالة مشتركة: بترسل رد الأدمن لثريد يوزر معين (بتتستخدم من شاشة الثريد الواحد وبرده من الشات الموحد) */
async function sendAdminSupportReplyTo(uid, text, adminNameOverride){
  if(!currentProfile.isAdmin || !uid || !text) return;
  var adminName = adminNameOverride || currentProfile.displayName || currentProfile.username;
  await rtdb.ref('supportMessages/'+uid).push({
    text: text, from:'admin', senderName: adminName, timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('supportThreads/'+uid).update({
    lastMessage: text, lastMessageTime: firebase.database.ServerValue.TIMESTAMP, lastSender: 'admin'
  });
  incrementSupportCounter(uid, 'unreadForUser');
}

function incrementSupportCounter(uid, field){
  rtdb.ref('supportThreads/'+uid+'/'+field).transaction(function(cur){ return (cur||0)+1; });
}

/* ============ الشات الموحد للدعم (كل رسايل كل الثريدات في مكان واحد) ============
   بيسمح للأدمن يشوف كل رسايل الدعم مجمّعة، ولما يضغط على رسالة/اسم حد بيبقى "شايلها" فبيرد
   عليها لوحدها (شات صاحبها بس). لو رد من غير ما يشيل حد، ردّه بيتبعت لكل اللي مراسلين الدعم.
*/
var unifiedSupportListeners = {}; // uid -> ref (عشان نقدر نشيلهم لما نقفل)
var unifiedSupportMessagesData = []; // [{uid, m}]
var unifiedSupportSelectedUid = null;
var unifiedSupportSelectedName = null;
var unifiedSupportWindowOpen = false;

window.openUnifiedSupportChat = function(){
  if(!currentProfile.isAdmin) return;
  unifiedSupportWindowOpen = true;
  document.getElementById('unifiedSupportChatWindow').classList.add('active');
  document.getElementById('unifiedSupportMessagesArea').innerHTML = '<div class="loading-msg">جارٍ تحميل كل رسايل الدعم...</div>';
  unifiedSupportMessagesData = [];
  clearUnifiedSupportTarget();
  syncUnifiedSupportListeners();
};

window.closeUnifiedSupportChat = function(){
  unifiedSupportWindowOpen = false;
  document.getElementById('unifiedSupportChatWindow').classList.remove('active');
  Object.keys(unifiedSupportListeners).forEach(function(uid){ unifiedSupportListeners[uid].off(); });
  unifiedSupportListeners = {};
  unifiedSupportMessagesData = [];
  clearUnifiedSupportTarget();
};

/* بتتنادى كل مرة ثريدات الدعم تتحدث، عشان نربط listener لأي ثريد جديد ونشيل اللي اتشال */
function syncUnifiedSupportListeners(){
  if(!unifiedSupportWindowOpen || !currentProfile.isAdmin) return;
  var uids = Object.keys(supportThreadsCache);
  uids.forEach(function(uid){
    if(unifiedSupportListeners[uid]) return; // متربوط بالفعل
    var ref = rtdb.ref('supportMessages/'+uid).limitToLast(50);
    ref.on('child_added', function(snap){
      unifiedSupportMessagesData.push({ uid: uid, m: snap.val() });
      renderUnifiedSupportChatFull();
    });
    unifiedSupportListeners[uid] = ref;
  });
  Object.keys(unifiedSupportListeners).forEach(function(uid){
    if(uids.indexOf(uid)===-1){
      unifiedSupportListeners[uid].off();
      delete unifiedSupportListeners[uid];
      unifiedSupportMessagesData = unifiedSupportMessagesData.filter(function(e){ return e.uid!==uid; });
    }
  });
}

function renderUnifiedSupportChatFull(){
  var area = document.getElementById('unifiedSupportMessagesArea');
  if(!area) return;
  if(unifiedSupportMessagesData.length===0){
    area.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-layer-group"></i>مفيش رسايل دعم لسه</div>';
    return;
  }
  var sorted = unifiedSupportMessagesData.slice().sort(function(a,b){ return (a.m.timestamp||0)-(b.m.timestamp||0); });
  var html = '';
  sorted.forEach(function(entry){
    var uid = entry.uid, m = entry.m;
    var t = supportThreadsCache[uid] || {};
    var userName = t.userName || 'مستخدم';
    var sent = (m.from==='admin');
    var isSelected = (unifiedSupportSelectedUid===uid);
    var senderNameHtml = '<div class="unified-msg-sender" onclick="selectUnifiedSupportTarget(\''+uid+'\',\''+esc(userName).replace(/'/g,"\\'")+'\')" title="اضغط عشان ترد على '+esc(userName)+' لوحده"><i class="fa-solid '+(m.from==='admin'?'fa-headset':'fa-user')+'"></i>'+(m.from==='admin'?'الدعم → ':'')+esc(userName)+'</div>';
    html += '<div class="msg-row '+(sent?'sent':'received')+'" style="'+(isSelected?'outline:2px solid var(--neon-blue);border-radius:12px':'')+'">'+
      '<div class="msg-bubble">'+senderNameHtml+esc(m.text)+'<div class="msg-time">'+fmtTime(m.timestamp)+'</div></div></div>';
  });
  area.innerHTML = html;
  area.scrollTop = area.scrollHeight;
}

window.selectUnifiedSupportTarget = function(uid, name){
  unifiedSupportSelectedUid = uid;
  unifiedSupportSelectedName = name;
  document.getElementById('unifiedTargetBar').style.display='flex';
  document.getElementById('unifiedTargetName').textContent = name;
  document.getElementById('unifiedBroadcastHint').style.display='none';
  renderUnifiedSupportChatFull();
};

window.clearUnifiedSupportTarget = function(){
  unifiedSupportSelectedUid = null;
  unifiedSupportSelectedName = null;
  var bar = document.getElementById('unifiedTargetBar');
  if(bar) bar.style.display='none';
  var hint = document.getElementById('unifiedBroadcastHint');
  if(hint) hint.style.display='block';
  renderUnifiedSupportChatFull();
};

window.sendUnifiedSupportReply = async function(){
  if(!currentProfile.isAdmin) return;
  var input = document.getElementById('unifiedSupportReplyInput');
  var text = input.value.trim();
  if(!text) return;
  var adminName = currentProfile.displayName || currentProfile.username;
  if(unifiedSupportSelectedUid){
    input.value='';
    await sendAdminSupportReplyTo(unifiedSupportSelectedUid, text, adminName);
  }else{
    var uids = Object.keys(supportThreadsCache);
    if(uids.length===0){ alert('مفيش أي حد مراسل الدعم لسه'); return; }
    if(!confirm('مفيش شخص متحدد — الرد ده هيتبعت لكل اللي مراسلين الدعم وعددهم '+uids.length+'. متأكد؟')) return;
    input.value='';
    for(var i=0;i<uids.length;i++){
      await sendAdminSupportReplyTo(uids[i], text, adminName);
    }
    showBlackToast('تم إرسال الرد لكل محادثات الدعم ('+uids.length+')');
  }
};

/* viewerIsAdmin = true يعني اللي بيشوف الشاشة دلوقتي هو الأدمن (فبيبقى رده هو اللي على الشمال كـ"أنا") */
function renderSupportMessage(container, m, viewerIsAdmin){
  var sent = viewerIsAdmin ? (m.from==='admin') : (m.from==='user');
  var row = document.createElement('div');
  row.className = 'msg-row ' + (sent?'sent':'received');
  var senderLabel = (m.from==='admin' && !sent) ? '<div class="msg-sender"><i class="fa-solid fa-headset"></i> فريق الدعم</div>' : '';
  row.innerHTML = '<div class="msg-bubble">'+senderLabel+esc(m.text)+'<div class="msg-time">'+fmtTime(m.timestamp)+'</div></div>';
  container.appendChild(row);
}
