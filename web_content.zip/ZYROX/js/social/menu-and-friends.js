/* ZYROX — social/menu-and-friends.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ SIDE MENU / TABS ============ */
window.switchTab = function(tabId, el){
  document.querySelectorAll('.tab-content').forEach(function(t){ t.classList.remove('active'); });
  document.querySelectorAll('.nav-item').forEach(function(n){ n.classList.remove('active'); });
  document.getElementById(tabId).classList.add('active');
  el.classList.add('active');
  var contentEl = document.querySelector('.content');
  if(contentEl) contentEl.classList.toggle('reels-active', tabId==='videosTab');
  var fab = document.getElementById('chatsFab');
  if(fab) fab.style.display = (tabId==='chatsTab') ? 'flex' : 'none';
};
window.switchToFriendsTab = function(){
  document.getElementById('sideMenu').classList.remove('active');
  document.querySelectorAll('.tab-content').forEach(function(t){ t.classList.remove('active'); });
  document.querySelectorAll('.nav-item').forEach(function(n){ n.classList.remove('active'); });
  document.getElementById('friendsTab').classList.add('active');
  document.querySelectorAll('.nav-item')[2].classList.add('active');
  var contentEl = document.querySelector('.content');
  if(contentEl) contentEl.classList.remove('reels-active');
  var fab = document.getElementById('chatsFab');
  if(fab) fab.style.display = 'none';
  var fsInput = document.getElementById('friendSearchInput');
  if(fsInput) setTimeout(function(){ fsInput.focus(); }, 250);
};

/* ============ USER SEARCH (top bar - start chat) ============ */
window.onSearchInput = function(){
  var qRaw = document.getElementById('searchInput').value.trim();
  var q = qRaw.toLowerCase();
  var resBox = document.getElementById('searchResults');
  clearTimeout(searchDebounce);
  if(!q){ resBox.classList.remove('active'); resBox.innerHTML=''; return; }

  // لو المستخدم كتب رقمه السري بالظبط، نطلع له المحادثات المقفولة فقط
  if(/^\d{4,8}$/.test(qRaw) && currentProfile.chatLock && currentProfile.chatLock.pin && simpleHashPin(qRaw) === currentProfile.chatLock.pin){
    var lockedIds = Object.keys((currentProfile.lockedChats)||{});
    resBox.innerHTML = '';
    if(lockedIds.length===0){
      resBox.innerHTML = '<div class="loading-msg">مفيش محادثات مقفولة</div>';
    }else{
      lockedIds.forEach(function(cid){
        var c = chatsCache[cid];
        if(!c) return;
        var title;
        if(c.type==='direct'){
          var otherUid = Object.keys(c.members||{}).find(function(k){ return k!==currentUser.uid; });
          title = (c.memberNames && c.memberNames[otherUid]) || 'مستخدم';
        }else{
          title = c.name || 'محادثة';
        }
        var row = document.createElement('div');
        row.className='user-result-item';
        row.innerHTML = avatarBlockHTML(title, c.otherPhoto||c.photoURL, 'width:38px;height:38px;font-size:14px;')+
          '<div class="uinfo"><h5><i class="fa-solid fa-lock" style="color:#FFD700;font-size:11px;margin-left:5px"></i>'+esc(title)+'</h5></div>'+
          '<button class="small-btn filled">فتح</button>';
        row.querySelector('button').onclick = function(){ resBox.classList.remove('active'); resBox.innerHTML=''; document.getElementById('searchInput').value=''; openChat(cid); };
        row.onclick = function(){ resBox.classList.remove('active'); resBox.innerHTML=''; document.getElementById('searchInput').value=''; openChat(cid); };
        resBox.appendChild(row);
      });
    }
    resBox.classList.add('active');
    return;
  }

  searchDebounce = setTimeout(async function(){
    var results = [];
    var seenUids = {};
    resBox.innerHTML = '<div class="loading-msg">جارٍ البحث...</div>';
    resBox.classList.add('active');
    try{
      // بنبعت الطلبين مع بعض بالتوازي بدل ما ننتظر واحد يخلص عشان يبدأ التاني - بيقلل وقت الانتظار كتير
      var searchResults = await Promise.all([
        dbGetWithTimeout(rtdb.ref('usernames').orderByKey().startAt(q).endAt(q+'\uf8ff').limitToFirst(20), 22000),
        dbGetWithTimeout(rtdb.ref('users'), 22000)
      ]);
      var prefixRes = searchResults[0];
      var allUsersRes = searchResults[1];
      if(prefixRes.timedOut){ resBox.innerHTML = '<div class="loading-msg">الاتصال بطيء أو مفيش نت، حاول تاني</div>'; return; }
      if(prefixRes.val){
        Object.keys(prefixRes.val).forEach(function(k){
          var uid = prefixRes.val[k];
          if(uid !== currentUser.uid && !seenUids[uid]){ seenUids[uid]=true; results.push({usernameLower:k, uid:uid}); }
        });
      }
      // مطابقة يوزر/اسم يحتوي على كلمة البحث في أي مكان (مش بس أول الاسم)، عشان البحث يلاقي كل الناس مش بس المطابقة من الأول
      if(!allUsersRes.timedOut && allUsersRes.val){
        Object.keys(allUsersRes.val).forEach(function(uid){
          if(uid === currentUser.uid || seenUids[uid]) return;
          var u = allUsersRes.val[uid] || {};
          var uname = (u.username||'').toLowerCase();
          var dname = (u.displayName||'').toLowerCase();
          if(uname.indexOf(q)!==-1 || dname.indexOf(q)!==-1){
            seenUids[uid]=true;
            results.push({usernameLower:uname, uid:uid});
          }
        });
      }
    }catch(err){
      resBox.innerHTML = '<div class="loading-msg">حصل خطأ في البحث، حاول تاني</div>';
      return;
    }
    results = results.slice(0, 25);
    if(results.length===0){ resBox.innerHTML = '<div class="loading-msg">مفيش نتائج</div>'; resBox.classList.add('active'); return; }
    resBox.innerHTML = '';
    // بنجيب بيانات كل النتائج مع بعض على التوازي (أسرع من واحدة واحدة) وبعدين نرسمهم بالترتيب الأصلي
    var usersData = await Promise.all(results.map(function(r){
      return rtdb.ref('users/'+r.uid).once('value').then(function(s){ return {r:r, u:s.val()}; }).catch(function(){ return {r:r, u:null}; });
    }));
    usersData.forEach(function(item){
      var u = item.u; if(!u) return;
      var r = item.r;
      var dn = u.displayName || u.username;
      var row = document.createElement('div');
      row.className='user-result-item';
      row.innerHTML = avatarBlockHTML(dn, u.photoURL, 'width:38px;height:38px;font-size:14px;')+
        '<div class="uinfo"><h5>'+nameWithBadge(dn, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h5></div>'+
        '<button class="small-btn">بدء محادثة</button>';
      (function(uid, uname){
        row.querySelector('button').onclick = function(){ startDirectChat(uid, uname); };
      })(r.uid, dn);
      resBox.appendChild(row);
    });
    resBox.classList.add('active');
  }, 300);
};

/* ============ FRIENDS: SEARCH + SEND REQUEST ============ */
window.onFriendSearchInput = function(){
  var q = document.getElementById('friendSearchInput').value.trim().toLowerCase();
  var box = document.getElementById('friendSearchResults');
  clearTimeout(friendSearchDebounce);
  if(!q){ box.innerHTML=''; return; }
  friendSearchDebounce = setTimeout(async function(){
    box.innerHTML = '<div class="loading-msg">جارٍ البحث...</div>';
    var snapRes = await dbGetWithTimeout(rtdb.ref('usernames').orderByKey().startAt(q).endAt(q+'\uf8ff').limitToFirst(15), 22000);
    if(snapRes.timedOut){ box.innerHTML = '<div class="loading-msg">الاتصال بطيء أو مفيش نت، حاول تاني</div>'; return; }
    box.innerHTML = '';
    var uidList = snapRes.val ? Object.keys(snapRes.val).map(function(k){ return snapRes.val[k]; }).filter(function(uid){ return uid !== currentUser.uid; }) : [];
    if(!uidList.length){ box.innerHTML = '<div class="loading-msg">مفيش نتائج</div>'; return; }
    uidList.forEach(function(uid){
      rtdb.ref('users/'+uid).once('value').then(function(uSnap){
        var u = uSnap.val(); if(!u) return;
        var dn = u.displayName || u.username;
        var row = document.createElement('div');
        row.className='user-result-item';
        var already = !!friendsMap[uid];
        row.innerHTML = avatarBlockHTML(dn, u.photoURL, 'width:38px;height:38px;font-size:14px;')+
          '<div class="uinfo"><h5>'+nameWithBadge(dn, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h5></div>'+
          '<button class="small-btn" '+(already?'disabled':'')+'>'+(already?'صديق بالفعل':'إضافة صديق')+'</button>';
        if(!already){
          row.querySelector('button').onclick = function(){ sendFriendRequest(uid, dn); };
        }
        box.appendChild(row);
      }).catch(function(){});
    });
  }, 300);
};

window.sendFriendRequest = async function(toUid, toName){
  await rtdb.ref('friendRequests/'+toUid+'/'+currentUser.uid).set({
    fromUsername: currentProfile.displayName || currentProfile.username,
    timestamp: firebase.database.ServerValue.TIMESTAMP
  });
  alert('اتبعت طلب الصداقة لـ '+toName);
  onFriendSearchInput();
};

/* ============ FRIENDS: INCOMING REQUESTS ============ */
function listenFriendRequests(){
  friendReqRef = rtdb.ref('friendRequests/'+currentUser.uid);
  friendReqRef.on('value', function(snap){
    var list = document.getElementById('friendRequestsList');
    var count = snap.exists() ? Object.keys(snap.val()).length : 0;
    var badge1 = document.getElementById('menuFriendBadge');
    var badge2 = document.getElementById('navFriendBadge');
    if(count > 0){ badge1.style.display='flex'; badge1.innerText=count; badge2.style.display='flex'; badge2.innerText=count; }
    else{ badge1.style.display='none'; badge2.style.display='none'; }

    if(!snap.exists()){ list.innerHTML = '<div class="empty-hint">مفيش طلبات صداقة جديدة</div>'; return; }
    var data = snap.val();
    var html = '';
    Object.keys(data).forEach(function(fromUid){
      var req = data[fromUid];
      html += '<div class="item-card" style="cursor:default">'+
        '<div class="avatar">'+esc(avatarLetter(req.fromUsername))+'</div>'+
        '<div class="item-info"><h4>'+esc(req.fromUsername)+'</h4><p>عايز يضيفك كصديق</p></div>'+
        '<div style="display:flex;gap:6px">'+
        '<button class="small-btn filled" onclick="acceptFriendRequest(\''+fromUid+'\',\''+esc(req.fromUsername)+'\')">قبول</button>'+
        '<button class="small-btn danger" onclick="rejectFriendRequest(\''+fromUid+'\')">رفض</button>'+
        '</div></div>';
    });
    list.innerHTML = html;
  });
}

window.acceptFriendRequest = async function(fromUid, fromName){
  var updates = {};
  updates['friends/'+currentUser.uid+'/'+fromUid] = true;
  updates['friends/'+fromUid+'/'+currentUser.uid] = true;
  updates['friendRequests/'+currentUser.uid+'/'+fromUid] = null;
  await rtdb.ref().update(updates);
};
window.rejectFriendRequest = async function(fromUid){
  await rtdb.ref('friendRequests/'+currentUser.uid+'/'+fromUid).remove();
};

/* ============ FRIENDS: MY FRIENDS LIST ============ */
function listenFriendsList(){
  friendsRef = rtdb.ref('friends/'+currentUser.uid);
  friendsRef.on('value', async function(snap){
    friendsMap = snap.exists() ? snap.val() : {};
    var el = document.getElementById('friendsListEl');
    var uids = Object.keys(friendsMap);
    if(uids.length===0){ el.innerHTML = '<div class="empty-hint">لسه معندكش أصدقاء</div>'; return; }
    var usersData = await Promise.all(uids.map(function(uid){
      return rtdb.ref('users/'+uid).once('value').then(function(s){ return {uid:uid, u:s.val()}; });
    }));
    var html = '';
    usersData.forEach(function(item){
      var u = item.u; if(!u) return;
      var uid = item.uid;
      var dn = u.displayName || u.username;
      html += '<div class="item-card" onclick="startDirectChat(\''+uid+'\',\''+esc(dn)+'\')">'+
        avatarBlockHTML(dn, u.photoURL, '')+
        '<div class="item-info"><h4>'+nameWithBadge(dn, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h4><p>اضغط لبدء محادثة</p></div></div>';
    });
    el.innerHTML = html;
  });
}

/* ============ BLOCKED USERS ============ */
function listenBlockedList(){
  rtdb.ref('blocked/'+currentUser.uid).on('value', async function(snap){
    blockedMap = snap.exists() ? snap.val() : {};
    var el = document.getElementById('blockedListEl');
    if(!el) return;
    var uids = Object.keys(blockedMap);
    if(uids.length===0){ el.innerHTML = '<div class="loading-msg">لا يوجد محظورين</div>'; return; }
    var usersData = await Promise.all(uids.map(function(uid){
      return rtdb.ref('users/'+uid).once('value').then(function(s){ return {uid:uid, u:s.val()}; });
    }));
    var html = '';
    usersData.forEach(function(item){
      var u = item.u; if(!u) return;
      var dn = u.displayName || u.username;
      html += '<div class="settings-row"><div class="label">'+esc(dn)+'</div><button class="small-btn" onclick="unblockUser(\''+item.uid+'\')">إلغاء الحظر</button></div>';
    });
    el.innerHTML = html;
  });
}
window.unblockUser = async function(uid){ await rtdb.ref('blocked/'+currentUser.uid+'/'+uid).remove(); };

/* ============ متابعة (FOLLOW) ============
   following/{uid}/{targetUid}=true ، followers/{uid}/{followerUid}=true
   users/{uid}/followersCount و followingCount بيتحدثوا مع كل متابعة/إلغاء متابعة
*/
window.toggleFollowUser = async function(targetUid){
  if(!currentUser || !targetUid || targetUid===currentUser.uid) return;
  var myUid = currentUser.uid;
  var followRef = rtdb.ref('following/'+myUid+'/'+targetUid);
  try{
    var snap = await followRef.once('value');
    if(snap.exists()){
      await followRef.remove();
      await rtdb.ref('followers/'+targetUid+'/'+myUid).remove();
      await rtdb.ref('users/'+myUid+'/followingCount').transaction(function(c){ return Math.max((c||0)-1,0); });
      await rtdb.ref('users/'+targetUid+'/followersCount').transaction(function(c){ return Math.max((c||0)-1,0); });
    }else{
      await followRef.set(true);
      await rtdb.ref('followers/'+targetUid+'/'+myUid).set(true);
      await rtdb.ref('users/'+myUid+'/followingCount').transaction(function(c){ return (c||0)+1; });
      await rtdb.ref('users/'+targetUid+'/followersCount').transaction(function(c){ return (c||0)+1; });
    }
    window.openUserProfile(targetUid);
  }catch(err){
    alert('حصل خطأ، حاول تاني');
  }
};

window.toggleBlockByUid = async function(uid){
  if(blockedMap[uid]){
    if(confirm('تلغي حظر المستخدم ده؟')) await rtdb.ref('blocked/'+currentUser.uid+'/'+uid).remove();
  }else{
    if(confirm('تحظر المستخدم ده؟ مش هيقدر يبعتلك رسايل')) await rtdb.ref('blocked/'+currentUser.uid+'/'+uid).set(true);
  }
  window.openUserProfile(uid);
};
