/* ZYROX — social/posts-and-reels.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ المنشورات (Posts) ============ */
var pendingPostMedia = null; // {type:'image'|'video', dataUrl, duration}
var currentOpenCommentsPostId = null;

var postComposeMode = 'post'; // 'post' | 'video'

window.openPostComposeModal = function(){
  postComposeMode = 'post';
  document.getElementById('postComposeTitle').innerText = 'منشور جديد';
  document.getElementById('postImageBtn').style.display = 'flex';
  document.getElementById('postTextInput').value = '';
  removePostMedia();
  document.getElementById('postComposeModal').classList.add('active');
};

window.openVideoComposeModal = function(){
  postComposeMode = 'video';
  document.getElementById('postComposeTitle').innerText = 'فيديو جديد';
  document.getElementById('postImageBtn').style.display = 'none';
  document.getElementById('postTextInput').value = '';
  removePostMedia();
  document.getElementById('postComposeModal').classList.add('active');
};

window.attachPostImage = function(inputEl){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value='';
  if(file.size > 6*1024*1024){ alert('الصورة كبيرة، اختار صورة أصغر من 6 ميجا'); return; }
  compressImage(file, function(dataUrl){
    pendingPostMedia = { type:'image', dataUrl: dataUrl };
    var prev = document.getElementById('postMediaPreview');
    prev.style.display='block';
    prev.innerHTML = '<img src="'+dataUrl+'" style="width:100%;border-radius:10px;max-height:220px;object-fit:cover">';
    document.getElementById('postRemoveMediaBtn').style.display='inline-block';
  });
};

window.attachPostVideo = function(inputEl){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value='';
  if(file.size > 60*1024*1024){ alert('الفيديو كبير، اختار فيديو أصغر من 60 ميجا عشان يترفع صح'); return; }
  checkVideoDuration(file, 200, function(ok, dur){
    if(!ok){ alert('الفيديو لازم يكون 200 ثانية أو أقل (طول الفيديو ده '+Math.round(dur)+' ثانية)'); return; }
    if(!currentUser){ alert('لازم تسجل دخول الأول'); return; }
    showUploadOverlay('جارٍ رفع الفيديو...', 'من فضلك ماتقفلش الصفحة لحد ما يخلص');
    var storagePath = 'postVideos/'+currentUser.uid+'/'+Date.now()+'_'+file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
    var uploadTask = fbStorage.ref(storagePath).put(file);
    uploadTask.on('state_changed', function(snap){
      if(snap.totalBytes){
        var pct = Math.round((snap.bytesTransferred/snap.totalBytes)*100);
        showUploadOverlay('جارٍ رفع الفيديو... '+pct+'%', 'من فضلك ماتقفلش الصفحة لحد ما يخلص');
      }
    }, function(err){
      hideUploadOverlay();
      alert('تعذر رفع الفيديو، حاول تاني');
    }, function(){
      uploadTask.snapshot.ref.getDownloadURL().then(function(url){
        hideUploadOverlay();
        pendingPostMedia = { type:'video', dataUrl: url, duration: dur, storagePath: storagePath };
        var prev = document.getElementById('postMediaPreview');
        prev.style.display='block';
        prev.innerHTML = '<video src="'+url+'" controls style="width:100%;border-radius:10px;max-height:220px"></video>';
        document.getElementById('postRemoveMediaBtn').style.display='inline-block';
      }).catch(function(){
        hideUploadOverlay();
        alert('تعذر رفع الفيديو، حاول تاني');
      });
    });
  });
};

window.removePostMedia = function(){
  if(pendingPostMedia && pendingPostMedia.storagePath){
    fbStorage.ref(pendingPostMedia.storagePath).delete().catch(function(){});
  }
  pendingPostMedia = null;
  document.getElementById('postMediaPreview').style.display='none';
  document.getElementById('postMediaPreview').innerHTML='';
  document.getElementById('postRemoveMediaBtn').style.display='none';
};

var DAILY_POST_LIMIT = 4;

window.submitPost = async function(){
  if(currentProfile.postingBanned){ alert('الأدمن وقف قدرتك على نشر منشورات جديدة دلوقتي.'); return; }
  var text = document.getElementById('postTextInput').value.trim();
  if(postComposeMode==='video'){
    if(!pendingPostMedia || pendingPostMedia.type!=='video'){ alert('ضيف فيديو الأول'); return; }
  }else{
    if(!text && !pendingPostMedia){ alert('اكتب حاجة أو ضيف صورة/فيديو الأول'); return; }
  }
  var now = Date.now();
  var startOfDay = new Date(); startOfDay.setHours(0,0,0,0);
  try{
    var mySnap = await rtdb.ref('posts').orderByChild('authorId').equalTo(currentUser.uid).once('value');
    var myCountToday = 0;
    if(mySnap.exists()){
      var mine = mySnap.val();
      Object.keys(mine).forEach(function(k){
        if((mine[k].tsLocal||0) >= startOfDay.getTime()) myCountToday++;
      });
    }
    if(myCountToday >= DAILY_POST_LIMIT){
      alert('وصلت للحد الأقصى من المنشورات النهاردة ('+DAILY_POST_LIMIT+' منشورات)، جرب تاني بكرة.');
      return;
    }
  }catch(err){
    // لو فشل الفحص، منكملش عشان منضمنش تجاوز الحد
    alert('تعذر التأكد من عدد منشوراتك النهاردة، حاول تاني');
    return;
  }
  var payload = {
    authorId: currentUser.uid,
    authorName: currentProfile.displayName || currentProfile.username,
    authorPhoto: currentProfile.photoURL || null,
    authorVerified: currentProfile.isVerified || null,
    text: text || '',
    mediaType: pendingPostMedia ? pendingPostMedia.type : null,
    mediaData: pendingPostMedia ? pendingPostMedia.dataUrl : null,
    ts: firebase.database.ServerValue.TIMESTAMP,
    tsLocal: now
  };
  var isVideoPost = pendingPostMedia && pendingPostMedia.type==='video';
  if(isVideoPost) showUploadOverlay('جارٍ نشر الفيديو...', 'من فضلك ماتقفلش الصفحة لحد ما يخلص');
  try{
    await rtdb.ref('posts').push(payload);
    window.closeModal('postComposeModal');
    if(postComposeMode==='video'){ loadVideosFeed(true); alert('تم نشر الفيديو'); }
    else{ loadPostsFeed(true); alert('تم نشر المنشور'); }
  }catch(err){
    alert('تعذر نشر المنشور، حاول تاني');
  }finally{
    if(isVideoPost) hideUploadOverlay();
  }
};

function renderPostCardHTML(p){
  var avatarHtml = p.authorPhoto ? '<div class="avatar" style="background-image:url(\''+p.authorPhoto+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar">'+esc(avatarLetter(p.authorName||'؟'))+'</div>';
  var mediaHtml = '';
  if(p.mediaType==='image') mediaHtml = '<div class="post-media" onclick="openMediaViewerFromPost(\''+p.id+'\')"><img src="'+p.mediaData+'" alt=""></div>';
  else if(p.mediaType==='video') mediaHtml = '<div class="post-media" onclick="openMediaViewerFromPost(\''+p.id+'\')"><video src="'+p.mediaData+'" muted playsinline></video></div>';
  var liked = !!(p.likes && p.likes[currentUser.uid]);
  var likeCount = p.likes ? Object.keys(p.likes).length : 0;
  var isMine = p.authorId === currentUser.uid;
  return '<div class="post-card">'+
    '<div class="post-head">'+avatarHtml+
    '<div class="pinfo"><h5>'+nameWithBadge(p.authorName||'؟', p.authorVerified)+'</h5><span>'+fmtTime(p.ts||p.tsLocal)+'</span></div>'+
    (isMine ? '<div class="header-icon" style="font-size:15px" onclick="deletePost(\''+p.id+'\')"><i class="fa-solid fa-trash"></i></div>' : '')+
    '</div>'+
    (p.text ? '<div class="post-text">'+esc(p.text)+'</div>' : '')+
    mediaHtml+
    '<div class="post-actions">'+
      '<div class="post-action-btn'+(liked?' liked':'')+'" onclick="togglePostLike(\''+p.id+'\')"><i class="fa-solid fa-heart"></i> <span>'+likeCount+'</span></div>'+
      '<div class="post-action-btn" onclick="openPostComments(\''+p.id+'\')"><i class="fa-solid fa-comment"></i> <span>'+(p.commentsCount||0)+'</span></div>'+
    '</div>'+
  '</div>';
}

/* ============ كاش المنشورات (صور + نصوص) ============ */
var postsRawCache = null;
var postsRawCacheTime = 0;
var POSTS_CACHE_MS = 20000; // مدة صلاحية الكاش قبل ما نجيب داتا جديدة من السيرفر
function loadPostsCacheFromDisk(){
  if(postsRawCache) return postsRawCache;
  try{
    var raw = localStorage.getItem('exe_posts_cache');
    if(raw){ postsRawCache = JSON.parse(raw); postsRawCacheTime = 0; /* كاش قديم، لازم يتحدث في الخلفية */ }
  }catch(e){}
  return postsRawCache;
}
async function getPostsRaw(forceRefresh){
  if(!forceRefresh && postsRawCache && (Date.now()-postsRawCacheTime) < POSTS_CACHE_MS) return postsRawCache;
  var snap = await rtdb.ref('posts').limitToLast(20).once('value');
  postsRawCache = snap.exists() ? snap.val() : {};
  postsRawCacheTime = Date.now();
  try{ localStorage.setItem('exe_posts_cache', JSON.stringify(postsRawCache)); }catch(e){}
  return postsRawCache;
}

/* ============ كاش الفيديوهات (منفصل عن كاش الصور/النصوص) ============
   قبل كده الفيديوهات كانت بتتفلتر من نفس المجموعة المحدودة اللي بتيجي لقسم
   المنشورات (آخر 20 عنصر مهما كان نوعه)، فلو أغلب المنشورات الأخيرة صور،
   قسم الفيديوهات كان بيطلع فاضي أو شبه فاضي حتى لو فيه فيديوهات موجودة فعلاً.
   عشان كده الفيديوهات بقى ليها استعلام خاص بيها بيجيب آخر فيديوهات فعليًا
   بغض النظر عن عدد الصور/المنشورات النصية اللي بينها. */
var videosRawCache = null;
var videosRawCacheTime = 0;
function loadVideosCacheFromDisk(){
  if(videosRawCache) return videosRawCache;
  try{
    var raw = localStorage.getItem('exe_videos_cache');
    if(raw){ videosRawCache = JSON.parse(raw); videosRawCacheTime = 0; }
  }catch(e){}
  return videosRawCache;
}
async function getVideosRaw(forceRefresh){
  if(!forceRefresh && videosRawCache && (Date.now()-videosRawCacheTime) < POSTS_CACHE_MS) return videosRawCache;
  var snap = await rtdb.ref('posts').orderByChild('mediaType').equalTo('video').limitToLast(20).once('value');
  videosRawCache = snap.exists() ? snap.val() : {};
  videosRawCacheTime = Date.now();
  try{ localStorage.setItem('exe_videos_cache', JSON.stringify(videosRawCache)); }catch(e){}
  return videosRawCache;
}

window.loadPostsFeed = async function(forceRefresh){
  var feedEl = document.getElementById('postsFeed');
  var diskCache = loadPostsCacheFromDisk();
  var hadCache = !!diskCache;
  if(hadCache){
    // عرض فوري من الكاش المحفوظ من غير ما نستنى النت خالص
    var cachedPosts = Object.keys(diskCache).map(function(k){ return Object.assign({id:k}, diskCache[k]); }).filter(function(p){ return p.mediaType!=='video'; });
    cachedPosts.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
    feedEl.innerHTML = cachedPosts.length ? cachedPosts.map(renderPostCardHTML).join('') : '<div class="loading-msg">جارٍ التحميل...</div>';
  }else{
    feedEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  }
  var postsObj = await getPostsRaw(forceRefresh);
  var posts = Object.keys(postsObj).map(function(k){ return Object.assign({id:k}, postsObj[k]); }).filter(function(p){ return p.mediaType!=='video'; });
  posts.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });

  if(posts.length===0){
    feedEl.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-newspaper"></i>مفيش منشورات لسه.. كن أول واحد ينشر!</div>';
    return;
  }
  feedEl.innerHTML = posts.map(renderPostCardHTML).join('');
};

/* خلط عشوائي (Fisher-Yates) عشان فيد الفيديوهات يطلع بترتيب مختلف كل مرة */
function shuffleArray(arr){
  for(var i=arr.length-1;i>0;i--){
    var j = Math.floor(Math.random()*(i+1));
    var tmp = arr[i]; arr[i]=arr[j]; arr[j]=tmp;
  }
  return arr;
}

/* كاش بسيط للمتابَعين عشان نعرف نظهر زرار المتابعة صح فوق كل فيديو من غير ما نسأل السيرفر لكل فيديو لوحده */
var myFollowingSet = null;
async function loadMyFollowingSet(forceRefresh){
  if(myFollowingSet && !forceRefresh) return myFollowingSet;
  var snap = await rtdb.ref('following/'+currentUser.uid).once('value');
  myFollowingSet = snap.exists() ? snap.val() : {};
  return myFollowingSet;
}

window.loadVideosFeed = async function(forceRefresh){
  var feedEl = document.getElementById('videosFeed');
  await loadMyFollowingSet();
  var diskCache = loadVideosCacheFromDisk();
  var hadCache = !!diskCache;
  if(hadCache){
    var cachedVideos = Object.keys(diskCache).map(function(k){ return Object.assign({id:k}, diskCache[k]); }).filter(function(p){ return p.mediaType==='video'; });
    shuffleArray(cachedVideos);
    feedEl.innerHTML = cachedVideos.length ? cachedVideos.map(renderReelCardHTML).join('') : '<div class="loading-msg">جارٍ التحميل...</div>';
    if(cachedVideos.length) setupVideoFeedAutoplay();
  }else{
    feedEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  }
  var postsObj = await getVideosRaw(forceRefresh);
  var videos = Object.keys(postsObj).map(function(k){ return Object.assign({id:k}, postsObj[k]); }).filter(function(p){ return p.mediaType==='video'; });
  shuffleArray(videos);

  if(videos.length===0){
    feedEl.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-video"></i>مفيش فيديوهات لسه.. كن أول واحد ينشر!</div>';
    return;
  }
  feedEl.innerHTML = videos.map(renderReelCardHTML).join('');
  setupVideoFeedAutoplay();
};

/* ============ كارت فيديو بشكل تيك توك (فُل سكرين + لايك/متابعة/تعليق) ============ */
function renderReelCardHTML(p){
  var avatarHtml = p.authorPhoto ? '<div class="avatar" style="background-image:url(\''+p.authorPhoto+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar">'+esc(avatarLetter(p.authorName||'؟'))+'</div>';
  var liked = !!(p.likes && p.likes[currentUser.uid]);
  var likeCount = p.likes ? Object.keys(p.likes).length : 0;
  var isMine = p.authorId === currentUser.uid;
  var isFollowing = !!(myFollowingSet && myFollowingSet[p.authorId]);
  return '<div class="reel-item" data-post-id="'+p.id+'">'+
    '<video src="'+p.mediaData+'" muted playsinline loop onclick="toggleReelPlay(this)"></video>'+
    '<div class="reel-mute-btn" onclick="event.stopPropagation();toggleReelMute(this)"><i class="fa-solid fa-volume-xmark"></i></div>'+
    '<div class="reel-side">'+
      '<div class="reel-avatar-wrap" onclick="event.stopPropagation();openUserProfile(\''+p.authorId+'\')">'+avatarHtml+
        (isMine ? '' : '<div class="reel-follow-dot'+(isFollowing?' following':'')+'" onclick="event.stopPropagation();toggleReelFollow(\''+p.authorId+'\',this)"><i class="fa-solid '+(isFollowing?'fa-check':'fa-plus')+'"></i></div>')+
      '</div>'+
      '<div class="reel-action'+(liked?' liked':'')+'" onclick="event.stopPropagation();toggleReelLike(\''+p.id+'\',this)"><i class="fa-solid fa-heart"></i><span>'+likeCount+'</span></div>'+
      '<div class="reel-action" onclick="event.stopPropagation();openPostComments(\''+p.id+'\')"><i class="fa-solid fa-comment"></i><span>'+(p.commentsCount||0)+'</span></div>'+
      '<div class="reel-action" onclick="event.stopPropagation();shareVideoLink(\''+p.id+'\')"><i class="fa-solid fa-share"></i></div>'+
      (isMine ? '<div class="reel-action" onclick="event.stopPropagation();deletePost(\''+p.id+'\')"><i class="fa-solid fa-trash"></i></div>' : '')+
    '</div>'+
    '<div class="reel-bottom-info">'+
      '<h5>'+nameWithBadge(p.authorName||'؟', p.authorVerified)+'</h5>'+
      (p.text ? '<p>'+esc(p.text)+'</p>' : '')+
    '</div>'+
  '</div>';
}

window.toggleReelPlay = function(video){
  if(video.paused) video.play(); else video.pause();
};
window.toggleReelMute = function(btn){
  var video = btn.parentElement.querySelector('video');
  video.muted = !video.muted;
  btn.innerHTML = video.muted ? '<i class="fa-solid fa-volume-xmark"></i>' : '<i class="fa-solid fa-volume-high"></i>';
};
window.toggleReelLike = async function(postId, el){
  var span = el.querySelector('span');
  var count = parseInt(span.innerText, 10) || 0;
  var ref = rtdb.ref('posts/'+postId+'/likes/'+currentUser.uid);
  try{
    var snap = await ref.once('value');
    if(snap.exists()){
      await ref.remove();
      el.classList.remove('liked'); span.innerText = Math.max(count-1, 0);
    }else{
      await ref.set(true);
      el.classList.add('liked'); span.innerText = count+1;
    }
  }catch(err){ /* لو فشل الاتصال منسيبش الشكل يتغير غلط */ }
};
window.toggleReelFollow = async function(targetUid, el){
  if(!currentUser || !targetUid || targetUid===currentUser.uid) return;
  var myUid = currentUser.uid;
  var followRef = rtdb.ref('following/'+myUid+'/'+targetUid);
  try{
    var snap = await followRef.once('value');
    if(snap.exists()){
      await followRef.remove();
      await rtdb.ref('followers/'+targetUid+'/'+myUid).remove();
      await rtdb.ref('users/'+myUid+'/followingCount').transaction(function(c){ return Math.max((c||0)-1,0); });
      await rtdb.ref('users/'+targetUid+'/followersCount').transaction(function(c){ return Math.max((c||0)-1,0); });
      if(myFollowingSet) delete myFollowingSet[targetUid];
      el.classList.remove('following'); el.innerHTML = '<i class="fa-solid fa-plus"></i>';
    }else{
      await followRef.set(true);
      await rtdb.ref('followers/'+targetUid+'/'+myUid).set(true);
      await rtdb.ref('users/'+myUid+'/followingCount').transaction(function(c){ return (c||0)+1; });
      await rtdb.ref('users/'+targetUid+'/followersCount').transaction(function(c){ return (c||0)+1; });
      if(myFollowingSet) myFollowingSet[targetUid] = true;
      el.classList.add('following'); el.innerHTML = '<i class="fa-solid fa-check"></i>';
    }
  }catch(err){
    alert('حصل خطأ، حاول تاني');
  }
};

/* لما تقلب من فيديو لفيديو تاني في فيد الفيديوهات: الفيديو اللي طلع بره الشاشة يقفل، واللي دخل الشاشة يشتغل تلقائي */
var videosFeedObserver = null;
function setupVideoFeedAutoplay(){
  var feedEl = document.getElementById('videosFeed');
  if(!feedEl) return;
  if(videosFeedObserver){ videosFeedObserver.disconnect(); videosFeedObserver = null; }
  var vids = Array.prototype.slice.call(feedEl.querySelectorAll('video'));
  if(!vids.length) return;
  videosFeedObserver = new IntersectionObserver(function(entries){
    entries.forEach(function(entry){
      var v = entry.target;
      if(entry.isIntersecting && entry.intersectionRatio >= 0.6){
        vids.forEach(function(other){ if(other!==v && !other.paused) other.pause(); });
        if(v.paused){
          v.muted = false; // الصوت يشتغل تلقائي زي المطلوب
          var playPromise = v.play();
          if(playPromise && playPromise.catch) playPromise.catch(function(){
            v.muted = true; v.play().catch(function(){}); // لو المتصفح رفض الصوت التلقائي، شغّل صامت واحتفظ بإمكانية الفتح الكامل بالصوت بالضغط
          });
        }
      }else{
        if(!v.paused) v.pause();
      }
    });
  }, { threshold: [0, 0.6, 1] });
  vids.forEach(function(v){ videosFeedObserver.observe(v); });
}

function refreshFeedsAfterPostChange(){
  var postsTabActive = document.getElementById('postsTab').classList.contains('active');
  var videosTabActive = document.getElementById('videosTab').classList.contains('active');
  if(postsTabActive) loadPostsFeed(true);
  if(videosTabActive) loadVideosFeed(true);
  if(!postsTabActive && !videosTabActive){ loadPostsFeed(true); loadVideosFeed(true); }
}

window.togglePostLike = async function(postId){
  var ref = rtdb.ref('posts/'+postId+'/likes/'+currentUser.uid);
  var snap = await ref.once('value');
  if(snap.exists()) await ref.remove();
  else await ref.set(true);
  refreshFeedsAfterPostChange();
};

window.deletePost = async function(postId){
  if(!confirm('تمسح المنشور ده؟')) return;
  await rtdb.ref('posts/'+postId).remove();
  await rtdb.ref('postComments/'+postId).remove();
  refreshFeedsAfterPostChange();
};

window.openPostComments = async function(postId){
  currentOpenCommentsPostId = postId;
  document.getElementById('postCommentInput').value='';
  var listEl = document.getElementById('postCommentsList');
  listEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  document.getElementById('postCommentsScreen').classList.add('active');
  var snap = await rtdb.ref('postComments/'+postId).once('value');
  if(!snap.exists()){
    listEl.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-comment"></i>لسه مفيش تعليقات، اكتب أول تعليق!</div>';
    return;
  }
  var commentsObj = snap.val();
  var comments = Object.keys(commentsObj).map(function(k){ return Object.assign({id:k}, commentsObj[k]); });
  comments.sort(function(a,b){ return (a.tsLocal||0)-(b.tsLocal||0); });
  listEl.innerHTML = comments.map(function(c){
    var avatarHtml = c.authorPhoto ? '<div class="avatar" style="background-image:url(\''+c.authorPhoto+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar">'+esc(avatarLetter(c.authorName||'؟'))+'</div>';
    return '<div class="comment-row">'+avatarHtml+'<div class="cbody"><h6>'+esc(c.authorName||'؟')+'</h6><p>'+esc(c.text)+'</p></div></div>';
  }).join('');
};

window.submitPostComment = async function(){
  var postId = currentOpenCommentsPostId;
  if(!postId) return;
  var input = document.getElementById('postCommentInput');
  var text = input.value.trim();
  if(!text) return;
  input.value='';
  var now = Date.now();
  await rtdb.ref('postComments/'+postId).push({
    authorId: currentUser.uid,
    authorName: currentProfile.displayName || currentProfile.username,
    authorPhoto: currentProfile.photoURL || null,
    text: text,
    ts: firebase.database.ServerValue.TIMESTAMP,
    tsLocal: now
  });
  await rtdb.ref('posts/'+postId+'/commentsCount').transaction(function(cur){ return (cur||0) + 1; });
  openPostComments(postId);
};
