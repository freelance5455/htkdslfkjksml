/* ZYROX — social/games.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ===================== GAMES / الألعاب ===================== */
var pendingGameImage = null;
var pendingGameHtmlContent = null;

window.openGameComposeModal = function(){
  document.getElementById('gameNameInput').value = '';
  document.getElementById('gameImagePreview').style.display = 'none';
  document.getElementById('gameHtmlFileName').innerHTML = '';
  pendingGameImage = null;
  pendingGameHtmlContent = null;
  document.getElementById('gameComposeModal').classList.add('active');
};

window.attachGameImage = function(input){
  var file = input.files && input.files[0];
  if(!file) return;
  if(file.size > 3*1024*1024){ alert('الصورة كبيرة، اختار صورة أصغر من 3 ميجا'); return; }
  readFileAsDataURL(file, function(dataUrl){
    pendingGameImage = dataUrl;
    var prev = document.getElementById('gameImagePreview');
    prev.style.display = 'block';
    prev.querySelector('img').src = dataUrl;
  });
};

window.attachGameHtml = function(input){
  var file = input.files && input.files[0];
  if(!file) return;
  if(file.size > 3*1024*1024){ alert('ملف اللعبة كبير، اختار ملف أصغر من 3 ميجا'); return; }
  var reader = new FileReader();
  reader.onload = function(e){
    pendingGameHtmlContent = e.target.result;
    document.getElementById('gameHtmlFileName').innerHTML = '<i class="fa-solid fa-circle-check" style="color:var(--neon-blue)"></i> '+esc(file.name);
  };
  reader.onerror = function(){ alert('تعذر قراءة الملف، حاول تاني'); };
  reader.readAsText(file);
};

window.submitGame = async function(){
  var title = document.getElementById('gameNameInput').value.trim();
  if(!title){ alert('اكتب اسم اللعبة'); return; }
  if(!pendingGameImage){ alert('ضيف صورة غلاف للعبة'); return; }
  if(!pendingGameHtmlContent){ alert('ارفع ملف html للعبة'); return; }
  var payload = {
    title: title,
    coverImage: pendingGameImage,
    htmlContent: pendingGameHtmlContent,
    authorId: currentUser.uid,
    authorName: currentProfile.displayName || currentProfile.username,
    authorPhoto: currentProfile.photoURL || null,
    status: 'pending',
    ts: firebase.database.ServerValue.TIMESTAMP,
    tsLocal: Date.now()
  };
  showUploadOverlay('جارٍ نشر اللعبة...', 'من فضلك ماتقفلش الصفحة لحد ما تخلص');
  try{
    await rtdb.ref('games').push(payload);
    window.closeModal('gameComposeModal');
    alert('تم إرسال اللعبة للمراجعة، هتظهر في القسم بعد موافقة الأدمن');
    loadGamesFeed();
  }catch(err){
    alert('تعذر إرسال اللعبة، حاول تاني');
  }finally{
    hideUploadOverlay();
  }
};

function renderGameCardHTML(g){
  var cover = g.coverImage ? '<img class="gcover" src="'+g.coverImage+'" alt="">' : '<div class="gcover-fallback"><i class="fa-solid fa-gamepad"></i></div>';
  var avatarHtml = g.authorPhoto ? '<div class="avatar gav" style="background-image:url(\''+g.authorPhoto+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar gav">'+esc(avatarLetter(g.authorName||'؟'))+'</div>';
  return '<div class="game-card" onclick="openGamePlayer(\''+g.id+'\')">'+cover+
    '<div class="gbody"><div class="gtitle">'+esc(g.title||'لعبة')+'</div>'+
    '<div class="gauthor">'+avatarHtml+'<span>'+esc(g.authorName||'؟')+'</span></div></div></div>';
}

var gamesRawCache = null;
function loadGamesCacheFromDisk(){
  if(gamesRawCache) return gamesRawCache;
  try{
    var raw = localStorage.getItem('exe_games_cache');
    if(raw) gamesRawCache = JSON.parse(raw);
  }catch(e){}
  return gamesRawCache;
}
window.loadGamesFeed = async function(){
  var gridEl = document.getElementById('gamesGrid');
  var diskCache = loadGamesCacheFromDisk();
  if(diskCache){
    // عرض فوري من آخر نسخة محفوظة على الجهاز من غير ما نستنى النت، وبعدين نجيب الأحدث في الخلفية
    var cachedApproved = Object.keys(diskCache).map(function(k){ return Object.assign({id:k}, diskCache[k]); }).filter(function(g){ return g.status==='approved'; });
    cachedApproved.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
    gridEl.innerHTML = cachedApproved.length ? cachedApproved.map(renderGameCardHTML).join('') : '<div class="loading-msg">جارٍ التحميل...</div>';
  }else{
    gridEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  }
  var snap = await rtdb.ref('games').limitToLast(20).once('value');
  var obj = snap.exists() ? snap.val() : {};
  gamesRawCache = obj;
  try{ localStorage.setItem('exe_games_cache', JSON.stringify(obj)); }catch(e){}
  var all = Object.keys(obj).map(function(k){ return Object.assign({id:k}, obj[k]); });
  var approved = all.filter(function(g){ return g.status==='approved'; });
  approved.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
  gridEl.innerHTML = approved.length ? approved.map(renderGameCardHTML).join('') : '<div class="empty-hint" style="grid-column:1/-1"><i class="fa-solid fa-gamepad"></i>مفيش ألعاب لسه.. كن أول واحد ينشر لعبة!</div>';

  var mine = all.filter(function(g){ return currentUser && g.authorId===currentUser.uid && g.status!=='approved'; });
  var wrap = document.getElementById('myGameSubmissionsWrap');
  var listEl = document.getElementById('myGameSubmissions');
  if(mine.length===0){ wrap.style.display='none'; return; }
  mine.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
  wrap.style.display = 'block';
  listEl.innerHTML = mine.map(function(g){
    var badge = g.status==='pending' ? '<span class="game-status-badge pending" style="position:static">قيد المراجعة</span>' : '<span class="game-status-badge rejected" style="position:static">مرفوضة</span>';
    var cover = g.coverImage ? '<img src="'+g.coverImage+'" alt="">' : '';
    return '<div class="game-submit-row">'+cover+'<div class="gsinfo"><h5>'+esc(g.title||'لعبة')+'</h5></div>'+badge+'</div>';
  }).join('');
};

window.openGamePlayer = async function(gameId){
  document.getElementById('gpFrame').srcdoc = '';
  document.getElementById('gpTitle').innerText = '...';
  document.getElementById('gpAuthor').innerText = '';
  document.getElementById('gamePlayerScreen').classList.add('active');
  var snap = await rtdb.ref('games/'+gameId).once('value');
  var g = snap.val();
  if(!g){ document.getElementById('gpTitle').innerText = 'اللعبة غير موجودة'; return; }
  document.getElementById('gpTitle').innerText = g.title || 'لعبة';
  document.getElementById('gpAuthor').innerText = 'بواسطة ' + (g.authorName || '؟');
  document.getElementById('gpFrame').srcdoc = g.htmlContent || '<body style="font-family:sans-serif;text-align:center;margin-top:40px">تعذر تحميل اللعبة</body>';
  rtdb.ref('games/'+gameId+'/plays').transaction(function(cur){ return (cur||0) + 1; });
};

window.closeGamePlayer = function(){
  document.getElementById('gamePlayerScreen').classList.remove('active');
  document.getElementById('gpFrame').srcdoc = '';
};

window.renderAdminGamesList = async function(){
  var el = document.getElementById('adminGamesList');
  if(!el || !currentProfile.isAdmin) return;
  el.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  try{
    var snap = await rtdb.ref('games').orderByChild('status').equalTo('pending').once('value');
    var badgeEl = document.getElementById('adminGamesBadge');
    if(!snap.exists()){
      el.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-gamepad"></i>مفيش ألعاب محتاجة مراجعة دلوقتي</div>';
      if(badgeEl) badgeEl.innerText = '';
      return;
    }
    var obj = snap.val();
    var games = Object.keys(obj).map(function(k){ return Object.assign({id:k}, obj[k]); });
    games.sort(function(a,b){ return (a.tsLocal||0)-(b.tsLocal||0); });
    if(badgeEl) badgeEl.innerText = games.length;
    el.innerHTML = games.map(function(g){
      var cover = g.coverImage ? '<img src="'+g.coverImage+'" alt="">' : '<div style="width:52px;height:52px;border-radius:10px;background:var(--card-bg2);display:flex;align-items:center;justify-content:center;color:var(--neon-purple)"><i class="fa-solid fa-gamepad"></i></div>';
      return '<div class="admin-games-card">'+cover+
        '<div class="agc-info"><h5>'+esc(g.title||'لعبة')+'</h5><p>بواسطة '+esc(g.authorName||'؟')+'</p></div>'+
        '<div class="agc-btns"><button class="small-btn filled" onclick="adminApproveGame(\''+g.id+'\')"><i class="fa-solid fa-check"></i></button>'+
        '<button class="small-btn danger" onclick="adminRejectGame(\''+g.id+'\')"><i class="fa-solid fa-xmark"></i></button></div>'+
      '</div>';
    }).join('');
  }catch(err){
    el.innerHTML = '<div class="empty-hint">تعذر تحميل الألعاب</div>';
  }
};
