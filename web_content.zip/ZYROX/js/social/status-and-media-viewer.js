/* ZYROX — social/status-and-media-viewer.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ الحالات (Status / Stories) ============ */
var STATUS_TTL_MS = 24*60*60*1000;
var STATUS_COLORS = ['#ff1f3d','#3d0c09','#ffb020','#39ffb0','#7a1cff','#0c8bff'];
var statusColorPicked = STATUS_COLORS[0];
var statusViewerState = null; // {ownerUid, ownerName, ownerPhoto, items, index, timerId, isMine}

window.openStatusComposeModal = function(){
  document.getElementById('statusTextInput').value = '';
  var sw = document.getElementById('statusColorSwatches');
  sw.innerHTML = STATUS_COLORS.map(function(c,i){
    return '<div class="theme-swatch'+(i===0?' active':'')+'" style="background:'+c+'" onclick="pickStatusColor(\''+c+'\',this)"></div>';
  }).join('');
  statusColorPicked = STATUS_COLORS[0];
  document.getElementById('statusComposeModal').classList.add('active');
};
window.pickStatusColor = function(c, el){
  statusColorPicked = c;
  document.querySelectorAll('#statusColorSwatches .theme-swatch').forEach(function(s){ s.classList.remove('active'); });
  el.classList.add('active');
};

async function pushStatusPayload(payload){
  var now = Date.now();
  var base = Object.assign({
    ownerName: currentProfile.displayName || currentProfile.username,
    ts: firebase.database.ServerValue.TIMESTAMP,
    tsLocal: now,
    expiresAt: now + STATUS_TTL_MS
  }, payload);
  await rtdb.ref('statuses/'+currentUser.uid).push(base);
}

window.postTextStatus = async function(){
  var text = document.getElementById('statusTextInput').value.trim();
  if(!text){ alert('اكتب نص الحالة الأول'); return; }
  await pushStatusPayload({ type:'text', text: text, color: statusColorPicked });
  window.closeModal('statusComposeModal');
  loadStatusesTab();
  alert('تم نشر الحالة');
};

window.postImageStatus = function(inputEl){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value='';
  if(file.size > 6*1024*1024){ alert('الصورة كبيرة، اختار صورة أصغر من 6 ميجا'); return; }
  compressImage(file, async function(dataUrl){
    await pushStatusPayload({ type:'image', mediaData: dataUrl });
    window.closeModal('statusComposeModal');
    loadStatusesTab();
    alert('تم نشر الحالة');
  });
};

window.postVideoStatus = function(inputEl){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value='';
  if(file.size > 60*1024*1024){ alert('الفيديو كبير، اختار فيديو أصغر من 60 ميجا عشان يترفع صح'); return; }
  checkVideoDuration(file, 200, function(ok, dur){
    if(!ok){ alert('الفيديو لازم يكون 200 ثانية أو أقل (طول الفيديو ده '+Math.round(dur)+' ثانية)'); return; }
    showUploadOverlay('جارٍ رفع الفيديو...', 'بيتحضر عشان ينشر في الحالة');
    readFileAsDataURL(file, async function(dataUrl){
      try{
        await pushStatusPayload({ type:'video', mediaData: dataUrl, duration: dur });
        window.closeModal('statusComposeModal');
        loadStatusesTab();
        alert('تم نشر الحالة');
      }catch(err){
        alert('تعذر نشر الحالة، حاول تاني');
      }finally{
        hideUploadOverlay();
      }
    });
  });
};

/* ============ كاش الحالات عشان قسم الحالات يفتح سريع، والضغط على أي حالة يفتحها فورًا من غير ما تستنى النت ============ */
var statusesListCache = {}; // fuid -> {items, u}
var myStatusItemsCache = null;

window.loadStatusesTab = async function(){
  var myRow = document.getElementById('myStatusRow');
  var listEl = document.getElementById('friendsStatusList');
  var now = Date.now();

  // عرض فوري من الكاش (لو موجود من فتحة سابقة) من غير ما نستنى السيرفر
  var hasCache = myStatusItemsCache!==null || Object.keys(statusesListCache).length>0;
  if(!hasCache){
    myRow.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
    listEl.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  }else{
    renderStatusesTabFromCache(now);
  }

  var mySnap = await rtdb.ref('statuses/'+currentUser.uid).once('value');
  var myItems = mySnap.exists() ? Object.keys(mySnap.val()).map(function(k){ return Object.assign({id:k}, mySnap.val()[k]); }).filter(function(s){ return s.expiresAt > now; }) : [];
  myStatusItemsCache = myItems;

  var friendUids = Object.keys(friendsMap||{});
  if(friendUids.length===0){
    statusesListCache = {};
    renderStatusesTabFromCache(now);
    return;
  }
  var statusRows = await Promise.all(friendUids.map(async function(fuid){
    var fSnap = await rtdb.ref('statuses/'+fuid).once('value');
    if(!fSnap.exists()) return null;
    var items = Object.keys(fSnap.val()).map(function(k){ return Object.assign({id:k}, fSnap.val()[k]); }).filter(function(s){ return s.expiresAt > now; });
    if(items.length===0) return null;
    var uSnap = await rtdb.ref('users/'+fuid).once('value');
    var u = uSnap.val();
    if(!u) return null;
    return {fuid:fuid, items:items, u:u};
  }));
  var freshCache = {};
  statusRows.forEach(function(row){ if(row) freshCache[row.fuid] = {items: row.items, u: row.u}; });
  statusesListCache = freshCache;
  renderStatusesTabFromCache(now);
};

function renderStatusesTabFromCache(now){
  var myRow = document.getElementById('myStatusRow');
  var listEl = document.getElementById('friendsStatusList');
  var myItems = (myStatusItemsCache||[]).filter(function(s){ return s.expiresAt > now; });
  var myAvatarHtml = currentProfile.photoURL ? '<div class="avatar" style="background-image:url(\''+currentProfile.photoURL+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar">'+esc(avatarLetter(currentProfile.displayName||currentProfile.username))+'</div>';
  myRow.innerHTML = '<div class="item-card" onclick="'+(myItems.length? "viewStatus('"+currentUser.uid+"')" : "openStatusComposeModal()")+'">'+
    '<div class="status-avatar-ring'+(myItems.length?'':' seen')+'">'+myAvatarHtml+'</div>'+
    '<div class="item-info"><h4>حالتي</h4><p>'+(myItems.length ? myItems.length+' حالة نشطة — اضغط للمشاهدة' : 'اضغط لإضافة حالة جديدة')+'</p></div>'+
    (myItems.length ? '<button class="small-btn" onclick="event.stopPropagation();openStatusComposeModal()"><i class="fa-solid fa-plus"></i></button>' : '')+
  '</div>';

  var friendUids = Object.keys(friendsMap||{});
  if(friendUids.length===0){
    listEl.innerHTML = '<div class="empty-hint"><i class="fa-solid fa-circle-notch"></i>ضيف أصدقاء عشان تشوف حالاتهم</div>';
    return;
  }
  var html = '';
  friendUids.forEach(function(fuid){
    var row = statusesListCache[fuid];
    if(!row) return;
    var items = row.items.filter(function(s){ return s.expiresAt > now; });
    if(items.length===0) return;
    var u = row.u;
    var allSeen = items.every(function(s){ return s.viewers && s.viewers[currentUser.uid]; });
    var avatarHtml = u.photoURL ? '<div class="avatar" style="background-image:url(\''+u.photoURL+'\');background-size:cover;background-position:center"></div>' : '<div class="avatar">'+esc(avatarLetter(u.displayName||u.username))+'</div>';
    html += '<div class="item-card" onclick="viewStatus(\''+fuid+'\')">'+
      '<div class="status-avatar-ring'+(allSeen?' seen':'')+'">'+avatarHtml+'</div>'+
      '<div class="item-info"><h4>'+nameWithBadge(u.displayName||u.username, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h4><p>'+items.length+' حالة</p></div>'+
    '</div>';
  });
  listEl.innerHTML = html || '<div class="empty-hint"><i class="fa-solid fa-circle-notch"></i>مفيش حالات من أصدقائك دلوقتي</div>';
}

window.viewStatus = async function(uid){
  var now = Date.now();
  var isMine = uid === currentUser.uid;
  var items, ownerName, ownerPhoto;

  // بنفتح فورًا من الكاش لو متاح (من غير أي استنى للسيرفر) — ده اللي بيخلي فتح الحالة سريع لحظة الضغط
  if(isMine && myStatusItemsCache){
    items = myStatusItemsCache.filter(function(s){ return s.expiresAt > now; });
    ownerName = currentProfile.displayName || currentProfile.username;
    ownerPhoto = currentProfile.photoURL;
  }else if(!isMine && statusesListCache[uid]){
    var cached = statusesListCache[uid];
    items = cached.items.filter(function(s){ return s.expiresAt > now; });
    ownerName = (cached.u.displayName || cached.u.username);
    ownerPhoto = cached.u.photoURL;
  }

  if(!items || items.length===0){
    // فولباك: مفيش كاش (مثلاً أول فتحة قبل ما تاب الحالات يتحمّل) — نجيب من السيرفر زي الأول
    var snap = await rtdb.ref('statuses/'+uid).once('value');
    if(!snap.exists()) return;
    items = Object.keys(snap.val()).map(function(k){ return Object.assign({id:k}, snap.val()[k]); }).filter(function(s){ return s.expiresAt > now; });
    if(items.length===0) return;
    if(isMine){
      ownerName = currentProfile.displayName || currentProfile.username;
      ownerPhoto = currentProfile.photoURL;
    }else{
      var uSnap = await rtdb.ref('users/'+uid).once('value');
      var u = uSnap.val() || {};
      ownerName = u.displayName || u.username;
      ownerPhoto = u.photoURL;
    }
  }
  items.sort(function(a,b){ return (a.tsLocal||0)-(b.tsLocal||0); });
  statusViewerState = { ownerUid: uid, ownerName: ownerName, ownerPhoto: ownerPhoto, items: items, index: 0, timerId: null, isMine: isMine };
  document.getElementById('svAvatar').innerHTML = ownerPhoto ? '' : esc(avatarLetter(ownerName));
  document.getElementById('svAvatar').style.cssText = ownerPhoto ? 'width:34px;height:34px;font-size:13px;background-image:url(\''+ownerPhoto+'\');background-size:cover;background-position:center' : 'width:34px;height:34px;font-size:13px';
  document.getElementById('svName').innerText = isMine ? 'حالتي' : ownerName;
  document.getElementById('svDeleteBtn').style.display = isMine ? 'flex' : 'none';
  document.getElementById('statusViewerScreen').classList.add('active');
  showStatusItem(0);
};

function showStatusItem(idx){
  var st = statusViewerState;
  if(!st) return;
  if(idx < 0){ closeStatusViewer(); return; }
  if(idx >= st.items.length){ closeStatusViewer(); return; }
  st.index = idx;
  var item = st.items[idx];
  if(st.timerId) clearTimeout(st.timerId);

  var progRow = document.getElementById('statusProgressRow');
  progRow.innerHTML = st.items.map(function(_,i){
    return '<div class="seg'+(i<idx?' done':'')+'"><div class="fill" id="seg_'+i+'" style="'+(i<idx?'width:100%':'')+'"></div></div>';
  }).join('');

  document.getElementById('svTime').innerText = fmtTime(item.ts||item.tsLocal);
  var body = document.getElementById('statusViewBody');
  var durationMs = 5000;
  if(item.type==='image'){
    body.innerHTML = '<img src="'+item.mediaData+'" alt="">';
  }else if(item.type==='video'){
    durationMs = Math.min(item.duration||20, 20) * 1000;
    body.innerHTML = '<video src="'+item.mediaData+'" autoplay playsinline webkit-playsinline="true" style="max-width:100%;max-height:100%;border-radius:10px"></video>';
    (function(){
      var svVid = body.querySelector('video');
      if(svVid){
        svVid.muted = false; // الصوت يشتغل تلقائي مع الحالة زي المطلوب
        var pp = svVid.play();
        if(pp && pp.catch) pp.catch(function(){ svVid.muted = true; svVid.play().catch(function(){}); });
      }
    })();
  }else{
    body.innerHTML = '<div class="status-text-slide" style="background:'+(item.color||STATUS_COLORS[0])+'">'+esc(item.text||'')+'</div>';
  }

  if(!st.isMine && !(item.viewers && item.viewers[currentUser.uid])){
    rtdb.ref('statuses/'+st.ownerUid+'/'+item.id+'/viewers/'+currentUser.uid).set(true);
  }
  document.getElementById('svViewersBar').style.display = 'none';
  if(st.isMine){
    var viewerCount = item.viewers ? Object.keys(item.viewers).length : 0;
    var likeCount = item.likes ? Object.keys(item.likes).length : 0;
    document.getElementById('svViewersBar').style.display = 'block';
    document.getElementById('svViewersBar').innerHTML = '<i class="fa-solid fa-eye"></i> '+viewerCount+' مشاهدة &nbsp;•&nbsp; <i class="fa-solid fa-heart" style="color:#ff2255"></i> '+likeCount+' لايك &nbsp;<span style="opacity:.6">(اضغط لعرض التفاصيل)</span>';
  }
  var liked = !!(item.likes && item.likes[currentUser.uid]);
  var likeBtn = document.getElementById('svLikeBtn');
  likeBtn.innerHTML = liked ? '<i class="fa-solid fa-heart" style="color:#ff2255"></i>' : '<i class="fa-regular fa-heart"></i>';
  likeBtn.style.display = st.isMine ? 'none' : 'flex';

  var seg = document.getElementById('seg_'+idx);
  if(seg){
    requestAnimationFrame(function(){
      seg.style.transition = 'width '+(durationMs/1000)+'s linear';
      seg.style.width = '100%';
    });
  }
  st.timerId = setTimeout(function(){ showStatusItem(idx+1); }, durationMs);
}

window.toggleStatusLike = async function(){
  var st = statusViewerState;
  if(!st || st.isMine) return;
  var item = st.items[st.index];
  var likeRef = rtdb.ref('statuses/'+st.ownerUid+'/'+item.id+'/likes/'+currentUser.uid);
  var liked = !!(item.likes && item.likes[currentUser.uid]);
  if(liked){
    await likeRef.remove();
    item.likes = item.likes || {}; delete item.likes[currentUser.uid];
  }else{
    await likeRef.set(true);
    item.likes = item.likes || {}; item.likes[currentUser.uid] = true;
  }
  var likeBtn = document.getElementById('svLikeBtn');
  likeBtn.innerHTML = !liked ? '<i class="fa-solid fa-heart" style="color:#ff2255"></i>' : '<i class="fa-regular fa-heart"></i>';
};

var statusViewersModalTab = 'viewers';
window.openStatusViewersModal = async function(){
  var st = statusViewerState;
  if(!st || !st.isMine) return;
  statusViewersModalTab = 'viewers';
  document.getElementById('statusViewersModal').classList.add('active');
  document.getElementById('svTabViewersChip').classList.add('active');
  document.getElementById('svTabLikesChip').classList.remove('active');
  await renderStatusViewersList();
};
window.showStatusViewersTab = async function(tab){
  statusViewersModalTab = tab;
  document.getElementById('svTabViewersChip').classList.toggle('active', tab==='viewers');
  document.getElementById('svTabLikesChip').classList.toggle('active', tab==='likes');
  await renderStatusViewersList();
};
async function renderStatusViewersList(){
  var st = statusViewerState;
  var el = document.getElementById('statusViewersListBody');
  if(!st){ el.innerHTML=''; return; }
  el.innerHTML = '<div class="loading-msg">جارٍ التحميل...</div>';
  var item = st.items[st.index];
  var uids = Object.keys((statusViewersModalTab==='likes' ? item.likes : item.viewers) || {});
  if(uids.length===0){ el.innerHTML = '<div class="empty-hint"><i class="fa-solid '+(statusViewersModalTab==='likes'?'fa-heart':'fa-eye')+'"></i>لسه محدش '+(statusViewersModalTab==='likes'?'عمل لايك':'شاف الحالة دي')+'</div>'; return; }
  var usersData = await Promise.all(uids.map(function(uid){
    return rtdb.ref('users/'+uid).once('value').then(function(s){ return {uid:uid, u:s.val()}; }).catch(function(){ return {uid:uid, u:null}; });
  }));
  el.innerHTML = usersData.filter(function(x){ return x.u; }).map(function(x){
    var u = x.u;
    var dn = u.displayName || u.username;
    return '<div class="user-result-item" onclick="closeAllModals();openUserProfile(\''+x.uid+'\')">'+
      avatarBlockHTML(dn, u.photoURL, 'width:38px;height:38px;font-size:14px;')+
      '<div class="uinfo"><h5>'+nameWithBadge(dn, u.isVerified, u.activeBadgeColor, u.verifiedEmoji)+'</h5></div>'+
    '</div>';
  }).join('') || '<div class="empty-hint">لسه محدش</div>';
}
function closeAllModals(){
  document.getElementById('statusViewersModal').classList.remove('active');
  document.querySelectorAll('.modal-overlay.active').forEach(function(m){ m.classList.remove('active'); });
}

/* ============ FULL SCREEN MEDIA VIEWER (صور/فيديوهات الشات — سحب فوق/تحت زي التيك توك) ============ */
var mvItems = [];
var mvIndex = 0;
function getChatMediaList(){
  return Object.keys(messagesCache).map(function(id){ return {id:id, m:messagesCache[id]}; })
    .filter(function(x){
      var m = x.m;
      if(m.type==='image') return !m.viewOnce || m.viewed===false ? !m.viewOnce : false;
      if(m.type==='video') return true;
      return false;
    });
}
window.openMediaViewer = function(msgId){
  var list = getChatMediaList().map(function(x){ return {id:x.id, type:x.m.type, mediaData:x.m.mediaData}; });
  var idx = list.findIndex(function(x){ return x.id===msgId; });
  openMediaViewerList(list, idx===-1?0:idx);
};
window.openMediaViewerList = function(list, startIndex){
  mvItems = list || [];
  mvIndex = startIndex || 0;
  if(!mvItems.length) return;
  document.getElementById('mediaViewerModal').classList.add('active');
  renderMvTrack();
};
/* ============ قسم "الميديا" في البروفايل: فيديوهات المستخدم ده وعدد اللايكات على كل واحد ============ */
async function loadUserVideosForProfile(uid){
  var gridEl = document.getElementById('upVideosGrid');
  if(!gridEl) return;
  try{
    var postsObj = await getVideosRaw();
    var vids = Object.keys(postsObj).map(function(k){ return Object.assign({id:k}, postsObj[k]); })
      .filter(function(p){ return p.mediaType==='video' && p.authorId===uid; });
    vids.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
    if(document.getElementById('userProfileScreen').classList.contains('active') === false) return; // المستخدم قفل البروفايل قبل ما التحميل يخلص
    gridEl.innerHTML = vids.length ? vids.map(renderUserVideoCellHTML).join('') : '<div class="empty-hint" style="grid-column:1/-1"><i class="fa-solid fa-film"></i>لسه مفيش فيديوهات منشورة</div>';
  }catch(err){
    gridEl.innerHTML = '<div class="empty-hint" style="grid-column:1/-1">تعذر تحميل الفيديوهات</div>';
  }
}
function renderUserVideoCellHTML(p){
  var likeCount = p.likes ? Object.keys(p.likes).length : 0;
  return '<div class="up-video-cell" onclick="openMediaViewerFromUserVideos(\''+p.authorId+'\',\''+p.id+'\')">'+
    '<video src="'+p.mediaData+'" muted playsinline preload="metadata"></video>'+
    '<div class="uv-play-ic"><i class="fa-solid fa-play"></i></div>'+
    '<div class="uv-likes"><i class="fa-solid fa-heart"></i> '+likeCount+'</div>'+
  '</div>';
}
window.openMediaViewerFromUserVideos = async function(uid, postId){
  try{
    var postsObj = await getVideosRaw();
    var vids = Object.keys(postsObj).map(function(k){ return Object.assign({id:k}, postsObj[k]); })
      .filter(function(p){ return p.mediaType==='video' && p.authorId===uid; });
    vids.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
    var list = vids.map(function(p){ return {id:p.id, type:p.mediaType, mediaData:p.mediaData}; });
    var idx = list.findIndex(function(x){ return x.id===postId; });
    openMediaViewerList(list, idx===-1?0:idx);
  }catch(e){}
};

/* ============ مشاركة رابط الفيديو ============ */
window.shareVideoLink = async function(postId){
  var link = location.origin + location.pathname + '?video=' + encodeURIComponent(postId);
  try{
    if(navigator.share){
      await navigator.share({title:'فيديو من ZYROX', url: link});
      return;
    }
  }catch(e){ /* المستخدم لغى شاشة المشاركة أو فشلت - نكمل ننسخ الرابط بدالها */ }
  try{
    await navigator.clipboard.writeText(link);
    showBlackToast('تم نسخ رابط الفيديو 🔗');
  }catch(e){
    prompt('انسخ رابط الفيديو:', link);
  }
};
/* لو حد فتح رابط فيديو متشارك، بنفتحله الفيديو ده فورًا أول ما يدخل التطبيق */
function extractVideoIdFromShareInput(raw){
  raw = (raw||'').trim();
  if(!raw) return null;
  try{
    if(raw.indexOf('video=')!==-1){
      var qIdx = raw.indexOf('?');
      var qs = qIdx!==-1 ? raw.slice(qIdx+1) : raw;
      var params = new URLSearchParams(qs);
      var v = params.get('video');
      if(v) return v;
    }
  }catch(e){}
  var trimmed = raw.split('?')[0].split('#')[0];
  var lastSlash = trimmed.lastIndexOf('/');
  var lastPart = lastSlash!==-1 ? trimmed.slice(lastSlash+1) : trimmed;
  return lastPart || null;
}
function handleSharedVideoDeepLink(){
  try{
    var params = new URLSearchParams(location.search);
    var vid = params.get('video');
    if(!vid) return;
    history.replaceState(null, '', location.pathname);
    setTimeout(async function(){
      try{
        var snap = await rtdb.ref('posts/'+vid).once('value');
        var p = snap.val();
        if(!p || p.mediaType!=='video'){ showBlackToast('الفيديو ده مش موجود أو اتمسح'); return; }
        openMediaViewerList([{id:vid, type:'video', mediaData:p.mediaData}], 0);
      }catch(e){}
    }, 500);
  }catch(e){}
}

window.openMediaViewerFromPost = function(postId){
  if(!postsRawCache) return;
  var clicked = postsRawCache[postId];
  if(!clicked) return;
  var posts = Object.keys(postsRawCache).map(function(k){ return Object.assign({id:k}, postsRawCache[k]); })
    .filter(function(p){ return p.mediaType===clicked.mediaType; }); // نفس نوع الوسيط بس (صور مع صور، وفيديوهات مع فيديوهات زي التيك توك)
  posts.sort(function(a,b){ return (b.tsLocal||0)-(a.tsLocal||0); });
  var list = posts.map(function(p){ return {id:p.id, type:p.mediaType, mediaData:p.mediaData}; });
  var idx = list.findIndex(function(x){ return x.id===postId; });
  openMediaViewerList(list, idx===-1?0:idx);
};
function renderMvTrack(){
  var track = document.getElementById('mvTrack');
  track.innerHTML = mvItems.map(function(x, i){
    if(x.type==='image'){
      return '<div class="mv-slide" style="transform:translateY('+(i*100)+'%)"><img src="'+x.mediaData+'" alt=""></div>';
    }else{
      return '<div class="mv-slide" style="transform:translateY('+(i*100)+'%)"><video src="'+x.mediaData+'" playsinline webkit-playsinline="true" loop data-idx="'+i+'"></video></div>';
    }
  }).join('');
  positionMvTrack(false);
  playCurrentMvVideoIfAny();
}
function positionMvTrack(animate){
  var track = document.getElementById('mvTrack');
  track.style.transition = animate ? 'transform .28s ease' : 'none';
  track.style.transform = 'translateY(-'+(mvIndex*100)+'%)';
  var current = mvItems[mvIndex];
  document.getElementById('mvDownloadBtn').href = current.mediaData;
}
function playCurrentMvVideoIfAny(){
  document.querySelectorAll('#mvTrack video').forEach(function(v){ v.pause(); v.muted = false; });
  var current = mvItems[mvIndex];
  if(current && current.type==='video'){
    var vid = document.querySelector('#mvTrack video[data-idx="'+mvIndex+'"]');
    if(vid){ vid.muted = false; vid.play().catch(function(){ /* المتصفح ممكن يمنع الصوت التلقائي لو مفيش تفاعل، بس فتح الفيوير نفسه لمسة يد فتكفي غالبًا */ }); }
  }
}
function mvGoTo(newIndex){
  if(newIndex < 0 || newIndex >= mvItems.length) return;
  mvIndex = newIndex;
  positionMvTrack(true);
  playCurrentMvVideoIfAny();
}
window.closeMediaViewer = function(){
  document.querySelectorAll('#mvTrack video').forEach(function(v){ v.pause(); });
  document.getElementById('mediaViewerModal').classList.remove('active');
  document.getElementById('mvTrack').innerHTML = '';
};

window.statusViewerTap = function(ev){
  if(!statusViewerState) return;
  var w = window.innerWidth;
  if(ev.clientX > w/2){ showStatusItem(statusViewerState.index-1); }
  else{ showStatusItem(statusViewerState.index+1); }
};

window.closeStatusViewer = function(){
  if(statusViewerState && statusViewerState.timerId) clearTimeout(statusViewerState.timerId);
  statusViewerState = null;
  document.getElementById('statusViewerScreen').classList.remove('active');
  loadStatusesTab();
};

window.deleteViewingStatus = async function(){
  var st = statusViewerState;
  if(!st || !st.isMine) return;
  if(!confirm('تمسح الحالة دي؟')) return;
  var item = st.items[st.index];
  await rtdb.ref('statuses/'+st.ownerUid+'/'+item.id).remove();
  st.items.splice(st.index,1);
  if(st.items.length===0){ closeStatusViewer(); return; }
  showStatusItem(Math.min(st.index, st.items.length-1));
};
