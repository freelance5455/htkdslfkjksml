/* ZYROX — groups/groups.js
   جزء من التطبيق الأصلي. كل الملفات بتتحمل بالترتيب من index.html وبتشارك نفس النطاق العام (global scope). */

/* ============ CREATE GROUP ============ */
window.openCreateGroupModal = function(){
  document.getElementById('sideMenu').classList.remove('active');
  groupSelectedMembers = {};
  document.getElementById('groupName').value='';
  document.getElementById('groupMemberSearch').value='';
  document.getElementById('groupMembersResults').innerHTML='';
  renderChips('groupSelectedChips', groupSelectedMembers, 'group');
  document.getElementById('groupModal').classList.add('active');
};
window.closeModal = function(id){ document.getElementById(id).classList.remove('active'); };

window.searchForGroupModal = async function(q, resultsElId, mode){
  q = q.trim().toLowerCase();
  var box = document.getElementById(resultsElId);
  if(!q){ box.innerHTML=''; return; }
  var snap = await rtdb.ref('usernames').orderByKey().startAt(q).endAt(q+'\uf8ff').limitToFirst(10).once('value');
  box.innerHTML='';
  var selectedMap = mode==='group' ? groupSelectedMembers : addMemberSelected;
  var existingMembers = (mode==='add' && currentChatData) ? currentChatData.members : {};
  snap.forEach(function(c){
    var uid = c.val();
    if(uid===currentUser.uid) return;
    if(existingMembers[uid]) return;
    rtdb.ref('users/'+uid).once('value').then(function(uSnap){
      var u = uSnap.val(); if(!u) return;
      var dn = u.displayName || u.username;
      var row = document.createElement('div');
      row.className='member-row';
      var checked = selectedMap[uid] ? 'checked' : '';
      row.innerHTML = '<input type="checkbox" '+checked+'> <div class="avatar" style="width:32px;height:32px;font-size:12px">'+esc(avatarLetter(dn))+'</div><span>'+esc(dn)+'</span>';
      row.onclick = function(ev){
        if(ev.target.tagName!=='INPUT'){ row.querySelector('input').checked = !row.querySelector('input').checked; }
        if(row.querySelector('input').checked){ selectedMap[uid]=dn; } else { delete selectedMap[uid]; }
        renderChips(mode==='group'?'groupSelectedChips':'addMemberChips', selectedMap, mode);
      };
      box.appendChild(row);
    });
  });
};

function renderChips(elId, map, mode){
  var el = document.getElementById(elId);
  el.innerHTML = Object.keys(map).map(function(uid){
    return '<span class="selected-chip">'+esc(map[uid])+' <i class="fa-solid fa-xmark" onclick="removeChip(\''+uid+'\',\''+mode+'\')"></i></span>';
  }).join('');
}
window.removeChip = function(uid, mode){
  var map = mode==='group' ? groupSelectedMembers : addMemberSelected;
  delete map[uid];
  renderChips(mode==='group'?'groupSelectedChips':'addMemberChips', map, mode);
  window.searchForGroupModal(document.getElementById(mode==='group'?'groupMemberSearch':'addMemberSearch').value, mode==='group'?'groupMembersResults':'addMemberResults', mode);
};

/* ============ جروب ZYROX الرسمي المثبّت — إجباري لكل المستخدمين، والأدمن الوحيد فيه هو مطور المنصة ============ */
var MANDATORY_GROUP_ID = 'group_exe_official';
var MANDATORY_GROUP_OWNER_USERNAME = 'شيفو';
async function ensureOfficialGroupMembership(){
  try{
    var gRef = rtdb.ref('chats/'+MANDATORY_GROUP_ID);
    var gSnap = await gRef.once('value');
    if(!gSnap.exists()){
      // أول مرة الجروب ده بيتعمل — نجيب يوزر آيدي المطور عشان يبقى الأدمن الوحيد
      var ownerLower = MANDATORY_GROUP_OWNER_USERNAME.toLowerCase();
      var ownerIdSnap = await rtdb.ref('usernames/'+ownerLower).once('value');
      var ownerUid = ownerIdSnap.val() || currentUser.uid;
      var members = {}; members[ownerUid] = true;
      var memberNames = {}; memberNames[ownerUid] = 'مطور المنصة';
      var admins = {}; admins[ownerUid] = true;
      await gRef.set({
        type:'group', name:'ZYROX', members: members, memberNames: memberNames,
        owner: ownerUid, admins: admins, isVerified: true, isOfficial: true,
        createdBy: ownerUid, createdAt: firebase.database.ServerValue.TIMESTAMP
      });
      await rtdb.ref('userChats/'+ownerUid+'/'+MANDATORY_GROUP_ID).set(true);
    }
    // نضيف المستخدم الحالي لو مش عضو أصلاً
    var alreadyMember = await rtdb.ref('chats/'+MANDATORY_GROUP_ID+'/members/'+currentUser.uid).once('value');
    if(!alreadyMember.exists()){
      var dn = currentProfile.displayName || currentProfile.username;
      var updates = {};
      updates['chats/'+MANDATORY_GROUP_ID+'/members/'+currentUser.uid] = true;
      updates['chats/'+MANDATORY_GROUP_ID+'/memberNames/'+currentUser.uid] = dn;
      updates['userChats/'+currentUser.uid+'/'+MANDATORY_GROUP_ID] = true;
      await rtdb.ref().update(updates);
    }
  }catch(e){ /* أوفلاين أو مشكلة اتصال — هتتظبط لوحدها أول ما النت يرجع ويفتح التطبيق تاني */ }
}

window.createGroup = async function(){
  var name = document.getElementById('groupName').value.trim();
  if(!name) return alert('اكتب اسم الجروب');
  var memberUids = Object.keys(groupSelectedMembers);

  var members = {}; members[currentUser.uid] = true;
  var memberNames = {}; memberNames[currentUser.uid] = currentProfile.displayName || currentProfile.username;
  var admins = {}; admins[currentUser.uid] = true;
  memberUids.forEach(function(uid){ members[uid]=true; memberNames[uid]=groupSelectedMembers[uid]; });

  var chatRef = rtdb.ref('chats').push();
  var inviteCode = generateInviteCode();
  await chatRef.set({
    type:'group', name: name, members: members, memberNames: memberNames,
    owner: currentUser.uid, admins: admins, inviteCode: inviteCode,
    createdBy: currentUser.uid, createdAt: firebase.database.ServerValue.TIMESTAMP
  });
  await rtdb.ref('groupInvites/'+inviteCode).set(chatRef.key);
  var allUids = Object.keys(members);
  await Promise.all(allUids.map(function(uid){ return rtdb.ref('userChats/'+uid+'/'+chatRef.key).set(true); }));
  window.closeModal('groupModal');
  window.openChat(chatRef.key);
};

function generateInviteCode(){
  var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  var code = '';
  for(var i=0;i<7;i++) code += chars.charAt(Math.floor(Math.random()*chars.length));
  return code;
}

window.copyInviteCode = function(){
  var code = document.getElementById('gsInviteCode').innerText;
  if(!code || code==='—') return;
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(code).then(function(){ alert('تم نسخ الكود'); });
  }else{
    alert('الكود: '+code);
  }
};

window.joinGroupByCodePrompt = async function(){
  var code = prompt('اكتب كود دعوة الجروب:');
  if(!code) return;
  code = code.trim().toUpperCase();
  try{
    var gidSnap = await rtdb.ref('groupInvites/'+code).once('value');
    if(!gidSnap.exists()){ alert('الكود ده مش صحيح'); return; }
    var chatId = gidSnap.val();
    var cSnap = await rtdb.ref('chats/'+chatId).once('value');
    var cData = cSnap.val();
    if(!cData){ alert('الجروب ده مش موجود'); return; }
    if(cData.members && cData.members[currentUser.uid]){ alert('انت أصلاً عضو في الجروب ده'); window.openChat(chatId); return; }
    if(cData.bannedUsers && cData.bannedUsers[currentUser.uid]){ alert('انت محظور من الجروب ده، مينفعش تنضم تاني'); return; }
    var protActive = !!(cData.protectionBot && cData.protectionBot.enabled);
    var updates = {};
    updates['chats/'+chatId+'/members/'+currentUser.uid] = true;
    updates['chats/'+chatId+'/memberNames/'+currentUser.uid] = currentProfile.displayName || currentProfile.username;
    updates['userChats/'+currentUser.uid+'/'+chatId] = protActive ? {pinned:true} : true;
    await rtdb.ref().update(updates);
    window.openChat(chatId);
  }catch(err){
    alert('حصل خطأ وانت بتنضم للجروب، حاول تاني');
  }
};

/* ============ ADD MEMBERS TO EXISTING GROUP ============ */
window.openAddMemberModal = function(){
  addMemberSelected = {};
  document.getElementById('addMemberSearch').value='';
  document.getElementById('addMemberResults').innerHTML='';
  renderChips('addMemberChips', addMemberSelected, 'add');
  document.getElementById('addMemberModal').classList.add('active');
};

window.confirmAddMembers = async function(){
  var uids = Object.keys(addMemberSelected);
  if(uids.length===0) return alert('اختار عضو واحد على الأقل');
  var protActive = !!(currentChatData && currentChatData.protectionBot && currentChatData.protectionBot.enabled);
  var updates = {};
  uids.forEach(function(uid){
    updates['chats/'+currentChatId+'/members/'+uid] = true;
    updates['chats/'+currentChatId+'/memberNames/'+uid] = addMemberSelected[uid];
    updates['userChats/'+uid+'/'+currentChatId] = protActive ? {pinned:true} : true;
  });
  await rtdb.ref().update(updates);
  window.closeModal('addMemberModal');
  if(document.getElementById('groupSettingsScreen').classList.contains('active')) openGroupSettings();
  else window.openChat(currentChatId);
};

/* ============ GROUP SETTINGS (owner/admin management) ============ */
window.openGroupSettingsIfGroup = function(){
  if(!currentChatData) return;
  if(currentChatData.type==='group') openGroupSettings();
  else if(currentChatData.type==='direct'){
    var otherUid = Object.keys(currentChatData.members).find(function(k){ return k!==currentUser.uid; });
    window.openUserProfile(otherUid);
  }
};

async function openGroupSettings(){
  var snap = await rtdb.ref('chats/'+currentChatId).once('value');
  currentChatData = snap.val();
  var isOwner = currentChatData.owner === currentUser.uid;
  var isAdmin = !!(currentChatData.admins && currentChatData.admins[currentUser.uid]);
  var isMod = !!(currentChatData.moderators && currentChatData.moderators[currentUser.uid]);
  var canModerate = isOwner || isAdmin || isMod; // كيك/حظر
  var canManage = isOwner || isAdmin; // ترقية/تسمية

  document.getElementById('gsGroupName').value = currentChatData.name;
  document.getElementById('gsGroupName').disabled = !isAdmin;

  var gAvatarPrev = document.getElementById('gsGroupAvatarPreview');
  if(currentChatData.photoURL){
    gAvatarPrev.innerHTML=''; gAvatarPrev.style.cssText='width:74px;height:74px;font-size:26px;background-image:url(\''+currentChatData.photoURL+'\');background-size:cover;background-position:center';
  }else{
    gAvatarPrev.style.cssText='width:74px;height:74px;font-size:26px';
    gAvatarPrev.innerHTML = '<i class="fa-solid fa-users"></i>';
  }
  document.getElementById('gsGroupAvatarCamBtn').style.display = isAdmin ? 'flex' : 'none';

  document.getElementById('gsAdminsOnlyToggle').checked = !!currentChatData.adminsOnly;
  document.getElementById('gsAdminsOnlyToggle').disabled = !isAdmin;
  if(!currentChatData.inviteCode && (isOwner || isAdmin)){
    var newCode = generateInviteCode();
    await rtdb.ref('chats/'+currentChatId+'/inviteCode').set(newCode);
    await rtdb.ref('groupInvites/'+newCode).set(currentChatId);
    currentChatData.inviteCode = newCode;
  }
  document.getElementById('gsInviteCode').innerText = currentChatData.inviteCode || '—';
  document.getElementById('gsRenameBtn').style.display = isAdmin ? 'block' : 'none';
  document.getElementById('gsDeleteBtn').style.display = isOwner ? 'block' : 'none';

  /* ===== قسم بوت الحماية (المالك بس اللي يتحكم فيه) ===== */
  var protection = currentChatData.protectionBot || null;
  var protToggle = document.getElementById('gsProtectionToggle');
  protToggle.checked = !!(protection && protection.enabled);
  protToggle.disabled = !isOwner;
  document.getElementById('gsProtectionHint').style.display = isOwner ? 'block' : 'none';
  var pbCardEl = document.getElementById('gsProtectionBotCard');
  if(protection && protection.enabled){
    pbCardEl.innerHTML = '<div class="protection-bot-card">'+
      '<div class="pb-icon"><i class="fa-solid fa-shield-halved"></i></div>'+
      '<div class="pb-info"><h5>🛡️ حارس الجروب</h5><p>بوت رسمي وحيد بالجروب — الأدمن: @'+esc(protection.ownerUsername||'')+'</p></div>'+
    '</div>';
  }else{
    pbCardEl.innerHTML = '';
  }

  var memberUids = Object.keys(currentChatData.members);
  document.getElementById('gsMembersCount').innerText = 'الأعضاء (' + memberUids.length + ')';

  var html = '';
  memberUids.forEach(function(uid){
    var name = currentChatData.memberNames[uid] || 'مستخدم';
    var isTargetOwner = currentChatData.owner === uid;
    var isTargetAdmin = !!(currentChatData.admins && currentChatData.admins[uid]);
    var isTargetMod = !!(currentChatData.moderators && currentChatData.moderators[uid]);
    var roleHtml = '';
    if(isTargetOwner) roleHtml = '<span class="role-tag role-owner">👑 المالك</span>';
    else if(isTargetAdmin) roleHtml = '<span class="role-tag role-admin">⭐ أدمن</span>';
    else if(isTargetMod) roleHtml = '<span class="role-tag role-mod">🛡️ مشرف</span>';

    var actions = '';
    if(uid !== currentUser.uid && !isTargetOwner){
      if(canManage){
        if(isTargetAdmin){
          actions += '<button class="small-btn" onclick="toggleAdmin(\''+uid+'\',false)">إلغاء الأدمن</button>';
        }else{
          actions += '<button class="small-btn" onclick="toggleAdmin(\''+uid+'\',true)">ترقية لأدمن</button>';
          if(isTargetMod){
            actions += '<button class="small-btn" onclick="toggleModerator(\''+uid+'\',false)">إلغاء الإشراف</button>';
          }else{
            actions += '<button class="small-btn" onclick="toggleModerator(\''+uid+'\',true)">ترقية لمشرف</button>';
          }
        }
      }
      if(canModerate && !isTargetAdmin){
        actions += '<button class="small-btn danger" onclick="removeMember(\''+uid+'\')">إزالة</button>';
        actions += '<button class="small-btn danger" onclick="banMember(\''+uid+'\')">حظر</button>';
      }
    }
    html += '<div class="member-list-row"><div class="avatar" style="width:36px;height:36px;font-size:13px">'+esc(avatarLetter(name))+'</div>'+
      '<div class="minfo"><h5>'+esc(name)+' '+roleHtml+'</h5></div>'+
      '<div class="member-actions">'+actions+'</div></div>';
  });
  document.getElementById('gsMembersList').innerHTML = html;
  document.getElementById('groupSettingsScreen').classList.add('active');
}

window.toggleProtectionBot = async function(enable){
  var snap = await rtdb.ref('chats/'+currentChatId).once('value');
  var data = snap.val();
  if(!data || data.owner !== currentUser.uid){
    alert('المالك بس اللي يقدر يفعّل أو يلغي بوت الحماية');
    openGroupSettings();
    return;
  }
  var memberUids = Object.keys(data.members || {});
  var updates = {};
  if(enable){
    updates['chats/'+currentChatId+'/protectionBot'] = {
      enabled: true,
      ownerUsername: currentProfile.username,
      activatedAt: firebase.database.ServerValue.TIMESTAMP
    };
    memberUids.forEach(function(uid){ updates['userChats/'+uid+'/'+currentChatId+'/pinned'] = true; });
  }else{
    updates['chats/'+currentChatId+'/protectionBot'] = null;
    memberUids.forEach(function(uid){ updates['userChats/'+uid+'/'+currentChatId+'/pinned'] = false; });
  }
  await rtdb.ref().update(updates);
  openGroupSettings();
};

window.toggleAdmin = async function(uid, makeAdmin){
  if(makeAdmin){
    await rtdb.ref('chats/'+currentChatId+'/admins/'+uid).set(true);
    await rtdb.ref('chats/'+currentChatId+'/moderators/'+uid).remove();
  }else{
    await rtdb.ref('chats/'+currentChatId+'/admins/'+uid).remove();
  }
  openGroupSettings();
};

window.toggleModerator = async function(uid, makeMod){
  if(makeMod) await rtdb.ref('chats/'+currentChatId+'/moderators/'+uid).set(true);
  else await rtdb.ref('chats/'+currentChatId+'/moderators/'+uid).remove();
  openGroupSettings();
};

window.removeMember = async function(uid){
  if(!confirm('تشيل العضو ده من الجروب؟')) return;
  var updates = {};
  updates['chats/'+currentChatId+'/members/'+uid] = null;
  updates['chats/'+currentChatId+'/memberNames/'+uid] = null;
  updates['chats/'+currentChatId+'/admins/'+uid] = null;
  updates['chats/'+currentChatId+'/moderators/'+uid] = null;
  updates['userChats/'+uid+'/'+currentChatId] = null;
  await rtdb.ref().update(updates);
  openGroupSettings();
};

window.banMember = async function(uid){
  if(!confirm('تحظر العضو ده نهائيًا من الجروب؟ مش هيقدر يرجع بكود الدعوة تاني.')) return;
  var updates = {};
  updates['chats/'+currentChatId+'/members/'+uid] = null;
  updates['chats/'+currentChatId+'/memberNames/'+uid] = null;
  updates['chats/'+currentChatId+'/admins/'+uid] = null;
  updates['chats/'+currentChatId+'/moderators/'+uid] = null;
  updates['chats/'+currentChatId+'/bannedUsers/'+uid] = { by: currentUser.uid, ts: firebase.database.ServerValue.TIMESTAMP };
  updates['userChats/'+uid+'/'+currentChatId] = null;
  await rtdb.ref().update(updates);
  openGroupSettings();
};

window.handleGroupAvatarSelect = function(inputEl){
  var file = inputEl.files[0];
  if(!file) return;
  inputEl.value = '';
  var isAdminNow = currentChatData && ((currentChatData.owner === currentUser.uid) || (currentChatData.admins && currentChatData.admins[currentUser.uid]));
  if(!isAdminNow){ alert('الأدمن بس هو اللي يقدر يغيّر صورة الجروب'); return; }
  if(file.size > 6*1024*1024){ alert('الصورة كبيرة، اختار صورة أصغر من 6 ميجا'); return; }
  compressImage(file, async function(dataUrl){
    try{
      await rtdb.ref('chats/'+currentChatId+'/photoURL').set(dataUrl);
      currentChatData.photoURL = dataUrl;
      openGroupSettings();
      if(currentChatId) window.openChat(currentChatId);
      alert('تم تغيير صورة الجروب');
    }catch(err){
      alert('تعذر رفع الصورة، حاول تاني');
    }
  });
};

window.toggleAdminsOnlyMessaging = async function(enable){
  var isAdminNow = currentChatData && ((currentChatData.owner === currentUser.uid) || (currentChatData.admins && currentChatData.admins[currentUser.uid]));
  if(!isAdminNow){
    alert('الأدمن بس هو اللي يقدر يغيّر إعداد المراسلة ده');
    openGroupSettings();
    return;
  }
  await rtdb.ref('chats/'+currentChatId+'/adminsOnly').set(!!enable);
  currentChatData.adminsOnly = !!enable;
  openGroupSettings();
};

window.renameGroup = async function(){
  var name = document.getElementById('gsGroupName').value.trim();
  if(!name) return alert('اكتب اسم صحيح');
  await rtdb.ref('chats/'+currentChatId+'/name').set(name);
  document.getElementById('chatTitle').innerText = name;
  alert('تم تغيير اسم الجروب');
};

window.leaveGroup = async function(){
  if(currentChatId === MANDATORY_GROUP_ID){ alert('جروب ZYROX الرسمي مثبّت ومينفعش تسيبه'); return; }
  if(!confirm('متأكد إنك عايز تسيب الجروب؟')) return;
  var snap = await rtdb.ref('chats/'+currentChatId).once('value');
  var data = snap.val();
  var updates = {};
  updates['chats/'+currentChatId+'/members/'+currentUser.uid] = null;
  updates['chats/'+currentChatId+'/memberNames/'+currentUser.uid] = null;
  updates['chats/'+currentChatId+'/admins/'+currentUser.uid] = null;
  updates['userChats/'+currentUser.uid+'/'+currentChatId] = null;

  if(data.owner === currentUser.uid){
    var remaining = Object.keys(data.members).filter(function(u){ return u!==currentUser.uid; });
    if(remaining.length > 0){
      var admins = data.admins || {};
      var nextOwner = remaining.find(function(u){ return admins[u]; }) || remaining[0];
      updates['chats/'+currentChatId+'/owner'] = nextOwner;
      updates['chats/'+currentChatId+'/admins/'+nextOwner] = true;
    }
  }
  await rtdb.ref().update(updates);
  document.getElementById('groupSettingsScreen').classList.remove('active');
  window.closeChat();
};

window.deleteGroup = async function(){
  if(!confirm('حذف الجروب نهائيًا؟ الخطوة دي مينفعش تتراجع فيها')) return;
  var snap = await rtdb.ref('chats/'+currentChatId).once('value');
  var data = snap.val();
  var updates = {};
  Object.keys(data.members).forEach(function(uid){ updates['userChats/'+uid+'/'+currentChatId] = null; });
  updates['chats/'+currentChatId] = null;
  updates['messages/'+currentChatId] = null;
  if(data.inviteCode) updates['groupInvites/'+data.inviteCode] = null;
  await rtdb.ref().update(updates);
  document.getElementById('groupSettingsScreen').classList.remove('active');
  window.closeChat();
};
