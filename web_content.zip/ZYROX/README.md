# ZYROX

منصة تواصل اجتماعي (شاتات، جروبات، حالات، منشورات، فيديوهات، ألعاب، ذكاء اصطناعي) — Firebase + HTML/CSS/JS عادي (من غير build).

## تشغيل المشروع
افتح `index.html` من أي استضافة ثابتة (Firebase Hosting / Netlify / GitHub Pages...).
لو هتستخدم Firebase Hosting: `firebase deploy --only hosting` (ملف `firebase.json` جاهز).
> تسجيل الدخول بجوجل/فيسبوك مش بيشتغل من `file://` — لازم يتفتح من دومين (أو `localhost`).

## تسجيل الدخول والأدمن
- الدخول بـ **جوجل** أو **فيسبوك** (`js/auth/social-auth.js`).
- **الأدمن** = صاحب الإيميل `s01026840335@gmail.com` — بشرط يدخل بـ **جوجل** والإيميل متحقق منه. فيسبوك عمره ما بيدّي صلاحية أدمن.
- تغيير الأدمن: غيّر `ADMIN_EMAIL` في `js/core/admin-config.js` (وفي القواعد تحت).
- أول دخول للأدمن بيعمل له بروفايل `isAdmin` + `isRootAdmin` + موثّق، وبيتحصّن (محدش يشيل صلاحيته أو يحظره أو يحذفه).
- اتشال: كود الأدمن السري (ADMIN_ACCESS_CODE)، فورم دخول الأدمن بالباسورد، وإنشاء حسابات باليوزر/باسورد.
- الحسابات القديمة (يوزر + باسورد) لسه تقدر تدخل من "عندي حساب قديم" تحت أزرار الدخول. لو مش عايزه امسح `<details class="legacy-login">` من `index.html`.

## إعداد Firebase (لازم تعمله مرة واحدة)
1. **Authentication → Sign-in method**: فعّل **Google**، وفعّل **Facebook**.
2. **فيسبوك**: اعمل تطبيق على developers.facebook.com، وحط **App ID** و **App Secret** في Firebase، وانسخ رابط الـ redirect من Firebase (شكله `https://sheref-4f53f.firebaseapp.com/__/auth/handler`) في Facebook Login → Valid OAuth Redirect URIs. لازم التطبيق يبقى Live.
3. **Authentication → Settings → Authorized domains**: ضيف دومين موقعك.
4. **Realtime Database → Rules** (مهم جدًا للأمان): الفحص في المتصفح لوحده ممكن يتخطاه أي حد. ادمج ده في قواعدك الحالية تحت `users/$uid` واختبره في Rules Playground:
```json
"isAdmin": {
  ".validate": "newData.val() === false || newData.val() === data.val() || (auth.token.email_verified === true && auth.token.email === 's01026840335@gmail.com') || root.child('users').child(auth.uid).child('isAdmin').val() === true"
},
"isRootAdmin": {
  ".validate": "newData.val() === false || newData.val() === data.val() || (auth.token.email_verified === true && auth.token.email === 's01026840335@gmail.com')"
}
```

## ملاحظات
- مبدّل الحسابات المتعددة بيشتغل مع الحسابات القديمة بس (الحسابات الاجتماعية مالهاش باسورد يتحفظ).
- اسم المستخدم لحسابات جوجل/فيسبوك بيتولّد تلقائي (مش من الإيميل، عشان الإيميل ميتكشفش). الأدمن بياخد `admin` لو متاح.
- كود الدخول بالتليفون القديم موجود في `js/auth/phone-auth-legacy.js` (مش مستخدم في الواجهة).

## هيكل الملفات
```
index.html              الصفحة + كل الشاشات
css/                    01 → 09 بالترتيب (الترتيب مهم)
js/core/                الإعدادات، الحالة العامة، الدوال المساعدة، فايربيز
js/auth/                الدخول (social-auth = جوجل/فيسبوك)، الحسابات، حالة الدخول
js/chat/                الشاتات، الرسائل، المرفقات، الإشعارات، القفل
js/groups/              الجروبات
js/social/              القوائم والأصدقاء، الحالات، المنشورات، الفيديوهات، الألعاب
js/support/             الدعم
js/settings/            الإعدادات
js/moderation/          التحذيرات، البلاغات، مراجعة الحظر
js/admin/               لوحة الأدمن
js/boot.js              أوامر التشغيل الأولى (بيتحمل آخر ملف)
```
كل ملفات `js/` سكربتات عادية بتشارك نفس النطاق العام، وبتتحمل من `index.html` **بنفس الترتيب المكتوب هناك** — لو ضفت ملف جديد حطه قبل `boot.js`.
