/**
 * سحابة تطبيق "دولار لايف | Dollar Live" - Cloudflare Worker (مجاني حتى 100,000 طلب يومياً)
 * يدمج أسعار العملات العالمية وأونصة الذهب مع أسعار الصاغة المصرية في استجابة JSON واحدة سريعة ومخزنة في الكاش.
 *
 * طريقة الاستخدام:
 * 1. ادخل على https://dash.cloudflare.com وأنشئ Worker مجاني جديد.
 * 2. الصق هذا الكود واضغط Deploy.
 * 3. انسخ رابط الـ Worker وضعه في إعدادات (⚙️ المصدر) داخل تطبيق دولار لايف أو اجعله الرابط الافتراضي.
 */

export default {
  async fetch(request, env, ctx) {
    const corsHeaders = {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'public, max-age=180' // كاش لمدة 3 دقائق لحماية الحصة المجانية وتسريع الاستجابة
    };

    if (request.method === 'OPTIONS') {
      return new Response(null, { headers: corsHeaders });
    }

    try {
      // 1) جلب أسعار العملات مقابل الدولار (مصدر بلا حدود طلبات)
      const [usdRes, xauRes] = await Promise.all([
        fetch('https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json', {
          cf: { cacheTtl: 300, cacheEverything: true }
        }),
        fetch('https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/xau.json', {
          cf: { cacheTtl: 300, cacheEverything: true }
        })
      ]);

      const usdData = usdRes.ok ? await usdRes.json() : null;
      const xauData = xauRes.ok ? await xauRes.json() : null;

      const rates = { USD: 1, EGP: 53.5507 };
      if (usdData && usdData.usd) {
        for (const [k, v] of Object.entries(usdData.usd)) {
          if (typeof v === 'number') rates[k.toUpperCase()] = v;
        }
      }

      const goldOzUsd = (xauData && xauData.xau && typeof xauData.xau.usd === 'number')
        ? xauData.xau.usd
        : 3884.00;

      // 2) تسعير الصاغة المصرية (يمكنك تعديل معامل دولار الصاغة هنا في أي وقت ليتحدث عند كل المستخدمين فوراً)
      const saghaUsdEgp = rates.EGP ? Number((rates.EGP - 0.13).toFixed(2)) : 53.42;
      const rawGram24 = (goldOzUsd / 31.1034768) * saghaUsdEgp;
      const karat21Sell = Math.round(rawGram24 * (21 / 24));
      const karat21Buy = Math.round(karat21Sell * 0.9966);

      const payload = {
        app: 'Dollar Live - com.mohamed.dollarlive',
        updatedAt: new Date().toISOString(),
        goldOzUsd,
        rates,
        sagha: {
          saghaUsdEgp,
          karat24Sell: Math.round(karat21Sell * (24 / 21)),
          karat24Buy: Math.round(karat21Buy * (24 / 21)),
          karat21Sell,
          karat21Buy,
          karat18Sell: Math.round(karat21Sell * (18 / 21)),
          karat18Buy: Math.round(karat21Buy * (18 / 21))
        }
      };

      return new Response(JSON.stringify(payload), { headers: corsHeaders });
    } catch (err) {
      return new Response(JSON.stringify({ error: 'fallback_mode', message: err.message }), {
        status: 200,
        headers: corsHeaders
      });
    }
  }
};
