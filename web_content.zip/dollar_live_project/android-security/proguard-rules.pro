# قواعد التعتيم والحماية المتقدمة (ProGuard / R8) لتطبيق دولار لايف (com.mohamed.dollarlive)
# ضع هذا الملف في: android/app/proguard-rules.pro وفعّل minifyEnabled true في build.gradle

-optimizationpasses 5
-dontusemixedcaseclassnames
-dontskipnonpubliclibraryclasses
-verbose

# حذف جميع رسائل Logcat في النسخة النهائية لمنع تتبع الكود
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
    public static int e(...);
}

# الحفاظ على كلاسات Capacitor ودرع الحماية و AdMob من الحذف الخاطئ مع تعتيم الباقي
-keep class com.getcapacitor.** { *; }
-keep class com.mohamed.dollarlive.DollarLiveSecurityPlugin { *; }
-keep class com.google.android.gms.ads.** { *; }
