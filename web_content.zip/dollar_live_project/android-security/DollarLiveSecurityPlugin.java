package com.mohamed.dollarlive;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.provider.Settings;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.InetAddress;
import java.security.MessageDigest;

/**
 * DollarLiveSecurityPlugin - درع الحماية الأصلي للأندرويد (Native Android Security Shield)
 * يكشف:
 * 1) وجود تطبيقات Lucky Patcher وأدوات التعديل والباتش (Jasi Patcher / Uret / Xposed / Frida).
 * 2) تفعيل Private DNS لحجب الإعلانات (مثل dns.adguard.com أو NextDNS أو Mullvad) أو تعديل ملف /etc/hosts.
 * 3) التلاعب بالتوقيع الرقمي الأصلي لملف الـ APK (SHA-256 Signature Check).
 * 4) وجود بروكسي تجسس على الشبكة (HTTP Proxy / HttpCanary / Reqable) لحماية مفاتيح الـ API.
 */
@CapacitorPlugin(name = "DollarLiveSecurityPlugin")
public class DollarLiveSecurityPlugin extends Plugin {

    // ضع بصمة مفتاح التوقيع الخاص بك (SHA-256) هنا بعد توليد الـ Release Keystore
    private static final String EXPECTED_SIGNATURE_SHA256 = "C7:BA:4B:3F:74:71:AF:F6:07:FC:54:E9:92:F4:A0:25:23:3A:40:11:32:65:09:13:2D:F8:35:FC:14:28:65:BC";

    private static final String[] PATCHER_PACKAGES = new String[] {
        "com.chelpus.lackypatch",
        "com.dimonvideo.luckypatcher",
        "com.forpda.lp",
        "com.android.vending.billing.InAppBillingService.COIN",
        "com.android.vending.billing.InAppBillingService.LACK",
        "com.android.vending.billing.InAppBillingService.CLON",
        "com.android.vending.billing.InAppBillingService.CRAC",
        "uret.jasi2169.patcher",
        "zone.jasi2169.uretpatcher",
        "de.robv.android.xposed.installer",
        "org.meowcat.edxposed.manager",
        "com.topjohnwu.magisk"
    };

    private static final String[] ADBLOCK_DNS_KEYWORDS = new String[] {
        "adguard",
        "nextdns",
        "controld",
        "mullvad",
        "quad9",
        "cleanbrowsing",
        "ahadns",
        "libredns",
        "rethinkdns",
        "blokada"
    };

    @PluginMethod
    public void verifyEnvironment(PluginCall call) {
        Context ctx = getContext();
        boolean luckyPatcherDetected = isPatcherInstalled(ctx) || isHostsFileModified();
        String dnsHost = getPrivateDnsSpecifier(ctx);
        boolean privateDnsAdBlock = isAdBlockDns(dnsHost) || isAdDomainSinkholed();
        boolean signatureTampered = isSignatureTampered(ctx);
        boolean proxyDetected = isHttpProxyActive();

        JSObject ret = new JSObject();
        ret.put("luckyPatcherDetected", luckyPatcherDetected);
        ret.put("privateDnsAdBlock", privateDnsAdBlock);
        ret.put("dnsHost", dnsHost != null ? dnsHost : "");
        ret.put("signatureTampered", signatureTampered);
        ret.put("proxyDetected", proxyDetected);
        call.resolve(ret);
    }

    private boolean isPatcherInstalled(Context ctx) {
        PackageManager pm = ctx.getPackageManager();
        for (String pkg : PATCHER_PACKAGES) {
            try {
                pm.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES);
                return true;
            } catch (PackageManager.NameNotFoundException ignored) {}
        }
        return false;
    }

    private String getPrivateDnsSpecifier(Context ctx) {
        try {
            String mode = Settings.Global.getString(ctx.getContentResolver(), "private_dns_mode");
            if ("hostname".equalsIgnoreCase(mode)) {
                String spec = Settings.Global.getString(ctx.getContentResolver(), "private_dns_specifier");
                return spec != null ? spec.toLowerCase() : "";
            }
        } catch (Exception ignored) {}
        return "";
    }

    private boolean isAdBlockDns(String dnsHost) {
        if (dnsHost == null || dnsHost.isEmpty()) return false;
        for (String kw : ADBLOCK_DNS_KEYWORDS) {
            if (dnsHost.contains(kw)) return true;
        }
        return false;
    }

    private boolean isAdDomainSinkholed() {
        try {
            InetAddress addr = InetAddress.getByName("pagead2.googlesyndication.com");
            String ip = addr.getHostAddress();
            return "0.0.0.0".equals(ip) || "127.0.0.1".equals(ip);
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isHostsFileModified() {
        File hosts = new File("/system/etc/hosts");
        if (!hosts.exists() || !hosts.canRead()) return false;
        try (BufferedReader br = new BufferedReader(new FileReader(hosts))) {
            String line;
            while ((line = br.readLine()) != null) {
                String lower = line.toLowerCase();
                if (!lower.startsWith("#") && (lower.contains("googlesyndication") || lower.contains("doubleclick.net") || lower.contains("googleads"))) {
                    return true;
                }
            }
        } catch (Exception ignored) {}
        return false;
    }

    private boolean isSignatureTampered(Context ctx) {
        if (EXPECTED_SIGNATURE_SHA256.startsWith("REPLACE_")) return false;
        try {
            PackageInfo pkgInfo = ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), PackageManager.GET_SIGNATURES);
            for (Signature sig : pkgInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(sig.toByteArray());
                StringBuilder sb = new StringBuilder();
                for (byte b : md.digest()) {
                    sb.append(String.format("%02X:", b));
                }
                String currentSha = sb.substring(0, sb.length() - 1);
                if (EXPECTED_SIGNATURE_SHA256.equalsIgnoreCase(currentSha)) {
                    return false;
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isHttpProxyActive() {
        String proxyHost = System.getProperty("http.proxyHost");
        String proxyPort = System.getProperty("http.proxyPort");
        return (proxyHost != null && !proxyHost.isEmpty()) || (proxyPort != null && !proxyPort.isEmpty());
    }
}
