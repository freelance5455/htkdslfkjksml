# دليل منظومة الحماية المتقدمة لتطبيق "دولار لايف | Dollar Live"

تم تزويد تطبيقك بـ **4 طبقات حماية متكاملة** ضد الاختراق وحجب الإعلانات (Private DNS) وتطبيقات التهكير (Lucky Patcher) وسرقة مفاتيح الـ API:

## 1. خزنة تشفير المفاتيح المدمجة (`XOR + Base64 Key Vault`)
- داخل التطبيق، اضغط على زر **🛡️ الحماية** في الشريط العلوي.
- ستجد أداة **🔑 تشفير المفاتيح والروابط الخاصة بك**: الصق فيها أي رابط Cloudflare Worker أو مفتاح API أو معرف وحدة AdMob واضغط **تشفير المفتاح 🔐**.
- سيتحول الرابط أو المفتاح إلى نص مشفر يبدأ بـ `DLV1:...` لا يمكن قراءته عند فك ضغط ملف الـ APK بأدوات مثل `APKTool` أو `MT Manager`، ويفكه التطبيق في الذاكرة العشوائية (`RAM`) لحظة الاتصال فقط.

## 2. كاشف وحاظر Private DNS ومانع الإعلانات (`AdGuard / NextDNS / Hosts`)
- يحتوي `index.html` على فحص مزدوج (DOM Bait + Native Bridge) يكشف تلقائياً إذا كان المستخدم مفعّلاً لـ `dns.adguard.com` أو أي أداة تحجب إعلانات AdMob.
- عند اكتشاف الحجب، تظهر شاشة قفل أمنية تطلب من المستخدم إيقاف `Private DNS` من إعدادات الهاتف لمتابعة استخدام التطبيق (ويمكنك معاينتها من زر **معاينة شاشة الحظر 🚫** داخل نافذة الحماية).

## 3. كود الحماية الأصلي للأندرويد ضد Lucky Patcher (`android-security/DollarLiveSecurityPlugin.java`)
عند بناء نسخة الأندرويد عبر Capacitor:
1. انسخ ملف `android-security/DollarLiveSecurityPlugin.java` إلى مجلد الجافا في مشروع الأندرويد (`android/app/src/main/java/com/mohamed/dollarlive/`).
2. سيفحص هذا الكود تلقائياً:
   - وجود أي حزمة من حزم **Lucky Patcher** أو **Jasi Patcher** أو **Xposed** على الهاتف.
   - تعديل ملف `/system/etc/hosts` الذي يستخدمه Lucky Patcher لحجب إعلانات Google.
   - إعدادات النظام `Settings.Global` لكشف `private_dns_specifier` في أندرويد 9 فما فوق.
   - سلامة التوقيع الرقمي `SHA-256` لمنع إعادة توقيع التطبيق بعد تعديله.

## 4. منع اعتراض الشبكة وتعتيم الكود (`network_security_config.xml` + `proguard-rules.pro`)
- يمنع ملف `network_security_config.xml` برامج التجسس على الشبكة (مثل `HttpCanary` و `Reqable`) من قراءة طلبات الـ HTTPS الخاصة بتطبيقك.
- يقوم ملف `proguard-rules.pro` بتفعيل التعتيم الكامل للكود (`R8 Obfuscation`) وحذف جميع سجلات `Logcat` من النسخة النهائية.
