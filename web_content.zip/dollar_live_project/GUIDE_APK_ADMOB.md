# دليل تشغيل وبناء تطبيق "دولار لايف | Dollar Live" وإضافة إعلانات AdMob

## محتويات حزمة المشروع (`usd_gold_live_tracker.zip`)
1. `www/index.html` (ونسخة في المجلد الرئيسي `index.html`): التطبيق الكامل بصفحتي الدولار (بالطابع الأخضر) والذهب (بالطابع الذهبي) مع جسر إعلانات AdMob المدمج ونافذة سياسة الخصوصية.
2. `cloudflare-worker/worker.js`: كود السحابة المجاني (100,000 طلب/يوم) لتحديث أسعار الدولار والصاغة المصرية مركزياً.
3. `capacitor.config.json` و `package.json`: ملفات إعداد مشروع الأندرويد الجاهزة بمعرف `com.mohamed.dollarlive`.
4. `PRIVACY_POLICY.html`: صفحة سياسة الخصوصية المستقلة الجاهزة للرفع في Google Play Console و AdMob.

## خطوات التحويل إلى APK وتفعيل إعلانات AdMob الحقيقية
1. فك ضغط المشروع على الكمبيوتر، وافتح موجه الأوامر (Terminal) داخل المجلد:
   ```bash
   npm install
   npx cap add android
   npx cap sync android
   ```
2. افتح ملف `android/app/src/main/AndroidManifest.xml` وأضف معرف تطبيقك في AdMob داخل وسم `<application>`:
   ```xml
   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="ca-app-pub-XXXXXXXXXXXXXXXX~YYYYYYYYYY"/>
   ```
3. داخل `index.html` (أو من زر **💰 الإعلانات** داخل التطبيق)، استبدل معرف البانر التجريبي بمعرف وحدة البانر الحقيقي من حسابك في AdMob.
4. افتح المشروع في Android Studio عبر الأمر `npx cap open android` ثم اختر **Build > Generate Signed Bundle / APK** لتوقيع التطبيق بمفتاحك الخاص.
