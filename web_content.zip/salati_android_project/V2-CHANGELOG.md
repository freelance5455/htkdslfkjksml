# Salati V2 changelog

- Premium dark/light UI, redesigned navigation, prayer countdown and daily progress indicator.
- Animated launch splash and a native Capacitor splash-screen configuration.
- Arabic, English and French.
- Country-inferred calculation defaults and city/GPS location flow.
- Bundled audio preparation script and optional phone audio replacement.
- Native Kotlin AlarmManager + foreground Adhan service template with notification permission handling, exact-alarm settings, boot/time-change rescheduling, stop action, and user volume.
- GitHub update feed, support and non-intrusive review settings.

Note: exact build and runtime behavior still requires running `npm run android:init`, building in Android Studio and device testing.
