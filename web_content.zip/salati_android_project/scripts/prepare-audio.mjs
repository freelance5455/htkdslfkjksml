import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dest=path.join(root,'www','assets','adhan.ogg');
const urls=[
  'https://upload.wikimedia.org/wikipedia/commons/b/b0/Beautiful_adhan.ogg',
  'https://commons.wikimedia.org/wiki/Special:Redirect/file/Beautiful_adhan.ogg'
];
await fs.mkdir(path.dirname(dest),{recursive:true});
for (const url of urls) {
  try {
    const res=await fetch(url,{headers:{'User-Agent':'SalatiByTUX/2.0 (build asset preparation)'}});
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const type=(res.headers.get('content-type')||'').toLowerCase();
    const data=Buffer.from(await res.arrayBuffer());
    if(data.length<100000 || (type.includes('text/html') && data.subarray(0,100).toString().includes('<html'))) throw new Error('The response is not an audio file');
    await fs.writeFile(dest,data);
    console.log(`Bundled CC0 Adhan audio: ${dest} (${data.length} bytes)`);
    process.exit(0);
  } catch(e) { console.warn(`Could not download from ${url}: ${e.message}`); }
}
console.error('\nCould not fetch the bundled Adhan automatically. Check internet access and run `npm run prepare:audio` again. The app will otherwise try an online preview, but offline playback will not work until this asset is downloaded.');
process.exit(1);
