import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');const android=path.join(root,'android');
const mainRoot=path.join(android,'app','src','main');
try{await fs.access(mainRoot)}catch{console.error('Android platform not found. Run `npm run android:init` first.');process.exit(1)}
const manifestPath=path.join(mainRoot,'AndroidManifest.xml');let manifest=await fs.readFile(manifestPath,'utf8');
const permissions=['android.permission.POST_NOTIFICATIONS','android.permission.SCHEDULE_EXACT_ALARM','android.permission.FOREGROUND_SERVICE','android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK','android.permission.RECEIVE_BOOT_COMPLETED','android.permission.WAKE_LOCK'];
for(const p of permissions)if(!manifest.includes(`android:name="${p}"`))manifest=manifest.replace('<application',`<uses-permission android:name="${p}" />\n    <application`);
const components=`\n        <service android:name="com.tux.salati.SalatiAdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback" />\n        <receiver android:name="com.tux.salati.AdhanAlarmReceiver" android:exported="false" />\n        <receiver android:name="com.tux.salati.SalatiBootReceiver" android:enabled="true" android:exported="true"><intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /><action android:name="android.intent.action.TIMEZONE_CHANGED" /><action android:name="android.intent.action.TIME_SET" /></intent-filter></receiver>`;
if(!manifest.includes('SalatiAdhanService'))manifest=manifest.replace('</application>',`${components}\n    </application>`);
await fs.writeFile(manifestPath,manifest);
// Copy Kotlin classes into package directory.
const javaRoot=path.join(mainRoot,'java');let mainFile=null;
async function walk(dir){for(const ent of await fs.readdir(dir,{withFileTypes:true})){const p=path.join(dir,ent.name);if(ent.isDirectory())await walk(p);else if(ent.name==='MainActivity.java'||ent.name==='MainActivity.kt')mainFile=p}}
await walk(javaRoot);if(!mainFile)throw new Error('Could not locate MainActivity in Android project.');
const packageDir=path.dirname(mainFile);const template=await fs.readFile(path.join(root,'native','android','SalatiAdhanPlugin.kt.template'),'utf8');
// Match the app package, since Capacitor appId is com.tux.salati.
const mainContent=await fs.readFile(mainFile,'utf8');const pkg=(mainContent.match(/^package\s+([\w.]+)/m)||[])[1]||'com.tux.salati';
if(pkg!=='com.tux.salati')console.warn(`Warning: app package is ${pkg}; this V2 native plugin expects com.tux.salati. Keep appId com.tux.salati or update the package declarations before building.`);
const kotlin=template.replace(/^package com\.tux\.salati/m,`package ${pkg}`);
await fs.writeFile(path.join(packageDir,'SalatiAdhanPlugin.kt'),kotlin);
let updated=mainContent;
if(mainFile.endsWith('.java')){
  if(!updated.includes('SalatiAdhanPlugin')){
    updated=updated.replace(/import com\.getcapacitor\.BridgeActivity;\s*/,'import com.getcapacitor.BridgeActivity;\nimport android.os.Bundle;\nimport com.tux.salati.SalatiAdhanPlugin;\n');
    if(/class MainActivity extends BridgeActivity\s*\{\s*\}/.test(updated)) updated=updated.replace(/class MainActivity extends BridgeActivity\s*\{\s*\}/,'class MainActivity extends BridgeActivity {\n  @Override public void onCreate(Bundle savedInstanceState) { registerPlugin(SalatiAdhanPlugin.class); super.onCreate(savedInstanceState); }\n}');
    else if(updated.includes('class MainActivity extends BridgeActivity')) updated=updated.replace('class MainActivity extends BridgeActivity {','class MainActivity extends BridgeActivity {\n  @Override public void onCreate(Bundle savedInstanceState) { registerPlugin(SalatiAdhanPlugin.class); super.onCreate(savedInstanceState); }');
  }
}else{
  if(!updated.includes('SalatiAdhanPlugin')){
    updated=updated.replace('import com.getcapacitor.BridgeActivity','import com.getcapacitor.BridgeActivity\nimport android.os.Bundle\nimport com.tux.salati.SalatiAdhanPlugin');
    updated=updated.replace('class MainActivity : BridgeActivity() {','class MainActivity : BridgeActivity() {\n  override fun onCreate(savedInstanceState: Bundle?) { registerPlugin(SalatiAdhanPlugin::class.java); super.onCreate(savedInstanceState) }');
  }
}
await fs.writeFile(mainFile,updated);
// Android notification audio resource needs aapt-compatible lower-case resource name.
const rawDir=path.join(mainRoot,'res','raw');await fs.mkdir(rawDir,{recursive:true});
const audio=path.join(root,'www','assets','adhan.ogg');try{await fs.copyFile(audio,path.join(rawDir,'adhan.ogg'))}catch{console.warn('Bundled adhan.ogg not found. Run `npm run prepare:audio` then `npm run android:setup`.')}
console.log('Patched Android manifest, registered native Adhan plugin, and copied audio resource where available.');
