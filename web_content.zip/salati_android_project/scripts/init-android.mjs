import fs from 'node:fs/promises';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
function run(cmd,args){const r=spawnSync(cmd,args,{cwd:root,stdio:'inherit',shell:process.platform==='win32'});if(r.status!==0)process.exit(r.status||1)}
run('npm',['run','prepare:audio']);
try{await fs.access(path.join(root,'android'));console.log('Android platform already exists. Syncing it.');run('npx',['cap','sync','android']);}
catch{run('npx',['cap','add','android']);}
run('node',['scripts/setup-android.mjs']);
console.log('\nAndroid base is ready. Open Android Studio with `npm run open:android`.');
