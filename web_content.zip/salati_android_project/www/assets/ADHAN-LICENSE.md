# Bundled Adhan audio source

- Title: Beautiful adhan.ogg
- Creator: Adam-synagda
- Source page: https://commons.wikimedia.org/wiki/File:Beautiful_adhan.ogg
- License: CC0 1.0 Universal Public Domain Dedication, as stated on the file page.
- The project build script downloads the original Ogg audio into this directory before building the Android package.
