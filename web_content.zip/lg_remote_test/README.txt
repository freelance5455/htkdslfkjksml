LG Smart Remote - Wi-Fi compatibility test 0.1

1. This is an HTML/CSS/JS prototype, NOT an APK.
2. Upload index.html or the ZIP to a web-to-APK service only if it supports raw WebSocket connections to local network hosts (ws://TV_IP:3000) and permits cleartext traffic in Android WebView.
3. On the TV, find the IPv4 address in network settings. Phone and TV must share a LAN.
4. Open app, enter IP, press Connect, and accept pairing on TV.
5. If connection fails, the WebView packager may block insecure WebSocket/mixed content. Use native Android build in that case.
6. TV protocol compatibility, permissions, pointer and text entry are experimental; the 2014 TV may reject commands.
7. Never upload your TV pairing key to third-party sites. This prototype stores the key only in localStorage on the device.
8. No infrared support in this web prototype. Power-on requires IR or another supported wake method.
