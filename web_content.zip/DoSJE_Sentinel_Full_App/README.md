# DoSJE Sentinel — Full Working Prototype

Three roles: DoSJE Admin, Inspector, NGO/Institute.

Demo accounts:
- Admin: admin@dosje.gov.in / Admin@123
- Inspector: inspector@dosje.gov.in / Inspector@123
- NGO: ngo@example.org / Ngo@123

Features: JWT login, role-based dashboards, project registry, inspection assignment, inspector workflow, GPS verification fields, checklist, evidence upload, risk scoring, NGO status view, audit database.

Run:
1. Install Node.js 18+.
2. Extract ZIP.
3. Terminal in folder: npm install
4. npm start
5. Open http://localhost:3000

SQLite database is created automatically. Change the JWT secret and demo passwords before real deployment. CCTV/live GPS/push notifications are integration points, not production services.
