# Firebase cloud setup — Coffee Trade ERP

This build uses Firebase Authentication + Cloud Firestore for multi-device login and per-user ERP data.

## 1. Create the Firebase project
1. Open Firebase Console: https://console.firebase.google.com/
2. Create a project for Coffee Trade ERP.
3. Add a **Web app** to the project (the Android app contains a WebView, so the bundled ERP uses Firebase's web SDK).
4. Copy the web app configuration into:
   `app/src/main/assets/firebase-config.js`

Do not put service-account JSON, private keys, or Firebase Admin SDK secrets into the APK.

## 2. Enable authentication
Firebase Console → Authentication → Sign-in method → enable **Email/Password**.

## 3. Create Firestore
Firebase Console → Firestore Database → Create database.
Use production mode, then publish the supplied `firestore.rules` file.

## 4. Security model
Each signed-in user's records live under:
- `users/{uid}/profile/main`
- `users/{uid}/data/erp`

The rules only allow a signed-in user to read/write documents where `{uid}` equals their Firebase Auth UID.

## 5. Build
Open the project in Android Studio, sync Gradle, then build the APK.

## Existing local data
On first cloud sign-in, if that user has no cloud ERP workspace yet, the app uploads the local ERP workspace from that device. Once cloud data exists, other devices load the cloud workspace.
