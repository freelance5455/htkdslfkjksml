# Pocket Strike

Tiro tático estilo CS para celular (HTML + JavaScript + Three.js), leve, com bots offline e **multiplayer online por WebSocket** (servidor Node.js separado). Pronto para virar APK com Capacitor.

## Estrutura

```
cs-mobile/
├── package.json              (scripts do projeto / Capacitor)           [NOVO]
├── capacitor.config.json     (config do APK)                            [NOVO]
├── .gitignore                                                           [NOVO]
├── README.md                                                            [NOVO]
├── scripts/
│   └── setup-android.js      (landscape + internet + ws:// no APK)      [NOVO]
├── server/                   ===== SERVIDOR (Node.js) =====             [NOVO]
│   ├── package.json
│   ├── server.js             (salas, partida, tiro, dano, respawn, placar)
│   └── test-server.js        (teste automático do servidor)
└── www/                      ===== CLIENTE (vira o APK) =====
    ├── index.html            (HUD, botões de toque, menus + telas online)  [MODIFICADO]
    ├── assets/char.jpg       (textura do personagem, 512px)
    └── js/
        ├── three.min.js      (Three.js r150)
        ├── models.js         (personagem + peixe/bomba de sabão otimizados)
        ├── maps.js           (3 mapas)                                  [MODIFICADO: roda também no servidor]
        ├── shared.js         (armas, colisão, raios — cliente E servidor)  [NOVO]
        ├── game.js           (jogo: render, bots, armas, habilidades...) [NOVO nesta etapa]
        ├── net.js            (cliente WebSocket, salas, lobby)          [NOVO]
        └── ui.js             (menus, configurações, inicialização)      [NOVO]
```

## 1) Rodar o servidor

Precisa do Node.js 16 ou mais novo.

```bash
cd server
npm install
npm start            # porta 3000   (outra porta:  PORT=8080 npm start)
```

O servidor também entrega a pasta `www/` por HTTP (para testar no navegador). Para desligar isso: `SERVE_CLIENT=0 npm start`.

## 2) Jogar

- **No navegador (PC ou celular na mesma rede Wi‑Fi):** abra `http://IP-DO-PC:3000` → *Multiplayer online* → *Conectar* (o endereço já vem preenchido) → crie uma sala; o amigo abre o mesmo endereço e entra na sala.
- **Offline:** *Jogar offline (bots)* — não precisa de servidor.

Controles no celular: joystick à esquerda, arraste a direita para mirar, FOGO, PULAR, 🫧 bomba de sabão, ⟳ recarregar, MIRA, TROCA, ⚡ dash, 📡 radar, ✚ cura, 🛒 armas, 📊 placar.
No PC: WASD, mouse, Espaço, R, G (bomba), Q/E/F (habilidades), B (armas), Tab (placar), 1‑5 (armas), botão direito (mira).

## 3) Gerar o APK (Capacitor)

Precisa de Node.js, Android Studio e JDK 17.

```bash
npm install
npm run android:add     # cria a pasta android/ e ajusta o manifesto (landscape, internet)
npm run android:open    # abre no Android Studio -> Build > Build APK(s)
```

Depois de mudar qualquer arquivo em `www/`: `npm run android:sync`.

No APK, o endereço do servidor não pode ser `localhost`. Na tela *Multiplayer online* digite o IP do PC (rede local) ou o domínio do servidor, por exemplo `ws://192.168.0.10:3000/ws`. O app lembra o último endereço usado. Para trocar o padrão, edite `defaultUrl()` em `www/js/net.js`.

## 4) Servidor na internet

Suba a pasta `server/` (e `www/` ao lado, pois o servidor usa `www/js/maps.js` e `www/js/shared.js`) em uma VPS/Render/Railway/Fly. Com HTTPS use **wss://** (proxy reverso como Nginx/Caddy repassando `/ws`). Se o app for usar `wss://`, pode trocar `androidScheme` para `https` em `capacitor.config.json`.

## Como o multiplayer funciona

- Servidor **autoritativo** para o que importa: tiros, dano, vida, morte, respawn, placar, bazuca e bomba de sabão são calculados no servidor. O cliente só envia posição/rotação (15x/s) e pedidos de ação.
- Servidor valida velocidade e posição (anti‑teleporte), limita cadência de tiro por arma e usa compensação de lag (volta no tempo as posições dos alvos).
- Partida: *Team Deathmatch* — primeiro time a 25 abates ou 5 minutos; respawn em 3 s com 1,5 s de proteção; placar com abates, mortes e ping; entrada e saída de jogadores a qualquer momento; host passa para outro jogador se sair.
- Bomba de sabão: o servidor simula o arremesso e, ao estourar, envia `flash` (1 s de tela clara) só para inimigos próximos, com linha de visão e olhando para ela.
- Mensagens são JSON por WebSocket em `/ws` (veja `server/server.js`).

## Testes feitos

`server/test-server.js` (salas, entrada/saída, sincronização, tiro, morte, respawn, bomba, anti‑teleporte): `ALLOW_TELEPORT=1 node server.js` e em outro terminal `node test-server.js`. (`ALLOW_TELEPORT` é só para teste, nunca use em produção.)

Observação: os testes de cliente foram feitos em ambiente simulado (sem GPU/tela). Teste em um celular real e ajuste a qualidade em *Configurações* se necessário.
