/* Ajusta o projeto Android gerado pelo Capacitor: tela deitada (landscape), internet e tráfego ws:// liberado.
   Rode depois de "npx cap add android" (o npm run android:add já faz isso). Pode rodar várias vezes. */
const fs = require('fs'), path = require('path');
const f = path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(f)) { console.error('AndroidManifest.xml não encontrado. Rode antes: npx cap add android'); process.exit(1); }
let s = fs.readFileSync(f, 'utf8');
if (!/android:screenOrientation=/.test(s)) s = s.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
if (!/android:usesCleartextTraffic=/.test(s)) s = s.replace('<application', '<application\n        android:usesCleartextTraffic="true"');
if (!/android.permission.INTERNET/.test(s)) s = s.replace('</manifest>', '    <uses-permission android:name="android.permission.INTERNET" />\n</manifest>');
if (!/android.permission.VIBRATE/.test(s)) s = s.replace('</manifest>', '    <uses-permission android:name="android.permission.VIBRATE" />\n</manifest>');
fs.writeFileSync(f, s); console.log('AndroidManifest.xml ajustado (landscape + internet + ws://).');
