'use strict';
/* =====================================================================
   Pocket Strike - Servidor multiplayer (Node.js + WebSocket)
   Pasta: server/server.js
   - Salas (criar / listar / entrar / sair)
   - Partida Team Deathmatch com respawn e placar
   - Servidor valida tiros, dano, vida, morte e projéteis (bazuca / bomba de sabão)
   - Reaproveita www/js/maps.js e www/js/shared.js (mesmas armas e mapas do cliente)
   Uso:  npm install && npm start      (porta padrão 3000, variável PORT)
   ===================================================================== */
const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const MAPS = require('../www/js/maps.js');
const SH = require('../www/js/shared.js');

const PORT = parseInt(process.env.PORT || '3000', 10);
const TEST_TELEPORT = process.env.ALLOW_TELEPORT === '1';             // SÓ para testes automáticos
const SERVE_CLIENT = process.env.SERVE_CLIENT !== '0';           // serve a pasta www por HTTP (opcional)
const WWW = path.join(__dirname, '..', 'www');
const TICK_MS = 50;                                              // 20 Hz
const MAX_ROOMS = 50, MAX_PLAYERS = 10;
const KILL_LIMIT = 25, TIME_LIMIT = 300, RESPAWN_MS = 3000, SPAWN_PROTECT_MS = 1500, END_MS = 8000;
const P = SH.P, W = SH.WEAPONS;

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.jpg': 'image/jpeg', '.png': 'image/png', '.json': 'application/json', '.svg': 'image/svg+xml' };
const httpServer = http.createServer((req, res) => {
  if (req.url === '/health') { res.writeHead(200); return res.end('ok'); }
  if (!SERVE_CLIENT) { res.writeHead(404); return res.end('cliente nao servido por aqui'); }
  let u = decodeURIComponent((req.url || '/').split('?')[0]);
  if (u === '/') u = '/index.html';
  const f = path.normalize(path.join(WWW, u));
  if (!f.startsWith(WWW)) { res.writeHead(403); return res.end(); }
  fs.readFile(f, (err, data) => {
    if (err) { res.writeHead(404); return res.end('404'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream' });
    res.end(data);
  });
});
const wss = new WebSocket.Server({ server: httpServer, path: '/ws', maxPayload: 4096 });

let nextId = 1;
const clients = new Map();   // id -> player
const rooms = new Map();     // id -> room
let nextRoom = 1;

const now = () => Date.now();
const r2 = (v) => Math.round(v * 100) / 100;
const clean = (s, n) => String(s || '').replace(/[^\p{L}\p{N} _.\-]/gu, '').trim().slice(0, n);
function send(p, o) { if (p.ws.readyState === WebSocket.OPEN) p.ws.send(JSON.stringify(o)); }
function bcast(room, o, except) { const s = JSON.stringify(o); for (const p of room.players.values()) if (p !== except && p.ws.readyState === WebSocket.OPEN) p.ws.send(s); }

// ------------------------------------------------------------------ salas
function roomInfo(r) { return { id: r.id, name: r.name, map: r.map.name, mapIdx: r.mapIdx, players: r.players.size, max: r.max, state: r.state }; }
function sendRoomList(p) { send(p, { t: 'rooms', list: Array.from(rooms.values()).map(roomInfo) }); }

function createRoom(host, name, mapIdx, max) {
  if (rooms.size >= MAX_ROOMS) return send(host, { t: 'err', m: 'Servidor cheio de salas' });
  mapIdx = Math.max(0, Math.min(MAPS.count - 1, mapIdx | 0));
  const room = { id: nextRoom++, name: clean(name, 20) || ('Sala de ' + host.name), mapIdx, map: MAPS.build(mapIdx), max: Math.max(2, Math.min(MAX_PLAYERS, max | 0 || 8)),
    host: host.id, players: new Map(), state: 'lobby', startedAt: 0, endsAt: 0, score: [0, 0], projs: [], pid: 1, endTimer: 0, lastSb: 0 };
  rooms.set(room.id, room);
  joinRoom(host, room);
}

function joinRoom(p, room) {
  if (p.room) leaveRoom(p, true);
  if (room.players.size >= room.max) return send(p, { t: 'err', m: 'Sala cheia' });
  const c = [0, 0]; for (const q of room.players.values()) c[q.team]++;
  p.team = c[0] <= c[1] ? 0 : 1;
  p.room = room; room.players.set(p.id, p);
  p.k = 0; p.d = 0; p.hist = [];
  spawn(p, room.state === 'live');
  send(p, { t: 'joined', room: roomInfo(room), you: p.id, host: room.host, team: p.team, state: room.state, score: room.score, left: timeLeft(room), players: listPlayers(room) });
  bcast(room, { t: 'pj', p: pubInfo(p) }, p);
}

function leaveRoom(p, silent) {
  const room = p.room; if (!room) return;
  room.players.delete(p.id); p.room = null;
  bcast(room, { t: 'pl', id: p.id });
  if (!silent) send(p, { t: 'left' });
  if (room.players.size === 0) { rooms.delete(room.id); return; }
  if (room.host === p.id) { room.host = room.players.keys().next().value; bcast(room, { t: 'host', id: room.host }); }
}

const pubInfo = (p) => ({ id: p.id, name: p.name, team: p.team, k: p.k, d: p.d, alive: p.alive ? 1 : 0, x: r2(p.x), y: r2(p.y), z: r2(p.z), yaw: r2(p.yaw), pit: r2(p.pit), w: p.w, hp: p.hp });
const listPlayers = (room) => Array.from(room.players.values()).map(pubInfo);
const timeLeft = (room) => room.state === 'live' ? Math.max(0, Math.round((room.endsAt - now()) / 1000)) : 0;

function spawn(p, alive) {
  const room = p.room; const s = SH.spawnPoint(room.map, p.team);
  p.x = s.x; p.y = 0; p.z = s.z; p.hp = P.hp; p.alive = !!alive; p.bombs = 2; p.inv = now() + SPAWN_PROTECT_MS;
  p.yaw = p.team === 0 ? 0 : Math.PI; p.pit = 0; p.hist.length = 0; p.healAt = 0; p.respawnAt = 0;
  p.lastPos = { x: p.x, y: p.y, z: p.z, t: now() };
  if (alive) bcast(room, { t: 'resp', id: p.id, team: p.team, x: r2(p.x), y: 0, z: r2(p.z), yaw: r2(p.yaw), hp: p.hp });
}

// ------------------------------------------------------------------ partida
function startMatch(room) {
  room.state = 'live'; room.score = [0, 0]; room.startedAt = now(); room.endsAt = now() + TIME_LIMIT * 1000; room.projs.length = 0;
  for (const p of room.players.values()) { p.k = 0; p.d = 0; spawn(p, true); }
  bcast(room, { t: 'start', left: TIME_LIMIT, limit: KILL_LIMIT, score: room.score, players: listPlayers(room) });
}
function endMatch(room) {
  room.state = 'end'; room.projs.length = 0;
  const winner = room.score[0] === room.score[1] ? -1 : (room.score[0] > room.score[1] ? 0 : 1);
  bcast(room, { t: 'end', winner, score: room.score, board: board(room) });
  room.endTimer = now() + END_MS;
}
function board(room) { return Array.from(room.players.values()).map((p) => ({ id: p.id, name: p.name, team: p.team, k: p.k, d: p.d, ping: Math.round(p.rtt || 0) })); }

// posição histórica (compensação de lag)
function posAt(p, t) {
  const h = p.hist; if (!h.length) return p;
  for (let i = h.length - 1; i >= 0; i--) if (h[i].t <= t) { const a = h[i], b = h[i + 1]; if (!b) return a; const f = (t - a.t) / Math.max(1, b.t - a.t); return { x: a.x + (b.x - a.x) * f, y: a.y + (b.y - a.y) * f, z: a.z + (b.z - a.z) * f }; }
  return h[0];
}

function damage(room, victim, attacker, dmg, wname, head) {
  if (!victim.alive || now() < victim.inv) return;
  victim.hp = Math.max(0, victim.hp - Math.round(dmg));
  bcast(room, { t: 'hit', to: victim.id, by: attacker.id, dmg: Math.round(dmg), hp: victim.hp, hs: head ? 1 : 0 });
  if (victim.hp <= 0) {
    victim.alive = false; victim.d++; victim.respawnAt = now() + RESPAWN_MS;
    if (attacker !== victim && attacker.team !== victim.team) { attacker.k++; room.score[attacker.team]++; }
    else if (attacker === victim) { victim.k = Math.max(0, victim.k - 1); }
    bcast(room, { t: 'kill', k: attacker.id, v: victim.id, w: wname, hs: head ? 1 : 0, score: room.score });
    if (room.score[0] >= KILL_LIMIT || room.score[1] >= KILL_LIMIT) endMatch(room);
  }
}

function handleFire(p, m) {
  const room = p.room; if (!room || room.state !== 'live' || !p.alive) return;
  const w = W[m.w]; if (!w) return;
  p.lastFire = p.lastFire || {}; const t = now();
  if (t - (p.lastFire[m.w] || 0) < w.rate * 850) return;       // limite de cadência
  p.lastFire[m.w] = t;
  let dx = +m.dx, dy = +m.dy, dz = +m.dz; if (!isFinite(dx + dy + dz)) return;
  const L = Math.hypot(dx, dy, dz); if (L < 0.5) return; dx /= L; dy /= L; dz /= L;
  p.w = m.w;
  if (w.rocket) {
    room.projs.push({ id: room.pid++, kind: 'rocket', owner: p.id, team: p.team, x: p.x + dx * 0.8, y: p.y + P.eye + dy * 0.8, z: p.z + dz * 0.8, vx: dx * 28, vy: dy * 28, vz: dz * 28, born: t });
    const pr = room.projs[room.projs.length - 1];
    return bcast(room, { t: 'proj', id: pr.id, kind: 'rocket', x: r2(pr.x), y: r2(pr.y), z: r2(pr.z), vx: r2(pr.vx), vy: r2(pr.vy), vz: r2(pr.vz), by: p.id });
  }
  const ox = p.x, oy = p.y + P.eye, oz = p.z;
  const wd = SH.rayWorld(room.map, ox, oy, oz, dx, dy, dz, w.range);
  let best = null, bt = Math.min(wd, w.range);
  const rewind = t - Math.min(300, 100 + (p.rtt || 0) / 2);
  for (const q of room.players.values()) {
    if (q === p || !q.alive || q.team === p.team) continue;
    const qp = posAt(q, rewind);
    const h = SH.rayChar(ox, oy, oz, dx, dy, dz, qp.x, qp.y, qp.z);
    if (h && h.t < bt) { bt = h.t; best = { q, head: h.head }; }
  }
  bcast(room, { t: 'shot', id: p.id, w: m.w, ox: r2(ox), oy: r2(oy), oz: r2(oz), ex: r2(ox + dx * bt), ey: r2(oy + dy * bt), ez: r2(oz + dz * bt), hit: best ? 1 : 0 });
  if (best) damage(room, best.q, p, w.dmg * (best.head ? 2.5 : 1), m.w, best.head);
}

function handleBomb(p, m) {
  const room = p.room; if (!room || room.state !== 'live' || !p.alive || p.bombs <= 0) return;
  let dx = +m.dx, dy = +m.dy, dz = +m.dz; if (!isFinite(dx + dy + dz)) return;
  const L = Math.hypot(dx, dy, dz); if (L < 0.5) return; dx /= L; dy /= L; dz /= L;
  p.bombs--;
  const pr = { id: room.pid++, kind: 'bomb', owner: p.id, team: p.team, x: p.x, y: p.y + P.eye, z: p.z, vx: dx * 14, vy: dy * 14 + 3, vz: dz * 14, born: now(), fuse: 1400 };
  room.projs.push(pr);
  bcast(room, { t: 'proj', id: pr.id, kind: 'bomb', x: r2(pr.x), y: r2(pr.y), z: r2(pr.z), vx: r2(pr.vx), vy: r2(pr.vy), vz: r2(pr.vz), by: p.id });
}

function explode(room, pr) {
  const owner = room.players.get(pr.owner);
  bcast(room, { t: 'boom', id: pr.id, kind: pr.kind, x: r2(pr.x), y: r2(pr.y), z: r2(pr.z) });
  if (pr.kind === 'rocket') {
    const R = W.bazooka.splash;
    for (const q of room.players.values()) {
      if (!q.alive) continue; if (q.team === pr.team && q.id !== pr.owner) continue;
      const d = Math.hypot(q.x - pr.x, q.y + 0.9 - pr.y, q.z - pr.z); if (d > R) continue;
      let dm = W.bazooka.dmg * (1 - d / R); if (q.id === pr.owner) dm *= 0.5;
      if (owner) damage(room, q, owner, dm, 'bazooka', false);
    }
  } else {   // bomba de sabão: ofusca inimigos por 1 segundo
    for (const q of room.players.values()) {
      if (!q.alive || q.team === pr.team) continue;
      const ex = pr.x - q.x, ey = pr.y - (q.y + P.eye), ez = pr.z - q.z, d = Math.hypot(ex, ey, ez);
      if (d > 14 || d < 0.01) continue;
      if (SH.rayWorld(room.map, q.x, q.y + P.eye, q.z, ex, ey, ez, d - 0.1) < d - 0.2) continue;   // parede no meio
      const fx = -Math.sin(q.yaw) * Math.cos(q.pit), fy = Math.sin(q.pit), fz = -Math.cos(q.yaw) * Math.cos(q.pit);
      if ((fx * ex + fy * ey + fz * ez) / d < -0.3) continue;                                  // de costas
      send(q, { t: 'flash', ms: 1000 });
    }
  }
}

function stepProjs(room, dt) {
  const t = now();
  for (let i = room.projs.length - 1; i >= 0; i--) {
    const pr = room.projs[i]; let done = false;
    if (pr.kind === 'rocket') {
      const n = 2, h = dt / n;
      for (let s = 0; s < n && !done; s++) {
        pr.x += pr.vx * h; pr.y += pr.vy * h; pr.z += pr.vz * h;
        if (pr.y < 0 || SH.cellH(room.map, Math.floor(pr.x / 2), Math.floor(pr.z / 2)) > pr.y) done = true;
        for (const q of room.players.values()) { if (q.alive && q.team !== pr.team && Math.hypot(q.x - pr.x, q.y + 0.9 - pr.y, q.z - pr.z) < 0.7) done = true; }
      }
      if (t - pr.born > 4000) done = true;
    } else {
      pr.vy -= 16 * dt;
      let nx = pr.x + pr.vx * dt, ny = pr.y + pr.vy * dt, nz = pr.z + pr.vz * dt;
      if (SH.cellH(room.map, Math.floor(nx / 2), Math.floor(pr.z / 2)) > ny) { pr.vx *= -0.5; nx = pr.x; }
      if (SH.cellH(room.map, Math.floor(pr.x / 2), Math.floor(nz / 2)) > ny) { pr.vz *= -0.5; nz = pr.z; }
      if (ny < 0.15) { ny = 0.15; pr.vy = Math.abs(pr.vy) * 0.45; pr.vx *= 0.7; pr.vz *= 0.7; }
      pr.x = nx; pr.y = ny; pr.z = nz;
      if (t - pr.born > pr.fuse) done = true;
    }
    if (done) { room.projs.splice(i, 1); explode(room, pr); }
  }
}

function tickRoom(room) {
  const t = now(), dt = TICK_MS / 1000;
  if (room.state === 'live') {
    if (t >= room.endsAt) endMatch(room);
    for (const p of room.players.values()) {
      if (!p.alive && p.respawnAt && t >= p.respawnAt) spawn(p, true);
    }
    stepProjs(room, dt);
  } else if (room.state === 'end' && t >= room.endTimer) {
    room.state = 'lobby'; room.score = [0, 0];
    for (const p of room.players.values()) { p.k = 0; p.d = 0; spawn(p, false); }
    bcast(room, { t: 'lobby', players: listPlayers(room) });
  }
  const arr = [];
  for (const p of room.players.values()) {
    arr.push([p.id, r2(p.x), r2(p.y), r2(p.z), r2(p.yaw), r2(p.pit), p.w, p.hp, p.alive ? 1 : 0]);
    p.hist.push({ t, x: p.x, y: p.y, z: p.z }); while (p.hist.length && p.hist[0].t < t - 600) p.hist.shift();
  }
  bcast(room, { t: 'snap', p: arr, left: timeLeft(room) });
  if (t - room.lastSb > 1000) { room.lastSb = t; bcast(room, { t: 'sb', board: board(room), score: room.score }); }
}
setInterval(() => { for (const room of rooms.values()) tickRoom(room); }, TICK_MS);

// ------------------------------------------------------------------ conexões
wss.on('connection', (ws) => {
  const p = { id: nextId++, ws, name: 'Jogador' + (nextId - 1), room: null, team: 0, x: 0, y: 0, z: 0, yaw: 0, pit: 0, w: 'revolver', hp: 100, alive: false, k: 0, d: 0, hist: [], rtt: 0, alive2: true, msgs: 0, mt: now() };
  clients.set(p.id, p);
  send(p, { t: 'welcome', id: p.id, maps: MAPS.DEFS.map((d) => d.name) });
  ws.on('pong', () => { p.alive2 = true; });
  ws.on('message', (raw) => {
    const t = now(); if (t - p.mt > 1000) { p.mt = t; p.msgs = 0; } if (++p.msgs > 150) return ws.terminate();
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || typeof m.t !== 'string') return;
    const room = p.room;
    switch (m.t) {
      case 'name': p.name = clean(m.name, 16) || p.name; break;
      case 'list': sendRoomList(p); break;
      case 'create': createRoom(p, m.name, m.map, m.max); break;
      case 'join': { const r = rooms.get(m.id | 0); if (!r) return send(p, { t: 'err', m: 'Sala não existe' }); joinRoom(p, r); break; }
      case 'leave': leaveRoom(p); break;
      case 'team': if (room && room.state === 'lobby' && (m.team === 0 || m.team === 1)) { p.team = m.team; spawn(p, false); bcast(room, { t: 'team', id: p.id, team: p.team }); } break;
      case 'start': if (room && room.host === p.id && room.state === 'lobby') startMatch(room); break;
      case 'st': {      // estado do jogador: posição, rotação, arma
        if (!room || !p.alive) break;
        const x = +m.x, y = +m.y, z = +m.z; if (!isFinite(x + y + z)) break;
        const dtm = Math.max(0.03, (t - p.lastPos.t) / 1000), d = Math.hypot(x - p.lastPos.x, z - p.lastPos.z);
        if ((!TEST_TELEPORT && d > 18 * dtm + 1.5) || SH.cellH(room.map, Math.floor(x / 2), Math.floor(z / 2)) > 1.6 || y < -1 || y > 6) {   // velocidade ou local impossível
          send(p, { t: 'fix', x: r2(p.x), y: r2(p.y), z: r2(p.z) }); break;
        }
        p.x = x; p.y = y; p.z = z; p.yaw = +m.yaw || 0; p.pit = Math.max(-1.5, Math.min(1.5, +m.pit || 0));
        if (W[m.w]) p.w = m.w; p.lastPos = { x, y, z, t };
        break;
      }
      case 'fire': handleFire(p, m); break;
      case 'bomb': handleBomb(p, m); break;
      case 'heal': if (room && p.alive && t > p.healAt && p.hp < P.hp) { p.healAt = t + 25000; p.hp = Math.min(P.hp, p.hp + 35); send(p, { t: 'healed', hp: p.hp }); } break;
      case 'ping': send(p, { t: 'pong', c: m.c }); if (typeof m.r === 'number' && m.r >= 0 && m.r < 5000) p.rtt = m.r; break;
      case 'chat': if (room) bcast(room, { t: 'chat', id: p.id, m: clean(m.m, 60) }); break;
    }
  });
  ws.on('close', () => { leaveRoom(p, true); clients.delete(p.id); });
  ws.on('error', () => {});
});
setInterval(() => { for (const p of clients.values()) { if (!p.alive2) { p.ws.terminate(); continue; } p.alive2 = false; try { p.ws.ping(); } catch (e) {} } }, 15000);

httpServer.listen(PORT, () => console.log('Pocket Strike server em http://0.0.0.0:' + PORT + '  (WebSocket em /ws)' + (SERVE_CLIENT ? '  [servindo cliente de ../www]' : '')));
