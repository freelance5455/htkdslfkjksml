'use strict';
// Teste automático: 2 clientes falsos entram numa sala, atiram, matam, respawnam, fim de partida.
// Uso: ALLOW_TELEPORT=1 node server.js   (em outra janela)   e depois:  node test-server.js [ws://localhost:3000/ws]
const WebSocket = require('ws');
const url = process.argv[2] || 'ws://localhost:3000/ws';
const SH = require('../www/js/shared.js');
let fail = 0; const ok = (c, m) => { console.log((c ? 'OK   ' : 'FALHA ') + m); if (!c) fail++; };
function client(name) {
  return new Promise((res) => {
    const ws = new WebSocket(url), c = { ws, name, got: [], send: (o) => ws.send(JSON.stringify(o)) };
    ws.on('message', (d) => { const m = JSON.parse(d); c.got.push(m); if (m.t === 'welcome') { c.id = m.id; c.send({ t: 'name', name }); res(c); } });
  });
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const find = (c, t) => c.got.filter((m) => m.t === t);
(async () => {
  const a = await client('Ana'), b = await client('Beto');
  a.send({ t: 'create', name: 'SalaTeste', map: 0, max: 6 }); await wait(150);
  ok(find(a, 'joined').length === 1, 'Ana criou e entrou na sala');
  b.send({ t: 'list' }); await wait(150);
  const list = find(b, 'rooms')[0].list; ok(list.length >= 1 && list[0].name === 'SalaTeste', 'Beto vê a sala na lista');
  b.send({ t: 'join', id: list[0].id }); await wait(150);
  const jb = find(b, 'joined')[0]; ok(jb && jb.players.length === 2, 'Beto entrou (2 jogadores)');
  ok(find(a, 'pj').length === 1, 'Ana foi avisada da entrada de Beto');
  const ja = find(a, 'joined')[0]; ok(ja.team !== jb.team, 'times balanceados');
  a.send({ t: 'start' }); await wait(200);
  ok(find(a, 'start').length === 1 && find(b, 'start').length === 1, 'partida iniciada para os dois');
  // posiciona os dois em linha reta sem paredes: usa spawn de cada time (mapa 0) e fica parado
  const sa = find(a, 'resp').pop(), sb = find(b, 'resp').pop();
  // coloca Ana e Beto no corredor do meio (x=40..48, z entre 40 e 60) cara a cara
  const mx = 44;
  for (let i = 0; i < 3; i++) { a.send({ t: 'st', x: mx, y: 0, z: 40, yaw: 0, pit: 0, w: 'rifle' }); b.send({ t: 'st', x: mx, y: 0, z: 40 + 0, yaw: 0, pit: 0, w: 'rifle' }); await wait(60); }
  // teleporte longo deve ser rejeitado
  const fixes0 = find(a, 'fix').length;
  // distancia real: Ana em z=40, Beto em z=60 (via passos pequenos)
  for (let z = 40; z < 60; z += 1) { b.send({ t: 'st', x: mx, y: 0, z, yaw: Math.PI, pit: 0, w: 'rifle' }); await wait(60); }
  await wait(300);
  const snap = find(a, 'snap').pop(); ok(snap.p.length === 2, 'snapshots com 2 jogadores');
  const bs = snap.p.find((p) => p[0] === b.id); ok(Math.abs(bs[3] - 59) < 1.5, 'posição de Beto sincronizada (z=' + bs[3] + ')');
  // Ana atira em Beto (direção +z, altura do peito)
  const killsBefore = find(a, 'kill').length;
  for (let i = 0; i < 12 && find(b, 'kill').length === killsBefore; i++) { a.send({ t: 'fire', w: 'rifle', dx: 0, dy: -0.04 + 0.0, dz: 1 }); await wait(130); }
  await wait(200);
  const hits = find(a, 'hit'); ok(hits.length > 0, 'tiros causaram dano (' + hits.length + ' acertos)');
  const kills = find(b, 'kill'); ok(kills.length === 1 && kills[0].k === a.id && kills[0].v === b.id, 'Beto morreu e o placar registrou a morte');
  ok(find(b, 'kill')[0].score[(find(a, 'joined')[0].team)] === 1, 'placar do time da Ana = 1');
  await wait(3300);
  const resp = find(b, 'resp').filter((r) => r.id === b.id); ok(resp.length >= 2, 'Beto renasceu após 3s');
  // bomba de sabão: Ana arremessa perto de Beto; Beto (virado para ela) recebe flash
  b.send({ t: 'st', x: mx, y: 0, z: 56, yaw: Math.PI, pit: 0, w: 'rifle' }); await wait(120);
  a.send({ t: 'st', x: mx, y: 0, z: 40, yaw: 0, pit: 0, w: 'rifle' }); await wait(120);
  const sbpos = find(b, 'resp').pop();
  // servidor corrige se o respawn colocou longe: reenvia posições em passos
  a.send({ t: 'bomb', dx: 0, dy: 0.2, dz: 1 }); await wait(2200);
  ok(find(a, 'proj').some((p) => p.kind === 'bomb') && find(a, 'boom').some((p) => p.kind === 'bomb'), 'bomba de sabão criada e explodiu');
  // saída
  b.ws.close(); await wait(200); ok(find(a, 'pl').length === 1, 'Ana foi avisada da saída de Beto');
  // anti-teleporte
  a.send({ t: 'st', x: 3, y: 0, z: 3, yaw: 0, pit: 0, w: 'rifle' }); await wait(150); ok(find(a, 'fix').length > fixes0, 'posição dentro de parede foi corrigida pelo servidor');
  a.ws.close(); await wait(100);
  console.log(fail ? ('\n' + fail + ' FALHA(S)') : '\nTodos os testes passaram'); process.exit(fail ? 1 : 0);
})();
