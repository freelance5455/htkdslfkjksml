/* Pocket Strike - menus, configurações e inicialização (www/js/ui.js) */
(function () {
  'use strict';
  const G = window.G, S = G.S, MAPS = window.MAPS, $ = (id) => document.getElementById(id);

  // navegação entre telas
  document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => { G.snd.click(); const to = b.dataset.go; if (to === 'online') G.openOnline(); else G.showScreen(to); }));

  // mapas no setup offline
  const mapSel = $('offMap'); MAPS.DEFS.forEach((d, i) => { const o = document.createElement('option'); o.value = i; o.textContent = d.name; mapSel.appendChild(o); });
  $('btnPlayOff').addEventListener('click', () => {
    S.diff = +$('offDiff').value; G.saveSettings();
    G.startOffline({ map: +mapSel.value, side: +$('offSide').value, size: +$('offSize').value });
  });

  // configurações
  $('setQ').value = S.q; $('setSens').value = S.sens; $('setFps').value = S.fps; $('setSound').checked = !!S.sound; $('offDiff').value = S.diff;
  $('setQ').addEventListener('input', (e) => { S.q = +e.target.value; G.applyQuality(); G.saveSettings(); });
  $('setSens').addEventListener('input', (e) => { S.sens = +e.target.value; G.saveSettings(); });
  $('setFps').addEventListener('change', (e) => { S.fps = +e.target.value; G.saveSettings(); });
  $('setSound').addEventListener('change', (e) => { S.sound = e.target.checked ? 1 : 0; G.saveSettings(); });

  // pausa e fim de partida
  $('btnResume').addEventListener('click', () => G.setPause(false));
  $('btnQuit').addEventListener('click', () => G.leaveToMenu());
  $('btnEndOk').addEventListener('click', () => { if (G.mode === 'offline') G.leaveToMenu(); else $('endBox').style.display = 'none'; });

  // tela cheia / sem rolagem
  document.addEventListener('contextmenu', (e) => e.preventDefault());
  document.addEventListener('visibilitychange', () => { if (document.hidden && G.mode === 'offline') G.setPause(true); });
  try { if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => {}); } catch (e) {}

  G.showScreen('menu'); G.boot();
})();
