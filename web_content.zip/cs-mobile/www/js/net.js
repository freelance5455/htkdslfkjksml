/* =====================================================================
   Pocket Strike - cliente multiplayer (www/js/net.js)
   Fala com server/server.js por WebSocket (JSON). Cuida de salas, lobby e
   repassa os eventos da partida para o núcleo (G.online.*).
   ===================================================================== */
(function () {
  'use strict';
  const G = window.G, $ = (id) => document.getElementById(id), MAPS = window.MAPS;
  const N = G.net = { active: false, ws: null, id: 0, room: null, host: 0, rtt: 0, players: {}, mapNames: [], inGame: false, board: [], score: [0, 0] };
  let pollT = 0, pingT = 0;

  function defaultUrl() {
    if (G.S.server) return G.S.server;
    if (window.Capacitor) return 'ws://192.168.0.10:3000/ws';   // dentro do APK: troque pelo IP/domínio do seu servidor
    if (location.protocol === 'http:' || location.protocol === 'https:') return (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws';
    return 'ws://192.168.0.10:3000/ws';
  }
  const send = (o) => { if (N.ws && N.ws.readyState === 1) N.ws.send(JSON.stringify(o)); };
  N.send = send;
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const status = (t, bad) => { const s = $('onStatus'); s.textContent = t; s.style.color = bad ? '#ff7a6a' : '#9fe29f'; };

  // ------------------------------------------------------------ conexão
  N.connect = function () {
    const url = $('onUrl').value.trim(); if (!url) return status('Digite o endereço do servidor', true);
    G.S.server = url; G.S.name = ($('onName').value.trim() || 'Jogador').slice(0, 16); G.saveSettings();
    if (N.ws) { try { N.ws.close(); } catch (e) {} }
    status('Conectando...');
    let ws; try { ws = new WebSocket(url); } catch (e) { return status('Endereço inválido', true); }
    N.ws = ws;
    ws.onopen = () => { N.active = true; send({ t: 'name', name: G.S.name }); };
    ws.onmessage = (e) => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } onMsg(m); };
    ws.onerror = () => status('Não foi possível conectar. Veja o endereço e se o servidor está ligado.', true);
    ws.onclose = () => {
      const was = N.active; N.active = false; N.room = null;
      if (G.mode === 'online' || N.inGame) { N.inGame = false; G.toast('Conexão perdida', 2500); G.leaveToMenu(); }
      else if (was) { G.showScreen('onConn'); status('Desconectado do servidor', true); }
    };
  };
  N.leave = function () { if (N.ws && N.ws.readyState === 1) send({ t: 'leave' }); N.room = null; N.inGame = false; };
  N.disconnect = function () { if (N.ws) { try { N.ws.close(); } catch (e) {} } N.active = false; };

  // envios da partida
  N.sendState = (c) => send({ t: 'st', x: +c.x.toFixed(2), y: +c.y.toFixed(2), z: +c.z.toFixed(2), yaw: +c.yaw.toFixed(3), pit: +c.pitch.toFixed(3), w: c.cur });
  N.sendFire = (w, d) => send({ t: 'fire', w: w, dx: +d.x.toFixed(4), dy: +d.y.toFixed(4), dz: +d.z.toFixed(4) });
  N.sendBomb = (d) => send({ t: 'bomb', dx: +d.x.toFixed(4), dy: +d.y.toFixed(4), dz: +d.z.toFixed(4) });
  N.sendHeal = () => send({ t: 'heal' });

  // ------------------------------------------------------------ mensagens
  function onMsg(m) {
    switch (m.t) {
      case 'welcome':
        N.id = m.id; N.mapNames = m.maps; fillMaps($('rmMap'), m.maps); status('Conectado!');
        G.showScreen('onRooms'); send({ t: 'list' }); break;
      case 'rooms': renderRooms(m.list); break;
      case 'joined': N.room = m.room; N.host = m.host; N.players = {}; m.players.forEach((p) => { N.players[p.id] = p; }); N.score = m.score || [0, 0];
        if (m.state === 'live') startGame(m.room.mapIdx, m.left, 25); else showLobby(); break;
      case 'pj': N.players[m.p.id] = m.p; if (N.inGame) { G.online.addPlayer(m.p); G.addFeed('<small>' + esc(m.p.name) + ' entrou</small>'); } else renderLobby(); break;
      case 'pl': { const p = N.players[m.id]; delete N.players[m.id]; if (N.inGame) { G.online.removePlayer(m.id); if (p) G.addFeed('<small>' + esc(p.name) + ' saiu</small>'); renderBoard(); } else renderLobby(); break; }
      case 'host': N.host = m.id; if (!N.inGame) renderLobby(); break;
      case 'team': if (N.players[m.id]) N.players[m.id].team = m.team; if (N.inGame) G.online.setTeam(m.id, m.team); else renderLobby(); break;
      case 'start': N.players = {}; m.players.forEach((p) => { N.players[p.id] = p; }); startGame(N.room.mapIdx, m.left, m.limit); break;
      case 'lobby': m.players.forEach((p) => { N.players[p.id] = p; }); N.inGame = false; G.toLobby(); showLobby(); break;
      case 'snap': if (G.mode === 'online') G.online.snap(m.p, m.left); break;
      case 'resp': if (G.mode === 'online') G.online.resp(m); break;
      case 'hit': if (G.mode === 'online') G.online.hit(m); break;
      case 'kill': if (G.mode === 'online') { G.online.kill(m); } break;
      case 'shot': if (G.mode === 'online') G.online.shot(m); break;
      case 'proj': if (G.mode === 'online') G.online.proj(m); break;
      case 'boom': if (G.mode === 'online') G.online.boom(m); break;
      case 'flash': if (G.mode === 'online') G.online.flash(m.ms); break;
      case 'fix': if (G.mode === 'online') G.online.fix(m); break;
      case 'healed': if (G.mode === 'online') G.online.healed(m.hp); break;
      case 'sb': N.board = m.board; N.score = m.score; renderBoard(); if (G.mode === 'online') G.online.score(m.score); break;
      case 'end': onEnd(m); break;
      case 'pong': N.rtt = Math.max(0, performance.now() - m.c); $('ping').textContent = Math.round(N.rtt) + ' ms'; break;
      case 'err': G.toast(m.m, 2500); status(m.m, true); break;
      case 'left': break;
    }
  }

  function startGame(mapIdx, left, limit) {
    N.inGame = true; const me = N.players[N.id]; if (!me) return;
    G.startOnline({ mapIdx: mapIdx, team: me.team, meId: N.id, players: Object.keys(N.players).map((k) => N.players[k]), limit: limit });
    if (me.alive) G.online.resp({ id: me.id, team: me.team, x: me.x, y: me.y, z: me.z, yaw: me.yaw, hp: me.hp });
    $('timer').textContent = Math.floor(left / 60) + ':' + ('0' + (left % 60)).slice(-2); G.online.score(N.score || [0, 0]);
    G.toast('Partida iniciada! Primeiro time a ' + limit + ' abates vence', 2500);
  }
  function onEnd(m) {
    N.board = m.board; N.score = m.score; renderBoard();
    const me = N.players[N.id], mine = me && m.winner === me.team;
    G.showEnd(m.winner < 0 ? 'EMPATE' : (mine ? 'VITÓRIA!' : 'DERROTA'), 'TR ' + m.score[0] + ' x ' + m.score[1] + ' CT — voltando para a sala...');
    $('sb').style.display = 'block';
  }

  // ------------------------------------------------------------ UI de salas
  function fillMaps(sel, names) { sel.innerHTML = ''; names.forEach((n, i) => { const o = document.createElement('option'); o.value = i; o.textContent = n; sel.appendChild(o); }); }
  function renderRooms(list) {
    const box = $('roomList'); box.innerHTML = '';
    if (!list.length) { box.innerHTML = '<div class="empty">Nenhuma sala ainda. Crie a primeira!</div>'; return; }
    list.forEach((r) => {
      const d = document.createElement('div'); d.className = 'room';
      d.innerHTML = '<div><b>' + esc(r.name) + '</b><small>' + esc(r.map) + ' • ' + (r.state === 'live' ? 'em jogo' : (r.state === 'end' ? 'terminando' : 'aguardando')) + '</small></div><span>' + r.players + '/' + r.max + '</span>';
      d.addEventListener('click', () => send({ t: 'join', id: r.id })); box.appendChild(d);
    });
  }
  function showLobby() { G.showScreen('onLobby'); renderLobby(); }
  function renderLobby() {
    if (!N.room) return; $('lobTitle').textContent = N.room.name + ' — ' + N.room.map;
    const T = [], C = []; Object.keys(N.players).forEach((k) => { const p = N.players[k]; (p.team === 0 ? T : C).push(p); });
    const li = (p) => '<li>' + esc(p.name) + (p.id === N.host ? ' <em>(host)</em>' : '') + (p.id === N.id ? ' <em>(você)</em>' : '') + '</li>';
    $('lobT').innerHTML = T.map(li).join('') || '<li class="empty">—</li>'; $('lobCT').innerHTML = C.map(li).join('') || '<li class="empty">—</li>';
    $('btnStart').style.display = N.host === N.id ? 'block' : 'none'; $('lobWait').style.display = N.host === N.id ? 'none' : 'block';
  }
  function renderBoard() {
    const rows = (N.board || []).slice().sort((a, b) => b.k - a.k || a.d - b.d);
    $('sbBody').innerHTML = '<tr><th></th><th>Jogador</th><th>K</th><th>D</th><th>Ping</th></tr>' + rows.map((p) => '<tr class="' + (p.id === N.id ? 'me' : '') + '"><td style="color:' + (p.team ? '#6aa0ff' : '#ff6a5a') + '">●</td><td>' + esc(p.name) + '</td><td>' + p.k + '</td><td>' + p.d + '</td><td>' + p.ping + '</td></tr>').join('');
    $('sbScore').textContent = 'TR ' + (N.score ? N.score[0] : 0) + '  x  ' + (N.score ? N.score[1] : 0) + ' CT';
  }

  // botões
  $('onUrl').value = defaultUrl(); $('onName').value = G.S.name === 'Jogador' ? '' : G.S.name;
  $('btnConnect').addEventListener('click', N.connect);
  $('btnRefresh').addEventListener('click', () => send({ t: 'list' }));
  $('btnCreate').addEventListener('click', () => send({ t: 'create', name: $('rmName').value, map: +$('rmMap').value, max: +$('rmMax').value }));
  $('btnTeam').addEventListener('click', () => { const me = N.players[N.id]; if (me) send({ t: 'team', team: 1 - me.team }); });
  $('btnStart').addEventListener('click', () => send({ t: 'start' }));
  $('btnLobLeave').addEventListener('click', () => { N.leave(); G.showScreen('onRooms'); send({ t: 'list' }); });
  $('btnRoomsBack').addEventListener('click', () => { N.disconnect(); G.showScreen('menu'); });
  $('btnConnBack').addEventListener('click', () => G.showScreen('menu'));
  G.openOnline = function () { if (N.active && N.ws && N.ws.readyState === 1) { G.showScreen('onRooms'); send({ t: 'list' }); } else G.showScreen('onConn'); };

  setInterval(() => {
    if (!N.active) return; pollT += 1; pingT += 1;
    if (pollT >= 3 && document.getElementById('onRooms').style.display === 'flex') { pollT = 0; send({ t: 'list' }); }
    if (pingT >= 2) { pingT = 0; send({ t: 'ping', c: performance.now(), r: Math.round(N.rtt) }); }
  }, 1000);
})();
