/* Código compartilhado entre o cliente (navegador/APK) e o servidor Node.
   Armas, colisão com o mapa, raios (tiro) e física do jogador. */
(function () {
  var CELL = 2;
  var WEAPONS = {
    revolver: { name: 'Revólver', cost: 0, dmg: 55, rate: 0.55, mag: 6, res: 36, reload: 1.8, spread: 0.004, auto: false, zoom: 60, range: 90 },
    smg: { name: 'Metralhadora', cost: 800, dmg: 18, rate: 0.075, mag: 35, res: 140, reload: 1.9, spread: 0.03, auto: true, zoom: 62, range: 70 },
    rifle: { name: 'Rifle', cost: 1500, dmg: 30, rate: 0.1, mag: 30, res: 90, reload: 2.3, spread: 0.012, auto: true, zoom: 55, range: 110 },
    sniper: { name: 'Sniper', cost: 2000, dmg: 110, rate: 1.3, mag: 5, res: 20, reload: 2.8, spread: 0, auto: false, zoom: 22, range: 160 },
    bazooka: { name: 'Bazuca', cost: 2500, dmg: 120, rate: 2.0, mag: 1, res: 4, reload: 3.0, spread: 0, auto: false, zoom: 60, range: 120, rocket: true, splash: 5 }
  };
  var WORDER = ['revolver', 'smg', 'rifle', 'sniper', 'bazooka'];
  var P = { eye: 1.6, radius: 0.35, height: 1.8, headY: 1.62, headR: 0.17, bodyH: 1.45, bodyR: 0.32, speed: 5.2, jump: 6.0, gravity: 15, hp: 100 };

  function cellH(m, i, j) {
    if (i < 0 || j < 0 || i >= m.w || j >= m.h) return 99;
    return m.g[j * m.w + i];
  }

  // Raio contra o mundo (grade 2D com altura). Retorna distância ou Infinity.
  function rayWorld(m, ox, oy, oz, dx, dy, dz, maxD) {
    var len = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1; dx /= len; dy /= len; dz /= len;
    var i = Math.floor(ox / CELL), j = Math.floor(oz / CELL);
    var sx = dx > 0 ? 1 : -1, sz = dz > 0 ? 1 : -1;
    var tdx = dx !== 0 ? Math.abs(CELL / dx) : Infinity, tdz = dz !== 0 ? Math.abs(CELL / dz) : Infinity;
    var nx = dx > 0 ? (i + 1) * CELL : i * CELL, nz = dz > 0 ? (j + 1) * CELL : j * CELL;
    var tmx = dx !== 0 ? (nx - ox) / dx : Infinity, tmz = dz !== 0 ? (nz - oz) / dz : Infinity;
    var t = 0, guard = 0;
    if (cellH(m, i, j) > oy) { /* começou dentro de sólido: ignora a célula inicial */ }
    while (t < maxD && guard++ < 400) {
      var tex = Math.min(tmx, tmz);
      if (tmx < tmz) { i += sx; t = tmx; tmx += tdx; } else { j += sz; t = tmz; tmz += tdz; }
      if (t > maxD) break;
      var h = cellH(m, i, j);
      if (h > 0) {
        var te = t, tx = Math.min(tmx, tmz);
        var y1 = oy + dy * te, y2 = oy + dy * tx;
        if (Math.min(y1, y2) < h && Math.max(y1, y2) > 0) return te;
      }
    }
    return Infinity;
  }

  // Raio contra um personagem (cabeça + corpo). Retorna {t, head} ou null.
  function rayChar(ox, oy, oz, dx, dy, dz, cx, cy, cz) {
    var best = null, t;
    // cabeça (esfera)
    var hx = cx - ox, hy = cy + P.headY - oy, hz = cz - oz;
    var b = hx * dx + hy * dy + hz * dz;
    if (b > 0) {
      var c = hx * hx + hy * hy + hz * hz - P.headR * P.headR, disc = b * b - c;
      if (disc >= 0) { t = b - Math.sqrt(disc); if (t >= 0) best = { t: t, head: true }; }
    }
    // corpo (cilindro vertical)
    var ex = ox - cx, ez = oz - cz, a = dx * dx + dz * dz;
    if (a > 1e-8) {
      var bb = ex * dx + ez * dz, cc = ex * ex + ez * ez - P.bodyR * P.bodyR, d2 = bb * bb - a * cc;
      if (d2 >= 0) {
        var sq = Math.sqrt(d2), t0 = (-bb - sq) / a;
        if (t0 >= 0) { var yy = oy + dy * t0; if (yy >= cy && yy <= cy + P.bodyH && (!best || t0 < best.t)) best = { t: t0, head: false }; }
      }
    }
    return best;
  }

  function cl(v, a, b) { return v < a ? a : (v > b ? b : v); }

  function collide(m, e) {
    var r = P.radius, i0 = Math.floor((e.x - r) / CELL), i1 = Math.floor((e.x + r) / CELL), j0 = Math.floor((e.z - r) / CELL), j1 = Math.floor((e.z + r) / CELL);
    for (var j = j0; j <= j1; j++) for (var i = i0; i <= i1; i++) {
      var h = cellH(m, i, j); if (h <= e.y + 0.2) continue;
      var x0 = i * CELL, x1 = x0 + CELL, z0 = j * CELL, z1 = z0 + CELL;
      var qx = cl(e.x, x0, x1), qz = cl(e.z, z0, z1), dx = e.x - qx, dz = e.z - qz, d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 1e-8) { var d = Math.sqrt(d2), p = r - d; e.x += dx / d * p; e.z += dz / d * p; }
        else {
          var l = e.x - x0, rr = x1 - e.x, u = e.z - z0, dn = z1 - e.z, mn = Math.min(l, rr, u, dn);
          if (mn === l) e.x = x0 - r; else if (mn === rr) e.x = x1 + r; else if (mn === u) e.z = z0 - r; else e.z = z1 + r;
        }
      }
    }
  }

  // Move uma entidade {x,y,z,vy,on}. wx,wz = velocidade desejada (m/s)
  function step(m, e, wx, wz, dt) {
    e.x += wx * dt; e.z += wz * dt; collide(m, e);
    e.vy -= P.gravity * dt; e.y += e.vy * dt;
    var h = cellH(m, Math.floor(e.x / CELL), Math.floor(e.z / CELL));
    var g = h <= e.y + 0.2 ? h : 0;
    if (e.y <= g) { e.y = g; e.vy = 0; e.on = true; } else e.on = false;
  }

  function spawnPoint(m, team) {
    var r = team === 0 ? m.T : m.CT;
    var a = Math.random(), b = Math.random();
    return { x: (r[0] + Math.floor(a * (r[2] - r[0] + 1))) * CELL + 1, z: (r[1] + Math.floor(b * (r[3] - r[1] + 1))) * CELL + 1, y: 0 };
  }

  var API = { CELL: CELL, WEAPONS: WEAPONS, WORDER: WORDER, P: P, cellH: cellH, rayWorld: rayWorld, rayChar: rayChar, collide: collide, step: step, spawnPoint: spawnPoint };
  if (typeof module !== 'undefined' && module.exports) module.exports = API; else window.SH = API;
})();
