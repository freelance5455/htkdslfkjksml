/* =====================================================================
   Pocket Strike - núcleo do jogo (www/js/game.js)
   Modo offline com bots + ganchos (G.online / G.net) usados pelo multiplayer (net.js)
   ===================================================================== */
(function () {
  'use strict';
  const THREE = window.THREE, SH = window.SH, MAPS = window.MAPS, MODELS = window.MODELS;
  const W = SH.WEAPONS, P = SH.P, CELL = SH.CELL, WORDER = SH.WORDER;
  const G = window.G = { mode: 'menu', chars: [], me: null, map: null, net: null, S: null };
  const $ = (id) => document.getElementById(id);
  const rnd = (a, b) => a + Math.random() * (b - a);
  const clamp = (v, a, b) => v < a ? a : (v > b ? b : v);
  const angDiff = (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; };
  const TEAMCOL = [0xff3030, 0x3a7bff], TEAMNAME = ['TR', 'CT'];

  // ------------------------------------------------------------ configurações
  const S = G.S = { q: 0.8, sens: 1, fps: 60, sound: 1, diff: 1, name: 'Jogador', server: '' };
  try { Object.assign(S, JSON.parse(localStorage.getItem('ps_settings') || '{}')); } catch (e) {}
  G.saveSettings = () => { try { localStorage.setItem('ps_settings', JSON.stringify(S)); } catch (e) {} };

  // ------------------------------------------------------------ áudio (sintetizado, sem arquivos)
  let AC = null, noiseBuf = null;
  function audio() {
    if (!S.sound) return null;
    if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); const n = AC.sampleRate * 0.5; noiseBuf = AC.createBuffer(1, n, AC.sampleRate); const d = noiseBuf.getChannelData(0); for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1; } catch (e) { return null; } }
    if (AC.state === 'suspended') AC.resume();
    return AC;
  }
  function tone(f0, f1, dur, type, vol) {
    const a = audio(); if (!a) return; const o = a.createOscillator(), g = a.createGain(), t = a.currentTime;
    o.type = type || 'square'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol || 0.1, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, vol, lp) {
    const a = audio(); if (!a) return; const s = a.createBufferSource(), g = a.createGain(), f = a.createBiquadFilter(), t = a.currentTime;
    s.buffer = noiseBuf; f.type = 'lowpass'; f.frequency.value = lp || 2000; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(a.destination); s.start(t); s.stop(t + dur);
  }
  const SND = {
    shot: (k) => { if (k === 'bazooka') { noise(0.4, 0.5, 700); tone(120, 40, 0.3, 'sawtooth', 0.15); } else if (k === 'sniper') { noise(0.35, 0.5, 3000); tone(300, 60, 0.2, 'square', 0.12); } else if (k === 'revolver') { noise(0.2, 0.4, 2500); tone(220, 70, 0.12, 'square', 0.1); } else { noise(0.09, 0.3, 3500); tone(260, 90, 0.06, 'square', 0.06); } },
    reload: () => { tone(700, 500, 0.05, 'square', 0.05); setTimeout(() => tone(500, 800, 0.05, 'square', 0.05), 450); },
    hit: () => tone(1500, 900, 0.06, 'sine', 0.12),
    hurt: () => { noise(0.12, 0.3, 600); tone(150, 80, 0.1, 'sawtooth', 0.08); },
    boom: () => { noise(0.7, 0.7, 500); tone(90, 25, 0.5, 'sawtooth', 0.2); },
    pop: () => { tone(500, 1400, 0.18, 'sine', 0.18); noise(0.15, 0.25, 6000); },
    ring: () => tone(3200, 3000, 0.9, 'sine', 0.05),
    ability: () => tone(400, 1200, 0.2, 'triangle', 0.12),
    click: () => tone(900, 700, 0.03, 'square', 0.04)
  };
  G.snd = SND;

  // ------------------------------------------------------------ renderer
  const canvas = $('gl');
  const renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: false, powerPreference: 'low-power', alpha: false, stencil: false });
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(75, 1, 0.08, 120); camera.rotation.order = 'YXZ'; scene.add(camera);
  let qScale = S.q;
  function resize() {
    const w = window.innerWidth, h = window.innerHeight;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5) * qScale); renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize); resize();
  G.applyQuality = () => { qScale = S.q; resize(); };

  // ------------------------------------------------------------ mapa
  let mapMesh = null, mapIdx = 0, miniBase = null;
  function buildMapMesh(m) {
    const pos = [], col = [], g = m.g, w = m.w, h = m.h, pal = m.pal;
    const H = (i, j) => (i < 0 || j < 0 || i >= w || j >= h) ? 5 : g[j * w + i];
    function quad(a, b, c, d, r, gg, bb, sh, sh2) {   // sh = brilho em baixo, sh2 = em cima
      const v = [a, b, c, a, c, d], s = [sh, sh, sh2, sh, sh2, sh2];
      for (let k = 0; k < 6; k++) { pos.push(v[k][0], v[k][1], v[k][2]); col.push(r * s[k], gg * s[k], bb * s[k]); }
    }
    const inSite = (r, i, j) => r && i >= r[0] && i <= r[2] && j >= r[1] && j <= r[3];
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const hh = g[j * w + i], x0 = i * CELL, x1 = x0 + CELL, z0 = j * CELL, z1 = z0 + CELL;
      if (hh === 0) {
        let c = pal.floor, k = ((i + j) & 1) ? 1 : 0.93;
        if (inSite(m.site.a, i, j)) c = pal.siteA; else if (inSite(m.site.b, i, j)) c = pal.siteB;
        quad([x0, 0, z0], [x0, 0, z1], [x1, 0, z1], [x1, 0, z0], c[0] * k, c[1] * k, c[2] * k, 1, 1);
        continue;
      }
      const c = hh >= 5 ? pal.wall : pal.crate, v = 0.94 + ((i * 7 + j * 13) % 5) * 0.015;
      let interior = true;
      for (let dj = -1; dj <= 1; dj++) for (let di = -1; di <= 1; di++) if (H(i + di, j + dj) < hh) interior = false;
      if (!interior) quad([x0, hh, z0], [x0, hh, z1], [x1, hh, z1], [x1, hh, z0], c[0] * 1.05 * v, c[1] * 1.05 * v, c[2] * 1.05 * v, 1, 1);
      if (H(i, j - 1) < hh) quad([x1, H(i, j - 1), z0], [x0, H(i, j - 1), z0], [x0, hh, z0], [x1, hh, z0], c[0] * 0.8 * v, c[1] * 0.8 * v, c[2] * 0.8 * v, 0.7, 1);
      if (H(i, j + 1) < hh) quad([x0, H(i, j + 1), z1], [x1, H(i, j + 1), z1], [x1, hh, z1], [x0, hh, z1], c[0] * 0.62 * v, c[1] * 0.62 * v, c[2] * 0.62 * v, 0.7, 1);
      if (H(i - 1, j) < hh) quad([x0, H(i - 1, j), z0], [x0, H(i - 1, j), z1], [x0, hh, z1], [x0, hh, z0], c[0] * 0.72 * v, c[1] * 0.72 * v, c[2] * 0.72 * v, 0.7, 1);
      if (H(i + 1, j) < hh) quad([x1, H(i + 1, j), z1], [x1, H(i + 1, j), z0], [x1, hh, z0], [x1, hh, z1], c[0] * 0.9 * v, c[1] * 0.9 * v, c[2] * 0.9 * v, 0.7, 1);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); geo.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
    return new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ vertexColors: true }));
  }
  function loadMap(idx) {
    if (mapMesh) { scene.remove(mapMesh); mapMesh.geometry.dispose(); }
    mapIdx = idx; const m = G.map = MAPS.build(idx);
    mapMesh = buildMapMesh(m); scene.add(mapMesh);
    scene.background = new THREE.Color(m.pal.sky); scene.fog = new THREE.Fog(m.pal.sky, 35, 95);
    // minimapa base
    miniBase = document.createElement('canvas'); miniBase.width = m.w * 3; miniBase.height = m.h * 3; const x = miniBase.getContext('2d');
    for (let j = 0; j < m.h; j++) for (let i = 0; i < m.w; i++) { const h = m.g[j * m.w + i]; x.fillStyle = h === 0 ? '#3a3f46' : (h >= 5 ? '#c9ccd2' : '#a07a3c'); x.fillRect(i * 3, j * 3, 3, 3); }
  }

  // ------------------------------------------------------------ modelos (personagem e peixe)
  function b64(s) { const b = atob(s), n = b.length, u = new Uint8Array(n); for (let i = 0; i < n; i++) u[i] = b.charCodeAt(i); return u.buffer; }
  const CM = MODELS.char;
  const cPos = new Float32Array(CM.n * 3), cUv = new Float32Array(CM.n * 2), cPart = new Float32Array(CM.n);
  { const p = new Int16Array(b64(CM.p)), u = new Uint16Array(b64(CM.u)), t = new Uint8Array(b64(CM.t));
    for (let i = 0; i < p.length; i++) cPos[i] = p[i] / 10000; for (let i = 0; i < u.length; i++) cUv[i] = u[i] / 65535; for (let i = 0; i < t.length; i++) cPart[i] = t[i]; }
  const charGeo = new THREE.BufferGeometry();
  charGeo.setAttribute('position', new THREE.BufferAttribute(cPos, 3)); charGeo.setAttribute('uv', new THREE.BufferAttribute(cUv, 2)); charGeo.setAttribute('part', new THREE.BufferAttribute(cPart, 1));
  // contorno: cópia expandida ao longo das normais suavizadas
  const hullGeo = (function () {
    const acc = new Map(), key = (x, y, z) => Math.round(x * 400) + ',' + Math.round(y * 400) + ',' + Math.round(z * 400);
    for (let f = 0; f < CM.n; f += 3) {
      const a = f * 3, ux = cPos[a + 3] - cPos[a], uy = cPos[a + 4] - cPos[a + 1], uz = cPos[a + 5] - cPos[a + 2], vx = cPos[a + 6] - cPos[a], vy = cPos[a + 7] - cPos[a + 1], vz = cPos[a + 8] - cPos[a + 2];
      const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
      for (let k = 0; k < 3; k++) { const kk = key(cPos[a + k * 3], cPos[a + k * 3 + 1], cPos[a + k * 3 + 2]); const o = acc.get(kk) || [0, 0, 0]; o[0] += nx; o[1] += ny; o[2] += nz; acc.set(kk, o); }
    }
    const hp = new Float32Array(cPos.length);
    for (let i = 0; i < CM.n; i++) { const o = acc.get(key(cPos[i * 3], cPos[i * 3 + 1], cPos[i * 3 + 2])), l = Math.hypot(o[0], o[1], o[2]) || 1; hp[i * 3] = cPos[i * 3] + o[0] / l * 0.022; hp[i * 3 + 1] = cPos[i * 3 + 1] + o[1] / l * 0.022; hp[i * 3 + 2] = cPos[i * 3 + 2] + o[2] / l * 0.022; }
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(hp, 3)); g.setAttribute('part', new THREE.BufferAttribute(cPart, 1)); return g;
  })();
  const charTex = new THREE.TextureLoader().load('assets/char.jpg');
  const fishGeo = (function () {
    const F = MODELS.fish, p = new Int16Array(b64(F.p)), c = new Uint8Array(b64(F.c)), pf = new Float32Array(p.length), cf = new Float32Array(c.length);
    for (let i = 0; i < p.length; i++) pf[i] = p[i] / 10000; for (let i = 0; i < c.length; i++) cf[i] = c[i] / 255;
    const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(pf, 3)); g.setAttribute('color', new THREE.BufferAttribute(cf, 3)); return g;
  })();
  // animação de pernas/braços no vertex shader (1 draw call por personagem)
  function swing(mat, sw) {
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uSw = { value: sw };
      sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nattribute float part;\nuniform vec4 uSw;')
        .replace('#include <begin_vertex>', '#include <begin_vertex>\n{float a=part<0.5?0.0:(part<1.5?uSw.x:(part<2.5?uSw.y:(part<3.5?uSw.z:uSw.w)));float py=part<2.5?0.78:1.22;float c=cos(a),s=sin(a);float yy=transformed.y-py;float zz=transformed.z;transformed.y=py+yy*c-zz*s;transformed.z=yy*s+zz*c;}');
    };
  }
  const WCOL = { revolver: 0xc0c4cc, smg: 0x3e5a3e, rifle: 0x4a4038, sniper: 0x1c1c22, bazooka: 0x5c6b34 };
  const gunMats = {}; WORDER.forEach((k) => gunMats[k] = new THREE.MeshBasicMaterial({ color: WCOL[k] }));
  const boxGeo = new THREE.BoxGeometry(1, 1, 1);
  const shadowGeo = new THREE.CircleGeometry(0.5, 10).rotateX(-Math.PI / 2), shadowMat = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.3, depthWrite: false });
  const GLEN = { revolver: 0.28, smg: 0.45, rifle: 0.7, sniper: 0.95, bazooka: 0.9 };

  function makeVisual(team) {
    const sw = new THREE.Vector4(0, 0, 0, 0), grp = new THREE.Group();
    const bm = new THREE.MeshBasicMaterial({ map: charTex }); swing(bm, sw);
    const hm = new THREE.MeshBasicMaterial({ color: TEAMCOL[team], side: THREE.BackSide }); swing(hm, sw);
    const xm = new THREE.MeshBasicMaterial({ color: TEAMCOL[team], transparent: true, opacity: 0.6, depthWrite: false, depthFunc: THREE.GreaterDepth, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }); swing(xm, sw);
    const body = new THREE.Mesh(charGeo, bm), hull = new THREE.Mesh(hullGeo, hm), xray = new THREE.Mesh(charGeo, xm), gun = new THREE.Mesh(boxGeo, gunMats.revolver), sh = new THREE.Mesh(shadowGeo, shadowMat);
    body.frustumCulled = hull.frustumCulled = xray.frustumCulled = false; xray.renderOrder = 5; xray.visible = false;
    const inner = new THREE.Group(); inner.add(body, hull, xray, gun); grp.add(inner, sh); sh.position.y = 0.03;
    gun.position.set(-0.2, 0.98, -0.3); gun.scale.set(0.07, 0.1, 0.45);
    // o modelo olha para +Z; o grupo é girado em yaw+PI
    scene.add(grp);
    return { grp, inner, body, hull, xray, gun, shadow: sh, sw, mats: [bm, hm, xm] };
  }
  function setVisualTeam(v, team) { v.mats[1].color.setHex(TEAMCOL[team]); v.mats[2].color.setHex(TEAMCOL[team]); }

  // ------------------------------------------------------------ personagens
  let uid = 1;
  function newChar(team, opts) {
    const c = Object.assign({ id: uid++, team: team, x: 0, y: 0, z: 0, vy: 0, on: true, yaw: 0, pitch: 0, hp: 100, alive: false, name: 'Bot', cur: 'revolver', prim: 'revolver',
      ammo: {}, fireT: 0, reloadT: 0, flashT: 0, kills: 0, deaths: 0, bombs: 2, inv: 0, walk: 0, spd: 0, deadT: 0, ai: null, isBot: false, isPlayer: false, isRemote: false, tx: 0, ty: 0, tz: 0, tyaw: 0, tpit: 0 }, opts || {});
    c.vis = makeVisual(team); giveAmmo(c, 'revolver'); setWeapon(c, 'revolver'); G.chars.push(c); return c;
  }
  function removeChar(c) { scene.remove(c.vis.grp); c.vis.mats.forEach((m) => m.dispose()); const i = G.chars.indexOf(c); if (i >= 0) G.chars.splice(i, 1); }
  function clearChars() { while (G.chars.length) removeChar(G.chars[0]); G.me = null; }
  function giveAmmo(c, k) { c.ammo[k] = { mag: W[k].mag, res: W[k].res }; }
  function setWeapon(c, k) {
    c.cur = k; c.reloadT = 0; c.vis.gun.material = gunMats[k]; c.vis.gun.scale.set(0.07, 0.1, GLEN[k]); c.vis.gun.position.z = -0.12 - GLEN[k] * 0.5 + 0.12;
    if (c.isPlayer) { buildVM(k); hudWeapon(); }
  }
  function spawnChar(c, x, z, yaw) {
    c.x = x; c.z = z; c.y = 0; c.vy = 0; c.yaw = yaw || 0; c.pitch = 0; c.hp = P.hp; c.alive = true; c.flashT = 0; c.deadT = 0; c.bombs = 2; c.fireT = 0; c.reloadT = 0; c.inv = performance.now() + 1500;
    c.tx = x; c.ty = 0; c.tz = z; c.tyaw = c.yaw; c.vis.grp.visible = !c.isPlayer; c.vis.inner.rotation.x = 0; c.vis.inner.position.y = 0; c.vis.hull.visible = true;
  }

  // ------------------------------------------------------------ viewmodel (arma em primeira pessoa)
  const vm = new THREE.Group(); camera.add(vm); vm.position.set(0.2, -0.2, -0.42);
  const vmParts = {};
  function bx(parent, w, h, d, x, y, z, color) { const m = new THREE.Mesh(boxGeo, new THREE.MeshBasicMaterial({ color: color })); m.scale.set(w, h, d); m.position.set(x, y, z); parent.add(m); return m; }
  function buildAllVM() {
    const skin = 0x8a5a38, hood = 0x4a3020;
    WORDER.forEach((k) => {
      const g = new THREE.Group(); g.visible = false; vm.add(g); vmParts[k] = g; const c = WCOL[k];
      bx(g, 0.12, 0.13, 0.32, 0.06, -0.12, 0.28, hood); bx(g, 0.07, 0.07, 0.1, 0.0, -0.06, 0.02, skin);
      if (k === 'revolver') { bx(g, 0.05, 0.07, 0.22, 0, 0, -0.06, c); bx(g, 0.06, 0.1, 0.06, 0, -0.07, 0.04, 0x3a2a1a); bx(g, 0.07, 0.07, 0.07, 0, 0, 0.04, 0x8a8f99); }
      else if (k === 'smg') { bx(g, 0.07, 0.1, 0.34, 0, 0, -0.08, c); bx(g, 0.05, 0.14, 0.06, 0, -0.1, -0.02, 0x222222); bx(g, 0.03, 0.03, 0.12, 0, 0.01, -0.3, 0x111111); }
      else if (k === 'rifle') { bx(g, 0.07, 0.1, 0.5, 0, 0, -0.14, c); bx(g, 0.05, 0.12, 0.06, 0, -0.1, -0.06, 0x222222); bx(g, 0.03, 0.03, 0.2, 0, 0.01, -0.5, 0x111111); bx(g, 0.05, 0.05, 0.14, 0, 0.08, -0.12, 0x111111); }
      else if (k === 'sniper') { bx(g, 0.06, 0.09, 0.7, 0, 0, -0.2, c); bx(g, 0.04, 0.04, 0.3, 0, 0.0, -0.7, 0x111111); bx(g, 0.05, 0.06, 0.22, 0, 0.09, -0.15, 0x22262e); bx(g, 0.05, 0.12, 0.12, 0, -0.04, 0.12, 0x2a2a30); }
      else { bx(g, 0.14, 0.14, 0.8, 0.0, 0.04, -0.2, c); bx(g, 0.17, 0.17, 0.08, 0, 0.04, -0.62, 0x2d3516); bx(g, 0.05, 0.1, 0.06, 0, -0.07, -0.02, 0x222222); }
      vmParts[k].flash = bx(g, 0.1, 0.1, 0.1, 0, 0.0, -0.35 - (GLEN[k] || 0.4) * 0.5, 0xffd060); vmParts[k].flash.visible = false;
    });
  }
  buildAllVM();
  let vmKick = 0, flashShow = 0;
  function buildVM(k) { for (const n in vmParts) vmParts[n].visible = (n === k); }

  // ------------------------------------------------------------ efeitos (pools)
  const fx = [];
  const trMat = new THREE.MeshBasicMaterial({ color: 0xffe9a0 });
  function mkPool(n, f) { const a = []; for (let i = 0; i < n; i++) { const o = f(); o.visible = false; scene.add(o); a.push(o); } return a; }
  const trPool = mkPool(14, () => new THREE.Mesh(boxGeo, trMat));
  const spPool = mkPool(16, () => new THREE.Mesh(boxGeo, new THREE.MeshBasicMaterial({ color: 0xffc070 })));
  const sphGeo = new THREE.IcosahedronGeometry(1, 1);
  const exPool = mkPool(6, () => new THREE.Mesh(sphGeo, new THREE.MeshBasicMaterial({ color: 0xff8a20, transparent: true, opacity: 0.8, depthWrite: false })));
  const buPool = mkPool(6, () => new THREE.Mesh(sphGeo, new THREE.MeshBasicMaterial({ color: 0xcfeaff, transparent: true, opacity: 0.7, depthWrite: false })));
  const pick = (pool) => { for (let i = 0; i < pool.length; i++) if (!pool[i].visible) return pool[i]; return pool[0]; };
  function tracer(ox, oy, oz, ex, ey, ez) {
    const t = pick(trPool), dx = ex - ox, dy = ey - oy, dz = ez - oz, l = Math.hypot(dx, dy, dz); if (l < 0.5) return;
    t.visible = true; t.position.set((ox + ex) / 2, (oy + ey) / 2, (oz + ez) / 2); t.lookAt(ex, ey, ez); t.scale.set(0.025, 0.025, l); fx.push({ o: t, t: 0, life: 0.06, k: 'hide' });
  }
  function spark(x, y, z) { const s = pick(spPool); s.visible = true; s.position.set(x, y, z); s.scale.setScalar(0.1); fx.push({ o: s, t: 0, life: 0.18, k: 'spark' }); }
  function explosion(x, y, z, kind) {
    const e = pick(kind === 'bomb' ? buPool : exPool); e.visible = true; e.position.set(x, y, z); e.scale.setScalar(0.2); e.material.opacity = 0.8;
    fx.push({ o: e, t: 0, life: kind === 'bomb' ? 0.45 : 0.5, k: kind === 'bomb' ? 'bubble' : 'boom' });
    if (kind === 'bomb') SND.pop(); else SND.boom();
  }
  function updateFx(dt) {
    for (let i = fx.length - 1; i >= 0; i--) {
      const f = fx[i]; f.t += dt; const u = f.t / f.life;
      if (f.k === 'spark') f.o.scale.setScalar(0.1 + u * 0.2); else if (f.k === 'boom') { f.o.scale.setScalar(0.5 + u * 5); f.o.material.opacity = 0.8 * (1 - u); } else if (f.k === 'bubble') { f.o.scale.setScalar(0.4 + u * 3.2); f.o.material.opacity = 0.7 * (1 - u * u); }
      if (u >= 1) { f.o.visible = false; fx.splice(i, 1); }
    }
  }

  // ------------------------------------------------------------ projéteis (bazuca e bomba de sabão)
  const projs = [];
  const fishMat = new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide }), rocketMat = new THREE.MeshBasicMaterial({ color: 0xff7a1a });
  function addProj(kind, x, y, z, vx, vy, vz, owner, id) {
    const mesh = kind === 'bomb' ? new THREE.Mesh(fishGeo, fishMat) : new THREE.Mesh(boxGeo, rocketMat);
    if (kind === 'rocket') mesh.scale.set(0.14, 0.14, 0.6); mesh.frustumCulled = false; scene.add(mesh);
    const p = { kind, x, y, z, vx, vy, vz, owner, id: id || 0, born: performance.now(), mesh, spin: rnd(6, 10) }; projs.push(p); return p;
  }
  function removeProj(p) { scene.remove(p.mesh); const i = projs.indexOf(p); if (i >= 0) projs.splice(i, 1); }
  function stepProj(p, dt) {
    const m = G.map;
    if (p.kind === 'rocket') {
      p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt; p.mesh.position.set(p.x, p.y, p.z); p.mesh.lookAt(p.x + p.vx, p.y + p.vy, p.z + p.vz);
      if (p.y < 0 || SH.cellH(m, Math.floor(p.x / CELL), Math.floor(p.z / CELL)) > p.y) return true;
      if (G.mode === 'offline') for (const c of G.chars) if (c.alive && c.team !== p.owner.team && Math.hypot(c.x - p.x, c.y + 0.9 - p.y, c.z - p.z) < 0.7) return true;
      return performance.now() - p.born > 4000;
    }
    p.vy -= 16 * dt; let nx = p.x + p.vx * dt, ny = p.y + p.vy * dt, nz = p.z + p.vz * dt;
    if (SH.cellH(m, Math.floor(nx / CELL), Math.floor(p.z / CELL)) > ny) { p.vx *= -0.5; nx = p.x; }
    if (SH.cellH(m, Math.floor(p.x / CELL), Math.floor(nz / CELL)) > ny) { p.vz *= -0.5; nz = p.z; }
    if (ny < 0.15) { ny = 0.15; p.vy = Math.abs(p.vy) * 0.45; p.vx *= 0.7; p.vz *= 0.7; }
    p.x = nx; p.y = ny; p.z = nz; p.mesh.position.set(p.x, p.y, p.z); p.mesh.rotation.y += p.spin * dt; p.mesh.rotation.z += p.spin * 0.6 * dt;
    return performance.now() - p.born > 1400;
  }
  function updateProjs(dt) {
    for (let i = projs.length - 1; i >= 0; i--) {
      const p = projs[i], done = stepProj(p, dt);
      if (G.mode === 'online') { if (performance.now() - p.born > 5000) removeProj(p); continue; }   // online: o servidor decide a explosão
      if (done) { removeProj(p); explodeLocal(p); }
    }
  }
  function explodeLocal(p) {
    explosion(p.x, p.y, p.z, p.kind);
    const owner = p.owner;
    if (p.kind === 'rocket') {
      const R = W.bazooka.splash;
      for (const c of G.chars) { if (!c.alive || (c.team === owner.team && c !== owner)) continue; const d = Math.hypot(c.x - p.x, c.y + 0.9 - p.y, c.z - p.z); if (d > R) continue; damage(c, owner, W.bazooka.dmg * (1 - d / R) * (c === owner ? 0.5 : 1) * dmgMul(owner), false, 'bazooka'); }
    } else {
      for (const c of G.chars) {
        if (!c.alive || c.team === owner.team) continue;
        const ex = p.x - c.x, ey = p.y - (c.y + P.eye), ez = p.z - c.z, d = Math.hypot(ex, ey, ez); if (d > 14 || d < 0.01) continue;
        if (SH.rayWorld(G.map, c.x, c.y + P.eye, c.z, ex, ey, ez, d - 0.1) < d - 0.2) continue;
        const fx_ = -Math.sin(c.yaw) * Math.cos(c.pitch), fy = Math.sin(c.pitch), fz = -Math.cos(c.yaw) * Math.cos(c.pitch);
        if ((fx_ * ex + fy * ey + fz * ez) / d < -0.3) continue;
        if (c.isPlayer) G.flash(1000); else c.flashT = 1.0;
      }
    }
  }
  const dmgMul = (c) => c.isBot ? [0.55, 0.75, 1][S.diff] : 1;

  // flash branco da bomba de sabão: tela clara por 1 segundo
  let flashT = 0, flashDur = 1;
  G.flash = (ms) => { flashT = flashDur = ms / 1000; SND.ring(); };

  // ------------------------------------------------------------ combate
  const feed = $('feed');
  function addFeed(html) { const d = document.createElement('div'); d.innerHTML = html; feed.appendChild(d); setTimeout(() => { if (d.parentNode) d.parentNode.removeChild(d); }, 4500); while (feed.children.length > 5) feed.removeChild(feed.firstChild); }
  G.addFeed = addFeed;
  const nameHtml = (c) => '<b style="color:' + (c.team ? '#6aa0ff' : '#ff6a5a') + '">' + (c.name || '?') + '</b>';
  function toast(t, ms) { const m = $('msg'); m.textContent = t; m.style.opacity = 1; clearTimeout(toast.t); toast.t = setTimeout(() => { m.style.opacity = 0; }, ms || 1800); }
  G.toast = toast;

  function dirWithSpread(c, spread) {
    const cp = Math.cos(c.pitch), fx_ = -Math.sin(c.yaw) * cp, fy = Math.sin(c.pitch), fz = -Math.cos(c.yaw) * cp;
    const rx = Math.cos(c.yaw), rz = -Math.sin(c.yaw), ux = Math.sin(c.yaw) * Math.sin(c.pitch), uy = cp, uz = Math.cos(c.yaw) * Math.sin(c.pitch);
    const a = (Math.random() * 2 - 1) * spread, b = (Math.random() * 2 - 1) * spread;
    const dx = fx_ + rx * a + ux * b, dy = fy + uy * b, dz = fz + rz * a + uz * b, l = Math.hypot(dx, dy, dz);
    return { x: dx / l, y: dy / l, z: dz / l };
  }
  function alertBots(shooter) {
    if (G.mode !== 'offline') return;
    for (const b of G.chars) if (b.isBot && b.alive && b.team !== shooter.team && !(b.ai.tgt && b.ai.vis) && Math.hypot(b.x - shooter.x, b.z - shooter.z) < 32) b.ai.alert = { x: shooter.x + rnd(-3, 3), z: shooter.z + rnd(-3, 3), t: 6 };
  }
  // tiro hitscan offline
  function hitscan(shooter, ox, oy, oz, d, w, wname) {
    const wd = SH.rayWorld(G.map, ox, oy, oz, d.x, d.y, d.z, w.range); let best = null, bt = Math.min(wd, w.range);
    for (const c of G.chars) { if (c === shooter || !c.alive || c.team === shooter.team || c.isRemote) continue; const h = SH.rayChar(ox, oy, oz, d.x, d.y, d.z, c.x, c.y, c.z); if (h && h.t < bt) { bt = h.t; best = { c: c, head: h.head }; } }
    const ex = ox + d.x * bt, ey = oy + d.y * bt, ez = oz + d.z * bt;
    if (!(shooter.isPlayer && w.range > 0 && false)) tracer(ox + d.x * 0.6, oy + d.y * 0.6 - (shooter.isPlayer ? 0.12 : 0), oz + d.z * 0.6, ex, ey, ez);
    if (best) { if (shooter.isPlayer) { hitMarker(best.head); } damage(best.c, shooter, w.dmg * (best.head ? 2.5 : 1) * dmgMul(shooter), best.head, wname); } else if (bt < w.range) spark(ex - d.x * 0.05, ey - d.y * 0.05, ez - d.z * 0.05);
  }
  function fire(c, dirOverride) {
    const k = c.cur, w = W[k], am = c.ammo[k];
    if (!c.alive || c.fireT > 0 || c.reloadT > 0) return false;
    if (am.mag <= 0) { reload(c); return false; }
    am.mag--; c.fireT = w.rate;
    const moving = c.spd > 1 || !c.on, sp = w.spread + (moving ? (k === 'sniper' ? 0.06 : 0.012) : 0) + (c.isPlayer && aiming && k !== 'sniper' ? -w.spread * 0.4 : 0) + (k === 'sniper' && c.isPlayer && aiming ? 0 : 0);
    const d = dirOverride || dirWithSpread(c, Math.max(0, sp)), ox = c.x, oy = c.y + P.eye, oz = c.z;
    SND.shot(k);
    if (c.isPlayer) { vmKick = k === 'bazooka' ? 0.18 : (k === 'sniper' ? 0.14 : 0.06); flashShow = 0.05; c.pitch += k === 'sniper' ? 0.035 : (k === 'bazooka' ? 0.05 : 0.008 + Math.random() * 0.006); c.yaw += rnd(-0.004, 0.004); }
    if (G.mode === 'online' && c.isPlayer) {   // servidor valida tiro e dano
      if (w.rocket) { /* projétil vem do servidor */ } else tracer(ox + d.x * 0.6, oy + d.y * 0.6 - 0.12, oz + d.z * 0.6, ox + d.x * 40, oy + d.y * 40, oz + d.z * 40);
      G.net.sendFire(k, d); if (am.mag <= 0 && am.res > 0) setTimeout(() => reload(c), 300); return true;
    }
    if (w.rocket) { const p = addProj('rocket', ox + d.x * 0.8, oy + d.y * 0.8 - 0.1, oz + d.z * 0.8, d.x * 28, d.y * 28, d.z * 28, c); p.owner = c; }
    else hitscan(c, ox, oy, oz, d, w, k);
    alertBots(c);
    if (am.mag <= 0 && am.res > 0 && c.isPlayer) setTimeout(() => reload(c), 300);
    return true;
  }
  function reload(c) {
    const am = c.ammo[c.cur], w = W[c.cur]; if (c.reloadT > 0 || am.mag >= w.mag || am.res <= 0 || !c.alive) return;
    c.reloadT = w.reload; if (c.isPlayer) { SND.reload(); toast('Recarregando...', 700); }
  }
  function finishReload(c) { const am = c.ammo[c.cur], w = W[c.cur], n = Math.min(w.mag - am.mag, am.res); am.mag += n; am.res -= n; }
  function throwBomb(c, dirOverride) {
    if (!c.alive || c.bombs <= 0) return false;
    if (G.mode === 'online' && c.isPlayer) { const d = dirWithSpread(c, 0); c.bombs--; G.net.sendBomb(d); SND.click(); hudBomb(); return true; }
    c.bombs--; const d = dirOverride || dirWithSpread(c, 0);
    addProj('bomb', c.x + d.x * 0.5, c.y + P.eye + d.y * 0.5, c.z + d.z * 0.5, d.x * 14, d.y * 14 + 3, d.z * 14, c); SND.click(); if (c.isPlayer) hudBomb(); alertBots(c); return true;
  }

  function damage(v, a, dmg, head, wname) {
    if (!v.alive || performance.now() < v.inv) return;
    v.hp = Math.max(0, v.hp - Math.round(dmg));
    if (v.isPlayer) { dmgFlash = 0.5; SND.hurt(); }
    if (v.isBot && a && v.ai) { v.ai.tgt = a; v.ai.vis = true; v.ai.react = Math.min(v.ai.react, 0.2); }
    if (v.hp <= 0) kill(v, a, wname, head);
  }
  function kill(v, a, wname, head) {
    v.alive = false; v.deaths++; v.deadT = 0; v.vis.hull.visible = false;
    if (a && a !== v && a.team !== v.team) { a.kills++; if (a.isPlayer) off.money = Math.min(16000, off.money + 300); } else if (a === v) v.kills = Math.max(0, v.kills - 1);
    addFeed(nameHtml(a || v) + ' ➜ ' + nameHtml(v) + ' <small>[' + (W[wname] ? W[wname].name : '?') + (head ? ' ★' : '') + ']</small>');
    if (v.isPlayer) { toast('Você morreu', 2500); G.dead = true; }
    if (G.mode === 'offline') checkRoundEnd();
  }
  let dmgFlash = 0, aiming = false;
  function hitMarker(head) { const h = $('hitm'); h.style.opacity = 1; h.style.color = head ? '#ff4040' : '#fff'; clearTimeout(hitMarker.t); hitMarker.t = setTimeout(() => { h.style.opacity = 0; }, 120); SND.hit(); }
  G.hitMarker = hitMarker;

  // ------------------------------------------------------------ entrada (toque, teclado, mouse)
  const inp = { mx: 0, mz: 0, fire: false, look: { x: 0, y: 0 }, jump: false, keys: {} };
  let joyId = null, joyOx = 0, joyOy = 0, lookId = null, lookX = 0, lookY = 0;
  const joy = $('joy'), knob = $('joyKnob'), JR = 55;
  function tStart(e) {
    for (const t of e.changedTouches) {
      const el = document.elementFromPoint(t.clientX, t.clientY);
      if (el && el.closest && el.closest('.btn,.screen,#buy,#sb,#pause')) continue;
      if (t.clientX < window.innerWidth * 0.45 && joyId === null) { joyId = t.identifier; joyOx = t.clientX; joyOy = t.clientY; joy.style.display = 'block'; joy.style.left = (joyOx - JR) + 'px'; joy.style.top = (joyOy - JR) + 'px'; knob.style.transform = 'translate(0,0)'; }
      else if (lookId === null) { lookId = t.identifier; lookX = t.clientX; lookY = t.clientY; }
    }
  }
  function tMove(e) {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) { let dx = t.clientX - joyOx, dy = t.clientY - joyOy; const l = Math.hypot(dx, dy); if (l > JR) { dx = dx / l * JR; dy = dy / l * JR; } knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)'; inp.mx = dx / JR; inp.mz = -dy / JR; }
      else if (t.identifier === lookId) { inp.look.x += t.clientX - lookX; inp.look.y += t.clientY - lookY; lookX = t.clientX; lookY = t.clientY; }
    }
    if (joyId !== null || lookId !== null) e.preventDefault();
  }
  function tEnd(e) {
    for (const t of e.changedTouches) {
      if (t.identifier === joyId) { joyId = null; inp.mx = inp.mz = 0; joy.style.display = 'none'; }
      if (t.identifier === lookId) lookId = null;
    }
  }
  document.addEventListener('touchstart', tStart, { passive: false }); document.addEventListener('touchmove', tMove, { passive: false });
  document.addEventListener('touchend', tEnd); document.addEventListener('touchcancel', tEnd);
  function act(a, down) {
    const c = G.me; if (!c) return;
    if (a === 'fire') inp.fire = down;
    if (!down) return;
    if (G.paused) return;
    if (a === 'jump') inp.jump = true;
    else if (a === 'reload') reload(c);
    else if (a === 'bomb') throwBomb(c);
    else if (a === 'swap') swapWeapon(c);
    else if (a === 'aim') { aiming = !aiming; }
    else if (a === 'dash') ability(c, 'dash'); else if (a === 'scan') ability(c, 'scan'); else if (a === 'heal') ability(c, 'heal');
    else if (a === 'buy') openBuy(); else if (a === 'pause') setPause(true);
    else if (a === 'sb') $('sb').style.display = $('sb').style.display === 'block' ? 'none' : 'block';
  }
  document.querySelectorAll('.btn[data-a]').forEach((b) => {
    const a = b.dataset.a;
    b.addEventListener('touchstart', (e) => { e.preventDefault(); b.classList.add('on'); act(a, true); }, { passive: false });
    const up = (e) => { e.preventDefault(); b.classList.remove('on'); act(a, false); };
    b.addEventListener('touchend', up, { passive: false }); b.addEventListener('touchcancel', up, { passive: false });
    b.addEventListener('mousedown', (e) => { act(a, true); }); b.addEventListener('mouseup', () => act(a, false));
  });
  // desktop (para testar no computador)
  const KEYMAP = { Space: 'jump', KeyR: 'reload', KeyG: 'bomb', KeyQ: 'dash', KeyE: 'scan', KeyF: 'heal', KeyB: 'buy', Tab: 'sb', KeyX: 'swap', KeyV: 'aim' };
  window.addEventListener('keydown', (e) => { if (G.mode === 'menu') return; if (e.code === 'Escape') { setPause(!G.paused); return; } inp.keys[e.code] = true; const a = KEYMAP[e.code]; if (a) { e.preventDefault(); if (a === 'sb') { $('sb').style.display = 'block'; } else act(a, true); } if (/^Digit[1-5]$/.test(e.code) && G.me) { const k = WORDER[+e.code[5] - 1]; if (G.mode === 'online' || k === 'revolver' || G.me.ammo[k] && G.me.prim === k) { if (!G.me.ammo[k] || G.mode === 'online') { giveIfNeeded(G.me, k); } setWeapon(G.me, k); } } });
  window.addEventListener('keyup', (e) => { inp.keys[e.code] = false; if (e.code === 'Tab') $('sb').style.display = 'none'; });
  canvas.addEventListener('mousedown', (e) => { if (G.mode === 'menu') return; if (document.pointerLockElement !== canvas && !('ontouchstart' in window)) canvas.requestPointerLock && canvas.requestPointerLock(); if (e.button === 0) inp.fire = true; if (e.button === 2) aiming = !aiming; });
  window.addEventListener('mouseup', (e) => { if (e.button === 0) inp.fire = false; });
  window.addEventListener('mousemove', (e) => { if (document.pointerLockElement === canvas) { inp.look.x += e.movementX; inp.look.y += e.movementY; } });
  canvas.addEventListener('contextmenu', (e) => e.preventDefault());

  function giveIfNeeded(c, k) { if (!c.ammo[k]) giveAmmo(c, k); }
  function swapWeapon(c) {
    if (G.mode === 'online') { const i = WORDER.indexOf(c.cur); const k = WORDER[(i + 1) % WORDER.length]; giveIfNeeded(c, k); setWeapon(c, k); c.prim = k; SND.click(); return; }
    const k = c.cur === 'revolver' ? c.prim : 'revolver'; if (k === c.cur) return; setWeapon(c, k); SND.click();
  }

  // ------------------------------------------------------------ habilidades
  const AB = { dash: { cd: 7, t: 0 }, scan: { cd: 20, t: 0 }, heal: { cd: 25, t: 0 } };
  let dashT = 0, scanT = 0;
  function ability(c, k) {
    const a = AB[k]; if (a.t > 0 || !c.alive) return;
    if (k === 'heal' && c.hp >= P.hp) { toast('Vida já está cheia', 900); return; }
    a.t = a.cd; SND.ability();
    if (k === 'dash') dashT = 0.2; else if (k === 'scan') { scanT = 4; toast('Radar: inimigos revelados', 1200); }
    else if (k === 'heal') { if (G.mode === 'online') G.net.sendHeal(); else c.hp = Math.min(P.hp, c.hp + 35); toast('+35 de vida', 900); }
  }

  // ------------------------------------------------------------ bots (offline)
  function newAI() { return { tgt: null, vis: false, react: 0, scan: 0, path: [], pi: 0, goalT: 0, strafe: 1, strafeT: 0, stuckT: 0, lx: 0, lz: 0, alert: null, blind: 0, bombT: rnd(3, 10) }; }
  function walkable(m, i, j) { return i >= 0 && j >= 0 && i < m.w && j < m.h && m.g[j * m.w + i] === 0; }
  function astar(m, sx, sz, gx, gz) {
    if (!walkable(m, gx, gz)) return [];
    const w = m.w, N = w * m.h, gS = new Float32Array(N).fill(1e9), from = new Int32Array(N).fill(-1), closed = new Uint8Array(N), open = [sz * w + sx], goal = gz * w + gx;
    gS[open[0]] = 0; let it = 0;
    while (open.length && it++ < 4000) {
      let bi = 0, bf = 1e9; for (let k = 0; k < open.length; k++) { const n = open[k], f = gS[n] + Math.hypot((n % w) - gx, ((n / w) | 0) - gz); if (f < bf) { bf = f; bi = k; } }
      const cur = open[bi]; open.splice(bi, 1); if (cur === goal) break; closed[cur] = 1;
      const cx = cur % w, cz = (cur / w) | 0;
      for (let dz = -1; dz <= 1; dz++) for (let dx = -1; dx <= 1; dx++) {
        if (!dx && !dz) continue; const nx = cx + dx, nz = cz + dz; if (!walkable(m, nx, nz)) continue;
        if (dx && dz && (!walkable(m, cx + dx, cz) || !walkable(m, cx, cz + dz))) continue;
        const n = nz * w + nx; if (closed[n]) continue; const g = gS[cur] + (dx && dz ? 1.41 : 1);
        if (g < gS[n]) { gS[n] = g; from[n] = cur; if (open.indexOf(n) < 0) open.push(n); }
      }
    }
    if (from[goal] < 0 && goal !== sz * w + sx) return [];
    const path = []; let n = goal; while (n !== sz * w + sx && n >= 0) { path.push(n); n = from[n]; } return path.reverse();
  }
  function botGoal(b) {
    const ai = b.ai, m = G.map, en = G.chars.filter((c) => c.alive && c.team !== b.team); let gx, gz;
    if (ai.alert) { gx = Math.floor(ai.alert.x / CELL); gz = Math.floor(ai.alert.z / CELL); ai.alert = null; }
    else if (en.length && Math.random() < 0.8) { const t = en[(Math.random() * en.length) | 0]; gx = Math.floor((t.x + rnd(-5, 5)) / CELL); gz = Math.floor((t.z + rnd(-5, 5)) / CELL); }
    else { gx = (Math.random() * m.w) | 0; gz = (Math.random() * m.h) | 0; }
    for (let k = 0; k < 6 && !walkable(m, gx, gz); k++) { gx = (Math.random() * m.w) | 0; gz = (Math.random() * m.h) | 0; }
    ai.path = astar(m, Math.floor(b.x / CELL), Math.floor(b.z / CELL), gx, gz); ai.pi = 0; ai.goalT = rnd(4, 8);
  }
  function findTarget(b) {
    const ai = b.ai, ex = b.x, ey = b.y + P.eye, ez = b.z; let best = null, bd = 1e9;
    const fx_ = -Math.sin(b.yaw), fz = -Math.cos(b.yaw);
    for (const c of G.chars) {
      if (!c.alive || c.team === b.team) continue; const dx = c.x - ex, dz = c.z - ez, dy = c.y + 1.2 - ey, d = Math.hypot(dx, dy, dz); if (d > 70 || d >= bd) continue;
      if (d > 7 && (dx * fx_ + dz * fz) / (Math.hypot(dx, dz) || 1) < 0.3) continue;
      if (SH.rayWorld(G.map, ex, ey, ez, dx, dy, dz, d) < d - 0.4) continue;
      best = c; bd = d;
    }
    if (best) { if (ai.tgt !== best) ai.react = [0.55, 0.38, 0.22][S.diff] + Math.random() * 0.15; ai.tgt = best; ai.vis = true; } else ai.vis = false;
  }
  function botUpdate(b, dt) {
    const ai = b.ai; let wx = 0, wz = 0;
    if (b.flashT > 0) { b.flashT -= dt; b.yaw += 2.5 * dt; ai.vis = false; moveChar(b, 0, 0, dt); return; }
    ai.scan -= dt; if (ai.scan <= 0) { ai.scan = 0.12 + Math.random() * 0.1; findTarget(b); }
    if (ai.tgt && !ai.tgt.alive) { ai.tgt = null; ai.vis = false; }
    if (ai.alert) ai.alert.t -= dt;
    const w = W[b.cur];
    if (ai.tgt && ai.vis) {
      const t = ai.tgt, dx = t.x - b.x, dz = t.z - b.z, dist = Math.hypot(dx, dz), want = Math.atan2(-dx, -dz), df = angDiff(b.yaw, want), maxT = [3.2, 4.8, 7][S.diff] * dt;
      b.yaw += clamp(df, -maxT, maxT); const ty = t.y + (b.cur === 'sniper' ? 1.5 : 1.25), wp = Math.atan2(ty - (b.y + P.eye), dist); b.pitch += clamp(wp - b.pitch, -maxT, maxT);
      ai.react -= dt; ai.strafeT -= dt; if (ai.strafeT <= 0) { ai.strafe = Math.random() < 0.5 ? -1 : 1; ai.strafeT = rnd(0.5, 1.4); }
      const sp = 3.4, rx = Math.cos(b.yaw), rz = -Math.sin(b.yaw), fx_ = -Math.sin(b.yaw), fz = -Math.cos(b.yaw);
      wx = rx * ai.strafe * sp * 0.7; wz = rz * ai.strafe * sp * 0.7;
      if (dist > 22) { wx += fx_ * sp; wz += fz * sp; } else if (dist < 6) { wx -= fx_ * sp; wz -= fz * sp; }
      if (b.cur === 'sniper') { wx *= 0.2; wz *= 0.2; }
      if (ai.react <= 0 && Math.abs(angDiff(b.yaw, want)) < 0.1 && dist < w.range * 0.8 && !(b.cur === 'bazooka' && dist < 7)) {
        const err = [0.045, 0.028, 0.016][S.diff] * (0.6 + dist / 40) + (b.spd > 1 ? 0.01 : 0) + w.spread * 0.5, cp = Math.cos(b.pitch);
        const d = dirWithSpread(b, err); if (b.ammo[b.cur].mag <= 0) reload(b); else fire(b, d);
      }
      ai.bombT -= dt; if (ai.bombT <= 0 && b.bombs > 0 && dist > 9 && dist < 24) { throwBomb(b, (function () { const l = Math.hypot(dx, dz) + 0.01; return { x: dx / l * 0.95, y: 0.32, z: dz / l * 0.95 }; })()); ai.bombT = rnd(8, 18); }
    } else {
      ai.goalT -= dt; if (ai.goalT <= 0 || ai.pi >= ai.path.length) botGoal(b);
      const n = ai.path[ai.pi];
      if (n !== undefined) {
        const tx = (n % G.map.w) * CELL + 1, tz = ((n / G.map.w) | 0) * CELL + 1, dx = tx - b.x, dz = tz - b.z, d = Math.hypot(dx, dz);
        if (d < 0.7) ai.pi++; else { wx = dx / d * 4.2; wz = dz / d * 4.2; const want = Math.atan2(-dx, -dz); b.yaw += clamp(angDiff(b.yaw, want), -6 * dt, 6 * dt); b.pitch += (0 - b.pitch) * Math.min(1, 5 * dt); }
      }
      ai.stuckT += dt; if (ai.stuckT > 1) { ai.stuckT = 0; if (Math.hypot(b.x - ai.lx, b.z - ai.lz) < 0.3) botGoal(b); ai.lx = b.x; ai.lz = b.z; }
      if (b.ammo[b.cur].mag < W[b.cur].mag * 0.3) reload(b);
    }
    moveChar(b, wx, wz, dt);
  }
  function moveChar(c, wx, wz, dt) {
    const px = c.x, pz = c.z; SH.step(G.map, c, wx, wz, dt); c.spd = Math.hypot(c.x - px, c.z - pz) / Math.max(dt, 1e-3);
  }

  // ------------------------------------------------------------ partida offline (rodadas)
  const off = { round: 0, score: [0, 0], money: 2000, phase: 'none', t: 0, side: 0, size: 5, win: 8, over: false };
  G.off = off;
  const BOTNAMES = ['Rafa', 'Duda', 'Kauê', 'Bia', 'Lucas', 'Nina', 'Théo', 'Gabi', 'Davi', 'Mari', 'João', 'Lara'];
  G.startOffline = function (o) {
    clearChars(); resetWorldState(); G.mode = 'offline'; G.dead = false; loadMap(o.map);
    off.side = o.side; off.size = o.size; off.round = 0; off.score = [0, 0]; off.money = 2000; off.over = false;
    const me = G.me = newChar(o.side, { isPlayer: true, name: S.name || 'Você' }); me.vis.grp.visible = false;
    let ni = 0; for (let t = 0; t < 2; t++) { const n = o.size - (t === o.side ? 1 : 0); for (let i = 0; i < n; i++) newChar(t, { isBot: true, name: BOTNAMES[ni++ % BOTNAMES.length], ai: newAI() }); }
    showHud(true); G.showScreen(null); startRound();
  };
  function botLoadout(b) {
    const r = Math.random(), k = off.round <= 1 ? (r < 0.6 ? 'revolver' : 'smg') : (r < 0.3 ? 'smg' : r < 0.75 ? 'rifle' : r < 0.9 ? 'sniper' : (off.round > 3 ? 'bazooka' : 'rifle'));
    b.prim = k; giveAmmo(b, k); setWeapon(b, k);
  }
  function startRound() {
    off.round++; off.phase = 'freeze'; off.t = 5; G.dead = false; projs.slice().forEach(removeProj); scanT = 0; dashT = 0;
    for (const k in AB) AB[k].t = 0;
    const cnt = [0, 0];
    for (const c of G.chars) {
      const keep = c.isPlayer && c.alive && off.round > 1; const was = c.cur;
      const sp = SH.spawnPoint(G.map, c.team); const used = G.chars.some((o) => o !== c && o.alive && Math.hypot(o.x - sp.x, o.z - sp.z) < 1.2);
      spawnChar(c, sp.x + (used ? rnd(-0.8, 0.8) : 0), sp.z + (used ? rnd(-0.8, 0.8) : 0), c.team === 0 ? 0 : Math.PI);
      if (c.isBot) botLoadout(c); else if (!keep) { c.prim = 'revolver'; c.ammo = {}; giveAmmo(c, 'revolver'); setWeapon(c, 'revolver'); } else { for (const k in c.ammo) { const a = c.ammo[k]; a.mag = W[k].mag; a.res = W[k].res; } setWeapon(c, c.cur); }
      if (c.isBot) { c.ai = newAI(); c.ai.goalT = rnd(0, 1.5); }
      cnt[c.team]++;
    }
    const me = G.me; me.yaw = me.team === 0 ? 0 : Math.PI; me.pitch = 0;
    hudWeapon(); hudBomb(); toast('Rodada ' + off.round + ' — compre suas armas', 2500); openBuy(true);
  }
  function checkRoundEnd() {
    if (off.phase !== 'live') return;
    const alive = [0, 0]; for (const c of G.chars) if (c.alive) alive[c.team]++;
    if (alive[0] === 0 || alive[1] === 0) endRound(alive[0] === 0 ? 1 : 0);
  }
  function endRound(win) {
    off.phase = 'end'; off.t = 3.5; off.score[win]++;
    const mine = G.me.team === win; off.money = Math.min(16000, off.money + (mine ? 2500 : 1500));
    toast(mine ? 'Seu time venceu a rodada!' : 'Seu time perdeu a rodada', 3000);
    if (off.score[win] >= off.win) { off.over = true; setTimeout(() => showEnd(mine ? 'VITÓRIA!' : 'DERROTA', off.score[G.me.team] + ' x ' + off.score[1 - G.me.team]), 2800); }
  }
  function updateOffline(dt) {
    if (off.phase === 'freeze') { off.t -= dt; if (off.t <= 0) { off.phase = 'live'; off.t = 100; closeBuy(); toast('VALENDO!', 1000); } }
    else if (off.phase === 'live') { off.t -= dt; if (off.t <= 0) endRound(1); }   // tempo esgotado: CT vence
    else if (off.phase === 'end' && !off.over) { off.t -= dt; if (off.t <= 0) startRound(); }
  }

  // ------------------------------------------------------------ menu de compra / armas
  function openBuy(auto) {
    if (G.mode === 'offline' && off.phase !== 'freeze') { toast('Compra só no início da rodada', 1200); return; }
    const list = $('buyList'); list.innerHTML = '';
    WORDER.forEach((k, i) => {
      const w = W[k], b = document.createElement('div'); b.className = 'buyItem';
      const price = G.mode === 'online' ? 'grátis' : (w.cost ? '$' + w.cost : 'grátis');
      b.innerHTML = '<b>' + w.name + '</b><span>' + price + '</span><small>dano ' + w.dmg + ' • ' + (w.auto ? 'auto' : 'semi') + '</small>';
      b.addEventListener('click', () => buy(k)); b.addEventListener('touchend', (e) => { e.preventDefault(); buy(k); });
      list.appendChild(b);
    });
    $('buy').style.display = 'block';
  }
  function closeBuy() { $('buy').style.display = 'none'; }
  G.closeBuy = closeBuy; G.openBuy = openBuy;
  function buy(k) {
    const c = G.me, w = W[k];
    if (G.mode === 'offline') {
      if (off.phase !== 'freeze') return; if (k !== c.prim && off.money < w.cost) { toast('Dinheiro insuficiente', 1000); return; }
      if (k !== c.prim) { off.money -= w.cost; c.prim = k; giveAmmo(c, k); }
    } else { c.prim = k; giveIfNeeded(c, k); }
    setWeapon(c, k); SND.click(); closeBuy();
  }

  // ------------------------------------------------------------ HUD
  const hud = { hp: -1, ammo: '', money: -1, t: '', sc: '' };
  function showHud(v) { $('hud').style.display = v ? 'block' : 'none'; }
  function hudWeapon() { const c = G.me; if (c) $('wname').textContent = W[c.cur].name; }
  function hudBomb() { const c = G.me; if (c) $('bombN').textContent = c.bombs; }
  G.hudBomb = hudBomb;
  let miniT = 0;
  function drawMini() {
    const cv = $('mini'), x = cv.getContext('2d'), m = G.map; if (!m || !miniBase) return;
    x.clearRect(0, 0, cv.width, cv.height); const s = Math.min(cv.width / miniBase.width, cv.height / miniBase.height);
    x.globalAlpha = 0.85; x.drawImage(miniBase, 0, 0, miniBase.width * s, miniBase.height * s); x.globalAlpha = 1;
    const k = 3 * s / CELL, me = G.me;
    for (const c of G.chars) {
      if (!c.alive) continue; const ally = me && c.team === me.team;
      if (!ally && scanT <= 0 && !(G.mode === 'offline' && me && c.isBot && false)) continue;
      x.fillStyle = c.isPlayer ? '#fff' : (c.team ? '#4f8bff' : '#ff4a3a'); x.beginPath(); x.arc(c.x * k, c.z * k, c.isPlayer ? 3 : 2.4, 0, 6.3); x.fill();
      if (c.isPlayer) { x.strokeStyle = '#fff'; x.beginPath(); x.moveTo(c.x * k, c.z * k); x.lineTo(c.x * k - Math.sin(c.yaw) * 7, c.z * k - Math.cos(c.yaw) * 7); x.stroke(); }
    }
  }
  function updateHud(dt) {
    const c = G.me; if (!c) return;
    if (c.hp !== hud.hp) { hud.hp = c.hp; $('hp').textContent = Math.max(0, c.hp); $('hpfill').style.width = Math.max(0, c.hp) + '%'; }
    const a = c.ammo[c.cur], as = a.mag + ' / ' + a.res; if (as !== hud.ammo) { hud.ammo = as; $('ammo').textContent = as; }
    if (G.mode === 'offline') {
      if (off.money !== hud.money) { hud.money = off.money; $('money').textContent = '$' + off.money; }
      const t = Math.max(0, Math.ceil(off.t)); const ts = (off.phase === 'freeze' ? '⏳' : '') + Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2);
      if (ts !== hud.t) { hud.t = ts; $('timer').textContent = ts; }
      const sc = off.score[0] + '|' + off.score[1]; if (sc !== hud.sc) { hud.sc = sc; $('scT').textContent = off.score[0]; $('scCT').textContent = off.score[1]; }
    }
    for (const k in AB) { const el = $('cd-' + k); const v = AB[k].t > 0 ? Math.ceil(AB[k].t) : ''; if (el.textContent !== String(v)) el.textContent = v; }
    $('flashOv').style.opacity = flashT <= 0 ? 0 : (flashT > flashDur * 0.3 ? 1 : flashT / (flashDur * 0.3));
    $('dmgOv').style.opacity = clamp(dmgFlash * 1.2, 0, 0.7);
    const sc = aiming && c.cur === 'sniper'; $('scope').style.display = sc ? 'block' : 'none';
    miniT -= dt; if (miniT <= 0) { miniT = 0.12; drawMini(); }
  }
  function showEnd(title, sub) { if (G.mode === 'offline') G.paused = true; $('endTxt').textContent = title; $('endSub').textContent = sub; $('endBox').style.display = 'flex'; }
  G.showEnd = showEnd;

  // ------------------------------------------------------------ pausa / telas
  G.paused = false;
  function setPause(v) { if (G.mode === 'menu') return; G.paused = v && G.mode === 'offline' ? true : false; $('pause').style.display = v ? 'flex' : 'none'; if (v && document.exitPointerLock) document.exitPointerLock(); }
  G.setPause = setPause;
  G.showScreen = function (id) { document.querySelectorAll('.screen').forEach((s) => { s.style.display = s.id === id ? 'flex' : 'none'; }); };
  G.leaveToMenu = function () {
    if (G.net && G.net.active) G.net.leave(); G.mode = 'menu'; G.paused = false; $('pause').style.display = 'none'; $('endBox').style.display = 'none'; closeBuy(); $('sb').style.display = 'none';
    showHud(false); clearChars(); projs.slice().forEach(removeProj); G.showScreen('menu');
  };
  G.toLobby = function () {   // volta da partida online para a sala (sem sair dela)
    G.mode = 'menu'; G.paused = false; $('pause').style.display = 'none'; $('endBox').style.display = 'none'; closeBuy(); $('sb').style.display = 'none';
    showHud(false); clearChars(); projs.slice().forEach(removeProj);
  };
  function resetWorldState() { projs.slice().forEach(removeProj); flashT = 0; dmgFlash = 0; scanT = 0; dashT = 0; aiming = false; G.paused = false; $('endBox').style.display = 'none'; $('pause').style.display = 'none'; $('sb').style.display = 'none'; feed.innerHTML = ''; for (const k in AB) AB[k].t = 0; }

  // ------------------------------------------------------------ API online (usada por net.js)
  const byId = () => { const m = {}; G.chars.forEach((c) => { m[c.sid] = c; }); return m; };
  G.startOnline = function (cfg) {
    clearChars(); resetWorldState(); G.mode = 'online'; G.dead = false; loadMap(cfg.mapIdx);
    const me = G.me = newChar(cfg.team, { isPlayer: true, name: S.name, sid: cfg.meId }); me.vis.grp.visible = false;
    cfg.players.forEach((p) => { if (p.id !== cfg.meId) G.online.addPlayer(p); });
    me.prim = 'rifle'; giveAmmo(me, 'rifle'); setWeapon(me, 'rifle'); me.alive = false;
    showHud(true); G.showScreen(null); $('money').textContent = ''; hudBomb();
  };
  G.online = {
    addPlayer(p) { if (G.chars.some((c) => c.sid === p.id)) return; const c = newChar(p.team, { isRemote: true, name: p.name, sid: p.id }); spawnChar(c, p.x, p.z, p.yaw); c.alive = !!p.alive; c.hp = p.hp; c.vis.grp.visible = c.alive; if (!c.alive) c.vis.hull.visible = false; c.cur = p.w; },
    removePlayer(id) { const c = byId()[id]; if (c) { removeChar(c); } },
    setTeam(id, team) { const c = byId()[id]; if (!c) return; c.team = team; setVisualTeam(c.vis, team); if (c === G.me) G.me.team = team; },
    resp(m) {
      const c = byId()[m.id]; if (!c) return; spawnChar(c, m.x, m.z, m.yaw); c.team = m.team; setVisualTeam(c.vis, m.team); c.hp = m.hp; c.vis.grp.visible = !c.isPlayer;
      if (c.isPlayer) { G.dead = false; c.bombs = 2; hudBomb(); for (const k in c.ammo) { c.ammo[k].mag = W[k].mag; c.ammo[k].res = W[k].res; } toast('Renasceu — escolha sua arma', 1500); openBuy(true); setTimeout(closeBuy, 4000); }
    },
    snap(arr, left) {
      const m = byId();
      for (const s of arr) {
        const c = m[s[0]]; if (!c) continue;
        if (c.isPlayer) { c.hp = s[7]; continue; }
        c.tx = s[1]; c.ty = s[2]; c.tz = s[3]; c.tyaw = s[4]; c.tpit = s[5]; c.hp = s[7];
        if (typeof s[6] === 'string' && W[s[6]]) { if (c.cur !== s[6]) { c.cur = s[6]; c.vis.gun.material = gunMats[s[6]]; c.vis.gun.scale.set(0.07, 0.1, GLEN[s[6]]); c.vis.gun.position.z = -0.12 - GLEN[s[6]] * 0.5 + 0.12; } }
        const was = c.alive; c.alive = !!s[8]; if (!c.alive && was) { c.deadT = 0; c.vis.hull.visible = false; } if (c.alive && !was) { c.vis.hull.visible = true; c.vis.inner.rotation.x = 0; c.vis.inner.position.y = 0; }
      }
      if (left !== undefined) { const t = Math.max(0, left); $('timer').textContent = Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2); }
    },
    hit(m) { const me = G.me; if (m.to === me.sid) { me.hp = m.hp; dmgFlash = 0.5; SND.hurt(); } if (m.by === me.sid && m.to !== me.sid) hitMarker(!!m.hs); },
    kill(m) {
      const mm = byId(), k = mm[m.k], v = mm[m.v]; if (!v) return; v.alive = false; v.deadT = 0; v.vis.hull.visible = false; v.deaths++;
      addFeed(nameHtml(k || v) + ' ➜ ' + nameHtml(v) + ' <small>[' + (W[m.w] ? W[m.w].name : '?') + (m.hs ? ' ★' : '') + ']</small>');
      if (v.isPlayer) { toast('Você morreu — renasce em 3s', 2800); G.dead = true; }
      if (m.score) G.online.score(m.score);
    },
    score(sc) { $('scT').textContent = sc[0]; $('scCT').textContent = sc[1]; },
    shot(m) { if (G.me && m.id === G.me.sid) return; tracer(m.ox, m.oy, m.oz, m.ex, m.ey, m.ez); const c = byId()[m.id]; if (c) { const d = Math.hypot(c.x - G.me.x, c.z - G.me.z); if (d < 40) SND.shot(m.w); } if (!m.hit) spark(m.ex, m.ey, m.ez); },
    proj(m) { const c = byId()[m.by]; addProj(m.kind, m.x, m.y, m.z, m.vx, m.vy, m.vz, c || G.me, m.id).id = m.id; if (G.me && m.by === G.me.sid) { /* meu próprio */ } },
    boom(m) { for (const p of projs) if (p.id === m.id && p.kind === m.kind) { removeProj(p); break; } explosion(m.x, m.y, m.z, m.kind); },
    fix(m) { const c = G.me; c.x = m.x; c.y = m.y; c.z = m.z; c.vy = 0; },
    healed(hp) { G.me.hp = hp; },
    flash(ms) { G.flash(ms); }
  };

  // ------------------------------------------------------------ atualização do jogador
  let sendT = 0;
  function updatePlayer(dt) {
    const c = G.me; if (!c) return;
    // olhar
    const zoomK = aiming ? W[c.cur].zoom / 75 : 1, sens = 0.0042 * S.sens * zoomK;
    if (c.alive && !G.paused) { c.yaw -= inp.look.x * sens; c.pitch = clamp(c.pitch - inp.look.y * sens, -1.4, 1.4); }
    inp.look.x = inp.look.y = 0;
    if (!c.alive) { c.deadT += dt; return; }
    let mx = inp.mx, mz = inp.mz; const k = inp.keys;
    if (k.KeyW || k.ArrowUp) mz += 1; if (k.KeyS || k.ArrowDown) mz -= 1; if (k.KeyD || k.ArrowRight) mx += 1; if (k.KeyA || k.ArrowLeft) mx -= 1;
    const l = Math.hypot(mx, mz); if (l > 1) { mx /= l; mz /= l; }
    const frozen = G.mode === 'offline' && off.phase === 'freeze';
    let sp = P.speed * (aiming ? 0.6 : 1) * (c.cur === 'sniper' || c.cur === 'bazooka' ? 0.9 : 1);
    const fx_ = -Math.sin(c.yaw), fz = -Math.cos(c.yaw), rx = Math.cos(c.yaw), rz = -Math.sin(c.yaw);
    let wx = (rx * mx + fx_ * mz) * sp, wz = (rz * mx + fz * mz) * sp;
    if (dashT > 0) { dashT -= dt; const dl = Math.hypot(mx, mz), dx = dl > 0.1 ? (rx * mx + fx_ * mz) / dl : fx_, dz = dl > 0.1 ? (rz * mx + fz * mz) / dl : fz; wx = dx * 17; wz = dz * 17; }
    if (frozen || flashT > 0 && false) { wx = wz = 0; }
    if (inp.jump) { inp.jump = false; if (c.on && !frozen) { c.vy = P.jump; c.on = false; } }
    moveChar(c, wx, wz, dt);
    if (inp.fire && !frozen && !G.paused) { const w = W[c.cur]; if (w.auto || !inp._held) fire(c); inp._held = true; } else if (!inp.fire) inp._held = false;
    c.walk += c.spd * dt * 1.6;
    // envia estado ao servidor (15x por segundo)
    if (G.mode === 'online' && G.net) { sendT -= dt; if (sendT <= 0) { sendT = 0.066; G.net.sendState(c); } }
  }

  // ------------------------------------------------------------ atualização geral
  function updateChars(dt) {
    const now = performance.now(), me = G.me;
    for (const c of G.chars) {
      if (c.fireT > 0) c.fireT -= dt;
      if (c.reloadT > 0) { c.reloadT -= dt; if (c.reloadT <= 0) { c.reloadT = 0; finishReload(c); } }
      if (c.alive) {
        if (c.isBot && !G.paused && !(G.mode === 'offline' && off.phase === 'freeze')) botUpdate(c, dt);
        else if (c.isBot) { c.spd = 0; }
        if (c.isRemote) {   // interpolação suave dos jogadores remotos
          const k = Math.min(1, dt * 14), px = c.x, pz = c.z; c.x += (c.tx - c.x) * k; c.y += (c.ty - c.y) * k; c.z += (c.tz - c.z) * k; c.yaw += angDiff(c.yaw, c.tyaw) * k; c.pitch += (c.tpit - c.pitch) * k; c.spd = Math.hypot(c.x - px, c.z - pz) / Math.max(dt, 1e-3);
        }
        c.walk += c.spd * dt * 1.6;
      } else c.deadT = Math.min(1, c.deadT + dt * 2.5);
      // visual
      const v = c.vis; if (c.isPlayer) continue;
      v.grp.position.set(c.x, c.y, c.z); v.grp.rotation.y = c.yaw + Math.PI; v.shadow.position.y = 0.03 - c.y;
      const amt = clamp(c.spd / 5, 0, 1) * (c.on ? 1 : 0.3), s = Math.sin(c.walk) * 0.75 * amt;
      v.sw.set(s, -s, -s * 0.7, s * 0.7);
      if (!c.alive) { v.inner.rotation.x = -Math.PI / 2 * c.deadT; v.inner.position.y = 0.25 * c.deadT; v.grp.visible = c.deadT < 1 || true; v.gun.visible = false; v.shadow.visible = false; }
      else { v.gun.visible = true; v.shadow.visible = true; v.grp.visible = true; }
      // contorno/raio-x: aliados sempre visíveis através de paredes; inimigos só com radar
      const ally = me && c.team === me.team, showX = c.alive && c !== me && (ally || scanT > 0);
      v.xray.visible = showX; v.hull.visible = c.alive;
    }
  }
  function updateCamera(dt) {
    const c = G.me; if (!c) return; let tgt = c, y = c.y + P.eye;
    if (!c.alive) {   // espectador: segue um aliado vivo (offline) ou fica no corpo
      const alive = G.chars.filter((o) => o.alive && o.team === c.team && o !== c); if (alive.length && G.mode === 'offline') { tgt = alive[0]; y = tgt.y + P.eye; }
      else y = c.y + 0.5 + (1 - Math.min(1, c.deadT)) * 1.1;
    }
    camera.position.set(tgt.x, y, tgt.z); camera.rotation.set(tgt.pitch, tgt.yaw, !c.alive && tgt === c ? 0.5 * Math.min(1, c.deadT) : 0);
    const fov = aiming ? W[c.cur].zoom : 75; camera.fov += (fov - camera.fov) * Math.min(1, dt * 14); camera.updateProjectionMatrix();
    // arma na tela
    const sc = aiming && c.cur === 'sniper'; vm.visible = c.alive && !sc;
    vmKick = Math.max(0, vmKick - dt * 0.6); const bob = Math.sin(c.walk * 1.4) * 0.008 * clamp(c.spd / 5, 0, 1);
    const reloadDip = c.reloadT > 0 ? Math.sin(Math.min(1, c.reloadT / W[c.cur].reload) * Math.PI) * 0.18 : 0;
    vm.position.set((aiming ? 0.0 : 0.2) + bob, (aiming ? -0.14 : -0.2) + Math.abs(bob) - reloadDip, -0.42 + vmKick);
    flashShow -= dt; const vp = vmParts[c.cur]; if (vp && vp.flash) vp.flash.visible = flashShow > 0;
  }

  // ------------------------------------------------------------ loop principal
  let last = performance.now(), acc = 0, frameAvg = 16, adaptT = 0, lastRender = 0;
  function frame(ts) {
    requestAnimationFrame(frame);
    const now = performance.now(); let dt = (now - last) / 1000; last = now; dt = Math.min(dt, 0.05);
    if (G.mode === 'menu') { renderMenu(dt); return; }
    if (S.fps === 30 && now - lastRender < 29) return; lastRender = now;
    if (!G.paused) {
      if (G.mode === 'offline') updateOffline(dt);
      updatePlayer(dt); updateChars(dt); updateProjs(dt); updateFx(dt);
      for (const k in AB) if (AB[k].t > 0) AB[k].t -= dt; if (scanT > 0) scanT -= dt; if (flashT > 0) flashT -= dt; if (dmgFlash > 0) dmgFlash -= dt;
    }
    updateCamera(dt); updateHud(dt); renderer.render(scene, camera);
    // qualidade dinâmica: reduz a resolução se estiver pesado
    frameAvg += (dt * 1000 - frameAvg) * 0.05; adaptT += dt;
    if (adaptT > 2.5 && S.q > 0.45 && S.auto !== 0) { adaptT = 0; if (frameAvg > (S.fps === 30 ? 42 : 24) && qScale > 0.45) { qScale = Math.max(0.45, qScale - 0.1); resize(); } }
  }
  let menuT = 0;
  function renderMenu(dt) {   // fundo do menu: câmera girando no mapa
    if (!G.map) { loadMap(0); } menuT += dt * 0.15; const m = G.map; camera.position.set(m.w, 8, m.h); camera.rotation.set(-0.35, menuT, 0); camera.fov = 75; camera.updateProjectionMatrix(); vm.visible = false; renderer.render(scene, camera);
  }
  G.boot = function () { requestAnimationFrame(frame); };
  G.W = W; G.projsCount = () => projs.length; G.scene = scene; G.setQ = (q) => { qScale = q; resize(); };
})();
