# English Master Pro v11.6 — 7-Day Study Reward

## New feature
- A **Good Study Day** is earned when the learner completes all 3 daily study sessions (morning, afternoon, evening).
- 7 consecutive Good Study Days unlock the existing **AI Tutor** ability in the app.
- The app shows progress `0/7` through `7/7` and keeps the progress in local storage.
- Missing a day resets the pre-unlock Good Study Streak when the next complete day is recorded.
- Once AI Tutor is unlocked, it stays unlocked unless the learner resets app progress.
- The reward is separate from the normal daily streak.

## Existing feature
The unlocked ability is the app's existing AI Tutor page; v11.6 does not add a fake AI service or API key.

## Android
- Version code: 116
- Version name: 11.6.0
- Release signing and real AdMob/backend credentials remain external configuration as in v11.5.


## v11.7 reward-unlock redesign
- Premium/subscription UI removed from the learner app.
- Former Premium learning abilities remain locked and unlock one per qualifying 7-day week.
- A qualifying day requires all three scheduled study sessions plus a test score of at least 6/8.
- Adaptive/resizable Android layout; portrait-only activity restriction removed.
- versionCode 117 / versionName 11.7.0.
