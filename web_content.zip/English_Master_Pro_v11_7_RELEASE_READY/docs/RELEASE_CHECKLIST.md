# English Master Pro v11.6 — Release checklist

## Android build
- [ ] Version name is 11.4.0
- [ ] Version code is 114 and higher than every Play Console build already uploaded
- [ ] Debug and Release are separate
- [ ] Release is `debuggable=false`
- [ ] Release signing uses a private keystore that is NOT inside the public ZIP
- [ ] Generate signed AAB for Google Play
- [ ] Generate signed APK for direct device testing if needed
- [ ] Keep the keystore backup securely offline / in a private secret manager

## AdMob
- [ ] Test App ID and Test Ad Unit IDs are used only during testing
- [ ] Replace all three TEST IDs with the real AdMob IDs before production
- [ ] Test ads appear on a physical device
- [ ] Premium users do not receive ads

## WebView / Android permissions
- [ ] WebViewAssetLoader works for all local assets
- [ ] HTTPS backend only
- [ ] Cleartext traffic remains disabled
- [ ] Microphone permission tested on Android 8–15
- [ ] Denied microphone permission has a usable fallback
- [ ] WebView audio capture is granted only after Android permission
- [ ] Back navigation works

## Billing / backend
- [ ] Play Console subscriptions match `emp_premium_monthly` and `emp_premium_yearly`
- [ ] Real HTTPS backend URL configured
- [ ] Purchase token is sent to backend
- [ ] Backend verifies token with Google Play Developer API
- [ ] Premium is activated only after server verification
- [ ] Pending / purchased / canceled / expired / restored states tested
- [ ] Authentication, rate limits, logging and abuse protection checked

## Security / Play Console
- [ ] No API keys in app assets
- [ ] No private signing key in ZIP, Git, or APK assets
- [ ] `allowBackup=false` reviewed for product requirements
- [ ] Privacy Policy and Terms use real business details
- [ ] Play Console Data Safety completed
- [ ] Content rating and target audience completed
- [ ] Subscription disclosures and pricing completed
- [ ] Production release tested on real devices
