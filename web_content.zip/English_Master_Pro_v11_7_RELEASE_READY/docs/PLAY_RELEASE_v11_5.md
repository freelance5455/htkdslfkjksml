# English Master Pro v11.6 — Google Play release profile

This project is configured for a Google Play release workflow and for reducing avoidable Play Protect warnings. It cannot guarantee that Play Protect will never warn on an APK installed outside Google Play.

## Current Android release values
- versionName: `11.5.0`
- versionCode: `115`
- compileSdk / targetSdk: `36` (Android 16)
- Debug and Release are separate; Debug uses `.debug` applicationId suffix.
- Release is non-debuggable, minified and resource-shrunk.
- Release requires a private upload keystore configured outside this ZIP.
- Release requires real AdMob IDs through environment variables; it intentionally refuses to build with the Google test IDs.

Google Play currently requires new apps and app updates submitted from 31 August 2026 to target Android 16 / API 36 or higher. See the official policy before submission.

## Play App Signing
For a new Google Play app, use Play App Signing and keep the upload key private. Google protects the app-signing key; your local upload key should never be committed to this ZIP or repository.

## Release build environment
Set these private variables on the build machine/CI:

### Signing
- `EMP_KEYSTORE_PATH`
- `EMP_KEYSTORE_PASSWORD`
- `EMP_KEY_ALIAS`
- `EMP_KEY_PASSWORD`

### Production AdMob
- `ADMOB_APP_ID`
- `ADMOB_BANNER_ID`
- `ADMOB_INTERSTITIAL_ID`

If these are absent, `assembleRelease` / `bundleRelease` is intentionally blocked.

## Build
Open `android/` in Android Studio with JDK 17 and let Gradle sync. Use:

```text
./gradlew clean bundleRelease
```

For direct-device testing:

```text
./gradlew clean assembleRelease
```

For Google Play, upload the `.aab`, not a locally distributed debug APK.

## Before upload
1. Create the Play Console app with the exact package name `com.englishmasterpro.app`.
2. Enroll in Play App Signing.
3. Generate/register a private upload key.
4. Register the Google-held app-signing fingerprints with Google Login/OAuth and any API providers that need them.
5. Configure real AdMob IDs.
6. Configure the real HTTPS backend URL.
7. Configure Play subscriptions and server-side purchase-token verification.
8. Complete Data safety, content rating, target audience, privacy policy, terms, and subscription disclosures.
9. Test the signed release on real devices before production rollout.
10. Use internal/closed testing in Play Console before production.

## Play Protect note
The screenshots showing “App blocked to protect your device” are consistent with installing a locally distributed APK from a developer Google Play Protect has not seen before. Release signing, Play App Signing, a stable package identity, and distribution through Google Play reduce avoidable trust problems, but only Google can decide whether Play Protect displays a warning.
