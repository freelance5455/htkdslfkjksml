# English Master Pro v7

Upgraded from v6 with:
- 🎤 Microphone permission request using `getUserMedia`
- Speech Recognition language fixed to `en-US`
- Android WebView/native bridge hooks when a host app exposes `AndroidBridge.requestMicrophonePermission()` and `AndroidBridge.startSpeechRecognition(lang)`
- Graceful fallback when Speech Recognition is unavailable: offline text speaking practice
- Offline-first PWA caching with `sw.js`
- Built-in offline English AI Tutor (rule-based/local; no API key required)
- AI quick prompts, chat history for the current session, and text-to-speech replies
- Existing lessons, vocabulary, XP, streaks, tests, dark mode and progress retained
- Constructor footer: hezbullah kashmiri

## Android WebView note
A plain HTML ZIP cannot itself grant Android runtime permissions. The Android host/WebView must grant `RECORD_AUDIO` and allow microphone access. If the native wrapper exposes the optional `AndroidBridge` methods, v7 will use them.

For service-worker offline caching, load the app from an HTTP(S) origin (for example an Android WebView asset loader with a secure origin), not `file://`.
