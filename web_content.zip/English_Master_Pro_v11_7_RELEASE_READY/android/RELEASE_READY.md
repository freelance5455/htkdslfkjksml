# English Master Pro v11.7 — Release-ready Android project

This project is configured for a non-debuggable Release build. It is suitable for private APK testing and can also produce an AAB when built with Android Studio/Gradle.

## What is configured
- versionCode: 117
- versionName: 11.7.0
- minSdk: 23 (Android 6.0+)
- targetSdk / compileSdk: 36
- Release: debuggable=false, R8/minification enabled, resource shrinking enabled
- `resizeableActivity=true`; no fixed portrait orientation
- cleartext HTTP disabled
- backup disabled
- WebView local assets loaded through `WebViewAssetLoader`
- Debug build remains separate with `.debug` application ID suffix
- Release signing reads the private keystore from `keystore.properties` or environment variables
- Real AdMob IDs are injected only at private Release build time
- Backend URL is injected through `EMP_BACKEND_URL`; leave it unset for local/offline mode
- Premium/subscription UI is not present in the Android app UI; weekly unlock gates remain in the learning logic

## Important
Do **not** put a private `.jks`/`.keystore`, passwords, API secrets, or production credentials into this ZIP. Android's documentation recommends keeping signing credentials outside source/build files and using environment variables or local properties.

## Build in Android Studio
1. Open the `android/` folder.
2. Let Android Studio sync Gradle and install any required SDK components.
3. Create/select your Release keystore.
4. Set the AdMob Release values and signing values locally.
5. Build `release` from the Build menu, or use **Generate Signed Bundle / APK**.

## Command-line environment
Set these variables on the private build machine:
- `ADMOB_APP_ID`
- `ADMOB_BANNER_ID`
- `ADMOB_INTERSTITIAL_ID`
- `EMP_KEYSTORE_PATH`
- `EMP_KEYSTORE_PASSWORD`
- `EMP_KEY_ALIAS`
- `EMP_KEY_PASSWORD`
- optional: `EMP_BACKEND_URL`

Then run `build-release.sh`.

The APK is the file to install directly on a phone. The AAB is a publishing/distribution bundle and is not directly installable on Android.
