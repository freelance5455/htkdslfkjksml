# English Master Pro v11.7 Android build

Release-ready private-test configuration. Google Play publication is not required for local APK testing.

- Release: non-debuggable, minified, resource-shrunk
- Debug: separate `.debug` application ID
- versionCode 117 / versionName 11.7.0
- minSdk 23 / targetSdk 36
- Real release AdMob IDs are injected from environment variables; debug uses Google test IDs.
- Release signing uses a private keystore supplied locally; the private key is never included in this ZIP.
- `EMP_BACKEND_URL` is optional; if omitted, the app can operate in local/offline mode.

See `RELEASE_READY.md` for the complete build steps.
