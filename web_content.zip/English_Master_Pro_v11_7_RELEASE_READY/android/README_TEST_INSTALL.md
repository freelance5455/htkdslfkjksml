# English Master Pro v11.6 — install test

The previous APK that was supplied for testing was unsigned, which causes Android to show **App not installed**.

For a quick device test, build the `testRelease` variant in Android Studio:

1. Open the `v115/android/` folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Select Build Variant** and choose `testRelease`.
4. Build the APK with **Build > Build APK(s)**.
5. Install the resulting `app-testRelease.apk`.

`testRelease` uses Android Studio's debug keystore and has package suffix `.test`. It is for device testing only, not Google Play.

For Google Play production, use the normal `release` variant with your own private upload keystore and real AdMob production IDs. Never put the private keystore in the public ZIP.
