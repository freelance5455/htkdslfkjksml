const lessons={
Speaking:[["🗣️","Greetings & Introductions","Introduce yourself naturally.","Hello! My name is Sara. Nice to meet you.","Beginner"],["💬","Daily Conversation","Practice questions used in everyday life.","What do you do? — I am a student.","Elementary"],["🎭","Role-play: At a Shop","Practice a short real-life conversation.","Could I have this one, please? How much is it?","Intermediate"]],
Listening:[["🎧","Main Idea","Train yourself to understand the main message.","Listen for keywords rather than translating every word.","Beginner"],["👂","Connected Speech","Notice how words change in natural speech.","What are you going to do? → Whaddaya gonna do?","Intermediate"],["🎙️","Everyday Dialogue","Understand a short conversation from context.","Could you say that again, please?","Intermediate"]],
Reading:[["📖","Reading Strategies","Use skimming and scanning before reading every word.","Read the title, predict the topic, then find key details.","Beginner"],["🔎","Vocabulary in Context","Infer unknown words from surrounding sentences.","The road was enormous; it was wide enough for six cars.","Elementary"],["📰","Short Article","Find the main idea and supporting details.","Technology can change how people learn and communicate.","Intermediate"]],
Writing:[["✍️","Build a Paragraph","Write a clear topic sentence and supporting ideas.","Learning English opens opportunities for education and work.","Beginner"],["🧩","Linking Ideas","Connect sentences using because, however, therefore and although.","I studied hard; therefore, I felt confident.","Intermediate"],["📝","Opinion Paragraph","State an opinion and support it with reasons and examples.","In my opinion, learning English is valuable because...","Upper-Intermediate"]]};
const questions=[["She ___ to school every day.","go","goes","going","went",1],["I have lived here ___ 2020.","for","since","from","during",1],["“Rapid” means:","slow","fast","old","quiet",1],["Correct sentence:","He don't like tea.","He doesn't like tea.","He doesn't likes tea.","He not like tea.",1],["If I had money, I ___ a new laptop.","buy","will buy","would buy","bought",2],["“Although it was raining, we went out.” expresses:","contrast","definition","place","permission",0],["By the time she arrived, they ___ dinner.","finish","finished","had finished","have finish",2],["Choose the best sentence:","English is useful internationally.","English useful many people.","Many English use people.","English good language.",0]];
const vocab=[
["reliable","able to be trusted","This app is reliable even when I study offline."],["improve","to become better","Practice every day to improve your English."],["confident","sure about your ability","She feels confident when speaking English."],["opportunity","a chance to do something","Learning English can create new opportunities."],["effective","successful in producing a result","Short daily practice can be very effective."],["curious","wanting to know or learn something","I am curious about how native speakers use this phrase."],["achieve","to successfully reach a goal","Small habits help you achieve bigger goals."]];
const defaultState={xp:0,streak:0,lastStudy:null,studySessions:{date:null,morning:false,afternoon:false,evening:false},level:"Beginner",lessons:0,tests:0,challengeDate:null,challengeDone:false,theme:"light",favorites:[],vocabIndex:0,wordsLearned:0,sessionSeconds:0,reviewed:0,completedLessons:[],dailyXP:0,dailyDate:null,goodStudyStreak:0,lastGoodStudyDate:null,weeklyAbilityUnlocked:false,weeklyAbilityUnlockedAt:null,dailyTestBest:0,dailyTestGood:false,lastQualifiedStudyDate:null,weeklyUnlockLevel:0};
let state=JSON.parse(localStorage.getItem("emp")||"null")||{...defaultState}; state={...defaultState,...state};
// V10 state migration: keep old progress and add adaptive-learning data.
state={...{aiMode:"tutor",skillXP:{Speaking:0,Listening:0,Reading:0,Writing:0},errors:[],reviewQueue:[],reviewStats:{due:0,done:0},dailyPlan:null,dailyPlanDate:null,roleplay:null,writingChecks:0,lessonMastery:{},streakBest:0,goodStudyStreak:0,lastGoodStudyDate:null,weeklyAbilityUnlocked:false,weeklyAbilityUnlockedAt:null,dailyTestBest:0,dailyTestGood:false,lastQualifiedStudyDate:null,weeklyUnlockLevel:0},...state};

let currentSkill="Speaking",currentLesson=0,selected={},quizSubmitted=false;
function today(){return new Date().toISOString().slice(0,10)}
function studySlot(){const h=new Date().getHours();if(h>=6&&h<12)return "morning";if(h>=12&&h<18)return "afternoon";if(h>=18&&h<24)return "evening";return null}
function refreshStudySessions(){const d=today();if(!state.studySessions||state.studySessions.date!==d)state.studySessions={date:d,morning:false,afternoon:false,evening:false};}
function renderStudySchedule(){refreshStudySessions();const slot=studySlot();const labels={morning:["☀️ صبح","06:00–12:00"],afternoon:["🌤️ بعدازظهر","12:00–18:00"],evening:["🌙 شب","18:00–24:00"]};const el=document.getElementById("studySlots");if(!el)return;el.innerHTML=Object.keys(labels).map(k=>`<div class="studySlot ${state.studySessions[k]?"done":""} ${slot===k?"current":""}"><b>${labels[k][0]}</b><small>${labels[k][1]}</small><small>${state.studySessions[k]?"✓ انجام شد":slot===k?"اکنون وقت مطالعه است":"هنوز انجام نشده"}</small></div>`).join("");const m=document.getElementById("studyScheduleMessage");if(m)m.textContent=state.studySessions.morning&&state.studySessions.afternoon&&state.studySessions.evening?"آفرین! هر سه نوبت امروز را انجام دادی. فاصله دادن بین درس‌ها کمک می‌کند خسته نشوی.":slot?`اکنون نوبت ${labels[slot][0]} است. یک درس کوتاه بخوان و بعد استراحت کن.`+" هدف این برنامه این است که از درس خواندن خسته نشوی.":"سه نوبت امروز را در زمان‌های مختلف انجام بده؛ بینشان استراحت داشته باش.";}
function showStudyReason(){alert("شما باید در سه وقت مختلف درس بخوانید تا مطالعه کوتاه و پراکنده باشد و از درس خواندن خسته نشوید. بین نوبت‌ها استراحت کنید و با انرژی برگردید.");}
function checkWeeklyStudyReward(){
  refreshStudySessions();
  refreshDaily();
  const d=today();
  const allSessions=!!(state.studySessions.morning&&state.studySessions.afternoon&&state.studySessions.evening);
  const goodTest=!!state.dailyTestGood;
  if(!allSessions || !goodTest || state.lastQualifiedStudyDate===d)return false;
  const prev=state.lastQualifiedStudyDate;
  const diff=prev?Math.round((new Date(d)-new Date(prev))/86400000):0;
  state.goodStudyStreak=prev&&diff===1?(state.goodStudyStreak||0)+1:1;
  state.lastQualifiedStudyDate=d;
  state.lastGoodStudyDate=d;
  const newLevel=Math.min(4,Math.floor(state.goodStudyStreak/7));
  if(newLevel>(state.weeklyUnlockLevel||0)){
    state.weeklyUnlockLevel=newLevel;
    state.weeklyAbilityUnlocked=newLevel>=1;
    state.weeklyAbilityUnlockedAt=d;
    const names=['AI Tutor','Advanced Speaking Feedback','B2–C1 Advanced Courses','Real AI Coach'];
    setTimeout(()=>v10Toast((empLang==='fa'?'🎉 توانایی جدید باز شد: ':'🎉 New ability unlocked: ')+(names[newLevel-1]||'Learning ability')),50);
  }
  return true;
}
function isWeeklyAbilityUnlocked(){return (state.weeklyUnlockLevel||0)>=1||!!state.weeklyAbilityUnlocked;}
function rewardLevel(){return Math.max((state.weeklyUnlockLevel||0),isWeeklyAbilityUnlocked()?1:0)}
function renderWeeklyReward(){
  const n=document.getElementById('weeklyRewardStreak'),bar=document.getElementById('weeklyRewardBar'),status=document.getElementById('weeklyRewardStatus'),btn=document.getElementById('aiNavBtn'),title=document.getElementById('weeklyRewardTitle'),pill=document.getElementById('weeklyRewardPill');
  const level=rewardLevel(), streak=Math.min(7,state.goodStudyStreak||0), next=Math.min(4,level+1);
  const names=empLang==='fa'?['AI Tutor','بازخورد پیشرفته گفتاری','دوره‌های پیشرفته B2–C1','AI Coach واقعی']:['AI Tutor','Advanced Speaking Feedback','B2–C1 Advanced Courses','Real AI Coach'];
  const unlocked=level>=4;
  const remaining=7-streak;
  if(n)n.textContent=level>=4?'4 / 4':`${streak} / 7`;
  if(bar)bar.style.width=(streak/7*100)+'%';
  if(title)title.textContent=unlocked?(empLang==='fa'?'همه توانایی‌ها باز شدند':'All learning abilities unlocked'):(empLang==='fa'?`هفته ${next}: ${names[next-1]||''}`:`Week ${next}: ${names[next-1]||''}`);
  if(pill)pill.textContent=empLang==='fa'?'🎁 جایزه‌های هفتگی مطالعه':'🎁 WEEKLY STUDY REWARDS';
  if(status)status.innerHTML=unlocked?(empLang==='fa'?'🔓 همه ۴ توانایی باز شده‌اند.':'🔓 All 4 learning abilities are unlocked.'):(empLang==='fa'?`هر روز ۳ نوبت مطالعه + یک آزمون خوب (حداقل ۶ از ۸) انجام بده. ${remaining} روز واجد شرایط دیگر تا باز شدن <b>${names[next-1]}</b> مانده است.`:`Complete all 3 daily study sessions + a good test (at least 6/8). ${remaining} qualifying day${remaining===1?'':'s'} remain to unlock <b>${names[next-1]}</b>.`);
  if(btn)btn.innerHTML=level>=1?'🤖<small>AI</small>':'🔒<small>AI</small>';
}
function markStudySession(){refreshStudySessions();const slot=studySlot();if(!slot)return;state.studySessions[slot]=true;checkWeeklyStudyReward();save();renderStudySchedule();renderWeeklyReward();}
function refreshDaily(){if(state.dailyDate!==today()){state.dailyDate=today();state.dailyXP=0;state.challengeDone=false;state.dailyTestBest=0;state.dailyTestGood=false}}
function save(){refreshDaily();localStorage.setItem("emp",JSON.stringify(state));update()}
function update(){
 refreshDaily(); refreshStudySessions(); renderStudySchedule(); const ids={xp:state.xp,streak:state.streak,level:state.level,profileLevel:state.level,lessonsDone:state.lessons,testsDone:state.tests,wordsLearned:state.wordsLearned};Object.entries(ids).forEach(([id,v])=>{const e=document.getElementById(id);if(e)e.textContent=v});
 const g=Math.min(100,state.dailyXP*2);const gb=document.getElementById("goalBar");if(gb)gb.style.width=g+"%";const gt=document.getElementById("goalText");if(gt)gt.textContent=state.dailyXP+" / 50 XP";
 const p=Math.min(100,state.xp%100),pb=document.getElementById("xpBar");if(pb)pb.style.width=p+"%";const pt=document.getElementById("xpProgressText");if(pt)pt.textContent=state.xp+" XP";
 const cb=document.getElementById("challengeBtn");if(cb)cb.textContent=state.challengeDate===today()&&state.challengeDone?"Completed ✓":"Start";
 const badge=document.getElementById("badgeText");if(badge)badge.textContent=state.xp>=500?"🏆 Master Habit":state.xp>=250?"🥇 Strong Learner":state.xp>=100?"⭐ Rising Learner":"🌱 Getting Started"; renderAchievements();renderWeeklyReward();
}
function openPage(id){if(id==="ai"&&!isWeeklyAbilityUnlocked()){document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById("dashboard").classList.add("active");update();v10Toast(empLang==='fa'?`🔒 AI Tutor بعد از ۷ روز مطالعه خوب باز می‌شود. پیشرفت: ${Math.min(7,state.goodStudyStreak||0)}/7`:`🔒 AI Tutor unlocks after 7 good study days. Progress: ${Math.min(7,state.goodStudyStreak||0)}/7`);return;}document.querySelectorAll(".page").forEach(p=>p.classList.remove("active"));document.getElementById(id).classList.add("active");scrollTo(0,0);update();if(id==="learn")renderSkills();if(id==="test")renderTest();if(id==="vocab")renderVocab();if(id==="review")renderReview();if(id==="profile")renderProfile();if(id==="ai")addAIWelcome()}
function renderSkills(){const icons={Speaking:"🗣️",Listening:"🎧",Reading:"📖",Writing:"✍️"};document.getElementById("skillList").innerHTML=Object.keys(lessons).map(k=>`<div class="lesson"><div class="icon">${icons[k]}</div><div style="flex:1"><h3>${k}</h3><p>${lessons[k].length} guided lessons · practice · feedback</p></div><button class="secondary" onclick="openSkill('${k}')">Open</button></div>`).join("")}
function openSkill(skill){currentSkill=skill;openPage("skillPage");document.getElementById("skillHero").innerHTML=`<div class="skillHero"><span class="pill">FOUR SKILLS</span><h1>${skill}</h1><p class="muted">Build your ${skill.toLowerCase()} ability through structured practice.</p></div>`;document.getElementById("lessonList").innerHTML=lessons[skill].map((l,i)=>`<div class="lesson"><div class="icon">${l[0]}</div><div style="flex:1"><h3>${i+1}. ${l[1]}</h3><p>${l[2]} · ${l[4]}</p></div><button class="secondary" onclick="startLesson(${i})">Start</button></div>`).join("")}
function startLesson(i){currentLesson=i;openPage("lessonPage");let l=lessons[currentSkill][i];document.getElementById("lessonBox").innerHTML=`<div class="lessonContent"><span class="pill">${currentSkill} · ${l[4]}</span><h1>${l[1]}</h1><p>${l[2]}</p><div class="example"><b>Key language</b><div class="word">${l[3]}</div></div><h3>Practice</h3><p>Read the example aloud, write your own sentence, and explain its meaning in your own words.</p><button class="primary" onclick="completeLesson()">Complete lesson · +20 XP</button>${currentSkill==="Speaking"?'<button class="secondary" onclick="modelSpeech()">🔊 Listen to model</button>':''}</div>`}
function markStudy(){const t=today();if(state.lastStudy!==t){if(state.lastStudy){const diff=Math.round((new Date(t)-new Date(state.lastStudy))/86400000);state.streak=diff===1?state.streak+1:1}else state.streak=1;state.lastStudy=t}}
function completeLesson(){markStudy();markStudySession();state.xp+=20;state.dailyXP+=20;state.skillXP[currentSkill]=(state.skillXP[currentSkill]||0)+20;const key=currentSkill+":"+currentLesson;if(!state.completedLessons.includes(key)){state.completedLessons.push(key);state.lessons++;}state.lessonMastery[key]=Math.min(100,(state.lessonMastery[key]||0)+25);save();v10GeneratePlan();v10Toast("Lesson mastered! +20 XP");openPage("dashboard")}
function renderTest(){selected={};quizSubmitted=false;document.getElementById("testBox").innerHTML=questions.map((q,i)=>`<div class="quizQ"><b>${i+1}. ${q[0]}</b>${q.slice(1,5).map((o,j)=>`<button class="option" onclick="choose(${i},${j},this)">${String.fromCharCode(65+j)}. ${o}</button>`).join("")}</div>`).join("")+`<button class="primary" onclick="finishTest()">Calculate my level</button><div id="result" class="result"></div>`}
function choose(i,j,el){selected[i]=j;el.parentElement.querySelectorAll(".option").forEach(x=>x.classList.remove("selected"));el.classList.add("selected")}
function finishTest(){
  markStudySession();
  if(Object.keys(selected).length<questions.length){alert(empLang==='fa'?'هر ۸ سوال را پاسخ بده.':'Answer all 8 questions first.');return}
  let score=Object.keys(selected).reduce((s,k)=>s+(selected[k]===questions[k][5]?1:0),0);
  let level=score<=2?'Beginner':score<=4?'Elementary':score<=6?'Intermediate':score===7?'Upper-Intermediate':'Advanced';
  markStudy(); state.level=level; state.xp+=score*10; state.dailyXP+=score*10; state.tests++;
  refreshDaily(); state.dailyTestBest=Math.max(state.dailyTestBest||0,score); state.dailyTestGood=(state.dailyTestBest||0)>=6;
  checkWeeklyStudyReward(); save(); renderWeeklyReward();
  document.getElementById('result').innerHTML=`<div class="card"><h2>${empLang==='fa'?'نتیجه':'Result'}: ${score}/8</h2><p>${score>=6?(empLang==='fa'?'آزمون خوب بود و برای جایزه هفتگی حساب شد.':'Good test! This counts toward your weekly reward.'):(empLang==='fa'?'برای جایزه هفتگی حداقل ۶ از ۸ بگیر.':'Score at least 6/8 for the weekly reward.')}</p><p>${empLang==='fa'?'سطح تقریبی':'Estimated level'}: <b>${level}</b></p></div>`;
}
async function startSpeaking(){
  const status=document.getElementById("speakStatus");
  const fallback=document.getElementById("speechFallback");
  if(status)status.textContent="🎤 Preparing microphone…";
  await requestMicPermission();
  if(fallback)fallback.style.display="none";

  // Android WebView/native host hook, if the wrapper provides one.
  try{
    if(window.AndroidBridge && typeof AndroidBridge.startSpeechRecognition==="function"){
      AndroidBridge.startSpeechRecognition("en-US");
      if(status)status.textContent="Listening… speak now.";
      return;
    }
  }catch(e){}

  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){
    // Some Android WebViews do not expose SpeechRecognition. Do not show an error dialog.
    // Switch directly to the offline practice method.
    if(status)status.textContent="Offline practice is ready. Type your sentence below.";
    if(fallback)fallback.style.display="block";
    return;
  }
  try{
    let r=new SR();
    r.lang="en-US";
    r.interimResults=false;
    r.continuous=false;
    r.maxAlternatives=1;
    r.onstart=()=>{if(status)status.textContent="🎙️ Listening… speak now.";};
    r.onresult=e=>{
      let t=e.results[0][0].transcript;
      if(status)status.innerHTML="You said: <b>"+escapeHtml(t)+"</b>";
      if(fallback)fallback.style.display="none";
      markStudy();markStudySession();state.xp+=5;state.dailyXP+=5;save();
    };
    r.onerror=e=>{
      // Never interrupt the learner with a Speech Recognition error dialog.
      if(status)status.textContent="Offline practice is ready. Type your sentence below.";
      if(fallback)fallback.style.display="block";
    };
    r.onend=()=>{};
    r.start();
  }catch(e){
    if(status)status.textContent="Offline practice is ready. Type your sentence below.";
    if(fallback)fallback.style.display="block";
  }
}
function submitSpeechFallback(){
  const input=document.getElementById("speechFallbackInput");
  const status=document.getElementById("speakStatus");
  const t=(input?.value||"").trim();
  if(!t){if(status)status.textContent="Type a sentence first.";return}
  if(status)status.innerHTML="Practice text: <b>"+escapeHtml(t)+"</b><br><span class='success'>✓ Saved as an offline speaking practice.</span>";
  markStudy();markStudySession();state.xp+=3;state.dailyXP+=3;save();
}
function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function modelSpeech(){
  const text=(document.getElementById("speakPrompt")?.textContent||"").replace(/[“”]/g,"");
  if("speechSynthesis" in window){
    try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang="en-US";speechSynthesis.speak(u);return;}catch(e){}
  }
  const status=document.getElementById("speakStatus");
  if(status)status.textContent="Audio playback is unavailable. Read the model sentence on screen and practice aloud.";
}
function dailyChallenge(){if(state.challengeDate===today()&&state.challengeDone){alert("Today's challenge is already complete.");return}state.challengeDate=today();state.challengeDone=true;markStudy();markStudySession();state.xp+=10;state.dailyXP+=10;save();alert("Challenge complete! +10 XP")}
function renderVocab(){const q=(document.getElementById("vocabSearch")?.value||"").trim().toLowerCase();const matches=vocab.filter(v=>!q||v[0].toLowerCase().includes(q)||v[1].toLowerCase().includes(q)||v[2].toLowerCase().includes(q));const v=matches[state.vocabIndex%Math.max(1,matches.length)]||vocab[0],fav=state.favorites.includes(v[0]);document.getElementById("vocabCard").innerHTML=`<span class="pill">${q?"SEARCH RESULTS":"WORD"} · ${v[0]}</span><h1>${v[0]}</h1><p class="meaning">${v[1]}</p><div class="example"><b>Example</b><div class="wordSmall">${v[2]}</div></div><button class="secondary" onclick="speakWord()">🔊 Listen</button><button class="secondary" onclick="toggleFavorite()">${fav?'★ Saved':'☆ Save word'}</button><button class="primary" onclick="nextVocab()">I know it · +5 XP</button>`}
function nextVocab(){markStudy();markStudySession();state.xp+=5;state.dailyXP+=5;state.wordsLearned++;state.reviewed++;state.vocabIndex=(state.vocabIndex+1)%vocab.length;save();renderVocab()}
function shuffleVocab(){state.vocabIndex=Math.floor(Math.random()*vocab.length);renderVocab()}
function speakWord(){
  const text=vocab[state.vocabIndex%vocab.length][0];
  if("speechSynthesis" in window){try{speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(text));return;}catch(e){}}
  alert("Audio is unavailable here. The word is: "+text);
}
function toggleFavorite(){const w=vocab[state.vocabIndex%vocab.length][0],i=state.favorites.indexOf(w);i<0?state.favorites.push(w):state.favorites.splice(i,1);save();renderVocab()}
function renderReview(){const words=state.favorites;document.getElementById("reviewBox").innerHTML=words.length?words.map(w=>{const v=vocab.find(x=>x[0]===w);return `<div class="lesson"><div><h3>${v[0]}</h3><p>${v[1]}</p><small>${v[2]}</small></div><button class="secondary" onclick="speakSpecific('${v[0]}')">🔊</button></div>`}).join(""): `<div class="card"><h3>No saved words yet</h3><p>Save words in Vocabulary and they will appear here.</p></div>`}
function speakSpecific(w){
  if("speechSynthesis" in window){try{speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(w));return;}catch(e){}}
  alert("Audio is unavailable here. The word is: "+w);
}


function addAIWelcome(){
  const box=document.getElementById("aiMessages");
  if(box && !box.children.length)addAIMessage("bot","Hi! I’m your Offline English AI Tutor 🤖. Ask me anything about English. No internet is required for this built-in tutor.");
}
const localTutorTips=[
  ["hello","Hello! 👋 Try: “Hello, my name is … Nice to meet you.”"],
  ["hi","Hi! A natural reply is: “Hi! How are you doing?”"],
  ["grammar","Grammar tip: use “doesn’t” with he/she/it: “She doesn’t like coffee.”"],
  ["past","Past simple example: “I visited my friend yesterday.” Use the past form for completed actions."],
  ["present","Present simple is common for routines: “I study English every day.”"],
  ["vocabulary","Vocabulary tip: learn a word with an example sentence, not alone."],
  ["pronunciation","Pronunciation tip: speak slowly first, then repeat the sentence at natural speed."],
  ["speaking","Speaking tip: use short sentences and focus on being understandable rather than perfect."],
  ["offline","Yes — this tutor works offline because its core replies are stored inside the app."],
  ["help","I can help with English grammar, vocabulary, pronunciation, speaking practice, and simple translations."],
  ["translate","Offline translation is limited, but I can explain common English phrases stored in this lesson pack."],
  ["thank","You're welcome! Keep practicing a little every day. 🌟"]
];
function offlineAIReply(message){
  const m=message.toLowerCase();
  for(const [key,reply] of localTutorTips){if(m.includes(key))return reply}
  if(/\b(what|how|why|when|where|who)\b/.test(m)){
    return "Good question! Try asking me about grammar, vocabulary, pronunciation, speaking, or an English sentence. I’ll give you an offline practice tip.";
  }
  if(/\b(correct|fix|check)\b/.test(m)){
    return "Send me the English sentence you want to check. I’ll give you a simple correction when it matches the offline rules I know.";
  }
  return "I’m your Offline English AI Tutor 🤖. I can practice English with you even without internet. Ask about grammar, vocabulary, pronunciation, or speaking.";
}
function addAIMessage(role,text){
  const box=document.getElementById("aiMessages"); if(!box)return;
  const row=document.createElement("div"); row.className="aiMsg "+role;
  row.innerHTML=escapeHtml(text).replace(/\n/g,"<br>");
  box.appendChild(row);box.scrollTop=box.scrollHeight;
}
function sendAIMessage(){
  const input=document.getElementById("aiInput"); const text=(input?.value||"").trim();
  if(!text)return;
  addAIMessage("user",text); input.value="";
  setTimeout(()=>{const reply=offlineAIReply(text);addAIMessage("bot",reply);},120);
}
function askAI(text){const input=document.getElementById("aiInput");if(input){input.value=text;sendAIMessage()}}
function speakAIReply(){
  const box=document.querySelector("#aiMessages .aiMsg.bot:last-child");
  if(!box)return;
  if("speechSynthesis" in window){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(box.textContent);u.lang="en-US";speechSynthesis.speak(u);return;}catch(e){}}
  const input=document.getElementById("aiInput");
  if(input)input.value="Audio unavailable. Please read the tutor reply on screen.";
}
function renderProfile(){const xpNext=state.xp<100?100:Math.ceil(state.xp/100)*100;document.getElementById("nextLevel").textContent=state.xp+" / "+xpNext+" XP";document.getElementById("favoriteCount").textContent=state.favorites.length}
function renderAchievements(){const defs=[['🔥','First Day',state.streak>=1],['📚','5 Lessons',state.lessons>=5],['🧠','10 Words',state.wordsLearned>=10],['🎯','First Test',state.tests>=1],['⭐','100 XP',state.xp>=100],['🏆','500 XP',state.xp>=500]];const box=document.getElementById("achievements"),count=document.getElementById("achievementCount");if(box)box.innerHTML=defs.map(d=>`<div class="achievement ${d[2]?'earned':''}"><span>${d[0]}</span><div><b>${d[1]}</b><small>${d[2]?'Unlocked':'Locked'}</small></div></div>`).join('');if(count)count.textContent=defs.filter(d=>d[2]).length+' / '+defs.length}
function toggleTheme(){state.theme=state.theme==="dark"?"light":"dark";document.body.classList.toggle("dark",state.theme==="dark");save()}
function resetAll(){if(confirm("Reset all progress?")){state={...defaultState};save();location.reload()}}

function updateOfflineStatus(){
  const e=document.getElementById("offlineStatus");
  if(!e)return;
  e.textContent=navigator.onLine?"🟢 Online":"🟠 Offline mode";
  window.addEventListener("online",()=>e.textContent="🟢 Online");
  window.addEventListener("offline",()=>e.textContent="🟠 Offline mode");
}
document.addEventListener("DOMContentLoaded",()=>{refreshDaily();document.body.classList.toggle("dark",state.theme==="dark");update();renderSkills();renderVocab();addAIWelcome();updateOfflineStatus();if("serviceWorker" in navigator){navigator.serviceWorker.register("sw.js").catch(()=>{})}let last=Date.now();setInterval(()=>{if(document.visibilityState==="visible"){state.sessionSeconds+=Math.round((Date.now()-last)/1000);last=Date.now()}},10000)})


/* =========================
   English Master Pro v11
   Extra features: ads, focus timer, PWA install, backup/restore, study stats
   ========================= */
const EMP_V9_AI = {
  adSenseClient: "", // Set your own ca-pub-XXXXXXXXXXXXXXXX publisher ID if using AdSense.
  adSlot: "",
  timer: 0,
  timerHandle: null,
  installPrompt: null
};

function v9Toast(msg){
  let t=document.getElementById("v9toast");
  if(!t){t=document.createElement("div");t.id="v9toast";t.className="v9-toast";document.body.appendChild(t)}
  t.textContent=msg;t.classList.add("show");clearTimeout(t._timer);
  t._timer=setTimeout(()=>t.classList.remove("show"),2200);
}

function v9LoadAds(){
  const box=document.getElementById("adBanner");
  if(!box)return;
  if(EMP_V9_AI.adSenseClient && EMP_V9_AI.adSlot){
    if(!document.querySelector('script[data-emp-adsense]')){
      const s=document.createElement("script");
      s.async=true;s.src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client="+encodeURIComponent(EMP_V9_AI.adSenseClient);
      s.crossOrigin="anonymous";s.dataset.empAdsense="1";document.head.appendChild(s);
    }
    box.innerHTML='<ins class="adsbygoogle" style="display:block" data-ad-client="'+escapeHtml(EMP_V9_AI.adSenseClient)+'" data-ad-slot="'+escapeHtml(EMP_V9_AI.adSlot)+'" data-ad-format="auto" data-full-width-responsive="true"></ins>';
    try{(window.adsbygoogle=window.adsbygoogle||[]).push({})}catch(e){}
  }else{
    box.innerHTML='<div class="ad-placeholder"><b>ADVERTISEMENT</b><span>Ad space · Configure your AdSense ID in app.js</span></div>';
  }
}

function v9OpenAdSettings(){
  alert("برای تبلیغ واقعی وب، EMP_V9_AI.adSenseClient و EMP_V9_AI.adSlot را در app.js با شناسه‌های خودت تنظیم کن. برای AdMob در Android WebView باید AdMob SDK در پروژه Android اضافه شود.");
}

function v9StartTimer(){
  if(EMP_V9_AI.timerHandle)return;
  if(!EMP_V9_AI.timer)EMP_V9_AI.timer=25*60;
  v9UpdateTimer();
  EMP_V9_AI.timerHandle=setInterval(()=>{
    EMP_V9_AI.timer--;
    if(EMP_V9_AI.timer<=0){
      clearInterval(EMP_V9_AI.timerHandle);EMP_V9_AI.timerHandle=null;EMP_V9_AI.timer=0;
      markStudy();state.xp+=10;state.dailyXP+=10;save();
      v9Toast("Focus session complete! +10 XP");
      if("vibrate" in navigator)navigator.vibrate([150,80,150]);
    }
    v9UpdateTimer();
  },1000);
}
function v9PauseTimer(){if(EMP_V9_AI.timerHandle){clearInterval(EMP_V9_AI.timerHandle);EMP_V9_AI.timerHandle=null}}
function v9ResetTimer(){v9PauseTimer();EMP_V9_AI.timer=25*60;v9UpdateTimer()}
function v9UpdateTimer(){
  const el=document.getElementById("focusTimer"); if(!el)return;
  const m=Math.floor(EMP_V9_AI.timer/60),s=EMP_V9_AI.timer%60;
  el.textContent=String(m).padStart(2,"0")+":"+String(s).padStart(2,"0");
}
function v9ExportProgress(){
  const blob=new Blob([JSON.stringify({version:"v10",exportedAt:new Date().toISOString(),state},null,2)],{type:"application/json"});
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="english-master-pro-v9-progress.json";a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
  v9Toast("Progress backup created");
}
function v9ImportProgress(file){
  if(!file)return;
  const r=new FileReader();
  r.onload=()=>{
    try{
      const data=JSON.parse(r.result);
      if(!data.state)throw new Error("invalid");
      state={...defaultState,...data.state};save();location.reload();
    }catch(e){alert("Invalid backup file.")}
  };r.readAsText(file);
}
function v9ShareProgress(){
  const text=`English Master Pro v11 — ${state.xp} XP, ${state.streak} day streak, ${state.lessons} lessons completed.`;
  if(navigator.share)navigator.share({title:"English Master Pro v11",text}).catch(()=>{});
  else navigator.clipboard?.writeText(text).then(()=>v9Toast("Progress copied")).catch(()=>alert(text));
}
function v9StudyMinutes(){
  const key="emp_v9_minutes", now=Date.now();
  const last=Number(localStorage.getItem(key)||now);
  const mins=Number(localStorage.getItem(key+"_total")||0);
  if(now-last>60000)localStorage.setItem(key+"_total",String(mins+Math.floor((now-last)/60000)));
  localStorage.setItem(key,String(now));
}
function v9Install(){
  if(EMP_V9_AI.installPrompt){EMP_V9_AI.installPrompt.prompt();EMP_V9_AI.installPrompt=null}
  else v9Toast("If supported, use your browser menu → Install app / Add to Home screen.");
}
window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();EMP_V9_AI.installPrompt=e;const b=document.getElementById("installBtn");if(b)b.style.display="inline-block"});
document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="hidden")v9StudyMinutes()});
document.addEventListener("DOMContentLoaded",()=>{
  const install=document.getElementById("installBtn"); if(install)install.style.display=EMP_V9_AI.installPrompt?"inline-block":"none";
  v9LoadAds();v9ResetTimer();
  if("serviceWorker" in navigator) navigator.serviceWorker.register("./sw.js").catch(()=>{});
  const ai=document.getElementById("aiMessages");
  if(ai && !ai.dataset.v9){ai.dataset.v9="1"; const note=document.createElement("div");note.className="aiMsg bot";note.textContent="v9 tip: Ask me to correct a sentence, explain a word, or create a short practice.";ai.appendChild(note)}
});

/* =========================
   English Master Pro v11
   Adaptive AI tutor + guided teaching
   ========================= */
const EMP_V9 = {
  mode: "tutor",
  drillIndex: 0,
  drillScore: 0,
  drillItems: [],
  smartSkill: "Speaking"
};

const v9ModeInfo = {
  tutor:["Personal Tutor","Ask a question, request an explanation, or send a sentence."],
  grammar:["Grammar Coach","I will focus on corrections, rules and examples."],
  conversation:["Conversation Coach","I will ask short questions and keep the conversation going."],
  vocab:["Vocabulary Coach","Learn words through meaning, example and recall."],
  pronunciation:["Pronunciation Coach","Practice natural English and listen to model sentences."]
};

function v9SetAIMode(mode){
  EMP_V9_AI.mode=v9ModeInfo[mode]?mode:"tutor";
  const t=document.getElementById("aiModeTitle"),h=document.getElementById("aiModeHint");
  if(t)t.textContent=v9ModeInfo[EMP_V9_AI.mode][0];
  if(h)h.textContent=v9ModeInfo[EMP_V9_AI.mode][1];
  v9Toast(v9ModeInfo[EMP_V9_AI.mode][0]+" ready");
}

function v9LevelAdvice(){
  const level=state.level||"Beginner";
  if(level==="Beginner")return "Use short sentences and learn one idea at a time.";
  if(level==="Elementary")return "Add one reason or detail to each answer.";
  if(level==="Intermediate")return "Try connectors such as because, however, although and therefore.";
  if(level==="Upper-Intermediate")return "Use natural collocations and vary your sentence structure.";
  return "Aim for precise vocabulary, natural phrasing and clear supporting details.";
}

function v9GrammarCheck(text){
  let original=text.trim(), corrected=original, notes=[];
  const rules=[
    [/\bI am study(ing)?\b/gi,"I am studying","After 'am', use the -ing form."],
    [/\bI am go(ing)?\b/gi,"I am going","After 'am', use the -ing form."],
    [/\bHe go\b/gi,"He goes","Use -s with he/she/it in the present simple."],
    [/\bShe go\b/gi,"She goes","Use -s with he/she/it in the present simple."],
    [/\bHe don't\b/gi,"He doesn't","Use doesn't with he/she/it."],
    [/\bShe don't\b/gi,"She doesn't","Use doesn't with he/she/it."],
    [/\bI has\b/gi,"I have","Use have with I/you/we/they."],
    [/\bHe have\b/gi,"He has","Use has with he/she/it."],
    [/\bmore better\b/gi,"better","Do not use 'more' with 'better'."],
    [/\bdiscuss about\b/gi,"discuss","'Discuss' normally does not need 'about'."]
  ];
  for(const [rx,repl,note] of rules){if(rx.test(corrected)){corrected=corrected.replace(rx,repl);notes.push(note)}}
  if(corrected && !/[.!?]$/.test(corrected)) corrected+=".";
  return {original,corrected,notes};
}

function v9ExtractTarget(message){
  const m=message.trim();
  const patterns=[/correct my sentence:\s*(.+)/i,/check this:\s*(.+)/i,/fix:\s*(.+)/i,/correct:\s*(.+)/i];
  for(const p of patterns){const hit=m.match(p);if(hit)return hit[1]}
  if(/[.!?]/.test(m) && /\b(i|you|he|she|we|they|my|this|that)\b/i.test(m))return m.replace(/^.*?:/,'').trim();
  return null;
}

function v9AIReply(message){
  const m=message.toLowerCase().trim();
  const target=v9ExtractTarget(message);
  if(target){
    const r=v9GrammarCheck(target);
    if(r.notes.length){
      return `✍️ Correction\nYour sentence: ${r.original}\nBetter: ${r.corrected}\nWhy: ${r.notes.join(" ")}\n\nNow try another sentence using the same rule.`;
    }
    return `✅ Your sentence looks good: ${r.corrected}\n\n${v9LevelAdvice()} Try adding one more detail to make it stronger.`;
  }
  if(/\b(hello|hi|conversation|talk|speaking)\b/.test(m)){
    return "💬 Let’s practice. What did you do today? Answer in 1–2 English sentences. I’ll correct important mistakes and ask the next question.";
  }
  if(/\b(grammar|tense|verb|doesn't|doesnt|past|present|future)\b/.test(m)){
    return "📘 Mini lesson: Present simple describes routines and facts. Example: “I study English every day.” With he/she/it, add -s: “She studies English.” Now write one sentence about your daily routine.";
  }
  if(/\b(vocab|vocabulary|word|words)\b/.test(m)){
    return "🧠 Vocabulary set: improve = become better; confident = sure of your ability; reliable = able to be trusted; opportunity = a chance; achieve = reach a goal. Choose one word and make your own sentence.";
  }
  if(/\b(pronunciation|pronounce|accent)\b/.test(m)){
    return "🔊 Pronunciation practice: say “I would like to improve my English.” slowly three times, then once naturally. Focus on clear word stress rather than speaking very fast.";
  }
  if(/\b(why|tired|three times|three sessions)\b/.test(m)){
    return "📅 Short study sessions are used so you can practice, rest, and return with attention instead of studying for one long tiring session.";
  }
  if(/\b(help|what can you do|how can you help)\b/.test(m)){
    return "🤖 I can teach grammar step-by-step, correct common mistakes, practice conversation, build vocabulary, give pronunciation drills, and create a short lesson for your current level.";
  }
  if(/\b(translate|meaning)\b/.test(m)){
    return "Send me the English word or sentence. I can explain its meaning, give an example, and create a short practice question.";
  }
  return `🤖 Let’s learn together. ${v9LevelAdvice()}\n\nTell me a topic (school, work, travel, daily life) or send an English sentence and I’ll turn it into practice.`;
}

function v9StartAIDrill(){
  const pool=[
    ["She ___ English every day.","study","studies","studying",1,"Present simple with she/he/it uses -s."],
    ["I ___ to school yesterday.","go","went","going",1,"Use the past form for a completed action yesterday."],
    ["Choose the natural sentence.","I am agree.","I agree.","I agreeing.",1,"'Agree' is normally a verb, so say 'I agree'."],
    ["Choose the best word: This plan is very ___.","effective","effect","effectively",0,"Effective is the adjective."],
    ["Complete: I have lived here ___ 2020.","for","since","during",1,"Use since with a starting point such as 2020."]
  ];
  EMP_V9_AI.drillItems=pool.slice();EMP_V9_AI.drillIndex=0;EMP_V9_AI.drillScore=0;v9RenderDrill();
}
function v9RenderDrill(){
  const box=document.getElementById("aiDrill");if(!box)return;
  const i=EMP_V9_AI.drillIndex, q=EMP_V9_AI.drillItems[i];
  if(!q){box.innerHTML=`<div class="card"><h3>🎉 Drill complete</h3><p>You scored <b>${EMP_V9_AI.drillScore}/${EMP_V9_AI.drillItems.length}</b>. Keep practicing a little each day.</p><button class="primary" onclick="v9StartAIDrill()">Try again</button></div>`;state.xp+=EMP_V9_AI.drillScore*2;state.dailyXP+=EMP_V9_AI.drillScore*2;markStudy();save();return;}
  box.innerHTML=`<div class="aiQuestion"><span class="pill">QUESTION ${i+1}/5</span><h3>${q[0]}</h3>${q.slice(1,4).map((o,j)=>`<button class="option" onclick="v9AnswerDrill(${j},this)">${String.fromCharCode(65+j)}. ${o}</button>`).join("")}<div id="v9DrillFeedback"></div></div>`;
}
function v9AnswerDrill(choice,el){
  const q=EMP_V9_AI.drillItems[EMP_V9_AI.drillIndex],fb=document.getElementById("v9DrillFeedback");
  document.querySelectorAll("#aiDrill .option").forEach(b=>b.disabled=true);
  if(choice===q[4]){EMP_V9_AI.drillScore++;el.classList.add("correct");fb.innerHTML=`<div class="aiFeedback good">✅ Correct. ${q[5]}</div>`}
  else{el.classList.add("wrong");fb.innerHTML=`<div class="aiFeedback neutral">Not quite. Correct answer: <b>${q[4]===0?'A':q[4]===1?'B':'C'}</b>. ${q[5]}</div>`}
  setTimeout(()=>{EMP_V9_AI.drillIndex++;v9RenderDrill()},900);
}

function v9SmartLesson(){
  const skill=EMP_V9_AI.smartSkill || Object.keys(lessons)[Math.floor(Math.random()*Object.keys(lessons).length)];
  const bank={
    Speaking:["Daily introductions","Learn to introduce yourself clearly.","Hello, my name is Sara. I’m a student, and I’m learning English.","Change the example to your own name and situation."],
    Listening:["Listen for the main idea","Do not translate every word. Catch the topic and key words first.","A short conversation can often be understood from a few important words.","Write three keywords you would listen for in a conversation about school."],
    Reading:["Find the main idea","Read the title first, predict the topic, then look for supporting details.","Learning a language becomes easier when practice is regular and focused.","Write the main idea of the sentence in your own words."],
    Writing:["Build a clear paragraph","Start with one main idea, then add a reason and an example.","Learning English is useful because it helps me communicate with more people.","Write 2–3 sentences about why you are learning English."]
  };
  const x=bank[skill];openPage("lessonPage");
  document.getElementById("lessonBox").innerHTML=`<div class="lessonContent smartLesson"><span class="pill">V9 SMART LESSON · ${skill}</span><h1>${x[0]}</h1><p>${x[1]}</p><div class="example"><b>Teacher example</b><div class="word">${x[2]}</div></div><div class="smartStep"><b>Step 1 · Understand</b><p>${v9LevelAdvice()}</p></div><div class="smartStep"><b>Step 2 · Your turn</b><p>${x[3]}</p><textarea id="v9LessonAnswer" placeholder="Write your answer in English…"></textarea><button class="primary" onclick="v9CheckLessonAnswer()">Check my answer</button></div><div id="v9LessonFeedback"></div><button class="secondary" onclick="openPage('ai')">🤖 Continue with AI Tutor</button></div>`;
}
function v9CheckLessonAnswer(){
  const el=document.getElementById("v9LessonAnswer"),fb=document.getElementById("v9LessonFeedback");const text=(el?.value||"").trim();
  if(!text){fb.innerHTML='<div class="aiFeedback neutral">Write at least one English sentence first.</div>';return}
  const r=v9GrammarCheck(text);let msg=r.notes.length?`<b>Small correction:</b> ${r.corrected}<br>${r.notes.join(" ")}`:`<b>Good work!</b> ${r.corrected}<br>Now try adding one more detail.`;
  fb.innerHTML=`<div class="aiFeedback ${r.notes.length?'neutral':'good'}">${msg}</div><button class="primary" onclick="v9FinishSmartLesson()">Finish lesson · +25 XP</button>`;
}
function v9FinishSmartLesson(){markStudy();markStudySession();state.xp+=25;state.dailyXP+=25;state.lessons++;save();v9Toast("Smart lesson complete! +25 XP");openPage("dashboard")}

// Upgrade the old AI message pipeline without requiring an internet API.
const _v9OldSendAIMessage=window.sendAIMessage;
window.sendAIMessage=function(){
  const input=document.getElementById("aiInput"),text=(input?.value||"").trim();if(!text)return;
  addAIMessage("user",text);input.value="";setTimeout(()=>addAIMessage("bot",v9AIReply(text)),140);
};

// Upgrade lesson pages: every normal lesson gets a teaching explanation and a small self-check.
const _v9OldStartLesson=window.startLesson;
window.startLesson=function(i){
  currentLesson=i;openPage("lessonPage");const l=lessons[currentSkill][i];
  const tip=currentSkill==="Speaking"?"Say the model sentence slowly, then replace one part with your own information.":currentSkill==="Listening"?"Listen for the key words first. You do not need to understand every word.":currentSkill==="Reading"?"Read the title and first sentence, predict the topic, then find the important details.":"Write one clear sentence first. Then add a reason or example.";
  document.getElementById("lessonBox").innerHTML=`<div class="lessonContent"><span class="pill">${currentSkill} · ${l[4]} · V9</span><h1>${l[1]}</h1><p>${l[2]}</p><div class="example"><b>Teacher example</b><div class="word">${l[3]}</div></div><div class="smartStep"><b>Step 1 · Learn</b><p>${tip}</p></div><div class="smartStep"><b>Step 2 · Practice</b><p>Write your own sentence about this topic.</p><textarea id="v9NormalAnswer" placeholder="Your English sentence…"></textarea><button class="secondary" onclick="v9CheckNormalLesson()">Check sentence</button><div id="v9NormalFeedback"></div></div><button class="primary" onclick="completeLesson()">Complete lesson · +20 XP</button>${currentSkill==="Speaking"?'<button class="secondary" onclick="modelSpeech()">🔊 Listen to model</button>':''}<button class="secondary" onclick="v9SmartLesson()">✨ More practice</button></div>`;
};
function v9CheckNormalLesson(){const t=(document.getElementById("v9NormalAnswer")?.value||"").trim(),fb=document.getElementById("v9NormalFeedback");if(!t){fb.innerHTML='<div class="aiFeedback neutral">Write a sentence first.</div>';return}const r=v9GrammarCheck(t);fb.innerHTML=`<div class="aiFeedback ${r.notes.length?'neutral':'good'}">${r.notes.length?'✍️ '+r.corrected+' — '+r.notes.join(' '):'✅ Looks good: '+r.corrected}</div>`}


/* =========================
   English Master Pro v11
   Adaptive academy, spaced review, writing coach and role-play.
   Core features work offline; no external AI service is required.
   ========================= */
const EMP_V10 = {roleplayTurn:0, roleplay:null, reviewIndex:0};

function v10LevelInfo(){
  const xp=state.xp||0;
  if(xp>=1800)return {name:"C1",title:"Advanced",next:2500};
  if(xp>=1100)return {name:"B2",title:"Upper-Intermediate",next:1800};
  if(xp>=600)return {name:"B1",title:"Intermediate",next:1100};
  if(xp>=250)return {name:"A2",title:"Elementary",next:600};
  return {name:"A1",title:"Beginner",next:250};
}
function v10WeakSkill(){
  const entries=Object.entries(state.skillXP||{});
  entries.sort((a,b)=>a[1]-b[1]);
  return entries[0]?.[0]||"Speaking";
}
function v10Health(){
  const xp=state.dailyXP||0, streak=Math.min(10,state.streak||0), errors=state.errors?.length||0;
  let score=Math.min(100,35+xp*1.2+streak*4-(errors>8?10:0));
  return Math.max(20,Math.round(score));
}
function v10GeneratePlan(force=false){
  const d=today();
  if(!force && state.dailyPlanDate===d && state.dailyPlan)return renderV10Academy();
  const level=v10LevelInfo(), weak=v10WeakSkill();
  const tasks={
    Speaking:["🎤 Speaking Sprint","Answer two real-life questions aloud, then type one answer if your microphone is unavailable.","+15 XP"],
    Listening:["🎧 Listening Sprint","Read the model sentence, hide it, then type what you remember. Focus on the main idea.","+15 XP"],
    Reading:["📖 Reading Sprint","Read a short paragraph and write its main idea in one sentence.","+15 XP"],
    Writing:["✍️ Writing Sprint","Write 3–5 sentences. The Writing Lab will check grammar and clarity.","+15 XP"]
  };
  const t=tasks[weak];
  state.dailyPlanDate=d;state.dailyPlan=[
    {type:"lesson",title:t[0],desc:t[1],xp:t[2],action:`openSkill('${weak}')`},
    {type:"review",title:"🃏 Smart Review",desc:"Review 5 saved or due vocabulary words.",xp:"+10 XP",action:"v10ReviewSession()"},
    {type:"ai",title:"🤖 AI Challenge",desc:`Complete a short ${level.name} challenge with the tutor.`,xp:"+10 XP",action:"v9StartAIDrill()"}
  ];
  save();
  renderV10Academy();
}
function renderV10Academy(){
  const plan=document.getElementById("v10Plan");if(!plan)return;
  const level=v10LevelInfo(),weak=v10WeakSkill();
  const title=document.getElementById("v10PlanTitle"),reason=document.getElementById("v10PlanReason");
  if(title)title.textContent=`Today’s ${level.name} plan · ${level.title}`;
  if(reason)reason.textContent=`Your plan focuses on ${weak.toLowerCase()} because it currently has the least practice. Small sessions are used to reduce fatigue.`;
  const items=state.dailyPlan||[];
  plan.innerHTML=items.map((x,i)=>`<div class="card academyTask"><span class="pill">STEP ${i+1}</span><h3>${x.title}</h3><p>${x.desc}</p><div class="sectionHead"><small>${x.xp}</small><button class="primary" onclick="${x.action}">Start</button></div></div>`).join("");
  const health=v10Health(),bar=document.getElementById("v10HealthBar"),lab=document.getElementById("v10HealthLabel"),txt=document.getElementById("v10HealthText");
  if(bar)bar.style.width=health+"%";if(lab)lab.textContent=health>=75?"Excellent":health>=50?"Good":"Needs attention";
  if(txt)txt.textContent=`Level ${level.name}. ${state.lessons||0} lessons, ${state.wordsLearned||0} words and ${state.streak||0} day streak. Keep sessions short and consistent.`;
  renderV10Errors();renderV10ReviewInfo();
}
function v10RecordError(original,corrected,note){
  if(!original)return;
  state.errors=state.errors||[];
  const exists=state.errors.find(e=>e.original===original);
  if(exists){exists.count=(exists.count||1)+1;exists.corrected=corrected;exists.note=note;}
  else state.errors.unshift({original,corrected,note,count:1,date:today()});
  state.errors=state.errors.slice(0,20);save();
}
function renderV10Errors(){
  const box=document.getElementById("v10Errors");if(!box)return;
  const es=(state.errors||[]).slice(0,4);
  box.innerHTML=es.length?es.map(e=>`<div class="v10Error"><b>${escapeHtml(e.original)}</b><small>→ ${escapeHtml(e.corrected)}</small><span>${escapeHtml(e.note||"")} · ${e.count||1}×</span></div>`).join(""):'<p class="muted">No saved mistakes yet. The tutor will add useful corrections here.</p>';
}
function v10ReviewInfo(){
  const words=state.favorites||[];
  return words.map(w=>vocab.find(v=>v[0]===w)).filter(Boolean);
}
function renderV10ReviewInfo(){
  const box=document.getElementById("v10ReviewNext");if(!box)return;
  const words=v10ReviewInfo();
  box.innerHTML=words.length?`<b>${words.length}</b> saved words ready for review.<br><small>${escapeHtml(words.slice(0,3).map(v=>v[0]).join(" · "))}</small>`:'<p class="muted">Save vocabulary words first. They will appear here.</p>';
}
function v10ReviewSession(){
  const words=v10ReviewInfo();
  if(!words.length){v10Toast("Save some vocabulary words first.");openPage("vocab");return;}
  let i=0,score=0;
  const box=document.getElementById("v10ReviewNext");
  if(!box)return;
  function show(){
    const v=words[i];
    box.innerHTML=`<div class="v10Flash"><span class="pill">${i+1}/${words.length}</span><h3>${escapeHtml(v[0])}</h3><p class="muted">What does this word mean?</p><button class="secondary" onclick="this.nextElementSibling.hidden=false">Show meaning</button><div hidden><p><b>${escapeHtml(v[1])}</b></p><p>${escapeHtml(v[2])}</p><button class="primary" onclick="window.__v10ReviewGood()">I remembered · +2 XP</button><button class="secondary" onclick="window.__v10ReviewNext()">Need more review</button></div></div>`;
  }
  window.__v10ReviewGood=()=>{score++;state.reviewed=(state.reviewed||0)+1;state.xp+=2;state.dailyXP+=2;state.reviewStats=state.reviewStats||{due:0,done:0};state.reviewStats.done++;save();window.__v10ReviewNext()};
  window.__v10ReviewNext=()=>{i++;if(i>=words.length){v10Toast(`Review complete: ${score}/${words.length} remembered`);renderV10Academy();}else show()};
  show();
}
function v10Roleplay(type){
  const data={
    job:["Job interview","Hello. Thank you for coming. Can you tell me about yourself?",["I am a student and I am learning English.","I am hardworking and I enjoy learning new skills."]],
    travel:["Airport","Good morning. May I see your passport, please?",["Here you are.","I am traveling to Dubai for a holiday."]],
    shop:["Shopping","Hello. Can I help you find something?",["Yes, I am looking for a shirt.","How much is this one?"]],
    school:["School","What subject do you enjoy most?",["I enjoy English because I can communicate with more people.","I want to improve my speaking."]]
  };
  EMP_V10.roleplay=data[type];EMP_V10.roleplayTurn=0;
  const box=document.getElementById("v10RoleplayBox");if(!box)return;
  box.innerHTML=`<div class="roleplay"><span class="pill">${data[type][0]}</span><h3>🤖 Coach</h3><p>${data[type][1]}</p><div class="aiQuick">${data[type][2].map((x,i)=>`<button class="secondary" onclick="v10RoleAnswer(${i})">${escapeHtml(x)}</button>`).join("")}</div><div id="v10RoleFeedback" class="aiFeedback neutral">Choose a reply. I’ll continue the conversation.</div></div>`;
}
function v10RoleAnswer(i){
  const r=EMP_V10.roleplay,fb=document.getElementById("v10RoleFeedback");if(!r||!fb)return;
  const answer=r[2][i];const check=v9GrammarCheck(answer);
  const positive=check.notes.length?`Your idea is good. A clearer version is: <b>${escapeHtml(check.corrected)}</b><br>${escapeHtml(check.notes.join(" "))}`:`Good choice. <b>${escapeHtml(answer)}</b>`;
  const next=["What do you do every day?","Why are you learning English?","What would you like to improve?","Can you give me one more detail?"][(EMP_V10.roleplayTurn++)%4];
  fb.innerHTML=`${positive}<hr><b>🤖 Coach:</b> ${next}`;
  if(check.notes.length)v10RecordError(answer,check.corrected,check.notes.join(" "));
  state.xp+=2;state.dailyXP+=2;save();
}
function v10CheckWriting(){
  const input=document.getElementById("v10Writing"),box=document.getElementById("v10WritingResult");const text=(input?.value||"").trim();if(!text){if(box)box.innerHTML='<div class="aiFeedback neutral">Write a few sentences first.</div>';return;}
  const sentences=text.split(/[.!?]+/).map(x=>x.trim()).filter(Boolean);let corrected=text,notes=[];
  for(const s of sentences){const r=v9GrammarCheck(s);if(r.notes.length){v10RecordError(s,r.corrected,r.notes.join(" "));corrected=corrected.replace(s,r.corrected);notes.push(...r.notes)}}
  state.writingChecks=(state.writingChecks||0)+1;state.xp+=5;state.dailyXP+=5;save();
  const quality=sentences.length>=5?"Great detail":sentences.length>=3?"Good paragraph":"Try adding one or two more sentences";
  if(box)box.innerHTML=`<div class="aiFeedback ${notes.length?'neutral':'good'}"><b>${quality}</b><p>${notes.length?'Suggested revision: '+escapeHtml(corrected):'Your common grammar patterns look good. Now add a reason, example, or detail.'}</p>${notes.length?'<small>'+escapeHtml(notes.join(' '))+'</small>':''}</div>`;
}
// Make the existing grammar coach feed the V10 error notebook.
const _v10OriginalGrammarCheck=v9GrammarCheck;
v9GrammarCheck=function(text){const r=_v10OriginalGrammarCheck(text);if(r.notes.length){try{v10RecordError(r.original,r.corrected,r.notes.join(" "))}catch(e){}}return r};

// Add V10 academy rendering without disturbing the existing navigation.
const _v10OpenPage=window.openPage;
window.openPage=function(id){_v10OpenPage(id);if(id==='academy'){v10GeneratePlan();renderV10Academy();}};

document.addEventListener('DOMContentLoaded',()=>{try{v10GeneratePlan();}catch(e){}});

/* ========================= V11 UPGRADE ========================= */
const V11_API_BASE = (window.EMP_API_BASE || localStorage.getItem('emp_api_base') || '').replace(/\/$/,'');
let v11AuthMode='login';
let v11User=null;
function v11Api(path,options={}){
  const headers={'Content-Type':'application/json',...(options.headers||{})};
  const token=localStorage.getItem('emp_token'); if(token) headers.Authorization='Bearer '+token;
  return fetch((V11_API_BASE||'')+path,{...options,headers}).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Request failed');return d;});
}
function openAccount(){const m=document.getElementById('accountModal');if(m){m.classList.add('show');m.setAttribute('aria-hidden','false');}document.getElementById('authName').style.display=v11AuthMode==='login'?'none':'block';}
function closeAccount(){const m=document.getElementById('accountModal');if(m){m.classList.remove('show');m.setAttribute('aria-hidden','true');}}
function toggleAuthMode(){v11AuthMode=v11AuthMode==='login'?'register':'login';document.getElementById('authTitle').textContent=v11AuthMode==='login'?'Sign in':'Create account';document.getElementById('authToggle').textContent=v11AuthMode==='login'?'Create an account':'Already have an account? Sign in';document.getElementById('authName').style.display=v11AuthMode==='login'?'none':'block';}
async function submitAuth(){
  const email=document.getElementById('authEmail').value.trim(),password=document.getElementById('authPassword').value,name=document.getElementById('authName').value.trim()||'English Learner',msg=document.getElementById('authMessage');
  if(!email||!password){msg.textContent='Enter your email and password.';return;}
  msg.textContent='Connecting securely…';
  try{const d=await v11Api(v11AuthMode==='login'?'/api/auth/login':'/api/auth/register',{method:'POST',body:JSON.stringify({email,password,name})});localStorage.setItem('emp_token',d.token);v11User=d.user;msg.textContent='Signed in ✓';closeAccount();applyV11User();await syncNow();}
  catch(e){msg.textContent=(V11_API_BASE?'Server: ':'Demo mode: ')+e.message;if(!V11_API_BASE){v11User={name,email,plan:'free',demo:true};localStorage.setItem('emp_demo_user',JSON.stringify(v11User));applyV11User();closeAccount();}}
}
function googleLogin(){if(V11_API_BASE){location.href=V11_API_BASE+'/auth/google';}else{document.getElementById('authMessage').textContent='Google Sign-In needs the V11 backend and your Google OAuth credentials.';}}
function applyV11User(){
  const u=v11User||JSON.parse(localStorage.getItem('emp_demo_user')||'null');if(!u)return;
  document.getElementById('accountName').textContent=u.name||'English Learner';document.getElementById('accountStatus').textContent=(u.plan||'free').toUpperCase()+' plan · cloud account';
  document.getElementById('accountBtn').textContent='👤 Account';
  document.getElementById('accountProfileName').textContent=u.name||'English Learner';document.getElementById('accountEmail').textContent=u.email||'';document.getElementById('accountAvatar').textContent=(u.name||'E').slice(0,1).toUpperCase();
  const coin=document.getElementById('coinCount');if(coin)coin.textContent=(state.coins||0)+' coins';
}
async function syncNow(){
  const box=document.getElementById('syncStatus'); if(box)box.textContent='Syncing…';
  if(!localStorage.getItem('emp_token')){if(box)box.textContent='Local-only mode. Sign in to enable cloud sync.';return;}
  try{await v11Api('/api/progress',{method:'PUT',body:JSON.stringify({progress:state})});const d=await v11Api('/api/progress');if(d.progress&&d.progress.xp>state.xp){state={...state,...d.progress};localStorage.setItem('emp',JSON.stringify(state));update();}if(box)box.textContent='✓ Synced to server';}
  catch(e){if(box)box.textContent='Sync unavailable; local progress is safe on this device.';}
}
function logoutAccount(){localStorage.removeItem('emp_token');v11User=null;document.getElementById('accountName').textContent='Guest learner';document.getElementById('accountStatus').textContent='Local progress · sign in for cloud sync';document.getElementById('accountBtn').textContent='🔐 Sign in';document.getElementById('syncStatus').textContent='Local-only mode';}
async function checkBackend(){const el=document.getElementById('realAIStatus');if(!el)return;el.textContent='Checking…';try{const d=await v11Api('/api/health');el.textContent=d.aiConfigured?'✓ Secure AI backend connected':'Backend connected · AI key not configured';}catch(e){el.textContent='Offline/local AI mode';}}
async function sendRealAI(message){
  if(!V11_API_BASE)throw new Error('No backend configured');
  const d=await v11Api('/api/ai/chat',{method:'POST',body:JSON.stringify({message,level:state.level,mode:state.aiMode||'tutor',progress:{xp:state.xp,streak:state.streak,errors:(state.errors||[]).slice(0,8)}})});return d.reply;
}
const _v11SendAIMessage=sendAIMessage;
sendAIMessage=async function(){const input=document.getElementById('aiInput'),text=(input?.value||'').trim();if(!text)return;addAIMessage('user',text);input.value='';addAIMessage('bot','⏳ Thinking…');const box=document.getElementById('aiMessages');try{const reply=rewardLevel()>=4?await sendRealAI(text):offlineAIReply(text);if(box&&box.lastElementChild)box.lastElementChild.remove();addAIMessage('bot',reply);state.aiHistory=state.aiHistory||[];state.aiHistory.push({role:'user',text,date:today()},{role:'assistant',text:reply,date:today()});state.aiHistory=state.aiHistory.slice(-30);state.xp+=2;state.dailyXP+=2;save();syncNow();}catch(e){if(box&&box.lastElementChild)box.lastElementChild.remove();const reply=offlineAIReply(text)+'\n\nTip: connect the V11 backend to unlock real AI responses.';addAIMessage('bot',reply);}};
async function startCheckout(plan){if(!localStorage.getItem('emp_token')){openAccount();document.getElementById('authMessage').textContent='Create/sign in to an account before subscribing.';return;}if(!V11_API_BASE){alert('Premium checkout needs the V11 backend and a payment provider configuration.');return;}try{const d=await v11Api('/api/billing/checkout',{method:'POST',body:JSON.stringify({plan})});if(d.url)location.href=d.url;}catch(e){alert(e.message);}}
function requirePremium(feature){if((v11User?.plan||'free')!=='premium'){openPage('premium');v11Toast('🔒 '+feature+' is available in Premium.');return false;}return true;}
async function enableNotifications(){
  if(!('Notification' in window)){alert('Notifications are not supported in this WebView/browser.');return;}
  const permission=await Notification.requestPermission();if(permission!=='granted'){alert('Notification permission was not granted.');return;}
  localStorage.setItem('emp_notifications','on');new Notification('English Master 📚',{body:'Your next English study session is ready!'});v11Toast('🔔 Daily reminders enabled on this device.');
  if('serviceWorker' in navigator&&V11_API_BASE){try{const keyData=await v11Api('/api/notifications/public-key');if(!keyData.publicKey)throw new Error('Push server key not configured');const reg=await navigator.serviceWorker.ready;const raw=Uint8Array.from(atob(keyData.publicKey.replace(/-/g,'+').replace(/_/g,'/')),c=>c.charCodeAt(0));const sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:raw});await v11Api('/api/notifications/subscribe',{method:'POST',body:JSON.stringify({subscription:{...sub,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone}})});}catch(e){/* local reminder remains enabled */}}
}
function v11ScheduleReminder(){if(localStorage.getItem('emp_notifications')!=='on')return;const slot=studySlot();if(!slot)return;}
async function loadLeaderboard(){const box=document.getElementById('leaderboardBox');if(!box)return;box.innerHTML='<div class="card">Loading…</div>';try{const d=await v11Api('/api/leaderboard');box.innerHTML=d.items.map((u,i)=>`<div class="lesson"><div class="icon">${i<3?['🥇','🥈','🥉'][i]:'🏅'}</div><div style="flex:1"><h3>${escapeHtml(u.name)}</h3><p>${u.xp} XP · ${escapeHtml(u.level||'Beginner')}</p></div></div>`).join('')||'<div class="card">No public scores yet.</div>';}catch(e){box.innerHTML='<div class="card">Leaderboard needs the V11 backend. Your private progress still works offline.</div>';}}
function v11SpeakingScore(transcript){
  if(rewardLevel()<2){v10Toast(empLang==='fa'?'🔒 بازخورد پیشرفته گفتاری بعد از ۱۴ روز واجد شرایط باز می‌شود.':'🔒 Advanced speaking feedback unlocks after 14 qualifying days.');return;}
  const target=(document.getElementById('speakPrompt')?.textContent||'').replace(/[“”]/g,'').trim().toLowerCase(),said=(transcript||'').toLowerCase();const tw=target.split(/\s+/).filter(Boolean),sw=said.split(/\s+/).filter(Boolean);const overlap=tw.filter(w=>said.includes(w.replace(/[^a-z']/g,''))).length;const pronunciation=Math.max(20,Math.min(100,Math.round((overlap/Math.max(1,tw.length))*100)));let grammar=85,vocab=75;if(/\b(i am|my name is|i study|i like)\b/.test(said))grammar+=8;if(sw.length>=4)vocab+=10;grammar=Math.min(100,grammar);vocab=Math.min(100,vocab);const s=document.getElementById('speakingScore');if(s)s.style.display='grid';document.getElementById('pronScore').textContent=pronunciation;document.getElementById('grammarScore').textContent=grammar;document.getElementById('vocabScore').textContent=vocab;document.getElementById('speakingFeedback').innerHTML=`<b>Speaking feedback</b><p>Pronunciation ${pronunciation}/100 · Grammar ${grammar}/100 · Vocabulary ${vocab}/100.</p><small>Repeat the model sentence slowly, then try again with one extra detail.</small>`;state.speakingScores=state.speakingScores||[];state.speakingScores.push({pronunciation,grammar,vocabulary:vocab,date:today()});state.speakingScores=state.speakingScores.slice(-20);state.xp+=5;state.dailyXP+=5;save();}
// Replace the old browser-only speaking handler with a scored version while preserving AndroidBridge support.
startSpeaking=async function(){const status=document.getElementById('speakStatus'),fallback=document.getElementById('speechFallback');if(status)status.textContent='🎤 Preparing microphone…';await requestMicPermission();if(fallback)fallback.style.display='none';try{if(window.AndroidBridge&&typeof AndroidBridge.startSpeechRecognition==='function'){AndroidBridge.startSpeechRecognition('en-US');if(status)status.textContent='Listening… speak now.';return;}}catch(e){}const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){if(status)status.textContent='Offline practice is ready. Type your sentence below.';if(fallback)fallback.style.display='block';return;}try{const r=new SR();r.lang='en-US';r.interimResults=false;r.continuous=false;r.maxAlternatives=1;r.onstart=()=>{if(status)status.textContent='🎙️ Listening… speak now.'};r.onresult=e=>{const t=e.results[0][0].transcript;if(status)status.innerHTML='You said: <b>'+escapeHtml(t)+'</b>';v11SpeakingScore(t);};r.onerror=()=>{if(status)status.textContent='Offline practice is ready. Type your sentence below.';if(fallback)fallback.style.display='block';};r.start();}catch(e){if(status)status.textContent='Offline practice is ready. Type your sentence below.';if(fallback)fallback.style.display='block';}};
const _v11Update=update;update=function(){_v11Update();const c=document.getElementById('coinCount');if(c)c.textContent=(state.coins||0)+' coins';};
const _v11OpenPage=window.openPage;window.openPage=function(id){_v11OpenPage(id);if(id==='account')applyV11User();if(id==='leaderboard')loadLeaderboard();if(id==='premium'){} };
function v11Init(){try{v11User=JSON.parse(localStorage.getItem('emp_demo_user')||'null');applyV11User();checkBackend();}catch(e){};state.coins=state.coins||Math.floor((state.xp||0)/10);state.aiHistory=state.aiHistory||[];state.speakingScores=state.speakingScores||[];save();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',v11Init);else v11Init();

// OAuth callback token handoff: store the server-issued session and clean the URL.
(function(){const q=new URLSearchParams(location.search);const t=q.get('v11token');if(t){localStorage.setItem('emp_token',t);history.replaceState({},document.title,location.pathname);v11Api('/api/progress').then(d=>{v11User=d.user;applyV11User();syncNow();}).catch(()=>{});}})();

/* ========================= v11.2 production bridge ========================= */
async function empAnalytics(event, properties={}){try{if(V11_API_BASE&&localStorage.getItem('emp_token')) await v11Api('/api/analytics',{method:'POST',body:JSON.stringify({event,properties})})}catch(e){}}
window.empHandleNativePurchase=async function(raw){try{const p=JSON.parse(raw), token=localStorage.getItem('emp_token');if(!token){alert('Please sign in before restoring a purchase.');return}const r=await v11Api('/api/play/verify',{method:'POST',body:JSON.stringify({purchaseToken:p.purchaseToken,productId:p.productId,purchaseType:'subscription'})});v11User={...(v11User||{}),plan:r.plan};applyV11User();if(window.EnglishMasterNative?.setPremium)window.EnglishMasterNative.setPremium(true);alert('Premium activated ✓');}catch(e){alert(e.message||'Purchase verification failed')}};
async function restoreGooglePlayPurchase(){if(window.EnglishMasterNative?.restorePurchases){window.EnglishMasterNative.restorePurchases();return}alert('Restore is available in the Android app.');}
const _oldStartCheckout=window.startCheckout;
window.startCheckout=async function(plan){if(window.EnglishMasterNative){if(!localStorage.getItem('emp_token')){openAccount();return} if(plan==='monthly')EnglishMasterNative.buyMonthly();else if(plan==='yearly')EnglishMasterNative.buyYearly();empAnalytics('subscription_purchase_started',{provider:'google_play',plan});return}return _oldStartCheckout(plan)};
const _oldApplyV11User=window.applyV11User;
window.applyV11User=function(){_oldApplyV11User();const premium=!!(v11User&&v11User.plan==='premium');if(window.EnglishMasterNative?.setPremium)window.EnglishMasterNative.setPremium(premium);empAnalytics('session_user_state',{plan:premium?'premium':'free'});};
function empConfigureProduction(){if(V11_API_BASE) localStorage.setItem('emp_backend_configured','1');}
empConfigureProduction();
async function manageStripeSubscription(){try{if(!V11_API_BASE)throw new Error('Backend is not configured');const d=await v11Api('/api/billing/portal',{method:'POST'});if(d.url)location.href=d.url;}catch(e){alert(e.message)}}

/* ========================= v11.4 — 10 LANGUAGE + DARI ========================= */
const EMP_LANGS=['en','fa','ar','es','fr','zh','hi','ru','pt','de'];
const EMP_LANG_NAMES={en:'English',fa:'دری',ar:'العربية',es:'Español',fr:'Français',zh:'中文',hi:'हिन्दी',ru:'Русский',pt:'Português',de:'Deutsch'};
let empLang=localStorage.getItem('emp_language')||'';

const EMP_T={
'English Master':{fa:'انگلیش مستر',ar:'مدرّب الإنجليزية',es:'Maestro de Inglés',fr:"Maître d’anglais",zh:'英语大师',hi:'इंग्लिश मास्टर',ru:'Мастер английского',pt:'Mestre de Inglês',de:'Englisch-Meister'},
'v11.6 · 10-language AI English learning':{fa:'v11.6 · آموزش انگلیسی با هوش مصنوعی در ۱۰ زبان',ar:'v11.6 · تعلّم الإنجليزية بالذكاء الاصطناعي بـ10 لغات',es:'v11.6 · Aprendizaje de inglés con IA en 10 idiomas',fr:"v11.6 · Apprentissage de l’anglais par IA en 10 langues",zh:'v11.6 · 10种语言的AI英语学习',hi:'v11.6 · 10 भाषाओं में AI अंग्रेज़ी सीखना',ru:'v11.6 · Изучение английского с ИИ на 10 языках',pt:'v11.6 · Aprendizagem de inglês com IA em 10 idiomas',de:'v11.6 · KI-Englischlernen in 10 Sprachen'},
'V11 AI LEARNING PATH':{fa:'مسیر یادگیری هوشمند V11',ar:'مسار تعلّم الإنجليزية بالذكاء الاصطناعي',es:'RUTA DE APRENDIZAJE IA V11',fr:"PARCOURS D’APPRENTISSAGE IA V11",zh:'V11 AI学习路径',hi:'V11 AI सीखने का मार्ग',ru:'ПУТЬ ОБУЧЕНИЯ С ИИ V11',pt:'CAMINHO DE APRENDIZAGEM IA V11',de:'V11 KI-LERNPFAD'},
'Build English that works in real life.':{fa:'انگلیسی‌ای بساز که در زندگی واقعی به کارت بیاید.',ar:'ابنِ إنجليزية مفيدة في الحياة الواقعية.',es:'Construye un inglés útil para la vida real.',fr:"Construisez un anglais utile dans la vraie vie.",zh:'学习能真正用于生活的英语。',hi:'ऐसी अंग्रेज़ी सीखें जो वास्तविक जीवन में काम आए।',ru:'Изучайте английский, который работает в реальной жизни.',pt:'Aprenda inglês que funciona na vida real.',de:'Lerne Englisch, das im echten Leben funktioniert.'},
'Practice four skills, build vocabulary, test your level and keep a real daily streak.':{fa:'چهار مهارت را تمرین کن، لغات بساز، سطح خود را بسنج و زنجیره روزانه را حفظ کن.',ar:'تدرّب على أربع مهارات، وابنِ مفرداتك، واختبر مستواك وحافظ على سلسلة يومية.',es:'Practica cuatro habilidades, aumenta tu vocabulario, mide tu nivel y mantén tu racha diaria.',fr:"Pratiquez quatre compétences, développez votre vocabulaire, testez votre niveau et gardez votre série quotidienne.",zh:'练习四项技能，积累词汇，测试水平并保持每日学习连续记录。',hi:'चार कौशलों का अभ्यास करें, शब्दावली बढ़ाएँ, स्तर जाँचें और दैनिक स्ट्रीक बनाए रखें।',ru:'Тренируйте четыре навыка, расширяйте словарный запас, проверяйте уровень и сохраняйте ежедневную серию.',pt:'Pratique quatro habilidades, aumente o vocabulário, teste seu nível e mantenha sua sequência diária.',de:'Übe vier Fähigkeiten, erweitere deinen Wortschatz, teste dein Niveau und halte deine tägliche Serie.'},
'Continue learning →':{fa:'ادامه یادگیری →',ar:'متابعة التعلّم →',es:'Continuar aprendiendo →',fr:'Continuer à apprendre →',zh:'继续学习 →',hi:'सीखना जारी रखें →',ru:'Продолжить обучение →',pt:'Continuar aprendendo →',de:'Weiterlernen →'},
'V11 MEMBERSHIP':{fa:'عضویت V11',ar:'عضوية V11',es:'MEMBRESÍA V11',fr:'ABONNEMENT V11',zh:'V11会员',hi:'V11 सदस्यता',ru:'ПОДПИСКА V11',pt:'ASSINATURA V11',de:'V11-MITGLIEDSCHAFT'},
'💎 Free + Premium':{fa:'💎 رایگان + پریمیوم',ar:'💎 مجاني + بريميوم',es:'💎 Gratis + Premium',fr:'💎 Gratuit + Premium',zh:'💎 免费 + 高级版',hi:'💎 मुफ़्त + प्रीमियम',ru:'💎 Бесплатно + Премиум',pt:'💎 Grátis + Premium',de:'💎 Kostenlos + Premium'},
'Premium unlocks advanced AI, extra courses and deeper speaking feedback.':{fa:'پریمیوم هوش مصنوعی پیشرفته، دوره‌های بیشتر و بازخورد دقیق‌تر گفتاری را باز می‌کند.',ar:'يفتح بريميوم الذكاء الاصطناعي المتقدم والدورات الإضافية وملاحظات التحدث الأعمق.',es:'Premium desbloquea IA avanzada, cursos extra y comentarios de pronunciación más detallados.',fr:"Premium débloque l’IA avancée, des cours supplémentaires et des retours plus détaillés à l’oral.",zh:'高级版解锁高级AI、更多课程和更深入的口语反馈。',hi:'प्रीमियम उन्नत AI, अतिरिक्त पाठ्यक्रम और बेहतर बोलने की प्रतिक्रिया देता है।',ru:'Премиум открывает расширенный ИИ, дополнительные курсы и подробную обратную связь по речи.',pt:'O Premium desbloqueia IA avançada, cursos extras e feedback de fala mais detalhado.',de:'Premium schaltet fortgeschrittene KI, zusätzliche Kurse und detaillierteres Sprechfeedback frei.'},
'View plans →':{fa:'دیدن برنامه‌ها →',ar:'عرض الخطط →',es:'Ver planes →',fr:'Voir les offres →',zh:'查看方案 →',hi:'प्लान देखें →',ru:'Посмотреть планы →',pt:'Ver planos →',de:'Pläne ansehen →'},
'3× DAILY STUDY':{fa:'۳ نوبت مطالعه روزانه',ar:'الدراسة 3 مرات يوميًا',es:'ESTUDIO 3 VECES AL DÍA',fr:'3 SÉANCES PAR JOUR',zh:'每日学习3次',hi:'दिन में 3 बार अध्ययन',ru:'УЧЁБА 3 РАЗА В ДЕНЬ',pt:'ESTUDO 3 VEZES AO DIA',de:'3× LERNEN TÄGLICH'},
'سه نوبت مطالعه':{en:'Three study sessions',ar:'ثلاث جلسات دراسة',es:'Tres sesiones de estudio',fr:'Trois séances d’étude',zh:'三次学习',hi:'तीन अध्ययन सत्र',ru:'Три учебные сессии',pt:'Três sessões de estudo',de:'Drei Lerneinheiten'},
'برای اینکه از درس خواندن خسته نشوی، هر روز در سه زمان جداگانه کمی تمرین کن.':{en:'To avoid getting tired of studying, practice a little at three separate times each day.',ar:'لتجنب التعب من الدراسة، تدرّب قليلًا في ثلاثة أوقات مختلفة كل يوم.',es:'Para no cansarte de estudiar, practica un poco en tres momentos distintos cada día.',fr:"Pour éviter la fatigue, pratique un peu à trois moments différents chaque jour.",zh:'为了避免学习疲劳，每天分三个不同时间短时间练习。',hi:'पढ़ाई से थकने से बचने के लिए हर दिन तीन अलग-अलग समय पर थोड़ा अभ्यास करें।',ru:'Чтобы не уставать от учёбы, занимайтесь понемногу три раза в разные часы каждый день.',pt:'Para não se cansar de estudar, pratique um pouco em três horários diferentes por dia.',de:'Damit du nicht vom Lernen müde wirst, übe jeden Tag kurz zu drei verschiedenen Zeiten.'},
'چرا سه نوبت؟':{en:'Why three sessions?',ar:'لماذا ثلاث جلسات؟',es:'¿Por qué tres sesiones?',fr:'Pourquoi trois séances ?',zh:'为什么分三次？',hi:'तीन सत्र क्यों?',ru:'Почему три занятия?',pt:'Por que três sessões?',de:'Warum drei Einheiten?'},
'day streak':{fa:'روز زنجیره',ar:'أيام متتالية',es:'días seguidos',fr:'jours consécutifs',zh:'连续学习天数',hi:'लगातार दिनों की स्ट्रीक',ru:'дней подряд',pt:'dias seguidos',de:'Tage in Folge'},
'total XP':{fa:'کل XP',ar:'إجمالي XP',es:'XP total',fr:'XP total',zh:'总XP',hi:'कुल XP',ru:'всего XP',pt:'XP total',de:'XP gesamt'},
'current level':{fa:'سطح فعلی',ar:'المستوى الحالي',es:'nivel actual',fr:'niveau actuel',zh:'当前等级',hi:'वर्तमान स्तर',ru:'текущий уровень',pt:'nível atual',de:'aktuelles Niveau'},
"Today's goal":{fa:'هدف امروز',ar:'هدف اليوم',es:'Objetivo de hoy',fr:"Objectif du jour",zh:'今日目标',hi:'आज का लक्ष्य',ru:'Цель на сегодня',pt:'Meta de hoje',de:'Tagesziel'},
'Four fundamental skills':{fa:'چهار مهارت اصلی',ar:'المهارات الأربع الأساسية',es:'Cuatro habilidades fundamentales',fr:'Quatre compétences fondamentales',zh:'四项核心技能',hi:'चार मूल कौशल',ru:'Четыре основных навыка',pt:'Quatro habilidades fundamentais',de:'Vier grundlegende Fähigkeiten'},
'Speaking':{fa:'گفتاری',ar:'المحادثة',es:'Expresión oral',fr:'Expression orale',zh:'口语',hi:'बोलना',ru:'Говорение',pt:'Fala',de:'Sprechen'},
'Listening':{fa:'شنیداری',ar:'الاستماع',es:'Comprensión auditiva',fr:'Écoute',zh:'听力',hi:'सुनना',ru:'Аудирование',pt:'Escuta',de:'Hören'},
'Reading':{fa:'خواندن',ar:'القراءة',es:'Lectura',fr:'Lecture',zh:'阅读',hi:'पठन',ru:'Чтение',pt:'Leitura',de:'Lesen'},
'Writing':{fa:'نوشتن',ar:'الكتابة',es:'Escritura',fr:'Écriture',zh:'写作',hi:'लेखन',ru:'Письмо',pt:'Escrita',de:'Schreiben'},
'Fluency & pronunciation':{fa:'روانی و تلفظ',ar:'الطلاقة والنطق',es:'Fluidez y pronunciación',fr:'Fluidité et prononciation',zh:'流利度与发音',hi:'प्रवाह और उच्चारण',ru:'Беглость и произношение',pt:'Fluência e pronúncia',de:'Flüssigkeit & Aussprache'},
'Understand real English':{fa:'درک انگلیسی واقعی',ar:'فهم الإنجليزية الواقعية',es:'Comprender inglés real',fr:'Comprendre l’anglais réel',zh:'理解真实英语',hi:'वास्तविक अंग्रेज़ी समझें',ru:'Понимание живого английского',pt:'Entender inglês real',de:'Echtes Englisch verstehen'},
'Comprehension & vocabulary':{fa:'درک مطلب و واژگان',ar:'الفهم والمفردات',es:'Comprensión y vocabulario',fr:'Compréhension et vocabulaire',zh:'理解与词汇',hi:'समझ और शब्दावली',ru:'Понимание и словарный запас',pt:'Compreensão e vocabulário',de:'Verstehen & Wortschatz'},
'Grammar & expression':{fa:'گرامر و بیان',ar:'القواعد والتعبير',es:'Gramática y expresión',fr:'Grammaire et expression',zh:'语法与表达',hi:'व्याकरण और अभिव्यक्ति',ru:'Грамматика и выражение',pt:'Gramática e expressão',de:'Grammatik & Ausdruck'},
'V11 SMART ACADEMY':{fa:'آکادمی هوشمند V11',ar:'الأكاديمية الذكية V11',es:'ACADEMIA INTELIGENTE V11',fr:'ACADÉMIE INTELLIGENTE V11',zh:'V11智能学院',hi:'V11 स्मार्ट अकादमी',ru:'УМНАЯ АКАДЕМИЯ V11',pt:'ACADEMIA INTELIGENTE V11',de:'V11 SMART-AKADEMIE'},
'🎯 Your personal learning plan':{fa:'🎯 برنامه یادگیری شخصی شما',ar:'🎯 خطتك التعليمية الشخصية',es:'🎯 Tu plan de aprendizaje personal',fr:'🎯 Votre plan d’apprentissage personnel',zh:'🎯 你的个性化学习计划',hi:'🎯 आपकी व्यक्तिगत सीखने की योजना',ru:'🎯 Ваш персональный план обучения',pt:'🎯 Seu plano de aprendizagem pessoal',de:'🎯 Dein persönlicher Lernplan'},
'AI chooses today’s lesson, review words and practice based on your progress.':{fa:'هوش مصنوعی بر اساس پیشرفت شما درس، مرور لغات و تمرین امروز را انتخاب می‌کند.',ar:'يختار الذكاء الاصطناعي درس اليوم وكلمات المراجعة والتدريب بناءً على تقدمك.',es:'La IA elige la lección, las palabras y la práctica de hoy según tu progreso.',fr:"L’IA choisit la leçon, les mots à revoir et la pratique selon vos progrès.",zh:'AI会根据你的学习进度选择今日课程、复习词汇和练习。',hi:'AI आपकी प्रगति के आधार पर आज का पाठ, शब्द और अभ्यास चुनता है।',ru:'ИИ выбирает урок, слова для повторения и практику на основе вашего прогресса.',pt:'A IA escolhe a lição, as palavras e a prática de hoje com base no seu progresso.',de:'Die KI wählt anhand deines Fortschritts die heutige Lektion, Wiederholungswörter und Übungen.'},
'Open Academy →':{fa:'باز کردن آکادمی →',ar:'فتح الأكاديمية →',es:'Abrir academia →',fr:'Ouvrir l’académie →',zh:'打开学院 →',hi:'अकादमी खोलें →',ru:'Открыть академию →',pt:'Abrir academia →',de:'Akademie öffnen →'},
'DAILY CHALLENGE':{fa:'چالش روزانه',ar:'تحدي اليوم',es:'DESAFÍO DIARIO',fr:'DÉFI QUOTIDIEN',zh:'每日挑战',hi:'दैनिक चुनौती',ru:'ЕЖЕДНЕВНЫЙ ЧЕЛЛЕНДЖ',pt:'DESAFIO DIÁRIO',de:'TÄGLICHE HERAUSFORDERUNG'},
'Learn 5 useful expressions':{fa:'۵ عبارت کاربردی یاد بگیر',ar:'تعلّم 5 عبارات مفيدة',es:'Aprende 5 expresiones útiles',fr:'Apprenez 5 expressions utiles',zh:'学习5个实用表达',hi:'5 उपयोगी अभिव्यक्तियाँ सीखें',ru:'Выучите 5 полезных выражений',pt:'Aprenda 5 expressões úteis',de:'Lerne 5 nützliche Ausdrücke'},
"Complete today's quick challenge and earn 10 XP.":{fa:'چالش کوتاه امروز را کامل کن و ۱۰ XP بگیر.',ar:'أكمل تحدي اليوم السريع واحصل على 10 XP.',es:'Completa el desafío rápido de hoy y gana 10 XP.',fr:'Terminez le défi rapide du jour et gagnez 10 XP.',zh:'完成今天的快速挑战并获得10 XP。',hi:'आज की छोटी चुनौती पूरी करें और 10 XP पाएं।',ru:'Выполните сегодняшнее быстрое задание и получите 10 XP.',pt:'Complete o desafio rápido de hoje e ganhe 10 XP.',de:'Schließe die heutige kurze Herausforderung ab und verdiene 10 XP.'},
'Start':{fa:'شروع',ar:'ابدأ',es:'Empezar',fr:'Commencer',zh:'开始',hi:'शुरू',ru:'Начать',pt:'Começar',de:'Starten'},
'LEARNING PATH':{fa:'مسیر یادگیری',ar:'مسار التعلّم',es:'RUTA DE APRENDIZAJE',fr:'PARCOURS D’APPRENTISSAGE',zh:'学习路径',hi:'सीखने का मार्ग',ru:'ПУТЬ ОБУЧЕНИЯ',pt:'CAMINHO DE APRENDIZAGEM',de:'LERNPFAD'},
'Choose a skill':{fa:'یک مهارت را انتخاب کن',ar:'اختر مهارة',es:'Elige una habilidad',fr:'Choisissez une compétence',zh:'选择一项技能',hi:'एक कौशल चुनें',ru:'Выберите навык',pt:'Escolha uma habilidade',de:'Wähle eine Fähigkeit'},
'← Back':{fa:'بازگشت →',ar:'→ رجوع',es:'← Volver',fr:'← Retour',zh:'← 返回',hi:'← वापस',ru:'← Назад',pt:'← Voltar',de:'← Zurück'},
'SMART PLACEMENT':{fa:'تعیین سطح هوشمند',ar:'تحديد المستوى الذكي',es:'NIVELACIÓN INTELIGENTE',fr:'ÉVALUATION INTELLIGENTE',zh:'智能测评',hi:'स्मार्ट स्तर परीक्षण',ru:'УМНОЕ ОПРЕДЕЛЕНИЕ УРОВНЯ',pt:'NIVELAMENTO INTELIGENTE',de:'INTELLIGENTE EINSTUFUNG'},
'Find your English level':{fa:'سطح انگلیسی خود را پیدا کن',ar:'اكتشف مستواك في الإنجليزية',es:'Descubre tu nivel de inglés',fr:'Trouvez votre niveau d’anglais',zh:'找到你的英语水平',hi:'अपना अंग्रेज़ी स्तर जानें',ru:'Определите свой уровень английского',pt:'Descubra seu nível de inglês',de:'Finde dein Englischniveau'},
'Grammar, vocabulary, reading and practical English.':{fa:'گرامر، واژگان، خواندن و انگلیسی کاربردی.',ar:'القواعد والمفردات والقراءة والإنجليزية العملية.',es:'Gramática, vocabulario, lectura e inglés práctico.',fr:'Grammaire, vocabulaire, lecture et anglais pratique.',zh:'语法、词汇、阅读和实用英语。',hi:'व्याकरण, शब्दावली, पठन और व्यावहारिक अंग्रेज़ी।',ru:'Грамматика, словарный запас, чтение и практический английский.',pt:'Gramática, vocabulário, leitura e inglês prático.',de:'Grammatik, Wortschatz, Lesen und praktisches Englisch.'},
'VOCAB BUILDER · V11':{fa:'سازنده واژگان · V11',ar:'بناء المفردات · V11',es:'CONSTRUCTOR DE VOCABULARIO · V11',fr:'CONSTRUCTEUR DE VOCABULAIRE · V11',zh:'词汇构建 · V11',hi:'शब्दावली बिल्डर · V11',ru:'ТРЕНЕР СЛОВАРЯ · V11',pt:'CONSTRUTOR DE VOCABULÁRIO · V11',de:'VOKABELTRAINER · V11'},
'Daily vocabulary':{fa:'واژگان روزانه',ar:'مفردات يومية',es:'Vocabulario diario',fr:'Vocabulaire quotidien',zh:'每日词汇',hi:'दैनिक शब्दावली',ru:'Словарь на каждый день',pt:'Vocabulário diário',de:'Täglicher Wortschatz'},
'Learn useful words with meaning, examples, audio and spaced review.':{fa:'لغات کاربردی را با معنی، مثال، صدا و مرور فاصله‌دار یاد بگیر.',ar:'تعلّم كلمات مفيدة مع المعنى والأمثلة والصوت والمراجعة المتباعدة.',es:'Aprende palabras útiles con significado, ejemplos, audio y repaso espaciado.',fr:'Apprenez des mots utiles avec sens, exemples, audio et révision espacée.',zh:'通过释义、例句、音频和间隔复习学习实用词汇。',hi:'अर्थ, उदाहरण, ऑडियो और स्पेस्ड रिव्यू के साथ उपयोगी शब्द सीखें।',ru:'Учите полезные слова с переводом, примерами, аудио и интервальным повторением.',pt:'Aprenda palavras úteis com significado, exemplos, áudio e revisão espaçada.',de:'Lerne nützliche Wörter mit Bedeutung, Beispielen, Audio und verteiltem Wiederholen.'},
'🔀 Shuffle':{fa:'🔀 تصادفی',ar:'🔀 عشوائي',es:'🔀 Aleatorio',fr:'🔀 Mélanger',zh:'🔀 随机',hi:'🔀 शफल',ru:'🔀 Перемешать',pt:'🔀 Embaralhar',de:'🔀 Mischen'},
'📚 Review saved words':{fa:'📚 مرور لغات ذخیره‌شده',ar:'📚 مراجعة الكلمات المحفوظة',es:'📚 Repasar palabras guardadas',fr:'📚 Réviser les mots enregistrés',zh:'📚 复习已保存词汇',hi:'📚 सहेजे शब्द दोहराएँ',ru:'📚 Повторить сохранённые слова',pt:'📚 Revisar palavras salvas',de:'📚 Gespeicherte Wörter wiederholen'},
'SPEAKING LAB':{fa:'آزمایشگاه گفتاری',ar:'مختبر المحادثة',es:'LABORATORIO DE EXPRESIÓN ORAL',fr:'LABORATOIRE D’ORAL',zh:'口语实验室',hi:'स्पीकिंग लैब',ru:'ЛАБОРАТОРИЯ РЕЧИ',pt:'LABORATÓRIO DE FALA',de:'SPRECHLABOR'},
'Speak with confidence':{fa:'با اعتمادبه‌نفس صحبت کن',ar:'تحدث بثقة',es:'Habla con confianza',fr:'Parlez avec confiance',zh:'自信开口说英语',hi:'आत्मविश्वास से बोलें',ru:'Говорите уверенно',pt:'Fale com confiança',de:'Sprich selbstbewusst'},
'🎤 Start microphone · +5 XP':{fa:'🎤 شروع میکروفون · +۵ XP',ar:'🎤 تشغيل الميكروفون · +5 XP',es:'🎤 Iniciar micrófono · +5 XP',fr:'🎤 Démarrer le micro · +5 XP',zh:'🎤 开始麦克风 · +5 XP',hi:'🎤 माइक्रोफ़ोन शुरू करें · +5 XP',ru:'🎤 Запустить микрофон · +5 XP',pt:'🎤 Iniciar microfone · +5 XP',de:'🎤 Mikrofon starten · +5 XP'},
'🔊 Model':{fa:'🔊 نمونه',ar:'🔊 النموذج',es:'🔊 Modelo',fr:'🔊 Modèle',zh:'🔊 示例',hi:'🔊 मॉडल',ru:'🔊 Образец',pt:'🔊 Modelo',de:'🔊 Modell'},
'Pronunciation':{fa:'تلفظ',ar:'النطق',es:'Pronunciación',fr:'Prononciation',zh:'发音',hi:'उच्चारण',ru:'Произношение',pt:'Pronúncia',de:'Aussprache'},
'Grammar':{fa:'گرامر',ar:'القواعد',es:'Gramática',fr:'Grammaire',zh:'语法',hi:'व्याकरण',ru:'Грамматика',pt:'Gramática',de:'Grammatik'},
'Vocabulary':{fa:'واژگان',ar:'المفردات',es:'Vocabulario',fr:'Vocabulaire',zh:'词汇',hi:'शब्दावली',ru:'Словарный запас',pt:'Vocabulário',de:'Wortschatz'},
'Offline fallback':{fa:'حالت جایگزین آفلاین',ar:'الوضع البديل دون اتصال',es:'Alternativa sin conexión',fr:'Solution hors ligne',zh:'离线备用模式',hi:'ऑफ़लाइन विकल्प',ru:'Офлайн-режим',pt:'Alternativa offline',de:'Offline-Alternative'},
'✓ Practice offline':{fa:'✓ تمرین آفلاین',ar:'✓ تدرب دون اتصال',es:'✓ Practicar sin conexión',fr:'✓ Pratiquer hors ligne',zh:'✓ 离线练习',hi:'✓ ऑफ़लाइन अभ्यास',ru:'✓ Практиковаться офлайн',pt:'✓ Praticar offline',de:'✓ Offline üben'},
'REVIEW DECK':{fa:'دسته مرور',ar:'مجموعة المراجعة',es:'MAZO DE REPASO',fr:'PAQUET DE RÉVISION',zh:'复习卡组',hi:'रिव्यू डेक',ru:'КОЛОДА ПОВТОРЕНИЯ',pt:'BARALHO DE REVISÃO',de:'WIEDERHOLUNGSDECK'},
'Saved words':{fa:'لغات ذخیره‌شده',ar:'الكلمات المحفوظة',es:'Palabras guardadas',fr:'Mots enregistrés',zh:'已保存词汇',hi:'सहेजे शब्द',ru:'Сохранённые слова',pt:'Palavras salvas',de:'Gespeicherte Wörter'},
'Quickly revisit the vocabulary you want to remember.':{fa:'لغاتی را که می‌خواهی به خاطر بسپاری سریع مرور کن.',ar:'راجع بسرعة المفردات التي تريد تذكرها.',es:'Repasa rápidamente el vocabulario que quieres recordar.',fr:'Revoyez rapidement le vocabulaire que vous voulez retenir.',zh:'快速复习你想记住的词汇。',hi:'जिन शब्दों को याद रखना है उन्हें जल्दी दोहराएँ।',ru:'Быстро повторяйте слова, которые хотите запомнить.',pt:'Revise rapidamente o vocabulário que deseja lembrar.',de:'Wiederhole schnell die Wörter, die du behalten möchtest.'},
'V11 REAL AI ENGLISH COACH':{fa:'مربی واقعی انگلیسی با هوش مصنوعی V11',ar:'مدرب الإنجليزية الحقيقي بالذكاء الاصطناعي V11',es:'COACH REAL DE INGLÉS CON IA V11',fr:'COACH D’ANGLAIS IA V11',zh:'V11真实AI英语教练',hi:'V11 वास्तविक AI अंग्रेज़ी कोच',ru:'РЕАЛЬНЫЙ ИИ-ТРЕНЕР АНГЛИЙСКОГО V11',pt:'COACH REAL DE INGLÊS COM IA V11',de:'V11 ECHTER KI-ENGLISCHCOACH'},
'Smart English Tutor 🤖':{fa:'مربی هوشمند انگلیسی 🤖',ar:'مدرس الإنجليزية الذكي 🤖',es:'Tutor inteligente de inglés 🤖',fr:'Tuteur d’anglais intelligent 🤖',zh:'智能英语导师 🤖',hi:'स्मार्ट अंग्रेज़ी ट्यूटर 🤖',ru:'Умный репетитор английского 🤖',pt:'Tutor inteligente de inglês 🤖',de:'Intelligenter Englisch-Tutor 🤖'},
'Your tutor adapts practice to your level, checks common mistakes, teaches step-by-step and can run offline.':{fa:'مربی شما تمرین را با سطح‌تان سازگار می‌کند، اشتباهات رایج را بررسی می‌کند و مرحله‌به‌مرحله آموزش می‌دهد؛ حتی آفلاین.',ar:'يكيّف المدرّب التمارين حسب مستواك، ويفحص الأخطاء الشائعة ويعلّم خطوة بخطوة ويمكنه العمل دون اتصال.',es:'Tu tutor adapta la práctica a tu nivel, revisa errores comunes, enseña paso a paso y puede funcionar sin conexión.',fr:"Votre tuteur adapte les exercices à votre niveau, vérifie les erreurs courantes, enseigne étape par étape et peut fonctionner hors ligne.",zh:'导师会根据你的水平调整练习、检查常见错误、逐步教学，并可离线运行。',hi:'ट्यूटर आपके स्तर के अनुसार अभ्यास बदलता है, सामान्य गलतियाँ जाँचता है, चरण-दर-चरण सिखाता है，并离线也 काम कर सकता है।',ru:'Репетитор подстраивает практику под ваш уровень, проверяет типичные ошибки, учит пошагово и может работать офлайн.',pt:'Seu tutor adapta a prática ao seu nível, verifica erros comuns, ensina passo a passo e pode funcionar offline.',de:'Dein Tutor passt Übungen an dein Niveau an, prüft häufige Fehler, erklärt Schritt für Schritt und kann offline laufen.'},
'🎓 Tutor':{fa:'🎓 مربی',ar:'🎓 المدرّب',es:'🎓 Tutor',fr:'🎓 Tuteur',zh:'🎓 导师',hi:'🎓 ट्यूटर',ru:'🎓 Репетитор',pt:'🎓 Tutor',de:'🎓 Tutor'},
'✍️ Grammar':{fa:'✍️ گرامر',ar:'✍️ قواعد',es:'✍️ Gramática',fr:'✍️ Grammaire',zh:'✍️ 语法',hi:'✍️ व्याकरण',ru:'✍️ Грамматика',pt:'✍️ Gramática',de:'✍️ Grammatik'},
'💬 Conversation':{fa:'💬 مکالمه',ar:'💬 محادثة',es:'💬 Conversación',fr:'💬 Conversation',zh:'💬 对话',hi:'💬 बातचीत',ru:'💬 Разговор',pt:'💬 Conversa',de:'💬 Gespräch'},
'🧠 Vocabulary':{fa:'🧠 واژگان',ar:'🧠 مفردات',es:'🧠 Vocabulario',fr:'🧠 Vocabulaire',zh:'🧠 词汇',hi:'🧠 शब्दावली',ru:'🧠 Словарь',pt:'🧠 Vocabulário',de:'🧠 Wortschatz'},
'🔊 Pronunciation':{fa:'🔊 تلفظ',ar:'🔊 النطق',es:'🔊 Pronunciación',fr:'🔊 Prononciation',zh:'🔊 发音',hi:'🔊 उच्चारण',ru:'🔊 Произношение',pt:'🔊 Pronúncia',de:'🔊 Aussprache'},
'Personal Tutor':{fa:'مربی شخصی',ar:'مدرّب شخصي',es:'Tutor personal',fr:'Tuteur personnel',zh:'私人导师',hi:'व्यक्तिगत ट्यूटर',ru:'Персональный репетитор',pt:'Tutor pessoal',de:'Persönlicher Tutor'},
'Ask a question or send an English sentence.':{fa:'یک سؤال بپرس یا یک جمله انگلیسی بفرست.',ar:'اطرح سؤالًا أو أرسل جملة إنجليزية.',es:'Haz una pregunta o envía una frase en inglés.',fr:'Posez une question ou envoyez une phrase anglaise.',zh:'提一个问题或发送一句英语句子。',hi:'कोई प्रश्न पूछें या अंग्रेज़ी वाक्य भेजें।',ru:'Задайте вопрос или отправьте английское предложение.',pt:'Faça uma pergunta ou envie uma frase em inglês.',de:'Stelle eine Frage oder sende einen englischen Satz.'},
'Start 5-question drill':{fa:'شروع تمرین ۵ سؤالی',ar:'ابدأ تدريبًا من 5 أسئلة',es:'Iniciar práctica de 5 preguntas',fr:'Démarrer 5 questions',zh:'开始5题练习',hi:'5 प्रश्नों का अभ्यास शुरू करें',ru:'Начать тренировку из 5 вопросов',pt:'Iniciar treino de 5 perguntas',de:'5-Fragen-Übung starten'},
'✨ Teach me a lesson':{fa:'✨ یک درس به من یاد بده',ar:'✨ علّمني درسًا',es:'✨ Enséñame una lección',fr:'✨ Apprenez-moi une leçon',zh:'✨ 教我一课',hi:'✨ मुझे एक पाठ सिखाएँ',ru:'✨ Обучить меня уроку',pt:'✨ Ensine-me uma lição',de:'✨ Unterrichte mich'},
'Correct a sentence':{fa:'اصلاح یک جمله',ar:'صحّح جملة',es:'Corregir una frase',fr:'Corriger une phrase',zh:'纠正句子',hi:'वाक्य सुधारें',ru:'Исправить предложение',pt:'Corrigir uma frase',de:'Einen Satz korrigieren'},
'5 useful words':{fa:'۵ لغت کاربردی',ar:'5 كلمات مفيدة',es:'5 palabras útiles',fr:'5 mots utiles',zh:'5个实用词',hi:'5 उपयोगी शब्द',ru:'5 полезных слов',pt:'5 palavras úteis',de:'5 nützliche Wörter'},
'Start conversation':{fa:'شروع مکالمه',ar:'ابدأ محادثة',es:'Iniciar conversación',fr:'Démarrer une conversation',zh:'开始对话',hi:'बातचीत शुरू करें',ru:'Начать разговор',pt:'Iniciar conversa',de:'Gespräch starten'},
'Explain grammar':{fa:'گرامر را توضیح بده',ar:'اشرح القواعد',es:'Explicar gramática',fr:'Expliquer la grammaire',zh:'解释语法',hi:'व्याकरण समझाएँ',ru:'Объяснить грамматику',pt:'Explicar gramática',de:'Grammatik erklären'},
'🌐 Real AI':{fa:'🌐 هوش مصنوعی واقعی',ar:'🌐 ذكاء اصطناعي حقيقي',es:'🌐 IA real',fr:'🌐 IA réelle',zh:'🌐 真实AI',hi:'🌐 वास्तविक AI',ru:'🌐 Реальный ИИ',pt:'🌐 IA real',de:'🌐 Echte KI'},
'Checking secure AI backend…':{fa:'در حال بررسی اتصال امن هوش مصنوعی…',ar:'جارٍ فحص اتصال الذكاء الاصطناعي الآمن…',es:'Comprobando el backend seguro de IA…',fr:'Vérification du backend IA sécurisé…',zh:'正在检查安全AI后端…',hi:'सुरक्षित AI बैकएंड जाँचा जा रहा है…',ru:'Проверка защищённого ИИ-бэкенда…',pt:'Verificando o backend seguro de IA…',de:'Sicheres KI-Backend wird geprüft…'},
'Check connection':{fa:'بررسی اتصال',ar:'فحص الاتصال',es:'Comprobar conexión',fr:'Vérifier la connexion',zh:'检查连接',hi:'कनेक्शन जाँचें',ru:'Проверить соединение',pt:'Verificar conexão',de:'Verbindung prüfen'},
'Send':{fa:'ارسال',ar:'إرسال',es:'Enviar',fr:'Envoyer',zh:'发送',hi:'भेजें',ru:'Отправить',pt:'Enviar',de:'Senden'},
'Personal Learning Academy 🚀':{fa:'آکادمی یادگیری شخصی 🚀',ar:'أكاديمية التعلّم الشخصية 🚀',es:'Academia de aprendizaje personal 🚀',fr:'Académie d’apprentissage personnelle 🚀',zh:'个人学习学院 🚀',hi:'व्यक्तिगत लर्निंग अकादमी 🚀',ru:'Персональная академия обучения 🚀',pt:'Academia de aprendizagem pessoal 🚀',de:'Persönliche Lernakademie 🚀'},
'A daily plan that adapts to your level, weak skills and recent mistakes.':{fa:'برنامه روزانه بر اساس سطح، مهارت‌های ضعیف و اشتباهات اخیر شما تنظیم می‌شود.',ar:'خطة يومية تتكيف مع مستواك ونقاط ضعفك وأخطائك الأخيرة.',es:'Un plan diario que se adapta a tu nivel, habilidades débiles y errores recientes.',fr:'Un plan quotidien adapté à votre niveau, vos points faibles et vos erreurs récentes.',zh:'每日计划会根据你的水平、薄弱技能和近期错误进行调整。',hi:'आपके स्तर, कमजोर कौशल और हाल की गलतियों के अनुसार दैनिक योजना बदलती है।',ru:'Ежедневный план адаптируется к вашему уровню, слабым навыкам и недавним ошибкам.',pt:'Um plano diário que se adapta ao seu nível, pontos fracos e erros recentes.',de:'Ein Tagesplan, der sich an dein Niveau, schwache Fähigkeiten und aktuelle Fehler anpasst.'},
'Today’s smart plan':{fa:'برنامه هوشمند امروز',ar:'خطة اليوم الذكية',es:'Plan inteligente de hoy',fr:'Plan intelligent du jour',zh:'今日智能计划',hi:'आज की स्मार्ट योजना',ru:'Умный план на сегодня',pt:'Plano inteligente de hoje',de:'Intelligenter Plan für heute'},
'🔄 Rebuild plan':{fa:'🔄 ساخت دوباره برنامه',ar:'🔄 إعادة بناء الخطة',es:'🔄 Reconstruir plan',fr:'🔄 Refaire le plan',zh:'🔄 重新生成计划',hi:'🔄 योजना फिर बनाएँ',ru:'🔄 Пересобрать план',pt:'🔄 Refazer plano',de:'🔄 Plan neu erstellen'},
'🧠 Learning health':{fa:'🧠 سلامت یادگیری',ar:'🧠 صحة التعلّم',es:'🧠 Salud del aprendizaje',fr:'🧠 Santé de l’apprentissage',zh:'🧠 学习状态',hi:'🧠 सीखने की स्थिति',ru:'🧠 Состояние обучения',pt:'🧠 Saúde da aprendizagem',de:'🧠 Lernstatus'},
'Good':{fa:'خوب',ar:'جيد',es:'Bien',fr:'Bien',zh:'良好',hi:'अच्छा',ru:'Хорошо',pt:'Bom',de:'Gut'},
'📝 Error Notebook':{fa:'📝 دفترچه اشتباهات',ar:'📝 دفتر الأخطاء',es:'📝 Cuaderno de errores',fr:'📝 Carnet d’erreurs',zh:'📝 错误笔记',hi:'📝 त्रुटि नोटबुक',ru:'📝 Дневник ошибок',pt:'📝 Caderno de erros',de:'📝 Fehler-Notizbuch'},
'Mistakes found by the tutor are saved here for review.':{fa:'اشتباهاتی که مربی پیدا می‌کند برای مرور اینجا ذخیره می‌شوند.',ar:'تُحفظ هنا الأخطاء التي يكتشفها المدرّب للمراجعة.',es:'Aquí se guardan los errores encontrados por el tutor para repasarlos.',fr:'Les erreurs trouvées par le tuteur sont enregistrées ici pour révision.',zh:'导师发现的错误会保存在这里供复习。',hi:'ट्यूटर द्वारा मिली गलतियाँ यहाँ दोहराने के लिए सहेजी जाती हैं।',ru:'Ошибки, найденные репетитором, сохраняются здесь для повторения.',pt:'Os erros encontrados pelo tutor são salvos aqui para revisão.',de:'Vom Tutor gefundene Fehler werden hier zum Wiederholen gespeichert.'},
'🃏 Smart Review':{fa:'🃏 مرور هوشمند',ar:'🃏 مراجعة ذكية',es:'🃏 Repaso inteligente',fr:'🃏 Révision intelligente',zh:'🃏 智能复习',hi:'🃏 स्मार्ट रिव्यू',ru:'🃏 Умное повторение',pt:'🃏 Revisão inteligente',de:'🃏 Smarte Wiederholung'},
'Review words using simple spaced repetition.':{fa:'لغات را با مرور فاصله‌دار ساده مرور کن.',ar:'راجع الكلمات باستخدام التكرار المتباعد البسيط.',es:'Repasa palabras con repetición espaciada sencilla.',fr:'Révisez les mots avec une répétition espacée simple.',zh:'使用简单的间隔重复复习词汇。',hi:'सरल स्पेस्ड रिपीटिशन से शब्द दोहराएँ।',ru:'Повторяйте слова с помощью простого интервального повторения.',pt:'Revise palavras usando repetição espaçada simples.',de:'Wiederhole Wörter mit einfacher verteilten Wiederholung.'},
'Start review':{fa:'شروع مرور',ar:'ابدأ المراجعة',es:'Iniciar repaso',fr:'Commencer la révision',zh:'开始复习',hi:'रिव्यू शुरू करें',ru:'Начать повторение',pt:'Iniciar revisão',de:'Wiederholung starten'},
'🎭 Real-life Role Play':{fa:'🎭 نقش‌آفرینی زندگی واقعی',ar:'🎭 تمثيل مواقف واقعية',es:'🎭 Role-play de la vida real',fr:'🎭 Jeu de rôle réel',zh:'🎭 真实场景角色扮演',hi:'🎭 वास्तविक जीवन रोल-प्ले',ru:'🎭 Ролевые ситуации из жизни',pt:'🎭 Role-play da vida real',de:'🎭 Rollenspiel aus dem echten Leben'},
'Choose a situation and practice a short conversation.':{fa:'یک موقعیت را انتخاب کن و یک مکالمه کوتاه تمرین کن.',ar:'اختر موقفًا وتدرّب على محادثة قصيرة.',es:'Elige una situación y practica una conversación breve.',fr:'Choisissez une situation et pratiquez une courte conversation.',zh:'选择一个场景并练习简短对话。',hi:'एक स्थिति चुनें और छोटी बातचीत का अभ्यास करें।',ru:'Выберите ситуацию и потренируйте короткий диалог.',pt:'Escolha uma situação e pratique uma conversa curta.',de:'Wähle eine Situation und übe ein kurzes Gespräch.'},
'💼 Job interview':{fa:'💼 مصاحبه کاری',ar:'💼 مقابلة عمل',es:'💼 Entrevista de trabajo',fr:'💼 Entretien d’embauche',zh:'💼 求职面试',hi:'💼 नौकरी साक्षात्कार',ru:'💼 Собеседование',pt:'💼 Entrevista de emprego',de:'💼 Bewerbungsgespräch'},
'✈️ Travel':{fa:'✈️ سفر',ar:'✈️ سفر',es:'✈️ Viajes',fr:'✈️ Voyage',zh:'✈️ 旅行',hi:'✈️ यात्रा',ru:'✈️ Путешествия',pt:'✈️ Viagem',de:'✈️ Reisen'},
'🛍️ Shopping':{fa:'🛍️ خرید',ar:'🛍️ التسوق',es:'🛍️ Compras',fr:'🛍️ Achats',zh:'🛍️ 购物',hi:'🛍️ खरीदारी',ru:'🛍️ Покупки',pt:'🛍️ Compras',de:'🛍️ Einkaufen'},
'🏫 School':{fa:'🏫 مکتب',ar:'🏫 المدرسة',es:'🏫 Escuela',fr:'🏫 École',zh:'🏫 学校',hi:'🏫 स्कूल',ru:'🏫 Школа',pt:'🏫 Escola',de:'🏫 Schule'},
'✍️ Writing Lab':{fa:'✍️ آزمایشگاه نوشتن',ar:'✍️ مختبر الكتابة',es:'✍️ Laboratorio de escritura',fr:'✍️ Atelier d’écriture',zh:'✍️ 写作实验室',hi:'✍️ लेखन लैब',ru:'✍️ Лаборатория письма',pt:'✍️ Laboratório de escrita',de:'✍️ Schreibwerkstatt'},
'Check my writing':{fa:'نوشته‌ام را بررسی کن',ar:'صحّح كتابتي',es:'Revisar mi escritura',fr:'Vérifier mon texte',zh:'检查我的写作',hi:'मेरी लेखन जाँचें',ru:'Проверить мой текст',pt:'Verificar meu texto',de:'Mein Schreiben prüfen'},
'V11 MEMBERSHIP':{fa:'عضویت V11',ar:'عضوية V11',es:'MEMBRESÍA V11',fr:'ABONNEMENT V11',zh:'V11会员',hi:'V11 सदस्यता',ru:'ПОДПИСКА V11',pt:'ASSINATURA V11',de:'V11-MITGLIEDSCHAFT'},
'Choose your plan 💎':{fa:'برنامه خود را انتخاب کن 💎',ar:'اختر خطتك 💎',es:'Elige tu plan 💎',fr:'Choisissez votre offre 💎',zh:'选择你的方案 💎',hi:'अपना प्लान चुनें 💎',ru:'Выберите план 💎',pt:'Escolha seu plano 💎',de:'Wähle deinen Plan 💎'},
'Free':{fa:'رایگان',ar:'مجاني',es:'Gratis',fr:'Gratuit',zh:'免费',hi:'मुफ़्त',ru:'Бесплатно',pt:'Grátis',de:'Kostenlos'},
'Current plan':{fa:'برنامه فعلی',ar:'الخطة الحالية',es:'Plan actual',fr:'Offre actuelle',zh:'当前方案',hi:'वर्तमान प्लान',ru:'Текущий план',pt:'Plano atual',de:'Aktueller Plan'},
'Monthly':{fa:'ماهانه',ar:'شهري',es:'Mensual',fr:'Mensuel',zh:'月度',hi:'मासिक',ru:'Ежемесячно',pt:'Mensal',de:'Monatlich'},
'Yearly':{fa:'سالانه',ar:'سنوي',es:'Anual',fr:'Annuel',zh:'年度',hi:'वार्षिक',ru:'Ежегодно',pt:'Anual',de:'Jährlich'},
'Subscribe monthly':{fa:'اشتراک ماهانه',ar:'اشترك شهريًا',es:'Suscribirse mensual',fr:'S’abonner au mois',zh:'订阅月度版',hi:'मासिक सदस्यता लें',ru:'Оформить ежемесячную подписку',pt:'Assinar mensalmente',de:'Monatlich abonnieren'},
'Subscribe yearly':{fa:'اشتراک سالانه',ar:'اشترك سنويًا',es:'Suscribirse anual',fr:'S’abonner à l’année',zh:'订阅年度版',hi:'वार्षिक सदस्यता लें',ru:'Оформить годовую подписку',pt:'Assinar anualmente',de:'Jährlich abonnieren'},
'ACCOUNT':{fa:'حساب',ar:'الحساب',es:'CUENTA',fr:'COMPTE',zh:'账户',hi:'खाता',ru:'АККАУНТ',pt:'CONTA',de:'KONTO'},
'Your account 🔐':{fa:'حساب شما 🔐',ar:'حسابك 🔐',es:'Tu cuenta 🔐',fr:'Votre compte 🔐',zh:'你的账户 🔐',hi:'आपका खाता 🔐',ru:'Ваш аккаунт 🔐',pt:'Sua conta 🔐',de:'Dein Konto 🔐'},
'Guest learner':{fa:'یادگیرنده مهمان',ar:'متعلم ضيف',es:'Alumno invitado',fr:'Apprenant invité',zh:'访客学习者',hi:'अतिथि शिक्षार्थी',ru:'Гость-ученик',pt:'Aluno convidado',de:'Gast-Lernender'},
'Not signed in':{fa:'وارد نشده‌اید',ar:'غير مسجل الدخول',es:'No has iniciado sesión',fr:'Non connecté',zh:'未登录',hi:'साइन इन नहीं है',ru:'Не выполнен вход',pt:'Não conectado',de:'Nicht angemeldet'},
'☁️ Sync now':{fa:'☁️ همگام‌سازی',ar:'☁️ مزامنة الآن',es:'☁️ Sincronizar ahora',fr:'☁️ Synchroniser',zh:'☁️ 立即同步',hi:'☁️ अभी सिंक करें',ru:'☁️ Синхронизировать',pt:'☁️ Sincronizar agora',de:'☁️ Jetzt synchronisieren'},
'Log out':{fa:'خروج',ar:'تسجيل الخروج',es:'Cerrar sesión',fr:'Se déconnecter',zh:'退出登录',hi:'लॉग आउट',ru:'Выйти',pt:'Sair',de:'Abmelden'},
'🌐 Multi-device sync':{fa:'🌐 همگام‌سازی چنددستگاهی',ar:'🌐 مزامنة بين الأجهزة',es:'🌐 Sincronización multidispositivo',fr:'🌐 Synchronisation multi-appareils',zh:'🌐 多设备同步',hi:'🌐 कई डिवाइस सिंक',ru:'🌐 Синхронизация устройств',pt:'🌐 Sincronização entre dispositivos',de:'🌐 Synchronisierung über mehrere Geräte'},
'🔔 Study reminders':{fa:'🔔 یادآوری مطالعه',ar:'🔔 تذكيرات الدراسة',es:'🔔 Recordatorios de estudio',fr:'🔔 Rappels d’étude',zh:'🔔 学习提醒',hi:'🔔 अध्ययन रिमाइंडर',ru:'🔔 Напоминания об учёбе',pt:'🔔 Lembretes de estudo',de:'🔔 Lernerinnerungen'},
'Enable reminders':{fa:'فعال‌کردن یادآوری‌ها',ar:'تفعيل التذكيرات',es:'Activar recordatorios',fr:'Activer les rappels',zh:'启用提醒',hi:'रिमाइंडर चालू करें',ru:'Включить напоминания',pt:'Ativar lembretes',de:'Erinnerungen aktivieren'},
'COMMUNITY':{fa:'جامعه',ar:'المجتمع',es:'COMUNIDAD',fr:'COMMUNAUTÉ',zh:'社区',hi:'समुदाय',ru:'СООБЩЕСТВО',pt:'COMUNIDADE',de:'COMMUNITY'},
'Leaderboard 🏆':{fa:'جدول امتیازات 🏆',ar:'لوحة المتصدرين 🏆',es:'Clasificación 🏆',fr:'Classement 🏆',zh:'排行榜 🏆',hi:'लीडरबोर्ड 🏆',ru:'Таблица лидеров 🏆',pt:'Classificação 🏆',de:'Rangliste 🏆'},
'Refresh':{fa:'تازه‌سازی',ar:'تحديث',es:'Actualizar',fr:'Actualiser',zh:'刷新',hi:'रिफ्रेश',ru:'Обновить',pt:'Atualizar',de:'Aktualisieren'},
'V11 SMART TOOLS':{fa:'ابزارهای هوشمند V11',ar:'أدوات V11 الذكية',es:'HERRAMIENTAS INTELIGENTES V11',fr:'OUTILS INTELLIGENTS V11',zh:'V11智能工具',hi:'V11 स्मार्ट टूल्स',ru:'УМНЫЕ ИНСТРУМЕНТЫ V11',pt:'FERRAMENTAS INTELIGENTES V11',de:'V11 SMART-TOOLS'},
'Extra tools':{fa:'ابزارهای بیشتر',ar:'أدوات إضافية',es:'Herramientas extra',fr:'Outils supplémentaires',zh:'更多工具',hi:'अतिरिक्त टूल्स',ru:'Дополнительные инструменты',pt:'Ferramentas extras',de:'Zusätzliche Tools'},
'FOCUS TIMER':{fa:'تایمر تمرکز',ar:'مؤقت التركيز',es:'TEMPORIZADOR DE ENFOQUE',fr:'MINUTEUR DE CONCENTRATION',zh:'专注计时器',hi:'फोकस टाइमर',ru:'ТАЙМЕР ФОКУСА',pt:'TEMPORIZADOR DE FOCO',de:'FOKUS-TIMER'},
'▶ Start':{fa:'▶ شروع',ar:'▶ بدء',es:'▶ Iniciar',fr:'▶ Démarrer',zh:'▶ 开始',hi:'▶ शुरू',ru:'▶ Старт',pt:'▶ Iniciar',de:'▶ Start'},
'⏸ Pause':{fa:'⏸ توقف',ar:'⏸ إيقاف مؤقت',es:'⏸ Pausa',fr:'⏸ Pause',zh:'⏸ 暂停',hi:'⏸ रोकें',ru:'⏸ Пауза',pt:'⏸ Pausar',de:'⏸ Pause'},
'↻ Reset':{fa:'↻ بازنشانی',ar:'↻ إعادة ضبط',es:'↻ Reiniciar',fr:'↻ Réinitialiser',zh:'↻ 重置',hi:'↻ रीसेट',ru:'↻ Сбросить',pt:'↻ Redefinir',de:'↻ Zurücksetzen'},
'📦 Backup progress':{fa:'📦 پشتیبان‌گیری پیشرفت',ar:'📦 نسخ احتياطي للتقدم',es:'📦 Copia de seguridad',fr:'📦 Sauvegarde de progression',zh:'📦 备份进度',hi:'📦 प्रगति बैकअप',ru:'📦 Резервная копия прогресса',pt:'📦 Backup do progresso',de:'📦 Fortschritt sichern'},
'Export':{fa:'خروجی',ar:'تصدير',es:'Exportar',fr:'Exporter',zh:'导出',hi:'निर्यात',ru:'Экспорт',pt:'Exportar',de:'Exportieren'},
'📥 Restore progress':{fa:'📥 بازیابی پیشرفت',ar:'📥 استعادة التقدم',es:'📥 Restaurar progreso',fr:'📥 Restaurer la progression',zh:'📥 恢复进度',hi:'📥 प्रगति पुनर्स्थापित करें',ru:'📥 Восстановить прогресс',pt:'📥 Restaurar progresso',de:'📥 Fortschritt wiederherstellen'},
'📤 Share progress':{fa:'📤 اشتراک‌گذاری پیشرفت',ar:'📤 مشاركة التقدم',es:'📤 Compartir progreso',fr:'📤 Partager la progression',zh:'📤 分享进度',hi:'📤 प्रगति साझा करें',ru:'📤 Поделиться прогрессом',pt:'📤 Compartilhar progresso',de:'📤 Fortschritt teilen'},
'Share':{fa:'اشتراک',ar:'مشاركة',es:'Compartir',fr:'Partager',zh:'分享',hi:'साझा करें',ru:'Поделиться',pt:'Compartilhar',de:'Teilen'},
'📱 Install app':{fa:'📱 نصب برنامه',ar:'📱 تثبيت التطبيق',es:'📱 Instalar app',fr:'📱 Installer l’application',zh:'📱 安装应用',hi:'📱 ऐप इंस्टॉल करें',ru:'📱 Установить приложение',pt:'📱 Instalar app',de:'📱 App installieren'},
'💰 Advertising':{fa:'💰 تبلیغات',ar:'💰 الإعلانات',es:'💰 Publicidad',fr:'💰 Publicité',zh:'💰 广告',hi:'💰 विज्ञापन',ru:'💰 Реклама',pt:'💰 Publicidade',de:'💰 Werbung'},
'Ad setup info':{fa:'اطلاعات تنظیم تبلیغات',ar:'معلومات إعداد الإعلانات',es:'Información de anuncios',fr:'Infos de configuration publicitaire',zh:'广告设置说明',hi:'विज्ञापन सेटअप जानकारी',ru:'Настройка рекламы',pt:'Informações de anúncios',de:'Werbeeinstellungen'},
'MY PROGRESS':{fa:'پیشرفت من',ar:'تقدمي',es:'MI PROGRESO',fr:'MA PROGRESSION',zh:'我的进度',hi:'मेरी प्रगति',ru:'МОЙ ПРОГРЕСС',pt:'MEU PROGRESSO',de:'MEIN FORTSCHRITT'},
'Your learning dashboard':{fa:'داشبورد یادگیری شما',ar:'لوحة تعلمك',es:'Tu panel de aprendizaje',fr:'Votre tableau de bord',zh:'你的学习面板',hi:'आपका लर्निंग डैशबोर्ड',ru:'Панель обучения',pt:'Seu painel de aprendizagem',de:'Dein Lern-Dashboard'},
'English Learner':{fa:'یادگیرنده انگلیسی',ar:'متعلم الإنجليزية',es:'Estudiante de inglés',fr:'Apprenant d’anglais',zh:'英语学习者',hi:'अंग्रेज़ी शिक्षार्थी',ru:'Изучающий английский',pt:'Aprendiz de inglês',de:'Englischlernender'},
'XP progress':{fa:'پیشرفت XP',ar:'تقدم XP',es:'Progreso de XP',fr:'Progression XP',zh:'XP进度',hi:'XP प्रगति',ru:'Прогресс XP',pt:'Progresso de XP',de:'XP-Fortschritt'},
'Next milestone':{fa:'مرحله بعدی',ar:'المرحلة التالية',es:'Próximo objetivo',fr:'Prochaine étape',zh:'下一里程碑',hi:'अगला लक्ष्य',ru:'Следующая цель',pt:'Próximo marco',de:'Nächster Meilenstein'},
'🌱 Getting Started':{fa:'🌱 شروع کار',ar:'🌱 البداية',es:'🌱 Primeros pasos',fr:'🌱 Débutant',zh:'🌱 入门',hi:'🌱 शुरुआत',ru:'🌱 Начало',pt:'🌱 Começando',de:'🌱 Erste Schritte'},
'Saved words:':{fa:'لغات ذخیره‌شده:',ar:'الكلمات المحفوظة:',es:'Palabras guardadas:',fr:'Mots enregistrés :',zh:'已保存词汇：',hi:'सहेजे शब्द:',ru:'Сохранённых слов:',pt:'Palavras salvas:',de:'Gespeicherte Wörter:'},
'V11 achievements':{fa:'دستاوردهای V11',ar:'إنجازات V11',es:'Logros V11',fr:'Réalisations V11',zh:'V11成就',hi:'V11 उपलब्धियाँ',ru:'Достижения V11',pt:'Conquistas V11',de:'V11-Erfolge'},
'lessons completed':{fa:'درس تکمیل‌شده',ar:'دروس مكتملة',es:'lecciones completadas',fr:'leçons terminées',zh:'已完成课程',hi:'पाठ पूरे',ru:'уроков завершено',pt:'lições concluídas',de:'Lektionen abgeschlossen'},
'tests completed':{fa:'آزمون تکمیل‌شده',ar:'اختبارات مكتملة',es:'pruebas completadas',fr:'tests terminés',zh:'已完成测试',hi:'टेस्ट पूरे',ru:'тестов завершено',pt:'testes concluídos',de:'Tests abgeschlossen'},
'🏆 Gamification':{fa:'🏆 بازی‌وارسازی',ar:'🏆 التحفيز بالألعاب',es:'🏆 Gamificación',fr:'🏆 Gamification',zh:'🏆 游戏化',hi:'🏆 गेमिफिकेशन',ru:'🏆 Геймификация',pt:'🏆 Gamificação',de:'🏆 Gamification'},
'🔥 Streak rewards':{fa:'🔥 پاداش زنجیره',ar:'🔥 مكافآت الاستمرارية',es:'🔥 Recompensas de racha',fr:'🔥 Récompenses de série',zh:'🔥 连续学习奖励',hi:'🔥 स्ट्रीक पुरस्कार',ru:'🔥 Награды за серию',pt:'🔥 Recompensas de sequência',de:'🔥 Serien-Belohnungen'},
'🎯 Daily challenge':{fa:'🎯 چالش روزانه',ar:'🎯 تحدي يومي',es:'🎯 Desafío diario',fr:'🎯 Défi quotidien',zh:'🎯 每日挑战',hi:'🎯 दैनिक चुनौती',ru:'🎯 Ежедневное задание',pt:'🎯 Desafio diário',de:'🎯 Tages-Challenge'},
'📅 Weekly challenge':{fa:'📅 چالش هفتگی',ar:'📅 تحدي أسبوعي',es:'📅 Desafío semanal',fr:'📅 Défi hebdomadaire',zh:'📅 每周挑战',hi:'📅 साप्ताहिक चुनौती',ru:'📅 Еженедельное задание',pt:'📅 Desafio semanal',de:'📅 Wochen-Challenge'},
'🏅 Badges':{fa:'🏅 نشان‌ها',ar:'🏅 الشارات',es:'🏅 Insignias',fr:'🏅 Badges',zh:'🏅 徽章',hi:'🏅 बैज',ru:'🏅 Значки',pt:'🏅 Distintivos',de:'🏅 Abzeichen'},
'🏆 Weekly leaderboard':{fa:'🏆 جدول امتیازات هفتگی',ar:'🏆 لوحة المتصدرين الأسبوعية',es:'🏆 Clasificación semanal',fr:'🏆 Classement hebdomadaire',zh:'🏆 每周排行榜',hi:'🏆 साप्ताहिक लीडरबोर्ड',ru:'🏆 Еженедельная таблица лидеров',pt:'🏆 Classificação semanal',de:'🏆 Wochenrangliste'},
'Reset progress':{fa:'بازنشانی پیشرفت',ar:'إعادة ضبط التقدم',es:'Restablecer progreso',fr:'Réinitialiser la progression',zh:'重置进度',hi:'प्रगति रीसेट करें',ru:'Сбросить прогресс',pt:'Redefinir progresso',de:'Fortschritt zurücksetzen'},
'Home':{fa:'خانه',ar:'الرئيسية',es:'Inicio',fr:'Accueil',zh:'首页',hi:'होम',ru:'Главная',pt:'Início',de:'Startseite'},
'Learn':{fa:'یادگیری',ar:'تعلّم',es:'Aprender',fr:'Apprendre',zh:'学习',hi:'सीखें',ru:'Учёба',pt:'Aprender',de:'Lernen'},
'Vocab':{fa:'واژگان',ar:'المفردات',es:'Vocabulario',fr:'Vocabulaire',zh:'词汇',hi:'शब्दावली',ru:'Словарь',pt:'Vocabulário',de:'Vokabeln'},
'Test':{fa:'آزمون',ar:'اختبار',es:'Prueba',fr:'Test',zh:'测试',hi:'टेस्ट',ru:'Тест',pt:'Teste',de:'Test'},
'Speak':{fa:'گفتار',ar:'تحدث',es:'Hablar',fr:'Parler',zh:'口语',hi:'बोलें',ru:'Речь',pt:'Falar',de:'Sprechen'},
'AI':{fa:'هوش مصنوعی',ar:'الذكاء الاصطناعي',es:'IA',fr:'IA',zh:'AI',hi:'AI',ru:'ИИ',pt:'IA',de:'KI'},
'Academy':{fa:'آکادمی',ar:'الأكاديمية',es:'Academia',fr:'Académie',zh:'学院',hi:'अकादमी',ru:'Академия',pt:'Academia',de:'Akademie'},
'Tools':{fa:'ابزارها',ar:'الأدوات',es:'Herramientas',fr:'Outils',zh:'工具',hi:'टूल्स',ru:'Инструменты',pt:'Ferramentas',de:'Tools'},
'Profile':{fa:'پروفایل',ar:'الملف الشخصي',es:'Perfil',fr:'Profil',zh:'个人资料',hi:'प्रोफ़ाइल',ru:'Профиль',pt:'Perfil',de:'Profil'},
'Premium':{fa:'پریمیوم',ar:'بريميوم',es:'Premium',fr:'Premium',zh:'高级版',hi:'प्रीमियम',ru:'Премиум',pt:'Premium',de:'Premium'},
'V11 ACCOUNT':{fa:'حساب V11',ar:'حساب V11',es:'CUENTA V11',fr:'COMPTE V11',zh:'V11账户',hi:'V11 खाता',ru:'АККАУНТ V11',pt:'CONTA V11',de:'V11-KONTO'},
'Sign in':{fa:'ورود',ar:'تسجيل الدخول',es:'Iniciar sesión',fr:'Se connecter',zh:'登录',hi:'साइन इन',ru:'Войти',pt:'Entrar',de:'Anmelden'},
'Continue':{fa:'ادامه',ar:'متابعة',es:'Continuar',fr:'Continuer',zh:'继续',hi:'जारी रखें',ru:'Продолжить',pt:'Continuar',de:'Weiter'},
'Create an account':{fa:'ساخت حساب',ar:'إنشاء حساب',es:'Crear una cuenta',fr:'Créer un compte',zh:'创建账户',hi:'खाता बनाएँ',ru:'Создать аккаунт',pt:'Criar conta',de:'Konto erstellen'},
'Already have an account? Sign in':{fa:'حساب داری؟ وارد شو',ar:'لديك حساب؟ سجّل الدخول',es:'¿Ya tienes una cuenta? Inicia sesión',fr:'Vous avez déjà un compte ? Connectez-vous',zh:'已有账户？登录',hi:'पहले से खाता है? साइन इन करें',ru:'Уже есть аккаунт? Войти',pt:'Já tem uma conta? Entre',de:'Schon ein Konto? Anmelden'},
'Name (for registration)':{fa:'نام (برای ثبت‌نام)',ar:'الاسم (للتسجيل)',es:'Nombre (para registro)',fr:'Nom (pour inscription)',zh:'姓名（注册用）',hi:'नाम (पंजीकरण के लिए)',ru:'Имя (для регистрации)',pt:'Nome (para cadastro)',de:'Name (für Registrierung)'},
'Email':{fa:'ایمیل',ar:'البريد الإلكتروني',es:'Correo electrónico',fr:'E-mail',zh:'邮箱',hi:'ईमेल',ru:'Эл. почта',pt:'E-mail',de:'E-Mail'},
'Password':{fa:'رمز عبور',ar:'كلمة المرور',es:'Contraseña',fr:'Mot de passe',zh:'密码',hi:'पासवर्ड',ru:'Пароль',pt:'Senha',de:'Passwort'},
'G  Continue with Google':{fa:'G  ادامه با گوگل',ar:'G  المتابعة مع Google',es:'G  Continuar con Google',fr:'G  Continuer avec Google',zh:'G  使用Google继续',hi:'G  Google से जारी रखें',ru:'G  Продолжить с Google',pt:'G  Continuar com Google',de:'G  Mit Google fortfahren'}
};

const EMP_VOCAB={
reliable:{fa:'قابل اعتماد',ar:'موثوق',es:'fiable',fr:'fiable',zh:'可靠的',hi:'विश्वसनीय',ru:'надёжный',pt:'confiável',de:'zuverlässig'},
improve:{fa:'بهتر کردن / پیشرفت کردن',ar:'يُحسّن',es:'mejorar',fr:'améliorer',zh:'改善；提高',hi:'सुधारना',ru:'улучшать',pt:'melhorar',de:'verbessern'},
confident:{fa:'بااعتمادبه‌نفس',ar:'واثق',es:'seguro de sí mismo',fr:'confiant',zh:'自信的',hi:'आत्मविश्वासी',ru:'уверенный',pt:'confiante',de:'selbstbewusst'},
opportunity:{fa:'فرصت',ar:'فرصة',es:'oportunidad',fr:'occasion',zh:'机会',hi:'अवसर',ru:'возможность',pt:'oportunidade',de:'Gelegenheit'},
effective:{fa:'موثر',ar:'فعّال',es:'eficaz',fr:'efficace',zh:'有效的',hi:'प्रभावी',ru:'эффективный',pt:'eficaz',de:'wirksam'},
curious:{fa:'کنجکاو',ar:'فضولي',es:'curioso',fr:'curieux',zh:'好奇的',hi:'जिज्ञासु',ru:'любопытный',pt:'curioso',de:'neugierig'},
achieve:{fa:'به هدف رسیدن / به دست آوردن',ar:'يحقق',es:'lograr',fr:'atteindre',zh:'实现；达到',hi:'प्राप्त करना',ru:'достигать',pt:'alcançar',de:'erreichen'}
};
const EMP_EXAMPLES={
reliable:{en:'This app is reliable even when I study offline.',fa:'این برنامه حتی وقتی آفلاین درس می‌خوانم قابل اعتماد است.',ar:'هذا التطبيق موثوق حتى عندما أدرس دون اتصال.',es:'Esta aplicación es fiable incluso cuando estudio sin conexión.',fr:"Cette application est fiable même lorsque j’étudie hors ligne.",zh:'即使我离线学习，这个应用也很可靠。',hi:'यह ऐप तब भी विश्वसनीय है जब मैं ऑफ़लाइन पढ़ता हूँ।',ru:'Это приложение надёжно, даже когда я учусь офлайн.',pt:'Este aplicativo é confiável mesmo quando estudo offline.',de:'Diese App ist zuverlässig, auch wenn ich offline lerne.'},
improve:{en:'Practice every day to improve your English.',fa:'هر روز تمرین کن تا انگلیسی‌ات بهتر شود.',ar:'تدرّب كل يوم لتحسّن لغتك الإنجليزية.',es:'Practica cada día para mejorar tu inglés.',fr:'Pratiquez chaque jour pour améliorer votre anglais.',zh:'每天练习以提高你的英语。',hi:'अपनी अंग्रेज़ी सुधारने के लिए हर दिन अभ्यास करें।',ru:'Практикуйтесь каждый день, чтобы улучшать английский.',pt:'Pratique todos os dias para melhorar seu inglês.',de:'Übe jeden Tag, um dein Englisch zu verbessern.'},
confident:{en:'She feels confident when speaking English.',fa:'او هنگام صحبت کردن انگلیسی اعتمادبه‌نفس دارد.',ar:'تشعر بالثقة عند التحدث بالإنجليزية.',es:'Ella se siente segura al hablar inglés.',fr:'Elle se sent en confiance quand elle parle anglais.',zh:'她说英语时很自信。',hi:'अंग्रेज़ी बोलते समय वह आत्मविश्वासी महसूस करती है।',ru:'Она уверенно чувствует себя, когда говорит по-английски.',pt:'Ela se sente confiante ao falar inglês.',de:'Sie fühlt sich beim Englischsprechen selbstbewusst.'},
opportunity:{en:'Learning English can create new opportunities.',fa:'یادگیری انگلیسی می‌تواند فرصت‌های تازه ایجاد کند.',ar:'يمكن لتعلم الإنجليزية أن يخلق فرصًا جديدة.',es:'Aprender inglés puede crear nuevas oportunidades.',fr:'Apprendre l’anglais peut créer de nouvelles opportunités.',zh:'学习英语可以创造新的机会。',hi:'अंग्रेज़ी सीखना नए अवसर पैदा कर सकता है।',ru:'Изучение английского может создать новые возможности.',pt:'Aprender inglês pode criar novas oportunidades.',de:'Englischlernen kann neue Chancen schaffen.'},
effective:{en:'Short daily practice can be very effective.',fa:'تمرین کوتاه روزانه می‌تواند بسیار موثر باشد.',ar:'يمكن أن يكون التدريب اليومي القصير فعالًا جدًا.',es:'La práctica diaria breve puede ser muy eficaz.',fr:'Une courte pratique quotidienne peut être très efficace.',zh:'每天短时间练习可以非常有效。',hi:'छोटा दैनिक अभ्यास बहुत प्रभावी हो सकता है।',ru:'Короткая ежедневная практика может быть очень эффективной.',pt:'Uma prática diária curta pode ser muito eficaz.',de:'Kurzes tägliches Üben kann sehr wirksam sein.'},
curious:{en:'I am curious about how native speakers use this phrase.',fa:'کنجکاوم بدانم گویندگان بومی از این عبارت چگونه استفاده می‌کنند.',ar:'أشعر بالفضول لمعرفة كيف يستخدم المتحدثون الأصليون هذه العبارة.',es:'Tengo curiosidad por cómo usan esta frase los hablantes nativos.',fr:'Je suis curieux de savoir comment les locuteurs natifs utilisent cette expression.',zh:'我很好奇母语者如何使用这个短语。',hi:'मैं जानना चाहता हूँ कि मूल वक्ता इस वाक्यांश का उपयोग कैसे करते हैं।',ru:'Мне интересно, как носители используют эту фразу.',pt:'Tenho curiosidade sobre como os falantes nativos usam esta expressão.',de:'Ich bin neugierig, wie Muttersprachler diesen Ausdruck verwenden.'},
achieve:{en:'Small habits help you achieve bigger goals.',fa:'عادت‌های کوچک کمک می‌کنند به هدف‌های بزرگ‌تر برسی.',ar:'تساعدك العادات الصغيرة على تحقيق أهداف أكبر.',es:'Los pequeños hábitos te ayudan a lograr objetivos mayores.',fr:'Les petites habitudes vous aident à atteindre de grands objectifs.',zh:'小习惯能帮助你实现更大的目标。',hi:'छोटी आदतें आपको बड़े लक्ष्य हासिल करने में मदद करती हैं।',ru:'Маленькие привычки помогают достигать больших целей.',pt:'Pequenos hábitos ajudam você a alcançar objetivos maiores.',de:'Kleine Gewohnheiten helfen dir, größere Ziele zu erreichen.'}
};

function empT(key){if(empLang==='en')return key;const row=EMP_T[key];return row?.[empLang]||key;}
function empSetText(el,key){if(el)el.textContent=empT(key)}
function empTranslateStatic(){
  const root=document.body; if(!root)return;
  const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT); const nodes=[];
  while(walker.nextNode())nodes.push(walker.currentNode);
  nodes.forEach(n=>{if(!n.parentElement||['SCRIPT','STYLE'].includes(n.parentElement.tagName))return;const raw=n.nodeValue;const key=n.__empSource||raw.trim();if(!key)return;n.__empSource=key;const val=empT(key);if(val!==key)n.nodeValue=raw.replace(raw.trim(),val);});
  document.documentElement.lang=empLang; document.documentElement.dir=empLang==='fa'||empLang==='ar'?'rtl':'ltr'; document.body.classList.toggle('rtl',empLang==='fa'||empLang==='ar');
  const sel=document.getElementById('languageSelect');if(sel)sel.value=empLang;
  document.title=empT('English Master Pro')==='English Master Pro'?'English Master Pro v11.6':empT('English Master Pro');
}
function setAppLanguage(lang){if(!EMP_LANGS.includes(lang))lang='en';empLang=lang;localStorage.setItem('emp_language',lang);empTranslateStatic();try{update();renderVocab();}catch(e){}try{renderSkills();}catch(e){}try{if(document.getElementById('profile')?.classList.contains('active'))renderProfile();}catch(e){}try{if(document.getElementById('review')?.classList.contains('active'))renderReview();}catch(e){}}

const EMP_VOCAB_LIST=[['reliable','able to be trusted'],['improve','to become better'],['confident','sure about your ability'],['opportunity','a chance to do something'],['effective','successful in producing a result'],['curious','wanting to know or learn something'],['achieve','to successfully reach a goal']];
const _empOldRenderVocab=window.renderVocab;
window.renderVocab=function(){
  const q=(document.getElementById('vocabSearch')?.value||'').trim().toLowerCase();
  const matches=EMP_VOCAB_LIST.filter(v=>!q||v[0].includes(q)||v[1].toLowerCase().includes(q));
  const v=matches[(state.vocabIndex||0)%Math.max(1,matches.length)]||EMP_VOCAB_LIST[0]; const key=v[0]; const meaning=empLang==='en'?v[1]:((EMP_VOCAB[key]||{})[empLang]||v[1]); const ex=(EMP_EXAMPLES[key]||{})[empLang]||(EMP_EXAMPLES[key]||{}).en; const fav=(state.favorites||[]).includes(key); const card=document.getElementById('vocabCard'); if(!card)return;
  card.innerHTML=`<span class="pill">${empLang==='en'?'WORD':empLang==='fa'?'لغت':'WORD'} · ${key}</span><h1>${key}</h1><p class="meaning">${meaning}</p><div class="example"><b>${empT('Example')||'Example'}</b><div class="wordSmall">${ex}</div></div><button class="secondary" onclick="speakWord()">🔊 ${empT('Listen')||'Listen'}</button><button class="secondary" onclick="toggleFavorite()">${fav?'★ '+(empLang==='fa'?'ذخیره شد':'Saved'):'☆ '+(empLang==='fa'?'ذخیره لغت':'Save word')}</button><button class="primary" onclick="nextVocab()">${empLang==='fa'?'بلدم · +۵ XP':'I know it · +5 XP'}</button>`;
};
function empExample(){return empT('Example')||'Example'}

// Localize core generated learning views.
window.renderSkills=function(){const icons={Speaking:'🗣️',Listening:'🎧',Reading:'📖',Writing:'✍️'};const box=document.getElementById('skillList');if(!box)return;box.innerHTML=Object.keys(lessons).map(k=>`<div class="lesson"><div class="icon">${icons[k]}</div><div style="flex:1"><h3>${empT(k)}</h3><p>${lessons[k].length} ${empLang==='fa'?'درس هدایت‌شده · تمرین · بازخورد':'guided lessons · practice · feedback'}</p></div><button class="secondary" onclick="openSkill('${k}')">${empT('Open')||'Open'}</button></div>`).join('')};
window.openSkill=function(skill){currentSkill=skill;openPage('skillPage');const hero=document.getElementById('skillHero');if(hero)hero.innerHTML=`<div class="skillHero"><span class="pill">${empT('Four fundamental skills')}</span><h1>${empT(skill)}</h1><p class="muted">${empLang==='fa'?'توانایی '+empT(skill)+' خود را با تمرین ساختاریافته تقویت کن.':`Build your ${skill.toLowerCase()} ability through structured practice.`}</p></div>`;const list=document.getElementById('lessonList');if(list)list.innerHTML=lessons[skill].map((l,i)=>`<div class="lesson"><div class="icon">${l[0]}</div><div style="flex:1"><h3>${i+1}. ${l[1]}</h3><p>${l[2]} · ${l[4]}</p></div><button class="secondary" onclick="startLesson(${i})">${empT('Start')}</button></div>`).join('')};
window.startLesson=function(i){currentLesson=i;openPage('lessonPage');const l=lessons[currentSkill][i];const box=document.getElementById('lessonBox');if(box)box.innerHTML=`<div class="lessonContent"><span class="pill">${empT(currentSkill)} · ${l[4]}</span><h1>${l[1]}</h1><p>${l[2]}</p><div class="example"><b>${empLang==='fa'?'زبان کلیدی':'Key language'}</b><div class="word">${l[3]}</div></div><h3>${empLang==='fa'?'تمرین':'Practice'}</h3><p>${empLang==='fa'?'مثال را با صدای بلند بخوان، جمله خودت را بنویس و معنی آن را با کلمات خودت توضیح بده.':'Read the example aloud, write your own sentence, and explain its meaning in your own words.'}</p><button class="primary" onclick="completeLesson()">${empLang==='fa'?'تکمیل درس · +۲۰ XP':'Complete lesson · +20 XP'}</button>${currentSkill==='Speaking'?'<button class="secondary" onclick="modelSpeech()">🔊 '+(empLang==='fa'?'گوش دادن به نمونه':'Listen to model')+'</button>':''}</div>`};

window.renderTest=function(){selected={};quizSubmitted=false;const box=document.getElementById('testBox');if(!box)return;box.innerHTML=questions.map((q,i)=>`<div class="quizQ"><b>${i+1}. ${q[0]}</b>${q.slice(1,5).map((o,j)=>`<button class="option" onclick="choose(${i},${j},this)">${String.fromCharCode(65+j)}. ${o}</button>`).join('')}</div>`).join('')+`<button class="primary" onclick="finishTest()">${empLang==='fa'?'سطح من را محاسبه کن':'Calculate my level'}</button><div id="result" class="result"></div>`};

// Translate the most visible dynamic status/alerts.
const _empOldStudy=window.renderStudySchedule;
window.renderStudySchedule=function(){refreshStudySessions();const slot=studySlot();const labels={morning:['☀️ '+(empLang==='fa'?'صبح':'Morning'),'06:00–12:00'],afternoon:['🌤️ '+(empLang==='fa'?'بعدازظهر':'Afternoon'),'12:00–18:00'],evening:['🌙 '+(empLang==='fa'?'شب':'Evening'),'18:00–24:00']};const el=document.getElementById('studySlots');if(!el)return;el.innerHTML=Object.keys(labels).map(k=>`<div class="studySlot ${state.studySessions[k]?'done':''} ${slot===k?'current':''}"><b>${labels[k][0]}</b><small>${labels[k][1]}</small><small>${state.studySessions[k]?'✓ '+(empLang==='fa'?'انجام شد':'Done'):slot===k?(empLang==='fa'?'اکنون وقت مطالعه است':'Study now'):(empLang==='fa'?'هنوز انجام نشده':'Not done yet')}</small></div>`).join('');const m=document.getElementById('studyScheduleMessage');if(m)m.textContent=state.studySessions.morning&&state.studySessions.afternoon&&state.studySessions.evening?(empLang==='fa'?'آفرین! هر سه نوبت امروز را انجام دادی. فاصله دادن بین درس‌ها کمک می‌کند خسته نشوی.':'Great! You completed all three sessions today. Spacing study helps you avoid getting tired.'):(empLang==='fa'?'سه نوبت امروز را در زمان‌های مختلف انجام بده؛ بینشان استراحت داشته باش.':'Complete the three sessions at different times and rest between them.');};
window.showStudyReason=function(){alert(empLang==='fa'?'سه نوبت مطالعه باعث می‌شود درس‌ها کوتاه و پخش‌شده باشند و از مطالعه خسته نشوی. بین نوبت‌ها استراحت کن.':'Three study sessions keep learning short and spaced out so you do not get tired. Rest between sessions.')};

const _empOldUpdate=window.update;
window.update=function(){_empOldUpdate();const level=document.getElementById('level');if(level){const map={Beginner:{fa:'مبتدی',ar:'مبتدئ',es:'Principiante',fr:'Débutant',zh:'初级',hi:'शुरुआती',ru:'Начальный',pt:'Iniciante',de:'Anfänger'},Elementary:{fa:'ابتدایی',ar:'أساسي',es:'Elemental',fr:'Élémentaire',zh:'初阶',hi:'प्राथमिक',ru:'Элементарный',pt:'Elementar',de:'Grundstufe'},Intermediate:{fa:'متوسط',ar:'متوسط',es:'Intermedio',fr:'Intermédiaire',zh:'中级',hi:'मध्यवर्ती',ru:'Средний',pt:'Intermediário',de:'Mittelstufe'},'Upper-Intermediate':{fa:'فوق متوسط',ar:'فوق المتوسط',es:'Intermedio alto',fr:'Intermédiaire supérieur',zh:'中高级',hi:'उच्च-मध्यवर्ती',ru:'Выше среднего',pt:'Intermediário avançado',de:'Obere Mittelstufe'},Advanced:{fa:'پیشرفته',ar:'متقدم',es:'Avanzado',fr:'Avancé',zh:'高级',hi:'उन्नत',ru:'Продвинутый',pt:'Avançado',de:'Fortgeschritten'}};level.textContent=empLang==='en'?state.level:(map[state.level]?.[empLang]||state.level)} };

// Replace vocabulary speech with the selected language's meaning/word.
window.speakWord=function(){const v=EMP_VOCAB_LIST[(state.vocabIndex||0)%EMP_VOCAB_LIST.length];if('speechSynthesis' in window){try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(v[0]);u.lang={en:'en-US',fa:'fa-IR',ar:'ar-SA',es:'es-ES',fr:'fr-FR',zh:'zh-CN',hi:'hi-IN',ru:'ru-RU',pt:'pt-BR',de:'de-DE'}[empLang]||'en-US';speechSynthesis.speak(u);return}catch(e){}}alert((empLang==='fa'?'لغت: ':'Word: ')+v[0]);};

// Run after the existing v11 boot code; keeps language choice persistent.
try{empTranslateStatic();renderVocab();renderSkills();}catch(e){}

Object.assign(EMP_T,{
'PREMIUM':{fa:'پریمیوم',ar:'بريميوم',es:'PREMIUM',fr:'PREMIUM',zh:'高级版',hi:'प्रीमियम',ru:'ПРЕМИУМ',pt:'PREMIUM',de:'PREMIUM'},
'Open':{fa:'باز کردن',ar:'فتح',es:'Abrir',fr:'Ouvrir',zh:'打开',hi:'खोलें',ru:'Открыть',pt:'Abrir',de:'Öffnen'},
'Example':{fa:'مثال',ar:'مثال',es:'Ejemplo',fr:'Exemple',zh:'例句',hi:'उदाहरण',ru:'Пример',pt:'Exemplo',de:'Beispiel'},
'Listen':{fa:'گوش دادن',ar:'استماع',es:'Escuchar',fr:'Écouter',zh:'听',hi:'सुनें',ru:'Слушать',pt:'Ouvir',de:'Anhören'},
'Saved':{fa:'ذخیره شد',ar:'محفوظ',es:'Guardado',fr:'Enregistré',zh:'已保存',hi:'सहेजा गया',ru:'Сохранено',pt:'Salvo',de:'Gespeichert'},
'Save word':{fa:'ذخیره لغت',ar:'حفظ الكلمة',es:'Guardar palabra',fr:'Enregistrer le mot',zh:'保存词汇',hi:'शब्द सहेजें',ru:'Сохранить слово',pt:'Salvar palavra',de:'Wort speichern'},
'V11 AI LEARNING PATH':{fa:'مسیر یادگیری هوشمند V11',ar:'مسار تعلم V11 بالذكاء الاصطناعي',es:'RUTA DE APRENDIZAJE IA V11',fr:'PARCOURS D’APPRENTISSAGE IA V11',zh:'V11 AI学习路径',hi:'V11 AI सीखने का मार्ग',ru:'ПУТЬ ОБУЧЕНИЯ ИИ V11',pt:'CAMINHO DE APRENDIZAGEM IA V11',de:'V11 KI-LERNPFAD'},
'🧾 Subscription management':{fa:'🧾 مدیریت اشتراک',ar:'🧾 إدارة الاشتراك',es:'🧾 Gestión de suscripción',fr:'🧾 Gestion de l’abonnement',zh:'🧾 订阅管理',hi:'🧾 सदस्यता प्रबंधन',ru:'🧾 Управление подпиской',pt:'🧾 Gestão da assinatura',de:'🧾 Abonnement verwalten'},
'🧾 Subscription':{fa:'🧾 اشتراک',ar:'🧾 الاشتراك',es:'🧾 Suscripción',fr:'🧾 Abonnement',zh:'🧾 订阅',hi:'🧾 सदस्यता',ru:'🧾 Подписка',pt:'🧾 Assinatura',de:'🧾 Abonnement'},
'Restore Google Play purchase':{fa:'بازیابی خرید Google Play',ar:'استعادة شراء Google Play',es:'Restaurar compra de Google Play',fr:'Restaurer l’achat Google Play',zh:'恢复Google Play购买',hi:'Google Play खरीद बहाल करें',ru:'Восстановить покупку Google Play',pt:'Restaurar compra do Google Play',de:'Google-Play-Kauf wiederherstellen'},
'Manage Stripe subscription':{fa:'مدیریت اشتراک Stripe',ar:'إدارة اشتراك Stripe',es:'Gestionar suscripción de Stripe',fr:'Gérer l’abonnement Stripe',zh:'管理Stripe订阅',hi:'Stripe सदस्यता प्रबंधित करें',ru:'Управлять подпиской Stripe',pt:'Gerenciar assinatura Stripe',de:'Stripe-Abonnement verwalten'},
'🔒 Premium lesson preview':{fa:'🔒 پیش‌نمایش درس پریمیوم',ar:'🔒 معاينة درس بريميوم',es:'🔒 Vista previa de lección Premium',fr:'🔒 Aperçu de leçon Premium',zh:'🔒 高级课程预览',hi:'🔒 प्रीमियम पाठ पूर्वावलोकन',ru:'🔒 Предпросмотр премиум-урока',pt:'🔒 Prévia da lição Premium',de:'🔒 Premium-Lektionsvorschau'},
'Open lesson':{fa:'باز کردن درس',ar:'فتح الدرس',es:'Abrir lección',fr:'Ouvrir la leçon',zh:'打开课程',hi:'पाठ खोलें',ru:'Открыть урок',pt:'Abrir lição',de:'Lektion öffnen'},
'Install v11.6':{fa:'نصب v11.6',ar:'تثبيت v11.6',es:'Instalar v11.6',fr:'Installer v11.6',zh:'安装v11.6',hi:'v11.6 इंस्टॉल करें',ru:'Установить v11.6',pt:'Instalar v11.6',de:'v11.6 installieren'},
'constructor:- hezbullah kashmiri · English Master Pro v11.6':{fa:'سازنده:- hezbullah kashmiri · English Master Pro v11.6',ar:'المطوّر:- hezbullah kashmiri · English Master Pro v11.6',es:'constructor:- hezbullah kashmiri · English Master Pro v11.6',fr:'constructeur:- hezbullah kashmiri · English Master Pro v11.6',zh:'构建者:- hezbullah kashmiri · English Master Pro v11.6',hi:'निर्माता:- hezbullah kashmiri · English Master Pro v11.6',ru:'создатель:- hezbullah kashmiri · English Master Pro v11.6',pt:'criador:- hezbullah kashmiri · English Master Pro v11.6',de:'Ersteller:- hezbullah kashmiri · English Master Pro v11.6'},
'Search vocabulary…':{fa:'جستجوی لغات…',ar:'ابحث في المفردات…',es:'Buscar vocabulario…',fr:'Rechercher dans le vocabulaire…',zh:'搜索词汇…',hi:'शब्दावली खोजें…',ru:'Поиск слов…',pt:'Pesquisar vocabulário…',de:'Vokabeln suchen…'},
'Ask your English tutor…':{fa:'از مربی انگلیسی خود بپرس…',ar:'اسأل مدرس الإنجليزية…',es:'Pregunta a tu tutor de inglés…',fr:'Demandez à votre tuteur d’anglais…',zh:'问你的英语导师…',hi:'अपने अंग्रेज़ी ट्यूटर से पूछें…',ru:'Спросите репетитора по английскому…',pt:'Pergunte ao seu tutor de inglês…',de:'Frage deinen Englisch-Tutor…'},
'Type your English sentence…':{fa:'جمله انگلیسی خود را بنویس…',ar:'اكتب جملتك الإنجليزية…',es:'Escribe tu frase en inglés…',fr:'Écrivez votre phrase anglaise…',zh:'输入你的英语句子…',hi:'अपना अंग्रेज़ी वाक्य लिखें…',ru:'Введите английское предложение…',pt:'Digite sua frase em inglês…',de:'Gib deinen englischen Satz ein…'},
'Write about your day, school, work, or a goal...':{fa:'درباره روز، مکتب، کار یا هدف خود ۳ تا ۵ جمله بنویس...',ar:'اكتب 3-5 جمل عن يومك أو مدرستك أو عملك أو هدفك...',es:'Escribe 3-5 frases sobre tu día, escuela, trabajo u objetivo...',fr:'Écrivez 3 à 5 phrases sur votre journée, école, travail ou objectif...',zh:'写3-5句关于你的日子、学校、工作或目标的内容...',hi:'अपने दिन, स्कूल, काम या लक्ष्य के बारे में 3-5 वाक्य लिखें...',ru:'Напишите 3–5 предложений о своём дне, учёбе, работе или цели...',pt:'Escreva 3–5 frases sobre seu dia, escola, trabalho ou objetivo...',de:'Schreibe 3–5 Sätze über deinen Tag, deine Schule, Arbeit oder ein Ziel...'}
});

const _empTranslateStatic2=empTranslateStatic;
empTranslateStatic=function(){_empTranslateStatic2();const placeholders={en:['Search vocabulary…','Ask your English tutor…','Type your English sentence…','Write about your day, school, work, or a goal...'],fa:['جستجوی لغات…','از مربی انگلیسی خود بپرس…','جمله انگلیسی خود را بنویس…','درباره روز، مکتب، کار یا هدف خود ۳ تا ۵ جمله بنویس...'],ar:['ابحث في المفردات…','اسأل مدرس الإنجليزية…','اكتب جملتك الإنجليزية…','اكتب 3-5 جمل عن يومك أو مدرستك أو عملك أو هدفك...'],es:['Buscar vocabulario…','Pregunta a tu tutor de inglés…','Escribe tu frase en inglés…','Escribe 3-5 frases sobre tu día, escuela, trabajo u objetivo...'],fr:['Rechercher dans le vocabulaire…','Demandez à votre tuteur d’anglais…','Écrivez votre phrase anglaise…','Écrivez 3 à 5 phrases sur votre journée, école, travail ou objectif...'],zh:['搜索词汇…','问你的英语导师…','输入你的英语句子…','写3-5句关于你的日子、学校、工作或目标的内容...'],hi:['शब्दावली खोजें…','अपने अंग्रेज़ी ट्यूटर से पूछें…','अपना अंग्रेज़ी वाक्य लिखें…','अपने दिन, स्कूल, काम या लक्ष्य के बारे में 3-5 वाक्य लिखें...'],ru:['Поиск слов…','Спросите репетитора по английскому…','Введите английское предложение…','Напишите 3–5 предложений о своём дне, учёбе, работе или цели...'],pt:['Pesquisar vocabulário…','Pergunte ao seu tutor de inglês…','Digite sua frase em inglês…','Escreva 3–5 frases sobre seu dia, escola, trabalho ou objetivo...'],de:['Vokabeln suchen…','Frage deinen Englisch-Tutor…','Gib deinen englischen Satz ein…','Schreibe 3–5 Sätze über deinen Tag, deine Schule, Arbeit oder ein Ziel...']};const vals=placeholders[empLang]||placeholders.en;['vocabSearch','aiInput','speechFallbackInput','v10Writing'].forEach((id,i)=>{const el=document.getElementById(id);if(el)el.placeholder=vals[i]});};
try{empTranslateStatic();}catch(e){}


// v11.4: mandatory first-launch language selection. The app stays blocked until a language is chosen.
const EMP_FIRST_LANGUAGE_UI={
  en:{title:'Choose your language',subtitle:'Select the language you want to use in English Master Pro.'},
  fa:{title:'زبان خود را انتخاب کنید',subtitle:'زبانی را که می‌خواهید در English Master Pro استفاده کنید انتخاب کنید.'},
  ar:{title:'اختر لغتك',subtitle:'اختر اللغة التي تريد استخدامها في English Master Pro.'},
  es:{title:'Elige tu idioma',subtitle:'Selecciona el idioma que quieres usar en English Master Pro.'},
  fr:{title:'Choisissez votre langue',subtitle:'Sélectionnez la langue que vous souhaitez utiliser dans English Master Pro.'},
  zh:{title:'选择你的语言',subtitle:'请选择你要在 English Master Pro 中使用的语言。'},
  hi:{title:'अपनी भाषा चुनें',subtitle:'English Master Pro में इस्तेमाल करने के लिए भाषा चुनें।'},
  ru:{title:'Выберите язык',subtitle:'Выберите язык, который хотите использовать в English Master Pro.'},
  pt:{title:'Escolha seu idioma',subtitle:'Selecione o idioma que deseja usar no English Master Pro.'},
  de:{title:'Sprache auswählen',subtitle:'Wählen Sie die Sprache für English Master Pro.'}
};
function showFirstLanguagePicker(){
  const overlay=document.getElementById('firstLanguageOverlay');
  if(!overlay)return;
  overlay.classList.add('show'); overlay.setAttribute('aria-hidden','false');
  document.body.classList.add('firstLanguageLocked');
  const ui=EMP_FIRST_LANGUAGE_UI.en;
  const title=document.getElementById('firstLanguageTitle'), sub=document.getElementById('firstLanguageSubtitle');
  if(title)title.textContent=ui.title; if(sub)sub.textContent=ui.subtitle;
}
window.chooseFirstLanguage=function(lang){
  if(!EMP_LANGS.includes(lang))return;
  localStorage.setItem('emp_language',lang);
  empLang=lang;
  const overlay=document.getElementById('firstLanguageOverlay');
  if(overlay){overlay.classList.remove('show');overlay.setAttribute('aria-hidden','true');}
  document.body.classList.remove('firstLanguageLocked');
  empTranslateStatic();
  try{update();renderVocab();renderSkills();}catch(e){}
};
function initFirstLanguage(){
  const saved=localStorage.getItem('emp_language');
  if(saved && EMP_LANGS.includes(saved)){empLang=saved;return;}
  empLang='';
  showFirstLanguagePicker();
}
window.addEventListener('load',initFirstLanguage);


/* v11.7 weekly unlock gates: Premium UI removed; learning abilities unlock one per qualifying week. */
(function(){
  const _oldOpenPage=window.openPage;
  window.openPage=function(id){
    const level=rewardLevel();
    const gates={
      ai:1,
      speakingAdvanced:2,
      academyAdvanced:3,
      realAI:4
    };
    if(gates[id] && level<gates[id]){
      const names=empLang==='fa'?['AI Tutor','بازخورد پیشرفته گفتاری','دوره‌های پیشرفته B2–C1','AI Coach واقعی']:['AI Tutor','Advanced Speaking Feedback','B2–C1 Advanced Courses','Real AI Coach'];
      v10Toast((empLang==='fa'?'🔒 هنوز باز نشده: ':'🔒 Locked: ')+names[gates[id]-1]+` · ${Math.min(4,level)}/4`);
      return;
    }
    _oldOpenPage(id);
  };
  window.isAbilityUnlocked=function(key){
    const map={ai:1,speaking:2,advancedCourses:3,realAI:4};
    return rewardLevel()>=map[key];
  };
})();
