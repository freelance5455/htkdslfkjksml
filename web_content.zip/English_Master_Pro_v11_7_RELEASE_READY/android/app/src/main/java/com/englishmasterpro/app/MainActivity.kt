package com.englishmasterpro.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdView
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var banner: AdView
    private var interstitial: InterstitialAd? = null
    private val executor = Executors.newSingleThreadExecutor()

    // Release builds inject the real backend URL through EMP_BACKEND_URL.
    // Empty URL keeps the app in local/offline mode.
    private val backendUrl by lazy { getString(R.string.backend_url) }

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        loadInterstitial()

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = false
            if (android.os.Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            webViewClient = object : WebViewClientCompat() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest) =
                    assetLoader.shouldInterceptRequest(request.url)

                override fun shouldInterceptRequest(view: WebView, url: String) =
                    assetLoader.shouldInterceptRequest(android.net.Uri.parse(url))

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript("window.EMP_API_BASE=${JSONObject.quote(backendUrl)}", null)
                    view?.evaluateJavascript("window.v11Init && window.v11Init()", null)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        val wantsAudio = request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                        val trustedOrigin = request.origin?.host == "appassets.androidplatform.net"
                        if (wantsAudio && trustedOrigin && ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            request.grant(arrayOf(PermissionRequest.RESOURCE_AUDIO_CAPTURE))
                        } else {
                            request.deny()
                        }
                    }
                }
            }
        }
        web.addJavascriptInterface(NativeBridge(), "EnglishMasterNative")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        banner = AdView(this).apply {
            adUnitId = getString(R.string.admob_banner_id)
            setAdSize(com.google.android.gms.ads.AdSize.BANNER)
            loadAd(AdRequest.Builder().build())
        }
        val root = FrameLayout(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        val bp = FrameLayout.LayoutParams(-1, FrameLayout.LayoutParams.WRAP_CONTENT)
        bp.gravity = android.view.Gravity.BOTTOM
        root.addView(banner, bp)
        setContentView(root)
    }

    private fun requestMicPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun loadInterstitial() {
        InterstitialAd.load(this, getString(R.string.admob_interstitial_id), AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            override fun onAdFailedToLoad(error: AdError) { interstitial = null }
        })
    }

    inner class NativeBridge {
        @JavascriptInterface fun showInterstitial() { runOnUiThread { interstitial?.show(this@MainActivity); interstitial = null; loadInterstitial() } }
        @JavascriptInterface fun isNativeAndroid(): Boolean = true
        @JavascriptInterface fun requestMicrophonePermission() { runOnUiThread { requestMicPermissionIfNeeded() } }
    }

    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android API; retained for compatibility with older devices.")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
}
