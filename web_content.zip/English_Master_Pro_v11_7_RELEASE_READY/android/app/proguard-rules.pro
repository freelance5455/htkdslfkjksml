# Keep the JavaScript bridge callable from WebView after R8 shrinking.
-keepclassmembers class com.englishmasterpro.app.MainActivity$NativeBridge {
    <methods>;
}
-keepattributes JavascriptInterface

# Keep Billing/Play classes referenced reflectively by the SDKs.
-keep class com.android.billingclient.** { *; }
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.**
