#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ ! -f ./gradlew ]]; then
  echo "ERROR: Gradle wrapper (gradlew) is not included in this ZIP." >&2
  echo "Open android/ in Android Studio, or run this script from a machine with the project Gradle wrapper installed." >&2
  exit 2
fi

: "${ADMOB_APP_ID:?Set ADMOB_APP_ID to your real AdMob app ID}"
: "${ADMOB_BANNER_ID:?Set ADMOB_BANNER_ID to your real AdMob banner ID}"
: "${ADMOB_INTERSTITIAL_ID:?Set ADMOB_INTERSTITIAL_ID to your real AdMob interstitial ID}"
: "${EMP_KEYSTORE_PATH:?Set EMP_KEYSTORE_PATH to your private release keystore}"
: "${EMP_KEYSTORE_PASSWORD:?Set EMP_KEYSTORE_PASSWORD}"
: "${EMP_KEY_ALIAS:?Set EMP_KEY_ALIAS}"
: "${EMP_KEY_PASSWORD:?Set EMP_KEY_PASSWORD}"

./gradlew clean assembleRelease bundleRelease

echo
echo "Release APK: app/build/outputs/apk/release/app-release.apk"
echo "Release AAB: app/build/outputs/bundle/release/app-release.aab"
