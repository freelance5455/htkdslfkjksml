English Master Pro v11.6
Google Play release-focused Android project.

Key changes from v11.4:
- versionCode 116 / versionName 11.5.0
- compileSdk 36 / targetSdk 36 for the current Google Play submission requirement
- AGP 8.13.2 / Gradle 8.13-compatible configuration
- Release build refuses to ship without real AdMob IDs and a private signing keystore
- Debug and Release remain separated
- WebView microphone permission is no longer requested immediately at app launch; it is requested when needed
- WebView audio capture is restricted to the trusted appassets.androidplatform.net origin
- cleartext traffic disabled and network security config added
- Android backup/data extraction excluded by default for this app profile
- Play App Signing / upload-key workflow documented
- Google Play and Play Protect release checklist included

IMPORTANT: No private signing key, keystore, API secret, OAuth secret, or production AdMob ID is included.
