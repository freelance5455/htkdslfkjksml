CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY, email TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password_hash TEXT, google_id TEXT UNIQUE,
 plan TEXT NOT NULL DEFAULT 'free', subscription_status TEXT DEFAULT 'inactive', subscription_id TEXT,
 subscription_provider TEXT, stripe_customer_id TEXT, subscription_expires_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS progress (
 user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, data JSONB NOT NULL DEFAULT '{}'::jsonb, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ai_history (id BIGSERIAL PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, role TEXT NOT NULL, text TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE INDEX IF NOT EXISTS ai_history_user_idx ON ai_history(user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS push_subscriptions (user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, subscription JSONB NOT NULL, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS purchases (
 purchase_token TEXT PRIMARY KEY, user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE, product_id TEXT NOT NULL,
 provider TEXT NOT NULL, state TEXT NOT NULL, acknowledged BOOLEAN NOT NULL DEFAULT FALSE, raw JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS analytics_events (id BIGSERIAL PRIMARY KEY, user_id UUID REFERENCES users(id) ON DELETE SET NULL, event_name TEXT NOT NULL, properties JSONB, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE INDEX IF NOT EXISTS analytics_event_idx ON analytics_events(event_name, created_at DESC);
