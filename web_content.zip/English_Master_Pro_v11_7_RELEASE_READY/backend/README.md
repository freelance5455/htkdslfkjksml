# English Master Pro v11.2 Backend

Production-oriented backend for accounts, cloud sync, server-side AI, Stripe, Google OAuth, Web Push, Google Play purchase verification and analytics.

## Production setup
1. Create PostgreSQL and set `DATABASE_URL`.
2. Run `schema.sql` against that database.
3. Set a long random `JWT_SECRET` and all provider secrets in the deployment secret manager.
4. Configure Google OAuth redirect URI.
5. Configure Stripe prices + webhook.
6. Configure VAPID keys.
7. Configure Google Play service-account JSON and package/product IDs. The server verifies purchase tokens with Google before granting Premium.
8. Use HTTPS and a reverse proxy. Set `APP_ORIGIN` to the exact web origin.

## AI limits
Free users: `AI_FREE_DAILY_LIMIT` (default 5) requests/day.
Premium: `AI_PREMIUM_DAILY_LIMIT` (default 50) requests/day.
The server enforces the limit; the client cannot raise it.

## Google Play flow
Android -> `/api/play/verify` with purchase token -> Google Play Developer API -> unique token check -> entitlement -> server acknowledgment -> Premium. Pending purchases do not grant Premium.

## Analytics
The client posts minimal events to `/api/analytics`. No raw AI prompt is logged as analytics.
