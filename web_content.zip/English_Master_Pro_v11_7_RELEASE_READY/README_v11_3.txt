English Master Pro v11.6

New localization release:
- 10 app languages: English, Dari, Arabic, Spanish, French, Chinese, Hindi, Russian, Portuguese, German.
- Language selector in the app header with persistent choice.
- RTL layout for Dari and Arabic.
- Core interface labels, navigation, study screens, AI screens, profile/tools/premium/account labels translated.
- Vocabulary meanings translated into all 10 languages.
- Vocabulary examples translated into all 10 languages.
- Language selection works offline from bundled dictionaries.
- Android WebView assets updated and Android version bumped to 11.4.0 (versionCode 114).

The translation pack is local/offline; it does not require a translation API. English learning content remains the target language, while explanations and UI can be displayed in the selected language.
