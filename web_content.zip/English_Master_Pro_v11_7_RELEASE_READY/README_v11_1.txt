English Master Pro v11.1

Production-oriented upgrade of v11.
- Real server-side AI integration; default model: gpt-5.6-luna.
- Email/password + Google OAuth.
- Cloud progress and AI history sync.
- Stripe monthly/yearly subscription checkout + lifecycle webhook handling.
- Web Push VAPID public-key flow fixed in the client.
- Android native starter with WebView, microphone permission, AdMob SDK and Google Play Billing dependency.
- Secrets remain server-side and are never bundled in app.js or the APK.

Important: replace credentials/placeholders with accounts you own and complete server-side purchase verification before publishing.
