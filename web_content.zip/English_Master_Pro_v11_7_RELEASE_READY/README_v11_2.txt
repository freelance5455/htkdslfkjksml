English Master Pro v11.2

This release completes the requested production-oriented architecture:

1. Email/password accounts + Google OAuth
2. PostgreSQL production database schema; JSON is retained only as a development fallback when DATABASE_URL is absent
3. Server-side AI with enforced daily limits (Free/Premium)
4. Free/Premium plan and Stripe monthly/yearly subscriptions with webhook lifecycle
5. Google Play Billing Android starter + secure backend purchase-token verification and acknowledgement
6. AdMob Android SDK with official test IDs; replace test IDs with your own before release
7. Web Push subscriptions
8. Leaderboard and minimal analytics events
9. Cloud progress, vocabulary/learning state and AI history sync
10. Subscription status endpoint, restore/query flow and expiry fields
11. Security hardening: rate limit, JWT, server-only secrets, input limits, purchase-token uniqueness
12. Landing page, Privacy Policy, Terms, FAQ and release/testing checklist
13. Android WebView + microphone permission

IMPORTANT:
- No real provider secret or payment credential is included.
- AdMob uses Google's official TEST IDs until you replace them.
- Production requires HTTPS, PostgreSQL, secret management, Play Console products/service account, Google OAuth configuration, Stripe configuration, VAPID keys and an OpenAI API key on the server.
- Google Play Premium entitlement is granted only after backend verification of the purchase token.
