English Master Pro v11.6

New: 7-Day Study Reward. Complete all 3 daily study sessions for 7 consecutive good-study days to unlock the existing AI Tutor ability.

Good Study Day = morning + afternoon + evening sessions completed.
Progress is shown on the home page as 0/7 to 7/7.

Android versionCode: 116
Android versionName: 11.6.0
