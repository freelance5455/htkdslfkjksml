English Master Pro v11

V10 upgrade includes:
- Adaptive Smart Academy with daily personalized plan
- CEFR-style level progression (A1-C1) based on XP
- Weak-skill targeting
- Smart vocabulary review
- Error Notebook
- Real-life role-play scenarios
- Writing Lab with offline grammar feedback
- Existing v8/v9 offline, microphone fallback, 3x daily study, ads-ready, PWA and backup features retained
- Version labels updated to v10

Ads: configure your own AdSense publisher/slot for web ads. Native AdMob still requires Android SDK integration in the wrapper app.
