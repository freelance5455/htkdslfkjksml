English Master Pro v11.1

Major upgrade from v10:
- Account system: email/password + Google OAuth backend integration
- Cloud progress sync and multi-device restore
- Secure real AI backend route (AI API key stays on server)
- Writing correction, grammar teaching, conversation, exercise generation and personalized tutoring through the real AI route
- Speaking evaluation UI with Pronunciation / Grammar / Vocabulary scores
- Free and Premium plan UI with monthly/yearly checkout integration
- Server-side subscription entitlement path
- Web Push notification integration and three daily study reminders
- XP, coins, badges, streak rewards, daily/weekly challenge UI and leaderboard
- Expanded A1–C1 content architecture ready for more lessons
- Backend folder with authentication, progress, AI, Google OAuth, Stripe, notifications and leaderboard endpoints
- Android integration checklist for native AdMob and Google Play Billing
- Offline fallback remains available when the backend is not connected

IMPORTANT:
The ZIP contains integration code, not your private production credentials. To make Google login, real AI, Stripe payments, Web Push, AdMob and Play Billing live, configure your own provider credentials and Android project settings. Never place secret keys in app.js or inside the APK.
