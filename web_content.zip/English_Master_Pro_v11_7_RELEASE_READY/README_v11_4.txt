English Master Pro v11.6

This release keeps the v11.3 multilingual/first-launch language features and upgrades the Android project for Google Play release preparation.

Android:
- versionName 11.4.0
- versionCode 114
- separate debug/release configurations
- Release R8/minification and resource shrinking
- external release signing; no private keystore in the ZIP
- AdMob official TEST IDs clearly marked for replacement before release
- safer WebViewAssetLoader setup
- microphone permission and WebView audio permission handling
- cleartext traffic disabled and Android backup disabled
- Billing/backend release checklist

The project is configured to build a signed APK/AAB on a trusted machine after the owner's real keystore, production AdMob IDs and HTTPS backend are supplied.
