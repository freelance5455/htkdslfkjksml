English Master Pro v9
======================
New in v9:
- v9 branding throughout the app (no v1 branding).
- Ad-ready banner for web/HTML. To use Google AdSense, put YOUR publisher client and slot in EMP_V9 in app.js.
- Android WebView note: real AdMob requires the native Android AdMob SDK and an AdMob ad unit ID; HTML alone cannot provide native AdMob.
- Focus timer (25 minutes) with +10 XP after completion.
- Export/restore progress JSON backup.
- Share progress using the device share sheet when supported.
- PWA install button / Add to Home Screen support.
- Improved v9 offline/service-worker cache name.
- Existing microphone en-US, WebView bridge, offline speech fallback, offline AI tutor, vocabulary, tests, achievements and footer are retained.
- Constructor footer retained: constructor:- hezbullah kashmiri

AdSense setup:
1. Get your own AdSense publisher client ID and ad slot from Google.
2. Open app.js and set EMP_V9.adSenseClient and EMP_V9.adSlot.
3. Do not use someone else's ad IDs.

For Google Play/Android:
For actual AdMob revenue in an APK, integrate the Google Mobile Ads SDK in the Android host project and use your own AdMob App ID + Ad Unit ID. The web ZIP cannot securely create a native AdMob SDK integration by itself.
