# UBAIS Certificate System — Android Fixed File Handling

This project packages the existing UBAIS Certificate System HTML app in an Android WebView.

## File handling fixes in this revision
- HTML `<input type="file">` uses Android Storage Access Framework (`ACTION_OPEN_DOCUMENT`) rather than WebView's default picker intent.
- Image, CSV, JSON and generic file inputs are supported through the native picker.
- Multiple-file selection is preserved when requested by the HTML input.
- Backup Restore uses `ACTION_OPEN_DOCUMENT` with broad MIME matching so Android file managers do not hide JSON backups saved with generic MIME types.
- Persistable read permission is requested when the selected provider supports it.
- Existing native backup Save flow remains in place and uses `ACTION_CREATE_DOCUMENT`.
- Existing IndexedDB/database, certificate design, QR payload, collection system and offline HTML application are preserved.

## Build
Open this folder in Android Studio and let Android Studio install/sync the required Android SDK and Gradle components. Then use Build > Build APK(s).

The environment used to prepare this source project does not contain the Android SDK/Gradle executable, so an APK was not compiled here.


## v3 correction
This version explicitly supports both Android Storage Access Framework (ACTION_OPEN_DOCUMENT) and ACTION_GET_CONTENT as a vendor-ROM fallback for HTML file uploads and backup restore. Multiple selected URIs receive read permissions where supported.
