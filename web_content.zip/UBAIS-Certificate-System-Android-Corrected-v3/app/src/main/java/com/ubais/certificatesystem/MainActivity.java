package com.ubais.certificatesystem;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 4201;
    private static final int FILE_CHOOSER_FALLBACK_REQUEST = 4204;
    private static final int BACKUP_SAVE_REQUEST = 4202;
    private static final int BACKUP_RESTORE_REQUEST = 4203;
    private final StringBuilder pendingBackupJson = new StringBuilder();
    private String pendingBackupFileName = "ubais_backup.json";
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 107, 58));

        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        webView.loadUrl("file:///android_asset/ubais-certificate-system.html");
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadsImagesAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setTextZoom(100);

        CookieManager.getInstance().setAcceptCookie(true);
        webView.setBackgroundColor(Color.WHITE);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidPrint");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) { }
                    return true;
                }
                return false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Route the HTML app's window.print() into Android's native print pipeline.
                view.evaluateJavascript(
                    "(function(){" +
                    "if(window.__ubaisNativePrintInstalled)return;" +
                    "window.__ubaisNativePrintInstalled=true;" +
                    "window.print=function(){AndroidPrint.print();};" +
                    "window.__ubaisAndroidRestoreChunks=[];" +
                    "window.__ubaisAndroidRestoreStart=function(){window.__ubaisAndroidRestoreChunks=[];};" +
                    "window.__ubaisAndroidRestoreChunk=function(c){window.__ubaisAndroidRestoreChunks.push(c);};" +
                    "window.__ubaisAndroidRestoreFinish=function(){if(window.__ubaisHandleNativeRestore){window.__ubaisHandleNativeRestore(window.__ubaisAndroidRestoreChunks.join(''));}};" +
                    "})();", null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                // Do not rely on WebView's default GET_CONTENT intent. Some Android
                // file managers return no usable URI for HTML <input type=file>.
                // Use the Storage Access Framework explicitly instead.
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

                String[] accepts = params.getAcceptTypes();
                java.util.ArrayList<String> mimeTypes = new java.util.ArrayList<>();
                if (accepts != null) {
                    for (String raw : accepts) {
                        if (raw == null) continue;
                        for (String part : raw.split(",")) {
                            String a = part.trim().toLowerCase(java.util.Locale.US);
                            if (a.isEmpty()) continue;
                            if (a.startsWith(".")) {
                                if (a.equals(".json")) mimeTypes.add("application/json");
                                else if (a.equals(".csv")) mimeTypes.add("text/csv");
                                else if (a.equals(".jpg") || a.equals(".jpeg")) mimeTypes.add("image/jpeg");
                                else if (a.equals(".png")) mimeTypes.add("image/png");
                            } else {
                                mimeTypes.add(a);
                            }
                        }
                    }
                }
                if (mimeTypes.isEmpty()) mimeTypes.add("*/*");
                // Remove duplicates while preserving order.
                java.util.LinkedHashSet<String> unique = new java.util.LinkedHashSet<>(mimeTypes);
                if (unique.size() == 1) {
                    intent.setType(unique.iterator().next());
                } else {
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, unique.toArray(new String[0]));
                }
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);

                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    // Some vendor ROMs do not expose ACTION_OPEN_DOCUMENT.
                    // Fall back to the broader ACTION_GET_CONTENT picker.
                    Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                    fallback.addCategory(Intent.CATEGORY_OPENABLE);
                    fallback.setType(intent.getType());
                    String[] extraTypes = intent.getStringArrayExtra(Intent.EXTRA_MIME_TYPES);
                    if (extraTypes != null) fallback.putExtra(Intent.EXTRA_MIME_TYPES, extraTypes);
                    fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    try {
                        startActivityForResult(fallback, FILE_CHOOSER_FALLBACK_REQUEST);
                    } catch (ActivityNotFoundException e2) {
                        filePathCallback = null;
                        Toast.makeText(MainActivity.this, "No file picker is available on this device.", Toast.LENGTH_LONG).show();
                        return false;
                    }
                }
                return true;
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.setTitle("UBAIS Certificate System export");
                request.setDescription("Downloading exported data");
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, guessFileName(contentDisposition, mimeType));
                DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
                if (dm != null) dm.enqueue(request);
            } catch (Exception e) {
                Toast.makeText(this, "Download could not be started.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String guessFileName(String contentDisposition, String mimeType) {
        if (contentDisposition != null) {
            String marker = "filename=";
            int i = contentDisposition.indexOf(marker);
            if (i >= 0) {
                String name = contentDisposition.substring(i + marker.length()).replace("\"", "").trim();
                if (!name.isEmpty()) return name;
            }
        }
        return "ubais-export" + (mimeType != null && mimeType.contains("json") ? ".json" : ".csv");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void print() {
            runOnUiThread(() -> printWebView());
        }

        @JavascriptInterface
        public void beginBackup(String fileName) {
            pendingBackupJson.setLength(0);
            pendingBackupFileName = safeFileName(fileName);
        }

        @JavascriptInterface
        public void appendBackupChunk(String chunk) {
            if (chunk != null) pendingBackupJson.append(chunk);
        }

        @JavascriptInterface
        public void finishBackup() {
            runOnUiThread(() -> {
                if (pendingBackupJson.length() == 0) {
                    Toast.makeText(MainActivity.this, "Backup data is empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupFileName);
                try { startActivityForResult(intent, BACKUP_SAVE_REQUEST); }
                catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "No file-saving app is available.", Toast.LENGTH_LONG).show();
                    pendingBackupJson.setLength(0);
                }
            });
        }

        @JavascriptInterface
        public void restoreBackup() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // Use * / * as the primary type so Android file managers do not hide
                // JSON backups stored with a generic MIME type. The MIME list remains
                // as a hint, while the HTML layer performs strict JSON validation.
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "application/octet-stream"});
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try { startActivityForResult(intent, BACKUP_RESTORE_REQUEST); }
                catch (ActivityNotFoundException e) {
                    Intent fallback = new Intent(Intent.ACTION_GET_CONTENT);
                    fallback.addCategory(Intent.CATEGORY_OPENABLE);
                    fallback.setType("*/*");
                    fallback.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "application/octet-stream"});
                    try { startActivityForResult(fallback, BACKUP_RESTORE_REQUEST); }
                    catch (ActivityNotFoundException e2) { Toast.makeText(MainActivity.this, "No file picker is available.", Toast.LENGTH_LONG).show(); }
                }
            });
        }
    }

    private void printWebView() {
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) {
            Toast.makeText(this, "Android printing is not available on this device.", Toast.LENGTH_LONG).show();
            return;
        }
        String jobName = "UBAIS Certificate System";
        PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
        PrintAttributes attributes = new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("ubais", "UBAIS", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build();
        printManager.print(jobName, adapter, attributes);
    }

    private String safeFileName(String name) {
        if (name == null || name.trim().isEmpty()) return "ubais_backup.json";
        String cleaned = name.replaceAll("[^a-zA-Z0-9._-]", "_");
        return cleaned.toLowerCase().endsWith(".json") ? cleaned : cleaned + ".json";
    }

    private void saveBackupToUri(Uri uri) {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Unable to open destination");
            byte[] bytes = pendingBackupJson.toString().getBytes(StandardCharsets.UTF_8);
            out.write(bytes);
            out.flush();
            pendingBackupJson.setLength(0);
            Toast.makeText(this, "Backup saved successfully.", Toast.LENGTH_LONG).show();
            webView.evaluateJavascript("window.__ubaisNativeBackupSaved && window.__ubaisNativeBackupSaved(true);", null);
        } catch (Exception e) {
            Toast.makeText(this, "Backup could not be saved: " + e.getMessage(), Toast.LENGTH_LONG).show();
            webView.evaluateJavascript("window.__ubaisNativeBackupSaved && window.__ubaisNativeBackupSaved(false);", null);
        }
    }

    private void readRestoreFromUri(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("Unable to open backup file");
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            String text = out.toString("UTF-8");
            webView.evaluateJavascript("window.__ubaisAndroidRestoreStart && window.__ubaisAndroidRestoreStart();", null);
            final int chunkSize = 24000;
            for (int i = 0; i < text.length(); i += chunkSize) {
                String chunk = text.substring(i, Math.min(text.length(), i + chunkSize));
                String quoted = org.json.JSONObject.quote(chunk);
                webView.evaluateJavascript("window.__ubaisAndroidRestoreChunk && window.__ubaisAndroidRestoreChunk(" + quoted + ");", null);
            }
            webView.evaluateJavascript("window.__ubaisAndroidRestoreFinish && window.__ubaisAndroidRestoreFinish();", null);
        } catch (Exception e) {
            Toast.makeText(this, "Backup could not be read: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_SAVE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) saveBackupToUri(data.getData());
            else {
                pendingBackupJson.setLength(0);
                webView.evaluateJavascript("window.__ubaisNativeBackupSaved && window.__ubaisNativeBackupSaved(false);", null);
            }
            return;
        }
        if (requestCode == BACKUP_RESTORE_REQUEST) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri uri = data.getData();
                try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                readRestoreFromUri(uri);
            } else {
                Toast.makeText(this, "Restore cancelled.", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST || requestCode == FILE_CHOOSER_FALLBACK_REQUEST) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        Uri uri = data.getClipData().getItemAt(i).getUri();
                        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                        results[i] = uri;
                    }
                } else if (data.getData() != null) {
                    Uri uri = data.getData();
                    try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                    results = new Uri[]{uri};
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidPrint");
            webView.destroy();
        }
        super.onDestroy();
    }
}
