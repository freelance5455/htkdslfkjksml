نسخه V6 - رفع خطای UColor
خطای تصویر: UColor is not defined
علت: رنگ‌ها در شیدر اضافه شده بودند اما محل دریافت uniform در JavaScript تعریف نشده بود.
این نسخه UColor را قبل از draw تعریف کرده و در نسخه Web و Android یکسان اصلاح شده است.
