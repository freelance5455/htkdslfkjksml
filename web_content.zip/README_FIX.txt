إصلاح مشكلة فتح Telegram في تطبيق X Gaming

المشكلة:
كان التطبيق يرسل رابط tg://resolve مباشرة بطريقة يمكن أن تصل إلى WebView/المتصفح كرابط ويب، فتظهر صفحة "صفحة الويب غير متاحة" مع ERR_HTTP_RESPONSE_CODE_FAILURE.

الإصلاح:
- اعتراض روابط tg:// بعد فك ترميزها.
- فتح Telegram عبر Intent مباشر.
- دعم الحزمة الرسمية org.telegram.messenger وTelegram X org.thunderdog.challegram.
- استخدام https://t.me/XGamesMods كخطة بديلة.
- اعتراض روابط t.me داخل WebView حتى لا يتم تحميلها كصفحة داخل التطبيق.

ملفات التعديل الأساسية:
assets/web/app/src/main/java/com/xgaming/app/MainActivity.kt

المشروع الأصلي كان يحتوي على ملفات المصدر داخل الـ APK، لذلك تم استخراجها والحفاظ عليها داخل هذا المشروع.

البناء:
1) افتح مجلد assets/web كمشروع Android Gradle.
2) استخدم Android Studio أو Gradle 8.10+.
3) نفّذ assembleDebug أو assembleRelease.
