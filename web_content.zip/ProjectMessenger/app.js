(() => {
  const $ = id => document.getElementById(id);
  const show = id => $(id).classList.remove('hidden');
  const hide = id => $(id).classList.add('hidden');
  const status = (id, text) => { $(id).textContent = text || ''; };
  let auth, db, storage, user = null, userProfile = {}, chats = [], activeChat = null;
  let chatsUnsub = null, messagesUnsub = null, mediaRecorder = null, audioChunks = [], recording = false;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const initials = s => (s || 'PM').trim().slice(0,2).toUpperCase();
  function toast(msg) { $('toast').textContent = msg; show('toast'); setTimeout(() => hide('toast'), 3000); }
  function configured() { return window.PM_CONFIG && window.PM_CONFIG.firebaseConfig && !window.PM_CONFIG.firebaseConfig.apiKey.includes('PASTE_'); }
  function initFirebase() {
    if (!configured()) { status('authStatus', 'Сначала настрой config.js по инструкции в README.md.'); return false; }
    try { firebase.initializeApp(window.PM_CONFIG.firebaseConfig); auth = firebase.auth(); db = firebase.firestore(); storage = firebase.storage(); return true; }
    catch (e) { status('authStatus', 'Ошибка настройки Firebase: ' + e.message); return false; }
  }
  $('loginBtn').onclick = async () => {
    if (!auth && !initFirebase()) return;
    try { await auth.signInWithEmailAndPassword($('email').value.trim(), $('password').value); status('authStatus',''); }
    catch(e) { status('authStatus', humanError(e)); }
  };
  $('registerBtn').onclick = async () => {
    if (!auth && !initFirebase()) return;
    const email = $('email').value.trim(), password = $('password').value;
    if (password.length < 6) return status('authStatus','Пароль должен быть не короче 6 символов.');
    try {
      const cred = await auth.createUserWithEmailAndPassword(email, password);
      await db.collection('users').doc(cred.user.uid).set({uid:cred.user.uid,email:email.toLowerCase(),name:email.split('@')[0],avatarUrl:'',createdAt:firebase.firestore.FieldValue.serverTimestamp()});
      status('authStatus','Аккаунт создан!');
    } catch(e) { status('authStatus',humanError(e)); }
  };
  $('logoutBtn').onclick = () => auth && auth.signOut();
  function humanError(e) {
    const map = {'auth/invalid-email':'Проверь email.','auth/user-not-found':'Аккаунт не найден. Зарегистрируйся.','auth/wrong-password':'Неверный пароль.','auth/invalid-credential':'Неверный email или пароль.','auth/email-already-in-use':'Этот email уже зарегистрирован.','auth/weak-password':'Сделай пароль длиннее (минимум 6 символов).','auth/operation-not-allowed':'В Firebase включи способ входа Email/Password.','permission-denied':'Доступ запрещён. Проверь правила Firestore/Storage.','auth/network-request-failed':'Нет соединения с интернетом.'};
    return map[e.code] || e.message || 'Что-то пошло не так.';
  }
  if (initFirebase()) auth.onAuthStateChanged(async u => {
    user = u;
    if (!u) { if(chatsUnsub) chatsUnsub(); if(messagesUnsub) messagesUnsub(); hide('appView'); show('authView'); hide('logoutBtn'); return; }
    show('appView'); hide('authView'); show('logoutBtn');
    try {
      const ref = db.collection('users').doc(u.uid); let snap = await ref.get();
      if (!snap.exists) { userProfile = {uid:u.uid,email:u.email,name:(u.email||'user').split('@')[0],avatarUrl:''}; await ref.set({...userProfile,createdAt:firebase.firestore.FieldValue.serverTimestamp()}); }
      else userProfile = snap.data();
      renderProfile();
      if (u.uid === window.PM_CONFIG.ADMIN_UID && !window.PM_CONFIG.ADMIN_UID.includes('PASTE_')) show('adminBtn'); else hide('adminBtn');
      subscribeChats();
    } catch(e) { toast(humanError(e)); }
  });
  function renderProfile() { $('myName').textContent=userProfile.name||'Пользователь'; $('myEmail').textContent=user.email||''; $('myAvatar').src=userProfile.avatarUrl||avatarData(userProfile.name||user.email); }
  function avatarData(text) { const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="96" height="96" rx="48" fill="#173b66"/><text x="48" y="58" text-anchor="middle" font-size="34" font-family="Arial" font-weight="bold" fill="#8ed6ff">${initials(text)}</text></svg>`; return 'data:image/svg+xml;charset=utf-8,'+encodeURIComponent(svg); }
  $('profileBtn').onclick=()=>{ $('profileName').value=userProfile.name||''; $('profileAvatar').value=userProfile.avatarUrl||''; status('profileStatus',''); show('profileModal'); };
  $('saveProfileBtn').onclick=async()=>{ const name=$('profileName').value.trim(); const avatarUrl=$('profileAvatar').value.trim(); if(!name)return status('profileStatus','Укажи имя.'); if(avatarUrl && !/^https:\/\//i.test(avatarUrl))return status('profileStatus','Ссылка на аватар должна начинаться с https://'); try{await db.collection('users').doc(user.uid).update({name,avatarUrl}); userProfile={...userProfile,name,avatarUrl};renderProfile();hide('profileModal');toast('Профиль сохранён');}catch(e){status('profileStatus',humanError(e));} };
  function subscribeChats() {
    if(chatsUnsub)chatsUnsub();
    chatsUnsub=db.collection('chats').where('members','array-contains',user.uid).onSnapshot(snap=>{chats=snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>(b.updatedAt?.toMillis?.()||0)-(a.updatedAt?.toMillis?.()||0));renderChats();},e=>toast(humanError(e)));
  }
  function renderChats() { const q=$('chatSearch').value.toLowerCase(); const filtered=chats.filter(c=>(c.name||'').toLowerCase().includes(q)||(c.memberEmails||[]).join(' ').toLowerCase().includes(q)); $('chatList').innerHTML=filtered.length?'':'<p class="muted tiny">Чаты не найдены.</p>'; filtered.forEach(c=>{const b=document.createElement('button');b.className='chat-item'+(activeChat?.id===c.id?' active':'');b.innerHTML=`<span class="chat-symbol">${c.type==='channel'?'#':c.type==='group'?'👥':'✦'}</span><span class="chat-label"><b>${esc(c.name||'Личный чат')}</b><small>${esc(c.type==='channel'?'Канал':c.type==='group'?'Группа':'Личная переписка')}</small></span>`;b.onclick=()=>openChat(c);$('chatList').appendChild(b);}); }
  $('chatSearch').oninput=renderChats;
  $('newChatBtn').onclick=()=>{hide('groupFields');show('directFields');$('createTitle').textContent='Новый личный чат';$('targetEmail').value='';status('createStatus','');show('createModal');};
  $('newGroupBtn').onclick=()=>{show('groupFields');hide('directFields');$('createTitle').textContent='Новая группа или канал';$('groupName').value='';$('groupMembers').value='';status('createStatus','');show('createModal');};
  $('createBtn').onclick=async()=>{
    status('createStatus','Создаю…');
    try {
      if(!$('directFields').classList.contains('hidden')) {
        const email=$('targetEmail').value.trim().toLowerCase(); if(!email||email===user.email.toLowerCase())return status('createStatus','Укажи email другого пользователя.');
        const found=await db.collection('users').where('email','==',email).limit(1).get(); if(found.empty)return status('createStatus','Пользователь не найден. Он должен сначала зарегистрироваться.');
        const other=found.docs[0].data(); const members=[user.uid,other.uid].sort(); const existing=chats.find(c=>c.type==='direct'&&members.every(m=>c.members.includes(m))&&c.members.length===2); if(existing){hide('createModal');return openChat(existing);}
        const doc=await db.collection('chats').add({type:'direct',name:other.name||email,createdBy:user.uid,members,memberEmails:[user.email.toLowerCase(),email],createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()}); hide('createModal'); toast('Личный чат создан');
      } else {
        const name=$('groupName').value.trim();if(!name)return status('createStatus','Укажи название.'); const type=$('groupType').value; let members=[user.uid];
        const emails=$('groupMembers').value.split(',').map(x=>x.trim().toLowerCase()).filter(Boolean); for(const email of emails){const found=await db.collection('users').where('email','==',email).limit(1).get();if(!found.empty)members.push(found.docs[0].id);} members=[...new Set(members)];
        const memberEmails=[user.email.toLowerCase(),...emails]; const doc=await db.collection('chats').add({type,name,createdBy:user.uid,members,memberEmails,createdAt:firebase.firestore.FieldValue.serverTimestamp(),updatedAt:firebase.firestore.FieldValue.serverTimestamp()}); hide('createModal');toast(type==='channel'?'Канал создан':'Группа создана');
      }
    } catch(e){status('createStatus',humanError(e));}
  };
  async function openChat(chat) { activeChat=chat; renderChats(); show('chatView');hide('emptyChat');$('activeChatName').textContent=chat.name||'Чат';$('activeChatMeta').textContent=(chat.type==='channel'?'Канал':chat.type==='group'?'Группа':'Личный чат')+' · '+(chat.members?.length||1)+' участн.'; $('messages').innerHTML=''; if(messagesUnsub)messagesUnsub(); messagesUnsub=db.collection('chats').doc(chat.id).collection('messages').orderBy('createdAt','asc').limit(150).onSnapshot(snap=>{const box=$('messages');box.innerHTML='';snap.forEach(d=>{const m=d.data();const el=document.createElement('div');el.className='message'+(m.senderId===user.uid?' mine':'');const sender=m.senderName||'Пользователь';let body=m.audioUrl?`<audio controls preload="none" src="${esc(m.audioUrl)}"></audio>`:esc(m.text||'');el.innerHTML=`${m.senderId===user.uid?'':`<span class="sender">${esc(sender)}</span>`}${body}<time>${m.createdAt?.toDate?m.createdAt.toDate().toLocaleTimeString('ru-RU',{hour:'2-digit',minute:'2-digit'}):'сейчас'}</time>`;box.appendChild(el);});box.scrollTop=box.scrollHeight;},e=>toast(humanError(e))); }
  $('messageForm').onsubmit=async e=>{e.preventDefault();const text=$('messageInput').value.trim();if(!text||!activeChat)return; $('messageInput').value='';try{await db.collection('chats').doc(activeChat.id).collection('messages').add({text,senderId:user.uid,senderName:userProfile.name||user.email,createdAt:firebase.firestore.FieldValue.serverTimestamp()});await db.collection('chats').doc(activeChat.id).update({updatedAt:firebase.firestore.FieldValue.serverTimestamp()});}catch(err){toast(humanError(err));$('messageInput').value=text;}};
  $('membersBtn').onclick=()=>{if(!activeChat)return;$('infoTitle').textContent=activeChat.name||'Участники';$('infoContent').innerHTML=`<p>Тип: ${esc(activeChat.type)}</p><p>Участников: ${activeChat.members.length}</p><p class="tiny">UID участников: ${activeChat.members.map(esc).join('<br>')}</p>`;show('infoModal');};
  $('voiceBtn').onclick=async()=>{
    if(!activeChat)return toast('Сначала открой чат.');
    if(recording&&mediaRecorder){mediaRecorder.stop();return;}
    if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder)return toast('Запись аудио не поддерживается этим браузером.');
    try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});audioChunks=[];mediaRecorder=new MediaRecorder(stream);mediaRecorder.ondataavailable=e=>{if(e.data.size)audioChunks.push(e.data);};mediaRecorder.onstop=async()=>{recording=false;stream.getTracks().forEach(t=>t.stop());$('voiceBtn').textContent='🎙';status('recordingStatus','Отправляю голосовое…');try{const blob=new Blob(audioChunks,{type:mediaRecorder.mimeType||'audio/webm'});if(blob.size>10*1024*1024)throw new Error('Запись больше 10 МБ. Запиши короче.');const ext=blob.type.includes('mp4')?'m4a':'webm';const path=`voice/${activeChat.id}/${user.uid}_${Date.now()}.${ext}`;const snap=await storage.ref(path).put(blob,{contentType:blob.type});const url=await snap.ref.getDownloadURL();await db.collection('chats').doc(activeChat.id).collection('messages').add({text:'',audioUrl:url,senderId:user.uid,senderName:userProfile.name||user.email,createdAt:firebase.firestore.FieldValue.serverTimestamp()});await db.collection('chats').doc(activeChat.id).update({updatedAt:firebase.firestore.FieldValue.serverTimestamp()});status('recordingStatus','');}catch(e){status('recordingStatus',humanError(e));} };mediaRecorder.start();recording=true;$('voiceBtn').textContent='■';status('recordingStatus','Идёт запись… нажми ■, чтобы отправить.');}catch(e){toast('Разреши доступ к микрофону в браузере.');}
  };
  $('adminBtn').onclick=async()=>{show('adminModal');$('adminStats').innerHTML='<div class="stat"><b>…</b><small>Пользователи</small></div><div class="stat"><b>…</b><small>Чаты</small></div>';try{const [u,c]=await Promise.all([db.collection('users').get(),db.collection('chats').get()]);$('adminStats').innerHTML=`<div class="stat"><b>${u.size}</b><small>Пользователи</small></div><div class="stat"><b>${c.size}</b><small>Чаты / группы / каналы</small></div>`;}catch(e){toast(humanError(e));}};
  $('adminLookupBtn').onclick=async()=>{const email=$('adminEmail').value.trim().toLowerCase();if(!email)return status('adminResult','Введи email.');try{const s=await db.collection('users').where('email','==',email).limit(1).get();status('adminResult',s.empty?'Пользователь не найден.':`Найден: ${s.docs[0].data().name||email} · UID: ${s.docs[0].id}`);}catch(e){status('adminResult',humanError(e));}};
  document.querySelectorAll('[data-close]').forEach(b=>b.onclick=()=>hide(b.dataset.close));document.querySelectorAll('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)hide(m.id);}));
  if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();
