/* 1) Создай проект в Firebase Console. 2) Вставь данные Web App в firebaseConfig.
   3) После первой регистрации скопируй UID владельца и вставь в ADMIN_UID.
   Это не пароль; настоящая защита дополнительно задаётся правилами Firestore/Storage. */
window.PM_CONFIG = {
  firebaseConfig: {
    apiKey: "PASTE_API_KEY_HERE",
    authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
    projectId: "PASTE_PROJECT_ID",
    storageBucket: "PASTE_PROJECT_ID.appspot.com",
    messagingSenderId: "PASTE_SENDER_ID",
    appId: "PASTE_APP_ID"
  },
  ADMIN_UID: "PASTE_YOUR_FIREBASE_AUTH_UID_HERE"
};
