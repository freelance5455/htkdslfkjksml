package br.com.radiolivre

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.content.Context
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.FrameLayout
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var banner: AdView
    private var interstitial: InterstitialAd? = null
    private var sectionChanges = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MobileAds.initialize(this) {}
        loadInterstitial()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(9, 14, 27))
        }
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(AdBridge(), "RadioLivreAds")
        }
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        banner = AdView(this).apply {
            adUnitId = "ca-app-pub-3940256099942544/9214589741" // Banner de teste do Google
            setAdSize(AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this@MainActivity, 360))
        }
        root.addView(banner, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        banner.loadAd(AdRequest.Builder().build())
        webView.loadUrl("file:///android_asset/index.html")
    }

    private fun loadInterstitial() {
        InterstitialAd.load(
            this,
            "ca-app-pub-3940256099942544/1033173712", // Intersticial de teste do Google
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
                override fun onAdFailedToLoad(error: LoadAdError) { interstitial = null }
            }
        )
    }

    private inner class AdBridge {
        @JavascriptInterface
        fun copyPixKey() {
            runOnUiThread {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Chave Pix Rádio Livre", "meajudecomumvalor@gmail.com"))
            }
        }

        @JavascriptInterface
        fun requestPremium() {
            runOnUiThread {
                val uri = Uri.parse("mailto:meajudecomumvalor@gmail.com?subject=Pedido%20Premium%20Radio%20Livre&body=Quero%20assinar%20o%20Premium%20de%20R%24%202%2Fmes.%20Vou%20enviar%20o%20comprovante%20Pix.")
                try { startActivity(Intent(Intent.ACTION_SENDTO, uri)) } catch (_: Exception) { }
            }
        }

        @JavascriptInterface
        fun openChatGPT() {
            runOnUiThread {
                val uri = Uri.parse("https://play.google.com/store/apps/details?id=com.openai.chatgpt")
                try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { }
            }
        }

        @JavascriptInterface
        fun sectionChanged() {
            runOnUiThread {
                sectionChanges++
                // Mostrar apenas após várias trocas de seção, em uma pausa natural; nunca durante cada clique.
                if (sectionChanges >= 5) {
                    sectionChanges = 0
                    val ad = interstitial
                    if (ad != null) {
                        ad.show(this@MainActivity)
                        interstitial = null
                        loadInterstitial()
                    }
                }
            }
        }
    }

    override fun onPause() {
        if (::banner.isInitialized) banner.pause()
        if (::webView.isInitialized) webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::banner.isInitialized) banner.resume()
        if (::webView.isInitialized) webView.onResume()
    }

    override fun onDestroy() {
        if (::banner.isInitialized) banner.destroy()
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
