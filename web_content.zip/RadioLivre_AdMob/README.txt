RÁDIO LIVRE — PROJETO ANDROID COM ADMOB (ANÚNCIOS DE TESTE)

O que contém:
- O site Rádio Livre dentro de um WebView Android.
- Banner fixo na parte inferior usando o ID oficial de teste do Google.
- Anúncio intersticial de teste depois de cinco trocas de seção, em pausa de navegação; não é disparado ao tocar/selecionar uma rádio.

COMO ABRIR
1. Extraia o ZIP.
2. Abra a pasta RadioLivre_AdMob no Android Studio (Open).
3. Aguarde o Gradle Sync e instale no dispositivo/emulador.
4. Durante o desenvolvimento, use apenas os IDs de teste que já estão configurados.

ANTES DE PUBLICAR / MONETIZAR
- Este projeto usa IDs de demonstração do Google. Eles servem para testar e NÃO geram receita.
- Para anúncios reais, o responsável pela publicação precisa registrar o app na conta AdMob, criar um App ID e IDs separados para banner e intersticial e substituir os valores em AndroidManifest.xml e MainActivity.kt.
- Não clique repetidamente em anúncios reais para testar. Use IDs de teste durante desenvolvimento.
- Configure consentimento/privacidade e as divulgações exigidas para o público e países onde o app será distribuído. Se você for menor de idade, peça a um responsável para cuidar da conta e da publicação.

IDs oficiais de teste usados:
App ID: ca-app-pub-3940256099942544~9257395921
Banner: ca-app-pub-3940256099942544/9214589741
Intersticial: ca-app-pub-3940256099942544/1033173712

A integração precisa ser compilada e testada no Android Studio. Este arquivo ZIP contém o projeto-fonte; não é um APK pronto.

Divulgacao do ChatGPT:
- O app inclui um banner promocional e uma tela promocional em tela cheia após algumas trocas de seção.
- Os botões abrem a página do aplicativo ChatGPT na Google Play.
- É uma divulgação dentro do Rádio Livre, não uma campanha oficial/paga da OpenAI; não implica parceria ou patrocínio.
- Os anúncios do AdMob continuam usando IDs de teste até serem substituídos por IDs reais da conta do responsável.
