VR BOX WORLD — PACOTE INICIAL

Este ZIP contém o protótipo web e os arquivos iniciais para começar a empacotá-lo como app Android com Capacitor.

IMPORTANTE
- Este pacote ainda NÃO é um APK.
- A câmera no app Android precisa de permissões nativas e tratamento da permissão da WebView. A interface HTML atual apenas tenta acessar a câmera pelo navegador.
- O rastreamento real das mãos ainda não foi integrado.
- Para gerar APK, é necessário configurar um ambiente de build na nuvem que aceite projetos Node/Gradle, ou usar um fluxo CI como GitHub Actions.
- Não coloque senhas, tokens ou chaves privadas dentro do ZIP ou do repositório.

PRÓXIMA ETAPA
1. Envie o conteúdo deste ZIP para um repositório Git.
2. Configure um workflow de compilação Android na nuvem.
3. Gere um APK de teste.
4. Instale e teste no seu próprio celular.
5. Depois adicionamos a permissão de câmera Android corretamente e integramos o rastreamento das mãos.

Documentação oficial do Capacitor:
https://capacitorjs.com/docs
