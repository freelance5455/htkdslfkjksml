# MUGENN AI Bubble (Android 16)

Starter project: a draggable Android overlay bubble and a simple web demo. The question response is a local placeholder; it is NOT connected to a real AI service yet.

## Build APK using only your phone
1. Sign in to GitHub in Chrome and create a new **public or private** repository named `MUGENN-AI-Bubble`.
2. Upload the *contents* of this folder to the repository root (including `.github/workflows/build-apk.yml`). GitHub mobile upload may require selecting files individually or using the browser's desktop-site option.
3. Open the repository's **Actions** tab and select **Build MUGENN AI Bubble APK**.
4. Tap **Run workflow** (or wait for the first push workflow), then open the completed run.
5. Download the artifact `MUGENN-AI-Bubble-debug-apk` and extract it; the file inside is `app-debug.apk`.
6. Install it on your Android device. If Android asks, allow installation from the browser/file manager you used.
7. Open MUGENN AI Bubble, tap **IZINKAN PANEL MENGAMBANG**, enable **Display over other apps**, return to the app, and tap **MULAI GELEMBUNG**.

## Notes
- The bubble can be dragged and tapped. Tap it to open/close the demo panel.
- The web demo is `website/index.html`; open it in Chrome.
- This is a starter/demo, not a finished AI assistant. The AI button shows a placeholder until a secure backend is connected. Never put private AI API keys in an Android app or public repository.
- Use the overlay transparently and only where allowed. It does not read other apps' screens or bypass app protections.
