// Atajo para compilar con Gradle desde la terminal:  node scripts/gradle.mjs assembleDebug | bundleRelease
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../android');
const win = process.platform === 'win32';
const task = process.argv[2] || 'assembleDebug';
const r = spawnSync(win ? 'gradlew.bat' : './gradlew', [task], { cwd: dir, stdio: 'inherit', shell: win });
if (r.status !== 0) { console.error('\n✖ Gradle falló. Lee docs/ANDROID.md → "Si algo falla" (JAVA_HOME, Android SDK, licencias).'); process.exit(r.status || 1); }
const out = { assembleDebug: 'android/app/build/outputs/apk/debug/app-debug.apk', bundleRelease: 'android/app/build/outputs/bundle/release/app-release.aab' }[task];
if (out) console.log('\n✔ Listo: ' + path.resolve(dir, '..', out));
