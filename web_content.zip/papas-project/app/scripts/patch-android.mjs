// Se ejecuta UNA vez justo después de `npx cap add android` (lo hace `npm run add:android`).
// Cambia solo lo necesario en el proyecto Android generado y es seguro repetirlo:
//   - Bloquea la app en vertical (el juego está pensado para celular vertical). ORIENTATION=any para permitir girar.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const manifest = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../android/app/src/main/AndroidManifest.xml');
if (!fs.existsSync(manifest)) { console.error('✖ No encuentro ' + manifest + '. Primero corre: npx cap add android'); process.exit(1); }
let xml = fs.readFileSync(manifest, 'utf8');
const orient = (process.env.ORIENTATION || 'portrait').toLowerCase();
if (orient === 'any') console.log('· Orientación libre: no se cambia nada.');
else if (/android:screenOrientation=/.test(xml)) console.log('· El manifiesto ya tiene screenOrientation: no se toca.');
else {
  const next = xml.replace(/(android:name="\.MainActivity")/, `$1\n            android:screenOrientation="${orient}"`);
  if (next === xml) console.warn('⚠ No pude editar el manifiesto automáticamente. Agrega android:screenOrientation="portrait" a <activity android:name=".MainActivity"> a mano.');
  else { fs.writeFileSync(manifest, next); console.log('✔ Orientación fijada: ' + orient); }
}
