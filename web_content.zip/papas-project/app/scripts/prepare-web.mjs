// Copia el juego (../www) a ./www (la carpeta que empaqueta Capacitor) y escribe config.js con los datos de TU servidor.
//   API_BASE=https://tu-servidor.com npm run web
// Variables opcionales: WHATSAPP_NUMBER (solo dígitos), SHOW_BUY=0 (versión sin compra, para Google Play), PRIVACY_URL
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const src = path.resolve(here, '../../www');
const dst = path.resolve(here, '../www');

const base = {};
vm.runInNewContext(fs.readFileSync(path.join(src, 'config.js'), 'utf8'), { window: base });
const cfg = { ...base.GAME_CONFIG };

const api = (process.env.API_BASE || '').trim().replace(/\/+$/, '');
if (!/^https:\/\/[^\s/?#]+$/.test(api)) {
  if (process.env.ALLOW_INSECURE === '1' && /^http:\/\//.test(api)) console.warn('⚠ API_BASE sin https: el APK normal NO podrá usarlo (contenido mixto bloqueado).');
  else {
    console.error('✖ Falta API_BASE con la URL https de tu servidor, por ejemplo:\n    API_BASE=https://mi-servidor.com npm run web\n  (Dentro del APK no existe "el mismo sitio": hay que decirle dónde está el servidor.)');
    process.exit(1);
  }
}
cfg.API_BASE = api;
if (process.env.WHATSAPP_NUMBER) cfg.WHATSAPP_NUMBER = process.env.WHATSAPP_NUMBER.replace(/\D/g, '');
if (process.env.SHOW_BUY !== undefined) cfg.SHOW_BUY = process.env.SHOW_BUY !== '0';
if (process.env.PRIVACY_URL) cfg.PRIVACY_URL = process.env.PRIVACY_URL;

fs.rmSync(dst, { recursive: true, force: true });
fs.mkdirSync(dst, { recursive: true });
for (const f of fs.readdirSync(src)) if (f !== 'config.js') fs.copyFileSync(path.join(src, f), path.join(dst, f));
fs.writeFileSync(path.join(dst, 'config.js'), '// Generado por scripts/prepare-web.mjs — no lo edites a mano.\nwindow.GAME_CONFIG = ' + JSON.stringify(cfg, null, 2) + ';\n');
console.log('✔ www listo → ' + dst + '\n  servidor: ' + cfg.API_BASE + ' · compra por WhatsApp: ' + (cfg.SHOW_BUY !== false ? 'sí' : 'NO (versión sin compra)'));
