# 🥔 LAS PAPAS DE RINCÓN, JAIR Y PARCHADITA — juego + Pase de Batalla + Premium + app Android

```
www/      El juego (index.html) + config.js + icon.png. Funciona solo, sin servidor.
server/   Servidor (Node, sin dependencias): cuentas, Pase de Batalla, Premium por clave, recompensa diaria, /admin.
app/      Proyecto Capacitor para generar el APK (prueba) y el AAB (Google Play).
docs/     Guías: CAMBIOS · BACKEND · VENTAS-Y-LEGAL · ANDROID
Dockerfile  Para subir el servidor a un hosting con Docker.
```

## Correrlo en tu computador (3 pasos)

Necesitas **Node.js 22.13 o más nuevo** (`node -v`).

```bash
cd server
cp .env.example .env
# Abre .env y pon en ADMIN_TOKEN una contraseña larga y aleatoria (mínimo 24 caracteres). Para crearla:
#   node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"
# Y agrega esta línea al final de .env para que el servidor también entregue el juego:
#   STATIC_DIR=../www
npm start
```

- Juego: <http://localhost:8787>
- Generar claves Premium (solo tú): <http://localhost:8787/admin>
- Pruebas automáticas del servidor: `npm test` (16 pruebas)

El juego **sigue funcionando sin servidor** (partida guardada en el celular); el servidor solo hace falta para el Pase, el Premium y la recompensa diaria.

## Cómo se vende el Premium ($4.000 COP)

1. El jugador crea su cuenta y toca **COMPRAR PREMIUM** → se abre **tu WhatsApp (+57 314 807 8630)** con el mensaje ya escrito.
2. Tú cobras por el medio que quieras (Nequi, Efecty, etc.).
3. Entras a `/admin`, generas una **clave de un solo uso** y se la mandas (hay botón "Enviar por WhatsApp").
4. El jugador la escribe en el juego (**PASE → Tengo una clave**) y queda Premium. La clave ya no sirve para nadie más.

Lee **docs/VENTAS-Y-LEGAL.md** antes de vender (qué debes tener en regla y la política de Google Play).

## Siguiente paso
- Subir el servidor a un hosting con disco persistente → **docs/BACKEND.md**
- Generar el APK / AAB → **docs/ANDROID.md**
- Qué cambió y qué límites tiene la seguridad → **docs/CAMBIOS.md**
