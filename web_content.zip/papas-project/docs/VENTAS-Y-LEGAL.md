# Cómo vender el Premium (WhatsApp) y qué tener en regla

> **No soy abogado ni contador.** Esto es una lista de puntos a revisar, con lo que pude verificar. Confirma con un profesional antes de cobrar de forma habitual.

## Cómo funciona la venta (lo que pediste)
Jugador toca **COMPRAR PREMIUM** → se abre tu WhatsApp con el mensaje listo → tú cobras por **cualquiera de tus medios** → generas una clave de un solo uso en `/admin` → se la envías → la escribe en **PASE → Tengo una clave** → Premium activo.

- **No hay pasarela de pagos ni pagos simulados.** El juego no procesa dinero, no pide ni guarda tarjetas, claves de Nequi ni datos bancarios.
- **Tú verificas el pago** (mira que el dinero realmente llegó) **antes** de generar la clave. Guarda el comprobante junto a la nota de la clave en `/admin`.
- El dinero virtual del juego **no se puede retirar ni convertir**; el único dinero real es el pago de $4.000 COP.

## Lista para revisar (Colombia)
1. **Tratamiento de datos personales (Ley 1581 de 2012, "habeas data").** Guardas usuario, contraseña cifrada y progreso. Necesitas: una **política de tratamiento** publicada (`/privacidad` es un **borrador**: reemplaza lo que está en [corchetes] con tus datos), **autorización** del jugador (el juego pide marcar la casilla al crear la cuenta y el servidor deja registro con fecha), y permitir **consultar y suprimir** datos (el juego tiene "Borrar mi cuenta" y existe `/borrar-cuenta`). Pregunta a la SIC (Superintendencia de Industria y Comercio) si tu caso te obliga a inscribir la base en el Registro Nacional de Bases de Datos.
2. **Menores de edad.** Los menores no pueden contratar solos. El juego pide "18 años o permiso de un adulto" al crear cuenta, y el texto lo repite; **no pidas nombre real, correo ni teléfono al jugador**. Si crees que tu público es mayormente de niños, consulta antes de publicar (hay reglas más estrictas para datos de menores).
3. **Vender con regularidad = actividad económica.** Pregunta a un contador por RUT, declaración de renta/IVA/ICA y factura o documento equivalente según tus ingresos. Cobrar por tu Nequi personal de forma habitual puede traer preguntas de tu entidad; pregunta cuál es el uso permitido de tu cuenta.
4. **Ventas a distancia / consumidor (Ley 1480 de 2011).** Define y publica tu política: qué compra el jugador, cuánto dura, si hay reembolso, cómo reclamar (hay un campo `[Reembolsos]` en `/privacidad`). Consulta si el derecho de retracto aplica a tu caso.
5. **Términos del juego.** Si usas música, imágenes o marcas de terceros (por ejemplo la bolsa real de "Parchaditas" de tu foto), asegúrate de tener derecho a usarlas. El juego usa dibujos propios hechos en el código.

## Pasarela de pago (si algún día quieres cobro automático)
No está implementado (elegiste WhatsApp + clave). Si luego quieres que el pago se confirme solo, lo legítimo sería un proveedor que tú contrates **a tu nombre**, y el servidor debe confirmar el pago con **webhooks firmados/consulta directa al proveedor** (nunca con lo que diga el navegador). Lo que verifiqué:
- **Wompi (Bancolombia)** ofrece **Nequi** (notificación push al celular), pero **no Efecty**.
- **Mercado Pago Colombia** ofrece **Efecty** (se genera un ticket para pagar en el punto), no Nequi.
- Para abrir cuenta comercial te piden verificación de identidad/negocio (por ejemplo RUT o cédula, cuenta bancaria; si eres persona natural o empresa cambia). **Confirma los requisitos actuales con cada proveedor**, cambian.
Para integrarlo habría que añadir al servidor "crear pago → recibir webhook → activar Premium"; las claves seguirían sirviendo como respaldo.

## ⚠️ Google Play (muy importante)
La política de pagos de Google Play exige **Google Play Billing** para vender cosas digitales (funciones, monedas del juego, suscripciones) dentro de apps publicadas en Play. Los programas que permiten otros métodos de pago solo cubren ciertos países (según lo que verifiqué: India, Corea, Espacio Económico Europeo y EE. UU.; **Colombia no**). Por eso:
- **APK que tú repartes directamente** (tu WhatsApp, tu página): puedes vender por WhatsApp sin problema con Google. Es lo que está configurado por defecto.
- **Versión en Google Play**: vender Premium por WhatsApp/claves dentro de esa app **puede hacer que suspendan la app**. Opciones: (a) publicar en Play una versión **sin compra** (`SHOW_BUY=0`: sin botón de compra ni campo de claves; los que ya sean Premium entran con su cuenta y funciona; hay riesgo de que Google lo vea como evasión si la compra se promociona fuera), o (b) implementar Google Play Billing (el servidor tendría que validar compras con la API de Google Play; **no está hecho**).
- Google también está endureciendo la instalación de apps fuera de Play (verificación de desarrolladores). Revisa si aplica a Colombia cuando publiques.
