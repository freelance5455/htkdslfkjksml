# Convertir el juego en app Android (APK de prueba y AAB para Google Play)

Se usa **Capacitor**: mete tu juego web (`www/`) dentro de un WebView de Android con tu propio ícono y nombre. No es "cambiar la extensión": es una app Android real (proyecto Gradle) que se compila a `.apk` / `.aab`.

> ⚠️ **No pude compilar el APK en el entorno donde trabajé** (no tiene Android SDK ni acceso a `npm install`). Por eso el `.zip` no trae un `.apk`: lo generas tú en tu computador con los pasos de abajo. La configuración sigue la documentación de Capacitor 8 pero **no la ejecuté en un teléfono**.

## 1. Lo que necesitas instalar (una vez)
| Qué | Versión | Nota |
|---|---|---|
| Node.js | 22 o más nuevo | `node -v` |
| Android Studio | **Otter 2025.2.1 o más nuevo** (requisito de Capacitor 8) | Instálalo y ábrelo una vez; en *SDK Manager* instala **Android SDK Platform 36**. Trae el JDK que hace falta (JDK 21). |
| Tu servidor en internet con **https** | — | ver `BACKEND.md`. El APK **no** trae servidor: hay que decirle dónde está. |

## 2. Generar el APK de prueba
En una terminal, dentro de la carpeta `app/`:

```bash
# 1) La dirección de TU servidor (obligatoria, con https y sin "/" al final).
#    Mac/Linux:   export API_BASE=https://tu-servidor.com
#    PowerShell:  $env:API_BASE="https://tu-servidor.com"
#    CMD:         set API_BASE=https://tu-servidor.com

npm install                # instala Capacitor
npm run web                # copia el juego a app/www y escribe su config.js con tu servidor
npm run add:android        # crea la carpeta android/ (solo la primera vez) y fija orientación vertical
npm run icons              # genera ícono (adaptativo) y pantalla de carga desde app/assets/
npm run apk                # sincroniza y compila
```
Resultado: **`app/android/app/build/outputs/apk/debug/app-debug.apk`**

Instalarlo en tu teléfono: pásalo por cable/WhatsApp/Drive y ábrelo (Android pedirá permitir "instalar apps de esta fuente"), o con el teléfono conectado y la depuración USB activada: `adb install -r app-debug.apk`.
Alternativa gráfica: `npm run open` abre Android Studio → botón ▶ Run con el teléfono conectado.

Cada vez que cambies algo del juego (`www/`) o el servidor de `API_BASE`: `npm run apk` otra vez.

> El APK "debug" está firmado con una llave de pruebas: sirve para probar y para repartir directo. **No** se sube a Google Play (ahí va el AAB).

## 3. Lo que ya está hecho para Android
- **Pantalla completa**: barra de estado oculta (`@capacitor/status-bar`), `viewport-fit=cover` y márgenes seguros (`safe-area`) para muescas/notch. El juego usa `position:fixed` a pantalla completa.
- **Adaptable**: el diseño ya era móvil-primero (probado de 360 px de ancho hasta escritorio y horizontal).
- **Táctil**: toques con `pointerdown`, sin zoom ni doble toque (`touch-action: manipulation`), sin selección de texto salvo en los campos de usuario/clave.
- **Orientación**: bloqueada en vertical (`ORIENTATION=any npm run add:android` si prefieres que gire).
- **Rendimiento**: sin librerías externas; el juego dibuja un solo SVG y actualiza solo lo que cambia. No pude medir fps en un teléfono real: pruébalo en uno de gama baja y dime si va lento.
- **Teclado**: al tocar usuario/clave la pantalla se desplaza hasta el campo. Si en tu teléfono el teclado tapa los botones, avísame (se arregla con el plugin `@capacitor/keyboard`).
- **WhatsApp**: "COMPRAR PREMIUM" abre `wa.me/573148078630` con el mensaje (usa `@capacitor/browser`; si el plugin no estuviera, cae a abrir el enlace externo). **Compruébalo en el teléfono.**
- **Nombre e ícono**: nombre "Las Papas de Rincón"; ícono propio (papa ondulada con limón) generado en `app/assets/` (se puede reemplazar por tu diseño: `icon-only.png`, `icon-foreground.png`, `icon-background.png` de 1024×1024 y `splash.png` de 2732×2732, luego `npm run icons`).

### Cambiar nombre / identificador
- **Nombre**: `app/capacitor.config.json` → `appName` (solo se lee al hacer `add:android`; después edita `android/app/src/main/res/values/strings.xml` → `app_name`).
- **Identificador** `appId` (ahora `co.parchaditas.papasderincon`, **inventado por mí**): cámbialo por uno tuyo (ej. `co.tunombre.papasderincon`) **antes** de publicar. Después de publicado en Google Play ya no se puede cambiar. Si ya creaste `android/`, bórrala y repite `npm run add:android`.

## 4. Generar el AAB para Google Play
El AAB (`.aab`) es el formato que pide Google Play; debe ir **firmado con tu llave**.

1. **Versión**: abre `app/android/app/build.gradle` → `defaultConfig` → `versionCode` (entero que **sube en cada subida**: 1, 2, 3…) y `versionName` ("1.0").
2. `npm run sync` (con `API_BASE` definida) para actualizar el juego dentro del proyecto.
3. `npm run open` → en Android Studio: **Build → Generate Signed App Bundle / APK… → Android App Bundle → Next**.
4. **Create new…** para crear tu *keystore* (un archivo `.jks` + contraseñas + alias). **Guárdalo y haz copias** (y anota las contraseñas): sin él no podrás actualizar la app (con *Play App Signing*, que es lo normal, Google guarda la llave final y la tuya es solo de "subida"; aun así guárdala).
5. Elige la variante **release** → Finish. Android Studio te dice dónde quedó el `.aab` (normalmente `android/app/release/app-release.aab`).

*(Opcional, desde terminal — no lo probé: crea `android/keystore.properties` con `storeFile`, `storePassword`, `keyAlias`, `keyPassword`, enlázalo en `android/app/build.gradle` con un `signingConfigs.release` y corre `npm run aab` → `android/app/build/outputs/bundle/release/app-release.aab`.)*

### Lista para publicar en Google Play (verificado en noviembre de 2026; revisa Play Console por si cambió)
- **Cuenta de desarrollador** de Google Play (pago único de inscripción).
- Si tu cuenta personal se creó **después del 13 de noviembre de 2023**, Google exige una **prueba cerrada con al menos 12 testers durante 14 días seguidos** antes de pedir acceso a producción ([fuente](https://support.google.com/googleplay/android-developer/answer/14151465)).
- **Nivel de API**: apps nuevas y actualizaciones deben apuntar a **Android 16 (API 36)** o superior ([fuente](https://support.google.com/googleplay/android-developer/answer/11926878?hl=en-419)). Capacitor 8 ya apunta a 36.
- **Política de privacidad** con URL pública: completa el borrador de `https://tu-servidor/privacidad`.
- **Formulario "Seguridad de los datos"**: declara que recoges usuario y contraseña (cuenta) y progreso del juego, cifrado en tránsito (https) y que el usuario puede pedir borrarlos.
- **Borrado de cuenta**: Google lo exige si la app crea cuentas: ya está **dentro del juego** (PASE → Tu cuenta → Borrar mi cuenta) y en la web `https://tu-servidor/borrar-cuenta` (pega esa URL en Play Console).
- **Clasificación de contenido** y **público objetivo**: responde con honestidad; si incluye niños aplican reglas más estrictas (Familias).
- **Pagos (¡importante!)**: lee la sección de Google Play en `VENTAS-Y-LEGAL.md`. Para Play usa `SHOW_BUY=0`:
  `SHOW_BUY=0 npm run sync` → sin botón de compra ni campo de claves.
- Ficha: ícono 512×512 (`www/icon.png` sirve), gráfico de función 1024×500 y capturas de pantalla (las haces tú).
- Sube primero a **prueba interna**, instala desde Play en un teléfono y revisa todo antes de producción.

## 5. Si algo falla
- **`API_BASE` error**: define la variable en la misma terminal (ver paso 2).
- **Gradle: "JAVA_HOME is not set"/versión de Java**: usa el JDK de Android Studio (en Windows suele ser `C:\Program Files\Android\Android Studio\jbr`); `JAVA_HOME` debe apuntar ahí.
- **"SDK location not found"**: abre el proyecto una vez con `npm run open` (Android Studio crea `local.properties`) o define `ANDROID_HOME`.
- **Licencias del SDK**: `sdkmanager --licenses` (viene con las "command-line tools" del SDK Manager).
- **`npm install` dice que no encuentra una versión de un plugin**: ejecuta `npm install @capacitor/browser@latest @capacitor/status-bar@latest` (los plugins oficiales deben tener la **misma versión mayor** que `@capacitor/core`).
- **Pantalla en blanco**: `npm run sync` otra vez. Para ver errores: pon `"webContentsDebuggingEnabled": true` en `capacitor.config.json`, `npm run sync`, abre `chrome://inspect` en Chrome con el teléfono conectado (déjalo en `false` para publicar).
- **El Pase dice "Sin conexión" en el APK**: revisa que `API_BASE` sea https y que el servidor tenga `ALLOWED_ORIGINS` con `https://localhost` (así se ve la app por dentro).
- **El botón de WhatsApp no abre nada**: dime en qué teléfono/Android; se resuelve con el plugin `@capacitor/app-launcher`.
