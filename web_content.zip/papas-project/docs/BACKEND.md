# Servidor (backend)

## ¿Por qué hace falta?
Con solo HTML/JavaScript **no se puede** hacer de forma segura: saber quién es Premium, que una clave sirva una sola vez, que el millón diario se reclame una vez por día, ni que las recompensas del Pase no se puedan inventar. Cualquier cosa que viva en el navegador la puede editar el jugador. Por eso hay un servidor pequeño (`server/`):

- Node.js **sin dependencias** (solo módulos incluidos: `node:http`, `node:crypto`, `node:sqlite`). Requiere **Node ≥ 22.13**.
- Base de datos **SQLite** en un solo archivo (`DB_PATH`). Para un juego de este tamaño sobra y es barata. **Necesita un disco que no se borre.**

## Variables de entorno (`server/.env`, nunca lo subas a GitHub)
| Variable | Para qué | Valor / ejemplo |
|---|---|---|
| `ADMIN_TOKEN` | **Obligatoria para vender.** Contraseña de `/admin`. Mínimo 24 caracteres aleatorios. Sin ella no se pueden generar claves. | `node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))"` |
| `WHATSAPP_NUMBER` | Tu WhatsApp, país + número, solo dígitos | `573148078630` |
| `PUBLIC_BASE_URL` | URL pública del servidor (con https) | `https://tu-dominio.com` |
| `ALLOWED_ORIGINS` | Quién puede llamar al servidor desde otro origen. **Para el APK debe incluir `https://localhost`** (así se ve la app por dentro). Separados por coma. | `https://localhost,capacitor://localhost` |
| `DB_PATH` | Dónde está la base de datos (en el disco persistente) | `/data/papas.db` |
| `STATIC_DIR` | Carpeta del juego web, si quieres que el servidor también lo sirva | `../www` |
| `TRUST_PROXY` | `1` si estás detrás de un hosting/proxy (para leer bien la IP real y limitar abusos) | `1` |
| `PORT` | Puerto | `8787` (muchos hostings lo ponen solos) |
| `PREMIUM_PRICE_COP` | Precio que se muestra | `4000` |
| `PREMIUM_DAYS` | Días de Premium por clave (0 = permanente). En `/admin` puedes cambiarlo clave por clave | `30` |
| `PREMIUM_DAILY_MONEY` | Dinero virtual diario | `1000000` |
| `SEASON_ID`, `SEASON_NAME` | Temporada del Pase. Cambiar `SEASON_ID` empieza un Pase nuevo desde cero | `S1` |
| `DAILY_XP_CAP` | Tope de XP por día (anti-trampa) | `1000` |
| `WHATSAPP_MESSAGE` | Mensaje prellenado (`{precio}` y `{usuario}` se reemplazan solos) | opcional |

No hay **ninguna** clave de pasarela de pagos, API de terceros ni credenciales bancarias en este proyecto.

## ¿Dónde alojarlo? (verificado en noviembre de 2026; los precios cambian, confirma)
La base es un archivo, así que el hosting **debe tener disco persistente**. Si se borra, **se pierden las cuentas y los Premium que ya vendiste**.

- ❌ **Render plan gratis**: [no tiene discos persistentes y el sistema de archivos se borra en cada reinicio o suspensión](https://render.com/docs/free) (se duerme tras 15 min sin tráfico). **No lo uses para esto.**
- ✅ **Un VPS pequeño** (cualquier proveedor, normalmente unos pocos USD al mes) con Ubuntu: instalas Node 22, corres el servidor con `systemd` y pones HTTPS con Caddy. Es lo más simple de entender y de respaldar.
- ✅ **Fly.io** (con Docker + un *volume*): [no tiene plan gratis para cuentas nuevas; una máquina pequeña cuesta del orden de US$2 al mes más el volumen](https://www.activepieces.com/blog/fly-io-pricing-in-2026-for-machines-volumes-and-ips.md). Usa el `Dockerfile` de la raíz y monta el volumen en `/data`.
- ✅ Cualquier hosting con Docker y volúmenes (Railway, etc.): mismo `Dockerfile`, volumen en `/data`.
- Más adelante, si crece mucho, se puede migrar a PostgreSQL (no está hecho).

**HTTPS es obligatorio** para el APK (Android bloquea http dentro de la app). Todos los hostings anteriores lo dan o se pone con Caddy.

### Con Docker (ejemplo)
```bash
docker build -t papas .
docker run -d --restart unless-stopped -p 8787:8787 -v papas-datos:/data --env-file server/.env papas
```
(En `server/.env` no pongas `DB_PATH` ni `STATIC_DIR`: el Dockerfile ya los define.)

### Respaldos (haz esto, en serio)
Copia segura de la base mientras corre (cada día, a otro lugar):
```bash
node --disable-warning=ExperimentalWarning -e "const {DatabaseSync}=require('node:sqlite');new DatabaseSync('/data/papas.db').exec(\"VACUUM INTO '/data/respaldo.db'\")"
```
Guarda `respaldo.db` fuera del servidor. Para restaurar: detén el servidor y reemplaza `papas.db` por la copia.

## Generar y vender claves
- Página privada: `https://tu-servidor/admin` → pones la contraseña (`ADMIN_TOKEN`) → "Generar 1 clave" (días + nota, ej. "Juan – Nequi 14 nov") → copiar o "Enviar por WhatsApp".
- Terminal: `cd server && npm run codes -- 5 30 "lote nov"` (5 claves de 30 días).
- La clave **se muestra una sola vez**: en la base solo queda su huella (hash). Si la pierdes, anulas la anterior en `/admin` y generas otra.
- Una clave usada queda ligada a la cuenta y no sirve de nuevo (aunque la cuenta se borre).
- Si alguien escribe mal claves muchas veces, el servidor lo frena (8 intentos / 10 min por cuenta).

## Páginas que sirve el servidor
`/admin` (claves) · `/privacidad` (**borrador**, complétalo: ver VENTAS-Y-LEGAL.md) · `/borrar-cuenta` (borrado de cuenta por web; Google Play lo pide).

## API (para referencia)
`GET /api/health` · `GET /api/config` · `POST /api/auth/register|login|logout` · `GET /api/me` · `POST /api/daily/claim` · `POST /api/pass/progress` · `POST /api/pass/claim` · `POST /api/wallet/ack` · `POST /api/premium/redeem` · `POST /api/account/delete` · `POST|GET /api/admin/codes`, `POST /api/admin/codes/void` (solo con `ADMIN_TOKEN`).
Respuestas `{ok:true,...}` o `{ok:false,error:"codigo"}`.

## Seguridad implementada
- Contraseñas con **scrypt** + sal; nunca se guardan ni se registran en texto. Las sesiones son tokens aleatorios guardados **como hash**, vencen a los 30 días y se pueden cerrar.
- Claves Premium: 16 caracteres aleatorios criptográficos (~78 bits), guardadas solo como hash, canje **atómico** (transacción) → dos personas con la misma clave nunca la usan las dos.
- Reclamos (diario, niveles) con restricción única en la base de datos: ni dos clics a la vez ni peticiones falsas los duplican.
- Dinero virtual entregado como "grants" con id único; el juego los aplica una vez y los confirma (ack).
- Límite de intentos por IP/cuenta, tamaño máximo de petición, CORS con lista de orígenes, cabeceras de seguridad y CSP en las páginas del servidor, registro de auditoría (sin IP ni contraseñas).
- **No** guarda tarjetas, claves de Nequi ni datos bancarios, ni los pide.

## Pruebas
`cd server && npm test` → 16 pruebas (claves de un solo uso, carreras, doble reclamo, caducidad, tope de XP, borrado de cuenta, CORS…).
