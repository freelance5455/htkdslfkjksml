# Qué cambié (y qué NO)

El juego **no se rediseñó**: mismos personajes, nombres, mecánicas, estilo, guardado y partida. Todo lo nuevo está **añadido**.
Las únicas líneas existentes que toqué son las mínimas para enganchar lo nuevo (lista abajo).

## 1. Análisis previo (lo que había)
| Pregunta | Respuesta |
|---|---|
| ¿Cómo funciona el dinero? | `S.money` (pesos COP), se gana al vender paquetes/pedidos y se gasta en mejoras, ayudantes y niveles. Todo vive en el navegador. |
| ¿Dónde se guardan los datos? | `localStorage` clave `parchaditas_save_v1`, cada 4 s. **No cambié ese formato** (las partidas viejas siguen funcionando). |
| ¿Había cuentas/login? | No. |
| ¿Dónde va el Pase? | Una pestaña nueva en la hoja de menú (`TABS`) + un botón en la escena + una sección nueva al final del `<script>`. |
| ¿Qué necesita servidor? | Premium, claves de un solo uso, recompensa diaria, niveles/XP y recompensas del Pase (todo lo que "no debe confiar en el navegador"). |
| ¿Qué cambia para Android? | Pantalla completa, orientación, URL del servidor (en el APK no existe "el mismo sitio"), abrir WhatsApp, ícono. |

## 2. Archivos

**Nuevos**
- `server/` completo: `server.mjs`, `game.mjs`, `db.mjs`, `codes.mjs`, `admin.html`, `legal/privacy.html`, `legal/delete-account.html`, `scripts/make-codes.mjs`, `test/server.test.mjs`, `.env.example`, `package.json`.
- `www/config.js` (ajustes no secretos del juego), `www/icon.png`.
- `app/` completo (Capacitor): `package.json`, `capacitor.config.json`, `assets/` (ícono y splash), `scripts/*.mjs`.
- `Dockerfile`, `README.md`, `docs/*.md`.

**Modificado**: `www/index.html` (antes `index.html`, 62 KB → 90 KB). Cambios:
| Dónde | Qué |
|---|---|
| `<head>` | `theme-color`, ícono, `<script src="config.js">` |
| CSS | Bloque nuevo "PASE DE BATALLA / PREMIUM" al final de los estilos. **Arreglo de un defecto que ya tenía el juego**: la barra de pestañas se aplastaba en pantallas largas (MEJORAS). Márgenes seguros (`--safe-area-*`) además de `env()`. |
| Escena | Botón `🎟️ PASE DE BATALLA` (aparece al terminar el tutorial; con ❗ si hay algo por reclamar y 👑 si eres Premium). |
| `power()` | `+ perk('tap')` → **Agilidad**: +1 de fuerza por toque. |
| `cookTime()` | `× (1 - perk('cook'))` → **Rapidez**: cocción 15 % más rápida. |
| `TRIP` | pasó de `const` a `let` y se recalcula en `tick()` → camión 20 % más rápido. |
| trabajadores | `× (1 + perk('workers'))` → ayudantes 10 % más rápidos. |
| `TABS`, `cfgHTML`, `panelSig`, `renderPanel`, `renderTabs` | Pestaña `🎟️ PASE`, tarjeta de cuenta en ⚙️, y que los campos de texto y el scroll no se pierdan al redibujar. |
| HUD | `👑` junto a "NIVEL" si eres Premium. |
| `ui()`, clics, `startGame` | `passUI()` en cada cuadro, acciones `p_*`, `passInit()` al empezar. |
| **Sección 8 (nueva, al final)** | Cuenta, Pase, Premium, recompensa diaria, WhatsApp, canje de clave, sincronización, modo sin conexión. |

## 3. Qué decide el servidor y qué no (leer esto)

**El servidor es la autoridad de:** quién es Premium y hasta cuándo · las claves (guardadas solo como hash, un solo uso, atómico) · la recompensa diaria (1 por día de Colombia, hora del servidor) · el XP y el nivel del Pase (con tope diario y límite de velocidad) · qué recompensas se reclamaron (una sola vez) · cuánto dinero virtual se entrega (cada entrega tiene un id y se confirma una sola vez).
El navegador **nunca** dice "dame Premium" ni "súmame dinero": solo pide, y el servidor responde.

**Límites reales (no los escondo):**
1. El juego es de **un solo jugador y vive en el celular**: el dinero y los bonos de velocidad se aplican en el cliente. Alguien que modifique el APK/HTML puede cambiarse el dinero de su propia partida o activarse los bonos **en su propio celular**. Lo que **no** puede es ser Premium de verdad, canjear claves ajenas, reclamar dos veces, ni tener recompensas del Pase sin ganarlas. Para blindar también el dinero tendría que mover toda la economía al servidor (otro proyecto).
2. El progreso del Pase usa lo que el cliente **reporta** que jugó; el servidor lo limita (máx. por envío, 1 envío cada 10 s, tope diario de XP) pero no puede "ver" el juego.
3. Bonos sin conexión: se recuerda el último estado verificado por el servidor, **máximo 72 horas**.
4. El dinero virtual del juego no tiene ninguna función de retiro ni de conversión; no existe en el código.

## 4. Decisiones que tomé por ti (cámbialas si quieres)
- **Duración del Premium: 30 días por clave** (`PREMIUM_DAYS`; 0 = permanente; en `/admin` puedes poner otra por clave). Tu pedido decía "cada día" para el millón, no decía duración.
- **Un millón diario** = 1 reclamo por día calendario de Colombia (se reinicia a las 12:00 a. m. hora de Bogotá).
- **Recompensas del Pase** (30 niveles, dinero virtual + objetos cosméticos 🧢 ✨ 🍋…) están en `server/game.mjs` (`rewardFor`, `ITEMS`). Los objetos son decorativos: se muestran en la lista del Pase.
- **Nombre del paquete Android**: `co.parchaditas.papasderincon` es un nombre puesto por mí; cámbialo por uno tuyo **antes** de publicar (después no se puede).

## 5. Qué probé (y qué no)
✔ Servidor: 16 pruebas automáticas (claves de un solo uso, doble reclamo, carreras, sesiones, XP, tope diario, borrado de cuenta, CORS…).
✔ Juego en navegador móvil simulado (360×700): flujo original completo sin errores; cuenta, canje, diario, reclamos, WhatsApp (se abre `wa.me/573148078630` con usuario y precio), recarga de página, sin internet, caché de más de 72 h, caché falsificada, ack fallido sin duplicar dinero, otro origen (CORS como el APK), simulación de 10 min con y sin Premium.
✘ **No pude compilar el APK/AAB aquí** (no hay Android SDK y no hay red para `npm install`). Los scripts y la configuración están hechos según la documentación de Capacitor 8 pero **no se ejecutaron en un teléfono**. Revisa en el APK de prueba: pantalla completa/notch, teclado al escribir usuario/clave, y que el botón de WhatsApp abra la app.
✘ No probé un hosting real ni HTTPS real.
