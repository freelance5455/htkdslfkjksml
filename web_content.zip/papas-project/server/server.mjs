// server.mjs — Backend del juego (Node 22, sin dependencias). Autoridad de: cuentas, Premium,
// claves de Premium (un solo uso), recompensa diaria, XP/niveles/recompensas del Pase y dinero virtual entregado por esas recompensas.
// Ejecutar:  node server.mjs   (ver .env.example)
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { openDb, tx } from './db.mjs';
import { loadConfig, ITEMS, PERKS, XP, passLevels, levelOf, thr, rewardFor, dayKey, nextDayAt } from './game.mjs';
import { makeCode, normCode, sha256 } from './codes.mjs';

const scrypt = promisify(crypto.scrypt);
const DAY = 86400e3;
class HttpError extends Error { constructor(status, code, extra) { super(code); this.status = status; this.code = code; this.extra = extra || {}; } }
const fail = (s, c, e) => { throw new HttpError(s, c, e); };
const int = (v) => (typeof v === 'number' && Number.isFinite(v) ? Math.floor(v) : 0);
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json' };

export function createApp(opts = {}) {
  const cfg = opts.cfg || loadConfig();
  const db = opts.db || openDb(cfg.dbPath);
  const now = opts.now || Date.now;
  const q = (sql) => db.prepare(sql);
  const log = opts.log || ((o) => console.log(JSON.stringify(o)));
  const audit = (accountId, event, detail) => q('INSERT INTO audit(ts,account_id,event,detail) VALUES(?,?,?,?)').run(now(), accountId ?? null, event, detail ? String(detail).slice(0, 300) : null);

  /* ---------- límites de uso (en memoria) ---------- */
  const buckets = new Map();
  const limit = (key, max, win) => {
    const t = now(); let b = buckets.get(key);
    if (!b || b.reset < t) { b = { n: 0, reset: t + win }; buckets.set(key, b); }
    if (++b.n > max) fail(429, 'rate_limited', { retryMs: b.reset - t });
  };
  const purge = setInterval(() => { const t = now(); for (const [k, b] of buckets) if (b.reset < t) buckets.delete(k); }, 60e3); purge.unref();

  /* ---------- cuentas y sesiones ---------- */
  const pwHash = async (pw, salt) => (await scrypt(pw, salt, 64, { N: 16384, r: 8, p: 1 })).toString('hex');
  const same = (a, b) => a.length === b.length && crypto.timingSafeEqual(Buffer.from(a, 'hex'), Buffer.from(b, 'hex'));
  async function newSession(id) {
    const token = crypto.randomBytes(32).toString('base64url');
    q('INSERT INTO sessions(token_hash,account_id,created_at,expires_at) VALUES(?,?,?,?)').run(sha256(token), id, now(), now() + 30 * DAY);
    return token;
  }
  function authed(req) {
    const m = /^Bearer ([A-Za-z0-9_-]{20,100})$/.exec(req.headers.authorization || '');
    if (!m) fail(401, 'unauthorized');
    const s = q('SELECT account_id,expires_at FROM sessions WHERE token_hash=?').get(sha256(m[1]));
    if (!s || s.expires_at < now()) fail(401, 'unauthorized');
    return q('SELECT * FROM accounts WHERE id=?').get(s.account_id);
  }
  const validCreds = (b) => {
    const u = typeof b.username === 'string' ? b.username.trim() : '', p = typeof b.password === 'string' ? b.password : '';
    if (!/^[A-Za-z0-9_]{3,16}$/.test(u)) fail(400, 'bad_username');
    if (p.length < 8 || p.length > 128) fail(400, 'bad_password');
    return { u, p };
  };

  /* ---------- Premium, dinero virtual (grants), recompensas ---------- */
  const premiumState = (a) => {
    const perm = a.premium_perm === 1, until = a.premium_until || null;
    return { active: perm || (!!until && until > now()), until, permanent: perm };
  };
  function activatePremium(id, days) {   // days = 0 → permanente; si ya hay Premium activo, los días se SUMAN
    const a = q('SELECT premium_until FROM accounts WHERE id=?').get(id);
    if (days === 0) q('UPDATE accounts SET premium_perm=1 WHERE id=?').run(id);
    else q('UPDATE accounts SET premium_until=? WHERE id=?').run(Math.max(now(), a.premium_until || 0) + days * DAY, id);
  }
  // Un "grant" es dinero virtual pendiente de entregar al juego. El cliente lo aplica una vez y lo confirma (ack).
  function addGrant(accountId, amount, reason) {
    const id = 'g_' + crypto.randomUUID();
    q('INSERT INTO grants(id,account_id,amount,reason,created_at) VALUES(?,?,?,?,?)').run(id, accountId, amount, reason, now());
    return { id, amount, reason };
  }
  function profile(a) {
    const t = now(), prem = premiumState(a), day = dayKey(t);
    const xp = (q('SELECT xp FROM pass_progress WHERE account_id=? AND season=?').get(a.id, cfg.seasonId) || { xp: 0 }).xp;
    const level = levelOf(xp, cfg.maxLevel);
    const used = (q('SELECT xp FROM xp_daily WHERE account_id=? AND day=?').get(a.id, day) || { xp: 0 }).xp;
    const last = q('SELECT day,claimed_at FROM daily_claims WHERE account_id=? ORDER BY day DESC LIMIT 1').get(a.id);
    const today = !!last && last.day === day;
    return {
      serverTime: t, user: { username: a.username }, premium: prem, perks: prem.active ? PERKS : null,
      daily: { amount: cfg.dailyMoney, available: prem.active && !today, claimedToday: today, nextAt: today ? nextDayAt(day) : null, lastAt: last ? last.claimed_at : null },
      pass: {
        season: cfg.seasonId, xp, level, maxLevel: cfg.maxLevel, levelStart: thr(level), levelEnd: thr(Math.min(level + 1, cfg.maxLevel)),
        dailyXp: used, dailyCap: cfg.dailyXpCap, lastSeq: a.last_seq,
        claims: q('SELECT level,track FROM pass_claims WHERE account_id=? AND season=?').all(a.id, cfg.seasonId).map((c) => `${c.track}:${c.level}`),
      },
      items: q('SELECT item_id FROM items WHERE account_id=?').all(a.id).map((r) => r.item_id),
      grants: q('SELECT id,amount,reason FROM grants WHERE account_id=? AND acked_at IS NULL ORDER BY created_at LIMIT 50').all(a.id),
    };
  }
  const fresh = (id) => q('SELECT * FROM accounts WHERE id=?').get(id);

  /* ---------- administración de claves (solo con ADMIN_TOKEN) ---------- */
  function adminAuth(req, ip) {
    if (!cfg.adminToken || cfg.adminToken.length < 24) fail(503, 'admin_disabled');
    const bad = buckets.get('admbad:' + ip);
    if (bad && bad.reset > now() && bad.n >= 10) fail(429, 'rate_limited', { retryMs: bad.reset - now() });   // se revisa ANTES de comparar
    const m = /^Bearer (.{1,200})$/.exec(req.headers.authorization || '');
    const h = (s) => crypto.createHash('sha256').update(s).digest();
    if (!m || !crypto.timingSafeEqual(h(m[1]), h(cfg.adminToken))) { audit(null, 'admin_bad_token', ip); limit('admbad:' + ip, 10, 900e3); fail(401, 'unauthorized'); }
  }

  /* ---------- rutas ---------- */
  const routes = {
    'GET /api/health': () => ({ time: now() }),
    'GET /api/config': () => ({
      season: { id: cfg.seasonId, name: cfg.seasonName, maxLevel: cfg.maxLevel }, levels: passLevels(cfg.maxLevel), items: ITEMS,
      price: { cop: cfg.priceCop, days: cfg.premiumDays }, dailyMoney: cfg.dailyMoney, dailyXpCap: cfg.dailyXpCap, perks: PERKS,
      xp: { pack: XP.pack, order: XP.order, trip: XP.trip },
      whatsapp: cfg.whatsappNumber ? { number: cfg.whatsappNumber, message: cfg.whatsappMessage } : null,
    }),
    'POST /api/auth/register': async ({ body, ip }) => {
      limit('reg:' + ip, 40, 3600e3);   // generoso: en Colombia muchos celulares comparten la misma IP (CGNAT)
      const { u, p } = validCreds(body);
      if (body.terms !== true) fail(400, 'terms_required');   // el jugador marcó "Acepto términos y privacidad" (queda registrado en audit con la fecha)
      if (q('SELECT 1 FROM accounts WHERE username=?').get(u)) fail(409, 'username_taken');
      const salt = crypto.randomBytes(16).toString('hex');
      let id;
      try { id = Number(q('INSERT INTO accounts(username,pass_salt,pass_hash,created_at) VALUES(?,?,?,?)').run(u, salt, await pwHash(p, salt), now()).lastInsertRowid); }
      catch { fail(409, 'username_taken'); }
      audit(id, 'register', 'terms=v1'); return { token: await newSession(id) };
    },
    'POST /api/auth/login': async ({ body, ip }) => {
      const { u, p } = validCreds(body);
      limit('login:' + ip, 30, 900e3); limit('loginu:' + u.toLowerCase(), 8, 900e3);
      const a = q('SELECT * FROM accounts WHERE username=?').get(u);
      const h = await pwHash(p, a ? a.pass_salt : '0'.repeat(32));        // se calcula siempre (evita revelar si el usuario existe)
      if (!a || !same(h, a.pass_hash)) fail(401, 'bad_credentials');
      return { token: await newSession(a.id) };
    },
    'POST /api/auth/logout': ({ req }) => {
      const m = /^Bearer (\S+)$/.exec(req.headers.authorization || '');
      if (m) q('DELETE FROM sessions WHERE token_hash=?').run(sha256(m[1]));
      return {};
    },
    'GET /api/me': ({ req }) => ({ profile: profile(authed(req)) }),
    'POST /api/daily/claim': ({ req }) => {
      const a = authed(req); limit('dc:' + a.id, 30, 60e3);
      return tx(db, () => {
        const f = fresh(a.id);
        if (!premiumState(f).active) fail(403, 'premium_required');
        const day = dayKey(now());
        const ins = q('INSERT OR IGNORE INTO daily_claims(account_id,day,claimed_at,amount) VALUES(?,?,?,?)').run(a.id, day, now(), cfg.dailyMoney);
        if (ins.changes === 0) fail(409, 'already_claimed', { nextAt: nextDayAt(day) });
        const grant = addGrant(a.id, cfg.dailyMoney, 'daily'); audit(a.id, 'daily_claim', day);
        return { grant, profile: profile(f) };
      });
    },
    'POST /api/pass/progress': ({ req, body }) => {
      const a = authed(req), t = now(), seq = body.seq;
      if (!Number.isInteger(seq) || seq < 1) fail(400, 'bad_request');
      if (seq <= a.last_seq) fail(409, 'stale_seq', { lastSeq: a.last_seq });
      if (t - a.last_progress_at < XP.minSyncMs) fail(429, 'too_fast', { retryMs: XP.minSyncMs - (t - a.last_progress_at) });
      const c = (v, m) => Math.min(m, Math.max(0, int(v)));
      const want = c(body.packs, XP.maxPerSync.packs) * XP.pack + c(body.orders, XP.maxPerSync.orders) * XP.order + c(body.trips, XP.maxPerSync.trips) * XP.trip;
      return tx(db, () => {
        const day = dayKey(t), used = (q('SELECT xp FROM xp_daily WHERE account_id=? AND day=?').get(a.id, day) || { xp: 0 }).xp;
        const gain = Math.max(0, Math.min(want, cfg.dailyXpCap - used));      // tope diario: tampoco se puede acelerar sin límite haciendo trampa
        if (gain > 0) {
          q('INSERT INTO xp_daily(account_id,day,xp) VALUES(?,?,?) ON CONFLICT(account_id,day) DO UPDATE SET xp=xp+excluded.xp').run(a.id, day, gain);
          q('INSERT INTO pass_progress(account_id,season,xp) VALUES(?,?,?) ON CONFLICT(account_id,season) DO UPDATE SET xp=xp+excluded.xp').run(a.id, cfg.seasonId, gain);
        }
        q('UPDATE accounts SET last_seq=?,last_progress_at=? WHERE id=?').run(seq, t, a.id);
        return { gained: gain, capped: gain < want, profile: profile(fresh(a.id)) };
      });
    },
    'POST /api/pass/claim': ({ req, body }) => {
      const a = authed(req), { level, track } = body; limit('pc:' + a.id, 60, 60e3);
      if (!Number.isInteger(level) || level < 1 || level > cfg.maxLevel || !['free', 'premium'].includes(track)) fail(400, 'bad_request');
      return tx(db, () => {
        const f = fresh(a.id), xp = (q('SELECT xp FROM pass_progress WHERE account_id=? AND season=?').get(a.id, cfg.seasonId) || { xp: 0 }).xp;
        if (levelOf(xp, cfg.maxLevel) < level) fail(403, 'level_locked');
        if (track === 'premium' && !premiumState(f).active) fail(403, 'premium_required');
        const ins = q('INSERT OR IGNORE INTO pass_claims(account_id,season,level,track,claimed_at) VALUES(?,?,?,?,?)').run(a.id, cfg.seasonId, level, track, now());
        if (ins.changes === 0) fail(409, 'already_claimed');
        const rw = rewardFor(track, level);
        const grant = rw.money > 0 ? addGrant(a.id, rw.money, `pass:${track}:${level}`) : null;
        if (rw.item) q('INSERT OR IGNORE INTO items(account_id,item_id,acquired_at) VALUES(?,?,?)').run(a.id, rw.item, now());
        return { reward: rw, grant, profile: profile(f) };
      });
    },
    'POST /api/wallet/ack': ({ req, body }) => {
      const a = authed(req), ids = Array.isArray(body.ids) ? body.ids.filter((x) => typeof x === 'string').slice(0, 50) : [];
      const st = q('UPDATE grants SET acked_at=? WHERE id=? AND account_id=? AND acked_at IS NULL');
      for (const id of ids) st.run(now(), id, a.id);
      return { profile: profile(a) };
    },
    // El jugador canjea la clave que le diste. Se marca como usada de forma ATÓMICA: dos canjes a la vez nunca pasan los dos.
    'POST /api/premium/redeem': ({ req, body, ip }) => {
      const a = authed(req); limit('rd:' + a.id, 8, 600e3); limit('rdip:' + ip, 30, 600e3);
      const norm = normCode(body.code);
      if (!norm) { audit(a.id, 'redeem_bad_format'); fail(400, 'invalid_code'); }
      return tx(db, () => {
        const c = q('SELECT id,days,redeemed_at,voided_at FROM premium_codes WHERE hash=?').get(sha256(norm));
        if (!c || c.voided_at) { audit(a.id, 'redeem_invalid'); fail(404, 'invalid_code'); }
        if (c.redeemed_at) { audit(a.id, 'redeem_already_used', c.id); fail(409, 'code_used'); }
        const u = q('UPDATE premium_codes SET redeemed_at=?,redeemed_by=? WHERE id=? AND redeemed_at IS NULL').run(now(), a.id, c.id);
        if (u.changes !== 1) fail(409, 'code_used');
        activatePremium(a.id, c.days); audit(a.id, 'premium_activated', 'code#' + c.id);
        return { profile: profile(fresh(a.id)) };
      });
    },
    // Borrado de cuenta (exigido por Ley 1581 / Google Play): pide la contraseña, borra todo lo del jugador y anonimiza el registro.
    'POST /api/account/delete': async ({ req, body }) => {
      const a = authed(req); limit('del:' + a.id, 5, 900e3);
      const pw = typeof body.password === 'string' ? body.password.slice(0, 128) : '';
      if (!same(await pwHash(pw, a.pass_salt), a.pass_hash)) { audit(a.id, 'delete_bad_password'); fail(401, 'bad_credentials'); }
      tx(db, () => {
        for (const t of ['sessions', 'pass_progress', 'xp_daily', 'pass_claims', 'daily_claims', 'grants', 'items']) q(`DELETE FROM ${t} WHERE account_id=?`).run(a.id);
        q('UPDATE premium_codes SET redeemed_by=NULL WHERE redeemed_by=?').run(a.id);   // la clave sigue marcada como usada
        q('UPDATE audit SET account_id=NULL WHERE account_id=?').run(a.id);
        q('DELETE FROM accounts WHERE id=?').run(a.id);
        audit(null, 'account_deleted', 'id#' + a.id);
      });
      return {};
    },
    'POST /api/admin/codes': ({ req, body, ip }) => {
      adminAuth(req, ip);
      const count = Math.min(50, Math.max(1, int(body.count) || 1));
      const days = body.days === undefined ? cfg.premiumDays : Math.min(3650, Math.max(0, int(body.days)));
      const note = typeof body.note === 'string' ? body.note.trim().slice(0, 80) : '';
      const codes = [];
      tx(db, () => {
        for (let i = 0; i < count; i++) {
          const c = makeCode(), norm = normCode(c);
          q('INSERT INTO premium_codes(hash,hint,days,note,created_at) VALUES(?,?,?,?,?)').run(sha256(norm), norm.slice(-4), days, note, now());
          codes.push(c);
        }
      });
      audit(null, 'admin_codes_created', `${count} x ${days}d`);
      return { codes, days };
    },
    'GET /api/admin/codes': ({ req, ip }) => {
      adminAuth(req, ip);
      return { codes: q('SELECT c.id,c.hint,c.days,c.note,c.created_at,c.redeemed_at,c.voided_at,a.username AS redeemed_by FROM premium_codes c LEFT JOIN accounts a ON a.id=c.redeemed_by ORDER BY c.id DESC LIMIT 100').all() };
    },
    'POST /api/admin/codes/void': ({ req, body, ip }) => {
      adminAuth(req, ip);
      const u = q('UPDATE premium_codes SET voided_at=? WHERE id=? AND redeemed_at IS NULL AND voided_at IS NULL').run(now(), int(body.id));
      if (u.changes !== 1) fail(404, 'not_found');
      audit(null, 'admin_code_voided', body.id); return {};
    },
  };

  /* ---------- HTTP ---------- */
  const ipOf = (req) => (cfg.trustProxy && req.headers['x-forwarded-for'] ? String(req.headers['x-forwarded-for']).split(',')[0].trim() : req.socket.remoteAddress) || '?';
  const send = (res, code, obj) => { const s = JSON.stringify(obj); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(s) }); res.end(s); };
  const readBody = (req) => new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', (c) => { n += c.length; if (n > 16384) { if (n - c.length <= 16384) reject(new HttpError(413, 'too_large')); chunks.length = 0; } else chunks.push(c); });
    req.on('end', () => { const s = Buffer.concat(chunks).toString('utf8'); if (!s) return resolve({}); try { const j = JSON.parse(s); resolve(j && typeof j === 'object' ? j : {}); } catch { reject(new HttpError(400, 'bad_json')); } });
    req.on('error', reject);
  });
  function serveStatic(req, res, pathname) {
    const PAGES = { '/admin': 'admin.html', '/borrar-cuenta': 'legal/delete-account.html', '/privacidad': 'legal/privacy.html' };   // viven en server/, NO dentro de www/ (no van dentro del APK)
    if (PAGES[pathname]) {
      const f = path.resolve(path.dirname(fileURLToPath(import.meta.url)), PAGES[pathname]);
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'" });
      return res.end(fs.readFileSync(f));
    }
    const root = cfg.staticDir && path.resolve(cfg.staticDir);
    if (!root || req.method !== 'GET' || !fs.existsSync(root)) { res.writeHead(404); return res.end('not found'); }
    const rel = decodeURIComponent(pathname === '/' ? '/index.html' : pathname), file = path.resolve(root, '.' + rel);
    if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404); return res.end('not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream' }); fs.createReadStream(file).pipe(res);
  }
  const server = http.createServer(async (req, res) => {
    const origin = req.headers.origin, t0 = Date.now();
    res.setHeader('Vary', 'Origin'); res.setHeader('X-Content-Type-Options', 'nosniff'); res.setHeader('Referrer-Policy', 'no-referrer');
    if (origin && cfg.allowedOrigins.includes(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin); res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); res.setHeader('Access-Control-Max-Age', '600');
    }
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
    let url;
    try { url = new URL(req.url, 'http://x'); } catch { res.writeHead(400); return res.end(); }
    if (!url.pathname.startsWith('/api/')) return serveStatic(req, res, url.pathname);
    res.setHeader('Cache-Control', 'no-store');
    let code = 200;
    try {
      const h = routes[`${req.method} ${url.pathname}`];
      if (!h) fail(404, 'not_found');
      const body = req.method === 'POST' ? await readBody(req) : {};
      send(res, 200, { ok: true, ...(await h({ req, body, url, ip: ipOf(req) })) });
    } catch (e) {
      if (e instanceof HttpError) { code = e.status; if (code === 413) { res.setHeader('Connection', 'close'); res.on('finish', () => req.socket.destroy()); } send(res, code, { ok: false, error: e.code, ...e.extra }); }
      else { code = 500; log({ ev: 'server_error', msg: e.message }); send(res, 500, { ok: false, error: 'server_error' }); }
    }
    log({ ev: 'req', m: req.method, p: url.pathname, s: code, ms: Date.now() - t0 });
  });
  return { server, db, cfg, close: () => { clearInterval(purge); server.close(); try { db.close(); } catch { /* ya cerrada */ } } };
}

// Arranque directo: node server.mjs
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const cfg = loadConfig();
  if (!cfg.staticDir) cfg.staticDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../www');
  const app = createApp({ cfg });
  app.server.listen(cfg.port, () => console.log(`Papas server en ${cfg.publicBaseUrl} (puerto ${cfg.port}) · claves Premium: ${cfg.adminToken.length >= 24 ? 'admin activo' : 'ADMIN_TOKEN no configurado (no podrás generar claves)'}`));
}
