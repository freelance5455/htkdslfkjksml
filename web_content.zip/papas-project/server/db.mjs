// db.mjs — SQLite (módulo integrado de Node 22: node:sqlite). Sin dependencias externas.
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS accounts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  pass_salt TEXT NOT NULL, pass_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  premium_until INTEGER, premium_perm INTEGER NOT NULL DEFAULT 0,
  last_seq INTEGER NOT NULL DEFAULT 0, last_progress_at INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS sessions(
  token_hash TEXT PRIMARY KEY, account_id INTEGER NOT NULL REFERENCES accounts(id),
  created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS pass_progress(
  account_id INTEGER NOT NULL, season TEXT NOT NULL, xp INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(account_id, season));
CREATE TABLE IF NOT EXISTS xp_daily(
  account_id INTEGER NOT NULL, day INTEGER NOT NULL, xp INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(account_id, day));
CREATE TABLE IF NOT EXISTS pass_claims(
  account_id INTEGER NOT NULL, season TEXT NOT NULL, level INTEGER NOT NULL, track TEXT NOT NULL, claimed_at INTEGER NOT NULL,
  PRIMARY KEY(account_id, season, level, track));
CREATE TABLE IF NOT EXISTS daily_claims(
  account_id INTEGER NOT NULL, day INTEGER NOT NULL, claimed_at INTEGER NOT NULL, amount INTEGER NOT NULL,
  PRIMARY KEY(account_id, day));
CREATE TABLE IF NOT EXISTS grants(
  id TEXT PRIMARY KEY, account_id INTEGER NOT NULL, amount INTEGER NOT NULL, reason TEXT NOT NULL,
  created_at INTEGER NOT NULL, acked_at INTEGER);
CREATE TABLE IF NOT EXISTS items(
  account_id INTEGER NOT NULL, item_id TEXT NOT NULL, acquired_at INTEGER NOT NULL,
  PRIMARY KEY(account_id, item_id));
CREATE TABLE IF NOT EXISTS premium_codes(
  id INTEGER PRIMARY KEY AUTOINCREMENT, hash TEXT NOT NULL UNIQUE, hint TEXT NOT NULL,
  days INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL,
  redeemed_at INTEGER, redeemed_by INTEGER, voided_at INTEGER);
CREATE TABLE IF NOT EXISTS audit(
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, account_id INTEGER, event TEXT NOT NULL, detail TEXT);
`;

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=3000;');
  db.exec(SCHEMA);
  return db;
}

/** Transacción atómica (BEGIN IMMEDIATE evita carreras entre reclamos simultáneos). */
export function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { db.exec('ROLLBACK'); throw e; }
}
