// Genera claves Premium desde la terminal (alternativa a la página /admin).
//   node scripts/make-codes.mjs [cantidad=1] [dias=30] [nota]      (DB_PATH igual que el servidor)
// Muestra las claves UNA sola vez; en la base de datos solo queda su hash.
import { openDb } from '../db.mjs';
import { makeCode, normCode, sha256 } from '../codes.mjs';
import { loadConfig } from '../game.mjs';
const cfg = loadConfig();
const count = Math.min(200, Math.max(1, parseInt(process.argv[2] ?? '1', 10) || 1));
const days = process.argv[3] === undefined ? cfg.premiumDays : Math.max(0, parseInt(process.argv[3], 10) || 0);
const note = (process.argv[4] || '').slice(0, 80);
const db = openDb(cfg.dbPath);
const ins = db.prepare('INSERT INTO premium_codes(hash,hint,days,note,created_at) VALUES(?,?,?,?,?)');
for (let i = 0; i < count; i++) { const c = makeCode(), n = normCode(c); ins.run(sha256(n), n.slice(-4), days, note, Date.now()); console.log(c); }
console.error(`\n${count} clave(s) · ${days ? days + ' días' : 'permanente'} · un solo uso.`);
