// codes.mjs — Claves de Premium de UN SOLO USO.
// La clave en texto plano solo existe cuando se genera (la ves una vez). En la base de datos solo se guarda su hash (SHA-256),
// así que ni una copia de la base de datos sirve para canjear claves.
import crypto from 'node:crypto';

export const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

// 30 símbolos sin letras/números confusos (sin I, L, O, U, 0, 1): 30^16 ≈ 4,3·10^23 combinaciones (~78 bits).
const ALPHA = 'ABCDEFGHJKMNPQRSTVWXYZ23456789';

/** Genera una clave aleatoria criptográficamente segura: PAPA-XXXX-XXXX-XXXX-XXXX */
export function makeCode() {
  let s = '';
  while (s.length < 16) for (const b of crypto.randomBytes(32)) { if (b < 240 && s.length < 16) s += ALPHA[b % 30]; } // 240 = 30·8 → sin sesgo
  return 'PAPA-' + s.match(/.{4}/g).join('-');
}

/** Acepta mayúsculas/minúsculas, espacios y guiones. Devuelve los 16 caracteres normalizados o null si no tiene forma de clave. */
export function normCode(input) {
  if (typeof input !== 'string' || input.length > 64) return null;
  let s = input.toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (s.length === 20 && s.startsWith('PAPA')) s = s.slice(4);
  return s.length === 16 && [...s].every((c) => ALPHA.includes(c)) ? s : null;
}
