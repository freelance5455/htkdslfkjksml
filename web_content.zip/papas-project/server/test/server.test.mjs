// Pruebas del backend. Ejecutar: npm test   (Node >= 22.13, sin instalar nada)
// Cubren: cuentas, claves Premium de un solo uso, página/API de admin, recompensa diaria, Pase de Batalla y protecciones.
import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server.mjs';
import { loadConfig, thr } from '../game.mjs';
import { makeCode, normCode, sha256 } from '../codes.mjs';
import { openDb } from '../db.mjs';

const ADMIN = 'token-admin-de-prueba-0123456789';
const ENV = { ADMIN_TOKEN: ADMIN, WHATSAPP_NUMBER: '+57 300 123 4567' };
const T0 = Date.UTC(2026, 10, 13, 15, 0, 0); // 13-nov-2026 10:00 hora Colombia

async function boot(extraEnv = {}) {
  const st = { T: T0 };
  const cfg = loadConfig({ ...ENV, ...extraEnv });
  const app = createApp({ cfg, db: openDb(':memory:'), now: () => st.T, log: () => {} });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;
  const call = async (method, path, body, token, headers = {}) => {
    const r = await globalThis.fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...headers }, body: body === undefined ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)) });
    return { status: r.status, ...(await r.json().catch(() => ({}))) };
  };
  let n = 0;
  const user = async (name = 'jugador' + ++n) => { const r = await call('POST', '/api/auth/register', { username: name, password: 'clave-segura-1', terms: true }); assert.equal(r.status, 200); return r.token; };
  const mkCode = async (over = {}) => { const r = await call('POST', '/api/admin/codes', { count: 1, ...over }, ADMIN); assert.equal(r.status, 200); return r.codes[0]; };
  const getPremium = async (token, over) => { const c = await mkCode(over); const r = await call('POST', '/api/premium/redeem', { code: c }, token); assert.equal(r.status, 200); return c; };
  return { st, app, call, user, mkCode, getPremium, base, close: () => app.close() };
}

test('claves: formato, normalización y aleatoriedad', () => {
  const c = makeCode();
  assert.match(c, /^PAPA(-[A-HJKMNP-TV-Z2-9]{4}){4}$/);
  assert.equal(new Set(Array.from({ length: 2000 }, makeCode)).size, 2000);
  const n = normCode(c); assert.equal(n.length, 16);
  assert.equal(normCode(c.toLowerCase()), n); assert.equal(normCode(' ' + c.replaceAll('-', ' ') + ' '), n); assert.equal(normCode(n), n);
  for (const bad of ['', 'abc', null, undefined, 123, 'PAPA-0000-0000-0000-0000', c + 'X', 'x'.repeat(100)]) assert.equal(normCode(bad), null);
});

test('cuentas: registro, login, validaciones y rutas protegidas', async () => {
  const s = await boot();
  assert.equal((await s.call('GET', '/api/me')).status, 401);
  assert.equal((await s.call('GET', '/api/me', undefined, 'x'.repeat(43))).status, 401);
  assert.equal((await s.call('POST', '/api/auth/register', { username: 'a', password: 'clave-segura-1' })).error, 'bad_username');
  assert.equal((await s.call('POST', '/api/auth/register', { username: 'jair_1', password: '123' })).error, 'bad_password');
  const t = (await s.call('POST', '/api/auth/register', { username: 'Jair_1', password: 'clave-segura-1', terms: true })).token;
  assert.equal((await s.call('POST', '/api/auth/register', { username: 'jair_1', password: 'otra-clave-123', terms: true })).error, 'username_taken');
  assert.equal((await s.call('POST', '/api/auth/register', { username: 'sin_terminos', password: 'clave-segura-1' })).error, 'terms_required');
  assert.equal((await s.call('POST', '/api/auth/login', { username: 'jair_1', password: 'mala-clave-123' })).status, 401);
  assert.equal((await s.call('POST', '/api/auth/login', { username: 'nadie_x', password: 'clave-segura-1' })).status, 401);
  const l = await s.call('POST', '/api/auth/login', { username: 'JAIR_1', password: 'clave-segura-1' });
  const me = await s.call('GET', '/api/me', undefined, l.token);
  assert.equal(me.profile.user.username, 'Jair_1'); assert.equal(me.profile.premium.active, false); assert.equal(me.profile.perks, null);
  await s.call('POST', '/api/auth/logout', {}, t);
  assert.equal((await s.call('GET', '/api/me', undefined, t)).status, 401);
  s.close();
});

test('el cliente NO puede darse Premium ni reclamar sin una clave válida', async () => {
  const s = await boot(); const t = await s.user();
  assert.equal((await s.call('POST', '/api/daily/claim', {}, t)).error, 'premium_required');
  assert.equal((await s.call('POST', '/api/pass/claim', { level: 1, track: 'premium' }, t)).status, 403);
  // intentos de falsificar estado desde el navegador
  await s.call('POST', '/api/me', { premium: true }, t);
  await s.call('POST', '/api/premium/redeem', { code: 'PAPA-AAAA-AAAA-AAAA-AAAA', premium: true, days: 9999 }, t);
  await s.call('POST', '/api/pass/progress', { seq: 1, premium: true, premiumUntil: 9e15 }, t);
  assert.equal((await s.call('GET', '/api/me', undefined, t)).profile.premium.active, false);
  s.close();
});

test('canje: una clave activa Premium UNA sola vez (aunque la use otra cuenta o la misma)', async () => {
  const s = await boot(); const a = await s.user('ana'), b = await s.user('beto');
  const code = await s.mkCode();
  assert.equal((await s.call('POST', '/api/premium/redeem', { code })).status, 401);                    // sin sesión
  const r = await s.call('POST', '/api/premium/redeem', { code: code.toLowerCase().replaceAll('-', ' ') }, a);   // tolera minúsculas/espacios
  assert.equal(r.status, 200); assert.equal(r.profile.premium.active, true);
  assert.equal(r.profile.premium.until, T0 + 30 * 86400e3); assert.ok(r.profile.perks && r.profile.perks.tap === 1);
  assert.equal((await s.call('POST', '/api/premium/redeem', { code }, b)).error, 'code_used');          // otra cuenta: no
  assert.equal((await s.call('POST', '/api/premium/redeem', { code }, a)).error, 'code_used');          // la misma: no suma de nuevo
  assert.equal((await s.call('GET', '/api/me', undefined, b)).profile.premium.active, false);
  assert.equal((await s.call('GET', '/api/me', undefined, a)).profile.premium.until, T0 + 30 * 86400e3);
  s.close();
});

test('canje: claves inventadas, mal formadas o anuladas no funcionan; 10 canjes a la vez → solo 1', async () => {
  const s = await boot(); const t = await s.user();
  assert.equal((await s.call('POST', '/api/premium/redeem', { code: 'PAPA-KKKK-KKKK-KKKK-KKKK' }, t)).error, 'invalid_code');   // con forma de clave pero no existe
  assert.equal((await s.call('POST', '/api/premium/redeem', { code: 'hola' }, t)).error, 'invalid_code');
  assert.equal((await s.call('POST', '/api/premium/redeem', {}, t)).error, 'invalid_code');
  const v = await s.mkCode(); const list = (await s.call('GET', '/api/admin/codes', undefined, ADMIN)).codes;
  assert.equal((await s.call('POST', '/api/admin/codes/void', { id: list[0].id }, ADMIN)).status, 200);
  assert.equal((await s.call('POST', '/api/premium/redeem', { code: v }, t)).error, 'invalid_code');            // anulada
  const code = await s.mkCode(); const users = await Promise.all(Array.from({ length: 10 }, (_, i) => s.user('carrera' + i)));
  const race = await Promise.all(users.map((u) => s.call('POST', '/api/premium/redeem', { code }, u)));
  assert.equal(race.filter((r) => r.status === 200).length, 1);
  assert.equal(race.filter((r) => r.error === 'code_used').length, 9);
  s.close();
});

test('canje: límite de intentos para no adivinar claves', async () => {
  const s = await boot(); const t = await s.user(); let last;
  for (let i = 0; i < 12; i++) last = await s.call('POST', '/api/premium/redeem', { code: makeCode() }, t);
  assert.equal(last.status, 429);
  s.close();
});

test('claves: duración por clave, permanente (0) y renovar suma días; vence a su tiempo', async () => {
  const s = await boot(); const t = await s.user();
  await s.getPremium(t, { days: 10 });
  assert.equal((await s.call('GET', '/api/me', undefined, t)).profile.premium.until, T0 + 10 * 86400e3);
  await s.getPremium(t, { days: 5 });                                                       // suma, no reemplaza
  assert.equal((await s.call('GET', '/api/me', undefined, t)).profile.premium.until, T0 + 15 * 86400e3);
  s.st.T = T0 + 16 * 86400e3;
  const me = (await s.call('GET', '/api/me', undefined, t)).profile;
  assert.equal(me.premium.active, false); assert.equal(me.perks, null);
  assert.equal((await s.call('POST', '/api/daily/claim', {}, t)).error, 'premium_required');
  await s.getPremium(t, { days: 0 });
  const p = (await s.call('GET', '/api/me', undefined, t)).profile.premium; assert.equal(p.active, true); assert.equal(p.permanent, true);
  s.st.T += 4000 * 86400e3;                                                                  // la sesión (30 días) vence, pero el Premium permanente sigue
  const t2 = (await s.call('POST', '/api/auth/login', { username: 'jugador1', password: 'clave-segura-1' })).token;
  assert.equal((await s.call('GET', '/api/me', undefined, t2)).profile.premium.active, true);
  s.close();
});

test('admin: solo con ADMIN_TOKEN; las claves se guardan con hash, nunca en texto plano', async () => {
  const s = await boot();
  assert.equal((await s.call('POST', '/api/admin/codes', { count: 1 })).status, 401);
  assert.equal((await s.call('POST', '/api/admin/codes', { count: 1 }, 'otro-token')).status, 401);
  assert.equal((await s.call('GET', '/api/admin/codes', undefined, await s.user())).status, 401);       // un jugador con sesión NO es admin
  const r = await s.call('POST', '/api/admin/codes', { count: 3, days: 7, note: 'Juan - Nequi' }, ADMIN);
  assert.equal(r.codes.length, 3); assert.equal(r.days, 7);
  assert.equal((await s.call('POST', '/api/admin/codes', { count: 999 }, ADMIN)).codes.length, 50);      // máximo 50 por vez
  const rows = s.app.db.prepare('SELECT * FROM premium_codes').all();
  const dump = JSON.stringify(rows);
  for (const c of r.codes) { assert.ok(!dump.includes(c) && !dump.includes(normCode(c))); assert.ok(rows.some((x) => x.hash === sha256(normCode(c)))); }
  const l = (await s.call('GET', '/api/admin/codes', undefined, ADMIN)).codes;
  assert.ok(l.every((c) => c.hint.length === 4) && !JSON.stringify(l).includes(r.codes[0]));
  assert.equal(l.find((c) => c.note === 'Juan - Nequi').redeemed_by, null);
  s.close();
  const off = await boot({ ADMIN_TOKEN: 'corto' });                                                      // token débil = admin apagado
  assert.equal((await off.call('POST', '/api/admin/codes', { count: 1 }, 'corto')).error, 'admin_disabled');
  off.close();
});

test('admin: tras 10 contraseñas incorrectas se bloquea (incluso con la correcta)', async () => {
  const s = await boot(); let r;
  for (let i = 0; i < 10; i++) r = await s.call('GET', '/api/admin/codes', undefined, 'mal-' + i);
  assert.equal(r.status, 401);
  assert.equal((await s.call('GET', '/api/admin/codes', undefined, ADMIN)).status, 429);
  s.st.T += 16 * 60e3; assert.equal((await s.call('GET', '/api/admin/codes', undefined, ADMIN)).status, 200);
  s.close();
});

test('la página /admin existe, sin caché y con política de seguridad; no se sirve desde www', async () => {
  const s = await boot(); const r = await globalThis.fetch(s.base + '/admin');
  assert.equal(r.status, 200); assert.match(r.headers.get('content-security-policy'), /default-src 'none'/); assert.equal(r.headers.get('cache-control'), 'no-store');
  assert.match(await r.text(), /Claves Premium/);
  assert.equal((await globalThis.fetch(s.base + '/admin.html')).status, 404);
  s.close();
});

test('recompensa diaria: una vez por día de Colombia, con reloj del servidor y entrega única', async () => {
  const s = await boot(); const t = await s.user(); await s.getPremium(t, { days: 0 });
  const c1 = await s.call('POST', '/api/daily/claim', {}, t);
  assert.equal(c1.grant.amount, 1_000_000); assert.equal(c1.profile.daily.available, false); assert.equal(c1.profile.daily.lastAt, T0);
  const again = await s.call('POST', '/api/daily/claim', {}, t);
  assert.equal(again.status, 409); assert.equal(again.nextAt, Date.UTC(2026, 10, 14, 5, 0, 0));   // medianoche de Colombia
  s.st.T = Date.UTC(2026, 10, 14, 5, 0, 0);                                                         // 00:00 del día siguiente (hora Colombia)
  const race = await Promise.all(Array.from({ length: 10 }, () => s.call('POST', '/api/daily/claim', {}, t)));
  assert.equal(race.filter((r) => r.status === 200).length, 1);
  s.st.T = Date.UTC(2026, 10, 15, 4, 59, 59); assert.equal((await s.call('POST', '/api/daily/claim', {}, t)).status, 409);
  s.st.T = Date.UTC(2026, 10, 15, 5, 0, 0); assert.equal((await s.call('POST', '/api/daily/claim', {}, t)).status, 200);
  let me = (await s.call('GET', '/api/me', undefined, t)).profile;
  assert.equal(me.grants.length, 3); assert.ok(me.grants.every((g) => g.amount === 1_000_000));
  await s.call('POST', '/api/wallet/ack', { ids: [me.grants[0].id, me.grants[0].id, 'g_ajeno'] }, t);
  me = (await s.call('GET', '/api/me', undefined, t)).profile; assert.equal(me.grants.length, 2);
  const o = await s.user(); await s.call('POST', '/api/wallet/ack', { ids: me.grants.map((g) => g.id) }, o);   // grants de otra cuenta: no se pueden confirmar
  assert.equal((await s.call('GET', '/api/me', undefined, t)).profile.grants.length, 2);
  s.close();
});

test('Pase: XP validado por el servidor (secuencia, frecuencia, topes) y recompensas únicas', async () => {
  const s = await boot(); const t = await s.user();
  const prog = (seq, p = {}) => s.call('POST', '/api/pass/progress', { seq, packs: 0, orders: 0, trips: 0, ...p }, t);
  let r = await prog(1, { packs: 50, orders: 1, trips: 2 }); assert.equal(r.status, 200); assert.equal(r.gained, 50 + 20 + 10);
  assert.equal((await prog(1, { packs: 50 })).error, 'stale_seq');
  assert.equal((await prog(2, { packs: 50 })).error, 'too_fast');
  s.st.T += 11_000;
  r = await prog(2, { packs: 999999, orders: 999999, trips: 999999 });
  assert.equal(r.capped, true); assert.equal(r.profile.pass.dailyXp, 1000);
  assert.equal(r.profile.pass.xp, 1000); assert.equal(r.profile.pass.level, 7);   // thr(7)=980 ≤ 1000 < thr(8)=1200
  s.st.T += 11_000; r = await prog(3, { packs: 100 }); assert.equal(r.gained, 0);
  s.st.T += 86400e3; r = await prog(4, { packs: 100 }); assert.equal(r.gained, 100);
  s.close();
});

test('Pase: reclamar niveles (nivel alcanzado, una sola vez, pista premium solo con Premium)', async () => {
  const s = await boot(); const t = await s.user();
  const claim = (level, track = 'free') => s.call('POST', '/api/pass/claim', { level, track }, t);
  assert.equal((await claim(1)).error, 'level_locked');
  await s.call('POST', '/api/pass/progress', { seq: 1, packs: 400, orders: 0, trips: 0 }, t);   // 400 XP → nivel 3
  assert.equal((await s.call('GET', '/api/me', undefined, t)).profile.pass.level, 3);
  assert.equal((await claim(4)).error, 'level_locked');
  const c = await claim(3); assert.equal(c.status, 200); assert.equal(c.grant.amount, 10000);       // 5000 + 2500*(3-1)
  assert.equal((await claim(3)).error, 'already_claimed');
  assert.equal((await claim(3, 'premium')).error, 'premium_required');
  assert.equal((await claim(0)).error, 'bad_request'); assert.equal((await claim(99)).error, 'bad_request'); assert.equal((await claim(1, 'vip')).error, 'bad_request');
  await s.getPremium(t);
  const p = await claim(3, 'premium'); assert.equal(p.status, 200); assert.equal(p.grant.amount, 25000);   // 15000 + 5000*2
  assert.equal((await claim(3, 'premium')).error, 'already_claimed');
  const race = await Promise.all(Array.from({ length: 30 }, () => claim(1)));
  assert.equal(race.filter((r) => r.status === 200).length, 1);
  s.st.T += 11_000; await s.call('POST', '/api/pass/progress', { seq: 2, packs: 400, orders: 40, trips: 0 }, t);
  assert.ok(thr(5) <= 1000);
  const c5 = await claim(5, 'premium'); assert.equal(c5.reward.item, 'p5');
  assert.ok((await s.call('GET', '/api/me', undefined, t)).profile.items.includes('p5'));
  s.close();
});

test('configuración pública: precio, premios y WhatsApp; nunca secretos', async () => {
  const s = await boot(); const cfg = await s.call('GET', '/api/config');
  assert.equal(cfg.price.cop, 4000); assert.equal(cfg.dailyMoney, 1_000_000); assert.equal(cfg.levels.length, 30);
  assert.equal(cfg.whatsapp.number, '573001234567');                                    // se limpia: solo dígitos
  assert.ok(cfg.whatsapp.message.includes('{usuario}'));
  assert.ok(!JSON.stringify(cfg).includes(ADMIN));
  s.close();
  const s2 = await boot({ WHATSAPP_NUMBER: '' }); assert.equal((await s2.call('GET', '/api/config')).whatsapp, null); s2.close();
});

test('protecciones: límite de intentos de login, cuerpo grande, JSON inválido, CORS y rutas inexistentes', async () => {
  const s = await boot({ ALLOWED_ORIGINS: 'https://localhost' }); await s.user('victima');
  let last; for (let i = 0; i < 10; i++) last = await s.call('POST', '/api/auth/login', { username: 'victima', password: 'adivinando-' + i });
  assert.equal(last.status, 429);
  assert.equal((await s.call('POST', '/api/auth/register', 'x'.repeat(20000))).status, 413);
  assert.equal((await s.call('POST', '/api/auth/register', '{no es json')).error, 'bad_json');
  assert.equal((await s.call('GET', '/api/no-existe')).status, 404);
  assert.equal((await s.call('POST', '/api/checkout', { provider: 'wompi' })).status, 404);          // ya no existe ninguna ruta de pagos
  const ok = await globalThis.fetch(`${s.base}/api/health`, { headers: { Origin: 'https://localhost' } });
  assert.equal(ok.headers.get('access-control-allow-origin'), 'https://localhost');
  const bad = await globalThis.fetch(`${s.base}/api/health`, { headers: { Origin: 'https://malo.example' } });
  assert.equal(bad.headers.get('access-control-allow-origin'), null);
  s.close();
});

test('borrar cuenta: pide contraseña, borra todo, la clave sigue gastada y las páginas legales existen', async () => {
  const s = await boot(); const t = await s.user('borrame'); const code = await s.getPremium(t);
  assert.equal((await s.call('POST', '/api/account/delete', { password: 'incorrecta-123' }, t)).error, 'bad_credentials');
  assert.equal((await s.call('GET', '/api/me', undefined, t)).profile.premium.active, true);          // nada se borró con la clave mala
  assert.equal((await s.call('POST', '/api/account/delete', {}, undefined)).status, 401);
  assert.equal((await s.call('POST', '/api/account/delete', { password: 'clave-segura-1' }, t)).status, 200);
  assert.equal((await s.call('GET', '/api/me', undefined, t)).status, 401);                            // la sesión ya no existe
  assert.equal((await s.call('POST', '/api/auth/login', { username: 'borrame', password: 'clave-segura-1' })).error, 'bad_credentials');
  const t2 = await s.user('borrame');                                                                  // el nombre queda libre; la cuenta nueva NO hereda Premium
  assert.equal((await s.call('GET', '/api/me', undefined, t2)).profile.premium.active, false);
  assert.equal((await s.call('POST', '/api/premium/redeem', { code }, t2)).error, 'code_used');       // borrar la cuenta no revive la clave
  for (const p of ['/privacidad', '/borrar-cuenta', '/admin']) { const r = await globalThis.fetch(s.base + p); assert.equal(r.status, 200); assert.match(r.headers.get('content-security-policy'), /default-src 'none'/); }
  s.close();
});
