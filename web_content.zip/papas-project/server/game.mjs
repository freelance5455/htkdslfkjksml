// game.mjs — Reglas del Pase de Batalla, Premium y recompensas.
// TODO lo que está aquí lo decide el SERVIDOR; el juego (cliente) solo lo muestra.
// Para cambiar recompensas, XP, precios o perks edita este archivo y reinicia el servidor.

/** Lee la configuración desde variables de entorno (ver .env.example). */
export function loadConfig(env = process.env) {
  const n = (k, d) => (env[k] !== undefined && env[k] !== '' ? Number(env[k]) : d);
  return {
    port: n('PORT', 8787),
    dbPath: env.DB_PATH || './data/papas.db',
    staticDir: env.STATIC_DIR || '',
    publicBaseUrl: (env.PUBLIC_BASE_URL || 'http://localhost:8787').replace(/\/$/, ''),
    allowedOrigins: (env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
    trustProxy: env.TRUST_PROXY === '1',
    // --- Premium ---
    priceCop: n('PREMIUM_PRICE_COP', 4000),      // solo informativo: el cobro lo haces tú por WhatsApp
    premiumDays: n('PREMIUM_DAYS', 30),          // días por defecto de cada clave; 0 = permanente
    dailyMoney: n('PREMIUM_DAILY_MONEY', 1_000_000), // DINERO VIRTUAL diario (no es dinero real)
    // --- Pase de Batalla ---
    seasonId: env.SEASON_ID || 'S1',
    seasonName: env.SEASON_NAME || 'Temporada 1: Papa Limón',
    maxLevel: 30,
    dailyXpCap: n('DAILY_XP_CAP', 1000),
    // --- Venta manual por WhatsApp + clave de un solo uso ---
    adminToken: env.ADMIN_TOKEN || '',                       // contraseña de la página /admin (mínimo 24 caracteres)
    whatsappNumber: (env.WHATSAPP_NUMBER || '').replace(/\D/g, ''),   // ej: 573001234567 (código de país + número, sin + ni espacios)
    whatsappMessage: env.WHATSAPP_MESSAGE || 'Hola, quiero el Pase Premium de Las Papas de Rincón ({precio}). Mi usuario en el juego es: {usuario}',
  };
}

/** Beneficios Premium que el cliente aplica mientras el servidor diga que Premium está activo. */
export const PERKS = {
  tap: 1,        // AGILIDAD: +1 de fuerza por toque (pelar, cortar, empacar)
  cook: 0.15,    // RAPIDEZ: cocción 15% más rápida
  trip: 0.2,     // RAPIDEZ: el camión tarda 20% menos
  workers: 0.1,  // RAPIDEZ: trabajadores 10% más rápidos
};

/** Objetos coleccionables (insignias/títulos). El 👑 PREMIUM no es un objeto: se muestra mientras Premium esté activo. */
export const ITEMS = {
  f5: { name: 'Gorra papera', icon: '🧢' }, f10: { name: 'Pin de limón', icon: '🍋' },
  f15: { name: 'Papa de bronce', icon: '🥉' }, f20: { name: 'Papa de plata', icon: '🥈' },
  f25: { name: 'Medalla crujiente', icon: '🏅' }, f30: { name: 'Trofeo papero', icon: '🏆' },
  p5: { name: 'Estela dorada', icon: '✨' }, p10: { name: 'Sombrero de lujo', icon: '🎩' },
  p15: { name: 'Papa de diamante', icon: '💎' }, p20: { name: 'Camión dorado', icon: '🚚' },
  p25: { name: 'Título: Maestro Limonero', icon: '⭐' }, p30: { name: 'Corona Parchadita', icon: '👑' },
};

/** XP total necesario para alcanzar el nivel k (nivel 1 = 80 XP, cada nivel cuesta 20 XP más que el anterior). */
export const thr = (k) => 10 * k * k + 70 * k;
export const levelOf = (xp, max) => { let l = 0; while (l < max && xp >= thr(l + 1)) l++; return l; };

/** Recompensa de un nivel: { money, item } para la pista 'free' o 'premium'. */
export function rewardFor(track, k) {
  if (track === 'free') return { money: 5000 + 2500 * (k - 1), item: k % 5 === 0 ? 'f' + k : null };
  return { money: 15000 + 5000 * (k - 1), item: k % 5 === 0 ? 'p' + k : null };
}
export const passLevels = (max) => Array.from({ length: max }, (_, i) => {
  const k = i + 1;
  return { level: k, xp: thr(k), free: rewardFor('free', k), premium: rewardFor('premium', k) };
});

/** Reglas de XP (el cliente reporta cuánto jugó; el servidor limita y decide). */
export const XP = { pack: 1, order: 20, trip: 5, maxPerSync: { packs: 400, orders: 40, trips: 40 }, minSyncMs: 10_000 };

/** "Día" para el reclamo diario: calendario de Colombia (UTC-5, sin horario de verano), con el reloj del SERVIDOR. */
const TZ = -5 * 3600e3, DAY = 86400e3;
export const dayKey = (nowMs) => Math.floor((nowMs + TZ) / DAY);
export const nextDayAt = (day) => (day + 1) * DAY - TZ;
