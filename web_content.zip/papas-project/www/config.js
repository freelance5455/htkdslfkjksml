// config.js — Ajustes del juego que NO son secretos. Se carga antes del juego (index.html).
// Edita este archivo (no el index.html) cuando cambies de servidor.
window.GAME_CONFIG = {
  // URL del servidor del Pase/Premium, SIN "/" al final. Ejemplos:
  //   ''                              -> el juego y el servidor están en el mismo sitio (modo web / pruebas locales)
  //   'https://tu-servidor.onrender.com'  -> OBLIGATORIO para el APK (dentro del APK no hay servidor propio)
  API_BASE: '',
  // WhatsApp de ventas (código de país + número, solo dígitos). Se usa si el servidor no lo envía.
  WHATSAPP_NUMBER: '573148078630',
  // false = oculta el botón "Comprar por WhatsApp" (úsalo si publicas en Google Play: ver docs/ANDROID.md)
  SHOW_BUY: true,
  // Opcional: tus propias páginas legales. Si se dejan vacías se usa API_BASE + '/privacidad'.
  PRIVACY_URL: ''
};
