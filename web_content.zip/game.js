"use strict";
/* As Ilhas de Auralis — jogo de plataforma 2D em HTML5.
   Código original. Arte e sons reaproveitados dos projetos recebidos (ver CREDITOS.md). */
const TS = 32, VW = 448, VH = 256, SC = 2;
const cv = document.getElementById("c"), ctx = cv.getContext("2d");
ctx.imageSmoothingEnabled = false;
const TEST = /[?&]test=1/.test(location.search);

/* ---------------- recursos ---------------- */
const IMG = {}, SND = {};
const IMGS = ["tm_forest","tm_cave","tm_temple","bg_forest_0","bg_forest_1","bg_forest_2","bg_forest_4","bg_cave_0","bg_cave_1",
  "bg_temple_0","bg_temple_1","bg_temple_2","bg_titlescreen","stalactite","spring-0","door","spikes","cannon","cball"];
const ANIMS = {"player_mask-idle":2,"player_mask-run":6,"player_mask-jump":1,"en_beetle-walk":4,"en_hedgehog-walk":4,"en_acorn":4,"spring-boing":4,
  "torch":4,"mara-idle":4,"mara-lift":3,"marco":6,"boulder":8,"boss-default":1,"boss-charge":2,"boss-shoot":1,"orb":4,"pipa":3};
for (const [k,n] of Object.entries(ANIMS)) for (let i=0;i<n;i++) IMGS.push(k+"-"+i);
const SFX = ["Cannon","Boulder","Collectible_1","Collectible_2","Kiwi_Jump","Kiwi_Hurt","Enemy_Death","Enemy_Hurt","Spring","Menu_Move","Menu_Select","Door_Enter","Stalactite","Reflect","Splash"];
const MUS = ["Kiwi_Forest","Kiwi_Cave","Kiwi_Temple","Kiwi_TitleMaybe","Kiwi_LevelComplete","Kiwi_Credits","Kiwi_Death"];
let loaded = 0; const total = IMGS.length;
for (const n of IMGS) { const im = new Image(); im.onload = im.onerror = () => loaded++; im.src = "assets/img/" + n + ".png"; IMG[n] = im; }
// Peças extras (slash da espada, poeira de pouso/pulo) — não bloqueiam o loading
const EXTRA_IMGS = [];
for (let i = 0; i < 6; i++) EXTRA_IMGS.push("swordslash-default-00" + i);
for (let i = 0; i < 11; i++) {
  const id = i < 10 ? "0" + i : String(i);
  EXTRA_IMGS.push("landingdust-default-0" + id);
  EXTRA_IMGS.push("jumpingdust-default-0" + id);
}
for (let i = 0; i < 4; i++) EXTRA_IMGS.push("playergraphics-idle-00" + i);
for (let i = 0; i < 8; i++) EXTRA_IMGS.push("playergraphics-walk-00" + i);
EXTRA_IMGS.push("playergraphics-jump-000", "playergraphics-fall-000", "playergraphics-attack-000");
for (let i = 0; i < 7; i++) EXTRA_IMGS.push("j2_playeranimations-idle-00" + i);
for (let i = 0; i < 6; i++) EXTRA_IMGS.push("j2_playeranimations-walk-00" + i);
for (let i = 0; i < 5; i++) EXTRA_IMGS.push("j2_bubble-burst-00" + i);
EXTRA_IMGS.push("j2_bubble-float-000", "j2_fireflies", "j2_fog", "j2_watersplash");
for (const n of EXTRA_IMGS) {
  const im = new Image();
  im.src = "assets/img/extra/" + n + ".png";
  IMG[n] = im;
}
/* Personagens: afinidade + poder permanente de estilo.
   Desbloqueio de Brisa/Aural após terminar a campanha 1x (ou ?chars=1). */
const CHARACTERS = {
  kiwi:  { id:"kiwi",  nome:"Nilo",  afinidade:"Lâmina", desc:"Espada e stomp. Equilíbrio.", unlock:"always", difficulty:1.0,  attack:"sword", scale:1,    draw:"kiwi" },
  brisa: { id:"brisa", nome:"Brisa", afinidade:"Vento",  desc:"Mais velocidade e pulo duplo. Jogo um pouco mais denso.", unlock:"finished", difficulty:1.12, attack:"sword", scale:0.55, draw:"brisa" },
  aural: { id:"aural", nome:"Aural", afinidade:"Magia",  desc:"Orbes mágicos à distância. Menos vida, mais alcance.", unlock:"finished", difficulty:1.18, attack:"magic", scale:0.32, draw:"aural" }
};
function anySlotFinished() {
  try { if (localStorage.getItem("auralis_campaign_done") === "1") return true; } catch (e) {}
  if (/[?&]chars=1/.test(location.search)) return true;
  for (let i = 0; i < 3; i++) {
    try {
      const raw = localStorage.getItem("auralis_slot_" + i);
      if (raw && JSON.parse(raw).finished) return true;
    } catch (e) {}
  }
  return false;
}
function isCharUnlocked(id) {
  const c = CHARACTERS[id];
  return !!c && (c.unlock === "always" || anySlotFinished());
}
for (const n of SFX) { const a = new Audio("assets/snd/" + n + ".webm"); a.preload = "auto"; SND[n] = a; }
const MUSIC = {}; for (const n of MUS) { const a = new Audio("assets/mus/" + n + ".webm"); a.preload = "auto"; MUSIC[n] = a; }
let muted = false, audioOn = false, curMusic = null;
let storageOk = true, menuLock = 0;
try { muted = localStorage.getItem("auralis_mute") === "1"; } catch(e){ storageOk = false; }
function setMuted(v) { muted = v; try { localStorage.setItem("auralis_mute", v ? "1" : "0"); storageOk = true; } catch(e){ storageOk = false; } if (curMusic && MUSIC[curMusic]) { if (muted) MUSIC[curMusic].pause(); else MUSIC[curMusic].play().catch(()=>{}); } }
/* Save helpers — validação mínima para evitar save corrompido/forjado absurdo */
const SWORD_OK = new Set(["madeira","bronze","ferro","ouro","diamante","herdeira"]);
const POWER_OK = new Set(["wing","shield","boots","magnet"]);
function clampInt(v, lo, hi, fallback) {
  const n = Number(v);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(lo, Math.min(hi, Math.floor(n)));
}
let activeSlot = 0;
try {
  const as = parseInt(localStorage.getItem("auralis_active_slot") || "0", 10);
  activeSlot = (as >= 0 && as <= 2) ? as : 0;
} catch (e) { activeSlot = 0; }

function sanitizeSave(raw) {
  if (!raw || typeof raw !== "object") return null;
  const level = clampInt(raw.level, 0, Math.max(0, (typeof LEVELS !== "undefined" ? LEVELS.length : 200) - 1), 0);
  const coins = clampInt(raw.coins, 0, 99999, 0);
  const sword = SWORD_OK.has(raw.sword) ? raw.sword : "madeira";
  let swordRank = clampInt(raw.swordRank, 0, 5, 0);
  if (sword === "herdeira") swordRank = 5;
  else if (sword === "diamante") swordRank = Math.max(swordRank, 4);
  else if (sword === "ouro") swordRank = Math.max(swordRank, 3);
  else if (sword === "ferro") swordRank = Math.max(swordRank, 2);
  else if (sword === "bronze") swordRank = Math.max(swordRank, 1);
  const powers = Array.isArray(raw.powers) ? raw.powers.filter(p => POWER_OK.has(p)).slice(0, 4) : [];
  const difficultyMod = Math.max(1, Math.min(2, Number(raw.difficultyMod) || 1));
  const secretFound = !!raw.secretFound && sword === "herdeira";
  const maxLvl = (typeof LEVELS !== "undefined" ? LEVELS.length : 200);
  const percent = Math.max(0, Math.min(100, Math.round(((level + (raw.finished ? 1 : 0)) / maxLvl) * 100)));
  const savedAt = typeof raw.savedAt === "number" ? raw.savedAt : (raw.savedAt ? Date.parse(raw.savedAt) : 0);
  const character = CHARACTERS[raw.character] ? raw.character : "kiwi";
  return {
    version: 5, level, coins, sword, swordRank, powers, secretFound, difficultyMod,
    maxUnlocked: clampInt(raw.maxUnlocked, 0, 200, level + 1),
    totalFrags: clampInt(raw.totalFrags, 0, 99999, 0),
    percent, savedAt: Number.isFinite(savedAt) ? savedAt : 0,
    playTime: clampInt(raw.playTime, 0, 99999999, 0),
    finished: !!raw.finished,
    character
  };
}
function slotKey(i) { return "auralis_slot_" + i; }
function formatSaveTime(ts) {
  if (!ts) return "—";
  try {
    const d = new Date(ts);
    const pad = n => (n < 10 ? "0" : "") + n;
    return pad(d.getDate()) + "/" + pad(d.getMonth() + 1) + "/" + d.getFullYear() + " " + pad(d.getHours()) + ":" + pad(d.getMinutes());
  } catch (e) { return "—"; }
}
function readSlot(i) {
  try {
    const raw = localStorage.getItem(slotKey(i));
    if (!raw) return null;
    return sanitizeSave(JSON.parse(raw));
  } catch (e) { return null; }
}
function writeSlot(i, data) {
  try {
    localStorage.setItem(slotKey(i), JSON.stringify(data));
    storageOk = true;
    return true;
  } catch (e) {
    storageOk = false;
    return false;
  }
}
function clearSlot(i) {
  try { localStorage.removeItem(slotKey(i)); return true; } catch (e) { return false; }
}
/** Migra save antigo (1 slot) para o slot 0 uma vez. */
(function migrateLegacySave() {
  try {
    if (localStorage.getItem("auralis_slot_0") || localStorage.getItem("auralis_slot_1") || localStorage.getItem("auralis_slot_2")) return;
    const raw = localStorage.getItem("auralis_save");
    if (!raw) {
      const lvl = clampInt(localStorage.getItem("auralis_lvl"), 0, 199, 0);
      if (lvl > 0) writeSlot(0, sanitizeSave({ level: lvl, savedAt: Date.now() }));
      return;
    }
    const d = sanitizeSave(JSON.parse(raw));
    if (d) { d.savedAt = d.savedAt || Date.now(); writeSlot(0, d); }
  } catch (e) {}
})();
function writeSave(extra) {
  const data = sanitizeSave(Object.assign({
    level: S.lvl, coins: S.coins, sword: S.sword, swordRank: S.swordRank,
    powers: S.chosenPowers, secretFound: !!S.secretFound, difficultyMod: S.difficultyMod || 1,
    totalFrags: S.totalFrags, playTime: Math.floor((S.playTime || 0)),
    finished: !!S.finished, character: S.character || "kiwi"
  }, extra || {}, { savedAt: Date.now() }));
  if (!data) return false;
  data.percent = Math.max(0, Math.min(100, Math.round(((data.level + (data.finished ? 1 : 0)) / LEVELS.length) * 100)));
  const ok = writeSlot(activeSlot, data);
  if (!ok) {
    if (S) S.toast = { text: "Não foi possível salvar (armazenamento bloqueado).", t: 5, nome: "SAVE", desc: "Falhou", col: "#ff7a7a" };
    return false;
  }
  try {
    localStorage.setItem("auralis_active_slot", String(activeSlot));
    localStorage.setItem("auralis_lvl", String(data.level));
    localStorage.setItem("auralis_save", JSON.stringify(data));
  } catch (e) {}
  return true;
}
function readSave() { return readSlot(activeSlot); }
function applySaveToState(saveData) {
  if (!saveData) return;
  S.coins = saveData.coins;
  S.sword = saveData.sword;
  S.swordRank = saveData.swordRank;
  S.chosenPowers = saveData.powers.slice();
  S.permWing = saveData.powers.includes("wing");
  S.permShield = saveData.powers.includes("shield");
  S.permBoots = saveData.powers.includes("boots");
  S.difficultyMod = saveData.difficultyMod;
  S.secretFound = !!saveData.secretFound;
  if (saveData.secretFound) { S.sword = "herdeira"; S.swordRank = 5; }
  S.totalFrags = saveData.totalFrags || 0;
  S.playTime = saveData.playTime || 0;
  S.character = CHARACTERS[saveData.character] ? saveData.character : "kiwi";
  applyCharacterPassives();
}
function applyCharacterPassives() {
  const ch = CHARACTERS[S.character] || CHARACTERS.kiwi;
  S.charAttack = ch.attack;
  // passivas de personagem (somam com baú)
  if (ch.id === "brisa") {
    S.permBoots = true;
    S.permWing = true;
    S.difficultyMod = Math.max(S.difficultyMod || 1, ch.difficulty);
  } else if (ch.id === "aural") {
    S.maxHp = 3;
    S.hp = Math.min(S.hp, S.maxHp);
    S.difficultyMod = Math.max(S.difficultyMod || 1, ch.difficulty);
  } else {
    S.maxHp = S.maxHp || 4;
  }
}
function sfx(n, v = 0.55) { if (muted || !audioOn || !SND[n]) return; try { const c = SND[n].cloneNode(); c.volume = v; c.play().catch(()=>{}); } catch(e){} }
function music(n, loop = true) {
  if (curMusic && MUSIC[curMusic]) { MUSIC[curMusic].pause(); }
  curMusic = n; if (!n) return; const a = MUSIC[n]; a.loop = loop; a.volume = 0.35; a.currentTime = 0;
  if (!muted && audioOn) a.play().catch(()=>{});
}
let ac = null;
function note(freq, dur = 0.25, type = "triangle", vol = 0.12) {
  if (muted || !audioOn) return;
  try {
    ac = ac || new (window.AudioContext || window.webkitAudioContext)();
    const o = ac.createOscillator(), g = ac.createGain(); o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(vol, ac.currentTime); g.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + dur);
    o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + dur);
  } catch(e){}
}
const PENTA = [262,294,330,392,440,523,587,659,784,880];
function chirp() { note(1400,0.07,"square",0.04); setTimeout(()=>note(1900,0.09,"square",0.04),70); }

/* ---------------- entrada ---------------- */
const down = {}, pressed = {};
const MAP = {
  ArrowLeft:"left", KeyA:"left", ArrowRight:"right", KeyD:"right",
  ArrowUp:"up", KeyE:"up", ArrowDown:"down", KeyS:"down",
  KeyZ:"jump", Space:"jump", KeyK:"jump", KeyW:"jump",
  KeyX:"attack", KeyJ:"attack", KeyC:"attack",
  KeyQ:"power", KeyF:"power", KeyV:"power",
  Enter:"ok", Escape:"pause", KeyP:"pause", KeyM:"mute"
};
function press(k) { if (!down[k]) pressed[k] = true; down[k] = true; }
function release(k) { down[k] = false; }
addEventListener("keydown", e => { const k = MAP[e.code]; if (k) { e.preventDefault(); audioOn = true; press(k); } });
let secretBuffer = "";
/* Código montado em runtime (ainda client-side; evita string óbvia no grep) */
function secretExpected() {
  const p = ["AUR", "7K9", "ESPADA"];
  return p.join("-");
}
addEventListener("keyup", e => { const k = MAP[e.code]; if (k) release(k); });
addEventListener("keypress", e => {
  if (S.mode !== "play" || !L || !P) return;
  if (e.key.length === 1) {
    secretBuffer = (secretBuffer + e.key.toUpperCase()).slice(-20);
    if (secretBuffer.endsWith(secretExpected())) {
      S.secretFound = true;
      S.toast = { text: "CÓDIGO ACEITO — A HERDEIRA DESPERTOU!", t: 4, nome: "HERDEIRA", desc: "Desbloqueada", col: "#ffb7ff" };
      S.sword = "herdeira"; S.swordRank = 5;
      burst(P.x, P.y - 20, 24, "#ffb7ff", 180, 1); sfx("Collectible_2", 0.8);
      writeSave({ secretFound: true, sword: "herdeira", swordRank: 5 });
      secretBuffer = "";
    }
  }
});
function canvasXY(e) {
  const r = cv.getBoundingClientRect();
  if (!r.width || !r.height) return { x: 448, y: 256 };
  return {
    x: (e.clientX - r.left) * 896 / r.width,
    y: (e.clientY - r.top) * 512 / r.height
  };
}
function exitHelpCredits() {
  try { sfx("Menu_Select"); } catch (err) {}
  menuLock = 0.4;
  if (S._helpFromPause) {
    S._helpFromPause = false;
    S.mode = "play";
    openMenu("pause");
  } else {
    S.mode = "title";
    S.t = 0;
    music("Kiwi_TitleMaybe");
  }
}
/* Baú-sacrifício: não é aleatório nem a cada 25 fases.
   Ao acumular COIN_CHEST_NEED moedas desde o último baú, no PRÓXIMO nível surge um baú perto do fim.
   Sacrifica TODAS as moedas e escolhe 1 de 3 poderes (até o próximo sacrifício). */
const COIN_CHEST_NEED = 40;
const NEXT_SACRIFICE_POINTS = 3000;
const SACRIFICE_POWERS = [
  { id: "boots", nome: "BOTAS DE ÉTER", desc: "Impulso de velocidade por 1,2s.", strat: "Fuga e travessias rápidas.", diff: 1.15, col: "#ffd35a", cd: 3, duration: 1.2 },
  { id: "fury", nome: "FÚRIA DIVINA", desc: "Raios em inimigos próximos.", strat: "Limpa grupos no corpo a corpo.", diff: 1.2, col: "#ff7a4a", cd: 4, duration: 0.35 },
  { id: "sun", nome: "SOL CELESTIAL", desc: "Luz em linha reta por 3s.", strat: "Corredores longos e chefes.", diff: 1.25, col: "#ffe08a", cd: 4, duration: 3 },
  { id: "warwing", nome: "ASAS DE GUERRA", desc: "Plane por alguns segundos.", strat: "Quedas controladas e gaps longos.", diff: 1.18, col: "#c9b0ff", cd: 4, duration: 2.2 }
];
function playerPoints() {
  return (S.totalFrags || 0) * 50 + (S.coinsEarned || 0) * 10 + (S.lvl || 0) * 5;
}
function openSacrificeChest() {
  S.mode = "powerChoice";
  S.powerChoice = {
    sel: 0,
    stage: "cards", // cards → confirm → done
    cost: S.coins, // sacrifica tudo
    options: SACRIFICE_POWERS.map(p => p.nome),
    desc: SACRIFICE_POWERS.map(p => p.desc),
    strat: SACRIFICE_POWERS.map(p => p.strat),
    anim: 0
  };
  music(null);
  try { sfx("Collectible_2", 0.7); } catch (e) {}
}
function applySacrificePower(p) {
  S.chosenPowers = [p.id];
  S.activePower = p.id;
  S.activePowerName = p.nome;
  S.powerCd = 0;
  S.powerActive = 0;
  S.powerCdMax = p.cd || 4;
  S.difficultyMod = Math.max(1, p.diff * ((CHARACTERS[S.character] || {}).difficulty || 1));
  S.coins = 0;
  S.coinsTowardChest = 0;
  S.spawnChestNext = false;
  S.nextSacrificeAt = playerPoints() + NEXT_SACRIFICE_POINTS;
  S.chestConsumed = true;
  S.showPowerBtn = true;
}
function activatePower() {
  if (!S.activePower || !P || P.dead || S.mode !== "play") return;
  if ((S.powerCd || 0) > 0 || (S.powerActive || 0) > 0) return;
  const p = SACRIFICE_POWERS.find(x => x.id === S.activePower);
  if (!p) return;
  S.powerCd = p.cd;
  S.powerActive = p.duration;
  S.powerCdMax = p.cd;
  try { sfx("Collectible_2", 0.55); } catch (e) {}
  if (p.id === "boots") {
    P.vx = P.face * 320;
    P.pw.boots = Math.max(P.pw.boots || 0, p.duration);
    burst(P.x, P.y - 8, 10, "#ffd35a", 90, 0.4);
  } else if (p.id === "fury") {
    // raios em inimigos próximos
    let hits = 0;
    for (const e of ents) {
      if (e.alive === false || !["beetle","hedge","acorn"].includes(e.t)) continue;
      if (Math.hypot(e.px - P.x, e.py - P.y) < 110) {
        e.alive = false; hits++;
        burst(e.px, e.py - 8, 14, "#ff7a4a", 120, 0.5);
        S.coins += 1; S.coinsEarned = (S.coinsEarned || 0) + 1; S.coinsTowardChest = (S.coinsTowardChest || 0) + 1;
      }
    }
    if (boss && !boss.dead && Math.hypot(boss.x - P.x, boss.y - P.y) < 140) {
      if (boss.state === "vuln") {
        boss.hp -= 2; boss.flash = 0.3; sfx("Enemy_Hurt");
        if (boss.hp <= 0) { boss.dead = true; boss.dying = 0; }
      }
      burst(boss.x, boss.y - 40, 16, "#ff7a4a", 140, 0.5);
    }
    // efeito visual de raios
    for (let i = 0; i < 8; i++) {
      parts.push({
        x: P.x, y: P.y - 12, vx: (Math.random() - 0.5) * 200, vy: (Math.random() - 0.5) * 200,
        life: 0.35, max: 0.35, col: "#ffee88", size: 2 + Math.random() * 3, bolt: true
      });
    }
    if (hits) sfx("Enemy_Death");
  } else if (p.id === "sun") {
    // feixe de luz em linha reta (3s)
    S.sunBeam = {
      x: P.x + P.face * 16, y: P.y - 14,
      vx: P.face * 140, dir: P.face, life: 3, max: 3, w: 48, h: 14
    };
    burst(P.x + P.face * 20, P.y - 14, 8, "#ffe08a", 80, 0.4);
  } else if (p.id === "warwing") {
    P.glide = p.duration;
    P.vy = Math.min(P.vy, 40);
    burst(P.x, P.y - 16, 12, "#c9b0ff", 70, 0.45);
  }
}
function updatePowerEffects(dt) {
  if (S.powerCd > 0) S.powerCd = Math.max(0, S.powerCd - dt);
  if (S.powerActive > 0) S.powerActive = Math.max(0, S.powerActive - dt);
  if (P && P.glide > 0) {
    P.glide -= dt;
    // planar: gravidade reduzida e queda limitada
    if (P.vy > 50) P.vy = 50;
    if (P.vy > 0) P.vy *= 0.92;
  }
  // Sol Celestial
  if (S.sunBeam) {
    const b = S.sunBeam;
    b.x += b.vx * dt;
    b.life -= dt;
    // dano contínuo em inimigos na linha
    for (const e of ents) {
      if (e.alive === false || !["beetle","hedge","acorn"].includes(e.t)) continue;
      if (Math.abs(e.py - 8 - b.y) < 20 && Math.abs(e.px - b.x) < b.w / 2 + e.w / 2) {
        e.alive = false;
        sfx("Enemy_Death");
        burst(e.px, e.py - 8, 10, "#ffe08a", 90, 0.4);
        S.coins += 1; S.coinsEarned = (S.coinsEarned || 0) + 1; S.coinsTowardChest = (S.coinsTowardChest || 0) + 1;
      }
    }
    if (boss && !boss.dead && Math.abs(boss.y - 40 - b.y) < 40 && Math.abs(boss.x - b.x) < 40) {
      if (b._bossTick == null || b._bossTick <= 0) {
        b._bossTick = 0.35;
        if (boss.state === "vuln") {
          boss.hp -= 1; boss.flash = 0.2; sfx("Enemy_Hurt");
          if (boss.hp <= 0) { boss.dead = true; boss.dying = 0; }
        }
      }
    }
    if (b._bossTick > 0) b._bossTick -= dt;
    if (b.life <= 0 || tileAt(Math.floor(b.x / TS), Math.floor(b.y / TS)) === 1) {
      if (b.life <= 0) burst(b.x, b.y, 6, "#ffe08a", 50, 0.3);
      S.sunBeam = null;
    }
  }
}
function buildTrainLevel() {
  // arena curta para treinar o poder atual
  const L = mk("Treino de Deus", "temple", 48);
  L.bg = "temple"; L.music = "Kiwi_Temple"; L.start = 2; L.train = true;
  ground(L, 0, 47, 6);
  plat(L, 10, 4, 4); plat(L, 20, 3, 4); plat(L, 30, 4, 5);
  haz(L, 16, 5, 2);
  E(L, "beetle", 14, 6); E(L, "hedge", 24, 6); E(L, "acorn", 34, 6);
  E(L, "beetle", 38, 6);
  E(L, "light", 8, 6); E(L, "spring", 28, 6);
  E(L, "door", 44, 6); // volta à campanha
  E(L, "marco", 5, 6, { seq: "N01" });
  frags(L, [[12, 3], [21, 2], [31, 3], [36, 5], [40, 5]]);
  L.intro = null;
  return L;
}
/** Continua após FASE COMPLETA */
function advanceFromComplete() {
  if (S.mode !== "complete" || menuLock > 0) return;
  menuLock = 0.45;
  try { sfx("Menu_Select"); } catch (err) {}
  S.lvlDeaths = 0;
  // 1º baú: 40 moedas. Próximos: ao passar do marco de pontos
  if (!S.spawnChestNext) {
    if (!S.activePower && (S.coinsTowardChest || 0) >= COIN_CHEST_NEED) {
      S.spawnChestNext = true;
      S.toast = { text: "Um baú de sacrifício surgirá perto do fim da próxima fase.", t: 5, nome: "DESTINO", desc: "Baú a caminho", col: "#ffd36e" };
    } else if (S.activePower && S.nextSacrificeAt && playerPoints() >= S.nextSacrificeAt) {
      S.spawnChestNext = true;
      S.toast = { text: "Novo sacrifício disponível — baú no fim da próxima fase.", t: 5, nome: "DESTINO", desc: "Novo baú", col: "#ffd36e" };
    }
  }
  if (S.lvl + 1 < LEVELS.length) {
    const completed = S.lvl + 1;
    if (completed === 10 && S.swordRank < 2) { S.sword = "ferro"; S.swordRank = 2; S.toast = { text: "Espada forjada: Ferro!", t: 4, nome: "ESPADA", desc: "Ferro", col: "#a8c0d8" }; }
    else if (completed === 40 && S.swordRank < 3) { S.sword = "ouro"; S.swordRank = 3; S.toast = { text: "Espada forjada: Ouro!", t: 4, nome: "ESPADA", desc: "Ouro", col: "#ffd36e" }; }
    else if (completed === 80 && S.swordRank < 4) { S.sword = "diamante"; S.swordRank = 4; S.toast = { text: "Espada forjada: Diamante!", t: 4, nome: "ESPADA", desc: "Diamante", col: "#7ad7ff" }; }
    S.mode = "play";
    loadLevel(S.lvl + 1);
    if (L.intro) sayLater(L.intro, 400);
  } else {
    S.finished = true;
    writeSave({ finished: true, level: LEVELS.length - 1 });
    try { localStorage.setItem("auralis_campaign_done", "1"); } catch (e) {}
    S.mode = "ending";
    S.t = 0;
  }
}
/** Clique/toque em menus e UI — robusto para WebView/APK. */
function handleMenuPointer(e) {
  audioOn = true;
  if (menuLock > 0) return true;

  // Diálogo na fase: qualquer toque avança a fala
  if (S.mode === "play" && dlg && !S.menu) {
    menuLock = 0.12;
    dlgAdvance();
    return true;
  }

  if (S.mode === "splash") {
    menuLock = 0.3;
    toTitle();
    return true;
  }
  if (S.mode === "help" || S.mode === "credits") {
    exitHelpCredits();
    return true;
  }
  if (S.mode === "complete") {
    if (S.t > 0.5) advanceFromComplete();
    return true;
  }
  if (S.mode === "ending") {
    if (S.t > 0.5) { menuLock = 0.35; toTitle(); }
    return true;
  }

  const { x, y } = canvasXY(e);

  if (S.mode === "powerChoice" && S.powerChoice) {
    const q = S.powerChoice;
    if (q.stage === "confirm") {
      const row = (S.menuRows || []).find(o => x >= (o.x0 || 0) && x <= (o.x1 || 896) && y >= 360 && y <= 430);
      if (row) {
        menuLock = 0.3;
        if (row.act === "yes" || row.i === 0) pressed.ok = true;
        else { q.stage = "cards"; }
      }
    } else {
      const row = (S.menuRows || []).find(o => x >= (o.x0 || 0) && x <= (o.x1 || 896) && y >= 150 && y <= 380);
      if (row) {
        q.sel = row.i;
        menuLock = 0.3;
        pressed.ok = true;
      } else if (y > 420) {
        pressed.pause = true;
        menuLock = 0.3;
      }
    }
    return true;
  }

  if (S.menu) {
    const row = (S.menuRows || []).find(o => y >= o.y - 28 && y <= o.y + 28 && x >= 80 && x <= 816);
    if (row) {
      S.menu.sel = row.i;
      menuLock = 0.35;
      const it = S.menu.items[row.i];
      if (it) { try { sfx("Menu_Select"); } catch (err) {} it.fn(); }
    }
    return true;
  }

  if (S.mode === "title") {
    const row = (S.menuRows || []).find(o => y >= o.y - 28 && y <= o.y + 28 && x >= 80 && x <= 816);
    if (row) {
      S.titleSel = row.i;
      menuLock = 0.35;
      const items = titleItems();
      const it = items[row.i];
      if (it) { try { sfx("Menu_Select"); } catch (err) {} it.fn(); }
    }
    return true;
  }
  if (S.mode === "chars") {
    if (y > 455) { menuLock = 0.35; S.mode = "title"; S.t = 0; return true; }
    const ids = Object.keys(CHARACTERS);
    const row = (S.menuRows || []).find(o => o.i < 99 && x >= (o.x0 || 0) && x <= (o.x1 || 896) && y >= 120 && y <= 400);
    if (row) {
      S.charSel = row.i;
      menuLock = 0.35;
      const id = ids[row.i];
      if (isCharUnlocked(id)) {
        S.character = id; applyCharacterPassives();
        try { sfx("Menu_Select"); } catch (e) {}
        S.mode = "title"; S.t = 0;
      } else {
        S.toast = { text: "Termine a campanha 1x para desbloquear.", t: 3, nome: "BLOQUEADO", desc: CHARACTERS[id].nome, col: "#ff7a7a" };
      }
    }
    return true;
  }
  if (S.mode === "slots") {
    // voltar
    if (y > 455) {
      menuLock = 0.35;
      S.mode = "title"; S.t = 0;
      return true;
    }
    const row = (S.menuRows || []).find(o => o.i < 99 && y >= o.y - 48 && y <= o.y + 48);
    if (row) {
      S.slotSel = row.i;
      menuLock = 0.35;
      try { sfx("Menu_Select"); } catch (err) {}
      const data = readSlot(row.i);
      // toque longo na direita = apagar: se tocou na metade direita e tem save, pede apagar
      if (x > 620 && data && data.level > 0) {
        if (S.slotAction === 1 && S.slotSel === row.i) {
          clearSlot(row.i);
          S.slotAction = 0;
          S.toast = { text: "Slot " + (row.i + 1) + " apagado.", t: 2.5, nome: "SAVE", desc: "Vazio", col: "#ffd36e" };
        } else {
          S.slotAction = 1;
        }
      } else if (data && data.level > 0 && !data.finished) {
        startFromSlot(row.i, true);
      } else {
        startFromSlot(row.i, false);
      }
    }
    return true;
  }
  return false;
}
function onUiPointer(e) {
  // ignora toques nos botões do pad (eles têm handlers próprios)
  if (e.target && e.target.closest && e.target.closest("#touch")) return;
  if (handleMenuPointer(e)) {
    if (e.cancelable) e.preventDefault();
  } else {
    audioOn = true;
  }
}
function onUiTouch(e) {
  if (e.target && e.target.closest && e.target.closest("#touch")) return;
  if (!e.changedTouches || !e.changedTouches[0]) return;
  const t = e.changedTouches[0];
  if (handleMenuPointer({ clientX: t.clientX, clientY: t.clientY })) {
    if (e.cancelable) e.preventDefault();
  }
}
// Captura em document + canvas (WebViews de APK às vezes engolem um dos dois)
document.addEventListener("pointerdown", onUiPointer, { capture: true, passive: false });
document.addEventListener("touchstart", onUiTouch, { capture: true, passive: false });
cv.addEventListener("pointerdown", onUiPointer, { passive: false });
cv.addEventListener("touchstart", onUiTouch, { passive: false });

// Pad de toque + pause topo + interagir
function bindTouchButton(b) {
  const k = b.dataset.k;
  if (!k) return;
  const downFn = e => {
    if (e.cancelable) e.preventDefault();
    e.stopPropagation();
    audioOn = true;
    press(k);
    if (k === "up" || k === "jump") pressed.ok = true;
  };
  const upFn = e => {
    if (e && e.cancelable) e.preventDefault();
    release(k);
  };
  b.addEventListener("pointerdown", downFn, { passive: false });
  b.addEventListener("touchstart", downFn, { passive: false });
  b.addEventListener("pointerup", upFn);
  b.addEventListener("pointerleave", upFn);
  b.addEventListener("pointercancel", upFn);
  b.addEventListener("touchend", upFn);
  b.addEventListener("touchcancel", upFn);
}
document.querySelectorAll("#touch button, #btn-pause, #btn-up, #btn-power").forEach(bindTouchButton);

function canInteractNow() {
  if (S.mode !== "play" || !P || P.dead || dlg || cut || S.menu) return false;
  if (nearEnt("mara") || nearEnt("marco") || nearEnt("stone") || nearEnt("door") || nearEnt("chest") || nearEnt("trainDoor")) return true;
  return false;
}
function syncTouchPad() {
  const show = S.mode === "play" && !S.menu && !S.dying;
  document.body.classList.toggle("play-touch", !!show);
  document.body.classList.toggle("can-interact", !!show && canInteractNow());
  document.body.classList.toggle("has-power", !!show && !!S.activePower && !!S.showPowerBtn);
}

/* ---------------- poderes temporários ---------------- */
const PW = {
  wing:   {nome:"ASAS DE VENTO", desc:"pulo duplo", dur:18, col:"#dff6ff"},
  shield: {nome:"ESCUDO DE LUZ", desc:"absorve 1 golpe", dur:25, col:"#7ad7ff"},
  boots:  {nome:"BOTAS LEVES",   desc:"corre mais rápido", dur:14, col:"#ffd35a"},
  magnet: {nome:"ÍMÃ DE LUZ",    desc:"atrai fragmentos", dur:16, col:"#ff7a7a"},
  heart:  {nome:"CORAÇÃO DE LUZ", desc:"+1 coração", dur:0, col:"#ff5a8a"},
};
function glyph(c, k, x, y, r) {
  c.save(); c.translate(x, y); c.lineWidth = Math.max(1.5, r * 0.18); c.lineJoin = "round"; c.lineCap = "round";
  if (k === "wing") { c.fillStyle = "#fff"; c.strokeStyle = "#7ab8d8"; for (const sg of [-1, 1]) { c.beginPath(); c.moveTo(sg * r * 0.1, r * 0.5); c.quadraticCurveTo(sg * r * 1.1, r * 0.3, sg * r * 0.95, -r * 0.7); c.quadraticCurveTo(sg * r * 0.45, -r * 0.2, sg * r * 0.1, -r * 0.1); c.closePath(); c.fill(); c.stroke(); } }
  else if (k === "shield") { c.fillStyle = "#cfefff"; c.strokeStyle = "#2a7fb0"; c.beginPath(); c.moveTo(0, -r * 0.9); c.lineTo(r * 0.8, -r * 0.5); c.quadraticCurveTo(r * 0.8, r * 0.5, 0, r * 0.95); c.quadraticCurveTo(-r * 0.8, r * 0.5, -r * 0.8, -r * 0.5); c.closePath(); c.fill(); c.stroke(); }
  else if (k === "boots") { c.fillStyle = "#fff3b0"; c.strokeStyle = "#b8860b"; c.beginPath(); c.moveTo(r * 0.3, -r * 0.95); c.lineTo(-r * 0.6, r * 0.1); c.lineTo(-r * 0.05, r * 0.1); c.lineTo(-r * 0.3, r * 0.95); c.lineTo(r * 0.65, -r * 0.2); c.lineTo(r * 0.05, -r * 0.2); c.closePath(); c.fill(); c.stroke(); }
  else if (k === "magnet") { c.strokeStyle = "#ff5a5a"; c.lineWidth = r * 0.5; c.beginPath(); c.arc(0, -r * 0.05, r * 0.6, Math.PI, 0); c.lineTo(r * 0.6, r * 0.7); c.moveTo(-r * 0.6, -r * 0.05); c.lineTo(-r * 0.6, r * 0.7); c.stroke(); c.strokeStyle = "#fff"; c.lineWidth = r * 0.5; c.beginPath(); c.moveTo(-r * 0.6, r * 0.45); c.lineTo(-r * 0.6, r * 0.75); c.moveTo(r * 0.6, r * 0.45); c.lineTo(r * 0.6, r * 0.75); c.stroke(); }
  else { c.fillStyle = "#ff5a8a"; c.strokeStyle = "#8a1e40"; c.beginPath(); c.moveTo(0, r * 0.8); c.bezierCurveTo(-r * 1.3, -r * 0.1, -r * 0.5, -r * 1.1, 0, -r * 0.4); c.bezierCurveTo(r * 0.5, -r * 1.1, r * 1.3, -r * 0.1, 0, r * 0.8); c.fill(); c.stroke(); }
  c.restore();
}

/* ---------------- fases ---------------- */
const THEME = {
  forest: {ts:"tm_forest", top:[24,25], fill:[32,33,34,35,42,44,31,41], plat:[47,48,49], haz:76},
  cave:   {ts:"tm_cave",   top:[24,25], fill:[32,33,34,35,42,44,31,41], plat:[8,8,8],    haz:65},
  temple: {ts:"tm_temple", top:[42,43], fill:[52,53,54,55,62,63],        plat:[67,68,68], haz:68},
};
function mk(name, theme, w, h = 8) {
  return {name, theme, w, h, g: Array.from({length:h}, () => Array(w).fill(0)), ents: [], trig: [], wind: [], planks: [], start: 2, music: "Kiwi_Forest"};
}
function ground(L, x0, x1, top) { for (let x = x0; x <= x1; x++) for (let y = top; y < L.h; y++) L.g[y][x] = 1; }
function plat(L, x, y, len) { for (let i = 0; i < len; i++) L.g[y][x + i] = 2; }
function haz(L, x, y, len) { for (let i = 0; i < len; i++) L.g[y][x + i] = 3; }
function E(L, t, x, y, o = {}) { L.ents.push(Object.assign({t, x, y}, o)); }
function T(L, x, seq, w = 1, o = {}) { L.trig.push(Object.assign({x, w, seq}, o)); }
function frags(L, list) { list.forEach(([x, y]) => E(L, "frag", x, y)); }

function buildLevels() {
  const LV = [];
  /* 1 — Campos de Vento */
  { const L = mk("Campos de Vento", "forest", 96); L.bg = "day"; L.music = "Kiwi_Forest";
    ground(L,0,23,6); ground(L,16,17,5); ground(L,27,44,6); ground(L,49,70,6); ground(L,74,95,6);
    plat(L,35,3,5); plat(L,46,5,2);
    ground(L,78,81,5); ground(L,82,85,4); ground(L,86,89,5); haz(L,62,5,2);
    L.wind.push({x0:36*TS,y0:1*TS,x1:38*TS,y1:6*TS});
    E(L,"mara",6,6,{seq:"MARA"}); E(L,"marco",10,6,{seq:"N01"});
    E(L,"spring",32,6); E(L,"light",52,6); E(L,"light",90,6); E(L,"door",93,6);
    E(L,"beetle",41,6); E(L,"acorn",56,6); E(L,"hedge",66,6);
    frags(L,[[12,4.5],[20,5],[24.5,4],[25.5,3.5],[26.5,4],[35.5,2],[37,2],[39,2],[46.5,4],[53,5],[58,5],[63,3.5],[67,4.5],[80,3.5],[84,2.5],[87.5,3.5]]);
    T(L,14,"PRIMEIRO_SALTO"); T(L,33,"VENTO"); T(L,39,"CRIATURAS"); T(L,43,"ABISMO");
    E(L,"pw",8,5,{kind:"magnet"}); E(L,"pw",43,5,{kind:"wing"}); E(L,"pw",55,5,{kind:"shield"}); E(L,"pw",84,3,{kind:"heart"});
    E(L,"boulder",70,6,{x0:56,every:5.5});
    frags(L,[[44,3],[47,3.5]]);
    L.intro = "PROLOGO"; LV.push(L); }
  /* 2 — A Ponte Que Canta */
  { const L = mk("A Ponte Que Canta", "forest", 72); L.bg = "dusk"; L.music = "Kiwi_Forest";
    ground(L,0,17,6); ground(L,40,71,6); plat(L,24,3,2); plat(L,30,3,2);
    for (let x = 18; x <= 39; x++) L.planks.push({x, y:6, built:false, bob:0});
    E(L,"marco",8,6,{seq:"N03"}); E(L,"stone",16,6,{seq:"PONTE_B"});
    E(L,"light",43,6); E(L,"hedge",50,6); E(L,"beetle",56,6); E(L,"spring",60,6); E(L,"door",68,6);
    plat(L,61,3,3);
    frags(L,[[5,5],[11,4.5],[20,4.5],[23,4.5],[24.5,2],[26,4.5],[30.5,2],[33,4.5],[36,4.5],[46,5],[53,5],[62,2],[63,2],[64,2],[66,5]]);
    E(L,"pw",4,5,{kind:"boots"}); E(L,"pw",46,5,{kind:"shield"}); E(L,"pw",58,5,{kind:"heart"});
    T(L,11,"PONTE_A"); T(L,15,"PONTE_STONE"); T(L,27,"PONTE_D",1,{needBridge:true});
    LV.push(L); }
  /* 3 — Caverna Ressonante */
  { const L = mk("Caverna Ressonante", "cave", 100); L.bg = "cave"; L.music = "Kiwi_Cave"; L.dark = true;
    for (let x = 0; x < L.w; x++) L.g[0][x] = 1;
    ground(L,0,19,6); ground(L,23,40,6); ground(L,44,60,6); ground(L,61,75,6); ground(L,78,99,6);
    haz(L,12,5,2); haz(L,50,5,2); haz(L,34,5,1);
    plat(L,64,4,3); plat(L,68,3,3); plat(L,72,4,3); plat(L,41,5,2);
    E(L,"marco",6,6,{seq:"N02"}); E(L,"marco",95,6,{seq:"N04"});
    E(L,"light",31,6); E(L,"light",70,6); E(L,"door",97,6);
    E(L,"hedge",28,6); E(L,"beetle",36,6); E(L,"acorn",56,6); E(L,"hedge",66,6); E(L,"hedge",73,6); E(L,"beetle",85,6); E(L,"spring",61,6);
    [14,22,48,54,88,92].forEach(x => E(L,"stal",x,1));
    E(L,"pw",4,5,{kind:"magnet"}); E(L,"pw",26,5,{kind:"shield"}); E(L,"pw",62,5,{kind:"wing"}); E(L,"pw",82,5,{kind:"heart"});
    E(L,"cannon",39,6,{dir:-1}); E(L,"cannon",74,6,{dir:-1}); E(L,"boulder",60,6,{x0:46,every:6});
    frags(L,[[9,5],[17,5],[21.5,3.5],[26,5],[38,5],[41.5,4],[47,5],[58,5],[65,3],[69,2],[73,3],[82,5],[90,5]]);
    LV.push(L); }
  /* 4 — Ruínas do Vento */
  { const L = mk("Ruínas do Vento", "temple", 80); L.bg = "temple"; L.music = "Kiwi_Temple";
    ground(L,0,17,6); ground(L,44,60,6); ground(L,64,79,6);
    plat(L,19,5,2); plat(L,23,4,2); plat(L,27,5,2); plat(L,31,4,2); plat(L,35,2,3); plat(L,40,4,2);
    L.wind.push({x0:33*TS,y0:1*TS,x1:35*TS,y1:6*TS});
    haz(L,52,5,2); plat(L,61,5,3); plat(L,67,3,3);
    E(L,"marco",5,6,{seq:"N06"}); E(L,"light",12,6); E(L,"light",46,6); E(L,"door",76,6);
    E(L,"acorn",50,6); E(L,"hedge",56,6); E(L,"beetle",70,6); E(L,"acorn",73,6); E(L,"spring",66,6);
    frags(L,[[8,5],[14,5],[19.5,4],[23.5,3],[27.5,4],[31.5,3],[35.5,1],[37,1],[38.5,1],[40.5,3],[48,5],[53,3.5],[62,4],[68,2],[70,2],[72,5]]);
    E(L,"pw",8,5,{kind:"wing"}); E(L,"pw",44,5,{kind:"boots"}); E(L,"pw",58,5,{kind:"shield"}); E(L,"pw",68,2,{kind:"heart"});
    E(L,"cannon",59,6,{dir:-1}); E(L,"cannon",77,6,{dir:-1});
    T(L,2,"RUINAS"); LV.push(L); }
  /* 5 — Guardião de Turbina */
  { const L = mk("Guardião de Turbina", "temple", 14); L.bg = "temple"; L.music = "Kiwi_Temple"; L.start = 2; L.boss = true;
    ground(L,0,13,6); ground(L,0,0,0); ground(L,13,13,0); plat(L,1,5,2); plat(L,11,5,2); plat(L,3,3,3); plat(L,8,3,3);
    E(L,"pw",1,4,{kind:"shield"}); E(L,"pw",11,4,{kind:"heart"});
    L.intro = "GUARDIAO_INICIO"; LV.push(L); }
  /* 6 — O Farol (no meio da campanha 200: tem saída; o fim real é a fase 200) */
  { const L = mk("O Farol", "forest", 18); L.bg = "night"; L.music = "Kiwi_Credits"; L.start = 1; L.end = false;
    ground(L,0,17,6);
    E(L,"marco",3,6,{seq:"N05"});
    E(L,"light",8,6); E(L,"light",14,6);
    E(L,"door",16,6);
    frags(L,[[5,5],[9,4.5],[12,5],[15,5]]);
    T(L,4,"FAROL_A"); LV.push(L); }
  return LV;
}

/* Campanha expandida: níveis 7–200 gerados por famílias de cenário.
   Mantém as seis fases autorais iniciais e acrescenta variação procedural controlada.
   Fases densas, vivas, com inimigos, plataformas, hazards e ritmo. */
function buildCampaign200() {
  const lv = buildLevels();
  const scenes = [
    {name:"Bosque das Lanternas",theme:"forest",bg:"dusk",music:"Kiwi_Forest"},
    {name:"Minas de Cristal",theme:"cave",bg:"cave",music:"Kiwi_Cave"},
    {name:"Templo Partido",theme:"temple",bg:"temple",music:"Kiwi_Temple"},
    {name:"Pântano Luminoso",theme:"forest",bg:"night",music:"Kiwi_Forest"},
    {name:"Biblioteca Submersa",theme:"cave",bg:"cave",music:"Kiwi_Cave"},
    {name:"Cidadela Celeste",theme:"temple",bg:"temple",music:"Kiwi_Temple"},
    {name:"Ermos de Cinza",theme:"cave",bg:"night",music:"Kiwi_Cave"},
    {name:"Jardins do Eclipse",theme:"forest",bg:"dusk",music:"Kiwi_Forest"},
    {name:"Forja Estelar",theme:"temple",bg:"temple",music:"Kiwi_Temple"},
    {name:"Fronteira do Vazio",theme:"cave",bg:"cave",music:"Kiwi_Cave"}
  ];
  const bossNames = ["Sentinela de Musgo","Aranha de Obsidiana","Cavaleiro das Marés","Rainha das Cinzas"];
  for (let n = 7; n <= 200; n++) {
    const sceneIndex = Math.floor((n - 1) / 20) % scenes.length, sc = scenes[sceneIndex];
    const isBoss = n % 50 === 0;
    const width = isBoss ? 16 : 110 + ((n * 11) % 40); // fases bem longas e cheias
    const L = mk(isBoss ? bossNames[((n / 50) | 0) - 1] || "Arauto do Vazio" : sc.name + " — Travessia " + n, sc.theme, width);
    L.bg = sc.bg; L.music = sc.music; L.start = isBoss ? 2 : 1; L.end = false; L.campaignLevel = n;
    if (isBoss) {
      L.boss = true; ground(L, 0, 15, 6); plat(L, 1, 5, 3); plat(L, 12, 5, 3); plat(L, 3, 3, 4); plat(L, 9, 3, 4);
      E(L, "pw", 1, 4, {kind: "shield"}); E(L, "pw", 13, 4, {kind: "heart"});
      L.intro = "GUARDIAO_INICIO"; L.bossRank = (n / 50) | 0;
    } else {
      // Chão contínuo no início + seções com gaps controlados, plataformas e risco
      ground(L, 0, 16, 6);
      let x = 18;
      while (x < width - 14) {
        const gap = 2 + ((n + x) % 3);           // gaps menores = menos vazio
        const len = 10 + ((n * 5 + x) % 14);     // trechos longos de chão
        const gx = Math.min(width - 8, x + gap);
        ground(L, gx, Math.min(width - 1, gx + len), 6);
        // plataformas altas para exploração e fragmentos
        if ((x + n) % 2 === 0) plat(L, Math.min(width - 10, x + 1), 3 + ((x + n) % 3), 4 + ((n + x) % 4));
        if ((x + n) % 5 === 0) plat(L, Math.min(width - 8, gx + 3), 2, 3);
        // hazards
        if ((x + n) % 3 === 0) haz(L, Math.max(1, gx - 1), 5, 1 + ((n + x) % 3));
        // springs ocasionais
        if ((x + n) % 7 === 0) E(L, "spring", gx + 2, 6);
        x = gx + len + 3;
      }
      // garante chão no final
      ground(L, width - 12, width - 1, 6);
      E(L, "marco", 5, 6, {seq: "N0" + (1 + (n % 6))});
      // inimigos densos e variados
      const enemyTypes = ["beetle", "hedge", "acorn"];
      for (let ex = 14; ex < width - 10; ex += 7 + ((ex + n) % 5)) {
        E(L, enemyTypes[(ex + n) % enemyTypes.length], ex, 6);
        if ((ex + n) % 2 === 0) E(L, "frag", ex + 1.5, 4.2);
        if ((ex + n) % 3 === 0) E(L, "light", Math.min(width - 5, ex + 4), 6);
        if ((ex + n) % 4 === 0) E(L, "cannon", Math.min(width - 4, ex + 6), 6, {dir: -1});
        if ((ex + n) % 6 === 0) E(L, "boulder", Math.min(width - 6, ex + 8), 6, {x0: Math.max(10, ex - 8), every: 4.5 + (n % 3)});
      }
      // mais fragmentos no ar / plataformas
      for (let fx = 20; fx < width - 15; fx += 9 + (n % 5)) {
        E(L, "frag", fx + 0.5, 2.5 + ((fx + n) % 3) * 0.7);
      }
      E(L, "door", width - 4, 6);
      // poder temporário no meio
      E(L, "pw", Math.floor(width * 0.4), 4, {kind: ["wing", "shield", "boots", "magnet", "heart"][n % 5]});
      E(L, "pw", Math.floor(width * 0.7), 3, {kind: ["wing", "shield", "boots", "magnet", "heart"][(n + 2) % 5]});
      // marcos de história a cada 20
      if (n % 20 === 0) { L.intro = "RUINAS"; L.storyChapter = Math.floor(n / 20); }
      // nível especial: entrega do código secreto (NPC)
      if (n === 42) {
        E(L, "marco", 22, 6, {seq: "SECRET_CODE"});
        L.name = "Ruína do Código — Travessia 42";
      }
    }
    lv.push(L);
  }
  return lv;
}

const LEVELS = buildCampaign200();
LEVELS[5].end=false;
LEVELS[LEVELS.length-1].end=true;
LEVELS[LEVELS.length-1].name="A Última Aurora — Fim da Jornada";

/* ---------------- estado ---------------- */
const SEQ = {
  PROLOGO:["P01","P02","P03","P04","P05","P06","P07","P08"], MARA:["P05","P06"], PRIMEIRO_SALTO:["T01"], FRAGMENTO:["T02","T03","T04"], VENTO:["T05"],
  CRIATURAS:["T06","T07"], ABISMO:["T08"], CHECKPOINT:["T09","T10"], FRAGMENTOS:["T11"],
  PONTE_A:["B01","B02"], PONTE_STONE:["B03"], PONTE_B:["B04"], PONTE_C:["B05","B06"], PONTE_D:["B07"],
  GUARDIAO_INICIO:["G01","G02","G03","G04"], GUARDIAO_PRIMEIRO:["G05"], GUARDIAO_METADE:["G06","G07"], GUARDIAO_FIM:["G08","G09","G10"],
  FAROL_A:["F01"], FAROL_B:["F02","F03"], FAROL_C:["F04","F05","F06","F07"], FAROL_D:["F08","F09"], QUEDA:["S01","S02"],
  N01:["N01"], N02:["N02"], N03:["N03"], N04:["N04"], N05:["N05"], N06:["N06"], RUINAS:["R01","R02"],
  SECRET_CODE:["SC01","SC02"]
};
const S = {lvlDeaths:0, menu:null, dying:null, mode:"loading", t:0, lvl:0, fade:0, fadeDir:0, fadeCb:null, banner:0, hp:4, maxHp:4, frags:0, totalFrags:0, seen:{}, collected:new Set(), committed:new Set(),
  bridge:false, check:null, shake:0, paused:false, titleSel:0, flash:0, deaths:0,
  sword:"madeira", swordRank:0, chosenPowers:[], powerChoice:null, secretFound:false, character:"kiwi", charAttack:"sword",
  coins:0, coinsEarned:0, coinsTowardChest:0, spawnChestNext:false, chestConsumed:false,
  activePower:null, activePowerName:null, nextSacrificeAt:0, showPowerBtn:false,
  permWing:false, permShield:false, permBoots:false, permMagnet:false, difficultyMod:1, storyChapter:0};
let L = null, P = null, boss = null;
let ents = [], orbs = [], parts = [], pipa = {x:0,y:0,f:0}, cut = null, dlg = null, cam = {x:0,y:0};

function loadLevel(i, spawnAtCheck = false) {
  S.lvl = i; L = LEVELS[i];
  L.g.forEach((row, y) => row.forEach((v, x) => { if (v === 2 && L.planks.some(p => p.x === x && p.y === y)) row[x] = 0; })); // reset planks
  L.planks.forEach(p => { p.built = false; p.bob = 0; });
  if (S.bridge && i === 1) L.planks.forEach(p => { p.built = true; L.g[p.y][p.x] = 2; });
  ents = []; orbs = []; parts = []; boss = null; cut = null;
  L.ents.forEach((e, k) => {
    const id = i + ":" + k, o = Object.assign({}, e, {id, anim:Math.random()*4, alive:true});
    if (o.t === "pw") { if (S.collected.has(id)) return; o.px = (o.x + 0.5) * TS; o.py = (o.y + 0.5) * TS; }
    else if (o.t === "frag") { if (S.collected.has(id)) return; o.px = o.x * TS; o.py = o.y * TS; }
    else if (o.t === "stal") { o.px = o.x * TS + 16; o.py = TS; o.state = "hang"; o.vy = 0; }
    else { o.px = o.x * TS + 16; o.py = o.y * TS; }
    if (["beetle","hedge","acorn"].includes(o.t)) { o.dir = -1; o.vy = 0; o.w = o.t === "acorn" ? 16 : 22; o.h = o.t === "hedge" ? 18 : o.t === "acorn" ? 16 : 14; }
    if (o.t === "cannon") { o.cd = 1 + Math.random(); o.rec = 0; o.dir = e.dir || -1; }
    if (o.t === "boulder") { o.timer = 1.2; }
    if (o.t === "light") { o.on = !!(S.check && S.check.id === id); }
    ents.push(o);
  });
  // Baú de sacrifício: só no nível seguinte ao atingir 40 moedas (perto do fim)
  S.chestConsumed = false;
  if (S.spawnChestNext && !L.boss && !L.end && !L.train) {
    const door = ents.find(e => e.t === "door");
    const cx = door ? (door.px / TS) - 4 : L.w - 8;
    ents.push({
      t: "chest", id: i + ":chest", x: cx, y: 6,
      px: cx * TS + 16, py: 6 * TS, anim: 0, alive: true, opened: false
    });
    S.spawnChestNext = false; // aparece uma vez neste mapa
    S.toast = { text: "Baú de Sacrifício no fim do mapa — sacrifique suas moedas por 1 poder.", t: 5, nome: "BAÚ", desc: "Perto da saída", col: "#ffd36e" };
  }
  // Após escolher poder nesta fase: porta de treino perto da saída
  if (S.activePower && S.showTrainDoor && !L.boss && !L.train) {
    const door = ents.find(e => e.t === "door");
    const tx = door ? (door.px / TS) - 7 : L.w - 10;
    ents.push({
      t: "trainDoor", id: i + ":train", x: tx, y: 6,
      px: tx * TS + 16, py: 6 * TS, anim: 0, alive: true
    });
  }
  let sx = L.start * TS + 16, sy = 6 * TS;
  if (spawnAtCheck && S.check && S.check.lvl === i) { sx = S.check.x; sy = S.check.y; }
  P = {x:sx, y:sy, vx:0, vy:0, w:16, h:22, face:1, onG:false, coy:0, buf:0, inv:0, anim:0, dead:false, lastPlank:-1, enter:0, extra:0, pw:{wing:0, shield:0, boots:0, magnet:0}, trail:0, atk:0, atkHit:false};
  pipa = {x:sx - 20, y:sy - 40, f:0};
  if (L.boss) {
    const rank = Math.max(1, L.bossRank || Math.floor((i + 1) / 50) || 1);
    const baseHp = 5 + rank * 3;
    boss = { x: 9.5 * TS, y: 6 * TS, w: 38, h: 84, hp: Math.round(baseHp * (S.difficultyMod || 1)), maxHp: Math.round(baseHp * (S.difficultyMod || 1)),
      state: "wait", t: 0, flash: 0, dir: -1, started: false, dead: false, shots: 0, half: false, first: false, dying: 0, rank, name: L.name };
  }
  S.committed = S.committed || new Set();
  S.frags = S.collected.size;
  S.banner = 3; cam.x = 0;
  if (P) { P._shieldUsedThisLevel = false; P._shieldInit = false; }
  music(L.music, !L.end);
}
function newGame(lvl = 0) {
  S.collected = new Set(); S.committed = new Set(); S.check = null; S.bridge = false; S.seen = {}; S.deaths = 0; S.lvlDeaths = 0; S.menu = null; S.dying = null; S.totalFrags = 0;
  S.sword = "madeira"; S.swordRank = 0; S.chosenPowers = []; S.powerChoice = null; S.secretFound = false;
  S.coins = 0; S.coinsEarned = 0; S.coinsTowardChest = 0; S.spawnChestNext = false; S.chestConsumed = false;
  S.activePower = null; S.activePowerName = null; S.nextSacrificeAt = 0; S.showPowerBtn = false; S.showTrainDoor = false;
  S.permWing = false; S.permShield = false; S.permBoots = false; S.permMagnet = false; S.difficultyMod = 1; S.storyChapter = 0;
  S.character = CHARACTERS[S.character] ? S.character : "kiwi";
  S.maxHp = 4;
  applyCharacterPassives();
  S.hp = S.maxHp;
  // Novo jogo não herda progresso; Herdeira só se o código for digitado de novo nesta run
  S.mode = "play"; loadLevel(lvl);
  if (L.intro && !S.seen[L.intro] && !/[?&]nointro=1/.test(location.search)) { S.seen[L.intro] = 1; sayLater(L.intro, 400); }
  if (lvl === 0) {
    const ch = CHARACTERS[S.character] || CHARACTERS.kiwi;
    S.toast = { text: "TUTORIAL: " + ch.nome + " (" + ch.afinidade + ") — mova, pule e fale com Mara.", t: 7, nome: "TUTORIAL", desc: ch.desc, col: "#ffd36e" };
  }
}

/* ---------------- diálogo ---------------- */
function say(name, cb) {
  const ids = SEQ[name]; if (!ids) { cb && cb(); return; }
  dlg = {name, i:0, ch:0, lines: ids.map(id => ({who: FALAS[id][0], text: FALAS[id][1]})), cb};
  if (dlg.lines[0].who === "Pipa") chirp();
}
function sayLater(name, ms) { setTimeout(() => { if (S.mode === "play" && !S.menu && !S.dying && !dlg) say(name); }, ms); }
function dlgAdvance() {
  const l = dlg.lines[dlg.i];
  if (dlg.ch < l.text.length) { dlg.ch = l.text.length; return; }
  dlg.i++; dlg.ch = 0;
  if (dlg.i >= dlg.lines.length) { const cb = dlg.cb; dlg = null; pressed.jump = false; pressed.up = false; cb && cb(); return; }
  sfx("Menu_Move", 0.3); if (dlg.lines[dlg.i].who === "Pipa") chirp();
}
const WHO_COL = {"Nilo":"#8ee7ff","Mara":"#ffd36e","Pipa":"#ff9ed8","Guardião":"#ff7a7a","O Curador":"#c9a0ff"};

/* ---------------- física ---------------- */
function tileAt(tx, ty) { if (tx < 0 || tx >= L.w) return 1; if (ty < 0 || ty >= L.h) return 0; return L.g[ty][tx]; }
function moveX(e, dx) {
  e.x += dx; const l = e.x - e.w / 2, r = e.x + e.w / 2, t = e.y - e.h, b = e.y - 0.01;
  for (let ty = Math.floor(t / TS); ty <= Math.floor(b / TS); ty++) for (let tx = Math.floor(l / TS); tx <= Math.floor((r - 0.01) / TS); tx++)
    if (tileAt(tx, ty) === 1) { if (dx > 0) e.x = tx * TS - e.w / 2; else if (dx < 0) e.x = (tx + 1) * TS + e.w / 2; e.vx = 0; e.hitWall = true; return; }
}
function moveY(e, dy) {
  const pb = e.y; e.y += dy; e.onG = false; const l = e.x - e.w / 2, r = e.x + e.w / 2 - 0.01, t = e.y - e.h, b = e.y;
  for (let ty = Math.floor(t / TS); ty <= Math.floor((b - 0.01) / TS); ty++) for (let tx = Math.floor(l / TS); tx <= Math.floor(r / TS); tx++) {
    const v = tileAt(tx, ty);
    if (v === 1) { if (dy > 0) { e.y = ty * TS; e.onG = true; } else if (dy < 0) e.y = (ty + 1) * TS + e.h; e.vy = 0; return; }
    if (v === 2 && dy > 0 && pb <= ty * TS + 0.5) { e.y = ty * TS; e.onG = true; e.vy = 0; return; }
  }
}
function hazardHit(e) {
  const l = e.x - e.w / 2 + 2, r = e.x + e.w / 2 - 2, t = e.y - e.h + 2, b = e.y - 1;
  for (let ty = Math.floor(t / TS); ty <= Math.floor(b / TS); ty++) for (let tx = Math.floor(l / TS); tx <= Math.floor(r / TS); tx++)
    if (tileAt(tx, ty) === 3) { const hy0 = ty * TS + 14; if (b > hy0 && t < ty * TS + TS) return true; }
  return false;
}
const ov = (a, b) => Math.abs(a.x - b.x) < (a.w + b.w) / 2 && Math.abs((a.y - a.h / 2) - (b.y - b.h / 2)) < (a.h + b.h) / 2;
function burst(x, y, n, col, sp = 90, life = 0.5) {
  for (let i = 0; i < n; i++) { const a = Math.random() * 6.28, s = sp * (0.3 + Math.random()); parts.push({x, y, vx:Math.cos(a) * s, vy:Math.sin(a) * s - 30, life, max:life, col, size:1 + Math.random() * 2}); }
}

/* ---------------- ações do jogador ---------------- */
function hurt(src) {
  if (P.inv > 0 || P.dead) return;
  // escudo temporário ou permanente (1x por fase)
  if (P.pw.shield > 0 || (S.permShield && !P._shieldUsedThisLevel)) {
    if (P.pw.shield > 0) P.pw.shield = 0;
    if (S.permShield) P._shieldUsedThisLevel = true;
    P.inv = 1; sfx("Reflect", 0.5); S.shake = 0.12; burst(P.x, P.y - 12, 14, "#7ad7ff", 110, 0.5);
    if (src && src.x !== undefined) P.vx = (P.x < src.x ? -1 : 1) * 90; return;
  }
  S.hp--; P.inv = 1.3; sfx("Kiwi_Hurt"); S.shake = 0.25; burst(P.x, P.y - 12, 8, "#ff7a7a");
  if (S.hp <= 0) return die();
  P.vy = -230; P.vx = (src && src.x !== undefined ? (P.x < src.x ? -1 : 1) : -P.face) * 150;
}
function die(fall) {
  if (P.dead) return; P.dead = true; S.deaths++; S.lvlDeaths++;
  if (S.hp <= 0) { S.hp = 0; sfx(fall ? "Splash" : "Kiwi_Hurt"); S.dying = {t:0, fall:!!fall}; P.vy = -320; P.vx = 0; P.spin = 0; music("Kiwi_Death", false); return; }
  sfx(fall ? "Splash" : "Kiwi_Hurt");
  S.fadeDir = 1; S.fade = 0; S.fadeCb = () => { respawn(true); S.fadeDir = -1; S.fade = 1; };
}
function checkpoint(e) {
  if (e.on) return; e.on = true; sfx("Collectible_2"); burst(e.px, e.py - 40, 14, "#8ee7ff", 80, 0.8);
  S.check = {id:e.id, lvl:S.lvl, x:e.px, y:e.py}; S.committed = new Set(S.collected); S.hp = S.maxHp;
  if (!S.seen.CHECKPOINT) { S.seen.CHECKPOINT = 1; say("CHECKPOINT"); }
}
function collect(e) {
  e.alive = false; S.collected.add(e.id); S.frags = S.collected.size; S.totalFrags++;
  S.coins += 1; S.coinsEarned = (S.coinsEarned || 0) + 1;
  S.coinsTowardChest = (S.coinsTowardChest || 0) + 1;
  sfx(S.totalFrags % 2 ? "Collectible_1" : "Collectible_2", 0.45);
  burst(e.px, e.py, 6, "#8ee7ff", 60, 0.4);
  if (!S.seen.FRAGMENTO) { S.seen.FRAGMENTO = 1; say("FRAGMENTO"); }
  else if (S.totalFrags >= 5 && !S.seen.FRAGMENTOS) { S.seen.FRAGMENTOS = 1; say("FRAGMENTOS"); }
  if (S.coinsTowardChest === COIN_CHEST_NEED) {
    S.toast = { text: "40 moedas! O baú de sacrifício aparece no fim da PRÓXIMA fase.", t: 5, nome: "MARCO", desc: "40 moedas", col: "#ffd36e" };
  }
}
function buildBridge() {
  cut = {t:0, i:0, stage:"build"}; P.vx = 0;
}
function endLevel() {
  S.fadeDir = 1; S.fade = 0; sfx("Door_Enter"); music(null); P.enter = 1;
  S.fadeCb = () => {
    S.mode = "complete"; S.t = 0; S.committed = new Set(S.collected); S.check = null; S.hp = S.maxHp;
    if (S.lvl < LEVELS.length - 1) music("Kiwi_LevelComplete", false);
    S.fadeDir = -1; S.fade = 1;
    writeSave({
      level: Math.min(LEVELS.length - 1, S.lvl + 1),
      maxUnlocked: Math.min(LEVELS.length, S.lvl + 2),
      totalFrags: S.totalFrags
    });
  };
}

/* ---------------- menus ---------------- */
function lvlTotal() { return LEVELS[S.lvl].ents.filter(e => e.t === "frag").length; }
function lvlCount() { return [...S.collected].filter(id => id.startsWith(S.lvl + ":")).length; }
function openMenu(kind) {
  const back = () => { S.menu = null; S.dying = null; toTitle(); };
  const items = kind === "pause"
    ? [
        { t: () => "Continuar", fn: () => { S.menu = null; } },
        { t: () => "Reiniciar a fase", fn: restartLevel },
        { t: () => "Controles", fn: () => { S.menu = null; S.mode = "help"; S.t = 0; S._helpFromPause = true; } },
        { t: () => "Som: " + (muted ? "desligado" : "ligado"), fn: () => setMuted(!muted), keep: true },
        { t: () => "Voltar ao título", fn: back }
      ]
    : [
        { t: () => "Tentar de novo", fn: retry },
        { t: () => "Reiniciar a fase", fn: restartLevel },
        { t: () => "Voltar ao título", fn: back }
      ];
  S.menu = { kind, items, sel: 0, t: 0 };
}
function respawn(keepHp) {
  if (!keepHp) S.hp = S.maxHp;
  S.collected = new Set(S.committed); S.dying = null;
  if (L.boss) { loadLevel(S.lvl); sayLater("GUARDIAO_INICIO", 400); return; }
  loadLevel(S.lvl, true);
  if (!S.seen.QUEDA) { S.seen.QUEDA = 1; sayLater("QUEDA", 600); }
}
function retry() { S.menu = null; S.dying = null; S.fadeDir = 1; S.fade = 0; S.fadeCb = () => { respawn(false); S.fadeDir = -1; S.fade = 1; }; }
function restartLevel() {
  S.menu = null; S.dying = null; S.fadeDir = 1; S.fade = 0;
  S.fadeCb = () => {
    const pre = S.lvl + ":"; S.collected = new Set([...S.collected].filter(id => !id.startsWith(pre))); S.committed = new Set([...S.committed].filter(id => !id.startsWith(pre)));
    if (S.check && S.check.lvl === S.lvl) S.check = null; if (S.lvl === 1) S.bridge = false; S.hp = S.maxHp; S.dying = null; S.lvlDeaths = 0;
    loadLevel(S.lvl); if (L.intro) sayLater(L.intro, 400);
    S.fadeDir = -1; S.fade = 1;
  };
}
function updateMenu(dt) {
  const m = S.menu; m.t += dt; const n = m.items.length;
  if (menuLock > 0) menuLock -= dt;
  if (pressed.up) { m.sel = (m.sel + n - 1) % n; sfx("Menu_Move"); }
  if (pressed.down) { m.sel = (m.sel + 1) % n; sfx("Menu_Move"); }
  if (m.kind === "pause" && pressed.pause) { S.menu = null; }
  else if (m.t > 0.15 && menuLock <= 0 && (pressed.ok || pressed.jump)) {
    menuLock = 0.35; sfx("Menu_Select"); const it = m.items[m.sel]; if (it) it.fn();
  }
  for (const k of Object.keys(pressed)) pressed[k] = false;
}
function drawMenu() {
  const m = S.menu; ctx.fillStyle = m.kind === "death" ? "rgba(40,0,10,.72)" : "rgba(0,0,10,.62)"; ctx.fillRect(0, 0, 896, 512);
  T_(m.kind === "death" ? "VOCÊ CAIU" : "PAUSADO", 448, 150, 46, m.kind === "death" ? "#ff9aa8" : "#fff", "center");
  const tot = lvlTotal(); T_(L.name + (tot ? "  ·  fragmentos " + lvlCount() + "/" + tot : "") + "  ·  quedas " + S.lvlDeaths, 448, 192, 17, "#bfefff", "center");
  S.menuRows = [];
  m.items.forEach((it, i) => {
    const y = 250 + i * 44;
    S.menuRows.push({ y, i });
    if (m.sel === i) {
      ctx.fillStyle = "rgba(30,80,120,0.5)";
      ctx.fillRect(200, y - 22, 496, 36);
      ctx.strokeStyle = "#8ee7ff"; ctx.lineWidth = 2;
      ctx.strokeRect(200, y - 22, 496, 36);
    }
    T_((m.sel === i ? "▶ " : "  ") + it.t(), 448, y, 24, m.sel === i ? "#8ee7ff" : "#fff", "center");
  });
  T_("Toque na opção  ·  ou ↑↓ e Z/Enter", 448, 480, 14, "#aab", "center", false);
}

/* ---------------- atualização ---------------- */
function update(dt) {
  S.t += dt;
  if (S.mode === "play" && !S.menu && !S.dying) S.playTime = (S.playTime || 0) + dt;
  if (S.fadeDir) { S.fade += S.fadeDir * dt * 2.2; if (S.fadeDir > 0 && S.fade >= 1) { S.fade = 1; S.fadeDir = 0; const cb = S.fadeCb; S.fadeCb = null; cb && cb(); } else if (S.fadeDir < 0 && S.fade <= 0) { S.fade = 0; S.fadeDir = 0; } }
  if (S.mode === "loading") return;
  if (S.mode === "splash") return updateSplash(dt);
  if (S.mode === "title") return updateTitle(dt);
  if (S.mode === "slots") return updateSlots(dt);
  if (S.mode === "chars") return updateChars(dt);
  if (S.mode === "help" || S.mode === "credits") {
    if (menuLock > 0) menuLock -= dt;
    if (menuLock <= 0 && (pressed.ok || pressed.jump || pressed.pause)) exitHelpCredits();
    for (const k of Object.keys(pressed)) pressed[k] = false;
    return;
  }
  if (S.mode === "complete") {
    if (menuLock > 0) menuLock -= dt;
    if (S.t > 0.6 && menuLock <= 0 && (pressed.ok || pressed.jump || pressed.attack)) {
      advanceFromComplete();
    }
    for (const k of Object.keys(pressed)) pressed[k] = false; return;
  }
  if (S.mode === "powerChoice") {
    const q = S.powerChoice;
    if (!q) { S.mode = "play"; return; }
    if (menuLock > 0) menuLock -= dt;
    q.anim = (q.anim || 0) + dt;
    if (q.stage === "cards") {
      const n = SACRIFICE_POWERS.length;
      if (pressed.left || pressed.up) q.sel = (q.sel + n - 1) % n;
      if (pressed.right || pressed.down) q.sel = (q.sel + 1) % n;
      if (pressed.pause) {
        // recusar sacrifício: baú some, moedas ficam, próximo baú só com mais 40
        S.spawnChestNext = false; S.coinsTowardChest = 0;
        S.powerChoice = null; S.mode = "play";
        S.toast = { text: "Você recusou o sacrifício. O baú se fecha.", t: 3.5, nome: "BAÚ", desc: "Fechado", col: "#aab" };
        writeSave({ level: S.lvl });
      } else if ((pressed.ok || pressed.jump) && menuLock <= 0) {
        menuLock = 0.35; q.stage = "confirm";
      }
    } else if (q.stage === "confirm") {
      if (pressed.pause) { q.stage = "cards"; menuLock = 0.25; }
      else if ((pressed.ok || pressed.jump) && menuLock <= 0) {
        menuLock = 0.4;
        const p = SACRIFICE_POWERS[q.sel];
        applySacrificePower(p);
        S.showPowerBtn = true;
        S.showTrainDoor = true;
        // remove chest entity
        ents.forEach(e => { if (e.t === "chest") e.alive = false; });
        // spawn train door now
        const door = ents.find(e => e.t === "door");
        if (door) {
          const tx = (door.px / TS) - 7;
          ents.push({ t: "trainDoor", id: S.lvl + ":train", px: tx * TS + 16, py: 6 * TS, anim: 0, alive: true });
        }
        S.powerChoice = null; S.mode = "play";
        music(L.music);
        S.toast = { text: p.nome + " ativo até o próximo sacrifício (~" + NEXT_SACRIFICE_POINTS + " pts).", t: 5.5, nome: "PODER", desc: p.strat, col: p.col };
        writeSave({ level: S.lvl, powers: S.chosenPowers });
      }
    }
    for (const k of Object.keys(pressed)) pressed[k] = false; return;
  }
  if (S.mode === "ending") { if (S.t > 2 && pressed.ok) toTitle(); for (const k of Object.keys(pressed)) pressed[k] = false; return; }
  if (S.menu) return updateMenu(dt);
  if (pressed.mute) { setMuted(!muted); pressed.mute = false; }
  if (pressed.pause && !S.dying && !S.fadeDir) {
    pressed.pause = false;
    if (dlg || cut) {
      S.toast = { text: "Termine o diálogo / cena antes de pausar.", t: 2.5, nome: "PAUSA", desc: "Bloqueada", col: "#aab" };
    } else {
      openMenu("pause");
    }
    return;
  }
  if (S.dying) {
    S.dying.t += dt; if (!S.dying.fall) { P.vy += 900 * dt; P.y += P.vy * dt; P.spin += dt * 9; }
    updateParts(dt); if (S.dying.t > 1.3) openMenu("death");
    for (const k of Object.keys(pressed)) pressed[k] = false; return;
  }
  if (S.banner > 0) S.banner -= dt; if (S.toast && S.toast.t > 0) S.toast.t -= dt;
  if (S.shake > 0) S.shake -= dt; if (S.flash > 0) S.flash -= dt;
  // diálogo congela o mundo
  if (dlg) {
    const l = dlg.lines[dlg.i]; if (dlg.ch < l.text.length) dlg.ch = Math.min(l.text.length, dlg.ch + dt * 55);
    if (pressed.jump || pressed.up || pressed.ok) dlgAdvance();
    updatePipa(dt); updateParts(dt); for (const k of Object.keys(pressed)) pressed[k] = false; return;
  }
  if (cut) return updateCut(dt);
  if (!P.dead) updatePlayer(dt);
  updateEnts(dt); if (boss) updateBoss(dt);
  updateOrbs(dt); updateParts(dt); updatePipa(dt); updatePowerEffects(dt);
  // triggers de fala
  if (!P.dead) for (const tr of L.trig) {
    if (tr.done) continue; if (tr.needBridge && !S.bridge) continue;
    if (P.x >= tr.x * TS && P.x < (tr.x + tr.w) * TS) { tr.done = true; if (!S.seen[tr.seq] || !tr.once) { S.seen[tr.seq] = 1; say(tr.seq); break; } }
  }
  // câmera
  const tx = Math.max(0, Math.min(L.w * TS - VW, P.x - VW / 2 + P.face * 20));
  cam.x += (tx - cam.x) * Math.min(1, dt * 6); if (L.w * TS <= VW) cam.x = (L.w * TS - VW) / 2;
  for (const k of Object.keys(pressed)) pressed[k] = false;
}
function updatePlayer(dt) {
  const ctl = !cut;
  const dir = (down.right ? 1 : 0) - (down.left ? 1 : 0);
  for (const k in P.pw) if (P.pw[k] > 0) P.pw[k] = Math.max(0, P.pw[k] - dt);
  // poderes permanentes + temporários
  const hasWing = P.pw.wing > 0 || S.permWing;
  const hasBoots = P.pw.boots > 0 || S.permBoots;
  const hasShield = P.pw.shield > 0 || (S.permShield && !P._shieldUsedThisLevel);
  if (S.permShield && !P._shieldInit) { P.pw.shield = Math.max(P.pw.shield, 0.01); P._shieldInit = true; } // marca visual
  const bt = hasBoots, RUN = bt ? 220 : 150, acc = (P.onG ? 1500 : 950) * (bt ? 1.45 : 1);
  if (P.onG) P.extra = hasWing ? 1 : 0;
  if (dir) { P.vx += dir * acc * dt; P.face = dir; if (Math.abs(P.vx) > RUN && Math.sign(P.vx) === dir) P.vx = dir * RUN; }
  else { const f = (P.onG ? 1700 : 500) * dt; P.vx = Math.abs(P.vx) <= f ? 0 : P.vx - Math.sign(P.vx) * f; }
  P.coy = P.onG ? 0.1 : P.coy - dt; P.buf = pressed.jump ? 0.12 : P.buf - dt;
  if (P.buf > 0 && P.coy > 0) { P.vy = -420; P.buf = 0; P.coy = 0; sfx("Kiwi_Jump", 0.35); burst(P.x, P.y, 4, "#fff", 40, 0.25); }
  else if (P.buf > 0 && !P.onG && P.extra > 0 && hasWing) { P.vy = -400; P.extra = 0; P.buf = 0; sfx("Kiwi_Jump", 0.3); for (let i = 0; i < 8; i++) parts.push({x:P.x + (Math.random() - 0.5) * 16, y:P.y - 8, vx:(Math.random() - 0.5) * 80, vy:30 + Math.random() * 40, life:0.45, max:0.45, col:"#dff6ff", size:2}); }
  if (!down.jump && P.vy < -170) P.vy = -170;
  // Asas de Guerra: planar (gravidade fraca)
  if (P.glide > 0) {
    P.vy = Math.min(P.vy + 280 * dt, 70);
  } else {
    P.vy = Math.min(P.vy + 1150 * dt, 520);
  }
  // vento ascendente
  for (const w of L.wind) if (P.x > w.x0 && P.x < w.x1 && P.y > w.y0 && P.y - P.h < w.y1) { P.vy = Math.max(P.vy - 2600 * dt, -150); if (Math.random() < 0.5) parts.push({x:w.x0 + Math.random() * (w.x1 - w.x0), y:w.y1, vx:0, vy:-90, life:0.8, max:0.8, col:"#dff", size:1}); }
  const wasG = P.onG, pvy = P.vy; P.hitWall = false; moveX(P, P.vx * dt); moveY(P, P.vy * dt);
  if (P.onG && !wasG && pvy > 200) {
    burst(P.x, P.y, 6, "#d8cfa8", 50, 0.35);
    P.landDust = 0.35; // animação de poeira (peças extras)
  }
  if (P.landDust > 0) P.landDust -= dt;
  if (P.onG && Math.abs(P.vx) > 100) { P.dust = (P.dust || 0) - dt; if (P.dust <= 0) { P.dust = 0.14; parts.push({x:P.x - P.face * 6, y:P.y - 1, vx:-P.face * 20, vy:-15, life:0.3, max:0.3, col:"#d8cfa8", size:2}); } }
  if (P.inv > 0) P.inv -= dt;
  // queda
  if (P.y > L.h * TS + 40) { S.hp = Math.max(0, S.hp - 1); S.shake = 0.2; die(true); return; }
  if (hazardHit(P)) hurt({x:P.x});
  // plancas cantantes
  if (P.onG && S.lvl === 1) {
    const tx = Math.floor(P.x / TS), ty = Math.floor((P.y + 1) / TS), pl = L.planks.find(p => p.x === tx && p.y === ty && p.built);
    if (pl && P.lastPlank !== tx) { P.lastPlank = tx; pl.bob = 1; note(PENTA[(tx - 18) % PENTA.length], 0.35, "triangle", 0.14); } else if (!pl) P.lastPlank = -1;
  }
  if (bt && P.onG && Math.abs(P.vx) > 120) { P.trail -= dt; if (P.trail <= 0) { P.trail = 0.05; parts.push({x:P.x - P.face * 8, y:P.y - 8, vx:-P.face * 30, vy:0, life:0.3, max:0.3, col:"#ffd35a", size:3}); } }
  // ataque: espada (Nilo/Brisa) ou magia (Aural)
  if (P.atk > 0) P.atk -= dt;
  if (pressed.power) { activatePower(); pressed.power = false; }
  if (pressed.attack && P.atk <= 0 && !P.dead) {
    const isMagic = (S.charAttack === "magic") || (S.character === "aural");
    P.atk = isMagic ? 0.4 : 0.28; P.atkHit = false;
    if (isMagic) {
      sfx("Collectible_2", 0.4);
      orbs.push({
        x: P.x + P.face * 14, y: P.y - 14,
        vx: P.face * (160 + (S.swordRank || 0) * 12), vy: -20,
        t: 0, life: 1.4, max: 1.4, friendly: true, r: 8,
        spr: null, magic: true
      });
      for (let i = 0; i < 5; i++) parts.push({
        x: P.x + P.face * 10, y: P.y - 14,
        vx: P.face * (20 + Math.random() * 40), vy: (Math.random() - 0.5) * 40,
        life: 0.3, max: 0.3, col: "#b07aff", size: 2 + Math.random() * 2
      });
    } else {
      sfx("Reflect", 0.35);
      const col = ({ madeira:"#8b5a2b", bronze:"#cd7f32", ferro:"#a8c0d8", ouro:"#ffd36e", diamante:"#7ad7ff", herdeira:"#ffb7ff" })[S.sword] || "#ffd36e";
      for (let i = 0; i < 6; i++) parts.push({
        x: P.x + P.face * (12 + i * 3), y: P.y - 14 + (Math.random() - 0.5) * 10,
        vx: P.face * (40 + Math.random() * 40), vy: (Math.random() - 0.5) * 30,
        life: 0.25, max: 0.25, col, size: 2 + Math.random() * 2
      });
    }
  }
  if (P.atk > 0.08 && !P.atkHit && S.character !== "aural" && S.charAttack !== "magic") {
    P.atkHit = true;
    const reach = 24 + (S.swordRank || 0) * 4;
    const hx = P.x + P.face * (12 + reach / 2), hy = P.y - 10;
    for (const e of ents) {
      if (e.alive === false) continue;
      if (!["beetle", "hedge", "acorn"].includes(e.t)) continue;
      if (Math.abs(e.px - hx) < reach / 2 + e.w / 2 && Math.abs(e.py - 8 - hy) < 18) {
        e.alive = false;
        sfx("Enemy_Death");
        burst(e.px, e.py - 8, 12, e.t === "acorn" ? "#e0a050" : "#c33", 100, 0.5);
        S.coins += 1; S.coinsEarned = (S.coinsEarned || 0) + 1; S.coinsTowardChest = (S.coinsTowardChest || 0) + 1;
      }
    }
    if (boss && !boss.dead && boss.state === "vuln") {
      const bb = { x: boss.x, y: boss.y - boss.h / 2 };
      if (Math.abs(bb.x - hx) < 30 && Math.abs(bb.y - hy) < 40) {
        boss.hp -= 1 + Math.floor((S.swordRank || 0) / 2);
        boss.flash = 0.25;
        sfx("Enemy_Hurt");
        burst(boss.x, boss.y - 50, 10, "#fff", 120, 0.5);
        if (boss.hp <= 0) { boss.dead = true; boss.dying = 0; }
      }
    }
  }
  P.anim += dt;
}
function nearEnt(t, r = 28) { return ents.find(e => e.t === t && e.alive !== false && Math.abs(e.px - P.x) < r && Math.abs(e.py - P.y) < 40); }
function updateEnts(dt) {
  const spawn = [];
  for (const e of ents) {
    if (e.alive === false) continue; e.anim += dt;
    if (e.t === "frag") {
      if (!P.dead && P.pw.magnet > 0) { const dx = P.x - e.px, dy = (P.y - 12) - e.py, d = Math.hypot(dx, dy); if (d < 90 && d > 1) { e.px += dx / d * 230 * dt; e.py += dy / d * 230 * dt; } }
      if (!P.dead && Math.abs(e.px - P.x) < 16 && Math.abs(e.py - (P.y - 12)) < 20) collect(e);
    }
    else if (e.t === "pw") { if (!P.dead && Math.abs(e.px - P.x) < 18 && Math.abs(e.py - (P.y - 12)) < 24) takePw(e); }
    else if (e.t === "cannon") cannon(e, dt);
    else if (e.t === "boulder") { e.timer -= dt; if (e.timer <= 0 && Math.abs(P.x - e.px) < 460 && P.x > e.x0 * TS - 120) { e.timer = e.every || 5; spawn.push({t:"boulderB", px:e.px, py:e.py, w:26, h:26, vy:0, anim:0, alive:true, x0:e.x0 * TS - 40}); if (Math.abs(P.x - e.px) < 330) sfx("Boulder", 0.35); } }
    else if (e.t === "boulderB") boulderB(e, dt);
    else if (e.t === "light") { if (!P.dead && Math.abs(e.px - P.x) < 18 && Math.abs(e.py - P.y) < 40) checkpoint(e); }
    else if (e.t === "spring") { if (e.bt > 0) e.bt -= dt; if (!P.dead && P.vy >= 0 && Math.abs(e.px - P.x) < 18 && P.y > e.py - 16 && P.y < e.py + 6) { P.vy = -640; e.bt = 0.3; sfx("Spring"); } }
    else if (["beetle","hedge","acorn"].includes(e.t)) walker(e, dt);
    else if (e.t === "stal") stal(e, dt);
  }
  // interações
  if (!P.dead && pressed.up) {
    const chest = nearEnt("chest");
    const train = nearEnt("trainDoor");
    const m = nearEnt("mara") || nearEnt("marco") || nearEnt("stone");
    const d = nearEnt("door");
    if (chest && !chest.opened) {
      chest.opened = true;
      openSacrificeChest();
    } else if (train) {
      // Porta Treino de Deus
      S.fadeDir = 1; S.fade = 0; sfx("Door_Enter");
      S.fadeCb = () => {
        const trainL = buildTrainLevel();
        // injeta nível de treino temporário
        LEVELS._train = trainL;
        S._returnLvl = S.lvl;
        S.lvl = -1; L = trainL;
        // reusa load parcial
        ents = []; orbs = []; parts = []; boss = null;
        trainL.ents.forEach((e, k) => {
          const o = Object.assign({}, e, { id: "train:" + k, anim: 0, alive: true });
          o.px = (o.x + (o.t === "frag" ? 0 : 0.5)) * TS; o.py = o.y * TS;
          if (o.t === "frag") { o.px = o.x * TS; o.py = o.y * TS; }
          else { o.px = o.x * TS + 16; o.py = o.y * TS; }
          if (["beetle","hedge","acorn"].includes(o.t)) { o.dir = -1; o.vy = 0; o.w = 20; o.h = 16; }
          ents.push(o);
        });
        P.x = 2 * TS + 16; P.y = 6 * TS; P.vx = 0; P.vy = 0; P.dead = false;
        cam.x = 0; S.banner = 2.5; S.mode = "play";
        S.toast = { text: "Treino de Deus — teste seu poder. Saia pela porta dourada.", t: 5, nome: "TREINO", desc: S.activePowerName || "Poder", col: "#ffd36e" };
        music(trainL.music);
        S.fadeDir = -1; S.fade = 1;
      };
    } else if (m && !(d && !m)) {
      if (m.t === "stone") { if (!S.bridge) { say("PONTE_B", () => buildBridge()); } else say("PONTE_C"); }
      else {
        say(m.seq, () => {
          if (m.t === "mara" && S.lvl === 0 && S.swordRank < 1) {
            S.sword = "bronze"; S.swordRank = 1;
            S.toast = { text: "Espada de Bronze recebida! Agora você carrega a lâmina do vento.", t: 5, nome: "ESPADA", desc: "Bronze", col: "#cd7f32" };
            burst(P.x, P.y - 20, 18, "#cd7f32", 120, 0.8); sfx("Collectible_2", 0.7);
          }
          if (m.seq === "SECRET_CODE") {
            S.toast = { text: "Código revelado: AUR-7K9-ESPADA — digite-o em qualquer fase!", t: 6, nome: "CÓDIGO", desc: "Herdeira", col: "#ffb7ff" };
          }
        });
      }
    } else if (d && !S.fadeDir) {
      // saindo do treino: volta à fase
      if (L && L.train && S._returnLvl != null) {
        S.fadeDir = 1; S.fade = 0; sfx("Door_Enter");
        S.fadeCb = () => {
          const back = S._returnLvl; S._returnLvl = null;
          loadLevel(back); S.mode = "play";
          S.fadeDir = -1; S.fade = 1;
        };
      } else endLevel();
    }
  }
  ents = ents.filter(e => e.alive !== false).concat(spawn);
}
function takePw(e) {
  e.alive = false; const d = PW[e.kind]; S.collected.add(e.id); sfx("Collectible_2", 0.5); burst(e.px, e.py, 14, d.col, 100, 0.6);
  if (e.kind === "heart") { S.hp = Math.min(S.maxHp, S.hp + 1); } else { P.pw[e.kind] = d.dur; if (e.kind === "wing") P.extra = 1; }
  S.toast = {t:3.2, nome:d.nome, desc:d.desc, col:d.col};
}
function cannon(e, dt) {
  e.cd -= dt; if (e.rec > 0) e.rec -= dt;
  const front = (P.x - e.px) * e.dir > 0 && Math.abs(P.x - e.px) < 340 && Math.abs(P.x - e.px) > 40;
  if (e.cd <= 0 && front && !P.dead) { e.cd = 2.6; e.rec = 0.18; orbs.push({x:e.px + e.dir * 14, y:e.py - 14, vx:e.dir * 125, vy:0, t:0, spr:"cball", r:7}); sfx("Cannon", 0.4); burst(e.px + e.dir * 16, e.py - 14, 5, "#ddd", 40, 0.3); }
}
function boulderB(e, dt) {
  e.anim += dt; const body = {x:e.px, y:e.py, w:e.w, h:e.h, vx:0, vy:e.vy}; body.vy = Math.min(body.vy + 1000 * dt, 400); body.hitWall = false;
  moveX(body, -95 * dt); moveY(body, body.vy * dt); e.vy = body.vy; e.px = body.x; e.py = body.y;
  if (body.hitWall || e.px < e.x0 || e.py > L.h * TS + 40) { e.alive = false; burst(e.px, e.py - 10, 8, "#b8742a", 80, 0.5); return; }
  if (!P.dead && ov(P, {x:e.px, y:e.py, w:e.w, h:e.h})) hurt({x:e.px});
}
function walker(e, dt) {
  const sp = e.t === "acorn" ? 62 : e.t === "hedge" ? 52 : 38;
  const body = {x:e.px, y:e.py, w:e.w, h:e.h, vx:0, vy:e.vy};
  body.vy = Math.min(body.vy + 1000 * dt, 400); e.hitWall = false; body.hitWall = false;
  moveX(body, e.dir * sp * dt); moveY(body, body.vy * dt); e.vy = body.vy;
  const fx = body.x + e.dir * (e.w / 2 + 2), under = tileAt(Math.floor(fx / TS), Math.floor((body.y + 2) / TS));
  if (body.hitWall || (body.onG && under !== 1 && under !== 2)) e.dir *= -1;
  e.px = body.x; e.py = body.y;
  if (e.py > L.h * TS + 60) { e.alive = false; return; }
  if (P.dead) return;
  const eb = {x:e.px, y:e.py, w:e.w, h:e.h};
  if (ov(P, eb)) {
    const stomp = P.vy > 40 && P.y - 6 < e.py - e.h + 8 && e.t !== "hedge";
    if (stomp) { e.alive = false; sfx("Enemy_Death"); burst(e.px, e.py - 8, 10, e.t === "acorn" ? "#e0a050" : "#c33", 90, 0.5); P.vy = down.jump ? -380 : -250; }
    else hurt(eb);
  }
}
function stal(e, dt) {
  if (e.state === "hang") { if (!P.dead && Math.abs(e.px - P.x) < 30 && P.y > e.py) { e.state = "shake"; e.sh = 0.45; } }
  else if (e.state === "shake") { e.sh -= dt; if (e.sh <= 0) { e.state = "fall"; } }
  else if (e.state === "fall") {
    e.vy += 900 * dt; e.py += e.vy * dt;
    const t = tileAt(Math.floor(e.px / TS), Math.floor((e.py + 28) / TS));
    if (t === 1 || e.py > L.h * TS + 40) { e.alive = false; sfx("Stalactite", 0.5); burst(e.px, e.py + 24, 10, "#a9a0b8", 90, 0.5); return; }
    if (!P.dead && Math.abs(e.px - P.x) < 12 && P.y - P.h < e.py + 28 && P.y > e.py) { hurt({x:e.px}); e.alive = false; burst(e.px, e.py + 24, 10, "#a9a0b8", 90, 0.5); }
  }
}
function updatePipa(dt) {
  if (!P) return; const tx = P.x - P.face * 22, ty = P.y - 38 + Math.sin(S.t * 5) * 4;
  pipa.x += (tx - pipa.x) * Math.min(1, 6 * dt); pipa.y += (ty - pipa.y) * Math.min(1, 6 * dt); pipa.f += dt * 10;
}
function updateParts(dt) { for (const p of parts) { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 120 * dt; } parts = parts.filter(p => p.life > 0); }
function updateOrbs(dt) {
  for (const o of orbs) {
    o.x += o.vx * dt; o.y += o.vy * dt; o.t += dt;
    if (o.magic) o.vy += 40 * dt; // leve arco
    const lifeMax = o.life || 6;
    if (tileAt(Math.floor(o.x / TS), Math.floor(o.y / TS)) === 1 || o.t > lifeMax) {
      o.dead = true; burst(o.x, o.y, 4, o.magic ? "#b07aff" : "#fff", 40, 0.3);
      continue;
    }
    if (o.friendly || o.magic) {
      // magia do jogador: acerta inimigos e chefe
      for (const e of ents) {
        if (e.alive === false || !["beetle","hedge","acorn"].includes(e.t)) continue;
        if (Math.hypot(o.x - e.px, o.y - (e.py - 8)) < 16) {
          e.alive = false; o.dead = true;
          sfx("Enemy_Death"); burst(e.px, e.py - 8, 12, "#b07aff", 100, 0.5); S.coins += 1; S.coinsEarned = (S.coinsEarned || 0) + 1; S.coinsTowardChest = (S.coinsTowardChest || 0) + 1;
          break;
        }
      }
      if (!o.dead && boss && !boss.dead) {
        if (Math.hypot(o.x - boss.x, o.y - (boss.y - 40)) < 36) {
          o.dead = true;
          if (boss.state === "vuln") {
            boss.hp -= 1 + Math.floor((S.swordRank || 0) / 2);
            boss.flash = 0.25; sfx("Enemy_Hurt");
            burst(boss.x, boss.y - 50, 10, "#b07aff", 120, 0.5);
            if (boss.hp <= 0) { boss.dead = true; boss.dying = 0; }
          } else sfx("Reflect", 0.3);
        }
      }
    } else if (!P.dead && Math.hypot(o.x - P.x, o.y - (P.y - 11)) < (o.r || 7) + 5) {
      o.dead = true; hurt({ x: o.x });
    }
  }
  orbs = orbs.filter(o => !o.dead);
}
function updateCut(dt) {
  cut.t += dt;
  const cx = Math.max(0, Math.min(L.w * TS - VW, 29 * TS - VW / 2));
  cam.x += (cx - cam.x) * Math.min(1, dt * 3);
  if (cut.stage === "build") {
    while (cut.i < L.planks.length && cut.t > 0.7 + cut.i * 0.13) {
      const p = L.planks[cut.i]; p.built = true; p.bob = 1; L.g[p.y][p.x] = 2;
      note(PENTA[cut.i % PENTA.length], 0.4, "triangle", 0.13); if (cut.i % 3 === 0) sfx(cut.i % 2 ? "Collectible_1" : "Collectible_2", 0.3);
      burst(p.x * TS + 16, p.y * TS, 3, "#ffd36e", 40, 0.5); cut.i++;
    }
    if (cut.i >= L.planks.length && cut.t > 0.7 + L.planks.length * 0.13 + 0.8) { S.bridge = true; cut = null; say("PONTE_C"); }
  }
  updateParts(dt); updatePipa(dt);
  for (const k of Object.keys(pressed)) pressed[k] = false;
}

/* ---------------- chefe ---------------- */
function updateBoss(dt) {
  const b = boss; b.t += dt; if (b.flash > 0) b.flash -= dt;
  if (b.dead) { b.dying += dt; if (Math.random() < 0.5) burst(b.x + (Math.random() - 0.5) * 40, b.y - Math.random() * 90, 6, Math.random() < 0.5 ? "#fff" : "#8ee7ff", 120, 0.6);
    if (b.dying > 2.4 && !b.gone) { b.gone = true; S.flash = 0.5; sfx("Enemy_Death"); say("GUARDIAO_FIM", () => { ents.push({t:"door", px:11.5 * TS, py:6 * TS, alive:true, anim:0}); music("Kiwi_Temple"); }); }
    return; }
  if (b.state === "wait") { if (!b.started) { b.started = true; } if (!dlg && S.banner < 1.5) { b.state = "idle"; b.t = 0; } return; }
  const fast = b.hp <= 3;
  if (b.state === "idle") {
    const d = Math.sign(P.x - b.x); b.x = Math.max(3.8 * TS, Math.min(9.6 * TS, b.x + d * (fast ? 60 : 38) * dt));
    if (b.t > (fast ? 0.7 : 1.1)) { b.state = "charge"; b.t = 0; }
  } else if (b.state === "charge") {
    if (b.t > (fast ? 0.5 : 0.75)) {
      b.state = "vuln"; b.t = 0; sfx("Reflect", 0.4);
      const n = fast ? 5 : 3, base = Math.atan2((P.y - 14) - (b.y - 70), P.x - b.x);
      for (let i = 0; i < n; i++) { const a = base + (i - (n - 1) / 2) * 0.32; orbs.push({x:b.x, y:b.y - 70, vx:Math.cos(a) * (fast ? 125 : 105), vy:Math.sin(a) * (fast ? 125 : 105), t:0}); }
    }
  } else if (b.state === "vuln") { if (b.t > (fast ? 1.7 : 2.2)) { b.state = "idle"; b.t = 0; } }
  else if (b.state === "stun") { if (b.t > 0.7) { b.state = "idle"; b.t = 0; } }
  // contato
  if (P.dead) return;
  const bb = {x:b.x, y:b.y, w:b.w, h:b.h};
  if (ov(P, bb)) {
    const top = b.y - b.h;
    if (P.vy > 60 && P.y - 8 < top + 16) {
      P.vy = -380; P.y = top;
      if (b.state === "vuln") {
        b.hp--; b.flash = 0.4; b.state = "stun"; b.t = 0; sfx("Enemy_Hurt"); S.shake = 0.3; burst(b.x, top + 10, 14, "#8ee7ff", 120, 0.6);
        if (b.hp <= 0) { b.dead = true; b.state = "dead"; orbs = []; music(null); }
        else if (!b.first) { b.first = true; say("GUARDIAO_PRIMEIRO"); }
        else if (b.hp <= 3 && !b.half) { b.half = true; say("GUARDIAO_METADE"); }
      } else sfx("Reflect", 0.4);
    } else hurt(bb);
  }
}

/* ---------------- título ---------------- */
function toTitle() { S.mode = "title"; S.t = 0; music("Kiwi_TitleMaybe"); S.fade = 0; S.fadeDir = 0; }
function toSplash() {
  S.mode = "splash";
  S.t = 0;
  S.fade = 0;
  S.fadeDir = 0;
  music(null);
}
function updateSplash(dt) {
  // Timeline estilo logo Garena (~3.2s, skip a qualquer momento)
  if (pressed.ok || pressed.jump || pressed.pause || pressed.attack) {
    toTitle();
    for (const k of Object.keys(pressed)) pressed[k] = false;
    return;
  }
  if (S.t > 3.4) toTitle();
  for (const k of Object.keys(pressed)) pressed[k] = false;
}
function renderSplash() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.imageSmoothingEnabled = false;
  const t = S.t;
  // fundo preto → leve azul
  const bgA = Math.min(1, t * 0.8);
  ctx.fillStyle = "#000";
  ctx.fillRect(0, 0, 896, 512);
  ctx.fillStyle = "rgba(8,16,40," + (0.35 * Math.min(1, t * 0.5)) + ")";
  ctx.fillRect(0, 0, 896, 512);

  // brilho radial atrás do logo
  const glowIn = Math.max(0, Math.min(1, (t - 0.25) / 0.6));
  const glowOut = t > 2.6 ? Math.max(0, 1 - (t - 2.6) / 0.7) : 1;
  const gAlpha = glowIn * glowOut;
  if (gAlpha > 0.01) {
    const grd = ctx.createRadialGradient(448, 250, 10, 448, 250, 280);
    grd.addColorStop(0, "rgba(120,200,255," + (0.35 * gAlpha) + ")");
    grd.addColorStop(0.45, "rgba(40,100,180," + (0.12 * gAlpha) + ")");
    grd.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 896, 512);
  }

  // escala e fade do nome (entra com zoom suave)
  const nameIn = Math.max(0, Math.min(1, (t - 0.45) / 0.55));
  const nameOut = t > 2.7 ? Math.max(0, 1 - (t - 2.7) / 0.6) : 1;
  const nameA = nameIn * nameOut;
  const scale = 0.82 + 0.18 * (1 - Math.pow(1 - nameIn, 2)); // ease-out scale
  if (nameA > 0.01) {
    ctx.save();
    ctx.globalAlpha = nameA;
    ctx.translate(448, 230);
    ctx.scale(scale, scale);
    // sombra
    ctx.fillStyle = "rgba(0,0,0,0.45)";
    ctx.font = "bold 52px system-ui,sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("AS ILHAS DE", 2, -28);
    ctx.fillText("AURALIS", 2, 28);
    // título
    ctx.fillStyle = "#ffffff";
    ctx.fillText("AS ILHAS DE", 0, -30);
    ctx.fillStyle = "#ffd36e";
    ctx.fillText("AURALIS", 0, 26);
    // linha dourada
    const lw = 180 * nameIn;
    ctx.fillStyle = "rgba(255,211,110," + nameA + ")";
    ctx.fillRect(-lw / 2, 58, lw, 3);
    ctx.restore();
  }

  // kiwi pequeno sobe no fim
  const kiwiIn = Math.max(0, Math.min(1, (t - 1.15) / 0.4));
  const kiwiOut = t > 2.7 ? Math.max(0, 1 - (t - 2.7) / 0.55) : 1;
  if (kiwiIn * kiwiOut > 0.01 && IMG["player_mask-idle-0"] && IMG["player_mask-idle-0"].width) {
    ctx.save();
    ctx.globalAlpha = kiwiIn * kiwiOut;
    ctx.translate(448, 360 - (1 - kiwiIn) * 20);
    ctx.scale(2.4, 2.4);
    ctx.drawImage(IMG["player_mask-idle-" + (Math.floor(t * 3) % 2)], -16, -32);
    ctx.restore();
  }

  // "toque para pular" só depois de 1.2s
  if (t > 1.4 && t < 2.8) {
    ctx.globalAlpha = 0.45 + 0.25 * Math.sin(t * 4);
    T_("toque para pular", 448, 480, 14, "#9ab", "center", false);
    ctx.globalAlpha = 1;
  }
}
function startFromSlot(slot, continueGame) {
  if (S.fadeDir) return;
  activeSlot = slot;
  try { localStorage.setItem("auralis_active_slot", String(slot)); } catch (e) {}
  const saveData = readSlot(slot);
  menuLock = 0.4;
  S.fadeDir = 1;
  S.fade = 0;
  S.fadeCb = () => {
    if (continueGame && saveData && saveData.level > 0 && !saveData.finished) {
      newGame(saveData.level);
      applySaveToState(saveData);
    } else {
      newGame(0);
    }
    if (!storageOk) {
      S.toast = { text: "Save indisponível neste aparelho. Progresso pode não gravar.", t: 5, nome: "AVISO", desc: "Armazenamento", col: "#ffd36e" };
    }
    S.fadeDir = -1; S.fade = 1;
  };
}
function titleItems() {
  const ch = CHARACTERS[S.character] || CHARACTERS.kiwi;
  return [
    { t: () => "JOGAR / SAVES", fn: () => { S.mode = "slots"; S.t = 0; S.slotSel = 0; S.slotAction = 0; }, keep: true },
    { t: () => "HERÓI: " + ch.nome + " (" + ch.afinidade + ")", fn: () => { S.mode = "chars"; S.t = 0; S.charSel = Object.keys(CHARACTERS).indexOf(S.character || "kiwi"); }, keep: true },
    { t: () => "CONTROLES", fn: () => { S.mode = "help"; S.t = 0; }, keep: true },
    { t: () => "SOM: " + (muted ? "DESLIGADO" : "LIGADO"), fn: () => setMuted(!muted), keep: true },
    { t: () => "CRÉDITOS", fn: () => { S.mode = "credits"; S.t = 0; }, keep: true }
  ];
}
function updateTitle(dt) {
  if (menuLock > 0) menuLock -= dt;
  const it = titleItems(), n = it.length; if (S.titleSel >= n) S.titleSel = 0;
  if (pressed.up) { S.titleSel = (S.titleSel + n - 1) % n; sfx("Menu_Move"); }
  if (pressed.down) { S.titleSel = (S.titleSel + 1) % n; sfx("Menu_Move"); }
  if ((pressed.ok || pressed.jump) && !S.fadeDir && menuLock <= 0) {
    menuLock = 0.4; sfx("Menu_Select"); it[S.titleSel].fn();
  }
  for (const k of Object.keys(pressed)) pressed[k] = false;
}
function updateChars(dt) {
  if (menuLock > 0) menuLock -= dt;
  const ids = Object.keys(CHARACTERS);
  if (S.charSel == null || S.charSel < 0) S.charSel = 0;
  if (pressed.left || pressed.up) { S.charSel = (S.charSel + ids.length - 1) % ids.length; sfx("Menu_Move"); }
  if (pressed.right || pressed.down) { S.charSel = (S.charSel + 1) % ids.length; sfx("Menu_Move"); }
  if (pressed.pause) { S.mode = "title"; S.t = 0; }
  if ((pressed.ok || pressed.jump) && menuLock <= 0) {
    const id = ids[S.charSel];
    if (isCharUnlocked(id)) {
      S.character = id;
      applyCharacterPassives();
      menuLock = 0.35; sfx("Menu_Select");
      S.mode = "title"; S.t = 0;
      S.toast = { text: CHARACTERS[id].nome + " — " + CHARACTERS[id].afinidade, t: 3, nome: "HERÓI", desc: CHARACTERS[id].desc, col: "#ffd36e" };
    } else {
      menuLock = 0.35;
      S.toast = { text: "Termine a campanha 1x para desbloquear.", t: 3, nome: "BLOQUEADO", desc: CHARACTERS[id].nome, col: "#ff7a7a" };
    }
  }
  for (const k of Object.keys(pressed)) pressed[k] = false;
}
function renderChars() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "#080d20"; ctx.fillRect(0, 0, 896, 512);
  T_("ESCOLHA DE HERÓI", 448, 50, 30, "#ffd36e", "center");
  T_("Afinidade muda o estilo e a dificuldade base", 448, 78, 14, "#9ab", "center");
  const ids = Object.keys(CHARACTERS);
  S.menuRows = [];
  ids.forEach((id, i) => {
    const c = CHARACTERS[id];
    const x = 80 + i * 260;
    const y = 120;
    const sel = S.charSel === i;
    const unlocked = isCharUnlocked(id);
    S.menuRows.push({ y: y + 140, i, x0: x, x1: x + 240 });
    ctx.fillStyle = sel ? "rgba(30,100,150,0.6)" : "rgba(12,20,40,0.75)";
    ctx.fillRect(x, y, 240, 280);
    ctx.strokeStyle = sel ? "#8ee7ff" : "#3a5070";
    ctx.lineWidth = 3;
    ctx.strokeRect(x, y, 240, 280);
    // preview sprite
    ctx.save();
    ctx.translate(x + 120, y + 110);
    if (c.draw === "kiwi" && IMG["player_mask-idle-0"]) {
      ctx.scale(3, 3); ctx.drawImage(IMG["player_mask-idle-0"], -16, -32);
    } else if (c.draw === "brisa" && IMG["playergraphics-idle-000"]) {
      ctx.drawImage(IMG["playergraphics-idle-000"], -32, -48, 64, 64);
    } else if (c.draw === "aural" && IMG["j2_playeranimations-idle-000"]) {
      ctx.drawImage(IMG["j2_playeranimations-idle-000"], -40, -56, 80, 80);
    }
    ctx.restore();
    T_(c.nome, x + 120, y + 180, 22, unlocked ? "#fff" : "#667", "center");
    T_(c.afinidade, x + 120, y + 208, 16, unlocked ? "#ffd36e" : "#555", "center");
    T_(unlocked ? c.desc : "🔒 Termine a campanha", x + 120, y + 250, 12, unlocked ? "#cfefff" : "#886", "center");
    if (sel && unlocked) T_("▶ SELECIONAR", x + 120, y + 360, 14, "#8ee7ff", "center");
  });
  T_("◀ VOLTAR", 448, 480, 16, "#8ee7ff", "center");
  S.menuRows.push({ y: 480, i: 99 });
}
function updateSlots(dt) {
  if (menuLock > 0) menuLock -= dt;
  if (S.slotSel == null) S.slotSel = 0;
  if (S.slotAction == null) S.slotAction = 0;
  if (pressed.up) { S.slotSel = (S.slotSel + 2) % 3; sfx("Menu_Move"); }
  if (pressed.down) { S.slotSel = (S.slotSel + 1) % 3; sfx("Menu_Move"); }
  if (pressed.left || pressed.right) { S.slotAction = S.slotAction ? 0 : 1; sfx("Menu_Move"); }
  if (pressed.pause) { S.mode = "title"; S.t = 0; }
  if ((pressed.ok || pressed.jump) && menuLock <= 0 && !S.fadeDir) {
    menuLock = 0.4;
    sfx("Menu_Select");
    const data = readSlot(S.slotSel);
    if (S.slotAction === 1 && data) {
      clearSlot(S.slotSel);
      S.toast = { text: "Slot " + (S.slotSel + 1) + " apagado.", t: 2.5, nome: "SAVE", desc: "Vazio", col: "#ffd36e" };
      S.slotAction = 0;
    } else if (data && data.level > 0 && !data.finished) {
      startFromSlot(S.slotSel, true);
    } else {
      startFromSlot(S.slotSel, false);
    }
  }
  for (const k of Object.keys(pressed)) pressed[k] = false;
}
function renderSlots() {
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.fillStyle = "#080d20"; ctx.fillRect(0, 0, 896, 512);
  T_("SLOTS DE SAVE", 448, 48, 32, "#ffd36e", "center");
  T_("Escolha um arquivo · ← → apagar · Esc voltar", 448, 78, 14, "#9ab", "center");
  S.menuRows = [];
  for (let i = 0; i < 3; i++) {
    const data = readSlot(i);
    const y = 120 + i * 110;
    const sel = S.slotSel === i;
    S.menuRows.push({ y: y + 40, i });
    ctx.fillStyle = sel ? "rgba(30,100,150,0.55)" : "rgba(12,20,40,0.7)";
    ctx.fillRect(80, y, 736, 96);
    ctx.strokeStyle = sel ? "#8ee7ff" : "#3a5070";
    ctx.lineWidth = sel ? 3 : 2;
    ctx.strokeRect(80, y, 736, 96);
    // ícone de slot
    ctx.fillStyle = sel ? "#ffd36e" : "#5a7a9a";
    ctx.fillRect(100, y + 28, 40, 40);
    ctx.fillStyle = "#0a1020";
    T_(String(i + 1), 120, y + 56, 22, "#0a1020", "center");
    if (!data || (data.level <= 0 && !data.finished)) {
      T_("SLOT " + (i + 1) + " — VAZIO", 160, y + 40, 22, "#cfefff", "left");
      T_("Novo jogo neste slot", 160, y + 70, 16, "#889", "left");
    } else {
      const pct = data.percent != null ? data.percent : Math.round((data.level / LEVELS.length) * 100);
      T_("SLOT " + (i + 1) + "  ·  Fase " + (data.level + 1) + "/200  ·  " + pct + "%", 160, y + 34, 20, "#fff", "left");
      T_("Espada: " + (data.sword || "madeira").toUpperCase() + "   Moedas: " + (data.coins || 0), 160, y + 58, 15, "#bfefff", "left");
      T_("Salvo em: " + formatSaveTime(data.savedAt), 160, y + 80, 14, "#9ab", "left");
      // barra de progresso
      ctx.fillStyle = "#1a2a40";
      ctx.fillRect(520, y + 40, 260, 16);
      ctx.fillStyle = "#8ee7ff";
      ctx.fillRect(520, y + 40, 260 * (pct / 100), 16);
      T_(pct + "%", 650, y + 53, 13, "#fff", "center");
      if (sel && S.slotAction === 1) {
        T_("APAGAR ESTE SAVE?", 650, y + 80, 14, "#ff7a7a", "center");
      } else if (sel) {
        T_("Toque: continuar", 650, y + 80, 13, "#8ee7ff", "center");
      }
    }
  }
  T_("◀ VOLTAR AO MENU", 448, 480, 16, "#8ee7ff", "center");
  S.menuRows.push({ y: 480, i: 99 });
}

/* ---------------- desenho ---------------- */
function tint(img, w, h) { return img; }
function drawBG() {
  const th = L.bg, cx = cam.x;
  ctx.fillStyle = th === "temple" ? "#1c0b30" : "#05070d"; ctx.fillRect(-8, -8, VW + 16, VH + 16);
  const layer = (name, par, y, alpha = 1) => {
    const im = IMG[name]; if (!im.complete || !im.width) return; const w = im.width; ctx.globalAlpha = alpha;
    let x0 = -((cx * par) % w); for (let x = x0; x < VW; x += w) ctx.drawImage(im, Math.round(x), y);
    ctx.globalAlpha = 1;
  };
  if (th === "day") { layer("bg_forest_2", 0.05, 0); layer("bg_forest_4", 0.35, 16); }
  else if (th === "dusk") { layer("bg_forest_2", 0.05, 0); ctx.fillStyle = "rgba(255,120,60,0.35)"; ctx.fillRect(0, 0, VW, VH); layer("bg_forest_1", 0.35, 16); layer("bg_forest_4", 0.5, 22, 0.85); ctx.fillStyle = "rgba(90,30,60,0.28)"; ctx.fillRect(0, 0, VW, VH); }
  else if (th === "night") { layer("bg_forest_0", 0.05, 16); layer("bg_forest_1", 0.3, 16); for (let i = 0; i < 40; i++) { const x = (i * 97) % VW, y = (i * 53) % 130; ctx.fillStyle = "rgba(255,255,255," + (0.4 + 0.4 * Math.sin(S.t * 2 + i)) + ")"; ctx.fillRect(x, y, 1, 1); } }
  else if (th === "cave") { ctx.fillStyle = "#0e1424"; ctx.fillRect(0, 0, VW, VH); layer("bg_cave_0", 0.15, 8); layer("bg_cave_1", 0.35, 8); }
  else if (th === "temple") { layer("bg_temple_2", 0, 8); ctx.fillStyle = "rgba(20,0,40,0.25)"; ctx.fillRect(0, 0, VW, VH); }
}
function drawAbyss() {
  const col = {forest:"10,40,70", cave:"0,0,8", temple:"20,4,34"}[L.theme]; const g = ctx.createLinearGradient(0, 150, 0, VH);
  g.addColorStop(0, "rgba(" + col + ",0)"); g.addColorStop(0.45, "rgba(" + col + ",.8)"); g.addColorStop(1, "rgba(" + col + ",.97)"); ctx.fillStyle = g; ctx.fillRect(0, 150, VW, VH - 150);
  // névoa subindo do abismo
  ctx.save(); ctx.globalAlpha = 0.14; ctx.fillStyle = "#cfe6ff"; for (let i = 0; i < 9; i++) { const x = ((i * 97 - cam.x * 0.6 + S.t * (6 + i)) % (VW + 120) + VW + 120) % (VW + 120) - 60; ctx.beginPath(); ctx.ellipse(x, 236 + Math.sin(S.t + i) * 4, 44, 9, 0, 0, 6.3); ctx.fill(); } ctx.restore();
}
function drawSpikes(px, py, th) {
  const pulse = 0.5 + 0.5 * Math.sin(S.t * 5 + px * 0.1);
  for (let i = 0; i < 4; i++) { const bx = px + i * 8; ctx.fillStyle = th === "temple" ? "#c9cde0" : th === "cave" ? "#bfe9ff" : "#8bd13a"; ctx.beginPath(); ctx.moveTo(bx, py + 32); ctx.lineTo(bx + 4, py + 12); ctx.lineTo(bx + 8, py + 32); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = "rgba(10,10,30,.8)"; ctx.lineWidth = 1; ctx.stroke(); ctx.fillStyle = "rgba(255,60,80," + (0.55 + 0.4 * pulse) + ")"; ctx.beginPath(); ctx.moveTo(bx + 2.2, py + 18); ctx.lineTo(bx + 4, py + 12); ctx.lineTo(bx + 5.8, py + 18); ctx.closePath(); ctx.fill(); }
}
function drawTiles() {
  const th = THEME[L.theme], ts = IMG[th.ts]; const x0 = Math.floor(cam.x / TS), x1 = Math.min(L.w - 1, x0 + 15);
  const dt = (id, px, py) => { const i = id - 1; ctx.drawImage(ts, (i % 10) * 32, Math.floor(i / 10) * 32, 32, 32, px, py, 32, 32); };
  for (let y = 0; y < L.h; y++) for (let x = x0; x <= x1; x++) {
    const v = L.g[y][x]; if (!v) continue; const px = x * TS - Math.round(cam.x), py = y * TS, hsh = (x * 7 + y * 13) & 255;
    if (v === 1) { const open = y === 0 ? false : L.g[y - 1][x] !== 1; dt(open ? th.top[hsh % th.top.length] : th.fill[hsh % th.fill.length], px, py); }
    else if (v === 2) { let pl = L.planks.find(p => p.x === x && p.y === y); const bob = pl ? Math.sin(S.t * 8 - x) * pl.bob * 2 : 0; dt(th.plat[hsh % th.plat.length], px, py + bob); }
    else if (v === 3) drawSpikes(px, py, L.theme);
  }
}
function drawEnt(e) {
  const sx = Math.round(e.px - cam.x), sy = Math.round(e.py), im = n => IMG[n];
  if (e.t === "frag") {
    const y = e.py + Math.sin(S.t * 3 + e.px) * 2, x = e.px - cam.x;
    ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, y, 1, x, y, 14); g.addColorStop(0, "rgba(120,230,255,.7)"); g.addColorStop(1, "rgba(120,230,255,0)"); ctx.fillStyle = g; ctx.fillRect(x - 14, y - 14, 28, 28); ctx.restore();
    ctx.fillStyle = "#bff6ff"; ctx.beginPath(); ctx.moveTo(x, y - 7); ctx.lineTo(x + 5, y); ctx.lineTo(x, y + 7); ctx.lineTo(x - 5, y); ctx.closePath(); ctx.fill();
    ctx.fillStyle = "#4cc3ff"; ctx.beginPath(); ctx.moveTo(x, y - 7); ctx.lineTo(x + 5, y); ctx.lineTo(x, y + 2); ctx.closePath(); ctx.fill();
  } else if (e.t === "light") {
    const f = Math.floor(e.anim * 8) % 4; ctx.globalAlpha = e.on ? 1 : 0.5; ctx.drawImage(im("torch-" + f), sx - 16, sy - 64); ctx.globalAlpha = 1;
    if (e.on) { ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(sx, sy - 40, 2, sx, sy - 40, 40); g.addColorStop(0, "rgba(255,200,100,.5)"); g.addColorStop(1, "rgba(255,200,100,0)"); ctx.fillStyle = g; ctx.fillRect(sx - 40, sy - 80, 80, 80); ctx.restore(); }
  } else if (e.t === "mara") { const f = Math.floor(e.anim * 5) % 4; ctx.drawImage(im("mara-idle-" + f), sx - 16, sy - 48); if (Math.abs(e.px - P.x) < 40) prompt(sx, sy - 56, "↑ FALAR"); }
  else if (e.t === "marco") { ctx.drawImage(im("marco-0"), sx - 12, sy - 36); if (Math.abs(e.px - P.x) < 28 && Math.abs(e.py - P.y) < 40) prompt(sx, sy - 44, "↑ LER"); }
  else if (e.t === "stone") {
    ctx.drawImage(im("marco-0"), sx - 12, sy - 36); ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(sx, sy - 24, 2, sx, sy - 24, 30); g.addColorStop(0, "rgba(255,210,110," + (0.35 + 0.2 * Math.sin(S.t * 3)) + ")"); g.addColorStop(1, "rgba(255,210,110,0)"); ctx.fillStyle = g; ctx.fillRect(sx - 30, sy - 60, 60, 60); ctx.restore();
    if (Math.abs(e.px - P.x) < 32 && !cut) prompt(sx, sy - 44, "↑ TOCAR A PEDRA");
  }
  else if (e.t === "door") { ctx.drawImage(im("door"), sx - 16, sy - 64); ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(sx, sy - 30, 4, sx, sy - 30, 40); g.addColorStop(0, "rgba(140,230,255,.35)"); g.addColorStop(1, "rgba(140,230,255,0)"); ctx.fillStyle = g; ctx.fillRect(sx - 40, sy - 70, 80, 80); ctx.restore(); if (Math.abs(e.px - P.x) < 28) prompt(sx, sy - 70, L && L.train ? "↑ SAIR DO TREINO" : "↑ PRÓXIMA FASE"); }
  else if (e.t === "chest") {
    // baú dourado
    ctx.fillStyle = e.opened ? "#5a4030" : "#c9a227";
    ctx.fillRect(sx - 14, sy - 28, 28, 22);
    ctx.fillStyle = "#8b6914";
    ctx.fillRect(sx - 14, sy - 18, 28, 4);
    ctx.fillStyle = "#ffd36e";
    ctx.fillRect(sx - 3, sy - 20, 6, 6);
    if (!e.opened && Math.abs(e.px - P.x) < 32) prompt(sx, sy - 44, "↑ BAÚ-SACRIFÍCIO");
  }
  else if (e.t === "trainDoor") {
    ctx.fillStyle = "#4a2080";
    ctx.fillRect(sx - 16, sy - 56, 32, 56);
    ctx.strokeStyle = "#ffd36e"; ctx.lineWidth = 2;
    ctx.strokeRect(sx - 16, sy - 56, 32, 56);
    ctx.fillStyle = "#ffd36e";
    ctx.fillRect(sx - 4, sy - 28, 8, 8);
    if (Math.abs(e.px - P.x) < 32) prompt(sx, sy - 70, "↑ TREINO DE DEUS");
  }
  else if (e.t === "spring") { ctx.drawImage(e.bt > 0 ? im("spring-boing-" + Math.min(3, Math.floor((0.3 - e.bt) * 14))) : im("spring-0"), sx - 16, sy - 32); }
  else if (e.t === "beetle") {
    // sprites olham para a direita por padrão: dir>0 = direita (sem flip invertido = moonwalk)
    ctx.save(); ctx.translate(sx, sy); ctx.scale(e.dir >= 0 ? 1 : -1, 1);
    ctx.drawImage(im("en_beetle-walk-" + (Math.floor(e.anim * 6) % 4)), -16, -32); ctx.restore();
  }
  else if (e.t === "hedge") {
    ctx.save(); ctx.translate(sx, sy); ctx.scale(e.dir >= 0 ? 1 : -1, 1);
    ctx.drawImage(im("en_hedgehog-walk-" + (Math.floor(e.anim * 6) % 4)), -16, -32); ctx.restore();
  }
  else if (e.t === "acorn") {
    ctx.save(); ctx.translate(sx, sy); ctx.scale(e.dir >= 0 ? 1 : -1, 1);
    ctx.drawImage(im("en_acorn-" + (Math.floor(e.anim * 6) % 4)), -12, -24); ctx.restore();
  }
  else if (e.t === "pw") {
    const d = PW[e.kind], y = e.py + Math.sin(S.t * 3 + e.px) * 3, x = e.px - cam.x;
    ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, y, 2, x, y, 22); g.addColorStop(0, d.col); g.addColorStop(1, "rgba(0,0,0,0)"); ctx.globalAlpha = 0.55; ctx.fillStyle = g; ctx.fillRect(x - 22, y - 22, 44, 44); ctx.restore();
    ctx.fillStyle = "rgba(8,16,40,.85)"; ctx.beginPath(); ctx.arc(x, y, 11, 0, 6.3); ctx.fill(); ctx.strokeStyle = d.col; ctx.lineWidth = 2; ctx.stroke();
    glyph(ctx, e.kind, x, y, 7);
  }
  else if (e.t === "cannon") { ctx.save(); ctx.translate(sx - e.dir * (e.rec > 0 ? 3 : 0), sy); ctx.scale(e.dir > 0 ? -1 : 1, 1); ctx.drawImage(im("cannon"), -16, -32); ctx.restore(); }
  else if (e.t === "boulderB") { ctx.save(); ctx.translate(sx, sy - 14); ctx.rotate(-e.anim * 6); ctx.drawImage(im("boulder-" + (Math.floor(e.anim * 8) % 8)), -16, -16); ctx.restore(); }
  else if (e.t === "stal") { const sh = e.state === "shake" ? Math.sin(S.t * 60) * 1.5 : 0; ctx.drawImage(im("stalactite"), sx - 16 + sh, Math.round(e.py)); }
}
function prompt(x, y, s) { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.font = "bold 13px 'Trebuchet MS',system-ui,sans-serif"; ctx.textAlign = "center"; const w = ctx.measureText(s).width + 12; ctx.fillStyle = "rgba(5,10,25,.8)"; ctx.fillRect(x * SC - w / 2, y * SC - 14, w, 20); ctx.fillStyle = "#8ee7ff"; ctx.fillText(s, x * SC, y * SC); ctx.restore(); }
function drawPlayer() {
  if (!P.dead) { const px = Math.round(P.x - cam.x), py = Math.round(P.y - 12);
    if (P.pw.shield > 0) { ctx.save(); ctx.globalAlpha = 0.35 + 0.15 * Math.sin(S.t * 6) + (P.pw.shield < 3 ? (Math.floor(S.t * 8) % 2 ? -0.2 : 0) : 0); ctx.fillStyle = "#7ad7ff"; ctx.beginPath(); ctx.arc(px, py, 19, 0, 6.3); ctx.fill(); ctx.globalAlpha = 0.9; ctx.strokeStyle = "#dff6ff"; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore(); }
    if (P.pw.wing > 0 && (P.pw.wing > 3 || Math.floor(S.t * 8) % 2)) { ctx.save(); ctx.translate(px - P.face * 6, py - 2); ctx.globalAlpha = 0.8; glyph(ctx, "wing", 0, -4, 8 + (P.onG ? 0 : 2 * Math.sin(S.t * 18))); ctx.restore(); }
    if (P.pw.magnet > 0) { ctx.save(); ctx.globalAlpha = 0.25; ctx.strokeStyle = "#ff7a7a"; ctx.setLineDash([3, 4]); ctx.lineDashOffset = -S.t * 20; ctx.beginPath(); ctx.arc(px, py, 38 + 4 * Math.sin(S.t * 5), 0, 6.3); ctx.stroke(); ctx.restore(); } }
  if (P.dead) { if (S.dying && !S.dying.fall) { ctx.save(); ctx.translate(Math.round(P.x - cam.x), Math.round(P.y - 12)); ctx.rotate(P.spin); ctx.scale(P.face > 0 ? 1 : -1, 1); ctx.drawImage(IMG["player_mask-jump-0"], -16, -19); ctx.restore(); } return; } if (P.inv > 0 && Math.floor(P.inv * 14) % 2) return;
  const px = Math.round(P.x - cam.x), py = Math.round(P.y);
  // poeira de pouso
  if (P.landDust > 0) {
    const fi = Math.min(10, Math.floor((0.35 - P.landDust) / 0.35 * 11));
    const id = fi < 10 ? "0" + fi : String(fi);
    const dust = IMG["landingdust-default-0" + id];
    if (dust && dust.width) {
      ctx.save(); ctx.globalAlpha = Math.min(1, P.landDust * 3);
      ctx.drawImage(dust, px - dust.width / 2, py - dust.height + 4);
      ctx.restore();
    }
  }
  const chDraw = (CHARACTERS[S.character] || CHARACTERS.kiwi).draw;
  ctx.save();
  ctx.translate(px, py);
  ctx.scale(P.face >= 0 ? 1 : -1, 1);
  if (chDraw === "brisa") {
    let n;
    if (!P.onG) n = "playergraphics-jump-000";
    else if (Math.abs(P.vx) > 10) n = "playergraphics-walk-00" + (Math.floor(P.anim * 10) % 8);
    else n = "playergraphics-idle-00" + (Math.floor(P.anim * 3) % 4);
    if (P.atk > 0) n = "playergraphics-attack-000";
    const im = IMG[n];
    if (im && im.width) ctx.drawImage(im, -16, -30, 32, 32);
    else ctx.drawImage(IMG["player_mask-idle-0"], -16, -31);
  } else if (chDraw === "aural") {
    let n;
    if (!P.onG || Math.abs(P.vx) > 10) n = "j2_playeranimations-walk-00" + (Math.floor(P.anim * 8) % 6);
    else n = "j2_playeranimations-idle-00" + (Math.floor(P.anim * 4) % 7);
    const im = IMG[n];
    if (im && im.width) ctx.drawImage(im, -18, -34, 36, 36);
    else ctx.drawImage(IMG["player_mask-idle-0"], -16, -31);
  } else {
    let n; if (!P.onG) n = "player_mask-jump-0"; else if (Math.abs(P.vx) > 10) n = "player_mask-run-" + (Math.floor(P.anim * 12) % 6); else n = "player_mask-idle-" + (Math.floor(P.anim * 2.5) % 2);
    ctx.drawImage(IMG[n], -16, -31);
  }

  // Espada só para afinidade lâmina/vento (não magia)
  if (chDraw !== "aural") {
    const scols = { madeira:"#8b5a2b", bronze:"#cd7f32", ferro:"#c0d0e0", ouro:"#ffd36e", diamante:"#9ef0ff", herdeira:"#ffb7ff" };
    const scol = scols[S.sword] || "#cd7f32";
    const bladeLen = 12 + (S.swordRank || 0) * 2;
    const swinging = P.atk > 0;
    const t = swinging ? Math.min(1, (0.28 - P.atk) / 0.28) : 0;
    let ang, hx, hy;
    if (swinging) {
      const ease = t < 0.35 ? (t / 0.35) * 0.4 : 0.4 + ((t - 0.35) / 0.65) * 0.6;
      ang = -2.1 + ease * 3.4;
      hx = 7; hy = -11;
    } else {
      ang = 1.05; hx = 5; hy = -10;
    }
    ctx.save();
    ctx.translate(hx, hy);
    ctx.rotate(ang);
    ctx.fillStyle = "#5a4030"; ctx.fillRect(-4, -2.5, 6, 5);
    ctx.fillStyle = scol; ctx.fillRect(-1, -4, 3, 8);
    ctx.fillStyle = scol; ctx.fillRect(2, -1.5, bladeLen, 3);
    ctx.fillStyle = "rgba(255,255,255,0.45)"; ctx.fillRect(3, -0.5, bladeLen - 2, 1);
    ctx.beginPath();
    ctx.moveTo(2 + bladeLen, -1.5); ctx.lineTo(2 + bladeLen + 4, 0); ctx.lineTo(2 + bladeLen, 1.5);
    ctx.closePath(); ctx.fillStyle = scol; ctx.fill();
    if (swinging && t > 0.2 && t < 0.85) {
      ctx.globalAlpha = 0.35 * (1 - Math.abs(t - 0.5) * 2);
      ctx.fillStyle = scol; ctx.fillRect(2, -3, bladeLen + 2, 6); ctx.globalAlpha = 1;
    }
    ctx.restore();
    if (swinging) {
      const fi = Math.min(5, Math.floor(t * 6));
      const slash = IMG["swordslash-default-00" + fi];
      if (slash && slash.width) {
        ctx.save(); ctx.globalAlpha = 0.85; ctx.translate(10, -14);
        ctx.drawImage(slash, 0, -slash.height / 2); ctx.restore();
      }
    }
  }
  ctx.restore();
}
function drawPipa() {
  const x = pipa.x - cam.x, y = pipa.y; const act = P && Object.keys(PW).find(k => P.pw && P.pw[k] > 0); ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, y, 1, x, y, act ? 30 : 22); g.addColorStop(0, act ? PW[act].col : "rgba(255,170,230,.55)"); g.addColorStop(1, "rgba(255,170,230,0)"); ctx.fillStyle = g; ctx.fillRect(x - 32, y - 32, 64, 64); ctx.restore();
  ctx.drawImage(IMG["pipa-" + (Math.floor(pipa.f) % 3)], Math.round(x - 10), Math.round(y - 10));
}
function drawBoss() {
  const b = boss; if (b.gone) return; const x = b.x - cam.x, y = b.y;
  let n = "boss-default-0"; if (b.state === "charge") n = "boss-charge-" + (Math.floor(b.t * 10) % 2); else if (b.state === "vuln") n = "boss-shoot-0";
  ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.scale(2, 2);
  if (b.dead) ctx.globalAlpha = Math.max(0, 1 - b.dying / 2.4);
  if (b.flash > 0 && Math.floor(b.flash * 30) % 2) ctx.globalAlpha = 0.45;
  ctx.drawImage(IMG[n], -12, -45); ctx.restore();
  if (b.state === "vuln") { ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, y - 70, 2, x, y - 70, 40); g.addColorStop(0, "rgba(120,230,255,.55)"); g.addColorStop(1, "rgba(120,230,255,0)"); ctx.fillStyle = g; ctx.fillRect(x - 40, y - 110, 80, 80); ctx.restore(); }
  if (b.state === "charge") { ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, y - 70, 2, x, y - 70, 26); g.addColorStop(0, "rgba(255,80,80,.6)"); g.addColorStop(1, "rgba(255,80,80,0)"); ctx.fillStyle = g; ctx.fillRect(x - 30, y - 100, 60, 60); ctx.restore(); }
}
function drawDark() {
  if (!L.dark) return; const d = drawDark.c || (drawDark.c = document.createElement("canvas")); d.width = VW; d.height = VH; const c = d.getContext("2d");
  c.fillStyle = "rgba(2,4,14,.88)"; c.fillRect(0, 0, VW, VH); c.globalCompositeOperation = "destination-out";
  const hole = (x, y, r) => { const g = c.createRadialGradient(x, y, r * 0.15, x, y, r); g.addColorStop(0, "rgba(0,0,0,1)"); g.addColorStop(1, "rgba(0,0,0,0)"); c.fillStyle = g; c.fillRect(x - r, y - r, r * 2, r * 2); };
  hole(P.x - cam.x, P.y - 14, 120); hole(pipa.x - cam.x, pipa.y, 70);
  for (const e of ents) if (e.t === "light" && e.on) hole(e.px - cam.x, e.py - 34, 90); else if (e.t === "frag") hole(e.px - cam.x, e.py, 28); else if (e.t === "door") hole(e.px - cam.x, e.py - 30, 50);
  ctx.drawImage(d, 0, 0);
}
function T_(s, x, y, size, col, align = "left", bold = true) { ctx.font = (bold ? "bold " : "") + size + "px 'Trebuchet MS','Segoe UI',system-ui,sans-serif"; ctx.textAlign = align; ctx.fillStyle = "rgba(0,0,10,.7)"; ctx.fillText(s, x + 2, y + 2); ctx.fillStyle = col; ctx.fillText(s, x, y); }
function wrap(text, maxW) { const w = text.split(" "), out = []; let cur = ""; for (const t of w) { const n = cur ? cur + " " + t : t; if (ctx.measureText(n).width > maxW && cur) { out.push(cur); cur = t; } else cur = n; } out.push(cur); return out; }
function drawHeartIcon(x, y, full) {
  ctx.save();
  ctx.fillStyle = full ? "#ff4d6a" : "#2a1820";
  ctx.beginPath();
  ctx.moveTo(x, y + 6);
  ctx.bezierCurveTo(x - 10, y - 4, x - 12, y + 10, x, y + 16);
  ctx.bezierCurveTo(x + 12, y + 10, x + 10, y - 4, x, y + 6);
  ctx.fill();
  if (full) {
    ctx.fillStyle = "rgba(255,255,255,0.35)";
    ctx.beginPath();
    ctx.ellipse(x - 3, y + 4, 2.5, 1.8, -0.5, 0, 6.3);
    ctx.fill();
  }
  ctx.strokeStyle = "rgba(0,0,0,0.55)";
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}
function drawCoinIcon(x, y) {
  ctx.save();
  ctx.fillStyle = "#e8b84a";
  ctx.beginPath(); ctx.arc(x, y, 9, 0, 6.3); ctx.fill();
  ctx.fillStyle = "#ffd36e";
  ctx.beginPath(); ctx.arc(x - 1, y - 1, 7, 0, 6.3); ctx.fill();
  ctx.strokeStyle = "#a67c2a"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.arc(x, y, 9, 0, 6.3); ctx.stroke();
  ctx.fillStyle = "#a67c2a";
  ctx.font = "bold 10px system-ui"; ctx.textAlign = "center"; ctx.textBaseline = "middle";
  ctx.fillText("A", x, y + 1);
  ctx.restore();
}
function drawFragIcon(x, y) {
  ctx.save();
  const g = ctx.createLinearGradient(x - 8, y - 8, x + 8, y + 8);
  g.addColorStop(0, "#9ef0ff"); g.addColorStop(1, "#3a9fff");
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.moveTo(x, y - 10); ctx.lineTo(x + 8, y); ctx.lineTo(x, y + 10); ctx.lineTo(x - 8, y);
  ctx.closePath(); ctx.fill();
  ctx.fillStyle = "rgba(255,255,255,0.5)";
  ctx.beginPath(); ctx.moveTo(x, y - 6); ctx.lineTo(x + 3, y); ctx.lineTo(x, y + 2); ctx.closePath(); ctx.fill();
  ctx.restore();
}
function drawHUD() {
  ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0);
  for (let i = 0; i < S.maxHp; i++) drawHeartIcon(28 + i * 28, 18, i < S.hp);
  // fragmentos + moedas (direita)
  const fx = 860;
  drawFragIcon(fx - 58, 30);
  const tt = lvlTotal();
  T_(tt ? lvlCount() + "/" + tt : String(S.totalFrags), fx, 36, 20, "#fff", "right");
  drawCoinIcon(fx - 52, 58);
  T_(String(S.coins), fx, 62, 16, "#ffd36e", "right");
  // espada atual
  const swordCols = { madeira: "#8b5a2b", bronze: "#cd7f32", ferro: "#a8c0d8", ouro: "#ffd36e", diamante: "#7ad7ff", herdeira: "#ffb7ff" };
  ctx.fillStyle = "rgba(8,16,40,0.55)";
  ctx.fillRect(12, 44, 150, 22);
  T_("⚔ " + (S.sword || "madeira").toUpperCase(), 18, 60, 13, swordCols[S.sword] || "#fff", "left");
  // poderes permanentes
  let pi = 0;
  // botão/badge do poder ativo (só depois do sacrifício)
  if (S.activePower && S.showPowerBtn) {
    const p = SACRIFICE_POWERS.find(x => x.id === S.activePower) || SACRIFICE_POWERS[0];
    const cd = S.powerCd || 0, max = S.powerCdMax || p.cd || 4;
    const ready = cd <= 0;
    ctx.fillStyle = "rgba(8,16,40,0.8)";
    ctx.fillRect(12, 78, 220, 42);
    ctx.strokeStyle = ready ? p.col : "#556"; ctx.lineWidth = 2;
    ctx.strokeRect(12, 78, 220, 42);
    // barra de recarga
    if (!ready) {
      ctx.fillStyle = "rgba(255,255,255,0.12)";
      ctx.fillRect(14, 80, 216 * (1 - cd / max), 38);
    }
    T_("⚡ " + (S.activePowerName || p.nome), 22, 96, 12, ready ? p.col : "#889", "left");
    T_(ready ? "PRONTO (Q/F)" : ("recarga " + cd.toFixed(1) + "s"), 22, 112, 11, ready ? "#9ef0a8" : "#aab", "left");
  }
  // Sol Celestial visual
  if (S.sunBeam) {
    const b = S.sunBeam;
    const bx = b.x - cam.x, by = b.y;
    ctx.save();
    ctx.globalAlpha = 0.35 + 0.25 * Math.sin(S.t * 12);
    ctx.fillStyle = "#ffe08a";
    ctx.fillRect(bx - b.w / 2, by - b.h / 2, b.w, b.h);
    ctx.globalCompositeOperation = "lighter";
    ctx.fillStyle = "rgba(255,240,180,0.5)";
    ctx.fillRect(bx - b.w / 2 - 10, by - 4, b.w + 20, 8);
    ctx.restore();
  }
  { let i = 0; for (const k of Object.keys(PW)) { if (k === "heart" || !(P.pw[k] > 0)) continue; const x = 30 + i * 52, y = 94, d = PW[k], fr = P.pw[k] / d.dur, blink = P.pw[k] < 3 && Math.floor(S.t * 8) % 2;
      ctx.globalAlpha = blink ? 0.35 : 1; ctx.fillStyle = "rgba(8,16,40,.85)"; ctx.beginPath(); ctx.arc(x, y, 18, 0, 6.3); ctx.fill();
      ctx.strokeStyle = d.col; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, 18, -Math.PI / 2, -Math.PI / 2 + 6.283 * fr); ctx.stroke(); glyph(ctx, k, x, y, 11); ctx.globalAlpha = 1; i++; } }
  if (S.toast && S.toast.t > 0) { const a = Math.min(1, S.toast.t * 2); ctx.globalAlpha = a; ctx.fillStyle = "rgba(6,12,30,.85)"; ctx.fillRect(448 - 200, 470, 400, 34); ctx.strokeStyle = S.toast.col || "#8ee7ff"; ctx.lineWidth = 2; ctx.strokeRect(448 - 199, 471, 398, 32); T_((S.toast.nome ? S.toast.nome + " — " : "") + (S.toast.desc || S.toast.text || ""), 448, 493, 15, S.toast.col || "#fff", "center"); ctx.globalAlpha = 1; }
  if (S.banner > 0 && !dlg && !S.menu && !S.dying) { const a = Math.min(1, S.banner, 3 - S.banner + 0.2); ctx.globalAlpha = Math.max(0, Math.min(1, a)); T_(L.name.toUpperCase(), 448, 150, 28, "#fff", "center"); ctx.globalAlpha = 1; }
  if (boss && boss.started && !boss.gone) {
    const w = 280, x = 448 - w / 2, y = 20, maxH = boss.maxHp || 6;
    ctx.fillStyle = "rgba(0,0,10,.7)"; ctx.fillRect(x - 3, y - 3, w + 6, 14);
    ctx.fillStyle = "#ff5a5a"; ctx.fillRect(x, y, w * Math.max(0, boss.hp) / maxH, 8);
    T_((boss.name || "CHEFE").toUpperCase(), 448, 46, 12, "#ffd0d0", "center");
  }
  if (dlg) {
    const l = dlg.lines[dlg.i], bx = 40, by = 64, bw = 816, bh = 120;
    ctx.fillStyle = "rgba(6,12,30,.92)"; ctx.fillRect(bx, by, bw, bh); ctx.strokeStyle = WHO_COL[l.who] || "#aab"; ctx.lineWidth = 3; ctx.strokeRect(bx + 1.5, by + 1.5, bw - 3, bh - 3);
    ctx.font = "bold 17px 'Trebuchet MS',system-ui,sans-serif"; ctx.textAlign = "left"; ctx.fillStyle = WHO_COL[l.who] || "#ccd"; ctx.fillText(l.who.toUpperCase(), bx + 20, by + 30);
    ctx.font = "18px 'Trebuchet MS','Segoe UI',system-ui,sans-serif"; ctx.fillStyle = "#f2f6ff"; const txt = l.text.slice(0, Math.floor(dlg.ch)); const ln = wrap(l.text, bw - 40), shown = wrap(txt, bw - 40);
    // usar quebras do texto completo para não "pular" palavras durante a digitação
    let used = 0, yy = by + 58; for (const s of ln) { const part = txt.slice(used, used + s.length + 1).trimEnd(); ctx.fillText(part.slice(0, s.length), bx + 20, yy); used += s.length + 1; yy += 26; }
    if (dlg.ch >= l.text.length && Math.floor(S.t * 2) % 2) { ctx.fillStyle = "#8ee7ff"; ctx.font = "13px system-ui"; ctx.textAlign = "right"; ctx.fillText("Z ▶", bx + bw - 16, by + bh - 12); }
  }
  if (S.dying) { ctx.fillStyle = "rgba(120,0,20," + Math.min(0.35, S.dying.t * 0.4) + ")"; ctx.fillRect(0, 0, 896, 512); }
  if (S.menu) drawMenu();
  if (S.flash > 0) { ctx.fillStyle = "rgba(255,255,255," + Math.min(1, S.flash * 2) + ")"; ctx.fillRect(0, 0, 896, 512); }
  if (S.fade > 0) { ctx.fillStyle = "rgba(0,0,0," + Math.min(1, S.fade) + ")"; ctx.fillRect(0, 0, 896, 512); }
  ctx.restore();
}
function render() {
  ctx.setTransform(SC, 0, 0, SC, 0, 0); ctx.imageSmoothingEnabled = false;
  if (S.mode === "loading") { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = "#05070d"; ctx.fillRect(0, 0, 896, 512); T_("Carregando… " + Math.floor(100 * loaded / total) + "%", 448, 260, 22, "#8ee7ff", "center"); return; }
  if (S.mode === "splash") return renderSplash();
  if (S.mode === "title") return renderTitle();
  if (S.mode === "slots") return renderSlots();
  if (S.mode === "chars") return renderChars();
  if (S.mode === "help") {
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = "#080d20"; ctx.fillRect(0, 0, 896, 512);
    T_("CONTROLES", 448, 56, 34, "#ffd36e", "center");
    const lines = [
      "◀ ▶  —  andar",
      "⤒  —  pular",
      "⚔  —  atacar com a espada",
      "⇧  —  falar / interagir / entrar",
      "Ⅱ  —  pausar",
      "",
      "Pise na cabeça dos inimigos ou ataque.",
      "Ouriços: pule por cima ou ataque.",
      "Tochas = checkpoint. Fragmentos = moedas."
    ];
    lines.forEach((t, i) => T_(t, 448, 100 + i * 30, 18, t ? "#cfefff" : "#000", "center"));
    // botão VOLTAR bem visível
    ctx.fillStyle = "rgba(30,100,150,0.7)";
    ctx.fillRect(298, 430, 300, 48);
    ctx.strokeStyle = "#8ee7ff"; ctx.lineWidth = 3;
    ctx.strokeRect(298, 430, 300, 48);
    T_("◀  VOLTAR", 448, 462, 22, "#8ee7ff", "center");
    S.menuRows = [{ y: 454, i: 0 }];
    return;
  }
  if (S.mode === "credits") {
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = "#080d20"; ctx.fillRect(0, 0, 896, 512);
    T_("CRÉDITOS", 448, 90, 36, "#ffd36e", "center");
    T_("As Ilhas de Auralis", 448, 170, 24, "#fff", "center");
    T_("Código e design: projeto original", 448, 230, 18, "#cfefff", "center");
    T_("Arte e sons: reaproveitados", 448, 270, 18, "#cfefff", "center");
    T_("Campanha expandida até 200 fases", 448, 310, 18, "#cfefff", "center");
    ctx.fillStyle = "rgba(30,100,150,0.7)";
    ctx.fillRect(298, 430, 300, 48);
    ctx.strokeStyle = "#8ee7ff"; ctx.lineWidth = 3;
    ctx.strokeRect(298, 430, 300, 48);
    T_("◀  VOLTAR", 448, 462, 22, "#8ee7ff", "center");
    S.menuRows = [{ y: 454, i: 0 }];
    return;
  }
  if (S.mode === "powerChoice") {
    const q = S.powerChoice || {};
    ctx.setTransform(1,0,0,1,0,0); ctx.fillStyle="#080d20"; ctx.fillRect(0,0,896,512);
    // animação de abertura
    const a = Math.min(1, (q.anim || 0) * 1.5);
    ctx.globalAlpha = a;
    T_("BAÚ DE SACRIFÍCIO",448,50,34,"#ffd36e","center");
    T_("Sacrifique TODAS as suas " + S.coins + " moedas",448,88,18,"#ffd36e","center");
    T_("Escolha 1 de 3 poderes — vale até o próximo sacrifício",448,114,15,"#cfefff","center");
    if (q.stage === "confirm") {
      const p = SACRIFICE_POWERS[q.sel];
      ctx.fillStyle = "rgba(20,40,70,0.9)";
      ctx.fillRect(148, 160, 600, 240);
      ctx.strokeStyle = "#ffd36e"; ctx.lineWidth = 3; ctx.strokeRect(148, 160, 600, 240);
      T_("CONFIRMAR SACRIFÍCIO?", 448, 200, 26, "#fff", "center");
      T_(p.nome, 448, 245, 22, p.col, "center");
      T_(p.desc, 448, 280, 16, "#cfefff", "center");
      T_("Este será seu poder até o próximo sacrifício. Certeza?", 448, 318, 15, "#ffd36e", "center");
      T_("Próximo sacrifício previsto em ~" + NEXT_SACRIFICE_POINTS + " pontos.", 448, 348, 14, "#9ab", "center");
      ctx.fillStyle = "rgba(30,120,80,0.7)"; ctx.fillRect(200, 370, 200, 44);
      ctx.strokeStyle = "#8ee7ff"; ctx.strokeRect(200, 370, 200, 44);
      T_("SIM, ACEITO", 300, 398, 16, "#8ee7ff", "center");
      ctx.fillStyle = "rgba(80,30,40,0.7)"; ctx.fillRect(496, 370, 200, 44);
      ctx.strokeStyle = "#ff7a7a"; ctx.strokeRect(496, 370, 200, 44);
      T_("VOLTAR", 596, 398, 16, "#ff7a7a", "center");
      S.menuRows = [
        { y: 392, i: 0, x0: 200, x1: 400, act: "yes" },
        { y: 392, i: 1, x0: 496, x1: 696, act: "no" }
      ];
    } else {
      S.menuRows = [];
      const n = SACRIFICE_POWERS.length;
      SACRIFICE_POWERS.forEach((p, i) => {
        const x = 70 + i * 200;
        S.menuRows.push({ y: 280, i, x0: x - 90, x1: x + 90 });
        ctx.fillStyle = q.sel === i ? "rgba(30,90,140,0.85)" : "rgba(12,20,40,0.85)";
        ctx.fillRect(x - 92, 145, 184, 250);
        ctx.strokeStyle = q.sel === i ? p.col : "#45516d";
        ctx.lineWidth = 3; ctx.strokeRect(x - 92, 145, 184, 250);
        T_(p.nome, x, 180, 13, p.col, "center");
        T_(p.desc, x, 230, 11, "#cfefff", "center");
        T_(p.strat, x, 290, 10, "#9ab", "center");
        T_("CD " + p.cd + "s", x, 330, 12, "#ffd36e", "center");
        if (q.sel === i) T_("▶ ESCOLHER", x, 365, 13, "#8ee7ff", "center");
      });
      T_("Toque numa carta · Esc recusa · Poder ativo: Q / F ou botão ⚡", 448, 430, 13, "#aab", "center");
      T_("Depois: porta da fase + Porta Treino de Deus", 448, 455, 12, "#889", "center");
    }
    ctx.globalAlpha = 1;
    return;
  }
  if (S.mode === "complete") {
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = "#070b18"; ctx.fillRect(0, 0, 896, 512);
    T_("FASE COMPLETA!", 448, 160, 44, "#fff", "center");
    T_(L.name, 448, 210, 20, "#8ee7ff", "center");
    { const tt = lvlTotal(), cc = lvlCount();
      T_(tt ? "Fragmentos: " + cc + "/" + tt : "Fragmentos reunidos: " + S.totalFrags, 448, 270, 24, "#bfefff", "center");
      T_("Quedas nesta fase: " + S.lvlDeaths, 448, 308, 18, "#aab", "center");
      if (tt && cc === tt) T_("★ Perfeito! Todos os fragmentos ★", 448, 348, 20, "#ffd36e", "center");
    }
    if (S.t > 0.5) {
      ctx.fillStyle = "rgba(30,100,150,0.75)";
      ctx.fillRect(273, 400, 350, 52);
      ctx.strokeStyle = "#8ee7ff"; ctx.lineWidth = 3;
      ctx.strokeRect(273, 400, 350, 52);
      T_("▶  CONTINUAR", 448, 434, 24, "#8ee7ff", "center");
      T_("Toque na tela ou Z/Enter", 448, 480, 14, "#889", "center");
    }
    if (S.fade > 0) { ctx.fillStyle = "rgba(0,0,0," + S.fade + ")"; ctx.fillRect(0, 0, 896, 512); }
    return;
  }
  if (S.mode === "ending") { ctx.setTransform(1, 0, 0, 1, 0, 0); const g = ctx.createLinearGradient(0, 0, 0, 512); g.addColorStop(0, "#0a1030"); g.addColorStop(1, "#1d2f5a"); ctx.fillStyle = g; ctx.fillRect(0, 0, 896, 512);
    T_("AS ILHAS DE AURALIS", 448, 150, 48, "#fff", "center"); T_(FALAS.S04[1], 448, 230, 22, "#bfefff", "center"); T_("Fragmentos reunidos: " + S.totalFrags, 448, 290, 20, "#fff", "center");
    T_("Base de arte/sons: projetos recebidos — veja CREDITOS.md", 448, 350, 14, "#aab", "center", false); if (S.t > 2) T_("Pressione Enter para voltar ao título", 448, 420, 16, "#8ee7ff", "center"); return; }
  const sh = S.shake > 0 ? (Math.random() - 0.5) * 6 : 0; ctx.translate(sh, sh * 0.6);
  drawBG(); drawAbyss(); drawTiles();
  if (L.end) drawLighthouse();
  for (const e of ents) if (e.t !== "frag") drawEnt(e);
  if (boss) drawBoss();
  drawPlayer(); drawPipa();
  for (const e of ents) if (e.t === "frag") drawEnt(e);
  for (const o of orbs) { if (o.spr) ctx.drawImage(IMG[o.spr], Math.round(o.x - cam.x - 8), Math.round(o.y - 8)); else ctx.drawImage(IMG["orb-" + (Math.floor(o.t * 12) % 4)], Math.round(o.x - cam.x - 7), Math.round(o.y - 7)); }
  for (const p of parts) { ctx.globalAlpha = Math.max(0, p.life / p.max); ctx.fillStyle = p.col; ctx.fillRect(Math.round(p.x - cam.x), Math.round(p.y), p.size, p.size); } ctx.globalAlpha = 1;
  drawDark();
  { const vg = ctx.createRadialGradient(VW / 2, VH / 2, VH * 0.45, VW / 2, VH / 2, VW * 0.62); vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, "rgba(0,0,0,.35)"); ctx.fillStyle = vg; ctx.fillRect(0, 0, VW, VH); }
  ctx.setTransform(SC, 0, 0, SC, 0, 0);
  drawHUD();
}
function drawLighthouse() {
  const x = 9 * TS - cam.x, lit = S.seen.FAROL_B; ctx.fillStyle = "#cfd6e6"; ctx.beginPath(); ctx.moveTo(x - 20, 192); ctx.lineTo(x - 12, 60); ctx.lineTo(x + 12, 60); ctx.lineTo(x + 20, 192); ctx.closePath(); ctx.fill();
  ctx.fillStyle = "#b03a48"; for (let i = 0; i < 3; i++) ctx.fillRect(x - 17 + i * 1.2, 80 + i * 40, 34 - i * 2.4, 14);
  ctx.fillStyle = "#39445f"; ctx.fillRect(x - 16, 48, 32, 12); ctx.fillStyle = lit ? "#fff6b0" : "#4a5470"; ctx.fillRect(x - 10, 36, 20, 14);
  ctx.fillStyle = "#39445f"; ctx.beginPath(); ctx.moveTo(x - 14, 36); ctx.lineTo(x, 22); ctx.lineTo(x + 14, 36); ctx.closePath(); ctx.fill();
  if (lit) { ctx.save(); ctx.globalCompositeOperation = "lighter"; const g = ctx.createRadialGradient(x, 43, 4, x, 43, 110); g.addColorStop(0, "rgba(255,240,160,.6)"); g.addColorStop(1, "rgba(255,240,160,0)"); ctx.fillStyle = g; ctx.fillRect(x - 110, -70, 220, 220); ctx.restore(); }
  if (L.curador) { const cx = 11.5 * TS - cam.x, a = L.curador; ctx.globalAlpha = a; ctx.fillStyle = "#1a1030"; ctx.beginPath(); ctx.moveTo(cx - 14, 192); ctx.lineTo(cx - 8, 140); ctx.lineTo(cx, 128); ctx.lineTo(cx + 8, 140); ctx.lineTo(cx + 14, 192); ctx.closePath(); ctx.fill(); ctx.fillStyle = "#c9a0ff"; ctx.fillRect(cx - 5, 143, 3, 3); ctx.fillRect(cx + 2, 143, 3, 3); ctx.globalAlpha = 1; }
}
function renderTitle() {
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.imageSmoothingEnabled = false;
  const im = IMG.bg_titlescreen; if (im.width) ctx.drawImage(im, 0, 0, 896, 512);
  ctx.fillStyle = "rgba(10,20,60,.35)"; ctx.fillRect(0, 0, 896, 512);
  const bob = Math.sin(S.t * 2) * 3;
  T_("AS ILHAS", 448, 90 + bob, 56, "#ffffff", "center");
  T_("DE AURALIS", 448, 150 + bob, 56, "#ffd36e", "center");
  ctx.save(); ctx.translate(448 + Math.sin(S.t) * 6, 230); ctx.scale(3.2, 3.2);
  ctx.drawImage(IMG["player_mask-run-" + (Math.floor(S.t * 12) % 6)], -16, -32); ctx.restore();
  const o = titleItems(); S.menuRows = [];
  const startY = 300, gap = 40;
  o.forEach((it, i) => {
    const y = startY + i * gap;
    S.menuRows.push({ y, i });
    ctx.fillStyle = S.titleSel === i ? "rgba(30,100,150,0.55)" : "rgba(8,20,40,0.55)";
    ctx.fillRect(200, y - 20, 496, 36);
    ctx.strokeStyle = S.titleSel === i ? "#8ee7ff" : "#3a5070";
    ctx.lineWidth = 2;
    ctx.strokeRect(200, y - 20, 496, 36);
    T_((S.titleSel === i ? "▶ " : "") + it.t(), 448, y + 5, 20, S.titleSel === i ? "#8ee7ff" : "#e8f4ff", "center");
  });
  T_("Toque na opção para começar", 448, 500, 15, "#9cf", "center", false);
  if (S.fade > 0) { ctx.fillStyle = "rgba(0,0,0," + Math.min(1, S.fade) + ")"; ctx.fillRect(0, 0, 896, 512); }
}

/* epílogo: fala do farol dirigida por gatilhos */
const _say = say;
function epilogueHooks() {
  if (!L || !L.end || P.dead || dlg) return;
  if (S.seen.FAROL_A && !S.seen.FAROL_B && P.x > 8 * TS) { S.seen.FAROL_B = 1; S.flash = 0.6; sfx("Collectible_2"); say("FAROL_B", () => { S.seen.FAROL_C = 1; L.curador = 0.01; say("FAROL_C", () => { L.curador = 0; say("FAROL_D", () => { S.fadeDir = 1; S.fadeCb = () => { S.mode = "ending"; S.t = 0; music("Kiwi_Credits"); S.fadeDir = -1; S.fade = 1; try { localStorage.setItem("auralis_lvl", "0"); } catch(e){} }; }); }); }); }
  if (L.curador > 0 && L.curador < 1) L.curador = Math.min(1, L.curador + 0.02);
}

/* ---------------- laço ---------------- */
let last = 0;
function frame(t) {
  const dt = Math.min(0.033, (t - last) / 1000 || 0.016); last = t;
  if (S.mode === "loading" && loaded >= total) toSplash();
  if (!TEST || !window.__manual) { update(dt); epilogueHooks(); }
  syncTouchPad();
  render(); requestAnimationFrame(frame);
}
window.G = {cam, S, update: dt => { update(dt); epilogueHooks(); }, render, down, pressed, press, release, LEVELS, say, newGame, loadLevel, get P() { return P; }, get L() { return L; }, get boss() { return boss; }, get ents() { return ents; }, get dlg() { return dlg; }, set dlg(v) { dlg = v; }, get cut() { return cut; }, toTitle, get orbs() { return orbs; }};
const qs = new URLSearchParams(location.search);
if (qs.get("lvl")) { const iv = setInterval(() => { if (loaded >= total) { clearInterval(iv); newGame(parseInt(qs.get("lvl"), 10)); if (qs.get("nointro")) { dlg = null; } } }, 50); }
requestAnimationFrame(frame);
