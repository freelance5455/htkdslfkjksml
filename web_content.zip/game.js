const $=id=>document.getElementById(id);
const initial={node:"s1",love:0,trust:0,closeness:0,visited:[]};

const scenes={
s1:{ch:1,m:"🌙",sp:"نُسيبة",t:"الساعة كانت 2:17 بعد منتصف الليل.\nظهر اسم رضوان على شاشة نُسيبة بعد رسالة قصيرة: «لسه صاحي؟»",c:[
["«أيوه… وإنتِ؟»", "s2", {love:1,closeness:1}],
["«كنت مستني رسالتك.»","s2",{love:2,closeness:1}],
["«لا، نامي بدل السهر.»","s2",{trust:1}]
]},
s2:{ch:1,m:"💬",sp:"رضوان",t:"«مش عارف ليه، بس حاسس إن الليلة دي مختلفة.»\nتوقفت نُسيبة لحظة قبل ما تكتب.",c:[
["«مختلفة إزاي؟»","s3",{love:1,trust:1}],
["«يمكن عشان إحنا بنتكلم دلوقتي.»","s3",{love:2,closeness:1}],
["«بلاش كلام غامض 😂»","s3",{trust:1}]
]},
s3:{ch:1,m:"✨",sp:"نُسيبة",t:"«طيب لو قلتلك إن في كلام كتير نفسي أقوله… بس خايفة؟»\nكان ممكن يغيّر كل شيء.",c:[
["«قولي. أنا هسمعك للآخر.»","s4",{trust:2,love:1}],
["«خايفة مني؟»","s4",{closeness:2}],
["«مش لازم تقولي لو مش جاهزة.»","s4",{trust:2}]
]},
s4:{ch:2,m:"🌧️",sp:"رضوان",t:"«أنا كمان بخاف.»\n«أخاف أكون متعلق بيكي أكتر مما ينبغي، وأخاف أكتر إنك ما تكونيش حاسة بنفس الحاجة.»",c:[
["«أنا حاسة.»","s5",{love:3,closeness:2}],
["«إنت عارف إجابتي من زمان.»","s5",{love:2,trust:1}],
["«محتاج وقت أفكر.»","s5",{trust:2,closeness:-1}]
]},
s5:{ch:2,m:"🫶",sp:"نُسيبة",t:"سكتوا شوية. الصمت المرة دي ما كانش مريح… لكنه كان صادق.\nثم قالت: «لو وثقت فيك، هتفضل صريح معايا؟»",c:[
["«حتى لو الحقيقة صعبة.»","s6",{trust:3}],
["«هحاول، ومش هسيبك لو حصل خلاف.»","s6",{trust:2,love:1}],
["«أكيد.»","s6",{trust:1}]
]},
s6:{ch:2,m:"❤️",sp:"رضوان",t:"«في حاجة عايز أقولها من غير ما أجمّلها… وجودك بقى جزء من يومي. ولما بتبعدي، بحس إن اليوم ناقص.»",c:[
["«وأنا بحب وجودي في يومك.»","s7",{love:3,closeness:2}],
["«كمل… أنا سامعاك.»","s7",{love:2,trust:1}],
["«ده كلام كبير يا رضوان.»","s7",{trust:1,closeness:1}]
]},
s7:{ch:3,m:"🔥",sp:"نُسيبة",t:"«إنت قريب أوي دلوقتي…»\nالجملة كانت بسيطة، لكن وقعها كان أكبر من أي اعتراف مباشر.",c:[
["«لو قربت خطوة، هتخافي؟»","s8",{closeness:3,love:1}],
["«لو مش مرتاحة، هبعد فورًا.»","s8",{trust:3,closeness:1}],
["«يمكن أنا اللي خايف.»","s8",{love:1,trust:2}]
]},
s8:{ch:3,m:"🌹",sp:"رضوان",t:"«أنا مش عايز استعجل حاجة. عايز كل خطوة بينا تكون باختيارنا إحنا الاتنين.»\nنُسيبة ابتسمت، وكأن الجملة طمّنتها أكثر من أي وعد.",c:[
["«يبقى خليك هنا.»","s9",{love:2,trust:2,closeness:2}],
["«وعد؟»","s9",{trust:2,love:1}],
["«خلينا نسيب الليلة تاخدنا.»","s9",{closeness:3,love:1}]
]},
s9:{ch:3,m:"📱",sp:"نُسيبة",t:"قبل ما يقفلوا، ظهر سؤال واحد على الشاشة:\n«لو كان لازم تختار حاجة واحدة تحافظ عليها بينا… تختار إيه؟»",c:[
["الثقة.","s10",{trust:3}],
["الحب.","s10",{love:3}],
["القرب.","s10",{closeness:3}]
]},
s10:{ch:4,m:"🌅",sp:"رضوان",t:"الصبح قرب. وكل اختيار عملوه الليلة بدأ يظهر أثره.\n«نُسيبة… مهما كانت النتيجة، أنا مش ندمان إني قلتلك الحقيقة.»",c:[
["«ولا أنا.»","ending",{love:2,trust:2}],
["«لسه عندي خوف.»","ending",{trust:2}],
["«خلي الأفعال هي اللي تجاوب.»","ending",{closeness:2,trust:1}]
]}
};

const endings=[
{min:(s)=>s.love>=9&&s.trust>=8&&s.closeness>=7,e:"❤️",title:"الحب الأبدي",p:"اختاروا الصراحة حتى عندما كانت أصعب من الصمت. الليلة لم تكن مجرد اعتراف؛ كانت بداية علاقة يعرف فيها كل واحد أن الآخر اختاره بوعي."},
{min:(s)=>s.love>=10&&s.trust<8,e:"💞",title:"أخيرًا اعترفنا",p:"الحب كان واضحًا من البداية، لكن الشجاعة احتاجت وقتًا. في النهاية، قال كل واحد ما كان يخفيه."},
{min:(s)=>s.trust>=10&&s.love<10,e:"🌹",title:"فرصة ثانية",p:"لم تكن المشاعر ناقصة، بل كانت تحتاج أمانًا. تركا الباب مفتوحًا، ووعدا أن تكون الخطوة التالية أهدأ وأصدق."},
{min:(s)=>s.closeness>=11&&s.love>=7,e:"🔥",title:"قريب أوي",p:"بينهما انجذاب واضح وقرب لا يمكن إنكاره. لكنهما اتفقا أن القرب الحقيقي يبدأ من احترام حدود كل واحد منهما."},
{min:(s)=>s.trust<=5&&s.love>=7,e:"🥀",title:"كان ممكن نبقى مع بعض",p:"كان الحب موجودًا، لكن التردد وسوء الفهم أخذا مساحة أكبر مما ينبغي. انتهت الليلة بسؤال لم يجد إجابة كاملة."},
{min:(s)=>s.love<7&&s.trust>=7,e:"🌑",title:"النهاية الصامتة",p:"لم ينكسر شيء تمامًا، ولم يبدأ شيء تمامًا. اختارا الأمان، لكن بعض الكلمات ظلت معلقة في منتصف الليل."},
{min:()=>true,e:"🔒",title:"النهاية السرية",p:"لم تكن كل الأبواب مصممة لتفتح بسهولة. وصلت إلى نهاية مخفية تكشف أن أهم قرار في القصة لم يكن اختيار جملة… بل اختيار أن تسمع الآخر بصدق."}
];

let state=JSON.parse(localStorage.getItem("rn-save")||"null")||structuredClone(initial);

function save(){localStorage.setItem("rn-save",JSON.stringify(state));flash("تم الحفظ ✓")}
function load(){const x=JSON.parse(localStorage.getItem("rn-save")||"null");if(x){state=x;render()}else flash("لا يوجد حفظ")}
function flash(msg){const old=$("text").textContent; $("text").textContent=msg; setTimeout(()=>render(),700)}
function render(){
 if(state.node==="ending"){showEnding();return}
 const s=scenes[state.node]; $("chapter").textContent=`الفصل ${s.ch}`;$("mood").textContent=s.m;$("speaker").textContent=s.sp;$("text").textContent=s.t;
 $("love").textContent=state.love;$("trust").textContent=state.trust;$("closeness").textContent=state.closeness;
 $("progressBar").style.width=Math.min(100,(state.visited.length/10)*100)+"%";
 const box=$("choices");box.innerHTML="";
 s.c.forEach(([label,next,delta])=>{const b=document.createElement("button");b.className="choice";b.textContent=label;b.onclick=()=>choose(next,delta);box.appendChild(b)});
}
function choose(next,delta){
 state.love+=delta.love||0;state.trust+=delta.trust||0;state.closeness+=delta.closeness||0;
 if(!state.visited.includes(state.node))state.visited.push(state.node);
 state.node=next;localStorage.setItem("rn-save",JSON.stringify(state));render();
}
function showEnding(){
 const s=state, end=endings.find(x=>x.min(s));
 $("chapter").textContent="النهاية";$("mood").textContent=end.e;$("speaker").textContent="رضوان × نُسيبة";
 $("text").innerHTML=`<div class="ending"><div class="emoji">${end.e}</div><h2>${end.title}</h2><p>${end.p}</p><p>الحب: ${s.love} · الثقة: ${s.trust} · القرب: ${s.closeness}</p></div>`;
 $("choices").innerHTML=`<button class="choice" onclick="restart()">↻ العب من جديد</button>`;
 $("progressBar").style.width="100%";
}
function restart(){state=structuredClone(initial);localStorage.removeItem("rn-save");render()}
$("saveBtn").onclick=save;$("loadBtn").onclick=load;$("restartBtn").onclick=()=>{if(confirm("إعادة البداية؟"))restart()};
render();
