const W = 1280;
const H = 650;
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
const lerp = (a, b, t) => a + (b - a) * t;
const fmtTime = (seconds) => `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;

const rooms = [
  { name:'THE BEGINNING', objective:'Find the exit.', width:2100, exit:1900, start:210, hide:null, lights:true, type:'beginning' },
  { name:'THE LIGHT', objective:'Restore the light, then leave.', width:2200, exit:2010, start:190, hide:null, lights:false, type:'light', switch:860 },
  { name:'THE WATCHER', objective:'Reach the exit. Find somewhere to hide.', width:2200, exit:2010, start:190, hide:1050, lights:true, type:'hiding' },
  { name:'THE POWER ROOM', objective:'Restore power with three fuses.', width:2300, exit:2110, start:190, hide:1680, lights:false, type:'power', fuses:[620,1120,1510] },
  { name:'THE MIRROR', objective:'Look into the mirror. Decide what you see.', width:2100, exit:1900, start:190, hide:null, lights:true, type:'mirror', mirror:1070 },
  { name:'THE CORRIDOR', objective:'Keep moving. Do not look back.', width:2500, exit:2310, start:190, hide:1320, lights:false, type:'corridor' },
  { name:'THE DARK', objective:'Find the emergency lantern.', width:2300, exit:2110, start:190, hide:1260, lights:false, type:'dark', lantern:700 },
  { name:'THE SIGNAL', objective:'Follow the signal sequence.', width:2300, exit:2110, start:190, hide:1630, lights:false, type:'signal', signals:[520,1030,1530] },
  { name:'THE PRESENCE', objective:'Keep Presence low. Activate both anchors.', width:2300, exit:2110, start:190, hide:1180, lights:true, type:'presence', anchors:[760,1420] },
  { name:'THE EXIT', objective:'Use everything you have learned.', width:2400, exit:2200, start:190, hide:1510, lights:false, type:'exit', card:560, switch:940 }
];

const defaultSave = () => ({
  currentRoom:0, unlockedRooms:1, highestRoom:1, roomsCompleted:0, totalTime:0, deaths:0, encounters:0,
  bestTimes:{}, settings:{ master:true, sfx:true, music:true, vibration:true, effects:true, reduceFlashing:false }
});
let save = loadSave();
function loadSave() {
  try { return { ...defaultSave(), ...JSON.parse(localStorage.getItem('the-shadow-save') || '{}'), settings:{...defaultSave().settings,...(JSON.parse(localStorage.getItem('the-shadow-save') || '{}').settings || {})} }; }
  catch { return defaultSave(); }
}
function persist() { localStorage.setItem('the-shadow-save', JSON.stringify(save)); updateContinue(); }

const canvas = document.querySelector('#gameCanvas');
const ctx = canvas.getContext('2d');
const menuScreen = document.querySelector('#menuScreen');
const gameScreen = document.querySelector('#gameScreen');
const overlay = document.querySelector('#overlay');
const overlayCard = document.querySelector('#overlayCard');
const roomNumber = document.querySelector('#roomNumber');
const roomName = document.querySelector('#roomName');
const timeLabel = document.querySelector('#timeLabel');
const timeValue = document.querySelector('#timeValue');
const presenceFill = document.querySelector('#presenceFill');
const presenceState = document.querySelector('#presenceState');
const inventory = document.querySelector('#inventory');
const eventMessage = document.querySelector('#eventMessage');
const objectiveMessage = document.querySelector('#objectiveMessage');
const pauseButton = document.querySelector('#pauseButton');
const hideButton = document.querySelector('#hideButton');
const interactButton = document.querySelector('[data-action="interact"]');

let screen = 'menu';
let gameMode = 'idle';
let roomIndex = 0;
let room = rooms[0];
let player = { x:210, moving:false, hidden:false, hideTime:0 };
let roomState = {};
let roomTime = 0;
let presence = 8;
let shadowState = 'DORMANT';
let shadowX = 1850;
let huntTimer = 0;
let lastFrame = performance.now();
let cameraX = 0;
let eventTimer = null;
let warningShown = 0;
let shadowWasVisible = false;
let stepTimer = 0;
let input = { left:false, right:false };
let audioReady = false;
const sounds = {
  ambient: new Audio('./sfx/ambient.wav'),
  interact: new Audio('./sfx/interact.wav'),
  scare: new Audio('./sfx/scare.wav'),
  door: new Audio('./sfx/door.wav')
};
sounds.ambient.loop = true;

function updateContinue() {
  const btn = document.querySelector('#continueBtn');
  const canContinue = save.unlockedRooms > 1 || save.currentRoom > 0;
  btn.disabled = !canContinue;
  btn.querySelector('small').textContent = canContinue ? `ROOM ${String(save.currentRoom + 1).padStart(2, '0')}` : 'NO CHECKPOINT';
}
updateContinue();

function ensureAudio() {
  if (!audioReady) {
    audioReady = true;
    if (save.settings.music && save.settings.master) sounds.ambient.play().catch(() => {});
  }
}
function playSound(name, volume=0.7) {
  if (!save.settings.master || !save.settings.sfx) return;
  const source = sounds[name];
  if (!source) return;
  const clip = source.cloneNode();
  clip.volume = volume;
  clip.play().catch(() => {});
}
function refreshAudio() {
  sounds.ambient.volume = save.settings.master && save.settings.music ? .34 : 0;
  if (audioReady && sounds.ambient.paused && save.settings.master && save.settings.music) sounds.ambient.play().catch(() => {});
}

function showScreen(name) {
  screen = name;
  menuScreen.classList.toggle('active', name === 'menu');
  gameScreen.classList.toggle('active', name === 'game');
}
function showEvent(text, seconds=2, danger=false) {
  clearTimeout(eventTimer);
  eventMessage.textContent = text;
  eventMessage.classList.toggle('danger', danger);
  eventMessage.classList.add('show');
  eventTimer = setTimeout(() => eventMessage.classList.remove('show'), seconds * 1000);
}
function hideOverlay() { overlay.classList.add('hidden'); overlayCard.innerHTML = ''; }
function showOverlay(html) { overlayCard.innerHTML = html; overlay.classList.remove('hidden'); }

function beginGame(fromContinue=false) {
  ensureAudio();
  const index = fromContinue ? clamp(save.currentRoom, 0, Math.max(0, save.unlockedRooms - 1)) : 0;
  if (!fromContinue) {
    save.currentRoom = 0;
    persist();
  }
  startRoom(index, !fromContinue);
}
function startRoom(index, intro=false) {
  roomIndex = clamp(index, 0, rooms.length - 1);
  room = rooms[roomIndex];
  roomTime = 0;
  presence = roomIndex === 0 ? 5 : 12 + roomIndex * 1.8;
  player = { x:room.start, moving:false, hidden:false, hideTime:0 };
  roomState = { lightsOn:room.lights, fuses:[], signals:0, anchors:[], lantern:false, card:false, powered:false, mirrored:false, shadowTriggered:false, wrongSignal:false };
  shadowState = 'DORMANT'; shadowX = room.exit - 170; huntTimer = 0; warningShown = 0; shadowWasVisible = false; stepTimer = 0;
  gameMode = 'playing'; showScreen('game'); hideOverlay();
  showEvent(intro ? 'SOMETHING IS WRONG.' : `ROOM ${String(roomIndex + 1).padStart(2, '0')}`, intro ? 1.6 : 1.1);
  if (intro) setTimeout(() => showEvent('FIND THE EXIT.', 1.8), 1900);
  updateHud();
}

function roomRequirementsMet() {
  if (room.type === 'light') return roomState.lightsOn;
  if (room.type === 'power') return roomState.fuses.length === room.fuses.length;
  if (room.type === 'mirror') return roomState.mirrored;
  if (room.type === 'dark') return roomState.lantern;
  if (room.type === 'signal') return roomState.signals === room.signals.length;
  if (room.type === 'presence') return roomState.anchors.length === room.anchors.length;
  if (room.type === 'exit') return roomState.card && roomState.lightsOn;
  return true;
}
function getTarget() {
  const near = (x, radius=86) => Math.abs(player.x - x) < radius;
  if (room.type === 'light' && !roomState.lightsOn && near(room.switch)) return { type:'switch', label:'ACTIVATE LIGHT' };
  if (room.type === 'power') {
    const fuse = room.fuses.find((x) => near(x) && !roomState.fuses.includes(x));
    if (fuse) return {type:'fuse', x:fuse, label:'TAKE FUSE'};
  }
  if (room.type === 'mirror' && !roomState.mirrored && near(room.mirror)) return {type:'mirror',label:'LOOK IN MIRROR'};
  if (room.type === 'dark' && !roomState.lantern && near(room.lantern)) return {type:'lantern',label:'TAKE LANTERN'};
  if (room.type === 'signal' && roomState.signals < room.signals.length) {
    if (near(room.signals[roomState.signals])) return {type:'signal',label:`ACTIVATE SIGNAL ${roomState.signals + 1}`};
    const wrong = room.signals.some((x, i) => i > roomState.signals && near(x));
    if (wrong) return {type:'wrongSignal',label:'ACTIVATE SIGNAL'};
  }
  if (room.type === 'presence') {
    const anchor = room.anchors.find((x) => near(x) && !roomState.anchors.includes(x));
    if (anchor) return {type:'anchor',x:anchor,label:'STABILIZE ANCHOR'};
  }
  if (room.type === 'exit' && !roomState.card && near(room.card)) return {type:'card',label:'TAKE KEYCARD'};
  if (room.type === 'exit' && roomState.card && !roomState.lightsOn && near(room.switch)) return {type:'switch',label:'RESTORE LIGHT'};
  if (near(room.exit, 105)) return {type:'exit',label:roomRequirementsMet() ? 'OPEN EXIT' : 'EXIT LOCKED'};
  if (room.hide && Math.abs(player.x - room.hide) < 105 && !player.hidden) return {type:'hide',label:'HIDE'};
  if (player.hidden) return {type:'unhide',label:'LEAVE HIDING'};
  return null;
}
function attemptInteract() {
  if (gameMode !== 'playing') return;
  ensureAudio();
  const target = getTarget();
  if (!target) { showEvent('NOTHING HERE.', .8); return; }
  if (target.type === 'hide' || target.type === 'unhide') { toggleHide(); return; }
  if (target.type === 'exit') {
    if (!roomRequirementsMet()) { showEvent(room.type === 'power' ? 'THE POWER IS STILL OUT.' : 'IT WILL NOT OPEN.', 1.4, true); presence = clamp(presence + 5, 0, 100); return; }
    completeRoom(); return;
  }
  playSound('interact', .55);
  if (target.type === 'switch') { roomState.lightsOn = true; roomState.powered = true; showEvent('THE LIGHTS COME ON.', 1.3); presence = clamp(presence - 9, 0, 100); }
  if (target.type === 'fuse') { roomState.fuses.push(target.x); showEvent(`${roomState.fuses.length} / ${room.fuses.length} FUSES`, 1); presence = clamp(presence + 3, 0, 100); }
  if (target.type === 'mirror') { roomState.mirrored = true; save.encounters++; showEvent(presence > 45 ? 'THE REFLECTION IS LATE.' : 'THE ROOM LOOKS EMPTY.', 1.8, presence > 45); if (presence > 45) shadowState = 'WATCHING'; }
  if (target.type === 'lantern') { roomState.lantern = true; showEvent('A SMALL POCKET OF LIGHT.', 1.3); presence = clamp(presence - 13, 0, 100); }
  if (target.type === 'signal') { roomState.signals++; showEvent(`SIGNAL ${roomState.signals} RECEIVED.`, .9); presence = clamp(presence - 4, 0, 100); }
  if (target.type === 'wrongSignal') { roomState.wrongSignal = true; presence = clamp(presence + 18, 0, 100); showEvent('THE SIGNAL ANSWERS.', 1.2, true); playSound('warning', .5); }
  if (target.type === 'anchor') { roomState.anchors.push(target.x); showEvent('THE ROOM SETTLES.', 1.1); presence = clamp(presence - 16, 0, 100); }
  if (target.type === 'card') { roomState.card = true; showEvent('THE EXIT KEY.', 1.1); presence = clamp(presence + 4, 0, 100); }
  updateHud();
}
function toggleHide() {
  if (!room.hide) { showEvent('THERE IS NOWHERE TO HIDE.', 1); return; }
  if (!player.hidden && Math.abs(player.x - room.hide) > 115) { showEvent('TOO FAR FROM COVER.', 1); return; }
  player.hidden = !player.hidden;
  player.hideTime = 0;
  if (player.hidden) { showEvent('STAY QUIET.', 1.2); playSound('door', .26); }
  else showEvent('THE ROOM IS STILL HERE.', 1);
  updateHud();
}

function completeRoom() {
  gameMode = 'complete';
  playSound('door', .6);
  save.totalTime += roomTime;
  save.roomsCompleted = Math.max(save.roomsCompleted, roomIndex + 1);
  save.highestRoom = Math.max(save.highestRoom, roomIndex + 1);
  save.unlockedRooms = Math.max(save.unlockedRooms, Math.min(rooms.length, roomIndex + 2));
  save.currentRoom = Math.min(rooms.length - 1, roomIndex + 1);
  const oldBest = save.bestTimes[roomIndex];
  if (!oldBest || roomTime < oldBest) save.bestTimes[roomIndex] = roomTime;
  persist();
  if (roomIndex === rooms.length - 1) { setTimeout(showEnding, 450); return; }
  showOverlay(`<h2>ROOM COMPLETE</h2><p class="sub">ROOM ${String(roomIndex + 1).padStart(2,'0')}<br>TIME <strong>${fmtTime(roomTime)}</strong><br>PRESENCE <strong>${presence < 35 ? 'LOW' : presence < 70 ? 'UNSTEADY' : 'HIGH'}</strong><br><br>CHECKPOINT SAVED</p><div class="overlay-actions"><button class="overlay-button" data-action="next">CONTINUE</button><button class="overlay-button" data-action="mainmenu">MAIN MENU</button></div>`);
}
function showEnding() {
  gameMode = 'ending';
  showOverlay(`<h2>YOU ESCAPED.</h2><p class="sub">THE DOOR CLOSES BEHIND YOU.<br><br>YOU STILL HEAR SOMETHING MOVING.</p><div class="overlay-actions"><button class="overlay-button" data-action="playagain">PLAY AGAIN</button><button class="overlay-button" data-action="mainmenu">MAIN MENU</button></div>`);
}
function triggerGameOver() {
  if (gameMode !== 'playing') return;
  gameMode = 'gameover'; save.deaths++; persist(); playSound('scare', .8);
  if (save.settings.vibration && navigator.vibrate) navigator.vibrate([80,40,160]);
  showOverlay(`<h2>THE SHADOW<br>FOUND YOU.</h2><p class="sub">ROOM ${String(roomIndex + 1).padStart(2,'0')}<br>TIME SURVIVED <strong>${fmtTime(roomTime)}</strong></p><div class="overlay-actions"><button class="overlay-button danger" data-action="retry">RETRY ROOM</button><button class="overlay-button" data-action="mainmenu">MAIN MENU</button></div>`);
}

function update(dt) {
  if (gameMode !== 'playing') return;
  roomTime += dt;
  const axis = (input.right ? 1 : 0) - (input.left ? 1 : 0);
  player.moving = axis !== 0 && !player.hidden;
  if (player.moving) {
    player.x = clamp(player.x + axis * (roomIndex > 4 ? 205 : 190) * dt, 80, room.width - 70);
    stepTimer -= dt;
    if (stepTimer <= 0) { playSound('interact', .13); stepTimer = .52; }
  } else stepTimer = 0;
  if (player.hidden) { player.hideTime += dt; if (player.hideTime > 4.4) { player.hidden = false; showEvent('YOUR LEGS ARE NUMB.', 1); } }
  updatePresence(dt);
  updateShadow(dt);
  save.totalTime += dt * .05;
  updateHud();
}
function updatePresence(dt) {
  let rate = .07 + roomIndex * .018;
  if (room.type === 'beginning') rate = roomTime > 28 ? .13 : .04;
  if (room.type === 'light') rate = roomState.lightsOn ? -.12 : .62;
  if (room.type === 'hiding') rate = roomTime > 10 && !player.hidden ? .82 : (player.hidden ? -1.1 : .12);
  if (room.type === 'power') rate = roomState.fuses.length * -.03 + (roomState.fuses.length === 0 ? .24 : .11);
  if (room.type === 'mirror') rate = roomState.mirrored ? .32 : .16;
  if (room.type === 'corridor') rate = player.moving ? .16 : .52;
  if (room.type === 'dark') rate = roomState.lantern ? .14 : .48;
  if (room.type === 'signal') rate = roomState.wrongSignal ? .42 : .16;
  if (room.type === 'presence') rate = roomState.anchors.length ? .08 : .68;
  if (room.type === 'exit') rate = roomState.lightsOn ? .12 : .43;
  if (player.hidden) rate -= 1.18;
  presence = clamp(presence + rate * dt, 0, 100);
  if (room.type === 'hiding' && roomTime > 11 && !roomState.shadowTriggered) { roomState.shadowTriggered = true; showEvent('SOMETHING IS COMING.', 1.6, true); presence = Math.max(presence, 67); }
  if (presence >= 58 && warningShown < 1) { warningShown = 1; showEvent('THE AIR HAS CHANGED.', 1.3, true); }
  if (presence >= 82 && warningShown < 2) { warningShown = 2; showEvent('DO NOT LET IT SEE YOU.', 1.6, true); playSound('scare', .22); }
  if (presence >= 96 && warningShown < 3) { warningShown = 3; showEvent('IT IS VERY CLOSE.', 1.6, true); playSound('scare', .36); }
}
function updateShadow(dt) {
  const previous = shadowState;
  if (presence < 33) shadowState = 'DORMANT';
  else if (presence < 58) shadowState = 'WATCHING';
  else if (presence < 83) shadowState = 'APPROACHING';
  else shadowState = 'HUNTING';
  if (shadowState === 'HUNTING' && !player.hidden) huntTimer += dt; else huntTimer = Math.max(0, huntTimer - dt * 1.5);
  const distance = shadowState === 'DORMANT' ? 650 : shadowState === 'WATCHING' ? 390 : shadowState === 'APPROACHING' ? 255 : Math.max(55, 190 - huntTimer * 35);
  shadowX = clamp(player.x + distance, 100, room.width - 85);
  const visible = shadowState !== 'DORMANT' && (shadowState === 'APPROACHING' || shadowState === 'HUNTING' || (Math.floor(roomTime / 11) % 2 === 1 && roomTime % 11 < 1.1));
  if (visible && !shadowWasVisible) { save.encounters++; shadowWasVisible = true; }
  if (!visible) shadowWasVisible = false;
  if (previous !== shadowState && shadowState === 'HUNTING') playSound('scare', .32);
  if (huntTimer > 2.8 && shadowState === 'HUNTING' && !player.hidden) triggerGameOver();
}

function updateHud() {
  roomNumber.textContent = `ROOM ${String(roomIndex + 1).padStart(2,'0')}`;
  roomName.textContent = room.name;
  timeLabel.textContent = room.type === 'dark' ? 'TIME SURVIVED' : room.type === 'signal' ? 'TIME' : 'TIME';
  timeValue.textContent = fmtTime(roomTime);
  presenceFill.style.width = `${presence}%`;
  presenceFill.style.background = presence > 82 ? '#d62845' : presence > 57 ? '#9e3043' : '#6e3b45';
  presenceState.textContent = presence < 33 ? 'LOW' : presence < 58 ? 'WATCHING' : presence < 83 ? 'APPROACHING' : 'CRITICAL';
  presenceState.style.color = presence > 57 ? '#d62845' : '#b9bbc2';
  let items = [];
  if (room.type === 'power') items.push(`FUSE ${roomState.fuses.length}/${room.fuses.length}`);
  if (room.type === 'signal') items.push(`SIGNALS ${roomState.signals}/${room.signals.length}`);
  if (room.type === 'presence') items.push(`ANCHORS ${roomState.anchors.length}/${room.anchors.length}`);
  if (room.type === 'exit') { if (roomState.card) items.push('KEYCARD'); if (roomState.lightsOn) items.push('LIGHT RESTORED'); }
  inventory.textContent = items.join('  ·  ');
  const target = getTarget();
  interactButton.textContent = target && target.type !== 'hide' && target.type !== 'unhide' ? target.label : 'INTERACT';
  interactButton.disabled = !target || target.type === 'hide' || target.type === 'unhide';
  hideButton.disabled = !room.hide || (!player.hidden && Math.abs(player.x - room.hide) > 115);
  hideButton.textContent = player.hidden ? 'LEAVE' : 'HIDE';
  objectiveMessage.textContent = room.objective;
  pauseButton.disabled = false;
}

function draw() {
  ctx.clearRect(0, 0, W, H);
  ctx.save();
  const sky = ctx.createLinearGradient(0,0,0,H); sky.addColorStop(0,'#07080a'); sky.addColorStop(.68,'#0b0b0e'); sky.addColorStop(1,'#030304');
  ctx.fillStyle = sky; ctx.fillRect(0,0,W,H);
  cameraX = clamp(player.x - W * .48, 0, room.width - W);
  ctx.translate(-cameraX, 0);
  drawRoom();
  drawShadow();
  drawPlayer();
  ctx.restore();
  if (save.settings.effects) drawEffects();
}
function drawRoom() {
  const r = room.width;
  ctx.fillStyle = '#0c0d10'; ctx.fillRect(0,0,r,505);
  ctx.fillStyle = '#070708'; ctx.fillRect(0,505,r,145);
  ctx.strokeStyle = '#191a1e'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(0,505); ctx.lineTo(r,505); ctx.stroke();
  for (let x=0;x<r;x+=240) { ctx.fillStyle = x % 480 === 0 ? '#121319' : '#0f1014'; ctx.fillRect(x,120,2,385); ctx.fillStyle='#15161a';ctx.fillRect(x+2,140,1,365); }
  for (let x=0;x<r;x+=120) { ctx.fillStyle = '#111216'; ctx.fillRect(x,560,86,1); ctx.fillStyle='#0a0a0c'; ctx.fillRect(x+93,615,38,1); }
  ctx.fillStyle = '#16171b'; ctx.fillRect(0,85,r,2); ctx.fillStyle='#08090b'; ctx.fillRect(0,90,r,15);
  drawPipes();
  const lightOn = roomState.lightsOn || room.type === 'beginning' || room.type === 'mirror' || room.type === 'presence';
  const fixtureXs = [350,880,1430,1920, room.width-200];
  fixtureXs.forEach((x,i) => drawFixture(x, 87, lightOn && (i !== 2 || room.type !== 'hiding')));
  if (lightOn) { const grd = ctx.createLinearGradient(0,90,0,505); grd.addColorStop(0,'rgba(176,182,190,.045)'); grd.addColorStop(1,'rgba(176,182,190,0)'); ctx.fillStyle=grd; ctx.fillRect(0,90,r,410); }
  drawDoor(room.exit, roomRequirementsMet());
  drawFurniture();
  if (room.type === 'light') drawSwitch(room.switch, roomState.lightsOn);
  if (room.type === 'power') room.fuses.forEach((x) => drawFuse(x, roomState.fuses.includes(x)));
  if (room.type === 'mirror') drawMirror(room.mirror, roomState.mirrored);
  if (room.type === 'dark') drawLantern(room.lantern, roomState.lantern);
  if (room.type === 'signal') room.signals.forEach((x,i) => drawSignal(x, i < roomState.signals, i === roomState.signals));
  if (room.type === 'presence') room.anchors.forEach((x) => drawAnchor(x, roomState.anchors.includes(x)));
  if (room.type === 'exit') { drawCard(room.card, roomState.card); drawSwitch(room.switch, roomState.lightsOn); }
  if (room.hide) drawHideSpot(room.hide, player.hidden);
  drawRoomText();
}
function drawPipes() { ctx.strokeStyle='#1a1b20';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(80,145);ctx.lineTo(80,60);ctx.lineTo(620,60);ctx.lineTo(620,110);ctx.moveTo(1540,60);ctx.lineTo(1950,60);ctx.lineTo(1950,145);ctx.stroke();ctx.lineWidth=1;ctx.strokeStyle='#292a30';ctx.beginPath();ctx.moveTo(80,153);ctx.lineTo(80,70);ctx.lineTo(620,70);ctx.stroke(); }
function drawFixture(x,y,on) { ctx.fillStyle='#191a1e';ctx.fillRect(x-42,y-4,84,10);ctx.fillStyle=on?'#a3a7ae':'#292a30';ctx.fillRect(x-24,y+2,48,3); if(on){ctx.fillStyle='rgba(184,191,198,.05)';ctx.beginPath();ctx.moveTo(x-18,y+8);ctx.lineTo(x+18,y+8);ctx.lineTo(x+86,500);ctx.lineTo(x-86,500);ctx.fill();} }
function drawDoor(x,open) { ctx.fillStyle='#08090a';ctx.fillRect(x-58,230,116,275);ctx.strokeStyle=open?'#43464d':'#222329';ctx.lineWidth=3;ctx.strokeRect(x-58,230,116,275);ctx.fillStyle=open?'#3d424a':'#16171b';ctx.fillRect(x-45,245,90,248);ctx.fillStyle=open?'#a3a6ad':'#4a4b51';ctx.fillRect(x+31,365,4,7);ctx.fillStyle='#25262b';ctx.fillRect(x-75,505,150,8); }
function drawFurniture() { const pieces=[{x:430,w:150,h:75},{x:1300,w:210,h:90},{x:1750,w:100,h:62}]; pieces.forEach((p,i)=>{ctx.fillStyle=i===1?'#111217':'#0d0e11';ctx.fillRect(p.x,505-p.h,p.w,p.h);ctx.strokeStyle='#24262b';ctx.strokeRect(p.x,505-p.h,p.w,p.h);ctx.fillStyle='#17181d';ctx.fillRect(p.x+10,505-p.h+10,p.w-20,2);ctx.fillStyle='#292b31';ctx.fillRect(p.x+p.w-15,505-p.h+20,3,3);}); if(room.type==='corridor'||room.type==='dark'){ctx.fillStyle='#15161a';ctx.fillRect(920,250,2,255);ctx.fillRect(1600,210,2,295);} }
function drawSwitch(x,on) { ctx.fillStyle='#111216';ctx.fillRect(x-28,350,56,95);ctx.strokeStyle=on?'#5f6670':'#33353c';ctx.strokeRect(x-28,350,56,95);ctx.fillStyle=on?'#b0b4bb':'#4b4d55';ctx.fillRect(x-4,on?367:391,8,36);ctx.fillStyle=on?'#7c8790':'#632433';ctx.fillRect(x-13,420,26,5); }
function drawFuse(x,has) { ctx.fillStyle='#101115';ctx.fillRect(x-30,424,60,62);ctx.strokeStyle='#373940';ctx.strokeRect(x-30,424,60,62);ctx.fillStyle=has?'#34373e':'#8b8e96';ctx.fillRect(x-10,440,20,27);ctx.fillStyle=has?'#25272c':'#d1d1d2';ctx.fillRect(x-6,445,12,17); }
function drawMirror(x,used) { ctx.fillStyle='#17181d';ctx.fillRect(x-64,176,128,260);ctx.strokeStyle='#474a53';ctx.lineWidth=4;ctx.strokeRect(x-64,176,128,260);const gr=ctx.createRadialGradient(x,270,10,x,270,110);gr.addColorStop(0,used&&presence>40?'rgba(7,7,8,.9)':'rgba(100,105,112,.18)');gr.addColorStop(1,'rgba(15,16,19,.9)');ctx.fillStyle=gr;ctx.fillRect(x-54,187,108,238);ctx.strokeStyle='#25272d';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x-45,200);ctx.lineTo(x+20,410);ctx.stroke(); }
function drawLantern(x,on) { ctx.fillStyle='#101115';ctx.fillRect(x-28,445,56,60);ctx.strokeStyle='#565b62';ctx.strokeRect(x-28,445,56,60);ctx.fillStyle=on?'#8e9697':'#35383e';ctx.fillRect(x-12,458,24,27);if(on){ctx.fillStyle='rgba(204,204,180,.13)';ctx.beginPath();ctx.arc(x,457,72,0,Math.PI*2);ctx.fill();} }
function drawSignal(x,on,next) { ctx.fillStyle='#0f1014';ctx.fillRect(x-32,390,64,95);ctx.strokeStyle=on?'#68727a':next?'#8b3545':'#36383e';ctx.strokeRect(x-32,390,64,95);ctx.fillStyle=on?'#acb0b4':next?'#8c3144':'#41434a';ctx.beginPath();ctx.arc(x,422,9,0,Math.PI*2);ctx.fill();ctx.strokeStyle='#33353b';ctx.beginPath();ctx.moveTo(x-17,455);ctx.lineTo(x+17,455);ctx.stroke(); }
function drawAnchor(x,on) { ctx.strokeStyle=on?'#a0a7ad':'#454850';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,330,42,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.arc(x,330,23,0,Math.PI*2);ctx.stroke();ctx.fillStyle=on?'rgba(174,183,186,.18)':'rgba(90,96,105,.05)';ctx.beginPath();ctx.arc(x,330,16,0,Math.PI*2);ctx.fill(); }
function drawCard(x,on) { ctx.fillStyle=on?'#4b4f56':'#9b9ca0';ctx.fillRect(x-21,442,42,24);ctx.fillStyle='#1a1b1f';ctx.fillRect(x-14,449,28,3);ctx.fillRect(x-14,456,18,3); }
function drawHideSpot(x,hidden) { ctx.fillStyle='#08090a';ctx.fillRect(x-48,290,96,215);ctx.strokeStyle=hidden?'#6d2838':'#262830';ctx.strokeRect(x-48,290,96,215);ctx.fillStyle='#131419';ctx.fillRect(x-37,304,74,190);ctx.fillStyle='#35373d';ctx.fillRect(x+24,394,4,5); }
function drawRoomText() { ctx.fillStyle='rgba(185,187,194,.27)';ctx.font='10px Space Mono';ctx.letterSpacing='2px';ctx.fillText(`SECTOR ${String(roomIndex + 1).padStart(2,'0')}`, 75, 170); if(room.type==='corridor'||room.type==='dark'){ctx.fillStyle='rgba(214,40,69,.32)';ctx.fillText('NO EXIT',room.exit-38,210);} }
function drawPlayer() { if(player.hidden) return; const x=player.x;ctx.fillStyle='#060607';ctx.beginPath();ctx.arc(x,454,11,0,Math.PI*2);ctx.fill();ctx.fillRect(x-9,465,18,40);ctx.fillStyle='rgba(185,187,194,.16)';ctx.fillRect(x-1,469,2,28); }
function drawShadow() { const active = shadowState !== 'DORMANT' && (shadowState !== 'WATCHING' || Math.floor(roomTime / 11) % 2 === 1 || roomState.mirrored); if(!active || player.hidden) return; const x=shadowX; const alpha=shadowState==='WATCHING'?.55:shadowState==='APPROACHING'?.76:.95; ctx.save();ctx.globalAlpha=alpha;ctx.filter=save.settings.effects?'blur(1px)':'none';ctx.fillStyle='#010101';ctx.beginPath();ctx.ellipse(x,432,21,68,0,0,Math.PI*2);ctx.fill();ctx.beginPath();ctx.arc(x,351,25,0,Math.PI*2);ctx.fill();ctx.fillRect(x-25,410,50,98);ctx.strokeStyle='rgba(60,63,70,.35)';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x-19,414);ctx.lineTo(x-35,492);ctx.moveTo(x+19,414);ctx.lineTo(x+34,492);ctx.stroke();if(shadowState==='HUNTING'){ctx.fillStyle='rgba(190,194,199,.22)';ctx.fillRect(x-8,353,3,2);ctx.fillRect(x+6,353,3,2);}ctx.restore(); }
function drawEffects() { if(presence > 72 && !save.settings.reduceFlashing){ const a=(presence-72)/240;ctx.fillStyle=`rgba(105,12,28,${a})`;ctx.fillRect(0,0,W,H); } if(shadowState==='HUNTING' && !save.settings.reduceFlashing){ctx.save();ctx.globalAlpha=.06+Math.sin(roomTime*32)*.025;ctx.fillStyle='#d62845';ctx.fillRect(Math.sin(roomTime*13)*5,0,W,H);ctx.restore();} }

function openSettings(returnTo='menu') {
  gameMode = returnTo === 'paused' ? 'paused' : 'idle';
  const rows = [['master','MASTER SOUND'],['sfx','SFX'],['music','MUSIC'],['vibration','VIBRATION'],['effects','SCREEN EFFECTS'],['reduceFlashing','REDUCE FLASHING']];
  showOverlay(`<h2>SETTINGS</h2><div class="settings-list">${rows.map(([key,label])=>`<div class="setting-row"><span>${label}</span><button class="setting-toggle ${save.settings[key]?'on':'off'}" data-setting="${key}">${save.settings[key]?'ON':'OFF'}</button></div>`).join('')}</div><div class="overlay-actions" style="margin-top:24px"><button class="overlay-button" data-action="${returnTo === 'paused' ? 'backpause' : 'mainmenu'}">BACK</button></div>`);
}
function openStats() {
  const best = Object.entries(save.bestTimes).sort((a,b)=>Number(a[0])-Number(b[0])).map(([i,t])=>`ROOM ${String(Number(i)+1).padStart(2,'0')} &nbsp; ${fmtTime(t)}`).join('<br>') || 'NO COMPLETED ROOMS';
  showOverlay(`<h2>STATISTICS</h2><div class="stat-grid"><div class="stat-item"><span>ROOMS COMPLETED</span><b>${save.roomsCompleted}</b></div><div class="stat-item"><span>HIGHEST ROOM</span><b>${String(save.highestRoom).padStart(2,'0')}</b></div><div class="stat-item"><span>TOTAL TIME</span><b>${fmtTime(save.totalTime)}</b></div><div class="stat-item"><span>DEATHS</span><b>${save.deaths}</b></div><div class="stat-item"><span>SHADOW ENCOUNTERS</span><b>${save.encounters}</b></div><div class="stat-item"><span>CHECKPOINT</span><b>${save.unlockedRooms}/${rooms.length}</b></div></div><div class="best-times">BEST TIMES<br>${best}</div><div class="overlay-actions" style="margin-top:22px"><button class="overlay-button" data-action="mainmenu">BACK</button></div>`);
}
function openCredits() { showOverlay(`<h2>THE SHADOW</h2><div class="credit-lines">Created by Fabio<br>Powered by Websim<br><br><span style="color:#62646c">A SMALL GAME ABOUT THE THINGS<br>THAT MOVE WHEN YOU LOOK AWAY.</span></div><div class="overlay-actions" style="margin-top:25px"><button class="overlay-button" data-action="mainmenu">BACK</button></div>`); }
function pauseGame() { if(gameMode !== 'playing') return; gameMode='paused'; showOverlay(`<h2>PAUSED</h2><p class="sub">THE ROOM IS WAITING.</p><div class="overlay-actions"><button class="overlay-button" data-action="resume">RESUME</button><button class="overlay-button" data-action="restart">RESTART ROOM</button><button class="overlay-button" data-action="settingspause">SETTINGS</button><button class="overlay-button" data-action="mainmenu">MAIN MENU</button></div>`); }
function resumeGame() { hideOverlay(); gameMode='playing'; }

overlay.addEventListener('click', (e) => {
  const setting = e.target.closest('[data-setting]');
  if (setting) { const key=setting.dataset.setting;save.settings[key]=!save.settings[key];persist();refreshAudio();openSettings(gameMode === 'paused' ? 'paused' : 'menu');return; }
  const action = e.target.closest('[data-action]')?.dataset.action;
  if (!action) return;
  ensureAudio();
  if (action==='resume') resumeGame();
  if (action==='restart'||action==='retry') startRoom(roomIndex);
  if (action==='next') startRoom(roomIndex+1);
  if (action==='playagain') beginGame(false);
  if (action==='mainmenu') { hideOverlay(); gameMode='idle'; showScreen('menu'); updateContinue(); }
  if (action==='settingspause') openSettings('paused');
  if (action==='backpause') { gameMode='paused'; showOverlay(`<h2>PAUSED</h2><p class="sub">THE ROOM IS WAITING.</p><div class="overlay-actions"><button class="overlay-button" data-action="resume">RESUME</button><button class="overlay-button" data-action="restart">RESTART ROOM</button><button class="overlay-button" data-action="settingspause">SETTINGS</button><button class="overlay-button" data-action="mainmenu">MAIN MENU</button></div>`); }
});
document.addEventListener('click', (e) => {
  const action=e.target.closest('[data-action]')?.dataset.action;
  if (!action || e.target.closest('#overlay')) return;
  ensureAudio();
  if (action==='play') beginGame(false);
  if (action==='continue' && !e.target.closest('#continueBtn').disabled) beginGame(true);
  if (action==='settings') openSettings('menu');
  if (action==='stats') openStats();
  if (action==='credits') openCredits();
  if (action==='pause') pauseGame();
  if (action==='interact') attemptInteract();
  if (action==='hide') toggleHide();
});

document.querySelectorAll('[data-hold]').forEach((button) => {
  const key=button.dataset.hold;
  const start=(e)=>{e.preventDefault();ensureAudio();input[key]=true;button.classList.add('held');};
  const end=()=>{input[key]=false;button.classList.remove('held');};
  button.addEventListener('pointerdown',start);button.addEventListener('pointerup',end);button.addEventListener('pointercancel',end);button.addEventListener('pointerleave',end);
});
window.addEventListener('pointerup',()=>{input.left=false;input.right=false;document.querySelectorAll('.control-button.held').forEach(b=>b.classList.remove('held'));});
window.addEventListener('keydown',(e)=>{ if(e.key.toLowerCase()==='a'||e.key==='ArrowLeft') input.left=true; if(e.key.toLowerCase()==='d'||e.key==='ArrowRight') input.right=true; if(e.key.toLowerCase()==='e') attemptInteract(); if(e.code==='Space'){e.preventDefault();toggleHide();} if(e.key==='Escape') gameMode==='playing'?pauseGame():gameMode==='paused'?resumeGame():null; });
window.addEventListener('keyup',(e)=>{if(e.key.toLowerCase()==='a'||e.key==='ArrowLeft')input.left=false;if(e.key.toLowerCase()==='d'||e.key==='ArrowRight')input.right=false;});

function frame(now) { const dt=Math.min(.05,(now-lastFrame)/1000);lastFrame=now;update(dt);draw();requestAnimationFrame(frame); }
refreshAudio(); requestAnimationFrame(frame);
window.addEventListener('beforeunload', persist);
