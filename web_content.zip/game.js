const canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");
const moneyEl=document.getElementById("money"),hpEl=document.getElementById("hp"),wantedEl=document.getElementById("wanted");
const statusEl=document.getElementById("status"),missionText=document.getElementById("missionText"),toastEl=document.getElementById("toast");

let W,H,dpr=1;
function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();

const world={w:3600,h:2600};
const player={x:700,y:600,r:16,speed:190,angle:0,hp:100,money:500,inCar:false};
const car={x:820,y:600,w:58,h:30,angle:0,speed:0,owned:false};
const cam={x:0,y:0};
const keys={};
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.key===" "){interact()}});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);

const buildings=[
{x:300,y:250,w:360,h:250,name:"Prefeitura"}, {x:900,y:220,w:330,h:270,name:"Delegacia"},
{x:1500,y:260,w:430,h:250,name:"Shopping"}, {x:2400,y:300,w:400,h:280,name:"Hospital"},
{x:400,y:1050,w:480,h:330,name:"Oficinas"}, {x:1250,y:1000,w:390,h:300,name:"Banco"},
{x:2050,y:1050,w:500,h:330,name:"Mercado"}, {x:2850,y:1050,w:420,h:330,name:"Restaurante"},
{x:700,y:1800,w:500,h:300,name:"Apartamentos"}, {x:1850,y:1800,w:450,h:300,name:"Apartamentos 2"}
];
const roads=[
{x:0,y:700,w:3600,h:150},{x:0,y:1500,w:3600,h:150},{x:0,y:2250,w:3600,h:150},
{x:750,y:0,w:150,h:2600},{x:1700,y:0,w:150,h:2600},{x:2700,y:0,w:150,h:2600}
];
const mission={x:1510,y:640,done:false};
const npcs=[];
for(let i=0;i<26;i++) npcs.push({x:180+Math.random()*3200,y:180+Math.random()*2200,r:10,vx:(Math.random()-.5)*20,vy:(Math.random()-.5)*20});
const cars=[];
for(let i=0;i<14;i++) cars.push({x:100+Math.random()*3300,y:[760,1560,2310][i%3]+(Math.random()*40-20),w:52,h:28,angle:0,speed:50+Math.random()*35});

function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function rectHitCircle(r,cx,cy,rad){
 const x=clamp(cx,r.x,r.x+r.w),y=clamp(cy,r.y,r.y+r.h);
 return Math.hypot(cx-x,cy-y)<rad;
}
function blocked(x,y,r=16){
 for(const b of buildings) if(rectHitCircle(b,x,y,r+4)) return true;
 return x<r||y<r||x>world.w-r||y>world.h-r;
}
function moveEntity(e,dx,dy,r){
 let nx=e.x+dx,ny=e.y;
 if(!blocked(nx,ny,r)) e.x=nx;
 nx=e.x;ny=e.y+dy;
 if(!blocked(nx,ny,r)) e.y=ny;
}
function showToast(t){toastEl.textContent=t;toastEl.style.opacity=1;clearTimeout(showToast.t);showToast.t=setTimeout(()=>toastEl.style.opacity=0,1800)}

let joy={x:0,y:0,active:false,id:null};
const stick=document.getElementById("stick"),knob=document.getElementById("knob");
function joyPoint(e){
 const r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
 let x=e.clientX-cx,y=e.clientY-cy,max=r.width*.32,len=Math.hypot(x,y);
 if(len>max){x=x/len*max;y=y/len*max}
 joy.x=x/max;joy.y=y/max;knob.style.transform=`translate(${x}px,${y}px)`;
}
stick.addEventListener("pointerdown",e=>{joy.active=true;joy.id=e.pointerId;stick.setPointerCapture(e.pointerId);joyPoint(e)});
stick.addEventListener("pointermove",e=>{if(joy.active&&e.pointerId===joy.id)joyPoint(e)});
function endJoy(){joy.active=false;joy.x=joy.y=0;knob.style.transform=""}
stick.addEventListener("pointerup",endJoy);stick.addEventListener("pointercancel",endJoy);

function input(){
 let x=joy.x,y=joy.y;
 if(keys.w||keys.arrowup)y-=1;if(keys.s||keys.arrowdown)y+=1;if(keys.a||keys.arrowleft)x-=1;if(keys.d||keys.arrowright)x+=1;
 let l=Math.hypot(x,y);if(l>1){x/=l;y/=l} return{x,y};
}
function interact(){
 const target=player.inCar?car:player;
 if(!mission.done && Math.hypot(target.x-mission.x,target.y-mission.y)<90){
   mission.done=true;player.money+=250;missionText.textContent="Missão concluída! Pegue outra atividade na cidade.";showToast("Missão concluída: +$250");
   return;
 }
 if(!player.inCar && Math.hypot(player.x-car.x,player.y-car.y)<85){player.inCar=true;car.owned=true;statusEl.textContent="Dirigindo";showToast("Você entrou no veículo");return}
 if(player.inCar){player.inCar=false;player.x=car.x+45;player.y=car.y;statusEl.textContent="A pé";showToast("Você saiu do veículo");return}
 for(const b of buildings){
   if(Math.hypot(player.x-(b.x+b.w/2),player.y-(b.y+b.h/2))<Math.max(b.w,b.h)*.6){
     showToast("Local: "+b.name);return;
   }
 }
 showToast("Nada para interagir aqui");
}
document.getElementById("interact").onclick=interact;
document.getElementById("enter").onclick=interact;

let last=performance.now();
function update(dt){
 const v=input();
 if(player.inCar){
   car.speed += -v.y*260*dt;
   car.speed *= Math.pow(.18,dt);
   car.speed=clamp(car.speed,-210,330);
   car.angle += v.x*2.5*dt*(Math.abs(car.speed)/120+.2);
   const dx=Math.cos(car.angle)*car.speed*dt,dy=Math.sin(car.angle)*car.speed*dt;
   const oldx=car.x,oldy=car.y;moveEntity(car,dx,dy,24);
   if(car.x!==oldx||car.y!==oldy){player.x=car.x;player.y=car.y}
   else car.speed=0;
 }else{
   const sp=player.speed*(keys.shift?1.55:1);
   moveEntity(player,v.x*sp*dt,v.y*sp*dt,player.r);
   if(Math.hypot(v.x,v.y)>.1)player.angle=Math.atan2(v.y,v.x);
 }
 for(const n of npcs){
   n.x+=n.vx*dt;n.y+=n.vy*dt;
   if(blocked(n.x,n.y,10)||n.x<30||n.x>world.w-30)n.vx*=-1;
   if(blocked(n.x,n.y,10)||n.y<30||n.y>world.h-30)n.vy*=-1;
 }
 for(const c of cars){c.x+=Math.cos(c.angle)*c.speed*dt;c.y+=Math.sin(c.angle)*c.speed*dt;
   if(c.x<30||c.x>world.w-30)c.angle=Math.PI-c.angle;
 }
 cam.x+=(player.x-W/2-cam.x)*Math.min(1,dt*6);cam.y+=(player.y-H/2-cam.y)*Math.min(1,dt*6);
 cam.x=clamp(cam.x,0,world.w-W);cam.y=clamp(cam.y,0,world.h-H);
 moneyEl.textContent=Math.floor(player.money);hpEl.textContent=player.hp;wantedEl.textContent="★".repeat(Math.min(5,player.wanted||0));
}
function draw(){
 ctx.clearRect(0,0,W,H);ctx.save();ctx.translate(-cam.x,-cam.y);
 // grass
 ctx.fillStyle="#3c713f";ctx.fillRect(0,0,world.w,world.h);
 // parks
 ctx.fillStyle="#477f48";ctx.fillRect(30,40,500,150);ctx.fillRect(3050,50,500,180);
 // roads
 for(const r of roads){ctx.fillStyle="#45484b";ctx.fillRect(r.x,r.y,r.w,r.h);ctx.strokeStyle="#d7b94b";ctx.lineWidth=3;ctx.setLineDash([28,28]);
   if(r.w>r.h)ctx.beginPath(),ctx.moveTo(r.x,r.y+r.h/2),ctx.lineTo(r.x+r.w,r.y+r.h/2),ctx.stroke();
   else ctx.beginPath(),ctx.moveTo(r.x+r.w/2,r.y),ctx.lineTo(r.x+r.w/2,r.y+r.h),ctx.stroke();
 }ctx.setLineDash([]);
 // buildings
 for(const b of buildings){ctx.fillStyle="#b8b1a2";ctx.fillRect(b.x,b.y,b.w,b.h);ctx.fillStyle="#77706a";ctx.fillRect(b.x+12,b.y+12,b.w-24,45);
   ctx.fillStyle="#d8d0c1";ctx.font="bold 16px Arial";ctx.fillText(b.name,b.x+18,b.y+b.h/2);
   ctx.fillStyle="#58718a";for(let x=b.x+25;x<b.x+b.w-20;x+=55)for(let y=b.y+80;y<b.y+b.h-20;y+=55)ctx.fillRect(x,y,25,25);
 }
 // mission marker
 if(!mission.done){ctx.fillStyle="#ffd43b";ctx.beginPath();ctx.arc(mission.x,mission.y,22+Math.sin(performance.now()/180)*4,0,Math.PI*2);ctx.fill();ctx.fillStyle="#111";ctx.font="bold 14px Arial";ctx.fillText("RP",mission.x-10,mission.y+5)}
 // NPCs
 for(const n of npcs){ctx.fillStyle="#e9c9a7";ctx.beginPath();ctx.arc(n.x,n.y-12,7,0,Math.PI*2);ctx.fill();ctx.fillStyle="#6b4e71";ctx.fillRect(n.x-7,n.y-6,14,22)}
 // cars
 for(const c of cars.concat([car])){if(c===car&&!car.owned){}ctx.save();ctx.translate(c.x,c.y);ctx.rotate(c.angle);ctx.fillStyle=c===car?"#d63c3c":"#3e77b6";ctx.fillRect(-c.w/2,-c.h/2,c.w,c.h);ctx.fillStyle="#b9d4e5";ctx.fillRect(-12,-10,24,20);ctx.fillStyle="#222";ctx.fillRect(-20,-17,12,6);ctx.fillRect(8,-17,12,6);ctx.fillRect(-20,11,12,6);ctx.fillRect(8,11,12,6);ctx.restore()}
 // player
 if(!player.inCar){ctx.save();ctx.translate(player.x,player.y);ctx.rotate(player.angle);ctx.fillStyle="#f0c9a5";ctx.beginPath();ctx.arc(0,-13,7,0,Math.PI*2);ctx.fill();ctx.fillStyle="#3b62b8";ctx.fillRect(-9,-7,18,25);ctx.fillStyle="#222";ctx.fillRect(-8,18,6,10);ctx.fillRect(2,18,6,10);ctx.restore()}
 ctx.restore();
}
function loop(t){const dt=Math.min(.033,(t-last)/1000);last=t;update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);

// touch-friendly fullscreen/orientation attempt
document.documentElement.requestFullscreen?.().catch(()=>{});
screen.orientation?.lock?.("landscape").catch(()=>{});
