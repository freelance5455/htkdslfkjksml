export default {
  start(api) {
    // Preparar el juego y dibujar el personaje.
  },

  update(delta, api) {
    // Actualizar el tiempo y las necesidades.
  },

  onButton(button, api) {
    // Recibir los botones:
    // "left", "middle" y "right".
  },

  setLanguage(language) {
    // Cambiar el idioma del juego.
  }
};