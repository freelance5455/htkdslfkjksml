
const canvas = document.getElementById("field");
const ctx = canvas.getContext("2d");

let playing = false;
let paused = false;
let time = 90;
let blueScore = 0;
let redScore = 0;

let player = { x: 100, y: 150, r: 13 };
let enemy = { x: 280, y: 150, r: 13 };
let ball = { x: 190, y: 150, vx: 0, vy: 0, r: 7 };

let keys = {};
let speed = 3;

function resize() {
  canvas.width = canvas.clientWidth * devicePixelRatio;
  canvas.height = canvas.clientHeight * devicePixelRatio;
  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);
}

window.addEventListener("resize", resize);
resize();

function startGame() {
  document.getElementById("menu").style.display = "none";
  document.getElementById("settings").style.display = "none";
  document.getElementById("game").style.display = "flex";

  resize();
  playing = true;
  paused = false;
  time = 90;
  blueScore = 0;
  redScore = 0;
  resetPositions();
  updateScore();

  clearInterval(window.clock);
  window.clock = setInterval(() => {
    if (playing && !paused && time > 0) {
      time--;
      document.getElementById("timer").textContent = time;
      if (time === 0) finishGame();
    }
  }, 1000);

  requestAnimationFrame(loop);
}

function resetPositions() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;

  player.x = w * 0.25;
  player.y = h * 0.5;

  enemy.x = w * 0.75;
  enemy.y = h * 0.5;

  ball.x = w * 0.5;
  ball.y = h * 0.5;
  ball.vx = 0;
  ball.vy = 0;
}

function updateScore() {
  document.getElementById("score").textContent =
    blueScore + " - " + redScore;
}

function drawField() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;

  ctx.fillStyle = "#16883b";
  ctx.fillRect(0, 0, w, h);

  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = i % 2 === 0
      ? "#16883b" : "#198f40";
    ctx.fillRect(i * w / 8, 0, w / 8, h);
  }

  ctx.strokeStyle = "white";
  ctx.lineWidth = 3;

  ctx.strokeRect(10, 10, w - 20, h - 20);

  ctx.beginPath();
  ctx.moveTo(w / 2, 10);
  ctx.lineTo(w / 2, h - 10);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(w / 2, h / 2, 55, 0, Math.PI * 2);
  ctx.stroke();

  ctx.strokeRect(10, h * .3, 65, h * .4);
  ctx.strokeRect(w - 75, h * .3, 65, h * .4);

  ctx.fillStyle = "white";
  ctx.fillRect(0, h * .4, 12, h * .2);
  ctx.fillRect(w - 12, h * .4, 12, h * .2);
}

function drawPlayer(p, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "white";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = "white";
  ctx.beginPath();
  ctx.arc(p.x, p.y - 3, 4, 0, Math.PI * 2);
  ctx.fill();
}

function movePlayer() {
  let velocity = speed;

  if (keys.run) velocity *= 1.6;

  if (keys.up) player.y -= velocity;
  if (keys.down) player.y += velocity;
  if (keys.left) player.x -= velocity;
  if (keys.right) player.x += velocity;

  player.x = Math.max(25, Math.min(canvas.clientWidth - 25, player.x));
  player.y = Math.max(25, Math.min(canvas.clientHeight - 25, player.y));

  // Adversário segue a bola
  const dx = ball.x - enemy.x;
  const dy = ball.y - enemy.y;
  const distance = Math.hypot(dx, dy);

  if (distance > 2) {
    enemy.x += dx / distance * 1.8;
    enemy.y += dy / distance * 1.8;
  }
}

function updateBall() {
  ball.x += ball.vx;
  ball.y += ball.vy;

  ball.vx *= .985;
  ball.vy *= .985;

  const h = canvas.clientHeight;
  const w = canvas.clientWidth;

  if (ball.y < 15 || ball.y > h - 15) {
    ball.vy *= -1;
  }

  if (ball.x < 12 || ball.x > w - 12) {
    if (ball.y > h * .4 && ball.y < h * .6) {
      if (ball.x < 12) redScore++;
      else blueScore++;

      updateScore();
      resetPositions();
    } else {
      ball.vx *= -1;
    }
  }

  // Bola próxima do jogador
  let d = Math.hypot(ball.x - player.x, ball.y - player.y);

  if (d < 22) {
    ball.x += (ball.x - player.x) * .08;
    ball.y += (ball.y - player.y) * .08;
  }

  // Bola próxima do adversário
  let e = Math.hypot(ball.x - enemy.x, ball.y - enemy.y);

  if (e < 22) {
    ball.vx -= .5;
    ball.vy += (ball.y - enemy.y) * .04;
  }
}

function drawBall() {
  ctx.fillStyle = "white";
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = "black";
  ctx.stroke();
}

function shoot() {
  const dx = ball.x - player.x;
  const dy = ball.y - player.y;
  const d = Math.hypot(dx, dy);

  if (d < 45) {
    ball.vx = 9;
    ball.vy = dy / Math.max(d, 1) * 5;
  }
}

function pass() {
  const d = Math.hypot(ball.x - player.x, ball.y - player.y);

  if (d < 45) {
    ball.vx = 5;
    ball.vy = 0;
  }
}

function loop() {
  if (!playing) return;

  if (!paused) {
    movePlayer();
    updateBall();

    drawField();
    drawPlayer(player, "#1479ed");
    drawPlayer(enemy, "#e53935");
    drawBall();
  }

  requestAnimationFrame(loop);
}

function pauseGame() {
  paused = !paused;
}

function finishGame() {
  playing = false;
  clearInterval(window.clock);

  alert("FIM DE JOGO! Placar: " +
    blueScore + " - " + redScore);

  document.getElementById("game").style.display = "none";
  document.getElementById("menu").style.display = "flex";
}

function showSettings() {
  document.getElementById("menu").style.display = "none";
  document.getElementById("settings").style.display = "flex";
}

function closeSettings() {
  document.getElementById("settings").style.display = "none";
  document.getElementById("menu").style.display = "flex";
}

document.getElementById("speed").addEventListener("input", e => {
  speed = Number(e.target.value);
});

function bindButton(id, key) {
  const btn = document.getElementById(id);

  btn.addEventListener("pointerdown", e => {
    e.preventDefault();
    keys[key] = true;
  });

  ["pointerup", "pointerleave", "pointercancel"].forEach(event => {
    btn.addEventListener(event, () => {
      keys[key] = false;
    });
  });
}

bindButton("up", "up");
bindButton("down", "down");
bindButton("left", "left");
bindButton("right", "right");
bindButton("run", "run");

document.getElementById("shoot").addEventListener("pointerdown", shoot);
document.getElementById("pass").addEventListener("pointerdown", pass);

// CORREÇÃO DE COLISÃO DA BOLA COM OS JOGADORES

function fixBallCollision(p) {
  const dx = ball.x - p.x;
  const dy = ball.y - p.y;
  const distance = Math.hypot(dx, dy);

  const minDistance = p.r + ball.r + 2;

  if (distance < minDistance) {
    const angle = Math.atan2(dy, dx);

    // Impede a bola de atravessar o jogador
    ball.x = p.x + Math.cos(angle) * minDistance;
    ball.y = p.y + Math.sin(angle) * minDistance;

    // Empurra a bola para fora do jogador
    ball.vx += Math.cos(angle) * 1.5;
    ball.vy += Math.sin(angle) * 1.5;
  }
}

// Substitui a atualização original da bola
const originalUpdateBall = updateBall;

updateBall = function() {
  originalUpdateBall();

  fixBallCollision(player);
  fixBallCollision(enemy);
};
