const canvas=document.getElementById("canvas"),ctx=canvas.getContext("2d");
const hpEl=document.getElementById("hp"),energyEl=document.getElementById("energy"),coinsEl=document.getElementById("coins");
const woodEl=document.getElementById("wood"),stoneEl=document.getElementById("stone"),herbEl=document.getElementById("herb"),coinBagEl=document.getElementById("coinBag");
const progressEl=document.getElementById("progress"),questText=document.getElementById("questText"),toast=document.getElementById("toast");
let W=0,H=0,dpr=1,running=false,last=0,keys={},camera={x:0,y:0};
const world={w:2600,h:1900};
const p={x:400,y:1450,r:22,hp:100,energy:100,speed:190,dir:1};
const inv={wood:0,stone:0,herb:0,coins:0};
let resources=[],trees=[],rocks=[],snow=[],camp={x:2100,y:420},night=0,won=false;

function resize(){dpr=Math.min(devicePixelRatio||1,2);W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();

function rand(a,b){return a+Math.random()*(b-a)}
function dist(a,b){return Math.hypot(a.x-b.x,a.y-b.y)}
function makeWorld(){
 resources=[];trees=[];rocks=[];snow=[];
 for(let i=0;i<70;i++)trees.push({x:rand(90,world.w-90),y:rand(100,world.h-100),s:rand(.8,1.25)});
 for(let i=0;i<55;i++)rocks.push({x:rand(70,world.w-70),y:rand(100,world.h-80),s:rand(.7,1.2)});
 for(let i=0;i<34;i++)resources.push({x:rand(120,world.w-120),y:rand(120,world.h-120),type:["wood","wood","stone","herb"][i%4],got:false});
 for(let i=0;i<150;i++)snow.push({x:Math.random()*world.w,y:Math.random()*world.h,r:rand(1,3),a:rand(.2,.7),drift:rand(8,20)});
}
makeWorld();

function screen(x,y){return {x:x-camera.x,y:y-camera.y}}
function drawTree(o){let q=screen(o.x,o.y);ctx.save();ctx.translate(q.x,q.y);ctx.scale(o.s,o.s);ctx.fillStyle="#4b3329";ctx.fillRect(-7,-2,14,48);ctx.fillStyle="#284e4d";ctx.beginPath();ctx.arc(0,-12,34,0,7);ctx.fill();ctx.fillStyle="#376565";ctx.beginPath();ctx.arc(-18,8,25,0,7);ctx.arc(18,8,25,0,7);ctx.fill();ctx.fillStyle="#e8f1ef";ctx.beginPath();ctx.arc(-12,-26,12,0,7);ctx.arc(15,-20,10,0,7);ctx.fill();ctx.restore()}
function drawRock(o){let q=screen(o.x,o.y);ctx.save();ctx.translate(q.x,q.y);ctx.scale(o.s,o.s);ctx.fillStyle="#73868a";ctx.beginPath();ctx.ellipse(0,10,30,18,0,0,7);ctx.fill();ctx.fillStyle="#a9b9ba";ctx.beginPath();ctx.ellipse(-8,3,15,8,-.2,0,7);ctx.fill();ctx.restore()}
function drawResource(o){if(o.got)return;let q=screen(o.x,o.y);ctx.save();ctx.translate(q.x,q.y);ctx.font="24px sans-serif";ctx.textAlign="center";ctx.fillText(o.type==="wood"?"🪵":o.type==="stone"?"🪨":"🌿",0,0);ctx.restore()}
function drawPlayer(){let q=screen(p.x,p.y);ctx.save();ctx.translate(q.x,q.y);ctx.scale(p.dir,1);ctx.font="43px sans-serif";ctx.textAlign="center";ctx.fillText("🐿️",0,10);ctx.font="20px sans-serif";ctx.fillText("🧣",0,20);ctx.restore()}
function drawCamp(){let q=screen(camp.x,camp.y);ctx.save();ctx.translate(q.x,q.y);ctx.fillStyle="#8d573d";ctx.beginPath();ctx.moveTo(-65,25);ctx.lineTo(0,-45);ctx.lineTo(65,25);ctx.closePath();ctx.fill();ctx.fillStyle="#eee";ctx.beginPath();ctx.moveTo(-60,20);ctx.lineTo(0,-45);ctx.lineTo(60,20);ctx.lineTo(48,15);ctx.lineTo(0,-30);ctx.lineTo(-48,15);ctx.closePath();ctx.fill();ctx.fillStyle="#f2b84b";ctx.beginPath();ctx.arc(0,33,18,0,7);ctx.fill();ctx.font="28px sans-serif";ctx.textAlign="center";ctx.fillText("🏕️",0,70);ctx.restore()}
function draw(){
 ctx.clearRect(0,0,W,H);
 ctx.fillStyle="#b8d4dc";ctx.fillRect(0,0,W,H);
 const g=ctx.createLinearGradient(0,0,0,H);g.addColorStop(0,"#9cc5d2");g.addColorStop(1,"#e6eeee");ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 ctx.save();ctx.translate(-camera.x%120,-camera.y%120);ctx.strokeStyle="#ffffff38";ctx.lineWidth=1;
 for(let x=-120;x<world.w+120;x+=120){ctx.beginPath();ctx.moveTo(x,-120);ctx.lineTo(x,world.h+120);ctx.stroke()}
 for(let y=-120;y<world.h+120;y+=120){ctx.beginPath();ctx.moveTo(-120,y);ctx.lineTo(world.w+120,y);ctx.stroke()}ctx.restore();
 trees.forEach(drawTree);rocks.forEach(drawRock);resources.forEach(drawResource);drawCamp();drawPlayer();
 // snow overlay
 ctx.fillStyle="#fff";snow.forEach(s=>{let q=screen(s.x,s.y);if(q.x>-5&&q.x<W+5&&q.y>-5&&q.y<H+5){ctx.globalAlpha=s.a;ctx.beginPath();ctx.arc(q.x,q.y,s.r,0,7);ctx.fill()}});ctx.globalAlpha=1;
}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function update(dt){
 let dx=0,dy=0;if(keys.up||keys.w)dy--;if(keys.down||keys.s)dy++;if(keys.left||keys.a)dx--;if(keys.right||keys.d)dx++;
 if(dx||dy){let l=Math.hypot(dx,dy);dx/=l;dy/=l;if(dx)p.dir=dx>0?1:-1;let sp=p.speed;if(keys.shift&&p.energy>5){sp=290;p.energy-=18*dt}else p.energy=Math.min(100,p.energy+8*dt);p.x+=dx*sp*dt;p.y+=dy*sp*dt}else p.energy=Math.min(100,p.energy+14*dt);
 p.x=clamp(p.x,45,world.w-45);p.y=clamp(p.y,45,world.h-45);
 camera.x=clamp(p.x-W/2,0,world.w-W);camera.y=clamp(p.y-H/2,0,world.h-H);
 snow.forEach(s=>{s.y+=s.drift*dt;s.x+=Math.sin((s.y+s.x)*.01)*5*dt;if(s.y>world.h)s.y=0});
 night=(night+dt/180)%1;
}
function collect(){
 let nearest=null,nd=999;
 resources.forEach(o=>{if(!o.got){let d=dist(p,o);if(d<nd){nd=d;nearest=o}}});
 if(nearest&&nd<85){
  nearest.got=true;inv[nearest.type]++; if(Math.random()<.35){inv.coins++;showToast("+1 🪙")}
  showToast(nearest.type==="wood"?"+1 🪵 madeira":nearest.type==="stone"?"+1 🪨 pedra":"+1 🌿 erva"); updateUI();
 }else if(dist(p,camp)<130 && inv.wood>=5){win()}
 else showToast("Aproxime-se de um recurso.");
}
function dash(){if(p.energy>=25){keys.shift=true;setTimeout(()=>keys.shift=false,450);p.energy-=10}else showToast("Sem energia!")}
function updateUI(){
 hpEl.textContent=Math.round(p.hp);energyEl.textContent=Math.round(p.energy);coinsEl.textContent=inv.coins;
 woodEl.textContent=inv.wood;stoneEl.textContent=inv.stone;herbEl.textContent=inv.herb;coinBagEl.textContent=inv.coins;
 let n=Math.min(inv.wood,5);progressEl.style.width=(n/5*100)+"%";
 questText.textContent=inv.wood<5?`Colete 5 pedaços de madeira (${inv.wood}/5) e encontre o acampamento.`:`Madeira completa! Vá até o acampamento e toque em Coletar.`;
}
function showToast(t){toast.textContent=t;toast.style.opacity=1;clearTimeout(showToast.t);showToast.t=setTimeout(()=>toast.style.opacity=0,1200)}
function win(){if(won)return;won=true;running=false;document.getElementById("message").textContent="🎉 Missão concluída! Você sobreviveu ao inverno.";document.getElementById("message").style.opacity=1;showToast("🏆 Vitória!");}
function loop(t){if(!running)return;let dt=Math.min(.035,(t-last)/1000||0);last=t;update(dt);draw();updateUI();requestAnimationFrame(loop)}
function start(){document.getElementById("start").classList.add("hidden");running=true;last=performance.now();requestAnimationFrame(loop)}
document.getElementById("play").addEventListener("click",start);
document.getElementById("collect").addEventListener("click",collect);
document.getElementById("dash").addEventListener("click",dash);
document.getElementById("bag").addEventListener("click",()=>document.getElementById("inventory").classList.remove("hidden"));
document.getElementById("closeBag").addEventListener("click",()=>document.getElementById("inventory").classList.add("hidden"));
addEventListener("keydown",e=>{const k=e.key.toLowerCase();if(["arrowup","w"].includes(k))keys.up=true;if(["arrowdown","s"].includes(k))keys.down=true;if(["arrowleft","a"].includes(k))keys.left=true;if(["arrowright","d"].includes(k))keys.right=true;if(k==="shift")keys.shift=true;if(k==="e")collect()});
addEventListener("keyup",e=>{const k=e.key.toLowerCase();if(["arrowup","w"].includes(k))keys.up=false;if(["arrowdown","s"].includes(k))keys.down=false;if(["arrowleft","a"].includes(k))keys.left=false;if(["arrowright","d"].includes(k))keys.right=false;if(k==="shift")keys.shift=false});
document.querySelectorAll("[data-key]").forEach(b=>{
 const k=b.dataset.key;
 const on=e=>{e.preventDefault();keys[k]=true};const off=e=>{e.preventDefault();keys[k]=false};
 b.addEventListener("pointerdown",on);b.addEventListener("pointerup",off);b.addEventListener("pointercancel",off);b.addEventListener("pointerleave",off);
});
updateUI();draw();
