'use strict';
/* ============================================================
   Domínio neutro de idioma + motor de gamificação (100% derivado do histórico)
   ============================================================ */
const MUSCLES = ['chest','back','legs','shoulders','biceps','triceps','abs','glutes','calves','cardio','mobility','other'];
const EQUIPS  = ['barbell','dumbbell','machine','cable','bodyweight','kettlebell','band','bike','other'];
const isCardioKey = m => m === 'cardio' || m === 'mobility';

/* Mapeia textos antigos (pt/en) para chaves neutras */
const LEGACY_MUSCLE = { peito:'chest', costas:'back', pernas:'legs', ombros:'shoulders', biceps:'biceps', triceps:'triceps', abdomen:'abs', gluteos:'glutes', panturrilha:'calves', cardio:'cardio', mobilidade:'mobility', outro:'other',
  chest:'chest', back:'back', legs:'legs', shoulders:'shoulders', abs:'abs', glutes:'glutes', calves:'calves', mobility:'mobility', other:'other' };
const LEGACY_EQUIP = { barra:'barbell', halteres:'dumbbell', maquina:'machine', polia:'cable', 'peso corporal':'bodyweight', kettlebell:'kettlebell', elastico:'band', bike:'bike', outro:'other',
  barbell:'barbell', dumbbell:'dumbbell', machine:'machine', cable:'cable', bodyweight:'bodyweight', band:'band', other:'other' };
function muscleKey(v){ if(!v) return ''; const n = U.norm(v); return MUSCLES.includes(v) ? v : (LEGACY_MUSCLE[n] || 'other'); }
function equipKey(v){ if(!v) return ''; const n = U.norm(v); return EQUIPS.includes(v) ? v : (LEGACY_EQUIP[n] || 'other'); }
const isCardio = ex => isCardioKey(ex.muscle);

/* ---------- Patentes (tabela única; nomes no i18n: rank.<id>) ---------- */
const RANKS = [
  { id:'recruit',    min:1,  bars:1, chev:0, stars:0, laurel:0, color:'#8E959E' },
  { id:'private',    min:3,  bars:0, chev:1, stars:0, laurel:0, color:'#B87333' },
  { id:'corporal',   min:6,  bars:0, chev:2, stars:0, laurel:0, color:'#CD7F32' },
  { id:'sergeant',   min:10, bars:0, chev:3, stars:0, laurel:0, color:'#C9D1DB' },
  { id:'warrant',    min:15, bars:1, chev:3, stars:0, laurel:0, color:'#E5E9F0' },
  { id:'lieutenant', min:20, bars:0, chev:0, stars:1, laurel:0, color:'#F5C542' },
  { id:'captain',    min:27, bars:0, chev:0, stars:2, laurel:0, color:'#F5C542' },
  { id:'major',      min:35, bars:0, chev:0, stars:3, laurel:0, color:'#FFB020' },
  { id:'colonel',    min:45, bars:0, chev:0, stars:4, laurel:0, color:'#FFD166' },
  { id:'general',    min:60, bars:0, chev:0, stars:5, laurel:1, color:'#22D3EE' },
  { id:'marshal',    min:80, bars:0, chev:0, stars:5, laurel:2, color:'#FFD76A' }
];
const rankForLevel = l => { let r = RANKS[0]; for(const x of RANKS) if(l >= x.min) r = x; return r; };
const rankById = id => RANKS.find(r=>r.id === id) || RANKS[0];

/* ---------- XP / nível ---------- */
const XP_RULES = { set:10, exercise:15, session:50, cardioPerMin:1, cardioMax:60, pr:40, dailyCap:400, minSets:3, minMinutes:10, maxSessionMin:240 };
const xpToNext = n => Math.round(100 * Math.pow(n, 1.5));        // XP para sair do nível n e chegar ao n+1
function cumXp(level){ let s = 0; for(let i=1;i<level;i++) s += xpToNext(i); return s; }   // XP acumulado necessário para ALCANÇAR o nível
function levelFromXp(xp){ let l = 1, need = xpToNext(1), acc = 0; while(acc + need <= xp && l < 999){ acc += need; l++; need = xpToNext(l); } return l; }
function levelProgress(xpTotal){
  const level = levelFromXp(xpTotal), base = cumXp(level), need = xpToNext(level);
  const rank = rankForLevel(level), idx = RANKS.indexOf(rank), next = RANKS[idx+1] || null;
  return { level, xpInLevel: xpTotal - base, xpNeeded: need, pct: Math.min(100, (xpTotal - base) / need * 100),
    rank, nextRank: next, xpToNextRank: next ? Math.max(0, cumXp(next.min) - xpTotal) : 0 };
}

/* ---------- Insígnias SVG (geradas por código, sem letras, genéricas) ---------- */
function starPoints(cx, cy, R){
  const pts = [];
  for(let i=0;i<10;i++){ const ang = -Math.PI/2 + i*Math.PI/5, r = i%2 ? R*0.42 : R; pts.push((cx + r*Math.cos(ang)).toFixed(2) + ',' + (cy + r*Math.sin(ang)).toFixed(2)); }
  return pts.join(' ');
}
const STAR_POS = {
  1:[[32,32,9]], 2:[[24,32,7.5],[40,32,7.5]], 3:[[32,22,7],[23,38,7],[41,38,7]],
  4:[[23,24,6.5],[41,24,6.5],[23,40,6.5],[41,40,6.5]], 5:[[22,24,6],[32,22,6],[42,24,6],[27,40,6],[37,40,6]]
};
function insigniaSVG(rankId, size, locked){
  const r = rankById(rankId), c = locked ? '#4A4F57' : r.color, rim = locked ? '#32363C' : r.color;
  const glow = (!locked && r.id === 'marshal') ? ' filter="url(#g)"' : '';
  let g = '';
  g += '<circle cx="32" cy="32" r="30" fill="#0D0F12" stroke="' + rim + '" stroke-width="2.5"/>';
  g += '<circle cx="32" cy="32" r="25.5" fill="none" stroke="' + rim + '" stroke-opacity=".25" stroke-width="1"/>';
  if(r.laurel){
    const lc = (!locked && r.laurel === 2) ? '#FFD76A' : c;
    for(const side of [-1,1]) for(let i=0;i<6;i++){
      const th = (28 + i*24) * Math.PI/180, R = 25;
      const x = 32 + side*R*Math.sin(th), y = 32 + R*Math.cos(th), rot = side*(90 - th*180/Math.PI);
      g += '<ellipse cx="' + x.toFixed(2) + '" cy="' + y.toFixed(2) + '" rx="2.1" ry="4.4" fill="' + lc + '" transform="rotate(' + rot.toFixed(1) + ' ' + x.toFixed(2) + ' ' + y.toFixed(2) + ')"/>';
    }
  }
  if(r.chev){
    const h = r.chev * 8, y0 = (r.bars ? 17 : 32 - h/2 + 1);
    for(let i=0;i<r.chev;i++){ const y = y0 + i*8; g += '<polyline points="19,' + (y+7) + ' 32,' + y + ' 45,' + (y+7) + '" fill="none" stroke="' + c + '" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>'; }
  }
  if(r.bars){ const y = r.chev ? 46 : 29; g += '<rect x="19" y="' + y + '" width="26" height="6" rx="2" fill="' + c + '"/>'; }
  if(r.stars){ STAR_POS[r.stars].forEach(p=>{ g += '<polygon points="' + starPoints(p[0], p[1], p[2]) + '" fill="' + c + '"/>'; }); }
  const defs = glow ? '<defs><filter id="g" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="1.6" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>' : '';
  const s = size || 48;
  return '<svg xmlns="' + SVGNS + '" viewBox="0 0 64 64" width="' + s + '" height="' + s + '" aria-hidden="true" focusable="false">' + defs + '<g' + glow + '>' + g + '</g></svg>';
}
function insigniaEl(rankId, size, locked){ return U.el('span', { class:'insignia', html: insigniaSVG(rankId, size, locked), style:{width:(size||48)+'px', height:(size||48)+'px'} }); }
const svgDataUrl = svg => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);

/* ---------- Ícones das conquistas ---------- */
const ACH_ICON = {
  flag:'<path d="M5 21V4"/><path d="M5 4h12l-2.5 4L17 12H5"/>',
  dumbbell:'<path d="M6.5 6.5v11M17.5 6.5v11M3.5 9v6M20.5 9v6M6.5 12h11"/>',
  kettle:'<circle cx="12" cy="14" r="6.5"/><path d="M8.5 9a4 4 0 0 1 7 0"/>',
  medal:'<circle cx="12" cy="15" r="6"/><path d="M8.5 9.5 6 3h4l2 4 2-4h4l-2.5 6.5"/>',
  trophy:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0z"/><path d="M7 6H4v2a3 3 0 0 0 3 3M17 6h3v2a3 3 0 0 1-3 3"/>',
  crown:'<path d="M3 18h18M4 18 3 7l5 4 4-6 4 6 5-4-1 11"/>',
  calcheck:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M9 15l2 2 4-4"/>',
  repeat:'<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',
  shield:'<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  arrowup:'<path d="M12 20V6M6 12l6-6 6 6"/><path d="M5 3h14"/>',
  star:'<polygon points="12 2 15 9 22 9.5 16.5 14 18.5 21 12 17 5.5 21 7.5 14 2 9.5 9 9"/>',
  burst:'<path d="M12 2v5M12 17v5M2 12h5M17 12h5M5 5l3.5 3.5M15.5 15.5 19 19M19 5l-3.5 3.5M8.5 15.5 5 19"/><circle cx="12" cy="12" r="2"/>',
  weight:'<path d="M6 8h12l3 12H3z"/><circle cx="12" cy="5" r="2"/>',
  mountain:'<path d="M2 20 9 7l4 7 3-4 6 10z"/>',
  layers:'<polygon points="12 2 2 7 12 12 22 7"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
  heart:'<path d="M20.8 5.6a5.5 5.5 0 0 0-7.8 0L12 6.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 22l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/>',
  pulse:'<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
  infinity:'<path d="M12 12c-2-3-4-5-6-5a5 5 0 0 0 0 10c2 0 4-2 6-5s4-5 6-5a5 5 0 0 1 0 10c-2 0-4-2-6-5z"/>',
  sunrise:'<path d="M17 18a5 5 0 0 0-10 0M12 3v5M4.2 10.2l1.4 1.4M1 18h2M21 18h2M18.4 11.6l1.4-1.4M23 22H1M8 6l4-3 4 3"/>',
  moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  weekend:'<rect x="3" y="4" width="8" height="16" rx="2"/><rect x="13" y="4" width="8" height="16" rx="2"/><path d="M7 9v6M17 9v6"/>',
  uturn:'<path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  chev1:'<polyline points="5 15 12 8 19 15"/>',
  chev3:'<polyline points="5 9 12 3 19 9"/><polyline points="5 15 12 9 19 15"/><polyline points="5 21 12 15 19 21"/>',
  starline:'<polygon points="12 3 14.5 9 21 9.5 16 13.8 17.5 20.5 12 17 6.5 20.5 8 13.8 3 9.5 9.5 9"/>'
};
function achIconSVG(name, color, size){
  return '<svg xmlns="' + SVGNS + '" viewBox="0 0 24 24" width="' + (size||28) + '" height="' + (size||28) + '" fill="none" stroke="' + color + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + (ACH_ICON[name]||'') + '</svg>';
}

/* ---------- Conquistas: dados + check puro ---------- */
/* metric = campo do snapshot calculado só a partir do histórico; check(history,data) devolve {cur,target,done} */
const ACHIEVEMENTS = [
  { id:'first_workout', icon:'flag',      metric:'workouts', target:1 },
  { id:'workouts_10',   icon:'dumbbell',  metric:'workouts', target:10 },
  { id:'workouts_25',   icon:'kettle',    metric:'workouts', target:25 },
  { id:'workouts_50',   icon:'medal',     metric:'workouts', target:50 },
  { id:'workouts_100',  icon:'trophy',    metric:'workouts', target:100 },
  { id:'workouts_250',  icon:'crown',     metric:'workouts', target:250 },
  { id:'week_goal_1',   icon:'calcheck',  metric:'weeksMet', target:1 },
  { id:'week_streak_4', icon:'repeat',    metric:'weeksStreak', target:4 },
  { id:'week_streak_12',icon:'shield',    metric:'weeksStreak', target:12 },
  { id:'pr_1',          icon:'arrowup',   metric:'prs', target:1 },
  { id:'pr_10',         icon:'star',      metric:'prs', target:10 },
  { id:'pr_variety_5',  icon:'burst',     metric:'prKeys', target:5 },
  { id:'volume_10t',    icon:'weight',    metric:'volumeKg', target:10000 },
  { id:'volume_50t',    icon:'mountain',  metric:'volumeKg', target:50000 },
  { id:'volume_100t',   icon:'layers',    metric:'volumeKg', target:100000 },
  { id:'cardio_5h',     icon:'heart',     metric:'cardioMin', target:300 },
  { id:'cardio_25h',    icon:'pulse',     metric:'cardioMin', target:1500 },
  { id:'cardio_100h',   icon:'infinity',  metric:'cardioMin', target:6000 },
  { id:'early_bird',    icon:'sunrise',   metric:'early', target:1 },
  { id:'night_owl',     icon:'moon',      metric:'night', target:1 },
  { id:'weekend_warrior',icon:'weekend',  metric:'weekend', target:1 },
  { id:'comeback',      icon:'uturn',     metric:'comeback', target:1 },
  { id:'variety_6',     icon:'grid',      metric:'variety', target:6 },
  { id:'first_promotion',icon:'chev1',    metric:'level', target:RANKS[1].min },
  { id:'reach_sergeant',icon:'chev3',     metric:'level', target:RANKS.find(r=>r.id==='sergeant').min },
  { id:'reach_lieutenant',icon:'starline',metric:'level', target:RANKS.find(r=>r.id==='lieutenant').min }
].map(a => Object.assign(a, { check(history, data, game){ const g = game || computeGame(history, data); const cur = g.m[a.metric] || 0; return { cur, target:a.target, done: cur >= a.target }; } }));

/* ---------- Missões (sorteadas por semente da data) ---------- */
const QUEST_POOL = {
  day: [
    { id:'d_sets12', g:'sets', metric:'sets', target:12, xp:30 }, { id:'d_sets20', g:'sets', metric:'sets', target:20, xp:50 },
    { id:'d_ex4', g:'ex', metric:'ex', target:4, xp:30 }, { id:'d_cardio20', g:'cardio', metric:'cardio', target:20, xp:30 },
    { id:'d_dur40', g:'dur', metric:'dur', target:40, xp:30 }, { id:'d_pr1', g:'pr', metric:'prs', target:1, xp:50 },
    { id:'d_vol3000', g:'vol', metric:'volume', target:3000, xp:40 }, { id:'d_muscles3', g:'mus', metric:'muscles', target:3, xp:30 }
  ],
  week: [
    { id:'w_days3', g:'days', metric:'days', target:3, xp:80 }, { id:'w_days4', g:'days', metric:'days', target:4, xp:100 },
    { id:'w_days5', g:'days', metric:'days', target:5, xp:130 }, { id:'w_pr1', g:'pr', metric:'prs', target:1, xp:100 },
    { id:'w_pr3', g:'pr', metric:'prs', target:3, xp:150 }, { id:'w_sets60', g:'sets', metric:'sets', target:60, xp:100 },
    { id:'w_vol15000', g:'vol', metric:'volume', target:15000, xp:120 }, { id:'w_cardio60', g:'cardio', metric:'cardio', target:60, xp:80 },
    { id:'w_muscles5', g:'mus', metric:'muscles', target:5, xp:100 }
  ]
};
function questsFor(scope, key){
  const pool = QUEST_POOL[scope].slice(), rnd = U.rng(U.hash(scope + ':' + key));
  for(let i=pool.length-1;i>0;i--){ const j = Math.floor(rnd()*(i+1)); [pool[i],pool[j]] = [pool[j],pool[i]]; }
  const out = [], seen = new Set();
  for(const q of pool){ if(seen.has(q.g)) continue; seen.add(q.g); out.push(q); if(out.length === 3) break; }
  return out;
}
function aggregateInfos(infos){
  const a = { sets:0, ex:0, cardio:0, dur:0, prs:0, volume:0, muscles:0, days:0 }, mus = new Set(), days = new Set();
  infos.forEach(i=>{ a.sets += i.sets; a.ex += i.exAll; a.cardio += i.cardioMin; a.dur += i.durMin; a.prs += i.prs.length; a.volume += i.volume; i.muscles.forEach(m=>mus.add(m)); days.add(i.day); });
  a.muscles = mus.size; a.days = days.size; return a;
}

/* ---------- Sessão: informações derivadas (puro) ---------- */
function sessionInfo(s){
  let sets = 0, exAll = 0, cardioMin = 0, volume = 0;
  const muscles = new Set();
  (s.exercises || []).forEach(ex=>{
    const list = ex.sets || [], done = list.filter(x=>x.done);
    if(!done.length) return;
    if(list.every(x=>x.done)) exAll++;
    if(ex.muscle && ex.muscle !== 'other') muscles.add(ex.muscle);
    done.forEach(st=>{
      if(ex.cardio || 'minutes' in st){ cardioMin += U.parseNum(st.minutes) || 0; return; }
      sets++; const r = U.parseNum(st.reps), l = U.parseNum(st.load);
      if(r && l) volume += r*l;
    });
  });
  const durMin = Math.min(XP_RULES.maxSessionMin, Math.max(0, ((s.completedAt||0) - (s.startedAt || s.completedAt || 0)) / 60000));
  return { id:s.id, ts:s.completedAt, day:U.dayKey(s.completedAt), startedAt:s.startedAt || s.completedAt, sets, exAll, cardioMin, volume, durMin, muscles:[...muscles],
    qualified: (sets >= XP_RULES.minSets && durMin >= XP_RULES.minMinutes) || cardioMin >= XP_RULES.minMinutes, prs:[] };
}

/* ---------- Motor: tudo a partir do histórico ---------- */
const PLAN_PATTERN = { 1:[1], 2:[1,4], 3:[1,3,5], 4:[1,2,4,5], 5:[1,2,3,4,5], 6:[1,2,3,4,5,6], 7:[1,2,3,4,5,6,0] };
function plannedDows(data){
  const set = new Set((data.days || []).filter(d=>d.dow !== null && d.dow !== undefined && d.dow !== '').map(d=>Number(d.dow)));
  if(set.size) return set;
  return new Set(PLAN_PATTERN[Math.min(7, Math.max(1, Number(data.settings && data.settings.weeklyGoal) || 3))]);
}

function computeGame(history, data, nowTs){
  const now = nowTs || Date.now(), nowKey = U.dayKey(now);
  const goal = Math.min(7, Math.max(1, Number(data.settings && data.settings.weeklyGoal) || 3));
  const sessions = (history || []).filter(s=>s && typeof s.completedAt === 'number' && Array.isArray(s.exercises)).slice().sort((a,b)=>a.completedAt - b.completedAt);
  const infos = sessions.map(sessionInfo);

  /* 1) PRs (baseline: todas as sessões; só conta XP se a sessão qualifica) */
  const best = {};   // key -> { maxLoad, byLoad:{load:maxReps} }
  sessions.forEach((s, idx)=>{
    const seen = [];
    (s.exercises||[]).forEach(ex=>{
      if(ex.cardio) return;
      const key = ex.key || ('n:' + U.norm(ex.name));
      const done = (ex.sets||[]).filter(x=>x.done && !('minutes' in x));
      if(!done.length) return;
      const b = best[key];
      let pr = null;
      if(b){
        done.forEach(st=>{
          const l = U.parseNum(st.load) || 0, r = U.parseNum(st.reps) || 0; if(!r) return;
          const isNew = l > b.maxLoad || (l === b.maxLoad && r > (b.byLoad[l] || 0));
          if(isNew && (!pr || l > pr.load || (l === pr.load && r > pr.reps))) pr = { key, name:ex.name, load:l, reps:r, prev:b.maxLoad };
        });
      }
      if(pr) infos[idx].prs.push(pr);
      seen.push([key, done]);
    });
    seen.forEach(([key, done])=>{
      const b = best[key] || (best[key] = { maxLoad:0, byLoad:{} });
      done.forEach(st=>{ const l = U.parseNum(st.load) || 0, r = U.parseNum(st.reps) || 0; if(!r) return; if(l > b.maxLoad) b.maxLoad = l; if(r > (b.byLoad[l]||0)) b.byLoad[l] = r; });
    });
  });

  /* 2) XP, nível, patente, missões, métricas — cronológico, só sessões qualificadas */
  const qual = infos.filter(i=>i.qualified);
  const dailyXp = {}, reports = {}, achievements = {}, quests = {}, rankHistory = {}, weekDays = {}, weekDow = {}, weekMus = {};
  const m = { workouts:0, volumeKg:0, cardioMin:0, prs:0, prKeys:0, weeksStreak:0, weeksMet:0, early:0, night:0, weekend:0, comeback:0, variety:0, level:1, xp:0, bestWeekSessions:0 };
  const prKeySet = new Set();
  let xpTotal = 0, level = 1, rank = RANKS[0], prevDay = null;
  const metWeeks = new Set();
  const byDay = {}; qual.forEach(i=>{ (byDay[i.day] = byDay[i.day] || []).push(i); });
  const days = Object.keys(byDay).sort();

  const credit = (day, raw) => { const used = dailyXp[day] || 0, ok = Math.max(0, Math.min(raw, XP_RULES.dailyCap - used)); dailyXp[day] = used + ok; return ok; };
  const setAch = (id, ts) => { if(!achievements[id]) achievements[id] = ts; };
  const snapshotAch = ts => { ACHIEVEMENTS.forEach(a=>{ if((m[a.metric]||0) >= a.target) setAch(a.id, ts); }); };
  const levelTrack = ts => {
    level = levelFromXp(xpTotal); m.level = level; m.xp = xpTotal;
    const r = rankForLevel(level);
    if(!rankHistory[r.id]) rankHistory[r.id] = ts;
    if(r !== rank){ for(const x of RANKS){ if(x.min <= level && !rankHistory[x.id]) rankHistory[x.id] = ts; } rank = r; }
  };
  if(qual.length) rankHistory.recruit = qual[0].ts;

  days.forEach(day=>{
    const dayInfos = byDay[day], wk = U.weekKey(day);
    dayInfos.forEach(info=>{
      const lvlBefore = level, rankBefore = rank.id;
      const xp = { sets: info.sets*XP_RULES.set, ex: info.exAll*XP_RULES.exercise, session: XP_RULES.session, cardio: Math.min(XP_RULES.cardioMax, Math.floor(info.cardioMin)*XP_RULES.cardioPerMin), pr: info.prs.length*XP_RULES.pr };
      const raw = xp.sets + xp.ex + xp.session + xp.cardio + xp.pr;
      const got = credit(day, raw);
      xp.raw = raw; xp.total = got; xp.capped = got < raw;
      xpTotal += got;
      // métricas
      m.workouts++; m.volumeKg += info.volume; m.cardioMin += info.cardioMin; m.prs += info.prs.length; info.prs.forEach(p=>prKeySet.add(p.key)); m.prKeys = prKeySet.size;
      if(new Date(info.startedAt).getHours() < 7) m.early = 1;
      if(new Date(info.ts).getHours() >= 21) m.night = 1;
      const wd = (weekDays[wk] = weekDays[wk] || new Set()); wd.add(day);
      const dw = (weekDow[wk] = weekDow[wk] || new Set()); dw.add(U.dow(day));
      if(dw.has(6) && dw.has(0)) m.weekend = 1;
      const wm = (weekMus[wk] = weekMus[wk] || new Set()); info.muscles.forEach(x=>wm.add(x)); m.variety = Math.max(m.variety, wm.size);
      m.bestWeekSessions = Math.max(m.bestWeekSessions, wd.size);
      if(wd.size >= goal) metWeeks.add(wk);
      m.weeksMet = metWeeks.size;
      let st = 0, w = wk; while(metWeeks.has(w)){ st++; w = U.addDays(w, -7); } m.weeksStreak = Math.max(m.weeksStreak, st);
      if(prevDay && U.daysBetween(prevDay, day) >= 14) m.comeback = 1;
      prevDay = day;
      levelTrack(info.ts);
      snapshotAch(info.ts);
      reports[info.id] = { qualified:true, xp, prs:info.prs, levelBefore:lvlBefore, levelAfter:level, rankBefore, rankAfter:rank.id, questDone:[], questXp:0, info };
    });
    /* missões do dia e da semana (avaliadas ao fim do dia) */
    const last = dayInfos[dayInfos.length-1];
    const dAgg = aggregateInfos(dayInfos);
    const wInfos = qual.filter(i=>U.weekKey(i.day) === wk && i.day <= day);
    const wAgg = aggregateInfos(wInfos);
    const check = (scope, key, agg) => questsFor(scope, key).forEach(q=>{
      const id = (scope === 'day' ? 'd:' : 'w:') + key + ':' + q.id;
      if(quests[id] || (agg[q.metric] || 0) < q.target) return;
      const got = credit(day, q.xp);
      quests[id] = last.ts; xpTotal += got;
      const rep = reports[last.id]; rep.questDone.push(q.id); rep.questXp += got;
    });
    check('day', day, dAgg); check('week', wk, wAgg);
    const lb = level, rb = rank.id; levelTrack(last.ts); snapshotAch(last.ts);
    if(level !== lb || rank.id !== rb){ const rep = reports[last.id]; rep.levelAfter = level; rep.rankAfter = rank.id; }
  });
  Object.values(reports).forEach(r=>{ r.newAch = []; });
  Object.entries(achievements).forEach(([id, ts])=>{ const r = qual.find(i=>i.ts === ts); if(r && reports[r.id]) reports[r.id].newAch.push(id); });

  /* 3) Sequências (dias planejados + gelos) */
  const dows = plannedDows(data), planned = k => dows.has(U.dow(k));
  const qualDays = new Set(days);
  let cur = 0, bestStreak = 0, freezes = 0, wkStreak = 0, bestWk = 0, lastCounted = null;
  const frozenDays = []; let lastBreak = null;
  if(days.length){
    for(let k = days[0]; k <= nowKey; k = U.addDays(k, 1)){
      if(qualDays.has(k)){ cur++; bestStreak = Math.max(bestStreak, cur); lastCounted = k; }
      else if(k < nowKey && planned(k) && cur > 0){
        if(freezes > 0){ freezes--; frozenDays.push(k); } else { lastBreak = { lost:cur, at:k }; cur = 0; }
      }
      if(U.dow(k) === 0 && k < nowKey){
        const n = (weekDays[U.weekKey(k)] || new Set()).size;
        if(n >= goal){ wkStreak++; bestWk = Math.max(bestWk, wkStreak); if(wkStreak % 4 === 0) freezes = Math.min(2, freezes + 1); } else wkStreak = 0;
      }
    }
  }
  const curWk = U.weekKey(nowKey), curWeekMet = (weekDays[curWk] || new Set()).size >= goal;
  const lp = levelProgress(xpTotal);
  return {
    xpTotal, level: lp.level, rankId: lp.rank.id, rankHistory, achievements, quests, dailyXp,
    streak: { current:cur, best:bestStreak, freezes, lastCountedDate:lastCounted, frozenDays, lastBreak },
    weekStreak: { current: wkStreak + (curWeekMet ? 1 : 0), best: Math.max(bestWk, wkStreak + (curWeekMet ? 1 : 0)) },
    m, reports, qualifiedCount: qual.length
  };
}

/* Progresso das missões de hoje/semana (para exibir) */
function questBoard(history, data, nowTs){
  const now = nowTs || Date.now(), day = U.dayKey(now), wk = U.weekKey(day);
  const infos = (history||[]).map(sessionInfo).filter(i=>i.qualified);
  const g = computeGame(history, data, now);
  const mk = (scope, key, agg) => questsFor(scope, key).map(q=>{
    const id = (scope === 'day' ? 'd:' : 'w:') + key + ':' + q.id;
    return { def:q, cur:Math.min(q.target, Math.round(agg[q.metric]||0)), target:q.target, done:!!g.quests[id] || (agg[q.metric]||0) >= q.target };
  });
  return {
    day: mk('day', day, aggregateInfos(infos.filter(i=>i.day === day))),
    week: mk('week', wk, aggregateInfos(infos.filter(i=>U.weekKey(i.day) === wk && i.day <= day)))
  };
}
