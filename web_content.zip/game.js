(()=>{"use strict";
const $=id=>document.getElementById(id),canvas=$("screen"),ctx=canvas.getContext("2d");
canvas.width=720;canvas.height=1280;ctx.scale(2,2);ctx.imageSmoothingEnabled=true;const W=360,H=640;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),rand=(a,b)=>a+Math.random()*(b-a);
const guns=[
{name:"SIDEARM PISTOL",cost:0,damage:8,rate:2.4,color:"#ffd36b",kind:"pistol",desc:"Your first sidearm. Make every shot count."},
{name:"DUAL SERVICE PISTOLS",cost:180,damage:7,rate:3.8,color:"#ffe18a",kind:"dual",desc:"Two pistols. Twice the trouble."},
{name:"HEAVY REVOLVER",cost:360,damage:24,rate:1.45,color:"#ffcc77",kind:"revolver",desc:"Slow, heavy rounds with serious stopping power."},
{name:"MACHINE PISTOL",cost:620,damage:6,rate:7.5,color:"#ffe18a",kind:"smg",desc:"A compact storm of bullets."},
{name:"PUMP SHOTGUN",cost:950,damage:8,rate:1.05,color:"#ffb35a",kind:"shotgun",desc:"A brutal close-range spread."},
{name:"SAWN-OFF TWINS",cost:1500,damage:12,rate:1.25,color:"#ffad62",kind:"sawnoff",desc:"Two short barrels. One very bad day for zombies."},
{name:"SUBMACHINE GUN",cost:2400,damage:9,rate:8,color:"#ffe18a",kind:"smg",desc:"Fast automatic fire."},
{name:"ASSAULT CARBINE",cost:3900,damage:17,rate:5.2,color:"#ffd36b",kind:"rifle",desc:"A dependable automatic rifle."},
{name:"BURST RIFLE",cost:6200,damage:20,rate:3.2,color:"#ffdb78",kind:"burst",desc:"Three-round bursts with punch."},
{name:"COMBAT SHOTGUN",cost:9800,damage:11,rate:1.7,color:"#ffad62",kind:"shotgun",desc:"A wider, heavier blast."},
{name:"LIGHT MACHINE GUN",cost:15500,damage:15,rate:8.5,color:"#ffcf61",kind:"lmg",desc:"A belt-fed wall of lead."},
{name:"DUAL SMGS",cost:24000,damage:8,rate:12,color:"#ffe18a",kind:"dualSmg",desc:"Two automatic weapons, both singing."},
{name:"FLAMETHROWER",cost:38000,damage:11,rate:6,color:"#ff642e",kind:"flame",desc:"Set the horde alight."},
{name:"CROSSBOW",cost:60000,damage:90,rate:1.4,color:"#a7d6b1",kind:"crossbow",desc:"Silent, heavy bolts."},
{name:"GRENADE LAUNCHER",cost:95000,damage:95,rate:1.15,color:"#ff8b54",kind:"boom",desc:"Explosive crowd control."},
{name:"MINIGUN",cost:150000,damage:12,rate:15,color:"#fff08a",kind:"mini",desc:"Six barrels. Absolutely no manners."},
{name:"TESLA CANNON",cost:240000,damage:65,rate:2.8,color:"#7ef8ff",kind:"tesla",desc:"Chain lightning through the undead."},
{name:"RAILGUN",cost:380000,damage:240,rate:1.3,color:"#b8e6ff",kind:"rail",desc:"Punches a hole through the whole line."},
{name:"PLASMA DESTROYER",cost:600000,damage:180,rate:4,color:"#bd8cff",kind:"plasma",desc:"Experimental energy weapon."},
{name:"HELLSTORM MEGA GUN",cost:1000000,damage:45,rate:18,color:"#ff7148",kind:"mega",desc:"A ridiculous endgame bullet hose."},
{name:"ORBITAL DOOM CANNON",cost:2500000,damage:600,rate:1.8,color:"#ffec9a",kind:"orbital",desc:"The last word in excessive firepower."}
];
const upgradeDefs=[
["Stopping Power","Bullet damage",65,"damage",.22,"×"],
["Trigger Happy","Fire rate",90,"rate",.035,"×"],
["Pocket Full of Change","Coins earned per kill",100,"coins",.12,"×"],
["Critical Carnage","Critical hit chance",140,"crit",.006,"+"],
["Head Hunter","Critical hit damage",150,"critDmg",.08,"×"],
["Combat Conditioning","Maximum health",110,"health",8,"+"],
["Rapid Recovery","Health regeneration",130,"regen",.12,"+"],
["Kevlar Layers","Damage resistance",160,"armor",.004,"+"],
["Long Barrel","Projectile speed",95,"speed",.035,"×"],
["Extended Magazine","Multi-shot chance",180,"multi",.004,"+"],
["Explosive Tips","Explosion chance",240,"explosive",.003,"+"],
["Scavenger Instinct","Bonus coin drops",125,"drop",.004,"+"],
["Adrenaline Rush","Damage when low health",190,"adrenaline",.008,"+"],
["Zombie Bait","More enemies, more rewards",210,"horde",.012,"+"],
["Lucky Break","Rare bonus drop chance",260,"rare",.003,"+"],
["Hot Lead","Burn damage",220,"burn",.025,"×"],
["Shock Therapy","Chain lightning chance",280,"shock",.0025,"+"],
["Big Game Hunter","Boss damage",300,"boss",.035,"×"],
["Quick Hands","Reload / firing handling",175,"handling",.025,"×"],
["Battle Focus","Aim and hit radius",115,"aim",.02,"×"],
["Last Stand","Chance to survive a fatal hit",400,"laststand",.002,"+"],
["War Profiteer","Wave completion bonus",240,"wavecash",.06,"×"],
["Bloodlust","Damage per consecutive kill",200,"streak",.002,"+"],
["Fortune's Favourite","All coin income",350,"fortune",.025,"×"],
["Twin-Grip Training","Unlock dual-wielding and improve off-hand accuracy",45,"dual",1,"unlock"],
["Bullet Storm","Extra bullets fired per tap — build towards a 100-shot volley",65,"volley",1,"bullet"],
["Heavy Calibre","Bigger bullets and heavier impact",420,"calibre",.12,"×"],
["Execution Protocol","More damage against wounded zombies",520,"execute",.015,"+"],
["Ricochet Rounds","Bullets can bounce into another target",700,"ricochet",.01,"+"],
["Shockwave Muzzle","More powerful hit effects and knockback",800,"shockwave",.02,"+"]
];
const state={cash:0,runCash:0,running:true,runKills:0,wave:1,kills:0,best:1,hp:100,maxHp:100,damage:12,rate:1,bonus:1,weapon:0,
gunLevels:Array(guns.length).fill(0),unlocked:guns.map((_,i)=>i===0),upgradeLevels:Array(upgradeDefs.length).fill(0),
music:true,zombies:[],shots:[],particles:[],texts:[],bloodStains:[],limbs:[],spawn:0,fire:0,last:0,elapsed:0,screenShake:0,streak:0,streakTimer:0,
crit:0,critDmg:1.8,regen:0,armor:0,speed:1,multi:0,explosive:0,drop:0,adrenaline:0,horde:0,rare:0,burn:1,shock:0,boss:1,handling:1,aim:1,laststand:0,wavecash:1,streakBonus:0,fortune:1,dualWield:false,volley:1,calibre:1,execute:0,ricochet:0,shockwave:0,heroRecoil:0,muzzleTimer:0};
let audio=null,musicTimer=null,musicStep=0,musicOn=true,lastSave=0,pointerDown=false,groanTimer=2.5;
function save(){try{localStorage.setItem("lms_save_v3",JSON.stringify({...state,zombies:[],shots:[],particles:[],texts:[],bloodStains:[],limbs:[]}));}catch(e){}}
function load(){try{let s=JSON.parse(localStorage.getItem("lms_save_v3")||"null");if(!s)s=JSON.parse(localStorage.getItem("lms_save_v2")||"null");if(!s)s=JSON.parse(localStorage.getItem("lms_save_v1")||"null");if(s){Object.assign(state,s);state.cash=(Number.isFinite(+s.cash)?+s.cash:0)+Math.max(0,Number(s.runCash)||0);state.runCash=0;state.running=false;state.runKills=0;state.gunLevels=Array.from({length:guns.length},(_,i)=>Array.isArray(s.gunLevels)?(s.gunLevels[i]||0):0);state.unlocked=Array.from({length:guns.length},(_,i)=>Array.isArray(s.unlocked)?(s.unlocked[i]??(i===0)):(i===0));state.upgradeLevels=Array.from({length:upgradeDefs.length},(_,i)=>Array.isArray(s.upgradeLevels)?(s.upgradeLevels[i]||0):0);state.weapon=clamp(Number(s.weapon)||0,0,guns.length-1);state.zombies=[];state.shots=[];state.particles=[];state.texts=[];state.bloodStains=[];state.limbs=[];}}catch(e){}}
function toast(t){$("toast").textContent=t;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),1250)}
function audioReady(){try{audio=audio||new(window.AudioContext||window.webkitAudioContext)();if(audio.state==="suspended")audio.resume();return true}catch(e){return false}}
function tone(freq,dur=.08,type="square",vol=.025,when=0,slide=0){if(!audioReady())return;let o=audio.createOscillator(),g=audio.createGain(),t=audio.currentTime+when;o.type=type;o.frequency.setValueAtTime(freq,t);if(slide)o.frequency.exponentialRampToValueAtTime(Math.max(25,freq+slide),t+dur);g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0001,t+dur);o.connect(g);g.connect(audio.destination);o.start(t);o.stop(t+dur+.01)}
function noise(dur=.12,vol=.03,filter=900){if(!audioReady())return;let n=Math.floor(audio.sampleRate*dur),buf=audio.createBuffer(1,n,audio.sampleRate),d=buf.getChannelData(0);for(let i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);let src=audio.createBufferSource(),f=audio.createBiquadFilter(),g=audio.createGain();src.buffer=buf;f.type="lowpass";f.frequency.value=filter;g.gain.value=vol;src.connect(f);f.connect(g);g.connect(audio.destination);src.start()}
function sfxGun(){let k=guns[state.weapon].kind;if(k==="shotgun"||k==="sawnoff"){noise(.22,.095,1450);tone(72,.17,"sawtooth",.07,0,-48);tone(42,.12,"sine",.05)}else if(k==="flame"){noise(.22,.055,620);tone(58,.18,"sawtooth",.035)}else if(k==="tesla"||k==="plasma"){tone(720,.2,"sawtooth",.045,0,-560);noise(.12,.035,3000)}else if(k==="boom"||k==="orbital"){noise(.38,.12,520);tone(52,.28,"sawtooth",.09,0,-30)}else if(k==="pistol"||k==="revolver"||k==="dual"){noise(.095,.07,2200);tone(118,.085,"triangle",.045,0,-70);tone(920,.025,"square",.012,.005,-420)}else{noise(.085,k==="mini"?.05:.038,2100);tone(k==="smg"||k==="dualSmg"?165:112,.06,"square",.03,0,-42)}}
function zombieSound(type){if(type==="brute"){tone(58,.28,"sawtooth",.045,0,-22);noise(.2,.03,240)}else if(type==="runner"){tone(210,.09,"sawtooth",.018,0,-100)}else{tone(95,.12,"triangle",.018,0,-40);noise(.07,.012,500)}}
function killSound(){tone(115,.08,"square",.025,0,90);tone(260,.1,"triangle",.018,.04,120)}
function startMusic(){if(!state.music)return;const m=$("musicTrack");if(!m)return;try{m.volume=.34;const p=m.play();if(p&&p.catch)p.catch(()=>{});}catch(e){}}
function setMusic(on){state.music=on;if(on){audioReady();startMusic()}else{const m=$("musicTrack");if(m)m.pause()}if($("musicBtn"))$("musicBtn").textContent="♫ MUSIC: "+(on?"ON":"OFF");save()}
function getLevel(k){return state.upgradeLevels[k]||0}
function applyStats(){let L=state.upgradeLevels;state.damage=8*Math.pow(1.105,L[0]||0);state.rate=1*Math.pow(1.035,L[1]||0);state.bonus=Math.pow(1.12,L[2]||0);state.crit=Math.min(.75,(L[3]||0)*.006);state.critDmg=1.8*Math.pow(1.08,L[4]||0);state.maxHp=100+(L[5]||0)*8;state.hp=Math.min(state.hp,state.maxHp);state.regen=(L[6]||0)*.12;state.armor=Math.min(.8,(L[7]||0)*.004);state.speed=1*Math.pow(1.035,L[8]||0);state.multi=Math.min(.8,(L[9]||0)*.004);state.explosive=Math.min(.7,(L[10]||0)*.003);state.drop=(L[11]||0)*.004;state.adrenaline=(L[12]||0)*.008;state.horde=(L[13]||0)*.012;state.rare=(L[14]||0)*.003;state.burn=1+(L[15]||0)*.025;state.shock=Math.min(.65,(L[16]||0)*.0025);state.boss=1+(L[17]||0)*.035;state.handling=1+(L[18]||0)*.025;state.aim=1+(L[19]||0)*.02;state.laststand=Math.min(.65,(L[20]||0)*.002);state.wavecash=1+(L[21]||0)*.06;state.streakBonus=(L[22]||0)*.002;state.fortune=1+(L[23]||0)*.025;state.dualWield=(L[24]||0)>0;state.volley=Math.min(100,1+(L[25]||0));state.calibre=Math.pow(1.12,L[26]||0);state.execute=Math.min(.8,(L[27]||0)*.015);state.ricochet=Math.min(.9,(L[28]||0)*.01);state.shockwave=Math.min(2,(L[29]||0)*.02)}
function updateHud(){$("deployBtn").hidden=state.running;$("cash").textContent=Math.floor(state.cash).toLocaleString();$("runCash").textContent=Math.floor(state.runCash).toLocaleString();$("shopBank").textContent=Math.floor(state.cash).toLocaleString();$("wave").textContent=state.wave;$("kills").textContent=state.kills;$("dmg").textContent=Math.round(state.damage);$("rate").textContent=(state.rate*guns[state.weapon].rate).toFixed(1)+"/s";$("best").textContent=state.best;$("healthbar").style.width=(state.hp/state.maxHp*100)+"%";$("weaponLabel").textContent=guns[state.weapon].name+" · LV "+state.gunLevels[state.weapon];}
function spawn(){let r=Math.random(),boss=state.wave%5===0&&Math.random()<.055;let type=boss?"boss":r<.13?"brute":r<.38?"runner":r<.55?"spitter":"walker";let hp=type==="boss"?700+state.wave*90:type==="brute"?100+state.wave*15:type==="runner"?34+state.wave*5:type==="spitter"?55+state.wave*7:25+state.wave*4;
let size=type==="boss"?27:type==="brute"?20:type==="runner"?13:type==="spitter"?16:15;
state.zombies.push({x:rand(15,345),y:rand(45,180),hp,max:hp,speed:(type==="runner"?rand(14,19):type==="brute"?rand(5,7):type==="boss"?rand(4,6):rand(7,10))*(1+Math.min(1.8,Math.max(0,state.wave-1)*.012)),size,type,hit:0,phase:rand(0,6.28),attack:0});}
function target(){let best=null,dist=1e12;for(const z of state.zombies){let d=(z.x-180)**2+(z.y-490)**2;if(d<dist){dist=d;best=z}}return best}
function shoot(){if(!state.zombies.length){state.fire=1/(state.rate*guns[state.weapon].rate);return}let z=target(),g=guns[state.weapon],n=g.kind==="shotgun"||g.kind==="sawnoff"?6:Math.max(1,Math.floor(state.volley));if(g.kind==="burst")n=Math.max(n,3);if(g.kind==="dual"||g.kind==="dualSmg")n=Math.max(n,2);if(state.dualWield)n=Math.min(100,n+1);if(Math.random()<state.multi)n+=1+Math.floor(Math.random()*3);n=Math.min(100,n);let baseDamage=state.damage*(g.damage/8)*Math.pow(1.035,state.gunLevels[state.weapon]||0)*state.calibre;for(let i=0;i<n;i++){let spread=n===1?0:(i-(n-1)/2)*Math.min(.075,.7/n);let originX=state.dualWield?(i%2?200:160):200;let dx=z.x-originX,dy=z.y-492,dist=Math.hypot(dx,dy)||1;let speed=460*state.speed;let vx=dx/dist*speed+spread*260,vy=dy/dist*speed;let crit=Math.random()<state.crit;state.shots.push({x:originX,y:492,vx,vy,life:1.4,damage:baseDamage*(crit?state.critDmg:1)*(state.hp/state.maxHp<.35?1+state.adrenaline:1)*(z.type==="boss"?state.boss:1)*(state.burn>1?1+(state.burn-1)*.12:1),crit,kind:g.kind,color:g.color,radius:g.kind==="rail"||g.kind==="orbital"?4:2.2,ricochet:state.ricochet});}state.muzzleTimer=.12;state.heroRecoil=1;for(let q=0;q<7;q++)state.particles.push({x:200,y:482,vx:rand(-55,65),vy:rand(-65,25),life:rand(.08,.2),max:.2,color:q%2?g.color:"#fff0a0",size:rand(2,5),flash:true});state.screenShake=Math.max(state.screenShake,g.kind==="boom"?.14:.025);sfxGun();state.fire=1/(state.rate*g.rate*state.handling*Math.pow(1.008,state.gunLevels[state.weapon]||0));}
function addText(x,y,t,color="#ffe08a"){state.texts.push({x,y,text:t,color,life:.75})}
function bloodBurst(x,y,power=1){
 const n=Math.max(2,Math.floor(5*power));
 for(let i=0;i<n;i++){let a=rand(0,Math.PI*2),v=rand(22,105)*power;state.particles.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-rand(5,35),life:rand(.22,.62),max:.62,color:["#a70f1b","#d21e2c","#6f0b17","#ee3942"][i%4],size:rand(2,5)*power,blood:true})}
 if(power>1.4){state.bloodStains.push({x,y,rx:rand(4,10)*power,ry:rand(2,5)*power,life:24,angle:rand(0,6.28)});if(state.bloodStains.length>36)state.bloodStains.shift()}
}
function detachLimb(z){
 if(state.limbs.length>18)state.limbs.shift();
 const side=Math.random()<.5?-1:1,part=Math.random()<.55?"arm":"leg";
 state.limbs.push({x:z.x+side*4,y:z.y-rand(0,5),vx:rand(-100,100),vy:rand(-150,-55),rot:rand(-2,2),spin:rand(-8,8),life:3.2,part,skin:z.type==="boss"?"#a94c48":z.type==="brute"?"#8c7654":"#83a66a",cloth:"#39443a"});
 bloodBurst(z.x+side*5,z.y-rand(2,10),2.4);
}
function kill(z){state.kills++;state.runKills++;state.streak++;state.streakTimer=3;let base=1; // Every ordinary kill starts at exactly one coin.
let coins=Math.max(1,Math.floor((base+state.drop*10+((z.type==="brute")?1:0)+(z.type==="boss"?40:0))*state.bonus*state.fortune*(1+state.streak*state.streakBonus)));
if(z.type==="runner")coins=Math.max(1,Math.floor(coins*1.15));if(z.type==="boss")coins+=Math.floor(40+state.wave*5);
state.runCash+=coins;addText(z.x,z.y-12,"+"+coins+" COIN", "#ffdf75");if(z.type==="boss"){state.runCash+=Math.floor(100*state.wavecash);toast("BOSS DOWN! BIG PAYDAY!");}
for(let i=0;i<(z.type==="boss"?24:10);i++)state.particles.push({x:z.x,y:z.y,vx:rand(-100,100),vy:rand(-110,60),life:rand(.25,.8),max:.8,color:["#83b34e","#b7c86b","#812f27","#d6a05a"][i%4],size:rand(2,5)});bloodBurst(z.x,z.y-5,z.type==="boss"?3.2:2.1);if(Math.random()<.48||z.type==="boss")detachLimb(z);
killSound();if(state.runKills%30===0){state.wave++;state.best=Math.max(state.best,state.wave);state.hp=Math.min(state.maxHp,state.hp+12);let bonus=Math.floor((15+state.wave*3)*state.wavecash);state.runCash+=bonus;addText(180,150,"WAVE BONUS +"+bonus,"#9fffa0");toast("WAVE "+state.wave+" — KEEP MOVING!");}
if(Math.random()<state.rare){let bonus=Math.floor(10+state.wave*2);state.runCash+=bonus;addText(z.x,z.y-30,"RARE DROP +"+bonus,"#b88cff")}updateHud();save()}
function explode(x,y,r,damage){state.screenShake=.18;for(let i=state.zombies.length-1;i>=0;i--){let z=state.zombies[i],d=Math.hypot(z.x-x,z.y-y);if(d<r){z.hp-=damage*(1-d/r*.5);z.hit=.15;if(z.hp<=0){state.zombies.splice(i,1);kill(z)}}}for(let i=0;i<28;i++)state.particles.push({x,y,vx:rand(-150,150),vy:rand(-160,130),life:rand(.2,.7),max:.7,color:i%2?"#ff9a3d":"#ffe17a",size:rand(3,8)})}
function endRun(){if(!state.running)return;state.running=false;pointerDown=false;state.cash+=Math.floor(state.runCash);state.runCash=0;state.streak=0;state.shots.length=0;state.zombies.length=0;state.particles.length=0;state.bloodStains.length=0;state.limbs.length=0;state.hp=0;$("runSummary").textContent=`You survived to wave ${state.wave}, killed ${state.runKills} undead and banked your run earnings.`;$("bankTotal").textContent=state.cash.toLocaleString();$("endOverlay").hidden=false;updateHud();save();}
function startRun(){state.running=true;state.runCash=0;state.runKills=0;state.wave=1;state.hp=state.maxHp;state.spawn=.6;state.fire=0;state.streak=0;state.zombies=[];state.shots=[];state.particles=[];state.texts=[];state.bloodStains=[];state.limbs=[];pointerDown=false;$("endOverlay").hidden=true;updateHud();save();}
function update(dt){state.elapsed+=dt;if(!state.running){state.screenShake=Math.max(0,state.screenShake-dt);return;}groanTimer-=dt;if(groanTimer<=0&&state.zombies.length){let z=state.zombies[Math.floor(Math.random()*state.zombies.length)];zombieSound(z.type);groanTimer=rand(2.8,5.5)}state.fire=Math.max(0,state.fire-dt);state.spawn-=dt;state.streakTimer-=dt;if(state.streakTimer<=0)state.streak=0;if(state.regen>0)state.hp=Math.min(state.maxHp,state.hp+state.regen*dt);
if(state.spawn<=0){let count=Math.min(12,1+Math.floor(state.wave*.28)+Math.floor(state.horde*2));count=Math.min(count,Math.max(0,48-state.zombies.length));for(let i=0;i<count;i++)spawn();state.spawn=Math.max(.85,2.75-state.wave*.01)}
if(pointerDown&&state.fire<=0)shoot();
for(let i=state.zombies.length-1;i>=0;i--){let z=state.zombies[i];z.phase+=dt*5;z.hit=Math.max(0,z.hit-dt);let dx=180-z.x,dy=500-z.y,d=Math.hypot(dx,dy)||1;z.x+=dx/d*z.speed*dt;z.y+=dy/d*z.speed*dt;if(d<34){let dmg=(z.type==="boss"?24:z.type==="brute"?15:8)*(1-state.armor)*dt;state.hp-=dmg;if(state.hp<=0){if(Math.random()<state.laststand){state.hp=1;toast("LAST STAND!");}else{endRun();return;}}}}
for(let i=state.shots.length-1;i>=0;i--){let b=state.shots[i];b.x+=b.vx*dt;b.y+=b.vy*dt;b.life-=dt;let hit=null;for(const z of state.zombies){if(Math.hypot(z.x-b.x,z.y-b.y)<z.size+Math.max(5,state.aim*5)){hit=z;break}}
if(hit){let dealt=b.damage*(hit.hp/hit.max<.35?1+state.execute:1);hit.hp-=dealt;hit.hit=.16;if(Math.random()<.38||b.crit)bloodBurst(hit.x+rand(-4,4),hit.y-rand(2,9),b.crit?1.5:.75);if(state.shockwave>0){let pd=Math.hypot(hit.x-180,hit.y-492)||1;hit.x+=(hit.x-180)/pd*state.shockwave*3;hit.y+=(hit.y-492)/pd*state.shockwave*3;}if(b.crit)addText(hit.x,hit.y-20,"CRITICAL!","#fff3a1");if(Math.random()<state.explosive)explode(hit.x,hit.y,68,b.damage*.75);if(b.kind==="tesla"||Math.random()<state.shock){let other=state.zombies.find(q=>q!==hit&&Math.hypot(q.x-hit.x,q.y-hit.y)<105);if(other){other.hp-=b.damage*.55;state.particles.push({x:hit.x,y:hit.y,vx:0,vy:0,life:.12,max:.12,color:"#8dfaff",size:12})}}
if(hit.hp<=0){state.zombies.splice(state.zombies.indexOf(hit),1);kill(hit)}if(b.ricochet>0&&Math.random()<b.ricochet){let next=state.zombies.find(q=>q!==hit&&Math.hypot(q.x-hit.x,q.y-hit.y)<130);if(next){let d=Math.hypot(next.x-hit.x,next.y-hit.y)||1;b.x=hit.x;b.y=hit.y;b.vx=(next.x-hit.x)/d*470;b.vy=(next.y-hit.y)/d*470;b.damage*=.65;b.ricochet=0;continue}}state.shots.splice(i,1)}else if(b.life<=0||b.y<0||b.y>H||b.x<0||b.x>W)state.shots.splice(i,1)}
for(let i=state.particles.length-1;i>=0;i--){let p=state.particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.97;p.vy+=(p.blood?210:100)*dt;p.life-=dt;if(p.life<=0)state.particles.splice(i,1)}
for(let i=state.limbs.length-1;i>=0;i--){let l=state.limbs[i];l.x+=l.vx*dt;l.y+=l.vy*dt;l.vy+=260*dt;l.vx*=.985;l.rot+=l.spin*dt;l.life-=dt;if(l.y>620){l.y=620;l.vy*=-.18;l.vx*=.7}if(l.life<=0)state.limbs.splice(i,1)}
for(let i=state.bloodStains.length-1;i>=0;i--){state.bloodStains[i].life-=dt;if(state.bloodStains[i].life<=0)state.bloodStains.splice(i,1)}
for(let i=state.texts.length-1;i>=0;i--){let t=state.texts[i];t.y-=25*dt;t.life-=dt;if(t.life<=0)state.texts.splice(i,1)}
state.screenShake=Math.max(0,state.screenShake-dt);state.heroRecoil=Math.max(0,state.heroRecoil-dt*9);state.muzzleTimer=Math.max(0,state.muzzleTimer-dt);updateHud()}
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.max(1,Math.round(w)),Math.max(1,Math.round(h)))}
function poly(points,color){ctx.fillStyle=color;ctx.beginPath();ctx.moveTo(points[0][0],points[0][1]);for(let i=1;i<points.length;i++)ctx.lineTo(points[i][0],points[i][1]);ctx.closePath();ctx.fill()}
function oval(x,y,rx,ry,color){ctx.fillStyle=color;ctx.beginPath();ctx.ellipse(x,y,rx,ry,0,0,Math.PI*2);ctx.fill()}
function drawBackground(){
let sky=ctx.createLinearGradient(0,0,0,430);sky.addColorStop(0,"#101c2b");sky.addColorStop(.55,"#35424a");sky.addColorStop(1,"#9a6547");ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
let moon=ctx.createRadialGradient(286,90,4,286,90,42);moon.addColorStop(0,"#f4d9a0");moon.addColorStop(1,"#f4d9a000");ctx.fillStyle=moon;ctx.fillRect(235,39,102,102);oval(286,90,17,17,"#d7c49a");
// distant smoke columns
for(let i=0;i<4;i++){ctx.globalAlpha=.12;oval(45+i*83,120+(i%2)*25,18+i*3,65,"#b6aaa0");oval(58+i*83,84+(i%2)*20,23,38,"#b6aaa0")}ctx.globalAlpha=1;
// ruined skyline with broken rooflines
for(let i=0;i<9;i++){let x=i*45-12,h=95+(i*37%115),w=36+(i%3)*7;rect(x,355-h,w,h,"#18252a");rect(x+4,360-h,w-8,5,"#52605a");for(let yy=0;yy<Math.floor(h/25);yy++)for(let xx=0;xx<3;xx++){if((i+yy+xx)%3!==0)rect(x+7+xx*9,360-h+14+yy*23,4,8,(i+yy)%2?"#d18b4d":"#6b765f")}if(i%2===0)poly([[x,355-h],[x+9,344-h],[x+16,355-h],[x+25,337-h],[x+w,355-h]],"#18252a")}
// distant burning windows
for(let i=0;i<4;i++){let x=18+i*92;oval(x,335,13,20,"#ed7840");oval(x,337,6,12,"#ffcf72")}
// street and perspective
poly([[0,375],[360,375],[360,640],[0,640]],"#252d2b");poly([[115,375],[245,375],[360,640],[0,640]],"#303a35");ctx.strokeStyle="#647067";ctx.globalAlpha=.4;ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(180,376);ctx.lineTo(180,640);ctx.moveTo(110,405);ctx.lineTo(35,640);ctx.moveTo(250,405);ctx.lineTo(325,640);ctx.stroke();ctx.globalAlpha=1;
// broken lane markings and cracks
for(let i=0;i<8;i++){let y=408+i*31;let ww=2+i*.7;rect(177-ww,y,ww*2,Math.max(3,10-i*.5),"#b2a47c")}
ctx.strokeStyle="#101816";ctx.lineWidth=2;for(let i=0;i<7;i++){let x=(i*61+state.elapsed*3)%380-10,y=445+(i*43)%175;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+8,y+6);ctx.lineTo(x+4,y+15);ctx.lineTo(x+16,y+21);ctx.stroke()}
// wrecked vehicles at street edges
for(const side of [0,1]){ctx.save();if(side) {ctx.translate(360,0);ctx.scale(-1,1)}rect(3,390,72,31,"#293c3b");rect(10,380,48,18,"#40504b");rect(12,383,17,12,"#8b9990");rect(34,383,19,12,"#637b7b");rect(0,415,80,6,"#12191a");oval(20,420,9,9,"#101314");oval(61,420,9,9,"#101314");rect(5,399,7,5,"#df7846");ctx.restore()}
// foreground rubble
for(let i=0;i<45;i++){let x=(i*83)%360,y=470+(i*47)%160;poly([[x,y],[x+3+(i%5),y-2],[x+8,y+2],[x+5,y+5]],i%3===0?"#626456":"#414a42")}
// fire barrel glow
let glow=ctx.createRadialGradient(311,470,2,311,470,45);glow.addColorStop(0,"#ffb45a88");glow.addColorStop(1,"#ff8a2600");ctx.fillStyle=glow;ctx.fillRect(260,420,100,100);rect(300,461,22,25,"#34302a");rect(303,456,16,8,"#8c5532");poly([[307,457],[302,444],[310,448],[314,432],[319,448],[324,443],[319,458]],"#f7a54a");poly([[310,456],[309,447],[315,451],[318,440],[320,457]],"#ffe08a");
}
function drawZombie(z){let x=z.x,y=z.y+Math.sin(z.phase)*2,s=z.size*(z.type==="boss"?1.22:1),skin=z.type==="boss"?"#a94c48":z.type==="brute"?"#9a795f":z.type==="spitter"?"#9cb86b":(z.phase%1.5<.5?"#8eb58a":z.phase%1.5<1?"#a4a17b":"#879f9d");let dark="#29312b",cloth=z.type==="boss"?"#4c292b":"#39443a";ctx.save();ctx.translate(x,y);ctx.scale(.72,1);ctx.rotate(Math.sin(z.phase*.7)*.05);
oval(0,s*.88,s*.9,4,"#10141199");
// legs and boots
ctx.strokeStyle=cloth;ctx.lineWidth=s*.27;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-s*.25,s*.35);ctx.lineTo(-s*.34,s*.88+Math.sin(z.phase)*2);ctx.moveTo(s*.22,s*.35);ctx.lineTo(s*.32,s*.86-Math.sin(z.phase)*2);ctx.stroke();rect(-s*.58,s*.83,s*.42,s*.18,"#242a25");rect(s*.15,s*.82,s*.45,s*.18,"#242a25");
// torso silhouette
oval(0,-s*.03,s*.58,s*.66,cloth);oval(0,-s*.02,s*.43,s*.57,skin);poly([[-s*.42,-s*.34],[-s*.18,-s*.58],[s*.3,-s*.52],[s*.47,-s*.25],[s*.27,s*.2],[-s*.34,s*.2]],cloth);
// arms
ctx.strokeStyle=skin;ctx.lineWidth=s*.2;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-s*.42,-s*.24);ctx.lineTo(-s*.72,s*.18);ctx.moveTo(s*.42,-s*.24);ctx.lineTo(s*.68,s*.13);ctx.stroke();oval(-s*.72,s*.2,s*.13,s*.16,skin);oval(s*.68,s*.14,s*.13,s*.16,skin);
// neck and head
rect(-s*.16,-s*.64,s*.32,s*.22,"#876044");oval(0,-s*.77,s*.38,s*.37,skin);oval(0,-s*.99,s*.4,s*.15,dark);rect(-s*.36,-s*.84,s*.72,s*.11,dark);
// facial features, glowing eyes, torn mouth
oval(-s*.14,-s*.79,s*.055,s*.05,"#f5dc8b");oval(s*.14,-s*.79,s*.055,s*.05,"#f5dc8b");oval(-s*.14,-s*.79,s*.025,s*.035,"#291b18");oval(s*.14,-s*.79,s*.025,s*.035,"#291b18");rect(-s*.15,-s*.59,s*.3,s*.055,"#351f20");rect(-s*.1,-s*.58,s*.07,s*.035,"#e5d2ad");
// wounds, straps and type-specific armour
rect(-s*.34,-s*.1,s*.2,s*.09,"#782f2b");rect(s*.12,s*.06,s*.17,s*.08,"#c49a69");ctx.strokeStyle="#b7a17a";ctx.lineWidth=Math.max(1,s*.06);ctx.beginPath();ctx.moveTo(-s*.25,-s*.35);ctx.lineTo(s*.28,s*.22);ctx.stroke();
// layered pixel-art highlights: mottled skin, torn fabric, seams and grime
oval(-s*.25,-s*.48,s*.12,s*.09,"#c2b18a");oval(s*.23,-s*.43,s*.1,s*.07,"#647f65");
oval(-s*.29,-s*.02,s*.075,s*.055,"#d1b38a");oval(s*.28,s*.12,s*.08,s*.05,"#6e3938");
rect(-s*.29,-s*.25,s*.16,s*.035,"#a8b18a");rect(s*.08,-s*.18,s*.2,s*.035,"#d2bd8b");
rect(-s*.34,s*.13,s*.13,s*.055,"#6b302d");rect(s*.16,-s*.31,s*.14,s*.045,"#6c8270");
ctx.strokeStyle="#d0b28a";ctx.lineWidth=Math.max(.7,s*.025);ctx.beginPath();ctx.moveTo(-s*.24,-s*.1);ctx.lineTo(-s*.1,s*.14);ctx.moveTo(s*.1,-s*.32);ctx.lineTo(s*.25,-s*.13);ctx.stroke();
for(let q=0;q<4;q++){let px=(q-1.5)*s*.13;oval(px,-s*.51+(q%2)*s*.08,s*.035,s*.025,q%2?"#d5c18d":"#536b57")}

if(z.type==="runner"){oval(-s*.48,-s*.35,s*.14,s*.2,skin);oval(s*.48,-s*.35,s*.14,s*.2,skin)}if(z.type==="brute"||z.type==="boss"){oval(0,-s*.34,s*.72,s*.19,"#4c5146");rect(-s*.5,-s*1.12,s,Math.max(2,s*.1),"#c4a875")}if(z.type==="spitter"){oval(0,-s*.48,s*.32,s*.13,"#b7d879");rect(-s*.12,-s*.27,s*.24,s*.13,"#a4d56c")}
if(z.hit>0){ctx.globalAlpha=.42;oval(0,-s*.2,s*.85,s,"#fff1d6");ctx.globalAlpha=1;for(let k=0;k<3;k++){rect(rand(-s*.6,s*.6),rand(-s*.2,s*.45),2,3,"#a52e2a")}}if(z.type==="boss"){rect(-s,-s*1.25,s*2,5,"#371e20");rect(-s,-s*1.25,s*2*clamp(z.hp/z.max,0,1),5,"#f15b47")}ctx.restore()}
function drawHero(){let x=180,y=520;ctx.save();ctx.translate(x,y);ctx.scale(.31,.31);ctx.translate(0,-state.heroRecoil*3);oval(0,26,28,7,"#10151199");
// Compact commando silhouette, deliberately close to zombie scale.
poly([[-20,0],[-7,0],[-8,23],[-18,23]],"#353c32");poly([[7,0],[20,0],[18,23],[7,23]],"#353c32");rect(-21,20,17,7,"#171e1d");rect(5,20,18,7,"#171e1d");
poly([[-19,-38],[-13,-48],[13,-48],[20,-37],[17,-3],[-17,-3]],"#52684a");poly([[-13,-42],[0,-47],[14,-40],[12,-8],[-12,-8]],"#344637");rect(-12,-34,24,8,"#77845a");rect(-13,-20,10,12,"#26342d");rect(3,-20,10,12,"#26342d");
ctx.strokeStyle="#b77d55";ctx.lineWidth=9;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-15,-35);ctx.lineTo(-25,-14);ctx.moveTo(15,-35);ctx.lineTo(24,-16);ctx.stroke();oval(-25,-12,6,5,"#252a25");oval(24,-14,6,5,"#252a25");
rect(-6,-54,12,9,"#a96f4d");oval(0,-65,14,15,"#c18a62");rect(-14,-75,28,7,"#9d2825");poly([[-13,-73],[-20,-80],[-9,-78],[0,-75],[12,-78],[19,-83],[14,-70]],"#c4382e");rect(-9,-66,5,3,"#191c19");rect(4,-66,5,3,"#191c19");rect(-5,-57,10,3,"#583a2d");
let kind=guns[state.weapon].kind;function pistol(px,flip){ctx.save();ctx.translate(px,-23);if(flip)ctx.scale(-1,1);ctx.rotate(-.16-state.heroRecoil*.12);rect(-3,-3,23,6,"#262d2d");rect(13,-6,12,3,"#9aa49b");rect(2,2,7,12,"#69472f");rect(20,-4,5,3,"#d2c9a8");ctx.restore()}
if(state.dualWield||kind==="dual"||kind==="dualSmg"){pistol(-19,true);pistol(20,false)}else if(kind==="shotgun"||kind==="sawnoff"){ctx.save();ctx.translate(13,-22);ctx.rotate(-.14);rect(-7,-3,42,8,"#343b39");rect(24,-5,15,4,"#aab0a5");rect(0,4,12,9,"#68462e");ctx.restore()}else{ctx.save();ctx.translate(12,-23);ctx.rotate(-.16);rect(-5,-3,37,7,"#292f2d");rect(22,-7,16,4,"#9aa49b");rect(0,3,12,9,"#69472f");ctx.restore()}
if(state.muzzleTimer>0){let a=clamp(state.muzzleTimer/.16,0,1);ctx.globalAlpha=a;let flash=ctx.createRadialGradient(50,-26,1,50,-26,25);flash.addColorStop(0,"#ffffff");flash.addColorStop(.25,"#fff5a4");flash.addColorStop(.62,"#ff9b35");flash.addColorStop(1,"#ff4a1200");ctx.fillStyle=flash;ctx.beginPath();ctx.arc(50,-26,25,0,Math.PI*2);ctx.fill();poly([[40,-28],[57,-42],[53,-29],[73,-23],[51,-19],[45,-9]],"#fff4b0");oval(51,-26,6,5,"#fff");if(state.dualWield){ctx.save();ctx.scale(-1,1);ctx.fillStyle=flash;ctx.beginPath();ctx.arc(50,-26,25,0,Math.PI*2);ctx.fill();poly([[40,-28],[57,-42],[53,-29],[73,-23],[51,-19],[45,-9]],"#fff4b0");ctx.restore()}}ctx.restore()}
function drawBlood(){for(const b of state.bloodStains){ctx.save();ctx.globalAlpha=Math.min(.62,b.life/8);ctx.translate(b.x,b.y);ctx.rotate(b.angle);oval(0,0,b.rx,b.ry,"#570b16");oval(-b.rx*.35,-b.ry*.3,b.rx*.42,b.ry*.3,"#9d1422");ctx.restore()}}
function drawLimb(l){ctx.save();ctx.translate(l.x,l.y);ctx.rotate(l.rot);ctx.globalAlpha=Math.min(1,l.life/.5);if(l.part==="arm"){ctx.strokeStyle=l.cloth;ctx.lineWidth=5;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-7,0);ctx.lineTo(5,1);ctx.stroke();ctx.strokeStyle=l.skin;ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(5,1);ctx.lineTo(18,4);ctx.stroke();oval(19,4,3,3,l.skin);oval(-8,0,3,3,"#9c1521")}else{ctx.strokeStyle=l.cloth;ctx.lineWidth=7;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(-7,0);ctx.lineTo(10,2);ctx.stroke();ctx.strokeStyle=l.skin;ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(10,2);ctx.lineTo(21,4);ctx.stroke();oval(22,4,3,2,l.skin);oval(-8,0,4,3,"#9c1521")}ctx.restore()}
function draw(){ctx.save();if(state.screenShake)ctx.translate(rand(-3,3)*state.screenShake*8,rand(-3,3)*state.screenShake*8);ctx.clearRect(0,0,W,H);drawBackground();drawBlood();state.zombies.forEach(drawZombie);state.limbs.forEach(drawLimb);
for(const b of state.shots){ctx.save();ctx.strokeStyle=b.color;ctx.globalAlpha=.25;ctx.lineWidth=b.radius*4;ctx.beginPath();ctx.moveTo(b.x-b.vx*.045,b.y-b.vy*.045);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.globalAlpha=.9;ctx.strokeStyle=b.color;ctx.lineWidth=b.radius;ctx.lineCap="round";ctx.beginPath();ctx.moveTo(b.x-b.vx*.035,b.y-b.vy*.035);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.globalAlpha=1;ctx.fillStyle="#fff9df";ctx.beginPath();ctx.arc(b.x,b.y,b.radius*.8,0,Math.PI*2);ctx.fill();ctx.restore()}
state.particles.forEach(p=>{ctx.globalAlpha=clamp(p.life/(p.max||.8),0,1);if(p.blood){oval(p.x,p.y,p.size||2,(p.size||2)*.65,p.color)}else if(p.flash){ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,p.size||3,0,Math.PI*2);ctx.fill()}else{ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(p.x,p.y,(p.size||3)*.65,0,Math.PI*2);ctx.fill()}});ctx.globalAlpha=1;drawHero();
for(const t of state.texts){ctx.globalAlpha=clamp(t.life/.25,0,1);ctx.font="bold 11px system-ui,Arial";ctx.textAlign="center";ctx.fillStyle="#10140f";ctx.fillText(t.text,t.x+1,t.y+1);ctx.fillStyle=t.color;ctx.fillText(t.text,t.x,t.y)}ctx.globalAlpha=1;
ctx.textAlign="left";ctx.font="bold 10px system-ui,Arial";ctx.fillStyle="#e8e2c2";ctx.fillText("UNDEAD: "+state.zombies.length,10,615);ctx.fillStyle="#d3a84f";ctx.fillText("STREAK x"+Math.max(1,state.streak),270,615);
let v=ctx.createRadialGradient(180,320,170,180,320,390);v.addColorStop(0,"#0000");v.addColorStop(1,"#0008");ctx.fillStyle=v;ctx.fillRect(0,0,W,H);ctx.restore()}
canvas.addEventListener("pointerdown",e=>{e.preventDefault();if(!state.running)return;audioReady();if(state.music&&$("musicTrack")&&$("musicTrack").paused)startMusic();pointerDown=true;try{canvas.setPointerCapture(e.pointerId)}catch(_){}if(state.fire<=0)shoot()},{passive:false});
window.addEventListener("pointerup",()=>pointerDown=false);window.addEventListener("pointercancel",()=>pointerDown=false);window.addEventListener("blur",()=>pointerDown=false);canvas.addEventListener("contextmenu",e=>e.preventDefault());
function price(base,lv){return Math.min(1e15,Math.floor(base*Math.pow(1.115,lv)))}
function weaponArt(kind,color="#e7bd69"){
 let twin=(kind==="dual"||kind==="dualSmg"||kind==="sawnoff"),long=["shotgun","sawnoff","rifle","burst","lmg","mini","rail","mega","orbital","crossbow","boom"].includes(kind),energy=["tesla","plasma","rail","orbital"].includes(kind);
 let barrel=long?"M65 39 L174 33 L194 38 L193 47 L69 50 Z":"M72 36 L160 33 L176 39 L174 48 L72 48 Z";
 let body=kind==="shotgun"||kind==="sawnoff"?"M65 35 L134 34 L150 44 L132 55 L78 52 Z":"M67 32 L135 31 L151 43 L135 55 L76 52 Z";
 let accent=energy?"#76e9ff":color;
 let svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 220 82"><defs><linearGradient id="bg" x2="0" y2="1"><stop stop-color="#354b55"/><stop offset="1" stop-color="#10191e"/></linearGradient><linearGradient id="metal" x2="0" y2="1"><stop stop-color="#d4ddd9"/><stop offset=".35" stop-color="#59686b"/><stop offset="1" stop-color="#182126"/></linearGradient><linearGradient id="glow"><stop stop-color="${accent}"/><stop offset="1" stop-color="#fff"/></linearGradient></defs><rect width="220" height="82" rx="10" fill="url(#bg)"/><path d="M0 65 L220 15" stroke="#ffffff" stroke-opacity=".08" stroke-width="18"/><g fill="url(#metal)" stroke="#10171b" stroke-width="3">${twin?`<g transform="translate(-28 0) scale(.72 1)"><path d="${barrel}"/><path d="${body}"/><path d="M94 48 L111 52 L105 72 L91 71 Z" fill="#76543b"/><path d="M74 30 L93 25 L101 32 L84 37 Z" fill="#aeb9b4"/></g><g transform="translate(60 0) scale(.72 1)"><path d="${barrel}"/><path d="${body}"/><path d="M94 48 L111 52 L105 72 L91 71 Z" fill="#76543b"/><path d="M74 30 L93 25 L101 32 L84 37 Z" fill="#aeb9b4"/></g>`:`<path d="${barrel}"/><path d="${body}"/><path d="M105 48 L125 52 L117 74 L99 72 Z" fill="#76543b"/><path d="M72 30 L91 25 L104 32 L82 37 Z" fill="#aeb9b4"/>`}</g><path d="M80 34 L144 34" stroke="#e9f0e8" stroke-opacity=".6" stroke-width="2"/><path d="M177 39 L202 38" stroke="url(#glow)" stroke-width="3"/><circle cx="190" cy="42" r="4" fill="${accent}" opacity=".8"/><path d="M20 67 H200" stroke="#ffffff" stroke-opacity=".08"/>${energy?`<path d="M165 20 Q188 7 205 22 Q186 26 176 45" fill="none" stroke="${accent}" stroke-width="2" opacity=".8"/>`:""}</svg>`;
 return "data:image/svg+xml;charset=utf-8,"+encodeURIComponent(svg)
}
function upgradeWeapon(key){const map={damage:"pistol",rate:"smg",coins:"revolver",crit:"revolver",critDmg:"rail",health:"pistol",regen:"pistol",armor:"lmg",speed:"smg",multi:"burst",explosive:"boom",drop:"revolver",adrenaline:"mini",horde:"shotgun",rare:"rail",burn:"flame",shock:"tesla",boss:"rail",handling:"smg",aim:"crossbow",laststand:"shotgun",wavecash:"revolver",streak:"mini",fortune:"revolver",dual:"dual",volley:"mini",calibre:"rail",execute:"revolver",ricochet:"rail",shockwave:"orbital"};let k=map[key]||"pistol";let g=guns.find(x=>x.kind===k)||guns[0];return weaponArt(g.kind,g.color)}
function renderWeapons(){let el=$("weapons");el.innerHTML="";guns.forEach((g,i)=>{let lv=state.gunLevels[i]||0,owned=state.unlocked[i],d=document.createElement("div");d.className="item weaponItem";d.innerHTML=`<div class="weaponVisual"><img src="${weaponArt(g.kind,g.color)}" alt="${g.name} artwork"><div><strong>${g.name}</strong><small>${g.desc} · Power ${g.damage} · Weapon level ${lv.toLocaleString()}</small></div></div><button class="equip">${owned?(i===state.weapon?"EQUIPPED":"EQUIP WEAPON"):"UNLOCK · "+g.cost.toLocaleString()+" COINS"}</button><button class="level">UPGRADE WEAPON · ${price(45+i*20,lv).toLocaleString()}</button>`;let bs=d.querySelectorAll("button");bs[0].onclick=()=>{if(!owned){if(state.cash<g.cost)return toast("NOT ENOUGH COINS");state.cash-=g.cost;state.unlocked[i]=true;state.gunLevels[i]=1}state.weapon=i;updateHud();renderWeapons();save()};bs[1].onclick=()=>{let cost=price(45+i*20,lv);if(!owned)return toast("UNLOCK THIS WEAPON FIRST");if(state.cash<cost)return toast("NOT ENOUGH COINS");state.cash-=cost;state.gunLevels[i]++;renderWeapons();updateHud();save()};el.appendChild(d)})}
const upgradeGroups={damage:"combat",rate:"combat",crit:"combat",critDmg:"combat",multi:"combat",explosive:"combat",shock:"combat",boss:"combat",burn:"combat",health:"survival",regen:"survival",armor:"survival",laststand:"survival",coins:"economy",drop:"economy",rare:"economy",wavecash:"economy",fortune:"economy",streak:"special",horde:"special",speed:"special",adrenaline:"special",handling:"special",aim:"special",dual:"combat",volley:"combat",calibre:"combat",execute:"combat",ricochet:"combat",shockwave:"combat"};
let activeUpgradeFilter="all";
function renderUpgrades(){let el=$("upgradeList");el.innerHTML="";upgradeDefs.forEach((u,i)=>{let lv=getLevel(i),cost=price(u[2],lv),cat=upgradeGroups[u[3]]||"special";if(activeUpgradeFilter!=="all"&&cat!==activeUpgradeFilter)return;let d=document.createElement("div");d.className="upgradeCard";let progress=(lv%100);let effect=u[3]==="volley"?`BULLETS PER TAP: ${Math.min(100,1+lv)} / 100`:u[3]==="dual"?(lv?"DUAL WIELD: UNLOCKED":"DUAL WIELD: LOCKED"):u[3]==="calibre"?`BULLET POWER: x${state.calibre.toFixed(2)}`:`NEXT LEVEL: ${u[4]}${u[5]==="×"?" multiplier":u[5]==="unlock"?" unlock":" bonus"}`;d.innerHTML=`<div class="upgradeTop"><div class="upgradeArt"><img src="${upgradeWeapon(u[3])}" alt="${u[0]} weapon artwork"><span>${({damage:"POWER",rate:"FIRE RATE",coins:"BOUNTY",crit:"CRITICAL",critDmg:"HEADSHOT",health:"HEALTH",regen:"REGEN",armor:"ARMOUR",speed:"SPEED",multi:"MULTI-SHOT",explosive:"EXPLOSIVE",drop:"SCAVENGE",adrenaline:"ADRENALINE",horde:"HORDE",rare:"RARE LOOT",burn:"INCENDIARY",shock:"CHAIN",boss:"BOSS KILLER",handling:"HANDLING",aim:"PRECISION",laststand:"LAST STAND",wavecash:"WAVE PAY",streak:"KILL STREAK",fortune:"FORTUNE",dual:"DUAL WIELD",volley:"BULLET STORM",calibre:"HEAVY CALIBRE",execute:"EXECUTION",ricochet:"RICOCHET",shockwave:"SHOCKWAVE"})[u[3]]||"UPGRADE"}</span></div><div class="upgradeName"><strong>${u[0]}</strong><small>${u[1]}</small></div><span class="levelPill">LV ${lv.toLocaleString()}</span></div><div class="progressTrack"><i style="width:${progress}%"></i></div><div class="upgradeBottom"><span>${effect}</span><button class="buyUpgrade">UPGRADE · ${cost.toLocaleString()} 🪙</button></div>`;d.querySelector("button").onclick=()=>{if(state.cash<cost)return toast("NOT ENOUGH BANKED COINS");state.cash-=cost;state.upgradeLevels[i]=(state.upgradeLevels[i]||0)+1;applyStats();renderUpgrades();updateHud();save();toast(u[0]+" UPGRADED!")};el.appendChild(d)});if(!el.children.length)el.innerHTML='<p class="hint">No upgrades in this category yet.</p>';$ ("shopBank").textContent=state.cash.toLocaleString();}
const storyPages=[
 {img:"assets/story_hero.webp",tag:"DAY 01 · 04:17 AM",speaker:"RADIO BROADCAST",line:"This is an emergency message. The city has fallen. If anyone can hear this, head for the river checkpoint. Do not travel alone."},
 {img:"assets/story_city.webp",tag:"THE CITY · NO SAFE STREETS",speaker:"RADIO BROADCAST",line:"The dead are moving in packs. The eastern bridge is gone. The evacuation route is lost. Anyone still alive must fight their way out."},
 {img:"assets/story_family.webp",tag:"ONE PROMISE LEFT",speaker:"MARA",line:"You said you would get us out of here. I can hear them outside."},
 {img:"assets/story_hero.webp",tag:"THE LAST MAN STANDING",speaker:"SURVIVOR",line:"Stay behind me. First we find supplies. Then we find a way through. If they want this city, they can come and take it."}
];let storyIndex=0;
function paintStory(){let q=storyPages[storyIndex];$("storyImage").src=q.img;$("storyTag").textContent=q.tag;$("storySpeaker").textContent=q.speaker;$("storyLine").textContent=q.line;$("storyCount").textContent=(storyIndex+1)+" / "+storyPages.length;$("storyNext").textContent=storyIndex===storyPages.length-1?"START SURVIVING":"NEXT SCENE";}
function showStory(){storyIndex=0;paintStory();$("storyIntro").hidden=false;$("endOverlay").hidden=true;}
function finishStory(){ $("storyIntro").hidden=true;try{localStorage.setItem("lms_story_seen","1")}catch(e){}audioReady();if(state.music)startMusic();startRun();}
$("storyNext").onclick=()=>{if(storyIndex<storyPages.length-1){storyIndex++;paintStory()}else finishStory()};
$("storySkip").onclick=finishStory;
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{activeUpgradeFilter=b.dataset.filter;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderUpgrades()});
$("shopFromDeath").onclick=()=>{ $("endOverlay").hidden=true;document.querySelector('[data-tab="upgrades"]').click();};
$("restartRun").onclick=()=>startRun();$("deployBtn").onclick=()=>startRun();
$("fuseBtn").onclick=()=>{let own=state.unlocked.map((v,i)=>v?i:-1).filter(i=>i>=0);if(own.length<2)return toast("UNLOCK TWO WEAPONS FIRST");let cost=price(250,state.wave);if(state.cash<cost)return toast("FUSION COST: "+cost);state.cash-=cost;state.damage*=1.16;toast("WEAPON FUSION! +16% DAMAGE");save();updateHud()};
document.querySelectorAll("nav button").forEach(b=>b.onclick=()=>{document.querySelectorAll("nav button").forEach(x=>x.classList.toggle("active",x===b));["battle","arsenal","upgrades"].forEach(t=>$(t+"Panel").hidden=t!==b.dataset.tab);if(b.dataset.tab==="arsenal")renderWeapons();if(b.dataset.tab==="upgrades")renderUpgrades();});
$("musicBtn").onclick=()=>setMusic(!state.music);
const hadSave=!!(localStorage.getItem("lms_save_v3")||localStorage.getItem("lms_save_v2")||localStorage.getItem("lms_save_v1"));load();applyStats();if(hadSave){state.running=false;state.hp=state.maxHp;$("endOverlay").hidden=false;$("runSummary").textContent="Your permanent progress is saved. Spend banked coins, then head back out.";$("bankTotal").textContent=state.cash.toLocaleString();save();}else{state.running=true;}updateHud();renderWeapons();renderUpgrades();document.querySelectorAll("nav button").forEach(b=>b.classList.toggle("active",b.dataset.tab==="upgrades"));$("battlePanel").hidden=true;$("arsenalPanel").hidden=true;$("upgradesPanel").hidden=false;if(state.music){$("musicBtn").textContent="♫ MUSIC: ON";}else $("musicBtn").textContent="♫ MUSIC: OFF";if(!localStorage.getItem("lms_story_seen"))showStory();
let last=performance.now();function loop(now){let dt=Math.min(.04,(now-last)/1000);last=now;update(dt);draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
setInterval(()=>{save();if(Date.now()-lastSave>30000){lastSave=Date.now()}},5000);window.addEventListener("pagehide",save);document.addEventListener("visibilitychange",()=>{if(document.hidden){pointerDown=false;save()}});
})();