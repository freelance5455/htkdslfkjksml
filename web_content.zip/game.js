const THREE = window.THREE;
const $ = (id) => document.getElementById(id);
const ui = { game: $('game'), itemHint: $('item-hint'), grabButton: $('grab-button'), hitButton: $('hit-button'), spawnToggle: $('spawn-toggle'), spawnMenu: $('spawn-menu'), spawnClose: $('spawn-close'), tkControls: $('telekinesis-controls'), tkActivate: $('tk-activate') };
const npcData = [
  { image: 'SockPuppet-removebg-preview.png' },
  { image: "bad-cgi-90's-cgi.webp" },
  { image: 'Smiley.png' },
  { image: 'Minesweeper.png' }
];
const keys = { w: false, a: false, s: false, d: false };
const player = { x: 0, z: 0, y: 1.65, yaw: 0, pitch: 0 };
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(74, innerWidth / innerHeight, 0.1, 180);
scene.add(camera);
const viewModel = new THREE.Group();
camera.add(viewModel);
viewModel.position.set(0.20, -0.15, -0.75);
const crowbarState = { held: false, worldModel: null, viewModel: null, handModel: null, swingTimer: 0, cooldown: 0, impactDelay: 0 };
const pistolState = { model: null, muzzleFlash: null, cooldown: 0, recoil: 0, flashTimer: 0 };
let weaponMode = 'telekinesis';
const telekinesis = { target: null, activeTarget: null, command: null, active: false, outline: null, hand: null, beam: null, beamMaterial: null };
const hitRaycaster = new THREE.Raycaster();
const impactAudio = new Audio('metal-hit-2.mp3');
impactAudio.volume = 0.72;
const pistolAudio = new Audio('Gunshot.mp3');
pistolAudio.volume = 0.55;
const activeTracers = [];
const bulletHoles = [];
const bulletHoleGeometry = new THREE.PlaneGeometry(0.24, 0.24);
const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(1);
const renderScale = 0.6;
function resizeRenderBuffer() { renderer.setSize(Math.max(1, Math.floor(innerWidth * renderScale)), Math.max(1, Math.floor(innerHeight * renderScale)), false); }
resizeRenderBuffer();
renderer.outputEncoding = THREE.sRGBEncoding;
ui.game.appendChild(renderer.domElement);
scene.background = new THREE.Color(0x071d2a); scene.fog = new THREE.FogExp2(0x303236, 0.012);
scene.add(new THREE.AmbientLight(0xa8c8da, 0.8));
const ceilingLight = new THREE.PointLight(0x9bcfff, 1.2, 45); ceilingLight.position.set(0, 7, 0); scene.add(ceilingLight);
const groups = { world: new THREE.Group(), npcs: new THREE.Group(), spawned: new THREE.Group() };
Object.values(groups).forEach((group) => scene.add(group));
const tkBeamGeometry = new THREE.BufferGeometry();
tkBeamGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
telekinesis.beamMaterial = new THREE.LineBasicMaterial({ color: 0x65efff, transparent: true, opacity: 0.95, depthTest: false });
telekinesis.beam = new THREE.Line(tkBeamGeometry, telekinesis.beamMaterial);
telekinesis.beam.frustumCulled = false; telekinesis.beam.visible = false; scene.add(telekinesis.beam);
const activeImpactParticles = [];
const impactParticleGeometry = new THREE.OctahedronGeometry(0.035, 0);
const impactParticleMaterials = [0xffc45b, 0xf3f0dc, 0xaaa9a0].map((color) => new THREE.MeshBasicMaterial({ color }));
const clock = new THREE.Clock();
let gameActive = true, touchLook = null, audioCtx, animatedCoinFrame = -1, animatedRobotFrame = -1, robotSprite = null;
const vehicleState = { active: null, engine: new Audio('engine.mp3'), crash: new Audio('Crashing.mp3'), loader: null, crashCooldown: 0 };
vehicleState.engine.loop = true; vehicleState.engine.volume = 0.38;
vehicleState.crash.volume = 0.72;
vehicleState.engine.addEventListener('ended', () => {
  if (vehicleState.active) {
    vehicleState.engine.currentTime = 0;
    vehicleState.engine.play().catch(() => {});
  }
});
function playVehicleCrash(impactSpeed) {
  if (impactSpeed < 2.4 || vehicleState.crashCooldown > 0) return;
  vehicleState.crashCooldown = 0.48;
  vehicleState.crash.pause();
  vehicleState.crash.currentTime = 0;
  vehicleState.crash.volume = THREE.MathUtils.clamp(0.3 + impactSpeed * 0.045, 0.3, 0.92);
  vehicleState.crash.play().catch(() => {});
}

const assetLoader = new THREE.TextureLoader();
function loadAsset(path, repeatX = 1, repeatY = 1, pixelated = false) {
  const map = assetLoader.load(path);
  map.wrapS = map.wrapT = THREE.RepeatWrapping; map.repeat.set(repeatX, repeatY);
  map.encoding = THREE.sRGBEncoding;
  if (pixelated) { map.magFilter = THREE.NearestFilter; map.minFilter = THREE.NearestFilter; }
  return map;
}
const floorTexture = loadAsset('FloorTexture.jpeg', 10, 10);
const wallTexture = loadAsset('Walltexture.png', 2, 1);
const ceilingTexture = loadAsset('CeilingNoLight.webp', 5, 5);
const coinFrames = Array.from({ length: 8 }, (_, index) => loadAsset('assets/coin-' + String(index).padStart(2, '0') + '.png', 1, 1, true));
const npcTextures = [loadAsset(npcData[0].image)];
const smileyTexture = loadAsset(npcData[2].image);
const minesweeperTexture = loadAsset(npcData[3].image);
const manTexture = loadAsset('Man.png');
const crowbarTexture = loadAsset('crowbar.png');
const heldCrowbarTexture = loadAsset('crowbar-in-hand.png');
const playerHandTexture = loadAsset('PlayerHand.png');
const pistolHandTexture = loadAsset('hand-holding-gun.png');
const bulletHoleTexture = loadAsset('BULLET_Hole.GIF');
const robotFrames = Array.from({ length: 8 }, (_, index) => loadAsset('assets/robot-' + String(index).padStart(2, '0') + '.png'));
let victoryJingle;

function sound(type) {
  if (!audioCtx) return;
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const now = audioCtx.currentTime;
  const notes = type === 'coin' ? [880, 1320] : type === 'win' ? [523, 659, 784, 1047] : [180, 90];
  notes.forEach((frequency, i) => {
    const oscillator = audioCtx.createOscillator(), gain = audioCtx.createGain();
    oscillator.type = type === 'glitch' ? 'sawtooth' : 'triangle'; oscillator.frequency.setValueAtTime(frequency, now + i * (type === 'win' ? 0.13 : 0.07));
    gain.gain.setValueAtTime(type === 'glitch' ? 0.06 : 0.11, now + i * 0.07); gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.07 + 0.22);
    oscillator.connect(gain); gain.connect(audioCtx.destination); oscillator.start(now + i * 0.07); oscillator.stop(now + i * 0.07 + 0.23);
  });
}

function createLoremTexture() {
  const canvas = document.createElement('canvas'); canvas.width = 640; canvas.height = 320;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#d2cdb8'; ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.strokeStyle = '#27364b'; ctx.lineWidth = 12; ctx.strokeRect(8, 8, canvas.width - 16, canvas.height - 16);
  ctx.fillStyle = '#142643'; ctx.font = 'bold 38px Georgia'; ctx.fillText('LOREM IPSUM', 32, 58);
  ctx.fillStyle = '#272727'; ctx.font = '25px Georgia';
  const words = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.';
  let line = '', y = 112;
  words.split(' ').forEach((word) => {
    const next = line ? line + ' ' + word : word;
    if (ctx.measureText(next).width > 560) { ctx.fillText(line, 32, y); line = word; y += 42; } else line = next;
  });
  ctx.fillText(line, 32, y);
  const texture = new THREE.CanvasTexture(canvas); texture.encoding = THREE.sRGBEncoding;
  return texture;
}
const loremTexture = createLoremTexture();

function addCorridor(axis, along, across, end, floorMat, wallMat) {
  const alongX = axis === 'x';
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(alongX ? 20 : 8, alongX ? 8 : 20), floorMat);
  floor.position.set(alongX ? along : across, 0.01, alongX ? across : along); floor.rotation.x = -Math.PI / 2; groups.world.add(floor);
  const roof = new THREE.Mesh(floor.geometry, wallMat);
  roof.position.set(floor.position.x, 8, floor.position.z); roof.rotation.x = Math.PI / 2; groups.world.add(roof);
  if (alongX) {
    [-4.5, 4.5].forEach((z) => { const wall = new THREE.Mesh(new THREE.BoxGeometry(20, 8, 1), wallMat); wall.position.set(along, 4, across + z); groups.world.add(wall); });
    const cap = new THREE.Mesh(new THREE.BoxGeometry(1, 8, 8), wallMat); cap.position.set(end, 4, across); groups.world.add(cap);
  } else {
    [-4.5, 4.5].forEach((x) => { const wall = new THREE.Mesh(new THREE.BoxGeometry(1, 8, 20), wallMat); wall.position.set(across + x, 4, along); groups.world.add(wall); });
    const cap = new THREE.Mesh(new THREE.BoxGeometry(8, 8, 1), wallMat); cap.position.set(across, 4, end); groups.world.add(cap);
  }
}

function clearGroup(group) {
  while (group.children.length) {
    const object = group.children[0];
    group.remove(object);
    object.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      const materials = Array.isArray(child.material) ? child.material : [child.material];
      materials.forEach((material) => { if (material && material !== sharedCoinMaterial) material.dispose(); });
    });
  }
}
const sharedCoinMaterial = new THREE.SpriteMaterial({ map: coinFrames[0], transparent: true, alphaTest: 0.08, depthWrite: false });
const spawnCatalog = {
  puppet: { name: 'Fantoche', texture: npcTextures[0], width: 2.1, height: 2.8 },
  smiley: { name: 'Sorriso', texture: smileyTexture, width: 2.5, height: 2.5 },
  robot: { name: 'Robô', texture: robotFrames[0], width: 2.35, height: 2.5 },
};
function spawnPosition() {
  const distance = 3.2;
  return new THREE.Vector3(
    THREE.MathUtils.clamp(player.x - Math.sin(player.yaw) * distance, -21, 21),
    0,
    THREE.MathUtils.clamp(player.z - Math.cos(player.yaw) * distance, -21, 21)
  );
}
function makeRagdoll() {
  const ragdoll = new THREE.Group();
  const cloth = new THREE.MeshLambertMaterial({ color: 0x394550 });
  const skin = new THREE.MeshLambertMaterial({ color: 0xb4b2a4 });
  const dark = new THREE.MeshLambertMaterial({ color: 0x22292c });
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.58, 0.82, 0.34), cloth);
  torso.position.y = 1.28; ragdoll.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.24, 8, 6), skin);
  head.position.y = 1.88; ragdoll.add(head);
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.16, 7), skin);
  neck.position.y = 1.77; ragdoll.add(neck);
  const limb = (x, y, length, material, width, angle) => {
    const pivot = new THREE.Group(); pivot.position.set(x, y, 0); pivot.rotation.z = angle;
    const segment = new THREE.Mesh(new THREE.CylinderGeometry(width * 0.72, width, length, 6), material);
    segment.position.y = -length / 2; pivot.add(segment); ragdoll.add(pivot); return pivot;
  };
  const limbs = [
    limb(-0.38, 1.58, 0.78, cloth, 0.13, -0.28), limb(0.38, 1.58, 0.78, cloth, 0.13, 0.28),
    limb(-0.19, 0.91, 0.78, dark, 0.15, 0.08), limb(0.19, 0.91, 0.78, dark, 0.15, -0.08)
  ];
  ragdoll.userData.limbs = limbs;
  ragdoll.userData.materials = [cloth, skin, dark];
  return ragdoll;
}
function spawnThing(type) {
  if (!gameActive) return;
  const position = spawnPosition();
  let thing, floorY = 0;
  if (type === 'car' || type === 'motorcycle') {
    thing = new THREE.Group();
    thing.userData.vehicle = type;
    thing.userData.vehicleSpeed = 0;
    thing.userData.vehicleYaw = player.yaw;
    thing.userData.tkGravity = false;
    const placeholder = new THREE.Mesh(new THREE.BoxGeometry(type === 'car' ? 2.1 : 0.8, 0.75, type === 'car' ? 3.6 : 2.5), new THREE.MeshLambertMaterial({ color: type === 'car' ? 0x8a2525 : 0x282c32 }));
    placeholder.position.y = 0.7; thing.add(placeholder);
    loadVehicleModel(thing, type);
  } else if (type === 'crate' || type === 'sphere') {
    thing = new THREE.Group();
    const material = new THREE.MeshLambertMaterial({ color: type === 'crate' ? 0x8a7651 : 0x71899a });
    const geometry = type === 'crate' ? new THREE.BoxGeometry(0.9, 0.9, 0.9) : new THREE.SphereGeometry(0.48, 10, 8);
    const mesh = new THREE.Mesh(geometry, material); mesh.position.y = 0.48; thing.add(mesh);
    thing.userData.spin = new THREE.Vector3(0, 0, 0);
  } else if (type === 'coin') {
    thing = new THREE.Group();
    const coin = new THREE.Sprite(sharedCoinMaterial); coin.scale.set(0.8, 1, 1); coin.position.y = 0.55; thing.add(coin);
  } else if (type === 'ragdoll') {
    thing = makeRagdoll();
  } else {
    const data = spawnCatalog[type];
    if (!data) return;
    thing = new THREE.Group();
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: data.texture, transparent: true, alphaTest: 0.06, depthWrite: false }));
    sprite.scale.set(data.width, data.height, 1); sprite.position.y = data.height / 2; thing.add(sprite);
    thing.userData.isEntity = true;
  }
  thing.position.copy(position);
  thing.rotation.y = player.yaw;
  thing.userData.spawned = true;
  thing.userData.collisionRadius = type === 'car' ? 1.65 : type === 'motorcycle' ? 0.9 : type === 'crate' ? 0.64 : type === 'sphere' ? 0.5 : type === 'coin' ? 0.43 : type === 'ragdoll' ? 0.52 : 0.68;
  thing.userData.collisionHeight = type === 'car' ? 1.8 : type === 'motorcycle' ? 1.5 : type === 'ragdoll' ? 1.95 : (spawnCatalog[type]?.height || 1);
  thing.userData.restitution = type === 'sphere' ? 0.52 : type === 'coin' ? 0.24 : 0.34;
  thing.userData.velocity = thing.userData.vehicle ? new THREE.Vector3() : new THREE.Vector3(-Math.sin(player.yaw) * 1.8, 1.6, -Math.cos(player.yaw) * 1.8);
  thing.userData.spin ||= new THREE.Vector3((Math.random() - 0.5) * 1.2, (Math.random() - 0.5) * 1.8, (Math.random() - 0.5) * 1.2);
  thing.userData.bounce = 0;
  groups.spawned.add(thing);
}
function loadVehicleModel(vehicle, type) {
  if (!vehicleState.loader && THREE.GLTFLoader) vehicleState.loader = new THREE.GLTFLoader();
  if (!vehicleState.loader) return;
  const path = type === 'car' ? 'Car.glb' : 'Motorcycle.glb';
  vehicleState.loader.load(path, (gltf) => {
    if (!vehicle.parent) return;
    const model = gltf.scene;
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const targetLength = type === 'car' ? 3.5 : 2.5;
    const scale = targetLength / Math.max(size.x, size.z, 0.001);
    model.scale.setScalar(scale);
    model.updateMatrixWorld(true);
    const scaledBox = new THREE.Box3().setFromObject(model);
    model.position.y -= scaledBox.min.y;
    model.rotation.y = Math.PI;
    vehicle.remove(vehicle.children[0]);
    vehicle.add(model);
    vehicle.userData.vehicleModel = model;
  }, undefined, (error) => console.warn('Não foi possível carregar o veículo:', error));
}
function enterVehicle(vehicle) {
  if (!vehicle || vehicleState.active) return;
  vehicleState.active = vehicle;
  vehicle.userData.vehicleSpeed = 0;
  player.yaw = vehicle.userData.vehicleYaw;
  vehicleState.engine.currentTime = 0;
  vehicleState.engine.play().catch(() => {});
  ui.itemHint.textContent = 'W/S dirigir · A/D virar · E sair';
  ui.itemHint.hidden = false;
}
function exitVehicle() {
  const vehicle = vehicleState.active;
  if (!vehicle) return;
  const direction = new THREE.Vector3(Math.cos(vehicle.rotation.y), 0, -Math.sin(vehicle.rotation.y));
  player.x = vehicle.position.x + direction.x * 2.2;
  player.z = vehicle.position.z + direction.z * 2.2;
  player.yaw = vehicle.rotation.y;
  vehicleState.active = null;
  vehicleState.engine.pause();
  ui.itemHint.hidden = true;
}
function tryEnterVehicle() {
  if (vehicleState.active) { exitVehicle(); return true; }
  let nearest = null, nearestDistance = 4.6;
  groups.spawned.children.forEach((thing) => {
    if (!thing.userData.vehicle) return;
    const distance = Math.hypot(thing.position.x - player.x, thing.position.z - player.z);
    if (distance < nearestDistance) { nearest = thing; nearestDistance = distance; }
  });
  if (nearest) { enterVehicle(nearest); return true; }
  return false;
}
function updateVehicleToggle() {
  const button = $('vehicle-toggle');
  const steeringButtons = document.querySelectorAll('.vehicle-steer');
  const driving = Boolean(vehicleState.active);
  $('move-controls').classList.toggle('driving', driving);
  steeringButtons.forEach((control) => { control.hidden = !driving; });
  if (driving) {
    button.hidden = false;
    button.textContent = 'SAIR DO VEÍCULO';
    return;
  }
  const nearby = groups.spawned.children.some((thing) => thing.userData.vehicle && Math.hypot(thing.position.x - player.x, thing.position.z - player.z) < 4.6);
  button.hidden = !nearby;
  button.textContent = 'ENTRAR NO VEÍCULO';
}
function updateVehicles(delta) {
  vehicleState.crashCooldown = Math.max(0, vehicleState.crashCooldown - delta);
  const bodies = groups.spawned.children;
  bodies.forEach((thing) => {
    if (!thing.userData.vehicle || thing.userData.tkFrozen || thing.userData.tkControlled) return;
    if (thing !== vehicleState.active) {
      const speed = thing.userData.vehicleSpeed || 0;
      thing.position.x += -Math.sin(thing.rotation.y) * speed * delta;
      thing.position.z += -Math.cos(thing.rotation.y) * speed * delta;
      thing.userData.vehicleSpeed *= Math.exp(-0.75 * delta);
    }
    if (thing.userData.tkGravity) {
      const velocity = thing.userData.velocity;
      thing.position.addScaledVector(velocity, delta);
      velocity.y -= 9.8 * delta;
      velocity.x *= Math.exp(-0.7 * delta);
      velocity.z *= Math.exp(-0.7 * delta);
      if (thing.position.y <= 0) {
        thing.position.y = 0;
        velocity.y = 0;
        if (velocity.lengthSq() < 0.04) {
          velocity.set(0, 0, 0);
          thing.userData.tkGravity = false;
        }
      }
    }
  });
  const vehicle = vehicleState.active;
  if (!vehicle) return;
  const steering = Number(keys.d) - Number(keys.a);
  const throttle = Number(keys.w) - Number(keys.s);
  let speed = vehicle.userData.vehicleSpeed || 0;
  speed += throttle * (vehicle.userData.vehicle === 'car' ? 8 : 6.5) * delta;
  speed = THREE.MathUtils.clamp(speed, -4.5, vehicle.userData.vehicle === 'car' ? 13 : 10);
  speed *= Math.exp(-(throttle ? 0.08 : 1.4) * delta);
  vehicle.userData.vehicleSpeed = speed;
  const maxSpeed = vehicle.userData.vehicle === 'car' ? 13 : 10;
  const pitchTarget = 0.68 + THREE.MathUtils.clamp(Math.abs(speed) / maxSpeed, 0, 1) * 0.95;
  vehicleState.engine.playbackRate += (pitchTarget - vehicleState.engine.playbackRate) * Math.min(1, delta * 4.5);
  vehicle.rotation.y += steering * THREE.MathUtils.clamp(Math.abs(speed) / 5, 0.18, 1.35) * (speed < 0 ? -1 : 1) * delta;
  const nextX = vehicle.position.x - Math.sin(vehicle.rotation.y) * speed * delta;
  const nextZ = vehicle.position.z - Math.cos(vehicle.rotation.y) * speed * delta;
  if (canMove(nextX, nextZ) && Math.abs(nextX) < 44 && Math.abs(nextZ) < 44) { vehicle.position.x = nextX; vehicle.position.z = nextZ; }
  else {
    playVehicleCrash(Math.abs(speed));
    vehicle.userData.vehicleSpeed *= -0.18;
  }
  player.x = vehicle.position.x; player.z = vehicle.position.z; player.yaw = vehicle.rotation.y;
}
function updateSpawned(delta, now) {
  const bodies = groups.spawned.children;
  updateVehicles(delta);
  bodies.forEach((thing) => {
    if (thing.userData.vehicle) return;
    const velocity = thing.userData.velocity;
    if (!velocity || thing.userData.tkFrozen || thing.userData.tkControlled) return;
    const radius = thing.userData.collisionRadius || 0.45;
    thing.position.addScaledVector(velocity, delta);
    velocity.y -= 9.8 * delta;
    velocity.x *= Math.exp(-0.28 * delta); velocity.z *= Math.exp(-0.28 * delta);
    const spin = thing.userData.spin;
    if (spin) { thing.rotation.x += spin.x * delta; thing.rotation.y += spin.y * delta; thing.rotation.z += spin.z * delta; spin.multiplyScalar(Math.exp(-0.7 * delta)); }
    if (thing.position.y < 0) {
      thing.position.y = 0;
      if (Math.abs(velocity.y) > 0.85) { velocity.y = Math.abs(velocity.y) * (thing.userData.restitution ?? 0.34); velocity.x *= 0.82; velocity.z *= 0.82; if (spin) { spin.x += velocity.z * 0.08; spin.z -= velocity.x * 0.08; } }
      else { velocity.y = 0; velocity.x *= Math.exp(-2.4 * delta); velocity.z *= Math.exp(-2.4 * delta); }
    }
    const limit = 23 - radius;
    if (thing.position.x < -limit || thing.position.x > limit) { thing.position.x = THREE.MathUtils.clamp(thing.position.x, -limit, limit); velocity.x *= -0.42; }
    if (thing.position.z < -limit || thing.position.z > limit) { thing.position.z = THREE.MathUtils.clamp(thing.position.z, -limit, limit); velocity.z *= -0.42; }
    if (thing.userData.limbs) thing.userData.limbs.forEach((limb, index) => { limb.rotation.z += Math.sin(now * 0.012 + index * 2) * delta * (velocity.lengthSq() > 0.8 ? 2.2 : 0.18); });
  });
  // Contatos aproximados entre corpos: sobreposição no plano e altura.
  for (let i = 0; i < bodies.length; i++) for (let j = i + 1; j < bodies.length; j++) {
    const a = bodies[i], b = bodies[j], ua = a.userData, ub = b.userData;
    if (ua.tkFrozen && ub.tkFrozen) continue;
    const ra = ua.collisionRadius || 0.45, rb = ub.collisionRadius || 0.45;
    if (a.position.y + (ua.collisionHeight || 1) < b.position.y || b.position.y + (ub.collisionHeight || 1) < a.position.y) continue;
    let dx = b.position.x - a.position.x, dz = b.position.z - a.position.z;
    let distance = Math.hypot(dx, dz), minDistance = ra + rb;
    if (distance >= minDistance) continue;
    if (ua.vehicle || ub.vehicle) {
      playVehicleCrash(Math.max(Math.abs(ua.vehicleSpeed || 0), Math.abs(ub.vehicleSpeed || 0)));
    }
    if (distance < 0.0001) { dx = 1; dz = 0; distance = 1; }
    const nx = dx / distance, nz = dz / distance, overlap = minDistance - distance;
    const movableA = !ua.tkFrozen && !ua.tkControlled, movableB = !ub.tkFrozen && !ub.tkControlled;
    const shareA = movableA && movableB ? 0.5 : movableA ? 1 : 0, shareB = movableA && movableB ? 0.5 : movableB ? 1 : 0;
    a.position.x -= nx * overlap * shareA; a.position.z -= nz * overlap * shareA;
    b.position.x += nx * overlap * shareB; b.position.z += nz * overlap * shareB;
    const va = ua.velocity || new THREE.Vector3(), vb = ub.velocity || new THREE.Vector3();
    const closing = (vb.x - va.x) * nx + (vb.z - va.z) * nz;
    if (closing < 0) {
      const restitution = Math.min(ua.restitution ?? 0.34, ub.restitution ?? 0.34);
      const inverseMass = (movableA ? 1 : 0) + (movableB ? 1 : 0) || 1;
      const impulse = -(1 + restitution) * closing / inverseMass;
      if (movableA) { va.x -= impulse * nx; va.z -= impulse * nz; }
      if (movableB) { vb.x += impulse * nx; vb.z += impulse * nz; }
    }
  }
}
function findTkTarget() {
  camera.updateMatrixWorld(true);
  hitRaycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  hitRaycaster.far = 24;
  const hits = hitRaycaster.intersectObjects([groups.world, groups.npcs, groups.spawned], true);
  const hit = hits.find((entry) => entry.distance <= 24);
  if (!hit) return null;
  const rootIn = (object, group) => {
    let root = object;
    while (root && root.parent !== group) root = root.parent;
    return root && root.parent === group ? root : null;
  };
  const root = rootIn(hit.object, groups.spawned) || rootIn(hit.object, groups.npcs);
  return root ? { root, point: hit.point.clone(), distance: hit.distance } : null;
}
function targetCenter(root) {
  const box = new THREE.Box3().setFromObject(root);
  if (!box.isEmpty()) return box.getCenter(new THREE.Vector3());
  return root.getWorldPosition(new THREE.Vector3()).add(new THREE.Vector3(0, 1, 0));
}
function setTkTarget(root) {
  if (telekinesis.outline && telekinesis.outline.userData.target !== root) {
    scene.remove(telekinesis.outline);
    telekinesis.outline.geometry.dispose(); telekinesis.outline.material.dispose();
    telekinesis.outline = null;
  }
  if (root && !telekinesis.outline) {
    telekinesis.outline = new THREE.BoxHelper(root, 0x58efff);
    telekinesis.outline.material.depthTest = false;
    telekinesis.outline.material.transparent = true;
    telekinesis.outline.material.opacity = 0.95;
    telekinesis.outline.userData.target = root;
    scene.add(telekinesis.outline);
  }
  if (telekinesis.outline) telekinesis.outline.update();
}
function updateTelekinesis(delta) {
  if (weaponMode !== 'telekinesis') {
    telekinesis.beam.visible = false;
    if (telekinesis.outline) telekinesis.outline.visible = false;
    return;
  }
  const hit = telekinesis.active ? findTkTarget() : null;
  telekinesis.target = hit?.root || null;
  const target = telekinesis.command && telekinesis.activeTarget ? telekinesis.activeTarget : telekinesis.target;
  ui.tkControls.hidden = !telekinesis.active || !target;
  ui.tkActivate.textContent = telekinesis.active ? '✕ CANCELAR TELECINESE' : '✧ USAR TELECINESE';
  if (telekinesis.outline) telekinesis.outline.visible = Boolean(telekinesis.active && target);
  const freezeButton = document.querySelector('[data-tk-action="freeze"]');
  freezeButton.classList.toggle('active', Boolean(telekinesis.target?.userData.tkFrozen));
  setTkTarget(target);
  if (!target || !telekinesis.active) { telekinesis.beam.visible = false; return; }
  const controlled = telekinesis.command === 'pull' || telekinesis.command === 'rotate';
  target.userData.tkControlled = controlled;
  const direction = camera.getWorldDirection(new THREE.Vector3()).normalize();
  const center = targetCenter(target);
  if (!target.userData.tkFrozen && telekinesis.command === 'pull') {
    const desiredCenter = camera.position.clone().addScaledVector(direction, 3.6);
    const rootPosition = target.getWorldPosition(new THREE.Vector3());
    const offset = center.sub(rootPosition);
    const desired = desiredCenter.sub(offset);
    desired.x = THREE.MathUtils.clamp(desired.x, -22, 22);
    desired.z = THREE.MathUtils.clamp(desired.z, -22, 22);
    desired.y = Math.max(0, desired.y);
    target.position.lerp(desired, Math.min(1, delta * 5.5));
    if (target.userData.velocity) target.userData.velocity.set(0, 0, 0);
    if (target.userData.spin) target.userData.spin.set(0, 0, 0);
  } else if (!target.userData.tkFrozen && telekinesis.command === 'push') {
    if (target.parent === groups.spawned && target.userData.velocity) {
      target.userData.velocity.addScaledVector(direction, delta * 18);
      if (target.userData.spin) { target.userData.spin.x += delta * 2.4; target.userData.spin.z += delta * 2.4; }
    } else target.position.addScaledVector(direction, delta * 6.5);
  } else if (!target.userData.tkFrozen && telekinesis.command === 'rotate') {
    if (target.userData.spin) { target.rotation.y += delta * 2.4; target.rotation.x += delta * 0.9; }
    else { target.rotation.y += delta * 1.8; }
    if (target.userData.velocity) target.userData.velocity.set(0, 0, 0);
  }
  const start = camera.localToWorld(new THREE.Vector3(0.37, -0.34, -0.72));
  const end = targetCenter(target);
  const position = telekinesis.beam.geometry.attributes.position;
  position.setXYZ(0, start.x, start.y, start.z); position.setXYZ(1, end.x, end.y, end.z);
  position.needsUpdate = true; telekinesis.beam.geometry.computeBoundingSphere(); telekinesis.beam.visible = true;
}
function updateWeaponUI() {
  if (telekinesis.hand) telekinesis.hand.visible = weaponMode === 'telekinesis';
  if (crowbarState.viewModel) crowbarState.viewModel.visible = weaponMode === 'crowbar' && crowbarState.held;
  if (pistolState.model) pistolState.model.visible = weaponMode === 'pistol';
  ui.tkActivate.hidden = weaponMode !== 'telekinesis';
  ui.tkControls.hidden = weaponMode !== 'telekinesis' || !telekinesis.active || !telekinesis.target;
  document.querySelectorAll('[data-weapon]').forEach((button) => button.classList.toggle('selected', button.dataset.weapon === weaponMode));
  if (weaponMode !== 'telekinesis') {
    telekinesis.beam.visible = false;
    if (telekinesis.outline) telekinesis.outline.visible = false;
  }
}
function equipWeapon(mode) {
  if (!['telekinesis', 'crowbar', 'pistol', 'camera'].includes(mode)) return;
  weaponMode = mode;
  if (mode === 'crowbar' && !crowbarState.held) {
    if (crowbarState.worldModel) groups.world.remove(crowbarState.worldModel);
    crowbarState.worldModel = null; crowbarState.held = true;
  }
  if (telekinesis.activeTarget) telekinesis.activeTarget.userData.tkControlled = false;
  telekinesis.command = null; telekinesis.activeTarget = null; telekinesis.active = false; telekinesis.target = null;
  updateWeaponUI();
}
function beginTkCommand(action, event) {
  if (weaponMode !== 'telekinesis' || !telekinesis.active) return;
  const target = telekinesis.target;
  if (!target) return;
  if (action === 'freeze') {
    target.userData.tkFrozen = !target.userData.tkFrozen;
    if (target.userData.vehicle && !target.userData.tkFrozen) target.userData.tkGravity = true;
    if (target.userData.tkFrozen) {
      if (target.userData.velocity) target.userData.velocity.set(0, 0, 0);
      if (target.userData.spin) target.userData.spin.set(0, 0, 0);
      target.userData.tkControlled = false;
    }
    document.querySelector('[data-tk-action="freeze"]').classList.toggle('active', target.userData.tkFrozen);
    return;
  }
  event.preventDefault();
  if (target.userData.vehicle) target.userData.tkGravity = true;
  telekinesis.command = action; telekinesis.activeTarget = target;
  target.userData.tkControlled = action === 'pull' || action === 'rotate';
}
function endTkCommand() {
  if (telekinesis.activeTarget) telekinesis.activeTarget.userData.tkControlled = false;
  telekinesis.command = null; telekinesis.activeTarget = null;
  document.querySelectorAll('[data-tk-action="pull"],[data-tk-action="push"],[data-tk-action="rotate"]').forEach((button) => button.classList.remove('active'));
}
function makeCrowbar(worldItem = false) {
  const bar = new THREE.Group();
  const material = new THREE.MeshBasicMaterial({ map: crowbarTexture, transparent: true, alphaTest: 0.04, side: THREE.DoubleSide, depthWrite: false });
  if (worldItem) {
    const image = new THREE.Mesh(new THREE.PlaneGeometry(0.78, 1.17), material);
    image.rotation.x = -Math.PI / 2;
    image.position.y = 0.025;
    bar.add(image);
  } else {
    const image = new THREE.Sprite(new THREE.SpriteMaterial({ map: crowbarTexture, transparent: true, alphaTest: 0.04, depthWrite: false }));
    image.scale.set(0.36, 0.55, 1);
    image.position.set(-0.07, -0.015, 0);
    image.rotation.z = 0.55;
    bar.add(image);
  }
  return bar;
}
function buildPistolModel() {
  const model = new THREE.Group();
  const gun = new THREE.Sprite(new THREE.SpriteMaterial({ map: pistolHandTexture, transparent: true, alphaTest: 0.035, depthWrite: false }));
  gun.scale.set(0.92, 0.92, 1);
  gun.position.set(0.05, -0.015, 0);
  model.add(gun);
  const flash = new THREE.Group();
  const flashMaterial = new THREE.MeshBasicMaterial({ color: 0xffd16a, transparent: true, opacity: 0.94, depthWrite: false });
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.105, 7, 5), flashMaterial);
  core.scale.set(0.85, 0.65, 0.4); flash.add(core);
  const streakA = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.025, 0.025), flashMaterial);
  const streakB = new THREE.Mesh(new THREE.BoxGeometry(0.025, 0.22, 0.025), flashMaterial);
  streakA.rotation.z = -0.4; streakB.rotation.z = -0.4; flash.add(streakA, streakB);
  flash.position.set(-0.14, 0.22, -0.04); flash.visible = false; model.add(flash);
  viewModel.add(model);
  pistolState.model = model; pistolState.muzzleFlash = flash;
  model.visible = false;
}
function buildHand() {
  telekinesis.hand = new THREE.Sprite(new THREE.SpriteMaterial({ map: playerHandTexture, transparent: true, alphaTest: 0.035, depthWrite: false }));
  telekinesis.hand.scale.set(0.55, 0.55, 1);
  telekinesis.hand.position.set(0.37, -0.34, -0.72);
  telekinesis.hand.rotation.z = -0.28;
  camera.add(telekinesis.hand);
  const heldImage = new THREE.Sprite(new THREE.SpriteMaterial({ map: heldCrowbarTexture, transparent: true, alphaTest: 0.04, depthWrite: false }));
  heldImage.scale.set(0.68, 0.79, 1);
  heldImage.position.set(0, 0, -0.055);
  heldImage.visible = false;
  viewModel.add(heldImage);
  crowbarState.handModel = heldImage;
  crowbarState.viewModel = heldImage;
  buildPistolModel();
}
function spawnCrowbar(x = 1.05, z = -1.25) {
  if (crowbarState.held) return;
  const bar = makeCrowbar(true);
  bar.position.set(x, 0, z);
  bar.rotation.y = -0.35;
  groups.world.add(bar);
  crowbarState.worldModel = bar;
}
function updateItemHint() {
  const mobile = matchMedia('(pointer: coarse)').matches || innerWidth <= 700;
  if (weaponMode === 'camera') {
    ui.itemHint.hidden = true; ui.grabButton.hidden = true; ui.hitButton.hidden = true; return;
  }
  if (weaponMode === 'telekinesis') {
    ui.itemHint.hidden = true; ui.grabButton.hidden = true; ui.hitButton.hidden = true; return;
  }
  if (weaponMode === 'pistol') {
    ui.itemHint.textContent = 'CLIQUE / ESPAÇO: ATIRAR';
    ui.itemHint.hidden = mobile; ui.grabButton.hidden = true;
    ui.hitButton.textContent = 'fire'; ui.hitButton.hidden = !mobile; return;
  }
  if (crowbarState.held) {
    ui.itemHint.textContent = 'CLIQUE / ESPAÇO: BATER  ·  G: LARGAR';
    ui.itemHint.hidden = mobile; ui.grabButton.textContent = 'drop';
    ui.grabButton.hidden = !mobile; ui.hitButton.textContent = 'hit'; ui.hitButton.hidden = !mobile; return;
  }
  const item = crowbarState.worldModel;
  const close = item && Math.hypot(item.position.x - player.x, item.position.z - player.z) < 2.35;
  ui.itemHint.textContent = close ? 'E: PEGAR CROWBAR' : '';
  ui.itemHint.hidden = !close || mobile; ui.grabButton.textContent = 'grab';
  ui.grabButton.hidden = !mobile || !close; ui.hitButton.hidden = true;
}
function pickUpCrowbar() {
  const item = crowbarState.worldModel;
  if (!item || Math.hypot(item.position.x - player.x, item.position.z - player.z) > 2.35) return;
  groups.world.remove(item);
  crowbarState.worldModel = null;
  crowbarState.held = true;
  crowbarState.handModel.visible = true;
  crowbarState.viewModel.visible = true;
  weaponMode = 'crowbar';
  updateWeaponUI();
}
function dropCrowbar() {
  if (!crowbarState.held) return;
  crowbarState.held = false;
  crowbarState.handModel.visible = false;
  crowbarState.viewModel.visible = false;
  spawnCrowbar(player.x - Math.sin(player.yaw) * 1.15, player.z - Math.cos(player.yaw) * 1.15);
  weaponMode = 'telekinesis';
  updateWeaponUI();
}
function spawnImpactParticles(hit) {
  const normal = hit.face
    ? hit.face.normal.clone().applyMatrix3(new THREE.Matrix3().getNormalMatrix(hit.object.matrixWorld)).normalize()
    : new THREE.Vector3(0, 1, 0);
  for (let i = 0; i < 11; i++) {
    const material = impactParticleMaterials[Math.floor(Math.random() * impactParticleMaterials.length)];
    const mesh = new THREE.Mesh(impactParticleGeometry, material);
    mesh.position.copy(hit.point).addScaledVector(normal, 0.035);
    const direction = normal.clone().multiplyScalar(0.65 + Math.random() * 0.8);
    direction.x += (Math.random() - 0.5) * 1.5;
    direction.y += Math.random() * 1.25;
    direction.z += (Math.random() - 0.5) * 1.5;
    direction.normalize().multiplyScalar(1.4 + Math.random() * 3.1);
    mesh.scale.setScalar(0.55 + Math.random() * 1.1);
    scene.add(mesh);
    activeImpactParticles.push({ mesh, velocity: direction, life: 0.24 + Math.random() * 0.28 });
  }
}
function addBulletHole(hit) {
  const object = hit.object;
  if (!object) return;
  object.updateMatrixWorld(true);
  const localPoint = object.worldToLocal(hit.point.clone());
  let localNormal;
  if (hit.face && hit.face.normal) localNormal = hit.face.normal.clone().normalize();
  else {
    const worldNormal = camera.getWorldDirection(new THREE.Vector3()).negate();
    localNormal = object.worldToLocal(hit.point.clone().addScaledVector(worldNormal, 0.1)).sub(localPoint).normalize();
  }
  const decal = new THREE.Mesh(bulletHoleGeometry, new THREE.MeshBasicMaterial({ map: bulletHoleTexture, transparent: true, alphaTest: 0.04, side: THREE.DoubleSide, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -1 }));
  decal.position.copy(localPoint).addScaledVector(localNormal, 0.012);
  decal.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), localNormal);
  decal.raycast = () => {};
  object.add(decal);
  bulletHoles.push(decal);
  if (bulletHoles.length > 110) {
    const oldest = bulletHoles.shift();
    oldest.parent?.remove(oldest); oldest.material.dispose();
  }
}
function spawnBulletTracer(start, end) {
  const geometry = new THREE.BufferGeometry().setFromPoints([start, end]);
  const material = new THREE.LineBasicMaterial({ color: 0xffd18b, transparent: true, opacity: 0.92, depthTest: true });
  const line = new THREE.Line(geometry, material); line.frustumCulled = false; scene.add(line);
  activeTracers.push({ line, life: 0.085, maxLife: 0.085 });
}
function firePistol() {
  if (!gameActive || weaponMode !== 'pistol' || pistolState.cooldown > 0) return;
  pistolState.cooldown = 0.23; pistolState.recoil = 1; pistolState.flashTimer = 0.07;
  if (pistolState.muzzleFlash) pistolState.muzzleFlash.visible = true;
  pistolAudio.currentTime = 0; pistolAudio.play().catch(() => {});
  camera.updateMatrixWorld(true);
  hitRaycaster.setFromCamera(new THREE.Vector2(0, 0), camera); hitRaycaster.far = 80;
  const hit = hitRaycaster.intersectObjects([groups.world, groups.npcs, groups.spawned], true).find((entry) => entry.distance <= 80);
  const direction = camera.getWorldDirection(new THREE.Vector3()).normalize();
  const muzzle = camera.localToWorld(new THREE.Vector3(0.24, -0.22, -0.9));
  const end = hit ? hit.point.clone() : muzzle.clone().addScaledVector(direction, 65);
  spawnBulletTracer(muzzle, end);
  if (!hit) return;
  addBulletHole(hit);
  spawnImpactParticles(hit);
  let root = hit.object;
  while (root && root.parent !== groups.spawned) root = root.parent;
  if (root && root.parent === groups.spawned && root.userData.velocity) {
    root.userData.velocity.addScaledVector(direction, 3.1);
    if (root.userData.spin) root.userData.spin.add(new THREE.Vector3((Math.random() - 0.5) * 2, 1.2, (Math.random() - 0.5) * 2));
  }
}
function resolveCrowbarHit() {
  camera.updateMatrixWorld(true);
  hitRaycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
  const hits = hitRaycaster.intersectObjects([groups.world, groups.npcs, groups.spawned], true);
  const hit = hits.find((item) => item.distance <= 3.2);
  if (!hit) return;
  impactAudio.currentTime = 0;
  impactAudio.play().catch(() => {});
  spawnImpactParticles(hit);
  const man = groups.npcs.children[5];
  let struckObject = hit.object;
  while (struckObject && struckObject !== man) struckObject = struckObject.parent;
  let spawnedRoot = hit.object;
  while (spawnedRoot && spawnedRoot.parent !== groups.spawned) spawnedRoot = spawnedRoot.parent;
  if (spawnedRoot && spawnedRoot.parent === groups.spawned) {
    const away = new THREE.Vector3(spawnedRoot.position.x - player.x, 0, spawnedRoot.position.z - player.z);
    if (away.lengthSq() < 0.01) away.set(-Math.sin(player.yaw), 0, -Math.cos(player.yaw));
    away.normalize();
    spawnedRoot.userData.velocity.set(away.x * 5.5, 4.8, away.z * 5.5);
    spawnedRoot.userData.spin.set(Math.random() * 5, Math.random() * 5, Math.random() * 5);
  }
  if (man && struckObject === man) {
    const away = new THREE.Vector3(man.position.x - player.x, 0, man.position.z - player.z);
    if (away.lengthSq() < 0.01) away.set(-Math.sin(player.yaw), 0, -Math.cos(player.yaw));
    away.normalize();
    man.userData.throwVelocity = new THREE.Vector3(away.x * 6.5, 6.2, away.z * 6.5);
    man.userData.throwTimer = 1.15;
    man.rotation.z = -0.45;
  }
}
function swingCrowbar() {
  if (!gameActive || weaponMode !== 'crowbar' || !crowbarState.held || crowbarState.cooldown > 0) return;
  crowbarState.swingTimer = 0.46;
  crowbarState.cooldown = 0.58;
  crowbarState.impactDelay = 0.12;
}

function buildWorld() {
  robotSprite = null; animatedRobotFrame = -1;
  clearGroup(groups.world); clearGroup(groups.npcs); clearGroup(groups.spawned);
  scene.background.setHex(0x071d2a);
  ceilingLight.color.setHex(0x9bcfff); ceilingLight.intensity = 1.15;
  const floorMat = new THREE.MeshLambertMaterial({ map: floorTexture, color: 0xffffff });
  const wallMat = new THREE.MeshLambertMaterial({ map: wallTexture, color: 0xffffff });
  const ceilingMat = new THREE.MeshLambertMaterial({ map: ceilingTexture, color: 0xb8bec1 });
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(50, 50), floorMat); floor.rotation.x = -Math.PI / 2; groups.world.add(floor);
  const roof = new THREE.Mesh(new THREE.PlaneGeometry(50, 50), ceilingMat); roof.position.y = 8; roof.rotation.x = Math.PI / 2; groups.world.add(roof);
  const horizontalWall = new THREE.BoxGeometry(21, 8, 1);
  [-14.5, 14.5].forEach((x) => [-25, 25].forEach((z) => {
    const wall = new THREE.Mesh(horizontalWall, wallMat); wall.position.set(x, 4, z); groups.world.add(wall);
  }));
  const westWall = new THREE.Mesh(new THREE.BoxGeometry(1, 8, 50), wallMat); westWall.position.set(-25, 4, 0); groups.world.add(westWall);
  const eastSegment = new THREE.BoxGeometry(1, 8, 21);
  [-14.5, 14.5].forEach((z) => { const wall = new THREE.Mesh(eastSegment, wallMat); wall.position.set(25, 4, z); groups.world.add(wall); });
  [-25, 25].forEach((z) => { const lintel = new THREE.Mesh(new THREE.BoxGeometry(8, 2, 1), wallMat); lintel.position.set(0, 7, z); groups.world.add(lintel); });
  const eastLintel = new THREE.Mesh(new THREE.BoxGeometry(1, 2, 8), wallMat); eastLintel.position.set(25, 7, 0); groups.world.add(eastLintel);

  addCorridor('z', -35, 0, -45, floorMat, wallMat);
  addCorridor('x', 35, 0, 45, floorMat, wallMat);
  addCorridor('z', 35, 0, 45, floorMat, wallMat);
  const loremSign = new THREE.Mesh(new THREE.PlaneGeometry(5.2, 3.2), new THREE.MeshBasicMaterial({ map: loremTexture }));
  loremSign.position.set(3.98, 4.2, -35); loremSign.rotation.y = -Math.PI / 2; groups.world.add(loremSign);

  npcData.forEach((data, index) => {
    const angle = index * Math.PI / 2, character = new THREE.Group(); character.position.set(Math.sin(angle) * 12, 0, -Math.cos(angle) * 12);
    const map = index === 0 ? npcTextures[0] : index === 1 ? robotFrames[0] : index === 2 ? smileyTexture : minesweeperTexture;
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map, transparent: true, alphaTest: 0.06, depthWrite: false }));
    if (index === 1) robotSprite = sprite;
    const height = index === 0 ? 2.8 : 2.5;
    sprite.scale.set(height * (index === 0 ? 0.75 : 1), height, 1); sprite.position.y = height / 2; character.add(sprite);
    if (index === 2) character.userData.target = new THREE.Vector2((Math.random() - 0.5) * 36, (Math.random() - 0.5) * 36);
    if (index === 3) character.userData.velocity = new THREE.Vector2(3.6, 2.8);
    groups.npcs.add(character);
  });

  const loremWatcher = new THREE.Group();
  loremWatcher.position.set(-2.2, 0, -35);
  const watcherRobe = new THREE.Mesh(new THREE.ConeGeometry(0.72, 1.7, 6), new THREE.MeshLambertMaterial({ color: 0x293642 }));
  watcherRobe.position.y = 0.88; loremWatcher.add(watcherRobe);
  const watcherHead = new THREE.Mesh(new THREE.SphereGeometry(0.43, 8, 6), new THREE.MeshLambertMaterial({ color: 0x9aa5a1 }));
  watcherHead.position.y = 1.95; loremWatcher.add(watcherHead);
  const watcherEyesMaterial = new THREE.MeshBasicMaterial({ color: 0xb9ffd8 });
  [-0.15, 0.15].forEach((offset) => {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 4), watcherEyesMaterial);
    eye.position.set(0.38, 2.03, offset); loremWatcher.add(eye);
  });
  groups.npcs.add(loremWatcher);

  const follower = new THREE.Group(); follower.position.set(0, 0, 3);
  const followerSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: manTexture, transparent: true, alphaTest: 0.06, depthWrite: false }));
  followerSprite.scale.set(2.4, 2.7, 1); followerSprite.position.y = 1.35; follower.add(followerSprite);
  groups.npcs.add(follower);

  player.x = 0; player.z = 0; player.yaw = 0; player.pitch = 0;
  crowbarState.worldModel = null;
  if (!crowbarState.held) spawnCrowbar();
}

function canMove(x, z) {
  const inRoom = Math.abs(x) <= 23.5 && Math.abs(z) <= 23.5;
  const northHall = Math.abs(x) <= 3.5 && z >= -44 && z < -23.5;
  const eastHall = Math.abs(z) <= 3.5 && x > 23.5 && x <= 44;
  const southHall = Math.abs(x) <= 3.5 && z > 23.5 && z <= 44;
  return inRoom || northHall || eastHall || southHall;
}
function update(delta, now) {
  updateSpawned(delta, now);
  const coinFrame = Math.floor(now / 100) % coinFrames.length;
  if (coinFrame !== animatedCoinFrame) { sharedCoinMaterial.map = coinFrames[coinFrame]; sharedCoinMaterial.needsUpdate = true; animatedCoinFrame = coinFrame; }
  const robotFrame = Math.floor(now / 120) % robotFrames.length;
  if (robotSprite && robotFrame !== animatedRobotFrame) { robotSprite.material.map = robotFrames[robotFrame]; robotSprite.material.needsUpdate = true; animatedRobotFrame = robotFrame; }
  const smiley = groups.npcs.children[2];
  if (smiley && !smiley.userData.tkFrozen && !smiley.userData.tkControlled) {
    const target = smiley.userData.target;
    const dx = target.x - smiley.position.x, dz = target.y - smiley.position.z, distance = Math.hypot(dx, dz);
    if (distance < 0.8) target.set((Math.random() - 0.5) * 40, (Math.random() - 0.5) * 40);
    else { smiley.position.x += dx / distance * 2.2 * delta; smiley.position.z += dz / distance * 2.2 * delta; }
  }
  const minesweeper = groups.npcs.children[3];
  if (minesweeper && !minesweeper.userData.tkFrozen && !minesweeper.userData.tkControlled) {
    const velocity = minesweeper.userData.velocity;
    minesweeper.position.x += velocity.x * delta; minesweeper.position.z += velocity.y * delta;
    if (Math.abs(minesweeper.position.x) > 21) velocity.x *= -1;
    if (Math.abs(minesweeper.position.z) > 21) velocity.y *= -1;
    minesweeper.position.x = THREE.MathUtils.clamp(minesweeper.position.x, -21, 21);
    minesweeper.position.z = THREE.MathUtils.clamp(minesweeper.position.z, -21, 21);
    minesweeper.position.y = Math.abs(Math.sin(now * 0.004)) * 1.2;
  }
  const follower = groups.npcs.children[5];
  if (follower && !follower.userData.tkFrozen && !follower.userData.tkControlled) {
    if (follower.userData.throwTimer > 0) {
      follower.userData.throwTimer = Math.max(0, follower.userData.throwTimer - delta);
      const velocity = follower.userData.throwVelocity;
      follower.position.x += velocity.x * delta;
      follower.position.z += velocity.z * delta;
      follower.position.y += velocity.y * delta;
      velocity.y -= 12 * delta;
      follower.position.x = THREE.MathUtils.clamp(follower.position.x, -23, 23);
      follower.position.z = THREE.MathUtils.clamp(follower.position.z, -23, 23);
      if (follower.position.y < 0) {
        follower.position.y = 0;
        velocity.y = Math.max(0, -velocity.y * 0.24);
        velocity.x *= 0.76; velocity.z *= 0.76;
      }
      follower.rotation.z = -0.45;
      if (follower.userData.throwTimer === 0) {
        follower.position.y = 0;
        follower.userData.throwVelocity = null;
        follower.rotation.z = 0;
      }
    } else {
      // Trail close to the player's shoulder while remaining inside the forward view.
      const sideOffset = 0.85, forwardOffset = 1.7;
      const targetX = player.x + Math.cos(player.yaw) * sideOffset - Math.sin(player.yaw) * forwardOffset;
      const targetZ = player.z - Math.sin(player.yaw) * sideOffset - Math.cos(player.yaw) * forwardOffset;
      const dx = targetX - follower.position.x, dz = targetZ - follower.position.z;
      const distance = Math.hypot(dx, dz), step = Math.min(distance, 4.8 * delta);
      if (distance > 0.04) {
        const nextX = follower.position.x + dx / distance * step;
        const nextZ = follower.position.z + dz / distance * step;
        if (canMove(nextX, nextZ)) { follower.position.x = nextX; follower.position.z = nextZ; }
        else if (canMove(nextX, follower.position.z)) follower.position.x = nextX;
        else if (canMove(follower.position.x, nextZ)) follower.position.z = nextZ;
      }
      follower.position.y = 0;
      follower.rotation.z = 0;
    }
  }
  if (crowbarState.cooldown > 0) crowbarState.cooldown = Math.max(0, crowbarState.cooldown - delta);
  if (crowbarState.impactDelay > 0) {
    crowbarState.impactDelay -= delta;
    if (crowbarState.impactDelay <= 0) resolveCrowbarHit();
  }
  if (crowbarState.swingTimer > 0) {
    crowbarState.swingTimer = Math.max(0, crowbarState.swingTimer - delta);
    const progress = 1 - crowbarState.swingTimer / 0.46;
    const smooth = (value) => value * value * (3 - 2 * value);
    if (progress < 0.24) {
      const windup = smooth(progress / 0.24);
      viewModel.rotation.set(0.18 * windup, 0, -0.32 * windup);
      viewModel.position.set(0.20 + 0.08 * windup, -0.15 + 0.06 * windup, -0.75);
    } else if (progress < 0.54) {
      const strike = smooth((progress - 0.24) / 0.30);
      viewModel.rotation.set(0.18 - 1.22 * strike, 0.22 * strike, -0.32 + 1.28 * strike);
      viewModel.position.set(0.28 - 0.24 * strike, -0.09 - 0.27 * strike, -0.75 + 0.08 * strike);
    } else {
      const recovery = 1 - smooth((progress - 0.54) / 0.46);
      viewModel.rotation.set(-1.04 * recovery, 0.22 * recovery, 0.96 * recovery);
      viewModel.position.set(0.20 - 0.16 * recovery, -0.15 - 0.21 * recovery, -0.67 + 0.08 * recovery);
    }
  } else {
    viewModel.rotation.set(0, 0, 0);
    viewModel.position.set(0.20, -0.15, -0.75);
  }
  pistolState.cooldown = Math.max(0, pistolState.cooldown - delta);
  pistolState.recoil = Math.max(0, pistolState.recoil - delta * 7.5);
  pistolState.flashTimer = Math.max(0, pistolState.flashTimer - delta);
  if (pistolState.muzzleFlash) pistolState.muzzleFlash.visible = weaponMode === 'pistol' && pistolState.flashTimer > 0;
  if (weaponMode === 'pistol') {
    const kick = pistolState.recoil;
    viewModel.rotation.set(-kick * 0.16, 0, kick * 0.035);
    viewModel.position.set(0.20, -0.15 + kick * 0.07 + Math.sin(now * 0.003) * 0.004, -0.75 + kick * 0.17);
  }
  for (let i = activeTracers.length - 1; i >= 0; i--) {
    const tracer = activeTracers[i]; tracer.life -= delta;
    tracer.line.material.opacity = Math.max(0, tracer.life / tracer.maxLife) * 0.92;
    if (tracer.life <= 0) {
      scene.remove(tracer.line); tracer.line.geometry.dispose(); tracer.line.material.dispose(); activeTracers.splice(i, 1);
    }
  }
  for (let i = activeImpactParticles.length - 1; i >= 0; i--) {
    const particle = activeImpactParticles[i];
    particle.life -= delta;
    particle.mesh.position.addScaledVector(particle.velocity, delta);
    particle.velocity.y -= 5.2 * delta;
    particle.mesh.rotation.x += delta * 8;
    particle.mesh.rotation.y += delta * 6;
    if (particle.life <= 0) {
      scene.remove(particle.mesh);
      activeImpactParticles.splice(i, 1);
    }
  }
  if (gameActive) {
    if (!vehicleState.active) {
      const forward = Number(keys.w) - Number(keys.s);
      const sideways = Number(keys.d) - Number(keys.a);
      const magnitude = Math.max(1, Math.hypot(forward, sideways)), speed = 6.2 * delta;
      const dx = ((-Math.sin(player.yaw) * forward + Math.cos(player.yaw) * sideways) / magnitude) * speed;
      const dz = ((-Math.cos(player.yaw) * forward - Math.sin(player.yaw) * sideways) / magnitude) * speed;
      if (canMove(player.x + dx, player.z)) player.x += dx; if (canMove(player.x, player.z + dz)) player.z += dz;
    }
    const watcher = groups.npcs.children[4];
    if (watcher) {
      const hitX = player.x - watcher.position.x, hitZ = player.z - watcher.position.z;
      const distance = Math.hypot(hitX, hitZ), collisionRadius = 1.3;
      if (distance < collisionRadius) {
        const normalX = distance ? hitX / distance : 1, normalZ = distance ? hitZ / distance : 0;
        const pushedX = THREE.MathUtils.clamp(watcher.position.x + normalX * collisionRadius, -23.5, 23.5);
        const pushedZ = THREE.MathUtils.clamp(watcher.position.z + normalZ * collisionRadius, -23.5, 23.5);
        if (canMove(pushedX, pushedZ)) { player.x = pushedX; player.z = pushedZ; }
        else if (canMove(pushedX, player.z)) player.x = pushedX;
        else if (canMove(player.x, pushedZ)) player.z = pushedZ;
      }
    }
    const minesweeper = groups.npcs.children[3];
    if (minesweeper) {
      const hitX = player.x - minesweeper.position.x, hitZ = player.z - minesweeper.position.z;
      const distance = Math.hypot(hitX, hitZ), collisionRadius = 1.65;
      if (distance < collisionRadius) {
        const normalX = distance ? hitX / distance : 1, normalZ = distance ? hitZ / distance : 0;
        player.x = THREE.MathUtils.clamp(minesweeper.position.x + normalX * collisionRadius, -23.5, 23.5);
        player.z = THREE.MathUtils.clamp(minesweeper.position.z + normalZ * collisionRadius, -23.5, 23.5);
        const velocity = minesweeper.userData.velocity;
        const impact = velocity.x * normalX + velocity.y * normalZ;
        if (impact > 0) { velocity.x -= 2 * impact * normalX; velocity.y -= 2 * impact * normalZ; }
      }
    }
    if (vehicleState.active) {
      const vehicle = vehicleState.active;
      camera.position.set(vehicle.position.x, vehicle.position.y + (vehicle.userData.vehicle === 'car' ? 1.45 : 1.1), vehicle.position.z);
      camera.rotation.order = 'YXZ'; camera.rotation.y = vehicle.rotation.y; camera.rotation.x = player.pitch;
    } else {
      camera.position.set(player.x, player.y, player.z); camera.rotation.order = 'YXZ'; camera.rotation.y = player.yaw; camera.rotation.x = player.pitch;
    }
  }
  updateTelekinesis(delta);
  updateVehicleToggle();
  updateItemHint();
  renderer.render(scene, camera);
}
function setKey(key, value) { const normalized = key.toLowerCase(); if (normalized in keys) keys[normalized] = value; }
function setSpawnMenu(open) {
  ui.spawnMenu.hidden = !open;
  ui.spawnToggle.setAttribute('aria-expanded', String(open));
  if (open) { Object.keys(keys).forEach((key) => { keys[key] = false; }); if (document.pointerLockElement) document.exitPointerLock?.(); }
}
ui.spawnToggle.addEventListener('click', () => setSpawnMenu(ui.spawnMenu.hidden));
ui.spawnClose.addEventListener('click', () => setSpawnMenu(false));
document.querySelectorAll('[data-menu-tab]').forEach((button) => button.addEventListener('click', () => {
  const selected = button.dataset.menuTab;
  $('spawn-content').hidden = selected !== 'spawn';
  $('vehicles-content').hidden = selected !== 'vehicles';
  $('weapons-content').hidden = selected !== 'weapons';
  document.querySelectorAll('[data-menu-tab]').forEach((tab) => tab.classList.toggle('active', tab === button));
}));
document.querySelectorAll('[data-weapon]').forEach((button) => button.addEventListener('click', () => { equipWeapon(button.dataset.weapon); setSpawnMenu(false); }));
ui.tkActivate.addEventListener('click', () => {
  telekinesis.active = !telekinesis.active;
  endTkCommand();
  telekinesis.target = null;
  updateWeaponUI();
});
document.querySelectorAll('[data-tk-action]').forEach((button) => {
  const action = button.dataset.tkAction;
  if (action === 'freeze') button.addEventListener('click', (event) => beginTkCommand(action, event));
  else {
    button.addEventListener('pointerdown', (event) => { event.preventDefault(); button.setPointerCapture(event.pointerId); button.classList.add('active'); beginTkCommand(action, event); });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((type) => button.addEventListener(type, endTkCommand));
  }
});
document.querySelectorAll('[data-spawn]').forEach((button) => button.addEventListener('click', () => {
  startAudio(); spawnThing(button.dataset.spawn); setSpawnMenu(false);
}));
$('vehicle-toggle').addEventListener('click', () => {
  startAudio();
  tryEnterVehicle();
  updateVehicleToggle();
});
window.addEventListener('keydown', (event) => {
  startAudio();
  const key = event.key.toLowerCase();
  if (!ui.spawnMenu.hidden) { if (key === 'escape') setSpawnMenu(false); return; }
  if (key in keys || ['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(key)) event.preventDefault();
  if (key === 'w' || key === 'arrowup') setKey('w', true); if (key === 's' || key === 'arrowdown') setKey('s', true);
  if (key === 'a' || key === 'arrowleft') setKey('a', true); if (key === 'd' || key === 'arrowright') setKey('d', true);
  if (!event.repeat) {
    if (key === 'e') { if (!tryEnterVehicle()) pickUpCrowbar(); }
    if (key === 'g' && weaponMode === 'crowbar') dropCrowbar();
    if (key === ' ') { if (weaponMode === 'pistol') firePistol(); else swingCrowbar(); }
  }
});
window.addEventListener('keyup', (event) => {
  const key = event.key.toLowerCase();
  if (key === 'w' || key === 'arrowup') setKey('w', false); if (key === 's' || key === 'arrowdown') setKey('s', false);
  if (key === 'a' || key === 'arrowleft') setKey('a', false); if (key === 'd' || key === 'arrowright') setKey('d', false);
});
window.addEventListener('blur', () => Object.keys(keys).forEach((key) => { keys[key] = false; }));
renderer.domElement.addEventListener('click', () => {
  startAudio();
  if (gameActive && matchMedia('(pointer:fine)').matches && document.pointerLockElement !== renderer.domElement) renderer.domElement.requestPointerLock?.();
  if (weaponMode === 'crowbar') swingCrowbar();
  else if (weaponMode === 'pistol') firePistol();
});
window.addEventListener('mousemove', (event) => {
  if (gameActive && document.pointerLockElement === renderer.domElement) { player.yaw -= event.movementX * 0.0025; player.pitch = THREE.MathUtils.clamp(player.pitch - event.movementY * 0.0025, -1.15, 1.15); }
});
renderer.domElement.addEventListener('pointerdown', (event) => {
  startAudio();
  if (event.pointerType === 'touch' && gameActive) { touchLook = { x: event.clientX, y: event.clientY }; renderer.domElement.setPointerCapture(event.pointerId); }
});
renderer.domElement.addEventListener('pointermove', (event) => {
  if (touchLook && event.pointerType === 'touch') { player.yaw -= (event.clientX - touchLook.x) * 0.008; player.pitch = THREE.MathUtils.clamp(player.pitch - (event.clientY - touchLook.y) * 0.008, -1.15, 1.15); touchLook = { x: event.clientX, y: event.clientY }; }
});
renderer.domElement.addEventListener('pointerup', () => { touchLook = null; });
ui.grabButton.addEventListener('click', () => {
  startAudio();
  if (crowbarState.held) dropCrowbar();
  else pickUpCrowbar();
});
ui.hitButton.addEventListener('click', () => {
  startAudio();
  if (weaponMode === 'pistol') firePistol(); else swingCrowbar();
});
document.querySelectorAll('[data-move]').forEach((button) => {
  const key = button.dataset.move;
  button.addEventListener('pointerdown', (event) => {
    event.preventDefault(); startAudio(); button.setPointerCapture(event.pointerId); setKey(key, true);
  });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((type) => button.addEventListener(type, () => setKey(key, false)));
});
window.addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); resizeRenderBuffer(); });
function startAudio() {
  if (audioCtx) return;
  audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  victoryJingle = new Audio('tada.wav');
}
buildHand();
buildWorld();
updateWeaponUI();
function frame(now) { requestAnimationFrame(frame); update(Math.min(clock.getDelta(), 0.05), now); }
requestAnimationFrame(frame);
