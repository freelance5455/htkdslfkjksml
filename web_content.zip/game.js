const canvas = document.getElementById("field");
const ctx = canvas.getContext("2d");

let playing = false;
let paused = false;
let animationId = null;
let matchDuration = 90;
let time = matchDuration;
let blueScore = 0;
let redScore = 0;
let speed = 3;
let graphics = "medium";
let vibration = true;
let soundEnabled = true;
let coins = Number(localStorage.getItem("fg_coins") || 500);
let unlockedSkins = JSON.parse(localStorage.getItem("fg_unlocked") || '["default"]');
let playerSkin = localStorage.getItem("fg_player_skin") || "default";
let botSkin = localStorage.getItem("fg_bot_skin") || "default";
const skinInfo = {
  default: { name: "Clássico", emoji: "⚽", shirt: "#1479ed", hair: "#30251e", price: 0 },
  neymar: { name: "Neymar Jr.", emoji: "🇧🇷", shirt: "#f2d52e", hair: "#b58a42", price: 250 },
  cr7: { name: "Cristiano Ronaldo", emoji: "⭐", shirt: "#e53935", hair: "#29221d", price: 250 }
};

const player = { x: 100, y: 150, r: 13 };
const enemy = { x: 280, y: 150, r: 13 };
const ball = { x: 190, y: 150, vx: 0, vy: 0, r: 7 };
const keys = {};

function resize() {
  const deviceRatio = window.devicePixelRatio || 1;
  const ratio = graphics === "low" ? 1 : graphics === "high" ? Math.min(deviceRatio, 2) : Math.min(deviceRatio, 1.5);
  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  canvas.width = Math.round(width * ratio);
  canvas.height = Math.round(height * ratio);
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
}
window.addEventListener("resize", resize);

function showOnly(id) {
  ["menu", "settings", "shop", "developer", "game"].forEach(screenId => {
    document.getElementById(screenId).classList.toggle("hidden", screenId !== id);
  });
}

function startGame() {
  clearInterval(window.clock);
  if (animationId) cancelAnimationFrame(animationId);

  showOnly("game");
  resize();
  playing = true;
  paused = false;
  time = matchDuration;
  blueScore = 0;
  redScore = 0;
  document.getElementById("timer").textContent = time;
  document.getElementById("pauseOverlay").classList.add("hidden");
  resetPositions();
  updateScore();

  window.clock = setInterval(() => {
    if (playing && !paused && time > 0) {
      time--;
      document.getElementById("timer").textContent = time;
      if (time === 0) finishGame();
    }
  }, 1000);

  loop();
}

function resetPositions() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  player.x = w * 0.25;
  player.y = h * 0.5;
  enemy.x = w * 0.75;
  enemy.y = h * 0.5;
  ball.x = w * 0.5;
  ball.y = h * 0.5;
  ball.vx = 0;
  ball.vy = 0;
}

function updateScore() {
  document.getElementById("score").textContent = `${blueScore} - ${redScore}`;
}

function drawField() {
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;

  for (let i = 0; i < 8; i++) {
    ctx.fillStyle = i % 2 === 0 ? "#16883b" : "#198f40";
    ctx.fillRect(i * w / 8, 0, w / 8 + 1, h);
  }

  ctx.strokeStyle = "white";
  ctx.lineWidth = 3;
  ctx.strokeRect(10, 10, w - 20, h - 20);

  ctx.beginPath();
  ctx.moveTo(w / 2, 10);
  ctx.lineTo(w / 2, h - 10);
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(w / 2, h / 2, 55, 0, Math.PI * 2);
  ctx.stroke();

  ctx.strokeRect(10, h * .3, 65, h * .4);
  ctx.strokeRect(w - 75, h * .3, 65, h * .4);

  ctx.fillStyle = "white";
  ctx.fillRect(0, h * .4, 12, h * .2);
  ctx.fillRect(w - 12, h * .4, 12, h * .2);
}

function drawPlayer(p, color, skinId) {
  const skin = skinInfo[skinId] || skinInfo.default;
  ctx.fillStyle = skinId === "default" ? color : skin.shirt;
  ctx.beginPath();
  ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "white";
  ctx.lineWidth = 2;
  ctx.stroke();

  // Cabeça e cabelo estilizados para diferenciar cada skin em campo.
  ctx.fillStyle = "#d9a477";
  ctx.beginPath(); ctx.arc(p.x, p.y - 3, 5, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = skin.hair;
  ctx.beginPath(); ctx.arc(p.x, p.y - 7, skinId === "neymar" ? 5.5 : 4.5, Math.PI, Math.PI * 2); ctx.fill();
  if (skinId === "neymar") { ctx.fillRect(p.x - 5, p.y - 8, 2, 4); ctx.fillRect(p.x + 3, p.y - 8, 2, 4); }
  if (skinId === "cr7") { ctx.fillRect(p.x - 4, p.y - 9, 8, 2); }
}

function keepPlayerInField(p) {
  p.x = Math.max(25, Math.min(canvas.clientWidth - 25, p.x));
  p.y = Math.max(25, Math.min(canvas.clientHeight - 25, p.y));
}

function movePlayer() {
  let velocity = speed;
  if (keys.run) velocity *= 1.6;

  if (keys.up) player.y -= velocity;
  if (keys.down) player.y += velocity;
  if (keys.left) player.x -= velocity;
  if (keys.right) player.x += velocity;
  keepPlayerInField(player);

  // Adversário segue a bola.
  const dx = ball.x - enemy.x;
  const dy = ball.y - enemy.y;
  const distance = Math.hypot(dx, dy);
  if (distance > 2) {
    enemy.x += dx / distance * 1.8;
    enemy.y += dy / distance * 1.8;
  }
  keepPlayerInField(enemy);
}

function collideBallWithPlayer(p) {
  const dx = ball.x - p.x;
  const dy = ball.y - p.y;
  const distance = Math.hypot(dx, dy);
  const minDistance = p.r + ball.r + 1;

  if (distance < minDistance) {
    const angle = distance === 0 ? 0 : Math.atan2(dy, dx);
    const nx = Math.cos(angle);
    const ny = Math.sin(angle);

    // Reposiciona a bola fora do jogador e aplica um pequeno impulso.
    ball.x = p.x + nx * minDistance;
    ball.y = p.y + ny * minDistance;
    ball.vx += nx * 0.8;
    ball.vy += ny * 0.8;
  }
}

function updateBall() {
  ball.x += ball.vx;
  ball.y += ball.vy;
  ball.vx *= 0.985;
  ball.vy *= 0.985;

  const h = canvas.clientHeight;
  const w = canvas.clientWidth;

  if (ball.y < ball.r + 10) {
    ball.y = ball.r + 10;
    ball.vy = Math.abs(ball.vy);
  } else if (ball.y > h - ball.r - 10) {
    ball.y = h - ball.r - 10;
    ball.vy = -Math.abs(ball.vy);
  }

  if (ball.x < 12 || ball.x > w - 12) {
    if (ball.y > h * .4 && ball.y < h * .6) {
      if (ball.x < 12) redScore++;
      else blueScore++;
      updateScore();
      resetPositions();
      return;
    } else {
      ball.x = ball.x < 12 ? 12 : w - 12;
      ball.vx *= -0.8;
    }
  }

  // Colisões nos dois lados, impedindo a bola de atravessar os jogadores.
  collideBallWithPlayer(player);
  collideBallWithPlayer(enemy);
}

function drawBall() {
  ctx.fillStyle = "white";
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#111";
  ctx.lineWidth = 1;
  ctx.stroke();
}

function playEffect(frequency = 440) {
  if (!soundEnabled) return;
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const audio = new AudioCtx();
    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.045, audio.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audio.currentTime + 0.12);
    oscillator.connect(gain); gain.connect(audio.destination);
    oscillator.start(); oscillator.stop(audio.currentTime + 0.12);
    oscillator.onended = () => audio.close();
  } catch (e) { /* áudio opcional */ }
}

function shoot() {
  const dx = ball.x - player.x;
  const dy = ball.y - player.y;
  const distance = Math.hypot(dx, dy);
  if (distance < 45) {
    ball.vx = 9;
    ball.vy = distance > 0 ? (dy / distance) * 5 : 0;
    playEffect(180);
  }
}

function pass() {
  const distance = Math.hypot(ball.x - player.x, ball.y - player.y);
  if (distance < 45) {
    ball.vx = 5;
    ball.vy = 0;
    playEffect(520);
  }
}

function loop() {
  if (!playing) return;

  if (!paused) {
    movePlayer();
    updateBall();
    drawField();
    drawPlayer(player, "#1479ed", playerSkin);
    drawPlayer(enemy, "#e53935", botSkin);
    drawBall();
  }
  animationId = requestAnimationFrame(loop);
}

function pauseGame() {
  if (!playing) return;
  paused = true;
  document.getElementById("pauseOverlay").classList.remove("hidden");
}

function resumeGame() {
  paused = false;
  document.getElementById("pauseOverlay").classList.add("hidden");
}

function returnToMenu() {
  playing = false;
  paused = false;
  clearInterval(window.clock);
  if (animationId) cancelAnimationFrame(animationId);
  document.getElementById("pauseOverlay").classList.add("hidden");
  showOnly("menu");
}

function finishGame() {
  playing = false;
  if (blueScore > redScore) {
    coins += 100;
    saveSkins();
    alert(`VOCÊ VENCEU! +100 moedas. Saldo: ${coins}`);
  }
  clearInterval(window.clock);
  if (animationId) cancelAnimationFrame(animationId);
  alert(`FIM DE JOGO! Placar: ${blueScore} - ${redScore}`);
  showOnly("menu");
}

function showSettings() {
  document.getElementById("speed").value = speed;
  document.getElementById("speedValue").textContent = speed;
  document.getElementById("graphics").value = graphics;
  document.getElementById("matchDuration").value = String(matchDuration);
  document.getElementById("vibration").checked = vibration;
  document.getElementById("sound").checked = soundEnabled;
  showOnly("settings");
}

function closeSettings() {
  graphics = document.getElementById("graphics").value;
  matchDuration = Number(document.getElementById("matchDuration").value);
  vibration = document.getElementById("vibration").checked;
  soundEnabled = document.getElementById("sound").checked;
  localStorage.setItem("fg_settings", JSON.stringify({ speed, graphics, matchDuration, vibration, soundEnabled }));
  resize();
  showOnly("menu");
}

function saveSkins() {
  localStorage.setItem("fg_coins", String(coins));
  localStorage.setItem("fg_unlocked", JSON.stringify(unlockedSkins));
  localStorage.setItem("fg_player_skin", playerSkin);
  localStorage.setItem("fg_bot_skin", botSkin);
}

function showShop() { renderShop(); showOnly("shop"); }
function closeShop() { showOnly("menu"); }
function renderShop() {
  document.getElementById("coinBalance").textContent = coins;
  renderSkinGroup("playerSkinCards", "player");
  renderSkinGroup("botSkinCards", "bot");
}
function renderSkinGroup(containerId, target) {
  const selected = target === "player" ? playerSkin : botSkin;
  const container = document.getElementById(containerId);
  container.innerHTML = Object.entries(skinInfo).map(([id, skin]) => {
    const unlocked = unlockedSkins.includes(id);
    const isSelected = selected === id;
    const action = isSelected ? "Equipado" : unlocked ? "Selecionar" : `🪙 ${skin.price} — Comprar`;
    return `<article class="skin-card"><div class="skin-avatar" style="background:${skin.shirt}"><span class="avatar-face ${id}"></span></div><strong>${skin.name}</strong><small>${id === "default" ? "Visual original" : "Skin especial inspirada no craque"}</small><button class="${isSelected ? "selected" : ""}" onclick="skinAction('${id}','${target}')">${action}</button></article>`;
  }).join("");
}
function skinAction(id, target) {
  const skin = skinInfo[id];
  if (!unlockedSkins.includes(id)) {
    if (coins < skin.price) { alert("Você não tem moedas suficientes!"); return; }
    coins -= skin.price;
    unlockedSkins.push(id);
  }
  if (target === "player") playerSkin = id; else botSkin = id;
  saveSkins(); renderShop();
}
function showDeveloper() { showOnly("developer"); }
function closeDeveloper() { showOnly("menu"); }

try {
  const saved = JSON.parse(localStorage.getItem("fg_settings") || "{}");
  if (saved.speed) speed = Number(saved.speed);
  if (saved.graphics) graphics = saved.graphics;
  if (saved.matchDuration) matchDuration = Number(saved.matchDuration);
  if (typeof saved.vibration === "boolean") vibration = saved.vibration;
  if (typeof saved.soundEnabled === "boolean") soundEnabled = saved.soundEnabled;
} catch (e) { /* mantém as configurações padrão */ }

document.getElementById("speed").addEventListener("input", event => {
  speed = Number(event.target.value);
  document.getElementById("speedValue").textContent = speed;
});

function bindButton(id, key) {
  const button = document.getElementById(id);
  button.addEventListener("pointerdown", event => {
    event.preventDefault();
    keys[key] = true;
    if (vibration && navigator.vibrate) navigator.vibrate(12);
    if (button.setPointerCapture) button.setPointerCapture(event.pointerId);
  });
  ["pointerup", "pointercancel", "lostpointercapture"].forEach(type => {
    button.addEventListener(type, () => { keys[key] = false; });
  });
}

bindButton("up", "up");
bindButton("down", "down");
bindButton("left", "left");
bindButton("right", "right");
bindButton("run", "run");

document.getElementById("shoot").addEventListener("pointerdown", shoot);
document.getElementById("pass").addEventListener("pointerdown", pass);

// Evita que os controles fiquem pressionados se o app perder o foco.
window.addEventListener("blur", () => {
  Object.keys(keys).forEach(key => keys[key] = false);
});

resize();
