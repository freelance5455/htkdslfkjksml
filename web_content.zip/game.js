'use strict';
/* WORLD COUNTRIES BATTLE - Infinite Auto-Battle Edition
   Single authoritative state object (S), one rAF loop, all timers are game-time counters
   decremented inside the loop, so pause/resume/restart can never leave stray timers behind. */
(function () {

/* =====================================================================
   1. DATA - 193 UN members + Holy See + State of Palestine = 195
   ===================================================================== */
const RAW = `AF Afghanistan
AL Albania
DZ Algeria
AD Andorra
AO Angola
AG Antigua and Barbuda
AR Argentina
AM Armenia
AU Australia
AT Austria
AZ Azerbaijan
BS Bahamas
BH Bahrain
BD Bangladesh
BB Barbados
BY Belarus
BE Belgium
BZ Belize
BJ Benin
BT Bhutan
BO Bolivia
BA Bosnia and Herzegovina
BW Botswana
BR Brazil
BN Brunei
BG Bulgaria
BF Burkina Faso
BI Burundi
CV Cabo Verde
KH Cambodia
CM Cameroon
CA Canada
CF Central African Republic
TD Chad
CL Chile
CN China
CO Colombia
KM Comoros
CG Congo
CD DR Congo
CR Costa Rica
CI Côte d'Ivoire
HR Croatia
CU Cuba
CY Cyprus
CZ Czechia
DK Denmark
DJ Djibouti
DM Dominica
DO Dominican Republic
EC Ecuador
EG Egypt
SV El Salvador
GQ Equatorial Guinea
ER Eritrea
EE Estonia
SZ Eswatini
ET Ethiopia
FJ Fiji
FI Finland
FR France
GA Gabon
GM Gambia
GE Georgia
DE Germany
GH Ghana
GR Greece
GD Grenada
GT Guatemala
GN Guinea
GW Guinea-Bissau
GY Guyana
HT Haiti
HN Honduras
HU Hungary
IS Iceland
IN India
ID Indonesia
IR Iran
IQ Iraq
IE Ireland
IL Israel
IT Italy
JM Jamaica
JP Japan
JO Jordan
KZ Kazakhstan
KE Kenya
KI Kiribati
KP North Korea
KR South Korea
KW Kuwait
KG Kyrgyzstan
LA Laos
LV Latvia
LB Lebanon
LS Lesotho
LR Liberia
LY Libya
LI Liechtenstein
LT Lithuania
LU Luxembourg
MG Madagascar
MW Malawi
MY Malaysia
MV Maldives
ML Mali
MT Malta
MH Marshall Islands
MR Mauritania
MU Mauritius
MX Mexico
FM Micronesia
MD Moldova
MC Monaco
MN Mongolia
ME Montenegro
MA Morocco
MZ Mozambique
MM Myanmar
NA Namibia
NR Nauru
NP Nepal
NL Netherlands
NZ New Zealand
NI Nicaragua
NE Niger
NG Nigeria
MK North Macedonia
NO Norway
OM Oman
PK Pakistan
PW Palau
PA Panama
PG Papua New Guinea
PY Paraguay
PE Peru
PH Philippines
PL Poland
PT Portugal
QA Qatar
RO Romania
RU Russia
RW Rwanda
KN Saint Kitts and Nevis
LC Saint Lucia
VC Saint Vincent and the Grenadines
WS Samoa
SM San Marino
ST São Tomé and Príncipe
SA Saudi Arabia
SN Senegal
RS Serbia
SC Seychelles
SL Sierra Leone
SG Singapore
SK Slovakia
SI Slovenia
SB Solomon Islands
SO Somalia
ZA South Africa
SS South Sudan
ES Spain
LK Sri Lanka
SD Sudan
SR Suriname
SE Sweden
CH Switzerland
SY Syria
TJ Tajikistan
TZ Tanzania
TH Thailand
TL Timor-Leste
TG Togo
TO Tonga
TT Trinidad and Tobago
TN Tunisia
TR Türkiye
TM Turkmenistan
TV Tuvalu
UG Uganda
UA Ukraine
AE United Arab Emirates
GB United Kingdom
US United States
UY Uruguay
UZ Uzbekistan
VU Vanuatu
VE Venezuela
VN Vietnam
YE Yemen
ZM Zambia
ZW Zimbabwe
VA Holy See
PS Palestine`;

const COUNTRIES = RAW.trim().split('\n').map(line => {
  const i = line.indexOf(' ');
  const code = line.slice(0, i).trim();
  const name = line.slice(i + 1).trim();
  return {
    id: code, code, name,
    emoji: String.fromCodePoint(...[...code].map(ch => 0x1F1E6 + ch.charCodeAt(0) - 65)),
    hue: (code.charCodeAt(0) * 37 + code.charCodeAt(1) * 91) % 360
  };
});
const BY_CODE = Object.fromEntries(COUNTRIES.map(c => [c.code, c]));

/* ---- regions (every country belongs to exactly one; validated at start-up) ---- */
const REGIONS = {
  africa: 'DZ AO BJ BW BF BI CV CM CF TD KM CG CD CI DJ EG GQ ER SZ ET GA GM GH GN GW KE LS LR LY MG MW ML MR MU MA MZ NA NE NG RW ST SN SC SL SO ZA SS SD TZ TG TN UG ZM ZW'.split(' '),
  europe: 'AL AD AT BY BE BA BG HR CY CZ DK EE FI FR DE GR HU IS IE IT LV LI LT LU MT MD MC ME NL MK NO PL PT RO RU SM RS SK SI ES SE CH UA GB VA'.split(' '),
  asia: 'AF AM AZ BH BD BT BN KH CN GE IN ID IR IQ IL JP JO KZ KW KG LA LB MY MV MN MM NP KP OM PK PS PH QA SA SG KR LK SY TJ TH TL TR TM AE UZ VN YE'.split(' '),
  americas: 'AG AR BS BB BZ BO BR CA CL CO CR CU DM DO EC SV GD GT GY HT HN JM MX NI PA PY PE KN LC VC SR TT US UY VE'.split(' '),
  oceania: 'AU FJ KI MH FM NR NZ PW PG WS SB TO TV VU'.split(' ')
};

/* ---- game modes: each one is just a different configuration of the same engine ---- */
const MODE_BASE = { portalMin: 10, portalMax: 15, opening: 1.6, active: 9, closing: 1.2, suck: 1.8, maxPerOpen: 1, speedMul: 1, pool: null };
const regionMode = (label, region, extra) => Object.assign({}, MODE_BASE, {
  label, group: 'Regions', pool: { region },
  portalMin: 5, portalMax: 8, opening: 1.0, active: 6, closing: 0.8, suck: 1.3,
  desc: 'Only the ' + REGIONS[region].length + ' countries of ' + label + ' fight. The next black hole opens 5-8 seconds after the last one closes.'
}, extra || {});
const MODES = {
  classic: Object.assign({}, MODE_BASE, { label: 'Classic', group: 'Game modes',
    desc: 'All 195 countries. A black hole opens every 10-15 seconds and eliminates one country each time.' }),
  blitz: Object.assign({}, MODE_BASE, { label: 'Blitz', group: 'Game modes', portalMin: 3, portalMax: 5, opening: 0.8, active: 4.5, closing: 0.6, suck: 1.1, speedMul: 1.25,
    desc: 'All 195 countries, faster flags. The next black hole opens just 3-5 seconds after the last one closes.' }),
  mega: Object.assign({}, MODE_BASE, { label: 'Mega Hole', group: 'Game modes', active: 12, maxPerOpen: 3,
    desc: 'All 195 countries. Each black hole can swallow up to 3 countries at once.' }),
  quick32: Object.assign({}, MODE_BASE, { label: 'Quick 32', group: 'Game modes', pool: { random: 32 }, portalMin: 4, portalMax: 7, opening: 1.0, active: 6, closing: 0.8, suck: 1.3,
    desc: '32 random countries, a fresh lineup every round. The next black hole opens 4-7 seconds after the last one closes.' }),
  asia: regionMode('Asia', 'asia'),
  europe: regionMode('Europe', 'europe'),
  africa: regionMode('Africa', 'africa'),
  americas: regionMode('Americas', 'americas'),
  oceania: regionMode('Oceania', 'oceania', { portalMin: 4, portalMax: 6 })
};
const modeSize = id => { const m = MODES[id]; return !m.pool ? COUNTRIES.length : m.pool.region ? REGIONS[m.pool.region].length : m.pool.random; };
function poolFor(id) {
  const m = MODES[id];
  if (!m.pool) return COUNTRIES.slice();
  if (m.pool.region) return REGIONS[m.pool.region].map(code => BY_CODE[code]);
  return shuffle(COUNTRIES.slice()).slice(0, m.pool.random);
}


function validateCountries() {
  const errs = [];
  if (COUNTRIES.length !== 195) errs.push('Expected 195 countries but found ' + COUNTRIES.length + '.');
  const ids = new Set(), names = new Set();
  for (const c of COUNTRIES) {
    if (!/^[A-Z]{2}$/.test(c.code)) errs.push('Invalid code: ' + c.code);
    if (ids.has(c.id)) errs.push('Duplicate ID: ' + c.id);
    if (names.has(c.name)) errs.push('Duplicate name: ' + c.name);
    ids.add(c.id); names.add(c.name);
  }
  const seen = {};                                        // every country must sit in exactly one region
  for (const r of Object.keys(REGIONS)) for (const code of REGIONS[r]) {
    if (!BY_CODE[code]) errs.push('Region ' + r + ' has unknown code ' + code + '.');
    else if (seen[code]) errs.push(code + ' appears in two regions.');
    seen[code] = r;
  }
  for (const c of COUNTRIES) if (!seen[c.code]) errs.push(c.name + ' is missing from the regions.');
  return errs;
}

/* =====================================================================
   2. QUESTION BANK (local, static, family-friendly)
   ===================================================================== */
const Q = (cat, text, ans, wrong, exp) => ({ cat, text, options: [ans, ...wrong], correct: 0, exp });
const QUESTIONS_RAW = [
  Q('Capitals', 'What is the capital of Australia?', 'Canberra', ['Sydney', 'Melbourne', 'Perth'], 'Canberra is the capital; Sydney and Melbourne are larger cities.'),
  Q('Capitals', 'What is the capital of Canada?', 'Ottawa', ['Toronto', 'Vancouver', 'Montreal'], 'Ottawa, in Ontario, is Canada\'s capital.'),
  Q('Capitals', 'What is the capital of Brazil?', 'Brasília', ['Rio de Janeiro', 'São Paulo', 'Salvador'], 'Brasília became the capital in 1960.'),
  Q('Capitals', 'What is the capital of Türkiye?', 'Ankara', ['Istanbul', 'Izmir', 'Antalya'], 'Ankara is the capital, though Istanbul is the largest city.'),
  Q('Capitals', 'What is the capital of Kenya?', 'Nairobi', ['Mombasa', 'Kampala', 'Dar es Salaam'], 'Nairobi is Kenya\'s capital and largest city.'),
  Q('Capitals', 'What is the capital of Switzerland?', 'Bern', ['Zurich', 'Geneva', 'Basel'], 'Bern is the federal city of Switzerland.'),
  Q('Capitals', 'What is the capital of Nigeria?', 'Abuja', ['Lagos', 'Kano', 'Accra'], 'Abuja replaced Lagos as the capital in 1991.'),
  Q('Capitals', 'What is the capital of New Zealand?', 'Wellington', ['Auckland', 'Christchurch', 'Hamilton'], 'Wellington is at the southern tip of the North Island.'),
  Q('Capitals', 'What is the capital of Vietnam?', 'Hanoi', ['Ho Chi Minh City', 'Da Nang', 'Hue'], 'Hanoi is the capital; Ho Chi Minh City is the largest city.'),
  Q('Capitals', 'What is the capital of Morocco?', 'Rabat', ['Casablanca', 'Marrakech', 'Fez'], 'Rabat is the capital; Casablanca is the largest city.'),
  Q('Continents', 'Which continent is Peru in?', 'South America', ['North America', 'Africa', 'Asia'], 'Peru is on the Pacific coast of South America.'),
  Q('Continents', 'Which continent contains the most countries?', 'Africa', ['Asia', 'Europe', 'South America'], 'Africa has 54 recognised countries.'),
  Q('Geography', 'Which is the largest ocean on Earth?', 'Pacific Ocean', ['Atlantic Ocean', 'Indian Ocean', 'Arctic Ocean'], 'The Pacific covers about a third of Earth\'s surface.'),
  Q('Geography', 'Which country is the largest by total area?', 'Russia', ['Canada', 'China', 'United States'], 'Russia spans more than 17 million square kilometres.'),
  Q('Geography', 'Which is the smallest country in the world by area?', 'Vatican City', ['Monaco', 'Nauru', 'San Marino'], 'Vatican City is only about 0.44 square kilometres.'),
  Q('Geography', 'Which is the largest hot desert in the world?', 'Sahara', ['Gobi', 'Kalahari', 'Arabian Desert'], 'The Sahara covers much of North Africa.'),
  Q('Geography', 'Which river flows through Cairo?', 'Nile', ['Congo', 'Niger', 'Zambezi'], 'Cairo sits on the banks of the Nile.'),
  Q('Geography', 'Mount Everest lies on the border of Nepal and which country?', 'China', ['India', 'Bhutan', 'Pakistan'], 'The border runs through the summit region, between Nepal and Tibet (China).'),
  Q('Geography', 'Which is the largest landlocked country in the world?', 'Kazakhstan', ['Mongolia', 'Chad', 'Ethiopia'], 'Kazakhstan has no ocean coastline and is the biggest such country.'),
  Q('Landmarks', 'In which country is the Taj Mahal?', 'India', ['Pakistan', 'Bangladesh', 'Iran'], 'The Taj Mahal is in Agra, India.'),
  Q('Landmarks', 'In which country is Machu Picchu?', 'Peru', ['Bolivia', 'Chile', 'Ecuador'], 'Machu Picchu is an Inca site in the Peruvian Andes.'),
  Q('Landmarks', 'In which country is the Colosseum?', 'Italy', ['Greece', 'Spain', 'France'], 'The Colosseum stands in Rome.'),
  Q('Landmarks', 'In which country is the Christ the Redeemer statue?', 'Brazil', ['Portugal', 'Argentina', 'Mexico'], 'It overlooks Rio de Janeiro.'),
  Q('Landmarks', 'In which country is the ancient city of Petra?', 'Jordan', ['Egypt', 'Lebanon', 'Saudi Arabia'], 'Petra is the famous rose-red rock city of Jordan.'),
  Q('Landmarks', 'In which country is Angkor Wat?', 'Cambodia', ['Thailand', 'Vietnam', 'Laos'], 'Angkor Wat is near Siem Reap, Cambodia.'),
  Q('Landmarks', 'In which country are the Great Pyramids of Giza?', 'Egypt', ['Sudan', 'Libya', 'Jordan'], 'The pyramids are near Cairo.'),
  Q('Flags', 'Which country\'s flag is this? {CA}', 'Canada', ['Austria', 'Peru', 'Switzerland'], 'The red maple leaf is Canada\'s symbol.'),
  Q('Flags', 'Which of these is the flag of Japan?', '{JP}', ['{BD}', '{PW}', '{LA}'], 'Japan\'s flag is a red disc on white.'),
  Q('Flags', 'Which country has the only national flag that is not a quadrilateral?', 'Nepal', ['Bhutan', 'Sri Lanka', 'Brunei'], 'Nepal\'s flag is two stacked pennants.'),
  Q('Flags', 'Which country\'s flag features a green cedar tree?', 'Lebanon', ['Cyprus', 'Syria', 'Jordan'], 'The cedar is a national emblem of Lebanon.'),
  Q('General', 'By the common model, how many continents are there?', '7', ['5', '6', '8'], 'Africa, Antarctica, Asia, Australia/Oceania, Europe, North America, South America.'),
  Q('General', 'Which planet is known as the Red Planet?', 'Mars', ['Venus', 'Jupiter', 'Mercury'], 'Iron oxide gives Mars its red colour.'),
  Q('General', 'What is the currency of Japan?', 'Yen', ['Won', 'Yuan', 'Rupee'], 'The Japanese yen is the national currency.'),
  Q('General', 'Which language has the most native speakers?', 'Mandarin Chinese', ['English', 'Spanish', 'Hindi'], 'Mandarin has the most native speakers worldwide.'),
  Q('General', 'Which country gave the Statue of Liberty to the United States?', 'France', ['United Kingdom', 'Spain', 'Italy'], 'It was a gift from France in 1886.'),
  Q('General', 'How many stripes are on the flag of the United States?', '13', ['10', '12', '15'], 'The 13 stripes represent the original colonies.'),
  Q('General', 'What is the chemical formula for water?', 'H₂O', ['CO₂', 'O₂', 'NaCl'], 'Two hydrogen atoms and one oxygen atom.'),
  Q('General', 'The shape of which country is often compared to a boot?', 'Italy', ['Greece', 'Portugal', 'Chile'], 'Italy\'s peninsula looks like a boot.')
];

function validateQuestions(list) {
  const ok = [];
  list.forEach((q, i) => {
    const opts = q.options || [];
    const problems = [];
    if (!q.text) problems.push('missing text');
    if (opts.length !== 4) problems.push('needs exactly 4 options');
    if (new Set(opts).size !== opts.length) problems.push('duplicate options');
    if (opts.some(o => !o)) problems.push('empty option');
    if (!(q.correct >= 0 && q.correct < opts.length)) problems.push('missing correct answer');
    if (problems.length) console.warn('Question #' + i + ' skipped: ' + problems.join(', '));
    else ok.push(q);
  });
  return ok;
}

/* =====================================================================
   3. HELPERS
   ===================================================================== */
const $ = s => document.querySelector(s);
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const ease = t => { t = clamp(t, 0, 1); return t * t * (3 - 2 * t); };
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function setText(el, v) { v = String(v); if (el._v !== v) { el._v = v; el.textContent = v; } }
const fmtTime = s => String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(Math.floor(s % 60)).padStart(2, '0');
const reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

function detectEmojiFlags() {
  try {
    const c = document.createElement('canvas'); c.width = 64; c.height = 40;
    const x = c.getContext('2d', { willReadFrequently: true });
    x.font = '32px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
    x.textBaseline = 'top'; x.fillStyle = '#000';
    x.fillText('\u{1F1EE}\u{1F1F3}', 0, 0);
    const d = x.getImageData(0, 0, 64, 40).data;
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] > 200 && Math.max(d[i], d[i + 1], d[i + 2]) - Math.min(d[i], d[i + 1], d[i + 2]) > 60) return true;
    }
  } catch (e) { console.warn('Emoji flag detection failed, using code fallback.', e); }
  return false;
}
const FLAGS_OK = detectEmojiFlags();
const EMOJI_FONT = '"Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';

const flagURL = (c, w) => 'https://flagcdn.com/w' + w + '/' + c.code.toLowerCase() + '.png';
function fallbackFlag(c) {
  return FLAGS_OK
    ? '<span class="fl" aria-hidden="true">' + c.emoji + '</span>'
    : '<span class="fl fb" style="--h:' + c.hue + '" aria-hidden="true">' + c.code + '</span>';
}
function flagHTML(c, big) {
  return '<img class="flimg' + (big ? ' big' : '') + '" src="' + flagURL(c, big ? 160 : 40) + '" alt="" data-c="' + c.code + '" onerror="window.__flagFb(this)">';
}
window.__flagFb = img => {                       // image blocked/offline -> emoji or country-code badge
  const c = BY_CODE[img.dataset.c]; if (!c) return;
  const t = document.createElement('span'); t.innerHTML = fallbackFlag(c); img.replaceWith(t.firstChild);
};
function plainText(html) {
  return html.replace(/<img[^>]*>/g, '').replace(/<span class="fl[^"]*"[^>]*>.*?<\/span>/g, '').replace(/<[^>]+>/g, '')
    .replace(/&mdash;/g, ',').replace(/&[a-z]+;/g, ' ').replace(/\s+/g, ' ').trim();
}
function richText(str) { return str.replace(/\{([A-Z]{2})\}/g, (m, code) => BY_CODE[code] ? flagHTML(BY_CODE[code]) : code); }

/* =====================================================================
   4. CONFIG + STATE
   ===================================================================== */
const CFG = {
  N: 195, FLAG_R: 0.04, BASE_SPEED: 0.32,
  PORTAL_MIN: 10, PORTAL_MAX: 15, OPENING: 1.6, ACTIVE: 9, CLOSING: 1.2,
  PORTAL_R: 0.17, CORE_R: 0.07, PULL_RANGE: 0.62,
  SUCK_TIME: 1.8, CELEBRATE: 5.5,
  Q_MIN: 25, Q_MAX: 50, Q_DEADLINE: 30, Q_CLOSE: 10,
  MAX_EVENTS: 50, MAX_PARTICLES: 360,
  SUB_FIRST: 12, SUB_MIN: 22, SUB_MAX: 38, SUB_SHOW: 10      // subscribe button: first after 12s, then every 22-38s, visible 8s
};
const SPEEDS = { slow: 0.55, normal: 1, fast: 1.8 };
const IS_MOBILE = !!(window.matchMedia && matchMedia('(pointer: coarse)').matches) || window.innerWidth < 700;
if (IS_MOBILE) CFG.MAX_PARTICLES = 180;               // lighter rendering on phones
const Q_FREQ = { rare: 1.6, normal: 1, frequent: 0.6 };

const S = {
  mode: 'ready',          // ready | running | paused | celebrating
  pausedFrom: null,
  roundId: 0, round: 1, completed: 0,
  speed: 1,
  modeId: 'classic', nextModeId: 'classic', N: 195,
  flags: [], elimCount: 0, clock: 0, ramp: 0,
  bh: { phase: 'idle', t: 0, nextIn: 12, x: 0, y: 0, size: 0, strength: 0, captured: false, caught: 0, target: null, rot: 0 },
  celebrateT: 0, winner: null,
  evCool: 4, bounceCool: 6, bannerT: 0, calloutT: 0, callIn: 20, callIdx: 0,
  milestones: new Set(),
  events: [],
  winners: [],
  particles: [],
  q: { open: false, answered: false, data: null, order: [], remaining: 0, closeIn: 0, roundId: 0, n: 0 },
  qNext: 30, qDeck: [], qCounter: 0,
  qr: { a: 0, c: 0 }, qs: { a: 0, c: 0 },
  opts: { sfx: true, music: true, voice: true, pauseOnQ: true, qFreq: 'normal', track: 'shuffle' },
  subIn: 12, subT: 0,
  bg: 'auto', bgAuto: true, bgIn: 60, bgShown: 'aurora', customUrl: null, liked: false
};

/* =====================================================================
   5. AUDIO (Web Audio synth, no external files)
   ===================================================================== */
const Audio = (() => {
  let ctx = null, master = null, sfxG = null, musG = null, musIn = null, dlNode = null, noiseBuf = null;
  let musicTimer = null, nextNote = 0, step = 0, musicOn = false;
  const last = {};

  function ensure() {
    try {
      if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return ctx; }
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
      master = ctx.createGain(); master.gain.value = 1.0;
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -8; comp.ratio.value = 6;
      master.connect(comp); comp.connect(ctx.destination);
      sfxG = ctx.createGain(); sfxG.gain.value = 2.2; sfxG.connect(master);
      musG = ctx.createGain(); musG.gain.value = 0; musG.connect(master);
      // music bus: soft low-pass, dotted echo and a warm reverb tail
      musIn = ctx.createGain();
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 5200; musIn.connect(lp); lp.connect(musG);
      const dl = dlNode = ctx.createDelay(1.5); dl.delayTime.value = 60 / TRACKS[trackId].bpm * 0.75;
      const fb = ctx.createGain(); fb.gain.value = 0.32; const dlp = ctx.createBiquadFilter(); dlp.type = 'lowpass'; dlp.frequency.value = 2400;
      const ds = ctx.createGain(); ds.gain.value = 0.35; lp.connect(ds); ds.connect(dl); dl.connect(dlp); dlp.connect(fb); fb.connect(dl); dlp.connect(musG);
      const irLen = Math.floor(ctx.sampleRate * 1.8), ir = ctx.createBuffer(2, irLen, ctx.sampleRate);
      for (let c = 0; c < 2; c++) { const ch = ir.getChannelData(c); for (let k = 0; k < irLen; k++) ch[k] = (Math.random() * 2 - 1) * Math.pow(1 - k / irLen, 2.6); }
      const conv = ctx.createConvolver(); conv.buffer = ir; const rs = ctx.createGain(); rs.gain.value = 0.4; const ro = ctx.createGain();
      lp.connect(rs); rs.connect(conv); conv.connect(ro); ro.gain.value = 0.55; ro.connect(musG);
      const len = ctx.sampleRate; noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = noiseBuf.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      return ctx;
    } catch (e) { console.warn('Audio unavailable:', e); ctx = null; return null; }
  }
  function tone(f, dur, o) {
    o = o || {};
    const dest = o.dest || sfxG;
    const t0 = ctx.currentTime + (o.delay || 0);
    const osc = ctx.createOscillator(), g = ctx.createGain();
    osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(f, t0);
    if (o.slide) osc.frequency.exponentialRampToValueAtTime(Math.max(20, o.slide), t0 + dur);
    const v = o.vol == null ? 0.2 : o.vol;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(v, t0 + (o.attack || 0.01));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g); g.connect(dest);
    osc.start(t0); osc.stop(t0 + dur + 0.05);
  }
  function noise(dur, vol, f0, f1, delay, dest) {
    const t0 = ctx.currentTime + (delay || 0);
    const src = ctx.createBufferSource(); src.buffer = noiseBuf;
    const flt = ctx.createBiquadFilter(); flt.type = 'bandpass'; flt.Q.value = 1.2;
    flt.frequency.setValueAtTime(f0, t0); flt.frequency.exponentialRampToValueAtTime(Math.max(40, f1), t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol, t0 + 0.04);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(flt); flt.connect(g); g.connect(dest || sfxG);
    src.start(t0); src.stop(t0 + dur + 0.05);
  }
  function play(name, minGap, fn) {
    if (!S.opts.sfx || !ensure()) return;
    const now = performance.now();
    if (last[name] && now - last[name] < minGap) return;
    last[name] = now;
    try { fn(); } catch (e) { console.warn('Sound "' + name + '" failed:', e); }
  }
  const SFX = {
    collide(v) { play('collide', 70, () => tone(rand(260, 380), 0.06, { type: 'triangle', vol: clamp(v * 0.25, 0.02, 0.07) })); },
    bounce() { play('bounce', 90, () => tone(rand(130, 170), 0.08, { type: 'sine', vol: 0.09 })); },
    portalOpen() { play('open', 300, () => { tone(70, 1.4, { type: 'sawtooth', slide: 320, vol: 0.12, attack: 0.3 }); noise(1.4, 0.07, 200, 1200); }); },
    suction() { play('suck', 300, () => { noise(0.9, 0.14, 1400, 120); tone(520, 0.9, { type: 'sine', slide: 50, vol: 0.12 }); }); },
    eliminate() { play('elim', 200, () => { tone(320, 0.4, { type: 'square', slide: 45, vol: 0.12 }); noise(0.3, 0.12, 2000, 300); }); },
    correct() { play('ok', 100, () => { tone(660, 0.14, { vol: 0.16 }); tone(880, 0.22, { vol: 0.16, delay: 0.12 }); }); },
    incorrect() { play('bad', 100, () => { tone(240, 0.3, { type: 'sawtooth', slide: 140, vol: 0.12 }); }); },
    winner() { play('win', 500, () => { [523, 659, 784, 1047, 1319].forEach((f, i) => tone(f, 0.45, { type: 'triangle', vol: 0.16, delay: i * 0.13 })); }); },
    newRound() { play('new', 300, () => { tone(440, 0.18, { type: 'triangle', vol: 0.14 }); tone(660, 0.3, { type: 'triangle', vol: 0.14, delay: 0.15 }); }); }
  };

  // five calm-to-energetic music styles, all generated live (no files). Every bar the melody is new, so it never gets boring.
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  const CT = { maj7: [0, 4, 7, 11], m7: [0, 3, 7, 10], '7': [0, 4, 7, 10], '6': [0, 4, 7, 9], maj: [0, 4, 7], m: [0, 3, 7] };
  const PC = [67, 69, 72, 74, 76, 79, 81, 84], PA = [69, 72, 74, 76, 79, 81, 84];
  const TRACKS = {
    happy:  { bpm: 108, drums: 'pop',  arp: 2, mel: 0.7,  melVol: 0.09, pad: 0.03, scale: [72, 74, 76, 79, 81, 84],
      progs: [[[0, 'maj'], [7, 'maj'], [9, 'm'], [5, 'maj']], [[5, 'maj'], [0, 'maj'], [7, 'maj'], [9, 'm']]] },
    lofi:   { bpm: 84,  drums: 'lofi', arp: 2, mel: 0.5,  melVol: 0.085, pad: 0.032, scale: PC,
      progs: [[[0, 'maj7'], [9, 'm7'], [5, 'maj7'], [7, '6']], [[2, 'm7'], [7, '7'], [0, 'maj7'], [9, 'm7']], [[5, 'maj7'], [4, 'm7'], [2, 'm7'], [7, '7']]] },
    dreamy: { bpm: 66,  drums: 'soft', arp: 4, mel: 0.6,  melVol: 0.09, pad: 0.045, scale: PC,
      progs: [[[5, 'maj7'], [0, 'maj7'], [7, '6'], [9, 'm7']], [[0, 'maj7'], [5, 'maj7'], [9, 'm7'], [7, '6']]] },
    epic:   { bpm: 104, drums: 'epic', arp: 2, mel: 0.6,  melVol: 0.08, pad: 0.04, scale: PA,
      progs: [[[9, 'm'], [5, 'maj'], [0, 'maj'], [7, 'maj']], [[9, 'm'], [7, 'maj'], [5, 'maj'], [4, 'maj']]] },
    ocean:  { bpm: 60,  drums: 'none', arp: 0, mel: 0.35, melVol: 0.08, pad: 0.055, scale: PC,
      progs: [[[0, 'maj7'], [7, '6'], [5, 'maj7'], [9, 'm7']]] }
  };
  const ARPI = [0, 2, 1, 3, 2, 1, 3, 2];
  let trackId = 'happy', mi = 3, phrase = [], progPick = 0, lite = false;
  function setTrack(id) {
    if (!TRACKS[id]) return;
    trackId = id; phrase = []; progPick = 0; mi = 3; step = 0;
    if (ctx) { nextNote = ctx.currentTime + 0.1; if (dlNode) dlNode.delayTime.setTargetAtTime(60 / TRACKS[id].bpm * 0.75, ctx.currentTime, 0.1); }
  }
  function scheduler() {
    if (!ctx || !musIn) return;
    const T = TRACKS[trackId], STEP = 60 / T.bpm / 4;
    while (nextNote < ctx.currentTime + 0.4) {
      const d = Math.max(0, nextNote - ctx.currentTime), i = step % 16, bar = Math.floor(step / 16), D = T.drums;
      if (i === 0 && bar % 4 === 0) progPick = (progPick + 1 + (Math.random() < 0.3 ? 1 : 0)) % T.progs.length;
      const [root, type] = T.progs[progPick][bar % 4], base = 60 + root;
      const tones = CT[type].map(o => { const m = base + o; return m > 67 ? m - 12 : m; });
      const sw = (D === 'lofi' && i % 4 === 2) ? STEP * 0.2 : 0;
      if (i === 0) tones.forEach(m => tone(mtof(m), STEP * 16 + 0.6, { type: 'triangle', vol: T.pad, dest: musIn, delay: d, attack: 0.9 }));
      const bs = D === 'epic' ? [0, 2, 4, 6, 8, 10, 12, 14] : D === 'none' ? [0] : D === 'soft' ? [0, 8] : D === 'pop' ? [0, 4, 8, 12] : [0, 6, 10];
      if (bs.indexOf(i) >= 0) {
        const bm = 36 + root, ep = D === 'epic';
        tone(mtof(bm), STEP * (ep ? 1.6 : 3.2), { type: ep ? 'triangle' : 'sine', vol: ep ? 0.2 : 0.28, dest: musIn, delay: d + sw, attack: 0.02 });
        if (!lite) tone(mtof(bm + 12), STEP * 2, { type: 'triangle', vol: 0.035, dest: musIn, delay: d + sw });
      }
      if (T.arp && !lite && i % T.arp === 0) {
        const m = tones[ARPI[(i / T.arp) % 8] % tones.length] + 12;
        tone(mtof(m), 0.55, { type: 'triangle', vol: 0.06, dest: musIn, delay: d + sw, attack: 0.006 });
      }
      if (i === 0) {
        phrase = [];
        if (bar % 8 < 6) [2, 4, 7, 10, 12, 14].forEach(pos => {
          if (Math.random() < T.mel) { mi = clamp(mi + [-2, -1, -1, 1, 1, 2][(Math.random() * 6) | 0], 0, T.scale.length - 1); phrase.push({ at: pos, m: T.scale[mi] }); }
        });
      }
      phrase.forEach(n => { if (n.at === i) {
        tone(mtof(n.m), 1.0, { type: 'sine', vol: T.melVol, dest: musIn, delay: d + sw, attack: 0.02 });
        if (!lite) tone(mtof(n.m) * 2, 0.5, { type: 'triangle', vol: 0.016, dest: musIn, delay: d + sw, attack: 0.02 });
      } });
      const kick = v => tone(125, 0.24, { type: 'sine', slide: 42, vol: v, dest: musIn, delay: d });
      if (D === 'lofi' && (i === 0 || i === 10)) kick(0.28);
      if (D === 'pop' && i % 4 === 0) kick(0.26);
      if (D === 'epic' && (i % 4 === 0 || i === 14)) kick(0.34);
      if (D === 'soft' && i === 0) kick(0.18);
      if ((D === 'lofi' || D === 'pop' || D === 'epic') && (i === 4 || i === 12)) {
        noise(0.18, D === 'epic' ? 0.1 : 0.065, 1900, 1200, d, musIn);
        tone(190, 0.1, { type: 'triangle', vol: 0.05, dest: musIn, delay: d });
      }
      if (!lite && ((D === 'pop' && i % 2 === 0) || (D === 'lofi' && i % 4 === 0))) noise(0.04, 0.018, 8500, 7500, d + sw, musIn);
      nextNote += STEP; step++;
    }
  }
  function setMusic(on) {
    musicOn = on;
    if (on) {
      if (!ensure()) return;
      musG.gain.cancelScheduledValues(ctx.currentTime);
      musG.gain.linearRampToValueAtTime(1.0, ctx.currentTime + 0.9);
      if (!musicTimer) { nextNote = ctx.currentTime + 0.05; musicTimer = setInterval(scheduler, 120); }
    } else {
      if (musicTimer) { clearInterval(musicTimer); musicTimer = null; }
      if (ctx && musG) { musG.gain.cancelScheduledValues(ctx.currentTime); musG.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.3); }
    }
  }
  function duck(on) {                                  // lower the music while the commentator speaks
    if (!ctx || !musG || !musicOn) return;
    musG.gain.cancelScheduledValues(ctx.currentTime);
    musG.gain.setTargetAtTime(on ? 0.3 : 1.0, ctx.currentTime, 0.2);
  }
  return { ensure, setMusic, duck, setTrack, setLite: v => { lite = !!v; }, current: () => trackId, trackIds: Object.keys(TRACKS), sfx: SFX };
})();

/* =====================================================================
   5b. VOICE (Web Speech API: reads events, questions, options and answers aloud)
   ===================================================================== */
const Voice = (() => {
  // One utterance at a time, in order: nothing overlaps, nothing is cut, nothing important is dropped.
  const syn = window.speechSynthesis;
  let voice = null, chosen = null, cur = null, gen = 0, hold = 0;
  const queue = [];
  const api = { onchange: null };
  function score(v) {                                             // prefer natural / neural / online voices
    if (!/^en/i.test(v.lang)) return -1;
    let sc = 0;
    if (/natural|neural|online/i.test(v.name)) sc += 50;
    if (/google/i.test(v.name)) sc += 30;
    if (/aria|jenny|neerja|prabhat|libby|sonia|samantha|karen|serena|zira|moira|tessa|female/i.test(v.name)) sc += 20;
    if (/en[-_]IN/i.test(v.lang)) sc += 10; else if (/en[-_]US/i.test(v.lang)) sc += 8; else if (/en[-_]GB/i.test(v.lang)) sc += 6;
    return sc;
  }
  function list() { return syn ? syn.getVoices().filter(v => score(v) >= 0).sort((a, b) => score(b) - score(a)) : []; }
  function pick() {
    if (!syn) return;
    const l = list();
    voice = (chosen && l.find(v => v.name === chosen)) || l[0] || null;
    if (api.onchange) api.onchange(l, voice);
  }
  if (syn) { pick(); syn.onvoiceschanged = pick; }
  function chunks(text) {                                         // sentences, long ones split at commas (long utterances can freeze some browsers)
    const out = [];
    (text.match(/[^.!?]+[.!?]*/g) || [text]).map(t => t.trim()).filter(Boolean).forEach(t => {
      while (t.length > 200) { let k = t.lastIndexOf(',', 200); if (k < 60) k = t.lastIndexOf(' ', 200); if (k < 60) k = 200; out.push(t.slice(0, k + 1).trim()); t = t.slice(k + 1).trim(); }
      if (t) out.push(t);
    });
    return out;
  }
  function pump() {
    if (cur || !syn) return;
    if (performance.now() < hold) { setTimeout(pump, hold - performance.now() + 20); return; }   // phones drop speech sent right after cancel()
    let it = null;
    while ((it = queue.shift())) { if (it.prio >= 2 || performance.now() - it.t < 12000) break; it = null; }   // stale chatter is skipped
    if (!it) { Audio.duck(false); return; }
    cur = it; const g = gen;
    const u = new SpeechSynthesisUtterance(it.text);
    if (voice && !it.plain) { u.voice = voice; u.lang = voice.lang; } else u.lang = 'en-US';
    u.rate = it.rate || 1.0; u.pitch = 1.03; u.volume = 1;
    let fin = false, started = false;
    const wd = setTimeout(() => { try { syn.cancel(); } catch (e) { /* ignore */ } done(); }, Math.max(4000, it.text.length * 115 / u.rate + 2500));   // never get stuck
    const st = setTimeout(() => {                                   // browser stayed silent: retry once with the plain default voice
      if (!started && !fin && !it.retried && !syn.speaking) { it.retried = true; it.plain = true; queue.unshift(it); try { syn.cancel(); } catch (e) { /* ignore */ } done(); }
    }, 3500);
    function done() { if (fin) return; fin = true; clearTimeout(wd); clearTimeout(st); if (g !== gen) return; cur = null; setTimeout(pump, 90); }
    u.onstart = () => { started = true; clearTimeout(st); Audio.duck(true); }; u.onend = done; u.onerror = done;
    try { if (syn.paused) syn.resume(); syn.speak(u); } catch (e) { console.warn('Speech failed:', e); done(); }
  }
  // prio 0 = filler (only when idle), 1 = normal, 2 = must be said (questions, answers, eliminations, winner)
  function speak(text, o) {
    if (!S.opts.voice || !syn || !text) return;
    o = o || {};
    const prio = o.prio != null ? o.prio : (o.force || o.interrupt ? 2 : 1);
    if (prio === 0 && (cur || queue.length)) return;
    if (o.interrupt) for (let i = queue.length - 1; i >= 0; i--) if (queue[i].prio < 2) queue.splice(i, 1);   // drop waiting small talk, never the sentence being spoken
    if (prio < 2 && queue.length >= 4) return;
    chunks(text).forEach(t => queue.push({ text: t, prio, t: performance.now(), rate: o.rate }));
    pump();
  }
  function stop() { gen++; queue.length = 0; cur = null; hold = performance.now() + 300; try { if (syn) syn.cancel(); } catch (e) { console.warn(e); } Audio.duck(false); }
  function dropLow() { for (let i = queue.length - 1; i >= 0; i--) if (queue[i].prio < 2) queue.splice(i, 1); }
  api.unlock = () => { try { if (syn) syn.getVoices(); } catch (e) { /* ignore */ } };     // NOTE: no silent 'priming' utterance, it blocks speech on Android
  api.speak = speak; api.stop = stop; api.dropLow = dropLow; api.refresh = pick; api.list = list;
  api.busy = () => !!S.opts.voice && !!syn && (!!cur || queue.length > 0);
  api.setVoice = name => { chosen = name; pick(); };
  return api;
})();

/* =====================================================================
   6. DOM REFERENCES
   ===================================================================== */
const el = {};
['gameStatus', 'roundPill', 'sfxInd', 'musicInd', 'errorBanner', 'stAlive', 'stElim', 'stRound', 'stCompleted', 'stNext', 'stPortal',
  'stQAns', 'stQCorrect', 'stQAcc', 'arenaBox', 'arena', 'arenaBadge', 'startOverlay', 'btnStartBig', 'pauseOverlay', 'winnerOverlay',
  'winFlag', 'winName', 'winRound', 'eventFeed', 'elimFeed', 'elimCount', 'winnersList', 'qIdle', 'qCard', 'qNum', 'qCat', 'qText',
  'qBar', 'qOptions', 'qFeedback', 'qContinue', 'qSession', 'btnStart', 'btnPause', 'btnRestart', 'optSfx', 'optMusic', 'optPauseQ',
  'optQFreq', 'optVoice', 'voiceSel', 'optMode', 'optModeStart', 'modeDesc', 'modePill', 'startDesc', 'qbPause', 'qbRestart', 'qbMute', 'qPanel', 'elimBanner', 'ebFlag', 'ebName', 'callout', 'bgButtons', 'bgCustomBtn', 'bgFile', 'bgPreview', 'bgMsg', 'rosterActive', 'rosterOut', 'activeCount', 'outCount',
  'announcer', 'bg', 'subBtn', 'likeBtn', 'shareBtn', 'ctaBox', 'voiceInd', 'btnVoiceTest', 'optTrack', 'arenaWrap', 'stageStrip'
].forEach(id => { el[id] = document.getElementById(id); });
const ctx2d = el.arena.getContext('2d');

/* =====================================================================
   7. SPRITES + CANVAS SIZING
   ===================================================================== */
const sprites = {};
function paintSprite(cv, c, img) {
  const SZ = 96, x = cv.getContext('2d');
  x.clearRect(0, 0, SZ, SZ);
  x.save(); x.beginPath(); x.arc(SZ / 2, SZ / 2, SZ / 2 - 3, 0, Math.PI * 2); x.clip();
  if (img) {
    const sc = SZ / img.naturalHeight, w = img.naturalWidth * sc;
    x.drawImage(img, (SZ - w) / 2, 0, w, SZ);                  // cover the circle with the real flag
  } else if (FLAGS_OK) {
    x.fillStyle = '#eef3fa'; x.fillRect(0, 0, SZ, SZ);
    x.font = '76px ' + EMOJI_FONT; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(c.emoji, SZ / 2, SZ / 2 + 4);
  } else {
    x.fillStyle = 'hsl(' + c.hue + ',55%,45%)'; x.fillRect(0, 0, SZ, SZ);
    x.fillStyle = '#fff'; x.font = '800 38px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(c.code, SZ / 2, SZ / 2 + 2);
  }
  x.restore();
  x.beginPath(); x.arc(SZ / 2, SZ / 2, SZ / 2 - 2.5, 0, Math.PI * 2);
  x.lineWidth = 4; x.strokeStyle = 'rgba(30,60,100,.55)'; x.stroke();
}
function spriteW() { return (IS_MOBILE && S.N >= 100) ? 80 : 160; }
function getSprite(c) { const k = c.code + '@' + spriteW(); return sprites[k] || (sprites[k] = makeSprite(c)); }
function makeSprite(c) {
  const cv = document.createElement('canvas'); cv.width = cv.height = 96;
  paintSprite(cv, c, null);                                    // instant fallback, replaced when the image arrives
  const img = new Image();
  img.onload = () => paintSprite(cv, c, img);
  img.onerror = () => console.warn('Flag image unavailable for ' + c.name + ', using fallback.');
  img.src = flagURL(c, spriteW());
  return cv;
}

let lowQ = false;
const view = { size: 300, cx: 150, R: 144, dpr: 1 };
function fitArena() {                                     // the whole circle must fit on screen, whatever the device
  const vh = window.innerHeight, vw = window.innerWidth;
  let max;
  if (matchMedia('(max-width:1000px) and (orientation:portrait)').matches) max = Math.min(vh * 0.44, vw - 24);
  else {
    const top = el.arenaWrap.getBoundingClientRect().top + window.scrollY;
    max = vh - top - (el.arenaWrap.offsetHeight - el.arenaBox.offsetHeight) - 14;
  }
  max = Math.max(200, Math.floor(max));
  if (Math.abs(max - (fitArena.last || 0)) < 3) return;       // ignore tiny changes: the circle must not jitter
  fitArena.last = max; document.documentElement.style.setProperty('--arena-max', max + 'px');
}
function revealQuestion() {                                // bring circle + question into view together, never over the circle
  const b = el.arenaBox.getBoundingClientRect(), q = el.qPanel.getBoundingClientRect(), vh = window.innerHeight;
  if (b.top >= 0 && b.bottom <= vh && q.top < vh - 120 && q.bottom > 0) return;
  window.scrollTo({ top: window.scrollY + el.arenaBadge.getBoundingClientRect().top - 8, behavior: reduceMotion ? 'auto' : 'smooth' });
}
function resizeCanvas() {
  const w = Math.max(200, Math.floor(el.arenaBox.getBoundingClientRect().width));
  const dpr = lowQ ? 1 : Math.min(IS_MOBILE ? 1.5 : 1.75, window.devicePixelRatio || 1);
  if (view.ready && w === view.size && dpr === view.dpr) return;
  view.ready = true; view.dpr = dpr;
  el.arena.width = Math.floor(w * dpr); el.arena.height = Math.floor(w * dpr);
  view.size = w; view.cx = w / 2; view.R = w / 2 - 8;
}

/* =====================================================================
   8. ROUND LIFECYCLE
   ===================================================================== */
function flagRadius(n) { return clamp(CFG.FLAG_R * Math.sqrt(195 / n) * 0.75, CFG.FLAG_R, 0.11); }   // fewer countries -> bigger flags
function layoutFlags() {
  const order = shuffle(poolFor(S.modeId));
  S.N = order.length;
  const N = S.N, fr = N >= 150 ? CFG.FLAG_R : flagRadius(N), golden = Math.PI * (3 - Math.sqrt(5)), maxR = 1 - fr * 1.6, spd = CFG.BASE_SPEED * MD().speedMul;
  CELL = Math.max(2 / (GRID_N - 2), fr * 2 + 0.002);      // grid cell must be at least one flag wide
  S.flags = order.map((c, i) => {
    const rr = maxR * Math.sqrt((i + 0.5) / N), a = i * golden, ang = Math.random() * Math.PI * 2, sp = spd * rand(0.8, 1.2);
    return { c, x: Math.cos(a) * rr, y: Math.sin(a) * rr, vx: Math.cos(ang) * sp, vy: Math.sin(ang) * sp, sp,
      r: fr, state: 'alive', scale: 1, alpha: 1, bounce: 0, suckT: 0, sx: 0, sy: 0, spin: 0, pulled: false };
  });
}
function resetPortal() {
  const M = MD();
  Object.assign(S.bh, { phase: 'idle', t: 0, size: 0, strength: 0, captured: false, caught: 0, target: null, nextIn: rand(M.portalMin, M.portalMax), warned: false });
}

function startRound(n) {
  Voice.dropLow();
  if (n > 1 && S.opts.track === 'shuffle') applyTrack();
  if (S.bgAuto) applyBg(nextAutoBg());
  S.bgIn = 60;
  S.roundId++;
  S.round = n;
  S.modeId = S.nextModeId;                          // a mode chosen mid-round takes effect here
  S.mode = 'running'; S.pausedFrom = null; S.winner = null;
  layoutFlags();
  S.elimCount = 0; S.clock = 0; S.ramp = 0; S.celebrateT = 0;
  S.evCool = rand(4, 8); S.bounceCool = rand(6, 10);
  S.bannerT = 0; S.calloutT = 0; S.callIn = rand(15, 25);
  el.elimBanner.hidden = true; el.callout.hidden = true;
  hideSub(); S.subIn = CFG.SUB_FIRST;
  S.milestones = new Set();
  S.particles = [];
  resetPortal();
  closeQuestion();
  S.qNext = nextQInterval();
  S.qr = { a: 0, c: 0 };
  el.winnerOverlay.hidden = true;
  el.startOverlay.hidden = true;
  el.elimFeed.innerHTML = '';
  buildRoster();
  addEvent('<b>Round ' + n + ' started</b> &mdash; ' + S.N + ' countries entered the arena (' + MD().label + ' mode).', 'key');
  Audio.sfx.newRound();
  announce('Round ' + n + ' started');
  syncModeUI(); updateUI(); updateStats();
}

function MD() { return MODES[S.modeId]; }
function aliveFlags() { return S.flags.filter(f => f.state === 'alive'); }

function declareWinner(f) {
  if (S.mode !== 'running') return;              // exactly once
  S.mode = 'celebrating';
  S.winner = f.c; S.completed++;
  S.celebrateT = CFG.CELEBRATE;
  S.bh.phase = 'idle'; S.bh.size = 0; S.bh.strength = 0;
  S.bannerT = 0; S.calloutT = 0; el.elimBanner.hidden = true; el.callout.hidden = true;
  closeQuestion();
  S.winners.unshift({ round: S.round, c: f.c, mode: MD().label });
  if (S.winners.length > 12) S.winners.pop();
  el.winFlag.innerHTML = flagHTML(f.c, true);
  el.winName.textContent = f.c.name;
  el.winRound.textContent = 'WINNER OF ROUND ' + S.round;
  el.winnerOverlay.hidden = false;
  addEvent(flagHTML(f.c) + ' <b>Winner of Round ' + S.round + ': ' + f.c.name + '!</b>', 'win');
  renderWinners();
  Audio.sfx.winner();
  announce('Winner of round ' + S.round + ': ' + f.c.name);
  updateUI(); updateStats();
}

/* =====================================================================
   9. PHYSICS
   ===================================================================== */
const GRID_N = 26;
let CELL = 2 / (GRID_N - 2);
const gridHead = new Int32Array(GRID_N * GRID_N), gridNext = new Int32Array(CFG.N + 8);

function physics(dt) {
  const sub = S.speed > 1.2 ? 2 : 1;
  const h = dt * S.speed * S.ramp / sub;
  const fl = S.flags;
  for (let s = 0; s < sub; s++) {
    for (let i = 0; i < fl.length; i++) {
      const f = fl[i];
      if (f.state !== 'alive') continue;
      f.x += f.vx * h; f.y += f.vy * h;
      // boundary
      const d = Math.hypot(f.x, f.y), lim = 1 - f.r;
      if (d > lim && d > 1e-9) {
        const nx = f.x / d, ny = f.y / d;
        f.x = nx * lim; f.y = ny * lim;
        const vn = f.vx * nx + f.vy * ny;
        if (vn > 0) {
          f.vx -= 2 * vn * nx; f.vy -= 2 * vn * ny;
          if (vn > 0.12) f.bounce = 1;
          if (vn > 0.08) Audio.sfx.bounce();
          if (S.bounceCool <= 0 && S.mode === 'running') {
            S.bounceCool = rand(8, 16);
            addEvent(flagHTML(f.c) + ' ' + f.c.name + ' bounced off the arena wall.', 'minor');
          }
        }
      }
    }
    // broad phase: uniform grid
    gridHead.fill(-1);
    for (let i = 0; i < fl.length; i++) {
      const f = fl[i]; if (f.state !== 'alive') continue;
      const gx = clamp(Math.floor((f.x + 1) / CELL) + 1, 0, GRID_N - 1), gy = clamp(Math.floor((f.y + 1) / CELL) + 1, 0, GRID_N - 1);
      f._g = gy * GRID_N + gx; gridNext[i] = gridHead[f._g]; gridHead[f._g] = i;
    }
    for (let i = 0; i < fl.length; i++) {
      const a = fl[i]; if (a.state !== 'alive') continue;
      const gx = a._g % GRID_N, gy = (a._g / GRID_N) | 0;
      for (let oy = -1; oy <= 1; oy++) for (let ox = -1; ox <= 1; ox++) {
        const cx = gx + ox, cy = gy + oy;
        if (cx < 0 || cy < 0 || cx >= GRID_N || cy >= GRID_N) continue;
        for (let j = gridHead[cy * GRID_N + cx]; j !== -1; j = gridNext[j]) {
          if (j <= i) continue;
          const b = fl[j];
          let dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy);
          const minD = a.r + b.r;
          if (dist >= minD) continue;
          if (dist < 1e-6) { const t = Math.random() * 6.283; dx = Math.cos(t); dy = Math.sin(t); dist = 1e-6; }
          const nx = dx / dist, ny = dy / dist, push = (minD - dist) / 2;
          a.x -= nx * push; a.y -= ny * push; b.x += nx * push; b.y += ny * push;
          const vn = (a.vx - b.vx) * nx + (a.vy - b.vy) * ny;
          if (vn > 0) {                                  // approaching (a moves toward b along +n)
            a.vx -= vn * nx; a.vy -= vn * ny; b.vx += vn * nx; b.vy += vn * ny;
            if (vn > 0.06) Audio.sfx.collide(vn);
            if (S.evCool <= 0 && S.mode === 'running' && vn > 0.1) {
              S.evCool = rand(6, 12);
              addEvent(flagHTML(a.c) + ' ' + a.c.name + ' collided with ' + flagHTML(b.c) + ' ' + b.c.name + '.', 'minor');
            }
          }
        }
      }
    }
    // keep energy bounded and prevent stalls
    for (let i = 0; i < fl.length; i++) {
      const f = fl[i]; if (f.state !== 'alive' || f.pulled) continue;
      const sp = Math.hypot(f.vx, f.vy), hi = f.sp * 1.4, lo = f.sp * 0.7;
      if (sp > hi) { f.vx *= hi / sp; f.vy *= hi / sp; }
      else if (sp < lo) {
        if (sp < 1e-6) { const t = Math.random() * 6.283; f.vx = Math.cos(t) * lo; f.vy = Math.sin(t) * lo; }
        else { f.vx *= lo / sp; f.vy *= lo / sp; }
      }
    }
  }
  for (const f of fl) { if (f.bounce > 0) f.bounce = Math.max(0, f.bounce - dt * 5); f.pulled = false; }
}

/* =====================================================================
   10. BLACK HOLE
   ===================================================================== */
function openPortal() {
  const b = S.bh, a = Math.random() * 6.283, r = Math.sqrt(Math.random()) * 0.5;
  b.phase = 'opening'; b.t = 0; b.size = 0; b.strength = 0; b.captured = false; b.caught = 0;   // elimination guard reset only here
  b.x = 0; b.y = 0; b.target = null;          // always in the centre of the arena
  addEvent('<b>Black Hole is opening!</b>', 'key', MD().maxPerOpen > 1 ? 'Black hole is opening! Up to three countries will be eliminated!' : 'Black hole is opening! One country will be eliminated!');
  Audio.sfx.portalOpen();
}

function portalUpdate(dt) {
  const b = S.bh, M = MD();
  b.rot += dt * 2.2;
  switch (b.phase) {
    case 'idle':
      b.nextIn -= dt;
      if (M.portalMin >= 8 && !b.warned && b.nextIn <= 5 && b.nextIn > 0) { b.warned = true; Voice.speak('Black hole opens in five seconds!'); }
      if (b.nextIn <= 0) openPortal();
      return;
    case 'opening':
      b.t += dt; b.size = ease(b.t / M.opening); b.strength = b.size * 0.7;
      if (b.t >= M.opening) { b.phase = 'active'; b.t = 0; }
      break;
    case 'active':
      b.t += dt; b.size = 1; b.strength = 1;
      if (b.t >= M.active) { b.phase = 'closing'; b.t = 0; }
      break;
    case 'closing':
      b.t += dt; b.size = 1 - ease(b.t / M.closing); b.strength = b.size;
      if (b.t >= M.closing) {
        b.phase = 'idle'; b.size = 0; b.strength = 0;
        b.nextIn = rand(M.portalMin, M.portalMax); b.warned = false;         // interval counted after the portal closes
        if (!b.caught) addEvent('The Black Hole closed without capturing a country.', 'minor');
        return;
      }
      break;
  }
  // visual swirl particles
  if (b.phase === 'active' && !reduceMotion && Math.random() < 0.6) {
    const a = Math.random() * 6.283, rad = rand(0.12, 0.26);
    spawnParticle({ x: b.x + Math.cos(a) * rad, y: b.y + Math.sin(a) * rad,
      vx: (-Math.cos(a)) * 0.22 + Math.sin(a) * 0.3, vy: (-Math.sin(a)) * 0.22 - Math.cos(a) * 0.3,
      life: 0.7, size: 2, color: '0,170,200' });
  }
  if (b.captured || b.strength <= 0) return;
  // gravitational pull: one chosen flag is drawn in strongly, the rest feel only a gentle tug (no crowd jamming)
  if (!b.target || b.target.state !== 'alive') {
    const al = S.flags.filter(f => f.state === 'alive');
    if (al.length <= 1) return;                              // never pull the last survivor
    const near = al.sort((p, q) => Math.hypot(p.x, p.y) - Math.hypot(q.x, q.y)).slice(0, 3);
    b.target = near[(Math.random() * near.length) | 0];
  }
  for (const f of S.flags) {
    if (f.state !== 'alive') continue;
    const dx = b.x - f.x, dy = b.y - f.y, d = Math.hypot(dx, dy), isT = f === b.target;
    if (d < 1e-6 || (d >= CFG.PULL_RANGE && !isT)) continue;
    f.pulled = true;
    const a = (isT ? 1.8 + 2.2 * (1 - clamp(d, 0, 1)) : clamp(0.035 / (d * d + 0.02), 0, 0.7)) * b.strength;
    f.vx += (dx / d) * a * dt; f.vy += (dy / d) * a * dt;
    if (isT) { const damp = 1 - clamp(1.8 * dt, 0, 0.5); f.vx *= damp; f.vy *= damp; }
    const sp = Math.hypot(f.vx, f.vy), cap = isT ? 1.1 : 0.8;
    if (sp > cap) { f.vx *= cap / sp; f.vy *= cap / sp; }
    if (!isFinite(f.vx) || !isFinite(f.vy)) { f.vx = 0; f.vy = 0; }
  }
  const t = b.target;
  if (t && Math.hypot(t.x - b.x, t.y - b.y) < CFG.CORE_R * Math.max(0.6, b.size)) captureFlag(t);
}

function captureFlag(f) {
  const b = S.bh;
  if (b.captured || f.state !== 'alive') return;      // limit per opening (1 in most modes, 3 in Mega Hole)
  if (aliveFlags().length <= 1) return;                // never swallow the last survivor
  b.caught++;
  if (b.caught >= MD().maxPerOpen) b.captured = true;  // elimination guard: no further captures this opening
  b.target = null;
  f.state = 'sucked'; f.suckT = 0; f.sx = f.x; f.sy = f.y; f.cx = b.x; f.cy = b.y;
  addEvent(flagHTML(f.c) + ' <b>' + f.c.name + '</b> is being pulled into the portal!', 'bad');
  Audio.sfx.suction();
}

function suckUpdate(dt) {
  for (const f of S.flags) {
    if (f.state !== 'sucked') continue;
    f.suckT += dt / MD().suck;
    const p = ease(f.suckT);
    // spiral toward the stored portal centre
    const ox = f.sx - f.cx, oy = f.sy - f.cy, ang = p * 3.2, cs = Math.cos(ang), sn = Math.sin(ang), k = 1 - p;
    f.x = f.cx + (ox * cs - oy * sn) * k; f.y = f.cy + (ox * sn + oy * cs) * k;
    f.scale = Math.max(0, 1 - p) * (1 + 0.6 * Math.sin(Math.min(1, p * 3) * Math.PI));
    f.alpha = Math.max(0, 1 - p * 0.9); f.rot = p * Math.PI * 5;
    if (!reduceMotion && Math.random() < 0.7) spawnParticle({ x: f.x, y: f.y, vx: 0, vy: 0, life: 0.5, size: 3, color: '225,29,72' });
    if (f.suckT >= 1) { finalizeElimination(f); if (S.mode !== 'running') return; }
  }
}

function finalizeElimination(f) {
  f.state = 'out'; f.alpha = 0; f.scale = 0;
  S.elimCount++;
  const n = S.elimCount, alive = S.N - n;
  for (let i = 0; i < 18; i++) {
    const a = Math.random() * 6.283, v = rand(0.15, 0.55);
    spawnParticle({ x: f.cx, y: f.cy, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: rand(0.4, 0.9), size: rand(1.5, 3), color: '0,170,200' });
  }
  markEliminated(f.c);
  addElimEntry(n, f.c);
  addEvent(flagHTML(f.c) + ' <b>' + f.c.name + '</b> has been eliminated.', 'bad', false);
  hideSub(); S.calloutT = 0; el.callout.hidden = true; S.bannerT = 4.5; el.ebFlag.innerHTML = flagHTML(f.c, true); el.ebName.textContent = f.c.name; el.elimBanner.hidden = false;
  Voice.speak(f.c.name + ' has been eliminated. ' + alive + (alive === 1 ? ' country remains.' : ' countries remain.'), { force: true });
  Audio.sfx.eliminate();
  for (const m of [100, 50, 25, 10, 5, 2]) {
    if (alive === m && !S.milestones.has(m)) { S.milestones.add(m); addEvent('<b>' + m + ' countries remain!</b>', 'key'); }
  }
  updateStats();
  if (alive === 1) declareWinner(aliveFlags()[0]);
}

/* =====================================================================
   11. PARTICLES
   ===================================================================== */
function spawnParticle(p) {
  if (S.particles.length >= CFG.MAX_PARTICLES) return;
  p.max = p.life; S.particles.push(p);
}
function updateParticles(dt) {
  const ps = S.particles;
  for (let i = ps.length - 1; i >= 0; i--) {
    const p = ps[i];
    p.life -= dt;
    if (p.life <= 0) { ps[i] = ps[ps.length - 1]; ps.pop(); continue; }
    p.x += p.vx * dt; p.y += p.vy * dt;
    if (p.g) p.vy += p.g * dt;
  }
}
function confetti(dt) {
  if (reduceMotion) return;
  const n = Math.min(4, Math.ceil(dt * 160));
  const colors = ['0,170,200', '0,124,240', '255,209,102', '255,77,109', '150,90,255'];
  for (let i = 0; i < n; i++) {
    spawnParticle({ x: rand(-1, 1), y: -1.05, vx: rand(-0.15, 0.15), vy: rand(0.2, 0.6), g: 0.5, life: rand(1.8, 3), size: rand(2, 4), color: colors[(Math.random() * colors.length) | 0] });
  }
}

/* =====================================================================
   12. QUESTIONS
   ===================================================================== */
const QUESTIONS = validateQuestions(QUESTIONS_RAW);
function nextQInterval() { const m = Q_FREQ[S.opts.qFreq] || 1; return rand(CFG.Q_MIN, CFG.Q_MAX) * m; }

function plainSpeech(str) { return str.replace(/\{[A-Z]{2}\}/g, '').replace(/\s+/g, ' ').trim(); }
function speechOpt(raw) {                                  // flag-only options are read by country name; text options as written
  const m = raw.match(/^\{([A-Z]{2})\}$/);
  return m && BY_CODE[m[1]] ? BY_CODE[m[1]].name : plainSpeech(raw);
}

// community poll: "where are you from", "which country do you support", "did you subscribe" (no right/wrong answer)
function pickMeta() {
  const kind = ['from', 'support', 'subscribe'][(Math.random() * 3) | 0];
  if (kind === 'subscribe') {
    return { type: 'poll', kind, cat: 'Community', text: 'Have you subscribed to our YouTube channel?',
      options: ['Yes, I already subscribed', 'Not yet, subscribing right now', 'I will subscribe soon'] };
  }
  const picks = shuffle(COUNTRIES.slice()).slice(0, 5);
  return { type: 'poll', kind, cat: 'Community', text: kind === 'from' ? 'Where are you from?' : 'Which country do you support?',
    options: [...picks.map(c => '{' + c.code + '} ' + c.name), 'Another country'], countries: [...picks, null] };
}

function openQuestion() {
  if (S.mode !== 'running' || S.q.open) return;
  if (S.metaIn == null) S.metaIn = 1 + ((Math.random() * 3) | 0);     // a community poll after every 1-3 quiz questions
  let data;
  if (S.metaIn <= 0 || !QUESTIONS.length) { data = pickMeta(); S.metaIn = 1 + ((Math.random() * 3) | 0); }
  else {
    if (!S.qDeck.length) S.qDeck = shuffle(QUESTIONS.map((_, i) => i));
    data = QUESTIONS[S.qDeck.pop()]; S.metaIn--;
  }
  const q = S.q, poll = data.type === 'poll';
  q.open = true; q.answered = false; q.data = data; q.roundId = S.roundId; q.n = ++S.qCounter;
  q.order = poll ? data.options.map((_, i) => i) : shuffle(data.options.map((_, i) => i));
  q.remaining = CFG.Q_DEADLINE; q.closeIn = CFG.Q_CLOSE; q.readWait = 0; q.closeWait = 0;
  el.qNum.textContent = '#' + q.n;
  el.qCat.textContent = data.cat;
  el.qText.innerHTML = richText(data.text);
  el.qOptions.innerHTML = '';
  q.order.forEach((orig, pos) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'q-opt'; b.dataset.pos = pos;
    b.innerHTML = '<span>' + (pos + 1) + '. ' + richText(data.options[orig]) + '</span>';
    b.addEventListener('click', () => answerQuestion(pos));
    el.qOptions.appendChild(b);
  });
  el.qFeedback.textContent = ''; el.qContinue.hidden = true; el.qBar.style.transform = 'scaleX(1)';
  el.qIdle.hidden = true; el.qCard.hidden = false; el.qPanel.classList.add('open');
  addEvent('<b>' + (poll ? 'Community question' : 'Random Challenge') + ' #' + q.n + ' is live!</b>', 'key', false);
  const spoken = q.order.map((orig, pos) => 'Option ' + (pos + 1) + ', ' + (speechOpt(data.options[orig]) || 'the flag in position ' + (pos + 1))).join('. ');
  Voice.speak((poll ? 'Community question. ' : 'Random challenge number ' + q.n + '. ') + plainSpeech(data.text) + ' ' + spoken + '.', { interrupt: true });
  setTimeout(revealQuestion, 60);
}

function answerPoll(pos) {
  const q = S.q, d = q.data;
  if (pos < 0) { addEvent('Community question skipped.', 'minor', false); closeQuestion(); return; }
  q.answered = true; q.closeIn = CFG.Q_CLOSE;
  [...el.qOptions.children].forEach((b, i) => { b.disabled = true; if (i === pos) b.classList.add('picked'); });
  const c = d.countries && d.countries[pos];
  let msg;
  if (d.kind === 'subscribe') {
    msg = pos === 0 ? 'Thank you for subscribing! You are awesome.' : pos === 1 ? 'Great! Tap that subscribe button now. Thank you!' : 'Please subscribe soon, it really helps the channel. Thank you!';
  } else if (c) msg = (d.kind === 'from' ? 'Welcome, friend from ' : 'Great choice! Cheering for ') + c.name + '!';
  else msg = d.kind === 'from' ? 'Welcome, friend from around the world!' : 'Great! Every country deserves support!';
  if (d.kind === 'subscribe') msg += ' Please like and share the video too!';
  el.qFeedback.innerHTML = '<div class="verdict poll">&#10004; Thanks for answering!</div><div class="exp">' + (c ? flagHTML(c) + ' ' : '') + msg + '</div>';
  el.qContinue.hidden = false; el.qBar.style.transform = 'scaleX(0)';
  addEvent((c ? flagHTML(c) + ' ' : '') + msg, 'good', false);
  Audio.sfx.correct();
  Voice.speak(msg, { interrupt: true });
}

function answerQuestion(pos) {
  const q = S.q;
  if (!q.open || q.answered || q.roundId !== S.roundId) return;   // no double submit, no stale round
  const d = q.data;
  if (pos >= d.options.length) return;
  if (d.type === 'poll') { answerPoll(pos); return; }
  q.answered = true; q.closeIn = CFG.Q_CLOSE;
  const correctPos = q.order.indexOf(d.correct), isRight = pos === correctPos, timedOut = pos < 0;
  S.qr.a++; S.qs.a++;
  if (isRight) { S.qr.c++; S.qs.c++; }
  [...el.qOptions.children].forEach((b, i) => {
    b.disabled = true;
    if (i === correctPos) b.classList.add('correct');         // green tick on the right answer
    else if (i === pos) b.classList.add('wrong');
  });
  const ansRaw = d.options[d.correct];
  el.qFeedback.innerHTML = '<div class="verdict ' + (isRight ? 'good' : 'bad') + '">' + (isRight ? '&#10004; Correct!' : (timedOut ? '&#9201; Time is up.' : '&#10008; Incorrect.')) + '</div>' +
    '<div class="ans-line"><span class="tick">&#10004;</span> Correct answer: <b>' + richText(ansRaw) + '</b></div>' +
    '<div class="exp">' + richText(d.exp) + '</div>';
  el.qContinue.hidden = false;
  el.qBar.style.transform = 'scaleX(0)';
  addEvent(isRight ? 'Correct answer!' : (timedOut ? 'Challenge #' + q.n + ' timed out.' : 'Incorrect answer.'), isRight ? 'good' : 'bad', false);
  if (isRight) Audio.sfx.correct(); else Audio.sfx.incorrect();
  Voice.speak((isRight ? 'Correct! ' : timedOut ? 'Time is up. ' : 'Wrong answer. ') + 'The correct answer is ' +
    (speechOpt(ansRaw) || 'option ' + (correctPos + 1)) + '. ' + plainSpeech(d.exp), { interrupt: true });
  updateStats();
}

function closeQuestion() {
  const q = S.q;
  q.open = false; q.answered = false; q.data = null;
  el.qCard.hidden = true; el.qIdle.hidden = false; el.qPanel.classList.remove('open');
  S.qNext = nextQInterval();
}

function questionTick(dt) {
  const q = S.q;
  if (q.open) {
    if (q.roundId !== S.roundId) { closeQuestion(); return; }
    if (!q.answered) {
      if (Voice.busy() && q.readWait < 15) q.readWait += dt;   // the clock starts once the question has been read out
      else q.remaining -= dt;
      el.qBar.style.transform = 'scaleX(' + clamp(q.remaining / CFG.Q_DEADLINE, 0, 1).toFixed(3) + ')';
      if (q.remaining <= 0) answerQuestion(-1);
    } else {
      if (Voice.busy() && q.closeWait < 14) q.closeWait += dt;  // keep the answer on screen until it has been spoken
      else q.closeIn -= dt;
      if (q.closeIn <= 0) closeQuestion();
    }
  } else if (S.opts.qFreq !== 'off') {
    S.qNext -= dt;
    if (S.qNext <= 0) openQuestion();
  }
}

/* =====================================================================
   13. MAIN LOOP
   ===================================================================== */
let lastTs = 0, loopStarted = false, frameErrs = 0, dtS = 1 / 60, slowN = 0;
function goLowQ() {                                        // device is struggling: quietly switch to a lighter mode so the game stays smooth
  lowQ = true; CFG.MAX_PARTICLES = 60; el.bg.classList.add('calm'); Audio.setLite(true); resizeCanvas();
}
function frame(ts) {
  requestAnimationFrame(frame);
  const raw = Math.min(0.1, (ts - lastTs) / 1000 || 0);    // clamp: inactive tabs never create huge steps
  lastTs = ts;
  dtS = dtS * 0.85 + Math.min(raw, 0.05) * 0.15;           // smoothed time step = even, jitter-free movement
  const dt = dtS;
  if (!lowQ && S.mode === 'running') { if (raw > 0.034) slowN++; else slowN = Math.max(0, slowN - 1); if (slowN > 120) goLowQ(); }
  try { update(dt); render(ts); hud(); frameErrs = 0; }
  catch (e) {                                              // one bad frame must never kill the game
    if (++frameErrs <= 3) console.error('Frame error (game keeps running):', e);
    if (frameErrs === 60) { el.errorBanner.hidden = false; el.errorBanner.textContent = 'Something went wrong. Press Restart Round to recover.'; }
  }
}
function startLoop() { if (loopStarted) return; loopStarted = true; requestAnimationFrame(frame); }

const CALLOUTS = [
  'Where are you from? Tell us your country in the comments!',
  'Which country do you support? Type it in the chat!',
  'Like the video if you can see your country flag!',
  'Subscribe to the channel and cheer for your country!',
  'Like, share and subscribe to support the channel!'
];
function showSub() {
  const cta = el.ctaBox; if (!cta) return;
  el.callout.hidden = true; S.calloutT = 0;
  cta.classList.add('attn');
  S.subT = CFG.SUB_SHOW; S.subIn = rand(CFG.SUB_MIN, CFG.SUB_MAX);
  addEvent('Like, share and subscribe!', 'minor', false);
  Voice.speak('Don\'t forget to like, share and subscribe!');
}
function hideSub() { const cta = el.ctaBox; if (cta) cta.classList.remove('attn'); S.subT = 0; }
el.likeBtn.addEventListener('click', () => {
  S.liked = !S.liked; el.likeBtn.classList.toggle('on', S.liked); el.likeBtn.setAttribute('aria-pressed', String(S.liked));
  el.likeBtn.innerHTML = S.liked ? '&#128077; Liked!' : '&#128077; Like';
  if (S.liked) Voice.speak('Thank you for the like!', { prio: 1 });
});
el.shareBtn.addEventListener('click', () => {
  const data = { title: 'World Countries Battle', text: 'Watch World Countries Battle!', url: location.href };
  const flash = t => { el.shareBtn.textContent = t; setTimeout(() => { el.shareBtn.innerHTML = '&#8599; Share'; }, 2200); };
  if (navigator.share) navigator.share(data).catch(() => {});
  else if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(location.href).then(() => flash('Link copied!'), () => flash('Copy the page link'));
  else flash('Copy the page link');
  Voice.speak('Thanks for sharing! Share it with your friends.', { prio: 1 });
});
function uiTimers(dt) {
  if (S.bannerT > 0) { S.bannerT -= dt; if (S.bannerT <= 0) el.elimBanner.hidden = true; }
  if (S.calloutT > 0) { S.calloutT -= dt; if (S.calloutT <= 0) el.callout.hidden = true; }
  if (S.subT > 0) { S.subT -= dt; if (S.subT <= 0) hideSub(); }
  else if (!S.q.open) { S.subIn -= dt; if (S.subIn <= 0 && S.bannerT <= 0) showSub(); }
  if (S.q.open) return;
  S.callIn -= dt;
  if (S.callIn <= 0 && (S.bannerT > 0 || S.subT > 0)) S.callIn = 2;
  if (S.callIn <= 0) {
    const line = CALLOUTS[S.callIdx++ % CALLOUTS.length];
    S.callIn = rand(18, 32);
    el.callout.textContent = line; el.callout.hidden = false; S.calloutT = 8;
    addEvent(line, 'minor', false);
    Voice.speak(line, { prio: 0 });
  }
  if (S.opts.bgAutoTick !== false && S.bgAuto && (S.bgIn -= dt) <= 0) { S.bgIn = 60; applyBg(nextAutoBg()); }
}

function update(dt) {
  if (S.mode === 'paused' || S.mode === 'ready') return;
  if (S.mode === 'celebrating') {
    updateParticles(dt); confetti(dt);
    S.celebrateT -= dt;
    if (S.celebrateT <= 0) {                              // automatic next round, after the winner has been announced
      if (Voice.busy() && (S.celWait = (S.celWait || 0) + dt) < 7) return;
      S.celWait = 0; startRound(S.round + 1);
    }
    return;
  }
  // running
  S.clock += dt; S.evCool -= dt; S.bounceCool -= dt;
  S.ramp = Math.min(1, S.ramp + dt / 1.8);
  questionTick(dt);
  if (S.mode !== 'running') return;
  uiTimers(dt);
  const frozen = S.opts.pauseOnQ && S.q.open;
  if (!frozen) {
    portalUpdate(dt);
    physics(dt);
    suckUpdate(dt);
    updateParticles(dt);
  }
}

/* =====================================================================
   14. RENDERING
   ===================================================================== */
let discCv = null, discKey = '';
function discSprite() {
  const key = view.size + '@' + view.dpr;
  if (discKey === key && discCv) return discCv;
  const { size, cx, R, dpr } = view, cv = document.createElement('canvas'); cv.width = cv.height = Math.floor(size * dpr);
  const c = cv.getContext('2d'); c.setTransform(dpr, 0, 0, dpr, 0, 0);
  const g = c.createRadialGradient(cx, cx, R * 0.1, cx, cx, R);
  g.addColorStop(0, 'rgba(255,255,255,.94)'); g.addColorStop(1, 'rgba(210,230,250,.94)');
  c.beginPath(); c.arc(cx, cx, R, 0, 6.2832); c.fillStyle = g; c.fill();
  c.save(); c.shadowColor = '#12b89a'; c.shadowBlur = 14; c.lineWidth = 4; c.strokeStyle = '#12b89a';
  c.beginPath(); c.arc(cx, cx, R, 0, 6.2832); c.stroke(); c.restore();
  c.lineWidth = 1; c.strokeStyle = 'rgba(37,99,235,.35)'; c.beginPath(); c.arc(cx, cx, R - 6, 0, 6.2832); c.stroke();
  discKey = key; return (discCv = cv);
}
function render(ts) {
  const c = ctx2d, { size, cx, R, dpr } = view;
  c.setTransform(dpr, 0, 0, dpr, 0, 0);
  c.clearRect(0, 0, size, size);
  // arena disc
  c.drawImage(discSprite(), 0, 0, size, size);

  drawPortal(c, ts);

  // flags
  for (const f of S.flags) {
    if (f.state === 'out' || f.alpha <= 0.01) continue;
    const sp = f.spr || (f.spr = getSprite(f.c));
    const rad = f.r * R * f.scale * (1 + f.bounce * 0.12);
    if (rad < 0.5) continue;
    if (f.alpha < 1) c.globalAlpha = f.alpha;
    const px = cx + f.x * R, py = cx + f.y * R;
    if (f.state === 'sucked') {
      c.save(); c.translate(px, py); c.rotate(f.rot || 0);
      c.drawImage(sp, -rad, -rad, rad * 2, rad * 2);
      c.lineWidth = 3; c.strokeStyle = 'rgba(225,29,72,.9)'; c.beginPath(); c.arc(0, 0, rad * 1.18, 0, 6.2832); c.stroke();
      c.restore();
    } else c.drawImage(sp, px - rad, py - rad, rad * 2, rad * 2);
    if (f.alpha < 1) c.globalAlpha = 1;
  }

  // particles
  for (const p of S.particles) {
    const a = clamp(p.life / p.max, 0, 1);
    c.fillStyle = 'rgba(' + p.color + ',' + a.toFixed(2) + ')';
    c.beginPath(); c.arc(cx + p.x * R, cx + p.y * R, p.size, 0, 6.2832); c.fill();
  }
}

function drawPortal(c, ts) {
  const b = S.bh;
  if (b.phase === 'idle' || b.size <= 0.01) return;
  const { cx, R } = view, px = cx + b.x * R, py = cx + b.y * R, rr = CFG.PORTAL_R * R * b.size;
  const glow = c.createRadialGradient(px, py, rr * 0.2, px, py, rr * 1.9);
  glow.addColorStop(0, 'rgba(0,0,0,0.95)'); glow.addColorStop(0.45, 'rgba(0,124,240,0.35)');
  glow.addColorStop(0.7, 'rgba(0,170,200,0.22)'); glow.addColorStop(1, 'rgba(0,170,200,0)');
  c.fillStyle = glow; c.beginPath(); c.arc(px, py, rr * 1.9, 0, 6.2832); c.fill();
  // spiral arms
  c.lineWidth = 2;
  for (let arm = 0; arm < 3; arm++) {
    c.strokeStyle = arm === 0 ? 'rgba(0,170,200,.75)' : 'rgba(60,100,230,.75)';
    c.beginPath();
    for (let k = 0; k <= 28; k++) {
      const t = k / 28, ang = b.rot + arm * 2.094 + t * 3.4, rad = rr * (1.7 - t * 1.35);
      const x = px + Math.cos(ang) * rad, y = py + Math.sin(ang) * rad;
      if (k === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.stroke();
  }
  // core + ring
  c.fillStyle = '#000'; c.beginPath(); c.arc(px, py, rr * 0.52, 0, 6.2832); c.fill();
  c.lineWidth = 8; c.strokeStyle = 'rgba(18,184,154,.25)'; c.beginPath(); c.arc(px, py, rr * 0.58, 0, 6.2832); c.stroke();
  c.lineWidth = 3; c.strokeStyle = '#12b89a'; c.beginPath(); c.arc(px, py, rr * 0.58, 0, 6.2832); c.stroke();
}

/* =====================================================================
   15. UI (feeds, roster, stats, controls)
   ===================================================================== */
function announce(msg) { el.announcer.textContent = msg; }

function addEvent(html, cls, say) {
  S.events.unshift({ html, cls: cls || '', t: S.clock, r: S.round });
  if (S.events.length > CFG.MAX_EVENTS) S.events.length = CFG.MAX_EVENTS;
  const li = document.createElement('li'); li.className = cls || '';
  li.innerHTML = '<span class="t">R' + S.round + ' ' + fmtTime(S.clock) + '</span>' + html;
  el.eventFeed.prepend(li);
  while (el.eventFeed.children.length > CFG.MAX_EVENTS) el.eventFeed.lastElementChild.remove();
  if (say !== false) {                                   // say: undefined = auto for important events, false = silent, string = custom
    const txt = typeof say === 'string' ? say : (/^(key|bad|good|win|minor)$/.test(cls || '') ? plainText(html) : '');
    if (txt) Voice.speak(txt, { prio: cls === 'win' ? 2 : cls === 'minor' ? 0 : 1, interrupt: cls === 'win' });
  }
}
function addElimEntry(n, c) {
  const li = document.createElement('li');
  li.innerHTML = '<span class="t">#' + n + '</span>' + flagHTML(c) + ' ' + c.name;
  el.elimFeed.prepend(li);
  el.elimCount.textContent = n;
}
function renderWinners() {
  el.winnersList.innerHTML = S.winners.length
    ? S.winners.map(w => '<li><span class="t">R' + w.round + (w.mode ? ' &middot; ' + w.mode : '') + '</span>' + flagHTML(w.c) + ' ' + w.c.name + '</li>').join('')
    : '<li class="muted">No winners yet.</li>';
}

const rosterCells = {};
function buildRoster() {
  el.rosterActive.innerHTML = ''; el.rosterOut.innerHTML = '';
  const fa = document.createDocumentFragment();
  const inPool = new Set(S.flags.map(f => f.c.code));
  for (const c of COUNTRIES) {
    if (!inPool.has(c.code)) continue;
    let cell = rosterCells[c.code];
    if (!cell) {
      cell = document.createElement('div');
      cell.className = 'cell'; cell.setAttribute('role', 'listitem'); cell.title = c.name; cell.setAttribute('aria-label', c.name);
      cell.innerHTML = flagHTML(c);
      rosterCells[c.code] = cell;
    }
    fa.appendChild(cell);
  }
  el.rosterActive.appendChild(fa);
  el.activeCount.textContent = S.N; el.outCount.textContent = 0; el.elimCount.textContent = 0;
}
function markEliminated(c) {
  const cell = rosterCells[c.code];
  if (cell) el.rosterOut.prepend(cell);
  el.activeCount.textContent = S.N - S.elimCount; el.outCount.textContent = S.elimCount;
}

function updateStats() {
  const alive = S.N - S.elimCount;
  setText(el.stAlive, alive); setText(el.stElim, S.elimCount);
  setText(el.stRound, S.round); setText(el.stCompleted, S.completed);
  setText(el.stQAns, S.qr.a); setText(el.stQCorrect, S.qr.c);
  setText(el.stQAcc, S.qr.a ? Math.round(S.qr.c / S.qr.a * 100) + '%' : '--');
  setText(el.qSession, 'Session: ' + S.qs.c + ' / ' + S.qs.a + ' correct' + (S.qs.a ? ' (' + Math.round(S.qs.c / S.qs.a * 100) + '%)' : ''));
  setText(el.roundPill, 'ROUND ' + S.round);
}

const PORTAL_LABEL = { idle: 'Dormant', opening: 'Opening', active: 'ACTIVE', closing: 'Closing' };
function hud() {
  if (S.mode === 'ready') { setText(el.stNext, '--'); setText(el.stPortal, 'Dormant'); return; }
  const b = S.bh;
  setText(el.stPortal, S.mode === 'celebrating' ? 'Closed' : PORTAL_LABEL[b.phase]);
  setText(el.stNext, b.phase === 'idle' && S.mode !== 'celebrating' ? Math.max(0, Math.ceil(b.nextIn)) + 's' : '--');
  let badge;
  if (S.mode === 'paused') badge = 'PAUSED';
  else if (S.mode === 'celebrating') badge = 'WINNER!';
  else if (b.phase === 'idle') badge = 'NEXT PORTAL ' + Math.max(0, Math.ceil(b.nextIn)) + 's';
  else badge = 'BLACK HOLE ' + PORTAL_LABEL[b.phase].toUpperCase();
  setText(el.arenaBadge, badge);
}

function updateUI() {
  const m = S.mode;
  setText(el.gameStatus, m === 'ready' ? 'READY' : m === 'running' ? 'LIVE' : m === 'paused' ? 'PAUSED' : 'WINNER');
  el.gameStatus.className = 'pill' + (m === 'running' ? ' on' : (m === 'paused' || m === 'celebrating') ? ' warn' : '');
  el.pauseOverlay.hidden = m !== 'paused';
  el.btnPause.disabled = m === 'ready';
  el.btnPause.innerHTML = m === 'paused' ? '&#9654; Resume' : '&#10074;&#10074; Pause';
  el.btnStart.disabled = m !== 'ready';
  el.qbPause.innerHTML = m === 'ready' ? '&#9654; Start' : m === 'paused' ? '&#9654; Resume' : '&#10074;&#10074; Pause';
  const anyAudio = S.opts.sfx || S.opts.music || S.opts.voice;
  el.qbMute.innerHTML = anyAudio ? '&#128266; Sound' : '&#128263; Muted';
  el.qbMute.setAttribute('aria-pressed', String(!anyAudio));
  setText(el.voiceInd, !window.speechSynthesis ? 'VOICE N/A' : S.opts.voice ? 'VOICE ON' : 'VOICE OFF');
  setText(el.sfxInd, S.opts.sfx ? 'SFX ON' : 'SFX OFF');
  setText(el.musicInd, S.opts.music ? 'MUSIC ON' : 'MUSIC OFF');
}

/* =====================================================================
   16. CONTROLS
   ===================================================================== */
function applyTrack() {
  const ids = Audio.trackIds, id = S.opts.track === 'shuffle' ? ids.filter(t => t !== Audio.current())[(Math.random() * (ids.length - 1)) | 0] : S.opts.track;
  Audio.setTrack(id);
}
function startGame() {
  if (S.mode !== 'ready') return;
  Audio.ensure();                                    // first user gesture
  S.opts.voice = true; el.optVoice.checked = true; Voice.refresh(); applyTrack();
  if (S.opts.music) Audio.setMusic(true);
  Voice.speak('Welcome to World Countries Battle! Let the battle begin!', { prio: 2 });
  startRound(1);
}
function togglePause() {
  if (S.mode === 'paused') { S.mode = S.pausedFrom || 'running'; S.pausedFrom = null; }
  else if (S.mode === 'running' || S.mode === 'celebrating') { S.pausedFrom = S.mode; S.mode = 'paused'; Voice.stop(); hideSub(); }
  updateUI();
}
function restartRound() {
  Voice.stop();
  Audio.ensure();
  if (S.opts.music) Audio.setMusic(true);
  startRound(S.round);
}

el.btnStart.addEventListener('click', startGame);
el.btnStartBig.addEventListener('click', startGame);
el.btnPause.addEventListener('click', togglePause);
el.btnRestart.addEventListener('click', restartRound);

/* ---------- game modes ---------- */
function buildModeSelects() {
  const groups = {};
  Object.keys(MODES).forEach(id => {
    const m = MODES[id];
    (groups[m.group] = groups[m.group] || []).push('<option value="' + id + '">' + m.label + ' (' + modeSize(id) + ')</option>');
  });
  const html = Object.keys(groups).map(g => '<optgroup label="' + g + '">' + groups[g].join('') + '</optgroup>').join('');
  el.optMode.innerHTML = html; el.optModeStart.innerHTML = html;
}
function syncModeUI() {
  const cur = MODES[S.modeId], next = MODES[S.nextModeId], pending = S.nextModeId !== S.modeId;
  el.optMode.value = S.nextModeId; el.optModeStart.value = S.nextModeId;
  setText(el.modePill, 'MODE: ' + cur.label.toUpperCase());
  el.modeDesc.textContent = next.desc + (pending ? ' Starts next round (or press Restart Round to switch now).' : '');
  el.startDesc.textContent = next.desc;
}
function setMode(id) {
  if (!MODES[id]) return;
  S.nextModeId = id;
  if (S.mode === 'ready') {                              // before the game starts, show the new lineup straight away
    S.modeId = id; layoutFlags(); buildRoster(); resetPortal(); updateStats();
  }
  syncModeUI();
}
el.optMode.addEventListener('change', () => setMode(el.optMode.value));
el.optModeStart.addEventListener('change', () => setMode(el.optModeStart.value));

/* ---------- quick bar (phones) ---------- */
el.qbPause.addEventListener('click', () => { if (S.mode === 'ready') startGame(); else togglePause(); });
el.qbRestart.addEventListener('click', restartRound);
el.qbMute.addEventListener('click', () => {
  const on = !(S.opts.sfx || S.opts.music || S.opts.voice);
  S.opts.sfx = S.opts.music = S.opts.voice = on;
  el.optSfx.checked = el.optMusic.checked = el.optVoice.checked = on;
  if (on) Audio.ensure(); else Voice.stop();
  Audio.setMusic(on && S.mode !== 'ready');
  updateUI();
});

/* ---------- phones: pause when the page is hidden, resume audio when it is back ---------- */
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    if (S.mode === 'running' || S.mode === 'celebrating') togglePause();
    Voice.stop(); Audio.setMusic(false);
  } else if (S.opts.music && S.mode !== 'ready') Audio.setMusic(true);
});
el.qContinue.addEventListener('click', () => { if (S.q.open && S.q.answered) closeQuestion(); });

document.querySelectorAll('input[name="speed"]').forEach(r => r.addEventListener('change', () => { if (r.checked) S.speed = SPEEDS[r.value]; }));
el.optSfx.addEventListener('change', () => { S.opts.sfx = el.optSfx.checked; if (S.opts.sfx) Audio.ensure(); updateUI(); });
el.optMusic.addEventListener('change', () => { S.opts.music = el.optMusic.checked; if (S.mode !== 'ready' || S.opts.music) Audio.setMusic(S.opts.music); updateUI(); });
el.optPauseQ.addEventListener('change', () => { S.opts.pauseOnQ = el.optPauseQ.checked; });
el.optVoice.addEventListener('change', () => { S.opts.voice = el.optVoice.checked; if (!S.opts.voice) Voice.stop(); updateUI(); });
Voice.onchange = (l, cur) => {
  el.voiceSel.innerHTML = l.length ? l.map(v => '<option value="' + v.name.replace(/"/g, '&quot;') + '"' + (cur && v.name === cur.name ? ' selected' : '') + '>' + v.name + '</option>').join('') : '<option>Default voice</option>';
};
Voice.refresh();
el.voiceSel.addEventListener('change', () => { Voice.setVoice(el.voiceSel.value); Voice.speak('Hello! I will be your game commentator.', { interrupt: true }); });
el.optTrack.addEventListener('change', () => { S.opts.track = el.optTrack.value; applyTrack(); });
el.btnVoiceTest.addEventListener('click', () => {
  S.opts.voice = true; el.optVoice.checked = true; updateUI();
  Voice.speak('Voice test. If you can hear this, the commentator is working.', { prio: 2, interrupt: true });
});
el.optQFreq.addEventListener('change', () => {
  S.opts.qFreq = el.optQFreq.value;
  if (!S.q.open) S.qNext = nextQInterval();
});
document.addEventListener('keydown', e => {
  if (e.target.matches('input,select,textarea')) return;
  if (e.key === 'p' || e.key === 'P') { if (S.mode !== 'ready') togglePause(); }
  if (S.q.open && !S.q.answered && /^[1-9]$/.test(e.key)) answerQuestion(Number(e.key) - 1);
});

/* ---------- backgrounds ---------- */
const AUTO_BGS = ['aurora', 'sunset', 'ocean', 'galaxy', 'neon', 'forest', 'candy', 'lava', 'space', 'deep-space', 'nebula'];
function nextAutoBg() { const o = AUTO_BGS.filter(b => b !== S.bgShown); return o[(Math.random() * o.length) | 0]; }
function applyBg(real) { S.bgShown = real; el.bg.dataset.bg = real; el.bg.style.backgroundImage = real === 'custom' ? 'url("' + S.customUrl + '")' : ''; }
function setBackground(name) {
  if (name === 'custom' && !S.customUrl) return;
  S.bg = name; S.bgAuto = name === 'auto';
  applyBg(name === 'auto' ? nextAutoBg() : name);
  el.bgButtons.querySelectorAll('.chip').forEach(b => b.classList.toggle('active', b.dataset.bg === name));
}
el.bgButtons.addEventListener('click', e => { const b = e.target.closest('.chip'); if (b) setBackground(b.dataset.bg); });
el.bgFile.addEventListener('change', () => {
  const file = el.bgFile.files && el.bgFile.files[0];
  if (!file) return;
  el.bgMsg.textContent = '';
  if (!file.type.startsWith('image/')) { el.bgMsg.textContent = 'Please choose an image file.'; el.bgFile.value = ''; return; }
  if (file.size > 20 * 1024 * 1024) { el.bgMsg.textContent = 'Image is too large (max 20 MB).'; el.bgFile.value = ''; return; }
  const url = URL.createObjectURL(file), img = new Image();
  img.onload = () => {
    if (S.customUrl) URL.revokeObjectURL(S.customUrl);     // release the previous image
    S.customUrl = url;
    el.bgPreview.src = url; el.bgPreview.hidden = false; el.bgCustomBtn.hidden = false;
    setBackground('custom');
    el.bgMsg.textContent = 'Custom background applied.';
  };
  img.onerror = () => { URL.revokeObjectURL(url); el.bgMsg.textContent = 'That image could not be loaded.'; console.warn('Background image failed to load:', file.name); };
  img.src = url;
  el.bgFile.value = '';
});
window.addEventListener('beforeunload', () => { if (S.customUrl) URL.revokeObjectURL(S.customUrl); });

/* ---------- saved settings (survive reloads; every access is guarded) ---------- */
const PREF_KEY = 'wcb.prefs.v3';
function loadPrefs() { try { const r = localStorage.getItem(PREF_KEY); const p = r ? JSON.parse(r) : {}; return p && typeof p === 'object' ? p : {}; } catch (e) { return {}; } }
function savePrefs() {
  try {
    const sp = document.querySelector('input[name="speed"]:checked');
    localStorage.setItem(PREF_KEY, JSON.stringify({ sfx: S.opts.sfx, music: S.opts.music, voice: S.opts.voice, pauseOnQ: S.opts.pauseOnQ, qFreq: S.opts.qFreq,
      speed: sp ? sp.value : 'normal', track: S.opts.track, mode: S.nextModeId, bg: S.bg === 'custom' ? 'auto' : S.bg, voiceName: el.voiceSel.value }));
  } catch (e) { /* private mode / storage full: just don't save */ }
}
function applyPrefs() {
  const p = loadPrefs();
  ['pauseOnQ'].forEach(k => { if (typeof p[k] === 'boolean') S.opts[k] = p[k]; });
  if (Q_FREQ[p.qFreq] || p.qFreq === 'off') S.opts.qFreq = p.qFreq;
  if (typeof p.track === 'string' && (p.track === 'shuffle' || Audio.trackIds.indexOf(p.track) >= 0)) S.opts.track = p.track;
  el.optTrack.value = S.opts.track;
  if (SPEEDS[p.speed]) { S.speed = SPEEDS[p.speed]; const r = document.querySelector('input[name="speed"][value="' + p.speed + '"]'); if (r) r.checked = true; }
  if (typeof p.mode === 'string' && MODES[p.mode]) { S.modeId = S.nextModeId = p.mode; }
  if (typeof p.bg === 'string' && p.bg !== 'custom' && el.bgButtons.querySelector('[data-bg="' + p.bg + '"]')) setBackground(p.bg);
  if (typeof p.voiceName === 'string' && p.voiceName) Voice.setVoice(p.voiceName);
  el.optSfx.checked = S.opts.sfx; el.optMusic.checked = S.opts.music; el.optVoice.checked = S.opts.voice; el.optPauseQ.checked = S.opts.pauseOnQ; el.optQFreq.value = S.opts.qFreq;
}
document.querySelector('.controls').addEventListener('change', savePrefs);
el.bgButtons.addEventListener('click', savePrefs);
el.qbMute.addEventListener('click', savePrefs);

/* ---------- first tap unlocks sound + speech on phones ---------- */
function unlockMedia() {
  Audio.ensure(); Voice.unlock();
  if (S.opts.music && S.mode !== 'ready') Audio.setMusic(true);
  ['pointerdown', 'touchend', 'keydown'].forEach(ev => window.removeEventListener(ev, unlockMedia));
}
['pointerdown', 'touchend', 'keydown'].forEach(ev => window.addEventListener(ev, unlockMedia, { passive: true }));

/* =====================================================================
   17. INIT
   ===================================================================== */
function init() {
  if (!window.speechSynthesis) { el.errorBanner.hidden = false; el.errorBanner.textContent = 'Is browser me voice (speech) support nahi hai. Voice ke liye Chrome (Android) ya Safari (iPhone) me kholo; app ke andar wale browser (WhatsApp/Instagram) me voice nahi chalti.'; }
  const errs = validateCountries();
  if (errs.length) {
    el.errorBanner.hidden = false;
    el.errorBanner.textContent = 'Country data validation failed: ' + errs.slice(0, 3).join(' ');
    console.error('Country data validation failed', errs);
    el.btnStart.disabled = true; el.btnStartBig.disabled = true;
    return;
  }
  fitArena(); resizeCanvas();
  if ('ResizeObserver' in window) {
    new ResizeObserver(resizeCanvas).observe(el.arenaBox);
    const ro = new ResizeObserver(fitArena);
    ['.topbar', '.stats'].forEach(sel => { const n = document.querySelector(sel); if (n) ro.observe(n); });
  }
  window.addEventListener('resize', () => { fitArena(); resizeCanvas(); });
  window.addEventListener('orientationchange', () => setTimeout(() => { fitArena(); resizeCanvas(); }, 250));
  window.addEventListener('load', fitArena);
  if (IS_MOBILE) el.bg.classList.add('calm');                 // static background on phones = smoother game
  setBackground('auto');
  buildModeSelects();
  applyPrefs();
  layoutFlags();                 // show the starting arrangement while READY
  S.ramp = 1;
  buildRoster();
  resetPortal();
  renderWinners();
  updateStats(); updateUI(); syncModeUI();
  startLoop();                   // exactly one animation loop for the whole session
}
init();

})();
