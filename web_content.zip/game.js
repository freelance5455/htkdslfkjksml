// NovaSnake Ultimate - rebuilt single-player core
"use strict";

const canvas = document.getElementById("c");
const ctx = canvas.getContext("2d");

const WORLD_W = 5200, WORLD_H = 3300;
const FOOD_COUNT = 420;
const BOT_COUNT = 11;
const HEAD_RADIUS = 18;
const BODY_RADIUS = 14;
const PLAYER_START_LENGTH = 24;
const FOOD_PICKUP_DISTANCE = 30;

let raf = 0, last = 0, paused = false, gameOver = false;
let snakes = [], foods = [], airdrop = null;
let cameraX = 0, cameraY = 0;
let coins = Number(localStorage.getItem("novaCoins") || 0);
let selectedSkin = Number(localStorage.getItem("novaSkin") || 0);
let playerName = "Player";

const input = { active:false, angle:0, boost:false };
const skins = [
  ["Classic","#20d6a1",0],["Ocean","#29a9ff",100],["Fire","#ff594f",250],
  ["Royal","#b77cff",500],["Gold","#ffd34e",1000],["Shadow","#b9c2ca",1500]
];

function resize(){
  canvas.width = innerWidth * devicePixelRatio;
  canvas.height = innerHeight * devicePixelRatio;
  ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);
}
addEventListener("resize", resize); resize();

function rand(a,b){ return a + Math.random()*(b-a); }
function distance(a,b){ return Math.hypot(a.x-b.x,a.y-b.y); }

function makeFood(){
  const r = Math.random();
  let value;
  if(r < .58) value=2;
  else if(r < .85) value=5;
  else if(r < .97) value=10;
  else value=50;
  return {
    x:rand(35,WORLD_W-35), y:rand(35,WORLD_H-35),
    r: value===50 ? 9 : value===10 ? 7 : value===5 ? 6 : 5,
    value,
    color: value===2 ? "#62ed79" : value===5 ? "#35aaff" : value===10 ? "#ff536b" : "#ffffff"
  };
}

function createSnake(name,color,x,y,isBot){
  const body=[];
  for(let i=0;i<PLAYER_START_LENGTH;i++) body.push({x:x-i*14,y});
  return {
    id:Math.random().toString(36).slice(2),
    name,color,body,
    angle:isBot ? rand(0,Math.PI*2) : 0,
    targetAngle:isBot ? 0 : 0,
    score:20,
    alive:true,isBot,
    tier:isBot ? "Easy" : "KING",
    lootValue:0,
    killLoot:0,
    boost:false,kills:0,
    foodEaten:0,
    think:0
  };
}

function resetGame(){
  gameOver=false; paused=false; airdrop=null;
  foods=[];
  for(let i=0;i<FOOD_COUNT;i++) foods.push(makeFood());

  snakes=[];
  const player=createSnake(
    playerName,
    skins[selectedSkin][1],
    WORLD_W/2,WORLD_H/2,false
  );
  snakes.push(player);

  for(let i=0;i<BOT_COUNT;i++){
    const bot=createSnake(
      "BOT "+(i+1),
      skins[(i+1)%skins.length][1],
      rand(250,WORLD_W-250),rand(250,WORLD_H-250),true
    );
    bot.score=Math.floor(rand(20,80));
    bot.tier = bot.score >= 60 ? "PRO" : bot.score >= 40 ? "NORMAL" : "EASY";
    bot.lootValue = Math.max(5, Math.floor(bot.score * (bot.tier === "PRO" ? 0.75 : bot.tier === "NORMAL" ? 0.6 : 0.5)));
    while(bot.body.length < 24 + Math.floor(bot.score/3)){
      const tail=bot.body[bot.body.length-1];
      bot.body.push({x:tail.x-14,y:tail.y});
    }
    snakes.push(bot);
  }
}

function eatNearbyFood(snake){
  const head=snake.body[0];
  // IMPORTANT: use a fixed pickup radius; snake heads do not have a ".r" property.
  for(let i=foods.length-1;i>=0;i--){
    const food=foods[i];
    if(distance(head,food) <= FOOD_PICKUP_DISTANCE + food.r){
      const oldScore=snake.score;
      snake.score += food.value;
      snake.foodEaten++;

      // Each food directly adds physical body segments.
      const growth = food.value >= 50 ? 5 : food.value >= 10 ? 3 : food.value >= 5 ? 2 : 1;
      for(let g=0;g<growth;g++){
        const tail=snake.body[snake.body.length-1];
        snake.body.push({x:tail.x,y:tail.y});
      }

      if(snake===snakes[0]){
        if(food.value>=10) coins += 1;
        toast("+"+food.value+" FOOD  •  GROW +"+growth);
      }

      foods[i]=makeFood();
    }
  }
}

function chooseBotTarget(bot){
  let best=null,bestDist=Infinity;
  const head=bot.body[0];

  // Prefer nearby food.
  for(const f of foods){
    const dd=distance(head,f);
    if(dd<bestDist && dd<700){ best=f; bestDist=dd; }
  }

  if(best){
    bot.targetAngle=Math.atan2(best.y-head.y,best.x-head.x);
  }

  // Avoid walls.
  const margin=350;
  if(head.x<margin) bot.targetAngle=0;
  else if(head.x>WORLD_W-margin) bot.targetAngle=Math.PI;
  else if(head.y<margin) bot.targetAngle=Math.PI/2;
  else if(head.y>WORLD_H-margin) bot.targetAngle=-Math.PI/2;

  // Avoid other snake heads.
  for(const other of snakes){
    if(other===bot || !other.alive) continue;
    const dd=distance(head,other.body[0]);
    if(dd<180){
      const away=Math.atan2(head.y-other.body[0].y,head.x-other.body[0].x);
      bot.targetAngle=away;
      break;
    }
  }
}

function moveSnake(s,dt){
  if(!s.alive) return;

  if(s.isBot){
    s.think-=dt;
    if(s.think<=0){ chooseBotTarget(s); s.think=.12; }
  }else if(input.active){
    s.targetAngle=input.angle;
  }

  let diff=Math.atan2(
    Math.sin(s.targetAngle-s.angle),
    Math.cos(s.targetAngle-s.angle)
  );
  const turnSpeed=s.isBot ? 4.2 : 6.5;
  s.angle += Math.max(-turnSpeed*dt,Math.min(turnSpeed*dt,diff));

  const boosting=s.boost && s.score>25;
  const speed=boosting ? 300 : 185;

  const head=s.body[0];
  const newHead={
    x:head.x+Math.cos(s.angle)*speed*dt,
    y:head.y+Math.sin(s.angle)*speed*dt
  };

  s.body.unshift(newHead);

  if(boosting) s.score=Math.max(1,s.score-16*dt);

  // Base length + growth from score.
  const wanted=PLAYER_START_LENGTH+Math.floor(s.score/2);
  while(s.body.length>wanted) s.body.pop();

  // World boundary = death.
  if(newHead.x<HEAD_RADIUS || newHead.y<HEAD_RADIUS ||
     newHead.x>WORLD_W-HEAD_RADIUS || newHead.y>WORLD_H-HEAD_RADIUS){
    s.alive=false;
  }

  eatNearbyFood(s);
}

function bodyCollisions(){
  for(const attacker of snakes){
    if(!attacker.alive) continue;
    const head=attacker.body[0];

    for(const target of snakes){
      if(attacker===target || !target.alive) continue;

      // Ignore first few segments so a snake cannot instantly collide with
      // another head during a crossing.
      for(let i=4;i<target.body.length;i++){
        if(distance(head,target.body[i]) < HEAD_RADIUS+BODY_RADIUS-4){
          attacker.alive=false;
          target.kills++;
          const loot = attacker.isBot ? attacker.lootValue : Math.max(5, Math.floor(attacker.score * 0.5));
          target.score += loot;
          target.killLoot += loot;
          if(target === snakes[0]){
            coins += attacker.isBot && attacker.tier === "PRO" ? 3 : 1;
            toast("💀 KILL • " + attacker.name + " [" + attacker.tier + "]  •  LOOT +" + loot);
          }
          break;
        }
      }
      if(!attacker.alive) break;
    }
  }

  // Head-to-head: larger score survives; equal score eliminates both.
  const a=snakes[0];
  for(let i=1;i<snakes.length;i++){
    const b=snakes[i];
    if(!a.alive || !b.alive) continue;
    if(distance(a.body[0],b.body[0]) < HEAD_RADIUS*1.8){
      if(a.score>b.score){
        b.alive=false;
        const loot=b.isBot ? b.lootValue : Math.max(5,Math.floor(b.score*0.5));
        a.score += loot; a.killLoot += loot; a.kills++;
        if(a===snakes[0]) toast("💀 KILL • " + b.name + " [" + b.tier + "]  •  LOOT +" + loot);
      }else if(b.score>a.score){
        a.alive=false;
        const loot=a.isBot ? a.lootValue : Math.max(5,Math.floor(a.score*0.5));
        b.score += loot; b.killLoot += loot; b.kills++;
        if(b===snakes[0]) toast("💀 KILL • " + a.name + " [" + a.tier + "]  •  LOOT +" + loot);
      }else { a.alive=false; b.alive=false; }
    }
  }
}

function updateAirdrop(dt){
  if(!airdrop && Math.random()<dt/28){
    airdrop={x:rand(300,WORLD_W-300),y:rand(300,WORLD_H-300),life:18};
    toast("AIRDROP +100");
  }
  if(!airdrop) return;
  airdrop.life-=dt;
  const p=snakes[0];
  if(p.alive && distance(p.body[0],airdrop)<42){
    p.score+=100;
    coins+=5;
    airdrop=null;
    toast("🎁 AIRDROP +100!");
  }else if(airdrop.life<=0){
    airdrop=null;
  }
}

function update(dt){
  if(paused || gameOver) return;

  for(const s of snakes) moveSnake(s,dt);
  bodyCollisions();
  updateAirdrop(dt);

  const player=snakes[0];
  if(!player.alive){
    finishGame();
    return;
  }

  // Dead bots drop some food.
  for(const bot of snakes.slice(1)){
    if(!bot.alive && !bot.dropped){
      bot.dropped=true;
      for(let i=0;i<Math.min(15,Math.floor(bot.body.length/3));i++){
        const p=bot.body[i*3];
        foods.push({x:p.x,y:p.y,r:5,value:2,color:"#62ed79"});
      }
    }
  }

  localStorage.setItem("novaCoins",String(Math.floor(coins)));
}

function finishGame(){
  gameOver=true;
  cancelAnimationFrame(raf);

  const p=snakes[0];
  const rank=1+snakes.filter(s=>s.alive && s.score>p.score).length;
  const reward=Math.floor(p.score/50);
  coins+=reward;
  localStorage.setItem("novaCoins",String(Math.floor(coins)));

  document.getElementById("result").textContent="GAME OVER";
  document.getElementById("stats").innerHTML=
    `Score: <b>${Math.floor(p.score)}</b><br>`+
    `Length: <b>${p.body.length}</b><br>`+
    `Food eaten: <b>${p.foodEaten}</b><br>`+
    `Rank: <b>#${rank}</b><br>`+
    `Coins earned: <b>+${reward}</b>`;

  document.getElementById("game").classList.add("hidden");
  document.getElementById("over").classList.remove("hidden");
}

function draw(){
  const p=snakes[0];
  const h=p.body[0];

  cameraX=Math.max(0,Math.min(WORLD_W-innerWidth,h.x-innerWidth/2));
  cameraY=Math.max(0,Math.min(WORLD_H-innerHeight,h.y-innerHeight/2));

  ctx.fillStyle="#061017";
  ctx.fillRect(0,0,innerWidth,innerHeight);

  const grid=90;
  ctx.strokeStyle="#ffffff09";
  ctx.lineWidth=1;
  const ox=(-cameraX)%grid,oy=(-cameraY)%grid;
  for(let x=ox;x<innerWidth;x+=grid){
    ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,innerHeight);ctx.stroke();
  }
  for(let y=oy;y<innerHeight;y+=grid){
    ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(innerWidth,y);ctx.stroke();
  }

  ctx.strokeStyle="#286174";ctx.lineWidth=5;
  ctx.strokeRect(-cameraX,-cameraY,WORLD_W,WORLD_H);

  for(const f of foods){
    ctx.fillStyle=f.color;
    ctx.beginPath();
    ctx.arc(f.x-cameraX,f.y-cameraY,f.r,0,Math.PI*2);
    ctx.fill();
  }

  if(airdrop){
    ctx.fillStyle="#ffbd3d";
    ctx.fillRect(airdrop.x-cameraX-16,airdrop.y-cameraY-12,32,24);
    ctx.fillStyle="#fff";
    ctx.font="bold 9px Arial";
    ctx.textAlign="center";
    ctx.fillText("+100",airdrop.x-cameraX,airdrop.y-cameraY+3);
  }

  for(const s of snakes){
    if(!s.alive) continue;

    ctx.lineCap="round";ctx.lineJoin="round";
    ctx.strokeStyle=s.color;ctx.lineWidth=BODY_RADIUS*2;
    ctx.beginPath();
    s.body.forEach((q,i)=>{
      if(i===0)ctx.moveTo(q.x-cameraX,q.y-cameraY);
      else ctx.lineTo(q.x-cameraX,q.y-cameraY);
    });
    ctx.stroke();

    const q=s.body[0];
    ctx.fillStyle=s.color;
    ctx.beginPath();
    ctx.arc(q.x-cameraX,q.y-cameraY,HEAD_RADIUS,0,Math.PI*2);
    ctx.fill();

    ctx.fillStyle="#fff";
    ctx.beginPath();
    ctx.arc(q.x-cameraX-6,q.y-cameraY-5,4,0,Math.PI*2);
    ctx.arc(q.x-cameraX+6,q.y-cameraY-5,4,0,Math.PI*2);
    ctx.fill();

    ctx.fillStyle="#111";
    ctx.beginPath();
    ctx.arc(q.x-cameraX-6,q.y-cameraY-5,2,0,Math.PI*2);
    ctx.arc(q.x-cameraX+6,q.y-cameraY-5,2,0,Math.PI*2);
    ctx.fill();

    ctx.fillStyle="#fff";
    ctx.font="bold 11px Arial";
    ctx.textAlign="center";
    const liveRank=[...snakes].filter(x=>x.alive).sort((a,b)=>b.score-a.score).indexOf(s)+1;
    const label = liveRank===1 ? "👑 " + s.name : s.name;
    ctx.fillText(label,q.x-cameraX,q.y-cameraY-26);
    if(liveRank===1){
      ctx.font="bold 13px Arial";
      ctx.fillText("👑 KING",q.x-cameraX,q.y-cameraY-41);
    }
  }

  document.getElementById("score").textContent=Math.floor(p.score);
  document.getElementById("length").textContent=p.body.length;

  const rank=[...snakes].filter(s=>s.alive).sort((a,b)=>b.score-a.score);
  document.getElementById("board").innerHTML=
    "<b>👑 LEADERBOARD</b>"+
    rank.slice(0,7).map((s,i)=>
      `<div class="row ${s===p?"you":""}"><span>${i===0?"👑 ":""}${i+1}. ${s.name}</span><b>${Math.floor(s.score)}</b></div>`
    ).join("");

  drawMinimap();
}

function drawMinimap(){
  const holder=document.getElementById("mini");
  let cv=holder.querySelector("canvas");
  if(!cv){cv=document.createElement("canvas");cv.width=125;cv.height=75;holder.appendChild(cv);}
  const m=cv.getContext("2d");
  m.fillStyle="#08151b";m.fillRect(0,0,125,75);

  for(const s of snakes){
    if(!s.alive)continue;
    m.fillStyle=s.color;
    m.beginPath();
    m.arc(s.body[0].x/WORLD_W*125,s.body[0].y/WORLD_H*75,2.7,0,Math.PI*2);
    m.fill();
  }
}

function gameLoop(t){
  const dt=Math.min(.035,Math.max(0,(t-last)/1000));
  last=t;
  update(dt);
  if(!gameOver)draw();
  raf=requestAnimationFrame(gameLoop);
}

function startSolo(){
  playerName=document.getElementById("playerName").value.trim()||"Player";
  document.getElementById("menu").classList.add("hidden");
  document.getElementById("over").classList.add("hidden");
  document.getElementById("game").classList.remove("hidden");
  resetGame();
  last=performance.now();
  cancelAnimationFrame(raf);
  raf=requestAnimationFrame(gameLoop);
}

function toast(text){
  const el=document.getElementById("toast");
  el.textContent=text;
  clearTimeout(toast.timer);
  toast.timer=setTimeout(()=>el.textContent="",1200);
}

// Joystick
function moveJoystick(e){
  const r=document.getElementById("joy").getBoundingClientRect();
  const x=e.clientX-r.left-r.width/2;
  const y=e.clientY-r.top-r.height/2;
  const max=45;
  const dist=Math.hypot(x,y);
  const amount=Math.min(1,dist/max);
  const angle=Math.atan2(y,x);

  document.getElementById("knob").style.transform=
    `translate(${Math.cos(angle)*amount*max}px,${Math.sin(angle)*amount*max}px)`;

  if(dist>7){input.active=true;input.angle=angle;}
}
function endJoystick(){
  input.active=false;
  document.getElementById("knob").style.transform="translate(0,0)";
}

const joy=document.getElementById("joy");
joy.addEventListener("pointerdown",e=>{
  joy.setPointerCapture(e.pointerId);moveJoystick(e);
});
joy.addEventListener("pointermove",e=>{if(input.active)moveJoystick(e);});
joy.addEventListener("pointerup",endJoystick);
joy.addEventListener("pointercancel",endJoystick);

// Boost
const boost=document.getElementById("boost");
boost.addEventListener("pointerdown",e=>{
  e.preventDefault();input.boost=true;
  if(snakes[0])snakes[0].boost=true;
});
for(const ev of ["pointerup","pointercancel","pointerleave"]){
  boost.addEventListener(ev,()=>{
    input.boost=false;
    if(snakes[0])snakes[0].boost=false;
  });
}

// Keyboard
addEventListener("keydown",e=>{
  const k=e.key.toLowerCase();
  const map={w:-Math.PI/2,arrowup:-Math.PI/2,s:Math.PI/2,arrowdown:Math.PI/2,a:Math.PI,arrowleft:Math.PI,d:0,arrowright:0};
  if(k in map){input.active=true;input.angle=map[k];}
  if(e.code==="Space"){input.boost=true;if(snakes[0])snakes[0].boost=true;}
});
addEventListener("keyup",e=>{
  const k=e.key.toLowerCase();
  if(["w","a","s","d","arrowup","arrowdown","arrowleft","arrowright"].includes(k))input.active=false;
  if(e.code==="Space"){input.boost=false;if(snakes[0])snakes[0].boost=false;}
});

// Buttons
document.getElementById("singleBtn").onclick=startSolo;
document.getElementById("again").onclick=()=>{
  document.getElementById("over").classList.add("hidden");
  document.getElementById("game").classList.remove("hidden");
  resetGame();last=performance.now();
  cancelAnimationFrame(raf);raf=requestAnimationFrame(gameLoop);
};
document.getElementById("back").onclick=()=>location.reload();
document.getElementById("pause").onclick=()=>{
  paused=!paused;
  document.getElementById("pause").textContent=paused?"▶":"Ⅱ";
};

// Bluetooth UI
document.getElementById("btBtn").onclick=()=>{
  document.getElementById("btPanel").classList.toggle("hidden");
};
document.getElementById("btHost").onclick=()=>{
  document.getElementById("btStatus").textContent=
    "HOST selected. Use the Android Bluetooth bridge described in README to connect Player 2.";
};
document.getElementById("btJoin").onclick=()=>{
  document.getElementById("btStatus").textContent=
    "JOIN selected. Enter the host/device code after the native Bluetooth bridge reports it.";
};

// Skins
document.getElementById("skinsBtn").onclick=()=>{
  renderSkins();document.getElementById("skins").classList.remove("hidden");
};
document.getElementById("closeSkins").onclick=()=>{
  document.getElementById("skins").classList.add("hidden");
};
function renderSkins(){
  document.getElementById("coins").textContent="Coins: "+Math.floor(coins);
  document.getElementById("skinGrid").innerHTML=skins.map((s,i)=>{
    const owned=i===0||localStorage.getItem("skin"+i)==="1";
    return `<div class="skin">
      <div class="swatch" style="background:${s[1]}"></div>
      <b>${s[0]}</b><br><small>${i===0?"FREE":s[2]+" coins"}</small><br>
      <button onclick="useSkin(${i})">${selectedSkin===i?"SELECTED":owned?"USE":"BUY"}</button>
    </div>`;
  }).join("");
}
window.useSkin=function(i){
  if(i!==0 && localStorage.getItem("skin"+i)!=="1"){
    if(coins<skins[i][2]){toast("NOT ENOUGH COINS");return;}
    coins-=skins[i][2];
    localStorage.setItem("skin"+i,"1");
  }
  selectedSkin=i;
  localStorage.setItem("novaSkin",String(i));
  renderSkins();
};
