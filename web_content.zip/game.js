// MAFIA MYSTERY - Offline Social Deduction Engine with Dynamic Audio
// Developed by Siddharth Tiwari
class MafiaGame {
  constructor() {
    this.round = 1;
    this.phase = 'INIT';
    this.playerCount = 10;
    this.players = [];
    this.selectedTargetId = null;
    this.nightVictimId = null;
    this.doctorSavedId = null;
    this.wizardCheckedId = null;
    this.wizardKnownMafia = [];
    this.votes = {};
    this.chronicle = [];
    this.winStreak = parseInt(localStorage.getItem('mm_win_streak') || '0', 10);
    this.currentDirectiveTimer = null;
    this.activeTab = 'players';
    this.colors = [
      { name: 'RED', hex: '#EF4444' }, { name: 'CYAN', hex: '#06B6D4' },
      { name: 'GREEN', hex: '#10B981' }, { name: 'PURPLE', hex: '#8B5CF6' },
      { name: 'ORANGE', hex: '#F97316' }, { name: 'YELLOW', hex: '#EAB308' },
      { name: 'BLUE', hex: '#3B82F6' }, { name: 'PINK', hex: '#EC4899' },
      { name: 'LIME', hex: '#84CC16' }, { name: 'WHITE', hex: '#E2E8F0' }
    ];
    this.realNamesPool = [
      'Liam', 'Olivia', 'Noah', 'Emma', 'Oliver', 'Charlotte', 'James', 'Amelia',
      'Elijah', 'Sophia', 'William', 'Isabella', 'Lucas', 'Mia', 'Henry', 'Evelyn',
      'Alexander', 'Harper', 'Benjamin', 'Camila', 'Sebastian', 'Gianna', 'Jack', 'Abigail',
      'Daniel', 'Luna', 'Matthew', 'Ella', 'Jackson', 'Avery', 'David', 'Scarlett',
      'Joseph', 'Emily', 'Samuel', 'Aria', 'Arthur', 'Penelope', 'Chloe', 'Layla',
      'Leo', 'Maya', 'Julian', 'Elena', 'Marcus', 'Nora', 'Mateo', 'Freya', 'Ethan', 'Zoe'
    ];
    this.initDOM();
    this.bindEvents();
    this.showScreen('menu-screen');
  }

  initDOM() {
    this.dom = {
      menuScreen: document.getElementById('menu-screen'),
      playScreen: document.getElementById('play-screen'),
      gameOverScreen: document.getElementById('game-over-screen'),
      btnMenuStart: document.getElementById('btn-menu-start'),
      btnMenuSettings: document.getElementById('btn-menu-settings'),
      btnMenuRules: document.getElementById('btn-menu-rules'),
      btnMenuCredits: document.getElementById('btn-menu-credits'),
      btnGameBack: document.getElementById('btn-game-back'),
      phaseBadge: document.getElementById('phase-badge'),
      roundNumber: document.getElementById('round-number'),
      hudProgressLine: document.getElementById('hud-progress-line'),
      emergencyAlert: document.getElementById('emergency-alert'),
      gameplayTabsPanel: document.getElementById('gameplay-tabs-panel'),
      btnTabPlayers: document.getElementById('btn-tab-players'),
      btnTabLiveLog: document.getElementById('btn-tab-live-log'),
      btnTabChat: document.getElementById('btn-tab-chat'),
      tabsAlivePill: document.getElementById('tabs-alive-pill'),
      chatLockBadge: document.getElementById('chat-lock-badge'),
      tabPlayersView: document.getElementById('tab-players-view'),
      tabLiveLogView: document.getElementById('tab-live-log-view'),
      tabChatView: document.getElementById('tab-chat-view'),
      cardTableGrid: document.getElementById('card-table-grid'),
      playersDirectoryList: document.getElementById('players-directory-list'),
      liveLogFeed: document.getElementById('live-log-feed'),
      chatLockedOverlay: document.getElementById('chat-locked-overlay'),
      chatActiveWrap: document.getElementById('chat-active-wrap'),
      quickReactionsBar: document.getElementById('quick-reactions-bar'),
      chatContainer: document.getElementById('chat-messages-container'),
      dockRoleIndicator: document.getElementById('dock-role-indicator'),
      dockInstruction: document.getElementById('dock-instruction'),
      dockActionButtons: document.getElementById('dock-action-buttons'),
      diceRollOverlay: document.getElementById('dice-roll-overlay'),
      cyberDiceCube: document.getElementById('cyber-dice-cube'),
      diceStatusTitle: document.getElementById('dice-status-title'),
      diceRoleTicker: document.getElementById('dice-role-ticker'),
      outcomeIcon: document.getElementById('outcome-icon'),
      outcomeTitle: document.getElementById('outcome-title'),
      outcomeDesc: document.getElementById('outcome-desc'),
      streakCountVal: document.getElementById('streak-count-val'),
      finalRosterSummary: document.getElementById('final-roster-summary'),
      btnPlayAgain: document.getElementById('btn-play-again'),
      btnViewSummaryLog: document.getElementById('btn-view-summary-log'),
      btnGameoverMenu: document.getElementById('btn-gameover-menu'),
      playerNameInput: document.getElementById('player-name-input'),
      toggleSfx: document.getElementById('toggle-sfx'),
      toggleBgm: document.getElementById('toggle-bgm'),
      toggleHaptics: document.getElementById('toggle-haptics'),
      fastModeToggle: document.getElementById('fast-mode-toggle'),
      chronicleTimeline: document.getElementById('chronicle-timeline'),
      divinationResultText: document.getElementById('divination-result-text'),
      btnCloseDivination: document.getElementById('btn-close-divination'),
      ruleFlyoutBackdrop: document.getElementById('rule-flyout-backdrop'),
      ruleFlyoutCard: document.getElementById('rule-flyout-card'),
      flyoutIcon: document.getElementById('flyout-icon'),
      flyoutTitle: document.getElementById('flyout-title'),
      flyoutBody: document.getElementById('flyout-body'),
      btnCloseFlyout: document.getElementById('btn-close-flyout'),
      btnFlyoutOk: document.getElementById('btn-flyout-ok')
    };
  }

  bindEvents() {
    const startAudioOnGesture = () => {
      window.soundEngine.init();
      if (this.phase === 'MENU' || this.phase === 'INIT') {
        window.soundEngine.startMenuMusic();
      }
      document.removeEventListener('click', startAudioOnGesture);
      document.removeEventListener('touchstart', startAudioOnGesture);
    };
    document.addEventListener('click', startAudioOnGesture, { once: true });
    document.addEventListener('touchstart', startAudioOnGesture, { once: true });

    this.dom.btnMenuStart.addEventListener('click', () => {
      window.soundEngine.init();
      this.startNewGame();
    });
    this.dom.btnMenuSettings.addEventListener('click', () => this.showModal('modal-settings'));
    this.dom.btnMenuRules.addEventListener('click', () => this.showModal('modal-rules'));
    this.dom.btnMenuCredits.addEventListener('click', () => this.openMovieCredits());

    this.dom.btnGameBack.addEventListener('click', () => {
      if (confirm('Leave current game and return to Main Menu?')) {
        this.clearDirectiveTimer();
        this.showScreen('menu-screen');
        this.phase = 'MENU';
        window.soundEngine.startMenuMusic();
      }
    });

    document.querySelectorAll('.modal-close-cyber').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-close');
        if (id) this.hideModal(id);
      });
    });

    if (this.dom.btnCloseDivination) {
      this.dom.btnCloseDivination.addEventListener('click', () => {
        this.hideModal('modal-divination');
        this.stepWizardSleep();
      });
    }

    this.dom.btnPlayAgain.addEventListener('click', () => this.startNewGame());
    this.dom.btnViewSummaryLog.addEventListener('click', () => {
      this.renderChronicle();
      this.showModal('modal-log');
    });
    this.dom.btnGameoverMenu.addEventListener('click', () => {
      this.showScreen('menu-screen');
      this.phase = 'MENU';
      window.soundEngine.startMenuMusic();
    });

    document.querySelectorAll('.gameplay-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tabKey = btn.getAttribute('data-tab');
        if (tabKey) this.switchTab(tabKey);
      });
    });

    document.querySelectorAll('.rule-interactive-box').forEach(box => {
      box.addEventListener('click', () => {
        const ruleKey = box.getAttribute('data-rule');
        if (ruleKey) this.openRuleFlyout(ruleKey);
      });
    });

    if (this.dom.btnCloseFlyout) this.dom.btnCloseFlyout.addEventListener('click', () => this.closeRuleFlyout());
    if (this.dom.btnFlyoutOk) this.dom.btnFlyoutOk.addEventListener('click', () => this.closeRuleFlyout());
    if (this.dom.ruleFlyoutBackdrop) {
      this.dom.ruleFlyoutBackdrop.addEventListener('click', (e) => {
        if (e.target === this.dom.ruleFlyoutBackdrop) this.closeRuleFlyout();
      });
    }

    if (this.dom.quickReactionsBar) {
      this.dom.quickReactionsBar.querySelectorAll('.quick-react-btn').forEach(btn => {
        btn.addEventListener('click', () => this.handleUserReaction(btn.getAttribute('data-reaction')));
      });
    }

    // Settings persistence (Local Storage)
    if (this.dom.playerNameInput) {
      try {
        const savedName = localStorage.getItem('mm_player_name');
        if (savedName) this.dom.playerNameInput.value = savedName;
      } catch (e) {}
      this.dom.playerNameInput.addEventListener('input', (e) => {
        try { localStorage.setItem('mm_player_name', e.target.value.trim()); } catch (err) {}
      });
    }

    if (this.dom.fastModeToggle) {
      try {
        const savedFast = localStorage.getItem('mm_fast_mode');
        if (savedFast !== null) this.dom.fastModeToggle.checked = (savedFast === 'true');
      } catch (e) {}
      this.dom.fastModeToggle.addEventListener('change', (e) => {
        try { localStorage.setItem('mm_fast_mode', e.target.checked ? 'true' : 'false'); } catch (err) {}
      });
    }

    if (this.dom.toggleSfx) {
      this.dom.toggleSfx.checked = window.soundEngine.sfxEnabled;
      this.dom.toggleSfx.addEventListener('change', (e) => {
        window.soundEngine.setSfxEnabled(e.target.checked);
      });
    }
    if (this.dom.toggleBgm) {
      this.dom.toggleBgm.checked = window.soundEngine.bgmEnabled;
      this.dom.toggleBgm.addEventListener('change', (e) => {
        window.soundEngine.setBgmEnabled(e.target.checked);
      });
    }
    if (this.dom.toggleHaptics) {
      this.dom.toggleHaptics.checked = window.soundEngine.hapticsEnabled;
      this.dom.toggleHaptics.addEventListener('change', (e) => {
        window.soundEngine.setHapticsEnabled(e.target.checked);
      });
    }
  }

  handleUserReaction(reaction) {
    if (!this.players[0] || !this.players[0].alive) return;
    this.addChat('user', reaction, this.players[0].name);
    this.showReactionBubble(0, reaction);
    window.soundEngine.playCardFlip();
    if (Math.random() < 0.65) {
      const livingBots = this.players.filter(p => !p.isUser && p.alive);
      if (livingBots.length > 0) {
        const bot = livingBots[Math.floor(Math.random() * livingBots.length)];
        const answers = ['AGREED', 'NOT SURE', 'VOTE THEM', 'WAIT FOR EVIDENCE'];
        const ans = answers[Math.floor(Math.random() * answers.length)];
        setTimeout(() => {
          if (!bot.alive) return;
          this.addChat('bot', ans, bot.name);
          this.showReactionBubble(bot.id, ans);
        }, 600 + Math.random() * 800);
      }
    }
  }

  showReactionBubble(playerId, text) {
    const cardEl = document.querySelector(`.cyber-card[data-id="${playerId}"]`);
    if (!cardEl) return;
    const artWrap = cardEl.querySelector('.astronaut-frame');
    if (!artWrap) return;
    const existing = artWrap.querySelector('.card-reaction-bubble');
    if (existing) existing.remove();
    const bubble = document.createElement('div');
    bubble.className = 'card-reaction-bubble';
    bubble.textContent = text;
    artWrap.appendChild(bubble);
    setTimeout(() => bubble.remove(), 2200);
  }

  triggerScreenShake() {
    const screen = this.dom.playScreen;
    if (screen) {
      screen.classList.add('screen-shake');
      setTimeout(() => screen.classList.remove('screen-shake'), 450);
    }
  }

  showModal(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'flex';
  }

  hideModal(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = 'none';
  }

  showScreen(id) {
    this.dom.menuScreen.style.display = id === 'menu-screen' ? 'flex' : 'none';
    this.dom.playScreen.style.display = id === 'play-screen' ? 'flex' : 'none';
    this.dom.playScreen.style.flexDirection = 'column';
    this.dom.gameOverScreen.style.display = id === 'game-over-screen' ? 'block' : 'none';
  }

  openMovieCredits() {
    this.showModal('modal-credits');
    this.restartCreditsCrawl();
  }

  restartCreditsCrawl() {
    const crawl = document.getElementById('credits-crawl-content');
    if (!crawl) return;
    crawl.style.animation = 'none';
    void crawl.offsetHeight;
    crawl.style.animation = 'movieCreditsRoll 32s linear infinite';
  }

  getOperativeSvg(player) {
    const color = player.color.hex;
    const isDead = !player.alive;
    const isSleeping = player.sleeping && player.alive;

    if (isDead) {
      return `
        <svg class="astronaut-svg dead" viewBox="0 0 100 100" fill="none">
          <ellipse cx="50" cy="24" rx="15" ry="15" fill="#2E3947" stroke="#1E2633" stroke-width="2"/>
          <path d="M 25 84 C 25 58 33 44 50 44 C 67 44 75 58 75 84 Z" fill="#2E3947" stroke="#1E2633" stroke-width="2"/>
          <rect x="36" y="19" width="28" height="11" rx="4" fill="#161C24"/>
          <line x1="42" y1="21" x2="48" y2="28" stroke="#D9383A" stroke-width="2.5" stroke-linecap="round"/>
          <line x1="48" y1="21" x2="42" y2="28" stroke="#D9383A" stroke-width="2.5" stroke-linecap="round"/>
          <line x1="52" y1="21" x2="58" y2="28" stroke="#D9383A" stroke-width="2.5" stroke-linecap="round"/>
          <line x1="58" y1="21" x2="52" y2="28" stroke="#D9383A" stroke-width="2.5" stroke-linecap="round"/>
          <text x="50" y="70" fill="#D9383A" font-family="'JetBrains Mono',monospace" font-size="8.5" font-weight="900" text-anchor="middle">OUT</text>
        </svg>
      `;
    }

    const visorBg = isSleeping ? '#0B0F15' : '#0F1722';
    const visorReflect = isSleeping ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.4)';
    const sleepEye = isSleeping
      ? `<line x1="40" y1="24.5" x2="47" y2="24.5" stroke="#4A5568" stroke-width="2" stroke-linecap="round"/><line x1="53" y1="24.5" x2="60" y2="24.5" stroke="#4A5568" stroke-width="2" stroke-linecap="round"/>`
      : `<polygon points="37,20 63,20 60,28 40,28" fill="${visorBg}" stroke="rgba(255,255,255,0.4)" stroke-width="0.8"/><path d="M 40 21 L 52 21 L 47 25 L 39 25 Z" fill="${visorReflect}"/>`;

    return `
      <svg class="astronaut-svg ${isSleeping ? 'sleeping' : 'awake'}" viewBox="0 0 100 100" fill="none" style="filter: drop-shadow(0 3px 8px ${color}55);">
        <rect x="17" y="50" width="8" height="26" rx="3" fill="${color}" opacity="0.9"/>
        <rect x="17" y="50" width="8" height="26" rx="3" fill="rgba(0,0,0,0.25)"/>
        <path d="M 25 84 C 25 56 33 42 50 42 C 67 42 75 56 75 84 Z" fill="${color}"/>
        <path d="M 50 42 C 67 42 75 56 75 84 L 50 84 Z" fill="rgba(0,0,0,0.2)"/>
        <path d="M 36 43 Q 50 47 64 43" stroke="rgba(0,0,0,0.35)" stroke-width="2" fill="none"/>
        <circle cx="50" cy="56" r="3.5" fill="rgba(255,255,255,0.85)"/>
        <ellipse cx="50" cy="24" rx="16" ry="16" fill="${color}"/>
        <path d="M 50 8 A 16 16 0 0 1 66 24 A 16 16 0 0 1 50 40 Z" fill="rgba(0,0,0,0.2)"/>
        <rect x="35" y="18" width="30" height="13" rx="5" fill="${visorBg}" stroke="rgba(255,255,255,0.35)" stroke-width="1"/>
        ${sleepEye}
      </svg>
    `;
  }

  rollDiceSequence(userRole, onFinish) {
    if (!this.dom.diceRollOverlay) { if (onFinish) onFinish(); return; }
    this.dom.diceRollOverlay.style.display = 'flex';
    this.dom.cyberDiceCube.classList.add('rolling');
    this.dom.diceStatusTitle.innerHTML = '<span class="live-dot">●</span> DECIDING YOUR ROLE...';
    window.soundEngine.playDiceRoll();

    const roleSignatures = ['[ CIVILIAN ]', '[ MEDIC ]', '[ POLICE ]', '[ IMPOSTER ]'];
    let tickIdx = 0;
    const tickerInterval = setInterval(() => {
      if (this.dom.diceRoleTicker) {
        this.dom.diceRoleTicker.textContent = roleSignatures[tickIdx % roleSignatures.length];
        tickIdx++;
      }
    }, 90);

    setTimeout(() => {
      clearInterval(tickerInterval);
      this.dom.cyberDiceCube.classList.remove('rolling');
      const landingTransforms = {
        'mafia': 'rotateY(180deg)',
        'doctor': 'rotateY(90deg)',
        'wizard': 'rotateY(-90deg)',
        'civilian': 'rotateX(-90deg)'
      };
      this.dom.cyberDiceCube.style.transform = landingTransforms[userRole] || 'rotateY(0deg)';
      window.soundEngine.playDiceLanding();
      const roleDisplayNames = {
        'mafia': '⚠️ IMPOSTER',
        'doctor': '🛡️ MEDIC',
        'wizard': '🔍 POLICE',
        'civilian': '📋 CIVILIAN'
      };
      if (this.dom.diceRoleTicker) this.dom.diceRoleTicker.textContent = roleDisplayNames[userRole] || '[ ASSIGNED ]';
      if (this.dom.diceStatusTitle) this.dom.diceStatusTitle.innerHTML = '✨ ROLE CONFIRMED!';
      setTimeout(() => {
        this.dom.diceRollOverlay.style.display = 'none';
        this.dom.cyberDiceCube.style.transform = 'none';
        if (onFinish) onFinish();
      }, 1050);
    }, 1750);
  }

  startNewGame() {
    this.round = 1;
    this.phase = 'ROLE_SELECTION';
    this.wizardKnownMafia = [];
    this.chronicle = [];
    this.votes = {};
    if (this.dom.chatContainer) this.dom.chatContainer.innerHTML = '';
    if (this.dom.liveLogFeed) this.dom.liveLogFeed.innerHTML = '<div class="log-entry system"><span class="log-time">[00:00]</span> Game started. 10 players assembled in town.</div>';

    const roleDeck = ['mafia', 'doctor', 'wizard'];
    for (let i = 0; i < 7; i++) roleDeck.push('civilian');
    for (let i = roleDeck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [roleDeck[i], roleDeck[j]] = [roleDeck[j], roleDeck[i]];
    }

    const userName = (this.dom.playerNameInput ? this.dom.playerNameInput.value.trim() : '') || 'Siddharth';
    const shuffledNames = [...this.realNamesPool].sort(() => Math.random() - 0.5);

    this.players = [];
    for (let i = 0; i < 10; i++) {
      const isUser = (i === 0);
      const name = isUser ? userName : shuffledNames[i - 1];
      this.players.push({
        id: i,
        name: name,
        role: roleDeck[i],
        alive: true,
        sleeping: true,
        isUser: isUser,
        color: this.colors[i],
        votesReceived: 0,
        eliminatedRound: null
      });
    }

    const userRole = this.players[0].role;
    this.rollDiceSequence(userRole, () => {
      this.showScreen('play-screen');
      if (this.dom.roundNumber) this.dom.roundNumber.textContent = this.round < 10 ? `0${this.round}` : this.round;
      window.soundEngine.startGameplayMusic();
      window.soundEngine.playCardFlip();
      this.renderCards();
      this.updateAliveCount();
      this.updatePlayersDirectory();
      this.switchTab('players');
      this.addLiveLog(`You were assigned role: ${userRole.toUpperCase()}`, 'system');
      setTimeout(() => {
        const userCard = document.querySelector('.cyber-card[data-id="0"]');
        if (userCard) userCard.classList.add('flipped');
      }, 250);
      this.addChronicleEntry(`Day 1 begins. 10 citizens assembled in town.`);
      setTimeout(() => this.stepNightFalls(), 1200);
    });
  }

  updateAliveCount() {
    const aliveCount = this.players.filter(p => p.alive).length;
    if (this.dom.tabsAlivePill) this.dom.tabsAlivePill.textContent = `${aliveCount}/10`;
  }

  switchTab(tabId) {
    this.activeTab = tabId;
    if (this.dom.btnTabLiveLog) this.dom.btnTabLiveLog.classList.toggle('active', tabId === 'live-log');
    if (this.dom.btnTabChat) this.dom.btnTabChat.classList.toggle('active', tabId === 'chat');
    if (this.dom.btnTabPlayers) this.dom.btnTabPlayers.classList.toggle('active', tabId === 'players');
    if (this.dom.tabLiveLogView) {
      this.dom.tabLiveLogView.style.display = tabId === 'live-log' ? 'flex' : 'none';
      if (tabId === 'live-log' && this.dom.liveLogFeed) this.dom.liveLogFeed.scrollTop = this.dom.liveLogFeed.scrollHeight;
    }
    if (this.dom.tabChatView) {
      this.dom.tabChatView.style.display = tabId === 'chat' ? 'flex' : 'none';
      if (tabId === 'chat' && this.dom.chatContainer) this.dom.chatContainer.scrollTop = this.dom.chatContainer.scrollHeight;
    }
    if (this.dom.tabPlayersView) {
      this.dom.tabPlayersView.style.display = tabId === 'players' ? 'flex' : 'none';
    }
    window.soundEngine.playCardFlip();
  }

  addLiveLog(text, type = 'system') {
    if (!this.dom.liveLogFeed) return;
    const now = new Date();
    const timeStr = `[${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}]`;
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    entry.innerHTML = `<span class="log-time">${timeStr}</span> ${text}`;
    this.dom.liveLogFeed.appendChild(entry);
    this.dom.liveLogFeed.scrollTop = this.dom.liveLogFeed.scrollHeight;
  }

  updateChatLockState() {
    const isVoting = (this.phase === 'VOTING');
    const userAlive = this.players[0] && this.players[0].alive;
    if (this.dom.chatLockBadge) {
      this.dom.chatLockBadge.textContent = isVoting ? 'OPEN' : 'LOCKED';
      this.dom.chatLockBadge.className = `chat-lock-tag ${isVoting ? 'unlocked' : 'locked'}`;
    }
    if (this.dom.chatLockedOverlay) this.dom.chatLockedOverlay.style.display = isVoting ? 'none' : 'flex';
    if (this.dom.chatActiveWrap) this.dom.chatActiveWrap.style.display = isVoting ? 'flex' : 'none';
    if (this.dom.quickReactionsBar) this.dom.quickReactionsBar.style.display = (isVoting && userAlive) ? 'flex' : 'none';
    if (!userAlive && isVoting) {
      const existingNotice = document.getElementById('chat-eliminated-notice');
      if (!existingNotice && this.dom.chatContainer) {
        const deadNotice = document.createElement('div');
        deadNotice.id = 'chat-eliminated-notice';
        deadNotice.className = 'chat-dead-notice';
        deadNotice.textContent = '👻 You have been eliminated. Dead players cannot speak.';
        this.dom.chatContainer.prepend(deadNotice);
      }
    }
  }

  updatePlayersDirectory() {
    if (!this.dom.playersDirectoryList || !this.players) return;
    const aliveCount = this.players.filter(p => p.alive).length;
    if (this.dom.tabsAlivePill) this.dom.tabsAlivePill.textContent = `${aliveCount}/10`;
    this.dom.playersDirectoryList.innerHTML = this.players.map(p => `
      <div class="player-directory-item ${p.alive ? '' : 'dead'}">
        <div class="dir-left">
          <span class="dir-color-dot" style="background: ${p.color.hex}"></span>
          <span class="dir-name">${p.name} ${p.isUser ? '(YOU)' : ''}</span>
        </div>
        <div class="dir-status ${p.alive ? 'alive' : 'dead'}">
          ${p.alive ? (p.sleeping ? 'SLEEPING' : 'AWAKE') : 'ELIMINATED'}
        </div>
      </div>
    `).join('');
  }

  openRuleFlyout(ruleKey) {
    const rulesArchive = {
      'win-conditions': {
        icon: '🎯', title: 'WIN CONDITIONS',
        bullets: [
          '<strong>CIVILIAN WIN:</strong> Civilians win as soon as the Imposter is voted out during daytime voting!',
          '<strong>IMPOSTER WIN:</strong> The Imposter wins if they eliminate Civilians until numbers are equal.',
          '<strong>ROLE REVEAL:</strong> When eliminated (night attack or daytime vote), true roles are revealed!'
        ]
      },
      'role-mafia': {
        icon: '⚠️', title: 'IMPOSTER (1 Player)',
        bullets: [
          '<strong>COUNT:</strong> Exactly <span class="flyout-highlight-magenta">1 Imposter</span> is hiding in town.',
          '<strong>NIGHT ATTACK:</strong> Wakes up first at night to secretly eliminate 1 player.',
          '<strong>BLUFF:</strong> Act innocent in daytime chat so players don\'t vote you out!',
          '<strong>MEDIC SAVE:</strong> If Medic heals your target, your attack is blocked and nobody dies!'
        ]
      },
      'role-doctor': {
        icon: '🛡️', title: 'MEDIC (1 Player)',
        bullets: [
          '<strong>COUNT:</strong> Exactly <span class="flyout-highlight-green">1 Medic</span> protects the town.',
          '<strong>NIGHT PROTECTION:</strong> Wakes up after Imposter. Protects 1 player each night (can protect yourself).',
          '<strong>SUCCESSFUL SAVE:</strong> If you protect the attacked player, they survive!'
        ]
      },
      'role-wizard': {
        icon: '🔍', title: 'POLICE (1 Player)',
        bullets: [
          '<strong>COUNT:</strong> Exactly <span class="flyout-highlight-purple">1 Police</span> officer investigates.',
          '<strong>NIGHT INVESTIGATION:</strong> Wakes up after Medic to check 1 suspect.',
          '<strong>CLUE:</strong> Secretly learns if that player is the <span class="flyout-highlight-magenta">IMPOSTER</span> or an innocent <span class="flyout-highlight-green">CIVILIAN</span>.',
          '<strong>GUIDE THE TOWN:</strong> Use your clues in voting to help the town vote out the Imposter!'
        ]
      },
      'role-civilian': {
        icon: '📋', title: 'CIVILIANS (7 Players)',
        bullets: [
          '<strong>COUNT:</strong> Exactly <span class="flyout-highlight">7 innocent Civilians</span> form the town majority.',
          '<strong>SLEEP AT NIGHT:</strong> Sleep peacefully through the night without secret actions.',
          '<strong>DAYTIME VOTING:</strong> Discuss clues in chat and vote to eliminate suspects.',
          '<strong>MAJORITY RULE:</strong> Whoever gets the most votes is eliminated.'
        ]
      },
      'cycle-sequence': {
        icon: '⏱️', title: 'HOW TURNS WORK',
        bullets: [
          '<strong>1. NIGHT FALLS:</strong> Everyone goes to sleep.',
          '<strong>2. IMPOSTER:</strong> Wakes up secretly and picks someone to eliminate.',
          '<strong>3. MEDIC:</strong> Wakes up secretly and picks someone to protect.',
          '<strong>4. POLICE:</strong> Wakes up secretly and checks one suspect.',
          '<strong>5. MORNING:</strong> Everyone wakes up! Night results revealed.',
          '<strong>6. VOTING:</strong> Discuss clues and vote to eliminate a suspect.'
        ]
      }
    };

    const data = rulesArchive[ruleKey];
    if (!data || !this.dom.ruleFlyoutBackdrop) return;
    if (this.dom.flyoutIcon) this.dom.flyoutIcon.textContent = data.icon;
    if (this.dom.flyoutTitle) this.dom.flyoutTitle.textContent = data.title;
    if (this.dom.flyoutBody) {
      this.dom.flyoutBody.innerHTML = data.bullets.map(b => `
        <div class="flyout-bullet">
          <span class="flyout-bullet-dot">◈</span>
          <div class="flyout-bullet-text">${b}</div>
        </div>
      `).join('');
    }
    this.dom.ruleFlyoutBackdrop.style.display = 'flex';
    if (this.dom.ruleFlyoutCard) this.dom.ruleFlyoutCard.classList.remove('fly-out');
    window.soundEngine.playCardFlip();
  }

  closeRuleFlyout() {
    if (!this.dom.ruleFlyoutCard) return;
    this.dom.ruleFlyoutCard.classList.add('fly-out');
    window.soundEngine.playCardFlip();
    setTimeout(() => {
      if (this.dom.ruleFlyoutBackdrop) this.dom.ruleFlyoutBackdrop.style.display = 'none';
    }, 200);
  }

  renderCards() {
    if (!this.dom.cardTableGrid) return;
    this.dom.cardTableGrid.innerHTML = '';
    const user = this.players[0];

    this.players.forEach(p => {
      const card = document.createElement('div');
      card.className = `cyber-card is-${p.role}`;
      card.setAttribute('data-id', p.id);
      if (p.isUser) card.classList.add('flipped');

      let statusBadgeText = 'SLEEPING';
      let statusBadgeClass = 'sleeping';
      if (!p.alive) {
        statusBadgeText = 'ELIMINATED';
        statusBadgeClass = 'dead';
      } else if (!p.sleeping) {
        statusBadgeText = 'AWAKE';
        statusBadgeClass = 'awake';
      }

      const roleDisplayNames = {
        'mafia': 'IMPOSTER',
        'doctor': 'MEDIC',
        'wizard': 'POLICE',
        'civilian': 'CIVILIAN'
      };

      let frontRoleBadge = '';
      if (p.isUser || !p.alive || (user.role === 'mafia' && p.role === 'mafia')) {
        frontRoleBadge = `<div class="role-flat-label ${p.role}">${roleDisplayNames[p.role]}</div>`;
      }

      card.innerHTML = `
        <div class="card-face card-back">
          <div class="card-top-tag">
            <span class="unit-id">#${p.id < 9 ? '0' + (p.id + 1) : p.id + 1}</span>
            <span class="card-status-badge ${statusBadgeClass}">${statusBadgeText}</span>
          </div>
          <div class="astronaut-frame">
            ${this.getOperativeSvg(p)}
          </div>
          <div class="card-center-cyber">
            <div class="cyber-unit-handle">${p.name}${p.isUser ? ' <span class="you-pill-cyber">YOU</span>' : ''}</div>
            <div class="cyber-class-tag">${p.color.name}</div>
          </div>
          <div class="card-bottom-telemetry">
            <span class="telemetry-votes" data-votes-id="${p.id}">
              <span class="vote-dots-row"></span>
            </span>
          </div>
          ${!p.alive ? '<div class="eliminated-stamp">ELIMINATED</div>' : ''}
        </div>
        <div class="card-face card-front">
          <div class="card-top-tag">
            <span class="unit-id">#${p.id < 9 ? '0' + (p.id + 1) : p.id + 1}</span>
            <span class="card-status-badge ${statusBadgeClass}">${statusBadgeText}</span>
          </div>
          <div class="astronaut-frame">
            ${this.getOperativeSvg(p)}
          </div>
          <div class="card-center-cyber">
            ${frontRoleBadge}
            <div class="cyber-unit-handle">${p.name}${p.isUser ? ' <span class="you-pill-cyber">YOU</span>' : ''}</div>
            <div class="cyber-class-tag">${p.color.name}</div>
          </div>
          <div class="card-bottom-telemetry">
            <span class="telemetry-votes" data-votes-id="${p.id}">
              <span class="vote-dots-row"></span>
            </span>
          </div>
          ${!p.alive ? '<div class="eliminated-stamp">ELIMINATED</div>' : ''}
        </div>
      `;

      card.addEventListener('click', () => this.handleCardClick(p.id));
      this.dom.cardTableGrid.appendChild(card);
    });

    this.updateAliveCount();
    this.updatePlayersDirectory();
  }

  setPhase(name, badgeText) {
    this.phase = name;
    if (this.dom.phaseBadge) this.dom.phaseBadge.textContent = badgeText || name;
    this.updateChatLockState();
  }

  systemDirect(text) {
    if (this.dom.dockInstruction) this.dom.dockInstruction.textContent = text;
  }

  clearDirectiveTimer() {
    if (this.currentDirectiveTimer) {
      clearTimeout(this.currentDirectiveTimer);
      this.currentDirectiveTimer = null;
    }
  }

  // ========================================================
  // NIGHT SEQUENCE: STRICTLY NO BOT REVELATION!
  // Neither Doctor nor Police bot card ever switches to AWAKE!
  // ========================================================
  stepNightFalls() {
    this.setPhase('NIGHT', 'NIGHT 01');
    this.systemDirect('Night falls. Everyone goes to sleep.');
    window.soundEngine.playNightBell();
    // Everyone sleeps
    this.players.forEach(p => { if (p.alive) p.sleeping = true; });
    this.renderCards();
    this.clearDirectiveTimer();
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 800 : 2000;
    this.currentDirectiveTimer = setTimeout(() => this.stepMafiaWake(), waitMs);
  }

  stepMafiaWake() {
    const user = this.players[0];
    const isUserMafia = (user.role === 'mafia' && user.alive);

    if (isUserMafia) {
      user.sleeping = false;
      this.setPhase('MAFIA_WAKE', 'IMPOSTER');
      this.systemDirect('You are the Imposter. Pick a player to eliminate.');
      this.renderCards();
      this.highlightSelectableTargets(p => p.alive && p.id !== user.id);
      this.renderDockActions([
        { id: 'btn-confirm-kill', label: 'CONFIRM ATTACK', onClick: () => this.confirmMafiaKill() }
      ]);
    } else {
      // User is innocent: do NOT reveal who wakes up! All bots stay SLEEPING!
      this.setPhase('NIGHT', 'NIGHT 01');
      this.systemDirect('The town sleeps in darkness. Secret actions underway...');
      // Ensure all bots stay visually sleeping
      this.players.forEach(p => { if (p.alive) p.sleeping = true; });
      this.renderCards();
      const livingMafias = this.players.filter(p => p.role === 'mafia' && p.alive);
      const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 600 : 2000;
      this.currentDirectiveTimer = setTimeout(() => {
        this.executeAIMafiaTurn(livingMafias);
        this.stepMafiaSleep();
      }, waitMs);
    }
  }

  confirmMafiaKill() {
    if (this.selectedTargetId === null) return;
    this.nightVictimId = this.selectedTargetId;
    window.soundEngine.playKill();
    this.triggerScreenShake();
    this.clearSelectableTargets();
    this.clearDockActions();
    this.stepMafiaSleep();
  }

  executeAIMafiaTurn(mafias) {
    const targets = this.players.filter(p => p.alive && p.role !== 'mafia');
    if (targets.length === 0) { this.nightVictimId = null; return; }
    const wizardTarget = targets.find(p => p.role === 'wizard');
    let chosen = targets[Math.floor(Math.random() * targets.length)];
    if (wizardTarget && Math.random() < 0.45) chosen = wizardTarget;
    this.nightVictimId = chosen.id;
  }

  stepMafiaSleep() {
    // Put user back to sleep
    const user = this.players[0];
    if (user && user.alive) user.sleeping = true;
    this.renderCards();
    this.clearDirectiveTimer();
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 500 : 1200;
    this.currentDirectiveTimer = setTimeout(() => this.stepDoctorWake(), waitMs);
  }

  stepDoctorWake() {
    const user = this.players[0];
    const isUserDoctor = (user.role === 'doctor' && user.alive);
    const doctor = this.players.find(p => p.role === 'doctor' && p.alive);

    if (isUserDoctor) {
      user.sleeping = false;
      this.setPhase('DOCTOR_WAKE', 'MEDIC');
      this.systemDirect('You are the Medic. Pick a player to protect tonight.');
      this.renderCards();
      this.highlightSelectableTargets(p => p.alive);
      this.renderDockActions([
        { id: 'btn-confirm-heal', label: 'PROTECT PLAYER', onClick: () => this.confirmDoctorHeal() }
      ]);
    } else {
      // User is not doctor: do NOT reveal who doctor is! Keep every bot SLEEPING!
      this.setPhase('NIGHT', 'NIGHT 01');
      this.systemDirect('The town sleeps quietly through the night...');
      this.players.forEach(p => { if (p.alive) p.sleeping = true; });
      this.renderCards();
      const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 600 : 2000;
      this.currentDirectiveTimer = setTimeout(() => {
        if (doctor) this.executeAIDoctorTurn(doctor);
        this.stepDoctorSleep();
      }, waitMs);
    }
  }

  confirmDoctorHeal() {
    if (this.selectedTargetId === null) return;
    this.doctorSavedId = this.selectedTargetId;
    window.soundEngine.playHeal();
    this.clearSelectableTargets();
    this.clearDockActions();
    this.stepDoctorSleep();
  }

  executeAIDoctorTurn(doctor) {
    const candidates = this.players.filter(p => p.alive);
    if (candidates.length === 0) return;
    const chosen = candidates[Math.floor(Math.random() * candidates.length)];
    this.doctorSavedId = chosen.id;
  }

  stepDoctorSleep() {
    const user = this.players[0];
    if (user && user.alive) user.sleeping = true;
    this.renderCards();
    this.clearDirectiveTimer();
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 500 : 1200;
    this.currentDirectiveTimer = setTimeout(() => this.stepWizardWake(), waitMs);
  }

  stepWizardWake() {
    const user = this.players[0];
    const isUserWizard = (user.role === 'wizard' && user.alive);
    const wizard = this.players.find(p => p.role === 'wizard' && p.alive);

    if (isUserWizard) {
      user.sleeping = false;
      this.setPhase('WIZARD_WAKE', 'POLICE');
      this.systemDirect('You are Police. Pick a suspect to investigate.');
      this.renderCards();
      this.highlightSelectableTargets(p => p.alive && p.id !== user.id);
      this.renderDockActions([
        { id: 'btn-confirm-divine', label: 'INVESTIGATE', onClick: () => this.confirmWizardDivination() }
      ]);
    } else {
      // User is not police: do NOT reveal who police is! Keep every bot SLEEPING!
      this.setPhase('NIGHT', 'NIGHT 01');
      this.systemDirect('Shadows move through the silent streets...');
      this.players.forEach(p => { if (p.alive) p.sleeping = true; });
      this.renderCards();
      const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 600 : 2000;
      this.currentDirectiveTimer = setTimeout(() => {
        if (wizard) this.executeAIWizardTurn(wizard);
        this.stepWizardSleep();
      }, waitMs);
    }
  }

  confirmWizardDivination() {
    if (this.selectedTargetId === null) return;
    const target = this.players.find(p => p.id === this.selectedTargetId);
    window.soundEngine.playMagic();
    this.clearSelectableTargets();
    this.clearDockActions();
    const isMafia = (target.role === 'mafia');
    if (this.dom.divinationResultText) {
      this.dom.divinationResultText.textContent = `${target.name} is ${isMafia ? '⚠️ THE IMPOSTER!' : '🛡️ an innocent Civilian.'}`;
      this.dom.divinationResultText.className = `divination-result-text ${isMafia ? 'is-mafia' : 'is-innocent'}`;
    }
    this.showModal('modal-divination');
  }

  executeAIWizardTurn(wizard) {
    const pool = this.players.filter(p => p.alive && p.id !== wizard.id && !this.wizardKnownMafia.includes(p.id));
    if (pool.length > 0) {
      const chosen = pool[Math.floor(Math.random() * pool.length)];
      this.wizardCheckedId = chosen.id;
      if (chosen.role === 'mafia') this.wizardKnownMafia.push(chosen.id);
    }
  }

  stepWizardSleep() {
    const user = this.players[0];
    if (user && user.alive) user.sleeping = true;
    this.renderCards();
    this.clearDirectiveTimer();
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 500 : 1000;
    this.currentDirectiveTimer = setTimeout(() => this.stepDawnWakeAll(), waitMs);
  }

  stepDawnWakeAll() {
    this.setPhase('DAWN', 'MORNING');
    this.systemDirect('Morning arrives! Everyone wakes up.');
    window.soundEngine.playDayDawn();
    // In morning, all alive players wake up together
    this.players.forEach(p => { if (p.alive) p.sleeping = false; });
    this.renderCards();
    this.clearDirectiveTimer();
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 800 : 2000;
    this.currentDirectiveTimer = setTimeout(() => this.announceNightOutcome(), waitMs);
  }

  announceNightOutcome() {
    const victim = this.players.find(p => p.id === this.nightVictimId);
    const saved = (this.nightVictimId !== null && this.nightVictimId === this.doctorSavedId);

    if (victim && saved) {
      this.systemDirect(`Medic saved ${victim.name}! Nobody died tonight.`);
      this.addLiveLog(`Medic saved ${victim.name} from attack!`, 'saved');
      this.addChronicleEntry(`Night ${this.round}: Imposter attacked ${victim.name}, but Medic saved them.`);
      window.soundEngine.playHeal();
    } else if (victim && !saved) {
      victim.alive = false;
      victim.eliminatedRound = this.round;
      this.systemDirect(`${victim.name} was eliminated! Role: ${victim.role.toUpperCase()}`);
      this.addLiveLog(`${victim.name} was eliminated. Role: ${victim.role.toUpperCase()}`, 'death');
      this.addChronicleEntry(`Night ${this.round}: ${victim.name} was eliminated (${victim.role.toUpperCase()}).`);
      window.soundEngine.playKill();
      this.triggerScreenShake();
      const card = document.querySelector(`.cyber-card[data-id="${victim.id}"]`);
      if (card) card.classList.add('flipped');
    } else {
      this.systemDirect('A quiet night. Nobody was eliminated.');
      this.addLiveLog('A quiet night. Nobody died.', 'system');
      this.addChronicleEntry(`Night ${this.round}: A quiet night, nobody died.`);
    }

    this.renderCards();
    this.updateAliveCount();
    this.updatePlayersDirectory();
    this.nightVictimId = null;
    this.doctorSavedId = null;

    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 1000 : 2500;
    this.currentDirectiveTimer = setTimeout(() => this.checkWinOrProceedDay(), waitMs);
  }

  checkWinOrProceedDay() {
    const outcome = this.checkWinCondition();
    if (outcome) {
      this.endGame(outcome);
    } else {
      this.stepDayDeliberation();
    }
  }

  stepDayDeliberation() {
    this.setPhase('VOTING', 'VOTING');
    this.systemDirect('Voting time! Discuss clues and vote out the Imposter.');
    window.soundEngine.playEmergencySiren();
    if (this.dom.emergencyAlert) {
      this.dom.emergencyAlert.style.display = 'flex';
      setTimeout(() => { if (this.dom.emergencyAlert) this.dom.emergencyAlert.style.display = 'none'; }, 1600);
    }
    this.generateTownBanter();
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 600 : 1500;
    this.currentDirectiveTimer = setTimeout(() => this.startVotingPhase(), waitMs);
  }

  generateTownBanter() {
    const wizard = this.players.find(p => p.role === 'wizard');
    if (wizard && !wizard.isUser && this.wizardKnownMafia.length > 0) {
      const mafiaPlayer = this.players.find(p => p.id === this.wizardKnownMafia[0]);
      if (mafiaPlayer) {
        setTimeout(() => {
          if (!wizard.alive) return;
          this.addChat('bot', `I have evidence against ${mafiaPlayer.name}!`, wizard.name);
          this.showReactionBubble(wizard.id, '🚩 SUSPECT');
        }, 800);
      }
    }

    const livingBots = this.players.filter(p => !p.isUser && p.alive);
    if (livingBots.length >= 2) {
      const bot1 = livingBots[0];
      const bot2 = livingBots[1];
      setTimeout(() => {
        if (!bot1.alive) return;
        const suspects = this.players.filter(p => p.alive && p.id !== bot1.id);
        if (suspects.length === 0) return;
        const target = suspects[Math.floor(Math.random() * suspects.length)];
        this.addChat('bot', `I suspect ${target.name}.`, bot1.name);
        this.showReactionBubble(bot1.id, '❓');
      }, 1400);

      setTimeout(() => {
        if (!bot2.alive) return;
        this.addChat('bot', 'Let us review alibis carefully.', bot2.name);
      }, 2400);
    }
  }

  startVotingPhase() {
    this.votes = {};
    const userIsAlive = this.players[0] && this.players[0].alive;
    if (userIsAlive) {
      this.systemDirect('Tap a suspect card to cast your vote.');
      this.highlightSelectableTargets(p => p.alive && p.id !== 0);
      this.renderDockActions([
        { id: 'btn-cast-vote', label: 'VOTE SUSPECT', onClick: () => this.confirmUserVote() },
        { id: 'btn-skip-vote', label: 'SKIP VOTE', className: 'dock-action-btn btn-sm-skip', onClick: () => this.skipUserVote() }
      ]);
    } else {
      this.systemDirect('You are eliminated. Watching town vote...');
      this.clearDockActions();
      const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 600 : 1200;
      setTimeout(() => this.simulateAIVotes(), waitMs);
    }
  }

  confirmUserVote() {
    if (this.selectedTargetId === null) return;
    this.castVote(0, this.selectedTargetId);
    this.clearSelectableTargets();
    this.clearDockActions();
    this.systemDirect('Vote cast. Waiting for other players...');
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 300 : 500;
    setTimeout(() => this.simulateAIVotes(), waitMs);
  }

  skipUserVote() {
    this.clearSelectableTargets();
    this.clearDockActions();
    this.systemDirect('You skipped your vote. Waiting for others...');
    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 300 : 500;
    setTimeout(() => this.simulateAIVotes(), waitMs);
  }

  castVote(voterId, targetId) {
    if (targetId === null) return;
    const voter = this.players.find(p => p.id === voterId);
    const target = this.players.find(p => p.id === targetId);
    if (!voter || !target) return;
    this.votes[targetId] = (this.votes[targetId] || 0) + 1;
    target.votesReceived = this.votes[targetId];
    this.updateCardVotesDisplay(targetId, target.votesReceived);
    window.soundEngine.playGavel();
  }

  updateCardVotesDisplay(playerId, count) {
    const el = document.querySelector(`.telemetry-votes[data-votes-id="${playerId}"] .vote-dots-row`);
    if (el) {
      el.innerHTML = Array(count).fill('<span class="vote-dot">●</span>').join('');
    }
  }

  simulateAIVotes() {
    const livingBots = this.players.filter(p => !p.isUser && p.alive);
    livingBots.forEach((bot, index) => {
      const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? index * 120 : index * 400;
      setTimeout(() => {
        if (!bot.alive) return;
        const targetId = this.chooseAIVoteTarget(bot);
        if (targetId !== null) this.castVote(bot.id, targetId);
        if (index === livingBots.length - 1) {
          const tallyWait = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 400 : 800;
          setTimeout(() => this.tallyVotesAndExecute(), tallyWait);
        }
      }, waitMs);
    });

    if (livingBots.length === 0) {
      setTimeout(() => this.tallyVotesAndExecute(), 600);
    }
  }

  chooseAIVoteTarget(voter) {
    const candidates = this.players.filter(p => p.alive && p.id !== voter.id);
    if (candidates.length === 0) return null;
    if (voter.role === 'wizard' && this.wizardKnownMafia.length > 0) {
      const known = candidates.find(p => p.id === this.wizardKnownMafia[0]);
      if (known) return known.id;
    }
    if (voter.role === 'mafia') {
      const innocents = candidates.filter(p => p.role !== 'mafia');
      if (innocents.length > 0) {
        return innocents[Math.floor(Math.random() * innocents.length)].id;
      }
    }
    if (this.wizardKnownMafia.length > 0 && Math.random() < 0.65) {
      const knownMafia = candidates.find(p => p.id === this.wizardKnownMafia[0]);
      if (knownMafia) return knownMafia.id;
    }
    if (Math.random() < 0.25) return null;
    return candidates[Math.floor(Math.random() * candidates.length)].id;
  }

  tallyVotesAndExecute() {
    let maxVotes = 0;
    let accusedId = null;
    let isTie = false;

    for (const [idStr, count] of Object.entries(this.votes)) {
      const id = parseInt(idStr, 10);
      if (count > maxVotes) {
        maxVotes = count;
        accusedId = id;
        isTie = false;
      } else if (count === maxVotes && maxVotes > 0) {
        isTie = true;
      }
    }

    if (accusedId === null || maxVotes === 0 || isTie) {
      this.systemDirect(isTie ? 'Tie vote! Nobody was eliminated today.' : 'No consensus reached. Nobody was eliminated.');
      this.addLiveLog(isTie ? 'Voting resulted in a tie. No exile.' : 'Town voted to skip elimination.', 'vote');
      this.addChronicleEntry(`Day ${this.round}: No player eliminated (${isTie ? 'Tie' : 'Skipped'}).`);
    } else {
      const accused = this.players.find(p => p.id === accusedId);
      accused.alive = false;
      accused.eliminatedRound = this.round;
      this.systemDirect(`${accused.name} was voted out! Role: ${accused.role.toUpperCase()}`);
      this.addLiveLog(`${accused.name} was voted out (${maxVotes} votes). Role: ${accused.role.toUpperCase()}`, 'vote');
      this.addChronicleEntry(`Day ${this.round}: ${accused.name} was voted out with ${maxVotes} votes (${accused.role.toUpperCase()}).`);
      window.soundEngine.playGavel();
      this.triggerScreenShake();
      const card = document.querySelector(`.cyber-card[data-id="${accused.id}"]`);
      if (card) card.classList.add('flipped');
    }

    this.renderCards();
    this.updateAliveCount();
    this.updatePlayersDirectory();

    const waitMs = (this.dom.fastModeToggle && this.dom.fastModeToggle.checked) ? 1200 : 2500;
    setTimeout(() => {
      const win = this.checkWinCondition();
      if (win) this.endGame(win);
      else this.advanceToNextRound();
    }, waitMs);
  }

  advanceToNextRound() {
    this.round++;
    if (this.dom.roundNumber) this.dom.roundNumber.textContent = this.round < 10 ? `0${this.round}` : this.round;
    setTimeout(() => this.stepNightFalls(), 800);
  }

  checkWinCondition() {
    const livingMafia = this.players.filter(p => p.role === 'mafia' && p.alive);
    const livingInnocents = this.players.filter(p => p.role !== 'mafia' && p.alive);

    if (livingMafia.length === 0) {
      return { winner: 'civilian', title: 'CIVILIAN VICTORY', desc: 'The Imposter has been voted out! Town is safe.' };
    }
    if (livingMafia.length >= livingInnocents.length) {
      return { winner: 'mafia', title: 'IMPOSTER VICTORY', desc: 'The Imposter has overrun the town!' };
    }
    return null;
  }

  endGame(outcome) {
    this.setPhase('GAME_OVER', 'FINISHED');
    this.clearDirectiveTimer();
    this.players.forEach(p => {
      const cardEl = document.querySelector(`.cyber-card[data-id="${p.id}"]`);
      if (cardEl) cardEl.classList.add('flipped');
    });

    const user = this.players[0];
    const userWon = (user.role === 'mafia' && outcome.winner === 'mafia') || (user.role !== 'mafia' && outcome.winner === 'civilian');

    if (userWon) {
      this.winStreak++;
      localStorage.setItem('mm_win_streak', this.winStreak.toString());
      window.soundEngine.playVictory();
    } else {
      this.winStreak = 0;
      localStorage.setItem('mm_win_streak', '0');
      window.soundEngine.playDefeat();
    }

    this.addLiveLog(`Game Over: ${outcome.title}. ${outcome.desc}`, 'system');
    this.addChronicleEntry(`GAME OVER: ${outcome.title}.`);
    setTimeout(() => this.showGameOverModal(outcome), 1000);
  }

  showGameOverModal(outcome) {
    this.showScreen('game-over-screen');
    this.dom.outcomeIcon.textContent = outcome.winner === 'civilian' ? '🏆' : '⚠️';
    this.dom.outcomeTitle.textContent = outcome.title;
    this.dom.outcomeTitle.style.color = outcome.winner === 'civilian' ? 'var(--accent-police-blue)' : 'var(--accent-crimson)';
    this.dom.outcomeDesc.textContent = outcome.desc;
    if (this.dom.streakCountVal) this.dom.streakCountVal.textContent = this.winStreak;

    if (this.dom.finalRosterSummary) {
      this.dom.finalRosterSummary.innerHTML = this.players.map(p => `
        <div class="final-item-cyber">
          <strong style="color: ${p.color.hex}">${p.name}</strong>
          <span style="font-size: 0.65rem; color: var(--text-secondary)">${p.role.toUpperCase()} ${p.alive ? '✓' : '✗'}</span>
        </div>
      `).join('');
    }
  }

  renderChronicle() {
    if (!this.dom.chronicleTimeline) return;
    this.dom.chronicleTimeline.innerHTML = this.chronicle.map(entry => `
      <div class="chronicle-event" style="padding: 6px 0; border-bottom: 1px solid var(--hairline-border); font-size: 0.75rem;">
        <span style="color: var(--accent-gold); font-family: var(--font-mono); font-weight: 700;">[LOG]</span> ${entry}
      </div>
    `).join('');
  }

  addChronicleEntry(text) {
    this.chronicle.push(text);
  }

  addChat(type, msg, author = '') {
    if (type === 'system' || type === 'death' || type === 'saved') return;
    if (author) {
      const authorPlayer = this.players.find(p => p.name === author);
      if (authorPlayer && !authorPlayer.alive) return;
    }
    if (!this.dom.chatContainer) return;
    const authorPlayer = author ? this.players.find(p => p.name === author) : null;
    const colorHex = authorPlayer ? authorPlayer.color.hex : 'var(--accent-police-blue)';
    const div = document.createElement('div');
    div.className = `chat-msg chat-${type}`;
    div.innerHTML = `
      <div class="chat-msg-author">
        <span class="author-color" style="background: ${colorHex}"></span>
        <span>${author || 'TOWN'}</span>
      </div>
      <div class="chat-msg-bubble">${msg}</div>
    `;
    this.dom.chatContainer.appendChild(div);
    this.dom.chatContainer.scrollTop = this.dom.chatContainer.scrollHeight;
  }

  highlightSelectableTargets(predicate) {
    this.clearSelectableTargets();
    this.players.forEach(p => {
      if (predicate(p)) {
        const card = document.querySelector(`.cyber-card[data-id="${p.id}"]`);
        if (card) card.classList.add('selectable');
      }
    });
  }

  clearSelectableTargets() {
    document.querySelectorAll('.cyber-card.selectable').forEach(el => el.classList.remove('selectable'));
    document.querySelectorAll('.cyber-card.selected').forEach(el => el.classList.remove('selected'));
    this.selectedTargetId = null;
  }

  handleCardClick(playerId) {
    const card = document.querySelector(`.cyber-card[data-id="${playerId}"]`);
    if (!card || !card.classList.contains('selectable')) return;
    document.querySelectorAll('.cyber-card.selected').forEach(el => el.classList.remove('selected'));
    card.classList.add('selected');
    this.selectedTargetId = playerId;
    window.soundEngine.playCardFlip();
  }

  renderDockActions(actions) {
    if (!this.dom.dockActionButtons) return;
    this.dom.dockActionButtons.innerHTML = '';
    actions.forEach(act => {
      const btn = document.createElement('button');
      btn.id = act.id;
      btn.className = act.className || 'dock-action-btn';
      btn.textContent = act.label;
      btn.addEventListener('click', act.onClick);
      this.dom.dockActionButtons.appendChild(btn);
    });
  }

  clearDockActions() {
    if (this.dom.dockActionButtons) this.dom.dockActionButtons.innerHTML = '';
  }
}

document.addEventListener('DOMContentLoaded', () => {
  window.mafiaGame = new MafiaGame();
});
