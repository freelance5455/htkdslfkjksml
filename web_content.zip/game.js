const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");
const menu=document.getElementById("menu"), game=document.getElementById("game");
let W=innerWidth,H=innerHeight,dpr=Math.min(devicePixelRatio||1,2);
function resize(){W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;canvas.style.width=W+"px";canvas.style.height=H+"px";ctx.setTransform(dpr,0,0,dpr,0,0)}
addEventListener("resize",resize);resize();

const world={w:2400,h:1800};
const roads=[
 {x:0,y:700,w:2400,h:180},{x:0,y:1050,w:2400,h:150},
 {x:500,y:0,w:180,h:1800},{x:1350,y:0,w:180,h:1800}
];
const buildings=[];
for(let x=40;x<2300;x+=230){
  for(let y=40;y<650;y+=190) buildings.push({x,y,w:155,h:110});
}
for(let x=40;x<2300;x+=230){
  for(let y=1230;y<1700;y+=190) buildings.push({x,y,w:155,h:110});
}
const parks=[{x:820,y:70,w:430,h:420},{x:1650,y:800,w:600,h:220}];
const cars=[
 {x:760,y:790,a:0,c:"#e84b4b"},{x:980,y:790,a:0,c:"#42a5f5"},
 {x:1450,y:960,a:Math.PI/2,c:"#ffd34d"},{x:1250,y:1150,a:Math.PI/2,c:"#b26cff"}
];

let me={id:null,x:760,y:790,a:0,hp:100,money:500,car:false};
let others={};
let keys={};
let touch={up:false,down:false,left:false,right:false};
let socket=null,connected=false,lastSend=0;

document.getElementById("startBtn").onclick=()=>{menu.classList.add("hidden");game.classList.remove("hidden");connect();loop()};
addEventListener("keydown",e=>{keys[e.key.toLowerCase()]=true;if(e.code==="Space"){e.preventDefault();toggleCar()}});
addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);

document.querySelectorAll("#touch [data-key]").forEach(b=>{
  const k=b.dataset.key;
  const on=e=>{e.preventDefault();touch[k]=true};
  const off=e=>{e.preventDefault();touch[k]=false};
  b.addEventListener("touchstart",on,{passive:false});b.addEventListener("touchend",off,{passive:false});
  b.addEventListener("mousedown",on);b.addEventListener("mouseup",off);b.addEventListener("mouseleave",off);
});
document.getElementById("carBtn").addEventListener("click",toggleCar);

function toggleCar(){
  if(me.car){me.car=false;return}
  let best=null,dist=9999;
  cars.forEach(c=>{let d=Math.hypot(c.x-me.x,c.y-me.y);if(d<dist){dist=d;best=c}});
  if(best&&dist<80){me.car=true;me.x=best.x;me.y=best.y;me.a=best.a}
}
function input(){
  let x=0,y=0;
  if(keys["w"]||keys["arrowup"]||touch.up)y--;
  if(keys["s"]||keys["arrowdown"]||touch.down)y++;
  if(keys["a"]||keys["arrowleft"]||touch.left)x--;
  if(keys["d"]||keys["arrowright"]||touch.right)x++;
  return {x,y};
}
function blocked(x,y,r=18){
  if(x<r||y<r||x>world.w-r||y>world.h-r)return true;
  for(const b of buildings) if(x+r>b.x&&x-r<b.x+b.w&&y+r>b.y&&y-r<b.y+b.h)return true;
  return false;
}
function update(dt){
  const i=input(); const len=Math.hypot(i.x,i.y)||1;
  const speed=me.car?260:150;
  const nx=me.x+i.x/len*speed*dt,ny=me.y+i.y/len*speed*dt;
  if(!blocked(nx,me.y,me.car?24:16))me.x=nx;
  if(!blocked(me.x,ny,me.car?24:16))me.y=ny;
  if(i.x||i.y)me.a=Math.atan2(i.y,i.x);
}
function send(){
  if(!socket||socket.readyState!==1)return;
  const now=performance.now();if(now-lastSend<50)return;lastSend=now;
  socket.send(JSON.stringify({t:"state",x:me.x,y:me.y,a:me.a,hp:me.hp,car:me.car}));
}
function connect(){
  const proto=location.protocol==="https:"?"wss":"ws";
  socket=new WebSocket(proto+"://"+location.host);
  socket.onopen=()=>{connected=true};
  socket.onclose=()=>{connected=false};
  socket.onmessage=e=>{
    try{const m=JSON.parse(e.data);
      if(m.t==="welcome"){me.id=m.id;document.getElementById("online").textContent=m.count}
      if(m.t==="players"){others=m.players;document.getElementById("online").textContent=Object.keys(others).length+1}
    }catch(_){}
  };
}
function draw(){
  ctx.clearRect(0,0,W,H);
  const scale=Math.min(W/world.w,H/world.h)*1.15;
  const camX=Math.max(0,Math.min(world.w-W/scale,me.x-W/(2*scale)));
  const camY=Math.max(0,Math.min(world.h-H/scale,me.y-H/(2*scale)));
  ctx.save();ctx.scale(scale,scale);ctx.translate(-camX,-camY);
  ctx.fillStyle="#79a85d";ctx.fillRect(0,0,world.w,world.h);
  parks.forEach(p=>{ctx.fillStyle="#5f9853";ctx.fillRect(p.x,p.y,p.w,p.h);for(let x=p.x+30;x<p.x+p.w;x+=65){ctx.fillStyle="#37783c";ctx.beginPath();ctx.arc(x,p.y+70,14,0,7);ctx.fill()}});
  roads.forEach(r=>{ctx.fillStyle="#555b61";ctx.fillRect(r.x,r.y,r.w,r.h);ctx.strokeStyle="#d5c77a";ctx.lineWidth=5;ctx.setLineDash([35,30]);ctx.beginPath();if(r.w>r.h){ctx.moveTo(r.x,r.y+r.h/2);ctx.lineTo(r.x+r.w,r.y+r.h/2)}else{ctx.moveTo(r.x+r.w/2,r.y);ctx.lineTo(r.x+r.w/2,r.y+r.h)}ctx.stroke();ctx.setLineDash([])});
  buildings.forEach(b=>{ctx.fillStyle="#d7d1c6";ctx.fillRect(b.x,b.y,b.w,b.h);ctx.fillStyle="#777";ctx.fillRect(b.x+8,b.y+8,b.w-16,20);ctx.fillStyle="#86b4cc";for(let xx=b.x+18;xx<b.x+b.w-10;xx+=35)for(let yy=b.y+45;yy<b.y+b.h-10;yy+=32)ctx.fillRect(xx,yy,16,13)});
  cars.forEach(c=>drawCar(c.x,c.y,c.a,c.c));
  Object.values(others).forEach(p=>drawPlayer(p.x,p.y,p.a,"#f39c12",p.car,p.id));
  drawPlayer(me.x,me.y,me.a,"#29b6f6",me.car,"TU");
  ctx.restore();
}
function drawCar(x,y,a,c){
  ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle=c;ctx.fillRect(-27,-15,54,30);ctx.fillStyle="#20262b";ctx.fillRect(-15,-11,25,22);ctx.fillStyle="#111";ctx.fillRect(-25,-19,12,5);ctx.fillRect(13,-19,12,5);ctx.fillRect(-25,14,12,5);ctx.fillRect(13,14,12,5);ctx.restore();
}
function drawPlayer(x,y,a,c,car,id){
  if(car){drawCar(x,y,a,c);return}
  ctx.save();ctx.translate(x,y);ctx.fillStyle="#222";ctx.beginPath();ctx.arc(0,0,15,0,7);ctx.fill();ctx.fillStyle=c;ctx.beginPath();ctx.arc(0,-17,9,0,7);ctx.fill();ctx.strokeStyle="#111";ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(0,-2);ctx.lineTo(Math.cos(a)*22,-2+Math.sin(a)*22);ctx.stroke();ctx.restore();
  ctx.font="bold 13px Arial";ctx.textAlign="center";ctx.fillStyle="#fff";ctx.fillText(id||"Jogador",x,y-32);
}
function loop(t=performance.now()){update(Math.min((t-(loop.last||t))/1000,.05));loop.last=t;send();draw();requestAnimationFrame(loop)}
