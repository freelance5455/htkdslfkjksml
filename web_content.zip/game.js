
import * as THREE from "https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js";
import { PointerLockControls } from "https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/controls/PointerLockControls.js";

const WORLD_W = 128;
const WORLD_D = 128;
const WORLD_H = 64;
const SEA = 22;
const CHUNK = 16;
const GRAVITY = 24;
const MOVE_SPEED = 6.3;
const SPRINT_SPEED = 9.0;
const JUMP = 9.2;

const BLOCK = {
  AIR:0, GRASS:1, DIRT:2, STONE:3, SAND:4, WOOD:5, LEAVES:6,
  COAL:7, IRON:8, WATER:9, PLANK:10, GLASS:11, SNOW:12
};
const NAMES = {
  [BLOCK.GRASS]:"Grass", [BLOCK.DIRT]:"Dirt", [BLOCK.STONE]:"Stone",
  [BLOCK.SAND]:"Sand", [BLOCK.WOOD]:"Wood", [BLOCK.LEAVES]:"Leaves",
  [BLOCK.COAL]:"Coal Ore", [BLOCK.IRON]:"Iron Ore", [BLOCK.PLANK]:"Planks",
  [BLOCK.GLASS]:"Glass", [BLOCK.SNOW]:"Snow"
};
const PLACEABLE = [BLOCK.GRASS,BLOCK.DIRT,BLOCK.STONE,BLOCK.SAND,BLOCK.WOOD,BLOCK.PLANK,BLOCK.GLASS,BLOCK.COBBLE||BLOCK.STONE];

const canvasRoot = document.getElementById("game");
const renderer = new THREE.WebGLRenderer({ antialias:true, powerPreference:"high-performance" });
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
canvasRoot.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8ab9dd);
scene.fog = new THREE.Fog(0x8ab9dd, 75, 190);

const camera = new THREE.PerspectiveCamera(72, innerWidth/innerHeight, 0.05, 320);
camera.position.set(WORLD_W/2, 38, WORLD_D/2);

const hemi = new THREE.HemisphereLight(0xcfe9ff,0x3a2a22,1.2);
scene.add(hemi);

const sun = new THREE.DirectionalLight(0xfff0cf, 2.4);
sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left = -90; sun.shadow.camera.right = 90;
sun.shadow.camera.top = 90; sun.shadow.camera.bottom = -90;
sun.shadow.camera.near = 1; sun.shadow.camera.far = 260;
scene.add(sun);
scene.add(sun.target);

const controls = new PointerLockControls(camera, renderer.domElement);
controls.pointerSpeed = 0.85;

const world = new Uint8Array(WORLD_W*WORLD_H*WORLD_D);
const water = new Uint8Array(WORLD_W*WORLD_D);
const chunks = new Map();

let selectedSlot = 0;
const inventory = [
  { id:BLOCK.GRASS, count:64 }, { id:BLOCK.DIRT, count:64 }, { id:BLOCK.STONE, count:64 },
  { id:BLOCK.SAND, count:48 }, { id:BLOCK.WOOD, count:32 }, { id:BLOCK.PLANK, count:64 },
  { id:BLOCK.GLASS, count:32 }, { id:BLOCK.LEAVES, count:16 }, { id:BLOCK.COAL, count:16 }
];

const player = {
  pos: new THREE.Vector3(WORLD_W/2+0.5, 35, WORLD_D/2+0.5),
  vel: new THREE.Vector3(),
  radius: 0.34,
  height: 1.78,
  eye: 1.62,
  grounded:false,
  health:100, hunger:100
};
camera.position.copy(player.pos).add(new THREE.Vector3(0,player.eye,0));

const keys = {};
let pointerLocked = false;
let last = performance.now();
let dayTime = 0.18;
let worldGenerated = false;

const tex = makeAtlasTexture();
const atlas = new THREE.MeshLambertMaterial({ map:tex, vertexColors:true });
const leafMat = new THREE.MeshLambertMaterial({ map:tex, vertexColors:true, transparent:true, alphaTest:.18 });
const waterMat = new THREE.MeshPhongMaterial({
  color:0x4b9fb7, transparent:true, opacity:.63, shininess:90, side:THREE.DoubleSide
});
const glassMat = new THREE.MeshPhongMaterial({ color:0xb8e4ee, transparent:true, opacity:.34, shininess:100, side:THREE.DoubleSide });

const blockHighlight = new THREE.LineSegments(
  new THREE.EdgesGeometry(new THREE.BoxGeometry(1.003,1.003,1.003)),
  new THREE.LineBasicMaterial({color:0xffffff, transparent:true, opacity:.9})
);
blockHighlight.visible = false;
scene.add(blockHighlight);

const clouds = [];
makeClouds();

function index(x,y,z){ return x + WORLD_W*(z + WORLD_D*y); }
function colIndex(x,z){ return x + WORLD_W*z; }
function inBounds(x,y,z){ return x>=0&&z>=0&&x<WORLD_W&&z<WORLD_D&&y>=0&&y<WORLD_H; }
function getBlock(x,y,z){ return inBounds(x,y,z) ? world[index(x,y,z)] : BLOCK.AIR; }
function setBlock(x,y,z,id){
  if(!inBounds(x,y,z)) return;
  world[index(x,y,z)] = id;
  const cx=Math.floor(x/CHUNK), cz=Math.floor(z/CHUNK);
  rebuildChunk(cx,cz);
  if(x%CHUNK===0) rebuildChunk(cx-1,cz);
  if(x%CHUNK===CHUNK-1) rebuildChunk(cx+1,cz);
  if(z%CHUNK===0) rebuildChunk(cx,cz-1);
  if(z%CHUNK===CHUNK-1) rebuildChunk(cx,cz+1);
}

function noise2(x,z){
  const s = Math.sin(x*127.1 + z*311.7)*43758.5453;
  return s-Math.floor(s);
}
function smoothNoise(x,z){
  const ix=Math.floor(x), iz=Math.floor(z);
  const fx=x-ix, fz=z-iz;
  const u=fx*fx*(3-2*fx), v=fz*fz*(3-2*fz);
  const a=noise2(ix,iz), b=noise2(ix+1,iz), c=noise2(ix,iz+1), d=noise2(ix+1,iz+1);
  return THREE.MathUtils.lerp(THREE.MathUtils.lerp(a,b,u),THREE.MathUtils.lerp(c,d,u),v);
}
function fbm(x,z){
  let v=0,a=.5,f=1;
  for(let i=0;i<5;i++){ v+=smoothNoise(x*f,z*f)*a; f*=2; a*=.5; }
  return v;
}
function ridge(x,z){
  let v=0,a=.5,f=1;
  for(let i=0;i<4;i++){ v+=(1-Math.abs(smoothNoise(x*f,z*f)*2-1))*a; f*=2; a*=.5; }
  return v;
}
function heightAt(x,z){
  const large=fbm(x*.012,z*.012);
  const medium=fbm(x*.045+7,z*.045-2);
  const detail=fbm(x*.11-5,z*.11+9);
  const rid=ridge(x*.025,z*.025);
  let h = 17 + large*22 + medium*8 + detail*3 + Math.pow(rid,3)*8;
  const edge=Math.min(x,z,WORLD_W-1-x,WORLD_D-1-z);
  h -= Math.max(0, 6-edge)*2.2;
  return Math.floor(THREE.MathUtils.clamp(h,4,WORLD_H-7));
}

function caveNoise(x,y,z){
  const a=fbm(x*.065+11,z*.065+y*.031);
  const b=fbm(x*.09-7,z*.09+y*.025);
  return a*0.58+b*0.42;
}

function generateWorld(){
  for(let z=0;z<WORLD_D;z++){
    for(let x=0;x<WORLD_W;x++){
      const h=heightAt(x,z);
      const beach=h<=SEA+2;
      for(let y=0;y<=h;y++){
        let id=BLOCK.STONE;
        if(y===h) id=beach?BLOCK.SAND:BLOCK.GRASS;
        else if(y>=h-3) id=beach?BLOCK.SAND:BLOCK.DIRT;
        if(y<5 && Math.random()<.015) id=BLOCK.COAL;
        if(y>6 && y<h-3 && caveNoise(x,y,z)>.73 && y<46) id=BLOCK.AIR;
        if(id!==BLOCK.AIR && y>h-6){
          const r=noise2(x*3+y,z*2+y);
          if(y<h-6 && r>.92) id = y<22 ? BLOCK.COAL : BLOCK.IRON;
        }
        world[index(x,y,z)]=id;
      }
      if(h<SEA){
        for(let y=h+1;y<=SEA;y++) water[colIndex(x,z)]=1;
      }
    }
  }
  // trees on grass plateaus
  for(let z=3;z<WORLD_D-3;z++){
    for(let x=3;x<WORLD_W-3;x++){
      const h=heightAt(x,z);
      if(h<SEA+2 || getBlock(x,h,z)!==BLOCK.GRASS) continue;
      const chance = smoothNoise(x*.23+30,z*.23-13);
      if(chance>.77 && noise2(x+91,z+17)>.24) makeTree(x,h+1,z);
    }
  }
  // distant mountain snow caps
  for(let z=0;z<WORLD_D;z++) for(let x=0;x<WORLD_W;x++){
    const h=heightAt(x,z);
    if(h>48){
      const depth=Math.min(2, h-47);
      for(let y=h;y>h-depth;y--) if(getBlock(x,y,z)===BLOCK.GRASS) world[index(x,y,z)]=BLOCK.SNOW;
    }
  }
  worldGenerated=true;
  buildAllChunks();
}

function makeTree(x,y,z){
  const tall=4+Math.floor(noise2(x*5,z*9)*3);
  for(let i=0;i<tall;i++) if(inBounds(x,y+i,z)) world[index(x,y+i,z)]=BLOCK.WOOD;
  const top=y+tall-1;
  for(let dy=-2;dy<=2;dy++){
    for(let dx=-2;dx<=2;dx++) for(let dz=-2;dz<=2;dz++){
      const man=Math.abs(dx)+Math.abs(dz)+Math.abs(dy);
      if(man<=4 && inBounds(x+dx,top+dy,z+dz) && getBlock(x+dx,top+dy,z+dz)===BLOCK.AIR)
        world[index(x+dx,top+dy,z+dz)]=BLOCK.LEAVES;
    }
  }
}

function buildAllChunks(){
  for(let cz=0;cz<Math.ceil(WORLD_D/CHUNK);cz++)
    for(let cx=0;cx<Math.ceil(WORLD_W/CHUNK);cx++) rebuildChunk(cx,cz);
}

function rebuildChunk(cx,cz){
  if(cx<0||cz<0||cx>=Math.ceil(WORLD_W/CHUNK)||cz>=Math.ceil(WORLD_D/CHUNK)) return;
  const key=cx+","+cz;
  const old=chunks.get(key);
  if(old){ scene.remove(old); old.traverse(o=>{ if(o.geometry) o.geometry.dispose(); }); }
  const group=new THREE.Group();

  const p=[], n=[], u=[], c=[];
  const wp=[], wn=[], wc=[];
  const face=[
    [[0,0,1],[0,0,1],[0,0,1, 1,0,1, 1,1,1, 0,1,1]],
    [[0,0,-1],[0,0,-1],[1,0,0, 0,0,0, 0,1,0, 1,1,0]],
    [[1,0,0],[1,0,0],[1,0,1, 1,0,0, 1,1,0, 1,1,1]],
    [[-1,0,0],[-1,0,0],[0,0,0, 0,0,1, 0,1,1, 0,1,0]],
    [[0,1,0],[0,1,0],[0,1,0, 0,1,1, 1,1,1, 1,1,0]],
    [[0,-1,0],[0,-1,0],[0,0,1, 0,0,0, 1,0,0, 1,0,1]]
  ];
  const tris=[0,1,2,0,2,3];
  for(let z=cz*CHUNK;z<Math.min((cz+1)*CHUNK,WORLD_D);z++){
    for(let x=cx*CHUNK;x<Math.min((cx+1)*CHUNK,WORLD_W);x++){
      for(let y=0;y<WORLD_H;y++){
        const id=getBlock(x,y,z);
        if(id===BLOCK.AIR||id===BLOCK.WATER) continue;
        for(let f=0;f<6;f++){
          const [dir,nrm,arr]=face[f], nx=x+dir[0], ny=y+dir[1], nz=z+dir[2];
          const neighbor=getBlock(nx,ny,nz);
          const exposed = neighbor===BLOCK.AIR || neighbor===BLOCK.WATER || neighbor===BLOCK.LEAVES;
          if(!exposed) continue;
          const base=p.length/3;
          const coords=[
            [arr[0],arr[1],arr[2]],[arr[3],arr[4],arr[5]],[arr[6],arr[7],arr[8]],[arr[9],arr[10],arr[11]]
          ];
          const uv=getUV(id,f);
          for(const cc of coords){ p.push(x+cc[0],y+cc[1],z+cc[2]); n.push(...nrm); }
          for(const t of tris) u.push(uv[t*2],uv[t*2+1]);
          const tint=faceTint(id,f);
          for(let i=0;i<4;i++) c.push(tint.r,tint.g,tint.b);
        }
      }
    }
  }
  if(p.length){
    const geom=new THREE.BufferGeometry();
    geom.setAttribute("position",new THREE.Float32BufferAttribute(p,3));
    geom.setAttribute("normal",new THREE.Float32BufferAttribute(n,3));
    geom.setAttribute("uv",new THREE.Float32BufferAttribute(u,2));
    geom.setAttribute("color",new THREE.Float32BufferAttribute(c,3));
    geom.computeBoundingSphere();
    const mesh=new THREE.Mesh(geom, idHasTransparency(group,p)?leafMat:atlas);
    mesh.castShadow=true; mesh.receiveShadow=true;
    group.add(mesh);
  }

  // Water as low-detail surfaces.
  const wp2=[], wn2=[], wu2=[];
  for(let z=cz*CHUNK;z<Math.min((cz+1)*CHUNK,WORLD_D);z++){
    for(let x=cx*CHUNK;x<Math.min((cx+1)*CHUNK,WORLD_W);x++){
      if(!water[colIndex(x,z)]) continue;
      const h=SEA+0.42;
      // skip if solid block at sea level already occupies it
      if(getBlock(x,SEA,z)!==BLOCK.AIR) continue;
      wp2.push(x,h,z,x+1,h,z,x+1,h,z+1,x,h,z+1);
      wn2.push(0,1,0,0,1,0,0,1,0,0,1,0);
      wu2.push(0,0,1,0,1,1,0,1);
    }
  }
  if(wp2.length){
    const wg=new THREE.BufferGeometry();
    wg.setAttribute("position",new THREE.Float32BufferAttribute(wp2,3));
    wg.setAttribute("normal",new THREE.Float32BufferAttribute(wn2,3));
    wg.setAttribute("uv",new THREE.Float32BufferAttribute(wu2,2));
    const wm=new THREE.Mesh(wg,waterMat); wm.receiveShadow=true; group.add(wm);
  }

  scene.add(group); chunks.set(key,group);
}

function idHasTransparency(){ return false; }

function faceTint(id,f){
  let v = [1,1,1];
  if(f===5) v=[.62,.62,.62];
  if(f===3) v=[.74,.74,.74];
  if(f===2) v=[.9,.9,.9];
  if(id===BLOCK.LEAVES) v=[.72,.84,.68];
  if(id===BLOCK.SNOW) v=[1,1,1];
  return {r:v[0],g:v[1],b:v[2]};
}

function atlasCell(col,row){
  const cols=8, rows=4;
  const x=col/cols, y=1-(row+1)/rows, w=1/cols, h=1/rows;
  return {x,y,w,h};
}
function getUV(id,face){
  // Atlas: each block gets a tile. top/bottom can vary for grass.
  let col=0,row=0;
  switch(id){
    case BLOCK.GRASS: col=(face===4)?0:(face===5?1:2); row=0; break;
    case BLOCK.DIRT: col=1; row=0; break;
    case BLOCK.STONE: col=2; row=0; break;
    case BLOCK.SAND: col=3; row=0; break;
    case BLOCK.WOOD: col=(face===4||face===5)?5:4; row=0; break;
    case BLOCK.LEAVES: col=6; row=0; break;
    case BLOCK.COAL: col=7; row=0; break;
    case BLOCK.IRON: col=0; row=1; break;
    case BLOCK.PLANK: col=1; row=1; break;
    case BLOCK.GLASS: col=2; row=1; break;
    case BLOCK.SNOW: col=3; row=1; break;
    default: col=2; row=0;
  }
  const q=atlasCell(col,row), e=.002;
  return [q.x+e,q.y+e,q.x+q.w-e,q.y+e,q.x+q.w-e,q.y+q.h-e,q.x+e,q.y+q.h-e];
}

function makeAtlasTexture(){
  const s=128, tile=16, cvs=document.createElement("canvas"); cvs.width=s; cvs.height=64;
  const g=cvs.getContext("2d");
  const tileFns=[
    (x,y)=>[112,164,72], (x,y)=>[126,82,46], (x,y)=>[116,120,123], (x,y)=>[214,192,134],
    (x,y)=>[132,87,48], (x,y)=>[178,122,68], (x,y)=>[84,154,76], (x,y)=>[52,55,58],
    (x,y)=>[107,72,46], (x,y)=>[195,147,91], (x,y)=>[180,221,232], (x,y)=>[236,238,226]
  ];
  const blocks=[
    [0,0,0],[1,0,1],[2,0,2],[3,0,3],[4,0,4],[5,0,4],[6,0,6],[7,0,7],
    [0,1,7],[1,1,8],[2,1,9],[3,1,11]
  ];
  const rand=(x,y)=>{ let n=Math.sin(x*12.9898+y*78.233)*43758.5453; return n-Math.floor(n); };
  for(const [col,row,fnIndex] of blocks){
    for(let y=0;y<tile;y++) for(let x=0;x<tile;x++){
      const base=tileFns[fnIndex](x,y);
      let k=1 + (rand(x+col*31,y+row*67)-.5)*.22;
      if(fnIndex===6) k=0.75 + rand(x+12,y+3)*.5;
      if(fnIndex===7 && (x+y)%5===0) k=.4;
      g.fillStyle=`rgb(${Math.max(0,Math.min(255,base[0]*k))},${Math.max(0,Math.min(255,base[1]*k))},${Math.max(0,Math.min(255,base[2]*k))})`;
      g.fillRect(col*tile+x,row*tile+y,1,1);
    }
  }
  // carve tiny transparent specks into leaves/glass look
  const t=new THREE.CanvasTexture(cvs);
  t.colorSpace=THREE.SRGBColorSpace;
  t.magFilter=THREE.NearestFilter; t.minFilter=THREE.NearestMipMapLinearFilter;
  t.generateMipmaps=true;
  return t;
}

function makeClouds(){
  const mat=new THREE.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.75});
  for(let i=0;i<18;i++){
    const group=new THREE.Group();
    const parts=3+Math.floor(Math.random()*4);
    for(let k=0;k<parts;k++){
      const m=new THREE.Mesh(new THREE.BoxGeometry(8+Math.random()*8,1.8+Math.random()*2.0,5+Math.random()*6),mat);
      m.position.set(k*4,Math.random()*1.5,k*1.2);
      group.add(m);
    }
    group.position.set(Math.random()*WORLD_W,55+Math.random()*14,Math.random()*WORLD_D);
    scene.add(group); clouds.push(group);
  }
}

function nearestSolid(x,y,z){
  return getBlock(Math.floor(x),Math.floor(y),Math.floor(z));
}

function aabbCollides(pos){
  const minX=Math.floor(pos.x-player.radius), maxX=Math.floor(pos.x+player.radius);
  const minY=Math.floor(pos.y), maxY=Math.floor(pos.y+player.height-.05);
  const minZ=Math.floor(pos.z-player.radius), maxZ=Math.floor(pos.z+player.radius);
  for(let y=minY;y<=maxY;y++) for(let z=minZ;z<=maxZ;z++) for(let x=minX;x<=maxX;x++){
    const id=getBlock(x,y,z);
    if(id===BLOCK.AIR||id===BLOCK.LEAVES||id===BLOCK.WATER) continue;
    if(player.pos.x+player.radius>x && player.pos.x-player.radius<x+1 &&
       player.pos.y+player.height>y && player.pos.y<y+1 &&
       player.pos.z+player.radius>z && player.pos.z-player.radius<z+1) return true;
  }
  return false;
}

function movePlayer(dt){
  const dir=new THREE.Vector3();
  if(keys.KeyW) dir.z-=1;
  if(keys.KeyS) dir.z+=1;
  if(keys.KeyA) dir.x-=1;
  if(keys.KeyD) dir.x+=1;
  if(dir.lengthSq()>0) dir.normalize();

  const speed=(keys.ShiftLeft||keys.ShiftRight)?SPRINT_SPEED:MOVE_SPEED;
  const forward=new THREE.Vector3(); camera.getWorldDirection(forward); forward.y=0; forward.normalize();
  const right=new THREE.Vector3().crossVectors(forward,camera.up).normalize();
  const wish=new THREE.Vector3().addScaledVector(forward,-dir.z).addScaledVector(right,dir.x);
  if(wish.lengthSq()>0) wish.normalize();

  player.vel.x=THREE.MathUtils.damp(player.vel.x,wish.x*speed,10,dt);
  player.vel.z=THREE.MathUtils.damp(player.vel.z,wish.z*speed,10,dt);
  player.vel.y-=GRAVITY*dt;

  const old=player.pos.clone();

  player.pos.x+=player.vel.x*dt;
  if(aabbCollides(player.pos)){ player.pos.x=old.x; player.vel.x=0; }

  player.pos.z+=player.vel.z*dt;
  if(aabbCollides(player.pos)){ player.pos.z=old.z; player.vel.z=0; }

  player.pos.y+=player.vel.y*dt;
  player.grounded=false;
  if(aabbCollides(player.pos)){
    if(player.vel.y<0){ player.grounded=true; }
    player.pos.y=old.y;
    player.vel.y=0;
  }

  if(player.grounded && (keys.Space||keys.KeyE)) { player.vel.y=JUMP; player.grounded=false; }
  camera.position.copy(player.pos).add(new THREE.Vector3(0,player.eye,0));

  player.pos.x=THREE.MathUtils.clamp(player.pos.x,1,WORLD_W-2);
  player.pos.z=THREE.MathUtils.clamp(player.pos.z,1,WORLD_D-2);
  if(player.pos.y<-10){
    const h=heightAt(Math.floor(player.pos.x),Math.floor(player.pos.z))+1;
    player.pos.set(WORLD_W/2,h,WORLD_D/2);
    player.vel.set(0,0,0);
    player.health=Math.max(1,player.health-18);
  }
}

const raycaster=new THREE.Raycaster();
const center=new THREE.Vector2(0,0);
let targetBlock=null, targetNormal=null, targetDistance=0;

function raycastVoxel(){
  raycaster.setFromCamera(center,camera);
  const step=.08, max=7.0;
  let prev=[Math.floor(camera.position.x),Math.floor(camera.position.y),Math.floor(camera.position.z)];
  for(let t=0;t<max;t+=step){
    const p=raycaster.ray.origin.clone().addScaledVector(raycaster.ray.direction,t);
    const x=Math.floor(p.x), y=Math.floor(p.y), z=Math.floor(p.z);
    if(x!==prev[0]||y!==prev[1]||z!==prev[2]){
      const id=getBlock(x,y,z);
      if(id!==BLOCK.AIR && id!==BLOCK.WATER){
        targetBlock={x,y,z,id};
        targetNormal=[prev[0]-x,prev[1]-y,prev[2]-z];
        targetDistance=t;
        blockHighlight.position.set(x+.5,y+.5,z+.5);
        blockHighlight.visible=true;
        return;
      }
      prev=[x,y,z];
    }
  }
  targetBlock=null; targetNormal=null; blockHighlight.visible=false;
}

function mineBlock(){
  if(!pointerLocked||!targetBlock) return;
  const {x,y,z,id}=targetBlock;
  if(y<=0) return;
  setBlock(x,y,z,BLOCK.AIR);
  const slot=inventory.find(s=>s.id===id);
  if(slot) slot.count=Math.min(99,slot.count+1);
  updateHotbar();
}

function placeBlock(){
  if(!pointerLocked||!targetBlock||targetDistance>7) return;
  const s=inventory[selectedSlot];
  if(!s||s.count<=0) return;
  const nx=targetBlock.x+targetNormal[0], ny=targetBlock.y+targetNormal[1], nz=targetBlock.z+targetNormal[2];
  if(!inBounds(nx,ny,nz)||getBlock(nx,ny,nz)!==BLOCK.AIR) return;
  // prevent placing inside player
  const probe={x:nx+.5,y:ny,z:nz+.5};
  const old=player.pos.clone();
  player.pos.set(probe.x,probe.y,probe.z);
  const bad=aabbCollides(player.pos);
  player.pos.copy(old);
  if(bad) return;
  setBlock(nx,ny,nz,s.id); s.count--; updateHotbar();
}

renderer.domElement.addEventListener("mousedown",e=>{
  if(!pointerLocked) return;
  if(e.button===0) mineBlock();
  if(e.button===2) placeBlock();
});
renderer.domElement.addEventListener("contextmenu",e=>e.preventDefault());

addEventListener("keydown",e=>{
  keys[e.code]=true;
  if(e.code.startsWith("Digit")){
    const n=Number(e.code.slice(5))-1;
    if(n>=0&&n<inventory.length){selectedSlot=n;updateHotbar();}
  }
});
addEventListener("keyup",e=>keys[e.code]=false);

controls.addEventListener("lock",()=>{
  pointerLocked=true;
  document.getElementById("start").classList.add("hidden");
  document.getElementById("pause").classList.add("hidden");
});
controls.addEventListener("unlock",()=>{
  pointerLocked=false;
  if(worldGenerated) document.getElementById("pause").classList.remove("hidden");
});

document.getElementById("playBtn").addEventListener("click",()=>{
  controls.lock();
});

function updateHotbar(){
  const bar=document.getElementById("hotbar"); bar.innerHTML="";
  inventory.forEach((s,i)=>{
    const d=document.createElement("div"); d.className="slot"+(i===selectedSlot?" selected":"");
    const num=document.createElement("div"); num.className="num"; num.textContent=String(i+1);
    const icon=document.createElement("div"); icon.className="icon"; icon.style.background=blockIcon(s.id);
    const count=document.createElement("div"); count.className="count"; count.textContent=s.count;
    d.append(num,icon,count); d.onclick=()=>{selectedSlot=i;updateHotbar();};
    bar.appendChild(d);
  });
}
function blockIcon(id){
  const m={
    [BLOCK.GRASS]:"#72a548",[BLOCK.DIRT]:"#80522f",[BLOCK.STONE]:"#757a7e",
    [BLOCK.SAND]:"#d6bd85",[BLOCK.WOOD]:"#82552f",[BLOCK.PLANK]:"#bd8b55",
    [BLOCK.GLASS]:"linear-gradient(135deg,#d9f2f7 0%,#8ebdca 60%,#eefaff 100%)",
    [BLOCK.LEAVES]:"#5a944f",[BLOCK.COAL]:"#353535"
  };
  return m[id]||"#999";
}
updateHotbar();

function animateWorld(dt){
  dayTime=(dayTime+dt*.006)%1;
  const ang=dayTime*Math.PI*2;
  sun.position.set(
    WORLD_W/2+Math.cos(ang)*90,
    55+Math.sin(ang)*90,
    WORLD_D/2+Math.sin(ang)*35
  );
  sun.target.position.set(WORLD_W/2,15,WORLD_D/2);

  const daylight=Math.max(.08,Math.sin(ang)*.5+.5);
  sun.intensity=.45+daylight*2.2;
  hemi.intensity=.45+daylight*1.0;
  const sky=new THREE.Color().setHSL(.56,.46,.42+.22*daylight);
  scene.background.copy(sky);
  scene.fog.color.copy(sky);

  clouds.forEach((c,i)=>{
    c.position.x=(c.position.x+dt*(1.8+i*.04))%(WORLD_W+25)-12;
  });

  // gentle survival drain
  player.hunger=Math.max(0,player.hunger-dt*.18);
  if(player.hunger<=0) player.health=Math.max(0,player.health-dt*0.7);
  document.querySelector("#healthBar i").style.width=player.health+"%";
  document.querySelector("#foodBar i").style.width=player.hunger+"%";
}

function updateHUD(){
  document.getElementById("coords").textContent =
    `XYZ ${player.pos.x.toFixed(1)} ${player.pos.y.toFixed(1)} ${player.pos.z.toFixed(1)} · ${NAMES[inventory[selectedSlot].id]}`;
  document.getElementById("status").textContent =
    player.grounded ? "Grounded · world stable" : "Airborne · exploring";
}

function respawn(){
  const h=heightAt(Math.floor(WORLD_W/2),Math.floor(WORLD_D/2))+2;
  player.pos.set(WORLD_W/2+.5,h,WORLD_D/2+.5);
  player.vel.set(0,0,0); player.health=100; player.hunger=100;
}

document.addEventListener("visibilitychange",()=>{ if(document.hidden) controls.unlock(); });

function boot(){
  generateWorld();
  respawn();
  updateHotbar();
}

function frame(){
  requestAnimationFrame(frame);
  const now=performance.now(), dt=Math.min(.05,(now-last)/1000); last=now;
  if(pointerLocked){
    movePlayer(dt);
    raycastVoxel();
  }
  animateWorld(dt);
  updateHUD();
  renderer.render(scene,camera);
}
addEventListener("resize",()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});
boot();
frame();
