const c=document.getElementById('game'),ctx=c.getContext('2d');
const menu=document.getElementById('menu'),hud=document.getElementById('hud'),touch=document.getElementById('touch'),pause=document.getElementById('pause');
const maps=[{"s": [45, 450], "g": [890, 450], "p": [[0, 500, 960, 40], [100, 420, 160, 20], [350, 350, 180, 20], [620, 420, 170, 20]], "sp": [[270, 480, 55, 20]], "m": [[410, 310]]}, {"s": [45, 450], "g": [885, 380], "p": [[0, 500, 960, 40], [80, 430, 140, 20], [290, 455, 110, 20], [450, 380, 150, 20], [700, 420, 180, 20]], "sp": [[225, 480, 55, 20], [555, 480, 55, 20]], "m": [[320, 415], [750, 380]]}, {"s": [40, 450], "g": [875, 290], "p": [[0, 500, 960, 40], [80, 430, 130, 20], [270, 360, 120, 20], [470, 430, 130, 20], [650, 350, 120, 20], [810, 280, 110, 20]], "sp": [[215, 480, 55, 20], [400, 480, 65, 20], [600, 480, 55, 20]], "m": [[305, 325], [680, 315]]}, {"s": [40, 450], "g": [870, 220], "p": [[0, 500, 960, 40], [70, 430, 150, 20], [270, 390, 100, 20], [430, 320, 130, 20], [610, 390, 100, 20], [750, 300, 130, 20], [850, 220, 80, 20]], "sp": [[225, 480, 45, 20], [370, 480, 60, 20], [540, 480, 65, 20]], "m": [[290, 355], [635, 355], [785, 265]]}, {"s": [40, 450], "g": [885, 360], "p": [[0, 500, 960, 40], [80, 440, 120, 20], [240, 370, 110, 20], [390, 450, 90, 20], [530, 370, 110, 20], [680, 440, 100, 20], [820, 340, 110, 20]], "sp": [[200, 480, 45, 20], [330, 480, 60, 20], [490, 480, 55, 20], [650, 480, 50, 20]], "m": [[270, 335], [555, 335], [840, 305]]}, {"s": [40, 450], "g": [880, 240], "p": [[0, 500, 960, 40], [90, 420, 100, 20], [230, 330, 110, 20], [390, 420, 100, 20], [530, 300, 120, 20], [690, 390, 100, 20], [810, 260, 110, 20]], "sp": [[190, 480, 60, 20], [330, 480, 60, 20], [490, 480, 60, 20], [630, 480, 60, 20]], "m": [[255, 295], [555, 265], [715, 355]]}, {"s": [40, 450], "g": [875, 180], "p": [[0, 500, 960, 40], [70, 430, 110, 20], [210, 370, 100, 20], [340, 300, 100, 20], [480, 390, 100, 20], [620, 300, 100, 20], [760, 230, 100, 20], [850, 160, 80, 20]], "sp": [[180, 480, 45, 20], [310, 480, 50, 20], [445, 480, 55, 20], [585, 480, 55, 20], [725, 480, 55, 20]], "m": [[235, 335], [500, 355], [650, 265], [790, 195]]}, {"s": [35, 450], "g": [875, 120], "p": [[0, 500, 960, 40], [70, 430, 100, 20], [200, 350, 100, 20], [330, 270, 100, 20], [460, 370, 100, 20], [590, 250, 100, 20], [720, 330, 100, 20], [835, 180, 95, 20], [850, 110, 70, 20]], "sp": [[170, 480, 50, 20], [300, 480, 55, 20], [430, 480, 55, 20], [560, 480, 55, 20], [690, 480, 55, 20], [805, 480, 55, 20]], "m": [[220, 315], [490, 335], [620, 215], [750, 295], [850, 145]]}];
let n=0,running=false,paused=false,keys={},bullets=[],monsters=[],traps=[],last=0,shake=0;
let P={x:0,y:0,w:28,h:40,vx:0,vy:0,on:false,hp:3,inv:0,dir:1};

function levelStart(){let m=maps[n];P={x:m.s[0],y:m.s[1],w:28,h:40,vx:0,vy:0,on:false,hp:3,inv:0,dir:1};bullets=[];monsters=m.m.map(q=>({x:q[0],y:q[1],w:32,h:32,vx:1,dir:1,hp:2,flash:0}));traps=[];updateHUD()}
function updateHUD(){document.getElementById('lvl').textContent='NÍVEL '+(n+1)+' / 8';document.getElementById('hp').textContent='♥'.repeat(P.hp)+'♡'.repeat(3-P.hp)}
function rect(a,b){return a.x<b[0]+b[2]&&a.x+a.w>b[0]&&a.y<b[1]+b[3]&&a.y+a.h>b[1]}
function sfx(f=500,d=.06){try{let A=window.AudioContext||window.webkitAudioContext,a=new A(),o=a.createOscillator(),g=a.createGain();o.frequency.value=f;g.gain.value=.035;o.connect(g);g.connect(a.destination);o.start();o.stop(a.currentTime+d)}catch(e){}}
function shoot(){if(!running||paused)return;bullets.push({x:P.x+P.w/2,y:P.y+15,vx:P.dir*11,life:75});sfx(760,.05)}
function hurt(){if(P.inv>0)return;P.hp--;P.inv=70;shake=8;sfx(150,.12);updateHUD();if(P.hp<=0)setTimeout(levelStart,300)}
function jump(){if(P.on){P.vy=-12;P.on=false;sfx(390,.07)}}
function input(){P.vx=0;if(keys.ArrowLeft||keys.a){P.vx=-4;P.dir=-1}if(keys.ArrowRight||keys.d){P.vx=4;P.dir=1}}
function update(){
 input();P.vy+=.55;if(P.vy>14)P.vy=14;P.x+=P.vx;P.y+=P.vy;P.on=false;
 let m=maps[n];
 for(let q of m.p){if(P.vy>=0&&P.x+P.w>q[0]&&P.x<q[0]+q[2]&&P.y+P.h>=q[1]&&P.y+P.h<=q[1]+18){P.y=q[1]-P.h;P.vy=0;P.on=true}}
 P.x=Math.max(0,Math.min(932,P.x));
 for(let q of m.sp)if(rect(P,q))hurt();
 for(let q of monsters){q.x+=q.vx*q.dir;if(q.x<30||q.x>900)q.dir*=-1;if(rect(P,[q.x,q.y,q.w,q.h]))hurt();if(q.flash>0)q.flash--}
 for(let b of bullets){b.x+=b.vx;b.life--;for(let q of monsters)if(b.x>q.x&&b.x<q.x+q.w&&b.y>q.y&&b.y<q.y+q.h){q.hp--;b.life=0;q.flash=5;sfx(260,.05)}}
 bullets=bullets.filter(b=>b.life>0&&b.x>-20&&b.x<980);monsters=monsters.filter(q=>q.hp>0);
 let near=monsters.some(q=>Math.abs(q.x-P.x)<130);if(near&&!traps.length)traps=[{x:P.x+65,y:500,h:0}];
 for(let t of traps){t.h=Math.min(42,t.h+2);if(P.x>t.x-20&&P.x<t.x+30&&P.y+P.h>500-t.h)hurt()}
 let g=m.g;if(P.x+P.w>g[0]&&P.y+P.h>g[1]&&P.y<g[1]+50){sfx(900,.2);n++;if(n>=maps.length){win();return}else levelStart()}
 if(P.y>560)hurt();
 P.inv=Math.max(0,P.inv-1)
}
function win(){running=false;hud.classList.add('hidden');touch.classList.add('hidden');menu.classList.remove('hidden');menu.innerHTML='<div class="logo">TORRE<br><span>CONCLUÍDA!</span></div><div class="tag">VOCÊ SOBREVIVEU AOS 8 NÍVEIS</div><button onclick="location.reload()">JOGAR DE NOVO</button>'}
function draw(){
 let g=ctx.createLinearGradient(0,0,0,540);g.addColorStop(0,'#111a31');g.addColorStop(1,'#080b13');ctx.fillStyle=g;ctx.fillRect(0,0,960,540);
 ctx.fillStyle='#ffffff08';for(let i=0;i<30;i++)ctx.fillRect((i*137)%960,70+(i*83)%400,2,2);
 let m=maps[n];ctx.fillStyle='#2b3449';for(let q of m.p){ctx.fillRect(q[0],q[1],q[2],q[3]);ctx.fillStyle='#3d4962';ctx.fillRect(q[0],q[1],q[2],4);ctx.fillStyle='#2b3449'}
 ctx.fillStyle='#dfe6f5';for(let q of m.sp){ctx.beginPath();ctx.moveTo(q[0],q[1]+20);ctx.lineTo(q[0]+q[2]/2,q[1]);ctx.lineTo(q[0]+q[2],q[1]+20);ctx.fill()}
 ctx.fillStyle='#27e27d';ctx.fillRect(m.g[0],m.g[1],45,60);ctx.fillStyle='#07120c';ctx.fillRect(m.g[0]+8,m.g[1]+10,29,45);ctx.fillStyle='#9affc2';ctx.fillRect(m.g[0]+13,m.g[1]+18,17,22);
 for(let t of traps){ctx.fillStyle='#e84b5b';ctx.fillRect(t.x,500-t.h,28,t.h);for(let y=0;y<t.h;y+=9)ctx.fillRect(t.x+4,500-y,20,3)}
 for(let q of monsters){ctx.fillStyle=q.flash?'#fff':'#a64cff';ctx.beginPath();ctx.arc(q.x+16,q.y+16,16,0,Math.PI*2);ctx.fill();ctx.fillStyle='#111';ctx.fillRect(q.x+7,q.y+10,6,6);ctx.fillRect(q.x+20,q.y+10,6,6);ctx.fillStyle='#ff5d70';ctx.fillRect(q.x+9,q.y+23,15,4)}
 for(let b of bullets){ctx.fillStyle='#ffd34d';ctx.fillRect(b.x,b.y,12,4)}
 ctx.save();if(P.inv%6<3)ctx.globalAlpha=.45;ctx.fillStyle='#4bb3ff';ctx.fillRect(P.x,P.y+9,P.w,P.h-9);ctx.fillStyle='#f2c39a';ctx.beginPath();ctx.arc(P.x+14,P.y+8,10,0,Math.PI*2);ctx.fill();ctx.fillStyle='#202b40';ctx.fillRect(P.x+4,P.y,P.w-4,6);ctx.fillStyle='#cfd8e8';ctx.fillRect(P.x+(P.dir>0?22:-12),P.y+18,16,6);ctx.restore();
}
function loop(t){if(running&&!paused)update();draw();requestAnimationFrame(loop)}
function start(){n=0;running=true;paused=false;menu.classList.add('hidden');hud.classList.remove('hidden');touch.classList.remove('hidden');pause.classList.add('hidden');levelStart()}
document.getElementById('play').onclick=start;
document.getElementById('how').onclick=()=>document.getElementById('howBox').classList.toggle('hidden');
document.getElementById('resume').onclick=()=>{paused=false;pause.classList.add('hidden')};
document.getElementById('restart').onclick=()=>{paused=false;pause.classList.add('hidden');levelStart()};
document.getElementById('menuBtn').onclick=()=>location.reload();
addEventListener('keydown',e=>{keys[e.key]=true;if(e.key===' '||e.key==='ArrowUp'||e.key==='w')jump();if(e.key==='f'||e.key==='F')shoot();if(e.key==='Escape'&&running){paused=!paused;pause.classList.toggle('hidden')}});
addEventListener('keyup',e=>keys[e.key]=false);
function hold(id,key){let b=document.getElementById(id);b.onpointerdown=e=>{e.preventDefault();keys[key]=true};b.onpointerup=b.onpointercancel=b.onpointerleave=e=>{keys[key]=false}}
hold('L','ArrowLeft');hold('R','ArrowRight');document.getElementById('J').onpointerdown=e=>{e.preventDefault();jump()};document.getElementById('F').onpointerdown=e=>{e.preventDefault();shoot()};
requestAnimationFrame(loop);
