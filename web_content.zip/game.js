import * as THREE from
"https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js";


/* =====================================================
   BASIC SETUP
===================================================== */

const game =
    document.getElementById("game");


const scene =
    new THREE.Scene();


scene.background =
    new THREE.Color(0x87ceeb);


scene.fog =
    new THREE.Fog(
        0x87ceeb,
        35,
        150
    );


/* =====================================================
   CAMERA
===================================================== */

const camera =
    new THREE.PerspectiveCamera(
        70,
        window.innerWidth /
        window.innerHeight,
        0.1,
        500
    );


/* =====================================================
   RENDERER
===================================================== */
const renderer = new THREE.WebGLRenderer({
    antialias: false,
    powerPreference: "high-performance"
});

renderer.setPixelRatio(1);

renderer.setSize(
    window.innerWidth,
    window.innerHeight
);

renderer.shadowMap.enabled = false;

/* =====================================================
   LIGHTING
===================================================== */
const sun = new THREE.DirectionalLight(
    0xffffff,
    1
);

sun.position.set(10, 20, 10);

scene.add(sun);

scene.add(
    new THREE.AmbientLight(
        0xffffff,
        1
    )
);


/* =====================================================
   MATERIALS
===================================================== */

const groundMaterial =
    new THREE.MeshStandardMaterial({
        color: 0x4b8b45
    });


const wallMaterial =
    new THREE.MeshStandardMaterial({
        color: 0x888888
    });


const roofMaterial =
    new THREE.MeshStandardMaterial({
        color: 0x555555
    });


const windowMaterial =
    new THREE.MeshStandardMaterial({
        color: 0x4da6ff,
        metalness: .2,
        roughness: .2
    });


/* =====================================================
   GROUND
===================================================== */

const ground =
    new THREE.Mesh(
        new THREE.PlaneGeometry(
            220,
            220
        ),
        groundMaterial
    );


ground.rotation.x =
    -Math.PI / 2;


ground.receiveShadow = true;


scene.add(ground);


/* =====================================================
   ROAD
===================================================== */

function createRoad(
    x,
    z,
    width,
    depth
) {

    const road =
        new THREE.Mesh(
            new THREE.BoxGeometry(
                width,
                .03,
                depth
            ),
            new THREE.MeshStandardMaterial({
                color: 0x303030
            })
        );

    road.position.set(
        x,
        .02,
        z
    );

    scene.add(road);
}


createRoad(
    0,
    -15,
    150,
    12
);


createRoad(
    0,
    30,
    150,
    12
);


/* =====================================================
   BUILDINGS
===================================================== */

const obstacles = [];


function createBuilding(
    x,
    z,
    width,
    height,
    depth
) {

    const building =
        new THREE.Group();


    building.position.set(
        x,
        height / 2,
        z
    );


    const body =
        new THREE.Mesh(
            new THREE.BoxGeometry(
                width,
                height,
                depth
            ),
            wallMaterial
        );


    body.castShadow = true;
    body.receiveShadow = true;


    building.add(body);


    /* roof */

    const roof =
        new THREE.Mesh(
            new THREE.BoxGeometry(
                width + .3,
                .25,
                depth + .3
            ),
            roofMaterial
        );


    roof.position.y =
        height / 2 + .12;


    building.add(roof);


    /* windows */

    const windowRows = 2;

    const windowColumns = 3;


    for (
        let row = 0;
        row < windowRows;
        row++
    ) {

        for (
            let col = 0;
            col < windowColumns;
            col++
        ) {

            const window =
                new THREE.Mesh(
                    new THREE.BoxGeometry(
                        .9,
                        .8,
                        .05
                    ),
                    windowMaterial
                );


            window.position.set(
                (col - 1) *
                    (width / 3),

                -height / 2 +
                    1.4 +
                    row * 2,

                -depth / 2 - .03
            );


            building.add(window);
        }
    }


    scene.add(building);


    obstacles.push({
        x,
        z,
        width,
        depth
    });
}


/* CITY */

createBuilding(
    -15,
    -5,
    10,
    7,
    10
);


createBuilding(
    18,
    -7,
    12,
    9,
    11
);


createBuilding(
    -18,
    -30,
    14,
    8,
    12
);


createBuilding(
    17,
    -35,
    10,
    6,
    10
);


createBuilding(
    -25,
    20,
    12,
    7,
    10
);


createBuilding(
    25,
    20,
    13,
    9,
    12
);


/* =====================================================
   PLAYER
===================================================== */

const player =
    new THREE.Group();


player.position.set(
    0,
    0,
    15
);


scene.add(player);


/* =====================================================
   FIRST PERSON CAMERA
===================================================== */

camera.position.set(
    0,
    1.65,
    0
);


player.add(camera);


/* =====================================================
   PLAYER BODY - VISIBLE IN THIRD PERSON
===================================================== */

const playerBody =
    new THREE.Mesh(
        new THREE.BoxGeometry(
            .8,
            1.4,
            .45
        ),
        new THREE.MeshStandardMaterial({
            color: 0x2563eb
        })
    );


playerBody.position.y =
    1;


playerBody.castShadow = true;


/* Keep body hidden from first-person camera */

playerBody.visible = false;


player.add(
    playerBody
);


/* =====================================================
   GUN
===================================================== */

const gun =
    new THREE.Group();


camera.add(gun);


gun.position.set(
    .35,
    -.35,
    -.65
);


/* gun receiver */

const receiver =
    new THREE.Mesh(
        new THREE.BoxGeometry(
            .25,
            .2,
            .8
        ),
        new THREE.MeshStandardMaterial({
            color: 0x222222,
            metalness: .8,
            roughness: .25
        })
    );


gun.add(receiver);


/* barrel */

const barrel =
    new THREE.Mesh(
        new THREE.CylinderGeometry(
            .045,
            .055,
            .75,
            12
        ),
        new THREE.MeshStandardMaterial({
            color: 0x111111,
            metalness: .9
        })
    );


barrel.rotation.x =
    Math.PI / 2;


barrel.position.z =
    -.7;


gun.add(barrel);


/* magazine */

const magazine =
    new THREE.Mesh(
        new THREE.BoxGeometry(
            .16,
            .35,
            .22
        ),
        new THREE.MeshStandardMaterial({
            color: 0x151515
        })
    );


magazine.position.set(
    0,
    -.25,
    .1
);


magazine.rotation.x =
    -.2;


gun.add(magazine);


/* handle */

const handle =
    new THREE.Mesh(
        new THREE.BoxGeometry(
            .14,
            .4,
            .18
        ),
        new THREE.MeshStandardMaterial({
            color: 0x111111
        })
    );


handle.position.set(
    0,
    -.28,
    .25
);


handle.rotation.x =
    -.25;


gun.add(handle);


/* =====================================================
   MUZZLE FLASH
===================================================== */

const muzzleFlash =
    new THREE.Mesh(
        new THREE.SphereGeometry(
            .1,
            8,
            8
        ),
        new THREE.MeshBasicMaterial({
            color: 0xffaa00
        })
    );


muzzleFlash.position.z =
    -1.08;


muzzleFlash.visible = false;


gun.add(
    muzzleFlash
);


/* =====================================================
   WEAPON VARIABLES
===================================================== */

const MAG_SIZE = 30;

let ammo = MAG_SIZE;

let reserveAmmo = 120;

let reloading = false;

let shooting = false;

let aiming = false;


/* =====================================================
   HUD
===================================================== */

const healthElement =
    document.getElementById(
        "health"
    );


const killsElement =
    document.getElementById(
        "kills"
    );


const ammoElement =
    document.getElementById(
        "ammo"
    );


const reserveElement =
    document.getElementById(
        "reserve"
    );


const reloadElement =
    document.getElementById(
        "reloadText"
    );


const statusElement =
    document.getElementById(
        "status"
    );


const hitMarker =
    document.getElementById(
        "hitMarker"
    );


function updateHUD() {

    ammoElement.textContent =
        ammo;

    reserveElement.textContent =
        reserveAmmo;
}


/* =====================================================
   ENEMIES
===================================================== */

const enemies = [];

let kills = 0;


function createEnemy(
    x,
    z
) {

    const enemy =
        new THREE.Group();


    enemy.position.set(
        x,
        0,
        z
    );


    /* body */

    const body =
        new THREE.Mesh(
            new THREE.BoxGeometry(
                .8,
                1.3,
                .45
            ),
            new THREE.MeshStandardMaterial({
                color: 0xb91c1c
            })
        );


    body.position.y =
        1;


    body.castShadow = true;


    enemy.add(body);


    /* head */

    const head =
        new THREE.Mesh(
            new THREE.SphereGeometry(
                .27,
                16,
                16
            ),
            new THREE.MeshStandardMaterial({
                color: 0xd39a6a
            })
        );


    head.position.y =
        1.85;


    head.castShadow = true;


    enemy.add(head);


    /* gun */

    const enemyGun =
        new THREE.Mesh(
            new THREE.BoxGeometry(
                .15,
                .15,
                .65
            ),
            new THREE.MeshStandardMaterial({
                color: 0x111111
            })
        );


    enemyGun.position.set(
        .45,
        1.15,
        -.25
    );


    enemyGun.rotation.y =
        -.25;


    enemy.add(enemyGun);


    enemy.userData.health =
        100;


    enemy.userData.attackTimer =
        0;


    scene.add(enemy);


    enemies.push(enemy);
}


/* enemies */

createEnemy(
    5,
    -20
);


createEnemy(
    -7,
    -25
);


createEnemy(
    12,
    -35
);


createEnemy(
    -14,
    -42
);


createEnemy(
    20,
    -50
);


/* =====================================================
   JOYSTICK
===================================================== */

const joystick =
    document.getElementById(
        "joystick"
    );


const joystickStick =
    document.getElementById(
        "joystickStick"
    );


let moveX = 0;

let moveY = 0;

let joystickActive = false;


joystick.addEventListener(
    "touchstart",
    event => {

        event.preventDefault();

        joystickActive = true;

        updateJoystick(
            event.touches[0]
        );
    },
    {
        passive: false
    }
);


joystick.addEventListener(
    "touchmove",
    event => {

        event.preventDefault();

        if (!joystickActive)
            return;

        updateJoystick(
            event.touches[0]
        );
    },
    {
        passive: false
    }
);


joystick.addEventListener(
    "touchend",
    () => {

        joystickActive = false;

        moveX = 0;
        moveY = 0;

        joystickStick.style.left =
            "35px";

        joystickStick.style.top =
            "35px";
    }
);


function updateJoystick(
    touch
) {

    const rect =
        joystick.getBoundingClientRect();


    const centerX =
        rect.left +
        rect.width / 2;


    const centerY =
        rect.top +
        rect.height / 2;


    let dx =
        touch.clientX -
        centerX;


    let dy =
        touch.clientY -
        centerY;


    const maxDistance = 38;


    const distance =
        Math.sqrt(
            dx * dx +
            dy * dy
        );


    if (
        distance >
        maxDistance
    ) {

        dx =
            dx / distance *
            maxDistance;

        dy =
            dy / distance *
            maxDistance;
    }


    joystickStick.style.left =
        `${35 + dx}px`;


    joystickStick.style.top =
        `${35 + dy}px`;


    moveX =
        dx / maxDistance;


    moveY =
        dy / maxDistance;
}


/* =====================================================
   CAMERA LOOK
===================================================== */

const lookArea =
    document.getElementById(
        "lookArea"
    );


let looking = false;

let lastX = 0;

let lastY = 0;

let cameraPitch = 0;


lookArea.addEventListener(
    "touchstart",
    event => {

        event.preventDefault();

        looking = true;

        lastX =
            event.touches[0].clientX;

        lastY =
            event.touches[0].clientY;
    },
    {
        passive: false
    }
);


lookArea.addEventListener(
    "touchmove",
    event => {

        event.preventDefault();

        if (!looking)
            return;


        const touch =
            event.touches[0];


        const dx =
            touch.clientX -
            lastX;


        const dy =
            touch.clientY -
            lastY;


        player.rotation.y -=
            dx * .006;


        cameraPitch -=
            dy * .004;


        cameraPitch =
            THREE.MathUtils.clamp(
                cameraPitch,
                -1.2,
                1.2
            );


        camera.rotation.x =
            cameraPitch;


        lastX =
            touch.clientX;


        lastY =
            touch.clientY;
    },
    {
        passive: false
    }
);


lookArea.addEventListener(
    "touchend",
    () => {

        looking = false;
    }
);


/* =====================================================
   AIM
===================================================== */

const aimButton =
    document.getElementById(
        "aimButton"
    );


aimButton.addEventListener(
    "touchstart",
    event => {

        event.preventDefault();

        aiming = true;

        document.body.classList.add(
            "aimMode"
        );


        camera.fov = 45;


        camera.updateProjectionMatrix();


        gun.position.set(
            .15,
            -.22,
            -.5
        );
    },
    {
        passive: false
    }
);


aimButton.addEventListener(
    "touchend",
    () => {

        aiming = false;

        document.body.classList.remove(
            "aimMode"
        );


        camera.fov = 70;


        camera.updateProjectionMatrix();


        gun.position.set(
            .35,
            -.35,
            -.65
        );
    }
);


/* =====================================================
   AUDIO SYSTEM
===================================================== */

let audioContext = null;


function initAudio() {

    if (!audioContext) {

        audioContext =
            new (
                window.AudioContext ||
                window.webkitAudioContext
            )();
    }


    if (
        audioContext.state ===
        "suspended"
    ) {

        audioContext.resume();
    }
}


/* gun sound */

function gunSound() {

    initAudio();


    const oscillator =
        audioContext.createOscillator();


    const gain =
        audioContext.createGain();


    oscillator.type =
        "sawtooth";


    oscillator.frequency.setValueAtTime(
        130,
        audioContext.currentTime
    );


    oscillator.frequency.exponentialRampToValueAtTime(
        45,
        audioContext.currentTime + .12
    );


    gain.gain.setValueAtTime(
        .16,
        audioContext.currentTime
    );


    gain.gain.exponentialRampToValueAtTime(
        .001,
        audioContext.currentTime + .12
    );


    oscillator.connect(gain);

    gain.connect(
        audioContext.destination
    );


    oscillator.start();

    oscillator.stop(
        audioContext.currentTime + .12
    );
}


/* reload sound */

function reloadSound() {

    initAudio();


    const oscillator =
        audioContext.createOscillator();


    const gain =
        audioContext.createGain();


    oscillator.type =
        "square";


    oscillator.frequency.value =
        500;


    gain.gain.value =
        .05;


    oscillator.connect(gain);

    gain.connect(
        audioContext.destination
    );


    oscillator.start();


    oscillator.stop(
        audioContext.currentTime + .08
    );
}


/* footsteps */

let footstepTimer = 0;


function footstepSound() {

    initAudio();


    const oscillator =
        audioContext.createOscillator();


    const gain =
        audioContext.createGain();


    oscillator.type =
        "triangle";


    oscillator.frequency.value =
        90;


    gain.gain.setValueAtTime(
        .035,
        audioContext.currentTime
    );


    gain.gain.exponentialRampToValueAtTime(
        .001,
        audioContext.currentTime + .08
    );


    oscillator.connect(gain);

    gain.connect(
        audioContext.destination
    );


    oscillator.start();

    oscillator.stop(
        audioContext.currentTime + .08
    );
}


/* =====================================================
   SHOOTING
===================================================== */

const raycaster =
    new THREE.Raycaster();


function shoot() {

    initAudio();


    if (reloading)
        return;


    if (ammo <= 0) {

        reload();

        return;
    }


    ammo--;

    updateHUD();


    gunSound();


    /* muzzle */

    muzzleFlash.visible =
        true;


    setTimeout(
        () => {

            muzzleFlash.visible =
                false;

        },
        55
    );


    /* recoil */

    gun.rotation.x =
        -.05;


    setTimeout(
        () => {

            gun.rotation.x =
                0;

        },
        70
    );


    /* ray */

    raycaster.setFromCamera(
        new THREE.Vector2(0,0),
        camera
    );


    const targets = [];


    enemies.forEach(
        enemy => {

            enemy.children.forEach(
                child => {

                    targets.push(child);
                }
            );
        }
    );


    const hits =
        raycaster.intersectObjects(
            targets,
            false
        );


    if (
        hits.length === 0
    )
        return;


    const hit =
        hits[0].object;


    const enemy =
        hit.parent;


    enemy.userData.health -=
        25;


    showHitMarker();


    hit.material.emissive =
        new THREE.Color(
            0xff0000
        );


    setTimeout(
        () => {

            if (hit.material) {

                hit.material.emissive =
                    new THREE.Color(
                        0x000000
                    );
            }

        },
        100
    );


    if (
        enemy.userData.health <= 0
    ) {

        scene.remove(
            enemy
        );


        const index =
            enemies.indexOf(
                enemy
            );


        if (index !== -1) {

            enemies.splice(
                index,
                1
            );
        }


        kills++;


        killsElement.te