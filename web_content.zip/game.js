// ================================================
// METALLIC FEAST — game.js
// Full game logic: Hunt, Combat, Cook, Serve
// ================================================

'use strict';

// ───────────────────────────────── STATE ─────────────────────────────────────
const GAME = {
  screen:     'intro',
  credits:    200,
  reputation: 0,
  level:      1,
  xp:         0,
  xpToNext:   100,
  player: { hp: 100, maxHp: 100, baseAttack: 15, attack: 15, defense: 5 },
  upgrades: { attack: 0, defense: 0, maxHp: 0 },
  inventory:  {},        // { ingredient_id: qty }
  readyDishes: [],       // [{ recipeId, stars, price }]
  activityLog: ['Sistema inicializado...', 'Bestias detectadas en sector 7.'],

  // Sector actual (1 al 10)
  currentSector: 1,

  // Armas y equipamiento
  weaponsOwned: [],      // ['vibro_knife', ...]
  equippedWeapon: null,  // id del arma o null

  // Consumibles
  fullHeals: 0,          // cantidad de curaciones completas almacenadas

  // Habilidades pasivas desbloqueadas por nivel
  abilities: [],         // ['overcharge', 'nanoshield', 'vampirism', ...]

  // Niveles del Laboratorio de Mejoras (expansión): { lab_crit: 5, lab_atkpct: 12, ... }
  labUpgrades: {},

  // Hitos de nivel ya reclamados
  claimedMilestones: [],

  // Estado de interfaz (no se guarda)
  ui: { sectorsPage: 0, labTab: 'combat', labBuy: 1, recipeOnlyCookable: false, recipeSearch: '' },

  // Tienda rotativa
  shopStock: {
    weapons: [],
    nextRotationTime: 0
  },

  hunt: {
    map: null,
    playerPos: { x: 0, y: 0 },
    beasts: [],
    log: []
  },

  combat: {
    beast:     null,
    beastHp:   0,
    log:       [],
    turn:      'player',
    defending: false,
    animating: false
  },

  cook: {
    selected:       [],   // ingredient ids (with repeats)
    phase:          'select',
    currentRecipe:  null,
    barPos:         0,
    barDir:         1,
    barInterval:    null,
    resultStars:    0
  },

  serve: {
    customers:    [],
    dishes:       [],      // copy of readyDishes used during serve
    selectedDish: null,
    selIndex:     -1,
    timeLeft:     60,
    timerInterval: null,
    earned:       0
  }
};

const SAVE_KEY = 'metallic-feast-save-v1';
const ROTATION_INTERVAL_MS = 2 * 60 * 1000; // 2 minutos

function recalculatePlayerAttack() {
  if (GAME.player.baseAttack === undefined) {
    GAME.player.baseAttack = 15 + (GAME.upgrades.attack || 0) + ((GAME.level - 1) * 2);
  }
  let weaponBonus = 0;
  if (GAME.equippedWeapon) {
    const w = WEAPONS_CATALOG.find(x => x.id === GAME.equippedWeapon);
    if (w) weaponBonus = w.attack;
  }
  GAME.player.attack = Math.floor((GAME.player.baseAttack + weaponBonus) * (1 + getStat('atkpct')));
}

function saveGame() {
  const savedState = {
    credits: GAME.credits, reputation: GAME.reputation, level: GAME.level,
    xp: GAME.xp, xpToNext: GAME.xpToNext, player: GAME.player,
    upgrades: GAME.upgrades, inventory: GAME.inventory,
    readyDishes: GAME.readyDishes, activityLog: GAME.activityLog,
    currentSector: GAME.currentSector || 1,
    weaponsOwned: GAME.weaponsOwned,
    equippedWeapon: GAME.equippedWeapon,
    fullHeals: GAME.fullHeals,
    abilities: GAME.abilities,
    claimedMilestones: GAME.claimedMilestones,
    shopStock: GAME.shopStock,
    labUpgrades: GAME.labUpgrades
  };
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(savedState)); } catch (error) { /* Storage may be unavailable. */ }
}

function loadGame() {
  try {
    const savedState = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (!savedState) return false;
    Object.assign(GAME, {
      credits: Number.isFinite(savedState.credits) ? savedState.credits : GAME.credits,
      reputation: Number.isFinite(savedState.reputation) ? savedState.reputation : GAME.reputation,
      level: Number.isFinite(savedState.level) ? savedState.level : GAME.level,
      xp: Number.isFinite(savedState.xp) ? savedState.xp : GAME.xp,
      xpToNext: Number.isFinite(savedState.xpToNext) ? savedState.xpToNext : GAME.xpToNext,
      inventory: savedState.inventory && typeof savedState.inventory === 'object' ? savedState.inventory : {},
      readyDishes: Array.isArray(savedState.readyDishes) ? savedState.readyDishes : [],
      activityLog: Array.isArray(savedState.activityLog) ? savedState.activityLog : GAME.activityLog,
      currentSector: Number.isFinite(savedState.currentSector) ? savedState.currentSector : 1,
      weaponsOwned: Array.isArray(savedState.weaponsOwned) ? savedState.weaponsOwned : [],
      equippedWeapon: savedState.equippedWeapon || null,
      fullHeals: Number.isFinite(savedState.fullHeals) ? savedState.fullHeals : 0,
      abilities: Array.isArray(savedState.abilities) ? savedState.abilities : [],
      claimedMilestones: Array.isArray(savedState.claimedMilestones) ? savedState.claimedMilestones : [],
      labUpgrades: savedState.labUpgrades && typeof savedState.labUpgrades === 'object' ? savedState.labUpgrades : {},
      shopStock: savedState.shopStock && typeof savedState.shopStock === 'object' ? savedState.shopStock : { weapons: [], nextRotationTime: 0 }
    });
    GAME.player = { ...GAME.player, ...(savedState.player || {}) };
    GAME.upgrades = { ...GAME.upgrades, ...(savedState.upgrades || {}) };

    if (GAME.player.baseAttack === undefined) {
      GAME.player.baseAttack = 15 + (GAME.upgrades.attack || 0) + ((GAME.level - 1) * 2);
    }
    recalculatePlayerAttack();
    return true;
  } catch (error) { return false; }
}

function resetGame() {
  if (confirm('⚠️ ¿Estás seguro de que quieres BORRAR todo tu progreso y empezar desde cero?')) {
    try {
      localStorage.removeItem(SAVE_KEY);
      localStorage.clear();
    } catch (e) {
      console.error(e);
    }
    window.location.reload();
  }
}

// ── COPIA DE SEGURIDAD (EXPORTAR / IMPORTAR) ──
function getSaveData() {
  return {
    version: '1.0',
    timestamp: new Date().toISOString(),
    credits: GAME.credits,
    reputation: GAME.reputation,
    level: GAME.level,
    xp: GAME.xp,
    xpToNext: GAME.xpToNext,
    player: GAME.player,
    upgrades: GAME.upgrades,
    inventory: GAME.inventory,
    readyDishes: GAME.readyDishes,
    activityLog: GAME.activityLog,
    currentSector: GAME.currentSector || 1,
    weaponsOwned: GAME.weaponsOwned,
    equippedWeapon: GAME.equippedWeapon,
    fullHeals: GAME.fullHeals,
    abilities: GAME.abilities,
    claimedMilestones: GAME.claimedMilestones,
    shopStock: GAME.shopStock,
    labUpgrades: GAME.labUpgrades
  };
}

function openBackupModal() {
  const modal = document.getElementById('modal-backup');
  if (modal) {
    modal.style.display = 'flex';
    const status = document.getElementById('backup-status-msg');
    if (status) status.innerHTML = '';
  }
}

function closeBackupModal() {
  const modal = document.getElementById('modal-backup');
  if (modal) modal.style.display = 'none';
}

function exportBackup() {
  saveGame();
  const data = getSaveData();
  const jsonStr = JSON.stringify(data, null, 2);

  // Mostrar el JSON en el textarea para que el usuario pueda copiarlo.
  // Funciona en CUALQUIER WebView / APK (AppGeyser, etc.) donde las descargas
  // de archivos están bloqueadas por Android sin permisos nativos.
  const exportArea = document.getElementById('backup-export-text');
  if (exportArea) {
    exportArea.value = jsonStr;
    exportArea.focus();
    exportArea.select();
  }

  const status = document.getElementById('backup-status-msg');
  if (status) {
    status.innerHTML = `<span style="color:#00ff88;">✅ Código generado (Nivel ${GAME.level}). ¡Cópialo y guárdalo en un lugar seguro!</span>`;
  }
  addLog(`💾 Copia de seguridad generada (Nivel ${GAME.level}).`);
}

function copyBackupToClipboard() {
  const exportArea = document.getElementById('backup-export-text');
  const status = document.getElementById('backup-status-msg');
  if (!exportArea || !exportArea.value) {
    if (status) status.innerHTML = `<span style="color:#ff4455;">❌ Primero genera el código con el botón de arriba.</span>`;
    return;
  }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(exportArea.value).then(() => {
      if (status) status.innerHTML = `<span style="color:#00ff88;">✅ ¡Copiado al portapapeles!</span>`;
    }).catch(() => {
      exportArea.focus(); exportArea.select();
      if (status) status.innerHTML = `<span style="color:#ffcc00;">⚠️ Seleccionado. Mantén pulsado el texto y elige Copiar.</span>`;
    });
  } else {
    exportArea.focus(); exportArea.select();
    if (status) status.innerHTML = `<span style="color:#ffcc00;">⚠️ Seleccionado. Mantén pulsado el texto y elige Copiar.</span>`;
  }
}

function importFromText() {
  const importArea = document.getElementById('backup-import-text');
  const status = document.getElementById('backup-status-msg');
  if (!importArea || !importArea.value.trim()) {
    if (status) status.innerHTML = `<span style="color:#ff4455;">❌ Pega el código de guardado en el campo de texto.</span>`;
    return;
  }
  _applyBackupJson(importArea.value.trim(), status);
}

function importBackup(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const status = document.getElementById('backup-status-msg');
  const reader = new FileReader();
  reader.onload = function(e) { _applyBackupJson(e.target.result, status); };
  reader.readAsText(file);
}

function _applyBackupJson(jsonStr, statusEl) {
  try {
    const parsed = JSON.parse(jsonStr);
    if (!parsed || typeof parsed !== 'object') throw new Error('Formato inválido');
    if (typeof parsed.level !== 'number') throw new Error('El código no contiene un nivel válido');
    localStorage.setItem(SAVE_KEY, JSON.stringify(parsed));
    if (statusEl) statusEl.innerHTML = `<span style="color:#00ff88;">✅ ¡Partida restaurada! Recargando...</span>`;
    setTimeout(() => window.location.reload(), 1000);
  } catch (err) {
    console.error(err);
    if (statusEl) statusEl.innerHTML = `<span style="color:#ff4455;">❌ Error: Código corrupto o no válido.</span>`;
  }
}

// ── EXPANSIÓN: STATS UNIFICADOS, DESCUENTOS Y FORMATO ──
function fmtNum(n) {
  n = Math.floor(n || 0);
  const trim = s => s.replace(/\.?0+$/, '');
  if (n >= 1e12) return trim((n / 1e12).toFixed(2)) + 'T';
  if (n >= 1e9)  return trim((n / 1e9).toFixed(2)) + 'B';
  if (n >= 1e6)  return trim((n / 1e6).toFixed(2)) + 'M';
  return String(n);
}

function labLevel(id) { return (GAME.labUpgrades && GAME.labUpgrades[id]) || 0; }

// Suma: mejoras del laboratorio + perk del arma equipada + habilidades pasivas
function getStat(key) {
  let v = 0;
  const w = GAME.equippedWeapon ? WEAPONS_CATALOG.find(x => x.id === GAME.equippedWeapon) : null;
  if (w && w.perk && w.perk.type === key) v += w.perk.value;
  UPGRADE_LINES.forEach(l => { if (l.stat === key) v += labLevel(l.id) * l.perLevel; });
  (GAME.abilities || []).forEach(a => {
    const d = ABILITY_DEFS[a];
    if (d && d.stats && d.stats[key]) v += d.stats[key];
  });
  const cap = STAT_CAPS[key];
  return cap !== undefined ? Math.min(v, cap) : v;
}

function applyDiscount(cost) {
  return Math.max(1, Math.round(cost * (1 - getStat('discount'))));
}

// ── LABORATORIO DE MEJORAS ──
function labFmt(line, v) {
  if (line.stat === 'servetime') return `+${v} s`;
  if (line.stat === 'extracust') return `+${v}`;
  return `+${parseFloat((v * 100).toFixed(1))}%`;
}

function getLabCost(line, lvl) { return applyDiscount(getLabUpgradeCost(line, lvl)); }

function openLab() {
  renderLab();
  const modal = document.getElementById('modal-lab');
  if (modal) modal.style.display = 'flex';
}
function closeLab() {
  const modal = document.getElementById('modal-lab');
  if (modal) modal.style.display = 'none';
}
function labSetTab(tab) { GAME.ui.labTab = tab; renderLab(); }
function labSetBuy(n)   { GAME.ui.labBuy = n;   renderLab(); }

function renderLab() {
  const el = document.getElementById('lab-content');
  if (!el) return;
  const prevScroll = el.scrollTop;
  const tab = GAME.ui.labTab;

  let html = `
    <div class="equipped-weapon-banner" style="background:rgba(0,30,50,0.6);">
      <div>💳 Créditos: <strong style="color:var(--neon-yellow)">${fmtNum(GAME.credits)}₿</strong>
        · Descuento: <strong style="color:#00ff88">-${Math.round(getStat('discount') * 100)}%</strong></div>
      <div class="equipped-stat-tag">Mejoras permanentes con niveles. Los bonos se suman a los perks de tus armas y a tus habilidades.</div>
    </div>
    <div class="lab-tabs">
      ${LAB_CATEGORIES.map(c => `<button class="lab-tab ${c.id === tab ? 'active' : ''}" onclick="labSetTab('${c.id}')">${c.name}</button>`).join('')}
    </div>
    <div class="lab-buy-row">
      <span>Comprar:</span>
      ${[1, 5, 'max'].map(n => `<button class="lab-tab small ${GAME.ui.labBuy === n ? 'active' : ''}" onclick="labSetBuy(${typeof n === 'string' ? `'${n}'` : n})">${n === 'max' ? 'MÁX' : '×' + n}</button>`).join('')}
    </div>`;

  UPGRADE_LINES.filter(l => l.cat === tab).forEach(line => {
    const lvl = labLevel(line.id);
    const maxed = lvl >= line.max;
    const locked = GAME.level < line.reqLevel;
    const cost = getLabCost(line, lvl);
    const perTxt = line.instant
      ? `${labFmt(line, line.perLevel)} ${line.desc}`
      : `${labFmt(line, line.perLevel)} ${line.desc} por nivel`;
    const totalTxt = line.instant
      ? `Acumulado: x${Math.pow(1 + line.perLevel, lvl).toFixed(2)}`
      : `Total: ${labFmt(line, lvl * line.perLevel)}`;
    html += `
      <div class="lab-card ${locked ? 'locked' : ''} ${maxed ? 'maxed' : ''}">
        <span class="lab-emoji">${line.emoji}</span>
        <div class="lab-info">
          <strong>${line.name} <span class="shop-tag">Nv. ${lvl}/${line.max}</span></strong>
          <span>${perTxt}</span>
          <span style="color:var(--neon-cyan)">${totalTxt}</span>
        </div>
        <button class="btn-neon lab-buy" onclick="buyLabUpgrade('${line.id}')"
          ${(maxed || locked || GAME.credits < cost) ? 'disabled' : ''}>
          ${maxed ? 'MÁX' : locked ? `🔒 Nv.${line.reqLevel}` : fmtNum(cost) + '₿'}
        </button>
      </div>`;
  });

  el.innerHTML = html;
  el.scrollTop = prevScroll;
}

function buyLabUpgrade(id) {
  const line = UPGRADE_LINES.find(l => l.id === id);
  if (!line) return;
  if (GAME.level < line.reqLevel) { flashMsg(`🔒 Necesitas Nivel ${line.reqLevel} para esta mejora.`); return; }

  const want = GAME.ui.labBuy === 'max' ? 9999 : GAME.ui.labBuy;
  let bought = 0, spent = 0;
  while (bought < want) {
    const lvl = labLevel(id);
    if (lvl >= line.max) break;
    const cost = getLabCost(line, lvl);
    if (GAME.credits < cost) break;
    GAME.credits -= cost;
    spent += cost;
    GAME.labUpgrades[id] = lvl + 1;
    bought++;
    if (line.instant === 'maxHp') {
      GAME.player.maxHp = Math.max(GAME.player.maxHp + 1, Math.round(GAME.player.maxHp * (1 + line.perLevel)));
      GAME.player.hp = GAME.player.maxHp;
    } else if (line.instant === 'defense') {
      GAME.player.defense = Math.max(GAME.player.defense + 1, Math.round(GAME.player.defense * (1 + line.perLevel)));
    }
  }
  if (!bought) {
    flashMsg(labLevel(id) >= line.max ? 'Esta mejora ya está al máximo.' : 'No tienes suficientes créditos.');
    return;
  }
  recalculatePlayerAttack();
  addLog(`🧬 ${line.emoji} ${line.name} +${bought} nivel(es) (Nv. ${labLevel(id)}/${line.max}) por ${fmtNum(spent)}₿.`);
  saveGame();
  updateHubUI();
  renderLab();
}

// ── SISTEMA DE SECTORES (1 AL 110) ──
function getCurrentSectorObj() {
  const sId = GAME.currentSector || 1;
  return SECTORS.find(s => s.id === sId) || SECTORS[0];
}

function openSectorsModal() {
  GAME.ui.sectorsPage = getZoneOfSector(GAME.currentSector || 1).id;
  renderSectorsModal();
  const modal = document.getElementById('modal-sectors');
  if (modal) modal.style.display = 'flex';
}

function closeSectorsModal() {
  const modal = document.getElementById('modal-sectors');
  if (modal) modal.style.display = 'none';
}

function travelToSector(sectorId) {
  const s = SECTORS.find(sec => sec.id === sectorId);
  if (!s) return;
  if (GAME.level < s.reqLevel) {
    flashMsg(`🔒 Necesitas Nivel ${s.reqLevel} para entrar a ${s.name}.`);
    return;
  }
  GAME.currentSector = sectorId;
  addLog(`🚀 Viajaste al ${s.name}. ¡Los precios de los platos se han actualizado!`);
  saveGame();
  updateHubUI();
  renderSectorsModal();
}

function setSectorsPage(zoneId) {
  GAME.ui.sectorsPage = zoneId;
  renderSectorsModal();
  const box = document.querySelector('#modal-sectors .modal-content');
  if (box) box.scrollTop = 0;
}

function renderSectorsModal() {
  const grid = document.getElementById('sectors-grid');
  if (!grid) return;
  const currentS = getCurrentSectorObj();
  setTxt('current-sector-title', `${currentS.emoji} ${currentS.name}`);

  // Pestañas de zonas (10 sectores por página)
  const pager = document.getElementById('sectors-pages');
  if (pager) {
    pager.innerHTML = SECTOR_ZONES.map(z => {
      const active = z.id === GAME.ui.sectorsPage;
      const locked = GAME.level < getRequiredLevelForSector(z.from);
      return `<button class="zone-tab ${active ? 'active' : ''} ${locked ? 'locked' : ''}" onclick="setSectorsPage(${z.id})" title="${z.name}">${z.emoji}<span>${z.from}-${z.to}</span></button>`;
    }).join('');
  }
  const zone = SECTOR_ZONES[GAME.ui.sectorsPage] || SECTOR_ZONES[0];
  setTxt('sectors-zone-title', `${zone.emoji} ZONA ${zone.id}: ${zone.name.toUpperCase()} · Sectores ${zone.from}-${zone.to}`);

  let html = '';
  SECTORS.filter(sec => sec.id >= zone.from && sec.id <= zone.to).forEach(sec => {
    const isCurrent = (GAME.currentSector || 1) === sec.id;
    const isLocked  = GAME.level < sec.reqLevel;
    const diffInfo  = getSectorDifficultyInfo(sec.id);

    // Buscar mejores platos en este sector
    const bestDishes = Object.entries(sec.multipliers)
      .map(([rid, mult]) => {
        const r = RECIPES.find(x => x.id === rid);
        return { name: r ? r.name : rid, emoji: r ? r.emoji : '🍲', mult };
      })
      .sort((a, b) => b.mult - a.mult);

    const topSpecial = bestDishes[0];

    html += `
      <div class="sector-card ${isCurrent ? 'active-sector' : ''} ${isLocked ? 'locked-sector' : ''}">
        <div class="sector-header-row">
          <span class="sector-title">${sec.emoji} ${sec.name}</span>
          <span class="sector-lvl-badge">${isLocked ? `🔒 Nv. ${sec.reqLevel}` : `✅ Desbloqueado`}</span>
        </div>
        <div class="sector-desc">${sec.desc}</div>
        <div class="sector-bonuses">
          <div style="margin-bottom: 0.25rem;">
            <span class="sector-bonus-tag" style="border-color:${diffInfo.color}; color:${diffInfo.color}; font-weight:bold;">
              ${diffInfo.emoji} DIFICULTAD: ${diffInfo.name} (HP x${diffInfo.hpMult}, ATK x${diffInfo.atkMult})
            </span>
          </div>
          ${sec.balanced
            ? `<div class="sector-bonus-tag">⚖️ PAGO BALANCEADO: ~1.18x parejo por TODO (Sin abuso)</div>`
            : `<div>⭐ Especialidad: <span class="sector-bonus-tag">${topSpecial.emoji} ${topSpecial.name} (${Math.round(topSpecial.mult * 100)}%)</span></div>`
          }
        </div>
        ${isCurrent
          ? `<button class="btn-neon sector-btn-travel" disabled style="border-color:var(--neon-yellow); color:var(--neon-yellow);">📍 SECTOR ACTUAL</button>`
          : isLocked
            ? `<button class="btn-neon sector-btn-travel" disabled style="opacity:0.4;">🔒 NIVEL ${sec.reqLevel} REQUERIDO</button>`
            : `<button class="btn-neon sector-btn-travel" onclick="travelToSector(${sec.id})">🚀 VIAJAR AQUÍ</button>`
        }
      </div>`;
  });

  grid.innerHTML = html;
}

// Elige las armas del stock rotativo: las que son el siguiente paso de tu progreso
function pickRotatingWeapons() {
  const owned = GAME.weaponsOwned;
  const bestOwned = owned.reduce((m, id) => {
    const w = WEAPONS_CATALOG.find(x => x.id === id);
    return w ? Math.max(m, w.attack) : m;
  }, 0);
  const unowned = WEAPONS_CATALOG.filter(w => !owned.includes(w.id));
  const reachable = unowned.filter(w => (w.reqLevel || 1) <= GAME.level + 2);

  let pool = reachable.filter(w => w.attack > bestOwned).sort((a, b) => a.attack - b.attack).slice(0, 12);
  if (pool.length < 3) pool = reachable.sort((a, b) => b.attack - a.attack).slice(0, 12);
  if (pool.length < 3) pool = unowned.length ? unowned : WEAPONS_CATALOG;

  const shuffled = [...pool].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, Math.min(shuffled.length, rand(3, 4))).map(w => w.id);
}

function checkShopRotation(force = false) {
  const now = Date.now();
  if (force || !GAME.shopStock.nextRotationTime || now >= GAME.shopStock.nextRotationTime || !GAME.shopStock.weapons.length) {
    GAME.shopStock.weapons = pickRotatingWeapons();
    GAME.shopStock.nextRotationTime = now + ROTATION_INTERVAL_MS;
    saveGame();
    addLog('🔄 El stock de armas de la tienda se ha renovado.');
  }
}

function getShopCost(item) {
  if (item.type === 'heal') return applyDiscount(item.baseCost);
  if (item.type === 'weapon') return applyDiscount(item.price);
  const level = Math.floor((GAME.upgrades[item.stat] || 0) / item.amount);
  return applyDiscount(item.baseCost * (level + 1));
}

function renderShop() {
  const shopEl = document.getElementById('shop-list');
  if (!shopEl) return;
  checkShopRotation();

  // Actualizar etiqueta del contador de rotación
  const now = Date.now();
  const timeLeftMs = Math.max(0, GAME.shopStock.nextRotationTime - now);
  const totalSec = Math.ceil(timeLeftMs / 1000);
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  const timerBadge = document.getElementById('shop-timer-badge');
  if (timerBadge) {
    timerBadge.textContent = `⏳ ${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }

  let html = '';

  // 1. Stock Fijo
  FIXED_SHOP_ITEMS.forEach(item => {
    const cost = getShopCost(item);
    let extraInfo = '';
    if (item.type === 'stat') {
      const lvl = Math.floor((GAME.upgrades[item.stat] || 0) / item.amount);
      extraInfo = ` · Nv. ${lvl}`;
    } else if (item.type === 'heal') {
      extraInfo = ` · Posees: ${GAME.fullHeals}`;
    }

    html += `
      <div class="shop-item">
        <span class="shop-emoji">${item.emoji}</span>
        <div class="shop-info">
          <strong>${item.name} <span class="shop-tag">FIJO</span></strong>
          <span>${item.description}${extraInfo}</span>
        </div>
        <button class="btn-neon shop-buy" data-type="fixed" data-id="${item.id}" ${GAME.credits < cost ? 'disabled' : ''}>${fmtNum(cost)}₿</button>
      </div>`;
  });

  // 2. Stock Rotativo de Armas
  GAME.shopStock.weapons.forEach(wId => {
    const weapon = WEAPONS_CATALOG.find(x => x.id === wId);
    if (!weapon) return;
    const isOwned = GAME.weaponsOwned.includes(weapon.id);
    const isEquipped = GAME.equippedWeapon === weapon.id;
    const cost = applyDiscount(weapon.price);
    const perk = getWeaponPerkText(weapon);

    html += `
      <div class="shop-item">
        <span class="shop-emoji">${weapon.emoji}</span>
        <div class="shop-info">
          <strong>${weapon.name} <span class="shop-tag" style="color:var(--neon-yellow);border-color:var(--neon-yellow)">ROTATIVO</span></strong>
          <span>+${weapon.attack} Ataque${perk ? ' · <b style="color:var(--neon-cyan)">' + perk + '</b>' : ''} · ${weapon.desc}</span>
        </div>
        ${isEquipped
          ? `<button class="btn-neon shop-buy" disabled style="color:#00ff88;border-color:#00ff88">EQUIPADA</button>`
          : isOwned
            ? `<button class="btn-neon shop-buy" disabled style="color:var(--text-secondary);border-color:var(--text-secondary)">COMPRADA</button>`
            : `<button class="btn-neon shop-buy" data-type="weapon" data-id="${weapon.id}" ${GAME.credits < cost ? 'disabled' : ''}>${fmtNum(cost)}₿</button>`
        }
      </div>`;
  });

  // 3. Mejoras permanentes adicionales (delantal blindado, implante vital)
  const additionalUpgrades = [
    { id: 'defense', name: 'Delantal blindado', emoji: '🛡️', type: 'stat', description: '+2 defensa permanente', baseCost: 160, stat: 'defense', amount: 2 },
    { id: 'maxHp', name: 'Implante vital', emoji: '❤️', type: 'stat', description: '+25 vida máxima y cura', baseCost: 220, stat: 'maxHp', amount: 25 }
  ];
  additionalUpgrades.forEach(item => {
    const cost = getShopCost(item);
    const level = Math.floor((GAME.upgrades[item.stat] || 0) / item.amount);
    html += `
      <div class="shop-item">
        <span class="shop-emoji">${item.emoji}</span>
        <div class="shop-info">
          <strong>${item.name}</strong>
          <span>${item.description} · Nv. ${level}</span>
        </div>
        <button class="btn-neon shop-buy" data-type="stat_extra" data-id="${item.id}" ${GAME.credits < cost ? 'disabled' : ''}>${fmtNum(cost)}₿</button>
      </div>`;
  });

  // 4. Acceso al Laboratorio (mejoras con niveles)
  html += `
    <div class="shop-item">
      <span class="shop-emoji">🧬</span>
      <div class="shop-info">
        <strong>Laboratorio de Mejoras <span class="shop-tag">29 MEJORAS</span></strong>
        <span>Crítico, robo de vida, esquiva, XP, cocina, servicio y más.</span>
      </div>
      <button class="btn-neon shop-buy" data-type="lab" data-id="lab">ABRIR</button>
    </div>`;

  // Solo tocar el DOM si algo cambió (evita perder toques en móvil al refrescar cada segundo)
  if (shopEl.dataset.lastHtml === html) return;
  shopEl.dataset.lastHtml = html;
  shopEl.innerHTML = html;

  shopEl.querySelectorAll('.shop-buy').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.type;
      const id = btn.dataset.id;
      if (type === 'fixed') buyFixedItem(id);
      else if (type === 'weapon') buyWeapon(id);
      else if (type === 'stat_extra') buyExtraUpgrade(id);
      else if (type === 'lab') openLab();
    });
  });
}

function buyFixedItem(id) {
  const item = FIXED_SHOP_ITEMS.find(x => x.id === id);
  if (!item) return;
  const cost = getShopCost(item);
  if (GAME.credits < cost) { flashMsg('No tienes suficientes créditos.'); return; }

  if (item.id === 'full_heal') {
    GAME.credits -= cost;
    if (GAME.player.hp < GAME.player.maxHp) {
      // Si la vida no está llena, cura inmediatamente
      GAME.player.hp = GAME.player.maxHp;
      addLog(`🧪 Nanobots activados: ¡Vida restaurada al 100%! (${GAME.player.hp}/${GAME.player.maxHp})`);
    } else {
      // Si se compra con la vida llena, se guarda en el inventario para usarse en batallas
      GAME.fullHeals = (GAME.fullHeals || 0) + 1;
      addLog(`🧪 Compraste Nanobots con vida llena. Guardado en inventario (${GAME.fullHeals} disp.) para usar en combate.`);
    }
  } else if (item.stat === 'attack') {
    GAME.credits -= cost;
    GAME.upgrades.attack += item.amount;
    GAME.player.baseAttack += item.amount;
    recalculatePlayerAttack();
    addLog(`🛒 Sobrecarga de cuchillas comprada. Daño aumentado a ${GAME.player.attack}.`);
  }

  saveGame();
  updateHubUI();
}

function buyWeapon(weaponId) {
  const weapon = WEAPONS_CATALOG.find(x => x.id === weaponId);
  if (!weapon) return;
  if (GAME.weaponsOwned.includes(weaponId)) { flashMsg('Ya posees esta arma.'); return; }
  const cost = applyDiscount(weapon.price);
  if (GAME.credits < cost) { flashMsg('No tienes suficientes créditos.'); return; }

  GAME.credits -= cost;
  GAME.weaponsOwned.push(weapon.id);

  // Se equipa automáticamente solo si es mejor que la que llevas puesta
  const current = WEAPONS_CATALOG.find(x => x.id === GAME.equippedWeapon);
  const better = !current || weapon.attack >= current.attack;
  if (better) {
    GAME.equippedWeapon = weapon.id;
    recalculatePlayerAttack();
    addLog(`⚔️ ¡Compraste y equipaste ${weapon.emoji} ${weapon.name}! Daño ajustado directamente a ${GAME.player.attack}.`);
  } else {
    addLog(`⚔️ Compraste ${weapon.emoji} ${weapon.name}. Tu arma actual es más fuerte, así que la dejé equipada (cámbiala en la mochila).`);
  }
  saveGame();
  updateHubUI();
  renderBackpackModal();
}

function buyExtraUpgrade(id) {
  const additionalUpgrades = [
    { id: 'defense', name: 'Delantal blindado', emoji: '🛡️', type: 'stat', description: '+2 defensa permanente', baseCost: 160, stat: 'defense', amount: 2 },
    { id: 'maxHp', name: 'Implante vital', emoji: '❤️', type: 'stat', description: '+25 vida máxima y cura', baseCost: 220, stat: 'maxHp', amount: 25 }
  ];
  const item = additionalUpgrades.find(x => x.id === id);
  if (!item) return;
  const cost = getShopCost(item);
  if (GAME.credits < cost) { flashMsg('No tienes suficientes créditos.'); return; }

  GAME.credits -= cost;
  GAME.upgrades[item.stat] += item.amount;
  if (item.stat === 'maxHp') {
    GAME.player.maxHp += item.amount;
    GAME.player.hp = GAME.player.maxHp;
  } else {
    GAME.player[item.stat] += item.amount;
  }
  addLog(`🛒 Compraste ${item.name}. Mejora aplicada.`);
  saveGame();
  updateHubUI();
}

// Mochila de Armas
function openBackpack() {
  renderBackpackModal();
  const modal = document.getElementById('modal-backpack');
  if (modal) modal.style.display = 'flex';
}

function closeBackpack() {
  const modal = document.getElementById('modal-backpack');
  if (modal) modal.style.display = 'none';
}

function equipWeaponFromBackpack(weaponId) {
  if (weaponId === null) {
    GAME.equippedWeapon = null;
    recalculatePlayerAttack();
    addLog(`🎒 Desequipaste tu arma. Ahora usas Cuchillo Básico. Ataque: ${GAME.player.attack}`);
  } else {
    const w = WEAPONS_CATALOG.find(x => x.id === weaponId);
    if (!w || !GAME.weaponsOwned.includes(weaponId)) return;
    GAME.equippedWeapon = weaponId;
    recalculatePlayerAttack();
    addLog(`🎒 Equipaste ${w.emoji} ${w.name}. Daño ajustado a ${GAME.player.attack}`);
  }
  saveGame();
  updateHubUI();
  renderBackpackModal();
}

function renderBackpackModal() {
  const grid = document.getElementById('backpack-weapons-grid');
  if (!grid) return;

  const currentW = WEAPONS_CATALOG.find(x => x.id === GAME.equippedWeapon);
  setTxt('equipped-weapon-name', currentW ? `${currentW.emoji} ${currentW.name}` : 'Cuchillo Básico (Por Defecto)');
  setTxt('backpack-total-atk', GAME.player.attack);
  setTxt('backpack-base-atk', GAME.player.baseAttack);
  setTxt('backpack-weapon-atk', currentW ? currentW.attack : 0);
  setTxt('backpack-heals-count', GAME.fullHeals || 0);

  let html = '';

  // Opción para arma básica (desequipar arma especial)
  const isBasicEquipped = !GAME.equippedWeapon;
  html += `
    <div class="backpack-weapon-card ${isBasicEquipped ? 'active-weapon' : ''}">
      <span class="weapon-card-emoji">🔪</span>
      <div class="weapon-card-info">
        <strong>Cuchillo Básico de Cocinero</strong>
        <span>Arma reglamentaria entregada a todo chef de Nexus-7.</span>
        <div class="weapon-card-atk">+0 Daño adicional</div>
      </div>
      <div class="weapon-card-action">
        ${isBasicEquipped 
          ? `<span style="color:#00ff88;font-size:.7rem;font-weight:bold">EQUIPADO</span>`
          : `<button class="btn-neon" onclick="equipWeaponFromBackpack(null)">EQUIPAR</button>`
        }
      </div>
    </div>`;

  if (GAME.weaponsOwned.length === 0) {
    html += `<p class="empty-msg" style="padding:1rem 0">No has comprado armas aún. ¡Revisa el stock rotativo de la tienda!</p>`;
  } else {
    const ownedSorted = [...GAME.weaponsOwned].sort((a, b) => {
      const wa = WEAPONS_CATALOG.find(x => x.id === a), wb = WEAPONS_CATALOG.find(x => x.id === b);
      return (wb ? wb.attack : 0) - (wa ? wa.attack : 0);
    });
    ownedSorted.forEach(wId => {
      const w = WEAPONS_CATALOG.find(x => x.id === wId);
      if (!w) return;
      const isEquipped = GAME.equippedWeapon === w.id;
      html += `
        <div class="backpack-weapon-card ${isEquipped ? 'active-weapon' : ''}">
          <span class="weapon-card-emoji">${w.emoji}</span>
          <div class="weapon-card-info">
            <strong>${w.name}</strong>
            <span>${w.desc}</span>
            <div class="weapon-card-atk">+${w.attack} Daño adicional</div>
            ${w.perk ? `<div class="weapon-card-perk">${getWeaponPerkText(w)}</div>` : ''}
          </div>
          <div class="weapon-card-action">
            ${isEquipped 
              ? `<span style="color:#00ff88;font-size:.7rem;font-weight:bold">EQUIPADA</span>`
              : `<button class="btn-neon" onclick="equipWeaponFromBackpack('${w.id}')">EQUIPAR</button>`
            }
          </div>
        </div>`;
    });
  }

  grid.innerHTML = html;
}

// ───────────────────────────── MAP CONSTANTS ─────────────────────────────────
const TILE_SIZE  = 64;
const MAP_COLS   = 9;
const MAP_ROWS   = 6;
const TILE_POOL  = ['street','street','street','alley','alley','building','plaza'];
const TILE_COLOR = {
  street:   '#111222',
  alley:    '#0d1a2e',
  building: '#0a2244',
  plaza:    '#0e1a40'
};

// ─────────────────────────── UTILITY FUNCTIONS ───────────────────────────────
const rand   = (a, b)    => Math.floor(Math.random() * (b - a + 1)) + a;
const clamp  = (v, a, b) => Math.max(a, Math.min(b, v));
const chance = p         => Math.random() < p;

function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('screen-' + name).classList.add('active');
  GAME.screen = name;
}

function addLog(msg) {
  GAME.activityLog.push(msg);
  if (GAME.activityLog.length > 25) GAME.activityLog.shift();
  const el = document.getElementById('activity-log');
  if (el) el.innerHTML = [...GAME.activityLog].reverse()
    .map(l => `<p class="log-entry">${l}</p>`).join('');
}

function addHuntLog(msg) {
  GAME.hunt.log.unshift(msg);
  if (GAME.hunt.log.length > 10) GAME.hunt.log.pop();
  const el = document.getElementById('hunt-log');
  if (el) el.innerHTML = GAME.hunt.log.map(l => `<p class="log-entry">${l}</p>`).join('');
}

// ─────────────────────────────── HUB SCREEN ─────────────────────────────────
function updateHubUI() {
  setTxt('val-credits', fmtNum(GAME.credits));
  setTxt('val-rep',     GAME.reputation);
  setTxt('val-level',   GAME.level);
  setTxt('val-hp',      GAME.player.hp);
  setTxt('val-maxhp',   GAME.player.maxHp);
  setTxt('val-xp',      fmtNum(GAME.xp));
  setTxt('val-xpnext',  fmtNum(GAME.xpToNext));
  setStyle('xp-bar', 'width', (GAME.xp / GAME.xpToNext * 100) + '%');

  const curSec = getCurrentSectorObj();
  setTxt('val-sector-name', `Sector ${curSec.id}`);
  const sign = document.getElementById('restaurant-sign');
  if (sign) {
    sign.textContent = `${curSec.emoji} BARRA METÁLICA · ${curSec.name.toUpperCase()} (Toca para viajar)`;
  }

  renderShop();

  // Inventory
  const entries = Object.entries(GAME.inventory).filter(([, q]) => q > 0);
  const invEl = document.getElementById('inventory-list');
  invEl.innerHTML = entries.length === 0
    ? '<p class="empty-msg">Sin ingredientes. ¡Ve a cazar!</p>'
    : entries.map(([id, qty]) => {
        const i = INGREDIENTS[id];
        return `<div class="inv-item"><span class="inv-emoji">${i.emoji}</span><span class="inv-name">${i.name}</span><span class="inv-qty">×${qty}</span></div>`;
      }).join('');

  // Ready dishes
  const dishEl = document.getElementById('dishes-list');
  if (GAME.readyDishes.length === 0) {
    dishEl.innerHTML = '<p class="empty-msg">Sin platos preparados.</p>';
  } else {
    const g = {};
    GAME.readyDishes.forEach(d => { g[d.recipeId] = (g[d.recipeId] || 0) + 1; });
    dishEl.innerHTML = Object.entries(g).map(([rid, qty]) => {
      const r = RECIPES.find(x => x.id === rid);
      return `<div class="inv-item"><span class="inv-emoji">${r.emoji}</span><span class="inv-name">${r.name}</span><span class="inv-qty">×${qty}</span></div>`;
    }).join('');
  }

  // Activity log
  const al = document.getElementById('activity-log');
  if (al) al.innerHTML = [...GAME.activityLog].reverse()
    .map(l => `<p class="log-entry">${l}</p>`).join('');
}

function gainXP(amount) {
  GAME.xp += amount;
  while (GAME.xp >= GAME.xpToNext) {
    GAME.xp      -= GAME.xpToNext;
    const newLevel = GAME.level + 1;
    // Hasta el nivel 20 la curva es la original; después crece más suave (ver EXP_BAL)
    GAME.xpToNext = Math.floor(GAME.xpToNext * getXpGrowthForLevel(newLevel));
    GAME.level    = newLevel;
    const gains = getLevelGains(newLevel);
    GAME.player.maxHp += gains.hp;
    GAME.player.hp     = GAME.player.maxHp;
    if (GAME.player.baseAttack === undefined) {
      GAME.player.baseAttack = 15;
    }
    GAME.player.baseAttack += gains.atk;
    recalculatePlayerAttack();
    GAME.player.defense += gains.def;
    // Bonus de créditos por nivel
    const lvlBonus = GAME.level * 25;
    GAME.credits += lvlBonus;
    addLog(`⬆️ ¡NIVEL ${GAME.level}! +${gains.hp} HP máx, +${gains.atk} ataque, +${gains.def} defensa, +${lvlBonus}₿ bonus.`);
    checkLevelMilestone(GAME.level);
  }
  saveGame();
}

function checkLevelMilestone(lvl) {
  const milestone = LEVEL_MILESTONES[lvl];
  if (!milestone) return;
  if (GAME.claimedMilestones.includes(lvl)) return;
  GAME.claimedMilestones.push(lvl);

  // Recompensas base
  GAME.credits   += milestone.credits;
  GAME.fullHeals  = (GAME.fullHeals || 0) + milestone.heals;

  // Recompensa especial
  if (milestone.rewardType === 'weapon') {
    const wId = milestone.weaponId;
    if (!GAME.weaponsOwned.includes(wId)) {
      GAME.weaponsOwned.push(wId);
      GAME.equippedWeapon = wId;
      recalculatePlayerAttack();
    }
  } else if (milestone.rewardType === 'ability') {
    const aid = milestone.abilityId;
    if (!GAME.abilities.includes(aid)) {
      GAME.abilities.push(aid);
    }
  }

  addLog(`🏆 ${milestone.title}`);
  addLog(`🎁 ${milestone.description}`);

  // Mostrar popup de recompensa
  showMilestonePopup(milestone);
}

function showMilestonePopup(milestone) {
  // Crear overlay de recompensa
  let overlay = document.getElementById('milestone-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'milestone-overlay';
    overlay.className = 'milestone-overlay';
    document.body.appendChild(overlay);
  }
  overlay.innerHTML = `
    <div class="milestone-box">
      <div class="milestone-title">${milestone.title}</div>
      <div class="milestone-desc">${milestone.description}</div>
      <div class="milestone-rewards">
        <span class="milestone-tag">💳 +${milestone.credits.toLocaleString()}₿</span>
        <span class="milestone-tag">🧪 +${milestone.heals} Curaciones</span>
        ${milestone.rewardType === 'weapon' ? `<span class="milestone-tag">${milestone.weaponName}</span>` : ''}
        ${milestone.rewardType === 'ability' ? `<span class="milestone-tag">${milestone.abilityName}</span>` : ''}
      </div>
      <button class="btn-neon" onclick="document.getElementById('milestone-overlay').style.display='none'">✅ ¡RECLAMAR!</button>
    </div>
  `;
  overlay.style.display = 'flex';
}

// ─────────────────────────── HUNT (CAZA) SCREEN ──────────────────────────────
function getSectorDifficultyInfo(sectorId) {
  const sId = sectorId || GAME.currentSector || 1;
  const sectorConfigs = {
    1:  { hpMult: 0.55, atkMult: 0.60, defBonus: -2, xpMult: 0.70, credMult: 0.75, name: 'FÁCIL',      color: '#00ff88', emoji: '🟢', tierWeights: { common: 100, uncommon: 0,  elite: 0,  boss: 0  } },
    2:  { hpMult: 0.75, atkMult: 0.75, defBonus: -1, xpMult: 0.90, credMult: 0.90, name: 'APRENDIZ',   color: '#70ff00', emoji: '🟢', tierWeights: { common: 80,  uncommon: 20, elite: 0,  boss: 0  } },
    3:  { hpMult: 1.00, atkMult: 1.00, defBonus:  0, xpMult: 1.10, credMult: 1.10, name: 'MEDIO',      color: '#ffff00', emoji: '🟡', tierWeights: { common: 60,  uncommon: 35, elite: 5,  boss: 0  } },
    4:  { hpMult: 1.30, atkMult: 1.25, defBonus: +1, xpMult: 1.40, credMult: 1.40, name: 'RETADOR',    color: '#ffaa00', emoji: '🟠', tierWeights: { common: 40,  uncommon: 45, elite: 15, boss: 0  } },
    5:  { hpMult: 1.65, atkMult: 1.50, defBonus: +2, xpMult: 1.75, credMult: 1.80, name: 'DIFÍCIL',    color: '#ff6600', emoji: '🔴', tierWeights: { common: 25,  uncommon: 45, elite: 25, boss: 5  } },
    6:  { hpMult: 2.10, atkMult: 1.80, defBonus: +4, xpMult: 2.20, credMult: 2.30, name: 'EXPERTO',    color: '#ff3300', emoji: '🔥', tierWeights: { common: 15,  uncommon: 40, elite: 35, boss: 10 } },
    7:  { hpMult: 2.65, atkMult: 2.20, defBonus: +6, xpMult: 2.80, credMult: 2.90, name: 'HERÓICO',    color: '#ff0055', emoji: '💀', tierWeights: { common: 10,  uncommon: 30, elite: 40, boss: 20 } },
    8:  { hpMult: 3.30, atkMult: 2.65, defBonus: +8, xpMult: 3.50, credMult: 3.60, name: 'MORTAL',     color: '#cc00ff', emoji: '☠️', tierWeights: { common: 0,   uncommon: 30, elite: 45, boss: 25 } },
    9:  { hpMult: 4.10, atkMult: 3.20, defBonus: +11, xpMult: 4.40, credMult: 4.60, name: 'LEYENDA',   color: '#aa00ff', emoji: '⚡', tierWeights: { common: 0,   uncommon: 20, elite: 50, boss: 30 } },
    10: { hpMult: 5.00, atkMult: 3.80, defBonus: +14, xpMult: 5.50, credMult: 5.80, name: 'PESADILLA', color: '#ff00ff', emoji: '👑', tierWeights: { common: 0,   uncommon: 10, elite: 50, boss: 40 } }
  };
  if (sectorConfigs[sId]) return sectorConfigs[sId];
  if (sId > 10) return buildExpandedSectorDifficulty(sId);   // sectores 11-110 (data_expansion.js)
  return sectorConfigs[1];
}

function pickBeastForSector(sectorId) {
  const sId = sectorId || GAME.currentSector || 1;
  const diffInfo = getSectorDifficultyInfo(sId);
  const weights = diffInfo.tierWeights;

  const randVal = Math.random() * 100;
  let accumulated = 0;
  let chosenTier = 'common';

  for (const [tier, weight] of Object.entries(weights)) {
    accumulated += weight;
    if (randVal <= accumulated && weight > 0) {
      chosenTier = tier;
      break;
    }
  }

  // Cada bestia tiene una ventana de aparición [minSector, maxSector]
  const inWindow = b => (b.minSector || 1) <= sId && sId <= (b.maxSector || 9999);
  let validBeasts = BEASTS.filter(b => inWindow(b) && b.tier === chosenTier);
  if (!validBeasts.length) {
    validBeasts = BEASTS.filter(inWindow);
  }
  if (!validBeasts.length) {
    validBeasts = BEASTS.filter(b => b.tier === 'common');
  }

  return validBeasts[rand(0, validBeasts.length - 1)];
}

function spawnBeasts() {
  const sId = GAME.currentSector || 1;
  const diffInfo = getSectorDifficultyInfo(sId);
  const count = rand(4, Math.min(8, 4 + Math.floor(GAME.level / 2)));
  const beasts = [];
  const used   = [{ ...GAME.hunt.playerPos }];

  for (let i = 0; i < count; i++) {
    const tmpl = pickBeastForSector(sId);

    const scaledHp      = Math.max(20, Math.round(tmpl.hp * diffInfo.hpMult));
    const minAtk        = Math.max(2, Math.round(tmpl.attack[0] * diffInfo.atkMult));
    const maxAtk        = Math.max(minAtk + 2, Math.round(tmpl.attack[1] * diffInfo.atkMult));
    const scaledDef     = Math.max(0, tmpl.defense + diffInfo.defBonus);
    const scaledXp      = Math.max(10, Math.round(tmpl.xp * diffInfo.xpMult));
    const scaledCredits = Math.max(15, Math.round(tmpl.credits * diffInfo.credMult));

    let pos, tries = 0;
    do {
      pos = { x: rand(0, MAP_COLS - 1), y: rand(0, MAP_ROWS - 1) };
      tries++;
    } while (used.some(u => u.x === pos.x && u.y === pos.y) && tries < 60);

    used.push(pos);
    beasts.push({
      ...tmpl,
      hp: scaledHp,
      maxHp: scaledHp,
      attack: [minAtk, maxAtk],
      defense: scaledDef,
      xp: scaledXp,
      credits: scaledCredits,
      pos,
      currentHp: scaledHp,
      sectorLevel: sId,
      uid: `b_${i}_${Date.now()}`
    });
  }
  return beasts;
}

function generateMap() {
  const map = [];
  for (let y = 0; y < MAP_ROWS; y++) {
    const row = [];
    for (let x = 0; x < MAP_COLS; x++) {
      const tile = TILE_POOL[rand(0, TILE_POOL.length - 1)];
      row.push(tile);
    }
    map.push(row);
  }
  map[0][0] = 'street';
  return map;
}

function enterHunt() {
  const curS = getCurrentSectorObj();
  const diffInfo = getSectorDifficultyInfo(curS.id);
  GAME.player.hp = Math.min(GAME.player.maxHp, GAME.player.hp + Math.max(20, Math.floor(GAME.player.maxHp * getStat('huntheal'))));
  GAME.hunt.map       = generateMap();
  GAME.hunt.playerPos = { x: 0, y: 0 };
  GAME.hunt.beasts    = spawnBeasts();
  GAME.hunt.log       = [
    `Entrando al ${curS.name}...`,
    `Dificultad de Bestias: ${diffInfo.emoji} ${diffInfo.name}`,
    '¡Cuidado, hay bestias cerca!'
  ];

  const huntTitleEl = document.querySelector('.hunt-title');
  if (huntTitleEl) {
    huntTitleEl.innerHTML = `🗺️ NEXUS-7 — ${curS.name.toUpperCase()} <span style="color:${diffInfo.color}; font-weight:bold;">[${diffInfo.emoji} ${diffInfo.name}]</span>`;
  }

  showScreen('hunt');
  initHuntCanvas();
  renderHuntSidebar();
}

// Canvas
let huntCtx = null;
let _huntKeyHandler = null;

function initHuntCanvas() {
  const canvas = document.getElementById('hunt-canvas');
  huntCtx = canvas.getContext('2d');
  if (_huntKeyHandler) document.removeEventListener('keydown', _huntKeyHandler);
  _huntKeyHandler = handleHuntKey;
  document.addEventListener('keydown', _huntKeyHandler);
  drawMap();
}

function handleHuntKey(e) {
  if (GAME.screen !== 'hunt') return;
  const dirs = {
    ArrowLeft: [-1,0], ArrowRight:[1,0], ArrowUp:[0,-1], ArrowDown:[0,1],
    a:[-1,0], d:[1,0], w:[0,-1], s:[0,1],
    A:[-1,0], D:[1,0], W:[0,-1], S:[0,1]
  };
  if (!dirs[e.key]) return;
  e.preventDefault();
  const [dx, dy] = dirs[e.key];
  movePlayer(dx, dy);
}

function movePlayer(dx, dy) {
  const nx = clamp(GAME.hunt.playerPos.x + dx, 0, MAP_COLS - 1);
  const ny = clamp(GAME.hunt.playerPos.y + dy, 0, MAP_ROWS - 1);
  const beast = GAME.hunt.beasts.find(b => b.pos.x === nx && b.pos.y === ny);
  if (beast) { startCombat(beast); return; }
  GAME.hunt.playerPos.x = nx;
  GAME.hunt.playerPos.y = ny;
  drawMap();
}

function drawMap() {
  if (!huntCtx) return;
  const ctx = huntCtx;
  ctx.clearRect(0, 0, MAP_COLS * TILE_SIZE, MAP_ROWS * TILE_SIZE);

  for (let y = 0; y < MAP_ROWS; y++) {
    for (let x = 0; x < MAP_COLS; x++) {
      const px = x * TILE_SIZE, py = y * TILE_SIZE;
      const tile = GAME.hunt.map[y][x];

      ctx.fillStyle = TILE_COLOR[tile] || '#111';
      ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

      // Grid lines
      ctx.strokeStyle = 'rgba(0,255,200,.12)';
      ctx.lineWidth = 1;
      ctx.strokeRect(px, py, TILE_SIZE, TILE_SIZE);

      // Tile details
      if (tile === 'building') {
        ctx.fillStyle = 'rgba(0,80,180,.18)';
        ctx.fillRect(px + 8, py + 8, TILE_SIZE - 16, TILE_SIZE - 16);
        // windows
        [[14,14],[30,14],[14,28],[30,28]].forEach(([wx,wy]) => {
          ctx.fillStyle = Math.random() > .35 ? 'rgba(255,200,50,.35)' : 'rgba(0,100,200,.35)';
          ctx.fillRect(px + wx, py + wy, 9, 7);
        });
      } else if (tile === 'plaza') {
        ctx.strokeStyle = 'rgba(0,255,200,.22)';
        ctx.beginPath();
        ctx.moveTo(px+14, py+32); ctx.lineTo(px + TILE_SIZE-14, py+32);
        ctx.stroke();
      }
    }
  }

  // Beasts
  GAME.hunt.beasts.forEach(b => {
    const px = b.pos.x * TILE_SIZE + TILE_SIZE/2;
    const py = b.pos.y * TILE_SIZE + TILE_SIZE/2;
    const bx = b.pos.x * TILE_SIZE;
    const by = b.pos.y * TILE_SIZE;

    const g = ctx.createRadialGradient(px, py, 0, px, py, TILE_SIZE/2);
    g.addColorStop(0, b.color + '55');
    g.addColorStop(1, 'transparent');
    ctx.fillStyle = g;
    ctx.fillRect(bx, by, TILE_SIZE, TILE_SIZE);

    ctx.font = '30px serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(b.emoji, px, py);

    // HP mini-bar
    const ratio = b.currentHp / b.maxHp;
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(bx+4, by+4, TILE_SIZE-8, 5);
    ctx.fillStyle = ratio > .5 ? '#00ff88' : ratio > .25 ? '#ffaa00' : '#ff1144';
    ctx.fillRect(bx+4, by+4, (TILE_SIZE-8) * ratio, 5);
  });

  // Player
  const ppx = GAME.hunt.playerPos.x * TILE_SIZE + TILE_SIZE/2;
  const ppy = GAME.hunt.playerPos.y * TILE_SIZE + TILE_SIZE/2;
  const pbx = GAME.hunt.playerPos.x * TILE_SIZE;
  const pby = GAME.hunt.playerPos.y * TILE_SIZE;

  const pg = ctx.createRadialGradient(ppx, ppy, 0, ppx, ppy, TILE_SIZE/2);
  pg.addColorStop(0, 'rgba(0,255,200,.38)');
  pg.addColorStop(1, 'transparent');
  ctx.fillStyle = pg;
  ctx.fillRect(pbx, pby, TILE_SIZE, TILE_SIZE);

  ctx.font = '30px serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('👨‍🍳', ppx, ppy);

  ctx.strokeStyle = '#00ffcc';
  ctx.lineWidth = 2;
  ctx.strokeRect(pbx+2, pby+2, TILE_SIZE-4, TILE_SIZE-4);

  // Update HP bar
  const hpRatio = GAME.player.hp / GAME.player.maxHp;
  setStyle('hunt-hp-bar', 'width', (hpRatio * 100) + '%');
  setStyle('hunt-hp-bar', 'background',
    hpRatio > .5 ? 'linear-gradient(90deg,#00ff88,#00cc66)' :
    hpRatio > .25 ? 'linear-gradient(90deg,#ffaa00,#cc8800)' :
                    'linear-gradient(90deg,#ff1144,#cc0033)');
  setTxt('hunt-hp-text', `${GAME.player.hp}/${GAME.player.maxHp}`);
}

function renderHuntSidebar() {
  const el = document.getElementById('beast-list-sidebar');
  if (!el) return;
  if (GAME.hunt.beasts.length === 0) {
    el.innerHTML = '<p class="empty-msg">¡Sector limpiado!</p>';
    return;
  }
  el.innerHTML = GAME.hunt.beasts.map(b =>
    `<div class="beast-sidebar-item">
       <span>${b.emoji}</span>
       <span style="flex:1">${b.name}</span>
       <span class="beast-hp-tiny">${b.currentHp}/${b.maxHp}</span>
     </div>`
  ).join('');
}

// ─────────────────────────────── COMBAT ──────────────────────────────────────
function startCombat(beast) {
  GAME.combat.beast     = beast;
  GAME.combat.beastHp   = beast.currentHp;
  GAME.combat.log       = [`⚔️ ¡${beast.name} te ataca!`];
  GAME.combat.turn      = 'player';
  GAME.combat.defending = false;
  GAME.combat.animating = false;
  GAME.combat.phoenixUsed = false;
  GAME.combat.secondWindUsed = false;
  showScreen('combat');
  refreshCombatUI();
}

function refreshCombatUI() {
  const b = GAME.combat.beast;
  if (!b) return;
  const diffInfo = getSectorDifficultyInfo(b.sectorLevel || GAME.currentSector || 1);
  setTxt('combat-beast-emoji', b.emoji);
  setTxt('combat-beast-name',  `${b.name} (${diffInfo.emoji} Sector ${b.sectorLevel || GAME.currentSector || 1})`);
  setTxt('combat-beast-lore',  `${b.lore} [Dificultad: ${diffInfo.name} · Def: ${b.defense}]`);

  const br = GAME.combat.beastHp / b.maxHp;
  setStyle('combat-beast-hp-bar', 'width', (br*100)+'%');
  setStyle('combat-beast-hp-bar', 'background',
    br > .5 ? 'linear-gradient(90deg,#ff4455,#ff1144)' :
    br > .25 ? 'linear-gradient(90deg,#ffaa00,#cc8800)' :
               'linear-gradient(90deg,#aa0033,#660022)');
  setTxt('combat-beast-hp-text', `${GAME.combat.beastHp}/${b.maxHp}`);

  const pr = GAME.player.hp / GAME.player.maxHp;
  setStyle('combat-player-hp-bar', 'width', (pr*100)+'%');
  setStyle('combat-player-hp-bar', 'background',
    pr > .5 ? 'linear-gradient(90deg,#00ff88,#00cc66)' :
    pr > .25 ? 'linear-gradient(90deg,#ffaa00,#cc8800)' :
               'linear-gradient(90deg,#ff1144,#cc0033)');
  setTxt('combat-player-hp-text', `${GAME.player.hp}/${GAME.player.maxHp}`);

  // Log
  const logEl = document.getElementById('combat-log');
  logEl.innerHTML = GAME.combat.log.slice(-6)
    .map(l => `<p class="combat-log-entry">${l}</p>`).join('');
  logEl.scrollTop = logEl.scrollHeight;

  // Turn indicator
  const turnEl = document.getElementById('turn-indicator');
  turnEl.textContent = GAME.combat.turn === 'player' ? 'TU TURNO' : 'TURNO ENEMIGO';
  turnEl.className   = 'turn-indicator ' + (GAME.combat.turn === 'player' ? 'player-turn' : 'enemy-turn');

  const enabled = GAME.combat.turn === 'player' && !GAME.combat.animating;
  ['btn-attack','btn-defend','btn-special','btn-flee'].forEach(id => {
    document.getElementById(id).disabled = !enabled;
  });

  const healBtn = document.getElementById('btn-combat-heal');
  const healCountSpan = document.getElementById('combat-heal-count');
  if (healBtn && healCountSpan) {
    const healsAvailable = GAME.fullHeals || 0;
    healCountSpan.textContent = healsAvailable;
    if (healsAvailable > 0) {
      healBtn.style.display = 'block';
      healBtn.disabled = !enabled || (GAME.player.hp >= GAME.player.maxHp);
    } else {
      healBtn.style.display = 'none';
    }
  }
}

function useCombatHeal() {
  if (GAME.combat.turn !== 'player' || GAME.combat.animating) return;
  if (!GAME.fullHeals || GAME.fullHeals <= 0) {
    flashMsg('No tienes curaciones completas en tu inventario.');
    return;
  }
  if (GAME.player.hp >= GAME.player.maxHp) {
    flashMsg('Ya tienes la salud completa.');
    return;
  }

  GAME.fullHeals--;
  GAME.player.hp = GAME.player.maxHp;
  GAME.combat.log.push(`🧪 ¡Usaste una Curación Completa! Restauraste 100% de PS (${GAME.player.hp}/${GAME.player.maxHp}).`);
  saveGame();
  refreshCombatUI();
}

function playerAttack(type) {
  if (GAME.combat.turn !== 'player' || GAME.combat.animating) return;
  GAME.combat.animating = true;
  GAME.combat.defending = false;

  const b = GAME.combat.beast;
  let dmg = 0, msg = '';
  const weaponObj = WEAPONS_CATALOG.find(x => x.id === GAME.equippedWeapon);
  const weaponName = weaponObj ? weaponObj.name : 'cuchillo de carnicero';

  // Stats de la expansión (mejoras + perk del arma + habilidades)
  const effDef   = Math.max(0, Math.floor(b.defense * (1 - getStat('pierce'))));
  const execMult = (GAME.combat.beastHp / b.maxHp) < 0.3 ? 1 + getStat('exec') : 1;
  const critMult = 1.5 + getStat('critdmg');
  const atk      = GAME.player.attack;

  switch (type) {
    case 'attack': {
      let baseDmg = Math.max(1, rand(atk - 4, atk + 6) - effDef);
      // Habilidad pasiva: Sobrecarga de Filo → +15% daño crítico
      if (GAME.abilities && GAME.abilities.includes('overcharge') && chance(0.35)) {
        baseDmg = Math.floor(baseDmg * 1.15);
        msg = `⚡ ¡GOLPE CRÍTICO con ${weaponName}! ${baseDmg} de daño (Sobrecarga).`;
      } else {
        msg = `⚔️ ¡Atacas con ${weaponName}! ${baseDmg} de daño.`;
      }
      // Crítico de laboratorio / arma
      if (chance(getStat('crit'))) {
        baseDmg = Math.floor(baseDmg * critMult);
        msg = `💢 ¡CRÍTICO con ${weaponName}! ${baseDmg} de daño.`;
      }
      baseDmg = Math.floor(baseDmg * execMult);
      if (execMult > 1) msg += ' ☠️ ¡Ejecución!';
      // Golpe doble
      if (chance(getStat('double'))) {
        const second = Math.max(1, Math.floor(Math.max(1, rand(atk - 4, atk + 6) - effDef) * execMult));
        baseDmg += second;
        msg += ` ⚡ ¡Golpe doble! +${second}.`;
      }
      dmg = baseDmg;
      break;
    }
    case 'defend':
      GAME.combat.defending = true;
      msg = '🛡️ Te pones en guardia. Daño reducido este turno.';
      break;
    case 'special':
      if (chance(0.65 + getStat('specialacc'))) {
        dmg = Math.max(1, Math.floor(Math.max(1, rand(atk, atk * 2) - effDef) * (1 + getStat('special')) * execMult));
        msg = `💥 ¡CORTE ESPECIAL! ${dmg} de daño masivo.`;
      } else {
        msg = '💥 ¡Fallaste el especial! El monstruo se ríe de ti.';
      }
      break;
    case 'flee':
      if (chance(.5)) {
        GAME.combat.log.push('🏃 ¡Escapaste corriendo!');
        refreshCombatUI();
        setTimeout(() => { showScreen('hunt'); drawMap(); }, 900);
        GAME.combat.animating = false;
        return;
      } else {
        msg = '🏃 No pudiste escapar. El monstruo bloquea la salida.';
      }
      break;
  }

  if (dmg > 0) {
    GAME.combat.beastHp          = Math.max(0, GAME.combat.beastHp - dmg);
    GAME.combat.beast.currentHp  = GAME.combat.beastHp;
    // Robo de vida
    const steal = getStat('lifesteal');
    if (steal > 0) {
      const heal = Math.min(GAME.player.maxHp - GAME.player.hp, Math.floor(dmg * steal));
      if (heal > 0) { GAME.player.hp += heal; msg += ` 🩸 +${heal} PS.`; }
    }
  }
  GAME.combat.log.push(msg);
  refreshCombatUI();

  if (GAME.combat.beastHp <= 0) { setTimeout(combatVictory, 600); return; }

  GAME.combat.turn = 'enemy';
  refreshCombatUI();
  setTimeout(enemyTurn, 1100);
}

function enemyTurn() {
  const b = GAME.combat.beast;
  const p = GAME.player;

  if (chance(getStat('dodge'))) {
    GAME.combat.log.push(`💨 ¡Esquivaste el ataque de ${b.name}!`);
  } else {
    let dmg = Math.max(1, rand(b.attack[0], b.attack[1]) - p.defense);
    if (GAME.combat.defending) dmg = Math.max(1, Math.floor(dmg * 0.45));
    // Habilidad pasiva: Escudo de Nanocélulas → -25% daño enemigo permanente
    let shieldNote = '';
    if (GAME.abilities && GAME.abilities.includes('nanoshield')) {
      dmg = Math.max(1, Math.floor(dmg * 0.75));
      shieldNote = ' [🛡️ Nanoscudo -25%]';
    }
    // Campo de fuerza (laboratorio / arma)
    const reduce = getStat('reduce');
    if (reduce > 0) {
      dmg = Math.max(1, Math.floor(dmg * (1 - reduce)));
      shieldNote += ` [🔰 -${Math.round(reduce * 100)}%]`;
    }

    // Golpe mortal: Fénix Mecánico / Segundo Aliento
    if (p.hp - dmg <= 0) {
      if (!GAME.combat.phoenixUsed && GAME.abilities && GAME.abilities.includes('phoenix')) {
        GAME.combat.phoenixUsed = true;
        p.hp = Math.max(1, Math.ceil(p.maxHp * 0.5));
        GAME.combat.log.push(`🔥 ¡FÉNIX MECÁNICO! Renaces con ${p.hp} PS.`);
        dmg = 0;
      } else if (!GAME.combat.secondWindUsed && chance(getStat('secondwind'))) {
        GAME.combat.secondWindUsed = true;
        p.hp = Math.max(1, Math.ceil(p.maxHp * 0.25));
        GAME.combat.log.push(`🔁 ¡SEGUNDO ALIENTO! Sobrevives con ${p.hp} PS.`);
        dmg = 0;
      }
    }

    if (dmg > 0) {
      p.hp = Math.max(0, p.hp - dmg);
      GAME.combat.log.push(`${b.emoji} ${b.name} te ataca. ${dmg} de daño${GAME.combat.defending ? ' (bloqueado)' : ''}${shieldNote}.`);
      // Espinas reactivas
      const reflect = Math.floor(dmg * getStat('thorns'));
      if (reflect > 0 && p.hp > 0) {
        GAME.combat.beastHp = Math.max(0, GAME.combat.beastHp - reflect);
        GAME.combat.beast.currentHp = GAME.combat.beastHp;
        GAME.combat.log.push(`🌵 Tus espinas devuelven ${reflect} de daño.`);
      }
    }
  }

  // Nanoregeneración
  const regen = getStat('regen');
  if (regen > 0 && p.hp > 0 && p.hp < p.maxHp) {
    const heal = Math.min(p.maxHp - p.hp, Math.max(1, Math.floor(p.maxHp * regen)));
    p.hp += heal;
    GAME.combat.log.push(`💚 Nanoregeneración: +${heal} PS.`);
  }

  GAME.combat.animating = false;
  GAME.combat.turn      = 'player';
  refreshCombatUI();
  saveGame();
  if (p.hp <= 0) setTimeout(combatDefeat, 600);
  else if (GAME.combat.beastHp <= 0) setTimeout(combatVictory, 600);
}

function combatVictory() {
  const b = GAME.combat.beast;
  const drops = [];
  const dropBonus = 1 + getStat('droppct');
  b.drops.forEach(drop => {
    if (chance(Math.min(1, drop.chance * dropBonus))) {
      let qty = rand(drop.qty[0], drop.qty[1]);
      if (chance(getStat('lootqty'))) qty *= 2;
      GAME.inventory[drop.id] = (GAME.inventory[drop.id] || 0) + qty;
      drops.push({ id: drop.id, qty });
    }
  });
  const xpGain     = Math.floor(b.xp * (1 + getStat('xppct')));
  const creditGain = Math.floor(b.credits * (1 + getStat('creditpct')));
  gainXP(xpGain);
  GAME.credits    += creditGain;
  GAME.reputation += Math.floor(b.xp / 8);
  GAME.hunt.beasts = GAME.hunt.beasts.filter(x => x.uid !== b.uid);
  saveGame();

  addLog(`✅ Derrotaste: ${b.emoji} ${b.name}`);
  showResultOverlay(
    'victoria',
    '🏆 VICTORIA',
    drops.map(d => {
      const ing = INGREDIENTS[d.id];
      return `<span class="drop-item">${ing.emoji} ${ing.name} ×${d.qty}</span>`;
    }).join(''),
    `💳 +${fmtNum(creditGain)}₿ · ⭐ +${fmtNum(xpGain)} XP`,
    () => {
      if (GAME.hunt.beasts.length === 0) {
        addLog('🎉 ¡Sector limpiado! Regresando al hub.');
        showScreen('hub'); updateHubUI();
      } else {
        showScreen('hunt'); drawMap(); renderHuntSidebar();
        addHuntLog(`${b.emoji} ${b.name} eliminado.`);
      }
    }
  );
}

function combatDefeat() {
  GAME.player.hp = Math.max(1, Math.floor(GAME.player.maxHp * 0.28));
  addLog('💀 Fuiste derrotado. Regresaste al hub malherido.');
  showResultOverlay(
    'defeat',
    '💀 DERROTA',
    '<span class="drop-item">Regresaste malherido al restaurante...</span>',
    `❤️ HP restaurado al ${Math.round(GAME.player.hp/GAME.player.maxHp*100)}%`,
    () => { showScreen('hub'); updateHubUI(); }
  );
}

function showResultOverlay(type, title, dropsHtml, creditsHtml, onContinue) {
  const overlay = document.getElementById('combat-result');
  overlay.style.display = 'flex';
  const t = document.getElementById('result-title');
  t.textContent = title;
  t.className = 'result-title ' + (type === 'victoria' ? 'victory' : 'defeat');
  document.getElementById('result-drops').innerHTML =
    `<div class="drops-title">📦 DROPS:</div>${dropsHtml}`;
  document.getElementById('result-credits').innerHTML = creditsHtml;
  const btn = document.getElementById('btn-result-continue');
  btn.onclick = () => { overlay.style.display = 'none'; onContinue(); };
}

// ─────────────────────────── COOK (COCINA) SCREEN ────────────────────────────
function enterCook() {
  GAME.cook.selected      = [];
  GAME.cook.phase         = 'select';
  GAME.cook.currentRecipe = null;
  if (GAME.cook.barInterval) { clearInterval(GAME.cook.barInterval); GAME.cook.barInterval = null; }

  showScreen('cook');
  showCookPhase('select');
  refreshCookUI();
}

function showCookPhase(phase) {
  ['select','timing','result'].forEach(p => {
    document.getElementById('cook-phase-' + p).style.display = p === phase ? 'flex' : 'none';
  });
  GAME.cook.phase = phase;
}

function refreshCookUI() {
  // Ingredients
  const entries = Object.entries(GAME.inventory).filter(([, q]) => q > 0);
  const ingEl = document.getElementById('cook-ingredient-list');
  ingEl.innerHTML = entries.length === 0
    ? '<p class="empty-msg">Sin ingredientes.</p>'
    : entries.map(([id, qty]) => {
        const ing = INGREDIENTS[id];
        return `<div class="ingredient-card" onclick="addIngredient('${id}')">
          <span class="ing-emoji">${ing.emoji}</span>
          <span class="ing-name">${ing.name}</span>
          <span class="ing-qty">×${qty}</span>
        </div>`;
      }).join('');

  // Recipes reference (con filtro y búsqueda: ahora son más de 100)
  const recEl = document.getElementById('recipe-list');
  const canMakeRecipe = r => {
    const needed = {};
    r.ingredients.forEach(i => { needed[i] = (needed[i] || 0) + 1; });
    return Object.entries(needed).every(([id, n]) => (GAME.inventory[id] || 0) >= n);
  };
  let list = RECIPES.map(r => ({ r, can: canMakeRecipe(r) }));
  const q = (GAME.ui.recipeSearch || '').trim().toLowerCase();
  if (q) {
    list = list.filter(x => x.r.name.toLowerCase().includes(q) ||
      x.r.ingredients.some(i => ((INGREDIENTS[i] && INGREDIENTS[i].name) || '').toLowerCase().includes(q)));
  }
  if (GAME.ui.recipeOnlyCookable) list = list.filter(x => x.can);
  list.sort((a, b) => Number(b.can) - Number(a.can));   // primero las que puedes cocinar

  const cookableCount = RECIPES.filter(canMakeRecipe).length;
  const filterBtn = document.getElementById('btn-recipe-filter');
  if (filterBtn) {
    filterBtn.textContent = GAME.ui.recipeOnlyCookable ? '✅ Solo cocinables' : '📚 Ver todas';
    filterBtn.classList.toggle('active', !!GAME.ui.recipeOnlyCookable);
  }
  setTxt('recipe-count', `${cookableCount} cocinables · ${RECIPES.length} recetas`);

  recEl.innerHTML = list.length === 0
    ? '<p class="empty-msg">No hay recetas que coincidan.</p>'
    : list.map(({ r, can }) => {
        const names = r.ingredients.map(i => (INGREDIENTS[i] ? INGREDIENTS[i].name : i)).join(' + ');
        return `<div class="recipe-card ${can ? 'can-make' : 'cant-make'}" title="${names}" ${can ? `onclick="autoFillRecipe('${r.id}')" style="cursor:pointer"` : ''}>
          <span class="rec-emoji">${r.emoji}</span>
          <span class="rec-name">${r.name}<small class="rec-ing-names">${names}</small></span>
          <span class="rec-ingredients">${r.ingredients.map(i => INGREDIENTS[i]?.emoji || '?').join('')}</span>
          <span class="rec-price">💳 ${fmtNum(r.basePrice)}₿</span>
        </div>`;
      }).join('');

  refreshSlots();
}

// Toca una receta cocinable y se cargan sus ingredientes solos
function autoFillRecipe(id) {
  if (GAME.cook.phase !== 'select') return;
  const r = RECIPES.find(x => x.id === id);
  if (!r) return;
  const needed = {};
  r.ingredients.forEach(i => { needed[i] = (needed[i] || 0) + 1; });
  if (!Object.entries(needed).every(([iid, n]) => (GAME.inventory[iid] || 0) >= n)) {
    flashMsg('Te faltan ingredientes para esta receta.');
    return;
  }
  GAME.cook.selected = [...r.ingredients];
  refreshSlots();
}

function addIngredient(id) {
  if (GAME.cook.selected.length >= 3) return;
  const needed = GAME.cook.selected.filter(x => x === id).length + 1;
  if ((GAME.inventory[id] || 0) < needed) {
    flashMsg('¡No tienes suficiente!'); return;
  }
  GAME.cook.selected.push(id);
  refreshSlots();
}

function removeIngredient(idx) {
  GAME.cook.selected.splice(idx, 1);
  refreshSlots();
}

function refreshSlots() {
  document.querySelectorAll('.recipe-slot').forEach((slot, i) => {
    const id = GAME.cook.selected[i];
    if (id) {
      slot.textContent = INGREDIENTS[id].emoji;
      slot.classList.add('filled');
      slot.onclick = () => removeIngredient(i);
    } else {
      slot.textContent = '?';
      slot.classList.remove('filled');
      slot.onclick = null;
    }
  });

  const sorted = [...GAME.cook.selected].sort();
  const match  = RECIPES.find(r => {
    const rs = [...r.ingredients].sort();
    return rs.length === sorted.length && rs.every((v, i) => v === sorted[i]);
  });

  const matchEl = document.getElementById('recipe-match');
  const cookBtn = document.getElementById('btn-cook-action');

  if (match && GAME.cook.selected.length === match.ingredients.length) {
    matchEl.innerHTML = `✅ Receta: <strong>${match.emoji} ${match.name}</strong> — 💳 ${match.basePrice}₿`;
    matchEl.className = 'recipe-match matched';
    cookBtn.disabled  = false;
    GAME.cook.currentRecipe = match;
  } else if (GAME.cook.selected.length > 0) {
    matchEl.innerHTML = '❓ Combinación desconocida...';
    matchEl.className = 'recipe-match';
    cookBtn.disabled  = true;
    GAME.cook.currentRecipe = null;
  } else {
    matchEl.innerHTML = 'Selecciona ingredientes...';
    matchEl.className = 'recipe-match';
    cookBtn.disabled  = true;
    GAME.cook.currentRecipe = null;
  }
}

function startCooking() {
  if (!GAME.cook.currentRecipe) return;
  GAME.cook.barPos = 0;
  GAME.cook.barDir = 1;
  // Tope de velocidad (no cambia nada hasta el nivel 20) y ralentización del Fogón Estabilizado
  GAME.cook.barSpeed = Math.min(1.3 + GAME.level * 0.22, EXP_BAL.cookBarSpeedCap) * (1 - getStat('cookslow'));
  showCookPhase('timing');

  if (GAME.cook.barInterval) clearInterval(GAME.cook.barInterval);
  GAME.cook.barInterval = setInterval(() => {
    GAME.cook.barPos += GAME.cook.barDir * GAME.cook.barSpeed;
    if (GAME.cook.barPos >= 100) { GAME.cook.barPos = 100; GAME.cook.barDir = -1; }
    if (GAME.cook.barPos <= 0)   { GAME.cook.barPos = 0;   GAME.cook.barDir =  1; }
    const ind = document.getElementById('timing-indicator');
    if (ind) ind.style.left = GAME.cook.barPos + '%';
  }, 16);
}

function stopTiming() {
  if (GAME.cook.barInterval) { clearInterval(GAME.cook.barInterval); GAME.cook.barInterval = null; }

  const pos = GAME.cook.barPos;
  let stars, msg;
  const zw = getStat('cookzone') * 100;   // Termostato de Precisión: zona perfecta más ancha
  if      (pos >= 34 - zw && pos <= 66 + zw) { stars = 3; msg = '⭐⭐⭐ ¡PERFECTO! Cocción magistral.'; }
  else if ((pos >= 20 - zw && pos < 34 - zw) || (pos > 66 + zw && pos <= 80 + zw)) { stars = 2; msg = '⭐⭐ Bien hecho. Podría mejorar.'; }
  else { stars = 1; msg = '⭐ Apenas comestible... para un monstruo.'; }
  // Sazón Maestra: probabilidad de subir el plato una estrella
  if (stars < 3 && chance(getStat('starup'))) {
    stars++;
    msg += ' ✨ ¡Sazón Maestra! (+1 ⭐)';
  }

  // Consume ingredients
  GAME.cook.selected.forEach(id => { GAME.inventory[id]--; });

  // Price multiplier by stars
  const recipe = GAME.cook.currentRecipe;
  const mult   = stars === 3 ? 1.25 : stars === 2 ? 1.0 : 0.75;
  const price  = Math.floor(recipe.basePrice * mult);
  GAME.readyDishes.push({ recipeId: recipe.id, stars, price });
  addLog(`🍳 Cocinaste: ${recipe.emoji} ${recipe.name} (${'⭐'.repeat(stars)})`);
  saveGame();

  showCookPhase('result');
  setTxt('result-dish-emoji', recipe.emoji);
  setTxt('result-dish-name',  recipe.name);
  setTxt('result-stars',      '⭐'.repeat(stars) + '☆'.repeat(3 - stars));
  setTxt('result-quality-msg', msg);
}

// ─────────────────────────── SERVE (SERVICIO) SCREEN ─────────────────────────
function enterServe() {
  if (GAME.readyDishes.length === 0) {
    flashMsg('¡No tienes platos! Ve a cocinar primero.'); return;
  }

  // Generate 2-3 customers
  const num = rand(2, 3) + Math.round(getStat('extracust'));
  GAME.serve.customers = [];
  const availRecipes = [...new Set(GAME.readyDishes.map(d => d.recipeId))];
  // Prefiere clientes a los que les gusta algo de lo que tienes
  const interested = CUSTOMER_TYPES.filter(c => c.preferences.some(p => availRecipes.includes(p)));
  const customerPool = interested.length ? interested : CUSTOMER_TYPES;

  for (let i = 0; i < num; i++) {
    const tmpl  = customerPool[rand(0, customerPool.length - 1)];
    const liked = tmpl.preferences.filter(p => availRecipes.includes(p));
    const wanted = liked.length ? liked[rand(0, liked.length - 1)] : availRecipes[rand(0, availRecipes.length - 1)];
    const patienceTotal = Math.round(tmpl.patience * (1 + getStat('patience')));
    GAME.serve.customers.push({
      ...tmpl,
      uid:         `c_${i}_${Date.now()}`,
      wantedDish:  wanted,
      patience:    patienceTotal,
      maxPatience: patienceTotal,
      served:      false,
      satisfaction: 0
    });
  }

  GAME.serve.dishes       = [...GAME.readyDishes];
  GAME.serve.selectedDish = null;
  GAME.serve.selIndex     = -1;
  GAME.serve.earned       = 0;
  GAME.serve.timeLeft     = 60 + Math.round(getStat('servetime'));
  document.getElementById('selected-dish-display').style.display = 'none';

  showScreen('serve');
  setTxt('serve-timer-text', GAME.serve.timeLeft);
  renderServeScreen();

  if (GAME.serve.timerInterval) clearInterval(GAME.serve.timerInterval);
  GAME.serve.timerInterval = setInterval(serveTimerTick, 1000);
}

function serveTimerTick() {
  GAME.serve.timeLeft--;
  setTxt('serve-timer-text', GAME.serve.timeLeft);
  GAME.serve.customers.forEach(c => { if (!c.served) c.patience = Math.max(0, c.patience - 1); });
  renderCustomers();
  if (GAME.serve.timeLeft <= 0 || GAME.serve.customers.every(c => c.served)) endServe();
}

function getDishSectorPrice(recipeId, stars) {
  const r = RECIPES.find(x => x.id === recipeId);
  if (!r) return 100;
  const qualityMult = stars === 3 ? 1.25 : stars === 2 ? 1.0 : 0.75;
  const sectorObj   = getCurrentSectorObj();
  const sectorMult  = (sectorObj.multipliers && sectorObj.multipliers[recipeId]) || 1.0;
  return Math.floor(r.basePrice * qualityMult * sectorMult);
}

function renderServeScreen() {
  const curS = getCurrentSectorObj();
  setTxt('serve-sector-badge', `${curS.emoji} ${curS.name.toUpperCase()}`);
  renderCustomers();
  renderServeDishes();
  setTxt('serve-earned-text', GAME.serve.earned);
}

function renderCustomers() {
  const el = document.getElementById('customers-row');
  el.innerHTML = GAME.serve.customers.map((c, i) => {
    const pr      = c.patience / c.maxPatience;
    const pColor  = pr > .55 ? '#00ff88' : pr > .28 ? '#ffaa00' : '#ff1144';
    const rec     = RECIPES.find(r => r.id === c.wantedDish);
    if (c.served) return `
      <div class="customer-card served">
        <span class="cust-emoji">${c.emoji}</span>
        <div class="cust-name">${c.name}</div>
        <div class="cust-status">✅ ¡Satisfecho!</div>
        <div class="cust-stars">${'⭐'.repeat(c.satisfaction)}</div>
      </div>`;
    return `
      <div class="customer-card" onclick="serveCustomer(${i})">
        <span class="cust-emoji">${c.emoji}</span>
        <div class="cust-name">${c.name}</div>
        <div class="cust-wants">Quiere: <span class="cust-dish">${rec ? rec.emoji+' '+rec.name : '???'}</span></div>
        <div class="patience-bar-container">
          <div class="patience-bar" style="width:${pr*100}%;background:${pColor}"></div>
        </div>
      </div>`;
  }).join('');
}

function renderServeDishes() {
  const el = document.getElementById('serve-dishes-list');
  const g  = {};
  GAME.serve.dishes.forEach((d, i) => {
    if (!g[d.recipeId]) g[d.recipeId] = [];
    g[d.recipeId].push(i);
  });
  if (Object.keys(g).length === 0) {
    el.innerHTML = '<p class="empty-msg">Sin platos disponibles.</p>'; return;
  }
  const curS = getCurrentSectorObj();
  el.innerHTML = Object.entries(g).map(([rid, indices]) => {
    const r   = RECIPES.find(x => x.id === rid);
    const d   = GAME.serve.dishes[indices[0]];
    const dynamicPrice = getDishSectorPrice(rid, d.stars);
    const sel = GAME.serve.selectedDish?.recipeId === rid;
    const secMult = (curS.multipliers && curS.multipliers[rid]) || 1.0;
    const multPercent = Math.round((secMult - 1.0) * 100);
    const tagColor = multPercent > 0 ? '#00ff88' : multPercent < 0 ? '#ff4455' : '#88aacc';
    const multTag = multPercent !== 0 ? `<span style="font-size:.65rem; color:${tagColor}; margin-left:4px;">(${multPercent > 0 ? '+' : ''}${multPercent}%)</span>` : '';

    return `<div class="serve-dish-item ${sel ? 'selected' : ''}" onclick="selectDish('${rid}')">
      <span class="dish-emoji">${r.emoji}</span>
      <span class="dish-name">${r.name} ${multTag}</span>
      <span class="dish-stars">${'⭐'.repeat(d.stars)}</span>
      <span class="dish-qty">×${indices.length}</span>
      <span class="dish-price">💳 ${dynamicPrice}₿</span>
    </div>`;
  }).join('');
}

function selectDish(recipeId) {
  const idx = GAME.serve.dishes.findIndex(d => d.recipeId === recipeId);
  if (idx === -1) return;
  GAME.serve.selectedDish = GAME.serve.dishes[idx];
  GAME.serve.selIndex     = idx;
  const r = RECIPES.find(x => x.id === recipeId);
  const el = document.getElementById('selected-dish-display');
  el.style.display = 'block';
  document.getElementById('selected-dish-name').textContent = r.emoji + ' ' + r.name;
  renderServeDishes();
}

function serveCustomer(i) {
  const c = GAME.serve.customers[i];
  if (!c || c.served) return;
  if (!GAME.serve.selectedDish) {
    document.getElementById('selected-dish-display').style.display = 'block';
    return;
  }

  const dish = GAME.serve.selectedDish;
  const r    = RECIPES.find(x => x.id === dish.recipeId);
  const isWanted = c.wantedDish === dish.recipeId;
  const speedBonus = c.patience / c.maxPatience;
  
  // Precio adaptado al sector en el que estamos sirviendo
  const dynamicSectorPrice = getDishSectorPrice(dish.recipeId, dish.stars);
  let earned, satisfaction;

  if (isWanted) {
    satisfaction = dish.stars;
    earned = Math.floor(dynamicSectorPrice * 1.2 * (0.5 + speedBonus));
  } else {
    satisfaction = 1;
    earned = Math.floor(dynamicSectorPrice * 0.38);
  }

  earned = Math.floor(earned * (1 + getStat('tip')));   // Propina Cibernética + Paladar Gourmet
  c.served       = true;
  c.satisfaction = satisfaction;
  GAME.serve.earned  += earned;
  GAME.credits       += earned;
  GAME.reputation    += satisfaction * 4;

  // Remove dish
  GAME.serve.dishes.splice(GAME.serve.selIndex, 1);
  const rdIdx = GAME.readyDishes.findIndex(d => d.recipeId === dish.recipeId);
  if (rdIdx !== -1) GAME.readyDishes.splice(rdIdx, 1);

  GAME.serve.selectedDish = null;
  GAME.serve.selIndex     = -1;
  document.getElementById('selected-dish-display').style.display = 'none';

  addLog(`🍽️ Serviste ${r.emoji} a ${c.emoji} ${c.name} en ${getCurrentSectorObj().name}. +${earned}₿`);
  saveGame();
  setTxt('serve-earned-text', GAME.serve.earned);
  renderServeScreen();

  if (GAME.serve.customers.every(x => x.served)) setTimeout(endServe, 900);
}

function endServe() {
  if (GAME.serve.timerInterval) { clearInterval(GAME.serve.timerInterval); GAME.serve.timerInterval = null; }
  addLog(`✅ Servicio completado. Ganaste ${GAME.serve.earned}₿`);
  setTimeout(() => { showScreen('hub'); updateHubUI(); }, 1400);
}

// ─────────────────────────── INTRO RAIN ──────────────────────────────────────
function generateRain() {
  const c = document.getElementById('rain-container');
  if (!c) return;
  for (let i = 0; i < 90; i++) {
    const d = document.createElement('div');
    d.className = 'rain-drop';
    d.style.left              = rand(0, 100) + '%';
    d.style.height            = rand(10, 32) + 'px';
    d.style.animationDelay    = (Math.random() * 2.5).toFixed(2) + 's';
    d.style.animationDuration = (0.45 + Math.random() * 0.9).toFixed(2) + 's';
    d.style.opacity           = (0.3 + Math.random() * 0.7).toFixed(2);
    c.appendChild(d);
  }
}

// ─────────────────────────── HELPERS ─────────────────────────────────────────
function setTxt(id, val)           { const e = document.getElementById(id); if (e) e.textContent = val; }
function setStyle(id, prop, val)   { const e = document.getElementById(id); if (e) e.style[prop] = val; }
function flashMsg(msg)             { alert(msg); }  // simple for now

// ─────────────────────────── EVENT LISTENERS ─────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // PWA Service Worker (si está en HTTPS o localhost)
  if ('serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  }

  generateRain();
  const hasSave = loadGame();
  if (hasSave) {
    document.getElementById('btn-start').textContent = '▶ CONTINUAR PARTIDA';
    addLog('💾 Partida restaurada automáticamente.');
  }
  window.addEventListener('pagehide', saveGame);

  // INTRO
  document.getElementById('btn-start').addEventListener('click', () => {
    showScreen('hub'); updateHubUI(); saveGame();
  });

  // HUB
  document.getElementById('btn-hunt').addEventListener('click', enterHunt);
  document.getElementById('btn-cook').addEventListener('click', enterCook);
  document.getElementById('btn-serve').addEventListener('click', enterServe);

  // HUNT
  document.getElementById('btn-back-hunt').addEventListener('click', () => {
    showScreen('hub'); updateHubUI();
  });

  // D-PAD VIRTUAL TÁCTIL (Móvil)
  const dpadDirMap = {
    up: [0, -1],
    down: [0, 1],
    left: [-1, 0],
    right: [1, 0]
  };

  document.querySelectorAll('.dpad-btn').forEach(btn => {
    const handleMove = (e) => {
      e.preventDefault();
      const dir = btn.dataset.dir;
      if (dpadDirMap[dir]) {
        movePlayer(dpadDirMap[dir][0], dpadDirMap[dir][1]);
      }
    };
    btn.addEventListener('pointerdown', handleMove);
  });

  // Swipe / Tap en el canvas para mover al jugador
  const huntCanvas = document.getElementById('hunt-canvas');
  if (huntCanvas) {
    let touchStartX = 0;
    let touchStartY = 0;
    huntCanvas.addEventListener('touchstart', (e) => {
      if (e.touches.length > 0) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
      }
    }, { passive: true });

    huntCanvas.addEventListener('touchend', (e) => {
      if (!touchStartX || !touchStartY || e.changedTouches.length === 0) return;
      const dx = e.changedTouches[0].clientX - touchStartX;
      const dy = e.changedTouches[0].clientY - touchStartY;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);
      const minSwipe = 25; // px

      if (Math.max(absX, absY) > minSwipe) {
        if (absX > absY) {
          movePlayer(dx > 0 ? 1 : -1, 0);
        } else {
          movePlayer(0, dy > 0 ? 1 : -1);
        }
      }
    }, { passive: true });
  }

  // COMBAT
  document.getElementById('btn-attack').addEventListener('click', () => playerAttack('attack'));
  document.getElementById('btn-defend').addEventListener('click', () => playerAttack('defend'));
  document.getElementById('btn-special').addEventListener('click', () => playerAttack('special'));
  document.getElementById('btn-flee').addEventListener('click',   () => playerAttack('flee'));
  const combatHealBtn = document.getElementById('btn-combat-heal');
  if (combatHealBtn) {
    combatHealBtn.addEventListener('click', useCombatHeal);
  }

  // MOCHILA
  const btnBackpack = document.getElementById('btn-backpack');
  if (btnBackpack) btnBackpack.addEventListener('click', openBackpack);
  const btnCloseBackpack = document.getElementById('btn-close-backpack');
  if (btnCloseBackpack) btnCloseBackpack.addEventListener('click', closeBackpack);

  // SECTORES (1 AL 10)
  const btnOpenSectors = document.getElementById('btn-open-sectors');
  if (btnOpenSectors) btnOpenSectors.addEventListener('click', openSectorsModal);
  const btnHeaderSector = document.getElementById('btn-header-sector');
  if (btnHeaderSector) btnHeaderSector.addEventListener('click', openSectorsModal);
  const btnCloseSectors = document.getElementById('btn-close-sectors');
  if (btnCloseSectors) btnCloseSectors.addEventListener('click', closeSectorsModal);

  // COPIA DE SEGURIDAD (BACKUP)
  const btnOpenBackup = document.getElementById('btn-open-backup');
  if (btnOpenBackup) btnOpenBackup.addEventListener('click', openBackupModal);
  const btnCloseBackup = document.getElementById('btn-close-backup');
  if (btnCloseBackup) btnCloseBackup.addEventListener('click', closeBackupModal);

  // Exportar: genera JSON en textarea (compatible con WebView/APK Android)
  const btnExportBackup = document.getElementById('btn-export-backup');
  if (btnExportBackup) btnExportBackup.addEventListener('click', exportBackup);

  // Copiar al portapapeles
  const btnCopyBackup = document.getElementById('btn-copy-backup');
  if (btnCopyBackup) btnCopyBackup.addEventListener('click', copyBackupToClipboard);

  // Importar desde texto pegado (principal en APK)
  const btnImportTextBackup = document.getElementById('btn-import-text-backup');
  if (btnImportTextBackup) btnImportTextBackup.addEventListener('click', importFromText);

  // Importar desde archivo (fallback para PC)
  const btnImportBackup = document.getElementById('btn-import-backup');
  const backupFileInput = document.getElementById('backup-file-input');
  if (btnImportBackup && backupFileInput) {
    btnImportBackup.addEventListener('click', () => backupFileInput.click());
    backupFileInput.addEventListener('change', importBackup);
  }

  // LABORATORIO DE MEJORAS
  const btnOpenLab = document.getElementById('btn-open-lab');
  if (btnOpenLab) btnOpenLab.addEventListener('click', openLab);
  const btnCloseLab = document.getElementById('btn-close-lab');
  if (btnCloseLab) btnCloseLab.addEventListener('click', closeLab);

  // FILTRO DE RECETAS (cocina)
  const recipeSearch = document.getElementById('recipe-search');
  if (recipeSearch) recipeSearch.addEventListener('input', () => { GAME.ui.recipeSearch = recipeSearch.value; refreshCookUI(); });
  const recipeFilterBtn = document.getElementById('btn-recipe-filter');
  if (recipeFilterBtn) recipeFilterBtn.addEventListener('click', () => { GAME.ui.recipeOnlyCookable = !GAME.ui.recipeOnlyCookable; refreshCookUI(); });

  // Intervalo para actualizar el temporizador de la tienda de mejoras cada segundo
  setInterval(() => {
    if (GAME.screen === 'hub') {
      renderShop();
    }
  }, 1000);

  // COOK
  document.getElementById('btn-back-cook').addEventListener('click', () => {
    if (GAME.cook.barInterval) { clearInterval(GAME.cook.barInterval); GAME.cook.barInterval = null; }
    showScreen('hub'); updateHubUI();
  });
  document.getElementById('btn-cook-action').addEventListener('click', startCooking);
  document.getElementById('btn-stop-timing').addEventListener('click', stopTiming);
  document.getElementById('btn-clear-recipe').addEventListener('click', () => {
    GAME.cook.selected = []; refreshSlots(); refreshCookUI();
  });
  document.getElementById('btn-cook-again').addEventListener('click', () => {
    GAME.cook.selected = [];
    GAME.cook.currentRecipe = null;
    showCookPhase('select');
    refreshCookUI();
  });
  document.getElementById('btn-cook-done').addEventListener('click', () => {
    showScreen('hub'); updateHubUI();
  });

  // SERVE
  document.getElementById('btn-back-serve').addEventListener('click', () => {
    if (GAME.serve.timerInterval) { clearInterval(GAME.serve.timerInterval); GAME.serve.timerInterval = null; }
    showScreen('hub'); updateHubUI();
  });
});
