// game.js - logika lu di sini
// PENTING: panggil asset selalu pake path relatif, contoh:
// const idleVideo = 'assets/idle.mp4';
// const bg = 'assets/bg-arena.jpg';
// JANGAN pake C:/ atau /storage/ atau link AI Studio
console.log('ZIP Athena ke-load, struktur udah bener');
console.log('index.html di luar, assets di dalam folder assets/');
