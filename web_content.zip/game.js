(() => {
const $ = id => document.getElementById(id);
let scene,camera,renderer,clock,player,ground,started=false,paused=false;
let keys={}, yaw=0, pitch=0, velocity=new THREE.Vector3(), hp=100, ammo=30, reserve=90, kills=0;
let bots=[], bullets=[], peers=[], peer=null, conn=null, remotePlayer=null, roomCode="";
const mat=(color,roughness=.85)=>new THREE.MeshStandardMaterial({color,roughness});
function init3D(){
  scene=new THREE.Scene(); scene.background=new THREE.Color(0x91c8e8); scene.fog=new THREE.Fog(0x91c8e8,45,150);
  camera=new THREE.PerspectiveCamera(72,innerWidth/innerHeight,.1,300);
  renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)); renderer.setSize(innerWidth,innerHeight); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; $('game').appendChild(renderer.domElement);
  scene.add(new THREE.HemisphereLight(0xc9eaff,0x4c5c39,2));
  const sun=new THREE.DirectionalLight(0xfff1d4,2.4); sun.position.set(-25,45,20); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048); scene.add(sun);
  ground=new THREE.Mesh(new THREE.PlaneGeometry(220,220),mat(0x557b43)); ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
  const grid=new THREE.GridHelper(220,44,0x3f6940,0x66864b); grid.position.y=.02; scene.add(grid);
  player=new THREE.Group(); player.position.set(0,0,12); scene.add(player);
  const body=new THREE.Mesh(new THREE.CapsuleGeometry(.42,.85,4,8),mat(0x1c5672)); body.position.y=1.05; body.castShadow=true; player.add(body);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.25,12,10),mat(0xd9a77e)); head.position.y=1.78; player.add(head);
  const gun=new THREE.Mesh(new THREE.BoxGeometry(.14,.16,.85),mat(0x202a32)); gun.position.set(.35,1.25,-.48); player.add(gun);
  camera.position.set(0,2.5,4); camera.rotation.order='YXZ'; player.add(camera);
  buildArena(); clock=new THREE.Clock(); animate();
}
function buildArena(){
  const buildingMat=mat(0xb5a58b), roofMat=mat(0x465b69), trunkMat=mat(0x62462d), leafMat=mat(0x2e7043);
  for(let i=0;i<24;i++){
    const x=(Math.random()-.5)*115,z=(Math.random()-.5)*115;
    if(Math.abs(x)<12&&Math.abs(z)<15)continue;
    if(i%3===0){
      const w=5+Math.random()*5,d=5+Math.random()*5,h=3+Math.random()*4;
      const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),buildingMat);b.position.set(x,h/2,z);b.castShadow=true;b.receiveShadow=true;scene.add(b);
      const r=new THREE.Mesh(new THREE.BoxGeometry(w+.4,.35,d+.4),roofMat);r.position.set(x,h+.15,z);scene.add(r);
    }else{
      const t=new THREE.Mesh(new THREE.CylinderGeometry(.18,.28,2,7),trunkMat);t.position.set(x,1,z);t.castShadow=true;scene.add(t);
      const l=new THREE.Mesh(new THREE.SphereGeometry(1.35,9,8),leafMat);l.position.set(x,2.7,z);l.castShadow=true;scene.add(l);
    }
  }
  for(let i=0;i<9;i++){const box=new THREE.Mesh(new THREE.BoxGeometry(1.2,1,1.2),mat(0x9b713d));box.position.set((Math.random()-.5)*32,.5,(Math.random()-.5)*32);box.castShadow=true;scene.add(box);}
}
function makeBot(x,z){const g=new THREE.Group();g.position.set(x,0,z);const m=mat(0x9a3f38);const b=new THREE.Mesh(new THREE.CapsuleGeometry(.4,.8,4,8),m);b.position.y=1;g.add(b);const h=new THREE.Mesh(new THREE.SphereGeometry(.23,10,8),mat(0xc28d69));h.position.y=1.7;g.add(h);g.userData={hp:100,dir:Math.random()*6.28};scene.add(g);bots.push(g);}
function start(mode){
  $('menu').classList.add('hidden');$('hud').classList.remove('hidden');started=true;paused=false;
  $('roomLabel').textContent=mode==='online'?'ROOM '+roomCode:'TRAINING';
  if(mode==='training'){for(let i=0;i<7;i++)makeBot((Math.random()-.5)*55,(Math.random()-.5)*55);}
}
function animate(){
  requestAnimationFrame(animate);if(!renderer)return;const dt=Math.min(clock?clock.getDelta():.016,.04);
  if(started&&!paused){
    const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
    let move=new THREE.Vector3();if(keys.w||keys.up)move.add(forward);if(keys.s||keys.down)move.sub(forward);if(keys.d||keys.right)move.add(right);if(keys.a||keys.left)move.sub(right);
    if(move.lengthSq()>0)move.normalize();player.position.addScaledVector(move,dt*9);
    player.rotation.y=yaw;
    bots.forEach(bot=>{const dx=player.position.x-bot.position.x,dz=player.position.z-bot.position.z,dist=Math.hypot(dx,dz);if(dist>3){bot.position.x+=dx/dist*dt*1.2;bot.position.z+=dz/dist*dt*1.2;}});
    if(remotePlayer&&conn&&conn.open){conn.send({type:'pos',x:player.position.x,z:player.position.z,yaw});}
  }
  renderer.render(scene,camera);
}
function shoot(){
 if(!started||paused||ammo<=0)return;ammo--; $('ammo').textContent=ammo+' / '+reserve;
 const origin=new THREE.Vector3();camera.getWorldPosition(origin);const dir=new THREE.Vector3();camera.getWorldDirection(dir);
 const ray=new THREE.Raycaster(origin,dir,0,65);let hit=ray.intersectObjects(bots,true);
 if(hit.length){let obj=hit[0].object;while(obj.parent&&!obj.userData.hp)obj=obj.parent;if(obj.userData.hp){obj.userData.hp-=50;if(obj.userData.hp<=0){scene.remove(obj);bots=bots.filter(b=>b!==obj);kills++;$('kills').textContent=kills;}}}
 const flash=new THREE.Mesh(new THREE.SphereGeometry(.07,6,6),new THREE.MeshBasicMaterial({color:0xffd27b}));flash.position.copy(origin).addScaledVector(dir,1.1);scene.add(flash);setTimeout(()=>scene.remove(flash),70);
}
function reload(){if(reserve<=0||ammo===30)return;const n=Math.min(30-ammo,reserve);ammo+=n;reserve-=n;$('ammo').textContent=ammo+' / '+reserve;}
function heal(){if(hp>=100)return;hp=Math.min(100,hp+35);$('hp').textContent=hp;}
function setupOnline(){
 peer=new Peer();$('menuStatus').textContent='Connecting to online service…';
 peer.on('open',id=>{roomCode=id.slice(-6).toUpperCase();$('menuStatus').textContent='Room code: '+roomCode+' — share it with your friend.';start('online');});
 peer.on('connection',c=>{conn=c;wireConnection(c);});
 peer.on('error',e=>$('menuStatus').textContent='Online connection error: '+e.type+'. Try Training or check internet.');
}
function joinOnline(){
 const code=$('roomInput').value.trim();if(!code){$('menuStatus').textContent='Enter your friend’s room code.';return;}
 $('menuStatus').textContent='Connecting…';peer=new Peer();
 peer.on('open',()=>{conn=peer.connect(code,{reliable:true});wireConnection(conn);roomCode=code;});
 peer.on('error',e=>$('menuStatus').textContent='Could not connect: '+e.type+'. Check the code and internet.');
}
function wireConnection(c){c.on('open',()=>{ $('menuStatus').textContent='Connected!'; if(!started)start('online');});c.on('data',d=>{if(d.type==='pos'){if(!remotePlayer){remotePlayer=new THREE.Mesh(new THREE.CapsuleGeometry(.4,.8,4,8),mat(0x27d4c2));remotePlayer.position.y=1;scene.add(remotePlayer);}remotePlayer.position.set(d.x,1,d.z);remotePlayer.rotation.y=d.yaw;}});c.on('close',()=>$('menuStatus').textContent='Friend disconnected.');}
function pointerLook(dx,dy){yaw-=dx*.004;pitch=Math.max(-.7,Math.min(.7,pitch-dy*.004));camera.rotation.set(pitch,0,0);}
let lookTouch=null,stickTouch=null,stickOrigin=null;
function bindControls(){
 document.addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.key===' ')shoot();});
 document.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
 renderer.domElement.addEventListener('pointerdown',e=>{if(e.clientX>innerWidth*.38){lookTouch={x:e.clientX,y:e.clientY};}});
 renderer.domElement.addEventListener('pointermove',e=>{if(lookTouch){pointerLook(e.clientX-lookTouch.x,e.clientY-lookTouch.y);lookTouch={x:e.clientX,y:e.clientY};}});
 renderer.domElement.addEventListener('pointerup',()=>lookTouch=null);
 const base=$('stickBase'),knob=$('stickKnob');
 base.addEventListener('pointerdown',e=>{stickTouch=e.pointerId;stickOrigin={x:e.clientX,y:e.clientY};base.setPointerCapture(e.pointerId);});
 base.addEventListener('pointermove',e=>{if(stickTouch!==e.pointerId)return;let dx=e.clientX-stickOrigin.x,dy=e.clientY-stickOrigin.y;let len=Math.hypot(dx,dy),s=Math.min(1,48/(len||1));dx*=s;dy*=s;knob.style.transform=`translate(${dx}px,${dy}px)`;keys.a=dx<-12;keys.d=dx>12;keys.w=dy<-12;keys.s=dy>12;});
 base.addEventListener('pointerup',()=>{stickTouch=null;knob.style.transform='';keys.a=keys.d=keys.w=keys.s=false;});
 $('fireBtn').addEventListener('pointerdown',shoot);$('reloadBtn').onclick=reload;$('medBtn').onclick=heal;
 $('pauseBtn').onclick=()=>{paused=true;$('pausePanel').classList.remove('hidden');};
 $('resumeBtn').onclick=()=>{paused=false;$('pausePanel').classList.add('hidden');};
 $('homeBtn').onclick=()=>location.reload();
}
$('trainingBtn').onclick=()=>{start('training');};
$('hostBtn').onclick=setupOnline;$('joinBtn').onclick=joinOnline;
init3D();bindControls();
addEventListener('resize',()=>{if(!camera||!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
})();