(() => {
  const canvas = document.getElementById('game');
  const ctx = canvas.getContext('2d');
  const startCard = document.getElementById('startCard');
  const gameOverCard = document.getElementById('gameOver');
  const hudScore = document.getElementById('hudScore');
  const scoreEl = document.getElementById('finalScore');
  const bestEl = document.getElementById('best');
  const adOverlay = document.getElementById('adOverlay');
  const adImage = document.getElementById('adImage');
  const adCaption = document.getElementById('adCaption');

  const ads = [
    {src:'assets/ad-cocacola.jpg', caption:'A refreshing moment'},
    {src:'assets/ad-colgate.jpg', caption:'Smile with confidence'},
    {src:'assets/ad-burger.jpg', caption:'Try something delicious'}
  ];
  let bird, pipes, score, best = Number(localStorage.getItem('skyHopperBest') || 0);
  let running = false, raf = 0, frame = 0, lastAd = -1;
  bestEl.textContent = best;

  function randomAd() {
    if (ads.length < 2) return 0;
    let n;
    do { n = Math.floor(Math.random() * ads.length); } while (n === lastAd);
    lastAd = n;
    return n;
  }
  function showAd() {
    const ad = ads[randomAd()];
    adImage.src = ad.src;
    adCaption.textContent = ad.caption;
    adOverlay.classList.remove('hidden');
  }
  function hideAdAndStart() {
    adOverlay.classList.add('hidden');
    beginGame();
  }
  document.getElementById('closeAd').addEventListener('click', hideAdAndStart);
  document.getElementById('adPlay').addEventListener('click', hideAdAndStart);
  document.getElementById('startBtn').addEventListener('click', showAd);
  document.getElementById('restartBtn').addEventListener('click', showAd);

  function reset() {
    bird = {x:105,y:canvas.height*.45,vy:0,r:14,rotation:0};
    pipes = [];
    score = 0;
    frame = 0;
    addPipe(canvas.width + 50);
    hudScore.textContent = '0';
  }
  function addPipe(x) {
    const gap = 166;
    const top = 75 + Math.random() * (canvas.height - gap - 190);
    pipes.push({x,top,bottom:top+gap,w:66,passed:false});
  }
  function beginGame() {
    cancelAnimationFrame(raf);
    reset();
    running = true;
    startCard.classList.add('hidden');
    gameOverCard.classList.add('hidden');
    hudScore.style.display = 'block';
    loop();
  }
  function flap() {
    if (running) bird.vy = -5.9;
  }
  function endGame() {
    running = false;
    scoreEl.textContent = score;
    gameOverCard.classList.remove('hidden');
    hudScore.style.display = 'none';
    if (score > best) {
      best = score;
      localStorage.setItem('skyHopperBest', String(best));
      bestEl.textContent = best;
    }
  }
  function drawBackground() {
    const g = ctx.createLinearGradient(0,0,0,canvas.height);
    g.addColorStop(0,'#12b9d0'); g.addColorStop(.72,'#8be8e0'); g.addColorStop(1,'#d5f5c0');
    ctx.fillStyle = g; ctx.fillRect(0,0,canvas.width,canvas.height);
    // soft clouds
    ctx.fillStyle = '#ffffffa8';
    for(let i=0;i<5;i++){
      const x = ((i*115 - frame*0.35) % (canvas.width+130) + canvas.width+130)%(canvas.width+130)-65;
      const y = 445 + (i%2)*30;
      ctx.beginPath(); ctx.arc(x,y,28,0,Math.PI*2); ctx.arc(x+27,y-10,34,0,Math.PI*2); ctx.arc(x+58,y,25,0,Math.PI*2); ctx.fill();
    }
    ctx.fillStyle='#55d66b'; ctx.fillRect(0,canvas.height-38,canvas.width,38);
    ctx.fillStyle='#2eb84e'; ctx.fillRect(0,canvas.height-38,canvas.width,6);
  }
  function roundedRect(x,y,w,h,r) {
    ctx.beginPath(); ctx.roundRect(x,y,w,h,r); ctx.fill();
  }
  function drawPipe(p, topPipe) {
    const x=p.x, w=p.w;
    const y=topPipe ? 0 : p.bottom;
    const h=topPipe ? p.top : canvas.height-38-p.bottom;
    const grad=ctx.createLinearGradient(x,0,x+w,0);
    grad.addColorStop(0,'#5aaf18'); grad.addColorStop(.45,'#b8ed50'); grad.addColorStop(1,'#478e12');
    ctx.fillStyle=grad; ctx.strokeStyle='#315d16'; ctx.lineWidth=4;
    ctx.fillRect(x,y,w,h); ctx.strokeRect(x,y,w,h);
    const capY=topPipe ? p.top-25 : p.bottom;
    ctx.fillStyle=grad; ctx.fillRect(x-7,capY,w+14,25); ctx.strokeRect(x-7,capY,w+14,25);
  }
  function drawBird() {
    ctx.save(); ctx.translate(bird.x,bird.y); ctx.rotate(Math.max(-.45,Math.min(.8,bird.vy*.06)));
    // simple original cartoon bird
    ctx.fillStyle='#f6a623'; ctx.strokeStyle='#693e1d'; ctx.lineWidth=2.5;
    ctx.beginPath(); ctx.ellipse(0,0,16,12,0,0,Math.PI*2); ctx.fill(); ctx.stroke();
    ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(7,-6,5,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#172b38'; ctx.beginPath(); ctx.arc(9,-6,2,0,Math.PI*2); ctx.fill();
    ctx.fillStyle='#ef5a32'; ctx.beginPath(); ctx.moveTo(12,1); ctx.lineTo(25,5); ctx.lineTo(12,8); ctx.closePath(); ctx.fill();
    ctx.fillStyle='#f8d35b'; ctx.beginPath(); ctx.ellipse(-5,5,8,4,-.4,0,Math.PI*2); ctx.fill();
    ctx.restore();
  }
  function draw() {
    drawBackground();
    pipes.forEach(p=>{drawPipe(p,true);drawPipe(p,false);});
    drawBird();
  }
  function loop() {
    if(!running) return;
    frame++;
    bird.vy += .29; bird.y += bird.vy;
    pipes.forEach(p=>{
      p.x -= 2.65;
      if(!p.passed && p.x+p.w < bird.x){p.passed=true;score++;hudScore.textContent=score;}
    });
    if(pipes[pipes.length-1].x < canvas.width-220) addPipe(canvas.width+10);
    pipes = pipes.filter(p=>p.x+p.w>-20);
    const hitBounds = bird.y+bird.r>canvas.height-38 || bird.y-bird.r<0;
    const hitPipe = pipes.some(p=>bird.x+bird.r>p.x && bird.x-bird.r<p.x+p.w && (bird.y-bird.r<p.top || bird.y+bird.r>p.bottom));
    draw();
    if(hitBounds || hitPipe){endGame();return;}
    raf=requestAnimationFrame(loop);
  }
  function action(e) {
    if(e && e.target && (e.target.closest('button'))) return;
    if(running){ if(e && e.cancelable) e.preventDefault(); flap(); }
  }
  canvas.addEventListener('pointerdown', action);
  document.addEventListener('keydown', e=>{
    if(e.code==='Space' && running){e.preventDefault();flap();}
  });
  // Draw a preview behind the start card.
  reset(); draw();
})();