/**
 * ============================================================================
 * APOCALYPSE MAP TRAVEL — ЯДРО ИГРЫ (Чистый ES6+ JavaScript)
 * Классы: AudioFX, SaveSystem, Resources, Base, Unit, Combat, MapManager, Game
 * ============================================================================
 */

// Вспомогательная формула Гаверсинуса (расстояние между двумя координатами в км)
function calcHaversineKm(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
}

// Генерация координат многоугольника (восьмиугольника) вокруг точки (радиус в км)
function createTerritoryPolygonCoords(lat, lng, radiusKm = 50, sides = 8) {
    const coords = [];
    const latRad = lat * Math.PI / 180;
    for (let i = 0; i < sides; i++) {
        const angle = (i * 2 * Math.PI) / sides;
        const dLat = (radiusKm / 111.32) * Math.cos(angle);
        const dLng = (radiusKm / (111.32 * Math.max(0.2, Math.cos(latRad)))) * Math.sin(angle);
        coords.push([lat + dLat, lng + dLng]);
    }
    return coords;
}

/**
 * Синтезатор звука Web Audio API (щелчки счётчика Гейгера, ПДА, сирена, бой)
 */
class AudioFX {
    constructor() {
        this.ctx = null;
        this.muted = false;
        this.volume = 0.35;
    }

    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) {
                this.ctx = new AudioCtx();
            }
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    playTone(freq = 800, duration = 0.06, type = 'square') {
        if (this.muted) return;
        try {
            this.init();
            if (!this.ctx) return;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
            gain.gain.setValueAtTime(this.volume * 0.25, this.ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start();
            osc.stop(this.ctx.currentTime + duration);
        } catch (e) {
            // Игнорируем ограничения автозапуска аудио
        }
    }

    geigerClick() {
        this.playTone(1200 + Math.random() * 600, 0.018, 'sawtooth');
    }

    pdaBeep() {
        this.playTone(980, 0.07, 'sine');
        setTimeout(() => this.playTone(1320, 0.09, 'sine'), 80);
    }

    combatShot() {
        this.playTone(180, 0.11, 'sawtooth');
    }

    alarm() {
        this.playTone(440, 0.18, 'square');
        setTimeout(() => this.playTone(320, 0.22, 'square'), 200);
    }
}

/**
 * 1. КЛАСС SaveSystem — сохранение и загрузка состояния из localStorage
 */
class SaveSystem {
    static STORAGE_KEY = 'amt_stalker_save_v1';
    static GEO_CACHE_KEY = 'amt_nominatim_cache_v1';
    static LICENSE_KEY = 'amt_license_verified_v1';

    static saveGame(stateObj) {
        try {
            const serialized = JSON.stringify(stateObj);
            localStorage.setItem(SaveSystem.STORAGE_KEY, serialized);
            return true;
        } catch (e) {
            console.warn('Ошибка сохранения в localStorage:', e);
            return false;
        }
    }

    static loadGame() {
        try {
            const raw = localStorage.getItem(SaveSystem.STORAGE_KEY);
            return raw ? JSON.parse(raw) : null;
        } catch (e) {
            console.warn('Ошибка чтения сохранения из localStorage:', e);
            return null;
        }
    }

    static clearSave() {
        try {
            localStorage.removeItem(SaveSystem.STORAGE_KEY);
        } catch (e) {}
    }

    static getGeoCache() {
        try {
            const raw = localStorage.getItem(SaveSystem.GEO_CACHE_KEY);
            return raw ? JSON.parse(raw) : {};
        } catch (e) {
            return {};
        }
    }

    static setGeoCache(key, data) {
        try {
            const cache = SaveSystem.getGeoCache();
            cache[key] = data;
            localStorage.setItem(SaveSystem.GEO_CACHE_KEY, JSON.stringify(cache));
        } catch (e) {}
    }
}

/**
 * 2. КЛАСС Resources — управление ресурсами игрока (еда, топливо, металл, медикаменты, боеприпасы)
 */
class Resources {
    constructor(initial = {}) {
        this.food = initial.food ?? 320;
        this.fuel = initial.fuel ?? 260;
        this.metal = initial.metal ?? 350;
        this.meds = initial.meds ?? 140;
        this.ammo = initial.ammo ?? 280;
        this.maxStorage = initial.maxStorage ?? 2500;
    }

    hasEnough(cost) {
        return (
            this.food >= (cost.food || 0) &&
            this.fuel >= (cost.fuel || 0) &&
            this.metal >= (cost.metal || 0) &&
            this.meds >= (cost.meds || 0) &&
            this.ammo >= (cost.ammo || 0)
        );
    }

    spend(cost) {
        if (!this.hasEnough(cost)) return false;
        this.food -= (cost.food || 0);
        this.fuel -= (cost.fuel || 0);
        this.metal -= (cost.metal || 0);
        this.meds -= (cost.meds || 0);
        this.ammo -= (cost.ammo || 0);
        return true;
    }

    add(gain) {
        this.food = Math.min(this.maxStorage, Math.max(0, Math.round(this.food + (gain.food || 0))));
        this.fuel = Math.min(this.maxStorage, Math.max(0, Math.round(this.fuel + (gain.fuel || 0))));
        this.metal = Math.min(this.maxStorage, Math.max(0, Math.round(this.metal + (gain.metal || 0))));
        this.meds = Math.min(this.maxStorage, Math.max(0, Math.round(this.meds + (gain.meds || 0))));
        this.ammo = Math.min(this.maxStorage, Math.max(0, Math.round(this.ammo + (gain.ammo || 0))));
    }

    toJSON() {
        return {
            food: Math.round(this.food),
            fuel: Math.round(this.fuel),
            metal: Math.round(this.metal),
            meds: Math.round(this.meds),
            ammo: Math.round(this.ammo),
            maxStorage: this.maxStorage
        };
    }
}

/**
 * 3. КЛАСС Base — база игрока или противника, её характеристики и улучшения (уровни 1-5)
 */
class Base {
    constructor(data) {
        this.id = data.id;
        this.name = data.name;
        this.owner = data.owner || 'player'; // 'player' | 'enemy'
        this.lat = data.lat;
        this.lng = data.lng;
        this.terrain = data.terrain || 'city'; // 'city' | 'forest' | 'desert' | 'water' | 'plains'
        this.upgrades = data.upgrades || {
            walls: 1,
            turrets: 1,
            radar: 1,
            storage: 1,
            hospital: 1,
            workshop: 1
        };
        this.maxHp = this.calcMaxHp();
        this.hp = data.hp !== undefined ? Math.min(data.hp, this.maxHp) : this.maxHp;
    }

    calcMaxHp() {
        return 200 + (this.upgrades.walls - 1) * 90 + (this.upgrades.turrets - 1) * 35;
    }

    getDefensePower(commanderDefenseLvl = 1) {
        const baseDef = 35 + this.upgrades.walls * 22 + this.upgrades.turrets * 28;
        const terrainMod = this.terrain === 'forest' ? 1.35 : (this.terrain === 'city' ? 1.1 : 1.0);
        const cmdMod = 1 + (commanderDefenseLvl - 1) * 0.18;
        return Math.round(baseDef * terrainMod * cmdMod);
    }

    getTerritoryRadiusKm(commanderRadarLvl = 1) {
        return Math.round((45 + (this.upgrades.radar - 1) * 14) * (1 + (commanderRadarLvl - 1) * 0.15));
    }

    getProductionPerTick(commanderCargoLvl = 1) {
        const mult = (1 + (this.upgrades.storage - 1) * 0.2) *
                     (this.terrain === 'city' ? 1.4 : 1.0) *
                     (1 + (commanderCargoLvl - 1) * 0.2);
        return {
            food: 2.2 * mult,
            fuel: 1.6 * mult,
            metal: (1.8 + this.upgrades.workshop * 0.7) * mult,
            meds: (0.9 + this.upgrades.hospital * 0.65) * mult,
            ammo: (1.4 + this.upgrades.workshop * 0.85) * mult
        };
    }

    getUpgradeCost(key) {
        const lvl = this.upgrades[key] || 1;
        return {
            metal: 65 * lvl,
            fuel: 35 * lvl,
            food: 30 * lvl
        };
    }

    toJSON() {
        return {
            id: this.id,
            name: this.name,
            owner: this.owner,
            lat: this.lat,
            lng: this.lng,
            terrain: this.terrain,
            hp: Math.round(this.hp),
            upgrades: { ...this.upgrades }
        };
    }
}

/**
 * 4. КЛАСС Unit — отряд выживших или караван, перемещающийся по реальной карте
 */
class Unit {
    constructor(data) {
        this.id = data.id;
        this.name = data.name;
        this.type = data.type || 'squad'; // 'squad' | 'caravan'
        this.lat = data.lat;
        this.lng = data.lng;
        this.hp = data.hp ?? 100;
        this.maxHp = data.maxHp ?? 100;
        this.basePower = data.basePower ?? 65;
        this.speedKmh = data.speedKmh ?? 180; // Игровая тактическая скорость по карте
        this.targetLat = data.targetLat ?? null;
        this.targetLng = data.targetLng ?? null;
        this.targetPoiId = data.targetPoiId ?? null;
        this.currentTerrain = data.currentTerrain || 'plains';
        this.routeIds = data.routeIds || null; // Для караванов: [fromBaseId, toBaseId]
    }

    getCombatPower(commanderSquadLvl = 1, terrain = 'plains') {
        const cmdBonus = 1 + (commanderSquadLvl - 1) * 0.22;
        const hpFactor = 0.5 + 0.5 * (this.hp / this.maxHp);
        const terrainMod = terrain === 'forest' ? 1.2 : 1.0;
        return Math.round(this.basePower * cmdBonus * hpFactor * terrainMod);
    }

    setDestination(lat, lng, poiId = null) {
        this.targetLat = lat;
        this.targetLng = lng;
        this.targetPoiId = poiId;
    }

    isMoving() {
        return this.targetLat !== null && this.targetLng !== null;
    }

    toJSON() {
        return {
            id: this.id,
            name: this.name,
            type: this.type,
            lat: this.lat,
            lng: this.lng,
            hp: Math.round(this.hp),
            maxHp: this.maxHp,
            basePower: this.basePower,
            speedKmh: this.speedKmh,
            targetLat: this.targetLat,
            targetLng: this.targetLng,
            targetPoiId: this.targetPoiId,
            currentTerrain: this.currentTerrain,
            routeIds: this.routeIds
        };
    }
}

/**
 * 5. КЛАСС Combat — расчёт и симуляция боя за базу противника
 */
class Combat {
    static simulateAssault(unit, enemyBase, game) {
        const cmdSquadLvl = game.commander.upgrades.squadPower;
        const unitPower = unit.getCombatPower(cmdSquadLvl, enemyBase.terrain);
        const baseDefense = enemyBase.getDefensePower(1);

        // Бонус от боеприпасов и тактической разведки
        const ammoBonus = game.resources.ammo >= 35 ? 1.25 : 0.85;
        const randomFactor = 0.9 + Math.random() * 0.28;
        const effectiveAttack = Math.round(unitPower * ammoBonus * randomFactor);

        const rounds = [];
        let remEnemyHp = enemyBase.hp;
        let remUnitHp = unit.hp;

        for (let r = 1; r <= 3; r++) {
            const dmgToBase = Math.round((effectiveAttack / 2.1) * (0.85 + Math.random() * 0.3));
            const dmgToUnit = Math.round((baseDefense / 4.2) * (0.8 + Math.random() * 0.35));
            remEnemyHp = Math.max(0, remEnemyHp - dmgToBase);
            remUnitHp = Math.max(10, remUnitHp - dmgToUnit);
            rounds.push(
                `Фаза ${r}: Отряд «${unit.name}» наносит ${dmgToBase} ед. урона укреплениям. Ответный огонь турелей: -${dmgToUnit}% состава.`
            );
            if (remEnemyHp <= 0) break;
        }

        const victory = effectiveAttack >= baseDefense * 0.82 || remEnemyHp <= 0;
        const ammoSpent = Math.min(game.resources.ammo, 35);
        const loot = victory ? {
            food: 95 + Math.floor(Math.random() * 60),
            fuel: 80 + Math.floor(Math.random() * 50),
            metal: 130 + Math.floor(Math.random() * 70),
            meds: 45 + Math.floor(Math.random() * 30),
            ammo: 60 + Math.floor(Math.random() * 40)
        } : null;

        return {
            victory,
            unitPower,
            effectiveAttack,
            baseDefense,
            unitHpAfter: remUnitHp,
            enemyHpAfter: victory ? 0 : Math.max(25, remEnemyHp),
            ammoSpent,
            rounds,
            loot
        };
    }
}

/**
 * 6. КЛАСС MapManager — обёртка над Leaflet.js, слои карты, маркеры, полигоны и гео-анализ
 */
class MapManager {
    constructor(game) {
        this.game = game;
        this.map = null;
        this.tileLayer = null;
        this.currentTileTheme = 'dark';
        this.markers = new Map();
        this.polygons = new Map();
        this.routeLines = new Map();
    }

    initMap() {
        if (this.map) return;

        // Центр по умолчанию — Европа / Западная Азия
        this.map = L.map('world-map', {
            center: [50.45, 30.52],
            zoom: 5,
            minZoom: 2,
            maxZoom: 18,
            zoomControl: false
        });

        L.control.zoom({ position: 'bottomright' }).addTo(this.map);

        this.setTileSource('dark');

        // Обработка клика по карте
        this.map.on('click', (e) => {
            const { lat, lng } = e.latlng;
            this.game.handleMapClick(lat, lng);
        });

        this.renderAllObjects();
    }

    setTileSource(theme = 'dark') {
        this.currentTileTheme = theme;
        if (this.tileLayer) {
            this.map.removeLayer(this.tileLayer);
        }

        const darkUrl = 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png';
        const osmUrl = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
        const chosenUrl = theme === 'osm' ? osmUrl : darkUrl;

        this.tileLayer = L.tileLayer(chosenUrl, {
            attribution: '&copy; OpenStreetMap &copy; CARTO',
            subdomains: 'abcd',
            maxZoom: 18
        });

        // Обработка ошибки загрузки тайлов -> автоматический fallback на OpenStreetMap
        let fallbackTriggered = false;
        this.tileLayer.on('tileerror', () => {
            if (!fallbackTriggered && chosenUrl !== osmUrl) {
                fallbackTriggered = true;
                this.game.addLog('Внимание: сбой связи со спутником CartoDB. Переключение на резервный канал OpenStreetMap.', 'warn');
                this.setTileSource('osm');
            }
        });

        this.tileLayer.addTo(this.map);
    }

    /**
     * Определение типа местности по координатам (правила + Nominatim API с кэшем в localStorage)
     */
    classifyTerrainByRules(lat, lng) {
        // Проверка известных морских акваторий (Чёрное, Балтийское, Средиземное море, океаны)
        if (
            (lat > 41.2 && lat < 46.0 && lng > 28.5 && lng < 41.0) || // Чёрное море
            (lat > 54.0 && lat < 59.5 && lng > 17.0 && lng < 21.5) || // Балтика
            (lat > 32.0 && lat < 40.0 && lng > 12.0 && lng < 27.0) || // Средиземное
            (lng < -11.0 && lat > 35.0 && lat < 60.0)                 // Атлантика
        ) {
            return {
                code: 'water',
                label: 'Водная преграда / Море',
                effect: 'Блокирует пеший марш (нужен Понтон/Порт, скорость x0.35)'
            };
        }

        // Проверка пустынь и зон сильной радиации (Чернобыльская Зона, Сахара, Прикаспийская/Средняя Азия)
        const distChernobyl = calcHaversineKm(lat, lng, 51.389, 30.099);
        if (distChernobyl < 65 || (lat < 33.0 && lng > -5.0 && lng < 55.0) || (lat > 43.0 && lat < 48.0 && lng > 52.0 && lng < 68.0)) {
            return {
                code: 'desert',
                label: distChernobyl < 65 ? 'Аномальная Радиационная Зона' : 'Пустыня / Выжженная пустошь',
                effect: 'Радиационный/тепловой урон отряду (-3 HP/сек в пути)'
            };
        }

        // Проверка гор и густых лесов (Карпаты, Альпы, Урал, Кавказ, Скандинавия, Полесье)
        if (
            (lat > 46.5 && lat < 49.6 && lng > 22.0 && lng < 26.8) || // Карпаты
            (lat > 45.0 && lat < 48.0 && lng > 6.0 && lng < 15.5)  || // Альпы
            (lat > 41.5 && lat < 44.5 && lng > 39.5 && lng < 48.0) || // Кавказ
            (lat > 51.5 && lat < 64.0 && lng > 25.0 && lng < 38.0 && Math.abs(Math.sin(lat * 4 + lng * 3)) > 0.55)
        ) {
            return {
                code: 'forest',
                label: 'Горы и глухие леса',
                effect: '+35% к обороне базы, скорость отряда снижена (x0.65)'
            };
        }

        // Города и населённые узлы вокруг крупных координат
        return {
            code: 'city',
            label: 'Руины мегаполиса / Промзона',
            effect: '+40% к добыче ресурсов, но выше активность рейдеров'
        };
    }

    async queryLocationDetails(lat, lng) {
        const key = `${lat.toFixed(2)}_${lng.toFixed(2)}`;
        const cache = SaveSystem.getGeoCache();
        const ruleTerrain = this.classifyTerrainByRules(lat, lng);

        if (cache[key]) {
            return { ...ruleTerrain, placeName: cache[key].placeName };
        }

        try {
            const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat.toFixed(4)}&lon=${lng.toFixed(4)}&zoom=8`;
            const res = await fetch(url, { headers: { 'Accept-Language': 'ru' } });
            if (res.ok) {
                const data = await res.json();
                const placeName = data.display_name ? data.display_name.split(',').slice(0, 2).join(', ') : 'Дикий сектор';
                SaveSystem.setGeoCache(key, { placeName });
                return { ...ruleTerrain, placeName };
            }
        } catch (e) {
            // Офлайн или ограничение CORS в песочнице — используем встроенный гео-анализатор
        }
        return { ...ruleTerrain, placeName: `Сектор [${lat.toFixed(2)}, ${lng.toFixed(2)}]` };
    }

    renderAllObjects() {
        if (!this.map) return;

        // Очищаем старые слои
        this.markers.forEach(m => this.map.removeLayer(m));
        this.polygons.forEach(p => this.map.removeLayer(p));
        this.routeLines.forEach(l => this.map.removeLayer(l));
        this.markers.clear();
        this.polygons.clear();
        this.routeLines.clear();

        // 1. Отрисовка баз и полигонов территорий
        this.game.bases.forEach(base => {
            const isPlayer = base.owner === 'player';
            const radiusKm = base.getTerritoryRadiusKm(this.game.commander.upgrades.radarRange);
            const polyCoords = createTerritoryPolygonCoords(base.lat, base.lng, radiusKm, 8);

            const poly = L.polygon(polyCoords, {
                color: isPlayer ? '#38bdf8' : '#ef4444',
                weight: 2,
                dashArray: isPlayer ? null : '5, 5',
                fillColor: isPlayer ? '#0284c7' : '#dc2626',
                fillOpacity: 0.18
            }).addTo(this.map);
            this.polygons.set(base.id, poly);

            const iconHtml = `<div class="amt-marker ${isPlayer ? 'amt-marker-player' : 'amt-marker-enemy'}" style="width:34px;height:34px;">${isPlayer ? '🛡️' : '☠️'}</div>`;
            const icon = L.divIcon({ html: iconHtml, className: '', iconSize: [34, 34], iconAnchor: [17, 17] });

            const marker = L.marker([base.lat, base.lng], { icon }).addTo(this.map);
            marker.bindPopup(() => this.buildBasePopupHtml(base));
            this.markers.set(base.id, marker);
        });

        // 2. Отрисовка нейтральных руин и ресурсных точек
        this.game.pois.forEach(poi => {
            const isRuin = poi.kind === 'ruin';
            const cls = isRuin ? 'amt-marker-ruin' : 'amt-marker-resource';
            const emoji = isRuin ? '🏚️' : poi.icon;
            const icon = L.divIcon({
                html: `<div class="amt-marker ${cls}" style="width:28px;height:28px;font-size:14px;">${emoji}</div>`,
                className: '',
                iconSize: [28, 28],
                iconAnchor: [14, 14]
            });

            const marker = L.marker([poi.lat, poi.lng], { icon }).addTo(this.map);
            marker.bindPopup(() => this.buildPoiPopupHtml(poi));
            this.markers.set(poi.id, marker);
        });

        // 3. Отрисовка отрядов и караванов
        this.game.units.forEach(unit => {
            this.updateUnitMarker(unit);
        });
    }

    updateUnitMarker(unit) {
        if (!this.map) return;
        const isCaravan = unit.type === 'caravan';
        const isSelected = this.game.selectedUnitId === unit.id;
        const cls = isCaravan ? 'amt-marker-caravan' : 'amt-marker-unit';
        const emoji = isCaravan ? '🚚' : '🪖';
        const size = isSelected ? 34 : 28;

        const icon = L.divIcon({
            html: `<div class="amt-marker ${cls}" style="width:${size}px;height:${size}px;${isSelected ? 'border:2px solid #fff700;transform:scale(1.15);' : ''}">${emoji}</div>`,
            className: '',
            iconSize: [size, size],
            iconAnchor: [size / 2, size / 2]
        });

        if (this.markers.has(unit.id)) {
            const m = this.markers.get(unit.id);
            m.setLatLng([unit.lat, unit.lng]);
            m.setIcon(icon);
        } else {
            const m = L.marker([unit.lat, unit.lng], { icon, zIndexOffset: 500 }).addTo(this.map);
            m.on('click', () => {
                if (unit.type === 'squad') {
                    this.game.selectUnit(unit.id);
                }
            });
            m.bindTooltip(`${unit.name} (${Math.round(unit.hp)} HP)`, { direction: 'top', offset: [0, -14] });
            this.markers.set(unit.id, m);
        }

        // Линия маршрута
        if (unit.isMoving()) {
            const coords = [[unit.lat, unit.lng], [unit.targetLat, unit.targetLng]];
            if (this.routeLines.has(unit.id)) {
                this.routeLines.get(unit.id).setLatLngs(coords);
            } else {
                const line = L.polyline(coords, {
                    color: isCaravan ? '#4ade80' : '#ffb700',
                    weight: 2,
                    dashArray: '6, 6'
                }).addTo(this.map);
                this.routeLines.set(unit.id, line);
            }
        } else if (this.routeLines.has(unit.id)) {
            this.map.removeLayer(this.routeLines.get(unit.id));
            this.routeLines.delete(unit.id);
        }
    }

    buildBasePopupHtml(base) {
        const isPlayer = base.owner === 'player';
        const def = base.getDefensePower(isPlayer ? this.game.commander.upgrades.baseDefense : 1);
        return `
            <div style="min-width:210px;">
                <div style="font-weight:bold;color:${isPlayer ? '#38bdf8' : '#f87171'};font-size:13px;margin-bottom:4px;">
                    ${isPlayer ? '🛡️' : '☠️'} ${base.name}
                </div>
                <div style="color:#b8a686;margin-bottom:4px;">Статус: ${isPlayer ? 'База Выживших' : 'Укрепрайон Рейдеров'}</div>
                <div>Прочность: <b>${Math.round(base.hp)} / ${base.maxHp} HP</b></div>
                <div>Оборона: <b>⚔️ ${def} ед.</b> | Радар: <b>${base.getTerritoryRadiusKm(this.game.commander.upgrades.radarRange)} км</b></div>
                <div style="margin-top:8px;display:flex;gap:6px;">
                    ${isPlayer
                        ? `<button class="btn-stalker btn-sm" onclick="window.amtGame.openBaseModal('${base.id}')">⚙️ Улучшить</button>`
                        : `<button class="btn-stalker btn-rust btn-sm" onclick="window.amtGame.initiateAttackOnBase('${base.id}')">⚔️ Штурмовать</button>`
                    }
                    <button class="btn-stalker btn-sm" onclick="window.amtGame.sendSelectedUnitTo(${base.lat}, ${base.lng}, '${base.id}')">🥾 Марш сюда</button>
                </div>
            </div>
        `;
    }

    buildPoiPopupHtml(poi) {
        const isRuin = poi.kind === 'ruin';
        return `
            <div style="min-width:200px;">
                <div style="font-weight:bold;color:#facc15;font-size:13px;margin-bottom:4px;">
                    ${poi.icon} ${poi.name}
                </div>
                <div style="color:#b8a686;margin-bottom:6px;">
                    ${isRuin ? (poi.explored ? 'Руины зачищены' : 'Неразведанные руины (богатый хабар)') : `Ресурсная точка (${poi.captured ? 'Под вашим контролем' : 'Нейтральная'})`}
                </div>
                <button class="btn-stalker btn-sm" onclick="window.amtGame.sendSelectedUnitTo(${poi.lat}, ${poi.lng}, '${poi.id}')">
                    🥾 Отправить выбранный отряд
                </button>
            </div>
        `;
    }
}

/**
 * 7. КЛАСС Game — главный контроллер состояния игры, цикла симуляции и UI
 */
class Game {
    constructor() {
        this.audio = new AudioFX();
        this.resources = new Resources();
        this.bases = [];
        this.units = [];
        this.pois = [];
        this.commander = {
            level: 1,
            xp: 0,
            upgrades: {
                squadPower: 1,
                marchSpeed: 1,
                cargoYield: 1,
                baseDefense: 1,
                radarRange: 1
            }
        };
        this.settings = {
            mapTile: 'dark',
            stalkerFilter: true,
            simSpeed: 1,
            difficulty: 'stalker'
        };
        this.dayTimeMinutes = 8 * 60; // Начинаем в 08:00 утра
        this.dayCount = 1;
        this.raidCountdownSec = 75;
        this.selectedUnitId = null;
        this.activeTab = 'bases';
        this.mapClickMode = 'move'; // 'move' | 'build'
        this.pendingCombatTargetId = null;
        this.mapManager = new MapManager(this);
        this.loopTimer = null;
        this.autoSaveTimer = null;
    }

    /**
     * Формирование стартового состояния (2 базы игрока, 5 вражеских, 3 нейтральные руины, ресурсные точки)
     */
    loadDefaultState() {
        this.resources = new Resources({
            food: 360,
            fuel: 280,
            metal: 400,
            meds: 160,
            ammo: 300,
            maxStorage: 3000
        });

        // 2 базы игрока
        const initialBases = [
            new Base({
                id: 'base_p1',
                name: 'Бункер-01 «Киев-Кордон»',
                owner: 'player',
                lat: 50.4501,
                lng: 30.5234,
                terrain: 'city',
                upgrades: { walls: 2, turrets: 2, radar: 2, storage: 2, hospital: 1, workshop: 2 }
            }),
            new Base({
                id: 'base_p2',
                name: 'Форпост-02 «Варшава-Восток»',
                owner: 'player',
                lat: 52.2297,
                lng: 21.0122,
                terrain: 'city',
                upgrades: { walls: 1, turrets: 2, radar: 1, storage: 1, hospital: 2, workshop: 1 }
            }),
            // 5 вражеских баз
            new Base({
                id: 'base_e1',
                name: 'Цитадель Рейдеров «Припять»',
                owner: 'enemy',
                lat: 51.3890,
                lng: 30.0990,
                terrain: 'desert',
                upgrades: { walls: 2, turrets: 2, radar: 2, storage: 1, hospital: 1, workshop: 1 }
            }),
            new Base({
                id: 'base_e2',
                name: 'База Мародёров «Минск-Промзона»',
                owner: 'enemy',
                lat: 53.9006,
                lng: 27.5590,
                terrain: 'city',
                upgrades: { walls: 1, turrets: 2, radar: 1, storage: 1, hospital: 1, workshop: 1 }
            }),
            new Base({
                id: 'base_e3',
                name: 'Крепость Синдиката «Карпаты»',
                owner: 'enemy',
                lat: 48.6208,
                lng: 22.2879,
                terrain: 'forest',
                upgrades: { walls: 2, turrets: 1, radar: 2, storage: 1, hospital: 1, workshop: 1 }
            }),
            new Base({
                id: 'base_e4',
                name: 'Гарнизон «Бухарест-Юг»',
                owner: 'enemy',
                lat: 44.4268,
                lng: 26.1025,
                terrain: 'city',
                upgrades: { walls: 2, turrets: 2, radar: 1, storage: 2, hospital: 1, workshop: 1 }
            }),
            new Base({
                id: 'base_e5',
                name: 'Бастион «Харьков-Сталь»',
                owner: 'enemy',
                lat: 49.9935,
                lng: 36.2304,
                terrain: 'city',
                upgrades: { walls: 3, turrets: 2, radar: 2, storage: 2, hospital: 1, workshop: 2 }
            })
        ];
        this.bases = initialBases;

        // 3 нейтральные руины + 4 ресурсные точки
        this.pois = [
            { id: 'ruin_1', kind: 'ruin', name: 'Заброшенный НИИ «Янтарь»', icon: '🏚️', lat: 50.2547, lng: 28.6587, explored: false },
            { id: 'ruin_2', kind: 'ruin', name: 'Секретный Бункер Госрезерва', icon: '🏚️', lat: 51.2465, lng: 22.5684, explored: false },
            { id: 'ruin_3', kind: 'ruin', name: 'Разрушенный Аэродром «Полтава»', icon: '🏚️', lat: 49.5883, lng: 34.5514, explored: false },
            { id: 'res_1', kind: 'resource', resType: 'fuel', name: 'Нефтеперегонный узел «Мозырь»', icon: '⛽', lat: 52.0495, lng: 29.2456, captured: true },
            { id: 'res_2', kind: 'resource', resType: 'metal', name: 'Сталелитейный завод «Кривой Рог»', icon: '⚙️', lat: 47.9105, lng: 33.3918, captured: false },
            { id: 'res_3', kind: 'resource', resType: 'ammo', name: 'Военные склады «Орша»', icon: '🔫', lat: 54.5082, lng: 30.4172, captured: false },
            { id: 'res_4', kind: 'resource', resType: 'meds', name: 'Химфармлаборатория «Львов»', icon: '💉', lat: 49.8397, lng: 24.0297, captured: true }
        ];

        // Отряды игрока и караван снабжения
        this.units = [
            new Unit({
                id: 'unit_1',
                name: 'Штурм-группа «Сталкер-1»',
                type: 'squad',
                lat: 50.4501,
                lng: 30.5234,
                hp: 100,
                maxHp: 100,
                basePower: 85,
                speedKmh: 210
            }),
            new Unit({
                id: 'unit_2',
                name: 'Разведбат «Запад»',
                type: 'squad',
                lat: 52.2297,
                lng: 21.0122,
                hp: 100,
                maxHp: 100,
                basePower: 75,
                speedKmh: 230
            }),
            new Unit({
                id: 'caravan_1',
                name: 'Караван Снабжения #1',
                type: 'caravan',
                lat: 50.4501,
                lng: 30.5234,
                hp: 100,
                maxHp: 100,
                basePower: 25,
                speedKmh: 165,
                targetLat: 52.2297,
                targetLng: 21.0122,
                routeIds: ['base_p1', 'base_p2']
            })
        ];

        this.selectedUnitId = 'unit_1';
        this.commander = {
            level: 1,
            xp: 0,
            upgrades: { squadPower: 1, marchSpeed: 1, cargoYield: 1, baseDefense: 1, radarRange: 1 }
        };
        this.dayCount = 1;
        this.dayTimeMinutes = 8 * 60;
        this.raidCountdownSec = 75;
    }

    /**
     * Загрузка из сохранения или инициализация по умолчанию
     */
    initState() {
        const saved = SaveSystem.loadGame();
        if (saved && saved.bases && saved.bases.length > 0) {
            this.resources = new Resources(saved.resources);
            this.bases = saved.bases.map(b => new Base(b));
            this.units = saved.units.map(u => new Unit(u));
            this.pois = saved.pois || [];
            this.commander = saved.commander || this.commander;
            this.settings = { ...this.settings, ...(saved.settings || {}) };
            this.dayCount = saved.dayCount || 1;
            this.dayTimeMinutes = saved.dayTimeMinutes || 480;
            this.selectedUnitId = this.units.find(u => u.type === 'squad')?.id || null;
        } else {
            this.loadDefaultState();
        }
        this.applyVisualSettings();
    }

    toJSON() {
        return {
            resources: this.resources.toJSON(),
            bases: this.bases.map(b => b.toJSON()),
            units: this.units.map(u => u.toJSON()),
            pois: this.pois,
            commander: this.commander,
            settings: this.settings,
            dayCount: this.dayCount,
            dayTimeMinutes: this.dayTimeMinutes
        };
    }

    saveNow(showNotification = true) {
        const ok = SaveSystem.saveGame(this.toJSON());
        if (showNotification && ok) {
            this.addLog('Прогресс экспедиции сохранён в энергонезависимую память ПДА.', 'info');
            this.audio.pdaBeep();
        }
    }

    startSimulation() {
        this.mapManager.initMap();
        this.renderHUD();
        this.renderSidePanel();

        if (this.loopTimer) clearInterval(this.loopTimer);
        if (this.autoSaveTimer) clearInterval(this.autoSaveTimer);

        // Основной игровой цикл (каждые 500 мс)
        this.loopTimer = setInterval(() => this.tick(0.5), 500);

        // Автосохранение каждые 30 секунд
        this.autoSaveTimer = setInterval(() => this.saveNow(false), 30000);
    }

    tick(dtSec) {
        const speed = this.settings.simSpeed || 1;
        const dt = dtSec * speed;

        // 1. Время суток
        this.dayTimeMinutes += dt * 4;
        if (this.dayTimeMinutes >= 1440) {
            this.dayTimeMinutes -= 1440;
            this.dayCount += 1;
            this.addLog(`Наступил День ${this.dayCount}. Сводка радаров обновлена.`, 'info');
        }
        const hour = Math.floor(this.dayTimeMinutes / 60);
        const isNight = hour >= 21 || hour < 6;
        document.body.classList.toggle('night-cycle', isNight);

        // 2. Выработка ресурсов на базах игрока и ресурсных точках
        const playerBases = this.bases.filter(b => b.owner === 'player');
        let totalMaxStorage = 1500;
        const tickGain = { food: 0, fuel: 0, metal: 0, meds: 0, ammo: 0 };

        playerBases.forEach(base => {
            totalMaxStorage += base.upgrades.storage * 750;
            const prod = base.getProductionPerTick(this.commander.upgrades.cargoYield);
            tickGain.food += prod.food * (dt / 10);
            tickGain.fuel += prod.fuel * (dt / 10);
            tickGain.metal += prod.metal * (dt / 10);
            tickGain.meds += prod.meds * (dt / 10);
            tickGain.ammo += prod.ammo * (dt / 10);
        });

        this.pois.filter(p => p.kind === 'resource' && p.captured).forEach(p => {
            tickGain[p.resType] = (tickGain[p.resType] || 0) + 1.8 * (dt / 10);
        });

        this.resources.maxStorage = totalMaxStorage;
        this.resources.add(tickGain);

        // 3. Передвижение отрядов и караванов
        this.units.forEach(unit => {
            if (unit.isMoving()) {
                this.moveUnitStep(unit, dt);
            } else if (unit.type === 'squad') {
                // Лечение на союзной базе с госпиталем
                const nearBase = playerBases.find(b => calcHaversineKm(unit.lat, unit.lng, b.lat, b.lng) < 25);
                if (nearBase && unit.hp < unit.maxHp) {
                    unit.hp = Math.min(unit.maxHp, unit.hp + nearBase.upgrades.hospital * 1.5 * dt);
                }
            }
        });

        // 4. Таймер атаки рейдеров
        const enemyBases = this.bases.filter(b => b.owner === 'enemy');
        if (enemyBases.length > 0 && playerBases.length > 0) {
            this.raidCountdownSec -= dt;
            if (this.raidCountdownSec <= 0) {
                this.triggerEnemyRaid();
                this.raidCountdownSec = this.settings.difficulty === 'master' ? 50 : 75;
            }
        }

        this.renderHUD();
    }

    moveUnitStep(unit, dt) {
        const distKm = calcHaversineKm(unit.lat, unit.lng, unit.targetLat, unit.targetLng);
        const terrainInfo = this.mapManager.classifyTerrainByRules(unit.lat, unit.lng);
        unit.currentTerrain = terrainInfo.code;

        let terrainSpeedMod = 1.0;
        if (terrainInfo.code === 'forest') terrainSpeedMod = 0.65;
        if (terrainInfo.code === 'water') {
            terrainSpeedMod = this.commander.upgrades.radarRange >= 2 ? 0.85 : 0.35;
        }

        // Урон в пустыне / радиационной зоне
        if (terrainInfo.code === 'desert' && unit.type === 'squad') {
            const radDmg = Math.max(0.3, 1.4 - (this.commander.upgrades.radarRange - 1) * 0.3) * dt;
            unit.hp = Math.max(15, unit.hp - radDmg);
            if (Math.random() < 0.15) this.audio.geigerClick();
        }

        const cmdSpeedBonus = 1 + (this.commander.upgrades.marchSpeed - 1) * 0.25;
        const stepKm = (unit.speedKmh * cmdSpeedBonus * terrainSpeedMod) * (dt / 3.2);

        if (distKm <= stepKm || distKm < 3) {
            unit.lat = unit.targetLat;
            unit.lng = unit.targetLng;
            const arrivedPoiId = unit.targetPoiId;
            unit.targetLat = null;
            unit.targetLng = null;
            unit.targetPoiId = null;
            this.onUnitArrived(unit, arrivedPoiId);
        } else {
            const ratio = stepKm / distKm;
            unit.lat += (unit.targetLat - unit.lat) * ratio;
            unit.lng += (unit.targetLng - unit.lng) * ratio;
        }

        this.mapManager.updateUnitMarker(unit);
    }

    onUnitArrived(unit, targetId) {
        // Если это караван — доставляет ресурсы и разворачивается к следующей базе
        if (unit.type === 'caravan' && unit.routeIds) {
            const bonus = 30 * this.commander.upgrades.cargoYield;
            this.resources.add({ food: bonus, fuel: bonus * 0.7, metal: bonus });
            this.addLog(`${unit.name} доставил конвой ресурсов (+${bonus} еды и металла).`, 'loot');
            const [b1, b2] = unit.routeIds;
            const nextId = calcHaversineKm(unit.lat, unit.lng, this.getBaseById(b1)?.lat || 0, this.getBaseById(b1)?.lng || 0) < 15 ? b2 : b1;
            const nextBase = this.getBaseById(nextId);
            if (nextBase) {
                unit.setDestination(nextBase.lat, nextBase.lng);
            }
            return;
        }

        this.audio.pdaBeep();

        // Проверяем, пришёл ли отряд к руинам или ресурсной точке
        const poi = this.pois.find(p => p.id === targetId) ||
                    this.pois.find(p => calcHaversineKm(unit.lat, unit.lng, p.lat, p.lng) < 18);

        if (poi) {
            if (poi.kind === 'ruin' && !poi.explored) {
                poi.explored = true;
                const reward = { food: 110, fuel: 90, metal: 140, meds: 65, ammo: 95 };
                this.resources.add(reward);
                this.gainXp(45);
                this.addLog(`Отряд «${unit.name}» исследовал «${poi.name}»! Найдено: +140⚙️ +110🥫 +95🔫 +65💉.`, 'loot');
                this.mapManager.renderAllObjects();
            } else if (poi.kind === 'resource' && !poi.captured) {
                poi.captured = true;
                this.gainXp(35);
                this.addLog(`Точка «${poi.name}» взята под охрану отрядом «${unit.name}»! Добыча увеличена.`, 'build');
                this.mapManager.renderAllObjects();
            }
        }

        // Проверяем, пришёл ли отряд к вражеской базе
        const enemyBase = this.bases.find(b => b.owner === 'enemy' && (b.id === targetId || calcHaversineKm(unit.lat, unit.lng, b.lat, b.lng) < 20));
        if (enemyBase) {
            this.initiateAttackOnBase(enemyBase.id, unit.id);
        } else {
            this.addLog(`Отряд «${unit.name}» прибыл в заданный квадрат [${unit.lat.toFixed(2)}, ${unit.lng.toFixed(2)}].`, 'info');
        }

        this.renderSidePanel();
    }

    triggerEnemyRaid() {
        const playerBases = this.bases.filter(b => b.owner === 'player');
        const enemyBases = this.bases.filter(b => b.owner === 'enemy');
        if (!playerBases.length || !enemyBases.length) return;

        const targetBase = playerBases[Math.floor(Math.random() * playerBases.length)];
        const attacker = enemyBases[Math.floor(Math.random() * enemyBases.length)];

        const raidStrength = (55 + this.dayCount * 8) * (this.settings.difficulty === 'master' ? 1.35 : 1.0);
        const defense = targetBase.getDefensePower(this.commander.upgrades.baseDefense);

        this.audio.alarm();

        if (defense >= raidStrength) {
            const lightDmg = Math.max(8, Math.round(raidStrength * 0.18));
            targetBase.hp = Math.max(30, targetBase.hp - lightDmg);
            this.gainXp(25);
            this.addLog(`Атака рейдеров из «${attacker.name}» на «${targetBase.name}» ОТБИТА турелями! Урон стенам: -${lightDmg} HP.`, 'combat');
        } else {
            const heavyDmg = Math.round((raidStrength - defense * 0.5) * 0.75);
            targetBase.hp = Math.max(15, targetBase.hp - heavyDmg);
            this.resources.spend({ food: Math.min(30, this.resources.food), metal: Math.min(25, this.resources.metal) });
            this.addLog(`Прорыв периметра «${targetBase.name}» рейдерами! Потеряно ${heavyDmg} HP базы и часть припасов.`, 'combat');
        }
        this.renderSidePanel();
    }

    gainXp(amount) {
        this.commander.xp += amount;
        const needed = this.commander.level * 100;
        if (this.commander.xp >= needed) {
            this.commander.xp -= needed;
            this.commander.level += 1;
            this.addLog(`Повышение ранга! Командир достиг уровня ${this.commander.level}.`, 'loot');
        }
    }

    getBaseById(id) {
        return this.bases.find(b => b.id === id);
    }

    selectUnit(unitId) {
        this.selectedUnitId = unitId;
        const unit = this.units.find(u => u.id === unitId);
        if (unit && this.mapManager.map) {
            this.mapManager.map.panTo([unit.lat, unit.lng]);
        }
        this.mapManager.renderAllObjects();
        this.renderSidePanel();
    }

    setMapMode(mode) {
        this.mapClickMode = mode;
        const banner = document.getElementById('map-mode-banner');
        const text = document.getElementById('map-mode-text');
        if (mode === 'build') {
            banner.classList.remove('hidden');
            text.textContent = '🏗️ РЕЖИМ ПОСТРОЙКИ БАЗЫ: Кликните в любую точку на суше (Стоимость: 180⚙️ 100⛽ 120🥫)';
        } else {
            banner.classList.add('hidden');
        }
    }

    async handleMapClick(lat, lng) {
        const geo = await this.mapManager.queryLocationDetails(lat, lng);
        this.updateGeoInspector(lat, lng, geo);

        if (this.mapClickMode === 'build') {
            this.buildNewBaseAt(lat, lng, geo);
            this.setMapMode('move');
            return;
        }

        // Передвижение выбранного отряда
        this.sendSelectedUnitTo(lat, lng, null, geo);
    }

    sendSelectedUnitTo(lat, lng, poiId = null, precomputedGeo = null) {
        const unit = this.units.find(u => u.id === this.selectedUnitId && u.type === 'squad');
        if (!unit) {
            this.addLog('Выберите штурмовой отряд в левой панели для отправки по маршруту.', 'warn');
            return;
        }

        const geo = precomputedGeo || this.mapManager.classifyTerrainByRules(lat, lng);
        if (geo.code === 'water' && this.commander.upgrades.radarRange < 2) {
            this.addLog('Маршрут через глубоководную акваторию заблокирован! Прокачайте «Дальнюю РЛС и Понтоны» до ур. 2.', 'warn');
            this.audio.alarm();
            return;
        }

        const distKm = Math.round(calcHaversineKm(unit.lat, unit.lng, lat, lng));
        const fuelCost = Math.max(4, Math.min(45, Math.round(distKm * 0.03)));

        if (this.resources.fuel < fuelCost) {
            this.addLog(`Недостаточно топлива для марш-броска (${distKm} км, требуется ${fuelCost}⛽).`, 'warn');
            return;
        }

        this.resources.spend({ fuel: fuelCost });
        unit.setDestination(lat, lng, poiId);
        this.audio.pdaBeep();
        this.addLog(`Отряд «${unit.name}» выдвинулся в сектор (${distKm} км, расход ${fuelCost}⛽, местность: ${geo.label}).`, 'info');
        this.mapManager.updateUnitMarker(unit);
        this.renderSidePanel();
    }

    buildNewBaseAt(lat, lng, geo) {
        if (geo.code === 'water') {
            this.addLog('Невозможно основать наземную базу в открытом море!', 'warn');
            return;
        }
        const cost = { metal: 180, fuel: 100, food: 120 };
        if (!this.resources.hasEnough(cost)) {
            this.addLog('Не хватает ресурсов для строительства базы! Нужно: 180⚙️ Металла, 100⛽ Топлива, 120🥫 Еды.', 'warn');
            return;
        }

        this.resources.spend(cost);
        const idx = this.bases.filter(b => b.owner === 'player').length + 1;
        const newBase = new Base({
            id: 'base_p_' + Date.now(),
            name: `Аванпост-0${idx} «${geo.placeName ? geo.placeName.split(',')[0] : 'Рубеж'}»`,
            owner: 'player',
            lat,
            lng,
            terrain: geo.code
        });
        this.bases.push(newBase);
        this.gainXp(60);
        this.audio.pdaBeep();
        this.addLog(`Основана новая база «${newBase.name}»! Территория вокруг взята под контроль.`, 'build');
        this.mapManager.renderAllObjects();
        this.renderSidePanel();
    }

    updateGeoInspector(lat, lng, geo) {
        const elCoords = document.getElementById('geo-coords');
        const elPlace = document.getElementById('geo-place');
        const elTerrain = document.getElementById('geo-terrain');
        const elEffect = document.getElementById('geo-effect');
        if (elCoords) elCoords.textContent = `${lat.toFixed(3)}° N, ${lng.toFixed(3)}° E`;
        if (elPlace) elPlace.textContent = geo.placeName || 'Неизвестный сектор';
        if (elTerrain) elTerrain.textContent = geo.label;
        if (elEffect) elEffect.textContent = geo.effect;
    }

    /**
     * Открытие модального окна улучшения базы
     */
    openBaseModal(baseId) {
        const base = this.getBaseById(baseId);
        if (!base || base.owner !== 'player') return;

        const modal = document.getElementById('base-modal');
        const title = document.getElementById('base-modal-title');
        const body = document.getElementById('base-modal-body');

        title.textContent = `⚙️ Управление базой: ${base.name}`;

        const upgradeLabels = {
            walls: { name: '🧱 Защитные стены', desc: '+90 макс. HP и +22 к обороне базы' },
            turrets: { name: '🔫 Авто-турели', desc: '+28 к огневой обороне и отстрелу рейдеров' },
            radar: { name: '📡 Радар «Дуга-М»', desc: '+14 км к радиусу контролируемой территории' },
            storage: { name: '📦 Бункер-склад', desc: '+20% к выработке ресурсов и +750 к вместимости' },
            hospital: { name: '💉 Медсанчасть', desc: 'Ускоряет лечение отрядов и синтез медикаментов' },
            workshop: { name: '🛠️ Мастерская', desc: 'Производит боеприпасы и металл для штурмов' }
        };

        let html = `
            <div style="margin-bottom:14px;padding:10px;background:#1d160e;border:1px solid #4a3921;border-radius:3px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
                <div>
                    <div>Прочность укреплений: <b>${Math.round(base.hp)} / ${base.maxHp} HP</b> | Оборона: <b>🛡️ ${base.getDefensePower(this.commander.upgrades.baseDefense)}</b></div>
                    <div style="font-size:12px;color:#a8987d;">Местность сектора: ${base.terrain === 'city' ? 'Город (+40% добыча)' : (base.terrain === 'forest' ? 'Горы/Лес (+35% оборона)' : 'Пустошь')}</div>
                </div>
                <div style="display:flex;gap:8px;">
                    <button class="btn-stalker btn-sm" onclick="window.amtGame.repairBase('${base.id}')">🔧 Ремонт (50⚙️)</button>
                    <button class="btn-stalker btn-sm" onclick="window.amtGame.recruitUnitAtBase('${base.id}')">🪖 Нанять отряд (120🥫 80🔫)</button>
                </div>
            </div>
            <div class="upgrade-grid">
        `;

        Object.keys(upgradeLabels).forEach(key => {
            const lvl = base.upgrades[key];
            const info = upgradeLabels[key];
            const cost = base.getUpgradeCost(key);
            const isMax = lvl >= 5;
            html += `
                <div class="upgrade-item">
                    <div>
                        <div style="display:flex;justify-content:space-between;font-weight:bold;color:#ffb700;">
                            <span>${info.name}</span>
                            <span>Ур. ${lvl}/5</span>
                        </div>
                        <div style="font-size:11px;color:#b8a686;margin-top:4px;">${info.desc}</div>
                    </div>
                    <div>
                        ${isMax
                            ? `<button class="btn-stalker btn-sm" disabled style="width:100%;">МАКСИМАЛЬНЫЙ УРОВЕНЬ</button>`
                            : `<button class="btn-stalker btn-sm" style="width:100%;" onclick="window.amtGame.upgradeBaseModule('${base.id}', '${key}')">
                                Улучшить (${cost.metal}⚙️ ${cost.fuel}⛽ ${cost.food}🥫)
                               </button>`
                        }
                    </div>
                </div>
            `;
        });

        html += `</div>`;
        body.innerHTML = html;
        modal.classList.remove('hidden');
    }

    upgradeBaseModule(baseId, key) {
        const base = this.getBaseById(baseId);
        if (!base || base.upgrades[key] >= 5) return;
        const cost = base.getUpgradeCost(key);
        if (!this.resources.hasEnough(cost)) {
            this.addLog('Недостаточно ресурсов на складах для модернизации модуля базы.', 'warn');
            return;
        }
        this.resources.spend(cost);
        base.upgrades[key] += 1;
        base.maxHp = base.calcMaxHp();
        base.hp = Math.min(base.maxHp, base.hp + 60);
        this.gainXp(30);
        this.audio.pdaBeep();
        this.addLog(`На базе «${base.name}» улучшен модуль (${key} -> Ур. ${base.upgrades[key]}).`, 'build');
        this.mapManager.renderAllObjects();
        this.openBaseModal(baseId);
        this.renderSidePanel();
    }

    repairBase(baseId) {
        const base = this.getBaseById(baseId);
        if (!base || base.hp >= base.maxHp) return;
        if (!this.resources.spend({ metal: 50 })) {
            this.addLog('Нужно 50⚙️ Металла для капитального ремонта стен базы.', 'warn');
            return;
        }
        base.hp = base.maxHp;
        this.audio.pdaBeep();
        this.addLog(`Укрепления базы «${base.name}» полностью восстановлены.`, 'build');
        this.openBaseModal(baseId);
        this.renderSidePanel();
    }

    recruitUnitAtBase(baseId) {
        const base = this.getBaseById(baseId);
        if (!base) return;
        const cost = { food: 120, ammo: 80 };
        if (!this.resources.spend(cost)) {
            this.addLog('Недостаточно ресурсов для формирования нового отряда (нужно 120🥫 и 80🔫).', 'warn');
            return;
        }
        const count = this.units.filter(u => u.type === 'squad').length + 1;
        const unit = new Unit({
            id: 'unit_' + Date.now(),
            name: `Спецгруппа «Вега-${count}»`,
            type: 'squad',
            lat: base.lat + 0.08,
            lng: base.lng + 0.08,
            hp: 100,
            maxHp: 100,
            basePower: 85,
            speedKmh: 215
        });
        this.units.push(unit);
        this.selectedUnitId = unit.id;
        this.audio.pdaBeep();
        this.addLog(`На базе «${base.name}» сформирован новый отряд «${unit.name}».`, 'build');
        this.mapManager.renderAllObjects();
        this.renderSidePanel();
    }

    /**
     * Подготовка и проведение штурма вражеской базы
     */
    initiateAttackOnBase(enemyBaseId, forcedUnitId = null) {
        const enemyBase = this.getBaseById(enemyBaseId);
        if (!enemyBase || enemyBase.owner === 'player') return;

        const unitId = forcedUnitId || this.selectedUnitId;
        const unit = this.units.find(u => u.id === unitId && u.type === 'squad') ||
                     this.units.find(u => u.type === 'squad');

        if (!unit) {
            this.addLog('У вас нет боеспособных отрядов для штурма!', 'warn');
            return;
        }

        this.pendingCombatTargetId = enemyBaseId;
        const modal = document.getElementById('combat-modal');
        const body = document.getElementById('combat-modal-body');
        const distKm = Math.round(calcHaversineKm(unit.lat, unit.lng, enemyBase.lat, enemyBase.lng));
        const unitPower = unit.getCombatPower(this.commander.upgrades.squadPower, enemyBase.terrain);
        const enemyDef = enemyBase.getDefensePower(1);

        body.innerHTML = `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px;">
                <div class="card-stalker">
                    <div class="card-title">🪖 Ваш отряд: ${unit.name}</div>
                    <div>Состав: <b>${Math.round(unit.hp)} / ${unit.maxHp}%</b></div>
                    <div>Ударная мощь: <b>⚔️ ${unitPower} ед.</b></div>
                    <div>Дистанция до цели: <b>${distKm} км</b></div>
                </div>
                <div class="card-stalker enemy-card">
                    <div class="card-title" style="color:#f87171;">☠️ Цель: ${enemyBase.name}</div>
                    <div>Укрепления: <b>${Math.round(enemyBase.hp)} / ${enemyBase.maxHp} HP</b></div>
                    <div>Защита гарнизона: <b>🛡️ ${enemyDef} ед.</b></div>
                    <div>Местность: <b>${enemyBase.terrain}</b></div>
                </div>
            </div>
            <div id="combat-result-log" class="terminal-console" style="max-height:160px;">
                <p>&gt; Тактический компьютер готов к расчёту штурма...</p>
                <p>&gt; Расход боекомплекта на операцию: 35 🔫 боеприпасов.</p>
            </div>
        `;

        const btnExecute = document.getElementById('btn-execute-combat');
        btnExecute.disabled = false;
        btnExecute.onclick = () => this.executeCombatRound(unit.id, enemyBase.id);

        modal.classList.remove('hidden');
    }

    executeCombatRound(unitId, enemyBaseId) {
        const unit = this.units.find(u => u.id === unitId);
        const enemyBase = this.getBaseById(enemyBaseId);
        if (!unit || !enemyBase) return;

        this.audio.combatShot();
        const result = Combat.simulateAssault(unit, enemyBase, this);
        this.resources.spend({ ammo: result.ammoSpent });
        unit.hp = result.unitHpAfter;
        unit.lat = enemyBase.lat;
        unit.lng = enemyBase.lng;
        unit.targetLat = null;
        unit.targetLng = null;

        const logBox = document.getElementById('combat-result-log');
        let html = result.rounds.map(r => `<p>&gt; ${r}</p>`).join('');

        if (result.victory) {
            enemyBase.owner = 'player';
            enemyBase.hp = Math.round(enemyBase.maxHp * 0.65);
            this.resources.add(result.loot);
            this.gainXp(100);
            html += `<p style="color:#4ade80;font-weight:bold;margin-top:6px;">&gt; ПОБЕДА! База «${enemyBase.name}» и прилегающая территория (~50 км) захвачены! Трофеи: +${result.loot.metal}⚙️ +${result.loot.food}🥫 +${result.loot.fuel}⛽.</p>`;
            this.addLog(`ШТУРМ УСПЕШЕН! База «${enemyBase.name}» перешла под наш контроль!`, 'combat');
            document.getElementById('btn-execute-combat').disabled = true;
        } else {
            enemyBase.hp = result.enemyHpAfter;
            html += `<p style="color:#f87171;font-weight:bold;margin-top:6px;">&gt; Штурм захлебнулся. Укрепления врага повреждены (осталось ${enemyBase.hp} HP), можно повторить атаку!</p>`;
            this.addLog(`Штурм «${enemyBase.name}» ослабил оборону противника до ${enemyBase.hp} HP.`, 'combat');
        }

        if (logBox) logBox.innerHTML = html;
        this.mapManager.renderAllObjects();
        this.renderSidePanel();
        this.renderHUD();
    }

    /**
     * Модальное окно прокачки дерева технологий командира
     */
    openTechModal() {
        const modal = document.getElementById('tech-modal');
        const body = document.getElementById('tech-modal-body');

        const branches = [
            { key: 'squadPower', name: '⚔️ Штурмовое вооружение', desc: '+22% к боевой мощи всех отрядов за уровень' },
            { key: 'marchSpeed', name: '🛞 Форсированные двигатели', desc: '+25% к скорости передвижения отрядов и караванов' },
            { key: 'cargoYield', name: '📦 Тяжёлая логистика', desc: '+20% к добыче ресурсов базами и вместимости конвоев' },
            { key: 'baseDefense', name: '🛡️ Автоматизированный периметр', desc: '+18% к защите всех союзных баз' },
            { key: 'radarRange', name: '📡 Дальняя РЛС и Понтонные мосты', desc: '+15% к радиусу территорий и проход через водные преграды (с ур. 2)' }
        ];

        let html = `<div class="upgrade-grid">`;
        branches.forEach(b => {
            const lvl = this.commander.upgrades[b.key];
            const cost = { metal: 90 * lvl, ammo: 55 * lvl, fuel: 50 * lvl };
            const isMax = lvl >= 5;
            html += `
                <div class="upgrade-item">
                    <div>
                        <div style="display:flex;justify-content:space-between;font-weight:bold;color:#ffb700;">
                            <span>${b.name}</span>
                            <span>Ур. ${lvl}/5</span>
                        </div>
                        <div style="font-size:11px;color:#b8a686;margin-top:4px;">${b.desc}</div>
                    </div>
                    ${isMax
                        ? `<button class="btn-stalker btn-sm" disabled>МАКСИМУМ</button>`
                        : `<button class="btn-stalker btn-sm" onclick="window.amtGame.upgradeCommanderTech('${b.key}')">
                            Изучить (${cost.metal}⚙️ ${cost.ammo}🔫 ${cost.fuel}⛽)
                           </button>`
                    }
                </div>
            `;
        });
        html += `</div>`;
        body.innerHTML = html;
        modal.classList.remove('hidden');
    }

    upgradeCommanderTech(key) {
        const lvl = this.commander.upgrades[key];
        if (lvl >= 5) return;
        const cost = { metal: 90 * lvl, ammo: 55 * lvl, fuel: 50 * lvl };
        if (!this.resources.spend(cost)) {
            this.addLog('Недостаточно ресурсов для исследования технологии штаба!', 'warn');
            return;
        }
        this.commander.upgrades[key] += 1;
        this.gainXp(50);
        this.audio.pdaBeep();
        this.addLog(`Исследована технология штаба (${key} -> Ур. ${this.commander.upgrades[key]}).`, 'build');
        this.mapManager.renderAllObjects();
        this.openTechModal();
        this.renderSidePanel();
    }

    /**
     * Обновление верхнего HUD и боковой панели
     */
    renderHUD() {
        const setTxt = (id, val) => {
            const el = document.getElementById(id);
            if (el) el.textContent = val;
        };

        setTxt('res-food', Math.round(this.resources.food));
        setTxt('res-fuel', Math.round(this.resources.fuel));
        setTxt('res-metal', Math.round(this.resources.metal));
        setTxt('res-meds', Math.round(this.resources.meds));
        setTxt('res-ammo', Math.round(this.resources.ammo));

        const h = String(Math.floor(this.dayTimeMinutes / 60)).padStart(2, '0');
        const m = String(Math.floor(this.dayTimeMinutes % 60)).padStart(2, '0');
        const isNight = Number(h) >= 21 || Number(h) < 6;
        setTxt('hud-time', `${isNight ? '🌙' : '☀️'} День ${this.dayCount} | ${h}:${m}`);
        setTxt('hud-level', `🎖️ Командир Ур. ${this.commander.level}`);
        setTxt('hud-raid', `⚠️ Рейд: ${Math.max(0, Math.ceil(this.raidCountdownSec))}с`);
    }

    switchTab(tab) {
        this.activeTab = tab;
        document.querySelectorAll('.panel-tab').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tab);
        });
        this.renderSidePanel();
    }

    renderSidePanel() {
        const container = document.getElementById('side-panel-content');
        if (!container) return;

        if (this.activeTab === 'bases') {
            const playerBases = this.bases.filter(b => b.owner === 'player');
            const enemyBases = this.bases.filter(b => b.owner === 'enemy');

            let html = `<div style="font-size:11px;color:#c9a227;text-transform:uppercase;">🛡️ Базы выживших (${playerBases.length})</div>`;
            playerBases.forEach(b => {
                const hpPct = Math.round((b.hp / b.maxHp) * 100);
                html += `
                    <div class="card-stalker">
                        <div class="card-header">
                            <span class="card-title">🛡️ ${b.name}</span>
                            <span class="card-badge">Защита: ${b.getDefensePower(this.commander.upgrades.baseDefense)}</span>
                        </div>
                        <div class="card-meta">Сектор: ${b.terrain} | Радар: ${b.getTerritoryRadiusKm(this.commander.upgrades.radarRange)} км</div>
                        <div class="hp-bar-wrap"><div class="hp-bar-inner" style="width:${hpPct}%;"></div></div>
                        <div class="card-actions">
                            <button class="btn-stalker btn-sm" onclick="window.amtGame.focusOnMap(${b.lat}, ${b.lng})">📍 На карте</button>
                            <button class="btn-stalker btn-sm" onclick="window.amtGame.openBaseModal('${b.id}')">⚙️ Модули</button>
                        </div>
                    </div>
                `;
            });

            html += `<div style="font-size:11px;color:#f87171;text-transform:uppercase;margin-top:8px;">☠️ Базы противников (${enemyBases.length})</div>`;
            if (enemyBases.length === 0) {
                html += `<div class="card-stalker"><div class="card-title" style="color:#4ade80;">🏆 Все сектора зачищены от рейдеров!</div></div>`;
            }
            enemyBases.forEach(b => {
                const hpPct = Math.round((b.hp / b.maxHp) * 100);
                html += `
                    <div class="card-stalker enemy-card">
                        <div class="card-header">
                            <span class="card-title" style="color:#fca5a5;">☠️ ${b.name}</span>
                            <span class="card-badge">Оборона: ${b.getDefensePower(1)}</span>
                        </div>
                        <div class="hp-bar-wrap"><div class="hp-bar-inner enemy-hp" style="width:${hpPct}%;"></div></div>
                        <div class="card-actions">
                            <button class="btn-stalker btn-sm" onclick="window.amtGame.focusOnMap(${b.lat}, ${b.lng})">📍 На карте</button>
                            <button class="btn-stalker btn-rust btn-sm" onclick="window.amtGame.initiateAttackOnBase('${b.id}')">⚔️ Атаковать</button>
                        </div>
                    </div>
                `;
            });

            container.innerHTML = html;
        } else if (this.activeTab === 'units') {
            let html = `<div style="font-size:11px;color:#c9a227;text-transform:uppercase;">🪖 Оперативные отряды и караваны</div>`;
            this.units.forEach(u => {
                const isSelected = u.id === this.selectedUnitId;
                const hpPct = Math.round((u.hp / u.maxHp) * 100);
                html += `
                    <div class="card-stalker ${isSelected ? 'selected' : ''}">
                        <div class="card-header">
                            <span class="card-title">${u.type === 'caravan' ? '🚚' : '🪖'} ${u.name}</span>
                            <span class="card-badge">${u.isMoving() ? 'В ПУТИ' : 'НА ПОЗИЦИИ'}</span>
                        </div>
                        <div class="card-meta">Мощь: ⚔️ ${u.getCombatPower(this.commander.upgrades.squadPower, u.currentTerrain)} | Местность: ${u.currentTerrain}</div>
                        <div class="hp-bar-wrap"><div class="hp-bar-inner" style="width:${hpPct}%;"></div></div>
                        <div class="card-actions">
                            ${u.type === 'squad' ? `<button class="btn-stalker btn-sm" onclick="window.amtGame.selectUnit('${u.id}')">${isSelected ? '✅ Выбран' : 'Выбрать'}</button>` : ''}
                            <button class="btn-stalker btn-sm" onclick="window.amtGame.focusOnMap(${u.lat}, ${u.lng})">📍 Найти</button>
                            ${u.hp < u.maxHp ? `<button class="btn-stalker btn-sm" onclick="window.amtGame.healUnit('${u.id}')">💉 Лечить (25💉)</button>` : ''}
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        } else if (this.activeTab === 'pois') {
            let html = `<div style="font-size:11px;color:#c9a227;text-transform:uppercase;">🏚️ Руины и ресурсные объекты</div>`;
            this.pois.forEach(p => {
                const status = p.kind === 'ruin'
                    ? (p.explored ? 'Зачищено' : 'Не разведано')
                    : (p.captured ? 'Под контролем' : 'Свободно');
                html += `
                    <div class="card-stalker">
                        <div class="card-header">
                            <span class="card-title">${p.icon} ${p.name}</span>
                            <span class="card-badge">${status}</span>
                        </div>
                        <div class="card-actions">
                            <button class="btn-stalker btn-sm" onclick="window.amtGame.focusOnMap(${p.lat}, ${p.lng})">📍 Обзор</button>
                            <button class="btn-stalker btn-sm" onclick="window.amtGame.sendSelectedUnitTo(${p.lat}, ${p.lng}, '${p.id}')">🥾 Отправить отряд</button>
                        </div>
                    </div>
                `;
            });
            container.innerHTML = html;
        }
    }

    healUnit(unitId) {
        const unit = this.units.find(u => u.id === unitId);
        if (!unit || unit.hp >= unit.maxHp) return;
        if (!this.resources.spend({ meds: 25 })) {
            this.addLog('Недостаточно медикаментов (нужно 25💉) для полевой реанимации отряда.', 'warn');
            return;
        }
        unit.hp = unit.maxHp;
        this.audio.pdaBeep();
        this.addLog(`Отряд «${unit.name}» использовал аптечки и полностью восстановил боеспособность.`, 'info');
        this.renderSidePanel();
    }

    focusOnMap(lat, lng) {
        if (this.mapManager.map) {
            this.mapManager.map.setView([lat, lng], Math.max(this.mapManager.map.getZoom(), 6));
        }
    }

    addLog(text, type = 'info') {
        const box = document.getElementById('log-messages');
        if (!box) return;
        const h = String(Math.floor(this.dayTimeMinutes / 60)).padStart(2, '0');
        const m = String(Math.floor(this.dayTimeMinutes % 60)).padStart(2, '0');
        const entry = document.createElement('div');
        entry.className = 'log-entry';
        entry.innerHTML = `<span class="log-time">[Д${this.dayCount} ${h}:${m}]</span><span class="log-${type}">${text}</span>`;
        box.prepend(entry);
        while (box.children.length > 40) {
            box.removeChild(box.lastChild);
        }
    }

    applyVisualSettings() {
        document.body.classList.toggle('stalker-map-filter', !!this.settings.stalkerFilter);
        if (this.mapManager && this.mapManager.map) {
            this.mapManager.setTileSource(this.settings.mapTile || 'dark');
        }
    }
}

// ============================================================================
// ИНИЦИАЛИЗАЦИЯ ЛАУНЧЕРА, МЕНЮ И ИГРЫ ПРИ ЗАГРУЗКЕ СТРАНИЦЫ
// ============================================================================
window.addEventListener('DOMContentLoaded', () => {
    const game = new Game();
    window.amtGame = game;

    const launcherScreen = document.getElementById('launcher-screen');
    const mainMenuScreen = document.getElementById('main-menu-screen');
    const gameScreen = document.getElementById('game-screen');
    const fileInput = document.getElementById('license-file-input');
    const dropzone = document.getElementById('license-dropzone');
    const consoleBox = document.getElementById('launcher-console');
    const progressBar = document.getElementById('launcher-progress-bar');

    function logToLauncher(msg, color = '#d4b257') {
        if (!consoleBox) return;
        const p = document.createElement('p');
        p.style.color = color;
        p.textContent = `> ${msg}`;
        consoleBox.appendChild(p);
        consoleBox.scrollTop = consoleBox.scrollHeight;
    }

    function unlockLauncher(sourceLabel) {
        game.audio.pdaBeep();
        logToLauncher(`Файл ключа получен (${sourceLabel}). Проверка крипто-подписи OMEGA-7...`, '#ffb700');
        if (progressBar) progressBar.style.width = '55%';

        setTimeout(() => {
            if (progressBar) progressBar.style.width = '100%';
            logToLauncher('ДОСТУП РАЗРЕШЁН. Загрузка командного интерфейса AMT-OS...', '#4ade80');
            try {
                localStorage.setItem(SaveSystem.LICENSE_KEY, 'true');
            } catch (e) {}
        }, 350);

        setTimeout(() => {
            launcherScreen.classList.add('hidden');
            mainMenuScreen.classList.remove('hidden');
        }, 850);
    }

    function verifyLicenseFile(file) {
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (e) => {
            const content = String(e.target.result || '');
            const validName = file.name.toLowerCase().includes('license') || file.name.toLowerCase().endsWith('.key');
            const validContent = content.includes('AMT') || content.includes('LICENSE') || content.length > 5;
            if (validName || validContent) {
                unlockLauncher(file.name);
            } else {
                game.audio.alarm();
                logToLauncher(`ОШИБКА: Файл «${file.name}» не является корректным ключом License AMT.key!`, '#ef4444');
            }
        };
        reader.readAsText(file);
    }

    // Обработчики загрузки файла License AMT.key
    if (dropzone && fileInput) {
        dropzone.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', (e) => {
            if (e.target.files && e.target.files[0]) {
                verifyLicenseFile(e.target.files[0]);
            }
        });
        dropzone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropzone.classList.add('dragover');
        });
        dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropzone.classList.remove('dragover');
            if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                verifyLicenseFile(e.dataTransfer.files[0]);
            }
        });
    }

    // Кнопка генерации и скачивания License AMT.key прямо из лаунчера
    const btnDownloadKey = document.getElementById('btn-download-key');
    if (btnDownloadKey) {
        btnDownloadKey.addEventListener('click', () => {
            const keyText = [
                '====================================================================',
                '   APOCALYPSE MAP TRAVEL (AMT-OS v4.2) — TACTICAL BUNKER LICENSE',
                '====================================================================',
                'PRODUCT_ID: AMT-STALKER-COMMAND-2035',
                'SIGNATURE: AMT-KEY-9948-RAD-ZONE-VALID-2035',
                'STATUS: ACTIVE / VERIFIED',
                '===================================================================='
            ].join('\n');
            const blob = new Blob([keyText], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'License AMT.key';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            logToLauncher('Файл «License AMT.key» сгенерирован и сохранён. Теперь выберите его в окне выше или нажмите быстрый вход.', '#38bdf8');
        });
    }

    // Кнопка быстрой авторизации встроенным ключом (для удобства в браузере/Canvas)
    const btnQuickKey = document.getElementById('btn-quick-license');
    if (btnQuickKey) {
        btnQuickKey.addEventListener('click', () => {
            unlockLauncher('License AMT.key [Встроенный крипто-ключ]');
        });
    }

    // Кнопки Главного Меню
    const btnPlay = document.getElementById('btn-menu-play');
    if (btnPlay) {
        btnPlay.addEventListener('click', () => {
            game.audio.pdaBeep();
            mainMenuScreen.classList.add('hidden');
            gameScreen.classList.remove('hidden');
            game.initState();
            game.startSimulation();
        });
    }

    const btnNewGame = document.getElementById('btn-menu-new');
    if (btnNewGame) {
        btnNewGame.addEventListener('click', () => {
            SaveSystem.clearSave();
            game.audio.pdaBeep();
            mainMenuScreen.classList.add('hidden');
            gameScreen.classList.remove('hidden');
            game.loadDefaultState();
            game.applyVisualSettings();
            game.startSimulation();
            game.addLog('Начата новая кампания! Командир, изучите карту и укрепите базы.', 'info');
        });
    }

    const btnMenuSettings = document.getElementById('btn-menu-settings');
    if (btnMenuSettings) {
        btnMenuSettings.addEventListener('click', () => {
            document.getElementById('settings-modal').classList.remove('hidden');
        });
    }

    // Кнопки внутри игрового интерфейса
    document.getElementById('btn-hud-save')?.addEventListener('click', () => game.saveNow(true));
    document.getElementById('btn-hud-settings')?.addEventListener('click', () => {
        document.getElementById('settings-modal').classList.remove('hidden');
    });
    document.getElementById('btn-hud-menu')?.addEventListener('click', () => {
        game.saveNow(false);
        gameScreen.classList.add('hidden');
        mainMenuScreen.classList.remove('hidden');
    });

    // Кнопки быстрых действий боковой панели
    document.getElementById('btn-action-build')?.addEventListener('click', () => {
        game.setMapMode(game.mapClickMode === 'build' ? 'move' : 'build');
    });
    document.getElementById('btn-action-attack')?.addEventListener('click', () => {
        const firstEnemy = game.bases.find(b => b.owner === 'enemy');
        if (firstEnemy) {
            game.initiateAttackOnBase(firstEnemy.id);
        } else {
            game.addLog('Все вражеские базы на карте уже захвачены!', 'info');
        }
    });
    document.getElementById('btn-action-tech')?.addEventListener('click', () => {
        game.openTechModal();
    });

    document.getElementById('btn-cancel-map-mode')?.addEventListener('click', () => {
        game.setMapMode('move');
    });

    // Сворачивание боковой панели
    const sidePanel = document.getElementById('side-panel');
    const toggleBtn = document.getElementById('side-panel-toggle');
    if (toggleBtn && sidePanel) {
        toggleBtn.addEventListener('click', () => {
            sidePanel.classList.toggle('collapsed');
            toggleBtn.textContent = sidePanel.classList.contains('collapsed') ? '▶' : '◀';
        });
    }

    // Переключение вкладок боковой панели
    document.querySelectorAll('.panel-tab').forEach(btn => {
        btn.addEventListener('click', () => game.switchTab(btn.dataset.tab));
    });

    // Закрытие модальных окон
    document.querySelectorAll('[data-close-modal]').forEach(btn => {
        btn.addEventListener('click', () => {
            const modalId = btn.getAttribute('data-close-modal');
            document.getElementById(modalId)?.classList.add('hidden');
        });
    });

    // Настройки
    document.getElementById('setting-map-tile')?.addEventListener('change', (e) => {
        game.settings.mapTile = e.target.value;
        game.applyVisualSettings();
    });
    document.getElementById('setting-stalker-filter')?.addEventListener('change', (e) => {
        game.settings.stalkerFilter = e.target.checked;
        game.applyVisualSettings();
    });
    document.getElementById('setting-sim-speed')?.addEventListener('change', (e) => {
        game.settings.simSpeed = Number(e.target.value) || 1;
    });
    document.getElementById('setting-difficulty')?.addEventListener('change', (e) => {
        game.settings.difficulty = e.target.value;
    });
    document.getElementById('setting-sound-mute')?.addEventListener('change', (e) => {
        game.audio.muted = e.target.checked;
    });
    document.getElementById('btn-reset-save')?.addEventListener('click', () => {
        SaveSystem.clearSave();
        game.loadDefaultState();
        if (game.mapManager.map) game.mapManager.renderAllObjects();
        game.renderHUD();
        game.renderSidePanel();
        game.addLog('Сохранение сброшено к стартовой расстановке сил.', 'warn');
        document.getElementById('settings-modal')?.classList.add('hidden');
    });
});
