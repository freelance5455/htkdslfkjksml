/* ===== SIM: pure game rules (no DOM, no three.js). Units = tiles, y up. ===== */
var SIM = (function () {
  var P = {
    DT: 1 / 60, G: -36, JUMP: 11.8, SPEED: 5.2, ACC_G: 70, ACC_A: 45,
    PW: 0.34, PH: 0.76, COYOTE: 0.09, BUFFER: 0.1, AIR_JUMPS: 1, VIEW_W: 16, H: 9, GOAL_R: 0.42
  };

  function makeState(L, cp) {
    cp = cp || 0;
    var ents = L.ents.map(function (e) {
      var kind = e.kind || 'block';
      var solDef = e.sol === undefined ? (kind === 'block' ? 1 : 0) : e.sol;
      var hazDef = e.haz === undefined ? ((kind === 'spike' || kind === 'saw') ? 1 : 0) : e.haz;
      var hid = e.hidden ? 1 : 0;
      return {
        id: e.id, kind: kind, x: e.x, y: e.y, w: e.w || 0, h: e.h || 0, dir: e.dir || 'up',
        fake: e.fake || 0, msg: e.msg || '', solDef: solDef, hazDef: hazDef, belt: e.belt || 0, pad: e.pad || 0,
        glow: e.glow || '', pat: e.pat || null, cyc: e.cyc || null, bomb: e.bomb || null, crumble: e.crumble || 0,
        idx: e.idx || 0, mv: null, bs: 0, bt: 0, cT: 0, hit: (kind === 'flag' && e.idx <= cp) ? 1 : 0, warn: 0,
        vis: hid ? 0 : (e.vis === undefined ? 1 : e.vis), sol: hid ? 0 : solDef, haz: hid ? 0 : hazDef
      };
    });
    var sp = cp > 0 && L.cps && L.cps[cp] ? L.cps[cp] : L.spawn;
    return {
      L: L, t: 0, px: sp[0], py: sp[1], vx: 0, vy: 0, ground: false, gs: 1, beltV: 0, cp: cp,
      coyote: 0, buf: 0, air: 1, face: 1, ents: ents, rev: false, status: 'play', msg: '', fx: '',
      stand: '', jumpHeld: false, fired: L.trig.map(function () { return -1; }), say: ''
    };
  }

  function byId(st, id) {
    for (var i = 0; i < st.ents.length; i++) if (st.ents[i].id === id) return st.ents[i];
    return null;
  }
  function solidActive(e) { return e.sol && e.kind === 'block'; }
  function overlap(ax, ay, aw, ah, bx, by, bw, bh) {
    return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
  }
  function pbox(st) { return [st.px - P.PW / 2, st.py, P.PW, P.PH]; }
  function die(st, msg, e) { if (st.status !== 'play') return; st.status = 'dead'; st.msg = msg || ''; st.killer = e ? e.id : ''; }

  function moveAxis(st, dx, dy) {
    var i, e, b;
    if (dx) {
      st.px += dx; b = pbox(st);
      for (i = 0; i < st.ents.length; i++) {
        e = st.ents[i]; if (!solidActive(e)) continue;
        if (overlap(b[0], b[1], b[2], b[3], e.x, e.y, e.w, e.h)) {
          if (dx > 0) st.px = e.x - P.PW / 2 - 1e-4; else st.px = e.x + e.w + P.PW / 2 + 1e-4;
          st.vx = 0; b = pbox(st);
        }
      }
    }
    if (dy) {
      st.py += dy; b = pbox(st); st.ground = false;
      for (i = 0; i < st.ents.length; i++) {
        e = st.ents[i]; if (!solidActive(e)) continue;
        if (overlap(b[0], b[1], b[2], b[3], e.x, e.y, e.w, e.h)) {
          if (dy < 0) st.py = e.y + e.h; else st.py = e.y - P.PH - 1e-4;
          if (dy * st.gs < 0) st.ground = true; // moving with gravity = landed
          st.vy = 0; b = pbox(st);
        }
      }
    }
  }

  function standOn(st) {
    st.stand = ''; st.beltV = 0;
    if (!st.ground) return null;
    var b = pbox(st);
    for (var i = 0; i < st.ents.length; i++) {
      var e = st.ents[i]; if (!solidActive(e)) continue;
      var edge = st.gs > 0 ? e.y + e.h - st.py : st.py + P.PH - e.y;
      if (Math.abs(edge) < 0.02 && b[0] < e.x + e.w && b[0] + b[2] > e.x) {
        st.stand = e.id; st.beltV = e.belt;
        if (e.crumble && !e.cT) e.cT = st.t + 1e-6;
        return e;
      }
    }
    return null;
  }

  function idxOf(st, id) {
    for (var i = 0; i < st.L.trig.length; i++) if (st.L.trig[i].id === id) return i;
    return -1;
  }
  function condMet(st, c) {
    if (c.req && st.fired[idxOf(st, c.req)] < 0) return false;
    if (c.x) { if (!(st.px >= c.x[0] && st.px <= c.x[1])) return false; if (c.y && !(st.py >= c.y[0] && st.py <= c.y[1])) return false; return true; }
    if (c.rect) { var b = pbox(st); return overlap(b[0], b[1], b[2], b[3], c.rect[0], c.rect[1], c.rect[2], c.rect[3]); }
    if (c.stand) return st.stand === c.stand;
    if (c.time !== undefined) return st.t >= c.time;
    return !!c.req; // armed only by another trap firing (a chain)
  }

  function runAction(st, a) {
    var e;
    switch (a[0]) {
      case 'on': e = byId(st, a[1]); if (e) { e.vis = 1; e.sol = e.solDef; e.haz = e.hazDef; } break;
      case 'off': e = byId(st, a[1]); if (e) { e.vis = 0; e.sol = 0; e.haz = 0; } break;
      case 'show': e = byId(st, a[1]); if (e) e.vis = 1; break;
      case 'mv': e = byId(st, a[1]); if (e) e.mv = { x: a[2], y: a[3], s: a[4] || 99 }; break;
      case 'rev': st.rev = !!a[1]; break;
      case 'grav': st.gs = a[1] >= 0 ? 1 : -1; st.fx = 'flip'; break;
      case 'say': st.say = a[1]; break;
    }
  }

  function updateEnts(st, dt) {
    for (var i = 0; i < st.ents.length; i++) {
      var e = st.ents[i];
      if (e.cyc) { // laser: on/off cycle
        var per = e.cyc[0] + e.cyc[1], p = ((st.t + e.cyc[2]) % per + per) % per;
        e.haz = p < e.cyc[0] ? 1 : 0; e.warn = (!e.haz && per - p < 0.45) ? 1 : 0;
      }
      if (e.bomb && e.bs < 3) { // bomb: proximity fuse, then a short blast
        var d0 = Math.hypot(st.px - e.x, st.py + P.PH / 2 - e.y);
        if (e.bs === 0 && d0 < e.bomb[0]) { e.bs = 1; e.bt = st.t; }
        else if (e.bs === 1 && st.t - e.bt >= e.bomb[1]) { e.bs = 2; e.bt = st.t; }
        else if (e.bs === 2 && st.t - e.bt >= (e.bomb[3] || 0.25)) { e.bs = 3; e.vis = 0; }
      }
      if (e.crumble && e.cT && !e.fallen && st.t - e.cT >= e.crumble) { e.fallen = 1; e.sol = 0; e.mv = { x: e.x, y: -6, s: 10 }; }
      if (!e.mv && e.pat) { // patrol: shuttle between start and pat target
        if (!e.home) e.home = { x: e.x, y: e.y };
        var far = (Math.abs(e.x - e.pat[0]) < 1e-6 && Math.abs(e.y - e.pat[1]) < 1e-6);
        e.mv = far ? { x: e.home.x, y: e.home.y, s: e.pat[2] } : { x: e.pat[0], y: e.pat[1], s: e.pat[2] };
      }
      if (!e.mv) continue;
      var dx = e.mv.x - e.x, dy = e.mv.y - e.y, d = Math.hypot(dx, dy), s = e.mv.s * dt;
      if (d <= s) { e.x = e.mv.x; e.y = e.mv.y; e.mv = null; }
      else { e.x += dx / d * s; e.y += dy / d * s; }
    }
  }

  function step(st, inp) {
    if (st.status !== 'play') return st;
    var dt = P.DT, l = inp.l, r = inp.r, i, e, W = st.L.w || P.VIEW_W;
    if (st.rev) { var t = l; l = r; r = t; }
    var dir = (r ? 1 : 0) - (l ? 1 : 0);
    if (dir) st.face = dir;
    var acc = st.ground ? P.ACC_G : P.ACC_A, target = dir * P.SPEED + (st.ground ? st.beltV : 0);
    if (st.vx < target) st.vx = Math.min(target, st.vx + acc * dt);
    else if (st.vx > target) st.vx = Math.max(target, st.vx - acc * dt);

    if (inp.j && !st.jumpHeld) st.buf = P.BUFFER;
    st.jumpHeld = !!inp.j;
    st.buf = Math.max(0, st.buf - dt);
    st.coyote = st.ground ? P.COYOTE : Math.max(0, st.coyote - dt);
    if (st.ground) st.air = P.AIR_JUMPS;
    if (st.buf > 0 && st.coyote > 0) { st.vy = P.JUMP * st.gs; st.buf = 0; st.coyote = 0; st.ground = false; }
    else if (st.buf > 0 && st.air > 0 && !st.ground) { st.vy = P.JUMP * st.gs; st.buf = 0; st.air--; st.fx = 'air'; }
    st.vy += P.G * st.gs * dt;

    moveAxis(st, st.vx * dt, 0);
    moveAxis(st, 0, st.vy * dt);
    var lim = P.PW / 2;
    if (st.px < lim) { st.px = lim; st.vx = 0; }
    if (st.px > W - lim) { st.px = W - lim; st.vx = 0; }
    var under = standOn(st);
    if (under && under.pad) { st.vy = under.pad * st.gs; st.ground = false; st.coyote = 0; st.fx = 'bounce'; }

    st.t += dt;
    updateEnts(st, dt);

    for (i = 0; i < st.L.trig.length; i++) {
      if (st.fired[i] < 0 && condMet(st, st.L.trig[i].if)) st.fired[i] = st.t;
    }
    for (i = 0; i < st.L.trig.length; i++) {
      var tg = st.L.trig[i];
      if (st.fired[i] >= 0 && !st['d' + i] && st.t - st.fired[i] >= (tg.delay || 0) - 1e-9) {
        st['d' + i] = 1;
        for (var k = 0; k < tg.do.length; k++) runAction(st, tg.do[k]);
      }
    }

    var b = pbox(st), pcx = st.px, pcy = st.py + P.PH / 2;
    for (i = 0; i < st.ents.length; i++) {
      e = st.ents[i];
      if (e.kind === 'block') { if (e.sol && overlap(b[0], b[1], b[2], b[3], e.x, e.y, e.w, e.h)) die(st, e.msg || 'Squished', e); }
      else if (e.kind === 'spike') { if (e.haz && overlap(b[0], b[1], b[2], b[3], e.x + 0.08, e.y + 0.05, e.w - 0.16, e.h - 0.1)) die(st, e.msg || 'Ouch', e); }
      else if (e.kind === 'laser') { if (e.haz && overlap(b[0], b[1], b[2], b[3], e.x, e.y, e.w, e.h)) die(st, e.msg || 'Zapped', e); }
      else if (e.kind === 'saw') {
        if (e.haz) {
          var sx = Math.max(b[0], Math.min(e.x, b[0] + b[2])), sy = Math.max(b[1], Math.min(e.y, b[1] + b[3]));
          if (Math.hypot(sx - e.x, sy - e.y) < e.w / 2 - 0.06) die(st, e.msg || 'Sliced', e);
        }
      } else if (e.kind === 'bomb') { if (e.bs === 2 && Math.hypot(pcx - e.x, pcy - e.y) < e.bomb[2]) die(st, e.msg || 'Boom!', e); }
      else if (e.kind === 'flag') { if (!e.hit && Math.abs(st.px - e.x) < 0.6 && Math.abs(st.py - e.y) < 1.2) { e.hit = 1; if (e.idx > st.cp) st.cp = e.idx; st.fx = 'flag'; } }
      else if (e.kind === 'goal' && e.vis) {
        var cx = Math.max(b[0], Math.min(e.x, b[0] + b[2])), cy = Math.max(b[1], Math.min(e.y, b[1] + b[3]));
        if (Math.hypot(cx - e.x, cy - e.y) < P.GOAL_R) { if (e.fake) die(st, e.msg || 'Decaf!', e); else st.status = 'won'; }
      }
    }
    if (st.py < -2 || st.py > (st.L.mh || P.H) + 3) die(st, st.L.fall || 'Gravity wins');
    return st;
  }

  return { P: P, makeState: makeState, step: step, byId: byId };
})();
if (typeof module !== 'undefined') module.exports = SIM;

/* ===== LEVELS: big scrolling maps drawn as a character grid (y up in the sim, row 0 = top of the map).
   The camera follows the bean left/right AND up/down. Every level has its own look and its own trick.
   Grid legend:
     #  wall                .  air                S  start        1-9  checkpoint flags (in route order)
     M  coffee mug (goal)    m  fake mug ("Decaf!")
     ^  floor staple         v  ceiling staple     (  staple on a wall's left face   )  staple on a wall's right face
     h  hidden staple, pops up as you walk right to it     H  same, walking left
     D  ceiling staple that FALLS just before you, walking right     E  same, walking left
     c  crumbling tile       g  ghost tile (invisible until stood on)     x  decoy tile (looks solid, is not)
     y  trapdoor (vanishes as you step near)     p  spring pad     r / R  conveyor left / right
     n / N  ball rolls in along the floor from the right / left when you step here
     b  bomb       l / L  laser column (slow / fast pulse)     w  saw   a  saw patrolling to the next 'a' in its row   e  same, vertical
     ~  gravity flips upside down here      =  gravity back to normal      ?  controls reversed      !  controls normal
   ======================================================================================================== */
var LEVELS = (function () {
  /* ---------- tiny grid drawing kit ---------- */
  function G(w, h) {
    var a = []; for (var r = 0; r < h; r++) { a.push([]); for (var c = 0; c < w; c++) a[r].push('#'); }
    return {
      w: w, h: h, a: a,
      fill: function (c0, r0, c1, r1, ch) { for (var r = r0; r <= r1; r++) for (var c = c0; c <= c1; c++) a[r][c] = ch; return this; },
      carve: function (c0, r0, c1, r1) { return this.fill(c0, r0, c1, r1, '.'); },
      put: function (c, r, ch) { a[r][c] = ch; return this; },
      rows: function () { return a.map(function (x) { return x.join(''); }); },
      view: function (off) {                                   // same drawing calls, but every row is shifted down by 'off'
        var me = this, v = {
          fill: function (c0, r0, c1, r1, ch) { me.fill(c0, r0 + off, c1, r1 + off, ch); return v; },
          carve: function (c0, r0, c1, r1) { me.carve(c0, r0 + off, c1, r1 + off); return v; },
          put: function (c, r, ch) { me.put(c, r + off, ch); return v; }
        }; return v;
      }
    };
  }

  var SOLID = '#cgypr' + 'R';
  function mapLevel(name, theme, fall, g, zones, links) {
    var rows = g.rows(), mh = rows.length, mw = rows[0].length, ents = [], trig = [], cps = [null], spawn = null, flags = {};
    function Y(r) { return mh - 1 - r; }
    function ch(c, r) { return (r < 0 || r >= mh || c < 0 || c >= mw) ? '#' : rows[r][c]; }
    function solid(c, r) { return SOLID.indexOf(ch(c, r)) >= 0; }
    function lane(c, r) { var u = r, d = r; while (!solid(c, u - 1)) u--; while (!solid(c, d + 1)) d++; return [Y(d), Y(u) + 1]; } // [floor y, ceiling y]
    function id(c, r) { return 't' + r + '_' + c; }
    function add(e) { ents.push(e); return e; }

    // walls: merge horizontal runs, then stack identical runs vertically
    var open = {}, r, c, k;
    for (r = 0; r <= mh; r++) {
      var runs = {};
      if (r < mh) for (c = 0; c < mw; c++) if (rows[r][c] === '#') { var c0 = c; while (c + 1 < mw && rows[r][c + 1] === '#') c++; runs[c0 + '-' + c] = [c0, c]; }
      for (k in open) if (!runs[k]) { var o = open[k]; add({ id: 'w' + o.r0 + '_' + o.c0, kind: 'block', tile: 1, x: o.c0, y: Y(o.r1), w: o.c1 - o.c0 + 1, h: o.r1 - o.r0 + 1 }); delete open[k]; }
      for (k in runs) if (open[k]) open[k].r1 = r; else open[k] = { c0: runs[k][0], c1: runs[k][1], r0: r, r1: r };
    }

    var pend = {}, pendE = {};
    for (r = 0; r < mh; r++) for (c = 0; c < mw; c++) {
      var t = rows[r][c], x = c, y = Y(r), i = id(c, r), ln, ph = (c * 0.37 + r * 0.19) % 2.2;
      switch (t) {
        case 'S': spawn = [c + 0.5, y]; break;
        case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8': case '9':
          cps[+t] = [c + 0.5, y]; add({ id: 'flag' + t, kind: 'flag', x: c + 0.5, y: y, idx: +t }); break;
        case 'M': add({ id: 'goal', kind: 'goal', x: c + 0.5, y: y + 0.45 }); break;
        case 'm': add({ id: i, kind: 'goal', x: c + 0.5, y: y + 0.45, fake: 1, msg: 'Decaf!' }); break;
        case '^': add({ id: i, kind: 'spike', x: x, y: y, w: 1, h: 0.5, dir: 'up' }); break;
        case 'v': add({ id: i, kind: 'spike', x: x, y: y + 0.5, w: 1, h: 0.5, dir: 'down' }); break;
        case '(': add({ id: i, kind: 'spike', x: x, y: y, w: 0.5, h: 1, dir: 'right' }); break;
        case ')': add({ id: i, kind: 'spike', x: x + 0.5, y: y, w: 0.5, h: 1, dir: 'left' }); break;
        case 'h': case 'H':
          ln = lane(c, r); add({ id: i, kind: 'spike', x: x, y: y, w: 1, h: 0.5, dir: 'up', hidden: 1, msg: 'Surprise!' });
          trig.push({ cell: c + ',' + r, if: { x: t === 'h' ? [c - 1.25, c + 0.4] : [c + 0.6, c + 2.25], y: [ln[0], ln[1]] }, do: [['on', i]] }); break;
        case 'D': case 'E':
          ln = lane(c, r); add({ id: i, kind: 'spike', x: x, y: ln[1] - 0.6, w: 1, h: 0.6, dir: 'down', msg: 'Look up!' });
          trig.push({ cell: c + ',' + r, if: { x: t === 'D' ? [c - 0.45, c + 0.3] : [c + 0.75, c + 1.45], y: [ln[0], ln[1]] }, do: [['mv', i, x, ln[0], 30]] }); break;
        case 'j': add({ id: i, kind: 'spike', x: x, y: y, w: 1, h: 0.5, dir: 'up', hidden: 1, msg: 'Surprise!' });
          trig.push({ cell: c + ',' + r, if: {}, do: [['on', i]] }); break;           // only a chain arms it
        case 'k': ln = lane(c, r); add({ id: i, kind: 'spike', x: x, y: ln[1] - 0.6, w: 1, h: 0.6, dir: 'down', msg: 'Look up!' });        // only a chain drops it
          trig.push({ cell: c + ',' + r, if: {}, drop: [i, x, ln[0]], do: [['mv', i, x, ln[0], 30]] }); break;
        case 'c': add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1, crumble: 0.35 }); break;
        case 'g': add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1, vis: 0, ghost: 1 }); trig.push({ cell: c + ',' + r, if: { stand: i }, do: [['show', i]] }); break;
        case 'x': add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1, sol: 0 }); break;
        case 'y': ln = lane(c, r - 1);
          add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1 }); trig.push({ if: { x: [c - 0.9, c + 1.9], y: [y + 1, y + 3.5] }, do: [['off', i]] }); break;
        case 'p': add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1, pad: 16.5, glow: 'pad' }); break;
        case 'r': add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1, belt: -3, glow: 'belt' }); break;
        case 'R': add({ id: i, kind: 'block', tile: 1, x: x, y: y, w: 1, h: 1, belt: 3, glow: 'belt' }); break;
        case 'b': add({ id: i, kind: 'bomb', x: c + 0.5, y: y + 0.3, w: 0.5, h: 0.5, bomb: [3.4, 2.0, 5.6, 0.5] }); break;
        case 'l': case 'L':
          ln = lane(c, r); add({ id: i, kind: 'laser', x: c + 0.5 - 0.07, y: ln[0], w: 0.14, h: ln[1] - ln[0], cyc: t === 'l' ? [0.8, 1.4, ph] : [0.6, 0.9, ph], dir: 'v' }); break;
        case 'z': { var x0 = c, x1 = c + 1; while (!solid(x0 - 1, r)) x0--; while (!solid(x1, r)) x1++;
          add({ id: i, kind: 'laser', x: x0, y: y + 0.5 - 0.07, w: x1 - x0, h: 0.14, cyc: [0.8, 1.4, ph], dir: 'h' }); break; }               // horizontal laser across a shaft
        case 'n': case 'N': { ln = lane(c, r); var bx0 = c, bx1 = c + 1; while (!solid(bx0 - 1, r)) bx0--; while (!solid(bx1, r)) bx1++;
          var sx = t === 'n' ? Math.min(bx1 - 0.5, c + 9.5) : Math.max(bx0 + 0.5, c - 9.5), tx = t === 'n' ? bx0 - 1.5 : bx1 + 1.5;
          add({ id: i, kind: 'saw', x: sx, y: y + 0.45, w: 0.9, h: 0.9, hidden: 1, msg: 'Steamrolled!' });                       // a ball rolls in along the floor when you step here
          trig.push({ cell: c + ',' + r, if: { x: [c - 0.3, c + 0.3], y: [ln[0], ln[1]] }, do: [['on', i], ['mv', i, tx, y + 0.45, 10]] }); break; }
        case 'W': add({ id: i, kind: 'saw', x: c + 0.5, y: y + 0.55, w: 0.9, h: 0.9 }); break;                                                // saw hanging from the ceiling
        case 'q': add({ id: i, kind: 'spike', x: x, y: y, w: 1, h: 0.5, dir: 'up', hidden: 1, msg: 'Surprise!' });                           // pops when you come near (ledges)
          trig.push({ cell: c + ',' + r, if: { rect: [c - 0.6, y + 0.4, 2.2, 3.0] }, do: [['on', i]] }); break;
        case 'w': add({ id: i, kind: 'saw', x: c + 0.5, y: y + 0.45, w: 0.9, h: 0.9 }); break;
        case 'a': if (pend[r] === undefined) pend[r] = c; else { add({ id: i, kind: 'saw', x: pend[r] + 0.5, y: y + 0.45, w: 0.9, h: 0.9, pat: [c + 0.5, y + 0.45, 3.0] }); delete pend[r]; } break;
        case 'e': if (pendE[c] === undefined) pendE[c] = r; else { add({ id: i, kind: 'saw', x: c + 0.5, y: Y(pendE[c]) + 0.45, w: 0.9, h: 0.9, pat: [c + 0.5, y + 0.45, 3.0] }); delete pendE[c]; } break;
        case '~': trig.push({ if: { rect: [c, y, 1, 1] }, do: [['grav', -1]] }); break;
        case '=': trig.push({ if: { rect: [c, y, 1, 1] }, do: [['grav', 1]] }); break;
        case '?': trig.push({ if: { rect: [c, y, 1, 1] }, do: [['rev', true]] }); break;
        case '!': trig.push({ if: { rect: [c, y, 1, 1] }, do: [['rev', false]] }); break;
      }
    }
    cps[0] = spawn;
    (links || []).forEach(function (l) {                         // [fromCol, fromRow, toCol, toRow, delay]: the first trap, once it fires, arms the second
      var a = null, b = null; trig.forEach(function (tg) { if (tg.cell === l[0] + ',' + l[1]) a = tg; if (tg.cell === l[2] + ',' + l[3]) b = tg; });
      if (!a || !b) throw new Error('bad link ' + l.join(','));
      a.id = a.id || 'k' + l[1] + '_' + l[0]; b.if = { req: a.id }; b.delay = l[4];
    });
    return { name: name, theme: theme, cam: 'scroll', fall: fall, map: 1, mw: mw, mh: mh, w: mw, spawn: spawn, cps: cps, grid: rows, ents: ents, trig: trig,
      secs: zones.map(function (z) { return { ox: 0, w: mw, name: z }; }) };
  }

  /* ============ LEVEL 1 : FILING CABINET - four stacked lanes, zig-zag up the cabinet (40 x 22) ============ */
  var g1 = G(40, 32), s1 = g1.view(10);
  s1.carve(1, 16, 38, 19).carve(1, 11, 38, 14).carve(1, 6, 38, 9).carve(1, 1, 38, 4);            // lanes D (bottom), C, B, A (top)
  s1.carve(36, 15, 38, 15).carve(1, 10, 3, 10).carve(36, 5, 38, 5);                                 // holes in the shelves between lanes
  s1.put(2, 19, 'S');
  // ---- lane D (go right)
  s1.put(6, 19, 'h');
  s1.carve(9, 20, 10, 21).put(9, 21, '^').put(10, 21, '^');
  s1.put(13, 16, 'D').put(15, 19, 'j');
  s1.carve(16, 20, 18, 21).put(16, 20, 'c').put(17, 20, 'c').put(18, 20, 'c').fill(16, 21, 18, 21, '^');
  s1.put(20, 19, '1');
  s1.put(25, 19, 'b');
  s1.put(27, 20, 'x').carve(27, 21, 27, 21).put(27, 21, '^');
  s1.put(30, 19, 'w');
  s1.put(33, 16, 'D');
  s1.fill(36, 18, 38, 19, '#');                                                                     // climbing step under the hole
  // ---- lane C (go left)
  s1.put(33, 14, 'H').put(31, 14, '2');
  s1.put(26, 14, 'a').put(29, 14, 'a');
  s1.carve(22, 15, 23, 15);
  s1.put(19, 11, 'E');
  s1.put(16, 12, 'l').put(13, 12, 'l');
  s1.put(11, 15, 'x').put(10, 15, 'x').put(9, 15, 'x');
  s1.put(7, 14, 'w').put(4, 14, '3').put(16, 14, 'N');
  s1.put(3, 14, '#').fill(2, 13, 2, 14, '#').fill(1, 12, 1, 14, '#');                               // stairs up to the hole
  // ---- lane B (go right)
  s1.put(5, 9, 'h').put(7, 9, 'n');
  s1.put(9, 7, 'l').put(12, 7, 'l').put(15, 7, 'l');
  s1.put(18, 9, '4');
  s1.put(23, 9, 'b');
  s1.put(24, 10, 'c').put(25, 10, 'c').put(26, 10, 'c').put(27, 10, 'c').put(28, 10, 'c');
  s1.put(30, 10, 'r').put(31, 10, 'r').put(32, 10, 'r').put(33, 10, 'r');
  s1.put(35, 6, 'D');
  s1.fill(36, 8, 38, 9, '#');
  // ---- lane A (go left)
  s1.put(33, 4, 'H').put(31, 4, '5');
  s1.fill(18, 5, 30, 5, '.').put(28, 5, 'g').put(25, 5, 'g').put(22, 5, 'g').put(19, 5, 'g').put(28, 1, 'k');
  s1.put(15, 1, 'E');
  s1.put(13, 4, 'H').put(11, 4, 'N');
  s1.put(10, 4, 'w').put(8, 4, '6');
  s1.put(6, 4, 'm').put(5, 1, 'L');
  s1.carve(1, 0, 3, 0).put(3, 4, '#').fill(2, 3, 2, 4, '#').fill(1, 2, 1, 4, '#');                   // stairs up to the attic hatch (the mug moved higher)
  // ---- lane E, the attic (go right)  [absolute rows: floor 10, air 6-9]
  g1.carve(1, 6, 38, 9).carve(1, 1, 38, 4);
  g1.put(6, 9, '7').put(9, 6, 'L').put(11, 9, 'h').put(14, 9, 'n').put(17, 6, 'v').put(19, 9, '^');
  g1.put(25, 9, 'b').put(30, 9, 'w').put(34, 6, 'D');
  g1.carve(36, 5, 38, 5).fill(36, 8, 38, 9, '#');
  // ---- lane F, the roof beams (go left)  [absolute rows: floor 5, air 1-4]
  g1.put(33, 4, 'H').put(31, 4, '8');
  g1.fill(19, 5, 28, 5, '.').put(27, 5, 'g').put(24, 5, 'g').put(21, 5, 'g').put(27, 1, 'k');
  g1.put(17, 1, 'E').put(14, 4, 'N').put(11, 4, 'b');
  g1.put(5, 4, 'm').put(3, 4, 'H').put(1, 4, 'M');
  var L1 = mapLevel('Filing Cabinet', 'office', 'Down the pit!', g1, ['Bottom drawer', 'Second drawer', 'Hallway of lasers', 'Third drawer', 'Ghost shelf', 'Top drawer', 'Attic hatch', 'The attic', 'Roof beams'],
    [[13, 26, 15, 29, 0.5], [28, 15, 28, 11, 0.9], [27, 5, 27, 1, 0.6]]);

  /* ============ LEVEL 2 : SPIRAL VAULT - an outer ring and an inner ring wound around a hidden mug (40 x 26) ============ */
  var g2 = G(40, 26);
  g2.carve(1, 21, 38, 24).carve(35, 1, 38, 24).carve(1, 1, 38, 4).carve(1, 1, 4, 19).carve(5, 16, 5, 19);              // outer ring (row 20 plugs the left side)
  g2.carve(6, 6, 33, 19).fill(10, 10, 29, 15, '#').carve(11, 11, 28, 14).carve(10, 11, 10, 14).fill(6, 15, 9, 15, '#'); // inner ring, centre chamber
  g2.put(2, 24, 'S').put(15, 24, 'n');
  // ---- outer bottom lane (go right)
  g2.put(7, 24, 'h').put(10, 24, 'w').put(12, 24, '1');
  g2.carve(14, 25, 15, 25);
  g2.put(18, 21, 'D').put(20, 24, 'j');
  g2.put(23, 25, 'x').put(24, 25, 'x').put(26, 24, '2').put(31, 24, 'b');
  g2.put(30, 25, 'r').put(31, 25, 'r').put(32, 25, 'r').put(33, 25, 'r');
  // ---- outer right corridor: a staircase of ledges (go up)
  g2.fill(35, 22, 36, 22, '#').fill(37, 19, 38, 19, 'c').put(37, 13, 'y').put(38, 13, '#').fill(35, 16, 36, 16, '#').put(35, 15, '3');
  g2.fill(35, 10, 36, 10, '#').put(35, 9, 'q').fill(36, 7, 38, 7, '#').put(38, 1, 'k');
  g2.put(33, 4, '4');
  // ---- outer top lane (go left, upside down)
  g2.put(30, 4, '~').put(27, 1, 'W').put(25, 1, 'v').put(21, 0, 'x').put(17, 1, 'W').put(14, 1, 'v').put(8, 1, '=');
  // ---- outer left corridor (fall)
  g2.put(1, 8, '(').put(1, 9, '(').put(4, 10, ')').put(4, 11, ')').put(1, 13, '(').put(1, 14, '(').put(4, 15, ')').put(4, 16, ')');
  g2.put(2, 12, 'z').put(2, 7, 'z').put(2, 19, '5');
  // ---- inner bottom lane (go right)
  g2.put(8, 19, 'h').put(13, 16, 'D').put(15, 19, 'j').put(11, 19, '^').carve(16, 20, 17, 20).put(16, 20, 'c').put(17, 20, 'c').put(16, 21, '^').put(17, 21, '^').put(19, 19, '6');
  g2.put(22, 17, 'L').put(25, 17, 'L').put(28, 19, 'b').fill(30, 17, 31, 19, '.');
  // ---- inner right column (go up)
  g2.fill(32, 17, 33, 17, 'c').fill(30, 14, 31, 14, 'p').fill(32, 11, 33, 11, '#').put(32, 10, 'q').put(32, 6, 'k');
  g2.put(28, 9, '7');
  // ---- inner top lane (go left, controls reversed over the lasers)
  g2.put(26, 9, 'N').put(24, 9, 'H').put(22, 8, '?').put(19, 7, 'l').put(16, 7, 'l').put(13, 7, 'l').put(10, 8, '!').put(21, 6, 'E');
  g2.put(7, 14, '8');
  // ---- centre chamber
  g2.put(9, 14, 'w').put(11, 12, 'l').put(12, 14, '9').put(17, 14, 'h').put(15, 14, 'm').put(18, 14, 'b').put(21, 14, 'm').put(23, 14, 'h').put(25, 14, 'w').put(27, 14, 'M');
  var L2 = mapLevel('Spiral Vault', 'orbit', 'Gravity wins', g2, ['Outer floor', 'Bomb alley', 'The climb', 'Upside-down hall', 'Shaft', 'Inner floor', 'Laser ring', 'Reverse lane', 'Last drop', 'The core'],
    [[18, 21, 20, 24, 0.4], [35, 9, 38, 1, 0.2], [32, 10, 32, 6, 0.2], [13, 16, 15, 19, 0.45]]);

  /* ============ LEVEL 3 : DEEP CAVE - one long grey cave: organ pipes, a ceiling of teeth, a ledge shaft up, a long hall, a shaft down (134 x 34) ============ */
  var g3 = G(134, 34);
  function pipe(c0, c1, top) { g3.fill(c0, 34 - top, c1, 31, '#'); }                      // a column whose top surface is at height "top" (floor = 2)
  function pit(c0, c1, r0, r1) { g3.carve(c0, r0, c1, r1); for (var c = c0; c <= c1; c++) g3.put(c, r1, '^'); }
  g3.carve(1, 23, 40, 31).carve(41, 1, 45, 31).carve(46, 3, 90, 9).carve(91, 3, 95, 31).carve(96, 20, 132, 31);   // hall A, shaft up, hall B, shaft down, hall C
  g3.put(2, 31, 'S');
  // ---- hall A: organ pipes, then a low hall
  pipe(6, 7, 3); pipe(10, 11, 4); pipe(14, 15, 5); pipe(18, 19, 6); pipe(20, 27, 7);
  pit(8, 9, 32, 32); pit(12, 13, 32, 32); pit(16, 17, 32, 32);
  g3.carve(26, 27, 27, 31).put(26, 31, '^').put(27, 31, '^').put(26, 27, 'x').put(27, 27, 'x').put(26, 26, 'b').put(11, 29, 'h').put(14, 28, 'q').put(22, 23, 'v').put(25, 23, 'v').put(21, 26, '1').put(28, 23, 'D').put(24, 26, 'w');
  pit(33, 34, 32, 32); g3.put(29, 31, 'h').put(30, 31, '2').put(37, 31, 'w').put(36, 20 + 3, 'D').put(38, 31, 'b').fill(28, 32, 29, 32, '#');
  g3.put(35, 31, 'x');
  // ---- shaft up: ledges every 3 tiles, left / right
  g3.fill(41, 32, 45, 32, '#');
  g3.fill(41, 29, 42, 29, '#').fill(44, 26, 45, 26, 'c').fill(41, 23, 42, 23, '#').put(44, 20, 'y').put(45, 20, '#').fill(41, 17, 42, 17, 'g').fill(44, 14, 45, 14, '#').fill(41, 11, 42, 11, '#');
  g3.put(41, 22, 'q').put(45, 1, 'k').put(43, 12, 'e').put(43, 26, 'e').put(45, 12, ')').put(45, 13, ')').put(41, 16, '(');
  g3.put(62, 9, 'n').put(76, 3, 'D').put(104, 22, 'L').put(109, 22, 'l').put(113, 22, 'L').put(122, 20, 'D');
  // ---- hall B: the long upper hall (go right)
  g3.fill(46, 10, 90, 10, '#').put(47, 9, '3').put(52, 9, 'h').put(52, 3, 'v').put(57, 3, 'v').put(63, 3, 'v');
  pit(53, 54, 10, 12); g3.put(56, 9, 'a').put(60, 9, 'a').put(66, 9, '?').put(68, 6, 'l').put(71, 6, 'l').put(74, 9, '!');
  g3.carve(78, 10, 80, 12).fill(78, 10, 80, 10, 'c').fill(78, 12, 80, 12, '^').put(83, 9, 'b').put(86, 3, 'D').put(88, 9, '4');
  // ---- shaft down: lasers, a pinch of staples
  g3.put(93, 24, 'z').put(93, 18, 'z').put(93, 12, 'z').put(91, 15, '(').put(95, 15, ')').put(91, 16, '(').put(95, 16, ')').put(91, 22, '(').put(91, 23, '(').put(95, 8, ')');
  g3.put(92, 31, '5').put(95, 31, 'w');
  // ---- hall C: organ pipes up to the mug
  g3.put(102, 30, 'h');
  pipe(100, 102, 3); pipe(105, 107, 4); pipe(110, 112, 5); pipe(115, 117, 6); pipe(118, 124, 7); pipe(125, 127, 8); pipe(130, 131, 9);
  pit(103, 104, 32, 32); pit(108, 109, 32, 32); pit(113, 114, 32, 32); pit(128, 129, 32, 32);
  g3.put(97, 31, '6').put(106, 29, 'q').put(112, 20, 'D').put(116, 27, 'w').put(119, 26, '7').put(121, 26, 'm').put(123, 20, 'l').put(124, 26, 'b').put(126, 25, 'h').put(131, 24, 'M');
  var L3 = mapLevel('Deep Cave', 'cave', 'Into the dark!', g3, ['The pipes', 'Low hall', 'Ledge shaft', 'Upper hall', 'Falling shaft', 'Cave floor', 'Pipes again', 'The mug'],
    [[41, 22, 45, 1, 0.2]]);

  return [L1, L2, L3];
})();
if (typeof module !== 'undefined') module.exports = LEVELS;

/* ===== RENDER: three.js view of the sim state. Orthographic camera, slight tilt for depth. ===== */
var RENDER = (function () {
  var THEMES = {
    field:   { sky: [0x5b4b9a, 0xffc07a], ground: 0x4a2f24, top: 0xd9a441, crate: 0xb98448, barrel: 0x8a5a33, crumble: 0xe9c27a, spike: 0x4a3a78,
               steel: 0x6b7280, wall: 0xd94f4f, brick: 0xb98448, pipe: 0x8a5a33 },
    office:  { sky: [0xffd9a8, 0xffc98a], ground: 0x2f3a66, top: 0x4a5a9a, crumble: 0xe7b84a, spike: 0xd23a4a, steel: 0x6b7280, wall: 0xd94f4f },
    orbit:   { sky: [0x0e1a26, 0x16283a], ground: 0x1f8f7a, top: 0x5ff0cf, crumble: 0xff9bd0, spike: 0xff5a7a, steel: 0x6b8f9d, wall: 0xf0a24a },
    cave:    { sky: [0x1a1426, 0x2c1f3a], ground: 0x4b4560, top: 0xb7aee6, crumble: 0xf2c27a, spike: 0xff6a4a, steel: 0x8a85a8, wall: 0xe0452e },
    sky:     { sky: [0x1c2b78, 0xf2a0c8], ground: 0x4b4690, top: 0x9bf09b, crumble: 0xffd36e, spike: 0xffffff, steel: 0x8e96c8, wall: 0xe0452e },
    mint:    { sky: [0x53936a, 0x53936a], ground: 0x9be8d0, top: 0x9be8d0, brick: 0x9be8d0, pipe: 0x9be8d0, crumble: 0xc4f3e4, spike: 0x2a1a4f,
               steel: 0x6b8f7d, wall: 0xf0a24a },
    factory: { sky: [0x0d0f16, 0x1d212d], ground: 0x3b4252, top: 0xff9f1c, brick: 0x4a5163, pipe: 0x596273, crumble: 0x6b7384, spike: 0xe6ebf5,
               steel: 0x596273, wall: 0xe0452e, lava: 0xff4d12 }
  };
  var DEPTH = 0.9, Z_FRONT = 0.55;
  var scene, camera, renderer, root, dyn, items = [], player, T, L, camX = 0, shake = 0, parts = [], layers = [], lava = null, W = 16, H = 9, CY = 4.5, matCache = {};
  var tint = 0, camYv = 4.5;

  function mat(hex, o) {
    var k = hex + (o ? JSON.stringify(o) : '');
    if (!matCache[k]) {
      var m = (o && o.basic) ? new THREE.MeshBasicMaterial({ color: hex, transparent: !!(o && o.t), opacity: o && o.op !== undefined ? o.op : 1 })
        : new THREE.MeshLambertMaterial({ color: hex, emissive: o && o.em ? hex : 0x000000, emissiveIntensity: o && o.em ? o.em : 0 });
      matCache[k] = m;
    }
    return matCache[k];
  }
  function box(w, h, d, hex, o) { return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(hex, o)); }
  function lighten(hex, f) { var c = new THREE.Color(hex); c.lerp(new THREE.Color(0xffffff), f); return c.getHex(); }
  function darken(hex, f) { var c = new THREE.Color(hex); c.lerp(new THREE.Color(0x000000), f); return c.getHex(); }

  function init(container) {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    container.appendChild(renderer.domElement);
    scene = new THREE.Scene();
    camera = new THREE.OrthographicCamera(-W / 2, W / 2, H / 2, -H / 2, 0.1, 100);
    window.__cam = camera;
    scene.add(new THREE.AmbientLight(0xffffff, 0.66));
    var dl = new THREE.DirectionalLight(0xffffff, 0.42); dl.position.set(-6, 10, 14); scene.add(dl);
    buildPlayer();
    return renderer.domElement;
  }
  function resize(w, h) { renderer.setSize(w, h, false); }

  /* ---------- player: a coffee bean ---------- */
  function buildPlayer() {
    player = new THREE.Group();
    var body = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 16), mat(0x7a4a2e)); body.scale.set(0.2, 0.36, 0.2); player.add(body);
    var groove = box(0.035, 0.5, 0.05, 0x3b2112); groove.position.set(0, 0.0, 0.2); groove.rotation.z = 0.25; player.add(groove);
    var eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.065, 12, 10), mat(0xffffff)), eyeR = eyeL.clone();
    eyeL.position.set(-0.075, 0.1, 0.17); eyeR.position.set(0.075, 0.1, 0.17); player.add(eyeL); player.add(eyeR);
    var pL = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8), mat(0x111111)), pR = pL.clone();
    pL.position.set(-0.07, 0.1, 0.23); pR.position.set(0.07, 0.1, 0.23); player.add(pL); player.add(pR);
    player.userData = { body: body, pupils: [pL, pR] };
    player.position.z = Z_FRONT; scene.add(player);
  }

  /* ---------- level building ---------- */
  function disposeTree(o) { o.traverse(function (c) { if (c.geometry) c.geometry.dispose(); }); }
  function clearLevel() {
    if (root) { scene.remove(root); disposeTree(root); }
    root = new THREE.Group(); scene.add(root); items = []; layers = []; parts = []; lava = null;
  }
  function gradPlane(w, h, c1, c2) {
    var g = new THREE.PlaneGeometry(w, h, 1, 1), a = new THREE.Color(c1), b = new THREE.Color(c2), col = [];
    [a, a, b, b].forEach(function (c) { col.push(c.r, c.g, c.b); });
    g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(col), 3));
    return new THREE.Mesh(g, new THREE.MeshBasicMaterial({ vertexColors: true }));
  }
  function layer(p) { var g = new THREE.Group(); root.add(g); layers.push({ g: g, p: p }); return g; }

  function buildBackground() {
    var sky = gradPlane(Math.max(40, W * 2.4), Math.max(16, H * 2.4), T.sky[0], T.sky[1]); sky.position.set(0, CY, -12);
    var lsky = layer(1); lsky.add(sky); lsky.userData.isSky = true; // follows the camera exactly
    var i, m;
    if (L.theme === 'field') {
      var sun = layer(0.04), far = layer(0.18), near = layer(0.3), rows = layer(0.5), streaks = layer(0.12), j, sh, mt;
      var halo = new THREE.Mesh(new THREE.CircleGeometry(3.2, 40), mat(0xffd98a, { basic: 1, t: 1, op: 0.3 })); halo.position.set(11.5, 4.3, -9.5); sun.add(halo);
      var disc = new THREE.Mesh(new THREE.CircleGeometry(1.6, 40), mat(0xfff1b8, { basic: 1 })); disc.position.set(11.5, 4.3, -9); sun.add(disc);
      function ridge(group, cover, base, amp, step, col, z, ph) {
        var shp = new THREE.Shape(); shp.moveTo(-4, -3);
        for (var q = -4; q <= cover + 4; q += step) shp.lineTo(q, base + amp * (Math.sin(q * 0.9 + ph) * 0.6 + Math.sin(q * 0.37 + ph * 2) * 0.8 + 1.1));
        shp.lineTo(cover + 4, -3); var rm = new THREE.Mesh(new THREE.ShapeGeometry(shp), mat(col, { basic: 1 })); rm.position.z = z; group.add(rm);
      }
      ridge(far, L.w * 0.18 + 22, 2.4, 1.3, 1.1, 0x7a62ae, -8, 0.5);
      ridge(near, L.w * 0.3 + 22, 1.7, 1.0, 0.9, 0x4d3a85, -7, 2.1);
      for (i = 0; i < (L.w * 0.5 + 22) / 1.05; i++) {
        var bush = new THREE.Mesh(new THREE.SphereGeometry(0.62, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(i % 3 ? 0x2c6a45 : 0x377a50));
        bush.scale.set(1.15, 0.85 + (i % 4) * 0.08, 0.5); bush.position.set(i * 1.05 - 1, 2.3, -3 - (i % 2) * 0.1); rows.add(bush);
        if (i % 2 === 0) for (j = 0; j < 3; j++) { var ch = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 6), mat(0xd4443b, { basic: 1 })); ch.position.set(i * 1.05 - 1.25 + j * 0.28, 2.35 + (j % 2) * 0.2, -2.55); rows.add(ch); }
      }
      for (i = 0; i < (L.w * 0.12 + 24) / 7; i++) {
        var st2 = new THREE.Mesh(new THREE.CircleGeometry(1, 20), mat(0xffd2a8, { basic: 1, t: 1, op: 0.55 }));
        st2.scale.set(2.2 + (i % 3), 0.17, 1); st2.position.set(i * 7 + (i % 2) * 2, 6.2 + (i % 3) * 0.7, -9); streaks.add(st2);
      }
    } else if (L.theme === 'factory') {
      var gear = layer(0.3), pipes = layer(0.5);
      for (i = -2; i < L.w / 8 + 4; i++) {
        m = new THREE.Mesh(new THREE.TorusGeometry(1.1 + (i % 3) * 0.5, 0.22, 6, 10), mat(0x1c2030, { basic: 1 }));
        m.position.set(i * 7.5, 5.2 + (i % 2) * 1.5, -6); m.rotation.z = i; gear.add(m); m.userData.spin = (i % 2 ? 1 : -1) * 0.2;
        var pp = box(0.6, 12, 0.5, 0x181b27, { basic: 1 }); pp.position.set(i * 5.1 + 2, 5, -5); pipes.add(pp);
      }
      lava = box(L.w + 40, 3, 1.6, T.lava, { basic: 1 }); lava.position.set(L.w / 2, -0.3, -1.4); root.add(lava);
    }
  }

  function blockGroup(e) {
    var g = new THREE.Group(), w = e.w, h = e.h, gl = e.glow, ground = (e.y === 2 && h === 1 && !e.crumble && !gl && L.theme !== 'mint' && !L.map);
    var base = T.ground, m;
    if (gl === 'barrel') {
      var rad = w / 2;
      var tub = new THREE.Mesh(new THREE.CylinderGeometry(rad * 0.93, rad * 0.93, h, 20), mat(T.barrel)); tub.scale.z = 0.62; g.add(tub);
      [-0.28, 0.28].forEach(function (f) { var bd = new THREE.Mesh(new THREE.CylinderGeometry(rad * 0.98, rad * 0.98, 0.1, 20), mat(0x2b2b33)); bd.position.y = f * h; bd.scale.z = 0.66; g.add(bd); });
      var lid = new THREE.Mesh(new THREE.CylinderGeometry(rad * 0.86, rad * 0.86, 0.05, 20), mat(lighten(T.barrel, 0.25))); lid.position.y = h / 2; lid.scale.z = 0.62; g.add(lid);
      for (var pl = -2; pl <= 2; pl++) { var pk = box(0.03, h - 0.1, 0.02, darken(T.barrel, 0.3)); pk.position.set(pl * rad * 0.34, 0, rad * 0.62 * 0.9); g.add(pk); }
    } else if (gl === 'crate') {
      m = box(w, h, DEPTH, T.crate); g.add(m);
      var fc = darken(T.crate, 0.45), cx, cy;
      for (cx = 0; cx <= Math.round(w); cx++) { var vl = box(0.07, h + 0.02, DEPTH + 0.03, fc); vl.position.x = Math.min(w / 2, -w / 2 + cx); g.add(vl); }
      for (cy = 0; cy <= Math.round(h); cy++) { var hl = box(w + 0.02, 0.07, DEPTH + 0.03, fc); hl.position.y = Math.min(h / 2, -h / 2 + cy); g.add(hl); }
      if (w <= 2.6 && h <= 2.6) { var dg = box(Math.hypot(w, h) * 0.98, 0.06, DEPTH + 0.035, fc); dg.rotation.z = Math.atan2(h, w); g.add(dg); }
    } else if (gl === 'wall') {
      m = box(w, h, DEPTH, T.wall); g.add(m);
      for (var s = 0; s < 3; s++) { var st = box(w + 0.02, 0.18, DEPTH + 0.02, 0xffffff); st.position.y = -h / 2 + (s + 0.5) * h / 3; g.add(st); }
    } else if (gl === 'belt') {
      m = box(w, h, DEPTH, darken(T.steel, 0.4)); g.add(m);
      var chev = new THREE.Group(); chev.name = 'chev';
      for (var c = 0; c < Math.ceil(w); c++) { var a = box(0.18, 0.1, DEPTH + 0.04, 0xffd34e); a.position.set(c, h / 2 - 0.06, 0); a.rotation.z = e.belt > 0 ? -0.5 : 0.5; chev.add(a); }
      chev.position.x = -w / 2; g.add(chev); g.userData.belt = e.belt; g.userData.w = w;
    } else if (gl === 'pad') {
      m = box(w, h, DEPTH, T.ground); g.add(m);
      var sp = box(w * 0.8, 0.16, DEPTH * 0.7, 0xff8a1f, { em: 0.4 }); sp.position.y = h / 2 + 0.02; g.add(sp); g.userData.pad = sp;
    } else if (gl === 'crusher') {
      m = box(w, h, DEPTH, T.steel); g.add(m);
      for (var q = 0; q < 3; q++) { var tt = box(0.22, 0.2, DEPTH + 0.04, 0xe0452e); tt.position.set(-w / 2 + 0.25 + q * (w - 0.5) / 2, -h / 2 - 0.08, 0); g.add(tt); }
      var pist = box(0.32, 1, 0.4, 0x2b303c); g.add(pist); g.userData.piston = pist;
    } else if (ground) {
      var hh = h + 3.5; m = box(w, hh, DEPTH, base); m.position.y = -hh / 2 + h / 2; g.add(m);
      var tp = box(w + 0.02, 0.2, DEPTH + 0.02, T.top); tp.position.y = h / 2 - 0.1; g.add(tp);
      if (L.theme === 'field') [-0.45, -1.15, -2.05].forEach(function (dy) { var sl = box(w + 0.02, 0.06, DEPTH + 0.02, darken(base, 0.35)); sl.position.y = h / 2 + dy; g.add(sl); });
    } else {
      m = box(w, h, DEPTH, base); g.add(m);
      if (L.theme !== 'mint') { var t2 = box(w + 0.02, 0.16, DEPTH + 0.02, e.crumble ? T.crumble : T.top); t2.position.y = h / 2 - 0.08; g.add(t2); }
      else if (e.crumble) { var t3 = box(w + 0.02, 0.1, DEPTH + 0.02, T.crumble); t3.position.y = h / 2 - 0.05; g.add(t3); }
    }
    if (e.crumble && L.theme !== 'brick') { // crack marks so a crumbly tile can be recognised
      for (var k = 0; k < 2; k++) { var ck = box(0.05, 0.4, DEPTH + 0.04, darken(base, 0.45)); ck.position.set(-0.2 + k * 0.4, 0.05, 0); ck.rotation.z = k ? 0.4 : -0.3; g.add(ck); }
    }
    if (e.ghost) { // a "ghost" ledge is drawn as a row of dashes (like the reference game) until you stand on it, then it turns solid-looking
      g.userData.solidParts = g.children.slice();
      var dg2 = new THREE.Group();
      for (var di = 0; di < 3; di++) { var dd = box(0.24, 0.1, DEPTH * 0.7, T.top, { basic: 1, t: 1, op: 0.9 }); dd.position.set(-0.34 + di * 0.34, h / 2 - 0.05, 0); dg2.add(dd); }
      g.add(dg2); g.userData.ghostDash = dg2;
    }
    return g;
  }

  function spikeShape(len, tall, n) {
    var s = new THREE.Shape(), tw = len / n, i;
    s.moveTo(-len / 2, -tall / 2);
    for (i = 0; i < n; i++) { s.lineTo(-len / 2 + i * tw + tw / 2, tall / 2); s.lineTo(-len / 2 + (i + 1) * tw, -tall / 2); }
    s.lineTo(-len / 2, -tall / 2);
    return s;
  }
  function spikeGroup(e) {
    var g = new THREE.Group(), vertical = (e.dir === 'left' || e.dir === 'right'), len = vertical ? e.h : e.w, tall = vertical ? e.w : e.h;
    var col = T.spike, bodyW = 0;
    if (vertical && e.w > 0.8) { bodyW = e.w - 0.45; tall = 0.45; var bd = box(bodyW, e.h, 0.5, darken(0x6b2a2a, 0.2)); bd.position.x = e.dir === 'right' ? -(e.w - bodyW) / 2 : (e.w - bodyW) / 2; g.add(bd); }
    var n = Math.max(1, Math.round(len / 0.42));
    var geo = new THREE.ExtrudeGeometry(spikeShape(len, tall, n), { depth: 0.3, bevelEnabled: false });
    var m = new THREE.Mesh(geo, mat(col, L.theme === 'factory' ? { em: 0.25 } : undefined)); m.position.z = -0.15;
    var rz = { up: 0, down: Math.PI, right: -Math.PI / 2, left: Math.PI / 2 }[e.dir || 'up'];
    var holder = new THREE.Group(); holder.rotation.z = rz; holder.add(m);
    if (bodyW) holder.position.x = e.dir === 'right' ? e.w / 2 - 0.225 : -e.w / 2 + 0.225;
    g.add(holder); g.position.z = e.pat ? 0 : 0.2; return g;
  }
  function sawGroup(e) {
    var g = new THREE.Group(), r = e.w / 2;
    var blade = new THREE.Mesh(new THREE.CylinderGeometry(r, r, 0.22, 12), mat(0xc3c9d6, { em: 0.15 })); blade.rotation.x = Math.PI / 2; g.add(blade);
    var teeth = new THREE.Mesh(new THREE.CylinderGeometry(r * 1.12, r * 1.12, 0.12, 6), mat(0x8e96a8)); teeth.rotation.x = Math.PI / 2; g.add(teeth);
    var hub = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.28, r * 0.28, 0.3, 10), mat(0xb02a2a)); hub.rotation.x = Math.PI / 2; g.add(hub);
    g.userData.spin = [blade, teeth]; g.position.z = Z_FRONT - 0.1; return g;
  }
  function laserGroup(e) {
    var g = new THREE.Group(), beam = box(e.w, e.h, 0.12, 0xff2a2a, { basic: 1, t: 1, op: 1 }); g.add(beam); g.userData.beam = beam;
    var em1 = box(0.34, 0.34, 0.5, 0x2b303c), em2 = em1.clone();
    if (e.dir === 'v') { em1.position.y = -e.h / 2; em2.position.y = e.h / 2; } else { em1.position.x = -e.w / 2; em2.position.x = e.w / 2; }
    g.add(em1); g.add(em2); g.position.z = 0.25; return g;
  }
  function bombGroup(e) {
    var g = new THREE.Group(), s = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 12), new THREE.MeshLambertMaterial({ color: 0x20232b }));
    g.add(s); var fz = box(0.06, 0.16, 0.06, 0x8b6b3b); fz.position.set(0.1, 0.3, 0); fz.rotation.z = -0.4; g.add(fz);
    var sp = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), mat(0xffd34e, { basic: 1 })); sp.position.set(0.16, 0.4, 0); g.add(sp);
    var ex = new THREE.Mesh(new THREE.CircleGeometry(1, 72), new THREE.MeshBasicMaterial({ color: 0xff9a2e, transparent: true, opacity: 0.8, depthTest: false, depthWrite: false })); ex.visible = false; ex.renderOrder = 998; ex.position.z = 0.15; g.add(ex);
    // the danger zone: shown the whole time the fuse burns, so you can see exactly how far the blast reaches
    var zone = new THREE.Mesh(new THREE.CircleGeometry(1, 64), new THREE.MeshBasicMaterial({ color: 0xff3b2e, transparent: true, opacity: 0.2, depthTest: false, depthWrite: false })); zone.visible = false; zone.renderOrder = 996; zone.position.z = 0.15; g.add(zone);
    var ring = new THREE.Mesh(new THREE.RingGeometry(0.965, 1, 96), new THREE.MeshBasicMaterial({ color: 0xff2a1a, transparent: true, opacity: 0.9, depthTest: false, depthWrite: false })); ring.visible = false; ring.renderOrder = 997; ring.position.z = 0.15; g.add(ring);
    g.userData = { ball: s, spark: sp, ex: ex, zone: zone, ring: ring }; g.position.z = Z_FRONT - 0.15; return g;
  }
  function mugGroup(e) {
    var g = new THREE.Group();
    var body = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.22, 0.5, 18), mat(0xfaf3e3)); g.add(body);
    var cof = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.02, 18), mat(0x4a2c1a)); cof.position.y = 0.24; g.add(cof);
    var hd = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.045, 8, 14), mat(0xfaf3e3)); hd.position.set(0.3, 0, 0); g.add(hd);
    var band = box(0.56, 0.08, 0.56, 0xd9482b); band.visible = false; // (kept for future skins)
    g.userData.steam = [];
    if (!e.fake) for (var i = 0; i < 3; i++) { var st = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 })); g.add(st); g.userData.steam.push(st); }
    g.position.z = Z_FRONT - 0.2; return g;
  }
  function buttonGroup(e) {
    var g = new THREE.Group(), b = box(e.w * 0.9, 0.08, 0.6, 0x2b303c); g.add(b);
    var dome = new THREE.Mesh(new THREE.SphereGeometry(0.28, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(0xe02b2b, { em: 0.35 })); dome.position.y = 0.04; dome.scale.set(1, 0.7, 1); g.add(dome);
    g.userData.dome = dome; g.position.z = 0.3; return g;
  }
  function flagGroup(e) {
    var g = new THREE.Group(), pole = box(0.07, 1.5, 0.07, 0xdfe3ea); pole.position.y = 0.75; g.add(pole);
    var cl = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.42), new THREE.MeshBasicMaterial({ color: 0x9aa0aa, side: THREE.DoubleSide })); cl.position.set(0.38, 1.25, 0); g.add(cl);
    g.userData.cloth = cl; g.position.z = 0.1; return g;
  }

  function loadLevel(level) {
    L = level; T = THEMES[L.theme];
    clearLevel(); buildBackground();
    L.ents.forEach(function (e, ei) {
      var g, k = e.kind || 'block';
      if (k === 'block') g = blockGroup(e); else if (k === 'spike') g = spikeGroup(e); else if (k === 'saw') g = sawGroup(e);
      else if (k === 'laser') g = laserGroup(e); else if (k === 'bomb') g = bombGroup(e); else if (k === 'goal') g = mugGroup(e);
      else if (k === 'button') g = buttonGroup(e); else if (k === 'flag') g = flagGroup(e); else return;
      root.add(g); items.push({ id: e.id, kind: k, g: g, idx: ei });
    });
    camX = 0;
  }

  /* ---------- per-frame sync ---------- */
  function burst(x, y, color) {
    for (var i = 0; i < 16; i++) {
      var m = box(0.1, 0.1, 0.1, i % 3 ? (color || 0x7a4a2e) : 0x3b2112); m.position.set(x, y, Z_FRONT);
      root.add(m); parts.push({ m: m, vx: (Math.random() - 0.5) * 9, vy: Math.random() * 9 + 2, life: 0.9, spin: Math.random() * 8 });
    }
    shake = 0.3;
  }

  function update(st, dt, camTarget, time, camYT) {
    var i, it, e;
    tint = time;
    // camera
    camX += (camTarget - camX) * Math.min(1, dt * 7);
    var sx = shake > 0 ? (Math.random() - 0.5) * shake : 0, sy = shake > 0 ? (Math.random() - 0.5) * shake : 0; shake = Math.max(0, shake - dt * 1.2);
    var cy = CY;
    if (L.map) { camYv += ((camYT === undefined ? 4.5 : camYT) - camYv) * Math.min(1, dt * 6); cy = camYv; } else camYv = 4.5;
    var cx = camX + W / 2;
    camera.position.set(cx + 1.7 + sx, cy + 1.1 + sy, 20); camera.lookAt(cx, cy, 0);
    camera.updateMatrixWorld();
    layers.forEach(function (ly) {
      ly.g.position.x = ly.g.userData.isSky ? cx : camX * (1 - ly.p); if (ly.g.userData.isSky) ly.g.position.y = cy - CY;
      ly.g.children.forEach(function (c) { if (c.userData.spin) c.rotation.z += c.userData.spin * dt; });
    });
    if (lava) lava.position.y = -0.3 + Math.sin(time * 1.6) * 0.06;

    // entities
    for (i = 0; i < items.length; i++) {
      it = items[i]; e = st.ents[it.idx];
      if (!e || e.id !== it.id) continue;
      var g = it.g, k = it.kind, ud = g.userData;
      g.visible = !!e.vis || (k === 'flag');
      if (ud.ghostDash) { g.visible = true; var gv = !!e.vis; ud.solidParts.forEach(function (p) { p.visible = gv; }); ud.ghostDash.visible = !gv; }
      if (k === 'block') {
        g.position.set(e.x + e.w / 2, e.y + e.h / 2, 0);
        if (e.crumble && e.cT && !e.fallen) g.position.x += Math.sin(time * 60) * 0.03;
        if (ud.piston) { var top = e.y + e.h, len = Math.max(0.1, 9.8 - top); ud.piston.scale.y = len; ud.piston.position.y = e.h / 2 + len / 2; }
        if (ud.belt) { var ch = g.getObjectByName('chev'); var off = ((time * ud.belt * 0.45) % 1 + 1) % 1; ch.position.x = -ud.w / 2 + 0.5 + off - 0.5; }
        if (ud.pad) ud.pad.position.y = e.h / 2 + 0.02 + (st.stand === e.id ? -0.05 : 0);
      } else if (k === 'spike') {
        g.position.set(e.x + e.w / 2, e.y + e.h / 2, g.position.z);
      } else if (k === 'saw') {
        g.position.x = e.x; g.position.y = e.y; ud.spin.forEach(function (m) { m.rotation.y += dt * 14; });
        // blades spin around their own axis (cylinder rotated to face camera)
      } else if (k === 'laser') {
        g.position.x = e.x + e.w / 2; g.position.y = e.y + e.h / 2;
        var bm = ud.beam, mt = bm.material;
        if (e.haz) { mt.opacity = 0.95; bm.scale.x = e.dir === 'v' ? 1 + Math.sin(time * 70) * 0.25 : 1; bm.scale.y = e.dir === 'h' ? 1 + Math.sin(time * 70) * 0.25 : 1; mt.color.setHex(0xff3b3b); }
        else if (e.warn) { mt.opacity = (Math.floor(time * 18) % 2) ? 0.55 : 0.12; bm.scale.set(1, 1, 1); mt.color.setHex(0xff9c9c); }
        else { mt.opacity = 0.14; bm.scale.set(1, 1, 1); mt.color.setHex(0xff6666); }
      } else if (k === 'bomb') {
        g.position.x = e.x; g.position.y = e.y;
        var flash = e.bs === 1 ? (Math.floor(time * (8 + 10 * Math.min(1, (st.t - e.bt) / (e.bomb[1])))) % 2) : 0;
        ud.ball.material.color.setHex(flash ? 0xe02b2b : 0x20232b);
        ud.spark.visible = e.bs < 2; ud.ball.visible = e.bs < 2;
        var armed = e.bs === 1, bp = armed ? Math.min(1, (st.t - e.bt) / e.bomb[1]) : 0;
        ud.zone.visible = ud.ring.visible = armed;
        if (armed) { var br = e.bomb[2]; ud.zone.scale.set(br, br, 1); ud.ring.scale.set(br, br, 1); ud.zone.material.opacity = (flash ? 0.34 : 0.16) + 0.1 * bp; ud.ring.material.opacity = flash ? 1 : 0.6; }
        ud.ex.visible = e.bs === 2; if (e.bs === 2) { var f = Math.min(1, (st.t - e.bt) / (e.bomb[3] || 0.25)), rr = e.bomb[2]; ud.ex.scale.set(rr, rr, 1); ud.ex.material.opacity = 0.9 - 0.45 * f; }
      } else if (k === 'goal') {
        g.position.x = e.x; g.position.y = e.y; g.rotation.y = Math.sin(time * 2) * 0.35;
        ud.steam.forEach(function (s, n) { var p = ((time * 0.6 + n / 3) % 1); s.position.set(Math.sin(p * 6 + n) * 0.08, 0.3 + p * 0.55, 0); s.material.opacity = 0.6 * (1 - p); s.scale.setScalar(0.7 + p); });
      } else if (k === 'button') {
        g.position.x = e.x + e.w / 2; g.position.y = e.y;
        ud.dome.scale.y = 0.7 * Math.max(0.25, Math.min(1, (e.y - 2.9) / 0.1));
      } else if (k === 'flag') {
        g.position.x = e.x; g.position.y = e.y;
        ud.cloth.material.color.setHex(e.hit ? 0x4ade80 : 0x9aa0aa); ud.cloth.rotation.y = Math.sin(time * 4) * 0.25;
      }
    }

    // player
    var dead = st.status === 'dead';
    player.visible = !dead;
    var ud2 = player.userData, sq = Math.max(-0.25, Math.min(0.25, st.vy * 0.012 * st.gs));
    player.position.set(st.px, st.py + SIM.P.PH / 2, Z_FRONT);
    player.rotation.z += ((st.gs < 0 ? Math.PI : 0) - player.rotation.z) * Math.min(1, dt * 14);
    player.rotation.y += (st.face * 0.55 - player.rotation.y) * Math.min(1, dt * 16);
    var wob = st.ground && Math.abs(st.vx) > 0.5 ? Math.sin(time * 22) * 0.07 : 0;
    ud2.body.scale.set(0.2 * (1 - sq * 0.8), 0.36 * (1 + sq), 0.2);
    player.children.forEach(function (c) { if (c !== ud2.body) c.position.y += 0; });
    player.rotation.x = wob;

    // particles
    for (i = parts.length - 1; i >= 0; i--) {
      var p = parts[i]; p.life -= dt; p.vy -= 28 * dt; p.m.position.x += p.vx * dt; p.m.position.y += p.vy * dt; p.m.rotation.z += p.spin * dt;
      if (p.life <= 0) { root.remove(p.m); p.m.geometry.dispose(); parts.splice(i, 1); }
    }
    renderer.render(scene, camera);
  }

  return { init: init, resize: resize, loadLevel: loadLevel, update: update, burst: burst, THEMES: THEMES };
})();

/* ===== MAIN: input, screens, game loop, save/load ===== */
(function () {
  var TITLE = 'Bean Rage', KEY = 'beanrage_v1';
  var $ = function (id) { return document.getElementById(id); };
  var keys = { l: 0, r: 0, j: 0 }, pad = { l: 0, r: 0, j: 0 };
  var mode = 'boot', prog = { name: '', level: 1, deaths: 0, finished: false };
  var cur = 0, L = null, st = null, deadT = 0, deadDone = false, winDone = false, winT = 0, clock = 0, last = 0, acc = 0, levelDeaths = 0, saveTimer = 0, toastT = 0;

  /* ---------- persistence: this device + the Google Sheet (when running inside Apps Script) ---------- */
  var Store = {
    gas: function () { return typeof google !== 'undefined' && google.script && google.script.run; },
    key: function (n) { return KEY + ':' + String(n).toLowerCase(); },
    readLocal: function (n) { try { var j = JSON.parse(localStorage.getItem(Store.key(n))); if (j) return j; } catch (e) {} return null; },
    writeLocal: function () { try { localStorage.setItem(Store.key(prog.name), JSON.stringify({ level: prog.level, deaths: prog.deaths, finished: prog.finished })); localStorage.setItem(KEY + ':last', prog.name); } catch (e) {} },
    merge: function (r) {
      if (!r) return;
      prog.level = Math.max(prog.level, +r.level || 1); prog.deaths = Math.max(prog.deaths, +r.deaths || 0); prog.finished = prog.finished || !!r.finished;
      prog.level = Math.min(prog.level, LEVELS.length);
    },
    load: function (name, done) {
      prog = { name: name, level: 1, deaths: 0, finished: false };
      Store.merge(Store.readLocal(name));
      if (!Store.gas()) return done();
      var fin = false, to = setTimeout(function () { if (!fin) { fin = true; done(); } }, 4500);
      google.script.run.withSuccessHandler(function (r) { if (fin) return; fin = true; clearTimeout(to); Store.merge(r); Store.writeLocal(); done(); })
        .withFailureHandler(function () { if (fin) return; fin = true; clearTimeout(to); done(); }).ldGetProgress(name);
    },
    lastPush: 0,
    push: function (force) {
      Store.writeLocal();
      var now = Date.now(); if (!force && now - Store.lastPush < 5000) return; Store.lastPush = now;
      if (!Store.gas()) { setSave('Saved on this device'); return; }
      setSave('Saving…');
      google.script.run.withSuccessHandler(function (r) { Store.merge(r); Store.writeLocal(); setSave('Saved ✓'); })
        .withFailureHandler(function () { setSave('Offline – saved on this device'); }).ldSaveProgress(prog.name, prog.level, prog.deaths, prog.finished);
    }
  };
  function setSave(t) { var s = $('save'); if (s) s.textContent = t; }

  /* ---------- screens ---------- */
  function show(id) { ['ov-name', 'ov-title', 'ov-pause', 'ov-end'].forEach(function (x) { $(x).classList.toggle('on', x === id); }); }
  function toast(msg, cls, ms) { var t = $('toast'); t.textContent = msg; t.className = 'on ' + (cls || ''); toastT = ms || 1.0; }
  function hud() {
    $('h-level').textContent = 'Level ' + (cur + 1) + ' · ' + L.name;
    $('h-deaths').textContent = '☠ ' + prog.deaths;
    var px = st ? st.px : 0, s = L.secs, n = 0;
    for (var i = 0; i < s.length; i++) if (px >= s[i].ox) n = i;
    if (L.map) n = Math.min(st ? st.cp : 0, s.length - 1);
    $('h-room').textContent = (L.map ? 'Zone ' : (L.cam === 'room' ? 'Room ' : 'Part ')) + (n + 1) + '/' + s.length + ' · ' + s[n].name;
  }
  function renderTitle() {
    $('t-hello').textContent = 'Hi ' + prog.name + '!';
    var lv = Math.min(prog.level, LEVELS.length);
    $('t-play').textContent = prog.finished ? '▶ Play again' : (lv > 1 || prog.deaths ? '▶ Continue · Level ' + lv + ': ' + LEVELS[lv - 1].name : '▶ Start · Level 1: ' + LEVELS[0].name);
    var g = $('t-levels'); g.innerHTML = '';
    LEVELS.forEach(function (lev, i) {
      var b = document.createElement('button'); b.className = 'lv' + (i < prog.level ? '' : ' lock');
      b.textContent = i < prog.level ? (i + 1) + ' · ' + lev.name : '🔒 ' + (i + 1);
      b.disabled = i >= prog.level; b.onclick = function () { startLevel(i); }; g.appendChild(b);
    });
    $('t-stats').textContent = '☠ ' + prog.deaths + ' deaths so far';
    show('ov-title'); mode = 'title';
  }
  function afterName(name) {
    $('ov-name').querySelector('p').textContent = 'Loading your progress…';
    Store.load(name, function () { Store.writeLocal(); renderTitle(); });
  }

  /* ---------- game flow ---------- */
  function startLevel(i) {
    cur = i; L = LEVELS[i]; RENDER.loadLevel(L); st = SIM.makeState(L, 0);
    levelDeaths = 0; deadDone = false; winDone = false; winT = 0; deadT = 0; mode = 'play'; show(null);
    var t = $('intro'); t.innerHTML = '<small>LEVEL ' + (i + 1) + '</small>' + L.name; t.className = 'on'; setTimeout(function () { t.className = ''; }, 1800);
    hud();
  }
  function respawn() { st = SIM.makeState(L, st.cp); deadDone = false; deadT = 0; }
  function onDead() {
    deadDone = true; prog.deaths++; levelDeaths++; deadT = 0.8;
    RENDER.burst(st.px, st.py + 0.4); toast(st.msg || 'Ouch', 'bad', 0.9); hud();
    if (levelDeaths % 5 === 0) scheduleSave();
  }
  function onWin() {
    winT = 1.4; toast('☕ Level cleared!', 'good', 1.3);
    prog.level = Math.min(LEVELS.length, Math.max(prog.level, cur + 2));
    if (cur === LEVELS.length - 1) prog.finished = true;
    Store.push(true);
  }
  function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(function () { Store.push(); }, 4000); }
  function pause() { if (mode !== 'play') return; mode = 'pause'; show('ov-pause'); Store.push(); }
  function resume() { if (mode !== 'pause') return; mode = 'play'; show(null); last = performance.now(); }
  function toTitle() { Store.push(); renderTitle(); }

  function camTarget() {
    var W = SIM.P.VIEW_W, px = st.px;
    if (L.cam === 'room') {
      var ox = 0; for (var i = 0; i < L.secs.length; i++) if (px >= L.secs[i].ox) ox = L.secs[i].ox;
      return Math.max(0, Math.min(ox, L.w - W));
    }
    return Math.max(0, Math.min(px - W / 2 + st.face * 1.2, L.w - W));
  }

  function camTargetY() { return L.map ? Math.max(4.5, Math.min(L.mh - 4.5, st.py + 0.8)) : 4.5; }

  function frame(now) {
    requestAnimationFrame(frame);
    var dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (mode === 'play') {
      acc += dt;
      while (acc >= SIM.P.DT) {
        acc -= SIM.P.DT; clock += SIM.P.DT;
        if (st.status === 'play') SIM.step(st, { l: keys.l || pad.l, r: keys.r || pad.r, j: keys.j || pad.j });
      }
      if (st.fx) { if (st.fx === 'flag') { toast('⚑ Checkpoint', 'good', 0.8); Store.writeLocal(); } st.fx = ''; }
      if (st.status === 'dead') { if (!deadDone) onDead(); deadT -= dt; if (deadT <= 0) respawn(); }
      if (st.status === 'won') { if (!winDone) { winDone = true; onWin(); } winT -= dt; if (winT <= 0 && mode === 'play') { if (cur + 1 < LEVELS.length) startLevel(cur + 1); else { mode = 'end'; $('e-deaths').textContent = '☠ ' + prog.deaths + ' deaths in total'; show('ov-end'); } } }
      hud();
    }
    if (L && st) RENDER.update(st, dt, camTarget(), performance.now() / 1000, camTargetY());
    if (toastT > 0) { toastT -= dt; if (toastT <= 0) $('toast').className = ''; }
  }

  /* ---------- input: A / D / Space on desktop, on-screen buttons on phones ---------- */
  function key(e, v) {
    var k = e.key;
    if (k === 'a' || k === 'A') keys.l = v; else if (k === 'd' || k === 'D') keys.r = v; else if (k === ' ' || k === 'Spacebar') keys.j = v;
    else return;
    e.preventDefault();
  }
  window.addEventListener('keydown', function (e) {
    key(e, 1);
    if (e.repeat) return;
    if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') { if (mode === 'play') pause(); else if (mode === 'pause') resume(); }
    if ((e.key === 'r' || e.key === 'R') && mode === 'play' && st.status === 'play') respawn();
  });
  window.addEventListener('keyup', function (e) { key(e, 0); });
  window.addEventListener('blur', function () { keys.l = keys.r = keys.j = 0; pad.l = pad.r = pad.j = 0; if (mode === 'play') pause(); });
  document.addEventListener('visibilitychange', function () { if (document.hidden) { if (mode === 'play') pause(); } });

  function hold(id, k) {
    var b = $(id);
    function down(e) { e.preventDefault(); pad[k] = 1; b.classList.add('down'); try { b.setPointerCapture(e.pointerId); } catch (x) {} document.body.classList.add('touch'); }
    function up(e) { e.preventDefault(); pad[k] = 0; b.classList.remove('down'); }
    b.addEventListener('pointerdown', down); b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('lostpointercapture', up);
    b.addEventListener('contextmenu', function (e) { e.preventDefault(); });
  }

  function fit() {
    var vw = window.innerWidth, vh = window.innerHeight, w = Math.min(vw, vh * 16 / 9), h = w * 9 / 16, s = $('stage');
    s.style.width = w + 'px'; s.style.height = h + 'px'; RENDER.resize(w, h);
    document.body.classList.toggle('portrait', vh > vw);
  }

  function boot() {
    RENDER.init($('view')); fit(); window.addEventListener('resize', fit); window.addEventListener('orientationchange', function () { setTimeout(fit, 200); });
    hold('bL', 'l'); hold('bR', 'r'); hold('bJ', 'j');
    if (window.matchMedia && matchMedia('(pointer: coarse)').matches) document.body.classList.add('touch');
    window.addEventListener('touchstart', function () { document.body.classList.add('touch'); }, { passive: true });
    document.addEventListener('gesturestart', function (e) { e.preventDefault(); });

    $('n-go').onclick = function () {
      var v = $('n-in').value.replace(/[\u0000-\u001f]/g, '').replace(/^[=+\-@\s]+/, '').trim().slice(0, 24);
      if (!v) { $('n-in').focus(); return; } afterName(v);
    };
    $('n-in').addEventListener('keydown', function (e) { e.stopPropagation(); if (e.key === 'Enter') $('n-go').click(); });
    $('t-play').onclick = function () { startLevel(Math.min(prog.finished ? 0 : prog.level, LEVELS.length) - (prog.finished ? 0 : 1)); };
    $('t-name').onclick = function () { $('ov-name').querySelector('p').textContent = 'Who is playing?'; $('n-in').value = prog.name; show('ov-name'); mode = 'name'; };
    $('b-pause').onclick = pause; $('b-restart').onclick = function () { if (mode === 'play' && st.status === 'play') respawn(); };
    $('p-resume').onclick = resume; $('p-restart').onclick = function () { startLevel(cur); };
    $('p-title').onclick = toTitle; $('e-title').onclick = function () { renderTitle(); };

    var pre = (document.body.dataset.user || '').trim(), saved = ''; try { saved = localStorage.getItem(KEY + ':last') || ''; } catch (e) {}
    var name = pre || saved;
    L = LEVELS[0]; RENDER.loadLevel(L); st = SIM.makeState(L, 0); // pretty backdrop behind the menu
    if (name) { mode = 'boot'; afterName(name); } else { show('ov-name'); mode = 'name'; }
    last = performance.now(); requestAnimationFrame(frame);
  }
  window.__bean = { SIM: SIM, LEVELS: LEVELS, get st() { return st; }, startLevel: startLevel, get prog() { return prog; }, get mode() { return mode; } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
