
"use strict";

// VELOCITY X RACING

const game = document.getElementById("game");
const speedText = document.getElementById("speed");
const gearText = document.getElementById("gear");
const scoreText = document.getElementById("score");
const bestText = document.getElementById("best-score");
const message = document.getElementById("message");

if (!window.THREE) {
  if (message) message.textContent = "THREE.JS LOAD NAHI HUA";
  throw new Error("Three.js failed to load");
}

// SCENE
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x85c4e8);
scene.fog = new THREE.Fog(0x85c4e8, 65, 290);

const camera = new THREE.PerspectiveCamera(65, 1, 0.1, 350);

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: "high-performance"
});

renderer.setPixelRatio(
  Math.min(window.devicePixelRatio || 1, 1.5)
);
renderer.shadowMap.enabled = false;
renderer.outputColorSpace = THREE.SRGBColorSpace;
game.prepend(renderer.domElement);

// LIGHTS
scene.add(new THREE.HemisphereLight(0xe5f5ff, 0x46533a, 2));

const sun = new THREE.DirectionalLight(0xffffff, 2.4);
sun.position.set(-20, 35, 15);
sun.castShadow = false;
scene.add(sun);

// MATERIALS
function mat(color, roughness = 0.7, metalness = 0) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness,
    metalness
  });
}

const grassMat = mat(0x789e5e);
const roadMat = mat(0x292c30, 0.88);
const lineMat = mat(0xf7f5ed);
const metalMat = mat(0xc4d0d9, 0.22, 0.85);
const darkMat = mat(0x101720, 0.35, 0.5);
const goldMat = mat(0xc4a05b, 0.25, 0.75);

function box(parent, w, h, d, material, x, y, z) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    material
  );

  mesh.position.set(x, y, z);
  mesh.castShadow = false;
  mesh.receiveShadow = false;
  parent.add(mesh);
  return mesh;
}

// GROUND
const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(400, 450),
  grassMat
);

ground.rotation.x = -Math.PI / 2;
ground.position.set(0, -0.09, -170);
scene.add(ground);

// ROAD — NO EXTRA TEXTURE
const road = new THREE.Mesh(
  new THREE.PlaneGeometry(13, 450),
  roadMat
);

road.rotation.x = -Math.PI / 2;
road.position.set(0, 0, -170);
scene.add(road);

// ROAD EDGES
for (const x of [-6.35, 6.35]) {
  box(scene, 0.13, 0.035, 450, lineMat, x, 0.02, -170);
}

// LANE MARKINGS
const laneMarks = [];

for (let z = -430; z < 20; z += 10) {
  for (const x of [-2.15, 2.15]) {
    const mark = box(
      scene, 0.12, 0.025, 4,
      lineMat, x, 0.025, z
    );

    laneMarks.push(mark);
  }
}

// CITY
const towers = [];

const towerMats = [
  mat(0x344c60, 0.25, 0.62),
  mat(0x8198a8, 0.3, 0.48),
  mat(0x3a4556, 0.23, 0.65),
  mat(0x9d9b91, 0.4, 0.25),
  mat(0x49687b, 0.22, 0.65)
];

const glassMat = mat(0x3e87ad, 0.23, 0.48);
const warmWindowMat = mat(0xffd59b, 0.35, 0.15);

function createTower(side, z, i) {
  const group = new THREE.Group();

  const w = 5 + Math.random() * 4;
  const d = 6 + Math.random() * 5;
  const h = 18 + Math.random() * 24;
  const x = side * (11 + Math.random() * 9);

  box(group, w, h, d, towerMats[i % towerMats.length],
    0, h / 2, 0);

  box(group, w + 1, 2, d + 1, darkMat, 0, 1, 0);
  box(group, w + 0.7, 0.16, d + 0.7,
    metalMat, 0, 2.1, 0);

  const rows = Math.floor(h / 2);
  const cols = Math.max(3, Math.floor(w / 1.15));

  for (let r = 0; r < rows; r++) {
    const wy = 1.6 + r * (h - 2.2) / rows;

    for (let c = 0; c < cols; c++) {
      const wx = -w / 2 + (c + 0.5) * w / cols;
      const wm = Math.random() < 0.12
        ? warmWindowMat
        : glassMat;

      box(group, w / cols * 0.68, 0.85, 0.045,
        wm, wx, wy, d / 2 + 0.035);
    }
  }

  for (let r = 0; r < rows; r++) {
    const wy = 1.6 + r * (h - 2.2) / rows;

    for (let c = 0; c < 4; c++) {
      const wz = -d / 2 + (c + 0.5) * d / 4;

      box(group, 0.045, 0.85, d / 4 * 0.65,
        glassMat, -side * (w / 2 + 0.03), wy, wz);
    }
  }

  for (let y = 4; y < h; y += 4) {
    box(group, w + 0.12, 0.07, 0.1,
      metalMat, 0, y, d / 2 + 0.04);
  }

  box(group, w * 0.65, 0.6, d * 0.65,
    darkMat, 0, h + 0.3, 0);

  if (i % 2 === 0) {
    box(group, 0.09, 2, 0.09,
      metalMat, 0, h + 1.5, 0);
  }

  if (i % 3 === 0) {
    box(group, w + 0.2, 0.12, d + 0.2,
      goldMat, 0, h * 0.72, 0);
  }

  group.position.set(x, 0, z);
  scene.add(group);
  towers.push({ group });
}

for (let i = 0; i < 28; i++) {
  createTower(i % 2 === 0 ? -1 : 1, -18 - i * 13, i);
}

// ==================================================
// DETAILED PROCEDURAL 3D SPORTS CAR
// ==================================================

const car = new THREE.Group();
scene.add(car);
car.position.set(0, 0, 2);

const carRed = new THREE.MeshPhysicalMaterial({
  color: 0xe50920,
  metalness: 0.48,
  roughness: 0.2,
  clearcoat: 1,
  clearcoatRoughness: 0.1
});

const carGlass = new THREE.MeshPhysicalMaterial({
  color: 0x102432,
  roughness: 0.16,
  metalness: 0.25,
  clearcoat: 1
});

const darkMatCar = mat(0x080d12, 0.34, 0.35);
const rubberCar = mat(0x101113, 0.82);
const metalCar = mat(0xb9c5ce, 0.24, 0.85);
const carbonCar = mat(0x15191d, 0.48, 0.35);

const headCar = new THREE.MeshStandardMaterial({
  color: 0xffffff,
  emissive: 0x8bdfff,
  emissiveIntensity: 1.8
});

const tailCar = new THREE.MeshStandardMaterial({
  color: 0xff1020,
  emissive: 0xff0015,
  emissiveIntensity: 1.8
});

function carBox(w, h, d, material, x, y, z) {
  return box(car, w, h, d, material, x, y, z);
}

function carCylinder(radius, depth, material, x, y, z, sides = 24) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(radius, radius, depth, sides),
    material
  );

  mesh.rotation.z = Math.PI / 2;
  mesh.position.set(x, y, z);
  mesh.castShadow = false;
  car.add(mesh);
  return mesh;
}

// Low chassis and body
carBox(1.72, 0.25, 3.75, carbonCar, 0, 0.38, 0);
carBox(1.88, 0.24, 2.45, carRed, 0, 0.48, -0.15);

// Bonnet and rear engine cover
carBox(1.55, 0.15, 1.35, carRed, 0, 0.62, -1.22);
carBox(1.48, 0.16, 0.88, carRed, 0, 0.63, 1.22);

// Front splitter and rear diffuser
carBox(1.95, 0.075, 0.32, carbonCar, 0, 0.29, -1.91);
carBox(1.55, 0.045, 0.08, metalCar, 0, 0.34, -1.99);
carBox(1.62, 0.1, 0.36, carbonCar, 0, 0.29, 1.83);

for (const x of [-0.48, -0.16, 0.16, 0.48]) {
  carBox(0.045, 0.13, 0.3, metalCar, x, 0.31, 1.84);
}

// Cabin and roof
carBox(1.34, 0.43, 1.62, carGlass, 0, 1.0, 0.12);
carBox(1.12, 0.09, 0.78, carRed, 0, 1.25, 0.25);

for (const x of [-0.66, 0.66]) {
  const frontPillar = carBox(
    0.07, 0.42, 0.08, carRed, x, 1.0, -0.48
  );
  frontPillar.rotation.x = -0.22;

  const rearPillar = carBox(
    0.07, 0.4, 0.08, carRed, x, 1.0, 0.78
  );
  rearPillar.rotation.x = 0.25;
}

// Side skirts, mirrors and vents
for (const x of [-0.91, 0.91]) {
  carBox(0.12, 0.13, 2.25, carbonCar, x, 0.39, 0.02);
  carBox(0.035, 0.035, 1.5, metalCar, x * 1.025, 0.46, 0.05);

  carBox(0.21, 0.09, 0.15, carRed, x * 1.04, 0.96, -0.48);
  carBox(0.15, 0.045, 0.1, darkMatCar, x * 1.05, 0.99, -0.48);

  for (let i = 0; i < 3; i++) {
    carBox(0.025, 0.025, 0.16, metalCar,
      x * 1.035, 0.61, 0.72 + i * 0.09);
  }
}

// LED headlights and rear lights
for (const x of [-0.61, 0.61]) {
  carBox(0.43, 0.085, 0.12, carbonCar, x, 0.69, -1.79);
  carBox(0.33, 0.04, 0.055, headCar, x, 0.72, -1.85);

  carBox(0.48, 0.075, 0.07, carbonCar, x * 0.82, 0.68, 1.87);
  carBox(0.39, 0.04, 0.04, tailCar, x * 0.82, 0.70, 1.92);
}

// Front grille and air intakes
carBox(0.68, 0.17, 0.07, darkMatCar, 0, 0.46, -1.89);

for (const x of [-0.72, 0.72]) {
  carBox(0.23, 0.15, 0.07, carbonCar, x, 0.47, -1.78);
}

// Dual exhaust
for (const x of [-0.48, 0.48]) {
  carCylinder(0.105, 0.09, metalCar, x, 0.4, 1.94, 16);
  carCylinder(0.067, 0.095, darkMatCar, x, 0.4, 2.0, 16);
}

// Rear spoiler
for (const x of [-0.58, 0.58]) {
  carBox(0.07, 0.24, 0.07, carbonCar, x, 0.96, 1.53);
}

carBox(1.78, 0.085, 0.24, carbonCar, 0, 1.10, 1.58);
carBox(1.48, 0.035, 0.10, carRed, 0, 1.15, 1.58);

// Wheels, rims and spokes
const wheels = [];

for (const x of [-0.96, 0.96]) {
  for (const z of [-1.18, 1.18]) {
    const tyre = carCylinder(0.36, 0.26, rubberCar, x, 0.4, z, 28);
    wheels.push(tyre);

    carCylinder(0.245, 0.28, darkMatCar, x, 0.4, z, 24);
    carCylinder(0.225, 0.30, metalCar, x * 1.015, 0.4, z, 24);
    carCylinder(0.145, 0.31, darkMatCar, x * 1.02, 0.4, z, 16);
    carCylinder(0.06, 0.32, metalCar, x * 1.025, 0.4, z, 12);

    for (const side of [-1, 1]) {
      for (let i = 0; i < 5; i++) {
        const angle = i * Math.PI * 2 / 5;

        const spoke = carBox(
          0.035, 0.24, 0.035,
          metalCar,
          x + side * 0.155,
          0.4 + Math.sin(angle) * 0.09,
          z + Math.cos(angle) * 0.09
        );

        spoke.rotation.x = angle;
      }
    }
  }
}

// Bonnet details and rear vents
for (const x of [-0.36, 0.36]) {
  carBox(0.045, 0.018, 0.72, carbonCar, x, 0.704, -1.18);
}

for (let i = -2; i <= 2; i++) {
  carBox(0.045, 0.018, 0.32, carbonCar,
    i * 0.18, 0.72, 1.24);
}

// INPUTS
const input = {
  left: false,
  right: false,
  accelerate: false,
  brake: false
};

function bindButton(id, key) {
  const button = document.getElementById(id);
  if (!button) return;

  button.addEventListener("pointerdown", e => {
    e.preventDefault();
    input[key] = true;
    button.classList.add("active");
    message.textContent = "";

    try {
      button.setPointerCapture(e.pointerId);
    } catch (_) {}
  });

  const release = () => {
    input[key] = false;
    button.classList.remove("active");
  };

  button.addEventListener("pointerup", release);
  button.addEventListener("pointercancel", release);
  button.addEventListener("lostpointercapture", release);
}

bindButton("left", "left");
bindButton("right", "right");
bindButton("accelerate", "accelerate");
bindButton("brake", "brake");

// Keyboard controls
window.addEventListener("keydown", e => {
  const k = e.key.toLowerCase();

  if (k === "arrowleft" || k === "a") input.left = true;
  if (k === "arrowright" || k === "d") input.right = true;
  if (k === "arrowup" || k === "w") input.accelerate = true;
  if (k === "arrowdown" || k === "s") input.brake = true;
});

window.addEventListener("keyup", e => {
  const k = e.key.toLowerCase();

  if (k === "arrowleft" || k === "a") input.left = false;
  if (k === "arrowright" || k === "d") input.right = false;
  if (k === "arrowup" || k === "w") input.accelerate = false;
  if (k === "arrowdown" || k === "s") input.brake = false;
});

window.addEventListener("blur", () => {
  Object.keys(input).forEach(k => input[k] = false);
});

// BEST SCORE
let bestScore = 0;

try {
  bestScore = Number(localStorage.getItem("velocityXBest") || 0);
} catch (_) {}

let score = 0;
let speed = 0;
let carX = 0;
let steering = 0;
let started = false;

if (bestText) {
  bestText.textContent = String(bestScore).padStart(6, "0");
}

// FULLSCREEN
const fullscreenButton = document.getElementById("fullscreen");

if (fullscreenButton) {
  fullscreenButton.addEventListener("click", async () => {
    try {
      if (!document.fullscreenElement && game.requestFullscreen) {
        await game.requestFullscreen();
      }

      if (screen.orientation && screen.orientation.lock) {
        await screen.orientation.lock("landscape");
      }
    } catch (_) {
      message.textContent = "PHONE KO LANDSCAPE KARO";
    }
  });
}

// RESIZE
function resize() {
  const w = game.clientWidth;
  const h = game.clientHeight;

  if (!w || !h) return;

  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h, false);
}

window.addEventListener("resize", resize);

window.addEventListener("orientationchange", () => {
  setTimeout(resize, 250);
});

resize();

// GAME LOOP
const clock = new THREE.Clock();
const maxSpeed = 290;

function animate() {
  requestAnimationFrame(animate);

  const dt = Math.min(clock.getDelta(), 0.04);

  if (input.accelerate) {
    speed += 80 * dt;
    started = true;
  } else {
    speed -= 17 * dt;
  }

  if (input.brake) speed -= 125 * dt;

  speed = THREE.MathUtils.clamp(speed, 0, maxSpeed);

  let direction = 0;
  if (input.left) direction -= 1;
  if (input.right) direction += 1;

  steering += (direction - steering) * Math.min(1, dt * 7);

  carX += steering * (0.014 + speed * 0.00022) * speed * dt;
  carX = THREE.MathUtils.clamp(carX, -4.7, 4.7);

  car.position.x = carX;
  car.rotation.y = -steering * 0.12;
  car.rotation.z = -steering * 0.045;

  wheels.forEach(wheel => {
    wheel.rotation.x += speed * dt * 0.015;
  });

  // Road markings move to simulate driving
  const movement = speed * dt * 0.14;

  laneMarks.forEach(mark => {
    mark.position.z += movement;

    if (mark.position.z > 12) {
      mark.position.z -= 450;
    }
  });

  // Recycle city buildings
  towers.forEach(item => {
    item.group.position.z += movement;

    if (item.group.position.z > 25) {
      item.group.position.z -= 364;
    }
  });

  // Chase camera
  camera.position.x +=
    (carX * 0.65 - camera.position.x) * dt * 2.5;

  camera.position.y += (4.2 - camera.position.y) * dt * 2;
  camera.position.z += (10.5 - camera.position.z) * dt * 2;

  camera.lookAt(carX * 0.35, 0.6, -5);

  // Score
  if (speed > 0) score += speed * dt * 0.5;
  score = Math.floor(score);

  if (scoreText) {
    scoreText.textContent = String(score).padStart(6, "0");
  }

  if (score > bestScore) {
    bestScore = score;

    if (bestText) {
      bestText.textContent = String(bestScore).padStart(6, "0");
    }

    try {
      localStorage.setItem("velocityXBest", String(bestScore));
    } catch (_) {}
  }

  // Speedometer
  if (speedText) {
    speedText.textContent = String(Math.round(speed)).padStart(3, "0");
  }

  const gear = speed < 2 ? "N" :
    speed < 45 ? "1" :
    speed < 85 ? "2" :
    speed < 130 ? "3" :
    speed < 175 ? "4" : "5";

  if (gearText) gearText.textContent = "GEAR " + gear;

  if (!started) {
    message.textContent = "HOLD ACCELERATE TO DRIVE";
  } else if (Math.abs(carX) > 4.3) {
    message.textContent = "CAREFUL! ROAD EDGE";
  } else {
    message.textContent = "";
  }

  renderer.render(scene, camera);
}

animate();

// LOADING SCREEN
setTimeout(() => {
  const loadingScreen = document.getElementById("loading-screen");

  if (loadingScreen) {
    loadingScreen.style.display = "none";
  }
}, 3000);

// HOME MENU PLAY BUTTON
const playButton = document.getElementById("start-btn");
const homeMenu = document.getElementById("home-menu");

if (playButton && homeMenu) {
  playButton.addEventListener("click", () => {
    homeMenu.style.display = "none";
  });
}
