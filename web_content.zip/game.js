
  
  
const COLORS={
  R:{name:'Red',hex:'#ef4444',dark:'#b91c1c'},
  G:{name:'Green',hex:'#22c55e',dark:'#15803d'},
  B:{name:'Blue',hex:'#3b82f6',dark:'#1d4ed8'},
  Y:{name:'Yellow',hex:'#facc15',dark:'#ca8a04'},
  O:{name:'Orange',hex:'#f97316',dark:'#c2410c'},
  C:{name:'Cyan',hex:'#06b6d4',dark:'#0e7490'}
};

const KEYS=['R','G','B','Y','O','C'];
const expertMode=document.body.classList.contains('expert-mode');
const timeElement=document.getElementById('time');
const movesElement=document.getElementById('moves');
const stepListElement=document.getElementById('stepList');
const stepProgressElement=document.getElementById('stepProgress');
const nextStepElement=document.getElementById('nextStep');
const winElement=document.getElementById('win');
const resultElement=document.getElementById('result');

const wheelSpinSound=new Audio('wheel-spin.wav');

function playSound(sound){
  sound.currentTime=0;
  sound.play().catch(()=>{});
}

function rotationSound(){
  playSound(wheelSpinSound);
}

function persistExpertGame(game){
  if(!expertMode||!window.VennRubikStorage||!game.scrambleMoves.length)return;

  window.VennRubikStorage.save({
    scramble:game.scrambleMoves,
    moves:game.history.slice(game.scrambleMoves.length),
    elapsed:game.start?Math.floor((Date.now()-game.start)/1000):0
  });
}

class Engine{

  constructor(){
    this.centers=[
      {x:0,y:-.1486486486},
      {x:-.12,y:.0472972973},
      {x:.12,y:.0472972973}
    ];

    this.radii=[
      .2972972973,
      .2527027027,
      .2081081081
    ];

    this.rings=[];
    this.slots=[];
    this.pieces=[];
    this.pieceAt=[];
    this.ringPositions=[];
    this.moves=0;
    this.start=0;
    this.timer=null;
    this.resumeTimer=false;
    this.solved=true;
    this.history=[];
    this.scrambleMoves=[];
    this.solution=[];
    this.build();
    this.reset();

    if(expertMode){
      const saved=window.VennRubikStorage?.load();
      if(saved){
        this.restore(saved);
      }else{
        this.scramble(24);
      }
    }
  }

  inter(a,r,b,s){
    const dx=b.x-a.x;
    const dy=b.y-a.y;
    const d=Math.hypot(dx,dy);

    if(!d||d>r+s||d<Math.abs(r-s))return[];

    const q=(r*r-s*s+d*d)/(2*d);
    const h=Math.sqrt(Math.max(0,r*r-q*q));

    const mx=a.x+q*dx/d;
    const my=a.y+q*dy/d;

    const ox=-dy/d*h;
    const oy=dx/d*h;

    return[
      {x:mx+ox,y:my+oy},
      {x:mx-ox,y:my-oy}
    ];
  }

  build(){
    const defs=[];

    for(let c=0;c<3;c++){
      for(let l=0;l<3;l++){
        defs.push({
          id:c*3+l,
          center:this.centers[c],
          radius:this.radii[l],
          orbitIndex:l+1,
          circleIndex:c+1,
          nodeIds:[]
        });
      }
    }

    const pairs=[
      ['R','O'],
      ['G','B'],
      ['Y','C']
    ];

    let id=0;

    for(let a=0;a<3;a++){
      for(let b=a+1;b<3;b++){

        const pair=pairs[(a+b+2)%3];

        for(let la=0;la<3;la++){
          for(let lb=0;lb<3;lb++){

            const ra=defs[a*3+la];
            const rb=defs[b*3+lb];

            const pts=this.inter(
              ra.center,
              ra.radius,
              rb.center,
              rb.radius
            );

            for(const p of pts){

              const dx=rb.center.x-ra.center.x;
              const dy=rb.center.y-ra.center.y;

              const side=
                dx*(p.y-ra.center.y)-
                dy*(p.x-ra.center.x);

              const color=side>=0?pair[0]:pair[1];

              this.slots.push({
                id:id,
                x:p.x,
                y:p.y,
                rings:[ra.id,rb.id],
                solvedColor:color
              });

              ra.nodeIds.push(id);
              rb.nodeIds.push(id);

              this.pieces.push(color);

              id++;
            }
          }
        }
      }
    }

    for(const ring of defs){

      ring.nodeIds.sort((a,b)=>{
        return Math.atan2(
          this.slots[a].y-ring.center.y,
          this.slots[a].x-ring.center.x
        )-
        Math.atan2(
          this.slots[b].y-ring.center.y,
          this.slots[b].x-ring.center.x
        );
      });

      this.rings.push(ring);
    }

    this.pieceAt=this.slots.map(s=>s.id);
    this.ringPositions=this.rings.map(ring=>{
      const positions=new Int16Array(this.slots.length);
      positions.fill(-1);

      ring.nodeIds.forEach((slotId,index)=>{
        positions[slotId]=index;
      });

      return positions;
    });
  }

  reset(){
    this.pieceAt=this.slots.map(s=>s.id);
    this.moves=0;
    this.solved=true;
    this.history=[];
    this.scrambleMoves=[];
    this.solution=[];
    this.stop();
    this.start=0;
    this.resumeTimer=false;
  }

  color(slot){
    return this.pieces[this.pieceAt[slot]];
  }

  step(ringIndex,steps,count=true){
    const ring=this.rings[ringIndex];

    if(!ring||!steps)return;

    const ids=ring.nodeIds;
    const n=ids.length;
    const shift=((steps%n)+n)%n;
    const next=this.pieceAt.slice();

    for(let i=0;i<n;i++){
      next[ids[(i+shift)%n]]=this.pieceAt[ids[i]];
    }

    this.pieceAt=next;

    if(count){
      this.moves+=Math.abs(steps);
    }

    this.check();
  }

  recordMove(ring,step){
    if(!step)return;

    this.history.push({ring,step});

    const expected=this.solution[0];

    if(expected && expected.ring===ring && expected.step===step){
      this.solution.shift();
    }else{
      this.solution.unshift({ring,step:-step});
    }
  }

  consumeSolutionMove(ring,step){
    const expected=this.solution[0];
    if(expected && expected.ring===ring && expected.step===step){
      this.solution.shift();
    }
  }

  check(){
    this.solved=this.slots.every(
      s=>this.color(s.id)===s.solvedColor
    );

    if(this.solved&&this.moves){
      this.stop();
    }

    return this.solved;
  }

  scramble(n=24){
    this.reset();

    let prev=-1;
    const scrambleMoves=[];

    for(let i=0;i<n;i++){

      let r;

      do{
        r=Math.floor(Math.random()*this.rings.length);
      }while(r===prev);

      const direction=Math.random()<.5?1:-1;

      this.step(r,direction,false);

      scrambleMoves.push({
        ring:r,
        step:direction
      });

      prev=r;
    }

    this.moves=0;
    this.solved=false;
    this.scrambleMoves=scrambleMoves;
    this.history=this.scrambleMoves.slice();

    this.solution=this.history.slice().reverse().map(move=>({
      ring:move.ring,
      step:-move.step
    }));

    persistExpertGame(this);
  }

  restore(saved){
    if(!Array.isArray(saved.scramble)||!saved.scramble.length)return;

    this.reset();
    this.scrambleMoves=saved.scramble.map(move=>({
      ring:Number(move.ring),
      step:Number(move.step)
    }));

    for(const move of this.scrambleMoves){
      this.step(move.ring,move.step,false);
    }

    this.history=this.scrambleMoves.slice();
    this.solution=this.history.slice().reverse().map(move=>({
      ring:move.ring,
      step:-move.step
    }));

    if(Array.isArray(saved.moves)){
      for(const move of saved.moves){
        const restoredMove={ring:Number(move.ring),step:Number(move.step)};
        this.step(restoredMove.ring,restoredMove.step,true);
        this.recordMove(restoredMove.ring,restoredMove.step);
      }
    }

    this.check();
    if(!this.solved&&(saved.elapsed||saved.moves?.length)){
      this.start=Date.now()-Number(saved.elapsed)*1000;
      this.resumeTimer=true;
    }
  }

  startTimer(){
    if(this.timer)return;

    if(!this.start)this.start=Date.now();

    this.timer=setInterval(()=>{
      uiTime();
    },250);
  }

  stop(){
    if(this.timer){
      clearInterval(this.timer);
      this.timer=null;
    }
  }

  autoSolve(renderer){

    if(renderer.anim || this.solved || !this.solution.length || renderer.autoSolving){
      return;
    }

    renderer.autoSolving=true;

    const next=()=>{
      if(!this.solution.length){
        this.check();
        renderer.autoSolving=false;
        this.history=[];
        this.solution=[];
        stepSolution=[];
        stepIndex=0;
        stepSolverOpen=false;
        stepListElement?.classList.remove('show');
        if(stepProgressElement)stepProgressElement.textContent='';
        if(nextStepElement)nextStepElement.style.display='none';
        ui();
        return;
      }

      const move={...this.solution[0]};
      const ring=this.rings[move.ring];
      const amount=move.step*(Math.PI*2/ring.nodeIds.length);

      renderer.snap(move.ring,move.step,amount,()=>{
        this.consumeSolutionMove(move.ring,move.step);
        setTimeout(next,420);
      },false,false);
    };

    next();
  }
}

class Renderer{

  constructor(canvas,engine){

    this.c=canvas;
    this.x=canvas.getContext('2d');
    this.e=engine;

    this.w=0;
    this.h=0;
    this.scaleV=0;

    this.active=-1;
    this.hover=-1;
    this.down=false;
    this.moved=false;
    this.last=0;
    this.drag=0;

    this.anim=null;
    this.autoSolving=false;

    this.resize=this.resize.bind(this);
    this.downHandler=this.downHandler.bind(this);
    this.moveHandler=this.moveHandler.bind(this);
    this.upHandler=this.upHandler.bind(this);

    canvas.addEventListener(
      'pointerdown',
      this.downHandler
    );

    canvas.addEventListener(
      'pointermove',
      this.moveHandler
    );

    canvas.addEventListener(
      'pointerup',
      this.upHandler
    );

    canvas.addEventListener(
      'pointercancel',
      this.upHandler
    );

    window.addEventListener(
      'resize',
      this.resize
    );

    this.resize();
  }

  resize(){

    const r=this.c.parentElement.getBoundingClientRect();
    const d=Math.max(
      1,
      window.devicePixelRatio||1
    );

    this.c.width=Math.round(r.width*d);
    this.c.height=Math.round(r.height*d);

    this.x.setTransform(
      d,
      0,
      0,
      d,
      0,
      0
    );

    this.w=r.width;
    this.h=r.height;

    this.scaleV=Math.min(
      this.w,
      this.h
    );

    this.draw();
  }

  px(v){
    return this.w/2+v*this.scaleV;
  }

  py(v){
    return this.h/2+v*this.scaleV;
  }

  rad(v){
    return v*this.scaleV;
  }

  angle(r,x,y){
    return Math.atan2(
      y-this.py(r.center.y),
      x-this.px(r.center.x)
    );
  }

  norm(a){
    while(a>Math.PI)a-=Math.PI*2;
    while(a<-Math.PI)a+=Math.PI*2;
    return a;
  }

  ringAt(x,y){

    let best=-1;
    let delta=1e9;

    for(let i=0;i<this.e.rings.length;i++){

      const r=this.e.rings[i];

      const d=Math.hypot(
        x-this.px(r.center.x),
        y-this.py(r.center.y)
      );

      const q=Math.abs(
        d-this.rad(r.radius)
      );

      if(
        q<Math.min(25,this.w*.045)&&
        q<delta
      ){
        delta=q;
        best=i;
      }
    }

    return best;
  }

  pos(ev){

    const r=this.c.getBoundingClientRect();

    return{
      x:ev.clientX-r.left,
      y:ev.clientY-r.top
    };
  }

  downHandler(ev){

    if(this.anim||this.autoSolving)return;

    const p=this.pos(ev);
    const r=this.ringAt(p.x,p.y);

    if(r<0)return;

    this.down=true;
    this.moved=false;
    this.active=r;
    this.last=this.angle(
      this.e.rings[r],
      p.x,
      p.y
    );

    this.drag=0;

    this.c.classList.add('dragging');

    this.c.setPointerCapture?.(
      ev.pointerId
    );

    ev.preventDefault();
  }

  moveHandler(ev){

    const p=this.pos(ev);

    if(!this.down){

      const r=this.ringAt(
        p.x,
        p.y
      );

      if(r!==this.hover){
        this.hover=r;
        this.draw();
      }

      return;
    }

    const a=this.angle(
      this.e.rings[this.active],
      p.x,
      p.y
    );

    const d=this.norm(
      a-this.last
    );

    if(Math.abs(d)>.0004){

      this.moved=true;
      this.drag+=d;
      this.last=a;

      this.draw();
    }

    ev.preventDefault();
  }

  upHandler(ev){

    if(!this.down)return;

    this.down=false;

    this.c.classList.remove(
      'dragging'
    );

    const r=this.active;
    const d=this.drag;

    this.active=-1;

    if(!this.moved){

      this.draw();

      return;
    }

    const ring=this.e.rings[r];
    const n=ring.nodeIds.length;

    let step=Math.round(
      d/(Math.PI*2/n)
    );

    step=((step%n)+n)%n;

    if(step>n/2){
      step-=n;
    }

    if(!step){

      this.drag=0;
      this.draw();

      return;
    }

    this.snap(
      r,
      step,
      d,
      null,
      true
    );

    ev.preventDefault();
  }

  snap(
    r,
    step,
    from,
    done=null,
    countMove=true,
    recordHistory=true
  ){

    if(this.anim)return;

    if(countMove&&!this.e.timer){
      this.e.startTimer();
    }

    const ring=this.e.rings[r];
    const ids=ring.nodeIds;
    const n=ids.length;

    const start=performance.now();

    const duration=
      620+
      Math.min(
        260,
        Math.abs(from)*55
      );

    this.anim={
      r,
      step,
      from,
      ids,
      start,
      duration,
      progress:0,
      countMove
    };

    rotationSound(step>0?1:-1);

    const frame=now=>{

      if(!this.anim)return;

      const t=Math.min(
        1,
        (now-start)/duration
      );

      const q=
        t<.5
          ?4*t*t*t
          :1-Math.pow(-2*t+2,3)/2;

      this.anim.progress=q;

      this.draw();

      if(t<1){

        requestAnimationFrame(frame);

        return;
      }

      this.e.step(r,step,countMove);

      if(recordHistory){
        this.e.recordMove(r,step);
      }

      this.anim=null;
      this.drag=0;

      if(recordHistory){
        refreshStepSolverFromCurrentState();
      }

      persistExpertGame(this.e);

      ui();

      if(done)done();
    };

    requestAnimationFrame(frame);
  }

  ball(slotId){
    const a=this.e.pieceAt[slotId];

    return this.e.pieces[a];
  }

  nodePosition(slotId){

    const s=this.e.slots[slotId];

    if(!this.anim){

      return{
        x:this.px(s.x),
        y:this.py(s.y),
        color:this.ball(slotId)
      };
    }

    const an=this.anim;
    const ring=this.e.rings[an.r];
    const i=this.e.ringPositions[an.r][slotId];

    if(i<0){

      return{
        x:this.px(s.x),
        y:this.py(s.y),
        color:this.ball(slotId)
      };
    }

    const n=ring.nodeIds.length;

    let srcIndex=i-an.step;

    srcIndex=((srcIndex%n)+n)%n;

    const srcSlot=ring.nodeIds[srcIndex];

    const piece=this.e.pieceAt[srcSlot];

    const source=this.e.slots[srcSlot];

    const sourceAngle=Math.atan2(
      source.y-ring.center.y,
      source.x-ring.center.x
    );

    const targetAngle=Math.atan2(
      s.y-ring.center.y,
      s.x-ring.center.x
    );

    const totalAngle=an.from;

    let travel=totalAngle;

    const shortest=this.norm(
      targetAngle-
      (sourceAngle+totalAngle)
    );

    travel+=shortest;

    const angle=
      sourceAngle+
      travel*
      an.progress;

    return{
      x:
        this.px(ring.center.x)+
        this.rad(ring.radius)*
        Math.cos(angle),

      y:
        this.py(ring.center.y)+
        this.rad(ring.radius)*
        Math.sin(angle),

      color:this.e.pieces[piece]
    };
  }

  draw(){

    const x=this.x;

    x.clearRect(
      0,
      0,
      this.w,
      this.h
    );

    x.save();

    x.globalCompositeOperation='lighter';

    const glow=x.createRadialGradient(
      this.w/2,
      this.h/2,
      0,
      this.w/2,
      this.h/2,
      this.scaleV*.55
    );

    glow.addColorStop(
      0,
      'rgba(70,82,180,.10)'
    );

    glow.addColorStop(
      1,
      'rgba(0,0,0,0)'
    );

    x.fillStyle=glow;

    x.fillRect(
      0,
      0,
      this.w,
      this.h
    );

    x.restore();

    for(
      let i=0;
      i<this.e.rings.length;
      i++
    ){

      const r=this.e.rings[i];

      const active=
        i===this.active||
        i===this.hover||
        (this.anim&&i===this.anim.r);

      x.beginPath();

      x.arc(
        this.px(r.center.x),
        this.py(r.center.y),
        this.rad(r.radius),
        0,
        Math.PI*2
      );

      x.strokeStyle=
        active
          ? 'rgba(143,153,255,.9)'
          : 'rgba(139,148,174,.30)';

      x.lineWidth=
        active
          ? 2.5
          : 1.25;

      x.shadowColor=
        active
          ? 'rgba(99,102,241,.8)'
          : 'transparent';

      x.shadowBlur=
        active
          ? 14
          : 0;

      x.stroke();

      x.shadowBlur=0;
    }

    const rr=Math.max(
      6.5,
      Math.min(
        11,
        this.w*.016
      )
    );

    for(const s of this.e.slots){

      const p=this.nodePosition(s.id);

      const d=COLORS[p.color];

      if(!d)continue;

      x.beginPath();

      x.arc(
        p.x,
        p.y,
        rr+4,
        0,
        Math.PI*2
      );

      x.fillStyle=d.hex+'20';

      x.fill();

      const g=x.createRadialGradient(
        p.x-rr*.38,
        p.y-rr*.4,
        rr*.05,
        p.x,
        p.y,
        rr
      );

      g.addColorStop(
        0,
        '#fff'
      );

      g.addColorStop(
        .22,
        '#fff'
      );

      g.addColorStop(
        .4,
        d.hex
      );

      g.addColorStop(
        1,
        d.dark
      );

      x.beginPath();

      x.arc(
        p.x,
        p.y,
        rr,
        0,
        Math.PI*2
      );

      x.fillStyle=g;

      x.fill();

      x.strokeStyle='#ffffff80';
      x.lineWidth=1;

      x.stroke();
    }
  }
}

let stepSolution=[];
let stepIndex=0;
let stepSolverOpen=false;
let stepApplying=false;

function directionSymbol(step){return step>0?'↻':'↺';}
function stepLabel(move){return `C${move.circle} O${move.orbit} ${directionSymbol(move.step)} *${Math.abs(move.step)}`;}
function buildStepSolution(){
  return engine.solution.map(move=>({
    ring:move.ring,
    orbit:engine.rings[move.ring].orbitIndex,
    circle:engine.rings[move.ring].circleIndex,
    step:move.step
  }));
}
function renderStepList(){
  const list=stepListElement,progress=stepProgressElement,next=nextStepElement;
  if(!list||!progress||!next)return;
  if(!stepSolution.length){
    list.innerHTML='<div class="step-empty">No scramble moves are available. Scramble the puzzle first.</div>';
    list.classList.add('show');progress.textContent='';next.style.display='none';return;
  }
  list.innerHTML=stepSolution.map((move,i)=>`<div class="step-row ${i===stepIndex?'active':''} ${i<stepIndex?'done':''}"><span class="step-no">${String(i+1).padStart(2,'0')}</span><span class="step-code">${stepLabel(move)}</span></div>`).join('');
  list.classList.add('show');
  progress.textContent=stepIndex<stepSolution.length?`Step ${stepIndex+1} of ${stepSolution.length}`:`Solved · ${stepSolution.length} steps`;
  next.style.display=stepIndex<stepSolution.length?'inline-block':'none';
  list.scrollTop=Math.max(0,(stepIndex-2)*35);
}
function openStepSolver(){
  if(renderer.anim||renderer.autoSolving)return;
  stepSolverOpen=true;
  stepSolution=buildStepSolution();
  stepIndex=0;
  renderStepList();
}
function refreshStepSolverFromCurrentState(){
  if(!stepSolverOpen||stepApplying)return;
  stepSolution=buildStepSolution();
  stepIndex=0;

  if(engine.solved){
    const list=stepListElement;
    if(!list||!stepProgressElement||!nextStepElement)return;
    list.innerHTML='<div class="step-success">✓ Puzzle solved — all steps completed.</div>';
    list.classList.add('show');
    stepProgressElement.textContent='Solved';
    nextStepElement.style.display='none';
  }else{
    renderStepList();
  }
}

function doNextStep(){
  if(renderer.anim||renderer.autoSolving||!engine.solution.length)return;
  const move={...engine.solution[0]};
  stepApplying=true;
  renderer.snap(move.ring,move.step,move.step*(Math.PI*2/engine.rings[move.ring].nodeIds.length),()=>{
    stepApplying=false;
    engine.consumeSolutionMove(move.ring,move.step);
    stepSolution=buildStepSolution();
    stepIndex=0;
    refreshStepSolverFromCurrentState();
    ui();
  },true,false);
}
const solveByStepButton=document.getElementById('solveByStep');
const nextStepButton=document.getElementById('nextStep');

if(solveByStepButton)solveByStepButton.onclick=()=>{openStepSolver();};
if(nextStepButton)nextStepButton.onclick=()=>{doNextStep();};

function uiTime(){

  const t=
    engine.start
      ? Math.floor(
          (Date.now()-engine.start)/1000
        )
      : 0;

  if(!timeElement)return;

  timeElement.textContent=
    String(
      Math.floor(t/60)
    ).padStart(2,'0')+
    ':'+
    String(
      t%60
    ).padStart(2,'0');
}

function ui(){

  if(movesElement)movesElement.textContent=engine.moves;

  uiTime();

  renderer.draw();

  if(
    engine.solved&&
    engine.moves&&
    !renderer.autoSolving&&
    winElement
  ){

    if(!resultElement)return;

    resultElement.textContent=
      `${engine.moves} moves · ${timeElement.textContent}`;

    winElement.classList.add('show');
  }
}

const engine=new Engine();

const renderer=new Renderer(
  document.getElementById('puzzle'),
  engine
);

if(expertMode&&engine.resumeTimer&&!engine.solved&&!engine.timer){
  engine.startTimer();
}

renderer.onStateChanged=ui;

const circleControlsElement=document.getElementById('circleControls');
if(circleControlsElement)circleControlsElement.addEventListener('click',event=>{
  const button=event.target.closest('button[data-ring][data-step]');
  if(!button||renderer.anim||renderer.autoSolving)return;

  const ringIndex=Number(button.dataset.ring);
  const step=Number(button.dataset.step);
  const ring=engine.rings[ringIndex];
  if(!ring||![-1,1].includes(step))return;

  renderer.snap(
    ringIndex,
    step,
    step*(Math.PI*2/ring.nodeIds.length),
    null,
    true,
    true
  );
});

const scrambleButton=document.getElementById('scramble');
if(scrambleButton)scrambleButton.onclick=()=>{

  if(
    renderer.anim||
    renderer.autoSolving
  )return;

  document.getElementById(
    'win'
  ).classList.remove('show');

  engine.scramble(24);

  stepSolverOpen=false;
  stepSolution=[];
  stepIndex=0;

  document.getElementById(
    'time'
  ).textContent='00:00';

  ui();
};

const resetButton=document.getElementById('reset');
if(resetButton)resetButton.onclick=()=>{

  if(
    renderer.anim||
    renderer.autoSolving
  )return;

  engine.reset();

  stepSolverOpen=false;
  stepSolution=[];
  stepIndex=0;
  document.getElementById('stepList').classList.remove('show');
  document.getElementById('stepProgress').textContent='';
  document.getElementById('nextStep').style.display='none';

  document.getElementById(
    'time'
  ).textContent='00:00';

  document.getElementById(
    'win'
  ).classList.remove('show');

  ui();
};

const autoSolveButton=document.getElementById('autoSolve');
if(autoSolveButton)autoSolveButton.onclick=()=>{

  if(
    renderer.anim||
    renderer.autoSolving||
    engine.solved
  )return;

  document.getElementById(
    'win'
  ).classList.remove('show');

  engine.stop();

  engine.autoSolve(renderer);
};

const againButton=document.getElementById('again');
if(againButton)againButton.onclick=()=>{

  if(
    renderer.anim||
    renderer.autoSolving
  )return;

  document.getElementById(
    'win'
  ).classList.remove('show');

  engine.scramble(24);

  stepSolverOpen=false;
  stepSolution=[];
  stepIndex=0;

  document.getElementById(
    'time'
  ).textContent='00:00';

  ui();
};

ui();

if(expertMode){
  window.addEventListener('beforeunload',()=>persistExpertGame(engine));
  document.addEventListener('visibilitychange',()=>{
    if(document.visibilityState==='hidden')persistExpertGame(engine);
  });
}
  
  