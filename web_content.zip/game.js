import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87c9ef);
scene.fog = new THREE.Fog(0x87c9ef, 35, 180);
const camera = new THREE.PerspectiveCamera(65, innerWidth/innerHeight, 0.1, 300);
camera.position.set(0, 5.2, 10.5);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.querySelector('#game').prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xdaf4ff,0x52603a,2.0));
const sun = new THREE.DirectionalLight(0xffffff,2.2);
sun.position.set(-12,20,8); sun.castShadow=true; sun.shadow.mapSize.set(2048,2048);
scene.add(sun);

const mat=(color,roughness=.8)=>new THREE.MeshStandardMaterial({color,roughness});
const roadMat=mat(0x30343b), grassMat=mat(0x398347), lineMat=mat(0xf4f2df);
const road = new THREE.Mesh(new THREE.PlaneGeometry(13,260),roadMat);
road.rotation.x=-Math.PI/2; road.position.z=-85; road.receiveShadow=true; scene.add(road);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(240,300),grassMat);
ground.rotation.x=-Math.PI/2; ground.position.set(0,-.08,-85); ground.receiveShadow=true; scene.add(ground);
for (const x of [-6.35,6.35]) {
 const edge=new THREE.Mesh(new THREE.BoxGeometry(.16,.035,260),mat(0xffffff));
 edge.position.set(x,.025,-85); scene.add(edge);
}
const dashes=[];
for(let z=8;z>-250;z-=12){
 const dash=new THREE.Mesh(new THREE.BoxGeometry(.16,.035,5),lineMat);
 dash.position.set(0,.03,z); scene.add(dash); dashes.push(dash);
}
const scenery=[];
function tree(x,z){
 const g=new THREE.Group();
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.16,.23,1.6,7),mat(0x76502e)); trunk.position.y=.8; trunk.castShadow=true;g.add(trunk);
 const crown=new THREE.Mesh(new THREE.ConeGeometry(1.05,2.8,8),mat(0x176b39)); crown.position.y=2.65;crown.castShadow=true;g.add(crown);
 g.position.set(x,0,z);scene.add(g);scenery.push(g);
}
function building(x,z){
 const h=3+Math.random()*8,w=2+Math.random()*3;
 const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,2.5),mat([0xc6b7a3,0x9aaabd,0xd3c7b2][Math.floor(Math.random()*3)]));
 b.position.set(x,h/2,z);b.castShadow=true;scene.add(b);scenery.push(b);
}
for(let z=8;z>-260;z-=13){tree(-10-Math.random()*3,z);tree(10+Math.random()*3,z-5);if(Math.random()>.55)building(-17,z-3);if(Math.random()>.55)building(17,z-8);}

const bike=new THREE.Group();
const black=mat(0x171b20), red=mat(0xe52c35), metal=mat(0xbfc8ce,.35), rubber=mat(0x08090b);
function box(parent,w,h,d,m,x,y,z){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;parent.add(o);return o;}
function wheel(z){
 const tire=new THREE.Mesh(new THREE.TorusGeometry(.48,.14,10,22),rubber);
 tire.rotation.y=Math.PI/2;tire.position.set(0,.55,z);tire.castShadow=true;bike.add(tire);
 const hub=new THREE.Mesh(new THREE.CylinderGeometry(.2,.2,.18,16),metal);
 hub.rotation.z=Math.PI/2;hub.position.set(0,.55,z);bike.add(hub);
}
wheel(.95);wheel(-1.05);
box(bike,.48,.38,1.35,red,0,1.15,0);
box(bike,.52,.22,.65,black,0,1.43,-.1);
const tank=new THREE.Mesh(new THREE.SphereGeometry(.43,16,12),red);tank.scale.set(1,.7,1.15);tank.position.set(0,1.48,.25);tank.castShadow=true;bike.add(tank);
box(bike,.12,.7,.12,metal,0,1.1,.85);
const handle=box(bike,1.25,.09,.1,black,0,1.82,.8);
box(bike,.42,.12,.48,black,0,1.65,-.6);
const riderHead=new THREE.Mesh(new THREE.SphereGeometry(.27,16,12),mat(0x202b39));riderHead.position.set(0,2.1,-.18);bike.add(riderHead);
const riderBody=new THREE.Mesh(new THREE.CapsuleGeometry(.23,.55,5,8),mat(0x245b91));riderBody.position.set(0,1.78,-.2);riderBody.rotation.x=-.35;bike.add(riderBody);
bike.position.set(0,0,4);scene.add(bike);

const obstacles=[];
function spawnObstacle(z){
 const x=[-4,0,4][Math.floor(Math.random()*3)];
 const car=new THREE.Group();
 box(car,1.55,.65,2.4,mat([0xf2b632,0x2582d5,0xe64b3e][Math.floor(Math.random()*3)]),0,.75,0);
 box(car,1.2,.55,1.05,mat(0x9ed9ee),0,1.3,-.15);
 for(const wz of [-.75,.75])for(const wx of [-.78,.78]){
  const wh=new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,.15,12),rubber);wh.rotation.z=Math.PI/2;wh.position.set(wx,.32,wz);car.add(wh);
 }
 car.position.set(x,0,z);scene.add(car);obstacles.push(car);
}
for(let i=0;i<8;i++)spawnObstacle(-35-i*28);

let speed=0,gear=0,distance=0,steer=0,started=false,paused=false,gameOver=false;
const $=id=>document.getElementById(id);
function updateHUD(){ $('speed').textContent=Math.round(speed);$('gear').textContent=gear===0?'N':gear;$('distance').textContent=Math.floor(distance); }
function reset(){
 speed=0;gear=0;distance=0;steer=0;started=true;paused=false;gameOver=false;
 bike.position.x=0;bike.rotation.z=0;
 $('message').style.display='none';$('pauseTag').style.display='none';
 obstacles.forEach((o,i)=>o.position.set([-4,0,4][Math.floor(Math.random()*3)],0,-35-i*28));
 updateHUD();
}
$('startBtn').addEventListener('click',reset);
$('gearBtn').addEventListener('click',()=>{if(!started)return;gear=gear>=5?0:gear+1;updateHUD();});
function gas(){if(started&&!paused&&!gameOver&&gear>0)speed=Math.min(gear*24,speed+1.3);}
function brake(){if(started&&!paused)speed=Math.max(0,speed-3.2);}
function steerBy(v){if(started&&!paused){steer=Math.max(-1,Math.min(1,steer+v));}}
$('gasBtn').addEventListener('pointerdown',e=>{e.preventDefault();gas();});
$('brakeBtn').addEventListener('pointerdown',e=>{e.preventDefault();brake();});
$('leftBtn').addEventListener('pointerdown',e=>{e.preventDefault();steerBy(-.32);});
$('rightBtn').addEventListener('pointerdown',e=>{e.preventDefault();steerBy(.32);});
$('pauseBtn').addEventListener('click',()=>{if(!started)return;paused=!paused;$('pauseTag').style.display=paused?'block':'none';});
addEventListener('keydown',e=>{if(e.key==='ArrowUp')gas();if(e.key==='ArrowDown')brake();if(e.key==='ArrowLeft')steerBy(-.22);if(e.key==='ArrowRight')steerBy(.22);if(e.code==='Space'){gear=gear>=5?0:gear+1;updateHUD();}if(e.key.toLowerCase()==='p')$('pauseBtn').click();});
addEventListener('keyup',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight')steer=0;});
function endGame(){gameOver=true;speed=0;$('message').style.display='flex';$('message').querySelector('h1').textContent='RIDE OVER';$('message').querySelector('p').textContent='Distance: '+Math.floor(distance)+' m';$('startBtn').textContent='PLAY AGAIN';}
const clock=new THREE.Clock();
function animate(){
 requestAnimationFrame(animate);
 const dt=Math.min(clock.getDelta(),.04);
 if(started&&!paused&&!gameOver){
  if(speed>0){const move=(speed/3)*dt;distance+=move*2.5;
   dashes.forEach(d=>{d.position.z+=move*3;if(d.position.z>12)d.position.z-=260;});
   scenery.forEach(s=>{s.position.z+=move*3;if(s.position.z>15)s.position.z-=270;});
   obstacles.forEach(o=>{o.position.z+=move*3;if(o.position.z>10){o.position.z=-210-Math.random()*45;o.position.x=[-4,0,4][Math.floor(Math.random()*3)];}});
  }
  bike.position.x+=((steer*4.2)-bike.position.x)*Math.min(1,dt*5);
  bike.position.x=Math.max(-4.5,Math.min(4.5,bike.position.x));
  bike.rotation.z+=( -steer*.16-bike.rotation.z)*dt*5;
  camera.position.x+=(bike.position.x*.28-camera.position.x)*dt*2;
  camera.lookAt(bike.position.x*.25,1,-8);
  for(const o of obstacles){if(Math.abs(o.position.z-bike.position.z)<1.8&&Math.abs(o.position.x-bike.position.x)<1.45){endGame();break;}}
  updateHUD();
 }
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
