const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
let W, H;
function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }
resize();
window.addEventListener('resize', resize);
const launcher = document.getElementById('launcher');
const gameScreen = document.getElementById('gameScreen');
const gameOverEl = document.getElementById('gameOver');
let cube, enemies, bullets, score, level, gameOver, spawnTimer, paused, running;
const keys = {};
function init() {
  cube = { x: W/2 - 20, y: H - 120, size: 40, speed: 6 };
  enemies = []; bullets = [];
  score = 0; level = 1; gameOver = false; paused = false; running = true; spawnTimer = 0;
  document.getElementById('score').textContent = '0';
  document.getElementById('level').textContent = '1';
}
window.addEventListener('keydown', e => keys[e.key] = true);
window.addEventListener('keyup', e => keys[e.key] = false);
window.addEventListener('keydown', e => { if (e.code === 'Space') shoot(); });
function spawnEnemy() {
  enemies.push({ x: Math.random() * (W - 40), y: -40, size: 30 + Math.random() * 20, speed: (1.5 + Math.random() * 2) * (1 + level * 0.15) });
}
function shoot() { if (!running || paused) return; bullets.push({ x: cube.x + cube.size/2 - 3, y: cube.y, size: 6, speed: 12 }); }
function update() {
  if (!running || paused || gameOver) return;
  if (keys['ArrowUp'] || keys['w']) cube.y -= cube.speed;
  if (keys['ArrowDown'] || keys['s']) cube.y += cube.speed;
  if (keys['ArrowLeft'] || keys['a']) cube.x -= cube.speed;
  if (keys['ArrowRight'] || keys['d']) cube.x += cube.speed;
  cube.x = Math.max(0, Math.min(W - cube.size, cube.x));
  cube.y = Math.max(0, Math.min(H - cube.size, cube.y));
  for (let i = bullets.length - 1; i >= 0; i--) { bullets[i].y -= bullets[i].speed; if (bullets[i].y < -10) bullets.splice(i, 1); }
  for (let i = enemies.length - 1; i >= 0; i--) {
    const en = enemies[i]; en.y += en.speed;
    if (en.y > H) { enemies.splice(i, 1); triggerGameOver(); continue; }
    if (Math.abs(en.x - cube.x) < cube.size && Math.abs(en.y - cube.y) < cube.size) { triggerGameOver(); return; }
    for (let j = bullets.length - 1; j >= 0; j--) {
      const b = bullets[j];
      if (Math.abs(b.x - en.x) < en.size && Math.abs(b.y - en.y) < en.size) {
        enemies.splice(i, 1); bullets.splice(j, 1); score += 100;
        document.getElementById('score').textContent = score;
        if (score >= level * 1000) { level++; document.getElementById('level').textContent = level; }
        break;
      }
    }
  }
  spawnTimer++;
  if (spawnTimer > Math.max(20, 60 - level * 3)) { spawnEnemy(); spawnTimer = 0; }
}
function draw() {
  ctx.fillStyle = '#000'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#ffffff33';
  for (let i = 0; i < 30; i++) { ctx.fillRect((i*137+performance.now()*0.05)%W, (i*71+performance.now()*0.1)%H, 2, 2); }
  ctx.shadowColor = '#00ffff'; ctx.shadowBlur = 20; ctx.fillStyle = '#00ffff';
  ctx.fillRect(cube.x, cube.y, cube.size, cube.size); ctx.shadowBlur = 0;
  ctx.shadowColor = '#ffff00'; ctx.shadowBlur = 10; ctx.fillStyle = '#ffff00';
  bullets.forEach(b => ctx.fillRect(b.x, b.y, b.size, b.size * 2)); ctx.shadowBlur = 0;
  ctx.shadowColor = '#ff0066'; ctx.shadowBlur = 15; ctx.fillStyle = '#ff0066';
  enemies.forEach(en => ctx.fillRect(en.x, en.y, en.size, en.size)); ctx.shadowBlur = 0;
}
function loop() { update(); draw(); requestAnimationFrame(loop); }
function triggerGameOver() { gameOver = true; running = false; document.getElementById('finalScore').textContent = score; gameOverEl.classList.remove('hidden'); }
function startGame() {
  launcher.classList.add('hidden'); gameScreen.classList.remove('hidden'); gameOverEl.classList.add('hidden');
  init(); loop();
}
document.getElementById('startBtn').onclick = startGame;
document.getElementById('retryBtn').onclick = startGame;
document.getElementById('menuBtn').onclick = () => { gameScreen.classList.add('hidden'); gameOverEl.classList.add('hidden'); launcher.classList.remove('hidden'); running = false; };
document.getElementById('howBtn').onclick = () => alert('Di chuyển: WASD hoặc mũi tên. Bắn: SPACE hoặc FIRE. Kéo aim: chạm và kéo trên nút FIRE.');
document.getElementById('setBtn').onclick = () => alert('Cài đặt sẽ có ở phiên bản sau.');
document.getElementById('shootBtn').addEventListener('touchstart', e => { e.preventDefault(); shoot(); });
document.getElementById('pauseBtn').onclick = () => { paused = !paused; };
document.getElementById('aimBtn').addEventListener('click', () => {
  if (typeof toggleAim === 'function') toggleAim();
  document.getElementById('aimBtn').textContent = 'AIM: ' + (typeof aimActive !== 'undefined' && aimActive ? 'ON' : 'OFF');
  document.getElementById('aimPad').classList.toggle('active', typeof aimActive !== 'undefined' && aimActive);
});