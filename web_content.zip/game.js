function runDeviceBenchmark() {
  const t0 = performance.now();
  let calc = 0;
  for (let i = 0; i < 400000; i++) { calc += Math.sqrt(i) * Math.sin(i); }
  const dt = Math.max(1, performance.now() - t0);
  const cores = navigator.hardwareConcurrency || 4;
  const score = Math.round((cores * 1000) / dt);
  const hostEl = document.getElementById('host-score');
  if (hostEl) hostEl.innerText = score + " PTS";
  return score;
}
const myHostScore = runDeviceBenchmark();

// Low-Latency Web Audio Sound Engine
let audioCtx = null;
function ensureAudioCtx() {
  if (!audioCtx) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (Ctx) audioCtx = new Ctx();
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(function() {});
  }
  return audioCtx;
}

function playSoundEffect(type) {
  const ctx = ensureAudioCtx();
  if (!ctx) return;
  const now = ctx.currentTime;

  if (type === 'deagle') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(48, now + 0.14);
    gain.gain.setValueAtTime(0.24, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.15);
  } else if (type === 'shotgun') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(145, now);
    osc.frequency.exponentialRampToValueAtTime(34, now + 0.22);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.23);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.23);
  } else if (type === 'mp5' || type === 'ump') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type === 'mp5' ? 'triangle' : 'sawtooth';
    const startF = type === 'mp5' ? 320 : 270;
    osc.frequency.setValueAtTime(startF, now);
    osc.frequency.exponentialRampToValueAtTime(72, now + 0.09);
    gain.gain.setValueAtTime(0.16, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.095);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.095);
  } else if (type === 'rifle') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(250, now);
    osc.frequency.exponentialRampToValueAtTime(58, now + 0.12);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.125);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.125);
  } else if (type === 'glue') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.exponentialRampToValueAtTime(520, now + 0.18);
    gain.gain.setValueAtTime(0.22, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.19);
  } else if (type === 'hit') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(780, now);
    osc.frequency.exponentialRampToValueAtTime(420, now + 0.06);
    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.065);
  } else if (type === 'jump') {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(160, now);
    osc.frequency.exponentialRampToValueAtTime(300, now + 0.1);
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
    osc.connect(gain); gain.connect(ctx.destination);
    osc.start(now); osc.stop(now + 0.11);
  }
}

// Weapons Catalog: DEAGLE, SHOTGUN, MP5, UMP, RIFLE
const weaponsCatalog = {
  DEAGLE:  { key: 'DEAGLE',  sound: 'deagle',  ammo: 7,  maxAmmo: 7,  damage: 58, pellets: 1, speed: 3.0 },
  SHOTGUN: { key: 'SHOTGUN', sound: 'shotgun', ammo: 8,  maxAmmo: 8,  damage: 26, pellets: 4, speed: 2.4 },
  MP5:     { key: 'MP5',     sound: 'mp5',     ammo: 30, maxAmmo: 30, damage: 24, pellets: 1, speed: 2.7 },
  UMP:     { key: 'UMP',     sound: 'ump',     ammo: 25, maxAmmo: 25, damage: 29, pellets: 1, speed: 2.65 },
  RIFLE:   { key: 'RIFLE',   sound: 'rifle',   ammo: 30, maxAmmo: 30, damage: 35, pellets: 1, speed: 2.8 }
};

const weaponOrder = ['DEAGLE', 'SHOTGUN', 'MP5', 'UMP', 'RIFLE'];

const gunSlots = {
  1: Object.assign({}, weaponsCatalog.DEAGLE),
  2: Object.assign({}, weaponsCatalog.SHOTGUN)
};
let activeSlot = 1;
let glueWallsLeft = 5;
let hp = 100, medkits = 3, kills = 0, gameEnded = false, loopRunning = false;

// Active Gloo Walls in World
const activeGlooWalls = [];

function spawnGlooWallAt(x, y, z, rotY) {
  if (typeof createGlooWallMesh !== 'function') return;
  const mesh = createGlooWallMesh();
  mesh.position.set(x, y, z);
  mesh.rotation.y = rotY;
  scene.add(mesh);

  const colliderObj = {
    x: x,
    z: z,
    hw: 2.05,
    hd: 0.75,
    isGlue: true
  };
  colliders.push(colliderObj);

  activeGlooWalls.push({
    mesh: mesh,
    collider: colliderObj,
    hp: 160,
    life: 24
  });
}

function deployPlayerGlooWall() {
  if (gameEnded || !player || glueWallsLeft <= 0) return;
  glueWallsLeft--;
  const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), player.rotation.y);
  const gx = player.position.x + forward.x * 3.1;
  const gz = player.position.z + forward.z * 3.1;
  spawnGlooWallAt(gx, Math.max(0, player.position.y), gz, player.rotation.y);
  playSoundEffect('glue');
  updateHUD();
}

// Player & Pro Bots
const player = createSmoothCharacter({
  gender: 'male',
  topColor: 0x00a8ff,
  bottomColor: 0x1e272e,
  hairColor: 0x161311
});
scene.add(player);

// Ground Guns (DEAGLE, SHOTGUN, MP5, UMP, RIFLE)
const groundGuns = [];
const groundGunColors = {
  DEAGLE: 0xffd54f,
  SHOTGUN: 0xff5252,
  MP5: 0x40c4ff,
  UMP: 0x69f0ae,
  RIFLE: 0xffab40
};

function createGroundGunMesh(weaponKey) {
  const g = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({
    color: groundGunColors[weaponKey] || 0xffffff,
    metalness: 0.6,
    roughness: 0.3
  });
  const barrel = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.2, weaponKey === 'SHOTGUN' ? 1.25 : 0.95), mat);
  barrel.position.set(0, 0.15, 0);
  barrel.castShadow = true;
  const grip = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.28, 0.2), mat);
  grip.position.set(0, 0.05, -0.2);
  g.add(barrel, grip);
  g.rotation.y = Math.random() * Math.PI * 2;
  g.userData = { weaponKey: weaponKey };
  return g;
}

for (let i = 0; i < 16; i++) {
  const wKey = weaponOrder[i % weaponOrder.length];
  const gg = createGroundGunMesh(wKey);
  gg.position.set((Math.random() - 0.5) * 165, 0.05, (Math.random() - 0.5) * 165);
  scene.add(gg);
  groundGuns.push(gg);
}

const botProfiles = [
  { gender: 'male', topColor: 0xe53935, bottomColor: 0x263238, hairColor: 0x1a1512 },
  { gender: 'female', topColor: 0xec407a, bottomColor: 0x212121, hairColor: 0x2b1810 },
  { gender: 'male', topColor: 0xff9800, bottomColor: 0x37474f, hairColor: 0x111111 },
  { gender: 'female', topColor: 0xab47bc, bottomColor: 0x1c2541, hairColor: 0x181412 },
  { gender: 'male', topColor: 0x2ecc71, bottomColor: 0x212121, hairColor: 0x3b2314 },
  { gender: 'female', topColor: 0x00bcd4, bottomColor: 0x263238, hairColor: 0x14110f },
  { gender: 'male', topColor: 0xf5f7fa, bottomColor: 0x263238, hairColor: 0x1a1512 },
  { gender: 'female', topColor: 0xffd54f, bottomColor: 0x212121, hairColor: 0x23160f }
];

const enemies = [];
for (let i = 0; i < 10; i++) {
  const prof = botProfiles[i % botProfiles.length];
  const bot = createSmoothCharacter(prof);
  bot.position.set((Math.random() - 0.5) * 160, 0, (Math.random() - 0.5) * 160);
  bot.userData.hp = 100;
  bot.userData.dir = Math.random() * Math.PI * 2;
  bot.userData.strafeDir = i % 2 === 0 ? 1 : -1;
  bot.userData.strafeTimer = 1.2 + Math.random() * 1.5;
  bot.userData.shootTimer = 0.8 + Math.random() * 1.2;
  bot.userData.glueCooldown = 3 + Math.random() * 3;
  bot.userData.weaponKey = weaponOrder[i % weaponOrder.length];
  scene.add(bot);
  enemies.push(bot);
}

const bullets = [];
const bulletGeo = new THREE.SphereGeometry(0.15, 6, 6);
const bulletMat = new THREE.MeshBasicMaterial({ color: 0xffe600 });

function selectGunSlot(slot) {
  if (!gunSlots[slot]) return;
  activeSlot = slot;
  const g1 = document.getElementById('btn-gun1');
  const g2 = document.getElementById('btn-gun2');
  if (g1) g1.classList.toggle('active-gun', slot === 1);
  if (g2) g2.classList.toggle('active-gun', slot === 2);
  updateHUD();
}

function equipWeaponToSlot(slot, weaponKey) {
  const tpl = weaponsCatalog[weaponKey];
  if (!tpl) return;
  gunSlots[slot] = Object.assign({}, tpl);
  activeSlot = slot;
  selectGunSlot(slot);
}

function cycleActiveSlotGun() {
  const curKey = gunSlots[activeSlot].key;
  const idx = weaponOrder.indexOf(curKey);
  const nextKey = weaponOrder[(idx + 1) % weaponOrder.length];
  equipWeaponToSlot(activeSlot, nextKey);
}

function reloadGun() {
  const g = gunSlots[activeSlot];
  if (!g) return;
  g.ammo = g.maxAmmo;
  updateHUD();
}

function useMedkit() {
  if (medkits > 0 && hp < 100) {
    medkits--;
    hp = Math.min(100, hp + 45);
    updateHUD();
  }
}

function isBulletBlockedByGlooOrWall(pos) {
  for (let i = activeGlooWalls.length - 1; i >= 0; i--) {
    const gw = activeGlooWalls[i];
    const c = gw.collider;
    if (Math.abs(pos.x - c.x) < c.hw && Math.abs(pos.z - c.z) < c.hd && pos.y < 2.8) {
      gw.hp -= 24;
      if (gw.hp <= 0) {
        scene.remove(gw.mesh);
        const idx = colliders.indexOf(c);
        if (idx !== -1) colliders.splice(idx, 1);
        activeGlooWalls.splice(i, 1);
      }
      return true;
    }
  }
  return false;
}

function fireBullet(shooter, isPlayer) {
  if (gameEnded || !shooter) return;
  if (isPlayer) {
    const g = gunSlots[activeSlot];
    if (g.ammo <= 0) { reloadGun(); return; }
    g.ammo--;
    if (g.ammo === 0) reloadGun();
    playSoundEffect(g.sound || 'rifle');
    updateHUD();

    const baseYaw = shooter.rotation.y;
    for (let p = 0; p < g.pellets; p++) {
      const spread = g.pellets > 1 ? (p - (g.pellets - 1) / 2) * 0.05 : 0;
      const b = new THREE.Mesh(bulletGeo, bulletMat);
      b.position.copy(shooter.position).add(new THREE.Vector3(0, 1.5, 0));
      const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), baseYaw + spread);
      b.userData = { vel: forward.multiplyScalar(g.speed), isPlayer: true, dmg: g.damage, life: 75 };
      scene.add(b);
      bullets.push(b);
    }
  } else {
    const wKey = (shooter.userData && shooter.userData.weaponKey) || 'MP5';
    const tpl = weaponsCatalog[wKey] || weaponsCatalog.MP5;
    const b = new THREE.Mesh(bulletGeo, bulletMat);
    b.position.copy(shooter.position).add(new THREE.Vector3(0, 1.5, 0));
    const forward = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), shooter.rotation.y);
    b.userData = { vel: forward.multiplyScalar(1.45), isPlayer: false, dmg: 6, life: 75 };
    scene.add(b);
    bullets.push(b);
  }
}

function updateHUD() {
  const g = gunSlots[activeSlot];
  const gunEl = document.getElementById('gun-name');
  const glueEl = document.getElementById('glue-count');
  const hpValEl = document.getElementById('hp-val');
  const hpBarEl = document.getElementById('hp-bar');
  const ammoEl = document.getElementById('ammo-val');
  const killEl = document.getElementById('kill-count');
  const aliveEl = document.getElementById('alive-count');
  const s1El = document.getElementById('slot1-label');
  const s2El = document.getElementById('slot2-label');

  if (gunEl) gunEl.innerText = g.name + ' (MED:' + medkits + ')';
  if (glueEl) glueEl.innerText = glueWallsLeft;
  if (hpValEl) hpValEl.innerText = Math.max(0, Math.round(hp));
  if (hpBarEl) hpBarEl.style.width = Math.max(0, hp) + '%';
  if (ammoEl) ammoEl.innerText = g.ammo + ' / ' + g.maxAmmo;
  if (killEl) killEl.innerText = kills;
  if (aliveEl) aliveEl.innerText = enemies.length + 1;
  if (s1El) s1El.innerText = '1 • ' + gunSlots[1].name;
  if (s2El) s2El.innerText = '2 • ' + gunSlots[2].name;
}

function getStairHeightAt(x, z) {
  let maxH = 0;
  for (let i = 0; i < stairsList.length; i++) {
    const st = stairsList[i];
    if (Math.abs(x - st.x) < st.hw && Math.abs(z - st.z) < st.hd) {
      if (st.topY > maxH) maxH = st.topY;
    }
  }
  return maxH;
}

function showEndScreen(titleText) {
  gameEnded = true;
  if (document.pointerLockElement && document.exitPointerLock) {
    try { document.exitPointerLock(); } catch (e) {}
  }
  const tEl = document.getElementById('end-title');
  const sEl = document.getElementById('end-stats');
  const scrEl = document.getElementById('end-screen');
  if (tEl) tEl.innerText = titleText;
  if (sEl) sEl.innerText = 'KILLS: ' + kills;
  if (scrEl) scrEl.style.display = 'flex';
}

const restartBtn = document.getElementById('btn-restart');
if (restartBtn) {
  restartBtn.addEventListener('click', function() {
    location.reload();
  });
}

const clock = new THREE.Clock();

function animate() {
  if (gameEnded) return;
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05);

  // Update Gloo Wall timers
  for (let i = activeGlooWalls.length - 1; i >= 0; i--) {
    const gw = activeGlooWalls[i];
    gw.life -= dt;
    if (gw.life <= 0) {
      scene.remove(gw.mesh);
      const idx = colliders.indexOf(gw.collider);
      if (idx !== -1) colliders.splice(idx, 1);
      activeGlooWalls.splice(i, 1);
    }
  }

  let moveForward = (keys['KeyW'] || keys['ArrowUp'] ? 1 : 0) - (keys['KeyS'] || keys['ArrowDown'] ? 1 : 0) - joyZ;
  let moveRight = (keys['KeyD'] || keys['ArrowRight'] ? 1 : 0) - (keys['KeyA'] || keys['ArrowLeft'] ? 1 : 0) + joyX;

  const speed = (isRunning ? 15 : 9.5) * dt;
  player.rotation.y = yaw;

  const isMoving = Math.abs(moveForward) > 0.05 || Math.abs(moveRight) > 0.05;
  if (isMoving) {
    const angle = yaw + Math.atan2(-moveRight, moveForward);
    const nextX = player.position.x + Math.sin(angle) * speed;
    const nextZ = player.position.z + Math.cos(angle) * speed;

    const stairH = getStairHeightAt(nextX, nextZ);

    let blocked = false;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (Math.abs(nextX - c.x) < c.hw && Math.abs(nextZ - c.z) < c.hd) {
        blocked = true;
        break;
      }
    }

    if (!blocked || stairH > 0) {
      player.position.x = Math.max(-160, Math.min(160, nextX));
      player.position.z = Math.max(-160, Math.min(160, nextZ));
    }
  }

  const groundTargetY = Math.max(0, getStairHeightAt(player.position.x, player.position.z));
  const wasAirborne = !onGround || player.position.y > groundTargetY + 0.02;

  player.position.y += velY;
  if (player.position.y > groundTargetY) {
    velY -= 0.017;
    onGround = false;
  } else {
    if (wasAirborne && velY < -0.05 && player.userData) {
      player.userData.landSquash = Math.min(1, Math.abs(velY) * 2.8);
    }
    player.position.y = groundTargetY;
    velY = 0;
    onGround = true;
  }

  const isAirborne = !onGround || player.position.y > groundTargetY + 0.02;
  animateLimbs(player, isMoving, dt, isAirborne);

  const camDist = isScoped ? 2.2 : 6.25;
  const camOffset = new THREE.Vector3(-0.75, 2.5 + pitch * 2.1, -camDist).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);
  camera.position.copy(player.position).add(camOffset);
  const lookTarget = player.position.clone().add(new THREE.Vector3(0, 1.65, 15).applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw));
  lookTarget.y -= pitch * 5;
  camera.lookAt(lookTarget);

  if (zoneRadius > 20) {
    zoneRadius -= dt * 0.5;
    zoneMesh.scale.set(zoneRadius, 1, zoneRadius);
    const zEl = document.getElementById('zone-radius');
    if (zEl) zEl.innerText = Math.round(zoneRadius) + 'm';
  }
  if (Math.hypot(player.position.x, player.position.z) > zoneRadius) {
    hp -= dt * 4;
    updateHUD();
  }

  // Pick up ground guns into current or alternate slot + refill glue
  for (let i = groundGuns.length - 1; i >= 0; i--) {
    groundGuns[i].rotation.y += dt * 1.2;
    if (player.position.distanceTo(groundGuns[i].position) < 2.4) {
      const wKey = groundGuns[i].userData.weaponKey;
      equipWeaponToSlot(activeSlot, wKey);
      glueWallsLeft = Math.min(8, glueWallsLeft + 1);
      scene.remove(groundGuns[i]);
      groundGuns.splice(i, 1);
      updateHUD();
    }
  }

  for (let i = loots.length - 1; i >= 0; i--) {
    loots[i].rotation.y += dt * 2.2;
    if (player.position.distanceTo(loots[i].position) < 2.3) {
      hp = Math.min(100, hp + 35);
      medkits = Math.min(5, medkits + 1);
      glueWallsLeft = Math.min(8, glueWallsLeft + 2);
      reloadGun();
      scene.remove(loots[i]);
      loots.splice(i, 1);
      updateHUD();
    }
  }

  // Pro Bot AI: Strafe, Tactical Gloo Wall Cover & Aimed Firing
  for (let i = enemies.length - 1; i >= 0; i--) {
    const bot = enemies[i];
    const u = bot.userData;
    const dx = player.position.x - bot.position.x;
    const dz = player.position.z - bot.position.z;
    const distToPlayer = Math.hypot(dx, dz);

    u.glueCooldown = Math.max(0, u.glueCooldown - dt);
    u.strafeTimer -= dt;
    if (u.strafeTimer <= 0) {
      u.strafeDir *= -1;
      u.strafeTimer = 1.1 + Math.random() * 1.4;
    }

    if (distToPlayer < 46) {
      bot.lookAt(player.position.x, bot.position.y, player.position.z);

      // Pro bot deploys Gloo Wall when under pressure or mid-range
      if ((u.hp < 65 || distToPlayer < 18) && u.glueCooldown <= 0 && activeGlooWalls.length < 18) {
        const fwd = new THREE.Vector3(0, 0, 1).applyAxisAngle(new THREE.Vector3(0, 1, 0), bot.rotation.y);
        spawnGlooWallAt(bot.position.x + fwd.x * 2.8, 0, bot.position.z + fwd.z * 2.8, bot.rotation.y);
        u.glueCooldown = 6.5;
      }

      // Tactical side-strafe movement
      const rightVecX = Math.cos(bot.rotation.y) * u.strafeDir;
      const rightVecZ = -Math.sin(bot.rotation.y) * u.strafeDir;
      const advance = distToPlayer > 22 ? 0.55 : -0.25;
      const fwdX = Math.sin(bot.rotation.y) * advance;
      const fwdZ = Math.cos(bot.rotation.y) * advance;

      const bx = bot.position.x + (rightVecX + fwdX) * 5.2 * dt;
      const bz = bot.position.z + (rightVecZ + fwdZ) * 5.2 * dt;
      bot.position.x = Math.max(-155, Math.min(155, bx));
      bot.position.z = Math.max(-155, Math.min(155, bz));

      u.shootTimer -= dt;
      if (u.shootTimer <= 0) {
        fireBullet(bot, false);
        u.shootTimer = 1.15 + Math.random() * 0.85;
      }
    } else {
      bot.rotation.y = u.dir;
      bot.position.x += Math.sin(u.dir) * 4.8 * dt;
      bot.position.z += Math.cos(u.dir) * 4.8 * dt;
      if (Math.random() < 0.015) u.dir = Math.random() * Math.PI * 2;
    }
    animateLimbs(bot, true, dt, false);
  }

  for (let i = bullets.length - 1; i >= 0; i--) {
    const b = bullets[i];
    b.position.add(b.userData.vel);
    b.userData.life--;

    if (isBulletBlockedByGlooOrWall(b.position)) {
      b.userData.life = 0;
    }

    if (b.userData.life > 0) {
      if (b.userData.isPlayer) {
        for (let j = enemies.length - 1; j >= 0; j--) {
          if (b.position.distanceTo(enemies[j].position.clone().add(new THREE.Vector3(0, 1.3, 0))) < 1.15) {
            enemies[j].userData.hp -= b.userData.dmg;
            playSoundEffect('hit');
            b.userData.life = 0;
            if (enemies[j].userData.hp <= 0) {
              scene.remove(enemies[j]);
              enemies.splice(j, 1);
              kills++;
              updateHUD();
            }
            break;
          }
        }
      } else if (b.position.distanceTo(player.position.clone().add(new THREE.Vector3(0, 1.3, 0))) < 1.05) {
        hp -= b.userData.dmg;
        b.userData.life = 0;
        updateHUD();
      }
    }

    if (b.userData.life <= 0) {
      scene.remove(b);
      bullets.splice(i, 1);
    }
  }

  if (hp <= 0) {
    showEndScreen("MATCH OVER");
    return;
  } else if (enemies.length === 0) {
    showEndScreen("BOOYAH! YOU WON");
    return;
  }

  renderer.render(scene, camera);
}

window.startGameLoop = function() {
  if (!loopRunning) {
    loopRunning = true;
    ensureAudioCtx();
    updateHUD();
    animate();
  }
};
