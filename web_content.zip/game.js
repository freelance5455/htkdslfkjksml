var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");

var COLS = 20;
var ROWS = 20;
var CELL = 20;
var FPS = 8;

var snake = [];
var dir = { x: 1, y: 0 };
var nextDir = { x: 1, y: 0 };

var food = { x: 5, y: 5 };

var score = 0;
var best = 0;

var phase = "idle";
var loopTimer = null;

var message = document.getElementById("message");
var messageTitle = document.getElementById("message-title");
var messageText = document.getElementById("message-text");

// Load best score
try {
  best = Number(localStorage.getItem("snakeBest")) || 0;
} catch (error) {
  best = 0;
}

function saveBest() {
  if (score > best) {
    best = score;

    try {
      localStorage.setItem("snakeBest", String(best));
    } catch (error) {
      // Game still works if storage is unavailable.
    }
  }
}

function placeFood() {
  var emptyCells = [];

  for (var y = 0; y < ROWS; y++) {
    for (var x = 0; x < COLS; x++) {
      var occupied = snake.some(function (part) {
        return part.x === x && part.y === y;
      });

      if (!occupied) {
        emptyCells.push({ x: x, y: y });
      }
    }
  }

  if (emptyCells.length === 0) {
    phase = "dead";
    saveBest();
    finishGame("YOU WIN!", "तुमने पूरा ग्रिड भर दिया!");
    return;
  }

  food = emptyCells[
    Math.floor(Math.random() * emptyCells.length)
  ];
}

function init() {
  snake = [
    { x: 10, y: 10 },
    { x: 9, y: 10 },
    { x: 8, y: 10 }
  ];

  dir = { x: 1, y: 0 };
  nextDir = { x: 1, y: 0 };

  score = 0;

  placeFood();
  draw();
}

function start() {
  // Stop any previous game loop.
  if (loopTimer !== null) {
    clearInterval(loopTimer);
    loopTimer = null;
  }

  // IMPORTANT: Reset phase before initializing.
  phase = "idle";

  init();

  if (phase === "dead") {
    return;
  }

  phase = "running";

  message.classList.add("hidden");

  restartButton.textContent = "RESTART";

  draw();

  loopTimer = setInterval(function () {
    tick();
  }, 1000 / FPS);
}

function finishGame(title, text) {
  if (loopTimer !== null) {
    clearInterval(loopTimer);
    loopTimer = null;
  }

  messageTitle.textContent = title;
  messageText.textContent = text;

  restartButton.textContent = "PLAY AGAIN";

  message.classList.remove("hidden");

  draw();
}

function tick() {
  if (phase !== "running") {
    return;
  }

  dir = {
    x: nextDir.x,
    y: nextDir.y
  };

  var head = {
    x: snake[0].x + dir.x,
    y: snake[0].y + dir.y
  };

  // Left-right wall wrapping
  if (head.x < 0) {
    head.x = COLS - 1;
  } else if (head.x >= COLS) {
    head.x = 0;
  }

  // Top-bottom wall wrapping
  if (head.y < 0) {
    head.y = ROWS - 1;
  } else if (head.y >= ROWS) {
    head.y = 0;
  }

  var eating = (
    head.x === food.x &&
    head.y === food.y
  );

  // Check collision with snake's own body.
  var bodyToCheck = eating
    ? snake
    : snake.slice(0, -1);

  var collision = bodyToCheck.some(function (part) {
    return part.x === head.x && part.y === head.y;
  });

  if (collision) {
    phase = "dead";
    saveBest();

    finishGame("GAME OVER", "तुम्हारा स्कोर: " + score);
    return;
  }

  snake.unshift(head);

  if (eating) {
    score++;
    saveBest();

    placeFood();

    if (phase !== "running") {
      draw();
      return;
    }
  } else {
    snake.pop();
  }

  draw();
}

function resizeGame() {
  var topBar = document.getElementById("top-bar");

  var availableWidth = window.innerWidth;
  var availableHeight =
    window.innerHeight - topBar.offsetHeight;

  var boardSize = Math.floor(
    Math.min(availableWidth, availableHeight)
  );

  boardSize = Math.max(COLS, boardSize);

  CELL = Math.floor(boardSize / COLS);

  canvas.width = CELL * COLS;
  canvas.height = CELL * ROWS;

  canvas.style.width = canvas.width + "px";
  canvas.style.height = canvas.height + "px";

  draw();
}

// Resize when screen orientation changes.
window.addEventListener("resize", resizeGame);

window.addEventListener("orientationchange", function () {
  setTimeout(resizeGame, 150);
});

// Initial setup
resizeGame();
init();

messageTitle.textContent = "SNAKE GAME";
messageText.textContent = "खेल शुरू करने के लिए बटन दबाएँ";
restartButton.textContent = "START GAME";

message.classList.remove("hidden");