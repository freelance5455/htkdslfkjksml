/* Attack on Titan fan-made browser prototype. Three.js is loaded from CDN. */
const canvas=document.querySelector('#world');
let scene,camera,renderer,clock,player,ground,selected='eren',started=false;
let yaw=0,pitch=-.12,moveX=0,moveZ=0,keys={},velocity=new THREE.Vector3(),gas=100,health=100,kills=0;
let titans=[],buildings=[],hooks=[],swing=0,attacking=false,lastAttack=0;
let particles=[],speedStreaks=[],hitStopUntil=0,shakeUntil=0,shakeMagnitude=0,slashEffects=[];
let cameraBase=v(),lastPlayerPos=v();
const v=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
function mat(color,roughness=.8,metalness=0){return new THREE.MeshStandardMaterial({color,roughness,metalness})}
function addParticleBurst(position,count=22,color=0x7f332c){for(let i=0;i<count;i++){const mesh=new THREE.Mesh(new THREE.SphereGeometry(.045+Math.random()*.075,5,4),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.95}));mesh.position.copy(position);scene.add(mesh);particles.push({mesh,vel:v((Math.random()-.5)*5,Math.random()*5,(Math.random()-.5)*5),life:.35+Math.random()*.65,maxLife:.9});}}
function triggerHitEffects(position){addParticleBurst(position,28,0x8b332d);addParticleBurst(position,12,0xc9a17a);hitStopUntil=performance.now()+85;shakeUntil=performance.now()+230;shakeMagnitude=.28;const ring=new THREE.Mesh(new THREE.TorusGeometry(.55,.045,6,22),new THREE.MeshBasicMaterial({color:0xffd99a,transparent:true,opacity:.95}));ring.position.copy(position);ring.rotation.x=Math.random()*Math.PI;scene.add(ring);slashEffects.push({mesh:ring,life:.22,maxLife:.22,kind:'ring'});}
function updateEffects(realDt){const now=performance.now();for(let i=particles.length-1;i>=0;i--){const p=particles[i];p.life-=realDt;p.vel.y-=5*realDt;p.mesh.position.addScaledVector(p.vel,realDt);p.mesh.material.opacity=Math.max(0,p.life/p.maxLife);p.mesh.scale.multiplyScalar(1+realDt*.4);if(p.life<=0){scene.remove(p.mesh);p.mesh.geometry.dispose();p.mesh.material.dispose();particles.splice(i,1)}}for(let i=slashEffects.length-1;i>=0;i--){const e=slashEffects[i];e.life-=realDt;const k=1-e.life/e.maxLife;e.mesh.scale.setScalar(1+k*2.8);e.mesh.material.opacity=Math.max(0,e.life/e.maxLife);if(e.life<=0){scene.remove(e.mesh);e.mesh.geometry.dispose();e.mesh.material.dispose();slashEffects.splice(i,1)}}for(let i=speedStreaks.length-1;i>=0;i--){const e=speedStreaks[i];e.life-=realDt;e.line.material.opacity=Math.max(0,e.life/.16);if(e.life<=0){scene.remove(e.line);e.line.geometry.dispose();e.line.material.dispose();speedStreaks.splice(i,1)}}}
function emitSpeedLines(){const dir=velocity.clone();if(dir.length()<9)return;dir.normalize();for(let i=0;i<2;i++){const start=player.position.clone().add(v((Math.random()-.5)*3,Math.random()*2+.3,(Math.random()-.5)*3));const end=start.clone().addScaledVector(dir,-(1.4+Math.random()*2));const line=new THREE.Line(new THREE.BufferGeometry().setFromPoints([start,end]),new THREE.LineBasicMaterial({color:0xeaf7ff,transparent:true,opacity:.72}));scene.add(line);speedStreaks.push({line,life:.13+Math.random()*.06})}}
function box(w,h,d,m,x,y,z){let o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;scene.add(o);return o}
function makeHumanoid(scale=1,skin=0xc99e7c,uniform=0x4a6657){let g=new THREE.Group();const skinM=mat(skin),coat=mat(uniform),dark=mat(0x262d31),leather=mat(0x574332);function part(geo,m,x,y,z){let o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;g.add(o);return o}
 part(new THREE.BoxGeometry(.55,.7,.32),coat,0,1.42,0);part(new THREE.SphereGeometry(.22,16,12),skinM,0,1.96,0);
 part(new THREE.BoxGeometry(.22,.72,.24),dark,-.19,.65,0);part(new THREE.BoxGeometry(.22,.72,.24),dark,.19,.65,0);
 part(new THREE.BoxGeometry(.18,.62,.2),coat,-.42,1.45,0);part(new THREE.BoxGeometry(.18,.62,.2),coat,.42,1.45,0);
 part(new THREE.BoxGeometry(.07,.75,.07),leather,-.34,1.25,.2);part(new THREE.BoxGeometry(.07,.75,.07),leather,.34,1.25,.2);
 let cape=part(new THREE.BoxGeometry(.65,.8,.07),mat(0x667b76),0,1.35,-.22);cape.rotation.x=-.08;
 g.scale.setScalar(scale);return g}
function makeTitan(i){let g=new THREE.Group();let skinColors=[0xb98269,0xc99b81,0x9c7164,0xd2a58b,0xa87d68];let sk=mat(skinColors[i%skinColors.length],.92),hair=mat(i%2?0x382b27:0x514137),dark=mat(0x542c2b),eye=mat(0xf2d7b0,.3),mouth=mat(0x321d1a);
 function p(geo,m,x,y,z){let o=new THREE.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;g.add(o);return o}
 p(new THREE.SphereGeometry(.7,24,18),sk,0,3.5,0);
 p(new THREE.CapsuleGeometry(.62,1.75,7,12),sk,0,2.15,0);
 p(new THREE.SphereGeometry(.19,14,10),dark,-.25,3.52,.55);p(new THREE.SphereGeometry(.19,14,10),dark,.25,3.52,.55);
 p(new THREE.SphereGeometry(.075,10,8),eye,-.25,3.52,.66);p(new THREE.SphereGeometry(.075,10,8),eye,.25,3.52,.66);
 p(new THREE.BoxGeometry(.2,.06,.06),mouth,0,3.17,.63);
 p(new THREE.CapsuleGeometry(.15,.55,4,8),sk,0,2.9,.02);
 p(new THREE.CapsuleGeometry(.2,1.2,4,8),sk,-.78,2.25,0).rotation.z=-.16;
 p(new THREE.CapsuleGeometry(.2,1.2,4,8),sk,.78,2.25,0).rotation.z=.16;
 p(new THREE.CapsuleGeometry(.25,1.3,4,8),sk,-.32,.68,0).rotation.z=-.04;
 p(new THREE.CapsuleGeometry(.25,1.3,4,8),sk,.32,.68,0).rotation.z=.04;
 if(i%2===0)p(new THREE.SphereGeometry(.68,14,10,0,Math.PI*2,0,.6),hair,0,3.72,-.05);
 g.scale.setScalar(1.55+(i%3)*.13);g.position.set((i-2)*8,0,-17-(i%2)*5);g.userData={alive:true,id:i,hp:2,phase:i*.9,baseY:0};scene.add(g);titans.push(g);return g}
function init(){scene=new THREE.Scene();scene.background=new THREE.Color(0x829aa6);scene.fog=new THREE.Fog(0x829aa6,28,105);
 camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,250);
 renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,1.35));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;renderer.outputColorSpace=THREE.SRGBColorSpace;
 scene.add(new THREE.HemisphereLight(0xcbdff4,0x46352d,2.25));let sun=new THREE.DirectionalLight(0xffd6a1,3.4);sun.position.set(-20,35,15);sun.castShadow=true;sun.shadow.mapSize.set(1536,1536);sun.shadow.camera.left=-45;sun.shadow.camera.right=45;sun.shadow.camera.top=45;sun.shadow.camera.bottom=-45;scene.add(sun);
 const fill=new THREE.DirectionalLight(0x9bbfe0,.8);fill.position.set(25,12,-20);scene.add(fill);
 const sunDisc=new THREE.Mesh(new THREE.SphereGeometry(3,16,12),new THREE.MeshBasicMaterial({color:0xffd8a1}));sunDisc.position.set(-38,35,-75);scene.add(sunDisc);
 ground=new THREE.Mesh(new THREE.PlaneGeometry(220,220,30,30),mat(0x65745f));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
 // Stone roads and an old walled town.
 box(18,.08,130,mat(0x8d8a7b),0,.04,0);
 for(let z=-38;z<35;z+=9){for(let x of [-13,13]){let h=5+Math.random()*5,w=5+Math.random()*2;let b=box(w,h,6,mat([0xb4a38b,0x9f927e,0xc2b39a][Math.floor(Math.random()*3)]),x,h/2,z);buildings.push(b);for(let yy=1.5;yy<h-1;yy+=1.7)for(let xx=-w/2+1;xx<w/2-.4;xx+=1.6)box(.45,.7,.035,mat(0x4a5554),x+xx,yy,z+3.03);}}
 // distant wall
 for(let x=-65;x<=65;x+=5){let b=box(4,10,3,mat(0x9e9a8b),x,5,-55);if(x%10===0)box(5,1,4,mat(0xb5ad9b),x,10.3,-55)}
 // trees and debris
 for(let i=0;i<75;i++){let x=(Math.random()-.5)*110,z=(Math.random()-.5)*110;if(Math.abs(x)<15)continue;let trunk=box(.32,2.2,.32,mat(0x47362c),x,1.1,z);let crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.35,2),mat(i%3===0?0x3d5742:0x4b6548));crown.position.set(x,2.9,z);crown.scale.set(1,1.15,.9);crown.castShadow=true;scene.add(crown);if(i%3===0){let stone=box(.5+Math.random(),.35,.5,mat(0x6f7068),x+1,.18,z+1);stone.rotation.y=Math.random()*2}}
 // Atmospheric dust motes in the late-afternoon light.
 const dustGeo=new THREE.BufferGeometry(),dustPos=[];for(let i=0;i<350;i++)dustPos.push((Math.random()-.5)*95,Math.random()*16,(Math.random()-.5)*100);dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(dustPos,3));const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0xf4d8a7,size:.07,transparent:true,opacity:.45}));scene.add(dust);
 player=makeHumanoid(1,0xc99e7c,0x465c50);player.position.set(0,0,7);scene.add(player);
 // ODM gas canisters and blades
 box(.18,.48,.2,mat(0x858f91,.3,.6),-.34,1.4,-.12);box(.18,.48,.2,mat(0x858f91,.3,.6),.34,1.4,-.12);
 for(let i=0;i<5;i++)makeTitan(i);
 clock=new THREE.Clock();window.addEventListener('resize',resize);animate()}
function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)}
function addHook(side){if(!started||gas<=0)return;gas=Math.max(0,gas-4);updateHud();let origin=player.position.clone().add(v(side*.35,1.5,0));let dir=v(Math.sin(yaw+side*.35),.35,-Math.cos(yaw+side*.35));let target=origin.clone().add(dir.multiplyScalar(24));let ray=new THREE.Raycaster(origin,dir,0,28);let hits=ray.intersectObjects([...buildings,...titans.filter(t=>t.userData.alive)],true);if(hits.length)target.copy(hits[0].point);let geom=new THREE.BufferGeometry().setFromPoints([origin,target]);let line=new THREE.Line(geom,new THREE.LineBasicMaterial({color:0xc7d5dc,transparent:true,opacity:.9}));scene.add(line);hooks.push({line,target,life:.32});velocity.add(target.clone().sub(player.position).normalize().multiplyScalar(16));velocity.y+=5}
function attack(){if(!started||Date.now()-lastAttack<450)return;lastAttack=Date.now();attacking=true;setTimeout(()=>attacking=false,220);let best=null,dist=11;for(let t of titans){if(!t.userData.alive)continue;let d=t.position.distanceTo(player.position);if(d<dist){dist=d;best=t}}if(best&&dist<9){best.userData.hp--;best.rotation.y+=.2;triggerHitEffects(best.position.clone().add(v(0,4.7,0)));best.position.y=.12;if(best.userData.hp<=0){best.userData.alive=false;best.visible=false;kills++;document.querySelector('#kills').textContent=kills;document.querySelector('#hint').textContent='إصابة دقيقة! ابحث عن العملاق التالي.';if(kills>=5)document.querySelector('#hint').textContent='انتصار! أنهيت التدريب بنجاح.'}else document.querySelector('#hint').textContent='ضربة قوية! استهدف مؤخرة الرقبة لإنهائه.'}else document.querySelector('#hint').textContent='لا يوجد عملاق قريب. استخدم الخطاف للوصول إليه.'}
function updateHud(){document.querySelector('#gas').textContent=Math.round(gas);document.querySelector('#healthText').textContent=Math.round(health);document.querySelector('#healthFill').style.width=health+'%'}
function update(dt){if(!started)return;
 let mx=moveX+(keys.a?-1:0)+(keys.d?1:0),mz=moveZ+(keys.w?1:0)+(keys.s?-1:0);mx=THREE.MathUtils.clamp(mx,-1,1);mz=THREE.MathUtils.clamp(mz,-1,1);
 let forward=v(Math.sin(yaw),0,-Math.cos(yaw)),right=v(Math.cos(yaw),0,Math.sin(yaw));let dir=forward.multiplyScalar(mz).add(right.multiplyScalar(mx));if(dir.length()>1)dir.normalize();
 let speed=(keys.shift?10:6.2);velocity.x=THREE.MathUtils.lerp(velocity.x,dir.x*speed,Math.min(1,dt*5));velocity.z=THREE.MathUtils.lerp(velocity.z,dir.z*speed,Math.min(1,dt*5));
 if(dir.length()>.1)player.rotation.y=Math.atan2(dir.x,dir.z);
 velocity.y-=18*dt;player.position.addScaledVector(velocity,dt);if(velocity.length()>9&&Math.random()<.8)emitSpeedLines();if(player.position.y<0){player.position.y=0;velocity.y=Math.max(0,velocity.y)}
 player.position.x=THREE.MathUtils.clamp(player.position.x,-48,48);player.position.z=THREE.MathUtils.clamp(player.position.z,-48,28);
 // Titan AI: lumber toward the player when close enough.
 for(let t of titans){if(!t.userData.alive)continue;t.position.y=Math.sin(clock.elapsedTime*2+t.userData.phase)*.045;let delta=player.position.clone().sub(t.position);let d=delta.length();if(d<25){delta.y=0;delta.normalize();t.position.addScaledVector(delta,dt*.65);t.rotation.y=Math.atan2(delta.x,delta.z);t.children[8].rotation.z=Math.sin(clock.elapsedTime*2+t.userData.phase)*.08-.16;t.children[9].rotation.z=-Math.sin(clock.elapsedTime*2+t.userData.phase)*.08+.16;if(d<2.1&&Math.random()<dt*.45){health=Math.max(0,health-5);updateHud();if(health===0){health=100;player.position.set(0,0,7);velocity.set(0,0,0);updateHud();document.querySelector('#hint').textContent='سقطت أثناء التدريب. أُعيدت إلى نقطة البداية.'}}}else{t.position.x+=Math.sin(clock.elapsedTime*.4+t.userData.phase)*dt*.12}}
 for(let i=hooks.length-1;i>=0;i--){hooks[i].life-=dt;if(hooks[i].life<=0){scene.remove(hooks[i].line);hooks.splice(i,1)}}
 // Camera orbit
 let rot=new THREE.Euler(pitch,yaw,0,'YXZ');let offset=new THREE.Vector3(0,2.3,6.8).applyEuler(rot);cameraBase.copy(player.position.clone().add(offset));if(performance.now()<shakeUntil){cameraBase.x+=(Math.random()-.5)*shakeMagnitude;cameraBase.y+=(Math.random()-.5)*shakeMagnitude;cameraBase.z+=(Math.random()-.5)*shakeMagnitude}else shakeMagnitude=0;camera.position.lerp(cameraBase,Math.min(1,dt*8));camera.lookAt(player.position.clone().add(v(0,1.6,0)));
 // Slight dynamic camera FOV during high-speed ODM movement.
 const targetFov=velocity.length()>10?73:65;camera.fov=THREE.MathUtils.lerp(camera.fov,targetFov,Math.min(1,dt*3));camera.updateProjectionMatrix();
 let target=null,best=14;for(let t of titans){if(!t.userData.alive)continue;let d=t.position.distanceTo(player.position);if(d<best){best=d;target=t}}
 document.querySelector('#targetLabel').textContent=target?`عملاق على بُعد ${best.toFixed(1)} م`:'لا يوجد هدف محدد';
}
function animate(){requestAnimationFrame(animate);const realDt=Math.min(clock.getDelta(),.035);updateEffects(realDt);const now=performance.now();const dt=now<hitStopUntil?0:realDt;update(dt);renderer.render(scene,camera)}
// keyboard and mouse
window.addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(e.code==='Space'&&started&&player.position.y<.1)velocity.y=8;if(e.key.toLowerCase()==='q')addHook(-1);if(e.key.toLowerCase()==='e')addHook(1);if(e.key.toLowerCase()==='f')attack()});
window.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
let dragging=false,px=0,py=0;canvas.addEventListener('pointerdown',e=>{dragging=true;px=e.clientX;py=e.clientY;canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointerup',()=>dragging=false);canvas.addEventListener('pointermove',e=>{if(!dragging||!started)return;let dx=e.clientX-px,dy=e.clientY-py;px=e.clientX;py=e.clientY;yaw-=dx*.004;pitch=THREE.MathUtils.clamp(pitch-dy*.003,-.55,.45)});
document.querySelectorAll('.char').forEach(b=>b.addEventListener('click',()=>{selected=b.dataset.char;document.querySelectorAll('.char').forEach(x=>x.classList.toggle('selected',x===b));if(player){scene.remove(player);player=makeHumanoid(1,0xc99e7c,selected==='mikasa'?0x8d3030:selected==='levi'?0x435d69:0x465c50);player.position.set(0,0,7);scene.add(player)}}));
document.querySelector('#start').onclick=()=>{started=true;document.querySelector('#intro').style.display='none';document.querySelector('#hint').textContent='اقترب من العمالقة، أطلق الخطاف، ثم اضغط هجوم.'};
document.querySelector('#hookL').onclick=()=>addHook(-1);document.querySelector('#hookR').onclick=()=>addHook(1);document.querySelector('#attack').onclick=attack;document.querySelector('#jump').onclick=()=>{if(started&&player.position.y<.15)velocity.y=8};
const zone=document.querySelector('#stickZone'),knob=document.querySelector('#stickKnob');let stickId=null,center={x:0,y:0};
zone.addEventListener('pointerdown',e=>{stickId=e.pointerId;zone.setPointerCapture(stickId);let r=document.querySelector('#stickBase').getBoundingClientRect();center={x:r.left+r.width/2,y:r.top+r.height/2};moveStick(e)});
zone.addEventListener('pointermove',e=>{if(e.pointerId===stickId)moveStick(e)});function moveStick(e){let dx=e.clientX-center.x,dy=e.clientY-center.y,len=Math.hypot(dx,dy),max=43;if(len>max){dx*=max/len;dy*=max/len}knob.style.left=`calc(50% + ${dx}px)`;knob.style.top=`calc(50% + ${dy}px)`;moveX=dx/max;moveZ=-dy/max}
function resetStick(){stickId=null;moveX=moveZ=0;knob.style.left='50%';knob.style.top='50%'}zone.addEventListener('pointerup',resetStick);zone.addEventListener('pointercancel',resetStick);
const look=document.querySelector('#lookZone');let lookId=null,lx=0,ly=0;look.addEventListener('pointerdown',e=>{lookId=e.pointerId;lx=e.clientX;ly=e.clientY;look.setPointerCapture(lookId)});look.addEventListener('pointermove',e=>{if(e.pointerId!==lookId)return;yaw-=(e.clientX-lx)*.007;pitch=THREE.MathUtils.clamp(pitch-(e.clientY-ly)*.005,-.55,.45);lx=e.clientX;ly=e.clientY});look.addEventListener('pointerup',()=>lookId=null);
try{init();document.querySelector('#loading').style.display='none';if(matchMedia('(pointer:coarse)').matches)document.querySelector('#mobile').style.display='block'}catch(e){document.querySelector('#loading').innerHTML='<div class="load-title">تعذّر تشغيل اللعبة</div><p>تأكد من اتصال الإنترنت ثم أعد فتح الملف.</p><small>'+e.message+'</small>'}
