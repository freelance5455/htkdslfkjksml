const N=8;
const sols=[[0,2,4,6,1,3,5,7],[1,3,5,7,0,2,4,6],[0,3,6,4,1,7,2,5]];
const cols=['#fbdfe7','#e3e7ff','#dcf4e7','#fff0c8','#e4efff','#f1e1ff','#dcf6f2','#ffe5d2'];
let L=0,placed=[],hist=[],moves=0,sec=0,lives=3,timer,paused=false,soundOn=true,markMode=false;
let hint=null,marks=new Set();
const regions=[
[0,0,1,1,2,2,2,3],[0,0,1,1,2,2,3,3],[0,4,4,5,5,2,3,3],[0,4,4,5,5,6,6,3],
[7,4,4,5,5,6,6,3],[7,7,4,5,5,6,6,3],[7,7,4,4,1,1,1,3],[7,7,7,4,1,1,1,3]
];
const $=id=>document.getElementById(id);
function key(r,c){return r+','+c}
function p(k){return k.split(',').map(Number)}
function fmt(x){return String(Math.floor(x/60)).padStart(2,'0')+':'+String(x%60).padStart(2,'0')}
function valid(r,c){
  return !placed.some(k=>{let[x,y]=p(k);return x==r||y==c||regions[x][y]==regions[r][c]||(Math.abs(x-r)<=1&&Math.abs(y-c)<=1)})
}
function beep(type){
  if(!soundOn) return;
  try{
    const C=window.AudioContext||window.webkitAudioContext,ctx=new C(),o=ctx.createOscillator(),g=ctx.createGain();
    o.frequency.value=type==='bad'?170:type==='win'?720:480;g.gain.value=.035;o.connect(g);g.connect(ctx.destination);o.start();
    setTimeout(()=>{o.stop();ctx.close()},110);
  }catch(e){}
}
function render(){
  const b=$('board');b.innerHTML='';
  for(let r=0;r<N;r++)for(let c=0;c<N;c++){
    const e=document.createElement('button');e.type='button';e.className='cell';e.style.background=cols[regions[r][c]];
    const k=key(r,c);
    if(placed.includes(k)) e.innerHTML='<span class="girl">👧</span>';
    else if(marks.has(k)) e.innerHTML='<span class="xmark">×</span>';
    if(hint===k)e.classList.add('hint');
    e.onclick=()=>tap(r,c);b.appendChild(e);
  }
  $('mv').textContent=moves;$('lives').textContent=lives;
  $('progressBar').style.width=(placed.length/8*100)+'%';
  $('undo').disabled=!hist.length||paused;
}
function loseLife(){
  lives--; beep('bad'); $('lives').textContent=lives;
  if(lives<=0){clearInterval(timer);$('gameover').hidden=false;$('msg').textContent='No lives left. Retry the level.'}
  else $('msg').textContent=`Wrong move. ${lives} ${lives===1?'life':'lives'} left.`;
}
function tap(r,c){
  if(paused||lives<=0)return;
  const k=key(r,c);
  if(placed.includes(k))return;
  if(markMode){if(!marks.has(k))marks.add(k);else marks.delete(k);hint=null;render();return}
  if(marks.has(k))marks.delete(k);
  if(!valid(r,c)){loseLife();const el=[...$('board').children].find(x=>+x.dataset?.r===r&&+x.dataset?.c===c);render();return}
  hist.push([...placed]);placed.push(k);moves++;hint=null;beep('ok');$('msg').textContent='Good move!';render();checkWin();
}
function checkWin(){
  if(placed.length!==8)return;
  const win=placed.every(k=>{let[r,c]=p(k);return sols[L][r]===c});
  if(win){clearInterval(timer);beep('win');$('msg').textContent='Puzzle solved!';$('wt').textContent=`Level ${L+1} completed in ${moves} moves and ${fmt(sec)}.`;$('win').hidden=false;saveBest()}
  else $('msg').textContent='All rows filled, but the solution is different. Use Reset or Undo.';
}
function saveBest(){
  const keyName='girlPuzzleBest'+L; // best time only for this browser
  let old=Number(sessionStorage.getItem(keyName)||0);
  if(!old||sec<old){try{sessionStorage.setItem(keyName,String(sec))}catch(e){};$('best').textContent='Best: '+fmt(sec)}
}
function loadBest(){try{const v=sessionStorage.getItem('girlPuzzleBest'+L);$('best').textContent=v?'Best: '+fmt(+v):'Best: —'}catch(e){$('best').textContent='Best: —'}}
function start(){clearInterval(timer);timer=setInterval(()=>{if(!paused&&lives>0){sec++;$('tm').textContent=fmt(sec)}},1000)}
function reset(){
  placed=[];hist=[];moves=0;sec=0;lives=3;paused=false;hint=null;marks=new Set();
  $('win').hidden=true;$('gameover').hidden=true;$('msg').textContent='Place one girl in every row, column and region.';
  $('pause').textContent='⏸ Pause';$('tm').textContent='00:00';loadBest();render();start();
}
$('undo').onclick=()=>{if(paused||!hist.length)return;placed=hist.pop();moves=Math.max(0,moves-1);hint=null;render();$('msg').textContent='Last move undone.'};
$('hint').onclick=()=>{
  if(paused||lives<=0)return;
  const s=sols[L],k=Array.from({length:8},(_,r)=>key(r,s[r])).find(x=>!placed.includes(x));
  hint=k||null;beep('ok');$('msg').textContent='Hint: highlighted cell is a correct move.';render()
};
$('reset').onclick=reset;
$('retry').onclick=reset;
$('next').onclick=()=>{L=(L+1)%sols.length;$('lv').textContent=L+1;reset()};
$('pause').onclick=()=>{if(lives<=0)return;paused=!paused;$('pause').textContent=paused?'▶ Resume':'⏸ Pause';$('msg').textContent=paused?'Game paused.':'Game resumed.'};
$('sound').onclick=()=>{soundOn=!soundOn;$('sound').textContent=soundOn?'🔊 Sound':'🔇 Sound Off';if(soundOn)beep('ok')};
$('xmode').onclick=()=>{markMode=!markMode;$('xmode').textContent=markMode?'✕ Mark ON':'✕ Mark';$('msg').textContent=markMode?'Mark mode: tap cells to add/remove X marks.':'Normal placement mode.'};
reset();
