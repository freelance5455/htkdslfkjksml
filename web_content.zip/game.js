/* FableBlocks Mobile — open-source-friendly original WebGL voxel survival prototype.
 * Self-contained: NO CDN, NO modules, NO paid plugins. Designed for Android WebViews.
 * Land generation, structures, mobs and textures are original procedural implementations.
 */
(()=>{'use strict';
const $=id=>document.getElementById(id), clamp=(x,a,b)=>Math.max(a,Math.min(b,x)), mix=(a,b,t)=>a+(b-a)*t;
const CS=16, WH=56, SEA=18, SAVE_PREFIX='fableblocks_02_', VERSION=2;
const BIOMES=[
 {name:'Foresta degli Elfi',tag:'Boschi smeraldo',top:1,wood:6,leaf:7,race:'elf',palette:'forest'},
 {name:'Boschi delle Fate',tag:'Funghi e incantesimi',top:1,wood:6,leaf:25,race:'fairy',palette:'fairy'},
 {name:'Montagne dei Nani',tag:'Roccia e fortezze',top:3,wood:10,leaf:27,race:'dwarf',palette:'stone'},
 {name:'Ghiacciai Antichi',tag:'Lupi e palazzi di ghiaccio',top:8,wood:6,leaf:27,race:'icewolf',palette:'ice'},
 {name:'Terre Ardenti',tag:'Rocce di fuoco',top:10,wood:10,leaf:25,race:'goblin',palette:'ember'},
 {name:'Pianure degli Gnomi',tag:'Villaggi e campi',top:1,wood:6,leaf:7,race:'gnome',palette:'meadow'},
 {name:'Lagune degli Antichi',tag:'Porti tra le acque',top:4,wood:6,leaf:7,race:'elf',palette:'coast'},
 {name:'Paludi delle Streghe',tag:'Acque oscure e misteri',top:1,wood:6,leaf:25,race:'troll',palette:'swamp'},
 {name:'Deserto delle Rune',tag:'Rovine e sabbia dorata',top:4,wood:10,leaf:25,race:'goblin',palette:'desert'}
];
const ITEMS=[
 null,['Erba','🌿',1.4],['Terra','🟫',.65],['Pietra','🪨',2],['Sabbia','🟨',.6],['Acqua','💧',99],
 ['Tronco','🪵',2],['Foglie','🍃',.45],['Neve','❄️',.7],['Ghiaccio','🧊',1],['Basalto','⬛',2.8],['Lava','🔥',99],
 ['Cristallo','💎',3],['Fungo','🍄',.6],['Assi','📦',1],['Mattoni','🧱',2],['Ciottoli','🪨',1.7],['Paglia','🌾',.5],
 ['Lanterna','🏮',.5],['Cassa','🧰',1],['Fornace','♨️',2],['Carbone','⚫',1.5],['Ferro grezzo','🔩',2],
 ['Ossidiana','🔮',5],['Foglie cremisi','🍁',.5],['Fungo luminoso','🍄',.5],['Abete','🌲',.5],['Mattone dorato','🟨',2],
 ['Ardesia','◼️',2],['Lana','🧶',.4],['Vetro','🔷',.55],['Pane','🍞',0],['Carne','🥩',0],['Carne cotta','🍖',0],['Lingotto','🔗',0],['Spada','⚔️',0],['Piccone','⛏️',0],['Torcia','🕯️',.4]
];
const N={AIR:0,GRASS:1,DIRT:2,STONE:3,SAND:4,WATER:5,LOG:6,LEAF:7,SNOW:8,ICE:9,BASALT:10,LAVA:11,CRYSTAL:12,MUSHROOM:13,PLANK:14,BRICK:15,COBBLE:16,THATCH:17,LAMP:18,CHEST:19,FURNACE:20,COAL:21,IRON:22,OBSIDIAN:23,REDLEAF:24,GLOWMUSH:25,PINE:26,GOLD:27,SLATE:28,WOOL:29,GLASS:30};
// Item enum uses block IDs through 30, edible/craftable items start at 31.
const FOOD_MIN=31, MAX_BLOCK=30;
const ITEM_ID={BREAD:31,MEAT:32,COOKED:33,INGOT:34,SWORD:35,PICKAXE:36,TORCH:37};
const SLOT_MAX=64;
const RECIPES=[
 {title:'Assi ×4',out:14,n:4,need:{6:1},about:'Tronco → assi'},
 {title:'Ciottoli ×4',out:16,n:4,need:{3:4},about:'Pietra → ciottoli'},
 {title:'Mattoni ×2',out:15,n:2,need:{3:2,2:1},about:'Pietra e terra'},
 {title:'Cassa',out:19,n:1,need:{14:8},about:'Contenitore per oggetti'},
 {title:'Fornace',out:20,n:1,need:{16:8},about:'Cuoce e fonde risorse'},
 {title:'Lanterna ×2',out:18,n:2,need:{21:1,14:1},about:'Illumina le tue costruzioni'},
 {title:'Torcia ×4',out:37,n:4,need:{21:1,6:1},about:'Equipaggiamento'},
 {title:'Pane ×2',out:31,n:2,need:{17:3},about:'Ripristina la fame'},
 {title:'Piccone',out:36,n:1,need:{14:2,3:3},about:'Scava più rapidamente'},
 {title:'Spada',out:35,n:1,need:{14:1,34:2},about:'Danni extra ai mostri'},
 {title:'Vetro ×3',out:30,n:3,need:{4:3,21:1},about:'Ricetta di prova, smelt in futuro'}
];
const FACES=[
 {d:[0,1,0],l:1,pts:[[0,1,0],[0,1,1],[1,1,1],[1,1,0]]},
 {d:[0,-1,0],l:.53,pts:[[0,0,1],[0,0,0],[1,0,0],[1,0,1]]},
 {d:[0,0,1],l:.80,pts:[[0,0,1],[1,0,1],[1,1,1],[0,1,1]]},
 {d:[0,0,-1],l:.70,pts:[[1,0,0],[0,0,0],[0,1,0],[1,1,0]]},
 {d:[1,0,0],l:.85,pts:[[1,0,1],[1,0,0],[1,1,0],[1,1,1]]},
 {d:[-1,0,0],l:.73,pts:[[0,0,0],[0,0,1],[0,1,1],[0,1,0]]}
];
const TRI=[0,1,2,0,2,3],UV=[[0,0],[1,0],[1,1],[0,1]];
const DEFAULT_INV={6:10,14:12,17:3,31:3,36:1,37:5};
const SLOTS_INIT=[36,6,3,14,2,18,31];
let canvas=$('worldCanvas'),gl,game=null,seed=0,active=false,paused=false,loading=false,invTab='oggetti';
let chunks=new Map(),queue=[],edits={},containers={},killed={},activeMobs=[],renderRadius=3,requestedRadius=3;
let nearVisible=[],worldChanged=false,saveNext=0,worldTime=0,frameNo=0,lastNow=0,lastMob=0,viewDir=[0,0,-1];
let player={x:5.5,y:25,z:5.5,yaw:2.3,pitch:-.12,vy:0,hp:20,hunger:20,ground:false,fall:0,air:12,fire:0,regen:0},inventory={},slots=SLOTS_INIT.slice(),chosen=0;
let keys={},movePad={x:0,y:0},padPointer=null,lookPointer=null,holdBreak=false,breakTime=0,breakAt='',targeted=null,hitMob=null,zoomValue=0;
let glState={},particles=[];let lastRegion='',loadCount=0,expectedLoad=1,mobRenderBuffer=null,mobCount=0,uiTick=0,handTimer=null;
function rng(x,z,s=seed){let t=Math.sin(x*127.1+z*311.7+s*74.71)*43758.5453;return t-Math.floor(t)}
function noise(x,z,s=seed){let ix=Math.floor(x),iz=Math.floor(z),fx=x-ix,fz=z-iz;fx=fx*fx*(3-2*fx);fz=fz*fz*(3-2*fz);return mix(mix(rng(ix,iz,s),rng(ix+1,iz,s),fx),mix(rng(ix,iz+1,s),rng(ix+1,iz+1,s),fx),fz)}
function fbm(x,z,s=seed){return noise(x,z,s)*.57+noise(x*2,z*2,s+73)*.28+noise(x*4,z*4,s+144)*.15}
function biomeAt(x,z){let sx=x/175,sz=z/175,cx=Math.floor(sx),cz=Math.floor(sz),best=1e8,b=0;for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){let gx=cx+dx,gz=cz+dz,px=(gx+.16+.68*rng(gx,gz,seed+14))*175,pz=(gz+.16+.68*rng(gx,gz,seed+21))*175,size=.68+.8*rng(gx,gz,seed+8),d=((x-px)**2+(z-pz)**2)/(size*size);if(d<best){best=d;b=Math.floor(rng(gx,gz,seed+33)*BIOMES.length)}}let dist=Math.hypot(x,z);if(dist<58)return game?game.startBiome:0;if(dist<83&&rng(Math.floor(x/13),Math.floor(z/13),seed+52)<(83-dist)/25)return game?game.startBiome:0;return b}
function heightAt(x,z,b=biomeAt(x,z)){let w=fbm(x/49,z/49,seed+33),fine=fbm(x/13,z/13,seed+82),ridge=Math.abs(noise(x/42,z/42,seed+21)*2-1);let h;
 switch(b){case 0:h=20+w*8+fine*5;break;case 1:h=17+w*8+fine*4;break;case 2:h=23+w*11+(1-ridge)*13+fine*5;break;case 3:h=22+w*12+(1-ridge)*12+fine*4;break;case 4:h=18+w*9+(1-ridge)*11+fine*5;break;case 5:h=17+w*7+fine*3;break;case 6:h=7+w*12+fine*3;break;case 7:h=10+w*9+fine*4;break;default:h=14+w*13+fine*4;}
 let river=Math.abs(noise(x/102,z/102,seed+125)-.5),lake=(noise(x/67,z/67,seed+129)>.74);if(river<.033)h=Math.min(h,15+river*70);if(lake&&(b===0||b===1||b===5||b===7))h-=7;
 return clamp(Math.floor(h),3,WH-8)}
function inSolid(t){return t!==0&&t!==5&&t!==11&&t!==24&&t!==25&&t!==26} // foliage intentionally non-solid
function liquid(t){return t===5||t===11}
function blockKey(x,y,z){return x+','+y+','+z}
function chunkKey(cx,cz){return cx+','+cz}
function localIx(x,y,z,cx,cz){return ((y*CS)+(z-cz*CS))*CS+(x-cx*CS)}
function pickOre(x,y,z,b){let r=rng(x*3+y,z+y*7,seed+54);if(y<25&&r>.983)return r>.996?22:21;if(y<14&&r<.006)return 12;return b===4?10:3}
function createChunk(cx,cz){let a=new Uint8Array(CS*CS*WH),bmap=new Uint8Array(CS*CS),heights=new Uint8Array(CS*CS),ox=cx*CS,oz=cz*CS;
 const set=(x,y,z,t)=>{if(x>=ox&&x<ox+CS&&z>=oz&&z<oz+CS&&y>=0&&y<WH)a[localIx(x,y,z,cx,cz)]=t};
 for(let lz=0;lz<CS;lz++)for(let lx=0;lx<CS;lx++){let x=ox+lx,z=oz+lz,b=biomeAt(x,z),h=heightAt(x,z,b),ix=lz*CS+lx;bmap[ix]=b;heights[ix]=h;
  for(let y=0;y<=h;y++){let cave=y>5&&y<h-4&&noise(x/12+y*.16,z/12-y*.2,seed+77)>.79&&noise(x/13-y*.23,z/13+y*.13,seed+45)>.45;
   let t=y===0?23:y===h?(b===2||b===4?10:b===3?8:b===6||b===8?4:1):y>h-4?(b===6||b===8?4:b===4?10:2):pickOre(x,y,z,b);
   if(!cave)set(x,y,z,t);
  }
  let waterlevel=SEA;if(b===4&&h<20)waterlevel=20;for(let y=h+1;y<=waterlevel;y++)set(x,y,z,b===4?11:b===3?9:5);
 }
 // Procedural forests, mushrooms, pines, crystal clusters and rock spires.
 const tx0=Math.floor((ox-5)/7),tz0=Math.floor((oz-5)/7),tx1=Math.floor((ox+CS+5)/7),tz1=Math.floor((oz+CS+5)/7);
 for(let tz=tz0;tz<=tz1;tz++)for(let tx=tx0;tx<=tx1;tx++){
  if(rng(tx,tz,seed+311)>.43)continue;let x=tx*7+2+Math.floor(rng(tx,tz,seed+312)*4),z=tz*7+2+Math.floor(rng(tx,tz,seed+313)*4),b=biomeAt(x,z),h=heightAt(x,z,b);if(h<=SEA+1||b===6||b===8)continue;
  if(b===2||b===3){if(rng(tx,tz,seed+6)>.55)continue;let ht=4+Math.floor(rng(tx,tz,seed+10)*3);for(let j=1;j<=ht;j++)set(x,h+j,z,6);for(let dy=ht-2;dy<=ht+2;dy++)for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)if(Math.abs(dx)+Math.abs(dz)<(dy===ht+2?2:4)&&Math.abs(dx)+Math.abs(dz)+(Math.abs(dy-ht)*.5)<4.3)set(x+dx,h+dy,z+dz,26);
  }else if(b===4){if(rng(tx,tz,seed+12)<.5){let ht=2+Math.floor(rng(tx,tz,seed+18)*4);for(let i=1;i<=ht;i++)set(x,h+i,z,10);set(x,h+ht+1,z,12)}
  }else if(b===1||b===7){let ht=2+Math.floor(rng(tx,tz,seed+10)*3);for(let j=1;j<ht;j++)set(x,h+j,z,6);for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)if(Math.abs(dx)+Math.abs(dz)<4){set(x+dx,h+ht,z+dz,13);if(Math.abs(dx)<=1&&Math.abs(dz)<=1)set(x+dx,h+ht+1,z+dz,25)}
  }else{let ht=3+Math.floor(rng(tx,tz,seed+10)*3);for(let j=1;j<=ht;j++)set(x,h+j,z,6);for(let dy=ht-2;dy<=ht+1;dy++)for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++)if(Math.abs(dx)+Math.abs(dz)+Math.max(0,dy-ht)<5)set(x+dx,h+dy,z+dz,b===0?7:b===5?7:24)}
 }
 // Villages are zoned into hamlets, towns and occasionally walled seats of power.
 const sites=townSitesNear(ox+CS/2,oz+CS/2,88);
 for(const s of sites)stampTown(s,ox,oz,set);
 // Player edits always override procedurally generated terrain and settlements.
 let prefix='';for(let k in edits){let parts=k.split(','),x=+parts[0],z=+parts[2];if(x>=ox&&x<ox+CS&&z>=oz&&z<oz+CS){let y=+parts[1];set(x,y,z,edits[k])}}
 return {cx,cz,a,bmap,heights,dirty:true,solid:null,fluid:null,seen:0,mobSeeded:false};
}
function townSitesNear(x,z,range=90){let out=[{x:32,z:29,b:game.startBiome,size:'town',seed:101}];let cell=170,gx=Math.floor(x/cell),gz=Math.floor(z/cell);for(let dz=-1;dz<=1;dz++)for(let dx=-1;dx<=1;dx++){let ax=gx+dx,az=gz+dz;if(rng(ax,az,seed+117)<.45)continue;let tx=ax*cell+35+rng(ax,az,seed+118)*105,tz=az*cell+35+rng(ax,az,seed+119)*105;if(Math.hypot(tx-32,tz-29)<85)continue;let b=biomeAt(tx,tz),sz=rng(ax,az,seed+120),size=sz>.87?'city':sz>.42?'town':'hamlet';out.push({x:Math.round(tx),z:Math.round(tz),b,size,seed:ax*13+az*19+971})}
 return out.filter(s=>Math.abs(s.x-x)<=range&&Math.abs(s.z-z)<=range)}
function stampTown(s,ox,oz,set){const rad=s.size==='city'?42:s.size==='town'?30:18;if(s.x+rad<ox||s.x-rad>ox+CS||s.z+rad<oz||s.z-rad>oz+CS)return;
 const base=heightAt(s.x,s.z,s.b)+1, style=BIOMES[s.b].palette;
 let wall=style==='ice'?9:style==='ember'?10:style==='stone'?15:style==='fairy'?24:style==='desert'?4:style==='meadow'?14:style==='coast'?16:style==='swamp'?28:14;
 let roof=style==='ice'?8:style==='ember'?23:style==='stone'?28:style==='fairy'?13:style==='desert'?27:style==='meadow'?17:style==='coast'?26:style==='swamp'?24:7;
 let path=style==='ice'?9:style==='ember'?10:style==='stone'?16:style==='desert'?4:style==='fairy'?27:16;
 const put=(x,y,z,t)=>set(Math.round(x),Math.round(y),Math.round(z),t);
 function clear(x,z,level){for(let y=level;y<Math.min(WH,level+10);y++)put(x,y,z,0)}
 function paving(x,z){let h=heightAt(x,z,biomeAt(x,z));if(h<SEA-3)return;put(x,h,z,path);if(h<base-2){for(let y=h+1;y<Math.min(base-1,h+6);y++)put(x,y,z,path)}}
 // Crossroads, monumental central square, varied paving.
 for(let a=-rad;a<=rad;a++)for(let w=-1;w<=1;w++){let xx=s.x+a,zz=s.z+a;if(Math.abs(a)<rad-2){paving(xx,s.z+w);paving(s.x+w,zz)}}
 for(let dx=-3;dx<=3;dx++)for(let dz=-3;dz<=3;dz++)paving(s.x+dx,s.z+dz);
 function house(px,pz,w,d,h,variant,index){let level=heightAt(px,pz,biomeAt(px,pz))+1;level=clamp(level,SEA,WH-12);const left=px-Math.floor(w/2),front=pz-Math.floor(d/2),doorSide=index%4,doorX=left+Math.floor(w/2),doorZ=front;
  for(let x=left-1;x<=left+w;x++)for(let z=front-1;z<=front+d;z++){
   let ground=heightAt(x,z,biomeAt(x,z));for(let y=Math.max(ground+1,level-4);y<=level;y++)put(x,y,z,variant===3?16:wall);
   if(x>=left&&x<left+w&&z>=front&&z<front+d)for(let y=level+1;y<=level+h+4;y++)clear(x,z,y);
  }
  for(let y=level+1;y<=level+h;y++)for(let x=left;x<left+w;x++)for(let z=front;z<front+d;z++){
   let edge=x===left||x===left+w-1||z===front||z===front+d-1;if(!edge)continue;
   let t=(variant===2&&(x+z)%4===0)?6:wall;
   if((x===left||x===left+w-1)&&y===level+2&&z===front+Math.floor(d/2))t=30;
   if((z===front+d-1)&&y===level+2&&x===left+Math.floor(w/2))t=30;
   if(z===doorZ&&x===doorX&&(y===level+1||y===level+2))t=0;
   put(x,y,z,t)
  }
  // Gabled, pyramidal and tower roofs; awnings + varying eaves.
  for(let r=0;r<2+(variant===3?2:0);r++)for(let x=left-1+r;x<left+w+1-r;x++)for(let z=front-1+r;z<front+d+1-r;z++){
    if(x<left-1+r||z<front-1+r)continue;put(x,level+h+1+r, z,roof)
  }
  if(variant===3){for(let y=level+h+1;y<level+h+4;y++)for(let x of [left,left+w-1])for(let z of [front,front+d-1])put(x,y,z,wall);put(px,level+h+4,pz,18)}
  if(variant===1){for(let x=left;x<left+w;x++)put(x,level+h+3,front+Math.floor(d/2),roof)}
  put(doorX,level+3,doorZ,18);
 }
 let count=s.size==='city'?18:s.size==='town'?9:4;
 for(let i=0;i<count;i++){let ring=Math.floor(i/8),side=i%8,angle=(side/8)*Math.PI*2+(rng(i,s.seed,seed+401)-.5)*.12,distance=11+ring*12+(rng(i,s.seed,seed+402)-.5)*3,px=Math.round(s.x+Math.cos(angle)*distance),pz=Math.round(s.z+Math.sin(angle)*distance);let w=5+Math.floor(rng(i,s.seed,seed+403)*5),d=5+Math.floor(rng(i,s.seed,seed+404)*4),h=3+Math.floor(rng(i,s.seed,seed+405)*3),v=Math.floor(rng(i,s.seed,seed+406)*4);house(px,pz,w,d,h,v,i)}
 // Town hall / keep, central well, banner towers. Palette and scale depend on biome.
 if(s.size==='city'){for(let dx=-5;dx<=5;dx++)for(let dz=-5;dz<=5;dz++){let x=s.x+dx,z=s.z+dz;if(Math.abs(dx)===5||Math.abs(dz)===5){for(let y=base;y<Math.min(base+9,WH);y++)put(x,y,z,wall);if((Math.abs(dx)+Math.abs(dz))%3===0)put(x,base+9,z,roof)}else for(let y=base+1;y<base+9;y++)put(x,y,z,0)}for(let dy=1;dy<=3;dy++)put(s.x,base+dy,s.z,18);for(let dy=0;dy<2;dy++)put(s.x,base+dy,s.z-5,0)}
 else{for(let dx=-2;dx<=2;dx++)for(let dz=-2;dz<=2;dz++){let r=Math.max(Math.abs(dx),Math.abs(dz));if(r===2)put(s.x+dx,base+1,s.z+dz,wall);if(r===1)put(s.x+dx,base,s.z+dz,5)}put(s.x,base+2,s.z,18)}
 // A harbor on lagoon / coast; no repeated cookie-cutter houses.
 if(s.b===6||s.b===7){for(let z=s.z+5;z<s.z+24;z++)for(let x=s.x-2;x<=s.x+2;x++){put(x,SEA+2,z,14);if(z%5===0&&Math.abs(x)===2)put(x,SEA+3,z,6)}}
 // Library marker & watchtower in large towns (distinct roof and portal).
 if(s.size!=='hamlet'){let x=s.x-8,z=s.z-8;house(x,z,9,7,5,3,7);put(x,base+8,z,12)}
}
function getChunk(cx,cz){return chunks.get(chunkKey(cx,cz))}
function getBlock(x,y,z){x=Math.floor(x);y=Math.floor(y);z=Math.floor(z);if(y<0)return 23;if(y>=WH)return 0;let c=getChunk(Math.floor(x/CS),Math.floor(z/CS));return c?c.a[localIx(x,y,z,c.cx,c.cz)]:0}
function setBlock(x,y,z,t){x=Math.floor(x);y=Math.floor(y);z=Math.floor(z);if(y<=0||y>=WH)return false;let c=getChunk(Math.floor(x/CS),Math.floor(z/CS));if(!c)return false;edits[blockKey(x,y,z)]=t;c.a[localIx(x,y,z,c.cx,c.cz)]=t;c.dirty=true;for(let [nx,nz] of [[1,0],[-1,0],[0,1],[0,-1]]){let adj=getChunk(Math.floor((x+nx)/CS),Math.floor((z+nz)/CS));if(adj)adj.dirty=true}worldChanged=true;return true}
// Original programmatically painted pixel-art texture atlas: 8 x 4 tiles, 32 px each.
function makeAtlas(){let cv=document.createElement('canvas');cv.width=256;cv.height=128;let ctx=cv.getContext('2d',{alpha:false});let palette=[
 '#34444a','#4c9745','#83613d','#8d9298','#dfc486','#3d8dca','#966c42','#48854b',
 '#e9f2f1','#90dcef','#42353e','#ed6627','#77bdde','#c83f72','#b8824c','#a18d7e',
 '#838485','#bfa96c','#ffcf75','#855b34','#70757b','#24242e','#a17a57','#342d49',
 '#b45d46','#76dbd1','#386b67','#cfa64d','#545d71','#d8d0bd','#a4dce0'];
 for(let id=0;id<=30;id++){let ox=(id%8)*32,oy=Math.floor(id/8)*32,c=palette[id];ctx.fillStyle=c;ctx.fillRect(ox,oy,32,32);let rr=n=>rng(ox+n,oy+id*11,seed+171);
  for(let i=0;i<150;i++){let x=Math.floor(rr(i*7+1)*32),y=Math.floor(rr(i*9+2)*32),s=1+Math.floor(rr(i+32)*4);ctx.fillStyle=i%3===0?'#00000015':'#ffffff1c';ctx.fillRect(ox+x,oy+y,s,Math.max(1,s-1))}
  if(id===1){ctx.fillStyle='#2d7438';for(let i=0;i<60;i++){let x=rr(i)*32|0,y=rr(i+10)*32|0;ctx.fillRect(ox+x,oy+y,2,3)}ctx.fillStyle='#9eca65';for(let i=0;i<25;i++)ctx.fillRect(ox+(rr(i+100)*32|0),oy+(rr(i+90)*32|0),2,2)}
  if(id===6||id===14||id===17){ctx.fillStyle='#2d241f6e';for(let i=2;i<32;i+=7)ctx.fillRect(ox+i,oy,1,32);ctx.fillStyle='#e0b98b48';for(let i=5;i<32;i+=7)ctx.fillRect(ox+i,oy,2,32)}
  if(id===3||id===10||id===16||id===15||id===28){ctx.fillStyle='#161c2355';for(let i=0;i<32;i+=10)ctx.fillRect(ox,oy+i,32,2);for(let y=1;y<32;y+=10)for(let i=y%20===1?4:12;i<32;i+=16)ctx.fillRect(ox+i,oy+y,2,9)}
  if(id===4||id===8){ctx.fillStyle='#ffffff30';for(let i=0;i<14;i++)ctx.fillRect(ox+(rr(i+20)*30|0),oy+(rr(i+5)*30|0),4,2)}
  if(id===5||id===9){ctx.fillStyle='#d7faff55';for(let i=0;i<7;i++)ctx.fillRect(ox+3,oy+4+i*4,25,1)}
  if(id===7||id===24||id===26){ctx.fillStyle=id===24?'#edaa729e':'#c8ef8a78';for(let i=0;i<20;i++)ctx.fillRect(ox+(rr(i+9)*30|0),oy+(rr(i+56)*30|0),3,4)}
  if(id===12||id===25||id===27||id===18){ctx.shadowColor='#adfbff';ctx.shadowBlur=4;ctx.fillStyle=id===18?'#ffe8a4':'#b1fbff';for(let i=0;i<6;i++){let x=rr(i+12)*26|0,y=rr(i+71)*26|0;ctx.fillRect(ox+x+3,oy+y+3,2,5)}ctx.shadowBlur=0}
  if(id===11){ctx.fillStyle='#ffd64c';for(let i=0;i<20;i++)ctx.fillRect(ox+(rr(i+63)*29|0),oy+(rr(i+45)*29|0),2,4)}
  if(id===19||id===20){ctx.strokeStyle='#26262c';ctx.lineWidth=3;ctx.strokeRect(ox+2,oy+2,28,28);ctx.fillStyle='#ead2a1';ctx.fillRect(ox+14,oy+13,5,7)}
  if(id===30){ctx.strokeStyle='#e3fcffbb';ctx.lineWidth=3;ctx.strokeRect(ox+2,oy+2,27,27)}
 }
 return cv}
function compile(type,source){let s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s}
function program(v,f){let p=gl.createProgram();gl.attachShader(p,compile(gl.VERTEX_SHADER,v));gl.attachShader(p,compile(gl.FRAGMENT_SHADER,f));gl.linkProgram(p);if(!gl.getProgramParameter(p,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(p));return p}
function startGL(){try{gl=canvas.getContext('webgl',{alpha:false,antialias:false,depth:true,powerPreference:'high-performance'})||canvas.getContext('experimental-webgl');if(!gl)throw Error('WebGL non disponibile. Il convertitore APK deve abilitare WebGL e accelerazione hardware.');
 const skyV=`attribute vec2 aPos;varying vec2 vUv;void main(){vUv=(aPos+1.)*.5;gl_Position=vec4(aPos,0.,1.);}`;
 const skyF=`precision mediump float;varying vec2 vUv;uniform float uDay;uniform vec2 uSize;void main(){float h=smoothstep(.05,.95,vUv.y);vec3 top=mix(vec3(.028,.075,.16),vec3(.21,.48,.72),uDay);vec3 low=mix(vec3(.12,.18,.32),vec3(.68,.78,.70),uDay);vec3 c=mix(low,top,h);float sun=length((vUv-vec2(.79,.69))*vec2(uSize.x/uSize.y,1.));float glow=exp(-sun*15.)*.20*uDay;c+=vec3(1.,.70,.30)*glow;c+=vec3(.97,.76,.45)*smoothstep(.018,.006,sun)*uDay*.75;gl_FragColor=vec4(c,1.);}`;
 const voxelV=`attribute vec3 aPos;attribute vec2 aUV;attribute float aLight;uniform mat4 uProj,uView;varying vec2 vUV;varying float vL,vDistance;varying vec3 vWorld;void main(){vec4 v=uView*vec4(aPos,1.);gl_Position=uProj*v;vUV=aUV;vL=aLight;vDistance=length(v.xyz);vWorld=aPos;}`;
 const voxelF=`precision mediump float;uniform sampler2D uAtlas;uniform float uRadius,uDay,uTime,uAlpha;varying vec2 vUV;varying float vL,vDistance;varying vec3 vWorld;void main(){vec4 t=texture2D(uAtlas,vUV);vec3 lit=t.rgb*vL*mix(.35,1.10,uDay);float haze=clamp((vDistance-uRadius*.69)/(uRadius*.42),0.,1.);vec3 fog=mix(vec3(.13,.24,.35),vec3(.55,.72,.76),uDay);vec3 col=mix(lit,fog,haze*.88);gl_FragColor=vec4(col,uAlpha);}`;
 const mobV=`attribute vec3 aPos;attribute vec3 aColor;uniform mat4 uProj,uView;varying vec3 vColor;varying float vDist;void main(){vec4 v=uView*vec4(aPos,1.);gl_Position=uProj*v;vColor=aColor;vDist=length(v.xyz);}`;
 const mobF=`precision mediump float;varying vec3 vColor;varying float vDist;uniform float uFog,uDay;void main(){vec3 col=vColor*mix(.35,1.10,uDay);float f=clamp((vDist-uFog*.67)/(uFog*.4),0.,.9);gl_FragColor=vec4(mix(col,mix(vec3(.15,.25,.37),vec3(.55,.73,.76),uDay),f),1.);}`;
 let sky=program(skyV,skyF),vox=program(voxelV,voxelF),mob=program(mobV,mobF);
 function locs(p,names){let o={};for(const n of names)o[n]=n.startsWith('a')?gl.getAttribLocation(p,n):gl.getUniformLocation(p,n);return o}
 glState.sky={p:sky,l:locs(sky,['aPos','uDay','uSize'])};glState.vox={p:vox,l:locs(vox,['aPos','aUV','aLight','uProj','uView','uRadius','uDay','uTime','uAlpha','uAtlas'])};glState.mob={p:mob,l:locs(mob,['aPos','aColor','uProj','uView','uFog','uDay'])};
 glState.skyBuffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,glState.skyBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
 mobRenderBuffer=gl.createBuffer();glState.markerBuffer=gl.createBuffer();glState.atlas=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,glState.atlas);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.NEAREST);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,1);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,makeAtlas());
 gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.enable(gl.CULL_FACE);gl.cullFace(gl.BACK);
 canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();paused=true;notify('Contesto grafico perso, riavvia il gioco')});
 }catch(e){showError(e.message);return false}return true}
function textureFor(t,f){if(t===1){return f===0?1:f===1?2:2}if(t===6){return f<=1?14:6}if(t===13){return f===0?25:13}return Math.max(0,Math.min(30,t))}
function makeFace(out,x,y,z,t,f){let tex=textureFor(t,f),col=tex%8,row=Math.floor(tex/8);for(const q of TRI){let p=FACES[f].pts[q],uv=UV[q];const inset=.55,tx=(col*32+inset+uv[0]*(32-2*inset))/256,ty=(row*32+inset+uv[1]*(32-2*inset))/128;out.push(x+p[0],y+p[1],z+p[2],tx,ty,FACES[f].l)}}
function buildMesh(c){let solid=[],liquids=[],cx=c.cx,cz=c.cz;
 for(let y=0;y<WH;y++)for(let lz=0;lz<CS;lz++)for(let lx=0;lx<CS;lx++){
  let t=c.a[((y*CS)+lz)*CS+lx];if(!t)continue;let x=cx*CS+lx,z=cz*CS+lz,w=liquid(t),dest=w?liquids:solid;
  for(let f=0;f<6;f++){let d=FACES[f].d,adj=getBlock(x+d[0],y+d[1],z+d[2]);if(t===5||t===11){if(adj===t||adj&&adj!==5&&adj!==11)continue}else{if(adj&&adj!==5&&adj!==11&&adj!==24&&adj!==25&&adj!==26&&t!==24&&t!==25&&t!==26)continue;if(t===adj)continue}makeFace(dest,x,y,z,t,f)}
 }
 function makeBuf(a,old){let b=old||gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(a),gl.STATIC_DRAW);return {buffer:b,count:a.length/6}}
 c.solid=makeBuf(solid,c.solid?.buffer);c.fluid=makeBuf(liquids,c.fluid?.buffer);c.dirty=false}
function perspective(fov,aspect,near,far){let f=1/Math.tan(fov/2),m=new Float32Array(16);m[0]=f/aspect;m[5]=f;m[10]=(far+near)/(near-far);m[11]=-1;m[14]=2*far*near/(near-far);return m}
function camera(){let {x,y,z,yaw,pitch}=player,cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);let f=[sy*cp,sp,-cy*cp],r=[cy,0,sy],u=[-sy*sp,cp,cy*sp];viewDir=f;let m=new Float32Array(16);m[0]=r[0];m[4]=r[1];m[8]=r[2];m[1]=u[0];m[5]=u[1];m[9]=u[2];m[2]=-f[0];m[6]=-f[1];m[10]=-f[2];m[15]=1;m[12]=-(r[0]*x+r[1]*y+r[2]*z);m[13]=-(u[0]*x+u[1]*y+u[2]*z);m[14]=f[0]*x+f[1]*y+f[2]*z;return m}
function cube(out,x,y,z,sx,sy,sz,color){const rgb=[parseInt(color.slice(1,3),16)/255,parseInt(color.slice(3,5),16)/255,parseInt(color.slice(5,7),16)/255];for(let f=0;f<6;f++)for(let id of TRI){let p=FACES[f].pts[id];out.push(x+(p[0]-.5)*sx,y+p[1]*sy,z+(p[2]-.5)*sz,rgb[0]*FACES[f].l,rgb[1]*FACES[f].l,rgb[2]*FACES[f].l)}}
const RACES={
 elf:{head:'#eacfae',body:'#4b8b6a',legs:'#735c42',hostile:false,hp:16,speed:1.2,size:1},
 fairy:{head:'#f1e8cf',body:'#d3a4f1',legs:'#9b63b8',hostile:false,hp:8,speed:1.8,size:.53},
 dwarf:{head:'#c9a27b',body:'#6f8798',legs:'#695242',hostile:false,hp:22,speed:.85,size:.82},
 gnome:{head:'#d7b393',body:'#a77d48',legs:'#586c44',hostile:false,hp:12,speed:1.0,size:.64},
 goblin:{head:'#9bb74a',body:'#4b6233',legs:'#45362e',hostile:true,hp:14,speed:1.65,size:.78},
 troll:{head:'#899174',body:'#5d6053',legs:'#514b3c',hostile:true,hp:35,speed:.85,size:1.65},
 dragon:{head:'#b7464b',body:'#74314a',legs:'#46263a',hostile:true,hp:48,speed:1.3,size:2.4},
 icewolf:{head:'#dfebf1',body:'#8fa5c0',legs:'#64788e',hostile:true,hp:12,speed:1.8,size:.55},
 phoenix:{head:'#f7c142',body:'#cf542f',legs:'#78482d',hostile:false,hp:20,speed:1.7,size:1.2}
};
function renderMobs(now){let out=[];for(const m of activeMobs){if(m.hp<=0)continue;let meta=RACES[m.type]||RACES.elf,s=meta.size,px=m.x,py=m.y+(m.type==='fairy'?Math.sin(now*.004+m.wander)*.22+.6:0),pz=m.z;if(m.type==='dragon'||m.type==='icewolf'){
 cube(out,px,py+.35*s,pz,.9*s,.65*s,.5*s,meta.body);cube(out,px,py+.68*s,pz-.35*s,.52*s,.50*s,.55*s,meta.head);
 for(let dx of [-.30,.30])for(let dz of [-.25,.25])cube(out,px+dx*s,py,pz+dz*s,.21*s,.42*s,.20*s,meta.legs);
 if(m.type==='dragon'){let flap=Math.sin(now*.009+m.wander)*.13;cube(out,px-.65*s,py+(.35+flap)*s,pz,.70*s,.12*s,.75*s,'#a44b70');cube(out,px+.65*s,py+(.35+flap)*s,pz,.70*s,.12*s,.75*s,'#a44b70');cube(out,px,py+.43*s,pz+.58*s,.25*s,.2*s,.6*s,meta.body)}
 }else{cube(out,px,py+.62*s,pz,.56*s,.74*s,.36*s,meta.body);cube(out,px,py+1.22*s,pz,.57*s,.54*s,.54*s,meta.head);
  for(let a of [-.2,.2])cube(out,px+a*s,py+.06*s,pz,.19*s,.48*s,.26*s,meta.legs);
  for(let a of [-.38,.38])cube(out,px+a*s,py+.7*s,pz,.20*s,.67*s,.26*s,meta.head);
  if(m.type==='fairy'){cube(out,px-.38*s,py+.9*s,pz+.12*s,.35*s,.85*s,.08*s,'#97efea');cube(out,px+.38*s,py+.9*s,pz+.12*s,.35*s,.85*s,.08*s,'#97efea')}
  if(m.type==='gnome')cube(out,px,py+1.58*s,pz,.65*s,.29*s,.65*s,'#c54849');if(m.type==='goblin'){cube(out,px-.32*s,py+1.3*s,pz,.36*s,.15*s,.15*s,meta.head);cube(out,px+.32*s,py+1.3*s,pz,.36*s,.15*s,.15*s,meta.head)}
 }
 // Cubic black eye details on the forward facing head surface.
 cube(out,px-.15*s,py+(m.type==='dragon'?(.71*s):(1.28*s)),pz-.31*s,.075*s,.10*s,.035*s,'#112329');cube(out,px+.15*s,py+(m.type==='dragon'?(.71*s):(1.28*s)),pz-.31*s,.075*s,.10*s,.035*s,'#112329');
 }
 for(let p of particles)cube(out,p.x,p.y,p.z,.13,.13,.13,p.color);gl.bindBuffer(gl.ARRAY_BUFFER,mobRenderBuffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(out),gl.DYNAMIC_DRAW);mobCount=out.length/6}
function drawWorld(now){if(!gl)return;let dpr=Math.min(devicePixelRatio||1,1.6),factor=innerWidth<750?0.90:1,w=Math.floor(innerWidth*dpr*factor),h=Math.floor(innerHeight*dpr*factor);if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h;gl.viewport(0,0,w,h)}
 const day=clamp(.55+Math.sin(worldTime*.001)*.43,.13,1);
 gl.disable(gl.DEPTH_TEST);gl.disable(gl.CULL_FACE);let s=glState.sky;gl.useProgram(s.p);gl.uniform1f(s.l.uDay,day);gl.uniform2f(s.l.uSize,w,h);gl.bindBuffer(gl.ARRAY_BUFFER,glState.skyBuffer);gl.enableVertexAttribArray(s.l.aPos);gl.vertexAttribPointer(s.l.aPos,2,gl.FLOAT,false,0,0);gl.drawArrays(gl.TRIANGLES,0,3);gl.disableVertexAttribArray(s.l.aPos);
 gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.clear(gl.DEPTH_BUFFER_BIT);if(!active)return;
 let v=camera(),p=perspective(Math.PI/2.85,w/h,.07,(renderRadius+.8)*CS*1.42);let q=glState.vox;gl.useProgram(q.p);gl.uniformMatrix4fv(q.l.uView,false,v);gl.uniformMatrix4fv(q.l.uProj,false,p);gl.uniform1f(q.l.uRadius,renderRadius*CS+16);gl.uniform1f(q.l.uDay,day);gl.uniform1f(q.l.uTime,now*.001);gl.uniform1i(q.l.uAtlas,0);gl.activeTexture(gl.TEXTURE0);gl.bindTexture(gl.TEXTURE_2D,glState.atlas);
 const drawGroup=kind=>{for(let c of nearVisible){if(!c[kind]||!c[kind].count)continue;let entry=c[kind];gl.bindBuffer(gl.ARRAY_BUFFER,entry.buffer);gl.enableVertexAttribArray(q.l.aPos);gl.enableVertexAttribArray(q.l.aUV);gl.enableVertexAttribArray(q.l.aLight);gl.vertexAttribPointer(q.l.aPos,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(q.l.aUV,2,gl.FLOAT,false,24,12);gl.vertexAttribPointer(q.l.aLight,1,gl.FLOAT,false,24,20);gl.drawArrays(gl.TRIANGLES,0,entry.count)}};
 gl.uniform1f(q.l.uAlpha,1);drawGroup('solid');
 if(frameNo%3===0)renderMobs(now);let m=glState.mob;gl.useProgram(m.p);gl.uniformMatrix4fv(m.l.uView,false,v);gl.uniformMatrix4fv(m.l.uProj,false,p);gl.uniform1f(m.l.uFog,renderRadius*CS+16);gl.uniform1f(m.l.uDay,day);gl.bindBuffer(gl.ARRAY_BUFFER,mobRenderBuffer);gl.enableVertexAttribArray(m.l.aPos);gl.enableVertexAttribArray(m.l.aColor);gl.vertexAttribPointer(m.l.aPos,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(m.l.aColor,3,gl.FLOAT,false,24,12);gl.drawArrays(gl.TRIANGLES,0,mobCount);
 renderTargetLines(v,p,day);gl.useProgram(q.p);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.depthMask(false);gl.uniform1f(q.l.uAlpha,.70);nearVisible.sort((a,b)=>Math.hypot(b.cx*CS-player.x,b.cz*CS-player.z)-Math.hypot(a.cx*CS-player.x,a.cz*CS-player.z));drawGroup('fluid');gl.depthMask(true);gl.disable(gl.BLEND);
}
function renderTargetLines(view,projection,day){let target=rayBlock();if(!target)return;let [x,y,z]=target.p,arr=[],c=[.97,.83,.49],eps=.006;function line(a,b,col=c){arr.push(...a,...col,...b,...col)}
 let corners=[[0,0,0],[1,0,0],[1,1,0],[0,1,0],[0,0,1],[1,0,1],[1,1,1],[0,1,1]];
 for(let [a,b] of [[0,1],[1,2],[2,3],[3,0],[4,5],[5,6],[6,7],[7,4],[0,4],[1,5],[2,6],[3,7]]){
  line(corners[a].map((v,i)=>v+[x,y,z][i]+(v?eps:-eps)),corners[b].map((v,i)=>v+[x,y,z][i]+(v?eps:-eps)));
 }
 if(holdBreak&&breakTime>0){let steps=Math.min(16,Math.floor(breakTime*17)),face=0;
 for(let i=0;i<steps;i++){let xx=(rng(x*7+i,y+z,seed+401)*.75)+.12,zz=(rng(z*7+i,x+y,seed+402)*.75)+.12,nn=.14+(.10*(i%3));let color=[.19,.16,.12];line([x+xx,y+1.009,z+zz],[x+clamp(xx+nn,0,1),y+1.009,z+clamp(zz-nn*.6,0,1)],color)}
 }
 let buffer=new Float32Array(arr),m=glState.mob;gl.useProgram(m.p);gl.uniformMatrix4fv(m.l.uView,false,view);gl.uniformMatrix4fv(m.l.uProj,false,projection);gl.uniform1f(m.l.uFog,renderRadius*CS+16);gl.uniform1f(m.l.uDay,day);gl.bindBuffer(gl.ARRAY_BUFFER,glState.markerBuffer);gl.bufferData(gl.ARRAY_BUFFER,buffer,gl.DYNAMIC_DRAW);gl.enableVertexAttribArray(m.l.aPos);gl.enableVertexAttribArray(m.l.aColor);gl.vertexAttribPointer(m.l.aPos,3,gl.FLOAT,false,24,0);gl.vertexAttribPointer(m.l.aColor,3,gl.FLOAT,false,24,12);gl.drawArrays(gl.LINES,0,arr.length/6);
}
function streamChunks(){let cx=Math.floor(player.x/CS),cz=Math.floor(player.z/CS);let center=cx+','+cz+','+renderRadius;
 if(lastRegion!==center){lastRegion=center;let wanted=[];for(let dz=-renderRadius;dz<=renderRadius;dz++)for(let dx=-renderRadius;dx<=renderRadius;dx++){let dd=dx*dx+dz*dz;if(dd>(renderRadius+.18)**2)continue;let x=cx+dx,z=cz+dz,k=chunkKey(x,z);if(!chunks.has(k))wanted.push({x,z,dist:dd})}wanted.sort((a,b)=>a.dist-b.dist);queue=wanted;expectedLoad=wanted.length;loadCount=0}
 let quota=loading?2:1;while(quota-->0&&queue.length){let q=queue.shift(),id=chunkKey(q.x,q.z);if(chunks.has(id))continue;let c=createChunk(q.x,q.z);chunks.set(id,c);for(let dx=-1;dx<=1;dx++)for(let dz=-1;dz<=1;dz++){let a=getChunk(q.x+dx,q.z+dz);if(a)a.dirty=true}spawnMobs(c);loadCount++}
 if(frameNo%20===0)for(let [key,c] of chunks){if(Math.abs(c.cx-cx)>renderRadius+1||Math.abs(c.cz-cz)>renderRadius+1){if(c.solid)gl.deleteBuffer(c.solid.buffer);if(c.fluid)gl.deleteBuffer(c.fluid.buffer);chunks.delete(key)}}
 let meshQuota=loading?3:1,near=[];for(let dz=-renderRadius;dz<=renderRadius;dz++)for(let dx=-renderRadius;dx<=renderRadius;dx++){if(dx*dx+dz*dz>(renderRadius+.18)**2)continue;let c=getChunk(cx+dx,cz+dz);if(c){near.push(c);if(meshQuota&&c.dirty){buildMesh(c);meshQuota--}}}
 nearVisible=near;
 if(loading){let pct=expectedLoad?Math.floor((loadCount/expectedLoad)*100):100;$('loadingText').textContent='Preparazione del mondo • '+pct+'%';$('loadingBar').style.width=pct+'%';if(!queue.length&&nearVisible.length>0){loading=false;$('loading').classList.add('hidden');notify('Benvenuto nel regno! Cerca gli insediamenti e raccogli risorse.')}}
}
function spawnMobs(c){if(c.mobSeeded)return;c.mobSeeded=true;let prob=rng(c.cx,c.cz,seed+901);if(prob>.56)return;let x=c.cx*CS+3+Math.floor(rng(c.cx,c.cz,seed+902)*9),z=c.cz*CS+3+Math.floor(rng(c.cx,c.cz,seed+903)*9),h=heightAt(x,z),b=biomeAt(x,z);if(h<=SEA-1)return;
 let primary=BIOMES[b].race,extra=b===2||b===4?'dragon':b===1?'fairy':b===7?'troll':b===3?'icewolf':b===0?'elf':b===5?'gnome':'goblin';let special=rng(c.cx,c.cz,seed+904),type=special>.91?extra:primary;if(special>.965&&b===4)type='phoenix';let id=chunkKey(c.cx,c.cz)+'@'+Math.floor(special*10000);if(killed[id])return;
 activeMobs.push({id,x:x+.5,y:h+1,z:z+.5,type,hp:RACES[type].hp,age:0,wander:rng(c.cx,c.cz,seed+956)*6.3,turn:0,attack:0});if(activeMobs.length>28)activeMobs.shift()}
function walkCollision(x,foot,z){for(let dx of [-.24,.24])for(let dz of [-.24,.24])for(let dy of [.12,.96,1.66])if(inSolid(getBlock(x+dx,foot+dy,z+dz)))return true;return false}
function landAt(x,z){return heightAt(Math.floor(x),Math.floor(z))+1}
function jump(){if(active&&!paused&&player.ground){player.vy=7.25;player.ground=false;swingHand()}}
function takeDamage(n,label){if(!active||paused||n<=0)return;player.hp=Math.max(0,player.hp-n);$('hitFlash').style.opacity='.68';setTimeout(()=>$('hitFlash').style.opacity='0',190);notify(label+' −'+n+' ❤');worldChanged=true;if(player.hp===0)respawn()}
function respawn(){player.x=5.5;player.z=5.5;player.y=heightAt(5,5)+4;player.vy=0;player.hp=20;player.hunger=17;player.air=12;player.fire=0;notify('Ti sei risvegliato vicino al punto di partenza');}
function updatePlayer(dt){let ax=movePad.x,az=-movePad.y;if(keys.KeyW||keys.ArrowUp)az++;if(keys.KeyS||keys.ArrowDown)az--;if(keys.KeyA||keys.ArrowLeft)ax--;if(keys.KeyD||keys.ArrowRight)ax++;let len=Math.hypot(ax,az);if(len>1){ax/=len;az/=len}
 let sprint=!!keys.ShiftLeft||(len>.93&&player.hunger>5),speed=(sprint?5.4:3.6)*dt;let dx=(Math.cos(player.yaw)*ax+Math.sin(player.yaw)*az)*speed,dz=(Math.sin(player.yaw)*ax-Math.cos(player.yaw)*az)*speed;
 let foot=player.y-1.62,before=player.vy,fy=foot;let submerged=liquid(getBlock(player.x,player.y,player.z));if(submerged===5)player.vy=Math.max(player.vy-4*dt,-2.6);else player.vy=Math.max(player.vy-21*dt,-23);
 if(getChunk(Math.floor((player.x+dx)/CS),Math.floor(player.z/CS))&&!walkCollision(player.x+dx,foot,player.z))player.x+=dx;
 if(getChunk(Math.floor(player.x/CS),Math.floor((player.z+dz)/CS))&&!walkCollision(player.x,foot,player.z+dz))player.z+=dz;
 player.ground=false;let next=foot+player.vy*dt;
 if(player.vy<0){let hits=false;for(let xx of [-.23,.23])for(let zz of [-.23,.23])for(let yy=Math.floor(next);yy<=Math.floor(foot+.03);yy++)if(inSolid(getBlock(player.x+xx,yy,player.z+zz))){next=Math.max(next,yy+1);hits=true}
  if(hits){player.ground=true;player.vy=0;if(before< -11)takeDamage(Math.floor((Math.abs(before)-9)*.58),'Danno da caduta')}}
 else if(walkCollision(player.x,next,player.z)){next=foot;player.vy=0}
 player.y=next+1.62;if(player.y<-4)respawn();
 // Drowning, lava and fire, hunger, starvation, health regeneration.
 let head=getBlock(player.x,player.y-.07,player.z),body=getBlock(player.x,player.y-1.0,player.z);if(head===5){player.air-=dt;if(player.air<=0){player.air=0;player.regen+=dt;if(player.regen>1.5){takeDamage(2,'Annegamento');player.regen=0}}}else player.air=Math.min(12,player.air+dt*3);
 if(head===11||body===11){player.fire=3.5;player.regen+=dt;if(player.regen>1){takeDamage(3,'Lava');player.regen=0}}else if(player.fire>0){player.fire=Math.max(0,player.fire-dt);player.regen+=dt;if(player.regen>2){takeDamage(1,'Bruciatura');player.regen=0}}
 let effort=len>0?sprint?.0013:.0007:.00012;player.hunger=Math.max(0,player.hunger-effort*dt*60);if(player.hunger<=0){player.regen+=dt;if(player.regen>5){takeDamage(1,'Fame');player.regen=0}}else if(player.hunger>17&&player.hp<20){player.regen+=dt;if(player.regen>5){player.hp=Math.min(20,player.hp+1);player.hunger=Math.max(0,player.hunger-.12);player.regen=0}}
}
function updateMobs(dt){for(const m of activeMobs){if(m.hp<=0)continue;let d=Math.hypot(player.x-m.x,player.z-m.z);if(d>renderRadius*CS*.97)continue;let r=RACES[m.type],chase=r.hostile&&d<13&&player.hp>0,dir=chase?Math.atan2(player.z-m.z,player.x-m.x):m.wander;
 m.age+=dt;m.turn-=dt;if(m.turn<=0){m.turn=3+3*rng(Math.floor(m.x),Math.floor(m.z),seed+Math.floor(m.age));m.wander=rng(Math.floor(m.x*2),Math.floor(m.z*2),seed+Math.floor(m.age))*Math.PI*2}
 if(d>.9){let walk=(chase?1:.26)*r.speed*dt,nx=m.x+Math.cos(dir)*walk,nz=m.z+Math.sin(dir)*walk;
 if(getChunk(Math.floor(nx/CS),Math.floor(nz/CS))&&inSolid(getBlock(nx,landAt(nx,nz)-1,nz))){let ground=landAt(nx,nz);if(Math.abs(ground-m.y)<2.5){m.x=nx;m.z=nz;m.y=mix(m.y,ground,.17)}}}
 m.attack-=dt;if(chase&&d<1.6*r.size&&m.attack<=0){m.attack=m.type==='dragon'?2.4:1.6;takeDamage(m.type==='dragon'?5:m.type==='troll'?4:2,'Attacco di '+raceName(m.type));if(m.type==='dragon')player.fire=2}
 }
 activeMobs=activeMobs.filter(m=>m.hp>0&&Math.hypot(m.x-player.x,m.z-player.z)<renderRadius*CS+25)}
function raceName(t){return ({elf:'Elfo',fairy:'Fata',dwarf:'Nano',gnome:'Gnomo',goblin:'Goblin',troll:'Troll',dragon:'Drago',icewolf:'Lupo dei ghiacci',phoenix:'Fenice'})[t]||t}
function rayBlock(range=6){let x=player.x,y=player.y,z=player.z,cp=Math.cos(player.pitch),dx=Math.sin(player.yaw)*cp,dy=Math.sin(player.pitch),dz=-Math.cos(player.yaw)*cp,last=null,old='';for(let i=.06;i<range;i+=.07){let tx=Math.floor(x+dx*i),ty=Math.floor(y+dy*i),tz=Math.floor(z+dz*i),id=blockKey(tx,ty,tz);if(old===id)continue;old=id;let t=getBlock(tx,ty,tz);if(t&&t!==5){return {p:[tx,ty,tz],adj:last,type:t,dist:i}}last=[tx,ty,tz]}return null}
function mobAtCross(){let best=null,dist=6;let f=viewDir;for(let m of activeMobs){let size=RACES[m.type].size*1.2,px=m.x-player.x,py=m.y+size*.8-player.y,pz=m.z-player.z,d=px*f[0]+py*f[1]+pz*f[2];if(d<=0||d>dist)continue;let a=Math.hypot(px-f[0]*d,py-f[1]*d,pz-f[2]*d);if(a<Math.max(.42,size*.6)){dist=d;best=m}}return best}
function attack(){if(!active||paused)return;let m=mobAtCross();swingHand();if(!m){notify('Nessuna creatura a portata');return}let d=Math.hypot(m.x-player.x,m.z-player.z);if(d>4.8){notify('Troppo lontano');return}let weapon=slots[chosen]===35||inventory[35]>0&&slots[chosen]===35;let damage=weapon?9:4;m.hp-=damage;notify(raceName(m.type)+' −'+damage+' ❤');if(m.hp<=0){killed[m.id]=true;let drop=m.type==='goblin'?21:m.type==='dragon'?12:32;inventory[drop]=(inventory[drop]||0)+(m.type==='dragon'?5:1);notify(raceName(m.type)+' sconfitto · ricompensa: '+ITEMS[drop][0]);updateHotbar();worldChanged=true}}
function useFood(){let type=slots[chosen]===31||slots[chosen]===33||slots[chosen]===32?slots[chosen]:inventory[31]>0?31:inventory[33]>0?33:32;
 if(!(inventory[type]>0)){notify('Non hai cibo. Raccogli carne o prepara pane.');return}if(player.hunger>=20){notify('Sei già sazio');return}inventory[type]--;player.hunger=clamp(player.hunger+(type===33?8:type===31?6:3),0,20);worldChanged=true;updateHotbar();notify('Hai mangiato: '+ITEMS[type][0])}
function startBreaking(){if(!active||paused||$('modal').classList.contains('hidden')===false)return;holdBreak=true;breakTime=0;breakAt='';$('btnBreak').style.background='#8b6e49ad'}
function stopBreaking(){holdBreak=false;breakTime=0;breakAt='';$('btnBreak').style.background='';$('breakRing').style.setProperty('--percent','0%')}
function updateBreaking(dt){if(!holdBreak||!active||paused)return;let hit=rayBlock();if(!hit||hit.p[1]===0||hit.type===23){stopBreaking();return}let id=hit.p.join(',');if(id!==breakAt){breakAt=id;breakTime=0}let hardness=ITEMS[hit.type]?.[2]||1;let tool=slots[chosen]===36?2.5:1;breakTime+=dt*tool;let percentage=clamp(breakTime/(hardness*.62),0,1);$('breakRing').style.setProperty('--percent',(percentage*100)+'%');if(percentage>=1){breakBlock(hit);breakTime=0;breakAt='';swingHand()}}
function breakBlock(hit){let [x,y,z]=hit.p,t=hit.type;if(t===23&&y===0)return;let obtained=t===1?2:t===21?21:t===22?22:t===16?3:t;inventory[obtained]=(inventory[obtained]||0)+1;if(t===19)delete containers[hit.p.join(',')];setBlock(x,y,z,0);spawnParticles(x+.5,y+.5,z+.5,t);updateHotbar();notify('+'+ITEMS[obtained][0]);worldChanged=true}
function openContainer(hit){let id=hit.p.join(','),store=containers[id]||(containers[id]={});showModal(hit.type===19?'Cassa del regno':'Fornace',hit.type===19?renderStorage(id,store):renderFurnace(id,store))}
function place(){if(!active||paused)return;let hit=rayBlock();if(!hit){notify('Guarda un blocco vicino');return}if(hit.type===19||hit.type===20){openContainer(hit);return}let id=slots[chosen];if(id>MAX_BLOCK||id===0||id===5||id===11||id===23){notify('Seleziona un blocco dall’inventario');return}if(!(inventory[id]>0)){notify('Non hai '+ITEMS[id][0]);return}if(!hit.adj){notify('Non puoi piazzare qui');return}let [x,y,z]=hit.adj;if(y<1||y>WH-2)return;
 if(Math.abs(player.x-x-.5)<.85&&Math.abs(player.z-z-.5)<.85&&y<player.y+.2&&y+1>player.y-1.62){notify('Non puoi piazzare dentro il personaggio');return}
 if(getBlock(x,y,z)&&getBlock(x,y,z)!==5)return;if(setBlock(x,y,z,id)){inventory[id]--;updateHotbar();swingHand();notify(ITEMS[id][0]+' piazzato')}}
function spawnParticles(x,y,z,t){for(let i=0;i<10;i++){let a=i*Math.PI*.6;particles.push({x,y,z,vx:Math.cos(a)*1.5,vy:1.0+(i%4)*.38,vz:Math.sin(a)*1.5,life:.6,color:t===10?'#66616a':t===1?'#599d5d':t===4?'#d8c28e':'#a8a49c'})}}
function updateParticles(dt){for(let p of particles){p.x+=p.vx*dt;p.z+=p.vz*dt;p.y+=p.vy*dt;p.vy-=14*dt;p.life-=dt}particles=particles.filter(p=>p.life>0).slice(-65)}
function swingHand(){$('hand').classList.remove('swing');void $('hand').offsetWidth;$('hand').classList.add('swing')}
function notify(v){let e=$('notify');e.textContent=v;e.style.opacity=1;clearTimeout(notify.timer);notify.timer=setTimeout(()=>e.style.opacity=0,1900)}
function updateHUD(){if(!active)return;let b=biomeAt(player.x,player.z),bi=BIOMES[b];$('hudBiome').textContent=bi.name+' · '+bi.tag;$('coordInfo').textContent=[player.x|0,player.y|0,player.z|0].join(' · ');let hearts='',food='';for(let i=0;i<10;i++)hearts+='<span'+(player.hp<(i+1)*2?' class="dim"':'')+'>❤</span>';for(let i=0;i<10;i++)food+='<span'+(player.hunger<(i+1)*2?' class="dim"':'')+'>◆</span>';$('healthPips').innerHTML=hearts;$('foodPips').innerHTML=food;$('foodPips').style.color='#dfad5d';$('healthPips').style.color='#f5817b';let hit=rayBlock();$('blockHint').textContent=hit?(ITEMS[hit.type]?.[0]||'Blocco'):'';if(player.air<12)$('blockHint').textContent='ARIA '+Math.ceil(player.air)+'s'}
function updateHotbar(){$('hotbar').replaceChildren();slots.forEach((id,i)=>{let b=document.createElement('button');b.className='slot'+(chosen===i?' active':'');b.setAttribute('aria-label',ITEMS[id]?.[0]||'Vuoto');let icon=document.createElement('div');icon.className='slot-icon';icon.textContent=ITEMS[id]?.[1]||'·';let count=document.createElement('div');count.className='slot-count';count.textContent=(inventory[id]||0)||'–';b.append(icon,count);b.onclick=()=>{chosen=i;updateHotbar();worldChanged=true};$('hotbar').append(b)})}
function showModal(title,body){paused=true;holdBreak=false;$('modalTitle').textContent=title;$('modalBody').replaceChildren();$('modalBody').append(body);$('modal').classList.remove('hidden')}
function closeModal(){$('modal').classList.add('hidden');paused=false;saveWorld()}
function el(tag,cls,content){let v=document.createElement(tag);if(cls)v.className=cls;if(content!==undefined)v.textContent=content;return v}
function itemButton(id,count,onClick){let b=el('button','item'),ic=el('div','itememoji',ITEMS[id]?.[1]||'📦'),name=el('small','',ITEMS[id]?.[0]||'Oggetto'),num=el('b','',String(count));b.append(ic,name,num);b.onclick=onClick;return b}
function listing(of,action){let grid=el('div','item-grid');for(let id=1;id<ITEMS.length;id++)if((of[id]||0)>0)grid.append(itemButton(id,of[id],()=>action(id)));if(!grid.children.length)grid.textContent='Nessun oggetto';return grid}
function renderInventory(tab=invTab){invTab=tab;let div=el('div');let tabs=el('div','tabs');for(let [key,text] of [['oggetti','Inventario'],['craft','Creazione']]){let b=el('button',key===tab?'active':'',text);b.onclick=()=>showModal('Inventario',renderInventory(key));tabs.append(b)}div.append(tabs);
 if(tab==='oggetti'){div.append(el('div','modal-section','Tocca un oggetto per equipaggiarlo nello slot selezionato'));div.append(listing(inventory,id=>{slots[chosen]=id;updateHotbar();showModal('Inventario',renderInventory('oggetti'));notify('Equipaggiato: '+ITEMS[id][0])}));div.append(el('div','modal-section','Oggetti equipaggiati'));let p=el('p','',slots.map((id,i)=>i+1+': '+ITEMS[id][0]).join(' · '));p.style.fontSize='11px';div.append(p)}
 else{let list=el('div','recipe-list');for(const recipe of RECIPES){let b=el('button','recipe',recipe.title),details=Object.entries(recipe.need).map(([id,n])=>ITEMS[id][0]+' ×'+n).join(' + ');b.append(el('small','',details));b.onclick=()=>{if(!Object.entries(recipe.need).every(([id,n])=>(inventory[id]||0)>=n)){notify('Materiali insufficienti');return}for(let [id,n] of Object.entries(recipe.need))inventory[id]-=n;inventory[recipe.out]=(inventory[recipe.out]||0)+recipe.n;worldChanged=true;updateHotbar();showModal('Inventario',renderInventory('craft'));notify('Creato: '+recipe.title)};list.append(b)}div.append(list)}return div}
function renderStorage(pos,store){let div=el('div','storage');let left=el('div'),right=el('div');left.append(el('h3','','Zaino → Cassa'));left.append(listing(inventory,id=>{store[id]=(store[id]||0)+1;inventory[id]--;worldChanged=true;updateHotbar();showModal('Cassa del regno',renderStorage(pos,store))}));right.append(el('h3','','Cassa → Zaino'));right.append(listing(store,id=>{inventory[id]=(inventory[id]||0)+1;store[id]--;worldChanged=true;updateHotbar();showModal('Cassa del regno',renderStorage(pos,store))}));div.append(left,right);return div}
function renderFurnace(pos,store){let div=el('div');div.append(el('p','','Per fondere il ferro grezzo servono carbone e minerale; per cuocere la carne serve carbone. Il processo è istantaneo in questa alpha.'));let choices=[{name:'Fondi 1 ferro',need:{22:1,21:1},output:34},{name:'Cuoci 1 carne',need:{32:1,21:1},output:33}];for(const c of choices){let b=el('button','modal-action',c.name);b.onclick=()=>{if(!Object.entries(c.need).every(([id,n])=>(inventory[id]||0)>=n)){notify('Mancano materiali o combustibile');return}for(let [id,n] of Object.entries(c.need))inventory[id]-=n;inventory[c.output]=(inventory[c.output]||0)+1;worldChanged=true;updateHotbar();showModal('Fornace',renderFurnace(pos,store));notify('Fusione completata')};div.append(b)}return div}
function renderPause(){let div=el('div');div.append(el('p','','Progressi salvati automaticamente. Puoi regolare la distanza di renderizzazione per bilanciare grafica e prestazioni.'));div.append(el('div','modal-section','Distanza di renderizzazione'));let select=el('select');for(let r of [2,3,4]){let o=el('option','',r===2?'Breve • più FPS (circa 40 m)':r===3?'Media • consigliata (circa 56 m)':'Lunga • più dettagli (circa 72 m)');o.value=r;if(r===renderRadius)o.selected=true;select.append(o)}select.style.cssText='width:100%;padding:8px;background:#153442;color:#fff5da;margin-bottom:10px';select.onchange=()=>{renderRadius=+select.value;lastRegion='';game.renderRadius=renderRadius;worldChanged=true};div.append(select);
 const p=el('div','pause-buttons'),resume=el('button','','Riprendi il gioco'),home=el('button','leave','Salva ed esci');resume.onclick=closeModal;home.onclick=()=>{saveWorld();$('modal').classList.add('hidden');backToMenu()};p.append(resume,home);div.append(p);div.append(el('p','','Comandi: joystick sinistro, trascina la visuale a destra, tieni premuto SCAVA, tocca PIAZZA, SALTA, ATTACCA, INVENTARIO.'));return div}
function safeLoad(id){try{let raw=localStorage.getItem(SAVE_PREFIX+'world_'+id);return raw?JSON.parse(raw):null}catch(e){return null}}
function getIndex(){try{return JSON.parse(localStorage.getItem(SAVE_PREFIX+'index')||'[]')}catch(e){return []}}
function updateMenu(){let list=$('worldList');list.replaceChildren();let ids=getIndex();if(!ids.length){list.append(el('p','','Non ci sono mondi. Crea la tua prima avventura!'));return}for(let id of ids){let w=safeLoad(id);if(!w)continue;let entry=el('div','world-entry'),info=el('div'),title=el('b','',w.name),bi=BIOMES[w.startBiome]||BIOMES[0],meta=el('small','',bi.name+' · '+new Date(w.saved||Date.now()).toLocaleDateString('it-IT'));info.append(title,meta);
 let actions=el('div','world-action'),play=el('button','','Gioca'),del=el('button','delete','✕');play.onclick=()=>startWorld(w);del.onclick=()=>{if(confirm('Eliminare il mondo "'+w.name+'"? Questa operazione è irreversibile.')){localStorage.removeItem(SAVE_PREFIX+'world_'+id);localStorage.setItem(SAVE_PREFIX+'index',JSON.stringify(ids.filter(v=>v!==id)));updateMenu()}};actions.append(play,del);entry.append(info,actions);list.append(entry)}}
function saveWorld(){if(!game||!active)return;try{game.saved=Date.now();game.edits=edits;game.inventory=inventory;game.containers=containers;game.killed=killed;game.slots=slots;game.chosen=chosen;game.worldTime=worldTime;game.player={...player,vy:0,ground:false};game.renderRadius=renderRadius;localStorage.setItem(SAVE_PREFIX+'world_'+game.id,JSON.stringify(game));let ids=getIndex();if(!ids.includes(game.id)){ids.unshift(game.id);localStorage.setItem(SAVE_PREFIX+'index',JSON.stringify(ids))}worldChanged=false}catch(e){let reason=e&&e.name==='SecurityError'?'Salvataggi bloccati dal convertitore: abilita DOM Storage':e&&e.name==='QuotaExceededError'?'Memoria del dispositivo esaurita':'Salvataggio locale non disponibile';notify(reason);console.warn('Save failed',e)}}
function backToMenu(){saveWorld();active=false;paused=false;loading=false;$('mainMenu').classList.remove('hidden');$('hud').classList.add('hidden');$('loading').classList.add('hidden');document.body.classList.remove('playing');$('rotateOverlay').classList.add('hidden');chunks.forEach(c=>{if(c.solid)gl.deleteBuffer(c.solid.buffer);if(c.fluid)gl.deleteBuffer(c.fluid.buffer)});chunks.clear();activeMobs=[];particles=[];queue=[];game=null;updateMenu()}
function initWorld(name,startBiome,seedValue){let id=Date.now().toString(36)+'-'+Math.floor(Math.random()*100000);return {v:VERSION,id,name,startBiome,seed:seedValue,saved:Date.now(),edits:{},inventory:{...DEFAULT_INV},containers:{},killed:{},slots:SLOTS_INIT.slice(),chosen:0,worldTime:800,renderRadius:3,player:{x:5.5,y:heightAt(5,5,startBiome)+5,z:5.5,yaw:2.3,pitch:-.15,vy:0,hp:20,hunger:20,ground:false,fall:0,air:12,fire:0,regen:0}}}
function startWorld(w){game=w;seed=w.seed;edits=w.edits||{};containers=w.containers||{};killed=w.killed||{};inventory=w.inventory||{...DEFAULT_INV};slots=w.slots?.slice()||SLOTS_INIT.slice();chosen=w.chosen||0;worldTime=w.worldTime||800;renderRadius=w.renderRadius||3;player={...player,...w.player,vy:0,ground:false,air:w.player?.air??12,fire:0};
 if(!w.player){player.x=5.5;player.z=5.5;player.y=heightAt(5,5,w.startBiome)+5} // BiomeAt is valid after game assignment.
 gl.bindTexture(gl.TEXTURE_2D,glState.atlas);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,makeAtlas());
 active=true;paused=false;loading=true;chunks.clear();queue=[];activeMobs=[];particles=[];lastRegion='';nearVisible=[];frameNo=0;loadCount=0;expectedLoad=1;
 $('hudWorld').textContent=w.name;$('mainMenu').classList.add('hidden');$('hud').classList.remove('hidden');$('loading').classList.remove('hidden');document.body.classList.add('playing');updateHotbar();updateRotation();try{if(screen.orientation?.lock)screen.orientation.lock('landscape').catch(()=>{})}catch(e){}saveWorld()}
function updateRotation(){let portrait=innerHeight>innerWidth;let show=active&&portrait;$('rotateOverlay').classList.toggle('hidden',!show);if(portrait)stopBreaking()}
function readSeed(v){if(!v.trim())return (Math.random()*2147483000)|0;if(/^-?\d+$/.test(v.trim()))return Number(v.trim())|0;let n=0;for(const ch of v)n=(n*31+ch.charCodeAt(0))|0;return n}
function checkActive(){return active&&!paused&&!loading&&!($('rotateOverlay').classList.contains('hidden')===false)}
function frame(t){requestAnimationFrame(frame);let dt=clamp((t-lastNow)/1000||.016,0,.045);lastNow=t;frameNo++;
 try{if(active){streamChunks();if(!paused&&!loading&&$('rotateOverlay').classList.contains('hidden')){worldTime+=dt;updatePlayer(dt);updateMobs(dt);updateParticles(dt);updateBreaking(dt);if(frameNo%14===0)updateHUD();if(t>saveNext){saveWorld();saveNext=t+5000}}}drawWorld(t)}catch(e){console.error(e);showError('Errore durante il gioco: '+e.message)}}
function showError(message){$('errorMessage').textContent=message;$('error').classList.remove('hidden');paused=true}
function controls(){const pad=$('joystick'),knob=$('joystickKnob');function updatePad(e){let r=pad.getBoundingClientRect(),xx=e.clientX-(r.left+r.width/2),yy=e.clientY-(r.top+r.height/2),lim=r.width*.33,m=Math.hypot(xx,yy);if(m>lim){xx=xx*lim/m;yy=yy*lim/m}movePad.x=xx/lim;movePad.y=yy/lim;knob.style.transform=`translate(calc(-50% + ${xx}px),calc(-50% + ${yy}px))`}
 pad.addEventListener('pointerdown',e=>{if(!checkActive())return;padPointer=e.pointerId;pad.setPointerCapture(e.pointerId);updatePad(e)});pad.addEventListener('pointermove',e=>{if(e.pointerId===padPointer)updatePad(e)});function endPad(e){if(padPointer!==e.pointerId)return;padPointer=null;movePad.x=movePad.y=0;knob.style.transform='translate(-50%,-50%)'}pad.addEventListener('pointerup',endPad);pad.addEventListener('pointercancel',endPad);
 canvas.addEventListener('pointerdown',e=>{if(!checkActive())return;lookPointer={id:e.pointerId,x:e.clientX,y:e.clientY,at:Date.now(),travel:0};canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',e=>{if(!checkActive()||!lookPointer||e.pointerId!==lookPointer.id)return;let dx=e.clientX-lookPointer.x,dy=e.clientY-lookPointer.y;lookPointer.travel+=Math.abs(dx)+Math.abs(dy);player.yaw+=dx*.0045;player.pitch=clamp(player.pitch-dy*.0045,-1.44,1.44);lookPointer.x=e.clientX;lookPointer.y=e.clientY});canvas.addEventListener('pointerup',e=>{if(!lookPointer||e.pointerId!==lookPointer.id)return;if(lookPointer.travel<9&&e.pointerType==='mouse')startBreaking();lookPointer=null});
 const b=$('btnBreak');b.addEventListener('pointerdown',e=>{if(!checkActive())return;e.preventDefault();b.setPointerCapture(e.pointerId);startBreaking()});b.addEventListener('pointerup',stopBreaking);b.addEventListener('pointercancel',stopBreaking);window.addEventListener('pointerup',e=>{if(e.target!==b&&holdBreak&&e.pointerType!=='mouse')stopBreaking()});
 $('btnPlace').onclick=()=>{if(checkActive())place()};$('btnJump').onclick=()=>{if(checkActive())jump()};$('btnAttack').onclick=()=>{if(checkActive())attack()};$('btnEat').onclick=()=>{if(checkActive())useFood()};$('btnInventory').onclick=()=>{if(active&&!loading)showModal('Inventario',renderInventory())};$('openPause').onclick=()=>{if(!active)return;saveWorld();showModal('Pausa',renderPause())};$('modalClose').onclick=closeModal;
 window.addEventListener('keydown',e=>{keys[e.code]=true;if(!checkActive())return;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='Space')jump();if(e.code==='KeyE')showModal('Inventario',renderInventory());if(e.code==='KeyQ')useFood();if(e.code==='KeyF')attack();if(e.code==='KeyR')place();if(e.code==='Escape')showModal('Pausa',renderPause());if(e.code==='KeyB')startBreaking();if(/^Digit[1-7]$/.test(e.code)){chosen=+e.code.slice(-1)-1;updateHotbar()}});window.addEventListener('keyup',e=>{keys[e.code]=false;if(e.code==='KeyB')stopBreaking()});window.addEventListener('contextmenu',e=>e.preventDefault());canvas.addEventListener('mousedown',e=>{if(e.button===0&&checkActive())startBreaking();else if(e.button===2&&checkActive())place()});window.addEventListener('mouseup',stopBreaking);
 window.addEventListener('blur',()=>{keys={};movePad={x:0,y:0};stopBreaking();if(active)saveWorld()});document.addEventListener('visibilitychange',()=>{if(document.hidden&&active)saveWorld()});window.addEventListener('pagehide',()=>{if(active)saveWorld()});window.addEventListener('resize',updateRotation);
 $('createWorld').onclick=()=>{let name=$('worldName').value.trim()||'Il mio regno',b=Number($('startBiome').value),s=readSeed($('worldSeed').value);seed=s;game={startBiome:b};let w=initWorld(name,b,s);startWorld(w)};
 $('errorHome').onclick=()=>{$('error').classList.add('hidden');if(active)backToMenu()};
}
if(startGL()){controls();updateMenu();requestAnimationFrame(frame)}
})();
