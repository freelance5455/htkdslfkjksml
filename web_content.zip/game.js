(() => {
'use strict';

// ---------- Налаштування ----------
const CFG = {
  modelPath: 'models/bmw e34 540i.gltf',
  carLength: 4.8,     // довжина машини в метрах (модель масштабується сама)
  flipFront: true,    // постав false, якщо машина знову їде задом наперед
  maxSpeed: 250 / 3.6,                  // м/с (максимум машини 120 км/г)
  gearMax: [30, 45, 65, 85, 250],       // ліміт швидкості кожної передачі, км/г
  reverseMax: 25,                       // ліміт задньої передачі, км/г
  walkSpeed: 4.5,
  lookSens: 0.005,
  dayLengthSec: 480,   // скільки реальних секунд триває доба (висока графіка)
  startHour: 11        // о котрій годині починається гра
};

const $ = id => document.getElementById(id);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };

// ---------- Налаштування гравця (зберігаються в браузері) ----------
const SETTINGS_KEY = 'whiteDriveSettings';
const SETTINGS = { quality: 'low', sens: 1 };   // quality: 'low' | 'high'
try { Object.assign(SETTINGS, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')); } catch (e) {}
if (SETTINGS.quality !== 'high') SETTINGS.quality = 'low';
SETTINGS.sens = clamp(+SETTINGS.sens || 1, 0.3, 3);
const BASE_LOOK_SENS = CFG.lookSens;
CFG.lookSens = BASE_LOOK_SENS * SETTINGS.sens;
function saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(SETTINGS)); } catch (e) {} }
const isTouch = !!(window.matchMedia && matchMedia('(pointer: coarse)').matches);

// ---------- Сцена ----------
const canvas = $('c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const SKY_COLOR = 0x8c939a;   // сірий колір обрію, у який «тане» поле
scene.background = new THREE.Color(SKY_COLOR);
scene.fog = new THREE.Fog(SKY_COLOR, 60, 420);

const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 600);
camera.rotation.order = 'YXZ';
scene.add(camera);   // камера в сцені, щоб мотор у руках малювався

function resize() {
  renderer.setSize(innerWidth, innerHeight, false);
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize);
resize();

const hemi = new THREE.HemisphereLight(0xffffff, 0xdddddd, 1.0);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffffff, 0.35);   // сонце вдень, місяць уночі
sun.position.set(30, 60, 20);
scene.add(sun);
scene.add(sun.target);
// Тіні (висока графіка): тіньова карта їздить разом з гравцем. Якщо гальмує - зменш size або range
const SHADOW = { range: isTouch ? 30 : 38, size: isTouch ? 1024 : 2048 };
sun.shadow.mapSize.set(SHADOW.size, SHADOW.size);
Object.assign(sun.shadow.camera, { left: -SHADOW.range, right: SHADOW.range, top: SHADOW.range, bottom: -SHADOW.range, near: 5, far: 280 });
sun.shadow.camera.updateProjectionMatrix();
sun.shadow.bias = -0.0006;
sun.shadow.normalBias = 0.04;

// Біле поле з ледь помітними цяточками, щоб було видно рух
const tc = document.createElement('canvas');
tc.width = tc.height = 128;
const g = tc.getContext('2d');
g.fillStyle = '#fff';
g.fillRect(0, 0, 128, 128);
for (let i = 0; i < 60; i++) {
  g.fillStyle = `rgba(0,0,0,${0.04 + Math.random() * 0.06})`;
  g.fillRect((Math.random() * 128) | 0, (Math.random() * 128) | 0, 2, 2);
}
const tex = new THREE.CanvasTexture(tc);
tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
tex.repeat.set(500, 500);          // 5000 м / 500 = плитка 10 м
tex.encoding = THREE.sRGBEncoding;
tex.anisotropy = 4;
const groundBasic = new THREE.MeshBasicMaterial({ map: tex });     // мала графіка (як було)
const groundLit = new THREE.MeshLambertMaterial({ map: tex });     // висока: приймає світло й тіні
const ground = new THREE.Mesh(new THREE.PlaneGeometry(5000, 5000), groundBasic);
ground.rotation.x = -Math.PI / 2;
scene.add(ground);

// ---------- Похмуре небо з хмарами, що рухаються ----------
function makeCloudTexture() {
  const N = 256, octaves = [4, 8, 16, 32], amps = [0.5, 0.25, 0.125, 0.0625];
  const grids = octaves.map(p => Array.from({ length: p * p }, Math.random));
  const smooth = t => t * t * (3 - 2 * t);
  const noise = (x, y, p, gr) => {
    const gx = x / N * p, gy = y / N * p;
    const x0 = Math.floor(gx), y0 = Math.floor(gy);
    const fx = smooth(gx - x0), fy = smooth(gy - y0);
    const xa = x0 % p, xb = (x0 + 1) % p, ya = y0 % p, yb = (y0 + 1) % p;
    const top = gr[ya * p + xa] * (1 - fx) + gr[ya * p + xb] * fx;
    const bot = gr[yb * p + xa] * (1 - fx) + gr[yb * p + xb] * fx;
    return top * (1 - fy) + bot * fy;
  };
  const cv = document.createElement('canvas');
  cv.width = cv.height = N;
  const ctx = cv.getContext('2d');
  const img = ctx.createImageData(N, N);
  for (let y = 0; y < N; y++) {
    for (let x = 0; x < N; x++) {
      let v = 0;
      for (let o = 0; o < 4; o++) v += amps[o] * noise(x, y, octaves[o], grids[o]);
      v = clamp((v / 0.9375 - 0.25) / 0.55, 0, 1);   // більше контрасту між хмарами
      const i = (y * N + x) * 4;
      img.data[i]     = 92  + v * 100;   // темні дощові хмари -> світліші
      img.data[i + 1] = 99  + v * 99;
      img.data[i + 2] = 107 + v * 94;
      img.data[i + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

const skyMat = new THREE.ShaderMaterial({
  uniforms: {
    map: { value: makeCloudTexture() },
    time: { value: 0 },
    fogColor: { value: new THREE.Color(SKY_COLOR) },
    tint: { value: new THREE.Color(1, 1, 1) },            // колір хмар (день/ніч/захід)
    sunDir: { value: new THREE.Vector3(0, 1, 0) },
    moonDir: { value: new THREE.Vector3(0, -1, 0) },
    sunAmt: { value: 0 }, moonAmt: { value: 0 },
    night: { value: 0 },                                  // 0 день ... 1 ніч (зорі)
    glowColor: { value: new THREE.Color(1.0, 0.55, 0.25) },
    glowAmt: { value: 0 }                                 // сяйво на заході/сході
  },
  vertexShader: `
    varying vec3 vDir;
    void main() {
      vDir = normalize(position);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }`,
  fragmentShader: `
    uniform sampler2D map;
    uniform float time, sunAmt, moonAmt, night, glowAmt;
    uniform vec3 fogColor, tint, sunDir, moonDir, glowColor;
    varying vec3 vDir;
    float hash(vec3 p) { return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453); }
    void main() {
      vec3 d = vDir;
      float h = max(d.y, 0.0);
      vec2 uv = d.xz / (h + 0.25) * 0.55 + vec2(time * 0.006, time * 0.003);
      vec3 raw = texture2D(map, uv).rgb;
      float cloud = clamp((raw.r - 0.36) / 0.39, 0.0, 1.0);
      float vis = (1.0 - 0.8 * cloud) * smoothstep(0.0, 0.05, d.y);   // зорі, сонце й місяць видно крізь прогалини
      vec3 col = mix(fogColor, raw * tint, smoothstep(0.0, 0.3, h));
      // зорі
      vec3 p = d * 260.0, id = floor(p), f = fract(p) - 0.5;
      float star = step(0.9965, hash(id)) * smoothstep(0.42, 0.0, length(f)) * (0.4 + 0.6 * hash(id + 7.0));
      col += vec3(0.85, 0.9, 1.0) * star * night * night * vis * smoothstep(0.02, 0.2, d.y);
      // сонце: сяйво + диск
      float sd = dot(d, sunDir);
      col += glowColor * (pow(max(sd, 0.0), 5.0) * 0.35 + pow(max(sd, 0.0), 48.0) * 0.7) * glowAmt * (1.0 - 0.7 * smoothstep(0.0, 0.5, d.y));
      col += vec3(1.0, 0.93, 0.8) * smoothstep(0.9993, 0.9997, sd) * sunAmt * vis * 2.0;
      // місяць
      float md = dot(d, moonDir);
      col += vec3(0.75, 0.82, 1.0) * (smoothstep(0.9994, 0.9998, md) * 0.95 + pow(max(md, 0.0), 90.0) * 0.12) * moonAmt * vis;
      gl_FragColor = vec4(col, 1.0);
    }`,
  side: THREE.BackSide,
  depthWrite: false,
  depthTest: false,
  fog: false
});
const sky = new THREE.Mesh(new THREE.SphereGeometry(500, 24, 12), skyMat);
sky.renderOrder = -1;
sky.frustumCulled = false;
scene.add(sky);

// ---------- Машина ----------
const car = new THREE.Group();   // rotation.y = курс, передок дивиться в +Z
scene.add(car);
const pivot = new THREE.Group();
car.add(pivot);

let speed = 0, steer = 0;
let lat = 0, driftAmt = 0, steerIn = 0, thr = 0, brk = 0, yawRateG = 0;   // бічна швидкість (занос), дріфт, плавні кермо/газ/гальмо

// ---------- Графіка: мала (як була) / висока (тіні, світло, день і ніч, фари) ----------
let hiGfx = false, clockHour = CFG.startHour, lightLevel = 1, hlI = 0;
const sunDir = new THREE.Vector3(0, 1, 0.3).normalize(), moonDir = new THREE.Vector3(), lightDir = new THREE.Vector3(0.3, 1, 0.2).normalize();
const NIGHT_FOG = new THREE.Color(0x070a14), DAY_FOG = new THREE.Color(SKY_COLOR), TWI_FOG = new THREE.Color(0xb98d70);
const NIGHT_TINT = new THREE.Color(0.05, 0.07, 0.15), WHITE = new THREE.Color(1, 1, 1), WARM_TINT = new THREE.Color(1.3, 0.8, 0.55);
const NIGHT_SKY = new THREE.Color(0x2a3b6e), NIGHT_GROUND = new THREE.Color(0x07090f), DAY_GROUND = new THREE.Color(0xdddddd);
const SUN_WARM = new THREE.Color(0xff9a50), SUN_WHITE = new THREE.Color(0xfff1dc), MOON_COL = new THREE.Color(0x8fa8ff);
const fogC = new THREE.Color();

// Фари: два прожектори на машині, горять уночі, коли ти за кермом
const headL = [];
for (const sx of [-0.62, 0.62]) {
  const l = new THREE.SpotLight(0xfff1d6, 0, 60, 0.5, 0.65, 1.2);
  l.position.set(sx, 0.75, 2.2);
  l.target.position.set(sx * 0.6, 0.1, 16);
  l.visible = false;
  car.add(l); car.add(l.target);
  headL.push(l);
}

function updateDayNight(dt) {
  if (!hiGfx) return;
  clockHour = (clockHour + dt * 24 / CFG.dayLengthSec) % 24;
  const a = (clockHour - 6) / 12 * Math.PI;          // 6:00 схід, 12:00 зеніт, 18:00 захід
  sunDir.set(Math.cos(a), Math.sin(a), 0.35).normalize();
  moonDir.copy(sunDir).negate();
  const e = sunDir.y;
  const day = sstep(-0.1, 0.3, e);
  const twi = Math.exp(-Math.pow(e / 0.2, 2));       // багрянець біля горизонту
  lightLevel = 0.2 + 0.8 * day;

  fogC.copy(NIGHT_FOG).lerp(DAY_FOG, day).lerp(TWI_FOG, twi * 0.5);
  scene.fog.color.copy(fogC); scene.background.copy(fogC);
  const U = skyMat.uniforms;
  U.fogColor.value.copy(fogC);
  U.tint.value.copy(NIGHT_TINT).lerp(WHITE, day).lerp(WARM_TINT, twi * 0.4);
  U.sunDir.value.copy(sunDir); U.moonDir.value.copy(moonDir);
  U.sunAmt.value = sstep(-0.06, 0.04, e); U.moonAmt.value = sstep(-0.06, 0.04, -e);
  U.night.value = 1 - day; U.glowAmt.value = twi * 0.85;

  hemi.color.copy(NIGHT_SKY).lerp(WHITE, day);
  hemi.groundColor.copy(NIGHT_GROUND).lerp(DAY_GROUND, day);
  hemi.intensity = 0.25 + 0.37 * day;

  const up = e >= 0;                                  // вдень світить сонце, уночі - місяць
  lightDir.copy(up ? sunDir : moonDir); lightDir.y = Math.max(lightDir.y, 0.22); lightDir.normalize();
  sun.color.copy(up ? SUN_WARM : MOON_COL);
  if (up) sun.color.lerp(SUN_WHITE, sstep(0.05, 0.5, e));
  sun.intensity = up ? 0.95 * sstep(0, 0.3, e) : 0.22 * sstep(0, 0.3, -e);
}

const _lr = new THREE.Vector3(), _lu = new THREE.Vector3(), _fp = new THREE.Vector3();
function placeSun() {   // тіньова карта слідує за гравцем і «прилипає» до сітки текселів, щоб тіні не мерехтіли
  const f = driving ? car.position : player;
  _lr.crossVectors(new THREE.Vector3(0, 1, 0), lightDir).normalize();
  _lu.crossVectors(lightDir, _lr).normalize();
  const texel = SHADOW.range * 2 / SHADOW.size;
  const aa = Math.round(f.dot(_lr) / texel) * texel, bb = Math.round(f.dot(_lu) / texel) * texel, cc = f.dot(lightDir);
  _fp.set(0, 0, 0).addScaledVector(_lr, aa).addScaledVector(_lu, bb).addScaledVector(lightDir, cc);
  sun.target.position.copy(_fp);
  sun.position.copy(_fp).addScaledVector(lightDir, 130);
  sun.target.updateMatrixWorld();
}

function updateHeadlights(dt) {
  const dark = 1 - sstep(0.0, 0.35, sunDir.y);
  const t = hiGfx && driving ? dark * 2.2 : 0;
  hlI += (t - hlI) * Math.min(1, dt * 3);
  headL.forEach(l => { l.intensity = hlI; });
}

// Тіні та матеріали: викликається при зміні якості і після завантаження моделей
function refreshMaterials() {
  ground.receiveShadow = hiGfx;
  scene.traverse(o => {
    if (o === sky) return;
    if (o.isMesh) { o.castShadow = hiGfx; o.receiveShadow = hiGfx; }
    const m = o.material;
    if (m) (Array.isArray(m) ? m : [m]).forEach(x => { x.needsUpdate = true; });
  });
}

function applyGraphics() {
  hiGfx = SETTINGS.quality === 'high';
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, hiGfx ? 2 : 1.5));
  resize();
  renderer.shadowMap.enabled = hiGfx;
  renderer.toneMapping = hiGfx ? THREE.ACESFilmicToneMapping : THREE.NoToneMapping;
  renderer.toneMappingExposure = 0.9;
  ground.material = hiGfx ? groundLit : groundBasic;
  sun.castShadow = hiGfx;
  headL.forEach(l => { l.visible = hiGfx; });
  if (hiGfx) {
    updateDayNight(0);
  } else {   // повертаємо старий вигляд: сіре похмуре небо, пласке світло
    lightLevel = 1; hlI = 0;
    hemi.color.set(0xffffff); hemi.groundColor.set(0xdddddd); hemi.intensity = 1.0;
    sun.color.set(0xffffff); sun.intensity = 0.35; sun.position.set(30, 60, 20); sun.target.position.set(0, 0, 0);
    scene.fog.color.set(SKY_COLOR); scene.background.set(SKY_COLOR);
    const U = skyMat.uniforms;
    U.fogColor.value.set(SKY_COLOR); U.tint.value.set(1, 1, 1);
    U.sunAmt.value = U.moonAmt.value = U.night.value = U.glowAmt.value = 0;
    headL.forEach(l => { l.intensity = 0; });
  }
  refreshMaterials();
}

// Гра стартує з меню (кнопка «Грати»), коли машина завантажилась
let ready = false, wantPlay = false;
function startGame() {
  car.position.set(5, 0, 0);
  car.rotation.y = 0;
  ready = true;
  if (hiGfx) refreshMaterials();
  if (wantPlay) startPlay();
}

function useFallbackCar() {
  const m = new THREE.Mesh(
    new THREE.BoxGeometry(1.8, 1.3, CFG.carLength),
    new THREE.MeshStandardMaterial({ color: 0x8a1c1c })
  );
  m.position.y = 0.65;
  pivot.add(m);
  toast('Модель не знайдена: ' + CFG.modelPath);
}

new THREE.GLTFLoader().load(
  encodeURI(CFG.modelPath),
  gltf => {
    const m = gltf.scene;
    pivot.add(m);
    const wheelInfo = captureWheels(m);
    hood = captureHood(m);
    let openPivots = [];
    try { openPivots = captureOpenables(m); } catch (e) { console.warn('doors skipped', e); }
    try { optimizeModel(m, wheelInfo, [hood, ...openPivots]); } catch (e) { console.warn('merge skipped', e); }
    let box = new THREE.Box3().setFromObject(m);
    let s = box.getSize(new THREE.Vector3());
    if (s.x > s.z) m.rotation.y = Math.PI / 2;   // вирівнюємо довжину вздовж Z
    if (CFG.flipFront) m.rotation.y += Math.PI;
    box.setFromObject(m);
    s = box.getSize(new THREE.Vector3());
    m.scale.setScalar(CFG.carLength / Math.max(s.x, s.z));
    box.setFromObject(m);
    const c = box.getCenter(new THREE.Vector3());
    m.position.set(-c.x, -box.min.y, -c.z);      // центр по XZ, колеса на землі
    if (wheelInfo.length === 4) buildWheels(m, wheelInfo);
    collectDamageMeshes(m);
    startGame();
  },
  undefined,
  () => { useFallbackCar(); startGame(); }
);

// ---------- Ввід ----------
const held = { l: false, r: false, gas: false, brake: false, drift: false };
const joyIn = { x: 0, y: 0 };

function bindHold(id, key) {
  const el = $(id);
  const set = v => { held[key] = v; el.classList.toggle('on', v); };
  el.addEventListener('pointerdown', e => { e.preventDefault(); el.setPointerCapture(e.pointerId); set(true); });
  ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(t => el.addEventListener(t, () => set(false)));
}
bindHold('btnL', 'l');
bindHold('btnR', 'r');
bindHold('btnGas', 'gas');
bindHold('btnBrake', 'brake');
// Кнопка дріфту (ручник): ліворуч над кнопками керма
const driftBtn = document.createElement('button');
driftBtn.id = 'btnDrift';
driftBtn.className = 'ctl hidden';
driftBtn.textContent = 'Дріфт';
driftBtn.style.cssText = 'position:absolute;left:24px;bottom:160px;width:auto;min-width:96px;height:64px;padding:0 18px;font-size:18px;pointer-events:auto;touch-action:none';
$('ui').appendChild(driftBtn);
bindHold('btnDrift', 'drift');

// Джойстик
const joy = $('joy'), knob = $('knob');
let joyId = null;
function joyMove(e) {
  const r = joy.getBoundingClientRect();
  const R = r.width / 2;
  let dx = e.clientX - (r.left + R), dy = e.clientY - (r.top + R);
  const d = Math.hypot(dx, dy);
  if (d > R) { dx *= R / d; dy *= R / d; }
  knob.style.transform = `translate(${dx}px,${dy}px)`;
  joyIn.x = dx / R; joyIn.y = dy / R;
}
function joyEnd(e) {
  if (e.pointerId !== joyId) return;
  joyId = null; knob.style.transform = ''; joyIn.x = joyIn.y = 0;
}
joy.addEventListener('pointerdown', e => { joyId = e.pointerId; joy.setPointerCapture(e.pointerId); joyMove(e); });
joy.addEventListener('pointermove', e => { if (e.pointerId === joyId) joyMove(e); });
joy.addEventListener('pointerup', joyEnd);
joy.addEventListener('pointercancel', joyEnd);

// Огляд пальцем по екрану
let yaw = -Math.PI / 2, pitch = 0;
let orbitYaw = 0, orbitPitch = 0, orbitIdle = 0;   // камера навколо машини
let lookId = null, lx = 0, ly = 0;
canvas.addEventListener('pointerdown', e => {
  if (lookId !== null) return;
  lookId = e.pointerId; lx = e.clientX; ly = e.clientY;
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove', e => {
  if (e.pointerId !== lookId) return;
  if (!driving) {
    yaw -= (e.clientX - lx) * CFG.lookSens;
    pitch = clamp(pitch - (e.clientY - ly) * CFG.lookSens, -1.3, 1.3);
  } else {
    orbitYaw -= (e.clientX - lx) * CFG.lookSens;
    orbitPitch = clamp(orbitPitch + (e.clientY - ly) * CFG.lookSens, -0.17, 1.05);
    orbitIdle = 0;
  }
  lx = e.clientX; ly = e.clientY;
});
const lookEnd = e => { if (e.pointerId === lookId) lookId = null; };
canvas.addEventListener('pointerup', lookEnd);
canvas.addEventListener('pointercancel', lookEnd);

// ---------- Коробка передач (5 ступенів) ----------
const GEAR_ACCEL = [7, 5.5, 4.2, 3.2, 2.4];   // розгін (м/с²) на кожній передачі
let gear = 1;
const gearCap = () => CFG.gearMax[gear - 1] / 3.6 * (1 - 0.3 * damage);   // побита машина їде гірше

const gearUI = document.createElement('div');
gearUI.className = 'hidden';
gearUI.style.cssText = 'position:absolute;right:24px;bottom:160px;display:flex;gap:10px;align-items:center;pointer-events:auto;touch-action:none';
const gearLabel = document.createElement('div');
gearLabel.style.cssText = 'min-width:84px;height:64px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:30px;font-weight:700;line-height:1;color:#222;background:rgba(255,255,255,.85);border:1px solid #ccc;border-radius:12px';

function updateGearUI() {
  const name = gear === 0 ? 'R' : gear;
  const lim = gear === 0 ? CFG.reverseMax : CFG.gearMax[gear - 1];
  gearLabel.innerHTML = name + '<span style="font-size:11px;font-weight:600;margin-top:4px">до ' + lim + ' км/г</span>';
}
function shift(d) {
  const next = clamp(gear + d, 0, CFG.gearMax.length);   // 0 = задня передача
  if (next === gear) return;
  if ((gear === 0 || next === 0) && Math.abs(speed) > 1.5) {
    toast('Спершу зупинись');
    return;
  }
  gear = next;
  updateGearUI();
}
function shiftBtn(text, d) {
  const b = document.createElement('button');
  b.className = 'ctl';
  b.textContent = text;
  b.style.cssText = 'width:64px;height:64px;font-size:22px';
  b.addEventListener('pointerdown', e => { e.preventDefault(); shift(d); });
  return b;
}
gearUI.append(shiftBtn('▼', -1), gearLabel, shiftBtn('▲', 1));
$('ui').appendChild(gearUI);
updateGearUI();

// ---------- Гравець ----------
const player = new THREE.Vector3(0, 0, 0);
let driving = false;
let camH = 0;
const tmp = new THREE.Vector3();

function walk(dt) {
  const f = -joyIn.y, r = joyIn.x;
  player.x += (-Math.sin(yaw) * f + Math.cos(yaw) * r) * CFG.walkSpeed * dt;
  player.z += (-Math.cos(yaw) * f - Math.sin(yaw) * r) * CFG.walkSpeed * dt;

  // Не заходимо всередину машини
  const h = car.rotation.y, c = Math.cos(h), s = Math.sin(h);
  const dx = player.x - car.position.x, dz = player.z - car.position.z;
  let lx2 = dx * c - dz * s, lz2 = dx * s + dz * c;
  const hx = 1.2, hz = CFG.carLength / 2 + 0.3;
  if (Math.abs(lx2) < hx && Math.abs(lz2) < hz) {
    if (hx - Math.abs(lx2) < hz - Math.abs(lz2)) lx2 = (lx2 < 0 ? -1 : 1) * hx;
    else lz2 = (lz2 < 0 ? -1 : 1) * hz;
    player.x = car.position.x + lx2 * c + lz2 * s;
    player.z = car.position.z - lx2 * s + lz2 * c;
  }

  resolveCircle(player, 0.35); clampBounds(player);   // стіни, гори, дерева
  groundY += (mapFloorAt(player.x, player.z) - groundY) * Math.min(1, dt * 10);
  camera.position.set(player.x, 1.7 + groundY, player.z);
  camera.rotation.set(pitch, yaw, 0);
}

// ---------- Оптимізація моделі: зливаємо сотні дрібних мешів у кілька (менше draw calls) ----------
function mergeMeshes(target, skip) {
  target.updateMatrixWorld(true);
  const inv = new THREE.Matrix4().copy(target.matrixWorld).invert();
  const mat = new THREE.Matrix4(), nm = new THREE.Matrix3(), v = new THREE.Vector3();
  const bins = new Map(), used = [];
  target.traverse(o => {
    if (!o.isMesh || Array.isArray(o.material) || o.children.length || (skip && skip(o))) return;
    const g = o.geometry, A = g.attributes;
    if (!A.position || !A.normal || !A.uv || A.color) return;
    let b = bins.get(o.material);
    if (!b) bins.set(o.material, b = { pos: [], nor: [], uv: [], idx: [], off: 0 });
    mat.multiplyMatrices(inv, o.matrixWorld);
    nm.getNormalMatrix(mat);
    const n = A.position.count;
    for (let i = 0; i < n; i++) {
      v.fromBufferAttribute(A.position, i).applyMatrix4(mat); b.pos.push(v.x, v.y, v.z);
      v.fromBufferAttribute(A.normal, i).applyNormalMatrix(nm).normalize(); b.nor.push(v.x, v.y, v.z);
      b.uv.push(A.uv.getX(i), A.uv.getY(i));
    }
    if (g.index) for (let i = 0; i < g.index.count; i++) b.idx.push(g.index.getX(i) + b.off);
    else for (let i = 0; i < n; i++) b.idx.push(i + b.off);
    b.off += n;
    used.push(o);
  });
  const merged = [];
  for (const [material, b] of bins) {
    const bg = new THREE.BufferGeometry();
    bg.setAttribute('position', new THREE.Float32BufferAttribute(b.pos, 3));
    bg.setAttribute('normal', new THREE.Float32BufferAttribute(b.nor, 3));
    bg.setAttribute('uv', new THREE.Float32BufferAttribute(b.uv, 2));
    bg.setIndex(new THREE.Uint32BufferAttribute(b.idx, 1));
    merged.push(new THREE.Mesh(bg, material));
  }
  used.forEach(o => { o.parent.remove(o); o.geometry.dispose(); });   // видаляємо тільки після успішного злиття
  merged.forEach(mm => target.add(mm));
}
function optimizeModel(m, found, extra) {
  const groups = found.map(f => f.g);
  groups.push(...extra.filter(Boolean));
  groups.forEach(g => mergeMeshes(g));                    // кожне колесо і капот -> кілька мешів
  const set = new Set(groups);
  mergeMeshes(m, o => { for (let p = o.parent; p && p !== m; p = p.parent) if (set.has(p)) return true; return false; });
}

// ---------- Колеса й підвіска (візуально) ----------
// Жорсткість підвіски: більше число = жорсткіше (менше гойдання)
const SUSP = { bodyFreq: 28, bodyDamp: 0.9, pitchK: 0.0015, rollK: 0.002, wheelK: 2000, wheelDamp: 90, bumps: 0.003 };
let wheels = [], spinSign = 1, travel = 0, prevSpeed = 0, aLong = 0;
const bodyS = { y: 0, p: 0, pv: 0, q: 0, qv: 0 };

function captureWheels(m) {   // центри осей беремо до будь-яких змін
  return ['Wheel Front L', 'Wheel Front R', 'Wheel Rear L', 'Wheel Rear R'].map(n => {
    const g = m.getObjectByName(THREE.PropertyBinding.sanitizeNodeName(n));
    return g && g.children.length ? { g, c: g.children[0].position.clone(), front: n.includes('Front') } : null;
  }).filter(Boolean);
}
// Кожне колесо: підвіска -> поворот -> обертання -> меші колеса
function buildWheels(m, found) {
  const s = m.scale.x;
  spinSign = Math.cos(m.rotation.y) < 0 ? -1 : 1;
  wheels = found.map((f, i) => {
    const susp = new THREE.Object3D(), steerN = new THREE.Object3D(), spinN = new THREE.Object3D();
    susp.position.copy(f.c);
    susp.userData.noDamage = true;   // колеса не мнуться
    m.add(susp); susp.add(steerN); steerN.add(spinN); spinN.add(f.g);
    f.g.position.copy(f.c).negate();
    m.updateMatrixWorld(true);
    const wp = susp.getWorldPosition(new THREE.Vector3());
    return { front: f.front, x: wp.x, z: wp.z, R: Math.max(0.2, f.c.y * s + m.position.y),
             cy: f.c.y, s, susp, steerN, spinN, angle: 0, off: 0, vel: 0, phase: i * 1.9 };
  });
}

function updateWheels(dt) {
  if (!wheels.length) return;
  // прискорення: уздовж (розгін/гальмо) і поперек (поворот)
  aLong += ((speed - prevSpeed) / Math.max(dt, 1e-3) - aLong) * Math.min(1, dt * 10);
  prevSpeed = speed;
  const aLat = -speed * yawRateG;
  // кузов на пружинах: нахил вперед/назад і вбік
  const wn = SUSP.bodyFreq, dmp = 2 * SUSP.bodyDamp * wn, B = bodyS;
  const nSub = Math.ceil(dt * 120), h = dt / nSub;   // дрібні кроки, щоб жорстка пружина не «вибухала»
  const pT = clamp(aLong * SUSP.pitchK, -0.04, 0.04), qT = clamp(aLat * SUSP.rollK, -0.05, 0.05);
  for (let k = 0; k < nSub; k++) {
    B.pv += (-wn * wn * (B.p - pT) - dmp * B.pv) * h; B.p += B.pv * h;
    B.qv += (-wn * wn * (B.q - qT) - dmp * B.qv) * h; B.q += B.qv * h;
  }
  travel += Math.abs(speed) * dt;
  const rough = clamp(Math.abs(speed) / 12, 0, 1) * SUSP.bumps;   // дрібні нерівності, у кожного колеса свої
  let heave = 0;
  for (const w of wheels) {
    w.bump = rough * (Math.sin(travel * 1.7 + w.phase) + 0.5 * Math.sin(travel * 4.1 + w.phase * 2));
    heave += w.bump / wheels.length;
  }
  B.y = heave * 0.5;
  for (const w of wheels) {
    // у скільки кузов піднявся над колесом + нерівність під ним, а колесо йде за цим на власній пружині
    const target = B.y + B.p * w.z + B.q * w.x - w.bump;
    for (let k = 0; k < nSub; k++) {
      w.vel += (-SUSP.wheelK * (w.off - target) - SUSP.wheelDamp * w.vel) * h;
      w.off += w.vel * h;
    }
    w.susp.position.y = w.cy - w.off / w.s;
    w.steerN.rotation.y = w.front ? -steer : 0;
    w.angle += speed / w.R * dt;
    w.spinN.rotation.x = spinSign * w.angle;
  }
  pivot.position.y = B.y;
  pivot.rotation.set(-B.p, 0, B.q);
}

// ---------- Капот (E34: шарнір спереду, відкривається заднім краєм догори) ----------
const HOOD_ANGLE = 1.15;   // кут відкриття, радіани (~66°)
let hood = null, hoodOpen = 0, hoodTarget = 0;

function captureHood(m) {   // збираємо всі деталі «Hood…» в одну групу з шарніром на передньому краї
  const parts = [];
  m.traverse(o => { if (o !== m && /^hood/i.test(o.name)) parts.push(o); });
  if (!parts.length) return null;
  m.updateMatrixWorld(true);
  const box = new THREE.Box3();
  parts.forEach(o => box.expandByObject(o));
  const pv = new THREE.Group();
  pv.position.set((box.min.x + box.max.x) / 2, box.min.y + 0.05, box.min.z + 0.05);   // перед моделі = -Z
  m.add(pv);
  m.updateMatrixWorld(true);
  parts.forEach(o => pv.attach(o));
  return pv;
}
function updateHood(dt) {
  if (!hood) return;
  hoodOpen += clamp(hoodTarget - hoodOpen, -dt * 1.1, dt * 1.1);
  const e = hoodOpen * hoodOpen * (3 - 2 * hoodOpen);
  hood.rotation.x = -HOOD_ANGLE * e;   // задній край (+Z моделі) іде вгору
}

// ---------- Мотор M60B40: у капоті, витягнути, тримати в руках, кинути ----------
const ENGINE = { path: 'models/M60B40.gltf', length: 0.62, stretch: 1.0, pos: [0, 0.45, 1.45] };   // stretch: розтягнути ТІЛЬКИ в довжину (1.2 = на 20% довше)
//   // pos: центр мотора в системі машини (x, y, z)
const slot = new THREE.Object3D();            // «посадочне місце» мотора під капотом (рухається разом з кузовом)
slot.position.set(...ENGINE.pos);
slot.rotation.y = Math.PI;                    // перед мотора (-Z у Blockbench) дивиться вперед машини
pivot.add(slot);
let engineRoot = null, engineState = 'installed';   // installed | held | free
const engineHalf = new THREE.Vector3(0.34, 0.3, 0.31);
const eng = { v: new THREE.Vector3(), w: new THREE.Vector3() };
const ZERO = new THREE.Vector3(), QID = new THREE.Quaternion(), UP = new THREE.Vector3(0, 1, 0);
const HAND_POS = new THREE.Vector3(0.3, -0.3, -0.95);
const HAND_Q = new THREE.Quaternion().setFromEuler(new THREE.Euler(0.15, 0.5, 0));
const _ray = new THREE.Ray(), _sph = new THREE.Sphere(), _qa = new THREE.Quaternion(), _qb = new THREE.Quaternion();
const _a = new THREE.Vector3(), _b = new THREE.Vector3(), _c = new THREE.Vector3(), _d = new THREE.Vector3();

function setupEngine(obj, size) {
  engineRoot = new THREE.Group();
  engineRoot.add(obj);
  engineHalf.copy(size).multiplyScalar(0.5);
  slot.add(engineRoot);
  if (hiGfx) refreshMaterials();
}
new THREE.GLTFLoader().load(encodeURI(ENGINE.path), gltf => {
  const e = gltf.scene;
  const box = new THREE.Box3().setFromObject(e);
  const size = box.getSize(new THREE.Vector3()), c = box.getCenter(new THREE.Vector3());
  const s = ENGINE.length / size.z;           // довжина мотора = вісь Z
  e.scale.set(s, s, s * ENGINE.stretch);      // stretch розтягує тільки довжину
  e.position.copy(c).multiply(e.scale).negate();   // центр мотора в нулі
  try { mergeMeshes(e); } catch (err) { console.warn('engine merge skipped', err); }
  setupEngine(e, size.multiply(e.scale));
}, undefined, () => {
  const stub = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.55, ENGINE.length), new THREE.MeshStandardMaterial({ color: 0x8a8d93 }));
  setupEngine(stub, new THREE.Vector3(0.68, 0.55, ENGINE.length));
  toast('Не знайдено ' + ENGINE.path + ', тимчасовий мотор');
});

// Чи дивиться приціл (центр екрана) на кулю навколо точки
function aimAt(center, r, maxDist) {
  camera.getWorldPosition(_a); camera.getWorldDirection(_b);
  _ray.set(_a, _b); _sph.set(center, r);
  const hit = _ray.intersectSphere(_sph, _c);
  return !!hit && _a.distanceTo(hit) < maxDist;
}
const aimSlot = () => aimAt(slot.getWorldPosition(_d), 0.55, 4);

function pullEngine() { camera.attach(engineRoot); engineState = 'held'; }       // з капота в руки
function pickEngine() { camera.attach(engineRoot); engineState = 'held'; }       // з землі в руки
function installEngine() { slot.attach(engineRoot); engineState = 'installed'; } // з рук у капот
function throwEngine() {
  scene.attach(engineRoot);
  camera.getWorldDirection(_b);
  eng.v.copy(_b).multiplyScalar(6.5); eng.v.y += 1.5;
  eng.w.set((Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8, (Math.random() - 0.5) * 8);
  engineState = 'free';
}
const ENGINE_ACTIONS = [
  { label: () => 'Поставити мотор', near: () => engineRoot && engineState === 'held' && hoodOpen > 0.95 && aimSlot(), run: installEngine },
  { label: () => 'Кинути мотор', near: () => engineRoot && engineState === 'held', run: throwEngine },
  { label: () => 'Підняти мотор', near: () => engineRoot && engineState === 'free' && aimAt(engineRoot.position, 0.55, 3.5), run: pickEngine },
  { label: () => 'Витягнути мотор', near: () => engineRoot && engineState === 'installed' && hoodOpen > 0.95 && aimSlot(), run: pullEngine }
];

// Мотор лежить на землі: лягає на найближчу грань
function levelEngine(dt) {
  const r = engineRoot; let bestScore = -1;
  [[1, 0, 0, 1], [0, 1, 0, 1.7], [0, 0, 1, 1]].forEach(([x, y, z, w]) => {
    _a.set(x, y, z).applyQuaternion(r.quaternion);
    const sc = Math.abs(_a.y) * w;
    if (sc > bestScore) { bestScore = sc; _b.copy(_a); }
  });
  if (_b.y < 0) _b.negate();
  _qa.setFromUnitVectors(_b, UP);
  _qb.copy(_qa).multiply(r.quaternion);
  r.quaternion.slerp(_qb, Math.min(1, dt * 5));
}
// Падіння мотора: гравітація, обертання, відскок від землі, тертя
function freeEngine(dt) {
  const r = engineRoot, v = eng.v;
  v.y -= 9.8 * dt;
  r.position.addScaledVector(v, dt);
  const wl = eng.w.length();
  if (wl > 1e-4) { _qa.setFromAxisAngle(_c.copy(eng.w).divideScalar(wl), wl * dt); r.quaternion.premultiply(_qa).normalize(); }
  let low = Infinity;
  for (let i = 0; i < 8; i++) {
    _a.set(i & 1 ? engineHalf.x : -engineHalf.x, i & 2 ? engineHalf.y : -engineHalf.y, i & 4 ? engineHalf.z : -engineHalf.z).applyQuaternion(r.quaternion);
    low = Math.min(low, r.position.y + _a.y);
  }
  if (low < 0) {
    r.position.y -= low;
    if (v.y < 0) v.y = v.y < -1.5 ? -v.y * 0.3 : 0;
    const f = Math.exp(-5 * dt);
    v.x *= f; v.z *= f; eng.w.multiplyScalar(Math.exp(-4 * dt));
    if (Math.hypot(v.x, v.z) < 3) levelEngine(dt);
  }
}
const cross = document.createElement('div');   // приціл по центру екрана
cross.style.cssText = 'position:absolute;left:50%;top:50%;width:8px;height:8px;margin:-4px 0 0 -4px;border-radius:50%;border:2px solid rgba(0,0,0,.55);pointer-events:none';
$('ui').appendChild(cross);
function updateEngine(dt) {
  cross.classList.toggle('hidden', driving);
  if (!engineRoot) return;
  const k = Math.min(1, dt * 8);
  if (engineState === 'installed') { engineRoot.position.lerp(ZERO, k); engineRoot.quaternion.slerp(QID, k); }
  else if (engineState === 'held') { engineRoot.position.lerp(HAND_POS, k); engineRoot.quaternion.slerp(HAND_Q, k); }
  else freeEngine(dt);
}
let lastNoEngine = 0;
function noEngineHint() { const t = performance.now(); if (t - lastNoEngine > 2500) { lastNoEngine = t; toast('Немає мотора!'); } }

// ---------- Двері й багажник (відкриваються, якщо навести приціл) ----------
const DOOR_SPLIT_Z = -0.03125;   // лінія в моделі, де «Door skin» ділиться на передні й задні двері
let openables = [], aimedOpen = null;

// Розрізає меш площиною z = zs на дві частини (перед і зад), у системі моделі
function splitMeshZ(o, zs) {
  o.updateMatrixWorld(true);
  const g = o.geometry, A = g.attributes, idx = g.index;
  const nmx = new THREE.Matrix3().getNormalMatrix(o.matrixWorld);
  const tris = idx ? idx.count / 3 : A.position.count / 3;
  const vert = i => ({
    p: new THREE.Vector3().fromBufferAttribute(A.position, i).applyMatrix4(o.matrixWorld),
    n: A.normal ? new THREE.Vector3().fromBufferAttribute(A.normal, i).applyNormalMatrix(nmx).normalize() : new THREE.Vector3(0, 1, 0),
    u: A.uv ? [A.uv.getX(i), A.uv.getY(i)] : [0, 0]
  });
  const mix = (a, b, t) => ({ p: a.p.clone().lerp(b.p, t), n: a.n.clone().lerp(b.n, t).normalize(), u: [a.u[0] + (b.u[0] - a.u[0]) * t, a.u[1] + (b.u[1] - a.u[1]) * t] });
  const clip = (poly, less) => {   // відсікання багатокутника площиною
    const res = [];
    for (let i = 0; i < poly.length; i++) {
      const a = poly[i], b = poly[(i + 1) % poly.length], da = a.p.z - zs, db = b.p.z - zs;
      const ia = less ? da <= 0 : da >= 0, ib = less ? db <= 0 : db >= 0;
      if (ia) res.push(a);
      if (ia !== ib) res.push(mix(a, b, da / (da - db)));
    }
    return res;
  };
  const outF = [], outR = [];
  for (let t = 0; t < tris; t++) {
    const tri = [0, 1, 2].map(k => vert(idx ? idx.getX(t * 3 + k) : t * 3 + k));
    for (const [out, less] of [[outF, true], [outR, false]]) {
      const poly = clip(tri, less);
      for (let k = 1; k + 1 < poly.length; k++) out.push(poly[0], poly[k], poly[k + 1]);
    }
  }
  const mat = o.material.clone(); mat.side = THREE.DoubleSide;   // на розрізі модель порожня, тож малюємо обидва боки
  const build = vs => {
    if (!vs.length) return null;
    const pos = new Float32Array(vs.length * 3), nor = new Float32Array(vs.length * 3), uv = new Float32Array(vs.length * 2);
    vs.forEach((v, i) => { pos.set([v.p.x, v.p.y, v.p.z], i * 3); nor.set([v.n.x, v.n.y, v.n.z], i * 3); uv.set(v.u, i * 2); });
    const bg = new THREE.BufferGeometry();
    bg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    bg.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    bg.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    return new THREE.Mesh(bg, mat);
  };
  return [build(outF), build(outR)];
}

function makeOpenable(m, name, parts, hinge, axis, sign, angle, radius) {
  const pv = new THREE.Group();
  pv.position.copy(hinge); m.add(pv); m.updateMatrixWorld(true);
  parts.forEach(p => pv.attach(p));
  const box = new THREE.Box3(); parts.forEach(p => box.expandByObject(p));
  const marker = new THREE.Object3D();            // точка, на яку треба навести приціл
  box.getCenter(marker.position); pv.worldToLocal(marker.position); pv.add(marker);
  openables.push({ name, pv, marker, axis, sign, angle, radius, target: 0, cur: 0 });
  return pv;
}

// Знаходить у моделі двері й багажник, збирає їх у групи з шарнірами (викликати ДО злиття мешів)
function captureOpenables(m) {
  m.updateMatrixWorld(true);
  const all = []; m.traverse(o => { if (o !== m && o.isMesh) all.push(o); });
  const nm = o => o.name.replace(/_/g, ' ');
  const pivots = [];
  for (const side of ['R', 'L']) {
    const sx = side === 'R' ? 1 : -1;
    const sets = { Front: [], Rear: [] };
    for (const base of ['Door skin ', 'Door cap ']) {
      const o = all.find(a => nm(a) === base + side);
      if (!o) continue;
      const [fr, rr] = splitMeshZ(o, DOOR_SPLIT_Z);
      o.parent.remove(o);
      if (fr) { m.add(fr); sets.Front.push(fr); }
      if (rr) { m.add(rr); sets.Rear.push(rr); }
    }
    const re = new RegExp('^(Front|Rear) door (glass\\d+|handle) ' + side + '$');
    all.forEach(o => { const mt = nm(o).match(re); if (mt) sets[mt[1]].push(o); });
    for (const part of ['Front', 'Rear']) {
      const parts = sets[part];
      if (!parts.length) continue;
      const b0 = new THREE.Box3().setFromObject(parts[0]);   // шарнір: передній край дверей
      const hinge = new THREE.Vector3((b0.min.x + b0.max.x) / 2, 0, b0.min.z);
      const label = (part === 'Front' ? 'передні' : 'задні') + (side === 'R' ? ' праві' : ' ліві') + ' двері';
      pivots.push(makeOpenable(m, label, parts, hinge, 'y', sx, part === 'Front' ? 1.05 : 1.0, 0.5));
    }
  }
  const trunk = all.filter(o => /^trunk/i.test(nm(o)));
  if (trunk.length) {
    const b = new THREE.Box3(); trunk.forEach(o => b.expandByObject(o));
    pivots.push(makeOpenable(m, 'багажник', trunk, new THREE.Vector3(0, b.max.y - 0.1, b.min.z), 'x', -1, 1.1, 0.7));
  }
  return pivots;
}
function findAimedOpenable() {
  for (const o of openables) if (aimAt(o.marker.getWorldPosition(_d), o.radius, 3.5)) return o;
  return null;
}
function updateOpenables(dt) {
  for (const o of openables) {
    o.cur += clamp(o.target - o.cur, -dt * 2.2, dt * 2.2);
    o.pv.rotation[o.axis] = o.sign * o.angle * (o.cur * o.cur * (3 - 2 * o.cur));
  }
}
const OPEN_ACTION = {
  label: () => aimedOpen ? (aimedOpen.target ? 'Закрити ' : 'Відкрити ') + aimedOpen.name : '',
  near: () => (aimedOpen = findAimedOpenable()) !== null,
  run: () => { aimedOpen.target = aimedOpen.target ? 0 : 1; }
};

// ---------- Кнопка «Дія» (капот, пізніше двері, предмети) ----------
function nearHood() {
  if (!hood) return false;
  const h = car.rotation.y, c = Math.cos(h), s = Math.sin(h);
  const dx = player.x - car.position.x, dz = player.z - car.position.z;
  const lx = dx * c - dz * s, lz = dx * s + dz * c;   // позиція гравця в системі машини
  return Math.abs(lx) < 1.7 && lz > CFG.carLength / 2 - 0.6 && lz < CFG.carLength / 2 + 1.8;
}
const INTERACTIONS = [
  ...ENGINE_ACTIONS,
  OPEN_ACTION,
  { label: () => hoodTarget ? 'Закрити капот' : 'Відкрити капот', near: nearHood, run: () => { hoodTarget = hoodTarget ? 0 : 1; } }
  // сюди додаватимемо двері, предмети тощо
];
let currentInteraction = null;
const interactBtn = document.createElement('button');
interactBtn.className = 'ctl hidden';
interactBtn.style.cssText = 'position:absolute;right:24px;bottom:30px;width:auto;min-width:130px;height:76px;padding:0 22px;font-size:17px';
interactBtn.addEventListener('click', () => { if (currentInteraction) currentInteraction.run(); });
$('ui').appendChild(interactBtn);
function updateInteractions() {
  currentInteraction = driving ? null : (INTERACTIONS.find(i => i.near()) || null);
  interactBtn.classList.toggle('hidden', !currentInteraction);
  if (currentInteraction) {
    const l = currentInteraction.label();
    if (interactBtn.textContent !== l) interactBtn.textContent = l;
  }
}

// ---------- Пошкодження кузова: вм'ятини при ударі і ремонт за 1 секунду ----------
const dmgMeshes = [];                       // {mesh, orig, from} — усі меші кузова (без коліс)
let damage = 0, repairT = 1, lastCrash = 0;
let hitNx = 0, hitNz = 0;                   // напрямок останнього удару (від перешкоди до машини)
const _inv = new THREE.Matrix4(), _lp = new THREE.Vector3(), _ld = new THREE.Vector3();
const _cp = new THREE.Vector3(), _cd = new THREE.Vector3(), _sv = new THREE.Vector3(), _sw = new THREE.Vector3();

function collectDamageMeshes(m) {
  const walk = o => {
    if (o.userData.noDamage) return;
    const a = o.isMesh && o.geometry.attributes.position;
    if (a && a.isBufferAttribute && a.array instanceof Float32Array) dmgMeshes.push({ mesh: o, orig: a.array.slice(), from: null });
    o.children.forEach(walk);
  };
  walk(m);
}
// Вм'ятина: вершини біля точки удару зсуваються всередину машини, з трохи випадковим розкидом
function dentAt(wp, dir, depth, rad) {
  for (const d of dmgMeshes) {
    const me = d.mesh;
    me.updateWorldMatrix(true, false);
    _inv.copy(me.matrixWorld).invert();
    _lp.copy(wp).applyMatrix4(_inv);
    _ld.copy(dir).transformDirection(_inv);
    const sc = me.matrixWorld.getMaxScaleOnAxis(), R = rad / sc, dl = depth / sc, maxD = 0.9 / sc;
    const a = me.geometry.attributes.position, arr = a.array, org = d.orig;
    let touched = false;
    for (let i = 0; i < arr.length; i += 3) {
      const dx = arr[i] - _lp.x, dy = arr[i + 1] - _lp.y, dz = arr[i + 2] - _lp.z, d2 = dx * dx + dy * dy + dz * dz;
      if (d2 > R * R) continue;
      let f = 1 - Math.sqrt(d2) / R; f = f * f * (3 - 2 * f);
      const r1 = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1, r2 = Math.abs(Math.sin((i + 1) * 78.233) * 43758.5453) % 1, r3 = Math.abs(Math.sin((i + 2) * 37.719) * 43758.5453) % 1;
      const k = dl * f * (0.55 + 0.9 * r1), j = dl * f * 0.35;
      arr[i] += _ld.x * k + (r2 - 0.5) * j; arr[i + 1] += _ld.y * k + (r3 - 0.5) * j; arr[i + 2] += _ld.z * k + (r1 - 0.5) * j;
      const ox = arr[i] - org[i], oy = arr[i + 1] - org[i + 1], oz = arr[i + 2] - org[i + 2], len = Math.hypot(ox, oy, oz);
      if (len > maxD) { const q = maxD / len; arr[i] = org[i] + ox * q; arr[i + 1] = org[i + 1] + oy * q; arr[i + 2] = org[i + 2] + oz * q; }
      touched = true;
    }
    if (touched) a.needsUpdate = true;
  }
}
function crash(v, wx, wz, nx, nz) {
  const t = performance.now();
  if (t - lastCrash < 300) return;
  lastCrash = t;
  const depth = Math.min(0.5, (v - 2) * 0.04);                 // чим сильніший удар, тим глибша вм'ятина
  dentAt(_cp.set(wx, 0.65, wz), _cd.set(nx, 0, nz), depth, 1.0);
  damage = Math.min(1, damage + depth * 0.5);
  crashSound(v);
}
function startRepair() {
  for (const d of dmgMeshes) d.from = d.mesh.geometry.attributes.position.array.slice();
  repairT = 0; damage = 0;
}
function updateRepair(dt) {
  if (repairT >= 1) return;
  repairT = Math.min(1, repairT + dt / 1.0);                   // рівно за 1 секунду
  const e = repairT * repairT * (3 - 2 * repairT);
  for (const d of dmgMeshes) {
    const arr = d.mesh.geometry.attributes.position.array;
    for (let i = 0; i < arr.length; i++) arr[i] = d.from[i] + (d.orig[i] - d.from[i]) * e;
    d.mesh.geometry.attributes.position.needsUpdate = true;
  }
}
const repairBtn = document.createElement('button');
repairBtn.className = 'ctl';
repairBtn.style.cssText = 'position:absolute;left:14px;top:14px;width:auto;height:52px;padding:0 16px;font-size:16px';
repairBtn.addEventListener('click', startRepair);
$('ui').appendChild(repairBtn);
function updateRepairLabel() {
  const l = '🔧 Ремонт' + (damage > 0.01 ? ' ' + Math.round(damage * 100) + '%' : '');
  if (repairBtn.textContent !== l) repairBtn.textContent = l;
}

// ---------- Звук мотора і ударів (WebAudio, без файлів) ----------
let audio = null, thrS = 0;
function initAudio() {   // браузер вмикає звук лише після дотику
  if (audio) { if (audio.ctx.state === 'suspended') audio.ctx.resume(); return; }
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  const ctx = new AC(), master = ctx.createGain();
  master.gain.value = 0.6; master.connect(ctx.destination);
  const filt = ctx.createBiquadFilter(); filt.type = 'lowpass'; filt.frequency.value = 400; filt.Q.value = 1.2;
  const gain = ctx.createGain(); gain.gain.value = 0; filt.connect(gain); gain.connect(master);
  const mk = (type, mult, vol) => { const o = ctx.createOscillator(), g = ctx.createGain(); o.type = type; g.gain.value = vol; o.connect(g); g.connect(filt); o.start(); return { o, mult }; };
  audio = { ctx, master, filt, gain, rpm: 900, oscs: [mk('sawtooth', 1, 0.5), mk('square', 0.5, 0.35), mk('triangle', 2, 0.25)] };
  // писк шин: фільтрований шум, гучність залежить від заносу
  const nb = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate), nd = nb.getChannelData(0);
  for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  const ns = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), sg = ctx.createGain();
  ns.buffer = nb; ns.loop = true; bp.type = 'bandpass'; bp.frequency.value = 1300; bp.Q.value = 1.1; sg.gain.value = 0;
  ns.connect(bp); bp.connect(sg); sg.connect(master); ns.start();
  audio.skid = { sg, bp };
}
['pointerdown', 'touchstart'].forEach(ev => window.addEventListener(ev, initAudio, { passive: true }));
function updateAudio(dt) {
  if (!audio) return;
  const on = driving && engineState === 'installed';
  thrS += ((held.gas ? 1 : 0) - thrS) * Math.min(1, dt * 6);
  const top = (gear === 0 ? CFG.reverseMax : CFG.gearMax[gear - 1]) / 3.6;
  const ratio = clamp(Math.abs(speed) / top, 0, 1.05);
  audio.rpm += (900 + ratio * 5100 + thrS * 700 - audio.rpm) * Math.min(1, dt * 5);
  const f = audio.rpm / 60 * 4, t = audio.ctx.currentTime;      // V8: 4 запалювання за оберт
  audio.oscs.forEach(({ o, mult }) => o.frequency.setTargetAtTime(f * mult, t, 0.03));
  audio.filt.frequency.setTargetAtTime(250 + audio.rpm * 0.2 + thrS * 600, t, 0.05);
  audio.gain.gain.setTargetAtTime(on ? 0.12 + 0.2 * thrS + 0.1 * ratio : 0, t, on ? 0.1 : 0.15);
  if (audio.skid) {
    const sk = driving ? clamp((Math.abs(lat) - 1.5) / 6, 0, 1) * clamp(Math.abs(speed) / 10, 0, 1) : 0;
    audio.skid.sg.gain.setTargetAtTime(sk * 0.16, t, 0.08);
    audio.skid.bp.frequency.setTargetAtTime(1100 + Math.abs(speed) * 15, t, 0.1);
  }
}
function crashSound(v) {
  if (!audio) return;
  const ctx = audio.ctx, len = Math.floor(ctx.sampleRate * 0.35), buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.5);
  const src = ctx.createBufferSource(), lp = ctx.createBiquadFilter(), g = ctx.createGain();
  src.buffer = buf; lp.type = 'lowpass'; lp.frequency.value = 900; g.gain.value = clamp(v / 20, 0.15, 1);
  src.connect(lp); lp.connect(g); g.connect(audio.master); src.start();
}

// ---------- Дим з вихлопу і з-під капота (коли машина сильно побита) ----------
const smokeTex = (() => {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d'), g = x.createRadialGradient(32, 32, 2, 32, 32, 32);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
})();
const puffs = Array.from({ length: 80 }, () => {
  const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTex, transparent: true, depthWrite: false, opacity: 0 }));
  sp.visible = false; scene.add(sp);
  return { sp, life: 0, max: 1, v: new THREE.Vector3(), s0: 0.2, s1: 1, a: 0.3 };
});
let puffI = 0, smokeAcc = 0, hoodAcc = 0, driftAcc = 0;
function emitPuff(pos, vel, s0, s1, shade, alpha, life) {
  const p = puffs[puffI++ % puffs.length];
  p.sp.position.copy(pos); p.v.copy(vel); p.s0 = s0; p.s1 = s1; p.a = alpha; p.life = p.max = life;
  p.sp.material.color.setScalar(shade * lightLevel); p.sp.visible = true;   // вночі дим темніший
}
function updateSmoke(dt) {
  const h = car.rotation.y, fx = Math.sin(h), fz = Math.cos(h), lx = Math.cos(h), lz = -Math.sin(h);   // вперед і ліворуч машини
  if (driving && engineState === 'installed') {
    smokeAcc += dt * (4 + thrS * 14 + Math.abs(speed) * 0.2);
    while (smokeAcc >= 1) {
      smokeAcc -= 1;
      _sv.set(car.position.x + lx * 0.55 - fx * 2.45, 0.28, car.position.z + lz * 0.55 - fz * 2.45);   // труба ззаду зліва
      _sw.set(-fx * (0.9 + thrS) + (Math.random() - 0.5) * 0.4, 0.5 + Math.random() * 0.4, -fz * (0.9 + thrS) + (Math.random() - 0.5) * 0.4);
      emitPuff(_sv, _sw, 0.12, 0.7 + thrS * 0.6, 0.45 + (1 - thrS) * 0.25, 0.25 + thrS * 0.25, 0.9 + Math.random() * 0.5);
    }
  }
  if (driving && driftAmt > 0.25 && Math.abs(lat) > 2.2 && Math.abs(speed) > 5) {   // дим з-під задніх коліс при дріфті
    driftAcc += dt * (8 + Math.abs(lat) * 2);
    while (driftAcc >= 1) {
      driftAcc -= 1;
      for (const side of [-1, 1]) {
        _sv.set(car.position.x + lx * 0.82 * side - fx * 1.45, 0.12, car.position.z + lz * 0.82 * side - fz * 1.45);
        _sw.set((Math.random() - 0.5) * 0.6, 0.35 + Math.random() * 0.3, (Math.random() - 0.5) * 0.6);
        emitPuff(_sv, _sw, 0.35, 1.9, 0.88, 0.36, 0.9 + Math.random() * 0.5);
      }
    }
  }
  if (damage > 0.6) {                                           // чорний дим з-під капота
    hoodAcc += dt * (damage - 0.5) * 24;
    while (hoodAcc >= 1) {
      hoodAcc -= 1;
      _sv.set(car.position.x + fx * 1.5 + (Math.random() - 0.5) * 0.5, 0.95, car.position.z + fz * 1.5 + (Math.random() - 0.5) * 0.5);
      _sw.set((Math.random() - 0.5) * 0.4, 1.1 + Math.random() * 0.6, (Math.random() - 0.5) * 0.4);
      emitPuff(_sv, _sw, 0.2, 1.3, 0.15, 0.45, 1.4 + Math.random() * 0.8);
    }
  }
  for (const p of puffs) {
    if (p.life <= 0) continue;
    p.life -= dt;
    if (p.life <= 0) { p.sp.visible = false; continue; }
    const t = 1 - p.life / p.max;
    p.sp.position.addScaledVector(p.v, dt); p.v.y += 0.25 * dt;
    p.sp.scale.setScalar(p.s0 + (p.s1 - p.s0) * t);
    p.sp.material.opacity = p.a * (1 - t);
  }
}

// ---------- Карта: maps/model_maps.gltf (гори, будинки з колізіями; без файлу лишається біле поле) ----------
const MAP = { path: 'maps/model_maps.gltf', scale: 5.5 };   // scale: метрів в одній одиниці Blockbench (як у машини)
let mapLoaded = false, groundY = 0;
const colBoxes = [], colGrid = new Map(), mapFloors = [];
const mapBounds = { x0: -1e9, x1: 1e9, z0: -1e9, z1: 1e9 };
const CELL = 10, cellKey = (ix, iz) => ix * 100003 + iz;

function addColBox(b) {   // кладемо коробку в усі клітинки сітки, яких вона торкається
  colBoxes.push(b);
  const R = Math.hypot(b.hx, b.hz);
  for (let ix = Math.floor((b.cx - R) / CELL); ix <= Math.floor((b.cx + R) / CELL); ix++)
    for (let iz = Math.floor((b.cz - R) / CELL); iz <= Math.floor((b.cz + R) / CELL); iz++) {
      const k = cellKey(ix, iz); let a = colGrid.get(k);
      if (!a) colGrid.set(k, a = []);
      a.push(b);
    }
}
// Збираємо колізії з гір, будинків (стіни, меблі), стовбурів дерев, каміння і кактусів
function collectCollision(root) {
  const bb = new THREE.Box3(), v = new THREE.Vector3(), sz = new THREE.Vector3(), sc = new THREE.Vector3();
  root.updateMatrixWorld(true);
  root.traverse(o => {
    if (!o.isMesh) return;
    let zone = '';
    for (let p = o.parent; p && p !== root; p = p.parent) {
      if (p.name === 'Desert_Mountains' || p.name === 'Desert_Props') zone = 'solid';
      else if (p.name.startsWith('Houses_')) zone = 'house';
      else if (p.name === 'Forest_Trees') zone = 'tree';
    }
    if (!zone || (zone === 'tree' && !/^Trunk/.test(o.name))) return;
    bb.setFromObject(o);
    if (zone === 'house' && /^Foundation/.test(o.name)) { mapFloors.push({ x0: bb.min.x, x1: bb.max.x, z0: bb.min.z, z1: bb.max.z }); return; }
    if (bb.max.y < 0.45 || bb.min.y > 2.4) return;   // підлога, килими нижче, дах і стеля вище за людину
    const g = o.geometry;
    if (!g.boundingBox) g.computeBoundingBox();
    g.boundingBox.getCenter(v).applyMatrix4(o.matrixWorld);
    g.boundingBox.getSize(sz).multiplyScalar(0.5);
    sc.setFromMatrixScale(o.matrixWorld);
    const e = o.matrixWorld.elements, yaw = Math.atan2(-e[2], e[0]);
    addColBox({ cx: v.x, cz: v.z, hx: sz.x * sc.x, hz: sz.z * sc.z, c: Math.cos(yaw), s: Math.sin(yaw) });
  });
}
// Виштовхує коло (гравець або частина машини) з коробок поруч; повертає глибину удару
function resolveCircle(p, r) {
  let hit = 0;
  const ix0 = Math.floor(p.x / CELL), iz0 = Math.floor(p.z / CELL);
  for (let ix = ix0 - 1; ix <= ix0 + 1; ix++) for (let iz = iz0 - 1; iz <= iz0 + 1; iz++) {
    const a = colGrid.get(cellKey(ix, iz));
    if (!a) continue;
    for (const b of a) {
      const dx = p.x - b.cx, dz = p.z - b.cz;
      const lx = dx * b.c - dz * b.s, lz = dx * b.s + dz * b.c;       // у системі коробки
      let ex = lx - clamp(lx, -b.hx, b.hx), ez = lz - clamp(lz, -b.hz, b.hz);
      const d2 = ex * ex + ez * ez;
      if (d2 >= r * r) continue;
      let push;
      if (d2 > 1e-9) { const d = Math.sqrt(d2); push = r - d; ex /= d; ez /= d; }
      else {
        const px = b.hx - Math.abs(lx), pz = b.hz - Math.abs(lz);
        if (px < pz) { ex = lx < 0 ? -1 : 1; ez = 0; push = px + r; } else { ex = 0; ez = lz < 0 ? -1 : 1; push = pz + r; }
      }
      const wx = ex * b.c + ez * b.s, wz = -ex * b.s + ez * b.c;   // напрямок виштовхування у світі
      p.x += wx * push; p.z += wz * push;
      if (push > hit) { hit = push; hitNx = wx; hitNz = wz; }
    }
  }
  return hit;
}
function collideCar() {   // машина = три кола вздовж кузова
  if (!colBoxes.length) return;
  const h = car.rotation.y, fx = Math.sin(h), fz = Math.cos(h), p = { x: 0, z: 0 };
  const v0 = Math.hypot(speed, lat);
  let best = 0, bx = 0, bz = 0, bnx = 0, bnz = 0;
  for (const off of [-1.45, 0, 1.45]) {
    p.x = car.position.x + fx * off; p.z = car.position.z + fz * off;
    const x0 = p.x, z0 = p.z, hit = resolveCircle(p, 0.95);
    if (hit > best) { best = hit; bx = x0; bz = z0; bnx = hitNx; bnz = hitNz; }
    car.position.x += p.x - x0; car.position.z += p.z - z0;
  }
  if (best > 0.02) {
    speed *= 0.7; lat *= 0.5;                                                   // удар гасить швидкість
    if (v0 > 3) crash(v0, bx - bnx * 0.95, bz - bnz * 0.95, bnx, bnz);
  }
}
function clampBounds(p) {   // не виїжджаємо за край карти
  if (!mapLoaded) return;
  p.x = clamp(p.x, mapBounds.x0 + 3, mapBounds.x1 - 3); p.z = clamp(p.z, mapBounds.z0 + 3, mapBounds.z1 - 3);
}
function mapFloorAt(x, z) {   // усередині будинку підлога трохи вища за землю
  for (const f of mapFloors) if (x > f.x0 && x < f.x1 && z > f.z0 && z < f.z1) return 0.3;
  return 0;
}
function setupMap(root) {
  root.scale.setScalar(MAP.scale);
  scene.add(root);
  root.updateMatrixWorld(true);
  const bb = new THREE.Box3().setFromObject(root);
  mapBounds.x0 = bb.min.x; mapBounds.x1 = bb.max.x; mapBounds.z0 = bb.min.z; mapBounds.z1 = bb.max.z;
  collectCollision(root);                                            // колізії беремо ДО злиття мешів
  try { mergeMeshes(root); } catch (e) { console.warn('map merge skipped', e); }
  mapLoaded = true;
  if (hiGfx) refreshMaterials();
}
new THREE.GLTFLoader().load(encodeURI(MAP.path), gltf => setupMap(gltf.scene), undefined, () => console.info('Карту ' + MAP.path + ' не знайдено, біле поле'));

// ---------- Водіння ----------
function drive(dt) {
  const rev = gear === 0;
  const cap = rev ? CFG.reverseMax / 3.6 : gearCap();   // ліміт швидкості (модуль)
  const gasOn = held.gas && engineState === 'installed';   // без мотора газ не працює
  if (held.gas && !gasOn) noEngineHint();
  thr += ((gasOn ? 1 : 0) - thr) * Math.min(1, dt * (gasOn ? 6 : 10));   // газ і гальмо вмикаються плавно
  brk += ((held.brake ? 1 : 0) - brk) * Math.min(1, dt * 12);
  if (gasOn) {
    if (rev) {
      if (speed > 0) speed = Math.max(0, speed - 30 * dt);   // спершу гасимо рух уперед
      else if (-speed < cap) {
        speed -= 4 * thr * clamp((cap + speed) / (cap * 0.2), 0, 1) * dt;
        if (cap + speed < 0.15) speed = -cap;
      }
    } else if (speed < 0) {
      speed = Math.min(0, speed + 30 * dt);                  // спершу гасимо рух назад
    } else if (speed < cap) {
      speed += GEAR_ACCEL[gear - 1] * thr * clamp((cap - speed) / (cap * 0.2), 0, 1) * dt;
      if (cap - speed < 0.15) speed = cap;
    }
  }
  // Гальмо тільки гальмує, у будь-який бік
  if (brk > 0.01) speed = speed > 0 ? Math.max(0, speed - 30 * brk * dt) : Math.min(0, speed + 30 * brk * dt);
  // Гальмування двигуном, якщо швидкість вища за ліміт передачі
  if (Math.abs(speed) > cap) speed -= Math.sign(speed) * Math.min(Math.abs(speed) - cap, 7 * dt);
  if (!gasOn) speed -= speed * 0.02 * dt;
  if (!gasOn && !held.brake) {
    const fr = 3 * dt;
    speed = Math.abs(speed) < fr ? 0 : speed - Math.sign(speed) * fr;
  }
  speed = clamp(speed, -8, CFG.maxSpeed);

  // ----- дріфт: ручник знижує зчеплення, на газу з кермом занос тримається сам -----
  const v = Math.abs(speed);
  const hb = held.drift && v > 5;
  let dTarget = hb ? 1 : 0;
  if (!hb && gasOn && speed > 6 && Math.abs(lat) > 4.5) dTarget = 0.7;
  driftAmt += (dTarget - driftAmt) * Math.min(1, dt * (dTarget > driftAmt ? 5 : 2.2));   // входить і виходить плавно
  if (hb) speed -= Math.sign(speed) * Math.min(v, 1.5 * dt);                              // ручник трохи гальмує

  // ----- кермо: м'яко «набирається», на швидкості менш різке, у дріфті допомагає контрруль -----
  const inp = (held.r ? 1 : 0) - (held.l ? 1 : 0);
  const toward = Math.abs(inp) > Math.abs(steerIn) && (steerIn === 0 || Math.sign(inp) === Math.sign(steerIn));
  const sr = (toward ? 4.2 : 8) * dt;
  steerIn += clamp(inp - steerIn, -sr, sr);
  const beta = speed > 2 ? Math.atan2(lat, speed) : 0;                  // кут заносу (куди їдемо відносно носа)
  let want = steerIn * 0.5 / (1 + v * 0.1) * (1 + driftAmt * 0.45);
  if (steerIn * beta > 0) want *= 1 - sstep(0.25, 0.75, Math.abs(beta));  // не крутимося в занос глибше й глибше
  want -= clamp(beta, -0.9, 0.9) * 0.4 * driftAmt;                      // авто-контрруль
  steer += (clamp(want, -0.7, 0.7) - steer) * Math.min(1, dt * 7);

  yawRateG = clamp((speed / 2.8) * Math.tan(steer) * (1 + driftAmt * 0.15), -2.2, 2.2);
  const dh = -yawRateG * dt;
  car.rotation.y += dh;

  // Кузов повернувся, а швидкість «не встигла» - з'являється бокова складова (занос)
  const cd = Math.cos(dh), sd = Math.sin(dh);
  const nF = speed * cd + lat * sd;
  lat = -speed * sd + lat * cd; speed = nF;
  const grip = 10 - 8.5 * driftAmt;                                      // зчеплення: у дріфті слабке
  const keep = Math.exp(-grip * dt), lost = lat * (1 - keep);
  lat = clamp(lat * keep, -25, 25);
  speed -= Math.sign(speed) * Math.min(Math.abs(speed), Math.abs(lost) * 0.2);   // боковий ковзання трохи гальмує

  const h = car.rotation.y;
  const fx = Math.sin(h), fz = Math.cos(h), sx = Math.cos(h), sz = -Math.sin(h);   // вперед і вбік (ліворуч)
  car.position.x += (fx * speed + sx * lat) * dt;
  car.position.z += (fz * speed + sz * lat) * dt;
  collideCar(); clampBounds(car.position);

  // Камера ззаду з невеликим запізненням
  const tgtH = h + (speed > 3 ? 0.55 * Math.atan2(lat, speed) : 0);   // у заносі камера трохи відстає і показує слід
  const diff = ((tgtH - camH + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
  camH += diff * Math.min(1, dt * 4);
  // Якщо не крутимо пальцем і їдемо, камера плавно повертається за машину
  if (lookId === null) orbitIdle += dt;
  if (orbitIdle > 1.5 && Math.abs(speed) > 3) {
    orbitYaw = ((orbitYaw + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI;
    const k = Math.min(1, dt * 3);
    orbitYaw -= orbitYaw * k;
    orbitPitch -= orbitPitch * k;
  }
  const th = camH + orbitYaw;
  const el = clamp(0.225 + orbitPitch, 0.05, 1.3);
  const dist = 8.5;
  tmp.set(
    car.position.x - Math.sin(th) * dist * Math.cos(el),
    1.3 + dist * Math.sin(el),
    car.position.z - Math.cos(th) * dist * Math.cos(el)
  );
  camera.position.lerp(tmp, Math.min(1, dt * (lookId === null ? 8 : 20)));
  camera.lookAt(car.position.x, 1.3, car.position.z);
  camera.fov = 70 + (Math.abs(speed) / CFG.maxSpeed) * 12;
  camera.updateProjectionMatrix();

  $('speed').textContent = Math.round(Math.abs(speed) * 3.6) + ' км/г';
}

// ---------- Сісти / вийти ----------
const actionBtn = $('actionBtn');

function setMode(d) {
  driving = d;
  $('joy').classList.toggle('hidden', d);
  $('driveUI').classList.toggle('hidden', !d);
  $('speed').classList.toggle('hidden', !d);
  gearUI.classList.toggle('hidden', !d);
  driftBtn.classList.toggle('hidden', !d);
  if (!d) { camera.fov = 70; camera.updateProjectionMatrix(); }
}

actionBtn.addEventListener('click', () => {
  if (!driving) {
    if (player.distanceTo(car.position) > 5) return;
    if (hoodTarget) { toast('Спершу закрий капот'); return; }
    if (engineState === 'held') { toast('Спершу поклади мотор'); return; }
    openables.forEach(o => { o.target = 0; });   // двері й багажник зачиняються
    speed = 0; steer = 0; lat = 0; driftAmt = 0; steerIn = 0; thr = 0; brk = 0; yawRateG = 0; camH = car.rotation.y;
    gear = 1; updateGearUI();
    orbitYaw = orbitPitch = orbitIdle = 0;
    setMode(true);
  } else {
    if (Math.abs(speed) > 3) { toast('Спершу зупинись'); return; }
    const h = car.rotation.y;
    player.set(car.position.x + Math.cos(h) * 2.8, 0, car.position.z - Math.sin(h) * 2.8);
    yaw = Math.atan2(Math.cos(h), -Math.sin(h));   // дивимось на машину
    pitch = 0;
    speed = 0; lat = 0; driftAmt = 0;
    setMode(false);
  }
});

let toastTimer = 0;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 3000);
}

// ---------- Цикл ----------
let last = 0;
function loop(t) {
  const dt = Math.min((t - last) / 1000, 0.05);
  last = t;

  if (driving) drive(dt); else walk(dt);
  updateWheels(dt);
  updateHood(dt);
  updateEngine(dt);
  updateOpenables(dt);
  updateRepair(dt); updateRepairLabel(); updateAudio(dt); updateSmoke(dt);
  updateInteractions();
  updateDayNight(dt);
  if (hiGfx) placeSun();
  updateHeadlights(dt);

  if (driving) {
    actionBtn.textContent = 'Вийти';
    actionBtn.classList.remove('hidden');
  } else if (player.distanceTo(car.position) < 5) {
    actionBtn.textContent = 'Сісти';
    actionBtn.classList.remove('hidden');
  } else {
    actionBtn.classList.add('hidden');
  }

  // Небо йде за камерою, хмари пливуть
  sky.position.copy(camera.position);
  skyMat.uniforms.time.value = t / 1000;

  // Поле «їде» разом з гравцем, тож воно безкінечне
  ground.position.set(Math.round(camera.position.x / 10) * 10, mapLoaded ? -1.2 : 0, Math.round(camera.position.z / 10) * 10);

  renderer.render(scene, camera);
}

// ---------- Головне меню ----------
const MENU_BG = 'textures/menu.jpg';
const menuStyle = document.createElement('style');
menuStyle.textContent = `
#menu{position:fixed;top:0;left:0;right:0;bottom:0;z-index:100;display:flex;align-items:center;justify-content:center;
  background:#15171c url("${MENU_BG}") center/cover no-repeat;color:#fff;font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  user-select:none;-webkit-user-select:none;touch-action:manipulation;overflow:auto}
#menu::before{content:"";position:absolute;top:0;left:0;right:0;bottom:0;background:radial-gradient(ellipse at center,rgba(0,0,0,.28),rgba(0,0,0,.72))}
#menu .mBox{position:relative;width:min(88vw,380px);display:flex;flex-direction:column;gap:14px;padding:22px 0;box-sizing:border-box}
#menu h1{margin:0 0 14px;text-align:center;font-size:clamp(34px,9vw,56px);letter-spacing:.08em;font-weight:800;text-shadow:0 3px 18px rgba(0,0,0,.65)}
#menu h2{margin:0 0 6px;text-align:center;font-size:26px;text-shadow:0 2px 12px rgba(0,0,0,.6)}
#menu .mBtn{height:62px;border:1px solid rgba(255,255,255,.35);border-radius:16px;background:rgba(255,255,255,.14);color:#fff;font-size:21px;font-weight:600;
  backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);cursor:pointer;font-family:inherit}
#menu .mBtn:active{background:rgba(255,255,255,.28)}
#menu .mPrimary{background:rgba(255,255,255,.92);color:#15171c;border-color:#fff}
#menu .mPrimary:active{background:#ddd}
#menu .mRow{background:rgba(0,0,0,.42);border:1px solid rgba(255,255,255,.2);border-radius:16px;padding:14px;backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px)}
#menu .mLbl{font-size:17px;font-weight:600;margin-bottom:10px;display:flex;justify-content:space-between}
#menu .mSeg{display:flex;gap:8px}
#menu .mSeg button{flex:1;min-height:56px;padding:6px 8px;border:1px solid rgba(255,255,255,.35);border-radius:12px;background:transparent;color:#fff;font-size:15px;font-weight:600;cursor:pointer;font-family:inherit}
#menu .mSeg button.on{background:#fff;color:#15171c;border-color:#fff}
#menu .mHint{margin-top:10px;font-size:13px;line-height:1.35;opacity:.8}
#menu input[type=range]{width:100%;height:32px;accent-color:#fff}
#menu.mOff,#menu .mOff{display:none !important}
`;
document.head.appendChild(menuStyle);

const menu = document.createElement('div');
menu.id = 'menu';
menu.innerHTML = `
  <div class="mBox" id="mMain">
    <h1>WHITE DRIVE</h1>
    <button class="mBtn mPrimary" id="mPlay">Грати</button>
    <button class="mBtn" id="mSet">Налаштування</button>
  </div>
  <div class="mBox mOff" id="mSettings">
    <h2>Налаштування</h2>
    <div class="mRow">
      <div class="mLbl">Графіка</div>
      <div class="mSeg">
        <button data-q="low">Мала</button>
        <button data-q="high">Висока: тіні та освітлення</button>
      </div>
      <div class="mHint" id="mHint"></div>
    </div>
    <div class="mRow">
      <div class="mLbl"><span>Чутливість курсора</span><span id="mSensV"></span></div>
      <input type="range" id="mSens" min="0.3" max="3" step="0.1">
    </div>
    <button class="mBtn" id="mBack">Назад</button>
  </div>`;
document.body.appendChild(menu);
$('loading').classList.add('hidden');   // замість «Завантаження...» тепер меню

const mMain = menu.querySelector('#mMain'), mSettings = menu.querySelector('#mSettings');
const mPlay = menu.querySelector('#mPlay'), mHint = menu.querySelector('#mHint');
const mSens = menu.querySelector('#mSens'), mSensV = menu.querySelector('#mSensV');
const Q_HINT = {
  low: 'Як було: без тіней, швидко працює навіть на слабких пристроях.',
  high: 'Тіні від машини й будівель, освітлення, зміна дня і ночі, фари вночі. Потребує потужнішого пристрою.'
};
const showPanel = name => { mMain.classList.toggle('mOff', name !== 'main'); mSettings.classList.toggle('mOff', name !== 'set'); };
function syncMenu() {
  menu.querySelectorAll('[data-q]').forEach(b => b.classList.toggle('on', b.dataset.q === SETTINGS.quality));
  mHint.textContent = Q_HINT[SETTINGS.quality];
  mSens.value = SETTINGS.sens;
  mSensV.textContent = '×' + SETTINGS.sens.toFixed(1);
}
menu.querySelectorAll('[data-q]').forEach(b => b.addEventListener('click', () => {
  if (SETTINGS.quality === b.dataset.q) return;
  SETTINGS.quality = b.dataset.q;
  saveSettings(); applyGraphics(); syncMenu();
}));
mSens.addEventListener('input', () => {
  SETTINGS.sens = clamp(parseFloat(mSens.value) || 1, 0.3, 3);
  CFG.lookSens = BASE_LOOK_SENS * SETTINGS.sens;
  saveSettings(); syncMenu();
});
menu.querySelector('#mSet').addEventListener('click', () => { syncMenu(); showPanel('set'); });
menu.querySelector('#mBack').addEventListener('click', () => showPanel('main'));

// Кнопка меню під час гри
const menuBtn = document.createElement('button');
menuBtn.className = 'ctl hidden';
menuBtn.textContent = '☰';
menuBtn.style.cssText = 'position:absolute;right:14px;top:14px;width:52px;height:52px;padding:0;font-size:22px;pointer-events:auto';
$('ui').appendChild(menuBtn);

let started = false, menuOpen = true;
function resetInput() {   // відпускаємо всі кнопки, джойстик і огляд
  Object.keys(held).forEach(k => { held[k] = false; });
  ['btnL', 'btnR', 'btnGas', 'btnBrake', 'btnDrift'].forEach(id => $(id).classList.remove('on'));
  joyIn.x = joyIn.y = 0; knob.style.transform = ''; joyId = null; lookId = null;
}
function openMenu() {
  menuOpen = true;
  renderer.setAnimationLoop(null);
  resetInput();
  if (audio && audio.ctx.state === 'running') audio.ctx.suspend();
  menuBtn.classList.add('hidden');
  showPanel('main'); menu.classList.remove('mOff');
}
function startPlay() {
  wantPlay = false; menuOpen = false; started = true;
  mPlay.textContent = 'Продовжити';
  menu.classList.add('mOff');
  menuBtn.classList.remove('hidden');
  if (audio && audio.ctx.state === 'suspended') audio.ctx.resume();
  last = performance.now();
  renderer.setAnimationLoop(loop);
}
mPlay.addEventListener('click', () => {
  goLandscape();   // повний екран + горизонтальна орієнтація (потрібен дотик користувача)
  if (!ready) { wantPlay = true; mPlay.textContent = 'Завантаження...'; return; }   // запуститься, щойно машина завантажиться
  startPlay();
});
menuBtn.addEventListener('click', openMenu);
addEventListener('keydown', e => { if (e.key === 'Escape' && started) { if (menuOpen) startPlay(); else openMenu(); } });

// ---------- Горизонтальна орієнтація ----------
async function goLandscape() {
  const el = document.documentElement;
  try {
    if (!document.fullscreenElement && !document.webkitFullscreenElement) {
      if (el.requestFullscreen) await el.requestFullscreen({ navigationUI: 'hide' });
      else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    }
  } catch (e) {}
  try { if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape'); } catch (e) {}
}
if (isTouch) {   // якщо браузер не дозволив заблокувати орієнтацію (наприклад iPhone) - просимо повернути телефон
  const rs = document.createElement('style');
  rs.textContent = '#rotateHint{display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:200;background:#15171c;color:#fff;align-items:center;justify-content:center;flex-direction:column;gap:18px;font:600 22px system-ui,sans-serif;text-align:center;padding:24px}'
    + '#rotateHint span{font-size:64px;display:block;transform:rotate(90deg)}'
    + '@media (orientation:portrait){#rotateHint{display:flex}}#rotateHint.skip{display:none !important}';
  document.head.appendChild(rs);
  const rh = document.createElement('div');
  rh.id = 'rotateHint';
  rh.innerHTML = '<span>📱</span>Поверни телефон горизонтально<div style="font:400 15px system-ui,sans-serif;opacity:.7">Торкнись екрана, щоб грати й так</div>';
  rh.addEventListener('click', () => { goLandscape(); rh.classList.add('skip'); });
  document.body.appendChild(rh);
}

applyGraphics();
syncMenu();
})();
