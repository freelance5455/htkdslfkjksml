import * as THREE from 'three';

const host = document.querySelector('#scene');
const scene = new THREE.Scene();
scene.background = new THREE.Color('#20152b');
scene.fog = new THREE.Fog('#20152b', 16, 42);
const camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, .1, 90);
camera.position.set(0, 2.5, 9.2);
camera.lookAt(0, 1.4, -5);
const renderer = new THREE.WebGLRenderer({antialias:false, alpha:false});
const PIXEL_SCALE=.42;
renderer.setPixelRatio(1);
renderer.setSize(Math.max(180,Math.floor(innerWidth*PIXEL_SCALE)),Math.max(120,Math.floor(innerHeight*PIXEL_SCALE)),false);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;
renderer.outputColorSpace = THREE.SRGBColorSpace;
host.appendChild(renderer.domElement);

scene.add(new THREE.HemisphereLight('#f4d9ff', '#271527', 2.1));
const key = new THREE.DirectionalLight('#ffe6c0', 3.2); key.position.set(-4, 8, 5); key.castShadow = true; key.shadow.mapSize.set(1024,1024); scene.add(key);
const pinkLamp = new THREE.PointLight('#f33d8b', 18, 18); pinkLamp.position.set(-5,3,-7); scene.add(pinkLamp);
const blueLamp = new THREE.PointLight('#626eff', 22, 20); blueLamp.position.set(5,4,-10); scene.add(blueLamp);

const mat = (color, roughness=.72, metalness=0) => new THREE.MeshStandardMaterial({color, roughness, metalness});
const floorMat=mat('#21192a'), wallMat=mat('#25182a'), goldMat=mat('#eabf7d',.35,.4), neonPink=new THREE.MeshBasicMaterial({color:'#ff3f8f'}), neonBlue=new THREE.MeshBasicMaterial({color:'#6e8cff'});
const floor = new THREE.Mesh(new THREE.PlaneGeometry(50,50),floorMat); floor.rotation.x=-Math.PI/2; floor.position.set(0,-.02,-12); floor.receiveShadow=true; scene.add(floor);
const backWall = new THREE.Mesh(new THREE.PlaneGeometry(38,14),wallMat); backWall.position.set(0,6,-24); scene.add(backWall);
// A shallow perspective grid gives the room an expo-floor rhythm.
const grid = new THREE.GridHelper(50,32,'#54334f','#382642'); grid.position.set(0,.005,-12); grid.material.transparent=true; grid.material.opacity=.35; scene.add(grid);
function box(w,h,d,x,y,z,material, parent=scene){const mesh=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);mesh.position.set(x,y,z);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh}
function glowBar(x,y,z,w,h,material){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,.04),material);m.position.set(x,y,z);scene.add(m);return m}
// Neon wayfinding and stage borders.
box(38,.3,.35,0,.18,-20,goldMat);
glowBar(0,7.3,-23,13,.055,neonPink); glowBar(0,6.4,-23,8,.04,neonBlue);
for(let i=0;i<9;i++){const x=-12+i*3; const light=new THREE.Mesh(new THREE.BoxGeometry(.8,.09,.22),i%2?neonBlue:neonPink);light.position.set(x,9.5,-14);scene.add(light)}
// Character art supplied with the project lives on distant convention posters.
const loader=new THREE.TextureLoader();
function poster(url,x,y,z,h){loader.load(url,t=>{t.colorSpace=THREE.SRGBColorSpace;const m=new THREE.Mesh(new THREE.PlaneGeometry(h*.62,h),new THREE.MeshBasicMaterial({map:t,transparent:true,side:THREE.DoubleSide}));m.position.set(x,y,z);scene.add(m)})}
poster('HazbinHotel-Alastor.png',-9,3.1,-23,4.4);
poster('Niffty_Main_Series_Render_.webp',9,2.8,-23,3.8);
poster('Emily_Render%20(1).webp',-13,2.5,-17,3.2);

const targetColors=[['#f74872','#ffcd77','#5d234f'],['#8c72ff','#f4bde7','#39295f'],['#ff9553','#ffe58c','#72345e'],['#36bac8','#ffc8e4','#30345d']];
const targets=[];
const raycaster=new THREE.Raycaster();
const pointer=new THREE.Vector2();
const clock=new THREE.Clock();
let playing=false, score=0, ammo=6, seconds=45, reloadUntil=0, spawnClock=0, soundOn=true, startedAt=0;
let cameraYaw=0,cameraPitch=.035,walkClock=0;
const heldKeys=new Set();
const shotAudio=new Audio('sfx/arcade-shot.wav');shotAudio.preload='auto';
const scoreEl=document.querySelector('#score'), timeEl=document.querySelector('#time'), ammoEl=document.querySelector('#ammoPips');
const statusEl=document.querySelector('#status'), toastEl=document.querySelector('#toast');
function drawAmmo(){ammoEl.innerHTML=Array.from({length:6},(_,i)=>`<i class="pip ${i>=ammo?'empty':''}"></i>`).join('');const reloadBtn=document.querySelector('#reloadBtn');if(reloadBtn)reloadBtn.disabled=ammo>=6||performance.now()<reloadUntil}
drawAmmo();
function arcadeShot(){if(!soundOn)return;const shot=shotAudio.cloneNode();shot.volume=.68;shot.play().catch(()=>{})}
// The uploaded .GLB is a packaged editor project, so its embedded face art anchors
// a lightweight 3D player model built from matching shapes for this web version.
const player=new THREE.Group();player.position.set(0,0,4);scene.add(player);
const playerPurple=mat('#7411a9',.52), playerDark=mat('#321044'), playerSkin=mat('#ede8ed'), playerWhite=mat('#fffaff',.38), playerGold=mat('#ffcf75',.35,.3);
const body=new THREE.Group();player.add(body);
const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.35,.62,5,10),playerDark);torso.position.y=1;torso.castShadow=true;body.add(torso);
const chest=new THREE.Mesh(new THREE.BoxGeometry(.48,.48,.39),playerPurple);chest.position.set(0,1.15,-.015);chest.castShadow=true;body.add(chest);
const head=new THREE.Group();head.position.set(0,1.82,0);body.add(head);
const headShape=new THREE.Mesh(new THREE.SphereGeometry(.39,20,16),playerSkin);headShape.castShadow=true;head.add(headShape);
const cap=new THREE.Mesh(new THREE.SphereGeometry(.43,20,14,0,Math.PI*2,0,Math.PI*.47),playerPurple);cap.scale.set(1.06,.94,1.05);cap.position.y=.12;cap.castShadow=true;head.add(cap);
const capBand=new THREE.Mesh(new THREE.TorusGeometry(.35,.045,7,24),playerDark);capBand.rotation.x=Math.PI/2;capBand.position.set(0,.02,0);head.add(capBand);
for(const side of [-1,1]){const ear=new THREE.Mesh(new THREE.SphereGeometry(.13,12,10),playerSkin);ear.scale.set(.8,1.2,.7);ear.position.set(side*.38,-.04,0);head.add(ear)}
const faceTexture=loader.load('novo-player-face.png');faceTexture.colorSpace=THREE.SRGBColorSpace;
const face=new THREE.Mesh(new THREE.PlaneGeometry(.64,.8),new THREE.MeshBasicMaterial({map:faceTexture,transparent:true,side:THREE.DoubleSide,depthWrite:false}));face.position.set(0,-.03,-.326);head.add(face);
const badge=new THREE.Mesh(new THREE.CircleGeometry(.105,16),playerWhite);badge.position.set(0,.29,-.415);head.add(badge);
const armPivots=[],legPivots=[];
for(const side of [-1,1]){
 const armPivot=new THREE.Group();armPivot.position.set(side*.39,1.28,0);body.add(armPivot);const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.12,.5,4,8),playerPurple);arm.position.y=-.34;arm.castShadow=true;armPivot.add(arm);armPivots.push(armPivot);
 const legPivot=new THREE.Group();legPivot.position.set(side*.17,.51,0);body.add(legPivot);const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.14,.48,4,8),playerDark);leg.position.y=-.23;leg.castShadow=true;legPivot.add(leg);const boot=new THREE.Mesh(new THREE.BoxGeometry(.28,.16,.4),playerPurple);boot.position.set(0,-.48,-.07);boot.castShadow=true;legPivot.add(boot);legPivots.push(legPivot);
}
const shoulderCape=new THREE.Mesh(new THREE.ConeGeometry(.58,.48,4),playerDark);shoulderCape.position.set(0,1.1,.18);shoulderCape.rotation.x=Math.PI;body.add(shoulderCape);
const gun=new THREE.Group();gun.position.set(.5,1.02,-.3);gun.rotation.x=-.05;body.add(gun);
const gunBody=new THREE.Mesh(new THREE.BoxGeometry(.24,.2,.52),mat('#303044',.35,.65));gunBody.castShadow=true;gun.add(gunBody);
const gunTop=new THREE.Mesh(new THREE.BoxGeometry(.16,.1,.34),playerGold);gunTop.position.set(0,.14,-.04);gunTop.castShadow=true;gun.add(gunTop);
const gunBarrel=new THREE.Mesh(new THREE.BoxGeometry(.105,.1,.42),mat('#181724',.28,.75));gunBarrel.position.set(0,.015,-.43);gunBarrel.castShadow=true;gun.add(gunBarrel);
const grip=new THREE.Mesh(new THREE.BoxGeometry(.14,.3,.16),mat('#542445',.55,.15));grip.position.set(0,-.21,.1);grip.rotation.x=-.18;grip.castShadow=true;gun.add(grip);
const muzzleFlash=new THREE.Group();muzzleFlash.position.set(0,.015,-.68);muzzleFlash.visible=false;gun.add(muzzleFlash);
const flashMat=new THREE.MeshBasicMaterial({color:'#fff7a6'}),flashHot=new THREE.MeshBasicMaterial({color:'#ff9d42'});
const flashCore=new THREE.Mesh(new THREE.BoxGeometry(.18,.16,.12),flashMat);muzzleFlash.add(flashCore);
const flashSide=new THREE.Mesh(new THREE.BoxGeometry(.36,.07,.09),flashHot);muzzleFlash.add(flashSide);
const flashUp=new THREE.Mesh(new THREE.BoxGeometry(.07,.34,.09),flashHot);muzzleFlash.add(flashUp);
function updateCamera(dt,moving){
 const forward=new THREE.Vector3(Math.sin(cameraYaw),0,-Math.cos(cameraYaw));
 const right=new THREE.Vector3(Math.cos(cameraYaw),0,Math.sin(cameraYaw));
 const desired=new THREE.Vector3().copy(player.position).addScaledVector(forward,-4.6).addScaledVector(right,.85);desired.y+=2.8;
 camera.position.lerp(desired,Math.min(1,dt*7));
 const look=new THREE.Vector3().copy(player.position).addScaledVector(forward,8.5);look.y+=1.18+Math.sin(cameraPitch)*6;
 camera.lookAt(look);
 if(moving){walkClock+=dt*10;body.position.y=.035+Math.abs(Math.sin(walkClock))*0.045;legPivots[0].rotation.x=Math.sin(walkClock)*.58;legPivots[1].rotation.x=-Math.sin(walkClock)*.58;armPivots[0].rotation.x=-Math.sin(walkClock)*.38;armPivots[1].rotation.x=Math.sin(walkClock)*.38;}
 else{body.position.y=THREE.MathUtils.damp(body.position.y,0,8,dt);legPivots.forEach(p=>p.rotation.x=THREE.MathUtils.damp(p.rotation.x,0,8,dt));armPivots.forEach(p=>p.rotation.x=THREE.MathUtils.damp(p.rotation.x,0,8,dt));}
}
function standee(x,z,variant=0){
 const group=new THREE.Group();group.position.set(x,.2,z);scene.add(group);
 const [skin,accent,coat]=targetColors[variant%targetColors.length].map(c=>mat(c));
 const board=box(1.65,2.7,.12,0,1.38,-.16,mat('#413145'),group); board.material.roughness=.95;
 // The targets are convention standees: big heads, costume ears, and a bright fan badge.
 const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.38,.56,4,8),coat);torso.position.set(0,.84,.04);torso.castShadow=true;group.add(torso);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.43,18,14),skin);head.scale.set(1,.98,.72);head.position.set(0,1.72,.12);head.castShadow=true;group.add(head);
 const earGeo=new THREE.ConeGeometry(.16,.58,5);
 for(const side of [-1,1]){const ear=new THREE.Mesh(earGeo,accent);ear.position.set(side*.27,2.15,.1);ear.rotation.z=side*.24;group.add(ear)}
 const eyeMat=mat('#2b1730',.4), white=mat('#fff3d7',.35);
 for(const side of [-1,1]){const eye=new THREE.Mesh(new THREE.SphereGeometry(.052,10,8),white);eye.position.set(side*.14,1.77,.47);group.add(eye);const pupil=new THREE.Mesh(new THREE.SphereGeometry(.026,8,6),eyeMat);pupil.position.set(side*.14,1.77,.516);group.add(pupil)}
 const smile=new THREE.Mesh(new THREE.TorusGeometry(.12,.025,5,12,Math.PI),eyeMat);smile.position.set(0,1.58,.45);smile.rotation.z=Math.PI;group.add(smile);
 // A tiny sign makes the fan theme unmistakable while keeping the scene playful.
 const sign=box(.55,.35,.06,.02,1.02,.43,accent,group);sign.rotation.z=-.06;
 const heart=new THREE.Mesh(new THREE.ShapeGeometry(heartShape()),new THREE.MeshBasicMaterial({color:'#fff1e3',side:THREE.DoubleSide}));heart.scale.set(.12,.12,.12);heart.position.set(-.03,1,.47);group.add(heart);
 for(const side of [-1,1]){const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.095,.4,3,6),skin);arm.position.set(side*.48,.88,.05);arm.rotation.z=side*.3;group.add(arm);const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.12,.35,3,6),accent);leg.position.set(side*.18,.3,.04);group.add(leg)}
 const target={group, meshes:[],phase:Math.random()*6.28,homeX:x,homeY:.2, speed:.45+Math.random()*.28, dead:false, variant};
 group.traverse(o=>{if(o.isMesh) {o.userData.target=target;target.meshes.push(o)}});
 targets.push(target);return target;
}
function heartShape(){const s=new THREE.Shape();s.moveTo(0,.3);s.bezierCurveTo(-.5,.7,-.9,.15,0,-.38);s.bezierCurveTo(.9,.15,.5,.7,0,.3);return s}
function spawn(){const z=-8.8-Math.random()*4.2;const visibleWidth=2.5+Math.abs(z)*.37;standee((Math.random()-.5)*visibleWidth,z,Math.floor(Math.random()*targetColors.length))}
for(let i=0;i<5;i++)spawn();

function start(){document.querySelector('#startScreen').classList.add('hidden');document.querySelector('#endScreen').classList.add('hidden');score=0;ammo=6;seconds=45;reloadUntil=0;spawnClock=0;heldKeys.clear();drawAmmo();scoreEl.textContent='0000';timeEl.textContent='45';statusEl.textContent='WASD WALK · MOUSE AIM · CLICK FIRE';targets.forEach(t=>scene.remove(t.group));targets.length=0;for(let i=0;i<5;i++)spawn();player.position.set(0,0,4);player.rotation.y=0;cameraYaw=0;cameraPitch=.035;playing=true;startedAt=performance.now();clock.getDelta();if(!matchMedia('(pointer:coarse)').matches)renderer.domElement.requestPointerLock?.()}
function endRound(){playing=false;if(document.pointerLockElement)document.exitPointerLock();document.querySelector('#endTitle').textContent=score>=1000?'ZONE LEGEND':'NICE SHOOTING';document.querySelector('#finalScore').textContent=String(score).padStart(4,'0');document.querySelector('#endScreen').classList.remove('hidden')}
function shoot(){if(!playing)return;if(performance.now()<reloadUntil){return}if(ammo<=0){statusEl.textContent='TAP RELOAD';return}ammo--;drawAmmo();document.querySelector('.reticle').classList.add('firing');setTimeout(()=>document.querySelector('.reticle').classList.remove('firing'),80);muzzleFlash.visible=true;setTimeout(()=>muzzleFlash.visible=false,65);arcadeShot();
 pointer.set(0,0);raycaster.setFromCamera(pointer,camera);const hits=raycaster.intersectObjects(targets.flatMap(t=>t.meshes),false);const hit=hits.find(h=>h.object.userData.target&&!h.object.userData.target.dead);
 if(hit){const t=hit.object.userData.target;t.dead=true;score+=100;scoreEl.textContent=String(score).padStart(4,'0');document.querySelector('#hitFlash').classList.remove('show');void document.querySelector('#hitFlash').offsetWidth;document.querySelector('#hitFlash').classList.add('show');toastEl.textContent=['POP!','NICE!','BULLSEYE!'][Math.floor(Math.random()*3)];toastEl.classList.remove('show');void toastEl.offsetWidth;toastEl.classList.add('show');statusEl.textContent='TARGET POPPED +100';t.group.userData.pop=true;t.popAt=performance.now();}
 else {statusEl.textContent='MISS — KEEP YOUR EYE IN';}
 if(ammo===0)statusEl.textContent='RELOAD YOUR DARTS';
}
function reload(){if(!playing||ammo===6||performance.now()<reloadUntil)return;reloadUntil=performance.now()+950;document.querySelector('#reloadBtn').disabled=true;statusEl.textContent='RELOADING…';setTimeout(()=>{if(playing){reloadUntil=0;ammo=6;drawAmmo();statusEl.textContent='BACK IN ACTION'}},950)}
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.05), now=performance.now();
 let moving=false;
 if(playing){seconds=Math.max(0,45-Math.floor((now-startedAt)/1000));timeEl.textContent=String(seconds).padStart(2,'0');if(seconds===0)endRound();spawnClock+=dt;if(spawnClock>1.65&&targets.filter(t=>!t.dead).length<6){spawn();spawnClock=0}
  const forward=new THREE.Vector3(Math.sin(cameraYaw),0,-Math.cos(cameraYaw)),right=new THREE.Vector3(Math.cos(cameraYaw),0,Math.sin(cameraYaw));
  const move=new THREE.Vector3();if(heldKeys.has('w')||heldKeys.has('arrowup'))move.add(forward);if(heldKeys.has('s')||heldKeys.has('arrowdown'))move.sub(forward);if(heldKeys.has('d')||heldKeys.has('arrowright'))move.add(right);if(heldKeys.has('a')||heldKeys.has('arrowleft'))move.sub(right);
  if(move.lengthSq()>0){move.normalize();moving=true;player.position.addScaledVector(move,4.6*dt);player.position.x=THREE.MathUtils.clamp(player.position.x,-8,8);player.position.z=THREE.MathUtils.clamp(player.position.z,-5,9.5);const faceYaw=Math.atan2(move.x,-move.z),angleDelta=((faceYaw-player.rotation.y+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;player.rotation.y+=angleDelta*Math.min(1,9*dt)}
 }
 updateCamera(dt,moving);
 targets.forEach((t,i)=>{if(t.dead){if(t.popAt){const age=(now-t.popAt)/300;t.group.scale.setScalar(Math.max(0,1-age));t.group.rotation.z=age*.75;if(age>=1){scene.remove(t.group);t.popAt=0}}return}t.phase+=dt*t.speed;t.group.position.x=t.homeX+Math.sin(t.phase)*.48;t.group.position.y=t.homeY+Math.sin(t.phase*1.8)*.11;t.group.rotation.y=Math.sin(t.phase*.7)*.055});
 renderer.render(scene,camera)}
animate();
renderer.domElement.addEventListener('pointerdown',e=>{if(e.button===0){e.preventDefault();if(playing&&!document.pointerLockElement&&!matchMedia('(pointer:coarse)').matches)renderer.domElement.requestPointerLock?.();shoot()}});
document.addEventListener('pointerlockchange',()=>{if(playing)statusEl.textContent=document.pointerLockElement?'WASD WALK · MOUSE AIM · CLICK FIRE':'CLICK SCENE TO AIM · WASD WALK'});
document.addEventListener('mousemove',e=>{if(playing&&document.pointerLockElement===renderer.domElement){cameraYaw+=e.movementX*.0022;cameraPitch=THREE.MathUtils.clamp(cameraPitch-e.movementY*.0016,-.2,.24)}});
window.addEventListener('keydown',e=>{const key=e.key.toLowerCase();if(key==='r')reload();if(['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright'].includes(key)){heldKeys.add(key);e.preventDefault()}});
window.addEventListener('keyup',e=>heldKeys.delete(e.key.toLowerCase()));window.addEventListener('blur',()=>heldKeys.clear());
document.querySelectorAll('#touchPad button').forEach(button=>{const down=e=>{e.preventDefault();e.stopPropagation();const key={forward:'w',back:'s',left:'a',right:'d'}[button.dataset.move];heldKeys.add(key);button.classList.add('pressed');button.setPointerCapture?.(e.pointerId)};const up=e=>{e.preventDefault();const key={forward:'w',back:'s',left:'a',right:'d'}[button.dataset.move];heldKeys.delete(key);button.classList.remove('pressed')};button.addEventListener('pointerdown',down);button.addEventListener('pointerup',up);button.addEventListener('pointercancel',up);button.addEventListener('lostpointercapture',up)});
document.querySelector('#startBtn').addEventListener('click',start);document.querySelector('#againBtn').addEventListener('click',start);
document.querySelector('#reloadBtn').addEventListener('click',reload);
document.querySelector('#soundBtn').addEventListener('click',()=>{soundOn=!soundOn;document.querySelector('#soundBtn').textContent=soundOn?'SOUND ON':'SOUND OFF'});
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(Math.max(180,Math.floor(innerWidth*PIXEL_SCALE)),Math.max(120,Math.floor(innerHeight*PIXEL_SCALE)),false)});
