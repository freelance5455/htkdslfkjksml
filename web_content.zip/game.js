(() => {
'use strict';
const C = window.CFG, $ = id => document.getElementById(id);
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const sm = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const lerp = (a, b, t) => a + (b - a) * t;

/* ---------- seeded noise ---------- */
function h2(x, y) {
  let n = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(C.seed, 1013904223)) | 0;
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967295;
}
function vnoise(x, y) {
  const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0;
  const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
  return lerp(lerp(h2(x0, y0), h2(x0 + 1, y0), u), lerp(h2(x0, y0 + 1), h2(x0 + 1, y0 + 1), u), v);
}
function fbm(x, y, o) {
  let s = 0, a = 0.5, f = 1, t = 0;
  for (let i = 0; i < o; i++) { s += a * vnoise(x * f, y * f); t += a; a *= 0.5; f *= 2.03; }
  return s / t;
}
let rs = C.seed * 9301 + 49297;
const rnd = () => (rs = (rs * 16807) % 2147483647) / 2147483647;

/* ---------- real-world terrain (Terrarium elevation tiles) ---------- */
let REAL = null;
function realH(x, z) {
  const N = REAL.n, u = clamp((x / C.size + 0.5) * (N - 1), 0, N - 1.001), v = clamp((z / C.size + 0.5) * (N - 1), 0, N - 1.001);
  const i = Math.floor(u), j = Math.floor(v), fx = u - i, fy = v - j, G = REAL.g;
  let e = lerp(lerp(G[j * N + i], G[j * N + i + 1], fx), lerp(G[(j + 1) * N + i], G[(j + 1) * N + i + 1], fx), fy) - REAL.base;
  if (REAL.m) { const M = REAL.m, m = lerp(lerp(M[j * N + i], M[j * N + i + 1], fx), lerp(M[(j + 1) * N + i], M[(j + 1) * N + i + 1], fx), fy); if (m > 0.05) e = lerp(e, -3, sm(0.2, 0.85, m)); }   // real lakes
  if (e < 0) e = -4 * (1 - Math.exp(e / 4));            // river floor stays a shallow stream
  return e;
}
async function loadReal() {
  const R = C.real, Z = 14, n = 2 ** Z, lat = R.lat * Math.PI / 180;
  const fx = (R.lon + 180) / 360 * n, fy = (1 - Math.log(Math.tan(lat) + 1 / Math.cos(lat)) / Math.PI) / 2 * n;
  const tx0 = Math.floor(fx - 0.5), ty0 = Math.floor(fy - 0.5);
  const cv = document.createElement('canvas'); cv.width = cv.height = 512; const cx = cv.getContext('2d', { willReadFrequently: true });
  await Promise.all([0, 1].flatMap(i => [0, 1].map(j => new Promise((res, rej) => {
    const im = new Image(); im.crossOrigin = 'anonymous';
    im.onload = () => { cx.drawImage(im, i * 256, j * 256); res(); }; im.onerror = () => rej(new Error('tile'));
    im.src = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/' + Z + '/' + (tx0 + i) + '/' + (ty0 + j) + '.png';
  }))));
  const px = cx.getImageData(0, 0, 512, 512).data, E = new Float32Array(512 * 512);
  for (let k = 0; k < 512 * 512; k++) E[k] = px[k * 4] * 256 + px[k * 4 + 1] + px[k * 4 + 2] / 256 - 32768;
  const mpp = 156543.03392 * Math.cos(lat) / n, N = Math.min(500, Math.round(C.size / mpp) + 1), cxp = (fx - tx0) * 256, cyp = (fy - ty0) * 256, span = C.size / mpp, g = new Float32Array(N * N);
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
    const sx = clamp(cxp + (i / (N - 1) - 0.5) * span, 0, 510.99), sy = clamp(cyp + (j / (N - 1) - 0.5) * span, 0, 510.99), x0 = Math.floor(sx), y0 = Math.floor(sy), ax = sx - x0, ay = sy - y0;
    g[j * N + i] = lerp(lerp(E[y0 * 512 + x0], E[y0 * 512 + x0 + 1], ax), lerp(E[(y0 + 1) * 512 + x0], E[(y0 + 1) * 512 + x0 + 1], ax), ay);
  }
  const sorted = Float32Array.from(g).sort(), lo = sorted[Math.floor(g.length * 0.002)], hi = sorted[Math.floor(g.length * 0.998)];
  // Water only where it really is: flat lake surfaces (flat over ~300 m) and the very bottom of deep gorges (rivers). Valleys are NOT flooded.
  const RW = 15, mn = new Float32Array(N * N), mx = new Float32Array(N * N), t1 = new Float32Array(N * N), t2 = new Float32Array(N * N);
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { let a = 1e9, b = -1e9; for (let k = Math.max(0, i - RW); k <= Math.min(N - 1, i + RW); k++) { const v = g[j * N + k]; if (v < a) a = v; if (v > b) b = v; } t1[j * N + i] = a; t2[j * N + i] = b; }
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { let a = 1e9, b = -1e9; for (let k = Math.max(0, j - RW); k <= Math.min(N - 1, j + RW); k++) { const v1 = t1[k * N + i], v2 = t2[k * N + i]; if (v1 < a) a = v1; if (v2 > b) b = v2; } mn[j * N + i] = a; mx[j * N + i] = b; }
  const lake = new Float32Array(N * N); let any = 0; for (let k = 0; k < N * N; k++) if (mx[k] - mn[k] < 0.8) { lake[k] = 1; any++; }
  const mask = new Float32Array(N * N);   // soften the shoreline
  for (let j = 1; j < N - 1; j++) for (let i = 1; i < N - 1; i++) { let a = 0; for (let dj = -2; dj <= 2; dj++) for (let di = -2; di <= 2; di++) a += lake[(j + dj < 0 ? 0 : j + dj >= N ? N - 1 : j + dj) * N + Math.min(N - 1, Math.max(0, i + di))]; mask[j * N + i] = a / 25; }
  REAL = { g, n: N, base: (hi - lo > 120) ? lo + 1.2 : lo - 3, m: any > 200 ? mask : null, min: sorted[0], max: sorted[sorted.length - 1] };
}

function heightAt(x, z) {
  let h;
  if (REAL) h = realH(x, z) + (vnoise(x * 0.35, z * 0.35) - 0.5) * 0.35 + (vnoise(x * 0.08, z * 0.08) - 0.5) * 0.8;
  else {
  const n = fbm(x * 0.0011, z * 0.0011, 6);
  const r = 1 - Math.abs(fbm(x * 0.0026 + 50, z * 0.0026 + 50, 5) * 2 - 1);
  const mt = sm(0.46, 0.68, n);
  h = (n - 0.45) * 120 + Math.pow(r, 2.2) * 130 * mt * mt;          // sharp alpine peaks
  h -= sm(0.6, 0.72, fbm(x * 0.0009 + 300, z * 0.0009 + 300, 3)) * 22 * (1 - mt); // lake basins
  h += (vnoise(x * 0.35, z * 0.35) - 0.5) * 0.35 + (vnoise(x * 0.08, z * 0.08) - 0.5) * 1.2 * (1 - mt * 0.5);
  }
  const d = Math.max(Math.abs(x), Math.abs(z)) / (C.size / 2);
  let hh = REAL ? Math.max(h - sm(0.8, 1, d) * 90, Math.min(h, 0.6)) : h - sm(0.72, 1, d) * 90;
  if (site) hh = lerp(site[3], hh, sm(46, 70, Math.hypot(x - site[0], z - site[1])));
  return hh;
}

/* Ethiopia: climate follows real altitude (metres above sea level). Kolla <1800 hot & dry, Woina Dega 1800-2400 farmland,
   Dega 2400-3200 cool highland, Wurch/Afroalpine >3200 giant lobelia & heath, Danakil/desert <900. */
const ALT = h => REAL ? h + REAL.base : 1400 + h * 12;
const altAt = (x, z) => ALT(heightAt(x, z));
const dryAt = (x, z) => clamp(sm(2250, 1550, altAt(x, z)) * 0.85 + (fbm(x * 0.0007 + 120, z * 0.0007 + 120, 3) - 0.5) * 0.5, 0, 1);
const coldAt = (x, z) => sm(3900, 4300, altAt(x, z));
const SNOWC = new THREE.Color(0xe6eef5);
let site = null;
const inSite = (x, z) => site && Math.hypot(x - site[0], z - site[1]) < site[2];

/* ---------- renderer / scene ---------- */
const canvas = $('view');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
/* ---- shared performance / fx state ---- */
const AN = Math.min(16, renderer.capabilities.getMaxAnisotropy());
const FXS = { zoom: false, shot: false, hud: true, day: 1, glare: 0 };
const WIND = { value: 0 };                       // time uniform for tree sway
const GQ = { R: 44, cs: 0.85, dirty: true };     // grass radius, spacing
const CULL = [], CULLR = { v: 800, dirty: true }; // distance-culled instanced sets (trees, rocks, bushes)
const SUNDIR = new THREE.Vector3(0, 1, 0), WHITEC = new THREE.Color(1, 1, 1), SDV = new THREE.Vector3();
const DUSTC = new THREE.Color(0xd9b98a), HAZE = { v: 0, t: 0, target: 0 };
let cullX = 1e9, cullZ = 1e9;
function regCull(list, ms) {
  const n = list.length; if (!n) return;
  const xs = new Float32Array(n), zs = new Float32Array(n); list.forEach((t, i) => { xs[i] = t[0]; zs[i] = t[2]; });
  const m0 = ms.map(m => Float32Array.from(m.instanceMatrix.array.subarray(0, n * 16)));
  const c0 = ms.map(m => m.instanceColor ? Float32Array.from(m.instanceColor.array.subarray(0, n * 3)) : null);
  ms.forEach(m => { m.frustumCulled = false; });
  CULL.push({ n, xs, zs, ms, m0, c0 });
}
function cullAll(px, pz) {
  if (!CULLR.dirty && Math.hypot(px - cullX, pz - cullZ) < 12) return;
  cullX = px; cullZ = pz; CULLR.dirty = false; const R2 = CULLR.v * CULLR.v;
  for (const g of CULL) {
    let j = 0;
    for (let i = 0; i < g.n; i++) {
      const dx = g.xs[i] - px, dz = g.zs[i] - pz; if (dx * dx + dz * dz > R2) continue;
      for (let k = 0; k < g.ms.length; k++) {
        const a = g.ms[k].instanceMatrix.array, src = g.m0[k], o = i * 16, d = j * 16;
        for (let q = 0; q < 16; q++) a[d + q] = src[o + q];
        const c = g.c0[k]; if (c) { const ca = g.ms[k].instanceColor.array; ca[j * 3] = c[i * 3]; ca[j * 3 + 1] = c[i * 3 + 1]; ca[j * 3 + 2] = c[i * 3 + 2]; }
      }
      j++;
    }
    for (const m of g.ms) { m.count = j; m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; }
  }
}
// gentle wind sway for leaves (same shader code for every material, so the program cache stays valid)
function sway(m) {
  m.onBeforeCompile = sh => {
    sh.uniforms.uW = WIND;
    sh.vertexShader = 'uniform float uW;\n' + sh.vertexShader.replace('#include <begin_vertex>',
      'vec3 transformed=vec3(position); float ph=uW*1.25+instanceMatrix[3].x*.31+instanceMatrix[3].z*.27; float sw=(sin(ph)+.5*sin(ph*2.3+position.x*.7))*.02*max(position.y-1.5,0.); transformed.x+=sw; transformed.z+=sw*.7; transformed.y-=abs(sw)*.12;');
  };
  return m;
}
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.0;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x9ec2e8, 0.0016);
const camera = new THREE.PerspectiveCamera(70, 1, 0.1, 4000);
camera.rotation.order = 'YXZ';
scene.add(camera);

const hemi = new THREE.HemisphereLight(0xbfd8ff, 0x4a4030, 0.7); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xfff1d6, 2.2);
sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
Object.assign(sun.shadow.camera, { left: -70, right: 70, top: 70, bottom: -70, near: 1, far: 400 });
sun.shadow.bias = -0.0006; sun.shadow.normalBias = 0.05;
scene.add(sun, sun.target);
const torch = new THREE.SpotLight(0xffe2b0, 0, 45, 0.5, 0.6, 1.5);
torch.position.set(0.2, -0.2, 0); torch.target.position.set(0, 0, -5);
camera.add(torch, torch.target);

const SU = { uHor: { value: new THREE.Color() }, uZen: { value: new THREE.Color() }, uSun: { value: new THREE.Vector3(0, 1, 0) },
  uSunCol: { value: new THREE.Color(1, 1, 1) }, uNight: { value: 0 }, uDay: { value: 1 }, uTime: { value: 0 } };
const GL_NOISE = `float hs(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hs(i),hs(i+vec2(1.,0.)),f.x),mix(hs(i+vec2(0.,1.)),hs(i+vec2(1.,1.)),f.x),f.y);}
float fb(vec2 p){float s=0.,a=.5;for(int i=0;i<5;i++){s+=a*vn(p);p*=2.02;a*=.5;}return s;}
uniform vec3 uHor,uZen,uSun,uSunCol; uniform float uNight,uDay,uTime;`;
const skyDome = new THREE.Mesh(new THREE.SphereGeometry(3000, 32, 16), new THREE.ShaderMaterial({
  uniforms: SU, side: THREE.BackSide, depthWrite: false, fog: false,
  vertexShader: 'varying vec3 vD; void main(){vD=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader: 'varying vec3 vD;' + GL_NOISE + `
void main(){
  vec3 d=normalize(vD); float e=max(d.y,0.);
  vec3 col=mix(uHor,uZen,pow(e,.5));
  float sd=max(dot(d,uSun),0.), up=smoothstep(-.12,.05,uSun.y);
  col+=uSunCol*(pow(sd,5.)*.3+pow(sd,48.)*.55+smoothstep(.9993,.9997,sd)*4.)*up;
  col+=vec3(.8,.86,1.)*smoothstep(.9994,.9998,dot(d,-uSun))*uNight*2.;
  float mwb=dot(d,normalize(vec3(.35,.25,.9)));
  float mw=exp(-mwb*mwb*10.)*smoothstep(-.05,.3,d.y);
  float mn=fb(d.xz/(max(d.y,0.)+.6)*7.+vec2(3.,9.));
  col+=vec3(.55,.6,.9)*mw*(.25+mn*mn*1.6)*uNight*.3;
  if(d.y>0.){
    vec2 uv=d.xz/(d.y+.14)*.8+uTime*.008; float c=fb(uv*1.3), c2=fb(uv*1.3+uSun.xz*.1);
    float cov=smoothstep(.46,.76,c), lit=clamp(.55+(c2-c)*7.,0.,1.);
    vec3 cc=mix(uHor*.55+vec3(.18,.2,.26), uSunCol*.65+.45, lit);
    cc*=(1.-uNight*.92)*(.3+.7*uDay)+.03;
    col=mix(col,cc,cov*smoothstep(0.,.22,d.y)*.93);
  }
  gl_FragColor=vec4(col,1.);
  #include <tonemapping_fragment>
  #include <encodings_fragment>
}`
}));
skyDome.renderOrder = -10; skyDome.frustumCulled = false; scene.add(skyDome);
function heightTex() {
  const N = 512, d = new Float32Array(N * N * 4);
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) d[(j * N + i) * 4] = heightAt(((i + .5) / N - .5) * C.size, ((j + .5) / N - .5) * C.size);
  const t = new THREE.DataTexture(d, N, N, THREE.RGBAFormat, THREE.FloatType);
  t.minFilter = t.magFilter = THREE.NearestFilter; t.needsUpdate = true; return t;
}
function waterMat(ht) {
  const u = THREE.UniformsUtils.merge([THREE.UniformsLib.fog]);
  Object.assign(u, SU, { uH: { value: ht }, uSz: { value: C.size }, uWl: { value: C.waterLevel } });
  return new THREE.ShaderMaterial({
    uniforms: u, fog: true, transparent: true,
    vertexShader: 'varying vec3 vW;\n#include <fog_pars_vertex>\nvoid main(){vec4 wp=modelMatrix*vec4(position,1.);vW=wp.xyz;vec4 mvPosition=viewMatrix*wp;gl_Position=projectionMatrix*mvPosition;\n#include <fog_vertex>\n}',
    fragmentShader: 'varying vec3 vW;\n#include <fog_pars_fragment>\n' + GL_NOISE + `
uniform sampler2D uH; uniform float uSz,uWl;
float T(vec2 i){return texture2D(uH,(clamp(i,0.,255.)+.5)/256.).r;}
float terr(vec2 w){vec2 u=(w/uSz+.5)*256.-.5; vec2 i=floor(u),f=fract(u); return mix(mix(T(i),T(i+vec2(1.,0.)),f.x),mix(T(i+vec2(0.,1.)),T(i+vec2(1.,1.)),f.x),f.y);}
float wh(vec2 p){float t=uTime;return vn(p*.35+vec2(t*.05,t*.03))+vn(p*1.1-vec2(t*.12,-t*.08))*.5+vn(p*3.3+vec2(t*.25,t*.2))*.25;}
void main(){
  vec2 p=vW.xz; float h0=wh(p), dep=max(uWl-terr(p),0.);
  vec3 n=normalize(vec3((h0-wh(p+vec2(.15,0.)))*1.3,1.,(h0-wh(p+vec2(0.,.15)))*1.3));
  vec3 V=normalize(cameraPosition-vW); vec3 R=reflect(-V,n); R.y=abs(R.y);
  vec3 sk=mix(uHor,uZen,pow(R.y,.5)); float sd=max(dot(R,uSun),0.);
  sk+=uSunCol*(pow(sd,300.)*4.+pow(sd,8.)*.12)*smoothstep(-.1,.05,uSun.y);
  sk+=vec3(.7,.8,1.)*pow(max(dot(R,-uSun),0.),400.)*3.*uNight;
  float F=.03+.97*pow(1.-max(dot(n,V),0.),5.);
  vec3 shallow=vec3(.14,.45,.4)*(.35+.65*uDay)+vec3(0.,.012,.02);
  vec3 deep=vec3(.02,.12,.15)*(.25+.75*uDay)+vec3(0.,.01,.02);
  vec3 col=mix(mix(shallow,deep,smoothstep(0.,6.,dep)),sk,clamp(F+.15,0.,1.));
  float foam=smoothstep(.7,0.,dep)*(.45+.55*vn(p*2.+uTime*.35));
  col=mix(col,vec3(.9,.95,1.)*(.25+.75*uDay),foam*.65);
  gl_FragColor=vec4(col,mix(.35,.94,smoothstep(0.,1.2,dep)));
  #include <tonemapping_fragment>
  #include <encodings_fragment>
  #include <fog_fragment>
}`
  });
}
const sp = new Float32Array(2400 * 3);
for (let i = 0; i < 2400; i++) {
  const u = rnd() * 2 - 1, a = rnd() * 6.2832, r = Math.sqrt(1 - u * u);
  sp.set([r * Math.cos(a) * 2500, u * 2500, r * Math.sin(a) * 2500], i * 3);
}
const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
const stars = new THREE.Points(sg, new THREE.PointsMaterial({ color: 0xffffff, size: 1.6, sizeAttenuation: false, transparent: true, fog: false, depthWrite: false }));
scene.add(stars);

/* ---------- procedural PBR detail ---------- */
function groundNormals() {
  const N = 256, hg = new Float32Array(N * N);
  const pn = (x, y, per) => {
    const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0, u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    const H = (i, j) => h2(((i % per) + per) % per + 1000, ((j % per) + per) % per + 1000);
    return lerp(lerp(H(x0, y0), H(x0 + 1, y0), u), lerp(H(x0, y0 + 1), H(x0 + 1, y0 + 1), u), v);
  };
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) { let v = 0, a = 1; for (const per of [8, 16, 32, 64, 128]) { v += a * pn(i / N * per, j / N * per, per); a *= 0.58; } hg[j * N + i] = v; }
  const d = new Uint8Array(N * N * 4);
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
    const dx = hg[j * N + (i + 1) % N] - hg[j * N + (i + N - 1) % N], dy = hg[((j + 1) % N) * N + i] - hg[((j + N - 1) % N) * N + i];
    const l = Math.hypot(dx * 2.6, dy * 2.6, 1), o = (j * N + i) * 4;
    d[o] = (-dx * 2.6 / l * 0.5 + 0.5) * 255; d[o + 1] = (-dy * 2.6 / l * 0.5 + 0.5) * 255; d[o + 2] = (1 / l * 0.5 + 0.5) * 255; d[o + 3] = 255;
  }
  return (rx, ry) => {
    const t = new THREE.DataTexture(d, N, N, THREE.RGBAFormat);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.magFilter = THREE.LinearFilter; t.minFilter = THREE.LinearMipmapLinearFilter;
    t.generateMipmaps = true; t.anisotropy = AN; t.needsUpdate = true; return t;
  };
}
function branchTex() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 128; const g = c.getContext('2d'); g.lineCap = 'round';
  g.strokeStyle = '#4a3a28'; g.lineWidth = 2.6; g.beginPath(); g.moveTo(0, 64); g.lineTo(252, 64); g.stroke();
  for (let k = 0; k < 760; k++) {
    const t = Math.pow(Math.random(), 0.8), x = 6 + t * 240, side = Math.random() < 0.5 ? -1 : 1, len = (50 * (1 - t * 0.55) + 8) * (0.45 + Math.random() * 0.55), a = side * (0.3 + Math.random() * 0.95);
    g.strokeStyle = 'hsl(' + (92 + Math.random() * 32) + ',' + (30 + Math.random() * 22) + '%,' + (30 + Math.random() * 24) + '%)';
    g.lineWidth = 1.5 + Math.random() * 1.1; g.beginPath(); g.moveTo(x, 64); g.lineTo(x + Math.cos(a) * len * 0.55 + 9 * (1 - t), 64 + Math.sin(a) * len); g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = AN; return t;
}
function branchGeo() {
  const P = [], U = [], N = [], I = [];
  const quad = (o, d, w, len) => {
    const b = P.length / 3, tp = [o[0] + d[0] * len, o[1] + d[1] * len, o[2] + d[2] * len];
    [[o[0] - w[0], o[1] - w[1], o[2] - w[2], 0, 0], [o[0] + w[0], o[1] + w[1], o[2] + w[2], 0, 1], [tp[0] + w[0], tp[1] + w[1], tp[2] + w[2], 1, 1], [tp[0] - w[0], tp[1] - w[1], tp[2] - w[2], 1, 0]]
      .forEach(v => { P.push(v[0], v[1], v[2]); U.push(v[3], v[4]); N.push(d[0] * 0.4, 0.9, d[2] * 0.4); });
    I.push(b, b + 1, b + 2, b, b + 2, b + 3);
  };
  for (let L = 0; L < 20; L++) {
    const t = L / 19, y = 2.6 + t * 13.2, len = 5.2 * Math.pow(1 - t, 0.8) + 0.6, dr = 0.45 * (1 - t) + 0.12;
    for (let b = 0; b < 5; b++) {
      const j = h2(L * 7 + b, 31), ln = len * (0.75 + j * 0.5), a = L * 2.399 + b * Math.PI * 0.4 + j * 0.6;
      const d = [Math.cos(a) * Math.cos(dr), -Math.sin(dr), Math.sin(a) * Math.cos(dr)], o = [d[0] * 0.12, y + (j - 0.5) * 0.5, d[2] * 0.12];
      quad(o, d, [-Math.sin(a) * ln * 0.38, 0, Math.cos(a) * ln * 0.38], ln); quad(o, d, [0, ln * 0.3, 0], ln);
    }
  }
  quad([0, 15, 0], [0, 1, 0], [0.55, 0, 0], 2.4); quad([0, 15, 0], [0, 1, 0], [0, 0, 0.55], 2.4);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(U, 2)); g.setIndex(I);
  return g;
}

/* ---------- terrain ---------- */
function detailTexture() {
  const c = document.createElement('canvas'); c.width = c.height = 256;
  const g = c.getContext('2d'), d = g.createImageData(256, 256);
  for (let i = 0; i < 256 * 256; i++) {
    const v = 175 + rnd() * 60 + (vnoise((i % 256) * 0.12, (i / 256 | 0) * 0.12) - 0.5) * 50;
    d.data.set([v, v, v, 255], i * 4);
  }
  g.putImageData(d, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(C.size / 6, C.size / 6);
  t.anisotropy = AN; t.encoding = THREE.sRGBEncoding;
  return t;
}
function buildTerrain() {
  const g = new THREE.PlaneGeometry(C.size, C.size, C.seg, C.seg);
  g.rotateX(-Math.PI / 2);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) p.setY(i, heightAt(p.getX(i), p.getZ(i)));
  g.computeVertexNormals();
  const n = g.attributes.normal, col = new Float32Array(p.count * 3), W = C.seg + 1, ao = new Float32Array(p.count).fill(1);
  for (let r = 1; r < C.seg; r++) for (let q = 1; q < C.seg; q++) {
    const i = r * W + q, cav = (p.getY(i - 1) + p.getY(i + 1) + p.getY(i - W) + p.getY(i + W)) / 4 - p.getY(i);
    ao[i] = 1 - clamp(cav * 0.09, -0.12, 0.4);
  }
  const sand = [.78, .7, .5], grass1 = [.17, .29, .07], grass2 = [.32, .41, .12], rock = [.43, .35, .28], mud = [.3, .21, .14], laterite = [.5, .26, .14], savanna = [.66, .53, .27], tussock = [.43, .41, .2], heath = [.26, .29, .15];
  const mix = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
  const fieldCols = [[.2, .43, .1], [.72, .6, .25], [.4, .27, .16], [.86, .76, .16], [.55, .5, .2], [.3, .38, .12]];
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i), up = n.getY(i), alt = ALT(y);
    const wet = fbm(x * 0.004 + 77, z * 0.004 + 77, 3);
    const zKol = sm(2050, 1550, alt), zDes = sm(1000, 550, alt), zAlp = sm(3150, 3500, alt), zFro = sm(4100, 4500, alt);
    let c = mix(grass1, grass2, fbm(x * 0.02, z * 0.02, 3));
    c = mix(c, mud, sm(0.62, 0.5, fbm(x * 0.01 + 9, z * 0.01, 3)) * 0.35);
    c = mix(c, savanna, zKol * (0.45 + 0.45 * (1 - wet)));                                   // dry golden grass
    c = mix(c, laterite, zKol * sm(0.55, 0.38, wet) * 0.55);                                 // red laterite soil
    c = mix(c, tussock, zAlp * 0.85);                                                        // afroalpine tussock
    c = mix(c, heath, zAlp * sm(0.5, 0.66, fbm(x * 0.012 + 40, z * 0.012, 3)) * 0.6);        // erica heath patches
    // patchwork highland farms: teff gold, green barley, ploughed brown, yellow Meskel flowers
    const farm = sm(1550, 1800, alt) * sm(3250, 2950, alt) * sm(0.9, 0.97, up) * sm(0.4, 0.48, fbm(x * 0.0016 + 40, z * 0.0016 + 40, 2));
    if (farm > 0.01) {
      const u = (x * 0.8 + z * 0.6) / 38, v = (-x * 0.6 + z * 0.8) / 55, fu = Math.floor(u), fv = Math.floor(v), id = h2(fu * 7 + 3, fv * 13 + 5);
      const hedge = (Math.abs(u - fu - 0.5) > 0.465 || Math.abs(v - fv - 0.5) > 0.47) ? 1 : 0;
      if (id < 0.72) { const fc = fieldCols[Math.floor(id / 0.72 * 6) % 6], rows = 0.93 + 0.07 * Math.sin((x * 0.6 - z * 0.8) * 1.4); c = mix(c, hedge ? [.2, .26, .1] : [fc[0] * rows, fc[1] * rows, fc[2] * rows], farm * 0.92); }
    }
    c = mix(c, sand, sm(3.2, 1.2, y + (vnoise(x * .1, z * .1) - .5) * 1.5) * (1 - zDes * 0.3));
    c = mix(c, [.79, .66, .46], zDes);                                                       // Danakil / lowland desert
    c = mix(c, [.1, .09, .09], zDes * sm(0.52, 0.66, fbm(x * 0.012 + 5, z * 0.012, 3)) * 0.85); // black basalt
    c = mix(c, [.93, .92, .87], zDes * sm(0.66, 0.74, fbm(x * 0.006 + 300, z * 0.006 + 300, 3)) * sm(0.8, 0.95, up)); // salt pans
    const st = 0.85 + 0.2 * Math.sin(y * 0.9 + vnoise(x * .05, z * .05) * 6) + (vnoise(x * .6, z * .6) - .5) * .15;
    const rk = [rock[0] * st, rock[1] * st, rock[2] * st];
    c = mix(c, rk, sm(0.92, 0.74, up) * 0.97);                                               // basalt cliffs and gorge walls
    c = mix(c, rk, sm(3700, 4400, alt) * 0.55);
    c = mix(c, [.86, .89, .92], zFro * sm(0.5, 0.85, up) * 0.55);                            // rare frost on the highest peaks
    const pv = Math.abs(fbm(x * 0.0042 + 11, z * 0.0042 + 11, 3) - 0.5);
    c = mix(c, [.5, .38, .24], sm(0.012, 0.004, pv) * sm(3, 4, y) * sm(30, 20, y) * 0.9);    // dirt tracks
    const j = (0.92 + h2(i, 3) * 0.16) * ao[i] * (1 - sm(0.45, 0.62, fbm(x * 0.007 + 20, z * 0.007, 3)) * 0.22);
    col.set([c[0] * j, c[1] * j, c[2] * j], i * 3);
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, map: detailTexture(), roughness: 0.95, metalness: 0, normalMap: groundNormals()(C.size / 5, C.size / 5), normalScale: new THREE.Vector2(1.15, 1.15) }));
  m.receiveShadow = true; scene.add(m);
  const w = new THREE.Mesh(new THREE.PlaneGeometry(C.size * (REAL ? 1.02 : 2.2), C.size * (REAL ? 1.02 : 2.2)).rotateX(-Math.PI / 2),
    waterMat(heightTex()));
  w.position.y = C.waterLevel; w.receiveShadow = true; scene.add(w);
  return w;
}

/* ---------- vegetation, rocks, collision ---------- */
const grid = new Map(), CELL = 8;
const addCollider = (x, z, r) => { const k = (Math.floor(x / CELL)) + ',' + Math.floor(z / CELL); (grid.get(k) || grid.set(k, []).get(k)).push([x, z, r]); };

function trunkGeo(h, r0, r1, bend) {
  const g = new THREE.CylinderGeometry(r1, r0, h, 10, 12).translate(0, h / 2, 0), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const y = p.getY(i), t = y / h, f = 1 + 1.3 * Math.exp(-y * 1.6) + (h2(Math.round(p.getX(i) * 40), Math.round(y * 9)) - 0.5) * 0.25;
    p.setXYZ(i, p.getX(i) * f + Math.sin(t * 2.4) * bend * t, y, p.getZ(i) * f);
  }
  return g;
}
/* scale a box's UVs to metres so textures keep a true size on walls of any dimension */
function boxUV(g, w, h, d, k = 0.5) {
  const u = g.attributes.uv, dims = [[d, h], [d, h], [w, d], [w, d], [w, h], [w, h]];
  for (let f = 0; f < 6; f++) for (let i = 0; i < 4; i++) { const j = f * 4 + i; u.setXY(j, u.getX(j) * dims[f][0] * k, u.getY(j) * dims[f][1] * k); }
  return g;
}
const TXC = {};
function surfTex(kind) {   // procedural, tiling, near-white so the material colour tints them
  if (TXC[kind]) return TXC[kind];
  const N = 256, c = document.createElement('canvas'); c.width = c.height = N; const g = c.getContext('2d'), R = Math.random;
  const wrapDraw = (fn) => { for (const ox of [-N, 0, N]) for (const oy of [-N, 0, N]) { g.save(); g.translate(ox, oy); fn(); g.restore(); } };
  if (kind === 'plaster') {
    g.fillStyle = '#f0ece2'; g.fillRect(0, 0, N, N);
    for (let i = 0; i < 260; i++) { const v = 205 + R() * 50 | 0, x = R() * N, y = R() * N, r = 6 + R() * 26; wrapDraw(() => { const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(' + v + ',' + (v - 4) + ',' + (v - 12) + ',.28)'); gr.addColorStop(1, 'rgba(' + v + ',' + v + ',' + v + ',0)'); g.fillStyle = gr; g.fillRect(x - r, y - r, 2 * r, 2 * r); }); }
    for (let i = 0; i < 70; i++) { const x = R() * N, y = R() * N, a = R() * 6.28, l = 8 + R() * 30; wrapDraw(() => { g.strokeStyle = 'rgba(' + (120 + R() * 40 | 0) + ',100,80,' + (0.1 + R() * 0.22) + ')'; g.lineWidth = 0.6 + R() * 0.9; g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l * 0.5 + (R() - .5) * 6, y + Math.sin(a) * l * 0.5 + 4); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke(); }); }
    for (let i = 0; i < 400; i++) { g.fillStyle = 'rgba(' + (R() < .5 ? '120,100,70' : '255,255,255') + ',' + (0.1 + R() * 0.2) + ')'; g.fillRect(R() * N, R() * N, 1 + R() * 2, 1 + R() * 2); }
  } else if (kind === 'thatch') {
    g.fillStyle = '#e8d8a8'; g.fillRect(0, 0, N, N);
    for (let i = 0; i < 2600; i++) { const x = R() * N, y = R() * N, v = 150 + R() * 100 | 0, l = 10 + R() * 40; wrapDraw(() => { g.strokeStyle = 'rgba(' + v + ',' + (v - 22) + ',' + (v - 70) + ',' + (0.35 + R() * 0.5) + ')'; g.lineWidth = 0.8 + R() * 1.3; g.beginPath(); g.moveTo(x, y); g.lineTo(x + (R() - .5) * 5, y + l); g.stroke(); }); }
    for (let r = 0; r < 8; r++) { const y = r * 32; g.fillStyle = 'rgba(60,40,10,.22)'; g.fillRect(0, y, N, 2); g.fillStyle = 'rgba(255,240,190,.18)'; g.fillRect(0, y + 2, N, 2); }
  } else if (kind === 'tin') {
    g.fillStyle = '#dcdcdc'; g.fillRect(0, 0, N, N);
    for (let x = 0; x < N; x++) { const s = Math.sin(x / N * 6.2832 * 16), v = 190 + s * 55 | 0; g.fillStyle = 'rgb(' + v + ',' + v + ',' + (v + 4) + ')'; g.fillRect(x, 0, 1, N); }
    for (let i = 0; i < 34; i++) { const x = R() * N, y = R() * N, w = 3 + R() * 14, l = 20 + R() * 90; wrapDraw(() => { const gr = g.createLinearGradient(0, y, 0, y + l); gr.addColorStop(0, 'rgba(150,70,30,.0)'); gr.addColorStop(0.3, 'rgba(150,70,30,' + (0.2 + R() * 0.35) + ')'); gr.addColorStop(1, 'rgba(120,60,30,0)'); g.fillStyle = gr; g.fillRect(x, y, w, l); }); }
    for (let r = 0; r < 4; r++) { g.fillStyle = 'rgba(40,40,40,.25)'; g.fillRect(0, r * 64, N, 2); }
  } else {   // stone: coursed blocks with mortar, grain and lichen
    g.fillStyle = '#d4cfc4'; g.fillRect(0, 0, N, N); const rows = 5, rh = N / rows;
    for (let r = 0; r < rows; r++) { let x = -R() * 60; while (x < N) { const bw = 40 + R() * 56, v = 205 + R() * 50 | 0; g.fillStyle = 'rgb(' + v + ',' + (v - 3) + ',' + (v - 10) + ')'; g.fillRect(x + 1.5, r * rh + 1.5, bw - 3, rh - 3);
        for (let k = 0; k < 18; k++) { g.fillStyle = 'rgba(' + (R() < .5 ? '90,80,70' : '255,255,255') + ',' + (0.05 + R() * 0.1) + ')'; g.fillRect(x + R() * bw, r * rh + R() * rh, 2 + R() * 7, 1 + R() * 2); }
        g.fillStyle = 'rgba(60,50,40,.35)'; g.fillRect(x + bw - 2, r * rh, 2, rh); x += bw; } g.fillStyle = 'rgba(60,50,40,.4)'; g.fillRect(0, r * rh, N, 2.5); }
    for (let i = 0; i < 22; i++) { const x = R() * N, y = R() * N, r = 3 + R() * 9; wrapDraw(() => { g.fillStyle = 'rgba(120,150,80,' + (0.08 + R() * 0.1) + ')'; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill(); }); }
  }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = AN; return (TXC[kind] = t);
}
function mergeG(list) {
  const P = [], N = [], U = [];
  list.forEach(g0 => { const g = g0.index ? g0.toNonIndexed() : g0; for (const [a, o] of [['position', P], ['normal', N], ['uv', U]]) { const r = g.attributes[a].array; for (let i = 0; i < r.length; i++) o.push(r[i]); } });
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(U, 2)); return g;
}
function canopyGeo() {
  const list = [[0, 8.6, 0, 3], [1.9, 7.6, 0.6, 2.3], [-1.8, 7.8, -0.5, 2.4], [0.4, 7.4, 2, 2.2], [-0.3, 7.7, -2, 2.2], [0.2, 10.4, 0.2, 2.1], [2.2, 9.4, -0.8, 1.7], [-2, 9.5, 1, 1.8]].map(([x, y, z, r], bi) => {
    const g = new THREE.IcosahedronGeometry(1, 2), p = g.attributes.position, n = g.attributes.normal;
    for (let i = 0; i < p.count; i++) {
      const dx = p.getX(i), dy = p.getY(i), dz = p.getZ(i), k = r * (0.82 + h2(Math.round(dx * 30) + bi * 17, Math.round((dy + dz) * 30)) * 0.45);
      p.setXYZ(i, x + dx * k, y + dy * k * 0.8, z + dz * k); n.setXYZ(i, dx, dy, dz);
    }
    return g;
  });
  const m = mergeG(list), u = m.attributes.uv; for (let i = 0; i < u.count; i++) u.setXY(i, u.getX(i) * 4, u.getY(i) * 3);
  return m;
}
function leafTex() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
  for (let k = 0; k < 1100; k++) {
    g.fillStyle = 'hsl(' + (70 + Math.random() * 50) + ',' + (40 + Math.random() * 25) + '%,' + (26 + Math.random() * 26) + '%)';
    g.beginPath(); g.ellipse(Math.random() * 256, Math.random() * 256, 8, 4, Math.random() * 6.28, 0, 6.28); g.fill();
  }
  const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = AN; return t;
}
function blobG(x, y, z, rx, ry, rz, bi) {
  const g = new THREE.IcosahedronGeometry(1, 2), p = g.attributes.position, n = g.attributes.normal;
  for (let i = 0; i < p.count; i++) {
    const dx = p.getX(i), dy = p.getY(i), dz = p.getZ(i), k = 0.85 + h2(Math.round(dx * 30) + bi * 17, Math.round((dy + dz) * 30)) * 0.35;
    p.setXYZ(i, x + dx * rx * k, y + dy * ry * k, z + dz * rz * k); n.setXYZ(i, dx * 0.3, dy + 0.25, dz * 0.3);
  }
  return g;
}
function leafUV(m) { const u = m.attributes.uv; for (let i = 0; i < u.count; i++) u.setXY(i, u.getX(i) * 4, u.getY(i) * 3); return m; }
function acaciaGeo() {   // the classic umbrella crown of the savanna
  return leafUV(mergeG([blobG(0, 5.4, 0, 4.6, 0.9, 4.4, 0), blobG(2.7, 4.9, 0.8, 2.8, 0.7, 2.6, 1), blobG(-2.6, 5, -0.8, 2.9, 0.7, 2.7, 2), blobG(0.4, 4.7, 2.8, 2.6, 0.7, 2.5, 3), blobG(-0.3, 4.8, -2.9, 2.6, 0.7, 2.5, 4), blobG(0.2, 6.1, 0.2, 2.6, 0.55, 2.4, 5)]));
}
function eucGeo() {      // tall, narrow, drooping eucalyptus crown
  return leafUV(mergeG([blobG(0, 13.2, 0, 1.7, 3.2, 1.7, 0), blobG(0.9, 10.6, 0.4, 1.4, 2.4, 1.4, 1), blobG(-0.9, 11, -0.3, 1.4, 2.3, 1.4, 2), blobG(0.1, 15.2, 0, 1.1, 2, 1.1, 3)]));
}
function lobeliaGeo() {  // Lobelia rhynchopetalum: rosette of long leaves and one tall flower spike
  const l = [new THREE.CylinderGeometry(0.09, 0.16, 3.2, 6).translate(0, 1.6, 0)];
  for (let k = 0; k < 12; k++) l.push(new THREE.ConeGeometry(0.1, 1.5, 4).translate(0, 0.75, 0).rotateZ(1.1).rotateY(k / 12 * 6.283).translate(0, 3.1, 0));
  l.push(new THREE.ConeGeometry(0.17, 2.6, 6).translate(0, 4.5, 0)); return mergeG(l);
}
function euphGeo() {     // Euphorbia candelabrum
  const l = [new THREE.CylinderGeometry(0.22, 0.3, 2.6, 6).translate(0, 1.3, 0)];
  for (let k = 0; k < 7; k++) l.push(new THREE.CylinderGeometry(0.13, 0.15, 3.2, 6).translate(0, 1.6, 0).rotateZ(0.5 + (k % 2) * 0.18).rotateY(k * 0.9).translate(0, 2.2 + (k % 3) * 0.3, 0));
  return mergeG(l);
}
function populate() {
  CULL.length = 0; CULLR.dirty = true; cullX = 1e9;
  const half = Math.min(C.size * 0.46, 1700), trees = [], rocks = [];
  for (let i = 0, tries = 0; trees.length < C.trees && tries < C.trees * 6; tries++) {
    const x = (rnd() * 2 - 1) * half, z = (rnd() * 2 - 1) * half, h = heightAt(x, z);
    const al = ALT(h); if (h < 2.4 || al > 4150 || inSite(x, z)) continue;
    const dens = fbm(x * 0.007 + 20, z * 0.007, 3);
    let pr = sm(0.42, 0.6, dens) * 0.95 + 0.012; if (al < 1000) pr *= 0.12; else if (al < 1600) pr *= 0.6; if (al > 3300) pr *= 0.4; if (rnd() > pr) continue;
    if (Math.abs(heightAt(x + 2, z) - h) > 1.6 || Math.abs(heightAt(x, z + 2) - h) > 1.6) continue;
    const r = rnd(); let ty;   // 0 juniper, 1 wild fig/olive, 2 acacia, 3 eucalyptus, 4 giant lobelia, 5 candelabra euphorbia
    if (al > 3300) ty = 4; else if (al > 3000) ty = r < 0.6 ? 4 : r < 0.8 ? 1 : 0; else if (al > 2200) ty = r < 0.45 ? 0 : r < 0.8 ? 3 : 1;
    else if (al > 1650) ty = r < 0.4 ? 3 : r < 0.7 ? 2 : 1; else ty = r < 0.12 ? 5 : r < 0.78 ? 2 : 1;
    trees.push([x, h, z, 0.65 + rnd() * 0.8, rnd() * 6.28, ty]);
  }
  for (let tries = 0; rocks.length < C.rocks && tries < C.rocks * 8; tries++) {
    const x = (rnd() * 2 - 1) * half, z = (rnd() * 2 - 1) * half, h = heightAt(x, z);
    if (h < 0.3 || inSite(x, z)) continue;
    const slope = Math.abs(heightAt(x + 2, z) - h) + Math.abs(heightAt(x, z + 2) - h);
    if (rnd() > 0.15 + slope * 0.4) continue;
    rocks.push([x, h, z, 0.5 + rnd() * rnd() * 3.2, rnd() * 6.28]);
  }
  const gn = groundNormals(), ns = new THREE.Vector2(1.6, 1.6);
  const barkC = new THREE.MeshStandardMaterial({ color: 0x5a4330, roughness: 1, normalMap: gn(4, 10), normalScale: ns });
  const barkB = new THREE.MeshStandardMaterial({ color: 0x8a7d6a, roughness: 1, normalMap: gn(4, 10), normalScale: ns });
  const leafC = sway(new THREE.MeshStandardMaterial({ map: branchTex(), alphaTest: 0.32, side: THREE.DoubleSide, roughness: 0.85 }));
  const leafB = sway(new THREE.MeshStandardMaterial({ map: leafTex(), alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.8 }));
  const limbs = [0, 1, 2].map(k => new THREE.CylinderGeometry(0.04, 0.13, 3, 5).translate(0, 1.5, 0).rotateZ(0.75).rotateY(k * 2.1).translate(0, 4.4 + k * 0.4, 0));
  const conif = trees.filter(t => t[5] === 0), broad = trees.filter(t => t[5] === 1), acac = trees.filter(t => t[5] === 2), euc = trees.filter(t => t[5] === 3), lob = trees.filter(t => t[5] === 4), eup = trees.filter(t => t[5] === 5);
  const mk = (g, m, n) => { const im = new THREE.InstancedMesh(g, m, Math.max(1, n)); im.count = n; im.castShadow = im.receiveShadow = true; scene.add(im); return im; };
  const mC = [mk(trunkGeo(17, 0.4, 0.08, 0.4), barkC, conif.length), mk(branchGeo(), leafC, conif.length)];
  const mB = [mk(mergeG([trunkGeo(5.2, 0.34, 0.12, 0.3), ...limbs]), barkB, broad.length), mk(canopyGeo(), leafB, broad.length)];
  const barkA = new THREE.MeshStandardMaterial({ color: 0x4a3a2a, roughness: 1, normalMap: gn(4, 10), normalScale: ns });
  const barkE = new THREE.MeshStandardMaterial({ color: 0xcfc4ac, roughness: 1, normalMap: gn(4, 10), normalScale: ns });
  const leafA = sway(new THREE.MeshStandardMaterial({ map: leafTex(), alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.8 }));
  const plantM = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.85, flatShading: true });
  const mA = [mk(trunkGeo(5, 0.3, 0.12, 0.9), barkA, acac.length), mk(acaciaGeo(), leafA, acac.length)];
  const mE = [mk(trunkGeo(15, 0.3, 0.1, 0.4), barkE, euc.length), mk(eucGeo(), leafA, euc.length)];
  const mL = [mk(lobeliaGeo(), plantM, lob.length)], mU = [mk(euphGeo(), plantM, eup.length)];
  const M = new THREE.Matrix4(), Q = new THREE.Quaternion(), S = new THREE.Vector3(), P = new THREE.Vector3(), Y = new THREE.Vector3(0, 1, 0), col = new THREE.Color(), E = new THREE.Euler();
  const place = (list, ms, hue) => list.forEach((t, i) => {
    E.set((rnd() - 0.5) * 0.07, t[4], (rnd() - 0.5) * 0.07, 'YXZ'); Q.setFromEuler(E); S.set(t[3], t[3] * (0.9 + rnd() * 0.3), t[3]); P.set(t[0], t[1] - 0.2, t[2]);
    M.compose(P, Q, S); ms.forEach(m => m.setMatrixAt(i, M)); hue(t); (ms[1] || ms[0]).setColorAt(i, col); addCollider(t[0], t[2], 0.45 * t[3]);
  });
  place(conif, mC, t => { col.setHSL(0.3 + rnd() * 0.05, 0.3 + rnd() * 0.12, 0.5 + rnd() * 0.18); });   // dark highland juniper / podocarpus
  place(acac, mA, t => col.setHSL(0.17 + rnd() * 0.07, 0.4 + rnd() * 0.2, 0.72 + rnd() * 0.2));      // flat-topped acacia
  place(euc, mE, t => col.setHSL(0.3 + rnd() * 0.05, 0.22 + rnd() * 0.1, 0.62 + rnd() * 0.18));      // eucalyptus groves
  place(lob, mL, t => col.setHSL(0.24 + rnd() * 0.05, 0.22, 0.45 + rnd() * 0.2));                    // giant lobelia
  place(eup, mU, t => col.setHSL(0.3, 0.45, 0.32 + rnd() * 0.15));                                   // candelabra euphorbia
  place(broad, mB, t => { col.setHSL(rnd() < 0.12 ? 0.1 + rnd() * 0.04 : 0.2 + rnd() * 0.1, 0.35 + rnd() * 0.2, 0.6 + rnd() * 0.25); });
  regCull(conif, mC); regCull(acac, mA); regCull(euc, mE); regCull(lob, mL); regCull(eup, mU); regCull(broad, mB);
  const rg = new THREE.IcosahedronGeometry(1, 1), rp = rg.attributes.position;
  for (let i = 0; i < rp.count; i++) {
    const k = 0.78 + h2(Math.round(rp.getX(i) * 50), Math.round(rp.getZ(i) * 50) + Math.round(rp.getY(i) * 50)) * 0.5;
    rp.setXYZ(i, rp.getX(i) * k, rp.getY(i) * k * 0.75, rp.getZ(i) * k);
  }
  rg.computeVertexNormals();
  const rm = new THREE.InstancedMesh(rg, new THREE.MeshStandardMaterial({ color: 0x8a8782, roughness: 0.92, flatShading: false, normalMap: gn(2, 2), normalScale: new THREE.Vector2(1.8, 1.8) }), rocks.length);
  rm.castShadow = rm.receiveShadow = true; scene.add(rm);
  rocks.forEach((r, i) => {
    Q.setFromAxisAngle(Y, r[4]); S.set(r[3] * (1 + rnd() * .5), r[3] * (0.6 + rnd() * .5), r[3] * (1 + rnd() * .5)); P.set(r[0], r[1] + r[3] * 0.2, r[2]);
    M.compose(P, Q, S); rm.setMatrixAt(i, M);
    col.setHSL(0.08, 0.05, 0.38 + rnd() * 0.25); rm.setColorAt(i, col);
    addCollider(r[0], r[2], r[3] * 0.9);
  });
  regCull(rocks, [rm]);
  const bgm = new THREE.IcosahedronGeometry(1, 1), bp = bgm.attributes.position;
  for (let i = 0; i < bp.count; i++) { const k = 0.75 + h2(i * 3, 7) * 0.5; bp.setXYZ(i, bp.getX(i) * k, bp.getY(i) * k * 0.7, bp.getZ(i) * k); }
  bgm.computeVertexNormals();
  const bush = [];
  for (let tries = 0; bush.length < 3500 && tries < 28000; tries++) {
    const x = (rnd() * 2 - 1) * half, z = (rnd() * 2 - 1) * half, h = heightAt(x, z);
    if (h < 1.8 || ALT(h) > 4200 || inSite(x, z) || coldAt(x, z) > 0.55 || rnd() > 0.25 + dryAt(x, z) * 0.75) continue;
    if (Math.abs(heightAt(x + 2, z) - h) > 1.5) continue;
    bush.push([x, h, z, 0.5 + rnd() * 0.9]);
  }
  const bm = new THREE.InstancedMesh(bgm, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, flatShading: true }), bush.length);
  bm.castShadow = bm.receiveShadow = true; scene.add(bm);
  bush.forEach((b, i) => {
    Q.setFromAxisAngle(Y, rnd() * 6.28); S.set(b[3] * 1.4, b[3] * (0.7 + rnd() * 0.4), b[3] * 1.4); P.set(b[0], b[1] + b[3] * 0.2, b[2]);
    M.compose(P, Q, S); bm.setMatrixAt(i, M); const dr = dryAt(b[0], b[2]);
    col.setRGB(lerp(.16, .45, dr) + rnd() * .06, lerp(.3, .46, dr) + rnd() * .06, lerp(.1, .3, dr)); bm.setColorAt(i, col);
  });
  regCull(bush, [bm]);
  /* ---- extra ground life: fallen logs, stumps, termite mounds, boulder clusters, shore reeds, pebbles, thorn scrub ---- */
  const pick = (n, test) => { const out = []; for (let t = 0; out.length < n && t < n * 16; t++) { const x = (rnd() * 2 - 1) * half, z = (rnd() * 2 - 1) * half, h = heightAt(x, z); if (h < 0.25 || inSite(x, z)) continue; if (!test(x, z, h, ALT(h))) continue; out.push([x, h, z, rnd()]); } return out; };
  const flat = (x, z, h) => Math.abs(heightAt(x + 2, z) - h) < 1.2 && Math.abs(heightAt(x, z + 2) - h) < 1.2;
  const inst = (geo, mat, list, fn, tint) => {
    const im = new THREE.InstancedMesh(geo, mat, Math.max(1, list.length)); im.count = list.length; im.castShadow = im.receiveShadow = true; scene.add(im);
    list.forEach((t, i) => { fn(t, i); M.compose(P, Q, S); im.setMatrixAt(i, M); if (tint) { tint(t); im.setColorAt(i, col); } }); regCull(list, [im]); return im;
  };
  const gn2 = groundNormals(), nrm = new THREE.Vector2(1.4, 1.4);
  const logL = pick(260, (x, z, h, al) => al > 1700 && al < 3500 && fbm(x * 0.007 + 20, z * 0.007, 3) > 0.45 && flat(x, z, h));
  inst(mergeG([new THREE.CylinderGeometry(0.26, 0.3, 3.4, 9).rotateZ(Math.PI / 2), new THREE.CylinderGeometry(0.06, 0.1, 1.1, 5).rotateZ(1.0).translate(0.5, 0.35, 0.2), new THREE.CylinderGeometry(0.05, 0.09, 0.9, 5).rotateZ(-1.0).translate(-0.7, 0.3, -0.2)]), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, normalMap: gn2(3, 3), normalScale: nrm }), logL,
    t => { E.set(0, t[3] * 6.28, (rnd() - .5) * 0.1, 'YXZ'); Q.setFromEuler(E); const s = 0.8 + rnd() * 0.9; S.set(s, s, s); P.set(t[0], t[1] + 0.2, t[2]); }, t => col.setHSL(0.07 + rnd() * 0.03, 0.25, 0.22 + rnd() * 0.15));
  const stumpL = pick(300, (x, z, h, al) => al > 1500 && al < 3400 && fbm(x * 0.007 + 20, z * 0.007, 3) > 0.42);
  inst(mergeG([new THREE.CylinderGeometry(0.34, 0.5, 0.55, 10), new THREE.CylinderGeometry(0.3, 0.3, 0.02, 10).translate(0, 0.28, 0)]), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, normalMap: gn2(2, 2), normalScale: nrm }), stumpL,
    t => { Q.setFromAxisAngle(Y, t[3] * 6.28); const s = 0.6 + rnd() * 0.9; S.set(s, s * (0.7 + rnd() * 0.8), s); P.set(t[0], t[1] + 0.15, t[2]); }, t => col.setHSL(0.08, 0.3, 0.25 + rnd() * 0.15));
  const termL = pick(150, (x, z, h, al) => al > 900 && al < 2100 && flat(x, z, h));
  const tg2 = new THREE.CylinderGeometry(0.12, 0.8, 2.6, 10, 5); { const tp2 = tg2.attributes.position; for (let i = 0; i < tp2.count; i++) { const k = 1 + (h2(Math.round(tp2.getX(i) * 20), Math.round(tp2.getY(i) * 10)) - 0.5) * 0.45; tp2.setX(i, tp2.getX(i) * k); tp2.setZ(i, tp2.getZ(i) * k); } tg2.computeVertexNormals(); }
  inst(tg2, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, normalMap: gn2(2, 2), normalScale: nrm }), termL, t => { Q.setFromAxisAngle(Y, t[3] * 6.28); const s = 0.5 + rnd() * 1.1; S.set(s, s, s); P.set(t[0], t[1] + 1.1 * s, t[2]); addCollider(t[0], t[2], 0.6 * s); }, t => col.setHSL(0.045 + rnd() * 0.02, 0.5, 0.33 + rnd() * 0.1));
  const bcg = (() => { const l = []; for (const [x, y, z, r] of [[0, 0.5, 0, 1.2], [1.5, 0.3, 0.4, 0.8], [-1.2, 0.35, 0.8, 0.9], [0.4, 0.25, -1.3, 0.7], [-0.5, 1.1, 0.1, 0.65]]) { const g = new THREE.IcosahedronGeometry(1, 1), p2 = g.attributes.position; for (let i = 0; i < p2.count; i++) { const k = r * (0.8 + h2(Math.round(p2.getX(i) * 40) + Math.round(x * 9), Math.round(p2.getZ(i) * 40 + p2.getY(i) * 40)) * 0.4); p2.setXYZ(i, x + p2.getX(i) * k, y + p2.getY(i) * k * 0.8, z + p2.getZ(i) * k); } l.push(g); } const m = mergeG(l); m.computeVertexNormals(); return m; })();
  const bldL = pick(110, (x, z, h) => Math.abs(heightAt(x + 3, z) - h) + Math.abs(heightAt(x, z + 3) - h) > 0.8 || fbm(x * 0.01 + 5, z * 0.01, 3) > 0.7);
  inst(bcg, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95, normalMap: gn2(3, 3), normalScale: new THREE.Vector2(1.8, 1.8) }), bldL, t => { Q.setFromAxisAngle(Y, t[3] * 6.28); const s = 0.9 + rnd() * 1.8; S.set(s, s * 0.8, s); P.set(t[0], t[1] + 0.1, t[2]); for (const [dx, dz, rr] of [[0, 0, 1.5], [1.5, 0.4, 1], [-1.2, 0.8, 1.1]]) addCollider(t[0] + dx * s, t[2] + dz * s, rr * s * 0.8); }, t => col.setHSL(0.07, 0.07, 0.34 + rnd() * 0.22));
  const reedG = mergeG([0, 1, 2, 3, 4, 5, 6].map(k => new THREE.ConeGeometry(0.035, 1.5 + (k % 3) * 0.4, 4).translate(0, 0.75 + (k % 3) * 0.2, 0).rotateZ((k % 3 - 1) * 0.18).rotateY(k * 0.9).translate(Math.cos(k * 2) * 0.25, 0, Math.sin(k * 2) * 0.25)));
  const reedL = pick(900, (x, z, h) => h > 0.3 && h < 1.5);
  inst(reedG, sway(new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, side: THREE.DoubleSide })), reedL, t => { Q.setFromAxisAngle(Y, t[3] * 6.28); const s = 0.8 + rnd() * 0.9; S.set(s, s, s); P.set(t[0], t[1] - 0.05, t[2]); }, t => col.setHSL(0.2 + rnd() * 0.06, 0.4, 0.28 + rnd() * 0.12));
  const pebG = new THREE.IcosahedronGeometry(1, 0), pebL = pick(1800, (x, z, h, al) => al < 2400 || Math.abs(heightAt(x + 2, z) - h) > 0.6);
  inst(pebG, new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.95, flatShading: true }), pebL, t => { Q.setFromAxisAngle(Y, t[3] * 6.28); const s = 0.06 + rnd() * 0.16; S.set(s * 1.4, s * 0.7, s); P.set(t[0], t[1] + 0.02, t[2]); }, t => col.setHSL(0.08, 0.1 + rnd() * 0.1, 0.35 + rnd() * 0.3));
  const thornL = pick(420, (x, z, h, al) => al > 800 && al < 1900 && dryAt(x, z) > 0.35);   // low acacia scrub, thorn-green
  inst(mergeG([blobG(0, 0.55, 0, 1.0, 0.5, 1.0, 11), blobG(0.7, 0.4, 0.3, 0.6, 0.35, 0.6, 12), blobG(-0.6, 0.45, -0.4, 0.65, 0.4, 0.6, 13)]), sway(new THREE.MeshStandardMaterial({ color: 0xffffff, map: leafTex(), alphaTest: 0.4, side: THREE.DoubleSide, roughness: 0.9 })), thornL, t => { Q.setFromAxisAngle(Y, t[3] * 6.28); const s = 0.7 + rnd() * 1.2; S.set(s, s, s); P.set(t[0], t[1], t[2]); }, t => col.setHSL(0.17 + rnd() * 0.06, 0.38, 0.55 + rnd() * 0.2));
}

/* ---------- audio (procedural) ---------- */
let AC, noiseBuf, windGain;
function startAudio() {
  if (AC) return;
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    { const real = AC.destination, mg = AC.createGain(); mg.gain.value = HRS.mute ? 0 : HRS.vol; mg.connect(real); Object.defineProperty(AC, 'destination', { get: () => mg }); window.HR_MASTER = mg; }
    noiseBuf = AC.createBuffer(1, AC.sampleRate * 2, AC.sampleRate);
    const d = noiseBuf.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const s = AC.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = AC.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 380; f.Q.value = 0.4;
    windGain = AC.createGain(); windGain.gain.value = 0.04;
    s.connect(f).connect(windGain).connect(AC.destination); s.start();
    const mk = (type, fr, q) => { const b = AC.createBufferSource(); b.buffer = noiseBuf; b.loop = true; const fl = AC.createBiquadFilter(); fl.type = type; fl.frequency.value = fr; fl.Q.value = q; const gn = AC.createGain(); gn.gain.value = 0; b.connect(fl).connect(gn).connect(AC.destination); b.start(); return gn; };
    rainGain = mk('highpass', 2500, 0.5); waterGain = mk('lowpass', 700, 0.6);
  } catch (e) { AC = null; }
}
function step(kind, vol) {
  if (!AC) return;
  const s = AC.createBufferSource(); s.buffer = noiseBuf;
  const f = AC.createBiquadFilter(), g = AC.createGain(), t = AC.currentTime;
  const cfg = { grass: ['bandpass', 500, 0.11], sand: ['bandpass', 1500, 0.09], rock: ['highpass', 1800, 0.06], water: ['lowpass', 900, 0.3] }[kind];
  f.type = cfg[0]; f.frequency.value = cfg[1] * (0.85 + Math.random() * 0.3); f.Q.value = 0.8;
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + cfg[2]);
  s.connect(f).connect(g).connect(AC.destination); s.start(t, Math.random() * 1.5, cfg[2] + 0.05);
}
function chirp() {
  if (!AC) return;
  const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime, f0 = 2200 + Math.random() * 1800;
  o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f0 * 1.4, t + 0.08);
  g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.025, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.14);
  o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 0.16);
}

/* ---------- player ---------- */
const P = { x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, yaw: 0, pitch: 0, ground: true, stam: 100, crouch: 0, bob: 0, tired: false, swim: false };
const keys = {};
function findSpawn() {
  for (let r = 0; r < 800; r += 6) for (let a = 0; a < 6.28; a += 0.4) {
    const x = Math.cos(a) * r, z = Math.sin(a) * r, h = heightAt(x, z);
    if (h > 3 && h < (REAL ? 1e9 : 8) && Math.abs(heightAt(x + 3, z) - h) < 1.2) return [x, h, z];
  }
  return [0, heightAt(0, 0), 0];
}
function collide() {
  const cx = Math.floor(P.x / CELL), cz = Math.floor(P.z / CELL);
  for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) {
    const l = grid.get((cx + i) + ',' + (cz + j)); if (!l) continue;
    for (const [x, z, r] of l) {
      const dx = P.x - x, dz = P.z - z, rr = r + 0.35, d2 = dx * dx + dz * dz;
      if (d2 < rr * rr && d2 > 1e-6) { const d = Math.sqrt(d2); P.x = x + dx / d * rr; P.z = z + dz / d * rr; }
    }
  }
}
function update(dt, water) {
  const f = (keys.KeyW ? 1 : 0) - (keys.KeyS ? 1 : 0), s = (keys.KeyD ? 1 : 0) - (keys.KeyA ? 1 : 0);
  const sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  let wx = -sy * f + cy * s, wz = -cy * f - sy * s; const len = Math.hypot(wx, wz);
  if (len > 0) { wx /= len; wz /= len; }
  const crouching = keys.KeyC; P.crouch = lerp(P.crouch, crouching ? 1 : 0, Math.min(1, dt * 10));
  const wantRun = keys.ShiftLeft && len > 0 && !crouching && !P.tired && P.stam > 0;
  P.swim = heightAt(P.x, P.z) < C.waterLevel - 0.5;
  let speed = wantRun ? C.sprint : crouching ? C.crouch : C.walk;
  if (P.swim) speed *= 0.55;
  if (wantRun) P.stam = Math.max(0, P.stam - 18 * dt); else P.stam = Math.min(100, P.stam + (len > 0 ? 10 : 20) * dt);
  if (P.stam <= 0) P.tired = true; if (P.tired && P.stam > 25) P.tired = false;
  const acc = P.ground ? 11 : 1.5, k = Math.min(1, acc * dt);
  P.vx = lerp(P.vx, wx * speed, k); P.vz = lerp(P.vz, wz * speed, k);
  const gy = Math.max(heightAt(P.x, P.z), C.waterLevel - 1.35);
  for (const ax of ['x', 'z']) {                       // per-axis move so you slide along steep slopes
    const nx = P.x + (ax === 'x' ? P['v' + ax] * dt : 0), nz = P.z + (ax === 'z' ? P['v' + ax] * dt : 0);
    const rise = heightAt(nx, nz) - heightAt(P.x, P.z), run = Math.abs(P['v' + ax] * dt) + 1e-6;
    if (P.ground && rise / run > 1.35) { P['v' + ax] *= 0.2; continue; }
    P.x = nx; P.z = nz;
  }
  collide(); collideBoxes();
  P.x = clamp(P.x, -C.size / 2 + 5, C.size / 2 - 5); P.z = clamp(P.z, -C.size / 2 + 5, C.size / 2 - 5);
  const g2 = Math.max(heightAt(P.x, P.z), C.waterLevel - 1.35);
  if (P.ground && keys.Space && !P.swim) { P.vy = C.jump; P.ground = false; }
  P.vy -= C.gravity * dt; P.y += P.vy * dt;
  if (P.y <= g2) { if (!P.ground && P.vy < -9) { step('rock', 0.3); hurtFall(P.vy); } P.y = g2; P.vy = 0; P.ground = true; }
  else if (P.ground && P.y - g2 < 0.6 && P.vy <= 0) { P.y = g2; P.vy = 0; } else P.ground = false;
  // head bob + footsteps
  const mv = Math.hypot(P.vx, P.vz);
  if (P.ground && mv > 0.5) {
    const before = Math.floor(P.bob / Math.PI);
    P.bob += mv * dt * 1.35;
    if (Math.floor(P.bob / Math.PI) !== before) {
      const h = heightAt(P.x, P.z), up = Math.abs(heightAt(P.x + 1, P.z) - h);
      step(P.swim || h < C.waterLevel + 0.2 ? 'water' : h < 2.6 ? 'sand' : (up > 0.7 || h > 38) ? 'rock' : 'grass', 0.1 + mv * 0.02 * (crouching ? 0.4 : 1));
    }
  }
}

/* ---------- day / night ---------- */
const COL = { day: new THREE.Color(0x6aa6e6), dusk: new THREE.Color(0xe39a55), night: new THREE.Color(0x03060e) };
const sky = new THREE.Color(), tmp = new THREE.Color();
const ZU = new THREE.Color(0x2b2f6b), ZY = new THREE.Color(0x1f58bd), ZN = new THREE.Color(0x01030a);
let tod = C.startHour / 24, fast = false;
function lighting(dt) {
  tod = (tod + dt * (fast ? 20 : 1) / C.dayLength) % 1;
  const a = (tod - 0.25) * Math.PI * 2, dir = SUNDIR.set(Math.cos(a) * 0.9, Math.sin(a), 0.35).normalize();
  const el = dir.y, dayF = sm(0.02, 0.4, el), nightF = sm(0.03, -0.18, el);
  tmp.copy(COL.dusk).lerp(COL.day, dayF); sky.copy(tmp).lerp(COL.night, nightF); sky.lerp(DUSTC, HAZE.v * 0.3 * dayF);
  SU.uHor.value.copy(sky); SU.uZen.value.copy(ZU).lerp(ZY, dayF).lerp(ZN, nightF); scene.fog.color.copy(sky);
  SU.uNight.value = nightF; SU.uDay.value = dayF;
  scene.fog.density = 0.0011 + nightF * 0.0006 + (1 - dayF) * 0.0004 + HAZE.v * 0.0005;
  sun.intensity = 2.4 * sm(-0.04, 0.22, el);
  sun.color.setRGB(1, lerp(0.62, 0.95, dayF), lerp(0.4, 0.85, dayF));
  hemi.intensity = 0.12 + 0.75 * dayF + 0.06 * (1 - nightF);
  hemi.color.copy(sky).lerp(WHITEC, 0.35);
  renderer.toneMappingExposure = 0.85 + dayF * 0.25;
  const cp = camera.position;
  sun.target.position.set(P.x, P.y, P.z);
  const sd = el > -0.05 ? dir : SDV.copy(dir).negate();            // moonlight uses the opposite side of the sky
  sun.position.set(P.x + sd.x * 150, P.y + sd.y * 150, P.z + sd.z * 150);
  if (el <= -0.05) { sun.intensity = 0.28 * nightF; sun.color.set(0x8aa4ff); }
  skyDome.position.copy(cp); SU.uSun.value.copy(dir); SU.uSunCol.value.set(1, lerp(.6, .95, dayF), lerp(.35, .85, dayF));
  stars.position.copy(cp); stars.material.opacity = nightF;
  const hh = Math.floor(tod * 24), mm = Math.floor((tod * 24 - hh) * 60);
  $('clock').textContent = String(hh).padStart(2, '0') + ':' + String(mm).padStart(2, '0') + '   ET ' + String(((hh + 6) % 12) || 12) + ':' + String(mm).padStart(2, '0');
  return dayF;
}

/* ---------- input ---------- */
const HRS = Object.assign({ sens: 1, fov: C.fov || 70, vol: 1, invert: false, mute: false },
  (() => { try { return JSON.parse(localStorage.getItem('highland-reach-settings') || '{}') || {}; } catch (e) { return {}; } })());
C.fov = HRS.fov;
let locked = false, softLock = false;
function applyLock(v) {
  locked = v; $('start').hidden = v; $('hud').hidden = !v; document.body.classList.toggle('playing', v);
  if (!v) { $('go').textContent = 'Resume'; for (const k in keys) keys[k] = false; setMap(false); }
}
function lookBy(mx, my) {
  if (!locked) return;
  if (mapOpen) { MV.yaw -= mx * 0.005; MV.pitch = clamp(MV.pitch + my * 0.004, 0.14, 1.5); return; }
  const k = SENS * HRS.sens * (FXS.zoom ? 0.3 : 1);
  P.yaw -= mx * k; P.pitch = clamp(P.pitch - my * k * (HRS.invert ? -1 : 1), -1.5, 1.5);
}
addEventListener('keydown', e => {
  keys[e.code] = true;
  // Prevent browser scrolling while playing, and avoid repeated toggles when a key is held.
  if (['Space', 'ShiftLeft', 'ShiftRight', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  if (e.repeat) return;
  if (e.code === 'KeyF') torch.intensity = torch.intensity ? 0 : 6;
  if (e.code === 'KeyT') fast = !fast;
  if (e.code === 'KeyR') { rainTarget = rainTarget ? 0 : 1; rainTimer = 90; toast(rainTarget ? 'Rain incoming' : 'Skies clearing'); }
  if (e.code === 'KeyN' && P.won) { save = { best: save.best, qual: save.qual, layer: save.layer, pins: save.pins, trail: save.trail }; store(); location.reload(); }
});
addEventListener('keyup', e => keys[e.code] = false);
addEventListener('mousemove', e => lookBy(e.movementX || 0, e.movementY || 0));
document.addEventListener('pointerlockchange', () => { if (softLock && !document.pointerLockElement) return; applyLock(document.pointerLockElement === canvas); });
function resize() { renderer.setSize(innerWidth, innerHeight, false); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); }
addEventListener('resize', resize); resize();

/* ---------- grass & flowers ---------- */
function makeGrass() {
  const tex = d => { const c = document.createElement('canvas'); c.width = c.height = 128; d(c.getContext('2d')); const t = new THREE.CanvasTexture(c); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4; return t; };
  const gt = tex(g => { for (let i = 0; i < 11; i++) {
    const bx = 10 + i * 10.5 + Math.random() * 6, tip = bx + (Math.random() - .5) * 34, hh = 60 + Math.random() * 64;
    const gr = g.createLinearGradient(0, 128, 0, 128 - hh); gr.addColorStop(0, '#1f3a0e'); gr.addColorStop(1, '#b5d060'); g.fillStyle = gr;
    g.beginPath(); g.moveTo(bx - 3.5, 128); g.quadraticCurveTo(bx + (tip - bx) * .2, 128 - hh * .6, tip, 128 - hh); g.quadraticCurveTo(bx + (tip - bx) * .6 + 2, 128 - hh * .5, bx + 3.5, 128); g.fill(); } });
  const ft = tex(g => { g.fillStyle = '#fff'; for (let i = 0; i < 6; i++) { g.save(); g.translate(64, 50); g.rotate(i * 1.047); g.beginPath(); g.ellipse(0, -17, 9, 17, 0, 0, 6.3); g.fill(); g.restore(); } g.fillStyle = '#9a9a7a'; g.beginPath(); g.arc(64, 50, 7, 0, 6.3); g.fill(); });
  const star = (w, h, n, y0) => {
    const P = [], U = [], I = [];
    for (let k = 0; k < n; k++) { const g = new THREE.PlaneGeometry(w, h).rotateY(k * Math.PI / n).translate(0, y0 + h / 2, 0), o = P.length / 3;
      P.push(...g.attributes.position.array); U.push(...g.attributes.uv.array); I.push(...Array.from(g.index.array, v => v + o)); }
    const m = new THREE.BufferGeometry();
    m.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); m.setAttribute('uv', new THREE.Float32BufferAttribute(U, 2));
    m.setAttribute('normal', new THREE.Float32BufferAttribute(P.map((_, i) => i % 3 === 1 ? 1 : 0), 3)); m.setIndex(I); return m;
  };
  const gT = { value: 0 };
  const gm = new THREE.MeshStandardMaterial({ map: gt, alphaTest: 0.45, side: THREE.DoubleSide, roughness: 1 });
  gm.onBeforeCompile = sh => {
    sh.uniforms.uT = gT;
    sh.vertexShader = 'uniform float uT;\n' + sh.vertexShader.replace('#include <begin_vertex>',
      'vec3 transformed=vec3(position); float sw=sin(uT*1.7+instanceMatrix[3].x*.7+instanceMatrix[3].z*.5)*.13*position.y; transformed.x+=sw; transformed.z+=sw*.6;');
  };
  const NG = 26000, NF = 2500;
  const gMesh = new THREE.InstancedMesh(star(1.25, 0.95, 3, 0), gm, NG);
  const fMesh = new THREE.InstancedMesh(star(0.4, 0.4, 2, 0.28), new THREE.MeshStandardMaterial({ map: ft, alphaTest: 0.5, side: THREE.DoubleSide, roughness: 0.8 }), NF);
  for (const m of [gMesh, fMesh]) { m.frustumCulled = false; m.setColorAt(0, new THREE.Color(1, 1, 1)); scene.add(m); }
  const M = new THREE.Matrix4(), Q = new THREE.Quaternion(), S = new THREE.Vector3(), Pp = new THREE.Vector3(), Y = new THREE.Vector3(0, 1, 0), col = new THREE.Color();
  const FC = [[1.25, 1, .1], [1.1, 1.1, 1.1], [.85, .4, 1.15], [1.2, .5, .3]];
  let lx = 1e9, lz = 1e9, job = null;
  const tG = new Float32Array(NG * 16), tGc = new Float32Array(NG * 3), tF = new Float32Array(NF * 16), tFc = new Float32Array(NF * 3);
  function* gen(px, pz) {            // builds the grass around the player a little each frame (never a big hitch)
    const R = GQ.R, cs = GQ.cs; let n = 0, m = 0;
    for (let i = Math.floor((px - R) / cs); i < (px + R) / cs; i++) {
      for (let j = Math.floor((pz - R) / cs); j < (pz + R) / cs; j++) {
        const x = (i + h2(i, j * 7 + 1)) * cs, z = (j + h2(i * 5 + 3, j)) * cs, d2 = ((x - px) ** 2 + (z - pz) ** 2) / (R * R);
        if (d2 > 1 || n >= NG) continue;
        const r = h2(i + 91, j + 17); if (r < d2 * d2 * 0.8) continue;
        const y = heightAt(x, z); if (y < 1.5 || y > 36 || Math.abs(heightAt(x + 1, z) - y) > 0.8) continue;
        if (site && Math.hypot(x - site[0], z - site[1]) < 46) continue;
        if (coldAt(x, z) > 0.55) continue;
        const patch = fbm(x * 0.03, z * 0.03, 2), dry = Math.max(sm(0.62, 0.8, fbm(x * 0.012 + 70, z * 0.012, 2)), dryAt(x, z));
        Q.setFromAxisAngle(Y, r * 6.28); const sc = (0.65 + h2(j, i) * 0.9) * (0.55 + patch);
        S.set(sc, sc * (0.8 + r * 0.6), sc); Pp.set(x, y - 0.04, z); M.compose(Pp, Q, S); M.toArray(tG, n * 16);
        col.setRGB(lerp(.75, 1.3, dry) + r * .3, lerp(.9, 1.05, dry) + r * .25, lerp(.6, .55, dry) + r * .2); col.toArray(tGc, n * 3); n++;
        if (m < NF && patch > 0.52 && h2(i * 13, j * 17) > 0.9) {
          const fc = FC[Math.floor(h2(i, j) * 4) % 4], fs = 0.8 + r * 0.7; S.set(fs, fs, fs); Pp.y = y; M.compose(Pp, Q, S);
          M.toArray(tF, m * 16); col.setRGB(fc[0], fc[1], fc[2]); col.toArray(tFc, m * 3); m++;
        }
      }
      yield;
    }
    return [n, m];
  }
  return (px, pz, t) => {
    gT.value = t;
    if (!job && (GQ.dirty || Math.hypot(px - lx, pz - lz) > GQ.R * 0.22)) { lx = px; lz = pz; GQ.dirty = false; job = gen(px, pz); }
    if (job) {
      const t0 = performance.now(); let r;
      do { r = job.next(); } while (!r.done && performance.now() - t0 < 2.5);
      if (r.done) {
        const [n, m] = r.value; job = null;
        gMesh.instanceMatrix.array.set(tG.subarray(0, n * 16)); gMesh.instanceColor.array.set(tGc.subarray(0, n * 3));
        fMesh.instanceMatrix.array.set(tF.subarray(0, m * 16)); fMesh.instanceColor.array.set(tFc.subarray(0, m * 3));
        gMesh.count = n; fMesh.count = m;
        for (const k of [gMesh, fMesh]) { k.instanceMatrix.needsUpdate = true; k.instanceColor.needsUpdate = true; }
      }
    }
  };
}

/* ---------- village ---------- */
function findSite() {
  if (REAL && typeof HS !== 'undefined') for (const h of HS) { const [hx, hz] = xzOf(h[1], h[2]); if (Math.hypot(hx, hz) < 1800) return null; }
  for (let r = 80; r < 800; r += 40) for (let a = 0; a < 6.28; a += 0.45) {
    const x = Math.cos(a) * r, z = Math.sin(a) * r; let lo = 1e9, hi = -1e9;
    for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) { const h = heightAt(x + i * 14, z + j * 14); lo = Math.min(lo, h); hi = Math.max(hi, h); }
    if (lo > 3.5 && hi < (REAL ? 1e9 : 16) && hi - lo < (REAL ? 6 : 4) && coldAt(x, z) < 0.4) return [x, z, 62, heightAt(x, z)];
  }
  return null;
}
const VCUR = { get: null };
addEventListener('keydown', e => { if (e.code === 'KeyE' && locked && !mapOpen && VCUR.get) { const c = VCUR.get(); if (c) c.act(); } });
let ETH_inside = null;
/* Regional architecture: each part of Ethiopia builds differently */
const _T = [0x8d9296, 0x9aa0a4, 0x7e8488], _TH = [0xc9a050, 0xb88a3c, 0xc4a255];
const STY = {
  amhara: { wall: [0xb98a58, 0xa87a4c, 0xc99d6b, 0x9c7048], roof: [0xc9a050, 0x8d9296, 0xb88a3c], H: 3, Hr: 1, rect: 3, church: 'round', hut: { n: 9, wh: 2.3, rr: 4.3, rh: 3.2, rc: 0xc9a050 } },
  tigray: { wall: [0x9a8b78, 0x8b7d68, 0xa89a84, 0x7f7260], roof: [0x7a6d5a, 0x6f6352, 0x857862], flat: 1, stone: 1, H: 3.4, Hr: 0.8, rect: 4, church: 'stone', hut: { n: 0 } },
  harar: { wall: [0xf2ede0, 0x6fa8c8, 0xd98fa8, 0x8fc48a], roof: [0xe8e0d0, 0xdcd3c0, 0xe8e0d0], flat: 1, H: 3.4, Hr: 0.8, rect: 4, church: 'mosque', hut: { n: 0 } },
  shewa: { wall: [0xb9a07a, 0xa8957a, 0xc7b08a, 0x8f7f66], roof: _T, H: 3, Hr: 1, rect: 4, church: 'round', hut: { n: 5, wh: 2.3, rr: 4.3, rh: 3.2, rc: 0xb9a15a } },
  oromo: { wall: [0xa07850, 0x94704a, 0xb08a60, 0x8a6a48], roof: _TH, H: 3, Hr: 0.8, rect: 2, church: 'round', hut: { n: 10, wh: 2.2, rr: 4.4, rh: 5, rc: 0xbfa24c } },
  dorze: { wall: [0xb09a60], roof: _TH, H: 3, Hr: 1, rect: 0, church: 'none', hut: { n: 12, wh: 1.1, rr: 3.5, rh: 6.2, rc: 0xb59a50, wc: 0xa68c4e } },
  konso: { wall: [0x7a7468, 0x6f695e, 0x857e70, 0x756e62], roof: _TH, stone: 1, H: 3, Hr: 1, rect: 0, church: 'none', hut: { n: 14, wh: 2.2, rr: 4.4, rh: 3.8, rc: 0xb8974a, wc: 0x7a7468 } },
  afar: { wall: [0xb9a77c], roof: _TH, H: 3, Hr: 1, rect: 0, church: 'none', hut: { n: 14, wh: 0.9, rr: 3.5, rh: 2.4, rc: 0xb9a77c, dome: 1 } },
  somali: { wall: [0xd8c9a4, 0xc9b88e, 0xe0d4b4, 0xbfae84], roof: _T, flat: 1, H: 3, Hr: 0.8, rect: 2, church: 'mosque', hut: { n: 8, wh: 0.9, rr: 3.5, rh: 2.4, rc: 0xb09a6a, dome: 1 } },
  omo: { wall: [0x8a6a48], roof: _TH, H: 3, Hr: 1, rect: 0, church: 'none', hut: { n: 14, wh: 1.8, rr: 3.9, rh: 2.8, rc: 0xa8884a, wc: 0x8a6a48 } },
  city: { wall: [0xc8c2b4, 0xb4aea0, 0xd2ccbe, 0xa8a296], roof: _T, flat: 1, H: 8, Hr: 6, rect: 4, church: 'round', towers: 1, hut: { n: 0 } }
};
function villageStyle(cx, cz) {
  if (!REAL) return STY.amhara;
  const [la, lo] = llOf(cx, cz), al = altAt(cx, cz);
  if (la > 8.93 && la < 9.12 && lo > 38.62 && lo < 38.92) return STY.city;
  if (la > 10 && lo > 39.3 && al < 900) return STY.afar;
  if (lo > 41.2) return al >= 1300 ? STY.harar : STY.somali;
  if (la > 12.8 && lo > 37.4) return STY.tigray;
  if (la < 5.8 && lo > 36.9 && lo < 37.9) return STY.konso;
  if (la < 6.6 && lo > 37.2 && lo < 37.9 && al > 1700) return STY.dorze;
  if (la < 7.5 && lo < 37.1 && al < 1400) return STY.omo;
  if (la < 10 && lo < 37.6) return STY.oromo;
  if (la > 7.5 && la < 10.2 && lo > 37.6 && lo < 40) return STY.shewa;
  return STY.amhara;
}
function buildVillage() {
  HIT.length = 0;
  if (!site) return;
  const [cx, cz] = site, mats = {}, VS = villageStyle(cx, cz);
  const mat = c => mats[c] || (mats[c] = new THREE.MeshStandardMaterial({ color: SCol(c), roughness: 0.9 }));
  const mesh = (g, c, x, y, z, p) => { const m = new THREE.Mesh(g, mat(c)); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; p.add(m); return m; };
  const wallC = VS.wall, roofC = VS.roof;
  const glass = new THREE.MeshStandardMaterial({ color: 0x2c3a44, emissive: 0xffb060, emissiveIntensity: 0, roughness: 0.2 }), glow = new THREE.MeshBasicMaterial({ color: 0xff8a2a });
  const THATCH = new Set([0xc9a050, 0xb88a3c, 0xc4a255, 0xb9a15a, 0xbfa24c, 0xb59a50, 0xb8974a, 0xb9a77c, 0xb09a6a, 0xa8884a]), TINS = new Set(_T);
  const rm = {}, rmat = c => rm[c] || (rm[c] = (() => {
    const k = TINS.has(c) ? 'tin' : THATCH.has(c) ? 'thatch' : 'plaster', tx = surfTex(k).clone(); tx.needsUpdate = true; tx.repeat.set(k === 'tin' ? 14 : 5, k === 'tin' ? 1 : 3);
    return new THREE.MeshStandardMaterial({ color: SCol(c), roughness: k === 'tin' ? 0.55 : 0.95, metalness: k === 'tin' ? 0.45 : 0, map: tx, side: THREE.DoubleSide });
  })());
  const wc2 = document.createElement('canvas'); wc2.width = wc2.height = 128; const wg = wc2.getContext('2d'); wg.fillStyle = '#c9b8a0'; wg.fillRect(0, 0, 128, 128);
  for (let k = 0; k < 90; k++) { wg.strokeStyle = 'rgba(' + (60 + Math.random() * 60 | 0) + ',40,20,' + (0.08 + Math.random() * 0.18) + ')'; wg.lineWidth = 0.6 + Math.random() * 1.6; wg.beginPath(); const x0 = Math.random() * 128; wg.moveTo(x0, 0); wg.bezierCurveTo(x0 + 6, 40, x0 - 6, 90, x0 + 2, 128); wg.stroke(); }
  const woodTex = new THREE.CanvasTexture(wc2); woodTex.encoding = THREE.sRGBEncoding; woodTex.wrapS = woodTex.wrapT = THREE.RepeatWrapping;
  for (const c of [0x6b4f33, 0x4a3320, 0x5a3d26, 0x4a3f2c, 0x6a4a2a, 0x7a5a30]) mats[c] = new THREE.MeshStandardMaterial({ color: c, map: woodTex, roughness: 0.75 });
  if (VS.stone) { const sc = document.createElement('canvas'); sc.width = sc.height = 128; const sg = sc.getContext('2d'); sg.fillStyle = '#6a6258'; sg.fillRect(0, 0, 128, 128);
    for (let r = 0; r < 8; r++) for (let q = -1; q < 5; q++) { const l = 200 + Math.random() * 45 | 0; sg.fillStyle = 'rgb(' + l + ',' + (l - 8) + ',' + (l - 22) + ')'; sg.fillRect(q * 32 + (r % 2) * 16 + 1, r * 16 + 1, 30, 14); }
    const st = new THREE.CanvasTexture(sc); st.encoding = THREE.sRGBEncoding; st.wrapS = st.wrapT = THREE.RepeatWrapping; st.repeat.set(3, 1.5); for (const c of wallC) mats[c] = new THREE.MeshStandardMaterial({ color: SCol(c), map: st, roughness: 0.95 }); }
  if (!VS.stone) for (const c of [...wallC, ...(VS.hut && VS.hut.wc ? [VS.hut.wc] : [])]) mats[c] = new THREE.MeshStandardMaterial({ color: SCol(c), map: surfTex('plaster'), roughness: 0.96 });   // mud plaster walls
  const wood = 0x6b4f33, houses = [], chims = [], acts = [], bookC = [0x8a2f2f, 0x2f5a8a, 0x3f7a3f, 0xb89a3a, 0x5a3a7a];
  function house(x, z, yaw, w, d, H, rh, rc, wc) {
    const g = new THREE.Group(); g.position.set(x, heightAt(x, z), z); g.rotation.y = yaw; scene.add(g);
    const c = Math.cos(yaw), s = Math.sin(yaw), W = (lx, lz) => [x + lx * c + lz * s, z - lx * s + lz * c], t = 0.25;
    const bx = (lx, lz, hw, hd, off) => { const p = W(lx, lz); boxes.push({ x: p[0], z: p[1], c, s, hw, hd, R2: (hw + hd + 1) ** 2, off }); };
    const wall = (lx, ly, lz, sw, sh, sd, nc) => { mesh(boxUV(new THREE.BoxGeometry(sw, sh, sd), sw, sh, sd, VS.stone ? 0.33 : 0.4), wc, lx, ly, lz, g); if (!nc) bx(lx, lz, sw / 2, sd / 2); };
    const hh = H + 0.3, cy = (H - 0.3) / 2, fz = d / 2 - t / 2, sw = w / 2 - 0.7;
    wall(0, cy, -d / 2 + t / 2, w, hh, t);
    for (const sx of [-1, 1]) { wall(sx * (w / 2 - t / 2), cy, 0, t, hh, d - 2 * t); wall(sx * (0.7 + sw / 2), cy, fz, sw, hh, t); }
    wall(0, (2.2 + H) / 2, fz, 1.4, H - 2.2, t, true);
    const hinge = new THREE.Group(); hinge.position.set(-0.7, 0, fz); g.add(hinge);
    mesh(new THREE.BoxGeometry(1.4, 2.15, 0.08), 0x4a3320, 0.7, 1.075, 0, hinge); mesh(new THREE.SphereGeometry(0.05, 8, 6), 0xc9a64a, 1.25, 1.05, 0.07, hinge);
    const door = { open: 0, tgt: 0 }; bx(0, fz, 0.7, 0.1, () => door.open > 0.3);
    const dw = W(0, d / 2); acts.push({ x: dw[0], z: dw[1], r: 2.4, door, hinge, label: () => door.tgt ? 'E  close door' : 'E  open door', act: () => { door.tgt = door.tgt ? 0 : 1; creak(); } });
    if (VS.flat) { mesh(new THREE.BoxGeometry(w + 0.5, 0.3, d + 0.5), rc, 0, H + 0.45, 0, g); for (const sx of [-1, 1]) { mesh(new THREE.BoxGeometry(0.25, 0.55, d + 0.5), wc, sx * (w / 2 + 0.12), H + 0.75, 0, g); mesh(new THREE.BoxGeometry(w + 0.5, 0.55, 0.25), wc, 0, H + 0.75, sx * (d / 2 + 0.12), g); } }
    else { mesh(new THREE.CylinderGeometry(1, 1, d + 1.2, 3).rotateX(-Math.PI / 2), rc, 0, H + rh / 3, 0, g).scale.set(w * 0.66, rh / 1.5, 1);
    g.children[g.children.length - 1].material = rmat(rc); }
    const bz = -d / 2 + t, fx = w / 2 - t;
    mesh(new THREE.BoxGeometry(0.7, 2.4, 0.7), 0x6b6258, w * 0.25, H + rh * 0.7, bz + 0.3, g);
    for (const sx of [-1, 1]) { mesh(new THREE.BoxGeometry(0.08, 0.9, 1.1), 0x2c3a44, sx * (w / 2 + 0.02), 1.7, d * 0.2, g).material = glass; mesh(new THREE.BoxGeometry(0.9, 0.9, 0.06), 0x2c3a44, sx * w * 0.3, 1.7, d / 2 + 0.02, g).material = glass; }
    mesh(new THREE.BoxGeometry(w - 2 * t, 0.04, d - 2 * t), wood, 0, 0.02, 0, g); mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.02, 20), 0x7a2e24, 0.2, 0.05, 0.4, g);
    const bedX = -fx + 0.6, bedZ = bz + 1.15;                       // bed
    mesh(new THREE.BoxGeometry(1.1, 0.35, 2.1), 0x5a3d26, bedX, 0.2, bedZ, g); mesh(new THREE.BoxGeometry(1, 0.15, 1.6), 0xa23b32, bedX, 0.43, bedZ + 0.2, g); mesh(new THREE.BoxGeometry(0.7, 0.12, 0.4), 0xeee6d2, bedX, 0.5, bedZ - 0.8, g); bx(bedX, bedZ, 0.55, 1.05);
    const bw = W(bedX, bedZ); acts.push({ x: bw[0], z: bw[1], r: 1.9, label: () => 'E  sleep until morning', act: sleep });
    mesh(new THREE.BoxGeometry(1.3, 0.07, 0.8), wood, 0.2, 0.78, 0.4, g); bx(0.2, 0.4, 0.65, 0.4);                // table + chairs
    for (const lx of [-0.55, 0.55]) for (const lz of [-0.3, 0.3]) mesh(new THREE.BoxGeometry(0.07, 0.76, 0.07), wood, 0.2 + lx, 0.38, 0.4 + lz, g);
    for (const k of [-1, 1]) { mesh(new THREE.BoxGeometry(0.42, 0.05, 0.42), wood, 0.2, 0.45, 0.4 + k * 0.85, g); mesh(new THREE.BoxGeometry(0.42, 0.5, 0.05), wood, 0.2, 0.72, 0.4 + k * 1.05, g); }
    mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.1, 8), 0xcfc7b0, 0.2, 0.86, 0.4, g);
    mesh(new THREE.BoxGeometry(1.3, 2.1, 0.35), 0x4a3320, -w * 0.15, 1.05, bz + 0.2, g); bx(-w * 0.15, bz + 0.2, 0.65, 0.18);   // bookshelf
    for (let k = 0; k < 9; k++) mesh(new THREE.BoxGeometry(0.1, 0.32, 0.2), bookC[k % 5], -w * 0.15 - 0.55 + k * 0.13, 0.6 + (k % 3) * 0.55, bz + 0.38, g);
    mesh(new THREE.BoxGeometry(1.5, 1.2, 0.6), 0x7d7870, w * 0.25, 0.6, bz + 0.3, g); mesh(new THREE.BoxGeometry(0.8, 0.45, 0.1), 0xff7a22, w * 0.25, 0.42, bz + 0.62, g).material = glow; bx(w * 0.25, bz + 0.3, 0.75, 0.3);   // fireplace
    const kx = fx - 0.6, kz = d / 2 - t - 0.6; mesh(new THREE.BoxGeometry(0.8, 0.5, 0.5), 0x6a4a2a, kx, 0.25, kz, g); mesh(new THREE.BoxGeometry(0.82, 0.12, 0.52), 0x7a5a30, kx, 0.56, kz, g); bx(kx, kz, 0.4, 0.25);   // chest
    const kw = W(kx, kz); let looted = false;
    acts.push({ x: kw[0], z: kw[1], r: 1.8, label: () => looted ? '' : 'E  open chest', act: () => { looted = true; const r = rnd(); if (r < 0.5) { P.ammo += 6 + (rnd() * 6 | 0); toast('Chest: arrows!'); } else if (r < 0.8) { P.inv.tonic++; toast('Chest: a healing tonic  (press 2 to use)'); } else { P.ammo += 12; P.inv.tonic++; P.inv.meat++; toast('Chest: a hunter\'s stash!'); } chime(); } });
    mesh(new THREE.SphereGeometry(0.12, 8, 6), 0xffd27a, 0, H - 0.5, 0, g).material = glow;
    mesh(new THREE.BoxGeometry(w - 2 * t, 0.12, d - 2 * t), 0x6b4f33, 0, H + 0.06, 0, g);
    for (const bz2 of [-d / 4, d / 4]) mesh(new THREE.BoxGeometry(w - 2 * t, 0.18, 0.2), 0x4a3320, 0, H - 0.09, bz2, g);
    mesh(new THREE.BoxGeometry(w - 2 * t, 0.12, 0.04), 0x4a3320, 0, 0.1, bz + 0.02, g); for (const sx of [-1, 1]) mesh(new THREE.BoxGeometry(0.04, 0.12, d - 2 * t), 0x4a3320, sx * (fx - 0.02), 0.1, 0, g);
    mesh(new THREE.BoxGeometry(1.1, 0.95, 0.08), 0x4a3320, bedX, 0.7, bedZ - 1.04, g); mesh(new THREE.BoxGeometry(1.1, 0.5, 0.08), 0x4a3320, bedX, 0.42, bedZ + 1.04, g);
    for (const y of [0.42, 0.97, 1.52]) mesh(new THREE.BoxGeometry(1.3, 0.04, 0.3), 0x4a3320, -w * 0.15, y, bz + 0.38, g);
    mesh(new THREE.BoxGeometry(1.7, 0.1, 0.7), 0x4a3f2c, w * 0.25, 1.25, bz + 0.35, g); mesh(new THREE.BoxGeometry(0.9, 0.7, 0.05), 0x151210, w * 0.25, 0.4, bz + 0.605, g);
    for (const k of [-1, 1]) mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.7, 8).rotateZ(Math.PI / 2), 0x3a2a1c, w * 0.25, 0.14, bz + 0.62 + k * 0.03, g);
    for (const y of [0.3, 0.5]) mesh(new THREE.BoxGeometry(0.84, 0.04, 0.54), 0x4a3320, kx, y + 0.05, kz, g);
    /* ---- exterior detail: plinth, corner timbers, frames, shutters, flower boxes, step, lantern, barrels, firewood, drying racks ---- */
    const TB = 0x4a3320, ST = 0x77716a, fz2 = d / 2 + 0.02;
    mesh(new THREE.BoxGeometry(w + 0.3, 0.45, d + 0.3), ST, 0, 0.1, 0, g);                                   // stone plinth
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) mesh(new THREE.BoxGeometry(0.28, H + 0.3, 0.28), TB, sx * (w / 2), (H + 0.3) / 2 - 0.1, sz * (d / 2), g); // corner timbers
    mesh(new THREE.BoxGeometry(w + 0.35, 0.22, d + 0.35), TB, 0, H + 0.12, 0, g);                              // wall plate under the roof
    mesh(new THREE.BoxGeometry(0.2, 2.45, 0.2), TB, -0.8, 1.15, fz2, g); mesh(new THREE.BoxGeometry(0.2, 2.45, 0.2), TB, 0.8, 1.15, fz2, g); mesh(new THREE.BoxGeometry(1.8, 0.2, 0.22), TB, 0, 2.38, fz2, g);   // door frame
    mesh(new THREE.BoxGeometry(2.2, 0.18, 0.9), ST, 0, 0.1, d / 2 + 0.5, g); mesh(new THREE.BoxGeometry(1.9, 0.16, 0.6), 0x8a847a, 0, 0.26, d / 2 + 0.4, g);   // front steps
    for (const sx of [-1, 1]) {
      const wx = sx * w * 0.3;
      mesh(new THREE.BoxGeometry(1.1, 0.1, 0.12), TB, wx, 2.2, fz2 + 0.04, g); mesh(new THREE.BoxGeometry(1.1, 0.1, 0.16), 0x8a847a, wx, 1.2, fz2 + 0.07, g);       // lintel and sill
      mesh(new THREE.BoxGeometry(0.05, 0.9, 0.04), TB, wx, 1.7, fz2 + 0.03, g); mesh(new THREE.BoxGeometry(0.9, 0.05, 0.04), TB, wx, 1.7, fz2 + 0.03, g);              // window cross
      for (const sd of [-1, 1]) { const sh = mesh(new THREE.BoxGeometry(0.48, 0.98, 0.05), sx > 0 ? 0x3f6f5a : 0x7a3a2c, wx + sd * 0.7, 1.7, fz2 + 0.05, g); sh.rotation.y = sd * 0.35; }   // shutters
      mesh(new THREE.BoxGeometry(1.0, 0.2, 0.25), 0x5a3d26, wx, 1.05, fz2 + 0.18, g);                                                                                 // flower box
      for (let k = 0; k < 5; k++) mesh(new THREE.SphereGeometry(0.09, 6, 5), [0xd9402e, 0xf2c230, 0xe8e0d0, 0xd868a8, 0xf2c230][k], wx - 0.4 + k * 0.2, 1.22 + (k % 2) * 0.04, fz2 + 0.2, g);
    }
    const ln = mesh(new THREE.BoxGeometry(0.16, 0.24, 0.16), 0x2a2018, 1.15, 2.05, fz2 + 0.15, g); mesh(new THREE.SphereGeometry(0.1, 8, 6), 0xffd27a, 1.15, 2.05, fz2 + 0.15, g).material = glow; mesh(new THREE.BoxGeometry(0.04, 0.04, 0.2), 0x2a2018, 1.15, 2.2, fz2 + 0.05, g); ln.visible = true;
    // water barrel, firewood stack and a drying rack at the side wall
    const sxs = (houses.length % 2 ? 1 : -1), bxs = sxs * (w / 2 + 0.7);
    mesh(new THREE.CylinderGeometry(0.34, 0.3, 0.8, 12), 0x6a4a2a, bxs, 0.45, d * 0.25, g); for (const y of [0.25, 0.65]) mesh(new THREE.TorusGeometry(0.33, 0.025, 6, 16).rotateX(Math.PI / 2), 0x3a3a3a, bxs, y, d * 0.25, g); bx(bxs, d * 0.25, 0.34, 0.34);
    for (let r = 0; r < 3; r++) for (let q2 = 0; q2 < 4 - r; q2++) mesh(new THREE.CylinderGeometry(0.1, 0.1, 1.1, 7).rotateZ(Math.PI / 2), 0x6a4f33, sxs * (w / 2 + 0.7), 0.12 + r * 0.19, -d * 0.2 + q2 * 0.21 + r * 0.1, g);
    for (const k of [-1, 1]) mesh(new THREE.BoxGeometry(0.1, 1.6, 0.1), TB, sxs * (w / 2 + 1.6), 0.8, -d * 0.1 + k * 0.9, g);
    mesh(new THREE.BoxGeometry(0.08, 0.08, 2), TB, sxs * (w / 2 + 1.6), 1.55, -d * 0.1, g); for (let k = 0; k < 5; k++) mesh(new THREE.ConeGeometry(0.1, 0.5, 5).rotateX(Math.PI), 0xc9a860, sxs * (w / 2 + 1.6), 1.25, -d * 0.1 - 0.8 + k * 0.4, g);
    if (!VS.flat) { for (const sx of [-1, 1]) mesh(new THREE.BoxGeometry(0.12, 0.12, d + 1.4), TB, sx * (w * 0.33), H + 0.1, 0, g); mesh(new THREE.CylinderGeometry(0.12, 0.12, d + 1.6, 6).rotateX(Math.PI / 2), TB, 0, H + rh * 0.58, 0, g); }   // roof ridge pole and eave beams
    { const cw = W(w * 0.25, bz + 0.3); chims.push([cw[0], heightAt(x, z) + H + rh * 0.7 + 1.7, cw[1]]); }
    mesh(new THREE.CylinderGeometry(0.42, 0.5, 0.35, 8), 0x6b6258, w * 0.25, H + rh * 0.7 + 1.35, bz + 0.3, g); mesh(new THREE.CylinderGeometry(0.3, 0.3, 0.06, 8), 0x1c1815, w * 0.25, H + rh * 0.7 + 1.55, bz + 0.3, g);   // chimney pot
    // interior extras: wall hangings, rug, clay pots, hanging lamp, shelf with jugs
    mesh(new THREE.BoxGeometry(1.0, 1.1, 0.04), [0xa23b32, 0x2f5a8a, 0xc9a64a][houses.length % 3], w * 0.02 + 0.5, 1.6, bz + 0.24, g); mesh(new THREE.BoxGeometry(1.1, 0.06, 0.06), 0x3a2a1c, w * 0.02 + 0.5, 2.18, bz + 0.24, g);
    for (let k = 0; k < 3; k++) mesh(new THREE.CylinderGeometry(0.1 + k * 0.02, 0.07, 0.3 + k * 0.05, 10), [0x9a5a36, 0x7a4a2e, 0xb06a40][k], w / 2 - t - 0.35, 0.2, d / 2 - t - 1.5 - k * 0.45, g);
    mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.5, 4), 0x222222, 0, H - 0.25, 0, g);
    houses.push({ x, z, c, s, w, d, H });
  }
  for (let i = 0; i < VS.rect; i++) {
    house(cx - 24 + i * 16 + (rnd() - .5) * 3, cz - 13, 0, 7 + rnd() * 3, 5.5 + rnd() * 2, VS.H + rnd() * VS.Hr, 2.6, roofC[i % roofC.length], wallC[i % wallC.length]);
    house(cx - 16 + i * 16 + (rnd() - .5) * 3, cz + 13, Math.PI, 7 + rnd() * 3, 5.5 + rnd() * 2, VS.H + rnd() * VS.Hr, 2.6, roofC[(i + 1) % roofC.length], wallC[(i + 2) % wallC.length]);
  }
  if (VS.rect) house(cx + 38, cz, 0, 7, 14, VS.flat ? VS.H + 1 : 6, 4, VS.flat ? roofC[0] : 0x5d4636, wallC[0]);
  const tg = new THREE.Group(); tg.position.set(cx + 38, heightAt(cx + 38, cz - 9.5), cz - 9.5);
  if (VS.church === 'mosque') {
    mesh(new THREE.BoxGeometry(10, 6.5, 14), 0xf2ecdc, 0, 3.25, 0, tg); mesh(new THREE.SphereGeometry(3, 18, 10, 0, 6.283, 0, 1.5708), 0xe8e0cc, 0, 6.5, 0, tg);
    mesh(new THREE.CylinderGeometry(0.9, 1.2, 15, 12), 0xf2ecdc, 5.6, 7.5, -5, tg); mesh(new THREE.CylinderGeometry(1.5, 1.5, 0.3, 12), 0xcfc6b0, 5.6, 13, -5, tg); mesh(new THREE.ConeGeometry(1.1, 3, 12), 0x3a8a5a, 5.6, 16.1, -5, tg);
    mesh(new THREE.BoxGeometry(2, 3.6, 0.3), 0x2a6a4a, 0, 1.8, 7.1, tg); for (let k = -2; k <= 2; k += 2) if (k) mesh(new THREE.BoxGeometry(1, 2, 0.3), 0x2c3a44, k * 1.8, 3.6, 7.1, tg);
    scene.add(tg); addCollider(cx + 38, cz - 9.5, 7);
  } else if (VS.church === 'stone') {
    mesh(new THREE.BoxGeometry(12, 7, 8), 0x8b7d68, 0, 3.5, 0, tg); mesh(new THREE.BoxGeometry(12.6, 0.5, 8.6), 0x7a6d5a, 0, 7.25, 0, tg);
    for (const y of [2.3, 4.6]) mesh(new THREE.BoxGeometry(12.2, 0.35, 8.2), 0x5a4f40, 0, y, 0, tg);
    mesh(new THREE.BoxGeometry(1.8, 3.2, 0.3), 0x2a1c12, 0, 1.6, 4.1, tg); for (const k of [-3.5, 3.5]) mesh(new THREE.BoxGeometry(0.9, 1.6, 0.3), 0x2a1c12, k, 4.2, 4.1, tg);
    mesh(new THREE.BoxGeometry(0.2, 2.6, 0.2), 0xd4a73a, 0, 8.9, 0, tg); mesh(new THREE.BoxGeometry(1.1, 0.2, 0.2), 0xd4a73a, 0, 9.4, 0, tg);
    scene.add(tg); addCollider(cx + 38, cz - 9.5, 6.5);
  } else if (VS.church === 'round') {
  // Ethiopian Orthodox church: round, tiered, tin roof, gold cross
  mesh(new THREE.CylinderGeometry(5, 5.4, 8, 20), 0xe6d9b4, 0, 3, 0, tg); mesh(new THREE.CylinderGeometry(3.4, 3.6, 3.4, 20), 0xd8c8a0, 0, 8.7, 0, tg);
  mesh(new THREE.ConeGeometry(6.3, 3.6, 20), 0x8d9296, 0, 8.6, 0, tg); mesh(new THREE.ConeGeometry(3.9, 3.8, 20), 0x8d9296, 0, 12.6, 0, tg);
  mesh(new THREE.BoxGeometry(0.16, 2.4, 0.16), 0xd4a73a, 0, 15.8, 0, tg); mesh(new THREE.BoxGeometry(1, 0.16, 0.16), 0xd4a73a, 0, 16.2, 0, tg);
  for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283; mesh(new THREE.BoxGeometry(0.7, 1.7, 0.3), k % 2 ? 0x2a6a4a : 0xa23b32, Math.cos(a) * 5.4, 2.2, Math.sin(a) * 5.4, tg).rotation.y = -a + Math.PI / 2; }
  scene.add(tg); addCollider(cx + 38, cz - 9.5, 5.6); }
  // round tukul huts with thatched cone roofs on the village outskirts
  const HU = VS.hut;
  for (let k = 0; k < (HU.n || 0); k++) {   // enterable round huts, shaped per region: thatch cone, tall beehive (Dorze), low dome (Afar/Somali), stone-walled (Konso)
    const a = 0.3 + k * 6.4 / HU.n, r = 47 + rnd() * 9, hx = cx + Math.cos(a) * r, hz = cz + Math.sin(a) * r, door = a + Math.PI, hy = heightAt(hx, hz), N = 14, RR = HU.rr > 4 ? 3 : 2.9, wc = HU.wc || wallC[k % wallC.length], wh = HU.wh, rm = rmat(HU.rc);
    for (let i = 1; i < N; i++) {
      const ps = door + i * 6.2832 / N, px = hx + Math.cos(ps) * RR, pz = hz + Math.sin(ps) * RR, y = -ps - Math.PI / 2;
      mesh(new THREE.BoxGeometry(1.45, wh + 1, 0.32), wc, px, heightAt(px, pz) + (wh - 1) / 2, pz, scene).rotation.y = y;
      boxes.push({ x: px, z: pz, c: Math.cos(y), s: Math.sin(y), hw: 0.73, hd: 0.2, R2: 4 });
    }
    if (wh > 1.6) { const dx = hx + Math.cos(door) * RR, dz = hz + Math.sin(door) * RR; mesh(new THREE.BoxGeometry(1.5, 0.7, 0.36), wc, dx, heightAt(dx, dz) + wh - 0.35, dz, scene).rotation.y = -door - Math.PI / 2; }
    if (HU.dome) mesh(new THREE.SphereGeometry(HU.rr, 14, 8, 0, 6.283, 0, 1.5708), HU.rc, hx, hy + wh, hz, scene).scale.set(1, HU.rh / HU.rr, 1);
    else mesh(new THREE.ConeGeometry(HU.rr, HU.rh, 14), HU.rc, hx, hy + wh + HU.rh / 2, hz, scene);
    scene.children[scene.children.length - 1].material = rm;
    // hut details: clay finial, painted band, plinth stones, door posts and lintel, thatch skirt ring, small window, doorstep
    mesh(new THREE.CylinderGeometry(0.1, 0.2, 0.45, 8), 0x9a5a36, hx, hy + wh + HU.rh + 0.05, hz, scene); mesh(new THREE.SphereGeometry(0.13, 8, 6), 0x9a5a36, hx, hy + wh + HU.rh + 0.35, hz, scene);
    if (wh > 1.0) { mesh(new THREE.TorusGeometry(RR + 0.2, 0.06, 6, 28).rotateX(Math.PI / 2), [0xe8dcc0, 0xc9402e, 0x2f7a5a, 0xd9a830][k % 4], hx, hy + wh * 0.6, hz, scene); mesh(new THREE.TorusGeometry(RR + 0.2, 0.09, 6, 28).rotateX(Math.PI / 2), 0x6a645c, hx, hy + 0.12, hz, scene); }
    mesh(new THREE.TorusGeometry(HU.rr * 0.98, 0.09, 6, 32).rotateX(Math.PI / 2), 0x8a6a30, hx, hy + wh + 0.05, hz, scene);
    { const dx = hx + Math.cos(door) * RR, dz = hz + Math.sin(door) * RR, yy = -door - Math.PI / 2, ox = Math.cos(yy) * 0.78, oz = -Math.sin(yy) * 0.78;
      for (const s of [-1, 1]) mesh(new THREE.BoxGeometry(0.16, wh + 0.2, 0.4), 0x4a3320, dx + ox * s, heightAt(dx, dz) + (wh + 0.2) / 2, dz + oz * s, scene).rotation.y = yy;
      mesh(new THREE.BoxGeometry(1.7, 0.18, 0.42), 0x4a3320, dx, heightAt(dx, dz) + wh + 0.05, dz, scene).rotation.y = yy;
      mesh(new THREE.BoxGeometry(1.5, 0.12, 0.7), 0x8a847a, dx + Math.cos(door) * 0.4, heightAt(dx, dz) + 0.06, dz + Math.sin(door) * 0.4, scene).rotation.y = yy; }
    for (let m = 0; m < 5; m++) { const a2 = door + Math.PI * 0.5 + m * 0.6, rx = hx + Math.cos(a2) * (RR + 0.7), rz = hz + Math.sin(a2) * (RR + 0.7); mesh(new THREE.SphereGeometry(0.2 + (m % 2) * 0.08, 6, 5), 0x77716a, rx, heightAt(rx, rz) + 0.1, rz, scene); }
    mesh(new THREE.CylinderGeometry(2.7, 2.7, 0.08, 16), 0x6b5a3e, hx, hy + 0.04, hz, scene);
    for (let m = 0; m < 3; m++) mesh(new THREE.SphereGeometry(0.14, 6, 5), 0x6a655d, hx + Math.cos(m * 2.1) * 0.3, hy + 0.14, hz + Math.sin(m * 2.1) * 0.3, scene);
    mesh(new THREE.ConeGeometry(0.18, 0.4, 6), 0xff7a22, hx, hy + 0.3, hz, scene).material = glow; boxes.push({ x: hx, z: hz, c: 1, s: 0, hw: 0.35, hd: 0.35, R2: 4 });
    const bxp = hx + Math.cos(a) * 1.8, bzp = hz + Math.sin(a) * 1.8, by = Math.PI / 2 - a;
    mesh(new THREE.BoxGeometry(0.9, 0.3, 1.8), 0x5a3d26, bxp, hy + 0.2, bzp, scene).rotation.y = by; mesh(new THREE.BoxGeometry(0.8, 0.12, 1.4), 0xa23b32, bxp, hy + 0.42, bzp, scene).rotation.y = by;
    boxes.push({ x: bxp, z: bzp, c: Math.cos(by), s: Math.sin(by), hw: 0.45, hd: 0.9, R2: 4 });
    acts.push({ x: bxp, z: bzp, r: 2.2, label: () => 'E  sleep until morning', act: sleep });
  }
  if (VS.towers) for (const [tx, tz, th] of [[-52, -30, 36], [-50, 28, 28], [30, -54, 42]]) {   // Addis Ababa: glass and concrete towers
    mesh(new THREE.BoxGeometry(12, th, 12), 0x6f8594, cx + tx, heightAt(cx + tx, cz + tz) + th / 2 - 1, cz + tz, scene); mesh(new THREE.BoxGeometry(12.2, th * 0.7, 12.2), 0x3d5260, cx + tx, heightAt(cx + tx, cz + tz) + th * 0.5, cz + tz, scene);
    boxes.push({ x: cx + tx, z: cz + tz, c: 1, s: 0, hw: 6, hd: 6, R2: 150 });
  }
  const rg = new THREE.PlaneGeometry(76, 7, 24, 2).rotateX(-Math.PI / 2), rp = rg.attributes.position;
  for (let i = 0; i < rp.count; i++) rp.setY(i, heightAt(cx + rp.getX(i), cz + rp.getZ(i)) + 0.06);
  rg.computeVertexNormals(); const road = new THREE.Mesh(rg, mat(0x6b5a3e)); road.position.set(0, 0, 0); road.translateX(cx); road.translateZ(cz); road.receiveShadow = true; scene.add(road);
  rp.needsUpdate = true;
  const NP = 2 * 34, posts = new THREE.InstancedMesh(new THREE.BoxGeometry(0.14, 1.3, 0.14), mat(0x6a5236), NP), rails = new THREE.InstancedMesh(new THREE.BoxGeometry(2.25, 0.09, 0.06), mat(0x7a6040), NP * 2);
  const M = new THREE.Matrix4(); let n = 0;
  for (const zz of [-6, 6]) for (let i = 0; i < 34; i++, n++) {
    const x = cx - 38 + i * 2.2, y = heightAt(x, cz + zz);
    M.makeTranslation(x, y + 0.5, cz + zz); posts.setMatrixAt(n, M);
    M.makeTranslation(x + 1.1, y + 0.45, cz + zz); rails.setMatrixAt(n * 2, M); M.makeTranslation(x + 1.1, y + 0.95, cz + zz); rails.setMatrixAt(n * 2 + 1, M);
  }
  for (const m of [posts, rails]) { m.castShadow = true; scene.add(m); }
  /* ---------- village life: square with well and bonfire, market stalls, granary, pens, crop plots, lamp posts, trees, villagers ---------- */
  const Hh = (x, z) => heightAt(x, z), flick = [], vil = [];
  const S = (g, c, x, z, y, rot) => { const m = mesh(g, c, x, Hh(x, z) + y, z, scene); if (rot) m.rotation.y = rot; return m; };   // object standing on the ground
  // central well
  { const wx = cx - 3, wz = cz + 0.5;
    S(new THREE.CylinderGeometry(1.25, 1.35, 1.1, 18), 0x8a847a, wx, wz, 0.5); S(new THREE.TorusGeometry(1.2, 0.12, 8, 24).rotateX(Math.PI / 2), 0x6a645c, wx, wz, 1.08);
    S(new THREE.CylinderGeometry(1.0, 1.0, 0.05, 16), 0x1a3a4a, wx, wz, 1.0);
    for (const s of [-1, 1]) S(new THREE.BoxGeometry(0.14, 2.3, 0.14), 0x4a3320, wx + s * 1.1, wz, 1.2);
    S(new THREE.BoxGeometry(2.6, 0.12, 0.2), 0x4a3320, wx, wz, 2.3); S(new THREE.CylinderGeometry(0.08, 0.08, 2.3, 8).rotateZ(Math.PI / 2), 0x6a4a2a, wx, wz, 1.85);
    for (const s of [-1, 1]) S(new THREE.BoxGeometry(1.5, 0.08, 1.5), VS.flat ? roofC[0] : 0x8d9296, wx, wz, 2.55 + 0.0).rotation.z = s * 0.001;
    S(new THREE.CylinderGeometry(0.16, 0.13, 0.28, 8), 0x6a4a2a, wx, wz + 0.3, 1.35); addCollider(wx, wz, 1.4);
    for (let k = 0; k < 14; k++) { const a = k / 14 * 6.283; S(new THREE.BoxGeometry(0.5, 0.25, 0.3), [0x77716a, 0x8a847a, 0x6a645c][k % 3], wx + Math.cos(a) * 2.1, wz + Math.sin(a) * 2.1, 0.12, -a); }   // paving ring
    // waiting pots
    for (let k = 0; k < 4; k++) S(new THREE.CylinderGeometry(0.2, 0.14, 0.45, 10), 0x9a5a36, wx + 2.8 + (k % 2) * 0.5, wz - 0.6 + k * 0.3, 0.22);
  }
  // evening bonfire with log seats and stone ring
  { const bxx = cx + 14, bzz = cz + 1; for (let k = 0; k < 10; k++) { const a = k / 10 * 6.283; S(new THREE.SphereGeometry(0.22, 7, 6), 0x6a655d, bxx + Math.cos(a) * 1, bzz + Math.sin(a) * 1, 0.1); }
    for (let k = 0; k < 4; k++) S(new THREE.CylinderGeometry(0.07, 0.09, 1.2, 6).rotateZ(Math.PI / 2 - 0.5), 0x3a2a1c, bxx, bzz, 0.3, k * 0.8);
    const fl = S(new THREE.ConeGeometry(0.4, 1.2, 7), 0xff8a2a, bxx, bzz, 0.9); fl.material = new THREE.MeshBasicMaterial({ color: 0xff8a2a, transparent: true, opacity: 0.85 }); flick.push(fl);
    for (let k = 0; k < 4; k++) { const a = k * 1.57 + 0.4; S(new THREE.CylinderGeometry(0.28, 0.28, 2.0, 8).rotateZ(Math.PI / 2), 0x5a3d26, bxx + Math.cos(a) * 3, bzz + Math.sin(a) * 3, 0.3, -a + Math.PI / 2); }
    const bl = new THREE.PointLight(0xff8a3a, 0, 22, 2); bl.position.set(bxx, Hh(bxx, bzz) + 1.4, bzz); scene.add(bl); flick.push(bl); }
  // market: striped awnings over tables piled with produce, sacks, baskets, spice cones
  const ST2 = [[cx - 17, cz - 4.8, 0], [cx - 10, cz + 4.8, Math.PI], [cx + 7, cz - 4.8, 0], [cx + 20, cz + 4.8, Math.PI]], mk = [0xd9402e, 0x2f7a5a, 0xf2c230, 0x2f5a8a];
  ST2.forEach(([sx, sz, yw], i) => {
    for (const a of [-1, 1]) for (const b of [-1, 1]) S(new THREE.CylinderGeometry(0.05, 0.05, 2.4, 6), 0x4a3320, sx + a * 1.4, sz + b * 0.8, 1.2);
    for (let k = 0; k < 6; k++) S(new THREE.BoxGeometry(0.5, 0.05, 2.1), k % 2 ? 0xf2ecdc : mk[i], sx - 1.25 + k * 0.5, sz, 2.45 - (yw ? 0 : 0)).rotation.z = 0;
    S(new THREE.BoxGeometry(2.6, 0.08, 1.0), 0x6a4a2a, sx, sz, 0.9); S(new THREE.BoxGeometry(2.4, 0.5, 0.8), 0x4a3320, sx, sz, 0.45);
    const prod = [[0xd9402e, 0.14], [0xf2a830, 0.15], [0x5aa83a, 0.13], [0xc9a860, 0.12]];
    for (let k = 0; k < 14; k++) { const p = prod[(k + i) % 4]; S(new THREE.SphereGeometry(p[1], 7, 6), p[0], sx - 1 + (k % 7) * 0.33, sz - 0.2 + (k > 6 ? 0.35 : 0), 1.0 + p[1] * 0.5); }
    for (let k = 0; k < 3; k++) S(new THREE.CylinderGeometry(0.0, 0.2, 0.3, 8), [0xc8381a, 0xe0a020, 0x8a5a2a][k], sx - 1.0 + k * 0.45, sz + 0.55 - 1.2, 0.0 + 0.15).position.y += 0;
    for (let k = 0; k < 3; k++) S(new THREE.SphereGeometry(0.34, 8, 6).scale(1, 0.8, 0.8), 0xcdbd90, sx + 1.7, sz - 0.5 + k * 0.5, 0.25);
    S(new THREE.CylinderGeometry(0.28, 0.2, 0.3, 10), 0x9a6a3a, sx - 1.8, sz + 0.2, 0.15);
    addCollider(sx, sz, 1.0);
  });
  // granary (stilted, thatched) and a mud-plastered store
  { const gx = cx - 30, gz = cz - 22;
    for (const a of [-1, 1]) for (const b of [-1, 1]) S(new THREE.CylinderGeometry(0.14, 0.18, 1.2, 6), 0x5a3d26, gx + a * 1.0, gz + b * 1.0, 0.6);
    S(new THREE.CylinderGeometry(1.7, 1.5, 1.8, 14), 0xb98a58, gx, gz, 2.1); S(new THREE.ConeGeometry(2.3, 1.8, 14), 0xc9a050, gx, gz, 3.9).material = rmat(0xc9a050);
    S(new THREE.BoxGeometry(0.7, 0.9, 0.1), 0x4a3320, gx, gz + 1.6, 2.0, 0); addCollider(gx, gz, 2.0); }
  // livestock pens: woven fence, goats and sheep, a feed trough, hay bales
  for (const [px, pz] of [[cx - 36, cz + 24], [cx + 24, cz + 28]]) {
    for (let k = 0; k < 22; k++) { const a = k / 22 * 6.283, x = px + Math.cos(a) * 6, z = pz + Math.sin(a) * 4.5; S(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 5), 0x6a4f33, x, z, 0.6); if (k % 2) S(new THREE.BoxGeometry(1.9, 0.1, 0.07), 0x7a6040, x, z, 0.5, -a + Math.PI / 2), S(new THREE.BoxGeometry(1.9, 0.1, 0.07), 0x7a6040, x, z, 0.95, -a + Math.PI / 2); addCollider(x, z, 0.5); }
    for (let k = 0; k < 6; k++) { const gt = new THREE.Group(), cl = k % 3 === 0 ? 0xf2ecdc : k % 3 === 1 ? 0x6a4a2a : 0x2a221c; const body = mesh(new THREE.SphereGeometry(0.36, 8, 6).scale(1.5, 0.9, 0.8), cl, 0, 0.55, 0, gt); mesh(new THREE.SphereGeometry(0.17, 8, 6), cl, 0.5, 0.78, 0, gt); for (const lx of [-0.3, 0.3]) for (const lz of [-0.15, 0.15]) mesh(new THREE.CylinderGeometry(0.035, 0.03, 0.4, 5), 0x4a3a2c, lx, 0.2, lz, gt); if (k % 3 !== 1) for (const o of [-0.06, 0.06]) mesh(new THREE.ConeGeometry(0.03, 0.2, 5), 0xcfc0a2, 0.52, 1.0, o, gt);
      gt.position.set(px + (rnd() - .5) * 7, Hh(px, pz), pz + (rnd() - .5) * 5); gt.rotation.y = rnd() * 6.28; scene.add(gt); vil.push({ g: gt, pen: [px, pz], t: rnd() * 6, ph: rnd() * 6, goat: 1, x: gt.position.x, z: gt.position.z, yaw: gt.rotation.y }); }
    S(new THREE.BoxGeometry(2, 0.35, 0.5), 0x5a3d26, px + 3.5, pz - 0.5, 0.25); for (let k = 0; k < 3; k++) S(new THREE.BoxGeometry(0.9, 0.5, 0.5), 0xc9b060, px - 3.5 + k * 1.0, pz + 2, 0.25 + (k === 2 ? 0.45 : 0), 0.2 * k);
  }
  // crop plots behind the houses: teff, barley, maize rows, with a scarecrow
  const cropPlot = (px, pz, w, d, c1, rows, h) => { S(new THREE.BoxGeometry(w, 0.1, d), 0x4a3322, px, pz, 0.03); const n = Math.floor(w / rows); for (let k = 0; k < n; k++) S(new THREE.BoxGeometry(0.55, h, d - 1), c1, px - w / 2 + 0.5 + k * rows, pz, h / 2 + 0.1); };
  cropPlot(cx - 28, cz - 36, 16, 10, 0xc9a840, 1.0, 0.5); cropPlot(cx - 8, cz - 38, 16, 10, 0x4a8a2a, 1.0, 0.7); cropPlot(cx + 12, cz - 36, 14, 10, 0x6aa030, 1.4, 1.6); cropPlot(cx + 34, cz + 24, 12, 9, 0xd8b848, 1.0, 0.5);
  { const sx = cx - 8, sz = cz - 38; S(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5), 0x4a3320, sx, sz, 1.1); S(new THREE.BoxGeometry(1.6, 0.07, 0.07), 0x4a3320, sx, sz, 1.7); S(new THREE.BoxGeometry(0.5, 0.7, 0.2), 0xa23b32, sx, sz, 1.5); S(new THREE.SphereGeometry(0.2, 8, 6), 0xd8c9a0, sx, sz, 2.3); S(new THREE.ConeGeometry(0.3, 0.3, 8), 0x6a4a2a, sx, sz, 2.55); }
  // lamp posts along the road: warm glow at night
  const lampM = new THREE.MeshBasicMaterial({ color: 0xffc070 });
  for (let k = -3; k <= 3; k++) for (const s of [-1, 1]) { const lx = cx + k * 11 + (s > 0 ? 5 : 0), lz = cz + s * 4.4; S(new THREE.CylinderGeometry(0.06, 0.08, 2.9, 6), 0x2a2018, lx, lz, 1.45); S(new THREE.BoxGeometry(0.34, 0.4, 0.34), 0x2a2018, lx, lz, 3.0); S(new THREE.SphereGeometry(0.15, 8, 6), 0xffc070, lx, lz, 3.0).material = lampM; }
  // shade trees and flowering shrubs in the square, stones and benches
  for (const [tx2, tz2, ty2] of [[cx + 4, cz - 8.5, 0], [cx - 21, cz + 8, 1], [cx + 28, cz - 6, 0]]) {
    S(new THREE.CylinderGeometry(0.35, 0.55, 3.2, 8), 0x5a4330, tx2, tz2, 1.6); for (let k = 0; k < 6; k++) { const a = k * 1.05; S(new THREE.IcosahedronGeometry(2.0 + (k % 2) * 0.6, 1).scale(1, 0.7, 1), [0x3a6a24, 0x4a7a2a, 0x2f5a20][k % 3], tx2 + Math.cos(a) * 1.6, tz2 + Math.sin(a) * 1.6, 4.0 + (k % 3) * 0.3); } addCollider(tx2, tz2, 0.6);
    S(new THREE.BoxGeometry(2.2, 0.15, 0.6), 0x5a3d26, tx2 + 2.4, tz2, 0.5); for (const o of [-0.9, 0.9]) S(new THREE.BoxGeometry(0.15, 0.5, 0.5), 0x4a3320, tx2 + 2.4 + o, tz2, 0.25);
  }
  for (let k = 0; k < 40; k++) { const a = rnd() * 6.283, r = 18 + rnd() * 38, x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r; if (Math.abs(z - cz) < 5) continue; const c3 = [0xd9402e, 0xf2c230, 0xd868a8, 0xe8e0d0, 0x8a5ad8][k % 5]; for (let m = 0; m < 4; m++) S(new THREE.SphereGeometry(0.1, 6, 5), c3, x + (rnd() - .5) * 0.6, z + (rnd() - .5) * 0.6, 0.45 + rnd() * 0.15); S(new THREE.IcosahedronGeometry(0.5, 0).scale(1, 0.7, 1), 0x3a6a24, x, z, 0.3); }
  // villagers: robed figures with shamma shawls, walking between points; they stop and turn to face you when you are near
  const robe = [0xf2ecdc, 0xe8dcc0, 0xf2ecdc, 0xd9c9a0], shawl = [0x2f7a5a, 0xd9402e, 0xf2c230, 0x2f5a8a];
  for (let k = 0; k < 9; k++) {
    const vg = new THREE.Group(), kid = k % 4 === 3, sc = kid ? 0.65 : 0.95 + rnd() * 0.15, sk = [0x6a4430, 0x7a5236, 0x5a3a28, 0x8a6040][k % 4];
    mesh(new THREE.CylinderGeometry(0.2, 0.34, 1.0, 10), robe[k % 4], 0, 0.75, 0, vg); mesh(new THREE.SphereGeometry(0.2, 10, 8).scale(1.2, 0.5, 1), shawl[k % 4], 0, 1.3, 0, vg);
    mesh(new THREE.CylinderGeometry(0.06, 0.07, 0.12, 6), sk, 0, 1.38, 0, vg); mesh(new THREE.SphereGeometry(0.15, 10, 8), sk, 0, 1.54, 0, vg); mesh(new THREE.SphereGeometry(0.155, 10, 8, 0, 6.28, 0, 1.2), 0x1a120c, 0, 1.56, 0.015, vg).rotation.x = -0.3;
    const aL = new THREE.Group(), aR = new THREE.Group(); aL.position.set(-0.26, 1.3, 0); aR.position.set(0.26, 1.3, 0); vg.add(aL, aR); for (const a of [aL, aR]) { mesh(new THREE.CylinderGeometry(0.05, 0.045, 0.55, 6).translate(0, -0.27, 0), robe[k % 4], 0, 0, 0, a); mesh(new THREE.SphereGeometry(0.05, 6, 5), sk, 0, -0.58, 0, a); }
    const lL = new THREE.Group(), lR = new THREE.Group(); lL.position.set(-0.1, 0.35, 0); lR.position.set(0.1, 0.35, 0); vg.add(lL, lR); for (const l of [lL, lR]) { mesh(new THREE.CylinderGeometry(0.06, 0.05, 0.4, 6).translate(0, -0.17, 0), sk, 0, 0, 0, l); mesh(new THREE.BoxGeometry(0.12, 0.06, 0.2), 0x3a2a1c, 0, -0.38, 0.04, l); }
    if (k % 3 === 0) { mesh(new THREE.CylinderGeometry(0.17, 0.12, 0.3, 10), 0x9a5a36, 0.0, 1.9, 0, vg); }   // water jar on the head
    vg.scale.setScalar(sc); const a0 = rnd() * 6.283, r0 = 6 + rnd() * 28; vg.position.set(cx + Math.cos(a0) * r0, Hh(cx, cz), cz + Math.sin(a0) * r0 * 0.5); scene.add(vg);
    vil.push({ g: vg, aL, aR, lL, lR, x: vg.position.x, z: vg.position.z, tx: cx + (rnd() - .5) * 60, tz: cz + (rnd() - .5) * 40, yaw: rnd() * 6.28, t: rnd() * 5, ph: rnd() * 6, sc, sp: 0.8 + rnd() * 0.5 });
  }
  // chimney smoke: slow rising puffs that drift with the wind (denser in the cold evening)
  const puffTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 2, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,.9)'); gr.addColorStop(0.5, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
  const puffs = []; chims.slice(0, 10).forEach(([sx, sy, sz], i) => { for (let k = 0; k < 6; k++) { const sp2 = new THREE.Sprite(new THREE.SpriteMaterial({ map: puffTex, color: 0xb8b2a8, transparent: true, opacity: 0, depthWrite: false, fog: true })); scene.add(sp2); puffs.push({ s: sp2, x: sx, y: sy, z: sz, t: k / 6, sp: 0.8 + (i % 3) * 0.12 }); } });
  // trampled earth where the village stands
  { const gc = document.createElement('canvas'); gc.width = gc.height = 256; const g2 = gc.getContext('2d'), gr = g2.createRadialGradient(128, 128, 20, 128, 128, 128); gr.addColorStop(0, 'rgba(120,88,56,.95)'); gr.addColorStop(0.65, 'rgba(120,88,56,.7)'); gr.addColorStop(1, 'rgba(120,88,56,0)'); g2.fillStyle = gr; g2.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 900; i++) { const a = rnd() * 6.283, r = rnd() * 120; g2.fillStyle = 'rgba(' + (60 + rnd() * 90 | 0) + ',' + (45 + rnd() * 60 | 0) + ',30,' + (0.15 + rnd() * 0.25) + ')'; g2.fillRect(128 + Math.cos(a) * r, 128 + Math.sin(a) * r, 1 + rnd() * 3, 1 + rnd() * 3); }
    const gt = new THREE.CanvasTexture(gc); gt.encoding = THREE.sRGBEncoding; const gg = new THREE.PlaneGeometry(150, 110, 30, 22).rotateX(-Math.PI / 2), gp = gg.attributes.position; for (let i = 0; i < gp.count; i++) gp.setY(i, Hh(cx + gp.getX(i), cz + gp.getZ(i)) + 0.035); gg.computeVertexNormals();
    const gm2 = new THREE.Mesh(gg, new THREE.MeshStandardMaterial({ map: gt, transparent: true, depthWrite: false, roughness: 1, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 })); gm2.position.set(cx, 0, cz); gm2.receiveShadow = true; scene.add(gm2); }
  /* ---- coffee ceremony: grass mat, jebena pot on charcoal, cups, stools, incense, popcorn ---- */
  { const ox = cx - 12, oz = cz - 8.4;
    S(new THREE.BoxGeometry(5, 0.05, 3.4), 0x4f7a2a, ox, oz, 0.03); for (let k = 0; k < 14; k++) S(new THREE.BoxGeometry(0.08, 0.02, 3.3), k % 2 ? 0x6a9a3a : 0x3f6a22, ox - 2.3 + k * 0.35, oz, 0.07);
    S(new THREE.CylinderGeometry(0.35, 0.45, 0.25, 12), 0x2a2018, ox, oz, 0.16); S(new THREE.CylinderGeometry(0.28, 0.28, 0.04, 12), 0xff5a1a, ox, oz, 0.3).material = new THREE.MeshBasicMaterial({ color: 0xff5a1a });
    S(new THREE.SphereGeometry(0.3, 12, 10).scale(1, 1.1, 1), 0x1c1612, ox, oz, 0.7); S(new THREE.CylinderGeometry(0.1, 0.2, 0.4, 10), 0x1c1612, ox, oz, 1.1); S(new THREE.BoxGeometry(0.06, 0.06, 0.45), 0x1c1612, ox + 0.3, oz, 0.95).rotation.y = 0.8;
    S(new THREE.TorusGeometry(0.2, 0.025, 6, 12), 0x1c1612, ox - 0.2, oz, 0.95);
    S(new THREE.CylinderGeometry(0.7, 0.7, 0.05, 16), 0x8a5a30, ox + 1.2, oz + 0.2, 0.08); for (let k = 0; k < 8; k++) { const a = k * 0.785; S(new THREE.CylinderGeometry(0.045, 0.035, 0.07, 8), 0xf2ecdc, ox + 1.2 + Math.cos(a) * 0.4, oz + 0.2 + Math.sin(a) * 0.4, 0.15); }
    S(new THREE.CylinderGeometry(0.22, 0.14, 0.14, 10), 0xe8dcc0, ox - 1.4, oz + 0.6, 0.12); for (let k = 0; k < 9; k++) S(new THREE.SphereGeometry(0.035, 5, 4), 0xfff8e8, ox - 1.4 + (rnd() - .5) * 0.25, oz + 0.6 + (rnd() - .5) * 0.25, 0.2);
    S(new THREE.CylinderGeometry(0.1, 0.07, 0.18, 8), 0x6a4a2a, ox + 0.6, oz - 1.0, 0.1); const inc = S(new THREE.SphereGeometry(0.03, 5, 4), 0xcfc7b0, ox + 0.6, oz - 1.0, 0.28);
    for (const [sx2, sz2] of [[-1.7, -0.6], [-1.4, 1.2], [1.8, -0.9], [0.2, 1.6]]) { S(new THREE.CylinderGeometry(0.22, 0.2, 0.1, 10), 0x6a4a2a, ox + sx2, oz + sz2, 0.28); for (const a of [0, 2, 4]) S(new THREE.CylinderGeometry(0.03, 0.03, 0.26, 5), 0x4a3320, ox + sx2 + Math.cos(a) * 0.14, oz + sz2 + Math.sin(a) * 0.14, 0.13); }
    let cd = 0; acts.push({ x: ox, z: oz, r: 3.4, label: () => cd > performance.now() ? '' : 'E  join the coffee ceremony', act: () => { cd = performance.now() + 60000; P.hp = Math.min(100, P.hp + 40); P.stam = 100; chime(); say('Buna', 'Three rounds of coffee: abol, tona, baraka. "Buna dabo naw: coffee is our bread." Health and stamina restored.'); } });
  }
  /* ---- livestock: zebu cattle, donkeys, chickens, camels (drylands) ---- */
  const lv = [], dry = altAt(cx, cz) < 1300 || VS === STY.afar || VS === STY.somali;
  const blockedAt = (nx, nz) => { if (heightAt(nx, nz) < 0.8) return true; for (const b of boxes) { const ddx = nx - b.x, ddz = nz - b.z; if (ddx * ddx + ddz * ddz > b.R2) continue; const lx = ddx * b.c - ddz * b.s, lz = ddx * b.s + ddz * b.c; if (Math.abs(lx) < b.hw + 0.7 && Math.abs(lz) < b.hd + 0.7) return true; } return false; };
  const mkLeg = (par, x, z, len, r, c) => { const l = new THREE.Group(); l.position.set(x, len, z); par.add(l); mesh(new THREE.CylinderGeometry(r, r * 0.7, len, 6).translate(0, -len / 2, 0), c, 0, 0, 0, l); mesh(new THREE.BoxGeometry(r * 1.6, r, r * 2), 0x1c1612, 0, -len + r * 0.4, r * 0.4, l); return l; };
  function mkLive(kind, hx, hz, rad) {
    const g = new THREE.Group(), legs = []; let spd = 0.7, leg = 0;
    if (kind === 'cow') {
      const c = [0x8a5a36, 0xe8e0d0, 0x2a221c, 0xb08a60, 0xd8c9a8][lv.length % 5], b = mesh(new THREE.SphereGeometry(1, 14, 10).scale(0.5, 0.48, 1.05), c, 0, 1.15, 0, g);
      mesh(new THREE.SphereGeometry(0.3, 10, 8), c, 0, 1.68, 0.42, g); mesh(new THREE.SphereGeometry(1, 10, 8).scale(0.24, 0.28, 0.42), c, 0, 1.28, 1.15, g); mesh(new THREE.BoxGeometry(0.1, 0.5, 0.1), c, 0, 1.4, 0.95, g).rotation.x = 0.7; mesh(new THREE.SphereGeometry(0.08, 6, 5), 0x1c1612, 0, 1.2, 1.55, g);
      for (const s of [-1, 1]) { mesh(new THREE.ConeGeometry(0.05, 0.55, 6), 0xe8dcc0, s * 0.2, 1.55, 1.1, g).rotation.z = -s * 0.9; mesh(new THREE.SphereGeometry(0.06, 6, 5).scale(1.6, 0.6, 1), c, s * 0.28, 1.4, 1.1, g); }
      mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.9, 5), c, 0, 0.8, -1.1, g).rotation.x = 0.1; mesh(new THREE.SphereGeometry(0.1, 6, 5), 0x1c1612, 0, 0.35, -1.12, g);
      for (const [x, z] of [[-0.25, 0.7], [0.25, 0.7], [-0.25, -0.7], [0.25, -0.7]]) legs.push(mkLeg(g, x, z, 0.8, 0.08, c)); spd = 0.55; leg = 0.8;
    } else if (kind === 'donkey') {
      const c = [0x8a8a86, 0x6a625a, 0xa8a49a][lv.length % 3];
      mesh(new THREE.SphereGeometry(1, 12, 9).scale(0.3, 0.34, 0.75), c, 0, 0.85, 0, g); mesh(new THREE.SphereGeometry(1, 10, 8).scale(0.18, 0.2, 0.32), 0xe0dccf, 0, 1.12, 0.95, g); mesh(new THREE.CylinderGeometry(0.1, 0.14, 0.5, 8), c, 0, 1.05, 0.65, g).rotation.x = -0.6;
      for (const s of [-1, 1]) mesh(new THREE.ConeGeometry(0.06, 0.4, 6), c, s * 0.1, 1.5, 0.82, g).rotation.z = -s * 0.2; mesh(new THREE.BoxGeometry(0.04, 0.04, 0.5), 0x2a221c, 0, 0.9, -0.85, g);
      mesh(new THREE.BoxGeometry(0.5, 0.2, 0.6), 0x8a2f2f, 0, 1.15, -0.05, g);
      for (const [x, z] of [[-0.14, 0.5], [0.14, 0.5], [-0.14, -0.5], [0.14, -0.5]]) legs.push(mkLeg(g, x, z, 0.62, 0.05, c)); spd = 0.8; leg = 0.7;
    } else if (kind === 'camel') {
      const c = 0xb89a68; mesh(new THREE.SphereGeometry(1, 12, 9).scale(0.42, 0.55, 1.0), c, 0, 1.6, 0, g); mesh(new THREE.SphereGeometry(0.34, 8, 6).scale(1, 1.2, 1), c, 0, 2.3, -0.1, g);
      mesh(new THREE.CylinderGeometry(0.12, 0.2, 1.3, 8), c, 0, 2.3, 0.95, g).rotation.x = -0.5; mesh(new THREE.SphereGeometry(1, 8, 6).scale(0.17, 0.2, 0.3), c, 0, 2.95, 1.45, g); mesh(new THREE.SphereGeometry(0.06, 6, 5), 0x1c1612, 0, 2.9, 1.75, g);
      mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.8, 5), c, 0, 1.3, -1.0, g); for (const [x, z] of [[-0.25, 0.7], [0.25, 0.7], [-0.25, -0.7], [0.25, -0.7]]) legs.push(mkLeg(g, x, z, 1.35, 0.08, c)); spd = 0.7; leg = 0.6;
    } else {   // chicken
      const c = [0xa8522a, 0xe8e0d0, 0x2a221c, 0xc9a050][lv.length % 4]; mesh(new THREE.SphereGeometry(1, 8, 6).scale(0.1, 0.12, 0.17), c, 0, 0.22, 0, g); mesh(new THREE.SphereGeometry(0.06, 6, 5), c, 0, 0.36, 0.12, g); mesh(new THREE.ConeGeometry(0.02, 0.06, 4).rotateX(Math.PI / 2), 0xe0a020, 0, 0.35, 0.2, g);
      mesh(new THREE.BoxGeometry(0.02, 0.05, 0.06), 0xd2202a, 0, 0.43, 0.12, g); mesh(new THREE.ConeGeometry(0.07, 0.2, 5).rotateX(-2.2), c, 0, 0.3, -0.18, g);
      for (const s of [-1, 1]) legs.push(mkLeg(g, s * 0.04, 0, 0.12, 0.012, 0xe0a020)); spd = 0.5; leg = 1.0;
    }
    g.position.set(hx, Hh(hx, hz), hz); scene.add(g); lv.push({ g, legs, x: hx, z: hz, yaw: rnd() * 6.28, t: rnd() * 4, mv: false, ph: rnd() * 6, home: [hx, hz], rad, spd, leg, kind });
    { const o = lv[lv.length - 1], T = { cow: [120, 1.15, 1.1, 0.8, 3], donkey: [80, 0.85, 0.9, 0.6, 2], camel: [140, 1.1, 1.8, 1.3, 3], hen: [15, 0.35, 0.25, 0.25, 1] }[kind]; o.hp = o.hp0 = T[0]; HIT.push({ o, r: T[1], cy: T[2], hh: T[3], drop: () => { P.inv.meat += T[4]; toast(kind[0].toUpperCase() + kind.slice(1) + ' down  +' + T[4] + ' meat', 2); } }); }
  }
  for (let k = 0; k < 5; k++) mkLive('cow', cx + 32 + rnd() * 10, cz - 24 + rnd() * 10, 18);
  for (let k = 0; k < 3; k++) mkLive('donkey', cx - 44 + rnd() * 6, cz + 2 + rnd() * 6, 12);
  for (let k = 0; k < 12; k++) mkLive('hen', cx + (rnd() - .5) * 56, cz + (rnd() > .5 ? 9 : -9) + rnd() * 3, 7);
  if (dry) for (let k = 0; k < 4; k++) mkLive('camel', cx - 30 + rnd() * 12, cz + 36 + rnd() * 8, 16);
  const NPC = document.createElement('div'); NPC.id = 'npcbox'; document.body.appendChild(NPC); let npcT = 0;
  function say(who, txt, s = 7) { NPC.innerHTML = '<b>' + who + '</b>' + txt; NPC.classList.add('on'); clearTimeout(npcT); npcT = setTimeout(() => NPC.classList.remove('on'), s * 1000); }
  const GREET = [['Selam!', 'Hello! Welcome to our village, traveller.'], ['Dehna metah?', 'Did you arrive safely? The road is long.'], ['Tena yistilign!', 'May health be given to you. Sit, rest a while.'], ['Buna tetu!', 'Come and drink coffee with us at the mat near the road.'], ['Ayzoh!', 'Be strong! The hyenas are bolder after dark. Keep a torch lit and sleep in a house.']];
  function talk(v) {
    const night = SU.uNight.value > 0.5, got = new Set(save.lm || []); let line;
    v.talks = (v.talks || 0) + 1;
    if (v.talks % 3 === 0) {   // a hint toward the nearest undiscovered heritage site
      let best = null, bd = 1e9; LM.forEach(([nm, la, lo], i) => { if (got.has(i)) return; const d = kmTo(la, lo); if (d < bd) { bd = d; best = nm; } });
      line = best ? ['Elders speak of a light that shines at ' + best + ', about ' + Math.round(bd) + ' km from here.', 'A hunter told me: the relic of ' + best + ' glows in the night. ' + Math.round(bd) + ' km away.'][v.id % 2] : 'You have found every relic. The whole land sings of you.';
    } else if (night) line = ['It is late. The spotted ones are hunting. The beds in the houses are safe.', 'Come to the fire! The drums keep the night away.'][v.id % 2];
    else { const g = GREET[(v.id + v.talks) % GREET.length]; line = '<i>' + g[0] + '</i>  ' + g[1]; }
    if (!v.gift && rnd() < 0.5) { v.gift = 1; if (rnd() < 0.5) { P.inv.herb++; line += '<br><i>She hands you a healing herb.</i>'; } else { P.ammo += 6; line += '<br><i>He gives you six arrows.</i>'; } chime(); }
    say(v.kid ? 'Child' : 'Villager', line);
  }
  vil.forEach(v => { const sc = v.sc || 1; v.hp = v.goat ? 40 : 70; HIT.push({ o: v, r: v.goat ? 0.65 : 0.5 * sc + 0.15, cy: v.goat ? 0.5 : 0.95 * sc, hh: v.goat ? 0.5 : 0.95 * sc }); });
  vil.forEach((v, i) => { if (v.goat) return; v.id = i; v.kid = v.sc < 0.8; acts.push({ get x() { return v.x; }, get z() { return v.z; }, r: 2.6, label: () => v.dead ? '' : 'E  talk', act: () => talk(v) }); });
  const lvTick = (dt, tw) => {
    const nt = SU.uNight.value, nearV = Math.hypot(P.x - cx, P.z - cz) < 90;
    for (const a of lv) {
      if (a.dead) { a.g.rotation.z = lerp(a.g.rotation.z, 1.5, Math.min(1, dt * 6)); a.g.position.y = Hh(a.x, a.z) + 0.1; if ((a.rt -= dt) < 0) { a.dead = false; a.hp = a.hp0; a.g.rotation.z = 0; } continue; }
      if (a.fl > 0) { a.fl -= dt; a.yaw = Math.atan2(a.x - P.x, a.z - P.z); a.mv = true; a.t = 1; }
      if ((a.t -= dt) < 0) { a.t = 1.5 + rnd() * 5; a.mv = rnd() < (a.kind === 'hen' ? 0.55 : 0.5); if (a.mv) a.yaw = Math.atan2(a.home[0] - a.x, a.home[1] - a.z) + (rnd() - .5) * 3.4 * (Math.hypot(a.home[0] - a.x, a.home[1] - a.z) > a.rad * 0.6 ? 0.4 : 1.2); }
      let sp = 0; if (a.mv) { sp = a.spd * (a.kind === 'hen' ? 1.6 : 1) * (a.fl > 0 ? 2.6 : 1); const nx = a.x + Math.sin(a.yaw) * sp * dt, nz = a.z + Math.cos(a.yaw) * sp * dt; if (!blockedAt(nx, nz)) { a.x = nx; a.z = nz; } else { a.t = 0; a.mv = false; sp = 0; } }
      a.ph += sp * dt * (a.kind === 'hen' ? 7 : 3.4); const sw = Math.sin(a.ph) * a.leg * (sp ? 1 : 0);
      a.legs.forEach((l, i) => l.rotation.x = sw * (i % 3 === 0 ? 1 : -1) * 0.6);
      a.g.position.set(a.x, Hh(a.x, a.z) + (sp ? Math.abs(Math.sin(a.ph)) * 0.02 : 0), a.z); a.g.rotation.y = lerp(a.g.rotation.y, a.yaw, Math.min(1, dt * 4));
      if (a.kind === 'hen' && !sp) a.g.rotation.x = Math.max(0, Math.sin(tw * 5 + a.ph * 3)) * 0.35 * (a.g.id % 2);
    }
    if (AC && nearV) { SNDT.cow -= dt; SNDT.hen -= dt; if (SNDT.cow < 0) { SNDT.cow = 14 + rnd() * 25; if (nt < 0.5) moo(); } if (SNDT.hen < 0) { SNDT.hen = 7 + rnd() * 14; if (nt < 0.5) cluck(); else if (rnd() < 0.2) rooster(); } }
  };
  const SNDT = { cow: 6, hen: 3 };
  function moo() { const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain(), f = AC.createBiquadFilter(); o.type = 'sawtooth'; f.type = 'lowpass'; f.frequency.value = 500; o.frequency.setValueAtTime(110, t); o.frequency.linearRampToValueAtTime(150, t + 0.5); o.frequency.linearRampToValueAtTime(95, t + 1.3); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.05, t + 0.3); g.gain.linearRampToValueAtTime(0, t + 1.4); o.connect(f).connect(g).connect(AC.destination); o.start(t); o.stop(t + 1.5); }
  function cluck() { for (let i = 0; i < 3; i++) { const t = AC.currentTime + i * 0.12, o = AC.createOscillator(), g = AC.createGain(); o.type = 'square'; o.frequency.setValueAtTime(520 + Math.random() * 120, t); o.frequency.exponentialRampToValueAtTime(260, t + 0.07); g.gain.setValueAtTime(0.012, t); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.09); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 0.1); } }
  function rooster() { const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain(); o.type = 'sawtooth'; o.frequency.setValueAtTime(500, t); o.frequency.linearRampToValueAtTime(900, t + 0.2); o.frequency.linearRampToValueAtTime(650, t + 0.5); o.frequency.linearRampToValueAtTime(820, t + 0.7); o.frequency.linearRampToValueAtTime(380, t + 1.1); g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.02, t + 0.1); g.gain.linearRampToValueAtTime(0, t + 1.15); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 1.2); }
  const vilTick = (dt, tw) => {
    lvTick(dt, tw);
    { const nt2 = SU.uNight.value, wd = Math.sin(tw * 0.2) * 0.4 + 1; for (const p of puffs) { p.t += dt * 0.16 * p.sp; if (p.t > 1) p.t -= 1; const t = p.t; p.s.position.set(p.x + t * t * 5 * wd, p.y + t * 7, p.z + t * 1.5); p.s.scale.setScalar(0.5 + t * 3.4); p.s.material.opacity = Math.sin(Math.PI * Math.min(1, t * 1.05)) * (0.3 + nt2 * 0.2); p.s.material.color.setScalar(0.72 - nt2 * 0.35); } }
    for (const v of vil) {
      if (v.dead) { v.g.rotation.z = lerp(v.g.rotation.z, 1.5, Math.min(1, dt * 6)); v.g.position.y = Hh(v.x, v.z) + 0.12; if ((v.rt -= dt) < 0) { v.dead = false; v.hp = v.goat ? 40 : 70; v.g.rotation.z = 0; } continue; }
      if (v.goat) { v.t -= dt; if (v.t < 0) { v.t = 2 + rnd() * 5; v.yaw = rnd() * 6.28; v.mv = rnd() < 0.5; } const gx = v.pen[0] - v.x, gz = v.pen[1] - v.z; if (v.mv) { const nx = v.x + Math.sin(v.yaw) * 0.5 * dt, nz = v.z + Math.cos(v.yaw) * 0.5 * dt; if (Math.hypot(nx - v.pen[0], nz - v.pen[1]) < 3.8) { v.x = nx; v.z = nz; } else v.yaw = Math.atan2(gx, gz); } v.g.position.set(v.x, Hh(v.x, v.z) + (v.mv ? Math.abs(Math.sin(tw * 6 + v.ph)) * 0.03 : 0), v.z); v.g.rotation.y = lerp(v.g.rotation.y, v.yaw - Math.PI / 2, 0.1); continue; }
      const dx = P.x - v.x, dz = P.z - v.z, dp = Math.hypot(dx, dz); let sp = 0;
      if (v.fl > 0) { v.fl -= dt; v.tx = v.flee[0]; v.tz = v.flee[1]; v.t = 0; }
      if (locked && dp < 5 && !(v.fl > 0)) { v.yaw = Math.atan2(dx, dz); }
      else { const ex = v.tx - v.x, ez = v.tz - v.z, ed = Math.hypot(ex, ez); if (v.t > 0) v.t -= dt; else if (ed < 1.5) { v.t = 2 + rnd() * 5; v.tx = cx + (rnd() - .5) * 64; v.tz = cz + (rnd() - .5) * 44; } else { v.yaw = Math.atan2(ex, ez); sp = v.sp * (v.fl > 0 ? 2.4 : 1); } }
      if (sp) { const nx = v.x + Math.sin(v.yaw) * sp * dt, nz = v.z + Math.cos(v.yaw) * sp * dt; let ok = true; for (const b of boxes) { const ddx = nx - b.x, ddz = nz - b.z; if (ddx * ddx + ddz * ddz > b.R2) continue; const lx = ddx * b.c - ddz * b.s, lz = ddx * b.s + ddz * b.c; if (Math.abs(lx) < b.hw + 0.4 && Math.abs(lz) < b.hd + 0.4 && !(b.off && b.off())) { ok = false; break; } } if (ok) { v.x = nx; v.z = nz; } else { v.t = 0.1; v.tx = cx + (rnd() - .5) * 64; v.tz = cz + (rnd() - .5) * 44; } }
      v.ph += sp * dt * 5; const sw = Math.sin(v.ph) * (sp ? 0.7 : 0); v.lL.rotation.x = sw; v.lR.rotation.x = -sw; v.aL.rotation.x = -sw * 0.6; v.aR.rotation.x = sw * 0.6;
      if (!sp) { v.aR.rotation.x = Math.sin(tw * 1.3 + v.ph) * 0.04; }
      v.g.position.set(v.x, Hh(v.x, v.z) + Math.abs(Math.sin(v.ph)) * 0.03, v.z); v.g.rotation.y = lerp(v.g.rotation.y, v.yaw, Math.min(1, dt * 6));
    }
    const nt = SU.uNight.value; lampM.color.setHSL(0.09, 1, 0.35 + 0.35 * nt);
    for (const f of flick) if (f.isLight) f.intensity = (0.4 + nt * 2.6) * (1 + 0.15 * Math.sin(tw * 17) + 0.1 * Math.sin(tw * 29)); else { f.scale.set(1, 1 + 0.2 * Math.sin(tw * 14), 1); f.rotation.y = tw * 3; }
  };
  const pr = document.createElement('div'); pr.id = 'vprompt'; pr.style.cssText = 'position:fixed;left:50%;top:62%;transform:translateX(-50%);padding:8px 18px;background:rgba(16,22,20,.65);color:#f2efe6;border-radius:8px;font-size:17px;display:none;pointer-events:none'; document.body.appendChild(pr);
  const hl = new THREE.PointLight(0xffc27a, 0, 16, 2); scene.add(hl); let cur = null;
  VCUR.get = () => cur;
  return (dt, tw) => {
    vilTick(dt, tw);
    glass.emissiveIntensity = SU.uNight.value * 1.4; glow.color.setHSL(0.07, 1, 0.5 + 0.06 * Math.sin(tw * 13));
    let best = null, bd = 1e9; for (const a of acts) { if (!a.label()) continue; const d = Math.hypot(P.x - a.x, P.z - a.z); if (d < a.r && d < bd) { best = a; bd = d; } }
    cur = locked ? best : null; pr.style.display = cur ? 'block' : 'none'; if (cur) pr.textContent = cur.label();
    for (const a of acts) if (a.door) { a.door.open = lerp(a.door.open, a.door.tgt, Math.min(1, dt * 5)); a.hinge.rotation.y = -a.door.open * 1.7; }
    let nh = null, nd = 1e9; for (const h of houses) { const d = Math.hypot(P.x - h.x, P.z - h.z); if (d < nd) { nd = d; nh = h; } }
    let tgt = 0; if (nh) { const dx = P.x - nh.x, dz = P.z - nh.z, lx = dx * nh.c - dz * nh.s, lz = dx * nh.s + dz * nh.c; hl.position.set(nh.x, heightAt(nh.x, nh.z) + nh.H - 0.8, nh.z); tgt = (Math.abs(lx) < nh.w / 2 && Math.abs(lz) < nh.d / 2) ? 2.4 : nd < 30 ? 0.5 : 0; }
    hl.intensity = lerp(hl.intensity, tgt, Math.min(1, dt * 4));
  };
}

/* ---------- valley mist ---------- */
function makeMist() {
  const c = document.createElement('canvas'); c.width = c.height = 128;
  const g = c.getContext('2d'), gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  gr.addColorStop(0, 'rgba(255,255,255,.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  const mat = new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthWrite: false, opacity: 0.25 }), half = Math.min(C.size * 0.42, 1700), white = new THREE.Color(1, 1, 1);
  for (let i = 0, t = 0; i < 160 && t < 6000; t++) {
    const x = (rnd() * 2 - 1) * half, z = (rnd() * 2 - 1) * half, h = heightAt(x, z);
    if (h > 9 || h < -12) continue;
    const sp = new THREE.Sprite(mat); sp.scale.set(90 + rnd() * 120, 18 + rnd() * 14, 1); sp.position.set(x, Math.max(h, 0) + 3 + rnd() * 5, z); scene.add(sp); i++;
  }
  return dayF => { mat.color.copy(sky).lerp(white, 0.35 * dayF); mat.opacity = 0.14 + 0.2 * (1 - dayF); };
}

/* ---------- wildlife ---------- */
function makeAnimals(sp) {
  const fc = document.createElement('canvas'); fc.width = fc.height = 128; const fx = fc.getContext('2d');
  fx.fillStyle = '#f2f2f2'; fx.fillRect(0, 0, 128, 128);
  for (let k = 0; k < 1000; k++) { const v = 170 + Math.random() * 85 | 0; fx.strokeStyle = 'rgba(' + v + ',' + v + ',' + v + ',.55)'; fx.lineWidth = 0.7 + Math.random(); const x = Math.random() * 128, y = Math.random() * 128; fx.beginPath(); fx.moveTo(x, y); fx.lineTo(x + (Math.random() - .5) * 4, y + 5 + Math.random() * 6); fx.stroke(); }
  const furT = new THREE.CanvasTexture(fc); furT.wrapS = furT.wrapT = THREE.RepeatWrapping; furT.repeat.set(3, 3); furT.encoding = THREE.sRGBEncoding; furT.anisotropy = 4;
  const furM = new THREE.MeshStandardMaterial({ vertexColors: true, map: furT, roughness: 1 });
  const darkM = new THREE.MeshStandardMaterial({ color: 0x14100d, roughness: 0.35 }), hoofM = new THREE.MeshStandardMaterial({ color: 0x1c1612, roughness: 0.6 }), eyeM = new THREE.MeshStandardMaterial({ color: 0x050403, roughness: 0.1 }), antM = new THREE.MeshStandardMaterial({ color: 0xcfc0a2, roughness: 0.8 });

  /* species definitions (metres). e0/e1/e2 = ear pose [pitch, spread] at rest / alert / fleeing */
  const SP = {
    deer: { label: 'Bushbuck', len: .78, bh: .27, bw: .19, up: .43, lo: .43, lr: .038, nL: .56, nR: .1, hr: .088, hl: 1.6, ear: 'oval', er: .065, el: .19, tail: 'short', nA: .75, hT: .4, nG: 2.7, hG: 1.45, shadow: true,
      walk: 1.3, run: 11.5, stride: [4.2, 1.45], bounce: .1, alert: 46, flee: 27, alertT: 2.5, grazeT: 14, range: 32, hp: 70, hitR: .85, hy: 1, hh: .8, meat: 2, pelt: 1, cr: .45, minH: 1.5, maxH: 1e4, rest: true, fearWolf: true, e0: [-.35, .75], e1: [.2, .3], e2: [-.1, .5] },
    rabbit: { label: 'Hare', len: .2, bh: .105, bw: .085, up: .1, lo: .09, lr: .02, nL: .07, nR: .05, hr: .048, hl: 1.2, ear: 'oval', er: .024, el: .13, tail: 'puff', nA: 1.0, hT: .5, nG: 1.5, hG: 1.3, shadow: false,
      walk: 1.0, run: 8.5, stride: [6, 2.6], bounce: .16, alert: 17, flee: 9, alertT: 1, grazeT: 9, range: 14, hp: 15, hitR: .4, hy: .22, hh: .3, meat: 1, pelt: 0, cr: .15, minH: 1.8, maxH: 1e4, hop: true, zig: true, sit: true, fearWolf: true, e0: [-.2, .25], e1: [.1, .12], e2: [-1.2, .1] },
    fox: { label: 'Ethiopian wolf', len: .4, bh: .14, bw: .1, up: .22, lo: .24, lr: .03, nL: .22, nR: .075, hr: .065, hl: 1.8, ear: 'cone', er: .045, el: .12, tail: 'bushy', nA: .95, hT: .25, nG: 1.9, hG: 1.2, shadow: true,
      walk: 1.8, run: 9.5, stride: [3.4, 1.6], bounce: .06, alert: 30, flee: 16, alertT: 1.8, grazeT: 8, range: 40, hp: 30, hitR: .5, hy: .45, hh: .4, meat: 1, pelt: 1, cr: .25, minH: 1.5, maxH: 1e4, e0: [-.1, .2], e1: [.25, .1], e2: [-.7, .15] }
  };
  const PAL = {
    deer: [{ top: 0x9a6a3c, bot: 0xd9c8a6, leg: 0x7d5632, muz: 0xdccdb2, sock: 0x5e4128, tip: 0xf2ece0 }, { top: 0x84562f, bot: 0xcdb99a, leg: 0x6a4527, muz: 0xcfc0a6, sock: 0x4a331f, tip: 0xeee6d6 }, { top: 0xae814e, bot: 0xe2d4b6, leg: 0x8a6438, muz: 0xe4d8c0, sock: 0x6a4b2c, tip: 0xf5f0e4 }],
    rabbit: [{ top: 0x8c7b66, bot: 0xe9e2d4, leg: 0x8c7b66, muz: 0xd6cdbd, sock: 0x7a6a58, tip: 0xf4f0e8 }, { top: 0xa99a86, bot: 0xeee8dc, leg: 0xa99a86, muz: 0xddd5c6, sock: 0x8a7c6a, tip: 0xf4f0e8 }, { top: 0x5a4d40, bot: 0xb8aa98, leg: 0x5a4d40, muz: 0x8a7c6a, sock: 0x40362c, tip: 0xe8e2d6 }],
    fox: [{ top: 0xc4591f, bot: 0xf1e6d6, leg: 0xb04a18, muz: 0xf1e6d6, sock: 0x1c1410, tip: 0xf6f0e6 }, { top: 0xb4501c, bot: 0xeadfce, leg: 0xa24416, muz: 0xeadfce, sock: 0x1c1410, tip: 0xf2ece0 }]
  };
  const WP = [0, Math.PI, Math.PI, 0], BP = [0, .3, Math.PI * .95, Math.PI * .95 + .3];
  const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

  const shade = (g, top, bot) => {
    const p = g.attributes.position; g.computeBoundingBox(); const b = g.boundingBox, hh = (b.max.y - b.min.y) || 1, c = new THREE.Color(), t0 = new THREE.Color(top), t1 = new THREE.Color(bot), col = new Float32Array(p.count * 3);
    for (let i = 0; i < p.count; i++) { const t = (p.getY(i) - b.min.y) / hh; c.copy(t1).lerp(t0, sm(0.25, 0.65, t)); const j = 0.93 + h2(i, 11) * 0.14; col[i * 3] = c.r * j; col[i * 3 + 1] = c.g * j; col[i * 3 + 2] = c.b * j; }
    g.setAttribute('color', new THREE.BufferAttribute(col, 3)); return g;
  };
  const ell = (rx, ry, rz, top, bot, ws = 14, hs = 10) => shade(new THREE.SphereGeometry(1, ws, hs).scale(rx, ry, rz), top, bot);
  const antlerG = (() => {
    const V = a => new THREE.Vector3(a[0], a[1], a[2]), tube = (pts, r) => new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(V)), 8, r, 5, false);
    return mergeG([tube([[0, 0, 0], [.03, .14, -.04], [.08, .28, -.06], [.1, .42, 0], [.07, .55, .1]], .016), tube([[.03, .14, -.04], [.05, .22, .04], [.05, .3, .12]], .011), tube([[.08, .28, -.06], [.13, .36, -.02], [.16, .46, .04]], .011), tube([[.1, .42, 0], [.12, .5, .06], [.1, .6, .1]], .009)]);
  })();

  function build(s, col, stag) {
    const root = new THREE.Group(), body = new THREE.Group(), torso = new THREE.Group(); root.add(body); body.add(torso);
    const sh = s.shadow, mesh = (g, m, x, y, z, par) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); o.castShadow = sh; par.add(o); return o; };
    const H = s.up + s.lo, cy = H + s.bh * 0.6, top = col.top, bot = col.bot, F = (g, x, y, z, par) => mesh(g, furM, x, y, z, par);
    F(ell(s.bw, s.bh, s.len * 0.78, top, bot), 0, cy, 0, torso);
    F(ell(s.bw * 0.96, s.bh * 1.08, s.len * 0.46, top, bot), 0, cy + s.bh * 0.06, s.len * 0.42, torso);
    F(ell(s.bw, s.bh * 1.02, s.len * 0.5, top, bot), 0, cy + s.bh * 0.02, -s.len * 0.42, torso);
    for (const sd of [-1, 1]) F(ell(s.bw * 0.45, s.up * 0.62, s.len * 0.32, top, col.leg), sd * s.bw * 0.7, H - s.up * 0.1, -s.len * 0.5, torso);
    /* neck + head */
    const neck = new THREE.Group(); neck.rotation.order = 'YXZ'; neck.position.set(0, cy + s.bh * 0.35, s.len * 0.78); torso.add(neck);
    F(shade(new THREE.CylinderGeometry(s.nR * 0.72, s.nR, s.nL, 10).translate(0, s.nL / 2, 0), top, top), 0, 0, 0, neck);
    const head = new THREE.Group(); head.position.set(0, s.nL, 0); neck.add(head); const hr = s.hr;
    F(ell(hr * 0.88, hr, hr * 1.25, top, top), 0, 0, 0, head);
    F(ell(hr * 0.55, hr * 0.5, hr * s.hl * 0.55, col.muz, col.muz, 10, 8), 0, -hr * 0.22, hr * 0.85 + hr * s.hl * 0.35, head);
    mesh(new THREE.SphereGeometry(hr * 0.2, 8, 6).scale(1.1, 0.8, 0.8), darkM, 0, -hr * 0.1, hr * 0.85 + hr * s.hl * 0.9, head);
    const eyeG = new THREE.SphereGeometry(hr * 0.17, 8, 6), ears = [];
    for (const sd of [-1, 1]) {
      mesh(eyeG, eyeM, sd * hr * 0.78, hr * 0.22, hr * 0.5, head);
      const p = new THREE.Group(); p.position.set(sd * hr * 0.5, hr * 0.8, -hr * 0.25); head.add(p);
      const eg = s.ear === 'cone' ? new THREE.ConeGeometry(s.er, s.el, 6).translate(0, s.el / 2, 0) : new THREE.SphereGeometry(1, 8, 6).scale(s.er, s.el * 0.5, s.er * 0.3).translate(0, s.el * 0.5, 0);
      F(shade(eg, top, top), 0, 0, 0, p); ears.push({ p, side: sd, bz: 0 });
      if (stag) { const m = mesh(antlerG, antM, sd * hr * 0.5, hr * 0.85, -hr * 0.2, head); m.scale.set(sd * 1.25, 1.25, 1.25); m.rotation.x = -0.35; m.rotation.z = -sd * 0.25; m.castShadow = false; }
    }
    /* tail */
    const tail = new THREE.Group(); tail.position.set(0, cy + s.bh * 0.45, -s.len * 0.9); torso.add(tail);
    if (s.tail === 'short') F(ell(.05, .09, .04, col.tip, col.tip), 0, -.04, -.04, tail);
    else if (s.tail === 'puff') F(ell(.055, .055, .055, col.tip, col.tip), 0, 0, -.03, tail);
    else { F(ell(.07, .07, .3, top, top), 0, -.02, -.26, tail); F(ell(.062, .062, .1, col.tip, col.tip), 0, -.02, -.52, tail); tail.rotation.x = -0.35; }
    /* jointed legs */
    const legs = [];
    [[1, 1], [-1, 1], [1, -1], [-1, -1]].forEach(([sx, fz]) => {
      const front = fz > 0, hip = new THREE.Group(), lr = s.lr * (front ? 1 : 1.12); hip.position.set(sx * s.bw * 0.7, H, fz * s.len * 0.5); body.add(hip);
      F(shade(new THREE.CylinderGeometry(lr * 1.25, lr * 0.8, s.up, 8).translate(0, -s.up / 2, 0), top, col.leg), 0, 0, 0, hip);
      const knee = new THREE.Group(); knee.position.y = -s.up; hip.add(knee);
      F(ell(lr * 0.85, lr * 0.85, lr * 0.85, col.leg, col.leg, 8, 6), 0, 0, 0, knee);
      F(shade(new THREE.CylinderGeometry(lr * 0.75, lr * 0.55, s.lo, 8).translate(0, -s.lo / 2, 0), col.leg, col.sock), 0, 0, 0, knee);
      const hh = lr * 1.4; mesh(new THREE.CylinderGeometry(lr * 0.6, lr * 0.72, hh, 7), hoofM, 0, -s.lo + hh / 2, 0, knee);
      legs.push({ hip, knee, front });
    });
    return { root, body, torso, neck, head, tail, ears, legs };
  }

  /* ---- world: place / collide / steer ---- */
  const treeNear = (x, z, r) => { const cx = Math.floor(x / CELL), cz = Math.floor(z / CELL); for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) { const l = grid.get((cx + i) + ',' + (cz + j)); if (!l) continue; for (const c of l) { const dx = x - c[0], dz = z - c[1], rr = r + c[2]; if (dx * dx + dz * dz < rr * rr) return true; } } return false; };
  const pushOut = a => { const r0 = a.s.cr * a.sc, cx = Math.floor(a.x / CELL), cz = Math.floor(a.z / CELL); for (let i = -1; i <= 1; i++) for (let j = -1; j <= 1; j++) { const l = grid.get((cx + i) + ',' + (cz + j)); if (!l) continue; for (const [x, z, r] of l) { const dx = a.x - x, dz = a.z - z, rr = r + r0, d2 = dx * dx + dz * dz; if (d2 < rr * rr && d2 > 1e-6) { const d = Math.sqrt(d2); a.x = x + dx / d * rr; a.z = z + dz / d * rr; } } } };
  const valid = (a, nx, nz) => { const s = a.s, h = heightAt(nx, nz); return h > s.minH && h < s.maxH && !inSite(nx, nz) && h - a.gy < 0.8 && !treeNear(nx, nz, s.cr * a.sc * 0.8); };
  const steer = (a, want, look) => { for (const o of [0, .45, -.45, .9, -.9, 1.5, -1.5, 2.4]) { const y = want + o; if (valid(a, a.x + Math.sin(y) * look, a.z + Math.cos(y) * look)) return y; } return want + 2.8; };
  const place = (cx, cz, spread, s) => { for (let t = 0; t < 80; t++) { const x = cx + (rnd() * 2 - 1) * spread, z = cz + (rnd() * 2 - 1) * spread, h = heightAt(x, z); if (h > s.minH + 1 && h < s.maxH && !inSite(x, z) && Math.abs(heightAt(x + 3, z) - h) < 1.5 && Math.abs(heightAt(x, z + 3) - h) < 1.5) return [x, z]; } return null; };

  const list = [];
  function panic(a) {
    a.st = 'flee'; a.t = 3.5 + rnd() * 3; a.up = false;
    if (a.herd) for (const m of a.herd.members) if (m !== a && !m.dead && m.st !== 'flee' && Math.hypot(m.x - a.x, m.z - a.z) < 70) { m.st = 'flee'; m.t = 3 + rnd() * 3; }
  }
  function toGraze(a) { a.st = 'graze'; a.retreat = false; a.t = a.s.grazeT * (0.6 + rnd() * 0.8); a.lt = 2 + rnd() * 3; a.up = false; }
  function pickWalk(a) {
    const s = a.s; let tx = a.x, tz = a.z;
    for (let k = 0; k < 8; k++) { const an = a.yaw + (rnd() - .5) * 3, r = s.range * (0.4 + rnd() * 0.6), x = a.x + Math.sin(an) * r, z = a.z + Math.cos(an) * r, h = heightAt(x, z); tx = x; tz = z; if (h > s.minH + 0.3 && h < s.maxH && !inSite(x, z)) break; }
    a.tx = tx; a.tz = tz; a.st = 'walk'; a.t = 14; a.retreat = false;
  }
  function respawn(a) {
    const s = a.s;
    for (let t = 0; t < 40; t++) {
      const x = clamp(P.x + (rnd() * 2 - 1) * 700, -C.size * 0.45, C.size * 0.45), z = clamp(P.z + (rnd() * 2 - 1) * 700, -C.size * 0.45, C.size * 0.45), h = heightAt(x, z);
      if (Math.hypot(x - P.x, z - P.z) > 130 && h > s.minH + 1 && h < s.maxH && !inSite(x, z)) { a.x = x; a.z = z; a.hp = s.hp; a.dead = false; a.herd = null; a.st = 'graze'; a.t = 3; a.v = 0; a.fall = 0; a.root.rotation.z = 0; a.root.visible = true; return; }
    }
    a.rt = 6;
  }
  function make(sk, x, z, herd) {
    const s = SP[sk], pal = PAL[sk][Math.floor(rnd() * PAL[sk].length)], stag = sk === 'deer' && rnd() < 0.3, sc = (stag ? 1.1 : 1) * (0.92 + rnd() * 0.16), b = build(s, pal, stag);
    b.root.scale.setScalar(sc); b.root.visible = false; scene.add(b.root);
    const a = Object.assign(b, { s, sk, x, z, yaw: rnd() * 6.28, v: 0, st: 'graze', t: 2 + rnd() * 6, lt: 2 + rnd() * 4, up: false, tx: x, tz: z, herd, ph: rnd() * 6.28, gz: 0, al: 0, lie: 0, gr: 0, hp: s.hp, dead: false, rt: 0, sc, pit: 0, rol: 0, look: 0, lookT: 0, et: rnd() * 4, fl: 0, fs: 1, id: list.length, calm: 0, retreat: false, sT: 0, dir: 0, gy: 0, hitR: s.hitR * sc, hy: s.hy * sc, hh: s.hh * sc, fall: 0, dtm: 0 });
    a.dir = a.yaw;
    a.hurt = dmg => {
      if (a.dead) return; a.hp -= dmg;
      if (a.hp <= 0) { a.dead = true; a.fall = 0; a.dtm = 0; a.rt = 45 + rnd() * 40; P.inv.meat += s.meat; P.inv.pelt += s.pelt; toast(s.label + ' down  +' + s.meat + ' meat' + (s.pelt ? ', +1 pelt' : ''), 2.2); step('rock', 0.4); }
      else { panic(a); step('rock', 0.3); }
    };
    list.push(a); if (herd) herd.members.push(a); return a;
  }
  for (let k = 0; k < 4; k++) {
    const c = place(sp[0], sp[2], 270, SP.deer); if (!c) continue; const herd = { members: [], leader: null }, n = 3 + (rnd() * 3 | 0);
    for (let i = 0; i < n; i++) { const p = place(c[0], c[1], 10, SP.deer) || c; make('deer', p[0], p[1], herd); }
    herd.leader = herd.members[0];
  }
  for (let k = 0; k < 16; k++) { const c = place(sp[0], sp[2], 290, SP.rabbit); if (c) make('rabbit', c[0], c[1], null); }
  for (let k = 0; k < 4; k++) { const c = place(sp[0], sp[2], 290, SP.fox); if (c) make('fox', c[0], c[1], null); }
  P.fauna = list;

  let T = 0;
  return dt => {
    T += dt; const nt = SU.uNight.value;
    for (const a of list) {
      const s = a.s;
      if (a.dead) {
        a.dtm += dt; a.fall = Math.min(1, a.fall + dt * 2.2); a.root.rotation.z = (1 - Math.pow(1 - a.fall, 3)) * 1.5; a.root.position.set(a.x, heightAt(a.x, a.z), a.z);
        if (a.dtm > 20) a.root.visible = false;
        if ((a.rt -= dt) < 0) respawn(a);
        continue;
      }
      const dx = P.x - a.x, dz = P.z - a.z, d = Math.hypot(dx, dz) + 1e-6;
      if (d > 320) { a.root.visible = false; continue; }
      a.root.visible = d < 210; a.gy = heightAt(a.x, a.z);
      const h = a.herd; if (h && (!h.leader || h.leader.dead)) h.leader = h.members.find(m => !m.dead) || null;
      const lead = h && h.leader !== a ? h.leader : null;
      const sprint = keys.ShiftLeft && Math.hypot(P.vx, P.vz) > C.walk * 1.2;
      const stealth = (keys.KeyC ? 0.55 : 1) * (sprint ? 1.45 : 1) * (1 - nt * 0.2) * (a.st === 'rest' ? 0.65 : 1), det = s.alert * stealth, flr = s.flee * stealth;
      a.t -= dt; a.calm -= dt; a.lt -= dt;
      let thr = null;
      if (s.fearWolf && P.wolves) for (const w of P.wolves) if (!w.dead && Math.hypot(w.x - a.x, w.z - a.z) < s.flee * 1.2) { thr = w; break; }
      if (thr && a.st !== 'flee') panic(a);
      else if (locked && a.calm <= 0 && d < det && (a.st === 'graze' || a.st === 'walk' || a.st === 'rest')) { a.st = 'alert'; a.t = s.alertT * (0.7 + rnd() * 0.8); }

      let want = a.yaw, vt = 0, face = false;
      switch (a.st) {
        case 'alert':
          face = true; want = Math.atan2(dx, dz);
          if (d < flr) panic(a);
          else if (a.t <= 0) { if (d < det) { const aw = Math.atan2(-dx, -dz); a.st = 'walk'; a.calm = 7; a.retreat = true; a.tx = a.x + Math.sin(aw) * 22; a.tz = a.z + Math.cos(aw) * 22; a.t = 8; } else toGraze(a); }
          break;
        case 'walk': {
          if (lead) { const an = a.id * 2.1, r = 3 + (a.id % 4) * 1.4; a.tx = lead.x + Math.sin(an) * r; a.tz = lead.z + Math.cos(an) * r; }
          const ex = a.tx - a.x, ez = a.tz - a.z, ed = Math.hypot(ex, ez);
          want = Math.atan2(ex, ez); vt = (a.retreat ? 1.5 : 1) * s.walk; if (lead && ed > 14) vt *= 1.8;
          if (ed < 1.8 || (!lead && a.t <= 0)) { if (lead && lead.st === 'walk') vt = 0; else toGraze(a); }
          break; }
        case 'graze':
          if (a.lt <= 0) { a.up = !a.up; a.lt = a.up ? 1.5 + rnd() * 2.5 : 4 + rnd() * 6; a.lookT = a.up ? (rnd() - .5) * 1.6 : 0; }
          if (lead && (lead.st === 'walk' || Math.hypot(lead.x - a.x, lead.z - a.z) > 24)) { a.st = 'walk'; a.t = 14; a.retreat = false; }
          else if (nt > 0.6 && s.rest && a.id % 3 && a.t < s.grazeT * 0.6) { a.st = 'rest'; a.t = 20 + rnd() * 30; }
          else if (a.t <= 0) pickWalk(a);
          break;
        case 'rest':
          if (nt < 0.35 || a.t <= 0) { a.st = 'graze'; a.t = 5; a.lt = 3; }
          break;
        case 'flee': {
          let aw = Math.atan2(-dx, -dz);
          if (thr) { const wa = Math.atan2(a.x - thr.x, a.z - thr.z); aw = Math.atan2(Math.sin(aw) + Math.sin(wa), Math.cos(aw) + Math.cos(wa)); }
          if (s.zig) aw += Math.sin(T * 2.6 + a.id * 3.1) * 0.9;
          want = aw; vt = s.run;
          if (a.t <= 0) { if (d > det * 1.25 && !thr) { a.st = 'walk'; a.calm = 8; a.retreat = true; a.tx = a.x + Math.sin(aw) * 20; a.tz = a.z + Math.cos(aw) * 20; a.t = 8; } else a.t = 1.5; }
          break; }
      }
      /* heading + movement */
      const moving = vt > 0;
      if (face) a.dir = want; else if (moving) { if ((a.sT -= dt) <= 0) { a.sT = 0.18; a.dir = steer(a, want, 2.2 * a.sc + vt * 0.3); } } else a.dir = a.yaw;
      if (moving || face) { const rate = a.st === 'flee' ? 5 : face ? 3.5 : 2.4; a.yaw += clamp(wrap(a.dir - a.yaw), -rate * dt, rate * dt); }
      if (s.hop) { if (moving) a.ph += dt * (a.st === 'flee' ? 10 : 5.5); a.v = moving ? vt * clamp(0.2 + Math.max(0, Math.sin(a.ph)) * 1.2, 0, 1.2) : 0; }
      else { a.v = lerp(a.v, vt, Math.min(1, dt * (vt > a.v ? 3 : 6))); if (a.v < 0.03 && !moving) a.v = 0; a.ph += lerp(s.stride[0], s.stride[1], a.gr) * a.v * dt; }
      if (a.v > 0.02) { const nx = a.x + Math.sin(a.yaw) * a.v * dt, nz = a.z + Math.cos(a.yaw) * a.v * dt; if (valid(a, nx, nz)) { a.x = nx; a.z = nz; } else { a.v = 0; if (a.st === 'walk') a.t = 0; } }
      pushOut(a);
      if (!a.root.visible) continue;

      /* animation */
      const k8 = Math.min(1, dt * 8), L = s.len * a.sc, ys = Math.sin(a.yaw), yc = Math.cos(a.yaw), sw2 = s.bw * a.sc * 1.5;
      const hf = heightAt(a.x + ys * L, a.z + yc * L), hb = heightAt(a.x - ys * L, a.z - yc * L), hl = heightAt(a.x + yc * sw2, a.z - ys * sw2), hrr = heightAt(a.x - yc * sw2, a.z + ys * sw2);
      a.pit = lerp(a.pit, Math.atan2(hf - hb, 2 * L), k8); a.rol = lerp(a.rol, Math.atan2(hl - hrr, 2 * sw2), k8);
      a.root.position.set(a.x, heightAt(a.x, a.z), a.z); a.root.rotation.y = a.yaw;
      a.gz = lerp(a.gz, a.st === 'graze' && !a.up ? 1 : 0, Math.min(1, dt * 3));
      a.al = lerp(a.al, a.st === 'alert' ? 1 : a.st === 'flee' ? 0.5 : (a.st === 'graze' && a.up) ? 0.6 : 0, k8);
      a.lie = lerp(a.lie, a.st === 'rest' ? 1 : 0, Math.min(1, dt * 1.5));
      a.gr = lerp(a.gr, a.v > s.walk * 1.9 ? 1 : 0, Math.min(1, dt * 6));
      const gm = s.hop ? 1 : a.gr, amp = clamp(a.v / (s.walk * 0.8), 0, 1), lie = a.lie;
      for (let i = 0; i < 4; i++) {
        const l = a.legs[i], f = l.front, q = a.ph + lerp(WP[i], BP[i], gm), swg = Math.sin(q) * lerp(0.42, 0.8, gm) * amp, lift = Math.max(0, -Math.cos(q)) * lerp(0.9, 1.3, gm) * amp;
        let hx = swg + (f ? 0 : -0.15), kx = lift + (f ? 0.04 : 0.32);
        if (lie > 0.001) { hx = lerp(hx, f ? -1.35 : -1.0, lie); kx = lerp(kx, f ? 2.5 : 2.3, lie); }
        l.hip.rotation.x = hx; l.knee.rotation.x = kx;
      }
      const bob = gm > 0.5 ? Math.max(0, Math.sin(a.ph + 1.3)) * s.bounce * amp : Math.sin(a.ph * 2) * 0.012 * amp;
      a.body.position.y = -(s.up + s.lo) * 0.72 * lie + bob; a.body.rotation.x = -a.pit; a.body.rotation.z = a.rol;
      a.torso.rotation.x = Math.cos(a.ph) * 0.07 * gm * amp - (s.sit ? 0.5 * a.al : 0) + 0.1 * a.gz; a.torso.scale.y = 1 + 0.012 * Math.sin(T * 2.2 + a.id);
      const nA = lerp(lerp(s.nA, s.nG, a.gz), s.nA - 0.28, a.al * (1 - a.gz)) + Math.sin(a.ph) * 0.05 * amp * (1 - a.gz), hT = lerp(lerp(s.hT, s.hG, a.gz), s.hT - 0.22, a.al * (1 - a.gz));
      a.neck.rotation.x = nA; a.head.rotation.x = hT - nA;
      if (a.st === 'alert') a.lookT = clamp(wrap(Math.atan2(dx, dz) - a.yaw), -1.1, 1.1); else if (a.st !== 'graze') a.lookT = 0;
      a.look = lerp(a.look, a.lookT, Math.min(1, dt * 4)); a.neck.rotation.y = a.look;
      if ((a.et -= dt) <= 0) { a.et = 2 + rnd() * 5; a.fl = 0.3; a.fs = rnd() < .5 ? -1 : 1; } a.fl = Math.max(0, a.fl - dt);
      const et = a.st === 'flee' ? s.e2 : a.al > 0.4 ? s.e1 : s.e0;
      for (const e of a.ears) { e.p.rotation.x = lerp(e.p.rotation.x, et[0], k8); e.bz = lerp(e.bz, -e.side * et[1], k8); e.p.rotation.z = e.bz + (e.side === a.fs ? Math.sin(a.fl * 50) * a.fl * 1.1 : 0); }
      if (s.tail === 'bushy') { a.tail.rotation.y = Math.sin(T * 2.2 + a.id) * 0.25 * (0.3 + amp); a.tail.rotation.x = -0.35 + (a.st === 'flee' ? 0.3 : 0); }
      else a.tail.rotation.x = lerp(a.tail.rotation.x, a.st === 'flee' ? 1.1 : 0.2, k8) + (a.st === 'graze' ? Math.sin(T * 5 + a.id) * 0.02 : 0);
    }
  };
}

/* ---------- gameplay: relics, survival, minimap, weather, ambience ---------- */
const SENS = C.sens || 0.0022;
const $t = $('toast'), hurtEl = $('hurt');
let toastT = 0, hurtV = 0;
function toast(m, s = 3.2) { $t.textContent = m; $t.className = 'on'; clearTimeout(toastT); toastT = setTimeout(() => $t.className = '', s * 1000); }
const fmt = t => Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0');
const SAVE = 'highland-reach-' + C.seed;
function safeJsonParse(raw) { try { return raw ? JSON.parse(raw) : {}; } catch (e) { return {}; } }
let save = safeJsonParse(localStorage.getItem(SAVE));
const store = () => { try { localStorage.setItem(SAVE, JSON.stringify(save)); } catch (e) {} };
const resetSave = () => {
  save = { best: save.best || undefined };
  try { localStorage.removeItem(SAVE); } catch (e) {}
  store();
  toast('Run data cleared. Start a fresh journey.', 2.5);
};
P.hp = 100; P.time = save.time || 0; P.last = 0; P.won = false; P.saveT = 0;

function hurt(n) { P.hp -= n; P.last = 0; hurtV = Math.min(1, hurtV + n / 40 + 0.3); P.shake = 0.12; }
function hurtFall(v) { const d = (-v - 14) * 5; if (d > 0) { hurt(d); step('rock', 0.5); } }
function survival(dt) {
  P.last += dt;
  if (P.swim) { P.stam = Math.max(0, P.stam - 16 * dt); if (P.stam <= 0) hurt(5 * dt); }
  else if (P.last > 6 && P.hp < 100) P.hp = Math.min(100, P.hp + (inSite(P.x, P.z) ? 10 : 3) * dt);
  hurtV = Math.max(0, hurtV - dt * 0.6); hurtEl.style.opacity = hurtV;
  if (P.hp <= 0) { P.hp = 100; P.x = P.home[0]; P.y = P.home[1] + 1; P.z = P.home[2]; P.vx = P.vy = P.vz = 0; P.stam = 100; toast('You collapsed. Back at camp.'); }
  $('hp').style.width = Math.max(0, P.hp) + '%';
  if ((P.saveT += dt) > 10) { P.saveT = 0; save.time = P.time; save.inv = P.inv; store(); }
}

function chime() {
  if (!AC) return;
  [660, 880, 1320].forEach((f, i) => {
    const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime + i * 0.09;
    o.frequency.value = f; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.08, t + 0.02); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.9);
    o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 1);
  });
}
const LM = [['Lalibela rock churches', 12.0316, 39.0473], ['Aksum obelisks', 14.1217, 38.7188], ['Gondar castles', 12.607, 37.47], ['Simien: Ras Dejen', 13.2417, 38.3694], ['Blue Nile Falls', 11.4896, 37.5909],
  ['Harar Jugol', 9.3115, 42.123], ['Entoto hill, Addis Ababa', 9.083, 38.762], ['Bale: Sanetti plateau', 6.8667, 39.7667], ['Dallol salt desert', 14.2416, 40.2997], ['Konso hills', 5.25, 37.43]];
const llOf = (x, z) => { const R = C.real; return R ? [R.lat - z / 111320, R.lon + x / (111320 * Math.cos(R.lat * Math.PI / 180))] : [0, 0]; };
const xzOf = (lat, lon) => { const R = C.real; return [(lon - R.lon) * 111320 * Math.cos(R.lat * Math.PI / 180), -(lat - R.lat) * 111320]; };
const kmTo = (la, lo) => { const [a, b] = llOf(P.x, P.z), dx = (lo - b) * 111.32 * Math.cos(a * Math.PI / 180), dy = (la - a) * 111.32; return Math.hypot(dx, dy); };
function makeRelics(sp) {
  const list = [], pts = [], total = REAL ? LM.length : (C.relics || 10);
  const gc = document.createElement('canvas'); gc.width = gc.height = 64;
  const gg = gc.getContext('2d'), gr = gg.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(140,255,240,1)'); gr.addColorStop(1, 'rgba(140,255,240,0)'); gg.fillStyle = gr; gg.fillRect(0, 0, 64, 64);
  const glow = new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(gc), blending: THREE.AdditiveBlending, transparent: true, depthWrite: false, fog: false });
  const gem = new THREE.OctahedronGeometry(0.45).scale(1, 1.7, 1);
  const gm = new THREE.MeshStandardMaterial({ color: 0x7ff5e6, emissive: 0x30d8c8, emissiveIntensity: 1.6, roughness: 0.15, metalness: 0.4 });
  const beamG = new THREE.CylinderGeometry(0.12, 0.12, 70, 8, 1, true).translate(0, 35, 0);
  const beamM = new THREE.MeshBasicMaterial({ color: 0x66f0e0, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
  const lim = C.size * 0.47;
  if (REAL) {   // each relic sits on a real Ethiopian heritage site; it appears when you are in that part of the country
    LM.forEach(([name, la, lo], id) => {
      let [x, z] = xzOf(la, lo); if (Math.abs(x) > lim || Math.abs(z) > lim) return;
      for (let r = 0; r < 80; r += 4) { let ok = false; for (let k = 0; k < 8 && !ok; k++) { const px = x + Math.cos(k) * r, pz = z + Math.sin(k) * r; if (heightAt(px, pz) > 0.8 && !inSite(px, pz)) { x = px; z = pz; ok = true; } } if (ok) break; }
      pts.push([x, z, heightAt(x, z), id, name]);
    });
  } else {
    const far = (x, z, m) => pts.every(p => Math.hypot(p[0] - x, p[1] - z) > m);
    for (let t = 0; t < 8000 && pts.length < total; t++) {
      const x = (rnd() * 2 - 1) * C.size * 0.4, z = (rnd() * 2 - 1) * C.size * 0.4, h = heightAt(x, z), d = Math.hypot(x - sp[0], z - sp[2]);
      if (h < 2.5 || h > 48 || inSite(x, z) || d < 120 || (!pts.length && d > 380) || !far(x, z, 170)) continue;
      if (Math.abs(heightAt(x + 2, z) - h) > 1.2 || Math.abs(heightAt(x, z + 2) - h) > 1.2) continue;
      pts.push([x, z, h, pts.length, 'Relic']);
    }
  }
  const gotIds = () => save.lm || [];
  pts.forEach(p => {
    const g = new THREE.Group(); g.position.set(p[0], p[2], p[1]);
    const m = new THREE.Mesh(gem, gm); m.position.y = 1.6; m.castShadow = true; g.add(m);
    const s = new THREE.Sprite(glow); s.scale.set(5, 5, 1); s.position.y = 1.6; g.add(s, new THREE.Mesh(beamG, beamM));
    const got = gotIds().includes(p[3]); g.visible = !got; scene.add(g); list.push({ g, m, x: p[0], z: p[1], got, id: p[3], name: p[4] });
  });
  P.relics = list; let shown = '';
  const goal = () => {
    const n = new Set(gotIds()).size; P.won = n === total;
    let s = P.won ? 'All relics found  ' + fmt(P.time) : 'Relics ' + n + ' / ' + total + '   ' + fmt(P.time);
    if (REAL && !P.won) { let best = null, bd = 1e9; LM.forEach(([nm, la, lo], i) => { if (gotIds().includes(i)) return; const d = kmTo(la, lo); if (d < bd) { bd = d; best = nm; } }); if (best) s += '\nNearest: ' + best + ', ' + (bd < 10 ? bd.toFixed(1) : Math.round(bd)) + ' km'; }
    if (s !== shown) { shown = s; $('goal').textContent = s; }
  };
  goal();
  return (dt, t) => {
    for (const r of list) {
      if (r.got) continue;
      r.m.rotation.y = t * 1.2; r.m.position.y = 1.6 + Math.sin(t * 2 + r.x) * 0.15;
      if (Math.hypot(P.x - r.x, P.z - r.z) < 2.4 && Math.abs(P.y - r.g.position.y) < 4) {
        r.got = true; r.g.visible = false; chime(); P.ammo += 5;
        save.lm = Array.from(new Set([...gotIds(), r.id])); save.time = P.time;
        const n = save.lm.length;
        if (n === total) { const nb = P.time < (save.best || 1e9); save.best = Math.min(save.best || 1e9, P.time); toast('All relics found in ' + fmt(P.time) + (nb ? ' (new best!)' : '') + '. Press N for a new run.', 10); }
        else toast('Relic ' + n + ' of ' + total + ': ' + r.name, 4);
        store();
      }
    }
    beamM.opacity = 0.16 + 0.07 * Math.sin(t * 2); goal();
  };
}

function makeMap() {
  // whole-world map: north is up, the player is a pulsing arrow at their true position
  const cv = $('map'), g = cv.getContext('2d'), S = cv.width, N = 400, off = document.createElement('canvas'); off.width = off.height = N;
  const og = off.getContext('2d'), im = og.createImageData(N, N);
  for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
    const x = ((i + .5) / N - .5) * C.size, z = ((j + .5) / N - .5) * C.size, h = heightAt(x, z), al = ALT(h);
    let c = h < C.waterLevel ? [40, 100, 125] : al < 900 ? [200, 175, 125] : al < 1800 ? [170, 140, 80] : al < 2400 ? [110, 140, 60] : al < 3200 ? [60, 110, 55] : al < 4000 ? [120, 120, 70] : [150, 140, 125];
    if (h >= C.waterLevel && h < 2.5) c = [195, 180, 135];
    const k = 0.62 + 0.55 * clamp((heightAt(x - 14, z - 14) - h) * 0.06 + 0.5, 0, 1);   // hillshade from the north-west
    im.data.set([c[0] * k, c[1] * k, c[2] * k, 255], (j * N + i) * 4);
  }
  og.putImageData(im, 0, 0);
  const W = (x, z) => [(x / C.size + .5) * S, (z / C.size + .5) * S];
  return () => {
    g.clearRect(0, 0, S, S); g.imageSmoothingEnabled = true; g.drawImage(off, 0, 0, S, S);
    if (site) { const [vx, vz] = W(site[0], site[1]); g.fillStyle = '#f3d27a'; g.fillRect(vx - 4, vz - 3, 8, 6); g.strokeStyle = '#000'; g.lineWidth = 1; g.strokeRect(vx - 4, vz - 3, 8, 6); }
    for (const r of P.relics || []) if (!r.got) { const [rx, rz] = W(r.x, r.z); g.fillStyle = '#6ff5e4'; g.beginPath(); g.arc(rx, rz, 3, 0, 6.3); g.fill(); g.strokeStyle = '#043'; g.lineWidth = 1; g.stroke(); }
    const [px, pz] = W(P.x, P.z), t = performance.now() / 600 % 1;
    g.strokeStyle = 'rgba(255,255,255,' + (0.8 * (1 - t)) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(px, pz, 5 + t * 12, 0, 6.3); g.stroke();
    g.save(); g.translate(px, pz); g.rotate(-P.yaw); g.fillStyle = '#ff3b30'; g.strokeStyle = '#fff'; g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(0, -8); g.lineTo(6, 7); g.lineTo(0, 3.5); g.lineTo(-6, 7); g.closePath(); g.fill(); g.stroke(); g.restore();
    g.strokeStyle = 'rgba(255,255,255,.55)'; g.lineWidth = 2; g.strokeRect(1, 1, S - 2, S - 2);
    g.fillStyle = '#fff'; g.font = 'bold 12px Georgia'; g.textAlign = 'center'; g.fillText('N', S / 2, 13);
  };
}

let rain = 0, rainTarget = 0, rainTimer = 60 + Math.random() * 90, flash = 0, thunderT = 0, cricT = 0, rainGain, waterGain;
const RN = 2200, rpos = new Float32Array(RN * 6);
for (let i = 0; i < RN; i++) { const x = (Math.random() - .5) * 60, y = Math.random() * 30 - 6, z = (Math.random() - .5) * 60; rpos.set([x, y, z, x + 0.15, y - 0.9, z + 0.05], i * 6); }
const rg2 = new THREE.BufferGeometry(); rg2.setAttribute('position', new THREE.BufferAttribute(rpos, 3));
const rainMat = new THREE.LineBasicMaterial({ color: 0xb4c8dc, transparent: true, opacity: 0, fog: false, depthWrite: false });
const rainMesh = new THREE.LineSegments(rg2, rainMat); rainMesh.frustumCulled = false; rainMesh.visible = false; scene.add(rainMesh);
function thunder() {
  if (!AC) return;
  const s = AC.createBufferSource(), f = AC.createBiquadFilter(), g = AC.createGain(), t = AC.currentTime;
  s.buffer = noiseBuf; s.loop = true; f.type = 'lowpass'; f.frequency.setValueAtTime(220, t); f.frequency.exponentialRampToValueAtTime(40, t + 3);
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.7, t + 0.15); g.gain.exponentialRampToValueAtTime(0.001, t + 3.5);
  s.connect(f).connect(g).connect(AC.destination); s.start(t); s.stop(t + 3.6);
}
/* lightning bolt: a jagged branching line from the clouds to the ground, plus night shooting stars */
const boltN = 40, boltP = new Float32Array(boltN * 2 * 3 * 2), boltG = new THREE.BufferGeometry(); boltG.setAttribute('position', new THREE.BufferAttribute(boltP, 3));
const bolt = new THREE.LineSegments(boltG, new THREE.LineBasicMaterial({ color: 0xe8f0ff, fog: false, transparent: true, opacity: 0.95 })); bolt.frustumCulled = false; bolt.visible = false; scene.add(bolt);
function strike() {
  const a = Math.random() * 6.283, d = 160 + Math.random() * 500, bx = P.x + Math.cos(a) * d, bz = P.z + Math.sin(a) * d; let x = bx, z = bz, y = P.y + 420, k = 0, gy = heightAt(bx, bz);
  const seg = (x1, y1, z1, x2, y2, z2) => { if (k >= boltN * 2) return; boltP.set([x1, y1, z1, x2, y2, z2], k * 6); k++; };
  for (let i = 0; i < boltN / 2 + 8 && k < boltN * 2 - 6; i++) {
    const ny = Math.max(gy, y - 420 / (boltN / 2 + 8) * (0.8 + Math.random() * 0.5)), nx = x + (Math.random() - .5) * 34, nz = z + (Math.random() - .5) * 34; seg(x, y, z, nx, ny, nz);
    if (Math.random() < 0.2) seg(nx, ny, nz, nx + (Math.random() - .5) * 90, ny - 40 - Math.random() * 60, nz + (Math.random() - .5) * 90);
    x = nx; y = ny; z = nz; if (y <= gy) break;
  }
  for (let j = k; j < boltN * 2; j++) boltP.set([0, -999, 0, 0, -999, 0], j * 6);
  boltG.attributes.position.needsUpdate = true; burst(x, gy + 0.3, z, 0xaaccff, 12, 6, 4);
}
const SS = { t: 6, life: 0, x: 0, y: 0, z: 0, dx: 0, dy: 0, dz: 0 };
const ssG = new THREE.BufferGeometry(); ssG.setAttribute('position', new THREE.BufferAttribute(new Float32Array(6), 3));
const shootStar = new THREE.Line(ssG, new THREE.LineBasicMaterial({ color: 0xffffff, fog: false, transparent: true, opacity: 0, depthWrite: false })); shootStar.frustumCulled = false; scene.add(shootStar);
function starTick(dt) {
  if (SS.life > 0) { SS.life -= dt; SS.x += SS.dx * dt; SS.y += SS.dy * dt; SS.z += SS.dz * dt; const p = ssG.attributes.position.array, c = camera.position; p.set([c.x + SS.x, c.y + SS.y, c.z + SS.z, c.x + SS.x - SS.dx * 0.07, c.y + SS.y - SS.dy * 0.07, c.z + SS.z - SS.dz * 0.07]); ssG.attributes.position.needsUpdate = true; shootStar.material.opacity = Math.min(1, SS.life * 2.2); }
  else { shootStar.material.opacity = 0; if (SU.uNight.value > 0.7 && rain < 0.3 && (SS.t -= dt) < 0) { SS.t = 8 + Math.random() * 20; SS.life = 0.9; const a = Math.random() * 6.283; SS.x = Math.cos(a) * 1800; SS.z = Math.sin(a) * 1800; SS.y = 900 + Math.random() * 700; SS.dx = -Math.cos(a) * 1500 + (Math.random() - .5) * 400; SS.dz = -Math.sin(a) * 1500 + (Math.random() - .5) * 400; SS.dy = -500 - Math.random() * 400; } }
}
function weather(dt) {
  starTick(dt); bolt.visible = flash > 0.35;
  if ((rainTimer -= dt) < 0) { rainTarget = rainTarget ? 0 : (Math.random() < 0.6 ? 1 : 0); rainTimer = rainTarget ? 50 + Math.random() * 70 : 90 + Math.random() * 150; if (rainTarget && locked) toast('Clouds are rolling in...'); }
  rain = lerp(rain, rainTarget, Math.min(1, dt * 0.25));
  if (Math.abs(rain - rainTarget) < 0.005) rain = rainTarget;
  rainMesh.visible = rain > 0.02;
  if (rain > 0.001) {
    scene.fog.density += rain * 0.0011; SU.uHor.value.multiplyScalar(1 - 0.35 * rain); SU.uZen.value.multiplyScalar(1 - 0.4 * rain);
    scene.fog.color.multiplyScalar(1 - 0.3 * rain); sun.intensity *= 1 - 0.65 * rain; hemi.intensity *= 1 - 0.25 * rain;
    if (rain > 0.7 && Math.random() < dt * 0.04) { flash = 1; thunderT = 0.6 + Math.random() * 2.2; strike(); }
  }
  if (flash > 0) { hemi.intensity += flash * 2.5; SU.uHor.value.addScalar(flash * 0.4); flash = Math.max(0, flash - dt * 4); }
  if (thunderT > 0 && (thunderT -= dt) <= 0) thunder();
  if (rainMesh.visible) {
    rainMat.opacity = 0.35 * rain; rainMesh.position.copy(camera.position);
    const a = rg2.attributes.position, v = a.array, fall = 32 * dt;
    for (let i = 0; i < RN; i++) {
      const o = i * 6; v[o + 1] -= fall; v[o + 4] -= fall;
      if (v[o + 4] < -6) { const x = (Math.random() - .5) * 60, z = (Math.random() - .5) * 60; v[o] = x; v[o + 1] = 24; v[o + 2] = z; v[o + 3] = x + 0.15; v[o + 4] = 23.1; v[o + 5] = z + 0.05; }
    }
    a.needsUpdate = true;
  }
}
function cricket() {
  const t = AC.currentTime, f = 4100 + Math.random() * 500;
  for (let i = 0; i < 3; i++) {
    const o = AC.createOscillator(), g = AC.createGain(), a = t + i * 0.055;
    o.frequency.value = f; g.gain.setValueAtTime(0, a); g.gain.linearRampToValueAtTime(0.004, a + 0.01); g.gain.linearRampToValueAtTime(0, a + 0.04);
    o.connect(g).connect(AC.destination); o.start(a); o.stop(a + 0.05);
  }
}
/* ---- extra procedural sounds: church bell, village drum, bird songs, hyena whoop, owl ---- */
function bell(vol = 0.05) {
  if (!AC) return;
  for (const [f, v] of [[392, 1], [784, 0.5], [1176, 0.3], [1570, 0.18]]) {
    const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime; o.type = 'sine'; o.frequency.value = f * (1 + Math.random() * 0.002);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(vol * v, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0003, t + 3.2); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 3.3);
  }
}
function drum(vol = 0.12) {
  if (!AC) return;
  const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime; o.type = 'sine'; o.frequency.setValueAtTime(130, t); o.frequency.exponentialRampToValueAtTime(55, t + 0.18);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0005, t + 0.35); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 0.4);
}
function birdSong() {
  if (!AC) return; const t = AC.currentTime, n = 3 + (Math.random() * 6 | 0), base = 1800 + Math.random() * 2400, style = Math.random();
  for (let i = 0; i < n; i++) {
    const o = AC.createOscillator(), g = AC.createGain(), a = t + i * (style < 0.5 ? 0.11 : 0.19), f = base * (1 + (i % 3) * 0.18 + Math.random() * 0.06); o.type = 'sine';
    o.frequency.setValueAtTime(f, a); o.frequency.exponentialRampToValueAtTime(f * (style < 0.5 ? 1.5 : 0.7), a + 0.09);
    g.gain.setValueAtTime(0, a); g.gain.linearRampToValueAtTime(0.02, a + 0.015); g.gain.exponentialRampToValueAtTime(0.0004, a + 0.12); o.connect(g).connect(AC.destination); o.start(a); o.stop(a + 0.14);
  }
}
function whoop() {   // spotted hyena "whoo-oop"
  if (!AC) return; const t = AC.currentTime, o = AC.createOscillator(), g = AC.createGain(), f = AC.createBiquadFilter(); o.type = 'sawtooth'; f.type = 'lowpass'; f.frequency.value = 900;
  o.frequency.setValueAtTime(95, t); o.frequency.linearRampToValueAtTime(190, t + 0.35); o.frequency.linearRampToValueAtTime(420, t + 0.7); o.frequency.exponentialRampToValueAtTime(160, t + 1.1);
  g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.045, t + 0.2); g.gain.linearRampToValueAtTime(0.0, t + 1.15); o.connect(f).connect(g).connect(AC.destination); o.start(t); o.stop(t + 1.2);
}
function owl() {
  if (!AC) return; for (const dly of [0, 0.5]) { const t = AC.currentTime + dly, o = AC.createOscillator(), g = AC.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(420, t); o.frequency.linearRampToValueAtTime(360, t + 0.35);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.03, t + 0.08); g.gain.linearRampToValueAtTime(0, t + 0.4); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 0.45); }
}
const AUD = { bellT: 5, drumT: 8, drumN: 0, songT: 6, whoopT: 40, owlT: 20, lastHr: -1 };
function ambience2(dt) {
  const nt = SU.uNight.value, dayN = 1 - nt, vd = site ? Math.hypot(P.x - site[0], P.z - site[1]) : 1e9;
  const hr = Math.floor(tod * 24);
  if (hr !== AUD.lastHr) { AUD.lastHr = hr; if ((hr === 6 || hr === 12 || hr === 18) && vd < 700) { AUD.bell = 6; } }
  if (AUD.bell > 0 && (AUD.bellT -= dt) < 0) { AUD.bellT = 1.6; AUD.bell--; bell(0.05 * clamp(1.3 - vd / 700, 0.15, 1)); }
  if (vd < 160 && nt > 0.5 && rain < 0.3 && (AUD.drumT -= dt) < 0) { const seq = [0.4, 0.4, 0.8, 0.3, 0.3, 0.5, 1.6]; AUD.drumT = seq[AUD.drumN++ % seq.length]; drum(0.1 * clamp(1.2 - vd / 160, 0.15, 1)); }
  if (dayN > 0.5 && rain < 0.3 && P.y > 1.5 && (AUD.songT -= dt) < 0) { AUD.songT = 2.5 + Math.random() * 6; birdSong(); }
  if (nt > 0.6 && (AUD.whoopT -= dt) < 0) { AUD.whoopT = 30 + Math.random() * 50; whoop(); }
  if (nt > 0.6 && (AUD.owlT -= dt) < 0) { AUD.owlT = 18 + Math.random() * 30; owl(); }
}
function ambience(dt) {
  if (!AC) return; ambience2(dt);
  if (rainGain) rainGain.gain.value = 0.11 * rain;
  if (waterGain) waterGain.gain.value = 0.05 * clamp(1 - (P.y - 0.2) / 5, 0, 1);
  if (SU.uNight.value > 0.5 && rain < 0.3 && P.y > 1.5 && (cricT -= dt) < 0) { cricT = 0.12 + Math.random() * 0.25; cricket(); }
}

/* ---------- action: wolves + bow ---------- */
P.kills = 0; P.shake = 0; P.ammo = 15;
const arrows = [], arrowG = new THREE.CylinderGeometry(0.02, 0.02, 0.9, 5).rotateX(Math.PI / 2), arrowM = new THREE.MeshStandardMaterial({ color: 0xd9c9a0, roughness: 0.8 });
let shotCd = 0, howlT = 25;
function twang() {
  if (!AC) return;
  const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime; o.type = 'triangle';
  o.frequency.setValueAtTime(240, t); o.frequency.exponentialRampToValueAtTime(70, t + 0.25);
  g.gain.setValueAtTime(0.1, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.28); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 0.3);
}
function howl() {
  if (!AC) return;
  const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime; o.type = 'sine';
  o.type = 'sawtooth'; o.frequency.setValueAtTime(180, t); o.frequency.linearRampToValueAtTime(520, t + 0.7); o.frequency.linearRampToValueAtTime(200, t + 0.9); o.frequency.linearRampToValueAtTime(600, t + 1.8); o.frequency.linearRampToValueAtTime(220, t + 2.6);
  g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.025, t + 0.5); g.gain.linearRampToValueAtTime(0, t + 2.7); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 2.8);
}
const HIT = [];   // shootable village creatures (villagers, goats, livestock); rebuilt with the village
function hitEnt(t, dmg, p) {
  const o = t.o; o.hp -= dmg; burst(p.x, p.y, p.z, 0xaa1c14, 12, 2.2, 2.2);
  if (o.hp <= 0) { o.dead = true; o.rt = 50; hitmark(true); step('rock', 0.3); if (t.drop) t.drop(); }
  else { hitmark(false); o.fl = 4; const dx = o.x - P.x, dz = o.z - P.z, d = Math.hypot(dx, dz) || 1; o.flee = [o.x + dx / d * 30, o.z + dz / d * 30]; }
}
function killBird(b) { b.dead = true; b.rt = 25; b.vy = 2; hitmark(true); toast('Bird down', 1.6); }
function shoot(pw = 1) {
  if (!locked || shotCd > 0) return;
  if (P.ammo <= 0) { toast('Out of arrows. Relics and hyenas drop more.'); shotCd = 1; return; }
  P.ammo--; shotCd = 0.7; twang();
  const m = new THREE.Mesh(arrowG, arrowM), o = new THREE.Vector3(P.x, P.y + C.eye - P.crouch * 0.7, P.z), fe = new THREE.Vector3(0, 0, -1).applyEuler(new THREE.Euler(P.pitch, P.yaw, 0, 'YXZ'));
  const d = camMode === 1 ? camera.position.clone().addScaledVector(new THREE.Vector3(0, 0, -1).applyQuaternion(camera.quaternion), 60).sub(o).normalize() : fe;
  m.position.copy(o).addScaledVector(d, 0.9); m.position.y -= 0.1; m.castShadow = true; m.lookAt(m.position.clone().add(d));
  scene.add(m); arrows.push({ m, v: d.multiplyScalar(35 + 50 * pw), life: 4, k: 0.5 + 0.8 * pw });
}
let drawing = false, charge = 0;
document.addEventListener('mousedown', e => { if (e.button === 0 && locked && !mapOpen && shotCd <= 0) { drawing = true; charge = 0; } });
document.addEventListener('mouseup', e => { if (e.button === 0 && drawing) { drawing = false; shoot(Math.max(0.25, Math.min(1, charge / 0.9))); charge = 0; } });
const hitEl = $('hit');
function hitmark(k) { hitEl.className = ''; void hitEl.offsetWidth; hitEl.className = k ? 'k' : 'on'; }
function killWolf(w) {
  w.dead = true; w.g.visible = false; w.rt = 45 + rnd() * 40; P.kills++; P.ammo += 2; P.inv.meat++; P.inv.pelt++; step('rock', 0.4); toast('Hyena down  +2 arrows', 2);
}
/* ---- impact particles: dust where arrows land, red spray on hits, sparks, splashes ---- */
const PN = 160, ppos = new Float32Array(PN * 3).fill(-999), pcol = new Float32Array(PN * 3), pvel = new Float32Array(PN * 3), plife = new Float32Array(PN), pc0 = new Float32Array(PN * 3); let pHead = 0;
const pgeo = new THREE.BufferGeometry(); pgeo.setAttribute('position', new THREE.BufferAttribute(ppos, 3)); pgeo.setAttribute('color', new THREE.BufferAttribute(pcol, 3));
const pts = new THREE.Points(pgeo, new THREE.PointsMaterial({ size: 0.12, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, map: null })); pts.frustumCulled = false; scene.add(pts);
const _pc = new THREE.Color();
function burst(x, y, z, hex, n = 10, spd = 2.5, up = 2) {
  _pc.setHex(hex);
  for (let i = 0; i < n; i++) {
    const k = pHead; pHead = (pHead + 1) % PN; ppos[k * 3] = x; ppos[k * 3 + 1] = y; ppos[k * 3 + 2] = z;
    const a = Math.random() * 6.283, s = (0.3 + Math.random()) * spd; pvel[k * 3] = Math.cos(a) * s; pvel[k * 3 + 1] = up * (0.4 + Math.random()); pvel[k * 3 + 2] = Math.sin(a) * s;
    plife[k] = 0.5 + Math.random() * 0.5; pc0[k * 3] = _pc.r; pc0[k * 3 + 1] = _pc.g; pc0[k * 3 + 2] = _pc.b;
  }
}
function fxTick(dt) {
  for (let i = 0; i < PN; i++) {
    if (plife[i] <= 0) { ppos[i * 3 + 1] = -999; continue; }
    plife[i] -= dt; pvel[i * 3 + 1] -= 9 * dt; ppos[i * 3] += pvel[i * 3] * dt; ppos[i * 3 + 1] += pvel[i * 3 + 1] * dt; ppos[i * 3 + 2] += pvel[i * 3 + 2] * dt;
    const f = Math.max(0, plife[i]) * 1.6; pcol[i * 3] = pc0[i * 3] * f; pcol[i * 3 + 1] = pc0[i * 3 + 1] * f; pcol[i * 3 + 2] = pc0[i * 3 + 2] * f;
  }
  pgeo.attributes.position.needsUpdate = pgeo.attributes.color.needsUpdate = true;
}
function combat(dt) {
  fxTick(dt); shotCd -= dt; if (drawing) charge += dt; P.shake = Math.max(0, P.shake - dt * 0.5);
  for (let i = arrows.length - 1; i >= 0; i--) {
    const a = arrows[i], p = a.m.position; let done = false, stick = false; a.life -= dt; a.v.y -= 14 * dt;
    for (let s = 0; s < 3 && !done; s++) {
      p.addScaledVector(a.v, dt / 3);
      if (p.y < heightAt(p.x, p.z)) { done = true; stick = true; burst(p.x, p.y + 0.1, p.z, p.y < 0.6 ? 0x5a8aaa : 0x7a6a4a, 7, 1.2, 1.8); }
      for (const w of P.wolves) {
        if (w.dead) continue; const gy = heightAt(w.x, w.z);
        if (Math.hypot(p.x - w.x, p.z - w.z) < 0.9 && Math.abs(p.y - gy - 0.7) < 0.8) {
          w.hp -= (p.y > gy + 0.95 ? 45 : 30) * (a.k || 1); hitmark(w.hp <= 0); burst(p.x, p.y, p.z, 0xaa1c14, 14, 2.4, 2.4); w.hit = 1; w.alert = true; done = true; if (w.hp <= 0) killWolf(w); else step('rock', 0.3); break;
        }
      }
      if (!done) for (const t of HIT) {
        const o = t.o; if (o.dead) continue; const gy = heightAt(o.x, o.z);
        if (Math.hypot(p.x - o.x, p.z - o.z) < t.r && Math.abs(p.y - gy - t.cy) < t.hh) { hitEnt(t, (p.y > gy + t.cy + t.hh * 0.45 ? 50 : 32) * (a.k || 1), p); done = true; break; }
      }
      if (!done && birdsG.visible) for (const b of birds) { if (b.dead) continue; const br = 1.8 * b.g.scale.x; if (p.distanceToSquared(b.g.position) < br * br) { burst(p.x, p.y, p.z, 0x2a2a2a, 14, 2.4, 2.4); killBird(b); done = true; break; } }
      if (!done && P.fauna) for (const f of P.fauna) {
        if (f.dead || !f.root.visible) continue; const gy = heightAt(f.x, f.z);
        if (Math.hypot(p.x - f.x, p.z - f.z) < f.hitR && Math.abs(p.y - gy - f.hy) < f.hh) { f.hurt((p.y > gy + f.hy + f.hh * 0.45 ? 50 : 32) * (a.k || 1)); hitmark(f.dead); burst(p.x, p.y, p.z, 0xaa1c14, 12, 2.2, 2.2); done = true; break; }
      }
    }
    a.m.lookAt(p.clone().add(a.v)); trailAdd(p);
    if (done || a.life <= 0) { if (stick) stickArrow(a); else scene.remove(a.m); arrows.splice(i, 1); }
  }
  $('ammo').textContent = 'Arrows ' + P.ammo + '    Hyenas ' + P.kills + (drawing ? '\nDraw ' + '▮'.repeat(Math.round(Math.min(1, charge / 0.9) * 10)) : '');
}
function makeWolves(sp) {
  const list = [], fur = new THREE.MeshStandardMaterial({ color: 0x8a7a5c, roughness: 1 });   // spotted hyena
  const geo = { b: new THREE.BoxGeometry(0.5, 0.55, 1.2), h: new THREE.BoxGeometry(0.34, 0.34, 0.5), t: new THREE.BoxGeometry(0.12, 0.12, 0.6), l: new THREE.BoxGeometry(0.12, 0.6, 0.12).translate(0, -0.3, 0) };
  const spawn = (w, rx, rz) => {
    for (let t = 0; t < 80; t++) {
      const x = clamp(rx + (rnd() * 2 - 1) * 900, -C.size * 0.45, C.size * 0.45), z = clamp(rz + (rnd() * 2 - 1) * 900, -C.size * 0.45, C.size * 0.45), h = heightAt(x, z);
      if (h > 3 && h < 6000 && !inSite(x, z) && Math.hypot(x - rx, z - rz) > 140) { Object.assign(w, { x, z, hp: 60, dead: false }); w.g.visible = true; return; }
    }
    w.dead = true; w.rt = 20; w.g.visible = false;
  };
  for (let n = 0; n < (C.wolves || 8); n++) {
    const g = new THREE.Group(), dk = new THREE.MeshStandardMaterial({ color: 0x2a221c, roughness: 1 }), sp2 = new THREE.MeshStandardMaterial({ color: 0x3a2e22, roughness: 1 }), cream = new THREE.MeshStandardMaterial({ color: 0xcfc2a0, roughness: 1 });
    const part = (geom, m, x, y, z, sx = 1, sy = 1, sz = 1) => { const o = new THREE.Mesh(geom, m); o.position.set(x, y, z); o.scale.set(sx, sy, sz); o.castShadow = true; g.add(o); return o; };
    const sph = new THREE.SphereGeometry(1, 12, 9), cn = new THREE.ConeGeometry(1, 1, 6);
    part(sph, fur, 0, 0.92, 0.3, 0.3, 0.36, 0.42); part(sph, fur, 0, 0.8, -0.28, 0.28, 0.3, 0.45); part(sph, fur, 0, 0.88, 0.0, 0.27, 0.3, 0.4);       // high shoulders, sloping back, lower rump
    for (let i = 0; i < 7; i++) part(cn, dk, 0, 1.2 - i * 0.04, 0.55 - i * 0.14, 0.05, 0.22 - i * 0.012, 0.05).rotation.x = -0.7;                         // dark mane
    part(new THREE.CylinderGeometry(0.15, 0.2, 0.5, 8).rotateX(Math.PI / 2 - 0.5), fur, 0, 1.0, 0.62);
    part(sph, fur, 0, 1.0, 0.95, 0.19, 0.19, 0.24); part(sph, dk, 0, 0.93, 1.2, 0.13, 0.11, 0.15); part(sph, cream, 0, 0.84, 1.05, 0.11, 0.07, 0.15);    // head, dark muzzle, pale jaw
    for (const s of [-1, 1]) { part(sph, fur, s * 0.14, 1.19, 0.86, 0.07, 0.09, 0.03); part(sph, dk, s * 0.08, 1.04, 1.08, 0.025, 0.025, 0.02); }          // round ears, eyes
    part(cn, fur, 0, 0.78, -0.76, 0.1, 0.5, 0.1).rotation.x = 2.3; part(cn, dk, 0, 0.5, -0.98, 0.08, 0.2, 0.08).rotation.x = 2.5;                       // bushy tail
    for (let i = 0; i < 14; i++) { const sd = i % 2 ? 1 : -1; part(sph, sp2, sd * (0.25 + (i % 3) * 0.02), 0.74 + (i % 4) * 0.08, 0.5 - (i >> 1) * 0.17, 0.045, 0.05, 0.05); }   // spots
    const legGeoF = new THREE.CylinderGeometry(0.06, 0.04, 0.68, 6).translate(0, -0.34, 0), legGeoB = new THREE.CylinderGeometry(0.07, 0.04, 0.56, 6).translate(0, -0.28, 0);
    const legs = [[.19, .45, 0.74, legGeoF], [-.19, .45, 0.74, legGeoF], [.19, -.4, 0.62, legGeoB], [-.19, -.4, 0.62, legGeoB]].map(([x, z, y, lg]) => { const l = part(lg, fur, x, y, z); const f = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.06, 0.16), dk); f.position.set(0, lg === legGeoF ? -0.68 : -0.56, 0.03); l.add(f); return l; });
    scene.add(g); const w = { g, legs, x: 0, z: 0, hp: 60, dead: false, rt: 0, cd: 0.5, ph: 0, hit: 0, wt: 0, wa: 0, idle: true, alert: false };
    spawn(w, sp[0], sp[2]); list.push(w);
  }
  P.wolves = list;
  return dt => {
    const aggro = 38 + SU.uNight.value * 40, safe = inSite(P.x, P.z);
    for (const w of list) {
      if (w.dead) { if ((w.rt -= dt) < 0) spawn(w, P.x, P.z); continue; }
      const dx = P.x - w.x, dz = P.z - w.z, d = Math.hypot(dx, dz) + 1e-6; let v = 0, ang;
      w.hit = Math.max(0, w.hit - dt * 3);
      if (d < aggro && !safe) { w.alert = true; ang = Math.atan2(dx, dz); v = d > 1.6 ? 9 : 0; }
      else { w.alert = false; if ((w.wt -= dt) < 0) { w.wt = 3 + rnd() * 5; w.wa = rnd() * 6.28; w.idle = rnd() < 0.4; } ang = w.wa; v = w.idle ? 0 : 1.8; }
      let dy = ang - w.g.rotation.y; dy = Math.atan2(Math.sin(dy), Math.cos(dy)); w.g.rotation.y += dy * Math.min(1, dt * 6);
      if (v) {
        const nx = w.x + Math.sin(w.g.rotation.y) * v * dt, nz = w.z + Math.cos(w.g.rotation.y) * v * dt, nh = heightAt(nx, nz);
        if (nh > 0.8 && !inSite(nx, nz) && (nh - heightAt(w.x, w.z)) / (v * dt) < 1.3) { w.x = nx; w.z = nz; } else if (!w.alert) w.wt = 0;
      }
      if (w.alert && d < 1.9) { if ((w.cd -= dt) < 0) { w.cd = 1.1; hurt(11); step('grass', 0.4); } } else w.cd = Math.max(w.cd, 0.4);
      w.ph += v * dt * 2.4; const sw = v > 0 ? Math.sin(w.ph) : 0;
      w.legs.forEach((l, i) => l.rotation.x = sw * (i % 3 === 0 ? 1 : -1) * 0.7);
      w.g.scale.setScalar(1.15 + w.hit * 0.25); w.g.position.set(w.x, heightAt(w.x, w.z), w.z);
    }
    if (SU.uNight.value > 0.5 && (howlT -= dt) < 0) { howlT = 35 + Math.random() * 40; howl(); }
  };
}

/* ---------- extras: herbs, quivers, campfire, fireflies ---------- */
function makeExtras(sp) {
  const mk = (c, e) => new THREE.MeshStandardMaterial({ color: c, emissive: e, emissiveIntensity: 1.5, roughness: 0.5 });
  const gH = new THREE.OctahedronGeometry(0.3), gQ = new THREE.BoxGeometry(0.28, 0.5, 0.28), mH = mk(0x3ccf6a, 0x1fa84a), mQ = mk(0xd9a441, 0xb87a1a);
  const items = [], cx = site ? site[0] : sp[0], cz = site ? site[1] : sp[2];
  for (let n = 0, t = 0; n < 50 && t < 3000; t++) {
    const near = n < 14, x = near ? cx + (rnd() * 2 - 1) * 220 : (rnd() * 2 - 1) * Math.min(C.size * 0.42, 1700), z = near ? cz + (rnd() * 2 - 1) * 220 : (rnd() * 2 - 1) * Math.min(C.size * 0.42, 1700), h = heightAt(x, z);
    if (h < 1.5 || h > 55 || inSite(x, z)) continue;
    const q = n % 3 === 0, m = new THREE.Mesh(q ? gQ : gH, q ? mQ : mH); m.position.set(x, h + 0.9, z); scene.add(m); items.push({ m, q, y: h + 0.9, on: true }); n++;
  }
  const fx = sp[0] - 4, fz = sp[2] + 2, fy = heightAt(fx, fz);
  const flame = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.1, 7), new THREE.MeshBasicMaterial({ color: 0xff8a2a, transparent: true, opacity: 0.85 }));
  flame.position.set(fx, fy + 0.7, fz); scene.add(flame);
  for (let i = 0; i < 4; i++) { const l = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 1.1, 6), new THREE.MeshStandardMaterial({ color: 0x4a3322, roughness: 1 })); l.position.set(fx, fy + 0.12, fz); l.rotation.set(Math.PI / 2 - 0.25, i * 0.8, 0, 'YXZ'); scene.add(l); }
  const fire = new THREE.PointLight(0xff8a3a, 2.5, 26, 2); fire.position.set(fx, fy + 1.2, fz); scene.add(fire);
  const N = 120, fp = new Float32Array(N * 3), off = [];
  for (let i = 0; i < N; i++) off.push([rnd() * 60 - 30, rnd() * 4, rnd() * 60 - 30, rnd() * 6.28]);
  const fg = new THREE.BufferGeometry(); fg.setAttribute('position', new THREE.BufferAttribute(fp, 3));
  const fm = new THREE.PointsMaterial({ color: 0xd6ff7a, size: 0.35, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false });
  const ff = new THREE.Points(fg, fm); ff.frustumCulled = false; scene.add(ff);
  let told = false;
  return (dt, tw, lk) => {
    const fl = 1 + 0.18 * Math.sin(tw * 17) + 0.12 * Math.sin(tw * 31);
    fire.intensity = 2.5 * fl; flame.scale.set(1, fl, 1); flame.rotation.y = tw * 3;
    const night = SU.uNight.value; fm.opacity = night * 0.9; ff.visible = night > 0.05;
    if (ff.visible) {
      for (let i = 0; i < N; i++) {
        const o = off[i], x = P.x + ((o[0] + tw * 0.4 * Math.sin(o[3]) + 30) % 60 + 60) % 60 - 30, z = P.z + ((o[2] + tw * 0.4 * Math.cos(o[3]) + 30) % 60 + 60) % 60 - 30;
        fp[i * 3] = x; fp[i * 3 + 1] = heightAt(x, z) + 0.8 + o[1] + Math.sin(tw + o[3]) * 0.4; fp[i * 3 + 2] = z;
      }
      fg.attributes.position.needsUpdate = true;
    }
    if (!lk) return;
    if (Math.hypot(P.x - fx, P.z - fz) < 9 && P.hp < 100) { P.hp = Math.min(100, P.hp + 6 * dt); if (!told) { told = true; toast('The campfire warms you.', 2.5); } }
    for (const it of items) {
      if (!it.on) continue; it.m.rotation.y += dt * 1.5; it.m.position.y = it.y + Math.sin(tw * 2 + it.y) * 0.12;
      if (Math.hypot(P.x - it.m.position.x, P.z - it.m.position.z) < 2 && Math.abs(P.y - it.y) < 3) {
        if (it.q) { P.ammo += 8; toast('Quiver  +8 arrows', 2); }
        else { P.inv.herb++; toast('Healing herb collected  (press 1 to use)', 2); }
        it.on = false; it.m.visible = false; chime();
      }
    }
  };
}

const boxes = [];
function collideBoxes() {
  for (const b of boxes) {
    const dx = P.x - b.x, dz = P.z - b.z; if (dx * dx + dz * dz > b.R2 || (b.off && b.off())) continue;
    const lx = dx * b.c - dz * b.s, lz = dx * b.s + dz * b.c, rr = 0.35, qx = clamp(lx, -b.hw, b.hw), qz = clamp(lz, -b.hd, b.hd), ex = lx - qx, ez = lz - qz, d2 = ex * ex + ez * ez; let px, pz;
    if (d2 > 1e-8) { if (d2 >= rr * rr) continue; const k = rr / Math.sqrt(d2); px = qx + ex * k; pz = qz + ez * k; }
    else if (b.hw - Math.abs(lx) < b.hd - Math.abs(lz)) { px = (lx < 0 ? -1 : 1) * (b.hw + rr); pz = lz; } else { px = lx; pz = (lz < 0 ? -1 : 1) * (b.hd + rr); }
    P.x = b.x + px * b.c + pz * b.s; P.z = b.z - px * b.s + pz * b.c;
  }
}
function creak() {
  if (!AC) return; const o = AC.createOscillator(), g = AC.createGain(), t = AC.currentTime; o.type = 'sawtooth';
  o.frequency.setValueAtTime(150, t); o.frequency.linearRampToValueAtTime(95, t + 0.4); g.gain.setValueAtTime(0.03, t); g.gain.linearRampToValueAtTime(0, t + 0.45); o.connect(g).connect(AC.destination); o.start(t); o.stop(t + 0.5);
}
function sleep() { tod = 7 / 24; P.hp = 100; P.stam = 100; toast('You sleep until morning. Health restored.', 3.5); }

/* ---------- inventory ---------- */
P.inv = Object.assign({ herb: 0, tonic: 0, meat: 0, pelt: 0 }, save.inv || {});
const ITEMS = [['herb', 'Healing herb', '#3ccf6a', '+35 health  (1)'], ['tonic', 'Tonic', '#d9a441', 'full health and stamina  (2)'], ['meat', 'Hyena meat', '#c8563f', '+20 health  (3)'], ['pelt', 'Pelt', '#8a847a', 'trophy']];
const ICOL = { herb: '#3ccf6a', tonic: '#d9a441', meat: '#c8563f', pelt: '#8a847a', arrow: '#d9c9a0' };

/* small offscreen 3D renderer: every item is a real model, drawn into its slot canvas */
function makeIcons() {
  try {
    const R = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    R.setPixelRatio(1); R.setSize(128, 128, false); R.outputEncoding = THREE.sRGBEncoding; R.setClearColor(0x000000, 0);
    const sc = new THREE.Scene(), cam = new THREE.PerspectiveCamera(32, 1, 0.1, 30); cam.position.set(0, 0.5, 4.6); cam.lookAt(0, 0, 0);
    sc.add(new THREE.HemisphereLight(0xffffff, 0x665544, 1.0));
    const kl = new THREE.DirectionalLight(0xfff0d8, 2.4); kl.position.set(2.5, 3.5, 3); sc.add(kl);
    const rl = new THREE.DirectionalLight(0x9fd0ff, 1.2); rl.position.set(-3, 1.5, -2.5); sc.add(rl);
    const M = (c, o) => new THREE.MeshStandardMaterial(Object.assign({ color: c, roughness: 0.6 }, o || {}));
    const mesh = (g, m, x = 0, y = 0, z = 0) => { const o = new THREE.Mesh(g, m); o.position.set(x, y, z); return o; };
    const fit = (g, size, tilt) => {
      g.rotation.x = tilt || 0; const b = new THREE.Box3().setFromObject(g), c = b.getCenter(new THREE.Vector3()), z = b.getSize(new THREE.Vector3());
      g.position.sub(c); const w = new THREE.Group(); w.add(g); w.scale.setScalar(size / Math.max(z.x, z.y, z.z)); w.visible = false; sc.add(w); return w;
    };
    const V2 = a => a.map(p => new THREE.Vector2(p[0], p[1]));

    /* healing herb: bunch of stalks with glowing leaves */
    const herb = new THREE.Group(), stemM = M(0x2f8a3c), leafM = M(0x48c85a, { emissive: 0x1e8a38, emissiveIntensity: 0.55, side: THREE.DoubleSide }), leafG = new THREE.SphereGeometry(1, 12, 8).scale(0.2, 0.025, 0.09).translate(0.2, 0, 0), budM = M(0xf5f0c8, { emissive: 0xffe9a0, emissiveIntensity: 0.4 });
    for (let i = 0; i < 7; i++) {
      const sg = new THREE.Group(), h = 0.95 + (i % 3) * 0.22; sg.rotation.order = 'YXZ'; sg.rotation.y = i * 2.4; sg.rotation.x = 0.18 + (i % 2) * 0.2 - (i === 0 ? 0.18 : 0);
      sg.add(mesh(new THREE.CylinderGeometry(0.014, 0.026, h, 6).translate(0, h / 2, 0), stemM));
      for (let k = 0; k < 4; k++) { const l = mesh(leafG, leafM, 0, h * (0.35 + k * 0.17), 0); l.rotation.y = k * 2.1 + i; l.rotation.z = 0.7 - k * 0.12; l.scale.setScalar(1 - k * 0.1); sg.add(l); }
      if (i % 2) sg.add(mesh(new THREE.SphereGeometry(0.06, 8, 6), budM, 0, h + 0.02, 0));
      herb.add(sg);
    }
    herb.add(mesh(new THREE.TorusGeometry(0.07, 0.025, 6, 14).rotateX(Math.PI / 2), M(0x8a5a30), 0, 0.2, 0));

    /* tonic: glass bottle, amber liquid, cork */
    const tonic = new THREE.Group();
    tonic.add(mesh(new THREE.LatheGeometry(V2([[0.001, 0], [.34, 0], [.43, .08], [.46, .3], [.4, .58], [.22, .78], [.16, .92], [.16, 1.18], [.001, 1.18]]), 24), M(0xcdeff4, { transparent: true, opacity: 0.32, roughness: 0.05, metalness: 0.2, depthWrite: false, side: THREE.DoubleSide })));
    tonic.add(mesh(new THREE.LatheGeometry(V2([[0.001, .03], [.31, .03], [.4, .1], [.43, .3], [.37, .56], [.001, .6]]), 24), M(0xe0a43a, { emissive: 0xc07a14, emissiveIntensity: 0.6, roughness: 0.3, side: THREE.DoubleSide })));
    tonic.add(mesh(new THREE.CylinderGeometry(.14, .17, .26, 12), M(0x8a5a30), 0, 1.3, 0));
    tonic.add(mesh(new THREE.TorusGeometry(.17, .02, 6, 16).rotateX(Math.PI / 2), M(0xc9a64a), 0, 1.13, 0));
    tonic.add(mesh(new THREE.CylinderGeometry(.475, .475, .22, 24, 1, true), M(0xe8dcc0, { side: THREE.DoubleSide }), 0, .3, 0));

    /* meat: roast haunch on the bone */
    const meat = new THREE.Group(), boneM = M(0xf0e6cf, { roughness: 0.5 });
    meat.add(mesh(new THREE.SphereGeometry(1, 28, 20).scale(.62, .46, .46), M(0xb23b36, { roughness: 0.45 })));
    meat.add(mesh(new THREE.SphereGeometry(1, 20, 14).scale(.34, .26, .3), M(0x9a2e2c, { roughness: 0.5 }), -.18, .1, .18));
    meat.add(mesh(new THREE.SphereGeometry(1, 16, 12).scale(.3, .1, .34), M(0xf2dcc4, { roughness: 0.4 }), -.12, .38, 0));
    meat.add(mesh(new THREE.CylinderGeometry(.075, .075, .8, 10).rotateZ(Math.PI / 2), boneM, .85, 0, 0));
    meat.add(mesh(new THREE.SphereGeometry(.14, 12, 10), boneM, 1.27, .07, 0), mesh(new THREE.SphereGeometry(.13, 12, 10), boneM, 1.27, -.08, .05));

    /* pelt: stretched fur hide */
    const fc = document.createElement('canvas'); fc.width = fc.height = 128; const fx = fc.getContext('2d'); fx.fillStyle = '#9a968f'; fx.fillRect(0, 0, 128, 128);
    for (let k = 0; k < 700; k++) { const v = 90 + Math.random() * 120 | 0; fx.strokeStyle = 'rgba(' + v + ',' + v + ',' + (v - 4) + ',.55)'; fx.lineWidth = 1 + Math.random(); const x = Math.random() * 128, y = Math.random() * 128; fx.beginPath(); fx.moveTo(x, y); fx.lineTo(x + (Math.random() - .5) * 4, y + 8 + Math.random() * 6); fx.stroke(); }
    const furT = new THREE.CanvasTexture(fc); furT.wrapS = furT.wrapT = THREE.RepeatWrapping; furT.repeat.set(1.5, 1.5); furT.encoding = THREE.sRGBEncoding;
    const half = [[0, 1], [.1, .95], [.14, .82], [.3, .74], [.5, .78], [.6, .64], [.5, .5], [.38, .42], [.42, .12], [.54, -.08], [.5, -.3], [.58, -.46], [.46, -.58], [.3, -.5], [.15, -.66], [.1, -.92], [0, -1]];
    const outline = V2(half).concat(V2(half.slice(1, -1).reverse().map(p => [-p[0], p[1]]))); outline.push(outline[0].clone());
    const pg = new THREE.ExtrudeGeometry(new THREE.Shape(new THREE.SplineCurve(outline).getPoints(140)), { depth: .05, bevelEnabled: true, bevelThickness: .03, bevelSize: .03, bevelSegments: 2, curveSegments: 1 });
    const pelt = new THREE.Group(); pelt.add(mesh(pg, M(0xffffff, { map: furT, roughness: 1 }), 0, 0, -.025));

    /* arrow bundle */
    const arrows = new THREE.Group(), shaftM = M(0xd9c9a0, { roughness: .7 }), headM = M(0xaab2ba, { metalness: .8, roughness: .3 }), fl = [M(0xb23b36, { side: THREE.DoubleSide }), M(0xf0ece4, { side: THREE.DoubleSide })];
    for (let i = 0; i < 5; i++) {
      const g = new THREE.Group(); g.add(mesh(new THREE.CylinderGeometry(.022, .022, 1.9, 6), shaftM)); g.add(mesh(new THREE.ConeGeometry(.075, .26, 8), headM, 0, 1.05, 0));
      for (let k = 0; k < 3; k++) { const fg = new THREE.Group(); fg.rotation.y = k * 2.09; fg.add(mesh(new THREE.PlaneGeometry(.16, .36), fl[k === 1 ? 1 : 0], .08, -.72, 0)); g.add(fg); }
      g.rotation.z = (i - 2) * .11; g.rotation.x = ((i % 2) - .5) * .14; g.position.x = (i - 2) * .07; arrows.add(g);
    }
    arrows.add(mesh(new THREE.TorusGeometry(.17, .035, 6, 14).rotateX(Math.PI / 2), M(0x7a2e24), 0, .1, 0)); arrows.rotation.z = .6;

    const models = { herb: fit(herb, 2.0, 0.15), tonic: fit(tonic, 2.1, 0), meat: fit(meat, 2.3, 0.2), pelt: fit(pelt, 2.4, -0.9), arrow: fit(arrows, 2.3, 0.25) };
    return {
      draw(k, cv, ang) {
        const m = models[k]; if (!m) return; m.visible = true; m.rotation.y = ang; R.render(sc, cam); m.visible = false;
        const g = cv.getContext('2d'); g.clearRect(0, 0, cv.width, cv.height); g.drawImage(R.domElement, 0, 0, cv.width, cv.height);
      }
    };
  } catch (e) { return { draw() {} }; }
}
const ICONS = makeIcons();

const invEl = document.createElement('div'), barEl = document.createElement('div'); let invOpen = false, invKey = '';
invEl.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);display:none;gap:14px;padding:18px;background:rgba(16,22,20,.78);border-radius:16px;backdrop-filter:blur(6px);pointer-events:none;flex-wrap:wrap;justify-content:center;max-width:92vw';
barEl.style.cssText = 'position:fixed;left:50%;bottom:16px;transform:translateX(-50%);display:none;gap:10px;pointer-events:none';
function slot(k, size, hint) {
  const el = document.createElement('div'), cv = document.createElement('canvas'), cnt = document.createElement('b');
  el.style.cssText = 'position:relative;width:' + size + 'px;height:' + size + 'px;border-radius:14px;background:radial-gradient(circle at 50% 30%,rgba(255,255,255,.16),rgba(10,14,13,.75));border-bottom:3px solid ' + ICOL[k] + ';box-shadow:0 4px 14px rgba(0,0,0,.4)';
  cv.width = cv.height = 128; cv.style.cssText = 'width:100%;height:100%;display:block';
  cnt.style.cssText = 'position:absolute;right:7px;bottom:4px;font:700 ' + Math.round(size * 0.2) + 'px Georgia,serif;color:#f2efe6;text-shadow:0 1px 4px #000';
  el.append(cv, cnt);
  if (hint) { const h = document.createElement('i'); h.textContent = hint; h.style.cssText = 'position:absolute;left:7px;top:4px;font:12px Georgia,serif;color:#b8b4a6;font-style:normal'; el.append(h); }
  return { k, cv, cnt, el };
}
const barSlots = ['herb', 'tonic', 'meat'].map((k, i) => slot(k, 64, i + 1)), invSlots = ['herb', 'tonic', 'meat', 'pelt', 'arrow'].map(k => slot(k, 104));
barEl.append(...barSlots.map(s => s.el)); invEl.append(...invSlots.map(s => s.el));
document.body.append(invEl, barEl);
function useItem(k) {
  if (!P.inv[k]) { toast('You have none', 1.5); return; }
  if (k === 'herb' || k === 'meat') { if (P.hp >= 100) { toast('Health already full', 1.5); return; } P.hp = Math.min(100, P.hp + (k === 'herb' ? 35 : 20)); }
  else if (k === 'tonic') { P.hp = 100; P.stam = 100; } else { toast('A trophy. Nothing to use it on yet.', 2); return; }
  P.inv[k]--; chime(); toast('Used ' + ITEMS.find(i => i[0] === k)[1], 1.5);
}
addEventListener('keydown', e => { if (!locked || mapOpen) return; if (e.code === 'KeyI') invOpen = !invOpen; const k = { Digit1: 'herb', Digit2: 'tonic', Digit3: 'meat' }[e.code]; if (k) useItem(k); });
function invUI(tw) {
  const key = JSON.stringify(P.inv) + P.ammo + invOpen + locked;
  if (key !== invKey) {
    invKey = key; barEl.style.display = locked ? 'flex' : 'none'; invEl.style.display = invOpen && locked ? 'flex' : 'none';
    for (const s of barSlots.concat(invSlots)) { const n = s.k === 'arrow' ? P.ammo : P.inv[s.k]; s.cnt.textContent = n; s.el.style.opacity = n ? 1 : 0.4; }
    for (const s of barSlots) ICONS.draw(s.k, s.cv, -0.55);
  }
  if (invOpen && locked) for (const s of invSlots) ICONS.draw(s.k, s.cv, tw * 1.1 + s.k.length);
}

/* ---------- player body, bow, camera modes, arrow fx, adaptive performance ---------- */
let camMode = 0;
const stuck = [], TN = 140, tp = new Float32Array(TN * 3).fill(-999), tc = new Float32Array(TN * 3), tl = new Float32Array(TN); let th = 0;
const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(tp, 3)); tg.setAttribute('color', new THREE.BufferAttribute(tc, 3));
const trail = new THREE.Points(tg, new THREE.PointsMaterial({ size: 0.14, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false })); trail.frustumCulled = false; scene.add(trail);
function trailAdd(p) { tp[th * 3] = p.x; tp[th * 3 + 1] = p.y; tp[th * 3 + 2] = p.z; tl[th] = 0.35; th = (th + 1) % TN; }
function stickArrow(a) {
  a.m.position.addScaledVector(a.v.clone().normalize(), 0.25); stuck.push({ m: a.m, q: a.m.quaternion.clone(), t: 0 });
  if (stuck.length > 40) scene.remove(stuck.shift().m);
}
function makeBow() {
  const g = new THREE.Group(), wood = new THREE.MeshStandardMaterial({ color: 0x6b4423, roughness: 0.7 });
  g.add(new THREE.Mesh(new THREE.TorusGeometry(0.5, 0.014, 6, 18, Math.PI * 0.7).rotateZ(-0.35 * Math.PI).translate(-0.227, 0, 0).rotateY(Math.PI / 2), wood));
  const sp = new Float32Array(9), sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.BufferAttribute(sp, 3));
  const str = new THREE.Line(sg, new THREE.LineBasicMaterial({ color: 0xeeeeee })); str.frustumCulled = false; g.add(str);
  const arr = new THREE.Mesh(arrowG, arrowM); g.add(arr);
  g.set = (pull, show) => { sp.set([0, 0.445, 0, 0, 0, pull, 0, -0.445, 0]); sg.attributes.position.needsUpdate = true; arr.visible = show; arr.position.set(0, 0, pull - 0.35); };
  g.set(0, false); return g;
}
function makePlayer() {
  const mat = c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.9 });
  const box = (w, h, d, c, x, y, z, par) => { const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat(c)); m.position.set(x, y, z); m.castShadow = true; par.add(m); return m; };
  const piv = (x, y, z, par) => { const g = new THREE.Group(); g.position.set(x, y, z); par.add(g); return g; };
  const body = new THREE.Group(), skin = 0xc99672, cloth = 0x4a5a3c, leather = 0x4b3425, pants = 0x3b3128;
  const part = (g, c, x, y, z, par, r = 0.85) => { const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ color: c, roughness: r })); m.position.set(x, y, z); m.castShadow = true; par.add(m); return m; };
  const cyl = (a, b, h, y = 0) => new THREE.CylinderGeometry(a, b, h, 14).translate(0, y, 0), sph = (r, x = 1, y = 1, z = 1) => new THREE.SphereGeometry(r, 18, 14).scale(x, y, z);
  part(new THREE.LatheGeometry([[0, 0.82], [0.2, 0.84], [0.215, 0.95], [0.19, 1.1], [0.215, 1.28], [0.24, 1.42], [0.2, 1.52], [0.08, 1.58], [0, 1.6]].map(([r, y]) => new THREE.Vector2(r, y)), 22), cloth, 0, 0, 0, body).scale.z = 0.62;
  part(cyl(0.2, 0.27, 0.34), cloth, 0, 0.8, 0, body).scale.z = 0.66; part(sph(0.2, 1, 0.55, 0.7), pants, 0, 0.88, 0, body);
  part(cyl(0.2, 0.2, 0.1), leather, 0, 0.9, 0, body).scale.z = 0.64; part(new THREE.BoxGeometry(0.07, 0.08, 0.03), 0xc9a64a, 0, 0.9, -0.14, body);
  part(new THREE.BoxGeometry(0.44, 0.78, 0.05), 0x6e2a22, 0, 1.05, 0.2, body).rotation.x = 0.1;
  part(cyl(0.065, 0.055, 0.5), leather, 0.12, 1.32, 0.24, body).rotation.z = 0.22; for (let k = 0; k < 3; k++) part(cyl(0.012, 0.012, 0.14), 0xe8dcc0, 0.15 + k * 0.012, 1.62 + k * 0.01, 0.24, body);
  part(cyl(0.062, 0.07, 0.12), skin, 0, 1.6, 0, body); part(new THREE.TorusGeometry(0.1, 0.035, 8, 18).rotateX(Math.PI / 2), 0x8a3a2a, 0, 1.56, 0, body);
  const head = new THREE.Group(); head.position.set(0, 1.64, 0); body.add(head);
  part(sph(0.115, 0.95, 1.2, 1.08), skin, 0, 0.1, 0, head, 0.7); part(sph(0.122, 1, 1.05, 1.1), 0x3a2a1d, 0, 0.14, 0.03, head); part(sph(0.02), skin, 0, 0.09, -0.125, head, 0.7);
  part(new THREE.BoxGeometry(0.05, 0.008, 0.01), 0x8a4a40, 0, 0.045, -0.115, head); for (const sx of [-1, 1]) { part(sph(0.02, 1, 0.7, 0.5), 0xf0ece4, sx * 0.04, 0.13, -0.108, head); part(new THREE.BoxGeometry(0.05, 0.012, 0.012), 0x2a1c12, sx * 0.04, 0.16, -0.11, head); part(sph(0.011), 0x2a1a10, sx * 0.04, 0.13, -0.118, head); part(sph(0.025, 0.6, 1.4, 0.6), skin, sx * 0.118, 0.1, 0, head); }
  const leg = x => {
    const p = new THREE.Group(); p.position.set(x, 0.9, 0); body.add(p);
    part(cyl(0.125, 0.092, 0.45, -0.225), pants, 0, 0, 0, p); part(sph(0.095), pants, 0, -0.45, 0, p); part(cyl(0.088, 0.066, 0.4, -0.2), pants, 0, -0.45, 0, p);
    part(cyl(0.095, 0.1, 0.26, -0.13), leather, 0, -0.72, 0, p); part(sph(0.07, 1.1, 0.6, 2.1), leather, 0, -0.87, -0.06, p); return p;
  };
  const arm = x => {
    const p = new THREE.Group(); p.position.set(x, 1.48, 0); body.add(p);
    part(sph(0.085), cloth, 0, 0, 0, p); part(cyl(0.07, 0.056, 0.3, -0.15), cloth, 0, 0, 0, p); part(sph(0.058), cloth, 0, -0.3, 0, p);
    part(cyl(0.056, 0.044, 0.28, -0.14), cloth, 0, -0.3, 0, p); part(sph(0.05, 1, 1.15, 0.8), skin, 0, -0.63, 0, p); part(cyl(0.052, 0.052, 0.05), leather, 0, -0.57, 0, p); return p;
  };
  const lL = leg(-0.12), lR = leg(0.12), aL = arm(-0.33), aR = arm(0.33);
  const bowB = makeBow(); bowB.position.set(0, -0.62, 0); bowB.rotation.x = -Math.PI / 2; aL.add(bowB);
  scene.add(body);
  const vm = new THREE.Group(), bowV = makeBow(); bowV.scale.setScalar(0.6); vm.add(bowV); box(0.07, 0.07, 0.35, 0xd2a07a, 0, -0.06, 0.2, vm).rotation.x = 0.3;
  vm.position.set(-0.24, -0.2, -0.5); camera.add(vm);
  let prev = false, snap = 0, aimT = 0, aim = 0, ph = 0; const V = new THREE.Vector3(), Qw = new THREE.Quaternion(), AX = new THREE.Vector3(1, 0, 0), fwd = new THREE.Vector3();
  return dt => {
    const sp = Math.hypot(P.vx, P.vz), cp = Math.min(1, charge / 0.9);
    if (prev && !drawing) snap = 0.35; prev = drawing; snap = Math.max(0, snap - dt); aimT = drawing ? 1.4 : aimT - dt; aim = lerp(aim, aimT > 0 ? 1 : 0, Math.min(1, dt * 8));
    const pull = drawing ? cp * 0.38 : 0.12 * Math.sin(snap * 90) * snap / 0.35;
    bowB.set(pull, drawing); bowV.set(pull, drawing); vm.position.z = -0.5 + (drawing ? cp * 0.06 : 0) + snap * 0.12;
    vm.visible = camMode === 0; body.visible = camMode !== 0;
    for (let i = 0; i < TN; i++) { tl[i] -= dt; const f = Math.max(0, tl[i]) / 0.35; tc[i * 3] = tc[i * 3 + 1] = tc[i * 3 + 2] = f * 0.8; if (tl[i] <= 0) tp[i * 3 + 1] = -999; }
    tg.attributes.position.needsUpdate = tg.attributes.color.needsUpdate = true;
    for (const a of stuck) { a.t += dt; a.m.quaternion.copy(a.q).multiply(Qw.setFromAxisAngle(AX, Math.sin(a.t * 45) * 0.14 * Math.exp(-a.t * 7))); }
    if (camMode === 0) return;
    ph += sp * dt * 1.7; const amp = Math.min(1, sp / 4) * (P.ground ? 1 : 0.3), sw = Math.sin(ph);
    body.position.set(P.x, P.y, P.z); body.rotation.y = P.yaw; body.scale.y = 1 - 0.25 * P.crouch; head.rotation.x = P.pitch * 0.7;
    lL.rotation.x = sw * 0.8 * amp; lR.rotation.x = -sw * 0.8 * amp;
    aL.rotation.x = lerp(0.5 - sw * 0.2 * amp, Math.PI / 2 + P.pitch, aim); aR.rotation.x = lerp(sw * 0.6 * amp, Math.PI / 2 + P.pitch, aim);
    const eh = C.eye - P.crouch * 0.7, cy = Math.cos(P.yaw), sy = Math.sin(P.yaw), cpz = Math.cos(P.pitch);
    const hx = P.x, hy = P.y + eh, hz = P.z;
    if (camMode === 1) {
      fwd.set(-sy * cpz, Math.sin(P.pitch), -cy * cpz); let dist = 4.2;
      for (let t = 0.5; t <= 4.2; t += 0.5) if (hy - fwd.y * t < heightAt(hx - fwd.x * t, hz - fwd.z * t) + 0.35) { dist = Math.max(0.6, t - 0.5); break; }
      V.set(hx - fwd.x * dist + cy * 0.5, hy - fwd.y * dist + 0.4, hz - fwd.z * dist - sy * 0.5);
      V.y = Math.max(V.y, heightAt(V.x, V.z) + 0.4); camera.position.copy(V); camera.lookAt(V.x + fwd.x, V.y + fwd.y, V.z + fwd.z);
    } else {
      V.set(hx - sy * 3.2, hy + 0.3, hz - cy * 3.2); V.y = Math.max(V.y, heightAt(V.x, V.z) + 0.4); camera.position.copy(V); camera.lookAt(hx, hy - 0.1, hz);
    }
  };
}
addEventListener('keydown', e => {
  if (e.code === 'KeyV' && locked) { camMode = (camMode + 1) % 3; toast(['First person', 'Third person', 'Second person (facing you)'][camMode], 1.6); $('cross').style.display = camMode === 2 ? 'none' : ''; }
});
let pr = Math.min(devicePixelRatio, 1.25), prMax = Math.min(devicePixelRatio, 2), pAcc = 0, pN = 0, good = 0, bad = 0, pFrame = 0, lowQ = false, tierAge = 0;
renderer.setPixelRatio(pr);
function perf(dt) {
  pFrame++; pAcc += dt; pN++; tierAge += dt;
  if (pAcc > 0.6) {
    const f = pN / pAcc; pAcc = pN = 0; const old = pr;
    if (qMode < 0) {                                   // AUTO: first lower the resolution, then the detail; raise both again when there is headroom
      if (f < 52) {
        good = 0; bad++;
        if (pr > 0.62) pr = Math.max(0.6, pr - (f < 35 ? 0.2 : f < 45 ? 0.12 : 0.06));
        else if (bad >= 2 && qTier > 0) { setTier(qTier - 1); tierCap = qTier; pr = 0.85; bad = 0; tierAge = 0; }
      } else if (f >= 58) {
        bad = 0;
        if (++good >= 8) {
          good = 0;
          if (pr < prMax - 0.01 && pr < 1.6) pr = Math.min(prMax, pr + 0.08);
          else if (qTier < tierCap && tierAge > 25) { setTier(qTier + 1); tierAge = 0; }
        }
      }
    }
    lowQ = f < 40 && pr <= 0.65;
    if (pr !== old) { renderer.setPixelRatio(pr); resize(); }
  }
  renderer.shadowMap.autoUpdate = (shEvery === 1 && !lowQ) || (pFrame & 1) === 0;
}

/* ---------- ATLAS 3D map (M): the whole of Ethiopia, real elevation, layers, travel ---------- */
let mapOpen = false, map3d = null, travelBusy = false, ATLAS = null, atlasBroken = false;
// goals for the map camera (smoothed by the atlas): mouse rotates, wheel zooms, WASD pans
const MV = { yaw: 0, pitch: 0.95, dist: 1850, tx: 0, tz: 0, exag: 8 };
const mapHint = document.createElement('div');
mapHint.style.cssText = 'position:fixed;left:50%;bottom:22px;transform:translateX(-50%);padding:8px 18px;background:rgba(16,22,20,.7);color:#f2efe6;border-radius:8px;font-size:15px;display:none;pointer-events:none';
mapHint.textContent = 'Local map (the real map of Ethiopia is still loading): move the mouse to rotate   |   Scroll to zoom   |   M to close';
document.body.appendChild(mapHint);
function setMap(on) {
  if (on && !map3d) return; if (on === mapOpen) return; mapOpen = on;
  const ethOk = !!window.ETH3D && !atlasBroken;
  $('map').style.display = on ? 'none' : ''; $('cmap').style.display = on ? 'none' : ''; $('goal').style.display = on ? 'none' : '';
  $('hud').style.visibility = on || !FXS.hud ? 'hidden' : ''; $('cross').style.display = on || camMode === 2 ? 'none' : '';
  mapHint.style.display = on && !ethOk ? 'block' : 'none';
  if (on) {
    drawing = false; charge = 0;
    if (ethOk) {
      try { if (!ATLAS) ATLAS = createAtlas3D(); ATLAS.open(); } catch (e) { console.error('Atlas 3D failed, using the local map:', e); atlasBroken = true; ATLAS = null; MV.dist = 2300; MV.yaw = 0; MV.pitch = 0.95; mapHint.style.display = 'block'; }
    } else { MV.dist = 2300; MV.yaw = 0; MV.pitch = 0.95; }
  } else if (ATLAS) ATLAS.close();
}
addEventListener('keydown', e => { if (e.code === 'KeyM' && locked) setMap(!mapOpen); else if (mapOpen && ATLAS && !e.repeat) ATLAS.key(e.code); });
document.addEventListener('pointerlockchange', () => { if (!document.pointerLockElement) setMap(false); });
addEventListener('wheel', e => { if (mapOpen) MV.dist = clamp(MV.dist * (1 + Math.sign(e.deltaY) * 0.12), window.ETH3D && !atlasBroken ? 22 : 300, window.ETH3D && !atlasBroken ? 2900 : 4500); }, { passive: true });
addEventListener('mousedown', e => { if (e.button === 0 && mapOpen && locked && ATLAS) ATLAS.click(); });

// full-screen "travelling" veil while the next part of Ethiopia loads
function travelOverlay(text) {
  let el = document.getElementById('atlas-travel');
  if (!el) {
    el = document.createElement('div'); el.id = 'atlas-travel';
    el.style.cssText = 'position:fixed;inset:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;background:radial-gradient(ellipse at center,rgba(10,18,22,.55),rgba(5,9,11,.92));color:#f2efe6;font-family:Georgia,serif;pointer-events:none;opacity:0;transition:opacity .35s;z-index:30;text-align:center';
    el.innerHTML = '<div style="font-size:13px;letter-spacing:.35em;color:#d6c47a">TRAVELLING</div><div id="atlas-travel-t" style="font-size:26px"></div><div style="font-size:14px;color:#b8b4a6">Loading the real land of Ethiopia…</div>';
    document.body.appendChild(el);
  }
  if (text) document.getElementById('atlas-travel-t').textContent = text;
  el.style.opacity = text ? '1' : '0';
}

function makeMap3DLocal() {
  const ms = new THREE.Scene(); ms.background = new THREE.Color(0x0d1412);
  const mc = new THREE.PerspectiveCamera(45, 1, 10, 20000);
  ms.add(new THREE.HemisphereLight(0xdfeaff, 0x3a3226, 0.9));
  const dl = new THREE.DirectionalLight(0xfff1d6, 2.0); dl.position.set(-1500, 2000, 1000); ms.add(dl);
  const EX = 1.5, SEG = 220, g = new THREE.PlaneGeometry(C.size, C.size, SEG, SEG).rotateX(-Math.PI / 2), p = g.attributes.position, hs = new Float32Array(p.count), col = new Float32Array(p.count * 3);
  for (let i = 0; i < p.count; i++) { const h = heightAt(p.getX(i), p.getZ(i)); hs[i] = h; p.setY(i, h * EX); }
  g.computeVertexNormals(); const n = g.attributes.normal;
  const mix = (a, b, t) => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
  for (let i = 0; i < p.count; i++) {
    const h = hs[i], up = n.getY(i); let c;
    if (h < C.waterLevel) c = [.1, .28, .36];
    else if (h < 2.5) c = [.78, .7, .5];
    else if (h < 36) c = mix([.17, .32, .1], [.4, .46, .17], clamp(h / 36, 0, 1));
    else if (h < 55) c = mix([.4, .38, .35], [.55, .53, .5], (h - 36) / 19);
    else c = [.93, .95, 1];
    if (h > 2.5 && up < 0.8) c = mix(c, [.42, .39, .36], clamp((0.8 - up) * 3, 0, 0.85));
    col[i * 3] = c[0]; col[i * 3 + 1] = c[1]; col[i * 3 + 2] = c[2];
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 3));
  ms.add(new THREE.Mesh(g, new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95 })));
  const wp = new THREE.Mesh(new THREE.PlaneGeometry(C.size * 1.6, C.size * 1.6).rotateX(-Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x2f7f9a, transparent: true, opacity: 0.72, roughness: 0.2 }));
  wp.position.y = C.waterLevel * EX + 0.5; ms.add(wp);
  const frame = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(C.size, 4, C.size)), new THREE.LineBasicMaterial({ color: 0x8a9a92 })); frame.position.y = -2; ms.add(frame);
  const ground = x => heightAt(x[0], x[1]) * EX;
  const beamG = new THREE.CylinderGeometry(1, 1, 400, 8, 1, true).translate(0, 200, 0);
  /* player */
  const pg = new THREE.Group(), pm = new THREE.Mesh(new THREE.ConeGeometry(22, 70, 4).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffe070 }));
  pm.position.y = 45; const ring = new THREE.Mesh(new THREE.TorusGeometry(34, 3, 6, 28).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffffff })); ring.position.y = 45;
  pg.add(pm, ring, new THREE.Mesh(beamG, new THREE.MeshBasicMaterial({ color: 0xffe070, transparent: true, opacity: 0.35, depthWrite: false }))); pg.children[2].scale.set(3, 1, 3); ms.add(pg);
  /* village */
  if (site) { const v = new THREE.Mesh(new THREE.BoxGeometry(80, 14, 34), new THREE.MeshBasicMaterial({ color: 0xe8c27a })); v.position.set(site[0], ground([site[0], site[1]]) + 8, site[1]); ms.add(v); }
  /* relics */
  const rl = [], rm = new THREE.MeshBasicMaterial({ color: 0x6ff5e4 }), rb = new THREE.MeshBasicMaterial({ color: 0x66f0e0, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, depthWrite: false });
  for (const r of P.relics || []) { const gr = new THREE.Group(), gem = new THREE.Mesh(new THREE.OctahedronGeometry(16).scale(1, 1.7, 1), rm); gem.position.y = 40; gr.add(gem, new THREE.Mesh(beamG, rb)); gr.children[1].scale.set(5, 1, 5); gr.position.set(r.x, ground([r.x, r.z]), r.z); ms.add(gr); rl.push([r, gr, gem]); }
  let t = 0;
  return {
    render(dt) {
      t += 0.016; const sc = MV.dist / 2300, cp = Math.cos(MV.pitch);
      mc.position.set(Math.sin(MV.yaw) * cp * MV.dist, Math.sin(MV.pitch) * MV.dist, Math.cos(MV.yaw) * cp * MV.dist); mc.lookAt(0, 0, 0);
      mc.aspect = innerWidth / innerHeight; mc.updateProjectionMatrix();
      pg.position.set(P.x, heightAt(P.x, P.z) * EX, P.z); pg.scale.setScalar(sc); pm.rotation.y = P.yaw; ring.scale.setScalar(1 + 0.15 * Math.sin(t * 5));
      for (const [r, gr, gem] of rl) { gr.visible = !r.got; gr.scale.setScalar(sc); gem.rotation.y = t * 2; }
      renderer.render(ms, mc);
    }
  };
}

function makeMap3D() {
  let local = null;
  return {
    render(dt) {
      if (window.ETH3D && !atlasBroken) {
        try { if (!ATLAS) { ATLAS = createAtlas3D(); ATLAS.open(); mapHint.style.display = 'none'; } ATLAS.render(dt); return; }
        catch (e) { console.error('Atlas 3D failed, using the local map:', e); atlasBroken = true; ATLAS = null; mapHint.style.display = 'block'; }
      }
      local = local || makeMap3DLocal(); local.render(dt);
    }
  };
}

function createAtlas3D() {
  const D = window.ETH3D, ms = new THREE.Scene(), mc = new THREE.PerspectiveCamera(40, 1, 1, 12000), OW = D.OW, OH = D.OH, hw = OW / 2, hh = OH / 2, inv = 1 / D.mpp;
  ms.background = new THREE.Color(0x091015);
  ms.add(new THREE.HemisphereLight(0xeaf2ff, 0x59514a, 0.95));
  const sun = new THREE.DirectionalLight(0xfff0d8, 0.85); sun.position.set(-700, 900, -500); ms.add(sun);
  const encoding = renderer.outputEncoding === THREE.sRGBEncoding ? THREE.sRGBEncoding : THREE.LinearEncoding;

  /* ---------- the land: real elevation mesh, true scale in Y (the group is stretched by the height exaggeration) ---------- */
  const land = new THREE.Group(); ms.add(land);
  const STEP = 3, nx = Math.floor((OW - 1) / STEP) + 1, ny = Math.floor((OH - 1) / STEP) + 1;
  const hAt = (px, py) => { let s = 0; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) { const k = clamp(py + dy, 0, OH - 1) * OW + clamp(px + dx, 0, OW - 1); let e = D.EL[k]; if (!D.IN[k] && e < 0) e = 0; s += e; } return s / 9 * inv; };
  const pos = new Float32Array(nx * ny * 3), uv = new Float32Array(nx * ny * 2), hts = new Float32Array(nx * ny);
  for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
    const px = Math.min(i * STEP, OW - 1), py = Math.min(j * STEP, OH - 1), k = j * nx + i, y = hAt(px, py);
    pos[k * 3] = px - hw; pos[k * 3 + 1] = y; pos[k * 3 + 2] = py - hh; uv[k * 2] = px / (OW - 1); uv[k * 2 + 1] = 1 - py / (OH - 1); hts[k] = y;
  }
  const idx = new Uint32Array((nx - 1) * (ny - 1) * 6); let q = 0;
  for (let j = 0; j < ny - 1; j++) for (let i = 0; i < nx - 1; i++) { const a = j * nx + i, b = a + 1, c = a + nx, d = c + 1; idx[q++] = a; idx[q++] = c; idx[q++] = b; idx[q++] = b; idx[q++] = c; idx[q++] = d; }
  const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(pos, 3)); tg.setAttribute('uv', new THREE.BufferAttribute(uv, 2)); tg.setIndex(new THREE.BufferAttribute(idx, 1)); tg.computeVertexNormals();
  let tex = new THREE.CanvasTexture(D.layerCanvas()); tex.encoding = encoding; tex.anisotropy = AN;
  const terrain = new THREE.Mesh(tg, new THREE.MeshLambertMaterial({ map: tex })); land.add(terrain);
  // the diorama edge: a dark skirt around the map
  {
    const sp = [], sc = [], si = [], BOT = -0.9, add = (a, b) => { const v = sp.length / 3; sp.push(pos[a * 3], pos[a * 3 + 1], pos[a * 3 + 2], pos[b * 3], pos[b * 3 + 1], pos[b * 3 + 2], pos[b * 3], BOT, pos[b * 3 + 2], pos[a * 3], BOT, pos[a * 3 + 2]); sc.push(.34, .3, .24, .34, .3, .24, .08, .07, .06, .08, .07, .06); si.push(v, v + 1, v + 2, v, v + 2, v + 3); };
    for (let i = 0; i < nx - 1; i++) { add(i, i + 1); add((ny - 1) * nx + i, (ny - 1) * nx + i + 1); }
    for (let j = 0; j < ny - 1; j++) { add(j * nx, (j + 1) * nx); add(j * nx + nx - 1, (j + 1) * nx + nx - 1); }
    const sg = new THREE.BufferGeometry(); sg.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3)); sg.setAttribute('color', new THREE.Float32BufferAttribute(sc, 3)); sg.setIndex(si);
    land.add(new THREE.Mesh(sg, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.DoubleSide })));
  }
  // a soft glowing table under the map
  {
    const cv = document.createElement('canvas'); cv.width = cv.height = 256; const g = cv.getContext('2d'), gr = g.createRadialGradient(128, 128, 10, 128, 128, 128);
    gr.addColorStop(0, 'rgba(60,96,96,.55)'); gr.addColorStop(0.6, 'rgba(30,52,56,.28)'); gr.addColorStop(1, 'rgba(10,16,20,0)'); g.fillStyle = gr; g.fillRect(0, 0, 256, 256);
    g.strokeStyle = 'rgba(160,200,200,.10)'; g.lineWidth = 1; for (let r = 30; r < 128; r += 24) { g.beginPath(); g.arc(128, 128, r, 0, 6.3); g.stroke(); }
    const t = new THREE.CanvasTexture(cv), m = new THREE.Mesh(new THREE.CircleGeometry(2900, 72).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false })); m.position.y = -8.5; ms.add(m);
  }
  // the border: a glowing curtain standing on the line, plus a crisp line
  {
    const pts = []; const B = D.BORDER.map(([lo, la]) => D.pos(la, lo));
    for (let i = 0; i < B.length; i++) { const a = B[i], b = B[(i + 1) % B.length], n = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / 3)); for (let s = 0; s < n; s++) pts.push([a[0] + (b[0] - a[0]) * s / n, a[1] + (b[1] - a[1]) * s / n]); }
    pts.push(pts[0]);
    const cp = [], cu = [], ci = [], lp = [];
    pts.forEach(([px, py], k) => { const y = hAt(Math.round(px), Math.round(py)); cp.push(px - hw, y, py - hh, px - hw, y + 0.75, py - hh); cu.push(0, 0, 0, 1); lp.push(new THREE.Vector3(px - hw, y + 0.03, py - hh)); if (k < pts.length - 1) { const v = k * 2; ci.push(v, v + 1, v + 3, v, v + 3, v + 2); } });
    const cg = new THREE.BufferGeometry(); cg.setAttribute('position', new THREE.Float32BufferAttribute(cp, 3)); cg.setAttribute('uv', new THREE.Float32BufferAttribute(cu, 2)); cg.setIndex(ci);
    const gc = document.createElement('canvas'); gc.width = 4; gc.height = 64; const gg = gc.getContext('2d'), gl = gg.createLinearGradient(0, 0, 0, 64); gl.addColorStop(0, 'rgba(255,255,255,0)'); gl.addColorStop(1, 'rgba(255,241,192,.8)'); gg.fillStyle = gl; gg.fillRect(0, 0, 4, 64);
    land.add(new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(gc), transparent: true, side: THREE.DoubleSide, depthWrite: false })));
    land.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(lp), new THREE.LineBasicMaterial({ color: 0xffffff })));
  }
  // your journey, as a golden line over the land
  let trailLine = null, trailRev = -1;
  function buildTrail() {
    trailRev = D.trailRev; if (trailLine) { land.remove(trailLine); trailLine.geometry.dispose(); trailLine = null; }
    const p = []; for (const sg of D.trail()) for (let i = 1; i < sg.length; i++) for (const [la, lo] of [sg[i - 1], sg[i]]) { const [px, py] = D.pos(la, lo); p.push(px - hw, hAt(Math.round(clamp(px, 0, OW - 1)), Math.round(clamp(py, 0, OH - 1))) + 0.06, py - hh); }
    if (!p.length) return; const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.Float32BufferAttribute(p, 3));
    trailLine = new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: 0xffd45a })); trailLine.frustumCulled = false; land.add(trailLine);
  }

  /* ---------- markers (not stretched: their height is placed by hand every frame) ---------- */
  const marks = new THREE.Group(); ms.add(marks);
  const beamG = new THREE.CylinderGeometry(1, 1, 60, 8, 1, true).translate(0, 30, 0);
  const gemG = new THREE.OctahedronGeometry(2.4).scale(1, 1.7, 1), ringG = new THREE.TorusGeometry(1, 0.09, 6, 36).rotateX(Math.PI / 2);
  const mGem = new THREE.MeshBasicMaterial({ color: 0x6ff5e4 }), mBeam = new THREE.MeshBasicMaterial({ color: 0x66f0e0, transparent: true, opacity: 0.32, blending: THREE.AdditiveBlending, depthWrite: false }), mDead = new THREE.MeshBasicMaterial({ color: 0x7a7f7c }), mRing = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85 });
  const gy = (px, py) => D.elevAt(px, py) * inv * cur.exag;
  const toXZ = (lat, lon) => { const [px, py] = D.pos(lat, lon); return [px, py]; };
  const relics = LM.map(([n, la, lo], i) => {
    const [px, py] = toXZ(la, lo), g = new THREE.Group(), gem = new THREE.Mesh(gemG, mGem), beam = new THREE.Mesh(beamG, mBeam), ring = new THREE.Mesh(ringG, mRing);
    beam.scale.set(0.9, 1, 0.9); g.add(gem, beam, ring); marks.add(g); return { i, n, la, lo, px, py, g, gem, beam, ring, e: D.elevAt(px, py) };
  });
  // you
  const you = new THREE.Group(), youCone = new THREE.Mesh(new THREE.ConeGeometry(3, 9, 4).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xffe070 })), youRing = new THREE.Mesh(new THREE.TorusGeometry(5.2, 0.55, 6, 32).rotateX(Math.PI / 2), new THREE.MeshBasicMaterial({ color: 0xff3a2a })), youBeam = new THREE.Mesh(beamG, new THREE.MeshBasicMaterial({ color: 0xffe070, transparent: true, opacity: 0.4, depthWrite: false }));
  youCone.position.y = 6; youRing.position.y = 6; youBeam.scale.set(1, 1.4, 1); you.add(youCone, youRing, youBeam); marks.add(you);
  // the aim point (where the crosshair rests) and the route line from you to it
  const aim = new THREE.Group(), aimRing = new THREE.Mesh(ringG, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, depthTest: false })), aimDot = new THREE.Mesh(new THREE.ConeGeometry(1.1, 3.2, 12).rotateX(Math.PI), new THREE.MeshBasicMaterial({ color: 0xffe9a0, depthTest: false }));
  aimRing.scale.setScalar(5); aimRing.renderOrder = 8; aimDot.renderOrder = 8; aimDot.position.y = 5; aim.add(aimRing, aimDot); marks.add(aim);
  const RN = 48, routeG = new THREE.BufferGeometry(); routeG.setAttribute('position', new THREE.BufferAttribute(new Float32Array(RN * 3), 3));
  const route = new THREE.Line(routeG, new THREE.LineBasicMaterial({ color: 0xffe070, transparent: true, opacity: 0.9, depthTest: false })); route.frustumCulled = false; route.renderOrder = 7; marks.add(route);
  // pins
  let pinObjs = [], pinRev = -1;
  const flagM = new THREE.MeshBasicMaterial({ color: 0xff5fa2, side: THREE.DoubleSide }), poleM = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const poleG = new THREE.CylinderGeometry(0.25, 0.25, 12, 5).translate(0, 6, 0), flagG = new THREE.BufferGeometry(); flagG.setAttribute('position', new THREE.Float32BufferAttribute([0, 12, 0, 6.5, 10, 0, 0, 8, 0], 3)); flagG.setIndex([0, 1, 2]);
  function buildPins() {
    pinRev = D.pinRev; for (const p of pinObjs) { marks.remove(p.g); } pinObjs = [];
    D.pins().forEach(([la, lo], i) => { const [px, py] = toXZ(la, lo), g = new THREE.Group(); g.add(new THREE.Mesh(poleG, poleM), new THREE.Mesh(flagG, flagM)); marks.add(g); pinObjs.push({ g, px, py, la, lo, i }); });
  }

  /* ---------- labels: screen-size-constant sprites with level-of-detail ---------- */
  const labels = [];
  function labelTex(text, o) {
    const cv = document.createElement('canvas'), g = cv.getContext('2d'), fs = (o.fs || 13) * 2, font = (o.italic ? 'italic ' : '') + (o.bold ? 'bold ' : '') + fs + 'px Georgia', ls = o.ls || 0;
    if ('letterSpacing' in g) g.letterSpacing = ls + 'px'; g.font = font; const w = Math.ceil(g.measureText(text).width) + 28, bh = fs + 22, h = bh + (o.dot ? 20 : 0);
    cv.width = w; cv.height = h; if ('letterSpacing' in g) g.letterSpacing = ls + 'px'; g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineJoin = 'round';
    g.lineWidth = 8; g.strokeStyle = 'rgba(5,10,12,.88)'; g.strokeText(text, w / 2, bh / 2); g.fillStyle = o.color; g.fillText(text, w / 2, bh / 2);
    if (o.dot) { g.beginPath(); g.arc(w / 2, h - 10, o.dotR || 6, 0, 6.3); g.fillStyle = o.dotColor || '#fff'; g.fill(); g.lineWidth = 2.5; g.strokeStyle = '#000'; g.stroke(); }
    const t = new THREE.CanvasTexture(cv); t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; return { t, w, h };
  }
  function addLabel(text, lat, lon, o) {
    const { t, w, h } = labelTex(text, o), sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, transparent: true, depthTest: false, depthWrite: false }));
    sp.center.set(0.5, o.dot ? 0 : 0.5); sp.renderOrder = 10 + (o.prio || 0); marks.add(sp);
    const [px, py] = toXZ(lat, lon), L = { sp, w, h, px, py, kind: o.kind, prio: o.prio, e: D.elevAt(px, py), lift: o.lift || 0, size: o.size || 1, fade: o.fade || 1, lat, lon, name: text }; labels.push(L); return L;
  }
  for (const [n, la, lo, pr] of D.CITIES) addLabel(n, la, lo, { kind: 'city', prio: pr, fs: pr === 3 ? 15 : pr === 2 ? 13 : 11, bold: pr >= 2, color: pr === 3 ? '#ffe9a0' : '#ffffff', dot: true, dotR: pr === 3 ? 7 : 5, size: pr === 3 ? 1.1 : 1 });
  for (const [n, la, lo, kd, pr] of D.FEATURES) {
    if (kd === 'region') addLabel(n, la, lo, pr === 0 ? { kind: 'region', prio: 0, fs: 22, bold: true, ls: 10, color: '#ffffff', fade: 0.4, lift: 4 } : { kind: 'zone', prio: 1, fs: 13, italic: true, color: '#f1dfb8', lift: 4 });
    else if (kd === 'water') addLabel(n, la, lo, { kind: 'water', prio: pr, fs: 12, italic: true, color: '#a9dcff', lift: 3 });
    else addLabel(n, la, lo, { kind: 'peak', prio: pr, fs: 12, italic: true, color: kd === 'volcano' ? '#ffb27a' : '#f6e8cf', dot: true, dotR: 4, dotColor: kd === 'volcano' ? '#ff7a3a' : '#f4efe4' });
  }
  for (const hs of HS) addLabel(hs[0], hs[1], hs[2], { kind: 'site', prio: 2, fs: 11, italic: true, color: '#ffd9a0', dot: true, dotR: 4, dotColor: '#ffb347' });
  const relicLab = relics.map(r => ({ r, on: addLabel((r.i + 1) + '  ' + r.n, r.la, r.lo, { kind: 'relic', prio: 3, fs: 13, bold: true, italic: true, color: '#bffcf2', lift: 17 }), off: addLabel((r.i + 1) + '  ' + r.n, r.la, r.lo, { kind: 'relic', prio: 3, fs: 12, italic: true, color: '#9aa09c', lift: 9 }) }));

  /* ---------- interface (HTML) ---------- */
  const css = document.createElement('style');
  css.textContent = `#atlas{position:fixed;inset:0;pointer-events:none;display:none;font-family:Georgia,"Times New Roman",serif;color:#f2efe6;z-index:12}
#atlas .pn{background:rgba(10,18,22,.72);border:1px solid rgba(242,239,230,.18);border-radius:10px;backdrop-filter:blur(5px);box-shadow:0 2px 14px rgba(0,0,0,.4)}
#at-title{position:absolute;left:16px;top:14px;padding:9px 16px}#at-title b{letter-spacing:.28em;font-size:13px;color:#d6c47a;font-weight:400}#at-title div{font-size:15px;margin-top:2px}
#at-comp{position:absolute;right:16px;top:14px;width:62px;height:62px;border-radius:50%}#at-needle{position:absolute;inset:0;transition:transform .08s linear}
#at-needle:before{content:"";position:absolute;left:50%;top:7px;margin-left:-6px;border:6px solid transparent;border-bottom:20px solid #ff6b57;border-top:0}#at-needle:after{content:"";position:absolute;left:50%;bottom:7px;margin-left:-6px;border:6px solid transparent;border-top:20px solid #cfd6d2;border-bottom:0}
#at-needle i{position:absolute;left:0;right:0;top:-1px;text-align:center;font-style:normal;font-size:11px;font-weight:bold;color:#fff}
#at-rel{position:absolute;right:16px;top:88px;padding:10px 12px;font-size:13px;min-width:250px;line-height:1.55}#at-rel h4{margin:0 0 4px;font-weight:400;letter-spacing:.2em;font-size:11px;color:#d6c47a}
#at-rel div{display:flex;justify-content:space-between;gap:14px;white-space:nowrap}#at-rel div.sel{color:#fff;background:rgba(111,245,228,.16);margin:0 -6px;padding:0 6px;border-radius:5px}#at-rel div.got{color:#8d928f}#at-rel span{color:#b8b4a6}
#at-info{position:absolute;left:16px;bottom:16px;padding:12px 16px;min-width:300px;max-width:380px;line-height:1.5;font-size:14px}#at-info .nm{font-size:19px;color:#ffe9a0;margin-bottom:2px}#at-info .dim{color:#b8b4a6;font-size:13px}#at-info .go{margin-top:6px;font-size:13px;color:#7ff0b0}#at-info .no{margin-top:6px;font-size:13px;color:#ff9a8a}
#at-ret{position:absolute;left:50%;top:50%;width:46px;height:46px;margin:-23px;border:2px solid rgba(255,255,255,.85);border-radius:50%;box-shadow:0 0 0 1px rgba(0,0,0,.5)}#at-ret:before,#at-ret:after{content:"";position:absolute;background:rgba(255,255,255,.85)}#at-ret:before{left:50%;top:-9px;width:2px;height:64px;margin-left:-1px;-webkit-mask:linear-gradient(#000 0 14px,transparent 14px 50px,#000 50px);mask:linear-gradient(#000 0 14px,transparent 14px 50px,#000 50px)}#at-ret:after{top:50%;left:-9px;height:2px;width:64px;margin-top:-1px;-webkit-mask:linear-gradient(90deg,#000 0 14px,transparent 14px 50px,#000 50px);mask:linear-gradient(90deg,#000 0 14px,transparent 14px 50px,#000 50px)}
#at-ret.no{border-color:#ff7a66}#at-ret.no:before,#at-ret.no:after{background:#ff7a66}
#at-scale{position:absolute;right:16px;bottom:16px;padding:10px 14px}#at-lg{display:flex;gap:0;margin-bottom:6px}#at-lg i{display:block;width:34px;height:9px}#at-lgt{display:flex;justify-content:space-between;font-size:11px;color:#c9c5b6;margin-bottom:8px;gap:6px;flex-wrap:wrap}
#at-bar{height:6px;border:2px solid #fff;border-top:0;margin-top:2px}#at-bart{font-size:11px;color:#e8e4d6;display:block;text-align:center}
#at-keys{position:absolute;left:50%;bottom:14px;transform:translateX(-50%);padding:7px 16px;font-size:12px;color:#c9c5b6;text-align:center;line-height:1.6;max-width:min(560px,34vw)}#at-keys b{color:#fff;font-weight:600}
#at-prompt{position:absolute;left:50%;top:22%;transform:translateX(-50%);padding:10px 22px;font-size:17px;opacity:0;transition:opacity .25s;text-align:center;max-width:70vw}#at-prompt.on{opacity:1}
@media (max-width:1100px){#at-keys{display:none}}`;
  document.head.appendChild(css);
  const ui = document.createElement('div'); ui.id = 'atlas';
  ui.innerHTML = '<div id="at-title" class="pn"><b>ATLAS OF ETHIOPIA</b><div id="at-layer"></div></div><div id="at-comp" class="pn"><div id="at-needle"><i>N</i></div></div><div id="at-rel" class="pn"></div><div id="at-info" class="pn"></div><div id="at-ret"></div><div id="at-scale" class="pn"><div id="at-lg"></div><div id="at-lgt"></div><div id="at-bar"></div><span id="at-bart"></span></div><div id="at-keys" class="pn"><b>Mouse</b> rotate · <b>W A S D</b> move · <b>Wheel</b> zoom · <b>Q E</b> turn · <b>Z X</b> height<br><b>L</b> layer · <b>K</b> labels · <b>H</b> find me · <b>, .</b> relic sites · <b>P</b> pin · <b>Click / Enter</b> travel · <b>M</b> close</div><div id="at-prompt" class="pn"></div>';
  document.body.appendChild(ui);
  const el = id => ui.querySelector('#' + id), elInfo = el('at-info'), elRel = el('at-rel'), elRet = el('at-ret'), elPrompt = el('at-prompt');
  let promptT = 0; const say = (html, s = 3) => { elPrompt.innerHTML = html; elPrompt.classList.add('on'); clearTimeout(promptT); promptT = setTimeout(() => elPrompt.classList.remove('on'), s * 1000); };

  /* ---------- state ---------- */
  const cur = { yaw: 0, pitch: 1.2, dist: 2500, tx: 0, tz: 0, ty: 0, exag: MV.exag };
  let t = 0, uiT = 0, sel = -1, labelMode = 0, arm = null, info = null, lastLayer = null;
  const target = () => [cur.tx + hw, cur.tz + hh];
  const overview = () => { MV.yaw = 0; MV.pitch = 0.95; MV.dist = 1850; MV.tx = 0; MV.tz = 0; };
  const fly = (px, py, dist) => { MV.tx = clamp(px - hw, -hw, hw); MV.tz = clamp(py - hh, -hh, hh); MV.dist = Math.min(MV.dist, dist); };

  function setLegend() {
    const k = D.layerKind; el('at-layer').textContent = D.layerLabel(k);
    el('at-lg').innerHTML = D.LEGEND[k].map(([c]) => '<i style="background:rgb(' + c.map(Math.round) + ')"></i>').join('');
    el('at-lgt').innerHTML = D.LEGEND[k].filter(([, tx]) => tx).map(([, tx]) => '<span>' + tx + '</span>').join('');
    tex.image = D.layerCanvas(k); tex.needsUpdate = true; lastLayer = k;
  }
  const bearName = (a, b) => D.bearing(a, b);
  function refreshInfo() {
    const [px, py] = target(), [lat, lon] = D.unpos(px, py), e = D.elevAt(px, py), ok = D.inside(lon, lat), h = D.here(), nr = D.nearest(lat, lon);
    info = { lat, lon, e, ok, name: nr && nr.km < 14 ? nr.name : nr ? 'Near ' + nr.name : 'Ethiopia' };
    let h1 = '<div class="nm">' + info.name + '</div>';
    if (nr && nr.km >= 14) h1 += '<div class="dim">' + Math.round(nr.km) + ' km ' + nr.dir + ' of ' + nr.name + '</div>';
    h1 += '<div>' + Math.abs(lat).toFixed(3) + '°' + (lat >= 0 ? 'N' : 'S') + '  ' + lon.toFixed(3) + '°E</div>';
    h1 += '<div>' + D.fmtN(e) + ' m &nbsp;·&nbsp; ' + (ok ? D.zoneName(e) : 'outside Ethiopia') + '</div>';
    if (h) { const km = D.kmBetween(h, [lat, lon]); h1 += '<div class="dim">From you: ' + (km < 10 ? km.toFixed(1) : D.fmtN(km)) + ' km ' + (km > 0.5 ? bearName(h, [lat, lon]) : '') + ' &nbsp;·&nbsp; about ' + (km / 15.1 < 1 ? Math.max(1, Math.round(km / 15.1 * 60)) + ' min' : (km / 15.1).toFixed(km / 15.1 < 10 ? 1 : 0) + ' h') + ' on foot</div>'; }
    h1 += ok ? (window.ATLAS_TRAVEL ? '<div class="go">Click or press Enter to travel here</div>' : '<div class="dim">Travel needs the real-terrain world</div>') : '<div class="no">Move inside the white border to travel</div>';
    elInfo.innerHTML = h1; elRet.className = ok ? '' : 'no';
    // relic list
    const got = new Set(save.lm || []);
    elRel.innerHTML = '<h4>HERITAGE SITES  ' + got.size + ' / ' + LM.length + '</h4>' + relics.map(r => { const km = h ? D.kmBetween(h, [r.la, r.lo]) : null; return '<div class="' + (got.has(r.i) ? 'got ' : '') + (sel === r.i ? 'sel' : '') + '"><span style="color:inherit">' + (got.has(r.i) ? '✓ ' : '◆ ') + (r.i + 1) + '  ' + r.n + '</span><span>' + (km === null ? '' : D.fmtN(km) + ' km') + '</span></div>'; }).join('');
  }

  function travelRequest() {
    if (!info) return;
    if (!info.ok) { say('That is outside Ethiopia. Aim inside the white border.', 2.5); return; }
    if (!window.ATLAS_TRAVEL) { say('Fast travel is only available in the real-terrain world.', 3); return; }
    const now = performance.now();
    if (arm && now - arm.t < 5000 && Math.hypot(arm.lat - info.lat, arm.lon - info.lon) < 0.08) { arm = null; const n = info.name, la = info.lat, lo = info.lon; setMap(false); window.ATLAS_TRAVEL(la, lo, n); return; }
    arm = { t: now, lat: info.lat, lon: info.lon }; say('Travel to <b>' + info.name + '</b>?<br><span style="font-size:14px;color:#b8b4a6">Click or press Enter again to confirm</span>', 5);
  }

  /* ---------- per-frame ---------- */
  function input(dt) {
    const sp = cur.dist * 0.55 * dt, fx = -Math.sin(cur.yaw), fz = -Math.cos(cur.yaw), rx = Math.cos(cur.yaw), rz = -Math.sin(cur.yaw);
    let f = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 1 : 0), r = (keys.KeyD || keys.ArrowRight ? 1 : 0) - (keys.KeyA || keys.ArrowLeft ? 1 : 0);
    if (keys.ShiftLeft) { f *= 2.2; r *= 2.2; }
    MV.tx = clamp(MV.tx + (fx * f + rx * r) * sp, -hw, hw); MV.tz = clamp(MV.tz + (fz * f + rz * r) * sp, -hh, hh);
    MV.yaw += ((keys.KeyQ ? 1 : 0) - (keys.KeyE ? 1 : 0)) * dt * 1.4;
    const z = (keys.Equal || keys.NumpadAdd ? 1 : 0) - (keys.Minus || keys.NumpadSubtract ? 1 : 0); if (z) MV.dist = clamp(MV.dist * Math.exp(-z * dt * 1.6), 22, 2900);
    MV.pitch = clamp(MV.pitch, 0.14, 1.5); MV.dist = clamp(MV.dist, 22, 2900);
  }
  const sizeAt = (p, dist) => 2 * Math.tan(mc.fov * Math.PI / 360) * dist / innerHeight;
  function render(dt) {
    dt = clamp(dt || 0.016, 0.001, 0.05); t += dt; input(dt);
    const k = 1 - Math.exp(-dt * 9);
    cur.yaw = lerp(cur.yaw, MV.yaw, k); cur.pitch = lerp(cur.pitch, MV.pitch, k); cur.dist = lerp(cur.dist, MV.dist, k * 0.9); cur.tx = lerp(cur.tx, MV.tx, k); cur.tz = lerp(cur.tz, MV.tz, k); cur.exag = lerp(cur.exag, MV.exag, k);
    land.scale.y = cur.exag;
    const [tpx, tpy] = target(), ty = D.elevAt(tpx, tpy) * inv * cur.exag; cur.ty = lerp(cur.ty, ty, k);
    const cp = Math.cos(cur.pitch), cx = cur.tx + Math.sin(cur.yaw) * cp * cur.dist, cz = cur.tz + Math.cos(cur.yaw) * cp * cur.dist;
    let cy = cur.ty + Math.sin(cur.pitch) * cur.dist; const ground = D.elevAt(clamp(cx + hw, 0, OW - 1), clamp(cz + hh, 0, OH - 1)) * inv * cur.exag + 3; if (cy < ground) cy = ground;
    mc.position.set(cx, cy, cz); mc.lookAt(cur.tx, cur.ty, cur.tz); mc.aspect = innerWidth / innerHeight; mc.updateProjectionMatrix();
    if (lastLayer !== D.layerKind) setLegend();
    if (trailRev !== D.trailRev) buildTrail(); if (pinRev !== D.pinRev) buildPins();
    // markers
    const sc = clamp(cur.dist / 1000, 0.22, 2.2), got = new Set(save.lm || []), hr = D.here();
    for (const r of relics) {
      const f = got.has(r.i), y = r.e * inv * cur.exag, pulse = sel === r.i ? 1.5 + 0.2 * Math.sin(t * 6) : 1;
      r.g.position.set(r.px - hw, y, r.py - hh); r.g.scale.setScalar(sc * pulse); r.gem.material = f ? mDead : mGem; r.gem.scale.setScalar(f ? 0.55 : 1); r.gem.position.y = f ? 3 : 9 + Math.sin(t * 2 + r.i) * 1.2; r.gem.rotation.y = t * 2; r.beam.visible = !f; r.ring.visible = !f; r.ring.scale.setScalar(5.5 + Math.sin(t * 3 + r.i) * 0.6);
    }
    if (hr) { const [px, py] = D.pos(hr[0], hr[1]); you.visible = true; you.position.set(px - hw, gy(px, py), py - hh); you.scale.setScalar(sc); youCone.rotation.y = P.yaw; youRing.scale.setScalar(1 + 0.15 * Math.sin(t * 5)); } else you.visible = false;
    aim.position.set(cur.tx, ty + 0.3, cur.tz); aim.scale.setScalar(sc); aimRing.rotation.y = t * 0.8; aimDot.position.y = 7 + Math.sin(t * 3) * 1;
    for (const p of pinObjs) { p.g.position.set(p.px - hw, gy(p.px, p.py), p.py - hh); p.g.scale.setScalar(sc); }
    // route from you to the aim point (an arc that clears the mountains)
    if (hr && info && info.ok) {
      const [ax, ay2] = D.pos(hr[0], hr[1]), bx = tpx, by = tpy, len = Math.hypot(bx - ax, by - ay2), pa = routeG.attributes.position, h0 = gy(ax, ay2), h1 = gy(bx, by);
      for (let i = 0; i < RN; i++) { const u = i / (RN - 1), px = lerp(ax, bx, u), py = lerp(ay2, by, u), base = Math.max(gy(px, py) + 2, lerp(h0, h1, u)); pa.setXYZ(i, px - hw, base + Math.sin(u * Math.PI) * Math.min(60, len * 0.12) + 4, py - hh); }
      pa.needsUpdate = true; route.visible = len > 3;
    } else route.visible = false;
    // labels
    const dist = cur.dist;
    for (const L of labels) {
      let on, op = 1;
      if (L.kind === 'relic') on = labelMode < 2;
      else if (labelMode === 1 || labelMode === 2) on = false;
      else if (L.kind === 'region') { on = dist > 480; op = clamp((dist - 480) / 380, 0, 1) * L.fade; }
      else if (L.kind === 'zone') on = dist > 200 && dist < 1500;
      else on = L.prio >= 3 || (L.prio === 2 && dist < 1550) || (L.prio === 1 && dist < 720);
      if (L.kind === 'relic') { const g = relicLab[parseInt(L.name, 10) - 1], f = got.has(g.r.i); on = on && (L === g.on ? !f : f); }
      L.sp.visible = on; if (!on) continue;
      L.sp.material.opacity = op; const y = L.e * inv * cur.exag + 1.5 + L.lift * sc; L.sp.position.set(L.px - hw, y, L.py - hh);
      const u = sizeAt(0, mc.position.distanceTo(L.sp.position)) * 0.5 * L.size; L.sp.scale.set(L.w * u, L.h * u, 1);
    }
    // interface
    uiT -= dt; if (uiT <= 0) { uiT = 0.12; refreshInfo(); }
    el('at-needle').style.transform = 'rotate(' + (cur.yaw * 180 / Math.PI) + 'deg)';
    const kmPx = D.mpp / 1000 * sizeAt(0, cur.dist), nice = [1, 2, 5, 10, 20, 50, 100, 200, 500].filter(v => v / kmPx < 150).pop() || 1;
    el('at-bar').style.width = Math.max(20, nice / kmPx) + 'px'; el('at-bart').textContent = nice + ' km';
    const tm = renderer.toneMapping; renderer.toneMapping = THREE.NoToneMapping; renderer.render(ms, mc); renderer.toneMapping = tm;
  }
  return {
    open() {
      ui.style.display = 'block'; overview(); cur.dist = 2700; cur.pitch = 1.3; cur.yaw = 0.6; cur.exag = MV.exag; cur.tx = cur.tz = 0; arm = null; uiT = 0; lastLayer = null; buildTrail(); buildPins(); refreshInfo();
      say('<b>Atlas of Ethiopia</b><br><span style="font-size:14px;color:#b8b4a6">Move the aim point over any spot inside the border and click to travel there</span>', 4.5);
    },
    close() { ui.style.display = 'none'; elPrompt.classList.remove('on'); },
    click() { travelRequest(); },
    key(code) {
      if (code === 'Enter' || code === 'NumpadEnter') travelRequest();
      else if (code === 'KeyL') { D.nextLayer(); setLegend(); say('Layer: <b>' + D.layerLabel() + '</b>', 1.8); }
      else if (code === 'KeyK') { labelMode = (labelMode + 1) % 3; say(['Labels: all', 'Labels: heritage sites only', 'Labels: off'][labelMode].replace('Labels:', 'Labels:'), 1.6); }
      else if (code === 'KeyZ') { MV.exag = clamp(MV.exag / 1.3, 1, 26); say('Height ×' + MV.exag.toFixed(1), 1.2); }
      else if (code === 'KeyX') { MV.exag = clamp(MV.exag * 1.3, 1, 26); say('Height ×' + MV.exag.toFixed(1), 1.2); }
      else if (code === 'KeyH') { const h = D.here(); if (h) { const [px, py] = D.pos(h[0], h[1]); fly(px, py, 300); say('You are here', 1.4); } else overview(); }
      else if (code === 'Comma' || code === 'Period') { sel = sel < 0 ? (code === 'Period' ? 0 : LM.length - 1) : (sel + (code === 'Period' ? 1 : LM.length - 1)) % LM.length; const r = relics[sel]; fly(r.px, r.py, 380); MV.yaw = 0; refreshInfo(); }
      else if (code === 'KeyP') { if (!info.ok) { say('Pins must be inside Ethiopia', 1.6); return; } const r = D.togglePin(info.lat, info.lon); say(r === 1 ? 'Pin placed' : r === -1 ? 'Pin removed' : 'Too many pins (24 max)', 1.6); }
      else if (code === 'Home') overview();
    },
    render
  };
}


/* ---------- performance tiers + visual effects (G quality, P photo, H hide HUD, hold Z spyglass) ---------- */
const TIERS = [
  { name: 'Low', cull: 380, gR: 24, gCs: 1.15, sh: 1024, ext: 50, every: 2 },
  { name: 'Medium', cull: 600, gR: 34, gCs: 1.0, sh: 1536, ext: 60, every: 1 },
  { name: 'High', cull: 850, gR: 44, gCs: 0.85, sh: 2048, ext: 70, every: 1 },
  { name: 'Ultra', cull: 1150, gR: 52, gCs: 0.8, sh: 3072, ext: 70, every: 1 }];
let qMode = save.qual === undefined ? -1 : save.qual, qTier = 2, tierCap = 3, shEvery = 1;
function setTier(t) {
  qTier = t; const T = TIERS[t]; GQ.R = T.gR; GQ.cs = T.gCs; GQ.dirty = true; CULLR.v = T.cull; CULLR.dirty = true; shEvery = T.every;
  if (sun.shadow.mapSize.x !== T.sh) { sun.shadow.mapSize.set(T.sh, T.sh); if (sun.shadow.map) { sun.shadow.map.dispose(); sun.shadow.map = null; } }
  const c = sun.shadow.camera; c.left = -T.ext; c.right = T.ext; c.top = T.ext; c.bottom = -T.ext; c.updateProjectionMatrix();
}
const qLabel = () => (qMode < 0 ? 'auto ' : '') + TIERS[qTier].name;
if (qMode >= 0) { setTier(qMode); pr = [0.75, 1, Math.min(devicePixelRatio, 1.5), prMax][qMode]; renderer.setPixelRatio(pr); resize(); } else setTier(2);
function fxTemp() { const t = 33 - ALT(P.y) * 0.0065 - (1 - FXS.day) * 7 - rain * 4; return Math.round(t) + '°C'; }

// sun glare + lens flares (DOM overlay, only when the sun is really visible)
const glare = document.createElement('div'); glare.id = 'glare';
const gCore = document.createElement('div'); gCore.className = 'core'; glare.appendChild(gCore);
const flares = [[0.5, 70], [0.85, 38], [-0.35, 110], [1.3, 52], [1.7, 90]].map(([k, sz]) => { const d = document.createElement('i'); d.className = 'fl'; d.style.width = d.style.height = sz + 'px'; glare.appendChild(d); return { el: d, k }; });
document.body.appendChild(glare);
const flashEl = document.createElement('div'); flashEl.id = 'flash'; document.body.appendChild(flashEl);
const SV = new THREE.Vector3(), CD = new THREE.Vector3();
let glareN = 0, glareT = 0;

// floating dust and pollen in the light
const softTex = (() => { const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d'), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.4, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c); })();
const DN = 340, dpos = new Float32Array(DN * 3), dg = new THREE.BufferGeometry();
for (let i = 0; i < DN; i++) dpos.set([(Math.random() - .5) * 50, Math.random() * 14, (Math.random() - .5) * 50], i * 3);
dg.setAttribute('position', new THREE.BufferAttribute(dpos, 3));
const dustMat = new THREE.PointsMaterial({ map: softTex, size: 0.1, transparent: true, opacity: 0, depthWrite: false, color: 0xfff0c8 });
const dust = new THREE.Points(dg, dustMat); dust.frustumCulled = false; scene.add(dust);

// soaring birds (vultures, ibises) circling over the land by day
const birdsG = new THREE.Group(), birds = [], bMat = new THREE.MeshBasicMaterial({ color: 0x14181a, side: THREE.DoubleSide });
const wingG = new THREE.BufferGeometry(); wingG.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, -0.18, 1.2, 0.02, 0.05, 0, 0, 0.3], 3));
const bodyG = new THREE.ConeGeometry(0.1, 0.62, 5).rotateX(-Math.PI / 2);
for (let i = 0; i < 14; i++) {
  const g = new THREE.Group(), wL = new THREE.Mesh(wingG, bMat), wR = new THREE.Mesh(wingG, bMat); wR.scale.x = -1;
  g.add(new THREE.Mesh(bodyG, bMat), wL, wR); g.scale.setScalar(1.5 + Math.random() * 0.8); birdsG.add(g);
  birds.push({ g, wL, wR, a: Math.random() * 6.28, r: 70 + Math.random() * 150, h: 45 + Math.random() * 90, ph: Math.random() * 6, dir: Math.random() < 0.5 ? 1 : -1 });
}
scene.add(birdsG);
const bc = { x: 0, y: 0, z: 0, init: false };

function fxUpdate(dt, tw, dayF) {
  FXS.day = dayF; const cam = camera.position;
  // time-of-day colour grade: warm golden hour, a touch more contrast at dusk, desaturated in rain
  if ((FXS.gt = (FXS.gt || 0) - dt) < 0) { FXS.gt = 0.4; const dusk = clamp(1 - Math.abs(SUNDIR.y) * 4, 0, 1) * (SUNDIR.y > -0.2 ? 1 : 0); canvas.style.filter = 'contrast(' + (1.08 + dusk * 0.05).toFixed(2) + ') saturate(' + (1.1 + dusk * 0.14 - rain * 0.3).toFixed(2) + ') sepia(' + (dusk * 0.16).toFixed(2) + ') brightness(1.02)'; }
  // dry lands (Danakil, Kolla): warmer, dustier air
  if ((HAZE.t -= dt) < 0) { HAZE.t = 0.5; HAZE.target = locked ? dryAt(P.x, P.z) : 0; }
  HAZE.v = lerp(HAZE.v, HAZE.target || 0, Math.min(1, dt * 0.3));
  // sun glare
  glareT -= dt; camera.getWorldDirection(CD); const facing = CD.dot(SUNDIR);
  if (glareT < 0) {
    glareT = 0.1; let vis = SUNDIR.y > -0.02 && facing > 0.2 && locked && !mapOpen;
    if (vis) for (const t of [15, 40, 90, 180, 350, 700, 1400]) if (cam.y + SUNDIR.y * t < heightAt(cam.x + SUNDIR.x * t, cam.z + SUNDIR.z * t) + 1) { vis = false; break; }
    glareN = vis ? Math.max(0, (facing - 0.25) / 0.75) * sm(-0.02, 0.1, SUNDIR.y) * (1 - rain) : 0;
  }
  FXS.glare = lerp(FXS.glare, glareN, Math.min(1, dt * 5));
  if (FXS.glare > 0.01) {
    SV.copy(cam).addScaledVector(SUNDIR, 1000).project(camera);
    const sx = (SV.x * 0.5 + 0.5) * innerWidth, sy = (-SV.y * 0.5 + 0.5) * innerHeight, cx = innerWidth / 2, cy = innerHeight / 2;
    glare.style.opacity = Math.min(1, FXS.glare * (0.55 + 0.45 * (1 - SUNDIR.y))); gCore.style.transform = 'translate(' + sx + 'px,' + sy + 'px)';
    for (const f of flares) f.el.style.transform = 'translate(' + (sx + (cx - sx) * f.k) + 'px,' + (sy + (cy - sy) * f.k) + 'px) translate(-50%,-50%)';
    glare.style.display = 'block';
  } else glare.style.display = 'none';
  // dust / pollen
  const dOn = dayF > 0.15 && rain < 0.5 && !mapOpen;
  dust.visible = dOn;
  if (dOn) {
    dustMat.opacity = 0.55 * dayF * (1 - rain * 2) * (0.6 + 0.4 * HAZE.v + 0.4 * (1 - SUNDIR.y));
    dust.position.set(cam.x, cam.y - 3, cam.z); const v = dpos, wx = 0.35 + Math.sin(tw * 0.2) * 0.2;
    for (let i = 0; i < DN; i++) {
      const o = i * 3; v[o] += dt * (wx + Math.sin(tw + i) * 0.1); v[o + 1] += dt * Math.sin(tw * 0.7 + i * 1.7) * 0.15; v[o + 2] += dt * (0.1 + Math.cos(tw * 0.8 + i) * 0.12);
      if (v[o] > 25) v[o] -= 50; else if (v[o] < -25) v[o] += 50; if (v[o + 2] > 25) v[o + 2] -= 50; else if (v[o + 2] < -25) v[o + 2] += 50;
      if (v[o + 1] < 0) v[o + 1] += 14; else if (v[o + 1] > 14) v[o + 1] -= 14;
    }
    dg.attributes.position.needsUpdate = true;
  }
  // birds
  const bOn = dayF > 0.3 && rain < 0.6 && !mapOpen && P.y < 3000;
  birdsG.visible = bOn;
  if (bOn) {
    if (!bc.init) { bc.x = P.x; bc.y = P.y; bc.z = P.z; bc.init = true; }
    const k = Math.min(1, dt * 0.06); bc.x += (P.x - bc.x) * k; bc.y += (P.y - bc.y) * k; bc.z += (P.z - bc.z) * k;
    for (const b of birds) {
      if (b.dead) { b.vy -= 22 * dt; b.g.position.y += b.vy * dt; b.g.rotation.z += 6 * dt; b.g.rotation.x += 3 * dt; if (b.g.position.y < heightAt(b.g.position.x, b.g.position.z) + 0.3) b.g.visible = false; if ((b.rt -= dt) < 0) { b.dead = false; b.g.visible = true; } continue; }
      b.a += b.dir * (9 / b.r) * dt;
      b.g.position.set(bc.x + Math.cos(b.a) * b.r, bc.y + b.h + Math.sin(b.a * 3 + b.ph) * 5, bc.z + Math.sin(b.a) * b.r);
      b.g.rotation.set(0, b.dir > 0 ? Math.PI - b.a : -b.a, 0.28 * b.dir, 'YXZ');
      const fl = Math.sin(tw * (3.2 + b.ph * 0.15) + b.ph) * 0.35 * (Math.sin(tw * 0.4 + b.ph) > 0.2 ? 1 : 0.15); b.wL.rotation.z = fl; b.wR.rotation.z = -fl;
    }
  }
}
// photo: captured in the same frame as the render, at full resolution, without the HUD
function fxPhoto() {
  FXS.shot = false;
  try {
    const keep = pr; renderer.setPixelRatio(prMax); resize(); renderer.render(scene, camera);
    const url = canvas.toDataURL('image/png'), a = document.createElement('a'); a.href = url; a.download = 'highland-reach-' + Date.now() + '.png'; document.body.appendChild(a); a.click(); a.remove();
    renderer.setPixelRatio(keep); resize();
    flashEl.style.transition = 'none'; flashEl.style.opacity = 0.85; void flashEl.offsetWidth; flashEl.style.transition = 'opacity .6s'; flashEl.style.opacity = 0;
    toast('Photo saved to your downloads', 2);
  } catch (e) { toast('Could not save the photo', 2); }
}
addEventListener('keydown', e => {
  if (e.repeat || !locked || mapOpen) return;
  if (e.code === 'KeyZ') FXS.zoom = true;
  else if (e.code === 'KeyP') FXS.shot = true;
  else if (e.code === 'KeyH') { FXS.hud = !FXS.hud; $('hud').style.visibility = FXS.hud ? '' : 'hidden'; toast(FXS.hud ? 'HUD on' : 'HUD hidden (H to show)', 1.5); }
  else if (e.code === 'KeyG') {
    qMode = qMode >= 3 ? -1 : qMode + 1; save.qual = qMode; store();
    if (qMode < 0) { tierCap = 3; pr = Math.min(devicePixelRatio, 1.25); setTier(2); toast('Graphics: Auto (adapts to keep the game smooth)', 2.5); }
    else { setTier(qMode); pr = [0.75, 1, Math.min(devicePixelRatio, 1.5), prMax][qMode]; toast('Graphics: ' + TIERS[qMode].name, 2.5); }
    renderer.setPixelRatio(pr); resize();
  }
});
addEventListener('keyup', e => { if (e.code === 'KeyZ') FXS.zoom = false; });
addEventListener('blur', () => {
  FXS.zoom = false;
  for (const k in keys) keys[k] = false;
});
// Browsers throttle hidden tabs. Release controls and pointer lock so returning never
// leaves the player running into danger or the camera trapped outside the game.
document.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    FXS.zoom = false;
    for (const k in keys) keys[k] = false;
    if (document.pointerLockElement === canvas) document.exitPointerLock();
    if (softLock && locked) applyLock(false);
    if (AC && AC.state === 'running') AC.suspend().catch(() => {});
  }
});

/* ---------- input bridge: used by controls.js (touch, gamepad, settings, journal) ---------- */
window.HR_INPUT = {
  soft: false,
  look: lookBy,
  get locked() { return locked; },
  get map() { return mapOpen; },
  get settings() { return HRS; },
  start(soft) {
    startAudio(); if (AC && AC.state === 'suspended') AC.resume();
    if (soft) { softLock = true; applyLock(true); } else { softLock = false; canvas.requestPointerLock(); }
  },
  pause() { if (!locked) return; if (softLock) applyLock(false); else if (document.pointerLockElement === canvas) document.exitPointerLock(); },
  mapZoom(f) { const ok = window.ETH3D && !atlasBroken; MV.dist = clamp(MV.dist * f, ok ? 22 : 300, ok ? 2900 : 4500); },
  saveSettings() {
    try { localStorage.setItem('highland-reach-settings', JSON.stringify(HRS)); } catch (e) {}
    C.fov = HRS.fov; if (window.HR_MASTER) window.HR_MASTER.gain.value = HRS.mute ? 0 : HRS.vol;
  },
  journal() {
    const got = save.lm || [], seen = save.hs || [];
    return { relics: LM.map((l, i) => ({ name: l[0], got: got.includes(i) })), sites: HS.map(h => ({ name: h[0], history: h[5], seen: seen.includes(h[3]) })),
      time: P.time || 0, best: save.best || 0, hp: Math.round(P.hp) };
  }
};

/* ---------- Ethiopian historic sites: real coordinates, scaled models, walk-in discovery ---------- */
const HS = [   // [name, lat, lon, builder, discovery radius m, history]
  ['Bete Giyorgis (St George), Lalibela', 12.0297, 39.0472, 'giyorgis', 60, 'Cut downward out of solid rock c. 1200 AD, 12 m deep, in the shape of a Greek cross.'],
  ['Bete Medhane Alem, Lalibela', 12.0318, 39.0440, 'medhane', 60, 'The largest monolithic rock-hewn church in the world, ringed by 72 pillars.'],
  ['Northern Stelae Field, Aksum', 14.1305, 38.7190, 'stelae', 90, 'Granite stelae of the Aksumite kings, 4th century AD. The fallen Great Stele was 33 m long.'],
  ['St Mary of Zion, Aksum', 14.1299, 38.7178, 'zion', 50, "Ethiopia's holiest church, said to hold the Ark of the Covenant."],
  ['Fasil Ghebbi, Gondar', 12.6073, 37.4695, 'fasil', 140, 'Royal enclosure founded by Emperor Fasilides in 1636, the Camelot of Africa.'],
  ['Tiya stelae', 8.4333, 38.6167, 'tiya', 50, 'Carved grave stelae with swords, 12th to 14th century.'],
  ['Harar Jugol, the walled city', 9.3125, 42.1240, 'harar', 600, 'Walled in the 16th century, five gates, over 80 mosques, a holy city of Islam.'],
  ['Konso walled villages', 5.2500, 37.4300, 'konso', 60, 'Terraced stone-walled towns with carved generation statues (waka), over 400 years old.'],
  ['Yeha: Temple of Almaqah', 14.2833, 39.4350, 'yeha', 60, 'Built c. 700 BC, the oldest standing structure in Ethiopia.'],
  ['Debre Damo monastery', 14.3667, 39.2833, 'damo', 90, 'Founded in the 6th century on a sheer-sided amba, reached only by a leather rope.'],
  ['Sof Omar caves', 6.9333, 40.8500, 'omar', 80, 'A river tunnel through limestone, a sacred Muslim site for centuries.'],
  ['Hadar: where Lucy was found', 11.1167, 40.5833, 'hadar', 60, 'In 1974 the 3.2 million year old skeleton Lucy was discovered here.'],
  ['Yohannes IV palace, Mekelle', 13.4960, 39.4765, 'mekelle', 80, 'Built 1881 to 1884 for Emperor Yohannes IV.'],
  ['Entoto Maryam church', 9.0836, 38.7625, 'entoto', 60, 'Emperor Menelik II chose Entoto in the 1880s, the beginning of Addis Ababa.'],
  ['Debre Libanos monastery', 9.7167, 38.8667, 'libanos', 70, 'Founded in the 13th century by Saint Tekle Haymanot.'],
  ['Adwa battlefield', 14.1667, 38.9000, 'adwa', 70, 'On 1 March 1896 Ethiopia defeated Italy, a victory that kept Africa\'s oldest empire free.']
];
const SCol = c => new THREE.Color(c).convertSRGBToLinear();
const seenHS = new Set();
const SPW = { giyorgis: [0, 52], medhane: [0, 42], stelae: [0, 55], zion: [0, 55], fasil: [0, 150], tiya: [0, 28], harar: [0, 45], konso: [55, 0], yeha: [0, 28], damo: [0, 95], omar: [0, 60], hadar: [0, 28], mekelle: [0, 55], entoto: [0, 32], libanos: [0, 40], adwa: [0, 26] };
function hsSpawn() {   // when the loaded land is centred on a historic site, stand in front of it, facing it
  if (!REAL) return null;
  for (const h of HS) { const [x, z] = xzOf(h[1], h[2]); if (Math.hypot(x, z) < 400) { const d = SPW[h[3]] || [0, 40]; return [x + d[0], z + d[1], Math.atan2(d[0], d[1])]; } }
  return null;
}
function hsNear(lat, lon) {
  let best = null, bd = 2.5; for (const h of HS) { const d = Math.hypot((h[2] - lon) * 111.32 * Math.cos(lat * Math.PI / 180), (h[1] - lat) * 111.32); if (d < bd) { bd = d; best = h; } } return best;
}
function makeHeritage() {
  const lim = C.size * 0.47, mats = {}, root = new THREE.Group(), U = []; scene.add(root);
  const mt = c => mats[c] || (mats[c] = new THREE.MeshStandardMaterial({ color: SCol(c), roughness: 0.92 }));
  const NOTEX = new Set([0xd4a82a, 0x3a2a1e, 0x2a2018, 0x5a3d26, 0x8a2f2f, 0x6a3a2a, 0x078930, 0xfcdd09, 0xda121a, 0xdddddd, 0x35322e, 0x6b4a2a, 0x5a4630, 0x5a4020, 0x3a2a1c, 0x4a3320, 0xa23b32, 0x2a6a8a, 0x2a6a4a]);
  const mts = c => { const k = 'T' + tk + c; return mats[k] || (mats[k] = new THREE.MeshStandardMaterial({ color: SCol(c), roughness: 0.95, map: surfTex(tk) })); };
  const put = (g, c, x, y, z, ry) => { const m = new THREE.Mesh(g, (g.type === 'BoxGeometry' || g.type === 'CylinderGeometry') && !NOTEX.has(c) ? mts(c) : mt(c)); m.position.set(x, y, z); if (ry) m.rotation.y = ry; m.castShadow = m.receiveShadow = true; root.add(m); return m; };
  const solid = (x, z, hw, hd, yaw) => boxes.push({ x, z, c: Math.cos(yaw), s: Math.sin(yaw), hw, hd, R2: (hw + hd + 1) ** 2 });
  // box standing on the ground at (x,z); y0 = height above ground (0 = rests on ground and reaches 4 m below it)
  const blk = (x, z, w, h, d, y0, col, yaw = 0, sol = 1) => { const dn = y0 === 0 ? 4 : 0; put(boxUV(new THREE.BoxGeometry(w, h + dn, d), w, h + dn, d, 0.4), col, x, heightAt(x, z) + y0 + h / 2 - dn / 2, z, yaw); if (sol) solid(x, z, w / 2, d / 2, yaw); };
  const cyl = (x, z, rt, rb, h, y0, col, seg = 12, sol = 1) => { const dn = y0 === 0 ? 4 : 0; { const cg = new THREE.CylinderGeometry(rt, rb, h + dn, seg), cu = cg.attributes.uv; for (let i = 0; i < cu.count; i++) cu.setXY(i, cu.getX(i) * Math.max(1, Math.round(6.283 * rb * 0.4)), cu.getY(i) * Math.max(1, (h + dn) * 0.4)); put(cg, col, x, heightAt(x, z) + y0 + h / 2 - dn / 2, z); } if (sol) solid(x, z, rb, rb, 0); };
  const cone = (x, z, r, h, y0, col, seg = 12) => put(new THREE.ConeGeometry(r, h, seg), col, x, heightAt(x, z) + y0 + h / 2, z, seg === 4 ? 0.785 : 0);
  const dome = (x, z, r, y0, col) => put(new THREE.SphereGeometry(r, 16, 10, 0, 6.2832, 0, 1.5708), col, x, heightAt(x, z) + y0, z);
  const tap = (x, z, w, d, h, k, col, yaw = 0, sol = 1) => { const m = put(new THREE.CylinderGeometry(w * 0.7071 * k, w * 0.7071, h + 3, 4), col, x, heightAt(x, z) + h / 2 - 1.5, z, yaw + 0.785); m.scale.z = d / w; if (sol) solid(x, z, w / 2, d / 2, yaw); };
  const GOLD = 0xd4a82a, DARK = 0x3a2a1e;
  const cross = (x, z, y0, h = 2) => { blk(x, z, 0.25, h, 0.25, y0, GOLD, 0, 0); blk(x, z, 1.1, 0.25, 0.25, y0 + h * 0.6, GOLD, 0, 0); };
  let tk = 'stone';   // surface texture used by put(): 'stone' (coursed masonry) or 'plaster' (monolithic rock, render)
  const WOOD = 0x5a3d26; for (const c of [0x2a1a12, 0x1a120c, 0x24323a, 0x3a8a5a, 0x2a2824, 0x4a463f, 0x2d2a26, 0x2a2a2a, 0x3a5a6a, 0xd6c47a]) NOTEX.add(c);
  const plain = (g, c, x, y, z, ry) => { const m = new THREE.Mesh(g, mt(c)); m.position.set(x, y, z); if (ry) m.rotation.y = ry; m.castShadow = m.receiveShadow = true; root.add(m); return m; };
  const ball = (x, z, r, y, col) => plain(new THREE.SphereGeometry(r, 10, 8), col, x, heightAt(x, z) + y, z);
  const tcone = (x, z, r, h, y0, col, seg = 14) => { const g = new THREE.ConeGeometry(r, h, seg), u = g.attributes.uv; for (let i = 0; i < u.count; i++) u.setXY(i, u.getX(i) * r * 2.4, u.getY(i) * Math.hypot(r, h) * 0.5); const k = 'TH' + col; const m = new THREE.Mesh(g, mats[k] || (mats[k] = new THREE.MeshStandardMaterial({ color: SCol(col), roughness: 0.97, map: surfTex('thatch'), side: THREE.DoubleSide }))); m.position.set(x, heightAt(x, z) + y0 + h / 2, z); m.castShadow = true; root.add(m); };
  // arched window with a lighter surround; (x,z) is on the wall surface, f = side the wall faces (S,N,E,W)
  const win = (x, z, f, y, w, h, o = {}) => {
    const ry = f === 'E' || f === 'W' ? 1.5708 : 0, n = f === 'E' ? 1 : f === 'W' ? -1 : 0, m = f === 'S' ? 1 : f === 'N' ? -1 : 0, gy = heightAt(x, z) + y, dk = o.col || 0x1a120c, tr = o.trim || 0xcbbd9c;
    const P = (g, c, t, hh) => plain(g, c, x + n * t, gy + hh, z + m * t, ry);
    P(new THREE.BoxGeometry(w + 0.5, h + 0.2, 0.2), tr, 0.04, h / 2); P(new THREE.BoxGeometry(w, h, 0.3), dk, 0.1, h / 2);
    if (!o.sq) { P(new THREE.CylinderGeometry(w / 2 + 0.25, w / 2 + 0.25, 0.2, 14).rotateX(1.5708), tr, 0.04, h); P(new THREE.CylinderGeometry(w / 2, w / 2, 0.3, 14).rotateX(1.5708), dk, 0.1, h); }
    if (o.cross) { P(new THREE.BoxGeometry(0.16, h * 0.8, 0.34), tr, 0.1, h / 2); P(new THREE.BoxGeometry(w * 0.8, 0.16, 0.34), tr, 0.1, h * 0.6); }
  };
  const minaret = (x, z, h, c) => {
    cyl(x, z, 0.95, 1.15, h, 0, c, 14); for (const y of [4, h * 0.5]) cyl(x, z, 1.25, 1.25, 0.35, y, 0x3a8a5a, 14, 0); cyl(x, z, 1.8, 1.8, 0.4, h * 0.82, c, 14, 0); cyl(x, z, 0.75, 0.75, 3.2, h * 0.82 + 0.4, c, 12, 0);
    cone(x, z, 1.05, 2.6, h * 0.82 + 3.6, 0x3a8a5a, 12); ball(x, z, 0.28, h * 0.82 + 6.4, GOLD);
  };
  const wall = (x, z, a, b, n, h, t, col, gate) => {   // elliptical or circular wall, gates every `gate` segments
    for (let i = 0; i < n; i++) {
      const t1 = i / n * 6.2832, t2 = (i + 1) / n * 6.2832, x1 = x + a * Math.cos(t1), z1 = z + b * Math.sin(t1), x2 = x + a * Math.cos(t2), z2 = z + b * Math.sin(t2);
      const L = Math.hypot(x2 - x1, z2 - z1) + 0.3, yaw = -Math.atan2(z2 - z1, x2 - x1), dx = (x2 - x1) / L, dz = (z2 - z1) / L, mx = (x1 + x2) / 2, mz = (z1 + z2) / 2;
      if (gate && i % gate === 0) { for (const s of [-1, 1]) blk(mx + s * dx * L * 0.3, mz + s * dz * L * 0.3, L * 0.4, h, t, 0, col, yaw); blk(mx, mz, L * 0.2, 1.2, t, h - 1.2, col, yaw, 0); }
      else if (!(gate === -1 && i === 0)) blk(mx, mz, L, h, t, 0, col, yaw);
    }
  };
  const GL = new THREE.MeshBasicMaterial({ color: 0xffb050 }), I = [], lamp = new THREE.PointLight(0xffc27a, 0, 22, 2); root.add(lamp);
  const candle = (cx2, cz2, y) => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.13, 8, 6), GL); m.position.set(cx2, heightAt(cx2, cz2) + y, cz2); root.add(m); };
  const room = (x, z, w, d, h, col, o = {}) => {   // hollow building you can walk into: doorway in the south wall, roof slab, carpet, altar and candles
    const t = o.t || 0.9, gw = o.gw || 2.6, dh = o.dh || 3.4, sd = (w - gw) / 2;
    blk(x, z - d / 2 + t / 2, w, h, t, 0, col); blk(x - w / 2 + t / 2, z, t, h, d - 2 * t, 0, col); blk(x + w / 2 - t / 2, z, t, h, d - 2 * t, 0, col);
    blk(x - gw / 2 - sd / 2, z + d / 2 - t / 2, sd, h, t, 0, col); blk(x + gw / 2 + sd / 2, z + d / 2 - t / 2, sd, h, t, 0, col);
    blk(x, z + d / 2 - t / 2, gw, h - dh, t, dh, col, 0, 0); blk(x, z, w, 0.6, d, h - 0.3, col, 0, 0);
    if (o.deco) { blk(x, z + 1, 1.8, 0.06, d - t - 3, 0.07, 0x8a2f2f, 0, 0); blk(x, z - d / 2 + t + 1.4, Math.min(w * 0.4, 6), 0.9, 2, 0, 0x5a3d26); for (const k of [-1, 1]) candle(x + k * Math.min(w * 0.25, 3.6), z - d / 2 + t + 1.4, 1.2);
      // painted saints on the walls: framed panels with a gold halo, red/blue robes and a pale face; hanging lamps; curtain before the sanctuary
      const PN2 = [0xa23b32, 0x2a6a8a, 0x2a6a4a, 0x6a3a6a], icon = (mx, mz, yw, i) => { blk(mx, mz, 1.5, 2.2, 0.05, 1.0, 0x5a3d26, yw, 0); blk(mx, mz, 1.3, 1.3, 0.07, 1.1, PN2[i % 4], yw, 0); blk(mx, mz, 0.62, 0.62, 0.09, 2.15, 0xd4a82a, yw, 0); blk(mx, mz, 0.38, 0.4, 0.11, 2.27, 0xc99672, yw, 0); };
      const nI = Math.max(2, Math.floor((w - 2) / 3)); for (let i = 0; i < nI; i++) icon(x - (nI - 1) * 1.5 + i * 3, z - d / 2 + t + 0.06, 0, i);
      const nS = Math.max(1, Math.floor((d - 4) / 4)); for (let i = 0; i < nS; i++) for (const s of [-1, 1]) icon(x + s * (w / 2 - t - 0.06), z - (nS - 1) * 2 + i * 4, Math.PI / 2, i + (s > 0 ? 1 : 0));
      for (const [lx, lz] of [[-w * 0.2, 0], [w * 0.2, 0], [0, -d * 0.2]]) { blk(lx + x, lz + z, 0.04, 1.4, 0.04, h - 1.4, 0x2a2018, 0, 0); candle(lx + x, lz + z, h - 1.7); }
      blk(x, z - d / 2 + t + 2.4, Math.min(w * 0.7, 9), h * 0.55, 0.08, 0.3, 0x8a2f2f, 0, 0);   // sanctuary curtain
    }
    I.push({ x, z, w, d });
  };
  const church = (x, z, r, h, roof) => {   // round Orthodox church with a doorway to the south and a candle-lit sanctuary
    const N = 20, w = 2 * r * Math.sin(Math.PI / N) + 0.12;
    for (let i = 1; i < N; i++) { const ps = Math.PI / 2 + i * 6.2832 / N, px = x + Math.cos(ps) * r, pz = z + Math.sin(ps) * r, y = -ps - Math.PI / 2; put(new THREE.BoxGeometry(w, h + 4, 0.8), 0xd9c9a3, px, heightAt(px, pz) + h / 2 - 2, pz, y); solid(px, pz, w / 2, 0.4, y); }
    const cm = new THREE.Mesh(new THREE.ConeGeometry(r + 1.8, 5.5, 20), new THREE.MeshStandardMaterial({ color: SCol(roof), roughness: 0.9, side: THREE.DoubleSide })); cm.position.set(x, heightAt(x, z) + h + 2.75, z); cm.castShadow = true; root.add(cm);
    blk(x, z - r * 0.35, 2.6, 1.4, 2.4, 0, 0x5a3d26); for (const k of [-1, 1]) candle(x + k * 2.2, z - r * 0.35, 1.2); blk(x, z + 1, 1.6, 0.06, r, 0.07, 0x8a2f2f, 0, 0);
    cross(x, z, h + 5.5, 2.4); I.push({ x, z, w: 2 * r, d: 2 * r });
    // second tier drum, ostrich-egg finial, coloured windows, painted door frame, outer wall with gates, bell frame
    const top = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.45, r * 0.5, 2.4, 16), new THREE.MeshStandardMaterial({ color: SCol(0xe6d9b4), roughness: 0.9 })); top.position.set(x, heightAt(x, z) + h + 6.4, z); top.castShadow = true; root.add(top);
    const cm2 = new THREE.Mesh(new THREE.ConeGeometry(r * 0.55, 3, 16), new THREE.MeshStandardMaterial({ color: SCol(roof), roughness: 0.9 })); cm2.position.set(x, heightAt(x, z) + h + 9.1, z); root.add(cm2); put(new THREE.SphereGeometry(0.35, 10, 8).scale(1, 1.3, 1), 0xf2ecdc, x, heightAt(x, z) + h + 10.8, z); cross(x, z, h + 11.2, 1.6);
    for (let k = 0; k < 12; k++) { const a = k / 12 * 6.283 + 0.26; if (Math.abs(Math.sin(a - Math.PI / 2)) < 0.12 && Math.cos(a) > -0.2 && Math.sin(a) > 0.85) continue; put(new THREE.BoxGeometry(0.8, 1.7, 0.2), [0x2a6a8a, 0xa23b32, 0x2a6a4a, 0xd4a82a][k % 4], x + Math.cos(a) * (r + 0.42), heightAt(x, z) + h * 0.55, z + Math.sin(a) * (r + 0.42), -a + Math.PI / 2); }
    for (const s of [-1, 1]) blk(x + s * 1.3, z + r + 0.5, 0.35, 3.6, 0.35, 0, 0x6a3a2a, 0, 0); blk(x, z + r + 0.5, 3.0, 0.4, 0.4, 3.5, 0x6a3a2a, 0, 0);
    for (let k = 0; k < 10; k++) { const a = k / 10 * 6.283 + 0.31; if (Math.sin(a) > 0.8) continue; const ix = x + Math.cos(a) * (r - 0.55), iz = z + Math.sin(a) * (r - 0.55), yy = -a - Math.PI / 2; for (const [w2, h2_, y2, c2] of [[1.4, 2.4, 1.0, 0x5a3d26], [1.2, 1.5, 1.1, [0xa23b32, 0x2a6a8a, 0x2a6a4a, 0x6a3a6a][k % 4]], [0.55, 0.55, 2.3, 0xd4a82a], [0.34, 0.36, 2.4, 0xc99672]]) put(new THREE.BoxGeometry(w2, h2_, 0.05), c2, ix, heightAt(ix, iz) + y2 + h2_ / 2, iz, yy); }   // painted saints on the inner wall
    for (let k = 0; k < 3; k++) { const a = k * 2.094 + 0.5, lx = x + Math.cos(a) * r * 0.5, lz = z + Math.sin(a) * r * 0.5; put(new THREE.CylinderGeometry(0.02, 0.02, 1.6, 4), 0x2a2018, lx, heightAt(lx, lz) + h - 0.8, lz); candle(lx, lz, h - 1.7); }
    wall(x, z, r + 9, r + 9, 36, 1.6, 0.7, 0xcdbf9e, 9);
    for (const [px, pz] of [[-r - 5, r * 0.4], [r + 5, -r * 0.4]]) { blk(x + px, z + pz, 0.2, 2.6, 0.2, 0, 0x3a2a1e, 0, 0); blk(x + px, z + pz, 0.2, 0.2, 2.0, 2.4, 0x3a2a1e, 0, 0); put(new THREE.CylinderGeometry(0.18, 0.3, 0.5, 8), 0x8a7a4a, x + px, heightAt(x + px, z + pz) + 1.8, z + pz); }
    for (let k = 0; k < 8; k++) { const a = k / 8 * 6.283; blk(x + Math.cos(a) * (r + 3), z + Math.sin(a) * (r + 3) * 1.0, 0.5, 0.4, 0.3, 0, 0x8a847a, a, 0); }
  };
  const castle = (x, z, w, d, h, K, tall) => {
    room(x, z, w, d, h, K, { t: 1.2, gw: 2.8, dh: 3.8 }); for (const k of [-1, 1]) blk(x + k * w * 0.18, z, 1.4, h - 0.6, 1.4, 0, K); blk(x, z - d / 2 + 3, 6, 0.6, 3, 0, 0x5a3d26); blk(x, z + 2, 2, 0.06, d - 8, 0.07, 0x8a2f2f, 0, 0); candle(x - 2.6, z - d / 2 + 3, 1.2); candle(x + 2.6, z - d / 2 + 3, 1.2);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const th = tall && sx < 0 && sz > 0 ? tall : h + 5; cyl(x + sx * w / 2, z + sz * d / 2, 3, 3.3, th, 0, K); dome(x + sx * w / 2, z + sz * d / 2, 3.2, th, K); if (th === tall) cross(x + sx * w / 2, z + sz * d / 2, th + 3.2, 3); }
    for (let i = -w / 2 + 4; i < w / 2 - 3; i += 2.4) for (const sz of [-1, 1]) blk(x + i, z + sz * d / 2, 1.1, 1.1, 1.1, h, K, 0, 0);
    for (let i = -d / 2 + 4; i < d / 2 - 3; i += 2.4) for (const sx of [-1, 1]) blk(x + sx * w / 2, z + i, 1.1, 1.1, 1.1, h, K, 0, 0);
    for (const k of [-1, 1]) blk(x + k * w * 0.3, z + d / 2 + 0.1, 1, 1.6, 0.3, h * 0.55, DARK, 0, 0);
    /* ---- extra castle detail: gate arch, plinth, buttresses, arrow slits, frames, tower caps, banners, torches, stair, forecourt ---- */
    const FR = 0xb9ad98, BAN = [0xa23b32, 0x078930, 0xd4a82a];
    blk(x, z, w + 1.2, 1.0, d + 1.2, 0, 0x6a6258, 0, 0);                                                       // stone plinth
    blk(x - gw2(), z + d / 2 + 0.25, 0.6, 4.4, 0.6, 0, FR, 0, 0); blk(x + gw2(), z + d / 2 + 0.25, 0.6, 4.4, 0.6, 0, FR, 0, 0); blk(x, z + d / 2 + 0.25, 3.4, 0.7, 0.7, 4.0, FR, 0, 0);   // gate surround
    for (let i = -w / 2 + 3; i < w / 2 - 2; i += 6) { blk(x + i, z - d / 2 - 0.5, 1.2, h, 1.0, 0, K, 0, 0); if (Math.abs(i) > 2.5) blk(x + i, z + d / 2 + 0.5, 1.2, h, 1.0, 0, K, 0, 0); }       // buttresses
    for (let i = -d / 2 + 3; i < d / 2 - 2; i += 6) for (const s of [-1, 1]) blk(x + s * (w / 2 + 0.5), z + i, 1.0, h, 1.2, 0, K, 0, 0);
    for (let i = -w / 2 + 6; i < w / 2 - 4; i += 6) for (const lv of [0.45, 0.75]) { if (Math.abs(i) < 3 && lv < 0.5) continue; blk(x + i, z + d / 2 + 0.2, 0.7, 2.0, 0.3, h * lv - 0.6, DARK, 0, 0); blk(x + i, z + d / 2 + 0.28, 1.2, 0.2, 0.3, h * lv + 1.35, FR, 0, 0); blk(x + i, z + d / 2 + 0.28, 1.2, 0.2, 0.3, h * lv - 0.8, FR, 0, 0); }   // framed windows
    for (let i = -w / 2 + 3; i < w / 2 - 2; i += 3) for (const s of [-1, 1]) blk(x + i, z + s * (d / 2 + 0.15), 0.25, 1.4, 0.2, h * 0.6, DARK, 0, 0);   // arrow slits
    for (const s of [-1, 1]) for (let i = -d / 2 + 4; i < d / 2 - 3; i += 4) blk(x + s * (w / 2 + 0.1), z + i, 0.2, 1.8, 0.7, h * 0.45, DARK, 0, 0);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) {   // conical caps, ring bands, and a window on every tower
      const tx = x + sx * w / 2, tz = z + sz * d / 2, th = (tall && sx < 0 && sz > 0) ? tall : h + 5; if (th === tall) continue;
      cone(tx, tz, 3.6, 4.2, th + 1.4, 0x7a3a2a, 14); cross(tx, tz, th + 5.4, 1.2); cyl(tx, tz, 3.45, 3.45, 0.5, h * 0.55, FR, 14, 0); cyl(tx, tz, 3.45, 3.45, 0.5, th - 0.2, FR, 14, 0);
      blk(tx + sx * 3.1, tz + sz * 0.1, 0.2, 1.8, 0.8, th * 0.55, DARK, 0, 0);
    }
    for (const [bx2, bz2] of [[-w * 0.3, 0], [w * 0.3, 0]]) { const m2 = put(new THREE.BoxGeometry(2.2, 5, 0.1), BAN[(Math.abs(Math.round(bx2)) + 1) % 3], x + bx2, heightAt(x, z) + h - 1.6, z + d / 2 + 0.9, 0); put(new THREE.CylinderGeometry(0.07, 0.07, 2.6, 6).rotateZ(Math.PI / 2), 0x3a2a1e, x + bx2, heightAt(x, z) + h + 0.9, z + d / 2 + 0.9, 0); }   // hanging banners
    for (const s of [-1, 1]) { blk(x + s * 2.2, z + d / 2 + 0.7, 0.12, 1.4, 0.12, 2.0, 0x2a2018, 0, 0); candle(x + s * 2.2, z + d / 2 + 0.7, 3.5); }   // gate torches
    for (let k = 0; k < 9; k++) blk(x + w / 2 + 1.6 + k * 0.3, z - d * 0.2 + k * 0.5, 2.0, 0.4, 0.9, 0, 0x8a8478, 0.0, 0), blk(x + w / 2 + 2.2 + k * 0.3, z + d / 2 - 1.5 - k * 0.0, 0.1, 0.1, 0.1, 0, K, 0, 0);   // outer stair slabs
    for (let i = -3; i <= 3; i++) for (let j = 1; j <= 5; j++) blk(x + i * 2.4, z + d / 2 + 1 + j * 2.4, 2.3, 0.12, 2.3, 0.02, (i + j) % 2 ? 0x8a8478 : 0x77716a, 0, 0);   // flagstone forecourt
    for (const s of [-1, 1]) { blk(x + s * 5, z + d / 2 + 6, 0.5, 1.4, 0.5, 0, 0x6a6258); blk(x + s * 5, z + d / 2 + 6, 0.9, 0.4, 0.9, 1.4, 0x8a8478, 0, 0); candle(x + s * 5, z + d / 2 + 6, 1.9); }   // lantern pillars
    blk(x, z + d / 2 + 14, 1.2, 1.1, 1.2, 0, 0x6a6258); cyl(x, z + d / 2 + 14, 1.8, 2.0, 0.5, 0, 0x7e7870, 16, 0);                                              // fountain
    I.push({ x, z, w, d });
    function gw2() { return 1.7; }
  };
  let q = 12345; const rr = () => (q = (q * 16807) % 2147483647) / 2147483647;
  const B = {
    giyorgis(x, z) {   // Lalibela: three-tier Greek-cross church cut from one block of red tuff, standing in its trench
      tk = 'plaster'; const R = 0x8c5f46, T = 0xa86f50, L = 0xbc835e, D = 0x2a1a12;
      blk(x, z - 24, 54, 12, 6, 0, R); blk(x - 17, z + 24, 20, 12, 6, 0, R); blk(x + 17, z + 24, 20, 12, 6, 0, R); blk(x - 24, z, 6, 12, 42, 0, R); blk(x + 24, z, 6, 12, 42, 0, R);
      for (let i = -24; i <= 24; i += 3) { blk(x + i, z - 21, 1.2, 0.5, 0.5, 11.6, L, 0, 0); } for (let i = -18; i <= 18; i += 3) { blk(x - 21, z + i, 0.5, 0.5, 1.2, 11.6, L, 0, 0); blk(x + 21, z + i, 0.5, 0.5, 1.2, 11.6, L, 0, 0); }
      room(x, z, 8.5, 25, 5, T, { t: 0.7, gw: 2.2, dh: 3.4, deco: 1 }); blk(x - 8.4, z, 8.3, 5, 8.5, 0, T); blk(x + 8.4, z, 8.3, 5, 8.5, 0, T);
      const crs = (Lg, W, y0, h, c) => { blk(x, z, Lg, h, W, y0, c, 0, 0); blk(x, z, W, h, Lg, y0, c, 0, 0); };
      crs(25.6, 8.9, 4.9, 0.35, L); crs(21, 6.5, 5.25, 3.6, T); crs(21.4, 6.9, 8.85, 0.35, L); crs(17, 4.5, 9.2, 2.8, T); crs(17.4, 4.9, 12, 0.35, L); crs(12, 1.6, 12.35, 0.45, 0x6e4636); crs(7, 1, 12.8, 0.4, 0x6e4636);
      const o = { trim: L, cross: 1 }; for (const s of [-1, 1]) { win(x + s * 12.5, z, s > 0 ? 'E' : 'W', 1.2, 1.3, 2.4, o); win(x + s * 8.4, z - 4.25, 'N', 1.2, 1.3, 2.4, o); win(x + s * 8.4, z + 4.25, 'S', 1.2, 1.3, 2.4, o); win(x + s * 10.5, z, s > 0 ? 'E' : 'W', 5.8, 0.9, 1.6, o); }
      win(x, z - 12.5, 'N', 1.2, 1.3, 2.4, o); win(x, z - 10.5, 'N', 5.8, 0.9, 1.6, o); win(x, z + 10.5, 'S', 5.8, 0.9, 1.6, o); win(x, z + 8.5, 'S', 9.6, 0.8, 1.4, o);
    },
    medhane(x, z) {   // Lalibela: 33.5 x 23.5 x 11.5 m (Lonely Planet / Guinness); about 34 external pillars, 3 naves, 38 interior columns, gabled roof
      tk = 'plaster'; const S = 0xa86f50, L = 0xbc835e, PW = 33.5, PD = 23.5;
      room(x, z, 29.5, 19.5, 9.2, S, { gw: 3, dh: 4.2, deco: 1 }); blk(x, z, PW + 0.4, 0.5, PD + 0.4, 8.7, L, 0, 0);
      for (const s2 of [-1, 1]) plain(new THREE.BoxGeometry(PW + 0.6, 0.6, 12.2).rotateX(s2 * 0.19), S, x, heightAt(x, z + s2 * 5.9) + 10.35, z + s2 * 5.9); blk(x, z, PW + 0.6, 0.5, 0.7, 11.2, L, 0, 0);
      const pil = (px, pz) => { blk(px, pz, 1.3, 9, 1.3, 0, S); blk(px, pz, 1.7, 0.5, 1.7, 0, L, 0, 0); blk(px, pz, 1.7, 0.5, 1.7, 8.5, L, 0, 0); };
      for (let i = 0; i <= 10; i++) for (const s2 of [-1, 1]) { if (i === 5 && s2 === 1) continue; pil(x - PW / 2 + 0.65 + i * (PW - 1.3) / 10, z + s2 * (PD / 2 - 0.65)); }
      for (let i = 1; i < 7; i++) for (const s2 of [-1, 1]) pil(x + s2 * (PW / 2 - 0.65), z - (PD / 2 - 0.65) + i * (PD - 1.3) / 7);
      for (let i = 0; i < 10; i++) for (const s2 of [-1, 1]) blk(x - 11.7 + i * 2.6, z + s2 * 3.4, 0.8, 8.6, 0.8, 0, S);
      for (let i = 0; i < 9; i++) for (const s2 of [-1, 1]) blk(x - 12.4 + i * 3.1, z + s2 * 8.6, 0.7, 8.6, 0.5, 0, L, 0, 0);
      const o = { trim: L }; for (const k of [-10, -3.5, 3.5, 10]) win(x + k, z - 9.75, 'N', 2.6, 1.3, 3, o); for (const k of [-10.5, -6, 6, 10.5]) win(x + k, z + 9.75, 'S', 2.6, 1.3, 3, o);
    },
    stelae(x, z) {   // Aksum: granite stelae carved as multi-storey buildings: false doors, windows, rope-and-beam ends
      tk = 'plaster'; const G = 0x8b867c, TR = 0xa8a398;
      const st = (dx, dz, w, d, h, fancy) => {
        const sx = x + dx, sz = z + dz; blk(sx, sz, w * 2.6, 0.5, d * 3, 0, 0x7a766d, 0, 0); tap(sx, sz, w, d, h, 0.74, G);
        const fz = sz + d / 2 * 0.95; blk(sx, fz, w * 0.5, 1.6, 0.16, 0.25, 0x2a2824, 0, 0, '-'); ball(sx + w * 0.12, fz, 0.09, 1.1, GOLD);
        for (let y = 2.4; y < h - 1.8; y += 2.2) { const k = 1 - (y / h) * 0.26; blk(sx, fz, w * 0.92 * k, 0.2, 0.2, y - 0.4, TR, 0, 0); for (const s of [-1, 1]) blk(sx + s * w * 0.3 * k, fz, 0.22, 0.22, 0.24, y - 0.4, 0x4a463f, 0, 0, '-'); if (fancy) blk(sx, fz, w * 0.34 * k, 0.8, 0.14, y, 0x2a2824, 0, 0, '-'); }
        if (fancy) plain(new THREE.CylinderGeometry(w * 0.4, w * 0.4, d * 0.9, 18).rotateX(1.5708), G, sx, heightAt(sx, sz) + h - 0.1, sz, 0);
      };
      st(0, 0, 2.6, 1.2, 20.6, 1); st(-14, -6, 2.3, 1.3, 24.6, 1);
      for (const [a, b, w, h] of [[8, 10, 1.2, 6], [12, 2, 1, 4.5], [-6, 12, 1.3, 7.5], [18, -8, 0.9, 3], [-22, 4, 1, 5], [14, 14, 0.8, 2.5]]) st(a, b, w, w * 0.5, h, h > 5);
      for (let i = 0; i < 66; i++) { const a = -50 + rr() * 100, b = -30 + rr() * 60; if (Math.hypot(a, b) < 9 || Math.hypot(a + 14, b + 6) < 9) continue; const h = 1 + Math.pow(rr(), 2.2) * 10, w = 0.5 + h * 0.08; st(a, b, w, w * 0.5, h, h > 6); }   // the field has about 75 stelae over ~5000 m2
      for (let i = 0; i < 5; i++) { const px = x + 18 + i * 6.8 * Math.cos(0.35), pz = z - 22 - i * 6.8 * Math.sin(0.35); blk(px, pz, 6.6, 2.4, 3.8, 0, G, 0.35); blk(px, pz, 6.4, 0.18, 0.2, 2.4, TR, 0.35, 0, undefined); }
      blk(x - 6, z + 22, 5, 0.9, 7, 0, 0x6f6b62); blk(x - 6, z + 22, 5.6, 0.4, 7.6, 0.9, TR, 0, 0);   // a slab tomb
    },
    zion(x, z) {   // Aksum: St Mary of Zion, the modern cathedral (size is an estimate, no published dimensions found)
      tk = 'plaster'; const W = 0xe6d8b4, BN = 0xb9a37c, TR = 0xf0e6cc, CW = 40, CD = 30, CH = 13;
      room(x, z, CW, CD, CH, W, { gw: 4.4, dh: 5.4, deco: 1 }); blk(x, z, CW + 0.4, 1.2, CD + 0.4, 0, BN, 0, 0, 'rubble'); blk(x, z, CW + 0.6, 0.6, CD + 0.6, CH - 0.4, TR, 0, 0);
      for (const [i, c] of [[0, 0x078930], [1, 0xfcdd09], [2, 0xda121a]]) blk(x, z, CW + 0.7, 0.26, CD + 0.7, CH - 1.2 - i * 0.34, c, 0, 0);
      blk(x, z, 24, 4, 18, CH, W, 0, 0); cyl(x, z, 8, 8, 2.6, CH + 4, W, 24, 0); dome(x, z, 8.4, CH + 6.6, 0xb7b0a0); ball(x, z, 0.7, CH + 15.4, GOLD); cross(x, z, CH + 15.8, 4);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) { cyl(x + sx * 14, z + sz * 10, 3, 3, 1.8, CH, W, 16, 0); dome(x + sx * 14, z + sz * 10, 3.3, CH + 1.8, 0xb7b0a0); ball(x + sx * 14, z + sz * 10, 0.3, CH + 5.4, GOLD); }
      for (let k = -2; k <= 2; k++) cyl(x + k * 4, z + CD / 2 + 2.8, 0.55, 0.65, 8.5, 0, W, 12, 1); blk(x, z + CD / 2 + 2.8, 20, 0.7, 2, 8.5, TR, 0, 0); blk(x, z + CD / 2 + 1.6, 19, 0.5, 4.4, 9.2, W, 0, 0);
      const o = { trim: TR }; for (const k of [-14, -9.5, 9.5, 14]) win(x + k, z + CD / 2, 'S', 3.4, 1.4, 4, o); for (const k of [-9, 0, 9]) { win(x + CW / 2, z + k, 'E', 3.4, 1.4, 4, o); win(x - CW / 2, z + k, 'W', 3.4, 1.4, 4, o); } for (const k of [-12, -4, 4, 12]) win(x + k, z - CD / 2, 'N', 3.4, 1.4, 4, o);
    },
    fasil(x, z) {   // Gondar: enclosure with a 900 m wall (about 225 x 225 m); Fasilides' castle 25 x 25 m with a 32 m tower (UNESCO). Other palaces: estimated sizes
      const K = 0x7a6f60, P = 0x857a68, hw = 112, hd = 112; tk = 'stone';
      blk(x, z - hd, 2 * hw, 7, 2, 0, P); blk(x - 68, z + hd, 88, 7, 2, 0, P); blk(x + 68, z + hd, 88, 7, 2, 0, P); blk(x - hw, z, 2, 7, 2 * hd, 0, P); blk(x + hw, z, 2, 7, 2 * hd, 0, P);
      for (let i = -hw; i <= hw; i += 4) { blk(x + i, z - hd, 1.6, 1.4, 1.6, 7, P, 0, 0); if (Math.abs(i) > 14) blk(x + i, z + hd, 1.6, 1.4, 1.6, 7, P, 0, 0); }
      for (let i = -hd; i <= hd; i += 4) for (const s of [-1, 1]) blk(x + s * hw, z + i, 1.6, 1.4, 1.6, 7, P, 0, 0);
      for (const sx of [-1, 1]) for (const sz of [-1, 1]) { cyl(x + sx * hw, z + sz * hd, 3.4, 3.7, 11, 0, P); dome(x + sx * hw, z + sz * hd, 3.4, 11, P); }
      for (const s of [-1, 1]) { cyl(x + s * 16, z + hd, 2.8, 3.1, 10, 0, P); dome(x + s * 16, z + hd, 2.8, 10, P); }
      castle(x, z - 20, 25, 25, 11, K, 32);                                                          // Fasilides' castle
      castle(x + 55, z + 10, 22, 16, 9, K, 0); castle(x - 60, z + 30, 18, 14, 8, K, 0); castle(x - 45, z - 55, 20, 16, 9, K, 0);   // Iyasu, Dawit III, Bakaffa
      castle(x + 30, z - 70, 14, 10, 8, K, 0); castle(x + 75, z - 55, 12, 10, 6, K, 0);              // library, chancellery
    },
    tiya(x, z) {   // Tiya: carved granite grave stelae with swords and figures
      tk = 'plaster'; for (let i = 0; i < 36; i++) { const h = 1.2 + (i * 37 % 9) * 0.45, dx = (i % 12 - 5.5) * 3.4, dz = (Math.floor(i / 12) - 1) * 5, w = 0.7 + (i % 3) * 0.15, sx = x + dx, sz = z + dz; tap(sx, sz, w, 0.25, h, 0.85, 0x7b766d);
        const fz = sz + 0.15; blk(sx, fz, 0.13, h * 0.5, 0.05, h * 0.12, 0x2d2a26, 0, 0, '-'); blk(sx, fz, 0.42, 0.07, 0.05, h * 0.16, 0x2d2a26, 0, 0, '-'); blk(sx, fz, 0.1, 0.12, 0.05, h * 0.1, 0x2d2a26, 0, 0, '-'); if (h > 2.4) plain(new THREE.CylinderGeometry(0.16, 0.16, 0.06, 12).rotateX(1.5708), 0x2d2a26, sx, heightAt(sx, sz) + h * 0.82, fz, 0, '-'); }
    },
    harar(x, z) {   // Harar Jugol: pale limewashed rubble wall with five gates, Jami mosque with two minarets, pastel houses with painted doors
      tk = 'stone'; wall(x, z, 550, 400, 240, 4.2, 1.3, 0xd2c3a0, 48);
      tk = 'plaster'; const M = 0xefe6d2, TR = 0xf8f3e6;
      room(x, z, 24, 13, 7, M, { gw: 3, dh: 3.6, deco: 1 }); blk(x, z, 24.5, 0.5, 13.5, 6.8, TR, 0, 0); for (let i = -11; i <= 11; i += 2.2) { blk(x + i, z + 6.5, 1, 0.9, 0.5, 7.2, M, 0, 0); blk(x + i, z - 6.5, 1, 0.9, 0.5, 7.2, M, 0, 0); }
      for (const k of [-1, 0, 1]) dome(x + k * 6.5, z, 2.3, 7.3, 0xe0d6bc); minaret(x - 11.5, z + 7.5, 17, M); minaret(x + 11.5, z + 7.5, 17, M);
      const o = { trim: TR, col: 0x24323a }; for (const k of [-9, -6, 6, 9]) win(x + k, z + 6.5, 'S', 1.6, 1.2, 3.2, o); for (const k of [-3, 3]) win(x + 12, z + k * 1.5, 'E', 1.6, 1.2, 3.2, o);
      const hc = [0x6fa8c8, 0xd98fa8, 0x8fc48a, 0xf2ede0, 0xe8c34a], dc = [0x2a4a8a, 0x2a6a4a, 0xa23b32];
      for (let i = 0; i < 18; i++) { const a = rr() * 6.28, d = 30 + rr() * 330, px = x + Math.cos(a) * d * 1.3, pz = z + Math.sin(a) * d * 0.95, w = 5 + rr() * 3, hg = 3.4 + rr() * 1.4, c = hc[i % 5], dc2 = dc[i % 3];
        blk(px, pz, w, hg, 5, 0, c); blk(px, pz, w + 0.3, 0.5, 5.3, hg, 0xf5f0e4, 0, 0); win(px, pz + 2.5, 'S', 0, 1.1, 2.3, { trim: 0xf5f0e4, col: dc2 }); win(px - w * 0.3, pz + 2.5, 'S', 1.2, 0.8, 1.3, { trim: 0xf5f0e4, col: dc2 }); win(px + w * 0.3, pz + 2.5, 'S', 1.2, 0.8, 1.3, { trim: 0xf5f0e4, col: dc2 }); }
    },
    konso(x, z) {   // Konso: dry-stone walled settlement, mud-plastered thatched huts, a mora meeting house, carved wooden generation statues
      tk = 'stone'; wall(x, z, 30, 30, 36, 2.4, 1.4, 0x7a7468, -1); blk(x + 30, z - 3.6, 2.2, 3.2, 1.6, 0, 0x7a7468); blk(x + 30, z + 3.6, 2.2, 3.2, 1.6, 0, 0x7a7468);
      for (const [dx, dz] of [[-10, -8], [8, -12], [14, 6], [-14, 8], [0, 14], [-3, -18], [18, -4]]) { tk = 'plaster'; cyl(x + dx, z + dz, 2.2, 2.2, 2.4, 0, 0xb59a6a, 12); tcone(x + dx, z + dz, 3.5, 2.8, 2.4, 0xb8974a, 14, 'thatch'); tcone(x + dx, z + dz, 3.2, 0.6, 5.2, 0xa8883a, 14, 'thatch'); ball(x + dx, z + dz, 0.2, 5.8, 0x5a4a30); }
      for (const [dx, dz] of [[-6, 9], [9, 10], [5, -8]]) { for (const k of [0, 1, 2, 3]) plain(new THREE.CylinderGeometry(0.1, 0.1, 1.6, 6), WOOD, x + dx + (k % 2) * 1.4 - 0.7, heightAt(x + dx, z + dz) + 0.8, z + dz + (k > 1 ? 1.4 : 0) - 0.7, 0, 'wood'); cyl(x + dx, z + dz + 0.3, 1.1, 1.1, 1.3, 1.6, 0xb59a6a, 10, 0, 'plaster'); tcone(x + dx, z + dz + 0.3, 1.5, 1.1, 2.9, 0xb8974a, 10, 'thatch'); }
      for (let i = 0; i < 6; i++) blk(x + Math.cos(i) * 3.6, z + Math.sin(i) * 3.6, 0.4, 2.6, 0.4, 0, WOOD, 0, 1, 'wood'); tcone(x, z, 5.4, 3, 2.6, 0xb8974a, 14, 'thatch');
      for (const [dx, dz] of [[-6, -3], [6, -2], [-3, 5], [6, 6], [-8, 2]]) { blk(x + dx, z + dz, 0.35, 1.7, 0.35, 0, WOOD, 0, 1, 'wood'); blk(x + dx, z + dz, 0.8, 0.3, 0.3, 1.1, WOOD, 0, 0, 'wood'); ball(x + dx, z + dz, 0.26, 1.95, WOOD); cone(x + dx, z + dz, 0.12, 0.5, 2.1, WOOD, 6, '-'); }
    },
    yeha(x, z) {   // Yeha: Great Temple of Almaqah, 18.5 x 15 m, walls surviving to 14 m, dressed blocks up to 3 m long, no mortar (UNESCO)
      tk = 'stone'; const A = 0xc9a574, TR = 0xd8b988;
      blk(x, z, 22, 0.7, 19, 0, A, 0, 0); blk(x, z - 6.8, 18.5, 14, 1.4, 0, A); blk(x - 8.55, z, 1.4, 14, 12.2, 0, A); blk(x + 8.55, z, 1.4, 14, 12.2, 0, A);
      blk(x - 5.6, z + 6.8, 7.3, 14, 1.4, 0, A); blk(x + 5.6, z + 6.8, 7.3, 14, 1.4, 0, A); blk(x, z + 6.8, 3.9, 1, 1.4, 3.6, TR, 0, 0);
      for (const s2 of [-1, 1]) blk(x + s2 * 2.35, z + 7.2, 0.8, 3.7, 0.9, 0, TR, 0, 0); blk(x, z + 7.2, 5.6, 0.8, 0.9, 3.7, TR, 0, 0);
      for (const px of [-4, 0, 4]) for (const pz of [-3, 3]) { blk(x + px, z + pz, 0.9, 8, 0.9, 0, A); blk(x + px, z + pz, 1.3, 0.4, 1.3, 7.6, TR, 0, 0); }
      const o = { sq: 1, trim: TR }; for (const k of [-6, -3.2, 3.2, 6]) win(x + k, z + 7.5, 'S', 6.4, 0.9, 1.3, o); for (const k of [-5, 5]) win(x + k, z + 7.5, 'S', 9.4, 0.9, 1.3, o); for (let i = -8; i <= 8; i += 2) blk(x + i, z - 6.8, 1.3, 0.5, 1.5, 14, TR, 0, 0);
    },
    damo(x, z) {   // Debre Damo: the amba is about 1000 x 400 m; the last sheer cliff is 15 m, climbed on a leather rope. Church and bell tower sizes are estimates
      tk = 'plaster'; const CL = 0xb08556; blk(x, z - 20, 200, 15, 160, 0, CL);
      blk(x, z + 60.3, 3, 2.4, 0.5, 11.8, 0x1a120c, 0, 0); plain(new THREE.CylinderGeometry(0.09, 0.09, 15, 6), 0x5a4020, x + 0.8, heightAt(x, z + 60.5) + 7.5, z + 60.7); plain(new THREE.CylinderGeometry(0.06, 0.06, 15, 6), 0x7a5a30, x - 0.8, heightAt(x, z + 60.5) + 7.5, z + 60.7);
      tk = 'stone'; blk(x, z - 30, 14, 5.5, 8, 15, 0xcfc3a8, 0, 0); blk(x, z - 30, 15, 0.6, 9, 20.5, 0x9a8f7c, 0, 0); tcone(x, z - 30, 5, 2, 21.1, 0xb8974a, 4); cross(x, z - 30, 22.5, 2);
      blk(x + 22, z - 30, 6, 12, 6, 15, 0xcfc3a8, 0, 0); blk(x + 22, z - 30, 6.6, 0.6, 6.6, 27, 0x9a8f7c, 0, 0);
      for (let k = 0; k < 8; k++) blk(x - 30 + k * 8, z - 55, 6, 2.8, 5, 15, 0xc2b69a, 0, 0);
    },
    omar(x, z) {   // Sof Omar: the Weyib river tunnel; the cave system is about 15 km long, here the first 300 m
      tk = 'plaster'; const L = 0xcbc0a6, LEN = 300, SEG = 10, Z1 = z + 30;
      for (let k = 0; k < SEG; k++) { const zc = Z1 - LEN / SEG * (k + 0.5), sl = LEN / SEG; blk(x - 12, zc, 10, 18, sl + 0.2, 0, L); blk(x + 12, zc, 10, 18, sl + 0.2, 0, L); blk(x, zc, 34, 5, sl + 0.2, 13, L, 0, 0); blk(x, zc, 4, 0.12, sl + 0.2, 0.05, 0x3a5a6a, 0, 0); }
      blk(x, Z1 - LEN, 34, 18, 2, 0, L);
      for (let i = 0; i < 30; i++) for (const s2 of [-1, 1]) cyl(x + s2 * 6.3, Z1 - 6 - i * 9.6, 0.9, 1.1, 13, 0, L, 10);
      for (let i = 0; i < 130; i++) { const sx = x + (rr() - 0.5) * 11, sz = Z1 - rr() * LEN, hh = 1.5 + rr() * 3.5; plain(new THREE.ConeGeometry(0.35 + rr() * 0.3, hh, 7).rotateX(Math.PI), 0xd8cdb4, sx, heightAt(sx, sz) + 13 - hh / 2, sz); }
    },
    hadar(x, z) {   // Hadar: Lucy's excavation, staked grid, canvas tents, marker stone
      tk = 'plaster'; for (let i = -3; i <= 3; i++) for (const [a, b] of [[i * 2, -7], [i * 2, 7], [-7, i * 2], [7, i * 2]]) blk(x + a, z + b, 0.15, 1.1, 0.15, 0, 0x6b4a2a, 0, 0, 'wood');
      blk(x, z, 6, 0.1, 4, 0.02, 0x5a4630, 0, 0, '-'); for (const k of [-1, 0, 1]) blk(x + k * 2, z, 0.05, 0.05, 4, 0.14, 0xdddddd, 0, 0, '-'); blk(x + 11, z, 1.2, 2.2, 0.6, 0, 0x8a8a84); blk(x + 11, z + 0.34, 0.8, 0.5, 0.05, 1.2, 0xd6c47a, 0, 0, '-');
      cone(x - 12, z + 8, 2.6, 2.4, 0, 0xeee6d2, 4, 'plaster'); cone(x - 14, z - 6, 2.6, 2.4, 0, 0xeee6d2, 4, 'plaster'); blk(x - 7, z + 10, 2, 0.8, 1.2, 0, WOOD, 0, 1, 'wood');
    },
    mekelle(x, z) { castle(x, z, 48, 26, 10, 0x9b8a70, 20); blk(x, z + 30, 70, 4, 1.4, 0, 0x9b8a70); },
    entoto(x, z) { church(x, z, 8, 8, 0x9a7a3a); blk(x + 25, z + 5, 16, 4, 9, 0, 0xcbb08a); cone(x + 25, z + 5, 10, 3.5, 4, 0xb89a52); },
    libanos(x, z) { church(x, z, 11, 10, 0x8a8a8a); blk(x - 24, z, 12, 4, 8, 0, 0xcbb08a); blk(x - 24, z + 14, 12, 4, 8, 0, 0xcbb08a); },
    adwa(x, z) {   // Adwa: victory memorial with stepped plinth, obelisk, flag and two cannon
      tk = 'plaster'; blk(x, z, 11, 0.5, 11, 0, 0x9a948a, 0, 0); blk(x, z, 9, 0.5, 9, 0.5, 0x9a948a, 0, 0); blk(x, z, 7, 0.5, 7, 1, 0x9a948a, 0, 0); tap(x, z, 3.2, 3.2, 14, 0.45, 0x8d8a84); blk(x, z, 4, 0.5, 4, 1.5, 0xa8a398, 0, 0); cone(x, z, 1.1, 2, 14.2, 0x8d8a84, 4); ball(x, z, 0.3, 16.4, GOLD);
      plain(new THREE.CylinderGeometry(0.1, 0.1, 14, 6), 0xdddddd, x + 7, heightAt(x + 7, z) + 7, z, 0, '-'); [0x078930, 0xfcdd09, 0xda121a].forEach((c, i) => plain(new THREE.BoxGeometry(3, 0.5, 0.05), c, x + 8.6, heightAt(x + 7, z) + 13.3 - i * 0.5, z, 0, '-'));
      for (const s of [-1, 1]) { const cx2 = x + s * 7, cz2 = z + 7, gy = heightAt(cx2, cz2); plain(new THREE.CylinderGeometry(0.28, 0.36, 3.2, 10).rotateZ(1.5708), 0x2a2a2a, cx2, gy + 1.1, cz2, 0.4, '-'); for (const k of [-1, 1]) plain(new THREE.CylinderGeometry(0.7, 0.7, 0.14, 14).rotateX(1.5708), 0x4a3320, cx2 - k * 0.2, gy + 0.7, cz2 + k * 0.7, 0.4, 'wood'); }
    }
  };
  for (const [name, la, lo, fn, R, blurb] of HS) {
    const [x, z] = xzOf(la, lo); if (Math.abs(x) > lim || Math.abs(z) > lim) continue;
    try {
      tk = 'stone'; B[fn](x, z); U.push({ x, z, R, name, blurb, id: fn });
      const d = SPW[fn] || [0, 40], sx = x + d[0] * 0.8 + 3, sz = z + d[1] * 0.8, cv = document.createElement('canvas'); cv.width = 512; cv.height = 150; const g = cv.getContext('2d');
      g.fillStyle = '#4a3320'; g.fillRect(0, 0, 512, 150); g.strokeStyle = '#d6c47a'; g.lineWidth = 6; g.strokeRect(6, 6, 500, 138); g.fillStyle = '#f2efe6'; g.font = 'bold 30px Georgia'; g.textAlign = 'center';
      const w = name.split(' '), mid = Math.ceil(w.length / 2); g.fillText(w.slice(0, mid).join(' '), 256, 62); g.fillText(w.slice(mid).join(' '), 256, 104);
      const t = new THREE.CanvasTexture(cv), sg = new THREE.Mesh(new THREE.PlaneGeometry(4, 1.17), new THREE.MeshBasicMaterial({ map: t, side: THREE.DoubleSide })); sg.position.set(sx, heightAt(sx, sz) + 2.3, sz); sg.rotation.y = Math.atan2(d[0], d[1]); root.add(sg);
      for (const o of [-1.7, 1.7]) put(new THREE.BoxGeometry(0.15, 2.6, 0.15), 0x4a3320, sx + o * Math.cos(sg.rotation.y), heightAt(sx, sz) + 1.1, sz - o * Math.sin(sg.rotation.y));
    } catch (e) { console.warn('heritage', fn, e); }
  }
  let acc = 0;
  return dt => {
    let inn = null; for (const r of I) if (Math.abs(P.x - r.x) < r.w / 2 && Math.abs(P.z - r.z) < r.d / 2) { inn = r; break; }
    lamp.intensity = lerp(lamp.intensity, inn ? 1.8 : 0, Math.min(1, dt * 6)); if (inn) lamp.position.set(inn.x, heightAt(inn.x, inn.z) + 3, inn.z);
    acc += dt; if (acc < 0.5) return; acc = 0;
    for (const u of U) if (!seenHS.has(u.id) && Math.hypot(P.x - u.x, P.z - u.z) < u.R) {
      seenHS.add(u.id); const had = save.hs || []; if (!had.includes(u.id)) { save.hs = had.concat(u.id); store(); }
      toast(u.name + ' (historic site ' + (save.hs || []).length + ' / ' + HS.length + ') — ' + u.blurb, 8);
    }
  };
}

/* ---------- boot ---------- */
setTimeout(async () => {
  if (C.real) {
    $('msg').textContent = 'Loading real terrain: ' + (C.real.name || '') + '...';
    try { await loadReal(); } catch (e) { REAL = null; $('msg').textContent = 'Could not download real terrain (offline?). Using the generated world.'; await new Promise(r => setTimeout(r, 2500)); }
  }
  const W = {}; let rebuilding = false, lastBorder = -99, placeNext = false;
  const baseS = new Set(scene.children), baseC = new Set(camera.children), RC = C.real ? Math.max(500, C.size * 0.17) : 1e9;
  const disposeObj = o => o.traverse(c => { if (c.geometry) c.geometry.dispose(); const ms = c.material ? [].concat(c.material) : []; ms.forEach(m => { for (const k of ['map', 'normalMap']) if (m[k]) m[k].dispose(); m.dispose(); }); });
  function teardown() {
    for (const o of scene.children.slice()) if (!baseS.has(o)) { scene.remove(o); disposeObj(o); }
    for (const o of camera.children.slice()) if (!baseC.has(o)) camera.remove(o);
    grid.clear(); boxes.length = 0; site = null; const pr = document.getElementById('vprompt'); if (pr) pr.remove();
  }
  function buildWorld(first) {
    if (!first) teardown();
    let sp;
    if (first) { sp = findSpawn(); site = findSite(); if (site) { sp[0] = site[0] + 26; sp[2] = site[1] + 22; sp[1] = heightAt(sp[0], sp[2]); } }
    else { site = findSite(); sp = [P.x, heightAt(P.x, P.z), P.z]; }
    const spx = first ? sp : [sp[0] + 25, heightAt(sp[0] + 25, sp[2]), sp[2]];
    W.water = buildTerrain(); populate(); W.village = buildVillage(); W.grass = makeGrass(); W.mist = makeMist(); W.anim = makeAnimals(sp); W.relic = makeRelics(sp); W.heritage = makeHeritage(); W.map = makeMap(); W.wolf = makeWolves(sp); W.extras = makeExtras(spx); W.view = makePlayer(); map3d = makeMap3D();
    P.home = [sp[0], sp[1], sp[2]];
    const hsp = (first || placeNext) ? hsSpawn() : null; placeNext = false;
    if (hsp) { sp = [hsp[0], heightAt(hsp[0], hsp[1]), hsp[1]]; P.home = [sp[0], sp[1], sp[2]]; P.x = sp[0]; P.z = sp[2]; P.y = sp[1]; P.yaw = hsp[2]; P.vx = P.vy = P.vz = 0; }
    else     if (first) { P.x = sp[0]; P.y = sp[1]; P.z = sp[2]; P.yaw = site ? Math.atan2(sp[0] - site[0], sp[2] - site[1]) : 0; }
    else { P.y = sp[1]; P.vx = P.vy = P.vz = 0; }
  }
  // Walking far from the centre of the loaded land: load real terrain around the new spot (the whole of Ethiopia is one continuous world).
  async function recenter() {
    rebuilding = true;
    const R = C.real, old = { lat: R.lat, lon: R.lon }, [nl, nn] = llOf(P.x, P.z), kx = P.x, kz = P.z;
    if (ETH_inside && !ETH_inside(nn, nl)) {
      P.x = clamp(P.x, -RC, RC); P.z = clamp(P.z, -RC, RC); P.vx = P.vz = 0;
      if (performance.now() - lastBorder > 6000) { lastBorder = performance.now(); toast('This is the border of Ethiopia. Turn back.', 3); }
      rebuilding = false; return;
    }
    toast('Travelling on... loading the next part of Ethiopia', 6);
    R.lat = nl; R.lon = nn;
    try { await loadReal(); } catch (e) { R.lat = old.lat; R.lon = old.lon; P.x = clamp(P.x, -RC, RC); P.z = clamp(P.z, -RC, RC); toast('Could not load more land (offline?).', 4); rebuilding = false; return; }
    P.x -= kx; P.z -= kz; buildWorld(false);
    toast('You have entered a new part of Ethiopia  (' + nl.toFixed(2) + '°N, ' + nn.toFixed(2) + '°E, ' + Math.round(ALT(heightAt(P.x, P.z))) + ' m)', 4);
    rebuilding = false;
  }
  // Fast travel (used by the Atlas): load the real land around any point inside Ethiopia and set the player down there.
  async function travelTo(lat, lon, label) {
    if (rebuilding || !C.real || !REAL) return false;
    { const hn = hsNear(lat, lon); if (hn) { lat = hn[1]; lon = hn[2]; label = hn[0]; } }
    if (ETH_inside && !ETH_inside(lon, lat)) { toast('That place is outside Ethiopia.', 3); return false; }
    rebuilding = true; travelBusy = true; travelOverlay(label || (lat.toFixed(2) + '°N, ' + lon.toFixed(2) + '°E'));
    const R = C.real, old = { lat: R.lat, lon: R.lon }, t0 = performance.now();
    R.lat = lat; R.lon = lon;
    try { await loadReal(); } catch (e) { R.lat = old.lat; R.lon = old.lon; toast('Could not load that part of Ethiopia (offline?).', 4); travelOverlay(null); travelBusy = false; rebuilding = false; return false; }
    const wait = 900 - (performance.now() - t0); if (wait > 0) await new Promise(r => setTimeout(r, wait));
    P.x = 0; P.z = 0; placeNext = true; buildWorld(false); P.vx = P.vy = P.vz = 0;
    try { history.replaceState(null, '', '?lat=' + lat.toFixed(4) + '&lon=' + lon.toFixed(4)); } catch (e) {}
    toast('You have arrived  (' + lat.toFixed(2) + '°N, ' + lon.toFixed(2) + '°E, ' + Math.round(ALT(heightAt(P.x, P.z))) + ' m)', 4);
    travelOverlay(null); travelBusy = false; rebuilding = false; return true;
  }
  window.ATLAS_TRAVEL = travelTo;
  buildWorld(true);
  $('msg').textContent = 'The valley is ready.'; $('go').hidden = false;
  $('go').onclick = () => window.HR_INPUT.start(window.HR_INPUT.soft);
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  let last = performance.now(), fps = 60, tw = 0, tbird = 3;
  (function loop(now) {
    requestAnimationFrame(loop);
    const dt = Math.min(0.05, (now - last) / 1000); last = now; perf(dt); if (locked && !rebuilding && C.real && REAL && (Math.abs(P.x) > RC || Math.abs(P.z) > RC)) recenter(); fps = lerp(fps, 1 / Math.max(dt, 1e-3), 0.05);
    if (locked && !mapOpen && !travelBusy) { update(dt, W.water); survival(dt); if (!P.won) P.time += dt; }
    const dayF = lighting(locked ? dt : dt * 0.2); weather(dt); W.mist(dayF); W.extras(dt, tw, locked); invUI(tw); if (W.village) W.village(dt, tw); W.anim(dt); if (locked && !mapOpen && !travelBusy) { W.relic(dt, tw); if (W.heritage) W.heritage(dt, tw); W.map(); ambience(dt); combat(dt); W.wolf(dt); }
    const eye = C.eye - P.crouch * 0.7 + Math.sin(P.bob) * 0.04 * (P.ground ? 1 : 0);
    camera.position.set(P.x, P.y + eye, P.z); camera.rotation.set(P.pitch + (Math.random() - .5) * P.shake, P.yaw + (Math.random() - .5) * P.shake, 0); W.view(dt);
    const tf = (C.fov || 70) + (Math.hypot(P.vx, P.vz) > C.walk * 1.3 ? 7 : 0) - P.crouch * 3 - (FXS.zoom ? 46 : 0) - (drawing ? Math.min(1, charge / 0.9) * 16 : 0);
    if (Math.abs(camera.fov - tf) > 0.05) { camera.fov = lerp(camera.fov, tf, Math.min(1, dt * 6)); camera.updateProjectionMatrix(); }
    tw += dt; W.water.position.y = C.waterLevel + Math.sin(tw * 0.8) * 0.06; SU.uTime.value = tw; WIND.value = tw; W.grass(P.x, P.z, tw); cullAll(P.x, P.z); fxUpdate(dt, tw, dayF);
    if (windGain) windGain.gain.value = 0.03 + 0.03 * (Math.sin(tw * 0.3) * 0.5 + 0.5) * (1 + P.y * 0.02);
    if ((tbird -= dt) < 0) { tbird = 2 + Math.random() * 6; if (dayF > 0.4 && P.y > 2.5) for (let i = 0, n = 1 + Math.random() * 3 | 0; i < n; i++) setTimeout(chirp, i * 140); }
    if (locked) {
      const deg = ((-P.yaw * 180 / Math.PI) % 360 + 360) % 360;
      $('heading').textContent = dirs[Math.round(deg / 45) % 8]; $('deg').textContent = Math.round(deg) + '°';
      $('stam').style.width = P.stam + '%'; $('stam').style.background = P.tired ? '#b5533c' : '#d6c47a';
      $('info').textContent = 'alt ' + ALT(P.y).toFixed(0) + ' m above sea level   ' + fxTemp() + '   ' + (P.swim ? 'swimming' : '') + '\n' + fps.toFixed(0) + ' fps  ' + qLabel() + (fast ? '   time x20' : '') + (rain > 0.3 ? '   rain' : '');
    }
    if (mapOpen && map3d) map3d.render(dt); else { renderer.render(scene, camera); if (FXS.shot) fxPhoto(); }
  })(last);
}, 60);

/* ---------- ATLAS: real Ethiopia data shared by every map (elevation, border, rivers, lakes, places, layers, trail, pins) ---------- */
(() => {
  const BORDER = [[36.54,14.26],[37.0,14.38],[37.9,14.88],[38.45,14.42],[39.1,14.65],[39.8,14.6],[40.3,14.45],[40.8,14.25],[41.3,13.7],[41.8,13.0],[42.4,12.45],[42.4,11.9],[43.0,11.0],[43.3,10.2],[43.5,9.6],[44.4,8.95],[45.4,8.2],[46.6,7.95],[48.0,8.0],[47.3,6.9],[46.4,6.0],[45.5,5.0],[44.0,4.9],[43.2,4.4],[41.9,3.98],[41.0,3.9],[39.9,3.5],[38.1,3.6],[36.9,4.4],[35.9,4.7],[35.0,5.3],[34.5,6.0],[34.1,6.8],[34.4,7.6],[33.7,8.4],[33.0,8.5],[33.6,9.5],[34.2,9.9],[34.1,11.0],[35.1,11.9],[36.0,12.7],[36.5,13.8]];
  // [name, lat, lon, priority]  3 = capital, 2 = major town, 1 = smaller town
  const CITIES = [['Addis Ababa', 9.03, 38.74, 3], ['Mekelle', 13.5, 39.47, 2], ['Bahir Dar', 11.6, 37.39, 2], ['Gondar', 12.6, 37.47, 2], ['Dire Dawa', 9.6, 41.86, 2], ['Hawassa', 7.05, 38.48, 2], ['Jimma', 7.67, 36.83, 2], ['Adama', 8.54, 39.27, 2], ['Jijiga', 9.35, 42.8, 2], ['Harar', 9.31, 42.12, 2], ['Gambela', 8.25, 34.58, 2], ['Semera', 11.79, 41.0, 2],
    ['Dessie', 11.13, 39.63, 1], ['Aksum', 14.12, 38.72, 1], ['Lalibela', 12.03, 39.04, 1], ['Assosa', 10.07, 34.53, 1], ['Nekemte', 9.09, 36.55, 1], ['Debre Markos', 10.33, 37.72, 1], ['Mizan Teferi', 6.99, 35.58, 1], ['Arba Minch', 6.03, 37.55, 1], ['Shashemene', 7.2, 38.6, 1], ['Goba', 7.0, 39.98, 1], ['Gode', 5.95, 43.55, 1], ['Kebri Dahar', 6.74, 44.27, 1], ['Negele', 5.33, 39.58, 1], ['Moyale', 3.53, 39.05, 1], ['Dolo Odo', 4.18, 42.07, 1], ['Jinka', 5.78, 36.57, 1]];
  // kind: peak | volcano | water | region ; priority as above
  const FEATURES = [['Ras Dejen  4,550 m', 13.2417, 38.3694, 'peak', 2], ['Tullu Demtu  4,377 m', 6.83, 39.82, 'peak', 2], ['Abuna Yosef  4,260 m', 12.17, 39.25, 'peak', 1], ['Erta Ale', 13.6, 40.67, 'volcano', 2],
    ['Lake Tana', 12.0, 37.32, 'water', 2], ['Lake Ziway', 7.95, 38.85, 'water', 1], ['Lake Abaya', 6.3, 37.9, 'water', 1], ['Lake Abbe', 11.15, 41.78, 'water', 1], ['Lake Afrera', 13.25, 40.85, 'water', 1], ['GERD reservoir', 11.05, 35.35, 'water', 1],
    ['Abay (Blue Nile)', 10.2, 37.1, 'water', 1], ['Awash', 9.75, 40.2, 'water', 1], ['Omo', 7.2, 37.5, 'water', 1], ['Wabe Shebelle', 6.95, 41.6, 'water', 1], ['Tekeze', 13.4, 38.2, 'water', 1],
    ['Danakil Depression', 13.6, 40.2, 'region', 1], ['Great Rift Valley', 7.35, 38.95, 'region', 1],
    ['TIGRAY', 14.1, 39.6, 'region', 0], ['AMHARA', 11.35, 38.0, 'region', 0], ['AFAR', 11.4, 40.9, 'region', 0], ['OROMIA', 8.0, 39.3, 'region', 0], ['SOMALI', 6.6, 44.2, 'region', 0], ['BENISHANGUL-GUMUZ', 10.5, 35.0, 'region', 0], ['GAMBELA', 7.7, 34.5, 'region', 0], ['SOUTH ETHIOPIA', 5.7, 37.2, 'region', 0]];
  // [name, width, [[lon, lat], ...]]
  const RIVERS = [
    ['Abay', 2.4, [[37.38,11.60],[37.59,11.49],[37.85,11.2],[38.05,10.85],[38.2,10.3],[38.15,10.0],[37.7,10.05],[37.3,10.25],[36.8,10.5],[36.2,10.9],[35.6,11.1],[35.1,11.2],[34.5,11.3]]],
    ['Awash', 2.2, [[38.3,9.0],[38.6,8.7],[39.0,8.45],[39.4,8.55],[39.9,8.85],[40.17,9.0],[40.2,9.7],[40.65,10.15],[41.1,10.7],[41.5,11.0],[41.8,11.15]]],
    ['Omo', 2.2, [[37.9,8.8],[37.6,8.3],[37.4,7.7],[37.55,7.0],[37.5,6.5],[37.1,6.2],[36.6,6.1],[36.0,5.7],[36.0,5.0],[36.05,4.75]]],
    ['Wabe Shebelle', 2.0, [[39.6,7.5],[40.4,7.35],[41.2,6.9],[42.0,6.4],[43.0,5.95],[43.55,5.95],[44.3,5.3]]],
    ['Genale', 1.8, [[39.7,6.4],[40.3,5.9],[40.9,5.3],[41.4,4.6],[41.8,4.1]]],
    ['Tekeze', 1.8, [[39.0,12.1],[38.6,12.8],[38.2,13.5],[37.9,13.8],[37.5,14.0],[36.65,14.15]]],
    ['Baro', 1.8, [[36.1,8.0],[35.6,8.3],[35.1,8.3],[34.6,8.25],[34.0,8.4]]]
  ];
  // [name, lat, lon, half-width deg lon, half-height deg lat, rotation deg]
  const LAKES = [['Tana', 12.0, 37.32, 0.38, 0.30, 0], ['Ziway', 7.9, 38.85, 0.10, 0.12, 0], ['Langano', 7.6, 38.75, 0.07, 0.10, 0], ['Abijatta', 7.62, 38.6, 0.07, 0.05, 0], ['Shala', 7.47, 38.55, 0.07, 0.08, 0], ['Hawassa', 7.05, 38.43, 0.05, 0.06, 0],
    ['Abaya', 6.3, 37.9, 0.10, 0.20, 0], ['Chamo', 5.85, 37.55, 0.07, 0.14, 0], ['Abbe', 11.15, 41.78, 0.15, 0.10, 0], ['Afrera', 13.25, 40.85, 0.10, 0.08, 0], ['Koka', 8.4, 39.0, 0.05, 0.04, 0], ['GERD', 11.1, 35.3, 0.30, 0.13, 25]];

  const W0 = 32.6, E0 = 48.4, S0 = 3.0, N0 = 15.4, Z = 7, NT = 2 ** Z, TS = 256;
  const tx = lon => (lon + 180) / 360 * NT, ty = lat => (1 - Math.log(Math.tan(lat * Math.PI / 180) + 1 / Math.cos(lat * Math.PI / 180)) / Math.PI) / 2 * NT;
  const lonOf = u => u / NT * 360 - 180, latOf = v => Math.atan(Math.sinh(Math.PI * (1 - 2 * v / NT))) * 180 / Math.PI;
  const inside = (lon, lat) => { let c = false; for (let i = 0, j = BORDER.length - 1; i < BORDER.length; j = i++) { const [xi, yi] = BORDER[i], [xj, yj] = BORDER[j]; if ((yi > lat) !== (yj > lat) && lon < (xj - xi) * (lat - yi) / (yj - yi) + xi) c = !c; } return c; };
  ETH_inside = inside;
  const x0 = Math.floor(tx(W0)), x1 = Math.floor(tx(E0)), y0 = Math.floor(ty(N0)), y1 = Math.floor(ty(S0));
  const pxA = (tx(W0) - x0) * TS, pxB = (tx(E0) - x0) * TS, pyA = (ty(N0) - y0) * TS, pyB = (ty(S0) - y0) * TS, OW = Math.round(pxB - pxA), OH = Math.round(pyB - pyA);
  const MPP = 156543.03392 * Math.cos(9 * Math.PI / 180) / (NT);   // metres per map pixel (at 9 degrees north)
  const pos = (lat, lon) => [(tx(lon) - x0) * TS - pxA, (ty(lat) - y0) * TS - pyA];
  const unpos = (px, py) => [latOf(y0 + (pyA + py) / TS), lonOf(x0 + (pxA + px) / TS)];
  const here = () => { const R = C.real; if (!R) return null; return [R.lat - P.z / 111320, R.lon + P.x / (111320 * Math.cos(R.lat * Math.PI / 180))]; };
  const kmBetween = (a, b) => Math.hypot((b[1] - a[1]) * 111.32 * Math.cos((a[0] + b[0]) / 2 * Math.PI / 180), (b[0] - a[0]) * 111.32);
  const bearing = (a, b) => { const dx = (b[1] - a[1]) * Math.cos((a[0] + b[0]) / 2 * Math.PI / 180), dy = b[0] - a[0]; return ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(((Math.atan2(dx, dy) * 180 / Math.PI) % 360 + 360) % 360 / 45) % 8]; };

  /* ----- colour ramps ----- */
  const mix = (a, b, t) => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];
  const ramp = st => e => { if (e <= st[0][0]) return st[0][1]; for (let i = 1; i < st.length; i++) if (e < st[i][0]) { const a = st[i - 1], b = st[i]; return mix(a[1], b[1], (e - a[0]) / (b[0] - a[0])); } return st[st.length - 1][1]; };
  const RELIEF = ramp([[-130, [214, 206, 190]], [-1, [226, 218, 196]], [0, [30, 110, 35]], [500, [70, 145, 30]], [1000, [165, 190, 40]], [1500, [248, 208, 60]], [2000, [236, 150, 30]], [2500, [190, 96, 26]], [3000, [140, 60, 26]], [3800, [105, 42, 30]], [4500, [238, 230, 228]]]);
  const BIOME = ramp([[-130, [238, 230, 210]], [-1, [228, 216, 190]], [0, [214, 190, 140]], [850, [214, 190, 140]], [950, [204, 176, 98]], [1750, [190, 160, 84]], [1850, [170, 176, 82]], [2350, [150, 170, 76]], [2450, [82, 142, 82]], [3150, [70, 128, 74]], [3250, [130, 136, 102]], [4050, [128, 128, 108]], [4150, [226, 232, 236]]]);
  const TOPO = ramp([[-130, [150, 170, 190]], [0, [92, 106, 100]], [1500, [150, 156, 140]], [3000, [205, 205, 196]], [4500, [250, 250, 250]]]);
  const LAYERS = [['relief', 'Relief (height colours)', RELIEF], ['biome', 'Game biomes (by altitude)', BIOME], ['topo', 'Shaded grey', TOPO]];
  const LEGEND = {
    relief: [[0, '0 m'], [500, ''], [1000, '1,000'], [1500, ''], [2000, '2,000'], [2500, ''], [3000, '3,000'], [3800, ''], [4500, '4,500 m']].map(([e, t]) => [RELIEF(e), t]),
    biome: [[-50, 'Below sea level'], [500, 'Lowland / desert'], [1400, 'Kolla'], [2100, 'Woina Dega'], [2800, 'Dega'], [3600, 'Afroalpine'], [4300, 'Frost']].map(([e, t]) => [BIOME(e), t]),
    topo: [[0, '0 m'], [1500, ''], [3000, '3,000'], [4500, '4,500 m']].map(([e, t]) => [TOPO(e), t])
  };
  const zoneName = e => e < 0 ? 'Danakil depression (below sea level)' : e < 900 ? 'Lowland / desert' : e < 1800 ? 'Kolla (hot lowland)' : e < 2400 ? 'Woina Dega (farmland)' : e < 3200 ? 'Dega (cool highland)' : e < 4100 ? 'Afroalpine' : 'Afroalpine frost zone';
  const fmtN = n => Math.round(n).toLocaleString('en-US');

  /* ----- data ----- */
  let ready = false, EL = null, IN = null, SH = null;
  const layerCache = {}, scaledCache = {};
  const tick = () => new Promise(r => setTimeout(r, 0));
  const D = {
    OW, OH, mpp: MPP, pos, unpos, here, inside, kmBetween, bearing, zoneName, fmtN, BORDER, CITIES, FEATURES, RIVERS, LAKES, LAYERS, LEGEND,
    get ready() { return ready; }, EL: null, IN: null, SH: null, img: null, trailRev: 0, pinRev: 0,
    elevAt(px, py) {
      const u = clamp(px, 0, OW - 1.001), v = clamp(py, 0, OH - 1.001), i = Math.floor(u), j = Math.floor(v), fx = u - i, fy = v - j;
      return lerp(lerp(EL[j * OW + i], EL[j * OW + i + 1], fx), lerp(EL[(j + 1) * OW + i], EL[(j + 1) * OW + i + 1], fx), fy);
    },
    get layerKind() { return LAYERS.some(l => l[0] === save.layer) ? save.layer : 'relief'; },
    setLayer(k) { if (!LAYERS.some(l => l[0] === k)) return; save.layer = k; store(); },
    nextLayer() { const i = LAYERS.findIndex(l => l[0] === D.layerKind); D.setLayer(LAYERS[(i + 1) % LAYERS.length][0]); return D.layerKind; },
    layerLabel(k) { return LAYERS.find(l => l[0] === (k || D.layerKind))[1]; },
    layerCanvas(k) { k = k || D.layerKind; return layerCache[k] || (layerCache[k] = buildLayer(k)); },
    pins() { return save.pins || (save.pins = []); },
    togglePin(lat, lon) {
      const p = D.pins(); let hit = -1; p.forEach((q, i) => { if (kmBetween(q, [lat, lon]) < 18) hit = i; });
      if (hit >= 0) p.splice(hit, 1); else if (p.length < 24) p.push([+lat.toFixed(4), +lon.toFixed(4)]); else return 0;
      D.pinRev++; store(); return hit >= 0 ? -1 : 1;
    },
    trail() { return save.trail || []; },
    // nearest named place to a lat/lon: { name, km, dir }
    nearest(lat, lon) {
      let best = null, bd = 1e9; const q = [lat, lon];
      const test = (n, la, lo) => { const d = kmBetween(q, [la, lo]); if (d < bd) { bd = d; best = [n, la, lo]; } };
      for (const c of CITIES) test(c[0], c[1], c[2]);
      for (const f of FEATURES) if (f[3] !== 'region') test(f[0], f[1], f[2]);
      for (const l of LM) test(l[0], l[1], l[2]);
      return best ? { name: best[0], km: bd, dir: bearing([best[1], best[2]], q) } : null;
    }
  };
  window.ETH3D = null;   // published when the data is ready (the 3D map falls back to the local view until then)

  /* ----- build one coloured layer, with hill-shading, lakes and rivers baked in ----- */
  function smoothLine(g, pts) {
    g.beginPath(); g.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length - 1; i++) { const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2; g.quadraticCurveTo(pts[i][0], pts[i][1], mx, my); }
    g.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  }
  function buildLayer(kind) {
    const L = LAYERS.find(l => l[0] === kind) || LAYERS[0], col = L[2], cv = document.createElement('canvas'); cv.width = OW; cv.height = OH;
    const g = cv.getContext('2d'), im = g.createImageData(OW, OH), d = im.data;
    for (let j = 0; j < OH; j++) for (let i = 0; i < OW; i++) {
      const k = j * OW + i, e = EL[k], sh = SH[k], inn = IN[k] === 1; let c;
      if (inn) {
        c = col(e);
        if (kind === 'biome') { const n = ((Math.imul(i >> 1, 374761393) + Math.imul(j >> 1, 668265263)) >>> 7 & 255) / 255; const f = 0.95 + n * 0.1; c = [c[0] * f, c[1] * f, c[2] * f]; }
        d[k * 4] = c[0] * sh; d[k * 4 + 1] = c[1] * sh; d[k * 4 + 2] = c[2] * sh;
      } else if (e <= 0) { const dp = clamp(-e / 2200, 0, 1); d[k * 4] = 16 - dp * 8; d[k * 4 + 1] = 54 - dp * 24; d[k * 4 + 2] = 100 - dp * 38; }
      else { const gr = 100 + clamp(e / 30, 0, 50); d[k * 4] = gr * 0.86 * sh * 0.72; d[k * 4 + 1] = gr * 0.9 * sh * 0.72; d[k * 4 + 2] = gr * 0.82 * sh * 0.72; }
      d[k * 4 + 3] = 255;
    }
    g.putImageData(im, 0, 0);
    g.lineJoin = g.lineCap = 'round';
    g.fillStyle = 'rgba(54,132,186,.97)'; g.strokeStyle = 'rgba(18,72,116,.9)'; g.lineWidth = 1.2;
    for (const [, la, lo, rx, ry, rot] of LAKES) {
      const r = rot * Math.PI / 180, pts = []; for (let a = 0; a < 6.2832; a += 0.3) { const u = rx * Math.cos(a), v = ry * Math.sin(a); pts.push(pos(la + u * Math.sin(r) + v * Math.cos(r), lo + u * Math.cos(r) - v * Math.sin(r))); }
      g.beginPath(); pts.forEach((p, i) => i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1])); g.closePath(); g.fill(); g.stroke();
    }
    g.strokeStyle = 'rgba(74,156,222,.97)';
    for (const [, w, line] of RIVERS) { g.lineWidth = w; smoothLine(g, line.map(([lo, la]) => pos(la, lo))); g.stroke(); }
    return cv;
  }

  async function load() {
    const cv = document.createElement('canvas'); cv.width = (x1 - x0 + 1) * TS; cv.height = (y1 - y0 + 1) * TS; const cx = cv.getContext('2d', { willReadFrequently: true });
    let failed = 0, total = 0; const jobs = [];
    const getTile = (i, j) => new Promise(res => {
      let tries = 0; const go = () => { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => { cx.drawImage(im, (i - x0) * TS, (j - y0) * TS); res(); }; im.onerror = () => { if (++tries < 3) setTimeout(go, 400 * tries); else { failed++; cx.fillStyle = 'rgb(128,0,0)'; cx.fillRect((i - x0) * TS, (j - y0) * TS, TS, TS); res(); } }; im.src = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/' + Z + '/' + i + '/' + j + '.png'; }; go();
    });
    for (let i = x0; i <= x1; i++) for (let j = y0; j <= y1; j++) { total++; jobs.push(getTile(i, j)); }
    await Promise.all(jobs);
    if (failed > total * 0.25) throw new Error('map tiles unavailable');
    const W = cv.width, d = cx.getImageData(0, 0, W, cv.height).data, E = (px, py) => { const k = (py * W + px) * 4; return d[k] * 256 + d[k + 1] + d[k + 2] / 256 - 32768; };
    const el = new Float32Array(OW * OH), inn = new Uint8Array(OW * OH), sh = new Float32Array(OW * OH);
    const lonA = lonOf(x0 + pxA / TS), lonStep = (lonOf(x0 + (pxA + OW - 1) / TS) - lonA) / (OW - 1);
    const lx = -0.6, ly = -0.6, lz = 0.53, ln = Math.hypot(lx, ly, lz), Lx = lx / ln, Ly = ly / ln, Lz = lz / ln, ZF = 5, cell = MPP;
    for (let j = 0; j < OH; j++) {
      const lat = latOf(y0 + (pyA + j) / TS), py = Math.min(cv.height - 2, Math.max(1, Math.round(pyA + j)));
      for (let i = 0; i < OW; i++) {
        const px = Math.min(W - 2, Math.max(1, Math.round(pxA + i))), k = j * OW + i, e = E(px, py);
        el[k] = e; inn[k] = inside(lonA + i * lonStep, lat) ? 1 : 0;
        const dzx = (E(px + 1, py) - E(px - 1, py)) / (2 * cell) * ZF, dzy = (E(px, py + 1) - E(px, py - 1)) / (2 * cell) * ZF, nl = Math.hypot(dzx, dzy, 1);
        const s = (-dzx * Lx - dzy * Ly + Lz) / nl;   // lambert (y axis points south, light from the north-west)
        sh[k] = clamp(0.9 + (s - Lz) * 1.7, 0.5, 1.4);
      }
      if ((j & 127) === 127) await tick();
    }
    EL = el; IN = inn; SH = sh; D.EL = el; D.IN = inn; D.SH = sh; ready = true;
    D.img = D.layerCanvas(); window.ETH3D = D;
  }

  /* ----- flat maps (corner mini-map and the pause-screen map) ----- */
  function scaled(src, key, w, h) {
    const ck = key + ':' + w + 'x' + h; if (scaledCache[ck]) return scaledCache[ck];
    const ks = Object.keys(scaledCache); if (ks.length > 7) delete scaledCache[ks[0]];
    let cur = src; while (cur.width / 2 >= w) { const c = document.createElement('canvas'); c.width = Math.ceil(cur.width / 2); c.height = Math.ceil(cur.height / 2); const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, c.width, c.height); cur = c; }
    const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(cur, 0, 0, w, h);
    return (scaledCache[ck] = c);
  }
  const gotSet = () => new Set(save.lm || []);
  function drawFlat(cv, big) {
    const g = cv.getContext('2d'), CW = cv.width, CH = cv.height;
    g.fillStyle = '#0a1216'; g.fillRect(0, 0, CW, CH);
    if (!ready) { g.fillStyle = '#d6c47a'; g.font = '14px Georgia'; g.textAlign = 'center'; g.fillText('Loading the map of Ethiopia…', CW / 2, CH / 2); return; }
    const S = Math.min(CW / OW, CH / OH), ox = (CW - OW * S) / 2, oy = (CH - OH * S) / 2, kind = D.layerKind;
    g.imageSmoothingEnabled = true; g.drawImage(scaled(D.layerCanvas(kind), kind, Math.round(OW * S), Math.round(OH * S)), ox, oy);
    const X = (lat, lon) => { const p = pos(lat, lon); return [ox + p[0] * S, oy + p[1] * S]; };
    g.beginPath(); BORDER.forEach(([lon, lat], i) => { const [a, b] = X(lat, lon); i ? g.lineTo(a, b) : g.moveTo(a, b); }); g.closePath(); g.strokeStyle = 'rgba(255,255,255,.92)'; g.lineWidth = big ? 2 : 1.2; g.stroke();
    g.font = (big ? 'bold 13px' : '9px') + ' Georgia'; g.textAlign = 'left';
    const label = (txt, a, b, col, dx, dy, ital) => { g.font = (ital ? 'italic ' : big ? 'bold ' : '') + (big ? 13 : 9) + 'px Georgia'; g.lineWidth = 3; g.strokeStyle = 'rgba(0,0,0,.72)'; g.strokeText(txt, a + dx, b + dy); g.fillStyle = col; g.fillText(txt, a + dx, b + dy); };
    if (big) for (const [n, la, lo, kd] of FEATURES) { if (kd === 'region') { const [a, b] = X(la, lo); g.save(); g.globalAlpha = 0.38; g.textAlign = 'center'; g.font = 'bold 15px Georgia'; g.fillStyle = '#fff'; g.fillText(n.length > 10 ? n : n.split('').join(' '), a, b); g.restore(); } }
    for (const [n, la, lo, pr] of CITIES) {
      if (!big && pr < 3) continue; const [a, b] = X(la, lo); g.fillStyle = '#fff'; g.beginPath(); g.arc(a, b, pr === 3 ? 4 : 2.6, 0, 6.3); g.fill(); g.lineWidth = 1; g.strokeStyle = '#000'; g.stroke();
      if (big ? pr >= 2 || S > 0.42 : true) label(n, a, b, pr === 3 ? '#ffe9a0' : '#fff', 6, 4);
    }
    if (big) for (const [n, la, lo, kd] of FEATURES) { if (kd !== 'peak' && kd !== 'volcano') continue; const [a, b] = X(la, lo); g.fillStyle = kd === 'volcano' ? '#ff7a3a' : '#f4efe4'; g.strokeStyle = '#000'; g.lineWidth = 1; g.beginPath(); g.moveTo(a, b - 5); g.lineTo(a + 4.5, b + 3); g.lineTo(a - 4.5, b + 3); g.closePath(); g.fill(); g.stroke(); label(n, a, b, '#f6e8cf', 7, -3, true); }
    // your journey
    const tr = D.trail(); if (tr.length) { g.save(); g.strokeStyle = 'rgba(255,214,90,.95)'; g.lineWidth = big ? 2 : 1.4; g.setLineDash(big ? [5, 3] : [3, 2]); for (const sg of tr) { if (sg.length < 2) continue; g.beginPath(); sg.forEach(([la, lo], i) => { const [a, b] = X(la, lo); i ? g.lineTo(a, b) : g.moveTo(a, b); }); g.stroke(); } g.restore(); }
    // relic sites
    const got = gotSet(), h = here();
    LM.forEach(([n, la, lo], i) => {
      const [a, b] = X(la, lo), f = got.has(i), r = big ? 6.5 : 5; g.fillStyle = f ? '#6a6a6a' : '#6ff5e4'; g.strokeStyle = '#052'; g.lineWidth = 1; g.beginPath(); g.moveTo(a, b - r); g.lineTo(a + r * 0.8, b); g.lineTo(a, b + r); g.lineTo(a - r * 0.8, b); g.closePath(); g.fill(); g.stroke();
      if (big) { label((i + 1) + '  ' + n, a, b, f ? '#aaa' : '#bffcf2', 9, -7, true); }
    });
    // pins
    D.pins().forEach(([la, lo]) => { const [a, b] = X(la, lo); g.strokeStyle = '#fff'; g.lineWidth = 1.5; g.beginPath(); g.moveTo(a, b); g.lineTo(a, b - (big ? 12 : 8)); g.stroke(); g.fillStyle = '#ff5fa2'; g.beginPath(); g.moveTo(a, b - (big ? 12 : 8)); g.lineTo(a + (big ? 8 : 5), b - (big ? 9 : 6)); g.lineTo(a, b - (big ? 6 : 4)); g.closePath(); g.fill(); });
    // you
    if (h) {
      const [a, b] = X(h[0], h[1]), t = performance.now() / 700 % 1, fx = -Math.sin(P.yaw), fy = -Math.cos(P.yaw);
      g.strokeStyle = 'rgba(255,40,30,' + (1 - t) + ')'; g.lineWidth = 2; g.beginPath(); g.arc(a, b, 4 + t * (big ? 16 : 10), 0, 6.3); g.stroke();
      const r = big ? 8 : 6; g.save(); g.translate(a, b); g.rotate(Math.atan2(fx, -fy)); g.fillStyle = '#ff2a1e'; g.strokeStyle = '#fff'; g.lineWidth = 1.8; g.beginPath(); g.moveTo(0, -r * 1.25); g.lineTo(r * 0.8, r * 0.85); g.lineTo(0, r * 0.4); g.lineTo(-r * 0.8, r * 0.85); g.closePath(); g.fill(); g.stroke(); g.restore();
    }
    if (big) {
      // legend + scale + compass
      const lg = LEGEND[kind], bw = 54; g.save(); g.fillStyle = 'rgba(8,14,16,.72)'; g.fillRect(8, CH - 46, lg.length * bw + 16, 38); lg.forEach(([c, t], i) => { g.fillStyle = 'rgb(' + c.map(Math.round) + ')'; g.fillRect(16 + i * bw, CH - 40, bw - 2, 9); g.fillStyle = '#e8e4d6'; g.font = '10px Georgia'; g.textAlign = 'left'; if (t) g.fillText(t, 16 + i * bw, CH - 16); }); g.restore();
      const kmPx = MPP / 1000 / S, nice = [50, 100, 200, 500].find(v => v / kmPx < 150) || 500, wpx = nice / kmPx;
      g.fillStyle = 'rgba(8,14,16,.72)'; g.fillRect(CW - wpx - 24, CH - 34, wpx + 16, 26); g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath(); g.moveTo(CW - wpx - 16, CH - 16); g.lineTo(CW - wpx - 16, CH - 12); g.lineTo(CW - 16, CH - 12); g.lineTo(CW - 16, CH - 16); g.stroke(); g.fillStyle = '#fff'; g.font = '11px Georgia'; g.textAlign = 'center'; g.fillText(nice + ' km', CW - wpx / 2 - 16, CH - 19);
      g.fillStyle = '#fff'; g.font = 'bold 14px Georgia'; g.textAlign = 'center'; g.strokeStyle = 'rgba(0,0,0,.7)'; g.lineWidth = 3; g.strokeText('N', CW - 22, 20); g.fillText('N', CW - 22, 20); g.beginPath(); g.moveTo(CW - 22, 24); g.lineTo(CW - 27, 36); g.lineTo(CW - 17, 36); g.closePath(); g.fill();
      const hv = cv._hover;
      if (hv && hv.p) {
        const [lat, lon] = hv.p, [qa, qb] = pos(lat, lon), e = D.elevAt(qa, qb), nr = D.nearest(lat, lon), X0 = ox + qa * S, Y0 = oy + qb * S;
        g.strokeStyle = '#fff'; g.lineWidth = 1.5; g.beginPath(); g.arc(X0, Y0, 7, 0, 6.3); g.moveTo(X0 - 11, Y0); g.lineTo(X0 - 4, Y0); g.moveTo(X0 + 4, Y0); g.lineTo(X0 + 11, Y0); g.moveTo(X0, Y0 - 11); g.lineTo(X0, Y0 - 4); g.moveTo(X0, Y0 + 4); g.lineTo(X0, Y0 + 11); g.stroke();
        const lines = [(nr && nr.km < 12 ? nr.name : 'near ' + (nr ? nr.name : '') + (nr ? '  (' + Math.round(nr.km) + ' km ' + nr.dir + ')' : '')), lat.toFixed(3) + '°N  ' + lon.toFixed(3) + '°E', fmtN(e) + ' m  ·  ' + zoneName(e)];
        g.font = '12px Georgia'; const tw = Math.max(...lines.map(s => g.measureText(s).width)) + 18, th = 62; let bx = X0 + 16, by = Y0 + 14; if (bx + tw > CW - 4) bx = X0 - 16 - tw; if (by + th > CH - 4) by = Y0 - 14 - th;
        g.fillStyle = 'rgba(8,14,16,.86)'; g.fillRect(bx, by, tw, th); g.strokeStyle = 'rgba(255,255,255,.35)'; g.lineWidth = 1; g.strokeRect(bx + .5, by + .5, tw - 1, th - 1); g.textAlign = 'left'; g.fillStyle = '#ffe9a0'; g.fillText(lines[0], bx + 9, by + 18); g.fillStyle = '#e8e4d6'; g.fillText(lines[1], bx + 9, by + 36); g.fillText(lines[2], bx + 9, by + 53);
      }
      g.fillStyle = 'rgba(0,0,0,.6)'; g.fillRect(8, 8, 392, 20); g.fillStyle = '#fff'; g.font = '12px Georgia'; g.textAlign = 'left'; g.fillText('Click anywhere in Ethiopia to travel there   ·   M in game: 3D atlas', 14, 22);
    }
    cv._map = { ox, oy, S };
  }

  /* ----- start: load data, draw, wire up the pause-screen map ----- */
  const mini = $('cmap'), bigC = $('ethmap');
  load().catch(e => { console.warn('Atlas data failed:', e); window.ETH3D = null; });
  setInterval(() => { if (mini && locked) drawFlat(mini, false); if (bigC && !$('start').hidden) drawFlat(bigC, true); }, 120);
  if (bigC) {
    // layer buttons above the map
    const bar = document.createElement('div'); bar.id = 'atlasbar'; bar.style.cssText = 'display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:2px 0';
    const btns = LAYERS.map(([k, t]) => { const b = document.createElement('button'); b.textContent = t; b.style.cssText = 'font:inherit;font-size:13px;padding:4px 12px;border:1px solid rgba(242,239,230,.5);background:transparent;color:#f2efe6;border-radius:999px;cursor:pointer'; b.onclick = () => { D.setLayer(k); sync(); }; bar.appendChild(b); return [k, b]; });
    const sync = () => btns.forEach(([k, b]) => { const on = D.layerKind === k; b.style.background = on ? '#f2efe6' : 'transparent'; b.style.color = on ? '#0d1412' : '#f2efe6'; });
    bigC.parentNode.insertBefore(bar, bigC); sync();
    const q = e => { const r = bigC.getBoundingClientRect(), m = bigC._map; if (!m) return null; const px = (e.clientX - r.left) * bigC.width / r.width, py = (e.clientY - r.top) * bigC.height / r.height, ix = (px - m.ox) / m.S, iy = (py - m.oy) / m.S; if (ix < 0 || iy < 0 || ix > OW || iy > OH) return null; const ll = unpos(ix, iy); return inside(ll[1], ll[0]) ? ll : null; };
    bigC.addEventListener('mousemove', e => { const p = q(e); bigC._hover = p ? { p } : null; bigC.style.cursor = p ? 'crosshair' : 'default'; });
    bigC.addEventListener('mouseleave', () => { bigC._hover = null; });
    bigC.addEventListener('click', e => {
      const p = q(e); if (!p) return;
      if (window.ATLAS_TRAVEL) { $('go').click(); window.ATLAS_TRAVEL(p[0], p[1]); }
      else location.search = '?lat=' + p[0].toFixed(4) + '&lon=' + p[1].toFixed(4);
    });
  }

  // breadcrumb trail of your journey (new segment after every fast-travel)
  setInterval(() => {
    if (!locked || !ready || !C.real) return; const h = here(); if (!h) return;
    const tr = save.trail || (save.trail = []); let sg = tr[tr.length - 1]; const last = sg && sg[sg.length - 1], dk = last ? kmBetween(last, h) : 1e9;
    if (dk < 0.35) return; if (!sg || dk > 8) { sg = []; tr.push(sg); }
    sg.push([+h[0].toFixed(4), +h[1].toFixed(4)]);
    let total = 0; for (const s of tr) total += s.length; while (total > 900 && tr.length) { if (tr[0].length > 1) tr[0].shift(); else tr.shift(); total--; }
    D.trailRev++;
  }, 2000);
})();

})();
