const img={};let loaded=0;const NIMG=Object.keys(IMG).length;
for(const k in IMG){const i=new Image();i.onload=()=>{if(++loaded===NIMG)requestAnimationFrame(loop)};i.src=IMG[k];img[k]=i}

const $=id=>document.getElementById(id);
const cv=$('c'),ctx=cv.getContext('2d');ctx.imageSmoothingEnabled=false;
let W=1280,CX=640;const H=720,IW=1280;   // W melebar otomatis di layar yang lebih lebar dari 16:9, jadi tidak ada pita hitam

// ---------- layar 16:9 (auto-fit) ----------
const stage=$('stage');
function fit(){
  const ar=innerWidth/innerHeight;
  W=Math.max(1280,Math.min(1707,Math.round(H*ar)));CX=W/2;
  if(cv.width!==W){cv.width=W;ctx.imageSmoothingEnabled=false}
  cv.style.width=W+'px';stage.style.width=W+'px';
  const s=Math.min(innerWidth/W,innerHeight/H);
  const ox=(innerWidth-W*s)/2,oy=(innerHeight-H*s)/2;
  stage.style.transform='translate('+ox+'px,'+oy+'px) scale('+s+')';
  $('rot').style.display=innerHeight>innerWidth*1.1?'flex':'none';
}
function goFull(){ // layar penuh otomatis di HP (hilangkan bar browser) + kunci landscape
  try{
    if(!matchMedia('(pointer:coarse)').matches||document.fullscreenElement)return;
    const el=document.documentElement,f=el.requestFullscreen||el.webkitRequestFullscreen;
    if(!f)return;
    Promise.resolve(f.call(el)).then(()=>{try{screen.orientation.lock('landscape').catch(()=>{})}catch(e){}}).catch(()=>{});
  }catch(e){}
}
addEventListener('resize',fit);addEventListener('orientationchange',fit);fit();

// ---------- data mobil (SPEK ASLI — ubah di sini kalau mau) ----------
// vmax km/jam · aG = batas traksi (m/s²) · Pn = daya efektif per kg (W/kg) · gears = kecepatan (km/jam) tiap gigi di redline
// Sudah dikalibrasi: GT-R 0-100=2,9s · 0-200≈9,8s · top 315 | M4 Competition 0-100=3,5s · 0-200≈11,3s · top 290
const K=.36;                       // 1 px/s = 0,36 km/jam  (10 px = 1 meter)
const CFG={
  gtr:{vmax:315,aG:11,Pn:205,gears:[75,125,172,222,272,335],redline:7000,idle:900,shift:.10,rr:.12,wr:34,
       spec:'315 km/jam · 0–100 dalam 2,9 dtk<br>V6 twin-turbo · 565 hp'},
  m4: {vmax:290,aG:9.5,Pn:195,gears:[60,100,138,178,218,252,282,318],redline:7200,idle:800,shift:.18,rr:.12,wr:28.6,
       spec:'290 km/jam · 0–100 dalam 3,5 dtk<br>6-silinder twin-turbo · 510 hp'}
};
for(const k in CFG){const c=CFG[k],vm=c.vmax/3.6;c.cd=(c.Pn/vm-c.rr)/(vm*vm)}

// karakter suara tiap mesin (harm = isi harmonik gelombang letusan)
const SPEC={
  gtr:{harm:n=>Math.pow(n,-.9)*(1+.55*Math.cos(n*1.25)),N:36,sub:.55,rasp:.5,turbo:.03,lpBase:260,lpK:.55,resF:180,resG:6,k:2.2,vol:1,det:7,lope:.14,noise:.05},
  m4: {harm:n=>Math.pow(n,-.72)*((n>=6&&n<=10)?1.5:1),N:36,sub:.3,rasp:.75,turbo:.018,lpBase:420,lpK:.8,resF:300,resG:5,k:1.8,vol:.9,det:5,lope:.05,noise:.05}
};
// model: sprite, ukuran gambar, posisi knalpot (di sprite), roda, seberapa sering knalpot "burble"
const MODELS={
  gtr:{name:'NISSAN GT-R',short:'GT-R',cfg:CFG.gtr,spec:SPEC.gtr,top:'top',side:'side',topW:170,sideW:470,
       pipeTop:[-11,11],pipeSide:[7,156],burble:.8,spit:2,
       wheels:{p:[[141,148],[545,148]],r:37,cal:'#e8262a'}},
  m4: {name:'BMW M4',short:'BMW M4',cfg:CFG.m4,spec:SPEC.m4,top:'m4top',side:'m4side',topW:174,sideW:478,
       pipeTop:[-12,12],pipeSide:[6,138],burble:2.4,spit:3,
       wheels:{p:[[113,121],[458,121]],r:31,cal:'#2a6bff'}}
};
function mkCar(key,x,y){const cfg=MODELS[key].cfg;return{m:key,cfg,x,y,h:0,vx:0,vy:0,vf:0,slip:0,sway:0,gear:0,shiftT:0,rpm:cfg.idle,shifted:0,fin:null,lastThr:0,thr:0,eng:null,spr:null}}

// ---------- sprite: ambil asli atau versi diwarnai (kalau lawan = mobil yang sama) ----------
const tintCache={};
function recolor(im,rgb){
  const c=document.createElement('canvas');c.width=im.width;c.height=im.height;
  const g=c.getContext('2d');g.drawImage(im,0,0);
  const d=g.getImageData(0,0,c.width,c.height),p=d.data;
  for(let i=0;i<p.length;i+=4){
    if(!p[i+3])continue;
    const L=(.3*p[i]+.59*p[i+1]+.11*p[i+2])/255;
    p[i]=Math.min(255,L*rgb[0]*2.3*255);p[i+1]=Math.min(255,L*rgb[1]*2.3*255);p[i+2]=Math.min(255,L*rgb[2]*2.3*255);
  }
  g.putImageData(d,0,0);return c;
}
function tintSprites(key,rgb){
  if(!tintCache[key])tintCache[key]={top:recolor(img[MODELS[key].top],rgb),side:recolor(img[MODELS[key].side],rgb)};
  return tintCache[key];
}
const getSprite=(c,kind)=>c.spr?c.spr[kind]:img[MODELS[c.m][kind]];

// ---------- input ----------
const keys={up:0,down:0,left:0,right:0,drift:0};
const map={ArrowUp:'up',w:'up',ArrowDown:'down',s:'down',ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',' ':'drift',Shift:'drift'};
addEventListener('keydown',e=>{if(e.key==='c'||e.key==='C')toggleCam();const k=map[e.key];if(k){keys[k]=1;e.preventDefault()}});
addEventListener('keyup',e=>{const k=map[e.key];if(k)keys[k]=0});
for(const k of ['up','down','left','right','drift']){
  const el=$(k);
  const on=e=>{e.preventDefault();keys[k]=1;el.classList.add('on')};
  const off=e=>{e.preventDefault();keys[k]=0;el.classList.remove('on')};
  el.addEventListener('pointerdown',on);el.addEventListener('pointerup',off);
  el.addEventListener('pointerleave',off);el.addEventListener('pointercancel',off);
}
let cam=1;
function toggleCam(){cam=cam===1?2:1;$('cam').textContent='CAM '+cam;puffs=[];wind=[]}
$('cam').addEventListener('pointerdown',e=>{e.preventDefault();toggleCam()});
addEventListener('contextmenu',e=>e.preventDefault());

// ---------- state ----------
const ROAD_T=272,ROAD_B=490;           // batas jalur (tampak atas)
const SIDE_S=1;                        // skala jarak kamera samping = kamera atas (1 px dunia = 1 px layar)
let mode='solo',state='menu';          // state: menu | count | race | finish | result | solo
let sel={me:'m4',foe:'m4'};            // me = mobil pemain (dari Garage) · foe = lawan (dipilih di menu 1v1)
const PRICE={gtr:15000};                      // BMW M4 gratis & default · GT-R harus dibeli
let owned=['m4'],money=0,coin=0,colors={},foeChosen=false;   // saldo awal: $0 & 0 Coin (tidak ada pemberian gratis)
const DISTS=[.5,1,2,3,5,10,15,20];let di=1;
// Reward menang 1v1: [Money, Coin] per jarak (km), menurut mobil LAWAN. GT-R ≈ 1,5x BMW M4 (Money dibulatkan ke $50, Coin ke bilangan bulat)
const REWARD={
  m4: {0.5:[100,1],1:[200,2],2:[400,3],3:[650,5],5:[1000,7],10:[2000,12],15:[3500,18],20:[5500,25]},
  gtr:{0.5:[150,2],1:[300,3],2:[600,5],3:[1000,8],5:[1500,11],10:[3000,18],15:[5250,27],20:[8250,38]}
};
// Penyimpanan: satu entri JSON + segel (checksum). Data yang rusak/diubah manual tidak dipakai (kembali ke saldo awal).
const SAVE_KEY='neonGarage';
const hashStr=t=>{let h=2166136261;for(let i=0;i<t.length;i++){h^=t.charCodeAt(i);h=Math.imul(h,16777619)}return(h>>>0).toString(36)};
const sealOf=(o,m,c,col={})=>hashStr('NCR|'+o.join(',')+'|'+m+'|'+c+Object.keys(col).sort().map(k=>'|'+k+'='+col[k]).join(''));
const cleanColors=v=>{const r={};if(v&&typeof v==='object')for(const k in MODELS)if(typeof v[k]==='string'&&/^#[0-9a-f]{6}$/.test(v[k]))r[k]=v[k];return r};
const cleanInt=v=>{v=Math.floor(+v);return isFinite(v)&&v>=0?Math.min(v,999999999):0};
try{
  const g=JSON.parse(localStorage.getItem('neonGarage')||'null');
  if(g&&typeof g==='object'){
    const o=[...new Set(Array.isArray(g.owned)?g.owned.filter(k=>MODELS[k]):[])],m=cleanInt(g.money),c=cleanInt(g.coin);
    const legacy=g.h===undefined&&m===0&&c===0&&o.every(k=>k==='m4');   // data Tahap 1 (belum ada uang/GT-R)
    const cl=cleanColors(g.colors);
    if(g.h===sealOf(o,m,c,cl)||legacy){owned=o;money=m;coin=c;colors=cl}
  }
  if(!owned.includes('m4'))owned.unshift('m4');
  const s=JSON.parse(localStorage.getItem('neonSel')||'null');if(s&&owned.includes(s.me))sel.me=s.me;
  const d=+localStorage.getItem('neonDi');if(d>=0&&d<DISTS.length)di=d;
}catch(e){}
const saveSel=()=>{try{localStorage.setItem('neonSel',JSON.stringify({me:sel.me}));localStorage.setItem('neonDi',di)}catch(e){}};
const saveOwn=()=>{try{localStorage.setItem(SAVE_KEY,JSON.stringify({owned,money,coin,colors,h:sealOf(owned,money,coin,colors)}))}catch(e){}};
// ---------- Custom Color: hanya piksel bodi (mask) yang diwarnai; kaca, ban, lampu, trim tetap ----------
const COLOR_COST=5,DEF_COLOR={gtr:'#40444d',m4:'#1855cb'};   // DEF_COLOR = warna bodi asli tiap mobil
const maskCache={},colCache={},urlCache={};
function dil(m,w,h,r,src){   // dilasi kotak (2r+1), terbatas pada piksel src
  let cur=m;
  for(let it=0;it<r;it++){
    const o=new Uint8Array(cur);
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=y*w+x;if(cur[i]||(src&&!src[i]))continue;
      for(let dy=-1;dy<=1&&!o[i];dy++)for(let dx=-1;dx<=1;dx++){const X=x+dx,Y=y+dy;if(X>=0&&Y>=0&&X<w&&Y<h&&cur[Y*w+X]){o[i]=1;break}}}
    cur=o;
  }
  return cur;
}
function ero(m,w,h){const o=new Uint8Array(m.length);
  for(let y=1;y<h-1;y++)for(let x=1;x<w-1;x++){let k=1;
    for(let dy=-1;dy<=1&&k;dy++)for(let dx=-1;dx<=1;dx++)if(!m[(y+dy)*w+x+dx]){k=0;break}
    o[y*w+x]=k}
  return o}
function bodyMask(name){   // mask bodi dirapikan: lubang kecil ditutup & sisa warna asli di tepi bodi ikut masuk
  if(maskCache[name])return maskCache[name];
  const im=img['mk_'+name],base=img[name];if(!im||!im.width||!base||!base.width)return null;
  const w=im.width,h=im.height;
  const c=document.createElement('canvas');c.width=w;c.height=h;
  const g=c.getContext('2d');g.drawImage(im,0,0);
  const d=g.getImageData(0,0,w,h).data;
  g.clearRect(0,0,w,h);g.drawImage(base,0,0);
  const b=g.getImageData(0,0,w,h).data,N=w*h;
  const m=new Uint8Array(N),opq=new Uint8Array(N),L=new Float32Array(N);
  for(let i=0;i<N;i++){opq[i]=b[i*4+3]>200?1:0;L[i]=.3*b[i*4]+.59*b[i*4+1]+.11*b[i*4+2];m[i]=d[i*4]>127&&opq[i]?1:0}
  const isM4=name.indexOf('m4')===0;
  let out=m;
  if(isM4){   // sisa cat biru asli di dekat bodi (kaliper di dalam roda terlalu jauh, tidak ikut)
    const near=dil(m,w,h,4,null);
    out=new Uint8Array(m);
    for(let i=0;i<N;i++)if(!out[i]&&near[i]&&opq[i]){const r=b[i*4],gg=b[i*4+1],bl=b[i*4+2];
      if(bl>r*1.25+10&&bl>gg*1.05&&L[i]>8)out[i]=1}
  }
  // tutup lubang kecil (closing) tanpa menyentuh outline hitam
  const cl=ero(dil(out,w,h,isM4?1:2,null),w,h);
  const fin=new Uint8Array(out);
  for(let i=0;i<N;i++)if(!fin[i]&&cl[i]&&opq[i]&&L[i]>(isM4?38:22))fin[i]=1;
  return maskCache[name]=fin;
}
function paintBody(key,kind,hex){
  const name=MODELS[key][kind],base=img[name],mask=bodyMask(name);
  if(!base||!mask)return null;
  const c=document.createElement('canvas');c.width=base.width;c.height=base.height;
  const g=c.getContext('2d');g.drawImage(base,0,0);
  const id=g.getImageData(0,0,c.width,c.height),p=id.data;
  const t=[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)];
  let ls=0,n=0;
  for(let i=0;i<mask.length;i++)if(mask[i]){const j=i*4;ls+=.3*p[j]+.59*p[j+1]+.11*p[j+2];n++}
  const ref=n?ls/n:1;                                   // bayangan/kilau bodi asli dipertahankan
  for(let i=0;i<mask.length;i++)if(mask[i]){
    const j=i*4,f=(.3*p[j]+.59*p[j+1]+.11*p[j+2])/ref;
    for(let q=0;q<3;q++){const v=f<=1?t[q]*f:t[q]+(255-t[q])*Math.min(1,(f-1)*.6);p[j+q]=v>255?255:v}
  }
  g.putImageData(id,0,0);return c;
}
function colorSprites(key,hex){   // sprite balap berwarna (null = pakai sprite asli). hex opsional = warna preview picker; kosong = warna tersimpan
  if(hex===undefined)hex=colors[key];
  if(!hex||!/^#[0-9a-f]{6}$/.test(hex))return null;
  const ck=key+hex;if(colCache[ck])return colCache[ck];
  const top=paintBody(key,'top',hex),side=paintBody(key,'side',hex);
  return top&&side?(colCache[ck]={top,side}):null;
}
function sideURL(key,hex,cache){   // gambar samping untuk UI
  if(!hex||!/^#[0-9a-f]{6}$/.test(hex))return IMG[MODELS[key].side];
  const ck=key+hex;if(cache&&urlCache[ck])return urlCache[ck];
  const c=paintBody(key,'side',hex);if(!c)return IMG[MODELS[key].side];
  const u=c.toDataURL();if(cache)urlCache[ck]=u;return u;
}
let car=mkCar(sel.me,0,360),bot=mkCar(sel.foe,0,340),race=null;
let sideScroll=0,puffs=[],wind=[];
const fmtKm=d=>(d<1?d.toFixed(1):String(d))+' km';

// ---------- audio ----------
let AC,master,reverb,started=false,nb,sq={};
let eng1=null,eng2=null;
function mkWave(fn,N){
  const re=new Float32Array(N+1),im=new Float32Array(N+1);
  for(let n=1;n<=N;n++)im[n]=fn(n);
  return AC.createPeriodicWave(re,im);
}
function mkReverb(){ // ruang/gema singkat biar mesin tidak terdengar "kering"
  const len=Math.floor(AC.sampleRate*.7),ir=AC.createBuffer(2,len,AC.sampleRate);
  for(let ch=0;ch<2;ch++){const d=ir.getChannelData(ch);for(let i=0;i<len;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/len,3.2)}
  const cvn=AC.createConvolver();cvn.buffer=ir;
  const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=3200;
  const g=AC.createGain();g.gain.value=.3;
  cvn.connect(lp);lp.connect(g);g.connect(master);return cvn;
}
// Mesin = gelombang letusan (harmonik kaya) x2 + sub-bass + raspy knalpot + desis udara + siulan turbo,
// dilewatkan distorsi lembut, resonansi knalpot, dan filter yang ikut rpm/gas.
function mkEngine(sp){
  const e={sp,thrS:0,vol:1};
  const bus=AC.createStereoPanner?AC.createStereoPanner():AC.createGain();
  const out=AC.createGain();out.gain.value=0;out.connect(bus);bus.connect(master);
  const send=AC.createGain();send.gain.value=.55;bus.connect(send);send.connect(reverb);
  e.bus=bus;e.out=out;
  const wave=mkWave(sp.harm,sp.N);
  const tone=AC.createGain();tone.gain.value=.35;
  const o1=AC.createOscillator();o1.setPeriodicWave(wave);
  const o2=AC.createOscillator();o2.setPeriodicWave(wave);o2.detune.value=sp.det;
  const o3=AC.createOscillator();o3.type='triangle';
  const g3=AC.createGain();g3.gain.value=sp.sub;
  o1.connect(tone);o2.connect(tone);o3.connect(g3);g3.connect(tone);
  const sh=AC.createWaveShaper(),cur=new Float32Array(256);
  for(let i=0;i<256;i++){const x=i/128-1;cur[i]=Math.tanh(x*sp.k)}sh.curve=cur;
  const res=AC.createBiquadFilter();res.type='peaking';res.frequency.value=sp.resF;res.Q.value=1.2;res.gain.value=sp.resG;
  const lp=AC.createBiquadFilter();lp.type='lowpass';lp.Q.value=1.4;
  const amp=AC.createGain();amp.gain.value=0;
  tone.connect(sh);sh.connect(res);res.connect(lp);lp.connect(amp);amp.connect(out);
  // raspy knalpot
  const o4=AC.createOscillator();o4.type='sawtooth';
  const hp=AC.createBiquadFilter();hp.type='highpass';hp.frequency.value=700;
  const raspG=AC.createGain();raspG.gain.value=0;o4.connect(hp);hp.connect(raspG);raspG.connect(out);
  // desis udara/mekanis
  const ns=AC.createBufferSource();ns.buffer=nb;ns.loop=true;
  const nbp=AC.createBiquadFilter();nbp.type='bandpass';nbp.frequency.value=1200;nbp.Q.value=.7;
  const nG=AC.createGain();nG.gain.value=0;ns.connect(nbp);nbp.connect(nG);nG.connect(out);
  // siulan turbo
  const o5=AC.createOscillator();o5.type='sine';
  const tG=AC.createGain();tG.gain.value=0;o5.connect(tG);tG.connect(out);
  // goyangan lembut saat idle ("lope")
  const lfo=AC.createOscillator();lfo.type='sine';lfo.frequency.value=6;
  const lfoG=AC.createGain();lfoG.gain.value=0;lfo.connect(lfoG);lfoG.connect(amp.gain);
  for(const o of [o1,o2,o3,o4,o5,lfo])o.start();
  ns.start(0,Math.random()*.8);
  Object.assign(e,{o1,o2,o3,o4,o5,lfo,lp,amp,raspG,nbp,nG,tG,lfoG,ns});
  return e;
}
function disposeEng(e){
  if(!e)return;
  const t=AC.currentTime;e.out.gain.setTargetAtTime(0,t,.02);
  for(const o of [e.o1,e.o2,e.o3,e.o4,e.o5,e.lfo])try{o.stop(t+.2)}catch(x){}
  try{e.ns.stop(t+.2)}catch(x){}
  setTimeout(()=>{try{e.bus.disconnect()}catch(x){}},400);
}
function buildEngines(duel){
  if(!started)return;
  disposeEng(eng1);disposeEng(eng2);
  eng1=mkEngine(MODELS[car.m].spec);car.eng=eng1;
  eng2=duel?mkEngine(MODELS[bot.m].spec):null;bot.eng=eng2;
}
function startAudio(){
  if(started)return;started=true;
  AC=new (window.AudioContext||window.webkitAudioContext)();
  master=AC.createGain();master.gain.value=.6;
  const comp=AC.createDynamicsCompressor();     // jaga supaya tidak pecah saat banyak suara sekaligus
  comp.threshold.value=-16;comp.knee.value=14;comp.ratio.value=5;comp.attack.value=.004;comp.release.value=.2;
  master.connect(comp);comp.connect(AC.destination);
  const an=AC.createAnalyser();an.fftSize=2048;comp.connect(an);window.__an=an;   // untuk pengujian level suara
  nb=AC.createBuffer(1,AC.sampleRate,AC.sampleRate);const d=nb.getChannelData(0);
  for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
  reverb=mkReverb();
  // decit ban (pemain)
  const ns=AC.createBufferSource();ns.buffer=nb;ns.loop=true;
  const bp=AC.createBiquadFilter();bp.type='bandpass';bp.frequency.value=1900;bp.Q.value=6;
  const sg=AC.createGain();sg.gain.value=0;ns.connect(bp);bp.connect(sg);sg.connect(master);ns.start();
  sq.sg=sg;sq.bp=bp;
  // suara angin (makin ngebut makin kencang)
  const wn=AC.createBufferSource();wn.buffer=nb;wn.loop=true;
  const wf=AC.createBiquadFilter();wf.type='bandpass';wf.frequency.value=500;wf.Q.value=.5;
  const wg=AC.createGain();wg.gain.value=0;wn.connect(wf);wf.connect(wg);wg.connect(master);wn.start();
  sq.wg=wg;sq.wf=wf;
}
function ensureAudio(){startAudio();if(AC.state==='suspended')AC.resume()}
// efek suara knalpot
function pop(e,amp,delay){ // letupan: desis noise + dentuman rendah
  const t=AC.currentTime+(delay||0);
  const s=AC.createBufferSource();s.buffer=nb;
  const f=AC.createBiquadFilter();f.type='bandpass';f.frequency.value=900+Math.random()*1300;f.Q.value=.9;
  const g=AC.createGain();g.gain.setValueAtTime(amp,t);g.gain.exponentialRampToValueAtTime(.001,t+.14+.1*amp);
  s.connect(f);f.connect(g);g.connect(e.bus);s.start(t,Math.random()*.5,.4);
  const o=AC.createOscillator(),og=AC.createGain();o.type='sine';
  o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(48,t+.1);
  og.gain.setValueAtTime(amp*.8,t);og.gain.exponentialRampToValueAtTime(.001,t+.13);
  o.connect(og);og.connect(e.bus);o.start(t);o.stop(t+.2);
}
function thump(e,amp){ // hentakan pindah gigi
  const t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();o.type='sine';
  o.frequency.setValueAtTime(95,t);o.frequency.exponentialRampToValueAtTime(40,t+.14);
  g.gain.setValueAtTime(amp,t);g.gain.exponentialRampToValueAtTime(.001,t+.16);
  o.connect(g);g.connect(e.bus);o.start(t);o.stop(t+.2);
}
function bov(e,amp){ // "pssh" turbo saat gas dilepas
  const t=AC.currentTime,s=AC.createBufferSource();s.buffer=nb;
  const f=AC.createBiquadFilter();f.type='bandpass';f.Q.value=1.8;
  f.frequency.setValueAtTime(5200,t);f.frequency.exponentialRampToValueAtTime(2200,t+.45);
  const g=AC.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(amp*.6,t+.03);g.gain.exponentialRampToValueAtTime(.001,t+.5);
  s.connect(f);f.connect(g);g.connect(e.bus);s.start(t,Math.random()*.5,.6);
}
function beep(freq,dur){
  if(!started)return;
  const o=AC.createOscillator(),g=AC.createGain(),t=AC.currentTime;
  o.type='square';o.frequency.value=freq;
  g.gain.setValueAtTime(.12,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);
  o.connect(g);g.connect(master);o.start(t);o.stop(t+dur);
}
function updEng(e,c,thr,vol,pan,dt){
  const sp=e.sp,t=AC.currentTime,rpm=c.rpm,rf=rpm/c.cfg.redline,f=rpm/20;   // 6 silinder = 3 letusan / putaran
  e.thrS+=(thr-e.thrS)*Math.min(1,dt*9);e.vol=vol;
  const tc=.035;
  e.o1.frequency.setTargetAtTime(f,t,tc);e.o2.frequency.setTargetAtTime(f,t,tc);
  e.o3.frequency.setTargetAtTime(f/2,t,tc);e.o4.frequency.setTargetAtTime(f*2,t,tc);
  e.o5.frequency.setTargetAtTime(1000+rpm*.5,t,.06);
  e.lfo.frequency.setTargetAtTime(5+rf*4,t,.2);
  e.lp.frequency.setTargetAtTime(sp.lpBase+rpm*sp.lpK+e.thrS*1500,t,.05);
  let a=.14+.34*e.thrS+.2*rf;
  if(c.shiftT>0)a*=.55;                                    // tenaga terputus sesaat saat pindah gigi
  if(thr&&rf>.985)a*=((t*18)%1<.5?1:.45);                  // limiter
  e.amp.gain.setTargetAtTime(a*sp.vol,t,.04);
  e.raspG.gain.setTargetAtTime(sp.rasp*.05*e.thrS*rf*rf,t,.05);
  e.nG.gain.setTargetAtTime(sp.noise*(.2+e.thrS*.8)*(.3+rf)*.35,t,.06);
  e.nbp.frequency.setTargetAtTime(900+rpm*.25,t,.1);
  e.tG.gain.setTargetAtTime(sp.turbo*e.thrS*Math.pow(rf,1.4),t,.08);
  e.lfoG.gain.setTargetAtTime(sp.lope*.05*Math.max(0,1-rf*1.6),t,.1);
  e.out.gain.setTargetAtTime(vol,t,.05);
  if(e.bus.pan)e.bus.pan.setTargetAtTime(pan,t,.05);
}
function updateAudio(dt){
  if(!started)return;
  const t=AC.currentTime;
  if(state==='menu'){
    if(eng1)eng1.out.gain.setTargetAtTime(0,t,.1);if(eng2)eng2.out.gain.setTargetAtTime(0,t,.1);
    sq.sg.gain.setTargetAtTime(0,t,.1);sq.wg.gain.setTargetAtTime(0,t,.1);return;
  }
  if(eng1)updEng(eng1,car,keys.up?1:0,1,0,dt);
  sq.sg.gain.setTargetAtTime(Math.min(.32,(car.slip+(keys.drift?150:0))*.0016),t,.05);
  sq.bp.frequency.setTargetAtTime(1500+car.slip*3,t,.1);
  const fr=Math.min(1,Math.abs(car.vf)*K/320);
  sq.wg.gain.setTargetAtTime(fr*fr*.12*(cam===2?1.3:1),t,.1);
  sq.wf.frequency.setTargetAtTime(350+fr*1500,t,.1);
  if(mode==='duel'&&eng2){
    const dxm=(bot.x-car.x)/10;                     // jarak bot (meter), + = di depan
    const vol=Math.max(.12,1-Math.abs(dxm)/70)*.85; // makin jauh makin pelan
    const pan=Math.max(-1,Math.min(1,dxm/35))*.85;  // depan = kanan, belakang = kiri
    updEng(eng2,bot,bot.thr,vol,pan,dt);
  }
}

// ---------- menu & alur ----------
const SCREENS=['menu','garage','duel','result'];
function show(name){
  for(const id of SCREENS)$(id).classList.toggle('hidden',id!==name);
  if(name==='menu'){state='menu';renderMenu()}
  if(name==='duel'){foeChosen=false;$('duelMain').classList.remove('hidden');$('duelPick').classList.add('hidden');renderDuel()}
  if(name==='garage'){$('gList').classList.add('hidden');$('gColor').classList.add('hidden');resetTest();renderGarage()}
}
function hideAll(){for(const id of SCREENS)$(id).classList.add('hidden')}
function renderMenu(){$('curSel').textContent='Mobilmu: '+MODELS[sel.me].name}
function renderDuel(){
  const a=MODELS[sel.me],b=MODELS[sel.foe];
  $('imgA').src=sideURL(sel.me,colors[sel.me],true);
  $('nameA').textContent=a.name;$('specA').innerHTML=a.cfg.spec;
  $('foePh').classList.toggle('hidden',foeChosen);$('foeBox').classList.toggle('hidden',!foeChosen);
  if(foeChosen){$('imgB').src=IMG[b.side];$('nameB').textContent=b.name;$('specB').innerHTML=b.cfg.spec}
  $('bGo').classList.toggle('off',!foeChosen);
  $('dist').textContent=fmtKm(DISTS[di]);
}
function renderFoePick(){
  const box=$('foeCards');box.innerHTML='';
  for(const k in MODELS){
    const m=MODELS[k],d=document.createElement('div');
    const own=owned.includes(k);
    d.className='card pick bot'+(foeChosen&&sel.foe===k?' sel':'')+(own?'':' lock');
    const im=document.createElement('img');im.src=IMG[m.side];im.alt='';
    const b=document.createElement('b');b.textContent=m.name;
    const sp=document.createElement('div');if(own)sp.innerHTML=m.cfg.spec;else sp.textContent='🔒 TERKUNCI · beli di Garage';
    d.append(im,b,sp);
    if(own)d.onclick=()=>{sel.foe=k;foeChosen=true;$('duelPick').classList.add('hidden');$('duelMain').classList.remove('hidden');renderDuel()};
    box.appendChild(d);
  }
}
let gMsgT=0;
function gMsg(t){$('gMsg').textContent=t;clearTimeout(gMsgT);gMsgT=setTimeout(()=>{$('gMsg').textContent=''},1800)}
const fmtMoney=n=>'$'+Math.round(n).toLocaleString('id-ID');
function buyCar(k){
  if(owned.includes(k))return;
  if(PRICE[k]==null)return;
  if(money<PRICE[k]){gMsg('Uang tidak cukup');return}
  money-=PRICE[k];owned.push(k);saveOwn();renderGarage();
}
function updBal(){
  for(const [id,v] of [['moneyV',money],['coinV',coin]]){
    const el=$(id),t=v.toLocaleString('id-ID');el.textContent=t;
    el.style.fontSize=t.length>=8?'19px':t.length>=6?'24px':'';   // angka besar tetap muat di kotak
  }
}
let cFor=null,testOn=false,lastPick='';   // testOn = ada warna picker yang belum diterapkan & sedang di-preview (gratis)
let prevC={k:null,hex:null};               // WARNA AKTIF dari picker (belum Apply): jadi preview Garage dan warna race saat START
let lastRace={k:null,hex:null};            // warna yang dipakai race terakhir (untuk MAIN LAGI)
const curColor=k=>colors[k]||DEF_COLOR[k];
const colorOpen=()=>!$('gColor').classList.contains('hidden');
const clearPrev=()=>{prevC={k:null,hex:null}};
function setPreview(k,h){   // jadikan nilai picker sebagai preview aktif (kosong kalau sama dengan warna tersimpan/asli)
  h=String(h||'').toLowerCase();
  prevC=(/^#[0-9a-f]{6}$/.test(h)&&h!==curColor(k).toLowerCase())?{k,hex:h}:{k:null,hex:null};
}
function previewHex(k){   // warna yang tampil di Garage & dipakai race: warna picker aktif, kalau tidak ada = warna tersimpan (null = sprite asli)
  return(prevC.k===k&&prevC.hex)?prevC.hex:(colors[k]||null);
}
function pullPicker(){   // baca nilai picker terbaru (jaga-jaga event Android telat/tidak terkirim)
  if(colorOpen()&&cFor===sel.me)setPreview(sel.me,$('cPick').value);
}
function syncColorUI(){
  const k=sel.me;
  if(cFor!==k){cFor=k;$('cPick').value=(prevC.k===k&&prevC.hex)?prevC.hex:curColor(k)}   // buka lagi -> lanjut dari warna preview terakhir
  const hex=$('cPick').value.toLowerCase();
  lastPick=hex;   // nilai picker yang sudah tercermin di UI/preview
  testOn=prevC.k===k&&!!prevC.hex;
  $('cName').textContent='WARNA '+MODELS[k].name;
  $('cHex').textContent=hex.toUpperCase();
  $('cApply').classList.toggle('off',hex===curColor(k).toLowerCase());
  $('cTest').classList.toggle('on',testOn);
  $('cTest').textContent=testOn?'MATIKAN TEST':'TEST COLOR';
  $('cNote').textContent=testOn?'Preview aktif (gratis, Coin aman) — START memakai warna ini':'';
}
function resetTest(){testOn=false;cFor=null;clearPrev()}   // buang preview, kembali ke warna tersimpan
function applyColor(){   // Coin hanya berkurang di sini
  const k=sel.me,hex=$('cPick').value.toLowerCase();
  if(!owned.includes(k)||!/^#[0-9a-f]{6}$/.test(hex))return;
  if(hex===curColor(k).toLowerCase()){gMsg('Pilih warna baru dulu');return}
  if(coin<COLOR_COST){gMsg('Coin tidak cukup (butuh '+COLOR_COST+' Coin)');return}
  coin-=COLOR_COST;colors[k]=hex;saveOwn();testOn=false;clearPrev();
  for(const o of [colCache,urlCache])for(const x in o)delete o[x];
  $('gColor').classList.add('hidden');cFor=null;renderGarage();gMsg('Warna diterapkan (-'+COLOR_COST+' Coin)');
}
function renderGarage(){
  updBal();
  syncColorUI();
  $('gCarImg').src=sideURL(sel.me,previewHex(sel.me),false);
  const box=$('gList');box.innerHTML='';
  for(const k in MODELS){
    const m=MODELS[k],own=owned.includes(k),d=document.createElement('div');
    d.className='gcard'+(own?'':' lock')+(sel.me===k?' sel':'');
    const im=document.createElement('img');im.src=own?sideURL(k,colors[k],true):IMG[m.side];im.alt='';
    const b=document.createElement('b');b.textContent=m.name;
    const st=document.createElement('div');st.textContent=own?(sel.me===k?'DIPAKAI':'PILIH'):'🔒 TERKUNCI';
    d.append(im,b,st);
    if(own)d.onclick=()=>{if(sel.me!==k)resetTest();sel.me=k;saveSel();renderGarage()};
    else{
      const bt=document.createElement('span');bt.className='buy';bt.textContent='BELI '+fmtMoney(PRICE[k]);
      bt.onclick=e=>{e.stopPropagation();buyCar(k)};
      d.appendChild(bt);
    }
    box.appendChild(d);
  }
}
function startGame(m,hex){   // hex (opsional) = warna preview picker utk race ini; undefined = warna tersimpan; null = sprite asli
  mode=m;ensureAudio();
  car=mkCar(sel.me,0,m==='duel'?420:360);
  if(hex===undefined)hex=colors[sel.me]||null;
  lastRace={k:sel.me,hex};
  car.spr=colorSprites(sel.me,hex);   // warna custom / preview mobil pemain (null = asli)
  bot=mkCar(sel.foe,0,340);
  bot.spr=sel.foe===sel.me?tintSprites(sel.foe,[1,.42,.1]):null;   // kalau mobilnya sama, bot diwarnai oranye
  puffs=[];wind=[];sideScroll=0;
  buildEngines(m==='duel');
  if(m==='duel'){
    race={dist:DISTS[di]*1000,t:0,cd:3,lastN:4,winner:null,sinceFin:0,top:0,botDelay:.2+Math.random()*.25};
    state='count';
  }else{race=null;state='solo'}
  hideAll();
}
$('bSolo').onclick=()=>{goFull();ensureAudio();startGame('solo')};
$('bDuel').onclick=()=>{goFull();ensureAudio();show('duel')};
$('bGarage').onclick=()=>{goFull();show('garage')};
$('gBack').onclick=()=>{resetTest();$('gColor').classList.add('hidden');show('menu')};
$('gCust').onclick=()=>{$('gColor').classList.toggle('hidden');cFor=null;renderGarage()};   // preview TIDAK dibuang; picker lanjut dari warna terakhir
// Pemilih warna Android ("Sesuaikan") kadang cuma mengirim event 'change' (atau tidak sama sekali),
// jadi dengarkan keduanya + cek berkala supaya warna bebas tetap ter-preview dan bisa diterapkan.
function onPick(){
  if(cFor!==sel.me){renderGarage();return}
  const v=$('cPick').value.toLowerCase();
  if(v===lastPick)return;   // belum ada perubahan dibanding yang sudah ditampilkan
  setPreview(sel.me,v);     // warna picker langsung jadi warna aktif (tanpa TEST/Apply)
  syncColorUI();            // memperbarui lastPick + HEX + tombol
  $('gCarImg').src=sideURL(sel.me,previewHex(sel.me),false);
}
$('cPick').addEventListener('input',onPick);
$('cPick').addEventListener('change',onPick);
setInterval(()=>{if(colorOpen())onPick()},120);
$('cTest').onclick=()=>{
  if(testOn){clearPrev();cFor=null;renderGarage();gMsg('Test dimatikan, kembali ke warna tersimpan');return}   // matikan: picker balik ke warna tersimpan
  pullPicker();renderGarage();
  gMsg(testOn?'Preview aktif (gratis, Coin aman)':'Pilih warna dulu di picker');
};
$('cApply').onclick=applyColor;
$('cCancel').onclick=()=>{$('gColor').classList.add('hidden');resetTest();renderGarage()};
$('gMy').onclick=()=>$('gList').classList.toggle('hidden');
$('gStart').onclick=()=>{
  pullPicker();                    // ambil nilai picker terakhir
  const hex=previewHex(sel.me);    // warna aktif DIAMBIL DULU sebelum state di-reset
  resetTest();$('gColor').classList.add('hidden');goFull();ensureAudio();startGame('solo',hex);
};
$('bPick').onclick=()=>{renderFoePick();$('duelMain').classList.add('hidden');$('duelPick').classList.remove('hidden')};
$('pBack').onclick=()=>{$('duelPick').classList.add('hidden');$('duelMain').classList.remove('hidden')};
$('dMinus').onclick=()=>{di=Math.max(0,di-1);saveSel();renderDuel()};
$('dPlus').onclick=()=>{di=Math.min(DISTS.length-1,di+1);saveSel();renderDuel()};
$('bGo').onclick=()=>{if(foeChosen)startGame('duel')};
$('bBack').onclick=()=>show('menu');
$('bAgain').onclick=()=>startGame(mode,lastRace.k===sel.me?lastRace.hex:undefined);
$('bMenu2').onclick=()=>show('menu');
$('menuBtn').addEventListener('pointerdown',e=>{e.preventDefault();show('menu')});
renderMenu();

function showResult(){
  state='result';
  const fp=race.dist*10,me=car.fin,bt=bot.fin,win=race.winner==='me';
  let gap,est=false;
  if(me!=null&&bt!=null)gap=Math.abs(bt-me);
  else{est=true;gap=win?(fp-bot.x)/Math.max(bot.vf,50):(fp-car.x)/Math.max(car.vf,50)}
  $('resTitle').textContent=win?'🏆 MENANG!':'KALAH…';
  $('resTitle').style.color=win?'#7dffb0':'#ff6b8a';
  const tm=t=>t!=null?t.toFixed(2)+' dtk':'belum finish';
  $('resBody').innerHTML=
    'Jarak: '+fmtKm(race.dist/1000)+'<br>'+
    'Waktumu ('+MODELS[car.m].short+'): <b style="color:#8fe3ff">'+tm(me)+'</b><br>'+
    'Bot ('+MODELS[bot.m].short+'): <b style="color:#ff7bd0">'+tm(bt)+'</b><br>'+
    'Selisih: '+(est?'±':'')+(win?'+':'−')+gap.toFixed(2)+' dtk<br>'+
    'Top speed kamu: '+Math.round(race.top)+' km/jam'+
    (win&&race.reward?'<br>Hadiah: <b style="color:#ffd86b">+'+fmtMoney(race.reward[0])+' · +'+race.reward[1]+' Coin</b>':'');
  $('result').classList.remove('hidden');
}

// ---------- fisika ----------
// Satu fungsi tenaga untuk pemain & bot: gigi, redline, jeda pindah gigi, batas traksi, hambatan angin.
function propel(c,thr,brk,dt,locked,drift){
  const g=c.cfg;let vf=c.vf;
  const v=Math.max(0,vf)/10,kmh=v*3.6;
  c.shiftT=Math.max(0,c.shiftT-dt);
  const rpmIn=k=>kmh/g.gears[k]*g.redline;
  if(!locked&&c.shiftT===0){
    if(thr&&c.gear<g.gears.length-1&&rpmIn(c.gear)>g.redline*.97){c.gear++;c.shiftT=g.shift;c.shifted=1}
    else if(c.gear>0&&rpmIn(c.gear)<g.redline*.4)c.gear--;
  }
  const drag=g.cd*v*v+g.rr;
  if(locked)vf=0;
  else if(thr){
    if(vf<-1)vf+=700*dt;
    else{const a=(c.shiftT>0?0:Math.min(g.aG,g.Pn/Math.max(v,1)))-drag;vf+=a*10*dt}
  }else if(brk){
    if(vf>1)vf-=140*dt;else vf-=30*dt;
  }else{
    if(vf>0)vf=Math.max(0,vf-(drag+2)*10*dt);else if(vf<0)vf=Math.min(0,vf+60*dt);
  }
  if(drift)vf*=Math.pow(.82,dt);
  vf=Math.max(-90,Math.min(g.vmax/K,vf));
  // rpm
  let tgt;
  if(locked)tgt=thr?g.redline*.6:g.idle;
  else{tgt=Math.max(g.idle,rpmIn(c.gear));if(thr&&kmh<25)tgt=Math.max(tgt,g.redline*.5)}
  if(c.shiftT>0)tgt*=.8;
  c.rpm+=(tgt-c.rpm)*Math.min(1,dt*(thr?10:6));
  c.rpm=Math.min(c.rpm,g.redline);
  return vf;
}
function stepPlayer(dt,locked){
  const c=car;
  const thr=keys.up?1:0,brk=keys.down?1:0,steerIn=(keys.right?1:0)-(keys.left?1:0),drift=keys.drift;
  c.thr=thr;
  const fx=Math.cos(c.h),fy=Math.sin(c.h),rx=-fy,ry=fx;
  c.vf=c.vx*fx+c.vy*fy;let vl=c.vx*rx+c.vy*ry;
  let vf=propel(c,thr,brk,dt,locked,drift);
  const VMAXPX=c.cfg.vmax/K;
  {
    const sp=Math.abs(vf);
    const steer=steerIn*(drift?2.5:1.7)*Math.min(1,sp/160)*(vf<0?-1:1)*(1-Math.min(.35,sp/VMAXPX*.35));
    c.h+=steer*dt;
    vl*=Math.pow(drift?.35:.0006,dt);
  }
  c.vx=fx*vf+rx*vl;c.vy=fy*vf+ry*vl;
  c.x+=c.vx*dt;c.y+=c.vy*dt;
  let hit=false;
  if(c.y<ROAD_T){c.y=ROAD_T;c.vy*=-.3;hit=true}
  if(c.y>ROAD_B){c.y=ROAD_B;c.vy*=-.3;hit=true}
  if(hit){c.h*=.98;const f=Math.pow(.45,dt);c.vx*=f;c.vy*=f} // gesek pagar = melambat
  c.slip=Math.abs(vl);
  const swayT=drift?Math.min(1,Math.abs(vf)/300)*(steerIn||1)*.10:0;
  c.sway+=(swayT-c.sway)*Math.min(1,dt*6);
  sideScroll+=c.vx*dt;
  c.vf=vf;
  c.wa=((c.wa||0)+vf*dt/c.cfg.wr)%(Math.PI*2);
  const smk=(drift&&Math.abs(vf)>120)||c.slip>140;
  if(smk&&Math.random()<.7&&puffs.length<420)emitTire(c,fx,fy,rx,ry);
}
function stepBot(dt){
  const b=bot;
  const go=state!=='count'&&race.t>=race.botDelay;
  b.thr=state==='count'?(race.cd<1.5?1:0):1;       // bot ngegas pas hitungan mundur
  b.vf=propel(b,b.thr,0,dt,!go,0);
  b.x+=b.vf*dt;
  b.wa=((b.wa||0)+b.vf*dt/b.cfg.wr)%(Math.PI*2);
  const laneT=340+Math.sin(performance.now()/1700)*10;
  const nvy=(laneT-b.y)*1.5;b.y+=nvy*dt;
  b.h=Math.atan2(nvy,Math.max(60,b.vf));
  b.vx=b.vf*Math.cos(b.h);b.vy=b.vf*Math.sin(b.h);
}

// ---------- asap & api knalpot ----------
let wind0=0;
function stepWind(dt){   // garis hembusan angin (kamera samping), makin ngebut makin banyak & panjang
  const sp=Math.abs(car.vx)*K,f=Math.min(1,sp/320);
  if(sp>60){
    const L=sideLay(car);let n=(15+f*85)*dt;
    for(;n>0;n--){
      if(Math.random()>=Math.min(1,n))continue;
      wind.push({x:Math.random()*(W+300)-150,y:Math.random()<.65?L.by-150+Math.random()*165:480+Math.random()*235,
        len:25+f*210*(.4+Math.random()*.6),m:.9+Math.random()*.7,u:0,life:.3+Math.random()*.35,a:.2+Math.random()*.4});
    }
  }
  for(const p of wind){p.x-=car.vx*SIDE_S*p.m*dt;p.u+=dt/p.life}
  wind=wind.filter(p=>p.u<1);
}
// titik keluar knalpot, dalam koordinat kamera yang aktif (kamera 1 = koordinat dunia, kamera 2 = koordinat layar)
function pipes(c){
  const m=MODELS[c.m];
  if(cam===1){
    if(Math.abs(c.x-car.x)>W)return[];
    const fx=Math.cos(c.h),fy=Math.sin(c.h),rx=-fy,ry=fx,half=m.topW*.5*.97;
    return m.pipeTop.map(l=>({x:c.x-fx*half+rx*l,y:c.y-fy*half+ry*l,dx:-fx,dy:-fy,world:1,sc:.7}));
  }
  const L=sideLay(c);
  if(L.cx<-300||L.cx>W+300)return[];
  const im=getSprite(c,'side'),s=L.w/im.width,h=L.w*im.height/im.width,[px,py]=m.pipeSide;
  return[{x:L.cx+L.face*(px*s-L.w/2),y:L.by-h+py*s,dx:-L.face,dy:0,world:0,sc:1}];
}
function emitTire(c,fx,fy,rx,ry){
  if(cam===1)puffs.push({x:c.x-fx*58+rx*(Math.random()-.5)*30,y:c.y-fy*58+ry*(Math.random()-.5)*30,vx:c.vx*.2,vy:c.vy*.2,r:6,g:22,a0:.55,col:'#d9ccff',life:.6,age:0,world:1});
  else{const L=sideLay(c);puffs.push({x:L.cx-L.face*L.w*.38+(Math.random()-.5)*20,y:L.by-8,vx:c.vx*.25,vy:-20-Math.random()*20,r:8,g:22,a0:.55,col:'#d9ccff',life:.6,age:0,world:0})}
}
function emitSmoke(c,dark){
  for(const P of pipes(c))puffs.push({x:P.x,y:P.y,vx:c.vx*.25+P.dx*(40+Math.random()*50)*P.sc,vy:P.dy*40-15-Math.random()*25,
    r:(2.5+Math.random()*2)*P.sc,g:(10+Math.random()*8)*P.sc,a0:dark?.5:.22,col:dark?'#3b3b48':'#cfd3ea',life:.7+Math.random()*.5,age:0,world:P.world});
}
function emitFlame(c,amp){
  for(const P of pipes(c)){
    const n=Math.round(6+amp*6);
    for(let k=0;k<n;k++){
      const sp=(380+Math.random()*420)*P.sc;
      puffs.push({x:P.x+P.dx*Math.random()*6,y:P.y+P.dy*Math.random()*6,vx:c.vx*.8+P.dx*sp,vy:P.dy*sp+(Math.random()-.5)*70*P.sc,
        r:(4.5+Math.random()*4)*P.sc*(.7+.6*amp),g:-10*P.sc,a0:.95,life:.12+Math.random()*.14*amp+.06,age:0,world:P.world,fire:1});
    }
  }
}
function backfire(c,amp,why){   // api + suara letupan, selalu berbarengan
  if(puffs.length<420)emitFlame(c,amp);
  const e=c.eng;if(!started||!e||e.vol<.06)return;
  const v=e.vol,m=MODELS[c.m];
  if(why==='shift'){thump(e,.3*v);pop(e,.2*v,0);if(m.spit>2)pop(e,.14*v,.07)}
  else if(why==='lift'){bov(e,.5*v);for(let i=0;i<m.spit;i++)pop(e,(.4-.08*i)*v,.05+i*(.06+Math.random()*.06))}
  else pop(e,.2*v,0);
}
function stepExhaust(c,thr,dt){
  const m=MODELS[c.m],rf=c.rpm/c.cfg.redline;
  if(c.shifted){c.shifted=0;backfire(c,.55,'shift')}
  if(c.lastThr&&!thr&&c.rpm>4300)backfire(c,1,'lift');
  if(!thr&&c.rpm>3300&&Math.random()<dt*m.burble)backfire(c,.35,'burble');
  c.lastThr=thr;
  let rate=0;
  const slow=Math.abs(c.vf)*K<60;
  if(thr)rate=7+30*rf+(slow?18:0);
  if(rate&&puffs.length<420&&Math.random()<rate*dt)emitSmoke(c,thr&&slow);
}
function stepPuffs(dt){
  for(const p of puffs){
    p.x+=(p.vx-(p.world?0:car.vx*SIDE_S))*dt;p.y+=p.vy*dt;p.r=Math.max(.5,p.r+p.g*dt);p.age+=dt;
  }
  puffs=puffs.filter(p=>p.age<p.life);
}

function checkFinish(c,who){
  const fp=race.dist*10;
  if(c.fin==null&&c.x>=fp){
    c.fin=race.t-(c.x-fp)/Math.max(c.vf,1);
    if(race.winner==null){race.winner=who;state='finish';race.sinceFin=0;beep(who==='me'?1200:300,.7);if(who==='me')giveReward()}
  }
}
function giveReward(){   // hanya saat pemain MENANG 1v1, dan hanya sekali per race
  if(!race||race.rewarded||race.winner!=='me'||mode!=='duel')return;
  race.rewarded=true;
  const r=(REWARD[bot.m]||{})[race.dist/1000];
  if(!r)return;
  money+=r[0];coin+=r[1];race.reward=r;saveOwn();updBal();
}
function step(dt){
  if(state==='menu')return;
  const locked=state==='count';
  if(state==='count'){
    race.cd-=dt;
    const n=Math.ceil(race.cd);
    if(n!==race.lastN&&n>=1){race.lastN=n;beep(520,.18)}
    if(race.cd<=0){state='race';race.t=0;beep(1040,.55)}
  }else if(race&&(state==='race'||state==='finish'||state==='result'))race.t+=dt;
  stepPlayer(dt,locked);
  stepExhaust(car,car.thr,dt);
  if(cam===2)stepWind(dt);else if(wind.length)wind=[];
  if(mode==='duel'){
    stepBot(dt);
    stepExhaust(bot,bot.thr,dt);
    race.top=Math.max(race.top,Math.abs(car.vf)*K);
    if(state==='race'||state==='finish'){checkFinish(car,'me');checkFinish(bot,'bot')}
    if(state==='finish'){race.sinceFin+=dt;if(race.sinceFin>2.5)showResult()}
  }
  stepPuffs(dt);
}

// ---------- gambar ----------
function drawTiledX(im,offset,sy=0,sh=H){
  let x=-((offset%IW)+IW)%IW;
  for(;x<W+1;x+=IW)ctx.drawImage(im,0,sy,IW,sh,x,sy,IW,sh);
}
function drawPuffs(shiftX){
  for(const p of puffs){
    if(p.fire)continue;
    ctx.globalAlpha=Math.max(0,p.a0*Math.pow(1-p.age/p.life,1.3));ctx.fillStyle=p.col;
    ctx.beginPath();ctx.arc(p.world?p.x-shiftX:p.x,p.y,p.r,0,7);ctx.fill();
  }
  ctx.globalCompositeOperation='lighter';             // api: warna ditambah (menyala)
  for(const p of puffs){
    if(!p.fire)continue;
    const u=p.age/p.life,a=Math.max(0,(1-u)*p.a0),x=p.world?p.x-shiftX:p.x;
    ctx.fillStyle=u<.3?'rgb(255,236,170)':u<.65?'rgb(255,150,50)':'rgb(220,60,25)';
    ctx.globalAlpha=a*.4;ctx.beginPath();ctx.arc(x,p.y,p.r*2.4,0,7);ctx.fill();
    ctx.globalAlpha=a;ctx.beginPath();ctx.arc(x,p.y,p.r,0,7);ctx.fill();
  }
  ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;
}
function checker(x,y0,y1,cols,sz){
  const rows=Math.ceil((y1-y0)/sz);
  for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
    ctx.fillStyle=(r+c)%2?'#fff':'#111';
    ctx.fillRect(x+c*sz,y0+r*sz,sz,Math.min(sz,y1-(y0+r*sz)));
  }
}
function drawTopCar(c,sx){
  const im=getSprite(c,'top'),w=MODELS[c.m].topW,h=w*im.height/im.width;
  ctx.save();ctx.translate(sx,c.y);ctx.rotate(c.h);
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(-w/2+6,-h/2+8,w,h);
  ctx.drawImage(im,-w/2,-h/2,w,h);ctx.restore();
}
function drawTop(){
  drawTiledX(img.bgTop,car.x-CX);
  const duel=mode==='duel'&&race;
  if(duel){
    const s0=CX-car.x;                       // garis start
    if(s0>-20&&s0<W+20){ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillRect(s0-3,238,6,278)}
    const sf=CX+(race.dist*10-car.x);        // garis finish
    if(sf>-60&&sf<W+60)checker(sf-20,238,516,2,20);
  }
  if(duel){
    const sx=CX+(bot.x-car.x);
    if(sx>-120&&sx<W+120)drawTopCar(bot,sx);
  }
  drawTopCar(car,CX);
  drawPuffs(car.x-CX);
}
function drawWheel(wx,wy,r,ang,cal,omega){
  ctx.save();ctx.translate(wx,wy);
  ctx.fillStyle='#121218';ctx.beginPath();ctx.arc(0,0,r+.6,0,7);ctx.fill();   // tutup pelek lama
  ctx.fillStyle=cal;ctx.beginPath();ctx.arc(0,0,r*.84,-.75,.95);ctx.arc(0,0,r*.46,.95,-.75,true);ctx.fill(); // kaliper (diam)
  const a=Math.max(.3,Math.min(1,1.3-omega/35));                 // makin ngebut makin blur
  ctx.rotate(ang);ctx.globalAlpha=a;
  ctx.strokeStyle='#454551';ctx.lineWidth=r*.085;ctx.lineCap='round';
  for(let i=0;i<5;i++){
    const b=i*Math.PI*2/5;
    for(const d of [-.15,.15]){const q=b+d;ctx.beginPath();ctx.moveTo(Math.cos(q)*r*.2,Math.sin(q)*r*.2);ctx.lineTo(Math.cos(q)*r*.93,Math.sin(q)*r*.93);ctx.stroke()}
  }
  ctx.globalAlpha=1;
  if(a<1){ctx.fillStyle='rgba(30,30,40,'+((1-a)*.55)+')';ctx.beginPath();ctx.arc(0,0,r*.95,0,7);ctx.fill()}
  ctx.strokeStyle='#2d2d38';ctx.lineWidth=r*.07;ctx.beginPath();ctx.arc(0,0,r*.97,0,7);ctx.stroke();  // bibir pelek
  ctx.fillStyle='#22222a';ctx.beginPath();ctx.arc(0,0,r*.18,0,7);ctx.fill();                          // hub
  ctx.restore();
}
function sideLay(c){ // posisi di kamera samping dihitung dari posisi dunia: jalur (y) = kedalaman, arah hadap = flip
  const t=Math.max(0,Math.min(1,(c.y-ROAD_T)/(ROAD_B-ROAD_T)));
  const bob=Math.sin(performance.now()/55+(c===car?0:2))*Math.min(1,Math.abs(c.vf)*K/320)*1.3;
  return{cx:CX+(c.x-car.x)*SIDE_S,by:630+70*t+bob,w:MODELS[c.m].sideW*(.9+.2*t),face:Math.cos(c.h)<0?-1:1};
}
function drawSideCar(c,L,rot){
  const m=MODELS[c.m],im=getSprite(c,'side'),w=L.w,h=w*im.height/im.width,s=w/im.width;
  ctx.fillStyle='rgba(0,0,0,.4)';ctx.beginPath();ctx.ellipse(L.cx,L.by+4,w*.46,10*w/470,0,0,7);ctx.fill();
  ctx.save();ctx.translate(L.cx,L.by);ctx.scale(L.face,1);ctx.translate(-w*.3,0);ctx.rotate(rot);ctx.translate(-w*.2,-h);ctx.scale(s,s);
  ctx.drawImage(im,0,0);
  const omega=Math.abs(c.vf)/c.cfg.wr;
  for(const [px,py] of m.wheels.p)drawWheel(px,py,m.wheels.r,c.wa||0,m.wheels.cal,omega);
  ctx.restore();
}
function drawWind(){
  if(!wind.length)return;
  const dir=Math.sign(car.vx)||1;
  ctx.save();ctx.lineWidth=2.5;ctx.lineCap='round';
  for(const p of wind){
    ctx.strokeStyle='rgba(215,230,255,'+(p.a*Math.sin(Math.PI*p.u)).toFixed(3)+')';
    ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+dir*p.len,p.y);ctx.stroke();
  }
  ctx.restore();
}
function drawSide(){
  drawTiledX(img.bgSide,sideScroll*.15,0,500);          // kota di kejauhan (pelan)
  drawTiledX(img.bgSide,sideScroll,500,H-500);          // pagar & jalan = kecepatan asli mobil
  const duel=mode==='duel'&&race;
  if(duel){
    const sf=CX+(race.dist*10-car.x)*SIDE_S;
    if(sf>-200&&sf<W+200){
      checker(sf-18,578,716,2,18);
      ctx.fillStyle='#1a0b3a';ctx.fillRect(sf-3,400,6,170);
      ctx.fillStyle='rgba(20,8,60,.92)';ctx.fillRect(sf-95,396,190,50);
      ctx.strokeStyle='#ff5fa8';ctx.lineWidth=3;ctx.strokeRect(sf-95,396,190,50);
      ctx.fillStyle='#ff9fd0';ctx.font='bold 30px "Courier New",monospace';ctx.textAlign='center';ctx.textBaseline='middle';
      ctx.fillText('FINISH',sf,422);ctx.textAlign='left';
    }
  }
  const list=[[car,sideLay(car),-car.sway+(keys.up?-.012:0)]];
  if(duel){const L=sideLay(bot);if(L.cx>-300&&L.cx<W+300)list.push([bot,L,-.012])}
  list.sort((a,b)=>a[1].by-b[1].by);                    // yang jauh digambar dulu
  for(const [c,L,rot] of list)drawSideCar(c,L,rot);
  drawPuffs(0);
  drawWind();
}
function pill(txt,x,y,align,col){
  ctx.font='bold 20px "Courier New",monospace';
  const w=ctx.measureText(txt).width+24;
  const px=align==='right'?x-w:x;
  ctx.fillStyle='rgba(10,5,40,.8)';ctx.strokeStyle=col;ctx.lineWidth=2;
  ctx.beginPath();ctx.roundRect(px,y-18,w,36,10);ctx.fill();ctx.stroke();
  ctx.fillStyle=col;ctx.textAlign='left';ctx.textBaseline='middle';ctx.fillText(txt,px+12,y+1);
}
function bigText(txt,col,size){
  ctx.save();ctx.textAlign='center';ctx.textBaseline='middle';
  ctx.font='bold '+size+'px "Courier New",monospace';
  ctx.shadowColor=col;ctx.shadowBlur=30;ctx.fillStyle=col;ctx.fillText(txt,W/2,250);ctx.restore();
}
function drawHUD(){
  if(state==='menu')return;
  const kmh=Math.round(Math.abs(car.vf)*K);
  ctx.save();ctx.textBaseline='top';ctx.textAlign='left';
  ctx.shadowColor='#3aa8ff';ctx.shadowBlur=10;ctx.fillStyle='#8fe3ff';
  ctx.font='bold 48px "Courier New",monospace';ctx.fillText(kmh,20,12);
  const tw=ctx.measureText(kmh).width;
  ctx.font='bold 20px "Courier New",monospace';ctx.fillText('km/jam',28+tw,38);
  ctx.font='bold 24px "Courier New",monospace';ctx.fillText(car.vf<-5?'R':'G'+(car.gear+1),20,68);
  ctx.shadowBlur=0;
  const rp=car.rpm/car.cfg.redline;
  ctx.fillStyle='rgba(10,5,40,.7)';ctx.fillRect(20,100,200,10);
  ctx.fillStyle=rp>.92?'#ff4f6a':'#5ac8ff';ctx.fillRect(20,100,200*rp,10);
  ctx.restore();
  if(mode!=='duel'||!race)return;

  // panel progres duel
  const fp=race.dist*10,bx=CX-230,bw=460,by=44;
  const pc=Math.max(0,Math.min(1,car.x/fp)),pb=Math.max(0,Math.min(1,bot.x/fp));
  ctx.save();
  ctx.fillStyle='rgba(10,5,40,.7)';ctx.beginPath();ctx.roundRect(bx-70,10,bw+140,92,14);ctx.fill();
  ctx.strokeStyle='#5a3aa8';ctx.lineWidth=2;ctx.stroke();
  ctx.fillStyle='#3a2a7a';ctx.fillRect(bx,by-3,bw,6);
  checker(bx+bw-8,by-12,by+12,1,8);
  ctx.fillStyle='#fff';ctx.fillRect(bx-2,by-10,3,20);
  ctx.fillStyle='#ff7bd0';ctx.beginPath();ctx.arc(bx+bw*pb,by,9,0,7);ctx.fill();
  ctx.fillStyle='#5ac8ff';ctx.beginPath();ctx.arc(bx+bw*pc,by,9,0,7);ctx.fill();
  ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(bx+bw*pc,by,9,0,7);ctx.stroke();
  ctx.font='bold 17px "Courier New",monospace';ctx.textBaseline='middle';
  const gap=(car.x-bot.x)/10;
  ctx.textAlign='left';ctx.fillStyle='#5ac8ff';ctx.fillText('KAMU '+Math.max(0,(fp-car.x)/10000).toFixed(2)+' km',bx-58,80);
  ctx.textAlign='right';ctx.fillStyle='#ff7bd0';ctx.fillText('BOT '+Math.max(0,(fp-bot.x)/10000).toFixed(2)+' km',bx+bw+58,80);
  ctx.textAlign='center';ctx.fillStyle=gap>=0?'#7dffb0':'#ff6b8a';
  ctx.fillText((gap>=0?'P1 +':'P2 −')+Math.abs(gap).toFixed(0)+' m   '+Math.max(0,race.t).toFixed(1)+' dtk',bx+bw/2,80);
  ctx.restore();

  // penunjuk bot di luar layar
  const sc=cam===1?1:SIDE_S,sx=CX+(bot.x-car.x)*sc;
  const half=cam===1?CX+95:CX+250;
  if(Math.abs(sx-CX)>half){
    const m=Math.abs(gap).toFixed(0)+' m',yy=cam===1?Math.max(130,Math.min(660,bot.y)):470;
    if(sx>CX)pill('BOT '+m+' ▶',W-14,yy,'right','#ff7bd0');
    else pill('◀ BOT '+m,14,yy,'left','#ff7bd0');
  }
  // hitung mundur & banner
  if(state==='count')bigText(String(Math.max(1,Math.ceil(race.cd))),'#ffd86b',170);
  else if(state==='race'&&race.t<.9)bigText('GO!','#7dffb0',170);
  else if(state==='finish')bigText(race.winner==='me'?'FINISH! MENANG!':'FINISH! BOT DULUAN','#ff7bd0',72);
}

let last=performance.now();
function loop(now){
  const dt=Math.min(.05,(now-last)/1000);last=now;
  step(dt);
  ctx.clearRect(0,0,W,H);
  cam===1?drawTop():drawSide();
  drawHUD();
  updateAudio(dt);
  requestAnimationFrame(loop);
}
