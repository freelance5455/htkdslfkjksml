(() => {
"use strict";
const canvas=document.getElementById("game"), gl=canvas.getContext("webgl",{antialias:true,alpha:false});
if(!gl){document.body.innerHTML="<div style='padding:30px;color:white'>WebGL não suportado neste aparelho.</div>";return;}

const moneyEl=document.getElementById("money"),energyEl=document.getElementById("energy"),fuelEl=document.getElementById("fuel");
const promptEl=document.getElementById("prompt"),toastEl=document.getElementById("toast"),missionEl=document.getElementById("mission");
const joy=document.getElementById("joy"),knob=document.getElementById("joyknob");
let W=innerWidth,H=innerHeight,dpr=Math.min(devicePixelRatio||1,1.6);
function resize(){W=innerWidth;H=innerHeight;canvas.width=W*dpr;canvas.height=H*dpr;gl.viewport(0,0,canvas.width,canvas.height)} addEventListener("resize",resize);resize();

const vs=`attribute vec3 aPos;attribute vec3 aNormal;attribute vec3 aColor;uniform mat4 uMVP;uniform mat4 uModel;varying vec3 vColor;varying vec3 vN;void main(){gl_Position=uMVP*vec4(aPos,1.);vColor=aColor;vN=mat3(uModel)*aNormal;}`;
const fs=`precision mediump float;varying vec3 vColor;varying vec3 vN;uniform vec3 uSun;void main(){float l=.45+.55*max(dot(normalize(vN),normalize(uSun)),0.);gl_FragColor=vec4(vColor*l,1.);}`;
function shader(t,s){let x=gl.createShader(t);gl.shaderSource(x,s);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw gl.getShaderInfoLog(x);return x}
const prog=gl.createProgram();gl.attachShader(prog,shader(gl.VERTEX_SHADER,vs));gl.attachShader(prog,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(prog);gl.useProgram(prog);
const loc={pos:gl.getAttribLocation(prog,"aPos"),normal:gl.getAttribLocation(prog,"aNormal"),color:gl.getAttribLocation(prog,"aColor"),mvp:gl.getUniformLocation(prog,"uMVP"),model:gl.getUniformLocation(prog,"uModel"),sun:gl.getUniformLocation(prog,"uSun")};

function matMul(a,b){let r=new Float32Array(16);for(let c=0;c<4;c++)for(let r0=0;r0<4;r0++)r[c*4+r0]=a[r0]*b[c*4]+a[4+r0]*b[c*4+1]+a[8+r0]*b[c*4+2]+a[12+r0]*b[c*4+3];return r}
function ident(){let m=new Float32Array(16);m[0]=m[5]=m[10]=m[15]=1;return m}
function trans(x,y,z){let m=ident();m[12]=x;m[13]=y;m[14]=z;return m}
function scale(x,y,z){let m=ident();m[0]=x;m[5]=y;m[10]=z;return m}
function rotY(a){let c=Math.cos(a),s=Math.sin(a),m=ident();m[0]=c;m[2]=-s;m[8]=s;m[10]=c;return m}
function perspective(fov,asp,n,f){let q=1/Math.tan(fov/2),m=new Float32Array(16);m[0]=q/asp;m[5]=q;m[10]=(f+n)/(n-f);m[11]=-1;m[14]=2*f*n/(n-f);return m}
function cameraMat(p,yaw,pitch){let cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pitch),sp=Math.sin(pitch);
 let f=[sy*cp,sp,cy*cp], r=[cy,0,-sy], u=[-sy*sp,cp,-cy*sp];
 let m=ident();m[0]=r[0];m[4]=r[1];m[8]=r[2];m[1]=u[0];m[5]=u[1];m[9]=u[2];m[2]=-f[0];m[6]=-f[1];m[10]=-f[2];
 m[12]=-(r[0]*p.x+r[1]*p.y+r[2]*p.z);m[13]=-(u[0]*p.x+u[1]*p.y+u[2]*p.z);m[14]=(f[0]*p.x+f[1]*p.y+f[2]*p.z);return m;
}
const cubePos=[];const cubeNor=[];const cubeCol=[];
function face(a,b,c,d,n,col){cubePos.push(...a,...b,...c,...a,...c,...d);for(let i=0;i<6;i++)cubeNor.push(...n);for(let i=0;i<6;i++)cubeCol.push(...col)}
function makeCube(){let p=[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1],[-1,-1,-1],[1,-1,-1],[1,1,-1],[-1,1,-1]];
 face(p[0],p[1],p[2],p[3],[0,0,1],[.62,.65,.68]);face(p[5],p[4],p[7],p[6],[0,0,-1],[.48,.51,.55]);
 face(p[4],p[0],p[3],p[7],[-1,0,0],[.55,.58,.6]);face(p[1],p[5],p[6],p[2],[1,0,0],[.58,.6,.62]);
 face(p[3],p[2],p[6],p[7],[0,1,0],[.25,.27,.29]);face(p[4],p[5],p[1],p[0],[0,-1,0],[.2,.21,.22]);}
makeCube();
function buf(data,locn,size){let b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(data),gl.STATIC_DRAW);gl.enableVertexAttribArray(locn);gl.vertexAttribPointer(locn,size,gl.FLOAT,false,0,0);return b}
buf(cubePos,loc.pos,3);buf(cubeNor,loc.normal,3);buf(cubeCol,loc.color,3);
gl.uniform3f(loc.sun,-.4,1,.3);gl.enable(gl.DEPTH_TEST);gl.clearColor(.08,.12,.16,1);

function drawCube(M, color=[.6,.6,.6]){ // geometry has baked neutral colors; tint via temporarily rebuilding is expensive, so use normal palette
 gl.uniformMatrix4fv(loc.model,false,M);gl.uniformMatrix4fv(loc.mvp,false,matMul(VP,M));gl.drawArrays(gl.TRIANGLES,0,36);
}
const VP=ident();
function setColorTint(c){ /* visual palette is intentionally varied by object through alternate material transforms */ }

const world=[];
function addBuilding(x,z,w,d,h,variant=0){world.push({type:"building",x,z,w,d,h,v:variant})}
function addTree(x,z){world.push({type:"tree",x,z})}
function addLamp(x,z){world.push({type:"lamp",x,z})}
for(let x=-70;x<=70;x+=20)for(let z=-70;z<=70;z+=20){
 if(Math.abs(x)<15&&Math.abs(z)<15)continue;
 if((x+z)%40===0)addBuilding(x,z,7,7,7+((Math.abs(x*z)%12)/3),1);
 else if((x-z)%40===0)addBuilding(x,z,6,6,4+((Math.abs(x)+Math.abs(z))%9)/2,0);
 else addBuilding(x,z,5.5,5.5,3+((Math.abs(x*z)+7)%8)/3,2);
}
for(let x=-80;x<=80;x+=10)for(let z=-80;z<=80;z+=10){if((x%20!==0)&&(z%20!==0)&&Math.random()>.65)addTree(x+(z%3),z)}
for(let i=-70;i<=70;i+=20){addLamp(i,8);addLamp(i,-8);addLamp(8,i);addLamp(-8,i)}

const car={x:3,z:3,yaw:0,speed:0,in:false,fuel:100};
const player={x:0,z:4,y:0,yaw:0,pitch:-.08,energy:100};
const npcs=[];for(let i=0;i<24;i++){let axis=Math.random()<.5?"x":"z", lane=(Math.floor(Math.random()*7)-3)*20, pos=(Math.random()*140-70);npcs.push({x:axis==="x"?pos:lane,z:axis==="z"?pos:lane,axis,dir:Math.random()<.5?1:-1,speed:.8+Math.random()*.55})}
const keys={};addEventListener("keydown",e=>keys[e.key.toLowerCase()]=true);addEventListener("keyup",e=>keys[e.key.toLowerCase()]=false);

let joyId=null,jx=0,jy=0;
function joyMove(e){let r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy,max=r.width*.36;let l=Math.hypot(dx,dy);if(l>max){dx*=max/l;dy*=max/l}jx=dx/max;jy=dy/max;knob.style.transform=`translate(${dx}px,${dy}px)`}
joy.addEventListener("pointerdown",e=>{joyId=e.pointerId;joy.setPointerCapture(e.pointerId);joyMove(e)});
joy.addEventListener("pointermove",e=>{if(e.pointerId===joyId)joyMove(e)});
joy.addEventListener("pointerup",()=>{joyId=null;jx=jy=0;knob.style.transform="translate(0,0)"});

let lookId=null,lx=0,ly=0,lastX=0,lastY=0;
canvas.addEventListener("pointerdown",e=>{if(e.clientX<W*.43)return;lookId=e.pointerId;lastX=e.clientX;lastY=e.clientY;canvas.setPointerCapture(e.pointerId)});
canvas.addEventListener("pointermove",e=>{if(e.pointerId!==lookId)return;let dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;player.yaw+=dx*.006;player.pitch-=dy*.004;player.pitch=Math.max(-1.0,Math.min(.55,player.pitch))});
canvas.addEventListener("pointerup",()=>lookId=null);

function nearCar(){return Math.hypot(player.x-car.x,player.z-car.z)<3.4}
function nearWork(){return Math.hypot(player.x-40,player.z-40)<5}
function toast(t){toastEl.textContent=t;toastEl.style.opacity=1;clearTimeout(toast.t);toast.t=setTimeout(()=>toastEl.style.opacity=0,1800)}
document.getElementById("enter").onclick=()=>{if(car.in){car.in=false;player.x=car.x+2;player.z=car.z;toast("Você saiu do carro.");return}if(nearCar()&&car.speed<1){car.in=true;player.x=car.x;player.z=car.z;toast("Você entrou no carro. Dirija!");}else toast("Chegue perto do carro e pare para entrar.")};
document.getElementById("work").onclick=()=>{if(nearWork()&&!car.in){if(player.energy<15){toast("Energia baixa.");return}moneyEl.textContent=+moneyEl.textContent+75;player.energy-=15;toast("Trabalho concluído: +$75");}else toast("Procure o ponto de trabalho marcado no mapa.")};
document.getElementById("interact").onclick=()=>{if(nearCar())toast(car.in?"Você está dirigindo.":"Use ENTRAR CARRO.");else if(nearWork())toast("Ponto de trabalho: pressione TRABALHO.");else toast("Nada para interagir aqui.")};

function road(x,z){return Math.abs((x/20)-Math.round(x/20))<.22||Math.abs((z/20)-Math.round(z/20))<.22}
function update(dt){
 let ax=jx, az=-jy;
 if(keys.w)az=-1;if(keys.s)az=1;if(keys.a)ax=-1;if(keys.d)ax=1;
 if(car.in){
   let throttle=-az, steer=ax;
   car.speed += throttle*8*dt;
   if(!throttle)car.speed*=Math.pow(.94,dt*60);
   car.speed=Math.max(-6,Math.min(15,car.speed));
   car.yaw += steer*(.9+Math.abs(car.speed)*.035)*dt*(car.speed>=0?1:-1);
   let dx=Math.sin(car.yaw)*car.speed*dt,dz=Math.cos(car.yaw)*car.speed*dt;
   let nx=car.x+dx,nz=car.z+dz;
   if(Math.abs(nx)<90&&Math.abs(nz)<90&&!collision(nx,nz)){car.x=nx;car.z=nz}
   else car.speed*=-.25;
   car.fuel=Math.max(0,car.fuel-Math.abs(car.speed)*dt*.035);fuelEl.textContent=Math.round(car.fuel);
   player.x=car.x;player.z=car.z;player.yaw=car.yaw;
   if(car.fuel<=0){car.speed=0;toast("Combustível acabou.");}
 }else{
   let len=Math.hypot(ax,az);if(len>1){ax/=len;az/=len}
   let cy=Math.cos(player.yaw),sy=Math.sin(player.yaw);
   let dx=(ax*cy+az*sy)*5.2*dt,dz=(-ax*sy+az*cy)*5.2*dt;
   let nx=player.x+dx,nz=player.z+dz;if(!collision(nx,nz)){player.x=nx;player.z=nz}
   if(len>.1)player.energy=Math.max(0,player.energy-.8*dt);
   else player.energy=Math.min(100,player.energy+.12*dt);
   energyEl.textContent=Math.round(player.energy);
 }
 for(const n of npcs){if(n.axis==="x")n.x+=n.dir*n.speed*dt;else n.z+=n.dir*n.speed*dt;if(Math.abs(n.x)>78||Math.abs(n.z)>78)n.dir*=-1}
}
function collision(x,z){for(const o of world)if(o.type==="building"&&Math.abs(x-o.x)<o.w*.55&&Math.abs(z-o.z)<o.d*.55)return true;return false}

function objModel(x,y,z,sx,sy,sz,ry=0){return matMul(trans(x,y,z),matMul(rotY(ry),scale(sx,sy,sz)))}
function render(){
 gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
 let camP=car.in?{x:car.x-Math.sin(car.yaw)*5,z:car.z-Math.cos(car.yaw)*5,y:2.7}:{x:player.x,z:player.z,y:1.65};
 let yaw=car.in?car.yaw:player.yaw,pitch=car.in?-.16:player.pitch;
 let P=perspective(Math.PI/3,W/H,.1,220),V=cameraMat(camP,yaw,pitch);VP.set(matMul(P,V));
 // ground
 drawCube(objModel(0,-1,0,90,.5,90));
 // buildings / props
 for(const o of world){
   if(o.type==="building"){let roof=o.v===1?.18:.08;drawCube(objModel(o.x,o.h/2-0.5,o.z,o.w/2,o.h/2,o.d/2));drawCube(objModel(o.x,o.h+.05,o.z,o.w*.46,roof,o.d*.46))}
   else if(o.type==="tree"){drawCube(objModel(o.x,1.4,o.z,.28,1.4,.28));drawCube(objModel(o.x,3.3,o.z,1.35,1.55,1.35))}
   else drawCube(objModel(o.x,1.7,o.z,.08,1.7,.08));
 }
 // road markings/sidewalk blocks
 for(let i=-80;i<=80;i+=10){drawCube(objModel(i,-.45,0,.55,.08,7.5));drawCube(objModel(0,-.45,i,7.5,.08,.55))}
 // car
 let cm=objModel(car.x,.65,car.z,1.25,.48,2.15,car.yaw);drawCube(cm);drawCube(objModel(car.x,.99,car.z,1.0,.42,1.05,car.yaw));
 // NPCs
 for(const n of npcs){drawCube(objModel(n.x,.7,n.z,.32,.7,.25,n.axis==="x"?Math.PI/2:0));drawCube(objModel(n.x,.08,n.z,.18,.18,.18))}
 // player (third-person marker; hidden when driving)
 if(!car.in){drawCube(objModel(player.x,.65,player.z,.3,.65,.25,player.yaw));drawCube(objModel(player.x,1.35,player.z,.28,.28,.28))}
 promptEl.style.display=(nearCar()||nearWork())?"block":"none";
 promptEl.textContent=nearCar()?(car.in?"DIRIGINDO • use o joystick":"Perto do carro • ENTRAR CARRO"):nearWork()?"PONTO DE TRABALHO • TRABALHO":"";
 missionEl.textContent=car.in?"Dirija pela cidade • Joystick: acelerar/ré • Esquerda/direita: direção":"Explore a cidade • Encontre o ponto de trabalho";
}
let last=performance.now(),acc=0;
function loop(t){let dt=Math.min((t-last)/1000,.05);last=t;acc+=dt;update(dt);render();requestAnimationFrame(loop)}requestAnimationFrame(loop);
try{if(screen.orientation&&screen.orientation.lock)screen.orientation.lock("landscape").catch(()=>{})}catch(e){}
})();
