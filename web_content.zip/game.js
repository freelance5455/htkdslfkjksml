const worlds=[
 {name:"تحدي الذكاء",icon:"🧠",desc:"ألغاز ومنطق"},
 {name:"المحقق العبقري",icon:"🔍",desc:"قضايا وأدلة"},
 {name:"غرف الهروب",icon:"🔐",desc:"أقفال وأسرار"},
 {name:"اختبار العبقرية",icon:"⚡",desc:"سرعة وملاحظة"},
 {name:"المغامرة",icon:"🗺️",desc:"قرارات وتحديات"}
];
const riddles=[
 ["شيء كلما أخذت منه كبر، ما هو؟","الحفرة",["الظل","الحفرة","البئر","الجبل"],"فكر في شيء يتسع عندما تزيل منه."],
 ["له أسنان ولا يعض، ما هو؟","المشط",["المشط","المنشار","التمساح","المفتاح"],"تستخدمه لترتيب شعرك."],
 ["يمشي بلا قدمين ويبكي بلا عينين، ما هو؟","السحاب",["النهر","السحاب","الريح","الساعة"],"تراه في السماء وقد ينزل منه المطر."],
 ["ما الشيء الذي يسمع بلا أذن ويتكلم بلا لسان؟","الهاتف",["الراديو","الهاتف","الكتاب","المرآة"],"تحمله وتتحدث من خلاله."],
 ["بيت بلا أبواب ولا نوافذ، ما هو؟","البيضة",["الخيمة","البيضة","الصندوق","الكهف"],"قد تجد داخله كائناً صغيراً."]
];
const detective=[
 ["اختفت الكعكة من المطبخ. قال سامي: كنت في الحديقة. وقالت ليلى: رأيت سامي يدخل المطبخ. وقال الحارس: باب الحديقة كان مقفلاً. ما أقوى دليل؟","شهادة ليلى",["لون ملابس سامي","شهادة ليلى","حجم الكعكة","وقت الغروب"],"ابحث عن المعلومة التي تربط شخصاً بمكان الحادث."],
 ["تعطلت ساعة المتحف عند 8:10. قال الحارس إنه سمع الجرس عند 9:00، لكن الجرس موصول بالساعة المتعطلة. ما الاستنتاج؟","رواية الحارس غير متسقة",["المتحف مغلق","رواية الحارس غير متسقة","الساعة تعمل جيداً","لا توجد مشكلة"],"قارن بين أقوال الشهود والمعلومة المؤكدة."]
];
const escapes=[
 ["على باب غرفة رمز من رقمين. تلميح: مجموع الرقمين 9 والرقم الأول أكبر من الثاني بثلاثة. ما الرمز؟","63",["63","54","72","45"],"ابحث عن رقمين يحققان الشرطين معاً."],
 ["ثلاثة مفاتيح: الأحمر، الأزرق، الأخضر. المفتاح الصحيح ليس الأحمر ولا الأخضر. أي مفتاح تختار؟","الأزرق",["الأحمر","الأزرق","الأخضر","لا شيء"],"استبعد الخيارين المذكورين."],
 ["لغز القفل: 2، 4، 8، 16، ؟","32",["24","30","32","36"],"كل عدد يساوي ضعف السابق."]
];
const quizzes=[
 ["كم شهراً في السنة يحتوي على 28 يوماً؟","12",["1","2","6","12"],"كل أشهر السنة تحتوي على اليوم 28."],
 ["إذا تجاوزت صاحب المركز الثاني في سباق، فما مركزك؟","الثاني",["الأول","الثاني","الثالث","الرابع"],"أنت تأخذ مكان الشخص الذي تجاوزته."],
 ["أيها أثقل: كيلوغرام حديد أم كيلوغرام قطن؟","متساويان",["الحديد","القطن","متساويان","حسب الحجم"],"ركز على وحدة الوزن لا الحجم."],
 ["ما العدد التالي: 1، 1، 2، 3، 5، 8، ؟","13",["10","11","12","13"],"اجمع العددين السابقين."]
];
const adventures=[
 ["أنت أمام نهر وجسر قديم وقارب صغير. اللافتة تقول إن الجسر لا يتحمل إلا شخصاً واحداً في كل مرة. ما أول خطوة آمنة؟","افحص الجسر قبل العبور",["اركض بسرعة","افحص الجسر قبل العبور","اقفز في النهر","تدفع القارب"],"اجمع المعلومات قبل اتخاذ قرار."],
 ["وجدت خريطة عليها ثلاثة مسارات: قصير مجهول، طويل واضح، ومتوسط عليه علامات تحذير. ما القرار الأذكى؟","اختر الطويل الواضح",["القصير المجهول","الطويل الواضح","المتوسط المحذر","أغمض عينيك واختر"],"في المغامرات، السلامة والمعلومات أولاً."]
];
function makeStage(i){
 let w=Math.floor((i-1)/100), local=(i-1)%100+1, bank=[riddles,detective,escapes,quizzes,adventures][w];
 let item=bank[(local-1)%bank.length], q=item[0], ans=item[1], opts=[...item[2]], clue=item[3];
 // Increase variety and difficulty labels with level range.
 let difficulty=local<=30?"سهل":local<=70?"متوسط":"صعب";
 if(w===0 && local%7===0){let a=(local%9)+3,b=(local%5)+2;q=`ما ناتج ${a} × ${b} + ${a}؟`;ans=String(a*b+a);opts=[String(a*b),String(a*b+a),String((a+b)*a),String(a*b-a)];clue="نفّذ عملية الضرب أولاً ثم أضف العدد الأخير.";}
 if(w===2 && local%6===0){let n=(local%8)+2;q=`لغز القفل: أكمل المتتالية ${n}، ${n*2}، ${n*4}، ${n*8}، ؟`;ans=String(n*16);opts=[String(n*12),String(n*14),String(n*16),String(n*18)];clue="لاحظ كيف تتغير الأعداد من خطوة إلى أخرى.";}
 // Ensure unique choices and deterministic shuffle.
 opts=[...new Set(opts)]; while(opts.length<4)opts.push("حاول مرة أخرى");
 let seed=i*17; opts.sort((a,b)=>((a.length*13+seed)%19)-((b.length*13+seed)%19));
 return {i,w,local,q,ans,opts,clue,difficulty,title:["فكّر بذكاء","ملف القضية","افتح القفل","اختبر سرعتك","قرار المغامر"][w]};
}
const stages=Array.from({length:500},(_,k)=>makeStage(k+1));
let state=JSON.parse(localStorage.getItem("genius500")||'{"unlocked":1,"done":{},"stars":0}');
let current=1,hints=0,solved=false,suggestion=false;
const $=id=>document.getElementById(id);
function save(){localStorage.setItem("genius500",JSON.stringify(state));updateHome();}
function updateHome(){let done=Object.keys(state.done).length;$("totalStars").textContent=state.stars;$("totalSolved").textContent=done;$("progressText").textContent=`${done} / 500`;$("progressBar").style.width=(done/500*100)+"%";}
function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(id).classList.add("active");}
function renderLevels(){let g=$("levelGrid");g.innerHTML="";for(let i=1;i<=500;i++){let b=document.createElement("button");b.className="level "+(state.done[i]?"done":i<=state.unlocked?"open":"lock");b.textContent=state.done[i]?"★":i<=state.unlocked?i:"🔒";b.disabled=i>state.unlocked;b.onclick=()=>start(i);g.appendChild(b)}}
function start(n){current=n;hints=0;solved=false;suggestion=false;let s=stages[n-1];$("worldName").textContent=worlds[s.w].name;$("levelNumber").textContent=`المرحلة ${n} / 500 • ${s.difficulty}`;$("levelStars").textContent=state.done[n]?"★★★":"☆☆☆";$("kind").textContent=worlds[s.w].icon+" "+worlds[s.w].name;$("stageTitle").textContent=s.title+" — "+s.local;$("question").textContent=s.q;$("clue").classList.add("hidden");$("clue").textContent="";$("feedback").textContent="";$("feedback").className="feedback";$("nextBtn").classList.add("hidden");$("hintCount").textContent="3 متبقية";$("hintBtn").disabled=false;$("suggestBtn").disabled=true;$("suggestBtn").innerHTML="🎯 اقتراحات <small>بعد 3 تلميحات</small>";renderAnswers(s.opts);show("game");}
function renderAnswers(opts){let box=$("answers");box.innerHTML="";opts.forEach(o=>{let b=document.createElement("button");b.className="answer";b.textContent=o;b.onclick=()=>choose(o,b);box.appendChild(b)})}
function choose(v,btn){if(solved)return;let s=stages[current-1];if(v===s.ans){solved=true;let stars=hints===0?3:hints===1?2:1;if(!state.done[current]){state.done[current]=stars;state.stars+=stars;state.unlocked=Math.max(state.unlocked,Math.min(500,current+1));}else if(stars>state.done[current]){state.stars+=stars-state.done[current];state.done[current]=stars;}$("feedback").textContent=`إجابة صحيحة! ربحت ${stars} نجوم ⭐`; $("feedback").className="feedback good";$("levelStars").textContent="★".repeat(stars)+"☆".repeat(3-stars);$("nextBtn").classList.remove("hidden");$("hintBtn").disabled=true;$("suggestBtn").disabled=true;document.querySelectorAll(".answer").forEach(x=>{x.disabled=true;if(x.textContent===s.ans)x.classList.add("correct")});save();}else{btn.classList.add("wrong");$("feedback").textContent="ليست الإجابة الصحيحة. حاول مجدداً!";$("feedback").className="feedback bad";}}
$("hintBtn").onclick=()=>{if(hints>=3||solved)return;hints++;let s=stages[current-1];$("clue").textContent=`التلميح ${hints}: ${hints===1?s.clue:hints===2?"استبعد الإجابات التي لا تنسجم مع المعطيات. ركّز على التفاصيل المهمة.":"راجع كلمات السؤال جيداً؛ الحل يعتمد على فهم الشرط الأساسي."}`;$("clue").classList.remove("hidden");$("hintCount").textContent=(3-hints)+" متبقية";if(hints===3){$("suggestBtn").disabled=false;$("suggestBtn").innerHTML="🎯 اقتراحات <small>متاحة الآن</small>";}};
$("suggestBtn").onclick=()=>{if(hints<3||suggestion||solved)return;suggestion=true;let s=stages[current-1];let opts=[s.ans,...s.opts.filter(x=>x!==s.ans)].slice(0,3);renderAnswers(opts);$("feedback").textContent="ثلاثة اقتراحات متاحة؛ اختر الأقرب لما فهمته.";};
$("nextBtn").onclick=()=>{if(current<500)start(current+1);else{show("home");alert("مذهل! أكملت جميع المراحل الـ500!");}};
$("continueBtn").onclick=()=>start(Math.min(state.unlocked,500));$("levelsBtn").onclick=()=>{renderLevels();show("levels")};document.querySelectorAll(".back").forEach(b=>b.onclick=()=>show("home"));updateHome();
