const W=3200,H=2100,SAVE_KEY="ILS_FINAL_RC_1";
const crops={wheat:["🌾",28,3],carrot:["🥕",22,2],corn:["🌽",35,4],potato:["🥔",26,3],tomato:["🍅",40,5]};
const animalInfo={chicken:["🐔",12,"egg",45],cow:["🐄",35,"milk",70],goat:["🐐",26,"milk",55],sheep:["🐑",28,"wool",60]};
const base={x:1600,y:1050,day:1,time:360,weather:"Clear",hp:100,hunger:100,thirst:100,energy:100,level:1,xp:0,
wood:12,stone:8,fiber:5,food:5,water:2,seeds:15,wheat:0,carrot:0,corn:0,potato:0,tomato:0,egg:0,milk:0,wool:0,fish:0,meat:0,money:30,
tools:{axe:false,pick:false,rod:false,bow:false},build:{fire:false,shelter:false,workshop:false,pen:false,house:false,shop:false,dock:false,boat:false,storage:false},
plots:[],animals:[],npcs:[],quests:[],islands:1,discovered:[],gameOver:false};
let S=load(),scene,player,objects=[],touch={up:false,down:false,left:false,right:false},pulse=false,spawnTimer=0;
function load(){try{let s=JSON.parse(localStorage.getItem(SAVE_KEY));return s?merge(base,s):structuredClone(base)}catch(e){return structuredClone(base)}}
function merge(a,b){let r=structuredClone(a);for(const k in b){if(b[k]&&typeof b[k]==="object"&&!Array.isArray(b[k])&&typeof a[k]==="object")r[k]=merge(a[k],b[k]);else r[k]=b[k]}return r}
const config={type:Phaser.AUTO,width:innerWidth,height:innerHeight,parent:"game",physics:{default:"arcade"},scene:{create,update}};
new Phaser.Game(config);

function create(){
 scene=this;scene.cameras.main.setBounds(0,0,W,H);
 scene.add.rectangle(W/2,H/2,W,H,0x072328);
 scene.add.ellipse(1600,1050,2820,1770,0x277d50);
 scene.add.ellipse(1600,1050,2550,1510,0x3e9a62);
 scene.add.ellipse(1600,1050,2250,1250,0x61ad70);
 for(let i=0;i<95;i++)spawn("🌳","wood",180+Math.random()*2840,150+Math.random()*1800,0x185f3a);
 for(let i=0;i<45;i++)spawn("🪨","stone",180+Math.random()*2840,150+Math.random()*1800,0x68767d);
 for(let i=0;i<38;i++)spawn("🍎","fruit",180+Math.random()*2840,150+Math.random()*1800,0xb94a43);
 spawn("💧","water",2850,520,0x258bc0);spawn("🎣","fishspot",2910,650,0x1d678f);
 for(const p of S.plots)drawPlot(p);for(const a of S.animals)drawAnimal(a);for(const n of S.npcs)drawNPC(n);
 if(S.build.boat)drawBoat({x:2700,y:1350});drawBuildings();player=scene.add.circle(S.x,S.y,18,0xf0c995).setDepth(20);scene.cameras.main.startFollow(player,true,.08,.08);
 ui();toast("🎯 প্রথম লক্ষ্য: কাঠ সংগ্রহ করে কুঠার বানাও।");
}
function spawn(e,type,x,y,c){let g=scene.add.circle(x,y,25,c).setDepth(2);scene.add.text(x,y-8,e,{fontSize:"23px"}).setOrigin(.5).setDepth(3);objects.push({e,type,x,y,g})}
function drawPlot(p){p.t=scene.add.text(p.x,p.y,p.ready?crops[p.crop]?.[0]||"🌾":p.planted?"🌱":"⬛",{fontSize:"28px"}).setOrigin(.5).setDepth(5)}
function drawAnimal(a){a.t=scene.add.text(a.x,a.y,animalInfo[a.type]?.[0]||"🐾",{fontSize:"29px"}).setOrigin(.5).setDepth(5)}
function drawNPC(n){n.t=scene.add.text(n.x,n.y,n.role==="farmer"?"🧑‍🌾":n.role==="trader"?"🧑‍💼":"🧑‍🔧",{fontSize:"30px"}).setOrigin(.5).setDepth(5)}
function drawBoat(b){b.t=scene.add.text(b.x,b.y,"⛵",{fontSize:"40px"}).setOrigin(.5).setDepth(5)}
function drawBuildings(){if(S.build.shelter)scene.add.text(1500,850,"🏠",{fontSize:"65px"}).setOrigin(.5);if(S.build.shop)scene.add.text(1750,850,"🏪",{fontSize:"55px"}).setOrigin(.5);if(S.build.pen)scene.add.text(1350,1200,"🐄🐔",{fontSize:"34px"}).setOrigin(.5)}
function update(_,dt){
 if(!player||S.gameOver)return;let vx=(touch.right?1:0)-(touch.left?1:0),vy=(touch.down?1:0)-(touch.up?1:0);
 if(keys.left)vx--;if(keys.right)vx++;if(keys.up)vy--;if(keys.down)vy++;if(vx||vy){let l=Math.hypot(vx,vy),sp=S.energy>3?175:80;player.x+=vx/l*sp*dt/1000;player.y+=vy/l*sp*dt/1000;S.energy=Math.max(0,S.energy-dt/15000)}
 player.x=Phaser.Math.Clamp(player.x,150,3050);player.y=Phaser.Math.Clamp(player.y,120,1980);S.x=player.x;S.y=player.y;
 if(pulse){pulse=false;interact()}simulate(dt);ui();
}
let keys={up:false,down:false,left:false,right:false};
document.querySelectorAll("[data-k]").forEach(b=>{let k=b.dataset.k;["pointerdown","touchstart"].forEach(e=>b.addEventListener(e,x=>{x.preventDefault();touch[k]=true},{passive:false}));["pointerup","pointercancel","pointerout","touchend"].forEach(e=>b.addEventListener(e,x=>{x.preventDefault();touch[k]=false},{passive:false}))});
document.getElementById("action").onclick=()=>pulse=true;document.getElementById("menu").onclick=()=>{document.getElementById("panel").classList.toggle("hidden");showTab("craft")};document.getElementById("close").onclick=()=>document.getElementById("panel").classList.add("hidden");document.getElementById("save").onclick=save;
function save(){localStorage.setItem(SAVE_KEY,JSON.stringify(S));toast("💾 গেম সেভ হয়েছে")}
function simulate(dt){
 S.time+=dt/1000*2.2;if(S.time>=1440){S.time-=1440;S.day++;changeWeather();toast("🌅 Day "+S.day)}
 S.hunger=Math.max(0,S.hunger-dt/1000*.042);S.thirst=Math.max(0,S.thirst-dt/1000*.065);S.energy=Math.min(100,S.energy+dt/1000*.015);
 if(S.weather==="Rain"){S.thirst=Math.min(100,S.thirst+dt/1000*.025)}
 if(S.hunger<8)S.hp=Math.max(0,S.hp-dt/1000*.55);if(S.thirst<8)S.hp=Math.max(0,S.hp-dt/1000*.8);
 if(S.hp<=0){S.hp=100;S.hunger=55;S.thirst=55;S.energy=70;S.x=1600;S.y=1050;toast("💀 তুমি অজ্ঞান হয়েছিলে—ক্যাম্পে ফিরে এসেছো।")}
 for(const p of S.plots)if(p.planted&&!p.ready&&Date.now()>=p.readyAt){p.ready=true;p.t?.setText(crops[p.crop][0]);toast("🌾 "+p.crop+" প্রস্তুত!")}
 for(const a of S.animals){a.hunger=Math.max(0,a.hunger-dt/1000*.018);if(a.hunger<10)a.hp=Math.max(0,(a.hp??100)-dt/1000*.6);let inf=animalInfo[a.type];if(inf&&a.hunger>25&&Date.now()>(a.prodAt||0)){S[inf[2]]++;a.prodAt=Date.now()+inf[3]*1000;toast(inf[2]==="egg"?"🥚 ডিম পাওয়া গেছে":inf[2]==="milk"?"🥛 দুধ পাওয়া গেছে":"🧶 উল পাওয়া গেছে")}}
 if(S.xp>=S.level*100){S.xp-=S.level*100;S.level++;toast("⭐ Level Up! Lv "+S.level)}
}
function changeWeather(){S.weather=["Clear","Cloudy","Rain","Windy"][Math.floor(Math.random()*4)];}
function interact(){
 let near=objects.map(o=>({...o,d:Math.hypot(o.x-player.x,o.y-player.y)})).sort((a,b)=>a.d-b.d)[0];
 if(near&&near.d<72){if(near.type==="wood"){S.wood++;S.fiber++;S.xp+=4;takeObj(near,"🪵 কাঠ +1")}else if(near.type==="stone"){S.stone++;S.xp+=4;takeObj(near,"🪨 পাথর +1")}else if(near.type==="fruit"){S.food++;S.hunger=Math.min(100,S.hunger+4);S.xp+=4;takeObj(near,"🍎 খাবার +1")}else if(near.type==="water"){S.water++;S.thirst=Math.min(100,S.thirst+35);toast("💧 পানি পাওয়া গেল")}else if(near.type==="fishspot"){if(S.tools.rod){S.fish++;S.food++;S.xp+=12;toast("🎣 মাছ ধরা হয়েছে")}else toast("🎣 আগে Fishing Rod বানাও")}return}
 let p=S.plots.find(x=>Math.hypot(x.x-player.x,x.y-player.y)<65);if(p){if(p.ready){S[p.crop]+=p.amount;p.ready=false;p.planted=false;p.t.setText("⬛");S.xp+=20;toast("🌾 "+p.crop+" harvest!")}else if(!p.planted&&S.seeds>0){S.seeds--;let keys=Object.keys(crops);p.crop=keys[Math.floor(Math.random()*keys.length)];p.planted=true;p.readyAt=Date.now()+crops[p.crop][1]*1000;p.amount=crops[p.crop][2];p.t.setText("🌱");toast("🌱 "+p.crop+" লাগানো হয়েছে")}else toast("⏳ ফসল বাড়ছে");return}
 let a=S.animals.find(x=>Math.hypot(x.x-player.x,x.y-player.y)<75);if(a){if(S.food>0){S.food--;a.hunger=Math.min(100,a.hunger+40);a.hp=100;toast("🍎 পশুকে খাবার দেওয়া হলো")}else toast("পশুর খাবার নেই");return}
 let n=S.npcs.find(x=>Math.hypot(x.x-player.x,x.y-player.y)<80);if(n){trade(n);return}
 if(Math.hypot(player.x-2850,player.y-520)<85){S.water++;S.thirst=Math.min(100,S.thirst+35);toast("💧 পানি পান/সংগ্রহ")}else toast("কাছাকাছি কিছু নেই")}
function takeObj(o,msg){o.g.destroy();objects=objects.filter(x=>x!==o);toast(msg)}
function showTab(tab){let tabs=document.getElementById("tabs"),c=document.getElementById("content");tabs.innerHTML=["craft","farm","animals","village","inventory","quests"].map(x=>`<button onclick="showTab('${x}')">${({craft:"🛠️ Craft",farm:"🌱 Farm",animals:"🐾 Animals",village:"🏘️ Village",inventory:"🎒 Inventory",quests:"📜 Quests"})[x]}</button>`).join("");c.innerHTML="";
 if(tab==="craft"){card("🛠️ Crafting",`Wood ${S.wood} • Stone ${S.stone} • Fiber ${S.fiber}`);add("🪓 Axe — 6 wood + 2 stone",()=>tool("axe",6,2));add("⛏️ Pickaxe — 7 wood + 5 stone",()=>tool("pick",7,5));add("🎣 Fishing Rod — 5 wood + 3 fiber",()=>tool("rod",5,0,3));add("🏹 Bow — 8 wood + 4 fiber",()=>tool("bow",8,0,4));add("🔥 Campfire — 8 wood + 5 stone",()=>build("fire",8,5));add("🏠 Shelter — 20 wood + 10 stone",()=>build("shelter",20,10));add("🛠️ Workshop — 35 wood + 20 stone",()=>build("workshop",35,20));add("📦 Storage — 25 wood + 8 stone",()=>build("storage",25,8));add("🐄 Animal Pen — 25 wood + 12 stone",()=>build("pen",25,12))}
 if(tab==="farm"){card("🌱 Farming",`Seeds: ${S.seeds}<br>Wheat ${S.wheat} • Carrot ${S.carrot} • Corn ${S.corn} • Potato ${S.potato} • Tomato ${S.tomato}`);add("➕ Farm Plot — 3 wood",newPlot);add("🌾 Buy 10 seeds — 6 money",()=>{if(S.money>=6){S.money-=6;S.seeds+=10;toast("🌾 Seeds +10")}else toast("টাকা কম")})}
 if(tab==="animals"){card("🐾 Husbandry",`Egg ${S.egg} • Milk ${S.milk} • Wool ${S.wool}<br>খাবার দিলে পশুর health ও production বজায় থাকে।`);add("🐔 Chicken — 12 money",()=>buyAnimal("chicken",12));add("🐄 Cow — 35 money",()=>buyAnimal("cow",35));add("🐐 Goat — 26 money",()=>buyAnimal("goat",26));add("🐑 Sheep — 28 money",()=>buyAnimal("sheep",28))}
 if(tab==="village"){card("🏘️ Village",`NPC ${S.npcs.length} • Islands unlocked ${S.islands} • Money ${S.money}`);add("🧑‍🌾 Farmer NPC",()=>addNPC("farmer"));add("🧑‍💼 Trader NPC",()=>addNPC("trader"));add("🧑‍🔧 Builder NPC",()=>addNPC("builder"));add("🏠 House — 45 wood + 20 stone",()=>build("house",45,20));add("🏪 Shop — 55 wood + 25 stone",()=>build("shop",55,25));add("⚓ Dock — 65 wood + 30 stone",()=>build("dock",65,30));add("⛵ Boat — 90 wood + 45 stone",buildBoat);add("🗺️ Unlock island — 150 money",unlockIsland)}
 if(tab==="inventory")card("🎒 Inventory",`🪵 ${S.wood} 🪨 ${S.stone} 🧵 ${S.fiber}<br>🍎 Food ${S.food} 💧 Water ${S.water} 🎣 Fish ${S.fish} 🥩 Meat ${S.meat}<br>🥚 ${S.egg} 🥛 ${S.milk} 🧶 ${S.wool} 💰 ${S.money}<br>Tools: ${Object.keys(S.tools).filter(k=>S.tools[k]).join(", ")||"none"}`);
 if(tab==="quests"){card("📜 Quest Progress",`<b>1. First Shelter</b> — ${S.build.shelter?"Complete":"Build shelter"}<br><b>2. Farmer</b> — ${S.plots.length?"Complete":"Create a farm plot"}<br><b>3. Animal Keeper</b> — ${S.animals.length?"Complete":"Get an animal"}<br><b>4. Village</b> — ${S.npcs.length>=3?"Complete":"Invite 3 NPCs"}<br><b>5. Explorer</b> — ${S.islands>=2?"Complete":"Unlock another island"}`)}
}
function card(t,x){document.getElementById("content").insertAdjacentHTML("beforeend",`<div class=card><b>${t}</b><br>${x}</div>`)}
function add(t,f){let b=document.createElement("button");b.textContent=t;b.onclick=f;document.getElementById("content").appendChild(b)}
function tool(k,w,p,f=0){if(S.tools[k])return toast("আগেই আছে");if(S.wood>=w&&S.stone>=p&&S.fiber>=f){S.wood-=w;S.stone-=p;S.fiber-=f;S.tools[k]=true;S.xp+=25;toast("✅ Tool crafted")}else toast("সম্পদ কম")}
function build(k,w,p){if(S.build[k])return toast("আগেই তৈরি");if(S.wood>=w&&S.stone>=p){S.wood-=w;S.stone-=p;S.build[k]=true;S.xp+=35;toast("🏗️ "+k+" তৈরি হয়েছে");drawBuildings()}else toast("সম্পদ কম")}
function newPlot(){if(S.wood<3)return toast("কাঠ কম");S.wood-=3;let p={x:1250+Math.random()*650,y:700+Math.random()*500,planted:false,ready:false};S.plots.push(p);drawPlot(p);S.xp+=8;toast("🌱 Farm plot তৈরি")}
function buyAnimal(type,cost){if(!S.build.pen)return toast("আগে Animal Pen বানাও");if(S.money<cost)return toast("টাকা কম");S.money-=cost;let a={type,x:1320+Math.random()*260,y:1120+Math.random()*180,hunger:80,hp:100,prodAt:Date.now()+15000};S.animals.push(a);drawAnimal(a);toast("🐾 "+type+" এসেছে")}
function addNPC(role){if(S.npcs.length>=15)return toast("এই পর্যায়ে সর্বোচ্চ 15 NPC");let n={role,x:1600+S.npcs.length*55,y:800+Math.random()*170};S.npcs.push(n);drawNPC(n);S.xp+=20;toast("🧑 NPC এসেছে")}
function trade(n){if(n.role==="trader"){if(S.food>=3){S.food-=3;S.money+=8;toast("💰 3 food = 8 money")}else if(S.wheat>=2){S.wheat-=2;S.money+=10;toast("💰 2 wheat = 10 money")}else if(S.money>=6){S.money-=6;S.seeds+=10;toast("🌾 +10 seeds")}else toast("trade করার সম্পদ কম")}else if(n.role==="farmer"){if(S.seeds<3&&S.money>=4){S.money-=4;S.seeds+=6;toast("Farmer থেকে seeds")}else toast("Farmer: চাষ চালিয়ে যাও!")}else toast("Builder: workshop বানালে নতুন কাজ খুলবে।")}
function buildBoat(){if(!S.build.dock)return toast("আগে Dock বানাও");if(S.wood<90||S.stone<45)return toast("90 wood + 45 stone লাগবে");S.wood-=90;S.stone-=45;S.build.boat=true;drawBoat({x:2700,y:1350});toast("⛵ নৌকা তৈরি হয়েছে!")}
function unlockIsland(){if(!S.build.boat)return toast("আগে Boat বানাও");if(S.money<150)return toast("150 টাকা লাগবে");S.money-=150;S.islands++;S.discovered.push("Island "+S.islands);toast("🗺️ Island "+S.islands+" unlocked!")}
function ui(){const q=x=>Math.floor(x);document.getElementById("hp").textContent=q(S.hp);document.getElementById("hunger").textContent=q(S.hunger);document.getElementById("thirst").textContent=q(S.thirst);document.getElementById("energy").textContent=q(S.energy);document.getElementById("level").textContent=S.level;document.getElementById("day").textContent=S.day;let h=Math.floor(S.time/60),m=Math.floor(S.time%60);document.getElementById("clock").textContent=String(h).padStart(2,"0")+":"+String(m).padStart(2,"0");document.getElementById("weather").textContent=S.weather;document.getElementById("inventory").textContent=`🪵${S.wood} 🪨${S.stone} 🍎${S.food} 💧${S.water} 🌾${S.seeds} 🥚${S.egg} 🥛${S.milk} 🧶${S.wool} 💰${S.money} ⭐${S.xp}/${S.level*100}`;document.getElementById("quest").textContent=S.level<2?"🎯 কাঠ সংগ্রহ → Craft Axe → Shelter":S.level<4?"🎯 Farm Plot → Animal Pen → একটি পশু পালন":S.npcs.length<3?"🎯 3 NPC আনো → House/Shop/Dock বানাও":"🎯 Boat বানিয়ে নতুন Island unlock করো।"}
function toast(t){let e=document.getElementById("toast");e.textContent=t;e.style.opacity=1;clearTimeout(window.toastT);window.toastT=setTimeout(()=>e.style.opacity=0,1900)}
setInterval(save,30000);addEventListener("beforeunload",save);
