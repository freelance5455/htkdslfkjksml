// Custom JavaScript / Mod Script Template
function initializeMod() {
    console.log("MN Panel custom script loaded successfully.");
}
initializeMod();
