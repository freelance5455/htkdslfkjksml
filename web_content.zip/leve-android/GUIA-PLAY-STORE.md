# Guia para publicar o Leve na Google Play

## 1. O que está pronto e o que falta

**Pronto (neste pacote):**
- App Leve com cadastro, exercícios ilustrados, diário, cardápio, treinos, progresso e o plano Premium de R$ 23,90 por mês.
- Projeto Android (Capacitor) com ponte de cobrança para a Google Play via RevenueCat.
- Ícone 512, gráfico de recursos 1024x500, 5 capturas de tela e textos da ficha da loja.
- Páginas públicas de política de privacidade, termos e exclusão de conta.

**Falta fazer (precisa de você e de um computador):**
- Criar a conta de desenvolvedor na Google Play Console.
- Gerar o arquivo `.aab` no Android Studio. Não consegui gerar aqui, porque exige o Android Studio e o SDK do Android.
- Criar a assinatura na Play Console e no RevenueCat e testar a compra real. A ponte `billing.js` é um esqueleto que **não foi testado**.
- Hospedar as páginas da pasta `site` em endereços públicos.
- Cumprir os testes e a revisão do Google.

## 2. Regras do Google que mudam seu plano (conferidas em 14/10/2026)

- **Teste fechado antes da produção:** contas pessoais criadas depois de 13/11/2023 precisam de um teste fechado com pelo menos 12 testadores, todos inscritos sem interrupção por 14 dias, antes de pedir acesso à produção. Conta de organização segue regras diferentes, confira na Play Console.
- **Versão do Android:** a partir de 31/08/2026, apps novos e atualizações precisam mirar o Android 16 (API 36). Há extensão possível até 01/11/2026. Confira `targetSdkVersion` no projeto antes de gerar o `.aab`.
- **Exclusão de conta:** apps que criam conta precisam oferecer a exclusão dentro do app e também um link na web, informado no formulário Segurança dos dados. O Leve já tem o botão no app, e a página `site/excluir-conta.html` serve de link.
- **Assinaturas:** vendas digitais dentro do app devem usar o Google Play Billing, e o Google cobra uma tarifa de serviço sobre a assinatura (historicamente 15%). Confirme a tarifa vigente na Play Console.
- **Apps de saúde:** a Play Console pede declarações específicas para apps de saúde e fitness. Preencha todas.

Fontes: [requisitos de API alvo](https://developer.android.com/google/play/requirements/target-sdk), [testes para contas pessoais](https://support.google.com/googleplay/android-developer/answer/14151465), [exclusão de conta](https://support.google.com/googleplay/android-developer/answer/13327111).

## 3. Passo a passo

### 3.1 Conta e computador
1. Crie a conta em play.google.com/console (taxa única de registro, historicamente US$ 25) e conclua a verificação de identidade.
2. Configure o perfil de pagamentos (necessário para vender assinatura).
3. No computador, instale Node.js (versão LTS) e o Android Studio.

### 3.2 Gerar o app
1. Abra o `README.md` do projeto e troque `appId`, a chave do RevenueCat e os textos `NOME_DO_DESENVOLVEDOR` e `SEU_EMAIL_AQUI`.
2. Rode os comandos do README (instalar, `cap add android`, gerar ícones, sincronizar, abrir).
3. No Android Studio, confirme `targetSdkVersion` 36, defina `versionCode` e `versionName` e gere o `.aab` em Build, Generate Signed App Bundle.
4. Guarde o arquivo de chave (keystore) e a senha em local seguro. Ative o Play App Signing quando a Play Console oferecer.

### 3.3 Assinatura de R$ 23,90 por mês
1. Play Console, Monetizar com o Google Play, Produtos, Assinaturas, Criar assinatura.
2. ID do produto: `leve_premium`. Crie um plano básico mensal, com renovação automática, e defina R$ 23,90 para o Brasil. Os outros países podem usar a conversão automática.
3. No RevenueCat: crie o projeto, conecte a Google Play (conta de serviço), importe o produto, crie o entitlement `premium` e uma offering padrão com o pacote mensal.
4. Cole a chave pública Android do RevenueCat em `www/billing.js` e rode `npm run sync`.
5. Na Play Console, cadastre seu e-mail como testador de licença e teste a compra em um aparelho real.

### 3.4 Páginas públicas
1. Hospede a pasta `site` em um endereço público (GitHub Pages, Netlify ou Google Sites).
2. Use `privacidade.html` como política de privacidade e `excluir-conta.html` como link de exclusão de conta.

### 3.5 Ficha da loja
1. Nome, descrição curta e completa: use o arquivo `store/textos-da-loja.md`.
2. Imagens: `icon-512.png`, `feature-graphic-1024x500.png` e as capturas de `store/screenshots`.
3. Categoria Saúde e fitness, público-alvo 18 anos ou mais, sem anúncios.
4. Preencha classificação etária, Segurança dos dados, declaração de apps de saúde e os links da seção 3.4.

### 3.6 Testes e lançamento
1. Teste interno: libera na hora para até 100 pessoas.
2. Teste fechado: 12 testadores por 14 dias seguidos (contas pessoais novas).
3. Peça acesso à produção e aguarde a revisão do Google, que pode levar alguns dias.
4. A cada nova versão, aumente o `versionCode`.

## 4. Segurança dos dados: ponto de partida para as respostas

| Dado | Situação nesta versão | O que declarar |
|---|---|---|
| Nome e e-mail | Ficam só no aparelho | Não saem do aparelho, então não contam como coletados |
| Peso, alimentação, treinos | Ficam só no aparelho | Idem |
| Compras | O RevenueCat recebe os dados da compra e um identificador anônimo | Declare histórico de compras e identificadores como coletados, para funcionalidades do app, tratados por provedor de serviço |

Se você adicionar login em nuvem ou sincronização, esses dados passam a ser coletados e a política e o formulário precisam mudar. Revise as respostas com a ferramenta oficial: você responde por elas.

## 5. Limites desta versão

- **Cadastro simples:** o e-mail não é verificado e não há senha. Os dados ficam no aparelho, então trocar de celular perde o histórico. Para contas reais, sincronização e proteção do Premium, adicione um servidor (por exemplo Firebase Authentication e Firestore) e valide a assinatura no servidor.
- **Premium no aplicativo:** a liberação acontece dentro do app, e quem alterar o app pode burlar. O RevenueCat ajuda, mas a validação no servidor é o ideal.
- **Fontes:** carregam do Google Fonts e precisam de internet. Para uso offline, embutir as fontes no projeto.
- **Ilustrações:** são bonecos simplificados. Considere ilustrações ou fotos profissionais licenciadas antes do lançamento.
- **Conteúdo de saúde:** peça revisão de um nutricionista e de um profissional de educação física. Os cardápios e treinos são genéricos.
- **Textos legais:** termos e política são modelos. Revise com um advogado.
- **Capturas de tela:** foram geradas no computador com dados de exemplo. Para o lançamento final, refaça no emulador ou no celular.

## 6. Lista final

- [ ] Conta de desenvolvedor criada e verificada
- [ ] `appId`, chave do RevenueCat, nome e e-mail trocados
- [ ] `.aab` gerado com targetSdk 36
- [ ] Assinatura `leve_premium` de R$ 23,90 criada e testada
- [ ] Páginas do `site` publicadas e links colocados na Play Console
- [ ] Ficha da loja, imagens e declarações preenchidas
- [ ] Teste fechado com 12 testadores por 14 dias
- [ ] Revisão jurídica e de saúde feita
