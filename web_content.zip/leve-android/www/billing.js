/* Ponte de cobrança entre o app Leve e a Google Play, via RevenueCat.
   ESQUELETO NÃO TESTADO: valide em um aparelho com uma conta de testador de licença antes de publicar.
   O app (www/index.html) procura window.LeveBilling. Sem ele, o botão Assinar roda em modo de demonstração. */
(function(){
  var cap=window.Capacitor;
  if(!cap||!cap.isNativePlatform||!cap.isNativePlatform())return;
  var RC=cap.Plugins&&cap.Plugins.Purchases;
  if(!RC)return;
  var API_KEY='COLE_AQUI_A_CHAVE_PUBLICA_ANDROID_DO_REVENUECAT'; /* começa com goog_ */
  var ENTITLEMENT='premium';                                      /* nome do entitlement no RevenueCat */
  var ready=null;
  function init(){if(!ready)ready=RC.configure({apiKey:API_KEY});return ready}
  function result(r){
    var info=(r&&r.customerInfo)||r||{};
    var a=info.entitlements&&info.entitlements.active&&info.entitlements.active[ENTITLEMENT];
    return {active:!!a,renews:(a&&a.expirationDate)?String(a.expirationDate).slice(0,10):null};
  }
  window.LeveBilling={
    status:function(){return init().then(function(){return RC.getCustomerInfo()}).then(result)},
    subscribe:function(){
      return init().then(function(){return RC.getOfferings()}).then(function(o){
        var cur=o&&o.current,pkg=cur&&(cur.monthly||(cur.availablePackages&&cur.availablePackages[0]));
        if(!pkg)throw new Error('Nenhuma oferta encontrada no RevenueCat');
        return RC.purchasePackage({aPackage:pkg});
      }).then(result);
    },
    restore:function(){return init().then(function(){return RC.restorePurchases()}).then(result)}
  };
})();
