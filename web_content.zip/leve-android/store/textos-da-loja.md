# Textos da ficha da loja (Google Play)

**Nome do app** (28/30)
Leve: Plano de Emagrecimento

**Descrição curta** (78/80)
Metas de calorias, cardápio e treinos ilustrados para emagrecer com segurança.

**Descrição completa** (1486/4000)

Leve é o seu plano de emagrecimento no celular: metas calculadas para o seu corpo, cardápio, treinos com ilustrações e acompanhamento do seu progresso.

O QUE VOCÊ FAZ NO LEVE
• Meta diária de calorias, proteína, carboidrato, gordura e água, calculada com seus dados e com limites de segurança.
• Diário de alimentos com mais de 40 alimentos brasileiros e anel de calorias do dia.
• Cardápio sugerido com porções ajustadas à sua meta.
• Treinos de segunda a domingo, em casa, com ilustração de cada exercício (início e final do movimento) e cronômetro de descanso.
• Registro de peso e cintura, gráfico de evolução e previsão para chegar à meta.
• Hábitos diários, controle de água e conquistas.

LEVE PREMIUM · R$ 23,90 por mês
• Treinos de nível intermediário e de academia
• Cardápios B e C com lista de compras da semana
• Todas as receitas fit com macros
• Desafio de 21 dias com uma missão por dia
• Relatório semanal e gráfico de cintura
A assinatura é mensal, renovada automaticamente e cobrada pela sua conta Google Play. Você pode cancelar quando quiser em Play Store, Pagamentos e assinaturas, Assinaturas.

IMPORTANTE
O Leve oferece estimativas educativas e não substitui médico, nutricionista ou profissional de educação física. Consulte um profissional antes de mudar a alimentação ou começar a se exercitar. Não é indicado para menores de 18 anos.

Seus dados de uso ficam salvos no seu aparelho. Você pode excluir sua conta e seus dados a qualquer momento dentro do app.

**Categoria:** Saúde e fitness
**Tipo:** Aplicativo, gratuito com compras no app (assinatura)
**Público-alvo:** 18 anos ou mais
**Anúncios:** não
**Palavras para a descrição:** emagrecer, dieta, calorias, treino em casa, cardápio, perder peso, contador de calorias, exercícios
