# Leve para Android (projeto Capacitor)

Empacota o app Leve (pasta `www`) como app Android para a Google Play.
Leia primeiro o **GUIA-PLAY-STORE.md**.

## O que tem aqui
- `www/` o app (index.html) e a ponte de cobrança (billing.js)
- `assets/` ícone e splash para gerar os recursos do Android
- `site/` páginas públicas exigidas pela Play (privacidade, termos, exclusão de conta)
- `store/` ícone 512, gráfico de recursos 1024x500, capturas de tela e textos da ficha da loja

## Troque antes de usar
1. `capacitor.config.json`: `appId` (ex.: br.com.seunome.leve). Depois de publicar, não muda mais.
2. `www/billing.js`: `API_KEY` do RevenueCat (Android).
3. `site/*.html`: `NOME_DO_DESENVOLVEDOR` e `SEU_EMAIL_AQUI`.

## Comandos (Node.js LTS e Android Studio instalados)
```
npm install @capacitor/core @capacitor/android @revenuecat/purchases-capacitor
npm install -D @capacitor/cli @capacitor/assets
npx cap add android
npm run icons
npm run sync
npm run open
```
No Android Studio: confirme `targetSdkVersion` 36 em `android/variables.gradle`, defina versionCode e versionName e use Build > Generate Signed App Bundle para gerar o `.aab`.
