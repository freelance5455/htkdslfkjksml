package br.com.efraim.gestao;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebView.WebViewTransport;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.os.Message;

public class MainActivity extends Activity {
    private WebView webView;

    public class AndroidBridge {
        @JavascriptInterface
        public void openExternal(String rawUrl) {
            runOnUiThread(() -> handleExternalUrl(rawUrl));
        }
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.addJavascriptInterface(new AndroidBridge(), "EfraimAndroid");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog,
                                          boolean isUserGesture, Message resultMsg) {
                WebView popup = new WebView(MainActivity.this);
                WebSettings popupSettings = popup.getSettings();
                popupSettings.setJavaScriptEnabled(true);
                popupSettings.setDomStorageEnabled(true);
                popup.setWebViewClient(new WebViewClient() {
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                        handleExternalUrl(request.getUrl().toString());
                        v.post(() -> v.destroy());
                        return true;
                    }
                    @SuppressWarnings("deprecation")
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView v, String url) {
                        handleExternalUrl(url);
                        v.post(() -> v.destroy());
                        return true;
                    }
                    @Override
                    public void onPageStarted(WebView v, String url, android.graphics.Bitmap favicon) {
                        super.onPageStarted(v, url, favicon);
                        if (url != null && !url.equals("about:blank")) {
                            handleExternalUrl(url);
                            v.post(() -> v.destroy());
                        }
                    }
                });
                WebViewTransport transport = (WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleUrl(request.getUrl().toString());
            }
            @SuppressWarnings("deprecation")
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installExternalLinkHandler(view);
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void installExternalLinkHandler(WebView view) {
        String script =
            "(function(){" +
            "if(window.__efraimExternalLinksInstalled)return;" +
            "window.__efraimExternalLinksInstalled=true;" +
            "window.open=function(url){" +
            "if(url&&window.EfraimAndroid){window.EfraimAndroid.openExternal(String(url));}" +
            "return null;" +
            "};" +
            "document.addEventListener('click',function(e){" +
            "var a=e.target&&e.target.closest?e.target.closest('a[target=\"_blank\"]'):null;" +
            "if(a&&a.href){" +
            "e.preventDefault();e.stopPropagation();" +
            "if(window.EfraimAndroid)window.EfraimAndroid.openExternal(a.href);" +
            "}" +
            "},true);" +
            "})();";
        view.evaluateJavascript(script, null);
    }

    private boolean handleUrl(String rawUrl) {
        Uri uri = Uri.parse(rawUrl);
        String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
        if (scheme.equals("http") || scheme.equals("https") ||
            scheme.equals("whatsapp") || scheme.equals("tel") || scheme.equals("mailto") ||
            scheme.equals("intent")) {
            handleExternalUrl(rawUrl);
            return true;
        }
        return true;
    }

    private void handleExternalUrl(String rawUrl) {
        try {
            if (rawUrl == null || rawUrl.trim().isEmpty()) return;
            Intent intent;
            if (rawUrl.startsWith("intent://")) {
                intent = Intent.parseUri(rawUrl, Intent.URI_INTENT_SCHEME);
                if (intent.resolveActivity(getPackageManager()) == null) {
                    String fallback = intent.getStringExtra("browser_fallback_url");
                    if (fallback != null) intent = new Intent(Intent.ACTION_VIEW, Uri.parse(fallback));
                    else throw new IllegalStateException("Nenhum aplicativo compatível.");
                }
            } else {
                Uri uri = Uri.parse(rawUrl);
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if (!(scheme.equals("http") || scheme.equals("https") ||
                      scheme.equals("whatsapp") || scheme.equals("tel") || scheme.equals("mailto"))) {
                    Toast.makeText(this, "Endereço externo não suportado.", Toast.LENGTH_LONG).show();
                    return;
                }
                intent = new Intent(Intent.ACTION_VIEW, uri);
            }
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o link. Verifique se há um aplicativo compatível instalado.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
