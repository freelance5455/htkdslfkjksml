-- EFRAIM GESTÃO 6.2.0 — vendas lançadas por funcionários
-- Execute uma única vez no Supabase > SQL Editor, usando uma conta proprietária.
-- Não apaga dados existentes. Atualiza somente o payload de business_state na hora da venda.

create or replace function public.employee_get_sale_catalog()
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_uid uuid := auth.uid();
  v_payload jsonb;
  v_clients jsonb;
  v_products jsonb;
begin
  if v_uid is null then raise exception 'Sessão inválida.'; end if;
  if not exists (select 1 from public.user_profiles p where p.id=v_uid and p.active=true and p.role <> 'admin') then
    raise exception 'Acesso de funcionário não autorizado.';
  end if;
  if not exists (select 1 from public.employee_permissions ep where ep.user_id=v_uid and ep.permission_key='register_sales' and ep.enabled=true) then
    raise exception 'Permissão para registrar vendas não liberada pelo ADM.';
  end if;
  select payload into v_payload from public.business_state where id=1;
  if v_payload is null then raise exception 'Dados da empresa ainda não foram inicializados pelo ADM.'; end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',c->>'id','name',coalesce(c->>'name','Cliente'))),'[]'::jsonb)
    into v_clients from jsonb_array_elements(coalesce(v_payload->'clients','[]'::jsonb)) as x(c);
  select coalesce(jsonb_agg(jsonb_build_object('id',p->>'id','name',coalesce(p->>'name','Produto'),'qty',coalesce((p->>'qty')::numeric,0),'price',coalesce((p->>'price')::numeric,0),'unit',coalesce(p->>'unit','un.'))),'[]'::jsonb)
    into v_products from jsonb_array_elements(coalesce(v_payload->'products','[]'::jsonb)) as x(p)
    where coalesce((p->>'qty')::numeric,0)>0;
  return jsonb_build_object('clients',v_clients,'products',v_products);
end;
$$;

create or replace function public.employee_create_sale(
  p_client_id text,
  p_product_id text,
  p_qty numeric,
  p_unit_price numeric,
  p_sale_date date,
  p_method text,
  p_paid_amount numeric default 0,
  p_obs text default ''
)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare
  v_uid uuid := auth.uid();
  v_profile record;
  v_payload jsonb;
  v_products jsonb;
  v_sales jsonb;
  v_moves jsonb;
  v_client_name text := 'Consumidor avulso';
  v_product jsonb;
  v_sale_id text := gen_random_uuid()::text;
  v_total numeric(14,2);
  v_cost numeric(14,4);
  v_sale jsonb;
  v_move jsonb;
  v_new_products jsonb;
  v_new_moves jsonb;
  v_revision bigint;
begin
  if v_uid is null then raise exception 'Sessão inválida.'; end if;
  select id,username,full_name,role,active into v_profile
    from public.user_profiles where id=v_uid;
  if not found or not v_profile.active or v_profile.role='admin' then
    raise exception 'Acesso de funcionário não autorizado.';
  end if;
  if not exists (select 1 from public.employee_permissions ep where ep.user_id=v_uid and ep.permission_key='register_sales' and ep.enabled=true) then
    raise exception 'Permissão para registrar vendas não liberada pelo ADM.';
  end if;
  if p_product_id is null or btrim(p_product_id)='' or p_qty is null or p_qty<=0 or p_unit_price is null or p_unit_price<=0 then
    raise exception 'Produto, quantidade e preço precisam ser válidos.';
  end if;
  if p_paid_amount is null or p_paid_amount<0 then raise exception 'Valor recebido inválido.'; end if;
  if coalesce(p_method,'') not in ('Fiado','PIX','Dinheiro','Cartão','Transferência') then raise exception 'Forma de pagamento inválida.'; end if;
  if p_method='Fiado' and p_paid_amount>0 then raise exception 'Venda fiada não pode ter recebimento inicial.'; end if;
  v_total := round(p_qty*p_unit_price,2);
  if p_paid_amount>v_total then raise exception 'O recebido não pode superar o total da venda.'; end if;

  -- Lock serializa vendas concorrentes e evita duas baixas do mesmo saldo.
  select payload,revision into v_payload,v_revision
    from public.business_state where id=1 for update;
  if not found or v_payload is null then raise exception 'Dados da empresa ainda não foram inicializados.'; end if;
  v_products := coalesce(v_payload->'products','[]'::jsonb);
  v_sales := coalesce(v_payload->'sales','[]'::jsonb);
  v_moves := coalesce(v_payload->'stockMoves','[]'::jsonb);

  select p into v_product from jsonb_array_elements(v_products) as x(p) where p->>'id'=p_product_id limit 1;
  if v_product is null then raise exception 'Produto não encontrado no cadastro.'; end if;
  if coalesce((v_product->>'qty')::numeric,0)<p_qty then
    raise exception 'Estoque insuficiente. Disponível: % %.', coalesce((v_product->>'qty')::numeric,0), coalesce(v_product->>'unit','un.');
  end if;
  if p_client_id is not null and btrim(p_client_id)<>'' then
    select coalesce(c->>'name','Cliente') into v_client_name
      from jsonb_array_elements(coalesce(v_payload->'clients','[]'::jsonb)) as x(c)
      where c->>'id'=p_client_id limit 1;
    if v_client_name is null then raise exception 'Cliente não encontrado no cadastro.'; end if;
  end if;
  v_cost := coalesce((v_product->>'cost')::numeric,0);

  v_sale := jsonb_build_object(
    'id',v_sale_id,'date',coalesce(p_sale_date,current_date),'clientId',nullif(p_client_id,''),'client',v_client_name,
    'items',jsonb_build_array(jsonb_build_object('productId',p_product_id,'productName',coalesce(v_product->>'name','Produto'),'qty',p_qty,'price',p_unit_price,'cost',v_cost,'unit',coalesce(v_product->>'unit','un.'))),
    'discount',0,'total',v_total,'paidAmount',p_paid_amount,
    'payments',case when p_paid_amount>0 then jsonb_build_array(jsonb_build_object('date',coalesce(p_sale_date,current_date),'amount',p_paid_amount,'method',p_method,'kind','Recebimento inicial')) else '[]'::jsonb end,
    'method',p_method,'obs',concat_ws(' | ',nullif(btrim(coalesce(p_obs,'')),''),'Registrada por funcionário: '||coalesce(nullif(v_profile.full_name,''),v_profile.username)),
    'employeeId',v_uid,'employeeName',coalesce(nullif(v_profile.full_name,''),v_profile.username),'createdBy',coalesce(nullif(v_profile.full_name,''),v_profile.username)
  );
  v_move := jsonb_build_object('id',gen_random_uuid()::text,'date',coalesce(p_sale_date,current_date),'type','Saída','qty',p_qty,'reason','Venda','note',v_client_name,'saleId',v_sale_id,'productId',p_product_id,'productName',coalesce(v_product->>'name','Produto'),'unitCost',v_cost,'employeeId',v_uid,'employeeName',coalesce(nullif(v_profile.full_name,''),v_profile.username));

  select coalesce(jsonb_agg(case when p->>'id'=p_product_id then jsonb_set(p,'{qty}',to_jsonb(round(coalesce((p->>'qty')::numeric,0)-p_qty,4)),true) else p end order by ord),'[]'::jsonb)
    into v_new_products from jsonb_array_elements(v_products) with ordinality as x(p,ord);
  v_new_moves := jsonb_build_array(v_move) || v_moves;
  v_payload := jsonb_set(v_payload,'{products}',v_new_products,true);
  v_payload := jsonb_set(v_payload,'{sales}',jsonb_build_array(v_sale)||v_sales,true);
  v_payload := jsonb_set(v_payload,'{stockMoves}',v_new_moves,true);
  update public.business_state set payload=v_payload,revision=coalesce(revision,0)+1 where id=1 returning revision into v_revision;
  return jsonb_build_object('sale_id',v_sale_id,'total',v_total,'revision',v_revision,'employee_name',coalesce(nullif(v_profile.full_name,''),v_profile.username));
end;
$$;

revoke all on function public.employee_get_sale_catalog() from public, anon;
revoke all on function public.employee_create_sale(text,text,numeric,numeric,date,text,numeric,text) from public, anon;
grant execute on function public.employee_get_sale_catalog() to authenticated;
grant execute on function public.employee_create_sale(text,text,numeric,numeric,date,text,numeric,text) to authenticated;

-- Confirma que as funções foram instaladas:
select routine_name, security_type
from information_schema.routines
where routine_schema='public' and routine_name in ('employee_get_sale_catalog','employee_create_sale');
