NOVA CALC - Android Project

Open this folder in Android Studio and build:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The original HTML calculator is included at:
app/src/main/assets/index.html
