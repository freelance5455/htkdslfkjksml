const http = require('http');
const ftp = require('basic-ftp');
const { Readable } = require('stream');
const PORT = 8765;
const MAX_BODY = 15 * 1024 * 1024;

function send(res, status, body) {
  const text = JSON.stringify(body);
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type','Cache-Control':'no-store'});
  res.end(text);
}
function allowedHost(host) {
  if (host === 'localhost' || host.endsWith('.local')) return true;
  const m = host.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (!m || m.slice(1).some(x => Number(x) > 255)) return false;
  const a=+m[1], b=+m[2];
  return a===10 || a===127 || (a===192&&b===168) || (a===172&&b>=16&&b<=31) || (a===169&&b===254);
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let data='', size=0;
    req.on('data',chunk=>{size+=chunk.length;if(size>MAX_BODY){reject(new Error('O pedido é grande demais. Use uma imagem menor que 12 MB.'));req.destroy();return}data+=chunk.toString('utf8')});
    req.on('end',()=>{try{resolve(JSON.parse(data||'{}'))}catch{reject(new Error('Dados inválidos.'))}});
    req.on('error',reject);
  });
}
function validateConnection(c) {
  if (!c || typeof c.host!=='string' || !allowedHost(c.host.trim().toLowerCase())) throw new Error('Use o IP local do Xbox (por exemplo, 192.168.0.25) ou um nome .local.');
  const port=Number(c.port||21); if(!Number.isInteger(port)||port<1||port>65535) throw new Error('Porta FTP inválida.');
  return {host:c.host.trim(),port,user:String(c.user||'anonymous'),password:String(c.password||''),secure:false,timeout:9000};
}
async function withFtp(connection, fn) {
  const client=new ftp.Client(9000); client.ftp.verbose=false;
  try { await client.access(validateConnection(connection)); return await fn(client); }
  finally { client.close(); }
}
function safeRemotePath(p) {
  if(typeof p!=='string'||!p.startsWith('/')||p.includes('\0')) throw new Error('Pasta FTP inválida.');
  const parts=p.split('/'); if(parts.includes('..')) throw new Error('O caminho não pode conter ..');
  return p;
}
const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type'});return res.end()}
  const url=new URL(req.url,'http://127.0.0.1');
  if(req.method==='GET'&&url.pathname==='/health') return send(res,200,{ok:true});
  if(req.method!=='POST') return send(res,404,{error:'Rota não encontrada.'});
  try {
    const body=await readBody(req);
    if(url.pathname==='/api/list') {
      const path=safeRemotePath(body.path||'/');
      const entries=await withFtp(body.connection,c=>c.list(path));
      return send(res,200,{entries:entries.map(e=>({name:e.name,type:e.type===ftp.FileType.Directory?'directory':e.type===ftp.FileType.File?'file':'other',size:e.size,modified:e.modifiedAt?e.modifiedAt.toLocaleString('pt-BR'):''}))});
    }
    if(url.pathname==='/api/upload') {
      const path=safeRemotePath(body.path||'/'); const name=String(body.name||'');
      if(!name||name==='.'||name==='..'||/[\\/\0]/.test(name)) throw new Error('Nome de arquivo inválido.');
      if(typeof body.data!=='string'||body.data.length>14*1024*1024) throw new Error('Imagem inválida ou grande demais.');
      const buffer=Buffer.from(body.data,'base64');
      if(buffer.length>12*1024*1024) throw new Error('Use uma imagem de até 12 MB.');
      const remote=(path==='/'?'':path.replace(/\/$/,''))+'/'+name;
      await withFtp(body.connection,c=>c.uploadFrom(Readable.from(buffer),remote));
      return send(res,200,{ok:true,path:remote});
    }
    return send(res,404,{error:'Rota não encontrada.'});
  } catch(e) { return send(res,400,{error:e.message||'Falha na operação FTP. Confira IP, usuário, senha e se o FTP está ativo no Aurora.'}); }
});
server.listen(PORT,'127.0.0.1',()=>console.log(`Ponte FTP local ativa em http://127.0.0.1:${PORT}`));
