const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const backdrop = $('#modalBackdrop'), modalTitle = $('#modalTitle'), modalContent = $('#modalContent');
let toastTimer;
function toast(message){const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function openModal(title, html){modalTitle.textContent=title;modalContent.innerHTML=html;backdrop.hidden=false;document.body.style.overflow='hidden'}
function closeModal(){backdrop.hidden=true;document.body.style.overflow=''}
$('#closeModal').addEventListener('click',closeModal);
backdrop.addEventListener('click',e=>{if(e.target===backdrop)closeModal()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});

const demo = {
 photos:[
  {name:'IMG_2026_1042.jpg',size:'4.8 MB',kind:'صورة',icon:'▧'},
  {name:'IMG_2026_1042_copy.jpg',size:'4.8 MB',kind:'صورة مشابهة',icon:'▧'},
  {name:'WhatsApp Image 2026-10-12.jpeg',size:'3.2 MB',kind:'صورة',icon:'▧'},
  {name:'WhatsApp Image 2026-10-12 (1).jpeg',size:'3.1 MB',kind:'قد تكون مكررة',icon:'▧'},
  {name:'Screenshot_20261010.png',size:'2.4 MB',kind:'لقطة شاشة',icon:'▧'}
 ],
 videos:[
  {name:'VID_20261020_183011.mp4',size:'1.8 GB',kind:'فيديو كبير',icon:'▶'},
  {name:'Vacation_4K.mp4',size:'940 MB',kind:'فيديو كبير',icon:'▶'},
  {name:'ScreenRecord_20261017.mp4',size:'620 MB',kind:'تسجيل شاشة',icon:'▶'},
  {name:'WhatsApp Video 2026-10-15.mp4',size:'280 MB',kind:'فيديو',icon:'▶'}
 ],
 files:[
  {name:'Download/document_final.pdf',size:'18.2 MB',kind:'مستند',icon:'▤'},
  {name:'Download/document_final (1).pdf',size:'18.2 MB',kind:'قد يكون مكررًا',icon:'▤'},
  {name:'Archive_backup.zip',size:'450 MB',kind:'ملف مضغوط',icon:'▤'},
  {name:'old-project-copy.zip',size:'450 MB',kind:'قد يكون مكررًا',icon:'▤'}
 ]
};
const titles={photos:'الصور المتشابهة',videos:'الفيديوهات الكبيرة',files:'الملفات المكررة'};
function renderFileTool(tool){
 const items=demo[tool]||[];
 const subtitle=tool==='photos'?'عينات توضيحية — لا يتم فحص معرضك تلقائيًا':tool==='videos'?'أمثلة توضيحية لملفات كبيرة':'أمثلة توضيحية لملفات قد تكون مكررة';
 openModal(titles[tool],`<div class="result-summary"><strong>${items.length} عناصر للمعاينة</strong><small>${subtitle}</small></div><div class="notice">هذه نسخة HTML تجريبية. المتصفح لا يمنح الصفحة صلاحية مسح الهاتف بالكامل أو حذف الملفات تلقائيًا. البيانات المعروضة أمثلة وليست نتائج فحص حقيقية.</div><div class="file-list">${items.map((f,i)=>`<label class="file-item"><span class="file-icon">${f.icon}</span><span class="file-info"><strong>${escapeHtml(f.name)}</strong><small>${f.kind}</small></span><span class="file-size">${f.size}</span><input class="select-box" type="checkbox" data-index="${i}" aria-label="تحديد ${escapeHtml(f.name)}"></label>`).join('')}</div><div class="modal-actions"><button id="selectAllBtn">تحديد الكل</button><button class="confirm" id="reviewBtn">مراجعة المحدد</button></div>`);
 $('#selectAllBtn').addEventListener('click',()=>{$$('.select-box',modalContent).forEach(x=>x.checked=true);toast('تم تحديد العناصر المعروضة')});
 $('#reviewBtn').addEventListener('click',()=>{const count=$$('.select-box:checked',modalContent).length;if(!count){toast('حدد عنصرًا واحدًا على الأقل للمراجعة');return}openModal('مراجعة العناصر',`<div class="result-summary"><strong>${count} عناصر محددة</strong><small>لم يتم حذف أي شيء</small></div><p style="font-size:12px;line-height:2;color:var(--muted)">في نسخة أندرويد الكاملة، ستتمكن من فتح الملفات المحددة ومراجعتها قبل حذفها. لا يمكن لنسخة HTML هذه حذف الملفات الفعلية من هاتفك.</p><div class="modal-actions"><button id="backBtn">رجوع</button><button class="confirm" id="doneBtn">تمام</button></div>`);$('#backBtn').onclick=()=>renderFileTool(tool);$('#doneBtn').onclick=()=>{closeModal();toast('تمت المراجعة — لم يتم حذف ملفات')};});
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

function scan(){
 openModal('فحص مساحة الهاتف',`<div class="result-summary"><strong>جاهز لبدء التحليل</strong><small>معاينة واجهة الفحص التجريبية</small></div><div class="file-list"><div class="file-item"><span class="file-icon">▧</span><span class="file-info"><strong>الصور المتشابهة</strong><small>نماذج للمعاينة</small></span><span class="file-size">24 صورة</span></div><div class="file-item"><span class="file-icon">▶</span><span class="file-info"><strong>الفيديوهات الكبيرة</strong><small>نماذج للمعاينة</small></span><span class="file-size">8 ملفات</span></div><div class="file-item"><span class="file-icon">▤</span><span class="file-info"><strong>ملفات قد تكون مكررة</strong><small>تحتاج إلى مراجعة</small></span><span class="file-size">12 ملفًا</span></div></div><div class="notice">الأرقام هنا تجريبية لعرض التصميم. قراءة مساحة التخزين الحقيقية وفحص ملفات الجهاز تحتاجان إلى تطبيق أندرويد بصلاحيات مناسبة.</div><div class="modal-actions"><button class="confirm" id="scanOk">فهمت</button></div>`);
 $('#scanOk').onclick=()=>{closeModal();toast('واجهة الفحص جاهزة للتطوير')};
}
$('#scanBtn').addEventListener('click',scan);
$$('[data-tool]').forEach(btn=>btn.addEventListener('click',()=>{const tool=btn.dataset.tool;if(tool==='contacts')showContacts();else renderFileTool(tool)}));
function showContacts(){
 openModal('جهات الاتصال المكررة',`<div class="result-summary"><strong>نظّم الأسماء بسهولة</strong><small>أدخل بيانات تجريبية لاختبار اكتشاف التكرار</small></div><input class="contact-input" id="contactName" placeholder="اسم جهة الاتصال" maxlength="80"><input class="contact-input" id="contactPhone" placeholder="رقم الهاتف" inputmode="tel" maxlength="30"><div class="modal-actions"><button class="confirm" id="addContact">إضافة للاختبار</button><button id="demoContacts">عرض مثال</button></div><div id="contactResults"></div><div class="notice">هذه الأداة تختبر بيانات تكتبها بنفسك فقط. صفحة HTML لا تستطيع قراءة دفتر الهاتف دون واجهة صلاحيات أصلية في أندرويد.</div>`);
 const contacts=[];
 function draw(){const groups={};contacts.forEach(c=>{const key=c.phone.replace(/\D/g,'');if(key)(groups[key]??=[]).push(c)});const dup=Object.values(groups).filter(g=>g.length>1);$('#contactResults').innerHTML=contacts.length?`<div class="file-list" style="margin-top:14px">${contacts.map(c=>`<div class="file-item"><span class="file-icon">♙</span><span class="file-info"><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.phone)}</small></span></div>`).join('')}</div><div class="result-summary" style="margin-top:12px"><strong>${dup.length} مجموعות כפולות`.replace('مجموعות כפולות','مجموعات مكررة')+`</strong><small>المطابقة حسب رقم الهاتف الذي أدخلته</small></div>`:'<p class="empty-state">أضف اسمين بنفس الرقم لاختبار اكتشاف التكرار.</p>'}
 $('#addContact').onclick=()=>{const name=$('#contactName').value.trim(),phone=$('#contactPhone').value.trim();if(!name||!phone){toast('اكتب الاسم ورقم الهاتف أولًا');return}contacts.push({name,phone});$('#contactName').value='';$('#contactPhone').value='';draw()};
 $('#demoContacts').onclick=()=>{contacts.push({name:'أحمد محمد',phone:'01000000000'},{name:'أحمد محمد (مكرر)',phone:'01000000000'},{name:'مريم',phone:'01111111111'});draw();toast('تمت إضافة مثال تجريبي')};
 draw();
}
$('#settingsBtn').onclick=$('#aboutNav').onclick=()=>openModal('عن CleanNova',`<div class="result-summary"><strong>CleanNova</strong><small>واجهة أولية لتنظيف مساحة الهاتف — إصدار تجريبي</small></div><p style="font-size:12px;color:var(--muted);line-height:2">التطبيق مصمم بالعربية وباتجاه RTL، مع واجهة داكنة بتدرجات بنفسجي وأزرق. يمكن تطويره لاحقًا إلى تطبيق أندرويد فعلي لفحص الصور والفيديوهات والملفات وجهات الاتصال بعد طلب الأذونات المناسبة.</p><div class="notice">لا يحذف هذا النموذج ملفات فعلية، ولا يقرأ بيانات الهاتف، ولا يطلب أذونات أو يرسل بيانات إلى خادم.</div><div class="modal-actions"><button class="confirm" id="aboutClose">إغلاق</button></div>`);$('#aboutClose').onclick=closeModal;

if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
