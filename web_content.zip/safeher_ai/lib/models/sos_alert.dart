class SosAlert {
  final String id;
  final double latitude;
  final double longitude;
  final String locationUrl;
  final String time;
  final String source; // 'manual-sos' | 'voice-threat-detection'
  final String status; // 'activated' | 'cancelled' | 'resolved'

  SosAlert({
    required this.id,
    required this.latitude,
    required this.longitude,
    required this.locationUrl,
    required this.time,
    required this.source,
    required this.status,
  });

  Map<String, dynamic> toMap() {
    return {
      'latitude': latitude,
      'longitude': longitude,
      'locationUrl': locationUrl,
      'time': time,
      'source': source,
      'status': status,
    };
  }

  factory SosAlert.fromMap(String id, Map<dynamic, dynamic> map) {
    return SosAlert(
      id: id,
      latitude: (map['latitude'] as num?)?.toDouble() ?? 0.0,
      longitude: (map['longitude'] as num?)?.toDouble() ?? 0.0,
      locationUrl: map['locationUrl'] ?? '',
      time: map['time'] ?? '',
      source: map['source'] ?? 'manual-sos',
      status: map['status'] ?? 'activated',
    );
  }
}
