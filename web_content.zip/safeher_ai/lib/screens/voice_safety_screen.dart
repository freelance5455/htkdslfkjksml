import 'dart:async';
import 'package:flutter/material.dart';
import '../services/voice_service.dart';
import '../utils/constants.dart';
import 'sos_screen.dart';

class VoiceSafetyScreen extends StatefulWidget {
  const VoiceSafetyScreen({super.key});

  @override
  State<VoiceSafetyScreen> createState() => _VoiceSafetyScreenState();
}

class _VoiceSafetyScreenState extends State<VoiceSafetyScreen> {
  final VoiceService _voiceService = VoiceService();
  String _recognizedWords = '';
  bool _isListening = false;
  String? _detectedDistressPhrase;
  int _countdown = 5;
  Timer? _countdownTimer;
  bool _isCountingDown = false;
  String? _statusMessage;

  @override
  void dispose() {
    _countdownTimer?.cancel();
    _voiceService.stopListening();
    super.dispose();
  }

  void _toggleListening() async {
    if (_isListening) {
      await _voiceService.stopListening();
      setState(() {
        _isListening = false;
        _statusMessage = 'Voice monitoring paused.';
      });
    } else {
      setState(() {
        _recognizedWords = '';
        _detectedDistressPhrase = null;
        _statusMessage = 'Listening for distress keywords...';
      });

      try {
        await _voiceService.startListening(
          onResult: (words) {
            setState(() => _recognizedWords = words);
          },
          onEmergencyDetected: (phrase) {
            _onEmergencyDetected(phrase);
          },
        );
        setState(() => _isListening = true);
      } catch (e) {
        setState(() {
          _isListening = false;
          _statusMessage = 'Microphone error: $e';
        });
      }
    }
  }

  void _onEmergencyDetected(String phrase) {
    if (_isCountingDown) return;
    _voiceService.stopListening();
    setState(() {
      _isListening = false;
      _detectedDistressPhrase = phrase;
      _isCountingDown = true;
      _countdown = 5;
    });

    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_countdown > 1) {
        setState(() => _countdown--);
      } else {
        timer.cancel();
        _triggerSos();
      }
    });
  }

  void _cancelVoiceSos() {
    _countdownTimer?.cancel();
    setState(() {
      _isCountingDown = false;
      _detectedDistressPhrase = null;
      _statusMessage = 'Voice SOS cancelled by user.';
    });
  }

  void _triggerSos() {
    setState(() => _isCountingDown = false);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const SosScreen(
          initialSource: 'voice-threat-detection',
          autoStartCountdown: false, // directly activate
        ),
      ),
    );
  }

  // Academic Simulation Trigger for Demo
  void _simulatePhrase(String phrase) {
    setState(() {
      _recognizedWords = phrase;
    });
    _onEmergencyDetected(phrase);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('AI Voice Safety', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Academic Model Description Badge
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.blue.withOpacity(0.3)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.science_outlined, color: Colors.blueAccent, size: 20),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Engine: Speech Recognition + Rule-Based Emergency Intent Detection (Modular for future BERT/DistilBERT integration)',
                        style: TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              if (_isCountingDown) ...[
                // Emergency Detected Countdown Card
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppConstants.accentAlert.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppConstants.accentAlert, width: 2),
                  ),
                  child: Column(
                    children: [
                      const Icon(Icons.warning, color: AppConstants.accentAlert, size: 48),
                      const SizedBox(height: 12),
                      const Text(
                        'POSSIBLE EMERGENCY DETECTED',
                        style: TextStyle(
                          color: AppConstants.primaryRed,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.0,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Matched phrase: "$_detectedDistressPhrase"',
                        style: const TextStyle(color: Colors.white, fontStyle: FontStyle.italic),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        '$_countdown',
                        style: const TextStyle(color: Colors.white, fontSize: 64, fontWeight: FontWeight.bold),
                      ),
                      const Text(
                        'Activating SOS in seconds...',
                        style: TextStyle(color: AppConstants.textMuted),
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white12,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                        ),
                        onPressed: _cancelVoiceSos,
                        icon: const Icon(Icons.cancel),
                        label: const Text('Cancel Alarm'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),
              ] else ...[
                // Central Microphone Button
                Center(
                  child: GestureDetector(
                    onTap: _toggleListening,
                    child: Container(
                      width: 140,
                      height: 140,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _isListening
                            ? AppConstants.primaryRed.withOpacity(0.25)
                            : AppConstants.cardDark,
                        border: Border.all(
                          color: _isListening ? AppConstants.primaryRed : Colors.white24,
                          width: _isListening ? 3 : 1,
                        ),
                      ),
                      child: Center(
                        child: Icon(
                          _isListening ? Icons.mic : Icons.mic_none,
                          color: _isListening ? AppConstants.primaryRed : Colors.white70,
                          size: 54,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Center(
                  child: Text(
                    _isListening ? 'LISTENING ACTIVELY' : 'TAP MICROPHONE TO LISTEN',
                    style: TextStyle(
                      color: _isListening ? AppConstants.primaryRed : Colors.white,
                      fontSize: 15,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                    ),
                  ),
                ),
                if (_statusMessage != null) ...[
                  const SizedBox(height: 6),
                  Center(
                    child: Text(
                      _statusMessage!,
                      style: const TextStyle(color: AppConstants.textMuted, fontSize: 13),
                    ),
                  ),
                ],
                const SizedBox(height: 24),

                // Live Transcription Box
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppConstants.cardDark,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Live Speech Transcription:',
                        style: TextStyle(color: AppConstants.textMuted, fontSize: 12, fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _recognizedWords.isEmpty
                            ? 'Speak naturally (e.g. "Someone is following me", "Please help", "Danger")...'
                            : _recognizedWords,
                        style: TextStyle(
                          color: _recognizedWords.isEmpty ? Colors.white30 : Colors.white,
                          fontSize: 15,
                          fontStyle: _recognizedWords.isEmpty ? FontStyle.italic : FontStyle.normal,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 24),

                // Academic Mini-Project Demonstration Shortcuts
                const Text(
                  'Academic Demo Simulator (Instant Triggers):',
                  style: TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    ActionChip(
                      backgroundColor: AppConstants.cardDark,
                      label: const Text('Simulate: "Someone is following me"', style: TextStyle(color: Colors.white, fontSize: 12)),
                      onPressed: () => _simulatePhrase('someone is following me, please help'),
                    ),
                    ActionChip(
                      backgroundColor: AppConstants.cardDark,
                      label: const Text('Simulate: "Help me please"', style: TextStyle(color: Colors.white, fontSize: 12)),
                      onPressed: () => _simulatePhrase('help me please emergency'),
                    ),
                    ActionChip(
                      backgroundColor: AppConstants.cardDark,
                      label: const Text('Simulate: "Call police"', style: TextStyle(color: Colors.white, fontSize: 12)),
                      onPressed: () => _simulatePhrase('call police right now'),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                // Monitored Keywords List
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppConstants.cardDark,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Monitored Distress Keywords:',
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        AppConstants.distressKeywords.join(' • '),
                        style: const TextStyle(color: AppConstants.textMuted, fontSize: 12, height: 1.5),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
