import 'package:flutter/material.dart';
import '../models/emergency_contact.dart';
import '../services/firebase_service.dart';
import '../utils/constants.dart';
import '../widgets/contact_card.dart';

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({super.key});

  @override
  State<ContactsScreen> createState() => _ContactsScreenState();
}

class _ContactsScreenState extends State<ContactsScreen> {
  final FirebaseService _firebaseService = FirebaseService();

  void _showAddEditContactDialog({EmergencyContact? existingContact}) {
    final nameController = TextEditingController(text: existingContact?.name ?? '');
    final phoneController = TextEditingController(text: existingContact?.phone ?? '');
    String relationship = existingContact?.relationship ?? 'Mother';
    final formKey = GlobalKey<FormState>();

    const relationshipOptions = [
      'Mother',
      'Father',
      'Sister',
      'Brother',
      'Friend',
      'Guardian',
      'Spouse / Partner',
      'Neighbor',
      'Other',
    ];

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: AppConstants.cardDark,
          title: Text(
            existingContact == null ? 'Add Emergency Contact' : 'Edit Contact',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
          content: Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextFormField(
                    controller: nameController,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Full Name',
                      labelStyle: TextStyle(color: AppConstants.textMuted),
                      prefixIcon: Icon(Icons.person, color: AppConstants.primaryRed),
                    ),
                    validator: (val) => (val == null || val.trim().isEmpty) ? 'Please enter a name' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: phoneController,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Phone Number',
                      hintText: '+91 9876543210',
                      hintStyle: TextStyle(color: Colors.white24),
                      labelStyle: TextStyle(color: AppConstants.textMuted),
                      prefixIcon: Icon(Icons.phone, color: AppConstants.primaryRed),
                    ),
                    validator: (val) {
                      if (val == null || val.trim().isEmpty) return 'Please enter a phone number';
                      if (val.trim().length < 8) return 'Enter a valid 10-digit phone number';
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: relationshipOptions.contains(relationship) ? relationship : relationshipOptions.first,
                    dropdownColor: AppConstants.cardDark,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      labelText: 'Relationship',
                      labelStyle: TextStyle(color: AppConstants.textMuted),
                      prefixIcon: Icon(Icons.family_restroom, color: AppConstants.primaryRed),
                    ),
                    items: relationshipOptions.map((rel) {
                      return DropdownMenuItem<String>(
                        value: rel,
                        child: Text(rel, style: const TextStyle(color: Colors.white)),
                      );
                    }).toList(),
                    onChanged: (val) {
                      if (val != null) {
                        setDialogState(() => relationship = val);
                      }
                    },
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel', style: TextStyle(color: AppConstants.textMuted)),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppConstants.primaryRed),
              onPressed: () async {
                if (!formKey.currentState!.validate()) return;
                Navigator.pop(ctx);
                try {
                  if (existingContact == null) {
                    await _firebaseService.addContact(
                      nameController.text,
                      phoneController.text,
                      relationship,
                    );
                  } else {
                    await _firebaseService.updateContact(
                      existingContact.id,
                      nameController.text,
                      phoneController.text,
                      relationship,
                    );
                  }
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        backgroundColor: AppConstants.safetyGreen,
                        content: Text(existingContact == null ? 'Contact added.' : 'Contact updated.'),
                      ),
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(backgroundColor: AppConstants.accentAlert, content: Text(e.toString())),
                    );
                  }
                }
              },
              child: Text(existingContact == null ? 'Save' : 'Update', style: const TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _confirmDelete(EmergencyContact contact) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppConstants.cardDark,
        title: const Text('Delete Contact', style: TextStyle(color: Colors.white)),
        content: Text(
          'Remove ${contact.name} from your trusted emergency contacts?',
          style: const TextStyle(color: AppConstants.textMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: AppConstants.textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppConstants.accentAlert),
            onPressed: () async {
              Navigator.pop(ctx);
              await _firebaseService.deleteContact(contact.id);
            },
            child: const Text('Delete', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('Emergency Contacts', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppConstants.primaryRed,
        foregroundColor: Colors.white,
        onPressed: () => _showAddEditContactDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Add Contact', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: StreamBuilder<List<EmergencyContact>>(
        stream: _firebaseService.getContactsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppConstants.primaryRed));
          }

          final contacts = snapshot.data ?? [];

          if (contacts.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.05),
                      ),
                      child: const Icon(Icons.people_alt_outlined, size: 54, color: AppConstants.textMuted),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'No Emergency Contacts Yet',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Add your parents, relatives, or trusted friends so you can share your emergency location in one tap.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppConstants.textMuted, fontSize: 13),
                    ),
                    const SizedBox(height: 24),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppConstants.primaryRed,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () => _showAddEditContactDialog(),
                      icon: const Icon(Icons.add),
                      label: const Text('Add First Contact'),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: contacts.length,
            itemBuilder: (context, index) {
              final contact = contacts[index];
              return ContactCard(
                contact: contact,
                onDelete: () => _confirmDelete(contact),
                onEdit: () => _showAddEditContactDialog(existingContact: contact),
              );
            },
          );
        },
      ),
    );
  }
}
