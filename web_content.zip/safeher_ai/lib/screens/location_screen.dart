import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/location_service.dart';
import '../services/sos_service.dart';
import '../utils/constants.dart';

class LocationScreen extends StatefulWidget {
  const LocationScreen({super.key});

  @override
  State<LocationScreen> createState() => _LocationScreenState();
}

class _LocationScreenState extends State<LocationScreen> {
  final LocationService _locationService = LocationService();
  final SosService _sosService = SosService();

  Position? _currentPosition;
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _fetchLocation();
  }

  void _fetchLocation() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      final position = await _locationService.getCurrentLocation();
      setState(() {
        _currentPosition = position;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  void _openGoogleMaps() async {
    if (_currentPosition == null) return;
    final url = _locationService.getGoogleMapsUrl(
      _currentPosition!.latitude,
      _currentPosition!.longitude,
    );
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _shareLocation() async {
    if (_currentPosition == null) return;
    final url = _locationService.getGoogleMapsUrl(
      _currentPosition!.latitude,
      _currentPosition!.longitude,
    );
    await _sosService.shareEmergencyLocation(
      latitude: _currentPosition!.latitude,
      longitude: _currentPosition!.longitude,
      locationUrl: url,
    );
  }

  void _copyLocationLink() {
    if (_currentPosition == null) return;
    final url = _locationService.getGoogleMapsUrl(
      _currentPosition!.latitude,
      _currentPosition!.longitude,
    );
    Clipboard.setData(ClipboardData(text: url));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        backgroundColor: AppConstants.safetyGreen,
        content: Text('Google Maps link copied to clipboard!'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('Live Location & GPS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Header Card
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppConstants.cardDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppConstants.safetyGreen.withOpacity(0.15),
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.my_location, color: AppConstants.safetyGreen, size: 36),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Live GPS Coordinate System',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 6),
                    const Text(
                      'Precise satellite fix formatted for emergency dispatch and trusted contact sharing.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppConstants.textMuted, fontSize: 13),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Location Data Card
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppConstants.cardDark,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: _isLoading
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CircularProgressIndicator(color: AppConstants.primaryRed),
                              SizedBox(height: 16),
                              Text('Acquiring satellite GPS fix...', style: TextStyle(color: Colors.white70)),
                            ],
                          ),
                        )
                      : _errorMessage != null
                          ? Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  const Icon(Icons.location_off, color: AppConstants.accentAlert, size: 48),
                                  const SizedBox(height: 12),
                                  Text(
                                    _errorMessage!,
                                    textAlign: TextAlign.center,
                                    style: const TextStyle(color: Colors.white70),
                                  ),
                                  const SizedBox(height: 16),
                                  ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(backgroundColor: AppConstants.primaryRed),
                                    onPressed: _fetchLocation,
                                    icon: const Icon(Icons.refresh, size: 16),
                                    label: const Text('Try Again', style: TextStyle(color: Colors.white)),
                                  ),
                                ],
                              ),
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text('STATUS: ACTIVE GPS FIX',
                                        style: TextStyle(
                                            color: AppConstants.safetyGreen,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 12,
                                            letterSpacing: 1.0)),
                                    IconButton(
                                      icon: const Icon(Icons.refresh, color: AppConstants.textMuted),
                                      onPressed: _fetchLocation,
                                      tooltip: 'Refresh GPS',
                                    ),
                                  ],
                                ),
                                const Divider(color: Colors.white10),
                                const SizedBox(height: 12),
                                _buildDataRow('Latitude', '${_currentPosition?.latitude.toStringAsFixed(6)}° N'),
                                const SizedBox(height: 10),
                                _buildDataRow('Longitude', '${_currentPosition?.longitude.toStringAsFixed(6)}° E'),
                                const SizedBox(height: 10),
                                _buildDataRow('Accuracy', '± ${_currentPosition?.accuracy.toStringAsFixed(1)} meters'),
                                const SizedBox(height: 16),
                                const Text(
                                  'Google Maps URL:',
                                  style: TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, fontSize: 13),
                                ),
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: Colors.black26,
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: SelectableText(
                                    _locationService.getGoogleMapsUrl(
                                      _currentPosition!.latitude,
                                      _currentPosition!.longitude,
                                    ),
                                    style: const TextStyle(color: Colors.blueAccent, fontSize: 12),
                                  ),
                                ),
                                const Spacer(),
                                Row(
                                  children: [
                                    Expanded(
                                      child: OutlinedButton.icon(
                                        style: OutlinedButton.styleFrom(
                                          foregroundColor: Colors.white,
                                          side: const BorderSide(color: Colors.white24),
                                          padding: const EdgeInsets.symmetric(vertical: 14),
                                        ),
                                        onPressed: _copyLocationLink,
                                        icon: const Icon(Icons.copy, size: 16),
                                        label: const Text('Copy Link'),
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Expanded(
                                      child: ElevatedButton.icon(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: AppConstants.primaryRed,
                                          foregroundColor: Colors.white,
                                          padding: const EdgeInsets.symmetric(vertical: 14),
                                        ),
                                        onPressed: _shareLocation,
                                        icon: const Icon(Icons.share, size: 16),
                                        label: const Text('Share Live'),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 10),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton.icon(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue.shade700,
                                      foregroundColor: Colors.white,
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                    ),
                                    onPressed: _openGoogleMaps,
                                    icon: const Icon(Icons.map, size: 16),
                                    label: const Text('Open in Google Maps App'),
                                  ),
                                ),
                              ],
                            ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDataRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: AppConstants.textMuted, fontSize: 14)),
        Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
      ],
    );
  }
}
