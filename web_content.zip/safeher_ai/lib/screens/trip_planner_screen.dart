import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../utils/constants.dart';

class TripPlannerScreen extends StatefulWidget {
  const TripPlannerScreen({super.key});

  @override
  State<TripPlannerScreen> createState() => _TripPlannerScreenState();
}

class _TripPlannerScreenState extends State<TripPlannerScreen> {
  final _destinationController = TextEditingController(text: 'Visakhapatnam Railway Station');
  String _travelTime = 'Late Night';
  String _travellingWith = 'Alone';

  List<Map<String, dynamic>> _checklist = [];
  bool _generated = false;

  final List<String> _timeOptions = ['Daytime', 'Evening', 'Late Night'];
  final List<String> _companionOptions = ['Alone', 'With someone'];

  @override
  void initState() {
    super.initState();
    _generateChecklist();
  }

  @override
  void dispose() {
    _destinationController.dispose();
    super.dispose();
  }

  void _generateChecklist() {
    final destination = _destinationController.text.trim().isEmpty ? 'Destination' : _destinationController.text.trim();
    final isLateNight = _travelTime == 'Late Night';
    final isAlone = _travellingWith == 'Alone';

    final List<String> items = [
      'Share your destination ($destination) with trusted contact',
      'Share live GPS location with emergency contact before departure',
      'Keep mobile phone charged above 60% and carry a power bank',
    ];

    if (isLateNight) {
      items.add('Stick strictly to well-lit main arterial routes; avoid quiet shortcuts');
      items.add('Avoid boarding empty compartments, buses, or unregistered cabs');
      items.add('Keep emergency numbers (112, 100) on speed dial');
      items.add('Stay alert: do not wear noise-cancelling headphones while walking');
    } else {
      items.add('Verify public transit timings and track licensed vehicle plate numbers');
      items.add('Keep your bag zipped and carry money/cards in separate pockets');
    }

    if (isAlone) {
      items.add('Schedule check-in calls with family every 30-45 minutes');
      items.add('Note down local emergency kiosk or petrol pump checkpoints');
      items.add('Have SafeHer AI Voice Safety or SOS active on your phone');
    } else {
      items.add('Agree on an emergency meetup point with your travel companion');
      items.add('Ensure both phones have working internet and emergency contacts saved');
    }

    items.add('Carry valid photo identification and emergency medical details');

    setState(() {
      _checklist = items.map((e) => {'text': e, 'checked': false}).toList();
      _generated = true;
    });
  }

  String _formatChecklistText() {
    final dest = _destinationController.text;
    final buffer = StringBuffer();
    buffer.writeln('📋 SafeHer AI - Smart Trip Safety Checklist');
    buffer.writeln('📍 Destination: $dest');
    buffer.writeln('⏰ Timing: $_travelTime | Companion: $_travellingWith');
    buffer.writeln('----------------------------------------');
    for (var item in _checklist) {
      final mark = item['checked'] == true ? '✅' : '⬜';
      buffer.writeln('$mark ${item['text']}');
    }
    buffer.writeln('----------------------------------------');
    buffer.writeln('Generated via SafeHer AI Safety Planner.');
    return buffer.toString();
  }

  void _copyChecklist() {
    Clipboard.setData(ClipboardData(text: _formatChecklistText()));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        backgroundColor: AppConstants.safetyGreen,
        content: Text('Safety checklist copied to clipboard!'),
      ),
    );
  }

  void _shareChecklist() {
    Share.share(
      _formatChecklistText(),
      subject: 'Trip Safety Checklist: ${_destinationController.text}',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('Trip Safety Planner', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Planner Configuration Card
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: AppConstants.cardDark,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Trip Details',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    const SizedBox(height: 14),

                    // Destination input
                    TextField(
                      controller: _destinationController,
                      style: const TextStyle(color: Colors.white),
                      decoration: const InputDecoration(
                        labelText: 'Destination',
                        hintText: 'e.g. City Bus Station, College Campus',
                        labelStyle: TextStyle(color: AppConstants.textMuted),
                        prefixIcon: Icon(Icons.place, color: AppConstants.primaryRed),
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Travel Time
                    Row(
                      children: [
                        const Icon(Icons.access_time, color: AppConstants.primaryRed, size: 20),
                        const SizedBox(width: 8),
                        const Text('Travel Time:', style: TextStyle(color: AppConstants.textMuted, fontSize: 13)),
                        const Spacer(),
                        DropdownButton<String>(
                          value: _travelTime,
                          dropdownColor: AppConstants.cardDark,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                          items: _timeOptions.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(),
                          onChanged: (val) {
                            if (val != null) setState(() => _travelTime = val);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),

                    // Travelling With
                    Row(
                      children: [
                        const Icon(Icons.people_outline, color: AppConstants.primaryRed, size: 20),
                        const SizedBox(width: 8),
                        const Text('Travelling:', style: TextStyle(color: AppConstants.textMuted, fontSize: 13)),
                        const Spacer(),
                        DropdownButton<String>(
                          value: _travellingWith,
                          dropdownColor: AppConstants.cardDark,
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                          items: _companionOptions.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                          onChanged: (val) {
                            if (val != null) setState(() => _travellingWith = val);
                          },
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppConstants.primaryRed,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: _generateChecklist,
                        icon: const Icon(Icons.checklist, size: 18),
                        label: const Text('Generate Tailored Checklist', style: TextStyle(fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Checklist Output Card
              if (_generated) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Trip Safety Checklist',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                    Row(
                      children: [
                        IconButton(
                          icon: const Icon(Icons.copy, color: AppConstants.textMuted, size: 20),
                          tooltip: 'Copy Checklist',
                          onPressed: _copyChecklist,
                        ),
                        IconButton(
                          icon: const Icon(Icons.share, color: AppConstants.primaryRed, size: 20),
                          tooltip: 'Share Checklist',
                          onPressed: _shareChecklist,
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 8),

                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppConstants.cardDark,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Column(
                    children: _checklist.map((item) {
                      final bool isDone = item['checked'] == true;
                      return CheckboxListTile(
                        value: isDone,
                        contentPadding: EdgeInsets.zero,
                        activeColor: AppConstants.safetyGreen,
                        checkColor: Colors.white,
                        title: Text(
                          item['text'],
                          style: TextStyle(
                            color: isDone ? Colors.white38 : Colors.white,
                            fontSize: 13,
                            decoration: isDone ? TextDecoration.lineThrough : null,
                          ),
                        ),
                        onChanged: (val) {
                          setState(() {
                            item['checked'] = val ?? false;
                          });
                        },
                      );
                    }).toList(),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
