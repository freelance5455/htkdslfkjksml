import 'package:flutter/material.dart';
import '../utils/constants.dart';

class TipItem {
  final String title;
  final String description;
  final IconData icon;

  TipItem({required this.title, required this.description, required this.icon});
}

class SafetyTipsScreen extends StatelessWidget {
  const SafetyTipsScreen({super.key});

  final Map<String, List<TipItem>> _categorizedTips = const {
    'Personal Safety': [
      TipItem(
        title: 'Trust Your Intuition',
        description: 'If someone makes you feel uncomfortable or a situation feels wrong, remove yourself immediately without worrying about politeness.',
        icon: Icons.psychology,
      ),
      TipItem(
        title: 'Situational Awareness',
        description: 'Keep your eyes up and observe people around you. Avoid keeping both ears plugged with headphones in public.',
        icon: Icons.visibility,
      ),
      TipItem(
        title: 'Emergency Contacts Ready',
        description: 'Ensure at least two close relatives or trusted friends are saved in your SafeHer AI emergency contacts.',
        icon: Icons.quick_contacts_dialer,
      ),
    ],
    'Night Travel': [
      TipItem(
        title: 'Stick to Illuminated Streets',
        description: 'Always prefer well-lit main thoroughfares with active storefronts or security checkpoints over shortcuts.',
        icon: Icons.lightbulb,
      ),
      TipItem(
        title: 'Share Live Journey',
        description: 'Before beginning a late night walk or ride, share your GPS link with family and send regular milestone updates.',
        icon: Icons.navigation,
      ),
      TipItem(
        title: 'Keep Keys & Phone in Hand',
        description: 'Have your keys and phone easily accessible before reaching your car, house, or apartment entrance.',
        icon: Icons.vpn_key,
      ),
    ],
    'Travel & Transit': [
      TipItem(
        title: 'Verify Cab Details',
        description: 'Always match the vehicle license plate, driver face, and model with your ride-hailing app before getting in.',
        icon: Icons.local_taxi,
      ),
      TipItem(
        title: 'Avoid Empty Compartments',
        description: 'On trains or metros at off-peak hours, select coaches with families or other female passengers near the driver/guard cabin.',
        icon: Icons.train,
      ),
      TipItem(
        title: 'Pre-book Trusted Transport',
        description: 'Whenever possible, pre-arrange rides from certified stands or registered taxi dispatchers.',
        icon: Icons.directions_car,
      ),
    ],
    'Digital Safety': [
      TipItem(
        title: 'Delayed Social Sharing',
        description: 'Avoid posting real-time location check-ins on social media. Post photos and stories after leaving the venue.',
        icon: Icons.security,
      ),
      TipItem(
        title: 'Phone Battery Reserve',
        description: 'Never leave home with low battery. Carry a portable battery pack and keep emergency power-saving mode enabled.',
        icon: Icons.battery_charging_full,
      ),
      TipItem(
        title: 'Protect Personal Information',
        description: 'Do not discuss your address, daily travel schedule, or hotel room number in audible public conversations.',
        icon: Icons.lock,
      ),
    ],
    'Emergency Action': [
      TipItem(
        title: 'Know the 112 Unified Helpline',
        description: '112 connects to police, ambulance, and fire services nationwide. Memorize it and practice one-tap dialing.',
        icon: Icons.emergency,
      ),
      TipItem(
        title: 'Voice Distress Activation',
        description: 'Remember you can trigger SafeHer AI hands-free by speaking phrases like "Someone is following me" or "Please help".',
        icon: Icons.mic,
      ),
      TipItem(
        title: 'Loud Distraction Techniques',
        description: 'Yelling "FIRE" or using a shrill personal alarm often gets faster immediate bystander response than quiet resistance.',
        icon: Icons.volume_up,
      ),
    ],
  };

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: _categorizedTips.keys.length,
      child: Scaffold(
        backgroundColor: AppConstants.surfaceDark,
        appBar: AppBar(
          title: const Text('Safety Tips & Guidelines', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          backgroundColor: Colors.transparent,
          elevation: 0,
          iconTheme: const IconThemeData(color: Colors.white),
          bottom: TabBar(
            isScrollable: true,
            tabAlignment: TabAlignment.start,
            indicatorColor: AppConstants.primaryRed,
            labelColor: AppConstants.primaryRed,
            unselectedLabelColor: AppConstants.textMuted,
            indicatorWeight: 3,
            tabs: _categorizedTips.keys.map((cat) => Tab(text: cat)).toList(),
          ),
        ),
        body: TabBarView(
          children: _categorizedTips.values.map((tips) {
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: tips.length,
              itemBuilder: (context, index) {
                final tip = tips[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: AppConstants.cardDark,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: AppConstants.primaryRed.withOpacity(0.14),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(tip.icon, color: AppConstants.primaryRed, size: 22),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              tip.title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              tip.description,
                              style: const TextStyle(
                                color: AppConstants.textMuted,
                                fontSize: 13,
                                height: 1.4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          }).toList(),
        ),
      ),
    );
  }
}
