import 'package:flutter/material.dart';
import '../services/firebase_service.dart';
import '../utils/constants.dart';
import '../utils/emergency_numbers.dart';
import '../widgets/emergency_service_card.dart';
import '../widgets/feature_card.dart';
import '../widgets/sos_button.dart';
import 'ai_copilot_screen.dart';
import 'contacts_screen.dart';
import 'instructions_screen.dart';
import 'location_screen.dart';
import 'profile_screen.dart';
import 'safety_tips_screen.dart';
import 'sos_history_screen.dart';
import 'sos_screen.dart';
import 'trip_planner_screen.dart';
import 'voice_safety_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  String _userName = 'User';
  final FirebaseService _firebaseService = FirebaseService();

  @override
  void initState() {
    super.initState();
    _loadUserName();
  }

  void _loadUserName() async {
    final name = await _firebaseService.getUserName();
    if (mounted) setState(() => _userName = name);
  }

  Widget _buildHomeDashboard() {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Greeting Header
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Hello, $_userName',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 2),
                  const Text(
                    'Stay Safe. Stay Connected.',
                    style: TextStyle(
                      color: AppConstants.primaryRed,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              IconButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const InstructionsScreen()),
                  );
                },
                icon: const Icon(Icons.info_outline, color: AppConstants.textMuted),
                tooltip: 'How it works',
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Central Prominent SOS Button
          Center(
            child: SosButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SosScreen(initialSource: 'manual-sos')),
                );
              },
            ),
          ),
          const SizedBox(height: 32),

          // Emergency Services Section
          const Text(
            'Emergency Services',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 2.2,
            ),
            itemCount: 4,
            itemBuilder: (context, index) {
              return EmergencyServiceCard(service: EmergencyNumbers.services[index]);
            },
          ),
          const SizedBox(height: 28),

          // Quick Safety Tools Section
          const Text(
            'Quick Safety Tools',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 14),

          FeatureCard(
            icon: Icons.my_location,
            title: 'Share My Location',
            description: 'Get live GPS coordinates & share Google Maps link',
            accentColor: AppConstants.safetyGreen,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const LocationScreen()));
            },
          ),
          const SizedBox(height: 10),

          FeatureCard(
            icon: Icons.mic_none,
            title: 'AI Voice Safety',
            description: 'Hands-free voice recognition with emergency trigger',
            accentColor: AppConstants.primaryRed,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const VoiceSafetyScreen()));
            },
          ),
          const SizedBox(height: 10),

          FeatureCard(
            icon: Icons.psychology,
            title: 'AI Safety Copilot',
            description: 'Conversational situational safety recommendations',
            accentColor: Colors.purpleAccent,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const AiCopilotScreen()));
            },
          ),
          const SizedBox(height: 10),

          FeatureCard(
            icon: Icons.route,
            title: 'Smart Trip Safety Planner',
            description: 'Checklist tailored for your destination & travel timing',
            accentColor: Colors.blueAccent,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const TripPlannerScreen()));
            },
          ),
          const SizedBox(height: 10),

          FeatureCard(
            icon: Icons.contacts,
            title: 'Emergency Contacts',
            description: 'Manage trusted contacts for immediate alert sharing',
            accentColor: Colors.amber,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactsScreen()));
            },
          ),
          const SizedBox(height: 10),

          FeatureCard(
            icon: Icons.history,
            title: 'SOS History',
            description: 'Review previous emergency alerts and location timestamps',
            accentColor: Colors.tealAccent,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const SosHistoryScreen()));
            },
          ),
          const SizedBox(height: 10),

          FeatureCard(
            icon: Icons.lightbulb_outline,
            title: 'Safety Tips & Best Practices',
            description: 'Night transit, personal and digital defense tips',
            accentColor: Colors.orangeAccent,
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (_) => const SafetyTipsScreen()));
            },
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // 5 Main Tabs
    final List<Widget> tabs = [
      _buildHomeDashboard(),
      const SosScreen(initialSource: 'manual-sos'),
      const ContactsScreen(),
      const AiCopilotScreen(),
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      body: SafeArea(child: tabs[_currentIndex]),
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          backgroundColor: AppConstants.cardDark,
          indicatorColor: AppConstants.primaryRed.withOpacity(0.2),
          labelTextStyle: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return const TextStyle(
                color: AppConstants.primaryRed,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              );
            }
            return const TextStyle(
              color: AppConstants.textMuted,
              fontSize: 12,
              fontWeight: FontWeight.w500,
            );
          }),
          iconTheme: WidgetStateProperty.resolveWith((states) {
            if (states.contains(WidgetState.selected)) {
              return const IconThemeData(color: AppConstants.primaryRed);
            }
            return const IconThemeData(color: AppConstants.textMuted);
          }),
        ),
        child: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: (idx) => setState(() => _currentIndex = idx),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.emergency_outlined), selectedIcon: Icon(Icons.emergency), label: 'SOS'),
            NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Contacts'),
            NavigationDestination(icon: Icon(Icons.psychology_outlined), selectedIcon: Icon(Icons.psychology), label: 'AI Copilot'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
          ],
        ),
      ),
    );
  }
}
