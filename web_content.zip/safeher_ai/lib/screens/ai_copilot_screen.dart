import 'package:flutter/material.dart';
import '../utils/constants.dart';

class ChatMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  final List<String>? actionPoints;

  ChatMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
    this.actionPoints,
  });
}

class AiCopilotScreen extends StatefulWidget {
  const AiCopilotScreen({super.key});

  @override
  State<AiCopilotScreen> createState() => _AiCopilotScreenState();
}

class _AiCopilotScreenState extends State<AiCopilotScreen> {
  final List<ChatMessage> _messages = [];
  final TextEditingController _inputController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  final List<String> _suggestedPrompts = [
    'Someone is following me',
    'I feel unsafe walking alone',
    'I am travelling alone at night',
    'Emergency help numbers',
  ];

  @override
  void initState() {
    super.initState();
    _messages.add(
      ChatMessage(
        text:
            'Hello! I am your SafeHer AI Safety Copilot. If you feel uneasy, tell me your current situation or select a quick option below. In case of immediate life threat, tap SOS or call 112.',
        isUser: false,
        timestamp: DateTime.now(),
        actionPoints: [
          'Immediate physical danger? Use the SOS button at once.',
          'Suspicious behavior around you? Head toward populated public spots.',
        ],
      ),
    );
  }

  @override
  void dispose() {
    _inputController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _sendMessage(String query) {
    if (query.trim().isEmpty) return;

    final userMessage = ChatMessage(
      text: query.trim(),
      isUser: true,
      timestamp: DateTime.now(),
    );

    setState(() {
      _messages.add(userMessage);
    });
    _inputController.clear();
    _scrollToBottom();

    // Generate Rule-Based Safety Guidance Response
    final botResponse = _generateSafetyGuidance(query.trim());

    Future.delayed(const Duration(milliseconds: 400), () {
      if (mounted) {
        setState(() {
          _messages.add(botResponse);
        });
        _scrollToBottom();
      }
    });
  }

  ChatMessage _generateSafetyGuidance(String input) {
    final lower = input.toLowerCase();

    // 1. Following / Stalking
    if (lower.contains('follow') || lower.contains('stalk') || lower.contains('behind me')) {
      return ChatMessage(
        text: 'Action Guidance: Potential Following or Stalking detected.',
        isUser: false,
        timestamp: DateTime.now(),
        actionPoints: [
          'Change direction immediately and move toward a well-lit, crowded store or restaurant.',
          'Do NOT go directly to your home or into isolated lanes/parking areas.',
          'Call a trusted friend or family member and speak loudly about your exact location.',
          'If the person continues to follow, enter a public facility and inform security or dial Police (100).',
          'Use SafeHer AI "Share My Location" to alert your contacts.',
        ],
      );
    }

    // 2. Assault / Immediate Danger
    if (lower.contains('danger') || lower.contains('attack') || lower.contains('threat') || lower.contains('assault')) {
      return ChatMessage(
        text: 'CRITICAL ALERT: Potential Immediate Threat',
        isUser: false,
        timestamp: DateTime.now(),
        actionPoints: [
          'Trigger SafeHer AI 5-second SOS immediately from the top bar.',
          'Call 112 (National Emergency Helpline) or 100 (Police).',
          'Make loud noise, yell "HELP" or "FIRE" to attract nearby public attention.',
          'Look for open commercial establishments, security kiosks, or petrol pumps.',
        ],
      );
    }

    // 3. Night Travel
    if (lower.contains('night') || lower.contains('dark') || lower.contains('alone') || lower.contains('walk')) {
      return ChatMessage(
        text: 'Safety Guidelines for Solo Night Travel:',
        isUser: false,
        timestamp: DateTime.now(),
        actionPoints: [
          'Keep your phone charged and easily accessible (not buried deep in your bag).',
          'Avoid using two earbuds; keep one ear free to stay alert to ambient surroundings.',
          'Stay strictly on illuminated main roads even if a shortcut is faster.',
          'Share your live trip progress via the "Trip Safety Planner".',
          'Avoid empty cab or auto stops; prefer verified app-based transportation.',
        ],
      );
    }

    // 4. Emergency Numbers
    if (lower.contains('number') || lower.contains('helpline') || lower.contains('emergency') || lower.contains('police')) {
      return ChatMessage(
        text: 'Official Emergency Response Helplines:',
        isUser: false,
        timestamp: DateTime.now(),
        actionPoints: [
          'National Emergency: 112 (Integrated police, medical & fire)',
          'Police Control: 100',
          'Ambulance / Medical: 108',
          'Fire Service: 101',
          'Women Safety Helpline: 1091 (24/7 dedicated support)',
        ],
      );
    }

    // 5. Default / General Safety
    return ChatMessage(
      text: 'SafeHer AI General Safety Recommendation:',
      isUser: false,
      timestamp: DateTime.now(),
      actionPoints: [
        'Trust your intuition: if a place or person feels unsafe, leave immediately.',
        'Keep trusted emergency contacts updated with your current whereabouts.',
        'Never disclose sensitive personal details or real-time hotel/room numbers to strangers.',
        'Check that SafeHer AI location permission is enabled for prompt SOS dispatch.',
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('AI Safety Copilot', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Suggested chips
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: _suggestedPrompts.map((prompt) {
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      backgroundColor: AppConstants.cardDark,
                      label: Text(prompt, style: const TextStyle(color: Colors.white, fontSize: 12)),
                      onPressed: () => _sendMessage(prompt),
                    ),
                  );
                }).toList(),
              ),
            ),

            // Messages List
            Expanded(
              child: ListView.builder(
                controller: _scrollController,
                padding: const EdgeInsets.all(16),
                itemCount: _messages.length,
                itemBuilder: (context, index) {
                  final msg = _messages[index];
                  return _buildMessageBubble(msg);
                },
              ),
            ),

            // Input Bar
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppConstants.cardDark,
                border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08))),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _inputController,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'Describe your situation or concern...',
                        hintStyle: const TextStyle(color: AppConstants.textMuted, fontSize: 13),
                        filled: true,
                        fillColor: Colors.black26,
                        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide.none,
                        ),
                      ),
                      onSubmitted: _sendMessage,
                    ),
                  ),
                  const SizedBox(width: 8),
                  CircleAvatar(
                    backgroundColor: AppConstants.primaryRed,
                    child: IconButton(
                      icon: const Icon(Icons.send, color: Colors.white, size: 18),
                      onPressed: () => _sendMessage(_inputController.text),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMessageBubble(ChatMessage msg) {
    return Align(
      alignment: msg.isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.85),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: msg.isUser ? AppConstants.primaryRed : AppConstants.cardDark,
          borderRadius: BorderRadius.circular(16),
          border: msg.isUser ? null : Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              msg.text,
              style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.4),
            ),
            if (msg.actionPoints != null && msg.actionPoints!.isNotEmpty) ...[
              const SizedBox(height: 10),
              ...msg.actionPoints!.map(
                (point) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('✓ ', style: TextStyle(color: AppConstants.safetyGreen, fontWeight: FontWeight.bold)),
                      Expanded(
                        child: Text(
                          point,
                          style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.3),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
