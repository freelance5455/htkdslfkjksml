import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/sos_alert.dart';
import '../services/firebase_service.dart';
import '../utils/constants.dart';

class SosHistoryScreen extends StatelessWidget {
  const SosHistoryScreen({super.key});

  void _openMap(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    final FirebaseService firebaseService = FirebaseService();

    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('SOS Alert History', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: StreamBuilder<List<SosAlert>>(
        stream: firebaseService.getSosAlertsStream(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: AppConstants.primaryRed));
          }

          final alerts = snapshot.data ?? [];

          if (alerts.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white.withOpacity(0.05),
                      ),
                      child: const Icon(Icons.history_toggle_off, size: 54, color: AppConstants.textMuted),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'No SOS Alerts Recorded',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'When an SOS is activated either manually or via voice threat detection, the log with coordinates will appear here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppConstants.textMuted, fontSize: 13),
                    ),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: alerts.length,
            itemBuilder: (context, index) {
              final alert = alerts[index];

              DateTime? parsedDate;
              try {
                parsedDate = DateTime.parse(alert.time);
              } catch (_) {}

              final dateStr = parsedDate != null
                  ? DateFormat('dd MMM yyyy').format(parsedDate)
                  : 'Recent';
              final timeStr = parsedDate != null
                  ? DateFormat('hh:mm a').format(parsedDate)
                  : '';

              final isVoice = alert.source == 'voice-threat-detection';

              return Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppConstants.cardDark,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.08)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppConstants.primaryRed.withOpacity(0.18),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                children: [
                                  Icon(
                                    isVoice ? Icons.mic : Icons.warning_amber,
                                    color: AppConstants.primaryRed,
                                    size: 14,
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    isVoice ? 'Voice Detection' : 'Manual SOS',
                                    style: const TextStyle(
                                      color: AppConstants.primaryRed,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 11,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: AppConstants.safetyGreen.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                alert.status.toUpperCase(),
                                style: const TextStyle(
                                  color: AppConstants.safetyGreen,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text(
                          '$dateStr $timeStr',
                          style: const TextStyle(color: AppConstants.textMuted, fontSize: 11),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (alert.latitude != 0.0 && alert.longitude != 0.0) ...[
                      Text(
                        'Coordinates: ${alert.latitude.toStringAsFixed(5)}, ${alert.longitude.toStringAsFixed(5)}',
                        style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w500),
                      ),
                    ] else ...[
                      const Text(
                        'Location: Registered without GPS fix',
                        style: TextStyle(color: AppConstants.textMuted, fontSize: 13),
                      ),
                    ],
                    const SizedBox(height: 12),
                    if (alert.locationUrl.startsWith('http')) ...[
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          style: TextButton.styleFrom(
                            foregroundColor: Colors.blueAccent,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                          ),
                          onPressed: () => _openMap(alert.locationUrl),
                          icon: const Icon(Icons.open_in_new, size: 14),
                          label: const Text('View Location on Google Maps', style: TextStyle(fontSize: 12)),
                        ),
                      ),
                    ],
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}
