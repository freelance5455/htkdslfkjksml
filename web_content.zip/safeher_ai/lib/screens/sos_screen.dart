import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/sos_service.dart';
import '../utils/constants.dart';
import '../utils/emergency_numbers.dart';
import '../widgets/emergency_service_card.dart';

class SosScreen extends StatefulWidget {
  final String initialSource; // 'manual-sos' | 'voice-threat-detection'
  final bool autoStartCountdown;

  const SosScreen({
    super.key,
    this.initialSource = 'manual-sos',
    this.autoStartCountdown = false,
  });

  @override
  State<SosScreen> createState() => _SosScreenState();
}

enum SosState { idle, countingDown, activating, activated, cancelled }

class _SosScreenState extends State<SosScreen> {
  SosState _state = SosState.idle;
  int _countdown = 5;
  Timer? _countdownTimer;

  final SosService _sosService = SosService();

  double? _latitude;
  double? _longitude;
  String? _locationUrl;
  String? _activatedTime;
  String? _alertId;
  String _source = 'manual-sos';
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _source = widget.initialSource;
    if (widget.autoStartCountdown) {
      _startCountdown();
    }
  }

  @override
  void dispose() {
    _countdownTimer?.cancel();
    super.dispose();
  }

  void _startCountdown() {
    setState(() {
      _state = SosState.countingDown;
      _countdown = 5;
      _errorMessage = null;
    });

    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_countdown > 1) {
        setState(() => _countdown--);
      } else {
        timer.cancel();
        _activateSos();
      }
    });
  }

  void _cancelSos() {
    _countdownTimer?.cancel();
    setState(() {
      _state = SosState.cancelled;
    });
  }

  void _activateSos() async {
    setState(() {
      _state = SosState.activating;
    });

    try {
      final result = await _sosService.activateSos(source: _source);
      setState(() {
        _latitude = result['latitude'];
        _longitude = result['longitude'];
        _locationUrl = result['locationUrl'];
        _activatedTime = result['time'];
        _alertId = result['alertId'];
        _state = SosState.activated;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _state = SosState.activated; // still show activated status with error notice
      });
    }
  }

  void _shareLocation() async {
    if (_locationUrl == null) return;
    await _sosService.shareEmergencyLocation(
      latitude: _latitude ?? 0.0,
      longitude: _longitude ?? 0.0,
      locationUrl: _locationUrl!,
    );
  }

  void _openGoogleMaps() async {
    if (_locationUrl == null) return;
    final uri = Uri.parse(_locationUrl!);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Widget _buildCountingDownView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppConstants.accentAlert.withOpacity(0.18),
              border: Border.all(color: AppConstants.accentAlert, width: 3),
            ),
            child: Text(
              '$_countdown',
              style: const TextStyle(
                fontSize: 84,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
          ),
          const SizedBox(height: 28),
          const Text(
            'SOS ACTIVATION IN PROGRESS',
            style: TextStyle(
              color: AppConstants.primaryRed,
              fontSize: 18,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Acquiring GPS location and alerting Firebase.\nTap Cancel immediately if this was accidental.',
            textAlign: TextAlign.center,
            style: TextStyle(color: AppConstants.textMuted, fontSize: 14),
          ),
          const SizedBox(height: 48),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.white12,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 16),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: _cancelSos,
            icon: const Icon(Icons.close, size: 22),
            label: const Text('Cancel SOS', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  Widget _buildActivatingView() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(color: AppConstants.primaryRed, strokeWidth: 3),
          SizedBox(height: 24),
          Text(
            'Locking GPS & Logging to Firebase...',
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _buildActivatedView() {
    final formattedTime = _activatedTime != null
        ? DateFormat('dd MMM yyyy, hh:mm a').format(DateTime.parse(_activatedTime!))
        : 'Just now';

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Alert Banner
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFDC2626), Color(0xFF991B1B)],
              ),
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: AppConstants.accentAlert.withOpacity(0.4),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              children: [
                const Icon(Icons.warning_amber_rounded, color: Colors.white, size: 48),
                const SizedBox(height: 8),
                const Text(
                  'SOS ACTIVATED',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Source: ${_source == "voice-threat-detection" ? "Voice Distress Trigger" : "Manual SOS Button"}',
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
                Text(
                  'Time: $formattedTime',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Location Details Card
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppConstants.cardDark,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Row(
                  children: [
                    Icon(Icons.location_on, color: AppConstants.primaryRed, size: 20),
                    SizedBox(width: 8),
                    Text(
                      'Recorded Emergency Location',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                if (_latitude != null && _longitude != null && _latitude != 0.0) ...[
                  Text(
                    'Latitude: ${_latitude!.toStringAsFixed(6)}',
                    style: const TextStyle(color: AppConstants.textMuted, fontSize: 13),
                  ),
                  Text(
                    'Longitude: ${_longitude!.toStringAsFixed(6)}',
                    style: const TextStyle(color: AppConstants.textMuted, fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _locationUrl ?? '',
                    style: const TextStyle(color: Colors.blueAccent, fontSize: 12, decoration: TextDecoration.underline),
                  ),
                ] else ...[
                  Text(
                    _errorMessage ?? 'GPS coordinates pending or mocked.',
                    style: const TextStyle(color: AppConstants.warningAmber, fontSize: 13),
                  ),
                ],
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Colors.white24),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: _openGoogleMaps,
                        icon: const Icon(Icons.map, size: 16),
                        label: const Text('View on Map'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppConstants.primaryRed,
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        onPressed: _shareLocation,
                        icon: const Icon(Icons.share, size: 16),
                        label: const Text('Share Location'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Emergency Helplines Direct Dial
          const Text(
            'Immediate Emergency Helplines',
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          ...EmergencyNumbers.services.take(3).map(
                (svc) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: EmergencyServiceCard(service: svc),
                ),
              ),
          const SizedBox(height: 20),

          // Reset button
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: AppConstants.textMuted,
              side: const BorderSide(color: Colors.white12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
            onPressed: () {
              setState(() => _state = SosState.idle);
            },
            child: const Text('Reset SOS State'),
          ),
        ],
      ),
    );
  }

  Widget _buildCancelledView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white10,
            ),
            child: const Icon(Icons.cancel_outlined, size: 60, color: AppConstants.textMuted),
          ),
          const SizedBox(height: 16),
          const Text(
            'SOS Cancelled',
            style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 6),
          const Text(
            'No emergency alert was dispatched.',
            style: TextStyle(color: AppConstants.textMuted, fontSize: 14),
          ),
          const SizedBox(height: 32),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppConstants.primaryRed,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            onPressed: () => setState(() => _state = SosState.idle),
            child: const Text('Back to SOS', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _buildIdleView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppConstants.primaryRed.withOpacity(0.12),
                border: Border.all(color: AppConstants.primaryRed.withOpacity(0.3), width: 2),
              ),
              child: InkWell(
                onTap: _startCountdown,
                customBorder: const CircleBorder(),
                child: Container(
                  width: 160,
                  height: 160,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [Color(0xFFF43F5E), AppConstants.primaryRed, Color(0xFF881337)],
                    ),
                  ),
                  child: const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.touch_app, color: Colors.white, size: 36),
                        SizedBox(height: 6),
                        Text(
                          'ACTIVATE\nSOS',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 22,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 32),
            const Text(
              'Press to start 5-second emergency sequence',
              style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 8),
            const Text(
              'You will have 5 seconds to cancel before GPS locking & alert generation.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppConstants.textMuted, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('Emergency SOS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: switch (_state) {
          SosState.idle => _buildIdleView(),
          SosState.countingDown => _buildCountingDownView(),
          SosState.activating => _buildActivatingView(),
          SosState.activated => _buildActivatedView(),
          SosState.cancelled => _buildCancelledView(),
        },
      ),
    );
  }
}
