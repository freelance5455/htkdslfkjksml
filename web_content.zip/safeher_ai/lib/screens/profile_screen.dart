import 'package:flutter/material.dart';
import '../services/auth_service.dart';
import '../utils/constants.dart';
import 'contacts_screen.dart';
import 'instructions_screen.dart';
import 'login_screen.dart';
import 'sos_history_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  void _confirmLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppConstants.cardDark,
        title: const Text('Confirm Logout', style: TextStyle(color: Colors.white)),
        content: const Text(
          'Are you sure you want to sign out from SafeHer AI?',
          style: TextStyle(color: AppConstants.textMuted),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel', style: TextStyle(color: AppConstants.textMuted)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppConstants.primaryRed),
            onPressed: () async {
              Navigator.pop(ctx);
              await AuthService().signOut();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
            child: const Text('Sign Out', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  void _showProjectInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppConstants.cardDark,
        title: const Row(
          children: [
            Icon(Icons.school, color: AppConstants.primaryRed),
            SizedBox(width: 8),
            Text('Project Info', style: TextStyle(color: Colors.white, fontSize: 18)),
          ],
        ),
        content: const SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('Project Title:', style: TextStyle(color: AppConstants.primaryRed, fontWeight: FontWeight.bold)),
              Text(AppConstants.projectTitle, style: TextStyle(color: Colors.white, fontSize: 13)),
              SizedBox(height: 10),
              Text('Domain:', style: TextStyle(color: AppConstants.primaryRed, fontWeight: FontWeight.bold)),
              Text(AppConstants.projectDomain, style: TextStyle(color: Colors.white, fontSize: 13)),
              SizedBox(height: 10),
              Text('Academic Level:', style: TextStyle(color: AppConstants.primaryRed, fontWeight: FontWeight.bold)),
              Text(AppConstants.academicStudentLevel, style: TextStyle(color: Colors.white, fontSize: 13)),
              SizedBox(height: 10),
              Text('Key Technologies:', style: TextStyle(color: AppConstants.primaryRed, fontWeight: FontWeight.bold)),
              Text(
                '• Flutter & Dart (Material 3 UI)\n• Firebase Authentication & Realtime Database\n• Real-Time GPS Geolocator\n• Speech Recognition (Microphone STT)\n• Rule-Based Emergency Intent Detector\n• Mobile System URL Schemes & Share Sheet',
                style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.4),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppConstants.primaryRed),
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Close', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService().currentUser;
    final userName = user?.displayName ?? 'SafeHer User';
    final userEmail = user?.email ?? 'user@safeher.ai';

    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('Profile & Settings', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // User Card
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppConstants.cardDark,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: AppConstants.primaryRed.withOpacity(0.2),
                    child: Text(
                      userName.isNotEmpty ? userName[0].toUpperCase() : 'U',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppConstants.primaryRed),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          userName,
                          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          userEmail,
                          style: const TextStyle(color: AppConstants.textMuted, fontSize: 13),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Quick Links
            Container(
              decoration: BoxDecoration(
                color: AppConstants.cardDark,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: Column(
                children: [
                  ListTile(
                    leading: const Icon(Icons.people_outline, color: AppConstants.primaryRed),
                    title: const Text('Emergency Contacts', style: TextStyle(color: Colors.white)),
                    trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ContactsScreen())),
                  ),
                  const Divider(color: Colors.white10, height: 1),
                  ListTile(
                    leading: const Icon(Icons.history, color: AppConstants.primaryRed),
                    title: const Text('SOS Alert History', style: TextStyle(color: Colors.white)),
                    trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SosHistoryScreen())),
                  ),
                  const Divider(color: Colors.white10, height: 1),
                  ListTile(
                    leading: const Icon(Icons.help_outline, color: AppConstants.primaryRed),
                    title: const Text('How SafeHer AI Works', style: TextStyle(color: Colors.white)),
                    trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InstructionsScreen())),
                  ),
                  const Divider(color: Colors.white10, height: 1),
                  ListTile(
                    leading: const Icon(Icons.school_outlined, color: AppConstants.primaryRed),
                    title: const Text('Academic Project Information', style: TextStyle(color: Colors.white)),
                    trailing: const Icon(Icons.chevron_right, color: Colors.white38),
                    onTap: () => _showProjectInfo(context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Academic Disclaimer Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.03),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white10),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.info_outline, color: AppConstants.warningAmber, size: 16),
                      SizedBox(width: 6),
                      Text(
                        'Academic Prototype Disclaimer',
                        style: TextStyle(color: AppConstants.warningAmber, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ],
                  ),
                  SizedBox(height: 6),
                  Text(
                    AppConstants.academicDisclaimer,
                    style: TextStyle(color: AppConstants.textMuted, fontSize: 11, height: 1.4),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Logout Button
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                foregroundColor: AppConstants.accentAlert,
                side: BorderSide(color: AppConstants.accentAlert.withOpacity(0.5)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              onPressed: () => _confirmLogout(context),
              icon: const Icon(Icons.logout),
              label: const Text('Sign Out', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }
}
