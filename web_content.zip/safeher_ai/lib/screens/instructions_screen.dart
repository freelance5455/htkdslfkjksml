import 'package:flutter/material.dart';
import '../utils/constants.dart';

class InstructionsScreen extends StatelessWidget {
  const InstructionsScreen({super.key});

  Widget _buildStepCard({
    required String title,
    required IconData icon,
    required List<String> steps,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppConstants.cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppConstants.primaryRed.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: AppConstants.primaryRed, size: 22),
              ),
              const SizedBox(width: 12),
              Text(
                title,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 14),
          ...steps.asMap().entries.map((entry) {
            final idx = entry.key + 1;
            final text = entry.value;
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 10,
                    backgroundColor: AppConstants.primaryRed.withOpacity(0.2),
                    child: Text(
                      '$idx',
                      style: const TextStyle(color: AppConstants.primaryRed, fontSize: 10, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      text,
                      style: const TextStyle(color: Colors.white70, fontSize: 13, height: 1.4),
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppConstants.surfaceDark,
      appBar: AppBar(
        title: const Text('How SafeHer AI Works', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            // Banner
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppConstants.primaryRed.withOpacity(0.2),
                    AppConstants.cardDark,
                  ],
                ),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppConstants.primaryRed.withOpacity(0.3)),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Academic Demonstration Architecture',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'SafeHer AI connects Flutter on-device sensors (Microphone, GPS) with Firebase Realtime Database for rapid emergency dispatch.',
                    style: TextStyle(color: AppConstants.textMuted, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            _buildStepCard(
              title: 'Emergency SOS Protocol',
              icon: Icons.emergency,
              steps: [
                'User presses the central EMERGENCY SOS button.',
                'A 5-second audible countdown is initiated to prevent false triggers.',
                'The user can cancel anytime during the 5 seconds.',
                'If not cancelled, GPS coordinates are fetched via Geolocator.',
                'A Google Maps link is generated and logged into Firebase Realtime Database.',
                'The user is presented with one-tap location sharing and direct emergency dialers.',
              ],
            ),

            _buildStepCard(
              title: 'AI Voice Safety Protocol',
              icon: Icons.mic,
              steps: [
                'User enables "Start Voice Safety" in background or active mode.',
                'Microphone captures audio stream converted to text via speech recognition.',
                'Rule-based distress classifier scans for keywords like "help", "save me", "someone is following me".',
                'Upon detection, the system announces potential emergency and triggers 5-second countdown.',
                'If not aborted, the SOS alert is logged with source: "voice-threat-detection".',
              ],
            ),

            _buildStepCard(
              title: 'Emergency Contacts & Sharing',
              icon: Icons.people,
              steps: [
                'User stores primary emergency contacts (Parents, Guardians, Friends).',
                'Data is saved privately under users/{uid}/contacts.',
                'During an alert, the native share sheet allows sending GPS links via WhatsApp, SMS, or Telegram.',
                'One-tap calling allows placing telephone calls without navigating through phonebook.',
              ],
            ),

            _buildStepCard(
              title: 'AI Safety Copilot',
              icon: Icons.psychology,
              steps: [
                'Interactive situational guidance assistant.',
                'User enters situations like "someone is following me" or "walking alone at night".',
                'Categorized safety guidelines provide immediate actionable steps.',
                'Quick action buttons connect directly to National Emergency 112.',
              ],
            ),
          ],
        ),
      ),
    );
  }
}
