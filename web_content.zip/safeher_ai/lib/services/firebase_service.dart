import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import '../models/emergency_contact.dart';
import '../models/sos_alert.dart';

class FirebaseService {
  final FirebaseDatabase _db = FirebaseDatabase.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  String? get currentUid => _auth.currentUser?.uid;

  // Stream of user emergency contacts
  Stream<List<EmergencyContact>> getContactsStream() {
    final uid = currentUid;
    if (uid == null) return Stream.value([]);

    return _db.ref('users/$uid/contacts').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return [];

      final List<EmergencyContact> list = [];
      if (data is Map) {
        data.forEach((key, val) {
          if (val is Map) {
            list.add(EmergencyContact.fromMap(key.toString(), val));
          }
        });
      }
      return list;
    });
  }

  // Add contact
  Future<void> addContact(String name, String phone, String relationship) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';

    final newRef = _db.ref('users/$uid/contacts').push();
    await newRef.set({
      'name': name.trim(),
      'phone': phone.trim(),
      'relationship': relationship.trim(),
    });
  }

  // Update contact
  Future<void> updateContact(
    String contactId,
    String name,
    String phone,
    String relationship,
  ) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';

    await _db.ref('users/$uid/contacts/$contactId').update({
      'name': name.trim(),
      'phone': phone.trim(),
      'relationship': relationship.trim(),
    });
  }

  // Delete contact
  Future<void> deleteContact(String contactId) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';

    await _db.ref('users/$uid/contacts/$contactId').remove();
  }

  // Save SOS Alert
  Future<String> saveSosAlert({
    required double latitude,
    required double longitude,
    required String locationUrl,
    required String source,
  }) async {
    final uid = currentUid;
    if (uid == null) throw 'User not authenticated.';

    final alertRef = _db.ref('users/$uid/sosAlerts').push();
    final alertId = alertRef.key ?? DateTime.now().millisecondsSinceEpoch.toString();

    final nowStr = DateTime.now().toIso8601String();
    await alertRef.set({
      'latitude': latitude,
      'longitude': longitude,
      'locationUrl': locationUrl,
      'time': nowStr,
      'source': source,
      'status': 'activated',
    });

    return alertId;
  }

  // Stream of SOS Alerts
  Stream<List<SosAlert>> getSosAlertsStream() {
    final uid = currentUid;
    if (uid == null) return Stream.value([]);

    return _db.ref('users/$uid/sosAlerts').orderByChild('time').onValue.map((event) {
      final data = event.snapshot.value;
      if (data == null) return [];

      final List<SosAlert> list = [];
      if (data is Map) {
        data.forEach((key, val) {
          if (val is Map) {
            list.add(SosAlert.fromMap(key.toString(), val));
          }
        });
      }
      // Sort latest first
      list.sort((a, b) => b.time.compareTo(a.time));
      return list;
    });
  }

  // Get user profile name
  Future<String> getUserName() async {
    final uid = currentUid;
    if (uid == null) return 'User';
    final user = _auth.currentUser;
    if (user?.displayName != null && user!.displayName!.isNotEmpty) {
      return user.displayName!;
    }
    final snapshot = await _db.ref('users/$uid/name').get();
    if (snapshot.exists && snapshot.value != null) {
      return snapshot.value.toString();
    }
    return user?.email?.split('@').first ?? 'User';
  }
}
