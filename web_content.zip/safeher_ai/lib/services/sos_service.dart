import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'firebase_service.dart';
import 'location_service.dart';

class SosService {
  final LocationService _locationService = LocationService();
  final FirebaseService _firebaseService = FirebaseService();

  // Trigger SOS activation workflow
  Future<Map<String, dynamic>> activateSos({
    required String source, // 'manual-sos' | 'voice-threat-detection'
  }) async {
    double latitude = 0.0;
    double longitude = 0.0;
    String locationUrl = '';

    try {
      final position = await _locationService.getCurrentLocation();
      latitude = position.latitude;
      longitude = position.longitude;
      locationUrl = _locationService.getGoogleMapsUrl(latitude, longitude);
    } catch (e) {
      // If GPS fails or is denied, record placeholder with timestamp
      locationUrl = 'Location unavailable (${e.toString()})';
    }

    final alertId = await _firebaseService.saveSosAlert(
      latitude: latitude,
      longitude: longitude,
      locationUrl: locationUrl,
      source: source,
    );

    return {
      'alertId': alertId,
      'latitude': latitude,
      'longitude': longitude,
      'locationUrl': locationUrl,
      'time': DateTime.now().toIso8601String(),
      'source': source,
    };
  }

  // Share emergency location to contacts/apps via native share sheet
  Future<void> shareEmergencyLocation({
    required double latitude,
    required double longitude,
    required String locationUrl,
    String? customMessage,
  }) async {
    final String message = customMessage ??
        'EMERGENCY ALERT: I may need immediate help! My current GPS location is:\n$locationUrl\n\nSent via SafeHer AI Safety System.';

    await Share.share(
      message,
      subject: 'URGENT: SafeHer AI Emergency Alert',
    );
  }

  // Launch phone call dialer with confirmation
  Future<bool> makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber.replaceAll(RegExp(r'[^0-9+]'), ''),
    );

    if (await canLaunchUrl(launchUri)) {
      return await launchUrl(launchUri);
    } else {
      throw 'Could not launch dialer for number $phoneNumber';
    }
  }
}
