import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../utils/constants.dart';

class VoiceService {
  final SpeechToText _speechToText = SpeechToText();
  bool _isInitialized = false;

  bool get isListening => _speechToText.isListening;
  bool get isInitialized => _isInitialized;

  // Initialize Speech recognition
  Future<bool> initialize() async {
    if (_isInitialized) return true;
    try {
      _isInitialized = await _speechToText.initialize(
        onError: (val) => debugPrint('SpeechToText Error: $val'),
        onStatus: (val) => debugPrint('SpeechToText Status: $val'),
      );
      return _isInitialized;
    } catch (e) {
      debugPrint('SpeechToText init exception: $e');
      return false;
    }
  }

  // Start listening for speech
  Future<void> startListening({
    required Function(String recognizedWords) onResult,
    required Function(String detectedPhrase) onEmergencyDetected,
  }) async {
    if (!_isInitialized) {
      final initialized = await initialize();
      if (!initialized) {
        throw 'Microphone or speech recognition permission was denied or unavailable.';
      }
    }

    await _speechToText.listen(
      onResult: (result) {
        final words = result.recognizedWords;
        onResult(words);

        // Rule-Based Emergency Intent Detection
        final detected = detectEmergencyIntent(words);
        if (detected != null) {
          onEmergencyDetected(detected);
        }
      },
      listenFor: const Duration(seconds: 60),
      pauseFor: const Duration(seconds: 5),
      partialResults: true,
      cancelOnError: false,
    );
  }

  // Stop listening
  Future<void> stopListening() async {
    if (_speechToText.isListening) {
      await _speechToText.stop();
    }
  }

  /// Rule-Based Distress Intent Detector
  /// Note for Academic Review:
  /// Uses case-insensitive token matching and regular expressions across curated emergency phrases.
  /// Designed as an interface adapter where a future on-device TensorFlow Lite / ONNX / DistilBERT
  /// model can replace or augment this rule-based classifier.
  String? detectEmergencyIntent(String text) {
    if (text.trim().isEmpty) return null;
    final normalized = text.toLowerCase().replaceAll(RegExp(r"[.,!?;:'\-]"), ' ');

    // 1. Direct keyword match
    for (final keyword in AppConstants.distressKeywords) {
      final cleanKw = keyword.toLowerCase().replaceAll(RegExp(r"[.,!?;:'\-]"), ' ');
      if (normalized.contains(cleanKw)) {
        return keyword;
      }
    }

    // 2. Pattern intent matching
    final patterns = [
      RegExp(r'(someone|somebody|person).*(following|behind|stalking)'),
      RegExp(r'(i am|im|i m).*(being followed|followed|unsafe|scared|in danger)'),
      RegExp(r'(help|save) me'),
      RegExp(r'(please help|help please)'),
      RegExp(r'(call|dial).*(police|100|112|cops)'),
      RegExp(r'(leave me alone|get away|stop it|back off)'),
      RegExp(r'\b(emergency|danger|attack|threat|assault)\b'),
    ];

    for (final p in patterns) {
      if (p.hasMatch(normalized)) {
        return text.trim();
      }
    }

    return null;
  }
}
