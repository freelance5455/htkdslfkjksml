import 'package:flutter/material.dart';

class AppConstants {
  static const String appName = 'SafeHer AI';
  static const String appSubtitle = 'AI-Powered Women Safety & Emergency Response';
  static const String packageName = 'com.example.safeherai';

  // Colors
  static const Color primaryRed = Color(0xFFE11D48); // Rose 600
  static const Color darkRed = Color(0xFFBE123C);
  static const Color accentAlert = Color(0xFFDC2626);
  static const Color surfaceDark = Color(0xFF0F172A); // Slate 900
  static const Color cardDark = Color(0xFF1E293B); // Slate 800
  static const Color textLight = Color(0xFFF8FAFC);
  static const Color textMuted = Color(0xFF94A3B8);
  static const Color safetyGreen = Color(0xFF10B981);
  static const Color warningAmber = Color(0xFFF59E0B);

  // Voice distress detection keywords
  static const List<String> distressKeywords = [
    'help',
    'save me',
    'emergency',
    'danger',
    'attack',
    'someone is following me',
    "i'm being followed",
    'im being followed',
    'please help',
    'call police',
    "i'm scared",
    'im scared',
    'leave me alone',
    'stop',
    'help me',
  ];

  // Academic Project Info
  static const String projectTitle = 'AI-Powered Women Safety and Emergency Response System';
  static const String projectDomain = 'Artificial Intelligence and Machine Learning (AIML)';
  static const String academicStudentLevel = 'B.Tech CSE (AIML) 3rd Year Mini-Project';
  static const String academicDisclaimer =
      'This application is an academic prototype designed to demonstrate AI-assisted safety and emergency response features. '
      'It is not a replacement for official emergency services. Always contact appropriate emergency services during a real emergency.';
}
