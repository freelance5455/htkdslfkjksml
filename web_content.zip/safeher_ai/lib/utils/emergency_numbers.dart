class EmergencyServiceInfo {
  final String title;
  final String number;
  final String description;
  final String iconName;

  const EmergencyServiceInfo({
    required this.title,
    required this.number,
    required this.description,
    required this.iconName,
  });
}

class EmergencyNumbers {
  static const List<EmergencyServiceInfo> services = [
    EmergencyServiceInfo(
      title: 'Police',
      number: '100',
      description: 'Immediate law enforcement & crime prevention',
      iconName: 'local_police',
    ),
    EmergencyServiceInfo(
      title: 'National Emergency',
      number: '112',
      description: 'Unified all-in-one national helpline',
      iconName: 'emergency',
    ),
    EmergencyServiceInfo(
      title: 'Ambulance',
      number: '108',
      description: 'Medical & emergency medical response',
      iconName: 'medical_services',
    ),
    EmergencyServiceInfo(
      title: 'Fire Brigade',
      number: '101',
      description: 'Fire & rescue emergency response',
      iconName: 'local_fire_department',
    ),
    EmergencyServiceInfo(
      title: 'Women Helpline',
      number: '1091',
      description: '24/7 dedicated women distress & safety support',
      iconName: 'support_agent',
    ),
  ];
}
