import 'package:flutter/material.dart';
import '../services/sos_service.dart';
import '../utils/constants.dart';
import '../utils/emergency_numbers.dart';

class EmergencyServiceCard extends StatelessWidget {
  final EmergencyServiceInfo service;

  const EmergencyServiceCard({
    super.key,
    required this.service,
  });

  IconData _getIconData(String iconName) {
    switch (iconName) {
      case 'local_police':
        return Icons.local_police;
      case 'emergency':
        return Icons.emergency;
      case 'medical_services':
        return Icons.medical_services;
      case 'local_fire_department':
        return Icons.local_fire_department;
      case 'support_agent':
        return Icons.support_agent;
      default:
        return Icons.phone_in_talk;
    }
  }

  void _confirmAndCall(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          backgroundColor: AppConstants.cardDark,
          title: Row(
            children: [
              const Icon(Icons.phone_forwarded, color: AppConstants.primaryRed),
              const SizedBox(width: 8),
              Text(
                'Call ${service.title}?',
                style: const TextStyle(color: Colors.white, fontSize: 18),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Are you sure you want to dial ${service.title} (${service.number})?',
                style: const TextStyle(color: AppConstants.textMuted),
              ),
              const SizedBox(height: 8),
              Text(
                service.description,
                style: const TextStyle(color: Colors.white70, fontSize: 12),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancel', style: TextStyle(color: AppConstants.textMuted)),
            ),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppConstants.primaryRed,
                foregroundColor: Colors.white,
              ),
              onPressed: () async {
                Navigator.pop(ctx);
                try {
                  await SosService().makePhoneCall(service.number);
                } catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(e.toString())),
                    );
                  }
                }
              },
              icon: const Icon(Icons.call, size: 16),
              label: Text('Call ${service.number}'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppConstants.cardDark,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _confirmAndCall(context),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppConstants.primaryRed.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _getIconData(service.iconName),
                  color: AppConstants.primaryRed,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      service.title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      'Dial: ${service.number}',
                      style: const TextStyle(
                        color: AppConstants.primaryRed,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, color: Colors.white38, size: 14),
            ],
          ),
        ),
      ),
    );
  }
}
