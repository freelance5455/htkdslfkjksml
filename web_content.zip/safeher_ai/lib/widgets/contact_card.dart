import 'package:flutter/material.dart';
import '../models/emergency_contact.dart';
import '../services/sos_service.dart';
import '../utils/constants.dart';

class ContactCard extends StatelessWidget {
  final EmergencyContact contact;
  final VoidCallback onDelete;
  final VoidCallback? onEdit;

  const ContactCard({
    super.key,
    required this.contact,
    required this.onDelete,
    this.onEdit,
  });

  void _callContact(BuildContext context) async {
    try {
      await SosService().makePhoneCall(contact.phone);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppConstants.cardDark,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: AppConstants.primaryRed.withOpacity(0.2),
            foregroundColor: AppConstants.primaryRed,
            child: Text(
              contact.name.isNotEmpty ? contact.name[0].toUpperCase() : '?',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  contact.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  contact.relationship,
                  style: const TextStyle(
                    color: AppConstants.primaryRed,
                    fontWeight: FontWeight.w500,
                    fontSize: 12,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  contact.phone,
                  style: const TextStyle(
                    color: AppConstants.textMuted,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.phone, color: AppConstants.safetyGreen),
            tooltip: 'Call Contact',
            onPressed: () => _callContact(context),
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: Colors.rose),
            tooltip: 'Delete Contact',
            onPressed: onDelete,
          ),
        ],
      ),
    );
  }
}
