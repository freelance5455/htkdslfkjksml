# SafeHer AI: AI-Powered Women Safety and Emergency Response System

**Domain:** Artificial Intelligence & Machine Learning (AIML)  
**Academic Level:** 3rd Year B.Tech CSE Mini-Project  
**Package Name:** `com.example.safeherai`  
**Subtitle:** *"Your Safety. Your Connection. Your Protection."*

---

## 📌 Executive Summary

**SafeHer AI** is an emergency response mobile application engineered using **Flutter**, **Firebase**, and **Speech Recognition with Rule-Based Emergency Intent Detection**. The system bridges the critical gap between personal safety emergencies and rapid response by unifying one-touch SOS activation, hands-free voice threat detection, real-time satellite GPS coordinate broadcast, direct emergency dialers, trusted contacts management, and an interactive AI Safety Copilot.

---

## 🚀 Key Features

1. **Central Emergency SOS Button:**
   - 5-second animated countdown buffer to prevent accidental triggers.
   - GPS coordinate acquisition via high-accuracy device sensors.
   - Generation of instant Google Maps locator URL.
   - Realtime logging to Firebase Realtime Database (`users/{uid}/sosAlerts`).
   - One-tap native sharing via WhatsApp, SMS, or Telegram.

2. **AI Voice Safety (Hands-Free Threat Detection):**
   - Continuous on-device speech-to-text processing.
   - Real-time distress intent matcher across critical phrases (*"Someone is following me"*, *"Please help"*, *"Emergency"*, *"Danger"*).
   - 5-second abort countdown upon detection, transitioning seamlessly into emergency SOS dispatch.

3. **Official Emergency Helplines (Direct Dialer):**
   - Police (100)
   - National Integrated Emergency (112)
   - Medical Ambulance (108)
   - Fire & Rescue (101)
   - Women Safety Helpline (1091)
   - Safety confirmation dialog before system dialer launch.

4. **Emergency Contacts Management:**
   - Add, edit, remove, and telephone trusted contacts with relationship tags (Mother, Father, Friend, Guardian).
   - Private storage scoped under `users/{uid}/contacts`.

5. **Live Location & Satellite Fix:**
   - Latitude, longitude, and accuracy telemetry.
   - One-tap copy and direct launch in Google Maps.

6. **AI Safety Copilot:**
   - Conversational assistant providing situational guidance for following/stalking, solo night transit, assault threats, and emergency numbers.

7. **Smart Trip Safety Planner:**
   - Dynamically generated checklist based on destination, travel time (Daytime/Late Night), and companion status (Alone/Accompanied).
   - Shareable and interactive checklist items.

8. **SOS Alert History:**
   - Chronological audit log of all manual and voice-triggered emergency alerts.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend Mobile** | Flutter 3.x, Dart 3.x, Material 3 Design |
| **Backend & Cloud** | Firebase Authentication, Firebase Realtime Database |
| **Device Hardware** | GPS / Geolocator, Microphone / Speech-to-Text, Telephony Dialer, Native Share Sheet |
| **NLP / AI Engine** | Speech Recognition Engine + Rule-Based Distress Intent Classifier (Modular interface designed for future on-device BERT / DistilBERT integration) |

---

## 📁 Project Folder Structure

```text
safeher_ai/
│
├── android/
│   └── app/src/main/AndroidManifest.xml
├── ios/
│   └── Runner/Info.plist
├── lib/
│   ├── main.dart
│   ├── firebase_options.dart
│   │
│   ├── models/
│   │   ├── emergency_contact.dart
│   │   └── sos_alert.dart
│   │
│   ├── services/
│   │   ├── auth_service.dart
│   │   ├── firebase_service.dart
│   │   ├── location_service.dart
│   │   ├── sos_service.dart
│   │   └── voice_service.dart
│   │
│   ├── screens/
│   │   ├── splash_screen.dart
│   │   ├── login_screen.dart
│   │   ├── register_screen.dart
│   │   ├── home_screen.dart
│   │   ├── sos_screen.dart
│   │   ├── contacts_screen.dart
│   │   ├── location_screen.dart
│   │   ├── voice_safety_screen.dart
│   │   ├── ai_copilot_screen.dart
│   │   ├── trip_planner_screen.dart
│   │   ├── safety_tips_screen.dart
│   │   ├── sos_history_screen.dart
│   │   ├── instructions_screen.dart
│   │   └── profile_screen.dart
│   │
│   ├── widgets/
│   │   ├── sos_button.dart
│   │   ├── emergency_service_card.dart
│   │   ├── contact_card.dart
│   │   └── feature_card.dart
│   │
│   └── utils/
│       ├── emergency_numbers.dart
│       └── constants.dart
│
├── pubspec.yaml
├── firebase_database_rules.json
└── README.md
```

---

## 🔒 Firebase Realtime Database Structure & Security Rules

### Database Hierarchy
```text
users/
 └── {uid}/
      ├── name: "Priya Sharma"
      ├── email: "priya@example.com"
      ├── createdAt: "2026-10-02T10:00:00Z"
      │
      ├── contacts/
      │    └── {contactId}/
      │         ├── name: "Mother"
      │         ├── phone: "+919876543210"
      │         └── relationship: "Mother"
      │
      └── sosAlerts/
           └── {alertId}/
                ├── latitude: 17.6868
                ├── longitude: 83.2185
                ├── locationUrl: "https://www.google.com/maps/search/?api=1&query=17.6868,83.2185"
                ├── time: "2026-10-02T10:30:00Z"
                ├── source: "manual-sos"
                └── status: "activated"
```

### Security Rules (`firebase_database_rules.json`)
```json
{
  "rules": {
    "users": {
      "$uid": {
        ".read": "auth != null && auth.uid == $uid",
        ".write": "auth != null && auth.uid == $uid",
        "contacts": {
          "$contactId": {
            ".validate": "newData.hasChildren(['name', 'phone', 'relationship'])"
          }
        },
        "sosAlerts": {
          "$alertId": {
            ".validate": "newData.hasChildren(['latitude', 'longitude', 'locationUrl', 'time', 'source', 'status'])"
          }
        }
      }
    }
  }
}
```

---

## ⚙️ Setup and Installation Instructions

### 1. Prerequisites
- **Flutter SDK:** Version 3.19.0 or higher.
- **Dart SDK:** Version 3.3.0 or higher.
- **Android Studio / VS Code** with Flutter and Dart extensions.
- **Firebase Account** with a new project created.

### 2. Configure Firebase via FlutterFire CLI
In the root directory of `safeher_ai`:
```bash
# 1. Install FlutterFire CLI if not already installed
dart pub global activate flutterfire_cli

# 2. Login to your Google / Firebase account
firebase login

# 3. Configure platform options (Android & iOS)
flutterfire configure
```
*This command updates `lib/firebase_options.dart` automatically with your project keys.*

### 3. Install Dependencies
```bash
flutter pub get
```

### 4. Run the Application
Connect an Android/iOS device or start an emulator, then:
```bash
flutter run
```

### 5. Build Release APK (For Viva / Academic Submission)
```bash
flutter build apk --release
```
The APK will be generated at:
`build/app/outputs/flutter-apk/app-release.apk`

---

## 📱 Mobile Permissions Configuration

### Android (`android/app/src/main/AndroidManifest.xml`)
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.CALL_PHONE" />
```

### iOS (`ios/Runner/Info.plist`)
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>SafeHer AI requires location access to send your real-time coordinates to emergency services and trusted contacts during an SOS event.</string>
<key>NSMicrophoneUsageDescription</key>
<string>SafeHer AI uses the microphone for hands-free speech recognition to detect emergency distress keywords.</string>
<key>NSSpeechRecognitionUsageDescription</key>
<string>SafeHer AI analyzes spoken phrases on-device to trigger instant safety protocols when distress words are detected.</string>
```

---

## 🎓 Academic Presentation & Demonstration Steps

| Demo # | Title | Expected Action & Verification |
|---|---|---|
| **Demo 1** | **Registration & Authentication** | Register new user -> Profile created under `users/{uid}` -> Navigates to Home Dashboard. |
| **Demo 2** | **Emergency Contacts CRUD** | Add contact (e.g. "Mother") -> Stored in Firebase Realtime DB -> Verified on Contact Card. |
| **Demo 3** | **Manual SOS Execution** | Tap Emergency SOS -> 5-sec countdown -> GPS locked -> Logged to Firebase -> Location link shared. |
| **Demo 4** | **Direct Helpline Calling** | Tap "Police 100" -> Confirmation modal -> Phone dialer launched with `tel:100`. |
| **Demo 5** | **AI Voice Threat Detection** | Turn on Voice Safety -> Say *"Someone is following me"* -> Distress intent matched -> SOS countdown begins. |
| **Demo 6** | **AI Safety Copilot** | Ask *"Someone is following me"* -> Situational step-by-step guidance rendered. |
| **Demo 7** | **Smart Trip Safety Planner** | Enter destination + "Late Night" + "Alone" -> Tailored actionable safety checklist generated. |
| **Demo 8** | **SOS Audit History** | Open SOS History -> Review previously logged alerts with timestamps, sources, and coordinates. |

---

## ⚖️ Academic Disclaimer
> **Disclaimer:** This application is an academic prototype designed to demonstrate AI-assisted safety and emergency response features for a B.Tech CSE (AIML) mini-project. It is not a replacement for official government emergency services. In case of a life-threatening crisis, dial 112 or local police directly.
