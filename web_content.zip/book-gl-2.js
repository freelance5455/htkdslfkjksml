/* JOSTECH — MANUEL 09 : GÉNIE LOGICIEL NIVEAU 2 */
registerLessonDetail(9, 2, "gl-2-1-1", {
  title: "Leçon 1 : Architecture MVC, Principes SOLID, UML et Git",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Structurer une application selon le patron MVC et les principes SOLID (SRP, OCP).",
    "Lire et choisir les 3 diagrammes UML clés (Cas d'utilisation, Classes, Séquence).",
    "Gérer les versions et résoudre un conflit de fusion avec Git."
  ],
  prerequisites: ["Niveau 1 — Génie logiciel et bases POO."],
  sections: [
    {
      type: "definition",
      term: "Patron MVC et Principes SOLID",
      text: "L'architecture MVC sépare strictement trois responsabilités :\n• Modèle (Model) : données, règles métier et accès base.\n• Vue (View) : affichage HTML/CSS sans logique complexe.\n• Contrôleur (Controller) : reçoit les clics/requêtes, interroge le Modèle et met à jour la Vue.\n\nLes principes SOLID guident un code propre, notamment le SRP (Single Responsibility Principle : une classe ou un fichier = 1 seule responsabilité claire) et l'OCP (Ouvert à l'extension, fermé à la modification)."
    },
    {
      type: "table",
      title: "1. Les 3 Diagrammes UML incontournables",
      headers: ["Diagramme UML", "Ce qu'il représente"],
      rows: [
        ["Cas d'utilisation (Use Case)", "Qui (Acteurs : Étudiant, Admin) peut faire quoi dans le système."],
        ["Diagramme de Classes", "Structure statique des objets, attributs, méthodes et relations (Héritage, Composition)."],
        ["Diagramme de Séquence", "Chronologie des messages échangés entre navigateur, API et base de données."]
      ]
    },
    {
      type: "code",
      lang: "Git — Branches, Fusion et Résolution de Conflit",
      code: [
        "git checkout -b feat/mode-examen   # 1. Créer une branche isolée",
        "git add quiz-engine.js",
        "git commit -m 'Ajout chrono examen'",
        "git checkout main                  # 2. Revenir sur la branche stable",
        "git merge feat/mode-examen         # 3. Fusionner la nouvelle fonction",
        "// En cas de conflit (<<<<<<< HEAD ... ======= ... >>>>>>>),",
        "// choisir manuellement le bon code, supprimer les marqueurs puis refaire git commit !"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Architecture Monolithique vs Microservices",
      text: "Ne commencez JAMAIS un nouveau projet avec 15 microservices complexes ! Un Monolithe Modulaire propre (fichiers bien séparés dans un seul projet) est 10 fois plus facile à tester, déployer et maintenir au lancement."
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Appliquer le principe SRP",
      question: "Vous créez une classe unique « SuperClasse » qui gère à la fois le calcul des notes sur 20, l'affichage HTML des boutons et l'envoi d'e-mails. Quel principe SOLID est violé et comment corriger ?",
      solution: "Le SRP (Single Responsibility Principle) est violé : il faut séparer en trois modules distincts (CalculNotes, VueInterface, ServiceEmail)."
    },
    {
      title: "Exercice 2 — Choisir le bon diagramme UML",
      question: "Vous voulez montrer exactement dans quel ordre le téléphone envoie les identifiants à l'API, l'API vérifie le hachage en base PostgreSQL puis renvoie le jeton JWT. Quel diagramme UML tracez-vous ?",
      solution: "Un Diagramme de Séquence UML (qui représente l'axe vertical du temps et les flèches chronologiques entre objets)."
    }
  ],
  summary: "MVC et SOLID gardent le code propre et extensible, UML clarifie l'architecture avant de coder, et Git par branches protège la version stable en production.",
  references: ["Fowler, M. — UML Distilled.", "Chacon, S. — Pro Git (git-scm.com/book)."]
});