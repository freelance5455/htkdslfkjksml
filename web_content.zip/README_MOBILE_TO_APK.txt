Rice Mill Mobile Web App

इस ZIP में केवल web/PWA files हैं।
किसी mobile-friendly Web/PWA-to-APK builder में ZIP upload करें और APK build करें।

मुख्य file: index.html
PWA files: manifest.webmanifest, sw.js
