GALAXY DEFENDER 2.0 - ANDROID APK BUILDER PACKAGE

This ZIP contains the complete single-file HTML5 game as index.html.

Android APK builder settings:
App name: Galaxy Defender 2.0
Package ID: com.sribes.galaxydefender
Orientation: Portrait
Fullscreen: On (if available)
Offline/local HTML: On

Touch-control update:
- Finger-drag movement is enabled by default on a fresh install.
- Pointer movement prevents WebView page gestures from stealing the drag.
- A touch-event fallback is included for older Android WebViews.
- The D-pad control option remains available in Settings.

The game is self-contained and uses localStorage for saved settings and scores.
This is an updated source ZIP, not a compiled APK. Use a trusted HTML-to-APK
builder or Android Studio WebView project to create the installable APK.
