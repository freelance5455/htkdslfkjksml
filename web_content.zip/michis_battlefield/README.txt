MICHIS BATTLEFIELD – Android-Prototyp 0.1

Enthalten:
- Offline-Spielprototyp mit Ego-Perspektive, einfacher Raycasting-3D-Darstellung
- 5 KI-Gegner (einfache Prototyp-KI), Leben, Munition, Nachladen
- Touch-Steuerung, synthetische Schuss-/Treffersounds
- Android-Studio-Projekt mit WebView-Hülle

APK bauen:
1. Android Studio installieren.
2. Diesen Projektordner öffnen.
3. Gradle-Synchronisierung abwarten (Android SDK 35 und JDK 17 erforderlich).
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Die APK liegt danach unter app/build/outputs/apk/debug/app-debug.apk.

Hinweis: In dieser Umgebung war kein Android SDK/Gradle-Build verfügbar; deshalb ist dies ein Android-Studio-Projekt, keine bereits kompilierte APK.
Der aktuelle Prototyp ist kein vollwertiger fotorealistischer 3D-Shooter und enthält noch keine echten 4K-Texturen. Die Darstellung ist eine spielbare technische Grundlage.
