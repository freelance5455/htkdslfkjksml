مشروع Android للعبة لغز العقل

هذا مشروع Android Studio يحتوي على لعبة HTML داخل WebView.
لبناء APK:
1) افتح المجلد في Android Studio على حاسوب عليه Android SDK.
2) انتظر Gradle Sync.
3) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
4) ستجد الملف داخل app/build/outputs/apk/debug/app-debug.apk.

ملاحظة: هذا مشروع المصدر وليس APK مبنياً؛ يحتاج Android SDK/Android Studio للبناء.
