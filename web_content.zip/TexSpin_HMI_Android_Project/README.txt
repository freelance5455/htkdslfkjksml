TEXSPIN HMI - ANDROID STUDIO PROJECT

This project wraps the supplied Ring Frame HMI & TexCal Speed Pattern Suite HTML file in an Android WebView.

BUILD APK
1. Install Android Studio on a computer.
2. Open this folder (the folder containing settings.gradle) in Android Studio.
3. Allow Gradle sync to finish. Android Studio may download the Android Gradle Plugin and SDK components.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

IMPORTANT NOTES
- The original HTML uses Tailwind CSS, Chart.js, and Google Fonts from online CDNs. Internet access is required for those external resources to load correctly. The main HTML file itself is bundled inside the app.
- Program slots use browser LocalStorage. Data is stored on that device/app installation; clearing app data or uninstalling may erase it. Export important recipes as CSV.
- This is a WebView packaging project, not a verified machine-control application. The “PLC Ready” label in the HTML does not establish a live PLC connection. Do not connect it to or operate production machinery based only on this app. Validate calculations, controls, and machine behavior with qualified engineering review and safe testing before any operational use.
- No PLC communication protocol, credentials, or machine-control interface has been added.
