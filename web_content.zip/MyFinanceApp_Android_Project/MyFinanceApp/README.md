# My Finance Android App

A simple personal finance tracker with Dashboard, Transactions, Goals and SIPs.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Choose **Build > Build APK(s)**.
4. Install the generated APK on your Android phone.

The app stores finance data locally on the device using browser local storage inside the bundled WebView.
