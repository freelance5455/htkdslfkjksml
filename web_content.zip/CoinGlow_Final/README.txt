CoinGlow cleaned HTML source

This package removes/rewords visible “Demo” labels in the app interface while preserving the existing layout and colors as much as possible.

Important: this is HTML source for importing into HTML to App. It is NOT a rebuilt APK. The current app logic still stores balances and requests locally on this device; real accounts, verified referral rewards, secure admin access, real gift-card delivery/UPI payouts, and live AdMob ads are not implemented by this text cleanup. Live ads must be integrated separately through a supported native Android AdMob SDK workflow.

Import this ZIP in HTML to App as a zipped site, preview it, then rebuild the APK.
