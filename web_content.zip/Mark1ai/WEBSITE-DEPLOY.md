# Mark1ai Website — Setup and Deployment

This project includes a mobile-friendly website UI and a Node.js/Express backend.
The backend serves the website and exposes `/api/chat`. The Gemini API key must stay
on the server as an environment variable.

## Run locally

Requirements: Node.js 20 or newer.

1. Extract this ZIP.
2. Open a terminal in the `Mark1ai` folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Create a `.env` file in the project root. Add:

   ```env
   GEMINI_API_KEY=YOUR_REAL_GEMINI_API_KEY
   PORT=3000
   ```

5. Start the server:

   ```bash
   npm start
   ```

6. Open `http://localhost:3000` in your browser.

Do not publish your `.env` file or place the API key in any file under `public/`.

## Deploy online

Deploy this whole Node.js project to a host that supports Node.js applications.
Set `GEMINI_API_KEY` in the host's private environment/secrets settings and use
`npm start` as the start command. Configure the service to use the port provided
by the host (`process.env.PORT` is already supported).

The current `server.js` serves the website and API from the same origin, which is
the simplest deployment arrangement. If you host the frontend and backend on
different domains, configure `APP_ORIGIN` on the backend to include the exact
frontend origin, and set `public/backend-config.js` to the backend HTTPS origin.

## Important checks

- Confirm the configured Gemini model is available to your API key. Model names,
  quotas, and pricing can change.
- AI responses will not work until a valid API key is configured on the server.
- Free-tier usage and hosting are not guaranteed to be unlimited or permanently free.
- Chat history is stored locally in the browser; it is not synced across devices.
- Test text prompts and JPG/PNG/WebP image questions after deployment.
