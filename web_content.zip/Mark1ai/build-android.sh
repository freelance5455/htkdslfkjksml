#!/usr/bin/env bash
set -euo pipefail

if [[ ! -d android ]]; then
  echo "Android project missing; creating it with Capacitor..."
  npx cap add android
fi
npx cap sync android
cd android
./gradlew assembleDebug
printf '\nAPK output: %s/android/app/build/outputs/apk/debug/app-debug.apk\n' "$(cd .. && pwd)"
