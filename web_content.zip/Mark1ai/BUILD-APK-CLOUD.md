# Get the APK without Android Studio
1. Deploy this project's server (see WEBSITE-DEPLOY.md) on a Node host with GEMINI_API_KEY set.
2. Put its HTTPS URL in public/backend-config.js (window.MARK1AI_API_BASE = "https://your-server").
3. Create a GitHub repo, upload all these files (including .github folder), push to main.
4. Open the repo > Actions > "Build Android APK" > wait ~5 min > download "Mark1ai-debug-apk" > unzip > install app-debug.apk on your phone (allow unknown sources).
