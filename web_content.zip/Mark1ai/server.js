import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.GEMINI_API_KEY;

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "blob:"],
      connectSrc: ["'self'", "https:"],
      objectSrc: ["'none'"],
      upgradeInsecureRequests: []
    }
  }
}));
// Allow the bundled Capacitor WebView and optional browser frontends to call
// this API. Configure APP_ORIGIN as a comma-separated list in production.
const allowedOrigins = new Set([
  "https://localhost",
  "capacitor://localhost",
  ...(process.env.APP_ORIGIN || "").split(",").map(value => value.trim()).filter(Boolean)
]);
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && allowedOrigins.has(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: "8mb" }));
app.use("/api/", rateLimit({
  windowMs: 60 * 1000,
  limit: 12,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Too many requests. Wait a minute and try again." }
}));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/config", (_req, res) => {
  res.json({ apiBase: process.env.PUBLIC_API_BASE || "" });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY || API_KEY === "PASTE_YOUR_API_KEY_HERE") {
      return res.status(503).json({ error: "AI is not configured yet. Add GEMINI_API_KEY to your .env file and restart the server." });
    }

    const { messages, prompt, image } = req.body || {};
    const safePrompt = typeof prompt === "string" ? prompt.trim() : "";
    if (!safePrompt && !image) {
      return res.status(400).json({ error: "Type a question or attach an image." });
    }
    if (safePrompt.length > 12000) {
      return res.status(413).json({ error: "Your question is too long. Please shorten it." });
    }

    const parts = [];
    if (safePrompt) parts.push({ text: safePrompt });
    if (image) {
      const { mimeType, data } = image;
      const allowed = ["image/jpeg", "image/png", "image/webp"];
      if (!allowed.includes(mimeType) || typeof data !== "string" || data.length > 6_000_000) {
        return res.status(400).json({ error: "Use a JPG, PNG, or WebP image under about 4 MB." });
      }
      parts.push({ inlineData: { mimeType, data } });
    }

    // Keep only recent text turns to limit payload size. Images are sent only for the current question.
    const history = Array.isArray(messages) ? messages.slice(-10) : [];
    const contents = [];
    for (const item of history) {
      if (!item || !["user", "model"].includes(item.role) || typeof item.text !== "string") continue;
      const text = item.text.trim().slice(0, 4000);
      if (text) contents.push({ role: item.role, parts: [{ text }] });
    }
    contents.push({ role: "user", parts });

    const upstream = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": API_KEY
        },
        body: JSON.stringify({
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
        }),
        signal: AbortSignal.timeout(45000)
      }
    );

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const status = upstream.status === 429 ? 429 : 502;
      return res.status(status).json({
        error: upstream.status === 429
          ? "The AI free-tier limit may have been reached. Wait and try again later."
          : "The AI service could not answer. Check your API key and model access, then try again."
      });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "")
      .join("")
      .trim();
    if (!answer) return res.status(502).json({ error: "The AI returned an empty answer. Please try again." });
    res.json({ answer });
  } catch (error) {
    console.error("Chat request failed:", error?.name || "unknown error");
    res.status(500).json({ error: "Something went wrong. Check your connection and try again." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Mark1ai is running at http://localhost:${PORT}`);
});