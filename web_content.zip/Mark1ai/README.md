# Mark1ai — Android app starter

Mark1ai is a mobile-first AI chat UI with text questions, image questions (JPG/PNG/WebP), and locally saved conversation history. The Android app is built with Capacitor. The Gemini API key stays on the server and must never be placed in the Android app.

## Important before building

The uploaded project does not contain an Android platform project, a deployed AI backend, or an API key. The UI can be packaged into an APK, but AI answers will only work after you deploy the backend and configure its HTTPS URL below.

## 1. Requirements

- Node.js 20 or newer
- Android Studio with Android SDK installed
- Java 17 (Android Gradle Plugin compatible)
- A deployed HTTPS backend with a valid Gemini API key

## 2. Configure the backend

1. Deploy this Node.js project to a Node-compatible HTTPS host.
2. Set `GEMINI_API_KEY` in the host's secret/environment settings. Obtain a key at https://aistudio.google.com/app/apikey and check current quota/pricing.
3. Set `APP_ORIGIN` on the backend if you use a browser frontend hosted on a different origin. The Capacitor origins `https://localhost` and `capacitor://localhost` are allowed by default.
4. Edit `public/backend-config.js` and set `window.MARK1AI_API_BASE` to your deployed backend origin, for example `https://your-service.example.com` (no trailing slash).
5. Do not put the Gemini key in `public/`, `backend-config.js`, or any Android file.

## 3. Build the Android APK

From this folder, run:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

In Android Studio, let Gradle sync finish, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. For a command-line debug APK, run `bash build-android.sh` after Android Studio/SDK setup. The usual output is `android/app/build/outputs/apk/debug/app-debug.apk`.

For future frontend changes, run `npx cap sync android` again before rebuilding.

## Features

- Modern dark AI chat interface
- Text prompts and JPG/PNG/WebP image questions (up to 4 MB)
- Local conversation history in the app's WebView storage
- Mobile sidebar, suggested prompts, and loading indicator
- Server-side API key handling, request size checks, and basic rate limiting

## Notes

- Chat history is local to the device/browser and is not synced between devices.
- This repository is an Android-ready source project; a finished APK must be generated with the Android SDK and configured backend.
- API quotas, model availability, and hosting limits can change. Check the provider's current terms before use.
