const $ = (id) => document.getElementById(id);
const form = $("chatForm"), input = $("promptInput"), messagesEl = $("messages");
const welcome = $("welcome"), historyList = $("historyList");
let selectedImage = null, busy = false, currentChatId = null;
let chats = JSON.parse(localStorage.getItem("mark1ai-chats") || "[]");
// Set MARK1AI_API_BASE in backend-config.js for a bundled Android build.
let apiBase = String(window.MARK1AI_API_BASE || "").replace(/\/$/, "");

async function loadConfig() {
  // In a browser, let the server provide its public API origin. In the bundled
  // Capacitor app, backend-config.js supplies the HTTPS API origin directly.
  if (apiBase) return;
  try {
    const response = await fetch("/api/config");
    if (!response.ok) return;
    const data = await response.json();
    apiBase = String(data.apiBase || "").replace(/\/$/, "");
  } catch { /* API base may be configured later for a native build. */ }
}
function saveChats() {
  try { localStorage.setItem("mark1ai-chats", JSON.stringify(chats.slice(0, 30))); } catch {}
}
function createChat() {
  const chat = { id: crypto.randomUUID(), title: "New chat", messages: [] };
  chats.unshift(chat); currentChatId = chat.id; saveChats(); renderChat(); renderHistory();
}
function currentChat() {
  return chats.find(c => c.id === currentChatId) || null;
}
function renderHistory() {
  historyList.replaceChildren();
  if (!chats.length) {
    const empty = document.createElement("div"); empty.className = "empty-history"; empty.textContent = "Your conversations will appear here."; historyList.append(empty); return;
  }
  chats.slice(0, 30).forEach(chat => {
    const button = document.createElement("button");
    button.className = "history-item" + (chat.id === currentChatId ? " active" : "");
    button.textContent = chat.title || "New chat";
    button.title = button.textContent;
    button.onclick = () => { currentChatId = chat.id; renderChat(); renderHistory(); $("sidebar").classList.remove("open"); };
    historyList.append(button);
  });
}
function addMessage(role, text, imageData = null, transient = false) {
  const row = document.createElement("div"); row.className = "message " + role;
  const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = role === "user" ? "Y" : "M";
  const bubble = document.createElement("div"); bubble.className = "bubble";
  if (imageData) { const img = document.createElement("img"); img.src = imageData; img.alt = "Uploaded question"; bubble.append(img); }
  if (text) { const content = document.createElement("div"); content.textContent = text; bubble.append(content); }
  row.append(avatar, bubble); messagesEl.append(row);
  if (!transient) $("conversation").scrollTop = $("conversation").scrollHeight;
  return row;
}
function renderChat() {
  messagesEl.replaceChildren();
  const chat = currentChat();
  welcome.hidden = !!(chat && chat.messages.length);
  if (chat) chat.messages.forEach(m => addMessage(m.role === "user" ? "user" : "assistant", m.text, m.imageData || null, true));
  $("conversation").scrollTop = $("conversation").scrollHeight;
}
function resetImage() {
  selectedImage = null; $("imageInput").value = ""; $("imagePreview").hidden = true;
}
$("newChat").onclick = createChat;
$("clearChat").onclick = () => {
  const chat = currentChat();
  if (chat) { chat.messages = []; chat.title = "New chat"; saveChats(); }
  resetImage(); renderChat(); renderHistory(); input.focus();
};
$("menuBtn").onclick = () => $("sidebar").classList.toggle("open");
$("attachBtn").onclick = () => $("imageInput").click();
$("removeImage").onclick = resetImage;
$("imageInput").addEventListener("change", () => {
  const file = $("imageInput").files?.[0];
  if (!file) return;
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) { alert("Choose a JPG, PNG, or WebP image."); resetImage(); return; }
  if (file.size > 4 * 1024 * 1024) { alert("Please choose an image smaller than 4 MB."); resetImage(); return; }
  const reader = new FileReader();
  reader.onload = () => {
    selectedImage = { mimeType: file.type, data: String(reader.result).split(",")[1], preview: String(reader.result) };
    $("previewImg").src = selectedImage.preview; $("fileName").textContent = file.name; $("imagePreview").hidden = false;
  };
  reader.readAsDataURL(file);
});
document.querySelectorAll(".suggestion").forEach(btn => btn.addEventListener("click", () => { input.value = btn.dataset.prompt; input.focus(); autoResize(); }));
input.addEventListener("input", autoResize);
input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } });
function autoResize() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 160) + "px"; }

form.addEventListener("submit", async e => {
  e.preventDefault();
  if (busy) return;
  const prompt = input.value.trim();
  if (!prompt && !selectedImage) return;
  if (!currentChat()) createChat();
  const chat = currentChat();
  const imageSnapshot = selectedImage ? { ...selectedImage } : null;
  const visiblePrompt = prompt || "Please explain this image.";
  if (chat.messages.length === 0) chat.title = visiblePrompt.slice(0, 36);
  chat.messages.push({ role: "user", text: visiblePrompt, imageData: imageSnapshot?.preview || null });
  addMessage("user", visiblePrompt, imageSnapshot?.preview || null);
  welcome.hidden = true; input.value = ""; autoResize(); resetImage();
  const typing = addMessage("assistant", "");
  typing.querySelector(".bubble").innerHTML = '<div class="typing"><span></span><span></span><span></span> Thinking</div>';
  busy = true; $("sendBtn").disabled = true; renderHistory();
  try {
    if (!apiBase && location.protocol === "https:" && location.hostname === "localhost") {
      throw new Error("Connect Mark1ai to its HTTPS AI server first. Set MARK1AI_API_BASE in public/backend-config.js and rebuild the Android app.");
    }
    const prior = chat.messages.slice(0, -1).slice(-10).map(m => ({ role: m.role === "assistant" ? "model" : "user", text: m.text }));
    const payload = { prompt: visiblePrompt, messages: prior };
    if (imageSnapshot) payload.image = { mimeType: imageSnapshot.mimeType, data: imageSnapshot.data };
    const response = await fetch(`${apiBase}/api/chat`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || "Request failed. Please try again.");
    typing.remove();
    chat.messages.push({ role: "assistant", text: data.answer });
    addMessage("assistant", data.answer);
    saveChats();
  } catch (err) {
    typing.remove();
    addMessage("assistant", err.message || "Unable to connect. Check your connection and try again.");
    const last = chat.messages[chat.messages.length - 1];
    if (last?.role === "user") last.failed = true;
    saveChats();
  } finally {
    busy = false; $("sendBtn").disabled = false; input.focus(); renderHistory();
  }
});
(async function init() {
  await loadConfig();
  if (chats.length) currentChatId = chats[0].id; else createChat();
  renderChat(); renderHistory();
})();