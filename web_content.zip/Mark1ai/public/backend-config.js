// Android build setting: replace with your deployed backend HTTPS origin.
// Example: window.MARK1AI_API_BASE = "https://mark1ai-api.example.com";
// Leave blank for browser development on the same origin.
window.MARK1AI_API_BASE = "";
