# Angelcraftini Copienini v1.1
Rediseño horizontal con personaje 2D, controles táctiles y de teclado, monedas, enemigos, vidas, checkpoints, puntuación y récord local.

Archivos: index.html, game.js, style.css, manifest.json.
