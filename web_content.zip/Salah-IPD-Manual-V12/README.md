# Salah IPD Manual V12

V12 is based on the V8/V10 measurement engine and keeps the same measurement calculation.

Added/kept without changing the calculation:
- Patient name and result name
- PDF print/save sheet
- Measurement quality notice
- IPD measurement line with numeric label
- Zoom and pan
- Movable/deletable manual points
- Front-camera mirror
- Arabic/English and dark mode
- WhatsApp contact button (phone number hidden in the visible UI)

Important: the measurement engine was intentionally not replaced with the V11 perspective experiment. V8/V10 remains the reference engine.
