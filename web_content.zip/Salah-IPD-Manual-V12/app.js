(() => {
const $ = id => document.getElementById(id);
const video=$('video'), canvas=$('photoCanvas'), ctx=canvas.getContext('2d'), live=$('liveOverlay'), lctx=live.getContext('2d');
let stream=null, facing='user', captured=false, points=Array(5).fill(null), image=null, lang='ar';
let dragging=-1, vision=null, visionTimer=null, lastVideoTime=-1, capturedVision=null, precisionFactor=1;
let zoom=1, panX=0, panY=0, pointers=new Map(), pinchStartDist=0, pinchStartZoom=1, pinchStartMid=null, pinchStartPan=null, panning=false, panStart=null, imageLayer=null;
const steps={
 ar:['اضغط على طرف الكارت الأيسر','اضغط على طرف الكارت الأيمن (عرض الكارت 84 مم)','حدد مركز بؤبؤ عين المريض اليمنى','حدد مركز بؤبؤ عين المريض اليسرى','حدد منتصف الوجه بين العينين'],
 en:['Tap the left edge of the calibration card','Tap the right edge of the card (card width is 84 mm)','Mark the patient’s right pupil center','Mark the patient’s left pupil center','Mark the facial midline between the eyes']
};
const names={ar:['كارت — يسار','كارت — يمين','بؤبؤ — يمين','بؤبؤ — يسار','منتصف الوجه'],en:['Card — left','Card — right','Pupil — right','Pupil — left','Face midline']};
const translations={
 ar:{subtitle:'قياس المسافة بين الحدقتين',title:'قياس IPD يدويًا',intro:'صوّر الوجه مع كارت المعايرة، ثم حدّد النقاط بنفسك على الصورة.',cameraTitle:'1. التصوير',cameraOff:'الكاميرا متوقفة',cameraOn:'الكاميرا تعمل',guide:'ضع العينين والكارت داخل الإطار',start:'تشغيل الكاميرا',switch:'تبديل الكاميرا',capture:'التقاط الصورة',stop:'إيقاف',cameraHint:'لو طلب المتصفح إذن الكاميرا، اختر سماح. يلزم فتح الصفحة عبر HTTPS.',pointsTitle:'2. تحديد النقاط على الصورة',waiting:'بانتظار الصورة',emptyTitle:'لم تلتقط صورة بعد',emptyText:'التقط صورة أولًا، وستظهر هنا لتحديد النقاط.',undo:'تراجع عن آخر نقطة',reset:'مسح النقاط',retake:'إعادة التصوير',cardWidth:'عرض الكارت الحقيقي (مم)',resultHint:'القياس يعتمد على تحديدك للنقاط وعلى ظهور الكارت والعينين تقريبًا في نفس مستوى الصورة. يتم تصحيح فرق المسافة بين الكارت والعينين تلقائيًا عند اكتشاف القزحية. للحصول على أفضل دقة اجعل الكارت قريبًا من مستوى العينين.',howTitle:'ترتيب النقاط',p1:'طرف الكارت الأيسر',p2:'طرف الكارت الأيمن (المسافة بينهما 84 مم)',p3:'مركز بؤبؤ عين المريض اليمنى',p4:'مركز بؤبؤ عين المريض اليسرى',p5:'منتصف الوجه بين العينين (لحساب RPD وLPD)',footer:'Salah IPD · معالجة الصورة داخل المتصفح',needPhoto:'التقط صورة أولًا',done:'تم تحديد كل النقاط',remaining:'النقطة التالية',error:'تعذر تشغيل الكاميرا. تأكد من إذن الكاميرا وافتح الموقع عبر HTTPS.',notReady:'الكاميرا لم تبدأ بعد',delete:'حذف',vision:'إضاءة خفيفة عند مركز البؤبؤ',patientName:'اسم المريض',patientResult:'اسم المريض',distanceOk:'المسافة مناسبة',distanceAdjust:'قرّب أو بعّد قليلًا',distanceNear:'قرّب الهاتف',distanceFar:'ابعد الهاتف'},
 en:{subtitle:'Pupillary distance measurement',title:'Manual IPD Measurement',intro:'Take a photo with the calibration card, then mark the points yourself.',cameraTitle:'1. Camera',cameraOff:'Camera is off',cameraOn:'Camera is running',guide:'Keep both eyes and the card inside the frame',start:'Start camera',switch:'Switch camera',capture:'Capture photo',stop:'Stop',cameraHint:'Allow camera access if prompted. This page must be opened over HTTPS.',pointsTitle:'2. Mark points on the photo',waiting:'Waiting for photo',emptyTitle:'No photo captured',emptyText:'Capture a photo first; it will appear here for marking.',undo:'Undo last point',reset:'Clear points',retake:'Retake photo',cardWidth:'Actual card width (mm)',resultHint:'The measurement uses your marked points and the known card width. The app corrects for the depth difference between the card and the eyes when iris size can be detected. For best accuracy, keep the card close to the eye plane.',howTitle:'Point order',p1:'Left edge of card',p2:'Right edge of card (distance between them is 84 mm)',p3:'Patient’s right pupil center',p4:'Patient’s left pupil center',p5:'Facial midline between the eyes (for RPD and LPD)',footer:'Salah IPD · Image processing stays in your browser',needPhoto:'Capture a photo first',done:'All points marked',remaining:'Next point',error:'Could not start the camera. Check permission and open this site over HTTPS.',notReady:'Camera has not started',delete:'Delete',vision:'Soft light at pupil center',patientName:'Patient name',patientResult:'Patient name',distanceOk:'Good distance',distanceAdjust:'Adjust slightly',distanceNear:'Move closer',distanceFar:'Move farther'}
};
function tr(k){return translations[lang][k]||k}
function applyLanguage(){
 document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';
 document.querySelectorAll('[data-i18n]').forEach(el=>{el.textContent=tr(el.dataset.i18n)});
 $('langBtn').textContent=lang==='ar'?'EN':'عربي';$('cameraState').textContent=stream?tr('cameraOn'):tr('cameraOff');$('patientName').placeholder=lang==='ar'?'اكتب اسم المريض':'Enter patient name';updateResultPatient();
 renderInstruction();renderPointControls();
}
async function startCamera(){
 if(stream) stream.getTracks().forEach(t=>t.stop());
 try{
  stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:facing},width:{ideal:1280},height:{ideal:960}}});
  video.srcObject=stream;await video.play();
  video.classList.toggle('mirror', facing==='user');
  live.classList.toggle('mirror', facing==='user');
  $('cameraState').textContent=tr('cameraOn');$('captureBtn').disabled=false;$('stopBtn').disabled=false;
  startVision();
 }catch(e){stream=null;$('cameraState').textContent=tr('error');$('captureBtn').disabled=true;alert(tr('error'));}
}
function stopCamera(){if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}video.srcObject=null;$('cameraState').textContent=tr('cameraOff');$('captureBtn').disabled=true;$('stopBtn').disabled=true;stopVision();clearLive()}
$('startBtn').addEventListener('click',startCamera);
$('switchBtn').addEventListener('click',async()=>{facing=facing==='user'?'environment':'user';if(stream)await startCamera();});
$('stopBtn').addEventListener('click',stopCamera);
$('captureBtn').addEventListener('click',()=>{
 if(!stream||!video.videoWidth){alert(tr('notReady'));return;}
 canvas.width=video.videoWidth;canvas.height=video.videoHeight;
 ctx.save();
 if(facing==='user'){ctx.translate(canvas.width,0);ctx.scale(-1,1);}
 ctx.drawImage(video,0,0,canvas.width,canvas.height);
 ctx.restore();
 image=ctx.getImageData(0,0,canvas.width,canvas.height);captured=true;points=Array(5).fill(null);
 zoom=1; panX=0; panY=0; pointers.clear(); dragging=-1; panning=false;
 imageLayer=document.createElement('canvas'); imageLayer.width=canvas.width; imageLayer.height=canvas.height; imageLayer.getContext('2d').putImageData(image,0,0);
 capturedVision=null; precisionFactor=1;
 runCapturedVision();
 $('emptyState').classList.add('hidden');$('editor').classList.remove('hidden');$('stepPill').textContent=tr('remaining')+' 1 / 5';renderCanvas();renderInstruction();renderPointControls();
 $('measurePanel').scrollIntoView({behavior:'smooth',block:'start'});
});
function renderInstruction(){
 const n=points.findIndex(p=>!p); if(!captured){$('instruction').textContent=tr('needPhoto');return;}
 $('instruction').textContent=n===-1?tr('done'):`${tr('remaining')} ${n+1}/5 — ${steps[lang][n]}`;
 $('stepPill').textContent=n===-1?tr('done'):`${points.filter(Boolean).length}/5`;
}
function renderPointControls(){
 const box=$('pointControls'); if(!box)return; box.innerHTML='';
 points.forEach((p,i)=>{if(!p)return;const chip=document.createElement('div');chip.className='point-chip';const label=document.createElement('span');label.textContent=`${i+1}. ${names[lang][i]}`;const b=document.createElement('button');b.type='button';b.textContent='×';b.title=tr('delete');b.addEventListener('click',()=>{points[i]=null;renderCanvas();renderInstruction();renderPointControls();calculate()});chip.append(label,b);box.appendChild(chip)});
}
function renderCanvas(){
 if(!image||!imageLayer)return;
 ctx.clearRect(0,0,canvas.width,canvas.height);
 ctx.save();
 ctx.translate(panX,panY); ctx.scale(zoom,zoom);
 ctx.drawImage(imageLayer,0,0);
 const colors=['#ffd43b','#ffd43b','#32d583','#32d583','#ff5b6e'];
 points.forEach((p,i)=>{
  if(!p)return;
  const r=Math.max(2.2,canvas.width*.0025);
  ctx.save();
  ctx.fillStyle=colors[i];ctx.beginPath();ctx.arc(p.x,p.y,r,0,Math.PI*2);ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.95)';ctx.lineWidth=Math.max(1,canvas.width*.0008);ctx.stroke();
  // Minimal leader line + compact numbered tag. The point itself stays tiny and precise.
  const side=p.x<canvas.width/2?1:-1;
  const len=Math.max(18,canvas.width*.018), lift=Math.max(12,canvas.width*.012);
  const ex=p.x+side*len,ey=p.y-lift;
  ctx.strokeStyle='rgba(255,255,255,.82)';ctx.lineWidth=Math.max(.9,canvas.width*.0008);
  ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(ex,ey);ctx.stroke();
  const fs=Math.max(9,canvas.width*.0105), tw=fs*1.35, th=fs*1.35;
  ctx.fillStyle='rgba(7,17,31,.78)';ctx.beginPath();ctx.roundRect(ex-tw/2,ey-th/2,tw,th,Math.max(2,fs*.22));ctx.fill();
  ctx.fillStyle='#fff';ctx.font=`700 ${fs}px Arial`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(String(i+1),ex,ey);
  ctx.restore();
 });
 const a=points[2],b=points[3];if(a&&b){
  ctx.strokeStyle='#32d583';ctx.lineWidth=Math.max(1.5,canvas.width*.0018);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();
  const mx=(a.x+b.x)/2,my=(a.y+b.y)/2;
  const value=$('ipd')?.textContent;
  const label=(value&&value!=='—')?`IPD ${value} mm`:'IPD';
  const fs=Math.max(10,canvas.width*.0115),pad=fs*.55,th=fs*1.55;
  ctx.font=`700 ${fs}px Arial`;
  const tw=ctx.measureText(label).width+pad*2;
  const side=my<canvas.height*.35?1:-1,ly=my+side*(th+8);
  ctx.fillStyle='rgba(7,17,31,.84)';ctx.beginPath();ctx.roundRect(mx-tw/2,ly-th/2,tw,th,Math.max(3,fs*.25));ctx.fill();
  ctx.fillStyle='#fff';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(label,mx,ly);
 }
 ctx.restore();
}
function screenToImage(e){
 const r=canvas.getBoundingClientRect();
 const sx=(e.clientX-r.left)/r.width*canvas.width, sy=(e.clientY-r.top)/r.height*canvas.height;
 return {x:(sx-panX)/zoom,y:(sy-panY)/zoom};
}
function imageToScreen(p){return {x:p.x*zoom+panX,y:p.y*zoom+panY};}
function canvasPoint(e){return screenToImage(e)}
function nearestPoint(p){
 let best=-1,d=Infinity;
 points.forEach((q,i)=>{if(!q)return;const z=Math.hypot(p.x-q.x,p.y-q.y);if(z<d){d=z;best=i}});
 return d<Math.max(26/zoom,canvas.width*.025/zoom)?best:-1
}
function clampPan(){
 if(!canvas.width||!canvas.height)return;
 const maxX=(zoom-1)*canvas.width*.55, maxY=(zoom-1)*canvas.height*.55;
 panX=Math.max(-maxX,Math.min(maxX,panX));panY=Math.max(-maxY,Math.min(maxY,panY));
}
function setZoom(z,cx=canvas.width/2,cy=canvas.height/2){
 const old=zoom; zoom=Math.max(1,Math.min(5,z));
 const ix=(cx-panX)/old, iy=(cy-panY)/old; panX=cx-ix*zoom; panY=cy-iy*zoom; clampPan(); renderCanvas();
}
function pointerMid(){const a=[...pointers.values()][0],b=[...pointers.values()][1];return {x:(a.x+b.x)/2,y:(a.y+b.y)/2}}
function pointerDist(){const a=[...pointers.values()][0],b=[...pointers.values()][1];return Math.hypot(a.x-b.x,a.y-b.y)}
function clientToCanvas(x,y){const r=canvas.getBoundingClientRect();return {x:(x-r.left)/r.width*canvas.width,y:(y-r.top)/r.height*canvas.height}}
canvas.addEventListener('pointerdown',e=>{
 if(!captured)return; e.preventDefault(); canvas.setPointerCapture(e.pointerId); pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pointers.size===2){dragging=-1;panning=false;pinchStartDist=pointerDist();pinchStartZoom=zoom;const sm=pointerMid();pinchStartMid=clientToCanvas(sm.x,sm.y);pinchStartPan={x:panX,y:panY};return;}
 const p=canvasPoint(e),i=nearestPoint(p);
 if(i>=0){dragging=i;return;}
 if(zoom>1){panning=true;panStart={x:e.clientX,y:e.clientY,panX,panY};return;}
 const next=points.findIndex(q=>!q);if(next<0)return;points[next]=p;renderCanvas();renderInstruction();renderPointControls();calculate();
});
canvas.addEventListener('pointermove',e=>{
 if(!captured)return;
 if(pointers.has(e.pointerId))pointers.set(e.pointerId,{x:e.clientX,y:e.clientY});
 if(pointers.size===2){
  const d=pointerDist(); const m=pointerMid();
  const z=pinchStartZoom*(d/Math.max(1,pinchStartDist));
  zoom=Math.max(1,Math.min(5,z));
  const mc=clientToCanvas(m.x,m.y); const factor=zoom/pinchStartZoom;
  panX=mc.x-(pinchStartMid.x-pinchStartPan.x)*factor; panY=mc.y-(pinchStartMid.y-pinchStartPan.y)*factor; clampPan(); renderCanvas(); return;
 }
 if(dragging>=0){points[dragging]=canvasPoint(e);renderCanvas();calculate();return;}
 if(panning){panX=panStart.panX+(e.clientX-panStart.x)*canvas.width/canvas.getBoundingClientRect().width;panY=panStart.panY+(e.clientY-panStart.y)*canvas.height/canvas.getBoundingClientRect().height;clampPan();renderCanvas();}
});
function endPointer(e){pointers.delete(e.pointerId);if(dragging>=0){dragging=-1;renderInstruction();renderPointControls();calculate()}if(pointers.size===0)panning=false;}
canvas.addEventListener('pointerup',endPointer);canvas.addEventListener('pointercancel',endPointer);
canvas.addEventListener('wheel',e=>{if(!captured)return;e.preventDefault();const r=canvas.getBoundingClientRect();const cx=(e.clientX-r.left)/r.width*canvas.width,cy=(e.clientY-r.top)/r.height*canvas.height;setZoom(zoom*(e.deltaY<0?1.18:.85),cx,cy)},{passive:false});
function updateResultPatient(){const n=($('patientName')?.value||'').trim();if($('resultPatientName'))$('resultPatientName').textContent=n||'—'}
$('patientName')?.addEventListener('input',updateResultPatient);
function baseCalculate(){
 const val=Number($('cardWidth').value),a=points[0],b=points[1],r=points[2],l=points[3],m=points[4];
 if(!a||!b||!r||!l||!Number.isFinite(val)||val<=0){$('ipd').textContent='—';$('rpd').textContent='—';$('lpd').textContent='—';return}
 // Base scale from the known 84 mm card edge.
 const cardDx=b.x-a.x, cardDy=b.y-a.y, cardPx=Math.hypot(cardDx,cardDy);
 if(cardPx<10){$('ipd').textContent='—';$('rpd').textContent='—';$('lpd').textContent='—';return}
 const ux=cardDx/cardPx, uy=cardDy/cardPx, baseMmPerPx=val/cardPx;
 const signed=(p,q)=>(p.x-q.x)*ux+(p.y-q.y)*uy;
 // If iris landmarks are available, correct the scale for the fact that the card and eyes
 // may be at different camera distances. The correction is derived from the known
 // physical iris diameter (~11.7 mm), not an arbitrary +mm fudge factor.
 const mmPerPx=baseMmPerPx*precisionFactor;
 const ipd=Math.abs(signed(l,r))*mmPerPx; $('ipd').textContent=ipd.toFixed(1);
 if(m){$('rpd').textContent=Math.abs(signed(r,m)*mmPerPx).toFixed(1);$('lpd').textContent=Math.abs(signed(l,m)*mmPerPx).toFixed(1)}else{$('rpd').textContent='—';$('lpd').textContent='—'}
}

function calculate(){ baseCalculate(); updateQualityNotice(); }
$('cardWidth').addEventListener('input',calculate);
$('undoBtn').addEventListener('click',()=>{for(let i=4;i>=0;i--)if(points[i]){points[i]=null;break}renderCanvas();renderInstruction();renderPointControls();calculate()});
$('resetPointsBtn').addEventListener('click',()=>{points=Array(5).fill(null);renderCanvas();renderInstruction();renderPointControls();calculate()});
$('retakeBtn').addEventListener('click',()=>{$('editor').classList.add('hidden');$('emptyState').classList.remove('hidden');captured=false;points=Array(5).fill(null);image=null;capturedVision=null;precisionFactor=1;$('stepPill').textContent=tr('waiting');});
$('langBtn').addEventListener('click',()=>{lang=lang==='ar'?'en':'ar';applyLanguage()});
$('themeBtn').addEventListener('click',()=>{document.body.classList.toggle('dark');const dark=document.body.classList.contains('dark');$('themeBtn').textContent=dark?'☀':'☾'});
async function runCapturedVision(){
 // Reuse the same MediaPipe model if it is already loaded. Otherwise load it in IMAGE mode.
 try{
  const mod=await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/vision_bundle.mjs');
  const {FaceLandmarker,FilesetResolver}=mod;
  const fs=await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm');
  let lm=null;
  if(vision) lm=vision;
  else{
   const urls=['https://github.com/sanderdesnaijer/mediapipe-model-mirrors/releases/download/v1/face_landmarker.task','https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task'];
   for(const modelAssetPath of urls){
    try{lm=await FaceLandmarker.createFromOptions(fs,{baseOptions:{modelAssetPath,delegate:'GPU'},runningMode:'IMAGE',numFaces:1,minFaceDetectionConfidence:.5,minFacePresenceConfidence:.5,minTrackingConfidence:.5});break}catch(e){}
   }
  }
  if(!lm||!image)return;
  const ibmp=await createImageBitmap(canvas);
  const res=lm.detect(ibmp);
  if(ibmp.close)ibmp.close();
  const pts=res?.faceLandmarks?.[0];
  if(!pts)return;
  const irisD=[];
  // Horizontal iris diameter: left/right boundary points around each iris.
  [[468,469,471],[473,474,476]].forEach(([c,a,b])=>{
   const pa=pts[a],pb=pts[b],pc=pts[c];
   if(pa&&pb&&pc){
    const d=Math.hypot((pa.x-pb.x)*canvas.width,(pa.y-pb.y)*canvas.height);
    if(d>2)irisD.push(d);
   }
  });
  if(!irisD.length)return;
  const irisPx=irisD.reduce((x,y)=>x+y,0)/irisD.length;
  const physicalIrisMm=11.7;
  const baseCardPx=Math.hypot(points[1].x-points[0].x);
  if(baseCardPx<10||irisPx<2)return;
  const ratio=(physicalIrisMm*baseCardPx)/(Number($('cardWidth').value||84)*irisPx);
  // Keep the correction within a conservative range so a poor iris detection cannot
  // create a huge jump. The user's manual points remain the final measurement points.
  precisionFactor=Math.max(.80,Math.min(1.25,ratio));
  capturedVision={irisPx,precisionFactor};
  calculate();
 }catch(e){
  precisionFactor=1;
  calculate();
 }
}
async function startVision(){
 if(vision||visionTimer)return;
 try{
  const mod=await import('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/vision_bundle.mjs');
  const {FaceLandmarker,FilesetResolver}=mod;const fs=await FilesetResolver.forVisionTasks('https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.35/wasm');
  let lm=null;const urls=['https://github.com/sanderdesnaijer/mediapipe-model-mirrors/releases/download/v1/face_landmarker.task','https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task'];
  for(const modelAssetPath of urls){try{lm=await FaceLandmarker.createFromOptions(fs,{baseOptions:{modelAssetPath,delegate:'GPU'},runningMode:'VIDEO',numFaces:1,minFaceDetectionConfidence:.5,minFacePresenceConfidence:.5,minTrackingConfidence:.5});break}catch(e){}}
  if(!lm){visionTimer=setTimeout(()=>{visionTimer=null},100);return}
  vision=lm;visionLoop();
 }catch(e){visionTimer=setTimeout(()=>{visionTimer=null},100)}
}
function visionLoop(){
 if(!vision||!stream)return;requestAnimationFrame(visionLoop);if(video.readyState<2||video.currentTime===lastVideoTime)return;lastVideoTime=video.currentTime;
 try{const res=vision.detectForVideo(video,performance.now());drawPupilGlow(res)}catch(e){}
}
function drawPupilGlow(res){
 live.width=video.videoWidth||video.clientWidth;live.height=video.videoHeight||video.clientHeight;lctx.clearRect(0,0,live.width,live.height);
 if(!res?.faceLandmarks?.length){return;}const pts=res.faceLandmarks[0];const ids=[468,473];
 ids.forEach(id=>{const p=pts[id];if(!p)return;const x=p.x*live.width,y=p.y*live.height,r=Math.max(7,live.width*.010);const g=lctx.createRadialGradient(x,y,1,x,y,r*2.7);g.addColorStop(0,'rgba(255,255,255,.8)');g.addColorStop(.25,'rgba(120,240,210,.42)');g.addColorStop(1,'rgba(120,240,210,0)');lctx.fillStyle=g;lctx.beginPath();lctx.arc(x,y,r*2.7,0,Math.PI*2);lctx.fill();lctx.strokeStyle='rgba(255,255,255,.45)';lctx.lineWidth=2;lctx.beginPath();lctx.arc(x,y,r,0,Math.PI*2);lctx.stroke()});
}
function clearLive(){if(live){live.width=video.videoWidth||1;live.height=video.videoHeight||1;lctx.clearRect(0,0,live.width,live.height)}}
function stopVision(){vision=null;lastVideoTime=-1;clearLive()}
applyLanguage();

function updateQualityNotice(){
 const box=$('qualityNotice'); if(!box)return;
 if(!points[0]||!points[1]||!points[2]||!points[3]){box.classList.add('hidden');return}
 const cardPx=Math.hypot(points[1].x-points[0].x);
 let msg=''; let good=false;
 if(cardPx<120) msg=tr('qualityCardSmall');
 else if(capturedVision && (capturedVision.precisionFactor<.90 || capturedVision.precisionFactor>1.10)) msg=tr('qualityDepth');
 else {msg=tr('qualityGood');good=true;}
 box.textContent=(good?'✓ ':'⚠ ')+msg;
 box.classList.remove('hidden'); box.classList.toggle('good',good);
}
function refreshPrintSheet(){
 const name=(($('patientName')?.value||'').trim())||'—';
 $('printPatient').textContent=name;
 $('printDate').textContent=new Intl.DateTimeFormat(lang==='ar'?'ar-EG':'en-US',{dateStyle:'medium',timeStyle:'short'}).format(new Date());
 $('printIPD').textContent=$('ipd').textContent; $('printRPD').textContent=$('rpd').textContent; $('printLPD').textContent=$('lpd').textContent;
 try{$('printImage').src=canvas.toDataURL('image/jpeg',.92)}catch(e){}
}
function savePdf(){
 if($('ipd').textContent==='—'){alert(tr('needPhoto'));return;}
 refreshPrintSheet(); window.print();
}
$('pdfBtn')?.addEventListener('click',savePdf);

})();
