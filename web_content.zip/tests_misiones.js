const fs=require('fs'),h=fs.readFileSync(__dirname+'/index.html','utf8'),sc=[...h.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
const BAL=new Function(sc[0]+';return BAL')();let ok=0,bad=0;const T=(n,c)=>{c?ok++:(bad++,console.log('FALLA',n))};
T('nivel 1 con 0 xp',BAL.accLv(0)===1);
for(const l of [5,12,20]){T('accLv en cum('+l+')',BAL.accLv(BAL.accCum(l))===l);T('accLv justo antes',BAL.accLv(BAL.accCum(l)-1)===l-1)}
T('Normal desbloqueado en nivel 1',BAL.DIF[0].req<=1);
T('requisitos crecientes',BAL.DIF.every((d,i)=>!i||d.req>BAL.DIF[i-1].req));
const tot=BAL.MI.reduce((a,q)=>a+q.xp,0);console.log('XP total misiones',tot,'| XP para nivel 5/12/20:',[5,12,20].map(BAL.accCum),'| nivel máx alcanzable',BAL.accLv(tot));
T('Colapso alcanzable en <=8 semanas (solo semanales)',tot*8>=BAL.accCum(20));
T('ids únicos',new Set(BAL.MI.map(q=>q.id)).size===BAL.MI.length);
// Sin las misiones de dificultad (que exigen haberla desbloqueado) también debe llegarse a Colapso
const base=BAL.MI.filter(q=>!/^w\d/.test(q.k)).reduce((a,q)=>a+q.xp,0);console.log('XP sin misiones de dificultad',base,'-> nivel',BAL.accLv(base));
T('Colapso alcanzable en <=3 semanas sin misiones de dificultad',BAL.accLv(base*3)>=20);
T('diarias: 3 distintas y estables por fecha',(()=>{const a=BAL.dailyPick('2026-10-29'),b=BAL.dailyPick('2026-10-29');return a.length===3&&new Set(a.map(q=>q.k)).size===3&&JSON.stringify(a)===JSON.stringify(b)})());
T('semana empieza en lunes',BAL.weekKey(new Date(2026,9,29))==='2026-10-26'&&BAL.weekKey(new Date(2026,10,1))==='2026-10-26'&&BAL.weekKey(new Date(2026,10,2))==='2026-11-02');
T('misiones por dificultad no requeridas para desbloquearla (Difícil: w1 exige estar en Nv5)',BAL.accLv(BAL.MI.filter(q=>!/^w\d/.test(q.k)&&q.xp<=60).reduce((a,q)=>a+q.xp,0))>=1);
T('cap ACC_MAX',BAL.accLv(1e9)===BAL.ACC_MAX);T('entrada basura',BAL.accLv('x')===1&&BAL.accLv(-5)===1);
console.log(ok,'ok',bad,'fallos');
