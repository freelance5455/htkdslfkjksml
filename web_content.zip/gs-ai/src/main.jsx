import React, { useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Sparkles, MessageCircle, Image as ImageIcon, Search, PenLine, Mic, Send, Plus, LogOut, Menu, X, Bot, User, Download, LoaderCircle, Globe2, ArrowUpRight } from 'lucide-react';
import './style.css';

const API = import.meta.env.VITE_API_URL || '';
function App() {
  const [token, setToken] = useState(localStorage.getItem('gsai_token') || '');
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('gsai_user') || 'null'));
  const [authMode, setAuthMode] = useState('login');
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' });
  const [tab, setTab] = useState('chat');
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([]);
  const [conversationId, setConversationId] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [research, setResearch] = useState(false);
  const [busy, setBusy] = useState(false);
  const [image, setImage] = useState('');
  const [imagePrompt, setImagePrompt] = useState('');
  const [error, setError] = useState('');
  const [sidebar, setSidebar] = useState(false);
  const headers = { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) };

  async function request(path, body, method='POST') {
    const r = await fetch(`${API}/api${path}`, { method, headers, ...(body ? { body: JSON.stringify(body) } : {}) });
    const data = await r.json();
    if (!r.ok) throw new Error(data.error || 'Request failed');
    return data;
  }
  async function refreshConversations() {
    try { setConversations(await request('/conversations', null, 'GET')); } catch {}
  }
  useEffect(() => { if (token) refreshConversations(); }, [token]);
  async function authenticate(e) {
    e.preventDefault(); setError(''); setBusy(true);
    try {
      const data = await request(`/auth/${authMode}`, authForm);
      setToken(data.token); setUser(data.user);
      localStorage.setItem('gsai_token', data.token); localStorage.setItem('gsai_user', JSON.stringify(data.user));
    } catch (e) { setError(e.message); } finally { setBusy(false); }
  }
  function logout() {
    setToken(''); setUser(null); setMessages([]); setConversationId(null);
    localStorage.removeItem('gsai_token'); localStorage.removeItem('gsai_user');
  }
  function newChat() { setMessages([]); setConversationId(null); setTab('chat'); setSidebar(false); setError(''); }
  async function sendMessage(e) {
    e?.preventDefault(); if (!prompt.trim() || busy) return;
    const text = prompt.trim(); setPrompt(''); setMessages(m => [...m, { role: 'user', content: text }]); setBusy(true); setError('');
    try {
      const data = await request('/chat', { message: text, conversationId, research });
      setConversationId(data.conversationId); setMessages(m => [...m, { role: 'assistant', content: data.answer }]); refreshConversations();
    } catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function generateImage(e) {
    e.preventDefault(); if (!imagePrompt.trim() || busy) return;
    setBusy(true); setError(''); setImage('');
    try { const data = await request('/images', { prompt: imagePrompt }); setImage(data.image); }
    catch (e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function openConversation(id) {
    setBusy(true); setError('');
    try { const data = await request(`/conversations/${id}`, null, 'GET'); setConversationId(id); setMessages(data.messages); setTab('chat'); setSidebar(false); }
    catch (e) { setError(e.message); } finally { setBusy(false); }
  }

  if (!token) return <div className="auth-page"><div className="auth-card"><Brand/><p className="muted">Your all-in-one AI assistant</p><h2>{authMode === 'login' ? 'Welcome back' : 'Create your account'}</h2><form onSubmit={authenticate} className="stack">
    {authMode === 'register' && <input placeholder="Your name" value={authForm.name} onChange={e=>setAuthForm({...authForm,name:e.target.value})} required/>}
    <input type="email" placeholder="Email address" value={authForm.email} onChange={e=>setAuthForm({...authForm,email:e.target.value})} required/>
    <input type="password" placeholder="Password (8+ characters)" value={authForm.password} onChange={e=>setAuthForm({...authForm,password:e.target.value})} minLength="8" required/>
    {error && <p className="error">{error}</p>}<button className="primary full" disabled={busy}>{busy ? 'Please wait…' : authMode === 'login' ? 'Sign in' : 'Create account'}</button>
  </form><p className="muted center">{authMode === 'login' ? "New to GS AI?" : 'Already have an account?'} <button className="link" onClick={()=>{setAuthMode(authMode==='login'?'register':'login');setError('')}}>{authMode==='login'?'Create account':'Sign in'}</button></p><small className="muted">By continuing, you agree to use GS AI responsibly.</small></div></div>;

  return <div className="app-shell">
    <aside className={`sidebar ${sidebar?'show':''}`}><div className="side-top"><Brand/><button className="icon-btn mobile-only" onClick={()=>setSidebar(false)}><X/></button></div>
      <button className="new-chat" onClick={newChat}><Plus size={18}/> New chat</button>
      <div className="nav-label">WORKSPACE</div>
      <button className={`nav-item ${tab==='chat'?'active':''}`} onClick={()=>setTab('chat')}><MessageCircle/> AI Chat</button>
      <button className={`nav-item ${tab==='image'?'active':''}`} onClick={()=>setTab('image')}><ImageIcon/> Image Generator</button>
      <button className={`nav-item ${tab==='research'?'active':''}`} onClick={()=>{setTab('research');setResearch(true)}}><Search/> Deep Research</button>
      <button className={`nav-item ${tab==='writer'?'active':''}`} onClick={()=>setTab('writer')}><PenLine/> AI Writer</button>
      <div className="nav-label history-label">RECENT CHATS</div>
      <div className="history">{conversations.map(c=><button key={c.id} onClick={()=>openConversation(c.id)}>{c.title}</button>)}</div>
      <div className="side-bottom"><div className="profile"><div className="avatar">{user?.name?.[0]?.toUpperCase() || 'U'}</div><div className="profile-text"><b>{user?.name}</b><small>{user?.email}</small></div><button className="icon-btn" onClick={logout} title="Sign out"><LogOut size={17}/></button></div></div>
    </aside>
    {sidebar && <div className="scrim" onClick={()=>setSidebar(false)}/>}
    <main className="main"><header className="topbar"><button className="icon-btn mobile-only" onClick={()=>setSidebar(true)}><Menu/></button><div className="crumb">GS AI <span>/</span> {tab==='image'?'Image Generator':tab==='research'?'Deep Research':tab==='writer'?'AI Writer':'AI Chat'}</div><div className="top-right"><span className="online-dot"/> AI ready</div></header>
      <section className={`workspace ${tab==='chat'||tab==='research'?'chat-workspace':''}`}>
        {(tab==='chat'||tab==='research') ? <><div className="chat-content">
          {messages.length===0 ? <div className="welcome"><div className="sparkle-orb"><Sparkles size={27}/></div><p className="eyebrow">YOUR AI, WITHOUT LIMITS</p><h1>What can I help<br/><span>you with today?</span></h1><p className="muted">Ask in Telugu, English, Hindi, or your preferred language.</p><div className="suggestions">{['Explain a complex topic simply','Research the latest technology trends','Write a professional news article','Translate this into Telugu'].map((s,i)=><button key={i} onClick={()=>setPrompt(s)}><Sparkles size={15}/>{s}<ArrowUpRight size={14}/></button>)}</div></div> :
          <div className="messages">{messages.map((m,i)=><div className={`message ${m.role}`} key={i}><div className="message-icon">{m.role==='assistant'?<Bot size={18}/>:<User size={18}/>}</div><div className="message-body"><b>{m.role==='assistant'?'GS AI':'You'}</b><p>{m.content}</p></div></div>)}{busy&&<div className="message assistant"><div className="message-icon"><Bot size={18}/></div><div className="message-body"><b>GS AI</b><p className="typing">Thinking…</p></div></div>}</div>}
        </div><div className="composer-wrap"><div className="composer-tools"><label className="research-toggle"><input type="checkbox" checked={research||tab==='research'} onChange={e=>setResearch(e.target.checked)}/><Search size={14}/> Web research</label><span>Answers in your language</span></div><form className="composer" onSubmit={sendMessage}><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder="Message GS AI…" rows="1" onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}}}/><button className="send-btn" disabled={!prompt.trim()||busy}><Send size={18}/></button></form><p className="disclaimer">GS AI can make mistakes. Verify important information.</p></div></> :
        <div className="tool-page"><div className="tool-heading"><div className="tool-icon"><ImageIcon/></div><p className="eyebrow">{tab==='image'?'CREATIVE STUDIO':tab==='writer'?'CONTENT STUDIO':'RESEARCH LAB'}</p><h1>{tab==='image'?'Imagine it. Create it.':tab==='writer'?'Words that make an impact.':'Explore any topic deeply.'}</h1><p className="muted">{tab==='image'?'Turn your ideas into original AI images.':tab==='writer'?'Draft articles, captions, scripts and more with AI.':'Get researched answers with web search and source links.'}</p></div>
          {tab==='image' ? <form className="image-form" onSubmit={generateImage}><textarea value={imagePrompt} onChange={e=>setImagePrompt(e.target.value)} placeholder="Describe the image you want to create…" rows="4"/><div className="form-bottom"><span className="muted">Be descriptive for better results</span><button className="primary" disabled={busy||!imagePrompt.trim()}>{busy?<LoaderCircle className="spin"/>:<Sparkles size={17}/>} Generate image</button></div></form> :
          <div className="writer-box"><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} placeholder={tab==='writer'?'What should GS AI write for you?':'What topic should GS AI research?'} rows="4"/><button className="primary" onClick={()=>{setTab(tab==='writer'?'chat':'research');setResearch(tab!=='writer');setMessages([]);sendMessage()}} disabled={!prompt.trim()||busy}><Sparkles size={17}/> Generate</button></div>}
          {busy&&tab==='image'&&<div className="loading"><LoaderCircle className="spin"/> Creating your image…</div>}
          {error&&<p className="error">{error}</p>}
          {image&&<div className="generated-image"><img src={image} alt="AI generated"/><a className="primary download" href={image} download="gs-ai-image.png"><Download size={17}/> Download image</a></div>}
        </div>}
      </section>
    </main>
  </div>;
}
function Brand(){return <div className="brand"><div className="brand-mark"><Sparkles size={21}/></div><div><strong>GS AI</strong><small>INTELLIGENCE, REIMAGINED</small></div></div>}
createRoot(document.getElementById('root')).render(<App/>);
