# GS AI — Android + Website starter

A deployable full-stack starter for **GS AI** with:
- Responsive web app (Vite + React)
- Android wrapper (Capacitor)
- Email/password registration and login (SQLite + bcrypt + JWT)
- Multilingual AI chat
- Optional web research mode
- AI image generation
- Conversation history

## Important before public launch
This is a working starter project, not an already-hosted public service or a signed Play Store APK. You must configure an AI API key, deploy the backend, build/sign Android, and publish it. AI providers charge per use; set usage limits and monitor costs. Never expose API keys in the Android app or browser.

## Requirements
- Node.js 20+
- An OpenAI API key with access to the Responses API and image generation
- Android Studio + Android SDK for APK/AAB builds

## Run locally
1. Extract the ZIP and open the `gs-ai` folder in a terminal.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `OPENAI_API_KEY` and a long random `JWT_SECRET`.
5. Run `npm run dev`.
6. Open `http://localhost:5173`.

The API runs on port 8787. SQLite data is stored in `server/gsai.sqlite`.

## Build website
- `npm run build`
- Deploy the `dist/` folder to a static host and deploy the Express server separately.
- Set `VITE_API_URL` at build time to your public API base URL.
- Set backend `CLIENT_ORIGIN` to your deployed website origin.
- Use HTTPS in production.

For a simple single-service deployment, serve the built `dist` directory from the Express server as implemented. Set `CLIENT_ORIGIN` to your production origin.

## Build Android app
1. Set `VITE_API_URL` to your deployed HTTPS API URL (for example in a build environment variable).
2. Run `npm run android:add` once.
3. Run `npm run android:sync`.
4. Open the generated `android/` folder in Android Studio.
5. Test on physical devices, configure app signing, then build a signed APK/AAB.

Do not use `localhost` as the API URL in a Play Store build. The Android app needs to reach your deployed HTTPS backend.

## API endpoints
- `POST /api/auth/register` — `{name,email,password}`
- `POST /api/auth/login` — `{email,password}`
- `GET /api/conversations` — bearer token
- `GET /api/conversations/:id` — bearer token
- `POST /api/chat` — `{message,conversationId?,research?}` bearer token
- `POST /api/images` — `{prompt,size?}` bearer token
- `GET /api/health`

## Production checklist
Before accepting public users, add rate limiting, email verification, password reset, account deletion, moderation/safety checks, abuse reporting, backups, privacy policy, terms, age-appropriate safeguards, payment/subscription integration, analytics consent, and operational monitoring. SQLite is suitable for local testing/small single-instance use; consider managed PostgreSQL for scale. Review AI provider policies and regional data/privacy requirements.

## Brand
App name: GS AI. App ID: `com.gsai.app`.
