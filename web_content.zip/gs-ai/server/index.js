import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Database from 'better-sqlite3';
import OpenAI from 'openai';

const app = express();
const PORT = process.env.PORT || 8787;
const JWT_SECRET = process.env.JWT_SECRET;
const db = new Database('server/gsai.sqlite');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
  );
`);
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(',') || true }));
app.use(express.json({ limit: '12mb' }));

const openai = () => {
  if (!process.env.OPENAI_API_KEY) throw new Error('AI service is not configured. Add OPENAI_API_KEY to server environment.');
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
};
const auth = (req, res, next) => {
  const token = (req.headers.authorization || '').replace(/^Bearer /, '');
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch { res.status(401).json({ error: 'Please sign in again.' }); }
};
const safeError = (res, err) => {
  console.error(err);
  res.status(500).json({ error: err?.message || 'Something went wrong.' });
};

app.get('/api/health', (_req, res) => res.json({ ok: true, app: 'GS AI' }));
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password || password.length < 8) return res.status(400).json({ error: 'Enter your name, email and a password of at least 8 characters.' });
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare('INSERT INTO users (name,email,password_hash) VALUES (?,?,?)').run(name.trim(), email.toLowerCase().trim(), hash);
    const user = { id: result.lastInsertRowid, name: name.trim(), email: email.toLowerCase().trim() };
    res.json({ token: jwt.sign(user, JWT_SECRET, { expiresIn: '14d' }), user });
  } catch (e) { res.status(400).json({ error: e.code === 'SQLITE_CONSTRAINT_UNIQUE' ? 'Email is already registered.' : e.message }); }
});
app.post('/api/auth/login', async (req, res) => {
  const row = db.prepare('SELECT * FROM users WHERE email=?').get(String(req.body.email || '').toLowerCase().trim());
  if (!row || !(await bcrypt.compare(req.body.password || '', row.password_hash))) return res.status(401).json({ error: 'Incorrect email or password.' });
  const user = { id: row.id, name: row.name, email: row.email };
  res.json({ token: jwt.sign(user, JWT_SECRET, { expiresIn: '14d' }), user });
});
app.get('/api/me', auth, (req, res) => res.json({ user: req.user }));
app.get('/api/conversations', auth, (req, res) => {
  res.json(db.prepare('SELECT id,title,created_at FROM conversations WHERE user_id=? ORDER BY id DESC').all(req.user.id));
});
app.get('/api/conversations/:id', auth, (req, res) => {
  const c = db.prepare('SELECT * FROM conversations WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
  if (!c) return res.status(404).json({ error: 'Conversation not found.' });
  res.json({ ...c, messages: db.prepare('SELECT role,content,created_at FROM messages WHERE conversation_id=? ORDER BY id').all(c.id) });
});
app.post('/api/chat', auth, async (req, res) => {
  try {
    const { message, conversationId, research } = req.body;
    if (!message?.trim()) return res.status(400).json({ error: 'Write a message first.' });
    let conversation = conversationId && db.prepare('SELECT * FROM conversations WHERE id=? AND user_id=?').get(conversationId, req.user.id);
    if (!conversation) {
      const title = message.trim().slice(0, 60);
      const result = db.prepare('INSERT INTO conversations (user_id,title) VALUES (?,?)').run(req.user.id, title);
      conversation = { id: result.lastInsertRowid };
    }
    db.prepare('INSERT INTO messages (conversation_id,role,content) VALUES (?,?,?)').run(conversation.id, 'user', message);
    const history = db.prepare('SELECT role,content FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 16').all(conversation.id).reverse();
    const response = await openai().responses.create({
      model: 'gpt-4.1-mini',
      input: [
        { role: 'system', content: 'You are GS AI, a helpful multilingual assistant. Reply in the language used by the user. Be accurate, clear, and say when uncertain. For research, use web search and cite source URLs in your answer.' },
        ...history
      ],
      ...(research ? { tools: [{ type: 'web_search_preview' }] } : {})
    });
    const answer = response.output_text || 'I could not create an answer. Please try again.';
    db.prepare('INSERT INTO messages (conversation_id,role,content) VALUES (?,?,?)').run(conversation.id, 'assistant', answer);
    res.json({ answer, conversationId: conversation.id });
  } catch (e) { safeError(res, e); }
});
app.post('/api/images', auth, async (req, res) => {
  try {
    const { prompt, size = '1024x1024' } = req.body;
    if (!prompt?.trim()) return res.status(400).json({ error: 'Describe the image you want.' });
    const result = await openai().images.generate({ model: 'gpt-image-1', prompt, size, n: 1 });
    res.json({ image: `data:image/png;base64,${result.data[0].b64_json}` });
  } catch (e) { safeError(res, e); }
});
app.use(express.static('dist'));
app.get('*', (req, res, next) => req.path.startsWith('/api') ? next() : res.sendFile(process.cwd() + '/dist/index.html'));
app.listen(PORT, () => console.log(`GS AI server listening on ${PORT}`));
