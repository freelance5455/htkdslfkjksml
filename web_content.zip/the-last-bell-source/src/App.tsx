import { useCallback, useEffect, useRef, useState } from "react";

type Item = "Senter" | "Kunci BK" | "Foto Angkatan 2017" | "Sekring Lab";
type PlaceId =
  | "corridor"
  | "classroom"
  | "lab"
  | "field"
  | "library"
  | "bk"
  | "canteen"
  | "mushola";
type Place = { id: PlaceId; name: string; subtitle: string; description: string };

const PLACES: Place[] = [
  {
    id: "corridor",
    name: "Koridor Utama",
    subtitle: "Lantai 2 · Gedung Timur",
    description: "Bau kapur dan kertas lembap memenuhi koridor.",
  },
  {
    id: "classroom",
    name: "X TJKT 2",
    subtitle: "Ruang Kelas · 02",
    description: "Pintu yang tadi terkunci kini terbuka sedikit.",
  },
  {
    id: "lab",
    name: "Laboratorium Komputer",
    subtitle: "LAB TJKT",
    description: "Suara kipas komputer terdengar dari ruangan gelap.",
  },
  {
    id: "field",
    name: "Lapangan Upacara",
    subtitle: "Halaman Tengah",
    description: "Tiang bendera bergerak meski tidak ada angin.",
  },
  {
    id: "library",
    name: "Perpustakaan",
    subtitle: "Literasi Sekolah",
    description: "Rak buku menutupi sesuatu di dinding belakang.",
  },
  {
    id: "bk",
    name: "Ruang BK",
    subtitle: "Bimbingan Konseling",
    description: "Berkas siswa lama berserakan di lantai.",
  },
  {
    id: "canteen",
    name: "Kantin Sekolah",
    subtitle: "Kantin Kejujuran",
    description: "Gelas-gelas plastik tersusun seolah baru ditinggalkan.",
  },
  {
    id: "mushola",
    name: "Mushola Al-Ikhlas",
    subtitle: "Harap Menjaga Ketenangan",
    description: "Karpet hijau tampak bersih di antara bangunan lapuk.",
  },
];

const CLUES = [
  {
    title: "Daftar Hadir X TJKT 2",
    body: "Semester Ganjil · Tahun Pelajaran 2017/2018\n\n17. Naufal Pradana — ALPA\n18. Raka Aditya — ALPA\n19. [NAMA ANDA] — HADIR\n\nCatatan wali kelas: “Jangan bunyikan bel setelah tengah malam.”",
  },
  {
    title: "Surat Edaran Lama",
    body: "PENGUMUMAN\n\nKegiatan belajar mengajar diliburkan sementara terkait hilangnya seorang siswa kelas X TJKT 2 pada 17 Agustus 2017.\n\nPihak sekolah meminta semua pihak tidak memasuki ruang server lama.",
  },
  {
    title: "Catatan Teknisi",
    body: "Komputer nomor 17 kembali menyala sendiri tepat pukul 00.00. Rekaman terakhir Naufal masih tersimpan, tetapi pintu ruang server sudah ditutup permanen.\n\nSekring cadangan disimpan di Ruang BK.",
  },
];

type IconName = "bag" | "file" | "map" | "sound" | "off" | "flash" | "close" | "save" | "hand";
function Icon({ name, size = 20 }: { name: IconName; size?: number }) {
  const paths: Record<IconName, React.ReactNode> = {
    bag: (
      <>
        <path d="M6 8h12l1 12H5L6 8Z" />
        <path d="M9 9V6a3 3 0 0 1 6 0v3" />
      </>
    ),
    file: (
      <>
        <path d="M6 3h8l4 4v14H6V3Z" />
        <path d="M14 3v5h5M9 13h6M9 17h5" />
      </>
    ),
    map: (
      <>
        <path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z" />
        <path d="M9 3v15M15 6v15" />
      </>
    ),
    sound: (
      <>
        <path d="M5 10v4h4l5 4V6l-5 4H5Z" />
        <path d="M17 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12" />
      </>
    ),
    off: (
      <>
        <path d="M5 10v4h4l5 4V6l-5 4H5Z" />
        <path d="m17 10 5 5m0-5-5 5" />
      </>
    ),
    flash: <path d="M9 3h6l-1 7h3l-7 11 1-8H7l2-10Z" />,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    save: (
      <>
        <path d="M5 3h12l3 3v15H4V3h1Z" />
        <path d="M8 3v6h8V3M8 21v-7h8v7" />
      </>
    ),
    hand: (
      <path d="M8 12V6a2 2 0 0 1 4 0v5-7a2 2 0 0 1 4 0v7-5a2 2 0 0 1 4 0v8c0 5-3 7-7 7h-1c-3 0-5-2-7-5l-2-3a2 2 0 0 1 3-2l2 1Z" />
    ),
  };
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  );
}

function Start({
  onStart,
  onContinue,
  hasSave,
}: {
  onStart: () => void;
  onContinue: () => void;
  hasSave: boolean;
}) {
  return (
    <main className="start">
      <div className="rain" />
      <div className="school">
        <b>SMK BINA NUSANTARA</b>
        <div>
          {Array.from({ length: 18 }, (_, i) => (
            <i className={i === 13 ? "lit" : ""} key={i} />
          ))}
        </div>
      </div>
      <div className="shade" />
      <section className="title">
        <p>
          <span /> AN INDONESIAN SCHOOL HORROR <span />
        </p>
        <h1>
          THE LAST
          <br />
          <strong>BELL</strong>
        </h1>
        <em>LONCENG TERAKHIR</em>
        <div>
          <button className="primary" onClick={onStart}>
            MULAI PERMAINAN <b>›</b>
          </button>
          {hasSave && (
            <button className="secondary" onClick={onContinue}>
              LANJUTKAN
            </button>
          )}
        </div>
        <small>
          <Icon name="sound" size={14} /> Gunakan earphone untuk pengalaman terbaik
        </small>
      </section>
      <footer>
        <span>SMK BINA NUSANTARA · 2025</span>
        <span>v1.7 — INDONESIAN SCHOOL UPDATE</span>
      </footer>
    </main>
  );
}

function Classroom({ playerName }: { playerName: string }) {
  return (
    <>
      <div className="garuda">
        ◆
        <small>
          GARUDA
          <br />
          PANCASILA
        </small>
      </div>
      <div className="flag">
        <i />
        <i />
      </div>
      <div className="chalkboard">
        <p>JANGAN PULANG</p>
        <b>SEBELUM BEL BERBUNYI</b>
        <small>— Naufal, 2017</small>
      </div>
      <div className="schedule">
        <b>JADWAL PELAJARAN</b>
        <span>SENIN · B.INDONESIA</span>
        <span>SELASA · JARINGAN</span>
        <span>RABU · PANCASILA</span>
      </div>
      <div className="attendance">
        <b>ABSENSI SISWA</b>
        <span>17. NAUFAL · A</span>
        <span>18. RAKA · A</span>
        <em>19. {playerName.toUpperCase()} · H</em>
      </div>
      <div className="desks">
        {Array.from({ length: 6 }, (_, i) => (
          <i key={i} />
        ))}
      </div>
      <div className="uniform" />
    </>
  );
}

function Lab({ on }: { on: boolean }) {
  return (
    <>
      <div className="whiteboard">
        <b>TOPOLOGI JARINGAN</b>
        <small>LAB TJKT · DILARANG MEMINDAHKAN KABEL</small>
      </div>
      <div className="computers">
        {Array.from({ length: 5 }, (_, i) => (
          <div className={on && i === 2 ? "on" : ""} key={i}>
            <span>{on && i === 2 ? "NAUFAL_17\nMENUNGGU..." : ""}</span>
            <i />
          </div>
        ))}
      </div>
      <div className="poster">
        KESELAMATAN KERJA
        <br />
        <small>MATIKAN KOMPUTER SEBELUM PULANG</small>
      </div>
    </>
  );
}

function Field({ figure }: { figure: boolean }) {
  return (
    <>
      <div className="school-block">
        <b>SMK BINA NUSANTARA</b>
        {Array.from({ length: 12 }, (_, i) => (
          <i key={i} />
        ))}
      </div>
      <div className="pole">
        <div className="flag">
          <i />
          <i />
        </div>
      </div>
      <div className="field-lines" />
      <div className={`figure ${figure ? "visible" : ""}`}>
        <i />
        <b />
      </div>
      <div className="guard">
        POS
        <br />
        SATPAM
      </div>
    </>
  );
}

function Generic({ id }: { id: PlaceId }) {
  if (id === "library")
    return (
      <>
        <div className="shelves">
          {Array.from({ length: 42 }, (_, i) => (
            <i key={i} />
          ))}
        </div>
        <div className="poster">
          MEMBACA ADALAH
          <br />
          <b>JENDELA DUNIA</b>
        </div>
      </>
    );
  if (id === "bk")
    return (
      <>
        <div className="files">
          {Array.from({ length: 12 }, (_, i) => (
            <i key={i} />
          ))}
        </div>
        <div className="whiteboard">
          <b>RUANG BIMBINGAN KONSELING</b>
          <small>Kami mendengar. Kami membantu.</small>
        </div>
        <div className="archive">
          BERKAS SISWA
          <br />
          <b>2017</b>
        </div>
      </>
    );
  if (id === "canteen")
    return (
      <div className="stall">
        <b>KANTIN BU SRI</b>
        <span>SOTO · MIE · ES TEH</span>
        <i />
      </div>
    );
  if (id === "mushola")
    return (
      <>
        <div className="mihrab">
          <b>الله</b>
          <span>JAGALAH KEBERSIHAN</span>
        </div>
        <div className="rugs">
          {Array.from({ length: 5 }, (_, i) => (
            <i key={i} />
          ))}
        </div>
      </>
    );
  return null;
}

function World({
  place,
  moving,
  flicker,
  computerOn,
  doorOpen,
  figure,
  playerName,
}: {
  place: Place;
  moving: boolean;
  flicker: boolean;
  computerOn: boolean;
  doorOpen: boolean;
  figure: boolean;
  playerName: string;
}) {
  return (
    <div className={`world ${place.id} ${moving ? "moving" : ""} ${flicker ? "flicker" : ""}`}>
      <div className="ceiling">
        <i />
        <i />
        <i />
      </div>
      <div className="back">
        {place.id === "corridor" && (
          <>
            <div className="end-door">
              <span>GEDUNG TIMUR</span>
            </div>
            <div className={`end-figure ${figure ? "visible" : ""}`}>
              <i />
              <b />
            </div>
          </>
        )}
        {place.id === "classroom" && <Classroom playerName={playerName} />}
        {place.id === "lab" && <Lab on={computerOn} />}
        {place.id === "field" && <Field figure={figure} />}
        <Generic id={place.id} />
      </div>
      {place.id === "corridor" && (
        <>
          <div className="wall left">
            <div className="osis">
              <b>OSIS</b>
              <small>
                DISIPLIN · JUJUR
                <br />
                BERTANGGUNG JAWAB
              </small>
            </div>
            <div className="door near">
              <span>X TJKT 1</span>
              <i />
            </div>
            <div className="door far">
              <span>XI TJKT</span>
              <i />
            </div>
            <div className="notice">
              <b>PAPAN PENGUMUMAN</b>
              <i />
              <i />
              <i />
            </div>
          </div>
          <div className="wall right">
            <div className={`door near ${doorOpen ? "open" : ""}`}>
              <span>X TJKT 2</span>
              <i />
            </div>
            <div className="door far">
              <span>XII TJKT</span>
              <i />
            </div>
            <div className="signs">
              ← RUANG GURU
              <br />
              RUANG BK →<br />
              TOILET →
            </div>
          </div>
        </>
      )}
      {place.id !== "field" && <div className="floor" />}
      <div className="fog" />
      <div className="beam" />
    </div>
  );
}

type Modal = "inventory" | "map" | "document" | "pause" | null;
export default function App() {
  const [started, setStarted] = useState(false);
  const [placeIndex, setPlaceIndex] = useState(0);
  const [inventory, setInventory] = useState<Item[]>(["Senter"]);
  const [documents, setDocuments] = useState<number[]>([]);
  const [modal, setModal] = useState<Modal>(null);
  const [selectedDoc, setSelectedDoc] = useState(0);
  const [objective, setObjective] = useState("Temukan sumber suara lonceng");
  const [seconds, setSeconds] = useState(23 * 3600 + 59 * 60 + 43);
  const [flashlight, setFlashlight] = useState(true);
  const [sound, setSound] = useState(true);
  const [flicker, setFlicker] = useState(false);
  const [moving, setMoving] = useState(false);
  const [doorOpen, setDoorOpen] = useState(false);
  const [computerOn, setComputerOn] = useState(false);
  const [figure, setFigure] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [health, setHealth] = useState(100);
  const audio = useRef<AudioContext | null>(null);
  const place = PLACES[placeIndex];
  const time = `${String(Math.floor(seconds / 3600) % 24).padStart(2, "0")}:${String(Math.floor(seconds / 60) % 60).padStart(2, "0")}`;

  const tone = useCallback(
    (freq = 220, duration = 0.5, volume = 0.04) => {
      if (!sound) return;
      try {
        const ctx = audio.current ?? new AudioContext();
        audio.current = ctx;
        const osc = ctx.createOscillator(),
          gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        gain.gain.value = volume;
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
        osc.connect(gain).connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
      } catch {
        /* sound is an optional enhancement */
      }
    },
    [sound],
  );
  const announce = useCallback((text: string, ms = 3000) => {
    setMessage(text);
    window.setTimeout(() => setMessage(null), ms);
  }, []);

  useEffect(() => {
    if (!started || modal) return;
    const id = window.setInterval(() => setSeconds((s) => Math.min(86400, s + 1)), 1000);
    return () => clearInterval(id);
  }, [started, modal]);
  useEffect(() => {
    if (seconds === 86400 && !doorOpen) {
      setDoorOpen(true);
      setFlicker(true);
      setObjective("Selidiki kelas X TJKT 2");
      announce("DONG... DONG... DONG...\nBel sekolah berbunyi tepat pukul 00.00", 4500);
      tone(90, 2.5, 0.12);
      window.setTimeout(() => setFlicker(false), 2300);
    }
  }, [seconds, doorOpen, announce, tone]);
  useEffect(() => {
    if (!started) return;
    const id = window.setInterval(() => {
      setFlicker(true);
      window.setTimeout(() => setFlicker(false), 300);
    }, 7400);
    return () => clearInterval(id);
  }, [started]);

  const move = useCallback(
    (direction: number) => {
      if (modal || moving) return;
      setMoving(true);
      tone(70, 0.15, 0.025);
      window.setTimeout(() => {
        setPlaceIndex((i) => (i + direction + PLACES.length) % PLACES.length);
        setMoving(false);
        setFigure(false);
      }, 230);
    },
    [modal, moving, tone],
  );

  const save = useCallback(() => {
    localStorage.setItem(
      "last-bell-save",
      JSON.stringify({
        placeIndex,
        inventory,
        documents,
        seconds,
        doorOpen,
        computerOn,
        objective,
        health,
      }),
    );
    announce("Permainan tersimpan");
  }, [
    placeIndex,
    inventory,
    documents,
    seconds,
    doorOpen,
    computerOn,
    objective,
    health,
    announce,
  ]);
  const load = () => {
    try {
      const d = JSON.parse(localStorage.getItem("last-bell-save") || "{}");
      if (typeof d.placeIndex === "number") setPlaceIndex(d.placeIndex);
      if (Array.isArray(d.inventory)) setInventory(d.inventory);
      if (Array.isArray(d.documents)) setDocuments(d.documents);
      if (typeof d.seconds === "number") setSeconds(d.seconds);
      setDoorOpen(Boolean(d.doorOpen));
      setComputerOn(Boolean(d.computerOn));
      if (d.objective) setObjective(d.objective);
      if (d.health) setHealth(d.health);
    } catch {
      /* ignore incompatible save */
    }
    setStarted(true);
  };

  const interact = useCallback(() => {
    tone(420, 0.14, 0.025);
    if (place.id === "corridor") {
      if (!doorOpen) {
        announce("Pintu X TJKT 2 terkunci. Jam dinding berhenti di 00.00.");
        return;
      }
      setPlaceIndex(1);
      return;
    }
    if (place.id === "classroom") {
      if (!documents.includes(0)) {
        setDocuments((d) => [...d, 0]);
        setSelectedDoc(0);
        setModal("document");
        setObjective("Cari berkas hilangnya Naufal");
      } else announce("Tulisan baru muncul: “LAB. KOMPUTER. NOMOR 17.”");
      return;
    }
    if (place.id === "lab") {
      if (!inventory.includes("Sekring Lab")) {
        announce("Komputer nomor 17 mati. Kotak sekringnya kosong.");
        return;
      }
      if (!computerOn) {
        setComputerOn(true);
        setFlicker(true);
        setDocuments((d) => (d.includes(2) ? d : [...d, 2]));
        setObjective("Temukan ruang server lama");
        announce("Komputer 17 menyala sendiri: “NAUFAL_17 — MENUNGGU...”", 4200);
        tone(55, 1.4, 0.07);
        window.setTimeout(() => {
          setFlicker(false);
          setFigure(true);
        }, 900);
      } else announce("Suara dari speaker kosong: “Kembalikan namaku...”");
      return;
    }
    if (place.id === "bk") {
      if (!documents.includes(1)) {
        setDocuments((d) => [...d, 1]);
        setInventory((i) => [...i, "Sekring Lab", "Kunci BK"]);
        setSelectedDoc(1);
        setModal("document");
      } else announce("Lemari arsip kosong. Ada bekas tangan pada debu.");
      return;
    }
    if (place.id === "library") {
      if (!inventory.includes("Foto Angkatan 2017")) {
        setInventory((i) => [...i, "Foto Angkatan 2017"]);
        announce("Ditemukan: Foto Angkatan 2017. Wajah Naufal dicoret tinta merah.");
      } else announce("Di belakang rak tertulis: “Mereka menghapusku dari daftar.”");
      return;
    }
    if (place.id === "field") {
      setFigure(true);
      setHealth((h) => Math.max(65, h - 12));
      announce("Sosok berseragam putih abu-abu berdiri di dekat tiang bendera.", 3800);
      window.setTimeout(() => setFigure(false), 1900);
      return;
    }
    announce(place.description);
  }, [place, doorOpen, documents, inventory, computerOn, announce, tone]);

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (!started) return;
      if (e.key === "Escape") setModal((m) => (m ? null : "pause"));
      if (e.key.toLowerCase() === "e") interact();
      if (e.key.toLowerCase() === "f") setFlashlight((v) => !v);
      if (["w", "d", "ArrowUp", "ArrowRight"].includes(e.key)) move(1);
      if (["s", "a", "ArrowDown", "ArrowLeft"].includes(e.key)) move(-1);
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [started, interact, move]);

  const interaction: Record<PlaceId, string> = {
    corridor: "Periksa pintu kelas",
    classroom: "Baca daftar hadir",
    lab: "Periksa komputer 17",
    field: "Amati sosok",
    library: "Periksa rak belakang",
    bk: "Buka lemari arsip",
    canteen: "Periksa kantin",
    mushola: "Amati ruangan",
  };

  if (!started)
    return (
      <Start
        onStart={() => setStarted(true)}
        hasSave={Boolean(localStorage.getItem("last-bell-save"))}
        onContinue={load}
      />
    );
  return (
    <main className={`game ${flashlight ? "" : "dark"}`}>
      <World
        place={place}
        moving={moving}
        flicker={flicker}
        computerOn={computerOn}
        doorOpen={doorOpen}
        figure={figure}
        playerName="Raka Aditya"
      />
      <div className="grain" />
      <div className="shade" />
      <header className="hud">
        <div className="where">
          <b>{place.name}</b>
          <small>{place.subtitle}</small>
        </div>
        <div className="time">
          <b>{time}</b>
          <small>{seconds >= 86400 ? "TENGAH MALAM" : "MENUJU TENGAH MALAM"}</small>
        </div>
        <button onClick={() => setSound((v) => !v)}>
          <Icon name={sound ? "sound" : "off"} />
        </button>
        <button onClick={() => setModal("pause")} className="pause">
          <i />
          <i />
        </button>
      </header>
      <div className="objective">
        <small>TUJUAN SAAT INI</small>
        <b>
          <i />
          {objective}
        </b>
      </div>
      <div className="sanity">
        <span>
          KEWARASAN <b>{health}%</b>
        </span>
        <i>
          <b style={{ width: `${health}%` }} />
        </i>
      </div>
      {message && (
        <div className="message">
          {message.split("\n").map((l, i) => (
            <span key={i}>{l}</span>
          ))}
        </div>
      )}
      <div className="cross">
        <i />
        <i />
      </div>
      <button className="interact" onClick={interact}>
        <Icon name="hand" size={18} />
        <span>
          <small>INTERAKSI</small>
          {interaction[place.id]}
        </span>
        <kbd>E</kbd>
      </button>
      <aside className="quick">
        <button onClick={() => setModal("inventory")}>
          <Icon name="bag" />
          <b>{inventory.length}</b>
          <small>BARANG</small>
        </button>
        <button onClick={() => setModal("document")}>
          <Icon name="file" />
          <b>{documents.length}</b>
          <small>CATATAN</small>
        </button>
        <button onClick={() => setModal("map")}>
          <Icon name="map" />
          <small>PETA</small>
        </button>
      </aside>
      <div className="touch">
        <div className="joystick">
          <button onPointerDown={() => move(1)}>▲</button>
          <button onPointerDown={() => move(-1)}>◀</button>
          <i />
          <button onPointerDown={() => move(1)}>▶</button>
          <button onPointerDown={() => move(-1)}>▼</button>
        </div>
        <button
          className={`flash ${flashlight ? "active" : ""}`}
          onClick={() => setFlashlight((v) => !v)}
        >
          <Icon name="flash" />
          <small>SENTER</small>
        </button>
      </div>
      {modal && (
        <div className="modal">
          <section className="panel">
            <button className="close" onClick={() => setModal(null)}>
              <Icon name="close" />
            </button>
            {modal === "inventory" && (
              <>
                <p>TAS SEKOLAH</p>
                <h2>Barang Bawaan</h2>
                <div className="inventory">
                  {inventory.map((item, i) => (
                    <article key={item}>
                      <span>{i ? "▧" : "⌁"}</span>
                      <b>{item}</b>
                      <small>{item === "Senter" ? "Baterai 64%" : "Barang penting"}</small>
                    </article>
                  ))}
                </div>
              </>
            )}
            {modal === "document" && (
              <>
                <p>ARSIP SEKOLAH</p>
                <h2>Dokumen Ditemukan</h2>
                {documents.length ? (
                  <div className="docs">
                    <nav>
                      {documents.map((id) => (
                        <button
                          className={selectedDoc === id ? "active" : ""}
                          onClick={() => setSelectedDoc(id)}
                          key={id}
                        >
                          0{id + 1} · {CLUES[id].title}
                        </button>
                      ))}
                    </nav>
                    <article>
                      <i>ARSIP</i>
                      <h3>{CLUES[selectedDoc]?.title}</h3>
                      {CLUES[selectedDoc]?.body.split("\n").map((x, i) => (
                        <span key={i}>{x || <br />}</span>
                      ))}
                    </article>
                  </div>
                ) : (
                  <div className="empty">Belum ada dokumen yang ditemukan.</div>
                )}
              </>
            )}
            {modal === "map" && (
              <>
                <p>DENAH GEDUNG</p>
                <h2>SMK Bina Nusantara</h2>
                <div className="map">
                  {PLACES.map((x, i) => (
                    <button
                      className={i === placeIndex ? "current" : ""}
                      onClick={() => {
                        setPlaceIndex(i);
                        setModal(null);
                      }}
                      key={x.id}
                    >
                      <i>{String(i + 1).padStart(2, "0")}</i>
                      <b>{x.name}</b>
                      <small>{i === placeIndex ? "LOKASI ANDA" : "TELUSURI"}</small>
                    </button>
                  ))}
                </div>
                <div className="map-note">
                  Ruang Guru · Ruang BK · Toilet · Pos Satpam · Gedung Timur
                </div>
              </>
            )}
            {modal === "pause" && (
              <>
                <p>PERMAINAN DIJEDA</p>
                <h2>Jangan biarkan bel menemukanmu.</h2>
                <div className="pause-menu">
                  <button className="primary" onClick={() => setModal(null)}>
                    LANJUTKAN
                  </button>
                  <button className="secondary" onClick={save}>
                    <Icon name="save" size={17} /> SIMPAN PERMAINAN
                  </button>
                  <button className="secondary" onClick={() => setStarted(false)}>
                    KEMBALI KE MENU
                  </button>
                </div>
                <div className="help">
                  <b>WASD / PANAH</b> Bergerak <b>E</b> Interaksi <b>F</b> Senter <b>ESC</b> Jeda
                </div>
              </>
            )}
          </section>
        </div>
      )}
    </main>
  );
}
