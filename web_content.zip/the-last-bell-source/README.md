# THE LAST BELL — Lonceng Terakhir

Source project exported from the supplied Figma Make project and prepared as a standalone Vite + React application.

## Requirements
- Node.js 20.19+ (or a newer compatible LTS release)
- npm

## Run locally
```bash
npm install
npm run dev
```

## Build for publishing
```bash
npm run build
```

The production website files are generated in `dist/`.

## Preview the production build
```bash
npm run preview
```

## Publish
Deploy the **contents of the `dist` folder** to any static hosting provider. For Vercel or Netlify connected to a Git repository, use:
- Build command: `npm run build`
- Output/publish directory: `dist`

For a manual static upload, build first and upload the generated `dist` folder (not the whole source folder).

## Notes
- The current game uses React, TypeScript, CSS perspective scenes, and browser APIs. It is not a Three.js 3D project.
- Progress saving uses browser localStorage, so saves are local to the browser/device used to play.
- The Figma-specific Vite configuration was replaced with a standard Vite configuration so the source can run outside Figma Make.
