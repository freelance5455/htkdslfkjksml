# Panduan publish THE LAST BELL

## Cara menjalankan source di komputer
1. Ekstrak ZIP source.
2. Install Node.js versi LTS yang kompatibel.
3. Buka terminal di folder project.
4. Jalankan `npm install`.
5. Jalankan `npm run dev` untuk membuka preview lokal.
6. Jalankan `npm run build` untuk membuat folder `dist`.

## Cara publish melalui layanan hosting
Project ini adalah website statis berbasis Vite. Setelah source masuk ke repository Git, hubungkan repository tersebut ke Netlify atau Vercel.

Pengaturan build:
- Build command: `npm run build`
- Publish/output directory: `dist`

Netlify juga membaca pengaturan tersebut dari file `netlify.toml` yang sudah disertakan.

## Catatan penting
- Jangan upload folder `src` sebagai folder website jadi. Hosting harus menjalankan build terlebih dahulu, atau menerima hasil build dari folder `dist`.
- Folder `node_modules` tidak disertakan di ZIP karena bisa dibuat ulang dengan `npm install`.
- Penyimpanan progres menggunakan localStorage browser. Data save tidak otomatis tersinkron ke perangkat lain.
