const $ = (id) => document.getElementById(id);
const emojis = ["😎","😂","🦊","🐼","🦁","🐸","🐯","🐵","🐱","🐙","🦄","🐨"];
const questions = [
  "مين فينا ممكن يبقى مليونير الأول؟",
  "مين بيضحك في وقت مش مناسب؟",
  "مين ممكن ينسى هو داخل الأوضة ليه؟",
  "مين أكتر واحد بيتأخر على المواعيد؟",
  "مين لو بقى مشهور هيتغير؟",
  "مين بيقدر يقنع أي حد بأي حاجة؟",
  "مين أكتر واحد ممكن ينام في أي مكان؟",
  "مين عنده فرصة يعمل مشروع وينجح؟",
  "مين بيقول «أنا جاي» وهو لسه في البيت؟",
  "مين أكتر واحد بيصور الأكل قبل ما ياكله؟"
];
let players = [];
let qIndex = 0;
let votes = {};
let selectedPlayer = null;
let soundOn = true;

function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => s.classList.toggle("active", s.id === id));
  window.scrollTo({top:0, behavior:"smooth"});
}
function showModal(title, text) {
  $("modalTitle").textContent = title; $("modalText").textContent = text;
  $("modal").classList.remove("hidden");
}
function addPlayer() {
  const name = $("playerInput").value.trim();
  if (!name) return;
  if (players.length >= 12) return showModal("الشلة كملت 🎉", "النسخة التجريبية بتسمح بحد أقصى 12 لاعب.");
  if (players.some(p => p.name.toLowerCase() === name.toLowerCase())) return showModal("الاسم موجود", "جرّب اسم مختلف علشان نعرف نفرّق بين اللاعبين.");
  players.push({name, emoji:emojis[players.length % emojis.length]});
  $("playerInput").value = "";
  renderPlayers();
}
function renderPlayers() {
  $("playersList").innerHTML = "";
  players.forEach((p,i) => {
    const chip = document.createElement("div"); chip.className = "player-chip";
    const avatar = document.createElement("span"); avatar.className = "avatar"; avatar.textContent = p.emoji;
    const name = document.createElement("span"); name.textContent = p.name;
    const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.setAttribute("aria-label","حذف "+p.name);
    remove.onclick = () => { players.splice(i,1); renderPlayers(); };
    chip.append(avatar,name,remove); $("playersList").append(chip);
  });
  $("startBtn").disabled = players.length < 2;
}
function startGame() {
  if (players.length < 2) return showModal("ضيف أصحابك الأول", "لازم يكون فيه لاعبين على الأقل علشان تبدأوا.");
  qIndex = 0; votes = {}; selectedPlayer = null;
  showScreen("voteScreen"); renderQuestion();
}
function renderQuestion() {
  $("questionText").textContent = questions[qIndex];
  $("questionCount").textContent = `السؤال ${qIndex+1} من ${questions.length}`;
  $("voteCount").textContent = `${Object.values(votes).reduce((a,b)=>a+b,0)} تصويت`;
  $("progressFill").style.width = `${(qIndex/questions.length)*100}%`;
  $("nextQuestionBtn").disabled = selectedPlayer === null;
  $("nextQuestionBtn").textContent = qIndex === questions.length-1 ? "إنهاء الجولة ←" : "السؤال اللي بعده ←";
  $("voteOptions").innerHTML = "";
  players.forEach((p,i) => {
    const btn = document.createElement("button"); btn.className = "vote-option" + (selectedPlayer === i ? " selected" : "");
    const avatar = document.createElement("span"); avatar.className = "avatar"; avatar.textContent = p.emoji;
    const name = document.createElement("span"); name.textContent = p.name;
    btn.append(avatar,name); btn.onclick = () => { selectedPlayer = i; votes[p.name] = (votes[p.name]||0)+1; renderQuestion(); $("voteCount").textContent = `${Object.values(votes).reduce((a,b)=>a+b,0)} تصويت`; };
    $("voteOptions").append(btn);
  });
}
function nextQuestion() {
  if (selectedPlayer === null) return;
  if (qIndex >= questions.length-1) return showResults();
  qIndex++; selectedPlayer = null; renderQuestion();
}
function showResults() {
  showScreen("resultsScreen");
  const sorted = [...players].map(p=>({...p, score:votes[p.name]||0})).sort((a,b)=>b.score-a.score);
  const winner = sorted[0];
  $("winnerCard").innerHTML = "";
  const label=document.createElement("div"); label.className="winner-label"; label.textContent="نجم الجولة";
  const name=document.createElement("div"); name.className="winner-name"; name.textContent=winner ? `${winner.emoji} ${winner.name}` : "الشلة كلها";
  const score=document.createElement("div"); score.className="winner-score"; score.textContent=`${winner ? winner.score : 0} صوت`;
  $("winnerCard").append(label,name,score);
  $("leaderboard").innerHTML="";
  sorted.forEach((p,i)=>{
    const row=document.createElement("div"); row.className="leader-row";
    const rank=document.createElement("div"); rank.className="rank"; rank.textContent=["🥇","🥈","🥉"][i] || (i+1);
    const avatar=document.createElement("span"); avatar.className="avatar"; avatar.textContent=p.emoji;
    const pname=document.createElement("div"); pname.className="leader-name"; pname.textContent=p.name;
    const scoreEl=document.createElement("div"); scoreEl.className="leader-votes"; scoreEl.textContent=`${p.score} صوت`;
    row.append(rank,avatar,pname,scoreEl); $("leaderboard").append(row);
  });
}
async function shareResults() {
  const rows=[...$("leaderboard").querySelectorAll(".leader-row")].map((r,i)=>`${i+1}. ${r.querySelector(".leader-name").textContent} — ${r.querySelector(".leader-votes").textContent}`);
  const text=`😂 نتيجة لعبة مين فينا؟\n${rows.join("\n")}\nالعبوا معانا!`;
  if (navigator.share) { try { await navigator.share({title:"مين فينا؟",text}); } catch(e){} }
  else { try { await navigator.clipboard.writeText(text); showModal("اتنسخت النتيجة! 💜","تقدر تلصقها وتبعتها على واتساب."); } catch(e) { showModal("نتيجة الجولة",text); } }
}
$("addPlayerBtn").addEventListener("click",addPlayer);
$("playerInput").addEventListener("keydown",e=>{if(e.key==="Enter")addPlayer()});
$("startBtn").addEventListener("click",startGame);
$("nextQuestionBtn").addEventListener("click",nextQuestion);
$("finishBtn").addEventListener("click",showResults);
$("playAgainBtn").addEventListener("click",startGame);
$("shareBtn").addEventListener("click",shareResults);
$("howBtn").addEventListener("click",()=>showModal("إزاي نلعب؟ 🎮","ضيفوا أسماء الشلة. في كل سؤال، اختاروا الشخص المناسب. النسخة دي تجريبية على جهاز واحد، فمرّروا الموبايل بينكم. بعد الجولة اعرضوا النتائج وشاركوها."));
$("soundBtn").addEventListener("click",()=>{soundOn=!soundOn;$("soundBtn").textContent=soundOn?"♫":"♪";showModal("إعدادات الصوت","مفيش مؤثرات صوتية مفعّلة في النسخة الحالية.")});
$("closeModal").addEventListener("click",()=>$("modal").classList.add("hidden"));
$("modalOk").addEventListener("click",()=>$("modal").classList.add("hidden"));
document.querySelectorAll("[data-go]").forEach(btn=>btn.addEventListener("click",()=>showScreen(btn.dataset.go)));
renderPlayers();
