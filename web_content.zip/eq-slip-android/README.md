# EQ Slip Editor Android project

This is an Android Studio project that wraps the supplied EQ Slip Editor HTML in a local WebView. The form and saved-slip storage run on the device. The app's print bridge opens Android's system print dialog; choose **Save as PDF** to create a PDF.

## Build an APK
1. Install Android Studio and its Android SDK (API 35).
2. Open this folder (`eq-slip-android`) in Android Studio.
3. Allow Gradle sync, then choose **Build > Build APK(s)**.
4. Install the generated debug APK on your Android phone.

Core form parsing and saved slips work locally. The optional OCR script in the included HTML loads Tesseract.js from its CDN and therefore needs internet on first load; OCR is not required for normal manual/pasted-data use.

The source project is provided; an APK has not been compiled or tested in this environment.
