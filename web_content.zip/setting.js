let colorPicker = document.getElementById("colorPicker");
let buttonColor = document.getElementById("buttonColor");
let boxColor = document.getElementById("boxColor");
let textColor = document.getElementById("textColor");
let fontSize = document.getElementById("fontSize");
let ansowerColor = document.getElementById("ansowerColor");
let settingBoxColor = document.getElementById("settingBoxColor");

colorPicker.value = localStorage.getItem("bgColor") || "#ccd5ae";
buttonColor.value = localStorage.getItem("btnColor") || "#d4a373";
boxColor.value = localStorage.getItem("boxColor") || "#e9edc9";
textColor.value = localStorage.getItem("textColor") || "#808080";
fontSize.value = localStorage.getItem("fontsize") || "18";
ansowerColor.value = localStorage.getItem("ansowerColor") || "#fefae0";
settingBoxColor.value = localStorage.getItem("settingBoxColor") || "#fefae0";

function emal() {
    localStorage.setItem("bgColor", colorPicker.value);
    localStorage.setItem("btnColor", buttonColor.value);
    localStorage.setItem("boxColor", boxColor.value);
    localStorage.setItem("textColor", textColor.value);
    localStorage.setItem("fontsize", fontSize.value);
    localStorage.setItem("ansowerColor", ansowerColor.value);
    localStorage.setItem("settingBoxColor", settingBoxColor.value);
    syncThemeVariables();

    window.location.href = "Calculator.html";
}

function resetSettings() {
    localStorage.removeItem("bgColor");
    localStorage.removeItem("btnColor");
    localStorage.removeItem("boxColor");
    localStorage.removeItem("textColor");
    localStorage.removeItem("fontsize");
    localStorage.removeItem("ansowerColor");
    localStorage.removeItem("settingBoxColor");

    colorPicker.value = "#ccd5ae";
    buttonColor.value = "#d4a373";
    boxColor.value = "#e9edc9";
    textColor.value = "#808080";
    fontSize.value = "18";
    ansowerColor.value = "#fefae0";
    settingBoxColor.value = "#fefae0";

    syncThemeVariables();
    applySettings();
}

function syncThemeVariables(){
    const root = document.documentElement;
    root.style.setProperty("--user-bg", localStorage.getItem("bgColor") || "#ccd5ae");
    root.style.setProperty("--user-btn", localStorage.getItem("btnColor") || "#d4a373");
    root.style.setProperty("--user-box", localStorage.getItem("boxColor") || "#e9edc9");
    root.style.setProperty("--user-display", localStorage.getItem("ansowerColor") || "#fefae0");
    root.style.setProperty("--user-text", localStorage.getItem("textColor") || "#808080");
    root.style.setProperty("--user-setting", localStorage.getItem("settingBoxColor") || "#faedcd");
}

function applySettings(){
    document.querySelector("body").style.backgroundColor =
        localStorage.getItem("bgColor") || "#ccd5ae";

    let btnColor = localStorage.getItem("btnColor") || "#d4a373";
    let textColor = localStorage.getItem("textColor") || "#808080";
    let boxColor = localStorage.getItem("boxColor") || "#e9edc9";
    let fontsize = localStorage.getItem("fontsize") || "18";
    let settingBox = localStorage.getItem("settingBoxColor") || "#fefae0";

    document.querySelectorAll(".button, .clear-all").forEach(function(el){
        el.style.backgroundColor = btnColor;
        el.style.borderColor = btnColor;
        el.style.color = textColor;
    });

    document.querySelectorAll(".main").forEach(function(el){
        el.style.backgroundColor = boxColor;
        el.style.borderColor = boxColor;
    });

    document.querySelectorAll(".setting-row").forEach(function(el){
        el.style.backgroundColor = settingBox;
    });

    document.querySelector(".setting-title").style.fontSize = (Number(fontsize) + 4) + "px";
}

applySettings();