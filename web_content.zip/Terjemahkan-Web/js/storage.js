/* ===== History: riwayat terjemahan (disimpan di perangkat) ===== */
var History = (function () {
  var KEY = "terjemahkan.history.v1";
  var LIMIT = 20;
  var memory = [];

  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) { return memory; }
  }
  function save(list) {
    memory = list;
    try { localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* abaikan */ }
  }

  function all() { return load(); }

  function add(item) {
    var list = load();
    var head = list[0];
    // Jika masih mengetik teks yang sama (makin panjang/pendek), timpa entri teratas.
    if (head && (item.src.indexOf(head.src) === 0 || head.src.indexOf(item.src) === 0)) {
      list.shift();
    }
    list.unshift(item);
    save(list.slice(0, LIMIT));
  }

  function clear() { save([]); }

  return { all: all, add: add, clear: clear };
})();
