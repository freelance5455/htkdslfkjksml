/* ===== Translator: logika terjemahan (Indonesia <-> Inggris) =====
   Memakai endpoint Google Translate tanpa API key (tidak resmi).
   mode: "auto" (deteksi bahasa), "id-en", atau "en-id". */
var Translator = (function () {
  var MAX_CHUNK = 1500;

  // Pecah teks panjang per kalimat/baris agar tiap permintaan tidak terlalu panjang.
  function chunk(text) {
    var pieces = text.split(/(?<=[.!?\n])/);
    var chunks = [], cur = "";
    pieces.forEach(function (p) {
      while (p.length > MAX_CHUNK) {
        if (cur) { chunks.push(cur); cur = ""; }
        chunks.push(p.slice(0, MAX_CHUNK));
        p = p.slice(MAX_CHUNK);
      }
      if (cur.length + p.length > MAX_CHUNK) { chunks.push(cur); cur = ""; }
      cur += p;
    });
    if (cur) chunks.push(cur);
    return chunks.length ? chunks : [text];
  }

  // Pertahankan spasi / baris baru di akhir potongan teks.
  function keepTrailing(out, original) {
    var m = original.match(/\s*$/);
    return out.replace(/\s+$/, "") + (m ? m[0] : "");
  }

  async function request(q, sl, tl, signal) {
    var url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + sl +
      "&tl=" + tl + "&dt=t&q=" + encodeURIComponent(q);
    var res = await fetch(url, signal ? { signal: signal } : undefined);
    if (!res.ok) throw new Error("HTTP " + res.status);
    var data = await res.json();
    var text = "";
    (data[0] || []).forEach(function (seg) { text += seg[0] || ""; });
    return { text: text, detected: data[2] || "auto" };
  }

  async function translate(text, mode, signal) {
    var chunks = chunk(text);
    var sl = "auto", tl = "en", from = "id", firstOut = null;

    if (mode === "id-en") { sl = "id"; tl = "en"; from = "id"; }
    else if (mode === "en-id") { sl = "en"; tl = "id"; from = "en"; }
    else {
      var first = await request(chunks[0], "auto", "en", signal);
      from = first.detected;
      if (from === "en") { tl = "id"; } else { firstOut = first.text; }
    }

    var out = "";
    for (var i = 0; i < chunks.length; i++) {
      var t = (i === 0 && firstOut !== null)
        ? firstOut
        : (await request(chunks[i], sl, tl, signal)).text;
      out += keepTrailing(t, chunks[i]);
    }
    return { text: out.trim(), from: from, to: tl };
  }

  return { translate: translate };
})();
