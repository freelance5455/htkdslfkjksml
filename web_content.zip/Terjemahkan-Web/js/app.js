/* ===== App: pengatur tampilan dan interaksi ===== */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var LABELS = {
    "auto": ["Otomatis", "Hasil"],
    "id-en": ["Indonesia", "Inggris"],
    "en-id": ["Inggris", "Indonesia"]
  };
  var DEBOUNCE_MS = 900;

  var state = { mode: "auto", last: null, controller: null, timer: null, rotation: 0, toastTimer: null };
  var el = {
    src: $("src"), out: $("out"), error: $("error"), outCard: $("outCard"),
    go: $("btnGo"), counter: $("counter"), auto: $("autoToggle"),
    srcLang: $("srcLang"), dstLang: $("dstLang"),
    speak: $("btnSpeak"), copy: $("btnCopy"), share: $("btnShare"), swap: $("btnSwap"),
    modes: document.querySelectorAll(".mode"),
    historyBox: $("historyBox"), historyList: $("historyList"), toast: $("toast")
  };

  function langName(c) {
    return c === "id" ? "Indonesia" : c === "en" ? "Inggris" : String(c).toUpperCase();
  }

  /* ---------- UI helpers ---------- */
  function toast(msg) {
    el.toast.textContent = msg;
    el.toast.classList.add("show");
    clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(function () { el.toast.classList.remove("show"); }, 1800);
  }

  function updateCounter() { el.counter.textContent = el.src.value.length + " / 5000"; }

  function setLoading(on) {
    el.outCard.classList.toggle("loading", on);
    el.go.disabled = on;
    el.go.textContent = on ? "Menerjemahkan…" : "Terjemahkan";
  }

  function setActions(enabled) {
    el.speak.disabled = !enabled || !("speechSynthesis" in window);
    el.copy.disabled = !enabled;
    el.share.disabled = !enabled || !navigator.share;
  }

  function showError(msg) {
    el.error.textContent = msg || "";
    el.error.hidden = !msg;
  }

  function setMode(mode) {
    state.mode = mode;
    el.modes.forEach(function (b) {
      var on = b.getAttribute("data-mode") === mode;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", on ? "true" : "false");
    });
    if (!state.last) {
      el.srcLang.textContent = LABELS[mode][0];
      el.dstLang.textContent = LABELS[mode][1];
    }
  }

  function showResult(r) {
    state.last = r;
    el.out.textContent = r.text;
    el.out.classList.remove("pop");
    void el.out.offsetWidth; // ulang animasi
    el.out.classList.add("pop");
    el.srcLang.textContent = (state.mode === "auto" ? "Terdeteksi: " : "") + langName(r.from);
    el.dstLang.textContent = langName(r.to);
    showError("");
    setActions(true);
  }

  function resetOutput() {
    if (state.controller) { state.controller.abort(); state.controller = null; }
    clearTimeout(state.timer);
    state.last = null;
    el.out.textContent = "";
    showError("");
    setActions(false);
    setLoading(false);
    el.srcLang.textContent = LABELS[state.mode][0];
    el.dstLang.textContent = LABELS[state.mode][1];
  }

  /* ---------- Terjemahkan ---------- */
  async function run() {
    clearTimeout(state.timer);
    var text = el.src.value.trim();
    if (!text) { resetOutput(); return; }

    if (state.controller) state.controller.abort();
    var ctl = ("AbortController" in window) ? new AbortController() : null;
    state.controller = ctl;
    setLoading(true);
    showError("");

    try {
      var r = await Translator.translate(text, state.mode, ctl ? ctl.signal : undefined);
      if (state.controller !== ctl) return;
      showResult(r);
      History.add({ src: text, out: r.text, from: r.from, to: r.to });
      renderHistory();
    } catch (e) {
      if (e && e.name === "AbortError") return;
      if (state.controller !== ctl) return;
      el.out.textContent = "";
      state.last = null;
      setActions(false);
      showError("Gagal menerjemahkan. Cek koneksi internet lalu coba lagi.");
    }
    if (state.controller === ctl) setLoading(false);
  }

  function onInput() {
    updateCounter();
    if (!el.src.value.trim()) { resetOutput(); return; }
    if (el.auto.checked) {
      clearTimeout(state.timer);
      state.timer = setTimeout(run, DEBOUNCE_MS);
    }
  }

  /* ---------- Riwayat ---------- */
  function renderHistory() {
    var list = History.all();
    el.historyBox.hidden = list.length === 0;
    el.historyList.textContent = "";
    list.forEach(function (item) {
      var li = document.createElement("li");
      var b = document.createElement("button");
      b.type = "button"; b.className = "h-item";
      var s = document.createElement("span"); s.className = "h-src"; s.textContent = item.src;
      var o = document.createElement("span"); o.className = "h-out"; o.textContent = item.out;
      b.appendChild(s); b.appendChild(o);
      b.onclick = function () {
        el.src.value = item.src;
        updateCounter();
        showResult({ text: item.out, from: item.from, to: item.to });
        window.scrollTo({ top: 0, behavior: "smooth" });
      };
      li.appendChild(b);
      el.historyList.appendChild(li);
    });
  }

  /* ---------- Aksi hasil ---------- */
  function copyText(text) {
    function fallback() {
      var ta = document.createElement("textarea");
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); toast("Tersalin"); } catch (e) { toast("Gagal menyalin"); }
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { toast("Tersalin"); }, fallback);
    } else { fallback(); }
  }

  /* ---------- Event ---------- */
  el.modes.forEach(function (b) {
    b.onclick = function () {
      state.last = null;
      setMode(b.getAttribute("data-mode"));
      if (el.src.value.trim()) run();
    };
  });

  el.swap.onclick = function () {
    state.rotation += 180;
    el.swap.style.transform = "rotate(" + state.rotation + "deg)";
    if (state.last && el.out.textContent) {
      var r = state.last;
      el.src.value = r.text;
      updateCounter();
      var m = r.to + "-" + r.from;
      state.last = null;
      setMode(LABELS[m] ? m : "auto");
    } else {
      state.last = null;
      setMode(state.mode === "id-en" ? "en-id" : "id-en");
    }
    if (el.src.value.trim()) run();
  };

  el.src.addEventListener("input", onInput);
  el.src.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) run();
  });
  el.go.onclick = run;

  $("btnClear").onclick = function () {
    el.src.value = ""; updateCounter(); resetOutput(); el.src.focus();
  };

  $("btnPaste").onclick = async function () {
    try {
      var t = await navigator.clipboard.readText();
      if (t) { el.src.value = t; onInput(); }
    } catch (e) { toast("Tidak bisa menempel otomatis, tempel manual di kotak"); }
  };

  el.copy.onclick = function () { if (state.last) copyText(state.last.text); };

  el.share.onclick = function () {
    if (state.last && navigator.share) {
      navigator.share({ text: state.last.text }).catch(function () {});
    }
  };

  el.speak.onclick = function () {
    if (!state.last || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    var u = new SpeechSynthesisUtterance(state.last.text);
    u.lang = state.last.to === "id" ? "id-ID" : "en-US";
    window.speechSynthesis.speak(u);
  };

  $("btnClearHistory").onclick = function () { History.clear(); renderHistory(); toast("Riwayat dihapus"); };

  /* ---------- Mulai ---------- */
  setActions(false);
  updateCounter();
  renderHistory();

  // Dukungan teks dari tautan: index.html?text=Halo
  try {
    var q = new URLSearchParams(location.search).get("text");
    if (q) { el.src.value = q; updateCounter(); run(); }
  } catch (e) { /* abaikan */ }
})();
