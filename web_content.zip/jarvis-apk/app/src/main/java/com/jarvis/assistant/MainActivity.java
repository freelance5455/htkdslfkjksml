package com.jarvis.assistant;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    WebView webView;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new android.webkit.WebChromeClient(){
            @Override public void onPermissionRequest(PermissionRequest r){ r.grant(r.getResources()); }
        });
        // Загружаем локальный Jarvis PWA из assets
        webView.loadUrl("file:///android_asset/jarvis/pro.html");
        // JS bridge для Viber/StepGo
        webView.addJavascriptInterface(new JarvisBridge(this), "JarvisAndroid");
        setContentView(webView);
    }
    @Override public void onBackPressed(){
        if(webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
