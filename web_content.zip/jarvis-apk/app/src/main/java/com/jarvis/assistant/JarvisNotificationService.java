package com.jarvis.assistant;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.Intent;

// Читает уведомления Viber/Telegram/WhatsApp для автоответа через 5 мин
public class JarvisNotificationService extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn){
        String pkg=sbn.getPackageName();
        if(pkg.equals("com.viber.voip")||pkg.equals("org.telegram.messenger")||pkg.equals("com.whatsapp")){
            String title=sbn.getNotification().extras.getString("android.title");
            String text=sbn.getNotification().extras.getString("android.text");
            // Отправляем в WebView через broadcast
            Intent i=new Intent("JARVIS_NEW_MESSAGE");
            i.putExtra("pkg",pkg); i.putExtra("from",title); i.putExtra("text",text);
            sendBroadcast(i);
        }
    }
}
