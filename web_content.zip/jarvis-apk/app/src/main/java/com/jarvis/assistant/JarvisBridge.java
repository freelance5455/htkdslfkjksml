package com.jarvis.assistant;
import android.content.Context;
import android.content.Intent;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class JarvisBridge {
    Context ctx;
    public JarvisBridge(Context c){ctx=c;}
    @JavascriptInterface public void openStepGo(){ ctx.startActivity(new Intent(ctx.getPackageManager().getLaunchIntentForPackage("com.stepgo"))); }
    @JavascriptInterface public void openViber(){ ctx.startActivity(new Intent(ctx.getPackageManager().getLaunchIntentForPackage("com.viber.voip"))); }
    @JavascriptInterface public void openSupremeDuelist(){ ctx.startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://search?q=Supreme%20Duelist%20Stickman"))); }
    @JavascriptInterface public void openAudiomack(){ ctx.startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://audiomack.com"))); }
    @JavascriptInterface public void toast(String s){ Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show(); }
}
