package com.jarvis.assistant;
import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;

// Для Supreme Duelist / Noomiclone: тапает в координаты кнопки Атака
public class JarvisAccessibilityService extends AccessibilityService {
    public static JarvisAccessibilityService instance;
    Handler h = new Handler(Looper.getMainLooper());
    Runnable tapRunnable;

    @Override public void onServiceConnected(){ instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}

    public void startAutoTap(int x, int y, int intervalMs, int durationMin){
        long end = System.currentTimeMillis() + durationMin*60*1000L;
        tapRunnable = new Runnable(){ public void run(){
            if(System.currentTimeMillis() > end) return;
            dispatchTap(x,y);
            h.postDelayed(this, intervalMs);
        }};
        h.post(tapRunnable);
    }
    public void stopAutoTap(){ if(tapRunnable!=null) h.removeCallbacks(tapRunnable); }
    void dispatchTap(int x,int y){
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,60)).build();
        dispatchGesture(g,null,null);
    }
}
