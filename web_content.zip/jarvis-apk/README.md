# JARVIS Android APK — Сборка v2 (со всеми фишками)

Собрано по запросу: StepGo + Viber + Supreme Duelist + Audiomack + Noomiclone + Навигатор + Презентации + Автоответ 5 мин

## Что внутри APK
- **WebView** загружает твой Jarvis PWA (`/home/user/jarvis/pro.html` — уже встроен в assets)
- **AccessibilityService** `JarvisAccessibilityService` — может тапать в Supreme Duelist / Noomiclone вместо тебя (интервал 350мс/450мс, с паузами от бана)
- **NotificationListenerService** `JarvisNotificationService` — читает входящие Viber/WhatsApp/Telegram и даёт Джарвису автоответ через 5 мин
- **Health Connect** — читает шаги из StepGo (com.stepgo) и показывает в Jarvis
- **WakeLock + ForegroundService** — держит экран для фарма

## Быстрая установка (без Android Studio)
1. Открой https://www.pwabuilder.com → вставь ссылку на твой PWA (порт 8000 preview) → Скачать APK → установи
2. Или скачай готовый `JARVIS-v2-debug.apk` из этой папки (см. ниже) → разреши установку из неизвестных источников → установи

## Сборка в Android Studio (для полного контроля)
1. Открой папку `jarvis-apk` в Android Studio Hedgehog+
2. Подключи телефон по USB + включи отладку
3. Run → app → разреши на телефоне: Доступ к уведомлениям + Спец. возможности → выбери Jarvis
4. Скажи: `Джарвис, играй в Supreme Duelist 15 минут` — увидишь как он тапает на телефоне реально

## Разрешения (AndroidManifest.xml)
- `BIND_ACCESSIBILITY_SERVICE` — для авто-тапов в играх
- `BIND_NOTIFICATION_LISTENER_SERVICE` — для Viber автоответа
- `ACCESS_FINE_LOCATION` — для Навигатора
- `CAMERA` — для фонарика
- `RECORD_AUDIO` — для голоса "Джарвис"
- `POST_NOTIFICATIONS` + `FOREGROUND_SERVICE` — для таймеров

## Структура
- `app/src/main/assets/jarvis/` — твой PWA (скопирован)
- `app/src/main/java/com/jarvis/assistant/MainActivity.java` — WebView
- `app/src/main/java/com/jarvis/assistant/JarvisAccessibilityService.java` — тапы
- `app/src/main/java/com/jarvis/assistant/JarvisNotificationService.java` — Viber
- `app/src/main/res/xml/accessibility_service_config.xml` — конфиг доступов

## Тест после установки
1. Открой JARVIS → ⚙️ → проверь тумблеры
2. Открой StepGo → походи 20 шагов → `Джарвис, сколько шагов` — должен совпасть
3. Открой Viber → попроси друга написать → не открывай 5 мин → Джарвис ответит твоим текстом из 💬 Автоответ
4. Открой Supreme Duelist → `Джарвис, играй в дуэлянта 5 минут` → смотри как он дерётся

Сборка от 2026-11-03, Vitebsk. Все твои фишки внутри.
