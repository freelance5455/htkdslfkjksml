/* JOSTECH — MANUEL 05 : INTELLIGENCE ARTIFICIELLE NIVEAU 2 */
registerLessonDetail(5, 2, "ia-2-1-1", {
  title: "Leçon 1 : Machine Learning, Descente de Gradient et Overfitting",
  duration: "45 min (Manuel complet)",
  objectives: [
    "Maîtriser les 3 paradigmes : Supervisé (Classification/Régression), Non-Supervisé (Clustering) et Renforcement.",
    "Comprendre intuitivement la fonction de perte (Loss) et la Descente de Gradient.",
    "Évaluer un modèle (Précision, Rappel) et corriger le Surapprentissage (Overfitting)."
  ],
  prerequisites: ["Niveau 1 IA, bases Python et mathématiques élémentaires."],
  sections: [
    {
      type: "table",
      title: "1. Les 3 grands paradigmes du Machine Learning",
      headers: ["Paradigme", "Type de données", "Algorithmes & Exemples"],
      rows: [
        ["Supervisé", "Entrées X + Réponses Y connues", "Régression linéaire (prédire un prix), Classification (Spam / Non-spam)."],
        ["Non supervisé", "Entrées X seules (sans étiquettes)", "K-Means (regrouper des profils clients ou étudiants similaires)."],
        ["Renforcement", "Interaction + Récompenses", "Agent apprenant par essais/erreurs (robotique, jeux)."]
      ]
    },
    {
      type: "theory",
      title: "2. Comment la machine « apprend »-elle mathématiquement ?",
      text: "Prenons une régression simple : y = a·x + b. Au départ, l'algorithme choisit a et b au hasard et fait de grosses erreurs. On mesure l'erreur globale grâce à une Fonction de Coût (Loss, ex. erreur quadratique moyenne). Ensuite, l'algorithme de Descente de Gradient calcule la pente (dérivée) de cette erreur et ajuste progressivement a et b à petits pas (Learning Rate) jusqu'à minimiser l'erreur !\n\nC'est exactement comme un randonneur les yeux bandés sur une montagne dans le brouillard qui descend toujours dans le sens de la pente la plus raide pour atteindre le fond de la vallée."
    },
    {
      type: "code",
      lang: "Pipeline ML type en Python (Scikit-Learn)",
      code: [
        "# Toujours séparer : 80 % Entraînement (Train) / 20 % Évaluation (Test)",
        "X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)",
        "modele = RandomForestClassifier()",
        "modele.fit(X_train, y_train)        # Apprentissage uniquement sur Train",
        "score = modele.score(X_test, y_test) # Mesure réelle sur données jamais vues !"
      ].join("\n")
    },
    {
      type: "warning",
      title: "Pièges majeurs : Data Leakage et Overfitting",
      text: "1) Overfitting (Surapprentissage) : le modèle mémorise le bruit du jeu d'entraînement (99 % sur Train, 55 % sur Test). Solutions : plus de données, régularisation, modèle plus simple.\n2) Fuite de données (Data Leakage) : ne laissez jamais les données de Test influencer l'entraînement, sinon vos scores sont artificiellement gonflés !"
    }
  ],
  exercises: [
    {
      title: "Exercice 1 — Régression ou Classification ?",
      question: "Pour chaque cas, précisez s'il s'agit d'une Régression ou d'une Classification :\n1) Prédire la note exacte sur 20 d'un étudiant.\n2) Prédire s'il va réussir (Admis) ou échouer (Ajourné).",
      solution: "1) Régression (valeur numérique continue).\n2) Classification binaire (catégorie discrète : Admis ou Ajourné)."
    },
    {
      title: "Exercice 2 — Piège du taux de réussite brut (Accuracy)",
      question: "Sur 1 000 transactions bancaires, 990 sont honnêtes et 10 sont frauduleuses. Un programme idiot qui répond TOUJOURS « Honnête » obtient 99 % de précision ! Pourquoi est-il pourtant inutile ?",
      solution: "Face à des classes déséquilibrées, l'Accuracy trompe : ce modèle a 0 % de Rappel (Recall) sur les fraudes, ratant 100 % des pirates ! On utilise donc la Matrice de Confusion (Précision, Rappel et F1-Score)."
    }
  ],
  summary: "Un modèle ML optimise ses paramètres par Descente de Gradient sur un jeu d'entraînement, mais son véritable niveau de généralisation est toujours jugé sur un jeu de test indépendant.",
  references: ["Géron, A. — Machine Learning avec Scikit-Learn et TensorFlow.", "Bishop, C. — Pattern Recognition and Machine Learning."]
});