# CGD V117 — Socle 1.7 : Coupe Intergalactique des galaxies (AGD)

## Périmètre

Portage du moteur le plus récent `state.ic24` / `CGDIC24` retrouvé dans le code V116. L'ancien moteur `state.ic` à 16 sélections est écarté afin de ne pas faire coexister deux éditions de la même compétition.

## Règlement confirmé pour V117

- Organisateur : AGD.
- Une édition tous les trois cycles/saisons (saisons 3, 6, 9, 12...).
- 24 sélections mixtes réparties en 6 groupes de 4.
- Chaque groupe joue un mini-championnat simple : 6 matchs par groupe, 36 matchs au total, répartis en 3 journées.
- **Qualification : les deux premiers de chaque groupe (12 sélections) et les quatre meilleurs troisièmes (4 sélections), soit 16 qualifiés.**
- Les quatre meilleurs troisièmes sont comparés selon les points, la différence de buts, les buts marqués, la puissance sportive puis l'ordre alphabétique en dernier recours technique.
- Les 16 qualifiés disputent directement les huitièmes de finale, puis quarts, demi-finales et finale. Aucun barrage et aucune qualification directe en quarts.
- Total : 36 + 8 + 4 + 2 + 1 = **51 matchs**. Pas de petite finale.
- V116 indique une récompense de 1 000 000 Gold par match gagné et 15 000 000 Gold supplémentaires au champion. Le versement reste affecté à la sélection dirigée, au budget du club du manager.

## Correction du format précédent

Le format de la version précédente (12 qualifiés, quatre premiers directement en quarts et quatre barrages) est remplacé. La règle validée par l'utilisateur est désormais : deux premiers par groupe + quatre meilleurs troisièmes = 16 équipes, puis huitièmes de finale.

## Calendrier AGD

- La date AGD renseignée dans l'administration est interprétée comme la date d'ouverture de la compétition, après la fin officielle de la saison régulière FGD.
- Les phases sont espacées de deux jours : les trois journées de groupes, puis huitièmes, quarts, demi-finales et finale, avec un jour complet libre entre les étapes.
- L'édition sélections est due tous les trois cycles ; l'Intergalactique des Clubs reste due tous les quatre cycles.
- Lorsque les deux éditions tombent la même saison, leurs fenêtres doivent être séparées sur toute leur durée.
- Aucune date AGD n'est inventée. En l'absence de date officielle, les rencontres restent sans créneau et l'avancement est bloqué.

## Intégration technique

- Module : `src/intergalactic-cup.js`.
- Registre central des compétitions et des rencontres.
- Simulation par le moteur commun de dames.
- Le match de la sélection choisie par l'utilisateur reste jouable manuellement ; les autres rencontres sont simulées.
- Classements des groupes, repêchage des quatre meilleurs troisièmes, huitièmes, quarts, demies, finale, vainqueur et historique.
- Anti-double-homologation des résultats et contrôles de format.

## Limites

La validation navigateur interactive et la validation complète sur Android restent à effectuer. La date officielle d'ouverture AGD doit être renseignée à partir du calendrier de l'AGD.
