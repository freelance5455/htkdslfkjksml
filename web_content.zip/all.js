
//CORE
var VX={};
const K='h24v1',R=x=>Math.round(x*100)/100,EPS=1e-6,THEMES=['graphite','midnight','daylight','paper','classic','ocean','sunset','neon','forest','pastel'];
const DEF=[['Study','#3b82f6',1],['Sleep','#22c55e',0],['Entertainment','#f97316',0],['Namaz','#a855f7',0],['Meals','#eab308',0],['Other','#cbd5e1',0],['Wasted','#6b7280',0]];
const LT=['daylight','paper'];
const fresh=()=>({acts:DEF.map((a,i)=>({id:'a'+i,n:a[0],c:a[1],p:a[2]})),days:{},theme:'graphite',themeMode:'dark',darkTheme:'graphite',lightTheme:'daylight',unit:'hm',notif:0,timer:null,st:480,clock:'24',dateFmt:'long'});
function clean(d){
 if(!d||typeof d!=='object'||!Array.isArray(d.acts)||!d.acts.length||!d.days||typeof d.days!=='object')return'Not a 24H TRACKER file';
 const ids={};for(const a of d.acts){if(!a||typeof a.id!=='string'||typeof a.n!=='string'||!/^#[0-9a-f]{6}$/i.test(a.c))return'Bad activity list';ids[a.id]=1}
 for(const k in d.days){if(!/^\d{4}-\d\d-\d\d$/.test(k)||!Array.isArray(d.days[k]))return'Bad day '+k;let t=0;
  for(const e of d.days[k]){if(!e||!ids[e.act]||typeof e.min!=='number'||!isFinite(e.min)||e.min<=0)return'Bad entry on '+k;t+=e.min}
  if(t>1440+EPS)return k+' exceeds 24 h'}
 const o=fresh();o.acts=d.acts.map(a=>{const k=['w','n','l'].includes(a.cls)?a.cls:(a.p?'w':null),r={id:a.id,n:a.n.slice(0,30),c:a.c,p:k==='w'?1:0};if(k)r.cls=k;return r});
 for(const k in d.days)if(d.days[k].length)o.days[k]=d.days[k].map(e=>({act:e.act,min:R(e.min),note:String(e.note||'').slice(0,200)}));
 if(THEMES.includes(d.theme))o.theme=d.theme;
 // Appearance mode and colour palette are independent. Preserve the selected palette.
 o.themeMode=['dark','light'].includes(d.themeMode)?d.themeMode:(['daylight','paper'].includes(o.theme)?'light':'dark');
 o.darkTheme=o.theme;o.lightTheme=o.theme;
 if(['hm','dec','min'].includes(d.unit))o.unit=d.unit;o.notif=d.notif?1:0;if(d.clock==='12')o.clock='12';if(d.dateFmt==='compact')o.dateFmt='compact';if(typeof d.st==='number'&&d.st>=60&&d.st<=960)o.st=Math.round(d.st);if(d.ext&&typeof d.ext==='object')o.ext=cleanExt(d.ext);return o}
function load(){let raw=null;try{raw=localStorage.getItem(K)}catch(e){}
 if(raw){let r,j;try{j=JSON.parse(raw);r=clean(j)}catch(e){r='parse error'}
  if(typeof r==='object'){const t=j.timer;if(t&&typeof t.t==='number'&&r.acts.some(a=>a.id===t.a)&&/^\d{4}-\d\d-\d\d$/.test(t.d))r.timer={a:t.a,d:t.d,t:t.t};return r}
  try{localStorage.setItem(K+'_corrupt_backup',raw)}catch(e){}}
 return fresh()}
let S=load();
function save(){if(V&&V.v==='bw'&&BW.mode==='edit'){BW.dirty=1;return}try{localStorage.setItem(K,JSON.stringify(S))}catch(e){if(!window.SE){window.SE=1;alert('Storage is full: the latest changes may not be saved. Export a backup and remove large attachments.')}}}
const tot=d=>R((S.days[d]||[]).reduce((s,e)=>s+e.min,0));
const act=id=>S.acts.find(a=>a.id===id)||{n:'(deleted)',c:'#888',p:0};
function addE(d,a,m,n,i){m=R(+m);if(!(m>0))return'Enter a duration above 0';
 const L=(S.days[d]||[]).slice(),old=i==null?0:L[i].min,free=R(1440-tot(d)+old);
 if(m>free+EPS)return'Only '+free+' min free (a day has 1440 min)';
 const e={act:a,min:m,note:n||''};if(i==null)L.push(e);else L[i]=e;S.days[d]=L;save();return null}
// ---- OPUX 2.3: real elapsed intervals are split at LOCAL midnight and allocated to the calendar date they happened on
function splitSpan(a,b){const out=[];a=+a;b=+b;if(!isFinite(a)||!isFinite(b)||b<=a)return out;let cur=a,prev=0,g=0;
 while(cur<b&&g++<800){const dt=new Date(cur),nx=new Date(dt.getFullYear(),dt.getMonth(),dt.getDate()+1).getTime(),end=Math.min(b,nx>cur?nx:b),cum=R((end-a)/60000),m=R(cum-prev);prev=cum;if(m>0)out.push({d:ds(dt),min:m});cur=end}
 return out}
function putParts(parts,a,note,strict){const free={};for(const p of parts)free[p.d]=R(1440-tot(p.d));let lost=0;const use=[];
 for(const p of parts){const f=Math.max(0,free[p.d]),m=Math.min(p.min,f);
  if(strict&&p.min>f+EPS)return{err:'Only '+fmt(f)+' free on '+fd(p.d)+' (a day has 24 h). Adjust the time and try again.'};
  if(m>0)use.push({d:p.d,min:R(m)});lost=R(lost+p.min-m);free[p.d]=R(f-m)}
 use.forEach(p=>{const L=(S.days[p.d]||[]).slice(),e={act:a,min:p.min,note:note||''};if(p.d===parts[0].d)L.push(e);else L.unshift(e);S.days[p.d]=L});
 if(use.length)save();return{rec:use,lost}}
function delE(d,i){S.days[d].splice(i,1);if(!S.days[d].length)delete S.days[d];save()}
function segs(d){const T=Array.from({length:48},()=>[]);let pos=0;
 for(const e of S.days[d]||[]){const a=pos,b=R(pos+e.min);pos=b;
  for(let i=Math.floor(a/30+EPS);i<48&&i*30<b-EPS;i++){const m=R(Math.min(b,i*30+30)-Math.max(a,i*30));if(m>0)T[i].push({c:act(e.act).c,m})}}return T}
function tokBg(sg){let p=0;const st=[];for(const s of sg){st.push(s.c+' '+p/30*360+'deg '+(p+s.m)/30*360+'deg');p+=s.m}
 if(p<30-EPS)st.push('transparent '+p/30*360+'deg 360deg');return'conic-gradient('+st.join(',')+')'}
const fillPct=sg=>R(sg.reduce((s,x)=>s+x.m,0)/30*100);
const cellIdx=(r,c)=>r*6+(r%2?5-c:c);
const byAct=L=>{const o={};for(const d of L)for(const e of S.days[d]||[])o[e.act]=R((o[e.act]||0)+e.min);return o};
const ds=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const pd=s=>{const[y,m,d]=s.split('-');return new Date(+y,m-1,+d)};
const add=(s,n)=>{const d=pd(s);d.setDate(d.getDate()+n);return ds(d)};
const wk=s=>add(s,-((pd(s).getDay()+6)%7));
const mean=a=>a.reduce((s,x)=>s+x,0)/a.length;
const sd=a=>{if(a.length<2)return 0;const m=mean(a);return Math.sqrt(a.reduce((s,x)=>s+(x-m)**2,0)/(a.length-1))};
const pearson=(a,b)=>{const ma=mean(a),mb=mean(b);let n=0,x=0,y=0;for(let i=0;i<a.length;i++){n+=(a[i]-ma)*(b[i]-mb);x+=(a[i]-ma)**2;y+=(b[i]-mb)**2}return x&&y?n/Math.sqrt(x*y):null};
const slope=(xs,ys)=>{const mx=mean(xs),my=mean(ys);let n=0,d=0;for(let i=0;i<xs.length;i++){n+=(xs[i]-mx)*(ys[i]-my);d+=(xs[i]-mx)**2}return d?n/d:null};
//ENDCORE
const $=s=>document.querySelector(s),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let V={v:'ho',h:ds(new Date()),d:ds(new Date()),sr:'d',sa:'a0',wa:'a0'},M=null;
function fmt(m){m=R(m);if(S.unit==='dec')return R(m/60)+' h';if(S.unit==='min')return m+' min';const h=Math.floor(m/60+EPS),r=R(m-h*60);return h+'h'+(r?' '+r+'m':'')}
const MON=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'],fd=x=>{const d=pd(x);return S.dateFmt==='compact'?String(d.getDate()).padStart(2,'0')+' '+MON[d.getMonth()]+' '+d.getFullYear():d.toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})+' ('+d.toLocaleDateString('en-US',{weekday:'short'})+')'};
const hh=m=>{const t=Math.round(m)%1440,h=Math.floor(t/60),i=t%60,p=n=>String(n).padStart(2,'0');return S.clock==='12'?(h%12||12)+':'+p(i)+(h<12?' AM':' PM'):p(h)+':'+p(i)};
const lbl=d=>pd(d).toLocaleDateString('en-GB',{weekday:'short'})+', '+fd(d);
const sum=o=>R(Object.values(o).reduce((a,b)=>a+b,0));
const prod=d=>dayCls(d).w;
const chips=(sel,fn)=>'<div class="chips">'+S.acts.map(a=>`<button class="chip${sel===a.id?' on':''}" onclick="${fn}('${a.id}')"><i style="background:${a.c}"></i>${esc(a.n)}${CG(a)}</button>`).join('')+'</div>';
const GEAR='<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/></svg>';
const PRI=['ho','st','hi','rc','mo'],PAR={tr:'ho',se:'mo',hd:'hi'};let NS=[],DIR=0;
const IC={ho:'<path d="M4 11l8-7 8 7v9H4z"/>',st:'<path d="M5 20V11M12 20V4M19 20v-6"/>',hi:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',rc:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',mo:'<path d="M4 7h16M4 12h16M4 17h16"/>'};
const TABS=[['ho','Home'],['st','Stats'],['hi','History'],['rc','Records'],['mo','More']];
function render(){document.documentElement.dataset.t=S.theme;document.documentElement.dataset.mode=S.themeMode||'dark';const A=$('#app');
 A.innerHTML={ho:vHo,tr:vTr,st:vSt,hi:vHi,hd:vHd,rc:vRc,mo:vMo,se:vSe,br:vBr,bw:vBw,rd:vRd,so:vSo,th:vTh,...VX}[V.v]();
 const pt=PRI.includes(V.v)?V.v:(NS[0]||PAR[V.v]),n=$('#nav');
 if(!n.firstChild)n.innerHTML=TABS.map(t=>`<button data-v="${t[0]}" onclick="tab('${t[0]}')"><svg viewBox="0 0 24 24">${IC[t[0]]}</svg>${t[1]}</button>`).join('')+'<i id="ind"></i>';
 n.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.v===pt));$('#ind').style.transform='translateX('+PRI.indexOf(pt)*100+'%)';
 BC.dt=V.v==='hd'?V.h:null;board(V.v==='tr'||V.v==='hd');
 afterRender();$('#fab').style.display=V.v==='tr'?'block':'none';$('#md').innerHTML=M?vM():'';$('#md').className=M?'show':'';
 if(DIR){A.classList.remove('sl','sr','ent');void A.offsetWidth;A.classList.add(DIR>0?'sl':'sr','ent');clearTimeout(window._et);window._et=setTimeout(()=>A.classList.remove('ent'),900);DIR=0}}
function tab(v){sfx('nav');DIR=Math.sign(PRI.indexOf(v)-PRI.indexOf(PRI.includes(V.v)?V.v:PAR[V.v]));NS=[];V.v=v;render();scrollTo(0,0)}
function go(v){sfx('tap');NS.push(V.v);V.v=v;DIR=1;render();scrollTo(0,0)}
function back(){if(M){M=null;render();return true}if(NS.length){V.v=NS.pop();DIR=-1;render();scrollTo(0,0);return true}if(V.v!=='ho'){V.v='ho';DIR=-1;render();return true}return false}
window.opuxBack=back;
function vHo(){const T=ds(new Date()),t=tot(T),B=byAct([T]);
 return`<div class="row"><div><h2 style="margin:0">OPUX</h2><small>${greet()} · ${fd(T)}</small></div><button class="chip" aria-label="Settings" onclick="go('se')">${GEAR}</button></div>
 <div class="cd tw" style="margin-top:12px" onclick="V.d='${T}';go('tr')"><div class="row"><h4>Tracker</h4><small>Open ›</small></div>${S.timer?`<div class="tm row"><span>⏱ ${esc(act(S.timer.a).n)} <b id="tm">${elapsed()}</b></span></div>`:''}
 <div class="rw"><div class="rcw"><svg class="ring" viewBox="0 0 36 36"><circle class="rb" cx="18" cy="18" r="15.9"/><circle class="rf" cx="18" cy="18" r="15.9" pathLength="100" style="--p:${Math.min(100,R(t/14.4))}"/></svg><span>${Math.round(t/14.4)}%</span></div><div class="hero"><small>Today</small><b>${fmt(t)}</b><span>${fmt(R(1440-t))} untracked</span></div></div><div class="pg">${(S.days[T]||[]).map(e=>`<i style="width:${e.min/14.4}%;background:${act(e.act).c}"></i>`).join('')}</div></div>
 <div class="cd"><h4>Today's progress</h4><div class="li"><span>Productive</span><b>${fmt(prod(T))}</b></div><div class="li"><span>Sleep</span><b>${fmt(B.a1||0)}</b></div><div class="li"><span>Recorded days (all time)</span><b>${Object.keys(S.days).length}</b></div></div>`}
function vMo(){const r=(l,f)=>`<button class="mr" onclick="${f}"><span>${l}</span><span>›</span></button>`;
 return`<h2>More</h2>${r('Tracker',"go('tr')")}${r('Settings, data and backup',"go('se')")}<div class="cd"><h4>About OPUX</h4><small>Version 1.3 · package com.opux.tracker · data stored on this device.</small></div>`}
function vHd(){const d=V.h,t=tot(d),B=byAct([d]),E=S.days[d]||[];let p=0;
 return`<div class="row" style="margin-bottom:8px"><button class="chip" onclick="back()">‹ History</button><small>Read-only</small><span></span></div>
 <div class="row"><button class="chip" onclick="V.h=add(V.h,-1);render()">‹</button><div style="text-align:center"><small>${pd(d).toLocaleDateString('en-GB',{weekday:'long'})}</small><b style="display:block;font-size:19px">${fd(d)}</b></div><button class="chip" onclick="V.h=add(V.h,1);render()">›</button></div>
 <div class="bw"><canvas id="bc"></canvas></div><div class="ti" id="ti">Tap a ball for details. This view cannot change data.</div>
 <div class="cd"><div class="hero"><small>${t?'Total tracked':'Nothing tracked'}</small><b>${fmt(t)}</b><span>${fmt(R(1440-t))} untracked</span></div><div class="pg">${E.map(e=>`<i style="width:${e.min/14.4}%;background:${act(e.act).c}"></i>`).join('')}</div>
 <div class="lg">${S.acts.filter(a=>B[a.id]).map(a=>`<div><span><i class="dt" style="background:${a.c}"></i>${esc(a.n)}</span><b>${fmt(B[a.id])}</b></div>`).join('')}</div></div>
 ${dayExtras(d)}<div class="cd"><h4>Timeline</h4>${E.map(e=>{const s0=p;p=R(p+e.min);return`<div class="li" style="padding:6px 0"><span><i class="dt" style="background:${act(e.act).c}"></i>${esc(act(e.act).n)} <small>${hh(s0)}-${hh(p)} ${esc(e.note)}</small></span><b>${fmt(e.min)}</b></div>`}).join('')||'<small>Nothing recorded on this day.</small>'}</div>`}
const elapsed=()=>{const s=Math.floor((Date.now()-S.timer.t)/1000);return[Math.floor(s/3600),Math.floor(s/60)%60,s%60].map(x=>String(x).padStart(2,'0')).join(':')};
function vTr(){const d=V.d,T=segs(d),t=tot(d),B=byAct([d]);
 const E=S.days[d]||[];let p=0;
 const rows=[['Recorded',t],['Sleep',B.a1||0],['Productive',prod(d)],['Entertainment',B.a2||0],['Wasted',B.a6||0],['Untracked',R(1440-t)]];
 return`<div class="row" style="margin-bottom:8px"><button class="chip" onclick="back()">‹ Home</button><small>Tracker</small><span></span></div><div class="row"><button class="chip" onclick="V.d=add(V.d,-1);render()">‹</button><label class="dp"><small>${pd(d).toLocaleDateString(undefined,{weekday:'long'})}</small><b>${fd(d)}</b><input type="date" value="${d}" onchange="if(this.value){V.d=this.value;render()}"></label><button class="chip" onclick="V.d=add(V.d,1);render()">›</button></div>
 ${S.timer?`<div class="tm row"><span>⏱ ${esc(act(S.timer.a).n)} <b id="tm">${elapsed()}</b></span><button class="chip" onclick="stopT()">Stop</button></div>`:''}
 <div class="bw"><canvas id="bc"></canvas></div><div class="ti" id="ti">Tilt your phone, or drag sideways across the board. Tap a ball for details.</div>
 <div class="cd"><div class="hero"><small>${t?'Tracked':'Nothing tracked yet'}</small><b>${fmt(t)}</b><span>${fmt(R(1440-t))} untracked · ${R(t/14.4)}% of 24h</span></div><div class="pg">${E.map(e=>`<i style="width:${e.min/14.4}%;background:${act(e.act).c}"></i>`).join('')}</div>
 <div class="lg">${S.acts.filter(a=>B[a.id]).map(a=>`<div><span><i class="dt" style="background:${a.c}"></i>${esc(a.n)}</span><b>${fmt(B[a.id])}</b></div>`).join('')||'<small>No activity yet. Tap + to add one.</small>'}</div></div>
 <div class="cd"><h4>Day summary</h4>${rows.map(r=>`<div class="li"><span>${r[0]}</span><b>${fmt(r[1])}</b></div>`).join('')}<small>Untracked time is not counted as wasted.</small></div>
 <div class="cd"><h4>Activities (in order from 00:00)</h4>${E.map((e,i)=>{const s=p;p=R(p+e.min);return`<div class="li" style="padding:6px 0"><span><i class="dt" style="background:${act(e.act).c}"></i>${esc(act(e.act).n)} <small>${hh(s)}-${hh(p)} ${esc(e.note)}</small></span><span><b>${fmt(e.min)}</b> <button class="chip" onclick="openM(${i})">Edit</button></span></div>`}).join('')||'<small>Nothing recorded on this day.</small>'}</div>`}
function openM(i){sfx('tap');const e=i==null?null:S.days[V.d][i];M=e?{i,a:e.act,m:e.min,n:e.note}:{i:null,a:S.acts[0].id,m:'',n:''};render()}
function keep(){M.m=$('#dm').value;M.n=$('#nt').value}
function pick(a){keep();M.a=a;render()}
function vM(){const e=M.i==null?null:S.days[V.d][M.i],free=R(1440-tot(V.d)+(e?e.min:0));
 return`<div class="sheet"><div class="row"><h3>${e?'Edit':'Add'} activity</h3><button class="x" onclick="M=null;render()">✕</button></div>${chips(M.a,'pick')}
 <label>Duration · free today: ${free} min</label><div class="chips">${[5,10,15,30,60,120].map(n=>`<button class="chip" onclick="$('#dm').value=${n};syncHourFields()">${n<60?n+'m':(n/60)+'h'}</button>`).join('')}</div><div class="hour-entry"><div><label>Hours</label><input id="dm-hours" type="number" inputmode="numeric" min="0" max="24" value="${Math.floor((+M.m||0)/60)}" oninput="syncMinuteTotal()"></div><div><label>Minutes</label><input id="dm-minutes" type="number" inputmode="numeric" min="0" max="59" value="${(+M.m||0)%60}" oninput="syncMinuteTotal()"></div></div><input id="dm" type="number" inputmode="decimal" min="0" step="any" value="${M.m}" placeholder="Total minutes" aria-label="Total duration in minutes" style="margin-top:8px"><label>Notes (optional)</label><input id="nt" maxlength="200" value="${esc(M.n)}">
 <p id="er" class="er"></p><button class="btn" onclick="saveM()">Save</button>${e?'<button class="btn dn" onclick="delM()">Delete</button>':'<button class="btn ol" onclick="startT()">▶ Start timer instead</button>'}</div>`}
function saveM(){keep();const r=addE(V.d,M.a,M.m,M.n,M.i);if(r){$('#er').textContent=r;sfx('err');return}sfx('refill');M=null;render();toast('Activity saved')}
function delM(){if(confirm('Delete this activity?')){delE(V.d,M.i);sfx('del');M=null;render()}}
function startT(){keep();if(S.timer){$('#er').textContent='A timer is already running';return}S.timer={a:M.a,d:V.d,t:Date.now()};save();M=null;render()}
function stopT(){const t=S.timer;if(!t)return;const now=Date.now(),parts=splitSpan(t.t,now);S.timer=null;let msg='',got=0;
 if(parts.length){const r=putParts(parts,t.a,'Timer',false);got=R(r.rec.reduce((s,p)=>s+p.min,0));
  if(r.lost>0)msg=got>0?'A day reached its 24 h limit. Recorded '+fmt(got)+' of '+fmt(R(got+r.lost))+'.':'That day is already full. Timer time was not recorded.'}
 save();if(got>0&&S.notif&&window.Notification&&Notification.permission==='granted')new Notification('Timer saved',{body:act(t.a).n+' '+fmt(got)});
 V.d=parts.length?parts[0].d:ds(new Date(t.t));if(got>0)sfx('refill');sfx('ok');render();
 if(msg)alert(msg);else if(got>0)toast(parts.length>1?'Timer saved · '+parts.map(p=>fmt(p.min)+' on '+fd(p.d)).join(' · '):'Timer saved · '+fmt(got))}
setInterval(()=>{const e=$('#tm');if(e&&S.timer)e.textContent=elapsed()},1000);
function rng(k){const c=V.d;if(k==='d')return[c];if(k==='w'){const s=wk(c);return[0,1,2,3,4,5,6].map(i=>add(s,i))}
 if(k==='m'){const[y,m]=c.split('-').map(Number),n=new Date(y,m,0).getDate();return Array.from({length:n},(_,i)=>y+'-'+String(m).padStart(2,'0')+'-'+String(i+1).padStart(2,'0'))}
 return Object.keys(S.days).sort()}
function line(v,lb){const W=300,H=110,mx=Math.max(...v,1),n=v.length,x=i=>n>1?10+i*(W-20)/(n-1):W/2,y=q=>H-18-q/mx*(H-34);
 return`<svg viewBox="0 0 ${W} ${H}" class="ch"><polyline pathLength="1" fill="none" stroke="var(--ac)" stroke-width="2.5" points="${v.map((q,i)=>x(i)+','+y(q)).join(' ')}"/>${v.map((q,i)=>`<circle cx="${x(i)}" cy="${y(q)}" r="3" fill="var(--a2)"/>`).join('')}<text x="2" y="12" fill="#9aa3c7" font-size="9">max ${fmt(mx)}</text><text x="2" y="${H-3}" fill="#9aa3c7" font-size="9">${fd(lb[0])} to ${fd(lb[1])}</text></svg>`}
function vSt(){const k=V.sr,L=rng(k),B=byAct(L),T=sum(B),ids=S.acts.filter(a=>B[a.id]).sort((a,b)=>B[b.id]-B[a.id]);let p=0;
 const st=ids.map(a=>{const s=p/T*360;p+=B[a.id];return a.c+' '+s+'deg '+p/T*360+'deg'});
 const TL=k==='d'?Array.from({length:7},(_,i)=>add(V.d,i-6)):k==='a'?Array.from({length:30},(_,i)=>add(V.d,i-29)):L,v=TL.map(d=>byAct([d])[V.sa]||0);
 const nm={d:lbl(V.d),w:L[6]?fd(L[0])+' to '+fd(L[6]):'',m:MON[+V.d.slice(5,7)-1]+' '+V.d.slice(0,4),a:'All time, '+L.length+' recorded days'}[k];
 return`<h2>Statistics</h2><div class="sg">${[['d','Daily'],['w','Weekly'],['m','Monthly'],['a','All Time']].map(x=>`<button class="${k===x[0]?'on':''}" onclick="V.sr='${x[0]}';render()">${x[1]}</button>`).join('')}</div><small>${nm}</small>
 <div class="cd row"><div class="don" style="background:${T?'conic-gradient('+st.join(',')+')':'var(--em)'}"><b>${fmt(T)}<br><small>recorded</small></b></div><div style="flex:1">${ids.map(a=>`<div class="li"><span><i class="dt" style="background:${a.c}"></i>${esc(a.n)}</span><span>${Math.round(B[a.id]/T*1000)/10}%</span></div>`).join('')||'<small>No data in this period.</small>'}</div></div>
 <div class="cd"><h4>Total per activity</h4>${ids.map(a=>`<div style="margin-bottom:8px"><div class="li"><span>${esc(a.n)}</span><b>${fmt(B[a.id])}</b></div><div class="br" style="width:${B[ids[0].id]?B[a.id]/B[ids[0].id]*100:0}%;background:${a.c}"></div></div>`).join('')||'<small>No data.</small>'}</div>
 <div class="cd"><h4>Daily trend: ${esc(act(V.sa).n)}</h4>${chips(V.sa,'sa')}${line(v,[TL[0],TL[TL.length-1]])}</div>${k==='w'?vWk():''}${vGl()}${ins()}`}
const sa=a=>{V.sa=a;render()},wa=a=>{V.wa=a;render()};
function vWk(){const s=wk(V.d),a=V.wa,L=[0,1,2,3,4,5,6].map(i=>add(s,i)),v=L.map(d=>byAct([d])[a]||0),T=R(v.reduce((x,y)=>x+y,0)),mx=Math.max(...v,1);
 const wt=o=>R([0,1,2,3,4,5,6].reduce((q,i)=>q+(byAct([add(s,o*7+i)])[a]||0),0)),P=wt(-1),df=R(T-P),best=v.indexOf(Math.max(...v));
 return`<h4 style="margin:10px 0 6px">Weekly overview</h4><div class="row"><button class="chip" onclick="V.d=add(V.d,-7);render()">‹ Prev</button><small>${fd(L[0])} to ${fd(L[6])}</small><button class="chip" onclick="V.d=add(V.d,7);render()">Next ›</button></div>${chips(a,'wa')}
 <div class="cd"><div class="bars">${v.map((q,i)=>`<div><small>${q?fmt(q):''}</small><u style="height:${R(q/mx*120)}px;background:${act(a).c}"></u>${'MonTueWedThuFriSatSun'.slice(i*3,i*3+3)}</div>`).join('')}</div></div>
 <div class="cd"><div class="li"><span>Weekly total</span><b>${fmt(T)}</b></div><div class="li"><span>Daily average (total ÷ 7)</span><b>${fmt(T/7)}</b></div><div class="li"><span>Previous week</span><b>${fmt(P)}</b></div><div class="li"><span>Change vs previous week</span><b>${df>0?'▲ ':df<0?'▼ ':''}${fmt(Math.abs(df))}</b></div>${T?`<div class="li"><span>Highest day</span><b>${'MonTueWedThuFriSatSun'.slice(best*3,best*3+3)} ${fmt(v[best])}</b></div>`:''}</div>
 <div class="cd"><h4>Last 4 weeks: ${esc(act(a).n)}</h4>${[-3,-2,-1,0].map(o=>`<div class="li"><span>${fd(add(s,o*7))}</span><b>${fmt(wt(o))}</b></div>`).join('')}</div>`}
function vHi(){const D=Object.keys(S.days).sort().reverse();
 return`<h2>History</h2>${D.map(d=>`<div class="cd" onclick="V.h='${d}';go('hd')"><div class="row"><b>${lbl(d)}</b><span>${fmt(tot(d))} / 24h ›</span></div><div class="hs">${segs(d).map(g=>`<span style="${g.length?'background:'+tokBg(g)+',var(--em)':''}"></span>`).join('')}</div></div>`).join('')||'<div class="cd"><small>No recorded days yet. Add an activity on the Tracker screen.</small></div>'}`}
function vRc(){const D=Object.keys(S.days);const best=f=>{let b=null;for(const d of D){const v=f(d);if(v>0&&(!b||v>b.v))b={d,v}}return b};
 const card=(t,b,f)=>`<div><small>${t}</small><b>${b?fmt(b.v):'-'}</b><small>${b?fd(b.d):'no data'}</small></div>`;
 let ll=null;for(const d of D){const v=R(1440-tot(d));if(!ll||v<ll.v)ll={d,v}}
 const mt=best(d=>new Set(S.days[d].map(e=>e.act)).size),all=byAct(D);
 return`<h2>Records</h2><div class="rc">${card('Best Study Day',best(d=>byAct([d]).a0||0))}${card('Most Sleep',best(d=>byAct([d]).a1||0))}${card('Most Entertainment',best(d=>byAct([d]).a2||0))}${card('Most Productive Day',best(prod))}
 <div><small>Least Leftover</small><b>${ll?fmt(ll.v):'-'}</b><small>${ll?fd(ll.d):'no data'}</small></div><div><small>Most Activity Types</small><b>${mt?mt.v+' types':'-'}</b><small>${mt?fd(mt.d):'no data'}</small></div></div>
 <div class="cd"><h4>All-time per activity</h4>${S.acts.map(a=>{const b=best(d=>byAct([d])[a.id]||0);return`<div class="li" style="padding:4px 0"><span><i class="dt" style="background:${a.c}"></i>${esc(a.n)}</span><span><b>${fmt(all[a.id]||0)}</b> <small>best ${b?fmt(b.v)+' '+fd(b.d):'-'}</small></span></div>`}).join('')}</div><small>Productive = activities marked productive in Settings (default: Study).</small>`}
function ins(){const D=Object.keys(S.days).sort().filter(d=>tot(d)>0),n=D.length,rw=(a,b,c)=>`<div style="margin-bottom:9px"><div class="li"><span>${a}</span><b>${b}</b></div><small>${c}</small></div>`;
 if(n<2)return'<div class="cd"><h4>Insights</h4><small>Record at least 2 days to unlock insights.</small></div>';
 const sl=d=>byAct([d]).a1||0,su=d=>byAct([d]).a0||0,L=D.slice(-7),sv=L.map(sl),debt=Math.round(sv.reduce((q,x)=>q+S.st-x,0));
 const aw=D.reduce((q,d)=>q+tot(d)-sl(d),0),pr=D.reduce((q,d)=>q+prod(d),0),L14=D.slice(-14),x0=pd(L14[0]).getTime(),xs=L14.map(d=>Math.round((pd(d)-x0)/864e5)),b=slope(xs,L14.map(su)),r=pearson(D.map(su),D.map(sl));
 let sk=0,c=D[n-1];while(S.days[c]&&tot(c)>=1200){sk++;c=add(c,-1)}
 return'<div class="cd"><h4>Insights</h4>'+rw('Average sleep',fmt(Math.round(mean(sv))),`Σ sleep ÷ n, last ${L.length} recorded days (Sleep activity)`)
 +rw('Sleep vs '+R(S.st/60)+'h target',debt>0?'short '+fmt(debt):'ahead '+fmt(-debt),`Σ(target − sleep) over ${L.length} days`)
 +(L.length>2?rw('Sleep regularity (SD)',fmt(Math.round(sd(sv))),`sample SD (n−1), n=${L.length}; lower = more regular`):'')
 +rw('Productive share of awake time',aw>0?R(pr/aw*100)+'%':'-',`Σ productive ÷ Σ(recorded − sleep), ${n} days; untracked ignored`)
 +(L14.length>=5&&b!=null?rw('Study trend',(b>=0?'+':'−')+R(Math.abs(b))+' min/day',`least-squares slope, last ${L14.length} recorded days`):'')
 +(n>=5&&r!=null?rw('Study vs sleep',' r = '+R(r),`Pearson r, n=${n} days. Correlation is not causation`):'')
 +rw('Tracking streak',sk+(sk==1?' day':' days'),'consecutive days up to your latest record with ≥ 20 h tracked')+'</div>'}
function vSe(){return`<div class="row" style="margin-bottom:8px"><button class="chip" onclick="back()">‹ Back</button><small>Settings</small><span></span></div><div class="cd"><label>Daily productive goal (minutes, 0 = off)</label><input type="number" inputmode="numeric" min="0" max="1440" value="${X().goal||0}" onchange="X().goal=Math.max(0,Math.min(1440,Math.round(+this.value||0)));save()"><div class="li" style="margin-top:8px"><span>Haptic feedback</span><input type="checkbox" ${X().hap===0?'':'checked'} onchange="X().hap=this.checked?1:0;save()"></div></div><div class="cd"><button class="mr" onclick="go('so')"><span>Sounds</span><span>›</span></button><button class="mr" style="margin:0" onclick="go('th')"><span>Themes</span><span>›</span></button></div><div class="cd"><h4>Clock format</h4><div class="sg" style="margin:0">${[['24','24-hour (22:45)'],['12','12-hour (10:45 PM)']].map(o=>`<button class="${(S.clock||'24')===o[0]?'on':''}" onclick="S.clock='${o[0]}';save();render()">${o[1]}</button>`).join('')}</div><small>Applies to clock times only. Durations (e.g. 5h 35m) use Time display below.</small></div><div class="cd"><h4>Date format</h4><div class="sg" style="margin:0">${[['long','October 30, 2026 (Fri)'],['compact','30 OCT 2026']].map(o=>`<button class="${(S.dateFmt||'long')===o[0]?'on':''}" onclick="S.dateFmt='${o[0]}';save();render()">${o[1]}</button>`).join('')}</div><small>Weekday is calculated from the selected calendar date.</small></div><div class="cd"><h4>Theme</h4><div class="th">${THEMES.map(t=>`<button data-t="${t}" class="${S.theme===t?'on':''}" onclick="S.theme='${t}';save();render()"><span style="background:linear-gradient(135deg,var(--ac),var(--a2))"></span>${t[0].toUpperCase()+t.slice(1)}</button>`).join('')}</div></div>
 <div class="cd"><label>Time display</label><select onchange="S.unit=this.value;save();render()">${[['hm','Hours and minutes'],['dec','Decimal hours'],['min','Minutes']].map(o=>`<option value="${o[0]}"${S.unit===o[0]?' selected':''}>${o[1]}</option>`).join('')}</select>
 <div class="li" style="margin-top:8px"><span>Notifications (timer saved)</span><input type="checkbox" ${S.notif?'checked':''} onchange="togN(this.checked)"></div></div>
 <div class="cd"><label>Sleep target (hours per night)</label><input type="number" step="0.5" min="1" max="16" value="${S.st/60}" onchange="S.st=Math.max(60,Math.min(960,Math.round(+this.value*60)||480));save();render()"></div>
 <div class="cd"><h4>Activities</h4>${S.acts.map((a,i)=>`<div class="li act-row" style="margin-bottom:4px"><button class="swatch-btn" style="--sw:${a.c}" aria-label="Change colour of ${esc(a.n)}" onclick="openColorPick(${i})"></button><input value="${esc(a.n)}" maxlength="30" onchange="S.acts[${i}].n=this.value.trim()||S.acts[${i}].n;save()"><select class="cls-sel" aria-label="Productivity class of ${esc(a.n)}" onchange="clsPick(${i},this.value)">${['w','n','l','u'].map(k=>`<option value="${k}"${curCls(a)===k?' selected':''}>${CLS[k].g} ${CLS[k].n}</option>`).join('')}</select><button class="chip" onclick="delA(${i})">✕</button></div>`).join('')}
 <div class="li act-row"><button class="swatch-btn" id="ncb" style="--sw:${window.NCOL||'#14b8a6'}" aria-label="Choose colour for the new activity" onclick="openColorPick(-1)"></button><input type="hidden" id="nc" value="${window.NCOL||'#14b8a6'}"><input id="na" placeholder="New activity name" maxlength="30"><button class="chip" onclick="addA()">Add</button><select id="nk" class="cls-sel" aria-label="Productivity class of the new activity">${['u','w','n','l'].map(k=>`<option value="${k}">${CLS[k].g} ${CLS[k].n}</option>`).join('')}</select></div></div>
 <div class="cd"><h4>Data</h4><button class="btn ol sm" style="width:100%" onclick="expD()">Export JSON</button><button class="btn ol sm" style="width:100%;margin-top:8px" onclick="$('#imp').click()">Import JSON</button><input type="file" id="imp" accept=".json,application/json" hidden onchange="impD(this)"><button class="btn dn sm" style="width:100%;margin-top:8px" onclick="clrD()">Clear all data</button></div><div class="cd"><div class="li"><span><b>OPUX startup sound</b><br><small>Glitch, bass impact and startup chime</small></span><label style="display:flex;align-items:center;gap:8px"><input id="opux-sound-toggle" type="checkbox" ${opuxSoundOn?'checked':''} onchange="setOpuxSound(this.checked)"> On</label></div></div><small>OPUX v1.3. Data is stored on this device. Export a backup regularly.</small>`}
function togN(on){S.notif=on?1:0;if(on&&window.Notification&&Notification.permission==='default')Notification.requestPermission();save()}
function addA(){const n=$('#na').value.trim();if(!n)return alert('Enter a name');sfx('add');{const k=$('#nk')?$('#nk').value:'u',o={id:'a'+Date.now(),n:n.slice(0,30),c:$('#nc').value,p:k==='w'?1:0};if(k!=='u')o.cls=k;S.acts.push(o)}save();render()}
function delA(i){const a=S.acts[i];if(S.acts.length<2)return alert('Keep at least one activity');if(Object.values(S.days).some(L=>L.some(e=>e.act===a.id)))return alert('"'+a.n+'" has recorded time, so it cannot be deleted. Delete those records first.');S.acts.splice(i,1);save();render()}
function opuxSaved(ok){toast(ok?'File saved':'File was not saved')}
function expD(){const n='24h-tracker-'+ds(new Date())+'.json';if(window.OpuxAndroid&&OpuxAndroid.saveFile){OpuxAndroid.saveFile(n,JSON.stringify(S,null,1));return}const b=new Blob([JSON.stringify(S,null,1)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='24h-tracker-'+ds(new Date())+'.json';document.body.appendChild(a);a.click();a.remove()}
function impD(el){const f=el.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{let o;try{o=clean(JSON.parse(r.result))}catch(e){o='File is not valid JSON'}
 if(typeof o==='string'){alert('Import failed: '+o+'. Your data was not changed.');return}
 if(confirm('Replace all current data with this file ('+Object.keys(o.days).length+' days)?')){S=o;save();render()}};r.readAsText(f);el.value=''}
function clrD(){if(confirm('Delete ALL recorded data? This cannot be undone.')&&confirm('Really delete everything?')){const th=S.theme;S=fresh();S.theme=th;save();render()}}

//LIQUID
const BC={th:0,v:0,tg:0,sg:0,w:0,ph:0,an:[],sig:[],ios:0,drag:0,cv:null};
function solve(f){if(f<=1e-9)return 1;if(f>=1-1e-9)return -1;let a=-1,b=1;for(let n=0;n<30;n++){const m=(a+b)/2,A=(Math.acos(m)-m*Math.sqrt(1-m*m))/Math.PI;if(A>f)a=m;else b=m}return(a+b)/2}
function glass(){const c=BC.c*BC.dpr,st=getComputedStyle(document.documentElement),em=st.getPropertyValue('--em').trim(),bd=st.getPropertyValue('--bd').trim();
 const mk=fn=>{const o=document.createElement('canvas');o.width=o.height=Math.round(c);const x=o.getContext('2d');x.translate(c/2,c/2);fn(x,c*.45);return o},arc=(x,R)=>{x.beginPath();x.arc(0,0,R,0,7)};
 BC.b=mk((x,R)=>{const g=x.createRadialGradient(0,-R*.3,R*.1,0,0,R);g.addColorStop(0,em);g.addColorStop(1,'#000');x.fillStyle=g;arc(x,R);x.fill();x.strokeStyle=bd;x.lineWidth=c*.025;x.stroke()});
 BC.t=mk((x,R)=>{let g=x.createRadialGradient(0,0,R*.55,0,0,R);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.45)');x.fillStyle=g;arc(x,R);x.fill();
  g=x.createRadialGradient(-R*.33,-R*.42,0,-R*.33,-R*.42,R*.5);g.addColorStop(0,'rgba(255,255,255,.6)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.beginPath();x.ellipse(-R*.33,-R*.42,R*.42,R*.26,-.6,0,7);x.fill();
  x.strokeStyle='rgba(255,255,255,.22)';x.lineWidth=c*.02;arc(x,R);x.stroke()})}
let AX=null;function sfx(k){if(k!=='slide')hp();if(!opuxSoundOn||!sfxGate(k))return;try{AX=AX||new(window.AudioContext||window.webkitAudioContext)();if(AX.state==='suspended')AX.resume();const t=AX.currentTime,P={tap:[520,780,.06,'sine',.06],nav:[700,900,.05,'sine',.04],add:[330,660,.18,'sine',.09],refill:[190,520,.34,'sine',.11],slide:[420,760,.16,'triangle',.055],del:[420,110,.22,'triangle',.12],err:[170,110,.25,'square',.05],ok:[520,1040,.4,'sine',.12],p_soft:[520,780,.06,'sine',.06],p_click:[1200,600,.03,'square',.03],p_chime:[880,1320,.25,'sine',.09],p_bell:[660,990,.4,'triangle',.08],p_pop:[300,700,.08,'sine',.1]}[sfxKey(k)],o=AX.createOscillator(),g=AX.createGain();
 o.type=P[3];o.frequency.setValueAtTime(P[0],t);o.frequency.exponentialRampToValueAtTime(P[1],t+P[2]);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(Math.max(.0002,P[4]*snv()),t+.01);g.gain.exponentialRampToValueAtTime(.0001,t+P[2]+.08);o.connect(g);g.connect(AX.destination);o.start(t);o.stop(t+P[2]+.1)}catch(e){}}
const GL={};function glow(c,px){const k=c+px;if(!GL[k]){const o=document.createElement('canvas');o.width=o.height=px;const x=o.getContext('2d'),g=x.createRadialGradient(px/2,px/2,px*.2,px/2,px/2,px/2);g.addColorStop(0,c+'aa');g.addColorStop(.75,c+'55');g.addColorStop(1,c+'00');x.fillStyle=g;x.fillRect(0,0,px,px);GL[k]=o}return GL[k]}
function board(on){cancelAnimationFrame(BC.raf);BC.cv=null;if(!on)return;const cv=$('#bc');if(!cv)return;const W=cv.parentElement.clientWidth;
 BC.cv=cv;BC.c=W/6;BC.dpr=Math.min(devicePixelRatio||1,2);cv.style.width=W+'px';cv.style.height=BC.c*8+'px';cv.width=Math.round(W*BC.dpr);cv.height=Math.round(BC.c*8*BC.dpr);
 BC.T=segs(BC.dt||V.d);glass();BC.T.forEach((g,i)=>{const q=g.map(z=>z.c+z.m).join();if(q!==BC.sig[i]){BC.sig[i]=q;BC.an[i]=0}});
 let dn=null,mv=0;
 cv.onpointerdown=e=>{dn=e.clientX;mv=0;BC.drag=1;if(window.DeviceMotionEvent&&DeviceMotionEvent.requestPermission){BC.ios=1;DeviceMotionEvent.requestPermission().catch(()=>0)}};
 cv.onpointermove=e=>{if(dn==null)return;mv=Math.max(mv,Math.abs(e.clientX-dn));const r=cv.getBoundingClientRect();BC.tg=Math.max(-1,Math.min(1,(e.clientX-r.left-r.width/2)/(r.width/2)))*1.3};
 cv.onpointerup=cv.onpointercancel=e=>{if(dn==null)return;const r=cv.getBoundingClientRect();
  if(mv<6){const i=cellIdx(Math.floor((e.clientY-r.top)/BC.c),Math.floor((e.clientX-r.left)/BC.c));if(BC.T[i]){sfx('tap');const f=fillPct(BC.T[i]);$('#ti').textContent='Token '+(i+1)+' · '+hh(i*30)+'-'+hh(i*30+30)+' · '+f+'% filled'}}
  if(mv>=6)sfx('slide');dn=null;BC.drag=0;BC.tg=BC.sg};
 let lastFrame=performance.now();const x=cv.getContext('2d'),c=BC.c,d=BC.dpr,Ri=c*.45*.94,lg=x.createLinearGradient(0,-Ri,0,Ri);lg.addColorStop(0,'rgba(255,255,255,.22)');lg.addColorStop(1,'rgba(0,0,0,.3)');
 (function f(){if(!cv.isConnected||BC.cv!==cv)return;BC.raf=requestAnimationFrame(f);const now=performance.now(),dt=Math.min(40,now-lastFrame);lastFrame=now;
  let df=BC.tg-BC.th;df-=6.2832*Math.round(df/6.2832);BC.v=BC.v*.945+df*.035;BC.th+=BC.v;BC.w=Math.max(BC.w*.97,Math.min(.1,Math.abs(BC.v)*1.6));BC.ph+=.07;
  const A=.012+BC.w;x.setTransform(d,0,0,d,0,0);x.clearRect(0,0,cv.width,cv.height);
  for(let i=0;i<48;i++){const g=BC.T[i];if(!g.length)continue;const r=i/6|0,k=r%2?5-i%6:i%6;x.globalAlpha=fillPct(g)/100*.5;x.drawImage(glow(g[g.length-1].c,Math.round(c*1.3*d)),(k+.5)*c-c*.65,(r+.5)*c-c*.65,c*1.3,c*1.3)}x.globalAlpha=1;
  for(let r=0;r<8;r++)for(let k=0;k<6;k++){const i=cellIdx(r,k),cx=(k+.5)*c,cy=(r+.5)*c,g=BC.T[i];x.drawImage(BC.b,cx-c/2,cy-c/2,c,c);
   if(!g.length){x.fillStyle='rgba(255,255,255,.2)';x.font=c*.24+'px system-ui';x.textAlign='center';x.textBaseline='middle';x.fillText(i+1,cx,cy)}
   else{BC.an[i]=Math.min(1,BC.an[i]+dt/820);const a=Math.max(0,BC.an[i]),e=1-(1-a)**3;let cum=0;const ts=g.map(q=>{cum+=q.m;return solve(Math.min(cum/30*e,.97))});
    x.save();x.translate(cx,cy);x.beginPath();x.arc(0,0,Ri,0,7);x.clip();x.rotate(-BC.th);
    for(let j=g.length-1;j>=0;j--){const t=ts[j];if(t>=.999)continue;x.fillStyle=g[j].c;x.beginPath();
     if(t<=-.999)x.rect(-Ri,-Ri,2*Ri,3*Ri);else{const y0=t*Ri;x.moveTo(-Ri,y0+Math.sin(BC.ph+i+j-3)*A*Ri);for(let q=-Ri;q<=Ri;q+=Ri/6)x.lineTo(q,y0+Math.sin(q/Ri*3+BC.ph+i+j)*A*Ri);x.lineTo(Ri,2*Ri);x.lineTo(-Ri,2*Ri);x.closePath()}
     x.fill()}
    x.fillStyle=lg;x.fillRect(-Ri,-Ri,2*Ri,2*Ri);x.restore()}
   x.drawImage(BC.t,cx-c/2+Math.sin(BC.th)*c*.03,cy-c/2-Math.cos(BC.th)*c*.03,c,c)}})()}
let pa=null;addEventListener('devicemotion',e=>{const a=e.accelerationIncludingGravity;if(!a||a.x==null)return;const k=BC.ios?-1:1,gx=-a.x*k,gy=a.y*k;
 if(Math.hypot(gx,gy)>2.5){BC.sg=Math.atan2(gx,gy);if(!BC.drag)BC.tg=BC.sg}
 if(pa)BC.v+=(Math.random()-.5)*Math.min(Math.hypot(a.x-pa.x,a.y-pa.y,a.z-pa.z),15)*.004;pa={x:a.x,y:a.y,z:a.z}});
addEventListener('resize',()=>{if(V.v==='tr'||V.v==='hd')board(1)});
//ENDLIQUID

// OPUX STARTUP: procedural sound design (no external audio files/network needed)
const OPUX_SOUND_KEY='opux_sound_v1';
let opuxSoundOn=(()=>{try{return localStorage.getItem(OPUX_SOUND_KEY)!=='0'}catch(e){return true}})();
function setOpuxSound(on){opuxSoundOn=!!on;try{localStorage.setItem(OPUX_SOUND_KEY,opuxSoundOn?'1':'0')}catch(e){};const el=document.getElementById('opux-sound-toggle');if(el)el.checked=opuxSoundOn}
function opuxAudio(){
 if(!opuxSoundOn)return;
 const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
 try{
  const c=new AC();const master=c.createGain();master.gain.value=.48;master.connect(c.destination);
  const now=c.currentTime;
  const tone=(f,t,d,type='sine',vol=.12,endf=null)=>{const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(f,t);if(endf)o.frequency.exponentialRampToValueAtTime(Math.max(25,endf),t+d);g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(vol,t+.012);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(master);o.start(t);o.stop(t+d+.03)};
  const noise=(t,d,vol=.12,filter=1800)=>{const n=Math.max(1,Math.floor(c.sampleRate*d)),b=c.createBuffer(1,n,c.sampleRate),a=b.getChannelData(0);for(let i=0;i<n;i++)a[i]=(Math.random()*2-1)*(1-i/n);const s=c.createBufferSource(),f=c.createBiquadFilter(),g=c.createGain();s.buffer=b;f.type='highpass';f.frequency.value=filter;g.gain.setValueAtTime(vol,t);g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(f);f.connect(g);g.connect(master);s.start(t);s.stop(t+d)};
  // digital wake-up, glitch burst, logo impact, then a clean three-note resolve
  tone(110,now,.72,'sawtooth',.10,42);tone(880,now+.28,.16,'square',.045,210);noise(now+.42,.22,.09,2600);
  for(let i=0;i<5;i++){const t=now+.72+i*.105;tone(220+Math.random()*900,t,.075,'square',.035,90+Math.random()*1200)}
  noise(now+1.52,.32,.16,120);tone(62,now+1.52,.9,'sine',.42,34);tone(124,now+1.55,.55,'triangle',.13,58);
  tone(523.25,now+3.05,.34,'sine',.11);tone(659.25,now+3.22,.38,'sine',.10);tone(783.99,now+3.42,.72,'sine',.13);
  setTimeout(()=>{try{c.close()}catch(e){}},5200);
 }catch(e){}
}
(function opuxBoot(){
 const el=document.getElementById('opux-boot');if(!el)return;
 const word=document.getElementById('opux-word'),target='OPUX',chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&';let started=false;
 const begin=()=>{if(started)return;started=true;try{opuxAudio()}catch(e){};el.classList.add('ready');let frame=0;const scramble=setInterval(()=>{frame++;let out='';for(let i=0;i<target.length;i++)out+=frame>i*3+5?target[i]:chars[Math.floor(Math.random()*chars.length)];word.textContent=out;if(frame>19){clearInterval(scramble);word.textContent=target}},65)};
 // Android WebView permits startup audio when mediaPlaybackRequiresUserGesture=false.
 // In a regular browser, the first touch unlocks audio if autoplay is restricted.
 begin();const unlock=()=>{if(!started){begin()}else if(opuxSoundOn){/* resume is handled by the first boot call */}};
 window.addEventListener('pointerdown',unlock,{once:true,passive:true});
 setTimeout(()=>{el.classList.add('finish');setTimeout(()=>{el.classList.add('out');setTimeout(()=>el.remove(),800)},180)},1400);
})();

//MODULES
function cleanExt(e){const id=v=>typeof v==='string'&&/^[\w-]{1,40}$/.test(v),st=(v,n)=>String(v==null?'':v).slice(0,n),nm=v=>typeof v==='number'&&isFinite(v)?v:0,dt=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\d$/.test(v),
 o={goal:Math.max(0,Math.min(1440,Math.round(+e.goal||0))),hap:e.hap===0?0:1,checkinAt:nm(e.checkinAt)||Date.now(),snoozeUntil:nm(e.snoozeUntil),checkinEvery:[45,60,90,120].includes(+e.checkinEvery)?+e.checkinEvery:60,br:[],rd:{s:null,e:[]},ms:[],snd:{vol:.7,cat:{},sel:{},imp:[],amb:'off',av:.3},hw:['br','pg','rd']};
 for(const b of Array.isArray(e.br)?e.br:[]){if(!b||!id(b.id)||!Array.isArray(b.nodes))continue;const ids={},nodes=[];
  for(const n of b.nodes){if(!n||!id(n.id))continue;ids[n.id]=1;nodes.push({id:n.id,t:st(n.t,120),x:nm(n.x),y:nm(n.y),p:id(n.p)?n.p:null,note:st(n.note,4000),url:st(n.url,500),img:typeof n.img==='string'&&n.img.startsWith('data:image/')?n.img:'',att:(Array.isArray(n.att)?n.att:[]).filter(a=>a&&typeof a.d==='string'&&a.d.startsWith('data:')).map(a=>({n:st(a.n,100),d:a.d})),c:n.c?1:0})}
  for(const n of nodes)if(n.p&&!ids[n.p])n.p=null;
  o.br.push({id:b.id,n:st(b.n,80),lay:['radial','tree','mind'].includes(b.lay)?b.lay:'radial',nodes,links:(Array.isArray(b.links)?b.links:[]).filter(l=>Array.isArray(l)&&ids[l[0]]&&ids[l[1]]).map(l=>[l[0],l[1]])})}
 const r=e.rd||{};if(r.s&&dt(r.s.start)&&+r.s.days>=1&&+r.s.days<=3650)o.rd.s={n:st(r.s.n,60),start:r.s.start,days:Math.round(+r.s.days)};
 o.rd.e=(Array.isArray(r.e)?r.e:[]).filter(q=>q&&id(q.id)&&dt(q.d)).map(q=>({id:q.id,d:q.d,t:st(q.t,2000),a:st(q.a,80),k:q.k==='n'?'n':'q'}));
 o.ms=(Array.isArray(e.ms)?e.ms:[]).filter(q=>q&&id(q.id)&&dt(q.d)).map(q=>({id:q.id,d:q.d,t:st(q.t,80),n:st(q.n,300)}));
 const z=e.snd||{};o.snd.vol=Math.max(0,Math.min(1,+z.vol>=0?+z.vol:.7));o.snd.av=Math.max(0,Math.min(1,+z.av>=0?+z.av:.3));if(['off','rain','rumble'].includes(z.amb))o.snd.amb=z.amb;
 for(const k in z.cat||{})if(/^\w{1,10}$/.test(k))o.snd.cat[k]=z.cat[k]===0?0:1;for(const k in z.sel||{})if(/^\w{1,10}$/.test(k))o.snd.sel[k]=st(z.sel[k],30);
 o.snd.imp=(Array.isArray(z.imp)?z.imp:[]).filter(q=>q&&id(q.id)&&typeof q.d==='string'&&q.d.startsWith('data:audio')).map(q=>({id:q.id,n:st(q.n,60),d:q.d}));
 if(Array.isArray(e.hw)){const h=e.hw.filter(k=>['br','pg','rd'].includes(k));for(const k of['br','pg','rd'])if(!h.includes(k))h.push(k);o.hw=h.filter((k,i)=>h.indexOf(k)===i)}
 ext22(e,o);return o}
const X=()=>{if(!S.ext||typeof S.ext!=='object')S.ext=cleanExt({});if(!S.ext.checkinAt)S.ext.checkinAt=Date.now();if(![45,60,90,120].includes(+S.ext.checkinEvery))S.ext.checkinEvery=60;return S.ext};
const uid=()=>'x'+Date.now().toString(36)+Math.random().toString(36).slice(2,6),RM=()=>{const m=S.ext&&S.ext.rm;return m==='on'?true:m==='off'?false:matchMedia('(prefers-reduced-motion:reduce)').matches};
const bk=t=>`<div class="row" style="margin-bottom:8px"><button class="chip" onclick="back()">‹ Back</button><small>${t}</small><span></span></div>`;
// ---- side panels
let SP=null;
document.body.insertAdjacentHTML('beforeend','<div id="scrim"></div><aside id="sp"><div class="row"><b id="spt"></b><button class="x" aria-label="Close" onclick="closeSP()">✕</button></div><div id="spb"></div></aside>');
$('#scrim').onclick=()=>closeSP();
function openSP(side,t,f){SP={side,f};const a=$('#sp');$('#spt').textContent=t;$('#spb').innerHTML=f();a.className=side;void a.offsetWidth;a.classList.add('on');$('#scrim').classList.add('on');sfx('tap')}
function closeSP(){if(!SP)return;SP=null;$('#sp').classList.remove('on');$('#scrim').classList.remove('on')}
function refreshSP(){if(SP)$('#spb').innerHTML=SP.f()}
(function(){let x0=0,y0=0;const a=$('#sp');a.addEventListener('touchstart',e=>{x0=e.touches[0].clientX;y0=e.touches[0].clientY},{passive:true});
 a.addEventListener('touchend',e=>{if(!SP)return;const t=e.changedTouches[0],dx=t.clientX-x0,dy=t.clientY-y0;if(Math.abs(dx)>70&&Math.abs(dy)<Math.abs(dx)*.6&&(SP.side==='r'?dx>0:dx<0))closeSP()},{passive:true})})();
function tab(v){closeSP();sfx('nav');DIR=Math.sign(PRI.indexOf(v)-PRI.indexOf(PRI.includes(V.v)?V.v:(NS[0]||PAR[V.v])));NS=[];V.v=v;render();scrollTo(0,0)}
function go(v){closeSP();sfx('tap');NS.push(V.v);V.v=v;DIR=1;render();scrollTo(0,0)}
function back(){if(SP){closeSP();return true}if(M){M=null;render();return true}if(NS.length){V.v=NS.pop();DIR=-1;render();scrollTo(0,0);return true}if(V.v!=='ho'){V.v='ho';DIR=-1;render();return true}return false}
function afterRender(){if(DIR)countUp();if(V.v==='bw'){bwInit();if(!BW.fit){fitBW();BW.fit=1}drawBW()}if(V.v==='rd')rdStart();else rdStop()}
// ---- helpers: files
function pickFile(acc,cb){const i=document.createElement('input');i.type='file';i.accept=acc;i.onchange=()=>{if(i.files[0])cb(i.files[0])};i.click()}
function readFile(f,max,cb){if(f.size>max){alert('File is too large ('+Math.round(f.size/1024)+' KB). Limit: '+Math.round(max/1024)+' KB.');return}const r=new FileReader();r.onload=()=>cb(r.result);r.readAsDataURL(f)}
function readImg(f,cb){const r=new FileReader();r.onload=()=>{const im=new Image();im.onload=()=>{const k=Math.min(1,800/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);c.getContext('2d').drawImage(im,0,0,c.width,c.height);cb(c.toDataURL('image/jpeg',.75))};im.onerror=()=>alert('Could not read this image');im.src=r.result};r.readAsDataURL(f)}
function saveDataUrl(n,d){if(window.OpuxAndroid&&OpuxAndroid.saveData){OpuxAndroid.saveData(n,d.slice(5,d.indexOf(';')),d.split(',')[1]);return}const a=document.createElement('a');a.href=d;a.download=n;document.body.appendChild(a);a.click();a.remove()}
// ---- Branch workspace
const BW={id:null,tx:0,ty:0,k:1,sel:null,nw:null,cn:null,fit:0,mode:'view',snapshot:null};
const curB=()=>X().br.find(b=>b.id===BW.id),kids=(b,id)=>b.nodes.filter(n=>n.p===id);
function vis(b){const o=[];const f=n=>{o.push(n);if(!n.c)kids(b,n.id).forEach(f)};b.nodes.filter(n=>!n.p).forEach(f);return o}
function lay(b){const root=b.nodes.find(n=>!n.p);if(!root)return;const L={};const cnt=n=>L[n.id]=n.c?1:Math.max(1,kids(b,n.id).reduce((q,k)=>q+cnt(k),0));cnt(root);
 if(b.lay==='tree'){let leaf=0;(function f(n,d){const ks=n.c?[]:kids(b,n.id);if(!ks.length){n.x=leaf++*150;n.y=d*110;return}ks.forEach(k=>f(k,d+1));n.x=(ks[0].x+ks[ks.length-1].x)/2;n.y=d*110})(root,0);const ox=root.x;vis(b).forEach(n=>n.x-=ox)}
 else if(b.lay==='radial'){root.x=0;root.y=0;(function f(n,a0,a1,d){const ks=n.c?[]:kids(b,n.id);let a=a0;ks.forEach(k=>{const w=(a1-a0)*L[k.id]/L[n.id],m=a+w/2;k.x=Math.cos(m)*d*170;k.y=Math.sin(m)*d*170;f(k,a,a+w,d+1);a+=w})})(root,-Math.PI/2,Math.PI*1.5,1)}
 else{root.x=0;root.y=0;const ks=root.c?[]:kids(b,root.id),h=Math.ceil(ks.length/2);[[ks.slice(0,h),1],[ks.slice(h),-1]].forEach(([g,sg])=>{let leaf=0;const T=g.reduce((q,k)=>q+L[k.id],0);const f=(n,d)=>{const q=n.c?[]:kids(b,n.id);if(!q.length){n.y=(leaf++-(T-1)/2)*60;n.x=sg*d*200;return}q.forEach(k=>f(k,d+1));n.y=(q[0].y+q[q.length-1].y)/2;n.x=sg*d*200};g.forEach(k=>f(k,1))})}
}
function drawBW(){const b=curB(),g=$('#bg');if(!b||!g)return;const VS=vis(b),id={};VS.forEach(n=>id[n.id]=n);let h='';
 for(const n of VS){const p=n.p&&id[n.p];if(!p)continue;const dx=(n.x-p.x)/2;h+=`<path class="ed${BW.nw===n.id?' rv':''}" pathLength="1" d="M${p.x} ${p.y}C${p.x+dx} ${p.y} ${n.x-dx} ${n.y} ${n.x} ${n.y}"/>`}
 for(const l of b.links)if(id[l[0]]&&id[l[1]])h+=`<path class="ed lk" d="M${id[l[0]].x} ${id[l[0]].y}L${id[l[1]].x} ${id[l[1]].y}"/>`;
 for(const n of VS){const ks=kids(b,n.id).length,tg=[n.img?'img':'',n.url?'link':'',n.att.length?'file':''].filter(Boolean).join(' ');
  h+=`<g data-id="${n.id}" transform="translate(${n.x} ${n.y})"><g class="in${BW.sel===n.id?' sl':''}${BW.nw===n.id?' gr':''}"><rect x="-64" y="-19" width="128" height="38" rx="9"/><text text-anchor="middle" dy=".35em">${esc(n.t||'Untitled').slice(0,20)}</text>${n.c&&ks?`<text x="64" y="-22" text-anchor="end" class="bt">+${ks}</text>`:''}${tg?`<text x="-60" y="30" class="bt">${tg}</text>`:''}</g></g>`}
 g.innerHTML=h;g.setAttribute('transform',`translate(${BW.tx} ${BW.ty}) scale(${BW.k})`)}
function fitBW(){const b=curB();if(!b)return;const V2=vis(b);if(!V2.length)return;const s=$('#bs'),r=s?s.getBoundingClientRect():{width:360,height:480},W=r.width||360,H=r.height||480;
 const x0=Math.min(...V2.map(n=>n.x))-80,x1=Math.max(...V2.map(n=>n.x))+80,y0=Math.min(...V2.map(n=>n.y))-40,y1=Math.max(...V2.map(n=>n.y))+40;
 BW.k=Math.max(.3,Math.min(1.5,W/(x1-x0),H/(y1-y0)));BW.tx=W/2-(x0+x1)/2*BW.k;BW.ty=H/2-(y0+y1)/2*BW.k}
function relayout(){const b=curB();if(!b)return;const o=b.nodes.map(n=>[n.x,n.y]);lay(b);const w=b.nodes.map(n=>[n.x,n.y]);save();
 if(RM()){drawBW();BW.nw=null;return}const t0=performance.now();(function f(){const u=Math.min(1,(performance.now()-t0)/560),e=u<.5?4*u*u*u:1-(-2*u+2)**3/2;b.nodes.forEach((n,i)=>{n.x=o[i][0]+(w[i][0]-o[i][0])*e;n.y=o[i][1]+(w[i][1]-o[i][1])*e});drawBW();if(u<1&&V.v==='bw')requestAnimationFrame(f);else{b.nodes.forEach((n,i)=>{n.x=w[i][0];n.y=w[i][1]});drawBW();setTimeout(()=>{BW.nw=null},600)}})()}
function focusNode(n){const s=$('#bs');if(!s)return;const r=s.getBoundingClientRect(),tx=r.width/2-n.x*BW.k,ty=r.height*.4-n.y*BW.k;if(RM()){BW.tx=tx;BW.ty=ty;drawBW();return}const a=BW.tx,c=BW.ty,t0=performance.now();(function f(){const u=Math.min(1,(performance.now()-t0)/260),e=1-(1-u)**3;BW.tx=a+(tx-a)*e;BW.ty=c+(ty-c)*e;$('#bg')&&$('#bg').setAttribute('transform',`translate(${BW.tx} ${BW.ty}) scale(${BW.k})`);if(u<1)requestAnimationFrame(f)})()}
function bwInit(){const s=$('#bs');if(!s)return;const P=new Map();let drag=null,pan=null,pin=null,st=null,mv=0;
 const pt=e=>{const r=s.getBoundingClientRect();return[(e.clientX-r.left-BW.tx)/BW.k,(e.clientY-r.top-BW.ty)/BW.k]},dist=()=>{const a=[...P.values()];return Math.hypot(a[0][0]-a[1][0],a[0][1]-a[1][1])},tf=()=>$('#bg').setAttribute('transform',`translate(${BW.tx} ${BW.ty}) scale(${BW.k})`);
 s.onpointerdown=e=>{s.setPointerCapture(e.pointerId);P.set(e.pointerId,[e.clientX,e.clientY]);if(P.size===2){pin={d:dist(),k:BW.k};drag=pan=null;mv=99;return}
  st=[e.clientX,e.clientY];mv=0;const nd=e.target.closest('[data-id]');if(nd)drag={id:nd.dataset.id};else pan={x:e.clientX-BW.tx,y:e.clientY-BW.ty}};
 s.onpointermove=e=>{if(!P.has(e.pointerId))return;P.set(e.pointerId,[e.clientX,e.clientY]);
  if(pin&&P.size===2){BW.k=Math.max(.2,Math.min(3,pin.k*dist()/pin.d));tf();return}
  if(st)mv=Math.max(mv,Math.hypot(e.clientX-st[0],e.clientY-st[1]));
  if(drag&&mv>6){const n=curB().nodes.find(q=>q.id===drag.id),q=pt(e);n.x=q[0];n.y=q[1];drawBW()}else if(pan&&mv>3){BW.tx=e.clientX-pan.x;BW.ty=e.clientY-pan.y;tf()}};
 s.onpointerup=s.onpointercancel=e=>{P.delete(e.pointerId);if(pin){if(P.size<2)pin=null;return}
  if(drag){if(mv<=6)selNode(drag.id);else save()}else if(pan&&mv<=3){BW.sel=null;drawBW();closeSP()}drag=pan=null};
 s.onwheel=e=>{e.preventDefault();BW.k=Math.max(.2,Math.min(3,BW.k*(e.deltaY<0?1.1:.9)));tf()}}
function selNode(id){const b=curB();if(BW.cn){const a=BW.cn;BW.cn=null;if(a!==id){const i=b.links.findIndex(l=>(l[0]===a&&l[1]===id)||(l[0]===id&&l[1]===a));if(i>=0)b.links.splice(i,1);else b.links.push([a,id]);save();sfx('add')}BW.sel=id;drawBW();const h=$('#bh');if(h)h.textContent='Connection toggled.';return}
 BW.sel=id;drawBW();focusNode(b.nodes.find(n=>n.id===id));openSP('r','Node',nodeHtml)}
const selN=()=>{const b=curB();return b&&b.nodes.find(q=>q.id===BW.sel)};
function nodeEditHtml(){const b=curB(),n=selN();if(!n)return'<small>No node selected.</small>';const ks=kids(b,n.id).length,lk=b.links.map((l,i)=>[l,i]).filter(([l])=>l[0]===n.id||l[1]===n.id);
 return`<label>Title</label><input value="${esc(n.t)}" maxlength="120" onchange="nodeSet('t',this.value)"><label>Note</label><textarea rows="4" onchange="nodeSet('note',this.value)">${esc(n.note)}</textarea><label>Link (https://…)</label><input value="${esc(n.url)}" inputmode="url" onchange="nodeSet('url',this.value)">
 ${/^https?:\/\//i.test(n.url)?`<a class="lnk" href="${esc(n.url)}" target="_blank" rel="noopener">Open link</a>`:''}${n.img?`<img class="ni" src="${n.img}" alt=""><button class="chip" onclick="nodeSet('img','',1)">Remove image</button>`:''}
 ${n.att.map((a,i)=>`<div class="li" style="margin:6px 0"><span style="overflow:hidden;text-overflow:ellipsis">${esc(a.n)}</span><span><button class="chip" onclick="dlAtt(${i})">Save</button> <button class="chip" onclick="rmAtt(${i})">✕</button></span></div>`).join('')}
 ${lk.map(([l,i])=>{const o=b.nodes.find(q=>q.id===(l[0]===n.id?l[1]:l[0]));return`<div class="li" style="margin:6px 0"><small>Linked: ${esc(o?o.t:'?')}</small><button class="chip" onclick="unlink(${i})">✕</button></div>`}).join('')}
 <div class="chips"><button class="chip" onclick="addImg()">Add image</button><button class="chip" onclick="addAtt()">Add file</button></div>
 <button class="btn sm" style="width:100%" onclick="addNode()">Add sub-branch</button><button class="btn ol sm" style="width:100%;margin-top:8px" onclick="BW.cn=BW.sel;closeSP();$('#bh').textContent='Tap the node to connect to (tap again to unlink)'">Connect to another node</button>
 ${ks?`<button class="btn ol sm" style="width:100%;margin-top:8px" onclick="togC()">${n.c?'Expand':'Collapse'} (${ks} direct)</button>`:''}${n.p?'<button class="btn dn sm" style="width:100%;margin-top:8px" onclick="delNode()">Delete node and sub-branches</button>':''}`}
function nodeHtml(){const b=curB(),n=selN();if(!n)return'<small>No node selected.</small>';if(BW.mode==='edit')return nodeEditHtml();const kidsCount=kids(b,n.id).length,links=b.links.filter(l=>l.includes(n.id)).length;return`<div class="node-view"><div class="node-kicker">BRANCH NODE</div><h2>${esc(n.t)}</h2>${n.note?`<p>${esc(n.note)}</p>`:'<small>No description added.</small>'}<div class="node-meta"><span>${kidsCount} child nodes</span><span>${links} connections</span></div>${n.img?`<img class="ni" src="${n.img}" alt="">`:''}${n.url&&/^https?:\/\//i.test(n.url)?`<a class="lnk" href="${esc(n.url)}" target="_blank" rel="noopener">Open linked resource ↗</a>`:''}${n.att.length?`<h4>Attachments</h4>${n.att.map(a=>`<div class="li"><span>${esc(a.n)}</span><button class="chip" onclick="saveDataUrl('${esc(a.n)}','${a.d}')">Save</button></div>`).join('')}`:''}<button class="btn" onclick="beginBranchEdit('${n.id}')">Edit this node</button></div>`}
function beginBranchEdit(id){const b=curB();if(!b)return;BW.snapshot=JSON.stringify(b);BW.mode='edit';if(id)BW.sel=id;render();if(id)openSP('r','Edit node',nodeHtml);toast('Edit mode');}
function finishBranchEdit(commit){const b=curB();if(!b)return;if(!commit&&BW.snapshot){const restored=JSON.parse(BW.snapshot),list=X().br,ix=list.findIndex(x=>x.id===restored.id);if(ix>=0)list[ix]=restored;}BW.snapshot=null;BW.mode='view';save();closeSP();render();if(!commit)toast('Changes discarded');else toast('Branch saved');}
function nodeSet(k,v,r){const n=selN();if(!n)return;n[k]=k==='t'?v.slice(0,120):k==='note'?v.slice(0,4000):v.slice(0,k==='url'?500:undefined);save();drawBW();if(r||k==='url')refreshSP()}
function addNode(){const b=curB();if(!b)return;const par=selN()||b.nodes.find(n=>!n.p);const n={id:uid(),t:'New node',x:par.x,y:par.y,p:par.id,note:'',url:'',img:'',att:[],c:0};par.c=0;b.nodes.push(n);BW.sel=n.id;BW.nw=n.id;sfx('add');relayout();openSP('r','Node',nodeHtml)}
function togC(){const n=selN(),b=curB();n.c=n.c?0:1;relayout();refreshSP()}
function delNode(){const b=curB(),n=selN();if(!n||!n.p||!confirm('Delete "'+n.t+'" and everything under it?'))return;const dead={};(function f(q){dead[q.id]=1;kids(b,q.id).forEach(f)})(n);b.nodes=b.nodes.filter(q=>!dead[q.id]);b.links=b.links.filter(l=>!dead[l[0]]&&!dead[l[1]]);BW.sel=null;closeSP();sfx('del');relayout()}
function unlink(i){curB().links.splice(i,1);save();drawBW();refreshSP()}
function addImg(){pickFile('image/*',f=>readImg(f,d=>{nodeSet('img',d,1)}))}
function addAtt(){pickFile('*/*',f=>readFile(f,400*1024,d=>{selN().att.push({n:f.name.slice(0,100),d});save();drawBW();refreshSP()}))}
function dlAtt(i){const a=selN().att[i];saveDataUrl(a.n,a.d)}
function rmAtt(i){selN().att.splice(i,1);save();drawBW();refreshSP()}
function setLay(l){const b=curB();b.lay=l;save();render();relayout();setTimeout(()=>{smoothFit()},600)}
function brSP(){openSP('r','Branch',()=>{const b=curB();return`<label>Branch name</label><input value="${esc(b.n)}" maxlength="80" onchange="curB().n=this.value.trim()||'Untitled branch';save();render()"><small>${b.nodes.length} nodes · ${b.links.length} extra connections</small><button class="btn dn sm" style="width:100%;margin-top:12px" onclick="delBr('${b.id}')">Delete this branch</button>`})}
const TPL=[['Blank','',[]],['Project','Project',['Goals','Tasks','Notes']],['Study','Subject',['Topic 1','Topic 2','Topic 3']],['Mind map','Central idea',['Idea 1','Idea 2','Idea 3','Idea 4']],['Decision','Decision',['Option A','Option B','Criteria']]];
function newBr(i){const t=TPL[i],nm=($('#bn').value.trim()||(i?t[0]:'Untitled branch')).slice(0,80),r={id:uid(),t:i?t[1]:nm,x:0,y:0,p:null,note:'',url:'',img:'',att:[],c:0},b={id:uid(),n:nm,lay:'radial',nodes:[r],links:[]};
 t[2].forEach(q=>b.nodes.push({id:uid(),t:q,x:0,y:0,p:r.id,note:'',url:'',img:'',att:[],c:0}));lay(b);X().br.push(b);save();sfx('add');openBr(b.id)}
function openBr(id){BW.id=id;BW.fit=0;BW.sel=null;BW.cn=null;BW.mode='view';BW.snapshot=null;go('bw')}
function delBr(id){const b=X().br.find(q=>q.id===id);if(!b||!confirm('Delete branch "'+b.n+'" with all its nodes?'))return;X().br=X().br.filter(q=>q.id!==id);save();sfx('del');closeSP();if(V.v==='bw'){back()}else render()}
function vBr(){const L=X().br;return`${bk('Branch Library')}<div class="branch-library-hero"><div class="node-kicker">YOUR KNOWLEDGE SPACE</div><h2>Ideas,<br><em>connected.</em></h2><p>Build a living map of the things that matter.</p><div class="library-count"><b>${L.length.toString().padStart(2,'0')}</b><span>BRANCHES IN YOUR ATLAS</span></div></div><div class="cd branch-create"><div class="node-kicker">START A NEW MAP</div><input id="bn" maxlength="80" placeholder="Name your branch"><div class="chips">${TPL.map((t,i)=>`<button class="chip" onclick="newBr(${i})">${t[0]}</button>`).join('')}</div><small>Choose a blank canvas or begin with a structured template. Template labels are editable.</small></div>
 <div class="branch-library-list"><div class="row"><h3>Your branches</h3><small>${L.length} TOTAL</small></div>${L.map((b,i)=>`<article class="branch-library-card"><div class="branch-card-art"><div class="mini-orbit"><i></i><b></b><span></span></div><small>${String(i+1).padStart(2,'0')} ／ ${b.lay.toUpperCase()}</small></div><div class="branch-card-copy"><h3>${esc(b.n||'Untitled')}</h3><small>${b.nodes.length} nodes · ${b.links.length} extra connections</small><button class="btn sm" onclick="openBr('${b.id}')">Open workspace ↗</button></div></article>`).join('')||'<div class="empty-branch">No branches yet. Start with a blank map or choose a template above.</div>'}</div>`}
function vBw(){const b=curB();if(!b)return bk('Branch')+'<small>Branch not found.</small>';const editing=BW.mode==='edit';
 return`<div class="branch-head"><div class="row"><button class="chip" onclick="back()">‹ Branches</button><span class="branch-state">${editing?'EDITING':'VIEW MODE'}</span><button class="chip" onclick="brSP()">•••</button></div><h2>${esc(b.n)}</h2><small>${b.nodes.length} nodes · ${b.links.length} relationships · ${b.lay.toUpperCase()} LAYOUT</small></div>
 <div class="branch-toolbar">${editing?`<button class="chip" onclick="finishBranchEdit(false)">Cancel</button><button class="btn sm" onclick="finishBranchEdit(true)">Save changes</button>`:`<button class="btn sm" onclick="beginBranchEdit()">Edit branch</button><button class="chip" onclick="fitBW();drawBW()">Recenter</button>`}</div>
 ${editing?`<div class="chips branch-layouts">${[['radial','Radial'],['tree','Tree'],['mind','Mind map']].map(l=>`<button class="chip${b.lay===l[0]?' on':''}" onclick="setLay('${l[0]}')">${l[1]}</button>`).join('')}<button class="chip" onclick="addNode()">+ Add node</button></div>`:`<div class="branch-hint">Explore the map · drag to move · pinch to zoom · tap a node to inspect</div>`}
 <div class="branch-stage"><div class="stage-label">NEURAL ATLAS <span>／ ${editing?'EDIT':'EXPLORE'}</span></div><svg id="bs" class="bs"><g id="bg"></g></svg><div class="stage-foot"><span>● ${b.nodes.length} NODES</span><span>${editing?'DRAG TO REPOSITION':'TAP TO FOCUS'}</span></div></div>
 ${editing?`<div class="branch-edit-note">Changes are held in an edit session. Save to keep them or Cancel to restore the previous branch.</div>`:''}`}
// ---- RDBD
let RDT=null,RDI=-1,RE=null,RDM=false;
const rdQ=()=>X().rd.e.filter(q=>q.k==='q'),dayN=()=>Math.round(pd(ds(new Date()))/864e5);
function rdToday(){const q=rdQ();return q.length?q[dayN()%q.length]:null}
function rdSeason(){const s=X().rd.s;if(!s)return null;const n=Math.round((pd(ds(new Date()))-pd(s.start))/864e5)+1;return{n:s.n,txt:n<1?'Starts in '+(1-n)+' days':n>s.days?'Ended '+fd(add(s.start,s.days-1)):'Day '+n+' of '+s.days+' · '+(s.days-n)+' days left',p:Math.max(0,Math.min(1,n/s.days))}}
function rdCard(){const q=rdQ();if(!q.length)return'<small>No quotes yet. Add your own below.</small>';if(RDI<0)RDI=dayN()%q.length;RDI=(RDI%q.length+q.length)%q.length;const e=q[RDI];return`<div class="quote-index">DAILY REFLECTION <span>${String(RDI+1).padStart(2,'0')} / ${String(q.length).padStart(2,'0')}</span></div><p class="qt">“${esc(e.t)}”</p>${e.a?`<small class="quote-author">— ${esc(e.a)}</small>`:''}<div class="dots" aria-label="Quote ${RDI+1} of ${q.length}">${q.map((_,i)=>`<i class="${i===RDI?'on':''}"></i>`).join('')}</div><div class="rd-progress-track"><i id="rd-progress"></i></div>`}
function rdGo(d,automatic=false){rdPause();RDI+=d;const c=$('#rcq');if(c)c.innerHTML=rdCard();if(!RDM)rdStart()}
function rdPause(){clearInterval(RDT);RDT=null;const p=$('#rd-progress');if(p)p.classList.remove('running')}
function rdStop(){rdPause()}
function rdStart(){rdPause();const c=$('#rcq');if(!c)return;if(rdQ().length>1&&!RDM&&!RM()&&!document.hidden&&!c.matches(':focus-within')){const p=$('#rd-progress');if(p){p.classList.remove('running');void p.offsetWidth;p.classList.add('running')}RDT=setInterval(()=>{if(V.v==='rd'&&!document.hidden&&!c.matches(':focus-within'))rdGo(1,true);else rdPause()},7000)}let x0=0;c.ontouchstart=e=>{x0=e.touches[0].clientX;rdPause()};c.ontouchend=e=>{const dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>45)rdGo(dx<0?1:-1);else rdStart()};c.onpointerdown=()=>rdPause();c.onpointerup=()=>rdStart();c.onfocusin=()=>rdPause();c.onfocusout=()=>rdStart()}
document.addEventListener('visibilitychange',()=>{if(document.hidden)rdPause();else if(V.v==='rd')rdStart()});
function rdSave(){const t=$('#rt').value.trim();if(!t){sfx('err');return}const r=X().rd,k=$('#rk').value==='n'?'n':'q',a=$('#ra').value.trim().slice(0,80);if(RE){const e=r.e.find(q=>q.id===RE);if(e){e.t=t.slice(0,2000);e.a=a;e.k=k}RE=null}else r.e.push({id:uid(),d:ds(new Date()),t:t.slice(0,2000),a,k});save();sfx('add');render();toast('Entry saved')}
function rdEdit(id){RE=id;RDM=true;render();scrollTo(0,document.body.scrollHeight)}
function rdDel(id){if(!confirm('Delete this entry?'))return;X().rd.e=X().rd.e.filter(q=>q.id!==id);save();sfx('del');render()}
function rdSeasonSave(){const n=$('#sn').value.trim().slice(0,60),st=$('#ss').value,d=Math.round(+$('#sd').value);if(!n||!/^\d{4}-\d\d-\d\d$/.test(st)||!(d>=1&&d<=3650)){alert('Enter a name, a start date and a length of 1 to 3650 days.');sfx('err');return}X().rd.s={n,start:st,days:d};save();sfx('add');render()}
function rdSeasonClear(){if(confirm('Remove the current season?')){X().rd.s=null;save();render()}}
function vRd(){const r=X().rd,s=rdSeason(),ed=RE&&r.e.find(q=>q.id===RE),editing=RDM;rdStop();
 return`<div class="row" style="margin-bottom:12px"><button class="chip" onclick="back()">‹ Back</button><small>Return Day By Day</small><button class="chip" onclick="RDM=!RDM;RE=null;render()">${editing?'Done':'Edit RDBD'}</button></div><div class="rdbd-intro"><div class="rdbd-orbit"><span>R</span><i></i><b></b></div><div><div class="node-kicker">YOUR DAILY CONTINUITY</div><h2>Return, day by day.</h2><small>A record of the person you are becoming.</small></div></div>
 <div class="season-panel"><div class="node-kicker">CURRENT SEASON</div>${s?`<b>${esc(s.n)}</b><div class="li"><small>${s.txt}</small></div><div class="season-track"><i style="width:${s.p*100}%"></i></div>${editing?`<button class="chip" onclick="rdSeasonClear()">End season</button>`:''}`:`<small>No active season${editing?' yet.':' is currently set.'}</small>`}${editing?`<div id="season-form"><input id="sn" maxlength="60" placeholder="Season name"><label>Start date</label><input id="ss" type="date" value="${ds(new Date())}"><label>Length (days)</label><input id="sd" type="number" inputmode="numeric" min="1" max="3650" placeholder="e.g. 30"><button class="btn" onclick="rdSeasonSave()">Save season</button></div>`:''}</div>
 <div class="quote-stage"><div class="quote-topline"><span>THE DAILY PAGE</span><span>RDBD ／ ${fd(ds(new Date()))}</span></div><div id="rcq" class="rcq">${rdCard()}</div><div class="quote-controls">${rdQ().length>1?`<button class="chip" aria-label="Previous quote" onclick="rdGo(-1)">←</button><small>Swipe to move · pauses while you interact</small><button class="chip" aria-label="Next quote" onclick="rdGo(1)">→</button>`:`<small>Your quotes appear here as a daily sequence.</small>`}</div></div>
 ${editing?`<div class="cd rdbd-editor"><div class="node-kicker">${ed?'EDIT ENTRY':'ADD TO YOUR RECORD'}</div><h3>${ed?'Revise this entry':'Keep a thought'}</h3><select id="rk"><option value="q"${ed&&ed.k==='n'?'':' selected'}>Quote (shown in the daily sequence)</option><option value="n"${ed&&ed.k==='n'?' selected':''}>Written note</option></select><textarea id="rt" rows="4" maxlength="2000" placeholder="Write your own text">${ed?esc(ed.t):''}</textarea><input id="ra" maxlength="80" placeholder="Author or source (optional)" value="${ed?esc(ed.a):''}"><div class="row"><button class="btn" onclick="rdSave()">${ed?'Save changes':'Add entry'}</button>${ed?`<button class="chip" onclick="RE=null;render()">Cancel</button>`:''}</div></div><div class="rdbd-entries"><div class="row"><h3>Collected moments</h3><small>${r.e.length} ENTRIES</small></div>${r.e.slice().reverse().map(e=>`<article class="entry-row"><small>${fd(e.d)} · ${e.k==='q'?'QUOTE':'NOTE'}</small><p>${esc(e.t)}</p>${e.a?`<small>— ${esc(e.a)}</small>`:''}<div><button class="chip" onclick="rdEdit('${e.id}')">Edit</button> <button class="chip" onclick="rdDel('${e.id}')">Delete</button></div></article>`).join('')||'<small>No entries yet. Your record starts with what you choose to add.</small>'}</div>`:`<div class="rdbd-view-note">Your daily sequence and season stay here. Open Edit RDBD when you want to manage quotes, notes or season details.</div>`}`}
// ---- Home / More / Themes
function moveW(k,d){const h=X().hw,i=h.indexOf(k),j=i+d;if(j<0||j>=h.length)return;[h[i],h[j]]=[h[j],h[i]];save();render()}
function qaSP(){openSP('l','Quick actions',()=>`<button class="mr" onclick="closeSP();V.d=ds(new Date());go('tr');openM(null)"><span>Add activity</span><span>›</span></button><button class="mr" onclick="closeSP();go('br')"><span>New branch</span><span>›</span></button><button class="mr" onclick="closeSP();go('rd')"><span>New RDBD entry</span><span>›</span></button><button class="mr" onclick="closeSP();go('th')"><span>Change theme</span><span>›</span></button><button class="mr" onclick="closeSP();go('so')"><span>Sound settings</span><span>›</span></button>`)}
function vHo(){const T=ds(new Date()),t=tot(T),B=byAct([T]),e=X(),W={
 br:()=>`<div class="cd"><div class="row"><h4>Branch Library</h4><small onclick="go('br')">Open ›</small></div>${e.br.length?e.br.slice(0,3).map(b=>`<div class="li" style="padding:6px 0" onclick="openBr('${b.id}')"><span>${esc(b.n||'Untitled')}</span><small>${b.nodes.length} nodes</small></div>`).join(''):'<small>No branches yet.</small>'}<button class="btn ol sm" style="width:100%" onclick="go('br')">New branch</button></div>`,
 pg:()=>`<div class="cd"><h4>Today's progress</h4><div class="li"><span>Productive</span><b>${fmt(prod(T))}</b></div><div class="li"><span>Sleep</span><b>${fmt(B.a1||0)}</b></div>${goalRow(T)}<div class="li"><span>Tracked share of 24h</span><b>${R(t/14.4)}%</b></div><div class="li"><span>Recorded days (all time)</span><b>${Object.keys(S.days).length}</b></div></div>`,
 rd:()=>{const q=rdToday(),s=rdSeason();return`<div class="cd tw" onclick="go('rd')"><div class="row"><h4>RDBD</h4><small>Open ›</small></div>${q?`<p class="qt" style="font-size:17px">“${esc(q.t)}”</p>${q.a?`<small>— ${esc(q.a)}</small>`:''}<small class="quote-date">Written ${fd(q.d)}</small>`:'<small>No entries yet. Add your own quotes and notes.</small>'}${s?`<div class="li" style="margin-top:8px"><small>${esc(s.n)}</small><small>${s.txt}</small></div>`:''}</div>`}};
 return`<div class="row"><div><h2 style="margin:0">OPUX</h2><small>${greet()} · ${fd(T)}</small></div><span><button class="chip" aria-label="Quick actions" onclick="qaSP()">Quick</button> <button class="chip" aria-label="Settings" onclick="go('se')">${GEAR}</button></span></div>
 <div class="home-atlas"><div class="atlas-copy"><div class="node-kicker">PERSONAL OPERATING SPACE</div><div class="atlas-title">Your day,<br><em>in orbit.</em></div><small>24-HOUR PERSONAL MAP</small><div class="atlas-status"><i></i> SYSTEM ACTIVE <span>／ LOCAL TIME</span></div></div><div class="atlas-visual" aria-hidden="true"><div class="atlas-halo halo-a"></div><div class="atlas-halo halo-b"></div><div class="atlas-core"><span>${Math.round(t/14.4)}<small>%</small></span><i>DAY</i></div><b class="atlas-node n1"></b><b class="atlas-node n2"></b><b class="atlas-node n3"></b><div class="atlas-orbit-label">24H / ${fmt(t)} TRACKED</div></div><div class="atlas-foot"><span>01 ／ TODAY'S SYSTEM</span><span>LIVE DATA</span></div></div>
 <div class="cd tw" style="margin-top:12px" onclick="V.d='${T}';go('tr')"><div class="row"><h4>Tracker</h4><small>Open ›</small></div>${S.timer?`<div class="tm row"><span>⏱ ${esc(act(S.timer.a).n)} <b id="tm">${elapsed()}</b></span></div>`:''}<div class="rw"><div class="rcw"><svg class="ring" viewBox="0 0 36 36"><circle class="rb" cx="18" cy="18" r="15.9"/><circle class="rf" cx="18" cy="18" r="15.9" pathLength="100" style="--p:${Math.min(100,R(t/14.4))}"/></svg><span>${Math.round(t/14.4)}%</span></div><div class="hero"><small>Today</small><b>${fmt(t)}</b><span>${fmt(R(1440-t))} untracked</span></div></div><div class="pg">${(S.days[T]||[]).map(q=>`<i style="width:${q.min/14.4}%;background:${act(q.act).c}"></i>`).join('')}</div></div>
 ${e.hw.map(k=>`${V.ha?`<div class="row ar"><small>${{br:'Branch Library',pg:'Progress',rd:'RDBD'}[k]}</small><span><button class="chip" onclick="moveW('${k}',-1)">▲</button> <button class="chip" onclick="moveW('${k}',1)">▼</button></span></div>`:''}${W[k]()}`).join('')}
 <button class="chip" onclick="V.ha=!V.ha;render()">${V.ha?'Done arranging':'Arrange widgets'}</button>`}
function vMo(){const r=(l,f)=>`<button class="mr" onclick="${f}"><span>${l}</span><span>›</span></button>`;
 return`<h2>More</h2>${r('Branches',"go('br')")}${r('RDBD',"go('rd')")}${r('Tracker',"V.d=ds(new Date());go('tr')")}${r('Themes',"go('th')")}${r('Sounds',"go('so')")}${r('Settings',"go('se')")}${r('Data and backup',"go('se')")}<div class="cd"><h4>About OPUX</h4><small>Version 2.0.0 · com.opux.tracker · all data stays on this device. Export a backup regularly.</small></div>`}
const TN={graphite:'Graphite',midnight:'Midnight',daylight:'Daylight',paper:'Paper',classic:'Classic',ocean:'Ocean',sunset:'Sunset',neon:'Ember',forest:'Forest',pastel:'Pastel'};
// Palette previews are fixed to each palette's own accent identity, not the active theme.
const THEME_SWATCH={
 graphite:{dark:['#4f8cff','#8ab0ff'],light:['#4f8cff','#8ab0ff']},
 midnight:{dark:['#38bdf8','#818cf8'],light:['#0284c7','#6366f1']},
 daylight:{dark:['#2563eb','#0e7490'],light:['#2563eb','#0e7490']},
 paper:{dark:['#b45309','#0f766e'],light:['#b45309','#0f766e']},
 classic:{dark:['#6366f1','#a855f7'],light:['#6366f1','#9333ea']},
 ocean:{dark:['#06b6d4','#3b82f6'],light:['#0891b2','#2563eb']},
 sunset:{dark:['#f97316','#ec4899'],light:['#ea580c','#db2777']},
 neon:{dark:['#ff2a2a','#ff7a00'],light:['#dc2626','#ea580c']},
 forest:{dark:['#22c55e','#a3e635'],light:['#16a34a','#65a30d']},
 pastel:{dark:['#f9a8d4','#a5b4fc'],light:['#db2777','#6366f1']}
};
function setThemeMode(mode){if(!['dark','light'].includes(mode))return;S.themeMode=mode;save();sfx('tap');render()}
function setThemePalette(theme){if(!THEMES.includes(theme))return;S.theme=theme;S.darkTheme=theme;S.lightTheme=theme;save();sfx('tap');render()}
function vTh(){const mode=S.themeMode||'dark';
 const g=l=>`<div class="th">${l.map(t=>{const c=THEME_SWATCH[t][mode]||THEME_SWATCH[t].dark;return `<button data-t="${t}" class="${S.theme===t?'on':''}" onclick="setThemePalette('${t}')"><span style="background:linear-gradient(135deg,${c[0]},${c[1]})"></span>${TN[t]}</button>`}).join('')}</div>`;
 return`${bk('Appearance')}<h4>Appearance mode</h4><div class="sg" style="margin:8px 0 14px"><button class="${mode==='dark'?'on':''}" onclick="setThemeMode('dark')">Dark mode</button><button class="${mode==='light'?'on':''}" onclick="setThemeMode('light')">Light mode</button></div><h4>Colour palette</h4>${g(THEMES)}<small style="display:block;margin-top:12px">The same colour palettes are available in both appearance modes. Switching light/dark keeps your selected palette. Activity colours on the Tracker never change.</small>`}
// ---- Records
function recList(){const D=Object.keys(S.days).filter(d=>tot(d)>0).sort(),o=[],cl=id=>(S.acts.find(a=>a.id===id)||{}).c||'var(--ac)';
 const best=(t,f,c,fm)=>{let b=null;for(const d of D){const v=f(d);if(v>0&&(!b||v>b.v))b={d,v}}if(b)o.push({t,v:fm?fm(b.v):fmt(b.v),d:b.d,c})};
 best('Best study day',d=>byAct([d]).a0||0,cl('a0'));best('Most productive day',prod,'var(--ac)');best('Most sleep',d=>byAct([d]).a1||0,cl('a1'));best('Most entertainment',d=>byAct([d]).a2||0,cl('a2'));
 best('Most activity types',d=>new Set(S.days[d].map(e=>e.act)).size,'var(--a2)',v=>v+' types');
 let ll=null;for(const d of D){const v=R(1440-tot(d));if(!ll||v<ll.v)ll={d,v}}if(ll)o.push({t:'Least untracked time',v:fmt(ll.v),d:ll.d,c:'var(--a2)'});
 let bs=0,be=null,run=0,rs=null,pv=null;for(const d of D){if(tot(d)>=1200){run=pv&&add(pv,1)===d?run+1:1;if(run===1)rs=d;pv=d;if(run>bs){bs=run;be={s:rs,e:d}}}else{run=0;pv=null}}
 if(bs)o.push({t:'Longest tracking streak',v:bs+(bs==1?' day':' days'),d:be.e,r:fd(be.s)+' to '+fd(be.e),c:'var(--ac)',n:'days with at least 20 h tracked'});
 for(const a of S.acts){if(['a0','a1','a2'].includes(a.id))continue;best('Most '+a.n,d=>byAct([d])[a.id]||0,a.c)}
 return o}
function trophy(c){return`<svg viewBox="0 0 48 48" width="44" height="44" style="color:${c}" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 8h20v10a10 10 0 0 1-20 0z" fill="currentColor" fill-opacity=".25"/><path d="M14 11H8v3a6 6 0 0 0 6 6M34 11h6v3a6 6 0 0 1-6 6M24 28v8M16 41h16"/></svg>`}
function addMs(){const t=$('#mt').value.trim();if(!t){sfx('err');return}toast('Milestone added');X().ms.push({id:uid(),d:/^\d{4}-\d\d-\d\d$/.test($('#md2').value)?$('#md2').value:ds(new Date()),t:t.slice(0,80),n:$('#mn').value.trim().slice(0,300)});save();sfx('add');render()}
function delMs(id){if(confirm('Delete this milestone?')){X().ms=X().ms.filter(q=>q.id!==id);save();render()}}
function vRc(){const rl=recList(),m=V.rt||'c',ms=X().ms.slice().sort((a,b)=>a.d<b.d?1:-1),dd=r=>r.r||fd(r.d);
 const cards=rl.length?`<div class="rc">${rl.map(r=>`<div><small>${r.t}</small><b>${r.v}</b><small>${dd(r)}</small>${r.n?`<small>${r.n}</small>`:''}<span class="tg">Calculated</span></div>`).join('')}</div>`:'<div class="cd"><small>No records yet. They are calculated from your recorded days.</small></div>';
 let cab='';if(rl.length){cab='<div class="cab">';for(let i=0;i<rl.length;i+=3)cab+=`<div class="shelf">${rl.slice(i,i+3).map(r=>`<div class="tro">${trophy(r.c)}<b>${r.v}</b><small>${r.t}</small><small>${dd(r)}</small></div>`).join('')}</div>`;cab+='</div>'}else cab='<div class="cd"><small>The cabinet fills as records are calculated from your data.</small></div>';
 return`<h2>Records</h2><div class="sg"><button class="${m==='c'?'on':''}" onclick="V.rt='c';render()">Achievement cards</button><button class="${m==='t'?'on':''}" onclick="V.rt='t';render()">Trophy cabinet</button></div>${m==='c'?cards:cab}
 <div class="cd"><h4>Milestones <span class="tg" style="position:static">Manual</span></h4>${ms.map(q=>`<div class="li" style="padding:6px 0"><span><b>${esc(q.t)}</b><br><small>${fd(q.d)}${q.n?' · '+esc(q.n):''}</small></span><button class="chip" onclick="delMs('${q.id}')">✕</button></div>`).join('')||'<small>None yet. Milestones you add here are your own, not calculated.</small>'}
 <input id="mt" maxlength="80" placeholder="Milestone title"><input id="md2" type="date" value="${ds(new Date())}"><input id="mn" maxlength="300" placeholder="Note (optional)"><button class="btn ol sm" style="width:100%" onclick="addMs()">Add milestone</button></div>
 <small>Calculated records use your recorded days. Productive = activities marked productive in Settings. Streak counts days with at least 20 h tracked.</small>`}
function dayExtras(d){const rl=recList().filter(r=>r.d===d),ms=X().ms.filter(q=>q.d===d),nt=(S.days[d]||[]).filter(e=>e.note&&e.note!=='Timer');
 if(!rl.length&&!ms.length&&!nt.length)return'';return`<div class="cd"><h4>Notes and records</h4>${rl.map(r=>`<div class="li"><span>Record: ${r.t}</span><b>${r.v}</b></div>`).join('')}${ms.map(q=>`<div class="li"><span>Milestone: ${esc(q.t)}</span></div>`).join('')}${nt.map(e=>`<div class="li"><span>${esc(act(e.act).n)}: ${esc(e.note)}</span></div>`).join('')}</div>`}
// ---- Graph library
const GT=[['line','Line'],['bar','Bar'],['area','Stacked area'],['don','Doughnut'],['heat','Heatmap'],['sc','Scatter'],['hi','Histogram'],['rad','Radar']],GA=['line','bar','sc','hi'];
const gi=t=>{const e=$('#gi');if(e)e.textContent=t},emp=m=>`<small>${m}</small>`,sv=(H,b)=>`<svg viewBox="0 0 300 ${H}" class="ch">${b}</svg>`,ax=(x,y,t,a)=>`<text x="${x}" y="${y}" class="ax"${a?` text-anchor="${a}"`:''}>${t}</text>`;
function gLine(SD,H){const A=SD.filter(d=>tot(d)>0);if(A.length<2)return emp('Needs at least 2 recorded days in this period.');const v=A.map(d=>byAct([d])[V.sa]||0),mx=Math.max(...v,1),x=i=>12+i*276/(A.length-1),y=q=>H-22-q/mx*(H-40);
 return sv(H,`<polyline pathLength="1" fill="none" stroke="var(--ac)" stroke-width="2" points="${v.map((q,i)=>x(i)+','+y(q)).join(' ')}"/>${v.map((q,i)=>`<circle cx="${x(i)}" cy="${y(q)}" r="6" fill="var(--a2)" onclick="gi('${fd(A[i])}: ${fmt(q)}')"/>`).join('')}${ax(2,10,'max '+fmt(mx))}${ax(2,H-4,fd(A[0])+' to '+fd(A[A.length-1]))}`)}
function gBar(SD,H){const A=SD.slice(-31),v=A.map(d=>byAct([d])[V.sa]||0),mx=Math.max(...v);if(!mx)return emp('No time recorded for this activity in the period.');const w=276/A.length;
 return sv(H,v.map((q,i)=>`<rect x="${12+i*w+1}" y="${H-22-q/mx*(H-40)}" width="${Math.max(1,w-2)}" height="${q/mx*(H-40)}" fill="${act(V.sa).c}" rx="2" onclick="gi('${fd(A[i])}: ${fmt(q)}')"/>`).join('')+ax(2,10,'max '+fmt(mx))+ax(2,H-4,fd(A[0])+' to '+fd(A[A.length-1])))}
function gArea(SD,H){const A=SD.filter(d=>tot(d)>0).slice(-60);if(A.length<2)return emp('Needs at least 2 recorded days in this period.');const ids=S.acts.filter(a=>A.some(d=>byAct([d])[a.id])),mx=Math.max(...A.map(tot),1),x=i=>12+i*276/(A.length-1),y=q=>H-22-q/mx*(H-40),cum=A.map(()=>0);let h='';
 for(const a of ids){const lo=cum.slice();A.forEach((d,i)=>cum[i]+=byAct([d])[a.id]||0);const hi=cum.slice(),tt=R(A.reduce((q,d)=>q+(byAct([d])[a.id]||0),0));h+=`<path fill="${a.c}" fill-opacity=".85" d="M${hi.map((q,i)=>x(i)+' '+y(q)).join('L')}L${lo.map((q,i)=>x(i)+' '+y(q)).reverse().join('L')}Z" onclick="gi('${qq(a.n)}: ${fmt(tt)} total')"/>`}
 return sv(H,h+ax(2,10,'max '+fmt(mx)+' per day')+ax(2,H-4,fd(A[0])+' to '+fd(A[A.length-1])))}
function gDon(SD,H){const B=byAct(SD),T=sum(B);if(!T)return emp('No data in this period.');const C=2*Math.PI*50;let off=0;return sv(H,S.acts.filter(a=>B[a.id]).map(a=>{const f=B[a.id]/T,r=`<circle cx="150" cy="${H/2}" r="50" fill="none" stroke="${a.c}" stroke-width="26" stroke-dasharray="${f*C} ${C}" stroke-dashoffset="${-off*C}" transform="rotate(-90 150 ${H/2})" onclick="gi('${qq(a.n)}: ${fmt(B[a.id])} (${R(f*100)}%)')"/>`;off+=f;return r}).join('')+`<text x="150" y="${H/2+4}" text-anchor="middle" class="ax" style="font-size:12px">${fmt(T)}</text>`)}
function gHeat(){const end=add(wk(V.d),6),st=add(end,-83);let any=0,h='';for(let w=0;w<12;w++)for(let r=0;r<7;r++){const d=add(st,w*7+r),t=tot(d);if(t)any=1;h+=`<rect x="${10+w*23}" y="${6+r*22}" width="20" height="20" rx="4" fill="${t?'var(--ac)':'var(--em)'}" fill-opacity="${t?Math.max(.2,t/1440):1}" onclick="gi('${fd(d)}: ${t?fmt(t):'nothing recorded'}')"/>`}
 return any?sv(160,h):emp('No recorded days in the 12 weeks ending '+fd(end)+'.')}
function gSc(SD,H){const yi=V.sa==='a1'?'a0':'a1',P=SD.map(d=>[byAct([d])[V.sa]||0,byAct([d])[yi]||0,d]).filter(p=>p[0]>0&&p[1]>0);if(P.length<3)return emp('Needs at least 3 days with both activities recorded.');const mx=Math.max(...P.map(p=>p[0])),my=Math.max(...P.map(p=>p[1]));
 return sv(H,`<path d="M30 8V${H-24}H292" fill="none" stroke="var(--bd)"/>`+P.map(p=>`<circle cx="${30+p[0]/mx*254}" cy="${H-24-p[1]/my*(H-40)}" r="6" fill="var(--ac)" fill-opacity=".8" onclick="gi('${fd(p[2])}: ${fmt(p[0])} / ${fmt(p[1])}')"/>`).join('')+ax(292,H-8,esc(act(V.sa).n),'end')+ax(34,12,esc(act(yi).n)+' (y)'))}
function gHi(SD,H){const E=[];SD.forEach(d=>(S.days[d]||[]).forEach(e=>{if(e.act===V.sa)E.push(e.min)}));if(!E.length)return emp('No sessions for this activity in the period.');const ed=[0,15,30,60,120,240,1441],lb=['<15m','15-30m','30-60m','1-2h','2-4h','4h+'],c=lb.map((_,i)=>E.filter(m=>m>ed[i]&&m<=ed[i+1]||(i===0&&m>0&&m<=15)).length),mx=Math.max(...c),w=276/6;
 return sv(H,c.map((q,i)=>`<rect x="${12+i*w+3}" y="${H-24-q/mx*(H-44)}" width="${w-6}" height="${q/mx*(H-44)}" fill="${act(V.sa).c}" rx="3" onclick="gi('${lb[i]}: ${q} sessions')"/>${ax(12+i*w+w/2,H-10,lb[i],'middle')}`).join('')+ax(2,10,E.length+' sessions'))}
function gRad(SD,H){const B=byAct(SD),ids=S.acts.filter(a=>B[a.id]);if(ids.length<3)return emp('Needs at least 3 activities with recorded time.');const mx=Math.max(...ids.map(a=>B[a.id])),cx=150,cy=H/2,r=H/2-26,pt=(i,f)=>[cx+Math.cos(i*2*Math.PI/ids.length-Math.PI/2)*r*f,cy+Math.sin(i*2*Math.PI/ids.length-Math.PI/2)*r*f];
 return sv(H,[.5,1].map(f=>`<polygon fill="none" stroke="var(--bd)" points="${ids.map((_,i)=>pt(i,f).join(',')).join(' ')}"/>`).join('')+`<polygon fill="var(--ac)" fill-opacity=".3" stroke="var(--ac)" points="${ids.map((a,i)=>pt(i,B[a.id]/mx).join(',')).join(' ')}"/>`+ids.map((a,i)=>{const q=pt(i,1.18);return`<circle cx="${pt(i,B[a.id]/mx)[0]}" cy="${pt(i,B[a.id]/mx)[1]}" r="5" fill="${a.c}" onclick="gi('${qq(a.n)}: ${fmt(B[a.id])}')"/>${ax(q[0],q[1],esc(a.n).slice(0,9),'middle')}`}).join(''))}
function vGl(){const g=V.gt||'line',k=V.sr,SD=k==='d'?Array.from({length:7},(_,i)=>add(V.d,i-6)):k==='w'?rng('w'):k==='m'?rng('m'):rng('a').slice(-90),H=V.gx?260:160,F={line:gLine,bar:gBar,area:gArea,don:gDon,heat:gHeat,sc:gSc,hi:gHi,rad:gRad};
 return`<div class="cd"><div class="row"><h4>Graph library</h4><button class="chip" onclick="V.gx=!V.gx;render()">${V.gx?'Collapse':'Expand'}</button></div><div class="chips">${GT.map(t=>`<button class="chip${g===t[0]?' on':''}" onclick="V.gt='${t[0]}';render()">${t[1]}</button>`).join('')}</div>${GA.includes(g)?chips(V.sa,'sa'):''}${F[g](SD,H)}<div class="ti" id="gi">Tap a point, bar or slice for its value.</div><small>${g==='heat'?'Calendar view: 12 weeks ending with the selected date’s week.':SD.length+' days in the selected period (Daily shows the last 7 days).'} Only recorded data is plotted.</small></div>`}
// ---- Sounds
const SK={tap:'tap',slide:'tap',nav:'nav',refill:'timer',ok:'timer',add:'ok',del:'err',err:'err'},CK={tap:'tap',nav:'nav',timer:'refill',ok:'add',err:'err'},SCN=[['tap','Tap'],['nav','Navigation'],['timer','Timer'],['ok','Success'],['err','Error']],PRE={soft:'Soft',click:'Click',chime:'Chime',bell:'Bell',pop:'Pop'};
const snv=()=>Math.max(.05,X().snd.vol/.7);
function sfxGate(k){const e=X().snd,c=SK[k];if(!c)return true;if(e.cat[c]===0)return false;const s=e.sel[c];if(s&&s.startsWith('i:')){const m=e.imp.find(i=>'i:'+i.id===s);if(m){try{const a=new Audio(m.d);a.volume=e.vol;a.play().catch(()=>{})}catch(x){}return false}}return true}
function sfxKey(k){const s=X().snd.sel[SK[k]];return PRE[s]?'p_'+s:k}
function pvSnd(c,v){const e=X().snd,o=e.sel[c],oc=e.cat[c];e.sel[c]=v;e.cat[c]=1;sfx(CK[c]);e.sel[c]=o;e.cat[c]=oc}
function selSnd(c,v){const e=X().snd;if(v==='default')delete e.sel[c];else e.sel[c]=v;save();pvSnd(c,v==='default'?'':v)}
function togCat(c,on){X().snd.cat[c]=on?1:0;save()}
function setVol(v){X().snd.vol=+v/100;save()}
function impSnd(){pickFile('audio/*',f=>readFile(f,700*1024,d=>{X().snd.imp.push({id:uid(),n:f.name.slice(0,60),d});save();render()}))}
function rmSnd(id){const e=X().snd;e.imp=e.imp.filter(i=>i.id!==id);for(const c in e.sel)if(e.sel[c]==='i:'+id)delete e.sel[c];save();render()}
function playImp(id){const m=X().snd.imp.find(i=>i.id===id);if(m){const a=new Audio(m.d);a.volume=X().snd.vol;a.play().catch(()=>{})}}
let AMB=null;function ambStop(){if(AMB){try{AMB.s.stop()}catch(x){}AMB=null}}
function ambSet(k){const e=X().snd;e.amb=k;save();ambStop();if(k==='off')return;try{AX=AX||new(window.AudioContext||window.webkitAudioContext)();if(AX.resume)AX.resume();const n=AX.sampleRate*2,b=AX.createBuffer(1,n,AX.sampleRate),d=b.getChannelData(0);let l=0;for(let i=0;i<n;i++){const w=Math.random()*2-1;if(k==='rain')d[i]=w*.5;else{l=(l+.02*w)/1.02;d[i]=l*3.5}}
 const s=AX.createBufferSource(),f=AX.createBiquadFilter(),g=AX.createGain();s.buffer=b;s.loop=true;f.type=k==='rain'?'highpass':'lowpass';f.frequency.value=k==='rain'?1500:420;g.gain.value=e.av*.5;s.connect(f);f.connect(g);g.connect(AX.destination);s.start();AMB={s,g}}catch(x){}}
function ambVol(v){const e=X().snd;e.av=+v/100;save();if(AMB)AMB.g.gain.value=e.av*.5}
addEventListener('pointerdown',()=>{if(X().snd.amb!=='off'&&!AMB)ambSet(X().snd.amb)},{once:true});
document.addEventListener('visibilitychange',()=>{if(AX&&AMB){document.hidden?AX.suspend():AX.resume()}});
function vSo(){const e=X().snd;return`${bk('Sounds')}<div class="cd"><div class="li"><span><b>Sound effects</b><br><small>Master switch (also the startup sound)</small></span><input type="checkbox" ${opuxSoundOn?'checked':''} onchange="setOpuxSound(this.checked)"></div><label>Volume</label><input type="range" min="0" max="100" value="${Math.round(e.vol*100)}" oninput="setVol(this.value)"></div>
 <div class="cd"><h4>Sound categories</h4>${SCN.map(([c,n])=>`<div style="padding:8px 0;border-top:1px solid var(--bd)"><div class="li"><b>${n}</b><input type="checkbox" ${e.cat[c]===0?'':'checked'} onchange="togCat('${c}',this.checked)"></div><div class="row"><select onchange="selSnd('${c}',this.value)"><option value="default">Default</option>${Object.entries(PRE).map(([k,v])=>`<option value="${k}"${e.sel[c]===k?' selected':''}>${v}</option>`).join('')}${e.imp.map(i=>`<option value="i:${i.id}"${e.sel[c]==='i:'+i.id?' selected':''}>${esc(i.n)}</option>`).join('')}</select><button class="chip" onclick="pvSnd('${c}',X().snd.sel['${c}']||'')">▶</button></div></div>`).join('')}</div>
 <div class="cd"><h4>Imported sounds</h4>${e.imp.map(i=>`<div class="li" style="padding:6px 0"><span class="ell">${esc(i.n)}</span><span><button class="chip" onclick="playImp('${i.id}')">▶</button> <button class="chip" onclick="rmSnd('${i.id}')">Remove</button></span></div>`).join('')||'<small>None imported.</small>'}<button class="btn ol sm" style="width:100%" onclick="impSnd()">Import sound file</button><small>Short clips up to about 500 KB are stored inside the app data.</small></div>
 <div class="cd"><h4>Ambient background</h4><select onchange="ambSet(this.value)">${[['off','Off'],['rain','Rain (generated)'],['rumble','Soft rumble (generated)']].map(o=>`<option value="${o[0]}"${e.amb===o[0]?' selected':''}>${o[1]}</option>`).join('')}</select><label>Ambient volume</label><input type="range" min="0" max="100" value="${Math.round(e.av*100)}" oninput="ambVol(this.value)"></div>`}
const qq=t=>esc(String(t)).replace(/&#39;/g,'’');


//POLISH
const greet=()=>{const h=new Date().getHours();return h<5?'Good night':h<12?'Good morning':h<18?'Good afternoon':'Good evening'};
function hp(){try{if(X().hap!==0&&window.OpuxAndroid&&OpuxAndroid.haptic)OpuxAndroid.haptic()}catch(e){}}
function toast(t){let e=$('#toast');if(!e){document.body.insertAdjacentHTML('beforeend','<div id="toast" role="status"></div>');e=$('#toast')}e.textContent=t;e.classList.remove('on');void e.offsetWidth;e.classList.add('on');clearTimeout(window._tt);window._tt=setTimeout(()=>e.classList.remove('on'),2200)}
function goalRow(T){const g=X().goal;if(!g)return'';const p=prod(T);return`<div class="li"><span>Productive goal ${fmt(g)}</span><b>${Math.round(p/g*100)}%</b></div><div class="pg" style="display:block"><i style="display:block;width:${Math.min(100,p/g*100)}%;background:var(--ac)"></i></div>`}
function countUp(){if(RM())return;const e=document.querySelector('#app .hero b');if(!e)return;const m=V.v==='ho'?tot(ds(new Date())):V.v==='tr'?tot(V.d):V.v==='hd'?tot(V.h):0;if(!m)return;const t0=performance.now();(function f(){const u=Math.min(1,(performance.now()-t0)/700),k=1-(1-u)**4;e.textContent=fmt(u<1?Math.round(m*k):m);if(u<1&&e.isConnected)requestAnimationFrame(f)})()}
const IC2={br:'<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="8" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8 7l8 1M7 8l4 8M17 10l-4 6"/>',rd:'<path d="M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h11"/>',tr:'<circle cx="7" cy="7" r="3"/><circle cx="17" cy="7" r="3"/><circle cx="7" cy="17" r="3"/><circle cx="17" cy="17" r="3"/>',th:'<path d="M12 3a9 9 0 1 0 0 18c1.5 0 2-1 1.5-2s0-2 1.5-2h2a3 3 0 0 0 3-3 9 9 0 0 0-8-11z"/>',so:'<path d="M4 10v4h4l5 4V6L8 10zM16 9a4 4 0 0 1 0 6"/>',se:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',da:'<path d="M12 3v12M7 10l5 5 5-5M5 20h14"/>'};
function vMo(){return`<div class="more-hero"><div class="node-kicker">OPUX ／ SYSTEM DIRECTORY</div><h2>More of<br><em>your world.</em></h2><p>Move between your maps, daily continuity and personal controls.</p><div class="more-hero-foot"><span>LOCAL-FIRST</span><span>VERSION 2.3.1</span></div></div><div class="more-grid"><button class="more-tile" onclick="go('br')"><span>01 ／ MAPS</span><b>Branches</b><small>Your connected ideas and structures</small><i>↗</i></button><button class="more-tile" onclick="go('rd')"><span>02 ／ CONTINUITY</span><b>RDBD</b><small>Daily identity, quotes and seasons</small><i>↗</i></button><button class="more-tile" onclick="V.d=ds(new Date());go('tr')"><span>03 ／ TIME</span><b>Tracker</b><small>Open the 24-hour record</small><i>↗</i></button><button class="more-tile" onclick="go('th')"><span>04 ／ APPEARANCE</span><b>Themes</b><small>Choose your visual atmosphere</small><i>↗</i></button><button class="more-tile" onclick="go('so')"><span>05 ／ SOUND</span><b>Sound studio</b><small>Audio feedback and ambience</small><i>↗</i></button><button class="more-tile" onclick="go('se')"><span>06 ／ PREFERENCES</span><b>Settings</b><small>Time, dates, goals and backup</small><i>↗</i></button><button class="more-tile" onclick="go('pr')"><span>07 ／ INSIGHT</span><b>Productive time</b><small>Most productive day, streaks and classes</small><i>↗</i></button><button class="more-tile" onclick="go('pl')"><span>08 ／ PLAY</span><b>Playground</b><small>Wheel, coin, picker and focus</small><i>↗</i></button><button class="more-tile" onclick="go('ai')"><span>09 ／ INTELLIGENCE</span><b>ChatGPT prompts</b><small>Your data, prepared for ChatGPT</small><i>↗</i></button></div><div class="more-footer"><span>OPUX 2.3.1</span><span>YOUR DATA STAYS ON THIS DEVICE</span></div>`}


/* 2.3: tab swipe handled by the finger-following module at the end of this script */

// OPUX 2.1 — time check-in, hour entry, and remaining-screen refinement.
function clockText(d=new Date()){return d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',hour12:(S.clock||'24')==='12'})}
function syncMinuteTotal(){const h=Math.max(0,Math.min(24,parseInt($('#dm-hours')?.value||'0',10)||0)),m=Math.max(0,Math.min(59,parseInt($('#dm-minutes')?.value||'0',10)||0));if($('#dm'))$('#dm').value=h*60+m}
function syncHourFields(){const n=Math.max(0,Math.round(+($('#dm')?.value||0)));if($('#dm-hours'))$('#dm-hours').value=Math.floor(n/60);if($('#dm-minutes'))$('#dm-minutes').value=n%60}
function ciElapsed(){const at=+X().checkinAt||Date.now();return Math.max(1,Math.min(720,Math.round((Date.now()-at)/60000)))}
function openCheckin(manual=false){
 const mins=ciElapsed(),hours=Math.floor(mins/60),rem=mins%60;window.CI={manual,mins};
 const options=S.acts.map(a=>`<option value="${a.id}">${esc(a.n)}</option>`).join('');
 $('#md').innerHTML=`<div class="sheet checkin-sheet"><div class="row"><div><div class="node-kicker">TIME CHECK-IN</div><h3>What have you been doing?</h3></div><button class="x" onclick="closeCheckin(true)">✕</button></div><div class="checkin-clock"><span id="ci-clock">${clockText()}</span><small>YOUR DEVICE'S LOCAL TIME</small></div><p class="checkin-explain">Suggested elapsed time: <b>${fmt(mins)}</b> (default suggestion capped at 12 hours). This is not phone-usage history. Adjust it to match your day.</p><label>What were you doing?</label><select id="ci-act">${options}</select><div class="hour-entry"><div><label>Hours</label><input id="ci-hours" type="number" min="0" max="24" inputmode="numeric" value="${hours}" oninput="ciPreview()"></div><div><label>Minutes</label><input id="ci-minutes" type="number" min="0" max="59" inputmode="numeric" value="${rem}" oninput="ciPreview()"></div></div><label>Note (optional)</label><input id="ci-note" maxlength="200" placeholder="A short note about this time"><p id="ci-split" class="checkin-explain"></p><p id="ci-error" class="er"></p><button class="btn" onclick="saveCheckin()">Save this time</button><div class="row"><button class="btn ol" onclick="closeCheckin(true)">Remind me later</button><button class="chip" onclick="closeCheckin(false)">Not now</button></div></div>`;
 $('#md').className='show';$('#ci-act').value=S.acts[0]?.id||'';sfx('tap');ciPreview();
}
function closeCheckin(snooze){if(snooze){X().snoozeUntil=Date.now()+30*60000;save()}else{X().snoozeUntil=Date.now()+60*60000;save()}window.CI=null;$('#md').className='';$('#md').innerHTML=''}
function ciSpan(){const h=Math.max(0,Math.min(24,parseInt($('#ci-hours').value||'0',10)||0)),m=Math.max(0,Math.min(59,parseInt($('#ci-minutes').value||'0',10)||0)),total=h*60+m,now=Date.now();return{total,now,parts:splitSpan(now-total*60000,now)}}
function ciPreview(){const e=$('#ci-split');if(!e||!$('#ci-hours'))return;const s=ciSpan();e.textContent=s.parts.length>1?'This crosses midnight, so it is recorded as '+s.parts.map(p=>fmt(p.min)+' on '+fd(p.d)).join(' and ')+'.':''}
function saveCheckin(){const a=$('#ci-act').value,n=$('#ci-note').value.trim(),s=ciSpan();if(!(s.total>0)){$('#ci-error').textContent='Enter a duration above 0';return}
 const r=putParts(s.parts,a,n||'Check-in estimate',true);if(r.err){$('#ci-error').textContent=r.err;return}
 X().checkinAt=s.now;X().snoozeUntil=0;save();window.CI=null;$('#md').className='';$('#md').innerHTML='';render();toast(s.parts.length>1?'Time added · '+s.parts.map(p=>fmt(p.min)+' on '+fd(p.d)).join(' · '):'Time added · '+fmt(s.total));}
function checkinCardInner(){return `<div class="checkin-card-top"><div><div class="node-kicker">LOCAL TIME / CHECK-IN</div><b class="checkin-card-time" id="home-live-clock">${clockText()}</b></div><button class="chip" onclick="openCheckin(true)">Check in ↗</button></div><div class="checkin-card-bottom"><span>Last check-in</span><b>${X().checkinAt?new Date(X().checkinAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',hour12:(S.clock||'24')==='12'}):'Not yet'}</b><span class="checkin-card-note">Time is only added after you confirm it.</span></div>`}
function maybeCheckin(){if(V.v!=='ho'||M||window.CI||document.hidden)return;const e=X(),due=Date.now()-(+e.checkinAt||Date.now())>=60*60000;if(due&&Date.now()>(+e.snoozeUntil||0))openCheckin(false)}
let _ciClockTimer=null,_ciPromptTimer=null;
const _render=render;
render=function(){_render();
 // Check-in panel on Home: live local clock + explicit, user-confirmed time entry.
 if(V.v==='ho'){
  const host=$('#app');if(host&&!$('#home-checkin')){const card=document.createElement('section');card.id='home-checkin';card.className='checkin-card';card.innerHTML=checkinCardInner();const hero=host.querySelector('.home-atlas');if(hero)hero.insertAdjacentElement('afterend',card);else host.appendChild(card)}
 }
 const intros={tr:['TIME LEDGER','A clearer account of today.'],st:['PATTERNS & SIGNAL','Read the shape of your time.'],hi:['YOUR RECORD','Move through days, not just totals.'],rc:['PERSONAL MILESTONES','Records calculated from what you logged.'],so:['SOUND ENVIRONMENT','Small details, tuned to your space.'],th:['VISUAL ATMOSPHERE','Choose how OPUX feels.'],se:['SYSTEM PREFERENCES','Make the experience work your way.']};if(intros[V.v]&&!$('#screen-intro')){const q=document.createElement('div');q.id='screen-intro';q.className='screen-intro';q.innerHTML=`<span>${intros[V.v][0]}</span><p>${intros[V.v][1]}</p>`;const app=$('#app');app.insertBefore(q,app.firstChild)}
 if(['st','hi','rc'].includes(V.v)&&!$('#screen-summary')){const q=document.createElement('section');q.id='screen-summary';q.className='screen-summary';const days=Object.keys(S.days).filter(d=>tot(d)>0).sort(),all=days.reduce((n,d)=>n+tot(d),0),today=ds(new Date()),week=Array.from({length:7},(_,i)=>add(today,-i)).reduce((n,d)=>n+tot(d),0);let cells=[];if(V.v==='st')cells=[['TODAY',fmt(tot(today))],['LAST 7 DAYS',fmt(week)],['ALL RECORDED',fmt(all)]];else if(V.v==='hi')cells=[['RECORDED DAYS',String(days.length)],['TOTAL TIME',fmt(all)],['LATEST ENTRY',days.length?fd(days[days.length-1]):'—']];else{const records=recList();cells=[['CALCULATED RECORDS',String(records.length)],['MANUAL MILESTONES',String(X().ms.length)],['RECORDED DAYS',String(days.length)]]}q.innerHTML=cells.map(([a,b])=>`<div><small>${a}</small><b>${b}</b></div>`).join('');const intro=$('#screen-intro');if(intro)intro.insertAdjacentElement('afterend',q);else $('#app').prepend(q)}
 if(V.v==='tr'&&M&&$('#dm')&&!$('#dm-hours')){syncHourFields()}
 if(V.v==='se'&&!$('#checkin-settings')){const c=document.createElement('section');c.id='checkin-settings';c.className='cd';c.innerHTML=`<div class="node-kicker">TIME AWARENESS</div><h4>Check-in reminder</h4><p class="setting-copy">Ask what you have been doing after a period without a check-in. OPUX reads the device's current local clock; it cannot inspect your phone's usage history.</p><label>Reminder interval</label><select onchange="X().checkinEvery=+this.value;save()">${[45,60,90,120].map(n=>`<option value="${n}"${X().checkinEvery===n?' selected':''}>Every ${n} minutes</option>`).join('')}</select><button class="btn ol sm" style="width:100%;margin-top:10px" onclick="openCheckin(true)">Check in now</button>`;const app=$('#app');app.appendChild(c)}
 if(V.v==='tr'&&!M){const h=$('#app');if(h&&!$('#manual-hour-add')){const b=document.createElement('button');b.id='manual-hour-add';b.className='btn ol';b.style.width='100%';b.style.margin='10px 0 4px';b.textContent='＋ Add hours / minutes';b.onclick=()=>openM(null);const board=h.querySelector('.bw');if(board)board.insertAdjacentElement('afterend',b)}}
 if(_ciClockTimer)clearInterval(_ciClockTimer);_ciClockTimer=setInterval(()=>{const c=$('#home-live-clock');if(c)c.textContent=clockText();const mc=$('#ci-clock');if(mc)mc.textContent=clockText()},1000);
 if(_ciPromptTimer)clearInterval(_ciPromptTimer);_ciPromptTimer=setInterval(maybeCheckin,30000);setTimeout(maybeCheckin,800);
};
// Make Home's spatial core respond to pointer/touch movement without requiring WebGL.
function bindAtlasParallax(){const a=$('.home-atlas'),v=$('.atlas-visual');if(!a||!v||a.dataset.parallax)return;a.dataset.parallax='1';let raf=0;a.addEventListener('pointermove',e=>{if(RM())return;const r=a.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{v.style.setProperty('--tilt-x',(-y*9)+'deg');v.style.setProperty('--tilt-y',(x*11)+'deg');v.style.transform=`rotate(-12deg) rotateX(${-y*9}deg) rotateY(${x*11}deg) translate3d(${x*5}px,${y*5}px,0)`})});a.addEventListener('pointerleave',()=>{v.style.transform='rotate(-12deg)'})}
const _afterRender=afterRender;afterRender=function(){_afterRender();bindAtlasParallax()};
// ===================================================================
// OPUX 2.2 — Productivity intelligence, Playground, ChatGPT workflows
// (everything below is additive; the h24v1 tracker model is unchanged)
// ===================================================================
const CLS={w:{n:'Productive Work',s:'Work',g:'◆'},n:{n:'Neutral',s:'Neutral',g:'◇'},l:{n:'Leisure / Personal',s:'Leisure',g:'○'},u:{n:'Unclassified',s:'Unclassified',g:'–'}};
const CLR={w:'var(--ac)',n:'#7d88b0',l:'#f59e0b',u:'rgba(160,170,200,.35)'};
const CG=a=>{const k=curCls(a);return k==='u'?'':`<em class="cg cg-${k}" title="${CLS[k].n}">${CLS[k].g}</em>`};
const todayS=()=>ds(new Date());
const WD=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
const iso=d=>d+' ('+WD[pd(d).getDay()]+')';
const hm=m=>{m=Math.round(m);const h=Math.floor(m/60),r=m%60;return h+'h '+String(r).padStart(2,'0')+'m'};
const recDays=()=>Object.keys(S.days).filter(d=>tot(d)>0).sort();

// ---- classification engine -------------------------------------------------
function baseCls(a){return a.cls||(a.p?'w':'u')}
function clsOn(id,d){const a=S.acts.find(x=>x.id===id);if(!a)return'u';let b=null;for(const q of X().cl){if(q.a===id&&q.d<=d&&(!b||q.d>=b.d))b=q}return b?b.c:baseCls(a)}
function curCls(a){return clsOn(a.id,todayS())}
function dayCls(d){const o={t:0,w:0,n:0,l:0,u:0};for(const e of S.days[d]||[]){o.t+=e.min;o[clsOn(e.act,d)]+=e.min}for(const k of['t','w','n','l','u'])o[k]=R(o[k]);o.pct=o.t>0?Math.round(o.w/o.t*1000)/10:0;return o}
function aggCls(L){const o={t:0,w:0,n:0,l:0,u:0};for(const d of L){const c=dayCls(d);for(const k of['t','w','n','l','u'])o[k]+=c[k]}for(const k of['t','w','n','l','u'])o[k]=R(o[k]);o.pct=o.t>0?Math.round(o.w/o.t*1000)/10:0;return o}
function histImpact(id,c){let days=0,min=0;for(const d of Object.keys(S.days)){const m=S.days[d].filter(e=>e.act===id).reduce((s,e)=>s+e.min,0);if(m>0&&clsOn(id,d)!==c){days++;min+=m}}return{days,min:R(min)}}
function applyCls(id,c,mode){const a=S.acts.find(x=>x.id===id);if(!a)return;const x=X();
 if(mode==='all'){x.cl=x.cl.filter(q=>q.a!==id);if(c==='u')delete a.cls;else a.cls=c}
 else{const t=todayS();x.cl=x.cl.filter(q=>!(q.a===id&&q.d===t));x.cl.push({a:id,d:t,c})}
 a.p=clsOn(id,todayS())==='w'?1:0;save()}
function clsPick(i,c){const a=S.acts[i];if(!a||!CLS[c]||curCls(a)===c){render();return}
 const h=histImpact(a.id,c);
 if(!h.days){applyCls(a.id,c,'all');sfx('tap');toast(a.n+' → '+CLS[c].n);render();return}
 openSheet(`<div class="row"><h3>Reclassify “${esc(a.n)}”</h3><button class="x" onclick="closeSheet();render()">✕</button></div>
 <p class="setting-copy">Now: <b>${CLS[curCls(a)].n}</b> → <b>${CLS[c].n}</b>.<br>This activity has <b>${hm(h.min)}</b> recorded across <b>${h.days}</b> day${h.days>1?'s':''} that would be counted differently if the change applies to history.</p>
 <button class="btn" onclick="applyClsGo('${a.id}','${c}','all')">Apply to all history</button><small class="px-hint">Past statistics and records are recalculated. No time entries are changed.</small>
 <button class="btn ol" onclick="applyClsGo('${a.id}','${c}','from')">From today onward only</button><small class="px-hint">Past days keep their current classification. You can undo this later under Classification history.</small>
 <button class="btn ol" onclick="closeSheet();render()">Cancel</button>`)}
function applyClsGo(id,c,mode){applyCls(id,c,mode);closeSheet();sfx('ok');toast(mode==='all'?'Applied to all history':'Applies from today');render()}
function clsLogDel(i){const q=X().cl[i];if(!q)return;if(confirm('Remove this change? Days from '+fd(q.d)+' revert to the earlier classification.')){X().cl.splice(i,1);const a=S.acts.find(x=>x.id===q.a);if(a)a.p=curCls(a)==='w'?1:0;save();render();toast('Change removed')}}

// ---- sheets / clipboard / external links -----------------------------------
let SHO=0;
function openSheet(h){SHO=1;const m=$('#md');m.innerHTML='<div class="sheet">'+h+'</div>';m.className='show';sfx('tap')}
function closeSheet(){if(!SHO)return;SHO=0;const m=$('#md');m.className=M?'show':'';m.innerHTML=M?vM():''}
$('#md').addEventListener('click',e=>{if(e.target.id==='md'&&SHO){closeSheet();render()}});
function copyText(t){let ok=false;
 try{if(window.OpuxAndroid&&OpuxAndroid.copyText){OpuxAndroid.copyText(t);ok=true}}catch(e){}
 if(!ok){try{const a=document.createElement('textarea');a.value=t;a.setAttribute('readonly','');a.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(a);a.select();a.setSelectionRange(0,t.length);ok=document.execCommand('copy');a.remove()}catch(e){}}
 if(!ok&&navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(()=>toast('Copied to clipboard'),()=>toast('Copy failed. Select the text and copy it manually.'));return}
 toast(ok?'Copied to clipboard':'Copy failed. Select the text and copy it manually.');sfx(ok?'ok':'err');return ok}
function openExt(u){try{if(window.OpuxAndroid&&OpuxAndroid.openUrl){OpuxAndroid.openUrl(u);return}if(window.OpuxAndroid){location.href=u;return}}catch(e){}window.open(u,'_blank','noopener')}
function shareText(t){try{if(window.OpuxAndroid&&OpuxAndroid.shareText){OpuxAndroid.shareText(t);return}}catch(e){}if(navigator.share){navigator.share({text:t}).catch(()=>{});return}copyText(t)}

// ---- randomness (unbiased, rejection sampling over crypto) --------------------
function rint(n){n=Math.floor(n);if(n<=1)return 0;
 if(!(window.crypto&&crypto.getRandomValues))return Math.floor(Math.random()*n);
 const a=new Uint32Array(1),lim=Math.floor(4294967296/n)*n;do{crypto.getRandomValues(a)}while(a[0]>=lim);return a[0]%n}
const rfrac=()=>rint(1048576)/1048576;

// ---- Productivity screen --------------------------------------------------------
function pxBest(L){let b=null,r=null;for(const d of L){const c=dayCls(d);if(c.w<=0)continue;const v={d,w:c.w,t:c.t,pct:c.pct};
  if(!b||v.w>b.w||(v.w===b.w&&(v.pct>b.pct||(v.pct===b.pct&&v.d>b.d)))){r=b;b=v}else if(!r||v.w>r.w||(v.w===r.w&&v.d>r.d))r=v}return{b,r}}
function pxStreak(){const thr=X().goal>0?X().goal:1,D=recDays();let best=0,be=null,run=0,rs=null,pv=null;
 for(const d of D){if(prod(d)>=thr){run=pv&&add(pv,1)===d?run+1:1;if(run===1)rs=d;pv=d;if(run>best){best=run;be={s:rs,e:d}}}else{run=0;pv=null}}
 const T=todayS();let cur=0,c=prod(T)>=thr&&S.days[T]?T:add(T,-1);while(S.days[c]&&prod(c)>=thr){cur++;c=add(c,-1)}
 return{best,be,cur,thr}}
function pxBars(N){const T=todayS(),L=Array.from({length:N},(_,i)=>add(T,i-N+1)),v=L.map(d=>prod(d)),mx=Math.max(...v,60),W=300,H=120,bw=(W-16)/N,D=recDays(),avg=D.length?mean(D.map(prod)):0,y=q=>H-18-q/mx*(H-34);
 let s=`<svg viewBox="0 0 ${W} ${H}" class="ch" id="pxsvg">`;
 L.forEach((d,i)=>{const h=Math.max(v[i]?2:0,v[i]/mx*(H-34)),x=8+i*bw;
  s+=S.days[d]?`<rect class="pxb" data-d="${d}" x="${x+bw*.12}" y="${H-18-h}" width="${bw*.76}" height="${h}" rx="${Math.min(3,bw/3)}" fill="${v[i]?'var(--ac)':'rgba(160,170,200,.25)'}" onclick="pxPick('${d}')"/>`:`<rect x="${x+bw*.3}" y="${H-19}" width="${bw*.4}" height="1.5" fill="rgba(160,170,200,.3)"/>`});
 if(avg>0)s+=`<line x1="8" x2="${W-8}" y1="${y(avg)}" y2="${y(avg)}" stroke="var(--a2)" stroke-dasharray="3 3" stroke-width="1"/><text x="${W-8}" y="${y(avg)-3}" text-anchor="end" class="ax">avg ${hm(avg)}</text>`;
 s+=`<text x="8" y="10" class="ax">max ${hm(mx)}</text><text x="8" y="${H-4}" class="ax">${fd(L[0])}</text><text x="${W-8}" y="${H-4}" text-anchor="end" class="ax">${fd(L[N-1])}</text></svg>`;return s}
function pxPick(d){const c=dayCls(d),e=$('#pxr');if(e)e.textContent=fd(d)+' · productive '+hm(c.w)+' of '+hm(c.t)+' tracked ('+c.pct+'%)';sfx('tap')}
function stackBar(a){const T=a.t;if(!T)return'<small>No recorded time in this period.</small>';
 return`<div class="px-stack">${['w','n','l','u'].filter(k=>a[k]>0).map(k=>`<i style="width:${a[k]/T*100}%;background:${CLR[k]}" title="${CLS[k].n}"></i>`).join('')}</div>
 <div class="lg" style="margin-top:8px">${['w','n','l','u'].map(k=>`<div><span><i class="dt" style="background:${CLR[k]}"></i>${CLS[k].n}</span><b>${hm(a[k])} <small>${Math.round(a[k]/T*1000)/10}%</small></b></div>`).join('')}</div>`}
VX.pr=function(){const T=todayS(),D=recDays(),thr=X().goal>0?X().goal:1;
 const all=pxBest(D),avg=D.length?mean(D.map(prod)):0,wkL=Array.from({length:7},(_,i)=>add(wk(T),i)).filter(d=>S.days[d]),moL=D.filter(d=>d.slice(0,7)===T.slice(0,7)),wB=pxBest(wkL).b,mB=pxBest(moL).b,st=pxStreak();
 const N=V.pn||14,P=V.pp||'w',pL=P==='t'?[T]:P==='w'?Array.from({length:7},(_,i)=>add(T,-i)):P==='m'?Array.from({length:30},(_,i)=>add(T,-i)):D;
 const unc=aggCls(D).u;
 const small=(t,b)=>b?`<div class="px-mini" onclick="V.h='${b.d}';go('hd')"><small>${t}</small><b>${hm(b.w)}</b><span>${fd(b.d)}</span></div>`:`<div class="px-mini"><small>${t}</small><b>–</b><span>no productive work yet</span></div>`;
 let hero;
 if(!D.length)hero=`<div class="cd px-empty"><div class="node-kicker">MOST PRODUCTIVE DAY</div><h3>Nothing tracked yet</h3><p class="setting-copy">Record activities in the Tracker, then mark which ones are Productive Work below. OPUX only counts what you classify.</p><button class="btn" onclick="V.d=todayS();go('tr')">Open Tracker</button></div>`;
 else if(!all.b)hero=`<div class="cd px-empty"><div class="node-kicker">MOST PRODUCTIVE DAY</div><h3>No Productive Work classified</h3><p class="setting-copy">You have ${D.length} recorded day${D.length>1?'s':''}, but no recorded time belongs to an activity marked <b>Productive Work</b>. Classify your activities below and the result appears immediately.${unc>0?` (${hm(unc)} of your recorded time is currently unclassified.)`:''}</p></div>`;
 else{const b=all.b,r=all.r,dv=R(b.w-avg);
  const prevBest=pxBest(D.filter(d=>d<b.d)).b;
  hero=`<div class="cd px-hero" onclick="V.h='${b.d}';go('hd')"><div class="node-kicker">MOST PRODUCTIVE DAY ／ ALL TIME</div><b class="px-big">${hm(b.w)}</b><div class="px-date">${fd(b.d)}</div>
  <div class="px-grid"><div><small>Total tracked</small><b>${hm(b.t)}</b></div><div><small>Productive share</small><b>${b.pct}%</b></div><div><small>vs your average</small><b>${dv>=0?'+':'−'}${hm(Math.abs(dv))}</b></div></div>
  <small class="px-foot">Average productive time per recorded day: ${hm(avg)} (${D.length} days). ${r?'Runner-up: <b>'+hm(r.w)+'</b> on '+fd(r.d)+'.':'No runner-up yet.'}${prevBest&&(!r||prevBest.d!==r.d)?' Previous best before this day: <b>'+hm(prevBest.w)+'</b> on '+fd(prevBest.d)+'.':''}</small><small class="px-foot">Ranked by productive time, not by the longest tracked day.</small></div>`}
 const row=(a,i)=>{const k=curCls(a);return`<div class="px-act"><span><i class="dt" style="background:${a.c}"></i>${esc(a.n)}</span><div class="px-seg" role="group" aria-label="Classification for ${esc(a.n)}">${['w','n','l','u'].map(c=>`<button class="${k===c?'on':''}" onclick="clsPick(${i},'${c}')" title="${CLS[c].n}" aria-pressed="${k===c}">${CLS[c].g} ${CLS[c].s==='Unclassified'?'None':CLS[c].s}</button>`).join('')}</div></div>`};
 return bk('Stats')+`<div class="node-kicker">PRODUCTIVITY INTELLIGENCE</div><h2 style="margin-top:0">Productive <em>time</em></h2>
 <small class="setting-copy">Based on the classifications you set. Unclassified time is never counted as productive.</small>
 ${hero}
 <div class="px-minis">${small('BEST THIS WEEK',wB)}${small('BEST THIS MONTH',mB)}</div>
 <div class="cd"><h4>Rhythm</h4>
  <div class="li"><span>Average productive per recorded day</span><b>${D.length?hm(avg):'–'}</b></div>
  <div class="li"><span>Best productive streak</span><b>${st.best?st.best+(st.best>1?' days':' day'):'–'}</b></div>
  ${st.be?`<small>${fd(st.be.s)} to ${fd(st.be.e)}</small>`:''}
  <div class="li"><span>Current streak</span><b>${st.cur?st.cur+(st.cur>1?' days':' day'):'0 days'}</b></div>
  <small>A streak day has at least ${st.thr>1?hm(st.thr)+' (your daily goal)':'1 minute'} of Productive Work, on consecutive calendar days.</small></div>
 <div class="cd"><div class="row"><h4>Productive time over time</h4></div><div class="sg">${[7,14,30,90].map(n=>`<button class="${N===n?'on':''}" onclick="V.pn=${n};render()">${n}d</button>`).join('')}</div>${pxBars(N)}<div class="ti" id="pxr">Tap a bar for details. Grey ticks are days with no record.</div></div>
 <div class="cd"><h4>Productive vs everything else</h4><div class="sg">${[['t','Today'],['w','7 days'],['m','30 days'],['a','All']].map(x=>`<button class="${P===x[0]?'on':''}" onclick="V.pp='${x[0]}';render()">${x[1]}</button>`).join('')}</div>${stackBar(aggCls(pL))}</div>
 <div class="cd"><h4>Classify your activities</h4><p class="setting-copy">◆ Work counts as productive · ◇ Neutral · ○ Leisure / personal · None is unclassified.</p>${S.acts.map(row).join('')}
  <small class="px-hint">Changing a class that has history asks whether to apply it to the past or only from today. Time entries are never edited.</small></div>
 ${X().cl.length?`<div class="cd"><h4>Classification history</h4>${X().cl.map((q,i)=>`<div class="li" style="padding:5px 0"><span>${esc(act(q.a).n)} → <b>${CLS[q.c].n}</b><br><small>from ${fd(q.d)}</small></span><button class="chip" onclick="clsLogDel(${i})" aria-label="Remove change">✕</button></div>`).join('')}<small>Days before each date keep the earlier class. Remove an entry to revert that change.</small></div>`:''}
 <div class="cd"><h4>How history is handled</h4><p class="setting-copy">OPUX stores each day as a list of activity durations. A day does not remember a label of its own, so a new classification applies to all past days by default. Choose “From today onward” to preserve past statistics. Activities from older backups marked productive became Productive Work; everything else stays unclassified until you decide.</p></div>`}

// ---- Home atlas: interactive atom (Canvas 2D, own 3D projection; no libraries) ---------------
const ATL={raf:0,cv:null,yaw:.6,pit:.38,vy:0,vp:0,drag:null,t:0,last:0,intro:0,lastView:'',ph:[0,2.1,4.2],ripple:[],tip:null,tipT:0,hov:{x:0,y:0},dust:null,dirty:1,rm:false,el:[]};
const ATL_ORB=[{r:.80,inc:.95,node:.2,sp:.62},{r:.62,inc:-.55,node:1.9,sp:-.44},{r:.46,inc:1.45,node:3.3,sp:.31}];
function atlRGB(v,f){v=(v||'').trim();let m=/^#([0-9a-f]{6})$/i.exec(v);if(m){const n=parseInt(m[1],16);return[n>>16,n>>8&255,n&255]}m=/^#([0-9a-f]{3})$/i.exec(v);if(m){const h=m[1];return[17*parseInt(h[0],16),17*parseInt(h[1],16),17*parseInt(h[2],16)]}return f}
function atlData(){const T=todayS(),t=tot(T),B=byAct([T]),top=Object.keys(B).sort((a,b)=>B[b]-B[a])[0],g=X().goal,p=prod(T);
 return{t,pct:Math.round(t/14.4),el:[
  {k:'Productive today',v:hm(p),s:t?R(p/t*100)+'% of tracked':'nothing tracked yet'},
  {k:'Most time today',v:top?act(top).n:'–',s:top?hm(B[top]):'no activity yet'},
  g?{k:'Daily goal',v:Math.min(100,Math.round(p/g*100))+'%',s:hm(p)+' of '+hm(g)}:{k:'Untracked today',v:hm(1440-t),s:'of 24h'}]}}
function atlasStop(){cancelAnimationFrame(ATL.raf);ATL.raf=0;ATL.cv=null}
function atlasInit(){atlasStop();const host=document.querySelector('.atlas-visual');if(!host)return;
 const first=ATL.lastView!=='ho';ATL.lastView='ho';
 const D=atlData();ATL.data=D;
 host.removeAttribute('aria-hidden');host.setAttribute('role','group');host.setAttribute('aria-label','Interactive atom: today '+D.pct+'% of 24 hours tracked. Drag to rotate, tap an orbiting element for details.');
 host.innerHTML='<canvas class="atlas-cv"></canvas><div class="atlas-tip" id="atlas-tip"></div><div class="atlas-orbit-label">24H / '+fmt(D.t)+' TRACKED</div>';
 const cv=host.querySelector('canvas');ATL.cv=cv;ATL.rm=RM();
 const css=getComputedStyle(document.documentElement);ATL.c1=atlRGB(css.getPropertyValue('--ac'),[99,102,241]);ATL.c2=atlRGB(css.getPropertyValue('--a2'),[168,85,247]);ATL.tx=(css.getPropertyValue('--tx')||'#eef0ff').trim();
 if(first&&!ATL.rm)ATL.intro=0;else ATL.intro=1;
 if(!ATL.dust){ATL.dust=Array.from({length:26},()=>({x:rfrac()*2-1,y:rfrac()*2-1,z:rfrac()*2-1,s:.4+rfrac()*.8}))}
 ATL.trail=[[],[],[]];
 atlSize();bindAtl(cv);ATL.last=performance.now();ATL.dirty=1;
 if(ATL.rm){atlFrame(performance.now())}else ATL.raf=requestAnimationFrame(atlFrame)}
function atlSize(){const cv=ATL.cv;if(!cv)return;const w=cv.clientWidth||180,h=cv.clientHeight||180,dpr=Math.min(2,window.devicePixelRatio||1);ATL.W=w;ATL.H=h;ATL.dpr=dpr;cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr)}
// project a point in orbit space. returns [sx,sy,scale,z]
function atlProj(x,y,z){const cy=Math.cos(ATL.yaw),sy=Math.sin(ATL.yaw),cp=Math.cos(ATL.pit),sp=Math.sin(ATL.pit);
 let X1=x*cy+z*sy,Z1=-x*sy+z*cy,Y1=y*cp-Z1*sp,Z2=y*sp+Z1*cp;const f=3.4,s=f/(f-Z2),R0=Math.min(ATL.W,ATL.H)*.43;return[ATL.W/2+X1*s*R0,ATL.H/2-Y1*s*R0,s,Z2]}
function atlOrbitPt(o,a,k){const ex=o.r*(ATL.introE||1)*Math.cos(a),ey=o.r*(ATL.introE||1)*Math.sin(a);
 const ci=Math.cos(o.inc),si=Math.sin(o.inc);let x=ex,y=ey*ci,z=ey*si;const cn=Math.cos(o.node),sn=Math.sin(o.node);return atlProj(x*cn-y*sn,x*sn+y*cn,z)}
function atlFrame(now){const cv=ATL.cv;if(!cv||!document.body.contains(cv)){atlasStop();return}
 if(document.hidden&&!ATL.rm){ATL.raf=requestAnimationFrame(atlFrame);ATL.last=now;return}
 const dt=Math.min(.05,(now-ATL.last)/1000||0);ATL.last=now;ATL.t+=dt;
 // intro: orbits spread outward, electrons spin up then settle
 if(ATL.intro<1){ATL.intro=Math.min(1,ATL.intro+dt/1.15)}const e=ATL.intro,eo=1-Math.pow(1-e,3);ATL.introE=.55+.45*eo;
 if(!ATL.rm){const boost=(1-e)*5;for(let i=0;i<3;i++)ATL.ph[i]+=(ATL_ORB[i].sp+Math.sign(ATL_ORB[i].sp)*boost)*dt;
  if(!ATL.drag){ATL.yaw+=(.10*dt)+ATL.vy*dt;ATL.vy*=Math.pow(.04,dt);ATL.pit+=ATL.vp*dt;ATL.vp*=Math.pow(.04,dt);ATL.pit+=((.38+ATL.hov.y*.25)-ATL.pit)*Math.min(1,dt*1.6)}
  else{ATL.vy*=.9;ATL.vp*=.9}}
 atlDraw();
 if(ATL.rm){if(ATL.dirty&&(ATL.tipT>performance.now()||ATL.ripple.length||ATL.drag)){ATL.dirty=0;ATL.raf=requestAnimationFrame(atlFrame)}else ATL.raf=0}else ATL.raf=requestAnimationFrame(atlFrame)}
function atlGlow(x,c,px,py,r,a){const g=x.createRadialGradient(px,py,0,px,py,r);g.addColorStop(0,'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')');g.addColorStop(1,'rgba('+c[0]+','+c[1]+','+c[2]+',0)');x.fillStyle=g;x.beginPath();x.arc(px,py,r,0,6.2832);x.fill()}
function atlDraw(){const cv=ATL.cv,x=cv.getContext('2d'),W=ATL.W,H=ATL.H;x.setTransform(ATL.dpr,0,0,ATL.dpr,0,0);x.clearRect(0,0,W,H);
 const c1=ATL.c1,c2=ATL.c2,cx=W/2,cy=H/2,R0=Math.min(W,H)*.43,E=ATL.intro,rgba=(c,a)=>'rgba('+c[0]+','+c[1]+','+c[2]+','+a+')';
 // dust: depth cue / parallax
 x.fillStyle='#fff';for(const d of ATL.dust){const p=atlProj(d.x*1.1,d.y*1.1,d.z*1.1);x.globalAlpha=Math.max(0,.1+.18*(p[3]+1)/2)*E;x.beginPath();x.arc(p[0],p[1],d.s*p[2]*.9,0,6.2832);x.fill()}x.globalAlpha=1;
 // electron positions
 const els=[];for(let i=0;i<3;i++){const o=ATL_ORB[i],p=atlOrbitPt(o,ATL.ph[i]);els.push({i,p});const tr=ATL.trail[i];if(!ATL.rm){tr.push([p[0],p[1],p[2]]);if(tr.length>16)tr.shift()}else tr.length=0}
 ATL.el=els;
 // rings: back half, then nucleus, then front half
 const ring=(front)=>{for(let i=0;i<3;i++){const o=ATL_ORB[i],col=i===1?c2:c1;x.beginPath();let pen=false;
  for(let k=0;k<=72;k++){const a=k/72*6.2832,p=atlOrbitPt(o,a),isF=p[3]>=0;if(isF===front){if(!pen){x.moveTo(p[0],p[1]);pen=true}else x.lineTo(p[0],p[1])}else pen=false}
  x.lineWidth=front?1.4:1;x.strokeStyle=rgba(col,(front?.62:.24)*E);x.shadowColor=rgba(col,.9);x.shadowBlur=front?7:0;x.stroke();x.shadowBlur=0}};
 const drawE=(front)=>{for(const el of els){if((el.p[3]>=0)!==front)continue;const i=el.i,col=i===1?c2:c1,p=el.p,s=p[2];
   const tr=ATL.trail[i];for(let k=0;k<tr.length;k++){const q=tr[k],f=k/tr.length;x.fillStyle=rgba(col,.35*f*E);x.beginPath();x.arc(q[0],q[1],(1+3.2*f)*q[2]*.75,0,6.2832);x.fill()}
   const rr=(7.5+(ATL.sel===i?2.5:0))*s;x.globalCompositeOperation='lighter';atlGlow(x,col,p[0],p[1],rr*3.2,.55*E);x.globalCompositeOperation='source-over';
   const g=x.createRadialGradient(p[0]-rr*.3,p[1]-rr*.35,0,p[0],p[1],rr);g.addColorStop(0,'#fff');g.addColorStop(.35,rgba(col,1));g.addColorStop(1,rgba(col.map(v=>v*.45|0),1));x.fillStyle=g;x.globalAlpha=Math.min(1,E*(.62+.38*(p[3]+1)/2));x.beginPath();x.arc(p[0],p[1],rr,0,6.2832);x.fill();x.globalAlpha=1}};
 ring(false);drawE(false);
 // nucleus: lit sphere with breathing, specular, rim
 const br=1+(ATL.rm?0:.028*Math.sin(ATL.t*1.7)),nr=R0*.27*br*(.7+.3*E);
 x.globalCompositeOperation='lighter';atlGlow(x,c1,cx,cy,nr*3,.34*E+(ATL.flash||0));x.globalCompositeOperation='source-over';
 const lx=cx-nr*(.35+ATL.hov.x*.2),ly=cy-nr*(.4+ATL.hov.y*.2),g=x.createRadialGradient(lx,ly,nr*.05,cx,cy,nr);g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(.22,rgba(c1,1));g.addColorStop(.75,rgba(c1.map(v=>v*.35|0),1));g.addColorStop(1,'rgba(4,6,14,1)');
 x.fillStyle=g;x.beginPath();x.arc(cx,cy,nr,0,6.2832);x.fill();
 const rim=x.createRadialGradient(cx,cy,nr*.82,cx,cy,nr);rim.addColorStop(0,'rgba(255,255,255,0)');rim.addColorStop(1,rgba(c2,.5));x.fillStyle=rim;x.beginPath();x.arc(cx,cy,nr,0,6.2832);x.fill();
 x.fillStyle='#fff';x.textAlign='center';x.textBaseline='middle';x.font='900 '+Math.round(nr*.62)+'px system-ui,sans-serif';x.shadowColor='rgba(0,0,0,.5)';x.shadowBlur=4;x.fillText(ATL.data.pct+'%',cx,cy-nr*.06);x.shadowBlur=0;x.font='800 '+Math.max(6,Math.round(nr*.2))+'px system-ui,sans-serif';x.globalAlpha=.78;x.fillText('DAY',cx,cy+nr*.42);x.globalAlpha=1;
 ring(true);drawE(true);
 // tap ripples
 const now=performance.now();ATL.ripple=ATL.ripple.filter(r=>now-r.t0<700);for(const r of ATL.ripple){const f=(now-r.t0)/700;x.strokeStyle=rgba(r.c,.7*(1-f));x.lineWidth=1.5;x.beginPath();x.arc(r.x,r.y,8+f*30,0,6.2832);x.stroke()}
 if(ATL.flash)ATL.flash=Math.max(0,ATL.flash-.02);
 const tip=$('#atlas-tip');if(tip&&ATL.tip){if(now>ATL.tipT){tip.classList.remove('on');ATL.tip=null;ATL.sel=-1}}}
function atlHit(px,py){let best=null,bd=1e9;for(const el of ATL.el){const d=Math.hypot(el.p[0]-px,el.p[1]-py),lim=Math.max(24,11*el.p[2]*1.8);if(d<lim&&d<bd){bd=d;best={k:'e',i:el.i,x:el.p[0],y:el.p[1]}}}
 if(!best){const d=Math.hypot(ATL.W/2-px,ATL.H/2-py);if(d<Math.min(ATL.W,ATL.H)*.17)best={k:'n',x:ATL.W/2,y:ATL.H/2}}return best}
function atlTip(h){const tip=$('#atlas-tip');if(!tip)return;const D=ATL.data;let k,v,s;
 if(h.k==='e'){const e=D.el[h.i];k=e.k;v=e.v;s=e.s;ATL.sel=h.i}else{k='Tracked today';v=hm(D.t);s=D.pct+'% of 24 hours · '+hm(1440-D.t)+' untracked';ATL.sel=-1;ATL.flash=.5}
 tip.innerHTML='<small>'+esc(k)+'</small><b>'+esc(v)+'</b><span>'+esc(s)+'</span>';tip.classList.add('on');
 const px=Math.max(4,Math.min(ATL.W-120,h.x-56)),py=Math.max(2,Math.min(ATL.H-50,h.y+14));tip.style.left=px+'px';tip.style.top=py+'px';
 ATL.tip=1;ATL.tipT=performance.now()+3200;ATL.ripple.push({x:h.x,y:h.y,t0:performance.now(),c:h.k==='e'&&h.i===1?ATL.c2:ATL.c1});hp();sfx('tap');
 if(ATL.rm&&!ATL.raf){ATL.dirty=1;ATL.raf=requestAnimationFrame(atlFrame);setTimeout(()=>{ATL.dirty=1;if(!ATL.raf&&ATL.cv)ATL.raf=requestAnimationFrame(atlFrame)},3300)}}
function bindAtl(cv){let sx=0,sy=0,moved=0,pid=null,lx=0,ly=0,lt=0;
 cv.addEventListener('pointerdown',e=>{pid=e.pointerId;sx=lx=e.clientX;sy=ly=e.clientY;moved=0;lt=performance.now();ATL.drag=1;try{cv.setPointerCapture(pid)}catch(_){}});
 cv.addEventListener('pointermove',e=>{const r=cv.getBoundingClientRect();
  if(ATL.drag&&e.pointerId===pid){const dx=e.clientX-lx,dy=e.clientY-ly,n=performance.now(),dtm=Math.max(8,n-lt)/1000;lx=e.clientX;ly=e.clientY;lt=n;moved+=Math.abs(dx)+Math.abs(dy);
   ATL.yaw+=dx*.011;ATL.pit=Math.max(-.2,Math.min(1.25,ATL.pit+dy*.008));ATL.vy=Math.max(-6,Math.min(6,dx*.011/dtm));ATL.vp=0;ATL.dirty=1;if(ATL.rm&&!ATL.raf)ATL.raf=requestAnimationFrame(atlFrame)}
  else if(e.pointerType==='mouse'&&!RM()){ATL.hov.x=Math.max(-1,Math.min(1,(e.clientX-r.left)/r.width*2-1));ATL.hov.y=Math.max(-1,Math.min(1,(e.clientY-r.top)/r.height*2-1))}});
 const up=e=>{if(e.pointerId!==pid)return;ATL.drag=null;pid=null;if(moved<7){const r=cv.getBoundingClientRect(),h=atlHit(e.clientX-r.left,e.clientY-r.top);if(h)atlTip(h)}};
 cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',e=>{if(e.pointerId===pid){ATL.drag=null;pid=null}});
 cv.addEventListener('pointerleave',e=>{if(e.pointerType==='mouse'){ATL.hov.x=0;ATL.hov.y=0}});
}
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&ATL.cv&&!ATL.raf&&!ATL.rm){ATL.last=performance.now();ATL.raf=requestAnimationFrame(atlFrame)}});
window.addEventListener('resize',()=>{if(ATL.cv){atlSize();ATL.dirty=1;if(ATL.rm&&!ATL.raf)ATL.raf=requestAnimationFrame(atlFrame)}});
bindAtlasParallax=function(){};

// ===================== PLAYGROUND =====================
// Registry: to add a tool, push an entry here and define VX.<id> (a view function).
const PIC={
 pw:'<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="17"/><path d="M24 7v34M7 24h34M12 12l24 24M36 12L12 36"/><circle cx="24" cy="24" r="3" fill="currentColor"/></svg>',
 pc:'<svg viewBox="0 0 48 48"><ellipse cx="24" cy="24" rx="17" ry="17"/><ellipse cx="24" cy="24" rx="11" ry="11"/><path d="M21 19h6M24 19v10"/></svg>',
 pn:'<svg viewBox="0 0 48 48"><rect x="8" y="8" width="32" height="32" rx="8"/><circle cx="17" cy="17" r="2" fill="currentColor"/><circle cx="31" cy="17" r="2" fill="currentColor"/><circle cx="24" cy="24" r="2" fill="currentColor"/><circle cx="17" cy="31" r="2" fill="currentColor"/><circle cx="31" cy="31" r="2" fill="currentColor"/></svg>',
 pd:'<svg viewBox="0 0 48 48"><path d="M6 14h10l16 20h10M6 34h10l16-20h10"/><path d="M38 9l4 5-4 5M38 29l4 5-4 5"/></svg>',
 pf:'<svg viewBox="0 0 48 48"><circle cx="24" cy="26" r="15"/><path d="M24 17v9l6 4M19 6h10"/></svg>',
 pt:'<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="16"/><circle cx="24" cy="24" r="9"/><circle cx="24" cy="24" r="2.5" fill="currentColor"/></svg>'};
const PLAY=[
 {id:'pw',n:'Spin the Wheel',d:'Your own options, fair odds',k:'CHANCE'},
 {id:'pc',n:'Coin Toss',d:'A real flip, one or many',k:'CHANCE'},
 {id:'pn',n:'Random Number',d:'Any range you set',k:'CHANCE'},
 {id:'pd',n:'Decision Picker',d:'Let OPUX choose for you',k:'DECIDE'},
 {id:'pt',n:'Task Picker',d:'Pick from your activities',k:'DECIDE'},
 {id:'pf',n:'Focus Session',d:'Timed work, logged on your say',k:'FOCUS'}];
Object.assign(PAR,{pl:'mo',pr:'st',ai:'mo'});for(const t of PLAY)PAR[t.id]='mo';
VX.pl=function(){return bk('More')+`<div class="pl-hero"><div class="node-kicker">OPUX ／ PLAYGROUND</div><h2>Small things,<br><em>done well.</em></h2><p>Tools that decide, flip, roll and focus. Everything runs on this device.</p></div>
 <div class="pl-grid">${PLAY.map((t,i)=>`<button class="pl-tile" onclick="go('${t.id}')" style="--i:${i}"><span class="pl-ic">${PIC[t.id]}</span><small>${t.k}</small><b>${t.n}</b><span class="pl-d">${t.d}</span></button>`).join('')}</div>
 <div class="more-footer"><span>PLAYGROUND</span><span>SOUND &amp; MOTION IN SETTINGS</span></div>`};
const plHead=(k,t,sub)=>bk('Playground')+`<div class="node-kicker">${k}</div><h2 style="margin-top:0">${t}</h2>${sub?`<small class="setting-copy">${sub}</small>`:''}`;
const plSnd=()=>X().ps!==0;
function plTone(f,d,type,v,delay){if(!plSnd())return;try{AX=AX||new(window.AudioContext||window.webkitAudioContext)();if(AX.state==='suspended')AX.resume();const t=AX.currentTime+(delay||0),o=AX.createOscillator(),g=AX.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f,t);g.gain.setValueAtTime(0.0001,t);g.gain.exponentialRampToValueAtTime(v||.12,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(AX.destination);o.start(t);o.stop(t+d+.02)}catch(e){}}
const plSndChip=()=>`<button class="chip" onclick="X().ps=plSnd()?0:1;save();render()" aria-pressed="${plSnd()}">${plSnd()?'🔊 Sound on':'🔇 Sound off'}</button>`;
function confetti(){if(RM())return;let c=document.getElementById('confetti');if(c)c.remove();c=document.createElement('canvas');c.id='confetti';c.style.cssText='position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:50';document.body.appendChild(c);
 const W=c.width=innerWidth,H=c.height=innerHeight,x=c.getContext('2d'),cols=['#fff',getComputedStyle(document.documentElement).getPropertyValue('--ac').trim()||'#6366f1',getComputedStyle(document.documentElement).getPropertyValue('--a2').trim()||'#a855f7','#facc15','#34d399'],
 P=Array.from({length:70},()=>({x:W/2+(rfrac()-.5)*80,y:H*.45,vx:(rfrac()-.5)*9,vy:-5-rfrac()*8,r:3+rfrac()*4,c:cols[rint(cols.length)],a:rfrac()*6,va:(rfrac()-.5)*.4}));let t0=performance.now();
 (function f(n){const k=(n-t0)/1700;if(k>=1||!document.body.contains(c)){c.remove();return}x.clearRect(0,0,W,H);for(const p of P){p.vy+=.28;p.x+=p.vx;p.y+=p.vy;p.a+=p.va;x.save();x.translate(p.x,p.y);x.rotate(p.a);x.globalAlpha=1-k*k;x.fillStyle=p.c;x.fillRect(-p.r,-p.r/2,p.r*2,p.r);x.restore()}requestAnimationFrame(f)})(t0)}

// ---------- Spin the Wheel ----------
const WPAL={vivid:['#ef4444','#f97316','#eab308','#22c55e','#06b6d4','#3b82f6','#8b5cf6','#ec4899'],soft:['#fda4af','#fdba74','#fde68a','#bbf7d0','#a5f3fc','#bfdbfe','#ddd6fe','#fbcfe8'],ocean:['#0ea5e9','#0284c7','#06b6d4','#0891b2','#38bdf8','#14b8a6','#2563eb','#0d9488'],ember:['#7f1d1d','#b91c1c','#ea580c','#f59e0b','#be123c','#9a3412','#d97706','#dc2626'],mono:['#e2e8f0','#94a3b8','#cbd5e1','#64748b','#f1f5f9','#7c8aa5','#aab4c8','#475569'],theme:null};
const WPN={vivid:'Vivid',soft:'Soft',ocean:'Ocean',ember:'Ember',mono:'Mono',theme:'Theme'};
const W22={rot:0,sp:false,res:null,cache:null,raf:0,lastI:-1};
function wheelColors(w){let p=WPAL[w.pal];if(!p){const c=getComputedStyle(document.documentElement),a=c.getPropertyValue('--ac').trim()||'#6366f1',b=c.getPropertyValue('--a2').trim()||'#a855f7';p=[a,b,`color-mix(in srgb,${a} 60%,#000)`,`color-mix(in srgb,${b} 60%,#000)`,`color-mix(in srgb,${a} 70%,#fff)`,`color-mix(in srgb,${b} 70%,#fff)`]}
 return w.o.map((_,i)=>{let c=p[i%p.length];if(w.o.length>p.length&&i>=p.length&&i%p.length===0&&i===w.o.length-1)c=p[(i+1)%p.length];return c})}
function curWheel(){const x=X();let w=x.wh.find(q=>q.id===x.whSel);if(!w){w=x.wh[0]}return w}
function ensureWheel(){const x=X();if(!x.wh.length){const w={id:uid(),n:'Random decision',pal:'vivid',o:[{id:uid(),t:'Yes'},{id:uid(),t:'No'}]};x.wh.push(w);x.whSel=w.id;save()}else if(!x.wh.some(q=>q.id===x.whSel)){x.whSel=x.wh[0].id;save()}return curWheel()}
const wLock=()=>{if(W22.sp){toast('Wait for the wheel to stop');return true}return false};
VX.pw=function(){const w=ensureWheel(),x=X(),n=w.o.length;
 return plHead('PLAYGROUND ／ CHANCE','Spin the <em>wheel</em>','Winner is drawn first with unbiased random numbers; the animation then lands on it.')+
 `<div class="row" style="gap:8px;margin:6px 0 2px"><select aria-label="Saved wheels" onchange="wheelSel(this.value)">${x.wh.map(q=>`<option value="${q.id}"${q.id===w.id?' selected':''}>${esc(q.n)}</option>`).join('')}<option value="__new">＋ New wheel…</option></select>${plSndChip()}</div>
 <div class="wheel-wrap"><div class="wheel-ptr" id="wptr"></div><canvas id="wcv" class="wheel-cv" aria-label="Wheel with ${n} options"></canvas><button class="wheel-hub" id="whub" onclick="wheelSpin()" ${n<2?'disabled':''} aria-label="Spin the wheel">SPIN</button></div>
 <div class="wheel-res" id="wres" role="status" aria-live="polite">${W22.res?wheelResHTML(W22.res):'<small>Tap SPIN. '+(n<2?'Add at least 2 options below.':'')+'</small>'}</div>
 <div class="row" style="gap:8px"><button class="btn" id="wspin" style="margin:6px 0" onclick="wheelSpin()" ${n<2?'disabled':''}>Spin</button><button class="btn ol" style="margin:6px 0" onclick="wheelReset()">Reset</button></div>
 <div class="cd"><label>Wheel name</label><input value="${esc(w.n)}" maxlength="40" onchange="wheelName(this)">
 <label>Colours</label><div class="chips">${Object.keys(WPN).map(k=>`<button class="chip${w.pal===k?' on':''}" onclick="if(wLock())return;curWheel().pal='${k}';save();render()">${WPN[k]}</button>`).join('')}</div>
 <h4 style="margin-top:12px">Options (${n}/24)</h4>${w.o.map((o,i)=>`<div class="li" style="margin-bottom:4px"><i class="dt" style="background:${esc(wheelColors(w)[i])}"></i><input value="${esc(o.t)}" maxlength="40" aria-label="Option ${i+1}" onchange="wheelOpt(${i},this.value)"><button class="chip" aria-label="Remove option" onclick="wheelDel(${i})">✕</button></div>`).join('')}
 <div class="li"><input id="wnew" placeholder="Add an option" maxlength="40" onkeydown="if(event.key==='Enter'){wheelAdd();return false}"><button class="chip" onclick="wheelAdd()">Add</button></div></div>
 <div class="cd"><h4>Wheels</h4><div class="chips"><button class="chip" onclick="wheelTplSheet()">＋ From template</button><button class="chip" onclick="wheelDup()">Duplicate</button><button class="chip" onclick="wheelDelete()">Delete wheel</button></div><small>Saved on this device with your OPUX data.</small></div>`};
function wheelResHTML(r){return`<div class="wr-in"><small>WINNER</small><b><i class="dt" style="background:${esc(r.c)}"></i>${esc(r.t)}</b></div>`}
function wheelSel(v){if(wLock()){render();return}if(v==='__new'){const w={id:uid(),n:'New wheel',pal:'vivid',o:[{id:uid(),t:'Option 1'},{id:uid(),t:'Option 2'}]};X().wh.unshift(w);X().wh=X().wh.slice(0,30);X().whSel=w.id}else X().whSel=v;W22.res=null;W22.rot=0;save();render()}
function wheelName(el){if(W22.sp){toast('Wait for the wheel to stop');el.value=curWheel().n;return}const w=curWheel();w.n=el.value.trim().slice(0,40)||'Untitled wheel';save();const o=document.querySelector('select[aria-label="Saved wheels"] option[value="'+w.id+'"]');if(o)o.textContent=w.n}
function wheelOpt(i,v){if(W22.sp){toast('Wait for the wheel to stop');render();return}const w=curWheel();v=v.trim();if(!v){toast('Option names cannot be empty');render();return}w.o[i].t=v.slice(0,40);save();W22.res=null;const r=$('#wres');if(r)r.innerHTML='<small>Tap SPIN.</small>';wheelDraw(-1)}
function wheelAdd(){if(wLock())return;const w=curWheel(),el=$('#wnew'),v=(el.value||'').trim();if(!v){sfx('err');return}if(w.o.length>=24){toast('A wheel holds up to 24 options');return}w.o.push({id:uid(),t:v.slice(0,40)});save();W22.res=null;sfx('add');render();const e2=$('#wnew');if(e2)e2.focus()}
function wheelDel(i){if(wLock())return;const w=curWheel();if(w.o.length<=1){toast('Keep at least one option');return}w.o.splice(i,1);save();W22.res=null;sfx('del');render()}
function wheelDup(){if(wLock())return;const w=curWheel();if(X().wh.length>=30){toast('Wheel limit reached (30)');return}const c={id:uid(),n:(w.n+' copy').slice(0,40),pal:w.pal,o:w.o.map(o=>({id:uid(),t:o.t}))};X().wh.unshift(c);X().whSel=c.id;save();toast('Wheel duplicated');render()}
function wheelDelete(){if(wLock())return;const w=curWheel();if(!confirm('Delete the wheel “'+w.n+'”?'))return;X().wh=X().wh.filter(q=>q.id!==w.id);X().whSel='';W22.res=null;save();render();toast('Wheel deleted')}
function wheelReset(){if(wLock())return;W22.rot=0;W22.res=null;render()}
function wheelTplSheet(){if(wLock())return;const pw=S.acts.filter(a=>curCls(a)==='w').map(a=>a.n);
 openSheet(`<div class="row"><h3>New wheel from template</h3><button class="x" onclick="closeSheet();render()">✕</button></div><p class="setting-copy">Templates are ordinary wheels: edit everything afterwards. Study and subject wheels use your Productive Work activities when you have at least two; otherwise they start with placeholders.</p>
 ${[['study','What should I study?'],['subject','Which subject should I work on?'],['task','What task should I do next?'],['decide','Random decision']].map(t=>`<button class="mr" onclick="wheelTpl('${t[0]}')"><span>${t[1]}</span><span>›</span></button>`).join('')}`)}
function wheelTpl(k){const pw=S.acts.filter(a=>curCls(a)==='w').map(a=>a.n);let n,o;
 if(k==='study'||k==='subject'){n=k==='study'?'What should I study?':'Which subject should I work on?';o=pw.length>=2?pw.slice(0,24):['Subject 1','Subject 2','Subject 3']}
 else if(k==='task'){n='What task should I do next?';o=['Task 1','Task 2','Task 3']}else{n='Random decision';o=['Yes','No']}
 if(X().wh.length>=30){toast('Wheel limit reached (30)');return}
 const w={id:uid(),n,pal:'vivid',o:o.map(t=>({id:uid(),t:String(t).slice(0,40)}))};X().wh.unshift(w);X().whSel=w.id;W22.res=null;W22.rot=0;save();closeSheet();render();toast(pw.length<2&&(k==='study'||k==='subject')?'Placeholders added. Edit them to your subjects.':'Wheel created')}
const wIdx=(rot,n)=>{const T=6.283185307179586,a=(((-rot)%T)+T)%T;return Math.min(n-1,Math.floor(a/(T/n)))};
function wheelBuild(w,S2){const T=6.283185307179586,n=w.o.length,cols=wheelColors(w),c=document.createElement('canvas');c.width=c.height=S2;const x=c.getContext('2d'),r=S2/2,seg=T/n;x.translate(r,r);
 const lum=h=>{const t=document.createElement('canvas').getContext('2d');t.fillStyle=h;const v=t.fillStyle;const m=/^#([0-9a-f]{6})$/i.exec(v);if(!m)return .4;const q=parseInt(m[1],16);return(.299*(q>>16)+.587*(q>>8&255)+.114*(q&255))/255};
 for(let i=0;i<n;i++){const a0=-Math.PI/2+i*seg,a1=a0+seg;x.beginPath();x.moveTo(0,0);x.arc(0,0,r*.97,a0,a1);x.closePath();x.fillStyle=cols[i];x.fill();x.strokeStyle='rgba(0,0,0,.28)';x.lineWidth=S2/220;x.stroke();
  x.save();x.rotate(a0+seg/2);x.textAlign='right';x.textBaseline='middle';x.fillStyle=lum(cols[i])>.62?'#111827':'#fff';const fs=Math.max(S2/30,Math.min(S2/12,S2/(n>12?2.2*n/6:11)));x.font='800 '+Math.round(fs)+'px system-ui,sans-serif';
  let t=w.o[i].t;const maxw=r*.62;while(t.length>2&&x.measureText(t).width>maxw)t=t.slice(0,-2);if(t!==w.o[i].t)t+='…';x.fillText(t,r*.88,0);x.restore()}
 const g=x.createRadialGradient(0,0,r*.2,0,0,r);g.addColorStop(0,'rgba(255,255,255,.0)');g.addColorStop(.85,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.35)');x.fillStyle=g;x.beginPath();x.arc(0,0,r*.97,0,T);x.fill();
 x.lineWidth=S2/60;x.strokeStyle='rgba(255,255,255,.55)';x.beginPath();x.arc(0,0,r*.975,0,T);x.stroke();return c}
function wheelDraw(hi){const cv=$('#wcv');if(!cv)return;const w=curWheel(),n=w.o.length,size=cv.clientWidth||300,dpr=Math.min(2,window.devicePixelRatio||1),px=Math.round(size*dpr);if(cv.width!==px){cv.width=cv.height=px}
 const key=JSON.stringify([w.o.map(o=>o.t),w.pal,px,document.documentElement.dataset.t]);if(!W22.cache||W22.cache.k!==key)W22.cache={k:key,c:wheelBuild(w,px)};
 const x=cv.getContext('2d');x.setTransform(1,0,0,1,0,0);x.clearRect(0,0,px,px);x.save();x.translate(px/2,px/2);x.rotate(W22.rot);x.drawImage(W22.cache.c,-px/2,-px/2);x.restore();
 if(hi!=null&&hi>=0){const T=6.283185307179586,seg=T/n,a0=-Math.PI/2+hi*seg+W22.rot,r=px/2*.97;x.save();x.translate(px/2,px/2);x.beginPath();x.moveTo(0,0);x.arc(0,0,r,a0,a0+seg);x.closePath();x.fillStyle='rgba(255,255,255,'+(.12+.1*Math.sin(performance.now()/120))+')';x.fill();x.lineWidth=px/70;x.strokeStyle='#fff';x.stroke();x.restore()}}
function wheelInit(){W22.cache=null;wheelDraw(W22.res?W22.res.i:-1);const p=$('#wptr');if(p)p.classList.remove('flick')}
function wheelSpin(){if(W22.sp)return;const w=curWheel(),n=w.o.length;if(n<2){toast('Add at least 2 options');return}
 const T=6.283185307179586,win=rint(n),seg=T/n,u=.1+.8*rfrac(),target=-(win+u)*seg,cur=W22.rot,turns=5+rint(4);let end=cur+turns*T;end+=((target-end)%T+T)%T;
 const dur=(RM()?1200:4200+rint(2200)),t0=performance.now(),from=cur;W22.sp=true;W22.res=null;W22.lastI=wIdx(cur,n);const wr=$('#wres');if(wr)wr.innerHTML='<small>Spinning…</small>';document.querySelectorAll('#whub,#wspin').forEach(b=>b.disabled=true);
 const ease=k=>1-Math.pow(1-k,3.6);let tick=0;
 const step=now=>{if(!document.getElementById('wcv')){W22.sp=false;return}const k=Math.min(1,(now-t0)/dur);W22.rot=from+(end-from)*ease(k);const i=wIdx(W22.rot,n);
  if(i!==W22.lastI){W22.lastI=i;if(now-tick>45){tick=now;plTone(900+rint(150),.03,'triangle',.07);const p=$('#wptr');if(p){p.classList.remove('flick');void p.offsetWidth;p.classList.add('flick')}}}
  wheelDraw(-1);
  if(k<1){W22.raf=requestAnimationFrame(step);return}
  W22.sp=false;const wi=wIdx(W22.rot,n),cols=wheelColors(w);W22.res={i:wi,t:w.o[wi].t,c:cols[wi]};W22.rot=((W22.rot%T)+T)%T;
  const e=$('#wres');if(e){e.innerHTML=wheelResHTML(W22.res);e.classList.remove('pop');void e.offsetWidth;e.classList.add('pop')}document.querySelectorAll('#whub,#wspin').forEach(b=>b.disabled=false);
  plTone(523,.18,'sine',.12);plTone(659,.18,'sine',.12,.12);plTone(784,.3,'sine',.12,.24);hp();confetti();
  let f=0;const pulse=n2=>{if(!document.getElementById('wcv')||W22.sp)return;wheelDraw(W22.res.i);if(f++<50&&!RM())requestAnimationFrame(pulse);else wheelDraw(W22.res.i)};pulse()};
 W22.raf=requestAnimationFrame(step)}

// ---------- Coin Toss ----------
const CN={busy:false,n:1,series:[]};
VX.pc=function(){const h=X().cn,H=h.h,hc=H.filter(r=>r.t==='H').length,tc=H.length-hc;
 const layers=Array.from({length:9},(_,i)=>`<i class="cl" style="transform:translateZ(${(i-4)}px)"></i>`).join('');
 return plHead('PLAYGROUND ／ CHANCE','Coin <em>toss</em>','A fair 50/50 flip. The result is drawn first, then the coin is flipped to land on it.')+
 `<div class="coin-stage" id="cst"><div class="coin-shadow" id="csh"></div><div class="coin-air" id="cair"><div class="coin" id="coin" style="transform:rotateX(${CN.last==='T'?180:0}deg)"><div class="cf cf-h"><span>H</span><small>HEADS</small></div><div class="cf cf-t"><span>T</span><small>TAILS</small></div>${layers}</div></div></div>
 <div class="wheel-res coin-res" id="cres" role="status" aria-live="polite">${CN.last?'<div class="wr-in"><small>RESULT</small><b>'+(CN.last==='H'?'Heads':'Tails')+'</b></div>':'<small>Tap the coin or Flip.</small>'}</div>
 <div class="sg" role="group" aria-label="Number of flips">${[1,3,5,10].map(n=>`<button class="${CN.n===n?'on':''}" onclick="if(CN.busy)return;CN.n=${n};render()">${n===1?'Flip once':n+' flips'}</button>`).join('')}</div>
 <div class="row" style="gap:8px"><button class="btn" id="cbtn" style="margin:6px 0" onclick="coinFlip()">Flip</button><button class="btn ol" style="margin:6px 0" onclick="coinReset()">Reset</button></div>
 <div class="row" style="margin:4px 0 10px"><small>${H.length?`All time here: ${hc} heads · ${tc} tails`:''}</small>${plSndChip()}</div>
 <div class="cd"><h4>History</h4>${H.length?`<div class="coin-hist">${H.slice().reverse().slice(0,40).map(r=>`<span class="ch-${r.t}" title="${new Date(r.at).toLocaleString()}">${r.t}</span>`).join('')}</div><small>Latest first. Showing up to 40 of ${H.length}.</small>`:'<small>No flips yet. Your flips are saved here.</small>'}</div>`};
function coinFlip(){if(CN.busy)return;CN.busy=true;CN.series=[];const b=$('#cbtn');if(b)b.disabled=true;let i=0;const N=CN.n;
 const next=()=>{if(!$('#coin')){CN.busy=false;return}coinOne(N>3?560:N>1?900:1650,r=>{CN.series.push(r);X().cn.h.push({t:r,at:Date.now()});if(X().cn.h.length>200)X().cn.h.splice(0,X().cn.h.length-200);save();
   const e=$('#cres');if(e){e.innerHTML=N>1?'<div class="wr-in"><small>FLIP '+(i+1)+' OF '+N+'</small><b>'+CN.series.map(q=>q).join(' ')+'</b></div>':'<div class="wr-in"><small>RESULT</small><b>'+(r==='H'?'Heads':'Tails')+'</b></div>'}
   i++;if(i<N)setTimeout(next,N>3?120:260);else{CN.busy=false;if(b)b.disabled=false;const hs=CN.series.filter(q=>q==='H').length;
    if(N>1){const e2=$('#cres');if(e2)e2.innerHTML='<div class="wr-in"><small>'+N+' FLIPS</small><b>'+hs+' heads · '+(N-hs)+' tails</b><span class="coin-seq">'+CN.series.join(' ')+'</span></div>'}
    hp();setTimeout(()=>{if($('#coin'))render()},700)}})};next()}
function coinOne(dur,done){const r=rint(2)?'H':'T',el=$('#coin'),air=$('#cair'),sh=$('#csh');if(!el){done(r);return}
 const prev=CN.last||'H',spins=(RM()?1:4+rint(3)),from=(prev==='T'?180:0),to=spins*360+(r==='T'?180:0),d=RM()?400:dur;CN.last=r;
 plTone(1900,.06,'triangle',.1);plTone(2700,.09,'sine',.07,.03);
 if(el.animate){el.animate([{transform:'rotateX('+from+'deg)'},{transform:'rotateX('+(to)+'deg)'}],{duration:d,easing:'cubic-bezier(.2,.7,.25,1)',fill:'forwards'});
  if(!RM()&&air)air.animate([{transform:'translateY(0) scale(1)',offset:0,easing:'cubic-bezier(.2,.8,.4,1)'},{transform:'translateY(-120px) scale(1.2)',offset:.45,easing:'cubic-bezier(.6,0,.9,.4)'},{transform:'translateY(0) scale(1)',offset:.9},{transform:'translateY(-7px) scale(1)',offset:.95},{transform:'translateY(0) scale(1)',offset:1}],{duration:d});
  if(!RM()&&sh)sh.animate([{transform:'scale(1)',opacity:.5},{transform:'scale(.55)',opacity:.2,offset:.45},{transform:'scale(1)',opacity:.5}],{duration:d})}
 setTimeout(()=>{if(el.isConnected)el.style.transform='rotateX('+(r==='T'?180:0)+'deg)';plTone(r==='H'?740:520,.12,'sine',.1);done(r)},d+30)}
function coinReset(){if(CN.busy)return;if(X().cn.h.length&&!confirm('Clear the flip history?'))return;X().cn.h=[];CN.last=null;CN.series=[];save();render();toast('History cleared')}
document.addEventListener('click',e=>{if(e.target.closest&&e.target.closest('#cst'))coinFlip()});

// ---------- Random Number ----------
VX.pn=function(){const r=X().rn;
 return plHead('PLAYGROUND ／ CHANCE','Random <em>number</em>','Whole numbers, both ends included. Each value in the range is equally likely.')+
 `<div class="cd rn-card"><div class="rn-out" id="rnout" role="status" aria-live="polite">${V.rnv==null?'–':V.rnv}</div>
 <div class="hour-entry"><div><label>Minimum</label><input id="rnmin" type="number" inputmode="numeric" value="${r.min}" onchange="rnSet()"></div><div><label>Maximum</label><input id="rnmax" type="number" inputmode="numeric" value="${r.max}" onchange="rnSet()"></div></div>
 <p id="rner" class="er"></p><button class="btn" onclick="rnGen()">Generate</button>
 <div class="li" style="margin-top:10px"><span>Keep history</span><input type="checkbox" ${r.keep?'checked':''} onchange="X().rn.keep=this.checked?1:0;if(!this.checked)X().rn.h=[];save();render()"></div></div>
 ${r.keep?`<div class="cd"><div class="row"><h4>History</h4><button class="chip" onclick="X().rn.h=[];save();render()">Clear</button></div>${r.h.length?`<div class="coin-hist">${r.h.slice().reverse().slice(0,30).map(v=>`<span class="rn-chip">${v}</span>`).join('')}</div>`:'<small>Nothing generated yet.</small>'}</div>`:''}`};
function rnSet(){const lo=Math.round(+$('#rnmin').value),hi=Math.round(+$('#rnmax').value),e=$('#rner');if(!isFinite(lo)||!isFinite(hi)){e.textContent='Enter whole numbers';return false}
 if(Math.abs(lo)>1e9||Math.abs(hi)>1e9){e.textContent='Use values between −1,000,000,000 and 1,000,000,000';return false}if(lo>hi){e.textContent='Minimum must not exceed the maximum';return false}e.textContent='';X().rn.min=lo;X().rn.max=hi;save();return true}
function rnGen(){if(!rnSet()){sfx('err');return}const r=X().rn,v=r.min+rint(r.max-r.min+1),el=$('#rnout');V.rnv=v;
 const fin=()=>{if(el){el.textContent=v;el.classList.remove('pop');void el.offsetWidth;el.classList.add('pop')}if(r.keep){r.h.push(v);if(r.h.length>100)r.h.shift()}save();plTone(660,.1,'sine',.1);hp();if(r.keep)render()};
 if(RM()||!el){fin();return}let n=0;const id=setInterval(()=>{el.textContent=r.min+rint(r.max-r.min+1);if(++n>=12){clearInterval(id);fin()}},45)}

// ---------- Decision Picker ----------
const DP={busy:false,items:null,hi:-1,res:null};
function dpItems(){if(!DP.items)DP.items=(X().pk.last||'').split('\n').map(s=>s.trim()).filter(Boolean);return DP.items}
VX.pd=function(){const it=dpItems(),x=X();
 return plHead('PLAYGROUND ／ DECIDE','Decision <em>picker</em>','Add your choices and let chance pick one. Every choice has the same odds.')+
 `<div class="cd"><label>Choices (one per line)</label><textarea id="dpt" rows="5" placeholder="Pizza&#10;Sushi&#10;Tacos" onchange="dpRead(true)">${esc(it.join('\n'))}</textarea><small>${it.length} choice${it.length===1?'':'s'}${it.length<2?' · add at least 2':''}</small>
 <div class="dp-list" id="dpl">${it.map((t,i)=>`<span class="dp-it${DP.hi===i?' hi':''}${DP.res===i?' win':''}" data-i="${i}">${esc(t)}</span>`).join('')}</div>
 <button class="btn" onclick="dpPick()" ${DP.busy?'disabled':''}>Pick one</button></div>
 <div class="wheel-res" id="dpr" role="status" aria-live="polite">${DP.res!=null&&it[DP.res]!=null?'<div class="wr-in"><small>OPUX PICKS</small><b>'+esc(it[DP.res])+'</b></div>':''}</div>
 <div class="cd"><h4>Frequent choices</h4><div class="li"><input id="dpn" placeholder="Name this set (e.g. Lunch)" maxlength="30"><button class="chip" onclick="dpSave()">Save set</button></div>
 ${x.pk.list.length?x.pk.list.map(s=>`<div class="li" style="padding:6px 0"><span><b>${esc(s.n)}</b><br><small>${esc(s.items.slice(0,6).join(', '))}${s.items.length>6?'…':''}</small></span><span><button class="chip" onclick="dpLoad('${s.id}')">Load</button> <button class="chip" aria-label="Delete set" onclick="dpDel('${s.id}')">✕</button></span></div>`).join(''):'<small>Save sets you decide between often, then load them in one tap.</small>'}</div>`};
function dpRead(nr){if(DP.busy)return;const v=($('#dpt')||{}).value||'';DP.items=v.split('\n').map(s=>s.trim().slice(0,60)).filter(Boolean).slice(0,60);X().pk.last=DP.items.join('\n');DP.res=null;save();if(!nr)render()}
function dpPick(){if(DP.busy)return;dpRead();const it=dpItems();if(it.length<2){toast('Add at least 2 choices');sfx('err');return}DP.busy=true;const win=rint(it.length);DP.res=null;
 const seq=[];let n=RM()?0:Math.max(10,Math.min(26,it.length*2+6));let c=rint(it.length);for(let i=0;i<n;i++){c=(c+1)%it.length;seq.push(c)}seq.push(win);
 let i=0;const step=()=>{if(!$('#dpl')){DP.busy=false;return}DP.hi=seq[i];document.querySelectorAll('.dp-it').forEach((e,k)=>e.classList.toggle('hi',k===DP.hi));plTone(500+i*18,.03,'triangle',.06);i++;
  if(i<seq.length){setTimeout(step,45+Math.pow(i/seq.length,3)*320)}else{DP.busy=false;DP.res=win;DP.hi=-1;plTone(784,.2,'sine',.12);hp();render()}};step()}
function dpSave(){const nm=(($('#dpn')||{}).value||'').trim();dpRead(true);const n=nm,it=dpItems();if(!n){toast('Name the set first');return}if(it.length<2){toast('Add at least 2 choices');return}if(X().pk.list.length>=20){toast('Up to 20 saved sets');return}X().pk.list.push({id:uid(),n:n.slice(0,30),items:it.slice(0,60)});save();sfx('add');toast('Set saved');render()}
function dpLoad(id){const s=X().pk.list.find(q=>q.id===id);if(!s)return;DP.items=s.items.slice();X().pk.last=s.items.join('\n');DP.res=null;save();render()}
function dpDel(id){X().pk.list=X().pk.list.filter(q=>q.id!==id);save();render()}

// ---------- Task Picker (uses your existing activities; there is no separate task list in OPUX) ----------
const TP={res:null,busy:false};
function tpSet(){const x=X(),ok=S.acts.map(a=>a.id);let L=x.tp.filter(i=>ok.includes(i));if(!x.tpInit){L=S.acts.filter(a=>curCls(a)==='w').map(a=>a.id);if(!L.length)L=ok.slice();}return L}
VX.pt=function(){const L=tpSet(),x=X();
 return plHead('PLAYGROUND ／ DECIDE','Task <em>picker</em>','Picks from your existing activities. OPUX has no separate task list, so activities are the pool.')+
 `<div class="cd"><h4>Pool</h4><div class="chips">${S.acts.map(a=>`<button class="chip${L.includes(a.id)?' on':''}" onclick="tpTog('${a.id}')" aria-pressed="${L.includes(a.id)}"><i style="background:${a.c}"></i>${esc(a.n)}${CG(a)}</button>`).join('')}</div><small>${L.length} selected${!x.tpInit?' · defaults to your Productive Work activities':''}</small>
 <button class="btn" onclick="tpPick()" ${L.length<2?'disabled':''}>Pick one</button>${L.length<2?'<small>Select at least 2 activities.</small>':''}</div>
 <div class="wheel-res" id="tpr" role="status" aria-live="polite">${TP.res&&S.acts.find(a=>a.id===TP.res)?(()=>{const a=S.acts.find(q=>q.id===TP.res);return'<div class="wr-in"><small>NEXT UP</small><b><i class="dt" style="background:'+a.c+'"></i>'+esc(a.n)+'</b></div>'})():''}</div>
 ${TP.res&&S.acts.find(a=>a.id===TP.res)?`<div class="row" style="gap:8px"><button class="btn" style="margin:6px 0" onclick="fsFor('${TP.res}')">Start a focus session</button><button class="btn ol" style="margin:6px 0" onclick="tpTimer('${TP.res}')">Start tracker timer</button></div>`:''}`};
function tpTog(id){const x=X();let L=tpSet();L=L.includes(id)?L.filter(i=>i!==id):L.concat(id);x.tp=L;x.tpInit=1;TP.res=null;save();render()}
function tpPick(){const L=tpSet();if(L.length<2)return;TP.res=L[rint(L.length)];plTone(660,.12,'sine',.1);hp();render()}
function tpTimer(id){if(S.timer){toast('A tracker timer is already running');return}S.timer={a:id,d:todayS(),t:Date.now()};save();toast('Timer started for '+act(id).n);V.d=todayS();go('tr')}
function fsFor(id){X().fx.pre=id;go('pf')}

// ---------- Focus Session ----------
// state in X().fx: {a (activity), dur (min), acc (ms accumulated), run (start ts of current run or 0), on (1 when a session exists), pre}
const FS={tm:0};
const fsElapsed=()=>{const f=X().fx;return f.acc+(f.run?Date.now()-f.run:0)};
const clk=ms=>{const s=Math.max(0,Math.round(ms/1000));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0')};
VX.pf=function(){const f=X().fx,day=todayS(),done=X().fs.filter(s=>s.d===day);
 if(!f.on){const a=f.pre&&S.acts.some(q=>q.id===f.pre)?f.pre:(S.acts.find(q=>curCls(q)==='w')||S.acts[0]).id,du=f.dur||25;
  return plHead('PLAYGROUND ／ FOCUS','Focus <em>session</em>','Time one block of work. Nothing is added to your tracker until you confirm it.')+
  `<div class="cd"><label>Task / activity</label>${chips(a,'fsA')}<label>Duration</label><div class="chips">${[15,25,45,60,90].map(n=>`<button class="chip${du===n?' on':''}" onclick="X().fx.dur=${n};save();render()">${n} min</button>`).join('')}</div>
  <div class="hour-entry"><div><label>Custom minutes</label><input id="fsc" type="number" inputmode="numeric" min="1" max="480" value="${du}" onchange="X().fx.dur=Math.max(1,Math.min(480,Math.round(+this.value||25)));save()"></div><div></div></div>
  <button class="btn" onclick="fsStart('${a}')">Start focus</button></div>
  <div class="cd"><h4>Completed today</h4>${done.length?done.map(s=>`<div class="li"><span>${esc(act(s.a).n)}</span><b>${fmt(s.min)}</b></div>`).join(''):'<small>No confirmed sessions today.</small>'}</div>`}
 const el=fsElapsed(),left=f.dur*60000-el,pct=Math.min(100,el/(f.dur*600)),over=left<=0;
 return plHead('PLAYGROUND ／ FOCUS',over?'Time’s <em>up</em>':'In <em>focus</em>',esc(act(f.a).n))+
 `<div class="fs-ring"><svg viewBox="0 0 120 120"><circle class="rb" cx="60" cy="60" r="52"/><circle class="fs-prog" id="fsp" cx="60" cy="60" r="52" pathLength="100" style="stroke-dasharray:${pct} 100"/></svg><div><b id="fst">${over?'00:00':clk(left)}</b><small id="fss">${over?'Session complete':f.run?'Focusing':'Paused'}</small></div></div>
 <div class="row" style="gap:8px">${over?`<button class="btn" onclick="fsFinish()">Review &amp; record</button>`:f.run?`<button class="btn ol" onclick="fsPause()">Pause</button>`:`<button class="btn" onclick="fsResume()">Resume</button>`}${over?'':`<button class="btn" style="background:#374151" onclick="fsFinish()">Finish early</button>`}</div>
 <button class="btn ol" onclick="fsDiscard()">Discard session</button><small class="setting-copy">Elapsed ${clk(el)} of ${f.dur} min. The session keeps timing if you leave this screen.</small>`};
function fsA(a){X().fx.pre=a;save();render()}
function fsSeal(end){const f=X().fx;if(!f.run)return;end=end||Date.now();if(end>f.run)(f.sg=f.sg||[]).push([f.run,end]);f.acc+=Math.max(0,end-f.run);f.run=0}
function fsStart(a){const f=X().fx;f.on=1;f.a=a;f.acc=0;f.run=Date.now();f.dn=0;f.pre=a;f.sg=[];save();sfx('ok');hp();render()}
function fsPause(){const f=X().fx;if(f.run){fsSeal();save();render()}}
function fsResume(){const f=X().fx;if(!f.run){f.run=Date.now();save();render()}}
function fsDiscard(){if(!confirm('Discard this session? Nothing will be recorded.'))return;const f=X().fx;f.on=0;f.run=0;f.acc=0;save();render()}
function fsFinish(){const f=X().fx;if(f.run){fsSeal();save()}const m=Math.max(1,Math.round(f.acc/60000));
 openSheet(`<div class="row"><h3>Record this session?</h3><button class="x" onclick="closeSheet();render()">✕</button></div><p class="setting-copy">You focused on <b>${esc(act(f.a).n)}</b>. Confirm the time to add it to today’s tracker, or discard it. Nothing is recorded without your confirmation.</p>
 <label>Minutes to record</label><input id="fsm" type="number" inputmode="numeric" min="1" max="1440" value="${m}"><p id="fse" class="er"></p><button class="btn" onclick="fsConfirm()">Add to tracker</button><button class="btn ol" onclick="closeSheet();fsDiscardNow()">Discard</button><button class="btn ol" onclick="closeSheet();render()">Keep session open</button>`)}
function fsDiscardNow(){const f=X().fx;f.on=0;f.run=0;f.acc=0;save();render()}
function fsConfirm(){const f=X().fx,m=Math.round(+$('#fsm').value);if(!(m>0)){$('#fse').textContent='Enter minutes above 0';return}
 const sg=(f.sg||[]).filter(q=>q[1]>q[0]),segMin=sg.reduce((s,q)=>s+(q[1]-q[0])/60000,0),end=sg.length?sg[sg.length-1][1]:Date.now();let parts;
 if(sg.length&&Math.abs(segMin-m)<=1.5){const by={};sg.forEach(q=>splitSpan(q[0],q[1]).forEach(p=>by[p.d]=R((by[p.d]||0)+p.min)));parts=Object.keys(by).sort().map(d=>({d,min:by[d]}));
  const diff=R(m-parts.reduce((s,p)=>s+p.min,0));if(parts.length&&diff)parts[parts.length-1].min=R(Math.max(.01,parts[parts.length-1].min+diff))}
 else parts=splitSpan(end-m*60000,end);
 const r=putParts(parts,f.a,'Focus session',true);if(r.err){$('#fse').textContent=r.err;sfx('err');return}
 r.rec.forEach(p=>X().fs.push({id:uid(),d:p.d,a:f.a,min:p.min,at:Date.now()}));while(X().fs.length>1000)X().fs.shift();f.on=0;f.run=0;f.acc=0;f.sg=[];save();closeSheet();sfx('refill');toast('Focus session recorded · '+(r.rec.length>1?r.rec.map(p=>fmt(p.min)+' on '+fd(p.d)).join(' · '):fmt(m)));confetti();render()}
setInterval(()=>{if(V.v!=='pf')return;const f=X().fx;if(!f.on)return;const el=fsElapsed(),left=f.dur*60000-el,t=$('#fst');if(!t)return;
 if(left<=0&&f.run){fsSeal(f.run+Math.max(0,f.dur*60000-f.acc));f.acc=f.dur*60000;save();hp();sfx('ok');plTone(784,.25,'sine',.15);plTone(988,.35,'sine',.15,.2);render();return}
 if(left>0){t.textContent=clk(left);const p=$('#fsp');if(p)p.style.strokeDasharray=Math.min(100,el/(f.dur*600))+' 100'}},500);

// ===================== OPUX INTELLIGENCE (ChatGPT-assisted workflows) =====================
// These screens only BUILD TEXT from local data. Nothing is sent anywhere; the user copies it and pastes it into ChatGPT.
const AIQ={notes:0,tasks:''};
V.ai=V.ai||{dn:0,pd:14,wk:0,tb:{t:'',dl:'',tm:'',ctx:'',avg:0},ps:'all'};
function clsLine(a){return 'Productive Work '+hm(a.w)+' · Neutral '+hm(a.n)+' · Leisure/personal '+hm(a.l)+' · Unclassified '+hm(a.u)}
function actTotals(L,notes){const B=byAct(L),T=sum(B);return Object.keys(B).sort((a,b)=>B[b]-B[a]).map(id=>{const k=clsOn(id,L[L.length-1]||todayS());return'- '+act(id).n+' — '+hm(B[id])+' ('+(T?R(B[id]/T*100):0)+'% of tracked) — '+CLS[k].n}).join('\n')}
function dayRows(L){return L.map(d=>{if(!S.days[d])return iso(d)+': no record';const c=dayCls(d);return iso(d)+': tracked '+hm(c.t)+' | productive '+hm(c.w)+' ('+c.pct+'%) | neutral '+hm(c.n)+' | leisure/personal '+hm(c.l)+' | unclassified '+hm(c.u)}).join('\n')}
function dayNotes(d){const n=(S.days[d]||[]).filter(e=>e.note&&e.note!=='Timer'&&e.note!=='Focus session'&&e.note!=='Check-in estimate');return n.length?'\nMY ENTRY NOTES\n'+n.map(e=>'- '+act(e.act).n+': '+e.note).join('\n'):''}
function clsNote(){const x=X().cl;return x.length?'\n- Some activity classifications changed over time ('+x.map(q=>act(q.a).n+' → '+CLS[q.c].n+' from '+q.d).join('; ')+'); each day uses the classification in force on that day.':''}
function todayBlock(d,notes){const c=dayCls(d),B=byAct([d]),ids=Object.keys(B).sort((a,b)=>B[b]-B[a]);
 return'- Tracked: '+hm(c.t)+' ('+c.t+' min) of 24h; untracked: '+hm(1440-c.t)+'\n- Productive work: '+hm(c.w)+' ('+c.pct+'% of tracked)\n- Neutral: '+hm(c.n)+'\n- Leisure / personal: '+hm(c.l)+'\n- Unclassified: '+hm(c.u)+'\n\nMAIN ACTIVITIES (time — my classification)\n'+(ids.length?ids.map(id=>'- '+act(id).n+' — '+hm(B[id])+' — '+CLS[clsOn(id,d)].n).join('\n'):'- nothing recorded')+(notes?dayNotes(d):'')}
function prevAvg(d,n){const P=recDays().filter(q=>q<d).slice(-n);if(!P.length)return null;const a=aggCls(P);return{n:P.length,t:a.t/P.length,w:a.w/P.length,pct:a.pct,P}}
function focusLines(d){const f=X().fs.filter(s=>s.d===d);return f.length?f.map(s=>'- '+hm(s.min)+' on '+act(s.a).n+' (confirmed and recorded)').join('\n'):'- none recorded in OPUX for this date'}
function dailyBrief(d,o){const y=add(d,-1),pa=prevAvg(d,7),c=dayCls(d);
 let s='I use OPUX, a personal 24-hour time tracker. Below is my real tracked data for one day. Please write a concise daily brief.\n\nDATE: '+iso(d)+'\n\nTODAY\n'+todayBlock(d,o.notes)+'\n\nFOCUS SESSIONS COMPLETED\n'+focusLines(d)+'\n\nREMAINING TASKS\n'+(o.tasks.trim()?o.tasks.trim().split('\n').map(l=>'- '+l.replace(/^[-•*]\s*/,'')).join('\n'):'- OPUX has no task list, and I did not add any here. Do not assume any.')+'\n\nCOMPARISON WITH PREVIOUS DAYS\n';
 s+=S.days[y]?'- Yesterday ('+iso(y)+'): tracked '+hm(dayCls(y).t)+', productive '+hm(dayCls(y).w)+' ('+dayCls(y).pct+'%)\n':'- Yesterday ('+iso(y)+'): no record in OPUX\n';
 s+=pa?'- Average of my previous '+pa.n+' recorded day'+(pa.n>1?'s':'')+': tracked '+hm(pa.t)+', productive '+hm(pa.w)+'/day ('+pa.pct+'% of tracked)\n- Today vs that average: productive '+(c.w>=pa.w?'+':'−')+hm(Math.abs(c.w-pa.w))+', tracked '+(c.t>=pa.t?'+':'−')+hm(Math.abs(c.t-pa.t))+'\n':'- No earlier recorded days to compare with\n';
 s+='\nDATA NOTES\n- I only logged what is shown. Untracked time is unknown, not “wasted”.\n- Unclassified time is not counted as productive.'+clsNote()+'\n\nPLEASE\n1. Summarise my day in 3–4 sentences.\n2. Point out what stands out versus my recent days (use only the numbers above).\n3. Suggest 2–3 specific, realistic actions for the rest of today or tomorrow.\n4. Say clearly if the data is too thin to conclude something. Do not invent numbers.';return s}
function analysisPrompt(N,notes){const T=todayS(),L=Array.from({length:N},(_,i)=>add(T,i-N+1)),P=Array.from({length:N},(_,i)=>add(T,i-2*N+1)),rec=L.filter(d=>S.days[d]),a=aggCls(L),pr=P.filter(d=>S.days[d]),pa=aggCls(P);
 if(!rec.length)return'';
 const ranked=rec.map(d=>({d,w:dayCls(d).w})).sort((x,y)=>y.w-x.w);
 let s='I use OPUX, a personal 24-hour time tracker. Below is my real tracked data for the last '+N+' days ('+L[0]+' to '+L[N-1]+'). Please analyse how I used my time.\n\nDAILY BREAKDOWN\n'+dayRows(L)+'\n\nTOTALS FOR THE PERIOD ('+rec.length+' of '+N+' days have records)\n- Tracked: '+hm(a.t)+'\n- '+clsLine(a)+'\n- Productive share of tracked time: '+a.pct+'%\n- Average productive time per recorded day: '+hm(a.w/rec.length)+'\n\nWHERE MY TIME WENT (whole period)\n'+actTotals(L)+'\n\n';
 s+='STRONGEST / WEAKEST RECORDED DAYS (by productive time)\n- Highest: '+iso(ranked[0].d)+' — '+hm(ranked[0].w)+'\n- Lowest: '+iso(ranked[ranked.length-1].d)+' — '+hm(ranked[ranked.length-1].w)+'\n\nCHANGE VS THE PREVIOUS '+N+' DAYS\n';
 s+=pr.length?'- Previous period had '+pr.length+' recorded days: tracked '+hm(pa.t)+', productive '+hm(pa.w)+' ('+pa.pct+'%)\n- Productive time changed by '+(a.w>=pa.w?'+':'−')+hm(Math.abs(a.w-pa.w))+' in total; productive share '+(a.pct>=pa.pct?'+':'−')+R(Math.abs(a.pct-pa.pct))+' points\n- Note: the periods have '+rec.length+' and '+pr.length+' recorded days, so totals are not like-for-like; compare per-day averages too ('+hm(a.w/rec.length)+' vs '+hm(pa.w/pr.length)+' productive per recorded day).\n':'- No records in the previous period, so no comparison is possible.\n';
 s+='\nDATA NOTES\n- Days without a record are unknown, not zero.\n- '+hm(a.u)+' of recorded time is unclassified and is not counted as productive.'+clsNote()+(notes?'\n\nMY ENTRY NOTES (recent)\n'+rec.slice(-5).map(d=>(S.days[d]||[]).filter(e=>e.note&&!['Timer','Focus session','Check-in estimate'].includes(e.note)).map(e=>'- '+d+' '+act(e.act).n+': '+e.note).join('\n')).filter(Boolean).join('\n'):'')+'\n\nPLEASE ANALYSE\n1. How I used my time and which activities received the most attention.\n2. Productive vs non-productive time, and what the classification split suggests.\n3. How this period changed compared with the previous one.\n4. Patterns by day of week, if the data supports it.\n5. Three concrete improvements I could try next week.\nOnly use the data above. Say so when something cannot be concluded, and do not invent figures.';return s}
function weeklyPrompt(off){const T=todayS(),s0=add(wk(T),off*7),L=Array.from({length:7},(_,i)=>add(s0,i)),rec=L.filter(d=>S.days[d]),pL=L.map(d=>add(d,-7));if(!rec.length)return'';
 const a=aggCls(L),pr=pL.filter(d=>S.days[d]),pa=aggCls(pL),rk=rec.map(d=>({d,w:dayCls(d).w})).sort((x,y)=>y.w-x.w),miss=L.filter(d=>!S.days[d]),fs=X().fs.filter(q=>L.includes(q.d));
 let s='I use OPUX, a personal 24-hour time tracker. Please write a weekly review from my real data for the week '+L[0]+' to '+L[6]+(off===0?' (the current week; later days may be incomplete)':'')+'.\n\nDAY BY DAY\n'+dayRows(L)+'\n\nWEEK TOTALS\n- Tracked: '+hm(a.t)+' over '+rec.length+' recorded day'+(rec.length>1?'s':'')+'\n- Productive work: '+hm(a.w)+' ('+a.pct+'% of tracked), average '+hm(a.w/rec.length)+' per recorded day\n- Neutral '+hm(a.n)+' · Leisure/personal '+hm(a.l)+' · Unclassified '+hm(a.u)+'\n- Strongest day: '+iso(rk[0].d)+' — '+hm(rk[0].w)+' productive\n- Weakest recorded day: '+iso(rk[rk.length-1].d)+' — '+hm(rk[rk.length-1].w)+' productive'+(rk.length<2?' (only one recorded day)':'')+'\n- Focus sessions confirmed this week: '+(fs.length?fs.length+' totalling '+hm(fs.reduce((q,r)=>q+r.min,0)):'none recorded')+'\n\nACTIVITY DISTRIBUTION\n'+actTotals(L)+'\n\nCHANGE DURING THE WEEK\n';
 const h1=L.slice(0,3).filter(d=>S.days[d]),h2=L.slice(3).filter(d=>S.days[d]);
 s+=h1.length&&h2.length?'- First half (Mon–Wed) averaged '+hm(aggCls(h1).w/h1.length)+' productive per recorded day; second half (Thu–Sun) '+hm(aggCls(h2).w/h2.length)+'\n':'- Not enough recorded days in both halves of the week to describe a trend\n';
 s+='\nCOMPARED WITH THE PREVIOUS WEEK\n'+(pr.length?'- Previous week: '+pr.length+' recorded days, tracked '+hm(pa.t)+', productive '+hm(pa.w)+' ('+pa.pct+'%)\n- Productive time '+(a.w>=pa.w?'+':'−')+hm(Math.abs(a.w-pa.w))+' vs previous week (recorded days: '+rec.length+' vs '+pr.length+')\n':'- No records for the previous week\n');
 s+='\nMISSING DATA\n- Days with no record (unknown, not zero): '+(miss.length?miss.map(iso).join(', '):'none')+'\n- Unclassified time this week: '+hm(a.u)+' (not counted as productive)\n- OPUX has no task list, so completed or missed tasks are unknown'+clsNote()+'\n\nPLEASE\n1. Summarise the week honestly in one paragraph.\n2. What went well and what slipped, based only on the data above.\n3. One change to test next week, and how I can tell if it worked.\n4. List any questions the missing data stops you from answering.';return s}
function taskPrompt(t){let s='Help me break down this task into an actionable plan.\n\nTASK: '+t.t.trim()+'\n';if(t.dl.trim())s+='DEADLINE / TARGET: '+t.dl.trim()+'\n';if(t.tm.trim())s+='TIME I CAN GIVE IT: '+t.tm.trim()+'\n';if(t.ctx.trim())s+='CONTEXT / CONSTRAINTS: '+t.ctx.trim()+'\n';
 if(t.avg){const D=recDays().slice(-14);if(D.length){const a=aggCls(D);s+='MY TYPICAL CAPACITY (from OPUX, last '+D.length+' recorded days): about '+hm(a.w/D.length)+' of productive work per day.\n'}else s+='MY TYPICAL CAPACITY: OPUX has no recorded days yet.\n'}
 return s+'\nPlease respond with:\n1. Smaller steps — numbered, each concrete and finishable in one sitting.\n2. Suggested order, with a one-line reason and any dependencies.\n3. Estimated time for each step, and a total.\n4. Priority for each step (High / Medium / Low).\n5. My first action — something I can start within 5 minutes.\nIf something essential is missing, ask at most 3 questions first; otherwise state your assumptions and continue. A table is fine.'}

// ---- placeholders for Prompt Studio ----
const PH={'{{date}}':()=>iso(todayS()),'{{today_summary}}':()=>'TODAY ('+iso(todayS())+')\n'+todayBlock(todayS(),false),'{{week_summary}}':()=>{const L=Array.from({length:7},(_,i)=>add(wk(todayS()),i));return S.days&&L.some(d=>S.days[d])?'THIS WEEK\n'+dayRows(L):'(no OPUX data recorded this week)'},
 '{{last_7_days}}':()=>{const L=Array.from({length:7},(_,i)=>add(todayS(),i-6));return L.some(d=>S.days[d])?dayRows(L):'(no OPUX data in the last 7 days)'},'{{last_30_days}}':()=>{const L=Array.from({length:30},(_,i)=>add(todayS(),i-29));return L.some(d=>S.days[d])?dayRows(L):'(no OPUX data in the last 30 days)'},
 '{{top_activities_30d}}':()=>{const L=Array.from({length:30},(_,i)=>add(todayS(),i-29));return L.some(d=>S.days[d])?actTotals(L):'(no OPUX data in the last 30 days)'},
 '{{most_productive_day}}':()=>{const b=pxBest(recDays()).b;return b?'Most productive day: '+iso(b.d)+' — '+hm(b.w)+' productive of '+hm(b.t)+' tracked':'(no Productive Work classified yet)'}};
const PHD={'{{date}}':'today’s date','{{today_summary}}':'today’s totals & activities','{{week_summary}}':'this week day by day','{{last_7_days}}':'last 7 days','{{last_30_days}}':'last 30 days','{{top_activities_30d}}':'activity totals, 30 days','{{most_productive_day}}':'your best day'};
function expandPrompt(b){return b.replace(/\{\{[a-z_0-9]+\}\}/g,m=>PH[m]?PH[m]():m)}
const PCATS=['General','Study','Planning','Review','Reflection'];
const PSTART=[
 {id:'sp1',n:'Plan my study session',cat:'Study',b:'Help me plan a focused study session.\n\n{{today_summary}}\n\nSubject / goal: [type it here]\nTime available: [type it here]\n\nGive me a short plan with timed blocks, a first action, and one way to check I understood the material.'},
 {id:'sp2',n:'Explain it simply',cat:'Study',b:'Explain the following as if I am new to it, then give one worked example and two questions to test me.\n\nTopic: [type it here]'},
 {id:'sp3',n:'Evening reflection',cat:'Reflection',b:'Here is my tracked day. Ask me three short reflective questions based on it, then wait for my answers.\n\n{{today_summary}}'},
 {id:'sp4',n:'Plan next week',cat:'Planning',b:'Help me plan next week using how this week went.\n\n{{week_summary}}\n\nSuggest a realistic target for productive hours per day and where I could fit them. Use only the data above.'},
 {id:'sp5',n:'Find my time leaks',cat:'Review',b:'Look at my last 30 days and tell me where my time most likely leaks, using only these numbers.\n\n{{top_activities_30d}}\n\n{{last_30_days}}'}];
function seedPrompts(){const x=X();if(!x.prSeed){for(const p of PSTART)if(!x.pr.some(q=>q.id===p.id))x.pr.push({id:p.id,n:p.n,cat:p.cat,b:p.b});x.prSeed=1;save()}}

// ---- screens ----
VX.ai=function(){const T=[['aid','Daily Brief','Today’s hours, focus and comparisons, as a prompt'],['aip','Productivity Analysis','Several days of your data, ready for analysis'],['ait','Task Breakdown','Turn a task into steps, order and a first action'],['aiw','Weekly Review','A week of data with strongest and weakest days'],['ais','Prompt Studio','Your own reusable prompts with live OPUX data']];
 return bk('More')+`<div class="node-kicker">OPUX ／ INTELLIGENCE</div><h2 style="margin-top:0">Bring your data<br><em>to ChatGPT.</em></h2>
 <div class="ai-note"><b>How this works.</b> OPUX prepares a prompt from your own tracked data. You copy it and paste it into the ChatGPT app yourself. OPUX does not contain an AI model, makes no network requests for this, and sends nothing automatically.</div>
 <div class="ai-list">${T.map((t,i)=>`<button class="ai-row" onclick="go('${t[0]}')"><span class="ai-n">0${i+1}</span><span><b>${t[1]}</b><small>${t[2]}</small></span><i>›</i></button>`).join('')}</div>`};
Object.assign(PAR,{aid:'mo',aip:'mo',ait:'mo',aiw:'mo',ais:'mo'});
function aiOut(txt,hint){if(!txt)return'';return`<div class="cd ai-out"><div class="row"><h4>Your prompt</h4><small id="aicnt">${txt.length.toLocaleString()} characters</small></div><textarea id="aip" rows="12" spellcheck="false" oninput="$('#aicnt').textContent=this.value.length.toLocaleString()+' characters'">${esc(txt)}</textarea>
 <small class="setting-copy">${hint||'You can edit this text before copying.'} Review it: it contains your tracked data, and it only leaves OPUX when you paste it.</small>
 <div class="row" style="gap:8px"><button class="btn" style="margin:6px 0" onclick="copyText($('#aip').value)">Copy prompt</button><button class="btn ol" style="margin:6px 0" onclick="copyText($('#aip').value);openExt('https://chatgpt.com/')">Copy &amp; open ChatGPT</button></div>
 <button class="btn ol sm" style="width:100%" onclick="shareText($('#aip').value)">Share to another app…</button><small>Open ChatGPT is a link to chatgpt.com: Android may open it in the ChatGPT app or your browser. Paste the prompt there.</small></div>`}
const aiEmpty=(m)=>`<div class="cd px-empty"><h3>Not enough data yet</h3><p class="setting-copy">${m}</p><button class="btn" onclick="V.d=todayS();go('tr')">Open Tracker</button></div>`;
const aiHead=(k,t,s)=>bk('Intelligence')+`<div class="node-kicker">${k}</div><h2 style="margin-top:0">${t}</h2><small class="setting-copy">${s}</small>`;
const aiChk=(l,on,fn)=>`<div class="li" style="margin:6px 0"><span>${l}</span><input type="checkbox" ${on?'checked':''} onchange="${fn}"></div>`;
VX.aid=function(){const d=todayS(),a=V.ai;let out='';
 if(!S.days[d])return aiHead('INTELLIGENCE ／ DAILY BRIEF','Daily <em>brief</em>','Today’s tracked data, formatted for ChatGPT.')+aiEmpty('Nothing is tracked today yet. Add some activities, then come back to prepare the brief.');
 out=dailyBrief(d,{notes:a.dn,tasks:AIQ.tasks});
 return aiHead('INTELLIGENCE ／ DAILY BRIEF','Daily <em>brief</em>','Prepared from today’s real tracked data.')+
 `<div class="cd"><label>Tasks still to do today (optional — OPUX has no task list)</label><textarea rows="3" placeholder="One per line" onchange="AIQ.tasks=this.value;render()">${esc(AIQ.tasks)}</textarea>${aiChk('Include my entry notes',a.dn,"V.ai.dn=this.checked?1:0;render()")}<small>Notes stay out unless you include them.</small></div>`+(a.dbOn?aiOut(out,'This is today’s ChatGPT analysis prompt.'):`<button class="btn" onclick="V.ai.dbOn=1;render();setTimeout(()=>{const e=$('#aip');if(e)e.scrollIntoView({behavior:'smooth',block:'center'})},60)">Prepare ChatGPT Analysis</button><small class="setting-copy">Builds a prompt from today’s real data. You review it, copy it and open ChatGPT yourself.</small>`)};
VX.aip=function(){const a=V.ai,N=a.pd,out=analysisPrompt(N,a.dn);
 return aiHead('INTELLIGENCE ／ ANALYSIS','Productivity <em>analysis</em>','How you used your time, productive vs non-productive, and what changed.')+
 `<div class="cd"><label>Period</label><div class="sg">${[7,14,30].map(n=>`<button class="${N===n?'on':''}" onclick="V.ai.pd=${n};render()">${n} days</button>`).join('')}</div>${aiChk('Include recent entry notes',a.dn,"V.ai.dn=this.checked?1:0;render()")}</div>`+(out?aiOut(out):aiEmpty('There are no recorded days in the last '+N+' days.'))};
VX.ait=function(){const t=V.ai.tb,ok=t.t.trim();
 return aiHead('INTELLIGENCE ／ TASK BREAKDOWN','Task <em>breakdown</em>','Describe the task. OPUX builds a structured prompt for ChatGPT.')+
 `<div class="cd"><label>Task</label><textarea rows="3" maxlength="600" placeholder="e.g. Prepare for the physics mock exam" onchange="V.ai.tb.t=this.value;render()">${esc(t.t)}</textarea><label>Deadline (optional)</label><input value="${esc(t.dl)}" maxlength="80" onchange="V.ai.tb.dl=this.value;render()"><label>Time I can give it (optional)</label><input value="${esc(t.tm)}" maxlength="80" placeholder="e.g. 2 hours on weekdays" onchange="V.ai.tb.tm=this.value;render()"><label>Context or constraints (optional)</label><textarea rows="2" maxlength="600" onchange="V.ai.tb.ctx=this.value;render()">${esc(t.ctx)}</textarea>${aiChk('Include my typical productive time per day',t.avg,"V.ai.tb.avg=this.checked?1:0;render()")}</div>`+(ok?aiOut(taskPrompt(t)):'<div class="cd px-empty"><small>Enter a task to generate the prompt.</small></div>')};
VX.aiw=function(){const o=V.ai.wk,s0=add(wk(todayS()),o*7),out=weeklyPrompt(o);
 return aiHead('INTELLIGENCE ／ WEEKLY REVIEW','Weekly <em>review</em>','A week of your data with strongest day, weakest day and what is missing.')+
 `<div class="row" style="margin:8px 0"><button class="chip" onclick="V.ai.wk--;render()">‹ Prev</button><small>${fd(s0)} to ${fd(add(s0,6))}</small><button class="chip" onclick="V.ai.wk=Math.min(0,V.ai.wk+1);render()" ${o>=0?'disabled':''}>Next ›</button></div>`+(out?aiOut(out):aiEmpty('No recorded days in this week.'))};
// Prompt Studio
VX.ais=function(){seedPrompts();const x=X(),f=V.ai.ps,L=x.pr.filter(p=>f==='all'||p.cat===f),cats=['all'].concat(PCATS,x.pr.map(p=>p.cat).filter(c=>!PCATS.includes(c)).filter((c,i,a)=>a.indexOf(c)===i));
 return aiHead('INTELLIGENCE ／ PROMPT STUDIO','Prompt <em>studio</em>','Reusable prompts. Add {{placeholders}} to pull in live OPUX data when you copy.')+
 `<div class="chips">${cats.map(c=>`<button class="chip${f===c?' on':''}" onclick="V.ai.ps='${esc(c)}';render()">${c==='all'?'All':esc(c)}</button>`).join('')}</div><button class="btn" style="margin:2px 0 10px" onclick="promptEdit('')">＋ New prompt</button>
 ${L.length?L.map(p=>`<div class="cd ps-card"><div class="row"><b>${esc(p.n)}</b><small>${esc(p.cat)}</small></div><p class="ps-prev">${esc(p.b.slice(0,160))}${p.b.length>160?'…':''}</p>${/\{\{[a-z_0-9]+\}\}/.test(p.b)?'<small>Uses live OPUX data</small>':''}<div class="chips"><button class="chip" onclick="promptUse('${p.id}')">Preview &amp; copy</button><button class="chip" onclick="promptEdit('${p.id}')">Edit</button><button class="chip" onclick="promptDel('${p.id}')">Delete</button></div></div>`).join(''):'<div class="cd px-empty"><small>No prompts in this category.</small></div>'}
 <button class="btn ol sm" style="width:100%" onclick="promptRestore()">Restore starter prompts</button>`};
function promptUse(id){const p=X().pr.find(q=>q.id===id);if(!p)return;const t=expandPrompt(p.b);
 openSheet(`<div class="row"><h3>${esc(p.n)}</h3><button class="x" onclick="closeSheet();render()">✕</button></div><small class="setting-copy">Placeholders are filled with your current OPUX data. Edit freely, then copy.</small><textarea id="aip" rows="12" spellcheck="false">${esc(t)}</textarea><button class="btn" onclick="copyText($('#aip').value)">Copy prompt</button><button class="btn ol" onclick="copyText($('#aip').value);openExt('https://chatgpt.com/')">Copy &amp; open ChatGPT</button>`)}
function promptEdit(id){const p=id?X().pr.find(q=>q.id===id):null;window.PE={id,n:p?p.n:'',cat:p?p.cat:'General',b:p?p.b:''};
 openSheet(`<div class="row"><h3>${p?'Edit':'New'} prompt</h3><button class="x" onclick="closeSheet();render()">✕</button></div><label>Name</label><input id="pen" maxlength="60" value="${esc(PE.n)}"><label>Category</label><input id="pec" list="pecl" maxlength="24" value="${esc(PE.cat)}"><datalist id="pecl">${PCATS.map(c=>`<option value="${c}">`).join('')}</datalist>
 <label>Prompt text</label><textarea id="peb" rows="9" maxlength="6000" spellcheck="false">${esc(PE.b)}</textarea><small>Insert live data:</small><div class="chips">${Object.keys(PH).map(k=>`<button class="chip" onclick="promptIns('${k}')" title="${PHD[k]}">${k.slice(2,-2)}</button>`).join('')}</div><p id="per" class="er"></p><button class="btn" onclick="promptSave()">Save prompt</button>`)}
function promptIns(k){const t=$('#peb'),s=t.selectionStart==null?t.value.length:t.selectionStart,e=t.selectionEnd==null?s:t.selectionEnd;t.value=t.value.slice(0,s)+k+t.value.slice(e);t.focus();t.selectionStart=t.selectionEnd=s+k.length}
function promptSave(){const n=$('#pen').value.trim(),c=($('#pec').value.trim()||'General').slice(0,24),b=$('#peb').value;if(!n){$('#per').textContent='Give the prompt a name';return}if(!b.trim()){$('#per').textContent='The prompt text is empty';return}
 const x=X();if(PE.id){const p=x.pr.find(q=>q.id===PE.id);if(p){p.n=n.slice(0,60);p.cat=c;p.b=b.slice(0,6000)}}else{if(x.pr.length>=100){$('#per').textContent='Up to 100 prompts';return}x.pr.push({id:uid(),n:n.slice(0,60),cat:c,b:b.slice(0,6000)})}
 save();closeSheet();sfx('ok');toast('Prompt saved');render()}
function promptDel(id){if(!confirm('Delete this prompt?'))return;X().pr=X().pr.filter(q=>q.id!==id);save();render()}
function promptRestore(){const x=X();let n=0;for(const p of PSTART)if(!x.pr.some(q=>q.id===p.id)){x.pr.push({id:p.id,n:p.n,cat:p.cat,b:p.b});n++}save();toast(n?n+' starter prompt'+(n>1?'s':'')+' restored':'All starter prompts are already present');render()}

// ===================== validator for the 2.2 ext fields (self-contained: runs during first load) =====================
function ext22(e,o){const id=v=>typeof v==='string'&&/^[\w-]{1,40}$/.test(v),st=(v,n)=>String(v==null?'':v).slice(0,n),dt=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\d$/.test(v),nu=(v,a,b,d)=>{v=+v;return isFinite(v)?Math.max(a,Math.min(b,v)):d},arr=v=>Array.isArray(v)?v:[];
 o.cl=arr(e.cl).filter(q=>q&&id(q.a)&&dt(q.d)&&['w','n','l','u'].includes(q.c)).slice(0,500).map(q=>({a:q.a,d:q.d,c:q.c}));
 o.wh=arr(e.wh).filter(w=>w&&id(w.id)&&Array.isArray(w.o)).slice(0,30).map(w=>({id:w.id,n:st(w.n,40)||'Untitled wheel',pal:['vivid','soft','ocean','ember','mono','theme'].includes(w.pal)?w.pal:'vivid',o:w.o.filter(q=>q&&id(q.id)&&String(q.t||'').trim()).slice(0,24).map(q=>({id:q.id,t:st(q.t,40)}))})).filter(w=>w.o.length>0);
 o.whSel=id(e.whSel)?e.whSel:'';o.ps=e.ps===0?0:1;
 const c=e.cn||{};o.cn={h:arr(c.h).filter(q=>q&&(q.t==='H'||q.t==='T')).slice(-200).map(q=>({t:q.t,at:nu(q.at,0,9e15,0)}))};
 const r=e.rn||{};o.rn={min:Math.round(nu(r.min,-1e9,1e9,1)),max:Math.round(nu(r.max,-1e9,1e9,100)),keep:r.keep?1:0,h:arr(r.h).map(Number).filter(isFinite).slice(-100)};if(o.rn.min>o.rn.max){o.rn.min=1;o.rn.max=100}
 const p=e.pk||{};o.pk={last:st(p.last,4000),list:arr(p.list).filter(s=>s&&id(s.id)&&Array.isArray(s.items)).slice(0,20).map(s=>({id:s.id,n:st(s.n,30),items:s.items.map(t=>st(t,60)).filter(Boolean).slice(0,60)}))};
 o.tp=arr(e.tp).filter(id).slice(0,100);o.tpInit=e.tpInit?1:0;
 o.fs=arr(e.fs).filter(s=>s&&id(s.id)&&dt(s.d)&&id(s.a)&&+s.min>0).slice(-1000).map(s=>({id:s.id,d:s.d,a:s.a,min:R(nu(s.min,0,1440,0)),at:nu(s.at,0,9e15,0)}));
 const f=e.fx||{};o.fx={on:f.on?1:0,a:id(f.a)?f.a:'',dur:Math.round(nu(f.dur,1,480,25)),acc:nu(f.acc,0,864e5,0),run:nu(f.run,0,9e15,0),pre:id(f.pre)?f.pre:'',dn:0,sg:arr(f.sg).slice(-200).filter(q=>Array.isArray(q)&&isFinite(+q[0])&&isFinite(+q[1])&&+q[1]>+q[0]).map(q=>[+q[0],+q[1]])};if(o.fx.on&&!o.fx.a)o.fx.on=0;
 o.pr=arr(e.pr).filter(q=>q&&id(q.id)&&String(q.n||'').trim()&&typeof q.b==='string').slice(0,100).map(q=>({id:q.id,n:st(q.n,60),cat:st(q.cat,24)||'General',b:st(q.b,6000)}));o.prSeed=e.prSeed?1:0;
 o.rm=['on','off'].includes(e.rm)?e.rm:'auto';o.mo=['full','lite','off'].includes(e.mo)?e.mo:'full'}

// ===================== glue: hooks into the existing app shell =====================
(function(){
 // Back button / hardware back: close a 2.2 sheet first
 const _back=back;back=function(){if(SHO){closeSheet();render();return true}return _back()};window.opuxBack=back;
 // reduced motion: OS preference unless the user overrides in Settings
 // (RM itself is patched at its definition)
 const _r=render;render=function(){SHO=0;if(V.v!=='ho'){atlasStop();ATL.lastView=V.v}_r();document.documentElement.dataset.rm=RM()?'1':'0';
  const A=$('#app');
  // Stats: link to the Productivity screen with a live summary
  if(V.v==='st'&&!$('#px-link')){const T=todayS(),c=dayCls(T),D=recDays(),b=pxBest(D).b,q=document.createElement('button');q.id='px-link';q.className='px-link';
   q.innerHTML='<span><small>PRODUCTIVITY</small><b>'+(b?'Best day '+hm(b.w)+' · '+fd(b.d):D.length?'Classify activities to unlock':'Start tracking to unlock')+'</b></span><span>'+(c.t?'Today '+c.pct+'%':'Open')+' ›</span>';q.onclick=()=>go('pr');
   const sum=$('#screen-summary');if(sum)sum.insertAdjacentElement('afterend',q);else A.prepend(q)}
  // Tracker / History day pages: productive breakdown
  if((V.v==='tr'||V.v==='hd')&&!$('#px-day')){const d=V.v==='tr'?V.d:V.h,c=dayCls(d);
   if(c.t>0){const q=document.createElement('div');q.id='px-day';q.className='cd';q.innerHTML='<div class="row"><h4>Productivity</h4><small onclick="go(\'pr\')" style="cursor:pointer">Details ›</small></div>'+stackBar(c)+'<small>'+c.pct+'% of tracked time was Productive Work. Unclassified time is not counted.</small>';
    const hs=[...A.querySelectorAll('h4')].find(h=>h.textContent.trim()===(V.v==='tr'?'Day summary':'Timeline'));const host=hs&&hs.closest('.cd');if(host)host.insertAdjacentElement(V.v==='tr'?'afterend':'beforebegin',q);else A.appendChild(q)}}
  // Home: productive share row in Today's progress
  if(V.v==='ho'){const T=todayS(),t=tot(T);const cds=[...A.querySelectorAll('.cd h4')].find(h=>/progress/i.test(h.textContent));
   if(cds&&!$('#px-home')&&t>0){const host=cds.closest('.cd'),r=document.createElement('div');r.id='px-home';r.className='li';r.style.cursor='pointer';r.onclick=()=>go('pr');r.innerHTML='<span>Productive share of tracked</span><b>'+dayCls(T).pct+'% ›</b>';host.appendChild(r)}
   atlasInit()}
  // Settings: motion, playground sound, classification pointer
  if(V.v==='se'&&!$('#px-settings')){const c=document.createElement('section');c.id='px-settings';c.className='cd';
   c.innerHTML='<div class="node-kicker">MOTION &amp; PLAY</div><h4>Animation</h4><label>Reduce motion</label><select onchange="X().rm=this.value;save();render()">'+[['auto','Follow device setting'],['on','Always reduce'],['off','Never reduce']].map(o=>'<option value="'+o[0]+'"'+(X().rm===o[0]?' selected':'')+'>'+o[1]+'</option>').join('')+'</select><small class="setting-copy">Reduced motion stills the Home atom (drag and tap still work), shortens flips and disables confetti.</small><div class="li" style="margin-top:8px"><span>Playground sounds</span><input type="checkbox" '+(plSnd()?'checked':'')+' onchange="X().ps=this.checked?1:0;save()"></div>';A.appendChild(c)}
 };
 // ---- afterRender: draw the wheel canvas when that view is shown
 const _ar=afterRender;afterRender=function(){_ar();if(V.v==='pw')wheelInit()};
 // quick actions panel additions
 const _qa=qaSP;qaSP=function(){openSP('l','Quick actions',()=>`<button class="mr" onclick="closeSP();V.d=ds(new Date());go('tr');openM(null)"><span>Add activity</span><span>›</span></button><button class="mr" onclick="closeSP();go('pf')"><span>Start a focus session</span><span>›</span></button><button class="mr" onclick="closeSP();go('pr')"><span>Productive time</span><span>›</span></button><button class="mr" onclick="closeSP();go('pl')"><span>Playground</span><span>›</span></button><button class="mr" onclick="closeSP();go('ai')"><span>Intelligence (ChatGPT prompts)</span><span>›</span></button><button class="mr" onclick="closeSP();go('br')"><span>New branch</span><span>›</span></button><button class="mr" onclick="closeSP();go('rd')"><span>New RDBD entry</span><span>›</span></button><button class="mr" onclick="closeSP();go('th')"><span>Change theme</span><span>›</span></button><button class="mr" onclick="closeSP();go('so')"><span>Sound settings</span><span>›</span></button>`)};
 // keep a running focus session discoverable
 setInterval(()=>{const f=X().fx;if(f.on&&V.v==='ho'&&!$('#fs-pill')&&$('#app')){const p=document.createElement('button');p.id='fs-pill';p.className='px-link';p.innerHTML='<span><small>FOCUS SESSION</small><b>'+esc(act(f.a).n)+' · '+clk(f.dur*60000-fsElapsed())+'</b></span><span>Open ›</span>';p.onclick=()=>go('pf');const h=$('.home-atlas');if(h)h.insertAdjacentElement('afterend',p)}
  const p=$('#fs-pill');if(p){if(!f.on||V.v!=='ho')p.remove();else p.querySelector('b').textContent=act(f.a).n+' · '+clk(Math.max(0,f.dur*60000-fsElapsed()))}},1000);
})();


// ===================================================================
// OPUX 2.3 — motion system, finger-following navigation, RDBD reading, colour picker, toasts
// (additive; h24v1 storage key and data model unchanged)
// ===================================================================
const MO3=()=>RM()?'off':((S.ext&&S.ext.mo)||'full');
function applyMo(){document.documentElement.dataset.mo=MO3()}
document.addEventListener('visibilitychange',()=>document.documentElement.classList.toggle('pg-paused',document.hidden));
// ---- toasts: friendly, contextual; URLs never shown; errors stay visible
toast=function(t,kind){t=String(t==null?'':t);if(/https?:\/\/\S+/i.test(t))t=/link|url/i.test(t)?'Link saved':'Changes saved';let e=$('#toast');
 if(!e){document.body.insertAdjacentHTML('beforeend','<div id="toast" role="status" aria-live="polite"></div>');e=$('#toast')}
 e.className='';e.innerHTML='<i class="ti"></i><span></span>';e.lastChild.textContent=t;
 e.dataset.k=kind||(/fail|not |cannot|can.t|only |error|enter |too large|limit|full|import failed/i.test(t)?'err':'ok');
 void e.offsetWidth;e.classList.add('on');clearTimeout(window._tt);window._tt=setTimeout(()=>e.classList.remove('on'),e.dataset.k==='err'?4800:2300)};
window.alert=function(m){toast(String(m),'err')};
let _nt=0;const nodeToast=m=>{clearTimeout(_nt);_nt=setTimeout(()=>toast(m),350)};
{const _ns=nodeSet;nodeSet=function(k,v,r){const had=selN()&&selN()[k];_ns(k,v,r);nodeToast(k==='url'?(v?'Link saved':'Link removed'):k==='img'?(v?'Image added':'Image removed'):k==='note'?'Note saved':'Node updated')}}
{const _ra=rmAtt;rmAtt=function(i){_ra(i);toast('File removed')};const _aa=addAtt;addAtt=function(){const n=selN()?selN().att.length:0;_aa();let c=0;const iv=setInterval(()=>{const m=selN();if(m&&m.att.length>n){clearInterval(iv);toast('File attached')}if(++c>60)clearInterval(iv)},500)}}
document.addEventListener('change',e=>{const t=e.target;if(t.closest&&t.closest('.act-row')&&!t.classList.contains('cls-sel')&&t.tagName==='INPUT'&&t.id!=='na')nodeToast('Activity updated')});
// ---- RDBD: dates on quotes, notes readable without Edit mode
{const _c=rdCard;rdCard=function(){let h=_c();const q=rdQ();if(q.length&&q[RDI]&&q[RDI].d)h=h.replace('<div class="dots"','<small class="quote-date">Written '+fd(q[RDI].d)+'</small><div class="dots"');return h}}
{const _v=vRd;vRd=function(){let h=_v();if(!RDM){const N=X().rd.e.filter(e=>e.k==='n').slice().reverse();
  const sec='<section class="rd-notes"><div class="row"><h3>Notes</h3><small>'+N.length+(N.length===1?' NOTE':' NOTES')+'</small></div>'+(N.length?N.map(e=>'<article class="rd-note'+(e.t.length<140&&e.t.split('\n').length<4?' short':'')+'" onclick="this.classList.toggle(\'open\')"><small class="quote-date" style="margin:0 0 4px">Written '+fd(e.d)+'</small><p>'+esc(e.t)+'</p>'+(e.a?'<small>— '+esc(e.a)+'</small>':'')+'<span class="more"></span></article>').join(''):'<small>No notes yet. Use Edit RDBD to write one; it will appear here with its date.</small>')+'</section>';
  h=h.replace('<div class="rdbd-view-note">',sec+'<div class="rdbd-view-note">')}return h}}
// ---- colour picker
const PAL=['#ef4444','#f97316','#f59e0b','#eab308','#84cc16','#22c55e','#10b981','#14b8a6','#06b6d4','#0ea5e9','#3b82f6','#6366f1','#8b5cf6','#a855f7','#d946ef','#ec4899','#f43f5e','#78716c','#6b7280','#cbd5e1','#fda4af','#fcd34d','#86efac','#93c5fd'];
let CP=null;window.NCOL=window.NCOL||'#14b8a6';
const lum=c=>{const n=parseInt(c.slice(1),16),f=v=>{v/=255;return v<=.03928?v/12.92:((v+.055)/1.055)**2.4};return .2126*f(n>>16)+.7152*f((n>>8)&255)+.0722*f(n&255)};
const ckCol=c=>lum(c)>.45?'#111':'#fff';
function cpHtml(){const cur=CP.c.toLowerCase(),isPal=PAL.includes(cur);
 return '<div class="row"><h3>Activity colour</h3><button class="x" onclick="cpClose()">✕</button></div><div class="cp-prev" style="--sw:'+cur+'"><i id="cp-prev"></i><small id="cp-hex">'+cur.toUpperCase()+'</small></div><div class="cp-grid">'+PAL.map(c=>'<button class="cp-sw'+(c===cur?' on':'')+'" style="--sw:'+c+';--ck:'+ckCol(c)+'" aria-label="'+c+'" onclick="cpSet(\''+c+'\')"></button>').join('')+'</div><div class="cp-custom"><input type="color" id="cp-in" value="'+cur+'" oninput="cpSet(this.value)"><small>Custom colour</small></div><button class="btn" onclick="cpSave()">Use this colour</button>'}
function openColorPick(i){const c=i<0?window.NCOL:S.acts[i].c;CP={i,c};openSheet(cpHtml())}
function cpSet(c){if(!/^#[0-9a-f]{6}$/i.test(c))return;c=c.toLowerCase();CP.c=c;document.querySelectorAll('.cp-sw').forEach(b=>b.classList.toggle('on',b.getAttribute('aria-label')===c));const p=$('#cp-prev');if(p)p.parentElement.style.setProperty('--sw',c);const x=$('#cp-hex');if(x)x.textContent=c.toUpperCase();const k=$('#cp-in');if(k&&k.value!==c)k.value=c;hp&&hp()}
function cpClose(){CP=null;closeSheet()}
function cpSave(){if(!CP)return;const c=CP.c;if(CP.i<0)window.NCOL=c;else{S.acts[CP.i].c=c;save()}CP=null;closeSheet();render();toast(window.NCOL&&c?'Colour saved':'Colour saved')}
// ---- finger-following swipe navigation
const PG={on:0,lock:0,sup:0};
(function(){
 const EX='canvas,svg,input,textarea,select,.bars,.sheet,#sp,#md,#rcq,.dp,.no-swipe,[contenteditable],#nav,#fab,.rd-note.open';
 const hScroll=el=>{for(;el&&el!==document.body;el=el.parentElement){const s=getComputedStyle(el);if((s.overflowX==='auto'||s.overflowX==='scroll')&&el.scrollWidth>el.clientWidth+2)return true}return false};
 const destFor=dx=>{const i=PRI.indexOf(V.v);if(i>=0){const j=i+(dx<0?1:-1);return j>=0&&j<PRI.length?{kind:'tab',view:PRI[j]}:null}
  if(dx<=0||(V.v==='bw'&&BW.mode==='edit'))return null;return{kind:'back',view:NS.length?NS[NS.length-1]:'ho'}};
 const peekExtras=(view,html)=>{
  // Mirror the post-render injections so the preview has the same blocks, in the same order, as the real page.
  const t=document.createElement('template');t.innerHTML=html;const R=t.content;
  if(view==='ho'){const hero=R.querySelector('.home-atlas'),card=document.createElement('section');card.className='checkin-card';card.innerHTML=checkinCardInner();if(hero)hero.insertAdjacentElement('afterend',card);else R.appendChild(card);
   const T=todayS(),m=tot(T),hd=[...R.querySelectorAll('.cd h4')].find(x=>/progress/i.test(x.textContent));
   if(hd&&m>0){const r=document.createElement('div');r.className='li';r.innerHTML='<span>Productive share of tracked</span><b>'+dayCls(T).pct+'% ›</b>';hd.closest('.cd').appendChild(r)}}
  if(view==='tr'||view==='hd'){const d=view==='tr'?V.d:V.h,c=dayCls(d);
   if(c.t>0){const q=document.createElement('div');q.className='cd';q.innerHTML='<div class="row"><h4>Productivity</h4><small>Details ›</small></div>'+stackBar(c)+'<small>'+c.pct+'% of tracked time was Productive Work. Unclassified time is not counted.</small>';
    const hs=[...R.querySelectorAll('h4')].find(x=>x.textContent.trim()===(view==='tr'?'Day summary':'Timeline')),host=hs&&hs.closest('.cd');if(host)host.insertAdjacentElement(view==='tr'?'afterend':'beforebegin',q);else R.appendChild(q)}}
  if(view==='tr'){const bc=R.querySelector('#bc');if(bc)bc.setAttribute('data-pk-board','1')}
  if(view==='tr'&&!M){const board=R.querySelector('.bw');if(board){const b=document.createElement('button');b.className='btn ol';b.style.cssText='width:100%;margin:10px 0 4px';b.textContent='＋ Add hours / minutes';board.insertAdjacentElement('afterend',b)}}
  return t.innerHTML};
 const peekHtml=view=>{const sv=V.v;let h='';try{V.v=view;const f={ho:vHo,tr:vTr,st:vSt,hi:vHi,hd:vHd,rc:vRc,mo:vMo,se:vSe,br:vBr,bw:vBw,rd:vRd,so:vSo,th:vTh,...VX}[view];h=f?f():'';try{h=peekExtras(view,h)}catch(e){}}catch(e){h=''}finally{V.v=sv}
  // Keep the swipe preview structurally identical to the real destination.
  // These elements are normally injected by the post-render wrapper, so a
  // preview made from the page function alone used to omit them until release.
  const intros={tr:['TIME LEDGER','A clearer account of today.'],st:['PATTERNS & SIGNAL','Read the shape of your time.'],hi:['YOUR RECORD','Move through days, not just totals.'],rc:['PERSONAL MILESTONES','Records calculated from what you logged.'],so:['SOUND ENVIRONMENT','Small details, tuned to your space.'],th:['VISUAL ATMOSPHERE','Choose how OPUX feels.'],se:['SYSTEM PREFERENCES','Make the experience work your way.']};
  let prefix='';if(intros[view])prefix+=`<div class="screen-intro"><span>${intros[view][0]}</span><p>${intros[view][1]}</p></div>`;
  if(['st','hi','rc'].includes(view)){const days=Object.keys(S.days).filter(d=>tot(d)>0).sort(),all=days.reduce((n,d)=>n+tot(d),0),today=ds(new Date()),week=Array.from({length:7},(_,i)=>add(today,-i)).reduce((n,d)=>n+tot(d),0);let cells=[];if(view==='st')cells=[['TODAY',fmt(tot(today))],['LAST 7 DAYS',fmt(week)],['ALL RECORDED',fmt(all)]];else if(view==='hi')cells=[['RECORDED DAYS',String(days.length)],['TOTAL TIME',fmt(all)],['LATEST ENTRY',days.length?fd(days[days.length-1]):'—']];else{const records=recList();cells=[['CALCULATED RECORDS',String(records.length)],['MANUAL MILESTONES',String(X().ms.length)],['RECORDED DAYS',String(days.length)]]}prefix+=`<section class="screen-summary">${cells.map(([a,b])=>`<div><small>${a}</small><b>${b}</b></div>`).join('')}</section>`}
  // The real Stats render adds this live productivity shortcut in the render
  // wrapper. Include the same block in the swipe preview so it cannot vanish
  // during the gesture and pop back only after the destination is committed.
  if(view==='st'){const T=todayS(),c=dayCls(T),D=recDays(),b=pxBest(D).b;prefix+=`<button class="px-link" tabindex="-1" aria-hidden="true"><span><small>PRODUCTIVITY</small><b>${b?'Best day '+hm(b.w)+' · '+fd(b.d):D.length?'Classify activities to unlock':'Start tracking to unlock'}</b></span><span>${c.t?'Today '+c.pct+'%':'Open'} ›</span></button>`}
  return (prefix+h).replace(/\sid="[^"]*"/g,'')};
 let A,peek,W,dx,samples,tx0,ty0;
 const navTo=v=>{const n=$('#nav');if(!n||NAVV===v)return;NAVV=v;n.querySelectorAll('button').forEach(b=>b.classList.toggle('on',b.dataset.v===v))};
 const navRest=()=>{const pt=PRI.includes(V.v)?V.v:(NS[0]||PAR[V.v]);navTo(pt)};
 let NAVV=null;
 const setX=x=>{const p=Math.min(1,Math.abs(x)/W);A.style.transform='translate3d('+x+'px,0,0)';A.style.opacity=1-p*.22;
  // Keep the bottom-bar highlight in step with the page that will be shown, instead of lagging until release.
  if(PG.d&&PG.d.kind==='tab'){if(p>=.5)navTo(PG.d.view);else navRest()}
  if(PG.d&&peek){if(PG.d.kind==='tab')peek.style.transform='translate3d('+(x+(x<0?W:-W))+'px,0,0)';else{peek.style.transform='translate3d('+(-W*.28*(1-p))+'px,0,0)';peek.style.opacity=.55+.45*p}}};
 const clear=()=>{if(peek){peek.remove();peek=null}if(A){A.style.cssText='';A.classList.remove('pg-top','pg-cover')}PG.on=0;PG.lock=0;PG.d=null;NAVV=null;navRest()};
 function finish(done){
  const d=PG.d;
  if(done&&d){
   // Render the destination while the outgoing panel is still translated.
   // Removing the peek first exposed the old page for a frame and made the
   // destination's injected header/summary appear to reset after the swipe.
   PG.sup=1;
   if(d.kind==='tab')tab(d.view);else back();
  }
  clear();
 }
 function release(cancel){if(!PG.lock){PG.on=0;return}const n=samples.length,a=samples[Math.max(0,n-5)],z=samples[n-1],v=z.t>a.t?(z.x-a.x)/(z.t-a.t):0;
  const ok=!cancel&&PG.d&&(Math.abs(dx)>W*.4||(Math.abs(v)>.45&&Math.sign(v)===Math.sign(dx)&&Math.abs(dx)>W*.05));
  const tgt=ok?Math.sign(dx)*W:0,dist=Math.abs(tgt-dx),dur=MO3()==='off'?0:Math.max(160,Math.min(380,120+dist*.5));
  const t=dur?'transform '+dur+'ms cubic-bezier(.22,1,.36,1),opacity '+dur+'ms ease-out':'none';A.style.transition=t;if(peek)peek.style.transition=t;
  setX(tgt);
  // Only finish after the app panel itself completes its horizontal slide.
  // Listening to any transitionend (especially opacity) can clear the
  // transform early, making the page snap/reset before the swipe settles.
  let fin=0;
  const go2=()=>{if(fin)return;fin=1;A.removeEventListener('transitionend',onEnd);clearTimeout(fallback);finish(ok)};
  const onEnd=e=>{if(e.target===A&&e.propertyName==='transform')go2()};
  A.addEventListener('transitionend',onEnd);
  const fallback=setTimeout(go2,dur+140);
 }
 document.addEventListener('touchstart',e=>{if(PG.lock&&PG.on){return}PG.on=0;if(e.touches.length!==1||M||SP||SHO||window.CI||$('#md.show'))return;
  const t=e.target;if(!t.closest||t.closest(EX)||hScroll(t))return;const ae=document.activeElement;if(ae&&/INPUT|TEXTAREA|SELECT/.test(ae.tagName))return;
  A=$('#app');tx0=e.touches[0].clientX;ty0=e.touches[0].clientY;samples=[{t:performance.now(),x:0}];PG.on=1;PG.lock=0;dx=0},{passive:true});
 document.addEventListener('touchmove',e=>{if(!PG.on)return;if(e.touches.length!==1){if(PG.lock)release(true);else PG.on=0;return}
  const t=e.touches[0],rx=t.clientX-tx0,ry=t.clientY-ty0;
  if(!PG.lock){const ax=Math.abs(rx),ay=Math.abs(ry);if(ay>12&&ay>ax){PG.on=0;return}if(!(ax>10&&ax>ay*1.4))return;
   const d=destFor(rx);if(!d&&PRI.indexOf(V.v)<0){PG.on=0;return}PG.d=d;PG.lock=1;W=document.documentElement.clientWidth;
   if(d){const r=A.getBoundingClientRect();peek=document.createElement('div');peek.id='pg-peek';peek.setAttribute('aria-hidden','true');peek.style.left=r.left+'px';peek.style.width=r.width+'px';peek.innerHTML='<div class="pg-in">'+peekHtml(d.view)+'</div>';document.body.appendChild(peek);peek.querySelectorAll('[data-pk-board]').forEach(c=>{const w=c.parentElement.clientWidth;c.style.display='block';c.style.width=w+'px';c.style.height=(w/6*8)+'px'});if(d.kind==='back'){peek.classList.add('pk-back');peek.style.transform='translate3d('+(-W*.28)+'px,0,0)'}}
   A.classList.add('pg-top');if(d&&d.kind==='back')A.classList.add('pg-cover');NAVV=null;A.style.transition='none'}
  e.preventDefault();dx=PG.d?rx:rx*.28;samples.push({t:performance.now(),x:rx});if(samples.length>12)samples.shift();setX(dx)},{passive:false});
 document.addEventListener('touchend',()=>{if(PG.on)release(false)},{passive:true});
 document.addEventListener('touchcancel',()=>{if(PG.on)release(true)},{passive:true});
 window.addEventListener('blur',()=>{if(PG.lock)release(true)});
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&PG.lock)clear()});
})();
// ---- render hook: swipe hand-off, date-switch direction, ambient layers, branch entrance
let L3={v:null,d:null,h:null};
{const _r=render;render=function(){if(PG.sup){PG.sup=0;DIR=0}else if(!DIR&&L3.v===V.v){if(V.v==='tr'&&L3.d&&V.d!==L3.d)DIR=V.d>L3.d?1:-1;else if(V.v==='hd'&&L3.h&&V.h!==L3.h)DIR=V.h>L3.h?1:-1}
 const prev=L3.v;_r();L3={v:V.v,d:V.d,h:V.h};applyMo();
 let fx=$('#home-fx');if(V.v==='ho'&&MO3()==='full'){if(!fx){fx=document.createElement('div');fx.id='home-fx';fx.setAttribute('aria-hidden','true');fx.innerHTML=Array.from({length:14},()=>'<i style="left:'+(Math.random()*100).toFixed(1)+'%;--s:'+(2+Math.random()*3).toFixed(1)+'px;--du:'+(14+Math.random()*14).toFixed(1)+'s;--dl:-'+(Math.random()*20).toFixed(1)+'s;--dx:'+((Math.random()-.5)*80).toFixed(0)+'px"></i>').join('');document.body.appendChild(fx)}}else if(fx)fx.remove();
 if(V.v==='bw'&&prev!=='bw'&&MO3()!=='off'){const s=$('.branch-stage');if(s)s.classList.add('stage-in')}
 if(V.v==='se'&&!$('#motion-settings')){const c=document.createElement('section');c.id='motion-settings';c.className='cd';c.innerHTML='<div class="node-kicker">MOTION</div><h4>Animation intensity</h4><p class="setting-copy">Full adds ambient motion (floating particles, breathing Branch nodes, flowing connections). Balanced keeps only interaction feedback. Off removes animation. Android\'s reduced-motion setting is always respected.</p><select onchange="setMo(this.value)">'+[['full','Full'],['lite','Balanced'],['off','Off']].map(o=>'<option value="'+o[0]+'"'+((X().mo||'full')===o[0]?' selected':'')+'>'+o[1]+'</option>').join('')+'</select>';$('#app').appendChild(c)}}}
function setMo(v){X().mo=['full','lite','off'].includes(v)?v:'full';save();applyMo();render();toast('Animation: '+({full:'Full',lite:'Balanced',off:'Off'}[X().mo]))}
// ---- widget rearrangement (FLIP)
{const _mw=moveW;moveW=function(k,d){const A=$('#app'),f=new Map();[...A.children].forEach(el=>f.set(el.textContent.slice(0,40),el.getBoundingClientRect().top));_mw(k,d);
 if(MO3()==='off')return;[...$('#app').children].forEach(el=>{const t=f.get(el.textContent.slice(0,40));if(t==null)return;const dy=t-el.getBoundingClientRect().top;if(Math.abs(dy)>2)el.animate([{transform:'translateY('+dy+'px)'},{transform:'none'}],{duration:400,easing:'cubic-bezier(.22,1,.36,1)'})})}}
// ---- Branch: living network
{const _d=drawBW;drawBW=function(){_d();branchFx()}}
function branchFx(){const b=curB(),g=$('#bg');if(!b||!g)return;const mo=document.documentElement.dataset.mo,t=performance.now(),VS=vis(b),id={};VS.forEach(n=>id[n.id]=n);
 const edges=[];VS.forEach(n=>{const p=n.p&&id[n.p];if(p)edges.push([p.id,n.id])});b.links.forEach(l=>{if(id[l[0]]&&id[l[1]])edges.push([l[0],l[1]])});
 const paths=[...g.querySelectorAll('path.ed')],sel=BW.sel,nb=new Set();
 paths.forEach((p,i)=>{const e=edges[i];if(e&&sel&&(e[0]===sel||e[1]===sel)){p.classList.add('hot');nb.add(e[0]===sel?e[1]:e[0])}});
 g.classList.toggle('has-sel',!!sel);
 g.querySelectorAll('g[data-id]').forEach((el,i)=>{const c=el.firstElementChild,n=el.dataset.id;if(!c)return;if(nb.has(n))c.classList.add('nb');if(BW.dragId===n)c.classList.add('dg');if(BW.pop===n)c.classList.add('pop');
  if(mo==='full'){c.classList.add('br');c.style.animationDelay=(-(((t/1000)+i*.7)%5.5))+'s'}});
 if(mo==='full'&&paths.length<=90)paths.forEach(p=>{if(p.classList.contains('lk'))return;const c=p.cloneNode();c.setAttribute('class','fl');c.removeAttribute('pathLength');c.style.animationDelay=(-(t%1600)/1000)+'s';p.after(c)})}
{const _s=selNode;selNode=function(id){BW.pop=id;clearTimeout(BW._pt);BW._pt=setTimeout(()=>{BW.pop=null},450);if(typeof hp==='function')hp();_s(id)}}
document.addEventListener('pointerdown',e=>{const n=e.target.closest&&e.target.closest('#bs [data-id]');BW._dn=n?{id:n.dataset.id,x:e.clientX,y:e.clientY}:null},true);
document.addEventListener('pointermove',e=>{const d=BW._dn;if(d&&!BW.dragId&&Math.hypot(e.clientX-d.x,e.clientY-d.y)>6)BW.dragId=d.id},true);
const _bwUp=()=>{if(BW._dn||BW.dragId){BW._dn=null;BW.dragId=null;if(V.v==='bw'&&$('#bg'))drawBW()}};document.addEventListener('pointerup',_bwUp,true);document.addEventListener('pointercancel',_bwUp,true);
function smoothFit(){const a={x:BW.tx,y:BW.ty,k:BW.k};fitBW();const z={x:BW.tx,y:BW.ty,k:BW.k};if(MO3()==='off'){drawBW();return}const t0=performance.now();(function f(){const u=Math.min(1,(performance.now()-t0)/450),e=1-(1-u)**3;BW.tx=a.x+(z.x-a.x)*e;BW.ty=a.y+(z.y-a.y)*e;BW.k=a.k+(z.k-a.k)*e;const g=$('#bg');if(g)g.setAttribute('transform','translate('+BW.tx+' '+BW.ty+') scale('+BW.k+')');if(u<1&&V.v==='bw')requestAnimationFrame(f)})()}
applyMo();

render();
