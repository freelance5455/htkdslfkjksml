



const ROOM='nash-svit-kotusyk-kvitka';
const NAMES={he:'Котусик',she:'Квіточка'};
const EMOJI={he:'🐱',she:'🌸'};
let db=null;
try{
  if(typeof firebase!=='undefined'){
    firebase.initializeApp({apiKey:'AIzaSyA03kNmOlF4ys0cVEAfbVFe60tqXyp-4AI',authDomain:'our-universe-96cb1.firebaseapp.com',databaseURL:'https://our-universe-96cb1-default-rtdb.firebaseio.com',projectId:'our-universe-96cb1',storageBucket:'our-universe-96cb1.firebasestorage.app',messagingSenderId:'979090394458',appId:'1:979090394458:web:a07a2f46ba6c9d8bfdb763',measurementId:'G-RRQCLTH909'});
    db=firebase.database();
    try{db.goOnline()}catch(e){}
  }
}catch(e){console.log(e)}

const $=id=>document.getElementById(id);

(function(){
  const _ge = document.getElementById.bind(document);
  const noop = function(){ return null; };
  const dummy = {
    style: {},
    classList: { add:noop, remove:noop, toggle:noop, contains:function(){return false} },
    onclick: null, onchange: null, oninput: null, onkeydown: null,
    addEventListener: noop, removeEventListener: noop, appendChild: noop, remove: noop,
    focus: noop, click: noop, blur: noop,
    querySelectorAll: function(){ return []; },
    querySelector: function(){ return null; },
    closest: function(){ return null; },
    dataset: {},
    parentNode: null,
    value: '',
    innerHTML: '',
    textContent: '',
    src: '',
    checked: false,
    disabled: false,
    length: 0,
    setAttribute: noop, getAttribute: function(){ return null; },
    removeAttribute: noop,
    scrollIntoView: noop,
    getBoundingClientRect: function(){ return {top:0,left:0,width:0,height:0}; }
  };
  // allow setting textContent/innerHTML/value on dummy without throw
  Object.defineProperty(dummy, 'textContent', { get(){return '';}, set(){}, configurable:true });
  Object.defineProperty(dummy, 'innerHTML', { get(){return '';}, set(){}, configurable:true });
  Object.defineProperty(dummy, 'value', { get(){return '';}, set(){}, configurable:true });
  document.getElementById = function(id){
    return _ge(id) || dummy;
  };
})();

const MOODS=[
  {e:'❤️',t:'Кохаю'},{e:'🥰',t:'Щасливий/а'},{e:'😘',t:'Сумую'},{e:'😔',t:'Сумно'},
  {e:'🤗',t:'Хочу обійняти'},{e:'😴',t:'Сплю'},{e:'☕',t:'Спокійно'},{e:'😡',t:'Злюся'},
  {e:'🌸',t:'Квіточка: ніжна й закохана'},{e:'🌷',t:'Квіточка: хочу тепла'},{e:'🐱',t:'Котусик: мур-мур, кохаю'},{e:'🐾',t:'Котусик: хочу до тебе'}
];

function nearMsg(role){return role==='he'?'Я поруч моя квіточка ♥️':'Я поруч мій котусику ♥️'}
function sigText(kind,role){
  const n=NAMES[role];
  return ({
    love:n+' сказав(ла): Кохаю ❤️',
    miss:n+' сказав(ла): Сумую 😘',
    near:nearMsg(role),
    hug:n+' надіслав(ла) обійми 🫶',
    kiss:n+' цілує тебе 💋',
    morning:n+' бажає доброго ранку ☀️❤️',
    night:n+' лягає спати 🌙 Надобраніч'
  })[kind]||n+' щось надіслав(ла)';
}

let S={
  role:localStorage.getItem('ns_role_v2')||localStorage.getItem('ns_role')||'',
  startDate:new Date('2025-06-22T00:00:00').getTime(),
  meetAt:null,
  meetMsg:'Я дуже тебе чекаю ❤️',
  partnerMood:null,moodHe:null,moodShe:null,
  photos:{he:'',she:''},
  lastLocal:0,
  lastSaid:{he:'',she:''},
  calY:new Date().getFullYear(),
  calM:new Date().getMonth(),
  selectedDay:null,
  lbZoom:1,
  lbId:null,
  seenEventTs:Number(localStorage.getItem('ns_seen_ev')||0),
  appBg:localStorage.getItem('ns_app_bg')||'',
  chatBg:localStorage.getItem('ns_chat_bg')||'',
  appPhoto:localStorage.getItem('ns_app_photo')||'',
  palette:localStorage.getItem('ns_palette')||'pink',
  swipeNav:localStorage.getItem('ns_swipe_nav')!=='0',
  notifications:{chat:localStorage.getItem('ns_notif_chat')!=='0',signal:localStorage.getItem('ns_notif_signal')!=='0',mood:localStorage.getItem('ns_notif_mood')!=='0',gallery:localStorage.getItem('ns_notif_gallery')!=='0'}, unreadChat:Number(localStorage.getItem('ns_unread_chat')||0), appVersion:'4.1.0'
};

function toast(m,ms=2500){const t=$('toast');if(!t)return;t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),ms)}
async function notifyPhone(title,body){
  try{if(typeof Notification==='undefined')return false;if(Notification.permission==='default')return false;if(Notification.permission==='granted'){new Notification(title,{body,icon:S.appPhoto||S.appBg||'app_bg.jpg',tag:'nash-universe'});return true}}catch(e){}return false;
}
function showBanner(title,body){
  const b=$('banner');
  $('banner-title').textContent=title;
  $('banner-body').textContent=body;
  b.classList.add('show');
  try{navigator.vibrate&&navigator.vibrate([180,60,180])}catch(e){}
  try{
    if(typeof Notification!=='undefined'&&Notification.permission==='granted'){
      notifyPhone(title,body);
    }
  }catch(e){}
  setTimeout(()=>b.classList.remove('show'),4500);
}
function show(id){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('on'));$(id).classList.add('on')}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function R(p){return db.ref('worlds/'+ROOM+'/'+p)}
function other(){return S.role==='he'?'she':'he'}
function myName(){return NAMES[S.role]}

function applyPalette(name){
  const palettes={
    pink:{p:'#ec4899',p2:'#f472b6',d:'#0f172a',muted:'#64748b',card:'rgba(255,255,255,.92)'},
    blue:{p:'#3b82f6',p2:'#60a5fa',d:'#0f172a',muted:'#64748b',card:'rgba(255,255,255,.92)'},
    purple:{p:'#8b5cf6',p2:'#a78bfa',d:'#17122b',muted:'#6b6680',card:'rgba(255,255,255,.93)'},
    red:{p:'#ef4444',p2:'#fb7185',d:'#1f1720',muted:'#6b6268',card:'rgba(255,255,255,.93)'},
    green:{p:'#10b981',p2:'#34d399',d:'#10231d',muted:'#5f756d',card:'rgba(255,255,255,.93)'},
    dark:{p:'#f472b6',p2:'#fb7185',d:'#f8fafc',muted:'#cbd5e1',card:'rgba(15,23,42,.88)'}
  };
  const v=palettes[name]||palettes.pink; const root=document.documentElement;
  Object.entries(v).forEach(([k,val])=>root.style.setProperty('--'+k,val));
  if(name==='dark'){document.body.style.color='#f8fafc'}else{document.body.style.color='';}
  S.palette=name;localStorage.setItem('ns_palette',name);
  document.querySelectorAll('.palette').forEach(b=>b.classList.toggle('active',b.dataset.palette===name));
}
function setAppBackground(data){
  S.appBg=data||''; if(data){localStorage.setItem('ns_app_bg',data)}else localStorage.removeItem('ns_app_bg');
  document.body.style.backgroundImage=`url("${data||'app_bg.jpg'}")`;
  const p=$('app-bg-preview'); if(p)p.style.backgroundImage=`url("${data||'app_bg.jpg'}")`;
}

function setChatBackground(){
  S.chatBg='';
  try{localStorage.removeItem('ns_chat_bg')}catch(e){}
  const tab=document.getElementById('tab-chat');
  if(tab){tab.style.backgroundImage='none';tab.style.background='transparent';}
  const img=document.getElementById('chat-bg-img');
  if(img)img.style.display='none';
}


function setAppPhoto(data){
  S.appPhoto=data||''; if(data){localStorage.setItem('ns_app_photo',data)}else localStorage.removeItem('ns_app_photo');
  const src=data||S.appBg||'app_bg.jpg';
  ['welcome-app-photo','home-app-photo'].forEach(id=>{const el=$(id);if(el)el.src=src});
}
function refreshSettingsUI(){
  setAppBackground(S.appBg);setChatBackground();setAppPhoto(S.appPhoto);applyPalette(S.palette);
  const ids=['chat','signal','mood','gallery'];ids.forEach(k=>{const el=$('notif-'+k);if(el)el.checked=!!S.notifications[k]});
  if($('swipe-nav'))$('swipe-nav').checked=S.swipeNav;
  if($('settings-role'))$('settings-role').textContent=myName()+' '+EMOJI[S.role];
  const pr=$('settings-profile-preview'); if(pr){const data=S.photos[S.role];pr.innerHTML=data?`<img src="${data}" alt="">`:EMOJI[S.role]}
}
function bindAppearanceSettings(){
  $('btn-app-bg').onclick=()=>$('app-bg-input').click();
  $('app-bg-input').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{setAppBackground(await compress(f,1100,.72));toast('Фон застосунку змінено ❤️')}catch(err){toast('Не вдалося змінити фон')}e.target.value=''};
  $('btn-app-photo').onclick=()=>$('app-photo-input').click();
  $('app-photo-input').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{setAppPhoto(await compress(f,700,.72));toast('Фото застосунку змінено ❤️')}catch(err){toast('Не вдалося змінити фото')}e.target.value=''};
  $('btn-setting-profile').onclick=()=>$('settings-profile-input').click();
  $('settings-profile-input').onchange=async e=>{const f=e.target.files[0];if(!f||!db)return;try{const data=await compress(f,500,.72);S.photos[S.role]=data;setAv(S.role,data);await R('users/'+S.role+'/photo').set(data);refreshSettingsUI();toast('Фото профілю оновлено ❤️')}catch(err){toast('Помилка фото')}e.target.value=''};
  document.querySelectorAll('.palette').forEach(b=>b.onclick=()=>{applyPalette(b.dataset.palette);toast('Палітру змінено')});
  $('btn-reset-look').onclick=()=>{setAppBackground('');setChatBackground('');setAppPhoto('');applyPalette('pink');toast('Оформлення скинуто')};
  ['chat','signal','mood','gallery'].forEach(k=>{const el=$('notif-'+k);if(el)el.onchange=()=>{S.notifications[k]=el.checked;localStorage.setItem('ns_notif_'+k,el.checked?'1':'0')}});
  $('btn-enable-notifications').onclick=async()=>{try{if(typeof Notification==='undefined'){toast('Цей браузер не підтримує системні сповіщення');return}const p=await Notification.requestPermission();toast(p==='granted'?'Сповіщення увімкнено 🔔':'Сповіщення не дозволені')}catch(e){toast('Не вдалося увімкнути сповіщення')}};
  $('swipe-nav').onchange=()=>{S.swipeNav=$('swipe-nav').checked;localStorage.setItem('ns_swipe_nav',S.swipeNav?'1':'0')};
}

function compress(file,maxW=700,q=0.68){
  return new Promise((res,rej)=>{
    const r=new FileReader();
    r.onload=e=>{
      const img=new Image();
      img.onload=()=>{
        let w=img.width,h=img.height;if(w>maxW){h=Math.round(h*maxW/w);w=maxW}
        const c=document.createElement('canvas');c.width=w;c.height=h;
        c.getContext('2d').drawImage(img,0,0,w,h);
        res(c.toDataURL('image/jpeg',q));
      };
      img.onerror=rej;img.src=e.target.result;
    };
    r.onerror=rej;r.readAsDataURL(file);
  });
}

function tickHappy(){
  if(!S.startDate)return;
  const diff=Math.max(0,Date.now()-S.startDate);
  const days=Math.floor(diff/86400000);
  const h=Math.floor(diff%86400000/3600000);
  const m=Math.floor(diff%3600000/60000);
  const s=Math.floor(diff%60000/1000);
  if($('happy-days'))$('happy-days').textContent=days+' днів';
  if($('happy-live'))$('happy-live').textContent=h+' год · '+m+' хв · '+s+' сек';
  const now=new Date(),st=new Date(S.startDate);
  let y=now.getFullYear()-st.getFullYear(),mo=now.getMonth()-st.getMonth(),d=now.getDate()-st.getDate();
  if(d<0){mo--;d+=new Date(now.getFullYear(),now.getMonth(),0).getDate()}
  if(mo<0){y--;mo+=12}
  if($('rel-y')){$('rel-y').textContent=y;$('rel-m').textContent=mo;$('rel-d').textContent=d}
  if($('rel-live'))$('rel-live').textContent=days+' днів · '+(days*24+h)+' год · '+m+' хв · '+s+' сек';
}

function tickMeet(){
  const ids1=['cd-d','cd-h','cd-m','cd-s'],ids2=['cd2-d','cd2-h','cd2-m','cd2-s'];
  if(!S.meetAt){
    [...ids1,...ids2].forEach(id=>{const el=$(id);if(el)el.textContent='—'});
    if($('meet-block'))$('meet-block').classList.remove('hidden');
    if($('meet-done'))$('meet-done').classList.add('hidden');
    if($('meet-arrived2'))$('meet-arrived2').classList.add('hidden');
    return;
  }
  const diff=S.meetAt-Date.now();
  if(diff<=0){
    [...ids1,...ids2].forEach(id=>{const el=$(id);if(el)el.textContent='0'});
    if($('meet-block'))$('meet-block').classList.add('hidden');
    if($('meet-done'))$('meet-done').classList.remove('hidden');
    if($('meet-arrived2'))$('meet-arrived2').classList.remove('hidden');
    return;
  }
  if($('meet-block'))$('meet-block').classList.remove('hidden');
  if($('meet-done'))$('meet-done').classList.add('hidden');
  if($('meet-arrived2'))$('meet-arrived2').classList.add('hidden');
  const v=[Math.floor(diff/86400000),Math.floor(diff%86400000/3600000),Math.floor(diff%3600000/60000),Math.floor(diff%60000/1000)];
  ids1.forEach((id,i)=>{const el=$(id);if(el)el.textContent=v[i]});
  ids2.forEach((id,i)=>{const el=$(id);if(el)el.textContent=v[i]});
}

function setAv(role,dataUrl){
  const el=$(role==='he'?'av-he':'av-she');
  if(!el)return;
  if(dataUrl)el.innerHTML='<img src="'+dataUrl+'" alt="">';
  else el.textContent=EMOJI[role];
}

function renderMoods(){
  const he=S.moodHe, she=S.moodShe;
  if($('mood-he-display'))$('mood-he-display').textContent=he?((he.e||'')+' '+(he.t||'')):'—';
  if($('mood-she-display'))$('mood-she-display').textContent=she?((she.e||'')+' '+(she.t||'')):'—';
  if($('mood-he-time')&&he&&he.ts)$('mood-he-time').textContent=new Date(he.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'});
  if($('mood-she-time')&&she&&she.ts)$('mood-she-time').textContent=new Date(she.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'});
}
function renderHome(){
  if($('partner-label'))$('partner-label').textContent=NAMES[other()];
  if($('chat-unread')){$('chat-unread').textContent=S.unreadChat; $('chat-unread').classList.toggle('on',S.unreadChat>0)}
  if($('chat-title'))$('chat-title').textContent='❤️ '+NAMES[other()];
  if($('settings-role'))$('settings-role').textContent=myName()+' '+EMOJI[S.role];
  if($('edit-he'))$('edit-he').style.display=S.role==='he'?'block':'none';
  if($('edit-she'))$('edit-she').style.display=S.role==='she'?'block':'none';
  setAv('he',S.photos.he);setAv('she',S.photos.she);
  const spr=$('settings-profile-preview');if(spr&&S.role){spr.innerHTML=S.photos[S.role]?`<img src="${S.photos[S.role]}" alt="">`:EMOJI[S.role]}
  setAppPhoto(S.appPhoto);
  if(S.partnerMood){
    if($('partner-mood-display'))$('partner-mood-display').textContent=(S.partnerMood.e||'')+' '+(S.partnerMood.t||''); renderMoods();
    if(S.partnerMood.ts&&$('partner-mood-time'))$('partner-mood-time').textContent='Оновлено '+new Date(S.partnerMood.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'});
  }
  if($('meet-msg'))$('meet-msg').textContent=S.meetMsg||'Я дуже тебе чекаю ❤️';
  if($('said-he'))$('said-he').textContent=S.lastSaid.he||'ще нічого…';
  if($('said-she'))$('said-she').textContent=S.lastSaid.she||'ще нічого…';
  tickHappy();tickMeet();
}

function hideTabs(){
  ['home','chat','notes','gallery','feed','we','calendar','movies','dock','features'].forEach(t=>{
    const el=$('tab-'+t);if(!el)return;el.classList.add('hidden');el.style.display='none';
  });
  document.querySelectorAll('[id^="sub-"]').forEach(el=>{el.classList.add('hidden');el.style.display='none'});
}
function openTab(n){
  hideTabs();
  const el=$('tab-'+n);
  if(el){
    el.classList.remove('hidden');
    el.style.display=n==='chat'?'flex':'block';
  }
  document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===n));
  document.body.classList.toggle('on-chat-tab', n==='chat');
  if(n==='chat' && S.chatBg) setChatBackground();
  if(n==='chat'){S.unreadChat=0;localStorage.setItem('ns_unread_chat','0');const latest=localStorage.getItem('ns_last_chat_ts');if(latest)localStorage.setItem('ns_last_read_chat',latest);if($('chat-unread'))$('chat-unread').classList.remove('on');setTimeout(()=>{const a=$('chat-area');if(a)a.scrollTop=a.scrollHeight},100);}
  if(n==='calendar')renderCalendar();
  if(n==='we'){/* ok */}
  if(n==='gallery'){setTimeout(()=>{const el=$('photo-gallery');if(el)el.scrollIntoView({block:'nearest'})},20)}
}

function openSub(n){
  hideTabs();
  const el=$('sub-'+n);if(el){el.classList.remove('hidden');el.style.display='block'}
  document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('on'));
  if(n==='mood')renderMoodGrid();
  if(n==='calendar'){renderCalendar();}
  if(n==='memories'){/* list already bound */}
  if(n==='settings')refreshSettingsUI();
}

document.querySelectorAll('.nav button').forEach(b=>b.onclick=()=>openTab(b.dataset.tab));
if($('features-settings-btn'))$('features-settings-btn').onclick=()=>openSub('settings');

const SWIPE_TABS=['home','chat','gallery','features','dock','we'];
let swipeStartX=0,swipeStartY=0;
function swipeTo(delta){
  if(window.__blockTabSwipe||document.body.classList.contains("on-chat-tab")||document.body.classList.contains("on-features-tab"))return; if(!S.swipeNav)return; const current=SWIPE_TABS.findIndex(t=>!$('tab-'+t)?.classList.contains('hidden')); if(current<0)return;
  const next=Math.max(0,Math.min(SWIPE_TABS.length-1,current+delta)); if(next!==current)openTab(SWIPE_TABS[next]);
}
const swipeArea=$('main-scroll');
if(swipeArea){swipeArea.addEventListener('touchstart',e=>{if(document.body.classList.contains('on-chat-tab'))return;const t=e.changedTouches[0];swipeStartX=t.clientX;swipeStartY=t.clientY},{passive:true});swipeArea.addEventListener('touchend',e=>{if(document.body.classList.contains('on-chat-tab'))return;const t=e.changedTouches[0],dx=t.clientX-swipeStartX,dy=t.clientY-swipeStartY;if(Math.abs(dx)>55&&Math.abs(dx)>Math.abs(dy)*1.25)swipeTo(dx<0?1:-1)},{passive:true})}
document.querySelectorAll('[data-tab-go]').forEach(b=>b.onclick=()=>openTab(b.dataset.tabGo));
document.querySelectorAll('[data-sub]').forEach(b=>b.onclick=()=>openSub(b.dataset.sub));
document.querySelectorAll('[data-back]').forEach(b=>{
  b.onclick=()=>{
    const t=b.dataset.back;
    if(t==='home')openTab('home');
    else if(t==='we')openTab('features');
    else if(t==='memories')openSub('memories');
  };
});
$('btn-my-mood').onclick=()=>openSub('mood');

/* Profile photo */
function pickPhoto(){if(S.role)$('photo-input').click()}
$('edit-he').onclick=()=>{if(S.role==='he')pickPhoto()};
$('edit-she').onclick=()=>{if(S.role==='she')pickPhoto()};
$('av-he').onclick=()=>{if(S.role==='he')pickPhoto()};
$('av-she').onclick=()=>{if(S.role==='she')pickPhoto()};
$('photo-input').onchange=async e=>{
  const f=e.target.files[0];if(!f||!db)return;
  toast('Завантаження…');
  try{
    const data=await compress(f,400,0.7);
    S.photos[S.role]=data;setAv(S.role,data);
    await R('users/'+S.role+'/photo').set(data);
    toast('Фото оновлено ❤️');
  }catch(err){toast('Помилка фото')}
  e.target.value='';
};

function enter(role){
  S.role=role;
  localStorage.setItem('ns_role',role);localStorage.setItem('ns_role_v2',role);
  show('sc-main');openTab('home');
  if(db){
    R('meta').once('value').then(snap=>{
      if(!snap.exists()){
        R('meta').set({startDate:new Date('2025-06-22T00:00:00').getTime(),meetAt:null,meetMsg:'Я дуже тебе чекаю ❤️'});
      }
    });
    R('users/'+role).update({name:NAMES[role],lastSeen:Date.now()});
    bind();
    try{bindFilms()}catch(e){}
    try{bindCustom()}catch(e){}
  } else toast('Немає інтернету — синхронізація недоступна');
  renderHome();
  refreshSettingsUI();
  setInterval(()=>{if(db&&S.role)R('users/'+S.role+'/lastSeen').set(Date.now())},20000);
}
$('pick-he').onclick=()=>enter('he');
$('pick-she').onclick=()=>enter('she');
bindAppearanceSettings();
setAppBackground(S.appBg);setChatBackground();applyPalette(S.palette);

function pushEvent(type,text){
  if(!db){toast(text);return}
  const ts=Date.now();S.lastLocal=ts;
  R('events').push({type,text,from:S.role,fromName:myName(),ts});
  if(type==='signal')R('lastSaid/'+S.role).set({text,ts});
  if(['memory','note','date','song','gallery','calendar'].includes(type)){
    R('feed').push({type,text,from:S.role,ts});
  }
}

function bind(){
  if(!db)return;

  R('meta').on('value',snap=>{
    const m=snap.val()||{};
    if(m.startDate)S.startDate=m.startDate;
    S.meetAt=m.meetAt||null;
    S.meetMsg=m.meetMsg||S.meetMsg;
    if(m.startDate&&$('set-start'))$('set-start').value=new Date(m.startDate).toISOString().slice(0,10);
    if(m.meetAt){
      const d=new Date(m.meetAt),p=n=>String(n).padStart(2,'0');
      const v=`${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
      if($('set-meet'))$('set-meet').value=v;
      if($('set-meet2'))$('set-meet2').value=v;
    }
    if(m.meetMsg){
      if($('set-meet-msg'))$('set-meet-msg').value=m.meetMsg;
      if($('set-meet-msg2'))$('set-meet-msg2').value=m.meetMsg;
    }
    renderHome();
  });

  R('users/he/photo').on('value',s=>{S.photos.he=s.val()||'';setAv('he',S.photos.he)});
  R('users/she/photo').on('value',s=>{S.photos.she=s.val()||'';setAv('she',S.photos.she)});

  R('users/'+other()).on('value',snap=>{
    const u=snap.val()||{};
    if(u.lastSeen){
      const ago=Date.now()-u.lastSeen;
      const txt=ago<120000?'🟢 У мережі':'Була/був '+Math.max(1,Math.floor(ago/60000))+' хв тому';
      if($('partner-seen'))$('partner-seen').textContent=txt;
      if($('chat-status'))$('chat-status').textContent=txt;
    }
  });

  R('mood/he').on('value',snap=>{S.moodHe=snap.val();renderMoods()});
  R('mood/she').on('value',snap=>{S.moodShe=snap.val();renderMoods()});
  R('mood/'+other()).on('value',snap=>{S.partnerMood=snap.val();renderHome()});

  R('lastSaid/he').on('value',snap=>{const v=snap.val();S.lastSaid.he=v?v.text:'';if($('said-he'))$('said-he').textContent=S.lastSaid.he||'ще нічого…'});
  R('lastSaid/she').on('value',snap=>{const v=snap.val();S.lastSaid.she=v?v.text:'';if($('said-she'))$('said-she').textContent=S.lastSaid.she||'ще нічого…'});

  R('events').limitToLast(60).on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    const nonChat=arr.filter(e=>e.type!=='chat');if(nonChat[0]&&$('last-event-text'))$('last-event-text').textContent=nonChat[0].text+' · '+new Date(arr[0].ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'});
    if($('last-events-home')){
      $('last-events-home').innerHTML=arr.filter(e=>e.type!=='chat').slice(0,4).map(e=>`<div class="feed-item" style="margin-bottom:6px"><b>${esc(e.text)}</b><div class="muted">${new Date(e.ts).toLocaleString('uk-UA')}</div></div>`).join('')||'<div class="muted">Поки тихо…</div>';
    }
    if($('events-list'))$('events-list').innerHTML=arr.slice(0,4).map(e=>`<div class="list-item"><div class="t">${esc(e.text)}</div><div class="s">${new Date(e.ts).toLocaleString('uk-UA')}</div></div>`).join('')||'<div class="muted card center">Немає подій</div>';
    if($('near-history'))$('near-history').innerHTML=arr.filter(e=>e.type==='signal').slice(0,20).map(e=>`<div class="list-item"><div class="t">${esc(e.text)}</div><div class="s">${new Date(e.ts).toLocaleString('uk-UA')}</div></div>`).join('')||'—';
    const last=arr[0];
    if(last&&last.from!==S.role&&last.ts&&last.ts>S.seenEventTs&&last.ts!==S.lastLocal&&Date.now()-last.ts<60000){
      S.seenEventTs=last.ts;
      localStorage.setItem('ns_seen_ev',String(last.ts));
      const allowed=last.type==='chat'?S.notifications.chat:last.type==='signal'?S.notifications.signal:last.type==='mood'?S.notifications.mood:last.type==='gallery'?S.notifications.gallery:true;
      if(allowed)showBanner('❤️ Наш Світ', last.text);
    }
  });

  R('feed').limitToLast(50).on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if($('feed-empty'))$('feed-empty').style.display=arr.length?'none':'block';
    if($('feed-list'))$('feed-list').innerHTML=arr.map(f=>`<div class="feed-item"><b>${esc(f.text)}</b><div class="muted">${new Date(f.ts).toLocaleString('uk-UA')}</div></div>`).join('');
  });

  // CHAT - fixed
  
  R('chat').limitToLast(150).on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(a.ts||0)-(b.ts||0));
    const area=$('chat-area');
    if(!area)return;
    const myLastRead = Number(localStorage.getItem('ns_last_read_chat')||0);
    let unread=0;
    area.innerHTML=arr.map(m=>{
      const me=m.from===S.role;
      if(!me && (m.ts||0)>myLastRead) unread++;
      const readMark = me ? (`<div class="read">${m.seenByOther?'✓✓ прочитано':'✓'}</div>`) : '';
      const delBtn = me ? `<button type="button" class="del-msg" data-del="${m.id}">✕</button>` : '';
      const tm = new Date(m.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'});
      if(m.type==='photo'&&m.photo) return `<div class="bubble photo ${me?'me':'them'}">${delBtn}<img src="${m.photo}" alt=""><div class="tm">${tm}</div>${readMark}</div>`;
      if(m.type==='video'&&m.video) return `<div class="bubble video-circle ${me?'me':'them'}">${delBtn}<video src="${m.video}" playsinline controls></video>${readMark}</div>`;
      if(m.type==='voice'&&m.audio) return `<div class="bubble voice ${me?'me':'them'}">${delBtn}<span>🎤</span><audio controls src="${m.audio}"></audio><div class="tm">${tm}</div>${readMark}</div>`;
      return `<div class="bubble ${me?'me':'them'}">${delBtn}${esc(m.text||'')}<div class="tm">${tm}</div>${readMark}</div>`;
    }).join('');
    area.querySelectorAll('[data-del]').forEach(b=>{
      b.onclick=e=>{e.stopPropagation(); if(confirm('Видалити повідомлення?')) R('chat/'+b.dataset.del).remove();};
    });
    area.scrollTop=area.scrollHeight;
    // mark others' messages as seen when chat open
    const chatOpen = $('tab-chat') && !$('tab-chat').classList.contains('hidden');
    if(chatOpen){
      const latest=arr.length?arr[arr.length-1].ts:0;
      if(latest) localStorage.setItem('ns_last_read_chat',String(latest));
      S.unreadChat=0;
      if($('chat-unread')){$('chat-unread').textContent='0';$('chat-unread').classList.remove('on')}
      arr.forEach(m=>{
        if(m.from!==S.role && !m.seenByOther) R('chat/'+m.id+'/seenByOther').set(true);
      });
    } else {
      S.unreadChat=unread;
      if($('chat-unread')){$('chat-unread').textContent=String(unread);$('chat-unread').classList.toggle('on',unread>0)}
      localStorage.setItem('ns_unread_chat',String(unread));
    }
  });


  // NOTES
  R('notes').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if($('notes-empty'))$('notes-empty').style.display=arr.length?'none':'block';
    if($('notes-list')){
      $('notes-list').innerHTML=arr.map(n=>{
        const who=n.who==='he'?'Котусик':(n.who==='she'?'Квіточка':'');
        return `<div class="list-item"><div class="t">${esc(n.text)}</div><div class="s">${n.date||''}${who?' · '+who:''}</div><button class="del" data-id="${n.id}">✕</button></div>`;
      }).join('');
      $('notes-list').querySelectorAll('.del').forEach(b=>b.onclick=()=>R('notes/'+b.dataset.id).remove());
    }
  });

  // GALLERY
  R('gallery').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if($('gal-empty'))$('gal-empty').style.display=arr.length?'none':'block';
    const gal=$('photo-gallery');
    if(!gal)return;
    gal.innerHTML=arr.map(g=>`<div class="gi" data-id="${g.id}" data-src="${g.data}" data-cap="${esc(g.caption||'')}"><img src="${g.data}" alt=""><div class="cap">${esc(g.caption||'Натисни')}</div></div>`).join('');
    gal.querySelectorAll('.gi').forEach(el=>{
      el.onclick=()=>openLightbox(el.dataset.src, el.dataset.cap, el.dataset.id);
    });
  });

  R('memories').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if($('mem-empty'))$('mem-empty').style.display=arr.length?'none':'block';
    if($('mem-list')){
      $('mem-list').innerHTML=arr.map(m=>{
        const photos=m.photos||(m.photo?[m.photo]:[]);
        const gal=photos.length?`<div class="gallery">${photos.map(p=>`<div class="gi" data-src="${p}"><img src="${p}"></div>`).join('')}</div>`:'';
        return `<div class="list-item">${gal}<div class="t">${esc(m.title)}</div><div class="s">${esc(m.date||'')} ${esc(m.place||'')}</div><div class="s">${esc(m.desc||'')}</div><button class="del" data-id="${m.id}">✕</button></div>`;
      }).join('');
      $('mem-list').querySelectorAll('.del').forEach(b=>b.onclick=()=>R('memories/'+b.dataset.id).remove());
      $('mem-list').querySelectorAll('.gi').forEach(el=>el.onclick=()=>openLightbox(el.dataset.src,''));
    }
  });

  R('dates').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(a.when||0)-(b.when||0));
    if($('dates-list')){
      $('dates-list').innerHTML=arr.map(d=>`<div class="list-item"><div class="t">❤️ ${esc(d.title)}</div><div class="s">${d.when?new Date(d.when).toLocaleDateString('uk-UA'):''} · ${esc(d.desc||'')}</div><button class="del" data-id="${d.id}">✕</button></div>`).join('')||'<div class="card center muted">Додайте дати</div>';
      $('dates-list').querySelectorAll('.del').forEach(b=>b.onclick=()=>R('dates/'+b.dataset.id).remove());
    }
  });

  R('songs').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if($('songs-list')){
      $('songs-list').innerHTML=arr.map(s=>`<div class="list-item"><div class="t">🎵 ${esc(s.title)}</div><div class="s">${esc(s.artist||'')} ${s.link?`· <a href="${esc(s.link)}" target="_blank">▶</a>`:''}</div><div class="s">${esc(s.note||'')}</div><button class="del" data-id="${s.id}">✕</button></div>`).join('')||'<div class="card center muted">Додайте пісні</div>';
      $('songs-list').querySelectorAll('.del').forEach(b=>b.onclick=()=>R('songs/'+b.dataset.id).remove());
    }
  });

  R('mood/'+S.role+'/history').limitToLast(15).on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>data[k]).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if($('mood-history'))$('mood-history').innerHTML=arr.map(h=>`${new Date(h.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'})} — ${esc(h.e)} ${esc(h.t)}`).join('<br>')||'—';
  });

  R('calendar').on('value',snap=>{
    S.calData=snap.val()||{};
    if($('tab-calendar')&&!$('tab-calendar').classList.contains('hidden'))renderCalendar();
  });
}

/* Signals */
function sendNear(){
  const text=nearMsg(S.role);
  pushEvent('signal','🫶 '+text);
  toast(text);
  try{navigator.vibrate&&navigator.vibrate([100,50,100,50,200])}catch(e){}
}
$('btn-near-home').onclick=sendNear;
$('btn-heart').onclick=sendNear;

document.querySelectorAll('[data-sig]').forEach(btn=>{
  btn.onclick=()=>{
    const k=btn.dataset.sig;
    const text=sigText(k,S.role);
    pushEvent('signal',text);
    toast('📍 Надіслано');
    if(k==='night'&&db)R('mood/'+S.role).set({e:'😴',t:'Сплю',ts:Date.now()});
    if(k==='morning'&&db)R('mood/'+S.role).set({e:'☀️',t:'Прокинувся/лась',ts:Date.now()});
  };
});

function renderMoodGrid(){
  if(!$('mood-grid'))return;
  $('mood-grid').innerHTML=MOODS.map(m=>`<button class="mood-btn" data-e="${m.e}" data-t="${m.t}"><span class="e">${m.e}</span>${m.t}</button>`).join('');
  $('mood-grid').querySelectorAll('.mood-btn').forEach(b=>b.onclick=()=>setMood(b.dataset.e,b.dataset.t));
}
function setMood(e,t){
  if(!db)return;
  const ts=Date.now();
  R('mood/'+S.role).set({e,t,ts});
  R('mood/'+S.role+'/history').push({e,t,ts});
  if(S.role==='he')S.moodHe={e,t,ts};else S.moodShe={e,t,ts};renderMoods();
  pushEvent('mood',`${e} ${myName()}: ${t}`);
  toast(e+' '+t);
}
$('btn-custom-mood').onclick=()=>{const t=$('custom-mood').value.trim();if(!t)return;setMood('✨',t);$('custom-mood').value=''};

/* Chat send - robust */
function sendChat(){
  const input=$('chat-input');
  if(!input)return;
  const text=input.value.trim();
  if(!text)return;
  if(!db){toast('Немає інтернету');return}
  if(!S.role){toast('Оберіть роль');return}
  R('chat').push({text,from:S.role,ts:Date.now()});
  input.value='';
  // notify other via events lightly
  R('events').push({type:'chat',text:myName()+': '+text.slice(0,40),from:S.role,fromName:myName(),ts:Date.now()});
}
$('chat-send').onclick=sendChat;
if($('chat-emoji-btn'))$('chat-emoji-btn').onclick=()=>{const r=$('emoji-row');if(r)r.style.display=r.style.display==='none'?'flex':'none'};
document.querySelectorAll('[data-emoji]').forEach(b=>b.onclick=()=>{const i=$('chat-input');if(i){i.value+=b.dataset.emoji;i.focus()}});
$('chat-input').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();sendChat()}});
$('chat-hug').onclick=()=>{
  pushEvent('signal',sigText('hug',S.role));
  if(db)R('chat').push({text:'🫶 Обіймаю тебе',from:S.role,ts:Date.now()});
  toast('🫶');
};

/* Notes */
$('btn-add-note').onclick=()=>{
  const t=$('note-input').value.trim();if(!t||!db)return;
  const now=new Date();
  R('notes').push({text:t,who:S.role,date:now.toLocaleString('uk-UA'),ts:Date.now()});
  pushEvent('note','📝 Нотатка від '+myName());
  $('note-input').value='';
  toast('Збережено');
};
$('note-input').addEventListener('keydown',e=>{if(e.key==='Enter')$('btn-add-note').click()});

/* Gallery */
$('btn-add-gal').onclick=()=>$('gal-input').click();
$('gal-input').onchange=async e=>{
  if(!db)return;
  const files=[...e.target.files];
  toast('Завантаження…');
  for(const f of files.slice(0,12)){
    try{
      const data=await compress(f,800,0.65);
      R('gallery').push({data,caption:'',from:S.role,ts:Date.now()});
    }catch(err){}
  }
  pushEvent('gallery','🖼 Нові фото в галереї');
  toast('Додано');
  e.target.value='';
};

/* Lightbox */
function openLightbox(src,cap,id){
  S.lbZoom=1;S.lbId=id||null;
  $('lb-img').src=src;
  $('lb-img').style.transform='scale(1)';
  $('lb-cap').textContent=cap||'';
  $('lightbox').classList.add('on');
}
$('lb-close').onclick=()=>$('lightbox').classList.remove('on');
$('lightbox').onclick=e=>{if(e.target.id==='lightbox')$('lightbox').classList.remove('on')};
$('lb-zoom-in').onclick=()=>{S.lbZoom=Math.min(3,S.lbZoom+0.25);$('lb-img').style.transform='scale('+S.lbZoom+')'};
$('lb-zoom-out').onclick=()=>{S.lbZoom=Math.max(0.5,S.lbZoom-0.25);$('lb-img').style.transform='scale('+S.lbZoom+')'};
$('lb-comment').onclick=()=>{
  if(!S.lbId||!db){toast('Коментар лише для фото з галереї');return}
  const c=prompt('Коментар до фото:',$('lb-cap').textContent||'');
  if(c===null)return;
  R('gallery/'+S.lbId+'/caption').set(c);
  $('lb-cap').textContent=c;
  toast('Коментар збережено');
};

/* Memories */
$('btn-new-mem').onclick=()=>openSub('mem-form');
let memPhotos=[];
$('mem-photo').onchange=async e=>{
  const files=[...e.target.files];
  for(const f of files.slice(0,6)){
    try{memPhotos.push(await compress(f,600,0.65))}catch(err){}
  }
  $('mem-photo-prev').innerHTML=memPhotos.map(p=>`<div class="gi"><img src="${p}"></div>`).join('');
  e.target.value='';
};
$('btn-save-mem').onclick=()=>{
  const title=$('mem-title').value.trim();if(!title){toast('Вкажіть назву');return}
  if(!db)return;
  R('memories').push({title,date:$('mem-date').value,place:$('mem-place').value.trim(),desc:$('mem-desc').value.trim(),photos:memPhotos,photo:memPhotos[0]||'',from:S.role,ts:Date.now()});
  pushEvent('memory','📸 Спогад: '+title);
  memPhotos=[];$('mem-title').value='';$('mem-desc').value='';$('mem-photo-prev').innerHTML='';
  toast('Збережено ❤️');openSub('memories');
};

$('btn-add-date').onclick=()=>{
  const title=$('date-title').value.trim();if(!title||!db)return;
  R('dates').push({title,when:$('date-when').value?new Date($('date-when').value+'T00:00:00').getTime():Date.now(),desc:$('date-desc').value.trim(),ts:Date.now()});
  pushEvent('date','📅 '+title);
  $('date-title').value='';$('date-desc').value='';toast('Додано');
};
$('btn-add-song').onclick=()=>{
  const title=$('song-title').value.trim();if(!title||!db)return;
  R('songs').push({title,artist:$('song-artist').value.trim(),link:$('song-link').value.trim(),note:$('song-note').value.trim(),ts:Date.now()});
  pushEvent('song','🎵 '+title);
  $('song-title').value='';$('song-artist').value='';$('song-link').value='';$('song-note').value='';
  toast('Додано 🎵');
};

function saveMeet(meetEl,msgEl){
  if(!db)return;
  const v=$(meetEl).value;
  R('meta').update({meetAt:v?new Date(v).getTime():null,meetMsg:$(msgEl).value});
  toast('Збережено ❤️');
}
$('btn-save-meet').onclick=()=>saveMeet('set-meet','set-meet-msg');
if($('btn-save-meet2'))$('btn-save-meet2').onclick=()=>saveMeet('set-meet2','set-meet-msg2');
if($('btn-save-start'))$('btn-save-start').onclick=()=>{
  const v=$('set-start').value;if(!v||!db)return;
  R('meta').update({startDate:new Date(v+'T00:00:00').getTime()});
  toast('Збережено');
};
$('btn-leave').onclick=()=>{localStorage.removeItem('ns_role');location.reload()};

/* Calendar */
const WD=['Пн','Вт','Ср','Чт','Пт','Сб','Нд'];
function renderCalendar(){
  $('cal-weekdays').innerHTML=WD.map(w=>`<div class="cal-hd">${w}</div>`).join('');
  const y=S.calY,m=S.calM;
  $('cal-title').textContent=new Date(y,m,1).toLocaleDateString('uk-UA',{month:'long',year:'numeric'});
  const first=new Date(y,m,1);
  let start=(first.getDay()+6)%7; // Mon=0
  const daysIn=new Date(y,m+1,0).getDate();
  const prevDays=new Date(y,m,0).getDate();
  const today=new Date();
  let html='';
  for(let i=0;i<42;i++){
    let day,month=m,year=y,cls='cal-day';
    if(i<start){day=prevDays-start+i+1;month=m-1;if(month<0){month=11;year--}cls+=' other'}
    else if(i>=start+daysIn){day=i-start-daysIn+1;month=m+1;if(month>11){month=0;year++}cls+=' other'}
    else{day=i-start+1}
    const key=`${year}-${String(month+1).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
    if(year===today.getFullYear()&&month===today.getMonth()&&day===today.getDate())cls+=' today';
    const marked=S.calData&&S.calData[key];
    if(marked)cls+=' marked';
    html+=`<button class="${cls}" data-key="${key}">${day}${marked?'<span class="dot"></span>':''}</button>`;
  }
  $('cal-days').innerHTML=html;
  $('cal-days').querySelectorAll('.cal-day').forEach(b=>{
    b.onclick=()=>selectCalDay(b.dataset.key);
  });
  if($('cal-marked-list')){
    const entries=Object.keys(S.calData||{}).map(k=>({key:k,...(S.calData[k]||{})})).sort((a,b)=>b.key.localeCompare(a.key));
    if(!entries.length)$('cal-marked-list').innerHTML='<div class="muted">Поки немає відмічених дат</div>';
    else $('cal-marked-list').innerHTML=entries.map(e=>{
      const parts=e.key.split('-');
      const nice=parts.length===3?`${parts[2]}.${parts[1]}.${parts[0].slice(2)}`:e.key;
      return `<div class="list-item" data-key="${e.key}" style="cursor:pointer"><div class="t">📅 ${nice}</div><div class="s">${esc(e.comment||'Без коментаря')}</div></div>`;
    }).join('');
    $('cal-marked-list').querySelectorAll('.list-item').forEach(el=>el.onclick=()=>selectCalDay(el.dataset.key));
  }

}
function selectCalDay(key){
  S.selectedDay=key;
  $('cal-day-panel').style.display='block';
  $('cal-day-title').textContent=key;
  const d=(S.calData&&S.calData[key])||{};
  $('cal-comment').value=d.comment||'';
  $('cal-photo-prev').innerHTML=d.photo?`<img src="${d.photo}" style="max-width:100%;border-radius:12px;margin-top:6px">`:'';
  $('cal-day-photos').innerHTML=d.photo?`<div class="gi" data-src="${d.photo}"><img src="${d.photo}"></div>`:'';
  $('cal-day-photos').querySelectorAll('.gi').forEach(el=>el.onclick=()=>openLightbox(el.dataset.src,d.comment||''));
}
$('cal-prev').onclick=()=>{S.calM--;if(S.calM<0){S.calM=11;S.calY--}renderCalendar()};
$('cal-next').onclick=()=>{S.calM++;if(S.calM>11){S.calM=0;S.calY++}renderCalendar()};
let calPhotoData='';
$('cal-photo').onchange=async e=>{
  const f=e.target.files[0];if(!f)return;
  calPhotoData=await compress(f,700,0.65);
  $('cal-photo-prev').innerHTML=`<img src="${calPhotoData}" style="max-width:100%;border-radius:12px">`;
  e.target.value='';
};
$('btn-save-day').onclick=()=>{
  if(!S.selectedDay||!db)return;
  const comment=$('cal-comment').value.trim();
  const prev=(S.calData&&S.calData[S.selectedDay])||{};
  const photo=calPhotoData||prev.photo||'';
  R('calendar/'+S.selectedDay).set({comment,photo,ts:Date.now(),from:S.role});
  pushEvent('calendar','📅 День '+S.selectedDay+(comment?': '+comment.slice(0,30):''));
  calPhotoData='';
  toast('День збережено ❤️');
};

setInterval(()=>{tickHappy();tickMeet()},1000);


/* Chat photo/voice/stickers + films + custom */
if($('chat-photo-btn'))$('chat-photo-btn').onclick=()=>$('chat-photo-input')&&$('chat-photo-input').click();
if($('chat-photo-input'))$('chat-photo-input').onchange=async e=>{
  const f=e.target.files&&e.target.files[0];if(!f||!db||!S.role)return;
  toast('Надсилаємо фото…');
  try{
    const data=await compress(f,700,0.65);
    R('chat').push({type:'photo',photo:data,from:S.role,ts:Date.now()});
    R('events').push({type:'chat',text:myName()+' надіслав(ла) фото 📷',from:S.role,fromName:myName(),ts:Date.now()});
    toast('Фото надіслано');
  }catch(err){toast('Помилка фото')}
  e.target.value='';
};
document.querySelectorAll('[data-sticker]').forEach(b=>{
  b.onclick=()=>{ if(!db||!S.role)return; R('chat').push({text:b.dataset.sticker,from:S.role,ts:Date.now(),type:'sticker'}); };
});
let mediaRec=null, audioChunks=[];
if($('chat-mic')){
  $('chat-mic').onclick=async()=>{
    if(mediaRec&&mediaRec.state==='recording'){ mediaRec.stop();$('chat-mic').textContent='🎤';return; }
    try{
      const stream=await navigator.mediaDevices.getUserMedia({audio:true});
      audioChunks=[]; mediaRec=new MediaRecorder(stream);
      mediaRec.ondataavailable=e=>{if(e.data.size)audioChunks.push(e.data)};
      mediaRec.onstop=()=>{
        stream.getTracks().forEach(t=>t.stop());
        const blob=new Blob(audioChunks,{type:'audio/webm'});
        if(blob.size>900000){toast('Занадто довге');return}
        const reader=new FileReader();
        reader.onload=()=>{ if(!db||!S.role)return; R('chat').push({type:'voice',audio:reader.result,from:S.role,ts:Date.now()}); R('events').push({type:'chat',text:myName()+' надіслав(ла) голосове 🎤',from:S.role,fromName:myName(),ts:Date.now()}); toast('Голосове надіслано'); };
        reader.readAsDataURL(blob);
      };
      mediaRec.start(); $('chat-mic').textContent='⏹'; toast('Запис… натисни ще раз щоб зупинити');
    }catch(err){toast('Немає доступу до мікрофона')}
  };
}
function bindFilms(){
  if(!db)return;
  R('films').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    const todo=arr.filter(f=>!f.done); const done=arr.filter(f=>f.done);
    if($('films-todo'))$('films-todo').innerHTML=todo.map(f=>`<div class="film-item"><div class="t">🎬 ${esc(f.title)}</div><div class="s">${esc(f.note||'')}</div>
      <button class="btn btn-o" data-done="${f.id}" style="margin-top:6px">Подивились ✅</button>
      <button class="del" data-id="${f.id}">✕</button></div>`).join('')||'<div class="muted">Список порожній</div>';
    if($('films-done'))$('films-done').innerHTML=done.map(f=>`<div class="film-item"><div class="t">🎬 ${esc(f.title)}</div><div class="s">${'⭐'.repeat(f.rating||0)} ${f.rating?f.rating+'/5':''}</div><div class="s">${esc(f.impression||'')}</div>
      <button class="del" data-id="${f.id}">✕</button></div>`).join('')||'<div class="muted">Ще нічого</div>';
    document.querySelectorAll('[data-done]').forEach(b=>b.onclick=()=>{
      const rating=prompt('Оцінка 1-5','5'); const impression=prompt('Ваше враження ❤️','Супер!');
      const title=(todo.find(x=>x.id===b.dataset.done)||{}).title||'';
      R('films/'+b.dataset.done).update({done:true,rating:Number(rating)||5,impression:impression||'',doneAt:Date.now()});
      pushEvent('film','🎬 Подивились: '+title);
    });
    document.querySelectorAll('#films-todo .del, #films-done .del').forEach(b=>b.onclick=()=>R('films/'+b.dataset.id).remove());
  });
  R('watchInvite').on('value',snap=>{
    const v=snap.val(); if(!v||!$('watch-invite-status'))return;
    if(Date.now()-(v.ts||0)<600000){
      $('watch-invite-status').textContent=(v.fromName||'')+' кличе дивитись: '+(v.film||'фільм')+' 🥰';
      if(v.from!==S.role&&v.ts!==S.lastLocal) showBanner('🎬 Запрошення',(v.fromName||'')+' запрошує на фільм!');
    }
  });
}
if($('btn-add-film'))$('btn-add-film').onclick=()=>{
  const title=$('film-title').value.trim(); if(!title||!db)return;
  R('films').push({title,note:$('film-note').value.trim(),done:false,from:S.role,ts:Date.now()});
  pushEvent('film','🎬 У список: '+title); $('film-title').value='';$('film-note').value=''; toast('Додано');
};
if($('btn-invite-watch'))$('btn-invite-watch').onclick=()=>{
  if(!db)return; const film=prompt('Який фільм дивимось?','Наш улюблений'); if(film===null)return;
  const ts=Date.now(); S.lastLocal=ts;
  R('watchInvite').set({film,from:S.role,fromName:myName(),ts});
  pushEvent('film','🎬 '+myName()+' запрошує на «'+film+'»'); toast('Запрошення надіслано 🥰');
};
function bindCustom(){
  if(!db)return;
  R('customSections').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    if(!$('custom-sections-list'))return;
    $('custom-sections-list').innerHTML=arr.map(s=>`<div class="card"><div class="h2">${esc(s.title)}</div><div style="white-space:pre-wrap;font-size:14px">${esc(s.body||'')}</div>
      <div class="muted" style="margin-top:6px">${esc(s.fromName||'')} · ${new Date(s.ts).toLocaleString('uk-UA')}</div>
      <button class="del" data-id="${s.id}" style="position:relative">✕</button></div>`).join('')||'<div class="card center muted">Додайте першу мрію ❤️</div>';
    $('custom-sections-list').querySelectorAll('.del').forEach(b=>b.onclick=()=>R('customSections/'+b.dataset.id).remove());
  });
}
if($('btn-add-custom-sec'))$('btn-add-custom-sec').onclick=()=>{
  const title=$('custom-sec-title').value.trim(); if(!title||!db)return;
  R('customSections').push({title,body:$('custom-sec-body').value.trim(),from:S.role,fromName:myName(),ts:Date.now()});
  pushEvent('custom','✨ Новий розділ: '+title); $('custom-sec-title').value='';$('custom-sec-body').value=''; toast('Розділ створено');
};



/* Home blocks visibility */
S.homeBlocks = JSON.parse(localStorage.getItem('ns_home_blocks')||'null') || {
  avatars:true, happy:true, meet:true, near:true, moods:true, last:true
};
function applyHomeBlocks(){
  const map={
    avatars: document.querySelector('#tab-home .avatars')?.closest('.card'),
    happy: (document.getElementById('happy-days')&&$('happy-days').closest)?$('happy-days').closest('.card'):null,
    meet: $('meet-block')?.closest('.card'),
    near: $('btn-near-home')?.closest('.card'),
    moods: $('mood-he-display')?.closest('.card') || $('btn-my-mood')?.closest('.card'),
    last: $('last-events-home')?.closest('.card')
  };
  Object.keys(map).forEach(k=>{ if(map[k]) map[k].style.display = S.homeBlocks[k]===false ? 'none' : ''; });
  const box=$('home-blocks-settings');
  if(!box)return;
  const labels={avatars:'Профілі',happy:'Щасливих днів',meet:'До зустрічі',near:'Я поруч / кнопки',moods:'Настрої',last:'Останній момент'};
  box.innerHTML=Object.keys(labels).map(k=>`<div class="home-block-item"><span>${labels[k]}</span>
    <label class="switch"><input type="checkbox" data-hb="${k}" ${S.homeBlocks[k]!==false?'checked':''}><span class="slider"></span></label></div>`).join('');
  box.querySelectorAll('[data-hb]').forEach(inp=>{
    inp.onchange=()=>{ S.homeBlocks[inp.dataset.hb]=inp.checked; localStorage.setItem('ns_home_blocks',JSON.stringify(S.homeBlocks)); applyHomeBlocks(); };
  });
}
setTimeout(function(){ try{ applyHomeBlocks(); }catch(e){ console.log(e); } }, 400);

/* Dock up to 6 */
S.dock = JSON.parse(localStorage.getItem('ns_dock')||'[]');
const DOCK_META={
  home:{icon:'🏠',title:'Головна',tab:'home'},
  chat:{icon:'💬',title:'Чат',tab:'chat'},
  notes:{icon:'📝',title:'Нотатки',tab:'notes'},
  gallery:{icon:'🖼',title:'Галерея',tab:'gallery'},
  calendar:{icon:'📅',title:'Календар',tab:'calendar'},
  movies:{icon:'🎬',title:'Фільми',tab:'movies'},
  features:{icon:'✨',title:'Усі можливості',tab:'features'},
  dock:{icon:'✦',title:'Швидкий доступ',tab:'dock'},
  feed:{icon:'📰',title:'Стрічка',tab:'feed'},
  relations:{icon:'❤️',title:'Стосунки',sub:'relations'},
  dates:{icon:'📌',title:'Дати',sub:'dates'},
  meet:{icon:'🌎',title:'Зустріч',sub:'meet'},
  music:{icon:'🎵',title:'Музика',sub:'music'},
  memories:{icon:'📸',title:'Спогади',sub:'memories'},
  dreams:{icon:'🥰',title:'Мрії',sub:'dreams'},
  custom:{icon:'🥰',title:'Мрії',sub:'dreams'},
  near:{icon:'🫶',title:'Я поруч',sub:'near'},
  mood:{icon:'😊',title:'Настрій',sub:'mood'},
  widget:{icon:'📱',title:'Віджет',sub:'widget'},
  events:{icon:'🔔',title:'Події',sub:'events'},
  settings:{icon:'⚙️',title:'Налаштування',sub:'settings'}
};
function renderDock(){
  const g=$('dock-grid'); if(!g)return;
  const slots=[];
  for(let i=0;i<6;i++){
    const id=S.dock[i];
    if(id&&DOCK_META[id]){
      const m=DOCK_META[id];
      slots.push(`<button class="dock-slot filled" data-dock="${id}" data-i="${i}"><div style="font-size:22px">${m.icon}</div>${m.title}<div class="muted" style="font-size:10px;margin-top:4px">утримай = видалити</div></button>`);
    } else slots.push(`<div class="dock-slot muted">Порожньо</div>`);
  }
  g.innerHTML=slots.join('');
  g.querySelectorAll('[data-dock]').forEach(btn=>{
    btn.onclick=()=>{
      const m=DOCK_META[btn.dataset.dock];
      if(m.tab) openTab(m.tab); else if(m.sub) openSub(m.sub);
    };
    let t=null;
    btn.ontouchstart=()=>{t=setTimeout(()=>{S.dock=S.dock.filter(x=>x!==btn.dataset.dock);localStorage.setItem('ns_dock',JSON.stringify(S.dock));renderDock();toast('Прибрано');},650)};
    btn.ontouchend=()=>clearTimeout(t);
    btn.onmousedown=()=>{t=setTimeout(()=>{S.dock=S.dock.filter(x=>x!==btn.dataset.dock);localStorage.setItem('ns_dock',JSON.stringify(S.dock));renderDock();toast('Прибрано');},650)};
    btn.onmouseup=()=>clearTimeout(t);
  });
}
if($('btn-dock-add'))$('btn-dock-add').onclick=()=>{
  const v=$('dock-add-select').value; if(!v)return;
  if(S.dock.includes(v)){toast('Вже додано');return}
  if(S.dock.length>=6){toast('Максимум 6');return}
  S.dock.push(v); localStorage.setItem('ns_dock',JSON.stringify(S.dock)); renderDock(); toast('Додано ✦');
};
setTimeout(function(){ try{ renderDock(); }catch(e){} }, 300);

/* Video circles like Telegram */
let videoRec=null, videoChunks=[], videoStream=null;
if($('chat-video')){
  $('chat-video').onclick=async()=>{
    if(videoRec&&videoRec.state==='recording'){
      videoRec.stop(); $('chat-video').textContent='⚪'; return;
    }
    try{
      videoStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:480,height:480},audio:true});
      videoChunks=[];
      videoRec=new MediaRecorder(videoStream,{mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')?'video/webm;codecs=vp8,opus':'video/webm'});
      videoRec.ondataavailable=e=>{if(e.data.size)videoChunks.push(e.data)};
      videoRec.onstop=()=>{
        videoStream.getTracks().forEach(t=>t.stop());
        const blob=new Blob(videoChunks,{type:'video/webm'});
        if(blob.size>2_500_000){toast('Занадто довге відео');return}
        const reader=new FileReader();
        reader.onload=()=>{
          if(!db||!S.role)return;
          R('chat').push({type:'video',video:reader.result,from:S.role,ts:Date.now()});
          R('events').push({type:'chat',text:myName()+' надіслав(ла) відео-кружечок ⚪',from:S.role,fromName:myName(),ts:Date.now()});
          toast('Відео надіслано');
        };
        reader.readAsDataURL(blob);
      };
      videoRec.start();
      $('chat-video').textContent='⏹';
      toast('Запис кружечка… натисни ще раз');
      setTimeout(()=>{ if(videoRec&&videoRec.state==='recording'){videoRec.stop();$('chat-video').textContent='⚪'} },15000);
    }catch(err){toast('Немає доступу до камери')}
  };
}

/* Render video in chat - patch via global helper */
window._chatExtraBody=function(m,me){
  if(m.type==='video'&&m.video) return `<div class="bubble video-circle ${me?'me':'them'}"><video src="${m.video}" playsinline controls></video></div>`;
  return null;
};

/* Push prep */
if($('btn-push-prep'))$('btn-push-prep').onclick=async()=>{
  try{
    if(!('Notification' in window)){ $('push-status').textContent='Браузер/WebView не підтримує'; return; }
    const p=await Notification.requestPermission();
    $('push-status').textContent = p==='granted' ? 'Дозвіл є ✓ (потрібні FCM-ключі для фону)' : 'Дозвіл: '+p;
    if(p==='granted') localStorage.setItem('ns_push_perm','1');
    // Placeholders for FCM
    window.__NASH_PUSH__={ ready:true, permission:p, fcmToken:null, note:'Підключіть firebase-messaging + VAPID/server key' };
  }catch(e){ $('push-status').textContent='Помилка: '+e.message }
};
if(localStorage.getItem('ns_push_perm')==='1' && $('push-status'))$('push-status').textContent='Дозвіл є ✓ (очікує FCM)';



/* v2.3 runtime */
(function(){
  // disable pull-to-refresh-ish overscroll
  let lastY=0;
  document.addEventListener('touchstart',e=>{lastY=e.touches[0].clientY},{passive:true});
  document.addEventListener('touchmove',e=>{
    const sc=$('main-scroll');
    if(!sc)return;
    const y=e.touches[0].clientY;
    if(sc.scrollTop<=0 && y>lastY && e.cancelable){ /* allow natural but overscroll-behavior handles */ }
  },{passive:true});
})();

// Offline queue for chat when Firebase fails
function queueOrSend(path, payload){
  if(!db){
    const q=JSON.parse(localStorage.getItem('ns_outbox')||'[]');
    q.push({path,payload,ts:Date.now()});
    localStorage.setItem('ns_outbox',JSON.stringify(q.slice(-80)));
    toast('Збережено локально — надішлеться з інтернетом');
    return Promise.resolve();
  }
  return R(path).push(payload).catch(err=>{
    const q=JSON.parse(localStorage.getItem('ns_outbox')||'[]');
    q.push({path,payload,ts:Date.now()});
    localStorage.setItem('ns_outbox',JSON.stringify(q.slice(-80)));
    toast('Помилка мережі — у черзі');
  });
}
async function flushOutbox(){
  if(!db)return;
  const q=JSON.parse(localStorage.getItem('ns_outbox')||'[]');
  if(!q.length)return;
  const left=[];
  for(const item of q){
    try{ await R(item.path).push(item.payload); }catch(e){ left.push(item); }
  }
  localStorage.setItem('ns_outbox',JSON.stringify(left));
  if(q.length && !left.length) toast('Черга синхронізована ❤️');
}
setInterval(flushOutbox, 15000);
setTimeout(flushOutbox, 3000);

// Patch sendChat to use queue
window.sendChatFixed=true;
const _origSendChat = typeof sendChat==='function' ? sendChat : null;
function sendChat(){
  const input=$('chat-input');
  if(!input)return;
  const text=input.value.trim();
  if(!text)return;
  if(!S.role){toast('Оберіть роль');return}
  input.value='';
  const payload={text,from:S.role,ts:Date.now()};
  queueOrSend('chat', payload).then(()=>{
    if(db) R('events').push({type:'chat',text:myName()+': '+text.slice(0,40),from:S.role,fromName:myName(),ts:Date.now()});
  });
  // optimistic local show
  try{
    const area=$('chat-area');
    if(area){
      area.insertAdjacentHTML('beforeend', `<div class="bubble me">${esc(text)}<div class="tm">…</div></div>`);
      area.scrollTop=area.scrollHeight;
    }
  }catch(e){}
}
if($('chat-send'))$('chat-send').onclick=sendChat;
if($('chat-input')){
  $('chat-input').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();sendChat()}};
}

// Gallery album filter
S.galAlbum='photos';
function setGalAlbum(a){
  S.galAlbum=a;
  if($('gal-tab-photos'))$('gal-tab-photos').classList.toggle('on',a==='photos');
  if($('gal-tab-art'))$('gal-tab-art').classList.toggle('on',a==='art');
  if($('gal-panel-photos'))$('gal-panel-photos').classList.toggle('hidden',a!=='photos');
  if($('gal-panel-art'))$('gal-panel-art').classList.toggle('hidden',a!=='art');
}
if($('gal-tab-photos'))$('gal-tab-photos').onclick=()=>setGalAlbum('photos');
if($('gal-tab-art'))$('gal-tab-art').onclick=()=>setGalAlbum('art');
if($('btn-add-art'))$('btn-add-art').onclick=()=>$('art-input')&&$('art-input').click();
if($('art-input'))$('art-input').onchange=async e=>{
  if(!db||!S.role){toast('Немає зʼєднання');return}
  for(const f of [...e.target.files].slice(0,12)){
    try{
      const data=await compress(f,800,0.65);
      R('galleryArt').push({data,caption:'',from:S.role,ts:Date.now()});
    }catch(err){}
  }
  pushEvent('gallery','🥰 Нове зображення');
  e.target.value='';
};
if(db){
  try{
    R('galleryArt').on('value',snap=>{
      const data=snap.val()||{};
      const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
      if($('art-empty'))$('art-empty').style.display=arr.length?'none':'block';
      const gal=$('art-gallery'); if(!gal)return;
      gal.innerHTML=arr.map(g=>`<div class="gi" data-src="${g.data}" data-cap="${esc(g.caption||'')}"><img src="${g.data}"></div>`).join('');
      gal.querySelectorAll('.gi').forEach(el=>el.onclick=()=>openLightbox(el.dataset.src,el.dataset.cap||''));
    });
  }catch(e){}
}

// Dreams
let dreamPhotoData='';
if($('dream-photo'))$('dream-photo').onchange=async e=>{
  const f=e.target.files[0]; if(!f)return;
  dreamPhotoData=await compress(f,800,0.65);
  if($('dream-photo-prev'))$('dream-photo-prev').innerHTML=`<img src="${dreamPhotoData}" style="max-width:100%;border-radius:12px">`;
  e.target.value='';
};
if($('btn-add-dream'))$('btn-add-dream').onclick=()=>{
  const title=($('dream-title')&&$('dream-title').value.trim())||'';
  if(!title){toast('Напишіть мрію');return}
  if(!db){toast('Немає інтернету');return}
  R('dreams').push({title,body:($('dream-body')&&$('dream-body').value.trim())||'',photo:dreamPhotoData||'',from:S.role,fromName:myName(),ts:Date.now()});
  pushEvent('dream','🥰 Мрія: '+title);
  if($('dream-title'))$('dream-title').value='';
  if($('dream-body'))$('dream-body').value='';
  dreamPhotoData='';
  if($('dream-photo-prev'))$('dream-photo-prev').innerHTML='';
  toast('Мрію додано 🥰');
};
function bindDreams(){
  if(!db)return;
  R('dreams').on('value',snap=>{
    const data=snap.val()||{};
    const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    const box=$('dreams-list'); if(!box)return;
    box.innerHTML=arr.map(d=>`<div class="dream-card"><div class="h2">${esc(d.title)}</div><div style="font-size:14px;white-space:pre-wrap">${esc(d.body||'')}</div>${d.photo?`<img src="${d.photo}">`:''}<div class="muted" style="margin-top:6px">${esc(d.fromName||'')} · ${new Date(d.ts).toLocaleString('uk-UA')}</div><button class="del" data-id="${d.id}">✕</button></div>`).join('')||'<div class="card center muted">Додайте першу мрію 🥰</div>';
    box.querySelectorAll('.del').forEach(b=>b.onclick=()=>R('dreams/'+b.dataset.id).remove());
  });
}
try{bindDreams()}catch(e){}

// Widget love button
if($('btn-widget-love'))$('btn-widget-love').onclick=()=>{
  const text='Я поруч моє серденько ♥️♥️♥️';
  pushEvent('signal','🫶 '+text);
  if(db) R('lastSaid/'+S.role).set({text,ts:Date.now()});
  showBanner('❤️ Наш Всесвіт', text);
  toast(text);
  try{navigator.vibrate&&navigator.vibrate([120,40,120,40,200])}catch(e){}
};

// Recording preview helpers
function showRec(label, stream){
  const box=$('rec-preview'); if(!box)return;
  box.classList.add('on');
  if($('rec-label'))$('rec-label').textContent=label;
  const wrap=$('rec-video-wrap');
  if(wrap){
    wrap.innerHTML='';
    if(stream){
      const v=document.createElement('video');
      v.autoplay=true; v.muted=true; v.playsInline=true;
      v.srcObject=stream; v.style.width='140px'; v.style.height='140px'; v.style.borderRadius='50%'; v.style.objectFit='cover';
      wrap.appendChild(v);
    }
  }
}
function hideRec(){
  const box=$('rec-preview'); if(box)box.classList.remove('on');
  const wrap=$('rec-video-wrap'); if(wrap)wrap.innerHTML='';
}

// Re-bind mic with preview
if($('chat-mic')){
  let mediaRec=null, audioChunks=[];
  $('chat-mic').onclick=async()=>{
    if(mediaRec&&mediaRec.state==='recording'){
      mediaRec.stop(); $('chat-mic').textContent='🎤'; hideRec(); return;
    }
    try{
      const stream=await navigator.mediaDevices.getUserMedia({audio:true});
      audioChunks=[]; mediaRec=new MediaRecorder(stream);
      showRec('🎤 Запис голосу…', null);
      mediaRec.ondataavailable=e=>{if(e.data.size)audioChunks.push(e.data)};
      mediaRec.onstop=()=>{
        stream.getTracks().forEach(t=>t.stop()); hideRec();
        const blob=new Blob(audioChunks,{type:'audio/webm'});
        if(blob.size>900000){toast('Занадто довге');return}
        const reader=new FileReader();
        reader.onload=()=>{
          queueOrSend('chat',{type:'voice',audio:reader.result,from:S.role,ts:Date.now()});
          if(db) R('events').push({type:'chat',text:myName()+' надіслав(ла) голосове 🎤',from:S.role,fromName:myName(),ts:Date.now()});
          toast('Голосове надіслано');
        };
        reader.readAsDataURL(blob);
      };
      mediaRec.start(); $('chat-mic').textContent='⏹';
    }catch(err){toast('Немає доступу до мікрофона'); hideRec()}
  };
}

if($('chat-video')){
  let videoRec=null, videoChunks=[], videoStream=null;
  $('chat-video').onclick=async()=>{
    if(videoRec&&videoRec.state==='recording'){
      videoRec.stop(); $('chat-video').textContent='⚪'; return;
    }
    try{
      videoStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:'user',width:480,height:480},audio:true});
      videoChunks=[];
      showRec('⚪ Запис кружечка…', videoStream);
      videoRec=new MediaRecorder(videoStream,{mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')?'video/webm;codecs=vp8,opus':'video/webm'});
      videoRec.ondataavailable=e=>{if(e.data.size)videoChunks.push(e.data)};
      videoRec.onstop=()=>{
        videoStream.getTracks().forEach(t=>t.stop()); hideRec();
        const blob=new Blob(videoChunks,{type:'video/webm'});
        if(blob.size>2500000){toast('Занадто довге відео');return}
        const reader=new FileReader();
        reader.onload=()=>{
          queueOrSend('chat',{type:'video',video:reader.result,from:S.role,ts:Date.now()});
          if(db) R('events').push({type:'chat',text:myName()+' надіслав(ла) відео-кружечок ⚪',from:S.role,fromName:myName(),ts:Date.now()});
          toast('Відео надіслано');
        };
        reader.readAsDataURL(blob);
      };
      videoRec.start();
      $('chat-video').textContent='⏹';
      setTimeout(()=>{ if(videoRec&&videoRec.state==='recording'){videoRec.stop();$('chat-video').textContent='⚪'} },15000);
    }catch(err){toast('Немає доступу до камери'); hideRec()}
  };
}




/* ===== BOOTSTRAP v2.6 — single working init ===== */
(function(){
  'use strict';

  // no copy except chat bubbles + inputs
  document.addEventListener('contextmenu', function(e){
    var t=e.target;
    if(t && t.closest && (t.closest('.bubble') || t.tagName==='INPUT' || t.tagName==='TEXTAREA')) return;
    e.preventDefault();
  }, true);

  function showRec(label, stream){
    var box=$('rec-preview'); if(!box) return;
    box.classList.add('on');
    if($('rec-label')) $('rec-label').textContent=label;
    var wrap=$('rec-video-wrap');
    if(wrap){
      wrap.innerHTML='';
      if(stream){
        var v=document.createElement('video');
        v.autoplay=true; v.muted=true; v.playsInline=true; v.srcObject=stream;
        v.style.cssText='width:140px;height:140px;border-radius:50%;object-fit:cover;background:#000';
        wrap.appendChild(v);
      }
    }
  }
  function hideRec(){
    var box=$('rec-preview'); if(box) box.classList.remove('on');
    var wrap=$('rec-video-wrap'); if(wrap) wrap.innerHTML='';
  }

  function pushChat(payload){
    if(!S.role){ toast('Спочатку оберіть роль'); return; }
    if(!db){ toast('Немає інтернету / Firebase'); return; }
    try {
      R('chat').push(payload);
    } catch(err) {
      toast('Помилка надсилання');
      console.error(err);
    }
  }

  function wire(id, handler){
    var el=$(id);
    if(!el) return null;
    el.onclick = handler;
    return el;
  }

  // --- Emoji ---
  wire('chat-emoji-btn', function(e){
    e.preventDefault();
    var r=$('emoji-row');
    if(!r) return;
    r.style.display = (r.style.display==='none' || r.style.display==='') ? 'flex' : 'none';
  });
  document.querySelectorAll('#emoji-row [data-emoji]').forEach(function(b){
    b.onclick = function(){
      var i=$('chat-input');
      if(i){ i.value += b.getAttribute('data-emoji'); i.focus(); }
    };
  });

  // --- Photo ---
  wire('chat-photo-btn', function(e){
    e.preventDefault();
    var inp=$('chat-photo-input');
    if(inp) inp.click();
  });
  var pi=$('chat-photo-input');
  if(pi){
    pi.onchange = async function(e){
      var f=e.target.files && e.target.files[0];
      if(!f) return;
      try{
        var data = await compress(f, 700, 0.65);
        pushChat({type:'photo', photo:data, from:S.role, ts:Date.now(), seenByOther:false});
        toast('Фото надіслано');
      }catch(err){ toast('Помилка фото'); }
      e.target.value='';
    };
  }

  // --- Voice: MediaRecorder OR file capture fallback ---
  var audioRec=null, audioChunks=[], audioStream=null;
  wire('chat-mic', async function(e){
    e.preventDefault();
    e.stopPropagation();
    var mic=$('chat-mic');
    if(audioRec && audioRec.state==='recording'){
      try{ audioRec.stop(); }catch(err){}
      if(mic) mic.textContent='🎙️';
      return;
    }
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      // fallback
      var cap=$('chat-audio-capture');
      if(cap){ cap.click(); toast('Оберіть аудіофайл'); }
      else toast('Мікрофон недоступний у цій збірці APK');
      return;
    }
    try{
      audioStream = await navigator.mediaDevices.getUserMedia({audio:true, video:false});
      audioChunks=[];
      var mime = MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' :
                 (MediaRecorder.isTypeSupported('audio/mp4') ? 'audio/mp4' : '');
      audioRec = mime ? new MediaRecorder(audioStream,{mimeType:mime}) : new MediaRecorder(audioStream);
      showRec('🎙️ Запис голосу… натисни ще раз', null);
      audioRec.ondataavailable = function(ev){ if(ev.data && ev.data.size) audioChunks.push(ev.data); };
      audioRec.onstop = function(){
        try{ audioStream.getTracks().forEach(function(t){t.stop();}); }catch(err){}
        hideRec();
        if(mic) mic.textContent='🎙️';
        var blob=new Blob(audioChunks, {type: audioRec.mimeType || 'audio/webm'});
        if(blob.size < 200){ toast('Порожній запис'); return; }
        var reader=new FileReader();
        reader.onload = function(){
          pushChat({type:'voice', audio:reader.result, from:S.role, ts:Date.now(), seenByOther:false});
          toast('Голосове надіслано');
        };
        reader.readAsDataURL(blob);
      };
      audioRec.start();
      if(mic) mic.textContent='⏹';
    }catch(err){
      console.error(err);
      toast('Немає доступу до мікрофона. Додай дозвіл RECORD_AUDIO у APK.');
      hideRec();
      var cap=$('chat-audio-capture');
      if(cap) cap.click();
    }
  });

  var ac=$('chat-audio-capture');
  if(ac){
    ac.onchange = async function(e){
      var f=e.target.files && e.target.files[0];
      if(!f) return;
      var reader=new FileReader();
      reader.onload = function(){
        pushChat({type:'voice', audio:reader.result, from:S.role, ts:Date.now(), seenByOther:false});
        toast('Аудіо надіслано');
      };
      reader.readAsDataURL(f);
      e.target.value='';
    };
  }

  // --- Video circle ---
  var videoRec=null, videoChunks=[], videoStream=null;
  wire('chat-video', async function(e){
    e.preventDefault();
    e.stopPropagation();
    var vbtn=$('chat-video');
    if(videoRec && videoRec.state==='recording'){
      try{ videoRec.stop(); }catch(err){}
      if(vbtn) vbtn.textContent='⭕';
      return;
    }
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      var cap=$('chat-video-capture');
      if(cap){ cap.click(); toast('Оберіть відео'); }
      else toast('Камера недоступна у цій збірці APK');
      return;
    }
    try{
      videoStream = await navigator.mediaDevices.getUserMedia({
        audio:true,
        video:{facingMode:'user', width:480, height:480}
      });
      videoChunks=[];
      var mime = MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus') ? 'video/webm;codecs=vp8,opus' :
                 (MediaRecorder.isTypeSupported('video/webm') ? 'video/webm' :
                 (MediaRecorder.isTypeSupported('video/mp4') ? 'video/mp4' : ''));
      videoRec = mime ? new MediaRecorder(videoStream,{mimeType:mime}) : new MediaRecorder(videoStream);
      showRec('⭕ Запис відео… натисни ще раз', videoStream);
      videoRec.ondataavailable = function(ev){ if(ev.data && ev.data.size) videoChunks.push(ev.data); };
      videoRec.onstop = function(){
        try{ videoStream.getTracks().forEach(function(t){t.stop();}); }catch(err){}
        hideRec();
        if(vbtn) vbtn.textContent='⭕';
        var blob=new Blob(videoChunks, {type: videoRec.mimeType || 'video/webm'});
        if(blob.size < 500){ toast('Порожній запис'); return; }
        var reader=new FileReader();
        reader.onload = function(){
          pushChat({type:'video', video:reader.result, from:S.role, ts:Date.now(), seenByOther:false});
          toast('Відео надіслано');
        };
        reader.readAsDataURL(blob);
      };
      videoRec.start();
      if(vbtn) vbtn.textContent='⏹';
      setTimeout(function(){
        if(videoRec && videoRec.state==='recording'){ try{videoRec.stop();}catch(err){} if(vbtn) vbtn.textContent='⭕'; }
      }, 12000);
    }catch(err){
      console.error(err);
      toast('Немає доступу до камери. Додай CAMERA у APK.');
      hideRec();
      var cap=$('chat-video-capture');
      if(cap) cap.click();
    }
  });

  var vc=$('chat-video-capture');
  if(vc){
    vc.onchange = function(e){
      var f=e.target.files && e.target.files[0];
      if(!f) return;
      var reader=new FileReader();
      reader.onload = function(){
        pushChat({type:'video', video:reader.result, from:S.role, ts:Date.now(), seenByOther:false});
        toast('Відео надіслано');
      };
      reader.readAsDataURL(f);
      e.target.value='';
    };
  }

  // --- Send text ---
  function doSend(){
    var input=$('chat-input'); if(!input) return;
    var text=input.value.trim(); if(!text) return;
    input.value='';
    pushChat({text:text, from:S.role, ts:Date.now(), seenByOther:false});
  }
  wire('chat-send', function(e){ e.preventDefault(); doSend(); });
  var cinp=$('chat-input');
  if(cinp){
    cinp.addEventListener('keydown', function(e){
      if(e.key==='Enter'){ e.preventDefault(); doSend(); }
    });
  }

  // --- Features grid ---
  if(typeof renderFeatures==='function') renderFeatures();

  // --- Dock add (re-bind reliably) ---
  wire('btn-dock-add', function(e){
    e.preventDefault();
    var sel=$('dock-add-select');
    if(!sel){ toast('Немає списку'); return; }
    var v=sel.value;
    if(!v){ toast('Оберіть розділ'); return; }
    if(!S.dock) S.dock=[];
    if(S.dock.indexOf(v)>=0){ toast('Вже додано'); return; }
    if(S.dock.length>=6){ toast('Максимум 6'); return; }
    if(!DOCK_META[v]){ toast('Невідомий розділ'); return; }
    S.dock.push(v);
    localStorage.setItem('ns_dock', JSON.stringify(S.dock));
    if(typeof renderDock==='function') renderDock();
    toast('Додано ✦ '+DOCK_META[v].title);
    sel.value='';
  });
  if(typeof renderDock==='function'){
    try{ renderDock(); }catch(err){}
  }

  // --- Widget ---
  wire('btn-widget-love', function(e){
    e.preventDefault();
    if(!S.role){ toast('Спочатку оберіть роль (Котусик / Квіточка)'); return; }
    if(!db){ toast('Немає зʼєднання з Firebase'); return; }
    var text='Я поруч моє серденько ♥️♥️♥️';
    var ts=Date.now();
    var otherRole = S.role==='he' ? 'she' : 'he';
    var otherName = otherRole==='he' ? 'Котусик' : 'Квіточка';
    try{
      R('events').push({type:'widget', text:text, from:S.role, fromName:myName(), ts:ts});
      R('lastSaid/'+S.role).set({text:text, ts:ts});
      R('pushInbox/'+otherRole).push({title:'❤️ '+myName(), body:text, ts:ts, from:S.role});
      toast('Надіслано → '+otherName);
      showBanner('❤️ Надіслано', 'Сигнал для '+otherName);
      try{ navigator.vibrate && navigator.vibrate([150,50,150]); }catch(err){}
    }catch(err){
      toast('Помилка віджета');
      console.error(err);
    }
  });

  // Push inbox listener
  function bindPushInbox(){
    if(!db || !S.role) return;
    R('pushInbox/'+S.role).limitToLast(8).on('child_added', function(snap){
      var v=snap.val(); if(!v || !v.ts) return;
      if(Date.now()-v.ts > 180000) return;
      var key='ns_push_'+snap.key;
      if(localStorage.getItem(key)) return;
      localStorage.setItem(key,'1');
      showBanner(v.title||'❤️ Наш Всесвіт', v.body||'');
      try{
        if(typeof Notification!=='undefined' && Notification.permission==='granted'){
          new Notification(v.title||'Наш Всесвіт', {body:v.body||'', tag:'nash-'+snap.key});
        }
      }catch(err){}
      try{ navigator.vibrate && navigator.vibrate([200,80,200]); }catch(err){}
    });
  }
  setTimeout(bindPushInbox, 2000);
  // re-bind after role enter
  var _origEnter = typeof enter==='function' ? enter : null;
  if(_origEnter){
    window.enter = function(role){
      _origEnter(role);
      setTimeout(bindPushInbox, 500);
      setTimeout(renderFeatures, 300);
      setTimeout(function(){ if(typeof renderDock==='function') renderDock(); }, 300);
    };
  }

  // open features when opening tab
  var _origOpenTab = openTab;
  window.openTab = function(n){
    _origOpenTab(n);
    if(n==='features') renderFeatures();
    if(n==='dock' && typeof renderDock==='function') renderDock();
  };

  console.log('[Nash] bootstrap v2.6 ready');
})();


window.renderFeatures = function(){
  var MAIN = [
    {icon:'🏠', title:'Головна', tab:'home'},
    {icon:'💬', title:'Чат', tab:'chat'},
    {icon:'🖼️', title:'Галерея', tab:'gallery'},
    {icon:'📝', title:'Нотатки', tab:'notes'},
    {icon:'📅', title:'Календар', tab:'calendar'},
    {icon:'📰', title:'Стрічка', tab:'feed'},
    {icon:'🎬', title:'Наші фільми', tab:'movies'},
    {icon:'✦', title:'Швидкий доступ', tab:'dock'}
  ];
  var US = [
    {icon:'❤️', title:'Наші стосунки', sub:'relations'},
    {icon:'📌', title:'Важливі дати', sub:'dates'},
    {icon:'🌎', title:'До зустрічі', sub:'meet'},
    {icon:'🎵', title:'Наша музика', sub:'music'},
    {icon:'📸', title:'Спогади', sub:'memories'},
    {icon:'🥰', title:'Наші мрії', sub:'dreams'},
    {icon:'😊', title:'Мій настрій', sub:'mood'}
  ];
  var MORE = [
    {icon:'🫶', title:'Я поруч', sub:'near'},
    {icon:'📱', title:'Віджет', sub:'widget'},
    {icon:'🔔', title:'Події', sub:'events'}
  ];
  function fill(id, arr){
    var g = document.getElementById(id);
    if(!g) return;
    g.innerHTML = arr.map(function(f,i){
      return '<button type="button" class="func-btn" data-g="'+id+'" data-i="'+i+'"><span class="fi">'+f.icon+'</span><span class="ft">'+f.title+'</span></button>';
    }).join('');
    g.querySelectorAll('.func-btn').forEach(function(btn){
      btn.onclick = function(){
        var list = id==='feat-row-main'?MAIN:(id==='feat-row-us'?US:MORE);
        var f = list[Number(btn.getAttribute('data-i'))];
        if(!f) return;
        if(f.tab) openTab(f.tab);
        else if(f.sub) openSub(f.sub);
      };
    });
  }
  fill('feat-row-main', MAIN);
  fill('feat-row-us', US);
  fill('feat-row-more', MORE);
};


async function checkOnlineUpdate(){
  try{
    const r=await fetch('version.json?v='+Date.now(),{cache:'no-store'});
    if(!r.ok)return;
    const v=await r.json();
    if(v.version && v.version!==S.appVersion){
      showBanner('✨ Доступне оновлення',v.message||('Версія '+v.version));
      setTimeout(()=>{if(confirm('Доступна нова версія «Наш Всесвіт». Оновити зараз?')) location.reload(true)},900);
    }
  }catch(e){}
}
if('serviceWorker' in navigator){navigator.serviceWorker.register('./sw.js').catch(()=>{})}
checkOnlineUpdate();
setInterval(checkOnlineUpdate,5*60*1000);



/* v2.7 extras */
(function(){
  function sendLove(){
    if(!S.role){ toast('Оберіть роль один раз при вході'); return; }
    if(!db){ toast('Немає інтернету'); return; }
    var text='Я поруч моє серденько ♥️♥️♥️';
    var ts=Date.now();
    var otherRole=S.role==='he'?'she':'he';
    var otherName=otherRole==='he'?'Котусик':'Квіточка';
    R('events').push({type:'widget',text:text,from:S.role,fromName:myName(),ts:ts});
    R('lastSaid/'+S.role).set({text:text,ts:ts});
    R('pushInbox/'+otherRole).push({title:'❤️ '+myName(),body:text,ts:ts,from:S.role});
    toast('Надіслано → '+otherName);
    showBanner('❤️ Надіслано', 'Для '+otherName);
  }
  var a=document.getElementById('btn-widget-love');
  var b=document.getElementById('btn-widget-love-dock');
  if(a) a.onclick=function(e){ e.preventDefault(); sendLove(); };
  if(b) b.onclick=function(e){ e.preventDefault(); sendLove(); };
  var inst=document.getElementById('btn-install-widget');
  if(inst) inst.onclick=function(){
    toast('Утримуй іконку додатку / «Додати на головний екран» у браузері');
    try{
      if(window.deferredPrompt){ window.deferredPrompt.prompt(); }
      else if(navigator.share){ navigator.share({title:'Наш Всесвіт', text:'Я поруч моє серденько ♥️', url:location.href}).catch(function(){}); }
    }catch(e){}
  };
  // PWA install prompt capture
  window.addEventListener('beforeinstallprompt', function(e){
    e.preventDefault();
    window.deferredPrompt = e;
  });
  try{ renderFeatures(); }catch(e){}
})();


/* v2.8 back + video upload + chat tools */
(function(){
  // --- Android / browser back: navigate in-app, don't exit ---
  var navStack = ['home'];
  function pushNav(state){
    try{
      history.pushState({ns:true, tab: state.tab||null, sub: state.sub||null}, '');
      navStack.push(state);
      if(navStack.length > 40) navStack.shift();
    }catch(e){}
  }
  // seed
  try{ history.replaceState({ns:true, tab:'home'}, ''); }catch(e){}

  window.addEventListener('popstate', function(e){
    // Prevent app exit: if at root, push state again
    var st = e.state;
    if(st && st.ns){
      if(st.sub && typeof openSub === 'function'){
        // open sub without pushing again
        try{
          hideTabs();
          var el = document.getElementById('sub-'+st.sub);
          if(el){ el.classList.remove('hidden'); el.style.display='block'; }
        }catch(err){}
        return;
      }
      if(st.tab && typeof openTab === 'function'){
        var _ot = openTab;
        // call internal without history push
        try{
          hideTabs();
          var el = document.getElementById('tab-'+st.tab);
          if(el){
            el.classList.remove('hidden');
            el.style.display = st.tab==='chat' ? 'flex' : 'block';
          }
          document.querySelectorAll('.nav button').forEach(function(b){
            b.classList.toggle('on', b.dataset.tab === st.tab);
          });
          if(st.tab==='features' && typeof renderFeatures==='function') renderFeatures();
        }catch(err){}
        return;
      }
    }
    // No more stack — stay in app
    try{ history.pushState({ns:true, tab:'home'}, ''); }catch(err){}
    if(typeof openTab==='function') openTab('home');
  });

  // Wrap openTab to push history
  if(typeof openTab === 'function'){
    var _openTab = openTab;
    window.openTab = function(n){
      _openTab(n);
      pushNav({tab:n});
      if(n==='features'){ try{ renderFeatures(); }catch(e){} }
    };
  }
  if(typeof openSub === 'function'){
    var _openSub = openSub;
    window.openSub = function(n){
      _openSub(n);
      pushNav({sub:n});
    };
  }
  // back buttons in UI
  document.querySelectorAll('.back, [data-back]').forEach(function(b){
    b.addEventListener('click', function(e){
      // let default handler run; also history
    });
  });

  // --- Video: upload only (no recording) ---
  var vbtn = document.getElementById('chat-video-upload') || document.getElementById('chat-video');
  var vfile = document.getElementById('chat-video-file') || document.getElementById('chat-video-capture');
  if(vbtn){
    vbtn.onclick = function(e){
      e.preventDefault();
      e.stopPropagation();
      if(vfile) vfile.click();
      else toast('Немає вибору відео');
    };
  }
  if(vfile){
    vfile.onchange = function(e){
      var f = e.target.files && e.target.files[0];
      if(!f) return;
      if(!S.role){ toast('Оберіть роль'); return; }
      if(f.size > 8*1024*1024){ toast('Відео завелике (макс ~8МБ)'); e.target.value=''; return; }
      toast('Завантаження відео…');
      var reader = new FileReader();
      reader.onload = function(){
        if(!db){ toast('Немає інтернету'); return; }
        try{
          R('chat').push({type:'video', video:reader.result, from:S.role, ts:Date.now(), seenByOther:false});
          toast('Відео надіслано');
        }catch(err){ toast('Помилка надсилання'); }
      };
      reader.onerror = function(){ toast('Не вдалося прочитати відео'); };
      reader.readAsDataURL(f);
      e.target.value='';
    };
  }
  // Disable old video recorder if any leftover handlers
  var oldV = document.getElementById('chat-video');
  if(oldV && oldV.id==='chat-video'){
    oldV.onclick = function(e){
      e.preventDefault();
      if(vfile) vfile.click();
    };
  }

  // Re-wire emoji / photo / mic without button backgrounds (already CSS)
  var emb = document.getElementById('chat-emoji-btn');
  if(emb){
    emb.onclick = function(e){
      e.preventDefault();
      var r = document.getElementById('emoji-row');
      if(r) r.style.display = (r.style.display==='none'||!r.style.display) ? 'flex' : 'none';
    };
  }
  document.querySelectorAll('#emoji-row [data-emoji]').forEach(function(b){
    b.onclick = function(){
      var i = document.getElementById('chat-input');
      if(i){ i.value += b.getAttribute('data-emoji'); i.focus(); }
    };
  });
  var pb = document.getElementById('chat-photo-btn');
  if(pb){
    pb.onclick = function(e){
      e.preventDefault();
      var inp = document.getElementById('chat-photo-input');
      if(inp) inp.click();
    };
  }

  // Features tab in nav
  document.querySelectorAll('.nav button[data-tab="features"]').forEach(function(b){
    b.onclick = function(){ openTab('features'); };
  });
  try{ if(typeof renderFeatures==='function') renderFeatures(); }catch(e){}

  console.log('[Nash] v2.8 ready');
})();


/* v2.8.1 no horizontal swipe on features */
(function(){
  var _touchStartX = 0, _touchStartY = 0;
  // Override swipe: ignore if features or mostly vertical
  document.addEventListener('touchstart', function(e){
    if(!e.touches || !e.touches[0]) return;
    _touchStartX = e.touches[0].clientX;
    _touchStartY = e.touches[0].clientY;
  }, {passive:true});
  // Mark body when on features
  var _ot = window.openTab;
  if(typeof _ot === 'function'){
    window.openTab = function(n){
      _ot(n);
      document.body.classList.toggle('on-features-tab', n==='features');
      var sc = document.getElementById('main-scroll');
      if(sc) sc.classList.toggle('on-features', n==='features');
      if(n==='dock' && typeof renderDock==='function') try{ renderDock(); }catch(e){}
      if(n==='features' && typeof renderFeatures==='function') try{ renderFeatures(); }catch(e){}
    };
  }
  // Block SWIPE_TABS horizontal gesture when features
  if(typeof S !== 'undefined'){
    // patch: if features, disable swipeNav temporarily handled below
  }
  document.addEventListener('touchmove', function(e){
    if(!document.body.classList.contains('on-features-tab')) return;
    if(!e.touches || !e.touches[0]) return;
    var dx = Math.abs(e.touches[0].clientX - _touchStartX);
    var dy = Math.abs(e.touches[0].clientY - _touchStartY);
    // if horizontal dominant on features - prevent tab swipe (allow vertical scroll)
    if(dx > dy && dx > 12){
      // stop propagation to swipe handlers by flag
      window.__blockTabSwipe = true;
    } else {
      window.__blockTabSwipe = false;
    }
  }, {passive:true});
  document.addEventListener('touchend', function(){ window.__blockTabSwipe = false; }, {passive:true});
})();


/* full menu handlers */
document.querySelectorAll('[data-tab-go]').forEach(function(b){
  b.onclick = function(){ openTab(b.getAttribute('data-tab-go')); };
});
document.querySelectorAll('[data-sub]').forEach(function(b){
  b.onclick = function(){ openSub(b.getAttribute('data-sub')); };
});

try{renderFeatures();}catch(e){}

/* v2.9 chat extras */
(function(){
  var searchOn=false;
  var btnS=document.getElementById('chat-fn-search');
  if(btnS) btnS.onclick=function(){
    searchOn=!searchOn;
    if(!searchOn){
      document.querySelectorAll('#chat-area .bubble').forEach(function(b){ b.parentElement.style.display=''; });
      return;
    }
    var q=prompt('Пошук у чаті:');
    if(!q){searchOn=false;return}
    q=q.toLowerCase();
    document.querySelectorAll('#chat-area .bubble').forEach(function(b){
      var show=(b.textContent||'').toLowerCase().indexOf(q)>=0;
      if(b.parentElement) b.parentElement.style.display=show?'':'none';
    });
  };
  var btnE=document.getElementById('chat-fn-export');
  if(btnE) btnE.onclick=function(){
    var t='--- Наш чат ---\n\n';
    document.querySelectorAll('#chat-area .bubble').forEach(function(b){
      t+=b.textContent+'\n';
    });
    var a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([t],{type:'text/plain;charset=utf-8'}));
    a.download='nash-chat.txt'; a.click();
  };
  var btnL=document.getElementById('chat-fn-love');
  if(btnL) btnL.onclick=function(){
    if(!S.role||!db){toast('Немає зʼєднання');return}
    var text='Я поруч моє серденько ♥️♥️♥️';
    R('chat').push({text:'🫶 '+text,from:S.role,ts:Date.now(),seenByOther:false});
    R('pushInbox/'+(S.role==='he'?'she':'he')).push({title:'❤️ '+(S.role==='he'?'Котусик':'Квіточка'),body:text,ts:Date.now()});
    toast('Надіслано ❤️');
  };
})();


/* USER modern chat functions */
(function(){
  var soundOn = true;
  function playBeep(){
    if(!soundOn) return;
    try{
      var ctx = new (window.AudioContext||window.webkitAudioContext)();
      var osc = ctx.createOscillator(); var gain = ctx.createGain();
      osc.connect(gain); gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(587.33, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      osc.start(); osc.stop(ctx.currentTime+0.1);
    }catch(e){}
  }
  var th = document.getElementById('chat-fn-theme');
  if(th) th.onclick = function(){
    document.body.classList.toggle('chat-dark');
    toast(document.body.classList.contains('chat-dark') ? 'Темна тема чату' : 'Світла тема чату');
  };
  var sb = document.getElementById('chat-fn-search');
  var box = document.getElementById('chat-search-box');
  var sin = document.getElementById('chat-search-input');
  if(sb && box) sb.onclick = function(){
    box.style.display = box.style.display === 'block' ? 'none' : 'block';
    if(box.style.display === 'block' && sin) sin.focus();
    else if(sin){ sin.value=''; filterChat(''); }
  };
  function filterChat(q){
    q = (q||'').toLowerCase();
    document.querySelectorAll('#chat-area .bubble').forEach(function(b){
      var t = (b.textContent||'').toLowerCase();
      var show = !q || t.indexOf(q) >= 0;
      var row = b.closest ? b.closest('div') : b.parentElement;
      if(row) row.style.display = show ? '' : 'none';
    });
  }
  if(sin) sin.oninput = function(){ filterChat(this.value); };

  var ex = document.getElementById('chat-fn-export');
  if(ex) ex.onclick = function(){
    var t = '--- Наш чат ---\n\n';
    document.querySelectorAll('#chat-area .bubble').forEach(function(b){
      var tm = b.querySelector('.tm');
      t += (tm ? tm.textContent+' ' : '') + b.textContent + '\n';
    });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([t], {type:'text/plain;charset=utf-8'}));
    a.download = 'nash-chat-'+Date.now()+'.txt';
    a.click();
    toast('Експорт збережено');
  };

  var love = document.getElementById('chat-fn-love');
  if(love) love.onclick = function(){
    if(!S.role || !db){ toast('Немає зʼєднання'); return; }
    var text = 'Я поруч моє серденько ♥️♥️♥️';
    R('chat').push({text:'🫶 '+text, from:S.role, ts:Date.now(), seenByOther:false});
    R('pushInbox/'+(S.role==='he'?'she':'he')).push({title:'❤️ '+(S.role==='he'?'Котусик':'Квіточка'), body:text, ts:Date.now()});
    toast('Надіслано ❤️');
    playBeep();
  };

  var snd = document.getElementById('chat-fn-sound');
  if(snd) snd.onclick = function(){
    soundOn = !soundOn;
    toast(soundOn ? 'Звук увімкнено' : 'Звук вимкнено');
  };

  // update avatar/title when role known
  function refreshChatHeader(){
    var other = S.role==='he' ? 'she' : 'he';
    var title = document.getElementById('chat-title');
    var av = document.getElementById('chat-avatar');
    if(title) title.textContent = (other==='she'?'🌸 Квіточка':'🐱 Котусик');
    if(av) av.textContent = other==='she'?'🌸':'🐱';
  }
  var _ot = window.openTab;
  if(typeof _ot === 'function'){
    window.openTab = function(n){
      _ot(n);
      if(n==='chat') refreshChatHeader();
    };
  }
  setTimeout(refreshChatHeader, 500);
  window.__chatPlayBeep = playBeep;
  
document.querySelectorAll('#tab-chat [data-tab-go]').forEach(function(b){
  b.onclick = function(){ openTab(b.getAttribute('data-tab-go')); };
});
document.querySelectorAll('#tab-chat [data-sub]').forEach(function(b){
  b.onclick = function(){ openSub(b.getAttribute('data-sub')); };
});

  console.log('[Nash] user modern chat UI active');
})();

if(S.role==='he'||S.role==='she'){
  enter(S.role); // роль уже збережена — більше не питати
} else show('sc-welcome');

(function(){
'use strict';
const $=id=>document.getElementById(id);
const hasDB=()=>typeof db!=='undefined'&&db&&typeof S!=='undefined'&&S.role;
const esc2=v=>String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const roleName=r=>r==='he'?'Котусик':'Квіточка';
const otherRole=()=>S.role==='he'?'she':'he';

/* ---------- 1. CHAT: single reliable renderer/listener ---------- */
function renderChatFinal(snap){
  const area=$('chat-area'); if(!area)return;
  const d=snap.val()||{};
  const arr=Object.keys(d).map(id=>Object.assign({id:id},d[id]||{})).sort((a,b)=>(a.ts||0)-(b.ts||0));
  if(!arr.length){area.innerHTML='<div class="chat-empty" style="margin:auto;text-align:center;padding:30px;color:rgba(255,255,255,.85)"><div style="font-size:44px">💞</div><div style="font-weight:800">Ваш чат поки порожній</div><div style="font-size:12px;margin-top:5px">Напишіть перше повідомлення ❤️</div></div>';return;}
  area.innerHTML=arr.map(m=>{
    const me=m.from===S.role;
    const time=m.ts?new Date(m.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'}):'';
    const seen=me?`<span style="font-size:10px;opacity:.8">${m.seenByOther?'✓✓':'✓'}</span>`:'';
    const del=me?`<button type="button" data-chat-del="${esc2(m.id)}" style="float:right;border:0;background:transparent;color:inherit;opacity:.7">✕</button>`:'';
    let body='';
    if(m.type==='photo'&&m.photo) body=`<img src="${esc2(m.photo)}" alt="Фото" style="display:block;max-width:min(78vw,420px);max-height:55vh;border-radius:15px;object-fit:contain">`;
    else if(m.type==='video'&&m.video) body=`<video src="${esc2(m.video)}" controls playsinline style="display:block;max-width:min(78vw,420px);max-height:55vh;border-radius:15px"></video>`;
    else if(m.type==='voice'&&m.audio) body=`<div>🎙️ Голосове</div><audio controls src="${esc2(m.audio)}" style="max-width:75vw"></audio>`;
    else if(m.type==='sticker') body=`<div style="font-size:38px">${esc2(m.text)}</div>`;
    else body=`<div style="white-space:pre-wrap;overflow-wrap:anywhere">${esc2(m.text||'')}</div>`;
    return `<div class="bubble ${me?'me':'them'}" style="position:relative">${del}${body}<div class="tm" style="display:flex;justify-content:flex-end;gap:4px;align-items:center;margin-top:4px">${time}${seen}</div></div>`;
  }).join('');
  area.querySelectorAll('[data-chat-del]').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(confirm('Видалити повідомлення?'))await R('chat/'+b.dataset.chatDel).remove()});
  requestAnimationFrame(()=>{area.scrollTop=area.scrollHeight});
}
function sendChatFinal(payload){
  if(!hasDB()){toast('Firebase недоступний');return Promise.reject(new Error('Firebase unavailable'))}
  const msg=Object.assign({from:S.role,ts:Date.now(),seenByOther:false},payload||{});
  return R('chat').push(msg).then(()=>R('events').push({type:'chat',text:myName()+': '+(msg.text||'медіа').slice(0,70),from:S.role,fromName:myName(),ts:msg.ts}).catch(()=>{}));
}
window.sendChat=sendChatFinal;
if(hasDB()){
  try{R('chat').off();}catch(e){}
  R('chat').limitToLast(150).on('value',renderChatFinal);
}
const cinF=$('chat-input'), sendF=$('chat-send');
if(sendF)sendF.onclick=async e=>{e.preventDefault();const t=(cinF?.value||'').trim();if(!t)return;try{await sendChatFinal({text:t,type:'text'});if(cinF)cinF.value='';}catch(e){toast('Не вдалося надіслати')};};
if(cinF)cinF.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();sendF?.click()}};
const photoBtn=$('chat-photo-btn'), photoInput=$('chat-photo-input');
if(photoBtn&&photoInput){photoBtn.onclick=e=>{e.preventDefault();photoInput.click()};photoInput.onchange=async e=>{const f=e.target.files?.[0];e.target.value='';if(!f||!hasDB())return;if(!f.type.startsWith('image/'))return toast('Оберіть фото');try{toast('Надсилаємо фото…');const data=await compress(f,1200,.78);await sendChatFinal({type:'photo',photo:data});toast('Фото надіслано ❤️')}catch(err){console.error(err);toast('Помилка відправки фото')}}}

/* ---------- 2. Gallery: per-user rating/comment + delete ---------- */
function renderGalleryFinal(path,rootId,emptyId){
  if(!hasDB())return;
  R(path).off();
  R(path).on('value',snap=>{
    const d=snap.val()||{}, arr=Object.keys(d).map(id=>Object.assign({id:id},d[id]||{})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    const root=$(rootId), empty=$(emptyId);if(!root)return;if(empty)empty.style.display=arr.length?'none':'block';
    root.innerHTML=arr.map(p=>{
      const reviews=p.reviews||{}; const he=reviews.he||{},she=reviews.she||{};
      const review=(r,role)=>`<div class="gallery-review"><b>${role==='he'?'🐱 Котусик':'🌸 Квіточка'}</b>: ${r.rating?('⭐ '+r.rating+'/5'):'—'} ${r.comment?'<div>'+esc2(r.comment)+'</div>':'<div class="muted">Коментар ще не доданий</div>'}${S.role===role?`<button type="button" data-gal-review="${esc2(p.id)}" data-gal-role="${role}">✏️ Змінити</button>`:''}</div>`;
      return `<div class="gi" data-src="${esc2(p.data||'')}" data-cap="${esc2(p.caption||'')}"><img src="${esc2(p.data||'')}" alt="Фото" loading="lazy"><div class="cap">${esc2(p.caption||'')}</div><div class="gallery-actions"><button type="button" data-gal-review="${esc2(p.id)}" data-gal-role="${S.role}" title="Оцінити">⭐</button><button type="button" data-gal-del="${esc2(p.id)}" title="Видалити">🗑️</button></div>${review(he,'he')}${review(she,'she')}</div>`;
    }).join('');
    root.querySelectorAll('[data-gal-del]').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(confirm('Видалити фото?')){await R(path+'/'+b.dataset.galDel).remove();toast('Фото видалено 🗑️')}});
    root.querySelectorAll('[data-gal-review]').forEach(b=>b.onclick=async e=>{e.stopPropagation();const id=b.dataset.galReview,role=b.dataset.galRole;if(role!==S.role)return;const old=(d[id]?.reviews?.[role])||{};let rating=prompt('Оцінка фото від 1 до 5:',old.rating||'5');if(rating===null)return;rating=Math.max(1,Math.min(5,Math.round(Number(rating)||5)));const comment=prompt('Коментар до фото:',old.comment||'');if(comment===null)return;await R(path+'/'+id+'/reviews/'+role).set({rating,comment,updatedAt:Date.now(),author:role});toast('Оцінку та коментар збережено ❤️')});
  });
}
if(hasDB()){renderGalleryFinal('gallery','photo-gallery','gal-empty');renderGalleryFinal('galleryArt','art-gallery','art-empty')}

/* ---------- 3. Home: last online under avatars ---------- */
function ensureOnlineLabels(){
  ['he','she'].forEach(role=>{const av=$(role==='he'?'av-he':'av-she');if(!av)return;const wrap=av.parentElement;if(!wrap)return;let el=wrap.querySelector('.online-under');if(!el){el=document.createElement('div');el.className='online-under';wrap.appendChild(el)}});
}
function formatSeen(v){if(!v)return 'ще не був(ла) онлайн';if(v.online)return '🟢 зараз онлайн';return 'був(ла) в мережі '+new Date(v.ts||0).toLocaleString('uk-UA',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});}
function bindPresenceHome(){if(!hasDB())return;ensureOnlineLabels();['he','she'].forEach(role=>{R('presence/'+role).on('value',s=>{const el=($(role==='he'?'av-he':'av-she'))?.parentElement?.querySelector('.online-under');if(el)el.textContent=formatSeen(s.val()||{})})})}
bindPresenceHome();

/* ---------- 4. Gallery picker reusable for Memories/Dreams/Calendar/Notes ---------- */
let galleryCache=[];
function loadGalleryCache(){if(!hasDB())return Promise.resolve();return Promise.all(['gallery','galleryArt'].map(path=>new Promise(resolve=>R(path).once('value',s=>{const d=s.val()||{};Object.keys(d).forEach(id=>{if(d[id]?.data)galleryCache.push({id,path,data:d[id].data,caption:d[id].caption||''})});resolve()}))));}
function pickerHtml(){return `<div id="gallery-picker-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:12000;display:none;padding:18px;overflow:auto"><div style="max-width:520px;margin:30px auto;background:rgba(255,255,255,.96);border-radius:20px;padding:14px;color:#222"><div style="display:flex;justify-content:space-between;align-items:center"><b>🖼 Обрати фото з галереї</b><button id="gp-close" type="button">✕</button></div><div id="gp-grid" class="gallery" style="margin-top:10px"></div><div id="gp-empty" class="muted center" style="display:none;padding:20px">У галереї немає фото</div></div></div>`}
if(!$('gallery-picker-overlay'))document.body.insertAdjacentHTML('beforeend',pickerHtml());
async function chooseGalleryPhoto(onPick){const ov=$('gallery-picker-overlay'),grid=$('gp-grid'),empty=$('gp-empty');if(!ov)return;galleryCache=[];await loadGalleryCache();grid.innerHTML=galleryCache.map((p,i)=>`<button type="button" data-gp="${i}" style="border:0;background:transparent;padding:0"><img src="${esc2(p.data)}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:12px"></button>`).join('');empty.style.display=galleryCache.length?'none':'block';ov.style.display='block';const close=()=>{ov.style.display='none'};$('gp-close').onclick=close;grid.querySelectorAll('[data-gp]').forEach(b=>b.onclick=()=>{const p=galleryCache[+b.dataset.gp];close();onPick(p.data)})}
function addPickerButton(inputId, label){const input=$(inputId);if(!input)return;const parent=input.parentElement;if(!parent||parent.querySelector('.gallery-source-btn'))return;const b=document.createElement('button');b.type='button';b.className='btn btn-o gallery-source-btn';b.textContent='🖼 '+label+' з галереї';parent.appendChild(b);b.onclick=()=>chooseGalleryPhoto(data=>{if(inputId==='mem-photo'){window.__memGalleryPhotos=window.__memGalleryPhotos||[];window.__memGalleryPhotos.push(data);if(typeof memPhotos!=='undefined')memPhotos.push(data);$('mem-photo-prev').innerHTML=(window.__memGalleryPhotos||[]).map(x=>`<div class="gi"><img src="${x}"></div>`).join('')}else if(inputId==='dream-photo'){window.dreamPhotoData=data;$('dream-photo-prev').innerHTML=`<img src="${data}" style="max-width:100%;border-radius:12px">`}else if(inputId==='cal-photo'){window.calPhotoData=data;$('cal-photo-prev').innerHTML=`<img src="${data}" style="max-width:100%;border-radius:12px">`}})}
addPickerButton('mem-photo','Додати');addPickerButton('dream-photo','Вибрати');addPickerButton('cal-photo','Вибрати');

/* Notes: attach a gallery photo and save it with the note */
const noteInput=$('note-input');if(noteInput){const parent=noteInput.parentElement?.parentElement;if(parent&&!parent.querySelector('#note-gallery-btn')){const b=document.createElement('button');b.id='note-gallery-btn';b.type='button';b.className='btn btn-o gallery-source-btn';b.textContent='🖼 Додати фото з галереї';parent.appendChild(b);b.onclick=()=>chooseGalleryPhoto(data=>{window.noteGalleryPhoto=data;let pr=$('note-gallery-preview');if(!pr){pr=document.createElement('div');pr.id='note-gallery-preview';pr.style.marginTop='8px';parent.appendChild(pr)}pr.innerHTML=`<img src="${data}" style="max-width:180px;border-radius:12px">`})}}
if($('btn-add-note'))$('btn-add-note').onclick=async()=>{const t=($('note-input')?.value||'').trim();if(!t&&!window.noteGalleryPhoto)return;if(!hasDB())return toast('Firebase недоступний');await R('notes').push({text:t,photo:window.noteGalleryPhoto||'',who:S.role,fromName:myName(),date:new Date().toLocaleString('uk-UA'),ts:Date.now()});$('note-input').value='';window.noteGalleryPhoto='';$('note-gallery-preview')?.remove();toast('Нотатку збережено ❤️')};

/* Render note photos if notes renderer exists */
if(hasDB())R('notes').on('value',snap=>{const d=snap.val()||{},arr=Object.keys(d).map(id=>Object.assign({id},d[id]||{})).sort((a,b)=>(b.ts||0)-(a.ts||0));const box=$('notes-list'),empty=$('notes-empty');if(!box)return;if(empty)empty.style.display=arr.length?'none':'block';box.innerHTML=arr.map(n=>`<div class="card"><div style="white-space:pre-wrap">${esc2(n.text||'')}</div>${n.photo?`<img src="${esc2(n.photo)}" style="max-width:100%;border-radius:14px;margin-top:8px">`:''}<div class="muted" style="margin-top:6px">${esc2(n.fromName||roleName(n.who))} · ${esc2(n.date||'')}</div><button class="del" data-note-final="${esc2(n.id)}">✕</button></div>`).join('');box.querySelectorAll('[data-note-final]').forEach(b=>b.onclick=()=>{if(confirm('Видалити нотатку?'))R('notes/'+b.dataset.noteFinal).remove()})});

/* Force only application background, never chat background */
try{localStorage.removeItem('ns_chat_bg')}catch(e){};
try{S.chatBg=''}catch(e){}

console.log('[Nash Universe] user requested final fixes loaded');
})();


(function(){
  'use strict';
  const q=id=>document.getElementById(id);
  const roleName=r=>r==='he'?'Котусик':'Квіточка';
  const other=()=>S.role==='he'?'she':'he';
  const escv=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
  // Re-apply application background to chat whenever a tab opens. No chat background is used.
  function syncChatBackground(){
    const bg=getComputedStyle(document.body).backgroundImage;
    const chat=q('tab-chat');
    if(chat){chat.style.background='transparent'; chat.style.backgroundImage='none';}
  }
  // Profile photo + online/last seen in chat header.
  function syncChatProfile(){
    if(typeof db==='undefined'||!db||!S.role)return;
    const r=other();
    R('users/'+r).once('value').then(s=>{
      const u=s.val()||{};
      const av=q('chat-avatar'), title=q('chat-title'), status=q('chat-status');
      if(title) title.textContent='❤️ '+(u.name||roleName(r));
      if(av){
        const photo=u.photo || (S.photos&&S.photos[r]) || '';
        av.innerHTML=photo ? '<img src="'+escv(photo)+'" class="chat-avatar" alt="">' : (r==='he'?'🐱':'🌸');
      }
      if(status && u.lastSeen){
        const online=Date.now()-Number(u.lastSeen)<45000;
        status.textContent=online?'онлайн':'був(ла) в мережі '+new Date(Number(u.lastSeen)).toLocaleString('uk-UA',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});
      }
    }).catch(()=>{});
  }
  // Make unread count persistent and mark messages read only when chat is actually visible.
  function updateChatUnread(arr){
    const myLast=Number(localStorage.getItem('ns_last_read_chat')||0);
    const open=q('tab-chat')&&!q('tab-chat').classList.contains('hidden');
    const unread=arr.filter(m=>m.from!==S.role && !m.seenByOther && Number(m.ts||0)>myLast).length;
    const badge=q('chat-unread');
    if(badge){badge.textContent=String(unread);badge.classList.toggle('on',unread>0);}
    S.unreadChat=unread;
    if(open && arr.length){
      const last=Number(arr[arr.length-1].ts||0);
      if(last){localStorage.setItem('ns_last_read_chat',String(last));}
      arr.forEach(m=>{if(m.from!==S.role&&!m.seenByOther)R('chat/'+m.id+'/seenByOther').set(true);});
      if(badge){badge.textContent='0';badge.classList.remove('on');}
      S.unreadChat=0;
    }
  }
  // When the existing renderer is used, make sure it can scroll and refresh unread state.
  if(typeof db!=='undefined'&&db&&typeof R==='function'){
    R('chat').limitToLast(150).on('value',snap=>{
      const d=snap.val()||{}; const arr=Object.keys(d).map(id=>({id,...(d[id]||{})})).sort((a,b)=>(a.ts||0)-(b.ts||0));
      updateChatUnread(arr);
      syncChatProfile();
      syncChatBackground();
    });
    R('users/'+other()).on('value',()=>syncChatProfile());
  }
  // Do not add chat events to Last Moments. Existing event renderer already filters type=chat; this makes it explicit.
  if(typeof db!=='undefined'&&db){
    R('events').limitToLast(80).on('value',snap=>{
      const d=snap.val()||{};
      const arr=Object.keys(d).map(id=>({id,...(d[id]||{})})).filter(e=>e.type!=='chat').sort((a,b)=>(b.ts||0)-(a.ts||0));
      const el=q('last-events-home');
      if(el){el.innerHTML=arr.slice(0,4).map(e=>'<div class="feed-item" style="margin-bottom:6px"><b>'+escv(e.text)+'</b><div class="muted">'+escv(e.fromName||roleName(e.from||''))+' · '+new Date(Number(e.ts||Date.now())).toLocaleString('uk-UA')+'</div></div>').join('')||'<div class="muted">Поки тихо…</div>';}
      const one=q('last-event-text');
      if(one&&arr[0]) one.textContent=escv(arr[0].text)+' · '+(arr[0].fromName||roleName(arr[0].from||''))+' · '+new Date(Number(arr[0].ts||Date.now())).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'});
    });
  }
  document.addEventListener('click',e=>{
    const tab=e.target.closest('[data-tab]');
    if(tab && tab.dataset.tab==='chat') setTimeout(syncChatBackground,50);
  },true);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden){syncChatProfile();syncChatBackground();}});
})();


(function(){
  let startY=0;
  document.addEventListener('touchstart', function(e){ if(e.touches && e.touches.length) startY=e.touches[0].clientY; }, {passive:true});
  document.addEventListener('touchmove', function(e){
    const scroller=e.target.closest && e.target.closest('.chat-messages,#messages-list,.messages-list');
    if(scroller) return;
    if(window.scrollY<=0 && e.touches && e.touches[0].clientY>startY) e.preventDefault();
  }, {passive:false});
  document.addEventListener('gesturestart', function(e){ e.preventDefault(); }, {passive:false});
})();


(function(){
  /* Pull-to-refresh blocker: only block downward pull when the page itself is at the top.
     The chat scroller remains independently scrollable in both directions. */
  let startY=0,startX=0;
  document.addEventListener('touchstart',function(e){
    const t=e.touches&&e.touches[0]; if(!t)return; startY=t.clientY; startX=t.clientX;
  },{passive:true});
  document.addEventListener('touchmove',function(e){
    const t=e.touches&&e.touches[0]; if(!t)return;
    const dy=t.clientY-startY, dx=t.clientX-startX;
    if(Math.abs(dy)<=Math.abs(dx))return;
    const chat=e.target.closest && e.target.closest('#chat-area,.messages-container');
    if(chat){
      if(chat.scrollTop<=0 && dy>0 && e.cancelable) e.preventDefault();
      return;
    }
    if(dy>0 && window.scrollY<=0 && e.cancelable) e.preventDefault();
  },{passive:false});

  /* Per-user photo ratings/comments. */
  const roleName2=r=>r==='he'?'🐱 Котусик':'🌸 Квіточка';
  const esc2=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function getRef(path){return (typeof R==='function')?R(path):null}
  function renderRatedGallery(path,rootId,emptyId){
    const root=document.getElementById(rootId), empty=document.getElementById(emptyId); if(!root||!getRef(path))return;
    getRef(path).on('value',function(snap){
      const d=snap.val()||{}, arr=Object.keys(d).map(id=>Object.assign({id},d[id]||{})).filter(x=>x.data).sort((a,b)=>(b.ts||0)-(a.ts||0));
      if(empty)empty.style.display=arr.length?'none':'block';
      root.innerHTML=arr.map(p=>{
        const he=p.reviews&&p.reviews.he||{}, sh=p.reviews&&p.reviews.she||{};
        const stars=r=>r.rating?'⭐'.repeat(Math.max(0,Math.min(5,Number(r.rating))))+' '+r.rating+'/5':'Оцінки ще немає';
        const review=(role,r)=>`<div class="gallery-review-user"><b>${roleName2(role)}</b><br>${esc2(stars(r))}<br>${r.comment?esc2(r.comment):'<span style="opacity:.7">Коментар ще не доданий</span>'}${(typeof S!=='undefined'&&S.role===role)?`<br><button type="button" class="btn btn-o gal-review-edit" data-id="${esc2(p.id)}" data-path="${esc2(path)}" data-role="${role}">✏️ ${r.rating?'Змінити':'Додати'}</button>`:''}</div>`;
        return `<div class="gi" style="position:relative" data-rated-id="${esc2(p.id)}"><img src="${esc2(p.data)}" alt="Фото" loading="lazy"><div class="cap">${esc2(p.caption||'')}</div>${review('he',he)}${review('she',sh)}<button type="button" class="gal-del-rated" data-id="${esc2(p.id)}" data-path="${esc2(path)}" style="position:absolute;top:5px;right:5px;z-index:8">🗑️</button></div>`;
      }).join('');
      root.querySelectorAll('.gal-review-edit').forEach(b=>b.onclick=async function(e){e.stopPropagation();if(typeof S==='undefined'||S.role!==b.dataset.role)return;const old=(d[b.dataset.id]?.reviews?.[b.dataset.role])||{};let n=prompt('Оцінка фото від 1 до 5:',old.rating||'5');if(n===null)return;n=Math.max(1,Math.min(5,Math.round(Number(n)||5)));let c=prompt('Коментар до фото:',old.comment||'');if(c===null)return;try{await getRef(b.dataset.path+'/'+b.dataset.id+'/reviews/'+b.dataset.role).set({rating:n,comment:c,author:b.dataset.role,updatedAt:Date.now()});if(typeof toast==='function')toast('Оцінку та коментар збережено ⭐❤️')}catch(err){console.error(err);if(typeof toast==='function')toast('Не вдалося зберегти оцінку')}});
      root.querySelectorAll('.gal-del-rated').forEach(b=>b.onclick=async function(e){e.stopPropagation();if(!confirm('Видалити це фото?'))return;try{await getRef(b.dataset.path+'/'+b.dataset.id).remove();if(typeof toast==='function')toast('Фото видалено')}catch(err){console.error(err);if(typeof toast==='function')toast('Не вдалося видалити фото')}});
    });
  }
  function start(){renderRatedGallery('gallery','photo-gallery','gal-empty');renderRatedGallery('galleryArt','art-gallery','art-empty');}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();


(function(){
'use strict';
/* Do not let old document-level pull/swipe handlers cancel native vertical scrolling. */
function isVerticalScroller(t){return !!(t&&t.closest&&t.closest('#main-scroll,.screen.on>.scroll,#tab-chat .messages-container,#tab-chat .chat-area,#chat-area,.gallery-picker-overlay'))}
document.addEventListener('touchmove',function(e){
  if(!e.touches||!e.touches[0])return;
  if(isVerticalScroller(e.target)){
    /* Keep native scrolling; prevent old bubbling handlers from hijacking it. */
    e.stopImmediatePropagation();
  }
},{capture:true,passive:true});
/* Make every scroll container recover after tab changes. */
function fixScrollers(){
  document.querySelectorAll('#main-scroll,.screen.on>.scroll,#tab-chat .messages-container,#tab-chat .chat-area,#chat-area').forEach(function(el){
    el.style.touchAction='pan-y';el.style.overflowY='auto';el.style.overflowX='hidden';
  });
}
fixScrollers();
var oldOpen=window.openTab;
if(typeof oldOpen==='function')window.openTab=function(n){var r=oldOpen.apply(this,arguments);setTimeout(fixScrollers,0);return r};

/* Replace gallery rendering with robust per-photo reviews + glass delete icon. */
if(typeof renderGalleryFinal==='function'){
  window.renderGalleryFinalV13=function(path,rootId,emptyId){
    if(typeof hasDB!=='function'||!hasDB())return;
    R(path).off();
    R(path).on('value',function(snap){
      var d=snap.val()||{},arr=Object.keys(d).map(function(id){return Object.assign({id:id},d[id]||{})}).filter(function(p){return !!p.data}).sort(function(a,b){return (b.ts||0)-(a.ts||0)});
      var root=document.getElementById(rootId),empty=document.getElementById(emptyId);if(!root)return;
      if(empty)empty.style.display=arr.length?'none':'block';
      root.innerHTML=arr.map(function(p){
        var reviews=p.reviews||{},he=reviews.he||{},she=reviews.she||{};
        function review(r,role){
          var name=role==='he'?'🐱 Котусик':'🌸 Квіточка';
          var rating=r.rating?('⭐ '+r.rating+'/5'):'Оцінки ще немає';
          var comment=r.comment?'<div style="margin-top:3px;overflow-wrap:anywhere">💬 '+esc2(r.comment)+'</div>':'<div class="muted" style="margin-top:3px">💬 Коментар ще не доданий</div>';
          var edit=S.role===role?'<button type="button" data-gal-review="'+esc2(p.id)+'" data-gal-role="'+role+'" style="margin-top:5px">✏️ Змінити</button>':'';
          return '<div class="gallery-review"><b>'+name+'</b><div>'+rating+'</div>'+comment+edit+'</div>';
        }
        return '<div class="gi" data-src="'+esc2(p.data)+'" data-cap="'+esc2(p.caption||'')+'"><img src="'+esc2(p.data)+'" alt="Фото" loading="lazy"><div class="cap">'+esc2(p.caption||'')+'</div><div class="gallery-actions"><button type="button" data-gal-review="'+esc2(p.id)+'" data-gal-role="'+esc2(S.role)+'" title="Оцінити фото">⭐</button><button type="button" class="gal-delete" data-gal-del="'+esc2(p.id)+'" title="Видалити фото" aria-label="Видалити фото">⌫</button></div>'+review(he,'he')+review(she,'she')+'</div>';
      }).join('');
      root.querySelectorAll('[data-gal-del]').forEach(function(b){b.onclick=async function(e){e.preventDefault();e.stopPropagation();if(!confirm('Видалити фото?'))return;try{await R(path+'/'+b.dataset.galDel).remove();toast('Фото видалено ❤️')}catch(err){toast('Не вдалося видалити фото')}}});
      root.querySelectorAll('[data-gal-review]').forEach(function(b){b.onclick=async function(e){e.preventDefault();e.stopPropagation();var id=b.dataset.galReview,role=b.dataset.galRole;if(role!==S.role)return;var old=(d[id]&&d[id].reviews&&d[id].reviews[role])||{};var rating=prompt('Оцінка фото від 1 до 5:',old.rating||'');if(rating===null)return;rating=Math.round(Number(rating));if(!Number.isFinite(rating)||rating<1||rating>5){toast('Оцінка має бути від 1 до 5');return}var comment=prompt('Коментар до фото:',old.comment||'');if(comment===null)return;try{await R(path+'/'+id+'/reviews/'+role).set({rating:rating,comment:comment,updatedAt:Date.now(),author:role});toast('Оцінку та коментар збережено ❤️')}catch(err){toast('Не вдалося зберегти')}}});
      root.querySelectorAll('.gi').forEach(function(el){el.onclick=function(e){if(e.target.closest&&e.target.closest('button'))return;if(typeof openLightbox==='function')openLightbox(el.dataset.src,el.dataset.cap,el.querySelector('[data-gal-del]')?.dataset.galDel)}});
    });
  };
  renderGalleryFinalV13('gallery','photo-gallery','gal-empty');
  renderGalleryFinalV13('galleryArt','art-gallery','art-empty');
}

/* Gallery upload: reliably add to selected album and report errors. */
var gi=document.getElementById('gal-input'),ga=document.getElementById('btn-add-gal');
if(ga&&gi){ga.onclick=function(e){e.preventDefault();gi.click()};gi.onchange=async function(e){var files=Array.from(e.target.files||[]);e.target.value='';if(!files.length)return;if(typeof hasDB==='function'&&!hasDB()){toast('Firebase недоступний');return}var target=document.getElementById('gallery-target')?.value==='art'?'galleryArt':'gallery';var ok=0;toast('Додаємо фото…');for(var f of files.slice(0,12)){try{if(!f.type||!f.type.startsWith('image/'))continue;var data=await compress(f,1100,.78);await R(target).push({data:data,caption:'',from:S.role,ts:Date.now()});ok++}catch(err){console.error(err)}}if(ok){try{pushEvent('gallery','🖼 Нові фото в галереї')}catch(_){}toast('Додано фото: '+ok+' ❤️')}else toast('Не вдалося додати фото')}
}
/* Picker button: ensure all gallery-source buttons remain clickable. */
if(typeof addPickerButton==='function'){addPickerButton('mem-photo','Додати');addPickerButton('dream-photo','Вибрати');addPickerButton('cal-photo','Вибрати');}
})();


(function(){
  window.addEventListener('error', function(e){
    try { console.error('[Nash] runtime error:', e.error || e.message); } catch(_) {}
  });
  window.addEventListener('unhandledrejection', function(e){
    try { console.error('[Nash] promise error:', e.reason); } catch(_) {}
  });
})();


/* v4.1 stable patch */
(function(){
  // All = one clean list. Settings remain only top-right in All.
  window.renderFeatures=function(){
    var list=[
      ['🏠','Головна','tab','home'],['💬','Чат','tab','chat'],['📝','Нотатки','tab','notes'],['📅','Календар','tab','calendar'],
      ['🖼️','Галерея','tab','gallery'],['✨','Стрічка','tab','feed'],['🎬','Наші фільми','tab','movies'],['✦','Наші розділи','tab','dock'],
      ['❤️','Наші стосунки','sub','relations'],['📌','Важливі дати','sub','dates'],['🌎','До зустрічі','sub','meet'],['🎵','Наша музика','sub','music'],
      ['📸','Спогади','sub','memories'],['🥰','Наші мрії','sub','dreams'],['😊','Мій настрій','sub','mood'],['🫶','Я поруч','sub','near'],
      ['📱','Віджет','sub','widget'],['🔔','Події','sub','events']
    ];
    var wrap=document.getElementById('tab-features'); if(!wrap)return;
    var rows=wrap.querySelectorAll('.all-functions-row');
    var row=rows[0]; if(!row)return;
    rows.forEach(function(r,i){if(i>0)r.innerHTML='';});
    row.innerHTML=list.map(function(x,i){return '<button type="button" class="func-btn v4-list" data-i="'+i+'"><span class="fi">'+x[0]+'</span><span class="ft">'+x[1]+'</span></button>'}).join('');
    row.querySelectorAll('.func-btn').forEach(function(b){b.onclick=function(){var x=list[+b.dataset.i]; if(x[2]==='tab')openTab(x[3]); else openSub(x[3]);}});
    var old=wrap.querySelector('.v4-settings-hint'); if(old)old.remove();
    var h=document.createElement('div');h.className='v4-settings-hint';h.style.cssText='margin-top:10px;text-align:center;color:#6b7280;font-size:12px';h.textContent='⚙️ Налаштування відкриваються кнопкою у правому верхньому куті';wrap.appendChild(h);
  };

  // Notes and calendar are dedicated screens; make feature navigation explicit.
  var oldOpenSub=window.openSub;
  window.openSub=function(n){ oldOpenSub(n); if(n==='settings'){var b=document.getElementById('features-settings-btn');if(b)b.style.display='block';} };

  // Remove any pull-to-refresh gesture while keeping normal vertical scrolling.
  document.documentElement.style.overscrollBehaviorY='none';
  document.body.style.overscrollBehaviorY='none';
  var sc=document.getElementById('main-scroll');
  if(sc){sc.style.overscrollBehaviorY='none';sc.style.touchAction='pan-y';}
  var pullY=0;
  document.addEventListener('touchstart',function(e){if(e.touches&&e.touches[0])pullY=e.touches[0].clientY},{passive:true});
  document.addEventListener('touchmove',function(e){
    if(!e.touches||!e.touches[0])return;
    var y=e.touches[0].clientY;
    var active=document.querySelector('.screen.on #main-scroll');
    if(active && active.scrollTop<=0 && y>pullY && e.cancelable){e.preventDefault();}
  },{passive:false});

  // Gallery: delete buttons in both albums.
  function bindGalleryDelete(root,path){
    if(!root)return;
    root.querySelectorAll('.gal-del').forEach(function(b){b.onclick=function(e){e.preventDefault();e.stopPropagation();if(!db)return; if(confirm('Видалити це фото?')){R(path+'/'+b.dataset.id).remove();toast('Фото видалено');}}});
  }
  function renderGalleryWithDelete(snap){
    var data=snap.val()||{},arr=Object.keys(data).map(function(k){return Object.assign({id:k},data[k])}).sort(function(a,b){return (b.ts||0)-(a.ts||0)});
    var gal=document.getElementById('photo-gallery');if(!gal)return;
    document.getElementById('gal-empty')&&(document.getElementById('gal-empty').style.display=arr.length?'none':'block');
    gal.innerHTML=arr.map(function(g){return '<div class="gi" data-id="'+g.id+'" data-src="'+g.data+'" data-cap="'+esc(g.caption||'')+'"><img src="'+g.data+'" alt=""><div class="cap">'+esc(g.caption||'Натисни для перегляду')+'</div><button class="gal-del" data-id="'+g.id+'" type="button">🗑</button></div>'}).join('');
    gal.querySelectorAll('.gi').forEach(function(el){el.onclick=function(){openLightbox(el.dataset.src,el.dataset.cap,el.dataset.id)}});
    bindGalleryDelete(gal,'gallery');
  }
  if(typeof db!=='undefined'&&db)R('gallery').on('value',renderGalleryWithDelete);
  if(typeof db!=='undefined'&&db)R('galleryArt').on('value',function(snap){
    var data=snap.val()||{},arr=Object.keys(data).map(function(k){return Object.assign({id:k},data[k])}).sort(function(a,b){return (b.ts||0)-(a.ts||0)}),gal=document.getElementById('art-gallery');if(!gal)return;
    document.getElementById('art-empty')&&(document.getElementById('art-empty').style.display=arr.length?'none':'block');
    gal.innerHTML=arr.map(function(g){return '<div class="gi" data-id="'+g.id+'" data-src="'+g.data+'"><img src="'+g.data+'"><button class="gal-del" data-id="'+g.id+'" type="button">🗑</button></div>'}).join('');
    gal.querySelectorAll('.gi').forEach(function(el){el.onclick=function(){openLightbox(el.dataset.src,'')}});
    bindGalleryDelete(gal,'galleryArt');
  });

  // Avatar crop editor: pan + zoom + square crop.
  var ae={img:null,x:0,y:0,scale:1,drag:false,sx:0,sy:0,ox:0,oy:0,role:null};
  var canvas=document.getElementById('avatar-canvas'),ctx=canvas&&canvas.getContext('2d');
  function drawAvatar(){if(!ctx||!ae.img)return;var w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#111';ctx.fillRect(0,0,w,h);var base=Math.max(w/ae.img.width,h/ae.img.height)*ae.scale;var dw=ae.img.width*base,dh=ae.img.height*base;ctx.drawImage(ae.img,(w-dw)/2+ae.x,(h-dh)/2+ae.y,dw,dh);}
  function openAvatarEditor(file,role){
    if(!file||!canvas)return;ae.role=role||S.role;var r=new FileReader();r.onload=function(e){var im=new Image();im.onload=function(){ae.img=im;ae.x=0;ae.y=0;ae.scale=1;drawAvatar();document.getElementById('avatar-editor').classList.add('on')};im.src=e.target.result};r.readAsDataURL(file);
  }
  window.openAvatarEditor=openAvatarEditor;
  if(canvas){canvas.addEventListener('pointerdown',function(e){ae.drag=true;ae.sx=e.clientX;ae.sy=e.clientY;ae.ox=ae.x;ae.oy=ae.y;canvas.setPointerCapture&&canvas.setPointerCapture(e.pointerId)});canvas.addEventListener('pointermove',function(e){if(!ae.drag)return;ae.x=ae.ox+(e.clientX-ae.sx);ae.y=ae.oy+(e.clientY-ae.sy);drawAvatar()});canvas.addEventListener('pointerup',function(){ae.drag=false});canvas.addEventListener('pointercancel',function(){ae.drag=false});}
  document.getElementById('ae-plus')?.addEventListener('click',function(){ae.scale=Math.min(4,ae.scale+.15);drawAvatar()});
  document.getElementById('ae-minus')?.addEventListener('click',function(){ae.scale=Math.max(.5,ae.scale-.15);drawAvatar()});
  document.getElementById('ae-cancel')?.addEventListener('click',function(){document.getElementById('avatar-editor').classList.remove('on')});
  document.getElementById('ae-save')?.addEventListener('click',async function(){if(!ae.img||!ae.role)return;var data=canvas.toDataURL('image/jpeg',.82);try{S.photos[ae.role]=data;setAv(ae.role,data);if(db)await R('users/'+ae.role+'/photo').set(data);document.getElementById('avatar-editor').classList.remove('on');toast('Фото профілю збережено ❤️')}catch(e){toast('Не вдалося зберегти фото')}});
  function hookAvatarInput(id){var el=document.getElementById(id);if(!el)return;el.onchange=function(e){var f=e.target.files&&e.target.files[0];if(f)openAvatarEditor(f,S.role);e.target.value=''};}
  hookAvatarInput('photo-input');hookAvatarInput('settings-profile-input');

  // Telegram-like message actions: tap own message to get copy/delete options.
  var area=document.getElementById('chat-area');
  if(area)area.addEventListener('contextmenu',function(e){var b=e.target.closest('.bubble');if(!b)return;e.preventDefault();var text=(b.innerText||'').replace(/\n\d{1,2}:\d{2}.*$/,'').trim();if(confirm('Скопіювати повідомлення?'))navigator.clipboard?.writeText(text)});

  // Register service worker if hosted over HTTPS. Full background push additionally needs FCM/Web Push credentials.
  if('serviceWorker' in navigator && location.protocol==='https:') navigator.serviceWorker.register('./sw.js').catch(function(){});
  setTimeout(function(){try{renderFeatures()}catch(e){}},100);
})();


/* ===== Nash Universe v7 final feature layer ===== */
(function(){
'use strict';
function $v(id){return document.getElementById(id)}
function dbOK(){return typeof db!=='undefined'&&db&&typeof R==='function'&&typeof S!=='undefined'&&(S.role==='he'||S.role==='she')}
function safeV(v){return typeof esc==='function'?esc(String(v??'')):String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function roleName(r){return r==='he'?'Котусик':'Квіточка'}
function otherRole(){return S.role==='he'?'she':'he'}
function avatarFor(r){
  if(typeof S!=='undefined'&&S.photos&&S.photos[r])return S.photos[r];
  return r==='he'?'🐱':'🌸';
}

/* ---- Chat: profile + last online ---- */
function updateChatHeader(){
 const head=document.querySelector('#tab-chat .chat-head'); if(!head)return;
 const r=otherRole();
 const path='users/'+r;
 R(path).once('value').then(s=>{
   const u=s.val()||{}; const photo=u.photo||avatarFor(r); const name=u.name||roleName(r); const seen=u.lastSeen||0;
   const online=seen && Date.now()-Number(seen)<45000;
   let when='';
   if(seen){const d=new Date(Number(seen));when=online?'🟢 онлайн':'був(ла) в мережі '+d.toLocaleString('uk-UA',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'});}
   let img='';
   if(/^data:image\//.test(photo)||/^https?:/.test(photo)) img='<img class="chat-avatar" src="'+safeV(photo)+'">';
   else img='<div class="chat-avatar" style="display:flex;align-items:center;justify-content:center;font-size:22px">'+safeV(photo)+'</div>';
   head.innerHTML='<div style="display:flex;align-items:center;gap:9px">'+img+'<div><div style="font-weight:800">'+safeV(name)+'</div><div class="chat-online">'+safeV(when)+'</div></div></div>';
 }).catch(()=>{});
}
if(dbOK()){
 R('users/'+otherRole()).on('value',updateChatHeader);
 R('users/'+S.role+'/lastSeen').set(Date.now()).catch(()=>{});
 setInterval(()=>{if(dbOK())R('users/'+S.role+'/lastSeen').set(Date.now()).catch(()=>{})},20000);
}

/* ---- Movies: separate reviews for each user, both visible ---- */
function renderMoviesV7(snap){
 const data=snap.val()||{}; const arr=Object.keys(data).map(id=>Object.assign({id},data[id])).sort((a,b)=>(b.ts||0)-(a.ts||0));
 const todo=arr.filter(f=>!f.done),done=arr.filter(f=>f.done);
 const todoEl=$v('films-todo'),doneEl=$v('films-done');
 if(todoEl)todoEl.innerHTML=todo.map(f=>'<div class="film-item"><div class="t">🎬 '+safeV(f.title)+'</div><div class="s">'+safeV(f.note||'')+'</div><button class="btn btn-o" data-v7-done="'+f.id+'">Подивились ✅</button><button class="del" data-v7-film-del="'+f.id+'">✕</button></div>').join('')||'<div class="muted">Список порожній</div>';
 if(doneEl)doneEl.innerHTML=done.map(f=>{
   const a=f.reviews&&f.reviews.he||{}, b=f.reviews&&f.reviews.she||{};
   const review=(r,title)=>'<div class="film-review" style="margin-top:9px;padding:10px;border-radius:14px;background:rgba(255,255,255,.16)"><b>'+title+'</b><div>⭐ '+(r.rating||'—')+'/5</div><div style="white-space:pre-wrap">'+safeV(r.comment||'Коментар ще не доданий')+'</div><button class="btn btn-o film-review-edit" data-v7-review="'+f.id+'" data-v7-role="'+r.__role+'">'+(r.rating?'Змінити оцінку / коментар':'Додати оцінку / коментар')+'</button></div>';
   a.__role='he'; b.__role='she';
   return '<div class="film-item"><div class="t">🎬 '+safeV(f.title)+'</div><div class="s">Переглянули '+(f.doneAt?new Date(f.doneAt).toLocaleDateString('uk-UA'):'')+'</div>'+review(a,'🐱 Котусик')+review(b,'🌸 Квіточка')+'<button class="del" data-v7-film-del="'+f.id+'">✕</button></div>';
 }).join('')||'<div class="muted">Ще нічого не переглянули</div>';
 document.querySelectorAll('[data-v7-done]').forEach(b=>b.onclick=()=>R('films/'+b.dataset.v7Done).update({done:true,doneAt:Date.now()}));
 document.querySelectorAll('[data-v7-film-del]').forEach(b=>b.onclick=()=>{if(confirm('Видалити фільм?'))R('films/'+b.dataset.v7FilmDel).remove()});
 document.querySelectorAll('.film-review-edit').forEach(b=>b.onclick=async()=>{
   const old=(data[b.dataset.v7Review]&&data[b.dataset.v7Review].reviews&&data[b.dataset.v7Review].reviews[b.dataset.v7Role])||{};
   let rating=prompt('Оцінка '+roleName(b.dataset.v7Role)+' від 1 до 5:',old.rating||'5'); if(rating===null)return;
   rating=Math.max(1,Math.min(5,Math.round(Number(rating)||5)));
   const comment=prompt('Коментар після перегляду:',old.comment||''); if(comment===null)return;
   await R('films/'+b.dataset.v7Review+'/reviews/'+b.dataset.v7Role).set({rating,comment,updatedAt:Date.now(),author:b.dataset.v7Role});
   toast('Збережено ❤️');
 });
}
if(dbOK())R('films').on('value',renderMoviesV7);

/* ---- Gallery: rating, comment, delete, section ---- */
function renderGalleryV7(path,rootId,emptyId){
 R(path).on('value',snap=>{
   const d=snap.val()||{}; const arr=Object.keys(d).map(id=>Object.assign({id},d[id])).sort((a,b)=>(b.ts||0)-(a.ts||0));
   const root=$v(rootId),empty=$v(emptyId); if(!root)return;
   if(empty)empty.style.display=arr.length?'none':'block';
   root.innerHTML=arr.map(p=>'<div class="gi" data-v7-gal-id="'+p.id+'" data-v7-gal-path="'+path+'" data-cap="'+safeV(p.caption||'')+'"><img src="'+safeV(p.data||'')+'"><div class="cap">'+safeV(p.caption||'Без коментаря')+'<br>⭐ '+safeV(p.rating||'—')+'/5</div><div style="position:absolute;top:5px;right:5px;display:flex;gap:4px"><button class="gal-comment" data-id="'+p.id+'">💬</button><button class="gal-rate" data-id="'+p.id+'">⭐</button><button class="gal-del" data-id="'+p.id+'">🗑️</button></div></div>').join('');
   root.querySelectorAll('.gal-del').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(confirm('Видалити це фото?')){await R(path+'/'+b.dataset.id).remove();toast('Фото видалено 🗑️')}});
   root.querySelectorAll('.gal-comment').forEach(b=>b.onclick=async e=>{e.stopPropagation();const old=d[b.dataset.id]?.caption||'';const c=prompt('Коментар під фото:',old);if(c===null)return;await R(path+'/'+b.dataset.id+'/caption').set(c);toast('Коментар збережено ❤️')});
   root.querySelectorAll('.gal-rate').forEach(b=>b.onclick=async e=>{e.stopPropagation();const old=d[b.dataset.id]?.rating||5;let n=prompt('Оцінка фото від 1 до 5:',old);if(n===null)return;n=Math.max(1,Math.min(5,Math.round(Number(n)||5)));await R(path+'/'+b.dataset.id+'/rating').set(n);toast('Оцінку збережено ⭐')});
 });
}
if(dbOK()){renderGalleryV7('gallery','photo-gallery','gal-empty');renderGalleryV7('galleryArt','art-gallery','art-empty');}

/* ---- Gallery upload: choose section + comment ---- */
const gi=$v('gal-input');
if(gi)gi.onchange=async function(e){
 const files=Array.from(e.target.files||[]);e.target.value=''; if(!files.length||!dbOK())return;
 const target=$v('gallery-target')?.value||'photos',path=target==='art'?'galleryArt':'gallery';
 for(const f of files){if(!/^image\//.test(f.type)){toast('Тільки зображення');continue} if(f.size>12*1024*1024){toast('Файл більший за 12 МБ');continue}
   try{const data=await (typeof compress==='function'?compress(f,1400,.82):new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(f)})); const caption=prompt('Коментар під фото (можна пропустити):','')??''; await R(path).push({data,caption,rating:null,section:target,from:S.role,fromName:myName(),ts:Date.now()});}catch(err){console.error(err);toast('Не вдалося зберегти фото')}
 }
 toast('Фото збережено ❤️');
};

/* ---- Make chat profile visible even if original header markup is replaced ---- */
const chatTab=$v('tab-chat');
if(chatTab){chatTab.addEventListener('click',()=>setTimeout(updateChatHeader,50));}

/* ---- Settings persistence: extra settings in Firebase ---- */
function saveSettingV7(key,value){localStorage.setItem('ns_v7_'+key,String(value));if(dbOK())R('settings/'+S.role+'/'+key).set(value).catch(()=>{})}
window.NashV7={saveSetting:saveSettingV7};

console.log('[Nash Universe v7] final layer loaded');
})();


(function(){
  let startY=0;
  document.addEventListener('touchstart', function(e){ if(e.touches && e.touches.length) startY=e.touches[0].clientY; }, {passive:true});
  document.addEventListener('touchmove', function(e){
    const scroller=e.target.closest && e.target.closest('.chat-messages,#messages-list,.messages-list');
    if(scroller) return;
    if(window.scrollY<=0 && e.touches && e.touches[0].clientY>startY) e.preventDefault();
  }, {passive:false});
  document.addEventListener('gesturestart', function(e){ e.preventDefault(); }, {passive:false});
})();


(function(){
  /* Pull-to-refresh blocker: only block downward pull when the page itself is at the top.
     The chat scroller remains independently scrollable in both directions. */
  let startY=0,startX=0;
  document.addEventListener('touchstart',function(e){
    const t=e.touches&&e.touches[0]; if(!t)return; startY=t.clientY; startX=t.clientX;
  },{passive:true});
  document.addEventListener('touchmove',function(e){
    const t=e.touches&&e.touches[0]; if(!t)return;
    const dy=t.clientY-startY, dx=t.clientX-startX;
    if(Math.abs(dy)<=Math.abs(dx))return;
    const chat=e.target.closest && e.target.closest('#chat-area,.messages-container');
    if(chat){
      if(chat.scrollTop<=0 && dy>0 && e.cancelable) e.preventDefault();
      return;
    }
    if(dy>0 && window.scrollY<=0 && e.cancelable) e.preventDefault();
  },{passive:false});

  /* Per-user photo ratings/comments. */
  const roleName2=r=>r==='he'?'🐱 Котусик':'🌸 Квіточка';
  const esc2=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function getRef(path){return (typeof R==='function')?R(path):null}
  function renderRatedGallery(path,rootId,emptyId){
    const root=document.getElementById(rootId), empty=document.getElementById(emptyId); if(!root||!getRef(path))return;
    getRef(path).on('value',function(snap){
      const d=snap.val()||{}, arr=Object.keys(d).map(id=>Object.assign({id},d[id]||{})).filter(x=>x.data).sort((a,b)=>(b.ts||0)-(a.ts||0));
      if(empty)empty.style.display=arr.length?'none':'block';
      root.innerHTML=arr.map(p=>{
        const he=p.reviews&&p.reviews.he||{}, sh=p.reviews&&p.reviews.she||{};
        const stars=r=>r.rating?'⭐'.repeat(Math.max(0,Math.min(5,Number(r.rating))))+' '+r.rating+'/5':'Оцінки ще немає';
        const review=(role,r)=>`<div class="gallery-review-user"><b>${roleName2(role)}</b><br>${esc2(stars(r))}<br>${r.comment?esc2(r.comment):'<span style="opacity:.7">Коментар ще не доданий</span>'}${(typeof S!=='undefined'&&S.role===role)?`<br><button type="button" class="btn btn-o gal-review-edit" data-id="${esc2(p.id)}" data-path="${esc2(path)}" data-role="${role}">✏️ ${r.rating?'Змінити':'Додати'}</button>`:''}</div>`;
        return `<div class="gi" style="position:relative" data-rated-id="${esc2(p.id)}"><img src="${esc2(p.data)}" alt="Фото" loading="lazy"><div class="cap">${esc2(p.caption||'')}</div>${review('he',he)}${review('she',sh)}<button type="button" class="gal-del-rated" data-id="${esc2(p.id)}" data-path="${esc2(path)}" style="position:absolute;top:5px;right:5px;z-index:8">🗑️</button></div>`;
      }).join('');
      root.querySelectorAll('.gal-review-edit').forEach(b=>b.onclick=async function(e){e.stopPropagation();if(typeof S==='undefined'||S.role!==b.dataset.role)return;const old=(d[b.dataset.id]?.reviews?.[b.dataset.role])||{};let n=prompt('Оцінка фото від 1 до 5:',old.rating||'5');if(n===null)return;n=Math.max(1,Math.min(5,Math.round(Number(n)||5)));let c=prompt('Коментар до фото:',old.comment||'');if(c===null)return;try{await getRef(b.dataset.path+'/'+b.dataset.id+'/reviews/'+b.dataset.role).set({rating:n,comment:c,author:b.dataset.role,updatedAt:Date.now()});if(typeof toast==='function')toast('Оцінку та коментар збережено ⭐❤️')}catch(err){console.error(err);if(typeof toast==='function')toast('Не вдалося зберегти оцінку')}});
      root.querySelectorAll('.gal-del-rated').forEach(b=>b.onclick=async function(e){e.stopPropagation();if(!confirm('Видалити це фото?'))return;try{await getRef(b.dataset.path+'/'+b.dataset.id).remove();if(typeof toast==='function')toast('Фото видалено')}catch(err){console.error(err);if(typeof toast==='function')toast('Не вдалося видалити фото')}});
    });
  }
  function start(){renderRatedGallery('gallery','photo-gallery','gal-empty');renderRatedGallery('galleryArt','art-gallery','art-empty');}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();


(function(){
  const $=id=>document.getElementById(id);
  const esc=x=>typeof esc2==='function'?esc2(x):String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  function dbReady(){return typeof hasDB==='function'&&hasDB()&&typeof R==='function'&&typeof S!=='undefined';}
  function roleName2(r){return r==='he'?'🐱 Котусик':'🌸 Квіточка';}

  // Fullscreen image viewer with pinch zoom / wheel zoom / delete.
  if(!$('gallery-lightbox')) document.body.insertAdjacentHTML('beforeend',`<div id="gallery-lightbox"><div class="lb-top"><button class="lb-btn" id="lb-close">✕</button><button class="lb-btn" id="lb-delete">⌫</button></div><img class="lb-img" id="lb-img" draggable="false"><div class="lb-hint">Два пальці — збільшити • Подвійний дотик — масштаб</div></div>`);
  const lb=$('gallery-lightbox'), li=$('lb-img'); let lbPath='',lbId='',scale=1,lastDist=0,lastTap=0;
  function closeLB(){lb.classList.remove('on');li.src='';scale=1;li.style.transform='scale(1)';}
  function openLB(path,id,src){lbPath=path;lbId=id;li.src=src;scale=1;li.style.transform='scale(1)';lb.classList.add('on');}
  $('lb-close').onclick=closeLB;
  $('lb-delete').onclick=async()=>{if(!dbReady()||!lbId)return;if(confirm('Видалити це фото?')){await R(lbPath+'/'+lbId).remove();closeLB();if(typeof toast==='function')toast('Фото видалено');}};
  li.addEventListener('dblclick',()=>{scale=scale>1?1:2;li.style.transform=`scale(${scale})`});
  li.addEventListener('wheel',e=>{e.preventDefault();scale=Math.max(1,Math.min(4,scale+(e.deltaY<0?.2:-.2)));li.style.transform=`scale(${scale})`},{passive:false});
  li.addEventListener('touchstart',e=>{if(e.touches.length===2){lastDist=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);}},{passive:true});
  li.addEventListener('touchmove',e=>{if(e.touches.length===2){e.preventDefault();const d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);if(lastDist){scale=Math.max(1,Math.min(4,scale*d/lastDist));li.style.transform=`scale(${scale})`;}lastDist=d;}},{passive:false});
  lb.addEventListener('click',e=>{if(e.target===lb)closeLB();});

  function attachGallery(root,path){
    if(!root||root.dataset.v14==='1')return; root.dataset.v14='1';
    const bind=()=>{
      root.querySelectorAll('.gi[data-src]').forEach(card=>{
        const img=card.querySelector('img');
        if(img && !img.dataset.lb){img.dataset.lb='1';img.addEventListener('click',e=>{e.stopPropagation();openLB(path,card.dataset.id||'',card.dataset.src||img.src);});}
      });
    };
    bind(); new MutationObserver(bind).observe(root,{childList:true,subtree:true});
  }

  // Replace gallery renderer with a real per-user review editor, keeping Firebase structure.
  window.renderGalleryV14=function(path,rootId,emptyId){
    if(!dbReady())return; const root=$(rootId); if(!root)return; R(path).off();
    R(path).on('value',snap=>{
      const d=snap.val()||{},arr=Object.keys(d).map(id=>Object.assign({id},d[id]||{})).sort((a,b)=>(b.ts||0)-(a.ts||0));
      const empty=$(emptyId); if(empty)empty.style.display=arr.length?'none':'block';
      root.innerHTML=arr.map(p=>{
        const rev=p.reviews||{};
        const review=(role)=>{const r=rev[role]||{}, editable=S.role===role; const stars=[1,2,3,4,5].map(n=>`<button type="button" data-rate="${esc(p.id)}" data-role="${role}" data-n="${n}" aria-label="${n}">${n<=(r.rating||0)?'★':'☆'}</button>`).join(''); return `<div class="gallery-review"><b>${roleName2(role)}</b><div class="review-stars">${stars}</div>${r.comment?`<div style="margin-top:4px">💬 ${esc(r.comment)}</div>`:`<div class="muted">Коментар ще не доданий</div>`}${editable?`<div class="review-edit"><textarea class="review-comment" data-comment="${esc(p.id)}" data-role="${role}" placeholder="Ваш коментар…">${esc(r.comment||'')}</textarea><button class="review-save" type="button" data-save-review="${esc(p.id)}" data-role="${role}">Зберегти</button></div>`:''}</div>`};
        return `<div class="gi" data-id="${esc(p.id)}" data-src="${esc(p.data||'')}" data-cap="${esc(p.caption||'')}" style="margin-bottom:12px"><img src="${esc(p.data||'')}" alt="Фото" loading="lazy"><div class="cap">${esc(p.caption||'')}</div><div class="gallery-actions"><button type="button" data-gal-del="${esc(p.id)}" title="Видалити">⌫</button></div>${review('she')}${review('he')}</div>`;
      }).join('');
      root.querySelectorAll('[data-gal-del]').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(confirm('Видалити фото?')){await R(path+'/'+b.dataset.galDel).remove();if(typeof toast==='function')toast('Фото видалено');}});
      root.querySelectorAll('[data-rate]').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(b.dataset.role!==S.role)return;const id=b.dataset.rate,n=Number(b.dataset.n);await R(path+'/'+id+'/reviews/'+S.role+'/rating').set(n);if(typeof toast==='function')toast('Оцінку збережено ⭐');});
      root.querySelectorAll('[data-save-review]').forEach(b=>b.onclick=async e=>{e.stopPropagation();const ta=root.querySelector(`[data-comment="${CSS.escape(b.dataset.saveReview)}"][data-role="${b.dataset.role}"]`);if(!ta)return;await R(path+'/'+b.dataset.saveReview+'/reviews/'+S.role+'/comment').set(ta.value.trim());await R(path+'/'+b.dataset.saveReview+'/reviews/'+S.role+'/updatedAt').set(Date.now());if(typeof toast==='function')toast('Коментар збережено ❤️');});
      attachGallery(root,path);
    });
  };
  if(dbReady()){window.renderGalleryV14('gallery','photo-gallery','gal-empty');window.renderGalleryV14('galleryArt','art-gallery','art-empty');}

  // Notes: stable gallery picker + save photo even when an older handler overrides the button.
  function setupNotes(){
    const input=$('note-input'), add=$('btn-add-note'); if(!input||!add||!dbReady())return;
    let host=input.parentElement; if(!host)return;
    let btn=$('note-gallery-btn');
    if(!btn){btn=document.createElement('button');btn.id='note-gallery-btn';btn.type='button';btn.className='btn btn-o gallery-source-btn';btn.textContent='🖼 Додати фото з галереї';host.parentElement?.appendChild(btn);}
    btn.onclick=async e=>{e.preventDefault();e.stopPropagation(); if(typeof chooseGalleryPhoto==='function'){chooseGalleryPhoto(data=>{window.noteGalleryPhoto=data;let pr=$('note-gallery-preview');if(!pr){pr=document.createElement('div');pr.id='note-gallery-preview';host.parentElement?.appendChild(pr);}pr.innerHTML=`<img src="${esc(data)}" alt="">`;});return;}
      // fallback picker directly from Firebase
      const items=[]; for(const path of ['gallery','galleryArt']){const s=await R(path).once('value');const d=s.val()||{};Object.keys(d).forEach(id=>d[id]?.data&&items.push(d[id].data));}
      if(!items.length){if(typeof toast==='function')toast('У галереї немає фото');return;}
      const choice=prompt('Введіть номер фото з галереї: 1–'+items.length);const i=Number(choice)-1;if(i<0||i>=items.length)return;window.noteGalleryPhoto=items[i];let pr=$('note-gallery-preview');if(!pr){pr=document.createElement('div');pr.id='note-gallery-preview';host.parentElement?.appendChild(pr);}pr.innerHTML=`<img src="${esc(items[i])}" alt="">`;
    };
    add.onclick=async e=>{e.preventDefault();e.stopPropagation();const t=input.value.trim(),photo=window.noteGalleryPhoto||'';if(!t&&!photo){if(typeof toast==='function')toast('Додайте текст або фото');return;}try{await R('notes').push({text:t,photo,who:S.role,fromName:typeof myName==='function'?myName():'',date:new Date().toLocaleString('uk-UA'),ts:Date.now()});input.value='';window.noteGalleryPhoto='';$('note-gallery-preview')?.remove();if(typeof toast==='function')toast('Нотатку збережено ❤️');}catch(err){console.error(err);if(typeof toast==='function')toast('Не вдалося зберегти нотатку');}};
  }
  setTimeout(setupNotes,300);setTimeout(setupNotes,1200);
})();


(function(){
  'use strict';
  const $=id=>document.getElementById(id);
  const hasDB=()=>typeof db!=='undefined'&&db&&typeof S!=='undefined'&&S.role;
  const safe=v=>String(v==null?'':v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  function setGal(a){
    ['photos','art','add'].forEach(x=>{const b=$('gal-tab-'+x),p=$('gal-panel-'+x);if(b)b.classList.toggle('on',x===a);if(p)p.classList.toggle('hidden',x!==a)});
  }
  $('gal-tab-photos')?.addEventListener('click',()=>setGal('photos'));
  $('gal-tab-art')?.addEventListener('click',()=>setGal('art'));
  $('gal-tab-add')?.addEventListener('click',()=>setGal('add'));

  // Gallery upload with album selection + comment. Uses the same proven Base64/Realtime Database storage.
  const gi=$('gal-input');
  if(gi){
    gi.onchange=async function(e){
      const files=[...(e.target.files||[])].slice(0,12); e.target.value='';
      if(!files.length)return; if(!hasDB()){toast('Firebase недоступний');return;}
      const target=$('gallery-target')?.value||'photos';
      for(const f of files){
        if(!/^image\//.test(f.type)){toast('Можна додавати лише зображення');continue;}
        try{
          const data=await compress(f,1200,.80);
          const comment=prompt('Коментар під фото (можна залишити порожнім):','') ?? '';
          const path=target==='art'?'galleryArt':'gallery';
          await R(path).push({data,caption:comment,from:S.role,fromName:myName(),ts:Date.now()});
        }catch(err){console.error(err);toast('Помилка збереження фото');}
      }
      pushEvent('gallery','🖼 Нові фото додано'); toast('Фото збережено ❤️'); setGal(target);
    };
  }
  function renderGallery(path,rootId,emptyId){
    if(!hasDB())return;
    R(path).on('value',snap=>{
      const data=snap.val()||{}; const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
      const root=$(rootId); if(!root)return; const empty=$(emptyId); if(empty)empty.style.display=arr.length?'none':'block';
      root.innerHTML=arr.map(g=>`<div class="gi" data-id="${safe(g.id)}" data-src="${safe(g.data)}" data-cap="${safe(g.caption||'')}"><img src="${safe(g.data)}" alt=""><div class="cap">${safe(g.caption||'Коментар відсутній')}</div><button type="button" class="gal-comment" data-id="${safe(g.id)}">💬</button><button type="button" class="gal-del" data-id="${safe(g.id)}">🗑</button></div>`).join('');
      root.querySelectorAll('.gi').forEach(card=>{
        card.onclick=e=>{if(e.target.closest('button'))return; if(typeof openLightbox==='function')openLightbox(card.dataset.src,card.dataset.cap,card.dataset.id);};
      });
      root.querySelectorAll('.gal-del').forEach(b=>b.onclick=async e=>{e.stopPropagation();if(!confirm('Видалити це фото?'))return;try{await R(path+'/'+b.dataset.id).remove();toast('Фото видалено');}catch(err){toast('Не вдалося видалити фото')}});
      root.querySelectorAll('.gal-comment').forEach(b=>b.onclick=async e=>{e.stopPropagation();const card=b.closest('.gi');const old=card?.dataset.cap||'';const c=prompt('Коментар під фото:',old);if(c===null)return;try{await R(path+'/'+b.dataset.id+'/caption').set(c);toast('Коментар збережено ❤️')}catch(err){toast('Не вдалося зберегти коментар')}});
    });
  }
  renderGallery('gallery','photo-gallery','gal-empty'); renderGallery('galleryArt','art-gallery','art-empty');

  // Enhanced film reviews: one review per role, both visible on every film.
  function starLine(f,role){
    const r=f.reviews&&f.reviews[role]||{}; const who=role==='he'?'Котусик':'Квіточка';
    return `<div class="film-review"><div class="review-head">${role==='he'?'👨':'👩'} ${who}</div><div class="s">${r.rating?'⭐'.repeat(Number(r.rating))+' '+r.rating+'/5':'Оцінки ще немає'}</div><div class="s">${safe(r.comment||'Коментар ще не доданий')}</div><button type="button" class="btn btn-o film-review-btn" data-film="${safe(f.id)}" data-role="${role}">${r.rating?'Змінити оцінку':'Додати оцінку'} ✍️</button></div>`;
  }
  function renderFilmsEnhanced(snap){
    const data=snap.val()||{}; const arr=Object.keys(data).map(k=>({id:k,...data[k]})).sort((a,b)=>(b.ts||0)-(a.ts||0));
    const todo=arr.filter(f=>!f.done),done=arr.filter(f=>f.done);
    if($('films-todo'))$('films-todo').innerHTML=todo.map(f=>`<div class="film-item"><div class="t">🎬 ${safe(f.title)}</div><div class="s">${safe(f.note||'')}</div><button class="btn btn-o" data-enh-done="${safe(f.id)}" style="margin-top:6px">Подивились ✅</button><button class="del" data-enh-del="${safe(f.id)}">✕</button></div>`).join('')||'<div class="muted">Список порожній</div>';
    if($('films-done'))$('films-done').innerHTML=done.map(f=>`<div class="film-item"><div class="t">🎬 ${safe(f.title)}</div><div class="s">Додано: ${f.fromName?safe(f.fromName):f.from==='he'?'Котусик':'Квіточка'}</div>${starLine(f,'he')}${starLine(f,'she')}<button class="del" data-enh-del="${safe(f.id)}">✕</button></div>`).join('')||'<div class="muted">Ще нічого не переглянули</div>';
    document.querySelectorAll('[data-enh-done]').forEach(b=>b.onclick=async()=>{const id=b.dataset.enhDone;try{await R('films/'+id).update({done:true,doneAt:Date.now()});toast('Фільм позначено як переглянутий');}catch(e){toast('Помилка')}});
    document.querySelectorAll('[data-enh-del]').forEach(b=>b.onclick=async()=>{if(confirm('Видалити фільм?'))await R('films/'+b.dataset.enhDel).remove()});
    document.querySelectorAll('.film-review-btn').forEach(b=>b.onclick=async()=>{const rating=prompt('Оцінка '+(b.dataset.role==='he'?'Котусика':'Квіточки')+' від 1 до 5:','5');if(rating===null)return;const n=Math.max(1,Math.min(5,Number(rating)||5));const comment=prompt('Коментар:', '');if(comment===null)return;try{await R('films/'+b.dataset.film+'/reviews/'+b.dataset.role).set({rating:n,comment,from:S.role,ts:Date.now()});toast('Оцінку і коментар збережено ❤️')}catch(e){toast('Помилка збереження')}});
  }
  if(hasDB())R('films').on('value',renderFilmsEnhanced);

  // More settings, all persisted locally and mirrored to Firebase.
  const settingsCard=document.querySelector('#sub-settings .card:last-child');
  if(settingsCard && !$('extra-settings-card')){
    const d=document.createElement('div'); d.id='extra-settings-card'; d.className='card';
    d.innerHTML=`<div class="h2">🛠 Додаткові налаштування</div><div class="setting-check-grid">
      <div class="setting-row"><div class="setting-main"><div class="setting-title">🔊 Звук</div><div class="setting-desc">Звуковий сигнал для нових подій</div></div><label class="switch"><input type="checkbox" id="set-sound" checked><span class="slider"></span></label></div>
      <div class="setting-row"><div class="setting-main"><div class="setting-title">📳 Вібрація</div><div class="setting-desc">Вібрація під час сигналів</div></div><label class="switch"><input type="checkbox" id="set-vibrate" checked><span class="slider"></span></label></div>
      <div class="setting-row"><div class="setting-main"><div class="setting-title">🕐 Час повідомлень</div><div class="setting-desc">Показувати час біля повідомлень</div></div><label class="switch"><input type="checkbox" id="set-time" checked><span class="slider"></span></label></div>
      <div class="setting-row"><div class="setting-main"><div class="setting-title">✨ Анімації</div><div class="setting-desc">Плавні переходи інтерфейсу</div></div><label class="switch"><input type="checkbox" id="set-anim" checked><span class="slider"></span></label></div>
      <div class="setting-row"><div class="setting-main"><div class="setting-title">💾 Автозбереження</div><div class="setting-desc">Зберігати налаштування одразу після зміни</div></div><label class="switch"><input type="checkbox" id="set-autosave" checked><span class="slider"></span></label></div>
    </div><button class="btn btn-o" id="btn-reset-settings">↺ Скинути додаткові налаштування</button>`;
    settingsCard.parentNode.insertBefore(d,settingsCard);
  }
  const defaults={sound:true,vibrate:true,time:true,anim:true,autosave:true};
  function readExtra(){Object.keys(defaults).forEach(k=>{const e=$('set-'+k);if(e)e.checked=localStorage.getItem('ns_set_'+k)!=='0'})}
  function saveExtra(){const obj={};Object.keys(defaults).forEach(k=>{const e=$('set-'+k);if(e){localStorage.setItem('ns_set_'+k,e.checked?'1':'0');obj[k]=e.checked}}); if(hasDB()&&obj.autosave!==false){R('settings/'+S.role+'/extra').set(obj).catch(()=>{})} applyExtra();}
  function applyExtra(){document.documentElement.classList.toggle('no-anim',localStorage.getItem('ns_set_anim')==='0');}
  readExtra(); applyExtra(); Object.keys(defaults).forEach(k=>$( 'set-'+k)?.addEventListener('change',saveExtra)); $('btn-reset-settings')?.addEventListener('click',()=>{Object.keys(defaults).forEach(k=>localStorage.removeItem('ns_set_'+k));readExtra();saveExtra();toast('Налаштування скинуто')});

  // Persist existing appearance/profile settings in Firebase as well, while keeping local fallback.
  function cloudSetting(path,value){if(hasDB())R('settings/'+S.role+'/'+path).set(value).catch(()=>{})}
  ['btn-app-bg','btn-app-photo'].forEach(id=>{const b=$(id); if(b)b.addEventListener('click',()=>setTimeout(()=>{cloudSetting(id,Date.now())},1500))});
  document.querySelectorAll('.palette').forEach(b=>b.addEventListener('click',()=>cloudSetting('palette',b.dataset.palette)));

  // Avatar editor replacement: full-image fit, pan and zoom, no forced crop.
  const editor=$('avatar-editor'), canvas=$('avatar-canvas');
  if(editor&&canvas){
    const oldSave=$('ae-save'); if(oldSave){const fresh=oldSave.cloneNode(true);oldSave.replaceWith(fresh)}
    const oldCancel=$('ae-cancel'); if(oldCancel){const fresh=oldCancel.cloneNode(true);oldCancel.replaceWith(fresh)}
    const oldPlus=$('ae-plus'); if(oldPlus){const fresh=oldPlus.cloneNode(true);oldPlus.replaceWith(fresh)}
    const oldMinus=$('ae-minus'); if(oldMinus){const fresh=oldMinus.cloneNode(true);oldMinus.replaceWith(fresh)}
    const title=editor.querySelector('.ae-box>div'); if(title)title.textContent='Фото профілю ❤️';
    const hint=editor.querySelector('.ae-box>div:nth-of-type(2)'); if(hint)hint.textContent='Фото вписується повністю. Перетягніть його пальцем або змініть масштаб.';
    let av={img:null,x:0,y:0,scale:1,drag:false,sx:0,sy:0,ox:0,oy:0,role:null}; const cx=canvas.getContext('2d');
    function draw(){if(!av.img)return;const w=canvas.width,h=canvas.height;cx.clearRect(0,0,w,h);cx.fillStyle='#111';cx.fillRect(0,0,w,h);const base=Math.min(w/av.img.width,h/av.img.height)*av.scale;const dw=av.img.width*base,dh=av.img.height*base;cx.drawImage(av.img,(w-dw)/2+av.x,(h-dh)/2+av.y,dw,dh)}
    window.openAvatarEditor=function(file,role){if(!file)return;av.role=role||S.role;const r=new FileReader();r.onload=e=>{const im=new Image();im.onload=()=>{av.img=im;av.x=0;av.y=0;av.scale=1;draw();editor.classList.add('on')};im.src=e.target.result};r.readAsDataURL(file)};
    ['photo-input','settings-profile-input'].forEach(id=>{const input=$(id);if(input)input.onchange=e=>{const f=e.target.files?.[0];if(f)window.openAvatarEditor(f,S.role);e.target.value=''}});
    canvas.onpointerdown=e=>{av.drag=true;av.sx=e.clientX;av.sy=e.clientY;av.ox=av.x;av.oy=av.y;canvas.setPointerCapture?.(e.pointerId)}; canvas.onpointermove=e=>{if(av.drag){av.x=av.ox+e.clientX-av.sx;av.y=av.oy+e.clientY-av.sy;draw()}}; canvas.onpointerup=()=>av.drag=false; canvas.onpointercancel=()=>av.drag=false;
    $('ae-plus')?.addEventListener('click',()=>{av.scale=Math.min(4,av.scale+.15);draw()}); $('ae-minus')?.addEventListener('click',()=>{av.scale=Math.max(.5,av.scale-.15);draw()}); $('ae-cancel')?.addEventListener('click',()=>editor.classList.remove('on'));
    $('ae-save')?.addEventListener('click',async()=>{if(!av.img||!av.role)return;try{const data=canvas.toDataURL('image/jpeg',.88);S.photos[av.role]=data;setAv(av.role,data);if(hasDB())await R('users/'+av.role+'/photo').set(data);editor.classList.remove('on');refreshSettingsUI?.();toast('Фото профілю збережено повністю ❤️')}catch(e){toast('Не вдалося зберегти фото')}});
  }
  // Make avatar previews show the whole saved photo rather than crop.
  document.querySelectorAll('.av img,.app-photo').forEach(i=>{i.style.objectFit='contain';i.style.background='rgba(255,255,255,.15)'});

  console.log('[Nash] v5 enhancements loaded');
})();


/* ===== FINAL MEDIA FIX — keep the proven Base64/Realtime Database storage from backup ===== */
(function(){
  'use strict';
  function el(id){ return document.getElementById(id); }
  function ok(){ return typeof db !== 'undefined' && db && typeof S !== 'undefined' && (S.role==='he'||S.role==='she'); }
  function send(payload, eventText){
    if(!ok()){ toast('Оберіть Котусика або Квіточку та перевірте Firebase'); return false; }
    payload.from = S.role;
    payload.ts = Date.now();
    payload.seenByOther = false;
    try{
      var p = R('chat').push(payload);
      if(eventText){ try{ R('events').push({type:'chat',text:eventText,from:S.role,fromName:myName(),ts:payload.ts}); }catch(_){} }
      return p;
    }catch(e){ console.error('[Nash media]',e); toast('Помилка збереження повідомлення'); return false; }
  }
  function readAsDataURL(file, done){
    var r=new FileReader();
    r.onload=function(){done(r.result)};
    r.onerror=function(){toast('Не вдалося прочитати файл')};
    r.readAsDataURL(file);
  }

  /* PHOTO */
  var photoBtn=el('chat-photo-btn'), photoInput=el('chat-photo-input');
  if(photoBtn && photoInput) photoBtn.onclick=function(e){e.preventDefault();e.stopPropagation();photoInput.click();};
  if(photoInput) photoInput.onchange=async function(e){
    e.stopPropagation();
    var f=e.target.files && e.target.files[0];
    e.target.value='';
    if(!f) return;
    if(!/^image\//.test(f.type)){toast('Оберіть зображення');return;}
    if(f.size>12*1024*1024){toast('Фото завелике (максимум 12 МБ)');return;}
    if(!ok()){toast('Firebase недоступний');return;}
    try{
      toast('Підготовка фото…');
      var data=await compress(f,1000,0.78);
      send({type:'photo',photo:data},myName()+' надіслав(ла) фото 📷');
      toast('Фото надіслано ❤️');
    }catch(err){console.error(err);toast('Помилка завантаження фото');}
  };

  /* VIDEO FILE */
  var videoBtn=el('chat-video-upload'), videoInput=el('chat-video-file') || el('chat-video-capture');
  if(videoBtn && videoInput) videoBtn.onclick=function(e){e.preventDefault();e.stopPropagation();videoInput.click();};
  if(videoInput) videoInput.onchange=function(e){
    e.stopPropagation();
    var f=e.target.files && e.target.files[0]; e.target.value='';
    if(!f) return;
    if(!/^video\//.test(f.type)){toast('Оберіть відео');return;}
    if(f.size>10*1024*1024){toast('Відео завелике (максимум 10 МБ)');return;}
    if(!ok()){toast('Firebase недоступний');return;}
    toast('Завантаження відео…');
    readAsDataURL(f,function(data){
      send({type:'video',video:data},myName()+' надіслав(ла) відео 🎬');
      toast('Відео надіслано ❤️');
    });
  };

  /* AUDIO FILE */
  var audioInput=el('chat-audio-capture');
  if(audioInput) audioInput.onchange=function(e){
    e.stopPropagation();
    var f=e.target.files && e.target.files[0]; e.target.value='';
    if(!f) return;
    if(!/^audio\//.test(f.type)){toast('Оберіть аудіофайл');return;}
    if(f.size>10*1024*1024){toast('Аудіо завелике (максимум 10 МБ)');return;}
    toast('Завантаження аудіо…');
    readAsDataURL(f,function(data){send({type:'voice',audio:data},myName()+' надіслав(ла) аудіо 🎵');toast('Аудіо надіслано ❤️');});
  };

  /* VOICE RECORDER — one final handler */
  var mic=el('chat-mic');
  var recorder=null, chunks=[], stream=null;
  if(mic) mic.onclick=async function(e){
    e.preventDefault();e.stopPropagation();
    if(recorder && recorder.state==='recording'){
      try{recorder.stop();}catch(_){}
      mic.textContent='🎙️';
      return;
    }
    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || typeof MediaRecorder==='undefined'){
      if(audioInput) audioInput.click(); else toast('Запис голосу не підтримується');
      return;
    }
    if(!ok()){toast('Firebase недоступний');return;}
    try{
      stream=await navigator.mediaDevices.getUserMedia({audio:true});
      chunks=[];
      var types=['audio/webm;codecs=opus','audio/webm','audio/mp4'];
      var mime='';
      for(var i=0;i<types.length;i++){if(MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(types[i])){mime=types[i];break;}}
      recorder=mime?new MediaRecorder(stream,{mimeType:mime}):new MediaRecorder(stream);
      recorder.ondataavailable=function(ev){if(ev.data && ev.data.size) chunks.push(ev.data);};
      recorder.onerror=function(){toast('Помилка запису голосу');};
      recorder.onstop=function(){
        try{stream.getTracks().forEach(function(t){t.stop();});}catch(_){}
        var blob=new Blob(chunks,{type:recorder.mimeType||'audio/webm'});
        if(blob.size<200){toast('Запис порожній');return;}
        if(blob.size>10*1024*1024){toast('Аудіо завелике');return;}
        toast('Збереження голосового…');
        readAsDataURL(blob,function(data){send({type:'voice',audio:data},myName()+' надіслав(ла) голосове 🎙️');toast('Голосове надіслано ❤️');});
      };
      recorder.start(250);
      mic.textContent='⏹️';
      toast('Запис… натисніть ще раз для завершення');
    }catch(err){console.error(err);toast('Немає дозволу на мікрофон');try{if(stream)stream.getTracks().forEach(function(t){t.stop();});}catch(_){} if(audioInput) setTimeout(function(){audioInput.click();},50);}
  };

  /* Ensure video picker exists even if the UI was renamed. */
  if(videoBtn && !videoInput){
    videoInput=document.createElement('input');videoInput.type='file';videoInput.accept='video/*';videoInput.className='hidden';videoInput.id='chat-video-file-runtime';document.body.appendChild(videoInput);
    videoBtn.onclick=function(e){e.preventDefault();videoInput.click();};
    videoInput.onchange=function(e){var f=e.target.files&&e.target.files[0];e.target.value='';if(!f)return;if(f.size>10*1024*1024){toast('Відео завелике');return;}readAsDataURL(f,function(data){send({type:'video',video:data},myName()+' надіслав(ла) відео 🎬');toast('Відео надіслано ❤️');});};
  }

  console.log('[Nash] FINAL MEDIA FIX loaded');
})();


/* ===== FINAL V8 USER REQUEST PATCH ===== */
(function(){
'use strict';
const CFG={apiKey:'AIzaSyA03kNmOlF4ys0cVEAfbVFe60tqXyp-4AI',authDomain:'our-universe-96cb1.firebaseapp.com',databaseURL:'https://our-universe-96cb1-default-rtdb.firebaseio.com',projectId:'our-universe-96cb1',storageBucket:'our-universe-96cb1.firebasestorage.app',messagingSenderId:'979090394458',appId:'1:979090394458:web:a07a2f46ba6c9d8bfdb763',measurementId:'G-RRQCLTH909'};
const VAPID='BLh9eylc5G0E3oc6ziL1s_UF8Bt-VdbqRfBqDFt3H4TdFqrIlJ4iKBOFt6W6wD1MF2blu2RFWe_jk4AnCadbo4w';
const css=document.createElement('style');css.textContent=`
html,body{overscroll-behavior-y:none!important}
#tab-chat{position:fixed!important;inset:0!important;width:100%!important;height:100dvh!important;z-index:5000!important;background:transparent!important;display:none;flex-direction:column!important;padding:0!important;margin:0!important}
#tab-chat .chat-container{width:100%!important;height:100%!important;min-height:100%!important;display:flex!important;flex-direction:column!important;background:transparent!important;border-radius:0!important;box-shadow:none!important;overflow:hidden!important}
#tab-chat .chat-header{flex:0 0 auto!important;background:rgba(255,255,255,.14)!important;backdrop-filter:blur(20px) saturate(150%)!important;-webkit-backdrop-filter:blur(20px) saturate(150%)!important;border:0!important;border-bottom:1px solid rgba(255,255,255,.2)!important;padding:calc(10px + env(safe-area-inset-top)) 14px 10px!important}
#tab-chat .search-box{background:transparent!important;padding:5px 12px!important}
#tab-chat .messages-container{flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important;background:transparent!important;padding:12px 10px 10px!important;overscroll-behavior:contain!important}
#tab-chat .chat-input-area{flex:0 0 auto!important;background:rgba(255,255,255,.14)!important;backdrop-filter:blur(20px) saturate(150%)!important;-webkit-backdrop-filter:blur(20px) saturate(150%)!important;border-top:1px solid rgba(255,255,255,.2)!important;padding:8px 10px calc(8px + env(safe-area-inset-bottom))!important}
#tab-chat .chat-tools{background:transparent!important}
#tab-chat .chat-tools .ct,#tab-chat .send-btn{background:rgba(255,255,255,.25)!important;border:1px solid rgba(255,255,255,.3)!important;backdrop-filter:blur(12px)!important;-webkit-backdrop-filter:blur(12px)!important;color:inherit!important}
#tab-chat .send-btn{background:rgba(236,72,153,.82)!important;color:#fff!important}
#tab-chat #chat-input{background:rgba(255,255,255,.22)!important;border:1px solid rgba(255,255,255,.3)!important;backdrop-filter:blur(12px)!important;-webkit-backdrop-filter:blur(12px)!important;color:inherit!important}
#tab-chat .bubble{box-shadow:0 4px 16px rgba(0,0,0,.12)!important;backdrop-filter:blur(14px)!important;-webkit-backdrop-filter:blur(14px)!important;border:1px solid rgba(255,255,255,.2)!important}
#tab-chat .bubble.me{background:rgba(236,72,153,.72)!important;color:#fff!important}
#tab-chat .bubble.them{background:rgba(255,255,255,.25)!important;color:inherit!important}
#tab-chat .chat-avatar{width:40px!important;height:40px!important;border-radius:50%!important;object-fit:cover!important;border:2px solid rgba(255,255,255,.8)!important}
#tab-chat .chat-online{opacity:.92!important}
#tab-chat .chat-bg,#tab-chat .chat-bg-img{display:none!important;background:none!important}
#tab-chat .chat-container,#tab-chat .messages-container{background:transparent!important;background-image:none!important}
.nav-six{grid-template-columns:repeat(6,1fr)!important}.nav-six button{font-size:8px!important}.nav-six button span{font-size:19px!important}
`;
document.head.appendChild(css);

function goTab(n,push){
  try{hideTabs();const el=document.getElementById('tab-'+n);if(el){el.classList.remove('hidden');el.style.display=n==='chat'?'flex':'block'}document.querySelectorAll('.nav button').forEach(b=>b.classList.toggle('on',b.dataset.tab===n));document.body.classList.toggle('on-chat-tab',n==='chat');if(n==='chat'){S.chatBg='';localStorage.removeItem('ns_chat_bg');setTimeout(()=>{const a=document.getElementById('chat-area');if(a)a.scrollTop=a.scrollHeight},50)}if(n==='calendar'&&typeof renderCalendar==='function')renderCalendar();if(n==='features'&&typeof renderFeatures==='function')renderFeatures();if(push)history.pushState({ns:true,tab:n},'');}catch(e){console.error(e)}}
window.openTab=function(n){goTab(n,true)};
window.openSub=function(n,push){try{hideTabs();const el=document.getElementById('sub-'+n);if(el){el.classList.remove('hidden');el.style.display='block'}document.querySelectorAll('.nav button').forEach(b=>b.classList.remove('on'));if(n==='mood'&&typeof renderMoodGrid==='function')renderMoodGrid();if(n==='calendar'&&typeof renderCalendar==='function')renderCalendar();if(n==='settings'&&typeof refreshSettingsUI==='function')refreshSettingsUI();if(push!==false)history.pushState({ns:true,sub:n},'')}catch(e){console.error(e)}};
window.addEventListener('popstate',function(e){const st=e.state;if(st&&st.ns){if(st.sub)window.openSub(st.sub,false);else if(st.tab)goTab(st.tab,false);else goTab('home',false)}else goTab('home',false)});
try{history.replaceState({ns:true,tab:'home'},'')}catch(e){}

document.querySelectorAll('.nav-six button[data-tab]').forEach(b=>b.onclick=e=>{e.preventDefault();window.openTab(b.dataset.tab)});
// Remove chat-background settings from any old DOM/cache and functions.
['btn-chat-bg','chat-bg-input','chat-bg-preview','chat-bg-img'].forEach(id=>{const el=document.getElementById(id);if(el)el.remove()});
window.setChatBackground=function(){S.chatBg='';try{localStorage.removeItem('ns_chat_bg')}catch(e){}const t=document.getElementById('tab-chat');if(t){t.style.background='transparent';t.style.backgroundImage='none'}};
try{window.setChatBackground()}catch(e){}

function dbOK(){return !!(db&&S.role)}
function sendChat(payload){if(!dbOK()){toast('Firebase недоступний або не вибрана роль');return Promise.reject(new Error('Firebase unavailable'))}const msg=Object.assign({from:S.role,ts:Date.now(),seenByOther:false},payload);return R('chat').push(msg).then(()=>{R('events').push({type:'chat',text:myName()+': '+(msg.text||'медіа').slice(0,60),from:S.role,fromName:myName(),ts:msg.ts}).catch(()=>{})}).catch(e=>{console.error(e);toast('Не вдалося надіслати повідомлення');throw e})}
function renderChat(snap){const area=document.getElementById('chat-area');if(!area)return;const d=snap.val()||{};const arr=Object.keys(d).map(k=>Object.assign({id:k},d[k])).sort((a,b)=>(a.ts||0)-(b.ts||0));const lastRead=+localStorage.getItem('ns_last_read_chat')||0;let unread=0;area.innerHTML=arr.map(m=>{const me=m.from===S.role;if(!me&&(m.ts||0)>lastRead)unread++;const tm=m.ts?new Date(m.ts).toLocaleTimeString('uk-UA',{hour:'2-digit',minute:'2-digit'}):'';const del=me?`<button class="del-msg" data-del="${esc(m.id)}" type="button">✕</button>`:'';const seen=me?`<div class="read">${m.seenByOther?'✓✓':'✓'}</div>`:'';if(m.type==='photo'&&m.photo)return `<div class="bubble photo ${me?'me':'them'}">${del}<img src="${m.photo}" alt="Фото" loading="lazy"><div class="tm">${tm}</div>${seen}</div>`;if(m.type==='video'&&m.video)return `<div class="bubble ${me?'me':'them'}">${del}<video src="${m.video}" controls playsinline style="max-width:100%;border-radius:14px"></video><div class="tm">${tm}</div>${seen}</div>`;if(m.type==='voice'&&m.audio)return `<div class="bubble voice ${me?'me':'them'}">${del}<div>🎙️ Голосове</div><audio controls src="${m.audio}" style="max-width:100%"></audio><div class="tm">${tm}</div>${seen}</div>`;return `<div class="bubble ${me?'me':'them'}">${del}<div style="white-space:pre-wrap;overflow-wrap:anywhere">${esc(m.text||'')}</div><div class="tm">${tm}</div>${seen}</div>`}).join('');area.querySelectorAll('[data-del]').forEach(b=>b.onclick=e=>{e.stopPropagation();if(confirm('Видалити повідомлення?'))R('chat/'+b.dataset.del).remove()});if(arr.length){area.scrollTop=area.scrollHeight;localStorage.setItem('ns_last_chat_ts',String(arr[arr.length-1].ts||0))}const tab=document.getElementById('tab-chat');if(tab&&!tab.classList.contains('hidden')){const latest=arr.length?arr[arr.length-1].ts:0;if(latest)localStorage.setItem('ns_last_read_chat',String(latest));S.unreadChat=0;arr.forEach(m=>{if(m.from!==S.role&&!m.seenByOther)R('chat/'+m.id+'/seenByOther').set(true)})}else{S.unreadChat=unread;localStorage.setItem('ns_unread_chat',String(unread))}const badge=document.getElementById('chat-unread');if(badge){badge.textContent=S.unreadChat||0;badge.classList.toggle('on',S.unreadChat>0)}}
if(db)R('chat').limitToLast(150).on('value',renderChat);
const cin=document.getElementById('chat-input'),csend=document.getElementById('chat-send');if(csend)csend.onclick=e=>{e.preventDefault();const t=(cin?.value||'').trim();if(t)sendChat({text:t}).then(()=>{cin.value=''})};if(cin)cin.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();csend?.click()}};
const pbtn=document.getElementById('chat-photo-btn'),pin=document.getElementById('chat-photo-input');if(pbtn&&pin){pbtn.onclick=e=>{e.preventDefault();e.stopPropagation();pin.click()};pin.onchange=async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;if(!f.type.startsWith('image/'))return toast('Оберіть фото');try{toast('Фото завантажується…');const data=await compress(f,1100,.75);await sendChat({type:'photo',photo:data});toast('Фото надіслано ❤️')}catch(err){console.error(err);toast('Помилка фото')}}}

// Presence: online + last seen.
function presence(){if(!dbOK())return;const me=R('presence/'+S.role);me.set({online:true,ts:firebase.database.ServerValue.TIMESTAMP});me.onDisconnect().set({online:false,ts:firebase.database.ServerValue.TIMESTAMP});R('presence/'+other()).on('value',s=>{const v=s.val()||{},el=document.getElementById('chat-status');if(!el)return;el.textContent=v.online?'онлайн':v.ts?'був(ла) в мережі '+new Date(v.ts).toLocaleString('uk-UA',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):'не в мережі'})}
presence();
function updateHeader(){const r=other(),av=document.getElementById('chat-avatar'),title=document.getElementById('chat-title'),photo=S.photos?.[r]||'';if(title)title.textContent='❤️ '+NAMES[r];if(av){av.innerHTML=photo?`<img src="${photo}" alt="" class="chat-avatar">`:EMOJI[r]}}updateHeader();

// App background only.
const ab=document.getElementById('btn-app-bg'),ai=document.getElementById('app-bg-input');if(ab&&ai)ab.onclick=()=>ai.click();if(ai)ai.onchange=async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;try{const data=await compress(f,1400,.78);window.setAppBackground(data);toast('Фон застосунку змінено ❤️')}catch(err){toast('Не вдалося змінити фон')}};

// Push setup. FCM token is stored in Realtime Database; background delivery needs HTTPS/PWA or native FCM in the APK.
async function setupPush(){const st=document.getElementById('push-status');try{if(!('Notification'in window)){if(st)st.textContent='Сповіщення не підтримуються';return}const perm=Notification.permission==='granted'?'granted':await Notification.requestPermission();if(perm!=='granted'){if(st)st.textContent='Дозвіл не надано';return}if(!('serviceWorker'in navigator)){if(st)st.textContent='Service Worker не підтримується';return}const reg=await navigator.serviceWorker.register('./firebase-messaging-sw.js');if(firebase.messaging){const m=firebase.messaging();const token=await m.getToken({vapidKey:VAPID,serviceWorkerRegistration:reg});if(token&&dbOK())await R('users/'+S.role+'/fcmToken').set(token);if(st)st.textContent=token?'FCM підключено ✓':'Токен не отримано';m.onMessage(payload=>{const n=payload.notification||{};showBanner(n.title||'❤️ Наш Всесвіт',n.body||'Нове повідомлення')})}else if(st)st.textContent='Firebase Messaging не завантажено'}catch(e){console.error(e);if(st)st.textContent='Помилка Push: '+e.message}}
const pb=document.getElementById('btn-push-prep');if(pb)pb.onclick=setupPush;

// Prevent accidental vertical pull-to-refresh on the app root.
document.addEventListener('touchmove',e=>{if(e.cancelable&&window.scrollY===0&&e.touches?.[0]?.clientY>0&&document.body.classList.contains('on-chat-tab')===false){/* normal internal scrolling remains enabled */}}, {passive:true});
console.log('[Nash Universe] V8 requested changes loaded');
})();
