YA HTML به APK / AAB — نسخه فارسی

این ابزار یک پروژه اندروید WebView می‌سازد و محتوای یک فایل ZIP یا پوشه HTML را
داخل assets قرار می‌دهد؛ سپس APK آزمایشی، APK انتشار و AAB را تولید می‌کند.

پیش‌نیازها:
1) JDK 17 یا بالاتر
2) Android SDK (متغیر ANDROID_HOME یا ANDROID_SDK_ROOT)
3) Gradle نصب‌شده و در PATH
4) دستور unzip

شروع سریع در Linux / Termux / محیط‌های لینوکسی:
1) فایل‌های HTML/CSS/JS و تصاویر را داخل input.zip قرار دهید.
2) فایل input.zip را کنار build.sh بگذارید.
3) در ترمینال اجرا کنید:
   chmod +x build.sh
   bash build.sh input.zip

برای ساخت با امضای انتشار:
   KEYSTORE_PATH=/مسیر/keystore.jks KEY_ALIAS=mykey bash build.sh input.zip

اسکریپت هنگام اجرا رمزها را به‌صورت مخفی می‌پرسد. رمز را داخل فایل‌ها ننویسید.
برای امنیت بیشتر، keystore را در پوشه عمومی یا ZIP اشتراکی قرار ندهید.

تنظیم نام و شناسه برنامه:
   APP_NAME="برنامه من" APP_ID="com.example.myapp" VERSION_NAME="1.0" VERSION_CODE=1 bash build.sh input.zip

خروجی‌ها در پوشه YA-WebApp قرار می‌گیرند:
- APK آزمایشی: app/build/outputs/apk/debug/app-debug.apk
- APK انتشار: app/build/outputs/apk/release/
- AAB: app/build/outputs/bundle/release/app-release.aab

نکته مهم:
- APK برای نصب مستقیم روی گوشی است.
- AAB قالب انتشار در Google Play است و به‌طور معمول مستقیماً نصب نمی‌شود.
- اگر keystore ندهید، APK/AAB انتشار با امضای نهایی شما ساخته نمی‌شوند.
- برای به‌روزرسانی یک اپلیکیشن منتشرشده، باید همان keystore و همان alias قبلی را استفاده کنید.
- فایل‌های HTML باید صفحه شروع index.html داشته باشند (یا حداقل یک فایل .html؛
  در این حالت اولین فایل HTML به index.html کپی می‌شود).
- این ابزار وب‌سایت‌های وابسته به سرور را به‌صورت آفلاین تبدیل نمی‌کند؛ منابع آنلاین
  و APIها همچنان به اینترنت نیاز دارند.
- JavaScript در WebView فعال است. فقط ZIPهایی را وارد کنید که به منبع آن‌ها اعتماد دارید.
