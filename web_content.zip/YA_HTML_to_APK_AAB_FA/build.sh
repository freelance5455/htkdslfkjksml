#!/usr/bin/env bash
set -Eeuo pipefail

# YA HTML به APK / AAB — سازنده پروژه اندروید از فایل ZIP یا پوشه HTML
# نیازمندی‌ها: JDK 17+، Android SDK، Gradle 8.9+، ابزار unzip

APP_NAME="${APP_NAME:-برنامه وب من}"
APP_ID="${APP_ID:-com.ya.webapp}"
VERSION_NAME="${VERSION_NAME:-1.0.0}"
VERSION_CODE="${VERSION_CODE:-1}"
MIN_SDK="${MIN_SDK:-23}"
TARGET_SDK="${TARGET_SDK:-35}"
COMPILE_SDK="${COMPILE_SDK:-35}"
INPUT_ZIP="${1:-input.zip}"
PROJECT_DIR="${PROJECT_DIR:-YA-WebApp}"
KEYSTORE_PATH="${KEYSTORE_PATH:-}"
KEY_ALIAS="${KEY_ALIAS:-}"
KEYSTORE_PASSWORD="${KEYSTORE_PASSWORD:-}"
KEY_PASSWORD="${KEY_PASSWORD:-}"

say() { printf '\n\033[1;36m[YA]\033[0m %s\n' "$*"; }
die() { printf '\n\033[1;31m[خطا]\033[0m %s\n' "$*" >&2; exit 1; }
command -v java >/dev/null 2>&1 || die "Java نصب نیست. JDK 17 یا بالاتر نصب کنید."
command -v unzip >/dev/null 2>&1 || die "دستور unzip پیدا نشد."
command -v gradle >/dev/null 2>&1 || die "Gradle نصب نیست یا در PATH قرار ندارد."
[[ -d "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-}}" ]] || die "مسیر Android SDK مشخص نیست؛ ANDROID_HOME یا ANDROID_SDK_ROOT را تنظیم کنید."
[[ "$APP_ID" =~ ^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$ ]] || die "شناسه برنامه نامعتبر است: $APP_ID"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT_ABS=""
if [[ -f "$INPUT_ZIP" ]]; then
  INPUT_ABS="$(cd "$(dirname "$INPUT_ZIP")" && pwd)/$(basename "$INPUT_ZIP")"
elif [[ -d "$INPUT_ZIP" ]]; then
  INPUT_ABS="$(cd "$INPUT_ZIP" && pwd)"
else
  die "فایل یا پوشه ورودی پیدا نشد: $INPUT_ZIP"
fi

# ساخت پوشه پروژه از ابتدا، بدون حذف پوشه قبلی
if [[ -e "$PROJECT_DIR" ]]; then
  PROJECT_DIR="${PROJECT_DIR}-$(date +%Y%m%d-%H%M%S)"
fi
mkdir -p "$PROJECT_DIR/app/src/main/assets" "$PROJECT_DIR/app/src/main/java"

if [[ -f "$INPUT_ABS" ]]; then
  say "استخراج فایل ZIP ..."
  # جلوگیری از استخراج مسیرهای خارج از پوشه مقصد
  unzip -Z1 "$INPUT_ABS" | while IFS= read -r entry; do
    [[ "$entry" != /* && "$entry" != *".."* ]] || die "مسیر ناامن در ZIP شناسایی شد: $entry"
  done
  unzip -oq "$INPUT_ABS" -d "$PROJECT_DIR/app/src/main/assets"
else
  say "کپی فایل‌های پوشه HTML ..."
  cp -a "$INPUT_ABS"/. "$PROJECT_DIR/app/src/main/assets/"
fi

if [[ ! -f "$PROJECT_DIR/app/src/main/assets/index.html" ]]; then
  FIRST_HTML="$(find "$PROJECT_DIR/app/src/main/assets" -type f -iname '*.html' | head -n 1 || true)"
  if [[ -n "$FIRST_HTML" ]]; then
    cp "$FIRST_HTML" "$PROJECT_DIR/app/src/main/assets/index.html"
  else
    die "فایل HTML پیدا نشد. داخل ZIP باید index.html یا دست‌کم یک فایل HTML باشد."
  fi
fi

PKG_PATH="${APP_ID//./\/}"
mkdir -p "$PROJECT_DIR/app/src/main/java/$PKG_PATH"

cat > "$PROJECT_DIR/settings.gradle" <<'EOF'
pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "YA-WebApp"
include(":app")
EOF

cat > "$PROJECT_DIR/build.gradle" <<'EOF'
plugins {
    id 'com.android.application' version '8.7.3' apply false
}
EOF

cat > "$PROJECT_DIR/gradle.properties" <<'EOF'
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
EOF

cat > "$PROJECT_DIR/app/build.gradle" <<EOF
plugins {
    id 'com.android.application'
}

def ksFile = System.getenv("YA_KEYSTORE_FILE")
def ksStorePassword = System.getenv("YA_KEYSTORE_PASSWORD")
def ksAlias = System.getenv("YA_KEY_ALIAS")
def ksKeyPassword = System.getenv("YA_KEY_PASSWORD")

android {
    namespace '$APP_ID'
    compileSdk $COMPILE_SDK

    defaultConfig {
        applicationId '$APP_ID'
        minSdk $MIN_SDK
        targetSdk $TARGET_SDK
        versionCode $VERSION_CODE
        versionName '$VERSION_NAME'
    }

    signingConfigs {
        release {
            if (ksFile && ksStorePassword && ksAlias && ksKeyPassword) {
                storeFile file(ksFile)
                storePassword ksStorePassword
                keyAlias ksAlias
                keyPassword ksKeyPassword
            }
        }
    }

    buildTypes {
        debug { }
        release {
            minifyEnabled false
            if (ksFile && ksStorePassword && ksAlias && ksKeyPassword) {
                signingConfig signingConfigs.release
            }
        }
    }

    bundle { language { enableSplit = false } }
}
EOF

cat > "$PROJECT_DIR/app/src/main/AndroidManifest.xml" <<EOF
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <application
        android:allowBackup="true"
        android:label="$(printf '%s' "$APP_NAME" | sed 's/[&<>"]/ /g')"
        android:usesCleartextTraffic="false"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
EOF

cat > "$PROJECT_DIR/app/src/main/java/$PKG_PATH/MainActivity.java" <<'EOF'
package PACKAGE_NAME;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
EOF
sed -i "s/PACKAGE_NAME/$APP_ID/" "$PROJECT_DIR/app/src/main/java/$PKG_PATH/MainActivity.java"

cat > "$PROJECT_DIR/README-FA.txt" <<EOF
برنامه ساخته‌شده با YA HTML به APK/AAB
نام: $APP_NAME
شناسه: $APP_ID
نسخه: $VERSION_NAME ($VERSION_CODE)

فایل‌های خروجی:
- app/build/outputs/apk/release/app-release-unsigned.apk یا app-release.apk
- app/build/outputs/bundle/release/app-release.aab

برای ساخت مجدد:
  gradle assembleDebug
  gradle assembleRelease
  gradle bundleRelease

امضا:
متغیرهای محیطی YA_KEYSTORE_FILE، YA_KEYSTORE_PASSWORD،
YA_KEY_ALIAS و YA_KEY_PASSWORD باید تنظیم شوند.
برای امنیت، رمزها را داخل فایل build.gradle یا اسکریپت ننویسید.

نکته: AAB برای انتشار در Google Play است و مستقیماً مثل APK روی گوشی نصب نمی‌شود.
برای نصب مستقیم، از APK استفاده کنید. اگر خروجی release بدون keystore ساخته شد،
امضای نهایی انتشار انجام نشده است.
EOF

say "آماده‌سازی Gradle Wrapper ..."
( cd "$PROJECT_DIR" && gradle wrapper --gradle-version 8.9 )

export YA_KEYSTORE_FILE="" YA_KEYSTORE_PASSWORD="" YA_KEY_ALIAS="" YA_KEY_PASSWORD=""
if [[ -n "$KEYSTORE_PATH" ]]; then
  [[ -f "$KEYSTORE_PATH" ]] || die "فایل keystore پیدا نشد: $KEYSTORE_PATH"
  KEYSTORE_ABS="$(cd "$(dirname "$KEYSTORE_PATH")" && pwd)/$(basename "$KEYSTORE_PATH")"
  export YA_KEYSTORE_FILE="$KEYSTORE_ABS"
  [[ -n "$KEY_ALIAS" ]] || read -r -p "نام Alias: " KEY_ALIAS
  [[ -n "$KEYSTORE_PASSWORD" ]] || read -r -s -p "رمز Keystore: " KEYSTORE_PASSWORD; echo
  [[ -n "$KEY_PASSWORD" ]] || read -r -s -p "رمز کلید (اگر یکسان است Enter و سپس مقدار رمز را وارد کنید): " KEY_PASSWORD; echo
  [[ -n "$KEY_PASSWORD" ]] || KEY_PASSWORD="$KEYSTORE_PASSWORD"
  export YA_KEY_ALIAS="$KEY_ALIAS" YA_KEYSTORE_PASSWORD="$KEYSTORE_PASSWORD" YA_KEY_PASSWORD="$KEY_PASSWORD"
else
  say "Keystore تعیین نشده؛ خروجی Release بدون امضای انتشار ساخته می‌شود."
fi

say "ساخت APK و AAB ..."
(
  cd "$PROJECT_DIR"
  ./gradlew --no-daemon assembleDebug
  ./gradlew --no-daemon assembleRelease
  ./gradlew --no-daemon bundleRelease
)

say "پایان ساخت."
echo "پروژه: $PROJECT_DIR"
echo "APK آزمایشی: $PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"
echo "APK انتشار: $PROJECT_DIR/app/build/outputs/apk/release/"
echo "AAB: $PROJECT_DIR/app/build/outputs/bundle/release/app-release.aab"
