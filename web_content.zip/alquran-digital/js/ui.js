window.App = window.App || {};

App.ui = (function () {
  var refs = {};
  var toastTimer = null;
  var dialogAction = null;

  function escapeHtml(value) {
    var map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
    var text = value === undefined || value === null ? '' : String(value);

    return text.replace(/[&<>"']/g, function (char) {
      return map[char];
    });
  }

  function toast(message) {
    refs.toast.textContent = message;
    refs.toast.classList.add('show');

    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      refs.toast.classList.remove('show');
    }, 2200);
  }

  function openSheet(options) {
    refs.sheetTitle.textContent = options.title || '';
    refs.sheetSubtitle.textContent = options.subtitle || '';
    refs.sheetSubtitle.hidden = !options.subtitle;
    refs.sheetBody.innerHTML = options.html || '';
    refs.sheetBody.scrollTop = 0;
    refs.sheet.hidden = false;
    document.body.classList.add('modal-open');
  }

  function setSheetBody(html) {
    refs.sheetBody.innerHTML = html;
  }

  function closeSheet() {
    refs.sheet.hidden = true;
    document.body.classList.remove('modal-open');
  }

  function isSheetOpen() {
    return !refs.sheet.hidden;
  }

  function confirmAction(message, confirmLabel, onConfirm) {
    refs.dialogMessage.textContent = message;
    refs.dialogOk.textContent = confirmLabel || 'Ya';
    dialogAction = onConfirm;
    refs.dialog.hidden = false;
  }

  function closeDialog() {
    refs.dialog.hidden = true;
    dialogAction = null;
  }

  function timeAgo(timestamp) {
    var diff = Date.now() - timestamp;
    var minute = 60000;
    var hour = 3600000;
    var day = 86400000;

    if (diff < minute) {
      return 'Baru saja';
    }
    if (diff < hour) {
      return Math.floor(diff / minute) + ' menit lalu';
    }
    if (diff < day) {
      return Math.floor(diff / hour) + ' jam lalu';
    }
    if (diff < day * 2) {
      return 'Kemarin';
    }
    if (diff < day * 7) {
      return Math.floor(diff / day) + ' hari lalu';
    }

    return new Date(timestamp).toLocaleDateString('id-ID', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  function formatNumber(value) {
    return Number(value).toLocaleString('id-ID');
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }

    return new Promise(function (resolve, reject) {
      var area = document.createElement('textarea');
      var copied = false;

      area.value = text;
      area.setAttribute('readonly', '');
      area.style.position = 'fixed';
      area.style.opacity = '0';
      document.body.appendChild(area);
      area.select();

      try {
        copied = document.execCommand('copy');
      } catch (error) {
        copied = false;
      }

      document.body.removeChild(area);

      if (copied) {
        resolve();
      } else {
        reject(new Error('copy failed'));
      }
    });
  }

  function init() {
    refs.toast = document.getElementById('toast');
    refs.sheet = document.getElementById('sheet');
    refs.sheetTitle = document.getElementById('sheetTitle');
    refs.sheetSubtitle = document.getElementById('sheetSubtitle');
    refs.sheetBody = document.getElementById('sheetBody');
    refs.dialog = document.getElementById('dialog');
    refs.dialogMessage = document.getElementById('dialogMessage');
    refs.dialogOk = document.getElementById('dialogOk');

    refs.sheet.addEventListener('click', function (event) {
      if (event.target.closest('[data-close-sheet]')) {
        closeSheet();
      }
    });

    document.getElementById('dialogCancel').addEventListener('click', closeDialog);
    document.getElementById('dialogBackdrop').addEventListener('click', closeDialog);

    refs.dialogOk.addEventListener('click', function () {
      var action = dialogAction;
      closeDialog();
      if (action) {
        action();
      }
    });

    document.addEventListener('keydown', function (event) {
      if (event.key !== 'Escape') {
        return;
      }
      if (!refs.dialog.hidden) {
        closeDialog();
      } else if (isSheetOpen()) {
        closeSheet();
      }
    });
  }

  return {
    init: init,
    escapeHtml: escapeHtml,
    toast: toast,
    openSheet: openSheet,
    setSheetBody: setSheetBody,
    closeSheet: closeSheet,
    confirmAction: confirmAction,
    timeAgo: timeAgo,
    formatNumber: formatNumber,
    copyText: copyText
  };
})();
