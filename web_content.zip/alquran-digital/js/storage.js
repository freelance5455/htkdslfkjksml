window.App = window.App || {};

App.storage = (function () {
  var state = null;
  var timer = null;

  function createDefault() {
    return {
      settings: Object.assign({}, App.config.defaults),
      favorites: [],
      history: [],
      lastRead: null,
      readAyahs: {},
      days: [],
      audioPlays: 0
    };
  }

  function load() {
    var base = createDefault();

    try {
      var raw = localStorage.getItem(App.config.storageKey);
      if (!raw) {
        return base;
      }

      var saved = JSON.parse(raw);
      base.settings = Object.assign(base.settings, saved.settings || {});
      base.favorites = Array.isArray(saved.favorites) ? saved.favorites : [];
      base.history = Array.isArray(saved.history) ? saved.history : [];
      base.lastRead = saved.lastRead || null;
      base.readAyahs = saved.readAyahs && typeof saved.readAyahs === 'object' ? saved.readAyahs : {};
      base.days = Array.isArray(saved.days) ? saved.days : [];
      base.audioPlays = Number(saved.audioPlays) || 0;
    } catch (error) {
      return createDefault();
    }

    return base;
  }

  function get() {
    if (!state) {
      state = load();
    }
    return state;
  }

  function persist() {
    try {
      localStorage.setItem(App.config.storageKey, JSON.stringify(get()));
    } catch (error) {}
  }

  function save() {
    clearTimeout(timer);
    timer = setTimeout(persist, 250);
  }

  function saveNow() {
    clearTimeout(timer);
    persist();
  }

  function reset() {
    state = createDefault();
    persist();
  }

  window.addEventListener('beforeunload', saveNow);
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'hidden') {
      saveNow();
    }
  });

  return { get: get, save: save, saveNow: saveNow, reset: reset, createDefault: createDefault };
})();
