window.App = window.App || {};

App.theme = (function () {
  var media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;

  function isDark(mode) {
    return mode === 'dark' || (mode === 'auto' && !!media && media.matches);
  }

  function apply(mode) {
    var dark = isDark(mode);
    var meta = document.querySelector('meta[name="theme-color"]');

    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');

    if (meta) {
      meta.setAttribute('content', dark ? '#0b1810' : '#178a49');
    }
  }

  function currentlyDark() {
    return document.documentElement.getAttribute('data-theme') === 'dark';
  }

  function watch() {
    if (!media) {
      return;
    }

    var listener = function () {
      if (App.storage.get().settings.theme === 'auto') {
        apply('auto');
        document.dispatchEvent(new CustomEvent('theme:changed'));
      }
    };

    if (media.addEventListener) {
      media.addEventListener('change', listener);
    } else if (media.addListener) {
      media.addListener(listener);
    }
  }

  return { apply: apply, watch: watch, currentlyDark: currentlyDark };
})();
