window.App = window.App || {};

App.quran = (function () {
  var view = null;
  var built = false;
  var surahs = [];
  var state = { query: '', juz: 0 };

  function normalise(text) {
    return String(text || '').toLowerCase().replace(/[\s\-'’`]/g, '');
  }

  function cardHtml(surah) {
    var tone = surah.type === 'Makkiyah' ? 'makki' : 'madani';

    return '<div class="surah-card" role="button" tabindex="0" data-surah="' + surah.number + '">' +
      '<div class="surah-number ' + tone + '">' + surah.number + '</div>' +
      '<div class="surah-body">' +
        '<h3 class="surah-latin">' + App.ui.escapeHtml(surah.latin) + '</h3>' +
        '<p class="surah-meaning">' + App.ui.escapeHtml(surah.meaning) + '</p>' +
        '<div class="chip-row">' +
          '<span class="chip chip-' + tone + '">' + App.icons.svg('pin', 12) + surah.type + '</span>' +
          '<span class="chip chip-muted">' + surah.ayahs + ' Ayat</span>' +
        '</div>' +
      '</div>' +
      '<div class="surah-side">' +
        '<span class="surah-arabic" lang="ar" dir="rtl">' + App.ui.escapeHtml(surah.arabic) + '</span>' +
        App.favorites.starButton(surah.number) +
      '</div>' +
    '</div>';
  }

  function bindList(container) {
    container.addEventListener('click', function (event) {
      var star = event.target.closest('[data-fav]');
      if (star) {
        event.stopPropagation();
        App.favorites.toggle(Number(star.getAttribute('data-fav')));
        return;
      }

      var card = event.target.closest('[data-surah]');
      if (card) {
        App.router.go('#/surah/' + card.getAttribute('data-surah'));
      }
    });

    container.addEventListener('keydown', function (event) {
      if (event.key !== 'Enter' && event.key !== ' ') {
        return;
      }

      var card = event.target.closest('[data-surah]');
      if (card && event.target === card) {
        event.preventDefault();
        App.router.go('#/surah/' + card.getAttribute('data-surah'));
      }
    });
  }

  function filtered() {
    var query = normalise(state.query);
    var range = state.juz ? App.juz.surahRange(state.juz) : null;

    return surahs.filter(function (surah) {
      if (range && (surah.number < range.first || surah.number > range.last)) {
        return false;
      }
      if (!query) {
        return true;
      }

      return [surah.latin, surah.meaning, surah.english, surah.arabic, String(surah.number)].some(function (field) {
        return normalise(field).indexOf(query) !== -1;
      });
    });
  }

  function renderJuzChips() {
    var box = view.querySelector('#juzChips');
    var html = '';
    var number;

    for (number = 0; number <= 30; number += 1) {
      html += '<button type="button" class="juz-chip' + (state.juz === number ? ' active' : '') +
        '" data-juz="' + number + '">' + (number === 0 ? 'Semua' : 'Juz ' + number) + '</button>';
    }

    box.innerHTML = html;
  }

  function renderSkeleton() {
    var html = '';
    var i;

    for (i = 0; i < 8; i += 1) {
      html += '<div class="skeleton"></div>';
    }

    view.querySelector('#surahList').innerHTML = html;
    view.querySelector('#listMeta').textContent = '';
  }

  function renderError() {
    view.querySelector('#listMeta').textContent = '';
    view.querySelector('#surahList').innerHTML =
      '<div class="empty-state">' +
        '<div class="empty-icon">' + App.icons.svg('refresh', 44) + '</div>' +
        '<h3>Daftar surah gagal dimuat</h3>' +
        '<p>Periksa koneksi internet kamu, lalu coba lagi.</p>' +
        '<button type="button" class="btn btn-primary" data-retry>Coba Lagi</button>' +
      '</div>';
  }

  function renderList() {
    var items = filtered();
    var list = view.querySelector('#surahList');
    var meta = view.querySelector('#listMeta');

    meta.textContent = items.length + ' surah' + (state.juz ? ' di Juz ' + state.juz : '');

    if (!items.length) {
      list.innerHTML =
        '<div class="empty-state">' +
          '<div class="empty-icon">' + App.icons.svg('search', 44) + '</div>' +
          '<h3>Surah tidak ditemukan</h3>' +
          '<p>Coba kata kunci lain untuk pencarian.</p>' +
        '</div>';
      return;
    }

    list.innerHTML = items.map(cardHtml).join('');
  }

  function renderLastRead() {
    var holder = view.querySelector('#lastReadCard');
    var last = App.storage.get().lastRead;
    var href = last ? '#/surah/' + last.surah + '/' + last.ayah : '#/surah/1';
    var label = last ? 'Terakhir Dibaca' : 'Belum ada bacaan';
    var title = last ? App.ui.escapeHtml(last.latin) + ' • Ayat ' + last.ayah : 'Mulai dari Al-Fatihah';

    holder.innerHTML =
      '<a class="last-read" href="' + href + '">' +
        '<span class="last-read-icon">' + App.icons.svg('play', 22) + '</span>' +
        '<span class="last-read-text"><span>' + label + '</span><strong>' + title + '</strong></span>' +
        App.icons.svg('chevron', 20) +
      '</a>';
  }

  function updateThemeIcon() {
    var holder = view.querySelector('#themeIcon');
    if (holder) {
      holder.innerHTML = App.icons.svg(App.theme.currentlyDark() ? 'sun' : 'moon', 20);
    }
  }

  function toggleTheme() {
    var next = App.theme.currentlyDark() ? 'light' : 'dark';
    App.storage.get().settings.theme = next;
    App.storage.save();
    App.theme.apply(next);
    updateThemeIcon();
  }

  function buildShell() {
    view.innerHTML =
      '<header class="hero">' +
        '<div class="container">' +
          '<div class="hero-top">' +
            '<div>' +
              '<p class="hero-greeting">Assalamualaikum</p>' +
              '<h1 class="hero-title">Al-Quran Digital</h1>' +
            '</div>' +
            '<div class="hero-actions">' +
              '<button type="button" class="icon-btn glass" data-act="theme" aria-label="Ganti tema terang atau gelap"><span id="themeIcon"></span></button>' +
              '<button type="button" class="icon-btn glass" data-act="guide" aria-label="Panduan">' + App.icons.svg('help', 20) + '</button>' +
              '<button type="button" class="icon-btn glass" data-act="settings" aria-label="Pengaturan">' + App.icons.svg('settings', 20) + '</button>' +
            '</div>' +
          '</div>' +
          '<div id="lastReadCard"></div>' +
          '<div class="juz-scroller" id="juzChips"></div>' +
        '</div>' +
      '</header>' +
      '<div class="search-wrap">' +
        '<div class="container">' +
          '<label class="search-box">' + App.icons.svg('search', 20) +
            '<input type="search" id="searchInput" placeholder="Cari surah..." autocomplete="off" aria-label="Cari surah">' +
          '</label>' +
        '</div>' +
      '</div>' +
      '<div class="container">' +
        '<p class="list-meta" id="listMeta"></p>' +
        '<div class="surah-list" id="surahList"></div>' +
      '</div>';

    renderJuzChips();

    view.querySelector('#searchInput').addEventListener('input', function (event) {
      state.query = event.target.value;
      renderList();
    });

    view.addEventListener('click', function (event) {
      var chip = event.target.closest('[data-juz]');
      var action = event.target.closest('[data-act]');

      if (chip) {
        state.juz = Number(chip.getAttribute('data-juz'));
        renderJuzChips();
        renderList();
        return;
      }

      if (event.target.closest('[data-retry]')) {
        load();
        return;
      }

      if (!action) {
        return;
      }

      var name = action.getAttribute('data-act');
      if (name === 'theme') {
        toggleTheme();
      } else if (name === 'guide') {
        App.guide.open();
      } else if (name === 'settings') {
        App.router.go('#/settings');
      }
    });

    bindList(view);
    document.addEventListener('theme:changed', updateThemeIcon);
  }

  function load() {
    renderSkeleton();

    return App.api.fetchSurahs().then(function (list) {
      surahs = list;
      renderList();
    }).catch(renderError);
  }

  function enter() {
    view = document.getElementById('view-quran');

    if (!built) {
      buildShell();
      built = true;
    }

    renderLastRead();
    updateThemeIcon();

    if (surahs.length) {
      renderList();
      return Promise.resolve();
    }

    return load();
  }

  return { enter: enter, cardHtml: cardHtml, bindList: bindList };
})();
