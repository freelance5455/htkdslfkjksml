window.App = window.App || {};

App.router = (function () {
  var tabs = ['quran', 'activity', 'favorit', 'developer'];
  var titles = {
    quran: 'Al-Quran Digital',
    activity: 'Activity • Al-Quran Digital',
    favorit: 'Favorit • Al-Quran Digital',
    developer: 'Developer • Al-Quran Digital',
    settings: 'Pengaturan • Al-Quran Digital'
  };
  var lastTab = '#/quran';
  var currentName = null;
  var scrollMemory = {};

  function isTab(name) {
    return tabs.indexOf(name) !== -1;
  }

  function parse() {
    var parts = window.location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
    var name = parts[0] || 'quran';

    if (name === 'surah') {
      var number = parseInt(parts[1], 10);
      var ayah = parseInt(parts[2], 10);

      if (!(number >= 1 && number <= 114)) {
        return { name: 'quran' };
      }
      return { name: 'surah', number: number, ayah: ayah > 0 ? ayah : null };
    }

    if (isTab(name) || name === 'settings') {
      return { name: name };
    }

    return { name: 'quran' };
  }

  function showView(id) {
    Array.prototype.forEach.call(document.querySelectorAll('.view'), function (section) {
      section.hidden = section.id !== 'view-' + id;
    });
  }

  function updateNav(name) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-nav]'), function (link) {
      var active = link.getAttribute('data-nav') === name;
      link.classList.toggle('active', active);

      if (active) {
        link.setAttribute('aria-current', 'page');
      } else {
        link.removeAttribute('aria-current');
      }
    });

    document.body.classList.toggle('nav-hidden', name === 'surah' || name === 'settings');
  }

  function enterTab(name) {
    if (name === 'quran') {
      return App.quran.enter();
    }
    if (name === 'activity') {
      return App.activity.render();
    }
    if (name === 'favorit') {
      return App.favorites.render();
    }
    if (name === 'developer') {
      return App.developer.render();
    }
    return App.settings.render();
  }

  function handle() {
    var route = parse();

    if (currentName && isTab(currentName)) {
      scrollMemory[currentName] = window.scrollY;
    }
    if (currentName === 'surah') {
      App.detail.leave();
    }

    currentName = route.name;
    showView(route.name === 'surah' ? 'detail' : route.name);
    updateNav(route.name);

    if (route.name === 'surah') {
      document.title = 'Al-Quran Digital';
      App.detail.enter(route.number, route.ayah);
      return;
    }

    document.title = titles[route.name];

    if (isTab(route.name)) {
      lastTab = '#/' + route.name;
    }

    window.scrollTo(0, 0);

    var saved = scrollMemory[route.name] || 0;
    Promise.resolve(enterTab(route.name)).then(function () {
      if (saved && currentName === route.name) {
        window.scrollTo(0, saved);
      }
    });
  }

  function go(hash) {
    if (window.location.hash === hash) {
      handle();
    } else {
      window.location.hash = hash;
    }
  }

  function back() {
    go(lastTab);
  }

  function start() {
    window.addEventListener('hashchange', handle);
    handle();
  }

  return { start: start, go: go, back: back };
})();
