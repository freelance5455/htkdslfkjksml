window.App = window.App || {};

App.favorites = (function () {
  var view = null;

  function list() {
    return App.storage.get().favorites;
  }

  function isFavorite(number) {
    return list().indexOf(number) !== -1;
  }

  function starButton(number) {
    var active = isFavorite(number);

    return '<button type="button" class="fav-btn' + (active ? ' active' : '') + '" data-fav="' + number +
      '" aria-pressed="' + active + '" aria-label="' + (active ? 'Hapus dari favorit' : 'Tambah ke favorit') + '">' +
      App.icons.svg(active ? 'starFilled' : 'star', 20) + '</button>';
  }

  function refreshStars() {
    var buttons = document.querySelectorAll('[data-fav]');

    Array.prototype.forEach.call(buttons, function (button) {
      var number = Number(button.getAttribute('data-fav'));
      var active = isFavorite(number);

      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
      button.setAttribute('aria-label', active ? 'Hapus dari favorit' : 'Tambah ke favorit');
      button.innerHTML = App.icons.svg(active ? 'starFilled' : 'star', 20);
    });
  }

  function toggle(number) {
    var items = list();
    var index = items.indexOf(number);

    if (index === -1) {
      items.push(number);
      App.ui.toast('Ditambahkan ke favorit');
    } else {
      items.splice(index, 1);
      App.ui.toast('Dihapus dari favorit');
    }

    App.storage.save();
    refreshStars();
    document.dispatchEvent(new CustomEvent('favorites:changed'));
  }

  function clearAll() {
    App.storage.get().favorites = [];
    App.storage.save();
    refreshStars();
    document.dispatchEvent(new CustomEvent('favorites:changed'));
  }

  function renderEmpty() {
    return '<div class="empty-state">' +
      '<div class="empty-icon">' + App.icons.svg('star', 44) + '</div>' +
      '<h3>Belum ada favorit</h3>' +
      '<p>Tekan ikon bintang pada surah yang ingin kamu simpan, lalu surah itu akan muncul di sini.</p>' +
      '<a class="btn btn-primary" href="#/quran">Jelajahi Surah</a>' +
      '</div>';
  }

  function renderCards(surahs) {
    var ids = list();
    var items = surahs.filter(function (surah) {
      return ids.indexOf(surah.number) !== -1;
    });

    var count = items.length;

    view.innerHTML =
      '<header class="page-head">' +
        '<div class="container">' +
          '<h1 class="page-title">Favorit</h1>' +
          '<p class="page-sub">' + (count ? count + ' surah tersimpan' : 'Surah pilihanmu tersimpan di sini') + '</p>' +
        '</div>' +
      '</header>' +
      '<div class="container">' +
        (count
          ? '<div class="surah-list">' + items.map(App.quran.cardHtml).join('') + '</div>'
          : renderEmpty()) +
      '</div>';
  }

  function render() {
    view = document.getElementById('view-favorit');

    return App.api.fetchSurahs().then(renderCards).catch(function () {
      view.innerHTML =
        '<header class="page-head"><div class="container"><h1 class="page-title">Favorit</h1></div></header>' +
        '<div class="container"><div class="empty-state">' +
        '<div class="empty-icon">' + App.icons.svg('refresh', 44) + '</div>' +
        '<h3>Data surah gagal dimuat</h3>' +
        '<p>Periksa koneksi internet kamu lalu coba lagi.</p>' +
        '<button type="button" class="btn btn-primary" data-retry-favorites>Coba Lagi</button>' +
        '</div></div>';
    });
  }

  function init() {
    view = document.getElementById('view-favorit');
    App.quran.bindList(view);

    view.addEventListener('click', function (event) {
      if (event.target.closest('[data-retry-favorites]')) {
        render();
      }
    });

    document.addEventListener('favorites:changed', function () {
      if (!view.hidden) {
        render();
      }
    });
  }

  return {
    init: init,
    render: render,
    toggle: toggle,
    clearAll: clearAll,
    isFavorite: isFavorite,
    starButton: starButton,
    refreshStars: refreshStars
  };
})();
