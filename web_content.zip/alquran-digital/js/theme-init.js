(function () {
  var mode = 'auto';
  try {
    var saved = JSON.parse(localStorage.getItem('alquran_digital_v1'));
    if (saved && saved.settings && saved.settings.theme) {
      mode = saved.settings.theme;
    }
  } catch (error) {}

  var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  var dark = mode === 'dark' || (mode === 'auto' && prefersDark);
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
})();
