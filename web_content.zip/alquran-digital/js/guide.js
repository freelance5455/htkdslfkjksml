window.App = window.App || {};

App.guide = (function () {
  var topics = [
    {
      icon: 'book',
      title: 'Membaca Al-Quran',
      text: 'Buka tab ALQURAN lalu pilih surah. Teks Arab tampil bersama terjemahan Indonesia di bawah setiap ayat. Ukuran huruf dan terjemahan bisa diubah di Pengaturan.'
    },
    {
      icon: 'search',
      title: 'Mencari surah dan juz',
      text: 'Ketik nama atau nomor surah di kolom pencarian. Gunakan tombol Juz di bagian atas untuk menampilkan surah yang ada di juz tertentu.'
    },
    {
      icon: 'headphones',
      title: 'Mendengarkan murottal',
      text: 'Di halaman surah, tekan tombol putar di bagian bawah untuk memutar dari ayat pertama, atau tombol putar kecil di tiap ayat untuk mulai dari ayat itu. Ganti qari di Pengaturan.'
    },
    {
      icon: 'star',
      title: 'Surah favorit',
      text: 'Tekan ikon bintang pada kartu surah atau di halaman surah. Semua surah favorit tersimpan di tab FAVORIT.'
    },
    {
      icon: 'activity',
      title: 'Activity',
      text: 'Tab ACTIVITY mencatat bacaan terakhir, jumlah ayat yang sudah dibaca, audio yang diputar, hari beruntun, dan riwayat. Tekan Lanjutkan Membaca untuk kembali ke posisi terakhir.'
    },
    {
      icon: 'info',
      title: 'Tafsir',
      text: 'Tekan ikon info di halaman surah untuk membaca tafsir Kemenag RI. Fitur ini membutuhkan koneksi internet.'
    },
    {
      icon: 'moon',
      title: 'Tema terang dan gelap',
      text: 'Tekan ikon matahari atau bulan di beranda untuk berganti tema. Di Pengaturan kamu juga bisa memilih tema otomatis mengikuti perangkat.'
    },
    {
      icon: 'trash',
      title: 'Data dan privasi',
      text: 'Pengaturan, favorit, dan aktivitas disimpan di browser perangkat ini saja, tanpa akun. Kamu bisa menghapusnya kapan saja lewat Pengaturan.'
    }
  ];

  function open() {
    var html = '<div class="guide-list">' + topics.map(function (topic) {
      return '<div class="guide-item">' +
        '<span class="guide-icon">' + App.icons.svg(topic.icon, 20) + '</span>' +
        '<div><h3>' + topic.title + '</h3><p>' + topic.text + '</p></div>' +
        '</div>';
    }).join('') + '</div>';

    App.ui.openSheet({
      title: 'Panduan Penggunaan',
      subtitle: 'Cara memakai Al-Quran Digital',
      html: html
    });
  }

  return { open: open };
})();
