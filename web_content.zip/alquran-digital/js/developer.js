window.App = window.App || {};

App.developer = (function () {
  function linkButton(className, icon, label, url) {
    return '<a class="link-btn ' + className + '" href="' + url + '" target="_blank" rel="noopener noreferrer">' +
      '<span class="link-btn-icon">' + App.icons.svg(icon, 22) + '</span>' +
      '<span class="link-btn-label">' + label + '</span>' +
      App.icons.svg('chevron', 18) +
      '</a>';
  }

  function render() {
    var view = document.getElementById('view-developer');
    var links = App.config.links;

    view.innerHTML =
      '<header class="page-head">' +
        '<div class="container">' +
          '<h1 class="page-title">Developer</h1>' +
          '<p class="page-sub">Kenali pembuat aplikasi ini</p>' +
        '</div>' +
      '</header>' +
      '<div class="container stack">' +
        '<div class="card dev-card">' +
          '<div class="avatar" aria-hidden="true">R</div>' +
          '<h2 class="dev-name">HARZ</h2>' +
          '<p class="dev-role">Developer</p>' +
          '<p class="dev-text">HARZ adalah developer yang membuat Al-Quran Digital. Aplikasi ini dibuat agar membaca, mendengarkan, dan mempelajari Al-Quran terasa mudah dan nyaman di mana saja.</p>' +
        '</div>' +
        '<div class="link-list">' +
          linkButton('link-primary', 'whatsapp', 'HUBUNGI DEVELOPER', wa.me/6285835437636 +
          linkButton('link-outline', 'tiktok', 'IKUTI TIKTOK', https://www.tiktok.com/@hrzz_suka_susu2?_r=1&_t=ZS-9BQO02pU3jK) +
          linkButton('link-soft', 'coffee', 'DONATE DEVELOPER', https://saweria.co/azharline) +
        '</div>' +
        '<p class="version-text">Al-Quran Digital • Versi 1.0.0</p>' +
      '</div>';
  }

  return { render: render };
})();
