window.App = window.App || {};

App.settings = (function () {
  var view = null;
  var limits = { arabic: { min: 20, max: 40, step: 2 }, translation: { min: 13, max: 22, step: 1 } };

  function current() {
    return App.storage.get().settings;
  }

  function applyDisplay() {
    var values = current();
    var root = document.documentElement;

    root.style.setProperty('--arabic-size', values.arabicFontSize + 'px');
    root.style.setProperty('--translation-size', values.translationFontSize + 'px');
    document.body.classList.toggle('hide-translation', !values.showTranslation);
  }

  function setValue(key, value) {
    current()[key] = value;
    App.storage.save();

    if (key === 'theme') {
      App.theme.apply(value);
      document.dispatchEvent(new CustomEvent('theme:changed'));
    }

    applyDisplay();
  }

  function themeOption(mode, icon, label, active) {
    return '<button type="button" class="seg-btn' + (active === mode ? ' active' : '') +
      '" data-theme-option="' + mode + '">' + App.icons.svg(icon, 18) + '<span>' + label + '</span></button>';
  }

  function toggleRow(key, title, description, checked) {
    return '<label class="setting-row">' +
      '<span class="setting-text"><strong>' + title + '</strong><small>' + description + '</small></span>' +
      '<span class="switch"><input type="checkbox" data-setting="' + key + '"' + (checked ? ' checked' : '') + '>' +
      '<span class="switch-track"></span></span>' +
      '</label>';
  }

  function sectionTitle(icon, title) {
    return '<div class="section-title-row">' + App.icons.svg(icon, 20) + '<h2>' + title + '</h2></div>';
  }

  function render() {
    view = document.getElementById('view-settings');

    var values = current();
    var reciterOptions = App.config.reciters.map(function (item, index) {
      return '<option value="' + index + '"' + (values.reciterIndex === index ? ' selected' : '') + '>' +
        App.ui.escapeHtml(item.name) + '</option>';
    }).join('');

    view.innerHTML =
      '<header class="page-head">' +
        '<div class="container page-head-row">' +
          '<button type="button" class="icon-btn glass" data-act="back" aria-label="Kembali">' + App.icons.svg('back', 20) + '</button>' +
          '<div><h1 class="page-title">Pengaturan</h1><p class="page-sub">Perubahan tersimpan otomatis</p></div>' +
        '</div>' +
      '</header>' +
      '<div class="container stack">' +

        '<section class="card">' +
          sectionTitle('sun', 'Tampilan') +
          '<p class="field-label">Tema</p>' +
          '<div class="segmented">' +
            themeOption('light', 'sun', 'Terang', values.theme) +
            themeOption('dark', 'moon', 'Gelap', values.theme) +
            themeOption('auto', 'monitor', 'Otomatis', values.theme) +
          '</div>' +
        '</section>' +

        '<section class="card">' +
          sectionTitle('book', 'Terjemahan') +
          toggleRow('showTranslation', 'Tampilkan Terjemahan', 'Terjemahan Indonesia di bawah setiap ayat', values.showTranslation) +
          '<p class="field-label">Ukuran Terjemahan: <span id="translationSizeValue">' + values.translationFontSize + '</span></p>' +
          '<input type="range" class="range" data-setting="translationFontSize" min="' + limits.translation.min +
            '" max="' + limits.translation.max + '" step="' + limits.translation.step + '" value="' + values.translationFontSize + '">' +
        '</section>' +

        '<section class="card">' +
          sectionTitle('code', 'Teks Arab') +
          '<p class="field-label">Ukuran Font Arab</p>' +
          '<div class="slider-row">' +
            '<button type="button" class="icon-btn small" data-act="font-down" aria-label="Perkecil">' + App.icons.svg('minus', 16) + '</button>' +
            '<input type="range" class="range" data-setting="arabicFontSize" min="' + limits.arabic.min +
              '" max="' + limits.arabic.max + '" step="' + limits.arabic.step + '" value="' + values.arabicFontSize + '">' +
            '<button type="button" class="icon-btn small" data-act="font-up" aria-label="Perbesar">' + App.icons.svg('plus', 16) + '</button>' +
          '</div>' +
          '<p class="field-label">Ukuran: <span id="arabicSizeValue">' + values.arabicFontSize + '</span></p>' +
          '<p class="font-preview" lang="ar" dir="rtl">' + App.config.bismillah + '</p>' +
        '</section>' +

        '<section class="card">' +
          sectionTitle('headphones', 'Audio') +
          '<p class="field-label">Pilih Qari</p>' +
          '<select class="select" data-setting="reciterIndex" aria-label="Pilih qari">' + reciterOptions + '</select>' +
          toggleRow('autoPlayNext', 'Putar Ayat Berikutnya', 'Lanjut otomatis setelah satu ayat selesai', values.autoPlayNext) +
          toggleRow('autoScroll', 'Gulir Otomatis', 'Layar mengikuti ayat yang sedang diputar', values.autoScroll) +
        '</section>' +

        '<section class="card">' +
          sectionTitle('help', 'Bantuan') +
          '<button type="button" class="btn btn-outline btn-block" data-act="guide">Buka Panduan Penggunaan</button>' +
        '</section>' +

        '<section class="card">' +
          sectionTitle('trash', 'Data') +
          '<div class="button-stack">' +
            '<button type="button" class="btn btn-outline btn-block" data-act="clear-favorites">Hapus Semua Favorit</button>' +
            '<button type="button" class="btn btn-outline btn-block" data-act="clear-activity">Hapus Riwayat dan Statistik</button>' +
            '<button type="button" class="btn btn-outline btn-block" data-act="reset-settings">Atur Ulang Pengaturan</button>' +
            '<button type="button" class="btn btn-danger btn-block" data-act="clear-all">Hapus Semua Data</button>' +
          '</div>' +
        '</section>' +

      '</div>';
  }

  function syncArabicControls() {
    var size = current().arabicFontSize;
    view.querySelector('[data-setting="arabicFontSize"]').value = size;
    view.querySelector('#arabicSizeValue').textContent = size;
  }

  function changeArabicSize(delta) {
    var next = current().arabicFontSize + delta;
    next = Math.max(limits.arabic.min, Math.min(limits.arabic.max, next));
    setValue('arabicFontSize', next);
    syncArabicControls();
  }

  function clearActivity() {
    var data = App.storage.get();
    data.history = [];
    data.lastRead = null;
    data.readAyahs = {};
    data.days = [];
    data.audioPlays = 0;
    App.storage.save();
    App.ui.toast('Riwayat dan statistik dihapus');
  }

  function resetSettings() {
    App.storage.get().settings = Object.assign({}, App.config.defaults);
    App.storage.save();
    App.theme.apply(App.config.defaults.theme);
    applyDisplay();
    render();
    App.ui.toast('Pengaturan dikembalikan ke awal');
  }

  function clearEverything() {
    App.storage.reset();
    App.theme.apply(App.config.defaults.theme);
    applyDisplay();
    App.favorites.refreshStars();
    render();
    App.ui.toast('Semua data dihapus');
  }

  function handleClick(event) {
    var themeButton = event.target.closest('[data-theme-option]');
    if (themeButton) {
      setValue('theme', themeButton.getAttribute('data-theme-option'));
      Array.prototype.forEach.call(view.querySelectorAll('[data-theme-option]'), function (button) {
        button.classList.toggle('active', button === themeButton);
      });
      return;
    }

    var button = event.target.closest('[data-act]');
    if (!button) {
      return;
    }

    var action = button.getAttribute('data-act');

    if (action === 'back') {
      App.router.back();
    } else if (action === 'guide') {
      App.guide.open();
    } else if (action === 'font-up') {
      changeArabicSize(limits.arabic.step);
    } else if (action === 'font-down') {
      changeArabicSize(-limits.arabic.step);
    } else if (action === 'clear-favorites') {
      App.ui.confirmAction('Hapus semua surah favorit?', 'Hapus', function () {
        App.favorites.clearAll();
        App.ui.toast('Favorit dihapus');
      });
    } else if (action === 'clear-activity') {
      App.ui.confirmAction('Hapus semua riwayat, bacaan terakhir, dan statistik?', 'Hapus', clearActivity);
    } else if (action === 'reset-settings') {
      App.ui.confirmAction('Kembalikan semua pengaturan ke bawaan?', 'Atur Ulang', resetSettings);
    } else if (action === 'clear-all') {
      App.ui.confirmAction('Hapus favorit, riwayat, statistik, dan pengaturan? Tindakan ini tidak bisa dibatalkan.', 'Hapus Semua', clearEverything);
    }
  }

  function handleInput(event) {
    var input = event.target.closest('[data-setting]');
    if (!input || input.type !== 'range') {
      return;
    }

    var key = input.getAttribute('data-setting');
    var value = Number(input.value);

    setValue(key, value);

    if (key === 'arabicFontSize') {
      view.querySelector('#arabicSizeValue').textContent = value;
    } else {
      view.querySelector('#translationSizeValue').textContent = value;
    }
  }

  function handleChange(event) {
    var input = event.target.closest('[data-setting]');
    if (!input || input.type === 'range') {
      return;
    }

    var key = input.getAttribute('data-setting');

    if (input.type === 'checkbox') {
      setValue(key, input.checked);
    } else if (key === 'reciterIndex') {
      setValue(key, Number(input.value));
    }
  }

  function init() {
    view = document.getElementById('view-settings');
    view.addEventListener('click', handleClick);
    view.addEventListener('input', handleInput);
    view.addEventListener('change', handleChange);
  }

  return { init: init, render: render, applyDisplay: applyDisplay };
})();
