window.App = window.App || {};

App.activity = (function () {
  var view = null;

  function dayKey(date) {
    var month = String(date.getMonth() + 1).padStart(2, '0');
    var day = String(date.getDate()).padStart(2, '0');
    return date.getFullYear() + '-' + month + '-' + day;
  }

  function touchDay(data) {
    var today = dayKey(new Date());
    var days = data.days;

    if (days[days.length - 1] !== today) {
      days.push(today);
    }
    if (days.length > 400) {
      data.days = days.slice(-400);
    }
  }

  function currentStreak(days) {
    var known = {};
    var cursor = new Date();
    var count = 0;

    days.forEach(function (key) {
      known[key] = true;
    });

    if (!known[dayKey(cursor)]) {
      cursor.setDate(cursor.getDate() - 1);
    }

    while (known[dayKey(cursor)]) {
      count += 1;
      cursor.setDate(cursor.getDate() - 1);
    }

    return count;
  }

  function countReadAyahs(readAyahs) {
    return Object.keys(readAyahs).reduce(function (total, key) {
      return total + readAyahs[key].length;
    }, 0);
  }

  function countReadSurahs(readAyahs) {
    return Object.keys(readAyahs).filter(function (key) {
      return readAyahs[key].length > 0;
    }).length;
  }

  function recordOpen(surah) {
    var data = App.storage.get();
    var previous = data.history.filter(function (item) {
      return item.surah === surah.number;
    })[0];

    data.history = data.history.filter(function (item) {
      return item.surah !== surah.number;
    });

    data.history.unshift({
      surah: surah.number,
      latin: surah.latin,
      arabic: surah.arabic,
      ayah: previous ? previous.ayah : 1,
      time: Date.now()
    });

    if (data.history.length > App.config.maxHistory) {
      data.history.length = App.config.maxHistory;
    }

    touchDay(data);
    App.storage.save();
  }

  function recordRead(surah, freshAyahs, topAyah) {
    var data = App.storage.get();
    var key = String(surah.number);
    var read = data.readAyahs[key] || (data.readAyahs[key] = []);
    var now = Date.now();

    freshAyahs.forEach(function (number) {
      if (read.indexOf(number) === -1) {
        read.push(number);
      }
    });

    data.lastRead = {
      surah: surah.number,
      latin: surah.latin,
      arabic: surah.arabic,
      ayah: topAyah,
      time: now
    };

    if (data.history.length && data.history[0].surah === surah.number) {
      data.history[0].ayah = topAyah;
      data.history[0].time = now;
    }

    touchDay(data);
    App.storage.save();
  }

  function recordPlay() {
    var data = App.storage.get();
    data.audioPlays += 1;
    touchDay(data);
    App.storage.save();
  }

  function statCard(icon, value, label) {
    return '<div class="stat-card">' +
      '<span class="stat-icon">' + App.icons.svg(icon, 20) + '</span>' +
      '<strong class="stat-value">' + value + '</strong>' +
      '<span class="stat-label">' + label + '</span>' +
      '</div>';
  }

  function lastReadHtml(last) {
    if (!last) {
      return '<div class="card resume-card">' +
        '<p class="resume-label">Terakhir Dibaca</p>' +
        '<h3>Belum ada bacaan</h3>' +
        '<p class="muted">Mulai membaca dan progresmu akan tercatat otomatis di sini.</p>' +
        '<a class="btn btn-primary" href="#/surah/1">Mulai Membaca</a>' +
        '</div>';
    }

    return '<div class="card resume-card">' +
      '<p class="resume-label">Terakhir Dibaca</p>' +
      '<h3>' + App.ui.escapeHtml(last.latin) + ' <span class="resume-arabic" lang="ar">' + App.ui.escapeHtml(last.arabic) + '</span></h3>' +
      '<p class="muted">Ayat ' + last.ayah + ' • ' + App.ui.timeAgo(last.time) + '</p>' +
      '<a class="btn btn-primary" href="#/surah/' + last.surah + '/' + last.ayah + '">Lanjutkan Membaca</a>' +
      '</div>';
  }

  function historyHtml(history) {
    if (!history.length) {
      return '<div class="empty-inline">' + App.icons.svg('clock', 28) + '<p>Riwayat bacaan masih kosong.</p></div>';
    }

    return '<div class="history-list">' + history.map(function (item) {
      return '<a class="history-item" href="#/surah/' + item.surah + '/' + item.ayah + '">' +
        '<span class="history-number">' + item.surah + '</span>' +
        '<span class="history-text"><strong>' + App.ui.escapeHtml(item.latin) + '</strong>' +
        '<small>Ayat ' + item.ayah + ' • ' + App.ui.timeAgo(item.time) + '</small></span>' +
        '<span class="history-arabic" lang="ar">' + App.ui.escapeHtml(item.arabic) + '</span>' +
        '</a>';
    }).join('') + '</div>';
  }

  function render() {
    view = document.getElementById('view-activity');

    var data = App.storage.get();
    var ayahsRead = countReadAyahs(data.readAyahs);
    var percent = Math.min(100, (ayahsRead / App.config.totalAyahs) * 100);
    var percentText = percent.toFixed(1).replace('.', ',');

    view.innerHTML =
      '<header class="page-head">' +
        '<div class="container">' +
          '<h1 class="page-title">Activity</h1>' +
          '<p class="page-sub">Pantau perjalanan membaca Al-Quran kamu</p>' +
        '</div>' +
      '</header>' +
      '<div class="container stack">' +
        lastReadHtml(data.lastRead) +
        '<div class="stat-grid">' +
          statCard('book', App.ui.formatNumber(countReadSurahs(data.readAyahs)), 'Surah dibaca') +
          statCard('check', App.ui.formatNumber(ayahsRead), 'Ayat dibaca') +
          statCard('headphones', App.ui.formatNumber(data.audioPlays), 'Audio diputar') +
          statCard('flame', currentStreak(data.days) + ' hari', 'Hari beruntun') +
        '</div>' +
        '<div class="card">' +
          '<div class="progress-head"><strong>Progres Khatam</strong><span>' + percentText + '%</span></div>' +
          '<div class="progress"><div class="progress-bar" style="width:' + percent + '%"></div></div>' +
          '<p class="muted small-text">' + App.ui.formatNumber(ayahsRead) + ' dari ' + App.ui.formatNumber(App.config.totalAyahs) + ' ayat</p>' +
        '</div>' +
        '<div>' +
          '<div class="section-head"><h2 class="section-title">Riwayat Bacaan</h2>' +
          (data.history.length ? '<button type="button" class="text-btn danger" data-act="clear-history">' + App.icons.svg('trash', 16) + 'Hapus</button>' : '') +
          '</div>' +
          historyHtml(data.history) +
        '</div>' +
      '</div>';
  }

  function clearHistory() {
    var data = App.storage.get();
    data.history = [];
    App.storage.save();
    App.ui.toast('Riwayat dihapus');
    render();
  }

  function init() {
    view = document.getElementById('view-activity');

    view.addEventListener('click', function (event) {
      if (event.target.closest('[data-act="clear-history"]')) {
        App.ui.confirmAction('Hapus semua riwayat bacaan? Statistik tidak ikut terhapus.', 'Hapus', clearHistory);
      }
    });
  }

  return {
    init: init,
    render: render,
    recordOpen: recordOpen,
    recordRead: recordRead,
    recordPlay: recordPlay,
    currentStreak: currentStreak
  };
})();
