window.App = window.App || {};

App.detail = (function () {
  var view = null;
  var current = null;
  var verses = [];
  var observer = null;
  var visible = {};
  var audio = null;
  var loadToken = 0;
  var player = { reciter: null, urls: [], index: -1, loading: false };

  function settings() {
    return App.storage.get().settings;
  }

  function reciter() {
    return App.config.reciters[settings().reciterIndex] || App.config.reciters[0];
  }

  function isPlaying() {
    return !!audio && !!audio.getAttribute('src') && !audio.paused && !audio.ended;
  }

  function backButton() {
    return '<button type="button" class="icon-btn glass" data-act="back" aria-label="Kembali">' + App.icons.svg('back', 20) + '</button>';
  }

  function renderLoading() {
    view.innerHTML =
      '<div class="detail-top"><div class="container detail-top-row">' + backButton() +
      '<span class="detail-top-title">Memuat surah...</span></div></div>' +
      '<div class="container"><div class="loading-box"><div class="spinner"></div><p>Memuat Surah...</p></div></div>';
  }

  function renderError(number, ayah) {
    var target = '#/surah/' + number + (ayah ? '/' + ayah : '');

    view.innerHTML =
      '<div class="detail-top"><div class="container detail-top-row">' + backButton() +
      '<span class="detail-top-title">Gagal memuat</span></div></div>' +
      '<div class="container"><div class="empty-state">' +
        '<div class="empty-icon">' + App.icons.svg('refresh', 44) + '</div>' +
        '<h3>Surah tidak bisa dimuat</h3>' +
        '<p>Periksa koneksi internet kamu, lalu coba lagi.</p>' +
        '<button type="button" class="btn btn-primary" data-act="retry" data-target="' + target + '">Coba Lagi</button>' +
      '</div></div>';
  }

  function ayahHtml(verse) {
    return '<article class="ayah" id="ayah-' + verse.number + '" data-ayah="' + verse.number + '">' +
      '<div class="ayah-head">' +
        '<span class="ayah-badge">' + verse.number + '</span>' +
        '<span class="ayah-rule"></span>' +
        '<button type="button" class="icon-btn small ayah-play" data-act="play-ayah" data-ayah="' + verse.number +
          '" aria-label="Putar ayat ' + verse.number + '">' + App.icons.svg('play', 16) + '</button>' +
        '<button type="button" class="icon-btn small" data-act="copy-ayah" data-ayah="' + verse.number +
          '" aria-label="Salin ayat ' + verse.number + '">' + App.icons.svg('copy', 16) + '</button>' +
      '</div>' +
      '<div class="ayah-box">' +
        '<p class="ayah-arabic" lang="ar" dir="rtl">' + App.ui.escapeHtml(verse.text) + '</p>' +
        (verse.translation ? '<p class="ayah-translation">' + App.ui.escapeHtml(verse.translation) + '</p>' : '') +
      '</div>' +
    '</article>';
  }

  function surahNavHtml(number) {
    var previous = number > 1
      ? '<a class="btn btn-outline" href="#/surah/' + (number - 1) + '">' + App.icons.svg('back', 16) + 'Sebelumnya</a>'
      : '<span></span>';
    var next = number < 114
      ? '<a class="btn btn-outline" href="#/surah/' + (number + 1) + '">Berikutnya' + App.icons.svg('chevron', 16) + '</a>'
      : '<span></span>';

    return '<div class="surah-nav">' + previous + next + '</div>';
  }

  function playerHtml() {
    return '<div class="player"><div class="player-inner">' +
      '<div class="player-info">' +
        '<span class="player-title" id="playerTitle">Putar murottal surah</span>' +
        '<span class="player-sub">' + App.ui.escapeHtml(reciter().name) + '</span>' +
      '</div>' +
      '<div class="player-controls">' +
        '<button type="button" class="icon-btn" data-act="prev" aria-label="Ayat sebelumnya">' + App.icons.svg('skipBack', 18) + '</button>' +
        '<button type="button" class="play-main" data-act="toggle-play" aria-label="Putar">' + App.icons.svg('play', 22) + '</button>' +
        '<button type="button" class="icon-btn" data-act="next" aria-label="Ayat berikutnya">' + App.icons.svg('skipForward', 18) + '</button>' +
      '</div>' +
    '</div></div>';
  }

  function renderPage(surah, showBismillah, targetAyah) {
    var tone = surah.type === 'Makkiyah' ? 'makki' : 'madani';

    view.innerHTML =
      '<div class="detail-top"><div class="container detail-top-row">' +
        backButton() +
        '<span class="detail-top-title">' + App.ui.escapeHtml(surah.latin) + '</span>' +
        '<div class="detail-top-actions">' +
          App.favorites.starButton(surah.number).replace('class="fav-btn', 'class="icon-btn glass fav-btn') +
          '<button type="button" class="icon-btn glass" data-act="tafsir" aria-label="Tafsir">' + App.icons.svg('info', 20) + '</button>' +
          '<button type="button" class="icon-btn glass" data-act="settings" aria-label="Pengaturan">' + App.icons.svg('settings', 20) + '</button>' +
        '</div>' +
      '</div></div>' +
      '<header class="detail-hero"><div class="container">' +
        '<h1 class="detail-arabic" lang="ar">' + App.ui.escapeHtml(surah.arabic) + '</h1>' +
        '<p class="detail-latin">' + App.ui.escapeHtml(surah.latin) + '</p>' +
        '<p class="detail-meaning">' + App.ui.escapeHtml(surah.meaning) + '</p>' +
        '<div class="tag-row">' +
          '<span class="tag">' + App.icons.svg('book', 12) + surah.ayahs + ' Ayat</span>' +
          '<span class="tag tag-' + tone + '">' + App.icons.svg('pin', 12) + surah.type + '</span>' +
        '</div>' +
      '</div></header>' +
      '<div class="container ayah-list">' +
        (showBismillah ? '<p class="bismillah" lang="ar" dir="rtl">' + App.config.bismillah + '</p>' : '') +
        verses.map(ayahHtml).join('') +
        surahNavHtml(surah.number) +
      '</div>' +
      playerHtml();

    updateUi();

    if (targetAyah) {
      var card = document.getElementById('ayah-' + targetAyah);
      if (card) {
        card.scrollIntoView({ block: 'start' });
      }
    } else {
      window.scrollTo(0, 0);
    }

    setTimeout(function () {
      if (current && current.number === surah.number) {
        watchReading();
      }
    }, 350);
  }

  function disconnectObserver() {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
    visible = {};
  }

  function watchReading() {
    if (!('IntersectionObserver' in window) || !current) {
      return;
    }

    disconnectObserver();

    observer = new IntersectionObserver(function (entries) {
      var fresh = [];

      entries.forEach(function (entry) {
        var number = Number(entry.target.getAttribute('data-ayah'));

        if (entry.isIntersecting) {
          visible[number] = true;
          fresh.push(number);
        } else {
          delete visible[number];
        }
      });

      var numbers = Object.keys(visible).map(Number);
      if (numbers.length) {
        App.activity.recordRead(current, fresh, Math.min.apply(null, numbers));
      }
    }, { rootMargin: '-90px 0px -35% 0px', threshold: 0 });

    Array.prototype.forEach.call(view.querySelectorAll('.ayah'), function (card) {
      observer.observe(card);
    });
  }

  function getAudio() {
    if (audio) {
      return audio;
    }

    audio = new Audio();
    audio.preload = 'auto';

    audio.addEventListener('playing', function () {
      player.loading = false;
      updateUi();
    });
    audio.addEventListener('waiting', function () {
      player.loading = true;
      updateUi();
    });
    audio.addEventListener('pause', updateUi);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', function () {
      if (!audio.getAttribute('src')) {
        return;
      }
      player.loading = false;
      updateUi();
      App.ui.toast('Audio tidak dapat diputar. Periksa koneksi internet.');
    });

    return audio;
  }

  function clearHighlight() {
    if (!view) {
      return;
    }
    Array.prototype.forEach.call(view.querySelectorAll('.ayah.playing'), function (card) {
      card.classList.remove('playing');
    });
  }

  function highlight(index) {
    clearHighlight();

    var verse = verses[index];
    var card = verse ? document.getElementById('ayah-' + verse.number) : null;

    if (!card) {
      return;
    }

    card.classList.add('playing');

    if (settings().autoScroll) {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function updateUi() {
    if (!view || !current) {
      return;
    }

    var playing = isPlaying();
    var main = view.querySelector('.play-main');
    var title = view.querySelector('#playerTitle');
    var activeVerse = verses[player.index];

    if (main) {
      main.innerHTML = App.icons.svg(playing ? 'pause' : 'play', 22);
      main.classList.toggle('loading', player.loading);
      main.setAttribute('aria-label', playing ? 'Jeda' : 'Putar');
    }

    if (title) {
      title.textContent = activeVerse
        ? 'Ayat ' + activeVerse.number + ' dari ' + verses.length
        : 'Putar murottal surah';
    }

    Array.prototype.forEach.call(view.querySelectorAll('.ayah-play'), function (button) {
      var active = playing && activeVerse && Number(button.getAttribute('data-ayah')) === activeVerse.number;
      button.innerHTML = App.icons.svg(active ? 'pause' : 'play', 16);
    });
  }

  function loadUrls() {
    var chosen = reciter();

    if (player.reciter === chosen.id && player.urls.length) {
      return Promise.resolve(player.urls);
    }

    return App.api.fetchAudio(current.number, chosen.id).then(function (urls) {
      player.reciter = chosen.id;
      player.urls = urls;
      return urls;
    });
  }

  function playAyah(index, countPlay) {
    if (!current) {
      return;
    }

    var token = loadToken;
    player.loading = true;
    updateUi();

    loadUrls().then(function (urls) {
      if (token !== loadToken) {
        return null;
      }

      var url = urls[index];
      if (!url) {
        throw new Error('missing audio');
      }

      var element = getAudio();
      player.index = index;
      element.src = url;
      highlight(index);

      if (countPlay) {
        App.activity.recordPlay();
      }

      return element.play();
    }).catch(function (error) {
      if (error && error.name === 'AbortError') {
        return;
      }
      player.loading = false;
      updateUi();
      App.ui.toast('Audio tidak dapat diputar. Periksa koneksi internet.');
    });
  }

  function resume() {
    audio.play().catch(function () {});
  }

  function togglePlay() {
    if (audio && audio.getAttribute('src') && player.index >= 0 && !audio.ended) {
      if (audio.paused) {
        resume();
      } else {
        audio.pause();
      }
      return;
    }

    playAyah(0, true);
  }

  function playFromAyah(number) {
    var index = verses.map(function (verse) {
      return verse.number;
    }).indexOf(number);

    if (index === -1) {
      return;
    }

    if (player.index === index && audio && audio.getAttribute('src')) {
      if (audio.paused) {
        resume();
      } else {
        audio.pause();
      }
      return;
    }

    playAyah(index, player.index < 0);
  }

  function step(delta) {
    var target = player.index < 0 ? 0 : player.index + delta;
    target = Math.max(0, Math.min(verses.length - 1, target));
    playAyah(target, player.index < 0);
  }

  function handleEnded() {
    var next = player.index + 1;

    if (settings().autoPlayNext && next < verses.length) {
      playAyah(next, false);
      return;
    }

    player.index = -1;
    clearHighlight();
    updateUi();
  }

  function stopAudio(clearUrls) {
    if (audio) {
      audio.pause();
      audio.removeAttribute('src');
      audio.load();
    }

    player.index = -1;
    player.loading = false;

    if (clearUrls) {
      player.urls = [];
      player.reciter = null;
    }

    clearHighlight();
  }

  function copyAyah(number) {
    var verse = verses.filter(function (item) {
      return item.number === number;
    })[0];

    if (!verse || !current) {
      return;
    }

    var text = verse.text + '\n\n' + verse.translation + '\n\n(QS. ' + current.latin + ': ' + verse.number + ')';

    App.ui.copyText(text).then(function () {
      App.ui.toast('Ayat disalin');
    }).catch(function () {
      App.ui.toast('Gagal menyalin ayat');
    });
  }

  function tafsirHtml(items) {
    if (!items.length) {
      return '<p class="muted">Tafsir untuk surah ini belum tersedia.</p>';
    }

    return items.map(function (item) {
      return '<div class="tafsir-item"><span class="tafsir-ayah">Ayat ' + item.ayah + '</span>' +
        '<p>' + App.ui.escapeHtml(item.text) + '</p></div>';
    }).join('');
  }

  function openTafsir() {
    if (!current) {
      return;
    }

    var number = current.number;

    App.ui.openSheet({
      title: 'Tafsir ' + current.latin,
      subtitle: 'Kemenag RI',
      html: '<div class="loading-box"><div class="spinner"></div><p>Memuat tafsir...</p></div>'
    });

    App.api.fetchTafsir(number).then(function (items) {
      App.ui.setSheetBody(tafsirHtml(items));
    }).catch(function () {
      App.ui.setSheetBody(
        '<div class="empty-state compact"><h3>Tafsir gagal dimuat</h3>' +
        '<p>Periksa koneksi internet kamu, lalu coba lagi.</p>' +
        '<button type="button" class="btn btn-primary" data-act="retry-tafsir">Coba Lagi</button></div>'
      );
    });
  }

  function handleClick(event) {
    var star = event.target.closest('[data-fav]');
    if (star) {
      App.favorites.toggle(Number(star.getAttribute('data-fav')));
      return;
    }

    var button = event.target.closest('[data-act]');
    if (!button) {
      return;
    }

    var action = button.getAttribute('data-act');
    var ayah = Number(button.getAttribute('data-ayah'));

    if (action === 'back') {
      App.router.back();
    } else if (action === 'settings') {
      App.router.go('#/settings');
    } else if (action === 'tafsir') {
      openTafsir();
    } else if (action === 'toggle-play') {
      togglePlay();
    } else if (action === 'prev') {
      step(-1);
    } else if (action === 'next') {
      step(1);
    } else if (action === 'play-ayah') {
      playFromAyah(ayah);
    } else if (action === 'copy-ayah') {
      copyAyah(ayah);
    } else if (action === 'retry') {
      App.router.go(button.getAttribute('data-target'));
    }
  }

  function enter(number, targetAyah) {
    var token = ++loadToken;

    view = document.getElementById('view-detail');
    stopAudio(true);
    disconnectObserver();
    current = null;
    renderLoading();
    window.scrollTo(0, 0);

    App.api.fetchSurahs().then(function (list) {
      var surah = list.filter(function (item) {
        return item.number === number;
      })[0];

      if (!surah) {
        throw new Error('surah not found');
      }

      return App.api.fetchDetail(number).then(function (detail) {
        if (token !== loadToken) {
          return;
        }

        current = surah;
        verses = detail.verses;
        App.activity.recordOpen(surah);
        renderPage(surah, detail.showBismillah, targetAyah);
      });
    }).catch(function () {
      if (token === loadToken) {
        renderError(number, targetAyah);
      }
    });
  }

  function leave() {
    loadToken += 1;
    stopAudio(true);
    disconnectObserver();
    current = null;
    App.storage.saveNow();
  }

  function init() {
    view = document.getElementById('view-detail');
    view.addEventListener('click', handleClick);

    document.getElementById('sheet').addEventListener('click', function (event) {
      if (event.target.closest('[data-act="retry-tafsir"]')) {
        openTafsir();
      }
    });
  }

  return { init: init, enter: enter, leave: leave };
})();
