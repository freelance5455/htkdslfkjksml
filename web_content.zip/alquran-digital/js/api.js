window.App = window.App || {};

App.api = (function () {
  var cache = { surahs: null, details: {}, audio: {}, tafsir: {} };
  var pendingSurahs = null;
  var arabicPattern = /[\u0600-\u06FF]/;
  var diacritics = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED]/g;

  function getJson(url) {
    return fetch(url).then(function (response) {
      if (!response.ok) {
        throw new Error('HTTP ' + response.status);
      }
      return response.json();
    });
  }

  function normaliseType(value) {
    var text = String(value || '').toLowerCase();
    return text.indexOf('mak') === 0 || text.indexOf('mec') === 0 ? 'Makkiyah' : 'Madaniyah';
  }

  function fromPrimary(list) {
    return list.map(function (item) {
      var names = item.name_translations || {};

      return {
        number: Number(item.number_of_surah),
        arabic: names.ar || item.name,
        meaning: names.id || names.en || item.name,
        english: names.en || '',
        ayahs: Number(item.number_of_ayah),
        type: normaliseType(item.type)
      };
    });
  }

  function fromFallback(list) {
    return list.map(function (item) {
      return {
        number: Number(item.number),
        arabic: String(item.name || '').replace(/^سُورَةُ\s+/, ''),
        meaning: item.englishNameTranslation || item.englishName,
        english: item.englishNameTranslation || '',
        ayahs: Number(item.numberOfAyahs),
        type: normaliseType(item.revelationType)
      };
    });
  }

  function finishList(items) {
    return items
      .sort(function (a, b) {
        return a.number - b.number;
      })
      .map(function (item) {
        item.latin = App.config.latinNames[item.number - 1] || item.english || item.meaning;
        return item;
      });
  }

  function isValidList(list) {
    return Array.isArray(list) && list.length === 114 && list.every(function (item) {
      return item.number > 0 && item.ayahs > 0 && arabicPattern.test(item.arabic);
    });
  }

  function loadFromPrimary() {
    return getJson(App.config.endpoints.surahListPrimary).then(function (data) {
      var list = finishList(fromPrimary(data));
      if (!isValidList(list)) {
        throw new Error('invalid primary list');
      }
      return list;
    });
  }

  function loadFromFallback() {
    return getJson(App.config.endpoints.surahListFallback).then(function (payload) {
      var list = finishList(fromFallback(payload.data));
      if (!isValidList(list)) {
        throw new Error('invalid fallback list');
      }
      return list;
    });
  }

  function fetchSurahs() {
    if (cache.surahs) {
      return Promise.resolve(cache.surahs);
    }
    if (pendingSurahs) {
      return pendingSurahs;
    }

    pendingSurahs = loadFromPrimary()
      .catch(loadFromFallback)
      .then(function (list) {
        cache.surahs = list;
        pendingSurahs = null;
        return list;
      }, function (error) {
        pendingSurahs = null;
        throw error;
      });

    return pendingSurahs;
  }

  function stripBismillah(text) {
    var clean = text.replace(/^[\uFEFF\u200B\s]+/, '');
    var words = clean.split(' ');
    var first = words[0].replace(diacritics, '');

    if (words.length > 4 && first.indexOf('\u0628\u0633\u0645') === 0) {
      return words.slice(4).join(' ');
    }
    return clean;
  }

  function pickEdition(editions, identifier, fallbackIndex) {
    var match = editions.filter(function (entry) {
      return entry.edition && entry.edition.identifier === identifier;
    })[0];
    return match || editions[fallbackIndex];
  }

  function fetchDetail(number) {
    if (cache.details[number]) {
      return Promise.resolve(cache.details[number]);
    }

    return getJson(App.config.endpoints.surahDetail(number)).then(function (payload) {
      var editions = payload.data;
      var arabic = pickEdition(editions, 'quran-uthmani', 0).ayahs;
      var translation = pickEdition(editions, 'id.indonesian', 1).ayahs;
      var hasBismillahHeader = number !== 1 && number !== 9;

      var verses = arabic.map(function (ayah, index) {
        var text = ayah.text;

        if (hasBismillahHeader && ayah.numberInSurah === 1) {
          text = stripBismillah(text);
        }

        return {
          number: ayah.numberInSurah,
          text: text,
          translation: translation[index] ? translation[index].text : ''
        };
      });

      var detail = { number: number, verses: verses, showBismillah: hasBismillahHeader };
      cache.details[number] = detail;
      return detail;
    });
  }

  function fetchAudio(number, reciterId) {
    var key = number + ':' + reciterId;

    if (cache.audio[key]) {
      return Promise.resolve(cache.audio[key]);
    }

    return getJson(App.config.endpoints.surahAudio(number, reciterId)).then(function (payload) {
      var urls = payload.data.ayahs.map(function (ayah) {
        return ayah.audio;
      });
      cache.audio[key] = urls;
      return urls;
    });
  }

  function fetchTafsir(number) {
    if (cache.tafsir[number]) {
      return Promise.resolve(cache.tafsir[number]);
    }

    return getJson(App.config.endpoints.tafsir(number)).then(function (payload) {
      var items = payload && payload.data && payload.data.tafsir;

      if (!Array.isArray(items)) {
        throw new Error('invalid tafsir');
      }

      var list = items.map(function (item) {
        return { ayah: item.ayat, text: item.teks };
      });
      cache.tafsir[number] = list;
      return list;
    });
  }

  return {
    fetchSurahs: fetchSurahs,
    fetchDetail: fetchDetail,
    fetchAudio: fetchAudio,
    fetchTafsir: fetchTafsir,
    stripBismillah: stripBismillah
  };
})();
