document.addEventListener('DOMContentLoaded', function () {
  var saved = App.storage.get().settings;

  App.theme.apply(saved.theme);
  App.theme.watch();
  App.settings.applyDisplay();
  App.icons.hydrate(document);

  App.ui.init();
  App.detail.init();
  App.settings.init();
  App.favorites.init();
  App.activity.init();

  App.router.start();
});
