window.App = window.App || {};

App.config = {
  storageKey: 'alquran_digital_v1',
  totalAyahs: 6236,
  maxHistory: 30,

  endpoints: {
    surahListPrimary: 'https://raw.githubusercontent.com/penggguna/QuranJSON/master/quran.json',
    surahListFallback: 'https://api.alquran.cloud/v1/surah',
    surahDetail: function (number) {
      return 'https://api.alquran.cloud/v1/surah/' + number + '/editions/quran-uthmani,id.indonesian';
    },
    surahAudio: function (number, reciterId) {
      return 'https://api.alquran.cloud/v1/surah/' + number + '/' + reciterId;
    },
    tafsir: function (number) {
      return 'https://equran.id/api/v2/tafsir/' + number;
    }
  },

  reciters: [
    { id: 'ar.alafasy', name: 'Mishari Rashid al-Afasy' },
    { id: 'ar.abdulbasitmurattal', name: 'Abdul Basit Abdul Samad' }
  ],

  links: {
    channel: 'https://whatsapp.com/channel/0029VbDGtCEDzgT8iNvBqB0V',
    tiktok: 'https://tiktok.com/@rafzline',
    donate: 'https://saweria.co/rafzline'
  },

  defaults: {
    theme: 'auto',
    showTranslation: true,
    arabicFontSize: 28,
    translationFontSize: 16,
    reciterIndex: 0,
    autoPlayNext: true,
    autoScroll: true
  },

  bismillah: 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ',

  juzStarts: [
    [1, 1], [2, 142], [2, 253], [3, 93], [4, 24], [4, 148], [5, 82], [6, 111], [7, 88], [8, 41],
    [9, 93], [11, 6], [12, 53], [15, 1], [17, 1], [18, 75], [21, 1], [23, 1], [25, 21], [27, 56],
    [29, 46], [33, 31], [36, 28], [39, 32], [41, 47], [46, 1], [51, 31], [58, 1], [67, 1], [78, 1]
  ],

  latinNames: [
    "Al-Fatihah", "Al-Baqarah", "Ali 'Imran", "An-Nisa'", "Al-Ma'idah", "Al-An'am", "Al-A'raf", "Al-Anfal",
    "At-Taubah", "Yunus", "Hud", "Yusuf", "Ar-Ra'd", "Ibrahim", "Al-Hijr", "An-Nahl", "Al-Isra'", "Al-Kahf",
    "Maryam", "Ta Ha", "Al-Anbiya'", "Al-Hajj", "Al-Mu'minun", "An-Nur", "Al-Furqan", "Asy-Syu'ara'", "An-Naml",
    "Al-Qasas", "Al-'Ankabut", "Ar-Rum", "Luqman", "As-Sajdah", "Al-Ahzab", "Saba'", "Fatir", "Ya Sin",
    "As-Saffat", "Sad", "Az-Zumar", "Gafir", "Fussilat", "Asy-Syura", "Az-Zukhruf", "Ad-Dukhan", "Al-Jasiyah",
    "Al-Ahqaf", "Muhammad", "Al-Fath", "Al-Hujurat", "Qaf", "Az-Zariyat", "At-Tur", "An-Najm", "Al-Qamar",
    "Ar-Rahman", "Al-Waqi'ah", "Al-Hadid", "Al-Mujadalah", "Al-Hasyr", "Al-Mumtahanah", "As-Saff", "Al-Jumu'ah",
    "Al-Munafiqun", "At-Tagabun", "At-Talaq", "At-Tahrim", "Al-Mulk", "Al-Qalam", "Al-Haqqah", "Al-Ma'arij",
    "Nuh", "Al-Jinn", "Al-Muzzammil", "Al-Muddassir", "Al-Qiyamah", "Al-Insan", "Al-Mursalat", "An-Naba'",
    "An-Nazi'at", "'Abasa", "At-Takwir", "Al-Infitar", "Al-Mutaffifin", "Al-Insyiqaq", "Al-Buruj", "At-Tariq",
    "Al-A'la", "Al-Gasyiyah", "Al-Fajr", "Al-Balad", "Asy-Syams", "Al-Lail", "Ad-Duha", "Asy-Syarh", "At-Tin",
    "Al-'Alaq", "Al-Qadr", "Al-Bayyinah", "Az-Zalzalah", "Al-'Adiyat", "Al-Qari'ah", "At-Takasur", "Al-'Asr",
    "Al-Humazah", "Al-Fil", "Quraisy", "Al-Ma'un", "Al-Kausar", "Al-Kafirun", "An-Nasr", "Al-Lahab", "Al-Ikhlas",
    "Al-Falaq", "An-Nas"
  ]
};

App.juz = {
  surahRange: function (juz) {
    var start = App.config.juzStarts[juz - 1];
    var next = App.config.juzStarts[juz];
    var first = start[0];
    var last = 114;

    if (next) {
      last = next[1] === 1 ? next[0] - 1 : next[0];
    }

    return { first: first, last: last };
  }
};
