package com.minibtchat;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.Looper;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Real Bluetooth (classic RFCOMM) link between exactly two phones.
 *  - User 1 listens (server). The server socket is closed as soon as one device
 *    connects, so a third device can never join.
 *  - User 2 connects (client) to a paired phone.
 *  - Both sides send a hello with their user number; if both picked the same
 *    user the link is dropped.
 * Messages are sent with DataOutputStream.writeUTF (length-prefixed UTF-8).
 */
@SuppressLint("MissingPermission")
public class BtChatService {
    public static final int IDLE = 0, LISTENING = 1, CONNECTING = 2, CONNECTED = 3;
    public static final UUID APP_UUID = UUID.fromString("8b0c5a52-2f6e-4d51-9a8e-3a1f0c6d7e11");

    public interface Listener {
        /** Called on the main thread. */
        void onState(int state, String info);

        /** Called on the main thread. */
        void onMessage(String text, boolean mine, long time);
    }

    private final BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Listener listener;
    private int state = IDLE;
    private int myRole = 1;
    private AcceptThread acceptThread;
    private ConnectThread connectThread;
    private ConnectedThread connectedThread;

    public BtChatService(Listener l) {
        listener = l;
    }

    public boolean isSupported() {
        return adapter != null;
    }

    public boolean isEnabled() {
        return adapter != null && adapter.isEnabled();
    }

    public Set<BluetoothDevice> bondedDevices() {
        return adapter == null ? null : adapter.getBondedDevices();
    }

    public synchronized int getState() {
        return state;
    }

    private synchronized void setState(final int s, final String info) {
        state = s;
        ui.post(new Runnable() {
            @Override
            public void run() {
                listener.onState(s, info);
            }
        });
    }

    private static String safeName(BluetoothDevice d) {
        String n = d.getName();
        return n == null ? d.getAddress() : n;
    }

    /** User 1: wait for User 2. */
    public synchronized void listen(int role) {
        stopAll();
        myRole = role;
        acceptThread = new AcceptThread();
        acceptThread.start();
        setState(LISTENING, "Waiting for the other user…");
    }

    /** User 2: connect to User 1's paired phone. */
    public synchronized void connect(BluetoothDevice device, int role) {
        stopAll();
        myRole = role;
        connectThread = new ConnectThread(device);
        connectThread.start();
        setState(CONNECTING, "Connecting to " + safeName(device) + "…");
    }

    public synchronized void disconnect() {
        stopAll();
        setState(IDLE, "Disconnected");
    }

    public void send(String text) {
        ConnectedThread t;
        synchronized (this) {
            if (state != CONNECTED) return;
            t = connectedThread;
        }
        if (t != null) t.sendText(text);
    }

    private synchronized void stopAll() {
        if (acceptThread != null) {
            acceptThread.cancel();
            acceptThread = null;
        }
        if (connectThread != null) {
            connectThread.cancel();
            connectThread = null;
        }
        if (connectedThread != null) {
            connectedThread.cancel();
            connectedThread = null;
        }
    }

    private synchronized void fail(String message) {
        stopAll();
        setState(IDLE, message);
    }

    private synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
        connectedThread = new ConnectedThread(socket);
        connectedThread.start();
        setState(CONNECTED, "Connected to " + safeName(device));
    }

    // ------------------------------------------------------------------ server
    private class AcceptThread extends Thread {
        private BluetoothServerSocket server;
        private volatile boolean cancelled;

        AcceptThread() {
            try {
                server = adapter.listenUsingRfcommWithServiceRecord("MiniBTChat", APP_UUID);
            } catch (IOException e) {
                server = null;
            }
        }

        @Override
        public void run() {
            if (server == null) {
                synchronized (BtChatService.this) {
                    if (acceptThread == this) fail("Cannot start listening");
                }
                return;
            }
            BluetoothSocket socket;
            try {
                socket = server.accept();            // blocks until one phone connects
            } catch (IOException e) {
                synchronized (BtChatService.this) {
                    if (!cancelled && acceptThread == this) fail("Listening stopped");
                }
                return;
            }
            try {
                server.close();                       // only two users: stop accepting
            } catch (IOException ignored) {
            }
            synchronized (BtChatService.this) {
                if (acceptThread != this) {
                    try {
                        socket.close();
                    } catch (IOException ignored) {
                    }
                    return;
                }
                acceptThread = null;
                connected(socket, socket.getRemoteDevice());
            }
        }

        void cancel() {
            cancelled = true;
            try {
                if (server != null) server.close();
            } catch (IOException ignored) {
            }
        }
    }

    // ------------------------------------------------------------------ client
    private class ConnectThread extends Thread {
        private final BluetoothDevice device;
        private BluetoothSocket socket;

        ConnectThread(BluetoothDevice d) {
            device = d;
        }

        @Override
        public void run() {
            try {
                adapter.cancelDiscovery();
                socket = device.createRfcommSocketToServiceRecord(APP_UUID);
                socket.connect();
            } catch (IOException e) {
                cancel();
                synchronized (BtChatService.this) {
                    if (connectThread == this) fail("Could not connect. Is User 1 waiting?");
                }
                return;
            }
            synchronized (BtChatService.this) {
                if (connectThread != this) {
                    cancel();
                    return;
                }
                connectThread = null;
                connected(socket, device);
            }
        }

        void cancel() {
            try {
                if (socket != null) socket.close();
            } catch (IOException ignored) {
            }
        }
    }

    // --------------------------------------------------------------- connection
    private class ConnectedThread extends Thread {
        private final BluetoothSocket socket;
        private DataInputStream in;
        private DataOutputStream out;
        private final ExecutorService writer = Executors.newSingleThreadExecutor();
        private volatile boolean cancelled;

        ConnectedThread(BluetoothSocket s) {
            socket = s;
            try {
                in = new DataInputStream(s.getInputStream());
                out = new DataOutputStream(s.getOutputStream());
            } catch (IOException e) {
                in = null;
                out = null;
            }
        }

        @Override
        public void run() {
            if (in == null || out == null) {
                lost();
                return;
            }
            writeRaw("H:" + myRole);
            try {
                while (true) {
                    handle(in.readUTF());
                }
            } catch (IOException e) {
                if (!cancelled) lost();
            }
        }

        private void handle(String m) {
            if (m.startsWith("H:")) {
                int other;
                try {
                    other = Integer.parseInt(m.substring(2).trim());
                } catch (NumberFormatException e) {
                    other = -1;
                }
                if (other == myRole) {
                    fail("Both phones chose User " + myRole + ". One must be User 1 and the other User 2.");
                }
            } else if (m.startsWith("M:")) {
                post(m.substring(2), false);
            }
        }

        private void post(final String text, final boolean mine) {
            final long now = System.currentTimeMillis();
            ui.post(new Runnable() {
                @Override
                public void run() {
                    listener.onMessage(text, mine, now);
                }
            });
        }

        private void writeRaw(final String s) {
            writer.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        synchronized (out) {
                            out.writeUTF(s);
                            out.flush();
                        }
                    } catch (IOException e) {
                        if (!cancelled) lost();
                    }
                }
            });
        }

        void sendText(final String text) {
            writer.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        synchronized (out) {
                            out.writeUTF("M:" + text);
                            out.flush();
                        }
                        post(text, true);
                    } catch (IOException e) {
                        if (!cancelled) lost();
                    }
                }
            });
        }

        private void lost() {
            synchronized (BtChatService.this) {
                if (connectedThread == this) {
                    stopAll();
                    setState(IDLE, "Connection lost");
                }
            }
        }

        void cancel() {
            cancelled = true;
            writer.shutdownNow();
            try {
                socket.close();
            } catch (IOException ignored) {
            }
        }
    }
}
