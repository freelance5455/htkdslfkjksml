package com.minibtchat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Runs the Silver Phone emulator (assets/vphone-emulator.html) in a WebView.
 * Real Bluetooth is exposed to the page as window.AndroidBT (see BtBridge).
 */
public class EmulatorActivity extends BtActivity {
    private static final int REQ_FILE = 201, REQ_MIC = 202;
    private WebView web;
    private BtBridge bridge;
    private ValueCallback<Uri[]> fileCallback;
    private PermissionRequest micRequest;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);

        bridge = new BtBridge(this);
        web.addJavascriptInterface(bridge, "AndroidBT");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest req) {
                if (Build.VERSION.SDK_INT < 23
                        || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    req.grant(req.getResources());
                } else {
                    micRequest = req;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                }
            }
        });
        web.loadUrl("file:///android_asset/vphone-emulator.html");
    }

    /** Sends an event object (already JSON) to window.onBT in the page. */
    void js(final String json) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("window.onBT&&window.onBT(" + json + ")", null);
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCallback = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_MIC && micRequest != null) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                micRequest.grant(micRequest.getResources());
            } else {
                micRequest.deny();
            }
            micRequest = null;
        }
    }

    @Override
    public void onBackPressed() {
        // Use the emulator's own back button; leave the app from the home screen.
        web.evaluateJavascript("cur", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if ("\"home\"".equals(v)) finish();
                else web.evaluateJavascript("back()", null);
            }
        });
    }

    @Override
    protected void onDestroy() {
        bridge.destroy();
        web.destroy();
        super.onDestroy();
    }
}
