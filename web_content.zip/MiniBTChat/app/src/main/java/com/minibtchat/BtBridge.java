package com.minibtchat;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Set;

/**
 * JavaScript bridge for the emulator page: window.AndroidBT.* (real Bluetooth).
 * The page receives events through window.onBT({...}).
 */
public class BtBridge implements BtChatService.Listener {
    private final EmulatorActivity act;
    private final BtChatService svc;

    BtBridge(EmulatorActivity a) {
        act = a;
        svc = new BtChatService(this);
    }

    void destroy() {
        svc.disconnect();
    }

    @JavascriptInterface
    public boolean available() {
        return svc.isSupported();
    }

    @JavascriptInterface
    public int state() {
        return svc.getState();
    }

    /** Asks permission / Bluetooth on, then answers with a {type:"devices"} event. */
    @JavascriptInterface
    public void requestDevices() {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.requireBt(svc, new Runnable() {
                    @Override
                    public void run() {
                        sendDevices();
                    }
                });
            }
        });
    }

    @SuppressLint("MissingPermission")
    private void sendDevices() {
        JSONArray arr = new JSONArray();
        Set<BluetoothDevice> set = svc.bondedDevices();
        if (set != null) {
            for (BluetoothDevice d : set) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("name", d.getName() == null ? "Unknown" : d.getName());
                    o.put("address", d.getAddress());
                    arr.put(o);
                } catch (JSONException ignored) {
                }
            }
        }
        try {
            JSONObject e = new JSONObject();
            e.put("type", "devices");
            e.put("list", arr);
            act.js(e.toString());
        } catch (JSONException ignored) {
        }
    }

    /** User 1. */
    @JavascriptInterface
    public void listen(final int role) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.requireBt(svc, new Runnable() {
                    @Override
                    public void run() {
                        svc.listen(role);
                    }
                });
            }
        });
    }

    /** User 2. */
    @SuppressLint("MissingPermission")
    @JavascriptInterface
    public void connect(final String address, final int role) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.requireBt(svc, new Runnable() {
                    @Override
                    public void run() {
                        Set<BluetoothDevice> set = svc.bondedDevices();
                        if (set == null) return;
                        for (BluetoothDevice d : set) {
                            if (d.getAddress().equals(address)) {
                                svc.connect(d, role);
                                return;
                            }
                        }
                    }
                });
            }
        });
    }

    @JavascriptInterface
    public void send(String text) {
        svc.send(text);
    }

    @JavascriptInterface
    public void disconnect() {
        svc.disconnect();
    }

    /** Saves a file (picture, QR image, ...) to the phone: Pictures or Downloads. */
    @JavascriptInterface
    public void saveFile(final String name, final String mime, final String base64) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    byte[] data = Base64.decode(base64, Base64.DEFAULT);
                    boolean img = mime != null && mime.startsWith("image/");
                    String where;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues v = new ContentValues();
                        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        String dir = (img ? Environment.DIRECTORY_PICTURES : Environment.DIRECTORY_DOWNLOADS) + "/MiniBTChat";
                        v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir);
                        Uri coll = img ? MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                                : MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                        Uri u = act.getContentResolver().insert(coll, v);
                        OutputStream os = act.getContentResolver().openOutputStream(u);
                        os.write(data);
                        os.close();
                        where = dir;
                    } else {
                        File d = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                        File f = new File(d, name);
                        FileOutputStream os = new FileOutputStream(f);
                        os.write(data);
                        os.close();
                        where = f.getAbsolutePath();
                    }
                    toast("Saved to " + where);
                } catch (Exception e) {
                    toast("Save failed: " + e.getMessage());
                }
            }
        }).start();
    }

    private void toast(final String t) {
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(act, t, Toast.LENGTH_LONG).show();
            }
        });
    }

    // ---- BtChatService.Listener -> JavaScript
    @Override
    public void onState(int state, String info) {
        try {
            JSONObject e = new JSONObject();
            e.put("type", "state");
            e.put("state", state);
            e.put("info", info);
            act.js(e.toString());
        } catch (JSONException ignored) {
        }
    }

    @Override
    public void onMessage(String text, boolean mine, long time) {
        try {
            JSONObject e = new JSONObject();
            e.put("type", "msg");
            e.put("text", text);
            e.put("mine", mine);
            e.put("time", time);
            act.js(e.toString());
        } catch (JSONException ignored) {
        }
    }
}
