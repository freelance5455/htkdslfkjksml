package com.minibtchat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.bluetooth.BluetoothDevice;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Set;

/** One chat screen, two users only. */
public class MainActivity extends BtActivity implements BtChatService.Listener {
    private BtChatService service;
    private int role = 1;

    private TextView statusText, roleText, hint;
    private View dot, setupPanel;
    private Button actionBtn, disconnectBtn, sendBtn;
    private EditText input;
    private ListView list;
    private RadioGroup radio;

    private final ArrayList<Msg> msgs = new ArrayList<>();
    private MsgAdapter adapter;
    private final SimpleDateFormat fmt = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    private static class Msg {
        final String text;
        final boolean mine;
        final long time;

        Msg(String t, boolean m, long ti) {
            text = t;
            mine = m;
            time = ti;
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        service = new BtChatService(this);

        statusText = findViewById(R.id.statusText);
        roleText = findViewById(R.id.roleText);
        hint = findViewById(R.id.hint);
        dot = findViewById(R.id.dot);
        setupPanel = findViewById(R.id.setupPanel);
        actionBtn = findViewById(R.id.actionBtn);
        disconnectBtn = findViewById(R.id.disconnectBtn);
        sendBtn = findViewById(R.id.sendBtn);
        input = findViewById(R.id.input);
        list = findViewById(R.id.list);
        radio = findViewById(R.id.radio);

        adapter = new MsgAdapter();
        list.setAdapter(adapter);

        radio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                role = id == R.id.user2 ? 2 : 1;
                refreshSetup();
            }
        });

        actionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (role == 1) {
                    requireBt(service, new Runnable() {
                        @Override
                        public void run() {
                            msgs.clear();
                            adapter.notifyDataSetChanged();
                            service.listen(1);
                        }
                    });
                } else {
                    requireBt(service, new Runnable() {
                        @Override
                        public void run() {
                            chooseDevice();
                        }
                    });
                }
            }
        });

        disconnectBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                service.disconnect();
            }
        });

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String t = input.getText().toString().trim();
                if (t.isEmpty()) return;
                service.send(t);
                input.setText("");
            }
        });

        refreshSetup();
        onState(BtChatService.IDLE, "Not connected");
    }

    private void refreshSetup() {
        roleText.setText("You: User " + role);
        if (role == 1) {
            hint.setText("User 1 waits for the connection. On the other phone choose User 2 and tap Connect.");
            actionBtn.setText("Wait for connection");
        } else {
            hint.setText("Pair both phones in Android Bluetooth settings first, then pick User 1's phone.");
            actionBtn.setText("Connect to User 1");
        }
    }

    @SuppressLint("MissingPermission")
    private void chooseDevice() {
        Set<BluetoothDevice> set = service.bondedDevices();
        if (set == null || set.isEmpty()) {
            Toast.makeText(this, "No paired devices. Pair the two phones in Android Bluetooth settings first.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        final ArrayList<BluetoothDevice> devs = new ArrayList<>(set);
        String[] names = new String[devs.size()];
        for (int i = 0; i < names.length; i++) {
            String n = devs.get(i).getName();
            names[i] = (n == null ? "Unknown" : n) + "\n" + devs.get(i).getAddress();
        }
        new AlertDialog.Builder(this)
                .setTitle("Choose User 1's phone")
                .setItems(names, new android.content.DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(android.content.DialogInterface d, int i) {
                        msgs.clear();
                        adapter.notifyDataSetChanged();
                        service.connect(devs.get(i), 2);
                    }
                })
                .show();
    }

    @Override
    public void onState(int s, String info) {
        int color = s == BtChatService.CONNECTED ? 0xFF2E7D32
                : s == BtChatService.IDLE ? 0xFF9E9E9E : 0xFFF9A825;
        GradientDrawable g = (GradientDrawable) dot.getBackground().mutate();
        g.setColor(color);
        statusText.setText(info);
        boolean idle = s == BtChatService.IDLE;
        boolean connected = s == BtChatService.CONNECTED;
        setupPanel.setVisibility(idle ? View.VISIBLE : View.GONE);
        disconnectBtn.setEnabled(!idle);
        input.setEnabled(connected);
        sendBtn.setEnabled(connected);
    }

    @Override
    public void onMessage(String text, boolean mine, long time) {
        msgs.add(new Msg(text, mine, time));
        adapter.notifyDataSetChanged();
    }

    @Override
    protected void onDestroy() {
        service.disconnect();
        super.onDestroy();
    }

    private class MsgAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return msgs.size();
        }

        @Override
        public Object getItem(int i) {
            return msgs.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View v, ViewGroup parent) {
            if (v == null) v = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_message, parent, false);
            Msg m = msgs.get(i);
            TextView bubble = v.findViewById(R.id.bubble);
            TextView time = v.findViewById(R.id.time);
            bubble.setText(m.text);
            bubble.setBackgroundResource(m.mine ? R.drawable.bubble_sent : R.drawable.bubble_received);
            bubble.setTextColor(m.mine ? 0xFFFFFFFF : 0xFF222222);
            String who = m.mine ? "You (User " + role + ")" : "User " + (role == 1 ? 2 : 1);
            time.setText(who + " · " + fmt.format(new Date(m.time)));
            int g = m.mine ? Gravity.END : Gravity.START;
            ((LinearLayout.LayoutParams) bubble.getLayoutParams()).gravity = g;
            ((LinearLayout.LayoutParams) time.getLayoutParams()).gravity = g;
            return v;
        }
    }
}
