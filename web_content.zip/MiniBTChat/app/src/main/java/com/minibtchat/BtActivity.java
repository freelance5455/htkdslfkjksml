package com.minibtchat;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.Toast;

/** Shared Bluetooth permission / "turn Bluetooth on" flow. */
public abstract class BtActivity extends Activity {
    protected static final int REQ_BT_PERM = 101, REQ_BT_ENABLE = 102;
    private Runnable pending;
    private BtChatService pendingService;

    protected boolean hasBtPermission() {
        return Build.VERSION.SDK_INT < 31
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
    }

    /** Runs r once Bluetooth permission is granted and Bluetooth is switched on. */
    protected void requireBt(BtChatService svc, Runnable r) {
        if (!svc.isSupported()) {
            Toast.makeText(this, "This device has no Bluetooth", Toast.LENGTH_LONG).show();
            return;
        }
        pending = r;
        pendingService = svc;
        if (!hasBtPermission()) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, REQ_BT_PERM);
            return;
        }
        if (!svc.isEnabled()) {
            startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQ_BT_ENABLE);
            return;
        }
        pending = null;
        r.run();
    }

    private void resume() {
        Runnable r = pending;
        BtChatService s = pendingService;
        pending = null;
        if (r != null && s != null) requireBt(s, r);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_BT_PERM) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) resume();
            else Toast.makeText(this, "Bluetooth permission is required", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BT_ENABLE) {
            if (res == RESULT_OK) resume();
            else Toast.makeText(this, "Please turn Bluetooth on", Toast.LENGTH_LONG).show();
        }
    }
}
