# Mini BT Chat — two-phone Bluetooth messenger (real Bluetooth, no internet)

Exactly **two users** can chat: **User 1** and **User 2**.
Uses classic Bluetooth RFCOMM (`BluetoothServerSocket` / `BluetoothSocket`). No internet,
no database, no AI, no third-party libraries.

> Status of this package: the source code is complete, but it was **not compiled and not run on a
> phone** by me (no Android SDK / internet was available where I wrote it). The first build may
> need a small fix; see "If the build fails" below.

## How it works
| Role | What it does |
|------|--------------|
| User 1 | Taps **Wait for connection** → listens. The listening socket closes after the first phone connects, so a 3rd phone cannot join. |
| User 2 | Taps **Connect to User 1** → picks User 1's phone from the paired list. |

Both phones exchange a hello with their user number; if both chose the same user the link is dropped.
Chat screen: status header (grey = disconnected, orange = waiting/connecting, green = connected),
chat bubbles (blue = you, grey = other user), a timestamp under every message, message box + Send,
and a **Disconnect** button.

## 1. Build the APK (pick one)
**A. Android Studio (easiest)**
1. Install Android Studio. 2. *File → Open* → select the `MiniBTChat` folder, wait for Gradle sync.
3. *Build → Build Bundle(s) / APK(s) → Build APK(s)*.
4. APK: `app/build/outputs/apk/debug/app-debug.apk` (already signed with the debug key, installable).

**B. Command line** (needs JDK 17, Android SDK, Gradle 8.7): `gradle assembleDebug` in this folder.

**C. No tools on your PC:** upload this folder to a GitHub repository; the included
`.github/workflows/build.yml` builds the APK. Download it from *Actions → Build APK → Artifacts*.

## 2. Install on both phones
1. Copy `app-debug.apk` to each phone (USB, Drive, Bluetooth…) or run `adb install app-debug.apk`.
2. Open the file on the phone and allow "Install unknown apps" for the app you opened it with.
3. Android 12+: when asked, allow **Nearby devices** (Bluetooth) permission.

## 3. Use it
1. **Pair the two phones once** in *Android Settings → Bluetooth* (accept the pairing code on both).
2. Phone A: open **Mini BT Chat**, select **User 1**, tap **Wait for connection**.
3. Phone B: open **Mini BT Chat**, select **User 2**, tap **Connect to User 1**, choose phone A.
4. Status turns green. Type a message and tap **Send**. **Disconnect** ends the link.

## 4. The Silver Phone emulator with real Bluetooth
The project also installs a second launcher icon, **Silver Phone** (`EmulatorActivity`).
It runs `app/src/main/assets/vphone-emulator.html` (the emulator, already copied there) in a WebView and
exposes real Bluetooth to it as `window.AndroidBT`. In the emulator open the **Mini BT Chat** app:
same User 1 / User 2 flow, same real Bluetooth. Outside this APK (plain browser) that emulator app
only shows a notice — it never fakes a connection.
The bridge also lets the emulator **export pictures** into the phone's `Pictures/MiniBTChat` folder.
To update the emulator later, replace the HTML file in `assets/` and rebuild.

## Files
- `BtChatService.java` – Bluetooth server/client/connection threads (the real Bluetooth code)
- `BtActivity.java` – permission + "turn Bluetooth on" flow
- `MainActivity.java`, `res/layout/*` – the one-screen chat UI
- `EmulatorActivity.java`, `BtBridge.java` – WebView host + JavaScript bridge for the emulator
- `AndroidManifest.xml` – permissions: BLUETOOTH, BLUETOOTH_ADMIN (Android ≤ 11), BLUETOOTH_CONNECT (Android 12+), RECORD_AUDIO (emulator voice apps only)

## Limits
- Android 7.0+ (API 24). Text only, up to 500 characters per message; history lives in memory only.
- Both phones must be paired first. One connection at a time (two users).
- Classic Bluetooth range (about 10 m).

## If the build fails
Send me the first error lines of the Gradle output and I will fix them. The Android Gradle Plugin /
Gradle versions are set in `build.gradle` (AGP 8.5.2) and `gradle/wrapper/gradle-wrapper.properties` (Gradle 8.7).
