Cell Biology Unit 1 Quiz — Android Project

ይህ ፕሮጀክት የቀድሞውን HTML Quiz በAndroid WebView ውስጥ አስገብቶ ወደ APK ለመገንባት የተዘጋጀ Android Studio project ነው።

አስፈላጊ፦ ይህ ፋይል የተጠናቀቀ APK አይደለም። በዚህ የሥራ አካባቢ Android SDK/Gradle ስላልተገኘ፣ APK መገንባቱን እዚህ ማረጋገጥ አልተቻለም።

APK ለመገንባት:
1. ፕሮጀክቱን ከZIP አውጣ።
2. Android Studio በኮምፒውተር ላይ ክፈት።
3. Open በመጫን የCell_Biology_Unit1_Android_Project ፎልደሩን ምረጥ።
4. Android Studio እንዲያዘጋጅ Gradle sync ጠብቅ፤ Android SDK Platform 35 እና ተስማሚ Build Tools ካልተጫኑ እንዲጭን ፍቀድ።
5. Build > Build Bundle(s) / APK(s) > Build APK(s) ምረጥ።
6. ሲጠናቀቅ Android Studio የAPK መንገድን ያሳያል። ብዙ ጊዜ app/build/outputs/apk/debug/app-debug.apk ውስጥ ይገኛል።

የመተግበሪያ መረጃ:
- App name: Cell Biology Unit 1 Quiz
- Package: com.hawassa.cellbiologyquiz
- 20 ጥያቄዎች፣ English + አማርኛ
- ከመልስ በኋላ ማብራሪያ፣ ውጤትና የመልስ ግምገማ
- ጥያቄዎቹ ከተሰጠው Cell Biology Chapter 1 ስላይድ የተዘጋጁ የመማሪያ ጥያቄዎች ናቸው።
