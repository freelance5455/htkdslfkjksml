# Socle 3.9 — Ambiance cinématique et animations du public

## Objectif
Renforcer l'immersion de l'arène 3D existante sans remplacer le moteur WebGL, les règles de dames, les compétitions ou l'interface horizontale.

## Changements
- Les supporters des quatre tribunes ont désormais un mouvement de bras variable, piloté par le temps de la scène : l'ambiance n'est plus une pose entièrement figée pendant les séquences animées.
- La caméra cinématique reçoit une dérive orbitale très légère et un mouvement vertical subtil, afin d'éviter une image totalement statique.
- Le contrôle manuel reste prioritaire : pendant le glissement de caméra, la dérive automatique est suspendue ; elle reprend après le relâchement.
- Les effets réutilisent les appels de rendu existants et le temps de scène. Ils ne modifient ni les coups légaux, ni les prises, ni les promotions, ni les résultats.

## Limites
- Les personnages et le public restent des modèles 3D stylisés construits en géométrie WebGL ; ce socle ne prétend pas produire un rendu photoréaliste.
- L'animation ambiante est actualisée lorsque la scène est redessinée (mouvement de damiste, pose, interaction ou redimensionnement). Il ne s'agit pas encore d'une simulation de foule autonome à fréquence constante.
- La validation visuelle sur navigateur et mobile doit encore être effectuée ; les contrôles réalisés ici sont automatisés.
