import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';

const dataDir = path.join(process.cwd(), 'data');
fs.mkdirSync(dataDir, { recursive: true });
export const db = new Database(path.join(dataDir, 'family-mart.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'admin',
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL DEFAULT 'General',
      description TEXT NOT NULL DEFAULT '',
      image_url TEXT NOT NULL DEFAULT '',
      price_paisa INTEGER NOT NULL CHECK(price_paisa > 0),
      stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_code TEXT NOT NULL UNIQUE,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL,
      city TEXT NOT NULL DEFAULT '',
      subtotal_paisa INTEGER NOT NULL,
      delivery_paisa INTEGER NOT NULL DEFAULT 0,
      total_paisa INTEGER NOT NULL,
      payment_method TEXT NOT NULL,
      payment_status TEXT NOT NULL DEFAULT 'unpaid',
      order_status TEXT NOT NULL DEFAULT 'pending',
      transaction_id TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
      product_name TEXT NOT NULL,
      unit_price_paisa INTEGER NOT NULL,
      quantity INTEGER NOT NULL CHECK(quantity > 0)
    );
    CREATE TABLE IF NOT EXISTS payment_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER REFERENCES orders(id),
      transaction_id TEXT NOT NULL,
      event_type TEXT NOT NULL,
      gateway_status TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      UNIQUE(transaction_id, event_type)
    );
  `);
  const count = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
  if (!count) {
    const now = new Date().toISOString();
    const seed = db.prepare(`INSERT INTO products
      (name, slug, category, description, image_url, price_paisa, stock, active, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`);
    const demo = [
      ['Everyday Tote Bag','everyday-tote-bag','Fashion','A versatile everyday tote bag.','https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=900',85000,15],
      ['Wireless Headphones','wireless-headphones','Electronics','Enjoy music, podcasts and calls.','https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=900',320000,8],
      ['Minimal Watch','minimal-watch','Accessories','A classic watch for everyday wear.','https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=900',165000,10],
      ['Home Decor Vase','home-decor-vase','Home & Living','Simple decor for your favourite space.','https://images.unsplash.com/photo-1578500494198-246f612d3b3d?w=900',125000,12],
      ['Sports Sneakers','sports-sneakers','Fashion','Comfortable sneakers for daily use.','https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=900',220000,9],
      ['Skincare Essentials','skincare-essentials','Beauty','A simple daily-care addition.','https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=900',95000,20]
    ];
    for (const p of demo) seed.run(...p, now, now);
  }
}
