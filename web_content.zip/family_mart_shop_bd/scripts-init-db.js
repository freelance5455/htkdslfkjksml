import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { db, initDatabase } from './db.js';

initDatabase();
const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD || '';
if (!email || password.length < 12 || password === 'change-this-before-first-run') {
  console.error('Set ADMIN_EMAIL and a strong ADMIN_PASSWORD (12+ characters) in .env before creating the admin.');
  process.exit(1);
}
const hash = bcrypt.hashSync(password, 12);
const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
if (existing) {
  db.prepare('UPDATE users SET password_hash = ?, role = ? WHERE email = ?').run(hash, 'admin', email);
  console.log('Updated admin password for', email);
} else {
  db.prepare('INSERT INTO users (email, password_hash, role, created_at) VALUES (?, ?, ?, ?)').run(email, hash, 'admin', new Date().toISOString());
  console.log('Created admin account:', email);
}
