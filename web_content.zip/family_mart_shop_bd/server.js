import 'dotenv/config';
import express from 'express';
import session from 'express-session';
import cookieParser from 'cookie-parser';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { db, initDatabase } from './db.js';

initDatabase();
const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, '');
const prod = process.env.NODE_ENV === 'production';
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  console.warn('WARNING: Set a long random SESSION_SECRET in .env before deployment.');
}
if (prod) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '30kb' }));
app.use(cookieParser());
app.use(session({
  name: 'fm_session',
  secret: process.env.SESSION_SECRET || 'development-only-change-this-session-secret',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: prod, maxAge: 1000 * 60 * 60 * 4 }
}));
app.use(express.static('public', { extensions: ['html'] }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false });
const checkoutLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const now = () => new Date().toISOString();
const moneyInt = v => Number.isSafeInteger(Number(v)) && Number(v) > 0 ? Number(v) : null;
const safeText = (v, max=300) => String(v ?? '').trim().slice(0, max);
const slugify = s => safeText(s, 100).toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'product';
const publicProduct = p => ({ id:p.id, name:p.name, slug:p.slug, category:p.category, description:p.description, imageUrl:p.image_url, price:p.price_paisa/100, stock:p.stock });
function requireAdmin(req,res,next){ if(req.session?.adminId) return next(); return res.status(401).json({error:'Please sign in as admin.'}); }
function csrfCheck(req,res,next) {
  if (['GET','HEAD','OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (origin) {
    try { if (new URL(origin).host !== req.get('host')) return res.status(403).json({error:'Invalid request origin.'}); }
    catch { return res.status(403).json({error:'Invalid request origin.'}); }
  }
  next();
}
app.use('/api', csrfCheck);

app.get('/api/products', (_req,res) => {
  const rows = db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all();
  res.json(rows.map(publicProduct));
});

app.get('/api/admin/session', (req,res) => res.json({ authenticated: !!req.session?.adminId, email: req.session?.adminEmail || '' }));
app.post('/api/admin/login', loginLimiter, async (req,res) => {
  const email = safeText(req.body?.email, 254).toLowerCase();
  const password = String(req.body?.password || '');
  const user = db.prepare("SELECT * FROM users WHERE email=? AND role='admin'").get(email);
  const ok = user ? await bcrypt.compare(password, user.password_hash) : false;
  if (!ok) return res.status(401).json({error:'Email or password is incorrect.'});
  req.session.regenerate(err => {
    if (err) return res.status(500).json({error:'Could not create secure session.'});
    req.session.adminId = user.id;
    req.session.adminEmail = user.email;
    res.json({ok:true,email:user.email});
  });
});
app.post('/api/admin/logout', requireAdmin, (req,res) => req.session.destroy(() => res.json({ok:true})));

app.get('/api/admin/products', requireAdmin, (_req,res) => {
  res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all().map(p=>({...publicProduct(p), active:!!p.active})));
});
app.post('/api/admin/products', requireAdmin, (req,res) => {
  const b=req.body||{}, name=safeText(b.name,100), category=safeText(b.category||'General',60);
  const price=Number(b.price), stock=Number(b.stock ?? 0);
  if(!name || !Number.isFinite(price) || price<=0 || price>100000000 || !Number.isInteger(stock) || stock<0 || stock>1000000)
    return res.status(400).json({error:'Enter a name, valid price and non-negative whole-number stock.'});
  const image=safeText(b.imageUrl,1000);
  if(image && !/^https:\/\/[^\s]+$/i.test(image)) return res.status(400).json({error:'Image URL must start with https://.'});
  const baseSlug=slugify(name); let slug=baseSlug, n=2;
  while(db.prepare('SELECT id FROM products WHERE slug=?').get(slug)) slug=`${baseSlug}-${n++}`;
  const t=now();
  const result=db.prepare(`INSERT INTO products(name,slug,category,description,image_url,price_paisa,stock,active,created_at,updated_at)
    VALUES(?,?,?,?,?,?,?,1,?,?)`).run(name,slug,category,safeText(b.description,1000),image,Math.round(price*100),stock,t,t);
  res.status(201).json({id:Number(result.lastInsertRowid),name,slug});
});
app.put('/api/admin/products/:id', requireAdmin, (req,res) => {
  const id=Number(req.params.id), b=req.body||{}, old=db.prepare('SELECT * FROM products WHERE id=?').get(id);
  if(!old) return res.status(404).json({error:'Product not found.'});
  const name=safeText(b.name,100), category=safeText(b.category||'General',60), price=Number(b.price), stock=Number(b.stock);
  if(!name || !Number.isFinite(price)||price<=0||price>100000000||!Number.isInteger(stock)||stock<0) return res.status(400).json({error:'Invalid product fields.'});
  const image=safeText(b.imageUrl,1000);
  if(image && !/^https:\/\/[^\s]+$/i.test(image)) return res.status(400).json({error:'Image URL must start with https://.'});
  db.prepare('UPDATE products SET name=?,category=?,description=?,image_url=?,price_paisa=?,stock=?,active=?,updated_at=? WHERE id=?')
    .run(name,category,safeText(b.description,1000),image,Math.round(price*100),stock,b.active===false?0:1,now(),id);
  res.json({ok:true});
});
app.delete('/api/admin/products/:id', requireAdmin, (req,res) => {
  const r=db.prepare('UPDATE products SET active=0,updated_at=? WHERE id=?').run(now(),Number(req.params.id));
  if(!r.changes) return res.status(404).json({error:'Product not found.'});
  res.json({ok:true});
});

function validateCart(items) {
  if(!Array.isArray(items)||!items.length||items.length>50) throw new Error('Cart is empty or too large.');
  const aggregated=new Map();
  for(const it of items){
    const id=Number(it.id), qty=Number(it.quantity);
    if(!Number.isInteger(id)||!Number.isInteger(qty)||qty<1||qty>99) throw new Error('Invalid product quantity.');
    aggregated.set(id,(aggregated.get(id)||0)+qty);
  }
  const rows=[];
  for(const [id,qty] of aggregated){
    const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(id);
    if(!p||qty>p.stock) throw new Error('A product is unavailable or stock is insufficient.');
    rows.push({product:p,quantity:qty,line:p.price_paisa*qty});
  }
  const total=rows.reduce((s,x)=>s+x.line,0);
  if(!Number.isSafeInteger(total)||total<100) throw new Error('Order total is invalid.');
  return {rows,total};
}
const createOrderTx=db.transaction(({customer,rows,total,paymentMethod,transactionId=null})=>{
  const code='FM-'+crypto.randomBytes(5).toString('hex').toUpperCase();
  const t=now();
  const order=db.prepare(`INSERT INTO orders(order_code,customer_name,phone,email,address,city,subtotal_paisa,delivery_paisa,total_paisa,payment_method,payment_status,order_status,transaction_id,created_at,updated_at)
  VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(code,customer.name,customer.phone,customer.email,customer.address,customer.city,total,0,total,paymentMethod,paymentMethod==='cod'?'unpaid':'pending','pending',transactionId,t,t);
  for(const {product,quantity} of rows){
    const changed=db.prepare('UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND stock>=?').run(quantity,t,product.id,quantity);
    if(!changed.changes) throw new Error('Stock changed during checkout. Please try again.');
    db.prepare('INSERT INTO order_items(order_id,product_id,product_name,unit_price_paisa,quantity) VALUES(?,?,?,?,?)')
      .run(order.lastInsertRowid,product.id,product.name,product.price_paisa,quantity);
  }
  return {id:Number(order.lastInsertRowid),code,total:total/100};
});
function cleanCustomer(b){
  const c={name:safeText(b.name,100),phone:safeText(b.phone,30),email:safeText(b.email,254),address:safeText(b.address,500),city:safeText(b.city,80)};
  if(c.name.length<2||!/^[+\d()\-\s]{7,30}$/.test(c.phone)||c.address.length<5) throw new Error('Enter a valid name, phone number and delivery address.');
  if(c.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(c.email)) throw new Error('Email address is invalid.');
  return c;
}
app.post('/api/checkout/cod', checkoutLimiter, (req,res)=>{
  try{
    const customer=cleanCustomer(req.body?.customer), {rows,total}=validateCart(req.body?.items);
    const order=createOrderTx({customer,rows,total,paymentMethod:'cod'});
    res.status(201).json({message:'Order placed. Pay on delivery.',order});
  }catch(e){res.status(400).json({error:e.message||'Could not place order.'});}
});

const gatewayBase=()=>process.env.SSLCOMMERZ_SANDBOX==='false'?'https://securepay.sslcommerz.com':'https://sandbox.sslcommerz.com';
app.post('/api/payment/sslcommerz/init', checkoutLimiter, async (req,res)=>{
  if(!process.env.SSLCOMMERZ_STORE_ID||!process.env.SSLCOMMERZ_STORE_PASSWORD) return res.status(503).json({error:'Online payment is not configured. COD is available.'});
  let created;
  try{
    const customer=cleanCustomer(req.body?.customer), {rows,total}=validateCart(req.body?.items);
    // Create a pending order and reserve inventory transactionally before sending the customer to the gateway.
    const tranId='FM'+Date.now()+crypto.randomBytes(4).toString('hex');
    created=createOrderTx({customer,rows,total,paymentMethod:'sslcommerz',transactionId:tranId});
    const params=new URLSearchParams({
      store_id:process.env.SSLCOMMERZ_STORE_ID,store_passwd:process.env.SSLCOMMERZ_STORE_PASSWORD,
      total_amount:total.toFixed(2),currency:'BDT',tran_id:tranId,
      success_url:`${BASE_URL}/api/payment/return/success`,fail_url:`${BASE_URL}/api/payment/return/fail`,
      cancel_url:`${BASE_URL}/api/payment/return/cancel`,ipn_url:`${BASE_URL}/api/payment/ipn`,
      shipping_method:'Courier',product_name:'Family Mart Shop BD order',product_category:'general',product_profile:'general',
      cus_name:customer.name,cus_email:customer.email||'customer@example.com',cus_add1:customer.address,cus_city:customer.city||'Bangladesh',
      cus_postcode:'0000',cus_country:'Bangladesh',cus_phone:customer.phone,
      ship_name:customer.name,ship_add1:customer.address,ship_city:customer.city||'Bangladesh',ship_postcode:'0000',ship_country:'Bangladesh'
    });
    const resp=await fetch(`${gatewayBase()}/gwprocess/v4/api.php`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params,signal:AbortSignal.timeout(15000)});
    const data=await resp.json();
    if(!resp.ok||data.status!=='SUCCESS'||!data.GatewayPageURL) throw new Error('Gateway could not create a payment session.');
    res.json({paymentUrl:data.GatewayPageURL,orderCode:created.code});
  }catch(e){
    if(created) {
      const order=db.prepare('SELECT id FROM orders WHERE order_code=?').get(created.code);
      if(order) db.prepare("UPDATE orders SET order_status='payment_failed',updated_at=? WHERE id=?").run(now(),order.id);
    }
    res.status(502).json({error:e.message||'Payment provider could not be reached.'});
  }
});

async function validateGatewayTransaction(valId){
  const params=new URLSearchParams({val_id:valId,store_id:process.env.SSLCOMMERZ_STORE_ID,store_passwd:process.env.SSLCOMMERZ_STORE_PASSWORD,v:1,format:'json'});
  const r=await fetch(`${gatewayBase()}/validator/api/validationserverAPI.php?${params}`,{signal:AbortSignal.timeout(15000)});
  if(!r.ok) throw new Error('Gateway validation request failed.');
  return r.json();
}
async function processVerifiedPayment(body){
  const tranId=safeText(body.tran_id,100), valId=safeText(body.val_id,200);
  if(!tranId||!valId) throw new Error('Missing gateway transaction details.');
  const order=db.prepare('SELECT * FROM orders WHERE transaction_id=?').get(tranId);
  if(!order) throw new Error('Order not found.');
  const verified=await validateGatewayTransaction(valId);
  const amount=Math.round(Number(verified.amount)*100);
  if(verified.status!=='VALID'&&verified.status!=='VALIDATED') throw new Error('Payment is not validated.');
  if(verified.tran_id!==order.transaction_id||amount!==order.total_paisa||verified.currency!=='BDT') throw new Error('Payment details do not match the order.');
  const t=now();
  const tx=db.transaction(()=>{
    db.prepare('INSERT OR IGNORE INTO payment_events(order_id,transaction_id,event_type,gateway_status,created_at) VALUES(?,?,?,?,?)')
      .run(order.id,tranId,'validated_success',verified.status,t);
    db.prepare("UPDATE orders SET payment_status='paid',order_status=CASE WHEN order_status='pending' THEN 'confirmed' ELSE order_status END,updated_at=? WHERE id=?")
      .run(t,order.id);
  });
  tx();
  return order.order_code;
}
app.post('/api/payment/ipn', async (req,res)=>{
  try{ await processVerifiedPayment(req.body||{}); res.status(200).send('OK'); }
  catch(e){ console.error('IPN validation:',e.message); res.status(400).send('Not validated'); }
});
app.all('/api/payment/return/:result', async (req,res)=>{
  const result=req.params.result;
  if(result==='success'){
    try { await processVerifiedPayment(req.method==='POST'?req.body:(req.query||{})); return res.redirect('/?payment=checking'); }
    catch(e){ console.warn('Return validation:',e.message); return res.redirect('/?payment=unverified'); }
  }
  if(['fail','cancel'].includes(result)){
    const tranId=safeText((req.method==='POST'?req.body:req.query)?.tran_id,100);
    if(tranId) db.prepare("UPDATE orders SET order_status=?,updated_at=? WHERE transaction_id=? AND payment_status!='paid'")
      .run(result==='fail'?'payment_failed':'payment_cancelled',now(),tranId);
    return res.redirect('/?payment='+result);
  }
  res.status(404).send('Not found');
});

app.get('/api/admin/orders', requireAdmin, (_req,res)=>{
  const orders=db.prepare('SELECT * FROM orders ORDER BY id DESC LIMIT 500').all();
  const items=db.prepare('SELECT * FROM order_items WHERE order_id=?');
  res.json(orders.map(o=>({...o,total:o.total_paisa/100,items:items.all(o.id).map(i=>({...i,price:i.unit_price_paisa/100}))})));
});
app.patch('/api/admin/orders/:id', requireAdmin, (req,res)=>{
  const status=safeText(req.body?.status,30);
  const allowed=['pending','confirmed','processing','shipped','delivered','cancelled','payment_failed','payment_cancelled'];
  if(!allowed.includes(status)) return res.status(400).json({error:'Invalid order status.'});
  const order=db.prepare('SELECT * FROM orders WHERE id=?').get(Number(req.params.id));
  if(!order) return res.status(404).json({error:'Order not found.'});
  if(order.payment_status==='paid'&&status==='cancelled') return res.status(400).json({error:'Paid order cancellation requires a separate refund workflow.'});
  db.prepare('UPDATE orders SET order_status=?,updated_at=? WHERE id=?').run(status,now(),order.id);
  res.json({ok:true});
});

app.get('/health',(_req,res)=>res.json({ok:true,service:'Family Mart Shop BD'}));
app.listen(PORT,()=>console.log(`Family Mart Shop BD running at ${BASE_URL}`));
