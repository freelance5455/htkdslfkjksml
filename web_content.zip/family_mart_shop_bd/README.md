# Family Mart Shop BD — E-commerce Starter

A responsive all-category store starter for Bangladesh using Express + SQLite, with admin login, product management, orders, COD checkout, and an SSLCommerz hosted-payment integration path.

## Requirements
- Node.js 20 or later
- A terminal/command prompt
- For real online payment: SSLCommerz merchant account and a public HTTPS deployment

## 1. Install and configure
```bash
npm install
cp .env.example .env
```
Edit `.env` and set:
- `SESSION_SECRET`: long random secret, at least 32 characters
- `ADMIN_EMAIL`: your admin email
- `ADMIN_PASSWORD`: a strong password of at least 12 characters
- `BASE_URL`: local URL while developing, public HTTPS URL after deployment
- SSLCommerz credentials only when ready to test online payment

## 2. Create the admin account
```bash
npm run db:init
```
This stores a bcrypt-hashed admin password in the SQLite database. Do not use the sample password in production.

## 3. Start
```bash
npm run dev
```
Open http://localhost:3000

## Included
- Responsive storefront and product search/category filters
- SQLite persistence and sample products
- Admin login with bcrypt password hashing and server-side session cookie
- Admin product creation, stock updates through product editor endpoint, hide product action
- Order listing and order status management
- Server-calculated totals and transactional stock decrement
- Cash on Delivery checkout
- SSLCommerz hosted checkout initiation scaffold and server-side transaction validation call on return/IPN

## Security and production checklist
This is a starter project, not a security-audited production service.
- Use HTTPS in production and set `NODE_ENV=production`, `BASE_URL` to the public HTTPS origin, and a strong unique `SESSION_SECRET`.
- Configure a persistent session store (the default Express MemoryStore is not suitable for production).
- Back up the SQLite database, restrict file access, monitor logs, and configure reliable hosting.
- Finish and test all SSLCommerz flows against the current official documentation before accepting real money. Ensure IPN/return validation, transaction ID, amount, currency, and status are checked. Test duplicate callbacks and failed/cancelled payments. Consider idempotent inventory release for abandoned/failed payment orders.
- The sample does not include customer accounts, password reset, email/SMS notifications, refunds, courier API, upload storage, tax rules, or a full inventory reservation expiry workflow.
- Product images use HTTPS image URLs. For real stores, use a managed object storage service and validate uploaded files.
- Consider a managed production database if you expect significant traffic.
- Review applicable Bangladesh business, consumer protection, tax, privacy and payment provider requirements.

Official SSLCommerz docs: https://developer.sslcommerz.com/doc/v4/
