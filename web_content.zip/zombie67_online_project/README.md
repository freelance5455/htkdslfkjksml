# Zombie in Days 67: BETAD — Online Edition

Bu proje 4 oyuncuya kadar aynı odada hareket senkronizasyonu yapan ilk online prototiptir.

## Neler var?
- Oda oluşturma ve 5 karakterli oda koduyla katılma
- Aynı odada en fazla 4 oyuncu
- Oyuncu konumlarının WebSocket üzerinden anlık paylaşılması
- Telefon/tablet tarayıcısına uygun dokunmatik yön tuşları

## Çalıştırma
Node.js 18 veya üzeri gerekir.

```bash
npm install
npm start
```

Sunucu `PORT` ortam değişkenini kullanır; yerelde varsayılan port 3000'dir.
Tarayıcıda `http://localhost:3000` adresini aç.

## İnternete yayınlama
Bu proje WebSocket destekleyen bir Node.js barındırma hizmetine dağıtılmalıdır.
Hizmetin verdiği HTTPS adresini açınca istemci otomatik olarak güvenli WebSocket (WSS) kullanır.
Sadece HTML dosyasını bir statik dosya sitesine yüklemek çok oyunculu sistemi çalıştırmaz.

## Önemli
Bu bir başlangıç prototipidir; henüz hesap sistemi, kalıcı kayıt, oyun içi sohbet,
zombi yapay zekâsı, eşya envanteri veya güvenlik/anti-hile sistemi yoktur.
Oda verileri sunucu belleğinde tutulur; sunucu yeniden başlarsa odalar silinir.
