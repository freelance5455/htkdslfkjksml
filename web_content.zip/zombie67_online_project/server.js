const express = require("express");
const http = require("http");
const { WebSocketServer } = require("ws");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, game: "Zombie in Days 67 Online" }));

const rooms = new Map();
const MAX_PLAYERS = 4;

function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}
function send(ws, data) {
  if (ws.readyState === 1) ws.send(JSON.stringify(data));
}
function roomState(room) {
  return {
    type: "state",
    room: room.code,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, x: p.x, y: p.y, color: p.color
    }))
  };
}
function broadcast(room) {
  const payload = JSON.stringify(roomState(room));
  for (const p of room.players.values()) if (p.ws.readyState === 1) p.ws.send(payload);
}
function removePlayer(ws) {
  const room = rooms.get(ws.roomCode);
  if (!room) return;
  room.players.delete(ws.playerId);
  if (room.players.size === 0) rooms.delete(room.code);
  else broadcast(room);
}

wss.on("connection", ws => {
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws, {type:"error", message:"Geçersiz mesaj."}); }

    if (msg.type === "create" || msg.type === "join") {
      if (ws.roomCode) removePlayer(ws);
      let room;
      if (msg.type === "create") {
        let code;
        do { code = makeCode(); } while (rooms.has(code));
        room = { code, players: new Map() };
        rooms.set(code, room);
      } else {
        const code = String(msg.code || "").trim().toUpperCase();
        room = rooms.get(code);
        if (!room) return send(ws, {type:"error", message:"Bu oda bulunamadı."});
      }
      if (room.players.size >= MAX_PLAYERS) return send(ws, {type:"error", message:"Oda dolu. En fazla 4 oyuncu."});
      const id = crypto.randomUUID();
      const names = ["Hayatta Kalan", "Gezgin", "Gözcü", "Tamirci"];
      const colors = ["#f4d06f", "#80c7ff", "#f18c8c", "#b99cff"];
      const player = {
        id, ws, name: String(msg.name || "Oyuncu").slice(0, 16),
        x: 320 + Math.random() * 50 - 25, y: 210 + Math.random() * 50 - 25,
        color: colors[room.players.size] || "#ffffff"
      };
      room.players.set(id, player);
      ws.roomCode = room.code;
      ws.playerId = id;
      send(ws, {type:"joined", room:room.code, playerId:id, maxPlayers:MAX_PLAYERS});
      broadcast(room);
      return;
    }

    if (msg.type === "move" && ws.roomCode) {
      const room = rooms.get(ws.roomCode);
      const player = room && room.players.get(ws.playerId);
      if (!player) return;
      const x = Number(msg.x), y = Number(msg.y);
      if (Number.isFinite(x) && Number.isFinite(y)) {
        player.x = Math.max(18, Math.min(622, x));
        player.y = Math.max(18, Math.min(402, y));
        broadcast(room);
      }
    }
  });
  ws.on("close", () => removePlayer(ws));
  ws.on("error", () => removePlayer(ws));
});

const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Zombie in Days 67 Online listening on ${port}`));
