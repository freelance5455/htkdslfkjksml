# Haider IQ Android project

This Android Studio project wraps the supplied `Haider IQ` HTML game in a native Android WebView. The original game HTML is bundled locally, so the game does not need an internet connection.

## Build the APK
1. Install Android Studio (with Android SDK Platform 35 and Build Tools).
2. Open this `HaiderIQ-Android` folder in Android Studio.
3. Wait for Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

Application ID: `com.haideriq.game`  
App name: `Haider IQ`  
Minimum Android version: Android 6.0 (API 23)
