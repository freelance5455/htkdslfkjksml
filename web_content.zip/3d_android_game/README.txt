3D CHARACTER — ANDROID BROWSER PROTOTYPE

Files:
- index.html: the playable prototype.

How to run:
1. Extract the ZIP file.
2. Open index.html in a modern browser with internet access. On Android, a local HTML file may block ES modules; if it does, upload the folder to a static host or run it from a local web server.
3. The 3D model and Three.js libraries are loaded from the internet, so an internet connection is required.

Controls:
- Arrow buttons: move/turn the character.
- Idle / Walk / Run: select an animation when available.
- Turn 180°: turn the character around.

Note: This is a starter prototype and uses a sample animated Soldier.glb model from the Three.js examples. It is not a finished game and does not include custom realistic female character models. Replace the model URL and animation setup with properly licensed adult character assets for that purpose.
