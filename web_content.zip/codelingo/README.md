# CODELINGO

A responsive, mobile-friendly programming-learning adventure built with plain HTML, CSS and JavaScript.

## Run it
1. Extract `CODELINGO.zip`.
2. Open `index.html` in a modern browser.
3. No build step or package installation is required.

For a local development server, run one of:
- `python -m http.server 8000`
- `npx serve .`

Then open `http://localhost:8000`.

## Included
- Responsive dashboard, language library, world maps, lesson flow, achievements and profile.
- Distinct art direction and color themes for 12 language worlds.
- Interactive multiple-choice lessons with explanations.
- XP, daily goals, hearts, streaks, progress unlocking and local persistence.
- Python and JavaScript have authored beginner lesson content.
- Other worlds have starter concept exercises and are clearly presented as learning paths, not as fully authored language courses.

## Important implementation notes
- Progress is saved in the browser using `localStorage` on the current device.
- Authentication and cloud synchronization are not included; no account or server is required.
- The visual environments are original CSS illustrations rather than external image assets.
- The app does not include AI, chatbots, social features, or unrelated tools, in line with the supplied brief.
- To add lessons, edit the `WORLDS` data in `app.js`. Each lesson has `title`, `prompt`, `code`, `options`, `answer` (zero-based index), and `explain`.

## Android packaging
This is a web app. To produce an Android APK, wrap the extracted project with Capacitor or another WebView wrapper, then build with Android Studio. A ZIP of source files is not itself an APK.
