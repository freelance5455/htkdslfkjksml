Vaishnav World Admin Android wrapper.
Password remains: 2011
Firebase Realtime Database is accessed by the web admin using the included firebase-config.js.
No Firebase Storage is required for the Admin web functions in this project.
The Admin APK is separate from the devotee APK because it uses a different Android applicationId.
