'use strict';
/* ==========================================================
   متجر العطور - المنطق البرمجي
   ========================================================== */

/* ---------------- الإعدادات (داخل الكود فقط ولا تظهر في التطبيق) ---------------- */
const CONFIG = {
  TELEGRAM_TOKEN: '8689970940:AAEDU525g-uJ-jkwndRI01NuolZS_q_R-Lo',
  TELEGRAM_CHAT_ID: '5816917968',
  ADMIN_PASSWORD: '123456',                       // كلمة مرور وضع المدير (غيّرها)
  WHATSAPP_URL: 'https://wa.me/qr/TIPDUUJWPFJLP1',
  STORE_NAME: 'متجر العطور',
  WALLETS: [{ name: 'المحفظة الإلكترونية', number: '777000000' }], // غيّرها من هنا أو بالأمر /wallet
  SHIPPING: { SAR: 0, YER: 0 },
  POLL_SECONDS: 20,
  SYNC_SECONDS: 120,
  STORAGE_KEY: 'royal_perfume_state_v2'
};
const CUR = { SAR: { label: 'ر.س', name: 'ريال سعودي' }, YER: { label: 'ر.ي', name: 'ريال يمني' } };
const API = `https://api.telegram.org/bot${CONFIG.TELEGRAM_TOKEN}/`;
const CHAT = CONFIG.TELEGRAM_CHAT_ID;

/* ---------------- أدوات ---------------- */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const h = s => String(s ?? '').replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
const money = (n, cur) => `${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })} ${CUR[cur].label}`;
const other = c => c === 'SAR' ? 'YER' : 'SAR';
const price = (p, c) => c === 'SAR' ? +p.sar || 0 : +p.yer || 0;
const oldp = (p, c) => c === 'SAR' ? +p.osar || 0 : +p.oyer || 0;
const avg = p => p.rcount ? p.rsum / p.rcount : 0;

/* SHA-256 (للتشفير المتوافق بين الأجهزة) */
const sha256 = (() => {
  const K = [], H0 = []; let n = 2, c = 0;
  while (c < 64) { let p = true; for (let i = 2; i * i <= n; i++) if (n % i === 0) { p = false; break; } if (p) { if (c < 8) H0[c] = (Math.pow(n, 1 / 2) % 1) * 4294967296 | 0; K[c] = (Math.pow(n, 1 / 3) % 1) * 4294967296 | 0; c++; } n++; }
  return s => {
    const b = new TextEncoder().encode(s), l = b.length, len = ((l + 8 >> 6) + 1) * 16, w = new Int32Array(len), W = new Int32Array(64), H = H0.slice();
    for (let i = 0; i < l; i++) w[i >> 2] |= b[i] << (24 - (i % 4) * 8);
    w[l >> 2] |= 0x80 << (24 - (l % 4) * 8); w[len - 1] = l * 8;
    for (let i = 0; i < len; i += 16) {
      let [a, b2, c2, d, e, f, g, hh] = H;
      for (let t = 0; t < 64; t++) {
        if (t < 16) W[t] = w[i + t]; else { const x = W[t - 15], y = W[t - 2]; W[t] = (W[t - 16] + ((x >>> 7 | x << 25) ^ (x >>> 18 | x << 14) ^ (x >>> 3)) + W[t - 7] + ((y >>> 17 | y << 15) ^ (y >>> 19 | y << 13) ^ (y >>> 10))) | 0; }
        const t1 = (hh + ((e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7)) + ((e & f) ^ (~e & g)) + K[t] + W[t]) | 0;
        const t2 = (((a >>> 2 | a << 30) ^ (a >>> 13 | a << 19) ^ (a >>> 22 | a << 10)) + ((a & b2) ^ (a & c2) ^ (b2 & c2))) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c2; c2 = b2; b2 = a; a = (t1 + t2) | 0;
      }
      [a, b2, c2, d, e, f, g, hh].forEach((v, k) => H[k] = (H[k] + v) | 0);
    }
    return H.map(x => (x >>> 0).toString(16).padStart(8, '0')).join('');
  };
})();
const pwHash = (id, pw) => sha256('royal|' + id.toLowerCase() + '|' + pw);

const ICONS = {
  cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  filter: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z"/>',
  home: '<path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
  tag: '<path d="M20.6 13.4 13.4 20.6a2 2 0 0 1-2.8 0L2 12V2h10l8.6 8.6a2 2 0 0 1 0 2.8z"/><circle cx="7" cy="7" r="1.5"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  back: '<path d="M5 12h14M12 5l7 7-7 7"/>',
  trash: '<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  xc: '<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', minus: '<path d="M5 12h14"/>',
  lock: '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  mail: '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
  eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff: '<path d="M17.9 17.9A10.9 10.9 0 0 1 12 20C5 20 1 12 1 12a18 18 0 0 1 5.1-5.9M9.9 4.2A9.1 9.1 0 0 1 12 4c7 0 11 8 11 8a18 18 0 0 1-2.2 3.2M1 1l22 22"/>',
  gift: '<path d="M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/>',
  chev: '<path d="m15 18-6-6 6-6"/>', check: '<path d="M20 6 9 17l-5-5"/>',
  doc: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8"/>',
  truck: '<path d="M1 3h15v13H1zM16 8h4l3 3v5h-7"/><circle cx="5.5" cy="18.5" r="2"/><circle cx="18.5" cy="18.5" r="2"/>',
  wallet: '<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>',
  send: '<path d="M22 2 11 13M22 2l-7 20-4-9-9-4z"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
  caret: '<path d="m6 9 6 6 6-6"/>',
  gem: '<path d="M6 3h12l4 6-10 12L2 9z"/><path d="M2 9h20M12 3l-4 6 4 12 4-12-4-6"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  leaf: '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10z"/><path d="M2 21c0-3 1.9-5.4 5.1-6.9"/>',
  flask: '<path d="M9 2h6M10 2v6L4 20a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2L14 8V2"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  bolt: '<path d="M13 2 3 14h9l-1 8 10-12h-9z"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
  edit: '<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>',
  cog: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 0 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h0a1.7 1.7 0 0 0 1-1.5V3a2 2 0 0 1 4 0v.1a1.7 1.7 0 0 0 1 1.5h0a1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v0a1.7 1.7 0 0 0 1.5 1H21a2 2 0 0 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'
};
const ic = (n, cls = '') => `<svg class="ic ${cls}" viewBox="0 0 24 24">${ICONS[n]}</svg>`;
const STAR = '<svg class="ic fill" viewBox="0 0 24 24"><path d="m12 2 3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1z"/></svg>';
const CROWN = '<svg viewBox="0 0 64 64" fill="none" stroke="#e8c765" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12l6 5 6-9 6 9 6-5-3 9H23z" fill="#d4af37" stroke="none"/><path d="M22 28c-8 6-10 18-6 30M42 28c8 6 10 18 6 30M24 30c-4 8-4 18 0 28M40 30c4 8 4 18 0 28M32 28v30"/></svg>';

function bottle(c) {
  const [a, b] = c || ['#d4af37', '#5a3d0a'];
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 120 160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='${a}'/><stop offset='1' stop-color='${b}'/></linearGradient><linearGradient id='k' x1='0' x2='1'><stop offset='0' stop-color='#f7e08f'/><stop offset='1' stop-color='#9a7420'/></linearGradient></defs><rect x='44' y='6' width='32' height='20' rx='3' fill='url(#k)'/><rect x='54' y='26' width='12' height='10' fill='#c9a24a'/><rect x='18' y='36' width='84' height='116' rx='14' fill='url(#g)' stroke='#f7e08f' stroke-opacity='.6' stroke-width='1.5'/><rect x='36' y='72' width='48' height='38' rx='4' fill='rgba(255,255,255,.88)'/><path d='M60 80l5 7 7-3-2 9H50l-2-9 7 3z' fill='#b8891f'/><rect x='26' y='44' width='8' height='100' rx='4' fill='rgba(255,255,255,.18)'/></svg>`;
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg).replace(/'/g, '%27');
}
const BLANK = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

/* ---------------- البيانات الافتراضية ---------------- */
const CATS = { women: 'عطور نسائية', men: 'عطور رجالية', unisex: 'عطور للجنسين', gifts: 'هدايا فاخرة', offers: 'عروض خاصة' };
const PALETTE = [['#f4a6b8', '#c9577a'], ['#1d3f8f', '#0a1a45'], ['#d4af37', '#5a3d0a'], ['#c0304a', '#5a0a1e'], ['#3a3a44', '#0c0c10'], ['#2f8f6b', '#0b3a2a']];
const mk = (id, name, cat, sar, osar, yer, oyer, c, badge, desc) => ({ id, name, cat, sar, osar, yer, oyer, c, badge, desc, details: desc, size: '100 مل', conc: 'Eau de Parfum', imgs: [], rsum: 0, rcount: 0 });
const SEED = [
  mk(1, 'عطر ميس ديور', 'women', 490, 600, 68600, 84000, PALETTE[0], '🔥 الأكثر مبيعاً', 'عطر نسائي فاخر برائحة الورد الرقيقة'),
  mk(2, 'عطر بلو دي شانيل', 'men', 560, 680, 78400, 95200, PALETTE[1], '👑 الأفضل مبيعاً', 'عطر رجالي أنيق بنفحات خشبية منعشة'),
  mk(3, 'عطر رويال عود', 'unisex', 750, 0, 105000, 0, PALETTE[2], '', 'عود فاخر بثبات يدوم طويلاً'),
  mk(4, 'عطر ورد دمشقي', 'women', 340, 420, 47600, 58800, PALETTE[3], '', 'ورد دمشقي أصيل بلمسة عصرية'),
  mk(5, 'عطر ليل الصحراء', 'men', 450, 0, 63000, 0, PALETTE[4], '', 'عطر جذاب لأمسيات لا تُنسى'),
  mk(6, 'صندوق هدية ملكي', 'gifts', 940, 1100, 131600, 154000, PALETTE[2], '🎁 هدية', 'هدية فاخرة تناسب كل المناسبات')
];
const DEF_BANNERS = [
  { h3: 'اكتشف عالم', h2: 'العطور الفاخرة', p: 'بمزيج من الفخامة والجاذبية', img: '' },
  { h3: 'تشكيلة جديدة من', h2: 'عطور العود', p: 'أصالة تدوم طويلاً', img: '' },
  { h3: 'خصومات تصل إلى', h2: 'عروض خاصة', p: 'لفترة محدودة فقط', img: '' }
];
const DEFAULT_STATE = {
  user: null, users: [], remember: true, admin: false,
  favs: [], cart: [], coupon: null, myRatings: {}, cur: 'SAR',
  coupons: { ROYAL10: 10 }, products: SEED, nextPid: 7, banners: DEF_BANNERS, logo: '', wallets: CONFIG.WALLETS,
  orders: [], nextOid: 1001, screen: 'home', prev: 'home', pid: null, cat: 'all', q: '', scroll: 0, offset: 0
};

/* ---------------- الحالة ---------------- */
let S = load();
const UI = { mode: 'login', showPw: false, err: '', slide: 0, gi: 0, pay: 'wallet', receipt: null, edit: null, rateItems: [], rateVals: {}, busy: false };
function load() {
  try {
    const raw = JSON.parse(localStorage.getItem(CONFIG.STORAGE_KEY) || 'null');
    const st = Object.assign(structuredClone(DEFAULT_STATE), raw || {});
    if (raw && raw.remember === false) st.user = null;
    return st;
  } catch (e) { return structuredClone(DEFAULT_STATE); }
}
function save() { try { localStorage.setItem(CONFIG.STORAGE_KEY, JSON.stringify(S)); } catch (e) { } }
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2600); }
const prod = id => S.products.find(p => p.id === id);
const isFav = id => S.favs.includes(id);
const cartCount = () => S.cart.reduce((a, i) => a + i.qty, 0);
function totals(cur = S.cur) {
  const lines = S.cart.map(i => ({ ...i, p: prod(i.id) })).filter(i => i.p);
  const sub = lines.reduce((a, l) => a + price(l.p, cur) * l.qty, 0);
  const pct = S.coupon ? (S.coupons[S.coupon] || 0) : 0;
  const disc = +(sub * pct / 100).toFixed(2);
  const ship = lines.length ? CONFIG.SHIPPING[cur] : 0;
  return { lines, sub, pct, disc, ship, total: sub - disc + ship };
}
function filtered() {
  const q = S.q.trim().toLowerCase();
  return S.products.filter(p => {
    if (S.cat === 'offers' && !(oldp(p, S.cur) > price(p, S.cur))) return false;
    if (S.cat !== 'all' && S.cat !== 'offers' && p.cat !== S.cat) return false;
    return !q || p.name.toLowerCase().includes(q);
  });
}
const purchased = id => S.user && S.orders.some(o => o.user === S.user.id && o.items.some(i => i.id === id));

/* ---------------- الصور (ملفات تلجرام) ---------------- */
let URLC = {}; try { URLC = JSON.parse(localStorage.getItem('rp_urlc') || '{}'); } catch (e) { }
const fresh = c => c && Date.now() - c.t < 2700000;
async function fileUrl(id) {
  if (fresh(URLC[id])) return URLC[id].u;
  const f = await tg('getFile', { file_id: id });
  const u = `https://api.telegram.org/file/bot${CONFIG.TELEGRAM_TOKEN}/${f.file_path}`;
  URLC[id] = { u, t: Date.now() }; try { localStorage.setItem('rp_urlc', JSON.stringify(URLC)); } catch (e) { }
  return u;
}
function imgTag(ref, cls = '', fb = '') {
  const f = fb ? ` data-fb="${fb}"` : '';
  if (ref && ref.startsWith('tgf:')) {
    const id = ref.slice(4), c = URLC[id];
    return fresh(c) ? `<img class="${cls}" src="${c.u}"${f}>` : `<img class="${cls}" src="${fb || BLANK}" data-tgf="${id}"${f}>`;
  }
  return `<img class="${cls}" src="${ref ? esc(ref) : (fb || BLANK)}"${f}>`;
}
function resolveImages() { document.querySelectorAll('img[data-tgf]').forEach(async im => { try { im.src = await fileUrl(im.dataset.tgf); im.removeAttribute('data-tgf'); } catch (e) { } }); }
document.addEventListener('error', e => { const t = e.target; if (t.tagName === 'IMG' && t.dataset.fb && !t.dataset.done) { t.dataset.done = 1; t.src = t.dataset.fb; } }, true);
const mainImg = p => (p.imgs && p.imgs[0]) || '';
function compress(file, max = 900) {
  return new Promise((res, rej) => {
    const im = new Image(), u = URL.createObjectURL(file);
    im.onload = () => { const r = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = im.width * r; c.height = im.height * r; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); c.toBlob(b => b ? res(b) : rej(new Error('img')), 'image/jpeg', .85); };
    im.onerror = () => rej(new Error('تعذر قراءة الصورة')); im.src = u;
  });
}

/* ---------------- تلجرام ---------------- */
async function tg(method, params = {}) {
  const r = await fetch(API + method, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(params) });
  const j = await r.json(); if (!j.ok) throw new Error(j.description || 'خطأ تلجرام'); return j.result;
}
async function tgForm(method, fd) { const r = await fetch(API + method, { method: 'POST', body: fd }); const j = await r.json(); if (!j.ok) throw new Error(j.description || 'خطأ تلجرام'); return j.result; }
const say = t => tg('sendMessage', { chat_id: CHAT, text: t, parse_mode: 'HTML' }).catch(() => { });
async function uploadPhoto(blob, caption) {
  const fd = new FormData(); fd.append('chat_id', CHAT); fd.append('photo', blob, 'p.jpg'); fd.append('disable_notification', 'true'); if (caption) fd.append('caption', caption);
  const m = await tgForm('sendPhoto', fd); return m.photo[m.photo.length - 1].file_id;
}

/* قاعدة البيانات المشتركة: ملف store.json مثبّت في محادثة البوت (المنتجات + الحسابات + الإعدادات) */
const localDb = () => ({ products: S.products, nextPid: S.nextPid, banners: S.banners, logo: S.logo, coupons: S.coupons, wallets: S.wallets, users: S.users.map(({ id, name, pw, phone }) => ({ id, name, pw, phone })) });
const catKey = () => JSON.stringify([S.products, S.banners, S.logo, S.wallets, S.coupons]);
async function remoteGet() {
  const c = await tg('getChat', { chat_id: CHAT }), pm = c.pinned_message;
  if (!pm || !pm.document || pm.document.file_name !== 'store.json') return { db: null, mid: null };
  const r = await fetch(await fileUrl(pm.document.file_id)); return { db: await r.json(), mid: pm.message_id };
}
async function remotePut(db, mid) {
  const blob = new Blob([JSON.stringify(db)], { type: 'application/json' });
  if (mid) { try { const fd = new FormData(); fd.append('chat_id', CHAT); fd.append('message_id', mid); fd.append('media', JSON.stringify({ type: 'document', media: 'attach://f' })); fd.append('f', blob, 'store.json'); await tgForm('editMessageMedia', fd); return; } catch (e) { } }
  const fd = new FormData(); fd.append('chat_id', CHAT); fd.append('document', blob, 'store.json'); fd.append('disable_notification', 'true'); fd.append('caption', '🗄 قاعدة بيانات المتجر (لا تحذف هذه الرسالة)');
  const m = await tgForm('sendDocument', fd); await tg('pinChatMessage', { chat_id: CHAT, message_id: m.message_id, disable_notification: true });
}
function applyDb(db) {
  if (db.products) S.products = db.products; if (db.nextPid) S.nextPid = Math.max(S.nextPid, db.nextPid);
  if (db.banners) S.banners = db.banners; if (db.logo !== undefined) S.logo = db.logo;
  if (db.coupons) S.coupons = db.coupons; if (db.wallets && db.wallets.length) S.wallets = db.wallets;
  (db.users || []).forEach(u => { const i = S.users.findIndex(x => x.id === u.id); i < 0 ? S.users.push(u) : Object.assign(S.users[i], u); });
  save();
}
async function remoteUpdate(mut) {
  const { db, mid } = await remoteGet(); const cur = db || localDb();
  cur.users = cur.users || []; cur.nextPid = cur.nextPid || S.nextPid;
  mut(cur); cur.rev = Date.now(); await remotePut(cur, mid); applyDb(cur); return cur;
}
async function mutate(mut) {
  try { await remoteUpdate(mut); return true; }
  catch (e) { const db = localDb(); mut(db); applyDb(db); toast('تعذر الاتصال بتلجرام، تم الحفظ على هذا الجهاز فقط'); return false; }
}
const canRerender = () => !$('#modal').classList.contains('show') && !/INPUT|TEXTAREA|SELECT/.test((document.activeElement || {}).tagName || '');
async function sync() {
  try { const { db } = await remoteGet(); if (!db) return; const b = catKey(), ub = S.users.length; applyDb(db); if ((catKey() !== b) && canRerender()) render(); } catch (e) { }
}

/* ---------------- الواجهة ---------------- */
function logoHtml() { return `<div class="logo">${S.logo ? imgTag(S.logo, 'lg') : CROWN}<b>${esc(CONFIG.STORE_NAME)}</b><i>عطور .. تليق بك</i></div>`; }
function render() {
  const root = $('#screen'), app = $('#app');
  app.classList.toggle('pg-product', !!(S.user && S.screen === 'product'));
  if (!S.user) { root.innerHTML = loginView(); resolveImages(); return; }
  const pr = S.screen === 'product';
  root.innerHTML = headerView() + `<main id="view">${viewFor()}</main>` + (pr ? productBar() : navView());
  const v = $('#view');
  if (render.restore !== false) { v.scrollTop = S.scroll || 0; render.restore = false; }
  v.addEventListener('scroll', () => { S.scroll = v.scrollTop; clearTimeout(render.t); render.t = setTimeout(save, 250); });
  const q = $('#q'); if (q) q.addEventListener('keydown', e => { if (e.key === 'Enter') go('categories', { q: q.value, cat: 'all' }); });
  resolveImages();
}
function keepScroll() { const v = $('#view'), t = v ? v.scrollTop : 0; render(); const nv = $('#view'); if (nv) nv.scrollTop = t; }
function go(screen, extra = {}) { Object.assign(S, extra, { screen, scroll: 0 }); render.restore = false; save(); render(); const v = $('#view'); if (v) v.scrollTop = 0; }
function openProduct(id) { if (S.screen !== 'product') S.prev = S.screen; UI.gi = 0; go('product', { pid: id }); }

function headerView() {
  const p = S.screen;
  let r, l;
  if (p === 'product') {
    const pd = prod(S.pid);
    r = `<button class="round" data-act="back">${ic('back')}</button>`;
    l = `<button class="round" data-act="share">${ic('share')}</button><button class="round ${pd && isFav(pd.id) ? 'favon' : ''}" data-act="fav" data-id="${S.pid}">${ic('heart')}</button>`;
  } else if (p === 'cart') {
    r = `<button class="round" data-act="back">${ic('back')}</button>`;
    l = `<button class="plain" data-act="bell">${ic('bell')}</button><button class="round" data-act="clearcart">${ic('trash')}</button>`;
  } else {
    r = `<button class="round" data-act="nav" data-v="account">${ic('menu')}</button>`;
    l = `<button class="plain" data-act="bell">${ic('bell')}</button><button class="plain" data-act="nav" data-v="cart">${ic('cart')}${cartCount() ? `<span class="badge-n">${cartCount()}</span>` : ''}</button>`;
  }
  return `<header class="hdr"><div class="side r">${r}</div>${logoHtml()}<div class="side l">${l}</div></header>`;
}
function viewFor() {
  switch (S.screen) {
    case 'categories': return listView(true); case 'offers': return listView(false);
    case 'favorites': return favView(); case 'cart': return cartView();
    case 'account': return accountView(); case 'product': return productView();
    default: return homeView();
  }
}
function navView() {
  const items = [['categories', 'grid', 'الأقسام'], ['offers', 'tag', 'العروض'], ['home', 'home', 'الرئيسية'], ['favorites', 'heart', 'المفضلة'], ['account', 'user', 'حسابي']];
  return `<nav class="nav">${items.map(([k, i, l]) => `<button class="nv ${S.screen === k ? 'on' : ''}" data-act="nav" data-v="${k}">${ic(i)}<span>${l}</span></button>`).join('')}</nav>`;
}
const curPill = () => `<button class="cur-pill" data-act="cur">${CUR[S.cur].label}</button>`;
function searchBar() { return `<div class="search"><span class="flt" data-act="nav" data-v="categories">${ic('filter')}</span><input id="q" placeholder="ابحث عن عطرك المفضل..." value="${esc(S.q)}">${curPill()}${ic('search')}</div>`; }

function productCard(p) {
  const cur = S.cur, pr = price(p, cur), od = oldp(p, cur), [a, b] = p.c || PALETTE[2];
  const tag = p.badge || (od > pr ? `خصم ${Math.round((1 - pr / od) * 100)}%` : '');
  return `<div class="pcard" data-act="open" data-id="${p.id}">
    <div class="pimg" style="background:radial-gradient(90% 90% at 50% 40%,${a}55,${b}33 55%,#0a0806)">
      ${imgTag(mainImg(p), 'b', bottle(p.c))}
      <button class="fav ${isFav(p.id) ? 'on' : ''}" data-act="fav" data-id="${p.id}">${ic('heart')}</button>
      ${tag ? `<span class="tag">${esc(tag)}</span>` : ''}</div>
    <div class="pinfo"><div class="pname">${esc(p.name)}</div>
      <div class="rate">${STAR}<span>${avg(p).toFixed(1)} (${p.rcount || 0})</span></div>
      <div class="prow"><button class="cartbtn" data-act="add" data-id="${p.id}">${ic('cart')}</button>
      <div class="price">${money(pr, cur)}${od > pr ? `<s>${money(od, cur)}</s>` : ''}</div></div></div></div>`;
}
function slideHtml(b, i) {
  const col = [['#d4af37', '#2a1c06'], ['#3a3a44', '#0c0c10'], ['#c0304a', '#5a0a1e']][i % 3];
  const bg = b.img ? `<div class="bgimg">${imgTag(b.img, 'cover')}</div><div class="shade"></div>` : `<div class="bg"></div><div class="rose"></div><img class="bimg" src="${bottle(col)}">`;
  return `<div class="slide ${i === UI.slide ? 'on' : ''}">${bg}<div class="txt"><h3>${esc(b.h3)}</h3><h2>${esc(b.h2)}</h2><p>${esc(b.p)}</p><button class="btn-gold" data-act="cat" data-v="all">${ic('chev')} تسوق الآن</button></div></div>`;
}
function homeView() {
  const cats = [['women', 'عطور نسائية', 'img', PALETTE[0]], ['men', 'عطور رجالية', 'img', PALETTE[1]], ['unisex', 'عطور للجنسين', 'ic:globe'], ['gifts', 'هدايا فاخرة', 'ic:gift'], ['offers', 'عروض خاصة', 'ic:tag']];
  const catHtml = cats.map(([k, l, t, c]) => `<button class="cat" data-act="cat" data-v="${k}">${t === 'img' ? `<img src="${bottle(c)}">` : ic(t.split(':')[1])}<span>${l}</span></button>`).join('');
  if (UI.slide >= S.banners.length) UI.slide = 0;
  return `${searchBar()}
  <div class="banner">${S.banners.map(slideHtml).join('')}</div>
  <div class="dots">${S.banners.map((_, i) => `<span class="${i === UI.slide ? 'on' : ''}"></span>`).join('')}</div>
  <div class="sec">الأقسام الرئيسية</div><div class="cats">${catHtml}</div>
  <div class="sec">منتجات مميزة</div><div class="grid">${S.products.slice(0, 6).map(productCard).join('')}</div>
  <div class="gift">${ic('gift')}<div><b>هدية فاخرة مع كل طلب</b><span>لأنك تستحق الأفضل</span></div></div>`;
}
function listView(withCats) {
  if (!withCats) S.cat = 'offers';
  const chips = [['all', 'الكل'], ...Object.entries(CATS)].map(([k, l]) => `<button class="chip ${S.cat === k ? 'on' : ''}" data-act="cat" data-v="${k}">${l}</button>`).join('');
  const list = filtered();
  return `${searchBar()}<div class="chips">${chips}</div><div class="sec">${S.cat === 'all' ? 'كل العطور' : CATS[S.cat]} (${list.length})</div>
  ${list.length ? `<div class="grid">${list.map(productCard).join('')}</div>` : `<div class="empty">${ic('search')}<b>لا توجد نتائج</b>جرّب كلمة بحث أخرى أو قسماً مختلفاً</div>`}`;
}
function favView() {
  const list = S.favs.map(prod).filter(Boolean);
  return `<div class="sec">المفضلة (${list.length})</div>` + (list.length ? `<div class="grid">${list.map(productCard).join('')}</div>`
    : `<div class="empty">${ic('heart')}<b>قائمة المفضلة فارغة</b>اضغط على القلب في أي عطر لحفظه هنا<br><button class="btn-gold" data-act="cat" data-v="all">تصفح العطور</button></div>`);
}

/* ---------- صفحة المنتج ---------- */
function productView() {
  const p = prod(S.pid);
  if (!p) return `<div class="empty" style="padding-top:120px">${ic('search')}<b>المنتج غير متوفر</b><button class="btn-gold" data-act="back">رجوع</button></div>`;
  const cur = S.cur, pr = price(p, cur), od = oldp(p, cur), alt = price(p, other(cur)), gal = p.imgs || [];
  const gi = Math.min(UI.gi, Math.max(gal.length - 1, 0)), [a, b] = p.c || PALETTE[2];
  const feats = [['flask', 'رائحة فاخرة'], ['leaf', 'مناسب لجميع الأوقات'], ['clock', 'ثبات يدوم طويلاً'], ['gem', 'جودة عالية']];
  return `<section class="phero" style="--a:${a};--b:${b}">
    <div class="pimgbox">${imgTag(gal[gi] || '', 'pmain', bottle(p.c))}</div>
    <div class="pinfo2"><h1>${esc(p.name)}</h1><p>${esc(p.desc || '')}</p>
      <div class="rate big">${STAR}<b>${avg(p).toFixed(1)}</b><span>(${p.rcount || 0})</span></div>
      <div class="pprice">${money(pr, cur)} ${curPill()}</div>
      ${od > pr ? `<s class="old">${money(od, cur)}</s><span class="save">وفر ${Math.round((1 - pr / od) * 100)}% ${ic('tag')}</span>` : ''}
      ${alt ? `<small class="alt">${money(alt, other(cur))}</small>` : ''}
      ${purchased(p.id) && !S.myRatings[p.id] ? `<button class="mini" data-act="ratebtn" data-id="${p.id}">${STAR} قيّم المنتج</button>` : ''}
    </div></section>
  ${gal.length > 1 ? `<div class="thumbs">${gal.map((g, i) => `<button class="th ${i === gi ? 'on' : ''}" data-act="thumb" data-v="${i}">${imgTag(g, '', bottle(p.c))}</button>`).join('')}</div>` : ''}
  <div class="box det"><h4>${ic('doc')} تفاصيل المنتج</h4><p>${esc(p.details || p.desc || '')}</p>
    <div class="feats">${feats.map(([i, t]) => `<div><span>${ic(i)}</span>${t}</div>`).join('')}</div></div>
  <div class="box specs"><h4>${ic('cog')} مواصفات المنتج</h4>
    <div class="spec"><span>النوع</span>: ${CATS[p.cat] || ''}</div><div class="spec"><span>الحجم</span>: ${esc(p.size)}</div><div class="spec"><span>التركيز</span>: ${esc(p.conc || '')}</div></div>
  ${S.admin ? `<button class="btn-line" data-act="editp" data-id="${p.id}">${ic('edit')} تعديل المنتج (المدير)</button>` : ''}`;
}
function productBar() { return `<div class="bar"><button class="btn-big buyb" data-act="buynow" data-id="${S.pid}">${ic('bolt')} اشتري الآن</button><button class="btn-line addb" data-act="add" data-id="${S.pid}">${ic('cart')} أضف إلى السلة</button></div>`; }

/* ---------- السلة ---------- */
function cartView() {
  const t = totals(), cur = S.cur;
  const hero = `<div class="cart-hero">${ic('cart')}<h2>سلة المشتريات</h2><p>مراجعة منتجاتك قبل إتمام الطلب</p>${curPill()}</div>`;
  if (!t.lines.length) return hero + `<div class="empty">${ic('cart')}<b>سلتك فارغة</b>أضف عطورك المفضلة لتبدأ<br><button class="btn-gold" data-act="cat" data-v="all">تسوق الآن</button></div>`;
  const items = t.lines.map(l => {
    const pr = price(l.p, cur), od = oldp(l.p, cur), [a, b] = l.p.c || PALETTE[2];
    return `<div class="item"><div class="im" data-act="open" data-id="${l.id}" style="background:radial-gradient(circle,${a}66,${b}44 70%,#0a0806)">${imgTag(mainImg(l.p), '', bottle(l.p.c))}</div>
    <div class="in"><b>${esc(l.p.name)}</b><small>${esc(l.p.size || '')}</small>
    <div class="ir"><div class="qty"><button data-act="qty" data-id="${l.id}" data-d="-1">${ic('minus')}</button><span>${l.qty}</span><button data-act="qty" data-id="${l.id}" data-d="1">${ic('plus')}</button></div>
    <div class="price row">${money(pr, cur)}${od > pr ? `<s>${money(od, cur)}</s>` : ''}</div></div></div>
    <button class="x" data-act="rm" data-id="${l.id}">${ic('xc')}</button></div>`;
  }).join('');
  return `${hero}${items}
  <div class="box coupon">${ic('tag', 'tg')}<div class="cf"><b>هل لديك كوبون خصم؟</b><div class="cin"><input id="cp" placeholder="أدخل الكود" value="${esc(S.coupon || '')}"><button data-act="coupon">تطبيق</button></div></div></div>
  <div class="box sum"><h4>${ic('doc')} ملخص الطلب</h4>
    <div class="sr"><span>المجموع الفرعي</span><em>${money(t.sub, cur)}</em></div>
    <div class="sr g"><span>${ic('tag')} خصم الكوبون${t.pct ? ` (${t.pct}%)` : ''}</span><em>${t.disc ? '-' : ''}${money(t.disc, cur)}</em></div>
    <div class="sr g"><span>${ic('truck')} مصاريف الشحن</span><em>${money(t.ship, cur)}</em></div>
    <div class="sr t"><span>${ic('wallet')} الإجمالي الكلي</span><em>${money(t.total, cur)}</em></div></div>
  <button class="btn-big" data-act="checkout">${ic('lock')} إتمام الشراء الآن</button>`;
}

/* ---------- حسابي ---------- */
function accountView() {
  const u = S.user, mine = S.orders.filter(o => o.user === u.id);
  return `<div class="prof"><div class="av">${esc((u.name || 'م')[0])}</div><div><b>${esc(u.name)}</b><small>${esc(u.id)}</small></div></div>
  <div class="stats"><div><b>${S.favs.length}</b><span>المفضلة</span></div><div><b>${cartCount()}</b><span>في السلة</span></div><div><b>${mine.length}</b><span>طلباتي</span></div></div>
  <div class="sec">العملة</div><div class="box curbox"><button class="chip ${S.cur === 'SAR' ? 'on' : ''}" data-act="setcur" data-v="SAR">ريال سعودي</button><button class="chip ${S.cur === 'YER' ? 'on' : ''}" data-act="setcur" data-v="YER">ريال يمني</button></div>
  <div class="sec">طلباتي الأخيرة</div>
  <div class="box">${mine.length ? mine.slice(-5).reverse().map(o => `<div class="ord"><span>#${o.id}<br><span class="status ${o.sent ? 'ok' : ''}">${o.sent ? 'تم إرساله' : 'محفوظ محلياً'}</span></span><em>${money(o.total, o.cur)}</em></div>`).join('') : '<div class="note" style="margin:0">لا توجد طلبات بعد</div>'}</div>
  ${S.admin ? `<div class="sec">لوحة المدير</div><div class="box">
    <button class="btn-gold" style="width:100%" data-act="newp">${ic('plus')} إضافة منتج جديد</button>
    <div class="note">أوامر البوت (تعمل أثناء فتح التطبيق بوضع المدير):<br><code>/help</code> لعرض كل الأوامر: إضافة وتعديل المنتجات، تغيير صور البنر والشعار، المحافظ، الكوبونات، المستخدمين.</div>
    <button class="btn-line" data-act="adminoff">الخروج من وضع المدير</button></div>`
    : `<button class="btn-line" data-act="adminon">${ic('lock')} وضع المدير</button>`}
  <button class="btn-line" data-act="logout">تسجيل الخروج</button>`;
}

/* ---------- تسجيل الدخول ---------- */
const GOOGLE = '<svg viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.6 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4.1-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
function loginView() {
  const reg = UI.mode === 'register';
  return `<div class="login"><div class="top">
    <div class="lang">${ic('globe')} العربية ${ic('caret')}</div>
    <img class="big" src="${bottle(['#d4af37', '#2a1c06'])}"><div class="rose"></div>
    <div class="brand">${logoHtml()}</div>
    <div class="welcome"><h2>${reg ? 'أهلاً بك' : 'مرحباً بك مجدداً'}</h2><p>${reg ? 'أنشئ حسابك للمتابعة' : 'تسجيل الدخول للمتابعة'}</p></div></div>
  <form id="lf" autocomplete="off">
    ${reg ? `<div class="inp">${ic('user')}<input id="ln" placeholder="الاسم الكامل"></div>` : ''}
    <div class="inp">${ic('mail')}<input id="lu" placeholder="البريد الإلكتروني أو رقم الجوال" autocapitalize="off"></div>
    <div class="inp">${ic('lock')}<input id="lp" type="${UI.showPw ? 'text' : 'password'}" placeholder="كلمة المرور"><button type="button" class="eye" data-act="togglepw">${ic(UI.showPw ? 'eye' : 'eyeoff')}</button></div>
    <div class="err">${esc(UI.err)}</div>
    <div class="row2"><button type="button" class="chk" data-act="remember"><i class="${S.remember ? '' : 'off'}">${ic('check')}</i>تذكرني</button><button type="button" class="lnk" data-act="forgot">نسيت كلمة المرور؟</button></div>
    <button class="btn-big" type="submit">${UI.busy ? 'جاري التحقق...' : (reg ? 'إنشاء الحساب' : 'تسجيل الدخول')} ${ic('send')}</button>
    <div class="divider">أو المتابعة عبر</div>
    <button type="button" class="btn-google" data-act="google">${GOOGLE} تسجيل الدخول بواسطة جوجل</button>
    <button type="button" class="btn-line" data-act="restorefile">استعادة حسابي من ملف محفوظ</button>
    <input type="file" id="rf" accept=".json,application/json" hidden>
    <div class="switch">${reg ? 'لديك حساب بالفعل؟' : 'ليس لديك حساب؟'}<button type="button" data-act="mode">${reg ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}</button></div>
  </form></div>`;
}
function setErr(m) { UI.err = m; const e = $('.err'); if (e) e.textContent = m; }
function downloadBackup(u) {
  try {
    const blob = new Blob([JSON.stringify({ type: 'perfume-account', id: u.id, name: u.name, pw: u.pw, phone: u.phone || '' })], { type: 'application/json' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'perfume-account-' + u.id.replace(/[^\w.@-]/g, '_') + '.json'; document.body.appendChild(a); a.click(); a.remove();
  } catch (e) { }
}
async function submitLogin() {
  if (UI.busy) return;
  const id = $('#lu').value.trim(), pw = $('#lp').value, nm = $('#ln') ? $('#ln').value.trim() : '';
  if (!id || !pw) return setErr('أدخل البريد أو الجوال وكلمة المرور');
  UI.busy = true; const btn = $('#lf .btn-big'); if (btn) btn.textContent = 'جاري التحقق...';
  try {
    const hp = pwHash(id, pw);
    if (UI.mode === 'register') {
      if (!nm) return setErr('أدخل اسمك الكامل');
      if (pw.length < 4) return setErr('كلمة المرور يجب ألا تقل عن 4 أحرف');
      try { const { db } = await remoteGet(); if (db) applyDb(db); } catch (e) { }
      if (S.users.some(u => u.id.toLowerCase() === id.toLowerCase())) return setErr('هذا الحساب مسجّل مسبقاً، سجّل الدخول');
      const u = { id, name: nm, pw: hp };
      await mutate(db => { db.users = db.users || []; if (!db.users.some(x => x.id.toLowerCase() === id.toLowerCase())) db.users.push(u); });
      if (!S.users.some(x => x.id === id)) S.users.push(u);
      say(`👤 <b>تسجيل مستخدم جديد</b>\nالاسم: ${h(nm)}\nالحساب: ${h(id)}\n🕒 ${new Date().toLocaleString('ar')}`);
      downloadBackup(u); S.user = { id, name: nm };
    } else {
      let u = S.users.find(x => x.id.toLowerCase() === id.toLowerCase() && x.pw === hp);
      if (!u) { try { const { db } = await remoteGet(); if (db) { applyDb(db); u = S.users.find(x => x.id.toLowerCase() === id.toLowerCase() && x.pw === hp); } } catch (e) { } }
      if (!u) return setErr('بيانات الدخول غير صحيحة');
      S.user = { id: u.id, name: u.name, phone: u.phone };
    }
    UI.err = ''; S.screen = 'home'; save(); render(); sync();
  } finally { UI.busy = false; if (!S.user) { const b = $('#lf .btn-big'); if (b) b.innerHTML = (UI.mode === 'register' ? 'إنشاء الحساب ' : 'تسجيل الدخول ') + ic('send'); } }
}

/* ---------- النوافذ ---------- */
function sheet(html) { const m = $('#modal'); m.innerHTML = `<div class="sheet">${html}</div>`; m.classList.add('show'); resolveImages(); }
function closeModal() { const m = $('#modal'); m.classList.remove('show'); m.innerHTML = ''; }
const copyText = async t => { try { await navigator.clipboard.writeText(t); } catch (e) { const a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); try { document.execCommand('copy'); } catch (e2) { } a.remove(); } };

function openCheckout() {
  const t = totals(); if (!t.lines.length) return toast('السلة فارغة');
  UI.receipt = null;
  const u = S.user;
  sheet(`<h3>إتمام الشراء <button data-act="closemodal">${ic('x')}</button></h3>
    <label class="fld"><span>الاسم</span><input class="rtl" id="on" value="${esc(u.name)}"></label>
    <label class="fld"><span>رقم الجوال</span><input id="op" value="${esc(u.phone || (/^[+\d\s-]+$/.test(u.id) ? u.id : ''))}"></label>
    <label class="fld"><span>عنوان التوصيل</span><textarea class="rtl" id="oa">${esc(u.address || '')}</textarea></label>
    <label class="fld"><span>ملاحظات (اختياري)</span><input class="rtl" id="oo"></label>
    <div class="tot"><span>الإجمالي</span><em>${money(t.total, S.cur)}</em></div>
    <div class="paytabs"><button class="chip ${UI.pay === 'wallet' ? 'on' : ''}" data-act="pay" data-v="wallet">${ic('wallet')} المحافظ الإلكترونية</button><button class="chip ${UI.pay === 'wa' ? 'on' : ''}" data-act="pay" data-v="wa">${ic('phone')} الشراء عبر الواتس</button></div>
    <div id="payBody">${payBody()}</div>
    <button class="btn-big" id="cfo" data-act="confirmorder">${ic('check')} تأكيد وإرسال الطلب</button>`);
}
function payBody() {
  if (UI.pay === 'wa') return `<div class="note" style="margin:0 0 12px">سيتم تسجيل طلبك وإرساله لنا، ثم يفتح الواتس مباشرة لإكمال الشراء. تفاصيل الطلب تُنسخ تلقائياً لتلصقها في المحادثة.</div>`;
  return `<div class="walletbox"><b>حوّل المبلغ إلى إحدى المحافظ التالية ثم أرفق صورة التحويل:</b>
    ${S.wallets.map(w => `<div class="wl"><div><small>${esc(w.name)}</small><strong>${esc(w.number)}</strong></div><button data-act="copy" data-v="${esc(w.number)}">${ic('copy')} نسخ</button></div>`).join('')}
    <label class="upl" for="rc">${ic('image')} <span id="rcn">${UI.receipt ? esc(UI.receipt.name) : 'إرفاق صورة التحويل (مطلوب)'}</span></label>
    <input type="file" id="rc" accept="image/*" hidden></div>`;
}
function orderMessage(o) {
  const lines = o.items.map((i, n) => `${n + 1}. ${h(i.name)} (${h(i.size || '')}) × ${i.qty} — ${money((o.cur === 'SAR' ? i.sar : i.yer) * i.qty, o.cur)}`).join('\n');
  return `🛍 <b>طلب جديد #${o.id}</b>\n💳 <b>طريقة الدفع:</b> ${o.method === 'wa' ? 'واتس' : 'محفظة إلكترونية (مع إيصال)'}\n\n👤 <b>الاسم:</b> ${h(o.name)}\n📞 <b>الجوال:</b> ${h(o.phone)}\n📍 <b>العنوان:</b> ${h(o.address)}\n${o.note ? '📝 <b>ملاحظات:</b> ' + h(o.note) + '\n' : ''}🔑 <b>الحساب:</b> ${h(o.user)}\n\n━━━━━━━━━━\n${lines}\n━━━━━━━━━━\nالمجموع الفرعي: ${money(o.sub, o.cur)}\n` +
    (o.coupon ? `🏷 كوبون ${h(o.coupon)} (${o.pct}%): -${money(o.disc, o.cur)}\n` : '') + `🚚 الشحن: ${money(o.ship, o.cur)}\n💰 <b>الإجمالي: ${money(o.total, o.cur)}</b>\n(≈ ${money(o.totalAlt, other(o.cur))})\n🕒 ${new Date(o.time).toLocaleString('ar')}`;
}
async function confirmOrder() {
  const name = $('#on').value.trim(), phone = $('#op').value.trim(), address = $('#oa').value.trim(), note = $('#oo').value.trim();
  if (!name || !phone || !address) return toast('أكمل الاسم والجوال والعنوان');
  if (UI.pay === 'wallet' && !UI.receipt) return toast('أرفق صورة التحويل أولاً');
  const cur = S.cur, t = totals(cur), alt = totals(other(cur)); if (!t.lines.length) return;
  const o = {
    id: S.nextOid++, user: S.user.id, name, phone, address, note, time: Date.now(), cur, method: UI.pay,
    items: t.lines.map(l => ({ id: l.id, name: l.p.name, size: l.p.size, sar: l.p.sar, yer: l.p.yer, qty: l.qty })),
    sub: t.sub, coupon: S.coupon, pct: t.pct, disc: t.disc, ship: t.ship, total: t.total, totalAlt: alt.total, sent: false
  };
  const btn = $('#cfo'); btn.disabled = true; btn.textContent = 'جاري الإرسال...';
  try {
    await tg('sendMessage', { chat_id: CHAT, text: orderMessage(o), parse_mode: 'HTML' }); o.sent = true;
    if (o.method === 'wallet') await uploadPhoto(await compress(UI.receipt, 1400), `🧾 إيصال تحويل للطلب #${o.id} — ${money(o.total, cur)}`);
  } catch (e) { toast('تم حفظ الطلب لكن تعذر إرساله بالكامل: ' + e.message); }
  S.orders.push(o); const items = o.items.map(i => i.id);
  S.cart = []; S.coupon = null; S.user.phone = phone; S.user.address = address; save();
  if (o.method === 'wa') {
    const txt = orderMessage(o).replace(/<\/?b>/g, '');
    await copyText(txt); try { window.open(CONFIG.WHATSAPP_URL, '_blank'); } catch (e) { }
    sheet(`<h3>تم تسجيل الطلب #${o.id} <button data-act="closemodal">${ic('x')}</button></h3><div class="note" style="margin:0 0 14px">نسخنا تفاصيل طلبك. إذا لم يفتح الواتس تلقائياً اضغط الزر ثم الصق التفاصيل في المحادثة.</div><a class="btn-big" style="text-decoration:none" href="${CONFIG.WHATSAPP_URL}" target="_blank">${ic('phone')} فتح الواتس</a><button class="btn-line" data-act="rateafter">تقييم المنتجات</button>`);
  } else { toast(`✅ تم إرسال طلبك #${o.id}`); rateSheet(items, true); }
  UI.lastItems = items; render();
}

/* ---------- التقييم ---------- */
function rateSheet(ids, after) {
  ids = ids.filter(id => prod(id) && !S.myRatings[id]); if (!ids.length) return closeModal();
  UI.rateItems = [...new Set(ids)]; UI.rateVals = {}; drawRate(after);
}
function drawRate(after) {
  sheet(`<h3>${after ? 'شكراً لطلبك! قيّم منتجاتك' : 'قيّم المنتج'} <button data-act="closemodal">${ic('x')}</button></h3>
  ${UI.rateItems.map(id => `<div class="rrow"><b>${esc(prod(id).name)}</b><div class="stars">${[1, 2, 3, 4, 5].map(n => `<button class="${(UI.rateVals[id] || 0) >= n ? 'on' : ''}" data-act="star" data-id="${id}" data-v="${n}">${STAR}</button>`).join('')}</div></div>`).join('')}
  <button class="btn-big" data-act="sendrate">إرسال التقييم</button><button class="btn-line" data-act="closemodal">تخطي</button>`);
}
async function sendRate() {
  const vals = Object.entries(UI.rateVals).filter(([id]) => !S.myRatings[id]); if (!vals.length) return closeModal();
  vals.forEach(([id, v]) => S.myRatings[id] = +v); save();
  await mutate(db => vals.forEach(([id, v]) => { const p = db.products.find(x => x.id === +id); if (p) { p.rsum = (p.rsum || 0) + +v; p.rcount = (p.rcount || 0) + 1; } }));
  closeModal(); toast('شكراً لتقييمك ⭐'); render();
}

/* ---------- تعديل المنتج (المدير) ---------- */
function editSheet(pid) {
  const p = pid ? prod(pid) : { name: '', desc: '', details: '', sar: '', osar: '', yer: '', oyer: '', cat: 'unisex', size: '100 مل', conc: 'Eau de Parfum', imgs: [] };
  UI.edit = { id: pid || null, imgs: [...(p.imgs || [])], c: p.c };
  const f = (id, label, val, extra = '') => `<label class="fld"><span>${label}</span><input id="${id}" value="${esc(val)}" ${extra}></label>`;
  sheet(`<h3>${pid ? 'تعديل المنتج' : 'منتج جديد'} <button data-act="closemodal">${ic('x')}</button></h3>
    ${f('en', 'اسم المنتج', p.name, 'class="rtl"')}${f('ed', 'وصف قصير', p.desc, 'class="rtl"')}
    <label class="fld"><span>تفاصيل المنتج</span><textarea class="rtl" id="ex">${esc(p.details || '')}</textarea></label>
    <div class="two">${f('es', 'السعر (ر.س)', p.sar, 'inputmode="decimal"')}${f('eos', 'قبل الخصم (ر.س)', p.osar, 'inputmode="decimal"')}</div>
    <div class="two">${f('ey', 'السعر (ر.ي)', p.yer, 'inputmode="decimal"')}${f('eoy', 'قبل الخصم (ر.ي)', p.oyer, 'inputmode="decimal"')}</div>
    <label class="fld"><span>القسم</span><select id="ec">${Object.entries(CATS).filter(([k]) => k !== 'offers').map(([k, l]) => `<option value="${k}" ${p.cat === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    <div class="two">${f('ez', 'الحجم', p.size, 'class="rtl"')}${f('ek', 'التركيز', p.conc)}</div>
    <div class="fld"><span>الصور (الأولى هي الرئيسية)</span><div class="eimgs" id="eimgs">${editImgs()}</div>
      <label class="upl" for="ef">${ic('image')} <span>إضافة صورة من الجهاز</span></label><input type="file" id="ef" accept="image/*" multiple hidden></div>
    <button class="btn-big" data-act="savep">حفظ</button>
    ${pid ? `<button class="btn-line danger" data-act="delp">حذف المنتج</button>` : ''}`);
}
const editImgs = () => UI.edit.imgs.map((r, i) => `<div class="ei">${imgTag(r, '', bottle(UI.edit.c))}<button data-act="eimg-rm" data-v="${i}">${ic('x')}</button>${i ? `<button class="mk" data-act="eimg-main" data-v="${i}">★</button>` : ''}</div>`).join('') || '<small style="color:var(--mut)">لا توجد صور</small>';
async function saveProduct() {
  const e = UI.edit, g = id => $('#' + id).value.trim(), num = id => parseFloat(g(id)) || 0, name = g('en');
  if (!name) return toast('أدخل اسم المنتج');
  const data = { name, desc: g('ed'), details: g('ex'), sar: num('es'), osar: num('eos'), yer: num('ey'), oyer: num('eoy'), cat: $('#ec').value, size: g('ez') || '100 مل', conc: g('ek') || 'Eau de Parfum', imgs: e.imgs };
  await mutate(db => {
    if (e.id) { const p = db.products.find(x => x.id === e.id); if (p) Object.assign(p, data); }
    else { const id = db.nextPid++; db.products.unshift({ id, rsum: 0, rcount: 0, badge: '🆕 جديد', c: PALETTE[id % PALETTE.length], ...data }); }
  });
  closeModal(); render(); toast('تم الحفظ ✅');
}

/* ---------- أوامر البوت (المدير) ---------- */
let polling = false;
function startPolling() {
  if (polling || !S.admin) return; polling = true;
  (async function loop() {
    while (S.admin) {
      try {
        const ups = await tg('getUpdates', { offset: S.offset, timeout: CONFIG.POLL_SECONDS, allowed_updates: ['message'] });
        for (const u of ups) { S.offset = u.update_id + 1; save(); await handleUpdate(u).catch(e => say('❌ ' + h(e.message))); }
      } catch (e) { await new Promise(r => setTimeout(r, 6000)); }
    }
    polling = false;
  })();
}
const CAT_MAP = { women: 'women', 'نسائي': 'women', 'نسائية': 'women', men: 'men', 'رجالي': 'men', 'رجالية': 'men', unisex: 'unisex', 'للجنسين': 'unisex', gifts: 'gifts', 'هدايا': 'gifts', 'هدية': 'gifts' };
const HELP = `📋 أوامر المتجر\n\n➕ /add الاسم | سعودي | يمني | قديم سعودي | قديم يمني | القسم | الحجم\n(القسم: women men unisex gifts — ضع 0 لعدم وجود خصم — أرسل صورة مع الأمر كتعليق)\n\n✏️ /edit رقم | الحقل | القيمة\nالحقول: name desc details sar yer osar oyer cat size conc\n🏷 /discount رقم | سعودي | يمني | قديم سعودي | قديم يمني\n🖼 /img رقم (صورة بتعليق: تغيير الصورة الرئيسية)\n🖼 /gallery رقم (صورة بتعليق: إضافة صورة للمعرض)\n🗑 /del رقم\n📃 /list\n\n🎞 /banner رقم | العنوان | العنوان الذهبي | الوصف (صورة اختيارية)\n/banner add | ... (صورة)  •  /banner del رقم\n🏷 /logo (صورة بتعليق: تغيير الشعار)  •  /logo reset\n\n💳 /wallet الاسم | الرقم  •  /wallets  •  /delwallet رقم\n🎟 /coupon كود | نسبة\n👥 /users  •  /resetpw الحساب | كلمة جديدة\n📦 /orders`;
async function handleUpdate(u) {
  const m = u.message; if (!m || String(m.chat.id) !== String(CHAT)) return;
  const text = (m.text || m.caption || '').trim(); if (!text.startsWith('/')) return;
  const first = text.split(/\s+/)[0], cmd = first.split('@')[0].toLowerCase(), args = text.slice(first.length).trim();
  const parts = args.split('|').map(x => x.trim()), fid = m.photo && m.photo.length ? 'tgf:' + m.photo[m.photo.length - 1].file_id : '';
  const refresh = () => { save(); if (S.user && canRerender()) keepScroll(); };
  const num = x => parseFloat(x) || 0;

  if (cmd === '/start' || cmd === '/help') return say(HELP);
  if (cmd === '/add') {
    const [name, sar, yer, osar, oyer, cat, size] = parts;
    if (!name || !(num(sar) > 0 || num(yer) > 0)) return say('❌ الصيغة:\n/add الاسم | سعودي | يمني | قديم سعودي | قديم يمني | القسم | الحجم');
    let newId; await mutate(db => { newId = db.nextPid++; db.products.unshift({ id: newId, name, sar: num(sar), yer: num(yer), osar: num(osar) > num(sar) ? num(osar) : 0, oyer: num(oyer) > num(yer) ? num(oyer) : 0, cat: CAT_MAP[(cat || '').toLowerCase()] || 'unisex', size: size || '100 مل', conc: 'Eau de Parfum', desc: '', details: '', imgs: fid ? [fid] : [], rsum: 0, rcount: 0, badge: '🆕 جديد', c: PALETTE[newId % PALETTE.length] }); });
    refresh(); return say(`✅ تمت إضافة المنتج #${newId}: ${h(name)}${fid ? ' (مع صورة)' : ''}\nلتعديل التفاصيل: /edit ${newId} | details | النص`);
  }
  if (cmd === '/edit') {
    const id = parseInt(parts[0]), field = (parts[1] || '').toLowerCase(), val = parts.slice(2).join(' | ');
    const fields = { name: 's', desc: 's', details: 's', size: 's', conc: 's', sar: 'n', yer: 'n', osar: 'n', oyer: 'n', cat: 'c' };
    if (!prod(id) || !fields[field]) return say('❌ الصيغة: /edit رقم | الحقل | القيمة\nالحقول: ' + Object.keys(fields).join(' '));
    await mutate(db => { const p = db.products.find(x => x.id === id); if (p) p[field] = fields[field] === 'n' ? num(val) : fields[field] === 'c' ? (CAT_MAP[val.toLowerCase()] || p.cat) : val; });
    refresh(); return say('✅ تم التعديل');
  }
  if (cmd === '/discount') {
    const id = parseInt(parts[0]); if (!prod(id)) return say('❌ رقم المنتج غير موجود. استخدم /list');
    await mutate(db => { const p = db.products.find(x => x.id === id); if (!p) return; if (parts[1]) p.sar = num(parts[1]); if (parts[2]) p.yer = num(parts[2]); p.osar = num(parts[3]); p.oyer = num(parts[4]); });
    refresh(); return say('✅ تم تحديث السعر والخصم');
  }
  if (cmd === '/img' || cmd === '/gallery') {
    const id = parseInt(parts[0]); if (!prod(id) || !fid) return say('❌ أرسل صورة مع تعليق مثل: ' + cmd + ' رقم_المنتج');
    await mutate(db => { const p = db.products.find(x => x.id === id); if (!p) return; p.imgs = p.imgs || []; cmd === '/img' ? p.imgs.unshift(fid) : p.imgs.push(fid); });
    refresh(); return say('✅ تم تحديث الصور');
  }
  if (cmd === '/del') {
    const id = parseInt(parts[0]), p = prod(id); if (!p) return say('❌ رقم المنتج غير موجود');
    await mutate(db => { db.products = db.products.filter(x => x.id !== id); }); S.cart = S.cart.filter(x => x.id !== id); S.favs = S.favs.filter(x => x !== id);
    refresh(); return say('🗑 تم حذف: ' + h(p.name));
  }
  if (cmd === '/list') return say(S.products.map(p => `#${p.id} ${h(p.name)} — ${money(p.sar, 'SAR')} | ${money(p.yer, 'YER')}${p.osar || p.oyer ? ' 🏷' : ''} ⭐${avg(p).toFixed(1)}(${p.rcount || 0})`).join('\n') || 'لا توجد منتجات');
  if (cmd === '/banner') {
    const w = (parts[0] || '').split(/\s+/); const op = w[0].toLowerCase();
    if (op === 'del') { const n = parseInt(w[1]); if (!S.banners[n - 1]) return say('❌ رقم غير صحيح'); await mutate(db => { db.banners.splice(n - 1, 1); }); refresh(); return say('🗑 تم حذف البنر'); }
    const txt = { h3: parts[1], h2: parts[2], p: parts[3] };
    if (op === 'add') { if (!fid) return say('❌ أرسل صورة مع الأمر'); await mutate(db => { db.banners.push({ h3: txt.h3 || 'اكتشف عالم', h2: txt.h2 || 'العطور الفاخرة', p: txt.p || 'بمزيج من الفخامة والجاذبية', img: fid }); }); refresh(); return say('✅ تمت إضافة بنر جديد'); }
    const n = parseInt(op); if (!S.banners[n - 1]) return say('❌ الصيغة: /banner رقم | العنوان | الذهبي | الوصف (مع صورة)\nعدد البنرات الحالية: ' + S.banners.length);
    await mutate(db => { const b = db.banners[n - 1]; if (fid) b.img = fid; if (txt.h3) b.h3 = txt.h3; if (txt.h2) b.h2 = txt.h2; if (txt.p) b.p = txt.p; });
    refresh(); return say('✅ تم تحديث البنر ' + n);
  }
  if (cmd === '/logo') {
    if (parts[0] === 'reset') { await mutate(db => { db.logo = ''; }); refresh(); return say('✅ تمت إعادة الشعار الافتراضي'); }
    if (!fid) return say('❌ أرسل صورة الشعار مع التعليق /logo');
    await mutate(db => { db.logo = fid; }); refresh(); return say('✅ تم تغيير شعار التطبيق');
  }
  if (cmd === '/wallet') { if (!parts[1]) return say('❌ الصيغة: /wallet الاسم | الرقم'); await mutate(db => { db.wallets = (db.wallets || []).filter(w => w.name !== parts[0]); db.wallets.push({ name: parts[0], number: parts[1] }); }); refresh(); return say('✅ تم حفظ المحفظة'); }
  if (cmd === '/wallets') return say(S.wallets.map((w, i) => `${i + 1}. ${h(w.name)}: ${h(w.number)}`).join('\n'));
  if (cmd === '/delwallet') { const n = parseInt(parts[0]); if (!S.wallets[n - 1] || S.wallets.length < 2) return say('❌ رقم غير صحيح (يجب بقاء محفظة واحدة على الأقل)'); await mutate(db => { db.wallets.splice(n - 1, 1); }); refresh(); return say('🗑 تم الحذف'); }
  if (cmd === '/coupon') { const code = (parts[0] || '').toUpperCase(), pct = num(parts[1]); if (!code || !(pct > 0 && pct <= 100)) return say('❌ الصيغة: /coupon كود | نسبة'); await mutate(db => { db.coupons = db.coupons || {}; db.coupons[code] = pct; }); return say(`✅ كوبون ${h(code)} بخصم ${pct}%`); }
  if (cmd === '/users') { try { const { db } = await remoteGet(); if (db) applyDb(db); } catch (e) { } return say(S.users.map((x, i) => `${i + 1}. ${h(x.name)} — ${h(x.id)}`).join('\n') || 'لا يوجد مستخدمون'); }
  if (cmd === '/resetpw') { const id = parts[0], pw = parts[1]; if (!id || !pw) return say('❌ الصيغة: /resetpw الحساب | كلمة المرور الجديدة'); let ok = false; await mutate(db => { const x = (db.users || []).find(y => y.id.toLowerCase() === id.toLowerCase()); if (x) { x.pw = pwHash(x.id, pw); ok = true; } }); return say(ok ? '✅ تم تغيير كلمة المرور' : '❌ الحساب غير موجود'); }
  if (cmd === '/orders') return say(S.orders.slice(-10).map(o => `#${o.id} ${h(o.name)} — ${money(o.total, o.cur)}`).join('\n') || 'لا توجد طلبات على هذا الجهاز');
}

/* ---------------- الأحداث ---------------- */
document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]'); if (!el) return;
  const a = el.dataset.act, id = +el.dataset.id, v = el.dataset.v;
  switch (a) {
    case 'open': openProduct(id); break;
    case 'back': go(S.screen === 'product' ? (S.prev || 'home') : 'home'); break;
    case 'nav': if (v === 'categories') go('categories', { cat: 'all', q: '' }); else if (v === 'offers') go('offers', { cat: 'offers' }); else go(v); break;
    case 'cat': go(v === 'offers' ? 'offers' : 'categories', { cat: v, q: ['categories', 'offers'].includes(S.screen) ? S.q : '' }); break;
    case 'cur': S.cur = other(S.cur); save(); keepScroll(); break;
    case 'setcur': S.cur = v; save(); keepScroll(); break;
    case 'thumb': UI.gi = +v; keepScroll(); break;
    case 'fav': S.favs = isFav(id) ? S.favs.filter(x => x !== id) : [...S.favs, id]; save(); keepScroll(); toast(isFav(id) ? 'أضيف إلى المفضلة' : 'أزيل من المفضلة'); break;
    case 'share': { const p = prod(S.pid); try { if (navigator.share) await navigator.share({ title: p.name, text: p.name + ' - ' + CONFIG.STORE_NAME, url: location.href }); else { await copyText(p.name + ' - ' + location.href); toast('تم نسخ الرابط'); } } catch (er) { } break; }
    case 'add': { const it = S.cart.find(x => x.id === id); it ? it.qty++ : S.cart.push({ id, qty: 1 }); save(); keepScroll(); toast('أضيف إلى السلة'); break; }
    case 'buynow': { if (!S.cart.find(x => x.id === id)) S.cart.push({ id, qty: 1 }); save(); render(); openCheckout(); break; }
    case 'qty': { const it = S.cart.find(x => x.id === id); if (it) { it.qty += +el.dataset.d; if (it.qty < 1) S.cart = S.cart.filter(x => x.id !== id); } save(); keepScroll(); break; }
    case 'rm': S.cart = S.cart.filter(x => x.id !== id); save(); keepScroll(); break;
    case 'clearcart': if (S.cart.length && confirm('تفريغ السلة بالكامل؟')) { S.cart = []; S.coupon = null; save(); render(); } break;
    case 'coupon': { const c = ($('#cp').value || '').trim().toUpperCase(); if (!c) { S.coupon = null; save(); return keepScroll(); } if (S.coupons[c]) { S.coupon = c; save(); keepScroll(); toast('تم تطبيق الكوبون ' + c); } else toast('كود الخصم غير صحيح'); break; }
    case 'checkout': openCheckout(); break;
    case 'pay': UI.pay = v; document.querySelectorAll('.paytabs .chip').forEach(b => b.classList.toggle('on', b.dataset.v === v)); $('#payBody').innerHTML = payBody(); break;
    case 'copy': await copyText(v); toast('تم نسخ الرقم'); break;
    case 'confirmorder': confirmOrder(); break;
    case 'closemodal': closeModal(); break;
    case 'rateafter': rateSheet(UI.lastItems || [], true); break;
    case 'ratebtn': rateSheet([id]); break;
    case 'star': UI.rateVals[id] = +v; drawRate(); break;
    case 'sendrate': sendRate(); break;
    case 'bell': toast('لا توجد إشعارات جديدة'); break;
    case 'togglepw': { const x = { u: $('#lu').value, p: $('#lp').value, n: $('#ln') ? $('#ln').value : '' }; UI.showPw = !UI.showPw; render(); $('#lu').value = x.u; $('#lp').value = x.p; if ($('#ln')) $('#ln').value = x.n; break; }
    case 'remember': { S.remember = !S.remember; save(); const x = { u: $('#lu').value, p: $('#lp').value }; render(); $('#lu').value = x.u; $('#lp').value = x.p; break; }
    case 'mode': UI.mode = UI.mode === 'login' ? 'register' : 'login'; UI.err = ''; render(); break;
    case 'forgot': { const id2 = ($('#lu').value || '').trim(); if (!id2) return toast('اكتب بريدك أو جوالك أولاً'); say(`🔐 <b>طلب استعادة كلمة مرور</b>\nالحساب: ${h(id2)}\nلإعادة التعيين: /resetpw ${h(id2)} | كلمة_جديدة`); toast('تم إرسال طلبك للمتجر، سيتواصلون معك'); break; }
    case 'restorefile': $('#rf').click(); break;
    case 'google': { const n = prompt('تجريبي: أدخل اسمك للمتابعة بحساب جوجل'); if (n) { S.user = { id: n.trim().toLowerCase().replace(/\s+/g, '') + '@gmail.com', name: n.trim() }; S.screen = 'home'; save(); render(); } break; }
    case 'logout': S.user = null; S.admin = false; S.screen = 'home'; save(); render(); break;
    case 'adminon': { const pw = prompt('كلمة مرور المدير'); if (pw === null) break; if (pw === CONFIG.ADMIN_PASSWORD) { S.admin = true; save(); startPolling(); say('🔓 تم تفعيل وضع المدير على جهاز.\n\n' + HELP); keepScroll(); toast('تم تفعيل وضع المدير'); } else toast('كلمة المرور غير صحيحة'); break; }
    case 'adminoff': S.admin = false; save(); keepScroll(); break;
    case 'newp': editSheet(null); break;
    case 'editp': editSheet(id); break;
    case 'savep': saveProduct(); break;
    case 'delp': if (confirm('حذف هذا المنتج نهائياً؟')) { const pid = UI.edit.id; await mutate(db => { db.products = db.products.filter(x => x.id !== pid); }); S.cart = S.cart.filter(x => x.id !== pid); S.favs = S.favs.filter(x => x !== pid); closeModal(); go(S.prev || 'home'); } break;
    case 'eimg-rm': UI.edit.imgs.splice(+v, 1); $('#eimgs').innerHTML = editImgs(); resolveImages(); break;
    case 'eimg-main': { const [x] = UI.edit.imgs.splice(+v, 1); UI.edit.imgs.unshift(x); $('#eimgs').innerHTML = editImgs(); resolveImages(); break; }
  }
});
document.addEventListener('submit', e => { e.preventDefault(); if (e.target.id === 'lf') submitLogin(); });
document.addEventListener('change', async e => {
  const t = e.target;
  if (t.id === 'rc' && t.files[0]) { UI.receipt = t.files[0]; $('#rcn').textContent = '✓ ' + t.files[0].name; }
  if (t.id === 'ef' && t.files.length) {
    toast('جاري رفع الصورة...');
    for (const f of [...t.files]) { try { const id = await uploadPhoto(await compress(f)); UI.edit.imgs.push('tgf:' + id); } catch (er) { toast('فشل رفع الصورة: ' + er.message); } }
    t.value = ''; $('#eimgs').innerHTML = editImgs(); resolveImages(); toast('تم رفع الصورة');
  }
  if (t.id === 'rf' && t.files[0]) {
    try {
      const d = JSON.parse(await t.files[0].text());
      if (d.type !== 'perfume-account' || !d.id || !d.pw) throw 0;
      const i = S.users.findIndex(x => x.id === d.id); const u = { id: d.id, name: d.name, pw: d.pw, phone: d.phone };
      i < 0 ? S.users.push(u) : S.users[i] = u; save(); $('#lu').value = d.id; toast('تم استرجاع الحساب، أدخل كلمة المرور');
    } catch (er) { toast('الملف غير صالح'); }
  }
});

/* مؤقت البنر */
setInterval(() => {
  if (!S.user || S.screen !== 'home') return;
  const sl = document.querySelectorAll('.slide'), ds = document.querySelectorAll('.dots span'); if (sl.length < 2) return;
  UI.slide = (UI.slide + 1) % sl.length;
  sl.forEach((s, i) => s.classList.toggle('on', i === UI.slide)); ds.forEach((d, i) => d.classList.toggle('on', i === UI.slide));
}, 4000);

/* ارتفاع الشاشة الحقيقي للهواتف */
function vh() { document.documentElement.style.setProperty('--vh', innerHeight * 0.01 + 'px'); }
addEventListener('resize', vh); vh();

/* بدء التشغيل */
render();
sync(); setInterval(sync, CONFIG.SYNC_SECONDS * 1000);
document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });
startPolling();
