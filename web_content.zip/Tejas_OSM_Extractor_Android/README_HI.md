# Tejas OSM Extractor Android project

Yeh Android Studio project aapki `Tejas_OSM_Extractor_v2.html` file ko Android WebView app ke andar chalane ke liye banaya gaya hai.

## APK banane ke liye
1. Android Studio install karein (Android SDK Platform 35 aur JDK 17 ke saath).
2. Is ZIP ko extract karein.
3. Android Studio mein `Tejas_OSM_Extractor_Android` folder open karein.
4. Gradle sync complete hone dein.
5. **Build > Build Bundle(s) / APK(s) > Build APK(s)** select karein.
6. APK aam taur par `app/build/outputs/apk/debug/app-debug.apk` mein milega.

## Zaroori baat
- Is project mein original HTML `app/src/main/assets/index.html` ke naam se bundled hai.
- Map tiles, OpenStreetMap/Nominatim, Overpass APIs aur CDN libraries ke liye internet zaroori hai.
- Location aur area import ke liye Android permissions/file picker use hote hain.
- Yeh ZIP Android project source hai, compiled APK nahi. APK ko Android SDK/Gradle build environment mein compile karna hoga.
