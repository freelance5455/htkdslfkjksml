# Privacy Shield Suite v4

This version connects Android `VpnService` to a real native TUN→SOCKS5 packet engine.

Architecture:
Device apps → Android TUN → hev-socks5-tunnel → configured SOCKS5 server → Internet.

The engine supports IPv4/IPv6 and TCP/UDP forwarding. The Android AAR is supplied through Maven Central as `com.wgtunnel:hevtunnel:1.7.6`; the underlying hev-socks5-tunnel project documents the same TUN file-descriptor integration and SOCKS5 configuration.

Important:
- You must enter a working SOCKS5 server and port. This app does not invent or provide a public proxy.
- The VPN only protects traffic that Android routes through this VPN. It does not spoof IMEI, hardware MAC, serial number, or other hardware identifiers for other apps.
- It does not make websites magically un-fingerprintable. Browser-level anti-fingerprinting requires a separate hardened browser/WebView layer.
- Do not use this to evade account bans, fraud controls, or access restrictions.

Build:
1. Android Studio
2. JDK 17
3. Android SDK 35
4. Internet access for Gradle/Maven Central
5. Build `app` → debug APK

The generic ZIP-to-APK HTML converters still cannot add Android VpnService/native tun2socks functionality.

Upstream technical reference:
https://github.com/heiher/hev-socks5-tunnel
