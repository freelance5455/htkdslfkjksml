package com.noor.islamiccompanion;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;
import androidx.core.app.NotificationCompat;

public class NoorAdhanService extends Service {
    public static final String ACTION_PLAY="com.noor.islamiccompanion.PLAY_ADHAN", ACTION_STOP="com.noor.islamiccompanion.STOP_ADHAN";
    private static final String CHANNEL="noor_adhan_playback"; private static final int NOTIFICATION_ID=7201;
    private MediaPlayer player;
    @Override public void onCreate(){super.onCreate();createChannel();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"NOOR Adhan",NotificationManager.IMPORTANCE_HIGH);c.setDescription("Adhan playing at prayer time");c.setSound(null,null);c.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    private Notification makeNotification(String prayer){
        Intent stop=new Intent(this,NoorAdhanService.class).setAction(ACTION_STOP);
        PendingIntent dismiss=PendingIntent.getService(this,7202,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(getApplicationInfo().icon).setContentTitle("NOOR · It's time for "+prayer).setContentText(getSharedPreferences("noor_prayer",0).getBoolean("adhanEnabled",true)?"Adhan is playing · Swipe this notification away to stop":"Prayer time · Adhan audio is turned off").setCategory(NotificationCompat.CATEGORY_ALARM).setPriority(NotificationCompat.PRIORITY_MAX).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setDeleteIntent(dismiss).setOngoing(false).setAutoCancel(false).build();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null&&ACTION_STOP.equals(intent.getAction())){stopPlayback();stopForeground(true);stopSelf();return START_NOT_STICKY;}
        String prayer=intent==null?"Prayer":intent.getStringExtra("prayer");
        startForeground(NOTIFICATION_ID,makeNotification(prayer));
        stopPlayback();
        boolean adhanEnabled=getSharedPreferences("noor_prayer",0).getBoolean("adhanEnabled",true);
        if(!adhanEnabled){stopForeground(false);stopSelf();return START_NOT_STICKY;}
        try {
            android.content.res.AssetFileDescriptor afd=getAssets().openFd("noor_adhan.mp3");
            player=new MediaPlayer(); player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength()); afd.close();
            player.setOnCompletionListener(mp->{stopPlayback();stopForeground(true);stopSelf();}); player.setOnErrorListener((mp,what,extra)->{stopPlayback();stopForeground(true);stopSelf();return true;}); player.prepare(); player.start();
        } catch(Exception e){stopForeground(true);stopSelf();}
        return START_NOT_STICKY;
    }
    private void stopPlayback(){if(player!=null){try{if(player.isPlaying())player.stop();}catch(Exception ignored){}player.release();player=null;}}
    @Override public void onDestroy(){stopPlayback();super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
