$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$AndroidRoot = Join-Path $ProjectRoot 'android'
if (!(Test-Path $AndroidRoot)) { throw 'android/ folder not found. First run: npm install; npx cap add android' }
$JavaDest = Join-Path $AndroidRoot 'app/src/main/java/com/noor/islamiccompanion'
New-Item -ItemType Directory -Force -Path $JavaDest | Out-Null
Get-ChildItem -Path $PSScriptRoot -Filter '*.java' | Copy-Item -Destination $JavaDest -Force
$AssetDest = Join-Path $AndroidRoot 'app/src/main/assets'
New-Item -ItemType Directory -Force -Path $AssetDest | Out-Null
Copy-Item (Join-Path $ProjectRoot 'assets/audio/adhan.mp3') (Join-Path $AssetDest 'noor_adhan.mp3') -Force

$Manifest = Join-Path $AndroidRoot 'app/src/main/AndroidManifest.xml'
$xml = Get-Content $Manifest -Raw
$permissions = @(
'    <uses-permission android:name="android.permission.INTERNET" />',
'    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
'    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />',
'    <uses-permission android:name="android.permission.WAKE_LOCK" />',
'    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
'    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />',
'    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM" />'
)
foreach ($line in $permissions) { $token = [regex]::Escape($line.Trim()); if ($xml -notmatch $token) { $xml = $xml -replace '(?s)(<application\b)', ($line + "`r`n    `$1") } }
$components = @'
        <service android:name="com.noor.islamiccompanion.NoorAdhanService" android:exported="false" android:foregroundServiceType="mediaPlayback" />
        <receiver android:name="com.noor.islamiccompanion.NoorAlarmReceiver" android:enabled="true" android:exported="false" />
        <receiver android:name="com.noor.islamiccompanion.NoorBootReceiver" android:enabled="true" android:exported="false">
            <intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /><action android:name="android.intent.action.MY_PACKAGE_REPLACED" /></intent-filter>
        </receiver>
'@
if ($xml -notmatch 'NoorAdhanService') { $xml = $xml -replace '</application>', ($components + "`r`n    </application>") }
Set-Content -Path $Manifest -Value $xml -Encoding UTF8

$Gradle = Join-Path $AndroidRoot 'app/build.gradle'
if (!(Test-Path $Gradle)) { throw 'Expected app/build.gradle (Groovy) was not found. Open the project in Android Studio and add androidx.work:work-runtime:2.9.1 inside dependencies {} manually.' }
$g = Get-Content $Gradle -Raw
if ($g -notmatch 'androidx\.work:work-runtime') { $g = $g -replace 'dependencies\s*\{', "dependencies {`r`n    implementation 'androidx.work:work-runtime:2.9.1'" }
Set-Content -Path $Gradle -Value $g -Encoding UTF8

$Main = Get-ChildItem (Join-Path $AndroidRoot 'app/src/main/java') -Filter 'MainActivity.java' -Recurse | Select-Object -First 1
if (!$Main) { throw 'MainActivity.java not found. Register NoorAdhanPlugin manually in your Capacitor MainActivity.' }
$m = Get-Content $Main.FullName -Raw
if ($m -notmatch 'import com\.noor\.islamiccompanion\.NoorAdhanPlugin;') { $m = $m -replace '(package [^;]+;)', ('$1' + "`r`n`r`nimport com.noor.islamiccompanion.NoorAdhanPlugin;") }
if ($m -notmatch 'registerPlugin\(NoorAdhanPlugin\.class\)') {
  if ($m -match 'super\.onCreate\(savedInstanceState\);') { $m = $m -replace 'super\.onCreate\(savedInstanceState\);', "super.onCreate(savedInstanceState);`r`n        registerPlugin(NoorAdhanPlugin.class);" }
  else { $m = $m -replace '\}\s*$', "    @Override`r`n    public void onCreate(android.os.Bundle savedInstanceState) {`r`n        super.onCreate(savedInstanceState);`r`n        registerPlugin(NoorAdhanPlugin.class);`r`n    }`r`n}`r`n" }
}
Set-Content -Path $Main.FullName -Value $m -Encoding UTF8
Write-Host 'NOOR native Adhan files installed. Next run: npm run build; npx cap sync android; then build the APK in Android Studio.' -ForegroundColor Green
