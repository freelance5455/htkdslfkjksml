# NOOR native Adhan integration (Android)

This folder contains Android-native code for the exact alarm + full Adhan playback + swipe-to-stop behavior. It is intended for the Capacitor Android project, **not** for AppMint or a generic HTML-to-APK converter.

## What it adds
- Android AlarmManager prayer alarms.
- A foreground media-playback service that plays the bundled `assets/audio/adhan.mp3`.
- A notification with a delete intent: dismissing/swiping it sends STOP to the playback service.
- Daily refresh from AlAdhan for the configured city/country/method/school.
- Re-scheduling after reboot or app update.
- Exact-alarm permission screen on Android 12+ (if the OS requires it).

## Install into the Capacitor Android project (mostly automatic)
1. On Windows, install Node.js 20+ and Android Studio.
2. In the NOOR project folder run `npm install`, then `npx cap add android` (only if `android/` does not exist).
3. Open PowerShell in the NOOR folder and run:
   `powershell -ExecutionPolicy Bypass -File .\native-android\install-native.ps1`
4. Run `npm run build`, then `npx cap sync android`, then open the `android/` folder in Android Studio and build the APK.

The installer copies the Java files and Adhan audio, merges Android permissions/components, adds WorkManager, and registers the Capacitor plugin. It expects the default package id `com.noor.islamiccompanion` and the standard Capacitor Groovy `app/build.gradle` file. If your generated project differs, the installer stops and the remaining changes can be made manually using `AndroidManifest_additions.xml` and the source files in this folder.

## Device setup
- Open NOOR, enable Prayer notifications and switch on Built-in Adhan audio. The two settings are independent.
- Allow Android notifications.
- When NOOR asks for exact alarm access, allow Alarms & reminders for NOOR.
- Do not restrict NOOR's battery use if the phone's manufacturer aggressively limits background apps.

## Important limits
- This source patch has not been compiled or tested on a physical Samsung phone in this environment. Test Fajr/other alarms using a temporary near-future test time before relying on it.
- Exact alarm access can be denied by Android or restricted by device policy. In that case Android uses an inexact fallback; timing may be delayed.
- Daily recalculation needs internet access. If the daily AlAdhan refresh fails, it retries after 30 minutes; already scheduled alarms remain in place.
- The Java package assumes the app id `com.noor.islamiccompanion`. If you change the app id/package, update the package declarations and file paths consistently.
