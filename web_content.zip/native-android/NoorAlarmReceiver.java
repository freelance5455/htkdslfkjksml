package com.noor.islamiccompanion;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class NoorAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String action=intent==null?"":intent.getAction();
        if (NoorAlarmScheduler.ACTION_PRAYER.equals(action)) {
            String prayer=intent.getStringExtra("prayer");
            Intent service=new Intent(context,NoorAdhanService.class).setAction(NoorAdhanService.ACTION_PLAY).putExtra("prayer",prayer);
            if(android.os.Build.VERSION.SDK_INT>=26) context.startForegroundService(service); else context.startService(service);
        } else if (NoorAlarmScheduler.ACTION_REFRESH.equals(action)) {
            WorkManager.getInstance(context).enqueue(new OneTimeWorkRequest.Builder(PrayerRefreshWorker.class).build());
        }
    }
}
