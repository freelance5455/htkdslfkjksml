package com.noor.islamiccompanion;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class PrayerRefreshWorker extends Worker {
    public PrayerRefreshWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
    @NonNull @Override public Result doWork(){
        Context c=getApplicationContext(); SharedPreferences prefs=c.getSharedPreferences("noor_prayer",0);
        if(!prefs.getBoolean("enabled",true))return Result.success();
        try {
            String city=prefs.getString("city","Riyadh"), country=prefs.getString("country","Saudi Arabia"); int method=prefs.getInt("method",4),school=prefs.getInt("school",0);
            String date=new SimpleDateFormat("dd-MM-yyyy",Locale.US).format(new Date());
            String url="https://api.aladhan.com/v1/timingsByCity/"+date+"?city="+URLEncoder.encode(city,"UTF-8")+"&country="+URLEncoder.encode(country,"UTF-8")+"&method="+method+"&school="+school;
            HttpURLConnection conn=(HttpURLConnection)new URL(url).openConnection();conn.setConnectTimeout(12000);conn.setReadTimeout(12000);conn.setRequestProperty("User-Agent","NOOR-Android");
            ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=conn.getInputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))>0)out.write(b,0,n);}conn.disconnect();
            JSONObject root=new JSONObject(out.toString("UTF-8"));JSONObject timings=root.getJSONObject("data").getJSONObject("timings");
            String[] names={"Fajr","Dhuhr","Asr","Maghrib","Isha"}; java.text.SimpleDateFormat tf=new java.text.SimpleDateFormat("HH:mm",Locale.US);tf.setTimeZone(TimeZone.getDefault());
            for(String name:names){String value=timings.getString(name).split(" ")[0];Date parsed=tf.parse(value);Calendar cal=Calendar.getInstance();cal.setTime(new Date());Calendar t=Calendar.getInstance();t.setTime(parsed);cal.set(Calendar.HOUR_OF_DAY,t.get(Calendar.HOUR_OF_DAY));cal.set(Calendar.MINUTE,t.get(Calendar.MINUTE));cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);if(cal.getTimeInMillis()>System.currentTimeMillis()+1000)NoorAlarmScheduler.schedulePrayer(c,name,cal.getTimeInMillis());}
            Calendar next=Calendar.getInstance();next.add(Calendar.DAY_OF_YEAR,1);next.set(Calendar.HOUR_OF_DAY,0);next.set(Calendar.MINUTE,5);next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);NoorAlarmScheduler.scheduleRefresh(c,next.getTimeInMillis());
            return Result.success();
        }catch(Exception e){NoorAlarmScheduler.scheduleRefresh(c,System.currentTimeMillis()+30*60*1000L);return Result.retry();}
    }
}
