package com.noor.islamiccompanion;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import org.json.JSONArray;
import org.json.JSONObject;

@CapacitorPlugin(name = "NoorAdhan", permissions = {
    @Permission(alias = "notifications", strings = { android.Manifest.permission.POST_NOTIFICATIONS })
})
public class NoorAdhanPlugin extends Plugin {
    @PluginMethod public void requestNotificationPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT < 33) { JSObject r = new JSObject(); r.put("granted", true); call.resolve(r); return; }
        if (getPermissionState("notifications") == PermissionState.GRANTED) { JSObject r = new JSObject(); r.put("granted", true); call.resolve(r); return; }
        requestPermissionForAlias("notifications", call, "notificationPermissionResult");
    }
    @PermissionCallback private void notificationPermissionResult(PluginCall call) {
        JSObject r = new JSObject(); r.put("granted", getPermissionState("notifications") == PermissionState.GRANTED); call.resolve(r);
    }
    @PluginMethod public void checkNotificationPermission(PluginCall call) {
        JSObject r = new JSObject(); r.put("granted", Build.VERSION.SDK_INT < 33 || getPermissionState("notifications") == PermissionState.GRANTED); call.resolve(r);
    }
    @PluginMethod public void requestExactAlarmPermission(PluginCall call) {
        if (Build.VERSION.SDK_INT >= 31 && !getContext().getSystemService(android.app.AlarmManager.class).canScheduleExactAlarms()) {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + getContext().getPackageName()));
            getActivity().startActivity(i);
        }
        call.resolve();
    }
    @PluginMethod public void schedulePrayerAlarms(PluginCall call) {
        String city = call.getString("city", "Riyadh"), country = call.getString("country", "Saudi Arabia");
        int method = call.getInt("method", 4), school = call.getInt("school", 0);
        android.content.SharedPreferences p = getContext().getSharedPreferences("noor_prayer", 0);
        p.edit().putString("city", city).putString("country", country).putInt("method", method).putInt("school", school).putBoolean("enabled", true).putBoolean("adhanEnabled", call.getBoolean("playAdhan", true)).apply();
        JSONArray prayers = call.getArray("prayers");
        int scheduled = 0;
        if (prayers != null) for (int i=0;i<prayers.length();i++) try {
            JSONObject item = prayers.getJSONObject(i); String name=item.getString("name"); long at=item.getLong("at");
            if (at > System.currentTimeMillis()) { NoorAlarmScheduler.schedulePrayer(getContext(), name, at); scheduled++; }
        } catch (Exception ignored) {}
        NoorAlarmScheduler.scheduleRefresh(getContext(), System.currentTimeMillis()+60_000L);
        JSObject r = new JSObject(); r.put("scheduled", scheduled); r.put("exactAlarmAllowed", Build.VERSION.SDK_INT < 31 || getContext().getSystemService(android.app.AlarmManager.class).canScheduleExactAlarms()); call.resolve(r);
    }
    @PluginMethod public void setAdhanEnabled(PluginCall call) {
        boolean enabled=call.getBoolean("enabled", true);
        getContext().getSharedPreferences("noor_prayer",0).edit().putBoolean("adhanEnabled",enabled).apply();
        call.resolve();
    }
    @PluginMethod public void cancelPrayerAlarms(PluginCall call) {
        getContext().getSharedPreferences("noor_prayer",0).edit().putBoolean("enabled",false).apply();
        NoorAlarmScheduler.cancelAll(getContext()); call.resolve();
    }
    @PluginMethod public void stopAdhan(PluginCall call) {
        Intent i = new Intent(getContext(), NoorAdhanService.class); i.setAction(NoorAdhanService.ACTION_STOP); getContext().startService(i); call.resolve();
    }
}
