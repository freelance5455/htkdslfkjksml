plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.privacyshield.suite"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.privacyshield.suite"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // Native TUN -> SOCKS5 packet engine (Maven Central)
    implementation("com.wgtunnel:hevtunnel:1.7.6")
}
