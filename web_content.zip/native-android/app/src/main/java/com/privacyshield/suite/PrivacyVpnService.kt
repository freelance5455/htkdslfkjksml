package com.privacyshield.suite

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import hev.htproxy.TProxyService
import java.io.File

class PrivacyVpnService : VpnService() {
    private var vpn: ParcelFileDescriptor? = null
    private var configFile: File? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val host = getSharedPreferences("privacy", MODE_PRIVATE)
            .getString("socks_host", "") ?: ""
        val port = getSharedPreferences("privacy", MODE_PRIVATE)
            .getInt("socks_port", 1080)

        if (host.isBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            TProxyService.TProxyStopService()
            vpn?.close()

            vpn = Builder()
                .setSession("Privacy Shield")
                .setMtu(1500)
                .addAddress("198.18.0.1", 15)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer("1.1.1.1")
                .addDnsServer("9.9.9.9")
                .establish()

            val fd = vpn?.fileDescriptor ?: throw IllegalStateException("TUN unavailable")

            val cfg = buildString {
                appendLine("tunnel:")
                appendLine("  name: tun0")
                appendLine("  mtu: 1500")
                appendLine("  ipv4: 198.18.0.1")
                appendLine("  icmp: 'off'")
                appendLine("socks5:")
                appendLine("  address: $host")
                appendLine("  port: $port")
                appendLine("  udp: 'udp'")
                appendLine("misc:")
                appendLine("  log-level: error")
            }

            configFile = File(filesDir, "hev-tun.yml").also {
                it.writeText(cfg)
            }

            if (!TProxyService.TProxyStartService(configFile!!.absolutePath, fd)) {
                throw IllegalStateException("tun2socks engine failed to start")
            }
        } catch (_: Exception) {
            try { TProxyService.TProxyStopService() } catch (_: Exception) {}
            try { vpn?.close() } catch (_: Exception) {}
            vpn = null
            stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { TProxyService.TProxyStopService() } catch (_: Exception) {}
        try { vpn?.close() } catch (_: Exception) {}
        vpn = null
        super.onDestroy()
    }
}
