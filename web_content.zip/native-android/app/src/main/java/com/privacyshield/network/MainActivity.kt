package com.privacyshield.network
import android.app.Activity
import android.content.*
import android.net.VpnService
import android.os.Bundle
import android.widget.*
class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val p=getSharedPreferences("ps",0)
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(40,40,40,40)}
  fun et(h:String,v:String)=EditText(this).apply{hint=h;setText(v)}
  val host=et("SOCKS5 host",p.getString("host","")!!);val port=et("SOCKS5 port",p.getInt("port",1080).toString());val dns=et("DNS",p.getString("dns","1.1.1.1")!!)
  val s=TextView(this)
  fun show(){s.text="Status: "+p.getString("state","OFF")}
  fun save(){p.edit().putString("host",host.text.toString()).putInt("port",port.text.toString().toIntOrNull()?:1080).putString("dns",dns.text.toString()).apply()}
  fun btn(t:String,a:()->Unit)=Button(this).apply{text=t;setOnClickListener{save();a();show()}}
  l.addView(host);l.addView(port);l.addView(dns)
  l.addView(btn("Save + grant VPN permission"){VpnService.prepare(this@MainActivity)?.let{startActivityForResult(it,1)}})
  l.addView(btn("Start VPN"){sendBroadcast(Intent("com.privacyshield.PRIVACY_ON").setComponent(ComponentName(packageName,"$packageName.ControlReceiver")),"com.privacyshield.permission.CONTROL")})
  l.addView(btn("Stop VPN"){sendBroadcast(Intent("com.privacyshield.PRIVACY_OFF").setComponent(ComponentName(packageName,"$packageName.ControlReceiver")),"com.privacyshield.permission.CONTROL")})
  l.addView(s);l.addView(TextView(this).apply{text="No tun2socks engine is bundled. Until one is integrated, status shows ENGINE_MISSING and no traffic is touched."})
  setContentView(l);show()}
}
