package com.privacyshield.browser
import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.widget.*
class MainActivity:Activity(){
 lateinit var wv:WebView
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val p=getSharedPreferences("ps",0)
  wv=WebView(this);val s=wv.settings
  s.javaScriptEnabled=p.getBoolean("js",true);s.cacheMode=WebSettings.LOAD_NO_CACHE;s.allowFileAccess=false;s.allowContentAccess=false
  s.saveFormData=false;s.setGeolocationEnabled(false);s.userAgentString="Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36"
  CookieManager.getInstance().setAcceptThirdPartyCookies(wv,false);wv.webViewClient=WebViewClient()
  val l=android.widget.LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val url=EditText(this).apply{hint="https://";setSingleLine()}
  val go=Button(this).apply{text="Go";setOnClickListener{wv.loadUrl(url.text.toString().let{if(it.startsWith("http"))it else "https://$it"})}}
  val clr=Button(this).apply{text="Clear Session";setOnClickListener{ControlReceiver.clear();wv.clearCache(true);wv.clearHistory();Toast.makeText(context,"Cleared",Toast.LENGTH_SHORT).show()}}
  val js=Switch(this).apply{text="JavaScript";isChecked=s.javaScriptEnabled;setOnCheckedChangeListener{_,v->p.edit().putBoolean("js",v).apply();s.javaScriptEnabled=v}}
  val audit=TextView(this).apply{text="Guard audit: cookies 3rd-party=OFF | cache=OFF | file access=OFF | JS=${s.javaScriptEnabled} | geolocation=OFF\nLimits: WebView cannot block canvas/WebGL/audio fingerprinting or fully stop WebRTC IP leaks. Not 100% anonymous."}
  l.addView(url);l.addView(go);l.addView(clr);l.addView(js);l.addView(audit);l.addView(wv,-1,0).also{(wv.layoutParams as LinearLayout.LayoutParams).weight=1f}
  setContentView(l)}
 override fun onDestroy(){super.onDestroy();if(getSharedPreferences("ps",0).getBoolean("private",false))ControlReceiver.clear()}
}
