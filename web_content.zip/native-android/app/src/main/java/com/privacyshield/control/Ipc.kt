package com.privacyshield.control
import android.content.*
object Ipc{
 const val PERM="com.privacyshield.permission.CONTROL"
 fun send(c:Context,action:String,pkg:String)=c.sendBroadcast(Intent(action).setComponent(ComponentName(pkg,pkg+".ControlReceiver")),PERM)
}
