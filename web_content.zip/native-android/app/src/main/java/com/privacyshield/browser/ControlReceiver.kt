package com.privacyshield.browser
import android.content.*
import android.webkit.*
class ControlReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
  val p=c.getSharedPreferences("ps",0)
  when(i.action){
   "com.privacyshield.PRIVACY_ON"->p.edit().putBoolean("private",true).putBoolean("guard",true).apply()
   "com.privacyshield.PRIVACY_OFF"->{p.edit().putBoolean("private",false).putBoolean("guard",false).apply();clear()}}
  fun s(b:Boolean)=if(b)"ON" else "OFF"
  c.sendBroadcast(Intent("com.privacyshield.STATUS_RESPONSE").setPackage("com.privacyshield.control").putExtra("component","browser").putExtra("state",s(p.getBoolean("private",false))).putExtra("guard",s(p.getBoolean("guard",false))),"com.privacyshield.permission.CONTROL")}
 companion object{fun clear(){CookieManager.getInstance().removeAllCookies(null);CookieManager.getInstance().flush();WebStorage.getInstance().deleteAllData()}}}
