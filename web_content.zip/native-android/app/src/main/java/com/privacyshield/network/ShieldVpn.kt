package com.privacyshield.network
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
/** Plug a mature tun2socks engine (e.g. hev-socks5-tunnel JNI) here. NONE is bundled: no fake VPN. */
interface TunEngine{fun start(tunFd:Int,host:String,port:Int,svc:VpnService);fun stop()}
object Engines{var engine:TunEngine?=null}
class ShieldVpn:VpnService(){
 var tun:ParcelFileDescriptor?=null
 fun set(s:String)=getSharedPreferences("ps",0).edit().putString("state",s).apply()
 fun halt(s:String){Engines.engine?.stop();tun?.close();tun=null;set(s);stopSelf()}
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  if(i?.action=="STOP"){halt("OFF");return START_NOT_STICKY}
  val p=getSharedPreferences("ps",0);val host=p.getString("host","")?:"";val port=p.getInt("port",1080)
  val e=Engines.engine
  if(host.isBlank()){halt("ERROR: SOCKS5 host not set");return START_NOT_STICKY}
  if(e==null){halt("ENGINE_MISSING (tun2socks not integrated)");return START_NOT_STICKY}
  try{tun=Builder().setSession("Privacy Shield").setMtu(1500).addAddress("10.255.0.2",32).addAddress("fd00::2",128)
    .addRoute("0.0.0.0",0).addRoute("::",0).addDnsServer(p.getString("dns","1.1.1.1")?:"1.1.1.1").addDisallowedApplication(packageName).establish()
   e.start(tun!!.fd,host,port,this);set("ON")}catch(x:Exception){halt("ERROR: "+x.javaClass.simpleName)}
  return START_NOT_STICKY}
 override fun onRevoke(){halt("DISCONNECTED (revoked by system)")}
}
