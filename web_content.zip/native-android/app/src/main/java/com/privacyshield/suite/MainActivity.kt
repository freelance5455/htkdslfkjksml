package com.privacyshield.suite

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var master: Switch
    private lateinit var host: EditText
    private lateinit var port: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("privacy", MODE_PRIVATE)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }

        val title = TextView(this).apply {
            text = "Privacy Shield"
            textSize = 30f
        }
        status = TextView(this).apply { textSize = 16f }

        host = EditText(this).apply {
            hint = "SOCKS5 server host/IP"
            setText(prefs.getString("socks_host", ""))
        }
        port = EditText(this).apply {
            hint = "SOCKS5 port"
            inputType = 2
            setText(prefs.getInt("socks_port", 1080).toString())
        }

        val save = Button(this).apply {
            text = "Save proxy"
            setOnClickListener {
                val p = port.text.toString().toIntOrNull() ?: 1080
                prefs.edit().putString("socks_host", host.text.toString().trim())
                    .putInt("socks_port", p).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }

        master = Switch(this).apply {
            text = "Master Privacy Switch"
            textSize = 18f
            setOnCheckedChangeListener { _, checked ->
                if (checked) startPrivacy() else {
                    stopService(Intent(this@MainActivity, PrivacyVpnService::class.java))
                    updateStatus(false)
                }
            }
        }

        val audit = TextView(this).apply {
            text = "Protection path\nDevice apps → Android TUN → tun2socks → your SOCKS5 server\n\nLocal privacy: no IMEI/serial/location/installed-app collection."
            setPadding(0, 25, 0, 0)
        }

        box.addView(title)
        box.addView(status)
        box.addView(host)
        box.addView(port)
        box.addView(save)
        box.addView(master)
        box.addView(audit)
        setContentView(box)
        updateStatus(false)
    }

    private fun startPrivacy() {
        if (host.text.toString().trim().isBlank()) {
            Toast.makeText(this, "Enter a SOCKS5 server first", Toast.LENGTH_LONG).show()
            master.isChecked = false
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) startActivityForResult(prepare, 1001)
        else startService(Intent(this, PrivacyVpnService::class.java))
        updateStatus(true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == Activity.RESULT_OK) {
            startService(Intent(this, PrivacyVpnService::class.java))
        } else if (requestCode == 1001) {
            master.isChecked = false
        }
    }

    private fun updateStatus(on: Boolean) {
        status.text = if (on) "Protection switch: ON" else "Protection switch: OFF"
    }
}
