package com.privacyshield.network
import android.content.*
import android.net.VpnService
class ControlReceiver:BroadcastReceiver(){
 override fun onReceive(c:Context,i:Intent){
  val p=c.getSharedPreferences("ps",0)
  when(i.action){
   "com.privacyshield.PRIVACY_ON"->if(VpnService.prepare(c)==null)c.startService(Intent(c,ShieldVpn::class.java)) else p.edit().putString("state","NEEDS_PERMISSION (open Network app)").apply()
   "com.privacyshield.PRIVACY_OFF"->c.startService(Intent(c,ShieldVpn::class.java).setAction("STOP"))}
  c.sendBroadcast(Intent("com.privacyshield.STATUS_RESPONSE").setPackage("com.privacyshield.control").putExtra("component","network").putExtra("state",p.getString("state","OFF")),"com.privacyshield.permission.CONTROL")}}
