package com.privacyshield.control
import android.app.Activity
import android.content.*
import android.os.*
import android.view.Gravity
import android.widget.*
class MainActivity:Activity(){
 val apps=linkedMapOf("network" to "com.privacyshield.network","browser" to "com.privacyshield.browser")
 val st=hashMapOf<String,String>()
 lateinit var out:TextView; lateinit var btn:Button
 val h=Handler(Looper.getMainLooper())
 val rx=object:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){
  st[i.getStringExtra("component")?:return]=i.getStringExtra("state")?:"?"
  if(i.getStringExtra("component")=="browser") st["guard"]=i.getStringExtra("guard")?:"?"; render()}}
 fun installed(p:String)=try{packageManager.getPackageInfo(p,0);true}catch(e:Exception){false}
 fun on()=apps.keys.all{st[it]=="ON"}
 fun render(){
  fun f(k:String,n:String)="$n: "+(if(!installed(apps[k]?:"com.privacyshield.browser"))"🔴 NOT INSTALLED" else when(val s=st[if(k=="guard")"guard" else k]){"ON"->"🟢 ON";null->"⚪ ..." ;else->"🔴 $s"})
  out.text=listOf(f("network","Network VPN"),f("browser","Private Browser"),f("guard","Privacy Guard")).joinToString("\n")
  btn.text=if(on())"STOP PROTECTION" else "🛡️ PROTECT DEVICE"}
 fun cmd(a:String){apps.values.filter{installed(it)}.forEach{Ipc.send(this,"com.privacyshield.$a",it)}}
 val poll=object:Runnable{override fun run(){cmd("STATUS_REQUEST");render();h.postDelayed(this,2000)}}
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(40,40,40,40);setBackgroundColor(0xFF0A1218.toInt())}
  out=TextView(this).apply{textSize=18f;setTextColor(0xFFD8F5EE.toInt())}
  btn=Button(this).apply{textSize=22f;setOnClickListener{cmd(if(on())"PRIVACY_OFF" else "PRIVACY_ON")
   val miss=apps.values.filter{!installed(it)};if(miss.isNotEmpty())Toast.makeText(context,"Missing: "+miss.joinToString(),Toast.LENGTH_LONG).show()}}
  val vpn=Button(this).apply{text="Grant VPN permission (first time)";setOnClickListener{
   try{startActivity(Intent().setClassName("com.privacyshield.network","com.privacyshield.network.MainActivity"))}catch(e:Exception){Toast.makeText(context,"Network app NOT INSTALLED",Toast.LENGTH_SHORT).show()}}}
  l.addView(btn);l.addView(out);l.addView(vpn);setContentView(l);render()}
 override fun onStart(){super.onStart()
  val f=IntentFilter("com.privacyshield.STATUS_RESPONSE")
  if(Build.VERSION.SDK_INT>=33)registerReceiver(rx,f,Ipc.PERM,null,Context.RECEIVER_EXPORTED) else registerReceiver(rx,f,Ipc.PERM,null)
  h.post(poll)}
 override fun onStop(){super.onStop();h.removeCallbacks(poll);unregisterReceiver(rx)}
}
