package com.noor.islamiccompanion;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class NoorAlarmScheduler {
    static final String ACTION_PRAYER = "com.noor.islamiccompanion.PRAYER_ALARM";
    static final String ACTION_REFRESH = "com.noor.islamiccompanion.PRAYER_REFRESH";
    static int idFor(String name) { return 100 + Math.abs(name.toLowerCase().hashCode() % 8000); }
    static PendingIntent prayerIntent(Context c, String name) {
        Intent i=new Intent(c, NoorAlarmReceiver.class).setAction(ACTION_PRAYER).putExtra("prayer",name);
        return PendingIntent.getBroadcast(c,idFor(name),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedulePrayer(Context c,String name,long at) {
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); PendingIntent pi=prayerIntent(c,name);
        if (Build.VERSION.SDK_INT>=23) {
            if (Build.VERSION.SDK_INT>=31 && !a.canScheduleExactAlarms()) a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else a.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
        } else a.setExact(AlarmManager.RTC_WAKEUP,at,pi);
    }
    public static void scheduleRefresh(Context c,long at) {
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent i=new Intent(c,NoorAlarmReceiver.class).setAction(ACTION_REFRESH);
        PendingIntent pi=PendingIntent.getBroadcast(c,9901,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        if(Build.VERSION.SDK_INT>=23) a.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi); else a.set(AlarmManager.RTC_WAKEUP,at,pi);
    }
    public static void cancelAll(Context c) {
        AlarmManager a=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        for(String n:new String[]{"Fajr","Dhuhr","Asr","Maghrib","Isha"}) a.cancel(prayerIntent(c,n));
        Intent i=new Intent(c,NoorAlarmReceiver.class).setAction(ACTION_REFRESH);
        PendingIntent pi=PendingIntent.getBroadcast(c,9901,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); a.cancel(pi);
    }
}
