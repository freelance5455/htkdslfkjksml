package com.noor.islamiccompanion;
import android.content.BroadcastReceiver;import android.content.Context;import android.content.Intent;import androidx.work.OneTimeWorkRequest;import androidx.work.WorkManager;
public class NoorBootReceiver extends BroadcastReceiver {@Override public void onReceive(Context c,Intent i){if(i!=null&&(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())||"android.intent.action.MY_PACKAGE_REPLACED".equals(i.getAction()))){WorkManager.getInstance(c).enqueue(new OneTimeWorkRequest.Builder(PrayerRefreshWorker.class).build());}}}
