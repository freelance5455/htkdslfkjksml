
    const API_OVERRIDE = '';
    const API = (API_OVERRIDE || (location.protocol.startsWith('http') ? location.origin : 'http://127.0.0.1:3000')).replace(/\/$/, '');
    // Keep administrator and viewer sessions separate so both roles can stay signed in in one browser.
    let token = localStorage.getItem('cg_admin_token') || '';

    async function api(path, opts = {}) {
      const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
      if (token) headers['Authorization'] = 'Bearer ' + token;
      let res;
      try {
        res = await fetch(API + path, Object.assign({}, opts, { headers }));
      } catch (e) {
        throw new Error('اتصال به سرور برقرار نشد. server.py را اجرا کنید. آدرس: ' + API);
      }
      const text = await res.text();
      let data = {};
      try { data = text ? JSON.parse(text) : {}; } catch { data = { error: text || 'پاسخ نامعتبر' }; }
      if (!res.ok) throw new Error(data.error || data.message || ('خطا ' + res.status));
      return data;
    }

    function showTab(name) {
      ['movies', 'add-movie', 'series', 'add-series', 'support', 'reports', 'users', 'audit'].forEach(t => {
        document.getElementById('tab-' + t).classList.toggle('hidden', t !== name);
      });
      if (name === 'movies') loadMovies();
      if (name === 'series') loadSeries();
      if (name === 'support') loadSupportAdmin();
      if (name === 'reports') loadReportsAdmin();
      if (name === 'users') loadAdminUsers();
      if (name === 'audit') loadAdminAudit();
    }

    async function login() {
      const msg = document.getElementById('loginMsg');
      msg.innerHTML = '';
      try {
        const data = await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            username: document.getElementById('username').value,
            password: document.getElementById('password').value
          })
        });
        if (data.user.role !== 'admin') throw new Error('فقط مدیر مجاز است');
        token = data.token;
        localStorage.setItem('cg_admin_token', token);
        document.getElementById('loginBox').classList.add('hidden');
        document.getElementById('adminBox').classList.remove('hidden');
        document.getElementById('userInfo').textContent = data.user.username;
        showTab('movies');
      } catch (e) {
        msg.innerHTML = '<div class="msg err">' + e.message + '</div>';
      }
    }

    async function logout() {
      try { if (token) await api('/api/auth/logout', {method:'POST'}); } catch (_) {}
      token = '';
      localStorage.removeItem('cg_admin_token');
      location.reload();
    }

    async function loadMovies() {
      const el = document.getElementById('moviesList');
      try {
        const movies = await api('/api/movies');
        if (!movies.length) { el.textContent = 'فیلمی ثبت نشده'; return; }
        el.innerHTML = '<table><tr><th>عنوان</th><th>امتیاز</th><th>بازدید</th><th>سال</th><th></th></tr>' +
          movies.map(m => `<tr>
            <td>${esc(m.title)}</td>
            <td>${m.rating_avg}</td>
            <td>${m.view_count}</td>
            <td>${m.year || ''}</td>
            <td><button class="small secondary" onclick="editMovie(${m.id})">ویرایش</button><button class="danger" onclick="deleteMovie(${m.id})">بایگانی</button></td>
          </tr>`).join('') + '</table>';
      } catch (e) {
        el.innerHTML = '<div class="msg err">' + e.message + '</div>';
      }
    }

    function chooseLocalFile(accept) {
      return new Promise(resolve => {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = accept; input.style.display = 'none';
        let settled = false;
        const finish = file => { if (settled) return; settled = true; input.remove(); resolve(file || null); };
        input.addEventListener('change', () => finish(input.files && input.files[0]));
        input.addEventListener('cancel', () => finish(null));
        document.body.appendChild(input); input.click();
      });
    }

    async function uploadReplacement(kind, accept, confirmFirst = true) {
      const labels = {video:'فایل ویدیوی فعلی', hls_bundle:'بسته HLS فعلی', subtitle:'زیرنویس فعلی', poster:'پوستر فعلی'};
      if (confirmFirst && !confirm((labels[kind] || 'فایل فعلی') + ' با فایل جدید جایگزین شود؟')) return null;
      const file = await chooseLocalFile(accept);
      if (!file) return null;
      const id = 'replace_' + kind + '_' + Date.now();
      const status = document.createElement('div'); status.className = 'upload-status'; status.textContent = 'آماده‌سازی آپلود...';
      const progress = document.createElement('span'); progress.style.cssText = 'display:block;height:7px;width:0;background:linear-gradient(90deg,#b98b43,#f0d38d);border-radius:99px';
      const track = document.createElement('div'); track.className = 'upload-progress'; track.appendChild(progress);
      const box = document.createElement('div'); box.className = 'upload-field'; box.append(status, track); document.body.appendChild(box);
      try { return await uploadInChunks(file, kind, status, progress); }
      finally { setTimeout(() => box.remove(), 1800); }
    }

    async function editMovie(id) {
      try {
        const m = await api('/api/movies/' + id);
        const title = prompt('عنوان فیلم', m.title || ''); if (title === null) return;
        const description = prompt('توضیحات', m.description || ''); if (description === null) return;
        const genre = prompt('ژانر', m.genre || 'عمومی'); if (genre === null) return;
        const subtitle_url = prompt('لینک زیرنویس (اختیاری)', m.subtitle_url || ''); if (subtitle_url === null) return;
        const qualityText = prompt('گزینه‌های کیفیت به‌صورت JSON', JSON.stringify(m.quality_options || []));
        if (qualityText === null) return;
        const quality_options = JSON.parse(qualityText);
        let poster_url = m.poster_url || '', video_url = m.video_url || '';
        const newPoster = await uploadReplacement('poster', 'image/*,.jpg,.jpeg,.png,.webp,.gif');
        if (newPoster) poster_url = newPoster;
        const newVideo = await uploadReplacement('video', 'video/*,.mp4,.m4v,.mov,.webm,.mkv,.ts');
        const newHls = (newVideo || !confirm('آیا می‌خواهید ویدیو را با بسته HLS جایگزین کنید؟')) ? null : await uploadReplacement('hls_bundle', '.zip,application/zip', false);
        if (newVideo && newHls) throw new Error('فقط یک نوع ویدیو قابل جایگزینی است');
        if (newVideo) video_url = newVideo;
        if (newHls) video_url = newHls;
        const newSubtitle = confirm('آیا می‌خواهید فایل زیرنویس را هم جایگزین کنید؟') ? await uploadReplacement('subtitle', '.srt,.vtt', false) : null;
        if (newSubtitle) subtitle_url = newSubtitle;
        await api('/api/admin/movies/' + id, {method:'PATCH', body:JSON.stringify({title,description,poster_url,video_url,subtitle_url:subtitle_url || null,genre,quality_options})});
        loadMovies(); alert('اطلاعات فیلم به‌روزرسانی شد.');
      } catch (e) { alert('ویرایش انجام نشد: ' + e.message); }
    }

    async function editSeries(id) {
      try {
        const s = await api('/api/series/' + id);
        const title = prompt('عنوان سریال', s.title || ''); if (title === null) return;
        const description = prompt('توضیحات', s.description || ''); if (description === null) return;
        const genre = prompt('ژانر', s.genre || 'عمومی'); if (genre === null) return;
        const audioText = prompt('فهرست دوبله/صدا به‌صورت JSON', JSON.stringify(s.audio_tracks || [])); if (audioText === null) return;
        const subtitleText = prompt('فهرست زیرنویس‌ها به‌صورت JSON', JSON.stringify(s.subtitle_tracks || [])); if (subtitleText === null) return;
        let poster_url = s.poster_url || '';
        const newPoster = await uploadReplacement('poster', 'image/*,.jpg,.jpeg,.png,.webp,.gif');
        if (newPoster) poster_url = newPoster;
        await api('/api/admin/series/' + id, {method:'PATCH', body:JSON.stringify({title,description,poster_url,genre,audio_tracks:JSON.parse(audioText),subtitle_tracks:JSON.parse(subtitleText)})});
        loadSeries(); alert('اطلاعات سریال به‌روزرسانی شد.');
      } catch (e) { alert('ویرایش انجام نشد: ' + e.message); }
    }

    async function deleteMovie(id) {
      if (!confirm('حذف این فیلم؟')) return;
      try {
        await api('/api/movies/' + id, { method: 'DELETE' });
        loadMovies();
      } catch (e) { alert(e.message); }
    }

    function previewPoster(input, previewId) {
      const file = input.files && input.files[0]; if (!file) return;
      const img = document.getElementById(previewId); img.src = URL.createObjectURL(file); img.style.display = 'block';
    }
    async function uploadInChunks(file, kind, statusId, progressId) {
      const status = typeof statusId === 'string' ? document.getElementById(statusId) : statusId, bar = typeof progressId === 'string' ? document.getElementById(progressId) : progressId;
      if (!file) return null;
      const resumeKey='cg_upload_'+kind+'_'+file.name+'_'+file.size+'_'+file.lastModified;
      let uploadId=localStorage.getItem(resumeKey), init, statusInfo;
      if(uploadId){
        try { statusInfo=await api('/api/admin/uploads/'+uploadId+'/status'); if(statusInfo.name!==file.name||statusInfo.size!==file.size) throw new Error('file mismatch'); init={upload_id:uploadId,chunk_size:4*1024*1024,chunks:statusInfo.chunks}; }
        catch { localStorage.removeItem(resumeKey); uploadId=null; }
      }
      if(!uploadId){ init=await api('/api/admin/uploads/init', {method:'POST', body:JSON.stringify({name:file.name,size:file.size,kind})}); uploadId=init.upload_id; localStorage.setItem(resumeKey,uploadId); statusInfo={received:[]}; }
      const chunkSize = init.chunk_size; let sent = 0;
      try {
        for (let i=0;i<init.chunks;i++) {
          const start=i*chunkSize, end=Math.min(file.size,start+chunkSize), chunk=file.slice(start,end);
          // Android document providers can expose a temporary content URI.
          // Reading the Blob into ArrayBuffer here may throw NotReadableError
          // even though the browser can stream the Blob in fetch(). The server
          // computes and verifies SHA-256 for every received chunk, so avoid a
          // second client-side read and upload the Blob directly.
          const chunkHashHex = '';
          if((statusInfo.received||[]).includes(i) && (!chunkHashHex || (statusInfo.chunk_hashes && statusInfo.chunk_hashes[String(i)]===chunkHashHex))){
            sent += chunk.size; bar.style.width=Math.round(sent/file.size*100)+'%'; continue;
          }
          let response;
          for (let attempt=0;attempt<3;attempt++) {
            try {
              response=await fetch(API+'/api/admin/uploads/'+uploadId+'/chunk',{method:'POST',headers:{'Authorization':'Bearer '+token,'Content-Type':'application/octet-stream','X-Chunk-Index':String(i),...(chunkHashHex ? {'X-Chunk-SHA256':chunkHashHex} : {})},body:chunk});
              if (!response.ok) { const d=await response.json().catch(()=>({})); throw new Error(d.error||'خطا در بارگذاری بخش'); }
              break;
            } catch(e) { if(attempt===2) throw e; status.textContent='اتصال قطع شد؛ تلاش مجدد برای بخش '+(i+1); await new Promise(r=>setTimeout(r,700*(attempt+1))); }
          }
          sent += chunk.size; const pct=Math.round(sent/file.size*100); bar.style.width=pct+'%'; status.textContent='بارگذاری '+pct+'٪ ('+i+'/'+init.chunks+' بخش)';
        }
        const done=await api('/api/admin/uploads/finalize',{method:'POST',body:JSON.stringify({upload_id:uploadId})});
        localStorage.removeItem(resumeKey); status.textContent='بارگذاری کامل شد'; return done.url;
      } catch(e) { status.textContent='بارگذاری متوقف شد؛ فایل را دوباره انتخاب کنید تا از بخش‌های دریافت‌شده ادامه دهد. '+(e && e.message ? e.message : 'خطای ناشناخته'); throw e; }
    }

    async function addMovie() {
      const msg = document.getElementById('addMovieMsg');
      msg.innerHTML = '';
      try {
        const posterFile=document.getElementById('m_poster_file').files[0];
        const videoFile=document.getElementById('m_video_file').files[0];
        const hlsFile=document.getElementById('m_hls_file').files[0];
        const subtitleFile=document.getElementById('m_subtitle_file').files[0];
        if(videoFile && hlsFile) throw new Error('برای یک فیلم فقط یکی از فایل ویدیو یا بسته HLS را انتخاب کنید');
        const posterUrl=posterFile ? await uploadInChunks(posterFile,'poster','m_poster_status','m_poster_progress') : document.getElementById('m_poster_url').value;
        const videoUrl=hlsFile ? await uploadInChunks(hlsFile,'hls_bundle','m_hls_status','m_hls_progress') : (videoFile ? await uploadInChunks(videoFile,'video','m_video_status','m_video_progress') : document.getElementById('m_video_url').value);
        const subtitleUrl=subtitleFile ? await uploadInChunks(subtitleFile,'subtitle','m_subtitle_status','m_subtitle_progress') : (document.getElementById('m_subtitle_url').value || null);
        if (!videoUrl) throw new Error('فایل فیلم یا لینک آن را انتخاب کنید');
        await api('/api/movies', {
          method: 'POST',
          body: JSON.stringify({
            title: document.getElementById('m_title').value,
            description: document.getElementById('m_description').value,
            poster_url: posterUrl,
            video_url: videoUrl,
            subtitle_url: subtitleUrl,
            year: parseInt(document.getElementById('m_year').value) || 2024,
            genre: document.getElementById('m_genre').value,
            duration: parseInt(document.getElementById('m_duration').value) || 0,
            allow_download: document.getElementById('m_allow_download').checked
          })
        });
        msg.innerHTML = '<div class="msg ok">فیلم اضافه شد</div>';
        document.getElementById('m_title').value = '';
        document.getElementById('m_video_url').value = '';
        showTab('movies');
      } catch (e) {
        msg.innerHTML = '<div class="msg err">' + e.message + '</div>';
      }
    }

    async function loadSeries() {
      const el = document.getElementById('seriesList');
      el.innerHTML = 'در حال بارگذاری...';
      try {
        const list = await api('/api/series');
        if (!list.length) { el.innerHTML = 'سریالی ثبت نشده. از «افزودن سریال» استفاده کنید.'; return; }
        let html = '';
        for (const s of list) {
          let detail;
          try {
            detail = await api('/api/series/' + s.id);
          } catch {
            detail = s;
          }
          const seasons = detail.seasons || [];
          html += `<div class="series-item" id="series-${s.id}">
            <header>
              <strong>${esc(s.title)}</strong>
              <span class="badge">${s.year || ''}</span>
              <span class="badge">${s.rating_avg} ★</span>
              <span class="badge">${s.view_count} بازدید</span>
              <div class="actions" style="margin-top:8px">
                <button class="small secondary" onclick="editSeries(${s.id})">ویرایش اطلاعات</button>
                <button class="small secondary" onclick="showAddSeason(${s.id})">+ فصل</button>
                <button class="danger" onclick="deleteSeries(${s.id})">بایگانی سریال</button>
              </div>
            </header>
            <div id="add-season-${s.id}" class="hidden season-box">
              <div class="row">
                <div><label>شماره فصل</label><input id="sn-${s.id}" type="number" placeholder="خودکار" /></div>
                <div><label>عنوان فصل</label><input id="st-${s.id}" placeholder="فصل ۱" /></div>
              </div>
              <button class="small" onclick="addSeason(${s.id})">ثبت فصل</button>
            </div>`;
          for (const season of seasons) {
            html += `<div class="season-box">
              <strong>${esc(season.title || ('فصل ' + season.season_number))}</strong>
              <button class="small secondary" style="margin-right:8px" onclick="toggleSeasonEditor(${season.id})">ویرایش فصل</button>
              <button class="small secondary" style="margin-right:8px" onclick="showAddEpisode(${season.id}, ${s.id})">+ قسمت</button>
              <div id="edit-season-${season.id}" class="hidden" style="margin-top:8px">
                <div class="row"><div><label>شماره فصل</label><input id="esn-${season.id}" type="number" min="1" value="${Number(season.season_number)||1}" /></div><div><label>عنوان فصل</label><input id="est-${season.id}" value="${esc(season.title || '')}" /></div></div>
                <button class="small" onclick="saveSeasonEdit(${season.id})">ذخیره فصل</button>
              </div>
              <div id="add-ep-${season.id}" class="hidden" style="margin-top:10px">
                <div class="row3">
                  <div><label>شماره</label><input id="en-${season.id}" type="number" placeholder="خودکار" /></div>
                  <div><label>عنوان</label><input id="et-${season.id}" /></div>
                  <div><label>مدت (ثانیه)</label><input id="ed-${season.id}" type="number" value="0" /></div>
                </div>
                <label>فایل ویدیو از حافظه دستگاه</label>
                <div class="upload-field"><input id="evf-${season.id}" type="file" accept="video/*,.mp4,.m4v,.mov,.webm,.mkv,.ts"/><div id="evs-${season.id}" class="upload-status">انتخاب فایل قسمت؛ آپلود چندبخشی</div><div class="upload-progress"><span id="evp-${season.id}"></span></div></div>
                <label>بسته HLS (اختیاری؛ ZIP شامل master.m3u8 و قطعه‌ها)</label>
                <div class="upload-field"><input id="ehls-${season.id}" type="file" accept=".zip,application/zip"/><div id="ehls-status-${season.id}" class="upload-status">برای کیفیت تطبیقی، بسته HLS را انتخاب کنید.</div><div class="upload-progress"><span id="ehls-progress-${season.id}"></span></div></div>
                <label>لینک ویدیو یا مانیفست HLS (اختیاری)</label><input id="ev-${season.id}" placeholder="https://....mp4 یا master.m3u8" />
                <label>فایل زیرنویس قسمت (SRT/VTT)</label>
                <div class="upload-field"><input id="esf-${season.id}" type="file" accept=".srt,.vtt,text/vtt,application/x-subrip"/><div id="esf-status-${season.id}" class="upload-status">انتخاب فایل زیرنویس (اختیاری)</div><div class="upload-progress"><span id="esf-progress-${season.id}"></span></div></div>
                <label>لینک زیرنویس (اختیاری)</label><input id="es-${season.id}" placeholder="https://....srt" />
                <label><input type="checkbox" id="ea-${season.id}" checked style="width:auto" /> دانلود</label>
                <button class="small" onclick="addEpisode(${season.id}, ${s.id})">ثبت قسمت</button>
              </div>
              <div style="margin-top:8px">`;
            const eps = season.episodes || [];
            if (!eps.length) html += '<div style="color:var(--muted);font-size:0.85rem">هنوز قسمتی نیست</div>';
            for (const ep of eps) {
              html += `<div class="ep-row" style="flex-wrap:wrap;gap:8px">
                <span style="flex:1">قسمت ${ep.episode_number}: ${esc(ep.title || '')}</span>
                <button class="small secondary" onclick="toggleEpisodeEditor(${ep.id})">ویرایش</button>
                <button class="danger" onclick="deleteEpisode(${ep.id}, ${s.id})">حذف</button>
                <div id="edit-episode-${ep.id}" class="hidden" style="width:100%;margin-top:8px">
                  <div class="row3">
                    <div><label>شماره قسمت</label><input id="ee-num-${ep.id}" type="number" min="1" value="${Number(ep.episode_number)||1}" /></div>
                    <div><label>عنوان قسمت</label><input id="ee-title-${ep.id}" value="${esc(ep.title || '')}" /></div>
                    <div><label>مدت (ثانیه)</label><input id="ee-duration-${ep.id}" type="number" min="0" value="${Number(ep.duration)||0}" /></div>
                  </div>
                  <label>جایگزینی فایل ویدئو (اختیاری)</label>
                  <div class="upload-field"><input id="ee-file-${ep.id}" type="file" accept="video/*,.mp4,.m4v,.mov,.webm,.mkv,.ts"/><div id="ee-status-${ep.id}" class="upload-status">اگر فایل جدید انتخاب نکنی، ویدئوی فعلی حفظ می‌شود</div><div class="upload-progress"><span id="ee-progress-${ep.id}"></span></div></div>
                  <label>جایگزینی با بسته HLS (ZIP، اختیاری)</label>
                  <div class="upload-field"><input id="ee-hls-${ep.id}" type="file" accept=".zip,application/zip"/><div id="ee-hls-status-${ep.id}" class="upload-status">بسته شامل مانیفست و قطعه‌های HLS</div><div class="upload-progress"><span id="ee-hls-progress-${ep.id}"></span></div></div>
                  <label>فایل زیرنویس جدید (SRT/VTT، اختیاری)</label>
                  <div class="upload-field"><input id="ee-sub-file-${ep.id}" type="file" accept=".srt,.vtt,text/vtt,application/x-subrip"/><div id="ee-sub-status-${ep.id}" class="upload-status">در صورت انتخاب فایل، جایگزین لینک زیرنویس می‌شود</div><div class="upload-progress"><span id="ee-sub-progress-${ep.id}"></span></div></div>
                  <label>لینک زیرنویس</label><input id="ee-subtitle-${ep.id}" value="${esc(ep.subtitle_url || '')}" placeholder="https://...srt" />
                  <label><input id="ee-download-${ep.id}" type="checkbox" ${ep.allow_download !== false ? 'checked' : ''} style="width:auto"/> اجازه دانلود</label>
                  <button class="small" onclick="saveEpisodeEdit(${ep.id})">ذخیره تغییرات قسمت</button>
                </div>
              </div>`;
            }
            html += `</div></div>`;
          }
          html += `</div>`;
        }
        el.innerHTML = html;
      } catch (e) {
        el.innerHTML = '<div class="msg err">' + e.message + '</div>';
      }
    }

    function toggleSeasonEditor(id) {
      document.getElementById('edit-season-' + id).classList.toggle('hidden');
    }

    async function saveSeasonEdit(id) {
      try {
        const season_number = parseInt(document.getElementById('esn-' + id).value, 10);
        const title = document.getElementById('est-' + id).value.trim();
        if (!Number.isInteger(season_number) || season_number < 1 || season_number > 999) throw new Error('شماره فصل نامعتبر است');
        if (!title) throw new Error('عنوان فصل الزامی است');
        await api('/api/admin/seasons/' + id, {method:'PATCH', body:JSON.stringify({season_number, title})});
        alert('اطلاعات فصل ذخیره شد');
        loadSeries();
      } catch (e) { alert(e.message); }
    }

    function showAddSeason(seriesId) {
      document.getElementById('add-season-' + seriesId).classList.toggle('hidden');
    }
    function showAddEpisode(seasonId) {
      document.getElementById('add-ep-' + seasonId).classList.toggle('hidden');
    }

    async function addSeries() {
      const msg = document.getElementById('addSeriesMsg');
      msg.innerHTML = '';
      try {
        const posterFile=document.getElementById('s_poster_file').files[0];
        const posterUrl=posterFile ? await uploadInChunks(posterFile,'poster','s_poster_status','s_poster_progress') : document.getElementById('s_poster_url').value;
        await api('/api/series', {
          method: 'POST',
          body: JSON.stringify({
            title: document.getElementById('s_title').value,
            description: document.getElementById('s_description').value,
            poster_url: posterUrl,
            year: parseInt(document.getElementById('s_year').value) || 2024,
            genre: document.getElementById('s_genre').value,
            allow_download: document.getElementById('s_allow_download').checked
          })
        });
        msg.innerHTML = '<div class="msg ok">سریال اضافه شد</div>';
        document.getElementById('s_title').value = '';
        showTab('series');
      } catch (e) {
        msg.innerHTML = '<div class="msg err">' + e.message + '</div>';
      }
    }

    async function addSeason(seriesId) {
      try {
        const sn = document.getElementById('sn-' + seriesId).value;
        const st = document.getElementById('st-' + seriesId).value;
        const body = {};
        if (sn) body.season_number = parseInt(sn);
        if (st) body.title = st;
        await api('/api/series/' + seriesId + '/seasons', { method: 'POST', body: JSON.stringify(body) });
        loadSeries();
      } catch (e) { alert(e.message); }
    }

    async function addEpisode(seasonId, seriesId) {
      try {
        const episodeFile=document.getElementById('evf-' + seasonId).files[0];
        const hlsFile=document.getElementById('ehls-' + seasonId).files[0];
        const subtitleFile=document.getElementById('esf-' + seasonId).files[0];
        if(episodeFile && hlsFile) throw new Error('برای یک قسمت فقط یکی از فایل ویدیو یا بسته HLS را انتخاب کنید');
        const episodeUrl=hlsFile ? await uploadInChunks(hlsFile,'hls_bundle','ehls-status-' + seasonId,'ehls-progress-' + seasonId) : (episodeFile ? await uploadInChunks(episodeFile,'video','evs-' + seasonId,'evp-' + seasonId) : document.getElementById('ev-' + seasonId).value);
        const subtitleUrl=subtitleFile ? await uploadInChunks(subtitleFile,'subtitle','esf-status-' + seasonId,'esf-progress-' + seasonId) : (document.getElementById('es-' + seasonId).value || null);
        const body = {
          title: document.getElementById('et-' + seasonId).value || undefined,
          video_url: episodeUrl,
          subtitle_url: subtitleUrl,
          duration: parseInt(document.getElementById('ed-' + seasonId).value) || 0,
          allow_download: document.getElementById('ea-' + seasonId).checked
        };
        const en = document.getElementById('en-' + seasonId).value;
        if (en) body.episode_number = parseInt(en);
        if (!body.video_url) throw new Error('فایل ویدیو یا لینک آن الزامی است');
        await api('/api/series/seasons/' + seasonId + '/episodes', { method: 'POST', body: JSON.stringify(body) });
        loadSeries();
      } catch (e) { alert(e.message); }
    }

    async function deleteSeries(id) {
      if (!confirm('حذف این سریال؟')) return;
      try {
        await api('/api/series/' + id, { method: 'DELETE' });
        loadSeries();
      } catch (e) { alert(e.message); }
    }

    function toggleEpisodeEditor(id) {
      document.getElementById('edit-episode-' + id).classList.toggle('hidden');
    }

    async function saveEpisodeEdit(id) {
      try {
        const videoFile = document.getElementById('ee-file-' + id).files[0];
        const hlsFile = document.getElementById('ee-hls-' + id).files[0];
        const subtitleFile = document.getElementById('ee-sub-file-' + id).files[0];
        if(videoFile && hlsFile) throw new Error('برای جایگزینی فقط یکی از ویدیو یا بسته HLS را انتخاب کنید');
        const patch = {
          episode_number: parseInt(document.getElementById('ee-num-' + id).value, 10),
          title: document.getElementById('ee-title-' + id).value.trim(),
          duration: parseInt(document.getElementById('ee-duration-' + id).value, 10) || 0,
          subtitle_url: document.getElementById('ee-subtitle-' + id).value.trim() || null,
          allow_download: document.getElementById('ee-download-' + id).checked
        };
        if (!Number.isInteger(patch.episode_number) || patch.episode_number < 1) throw new Error('شماره قسمت باید حداقل ۱ باشد');
        if (!patch.title) throw new Error('عنوان قسمت الزامی است');
        if (hlsFile) {
          patch.video_url = await uploadInChunks(hlsFile, 'hls_bundle', 'ee-hls-status-' + id, 'ee-hls-progress-' + id);
        } else if (videoFile) {
          patch.video_url = await uploadInChunks(videoFile, 'video', 'ee-status-' + id, 'ee-progress-' + id);
        }
        if (subtitleFile) {
          patch.subtitle_url = await uploadInChunks(subtitleFile, 'subtitle', 'ee-sub-status-' + id, 'ee-sub-progress-' + id);
        }
        await api('/api/admin/episodes/' + id, {method:'PATCH', body:JSON.stringify(patch)});
        alert('اطلاعات قسمت ذخیره شد');
        loadSeries();
      } catch (e) { alert(e.message); }
    }

    async function deleteEpisode(id, seriesId) {
      if (!confirm('حذف این قسمت؟')) return;
      try {
        await api('/api/series/episodes/' + id, { method: 'DELETE' });
        loadSeries();
      } catch (e) { alert(e.message); }
    }

    async function loadAdminUsers() {
      const el = document.getElementById('adminUsersList');
      try {
        const rows = await api('/api/admin/users');
        if (!rows.length) { el.textContent = 'هنوز کاربری ثبت نشده است.'; return; }
        el.innerHTML = '<table><tr><th>شناسه</th><th>نام کاربری</th><th>نقش</th><th>وضعیت</th><th>اقدام</th></tr>' + rows.map(u => `<tr><td>${u.id}</td><td>${esc(u.username)}</td><td>${esc(u.role)}</td><td>${u.is_active ? 'فعال' : 'مسدود'}</td><td><button class="small ${u.is_active ? 'danger' : ''}" onclick="setUserActive(${u.id},${!u.is_active})">${u.is_active ? 'مسدودسازی' : 'فعال‌سازی'}</button></td></tr>`).join('') + '</table>';
      } catch (e) { el.innerHTML = '<div class="msg err">' + esc(e.message) + '</div>'; }
    }
    async function setUserActive(id, is_active) {
      const promptText = is_active ? 'این حساب دوباره فعال شود؟' : 'این حساب مسدود شود و نشست‌های فعالش باطل شوند؟';
      if (!confirm(promptText)) return;
      try { await api('/api/admin/users/' + id, {method:'PATCH', body:JSON.stringify({is_active})}); loadAdminUsers(); }
      catch (e) { alert(e.message); }
    }
    async function loadAdminAudit() {
      const el = document.getElementById('adminAuditList');
      try {
        const rows = await api('/api/admin/audit-logs?limit=200');
        if (!rows.length) { el.textContent = 'هنوز اقدامی ثبت نشده است.'; return; }
        const labels = {user_blocked:'مسدودسازی کاربر',user_activated:'فعال‌سازی کاربر',movie_created:'افزودن فیلم',movie_archived:'بایگانی فیلم',series_created:'افزودن سریال',series_archived:'بایگانی سریال',episode_created:'افزودن قسمت',episode_archived:'بایگانی قسمت',season_created:'افزودن فصل',support_reply_sent:'پاسخ به تیکت',support_ticket_updated:'تغییر تیکت',content_report_updated:'تغییر گزارش'};
        el.innerHTML = '<table><tr><th>زمان (UTC)</th><th>مدیر</th><th>اقدام</th><th>نوع</th><th>شناسه</th></tr>' + rows.map(x => `<tr><td>${esc(x.created_at || '')}</td><td>${esc(x.admin_username || '')}</td><td>${esc(labels[x.action] || x.action)}</td><td>${esc(x.entity_type || '')}</td><td>${x.entity_id ?? ''}</td></tr>`).join('') + '</table>';
      } catch (e) { el.innerHTML = '<div class="msg err">' + esc(e.message) + '</div>'; }
    }

    async function loadReportsAdmin() {
      const el = document.getElementById('reportsAdminList');
      try {
        const rows = await api('/api/admin/reports');
        if (!rows.length) { el.textContent = 'گزارشی ثبت نشده است.'; return; }
        el.innerHTML = '<table><tr><th>محتوا</th><th>نوع مشکل</th><th>وضعیت</th><th>اقدام</th></tr>' + rows.map(r => `<tr><td>${esc(r.content_type)} #${r.content_id}</td><td>${esc(r.category)}<br>${esc(r.description||'')}</td><td>${esc(r.status)}</td><td><button class="small" onclick="updateReport(${r.id},'in_review')">بررسی</button><button class="small" onclick="updateReport(${r.id},'resolved')">رفع شد</button><button class="small secondary" onclick="updateReport(${r.id},'rejected')">رد</button></td></tr>`).join('') + '</table>';
      } catch(e) { el.textContent = e.message; }
    }
    async function updateReport(id,status) {
      try { await api('/api/admin/reports/'+id,{method:'PATCH',body:JSON.stringify({status})}); loadReportsAdmin(); }
      catch(e) { alert(e.message); }
    }

    async function loadSupportAdmin() {
      const el = document.getElementById('supportAdminList');
      try {
        const rows = await api('/api/admin/support/tickets');
        if (!rows.length) { el.textContent = 'درخواستی ثبت نشده است.'; return; }
        el.innerHTML = '<table><tr><th>کاربر</th><th>موضوع</th><th>وضعیت</th><th></th></tr>' + rows.map(t => `<tr><td>${esc(t.username)}</td><td>${esc(t.subject)}</td><td>${esc(t.status)}</td><td><button class="small" onclick="openAdminTicket(${t.id})">بازکردن</button></td></tr>`).join('') + '</table>';
      } catch(e) { el.textContent = e.message; }
    }
    async function openAdminTicket(id) {
      const el = document.getElementById('supportAdminThread');
      try {
        const data = await api('/api/admin/support/tickets');
        const ticket = data.find(t => t.id === id);
        if (!ticket) throw new Error('تیکت پیدا نشد');
        // Admin reads thread through the dedicated endpoint; messages are returned below.
        const thread = await api('/api/admin/support/tickets/'+id);
        el.innerHTML = `<div class="card"><h3>${esc(ticket.username)} — ${esc(ticket.subject)}</h3>${thread.messages.map(m=>`<div class="msg">${m.sender_role==='admin'?'مدیر':'کاربر'}: ${esc(m.message)}</div>`).join('')}<textarea id="adminReply" rows="3" placeholder="پاسخ مدیر"></textarea><button onclick="replyAdminTicket(${id})">ارسال پاسخ</button><div class="row"><button class="secondary" onclick="setTicketStatus(${id},'in_progress')">در حال بررسی</button><button class="secondary" onclick="setTicketStatus(${id},'closed')">بستن تیکت</button></div></div>`;
      } catch(e) { el.textContent = e.message; }
    }
    async function replyAdminTicket(id) {
      const message = document.getElementById('adminReply').value.trim();
      try { await api('/api/admin/support/tickets/'+id+'/messages',{method:'POST',body:JSON.stringify({message})}); loadSupportAdmin(); openAdminTicket(id); }
      catch(e) { alert(e.message); }
    }
    async function setTicketStatus(id,status) {
      try { await api('/api/admin/support/tickets/'+id,{method:'PATCH',body:JSON.stringify({status})}); loadSupportAdmin(); openAdminTicket(id); }
      catch(e) { alert(e.message); }
    }

    function esc(s) {
      const d = document.createElement('div');
      d.textContent = s || '';
      return d.innerHTML;
    }

    if (token) {
      document.getElementById('loginBox').classList.add('hidden');
      document.getElementById('adminBox').classList.remove('hidden');
      showTab('movies');
    }
  