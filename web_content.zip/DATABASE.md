# Database (Supabase)

The live application uses the Supabase project configured in `config.js`. Frontend changes and database changes must be reviewed together; uploading this static site to Netlify does not run SQL migrations automatically.

## Current public tables

- `profiles`, `invites`
- `releases`, `release_tracks`, `release_events`, `release_comments`, `release_internal_notes`, `release_tasks`, `release_links`, `release_stats`
- `earnings`, `announcements`, `notifications`
- `bands`, `band_members`, `band_invites`, `vault_files`

The `profiles.role` enum is `artist` / `label_admin`. Releases use the statuses `Draft`, `Submitted`, `Changes Requested`, `Approved`, `Sent to distributor`, `Live`, and `Rejected`. Release task seeding and date-shifting, profile protection, and notifications are handled in part by database triggers.

## Storage buckets

- Private: `artwork`, `audio`, `documents`, `vault`
- Public: `profile-media`, `releases-content`

The app uploads release artwork and audio to user/release-scoped paths in private buckets, and release metadata JSON to `documents`. Access is governed by Storage policies and, for private files, signed URLs. Public buckets must contain only content intended to be public.

## Security and operational notes

- Row Level Security is enabled on the application tables. RLS policies and function grants still need role-based testing; advisor warnings are not proof of a vulnerability by themselves, but must be reviewed.
- Sign-up is invite-only, enforced by database logic. The app reads invite details through `get_invite`.
- The live database already includes migrations for the portal schema, band invites, notifications, profile search/customisation, release stats, and the restricted `can_see_release` RPC.
- The release-processing notification trigger was updated in v15 to use generic artist-facing wording. In v16, direct RPC execution was revoked for ten trigger-only `SECURITY DEFINER` helpers, and `release_events` inserts were scoped to releases accessible to the actor. These live changes were applied directly to Supabase; static Netlify deployment does not apply them. Verification confirmed the trigger helpers are no longer executable by `anon` or `authenticated`, and `can_see_release` remains restricted to authenticated users.
- To export a schema backup, use the Supabase CLI (`supabase db dump`) with the appropriate project credentials. Back up before schema or policy changes.

## Portal language preference (v17)

`public.profiles.preferred_language` is an optional text field constrained to `en`, `es`, `fr`, `de`, `pt`, or `pl`. The portal stores a signed-in user's chosen interface language here; anonymous/pre-login selection remains in browser local storage until login. The field does not change release titles, lyrics, artist names, or other release metadata. Existing profile rows remain valid because the field is nullable.

Release status rules (enforced in the database since 2026-10-18): trigger `guard_release_update` plus the releases INSERT and DELETE policies. Artists: create Drafts, edit while Draft or Changes Requested, move Draft to Submitted, delete own Drafts only. Label admins: unrestricted.

