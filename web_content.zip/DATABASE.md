# Voucher Desk: database design

Engine: **IndexedDB** (the browser's built-in database), database name `voucher_desk`, version 1.
It lives on the phone, needs no internet, and survives closing the app and restarting the phone.
Everything is read into memory at start and every change is written straight back to the database.

## Tables (object stores)

### users  (key: id)
| Field | Type | Notes |
|---|---|---|
| id | text | unique id |
| fullName, username, email, org, phone | text | username and email are unique (checked in the app) |
| salt, hash | text | password stored as a salted SHA-256 hash, never as plain text |
| passport | text | passport photo (small JPEG, base64) |
| createdAt | text | ISO date |

### columns  (key: id)  one set per user
| Field | Type | Notes |
|---|---|---|
| id | text | |
| uid | text | owner, points to users.id |
| label | text | column name shown in the table (can be renamed) |
| type | `text` or `amount` | |
| effect | `add`, `subtract`, `none` or null | how an amount column changes the total |
| role | `name`, `accname`, `account`, `bank` or null | the four columns used by the payment list |
| locked | true/false | locked columns can be renamed but not deleted |
| order | number | left-to-right position |

Default columns for a new account: Full name, Account name, Account number, Bank name (locked) and
Initial salary (+), Deduction (-), Contribution (-), Increment (+).

### months  (key: id = uid + "|" + key)
| Field | Type | Notes |
|---|---|---|
| uid | text | owner |
| key | text | `2026-11` (sorts correctly) |
| name | text | `November 2026` (printed on exports) |

### rows  (key: id)  one row per staff member per month
| Field | Type | Notes |
|---|---|---|
| uid | text | owner |
| monthKey | text | points to months.key |
| seq | number | position in the month |
| vals | object | `{ columnId: value }` so added or deleted columns need no data migration |
| total | number | net amount = sum of "add" columns minus sum of "subtract" columns |

### meta  (key: k)
Holds the logged-in user (`session`), the Google client ID (`gclient`) and, per user, `changed_<uid>` and `synced_<uid>` timestamps used to show whether the latest changes are backed up.

## Relationships
users 1 --- n columns
users 1 --- n months
months 1 --- n rows (by uid + monthKey)
columns 1 --- n values inside rows.vals

## Total formula
total = (all columns with effect "add") - (all columns with effect "subtract")
Columns with effect "none" and text columns are ignored. Changing a column's effect or deleting a column recalculates every row.

## Backup file
"Save backup file" writes one JSON file with the user, columns, months and rows.
"Restore from backup file" puts them back (works on a new phone, before logging in).
