# EduMind AI 1.0

Bu ZIP ichida telefon brauzerida ishlaydigan, offline-first web ilova prototipi bor.

## Ishga tushirish
1. ZIP faylni oching.
2. `index.html` faylini brauzerda oching yoki papkani statik hostingga joylang.
3. Android Chrome'da hostingdagi sahifani ochib, menyudan **Add to Home screen** tanlang.

## Muhim cheklovlar
- Bu ZIP native Android APK yoki Kodular `.aia` loyihasi emas.
- AI ulanmagan va rasmdan avtomatik OCR/test yaratish yo‘q.
- Test savollari, konspektlar, so‘zlar va reja foydalanuvchi tomonidan kiritiladi.
- Ma’lumotlar brauzerning localStorage xotirasida saqlanadi. Brauzer ma’lumotlarini tozalash ularni o‘chirishi mumkin.
- Kamera/rasm biriktirish brauzer ruxsatlariga bog‘liq.
- Ilovani haqiqiy APK qilish uchun keyin Android wrapper/build bosqichi kerak bo‘ladi.

Created by Oygul
