import secrets
import json
import string
import time
import subprocess
import sys

def copy_to_clipboard(text):
    try:
        if sys.platform == "win32":
            subprocess.run("clip", input=text.strip().encode("utf-16le"), check=True)
            return True
        elif sys.platform == "darwin":
            subprocess.run("pbcopy", input=text.strip().encode("utf-8"), check=True)
            return True
        else:
            for cmd in [["termux-clipboard-set"], ["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]]:
                try:
                    subprocess.run(cmd, input=text.strip().encode("utf-8"), check=True)
                    return True
                except FileNotFoundError:
                    continue
    except Exception:
        pass
    return False

def get_password_length():
    print("\n--- เลือกความยาวรหัสผ่าน ---")
    print("ตัวเลือกยอดนิยม: 4, 6, 8, 9, 10, 12")
    print("พิมพ์ 'auto' เพื่อสุ่มความยาวอัตโนมัติ (4 - 20 ตัว)")
    print("หรือพิมพ์ตัวเลขที่ต้องการเอง (ขั้นต่ำ 4 ตัว)")

    while True:
        choice = input("\nความยาวที่ต้องการ: ").strip().lower()
        if choice == "auto":
            length = secrets.randbelow(17) + 4
            print(f"-> สุ่มความยาวอัตโนมัติได้: {length} ตัว")
            return length
        if choice.isdigit():
            length = int(choice)
            if 4 <= length <= 256:
                return length
            else:
                print("⚠️ กรุณาระบุความยาวตั้งแต่ 4 ถึง 256 ตัวอักษร")
        else:
            print("⚠️ กรุณาพิมพ์จำนวนเต็ม 4 ถึง 256 หรือพิมพ์ 'auto'")

def get_character_pool():
    print("\n--- เลือกประเภทตัวอักษร (กด Enter เพื่อเลือกทั้งหมด) ---")
    custom = input("ต้องการเลือกประเภทตัวอักษรเองไหม? (y/N): ").strip().lower()

    if custom != "y":
        return string.ascii_uppercase + string.ascii_lowercase + string.digits + "!@#$%^&*()_+-=[]{}|;:,.<>?"

    pool = ""
    if input("รวมตัวพิมพ์ใหญ่ A-Z? (Y/n): ").strip().lower() != "n":
        pool += string.ascii_uppercase
    if input("รวมตัวพิมพ์เล็ก a-z? (Y/n): ").strip().lower() != "n":
        pool += string.ascii_lowercase
    if input("รวมตัวเลข 0-9? (Y/n): ").strip().lower() != "n":
        pool += string.digits
    if input("รวมสัญลักษณ์พิเศษ !@#$...? (Y/n): ").strip().lower() != "n":
        pool += "!@#$%^&*()_+-=[]{}|;:,.<>?"

    while not pool:
        print("⚠️ ต้องเลือกอย่างน้อย 1 ประเภท")
        if input("รวมตัวพิมพ์ใหญ่ A-Z? (Y/n): ").strip().lower() != "n":
            pool += string.ascii_uppercase
        if input("รวมตัวพิมพ์เล็ก a-z? (Y/n): ").strip().lower() != "n":
            pool += string.ascii_lowercase
        if input("รวมตัวเลข 0-9? (Y/n): ").strip().lower() != "n":
            pool += string.digits
        if input("รวมสัญลักษณ์พิเศษ !@#$...? (Y/n): ").strip().lower() != "n":
            pool += "!@#$%^&*()_+-=[]{}|;:,.<>?"

    return pool

def generate_with_animation(length, pool, duration=5.0):
    print("\nกำลังสุ่มรหัสผ่าน...")
    start_time = time.time()

    while True:
        elapsed = time.time() - start_time
        remaining = max(0.0, duration - elapsed)
        temp_pass = "".join(secrets.choice(pool) for _ in range(length))
        sys.stdout.write(f"\r⏳ เหลือเวลา {remaining:0.1f} วิ | กำลังสุ่ม: {temp_pass}   ")
        sys.stdout.flush()

        if elapsed >= duration:
            break
        time.sleep(0.07)

    secure_rng = random.SystemRandom()
    final_password = "".join(secure_rng.choice(pool) for _ in range(length))
    sys.stdout.write(f"\r✅ สุ่มเสร็จสิ้น! (5.0 วิ) | รหัสผ่าน: {final_password}   \n")
    sys.stdout.flush()
    return final_password

def export_history_to_luau(history):
    luau_code = "--!strict\n"
    luau_code += "-- [[ Generated Password History (Luau / Lua) ]] --\n\n"
    luau_code += "export type PasswordRecord = {\n"
    luau_code += "    Id: number,\n"
    luau_code += "    Password: string,\n"
    luau_code += "    Length: number,\n"
    luau_code += "    Timestamp: string\n"
    luau_code += "}\n\n"
    luau_code += "local PasswordHistory: {PasswordRecord} = {\n"
    
    for idx, item in enumerate(history, 1):
        pw = json.dumps(item['password'], ensure_ascii=True)
        length = item['length']
        time_str = json.dumps(item['time'], ensure_ascii=True)
        luau_code += f"    {{\n"
        luau_code += f"        Id = {idx},\n"
        luau_code += f"        Password = {pw},\n"
        luau_code += f"        Length = {length},\n"
        luau_code += f"        Timestamp = {time_str}\n"
        luau_code += f"    }},\n"
    
    luau_code += "}\n\n"
    luau_code += "return PasswordHistory"
    return luau_code

def main():
    history = []
    print("==================================================")
    print("   🔐 โปรแกรมสุ่มรหัสผ่าน (บันทึกประวัติเป็น Luau)")
    print("==================================================")

    while True:
        length = get_password_length()
        pool = get_character_pool()
        password = generate_with_animation(length, pool, duration=5.0)
        
        current_time = time.strftime("%Y-%m-%d %H:%M:%S")
        history.append({
            "password": password,
            "length": length,
            "time": current_time
        })

        if copy_to_clipboard(password):
            print("📋 คัดลอกรหัสผ่านล่าสุดลงคลิปบอร์ดแล้ว!")
        
        print("\n" + "="*50)
        print("📜 ประวัติรหัสผ่านทั้งหมด (โค้ด Luau / Lua):")
        print("="*50)
        luau_output = export_history_to_luau(history)
        print(luau_output)
        print("="*50)

        choice = input("\n[Enter] สุ่มรหัสใหม่ต่อ | พิมพ์ 'copy-luau' คัดลอกโค้ด Luau | พิมพ์ 'save-luau' บันทึกเป็นไฟล์ .lua | พิมพ์ 'exit' ออก: ").strip().lower()
        if choice == "exit":
            print("ขอบคุณที่ใช้งานครับ!")
            break
        elif choice == "copy-luau":
            if copy_to_clipboard(luau_output):
                print("📋 คัดลอกโค้ด Luau ทั้งหมดลงคลิปบอร์ดเรียบร้อยแล้ว!")
        elif choice == "save-luau":
            with open("password_history.lua", "w", encoding="utf-8") as f:
                f.write(luau_output)
            print("💾 บันทึกไฟล์ 'password_history.lua' ลงในโฟลเดอร์ปัจจุบันเรียบร้อยแล้ว!")

if __name__ == "__main__":
    main()
