# بناء APK / Build the APK

## الطريقة 1: Android Studio (على جهازك)
1. ثبّت Node.js و Android Studio.
2. في مجلد المشروع:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. من Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
   الملف الناتج: android/app/build/outputs/apk/debug/app-debug.apk

## الطريقة 2: بدون تثبيت أي شيء (GitHub)
1. أنشئ مستودعًا جديدًا على github.com وارفع كل محتويات هذا المجلد (بما فيها .github).
2. افتح تبويب Actions > Build APK > Run workflow.
3. بعد دقائق حمّل app-debug-apk من قسم Artifacts.

## تحديث التطبيق
عدّل www/index.html ثم أعد: npx cap sync android وابنِ من جديد.
