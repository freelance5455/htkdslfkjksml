package de.bigshit.helfer

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.sin

/**
 * Durchsichtige Ebene über dem ganzen Bildschirm. Sie zeichnet nur den gelben,
 * pulsierenden Kreis mit Finger. Berührungen gehen durch sie hindurch.
 */
class RingView(context: Context) : View(context) {

    private var mode = GuideService.Mode.NONE
    private var target: RectF? = null
    private val d = resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(245, 196, 0); strokeWidth = 5f * d
    }
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.argb(110, 0, 0, 0); strokeWidth = 11f * d
    }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.rgb(245, 196, 0); strokeWidth = 6f * d
    }
    private val emoji = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 46f * d; textAlign = Paint.Align.CENTER
    }
    private val loc = IntArray(2)
    private val t0 = SystemClock.uptimeMillis()

    fun show(m: GuideService.Mode, r: RectF?) {
        mode = m
        target = r
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (mode == GuideService.Mode.NONE) return
        getLocationOnScreen(loc)
        val phase = ((SystemClock.uptimeMillis() - t0) % 1300L) / 1300f
        val wave = (sin(phase * 2.0 * PI) * 0.5 + 0.5).toFloat()
        glow.alpha = (170 * (1f - wave)).toInt()

        when (mode) {
            GuideService.Mode.NODE -> target?.let { r ->
                val left = r.left - loc[0]; val top = r.top - loc[1]
                val right = r.right - loc[0]; val bottom = r.bottom - loc[1]
                val cx = (left + right) / 2f; val cy = (top + bottom) / 2f
                val w = right - left; val h = bottom - top
                val reach: Float
                if (w > h * 2.6f) {
                    // Breite Zeilen (Listeneinträge) bekommen einen runden Rahmen statt eines Riesenkreises.
                    val pad = 6f * d; val g = pad + 8f * d * wave; val rr = 16f * d
                    c.drawRoundRect(left - pad, top - pad, right + pad, bottom + pad, rr, rr, shade)
                    c.drawRoundRect(left - g, top - g, right + g, bottom + g, rr, rr, glow)
                    c.drawRoundRect(left - pad, top - pad, right + pad, bottom + pad, rr, rr, ring)
                    reach = h / 2f + pad
                } else {
                    val rad = max(max(w, h) / 2f + 10f * d, 28f * d)
                    c.drawCircle(cx, cy, rad, shade)
                    c.drawCircle(cx, cy, rad + 9f * d * wave, glow)
                    c.drawCircle(cx, cy, rad, ring)
                    reach = rad
                }
                val bob = 7f * d * wave
                if (cy + reach + 60f * d < height) c.drawText("👆", cx, cy + reach + 48f * d - bob, emoji)
                else c.drawText("👇", cx, cy - reach - 10f * d + bob, emoji)
            }
            GuideService.Mode.SWIPE_DOWN -> {
                val cx = width / 2f
                val y = 20f * d + wave * 150f * d
                c.drawRoundRect(cx - 60f * d, 4f * d, cx + 60f * d, 14f * d, 6f * d, 6f * d, ring)
                c.drawText("👇", cx, y + 46f * d, emoji)
            }
            GuideService.Mode.SWIPE_UP -> {
                val cx = width / 2f
                val y = height - 30f * d - wave * 160f * d
                c.drawRoundRect(cx - 60f * d, height - 14f * d, cx + 60f * d, height - 4f * d, 6f * d, 6f * d, ring)
                c.drawText("👆", cx, y, emoji)
            }
            GuideService.Mode.HOME -> {
                val cx = width / 2f; val cy = height - 26f * d; val rad = 30f * d
                c.drawCircle(cx, cy, rad + 9f * d * wave, glow)
                c.drawCircle(cx, cy, rad, ring)
                c.drawText("👇", cx, cy - rad - 10f * d + 7f * d * wave, emoji)
            }
            GuideService.Mode.NONE -> {}
        }
        postInvalidateDelayed(40)
    }
}
