package de.bigshit.helfer

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * Zeigt die Register-Seite (assets/index.html) in einer WebView und verbindet sie
 * mit dem Gerät: Sprachausgabe, Spracheingabe und der geführte Modus mit Kreisen
 * direkt auf dem echten Bildschirm (GuideService).
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.GERMAN
                tts?.setSpeechRate(0.92f)
                ttsReady = true
            }
        }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }

    /** Diese Funktionen ruft die Seite über window.Android auf. */
    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "app")
        }

        @JavascriptInterface
        fun stopSpeak() {
            tts?.stop()
        }

        @JavascriptInterface
        fun guideReady(): Boolean = GuideService.instance != null

        @JavascriptInterface
        fun startGuide(json: String) {
            runOnUiThread { launchGuide(json) }
        }

        @JavascriptInterface
        fun listen() {
            runOnUiThread { startListening() }
        }

        @JavascriptInterface
        fun stopListen() {
            runOnUiThread { recognizer?.stopListening() }
        }
    }

    private fun launchGuide(json: String) {
        val o = runCatching { JSONObject(json) }.getOrNull() ?: return
        val arr = o.optJSONArray("steps") ?: JSONArray()
        val steps = (0 until arr.length()).map { i ->
            val s = arr.getJSONObject(i)
            Step(s.optString("t"), s.optString("ziel"))
        }
        val svc = GuideService.instance
        if (svc == null) {
            askForAccessibility()
            return
        }
        tts?.stop()
        svc.start(o.optString("title"), steps)
        if (o.optBoolean("home", true)) {
            // Anleitungen beginnen fast immer auf dem Startbildschirm.
            startActivity(
                Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    private fun askForAccessibility() {
        AlertDialog.Builder(this)
            .setTitle("Einmal freischalten")
            .setMessage(
                "Damit die Kreise direkt auf Ihrem Bildschirm erscheinen, schalten Sie die Handy-Hilfe einmal in den Bedienungshilfen ein.\n\n" +
                    "Tippen Sie gleich auf „Installierte Apps“ oder „Heruntergeladene Apps“, dann auf „Big Shit Helfer“, und schalten Sie den Schalter ein."
            )
            .setPositiveButton("Zu den Einstellungen") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Später", null)
            .show()
    }

    private fun js(code: String) {
        web.post { web.evaluateJavascript(code, null) }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.onNativeSpeechError && window.onNativeSpeechError('fehlt')")
            return
        }
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                js("window.onNativeSpeech && window.onNativeSpeech(" + JSONObject.quote(t) + ", false, [])")
            }

            override fun onResults(results: Bundle?) {
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                val first = list.firstOrNull() ?: ""
                js("window.onNativeSpeech && window.onNativeSpeech(" + JSONObject.quote(first) + ", true, " + JSONArray(list).toString() + ")")
            }

            override fun onError(error: Int) {
                val code = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "nichts"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "erlaubnis"
                    else -> "fehler"
                }
                js("window.onNativeSpeechError && window.onNativeSpeechError('$code')")
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "de-DE")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        r.startListening(intent)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_MIC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startListening()
            else js("window.onNativeSpeechError && window.onNativeSpeechError('erlaubnis')")
        }
    }

    companion object {
        private const val REQ_MIC = 7
    }
}
