package de.bigshit.helfer

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

data class Step(val text: String, val ziel: String)

/**
 * Geführter Modus direkt auf dem echten Bildschirm.
 *
 * Über die Bedienungshilfen sieht der Dienst, welche Knöpfe gerade zu sehen sind,
 * sucht den Knopf des aktuellen Schritts und legt einen durchsichtigen Kreis darüber.
 * Der Kreis bleibt, bis genau dieser Knopf angetippt wird, dann kommt der nächste Schritt.
 * Ein kleines Hinweisfenster zeigt den Schritt und Knöpfe für Weiter, Zurück und Beenden.
 */
class GuideService : AccessibilityService(), TextToSpeech.OnInitListener {

    companion object {
        @Volatile
        var instance: GuideService? = null
        private const val SYSTEM_UI = "com.android.systemui"
    }

    enum class Mode { NONE, NODE, SWIPE_DOWN, SWIPE_UP, HOME }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var ring: RingView? = null
    private var bubble: LinearLayout? = null
    private var bubbleTitle: TextView? = null
    private var bubbleText: TextView? = null
    private var bubbleHint: TextView? = null
    private var btnBack: Button? = null
    private var btnNext: Button? = null
    private var bubbleAtTop = false

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private var title = ""
    private var steps: List<Step> = emptyList()
    private var index = 0
    private var mode = Mode.NONE
    private var keys: List<String> = emptyList()
    private var targetRect: Rect? = null
    private var stepStarted = 0L
    private var advancing = false

    private val findRunnable = Runnable { findTarget() }

    val isGuiding: Boolean get() = steps.isNotEmpty()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.GERMAN
            tts?.setSpeechRate(0.92f)
            ttsReady = true
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        stop()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        stop()
        tts?.shutdown()
        instance = null
        super.onDestroy()
    }

    private fun speak(text: String) {
        if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "guide")
    }

    /** Wird von der App aufgerufen, wenn jemand „Zeig es mir am Handy“ antippt. */
    fun start(newTitle: String, list: List<Step>) {
        main.post {
            stop()
            if (list.isEmpty()) return@post
            title = newTitle
            steps = list
            index = 0
            showOverlays()
            showStep()
        }
    }

    fun stop() {
        main.removeCallbacks(findRunnable)
        ring?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        ring = null
        bubble = null
        steps = emptyList()
        targetRect = null
        mode = Mode.NONE
        advancing = false
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun overlayParams(touchable: Boolean, w: Int, h: Int): WindowManager.LayoutParams {
        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (!touchable) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        }
        val lp = WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return lp
    }

    private fun showOverlays() {
        val r = RingView(this)
        val rp = overlayParams(false, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT)
        rp.gravity = Gravity.TOP or Gravity.START
        wm.addView(r, rp)
        ring = r
        buildBubble()
    }

    private fun button(label: String, primary: Boolean, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(if (primary) Color.WHITE else Color.rgb(23, 41, 43))
        background = GradientDrawable().apply {
            setColor(if (primary) Color.rgb(31, 95, 102) else Color.rgb(229, 240, 239))
            cornerRadius = dp(12f).toFloat()
        }
        setPadding(dp(14f), dp(6f), dp(14f), dp(6f))
        minHeight = dp(46f)
        minimumHeight = dp(46f)
        minWidth = dp(46f)
        minimumWidth = dp(46f)
        setOnClickListener { onClick() }
    }

    private fun buildBubble() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(18f).toFloat()
                setStroke(dp(3f), Color.rgb(31, 95, 102))
            }
            elevation = dp(8f).toFloat()
        }
        bubbleTitle = TextView(this).apply { setTextColor(Color.rgb(83, 102, 106)); textSize = 13f }
        bubbleText = TextView(this).apply {
            setTextColor(Color.rgb(23, 41, 43)); textSize = 19f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4f), 0, dp(4f))
        }
        bubbleHint = TextView(this).apply { setTextColor(Color.rgb(107, 77, 0)); textSize = 15f; visibility = View.GONE }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun lpBtn() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(8f) }
        val close = button("✕", false) { finish(false) }.apply { contentDescription = "Anleitung beenden" }
        val again = button("🔊", false) { steps.getOrNull(index)?.let { speak(it.text) } }.apply { contentDescription = "Noch einmal vorlesen" }
        val back = button("◀", false) { if (index > 0) { index--; showStep() } }.apply { contentDescription = "Zurück" }
        val next = button("Weiter ▶", true) { next() }
        btnBack = back
        btnNext = next
        row.addView(close, lpBtn())
        row.addView(again, lpBtn())
        row.addView(back, lpBtn())
        row.addView(next, lpBtn())

        box.addView(bubbleTitle)
        box.addView(bubbleText)
        box.addView(bubbleHint)
        box.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8f) })

        val lp = overlayParams(true, resources.displayMetrics.widthPixels - dp(24f), WindowManager.LayoutParams.WRAP_CONTENT)
        lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        lp.y = dp(80f)
        wm.addView(box, lp)
        bubble = box
        bubbleAtTop = false
    }

    /** Das Hinweisfenster weicht dem Kreis aus: Ziel unten, Fenster oben und umgekehrt. */
    private fun positionBubble(target: Rect?) {
        val b = bubble ?: return
        val h = resources.displayMetrics.heightPixels
        val wantTop = (target != null && target.centerY() > h * 0.55f) || mode == Mode.SWIPE_UP || mode == Mode.HOME
        if (wantTop == bubbleAtTop) return
        val lp = b.layoutParams as WindowManager.LayoutParams
        lp.gravity = (if (wantTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        lp.y = if (wantTop) dp(56f) else dp(80f)
        runCatching { wm.updateViewLayout(b, lp) }
        bubbleAtTop = wantTop
    }

    private fun modeFor(ziel: String): Mode {
        val z = ziel.lowercase(Locale.GERMAN)
        return when {
            z.isBlank() -> Mode.NONE
            z.contains("oberer bildschirmrand") -> Mode.SWIPE_DOWN
            z.contains("unterer bildschirmrand") -> Mode.SWIPE_UP
            z.contains("startseite-taste") -> Mode.HOME
            else -> Mode.NODE
        }
    }

    private fun showStep() {
        val s = steps.getOrNull(index) ?: return
        advancing = false
        stepStarted = System.currentTimeMillis()
        mode = modeFor(s.ziel)
        keys = if (mode == Mode.NODE) Targets.keywords(s.ziel) else emptyList()
        targetRect = null
        ring?.show(if (mode == Mode.NODE) Mode.NONE else mode, null)
        bubbleTitle?.text = "$title, Schritt ${index + 1} von ${steps.size}"
        bubbleText?.text = s.text
        bubbleHint?.visibility = View.GONE
        btnBack?.isEnabled = index > 0
        btnBack?.alpha = if (index > 0) 1f else 0.4f
        btnNext?.text = if (index == steps.size - 1) "Fertig ✓" else "Weiter ▶"
        positionBubble(null)
        speak("Schritt ${index + 1}. ${s.text}")
        scheduleFind(200)
    }

    private fun scheduleFind(delay: Long) {
        main.removeCallbacks(findRunnable)
        main.postDelayed(findRunnable, delay)
    }

    private fun next() {
        if (index < steps.size - 1) {
            index++
            showStep()
        } else {
            finish(true)
        }
    }

    private fun advanceSoon() {
        if (advancing) return
        advancing = true
        ring?.show(Mode.NONE, null)
        bubbleHint?.apply { text = "Richtig!"; visibility = View.VISIBLE }
        main.postDelayed({ if (isGuiding) next() }, 900)
    }

    private fun finish(done: Boolean) {
        val t = title
        stop()
        speak(if (done) "Geschafft. $t ist erledigt." else "Anleitung beendet.")
        if (done) {
            val i = Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
            main.postDelayed({ runCatching { startActivity(i) } }, 1500)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !isGuiding || advancing) return
        val pkg = event.packageName?.toString() ?: ""
        if (pkg == packageName) return
        val sinceStart = System.currentTimeMillis() - stepStarted

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                if (mode == Mode.NODE && sinceStart > 400) {
                    val src = event.source
                    val r = Rect()
                    src?.getBoundsInScreen(r)
                    val tr = targetRect
                    val label = Targets.label(src) + " " + event.text.joinToString(" ") + " " + (event.contentDescription ?: "")
                    val hitBounds = tr != null && !r.isEmpty && Rect.intersects(tr, r)
                    if (hitBounds || Targets.matches(label, keys)) {
                        advanceSoon()
                        return
                    }
                }
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                if (sinceStart > 700) {
                    if (mode == Mode.SWIPE_DOWN && pkg == SYSTEM_UI) { advanceSoon(); return }
                    if ((mode == Mode.SWIPE_UP || mode == Mode.HOME) && pkg != SYSTEM_UI) { advanceSoon(); return }
                }
            }
        }
        if (mode == Mode.NODE) scheduleFind(250)
    }

    /** Sucht in allen sichtbaren Fenstern das Element, das am besten zum Ziel passt. */
    private fun findTarget() {
        if (!isGuiding || advancing) return
        if (mode != Mode.NODE) {
            ring?.show(mode, null)
            positionBubble(null)
            return
        }
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        val roots = ArrayList<AccessibilityNodeInfo>()
        runCatching { windows.forEach { w -> w.root?.let { roots.add(it) } } }
        if (roots.isEmpty()) rootInActiveWindow?.let { roots.add(it) }
        val budget = intArrayOf(4000)
        for (root in roots) {
            if (root.packageName?.toString() == packageName) continue
            walk(root, 0, budget) { n ->
                val sc = Targets.score(n, keys)
                if (sc > bestScore) {
                    bestScore = sc
                    best = n
                }
            }
        }
        val b = best
        if (b != null && bestScore >= 40) {
            val r = Rect()
            b.getBoundsInScreen(r)
            if (!r.isEmpty) {
                targetRect = r
                ring?.show(Mode.NODE, RectF(r))
                bubbleHint?.visibility = View.GONE
                positionBubble(r)
                return
            }
        }
        targetRect = null
        ring?.show(Mode.NONE, null)
        val name = keys.firstOrNull()
        bubbleHint?.apply {
            text = if (name != null)
                "Ich sehe „$name“ hier noch nicht. Öffnen Sie zuerst die passende App oder wischen Sie weiter, dann erscheint der Kreis von selbst."
            else
                "Diesen Schritt kann ich nicht einkreisen. Machen Sie ihn wie beschrieben und tippen Sie dann auf „Weiter“."
            visibility = View.VISIBLE
        }
        positionBubble(null)
    }

    private fun walk(n: AccessibilityNodeInfo?, depth: Int, budget: IntArray, f: (AccessibilityNodeInfo) -> Unit) {
        if (n == null || depth > 45 || budget[0] <= 0) return
        budget[0]--
        f(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1, budget, f)
    }
}
