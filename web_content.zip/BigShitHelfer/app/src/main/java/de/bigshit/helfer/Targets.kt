package de.bigshit.helfer

import android.os.Build
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Übersetzt die Ziel-Beschreibung einer Anleitung (zum Beispiel „Schalter „WLAN““)
 * in Suchwörter und bewertet, wie gut ein Element auf dem Bildschirm dazu passt.
 */
object Targets {

    // Symbole haben auf dem Bildschirm meist keinen sichtbaren Text, aber eine Beschreibung.
    private val SYN: List<Pair<String, List<String>>> = listOf(
        "grüner hörer" to listOf("Anrufen", "Anruf", "Wählen", "Annehmen", "Call", "Answer"),
        "roter hörer" to listOf("Auflegen", "Anruf beenden", "Beenden", "Ablehnen", "End call", "Decline"),
        "hörer oben" to listOf("Sprachanruf", "Anrufen", "Voice call"),
        "drei punkte" to listOf("Weitere Optionen", "Mehr Optionen", "Optionen", "Menü", "More options"),
        "drei striche" to listOf("Navigationsleiste öffnen", "Menü", "Navigation"),
        "zahnrad" to listOf("Einstellungen", "Settings"),
        "plus" to listOf("Hinzufügen", "Neu", "Erstellen", "Add", "Create", "New"),
        "mülleimer" to listOf("Löschen", "Papierkorb", "In den Papierkorb", "Delete"),
        "büroklammer" to listOf("Anhängen", "Anhang", "Attach"),
        "senden" to listOf("Senden", "Send"),
        "kamera-umdrehen" to listOf("Kamera wechseln", "Kamera umdrehen", "Switch camera", "Flip camera"),
        "kamera-zeichen" to listOf("Videoanruf", "Kamera", "Video", "Video call"),
        "mikrofon" to listOf("Mikrofon", "Spracheingabe", "Sprachnachricht", "Stumm", "Voice", "Mute"),
        "lupe" to listOf("Suchen", "Suche", "Search"),
        "teilen" to listOf("Teilen", "Share"),
        "stift" to listOf("Bearbeiten", "Edit"),
        "stern" to listOf("Favorit", "Zu Favoriten hinzufügen", "Star"),
        "herz" to listOf("Favorit", "Favorite", "Gefällt mir"),
        "tastenfeld" to listOf("Tastenfeld", "Wähltastatur", "Wählfeld", "Dialpad", "Keypad"),
        "zurück-taste" to listOf("Zurück", "Back"),
        "übersicht-taste" to listOf("Übersicht", "Letzte Apps", "Recents"),
        "galerie" to listOf("Galerie", "Fotos", "Gallery", "Photos"),
        "kamera-app" to listOf("Kamera", "Camera"),
        "telefon-app" to listOf("Telefon", "Phone"),
        "nachrichten-app" to listOf("Nachrichten", "Messages"),
        "uhr-app" to listOf("Uhr", "Clock"),
        "kalender-app" to listOf("Kalender", "Calendar"),
        "e-mail-app" to listOf("Gmail", "E-Mail", "Mail"),
        "chrome-app" to listOf("Chrome"),
        "play store" to listOf("Play Store"),
        "google maps" to listOf("Maps", "Google Maps"),
        "auslöser" to listOf("Auslöser", "Foto aufnehmen", "Aufnehmen", "Foto machen", "Shutter"),
        "abspiel-dreieck" to listOf("Abspielen", "Wiedergabe", "Play"),
        "blitz" to listOf("Blitz", "Flash"),
        "lautsprecher" to listOf("Lautsprecher", "Speaker"),
        "taschenlampe" to listOf("Taschenlampe", "Flashlight", "Torch"),
        "flugmodus" to listOf("Flugmodus", "Flugzeugmodus", "Airplane"),
        "wlan" to listOf("WLAN", "Wi-Fi", "WiFi", "Internet"),
        "bluetooth" to listOf("Bluetooth"),
        "mobile daten" to listOf("Mobile Daten", "Internet", "Mobile data"),
        "nicht stören" to listOf("Nicht stören", "Do not disturb"),
        "dunkelmodus" to listOf("Dunkelmodus", "Dunkles Design", "Dark theme"),
        "hotspot" to listOf("Hotspot"),
        "automatisch drehen" to listOf("Automatisch drehen", "Bildschirm drehen", "Hochformat", "Auto-rotate"),
        "helligkeit" to listOf("Helligkeit", "Brightness"),
        "whatsapp" to listOf("WhatsApp")
    )

    private val GENERIC = setOf(
        "knopf", "schalter", "eintrag", "zeichen", "reiter", "feld", "taste", "symbol", "ein", "eine",
        "der", "die", "das", "app", "link", "ordner", "oben", "unten", "rechts", "links", "in", "liste",
        "name", "neben", "am", "auf", "zum", "beispiel", "bildschirm"
    )

    private val QUOTED = Regex("„([^“]+)“")

    fun keywords(ziel: String): List<String> {
        val out = LinkedHashSet<String>()
        QUOTED.findAll(ziel).forEach { out.add(it.groupValues[1]) }
        val z = ziel.lowercase(Locale.GERMAN)
        SYN.forEach { (key, words) -> if (z.contains(key)) out.addAll(words) }
        if (out.isEmpty()) {
            val words = ziel.replace(Regex("[^\\p{L}\\p{N} -]"), " ")
                .split(Regex("\\s+"))
                .filter { it.length > 2 && it.lowercase(Locale.GERMAN) !in GENERIC }
            if (words.isNotEmpty()) out.add(words.joinToString(" "))
            out.addAll(words.filter { it.length > 3 })
        }
        return out.toList()
    }

    fun label(n: AccessibilityNodeInfo?): String {
        if (n == null) return ""
        val sb = StringBuilder()
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        if (Build.VERSION.SDK_INT >= 26) n.hintText?.let { sb.append(it).append(' ') }
        return sb.toString().trim()
    }

    private fun norm(s: String) = s.lowercase(Locale.GERMAN).replace(Regex("\\s+"), " ").trim()

    fun score(n: AccessibilityNodeInfo, keys: List<String>): Int {
        if (keys.isEmpty() || !n.isVisibleToUser) return 0
        val l = norm(label(n))
        if (l.isEmpty()) return 0
        var best = 0
        keys.forEachIndexed { i, raw ->
            val k = norm(raw)
            if (k.isEmpty()) return@forEachIndexed
            val s = when {
                l == k -> 100
                l.startsWith(k) && l.length <= k.length + 14 -> 85
                Regex("(^|[^\\p{L}])" + Regex.escape(k) + "([^\\p{L}]|$)").containsMatchIn(l) && l.length <= 60 -> 70
                l.contains(k) && l.length <= 40 -> 50
                else -> 0
            }
            if (s > 0) best = maxOf(best, s - i * 2 + if (n.isClickable || n.isCheckable) 4 else 0)
        }
        return best
    }

    fun matches(label: String, keys: List<String>): Boolean {
        val l = norm(label)
        if (l.isEmpty()) return false
        return keys.any { raw -> val k = norm(raw); k.isNotEmpty() && (l == k || l.contains(k)) }
    }
}
