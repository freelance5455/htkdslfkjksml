# Big Shit Helfer, Android-Prototyp

Diese App zeigt die Register-Seite mit allen Anleitungen. Der Knopf „Zeig es mir am Handy“ legt einen gelben, durchsichtigen Kreis direkt auf den echten Bildschirm, auch auf den Startbildschirm und in andere Apps. Ein kleines Hinweisfenster zeigt den Schritt. Der Kreis bleibt, bis genau dieser Knopf angetippt wird, dann kommt der nächste Schritt.

## So wird daraus eine APK

1. Android Studio kostenlos installieren: developer.android.com/studio
2. Diesen Ordner entpacken und in Android Studio über „Open“ öffnen.
3. Warten, bis unten „Gradle sync“ fertig ist (beim ersten Mal einige Minuten, braucht Internet). Schlägt Android Studio ein Upgrade von Gradle oder dem Android-Plugin vor, einfach zustimmen.
4. Menü „Build“, „Build App Bundle(s) / APK(s)“, „Build APK(s)“.
5. Die Datei liegt danach unter `app/build/outputs/apk/debug/app-debug.apk`.

Schneller zum Testen: Handy per USB anschließen, am Handy die Entwickleroptionen und „USB-Debugging“ einschalten und in Android Studio auf den grünen Play-Knopf tippen.

## Auf dem Handy einrichten

1. APK aufs Handy kopieren und öffnen. Installation aus „unbekannten Quellen“ erlauben.
2. App öffnen, einen Eintrag antippen, „Zeig es mir am Handy“.
3. Beim ersten Mal erscheint ein Hinweis. Über „Zu den Einstellungen“ unter „Installierte Apps“ den „Big Shit Helfer“ einschalten.
4. Ab Android 13 ist der Schalter bei selbst installierten Apps erst gesperrt. Dann: Einstellungen, Apps, Big Shit Helfer, oben rechts die drei Punkte, „Eingeschränkte Einstellungen zulassen“. Danach lässt er sich einschalten.
5. Beim ersten Tippen auf „Sprechen“ fragt die App nach dem Mikrofon.

## Was der Prototyp kann

- Alle 324 Anleitungen aus dem Register, Vorlesen und Spracheingabe über das Handy selbst.
- Kreise direkt auf dem Bildschirm: Die App liest über die Bedienungshilfen die Beschriftungen der Knöpfe und sucht den Knopf des aktuellen Schritts. Wechselt man in die richtige App, erscheint der Kreis von selbst.
- Wischschritte (von oben nach unten, von unten nach oben) werden mit einem wandernden Finger gezeigt.
- Erkennt die App das Antippen, geht sie selbst zum nächsten Schritt. Sonst hilft „Weiter“.

## Grenzen dieser Version

- Keine KI in der App: der Sprech-Knopf nutzt die eingebaute Wortsuche. Für Claude braucht die echte App später einen eigenen Server mit API-Schlüssel.
- Die Knopfsuche arbeitet mit Beschriftungen. Knöpfe ohne Beschriftung oder mit anderer Bezeichnung (je nach Hersteller) werden nicht immer gefunden. Dann erscheint ein Hinweis und man nutzt „Weiter“.
- Für den Play Store muss die Nutzung der Bedienungshilfen später bei Google begründet werden. Für Hilfe-Apps wie diese ist das vorgesehen.

## Aufbau

- `app/src/main/assets/index.html`: die Register-Seite (gleich wie im Browser, mit Verbindung zur App)
- `MainActivity.kt`: zeigt die Seite, Sprachausgabe und Spracheingabe
- `GuideService.kt`: der Bedienungshilfen-Dienst mit Kreis und Hinweisfenster
- `Targets.kt`: übersetzt Ziele wie „Schalter WLAN“ in Suchwörter
- `RingView.kt`: zeichnet den durchsichtigen, pulsierenden Kreis
