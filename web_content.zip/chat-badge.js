
/*
 QUÉ BOLÁ SHOP — ICONO Y CONTADOR DEL CHAT
 Cargar una sola vez desde site-common.js.
 No altera autenticación ni estructura de D1.
*/
(() => {
  "use strict";

  const CHAT_API = "https://que-bola-shop-chat.fonito93punk.workers.dev";
  const READ_PREFIX = "qb_chat_lecturas_v1_";
  const INTERVALO_MS = 45000;

  let temporizador = null;
  let actualizando = false;
  let conversacionesCache = [];

  function leerUsuario() {
    try {
      return JSON.parse(
        localStorage.getItem("que_bola_shop_usuario") || "null"
      );
    } catch (_) {
      return null;
    }
  }

  function idUsuario() {
    const u = leerUsuario();
    const id = u?.id ?? u?.usuario_id ?? u?.user_id;

    return id === null || id === undefined
      ? "actual"
      : String(id);
  }

  function tokenActual() {
    return (
      localStorage.getItem("que_bola_shop_token") ||
      localStorage.getItem("qbshop_token") ||
      ""
    );
  }

  function claveLecturas() {
    return READ_PREFIX + idUsuario();
  }

  function leerCursor() {
    try {
      const v = JSON.parse(
        localStorage.getItem(claveLecturas()) || "{}"
      );

      return v && typeof v === "object" && !Array.isArray(v)
        ? v
        : {};
    } catch (_) {
      return {};
    }
  }

  /* =====================================================
     ESTILOS DEL ICONO Y DEL CONTADOR
     ===================================================== */

  function crearEstilos() {
    if (document.getElementById("qbChatBadgeStyles")) return;

    const style = document.createElement("style");
    style.id = "qbChatBadgeStyles";

    style.textContent = `
      #qbHeaderProfile {
        margin-right: 0 !important;
      }

      #qbHeaderChat {
        position: relative;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        margin: 0 0 0 2px !important;
        padding: 0;
        border: 1px solid #ff7a00;
        border-radius: 10px;
        color: #ff7a00;
        background: #fff;
        text-decoration: none;
        font-size: 21px;
        line-height: 1;
        flex: 0 0 auto;
        box-sizing: border-box;
        vertical-align: middle;
      }

      #qbHeaderChat img {
        display: block;
        width: 24px;
        height: 24px;
        object-fit: contain;
      }

      #qbHeaderChat:hover {
        background: #fff3e8;
      }

      #qbHeaderChatBadge {
        position: absolute;
        top: -5px;
        right: -5px;
        min-width: 18px;
        height: 18px;
        padding: 0 4px;
        border-radius: 10px;
        box-sizing: border-box;
        background: #d90000;
        color: #fff;
        border: 2px solid #fff;
        font: 700 10px/14px Arial, sans-serif;
        text-align: center;
      }

      #qbHeaderChatBadge[hidden] {
        display: none !important;
      }
    `;

    document.head.appendChild(style);
  }

  /* =====================================================
     OBTENER BOTÓN DE PERFIL
     ===================================================== */

  function obtenerBotonPerfil() {
    return document.getElementById("qbHeaderProfile");
  }

  /* =====================================================
     CREAR O RECOLOCAR ICONO DE CHAT
     ===================================================== */

  function asegurarIcono() {
    const perfil = obtenerBotonPerfil();

    if (!perfil || !perfil.parentNode) {
      return null;
    }

    let boton = document.getElementById("qbHeaderChat");

    if (!boton) {
      boton = document.createElement("a");
      boton.id = "qbHeaderChat";
      boton.href = "chat.html";
      boton.setAttribute("aria-label", "Abrir chat");
      boton.title = "Chat y mensajes nuevos";

      boton.innerHTML =
        '<img src="img/icono%20de%20chat.svg" alt="">' +
        '<span id="qbHeaderChatBadge" hidden>0</span>';

      perfil.insertAdjacentElement("afterend", boton);
    } else if (boton.previousElementSibling !== perfil) {
      perfil.insertAdjacentElement("afterend", boton);
    }

    const activo = Boolean(tokenActual());

    boton.style.display = activo ? "inline-flex" : "none";

    return boton;
  }

  /* =====================================================
     OBTENER LISTA DE CONVERSACIONES
     ===================================================== */

  function obtenerLista(datos) {
    if (Array.isArray(datos)) {
      return datos;
    }

    const lista =
      datos?.conversaciones ||
      datos?.chats ||
      datos?.data ||
      [];

    return Array.isArray(lista) ? lista : [];
  }

  /* =====================================================
     CONTAR CONVERSACIONES CON MENSAJES NUEVOS
     ===================================================== */

  function contarConversacionesNoLeidas(conversaciones) {
    const cursores = leerCursor();
    const uid = idUsuario();

    let total = 0;

    for (const chat of conversaciones) {
      const chatId =
        chat?.id ??
        chat?.chat_id ??
        chat?.chatId;

      const ultimoId = Number(
        chat?.ultimo_mensaje_id || 0
      );

      const autor = chat?.ultimo_mensaje_usuario_id;

      if (
        chatId === null ||
        chatId === undefined ||
        !ultimoId ||
        autor === null ||
        autor === undefined
      ) {
        continue;
      }

      const cursor = Number(
        cursores[String(chatId)] || 0
      );

      if (
        ultimoId > cursor &&
        String(autor) !== uid
      ) {
        total++;
      }
    }

    return total;
  }

  /* =====================================================
     ACTUALIZAR CONTADOR VISUAL
     ===================================================== */

  function pintarBadge() {
    const boton = asegurarIcono();

    if (!boton) return;

    const badge = document.getElementById(
      "qbHeaderChatBadge"
    );

    if (!badge) return;

    if (!tokenActual()) {
      badge.hidden = true;
      return;
    }

    const cantidad =
      contarConversacionesNoLeidas(conversacionesCache);

    badge.textContent =
      cantidad > 99 ? "99+" : String(cantidad);

    badge.hidden = cantidad <= 0;

    boton.setAttribute(
      "aria-label",
      cantidad
        ? `Chat, ${cantidad} conversaciones con mensajes nuevos`
        : "Abrir chat"
    );
  }

  /* =====================================================
     CONSULTAR WORKER DE CHAT
     ===================================================== */

  async function actualizarBadge() {
    if (
      actualizando ||
      document.visibilityState !== "visible"
    ) {
      return;
    }

    const token = tokenActual();

    if (!token) {
      conversacionesCache = [];
      pintarBadge();
      return;
    }

    actualizando = true;

    try {
      const respuesta = await fetch(
        CHAT_API + "/conversaciones",
        {
          method: "GET",
          headers: {
            "Authorization": "Bearer " + token
          }
        }
      );

      if (!respuesta.ok) {
        return;
      }

      const datos = await respuesta.json();

      conversacionesCache = obtenerLista(datos);

      pintarBadge();
    } catch (_) {
      // Una desconexión temporal no interrumpe la página.
    } finally {
      actualizando = false;
    }
  }

  /* =====================================================
     INICIAR COMPLEMENTO
     ===================================================== */

  function iniciar() {
    crearEstilos();
    asegurarIcono();
    actualizarBadge();

    if (temporizador) {
      clearInterval(temporizador);
    }

    temporizador = setInterval(() => {
      if (document.visibilityState === "visible") {
        actualizarBadge();
      }
    }, INTERVALO_MS);
  }

  /* =====================================================
     ESCUCHAR CAMBIOS DE SESIÓN Y LECTURAS
     ===================================================== */

  window.addEventListener("storage", event => {
    if (
      event.key === claveLecturas() ||
      event.key === "que_bola_shop_token" ||
      event.key === "qbshop_token" ||
      event.key === "que_bola_shop_usuario"
    ) {
      pintarBadge();

      if (document.visibilityState === "visible") {
        actualizarBadge();
      }
    }
  });

  window.addEventListener(
    "qb:chat-read-state-change",
    pintarBadge
  );

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      actualizarBadge();
    }
  });

  /* =====================================================
     DOM READY
     ===================================================== */

  if (document.readyState === "loading") {
    document.addEventListener(
      "DOMContentLoaded",
      iniciar,
      { once: true }
    );
  } else {
    iniciar();
  }
})();