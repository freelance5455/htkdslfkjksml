export interface UserProfile {
  name: string;
  age: number;
  avatar: string; // emoji icon or id
  joinedAt: string;
  password?: string;
  isGoogleAccount?: boolean;
  googleEmail?: string;
  googleUid?: string;
  photoUrl?: string;
  cloudSynced?: boolean;
}

export interface BilingualText {
  en: string;
  bn: string;
}

export interface BilingualArray {
  en: string[];
  bn: string[];
}

export interface Chapter {
  id: number;
  category: string;
  phase?: number;
  phaseTitle?: BilingualText;
  emoji: string;
  title: BilingualText;
  summary: BilingualText;
  content: BilingualArray;
  keyTakeaway: BilingualText;
  branchingScenario?: {
    scenario: BilingualText;
    choiceA: BilingualText;
    resultA: BilingualText;
    choiceB: BilingualText;
    resultB: BilingualText;
  };
  actionableTakeaways?: BilingualArray;
}

export interface QuizQuestion {
  id: number;
  chapterId: number;
  question: BilingualText;
  options: BilingualArray;
  correctAnswerIndex: number;
  explanation: BilingualText;
}

export interface Helpline {
  name: BilingualText;
  number: string;
  description: BilingualText;
  iconName: string;
}

export interface Note {
  id: string;
  date: string;
  title: string;
  body: string;
  mood: 'happy' | 'brave' | 'nervous' | 'sad' | 'tired';
}

export interface DecisionTree {
  id: string;
  problem: string;
  optionA: {
    text: string;
    pros: string[];
    cons: string[];
  };
  optionB: {
    text: string;
    pros: string[];
    cons: string[];
  };
  timestamp: string;
}

export interface BudgetItem {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
  category: 'allowance' | 'education' | 'snacks' | 'hygiene' | 'savings' | 'hobby' | 'other';
}

export interface Badge {
  id: string;
  title: BilingualText;
  description: BilingualText;
  emoji: string;
}

export interface ProgressState {
  completedChapters: number[]; // ids of completed chapters
  quizAnswers: Record<number, number>; // questionId -> selectedIndex
  quizScores: Record<string, { score: number; total: number; recommendedAction: BilingualText }>; // block name -> score info
  notes: Note[];
  decisions: DecisionTree[];
  budget: BudgetItem[];
  starPoints: number; // custom virtual points rewarded from focus timers or chapter completion!
  timerMinutesCount: number; // total dedicated focus timer minutes
  unlockedBadgeIds: string[];
}
