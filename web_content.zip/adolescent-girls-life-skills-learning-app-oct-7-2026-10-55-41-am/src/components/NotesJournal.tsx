import React, { useState } from 'react';
import { Note } from '../types';
import { BookOpen, StickyNote, Smile, Sparkles, Delete, LayoutGrid, Heart, Trash } from 'lucide-react';

interface NotesJournalProps {
  currentLang: 'en' | 'bn';
  notes: Note[];
  onAddNote: (note: Omit<Note, 'id' | 'date'>) => void;
  onDeleteNote: (id: string) => void;
  onClearNotes: () => void;
}

export default function NotesJournal({
  currentLang,
  notes,
  onAddNote,
  onDeleteNote,
  onClearNotes
}: NotesJournalProps) {
  const [title, setTitle] = useState<string>('');
  const [body, setBody] = useState<string>('');
  const [mood, setMood] = useState<Note['mood']>('happy');

  const label = {
    title: { en: "💎 My Private Self-Care Diary & Journal", bn: "💎 আমার ব্যক্তিগত ডায়েরি ও মনের কথা" },
    subtitle: {
      en: "This notes journal operates entirely offline on your secure phone. Express how you feel, record learning takeaways, and let your mind rest.",
      bn: "এই ডায়েরিটি সম্পূর্ণ সুরক্ষিত এবং কোনো ইন্টারনেট ছাড়া কেবল তোমার ফোনেই সংরক্ষিত থাকে। তোমার খুশি বা কষ্টের কথা নির্দ্বিধায় লিখে রাখো।"
    },
    moodLabel: { en: "Select Your Current Mood:", bn: "আজ তোমার মন কেমন আছে?:" },
    noteTitleLabel: { en: "Title / Today's Topic:", bn: "আজকের মূল বিষয় / টাইটেল:" },
    noteBodyLabel: { en: "Write your feelings or lesson notes here...", bn: "নিজের মনের ভেতরের গল্প বা ক্লাসের শিক্ষার কথা লেখো..." },
    saveBtn: { en: "Save in My Diary", bn: "ডায়েরি পাতায় সংরক্ষণ করো" },
    saveSuccess: { en: "Diary Page Saved!", bn: "মনের কথা সফলভাবে ডায়েরিতে লেখা হয়েছে!" },
    diaryHeader: { en: "My Diary Pages Log", bn: "আমার ডায়েরি খাতা" },
    noNotes: { en: "No journal pages written yet. Write your thoughts above to start!", bn: "খাতাটি এখনও ফাঁকা আছে। তোমার প্রথম দিনের অনুভূতির কথা লিখে খাতা খোলা শুরু করো!" },
    clearBtn: { en: "Erase All Pages", bn: "সমগ্র ডায়েরি মুছে ফেলো" },
    moodHappy: { en: "Happy 🌸", bn: "খুশি ও প্রফুল্ল 🌸" },
    moodBrave: { en: "Brave 💪", bn: "সাহসী ও তেজস্বী 💪" },
    moodNervous: { en: "Nervous 🥺", bn: "ভয় বা অস্বস্তি 🥺" },
    moodSad: { en: "Sad 💧", bn: "মন খারাপ 💧" },
    moodTired: { en: "Tired 🥱", bn: "ক্লান্ত 🥱" }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;
    
    onAddNote({
      title: title.trim(),
      body: body.trim(),
      mood
    });

    setTitle('');
    setBody('');
    setMood('happy');
  };

  const MOODS: { type: Note['mood']; emoji: string; text: { en: string, bn: string }; colorClass: string }[] = [
    { type: 'happy', emoji: '🌸', text: label.moodHappy, colorClass: 'bg-emerald-50 text-emerald-800 border-emerald-250 ring-emerald-500' },
    { type: 'brave', emoji: '💪', text: label.moodBrave, colorClass: 'bg-indigo-50 text-indigo-800 border-indigo-250 ring-indigo-500' },
    { type: 'nervous', emoji: '🥺', text: label.moodNervous, colorClass: 'bg-amber-50 text-amber-800 border-amber-250 ring-amber-500' },
    { type: 'sad', emoji: '💧', text: label.moodSad, colorClass: 'bg-sky-50 text-sky-800 border-sky-250 ring-sky-500' },
    { type: 'tired', emoji: '🥱', text: label.moodTired, colorClass: 'bg-slate-50 text-slate-800 border-slate-250 ring-slate-500' }
  ];

  return (
    <div id="notes-journal-card" className="bg-white p-4 md:p-6 rounded-2xl border border-slate-200 shadow-xs max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div>
        <h3 className="text-md font-extrabold text-slate-900 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-indigo-600" />
          {label.title[currentLang]}
        </h3>
        <p className="text-xs text-slate-600 mt-1 lines-spaced font-sans font-normal">
          {label.subtitle[currentLang]}
        </p>
      </div>

      {/* Main split work area */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Write Entry */}
        <form onSubmit={handleSave} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
          <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-pink-500 fill-pink-50" />
            {currentLang === 'en' ? "Pen an Entry" : "নতুন ডায়েরি পাতা লেখো"}
          </h4>

          {/* Mood Selection */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-extrabold text-slate-600 uppercase">
              {label.moodLabel[currentLang]}
            </label>
            <div className="flex flex-wrap gap-1.5">
              {MOODS.map((m) => (
                <button
                  key={m.type}
                  type="button"
                  onClick={() => setMood(m.type)}
                  className={`py-1.5 px-3 rounded-lg border text-xs font-bold flex items-center gap-1 cursor-pointer transition-all ${
                    mood === m.type 
                      ? `${m.colorClass} border-slate-900 scale-102 font-black ring-2 ring-offset-1`
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <span className="text-sm select-none">{m.emoji}</span>
                  <span>{m.text[currentLang]}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-600 uppercase">
              {label.noteTitleLabel[currentLang]}
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={currentLang === 'en' ? "e.g., Today's Communication Class" : "যেমন: আজকের ক্লাস ও মাসিকের পরিচ্ছন্নতা..."}
              className="w-full text-xs p-2.5 border border-slate-200 rounded-lg bg-white focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-600 uppercase">
              {currentLang === 'en' ? "Diary Text Body:" : "ডায়েরি পাতায় বিস্তারিত:"}
            </label>
            <textarea
              required
              rows={4}
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder={label.noteBodyLabel[currentLang]}
              className="w-full text-xs p-2.5 border border-slate-200 rounded-lg bg-white focus:ring-1 focus:ring-indigo-500 font-sans leading-relaxed"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-lg shadow-sm cursor-pointer transition-colors"
          >
            {label.saveBtn[currentLang]}
          </button>
        </form>

        {/* Saved notes List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between border-b border-slate-150 pb-1">
            <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1">
              <StickyNote className="w-4 h-4 text-indigo-600" />
              {label.diaryHeader[currentLang]} ({notes.length})
            </h4>
            {notes.length > 0 && (
              <button
                type="button"
                onClick={onClearNotes}
                className="text-[10px] font-extrabold text-rose-600 hover:underline cursor-pointer"
              >
                {label.clearBtn[currentLang]}
              </button>
            )}
          </div>

          {notes.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <span className="block text-4xl">🗒️</span>
              <p className="text-xs text-slate-400 font-sans italic px-6 leading-relaxed">
                {label.noNotes[currentLang]}
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
              {notes.map((n) => {
                const moodObj = MOODS.find(m => m.type === n.mood);
                return (
                  <div key={n.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2 relative">
                    
                    <button
                      type="button"
                      onClick={() => onDeleteNote(n.id)}
                      className="absolute right-3 top-3 text-slate-300 hover:text-rose-600 transition-colors cursor-pointer p-1"
                    >
                      <Trash className="w-3.5 h-3.5" />
                    </button>

                    <div className="flex items-center gap-2">
                      <span className="text-sm select-none" title={n.mood}>
                        {moodObj?.emoji || '🌸'}
                      </span>
                      <div>
                        <h5 className="text-xs font-black text-slate-900">{n.title}</h5>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">{n.date}</p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-700 font-sans font-normal leading-relaxed whitespace-pre-wrap">
                      {n.body}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
