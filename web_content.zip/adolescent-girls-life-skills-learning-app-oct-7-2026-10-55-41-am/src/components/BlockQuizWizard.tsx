import React, { useState } from 'react';
import { QuizQuestion } from '../types';
import { CheckCircle, XCircle, ArrowRight, RotateCcw, Award, ChevronLeft, ChevronRight } from 'lucide-react';

interface BlockQuizWizardProps {
  blockType: string;
  title?: string;
  questions: QuizQuestion[];
  currentLang: 'en' | 'bn';
  selectedAnswers: Record<number, number>;
  selectAnswer: (questionId: number, optionIndex: number) => void;
  onSubmit: () => void;
  quizScore?: {
    score: number;
    total: number;
    recommendedAction: {
      en: string;
      bn: string;
    };
  };
  onReset: () => void;
}

export default function BlockQuizWizard({
  blockType,
  title,
  questions,
  currentLang,
  selectedAnswers,
  selectAnswer,
  onSubmit,
  quizScore,
  onReset
}: BlockQuizWizardProps) {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [showFeedback, setShowFeedback] = useState<boolean>(false);
  const [reviewMode, setReviewMode] = useState<boolean>(false);

  const currentQuestion = questions[currentIdx];
  const totalQuestions = questions.length;
  const selectedOption = selectedAnswers[currentQuestion?.id];

  // If the user has already submitted the quiz, show the results summary
  if (quizScore && !reviewMode) {
    const isPerfect = quizScore.score === quizScore.total;
    return (
      <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-150 shadow-sm space-y-6 animate-fadeIn">
        <div className="text-center space-y-3">
          <div className="inline-flex p-4 bg-amber-50 rounded-full text-amber-500 animate-bounce">
            <Award className="w-12 h-12" />
          </div>
          <h3 className="text-lg md:text-xl font-black text-slate-900">
            {title ? `${title} ${currentLang === 'en' ? "Completed!" : "সম্পূর্ণ হয়েছে!"}` : (currentLang === 'en' ? "Quiz Block Completed!" : "কুইজ ব্লক সম্পূর্ণ হয়েছে!")}
          </h3>
          <div className="inline-block py-1.5 px-4 bg-indigo-50 border border-indigo-150 rounded-2xl">
            <span className="text-sm font-extrabold text-indigo-900">
              {currentLang === 'en'
                ? `Your Score: ${quizScore.score} / ${quizScore.total} Correct!`
                : `তোমার প্রাপ্ত নম্বর: ${quizScore.total} এর মধ্যে ${quizScore.score} সঠিক!`
              }
            </span>
          </div>
          {isPerfect && (
            <p className="text-xs text-emerald-700 font-extrabold">
              🏆 {currentLang === 'en' ? "PERFECT SCORE! BONUS STARS AWARDED!" : "দুর্দান্ত স্কোর! অতিরিক্ত উপহার স্টার যোগ হয়েছে!"}
            </p>
          )}
        </div>

        <div className="p-5 bg-indigo-50/50 border border-indigo-100 rounded-2xl space-y-4">
          <p className="text-xs md:text-sm text-indigo-950 leading-relaxed font-sans font-medium">
            <strong>{currentLang === 'en' ? "NGO Advisor Recommendation:" : "শিক্ষিকা মণ্ডলীর সুপারিশ:"}</strong>{' '}
            {quizScore.recommendedAction[currentLang] || quizScore.recommendedAction.en}
          </p>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              id={`btn-review-${blockType}`}
              onClick={() => {
                setCurrentIdx(0);
                setReviewMode(true);
              }}
              className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-all cursor-pointer text-center"
            >
              🔍 {currentLang === 'en' ? "Review All Answers" : "সব উত্তরগুলো মেলাও"}
            </button>
            <button
              id={`btn-reset-${blockType}`}
              onClick={() => {
                onReset();
                setCurrentIdx(0);
                setShowFeedback(false);
                setReviewMode(false);
              }}
              className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer text-center flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" />
              {currentLang === 'en' ? "Re-attempt this Quiz Match" : "আবার পরীক্ষাটি দিতে চাও"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Handle option selection during active testing
  const handleSelectOption = (optIdx: number) => {
    if (showFeedback || reviewMode) return; // Prevent double selecting
    selectAnswer(currentQuestion.id, optIdx);
    setShowFeedback(true);
  };

  const handleNext = () => {
    if (currentIdx < totalQuestions - 1) {
      setCurrentIdx(prev => prev + 1);
      // If we already have answered this in the past, or in review mode
      setShowFeedback(selectedAnswers[questions[currentIdx + 1].id] !== undefined);
    } else if (!reviewMode) {
      onSubmit();
    }
  };

  const handlePrev = () => {
    if (currentIdx > 0) {
      setCurrentIdx(prev => prev - 1);
      setShowFeedback(true); // Since previous must have been answered
    }
  };

  const isCurrentCorrect = selectedOption === currentQuestion?.correctAnswerIndex;

  return (
    <div className="bg-white p-5 md:p-6 rounded-2xl border border-slate-200 shadow-xs space-y-6 animate-fadeIn">
      {/* Header Info */}
      <div className="flex justify-between items-center pb-3 border-b border-slate-100 flex-wrap gap-2">
        <div className="space-y-0.5">
          <span className="text-[10px] font-mono font-bold uppercase text-indigo-600 tracking-wider">
            {reviewMode 
              ? (currentLang === 'en' ? "Reviewing Answers" : "উত্তরগুলো দেখা হচ্ছে")
              : (currentLang === 'en' ? "Active Quiz Session" : "চলতি পরীক্ষা")
            }
          </span>
          <h4 className="text-xs font-black text-slate-800">
            {currentLang === 'en' ? `Question ${currentIdx + 1} of ${totalQuestions}` : `প্রশ্ন নং ${currentIdx + 1} (মোট ${totalQuestions} এর মধ্যে)`}
          </h4>
        </div>
        {/* Progress Dots/Bar */}
        <div className="flex gap-1">
          {questions.map((_, idx) => {
            const isAnswered = selectedAnswers[questions[idx].id] !== undefined;
            const isCurrent = idx === currentIdx;
            return (
              <div
                key={idx}
                className={`w-2.5 h-2.5 rounded-full transition-all ${
                  isCurrent 
                    ? 'bg-indigo-600 ring-2 ring-indigo-200 scale-110' 
                    : isAnswered 
                      ? 'bg-emerald-500' 
                      : 'bg-slate-200'
                }`}
              />
            );
          })}
        </div>
      </div>

      {/* Question Text */}
      <div className="space-y-4">
        <p className="text-sm md:text-base font-extrabold text-slate-900 leading-snug">
          Q{currentQuestion.id}. {currentQuestion.question[currentLang]}
        </p>

        {/* Option Cards */}
        <div className="grid grid-cols-1 gap-3">
          {currentQuestion.options[currentLang].map((opt, oIdx) => {
            const isSelected = selectedOption === oIdx;
            const isCorrectOption = oIdx === currentQuestion.correctAnswerIndex;
            
            let cardClass = "bg-white hover:bg-slate-50 border-slate-200 text-slate-800";
            let iconElement = null;

            if (showFeedback || reviewMode) {
              if (isCorrectOption) {
                cardClass = "bg-emerald-50 border-emerald-400 text-emerald-950 font-extrabold ring-1 ring-emerald-300";
                iconElement = <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />;
              } else if (isSelected) {
                cardClass = "bg-rose-50 border-rose-400 text-rose-950 font-extrabold ring-1 ring-rose-300";
                iconElement = <XCircle className="w-5 h-5 text-rose-600 shrink-0" />;
              } else {
                cardClass = "bg-slate-50 border-slate-100 text-slate-400 pointer-events-none";
              }
            } else if (isSelected) {
              cardClass = "bg-indigo-600 border-indigo-700 text-white font-extrabold shadow-sm";
            }

            return (
              <button
                key={oIdx}
                id={`btn-q-${currentQuestion.id}-opt-${oIdx}`}
                disabled={showFeedback || reviewMode}
                onClick={() => handleSelectOption(oIdx)}
                className={`p-3.5 rounded-xl border text-left text-xs md:text-sm transition-all flex justify-between items-center gap-3 cursor-pointer ${cardClass}`}
              >
                <span>{opt}</span>
                {iconElement}
              </button>
            );
          })}
        </div>
      </div>

      {/* Immediate Explanation Box */}
      {showFeedback && (
        <div className={`p-4 rounded-xl border animate-fadeIn space-y-2 ${
          isCurrentCorrect ? 'bg-emerald-50/50 border-emerald-100 text-emerald-950' : 'bg-amber-50/50 border-amber-100 text-amber-950'
        }`}>
          <div className="flex items-center gap-2 font-black text-xs md:text-sm">
            {isCurrentCorrect ? (
              <>
                <CheckCircle className="w-5 h-5 text-emerald-600" />
                <span>{currentLang === 'en' ? "Excellent, Correct! 🎉" : "চমৎকার, একদম সঠিক! 🎉"}</span>
              </>
            ) : (
              <>
                <XCircle className="w-5 h-5 text-rose-500" />
                <span>{currentLang === 'en' ? "Let's learn the correct answer:" : "সঠিক উত্তরটি দেখে নিই:"}</span>
              </>
            )}
          </div>
          <p className="text-xs font-sans leading-relaxed">
            💡 <strong>{currentLang === 'en' ? "Explanation:" : "ব্যাখ্যা:"}</strong> {currentQuestion.explanation[currentLang]}
          </p>
        </div>
      )}

      {/* Wizard Footer Controls */}
      <div className="flex justify-between items-center pt-2">
        {/* Previous Button (Only in review mode or if we want back tracking) */}
        {reviewMode ? (
          <button
            onClick={handlePrev}
            disabled={currentIdx === 0}
            className={`py-2 px-4 rounded-xl text-xs font-black flex items-center gap-1 cursor-pointer transition-all ${
              currentIdx === 0 ? 'bg-slate-100 text-slate-300 pointer-events-none' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            {currentLang === 'en' ? "Previous" : "আগেরটি"}
          </button>
        ) : (
          <div /> // Placeholder to keep Next button aligned right
        )}

        {/* Close Review Button */}
        {reviewMode && (
          <button
            onClick={() => setReviewMode(false)}
            className="py-2 px-4 bg-slate-900 hover:bg-slate-800 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer"
          >
            {currentLang === 'en' ? "Back to Summary" : "সারসংক্ষেপে ফেরো"}
          </button>
        )}

        {/* Next / Submit Button */}
        {(!reviewMode && selectedOption === undefined) ? (
          <span className="text-[11px] text-slate-400 italic">
            {currentLang === 'en' ? "Please select an answer above to continue" : "এগিয়ে যেতে উপরে যেকোনো একটি উত্তর নির্বাচন করো"}
          </span>
        ) : (
          <button
            onClick={handleNext}
            className="py-2.5 px-5 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span>
              {currentIdx < totalQuestions - 1 
                ? (currentLang === 'en' ? "Next Question" : "পরের প্রশ্ন")
                : reviewMode 
                  ? (currentLang === 'en' ? "Finish Review" : "রিভিউ শেষ করো")
                  : (currentLang === 'en' ? "Finish & Submit 🏁" : "কুইজ খাতা জমা দিন 🏁")
              }
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
}
