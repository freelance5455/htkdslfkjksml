import React, { useState } from 'react';
import { Chapter, QuizQuestion, BilingualText, BilingualArray } from '../types';
import * as mammoth from 'mammoth';
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  RefreshCw, 
  Download, 
  BookOpen, 
  HelpCircle, 
  X,
  Sparkles,
  Layers
} from 'lucide-react';
import { LIFE_SKILLS_CHAPTERS, QUIZ_QUESTIONS } from '../chaptersData';

interface CourseDocumentImporterProps {
  currentLang: 'en' | 'bn';
  isOpen: boolean;
  onClose: () => void;
  onUpdateCourse: (newChapters: Chapter[], newQuizzes: QuizQuestion[]) => void;
  currentChaptersCount: number;
  currentQuizzesCount: number;
}

export default function CourseDocumentImporter({
  currentLang,
  isOpen,
  onClose,
  onUpdateCourse,
  currentChaptersCount,
  currentQuizzesCount
}: CourseDocumentImporterProps) {
  const [activeTab, setActiveTab] = useState<'upload' | 'paste' | 'json' | 'preview'>('upload');
  const [inputText, setInputText] = useState<string>('');
  const [fileName, setFileName] = useState<string>('');
  const [parsingStatus, setParsingStatus] = useState<string>('');
  const [parsedChapters, setParsedChapters] = useState<Chapter[]>([]);
  const [parsedQuizzes, setParsedQuizzes] = useState<QuizQuestion[]>([]);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');

  if (!isOpen) return null;

  // Handle Word docx file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setErrorMsg('');
    setSuccessMsg('');
    setParsingStatus(currentLang === 'en' ? 'Reading Word document...' : 'ডকুমেন্ট পড়া হচ্ছে...');

    try {
      if (file.name.endsWith('.docx')) {
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        const rawText = result.value;
        setInputText(rawText);
        parseReportText(rawText);
      } else if (file.name.endsWith('.json')) {
        const text = await file.text();
        setInputText(text);
        parseJsonData(text);
      } else {
        // Plain text or markdown
        const text = await file.text();
        setInputText(text);
        parseReportText(text);
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(
        currentLang === 'en'
          ? `Failed to read document: ${err.message || 'Unknown error'}`
          : `ডকুমেন্ট পড়তে সমস্যা হয়েছে: ${err.message || 'ত্রুটি'}`
      );
    } finally {
      setParsingStatus('');
    }
  };

  // Helper to parse JSON
  const parseJsonData = (rawJson: string) => {
    try {
      const data = JSON.parse(rawJson);
      let ch: Chapter[] = [];
      let qu: QuizQuestion[] = [];

      if (Array.isArray(data)) {
        ch = data;
      } else if (data.chapters && Array.isArray(data.chapters)) {
        ch = data.chapters;
        if (data.quiz_questions && Array.isArray(data.quiz_questions)) {
          qu = data.quiz_questions;
        }
      }

      if (ch.length > 0) {
        setParsedChapters(ch);
        setParsedQuizzes(qu);
        setActiveTab('preview');
        setSuccessMsg(
          currentLang === 'en'
            ? `Successfully detected ${ch.length} chapters and ${qu.length} quizzes!`
            : `${ch.length}টি অধ্যায় এবং ${qu.length}টি কুইজ সফলভাবে পাওয়া গেছে!`
        );
      } else {
        setErrorMsg(
          currentLang === 'en'
            ? 'No valid chapters array found in JSON file.'
            : 'JSON ফাইলে সঠিক অধ্যায় তালিকা পাওয়া যায়নি।'
        );
      }
    } catch (err: any) {
      setErrorMsg(
        currentLang === 'en' ? `Invalid JSON syntax: ${err.message}` : `ভুল JSON ফরম্যাট: ${err.message}`
      );
    }
  };

  // Intelligent text parser for NotebookLLM report / Word docs
  const parseReportText = (text: string) => {
    setErrorMsg('');
    setSuccessMsg('');
    if (!text || text.trim().length < 50) {
      setErrorMsg(
        currentLang === 'en'
          ? 'The document text is too short. Please provide the full report.'
          : 'ডকুমেন্টে পর্যাপ্ত তথ্য নেই। অনুগ্রহ করে পূর্ণাঙ্গ রিপোর্ট প্রদান করুন।'
      );
      return;
    }

    // Split text into lines
    const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const chapters: Chapter[] = [];
    const quizzes: QuizQuestion[] = [];

    let currentChapter: Partial<Chapter> | null = null;
    let currentContentEn: string[] = [];
    let currentContentBn: string[] = [];
    let currentQuestions: Partial<QuizQuestion>[] = [];
    let currentQ: Partial<QuizQuestion> | null = null;

    // Regex matchers
    const chapterHeaderRegex = /^(?:Chapter|অধ্যায়|পাঠ|Module)\s*(\d+)[:\.\s]*(.*)/i;
    const questionRegex = /^(?:Question|প্রশ্ন|Q\s*\d*|\d+[\.\)])[:\s]*(.*)/i;
    const optionRegex = /^([A-D]|[ক-ঘ]|\d+)[\.\)]\s*(.*)/i;

    let questionIdCounter = 1;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Check for chapter header
      const chapMatch = line.match(chapterHeaderRegex);
      if (chapMatch) {
        // Save previous chapter if exists
        if (currentChapter && currentChapter.id) {
          chapters.push({
            id: currentChapter.id,
            category: currentChapter.category || 'life-skills',
            phase: currentChapter.phase || Math.ceil(currentChapter.id / 3.5),
            phaseTitle: currentChapter.phaseTitle || {
              en: `Phase ${Math.ceil(currentChapter.id / 3.5)}`,
              bn: `পর্যায় ${Math.ceil(currentChapter.id / 3.5)}`
            },
            emoji: currentChapter.emoji || '📖',
            title: currentChapter.title || { en: `Chapter ${currentChapter.id}`, bn: `অধ্যায় ${currentChapter.id}` },
            summary: currentChapter.summary || {
              en: currentContentEn.slice(0, 2).join(' ') || 'Chapter reading module.',
              bn: currentContentBn.slice(0, 2).join(' ') || 'শিক্ষামূলক পাঠ।'
            },
            content: {
              en: currentContentEn.length > 0 ? currentContentEn : ['Study the core concepts of this lesson.'],
              bn: currentContentBn.length > 0 ? currentContentBn : ['এই পাঠের মূল নীতিগুলো নিয়মিত চর্চা করো।']
            },
            keyTakeaway: currentChapter.keyTakeaway || {
              en: 'Believe in your inner strength and practice healthy life skills daily.',
              bn: 'নিজের ভেতরের শক্তিতে বিশ্বাস রাখো এবং প্রতিদিন স্বাস্থ্যকর জীবনশৈলী চর্চা করো।'
            }
          });
        }

        const chNum = parseInt(chapMatch[1], 10) || (chapters.length + 1);
        const titleRaw = chapMatch[2]?.trim() || `Chapter ${chNum}`;

        currentChapter = {
          id: chNum,
          category: chNum > 13 ? 'health' : 'life-skills',
          phase: Math.ceil(chNum / 3.5),
          emoji: chNum <= 3 ? '🌸' : chNum <= 7 ? '💬' : chNum <= 10 ? '🌱' : chNum <= 13 ? '🧭' : chNum <= 16 ? '🌺' : '⚖️',
          title: {
            en: titleRaw,
            bn: titleRaw // fallback
          }
        };
        currentContentEn = [];
        currentContentBn = [];
        continue;
      }

      // Check if line is quiz question
      const qMatch = line.match(questionRegex);
      if (qMatch && (line.includes('?') || line.toLowerCase().includes('which') || line.toLowerCase().includes('what') || line.includes('কোনটি') || line.includes('কী'))) {
        if (currentQ && currentQ.question && currentQ.options) {
          quizzes.push({
            id: questionIdCounter++,
            chapterId: currentChapter?.id || (chapters.length || 1),
            question: currentQ.question as BilingualText,
            options: currentQ.options as BilingualArray,
            correctAnswerIndex: currentQ.correctAnswerIndex ?? 0,
            explanation: currentQ.explanation || {
              en: 'Always choose the safe, respectful, and empowering approach.',
              bn: 'সর্বদা নিরাপদ, আত্মমর্যাদাসম্পন্ন ও সচেতন সিদ্ধান্ত বেছে নাও।'
            }
          });
        }
        currentQ = {
          chapterId: currentChapter?.id || (chapters.length || 1),
          question: { en: qMatch[1], bn: qMatch[1] },
          options: { en: [], bn: [] },
          correctAnswerIndex: 0
        };
        continue;
      }

      // Check if option in quiz
      const optMatch = line.match(optionRegex);
      if (currentQ && optMatch) {
        const optText = optMatch[2].trim();
        (currentQ.options as any).en.push(optText);
        (currentQ.options as any).bn.push(optText);
        continue;
      }

      // If regular paragraph text
      if (currentChapter) {
        if (/[\u0980-\u09FF]/.test(line)) {
          currentContentBn.push(line);
        } else {
          currentContentEn.push(line);
        }
      }
    }

    // Flush last chapter
    if (currentChapter && currentChapter.id) {
      chapters.push({
        id: currentChapter.id,
        category: currentChapter.category || 'life-skills',
        phase: currentChapter.phase || Math.ceil(currentChapter.id / 3.5),
        phaseTitle: currentChapter.phaseTitle || {
          en: `Phase ${Math.ceil(currentChapter.id / 3.5)}`,
          bn: `পর্যায় ${Math.ceil(currentChapter.id / 3.5)}`
        },
        emoji: currentChapter.emoji || '📖',
        title: currentChapter.title || { en: `Chapter ${currentChapter.id}`, bn: `অধ্যায় ${currentChapter.id}` },
        summary: currentChapter.summary || {
          en: currentContentEn.slice(0, 2).join(' ') || 'Chapter reading module.',
          bn: currentContentBn.slice(0, 2).join(' ') || 'শিক্ষামূলক পাঠ।'
        },
        content: {
          en: currentContentEn.length > 0 ? currentContentEn : ['Study the core concepts of this lesson.'],
          bn: currentContentBn.length > 0 ? currentContentBn : ['এই পাঠের মূল নীতিগুলো নিয়মিত চর্চা করো।']
        },
        keyTakeaway: currentChapter.keyTakeaway || {
          en: 'Believe in your inner strength and practice healthy life skills daily.',
          bn: 'নিজের ভেতরের শক্তিতে বিশ্বাস রাখো এবং প্রতিদিন স্বাস্থ্যকর জীবনশৈলী চর্চা করো।'
        }
      });
    }

    // Flush last quiz
    if (currentQ && currentQ.question && (currentQ.options as any)?.en?.length >= 2) {
      quizzes.push({
        id: questionIdCounter++,
        chapterId: currentChapter?.id || (chapters.length || 1),
        question: currentQ.question as BilingualText,
        options: currentQ.options as BilingualArray,
        correctAnswerIndex: currentQ.correctAnswerIndex ?? 0,
        explanation: currentQ.explanation || {
          en: 'Always choose the safe, respectful, and empowering approach.',
          bn: 'সর্বদা নিরাপদ, আত্মমর্যাদাসম্পন্ন ও সচেতন সিদ্ধান্ত বেছে নাও।'
        }
      });
    }

    // If text parser found few or 0 chapters, but text contains good info, provide helpful guidance
    if (chapters.length === 0) {
      setErrorMsg(
        currentLang === 'en'
          ? 'Could not automatically identify chapter headings (e.g., "Chapter 1: ..."). Please format chapters with "Chapter X:" or paste JSON.'
          : 'স্বয়ংক্রিয়ভাবে অধ্যায়ের শিরোনাম (যেমন "Chapter 1:" বা "অধ্যায় ১:") খুঁজে পাওয়া যায়নি। অনুগ্রহ করে শিরোনাম ঠিক রেখে চেষ্টা করুন।'
      );
    } else {
      setParsedChapters(chapters);
      setParsedQuizzes(quizzes);
      setActiveTab('preview');
      setSuccessMsg(
        currentLang === 'en'
          ? `Parsed ${chapters.length} chapters and ${quizzes.length} quiz questions!`
          : `${chapters.length}টি অধ্যায় ও ${quizzes.length}টি কুইজ শনাক্ত করা হয়েছে!`
      );
    }
  };

  // Reset to the official 21-chapter curriculum
  const handleResetToOfficialCurriculum = () => {
    onUpdateCourse(LIFE_SKILLS_CHAPTERS, QUIZ_QUESTIONS);
    setSuccessMsg(
      currentLang === 'en'
        ? `Course reset to official 21-Chapter NotebookLLM Curriculum (${LIFE_SKILLS_CHAPTERS.length} chapters, ${QUIZ_QUESTIONS.length} quizzes)!`
        : `পাঠক্রম সফলভাবে ২১টি অফিশিয়াল অধ্যায় এবং ৬৭টি কুইজে আপডেট করা হয়েছে!`
    );
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  // Save the parsed data to the live course
  const handleApplyChanges = () => {
    if (parsedChapters.length === 0) {
      setErrorMsg(
        currentLang === 'en'
          ? 'No parsed chapters to apply. Please upload or paste a document first.'
          : 'প্রয়োগ করার জন্য কোনো অধ্যায় নেই। অনুগ্রহ করে প্রথমে ডকুমেন্ট আপলোড করুন।'
      );
      return;
    }

    onUpdateCourse(parsedChapters, parsedQuizzes.length > 0 ? parsedQuizzes : QUIZ_QUESTIONS);
    setSuccessMsg(
      currentLang === 'en'
        ? `Course successfully updated with ${parsedChapters.length} chapters!`
        : `পাঠক্রম সফলভাবে ${parsedChapters.length}টি অধ্যায়ে আপডেট করা হয়েছে!`
    );
    setTimeout(() => {
      onClose();
    }, 1500);
  };

  // Download currently active course as JSON
  const handleExportJson = () => {
    const data = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      chapters: LIFE_SKILLS_CHAPTERS,
      quiz_questions: QUIZ_QUESTIONS
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shokhi_curriculum_21_chapters_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-slate-900/70 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[92vh] flex flex-col overflow-hidden">
        
        {/* Header */}
        <div className="p-5 md:p-6 bg-gradient-to-r from-indigo-700 via-purple-700 to-pink-700 text-white flex justify-between items-start gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              {currentLang === 'en' ? 'Curriculum Manager & Word (.docx) Importer' : 'পাঠক্রম পরিচালক ও ওয়ার্ড ডকুমেন্ট আপলোডার'}
            </div>
            <h2 className="text-lg md:text-xl font-black">
              {currentLang === 'en' ? 'Update Life Skills Course from Word / Report' : 'ওয়ার্ড বা নোটবুকএলএলএম রিপোর্ট থেকে সম্পূর্ণ কোর্স আপডেট'}
            </h2>
            <p className="text-xs text-indigo-100 max-w-2xl leading-relaxed">
              {currentLang === 'en'
                ? `Currently running ${currentChaptersCount} chapters and ${currentQuizzesCount} interactive quizzes. You can upload a Word (.docx) file, paste text from NotebookLLM, or reset to the full 21-chapter curriculum.`
                : `বর্তমানে অ্যাপটিতে ${currentChaptersCount}টি অধ্যায় ও ${currentQuizzesCount}টি কুইজ সক্রিয় আছে। আপনি ওয়ার্ড (.docx) ফাইল আপলোড করে বা টেক্সট পেস্ট করে সম্পূর্ণ কোর্স এক ক্লিকেই আপডেট করতে পারেন।`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white hover:bg-white/20 rounded-xl transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Bar */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 gap-2 pt-3">
          <button
            onClick={() => setActiveTab('upload')}
            className={`pb-3 px-4 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border-b-2 ${
              activeTab === 'upload'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Upload className="w-4 h-4" />
            {currentLang === 'en' ? 'Upload Word (.docx) / File' : 'ওয়ার্ড ফাইল (.docx) আপলোড'}
          </button>

          <button
            onClick={() => setActiveTab('paste')}
            className={`pb-3 px-4 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border-b-2 ${
              activeTab === 'paste'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            {currentLang === 'en' ? 'Paste NotebookLLM Report' : 'রিপোর্ট টেক্সট পেস্ট করুন'}
          </button>

          <button
            onClick={() => setActiveTab('preview')}
            className={`pb-3 px-4 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border-b-2 ${
              activeTab === 'preview'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            {currentLang === 'en' ? `Preview Extracted (${parsedChapters.length} Ch)` : `প্রিভিউ দেখুন (${parsedChapters.length}টি অধ্যায়)`}
          </button>

          <button
            onClick={() => setActiveTab('json')}
            className={`pb-3 px-4 text-xs font-bold flex items-center gap-1.5 transition-all cursor-pointer border-b-2 ${
              activeTab === 'json'
                ? 'border-indigo-600 text-indigo-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Download className="w-4 h-4" />
            {currentLang === 'en' ? 'Export / JSON Tools' : 'JSON এক্সপোর্ট ও টুলস'}
          </button>
        </div>

        {/* Status Alerts */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="mx-6 mt-4 p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs rounded-xl flex items-center gap-2 font-medium">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tab Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* TAB 1: FILE UPLOAD */}
          {activeTab === 'upload' && (
            <div className="space-y-6">
              <div className="border-2 border-dashed border-indigo-200 hover:border-indigo-400 bg-indigo-50/40 rounded-3xl p-8 text-center space-y-4 transition-colors">
                <div className="w-16 h-16 bg-white rounded-2xl shadow-sm text-indigo-600 flex items-center justify-center mx-auto">
                  <Upload className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-base font-extrabold text-slate-900">
                    {currentLang === 'en' ? 'Select your Word Document (.docx) or JSON File' : 'আপনার ওয়ার্ড ফাইল (.docx) অথবা JSON নির্বাচন করুন'}
                  </h3>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    {currentLang === 'en'
                      ? 'The built-in parser will read the document, recognize chapters and end-of-chapter quiz questions, and prepare them for your course.'
                      : 'স্বয়ংক্রিয় ওয়ার্ড পার্সার ফাইলটি পড়ে অধ্যায় ও কুইজগুলো সাজিয়ে প্রস্তুত করবে।'}
                  </p>
                </div>

                <div className="pt-2">
                  <label className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all">
                    <Upload className="w-4 h-4" />
                    <span>{currentLang === 'en' ? 'Browse Files from Computer' : 'কম্পিউটার থেকে ফাইল বেছে নিন'}</span>
                    <input
                      type="file"
                      accept=".docx,.json,.txt,.doc"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  {fileName && (
                    <div className="mt-3 text-xs font-bold text-indigo-800 bg-indigo-100/70 inline-block px-3 py-1 rounded-lg">
                      📄 {fileName}
                    </div>
                  )}
                </div>

                {parsingStatus && (
                  <div className="text-xs text-indigo-700 font-bold flex items-center justify-center gap-2 animate-pulse">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{parsingStatus}</span>
                  </div>
                )}
              </div>

              {/* Quick Preset: 21-Chapter Official Curriculum */}
              <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-150 p-5 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 text-purple-900 text-xs font-extrabold">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    {currentLang === 'en' ? 'Instant 21-Chapter NotebookLLM Curriculum' : 'এক ক্লিকে সম্পূর্ণ ২১ অধ্যায়ের পাঠক্রম লোড করুন'}
                  </div>
                  <p className="text-xs text-slate-600">
                    {currentLang === 'en'
                      ? 'Already have all 21 chapters with 67 quizzes ready extracted in the app.'
                      : 'অ্যাপে ইতিমধ্যেই ২১টি অধ্যায় ও ৬৭টি কুইজ সাজানো রয়েছে।'}
                  </p>
                </div>
                <button
                  onClick={handleResetToOfficialCurriculum}
                  className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white text-xs font-extrabold rounded-xl shadow-xs transition-all cursor-pointer whitespace-nowrap"
                >
                  🚀 {currentLang === 'en' ? 'Load 21 Chapters & 67 Quizzes' : '২১টি অধ্যায় ও কুইজ লোড করো'}
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: PASTE REPORT TEXT */}
          {activeTab === 'paste' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-800">
                  {currentLang === 'en'
                    ? 'Paste your NotebookLLM Report / Chapter Text here:'
                    : 'আপনার NotebookLLM রিপোর্ট বা পাঠের টেক্সট এখানে পেস্ট করুন:'}
                </label>
                <p className="text-[11px] text-slate-500">
                  {currentLang === 'en'
                    ? 'Tip: Format chapters with "Chapter 1: Title", "Chapter 2: Title", followed by reading content and end-of-chapter questions.'
                    : 'পরামর্শ: "Chapter 1: শিরোনাম" বা "অধ্যায় ১: শিরোনাম" লিখে তারপর পড়ার বিষয়বস্তু ও প্রশ্নাবলি রাখুন।'}
                </p>
              </div>

              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  currentLang === 'en'
                    ? "Paste your report here...\n\nExample:\nChapter 1: Understanding Myself\nContent of chapter 1...\nQuestion 1: What is self-awareness?\nA. Recognizing personal worth\nB. Ignoring feelings\n\nChapter 2: ..."
                    : "এখানে রিপোর্ট পেস্ট করুন..."
                }
                rows={12}
                className="w-full p-4 border border-slate-300 rounded-2xl text-xs font-mono leading-relaxed focus:ring-2 focus:ring-indigo-500 focus:outline-hidden bg-slate-50"
              />

              <div className="flex justify-between items-center">
                <span className="text-xs text-slate-500">
                  {inputText.length} {currentLang === 'en' ? 'characters' : 'অক্ষর'}
                </span>
                <button
                  onClick={() => parseReportText(inputText)}
                  disabled={!inputText.trim()}
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer"
                >
                  🔍 {currentLang === 'en' ? 'Parse & Extract Chapters' : 'পার্স ও অধ্যায় বের করো'}
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: PREVIEW */}
          {activeTab === 'preview' && (
            <div className="space-y-5">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <BookOpen className="w-4 h-4 text-indigo-600" />
                  {currentLang === 'en'
                    ? `Extracted Curriculum (${parsedChapters.length} Chapters, ${parsedQuizzes.length} Quizzes)`
                    : `শনাক্তকৃত পাঠক্রম (${parsedChapters.length}টি অধ্যায়, ${parsedQuizzes.length}টি কুইজ)`}
                </h3>
                {parsedChapters.length > 0 && (
                  <button
                    onClick={handleApplyChanges}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-md transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <CheckCircle className="w-4 h-4" />
                    <span>{currentLang === 'en' ? 'Apply to Active Course 🚀' : 'সরাসরি কোর্সে যুক্ত করো 🚀'}</span>
                  </button>
                )}
              </div>

              {parsedChapters.length === 0 ? (
                <div className="text-center py-12 text-slate-400 space-y-2">
                  <FileText className="w-12 h-12 mx-auto stroke-1 text-slate-300" />
                  <p className="text-xs">
                    {currentLang === 'en'
                      ? 'No chapters extracted yet. Upload a .docx file or paste text first.'
                      : 'এখনো কোনো অধ্যায় বের করা হয়নি। প্রথমে ফাইল আপলোড করুন।'}
                  </p>
                </div>
              ) : (
                <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
                  {parsedChapters.map((ch) => (
                    <div
                      key={ch.id}
                      className="p-4 bg-slate-50 border border-slate-200 rounded-2xl flex items-start gap-3"
                    >
                      <span className="text-2xl p-2 bg-white rounded-xl shadow-3xs">{ch.emoji}</span>
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold uppercase text-indigo-600 font-mono">
                            {currentLang === 'en' ? 'Chapter' : 'অধ্যায়'} {ch.id} • {ch.category}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            Phase {ch.phase || 1}
                          </span>
                        </div>
                        <h4 className="text-xs font-bold text-slate-900">
                          {ch.title.en} {ch.title.bn !== ch.title.en ? `| ${ch.title.bn}` : ''}
                        </h4>
                        <p className="text-[11px] text-slate-600 line-clamp-2">
                          {ch.summary.en || ch.summary.bn}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: JSON & EXPORT TOOLS */}
          {activeTab === 'json' && (
            <div className="space-y-5">
              <div className="p-5 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                <h4 className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Download className="w-4 h-4 text-indigo-600" />
                  {currentLang === 'en' ? 'Download Full Course for Cloud Firestore' : 'ক্লাউড ফায়ারস্টোরের জন্য সম্পূর্ণ পাঠক্রম ডাউনলোড'}
                </h4>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {currentLang === 'en'
                    ? 'Export all 21 chapters and 67 quizzes as a clean, standardized JSON seed file ready to import directly into Firebase Firestore.'
                    : 'সকল ২১টি অধ্যায় ও ৬৭টি কুইজ ক্লাউড ফায়ারস্টোরে আপলোড করার জন্য সাজানো JSON ফাইল হিসেবে সংরক্ষণ করুন।'}
                </p>
                <button
                  onClick={handleExportJson}
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Download className="w-4 h-4" />
                  <span>{currentLang === 'en' ? 'Download firestore_shokhi_seed.json' : 'JSON ফাইল ডাউনলোড করুন'}</span>
                </button>
              </div>

              <div className="p-5 bg-amber-50 border border-amber-200 rounded-2xl space-y-2">
                <h4 className="text-xs font-extrabold text-amber-900">
                  💡 {currentLang === 'en' ? 'Word Document Parsing Instructions' : 'ওয়ার্ড ডকুমেন্ট ফরম্যাটের নিয়মাবলী'}
                </h4>
                <p className="text-xs text-amber-950 leading-relaxed">
                  {currentLang === 'en'
                    ? 'If you have created a comprehensive report in NotebookLLM, save it as a Word (.docx) document or text file. You can upload it here directly, and the parser will automatically extract the chapter titles, summaries, reading modules, and quiz questions.'
                    : 'আপনার NotebookLLM রিপোর্টটি ওয়ার্ড ফাইল (.docx) হিসেবে সেভ করে এখানে আপলোড করুন। অ্যাপের অভ্যন্তরীণ পার্সার স্বয়ংক্রিয়ভাবে প্রতিটি অধ্যায় ও কুইজ সাজিয়ে নেবে।'}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center gap-4">
          <button
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition-all cursor-pointer"
          >
            {currentLang === 'en' ? 'Close' : 'বন্ধ করুন'}
          </button>

          {parsedChapters.length > 0 && activeTab !== 'preview' && (
            <button
              onClick={() => setActiveTab('preview')}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
            >
              <span>{currentLang === 'en' ? `Review ${parsedChapters.length} Chapters →` : `${parsedChapters.length}টি অধ্যায় দেখুন →`}</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
