import React, { useState, useEffect, useRef } from 'react';
import { Timer, Star, Leaf, Award, RotateCcw, Play, Pause, CheckCircle } from 'lucide-react';

interface StudyFocusTimerProps {
  currentLang: 'en' | 'bn';
  starPoints: number;
  onRewardStars: (stars: number, minutes: number) => void;
  unlockedBadgeIds: string[];
}

export default function StudyFocusTimer({
  currentLang,
  starPoints,
  onRewardStars,
  unlockedBadgeIds
}: StudyFocusTimerProps) {
  const [duration, setDuration] = useState<number>(45); // 45 mins or longer
  const [secondsLeft, setSecondsLeft] = useState<number>(45 * 60);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [isFinished, setIsFinished] = useState<boolean>(false);
  const [totalSecondsSet, setTotalSecondsSet] = useState<number>(45 * 60);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Labels Object
  const t = {
    title: { en: "🧠 Gamified Study & Focus Timer", bn: "🧠 পড়াশোনার সময় ও মনযোগ বাড়ানোর টাইমার" },
    subtitle: { 
      en: "Learn to focus and reward your brain. Select a session, start reading your chapters offline, and grow a virtual flower as you study!", 
      bn: "একাগ্রতা বাড়ানো এবং নিজের মনকে পুরস্কৃত করা শেখো। একটি সময় নির্বাচন করো, বই অধ্যায় রিভিশন করা শুরু করো এবং তোমার পাঠাভ্যাসের সাথে সাথে একটি ছোট চারাগাছ বড় করে তোলো!" 
    },
    selectTime: { en: "Choose Your Study Time:", bn: "পড়ার সময়সীমা বেছে নাও:" },
    startBtn: { en: "Start Focusing & Grow Plant", bn: "মনঃসংযোগ শুরু ও চারা রোপণ" },
    pauseBtn: { en: "Pause Timer", bn: "টাইমার সাময়িক থামাও" },
    resetBtn: { en: "Reset Timer", bn: "টাইমার আবার সেট করো" },
    minutesLabel: { en: "Minutes", bn: "মিনিট" },
    progressMessage: {
      inhale: { en: "Keep studying calmly! Your plant is soaking up knowledge...", bn: "মন দিয়ে শান্তভাবে পড়তে থাকো! তোমার চারাটি কিন্তু জ্ঞান আহরণ করছে..." }
    },
    completedTitle: { en: "🎉 Bravo! Focus Session Complete!", bn: "🎉 সাবাশ! তোমার পড়ার সেশন সম্পূর্ণ!" },
    completedDesc: {
      en: "Your seedling has blossomed into a glorious Golden Flower and you have earned 30 bonus Star Points! Repeat another session to build spectacular focus.",
      bn: "তোমার যত্নে ছোট বীজটি এক অপূর্ব সোনালী ফুলে প্রস্ফুটিত হয়েছে এবং তুমি পুরস্কার হিসেবে ৩০টি স্টার পয়েন্ট উপার্জন করেছ! একাগ্রতা আরও বাড়াতে আবার ট্রাই করো।"
    },
    starsCount: { en: "My Star Points:", bn: "আমার স্টার পয়েন্ট:" },
    medalBadge: { en: "Focus Badges Unlocked:", bn: "মনোযোগের মেডেল আনলক হয়েছে:" },
    growSprout: { en: "Seed", bn: "বীজ" },
    growStem: { en: "Sprouting", bn: "নতুন কুঁড়ি" },
    growPlant: { en: "Budding Leaf", bn: "সবুজ পাতা" },
    growFlower: { en: "Golden Flower! 🌸", bn: "সোনালী ফুল! 🌸" }
  };

  useEffect(() => {
    setSecondsLeft(duration * 60);
    setTotalSecondsSet(duration * 60);
    setIsActive(false);
    setIsFinished(false);
  }, [duration]);

  useEffect(() => {
    if (isActive && secondsLeft > 0) {
      timerRef.current = setInterval(() => {
        setSecondsLeft(prev => {
          if (prev <= 1) {
            handleCompleteSession();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive, secondsLeft]);

  const handleCompleteSession = () => {
    setIsActive(false);
    setIsFinished(true);
    // Reward points is 30 Star Points
    onRewardStars(30, duration);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const handleToggleTimer = () => {
    setIsActive(!isActive);
    setIsFinished(false);
  };

  const handleReset = () => {
    setIsActive(false);
    setSecondsLeft(duration * 60);
    setIsFinished(false);
  };

  // Format time
  const formatTime = (secs: number) => {
    const min = Math.floor(secs / 60);
    const sec = secs % 60;
    return `${min}:${sec < 10 ? '0' : ''}${sec}`;
  };

  // Determine stage of plant growth
  const getGrowthProgress = () => {
    if (isFinished) return 4; // Flower
    const ratio = (totalSecondsSet - secondsLeft) / totalSecondsSet;
    if (ratio >= 0.75) return 3; // Budding leaf
    if (ratio >= 0.4) return 2;  // sprout
    if (ratio > 0) return 1;     // tiny sprout
    return 0;                    // Seed
  };

  const plantStage = getGrowthProgress();

  const timeDurations = [45, 60, 120, 180, 240];

  const formatDurationLabel = (mins: number) => {
    if (mins < 60) {
      return `${mins} ${t.minutesLabel[currentLang]}`;
    } else {
      const hrs = mins / 60;
      if (currentLang === 'en') {
        return `${hrs} ${hrs === 1 ? 'Hour' : 'Hours'}`;
      } else {
        return `${hrs} ঘণ্টা`;
      }
    }
  };

  return (
    <div id="focus-timer-card" className="bg-gradient-to-tr from-slate-50 to-indigo-50/40 p-4 md:p-6 rounded-2xl border border-indigo-100 shadow-xs max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row gap-8 items-center">
        
        {/* Left side: Animated Plant stage & Visual Timer */}
        <div className="flex-1 flex flex-col items-center justify-center min-h-[300px] text-center w-full">
          
          <div className="relative w-56 h-56 flex items-center justify-center bg-white rounded-full border-4 border-indigo-200 outline-dashed outline-offset-4 outline-indigo-200 shadow-inner">
            
            {/* Visual plant stages */}
            {plantStage === 0 && (
              <div className="flex flex-col items-center animate-pulse">
                <span className="text-4xl">🫘</span>
                <span className="text-xs font-bold text-slate-500 mt-2">{t.growSprout[currentLang]}</span>
              </div>
            )}
            {plantStage === 1 && (
              <div className="flex flex-col items-center animate-bounce">
                <span className="text-4xl text-emerald-600">🌱</span>
                <span className="text-xs font-bold text-emerald-600 mt-2">{t.growStem[currentLang]}</span>
              </div>
            )}
            {plantStage === 2 && (
              <div className="flex flex-col items-center animate-pulse">
                <span className="text-5xl">🌿</span>
                <span className="text-xs font-bold text-emerald-700 mt-2">{t.growPlant[currentLang]}</span>
              </div>
            )}
            {plantStage === 3 && (
              <div className="flex flex-col items-center animate-bounce">
                <span className="text-5xl">🪴</span>
                <span className="text-xs font-bold text-teal-800 mt-2">Almost Blooming!</span>
              </div>
            )}
            {plantStage === 4 && (
              <div className="flex flex-col items-center animate-pulse">
                <span className="text-6xl filter drop-shadow">🌸</span>
                <span className="text-xs font-bold text-amber-600 uppercase tracking-wider mt-2">{t.growFlower[currentLang]}</span>
              </div>
            )}

            {/* Float virtual particles if active */}
            {isActive && (
              <div className="absolute inset-0 border-4 border-indigo-500 rounded-full animate-ping opacity-10 pointer-events-none" />
            )}
          </div>

          <div className="mt-5 space-y-1">
            <div className="text-4xl font-black font-mono text-slate-800 tracking-wider">
              {formatTime(secondsLeft)}
            </div>
            <div className="text-xs text-indigo-700 font-semibold uppercase tracking-wider">
              {isActive ? t.progressMessage.inhale[currentLang] : "Paused / Ready"}
            </div>
          </div>

          {/* Controls */}
          <div className="flex gap-3 mt-6">
            <button
              onClick={handleToggleTimer}
              className={`py-2 px-5 rounded-xl font-extrabold text-xs flex items-center gap-1.5 shadow-sm transform active:scale-95 transition-all cursor-pointer ${
                isActive ? 'bg-rose-500 hover:bg-rose-600 text-white' : 'bg-indigo-600 hover:bg-indigo-700 text-white'
              }`}
            >
              {isActive ? (
                <>
                  <Pause className="w-3.5 h-3.5" />
                  <span>{t.pauseBtn[currentLang]}</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-white" />
                  <span>{t.startBtn[currentLang]}</span>
                </>
              )}
            </button>

            <button
              onClick={handleReset}
              className="py-2 px-4 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-bold text-xs flex items-center gap-1 cursor-pointer transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.resetBtn[currentLang]}</span>
            </button>
          </div>

        </div>

        {/* Right side: Informational guide and timer setup selector */}
        <div className="flex-1 space-y-4 text-left w-full">
          <div>
            <h3 className="text-md font-extrabold text-indigo-950 flex items-center gap-2">
              <Timer className="w-5 h-5 text-indigo-600" />
              {t.title[currentLang]}
            </h3>
            <p className="text-xs text-slate-600 mt-1.5 leading-relaxed font-sans font-normal">
              {t.subtitle[currentLang]}
            </p>
          </div>

          {/* Duration choice selector */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-indigo-950">
              {t.selectTime[currentLang]}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {timeDurations.map((time) => (
                <button
                  key={time}
                  type="button"
                  onClick={() => !isActive && setDuration(time)}
                  disabled={isActive}
                  className={`py-2 px-1 text-[11px] font-extrabold rounded-xl border transition-all ${
                    isActive ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
                  } ${
                    duration === time
                      ? 'bg-indigo-600 text-white border-indigo-700 font-black scale-102 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {formatDurationLabel(time)}
                </button>
              ))}
            </div>
          </div>

          {/* Star Wallet indicator */}
          <div className="bg-indigo-50 border border-indigo-150 p-3 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold text-indigo-950">
              <Star className="w-4 h-4 text-amber-500 fill-amber-300" />
              <span>{t.starsCount[currentLang]}</span>
            </div>
            <span className="text-sm font-black text-indigo-900 font-mono">
              ⭐ {starPoints} Points
            </span>
          </div>

          {/* Focus Medals information */}
          <div className="bg-emerald-50 border border-emerald-150 p-3 rounded-xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <Award className="w-4 h-4 text-emerald-600" />
                {t.medalBadge[currentLang]}
              </span>
              <span className="text-xs font-extrabold text-emerald-800">
                {unlockedBadgeIds.includes("badge_focus_expert") ? "🌟 Focus Zen Master Unlocked" : "🔒 Focus Zen Master locked"}
              </span>
            </div>
            <p className="text-[10px] text-emerald-700 leading-normal font-sans font-medium mt-1">
              {currentLang === 'en' 
                ? "Gain this medal automatically as soon as you complete at least one focus study timer session of 45 minutes or longer!"
                : "পড়াশোনা টাইমার চালিয়ে অন্ততঃ ৪৫ মিনিট মন দিয়ে পড়াশোনা করলেই এই মেডেলটি সরাসরি তোমার প্রোফাইলে আনলক হয়ে যাবে!"
              }
            </p>
          </div>

          {/* Session Finished Box */}
          {isFinished && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2 animate-fadeIn">
              <div className="flex items-center gap-1 text-xs font-black text-amber-950">
                <CheckCircle className="w-4 h-4 text-amber-500" />
                <span>{t.completedTitle[currentLang]}</span>
              </div>
              <p className="text-[11px] text-amber-800 leading-relaxed font-sans font-medium">
                {t.completedDesc[currentLang]}
              </p>
            </div>
          )}

        </div>

      </div>
    </div>
  );
}
