import React, { useState, useEffect, useRef } from 'react';
import { Wind, RotateCcw, Heart, Brain, Smile, FlameKindling, ShieldAlert, Sparkles, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import RelaxGames from './RelaxGames';

// Memory Card Interface
interface MemoryCard {
  id: number;
  word: { en: string; bn: string };
  definition: { en: string; bn: string };
  isFlipped: boolean;
  isMatched: boolean;
  emoji: string;
}

const CARDS_POOL = [
  { 
    word: { en: "Respect", bn: "শ্রদ্ধা" }, 
    emoji: "🤝", 
    definition: { 
      en: "Accepting yourself and others as valuable persons.", 
      bn: "নিজেকে এবং অন্যদের মূল্যবান ব্যক্তি হিসেবে সম্মান করা ও মেনে নেওয়া।" 
    } 
  },
  { 
    word: { en: "Empathy", bn: "সহানুভূতি" }, 
    emoji: "❤️", 
    definition: { 
      en: "Understanding and feeling the joys and sorrows of another.", 
      bn: "অন্যের সুখ এবং দুঃখ নিজের মন দিয়ে বুঝতে শেখা ও পাশে থাকা।" 
    } 
  },
  { 
    word: { en: "Courage", bn: "সাহস" }, 
    emoji: "🦁", 
    definition: { 
      en: "Speaking up for what is right, even when you feel scared.", 
      bn: "ভয় পেলেও নিজের সত্য এবং ন্যায়ের পক্ষে দাঁড়িয়ে প্রতিবাদ করা।" 
    } 
  },
  { 
    word: { en: "Teamwork", bn: "দলগত কাজ" }, 
    emoji: "🌟", 
    definition: { 
      en: "Combining your strength with others to lift heavy challenges.", 
      bn: "অন্যদের সাথে শক্তি ও বুদ্ধি মিলিয়ে কঠিন কোনো কাজকে সহজ করে তোলা।" 
    } 
  },
  { 
    word: { en: "Cleanliness", bn: "পরিচ্ছন্নতা" }, 
    emoji: "🧼", 
    definition: { 
      en: "Keeping your body and pads clean to protect your health.", 
      bn: "সুস্বাস্থ্য বজায় রাখতে নিজের শরীর, কাপড় এবং প্যাড সর্বদা পরিচ্ছন্ন রাখা।" 
    } 
  },
  { 
    word: { en: "Dream Big", bn: "বড় স্বপ্ন" }, 
    emoji: "🚀", 
    definition: { 
      en: "Setting goals and working step-by-step toward your future.", 
      bn: " can do the best in future: নিজের জীবনের লক্ষ্য স্থির করা এবং ভবিষ্যতের দিকে ধাপে ধাপে এগিয়ে চলা।" 
    } 
  }
];

export default function SafeSpace({ 
  currentLang = 'en', 
  starPoints = 0, 
  onRewardStars = () => {} 
}: { 
  currentLang?: 'en' | 'bn'; 
  starPoints?: number; 
  onRewardStars?: (stars: number, description: string) => void;
}) {
  const [activeTab, setActiveTab] = useState<'breathing' | 'memory-game' | 'interactive-games'>('interactive-games');

  // Breathing Guide States
  const [breathPhase, setBreathPhase] = useState<'Inhale' | 'Hold (In)' | 'Exhale' | 'Hold (Out)'>('Inhale');
  const [secondsLeft, setSecondsLeft] = useState(4);
  const [isBreathingRunning, setIsBreathingRunning] = useState(false);
  const breathTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Box Breathing cycle sequence: Inhale (4s) -> Hold In (4s) -> Exhale (4s) -> Hold Out (4s)
  useEffect(() => {
    if (isBreathingRunning) {
      breathTimerRef.current = setInterval(() => {
        setSecondsLeft((prev) => {
          if (prev <= 1) {
            // Transition to next phase
            setBreathPhase((currentPhase) => {
              switch (currentPhase) {
                case 'Inhale': return 'Hold (In)';
                case 'Hold (In)': return 'Exhale';
                case 'Exhale': return 'Hold (Out)';
                case 'Hold (Out)': return 'Inhale';
                default: return 'Inhale';
              }
            });
            return 4; // Reset to 4 seconds
          }
          return prev - 1;
        });
      }, 1000);
    } else {
      if (breathTimerRef.current) {
        clearInterval(breathTimerRef.current);
      }
    }

    return () => {
      if (breathTimerRef.current) clearInterval(breathTimerRef.current);
    };
  }, [isBreathingRunning]);

  const toggleBreathing = () => {
    if (isBreathingRunning) {
      setIsBreathingRunning(false);
      setSecondsLeft(4);
      setBreathPhase('Inhale');
    } else {
      setIsBreathingRunning(true);
      setSecondsLeft(4);
      setBreathPhase('Inhale');
    }
  };

  // Memory Game States
  const [cards, setCards] = useState<MemoryCard[]>([]);
  const [flippedIndices, setFlippedIndices] = useState<number[]>([]);
  const [matchedPairsCount, setMatchedPairsCount] = useState(0);
  const [movesCount, setMovesCount] = useState(0);
  const [lastMatchedMeaning, setLastMatchedMeaning] = useState<{ en: string; bn: string } | null>(null);
  const [lastMatchedWord, setLastMatchedWord] = useState<{ en: string; bn: string } | null>(null);

  const initMemoryGame = () => {
    // Duplicate pool to make pairs
    const doubleCards = [...CARDS_POOL, ...CARDS_POOL].map((item, idx) => ({
      id: idx,
      word: item.word,
      definition: item.definition,
      emoji: item.emoji,
      isFlipped: false,
      isMatched: false
    }));

    // Shuffle simple client-side
    const shuffled = doubleCards.sort(() => Math.random() - 0.5);
    setCards(shuffled);
    setFlippedIndices([]);
    setMatchedPairsCount(0);
    setMovesCount(0);
    setLastMatchedMeaning(null);
    setLastMatchedWord(null);
  };

  useEffect(() => {
    initMemoryGame();
  }, []);

  const handleCardClick = (index: number) => {
    if (cards[index].isMatched || cards[index].isFlipped) return;
    if (flippedIndices.length >= 2) return; // Prevent clicking too fast

    const newCards = [...cards];
    newCards[index].isFlipped = true;
    setCards(newCards);

    const newFlipped = [...flippedIndices, index];
    setFlippedIndices(newFlipped);

    if (newFlipped.length === 2) {
      setMovesCount(prev => prev + 1);
      const [firstIdx, secondIdx] = newFlipped;

      if (cards[firstIdx].word.en === cards[secondIdx].word.en) {
        // MATCH found!
        setTimeout(() => {
          const matchCards = [...cards];
          matchCards[firstIdx].isMatched = true;
          matchCards[secondIdx].isMatched = true;
          setCards(matchCards);
          setMatchedPairsCount(prev => prev + 1);
          setLastMatchedWord(cards[firstIdx].word);
          setLastMatchedMeaning({
            en: `${cards[firstIdx].emoji} ${cards[firstIdx].word.en}: ${cards[firstIdx].definition.en}`,
            bn: `${cards[firstIdx].emoji} ${cards[firstIdx].word.bn}: ${cards[firstIdx].definition.bn}`
          });
          setFlippedIndices([]);
        }, 500);
      } else {
        // NO MATCH! flip back
        setTimeout(() => {
          const revertCards = [...cards];
          revertCards[firstIdx].isFlipped = false;
          revertCards[secondIdx].isFlipped = false;
          setCards(revertCards);
          setFlippedIndices([]);
        }, 1000);
      }
    }
  };

  return (
    <div id="safe-space-container" className="p-4 md:p-6 bg-amber-50/50 rounded-2xl border border-amber-100 shadow-sm max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 id="safe-space-heading" className="text-xl md:text-2xl font-bold text-emerald-900 flex items-center gap-2">
            <Heart className="w-6 h-6 text-rose-500 fill-rose-500" />
            {currentLang === 'en' ? "Empowerment Safe Space" : "মন ভালো করার শান্ত কুঠির ও সুরক্ষালয়"}
          </h2>
          <p className="text-sm text-emerald-700 font-sans">
            {currentLang === 'en'
              ? "A quiet corner to relax your breath, relieve stress, play cognitive games and celebrate positive thoughts."
              : "মন শান্ত করা, বিষণ্ণতা কাটানো ও মন ভালো করা অফলাইন মজাদার খেলার শান্ত নিভৃত সুরক্ষাকোণ।"
            }
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap border-b border-emerald-100 mb-6 gap-2">
        <button
          id="btn-tab-games-hub"
          onClick={() => setActiveTab('interactive-games')}
          className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors border-t border-x ${
            activeTab === 'interactive-games'
              ? 'border-emerald-200 bg-white text-emerald-950 font-extrabold pointer-events-none'
              : 'border-transparent text-emerald-600 hover:text-emerald-900'
          }`}
        >
          🎮 {currentLang === 'en' ? "Relaxing Mind Games" : "মন ভালো করার গেমস"}
        </button>
        <button
          id="btn-tab-breath"
          onClick={() => setActiveTab('breathing')}
          className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors border-t border-x ${
            activeTab === 'breathing'
              ? 'border-emerald-200 bg-white text-emerald-950 font-extrabold pointer-events-none'
              : 'border-transparent text-emerald-600 hover:text-emerald-900'
          }`}
        >
          💨 {currentLang === 'en' ? "Calm Deep Breathing" : "বুক ভরে নিশ্বাস নেওয়া"}
        </button>
        <button
          id="btn-tab-memory"
          onClick={() => setActiveTab('memory-game')}
          className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors border-t border-x ${
            activeTab === 'memory-game'
              ? 'border-emerald-200 bg-white text-emerald-950 font-extrabold pointer-events-none'
              : 'border-transparent text-emerald-600 hover:text-emerald-900'
          }`}
        >
          🧩 {currentLang === 'en' ? "Positive Values Memory Match" : "মূল্যবোধ জোড় মেলানো"}
        </button>
      </div>

      {/* Breathing Tab */}
      {activeTab === 'breathing' && (
        <div id="breathing-tab" className="flex flex-col md:flex-row gap-6 items-center p-4">
          <div className="flex-1 flex flex-col items-center justify-center min-h-[300px]">
            {/* Visual Breath Circle Container */}
            <div className="relative w-64 h-64 flex items-center justify-center">
              {/* Outer pulsing ring */}
              <div 
                className={`absolute inset-0 rounded-full bg-emerald-100/50 border border-emerald-200 transition-all duration-1000 ${
                  isBreathingRunning && breathPhase === 'Inhale' ? 'scale-110 opacity-70' : ''
                } ${
                  isBreathingRunning && breathPhase === 'Exhale' ? 'scale-75 opacity-30' : ''
                }`}
              />

              {/* Core guided breathing sphere */}
              <div
                className={`w-40 h-40 rounded-full flex flex-col items-center justify-center text-white font-sans transition-all duration-1000 shadow-lg ${
                  breathPhase === 'Inhale' 
                    ? 'bg-gradient-to-tr from-teal-500 to-emerald-400 scale-105' 
                    : breathPhase === 'Hold (In)'
                    ? 'bg-gradient-to-tr from-indigo-500 to-purple-400 scale-110'
                    : breathPhase === 'Exhale'
                    ? 'bg-gradient-to-tr from-cyan-500 to-sky-400 scale-90'
                    : 'bg-gradient-to-tr from-rose-400 to-amber-400 scale-95'
                }`}
              >
                <div className="text-center p-2">
                  <div className="text-sm uppercase tracking-widest font-semibold text-white/80">
                    {secondsLeft}s
                  </div>
                  <div className="text-xl font-bold mt-1 leading-snug">
                    {currentLang === 'en' ? (
                      breathPhase
                    ) : (
                      breathPhase === 'Inhale' ? 'শ্বাস নাও 💨' :
                      breathPhase === 'Hold (In)' ? 'ভিতরে ধরে রাখো' :
                      breathPhase === 'Exhale' ? 'শ্বাস ছাড়ো 🍃' :
                      'বাইরে আটকে রাখো'
                    )}
                  </div>
                </div>
              </div>

              {/* Small floating bubble representation */}
              {isBreathingRunning && (
                <div className="absolute animate-bounce text-2xl bottom-4 right-10">🍃</div>
              )}
            </div>

            {/* Controls */}
            <div className="mt-8 flex gap-4">
              <button
                id="btn-toggle-breath"
                onClick={toggleBreathing}
                className={`py-3 px-8 rounded-full font-bold shadow-md transform active:scale-95 transition-all text-sm gap-2 flex items-center ${
                  isBreathingRunning 
                    ? 'bg-rose-500 hover:bg-rose-600 text-white' 
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
              >
                {isBreathingRunning ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" /> {currentLang === 'en' ? "Stop and Rest" : "বন্ধ করো এবং আরাম করো"}
                  </>
                ) : (
                  <>
                    <Wind className="w-5 h-5" /> {currentLang === 'en' ? "Start Box Breathing" : "বক্স ব্রিদিং শুরু করো"}
                  </>
                )}
              </button>
            </div>
          </div>

          <div className="flex-1 bg-white p-5 rounded-xl border border-emerald-100 shadow-xs max-w-md">
            <h3 className="text-lg font-bold text-emerald-950 mb-2 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              {currentLang === 'en' ? "Why do this breathing exercise?" : "এই শ্বাস-প্রশ্বাসের ব্যায়াম কেন করবে?"}
            </h3>
            <p className="text-sm text-emerald-800 leading-relaxed mb-4">
              {currentLang === 'en'
                ? "When you feel anxious, tight, or angry, your body goes into defense mode, and your breathing speed builds up. Doing Box Breathing (4s inhale, 4s hold-in, 4s exhale, 4s hold-out) recalibrates your nervous system, signals to your brain that you are completely safe, and refreshes your emotional control instantly!"
                : "যখন তুমি কোনো কারণে উদ্বিগ্ন, নার্ভাস বা রাগান্বিত বোধ করো, তখন তোমার শরীর রক্ষণাত্মক মোডে চলে যায় এবং শ্বাস-প্রশ্বাসের গতি বেড়ে যায়। এই বক্স ব্রিদিং (৪ সেকেন্ড শ্বাস নেওয়া, ৪ সেকেন্ড ধরে রাখা, ৪ সেকেন্ড ছাড়া এবং ৪ সেকেন্ড বাইরে দম আটকে রাখা) করলে তোমার স্নায়ুতন্ত্র শান্ত হয়, মস্তিষ্কে সংকেত পৌঁছায় যে তুমি সম্পূর্ণ নিরাপদ এবং এটি তোমার মানসিক নিয়ন্ত্রণ ফিরিয়ে আনে মুহূর্তেই!"}
            </p>
            <div className="space-y-2 mt-4 bg-emerald-50 p-3 rounded-lg border border-emerald-100">
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-900">
                <span className="w-6 h-6 rounded-full bg-emerald-200 text-emerald-900 flex items-center justify-center text-xs font-bold">1</span>
                <span>
                  <strong>{currentLang === 'en' ? "Breathe In:" : "শ্বাস নাও:"}</strong>{" "}
                  {currentLang === 'en' ? "Fill your abdomen with quiet energy." : "শান্ত ও ইতিবাচক শক্তি দিয়ে বুক-পেট ভরিয়ে তোলো।"}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-900">
                <span className="w-6 h-6 rounded-full bg-indigo-200 text-indigo-900 flex items-center justify-center text-xs font-bold">2</span>
                <span>
                  <strong>{currentLang === 'en' ? "Hold:" : "শ্বাস ধরে রাখো:"}</strong>{" "}
                  {currentLang === 'en' ? "Let the energy absorb inside your body." : "শক্তিটি তোমার শরীরের প্রতিটি শিরায় অনুভব করো।"}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-900">
                <span className="w-6 h-6 rounded-full bg-cyan-200 text-cyan-900 flex items-center justify-center text-xs font-bold">3</span>
                <span>
                  <strong>{currentLang === 'en' ? "Exhale:" : "শ্বাস ছাড়ো:"}</strong>{" "}
                  {currentLang === 'en' ? "Let out all the tension and cloudiness." : "সমস্ত উদ্বেগ, ক্লান্তি ও নেতিবাচকতা বাইরে বের করে দাও।"}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-900">
                <span className="w-6 h-6 rounded-full bg-amber-200 text-amber-950 flex items-center justify-center text-xs font-bold">4</span>
                <span>
                  <strong>{currentLang === 'en' ? "Stay empty:" : "শ্বাস বন্ধ রাখো:"}</strong>{" "}
                  {currentLang === 'en' ? "Pause, feel the calmness, repeat." : "খানিক বিরতি নাও, গভীর প্রশান্তি অনুভব করো, আবার শুরু করো।"}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Memory game Tab */}
      {activeTab === 'memory-game' && (
        <div id="memory-game-tab" className="p-2">
          <div className="flex flex-col md:flex-row gap-6">
            
            {/* Game Board */}
            <div className="flex-1">
              <div className="flex justify-between items-center mb-4 bg-white p-3 rounded-xl border border-emerald-100 shadow-2xs">
                <div className="text-sm font-semibold text-emerald-800 font-mono">
                  {currentLang === 'en' ? "Moves: " : "চালসংখ্যা: "}<span className="text-emerald-950 font-bold text-base">{movesCount}</span>
                </div>
                <div className="text-sm font-semibold text-emerald-800 font-mono">
                  {currentLang === 'en' ? "Matched: " : "মিলানো জোড়: "}<span className="text-emerald-950 font-bold text-base">{matchedPairsCount} / 6</span>
                </div>
                <button
                  id="btn-reset-memory"
                  onClick={initMemoryGame}
                  className="px-3 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-lg border border-emerald-100 flex items-center gap-1 transition-colors"
                >
                  <RotateCcw className="w-3 h-3" /> {currentLang === 'en' ? "Retry Grid" : "পুনরায় শুরু করো"}
                </button>
              </div>

              {matchedPairsCount === 6 && (
                <div className="mb-4 bg-teal-50 border border-teal-200 p-4 rounded-xl text-center">
                  <h4 className="text-teal-900 font-bold flex items-center justify-center gap-1">
                    {currentLang === 'en' ? "🎉 Excellent! You matched all Positive Values!" : "🎉 অসাধারণ! তুমি সবগুলো মূল্যবোধ মেলাতে পেরেছ!"}
                  </h4>
                  <p className="text-xs text-teal-700 mt-1">
                    {currentLang === 'en' 
                      ? `You mastered the memory game in ${movesCount} moves. You are smart and highly focused!`
                      : `তুমি মাত্র ${movesCount} চালে মূল্যবোধের এই জোড়গুলো মিলিয়েছ। তুমি অত্যন্ত বুদ্ধিমান ও মনোযোগী সখী!`
                    }
                  </p>
                </div>
              )}

              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {cards.map((card, idx) => {
                  const pathMatchedOrFlipped = card.isMatched || card.isFlipped;
                  return (
                    <button
                      key={card.id}
                      onClick={() => handleCardClick(idx)}
                      style={{ minHeight: '90px' }}
                      className={`relative rounded-xl flex flex-col items-center justify-center p-2 cursor-pointer transition-all duration-300 transform active:scale-95 shadow-2xs border ${
                        card.isMatched
                          ? 'bg-teal-50 border-teal-200 text-teal-800 opacity-60'
                          : card.isFlipped
                          ? 'bg-white border-emerald-400 text-emerald-900 hover:border-emerald-500'
                          : 'bg-gradient-to-br from-emerald-700 to-emerald-800 border-emerald-900 text-white hover:brightness-110'
                      }`}
                    >
                      {pathMatchedOrFlipped ? (
                        <>
                          <span className="text-2xl mb-1">{card.emoji}</span>
                          <span className="text-xs font-bold text-center leading-tight tracking-tight">
                            {currentLang === 'en' ? card.word.en : card.word.bn}
                          </span>
                        </>
                      ) : (
                        <>
                          <div className="w-7 h-7 rounded-full bg-emerald-600/50 flex items-center justify-center text-white font-bold text-sm">
                            ?
                          </div>
                          <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-200 mt-1">
                            {currentLang === 'en' ? "Values" : "মূল্যবোধ"}
                          </span>
                        </>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Sidebar with dynamic word learnings */}
            <div className="w-full md:w-64 flex flex-col gap-4">
              <div className="bg-white p-4 rounded-xl border border-emerald-100 shadow-2xs flex-1">
                <h4 className="text-sm font-bold text-emerald-900 uppercase tracking-wider mb-2 border-b pb-1 flex items-center gap-1">
                  <Smile className="w-4 h-4 text-emerald-600" />
                  {currentLang === 'en' ? "Positive Insight" : "অনুপ্রেরণামূলক বাণী"}
                </h4>
                {lastMatchedMeaning ? (
                  <div className="bg-emerald-50/50 p-3 rounded-lg border border-emerald-100 animate-fadeIn">
                    <div className="text-sm font-bold text-emerald-950 mb-1 flex items-center gap-1">
                      {currentLang === 'en' ? "Matched: " : "মিলানো শব্দ: "}<span className="text-teal-700">{currentLang === 'en' ? lastMatchedWord?.en : lastMatchedWord?.bn}</span>
                    </div>
                    <p className="text-xs text-emerald-800 leading-relaxed font-sans font-medium">
                      {currentLang === 'en' ? lastMatchedMeaning.en : lastMatchedMeaning.bn}
                    </p>
                  </div>
                ) : (
                  <p className="text-xs text-emerald-600 italic">
                    {currentLang === 'en' 
                      ? "Flip and match two cards. Once you find a match, its empowering meaning will be illustrated right here!"
                      : "দুটি কার্ড উল্টে জোড় মেলাও। জোড় মিলে গেলে তার চমৎকার ও অনুপ্রেরণামূলক অর্থ এখানে ফুটে উঠবে!"
                    }
                  </p>
                )}
              </div>

              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200/60 text-[11px] text-amber-900">
                {currentLang === 'en' ? (
                  <>
                    <strong>Mind Tip:</strong> Games quieten the amygdala (the brain's anxiety panic room) because your focus is channelled on beautiful, structured details. If you feel panic, play a quick match of Memory!
                  </>
                ) : (
                  <>
                    <strong>মনের টিপস:</strong> মনে রেখো, অফলাইন গেমগুলো আমাদের মস্তিষ্কের দুশ্চিন্তা দূর করতে এবং মনোযোগ বাড়াতে দারুণ সাহায্য করে। তাই মন খারাপ লাগলে বা একা লাগলে ঝটপট মেমরি গেমটি খেলে নিজের মন সতেজ করো!
                  </>
                )}
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Interactive Micro Games Tab */}
      {activeTab === 'interactive-games' && (
        <div id="interactive-games-tab" className="p-2">
          <RelaxGames 
            currentLang={currentLang} 
            starPoints={starPoints} 
            onRewardStars={onRewardStars} 
          />
        </div>
      )}
    </div>
  );
}
