import React, { useState } from 'react';
import { Calendar, CheckCircle2, ShieldAlert, Sparkles, Smile, BookOpen, AlertTriangle } from 'lucide-react';

interface Myth {
  id: number;
  statement: {
    en: string;
    bn: string;
  };
  isTrue: boolean;
  explanation: {
    en: string;
    bn: string;
  };
}

const PERIOD_MYTHS: Myth[] = [
  {
    id: 1,
    statement: {
      en: "During her period, a girl is impure or dirty and should not touch food or enter the kitchen.",
      bn: "পিরিয়ডের সময়ে মেয়েরা অপবিত্র থাকে এবং রান্নাঘরে যাওয়া বা কোনো খাবার স্পর্শ করা ঠিক নয়।"
    },
    isTrue: false,
    explanation: {
      en: "This is a widespread false taboo! Menstruation is a normal, healthy biological growth process of the clean body. It has absolutely no effect on food hygiene. You can touch, cook, and eat pickles or food with complete safety and pride!",
      bn: "এটি একটি সর্বৈব অসত্য ও ক্ষতিকর কুসংস্কার! ঋতুস্রাব বা পিরিয়ড আমাদের শরীরের একটি অত্যন্ত স্বাভাবিক ও সুস্থ জৈবিক প্রক্রিয়া। পিরিয়ডের সঙ্গে রান্না করা বা কোনো খাবার ছোঁয়ার সাথে কোনো ক্ষতি বা অস্বাস্থ্যকর সম্পর্কের সম্পর্ক নেই।"
    }
  },
  {
    id: 2,
    statement: {
      en: "If you reuse a cotton cloth pad, drying it in a wet, dark room without sunlight is safe.",
      bn: "পরিষ্কার সুতি কাপড়ের প্যাড ব্যবহারের পর তা অন্ধকার বা স্যাঁতস্যাঁতে জায়গায় শুকানো নিরাপদ ও ভালো।"
    },
    isTrue: false,
    explanation: {
      en: "False and unsafe! Drying a re-usable cloth pad in dark, damp spaces keeps bacteria active, causing dangerous infections. You MUST wash cloth pads thoroughly with clean soap and dry them under direct, open hot sunlight. Sunlight acts as a natural germ-killer!",
      bn: "সম্পূর্ণ ভুল এবং বিপজ্জনক! স্যাঁতস্যাঁতে বা অন্ধকার বদ্ধ জায়গায় কাপড় শুকালে ক্ষতিকারক ব্যাকটেরিয়া ও ফাঙ্গাসের জন্ম হয়, যা থেকে রোগ ছড়ায়। ধোয়া সুতির কাপড় সবসময় কড়া রোদে খোলা জায়গায় শুকাতে হবে যেন সূর্যের উত্তাপ সব জীবাণু ধ্বংস করতে পারে।"
    }
  },
  {
    id: 3,
    statement: {
      en: "Gentle exercises, walking, or attending school are completely fine and healthy during periods.",
      bn: "পিরিয়ড চলাকালীন সময়ে হালকা ব্যায়াম করা, হাঁটাহাঁটি করা এবং স্কুলে যাওয়া নিরাপদ ও স্বাস্থ্যসম্মত।"
    },
    isTrue: true,
    explanation: {
      en: "True! Gentle movement and stretching actually improve blood circulation and help relieve painful stomach cramps! Continuing your routine or studies is highly encouraged.",
      bn: "একেবারে সত্যি! হালকা শারীরিক ব্যায়াম বা হাঁটাহাঁটি করলে শরীরের রক্ত সঞ্চালন ভালো থাকে যা তলপেটের ব্যথা ও অস্বস্তি কমাতে সাহায্য করে। স্বাভাবিক মনখোলা জীবনযাপন ও পড়াশোনা চালিয়ে যাওয়া উচিত।"
    }
  },
  {
    id: 4,
    statement: {
      en: "Showering or bathing during menstruation is harmful to a girl's health.",
      bn: "পিরিয়ডের সময়ে স্নান করা বা শরীর ধোয়া মেয়েদের স্বাস্থ্যের জন্য ক্ষতিকারক।"
    },
    isTrue: false,
    explanation: {
      en: "False! Keeping your body warm, clean, and taking baths during your cycle is highly important for hygiene and prevents itching and bad odors. Cleanliness is healthcare!",
      bn: "ভুল কথা! পিরিয়ড চলাকালীন সময়ে জল দিয়ে শরীর ধুয়ে পরিষ্কার-পরিচ্ছন্ন ও পরিপাটি থাকা অত্যন্ত জরুরী। নিয়মিত স্নান করলে চুলকানি উধাও হয়, শরীর দুর্গন্ধমুক্ত থাকে ও মন ফুরফুরে হয়।"
    }
  }
];

export default function AdolescentHealth({ currentLang = 'en' }: { currentLang?: 'en' | 'bn' }) {
  // Cycle Estimator States
  const [lastPeriodDate, setLastPeriodDate] = useState<string>('');
  const [cycleLength, setCycleLength] = useState<number>(28);
  const [estimatedNextISO, setEstimatedNextISO] = useState<string>('');
  const [prepCheckList, setPrepCheckList] = useState<Record<string, boolean>>({
    padInBag: false,
    extraUnderwear: false,
    calendarMarked: false
  });

  const calculateNextPeriod = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lastPeriodDate) return;

    const lastDateObj = new Date(lastPeriodDate);
    // Add cycleLength days
    lastDateObj.setDate(lastDateObj.getDate() + Number(cycleLength));
    setEstimatedNextISO(lastDateObj.toISOString());
  };

  const getFormattedEstimatedDate = () => {
    if (!estimatedNextISO) return '';
    try {
      const dateObj = new Date(estimatedNextISO);
      if (currentLang === 'bn') {
        return dateObj.toLocaleDateString('bn-BD', { year: 'numeric', month: 'long', day: 'numeric' });
      } else {
        return dateObj.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
      }
    } catch (e) {
      return '';
    }
  };

  const formattedNextDate = getFormattedEstimatedDate();

  const toggleCheck = (key: string) => {
    setPrepCheckList(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  // Myth Buster states
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, boolean>>({});
  const [showExplanation, setShowExplanation] = useState<Record<number, boolean>>({});

  const handleAnswerClick = (mythId: number, answer: boolean) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [mythId]: answer
    }));
    setShowExplanation(prev => ({
      ...prev,
      [mythId]: true
    }));
  };

  return (
    <div id="health-container" className="p-4 md:p-6 bg-rose-50/50 rounded-2xl border border-rose-100 shadow-sm max-w-4xl mx-auto space-y-8 animate-fadeIn">
      {/* Header */}
      <div>
        <h2 id="health-main-heading" className="text-xl md:text-2xl font-bold text-rose-950 flex items-center gap-2">
          <Calendar className="w-6 h-6 text-rose-500" />
          {currentLang === 'en' ? "My Body, My Health & Hygiene" : "আমার শরীর, আমার অমূল্য স্বাস্থ্য ও পরিচ্ছন্নতা"}
        </h2>
        <p className="text-sm text-rose-800 font-sans">
          {currentLang === 'en'
            ? "Embrace growing up with clean science, self-care, and pride. Learn about your monthly cycles and break the outdated taboos!"
            : "কৈশোরকালীন শারীরিক পরিবর্তনে বৈজ্ঞানিক তথ্য জানো, লজ্জা দূরে সরিয়ে কুসংস্কার জয় করো সগর্বে!"
          }
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Cycle Estimator */}
        <div id="cycle-calculator-card" className="bg-white p-5 rounded-xl border border-rose-100 shadow-sm space-y-4">
          <h3 className="text-base font-bold text-rose-950 flex items-center gap-2 pb-2 border-b border-rose-100">
            🌸 {currentLang === 'en' ? "Offline Period Cycle Planner" : "অফলাইন মাসিক ঋতুচক্র ক্যালকুলেটর"}
          </h3>
          <p className="text-xs text-rose-700 leading-relaxed font-sans font-medium">
            {currentLang === 'en'
              ? "Knowing your body helps you plan. Enter the first day of your last period, and we will estimate your next expected cycle date so you are never caught unprepared!"
              : "নিজের শরীর সম্পর্কে অবগত থাকা জরুরী। শেষ পিরিয়ডের শুরুর দিন ও সাধারণ চক্র ব্যবধান লিখলেই পরবর্তী দিন গণনা হয়ে যাবে।"
            }
          </p>

          <form onSubmit={calculateNextPeriod} className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-rose-900 mb-1">
                📅 {currentLang === 'en' ? "First day of last period:" : "শেষ পিরিয়ড শুরু হওয়ার প্রথম দিন:"}
              </label>
              <input
                id="input-last-period-date"
                type="date"
                value={lastPeriodDate}
                onChange={(e) => setLastPeriodDate(e.target.value)}
                className="w-full text-sm p-4 bg-rose-50 border border-rose-250 rounded-lg text-rose-950 focus:outline-rose-450 font-bold"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-rose-900 mb-1">
                🔄 {currentLang === 'en' ? "Average Cycle Length (usually 28 days):" : "গড় মাসিক ঋতুচক্রের দীর্ঘতা (সাধারণত ২৮ দিন):"}
              </label>
              <input
                id="input-cycle-length"
                type="number"
                min="20"
                max="45"
                value={cycleLength}
                onChange={(e) => setCycleLength(Number(e.target.value))}
                className="w-full text-sm p-4 bg-rose-50 border border-rose-250 rounded-lg text-rose-950 focus:outline-rose-450 font-bold font-mono"
                required
              />
            </div>
            <button
              id="btn-calc-cycle"
              type="submit"
              className="w-full py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white font-black text-xs rounded-lg transition-colors cursor-pointer shadow-3xs"
            >
              {currentLang === 'en' ? "Calculate Expected Next Period" : "পরবর্তী সম্ভাব্য ঋতুস্রাব শুরুর দিন নির্ণয় করো"}
            </button>
          </form>

          {formattedNextDate && (
            <div id="calc-result-box" className="p-3 bg-rose-100 border border-rose-200 rounded-lg animate-fadeIn text-center space-y-1">
              <div className="text-[10px] uppercase font-bold tracking-wider text-rose-800">
                {currentLang === 'en' ? "Your Next Expected Date" : "ঋতুচক্র অনুসারে পরবর্তী সম্ভাব্য তারিখ"}
              </div>
              <div className="text-base font-extrabold text-rose-950">{formattedNextDate}</div>
              <div className="text-[10px] text-rose-700 font-bold">
                {currentLang === 'en'
                  ? "Keep a backup clean pad or cloth ready in your schoolbag 2-3 days before this date!"
                  : "এই সম্ভাব্য তারিখের ২-৩ দিন আগে থেকেই স্কুলের ব্যাগে একটি অতিরিক্ত সুতি কাপড় বা স্যানিটারি প্যাড গুছিয়ে রাখুন!"
                }
              </div>
            </div>
          )}

          {/* Preparedness Checklist */}
          <div className="pt-2">
            <h4 className="text-xs font-bold text-rose-900 mb-2">
              🎈 {currentLang === 'en' ? "Proactive Preparation Checklist:" : "আগাম প্রস্তুতি আত্মরক্ষা নির্দেশিকাঃ"}
            </h4>
            <div className="space-y-2">
              <label className="flex items-start gap-2 text-xs font-semibold text-rose-800 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={prepCheckList.padInBag}
                  onChange={() => toggleCheck('padInBag')}
                  className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
                />
                <span className={prepCheckList.padInBag ? 'line-through text-rose-400' : ''}>
                  {currentLang === 'en'
                    ? "Keep 1 clean sanitary pad/cloth packaged safely in my school bag."
                    : "নিজের স্কুলের ব্যাগে ১টি অতিরিক্ত শুকনো স্যানিটারি ন্যাপকিন বা পরিষ্কার সুতি কাপড় কাগজ দিয়ে মুড়ে রাখা।"
                  }
                </span>
              </label>
              <label className="flex items-start gap-2 text-xs font-semibold text-rose-800 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={prepCheckList.extraUnderwear}
                  onChange={() => toggleCheck('extraUnderwear')}
                  className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
                />
                <span className={prepCheckList.extraUnderwear ? 'line-through text-rose-400' : ''}>
                  {currentLang === 'en'
                    ? "Keep an extra dark-colored underwear in case of direct leakage."
                    : "জাকজমকপূর্ণ কাজের ব্যাঘাত রুখতে ব্যাগে অতিরিক্ত কালো বা অমলিন রঙের অন্তর্বাস ব্যাকআপ রাখা।"
                  }
                </span>
              </label>
              <label className="flex items-start gap-2 text-xs font-semibold text-rose-800 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={prepCheckList.calendarMarked}
                  onChange={() => toggleCheck('calendarMarked')}
                  className="mt-0.5 rounded text-rose-600 focus:ring-rose-500"
                />
                <span className={prepCheckList.calendarMarked ? 'line-through text-rose-400' : ''}>
                  {currentLang === 'en'
                    ? "Mark my dates on this app or a paper calendar to check patterns."
                    : "মাসিক দিনপঞ্জি এই অ্যাপ্লিকেশন অথবা দেয়ালপঞ্জি খাতায় টিকচিহ্ন দিয়ে দিন গুনে হিসাব রাখা।"
                  }
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Hygiene Guideline Cards */}
        <div className="bg-white p-5 rounded-xl border border-rose-100 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-rose-950 flex items-center gap-1.5 pb-2 border-b border-rose-100">
              🧴 {currentLang === 'en' ? "Ideal Menstrual Cleanliness Rules" : "ঋতুস্রাবকালীন আদর্শ স্বাস্থ্যবিধি শিক্ষা"}
            </h3>
            <div className="space-y-3 mt-3">
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-rose-200 text-rose-950 flex items-center justify-center font-bold text-xs mt-0.5 shrink-0">1</div>
                <div>
                  <h4 className="text-xs font-black text-rose-950">
                    {currentLang === 'en' ? "Change Regularly (4-6 Hours)" : "নিয়মিত প্যাড/কাপড় বদলানো (৪-৬ ঘণ্টা অন্তর)"}
                  </h4>
                  <p className="text-[11px] text-rose-800 font-sans leading-relaxed">
                    {currentLang === 'en'
                      ? "Never wear the same cloth or pad for more than 6 hours. This keeps wetness away and blocks bacterial growth."
                      : "কোনোভাবেই পিরিয়ড শুরুর দিনে বা দিনগুলোতে ৬ ঘণ্টার বেশি একটানা এক প্যাড পরে থাকবেন না। এতে ফুসকুরি ও সংক্রামক ব্যধি দূর হয়।"
                    }
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-rose-200 text-rose-950 flex items-center justify-center font-bold text-xs mt-0.5 shrink-0">2</div>
                <div>
                  <h4 className="text-xs font-black text-rose-950">
                    {currentLang === 'en' ? "Soap & Safe Drying" : "সুতি কাপড় সেদ্ধ সাবান দিয়ে ধুয়ে রোদ পোড়ানো"}
                  </h4>
                  <p className="text-[11px] text-rose-800 font-sans leading-relaxed">
                    {currentLang === 'en'
                      ? "Wash cloth pads with clean warm water and standard soap. Dry them in open direct space under brilliant hot sunlight. Do NOT hide them in damp dark rooms."
                      : "পুনর্ব্যবহারযোগ্য সুতির কাপড় সাবান এবং গরম জলে কাচতে হবে। অন্ধকার ঘরের আলমারির পেছনে না লুকিয়ে সরাসরি কড়া সূর্যের আলোতে শুকিয়ে নিতে হবে।"
                    }
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-2.5">
                <div className="w-5 h-5 rounded-full bg-rose-200 text-rose-950 flex items-center justify-center font-bold text-xs mt-0.5 shrink-0">3</div>
                <div>
                  <h4 className="text-xs font-black text-rose-950">
                    {currentLang === 'en' ? "Correct Clean Disposal" : "সঠিকভাবে খবরের কাগজে মুড়ে ডাস্টবিনে ফেলা"}
                  </h4>
                  <p className="text-[11px] text-rose-800 font-sans leading-relaxed">
                    {currentLang === 'en'
                      ? "Wrap disposable sanitary napkins carefully in news-paper or waste paper, and throw them in garbage bins or burn pits. Never throw them open or flush them in toilets!"
                      : "ব্যবহৃত প্যাড কখনোই টয়লেট অথবা কমোডে ফেলে ফ্ল্যাশ করবেন না। খবরের কাগজে যত্নসহকারে মুড়ে ডাস্টবিনে বা ময়লার ঝুড়িতে জমা করুন।"
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-rose-50/80 p-3 rounded-lg border border-rose-200 text-[11px] text-rose-900 font-bold mt-2 leading-relaxed">
            💡 {currentLang === 'en' ? (
              <><strong>Did you know?</strong> Average girls get their first period between 11 to 15 years old. Everyone has their unique calendar pattern, and that is absolutely fine!</>
            ) : (
              <><strong>আপনি কি জানেন?</strong> মেয়েদের প্রথম পিরিয়ড বা ঋতুস্রাব সাধারণত ১১ থেকে ১৫ বছর বয়সের মধ্যে শুরু হয়। সবার শারীরিক চক্রের দিন ভিন্ন হতে পারে, যা নিখাদ স্বাভাবিক!</>
            )}
          </div>
        </div>
      </div>

      {/* Myth Buster Quiz Screen */}
      <div id="myth-buster-card" className="bg-white p-5 rounded-xl border border-rose-100 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-rose-950 flex items-center gap-1.5 pb-2 border-b border-rose-100 font-sans">
          🤔 {currentLang === 'en' ? "Period Taboo Myth-Buster Game!" : "কুসংস্কার ভাঙার বিজ্ঞানভিত্তিক কুইজ খেলা!"}
        </h3>
        <p className="text-xs text-rose-850 font-sans leading-relaxed">
          {currentLang === 'en'
            ? "In our villages, people sometimes share traditional stories about periods that make girls feel shame or distress. Let's test their science and discover the real truth together!"
            : "আমাদের গ্রামাঞ্চলে অনেকে পিরিয়ড নিয়ে অনেক ভ্রান্ত কথা বলেন যা অবৈজ্ঞানিক এবং যা কিশোরীদের মনে ভয়ের সৃষ্টি করে। এসো সত্য বৈজ্ঞানিক তথ্যগুলো যাচাই করে নিই!"
          }
        </p>

        <div className="space-y-4">
          {PERIOD_MYTHS.map((myth) => {
            const hasAnswered = selectedAnswers[myth.id] !== undefined;
            const chosenAnswer = selectedAnswers[myth.id];
            const isCorrect = chosenAnswer === myth.isTrue;

            return (
              <div key={myth.id} className="p-4 bg-rose-50/50 rounded-xl border border-rose-200/50 space-y-2">
                <div className="text-xs font-extrabold text-rose-950 font-sans flex items-start gap-2 leading-relaxed">
                  <span className="text-rose-650 font-mono text-xs">Q{myth.id}:</span>
                  <span>"{myth.statement[currentLang]}"</span>
                </div>

                {!hasAnswered ? (
                  <div className="flex gap-2 pt-1">
                    <button
                      onClick={() => handleAnswerClick(myth.id, true)}
                      className="px-4 py-1.5 bg-rose-200 hover:bg-rose-300 text-rose-950 text-xs font-black rounded-lg cursor-pointer"
                    >
                      👍 {currentLang === 'en' ? "This is True" : "এটি সত্য গুঞ্জন"}
                    </button>
                    <button
                      onClick={() => handleAnswerClick(myth.id, false)}
                      className="px-4 py-1.5 bg-rose-200 hover:bg-rose-300 text-rose-950 text-xs font-black rounded-lg cursor-pointer"
                    >
                      👎 {currentLang === 'en' ? "This is FALSE" : "এটি ভুল অবৈজ্ঞানিক"}
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2 animate-fadeIn">
                    <div className="flex items-center gap-1.5">
                      {isCorrect ? (
                        <span className="text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded text-[11px] font-extrabold flex items-center gap-1">
                          🎉 {currentLang === 'en' ? "CORRECT!" : "সঠিক উত্তর!"}
                        </span>
                      ) : (
                        <span className="text-rose-700 bg-rose-100 px-2 py-0.5 rounded text-[11px] font-extrabold flex items-center gap-1">
                          ❌ {currentLang === 'en' ? "NOT QUITE!" : "ভুল উত্তর!"}
                        </span>
                      )}
                      <span className="text-xs font-semibold text-rose-900">
                        {currentLang === 'en' ? "The real truth is: " : "প্রকৃত বিজ্ঞানভিত্তিক সত্যতা: "}{' '}
                        <strong>
                          {myth.isTrue 
                            ? (currentLang === 'en' ? "TRUE" : "সত্য") 
                            : (currentLang === 'en' ? "FALSE" : "ভুল / কুসংস্কার")
                          }
                        </strong>
                      </span>
                    </div>
                    <p className="text-[11px] text-rose-800 leading-relaxed font-semibold font-sans pl-2.5 border-l-2 border-rose-300">
                      {myth.explanation[currentLang]}
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
