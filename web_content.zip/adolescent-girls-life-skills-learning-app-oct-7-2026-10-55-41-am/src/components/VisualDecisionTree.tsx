import React, { useState } from 'react';
import { DecisionTree } from '../types';
import { HelpCircle, Sparkles, AlertCircle, CheckCircle, Scale, Eye, Trash } from 'lucide-react';

interface VisualDecisionTreeProps {
  currentLang: 'en' | 'bn';
  savedTrees: DecisionTree[];
  onSaveTree: (tree: Omit<DecisionTree, 'id' | 'timestamp'>) => void;
  onDeleteTree: (id: string) => void;
  onClearTrees: () => void;
}

export default function VisualDecisionTree({
  currentLang,
  savedTrees,
  onSaveTree,
  onDeleteTree,
  onClearTrees
}: VisualDecisionTreeProps) {
  // Input states
  const [problem, setProblem] = useState<string>('');
  const [optAText, setOptAText] = useState<string>('');
  const [optANewPro, setOptANewPro] = useState<string>('');
  const [optANewCon, setOptANewCon] = useState<string>('');
  const [optAPros, setOptAPros] = useState<string[]>([]);
  const [optACons, setOptACons] = useState<string[]>([]);

  const [optBText, setOptBText] = useState<string>('');
  const [optBNewPro, setOptBNewPro] = useState<string>('');
  const [optBNewCon, setOptBNewCon] = useState<string>('');
  const [optBPros, setOptBPros] = useState<string[]>([]);
  const [optBCons, setOptBCons] = useState<string[]>([]);

  const t = {
    title: { en: "🧭 Visual Decision-Maker: What Should I Do?", bn: "🧭 সঠিক সিদ্ধান্ত নেওয়ার ট্র্যাকার: আমি কী করব?" },
    subtitle: {
      en: "Facing a tough real-world dilemma? Map out the consequences of your choices to make a wise and safe decision.",
      bn: "ভীষণ কোনো দ্বিধা বা বাস্তব সমস্যার মুখে পড়েছ? ভেবে দেখার সুবিধার জন্য দুটি আলাদা পথ সাজাও, এবং ভালো ও খারাপ ফলাফল তুলনা করো।"
    },
    enterProblem: { en: "Describe Your Tough Situation / Dilemma:", bn: "তোমার কঠিন পরিস্থিতি বা দ্বন্দ্বটি লেখো:" },
    probPlaceholder: { 
      en: "e.g., My friend wants me to skip afternoon school classes with her, but the final exam is next week.", 
      bn: "যেমন: আমার বন্ধু আমাকে বিকেলের ক্লাস ফাঁকি দিয়ে ঘুরতে যেতে বলছে, কিন্তু সামনের সপ্তাহেই আমার ফাইনাল পরীক্ষা।" 
    },
    useTemplate: { en: "Or Choose a Village Scenario Guideline Template:", bn: "অথবা আমাদের তৈরি করা একটি গ্রামীণ পরিস্থিতি বেছে নাও:" },
    optionATitle: { en: "Option A (First Way):", bn: "প্রথম পথ (অপশন এ):" },
    optionBTitle: { en: "Option B (Second Way):", bn: "দ্বিতীয় পথ (অপশন বি):" },
    pathPl: { en: "e.g., Skip the lesson and go with my friend.", bn: "যেমন: ক্লাস ফাঁকি দিয়ে বন্ধুর সাথে চলে যাওয়া।" },
    prosTitle: { en: "Good Outcomes (Pros) 👍", bn: "ভালো ফলাফল (সুবিধা) 👍" },
    consTitle: { en: "Bad Consequences (Cons) 👎", bn: "খারাপ প্রভাব বা ঝুঁকি (অসুবিধা) 👎" },
    addBtn: { en: "Add", bn: "যোগ করো" },
    saveModel: { en: "Save Decision Tree Map", bn: "এই ছকটি সেভ করে রাখো" },
    adviceHeader: { en: "⚖️ The Decision Sandbox Balancing Scale", bn: "⚖️ বুদ্ধিমান সিদ্ধান্তের তুলনামূলক দাঁড়িপাল্লা" },
    emptyStateAdvice: {
      en: "Add options and weigh their pros and cons above. We'll show you a comparison to help you choose wisdom over pressure!",
      bn: "উপরে দুটি আলাদা পথ এবং তাদের ভালো-মন্দ দিকগুলো সাজিয়ে লেখো। তুলনামূলক বিচার করতে সাহায্য করার জন্য এখানে আমরা একটি বিশ্লেষণ দেখাবো।"
    },
    savedTreesTitle: { en: "My Saved Dilemma Maps", bn: "আমার সেভ করা সিদ্ধান্তের ছক" },
    noSavedTrees: { en: "No saved maps yet. Fill out the sandbox to record your first!", bn: "এখনো কোনো ছক সেভ করা নেই। নিজের কোনো সমস্যা নিয়ে প্রথম ছক তৈরি করো!" },
    clearBtn: { en: "Reset Decider Workstation", bn: "ছক নতুন করো" },
    clearAllSaved: { en: "Clear Saved Notebook", bn: "সেভ করা ছক মুছো" }
  };

  // Village templates to help inspire girls
  const TEMPLATES = [
    {
      title: { en: "📚 Studies vs. Busy Household Chores", bn: "📚 পড়াশোনা বনাম ঘরের কাজের ব্যস্ততা" },
      problem: { 
        en: "My family is asking me to cook and clean all afternoon instead of preparing for my school exams.",
        bn: "আমার পরীক্ষার আগে বাড়ির লোকেরা পড়ার সময়েও আমাকে সব ঘরের কাজ করতে বলছে।" 
      },
      optA: {
        text: { en: "Stay quiet, do everything, and miss studying.", bn: "চুপচাপ সব কাজ করা এবং নিজের রুটিন অনুযায়ী পড়া বাদ দেওয়া।" },
        pros: { en: ["Avoids any shouting or argument today"], bn: ["আজকের মতো ঝগড়াঝাটি বা বড়দের বকুনি এড়ানো যাবে"] },
        cons: { en: ["I might fail my exam", "I will feel quiet and sad inside"], bn: ["পরীক্ষায় নম্বর কম আসতে পারে বা ফেল করতে পারি", "মানসিকভাবে ভীষণ দুঃখ বা ক্লান্তি অনুভব করব"] }
      },
      optB: {
        text: { en: "Talk assertively, state my needs, and divide chores.", bn: "দৃঢ়তার সাথে শান্তভাবে বোঝানো এবং পরীক্ষা শেষে সব কাজ করে দেওয়ার প্রতিশ্রুতি দেওয়া।" },
        pros: { en: ["I get dedicated exam study hours", "My family starts respecting my learning dreams"], bn: ["গুরুত্বপূর্ণ পড়াশোনার জন্য সময় পাব", "বাড়ির লোকজন আমার স্বপ্ন ও পড়ার জেদকে সম্মান দিতে শিখবে"] },
        cons: { en: ["They might feel slightly annoyed initially"], bn: ["প্রথম প্রথম বাড়ির লোক বা কোনো সদস্য হয়তো একটু রেগে যেতে পারেন"] }
      }
    },
    {
      title: { en: "🎒 Friend Overcomes Safety Boundaries", bn: "🎒 সহপাঠীর অন্যায্য অনুরোধ" },
      problem: {
        en: "My popular school friend asks me to lie to my parents and hang out by the lake with people I do not trust.",
        bn: "আমার এক সহপাঠী আমাকে বাবা-মায়ের কাছে মিথ্যে বলে একটি অপরিচিত জায়গায় ঘুরে বেড়াতে জোর করছে।"
      },
      optA: {
        text: { en: "Agree and lie to fit in and remain popular.", bn: "বন্ধুকে খুশি করতে রাজি হওয়া এবং বাড়িতে মিথ্যে অজুহাত দেওয়া।" },
        pros: { en: ["My friend remains happy with me"], bn: ["বন্ধু আমার ওপর রেগে যাবে না, দলে থাকা যাবে"] },
        cons: { en: ["I might end up in an unsafe physical environment", "My parents will feel deeply hurt if they learn I lied"], bn: ["অপরিচিতদের মাঝে চরম নিরাপত্তা ঝুঁকিতে পড়তে পারি", "বাবা-মা সত্যিটা জানতে পারলে আমার প্রতি বিশ্বাস হারাবেন"] }
      },
      optB: {
        text: { en: "Refuse firmly and study for my goals instead.", bn: "দৃঢ়ভাবে 'না' বলা এবং নিজের স্বস্তি ও সুরক্ষাকে প্রাধান্য দেওয়া।" },
        pros: { en: ["I remain perfectly safe", "I learn to state my boundaries confidently"], bn: ["আমি সম্পূর্ণ সুরক্ষিত এবং বিপদমুক্ত থাকব", "আমি আত্মবিশ্বাসের সাথে সীমানা টানতে শিখব"] },
        cons: { en: ["My friend might be annoyed for a few days"], bn: ["বন্ধু হয়তো কয়েকদিন রেগে গিয়ে কথা বলবে না"] }
      }
    },
    {
      title: { en: "👰 Early Marriage Pressure vs. Education", bn: "👰 বাল্যবিয়ে চাপ বনাম উচ্চশিক্ষার স্বপ্ন" },
      problem: {
        en: "My relatives are pressurizing my parents to marry me off at 16, but I want to complete high school and become a nurse.",
        bn: "আমার আত্মীয়স্বজনরা ১৬ বছর বয়সে আমাকে বিয়ে দেওয়ার জন্য মা-বাবাকে চাপ দিচ্ছেন, কিন্তু আমি স্কুল শেষ করে নার্স হতে চাই।"
      },
      optA: {
        text: { en: "Stay silent and accept the early marriage.", bn: "চুপচাপ মেনে নেওয়া এবং অল্প বয়সে বিয়েতে সম্মতি দেওয়া।" },
        pros: { en: ["Avoids family tension and relative criticism today"], bn: ["আপাতত বাড়ির লোক খুশি হবে এবং কথা শুনতে হবে না"] },
        cons: { en: ["I will lose my career and educational independence", "Serious health risks of teenage pregnancy"], bn: ["নিজের পায়ে দাঁড়ানোর স্বপ্ন নষ্ট হবে", "অল্প বয়সে মা হওয়ার শারীরিক ও মানসিক স্বাস্থ্য ঝুঁকি বাড়বে"] }
      },
      optB: {
        text: { en: "Contact school teachers, state legal rights, and seek counselor/helpline assistance.", bn: "স্কুলের শিক্ষক-শিক্ষিকাদের জানানো, চাইল্ডলাইন (১০৯৮) বা সখীর হেল্পলাইনে সাহায্য চাওয়া।" },
        pros: { en: ["Save my education and career dreams", "Support from school authority and laws"], bn: ["নিজের পড়াশোনা ও উজ্জ্বল ভবিষ্যৎ রক্ষা পাবে", "শিক্ষক ও আইনের সাহায্য পাওয়া যাবে"] },
        cons: { en: ["Relatives may complain or get angry initially"], bn: ["আত্মীয়রা সাময়িকভাবে অসন্তুষ্ট হতে পারেন বা রাগ করতে পারেন"] }
      }
    },
    {
      title: { en: "📱 Smartphone Scrolling vs. Active Study", bn: "📱 ফোনের অতিরিক্ত নেশা বনাম পড়াশোনা" },
      problem: {
        en: "I spend hours on social apps/games every evening, leaving no time to study or sleep well.",
        bn: "আমি প্রতিদিন বিকেলে ও রাতে মোবাইল ফোনে ঘণ্টার পর ঘণ্টা কাটায়, যার ফলে পড়াশোনা বা ঘুমের সময় থাকে না।"
      },
      optA: {
        text: { en: "Continue scrolling and ignore my low school grades.", bn: "ফোনে পড়ে থাকা এবং পরীক্ষার খারাপ ফল অবহেলা করা।" },
        pros: { en: ["Instant cheap entertainment and virtual distraction"], bn: ["মুহূর্তের জন্য আনন্দ বা সাময়িক মোবাইল গেমিং বিনোদন"] },
        cons: { en: ["Poor school grades and low focus", "Severe eye strain and headache"], bn: ["পরীক্ষায় অত্যন্ত খারাপ ফল করা ও মনোযোগ কমে যাওয়া", "চোখের ক্ষতি, অনিদ্রা ও মাথা ব্যথার সমস্যা"] }
      },
      optB: {
        text: { en: "Set an app timer limit, put the phone in another room during study hours.", bn: "ফোনে একটি অ্যাপ টাইমার লক সেট করা, এবং পড়ার সময়ে ফোন অন্য ঘরে রাখা।" },
        pros: { en: ["Improved focus, perfect grades, and healthy sleep", "More time for offline sports or hobbies"], bn: ["পড়াশোনায় দারুণ মনোযোগ, ভালো রেজাল্ট ও চমৎকার ঘুম", "বন্ধুদের সাথে মাঠে খেলাধুলা ও হাতের কাজের সুযোগ"] },
        cons: { en: ["Feel bored and restless for the first few days"], bn: ["প্রথম ২-৩ দিন মোবাইল না পেয়ে একঘেয়েমি বা অস্থির লাগতে পারে"] }
      }
    },
    {
      title: { en: "🧼 Menstruation Myth Taboo vs. Hygiene", bn: "🧼 ঋতুস্রাব নিয়ে কুসংস্কার বনাম স্বাস্থ্য" },
      problem: {
        en: "During my periods, family members tell me to sleep in a cold outhouse and avoid healthy food like milk or fish.",
        bn: "পিরিয়ড চলাকালীন বাড়ির অনেকে আমাকে নোংরা বা অস্পৃশ্য মনে করে আলাদা ঘরে থাকতে এবং পুষ্টিকর খাবার খেতে নিষেধ করছেন।"
      },
      optA: {
        text: { en: "Follow the unsafe unhygienic traditional taboos blindly.", bn: "সব অন্ধ কুসংস্কার মেনে নোংরা কাপড় ব্যবহার করা ও কম খাওয়া।" },
        pros: { en: ["Superstitious elders don't criticize me today"], bn: ["বাড়ির বয়স্ক বা রক্ষণশীল সদস্যরা খুঁত ধরবেন না"] },
        cons: { en: ["Risk of severe uterine/urinary infections", "Physical weakness and anemia"], bn: ["গর্ভাশয়ে বা প্রস্রাবে মারাত্মক ইনফেকশন ও জটিল রোগ হতে পারে", "রক্তস্বল্পতা ও শারীরিক দুর্বলতা দেখা দেবে"] }
      },
      optB: {
        text: { en: "Use clean cotton pads, eat nutritious meals, and politely educate parents with health booklets.", bn: "পরিষ্কার প্যাড বা ধোয়া শুকনো কাপড় ব্যবহার করা, পুষ্টিকর খাবার খাওয়া এবং বাড়ির বড়দের সখীর বই থেকে বিজ্ঞান বোঝানো।" },
        pros: { en: ["Stay strong, disease-free, and confident", "Build scientific awareness in my family"], bn: ["শরীর সম্পূর্ণ সুস্থ, সুরক্ষিত ও ঝরঝরে থাকবে", "পরিবারে বিজ্ঞানসম্মত ও স্বাস্থ্যকর পরিবেশ তৈরি হবে"] },
        cons: { en: ["Some old relatives might complain about break in customs"], bn: ["কিছু রক্ষণশীল আত্মীয় হয়তো নিয়ম ভাঙার কথা তুলে অসন্তোষ প্রকাশ করতে পারেন"] }
      }
    },
    {
      title: { en: "🥬 Anemia and Nutrition Dilemma", bn: "🥬 রক্তস্বল্পতা বনাম ফাস্টফুডের আড্ডা" },
      problem: {
        en: "I have low hemoglobin (anemia) and need iron-rich food, but my friends call me boring if I don't buy processed chips and carbonated sodas with them.",
        bn: "আমার শরীরে হিমোগ্লোবিন কম (রক্তস্বল্পতা) এবং আয়রনযুক্ত খাবার খাওয়া দরকার, কিন্তু ফাস্টফুড না কিনে শাকসবজি খেলে বন্ধুরা আমাকে নিয়ে হাসাহাসি করে।"
      },
      optA: {
        text: { en: "Spend my pocket money on unhealthy street snacks to look cool.", bn: "বন্ধুদের দলে স্মার্ট সাজতে পকেটের টাকা দিয়ে অস্বাস্থ্যকর ফাস্টফুড কেনা।" },
        pros: { en: ["My peers consider me trendy and cool"], bn: ["বন্ধুদের আড্ডায় দলছুট হতে হবে না বা তাদের সাথে তাল মেলানো যাবে"] },
        cons: { en: ["Anemia worsens, leading to constant fatigue and fainting", "No pocket money left for dream goals"], bn: ["রক্তস্বল্পতা বেড়ে গিয়ে মাথা ঘোরা ও শরীর সবসময় ক্লান্ত থাকা", "ভবিষ্যতের স্বপ্নের কোনো জিনিস কেনার টাকা বাঁচবে না"] }
      },
      optB: {
        text: { en: "Eat spinach, eggs, and iron-rich home-cooked food; tell friends about my health priority.", bn: "ডিম, পুঁইশাক, ডালিম ইত্যাদি আয়রনযুক্ত পুষ্টিকর খাবার খাওয়া এবং বন্ধুদের নিজের স্বাস্থ্যের কথা বোঝানো।" },
        pros: { en: ["Become energetic, focus in class, and cure anemia", "Save extra rupees in my piggy wallet"], bn: ["শরীর সতেজ ও কর্মঠ হবে, রক্তস্বল্পতা দূর হবে", "ওয়ালেটে বেশ কিছু টাকা বেঁচে যাবে স্বপ্নের জিনিস কেনার জন্য"] },
        cons: { en: ["Friends might tease me for bringing leafy greens initially"], bn: ["শুরুতে বন্ধুরা হয়তো শাকসবজি বা টিফিন নিয়ে সামান্য ঠাট্টা করতে পারে"] }
      }
    }
  ];

  const loadTemplate = (idx: number) => {
    const tpl = TEMPLATES[idx];
    setProblem(tpl.problem[currentLang]);
    setOptAText(tpl.optA.text[currentLang]);
    setOptAPros(tpl.optA.pros[currentLang]);
    setOptACons(tpl.optA.cons[currentLang]);

    setOptBText(tpl.optB.text[currentLang]);
    setOptBPros(tpl.optB.pros[currentLang]);
    setOptBCons(tpl.optB.cons[currentLang]);
  };

  const addProA = () => { if (optANewPro.trim()) { setOptAPros([...optAPros, optANewPro.trim()]); setOptANewPro(''); } };
  const addConA = () => { if (optANewCon.trim()) { setOptACons([...optACons, optANewCon.trim()]); setOptANewCon(''); } };

  const addProB = () => { if (optBNewPro.trim()) { setOptBPros([...optBPros, optBNewPro.trim()]); setOptBNewPro(''); } };
  const addConB = () => { if (optBNewCon.trim()) { setOptBCons([...optBCons, optBNewCon.trim()]); setOptBNewCon(''); } };

  const handleSaveTree = () => {
    if (!problem.trim() || !optAText.trim() || !optBText.trim()) return;
    onSaveTree({
      problem: problem.trim(),
      optionA: { text: optAText.trim(), pros: optAPros, cons: optACons },
      optionB: { text: optBText.trim(), pros: optBPros, cons: optBCons }
    });

    handleReset();
  };

  const handleReset = () => {
    setProblem('');
    setOptAText('');
    setOptAPros([]);
    setOptACons([]);
    setOptBText('');
    setOptBPros([]);
    setOptBCons([]);
  };

  return (
    <div id="decision-tree-card" className="bg-white p-4 md:p-6 rounded-2xl border border-slate-200 shadow-xs max-w-4xl mx-auto space-y-6">
      
      {/* Title */}
      <div>
        <h3 className="text-md font-extrabold text-indigo-950 flex items-center gap-2">
          <Scale className="w-5 h-5 text-indigo-600" />
          {t.title[currentLang]}
        </h3>
        <p className="text-xs text-slate-600 mt-1 lines-spaced font-sans font-normal">
          {t.subtitle[currentLang]}
        </p>
      </div>

      {/* Templates Row */}
      <div className="bg-indigo-50/50 p-3 rounded-xl border border-indigo-100">
        <span className="block text-[11px] font-extrabold text-indigo-950 mb-2">
          {t.useTemplate[currentLang]}
        </span>
        <div className="flex flex-wrap gap-2">
          {TEMPLATES.map((tpl, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => loadTemplate(idx)}
              className="py-1.5 px-3 bg-white hover:bg-indigo-50 text-indigo-950 text-xs font-bold rounded-lg border border-indigo-150 cursor-pointer shadow-2xs transition-colors"
            >
              🚀 {tpl.title[currentLang]}
            </button>
          ))}
        </div>
      </div>

      {/* Input Problem */}
      <div className="space-y-1.5">
        <label className="block text-xs font-bold text-slate-800">
          {t.enterProblem[currentLang]}
        </label>
        <textarea
          rows={2}
          value={problem}
          onChange={(e) => setProblem(e.target.value)}
          placeholder={t.probPlaceholder[currentLang]}
          className="w-full text-xs p-3 border border-slate-200 rounded-lg focus:ring-1 focus:ring-indigo-500 bg-white"
        />
      </div>

      {/* Comparison Sandbox - Split columns */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Option A Box */}
        <div className="p-4 bg-slate-50/70 border border-slate-200 rounded-xl space-y-4">
          <div className="space-y-1">
            <label className="block text-xs font-black text-rose-950 uppercase tracking-wider">
              {t.optionATitle[currentLang]}
            </label>
            <input
              type="text"
              value={optAText}
              onChange={(e) => setOptAText(e.target.value)}
              placeholder={t.pathPl[currentLang]}
              className="w-full text-xs p-2 border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Pros List A */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
              {t.prosTitle[currentLang]}
            </span>
            <div className="flex gap-1">
              <input
                type="text"
                value={optANewPro}
                onChange={(e) => setOptANewPro(e.target.value)}
                placeholder={currentLang === 'en' ? "Add a positive outcome" : "একটি সুবিধা লেখো..."}
                className="flex-1 text-xs px-2 py-1 border border-slate-200 rounded-md bg-white"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addProA())}
              />
              <button
                type="button"
                onClick={addProA}
                className="px-3 bg-slate-200 text-slate-800 text-xs rounded-md font-bold hover:bg-slate-300 cursor-pointer"
              >
                {t.addBtn[currentLang]}
              </button>
            </div>
            {optAPros.length > 0 && (
              <ul className="space-y-1 pl-1">
                {optAPros.map((pro, i) => (
                  <li key={i} className="text-xs text-slate-700 flex items-start gap-1.5 font-medium leading-relaxed">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{pro}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Cons List A */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
              {t.consTitle[currentLang]}
            </span>
            <div className="flex gap-1">
              <input
                type="text"
                value={optANewCon}
                onChange={(e) => setOptANewCon(e.target.value)}
                placeholder={currentLang === 'en' ? "Add a danger/bad consequence" : "একটি ঝুঁকি লেখো..."}
                className="flex-1 text-xs px-2 py-1 border border-slate-200 rounded-md bg-white"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addConA())}
              />
              <button
                type="button"
                onClick={addConA}
                className="px-3 bg-slate-200 text-slate-800 text-xs rounded-md font-bold hover:bg-slate-300 cursor-pointer"
              >
                {t.addBtn[currentLang]}
              </button>
            </div>
            {optACons.length > 0 && (
              <ul className="space-y-1 pl-1">
                {optACons.map((con, i) => (
                  <li key={i} className="text-xs text-slate-700 flex items-start gap-1.5 font-medium leading-relaxed">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                    <span className="text-rose-950 font-medium">{con}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Option B Box */}
        <div className="p-4 bg-slate-50/70 border border-slate-200 rounded-xl space-y-4">
          <div className="space-y-1">
            <label className="block text-xs font-black text-indigo-950 uppercase tracking-wider">
              {t.optionBTitle[currentLang]}
            </label>
            <input
              type="text"
              value={optBText}
              onChange={(e) => setOptBText(e.target.value)}
              placeholder={t.pathPl[currentLang]}
              className="w-full text-xs p-2 border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Pros List B */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
              {t.prosTitle[currentLang]}
            </span>
            <div className="flex gap-1">
              <input
                type="text"
                value={optBNewPro}
                onChange={(e) => setOptBNewPro(e.target.value)}
                placeholder={currentLang === 'en' ? "Add a positive outcome" : "একটি সুবিধা লেখো..."}
                className="flex-1 text-xs px-2 py-1 border border-slate-200 rounded-md bg-white"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addProB())}
              />
              <button
                type="button"
                onClick={addProB}
                className="px-3 bg-slate-200 text-slate-800 text-xs rounded-md font-bold hover:bg-slate-300 cursor-pointer"
              >
                {t.addBtn[currentLang]}
              </button>
            </div>
            {optBPros.length > 0 && (
              <ul className="space-y-1 pl-1">
                {optBPros.map((pro, i) => (
                  <li key={i} className="text-xs text-slate-700 flex items-start gap-1.5 font-medium leading-relaxed">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{pro}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Cons List B */}
          <div className="space-y-2">
            <span className="text-[11px] font-bold text-slate-700 flex items-center gap-1">
              {t.consTitle[currentLang]}
            </span>
            <div className="flex gap-1">
              <input
                type="text"
                value={optBNewCon}
                onChange={(e) => setOptBNewCon(e.target.value)}
                placeholder={currentLang === 'en' ? "Add a danger/bad consequence" : "একটি ঝুঁকি লেখো..."}
                className="flex-1 text-xs px-2 py-1 border border-slate-200 rounded-md bg-white"
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addConB())}
              />
              <button
                type="button"
                onClick={addConB}
                className="px-3 bg-slate-200 text-slate-800 text-xs rounded-md font-bold hover:bg-slate-300 cursor-pointer"
              >
                {t.addBtn[currentLang]}
              </button>
            </div>
            {optBCons.length > 0 && (
              <ul className="space-y-1 pl-1">
                {optBCons.map((con, i) => (
                  <li key={i} className="text-xs text-slate-700 flex items-start gap-1.5 font-medium leading-relaxed">
                    <AlertCircle className="w-3.5 h-3.5 text-rose-500 shrink-0 mt-0.5" />
                    <span className="text-rose-950 font-medium">{con}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

      </div>

      {/* Comparison analysis scale output */}
      <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-2">
        <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-500" />
          {t.adviceHeader[currentLang]}
        </h4>
        
        {(!optAText || !optBText) ? (
          <p className="text-slate-500 italic">
            {t.emptyStateAdvice[currentLang]}
          </p>
        ) : (
          <div className="space-y-2 text-slate-700 leading-normal">
            <p className="font-semibold text-slate-900">
              {currentLang === 'en' 
                ? "💡 Wisdom Comparison Insight Summary:" 
                : "💡 সিদ্ধান্তের অন্তর্দৃষ্টি বিশ্লেষণ: "
              }
            </p>
            <p className="font-medium font-sans">
              {currentLang === 'en' 
                ? `Option A has ${optACons.length} direct risks, while Option B has ${optBCons.length} risks. Usually, paths that preserve your educational progress, health, or safety provide the best long-term success. State your choice with peaceful confidence!`
                : `১ম পথে (অপশন এ) রয়েছে ${optACons.length} টি বড় ঝুঁকি, যেখানে ২য় পথে (অপশন বি) ঝুঁকির সংখ্যা ${optBCons.length} টি। সাধারণত যে সিদ্ধান্ত তোমার পড়াশোনা ও নিরাপত্তাকে টিকিয়ে রাখে, তা-ই দীর্ঘমেয়াদে সবচেয়ে বেশি সুখ এনে দেয়!`
              }
            </p>
          </div>
        )}
      </div>

      {/* Save Action bar */}
      <div className="flex gap-2 justify-end pt-2">
        <button
          type="button"
          onClick={handleReset}
          className="py-2 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs cursor-pointer"
        >
          {t.clearBtn[currentLang]}
        </button>
        <button
          type="button"
          onClick={handleSaveTree}
          disabled={!problem.trim() || !optAText.trim() || !optBText.trim()}
          className={`py-2 px-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-xs cursor-pointer transition-all ${
            (!problem.trim() || !optAText.trim() || !optBText.trim()) ? 'opacity-40 cursor-not-allowed' : ''
          }`}
        >
          {t.saveModel[currentLang]}
        </button>
      </div>

      {/* Saved Notebook list */}
      <div className="pt-4 border-t border-slate-150 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-xs font-extrabold text-slate-800 flex items-center gap-1">
            <Eye className="w-4 h-4 text-emerald-600" />
            {t.savedTreesTitle[currentLang]}
          </h4>
          {savedTrees.length > 0 && (
            <button
              onClick={onClearTrees}
              className="text-[10px] text-rose-600 hover:underline font-bold cursor-pointer"
            >
              {t.clearAllSaved[currentLang]}
            </button>
          )}
        </div>

        {savedTrees.length === 0 ? (
          <p className="text-[11px] text-slate-400 italic">
            {t.noSavedTrees[currentLang]}
          </p>
        ) : (
          <div className="space-y-4">
            {savedTrees.map((tree) => (
              <div key={tree.id} className="p-4 bg-indigo-50/50 border border-slate-100 rounded-xl space-y-3 relative">
                
                {/* Delete individual */}
                <button
                  type="button"
                  onClick={() => onDeleteTree(tree.id)}
                  className="absolute right-3 top-3 text-slate-300 hover:text-rose-600 cursor-pointer p-1"
                >
                  <Trash className="w-4 h-4" />
                </button>

                <div>
                  <span className="text-[10px] text-indigo-700 font-extrabold uppercase tracking-wide">Dilemma Situation:</span>
                  <p className="text-xs font-extrabold text-slate-900 mt-0.5 leading-relaxed">{tree.problem}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1.5 border-t border-slate-200">
                  <div className="space-y-1">
                    <p className="text-[10px] text-rose-900 font-black uppercase">Option A: {tree.optionA.text}</p>
                    <div className="text-[11px] space-y-0.5">
                      {tree.optionA.pros.length > 0 && (
                        <p className="text-slate-600 font-medium font-sans">👍 Pros: {tree.optionA.pros.join(', ')}</p>
                      )}
                      {tree.optionA.cons.length > 0 && (
                        <p className="text-rose-900 font-medium font-sans">👎 Risks: {tree.optionA.cons.join(', ')}</p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <p className="text-[10px] text-indigo-900 font-black uppercase">Option B: {tree.optionB.text}</p>
                    <div className="text-[11px] space-y-0.5">
                      {tree.optionB.pros.length > 0 && (
                        <p className="text-slate-600 font-medium font-sans">👍 Pros: {tree.optionB.pros.join(', ')}</p>
                      )}
                      {tree.optionB.cons.length > 0 && (
                        <p className="text-rose-900 font-medium font-sans">👎 Risks: {tree.optionB.cons.join(', ')}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
