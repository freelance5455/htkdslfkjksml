import React from 'react';

interface StJohnLogoProps {
  className?: string;
  size?: number;
}

export default function StJohnLogo({ className = '', size = 50 }: StJohnLogoProps) {
  return (
    <img
      src="/assets/icon.png"
      alt="St. John Ambulance Association Raiganj"
      style={{ width: size, height: size }}
      className={`object-contain rounded-full ${className}`}
      referrerPolicy="no-referrer"
    />
  );
}
