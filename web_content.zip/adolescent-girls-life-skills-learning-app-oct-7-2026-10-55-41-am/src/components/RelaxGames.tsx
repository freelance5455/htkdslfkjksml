import React, { useState, useEffect } from 'react';
import { 
  Smile, 
  RotateCcw, 
  Sparkles, 
  Award, 
  HelpCircle, 
  Shuffle, 
  User, 
  Bot, 
  AlertCircle, 
  Grid3X3, 
  Check, 
  Heart,
  Lightbulb,
  BookOpen,
  Volume2
} from 'lucide-react';

interface RelaxGamesProps {
  currentLang: 'en' | 'bn';
  starPoints: number;
  onRewardStars: (stars: number, description: string) => void;
}

// ----------------------------------------------------
// Game Types & Constants - WORD PUZZLES
// ----------------------------------------------------
const WORD_PUZZLES = [
  {
    word: 'PAD',
    scrambled: 'ADP',
    hints: {
      en: 'A soft hygiene napkin used by girls during menstruation cycles.',
      bn: 'ঋতুস্রাব বা পিরিয়ডের সময় স্বাস্থ্যবিধি মেনে ব্যবহার করার প্যাড।'
    }
  },
  {
    word: 'BODY',
    scrambled: 'YDBO',
    hints: {
      en: 'The physical structure of a person experiencing adolescent growth.',
      bn: 'কৈশোরে বৃদ্ধি ও রূপান্তরের মধ্য দিয়ে যাওয়া আমাদের শরীর।'
    }
  },
  {
    word: 'CARE',
    scrambled: 'RACE',
    hints: {
      en: 'Looking after yourself with love, attention, and hygiene.',
      bn: 'নিজের প্রতি পরম যত্ন ও ভালোবাসা বজায় রাখার অনুভূতি।'
    }
  },
  {
    word: 'LOVE',
    scrambled: 'EVOL',
    hints: {
      en: 'Deep affection and respect for yourself and those around you.',
      bn: 'নিজের এবং আশেপাশের সকলের প্রতি গভীর শ্রদ্ধা ও ভালোবাসা।'
    }
  },
  {
    word: 'SAFE',
    scrambled: 'AFES',
    hints: {
      en: 'Free from danger, hurt, or early social pressures.',
      bn: 'যে কোনো বিপদ, অসম্মান বা বাল্যবিয়ের চাপ থেকে মুক্ত ও সুরক্ষিত থাকার অবস্থা।'
    }
  },
  {
    word: 'GIRL',
    scrambled: 'ILRG',
    hints: {
      en: 'A young female full of potential, courage, and dreams.',
      bn: 'সীমাহীন সম্ভাবনা, সাহস এবং অনেক সুন্দর স্বপ্নের অধিকারী এক কিশোরী।'
    }
  },
  {
    word: 'SISTER',
    scrambled: 'SSETIR',
    hints: {
      en: 'A supportive girl sibling or reliable best friend who always has your back.',
      bn: 'আপন বোন বা এমন বিশ্বস্ত সখী যে সর্বদা কঠিন সময়ে পাশে থাকে।'
    }
  },
  {
    word: 'HEALTH',
    scrambled: 'HLAETH',
    hints: {
      en: 'The overall physical and mental state of well-being.',
      bn: 'শারীরিক ও মানসিক সুস্থতা এবং ভালো থাকার স্বাভাবিক অবস্থা।'
    }
  },
  {
    word: 'DIARY',
    scrambled: 'YRDIA',
    hints: {
      en: 'A private place where you write down your daily feelings.',
      bn: 'যে খাতা বা ডায়েরিতে তুমি প্রতিদিনের সুখ-দুঃখ ও অনুভূতি লিখে রাখো।'
    }
  },
  {
    word: 'BUDGET',
    scrambled: 'GDEBTU',
    hints: {
      en: 'A smart financial plan to track pocket allowance and savings.',
      bn: 'নিজের পকেটমানি বা উপার্জিত অর্থের সুষম ব্যয় ও সঞ্চয়ের পরিকল্পনা।'
    }
  },
  {
    word: 'RIGHTS',
    scrambled: 'SIGHTR',
    hints: {
      en: 'Universal legal power and claims that protect children and women.',
      bn: 'নারী ও শিশুদের সুরক্ষার জন্য নির্ধারিত আইনি অধিকারসমূহ।'
    }
  },
  {
    word: 'EMPATHY',
    scrambled: 'MTEPHAY',
    hints: {
      en: 'Understanding and sharing other people\'s emotional feelings.',
      bn: 'অন্যের আনন্দ ও দুঃখ নিজের মন দিয়ে বুঝতে শেখা বা সহানুভূতি।'
    }
  },
  {
    word: 'COURAGE',
    scrambled: 'ACUGOER',
    hints: {
      en: 'Inner strength to speak up for rules or what is right.',
      bn: 'সত্যি ও ন্যায়ের পক্ষে কথা বলার মতো মনের সাহস ও শক্তি।'
    }
  },
  {
    word: 'HYGIENE',
    scrambled: 'YENEIGH',
    hints: {
      en: 'Keeping your body clean during periods to protect school attendance.',
      bn: 'সুস্বাস্থ্যের জন্য নিজের শরীর ও ব্যবহারের কাপড় পরিষ্কার রাখার নিয়ম বা স্বাস্থ্যবিধি।'
    }
  },
  {
    word: 'EMPOWER',
    scrambled: 'WMREOEP',
    hints: {
      en: 'To give power, authority, and confidence to make choices.',
      bn: 'নিজেকে আত্মবিশ্বাসী, দক্ষ এবং স্বাবলম্বী করে তোলা বা ক্ষমতায়ন।'
    }
  },
  {
    word: 'CONFIDENCE',
    scrambled: 'CIECDNEONF',
    hints: {
      en: 'A strong feeling of trust in one\'s own abilities, qualities, and judgment.',
      bn: 'নিজের কাজের দক্ষতা ও বুদ্ধিমত্তার উপর দৃঢ় বিশ্বাস বা আত্মবিশ্বাস।'
    }
  },
  {
    word: 'RESILIENCE',
    scrambled: 'ILERENCEIS',
    hints: {
      en: 'The capacity to recover quickly from difficulties; toughness and strength.',
      bn: 'কোনো বাধার সম্মুখীন হলে ঘাবড়ে না গিয়ে আবার ঘুরে দাঁড়ানোর ক্ষমতা।'
    }
  },
  {
    word: 'ADOLESCENT',
    scrambled: 'TDLSEAECNO',
    hints: {
      en: 'A young person developing from a child into an adult during transition years.',
      bn: '১০ থেকে ১৯ বছর বয়সের কিশোরী বা বাড়ন্ত বয়সের রূপান্তরকাল।'
    }
  },
  {
    word: 'DECISION',
    scrambled: 'SNDICOEI',
    hints: {
      en: 'Making a wise, thought-out choice in complex situations.',
      bn: 'কঠিন পরিস্থিতিতে উপস্থিত বুদ্ধি খাঁটিয়ে সঠিক সিদ্ধান্ত নেওয়া।'
    }
  },
  {
    word: 'PUBERTY',
    scrambled: 'YBRUTEP',
    hints: {
      en: 'The life stage of rapid body growth and physical maturity.',
      bn: 'কৈশোরকালীন শারীরিক রূপান্তর ও বয়ঃসন্ধির বিশেষ সময়কাল।'
    }
  }
];

// ----------------------------------------------------
// Game Types & Constants - PICTURE PUZZLES
// ----------------------------------------------------
const PUZZLE_IMAGES = [
  {
    url: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=600&q=80',
    title: {
      en: 'The Taj Mahal, India',
      bn: 'তাজমহল, ভারত'
    }
  },
  {
    url: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=600&q=80',
    title: {
      en: 'The Eiffel Tower, Paris',
      bn: 'আইফেল টাওয়ার, প্যারিস'
    }
  },
  {
    url: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=600&q=80',
    title: {
      en: 'The Colosseum, Rome',
      bn: 'কলোসিয়াম, রোম'
    }
  },
  {
    url: 'https://images.unsplash.com/photo-1509024644558-2f56ce76c490?auto=format&fit=crop&w=600&q=80',
    title: {
      en: 'Machu Picchu, Peru',
      bn: 'মাচু পিচু, পেরু'
    }
  },
  {
    url: 'https://images.unsplash.com/photo-1508873696983-2df519f0397e?auto=format&fit=crop&w=600&q=80',
    title: {
      en: 'The Great Wall of China',
      bn: 'চীনের মহাপ্রাচীর, চীন'
    }
  },
  {
    url: 'https://images.unsplash.com/photo-1539650116574-8efeb43e2750?auto=format&fit=crop&w=600&q=80',
    title: {
      en: 'Great Pyramids of Giza, Egypt',
      bn: 'গিজার পিরামিড, মিশর'
    }
  }
];

// ----------------------------------------------------
// Chess Piece Rules & Setup
// ----------------------------------------------------
type ChessPiece = {
  type: 'p' | 'r' | 'n' | 'b' | 'q' | 'k';
  color: 'w' | 'b';
};

type ChessBoardState = (ChessPiece | null)[][];

const INITIAL_CHESS_BOARD: ChessBoardState = [
  [
    { type: 'r', color: 'b' }, { type: 'n', color: 'b' }, { type: 'b', color: 'b' }, { type: 'q', color: 'b' },
    { type: 'k', color: 'b' }, { type: 'b', color: 'b' }, { type: 'n', color: 'b' }, { type: 'r', color: 'b' }
  ],
  [
    { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' },
    { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }, { type: 'p', color: 'b' }
  ],
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null),
  Array(8).fill(null),
  [
    { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' },
    { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }, { type: 'p', color: 'w' }
  ],
  [
    { type: 'r', color: 'w' }, { type: 'n', color: 'w' }, { type: 'b', color: 'w' }, { type: 'q', color: 'w' },
    { type: 'k', color: 'w' }, { type: 'b', color: 'w' }, { type: 'n', color: 'w' }, { type: 'r', color: 'w' }
  ]
];

const CHESS_PIECE_REPRESENTATION: Record<string, string> = {
  'w-k': '♔', 'w-q': '♕', 'w-r': '♖', 'w-b': '♗', 'w-n': '♘', 'w-p': '♙',
  'b-k': '♚', 'b-q': '♛', 'b-r': '♜', 'b-b': '♝', 'b-n': '♞', 'b-p': '♟'
};

// Chess legal move validator
function isValidChessMove(
  sr: number,
  sc: number,
  dr: number,
  dc: number,
  piece: ChessPiece,
  board: ChessBoardState
): boolean {
  // Can't stay in the same cell
  if (sr === dr && sc === dc) return false;

  // Can't capture a piece of the same color
  const targetPiece = board[dr][dc];
  if (targetPiece && targetPiece.color === piece.color) return false;

  const rowDiff = dr - sr;
  const colDiff = dc - sc;
  const absR = Math.abs(rowDiff);
  const absC = Math.abs(colDiff);

  switch (piece.type) {
    case 'p': { // Pawn
      const dir = piece.color === 'w' ? -1 : 1;
      const startRow = piece.color === 'w' ? 6 : 1;

      // Moving straight ahead
      if (colDiff === 0) {
        if (rowDiff === dir) {
          return !targetPiece;
        }
        if (sr === startRow && rowDiff === 2 * dir) {
          const midR = sr + dir;
          return !board[midR][sc] && !targetPiece;
        }
      }
      // Diagonal capture
      if (absC === 1 && rowDiff === dir) {
        return !!targetPiece && targetPiece.color !== piece.color;
      }
      return false;
    }

    case 'r': { // Rook
      if (rowDiff !== 0 && colDiff !== 0) return false;
      const stepR = rowDiff === 0 ? 0 : rowDiff > 0 ? 1 : -1;
      const stepC = colDiff === 0 ? 0 : colDiff > 0 ? 1 : -1;
      let currR = sr + stepR;
      let currC = sc + stepC;
      while (currR !== dr || currC !== dc) {
        if (board[currR][currC]) return false; // Blocked pathway
        currR += stepR;
        currC += stepC;
      }
      return true;
    }

    case 'b': { // Bishop
      if (absR !== absC) return false;
      const stepR = rowDiff > 0 ? 1 : -1;
      const stepC = colDiff > 0 ? 1 : -1;
      let currR = sr + stepR;
      let currC = sc + stepC;
      while (currR !== dr || currC !== dc) {
        if (board[currR][currC]) return false; // Blocked pathway
        currR += stepR;
        currC += stepC;
      }
      return true;
    }

    case 'n': { // Knight (L-move)
      return (absR === 2 && absC === 1) || (absR === 1 && absC === 2);
    }

    case 'q': { // Queen (Combination of Rook and Bishop)
      // Rook style check
      if (rowDiff === 0 || colDiff === 0) {
        const stepR = rowDiff === 0 ? 0 : rowDiff > 0 ? 1 : -1;
        const stepC = colDiff === 0 ? 0 : colDiff > 0 ? 1 : -1;
        let currR = sr + stepR;
        let currC = sc + stepC;
        while (currR !== dr || currC !== dc) {
          if (board[currR][currC]) return false;
          currR += stepR;
          currC += stepC;
        }
        return true;
      }
      // Bishop style check
      if (absR === absC) {
        const stepR = rowDiff > 0 ? 1 : -1;
        const stepC = colDiff > 0 ? 1 : -1;
        let currR = sr + stepR;
        let currC = sc + stepC;
        while (currR !== dr || currC !== dc) {
          if (board[currR][currC]) return false;
          currR += stepR;
          currC += stepC;
        }
        return true;
      }
      return false;
    }

    case 'k': { // King
      return absR <= 1 && absC <= 1;
    }

    default:
      return false;
  }
}

// ----------------------------------------------------
// Ludo Game Coordinates Mapping
// ----------------------------------------------------
// Standard 52-tile main loop track coordinates on a 15x15 board (0 to 14)
const LUDO_TRACK: [number, number][] = [
  [6, 1], [6, 2], [6, 3], [6, 4], [6, 5], // Red start & onward (0-4)
  [5, 6], [4, 6], [3, 6], [2, 6], [1, 6], [0, 6], // Going up (5-10)
  [0, 7], // Green start checkpoint (11)
  [0, 8], [1, 8], [2, 8], [3, 8], [4, 8], [5, 8], // Going down (12-17)
  [6, 9], [6, 10], [6, 11], [6, 12], [6, 13], [6, 14], // Yellow start & onward (18-23)
  [7, 14], // Yellow stretch connector (24)
  [8, 14], [8, 13], [8, 12], [8, 11], [8, 10], [8, 9], // Going left (25-30)
  [9, 8], [10, 8], [11, 8], [12, 8], [13, 8], [14, 8], // Going down (31-36)
  [14, 7], // Blue stretch connector (37)
  [14, 6], [13, 6], [12, 6], [11, 6], [10, 6], [9, 6], // Going up (38-43)
  [8, 5], [8, 4], [8, 3], [8, 2], [8, 1], [8, 0], // Going left (44-49)
  [7, 0], // Red checkpoint (50)
  [6, 0]  // Connector back to [6,1] (51)
];

// Starting track indices for players
// Red (0), Green (1), Yellow (2), Blue (3)
const LUDO_START_TRACK_INDICES = [0, 13, 26, 39];

// Safe tiles on the main board where pieces cannot be captured
const LUDO_SAFE_TRACK_INDICES = [0, 13, 26, 39, 8, 21, 34, 47];

export default function RelaxGames({ currentLang, starPoints, onRewardStars }: RelaxGamesProps) {
  const [gameTab, setGameTab] = useState<'puzzle' | 'tictactoe' | 'mine' | 'remember' | 'chess' | 'picture'>('puzzle');

  // ==========================================
  // Game 1: Word Puzzle State & Logic
  // ==========================================
  // Randomize word list by difficulty tiers: basic (<=5 letters), medium (6-7 letters), hard (>=8 letters)
  const [puzzlesList, setPuzzlesList] = useState<typeof WORD_PUZZLES>(() => {
    const basic = WORD_PUZZLES.filter(p => p.word.length <= 5).sort(() => Math.random() - 0.5);
    const medium = WORD_PUZZLES.filter(p => p.word.length >= 6 && p.word.length <= 7).sort(() => Math.random() - 0.5);
    const hard = WORD_PUZZLES.filter(p => p.word.length >= 8).sort(() => Math.random() - 0.5);
    return [...basic, ...medium, ...hard];
  });

  const [currentWordIdx, setCurrentWordIdx] = useState(0);
  const [scrambledLetters, setScrambledLetters] = useState<string[]>([]);
  const [selectedLetters, setSelectedLetters] = useState<number[]>([]);
  const [userGuess, setUserGuess] = useState('');
  const [puzzleSolved, setPuzzleSolved] = useState(false);
  const [puzzleError, setPuzzleError] = useState(false);

  const initWordPuzzle = (index: number, listToUse = puzzlesList) => {
    const p = listToUse[index];
    if (!p) return;
    setCurrentWordIdx(index);
    setScrambledLetters(p.scrambled.split(''));
    setSelectedLetters([]);
    setUserGuess('');
    setPuzzleSolved(false);
    setPuzzleError(false);
  };

  useEffect(() => {
    const basic = WORD_PUZZLES.filter(p => p.word.length <= 5).sort(() => Math.random() - 0.5);
    const medium = WORD_PUZZLES.filter(p => p.word.length >= 6 && p.word.length <= 7).sort(() => Math.random() - 0.5);
    const hard = WORD_PUZZLES.filter(p => p.word.length >= 8).sort(() => Math.random() - 0.5);
    const shuffledList = [...basic, ...medium, ...hard];
    setPuzzlesList(shuffledList);
    initWordPuzzle(0, shuffledList);
  }, []);

  const handleLetterClick = (letterIdx: number) => {
    if (puzzleSolved) return;
    if (selectedLetters.includes(letterIdx)) {
      const filtered = selectedLetters.filter(idx => idx !== letterIdx);
      setSelectedLetters(filtered);
      setUserGuess(filtered.map(idx => scrambledLetters[idx]).join(''));
    } else {
      const updated = [...selectedLetters, letterIdx];
      setSelectedLetters(updated);
      const guessResult = updated.map(idx => scrambledLetters[idx]).join('');
      setUserGuess(guessResult);

      const targetWord = puzzlesList[currentWordIdx]?.word || '';
      if (guessResult.toUpperCase() === targetWord) {
        setPuzzleSolved(true);
        setPuzzleError(false);
        onRewardStars(15, `Solved Word Puzzle: ${targetWord}`);
      } else if (guessResult.length === targetWord.length) {
        setPuzzleError(true);
      } else {
        setPuzzleError(false);
      }
    }
  };

  const handleClearGuess = () => {
    setSelectedLetters([]);
    setUserGuess('');
    setPuzzleError(false);
  };

  const handleNextPuzzle = () => {
    const nextIdx = (currentWordIdx + 1) % puzzlesList.length;
    initWordPuzzle(nextIdx);
  };

  // ==========================================
  // Game 2: Tic Tac Toe State & Logic
  // ==========================================
  const [tttBoard, setTttBoard] = useState<(string | null)[]>(Array(9).fill(null));
  const [tttIsXNext, setTttIsXNext] = useState(true);
  const [tttMode, setTttMode] = useState<'bot' | 'friend'>('bot');
  const [tttWinner, setTttWinner] = useState<string | null>(null);
  const [tttBotTyping, setTttBotTyping] = useState(false);

  const checkTTTWinner = (board: (string | null)[]) => {
    const winLines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6]
    ];
    for (let line of winLines) {
      const [a, b, c] = line;
      if (board[a] && board[a] === board[b] && board[a] === board[c]) {
        return board[a];
      }
    }
    if (board.every(cell => cell !== null)) return 'Draw';
    return null;
  };

  const handleTTTClick = (index: number) => {
    if (tttBoard[index] || tttWinner || tttBotTyping) return;

    const newBoard = [...tttBoard];
    newBoard[index] = tttIsXNext ? 'X' : 'O';
    setTttBoard(newBoard);

    const winStatus = checkTTTWinner(newBoard);
    if (winStatus) {
      setTttWinner(winStatus);
      if (winStatus === 'X') {
        onRewardStars(10, 'Won Tic-Tac-Toe Round!');
      }
    } else {
      const nextTurn = !tttIsXNext;
      setTttIsXNext(nextTurn);

      if (tttMode === 'bot' && !nextTurn) {
        setTttBotTyping(true);
        setTimeout(() => {
          makeBotMove(newBoard);
        }, 600);
      }
    }
  };

  const makeBotMove = (currentBoard: (string | null)[]) => {
    const emptyIndices: number[] = [];
    currentBoard.forEach((cell, idx) => {
      if (cell === null) emptyIndices.push(idx);
    });

    if (emptyIndices.length > 0) {
      let chosenIndex = -1;

      const testLine = (player: string) => {
        const winLines = [
          [0, 1, 2], [3, 4, 5], [6, 7, 8],
          [0, 3, 6], [1, 4, 7], [2, 5, 8],
          [0, 4, 8], [2, 4, 6]
        ];
        for (let line of winLines) {
          const cells = line.map(idx => currentBoard[idx]);
          const playerCount = cells.filter(c => c === player).length;
          const nullCount = cells.filter(c => c === null).length;
          if (playerCount === 2 && nullCount === 1) {
            const emptyOffset = line.find(idx => currentBoard[idx] === null);
            if (emptyOffset !== undefined) return emptyOffset;
          }
        }
        return -1;
      };

      chosenIndex = testLine('O');
      if (chosenIndex === -1) {
        chosenIndex = testLine('X');
      }

      if (chosenIndex === -1) {
        const randomIdx = Math.floor(Math.random() * emptyIndices.length);
        chosenIndex = emptyIndices[randomIdx];
      }

      const updatedBoard = [...currentBoard];
      updatedBoard[chosenIndex] = 'O';
      setTttBoard(updatedBoard);

      const winStatus = checkTTTWinner(updatedBoard);
      if (winStatus) {
        setTttWinner(winStatus);
      } else {
        setTttIsXNext(true);
      }
    }
    setTttBotTyping(false);
  };

  const initTTTGame = () => {
    setTttBoard(Array(9).fill(null));
    setTttIsXNext(true);
    setTttWinner(null);
    setTttBotTyping(false);
  };

  // ==========================================
  // Game 3: Memory Match Grid State & Logic
  // ==========================================
  type MemoryGridCard = {
    id: number;
    emoji: string;
    isFlipped: boolean;
    isMatched: boolean;
  };

  const [memoryGridCards, setMemoryGridCards] = useState<MemoryGridCard[]>([]);
  const [memoryGridSelected, setMemoryGridSelected] = useState<number[]>([]);
  const [memoryGridWin, setMemoryGridWin] = useState(false);
  const [memoryGridMoves, setMemoryGridMoves] = useState(0);

  const initMemoryGrid = () => {
    const emojis = ['🌸', '💮', '🍀', '🌟', '🧁', '🎈', '🥑', '🧸'];
    const items = [...emojis, ...emojis].map((emoji, idx) => ({
      id: idx,
      emoji,
      isFlipped: false,
      isMatched: false
    }));
    
    const shuffled = items.sort(() => Math.random() - 0.5);
    setMemoryGridCards(shuffled);
    setMemoryGridSelected([]);
    setMemoryGridWin(false);
    setMemoryGridMoves(0);
  };

  useEffect(() => {
    initMemoryGrid();
  }, []);

  const handleMemoryGridCardClick = (idx: number) => {
    if (memoryGridWin || memoryGridCards[idx].isFlipped || memoryGridCards[idx].isMatched || memoryGridSelected.length >= 2) {
      return;
    }

    const newCards = [...memoryGridCards];
    newCards[idx].isFlipped = true;
    setMemoryGridCards(newCards);

    const newSelected = [...memoryGridSelected, idx];
    setMemoryGridSelected(newSelected);

    if (newSelected.length === 2) {
      setMemoryGridMoves(prev => prev + 1);
      const [firstIdx, secondIdx] = newSelected;
      
      if (newCards[firstIdx].emoji === newCards[secondIdx].emoji) {
        setTimeout(() => {
          const matchedCards = [...newCards];
          matchedCards[firstIdx].isMatched = true;
          matchedCards[secondIdx].isMatched = true;
          setMemoryGridCards(matchedCards);
          setMemoryGridSelected([]);

          onRewardStars(5, 'Matched a pair in Memory Match Grid!');

          const allMatched = matchedCards.every(card => card.isMatched);
          if (allMatched) {
            setMemoryGridWin(true);
            onRewardStars(20, 'Congratulations! Solved the complete 4x4 Memory Match Grid!');
          }
        }, 450);
      } else {
        setTimeout(() => {
          const resetCards = [...newCards];
          resetCards[firstIdx].isFlipped = false;
          resetCards[secondIdx].isFlipped = false;
          setMemoryGridCards(resetCards);
          setMemoryGridSelected([]);
        }, 1000);
      }
    }
  };

  // ==========================================
  // Game 4: Remember the Pattern State & Logic
  // ==========================================
  const [rememberSequence, setRememberSequence] = useState<number[]>([]);
  const [rememberPlayerSeq, setRememberPlayerSeq] = useState<number[]>([]);
  const [rememberActiveIndex, setRememberActiveIndex] = useState<number | null>(null);
  const [rememberLevel, setRememberLevel] = useState(0);
  const [rememberPhase, setRememberPhase] = useState<'start' | 'computer' | 'player' | 'fail' | 'win'>('start');

  const startRememberGame = () => {
    const startSeq = [Math.floor(Math.random() * 9)];
    setRememberSequence(startSeq);
    setRememberPlayerSeq([]);
    setRememberLevel(1);
    setRememberPhase('computer');
    playSequence(startSeq);
  };

  const playSequence = (sequence: number[]) => {
    setRememberPhase('computer');
    let idx = 0;
    const interval = setInterval(() => {
      setRememberActiveIndex(sequence[idx]);
      setTimeout(() => {
        setRememberActiveIndex(null);
      }, 500);

      idx++;
      if (idx >= sequence.length) {
        clearInterval(interval);
        setTimeout(() => {
          setRememberPhase('player');
          setRememberPlayerSeq([]);
        }, 700);
      }
    }, 900);
  };

  const handleRememberClick = (gridIndex: number) => {
    if (rememberPhase !== 'player') return;

    setRememberActiveIndex(gridIndex);
    setTimeout(() => {
      setRememberActiveIndex(null);
    }, 200);

    const nextPlayerSeq = [...rememberPlayerSeq, gridIndex];
    setRememberPlayerSeq(nextPlayerSeq);

    const currentStepIdx = nextPlayerSeq.length - 1;
    if (gridIndex !== rememberSequence[currentStepIdx]) {
      setRememberPhase('fail');
      return;
    }

    if (nextPlayerSeq.length === rememberSequence.length) {
      onRewardStars(5 + rememberLevel * 2, `Passed Remember Level ${rememberLevel}`);
      if (rememberLevel >= 6) {
        setRememberPhase('win');
      } else {
        const updatedLevel = rememberLevel + 1;
        setRememberLevel(updatedLevel);
        const nextSeq = [...rememberSequence, Math.floor(Math.random() * 9)];
        setRememberSequence(nextSeq);
        setTimeout(() => {
          playSequence(nextSeq);
        }, 1000);
      }
    }
  };

  // ==========================================
  // Game 5: Noble Chess (With Proper Validations!)
  // ==========================================
  const [chessBoard, setChessBoard] = useState<ChessBoardState>(INITIAL_CHESS_BOARD);
  const [selectedChessCell, setSelectedChessCell] = useState<[number, number] | null>(null);
  const [highlightSquares, setHighlightSquares] = useState<[number, number][]>([]);
  const [chessTurn, setChessTurn] = useState<'w' | 'b'>('w');
  const [chessMode, setChessMode] = useState<'bot' | 'friend'>('bot');
  const [chessMoveLog, setChessMoveLog] = useState<string[]>([]);
  const [chessWinner, setChessWinner] = useState<string | null>(null);
  const [showChessRulesHelp, setShowChessRulesHelp] = useState(false);

  // Re-calculate move highlights whenever selection or board changes
  useEffect(() => {
    if (selectedChessCell) {
      const [sr, sc] = selectedChessCell;
      const selectedPiece = chessBoard[sr][sc];
      if (selectedPiece && selectedPiece.color === chessTurn) {
        const validMoves: [number, number][] = [];
        for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
            if (isValidChessMove(sr, sc, r, c, selectedPiece, chessBoard)) {
              validMoves.push([r, c]);
            }
          }
        }
        setHighlightSquares(validMoves);
        return;
      }
    }
    setHighlightSquares([]);
  }, [selectedChessCell, chessBoard, chessTurn]);

  const initChessGame = () => {
    setChessBoard(INITIAL_CHESS_BOARD.map(row => [...row]));
    setSelectedChessCell(null);
    setHighlightSquares([]);
    setChessTurn('w');
    setChessMoveLog([]);
    setChessWinner(null);
  };

  // Chess Smart Bot AI (Only plays 100% legal moves!)
  const makeChessBotMove = () => {
    if (chessWinner) return;

    // 1. Find all Black pieces on the board
    const blackPieces: { r: number; c: number; piece: ChessPiece }[] = [];
    chessBoard.forEach((row, r) => {
      row.forEach((piece, c) => {
        if (piece && piece.color === 'b') {
          blackPieces.push({ r, c, piece });
        }
      });
    });

    if (blackPieces.length === 0) return;

    // 2. Identify all valid legal moves for Black
    const legalMoves: { sr: number; sc: number; dr: number; dc: number; score: number; identifier: string }[] = [];
    blackPieces.forEach(bp => {
      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          if (isValidChessMove(bp.r, bp.c, r, c, bp.piece, chessBoard)) {
            // Priority weight scoring
            let score = 1;
            const target = chessBoard[r][c];
            if (target) {
              if (target.type === 'k') score = 1000;
              else if (target.type === 'q') score = 90;
              else if (target.type === 'r') score = 50;
              else if (target.type === 'b') score = 30;
              else if (target.type === 'n') score = 30;
              else if (target.type === 'p') score = 10;
            }
            // Pawn safety scoring
            if (bp.piece.type === 'p' && r === 7) {
              score += 15; // promotion incentive
            }
            legalMoves.push({
              sr: bp.r,
              sc: bp.c,
              dr: r,
              dc: c,
              score,
              identifier: `${bp.piece.type.toUpperCase()}${['a','b','c','d','e','f','g','h'][c]}${8 - r}`
            });
          }
        }
      }
    });

    // 3. Handle stalemate / checkmate for bot
    if (legalMoves.length === 0) {
      setChessWinner('w');
      onRewardStars(30, 'Congratulations! Won the Chess Sandbox Tournament!');
      return;
    }

    // 4. Select the highest weighted move (or choose a random smart one)
    legalMoves.sort((a, b) => b.score - a.score);
    const bestScore = legalMoves[0].score;
    const candidates = legalMoves.filter(m => m.score === bestScore);
    const chosen = candidates[Math.floor(Math.random() * candidates.length)];

    // Execute Bot Move
    const updated = chessBoard.map(row => [...row]);
    const movingPiece = updated[chosen.sr][chosen.sc];
    
    // Pawn promotion to Queen if it reaches the back rank
    if (movingPiece && movingPiece.type === 'p' && chosen.dr === 7) {
      updated[chosen.dr][chosen.dc] = { type: 'q', color: 'b' };
    } else {
      updated[chosen.dr][chosen.dc] = movingPiece;
    }
    updated[chosen.sr][chosen.sc] = null;

    setChessBoard(updated);
    setChessMoveLog(prev => [...prev, `🤖 ${chosen.identifier}`]);
    setChessTurn('w');

    // Confirm white king still exists
    const whiteKingExists = updated.some(row => row.some(piece => piece?.type === 'k' && piece.color === 'w'));
    if (!whiteKingExists) {
      setChessWinner('b');
    }
  };

  useEffect(() => {
    if (chessTurn === 'b' && chessMode === 'bot' && !chessWinner && gameTab === 'chess') {
      const timer = setTimeout(() => {
        makeChessBotMove();
      }, 700);
      return () => clearTimeout(timer);
    }
  }, [chessTurn, chessMode, chessBoard, chessWinner, gameTab]);

  const handleChessCellClick = (r: number, c: number) => {
    if (chessWinner) return;
    if (chessMode === 'bot' && chessTurn === 'b') return; // Bot's turn

    const clickedPiece = chessBoard[r][c];

    // If a friendly piece is clicked, select/change select
    if (clickedPiece && clickedPiece.color === chessTurn) {
      setSelectedChessCell([r, c]);
      return;
    }

    // If a destination cell is clicked and we have a selected piece
    if (selectedChessCell) {
      const [sr, sc] = selectedChessCell;
      const selectedPiece = chessBoard[sr][sc];

      if (selectedPiece && isValidChessMove(sr, sc, r, c, selectedPiece, chessBoard)) {
        const updated = chessBoard.map(row => [...row]);
        
        // Pawn promotion to Queen on back rank
        if (selectedPiece.type === 'p' && r === 0) {
          updated[r][c] = { type: 'q', color: 'w' };
        } else {
          updated[r][c] = selectedPiece;
        }
        updated[sr][sc] = null;

        const pieceSymbol = selectedPiece.type.toUpperCase();
        const fileLetter = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'][c];
        const moveStr = `${pieceSymbol}${fileLetter}${8 - r}`;

        setChessBoard(updated);
        setChessMoveLog(prev => [...prev, moveStr]);
        setSelectedChessCell(null);

        // Turn transition
        const nextColor = chessTurn === 'w' ? 'b' : 'w';
        setChessTurn(nextColor);

        if (chessMoveLog.length === 0) {
          onRewardStars(10, 'Started Chess Brain Training Sandbox Match!');
        }

        // Win check
        const blackKingExists = updated.some(row => row.some(piece => piece?.type === 'k' && piece.color === 'b'));
        if (!blackKingExists) {
          setChessWinner('w');
          onRewardStars(30, 'Congratulations! Won the Chess Sandbox Tournament!');
        }
      } else {
        // Not a legal target, reset selection
        setSelectedChessCell(null);
      }
    }
  };

  // ==========================================
  // Game 6: Pictures Puzzle State & Logic (NEW!)
  // ==========================================
  const [picPuzzleImgIdx, setPicPuzzleImgIdx] = useState<number>(0);
  const [picPuzzleTiles, setPicPuzzleTiles] = useState<number[]>([0, 1, 2, 3, 4, 5, 6, 7, 8]);
  const [picPuzzleSelectedIdx, setPicPuzzleSelectedIdx] = useState<number | null>(null);
  const [picPuzzleIsPreview, setPicPuzzleIsPreview] = useState<boolean>(true);
  const [picPuzzleCountdown, setPicPuzzleCountdown] = useState<number>(5);
  const [picPuzzleSolved, setPicPuzzleSolved] = useState<boolean>(false);
  const [picPuzzleMoves, setPicPuzzleMoves] = useState<number>(0);
  const [picPuzzleShowRef, setPicPuzzleShowRef] = useState<boolean>(false);

  const initPicPuzzle = (forcedIndex?: number) => {
    let nextIdx = picPuzzleImgIdx;
    if (forcedIndex !== undefined) {
      nextIdx = forcedIndex;
    } else {
      nextIdx = (picPuzzleImgIdx + 1) % PUZZLE_IMAGES.length;
    }
    setPicPuzzleImgIdx(nextIdx);
    setPicPuzzleTiles([0, 1, 2, 3, 4, 5, 6, 7, 8]);
    setPicPuzzleSelectedIdx(null);
    setPicPuzzleIsPreview(true);
    setPicPuzzleCountdown(5);
    setPicPuzzleSolved(false);
    setPicPuzzleMoves(0);
    setPicPuzzleShowRef(false);
  };

  const scramblePicPuzzleBoard = () => {
    let arr = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    const isSolved = arr.every((val, idx) => val === idx);
    if (isSolved) {
      [arr[0], arr[1]] = [arr[1], arr[0]];
    }
    setPicPuzzleTiles(arr);
    setPicPuzzleIsPreview(false);
    setPicPuzzleSelectedIdx(null);
    setPicPuzzleSolved(false);
    setPicPuzzleMoves(0);
  };

  useEffect(() => {
    initPicPuzzle(0);
  }, []);

  useEffect(() => {
    let countdownTimer: any;
    if (picPuzzleIsPreview && picPuzzleCountdown > 0 && !picPuzzleSolved && gameTab === 'picture') {
      countdownTimer = setTimeout(() => {
        setPicPuzzleCountdown(prev => {
          if (prev <= 1) {
            scramblePicPuzzleBoard();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearTimeout(countdownTimer);
  }, [picPuzzleIsPreview, picPuzzleCountdown, picPuzzleSolved, gameTab]);

  const handlePicPuzzleTileClick = (index: number) => {
    if (picPuzzleIsPreview || picPuzzleSolved) return;
    
    if (picPuzzleSelectedIdx === null) {
      setPicPuzzleSelectedIdx(index);
    } else {
      if (picPuzzleSelectedIdx === index) {
        setPicPuzzleSelectedIdx(null);
        return;
      }
      
      const newTiles = [...picPuzzleTiles];
      const temp = newTiles[picPuzzleSelectedIdx];
      newTiles[picPuzzleSelectedIdx] = newTiles[index];
      newTiles[index] = temp;
      
      const newMoves = picPuzzleMoves + 1;
      setPicPuzzleTiles(newTiles);
      setPicPuzzleSelectedIdx(null);
      setPicPuzzleMoves(newMoves);
      
      const isSolved = newTiles.every((val, idx) => val === idx);
      if (isSolved) {
        setPicPuzzleSolved(true);
        onRewardStars(25, `Solved picture puzzle in ${newMoves} moves!`);
      }
    }
  };

  // Ludo clean-up complete

  return (
    <div id="relax-games-card" className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-5 md:p-6 space-y-6">
      
      {/* Upper Title Section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-indigo-50 pb-4">
        <div>
          <h2 className="text-md md:text-lg font-extrabold text-indigo-950 flex items-center gap-2">
            <Smile className="w-5 h-5 text-rose-500 fill-rose-100" />
            {currentLang === 'en' ? "Relax Corner: Positive Games Hub" : "মন ভালো করার কোণ: মজার খেলাধুলো"}
          </h2>
          <p className="text-xs text-slate-500 font-sans">
            {currentLang === 'en' 
              ? "Sharpen your logical mind and relieve stress with these direct mind exercises. Earn star keys with each win!"
              : "ইন্টারনেট ছাড়াই খেলো নিজের আত্মবিশ্বাস আর মেধা বাড়াতে। প্রতিটি জয়ে জুড়বে চমৎকার সব গিফ্ট স্টার!"
            }
          </p>
        </div>
      </div>

      {/* Sub tabs of games */}
      <div className="flex flex-wrap gap-2 justify-center bg-slate-50 p-1.5 rounded-2xl border border-slate-100 select-none">
        <button
          onClick={() => setGameTab('puzzle')}
          className={`py-2 px-3 md:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gameTab === 'puzzle' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-650 hover:bg-slate-150'
          }`}
        >
          🔡 {currentLang === 'en' ? 'Word Solver' : 'শব্দ মেলানো'}
        </button>
        <button
          onClick={() => setGameTab('tictactoe')}
          className={`py-2 px-3 md:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gameTab === 'tictactoe' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-650 hover:bg-slate-150'
          }`}
        >
          ❌ {currentLang === 'en' ? 'Tic-Tac-Toe' : 'টিক-ট্যাক-টো'}
        </button>
        <button
          onClick={() => setGameTab('mine')}
          className={`py-2 px-3 md:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gameTab === 'mine' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-650 hover:bg-slate-150'
          }`}
        >
          🧩 {currentLang === 'en' ? 'Memory Grid' : 'মেমরি ম্যাচ গ্রিড'}
        </button>
        <button
          onClick={() => setGameTab('remember')}
          className={`py-2 px-3 md:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gameTab === 'remember' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-650 hover:bg-slate-150'
          }`}
        >
          💡 {currentLang === 'en' ? 'Remember Pattern' : 'মনে রাখার ধাঁধা'}
        </button>
        <button
          onClick={() => setGameTab('chess')}
          className={`py-2 px-3 md:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gameTab === 'chess' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-650 hover:bg-slate-150'
          }`}
        >
          👑 {currentLang === 'en' ? 'Noble Chess' : 'দাবার চাল'}
        </button>
        <button
          onClick={() => { setGameTab('picture'); initPicPuzzle(0); }}
          className={`py-2 px-3 md:px-4 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            gameTab === 'picture' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-650 hover:bg-slate-150'
          }`}
        >
          🖼️ {currentLang === 'en' ? 'Picture Puzzle' : 'ছবি মেলানো ধাঁধা'}
        </button>
      </div>

      {/* ==========================================
          GAME MODULE 1: WORD SOLVER
          ========================================== */}
      {gameTab === 'puzzle' && (
        <div id="word-solver-game" className="space-y-4 max-w-lg mx-auto animate-fadeIn col">
          <div className="bg-amber-50 p-4 rounded-xl border border-amber-200/50 space-y-2">
            <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
              {currentLang === 'en' ? 'Bilingual Clue' : 'বাংলায় সংকেত:'}
            </span>
            <p className="text-[13px] font-bold text-amber-900 leading-relaxed italic">
              "{puzzlesList[currentWordIdx]?.hints[currentLang]}"
            </p>
          </div>

          <div className="text-center py-4 space-y-3">
            <div className="text-[10px] text-slate-500 uppercase font-bold tracking-wider">
              {currentLang === 'en' ? 'Your Unscrambled Attempt:' : 'আপনার সাজানো উত্তর:'}
            </div>
            
            <div className="min-h-[48px] px-4 py-2 bg-slate-50 border border-slate-205 rounded-2xl flex items-center justify-center gap-1.5 font-mono text-lg font-black tracking-widest text-indigo-950 block">
              {userGuess ? userGuess : <span className="text-xs text-slate-400 italic font-sans">{currentLang === 'en' ? 'Tap letters below to order...' : 'নিচের অক্ষরগুলোতে টাচ করে শব্দ সাজাও'}</span>}
              {puzzleSolved && <span className="text-emerald-600 font-sans text-xs ml-2">🎉 Solved! +15 Stars</span>}
            </div>

            {puzzleError && !puzzleSolved && (
              <p className="text-[10px] text-rose-600 font-bold font-sans animate-shake">
                ⚠️ {currentLang === 'en' ? 'Not matched yet. Check Clues and try again!' : 'শব্দটি মেলেনি। সংকেত পড়ে সাজানো ঠিক করো'}
              </p>
            )}
          </div>

          <div className="flex flex-wrap gap-2.5 justify-center">
            {scrambledLetters.map((char, index) => {
              const isSelected = selectedLetters.includes(index);
              return (
                <button
                  key={index}
                  id={`btn-puzzle-letter-${index}`}
                  disabled={puzzleSolved}
                  onClick={() => handleLetterClick(index)}
                  className={`w-11 h-11 border-2 font-black rounded-xl text-sm flex items-center justify-center transition-all cursor-pointer transform active:scale-90 ${
                    isSelected
                      ? 'bg-indigo-50 border-indigo-300 text-indigo-400 cursor-not-allowed'
                      : 'bg-white border-slate-350 text-slate-800 shadow-3xs hover:-translate-y-0.5 hover:border-indigo-500'
                  }`}
                >
                  {char}
                </button>
              );
            })}
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <button
              onClick={handleClearGuess}
              disabled={puzzleSolved}
              className="py-1 px-3 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg transition-colors cursor-pointer disabled:opacity-40"
            >
              🔄 {currentLang === 'en' ? 'Clear' : 'মুছে ফেলো'}
            </button>
            <button
              onClick={handleNextPuzzle}
              className="py-1.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-lg shadow-2xs transition-colors cursor-pointer"
            >
              {currentLang === 'en' ? 'Next Clue Word ➡️' : 'পরবর্তী শব্দ ➡️'}
            </button>
          </div>
        </div>
      )}

      {/* ==========================================
          GAME MODULE 2: TIC TAC TOE
          ========================================== */}
      {gameTab === 'tictactoe' && (
        <div id="tictactoe-game" className="space-y-4 max-w-sm mx-auto animate-fadeIn text-center">
          
          <div className="flex gap-1 bg-slate-100 p-1 rounded-xl border max-w-[240px] mx-auto select-none justify-center">
            <button
              onClick={() => { setTttMode('bot'); initTTTGame(); }}
              className={`flex items-center gap-1.5 py-1 px-2.5 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                tttMode === 'bot' ? 'bg-indigo-600 text-white' : 'text-slate-650 hover:bg-slate-200'
              }`}
            >
              <Bot className="w-3.5 h-3.5" />
              {currentLang === 'en' ? 'Play Bot' : 'বট রোবট'}
            </button>
            <button
              onClick={() => { setTttMode('friend'); initTTTGame(); }}
              className={`flex items-center gap-1.5 py-1 px-2.5 rounded-lg text-[10px] font-black transition-all cursor-pointer ${
                tttMode === 'friend' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-650 hover:bg-slate-200'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              {currentLang === 'en' ? 'Play Friend' : 'বান্ধবী'}
            </button>
          </div>

          <p className="text-[11px] text-slate-500 font-sans font-semibold">
            {tttMode === 'bot' 
              ? (currentLang === 'en' ? "Your turn! Tap a grid. You are Flower 🌸, Bot is Daisy 💮." : "তোমার চাল! তুমি লাল ফুল 🌸, রোবট সাদা ফুল 💮।")
              : (currentLang === 'en' ? "Passing tablet between friends! X: 🌸, Player O: 💮" : "বন্ধুরা মিলে চাল দাও! প্রথমজন: 🌸, দ্বিতীয় জন: 💮")
            }
          </p>

          <div className="grid grid-cols-3 gap-2.5 max-w-[200px] mx-auto py-2">
            {tttBoard.map((cell, idx) => (
              <button
                key={idx}
                id={`btn-ttt-cell-${idx}`}
                onClick={() => handleTTTClick(idx)}
                style={{ minHeight: '60px', minWidth: '60px' }}
                className="bg-slate-50 hover:bg-indigo-50 border-2 border-slate-200 rounded-xl flex items-center justify-center text-xl sm:text-2xl transition-all cursor-pointer transform active:scale-95 leading-none select-none font-bold shadow-4xs"
              >
                {cell === 'X' ? '🌸' : cell === 'O' ? '💮' : ''}
              </button>
            ))}
          </div>

          <div className="min-h-[35px] flex items-center justify-center">
            {tttBotTyping && !tttWinner && (
              <span className="text-xs text-indigo-600 font-mono font-bold animate-pulse">🤖 Bot writing move...</span>
            )}

            {tttWinner && (
              <div className="space-y-2 animate-fadeIn">
                <p className="text-xs font-extrabold text-indigo-950">
                  {tttWinner === 'Draw'
                    ? (currentLang === 'en' ? "🤝 Peace! Match is a Draw!" : "🤝 সুন্দর খেলায় ড্র হয়েছে!")
                    : tttWinner === 'X'
                    ? (currentLang === 'en' ? "🎉 Excellent! You (🌸) Won! +10 Stars" : "🎉 চমৎকার! তুমি (🌸) জিতেছ! +১০ স্টার")
                    : (currentLang === 'en' ? "💮 Opponent (💮) has matched 3 blocks!" : "💮 বিপক্ষ দল (💮) জিতেছে! চেষ্টা জারি রাখো।")
                  }
                </p>
                <button
                  onClick={initTTTGame}
                  className="py-1 px-3 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
                >
                  {currentLang === 'en' ? 'Rematch Round' : 'আবার খেলো'}
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ==========================================
          GAME MODULE 3: MEMORY MATCH GRID
          ========================================== */}
      {gameTab === 'mine' && (
        <div id="memory-match-game" className="space-y-4 max-w-sm mx-auto animate-fadeIn text-center">
          
          <div className="flex justify-between items-center bg-emerald-50 p-3 rounded-xl border border-emerald-100 select-none">
            <div className="text-[11px] text-emerald-900 font-extrabold">
              {currentLang === 'en' ? 'Total Turns Used:' : 'ব্যবহৃত চাল:'} <span className="text-sm font-black text-emerald-950 font-mono">{memoryGridMoves}</span>
            </div>
            <button
              onClick={initMemoryGrid}
              className="py-1 px-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
            >
              Reset Memory Grid
            </button>
          </div>

          <p className="text-[11px] text-slate-500 leading-relaxed font-sans font-bold">
            {currentLang === 'en' 
              ? "Tap the 16 cards to discover matching pairs of visual emojis! Match all to win."
              : "১৬টি কার্ডে টাচ করে লুকিয়ে থাকা একই রকমের ছবির জোড়াগুলোকে খুঁজে মেলাও!"
            }
          </p>

          <div className="grid grid-cols-4 gap-2 max-w-[250px] mx-auto">
            {memoryGridCards.map((card, idx) => {
              const isRevealed = card.isFlipped || card.isMatched;
              return (
                <button
                  key={card.id}
                  id={`btn-memory-grid-card-${idx}`}
                  onClick={() => handleMemoryGridCardClick(idx)}
                  className={`w-14 h-14 rounded-xl border-2 font-black text-xl flex items-center justify-center transition-all cursor-pointer transform active:scale-95 ${
                    isRevealed
                      ? card.isMatched
                        ? 'bg-emerald-100 border-emerald-400 text-emerald-600 scale-102 font-bold cursor-default'
                        : 'bg-white border-indigo-400 font-bold'
                      : 'bg-gradient-to-tr from-indigo-700 to-indigo-650 border-indigo-800 text-indigo-100 shadow-4xs cursor-pointer hover:brightness-105'
                  }`}
                >
                  {isRevealed ? card.emoji : '❓'}
                </button>
              );
            })}
          </div>

          {memoryGridWin && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1.5 animate-fadeIn font-bold">
              <p className="text-xs font-black text-emerald-700">
                🎉 {currentLang === 'en' ? 'Superb! You solved the memory match in record moves!' : 'দুর্দান্ত! সমস্ত কার্ড জোড়ায় জোড়ায় মিলিয়ে তুমি জিতে নিয়েছ ২০ উপহার স্টার!'} (+20 ⭐)
              </p>
              <button
                onClick={initMemoryGrid}
                className="py-1.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
              >
                Play New Grid Map
              </button>
            </div>
          )}
        </div>
      )}

      {/* ==========================================
          GAME MODULE 4: REMEMBER THE PATTERN
          ========================================== */}
      {gameTab === 'remember' && (
        <div id="remember-pattern-game" className="space-y-4 max-w-sm mx-auto animate-fadeIn text-center font-bold">
          
          <div className="flex justify-between items-center bg-slate-50 p-2 rounded-xl border">
            <span className="text-[11px] font-extrabold text-slate-700 animate-pulse">
              {currentLang === 'en' ? `Level Passed: ${rememberLevel - 1}` : `উন্নীত ধাপ: ${rememberLevel - 1}`}
            </span>
            <span className="text-[10px] font-bold uppercase tracking-wider font-mono text-indigo-700">
              {rememberPhase === 'computer' && (currentLang === 'en' ? 'Watch lights' : 'ধৈর্য ধরে আলো দেখো')}
              {rememberPhase === 'player' && (currentLang === 'en' ? 'Your sequence turn' : 'নিজের আঙ্গুলের চাল দাও')}
              {rememberPhase === 'start' && (currentLang === 'en' ? 'Ready!' : 'প্রস্তুত হও')}
              {rememberPhase === 'fail' && (currentLang === 'en' ? 'Failed!' : 'ভুল হয়েছে')}
              {rememberPhase === 'win' && (currentLang === 'en' ? 'Champion!' : 'বিজয়ী!')}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-3 max-w-[240px] mx-auto py-2 select-none">
            {Array(9).fill(null).map((_, idx) => {
              const isGlowing = rememberActiveIndex === idx;
              return (
                <button
                  key={idx}
                  id={`btn-remember-pad-${idx}`}
                  disabled={rememberPhase !== 'player'}
                  onClick={() => handleRememberClick(idx)}
                  style={{ minHeight: '68px' }}
                  className={`rounded-xl border transition-all duration-150 transform active:scale-90 flex items-center justify-center cursor-pointer ${
                    isGlowing
                      ? 'bg-amber-400 border-amber-500 scale-105 shadow-md shadow-amber-302'
                      : 'bg-indigo-900 border-indigo-950 hover:bg-indigo-800'
                  }`}
                >
                  <span className="text-white text-md font-mono select-none">
                    {idx + 1}
                  </span>
                </button>
              );
            })}
          </div>

          {rememberPhase === 'start' && (
            <button
              onClick={startRememberGame}
              className="py-2 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
            >
              {currentLang === 'en' ? 'Play: Begin Memory Sequence' : 'প্যাটার্ন খেলা শুরু করো'}
            </button>
          )}

          {rememberPhase === 'fail' && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl space-y-1.5 animate-fadeIn">
              <p className="text-xs text-rose-800 font-bold">
                {currentLang === 'en' ? 'Oops, pattern sequence mixed! Keep going and try again.' : 'আহা! প্যাটার্ন মেলানো ভুল হয়েছে। মন শান্ত করে আবার চেষ্টা করো।'}
              </p>
              <button
                onClick={startRememberGame}
                className="py-1 px-3 bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
              >
                Re-attempt
              </button>
            </div>
          )}

          {rememberPhase === 'win' && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl space-y-1.5 animate-fadeIn">
              <p className="text-xs font-black text-emerald-800">
                🏆 {currentLang === 'en' ? 'Perfect Focus Champion! Mastered memory tier complete!' : 'বিস্ময়কর! তুমি সম্পূর্ণ মেমোরি লেভেল সফলভাবে অতিক্রম করেছ!'}
              </p>
            </div>
          )}

        </div>
      )}

      {/* ==========================================
          GAME MODULE 5: BILINGUAL INTEGRATED CHESS
          ========================================== */}
      {gameTab === 'chess' && (
        <div id="noble-chess-game" className="space-y-4 animate-fadeIn">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-amber-50 p-3 rounded-xl border border-amber-200 select-none font-sans">
            <div>
              <span className="text-[10px] bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider block w-fit mb-1 font-sans font-extrabold">
                {currentLang === 'en' ? 'Select Chess Mode' : 'দাবার মোড নির্ধারণ:'}
              </span>
              <div className="flex gap-1.5 bg-amber-100 p-1 rounded-xl font-bold text-xs">
                <button
                  onClick={() => { setChessMode('bot'); initChessGame(); }}
                  className={`py-1 px-3 text-[10px] font-black rounded-lg transition-all cursor-pointer ${
                    chessMode === 'bot' 
                      ? 'bg-amber-850 text-white shadow-sm' 
                      : 'text-amber-950 hover:bg-amber-200'
                  }`}
                >
                  🤖 {currentLang === 'en' ? 'VS Computer' : 'বটের বিরুদ্ধে খেলুন'}
                </button>
                <button
                  onClick={() => { setChessMode('friend'); initChessGame(); }}
                  className={`py-1 px-3 text-[10px] font-black rounded-lg transition-all cursor-pointer ${
                    chessMode === 'friend' 
                      ? 'bg-amber-850 text-white shadow-sm' 
                      : 'text-amber-950 hover:bg-amber-200'
                  }`}
                >
                  👧 {currentLang === 'en' ? 'VS BFF Offline' : 'বান্ধবীর সাথে খেলুন'}
                </button>
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowChessRulesHelp(!showChessRulesHelp)}
                className={`py-1 px-3 text-[10px] font-black rounded-lg transition-all border cursor-pointer ${
                  showChessRulesHelp 
                    ? 'bg-amber-100 text-amber-950 border-amber-305' 
                    : 'bg-amber-700 text-white border-transparent hover:bg-amber-850'
                }`}
              >
                📜 {currentLang === 'en' ? 'Game Rules' : 'খেলার নিয়ম'}
              </button>
              
              <button
                onClick={() => initChessGame()}
                className="py-1 px-3 bg-amber-950 hover:bg-amber-955 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
              >
                🔄 {currentLang === 'en' ? 'Reset' : 'রিসেট'}
              </button>
            </div>
          </div>

          {showChessRulesHelp && (
            <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl animate-fadeIn space-y-2 text-slate-850">
              <h3 className="text-xs font-bold text-amber-900 border-b border-amber-200 pb-1 flex items-center gap-1">
                <Lightbulb className="w-4 h-4 text-amber-600" />
                {currentLang === 'en' ? 'Bilingual Chess Piece Movement Guide:' : 'কোন গুটি কিভাবে চলে দাবার নিয়ম:'}
              </h3>
              <ul className="text-[11px] space-y-1 font-sans leading-relaxed text-slate-700">
                <li>
                  👑 <strong>{currentLang === 'en' ? 'King (♔/♚):' : 'রাজা (♔/♚):'}</strong> {currentLang === 'en' ? 'Moves any direction exactly 1 step.' : 'যেকোনো দিকে মাত্র ১ ঘর যেতে পারে।'}
                </li>
                <li>
                  ♕ <strong>{currentLang === 'en' ? 'Queen (♕/♛):' : 'মন্ত্রী (♕/♛):'}</strong> {currentLang === 'en' ? 'Moves any squares horizontally, vertically, or diagonally. Ultimate powers!' : 'সোজা, পাশে বা কোনাকুনি যতখুশি ঘর যেতে পারে স্বাধীনভাবে।'}
                </li>
                <li>
                  ♖ <strong>{currentLang === 'en' ? 'Rook (♖/♜):' : 'নৌকা (♖/♜):'}</strong> {currentLang === 'en' ? 'Moves straight horizontal or vertical steps. Paths must be un-blocked.' : 'সোজা ডানে-বামে বা ওপরে-নিচে যতখুশি ঘর যেতে পারে (গুটি না টপকে)।'}
                </li>
                <li>
                  ♗ <strong>{currentLang === 'en' ? 'Bishop (♗/♝):' : 'গজ/হাতি (♗/♝):'}</strong> {currentLang === 'en' ? 'Moves diagonally only, keeping to light/dark fields.' : 'শুধুমাত্র কোনাকুনি কোণ বাড়িয়ে যতখুশি ঘর ধাবিত হতে পারে।'}
                </li>
                <li>
                  ♘ <strong>{currentLang === 'en' ? 'Knight (♘/♞):' : 'ঘোড়া (♘/♞):'}</strong> {currentLang === 'en' ? 'L-shaped jumps (2 ahead, 1 side). The only piece that can jump over other blocks!' : 'আড়াই চাল লাফিয়ে চলে (২ ঘর সোজা, ১ ঘর পাশে)। একমাত্র গুটি যা অন্য গুটি টপকাতে পারে!'}
                </li>
                <li>
                  ♙ <strong>{currentLang === 'en' ? 'Pawn (♙/♟):' : 'সৈন্য / বোড়ে (♙/♟):'}</strong> {currentLang === 'en' ? 'Moves forward 1 step (or 2 steps on start). Captures diagonally. Promotes to Queen on reaching back-rank!' : 'সামনে ১ ঘর চলে (প্রথম চালে ২ ঘরও চলা যায়)। কাটাকুটি করে কোনাকুনি ডান/বামে ১ ঘর। শেষে পৌঁছালে মন্ত্রী হয়!'}
                </li>
              </ul>
            </div>
          )}

          <p className="text-[11px] text-slate-500 font-sans font-semibold text-center select-none leading-relaxed">
            {chessMode === 'bot'
              ? (currentLang === 'en' ? "Play single with CPU! White King ♔ is yours (⚪). Tap piece, then tap highlighted square to move legally." : "বট রোবটের বিরুদ্ধে একক খেলা! সাদা সৈন্য (⚪) আপনার। গুটি স্পর্শ করুন এবং জ্বলজ্বলে গোল চিহ্নিত ঘরে চাল দিন।")
              : (currentLang === 'en' ? "Open free sandbox match rules. White (⚪) vs Black (⚫)! Capture the King to win." : "বান্ধবীদের দুই জনের যুদ্ধ খেলা। সাদা (⚪) বনাম কালো গুটি (⚫) চাল দিন।")
            }
          </p>

          <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
            {/* Chess Board with wood visual colors and legal move circles */}
            <div className="border-4 border-amber-950 rounded-2xl overflow-hidden p-1 bg-amber-950 shrink-0 shadow-lg select-none">
              <div className="grid grid-cols-8 grid-rows-8 gap-0 w-[290px] h-[290px] sm:w-[330px] sm:h-[330px]">
                {chessBoard.map((row, r) =>
                  row.map((piece, c) => {
                    const isDarkSquare = (r + c) % 2 === 1;
                    const isSelected = selectedChessCell && selectedChessCell[0] === r && selectedChessCell[1] === c;
                    const isHighlighted = highlightSquares.some(sq => sq[0] === r && sq[1] === c);
                    
                    let bgClass = isDarkSquare ? 'bg-[#b58863]' : 'bg-[#f0d9b5]';
                    if (isSelected) bgClass = 'bg-rose-200 border-2 border-rose-500 scale-102 z-1 shadow-md';

                    return (
                      <button
                        key={`${r}-${c}`}
                        id={`btn-chess-square-${r}-${c}`}
                        onClick={() => handleChessCellClick(r, c)}
                        className={`w-full h-full flex items-center justify-center text-3xl sm:text-4xl transition-all cursor-pointer font-extrabold ${bgClass} select-none relative`}
                        style={{ outline: 'none' }}
                      >
                        {/* Legal Target Move Pointer */}
                        {isHighlighted && (
                          <div className="absolute inset-0 flex items-center justify-center bg-emerald-500/25">
                            <div className="w-3 h-3 bg-emerald-600 rounded-full animate-ping" />
                          </div>
                        )}

                        {piece ? (
                          <span 
                            className={`select-none transform active:scale-110 transition-transform ${
                              piece.color === 'w' 
                                ? 'text-white drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]' 
                                : 'text-slate-950 drop-shadow-[0_2px_2px_rgba(255,255,255,0.8)]'
                            }`}
                          >
                            {CHESS_PIECE_REPRESENTATION[`${piece.color}-${piece.type}`]}
                          </span>
                        ) : (
                          ''
                        )}
                      </button>
                    );
                  })
                )}
              </div>
            </div>

            {/* Turn Logger and Indicator panel */}
            <div className="w-full md:w-56 bg-slate-50 border p-3 rounded-xl max-h-[310px] flex flex-col justify-between">
              <div className="space-y-1.5 overflow-y-auto max-h-[220px]">
                <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1 border-b pb-1 select-none">
                  📰 {currentLang === 'en' ? 'Move Logs:' : 'দাবার চাল সমূহের খতিয়ান:'}
                </h4>
                {chessMoveLog.length === 0 ? (
                  <p className="text-[10px] text-slate-500 italic">No turns played yet.</p>
                ) : (
                  <div className="grid grid-cols-2 gap-1 uppercase font-mono text-[9px] text-indigo-950 font-bold">
                    {chessMoveLog.map((m, idx) => (
                      <div key={idx} className="bg-white px-2 py-0.5 rounded border border-slate-150">
                        {idx + 1}. {m}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-4 pt-2 border-t text-center select-none font-bold">
                {chessWinner ? (
                  <div className="bg-emerald-100 text-emerald-950 p-2 rounded-lg text-[10px] font-black animate-bounce">
                    🎉 {chessWinner === 'w' && (currentLang === 'en' ? 'White King wins! +30 Stars' : 'সাদা সৈন্যদল জয়ী! +৩০ স্টার')}
                    {chessWinner === 'b' && (currentLang === 'en' ? 'Black King has triumphed!' : 'কালো সৈন্যদল সেরা হয়েছে!')}
                  </div>
                ) : (
                  <div className="text-[10px] font-extrabold text-[#111827] font-mono">
                    {currentLang === 'en' ? 'Active Hand:' : 'যার চাল:'}{' '}
                    <span className="bg-indigo-150 px-2.5 py-1 rounded text-xs select-none">
                      {chessTurn === 'w' ? '⚪' : '⚫'} {chessTurn === 'w' ? 'White Only' : 'Black CPU'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==========================================
          GAME MODULE 6: PICTURES PUZZLE GAME
          ========================================== */}
      {gameTab === 'picture' && (
        <div id="picture-puzzle-game" className="space-y-4 max-w-sm mx-auto animate-fadeIn col">
          
          <div className="flex justify-between items-center bg-indigo-50 p-3 rounded-xl border border-indigo-100 select-none">
            <div className="space-y-1 text-left">
              <h4 className="text-xs font-bold text-indigo-950 font-sans">
                {currentLang === 'en' ? 'Game Mode: Image swap' : 'খেলা: ছবির ধাঁধা'}
              </h4>
              <p className="text-[10px] text-slate-500 font-sans">
                {currentLang === 'en' ? 'Click two tiles to swap their positions!' : 'যেকোনো দুটি টাইল পরপর ক্লিক করে অদলবদল করো!'}
              </p>
            </div>
            <div className="text-right">
              <span className="text-xs font-black text-indigo-950 block font-mono">
                {currentLang === 'en' ? 'Moves:' : 'মোট চাল:'} {picPuzzleMoves}
              </span>
            </div>
          </div>

          <div className="bg-white border border-slate-200 p-4 rounded-2xl shadow-xs space-y-4">
            
            <div className="relative aspect-[4/3] w-full max-w-[280px] sm:max-w-[320px] mx-auto rounded-xl overflow-hidden bg-slate-100 border border-slate-200">
              
              {picPuzzleIsPreview && (
                <div className="absolute inset-0 z-10 bg-black/45 flex flex-col items-center justify-center text-white p-4 select-none animate-fadeIn text-center">
                  <div className="bg-indigo-600/90 py-1 px-3 rounded-full text-[10px] font-black shadow-lg mb-1">
                    {currentLang === 'en' ? 'Memorize Picture!' : 'ছবিটি মনে রাখো!'}
                  </div>
                  <span className="text-3xl font-extrabold font-mono drop-shadow-md animate-ping">
                    {picPuzzleCountdown}
                  </span>
                  <p className="text-[9px] text-white/90 mt-1 font-bold font-sans">
                    {currentLang === 'en' ? 'Scrambling soon...' : 'কিছুক্ষণের মধ্যেই এলোমেলো হবে...'}
                  </p>
                </div>
              )}

              {picPuzzleSolved && (
                <div className="absolute inset-0 z-10 bg-emerald-950/80 flex flex-col items-center justify-center text-white p-4 select-none animate-fadeIn text-center">
                  <div className="bg-emerald-600 p-2 rounded-full text-white mb-2 animate-bounce">
                    🎉
                  </div>
                  <h4 className="text-xs font-black">
                    {currentLang === 'en' ? 'Masterpiece Aligned!' : 'অভিনন্দন! ছবি মিলে গেছে!'}
                  </h4>
                  <p className="text-[9px] text-emerald-200 mt-1 font-bold">
                    {currentLang === 'en' ? `Solved nicely in ${picPuzzleMoves} moves! +25 Stars` : `${picPuzzleMoves} চালে চমৎকার সমাধান হয়েছে! +২৫ স্টার`}
                  </p>
                  <button
                    onClick={() => initPicPuzzle()}
                    className="mt-3 py-1 px-3 bg-white text-emerald-950 hover:bg-emerald-100 text-[10px] font-black rounded-lg transition-colors cursor-pointer animate-fadeIn"
                  >
                    {currentLang === 'en' ? 'Play Next Picture' : 'পরবর্তী ছবি'}
                  </button>
                </div>
              )}

              <div className="grid grid-cols-3 grid-rows-3 h-full w-full">
                {picPuzzleTiles.map((tileVal, idx) => {
                  const displayOriginal = picPuzzleIsPreview || picPuzzleSolved;
                  const activeIndex = displayOriginal ? idx : tileVal;
                  const bgPos = `${(activeIndex % 3) * 50}% ${Math.floor(activeIndex / 3) * 55}%`;
                  
                  return (
                    <button
                      key={idx}
                      onClick={() => handlePicPuzzleTileClick(idx)}
                      disabled={picPuzzleIsPreview || picPuzzleSolved}
                      style={{
                        backgroundImage: `url(${PUZZLE_IMAGES[picPuzzleImgIdx].url})`,
                        backgroundSize: '300% 300%',
                        backgroundPosition: bgPos,
                      }}
                      className={`h-full w-full border border-slate-300 transition-all cursor-pointer overflow-hidden ${
                        picPuzzleSelectedIdx === idx 
                          ? 'ring-4 ring-rose-500 ring-inset opacity-80 z-10 scale-[0.98]' 
                          : 'hover:opacity-90'
                      }`}
                    />
                  );
                })}
              </div>

            </div>

            <div className="text-center font-bold text-xs text-indigo-950 select-none font-sans mt-2">
              {currentLang === 'en' ? 'Target:' : 'ছবির নাম:'} <span className="text-indigo-650">{currentLang === 'en' ? PUZZLE_IMAGES[picPuzzleImgIdx].title.en : PUZZLE_IMAGES[picPuzzleImgIdx].title.bn}</span>
            </div>

            <div className="flex flex-col gap-2 pt-1 border-t border-slate-100">
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => scramblePicPuzzleBoard()}
                  disabled={picPuzzleIsPreview || picPuzzleSolved}
                  className="py-1.5 px-3 bg-slate-100 hover:bg-indigo-50 text-indigo-950 text-[10px] font-black rounded-lg transition-colors border border-slate-200 cursor-pointer disabled:opacity-50"
                >
                  🌀 {currentLang === 'en' ? 'Force Scramble' : 'এলোমেলো করো'}
                </button>

                <button
                  onClick={() => setPicPuzzleShowRef(!picPuzzleShowRef)}
                  disabled={picPuzzleIsPreview || picPuzzleSolved}
                  className={`py-1.5 px-3 border text-[10px] font-black rounded-lg transition-colors cursor-pointer disabled:opacity-50 ${
                    picPuzzleShowRef
                      ? 'bg-rose-100 text-rose-950 border-rose-300'
                      : 'bg-slate-100 text-indigo-950 border-slate-200 hover:bg-indigo-50'
                  }`}
                >
                  👁️ {picPuzzleShowRef ? (currentLang === 'en' ? 'Hide Help' : 'সাহায্য লুকান') : (currentLang === 'en' ? 'Peek Reference' : 'পূর্ণ ছবি দেখুন')}
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => initPicPuzzle()}
                  className="py-1.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white text-[10px] font-black rounded-lg transition-colors cursor-pointer"
                >
                  🔄 {currentLang === 'en' ? 'Reset / Next' : 'নতুন ছবি / রিসেট'}
                </button>

                <div className="text-[9px] text-slate-400 select-none leading-tight font-bold flex items-center justify-center text-center">
                  {currentLang === 'en' ? 'Earn +25 Stars per victory!' : 'যেকোনো জয়ে +২৫ স্টারের চাবি!'}
                </div>
              </div>
            </div>

          </div>

          {picPuzzleShowRef && !picPuzzleIsPreview && !picPuzzleSolved && (
            <div className="bg-rose-50 p-2.5 rounded-xl border border-rose-100 space-y-1.5 animate-fadeIn select-none text-center">
              <p className="text-[10px] font-bold text-rose-950">
                {currentLang === 'en' ? '✨ Full Reference Image Preview:' : '✨ সমাধান করতে ছবিটি মেলাও:'}
              </p>
              <img
                src={PUZZLE_IMAGES[picPuzzleImgIdx].url}
                alt="Reference Target"
                referrerPolicy="no-referrer"
                className="w-32 h-24 object-cover rounded-md mx-auto border-2 border-rose-200 shadow-sm"
              />
            </div>
          )}

        </div>
      )}

    </div>
  );
}
