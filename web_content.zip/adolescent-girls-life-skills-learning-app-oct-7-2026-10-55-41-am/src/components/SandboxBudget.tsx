import React, { useState } from 'react';
import { BudgetItem } from '../types';
import { PiggyBank, PlusCircle, ArrowUpRight, ArrowDownLeft, Trash2, Milestone, ShieldAlert } from 'lucide-react';

interface SandboxBudgetProps {
  currentLang: 'en' | 'bn';
  budgetItems: BudgetItem[];
  onAddTransaction: (item: Omit<BudgetItem, 'id'>) => void;
  onClearTransactions: () => void;
  onDeleteItem: (id: string) => void;
}

export default function SandboxBudget({
  currentLang,
  budgetItems,
  onAddTransaction,
  onClearTransactions,
  onDeleteItem
}: SandboxBudgetProps) {
  // Input states
  const [desc, setDesc] = useState<string>('');
  const [amountStr, setAmountStr] = useState<string>('');
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [category, setCategory] = useState<BudgetItem['category']>('snacks');
  const [goalName, setGoalName] = useState<string>('');
  const [goalCost, setGoalCost] = useState<number>(300);
  const [addedAllowanceAmount, setAddedAllowanceAmount] = useState<string>('');

  const keyLabels = {
    title: { en: "🪙 Micro-Budgeting Sandbox Wallet", bn: "🪙 খুদে বাজেট ও জমানোর স্যান্ডবক্স ওয়ালেট" },
    subtitle: {
      en: "Learn financial discipline! Practice managing a small allowance (Simulated or Real). Plan your daily pocket money, track expenses, and view long-term goals.",
      bn: "ছোট থেকেই হিসেব করতে শেখো! একটি খসড়া পকেটমানি বা নিজের জমানো টাকা কীভাবে খরচ ও সুষম জমা করবে তার স্যান্ডবক্স প্র্যাকটিস করো।"
    },
    balance: { en: "Available Balance", bn: "মোট গচ্ছিত টাকা" },
    totalIncome: { en: "Total Received", bn: "মোট উপার্জন" },
    totalExpense: { en: "Total Spent", bn: "মোট খরচ" },
    addRecord: { en: "Add Record", bn: "হিসেব যুক্ত করো" },
    descPl: { en: "e.g., Bought school pen, pocket allowance", bn: "যেমন: খাতা কেনা, পকেটমানি..." },
    amountPl: { en: "Amount in Rupees (₹)", bn: "টাকার পরিমাণ (₹)" },
    typeLabel: { en: "Type:", bn: "ধরণ:" },
    categoryLabel: { en: "Category:", bn: "ক্যাটাগরি:" },
    btnSubmit: { en: "Add to Wallet", bn: "ওয়ালেটে যোগ করো" },
    logHeader: { en: "Transaction Ledger Log", bn: "ওয়ালেট খরচের খতিয়ান" },
    emptyLog: { en: "Your wallet is empty. Try simulating a starting pocket allowance!", bn: "তোমার ওয়ালেট এখন খালি। টাকা জমানো শুরু করতে একটি পকেটমানি যোগ করো!" },
    simulateBonus: { en: "+ Simulate ₹150 Homework Reward", bn: "+ বাড়ি সাহায্য করার জন্য ₹১৫০ যোগ করো" },
    clearAll: { en: "Reset Ledger", bn: "খাতা পরিষ্কার করো" },
    goalSec: { en: "🎯 Dream Savings Target Tracker", bn: "🎯 স্বপ্নের সঞ্চয় লক্ষ্যমাত্রার ট্র্যাকার" },
    goalDesc: {
      en: "Calculate how long it takes to save for an item (e.g. Higher Education Book, cycle repair, sanitary toolkit) based on your savings habits.",
      bn: "হিসেব করে দেখো তোমার বাজেটে প্রতিদিন বা প্রতি সপ্তাহে যা বাঁচছে, তা দিয়ে স্বপ্নের জিনিস কিনতে কতদিন লাগবে।"
    },
    goalTargetName : { en: "Target/Dream Item Name:", bn: "কী স্বপ্নের জিনিস কিনতে চাও?:" },
    goalTargetCost: { en: "Item Estimated Cost (₹):", bn: "তার আনুমানিক দাম (₹):" },
    goalResultSuccess: {
      en: "With your current pocket savings, it will take you just {days} days to purchase this {item}! Tremendous discipline!",
      bn: "তোমার ওয়ালেটে জমে থাকা টাকা অনুযায়ী, আর মাত্র {days} দিন জমালেই তুমি '{item}' কিনতে পারবে! দারুণ সঞ্চয়!"
    },
    goalResultWarning: {
      en: "You currently have ₹0 savings or a negative balance. Try reducing expenses on snacks to accumulate money for your goals!",
      bn: "তোমার ওয়ালেটে এখন সঞ্চয় ₹০ বা মাইনাস! লক্ষ্য পূরণের জন্য ফালতু খরচ কমিয়ে একটু জমানোর চেষ্টা করো!"
    },
    savingTip: {
      en: "💡 Girls' Wise Rule: Saving ₹10 every single week adds up to ₹520 in a year! This can purchase 2 robust reference study packages or sanitary hygiene toolkits for school.",
      bn: "💡 দিদিমণিদের জমানোর নিয়ম: সপ্তাহে মাত্র ১০ টাকা করে সঞ্চয় করতে পারলে বছরে ৫২০ টাকা জমে যায়! তা দিয়ে ৩টে দামি স্কুলের রেফারেন্স ডায়েরি বা স্যানিটারি স্বাস্থ্য কিট কেনা যায়।"
    }
  };

  // Calculations
  const incomeItems = budgetItems.filter(i => i.type === 'income');
  const expenseItems = budgetItems.filter(i => i.type === 'expense');

  const totalIncome = incomeItems.reduce((acc, curr) => acc + curr.amount, 0);
  const totalExpense = expenseItems.reduce((acc, curr) => acc + curr.amount, 0);
  const balance = totalIncome - totalExpense;

  const handleAddAllowance = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(addedAllowanceAmount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) return;

    onAddTransaction({
      description: currentLang === 'en' ? "Parent Allowance" : "অভিভাবকদের দেওয়া পকেটমানি",
      amount: parsedAmount,
      type: 'income',
      category: 'allowance',
      date: new Date().toLocaleDateString()
    });

    setAddedAllowanceAmount('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amountStr);
    if (!desc || isNaN(parsedAmount) || parsedAmount <= 0) return;

    onAddTransaction({
      description: desc,
      amount: parsedAmount,
      type: type,
      category: category,
      date: new Date().toLocaleDateString()
    });

    setDesc('');
    setAmountStr('');
  };

  // Dynamic values insertion
  const getGoalAdvice = () => {
    if (balance <= 0) {
      return keyLabels.goalResultWarning[currentLang];
    }
    const daysNeeded = Math.ceil(goalCost / (balance / (budgetItems.length || 1)));
    const finalDays = isFinite(daysNeeded) && daysNeeded > 0 ? daysNeeded : Math.ceil(goalCost / 10);
    return keyLabels.goalResultSuccess[currentLang]
      .replace('{days}', String(finalDays))
      .replace('{item}', goalName || (currentLang === 'en' ? "Dream Book" : "স্বপ্নের বই"));
  };

  return (
    <div id="sandbox-budget-card" className="bg-white p-4 md:p-6 rounded-2xl border border-slate-200 shadow-xs max-w-4xl mx-auto space-y-6">
      
      {/* Title */}
      <div>
        <h3 className="text-md font-extrabold text-blue-950 flex items-center gap-2">
          <PiggyBank className="w-5 h-5 text-indigo-600" />
          {keyLabels.title[currentLang]}
        </h3>
        <p className="text-xs text-slate-600 mt-1 lines-spaced font-sans font-normal">
          {keyLabels.subtitle[currentLang]}
        </p>
      </div>

      {/* Stats Block */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 p-3 rounded-xl border border-indigo-150 relative overflow-hidden">
          <p className="text-[10px] text-indigo-800 uppercase tracking-widest font-extrabold">{keyLabels.balance[currentLang]}</p>
          <p className={`text-xl font-black font-mono mt-1 ${balance >= 0 ? 'text-indigo-950' : 'text-rose-700'}`}>
            ₹{balance}
          </p>
          <div className="absolute right-0 bottom-0 text-indigo-200 text-6xl select-none font-bold translate-y-3 translate-x-3 pointer-events-none font-mono">₹</div>
        </div>

        <div className="bg-emerald-50 p-3 rounded-xl border border-emerald-150">
          <p className="text-[10px] text-emerald-800 uppercase tracking-widest font-extrabold flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
            {keyLabels.totalIncome[currentLang]}
          </p>
          <p className="text-lg font-black font-mono text-emerald-900 mt-1">₹{totalIncome}</p>
        </div>

        <div className="bg-rose-50 p-3 rounded-xl border border-rose-150">
          <p className="text-[10px] text-rose-800 uppercase tracking-widest font-extrabold flex items-center gap-1">
            <ArrowDownLeft className="w-3.5 h-3.5 text-rose-600" />
            {keyLabels.totalExpense[currentLang]}
          </p>
          <p className="text-lg font-black font-mono text-rose-900 mt-1">₹{totalExpense}</p>
        </div>
      </div>

      {/* Main Sandbox split screen */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
        
        {/* Left column containing both forms */}
        <div className="space-y-4">
          {/* Form Container (Expenses/Earnings Tracking) */}
          <form onSubmit={handleSubmit} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <h4 className="text-xs font-black text-slate-800 uppercase tracking-wider">{keyLabels.addRecord[currentLang]}</h4>
            
            <div className="space-y-1">
              <label className="text-[10px] font-extrabold text-slate-600">{currentLang === 'en' ? "Transaction description" : "লেনদেনের খতিয়ান বিবরণ"}</label>
              <input
                type="text"
                required
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                placeholder={keyLabels.descPl[currentLang]}
                className="w-full text-xs p-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-indigo-500 bg-white text-slate-950 font-medium"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-extrabold text-slate-600">{keyLabels.amountPl[currentLang]}</label>
              <input
                type="number"
                required
                value={amountStr}
                onChange={(e) => setAmountStr(e.target.value)}
                placeholder="e.g. ₹20,  ₹50"
                className="w-full text-xs p-2 border border-slate-200 rounded-md focus:ring-1 focus:ring-indigo-500 bg-white text-slate-950 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[10px] font-extrabold text-slate-600">{keyLabels.typeLabel[currentLang]}</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as 'income' | 'expense')}
                  className="w-full text-xs p-2 border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-indigo-500 text-slate-950 font-medium"
                >
                  <option value="expense">{currentLang === 'en' ? "Spend (Expense)" : "খরচ (Expense)"}</option>
                  <option value="income">{currentLang === 'en' ? "Gain (Income)" : "আয় (Income)"}</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-extrabold text-slate-600">{keyLabels.categoryLabel[currentLang]}</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as BudgetItem['category'])}
                  className="w-full text-xs p-2 border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-indigo-500 text-slate-950 font-medium"
                >
                  <option value="snacks">{currentLang === 'en' ? "🍟 Snacks & Food" : "🍟 খাবার দাবার"}</option>
                  <option value="education">{currentLang === 'en' ? "📚 School / Pen" : "📚 পড়াশোনা ও কুটিরশিল্প"}</option>
                  <option value="hygiene">{currentLang === 'en' ? "🧼 Clean Pad / Soap" : "🧼 পরিচ্ছন্নতা ও সাবান"}</option>
                  <option value="savings">{currentLang === 'en' ? "🔒 Dream Savings" : "🔒 নিজের ভবিষ্যতের জমা"}</option>
                  <option value="hobby">{currentLang === 'en' ? "🎨 Hobby / Crafts" : "🎨 হাতের কাজ / রং"}</option>
                  <option value="other">{currentLang === 'en' ? "📦 Other" : "📦 অন্যান্য খরচ"}</option>
                </select>
              </div>
            </div>

            <div className="pt-1.5">
              <button
                type="submit"
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md text-xs font-black cursor-pointer transition-colors text-center"
              >
                {keyLabels.btnSubmit[currentLang]}
              </button>
            </div>
          </form>

          {/* Parents Pocket Money Card */}
          <form onSubmit={handleAddAllowance} className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-3">
            <h4 className="text-xs font-black text-emerald-800 uppercase tracking-wider flex items-center gap-1">
              <span>🧧</span>
              {currentLang === 'en' ? "Add Money (Parent Allowance)" : "মা-বাবার দেওয়া পকেটমানি যোগ করো"}
            </h4>
            <p className="text-[11px] text-emerald-700 leading-snug">
              {currentLang === 'en' 
                ? "Did your parents give you money/allowance for this month? Enter the amount to credit your wallet!"
                : "মা-বাবা বা অভিভাবক কি তোমাকে এই মাসের খরচ চালানোর পকেটমানি দিয়েছেন? টাকার পরিমাণ লিখে ওয়ালেটে যোগ করো!"}
            </p>
            <div className="flex gap-2">
              <input
                id="input-parent-allowance"
                type="number"
                required
                value={addedAllowanceAmount}
                onChange={(e) => setAddedAllowanceAmount(e.target.value)}
                placeholder={currentLang === 'en' ? "E.g. ₹500, ₹100" : "যেমন: ৫০০, ১০০..."}
                className="flex-1 text-xs p-2 border border-emerald-200 rounded-md focus:ring-1 focus:ring-emerald-500 bg-white text-slate-950 font-medium"
              />
              <button
                type="submit"
                className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-black transition-colors shrink-0"
              >
                {currentLang === 'en' ? "Add Money" : "যোগ করো"}
              </button>
            </div>
          </form>
        </div>

        {/* ledger list */}
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
          <div className="flex items-center justify-between border-b pb-1 border-slate-150">
            <span className="text-xs font-bold text-slate-800">{keyLabels.logHeader[currentLang]}</span>
            {budgetItems.length > 0 && (
              <button
                onClick={onClearTransactions}
                className="text-[10px] font-bold text-rose-600 hover:underline cursor-pointer"
              >
                {keyLabels.clearAll[currentLang]}
              </button>
            )}
          </div>

          {budgetItems.length === 0 ? (
            <div className="text-center py-10 space-y-3">
              <span className="block text-4xl">🐷</span>
              <p className="text-xs text-slate-400 font-sans italic px-4">
                {keyLabels.emptyLog[currentLang]}
              </p>
            </div>
          ) : (
            <div className="space-y-1.5">
              {budgetItems.map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between p-2 rounded-lg border border-slate-100 bg-slate-50/50 text-xs transition-colors hover:bg-slate-50"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="text-base select-none">
                      {item.category === 'snacks' && "🍟"}
                      {item.category === 'education' && "📚"}
                      {item.category === 'hygiene' && "🧼"}
                      {item.category === 'savings' && "🔒"}
                      {item.category === 'hobby' && "🎨"}
                      {item.category === 'allowance' && "🪙"}
                      {item.category === 'other' && "📦"}
                    </span>
                    <div className="truncate">
                      <p className="font-extrabold text-slate-800 truncate">{item.description}</p>
                      <p className="text-[10px] text-slate-400 font-mono">{item.date}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className={`font-mono font-black ${item.type === 'income' ? 'text-emerald-600' : 'text-slate-800'}`}>
                      {item.type === 'income' ? '+' : '-'}₹{item.amount}
                    </span>
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="text-slate-300 hover:text-rose-600 p-1 cursor-pointer transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Goal Calculator Card Section */}
      <div className="bg-slate-50/70 p-4 rounded-xl border border-dashed border-indigo-200">
        <h4 className="text-xs font-black text-indigo-950 flex items-center gap-1.5">
          <Milestone className="w-4 h-4 text-indigo-600" />
          {keyLabels.goalSec[currentLang]}
        </h4>
        <p className="text-[11px] text-slate-600 mt-1">
          {keyLabels.goalDesc[currentLang]}
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-600">{keyLabels.goalTargetName[currentLang]}</label>
            <input
              type="text"
              value={goalName}
              onChange={(e) => setGoalName(e.target.value)}
              placeholder={currentLang === 'en' ? "e.g., Reference General Book Package" : "যেমন: রেফারেন্স বইয়ের সেট..."}
              className="w-full text-xs p-1.5 border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-600">{keyLabels.goalTargetCost[currentLang]}</label>
            <input
              type="number"
              value={goalCost}
              onChange={(e) => setGoalCost(Math.max(1, parseFloat(e.target.value) || 0))}
              placeholder="e.g. 150"
              className="w-full text-xs p-1.5 border border-slate-200 rounded-md bg-white focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* advice status */}
        <div className="mt-3 p-3 bg-white rounded-lg border border-slate-200 overflow-hidden text-xs text-indigo-950 font-medium font-sans leading-relaxed">
          {getGoalAdvice()}
        </div>
      </div>

      {/* advice banner card */}
      <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 font-medium leading-relaxed flex items-start gap-2">
        <ShieldAlert className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
        <span>{keyLabels.savingTip[currentLang]}</span>
      </div>

    </div>
  );
}
