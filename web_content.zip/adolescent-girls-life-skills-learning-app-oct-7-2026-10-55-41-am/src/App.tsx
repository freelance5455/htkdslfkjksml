import React, { useState, useEffect } from 'react';
import { 
  BookOpen, 
  HelpCircle, 
  Activity, 
  Phone, 
  User, 
  SwitchCamera, 
  CheckCircle, 
  RotateCcw, 
  ChevronRight, 
  Heart, 
  Bookmark, 
  Users, 
  Clock, 
  Smile, 
  LogOut, 
  ShieldCheck, 
  Check, 
  MapPin, 
  BookOpenCheck,
  PlusCircle,
  Lightbulb,
  AlertTriangle,
  Award,
  Sparkles,
  Pocket,
  FileText,
  Info
} from 'lucide-react';

import { UserProfile, ProgressState, Chapter, QuizQuestion, Note, DecisionTree, BudgetItem } from './types';
import { LIFE_SKILLS_CHAPTERS, QUIZ_QUESTIONS, HELPLINES, BADGES, DAILY_AFFIRMATIONS } from './chaptersData';
import SafeSpace from './components/SafeSpace';
import AdolescentHealth from './components/AdolescentHealth';
import StudyFocusTimer from './components/StudyFocusTimer';
import SandboxBudget from './components/SandboxBudget';
import VisualDecisionTree from './components/VisualDecisionTree';
import NotesJournal from './components/NotesJournal';
import StJohnLogo from './components/StJohnLogo';
import BlockQuizWizard from './components/BlockQuizWizard';
import CourseDocumentImporter from './components/CourseDocumentImporter';
// @ts-ignore
import shokhiLogo from './assets/images/shokhi_logo_1783352228495.jpg';

const AVATARS = [
  { emoji: "🌸", label: "Flower" },
  { emoji: "🌟", label: "Star" },
  { emoji: "🚀", label: "Explorer" },
  { emoji: "🦁", label: "Brave Lion" },
  { emoji: "🎨", label: "Artist" },
  { emoji: "🦉", label: "Wise Owl" },
  { emoji: "🦄", label: "Dreamer" },
  { emoji: "🍀", label: "Lucky Leaf" }
];

const renderAvatar = (avatar: string, sizeClass: string = "w-10 h-10 text-xl") => {
  if (avatar && avatar.startsWith('data:image/')) {
    const sizeParts = sizeClass.split(' ');
    const wClass = sizeParts.find(p => p.startsWith('w-')) || 'w-10';
    const hClass = sizeParts.find(p => p.startsWith('h-')) || 'h-10';
    return (
      <img 
        src={avatar} 
        className={`${wClass} ${hClass} rounded-full object-cover border-2 border-indigo-300 shadow-2xs inline-block`} 
        alt="User Selfie" 
      />
    );
  }
  return (
    <span className={sizeClass} role="img" aria-label="avatar">
      {avatar || '🌸'}
    </span>
  );
};

export default function App() {
  // Global Bilingual state
  const [currentLang, setCurrentLang] = useState<'en' | 'bn'>('en');

  // Camera & Custom Avatar States
  const [useCustomAvatar, setUseCustomAvatar] = useState(false);
  const [customAvatarDataUrl, setCustomAvatarDataUrl] = useState('');
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState('');
  const videoRef = React.useRef<HTMLVideoElement | null>(null);
  const streamRef = React.useRef<MediaStream | null>(null);

  // Profiles List & Current Active Profile Name in localStorage
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [currentProfile, setCurrentProfile] = useState<UserProfile | null>(null);

  // New Profile Form State
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileAge, setNewProfileAge] = useState<number | ''>('');
  const [selectedAvatar, setSelectedAvatar] = useState('🌸');
  const [newProfilePassword, setNewProfilePassword] = useState('');
  const [newProfileConfirmPassword, setNewProfileConfirmPassword] = useState('');

  // Passcode Verification Overlay state
  const [profileToVerify, setProfileToVerify] = useState<UserProfile | null>(null);
  const [enteredPasscode, setEnteredPasscode] = useState('');
  const [passcodeError, setPasscodeError] = useState('');
  const [showPasscodeValue, setShowPasscodeValue] = useState(false);

  // Migration passcode setup state (for pre-existing profiles without passwords)
  const [migratingPasscode, setMigratingPasscode] = useState('');
  const [migratingConfirmPasscode, setMigratingConfirmPasscode] = useState('');

  // Google Sign-In & Onboarding States
  const [showGoogleModal, setShowGoogleModal] = useState(false);
  const [googleEmail, setGoogleEmail] = useState('testnilanjan@gmail.com');
  const [googleName, setGoogleName] = useState('Nilanjan Majumdar');
  const [googleAge, setGoogleAge] = useState<number | ''>(15);
  const [googlePin, setGooglePin] = useState('');
  const [googleConfirmPin, setGoogleConfirmPin] = useState('');
  const [googleError, setGoogleError] = useState('');
  const [showOfflineForm, setShowOfflineForm] = useState(false);

  // Inactivity Detector states (2 min threshold, 30s countdown)
  const [showInactivityPrompt, setShowInactivityPrompt] = useState(false);
  const [inactivityCountdown, setInactivityCountdown] = useState(30);
  const [isSessionPaused, setIsSessionPaused] = useState(false);
  const lastActivityTimeRef = React.useRef(Date.now());
  const inactivityCountdownTimerRef = React.useRef<any>(null);

  // Positive Screen Time Tracker states
  const [secondsToday, setSecondsToday] = useState(0);
  const [screenTimeHistory, setScreenTimeHistory] = useState<Record<string, number>>({});
  const [showScreenTimeModal, setShowScreenTimeModal] = useState(false);
  const [estimatedPhoneHours, setEstimatedPhoneHours] = useState<number>(3);

  // Multi-profile View state. True shows the profile selector screen
  const [showProfileSelector, setShowProfileSelector] = useState(true);

  // Active Tab: 'chapters' | 'quizzes' | 'games' | 'health' | 'tools' | 'helpline' | 'about'
  const [activeTab, setActiveTab ] = useState<'chapters' | 'quizzes' | 'games' | 'health' | 'tools' | 'helpline' | 'about'>('chapters');

  // Subtab for within the interactive tools tab
  const [activeSubtab, setActiveSubtab] = useState<'timer' | 'budget' | 'decide' | 'journal'>('timer');

  // Dynamic Curriculum loaded from memory/localStorage, defaulting to LIFE_SKILLS_CHAPTERS (21 chapters)
  const [chapters, setChapters] = useState<Chapter[]>(() => {
    const saved = localStorage.getItem('sakhi_custom_chapters');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error("Error loading custom chapters", e);
      }
    }
    return LIFE_SKILLS_CHAPTERS;
  });

  // Dynamic Quizzes loaded from memory/localStorage, defaulting to QUIZ_QUESTIONS (67 questions)
  const [quizQuestions, setQuizQuestions] = useState<QuizQuestion[]>(() => {
    const saved = localStorage.getItem('sakhi_custom_quizzes');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (e) {
        console.error("Error loading custom quizzes", e);
      }
    }
    return QUIZ_QUESTIONS;
  });

  // Curriculum Manager & Document Importer modal state
  const [showCourseImporter, setShowCourseImporter] = useState<boolean>(false);

  // Admin Authentication State
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('sakhi_is_admin') === 'true';
  });
  const [showAdminLoginModal, setShowAdminLoginModal] = useState<boolean>(false);
  const [adminUsername, setAdminUsername] = useState<string>('');
  const [adminPassword, setAdminPassword] = useState<string>('');
  const [adminError, setAdminError] = useState<string>('');

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAdminError('');
    const u = adminUsername.trim().toLowerCase();
    const p = adminPassword;

    // Secure credential check (Admin email/username + pass)
    if ((u === 'admin' || u === 'admin@sakhi.org' || u === 'testnilanjan@gmail.com') && (p === 'sakhi2026' || p === 'admin123')) {
      setIsAdminAuthenticated(true);
      localStorage.setItem('sakhi_is_admin', 'true');
      setShowAdminLoginModal(false);
      setAdminUsername('');
      setAdminPassword('');
    } else {
      setAdminError(
        currentLang === 'en'
          ? 'Invalid admin credentials. Please enter a valid username/email and password.'
          : 'ভুল অ্যাডমিন তথ্য। সঠিক ইউজারনেম এবং পাসওয়ার্ড প্রদান করুন।'
      );
    }
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('sakhi_is_admin');
  };

  // Phase Filter for Curriculum tab
  const [selectedPhaseFilter, setSelectedPhaseFilter] = useState<number | 'all'>('all');

  // Interactive branching dilemma choice record: chapterId -> 'A' | 'B'
  const [branchingChoices, setBranchingChoices] = useState<Record<number, 'A' | 'B'>>({});

  // Active quiz in reader or modal
  const [openedChapterQuiz, setOpenedChapterQuiz] = useState<boolean>(false);

  // Currently opened chapter (null means list view)
  const [openedChapter, setOpenedChapter] = useState<Chapter | null>(null);

  // Random Daily Affirmation Index
  const [affirmationIndex, setAffirmationIndex] = useState(0);

  // State for user-specific offline progress
  const [progress, setProgress] = useState<ProgressState>({
    completedChapters: [],
    quizAnswers: {},
    quizScores: {},
    notes: [],
    decisions: [],
    budget: [],
    starPoints: 50, // default starts with 50 stars!
    timerMinutesCount: 0,
    unlockedBadgeIds: []
  });

  // Pick random daily suggestion on load
  useEffect(() => {
    const randomIdx = Math.floor(Math.random() * DAILY_AFFIRMATIONS.length);
    setAffirmationIndex(randomIdx);
  }, [activeTab]);

  // Load All profiles on mount (no auto-bypass to protect privacy!)
  useEffect(() => {
    const savedProfiles = localStorage.getItem('ls_edu_profiles');
    if (savedProfiles) {
      try {
        const parsedProfiles = JSON.parse(savedProfiles) as UserProfile[];
        setProfiles(parsedProfiles);
      } catch (e) {
        console.error("Error loading profiles:", e);
      }
    }
  }, []);

  const getTodayDateString = () => {
    const d = new Date();
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  const toBanglaNumber = (num: number) => {
    const numStr = String(num);
    const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return numStr.split('').map(digit => {
      const parsed = parseInt(digit, 10);
      return isNaN(parsed) ? digit : banglaDigits[parsed];
    }).join('');
  };

  const formatDateReadable = (dateStr: string) => {
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    const [year, month, day] = parts;
    const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthsBn = ['জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন', 'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'];
    
    const monthIdx = parseInt(month, 10) - 1;
    const mEn = monthsEn[monthIdx] || '';
    const mBn = monthsBn[monthIdx] || '';
    
    if (currentLang === 'en') {
      return `${parseInt(day, 10)} ${mEn} ${year}`;
    } else {
      return `${toBanglaNumber(parseInt(day, 10))} ${mBn} ${toBanglaNumber(parseInt(year, 10))}`;
    }
  };

  // Dedicated effect to track screen time in active session for the current profile
  useEffect(() => {
    if (!currentProfile) return;

    const key = `ls_edu_screentime_${currentProfile.name}`;
    const saved = localStorage.getItem(key);
    let historyObj: Record<string, number> = {};
    if (saved) {
      try {
        historyObj = JSON.parse(saved);
      } catch(e) {
        console.error("Error loading screen time:", e);
      }
    }

    const todayStr = getTodayDateString();
    const initialSeconds = historyObj[todayStr] || 0;
    setScreenTimeHistory(historyObj);
    setSecondsToday(initialSeconds);

    // Track active usage seconds (updates state + writes back every 5 seconds)
    const interval = setInterval(() => {
      if (isSessionPaused || showInactivityPrompt) return;
      setSecondsToday(prevSeconds => {
        const newSeconds = prevSeconds + 5;
        const updatedHistory = {
          ...historyObj,
          [todayStr]: newSeconds
        };
        historyObj = updatedHistory;
        setScreenTimeHistory(updatedHistory);
        localStorage.setItem(key, JSON.stringify(updatedHistory));
        return newSeconds;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [currentProfile, isSessionPaused, showInactivityPrompt]);

  // Touch / User Interaction listener to track activity
  useEffect(() => {
    const recordInteraction = () => {
      lastActivityTimeRef.current = Date.now();
      if (isSessionPaused) {
        setIsSessionPaused(false);
      }
    };

    window.addEventListener('touchstart', recordInteraction, { passive: true });
    window.addEventListener('mousedown', recordInteraction, { passive: true });
    window.addEventListener('keydown', recordInteraction, { passive: true });
    window.addEventListener('scroll', recordInteraction, { passive: true });

    return () => {
      window.removeEventListener('touchstart', recordInteraction);
      window.removeEventListener('mousedown', recordInteraction);
      window.removeEventListener('keydown', recordInteraction);
      window.removeEventListener('scroll', recordInteraction);
    };
  }, [isSessionPaused]);

  // Check 2 minutes inactivity
  useEffect(() => {
    if (!currentProfile || showProfileSelector) return;

    const inactivityCheckTimer = setInterval(() => {
      const elapsed = Date.now() - lastActivityTimeRef.current;
      // 2 minutes = 120,000ms
      if (elapsed >= 120000 && !showInactivityPrompt && !isSessionPaused) {
        setShowInactivityPrompt(true);
        setInactivityCountdown(30);
      }
    }, 2000);

    return () => clearInterval(inactivityCheckTimer);
  }, [currentProfile, showProfileSelector, showInactivityPrompt, isSessionPaused]);

  // Countdown timer for Inactivity Prompt (30 seconds)
  useEffect(() => {
    if (showInactivityPrompt) {
      inactivityCountdownTimerRef.current = setInterval(() => {
        setInactivityCountdown(prev => {
          if (prev <= 1) {
            clearInterval(inactivityCountdownTimerRef.current);
            setShowInactivityPrompt(false);
            setIsSessionPaused(true);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => {
        if (inactivityCountdownTimerRef.current) clearInterval(inactivityCountdownTimerRef.current);
      };
    }
  }, [showInactivityPrompt]);

  const handleResumeActivity = () => {
    lastActivityTimeRef.current = Date.now();
    setShowInactivityPrompt(false);
    setIsSessionPaused(false);
    if (inactivityCountdownTimerRef.current) clearInterval(inactivityCountdownTimerRef.current);
  };

  // Google Sign-In Handlers
  const handleOpenGoogleSignIn = () => {
    const existingGoogle = profiles.find(p => p.isGoogleAccount);
    if (existingGoogle) {
      handleSelectProfile(existingGoogle);
    } else {
      setGoogleEmail('testnilanjan@gmail.com');
      setGoogleName('Nilanjan Majumdar');
      setGoogleAge(15);
      setGooglePin('');
      setGoogleConfirmPin('');
      setGoogleError('');
      setShowGoogleModal(true);
    }
  };

  const handleCompleteGoogleOnboarding = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = googleName.trim();
    if (!trimmedName) {
      setGoogleError(currentLang === 'en' ? "Please enter your name" : "অনুগ্রহ করে নাম লিখুন");
      return;
    }
    const ageNum = Number(googleAge);
    if (!googleAge || ageNum < 10 || ageNum > 19) {
      setGoogleError(currentLang === 'en' ? "Age must be between 10 and 19 years (Adolescent focus)" : "বয়স অবশ্যই ১০ থেকে ১৯ বছরের মধ্যে হতে হবে");
      return;
    }
    if (!googlePin || googlePin.length !== 4 || !/^\d{4}$/.test(googlePin)) {
      setGoogleError(currentLang === 'en' ? "PIN must be exactly 4 numeric digits" : "পিন অবশ্যই ৪ সংখ্যার হতে হবে");
      return;
    }
    if (googlePin !== googleConfirmPin) {
      setGoogleError(currentLang === 'en' ? "PINs do not match" : "পিন দুটি মেলেনি");
      return;
    }

    const newGoogleProfile: UserProfile = {
      name: trimmedName,
      age: ageNum,
      avatar: "🌸",
      joinedAt: new Date().toISOString(),
      password: googlePin,
      isGoogleAccount: true,
      googleEmail: googleEmail.trim() || 'testnilanjan@gmail.com',
      googleUid: 'google_uid_' + Date.now(),
      cloudSynced: true
    };

    const updatedProfiles = [...profiles.filter(p => p.name !== newGoogleProfile.name), newGoogleProfile];
    setProfiles(updatedProfiles);
    localStorage.setItem('ls_edu_profiles', JSON.stringify(updatedProfiles));

    // Default progress with unlocked Chapter 1
    const defaultState: ProgressState = {
      completedChapters: [],
      quizAnswers: {},
      quizScores: {},
      notes: [],
      decisions: [],
      budget: [],
      starPoints: 50,
      timerMinutesCount: 0,
      unlockedBadgeIds: []
    };
    setProgress(defaultState);
    localStorage.setItem(`ls_edu_progress_${newGoogleProfile.name}`, JSON.stringify(defaultState));

    setCurrentProfile(newGoogleProfile);
    localStorage.setItem('ls_edu_current_profile', newGoogleProfile.name);
    setShowProfileSelector(false);
    setShowGoogleModal(false);
  };

  // Helper: load progress of a specific user
  const loadUserProgress = (userName: string) => {
    const key = `ls_edu_progress_${userName}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as ProgressState;
        // Ensure arrays are initialized if loading from a previous stale schema version
        setProgress({
          completedChapters: parsed.completedChapters || [],
          quizAnswers: parsed.quizAnswers || {},
          quizScores: parsed.quizScores || {},
          notes: parsed.notes || [],
          decisions: parsed.decisions || [],
          budget: parsed.budget || [],
          starPoints: parsed.starPoints ?? 50,
          timerMinutesCount: parsed.timerMinutesCount || 0,
          unlockedBadgeIds: parsed.unlockedBadgeIds || []
        });
      } catch (e) {
        console.error("Error parsing user progress", e);
      }
    } else {
      // Default empty progress
      const defaultState: ProgressState = {
        completedChapters: [],
        quizAnswers: {},
        quizScores: {},
        notes: [],
        decisions: [],
        budget: [],
        starPoints: 50,
        timerMinutesCount: 0,
        unlockedBadgeIds: []
      };
      setProgress(defaultState);
    }
  };

  // Helper to save progress
  const saveUserProgress = (updatedProgress: ProgressState) => {
    if (!currentProfile) return;
    setProgress(updatedProgress);
    localStorage.setItem(`ls_edu_progress_${currentProfile.name}`, JSON.stringify(updatedProgress));
  };

  // Badge Autocalculator checker hook
  useEffect(() => {
    if (!currentProfile) return;

    const unUnlocked = [...(progress.unlockedBadgeIds || [])];
    let changed = false;

    // Chapter completion badge (First Lesson)
    if (progress.completedChapters.length >= 1 && !unUnlocked.includes("badge_first_chapter")) {
      unUnlocked.push("badge_first_chapter");
      progress.starPoints += 20;
      changed = true;
    }
    // Phase 1 Master (Ch 1-3)
    if ([1, 2, 3].every(id => progress.completedChapters.includes(id)) && !unUnlocked.includes("badge_phase1_master")) {
      unUnlocked.push("badge_phase1_master");
      progress.starPoints += 40;
      changed = true;
    }
    // Phase 2 Master (Ch 4-7)
    if ([4, 5, 6, 7].every(id => progress.completedChapters.includes(id)) && !unUnlocked.includes("badge_phase2_master")) {
      unUnlocked.push("badge_phase2_master");
      progress.starPoints += 50;
      changed = true;
    }
    // Phase 3 Master (Ch 8-10)
    if ([8, 9, 10].every(id => progress.completedChapters.includes(id)) && !unUnlocked.includes("badge_phase3_master")) {
      unUnlocked.push("badge_phase3_master");
      progress.starPoints += 50;
      changed = true;
    }
    // Phase 4 Master (Ch 11-13)
    if ([11, 12, 13].every(id => progress.completedChapters.includes(id)) && !unUnlocked.includes("badge_phase4_master")) {
      unUnlocked.push("badge_phase4_master");
      progress.starPoints += 50;
      changed = true;
    }
    // Phase 5 Master (Ch 14-16)
    if ([14, 15, 16].every(id => progress.completedChapters.includes(id)) && !unUnlocked.includes("badge_phase5_master")) {
      unUnlocked.push("badge_phase5_master");
      progress.starPoints += 50;
      changed = true;
    }
    // Phase 6 Master (Ch 17-21)
    if ([17, 18, 19, 20, 21].every(id => progress.completedChapters.includes(id)) && !unUnlocked.includes("badge_phase6_master")) {
      unUnlocked.push("badge_phase6_master");
      progress.starPoints += 60;
      changed = true;
    }
    // All Chapters completion badge (21 chapters)
    if (chapters.length > 0 && progress.completedChapters.length >= chapters.length && !unUnlocked.includes("badge_all_chapters")) {
      unUnlocked.push("badge_all_chapters");
      progress.starPoints += 100;
      changed = true;
    }
    // Quiz Perfect Score on any quiz
    const hasPerfectQuiz = Object.values(progress.quizScores || {}).some((qs: any) => qs && qs.total > 0 && qs.score === qs.total);
    if (hasPerfectQuiz && !unUnlocked.includes("badge_quiz_champion_a")) {
      unUnlocked.push("badge_quiz_champion_a");
      progress.starPoints += 50;
      changed = true;
    }
    // Study Timer 45 mins badge
    if (progress.timerMinutesCount >= 45 && !unUnlocked.includes("badge_focus_expert")) {
      unUnlocked.push("badge_focus_expert");
      progress.starPoints += 40;
      changed = true;
    }
    // Self care journal badge
    if ((progress.notes || []).length >= 1 && !unUnlocked.includes("badge_journal_star")) {
      unUnlocked.push("badge_journal_star");
      progress.starPoints += 20;
      changed = true;
    }
    // Budget planner badge
    if ((progress.budget || []).length >= 1 && !unUnlocked.includes("badge_budget_planner")) {
      unUnlocked.push("badge_budget_planner");
      progress.starPoints += 20;
      changed = true;
    }

    if (changed) {
      saveUserProgress({
        ...progress,
        unlockedBadgeIds: unUnlocked
      });
    }
  }, [
    progress.completedChapters,
    progress.quizScores,
    progress.timerMinutesCount,
    progress.notes,
    progress.budget
  ]);

  // Camera & Custom Avatar Handlers
  const startCamera = async () => {
    setCameraError('');
    setCameraActive(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 300, height: 300, facingMode: 'user' } });
      streamRef.current = stream;
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(e => console.error("Video play failed:", e));
        }
      }, 150);
    } catch (err) {
      console.error(err);
      setCameraError(currentLang === 'en' 
        ? "Could not access camera. Please check permissions or upload an image instead." 
        : "ক্যামেরা সচল করা যায়নি। দয়া করে ছবি আপলোড করো বা পারমিশন চেক করো।"
      );
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  const captureSelfie = () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = 300;
      canvas.height = 300;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0, 300, 300);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setCustomAvatarDataUrl(dataUrl);
        setUseCustomAvatar(true);
        stopCamera();
      }
    }
  };

  const handleAvatarFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCustomAvatarDataUrl(reader.result as string);
        setUseCustomAvatar(true);
      };
      reader.readAsDataURL(file);
    }
  };

  React.useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Create Profile handler
  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = newProfileName.trim();
    if (!trimmedName) return;

    if (!newProfileAge || Number(newProfileAge) < 1 || Number(newProfileAge) > 120) {
      alert(currentLang === 'en'
        ? "Please enter a valid age (1 - 120)!"
        : "অনুগ্রহ করে একটি সঠিক বয়স (১ - ১২০) প্রবেশ করো!"
      );
      return;
    }

    // Check duplicate (normalizing all spaces and case-insensitive)
    const normalizedNewName = trimmedName.replace(/\s+/g, '').toLowerCase();
    if (profiles.some(p => p.name.replace(/\s+/g, '').toLowerCase() === normalizedNewName)) {
      alert(currentLang === 'en' 
        ? "This name is already used! Please pick a unique name (e.g., adding initials or surname)."
        : "এই নামটি ইতিমধ্যে ব্যবহার করা হয়েছে! অনুগ্রহ করে একটি নতুন বা অন্য ডাকনাম বেছে নাও।"
      );
      return;
    }

    // Password validation
    if (!newProfilePassword || newProfilePassword.length < 4 || newProfilePassword.length > 6 || !/^\d+$/.test(newProfilePassword)) {
      alert(currentLang === 'en'
        ? "Password must be a 4 to 6 digit numeric code!"
        : "পাসওয়ার্ড অবশ্যই ৪ থেকে ৬ সংখ্যার পিন কোড হতে হবে!"
      );
      return;
    }

    if (newProfilePassword !== newProfileConfirmPassword) {
      alert(currentLang === 'en'
        ? "Passwords do not match!"
        : "পাসওয়ার্ড দুটি মেলেনি!"
      );
      return;
    }

    const newProfile: UserProfile = {
      name: trimmedName,
      age: Number(newProfileAge),
      avatar: useCustomAvatar && customAvatarDataUrl ? customAvatarDataUrl : selectedAvatar,
      joinedAt: new Date().toISOString(),
      password: newProfilePassword
    };

    const updatedProfiles = [...profiles, newProfile];
    setProfiles(updatedProfiles);
    localStorage.setItem('ls_edu_profiles', JSON.stringify(updatedProfiles));

    // Select this user
    setCurrentProfile(newProfile);
    localStorage.setItem('ls_edu_current_profile', newProfile.name);
    setShowProfileSelector(false);

    // Stop and clear camera
    stopCamera();
    setUseCustomAvatar(false);
    setCustomAvatarDataUrl('');

    // Initial default progress
    const defaultState: ProgressState = {
      completedChapters: [],
      quizAnswers: {},
      quizScores: {},
      notes: [],
      decisions: [],
      budget: [],
      starPoints: 50,
      timerMinutesCount: 0,
      unlockedBadgeIds: []
    };
    setProgress(defaultState);
    localStorage.setItem(`ls_edu_progress_${newProfile.name}`, JSON.stringify(defaultState));

    // Reset inputs
    setNewProfileName('');
    setNewProfileAge('');
    setSelectedAvatar('🌸');
    setNewProfilePassword('');
    setNewProfileConfirmPassword('');
  };

  // Select existing profile handler
  const handleSelectProfile = (profile: UserProfile) => {
    setProfileToVerify(profile);
    setEnteredPasscode('');
    setPasscodeError('');
    setShowPasscodeValue(false);
    setMigratingPasscode('');
    setMigratingConfirmPasscode('');
  };

  // Handle actual passcode submission (Unlock Account)
  const handleVerifyPasscode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!profileToVerify) return;

    if (enteredPasscode === profileToVerify.password) {
      // Success! Log in
      setCurrentProfile(profileToVerify);
      localStorage.setItem('ls_edu_current_profile', profileToVerify.name);
      setShowProfileSelector(false);
      loadUserProgress(profileToVerify.name);
      setOpenedChapter(null); // Reset opened chapter
      setProfileToVerify(null); // Close modal
      setEnteredPasscode('');
      setPasscodeError('');
    } else {
      setPasscodeError(currentLang === 'en' ? "Incorrect passcode. Please try again!" : "ভুল পাসকোড। আবার চেষ্টা করো!");
      setEnteredPasscode('');
    }
  };

  // Handle setting a password for an older profile (Migration setup)
  const handleSetupMigrationPasscode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileToVerify) return;

    if (!migratingPasscode || migratingPasscode.length < 4 || migratingPasscode.length > 6 || !/^\d+$/.test(migratingPasscode)) {
      alert(currentLang === 'en'
        ? "Passcode must be a 4 to 6 digit numeric code!"
        : "পাসকোডটি অবশ্যই ৪ থেকে ৬ সংখ্যার হতে হবে!"
      );
      return;
    }

    if (migratingPasscode !== migratingConfirmPasscode) {
      alert(currentLang === 'en'
        ? "Passcodes do not match!"
        : "পাসকোড দুটি মেলেনি!"
      );
      return;
    }

    // Save passcode back to this profile
    const updatedProfiles = profiles.map(p => {
      if (p.name === profileToVerify.name) {
        return { ...p, password: migratingPasscode };
      }
      return p;
    });

    setProfiles(updatedProfiles);
    localStorage.setItem('ls_edu_profiles', JSON.stringify(updatedProfiles));

    // Now log in!
    const updatedProfile = { ...profileToVerify, password: migratingPasscode };
    setCurrentProfile(updatedProfile);
    localStorage.setItem('ls_edu_current_profile', updatedProfile.name);
    setShowProfileSelector(false);
    loadUserProgress(updatedProfile.name);
    setOpenedChapter(null);
    setProfileToVerify(null);
    setMigratingPasscode('');
    setMigratingConfirmPasscode('');
  };

  // Sign out / Switch Profile handler
  const handleSignOut = () => {
    setCurrentProfile(null);
    localStorage.removeItem('ls_edu_current_profile');
    setShowProfileSelector(true);
  };

  // Mark Chapter as Completed
  const completeChapter = (chapterId: number) => {
    if (!currentProfile) return;

    const completed = [...progress.completedChapters];
    if (!completed.includes(chapterId)) {
      completed.push(chapterId);
    }

    // Reward with 15 Stars for completing a lesson!
    const updatedProgress = {
      ...progress,
      completedChapters: completed,
      starPoints: progress.starPoints + 15
    };

    saveUserProgress(updatedProgress);
  };

  // Reset chapter progress (for self repeating)
  const resetChapterCompletion = (chapterId: number) => {
    if (!currentProfile) return;

    const completed = progress.completedChapters.filter(id => id !== chapterId);
    const updatedProgress = {
      ...progress,
      completedChapters: completed
    };

    saveUserProgress(updatedProgress);
  };

  // QUIZ STATE - Answers selections
  const [selectedQuizAnswers, setSelectedQuizAnswers] = useState<Record<number, number>>({});
  const [currentQuizScore, setCurrentQuizScore] = useState<{
    submitted: boolean;
    score: number;
    total: number;
    action: string;
  } | null>(null);

  const selectAnswer = (questionId: number, optionIndex: number) => {
    setSelectedQuizAnswers(prev => ({
      ...prev,
      [questionId]: optionIndex
    }));
  };

  // Submit Quiz for any quiz key (Phase or Chapter)
  const handleSubmitQuiz = (quizKey: string, customQuestions?: QuizQuestion[]) => {
    if (!currentProfile) return;

    let relevantQuestions: QuizQuestion[] = [];
    if (customQuestions && customQuestions.length > 0) {
      relevantQuestions = customQuestions;
    } else if (quizKey === 'blockA') {
      relevantQuestions = quizQuestions.filter(q => q.chapterId >= 1 && q.chapterId <= 5);
    } else if (quizKey === 'blockB') {
      relevantQuestions = quizQuestions.filter(q => q.chapterId >= 6 && q.chapterId <= 10);
    } else if (quizKey.startsWith('phase_')) {
      const pNum = parseInt(quizKey.replace('phase_', ''), 10);
      relevantQuestions = quizQuestions.filter(q => {
        const ch = chapters.find(c => c.id === q.chapterId);
        return ch?.phase === pNum;
      });
    } else if (quizKey.startsWith('ch_')) {
      const chNum = parseInt(quizKey.replace('ch_', ''), 10);
      relevantQuestions = quizQuestions.filter(q => q.chapterId === chNum);
    } else {
      relevantQuestions = quizQuestions.slice(0, 10);
    }

    if (relevantQuestions.length === 0) return;

    // Verify all answered
    const unanswered = relevantQuestions.filter(q => selectedQuizAnswers[q.id] === undefined);
    if (unanswered.length > 0) {
      alert(currentLang === 'en' 
        ? `Please answer all ${relevantQuestions.length} questions in this quiz before submitting!`
        : `অনুগ্রহ করে জমা দেওয়ার আগে কুইজের সবকটি ${toBanglaNumber(relevantQuestions.length)}টি প্রশ্নের উত্তর দাও!`
      );
      return;
    }

    // Compute score
    let score = 0;
    relevantQuestions.forEach(q => {
      if (selectedQuizAnswers[q.id] === q.correctAnswerIndex) {
        score += 1;
      }
    });

    const total = relevantQuestions.length;
    const percentage = Math.round((score / total) * 100);

    // Provide customized status advice
    let action = "";
    if (percentage === 100) {
      action = currentLang === 'en'
        ? `Superb! A perfect ${score}/${total} score! You fully mastered these life skill concepts. You are a true champion!`
        : `অসাধারণ! নিখুঁত ${score}/${total} স্কোর! তুমি খুব সুন্দরভাবে এই বিষয়গুলো বুঝতে পেরেছ। তুমি একজন সত্যিকারের চ্যাম্পিয়ন!`;
    } else if (percentage >= 60) {
      action = currentLang === 'en'
        ? `Good attempt! You scored ${score}/${total} (${percentage}%). You have a solid grasp. Re-read sections you had doubts about to reach 100%!`
        : `চমৎকার চেষ্টা! তুমি ${total} এর মধ্যে ${score} (${percentage}%) পেয়েছ। তোমার ভালো বোঝাপড়া তৈরি হয়েছে!`;
    } else {
      action = currentLang === 'en'
        ? `You got ${score}/${total}. Learning takes patience! Please review the chapter content and try again.`
        : `তুমি ${total} এর মধ্যে ${score} পেয়েছ। শেখার জন্য ধৈর্য প্রয়োজন! পাঠটি আরেকবার পড়ে নিয়ে আবার চেষ্টা করো।`;
    }

    // Save score in local state
    const newScores = {
      ...progress.quizScores,
      [quizKey]: { score, total, recommendedAction: { en: action, bn: action } }
    };

    const newQuizAnswers = {
      ...progress.quizAnswers,
      ...selectedQuizAnswers
    };

    // If chapter quiz, automatically complete the chapter!
    let completed = [...progress.completedChapters];
    if (quizKey.startsWith('ch_')) {
      const chId = parseInt(quizKey.replace('ch_', ''), 10);
      if (!completed.includes(chId)) {
        completed.push(chId);
      }
    }

    // Reward with star points (10 per correct answer!)
    const updatedProgress: ProgressState = {
      ...progress,
      completedChapters: completed,
      quizAnswers: newQuizAnswers,
      quizScores: newScores,
      starPoints: progress.starPoints + (score * 10)
    };

    saveUserProgress(updatedProgress);

    setCurrentQuizScore({
      submitted: true,
      score,
      total,
      action
    });
  };

  const handleResetQuiz = (quizKey: string, customQuestions?: QuizQuestion[]) => {
    if (!currentProfile) return;

    let relevantQuestions: QuizQuestion[] = [];
    if (customQuestions && customQuestions.length > 0) {
      relevantQuestions = customQuestions;
    } else if (quizKey === 'blockA') {
      relevantQuestions = quizQuestions.filter(q => q.chapterId >= 1 && q.chapterId <= 5);
    } else if (quizKey === 'blockB') {
      relevantQuestions = quizQuestions.filter(q => q.chapterId >= 6 && q.chapterId <= 10);
    } else if (quizKey.startsWith('phase_')) {
      const pNum = parseInt(quizKey.replace('phase_', ''), 10);
      relevantQuestions = quizQuestions.filter(q => {
        const ch = chapters.find(c => c.id === q.chapterId);
        return ch?.phase === pNum;
      });
    } else if (quizKey.startsWith('ch_')) {
      const chNum = parseInt(quizKey.replace('ch_', ''), 10);
      relevantQuestions = quizQuestions.filter(q => q.chapterId === chNum);
    }

    const updatedAnswers = { ...selectedQuizAnswers };
    relevantQuestions.forEach(q => {
      delete updatedAnswers[q.id];
    });
    setSelectedQuizAnswers(updatedAnswers);

    const updatedScores = { ...progress.quizScores };
    delete updatedScores[quizKey];

    const updatedProgress = {
      ...progress,
      quizScores: updatedScores
    };
    saveUserProgress(updatedProgress);
    setCurrentQuizScore(null);
  };

  // Helper to check what Chapter is unlocked next (Resume point)
  const getNextRecommendedChapter = () => {
    if (chapters.length === 0 || progress.completedChapters.length >= chapters.length) return null;
    
    // Find first unfinished chapter in order
    for (const ch of chapters) {
      if (!progress.completedChapters.includes(ch.id)) {
        return ch;
      }
    }
    return null;
  };

  const recommendedChapter = getNextRecommendedChapter();

  // STREAK AND STAGE DECORATION
  const handleRewardStarsFromTimer = (stars: number, durationMinutes: number) => {
    saveUserProgress({
      ...progress,
      starPoints: progress.starPoints + stars,
      timerMinutesCount: progress.timerMinutesCount + durationMinutes
    });
  };

  // ADD JOURNAL ENTRY HANDLER
  const handleAddNote = (newEntry: Omit<Note, 'id' | 'date'>) => {
    const entry: Note = {
      ...newEntry,
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toLocaleDateString()
    };
    saveUserProgress({
      ...progress,
      notes: [entry, ...progress.notes]
    });
  };

  const handleDeleteNote = (id: string) => {
    saveUserProgress({
      ...progress,
      notes: progress.notes.filter(n => n.id !== id)
    });
  };

  // ADD BUDGET TRANSACTION HANDLER
  const handleAddTransaction = (newTx: Omit<BudgetItem, 'id'>) => {
    const tx: BudgetItem = {
      ...newTx,
      id: Math.random().toString(36).substr(2, 9)
    };
    saveUserProgress({
      ...progress,
      budget: [tx, ...progress.budget]
    });
  };

  const handleDeleteTransaction = (id: string) => {
    saveUserProgress({
      ...progress,
      budget: progress.budget.filter(b => b.id !== id)
    });
  };

  // SAVE DILEMMA TREE MAP HANDLER
  const handleSaveTree = (newTree: Omit<DecisionTree, 'id' | 'timestamp'>) => {
    const tree: DecisionTree = {
      ...newTree,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleDateString()
    };
    saveUserProgress({
      ...progress,
      decisions: [tree, ...progress.decisions]
    });
  };

  const handleDeleteTree = (id: string) => {
    saveUserProgress({
      ...progress,
      decisions: progress.decisions.filter(d => d.id !== id)
    });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col justify-between">
      
      {/* PASSCODE LOCK OVERLAY SYSTEM */}
      {profileToVerify && (
        <div className="fixed inset-0 bg-indigo-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white rounded-3xl border border-slate-100 shadow-2xl p-6 md:p-8 space-y-6 animate-scaleIn text-center">
            
            <div className="flex justify-center">
              {renderAvatar(profileToVerify.avatar, "w-20 h-20 text-6xl flex items-center justify-center")}
            </div>
            
            <div>
              <h2 className="text-xl font-extrabold text-indigo-950">
                {currentLang === 'en' ? `Unlock Account: ${profileToVerify.name}` : `অ্যাকাউন্ট আনলক করো: ${profileToVerify.name}`}
              </h2>
              <p className="text-[11px] text-slate-500 font-extrabold uppercase tracking-widest mt-1">
                {currentLang === 'en' ? "Privacy & Diary Lock" : "ব্যক্তিগত ডায়েরি লক"}
              </p>
            </div>

            {/* Check if profile has a password, if not, present the Migration Setup layout! */}
            {!profileToVerify.password ? (
              <form onSubmit={handleSetupMigrationPasscode} className="space-y-4 text-left">
                <div className="bg-indigo-50 p-3.5 rounded-2xl border border-indigo-100 text-xs text-indigo-900 leading-relaxed font-semibold">
                  🛡️ {currentLang === 'en' 
                    ? "To protect your diary and health notes, please set a new 4-6 digit numeric passcode for your profile:" 
                    : "তোমার ডায়েরি ও স্বাস্থ্যের তথ্যের সুরক্ষার জন্য, তোমার প্রোফাইলে একটি নতুন ৪-৬ সংখ্যার পাসকোড সেট করো:"}
                </div>
                
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {currentLang === 'en' ? "Choose passcode (4-6 digits)" : "পাসকোড নির্বাচন করো (৪-৬ সংখ্যা):"}
                    </label>
                    <input
                      type="password"
                      pattern="[0-9]{4,6}"
                      maxLength={6}
                      required
                      value={migratingPasscode}
                      onChange={(e) => setMigratingPasscode(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 1234"
                      className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-bold font-mono tracking-widest text-center"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {currentLang === 'en' ? "Confirm passcode" : "পাসকোডটি নিশ্চিত করো:"}
                    </label>
                    <input
                      type="password"
                      pattern="[0-9]{4,6}"
                      maxLength={6}
                      required
                      value={migratingConfirmPasscode}
                      onChange={(e) => setMigratingConfirmPasscode(e.target.value.replace(/\D/g, ''))}
                      placeholder="Re-enter passcode..."
                      className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-bold font-mono tracking-widest text-center"
                    />
                  </div>
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setProfileToVerify(null)}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs rounded-xl transition-all cursor-pointer"
                  >
                    {currentLang === 'en' ? "Cancel" : "বাতিল"}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer shadow-md"
                  >
                    {currentLang === 'en' ? "Set & Enter 🚀" : "সেট করে প্রবেশ করো 🚀"}
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleVerifyPasscode} className="space-y-4">
                
                <div className="relative">
                  <input
                    type={showPasscodeValue ? "text" : "password"}
                    pattern="[0-9]{4,6}"
                    maxLength={6}
                    required
                    autoFocus
                    value={enteredPasscode}
                    onChange={(e) => {
                      setPasscodeError('');
                      setEnteredPasscode(e.target.value.replace(/\D/g, ''));
                    }}
                    placeholder={currentLang === 'en' ? "••••••" : "••••••"}
                    className="w-full text-2xl p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-black font-mono tracking-widest text-center"
                  />
                  
                  <button
                    type="button"
                    onClick={() => setShowPasscodeValue(!showPasscodeValue)}
                    className="absolute right-3 top-3.5 text-xs font-bold text-indigo-600 hover:text-indigo-800 focus:outline-none"
                  >
                    {showPasscodeValue ? (currentLang === 'en' ? "Hide" : "লুকান") : (currentLang === 'en' ? "Show" : "দেখান")}
                  </button>
                </div>

                {passcodeError && (
                  <p className="text-xs text-red-600 font-bold animate-pulse">
                    ⚠️ {passcodeError}
                  </p>
                )}

                {/* Mobile Friendly Custom On-screen Numeric Keypad */}
                <div className="grid grid-cols-3 gap-2 pt-2">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => {
                        setPasscodeError('');
                        if (enteredPasscode.length < 6) {
                          setEnteredPasscode(prev => prev + num);
                        }
                      }}
                      className="py-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl font-extrabold text-lg text-indigo-950 active:bg-indigo-50 transition-all cursor-pointer"
                    >
                      {num}
                    </button>
                  ))}
                  <button
                    type="button"
                    onClick={() => setEnteredPasscode('')}
                    className="py-3 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-bold text-xs flex items-center justify-center cursor-pointer"
                  >
                    {currentLang === 'en' ? "Clear" : "মুছুন"}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setPasscodeError('');
                      if (enteredPasscode.length < 6) {
                        setEnteredPasscode(prev => prev + '0');
                      }
                    }}
                    className="py-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl font-extrabold text-lg text-indigo-950 active:bg-indigo-50 transition-all cursor-pointer"
                  >
                    0
                  </button>
                  <button
                    type="button"
                    onClick={() => setEnteredPasscode(prev => prev.slice(0, -1))}
                    className="py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-sm flex items-center justify-center cursor-pointer"
                  >
                    ⌫
                  </button>
                </div>

                <div className="flex gap-2.5 pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setProfileToVerify(null)}
                    className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs rounded-xl transition-all cursor-pointer"
                  >
                    {currentLang === 'en' ? "Back to Profiles" : "তালিকায় ফেরো"}
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer shadow-md hover:shadow-indigo-100"
                  >
                    {currentLang === 'en' ? "Unlock & Enter 🔓" : "আনলক করে প্রবেশ করো 🔓"}
                  </button>
                </div>

              </form>
            )}

          </div>
        </div>
      )}

      {/* INACTIVITY TRACKER PROMPT (Are you still learning?) */}
      {showInactivityPrompt && (
        <div className="fixed inset-0 z-50 bg-indigo-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="max-w-md w-full bg-white rounded-3xl border border-slate-100 shadow-2xl p-6 md:p-8 space-y-5 animate-scaleIn text-center">
            <div className="w-16 h-16 mx-auto rounded-full bg-amber-50 border border-amber-200 flex items-center justify-center text-4xl shadow-inner animate-bounce">
              ⏳
            </div>
            
            <div className="space-y-1.5">
              <h2 className="text-xl font-black text-indigo-950">
                {currentLang === 'en' ? "Are you still learning?" : "তুমি কি এখনও পাঠটি পড়ছ?"}
              </h2>
              <p className="text-xs text-slate-600 leading-relaxed font-medium">
                {currentLang === 'en'
                  ? "We noticed no screen interactions for 2 minutes. We track genuine learning time to help your study focus!"
                  : "আমরা ২ মিনিট কোনো স্পর্শ বা ক্রিয়া দেখতে পাইনি। আমরা আসল পড়ার সময় ট্র্যাক করছি যাতে তোমার সময় নষ্ট না হয়!"}
              </p>
            </div>

            <div className="bg-red-50 border border-red-200 py-2 px-4 rounded-xl inline-block">
              <span className="text-xs font-mono font-black text-red-600">
                {currentLang === 'en' 
                  ? `Pausing active timer in ${inactivityCountdown} seconds...` 
                  : `${inactivityCountdown} সেকেন্ডে সক্রিয় টাইমার বন্ধ হবে...`}
              </span>
            </div>

            <button
              type="button"
              onClick={handleResumeActivity}
              className="w-full py-3.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm rounded-2xl shadow-lg shadow-indigo-200 transition-all cursor-pointer"
            >
              {currentLang === 'en' ? "Yes, I'm Still Learning! 🌸" : "হ্যাঁ, আমি এখনও পড়ছি! 🌸"}
            </button>
          </div>
        </div>
      )}

      {/* GOOGLE ONBOARDING PROFILE FORM MODAL */}
      {showGoogleModal && (
        <div className="fixed inset-0 z-50 bg-indigo-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="max-w-lg w-full bg-white rounded-3xl border border-slate-100 shadow-2xl p-6 md:p-8 space-y-6 animate-scaleIn">
            
            <div className="flex items-center justify-between border-b pb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-white border border-slate-200 flex items-center justify-center shadow-xs">
                  <svg className="w-6 h-6" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                </div>
                <div>
                  <h2 className="text-lg font-black text-indigo-950 leading-tight">
                    {currentLang === 'en' ? "Google Profile Onboarding" : "গুগল অ্যাকাউন্ট প্রোফাইল অনবোর্ডিং"}
                  </h2>
                  <p className="text-xs text-slate-500 font-medium">
                    {currentLang === 'en' ? "First-time Google Sign-In setup" : "প্রথমবারের গুগল অ্যাকাউন্ট সেটআপ"}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGoogleModal(false)}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Google Identity pill */}
            <div className="bg-indigo-50/70 border border-indigo-100 rounded-2xl p-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-pink-500 to-indigo-600 text-white font-black text-sm flex items-center justify-center shadow-xs">
                  {googleName ? googleName.charAt(0).toUpperCase() : 'G'}
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">{googleEmail}</div>
                  <div className="text-[10px] text-emerald-700 font-semibold flex items-center gap-1">
                    <span>✓</span> {currentLang === 'en' ? "Verified Google Account" : "যাচাইকৃত গুগল অ্যাকাউন্ট"}
                  </div>
                </div>
              </div>
              <span className="text-xs font-mono font-bold bg-white text-indigo-700 px-2.5 py-1 rounded-lg border border-indigo-100">
                ☁️ Cloud Sync
              </span>
            </div>

            {googleError && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-xs font-bold p-3 rounded-xl animate-shake">
                ⚠️ {googleError}
              </div>
            )}

            <form onSubmit={handleCompleteGoogleOnboarding} className="space-y-4">
              {/* Field 1: Name (prefilled, editable) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {currentLang === 'en' ? "Your Name (Pre-filled from Google):" : "তোমার নাম (গুগল থেকে নেওয়া):"}
                </label>
                <input
                  type="text"
                  required
                  value={googleName}
                  onChange={(e) => setGoogleName(e.target.value)}
                  placeholder={currentLang === 'en' ? "Enter your name" : "নাম লিখুন"}
                  className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-semibold"
                />
              </div>

              {/* Field 2: Age (Adolescent 10 to 19) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {currentLang === 'en' ? "Your Age (Target: 10 - 19 years):" : "তোমার বয়স (১০ - ১৯ বছর):"}
                </label>
                <input
                  type="number"
                  min="10"
                  max="19"
                  required
                  value={googleAge}
                  onChange={(e) => setGoogleAge(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="15"
                  className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-semibold"
                />
              </div>

              {/* Field 3: 4-digit App PIN & Field 4: Confirm PIN */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {currentLang === 'en' ? "Set 4-Digit Security PIN:" : "৪ সংখ্যার গোপন পিন দিন:"}
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    pattern="[0-9]{4}"
                    required
                    value={googlePin}
                    onChange={(e) => setGooglePin(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••"
                    className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-mono tracking-widest text-center font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {currentLang === 'en' ? "Confirm 4-Digit PIN:" : "পিন নিশ্চিত করুন:"}
                  </label>
                  <input
                    type="password"
                    maxLength={4}
                    pattern="[0-9]{4}"
                    required
                    value={googleConfirmPin}
                    onChange={(e) => setGoogleConfirmPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••"
                    className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-mono tracking-widest text-center font-bold"
                  />
                </div>
              </div>

              <p className="text-[11px] text-slate-500 leading-normal">
                🔒 {currentLang === 'en'
                  ? "Your 4-digit PIN secures your personal self-care notes and private diary on this device."
                  : "এই ৪ সংখ্যার পিনটি তোমার ব্যক্তিগত স্বাস্থ্য নোট ও ডায়েরি এই ফোনে সুরক্ষিত রাখবে।"}
              </p>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowGoogleModal(false)}
                  className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                >
                  {currentLang === 'en' ? "Cancel" : "বাতিল"}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-3 bg-gradient-to-r from-pink-600 to-indigo-600 hover:from-pink-700 hover:to-indigo-700 text-white font-black text-xs rounded-xl shadow-md cursor-pointer"
                >
                  {currentLang === 'en' ? "Complete Profile & Sync 🚀" : "প্রোফাইল সম্পন্ন করো ও সিঙ্ক করো 🚀"}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}
      
      {/* 1. WELCOME / PROFILE SWITCHER DIALOG SCREEN */}
      {showProfileSelector && (
        <div id="profile-selection-layer" className="flex-1 flex flex-col items-center justify-center p-4 md:p-8 bg-gradient-to-tr from-indigo-50/50 via-purple-50/50 to-pink-50/50">
          
          <div className="max-w-xl w-full bg-white rounded-3xl border border-slate-100 shadow-2xl overflow-hidden p-6 md:p-8 space-y-8 animate-fadeIn">
            
            {/* Header branding */}
            <div className="text-center space-y-3 flex flex-col items-center">
              <img 
                src={shokhiLogo} 
                alt="Shokhi Logo" 
                className="w-36 h-36 md:w-44 md:h-44 object-contain mb-1 filter drop-shadow-sm select-none" 
              />

              <h1 id="selection-heading" className="text-4xl md:text-5xl font-black text-indigo-950 tracking-tight leading-none bg-gradient-to-r from-pink-500 to-indigo-600 bg-clip-text text-transparent">
                {currentLang === 'en' ? "SHOKHI" : "সখী"}
              </h1>
              
              <div className="text-xs font-extrabold text-indigo-700 bg-indigo-50 border border-indigo-100 py-1 px-4 rounded-full uppercase tracking-wider font-sans">
                {currentLang === 'en' ? "Adolescent Girls Life Skills Academy" : "কিশোরী জীবনশৈলী শিক্ষা একাডেমী"}
              </div>
              
              <p className="text-xs text-slate-600 leading-relaxed font-semibold max-w-md">
                {currentLang === 'en' 
                  ? "Welcome to Shokhi! A safe space to grow, understand body health, learn positive communication, manage emotions, and build your future goals."
                  : "সখীতে স্বাগতম! একটি সুরক্ষিত প্ল্যাটফর্ম যা তোমার শারীরিক যত্ন, ইতিবাচক যোগাযোগ, ও উজ্জ্বল ভবিষ্যৎ গড়তে সাহায্য করবে।"
                }
              </p>

              <div className="text-[10px] text-indigo-900 bg-indigo-50 border border-indigo-100 py-1.5 px-4 rounded-xl font-bold font-mono">
                {currentLang === 'en' ? "Created & Managed by Nilanjan Majumdar" : "নির্মাণ ও পরিচালনায়: নীলাঞ্জন মজুমদার"}
              </div>
            </div>

            {/* Language toggle at setup */}
            <div className="flex justify-center gap-2 pb-1">
              <button
                type="button"
                onClick={() => setCurrentLang('en')}
                className={`py-1.5 px-4 rounded-xl text-xs font-black cursor-pointer transition-all border ${
                  currentLang === 'en' ? 'bg-indigo-600 text-white border-indigo-700' : 'bg-slate-100 text-slate-700'
                }`}
              >
                English Version
              </button>
              <button
                type="button"
                onClick={() => setCurrentLang('bn')}
                className={`py-1.5 px-4 rounded-xl text-xs font-black cursor-pointer transition-all border ${
                  currentLang === 'bn' ? 'bg-indigo-600 text-white border-indigo-700' : 'bg-slate-100 text-slate-700'
                }`}
              >
                বাংলা সংস্করণ
              </button>
            </div>

            {/* ⭐️ GOOGLE SIGN IN & CLOUD SYNC HERO CARD ⭐️ */}
            <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-pink-600 p-0.5 rounded-3xl shadow-xl">
              <div className="bg-white rounded-[22px] p-5 md:p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-white border border-slate-200 flex items-center justify-center shadow-xs">
                      <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-slate-900 leading-tight">
                        {currentLang === 'en' ? "Google Sign-In & Cloud Sync" : "গুগল সাইন-ইন ও ক্লাউড সিঙ্ক"}
                      </h3>
                      <p className="text-[11px] text-slate-500 font-medium">
                        {currentLang === 'en' ? "Safe Cloud Backup • Restore on any device" : "নিরাপদ ক্লাউড ব্যাকআপ • যেকোনো ডিভাইসে রিস্টোর"}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] font-black tracking-wide uppercase px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {currentLang === 'en' ? "Recommended" : "সুপারিশকৃত"}
                  </span>
                </div>

                <p className="text-xs text-slate-600 leading-relaxed font-medium">
                  {currentLang === 'en'
                    ? "Sign in with your Google Account to save all completed chapters, quiz scores, and earned badges safely to the cloud. If you switch phones or reinstall, everything is automatically restored!"
                    : "গুগল অ্যাকাউন্ট দিয়ে সাইন-ইন করুন যাতে তোমার অধ্যায় সমাপ্তি, কুইজের পয়েন্ট ও অর্জিত মেডেল ক্লাউডে নিরাপদ থাকে। ফোন পাল্টালেও সবকিছু আবার ফিরে পাবে!"}
                </p>

                {/* Big Primary Google Sign-In Button */}
                <button
                  type="button"
                  id="btn-google-sign-in"
                  onClick={handleOpenGoogleSignIn}
                  className="w-full py-3.5 px-4 bg-white hover:bg-slate-50 active:bg-slate-100 border-2 border-indigo-200 hover:border-indigo-500 rounded-2xl flex items-center justify-center gap-3 font-extrabold text-slate-800 text-sm shadow-md hover:shadow-lg transition-all cursor-pointer group"
                >
                  <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                  </svg>
                  <span className="text-indigo-950 group-hover:text-indigo-600 transition-colors font-black">
                    {currentLang === 'en' ? "Sign in with Google" : "গুগল অ্যাকাউন্ট দিয়ে সাইন ইন করুন"}
                  </span>
                </button>
              </div>
            </div>

            {/* Profiles lists (if any exist) */}
            {profiles.length > 0 && (
              <div id="existing-profiles-grid" className="space-y-3">
                <h2 className="text-xs font-bold text-slate-700 tracking-wider uppercase border-b pb-1">
                  {currentLang === 'en' ? "Saved Accounts on this Device:" : "এই ডিভাইসে সংরক্ষিত অ্যাকাউন্টসমূহ:"}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {profiles.map((prof) => (
                    <button
                      key={prof.name}
                      onClick={() => handleSelectProfile(prof)}
                      className="flex items-center p-3 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition-all hover:border-slate-300 text-left cursor-pointer group"
                    >
                      {renderAvatar(prof.avatar, "w-10 h-10 text-3xl mr-3 transform group-hover:scale-110 transition-transform duration-200 flex items-center justify-center shrink-0")}
                      <div className="overflow-hidden flex-1">
                        <div className="flex items-center gap-1.5">
                          <div className="font-bold text-slate-900 text-sm truncate">{prof.name}</div>
                          {prof.isGoogleAccount && (
                            <span className="text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded font-bold font-mono">
                              G
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                          <span>🔐</span>
                          <span>{currentLang === 'en' ? `Age: ${prof.age}` : `বয়স: ${prof.age}`}</span>
                          {prof.cloudSynced && <span className="text-emerald-600 font-sans font-bold">• ☁️ Synced</span>}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Offline Guest Profile Accordion Toggle */}
            <div className="pt-2 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setShowOfflineForm(!showOfflineForm)}
                className="w-full py-2.5 px-3 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 flex items-center justify-between cursor-pointer transition-colors"
              >
                <span className="flex items-center gap-1.5">
                  <PlusCircle className="w-4 h-4 text-slate-500" />
                  {currentLang === 'en' ? "Or Register an Offline Guest Profile (No Google)" : "অথবা ইন্টারনেট ছাড়া অফলাইন প্রোফাইল খুলুন"}
                </span>
                <span className="text-slate-400 font-mono">{showOfflineForm ? "▲" : "▼"}</span>
              </button>
            </div>

            {/* Profile Creation Form (Collapsed or Visible based on showOfflineForm) */}
            {showOfflineForm && (
            <form onSubmit={handleCreateProfile} id="create-profile-form" className="space-y-4 pt-2">
              <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
                <PlusCircle className="w-4 h-4 text-indigo-600" />
                {currentLang === 'en' ? "Register a New Local Offline Profile" : "খাতায় নতুন অফলাইন শিক্ষার্থীর নাম লেখাও"}
              </h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {currentLang === 'en' ? "What is your name? (e.g., Aarti, Sneha)" : "তোমার ডাকনাম কী? (যেমন: আরতি, স্নেহা):"}
                  </label>
                  <input
                    id="input-new-name"
                    type="text"
                    required
                    value={newProfileName}
                    onChange={(e) => setNewProfileName(e.target.value)}
                    placeholder={currentLang === 'en' ? "Enter your name..." : "নাম লেখো..."}
                    className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-medium"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {currentLang === 'en' ? "How old are you? (Enter any age)" : "তোমার বয়স কত? (যেকোনো বয়স লিখুন):"}
                  </label>
                  <input
                    id="input-new-age"
                    type="number"
                    min="1"
                    max="120"
                    required
                    value={newProfileAge}
                    onChange={(e) => {
                      const val = e.target.value;
                      setNewProfileAge(val === '' ? '' : Number(val));
                    }}
                    placeholder={currentLang === 'en' ? "E.g. 15, 22" : "যেমন: ১৫, ২২"}
                    className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-medium bg-white"
                  />
                </div>
              </div>

              {/* Passcode setup fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {currentLang === 'en' ? "Select a passcode (4-6 digits)" : "পাসকোড নির্বাচন করো (৪-৬ সংখ্যার):"}
                  </label>
                  <input
                    type="password"
                    pattern="[0-9]{4,6}"
                    maxLength={6}
                    required
                    value={newProfilePassword}
                    onChange={(e) => setNewProfilePassword(e.target.value.replace(/\D/g, ''))}
                    placeholder={currentLang === 'en' ? "E.g. 1234" : "যেমন: ১২৩৪"}
                    className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-medium font-mono tracking-widest"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {currentLang === 'en' ? "Confirm passcode" : "পাসকোডটি নিশ্চিত করো:"}
                  </label>
                  <input
                    type="password"
                    pattern="[0-9]{4,6}"
                    maxLength={6}
                    required
                    value={newProfileConfirmPassword}
                    onChange={(e) => setNewProfileConfirmPassword(e.target.value.replace(/\D/g, ''))}
                    placeholder={currentLang === 'en' ? "Re-enter passcode..." : "পাসকোড আবার লিখুন..."}
                    className="w-full text-sm p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-indigo-500 text-slate-950 font-medium font-mono tracking-widest"
                  />
                </div>
              </div>

              {/* Avatar Selector Section */}
              <div className="space-y-3">
                <div className="flex border-b border-slate-150">
                  <button
                    type="button"
                    onClick={() => { setUseCustomAvatar(false); stopCamera(); }}
                    className={`flex-1 pb-2 text-xs font-black border-b-2 text-center transition-all cursor-pointer ${
                      !useCustomAvatar 
                        ? 'border-indigo-600 text-indigo-600' 
                        : 'border-transparent text-slate-500 hover:text-indigo-500'
                    }`}
                  >
                    🌸 {currentLang === 'en' ? "Choose Badge Icon" : "পছন্দের ব্যাজ বেছে নাও"}
                  </button>
                  <button
                    type="button"
                    onClick={() => { setUseCustomAvatar(true); }}
                    className={`flex-1 pb-2 text-xs font-black border-b-2 text-center transition-all cursor-pointer ${
                      useCustomAvatar 
                        ? 'border-indigo-600 text-indigo-600' 
                        : 'border-transparent text-slate-500 hover:text-indigo-500'
                    }`}
                  >
                    📷 {currentLang === 'en' ? "Take Selfie / Photo" : "সেলফি তোলো / ছবি আপলোড"}
                  </button>
                </div>

                {!useCustomAvatar ? (
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700">
                      {currentLang === 'en' ? "Choose your profile avatar badge icon:" : "তোমার পছন্দের লোগোটি স্পর্শ করো:"}
                    </label>
                    <div className="grid grid-cols-4 sm:grid-cols-8 gap-2">
                      {AVATARS.map((av) => (
                        <button
                          key={av.emoji}
                          type="button"
                          onClick={() => { setSelectedAvatar(av.emoji); }}
                          className={`text-2xl p-2 rounded-xl transition-all border cursor-pointer ${
                            selectedAvatar === av.emoji && !useCustomAvatar
                              ? 'bg-indigo-100 border-indigo-400 scale-110 shadow-xs'
                              : 'bg-slate-50 border-transparent hover:bg-slate-100'
                          }`}
                          title={av.label}
                        >
                          {av.emoji}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 p-3 bg-slate-50 rounded-2xl border border-slate-200">
                    {customAvatarDataUrl ? (
                      <div className="flex flex-col items-center space-y-2">
                        <span className="text-[10px] text-indigo-600 font-extrabold uppercase">Preview:</span>
                        <img 
                          src={customAvatarDataUrl} 
                          className="w-24 h-24 rounded-full object-cover border-4 border-indigo-200 shadow-xs" 
                          alt="Selfie preview" 
                        />
                        <button
                          type="button"
                          onClick={() => { setCustomAvatarDataUrl(''); startCamera(); }}
                          className="py-1 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 text-[10px] font-extrabold rounded-lg border border-rose-100 cursor-pointer"
                        >
                          🔄 {currentLang === 'en' ? "Retake Selfie / Change Photo" : "আবার ছবি তোলো / পরিবর্তন করো"}
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {cameraActive ? (
                          <div className="flex flex-col items-center space-y-3">
                            <div className="relative w-48 h-48 rounded-2xl overflow-hidden border-2 border-indigo-500 bg-black shadow-inner flex items-center justify-center">
                              <video 
                                ref={videoRef} 
                                className="w-full h-full object-cover transform -scale-x-100" 
                                playsInline 
                                muted 
                              />
                            </div>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={captureSelfie}
                                className="py-2 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl shadow-xs cursor-pointer"
                              >
                                📸 {currentLang === 'en' ? "Capture Photo" : "ছবি তোলো"}
                              </button>
                              <button
                                type="button"
                                onClick={stopCamera}
                                className="py-2 px-3 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl cursor-pointer"
                              >
                                ❌ {currentLang === 'en' ? "Cancel" : "বাতিল"}
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-col sm:flex-row gap-3 justify-center items-center py-4">
                            <button
                              type="button"
                              onClick={startCamera}
                              className="py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-extrabold rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5"
                            >
                              📷 {currentLang === 'en' ? "Use Live Camera / Take Selfie" : "লাইভ ক্যামেরা দিয়ে সেলফি তোলো"}
                            </button>
                            <span className="text-slate-400 text-xs font-bold font-sans">
                              {currentLang === 'en' ? "or" : "অথবা"}
                            </span>
                            <label className="py-2.5 px-4 bg-white hover:bg-slate-50 text-indigo-950 text-xs font-extrabold rounded-xl border border-slate-300 cursor-pointer shadow-2xs flex items-center gap-1.5">
                              📁 {currentLang === 'en' ? "Upload Image File" : "ছবি আপলোড করো"}
                              <input 
                                type="file" 
                                accept="image/*" 
                                onChange={handleAvatarFileUpload} 
                                className="hidden" 
                              />
                            </label>
                          </div>
                        )}

                        {cameraError && (
                          <p className="text-[10px] text-rose-600 text-center font-bold">
                            ⚠️ {cameraError}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>

              <button
                id="btn-submit-profile"
                type="submit"
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-sm rounded-2xl cursor-pointer shadow-lg hover:shadow-indigo-200 transition-all text-center mt-2"
              >
                {currentLang === 'en' ? "Start My Study Journey offline! 🚀" : "ইন্টারনেট ছাড়া পড়াশোনা শুরু করো! 🚀"}
              </button>
            </form>
            )}

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 leading-normal flex gap-2">
              <span className="text-base select-none">💾</span>
              <span>
                <strong>{currentLang === 'en' ? "Strictly Offline & Private:" : "সম্পূর্ণ অফলাইন এবং ব্যক্তিগত:"}</strong>{' '}
                {currentLang === 'en'
                  ? "This information remains strictly stored on your own device. The data is saved offline via your browser's LocalStorage, preserving complete privacy."
                  : "তোমার সমস্ত তথ্য এবং পড়ার পরিধি কেবল তোমার নিজের ফোনেই সংরক্ষিত থাকবে, কেউ দেখতে পাবে না।"
                }
              </span>
            </div>

          </div>
        </div>
      )}

      {/* 2. THE MAIN APPLICATION IN-STUDY SCREEN */}
      {!showProfileSelector && currentProfile && (
        <div id="main-application" className="flex-1 flex flex-col">
          
          {/* Header Dashboard section */}
          <header className="bg-white border-b border-slate-200 shadow-3xs px-4 md:px-8 py-3 sticky top-0 z-10 animate-fadeIn">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
              
              {/* App Name in the Top Left corner */}
              <div id="header-logo-appname" className="flex items-center gap-2.5">
                <img 
                  src={shokhiLogo} 
                  alt="Shokhi Logo" 
                  className="w-11 h-11 object-contain rounded-xl shadow-xs select-none" 
                />
                <div>
                  <h1 className="text-base md:text-lg font-black text-indigo-950 flex items-center gap-1.5 leading-none tracking-tight">
                    SHOKHI <span className="text-xs text-indigo-600 font-extrabold font-sans">(সখী)</span>
                  </h1>
                  <p className="text-[10px] text-slate-500 font-bold leading-normal uppercase">
                    {currentLang === 'en' ? "Adolescent Girls Academy" : "কিশোরী জীবনশৈলী একাডেমী"}
                  </p>
                </div>
              </div>

              {/* Language + Stars Points + Accounts bar */}
              <div className="flex flex-wrap items-center justify-center gap-2.5">
                
                {/* Language Switcher pill */}
                <div className="bg-slate-100 p-0.5 rounded-lg flex border border-slate-200">
                  <button
                    onClick={() => setCurrentLang('en')}
                    className={`px-2 py-1 text-[10px] font-black rounded-md transition-all ${
                      currentLang === 'en' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    EN
                  </button>
                  <button
                    onClick={() => setCurrentLang('bn')}
                    className={`px-2 py-1 text-[10px] font-black rounded-md transition-all ${
                      currentLang === 'bn' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    বাংলা
                  </button>
                </div>

                {/* Positive Screen Time Tracker Button */}
                <button
                  onClick={() => setShowScreenTimeModal(true)}
                  className="bg-indigo-600 hover:bg-indigo-700 border border-indigo-700 px-3 py-1 rounded-xl flex items-center gap-1.5 text-xs font-black text-white cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-xs"
                  title={currentLang === 'en' ? "View App Usage Tracker" : "অ্যাপ ব্যবহারের হিসাব দেখো"}
                >
                  <span className="animate-pulse text-indigo-200 text-[10px]">⏳</span>
                  <span className="font-mono">
                    {currentLang === 'en' 
                      ? `${Math.floor(secondsToday / 60)}m spent` 
                      : `${toBanglaNumber(Math.floor(secondsToday / 60))} মিনিট`}
                  </span>
                </button>

                {/* Virtual Star Points Wallet */}
                <div className="bg-amber-50 border border-amber-200 px-3 py-1 rounded-xl flex items-center gap-1.5 text-xs font-black text-amber-900 animate-pulse">
                  <span>⭐</span>
                  <span className="font-mono">
                    {currentLang === 'en' 
                      ? `${progress.starPoints} Stars` 
                      : `${toBanglaNumber(progress.starPoints)} স্টার`}
                  </span>
                </div>

                {/* Google Cloud Synced Pill */}
                {currentProfile.isGoogleAccount && (
                  <div className="hidden sm:flex items-center gap-1.5 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-xl text-[10px] font-bold text-blue-900 shadow-2xs" title={currentProfile.googleEmail}>
                    <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                    </svg>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span>{currentLang === 'en' ? "Cloud Synced" : "ক্লাউড সিঙ্কড"}</span>
                  </div>
                )}

                {/* Profile Badge */}
                <div className="flex items-center gap-2 bg-indigo-50 px-3 py-1 rounded-xl border border-indigo-200/50">
                  {renderAvatar(currentProfile.avatar, "w-6 h-6 text-xl flex items-center justify-center shrink-0")}
                  <div className="text-left w-20 truncate">
                    <div id="header-name" className="text-xs font-bold text-indigo-950 truncate">
                      {currentProfile.name}
                    </div>
                    <div className="text-[9px] text-indigo-700 font-bold uppercase tracking-wider">
                      {currentLang === 'en' ? `Age ${currentProfile.age}` : `${currentProfile.age} বছর`}
                    </div>
                  </div>
                </div>

                {/* Account Actions */}
                <button
                  id="btn-sign-out"
                  onClick={handleSignOut}
                  className="p-1 px-2 bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 rounded-lg text-xs font-extrabold flex items-center gap-0.5 transition-colors cursor-pointer"
                >
                  <SwitchCamera className="w-3.5 h-3.5" />
                  <span>{currentLang === 'en' ? "Switch" : "বদলাও"}</span>
                </button>
              </div>

            </div>
          </header>

          {/* Inactivity Paused Banner */}
          {isSessionPaused && (
            <div 
              onClick={handleResumeActivity}
              className="bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold py-2 px-4 text-center cursor-pointer transition-colors flex items-center justify-center gap-2 shadow-inner"
            >
              <span>⏸️</span>
              <span>
                {currentLang === 'en' 
                  ? "Active study timer paused due to inactivity. Click anywhere on screen to resume learning!" 
                  : "নিষ্ক্রিয়তার কারণে পড়ার টাইমার স্থগিত রাখা হয়েছে। আবার চালিয়ে যেতে স্ক্রিনে চাপ দিন!"}
              </span>
            </div>
          )}

          {/* Core App Navigation Tabs */}
          <nav className="bg-indigo-950 text-white px-2 py-1 flex justify-center sticky top-[60px] z-10 shadow-md">
            <div className="max-w-7xl w-full flex overflow-x-auto scrollbar-none py-1 gap-1.5 justify-start md:justify-center">
              
              <button
                id="tab-btn-chapters"
                onClick={() => { setActiveTab('chapters'); setOpenedChapter(null); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'chapters' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? `Learn (${chapters.length} Lessons)` : `পড়াশোনা (${toBanglaNumber(chapters.length)}টি অধ্যায়)`}</span>
              </button>

              <button
                id="tab-btn-quizzes"
                onClick={() => { setActiveTab('quizzes'); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'quizzes' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? "My Quizzes" : "কুইজ পরীক্ষা"}</span>
              </button>

              <button
                id="tab-btn-tools"
                onClick={() => { setActiveTab('tools'); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'tools' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <Award className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? "My Self-Care & Tools 💎" : "আমার প্র্যাকটিস ও মেডেল 💎"}</span>
              </button>

              <button
                id="tab-btn-games"
                onClick={() => { setActiveTab('games'); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'games' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <Smile className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? "Relax Corner" : "মন ভালো করার কোণ"}</span>
              </button>

              <button
                id="tab-btn-health"
                onClick={() => { setActiveTab('health'); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'health' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? "My Body" : "আমার শরীর"}</span>
              </button>

              <button
                id="tab-btn-helpline"
                onClick={() => { setActiveTab('helpline'); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'helpline' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <Phone className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? "Helplines 📞" : "সাহায্য নম্বর 📞"}</span>
              </button>

              <button
                id="tab-btn-about"
                onClick={() => { setActiveTab('about'); }}
                className={`py-1.5 px-3 md:px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition-all text-center whitespace-nowrap cursor-pointer ${
                  activeTab === 'about' ? 'bg-white text-indigo-950 font-black shadow-xs' : 'text-indigo-100 hover:bg-indigo-900'
                }`}
              >
                <Info className="w-3.5 h-3.5" />
                <span>{currentLang === 'en' ? "About Us ℹ️" : "আমাদের পরিচিতি ℹ️"}</span>
              </button>

            </div>
          </nav>

          {/* MAIN PAGE BODY CONTENT */}
          <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">

            {/* TAB 1: CHAPTERS LEARNING */}
            {activeTab === 'chapters' && (
              <div id="tab-chapters-view" className="space-y-6 animate-fadeIn">
                
                {/* Recommended Resume Card */}
                {!openedChapter && recommendedChapter && (
                  <div id="resume-helper-bar" className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-4 rounded-2xl shadow-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div className="space-y-1">
                      <div className="text-xs uppercase font-extrabold tracking-widest text-emerald-100 flex items-center gap-1">
                        <BookOpenCheck className="w-4 h-4" /> 
                        {currentLang === 'en' ? "Recommended Next Study Lesson" : "পরবর্তী পড়ার অধ্যায় সুপারিশ:"}
                      </div>
                      <h3 className="text-base font-extrabold">
                        {currentLang === 'en' ? "Lesson" : "পাঠ"} {recommendedChapter.id}: {recommendedChapter.title[currentLang]}
                      </h3>
                      <p className="text-xs text-emerald-50/90 leading-normal max-w-xl">
                        {recommendedChapter.summary[currentLang]}
                      </p>
                    </div>
                    <button
                      id="btn-resume-auto"
                      onClick={() => setOpenedChapter(recommendedChapter)}
                      className="py-2.5 px-5 bg-white text-emerald-950 hover:bg-slate-100 font-extrabold text-xs rounded-xl shadow-xs transition-all transform active:scale-95 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <span>{currentLang === 'en' ? "Start Lesson" : "পড়া শুরু করো"} {recommendedChapter.id}</span>
                      <ChevronRight className="w-4 h-4 text-emerald-600" />
                    </button>
                  </div>
                )}

                {/* All Chapters Completed Celebration */}
                {!openedChapter && progress.completedChapters.length >= chapters.length && chapters.length > 0 && (
                  <div className="bg-gradient-to-r from-amber-500 to-rose-500 text-white p-5 rounded-2xl shadow-md text-center max-w-2xl mx-auto space-y-2 animate-bounce">
                    <span className="text-4xl">👑</span>
                    <h3 className="text-lg font-black">{currentLang === 'en' ? "All 21 Curriculum Chapters Finished!" : "সব ২১টি পাঠ সফলভাবে সমাপ্ত হয়েছে!"}</h3>
                    <p className="text-xs text-amber-50 leading-relaxed font-sans font-medium">
                      {currentLang === 'en'
                        ? `Congratulations, ${currentProfile.name}! You finished reading all ${chapters.length} chapters on Life Skills, emotional resilience, adolescent health, child marriage laws, and cyber safety. You are a true peer leader!`
                        : `সাবাশ, ${currentProfile.name}! তুমি সকল ${toBanglaNumber(chapters.length)}টি অধ্যায় সফলভাবে পড়ে ফেলেছ। তোমার ভবিষ্যৎ উজ্জ্বল হোক! নিচে দেওয়া নতুন পরীক্ষার কুইজ বা জমানোর ওয়ালেট পরীক্ষা করে দেখো।`
                      }
                    </p>
                  </div>
                )}

                {/* Main Chapter Viewer Popup / Details Frame */}
                {openedChapter ? (
                  <div id="chapter-reader-frame" className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden max-w-3xl mx-auto">
                    {/* Header */}
                    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 border-b border-indigo-150 flex justify-between items-start gap-4">
                      <div className="space-y-1">
                        <button
                          id="btn-back-to-list"
                          onClick={() => {
                            setOpenedChapter(null);
                            setOpenedChapterQuiz(false);
                          }}
                          className="px-3 py-1 text-xs font-bold text-indigo-700 hover:text-indigo-900 bg-indigo-100/50 hover:bg-indigo-100 rounded-lg flex items-center gap-1 transition-colors pointer-cursor"
                        >
                          ← {currentLang === 'en' ? "Back to Curriculum" : "সিলবাসের তালিকায় ফেরো"}
                        </button>
                        <div className="pt-3 flex items-center gap-2">
                          <span className="text-3xl animate-bounce" role="img">{openedChapter.emoji}</span>
                          <div>
                            <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-widest block font-mono">
                              {currentLang === 'en' ? "Chapter" : "অধ্যায়"} {openedChapter.id} • {openedChapter.phaseTitle ? `${currentLang === 'en' ? 'Phase' : 'পর্যায়'} ${openedChapter.phase || 1}: ${openedChapter.phaseTitle[currentLang]}` : (openedChapter.category === 'life-skills' ? (currentLang === 'en' ? '✨ Life Skill' : '✨ জীবনশৈলী') : (currentLang === 'en' ? '🩺 Health & Hygiene' : '🩺 শরীর ও স্বাস্থ্য'))}
                            </span>
                            <h2 className="text-md md:text-xl font-black text-slate-900 leading-snug">
                              {openedChapter.title[currentLang]}
                            </h2>
                          </div>
                        </div>
                      </div>
                      
                      {/* Completion Badge */}
                      {progress.completedChapters.includes(openedChapter.id) && (
                        <span className="bg-emerald-100 text-emerald-950 p-1.5 px-3 rounded-full text-[10px] font-extrabold flex items-center gap-1 shrink-0">
                          <Check className="w-3.5 h-3.5 text-emerald-700 font-bold" /> {currentLang === 'en' ? "Read & Awarded" : "সম্পন্ন ও পুরস্কৃত"}
                        </span>
                      )}
                    </div>

                    {/* Chapter Body Content */}
                    <div className="p-6 md:p-8 space-y-6 max-h-[60vh] overflow-y-auto font-sans leading-relaxed text-slate-800 text-sm md:text-base">
                      {openedChapter.content[currentLang].map((p, pIdx) => (
                        <p key={pIdx} className="leading-relaxed font-medium">
                          {p}
                        </p>
                      ))}

                      {/* Interactive Branching Dilemma Scenario (if present) */}
                      {openedChapter.branchingScenario && (
                        <div className="bg-gradient-to-tr from-purple-50 via-indigo-50 to-pink-50 border border-purple-200 rounded-3xl p-5 space-y-4 shadow-3xs">
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">🤔</span>
                            <div>
                              <h4 className="text-xs md:text-sm font-black text-purple-950 uppercase tracking-wider font-mono">
                                {currentLang === 'en' ? "Real-Life Decision Scenario: What Would You Do?" : "বাস্তব জীবনের সিদ্ধান্ত: তুমি হলে কী করতে?"}
                              </h4>
                              <p className="text-xs text-slate-700 font-medium mt-0.5">
                                {openedChapter.branchingScenario.scenario[currentLang]}
                              </p>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                            <button
                              onClick={() => setBranchingChoices(prev => ({ ...prev, [openedChapter.id]: 'A' }))}
                              className={`p-3.5 rounded-2xl text-left border text-xs font-bold transition-all cursor-pointer ${
                                branchingChoices[openedChapter.id] === 'A'
                                  ? 'bg-rose-100 border-rose-300 text-rose-950 shadow-xs ring-2 ring-rose-400/40'
                                  : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                              }`}
                            >
                              <div className="font-extrabold text-[11px] text-rose-700 uppercase mb-1">
                                {currentLang === 'en' ? "Option A" : "বিকল্প ক"}
                              </div>
                              <p>{openedChapter.branchingScenario.choiceA[currentLang]}</p>
                            </button>

                            <button
                              onClick={() => setBranchingChoices(prev => ({ ...prev, [openedChapter.id]: 'B' }))}
                              className={`p-3.5 rounded-2xl text-left border text-xs font-bold transition-all cursor-pointer ${
                                branchingChoices[openedChapter.id] === 'B'
                                  ? 'bg-emerald-100 border-emerald-300 text-emerald-950 shadow-xs ring-2 ring-emerald-400/40'
                                  : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                              }`}
                            >
                              <div className="font-extrabold text-[11px] text-emerald-700 uppercase mb-1">
                                {currentLang === 'en' ? "Option B (Empowering Choice)" : "বিকল্প খ (সচেতন সিদ্ধান্ত)"}
                              </div>
                              <p>{openedChapter.branchingScenario.choiceB[currentLang]}</p>
                            </button>
                          </div>

                          {/* Reveal Result based on Choice */}
                          {branchingChoices[openedChapter.id] && (
                            <div className={`p-4 rounded-2xl text-xs font-medium leading-relaxed animate-fadeIn ${
                              branchingChoices[openedChapter.id] === 'B'
                                ? 'bg-emerald-100/90 text-emerald-950 border border-emerald-200'
                                : 'bg-amber-100/90 text-amber-950 border border-amber-200'
                            }`}>
                              <strong className="block font-black mb-1">
                                {branchingChoices[openedChapter.id] === 'B' 
                                  ? (currentLang === 'en' ? '✨ Constructive Outcome:' : '✨ ইতিবাচক ফলফল:')
                                  : (currentLang === 'en' ? '⚠️ Cautionary Outcome:' : '⚠️ সতর্কতামূলক প্রভাব:')}
                              </strong>
                              {branchingChoices[openedChapter.id] === 'A'
                                ? openedChapter.branchingScenario.resultA[currentLang]
                                : openedChapter.branchingScenario.resultB[currentLang]}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Actionable Takeaways Checklist (if present) */}
                      {openedChapter.actionableTakeaways && (
                        <div className="bg-teal-50 border border-teal-200 rounded-2xl p-5 space-y-3">
                          <h4 className="text-xs md:text-sm font-black text-teal-950 flex items-center gap-1.5">
                            <span>🎯</span>
                            {currentLang === 'en' ? "Daily Life Habits & Action Items:" : "দৈনন্দিন জীবনের অভ্যাস ও করনীয় বিষয়:"}
                          </h4>
                          <ul className="space-y-2 text-xs text-teal-950 font-medium">
                            {openedChapter.actionableTakeaways[currentLang].map((item, idx) => (
                              <li key={idx} className="flex items-start gap-2">
                                <span className="text-emerald-600 font-bold shrink-0">✓</span>
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Key Takeaway Box */}
                      {openedChapter.keyTakeaway && (
                        <div className="bg-amber-50 border border-amber-100 rounded-2xl p-5 space-y-2">
                          <h4 className="text-xs md:text-sm font-black text-amber-900 flex items-center gap-1.5">
                            <Lightbulb className="w-5 h-5 text-amber-600" />
                            {currentLang === 'en' ? "Key Takeaway Message:" : "গুরুত্বপূর্ণ শিক্ষা বার্তা:"}
                          </h4>
                          <p className="text-xs md:text-sm font-bold text-amber-950 italic font-sans leading-relaxed">
                            "{openedChapter.keyTakeaway[currentLang]}"
                          </p>
                        </div>
                      )}

                      {/* Interactive End-of-Chapter Quiz Section */}
                      {(() => {
                        const chQuestions = quizQuestions.filter(q => q.chapterId === openedChapter.id);
                        if (chQuestions.length === 0) return null;
                        const quizKey = `ch_${openedChapter.id}`;
                        const scoreData = progress.quizScores[quizKey];

                        return (
                          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-indigo-200 rounded-3xl p-5 md:p-6 space-y-4">
                            <div className="flex justify-between items-center flex-wrap gap-2">
                              <div className="space-y-0.5">
                                <h4 className="text-xs md:text-sm font-black text-indigo-950 flex items-center gap-1.5">
                                  <span>📝</span>
                                  {currentLang === 'en'
                                    ? `Interactive Chapter Quiz (${chQuestions.length} Questions)`
                                    : `অধ্যায় মূল্যায়ন কুইজ (${toBanglaNumber(chQuestions.length)}টি প্রশ্ন)`}
                                </h4>
                                <p className="text-[11px] text-slate-600">
                                  {currentLang === 'en'
                                    ? "Complete the quiz with 100% to earn extra StarPoints and advance your profile!"
                                    : "সঠিক উত্তর দিয়ে অতিরিক্ত উপহার স্টার পয়েন্ট ও পদক অর্জন করো!"}
                                </p>
                              </div>
                              {scoreData && (
                                <span className="px-3 py-1 bg-emerald-100 text-emerald-900 text-xs font-black rounded-full">
                                  {currentLang === 'en' ? 'Score:' : 'স্কোর:'} {scoreData.score}/{scoreData.total}
                                </span>
                              )}
                            </div>

                            <BlockQuizWizard
                              blockType={quizKey}
                              title={`${currentLang === 'en' ? 'Chapter' : 'অধ্যায়'} ${openedChapter.id} ${currentLang === 'en' ? 'Quiz' : 'কুইজ'}`}
                              questions={chQuestions}
                              currentLang={currentLang}
                              selectedAnswers={selectedQuizAnswers}
                              selectAnswer={selectAnswer}
                              onSubmit={() => handleSubmitQuiz(quizKey, chQuestions)}
                              quizScore={scoreData}
                              onReset={() => handleResetQuiz(quizKey, chQuestions)}
                            />
                          </div>
                        );
                      })()}

                    </div>

                    {/* Footer Actions */}
                    <div className="bg-slate-50 p-6 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                      <button
                        onClick={() => {
                          setOpenedChapter(null);
                          setOpenedChapterQuiz(false);
                        }}
                        className="w-full sm:w-auto px-5 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl transition-all cursor-pointer"
                      >
                        {currentLang === 'en' ? "Close Chapter" : "অধ্যায় বন্ধ করো"}
                      </button>

                      {progress.completedChapters.includes(openedChapter.id) ? (
                        <button
                          onClick={() => resetChapterCompletion(openedChapter.id)}
                          className="w-full sm:w-auto px-6 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-black rounded-xl border border-rose-200 transition-all cursor-pointer"
                        >
                          🔄 {currentLang === 'en' ? "Reset & Re-read Lesson" : "পড়াটি রি-সেট করো"}
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            completeChapter(openedChapter.id);
                          }}
                          className="w-full sm:w-auto px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl shadow-md transform active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <span>🎉 {currentLang === 'en' ? "Mark as Completed (+15 ⭐)" : "পড়া শেষ ও ১৫ স্টার সংগ্রহ করো 🎉"}</span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {/* Curriculum Header & Admin Updater Bar */}
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-3xs">
                      <div>
                        <div className="flex items-center gap-2">
                          <h2 className="text-md md:text-lg font-extrabold text-slate-900 flex items-center gap-1.5">
                            <span>🎓</span>
                            {currentLang === 'en' 
                              ? `${chapters.length} Educational Life Skills Chapters` 
                              : `${toBanglaNumber(chapters.length)}টি জীবনশৈলী ও সুরক্ষার পাঠসমূহ`}
                          </h2>
                          <span className="bg-indigo-100 text-indigo-800 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full font-mono">
                            {currentLang === 'en' ? '6 Phases' : '৬টি পর্যায়'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 mt-0.5">
                          {currentLang === 'en'
                            ? "Complete sequential chapters and interactive quizzes to earn medals and develop life skills."
                            : "পর্যায়ক্রমে প্রতিটি অধ্যায় পড়ো ও কুইজ খেলে পদক ও পয়েন্ট অর্জন করো!"}
                        </p>
                      </div>

                      <div className="flex items-center gap-2.5 flex-wrap">
                        {/* Summary Ticks bar */}
                        <div className="text-xs font-mono font-bold bg-slate-100 border border-slate-200 text-slate-700 py-1.5 px-3 rounded-xl flex gap-1.5 font-sans">
                          {currentLang === 'en' ? "Progress:" : "অগ্রগতি:"}{' '}
                          <span className="text-indigo-700 font-extrabold">{progress.completedChapters.length} / {chapters.length}</span>
                        </div>
                      </div>
                    </div>

                    {/* Phase Navigation Filter Bar */}
                    <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
                      <button
                        onClick={() => setSelectedPhaseFilter('all')}
                        className={`py-1.5 px-3.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                          selectedPhaseFilter === 'all'
                            ? 'bg-indigo-600 text-white shadow-xs'
                            : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                        }`}
                      >
                        {currentLang === 'en' ? `All Chapters (${chapters.length})` : `সব অধ্যায় (${toBanglaNumber(chapters.length)})`}
                      </button>

                      {[
                        { num: 1, emoji: '🌸', en: '1: Self-Awareness', bn: '১: আত্মসচেতনতা' },
                        { num: 2, emoji: '💬', en: '2: Communication', bn: '২: যোগাযোগ' },
                        { num: 3, emoji: '🌱', en: '3: Resilience', bn: '৩: সহনশীলতা' },
                        { num: 4, emoji: '🧭', en: '4: Decision Making', bn: '৪: লক্ষ্য ও সিদ্ধান্ত' },
                        { num: 5, emoji: '🌺', en: '5: Puberty & Health', bn: '৫: বয়ঃসন্ধি ও স্বাস্থ্য' },
                        { num: 6, emoji: '⚖️', en: '6: Rights & Safety', bn: '৬: অধিকার ও সুরক্ষা' },
                      ].map(ph => (
                        <button
                          key={ph.num}
                          onClick={() => setSelectedPhaseFilter(ph.num)}
                          className={`py-1.5 px-3 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                            selectedPhaseFilter === ph.num
                              ? 'bg-indigo-600 text-white shadow-xs'
                              : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                          }`}
                        >
                          <span>{ph.emoji}</span>
                          <span>{currentLang === 'en' ? ph.en : ph.bn}</span>
                        </button>
                      ))}
                    </div>

                    {/* Chapters List Grid */}
                    <div id="chapters-list-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {chapters
                        .filter(chap => selectedPhaseFilter === 'all' || chap.phase === selectedPhaseFilter)
                        .map((chap) => {
                          const isFinished = progress.completedChapters.includes(chap.id);
                          const chQuestions = quizQuestions.filter(q => q.chapterId === chap.id);
                          const hasQuizScore = progress.quizScores[`ch_${chap.id}`];

                          return (
                            <div
                              key={chap.id}
                              style={{ 
                                borderLeft: chap.category === 'life-skills' 
                                  ? '5px solid #4f46e5' 
                                  : chap.category === 'health' 
                                    ? '5px solid #ec4899'
                                    : '5px solid #06b6d4' 
                              }}
                              className={`p-4 bg-white rounded-2xl shadow-3xs border border-slate-100 flex flex-col justify-between gap-3 transition-all hover:shadow-xs hover:border-slate-200 ${
                                isFinished ? 'bg-slate-50/60' : ''
                              }`}
                            >
                              <div className="flex items-start gap-3">
                                <span className="text-3xl shrink-0 p-2 bg-slate-50 rounded-xl" role="img">
                                  {chap.emoji}
                                </span>
                                <div className="flex-1 space-y-1 min-w-0">
                                  <div className="flex justify-between items-start gap-1">
                                    <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider font-mono">
                                      {currentLang === 'en' ? "Chapter" : "পাঠ"} {chap.id} • {chap.phase ? `P${chap.phase}` : ''}
                                    </span>
                                    {isFinished && (
                                      <span className="bg-emerald-100 text-emerald-800 text-[9px] font-bold py-0.5 px-2 rounded-full flex items-center gap-0.5 shrink-0">
                                        <Check className="w-2.5 h-2.5 text-emerald-700" /> {currentLang === 'en' ? "Done" : "পড়া শেষ"}
                                      </span>
                                    )}
                                  </div>
                                  <h3 className="text-xs md:text-sm font-extrabold text-slate-900 leading-tight line-clamp-2">
                                    {chap.title[currentLang]}
                                  </h3>
                                </div>
                              </div>

                              <p className="text-[11px] text-slate-650 line-clamp-2 leading-relaxed">
                                {chap.summary[currentLang]}
                              </p>

                              <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-100">
                                <button
                                  id={`btn-open-chap-${chap.id}`}
                                  onClick={() => setOpenedChapter(chap)}
                                  className="py-1.5 px-3 bg-slate-100 hover:bg-slate-200 text-indigo-700 font-extrabold text-[11px] rounded-lg transition-all transform active:scale-95 flex items-center gap-1 cursor-pointer"
                                >
                                  <span>{isFinished ? (currentLang === 'en' ? "Review Lesson" : "আবার পড়ো") : (currentLang === 'en' ? "Start Lesson" : "পড়া শুরু করো")}</span>
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </button>

                                {chQuestions.length > 0 && (
                                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                                    hasQuizScore 
                                      ? 'bg-emerald-50 text-emerald-800 font-mono' 
                                      : 'bg-indigo-50 text-indigo-700'
                                  }`}>
                                    {hasQuizScore 
                                      ? `Quiz: ${hasQuizScore.score}/${hasQuizScore.total}` 
                                      : `${chQuestions.length} Qs`}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: KNOWLEDGE QUIZZES */}
            {activeTab === 'quizzes' && (
              <div id="tab-quizzes-view" className="space-y-8 max-w-4xl mx-auto animate-fadeIn">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3 bg-white p-5 rounded-3xl border border-slate-200 shadow-3xs">
                  <div className="space-y-1 text-left">
                    <div className="flex items-center gap-2">
                      <h2 className="text-md md:text-lg font-extrabold text-slate-900 flex items-center gap-1.5">
                        <span>📝</span>
                        {currentLang === 'en' ? "Knowledge Milestones & Phase Quizzes" : "কুইজ পরীক্ষা ও পর্যায়ভিত্তিক মূল্যায়ন"}
                      </h2>
                      <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full font-mono">
                        {quizQuestions.length} {currentLang === 'en' ? 'Questions' : 'প্রশ্ন'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600">
                      {currentLang === 'en'
                        ? "Test your knowledge across all 6 phases. Answer questions to win extra star points and unlock royal badges!"
                        : "৬টি পর্যায়ের পাঠগুলোর ওপর পরীক্ষা দিয়ে অতিরিক্ত পয়েন্ট সংগ্রহ করো এবং মেডেল আনলক করো!"
                      }
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="text-xs font-mono bg-indigo-50 border border-indigo-100 text-indigo-900 py-1.5 px-3 rounded-xl font-bold">
                      {currentLang === 'en' ? "Quizzes Passed:" : "পাস করা কুইজ:"}{' '}
                      <span className="text-indigo-700 font-black">
                        {Object.keys(progress.quizScores || {}).length}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Grid of 6 Phase Quiz Checkpoints */}
                <div className="grid grid-cols-1 gap-6">
                  {[
                    { num: 1, emoji: '🌸', en: 'Phase 1: Self-Awareness & Body Positivity', bn: 'পর্যায় ১: আত্মসচেতনতা ও শারীরিক ইতিবাচকতা', chRange: [1, 2, 3], descEn: 'Questions assessing self-identity, strengths, and body confidence.', descBn: 'আত্মপরিচয়, আত্মমর্যাদা ও শারীরিক আত্মবিশ্বাস যাচাই পরীক্ষা।' },
                    { num: 2, emoji: '💬', en: 'Phase 2: Communication, Active Listening & Teamwork', bn: 'পর্যায় ২: যোগাযোগ ও দলগত কাজ', chRange: [4, 5, 6, 7], descEn: 'Questions on speaking up, active listening, and setting healthy boundaries.', descBn: 'কথা বলা, মনোযোগ দিয়ে শোনা ও ব্যক্তিগত সীমানা নির্ধারণের পরীক্ষা।' },
                    { num: 3, emoji: '🌱', en: 'Phase 3: Emotional Management, Stress & Resilience', bn: 'পর্যায় ৩: আবেগ নিয়ন্ত্রণ ও সহনশীলতা', chRange: [8, 9, 10], descEn: 'Questions on emotion regulation, overcoming challenges, and stress relief.', descBn: 'আবেগ নিয়ন্ত্রণ, মানসিক চাপ কমানো ও সহনশীলতা অর্জনের পরীক্ষা।' },
                    { num: 4, emoji: '🧭', en: 'Phase 4: Critical Thinking & Future Goal Planning', bn: 'পর্যায় ৪: লক্ষ্য নির্ধারণ ও সিদ্ধান্ত মূল্যায়ন', chRange: [11, 12, 13], descEn: 'Questions on critical evaluation, SMART goal setting, and saying no.', descBn: 'গঠনমূলক চিন্তা, স্মার্ট লক্ষ্য নির্ধারণ ও দৃঢ় আলোচনা।' },
                    { num: 5, emoji: '🌺', en: 'Phase 5: Puberty, Menstrual Health & Hygiene', bn: 'পর্যায় ৫: বয়ঃসন্ধি ও মাসিক স্বাস্থ্য', chRange: [14, 15, 16], descEn: 'Questions on biological growth, menstrual hygiene, and nutritious foods.', descBn: 'বয়ঃসন্ধির পরিবর্তন, মাসিক পরিচ্ছন্নতা ও পুষ্টিকর খাবারের নিয়ম।' },
                    { num: 6, emoji: '⚖️', en: 'Phase 6: Child Rights, Laws, Protection & Cyber Safety', bn: 'পর্যায় ৬: অধিকার, আইন ও সাইবার সুরক্ষা', chRange: [17, 18, 19, 20, 21], descEn: 'Questions on child marriage laws, safe touch, helplines, and digital safety.', descBn: 'বাল্যবিয়ে আইন, শিশু অধিকার, জরুরি হেল্পলাইন ও ইন্টারনেট সুরক্ষা।' },
                  ].map((ph) => {
                    const phaseKey = `phase_${ph.num}`;
                    const completedInPhase = progress.completedChapters.filter(id => ph.chRange.includes(id)).length;
                    const phaseQuestions = quizQuestions.filter(q => ph.chRange.includes(q.chapterId));
                    const scoreData = progress.quizScores[phaseKey];
                    const isUnlocked = completedInPhase >= 1;

                    return (
                      <div
                        key={ph.num}
                        id={`quiz-${phaseKey}`}
                        className="bg-white p-5 md:p-6 rounded-3xl border border-slate-200 shadow-3xs space-y-4"
                      >
                        <div className="flex justify-between items-start gap-4 pb-3 border-b border-slate-100 flex-col sm:flex-row">
                          <div className="space-y-0.5">
                            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                              <span>{ph.emoji}</span>
                              <span>{currentLang === 'en' ? ph.en : ph.bn}</span>
                            </h3>
                            <p className="text-xs text-slate-500">
                              {currentLang === 'en' ? ph.descEn : ph.descBn}
                            </p>
                          </div>
                          <div className="text-xs font-mono bg-indigo-50 border border-indigo-100 text-indigo-800 py-1 px-2.5 rounded-xl font-bold shrink-0">
                            {currentLang === 'en' ? "Chapters Studied:" : "অধ্যায় পড়া হয়েছে:"} {completedInPhase}/{ph.chRange.length}
                          </div>
                        </div>

                        {!isUnlocked ? (
                          <div className="p-4 bg-slate-50 text-slate-500 text-xs rounded-2xl flex items-center gap-2 italic">
                            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
                            <span>
                              {currentLang === 'en'
                                ? `Please complete at least 1 lesson in Phase ${ph.num} (Chapters ${ph.chRange[0]} to ${ph.chRange[ph.chRange.length - 1]}) to unlock this quiz checkpoint.`
                                : `অনুগ্রহ করে পর্যায় ${toBanglaNumber(ph.num)} এর অন্তত ১টি অধ্যায় পড়ে এই পরীক্ষাটি আনলক করো।`
                              }
                            </span>
                          </div>
                        ) : phaseQuestions.length === 0 ? (
                          <div className="p-4 bg-slate-50 text-slate-500 text-xs rounded-xl">
                            {currentLang === 'en' ? "No questions loaded for this phase." : "এই পর্যায়ের প্রশ্ন পাওয়া যায়নি।"}
                          </div>
                        ) : (
                          <BlockQuizWizard
                            blockType={phaseKey}
                            title={currentLang === 'en' ? ph.en : ph.bn}
                            questions={phaseQuestions}
                            currentLang={currentLang}
                            selectedAnswers={selectedQuizAnswers}
                            selectAnswer={selectAnswer}
                            onSubmit={() => handleSubmitQuiz(phaseKey, phaseQuestions)}
                            quizScore={scoreData}
                            onReset={() => handleResetQuiz(phaseKey, phaseQuestions)}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* TAB 3: NEW INTERACTIVE SELF-CARE & PRACTICE WORKSTATIONS */}
            {activeTab === 'tools' && (
              <div id="tab-interactive-labs" className="space-y-6 animate-fadeIn pb-12">
                
                {/* 1. Unlocked Medals Badges Section */}
                <div className="bg-gradient-to-tr from-slate-900 to-indigo-950 p-6 rounded-3xl text-white space-y-4 shadow-md">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-indigo-900/50 pb-3">
                    <div>
                      <h3 className="text-base font-black text-amber-400 flex items-center gap-1.5">
                        <Award className="w-5 h-5 text-amber-400" />
                        {currentLang === 'en' ? "My Achievements & Badge Medals" : "আমার অর্জিত শিক্ষা মেডেলসমূহ"}
                      </h3>
                      <p className="text-xs text-indigo-200">
                        {currentLang === 'en' ? "You unlock these custom badges as you read chapters, practice focus, and write your diary!" : "অধ্যায় পড়া, টাইমার ধরে পড়াশোনা এবং বাজেটিং প্র্যাকটিস করলে এই রাজকীয় মেডেলগুলো সয়ংক্রিয়ভাবে খুলে যাবে!"}
                      </p>
                    </div>
                    <span className="text-xs font-mono font-bold bg-indigo-900 text-indigo-100 py-1 px-3 rounded-md border border-indigo-800">
                      Unlocks: {progress.unlockedBadgeIds.length} / {BADGES.length}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3">
                    {BADGES.map((b) => {
                      const isUnlocked = progress.unlockedBadgeIds.includes(b.id);
                      return (
                        <div
                          key={b.id}
                          className={`p-3 rounded-xl border text-center space-y-1 transition-all ${
                            isUnlocked 
                              ? 'bg-indigo-900/60 border-amber-500/50 opacity-100 scale-102 ring-1 ring-amber-400/20' 
                              : 'bg-slate-950/40 border-indigo-950/70 opacity-40 select-none'
                          }`}
                        >
                          <span className={`text-3xl block filter ${isUnlocked ? 'drop-shadow-sm' : 'grayscale text-slate-500'}`}>
                            {isUnlocked ? b.emoji : "🔒"}
                          </span>
                          <h4 className="text-[10px] font-black leading-tight text-white">{b.title[currentLang]}</h4>
                          <p className="text-[8px] text-indigo-200 font-sans leading-tight line-clamp-2">{b.description[currentLang]}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Daily Affirmation Postcard */}
                <div className="bg-gradient-to-tr from-pink-50 to-indigo-50/50 p-4 rounded-xl border border-pink-100 flex items-start gap-3 relative overflow-hidden">
                  <div className="absolute right-0 bottom-0 text-pink-100 text-8xl font-bold select-none translate-y-6 pointer-events-none pr-4">🌻</div>
                  <span className="text-2xl mt-0.5 shrink-0 select-none">💌</span>
                  <div className="space-y-1 relative z-1">
                    <span className="text-[9px] uppercase font-bold text-pink-600 tracking-widest font-mono">
                      {currentLang === 'en' ? "Supportive Sisterly Affirmation of the Day" : "দিদিমণিদের আজকের মিষ্টি অনুপ্রেরণা"}
                    </span>
                    <p className="text-xs md:text-sm font-black text-slate-850 leading-relaxed font-sans italic">
                      "{DAILY_AFFIRMATIONS[affirmationIndex][currentLang]}"
                    </p>
                  </div>
                </div>

                {/* 3. Bento-Box navigation sub-tabs for Interactive tools */}
                <div className="flex flex-wrap gap-2 justify-center border-b pb-1 border-slate-200">
                  <button
                    onClick={() => setActiveSubtab('timer')}
                    className={`py-2 px-4 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1.5 transition-all ${
                      activeSubtab === 'timer' ? 'bg-indigo-600 text-white font-extrabold shadow-xs' : 'bg-white hover:bg-slate-150 border text-slate-700'
                    }`}
                  >
                    ⏰ {currentLang === 'en' ? "Smart Focus Timer" : "মনোযোগ টাইমার"}
                  </button>
                  <button
                    onClick={() => setActiveSubtab('budget')}
                    className={`py-2 px-4 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1.5 transition-all ${
                      activeSubtab === 'budget' ? 'bg-indigo-600 text-white font-extrabold shadow-xs' : 'bg-white hover:bg-slate-150 border text-slate-700'
                    }`}
                  >
                    🪙 {currentLang === 'en' ? "Play Wallet Sandbox" : "খসড়া জমানো ব্যাগ"}
                  </button>
                  <button
                    onClick={() => setActiveSubtab('decide')}
                    className={`py-2 px-4 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1.5 transition-all ${
                      activeSubtab === 'decide' ? 'bg-indigo-600 text-white font-extrabold shadow-xs' : 'bg-white hover:bg-slate-150 border text-slate-700'
                    }`}
                  >
                    🧭 {currentLang === 'en' ? "Dilemma Decider" : "আমি কী করব?"}
                  </button>
                  <button
                    onClick={() => setActiveSubtab('journal')}
                    className={`py-2 px-4 rounded-xl text-xs font-black cursor-pointer flex items-center gap-1.5 transition-all ${
                      activeSubtab === 'journal' ? 'bg-indigo-600 text-white font-extrabold shadow-xs' : 'bg-white hover:bg-slate-150 border text-slate-700'
                    }`}
                  >
                    📓 {currentLang === 'en' ? "Private Self-Care Diary" : "মনের কথা ডায়েরি"}
                  </button>
                </div>

                {/* RENDER THE CORRESPONDING ACTIVE LAB COMPONENT */}
                <div className="pt-2">
                  {activeSubtab === 'timer' && (
                    <StudyFocusTimer
                      currentLang={currentLang}
                      starPoints={progress.starPoints}
                      onRewardStars={handleRewardStarsFromTimer}
                      unlockedBadgeIds={progress.unlockedBadgeIds}
                    />
                  )}

                  {activeSubtab === 'budget' && (
                    <SandboxBudget
                      currentLang={currentLang}
                      budgetItems={progress.budget}
                      onAddTransaction={handleAddTransaction}
                      onDeleteItem={handleDeleteTransaction}
                      onClearTransactions={() => saveUserProgress({ ...progress, budget: [] })}
                    />
                  )}

                  {activeSubtab === 'decide' && (
                    <VisualDecisionTree
                      currentLang={currentLang}
                      savedTrees={progress.decisions}
                      onSaveTree={handleSaveTree}
                      onDeleteTree={handleDeleteTree}
                      onClearTrees={() => saveUserProgress({ ...progress, decisions: [] })}
                    />
                  )}

                  {activeSubtab === 'journal' && (
                    <NotesJournal
                      currentLang={currentLang}
                      notes={progress.notes}
                      onAddNote={handleAddNote}
                      onDeleteNote={handleDeleteNote}
                      onClearNotes={() => { if (confirm("Clear journal memory?")) saveUserProgress({ ...progress, notes: [] }); }}
                    />
                  )}
                </div>

              </div>
            )}

            {/* TAB 4: RELAX CORNER (BREATHING & memory GAME) */}
            {activeTab === 'games' && (
              <div id="tab-games-view" className="animate-fadeIn">
                <SafeSpace 
                  currentLang={currentLang} 
                  starPoints={progress.starPoints} 
                  onRewardStars={(stars, reason) => {
                    saveUserProgress({
                      ...progress,
                      starPoints: progress.starPoints + stars
                    });
                  }}
                />
              </div>
            )}

            {/* TAB 5: MY BODY & PUBERTY CALCULATIONS */}
            {activeTab === 'health' && (
              <div id="tab-health-view" className="animate-fadeIn">
                <AdolescentHealth currentLang={currentLang} />
              </div>
            )}

            {/* TAB 6: PHONE HELPLINES DIRECT DIAL */}
            {activeTab === 'helpline' && (
              <div id="tab-helpline-view" className="max-w-xl mx-auto space-y-6 animate-fadeIn pb-12">
                
                <div className="text-center space-y-1">
                  <h2 className="text-md md:text-lg font-extrabold text-slate-900 inline-flex items-center gap-2.5 justify-center">
                    🚨 {currentLang === 'en' ? "One-Click Emergency Helplines" : "জরুরী সহায়তা কল সেন্টারগুলো"}
                  </h2>
                  <p className="text-xs text-slate-600">
                    {currentLang === 'en'
                      ? "If you or your sister are facing distress, child abuse pressure, early marriage problems, or health anxiety, tap the green calling dialer below."
                      : "কোনো সমস্যা বা গার্হস্থ্য নির্যাতন বা জোরপূর্বক বিয়ে দিতে চাইলে নিচে দেওয়া বিশ্বস্ত কল সেন্টার গুলোতে টাচ করে সরাসরি ফ্রিতে ফোন করো।"
                    }
                  </p>
                </div>

                <div className="space-y-4">
                  {HELPLINES.map((hl) => (
                    <div key={hl.number} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-3xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:border-indigo-100 transition-colors">
                      <div className="space-y-1">
                        <h3 className="text-xs md:text-sm font-extrabold text-slate-950 flex items-center gap-1.5">
                          📞 {hl.name[currentLang]}
                        </h3>
                        <p className="text-xs text-slate-600 leading-normal">
                          {hl.description[currentLang]}
                        </p>
                      </div>

                      <a
                        id={`btn-call-helpline-${hl.number}`}
                        href={`tel:${hl.number}`}
                        className="py-2.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1.5 shrink-0 select-none cursor-pointer self-stretch sm:self-auto justify-center"
                      >
                        {currentLang === 'en' ? "Call dial:" : "কল করো:"} <span className="font-mono text-sm leading-none bg-emerald-700 px-2 py-0.5 rounded">{hl.number}</span>
                      </a>
                    </div>
                  ))}
                </div>

                <div className="p-4 bg-indigo-50 rounded-2xl border border-indigo-100 text-xs text-indigo-950 font-medium leading-relaxed font-sans text-center">
                  💡 <strong>{currentLang === 'en' ? "Sustainable Offline Advisory:" : "সহায়তা নির্দেশিকা:"}</strong>{' '}
                  {currentLang === 'en'
                    ? "Tapping calling buttons will launch your mobile's dialer application automatically without requiring active cellular internet packs."
                    : "ফোন করার জন্য মোবাইলে ডেটা প্যাক বা ইন্টারনেটের ব্যালেন্স কাটে না, তাই এটি সম্পুর্ণ বিনামূল্যে কাজের সময়ে সুরক্ষিত সাহায্য দান করে।"
                  }
                </div>

              </div>
            )}

            {/* TAB 7: ABOUT WEBPAGE TAB */}
            {activeTab === 'about' && (
              <div id="tab-about-view" className="max-w-2xl mx-auto space-y-6 animate-fadeIn pb-12">
                
                {/* Organization Details Card */}
                <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-200 shadow-3xs text-center space-y-5">
                  <div className="flex justify-center">
                    <StJohnLogo size={100} className="filter drop-shadow-sm animate-pulse-slow" />
                  </div>
                  
                  <div className="space-y-4">
                    {/* 1. Organisation Name */}
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider font-mono">
                        {currentLang === 'en' ? "Organisation" : "প্রতিষ্ঠান"}
                      </span>
                      <h2 className="text-base md:text-lg font-black text-rose-950 tracking-tight leading-tight">
                        {currentLang === 'en' ? "St. John Ambulance Association Raiganj" : "সেন্ট জন অ্যাম্বুলেন্স অ্যাসোসিয়েশন রায়গঞ্জ"}
                      </h2>
                    </div>

                    {/* 2. Address */}
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider font-mono">
                        {currentLang === 'en' ? "Address" : "ঠিকানা"}
                      </span>
                      <h3 className="text-xs md:text-sm font-extrabold text-slate-700 leading-snug">
                        {currentLang === 'en' ? "Raiganj Sub-District Branch, West Bengal" : "রায়গঞ্জ মহকুমা শাখা, পশ্চিমবঙ্গ"}
                      </h3>
                    </div>

                    <div className="h-px bg-slate-100 max-w-sm mx-auto"></div>

                    {/* 3. Project Name */}
                    <div className="space-y-1">
                      <span className="text-[10px] uppercase font-bold text-indigo-500 tracking-wider font-mono block">
                        {currentLang === 'en' ? "Project Name" : "প্রকল্পের নাম"}
                      </span>
                      <p className="text-xs md:text-sm font-black text-indigo-950 font-sans tracking-wide uppercase leading-snug">
                        {currentLang === 'en' 
                          ? "PROJECT: EMPOWERING ADOLESCENTS FOR A BETTER FUTURE" 
                          : "প্রকল্প: কিশোরীদের সুন্দর ভবিষ্যতের উদ্দেশ্যে ক্ষমতায়ন (EMPOWERING ADOLESCENTS FOR A BETTER FUTURE)"
                        }
                      </p>
                    </div>

                    <div className="h-px bg-slate-100 max-w-sm mx-auto"></div>

                    {/* 4. Underneath: Funded by Azim Premji Foundation */}
                    <div className="space-y-1 bg-emerald-50/50 p-3 rounded-2xl border border-emerald-100/55 max-w-md mx-auto">
                      <span className="text-[9px] font-extrabold text-emerald-700 block uppercase tracking-widest">
                        {currentLang === 'en' ? "Grant & Support Partner" : "সহযোগিতা ও অনুদান পার্টনার"}
                      </span>
                      <p className="text-xs md:text-sm font-black text-emerald-950 font-sans">
                        {currentLang === 'en' ? "Funded by: Azim Premji Foundation" : "অর্থায়নে: আজিম প্রেমজী ফাউন্ডেশন"}
                      </p>
                    </div>
                  </div>

                  <p className="text-xs text-slate-650 leading-relaxed max-w-lg mx-auto font-sans font-medium pt-2 border-t border-slate-100">
                    {currentLang === 'en'
                      ? "This offline-first academy applet serves to teach essential life skills, menstruation hygiene guidance, private self-expression journals, interactive finance budgeting, and provides instant 24/7 helplines for adolescent girls (aged 10-19) in underserved sub-districts."
                      : "এই অফলাইন লার্নিং অ্যাপলেটটি প্রান্তিক প্রত্যন্ত অঞ্চলের কিশোরী বালিকাদের (১০-১৯ বৎসর বয়সকাল) নিরাপত্তা সচেতনতা, বিজ্ঞানসম্মত বয়ঃসন্ধি পরিচ্ছন্নতা, মনের কথা ডায়েরি, হিসেব-নিকেশ ও জরুরী ২৪ ঘণ্টার হেল্পলাইন নম্বর সরবরাহ করতে বিশেষ উদ্যোগ।"
                    }
                  </p>
                </div>

                {/* Team / Developer Credit Card */}
                <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100 text-center space-y-1.5 max-w-md mx-auto">
                  <span className="text-[9px] font-extrabold text-indigo-700 block uppercase tracking-widest">
                    {currentLang === 'en' ? "Developer & Management" : "প্রোগ্রাম ও উন্নয়ন"}
                  </span>
                  <p className="text-xs font-black text-indigo-950">
                    {currentLang === 'en' ? "Developed with care by Nilanjan Majumdar" : "নির্মাণ ও পরিচালনায়: নীলাঞ্জন মজুমদার"}
                  </p>
                  <p className="text-[10px] text-indigo-700/80 font-bold font-sans">
                    {currentLang === 'en' ? "Raiganj Sub-District Branch • Active Sandbox" : "রায়গঞ্জ মহকুমা শাখা • সুরক্ষিত অফলাইন স্যান্ডবক্স"}
                  </p>
                </div>

                {/* 5. PROTECTED ADMIN ACCESS SECTION */}
                <div className="pt-2 max-w-md mx-auto text-center space-y-3">
                  {!isAdminAuthenticated ? (
                    <div className="bg-slate-100/70 hover:bg-slate-150 p-3.5 rounded-2xl border border-slate-200 transition-all flex items-center justify-between gap-3">
                      <div className="text-left">
                        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block font-mono">
                          {currentLang === 'en' ? "Staff & Facilitator Portal" : "শিক্ষক ও কর্মকর্তা পোর্টাল"}
                        </span>
                        <p className="text-xs font-bold text-slate-700">
                          {currentLang === 'en' ? "Curriculum & Course Management" : "পাঠক্রম ও কোর্স পরিচালনা"}
                        </p>
                      </div>
                      <button
                        id="btn-open-admin-login"
                        onClick={() => {
                          setAdminError('');
                          setShowAdminLoginModal(true);
                        }}
                        className="py-1.5 px-3.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-xl transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer shrink-0"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                        <span>{currentLang === 'en' ? "Admin Login 🔐" : "অ্যাডমিন লগইন 🔐"}</span>
                      </button>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-r from-purple-900 to-indigo-900 text-white p-5 rounded-3xl shadow-md space-y-4 border border-purple-700/50 text-left animate-fadeIn">
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex items-center gap-2">
                          <div className="p-2 bg-purple-800/80 rounded-xl text-amber-300">
                            <ShieldCheck className="w-5 h-5" />
                          </div>
                          <div>
                            <span className="text-[10px] font-black uppercase tracking-wider text-amber-300 font-mono block">
                              {currentLang === 'en' ? "Admin Verified • Authorized Staff" : "যাচাইকৃত অ্যাডমিন • অনুমোদিত শিক্ষক"}
                            </span>
                            <h4 className="text-sm font-extrabold text-white">
                              {currentLang === 'en' ? "Course Management Control" : "কোর্স আপডেট ও পাঠক্রম পরিচালনা"}
                            </h4>
                          </div>
                        </div>
                        <button
                          onClick={handleAdminLogout}
                          className="py-1 px-2.5 bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-[11px] font-bold rounded-lg border border-rose-400/30 transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <LogOut className="w-3 h-3" />
                          <span>{currentLang === 'en' ? "Sign Out" : "লগআউট"}</span>
                        </button>
                      </div>

                      <p className="text-xs text-purple-200 leading-relaxed">
                        {currentLang === 'en'
                          ? "As an authorized administrator, you can upload new Word documents (.docx) or JSON files to dynamically update the 21 chapters and quiz database."
                          : "অনুমোদিত কর্মকর্তা হিসেবে আপনি ওয়ার্ড ফাইল (.docx) অথবা JSON আপলোড করে নতুন অধ্যায় ও কুইজ ডাটাবেস আপডেট করতে পারবেন।"}
                      </p>

                      <div className="pt-1">
                        <button
                          id="btn-admin-open-importer"
                          onClick={() => setShowCourseImporter(true)}
                          className="w-full py-3 px-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer transform active:scale-98"
                        >
                          <FileText className="w-4 h-4 text-slate-950" />
                          <span>{currentLang === 'en' ? "Upload Word (.docx) & Update Course 📄" : "ওয়ার্ড (.docx) আপলোড ও কোর্স আপডেট 📄"}</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

              </div>
            )}

          </main>

          {/* supportive rural girls-specific footer */}
          <footer className="bg-indigo-950 text-indigo-200 py-6 px-4 border-t border-indigo-900 text-center text-xs space-y-1.5">
            <p className="font-bold flex items-center justify-center gap-1 text-slate-100">
               🌻 {currentLang === 'en' ? "EMPOWERING ADOLESCENTS FOR A BETTER FUTURE" : "কিশোরী মেলা প্রজেক্ট: কিশোরীদের সুন্দর ভবিষ্যতের উদ্দেশ্যে ক্ষমতায়ন"}
            </p>
            <p className="text-indigo-300 font-medium">
              {currentLang === 'en' 
                ? "St. John Ambulance Association Raiganj • Sustainable Offline Academy"
                : "সেন্ট জন অ্যাম্বুলেন্স অ্যাসোসিয়েশন রায়গঞ্জ • টেকসই অফলাইন জীবনশৈলী বিদ্যালয়"
              }
            </p>
            <p className="text-indigo-400 font-semibold font-mono text-[10px]">
              {currentLang === 'en' 
                ? "Created & Managed by Nilanjan Majumdar • Offline Sync Active"
                : "নির্মাণ ও পরিচালনায়: নীলাঞ্জন মজুমদার • অফলাইন স্টোরেজ ব্যাকআপ সচল"
              }
            </p>
          </footer>

        </div>
      )}

      {/* SCREEN TIME CALENDAR & POSITIVE FEEDBACK MODAL */}
      {showScreenTimeModal && (
        <div className="fixed inset-0 bg-indigo-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="max-w-xl w-full bg-white rounded-3xl border border-slate-100 shadow-2xl overflow-hidden flex flex-col max-h-[85vh] animate-scaleIn">
            
            {/* Modal Header */}
            <div className="bg-gradient-to-r from-pink-500 to-indigo-600 p-6 text-white text-center relative">
              <button
                onClick={() => setShowScreenTimeModal(false)}
                className="absolute right-4 top-4 w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 text-white font-extrabold flex items-center justify-center cursor-pointer text-sm"
              >
                ✕
              </button>
              
              <span className="text-5xl block select-none transform hover:rotate-12 transition-transform duration-300">⏳</span>
              <h2 className="text-2xl font-black tracking-tight mt-2">
                {currentLang === 'en' ? "Positive Usage Tracker" : "ইতিবাচক সময় ট্র্যাকার"}
              </h2>
              <p className="text-xs text-indigo-100 font-bold uppercase tracking-wider mt-1">
                {currentLang === 'en' ? "Your productive screen-time companion" : "তোমার ফলপ্রসূ মোবাইল ব্যবহারের হিসাব"}
              </p>
            </div>

            {/* Scrollable Modal Content */}
            <div className="p-6 md:p-8 overflow-y-auto space-y-6 flex-1 text-slate-800">
              
              {/* Interactive Phone Time Config Card */}
              <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-2xl space-y-3">
                <h3 className="text-sm font-extrabold text-indigo-950 flex items-center gap-1.5">
                  📱 {currentLang === 'en' ? "Daily Screen Time Calculator" : "দৈনিক ফোন ব্যবহারের ক্যালকুলেটর"}
                </h3>
                
                <p className="text-xs text-indigo-900 leading-normal font-semibold">
                  {currentLang === 'en' 
                    ? "How many hours do you usually spend on your phone every day?" 
                    : "তুমি সাধারণত প্রতিদিন মোট কত ঘন্টা মোবাইল ফোন ব্যবহার করো?"}
                </p>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="1"
                    max="12"
                    step="0.5"
                    value={estimatedPhoneHours}
                    onChange={(e) => setEstimatedPhoneHours(Number(e.target.value))}
                    className="flex-1 accent-indigo-600"
                  />
                  <div className="bg-indigo-600 text-white px-3 py-1 rounded-xl text-xs font-black font-mono whitespace-nowrap min-w-[70px] text-center shadow-xs">
                    {currentLang === 'en' 
                      ? `${estimatedPhoneHours} hours` 
                      : `${toBanglaNumber(estimatedPhoneHours)} ঘন্টা`}
                  </div>
                </div>

                {/* Mathematical Positive Feedback Analysis */}
                <div className="bg-white p-3.5 rounded-xl border border-indigo-100 mt-2 space-y-2">
                  <div className="text-xs text-slate-700 leading-relaxed font-bold">
                    {(() => {
                      const minutesInAppToday = Math.floor(secondsToday / 60);
                      const totalPhoneMinutes = estimatedPhoneHours * 60;
                      const percentage = totalPhoneMinutes > 0 ? Math.min(100, Math.round((minutesInAppToday / totalPhoneMinutes) * 100)) : 0;
                      
                      const fractionText = currentLang === 'en'
                        ? `you spent ${minutesInAppToday} minutes on Shokhi today. Out of your estimated ${estimatedPhoneHours} hours of total phone screen-time, you used ${percentage}% of it productively to learn life skills!`
                        : `আজ তুমি সখী অ্যাপে ${toBanglaNumber(minutesInAppToday)} মিনিট সময় কাটিয়েছ। তোমার আনুমানিক দৈনিক ${toBanglaNumber(estimatedPhoneHours)} ঘন্টা ফোন ব্যবহারের মধ্যে, তুমি মোট সময়ের ${toBanglaNumber(percentage)}% অংশ ইতিবাচক কাজে এবং নিজের দক্ষতা বৃদ্ধিতে ব্যয় করেছ!`;

                      return (
                        <div className="space-y-2">
                          <div className="text-indigo-950 text-sm font-black flex items-center gap-1">
                            <span>✨</span>
                            <span>
                              {currentLang === 'en' 
                                ? `Productive Ratio: ${percentage}%` 
                                : `ইতিবাচক ব্যবহারের অনুপাত: ${toBanglaNumber(percentage)}%`}
                            </span>
                          </div>
                          <p className="text-slate-600 font-semibold text-xs leading-relaxed">
                            {fractionText}
                          </p>
                          {percentage > 0 && (
                            <div className="bg-green-50 border border-green-100 p-2.5 rounded-lg text-[11px] text-green-900 flex gap-1.5 items-center font-bold">
                              <span>🌟</span>
                              <span>
                                {currentLang === 'en'
                                  ? "Excellent! You are transforming idle screen time into personal empowerment!"
                                  : "অসাধারণ! তুমি তোমার মোবাইল ব্যবহারের সময়কে নিজের সুন্দর ভবিষ্যৎ গড়ার শক্তিতে রূপান্তরিত করছ!"}
                              </span>
                            </div>
                          )}
                        </div>
                      );
                    })()}
                  </div>
                </div>
              </div>

              {/* Calendar-wise Usage Log */}
              <div className="space-y-3">
                <h3 className="text-xs font-bold text-slate-700 tracking-wider uppercase border-b pb-1">
                  📅 {currentLang === 'en' ? "Calendar-wise App Usage History:" : "ক্যালেন্ডার অনুযায়ী ব্যবহারের ইতিহাস:"}
                </h3>

                {Object.keys(screenTimeHistory).length === 0 ? (
                  <p className="text-xs text-slate-500 italic text-center py-4">
                    {currentLang === 'en' ? "No usage history logged yet." : "এখনো কোনো ব্যবহারের ইতিহাস রেকর্ড করা হয়নি।"}
                  </p>
                ) : (
                  <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                    {Object.entries(screenTimeHistory)
                      .sort((a, b) => b[0].localeCompare(a[0])) // Newest dates first
                      .map(([dateKey, seconds]) => {
                        const secNum = Number(seconds);
                        const minutes = Math.floor(secNum / 60);
                        const isToday = dateKey === getTodayDateString();
                        
                        return (
                          <div
                            key={dateKey}
                            className={`flex justify-between items-center p-3 rounded-xl border text-xs font-semibold ${
                              isToday 
                                ? 'bg-indigo-50 border-indigo-200' 
                                : 'bg-slate-50 border-slate-200'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span className="text-base select-none">🗓️</span>
                              <div className="text-left">
                                <span className="font-bold text-slate-900 block">
                                  {formatDateReadable(dateKey)}
                                </span>
                                {isToday && (
                                  <span className="text-[10px] text-indigo-600 font-extrabold uppercase">
                                    {currentLang === 'en' ? "Active Session" : "চলতি সেশন"}
                                  </span>
                                )}
                              </div>
                            </div>
                            
                            <div className="text-right">
                              <span className="font-mono text-indigo-950 font-black text-sm block">
                                {currentLang === 'en' 
                                  ? `${minutes} minutes` 
                                  : `${toBanglaNumber(minutes)} মিনিট`}
                              </span>
                              <span className="text-[10px] text-slate-500 block">
                                {currentLang === 'en' 
                                  ? `${secNum % 60} seconds active` 
                                  : `${toBanglaNumber(secNum % 60)} সেকেন্ড সক্রিয়`}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                )}
              </div>

              {/* Motivational Tip Box */}
              <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200 text-xs text-amber-950 leading-relaxed space-y-2">
                <div className="font-extrabold flex items-center gap-1 text-amber-900">
                  <span>💡</span>
                  <span>{currentLang === 'en' ? "Positive Phone Habits Tip:" : "ইতিবাচক ফোন ব্যবহারের সুবর্ণ পরামর্শ:"}</span>
                </div>
                <p className="font-semibold text-slate-700 text-xs">
                  {currentLang === 'en'
                    ? "Tracking your app usage helps you realize that screen time can be an ally! Try setting a daily goal of 20 minutes of study inside Shokhi to unlock special learner badges."
                    : "মোবাইলে অহেতুক সময় নষ্ট না করে প্রতিদিন মাত্র ২০ মিনিট সখী অ্যাপে পড়াশোনা করো। এতে তোমার জ্ঞান বৃদ্ধি পাবে এবং নতুন নতুন মেডেল বা ব্যাজ আনলক করতে পারবে।"}
                </p>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 border-t border-slate-100 p-4 text-center">
              <button
                onClick={() => setShowScreenTimeModal(false)}
                className="py-2.5 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs rounded-xl transition-all cursor-pointer shadow-md hover:shadow-indigo-100"
              >
                {currentLang === 'en' ? "Great, Close!" : "দারুণ, বন্ধ করো!"}
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ADMIN LOGIN MODAL */}
      {showAdminLoginModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-scaleUp">
            <div className="p-6 bg-gradient-to-r from-slate-900 via-purple-950 to-indigo-950 text-white flex justify-between items-start gap-3">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 bg-amber-400/20 text-amber-300 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider font-mono">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  {currentLang === 'en' ? "Restricted Staff Access" : "সুরক্ষিত কর্মী প্রবেশাধিকার"}
                </div>
                <h3 className="text-base font-black">
                  {currentLang === 'en' ? "Staff Administrator Login" : "অ্যাডমিন কর্মকর্তা প্রবেশ"}
                </h3>
              </div>
              <button
                onClick={() => setShowAdminLoginModal(false)}
                className="text-white/70 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAdminLogin} className="p-6 space-y-4">
              {adminError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 text-xs rounded-xl flex items-center gap-2 font-medium">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{adminError}</span>
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-800">
                  {currentLang === 'en' ? "Admin Username or Email" : "অ্যাডমিন ইউজারনেম বা ইমেইল"}
                </label>
                <input
                  type="text"
                  required
                  value={adminUsername}
                  onChange={(e) => setAdminUsername(e.target.value)}
                  placeholder="admin@sakhi.org or admin"
                  className="w-full p-3 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-800">
                  {currentLang === 'en' ? "Admin Password" : "অ্যাডমিন পাসওয়ার্ড"}
                </label>
                <input
                  type="password"
                  required
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full p-3 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-hidden"
                />
                <p className="text-[10px] text-slate-400">
                  {currentLang === 'en' ? "Demo pass: sakhi2026 or admin123" : "ডেমো পাসওয়ার্ড: sakhi2026"}
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdminLoginModal(false)}
                  className="flex-1 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-all cursor-pointer"
                >
                  {currentLang === 'en' ? "Cancel" : "বাতিল"}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl transition-all shadow-md cursor-pointer"
                >
                  {currentLang === 'en' ? "Verify & Enter 🛡️" : "যাচাই করুন ও প্রবেশ করুন 🛡️"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* COURSE DOCUMENT IMPORTER MODAL */}
      <CourseDocumentImporter
        currentLang={currentLang}
        isOpen={showCourseImporter}
        onClose={() => setShowCourseImporter(false)}
        onUpdateCourse={(newChapters, newQuizzes) => {
          setChapters(newChapters);
          setQuizQuestions(newQuizzes);
          localStorage.setItem('sakhi_custom_chapters', JSON.stringify(newChapters));
          localStorage.setItem('sakhi_custom_quizzes', JSON.stringify(newQuizzes));
        }}
        currentChaptersCount={chapters.length}
        currentQuizzesCount={quizQuestions.length}
      />

    </div>
  );
}
