import { Chapter, QuizQuestion, Helpline, Badge } from './types';

export const LIFE_SKILLS_CHAPTERS: Chapter[] = [
  {
    "id": 1,
    "phase": 1,
    "phaseTitle": {
      "en": "Self-Awareness & Body Positivity",
      "bn": "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা"
    },
    "category": "self-awareness",
    "emoji": "🌸",
    "title": {
      "en": "Understanding Myself & Building Self-Identity",
      "bn": "নিজেকে জানা ও আত্মপরিচয় গঠন"
    },
    "summary": {
      "en": "Accurately assess personal feelings, interests, values, and strengths to build self-worth and identity.",
      "bn": "নিজের অনুভূতি, আগ্রহ, মূল্যবোধ এবং শক্তিকে চিনে আত্মমর্যাদা ও ইতিবাচক পরিচয় গড়ে তোলা।"
    },
    "content": {
      "en": [
        "13-year-old Priya excels at mathematics and loves organizing community games in her village. However, her relatives frequently remind her that girls should remain quiet and focus on domestic chores.",
        "Torn between societal expectations and her own capabilities, Priya attends an Adolescent Circle session. Her mentor Sunita reassures her: 'Self-awareness means looking inside yourself to recognize your true worth, separate from external stereotypes.'",
        "When relatives ask her to stop studying to clean, Priya learns to use her Strengths Journal and plan a balanced schedule.",
        "Self-awareness empowers girls to accept themselves, recognize social barriers as external obstacles, and build a strong identity grounded in personal dignity."
      ],
      "bn": [
        "১৩ বছর বয়সী প্রিয়া অঙ্কে খুব ভালো কিন্তু আত্মীয়রা তাকে বলে মেয়েদের বেশি কথা না বলে ঘরের কাজে মন দেওয়া উচিত।",
        "কিশোরী সভায় গিয়ে প্রিয়া জানতে পারে যে আত্মসচেতনতার অর্থ হলো সমাজের বাঁধাধরা নিয়মের বাইরে নিজের আসল যোগ্যতা ও শক্তিকে চেনা।",
        "ঘরের কাজের সাথে নিজের পড়ার সময়সূচি সাজিয়ে সে নিজের শিক্ষার অধিকার রক্ষা করতে শেখে।",
        "আত্মসচেতনতা একজন কিশোরীকে নিজের মূল্য বুঝতে শেখায় এবং আত্মমর্যাদার সাথে নিজের পরিচয় গড়ে তুলতে সহায়তা করে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Relatives tell Priya to put away her math books to clean the kitchen.",
        "bn": "আত্মীয়রা প্রিয়াকে অঙ্কের বই সরিয়ে রান্নাঘরের কাজ করতে বলে।"
      },
      "choiceA": {
        "en": "Hide her books and assume girls shouldn't pursue academics.",
        "bn": "বই লুকিয়ে পড়ালেখা বন্ধ করে দেওয়া।"
      },
      "resultA": {
        "en": "Lowers self-esteem and reinforces external limitations.",
        "bn": "আত্মবিশ্বাস কমে যায় এবং পরাধীনতা বাড়ে।"
      },
      "choiceB": {
        "en": "Open 'My Strengths Journal' and plan a daily schedule balancing study and chores.",
        "bn": "'শক্তির খাতা' খুলে পড়াশোনা ও কাজের সুষম রুটিন করা।"
      },
      "resultB": {
        "en": "Builds internal agency, protects education, and establishes self-identity.",
        "bn": "নিজের অধিকার রক্ষা পায় এবং আত্মবিশ্বাস বাড়ে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Daily Strength Inventory: Log three specific accomplishments or personal qualities into your strength tracker every evening.",
        "Interactive Emotion Tracker: Use the visual emotion wheel twice daily to name current feelings without self-judgment.",
        "Digital Personal Values Journal: Complete daily 2-minute guided journaling prompts documenting your academic goals."
      ],
      "bn": [
        "দৈনিক শক্তির হিসাব: প্রতিদিন সন্ধ্যায় নিজের ৩টি ভালো গুণ বা কাজের হিসাব রাখো।",
        "অনুভূতি চাকা: দিনে দুবার নিজের মনের ভাব সঠিকভাবে চিহ্নিত করো।",
        "ব্যক্তিগত লক্ষ্যের ডায়েরি: প্রতিদিন নিজের পড়ার লক্ষ্যগুলো লিখে রাখো।"
      ]
    },
    "keyTakeaway": {
      "en": "Self-awareness is recognizing your true worth separate from stereotypes. Your skills define your future.",
      "bn": "আত্মসচেতনতা হলো সমাজের বাধানিষেধের বাইরে গিয়ে নিজের আসল মূল্য বোঝা।"
    }
  },
  {
    "id": 2,
    "phase": 1,
    "phaseTitle": {
      "en": "Self-Awareness & Body Positivity",
      "bn": "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা"
    },
    "category": "self-awareness",
    "emoji": "🌟",
    "title": {
      "en": "Embracing Strengths & Body Positivity",
      "bn": "নিজের শক্তিকে গ্রহণ ও শারীরিক ইতিবাচকতা"
    },
    "summary": {
      "en": "Develop positive self-esteem, counter body-shaming, and affirm physical and mental growth during puberty.",
      "bn": "আত্মমর্যাদা বাড়ানো, শারীরিক কটূক্তি প্রতিরোধ করা এবং বয়ঃসন্ধিকালের বৃদ্ধি স্বাভাবিকভাবে গ্রহণ করা।"
    },
    "content": {
      "en": [
        "14-year-old Sunita has grown taller than her classmates and slouches to hide her height after peers tease her.",
        "Her teacher reminds her: 'Your growth spurt is a sign that your body is developing normally. Your body works hard to grow strong—honor it, do not hide it.'",
        "WHO health guidelines confirm adolescence is a biological transition. Body positivity means focusing on health and functionality rather than unrealistic media beauty standards.",
        "Learning to celebrate individual growth protects mental health and builds lifelong self-confidence."
      ],
      "bn": [
        "১৪ বছর বয়সী সুনীতা বন্ধুদের চেয়ে লম্বা হয়ে যাওয়ায় লজ্জা পেয়ে ঝুঁকে হাঁটত।",
        "শিক্ষিকা তাকে বোঝালেন যে শরীরের বৃদ্ধি সম্পূর্ণ স্বাভাবিক এবং শক্তিশালী হওয়ার লক্ষণ। একে লুকানোর কিছু নেই।",
        "বিশ্ব স্বাস্থ্য সংস্থা অনুযায়ী বয়ঃসন্ধিকালে শারীরিক পরিবর্তন স্বাভাবিক নিয়মে ঘটে। বাহ্যিক চেহারার চেয়ে সুস্থতা বেশি গুরুত্বপূর্ণ।",
        "নিজের শরীরকে ভালোবাসা ও শ্রদ্ধা করা আত্মবিশ্বাসের মূল ভিত্তি।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Classmates tease Sunita about her height during lunch recess.",
        "bn": "সহপাঠীরা সুনীতার উচ্চতা নিয়ে ঠাট্টা করে।"
      },
      "choiceA": {
        "en": "Slouch, avoid eating lunch, and stay indoors.",
        "bn": "কুঁজো হয়ে থাকা ও খাবার না খাওয়া।"
      },
      "resultA": {
        "en": "Triggers negative self-talk, nutritional weakness, and fatigue.",
        "bn": "মন খারাপ ও শারীরিক দুর্বলতা দেখা দেয়।"
      },
      "choiceB": {
        "en": "Stand tall, tap 'Body Gratitude Affirmation', and state that growth happens naturally.",
        "bn": "সোজা হয়ে দাঁড়িয়ে স্বাভাবিক বৃদ্ধিকে স্বাগত জানানো।"
      },
      "resultB": {
        "en": "Reframes body image, stops teasing, and builds self-esteem.",
        "bn": "শারীরিক ইতিবাচকতা তৈরি হয় এবং আত্মবিশ্বাস বাড়ে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "In-App Body Gratitude Cards: Affirm what your body does (e.g., 'My legs carry me to school; my brain solves problems').",
        "Self-Talk Reframing: Convert negative thoughts ('I look awkward') into positive affirmations ('My body is growing naturally').",
        "Peer Support Boundary Checklist: Practice respectful verbal responses to interrupt peer body-shaming."
      ],
      "bn": [
        "শারীরিক কৃতজ্ঞতার কার্ড: শরীর তোমার জন্য কী করছে তা প্রতিদিন স্মরণ করো।",
        "ইতিবাচক ভাবনা বদল: নেতিবাচক চিন্তার জায়গায় নিজের বৃদ্ধির প্রশংসা করো।",
        "কটূক্তি মোকাবিলার উপায়: বন্ধুদের ঠাট্টায় শান্ত ও দৃঢ় গলায় উত্তর দাও।"
      ]
    },
    "keyTakeaway": {
      "en": "Pubertal changes are normal biological transitions. Honor what your body does rather than how it looks.",
      "bn": "শারীরিক পরিবর্তন সম্পূর্ণ স্বাভাবিক। বাহ্যিক রূপের চেয়ে নিজের সুস্থতাকে বড় করে দেখো।"
    }
  },
  {
    "id": 3,
    "phase": 1,
    "phaseTitle": {
      "en": "Self-Awareness & Body Positivity",
      "bn": "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা"
    },
    "category": "self-awareness",
    "emoji": "👑",
    "title": {
      "en": "Cultivating Self-Worth & Dignity Affirmation",
      "bn": "আত্মমর্যাদা ও অধিকার সচেতনতা"
    },
    "summary": {
      "en": "Recognize inherent human worth, fundamental legal rights, and gender equality aligning with UNICEF principles.",
      "bn": "মানুষ হিসেবে নিজের অন্তর্নিহিত মূল্য, মৌলিক আইনি অধিকার এবং লিঙ্গ সমতা উপলব্ধি করা।"
    },
    "content": {
      "en": [
        "In 15-year-old Meena's family, household funds are prioritized for her brother's tutoring while Meena does domestic labor.",
        "Her Sakhi mentor Rekha points out: 'UNICEF principles state that every girl has an equal right to education, health, and personal development.'",
        "True empowerment begins when a girl recognizes her inherent worth and rejects internalized gender discrimination.",
        "Standing up for educational equality creates opportunities not just for oneself, but for the entire community."
      ],
      "bn": [
        "১৫ বছর বয়সী মীনার পরিবারে ভাইয়ের পড়ালেখায় টাকা খরচ করা হলেও মীনাকে ঘরের কাজে আটকে রাখা হতো।",
        "সখী মেন্টর রেখা তাকে শেখায় যে শিক্ষা ও স্বাস্থ্যের অধিকার ছেলে ও মেয়ে উভয়ের সমান।",
        "মেয়েদের ক্ষমতায়ন তখনই শুরু হয় যখন তারা নিজেদের অধিকার চিনতে পারে এবং বৈষম্য দূর করতে কথা বলে।",
        "নিজের মর্যাদা জানা একটি সুন্দর ও স্বাধীন ভবিষ্যৎ গড়ে তোলে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Family asks Meena to drop evening study hours to do extra chores.",
        "bn": "পরিবার মীনাকে পড়াশোনা বাদ দিয়ে বাড়তি কাজ করতে বলে।"
      },
      "choiceA": {
        "en": "Silently accept that her education is less important than domestic labor.",
        "bn": "চুপচাপ মেনে নেওয়া যে পড়াশোনা জরুরি নয়।"
      },
      "resultA": {
        "en": "Internalizes low self-worth, increases dropout risk.",
        "bn": "হতাশা বাড়ে এবং পড়াশোনা বন্ধের ঝুঁকি তৈরি হয়।"
      },
      "choiceB": {
        "en": "Use the 'Dignity Advocacy Script' to calmly claim study hours with a shared chore schedule.",
        "bn": "শান্ত গলায় পড়ার অধিকার দাবি করা এবং কাজ ভাগ করে নেওয়ার প্রস্তাব দেওয়া।"
      },
      "resultB": {
        "en": "Asserts fundamental dignity and protects educational continuity.",
        "bn": "মর্যাদা রক্ষা পায় এবং পড়াশোনার সময় নিশ্চিত হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Interactive Dignity Checklist: Complete weekly app self-checks affirming equal rights to nutrition and education.",
        "Daily Affirmations: Listen to audio clips: 'I am worthy, I am capable, and my education is my fundamental right.'",
        "Ally Network Mapper: Identify trusted teachers or Anganwadi workers to assist when educational rights are overlooked."
      ],
      "bn": [
        "মর্যাদার তালিকা: নিজের পুষ্টি ও পড়ার অধিকারের নিশ্চয়তা যাচাই করো।",
        "দৈনিক অডিও বার্তা: 'আমি সক্ষম এবং শিক্ষা আমার মৌলিক অধিকার'—অনুশীলন করো।",
        "সহায়তাকারীদের তালিকা: কোনো বাধার মুখে শিক্ষক বা সচেতন বড়দের পাশে নাও।"
      ]
    },
    "keyTakeaway": {
      "en": "True empowerment begins with knowing your inherent worth. Every girl has an equal right to an education.",
      "bn": "আসল শক্তি আসে নিজের মর্যাদা চেনার মাধ্যমে। শিক্ষার অধিকার সবার সমান।"
    }
  },
  {
    "id": 4,
    "phase": 2,
    "phaseTitle": {
      "en": "Communication, Teamwork & Healthy Boundaries",
      "bn": "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা"
    },
    "category": "communication",
    "emoji": "💬",
    "title": {
      "en": "Expressing Feelings & Effective Speaking",
      "bn": "অনুভূতি প্রকাশ ও কার্যকর বক্তব্য"
    },
    "summary": {
      "en": "Master assertive verbal and non-verbal communication techniques to express thoughts, needs, and opinions clearly.",
      "bn": "দৃঢ় ও সুস্পষ্ট যোগাযোগের কৌশল আয়ত্ত করে নিজের ভাবনা ও অধিকার নির্ভয়ে প্রকাশ করা।"
    },
    "content": {
      "en": [
        "15-year-old Radha wants to join an after-school science club but is afraid her father will refuse if she speaks passively.",
        "Her friend teaches her assertive posture: standing upright, maintaining steady eye contact, and using clear 'I-messages'.",
        "UNICEF defines communication as exchanging information, feelings, and needs with mutual respect.",
        "Assertive communication differs from aggression because it respects both personal rights and the listener's dignity."
      ],
      "bn": [
        "১৫ বছর বয়সী রাধা বিজ্ঞান ক্লাবে যেতে চায় কিন্তু ভয়ে বাবাকে স্পষ্ট করে বলতে পারছিল না।",
        "তার বন্ধু তাকে সোজা হয়ে দাঁড়িয়ে, চোখে চোখ রেখে 'আমি-বার্তা' দিয়ে কথা বলতে শেখায়।",
        "যোগাযোগ মানে সম্মান বজায় রেখে নিজের প্রয়োজন ও অনুভূতি খোলাখুলি প্রকাশ করা।",
        "দৃঢ় বক্তব্য আক্রমণাত্মক না হয়েও নিজের মত প্রতিষ্ঠা করতে পারে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Radha speaks to her father about joining the science club.",
        "bn": "রাধা বাবার কাছে বিজ্ঞান ক্লাবে যোগ দেওয়ার ইচ্ছা জানায়।"
      },
      "choiceA": {
        "en": "Whisper passively: 'It doesn't matter, but there is a club...'",
        "bn": "মিনমিন করে অস্পষ্টভাবে বলা।"
      },
      "resultA": {
        "en": "Request dismissed due to lack of clarity and confidence.",
        "bn": "আত্মবিশ্বাসের অভাবে বাবা গুরুত্ব দেন না।"
      },
      "choiceB": {
        "en": "Use 'I-Message Tool': 'I feel passionate about science, and joining will help my high school exams.'",
        "bn": "'আমি-বার্তা' দিয়ে স্পষ্ট যুক্তি তুলে ধরা।"
      },
      "resultB": {
        "en": "Demonstrates clear purpose, opening constructive dialogue.",
        "bn": "বাবা রাজি হন এবং পড়ার পথ খোলে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "In-App 'I-Message' Builder: Practice: 'I feel [emotion] when [situation], and I would like [desired action].'",
        "Non-Verbal Checklist: Upright posture, steady eye contact, and calm vocal tone.",
        "Audio Speech Recorder: Record and play back practice requests inside the app to test clarity."
      ],
      "bn": [
        "'আমি-বার্তা' চর্চা: নিজের অনুভূতি ও প্রয়োজন শান্তভাবে প্রকাশ করো।",
        "শারীরিক অঙ্গভঙ্গি: সোজা দাঁড়াও এবং শান্ত দৃষ্টিতে তাকাও।",
        "রেকর্ড করে শোনা: নিজের কণ্ঠ কতটা আত্মবিশ্বাসী তা অ্যাপে রেকর্ড করে শোনো।"
      ]
    },
    "keyTakeaway": {
      "en": "Assertive speaking conveys personal needs with calm respect. Use 'I-messages' to be heard clearly.",
      "bn": "শান্ত অথচ স্পষ্ট কথা নিজের আত্মসম্মান বাড়ায় এবং অপরকে সম্মান দেয়।"
    }
  },
  {
    "id": 5,
    "phase": 2,
    "phaseTitle": {
      "en": "Communication, Teamwork & Healthy Boundaries",
      "bn": "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা"
    },
    "category": "communication",
    "emoji": "👂",
    "title": {
      "en": "Active Listening & Respecting Diversity",
      "bn": "মনোযোগ দিয়ে শোনা ও বৈচিত্র্যকে সম্মান"
    },
    "summary": {
      "en": "Cultivate empathy and active listening to construct inclusive relationships across diverse backgrounds.",
      "bn": "সহমর্মিতা ও গভীর মনোযোগ দিয়ে শোনার অভ্যাস গড়ে তুলে সৌহার্দ্য রক্ষা করা।"
    },
    "content": {
      "en": [
        "During a community project, Salma from a minority hamlet is interrupted, but 14-year-old Kavita steps in to ensure Salma is heard completely.",
        "Active listening involves giving undivided focus, withholding immediate judgment, and validating perspectives.",
        "UNICEF emphasizes empathy and tolerance as foundations for peaceful coexistence and strong friendships.",
        "Respecting diverse backgrounds enriches discussions and helps communities solve problems collectively."
      ],
      "bn": [
        "একটি সামাজিক কাজে সালমার কথা মাঝপথে থামিয়ে দেওয়া হলে কবিতা সবার সামনে সালমার সম্পূর্ণ বক্তব্য শুনতে অনুরোধ করে।",
        "মন দিয়ে শোনার অর্থ হলো কাউকে বিচার না করে পুরো মনোযোগ দিয়ে তার কথা বোঝা।",
        "সহমর্মিতা বিভিন্ন পটভূমির মানুষের মধ্যে সেতু তৈরি করে।",
        "সবার মতামত শুনলে দল আরও শক্তিশালী হয় এবং নতুন সমাধান মেলে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "A peer from a different background speaks during a group meeting.",
        "bn": "দলের বৈঠকে ভিন্ন পাড়ার একজন বন্ধু পরামর্শ দিচ্ছে।"
      },
      "choiceA": {
        "en": "Interrupt her to push your own plan forward.",
        "bn": "তাকে থামিয়ে দিয়ে নিজের মত চাপিয়ে দেওয়া।"
      },
      "resultA": {
        "en": "Creates group division and excludes diverse ideas.",
        "bn": "দলে বিভেদ সৃষ্টি হয় এবং ভালো আইডিয়া বাদ পড়ে।"
      },
      "choiceB": {
        "en": "Apply the '3-Step Active Listening Tool' (Focus, Summarize, Validate).",
        "bn": "'মনোযোগ, সারসংক্ষেপ ও স্বীকৃতি' নীতি প্রয়োগ করা।"
      },
      "resultB": {
        "en": "Builds empathy, strengthens group cohesion, and discovers better plans.",
        "bn": "বন্ধুত্ব বাড়ে এবং সেরা পরিকল্পনা তৈরি হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Active Listening 3-Step: 1. Focus, 2. Reflect ('What I hear you saying is...'), 3. Validate feelings.",
        "Inclusion Assessment Scale: Evaluate your interactions with peers from different communities.",
        "Empathy Role-Play: Complete scenarios reflecting on diverse lived experiences."
      ],
      "bn": [
        "সক্রিয় শোনার ৩ ধাপ: পুরো মন দাও, গুছিয়ে পুনরাবৃত্তি করো এবং অনুভূতিকে সম্মান দাও।",
        "অন্তর্ভুক্তির অভ্যাস: সব মানুষের সাথে সমান আন্তরিক থাকার চেষ্টা করো।",
        "সহমর্মিতার গল্প: অন্যের স্থানে নিজেকে বসিয়ে ভাবো।"
      ]
    },
    "keyTakeaway": {
      "en": "Active listening requires undivided attention. Respecting diversity enriches everyone's understanding.",
      "bn": "মন দিয়ে শোনার অর্থ হলো সম্মান জানানো। বৈচিত্র্য সমাজকে সুন্দর করে।"
    }
  },
  {
    "id": 6,
    "phase": 2,
    "phaseTitle": {
      "en": "Communication, Teamwork & Healthy Boundaries",
      "bn": "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা"
    },
    "category": "communication",
    "emoji": "🤝",
    "title": {
      "en": "Teamwork & Group Dynamics",
      "bn": "দলগত কাজ ও যৌথ নেতৃত্ব"
    },
    "summary": {
      "en": "Develop collaborative competencies to participate effectively in Adolescent Circles, committees, and teams.",
      "bn": "কিশোরী সভা, কমিটি ও সামাজিক কার্যক্রমে যৌথভাবে কাজ করার নেতৃত্ব দক্ষতা বৃদ্ধি।"
    },
    "content": {
      "en": [
        "When an Adolescent Circle gathers to solve mosquito breeding around a village tap, competing demands cause chaos.",
        "15-year-old Meera assigns distinct roles: Contributor (gathers facts), Supporter (encourages members), and Mediator (resolves disagreements).",
        "Working as a team converts isolated individual struggles into collective community advocacy.",
        "Clear ground rules, fair task distribution, and mutual respect produce impactful community results."
      ],
      "bn": [
        "গ্রামের পানীয় জলের জায়গায় মশা বংশবৃদ্ধি রোধ করতে গিয়ে শুরুতে সবাই একসাথে চিৎকার করছিল।",
        "১৫ বছর বয়সী মীনা দায়িত্ব ভাগ করে দিল: তথ্য সংগ্রহকারী, দল সমর্থক ও মধ্যস্থতাকারী।",
        "একতাবদ্ধ দলগত প্রচেষ্টা যে কোনো বড় সমস্যা সমাধানে বড় শক্তি এনে দেয়।",
        "পরস্পরকে সম্মান দিয়ে কাজ করলে পুরো গ্রামের উন্নতি সম্ভব।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "The Adolescent Circle must present a clean water petition to village elders.",
        "bn": "কিশোরী দলটিকে পঞ্চায়েতের কাছে পরিষ্কার জলের আবেদন করতে হবে।"
      },
      "choiceA": {
        "en": "Let one person do everything alone without telling the group.",
        "bn": "সব কাজ একজনকে একা করতে দেওয়া।"
      },
      "resultA": {
        "en": "Task overload, stress, and uncompleted petition.",
        "bn": "ক্লান্তি বাড়ে এবং আবেদন জমা পড়ে না।"
      },
      "choiceB": {
        "en": "Assign team roles using the Sakhi Task Allocation Tool.",
        "bn": "দলে কাজের দায়িত্ব সমানভাবে বণ্টন করা।"
      },
      "resultB": {
        "en": "Organized advocacy leading to successful community action.",
        "bn": "সফলভাবে আবেদন মঞ্জুর হয় এবং সমস্যার সমাধান হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Team Role Selector: Assign structured roles (Contributor, Supporter, Mediator).",
        "Group Ground Rules: Establish equal airtime and zero put-downs before meetings.",
        "Collaborative Goal Tracker: Monitor progress on joint tasks using the shared checklist."
      ],
      "bn": [
        "ভূমিকা নির্বাচন: দলে কাজের দায়িত্ব নির্দিষ্ট করে দাও।",
        "দলের নিয়ম: সবাইকে কথা বলার সুযোগ দাও এবং কাউকে ছোট করো না।",
        "যৌথ কাজের তালিকা: সবাই মিলে অগ্রগতি পরীক্ষা করো।"
      ]
    },
    "keyTakeaway": {
      "en": "Teamwork pools diverse strengths. Structured roles turn individual efforts into collective power.",
      "bn": "একতায় বল। দায়িত্ব ভাগ করে কাজ করলে অসম্ভবও সম্ভব হয়।"
    }
  },
  {
    "id": 7,
    "phase": 2,
    "phaseTitle": {
      "en": "Communication, Teamwork & Healthy Boundaries",
      "bn": "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা"
    },
    "category": "communication",
    "emoji": "🛡️",
    "title": {
      "en": "Setting Healthy Personal Boundaries",
      "bn": "সুস্থ ব্যক্তিগত সীমানা নির্ধারণ"
    },
    "summary": {
      "en": "Identify personal boundaries and assertively protect physical, emotional, and digital personal space.",
      "bn": "ব্যক্তিগত সীমানা চেনা এবং নিজের শরীর ও মানসিক শান্তি দৃঢ়ভাবে রক্ষা করা।"
    },
    "content": {
      "en": [
        "An older acquaintance sits uncomfortably close to 13-year-old Geeta on the bus and reaches for her notebook.",
        "Geeta feels sick with anxiety. Her mentor clarifies: 'Discomfort is your body's signal that a boundary is crossed. Protecting your safety is never disrespectful.'",
        "Setting boundaries means stating clearly what is acceptable and what must stop immediately.",
        "Adolescent girls possess full entitlement to bodily autonomy and emotional safety without guilt or apology."
      ],
      "bn": [
        "বাসে একজন পরিচিত ব্যক্তি ১৩ বছর বয়সী গীতার খুব কাছাকাছি বসে তার নোটবুক নেওয়ার চেষ্টা করায় গীতা ভয় পেয়ে যায়।",
        "মেন্টর গীতাকে বোঝান: 'ভয় বা অস্বস্তি লাগা মানে তোমার ব্যক্তিগত সীমানা লঙ্ঘন হচ্ছে। নিজের সুরক্ষা রক্ষা করা কখনো বেয়াদবি নয়।'",
        "সীমানা নির্ধারণের অর্থ হলো কোনটি গ্রহণযোগ্য আর কোনটি বন্ধ করতে হবে তা স্পষ্ট করে বলা।",
        "নিজের শরীর ও ব্যক্তিগত জায়গার ওপর সম্পূর্ণ অধিকার একমাত্র তোমার নিজের।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "The acquaintance sits uncomfortably close and reaches for Geeta's notebook.",
        "bn": "ব্যক্তিটি গীতার গা ঘেঁষে বসে তার ডায়েরি টানার চেষ্টা করে।"
      },
      "choiceA": {
        "en": "Move away quietly, stay silent, and blame yourself.",
        "bn": "চুপচাপ সরে গিয়ে নিজেকে দোষ দেওয়া।"
      },
      "resultA": {
        "en": "Boundary violation continues unchecked and increases fear.",
        "bn": "অসদাচরণ বাড়তেই থাকে এবং ভয় বৃদ্ধি পায়।"
      },
      "choiceB": {
        "en": "Execute the 3-Step Refusal Script: 'I am uncomfortable. This is my private space. Please move.'",
        "bn": "দৃঢ় গলায় বলা: 'আমার অস্বস্তি হচ্ছে। এটা আমার ব্যক্তিগত জায়গা। দয়া করে সরে বসুন।'"
      },
      "resultB": {
        "en": "Asserts clear boundaries and deters further intrusion.",
        "bn": "ব্যক্তিটি সরে যায় এবং নিজের নিরাপত্তা বজায় থাকে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "3-Step Refusal Script: 1. State the Boundary ('I am uncomfortable'), 2. State Reason ('This is private'), 3. Direct Action ('Step back').",
        "Body Warning Cues Tracker: Log physical discomfort cues (tight chest, butterfly feeling) to act early.",
        "Escalation Support Mapper: Save contacts to alert trusted adults if boundaries are breached."
      ],
      "bn": [
        "৩ ধাপের না বলা: ১. অস্বস্তি প্রকাশ করো, ২. কারণ বলো, ৩. পরিষ্কার নির্দেশ দাও সরে যাওয়ার।",
        "শরীরের সংকেত: ভয় পেলে বা অস্বস্তি লাগলে সাথে সাথে সতর্ক হও।",
        "জরুরি নম্বর: কোনো সমস্যা হলে নির্ভরযোগ্য বড়দের ফোন করো।"
      ]
    },
    "keyTakeaway": {
      "en": "Your personal space belongs to you. Saying 'No' to discomfort is a healthy exercise of your rights.",
      "bn": "তোমার শরীর তোমার নিজস্ব। অস্বস্তিকর পরিস্থিতিতে 'না' বলার পূর্ণ অধিকার তোমার আছে।"
    }
  },
  {
    "id": 8,
    "phase": 3,
    "phaseTitle": {
      "en": "Emotion Regulation, Stress & Resilience",
      "bn": "আবেগ নিয়ন্ত্রণ, মানসিক চাপ ও সহনশীলতা"
    },
    "category": "resilience",
    "emoji": "🧘",
    "title": {
      "en": "Managing Emotions & Feelings",
      "bn": "অনুভূতি ও তীব্র আবেগ নিয়ন্ত্রণ"
    },
    "summary": {
      "en": "Identify and regulate intense emotions, preventing destructive outlets such as lashing out or self-isolation.",
      "bn": "তীব্র রাগ বা দুঃখ নিয়ন্ত্রণ করে নিজেকে আঘাত করা বা অন্যদের ওপর ক্ষোভ ঝাড়ার ক্ষতি থেকে রক্ষা পাওয়া।"
    },
    "content": {
      "en": [
        "14-year-old Reena scores poorly on an exam and has an immediate impulse to smash her desk lamp and scream at her sister.",
        "Her older sister calms her: 'Freeze. Take two slow breaths. Disappointment is natural, but throwing things hurts our family. Pause, name the emotion, and choose a safe outlet.'",
        "WHO mental health guidelines note that rapid adolescent growth frequently intensifies emotional reactions.",
        "Practicing the 4-step sequence (Pause, Breathe, Name, Choose) builds lasting emotional mastery."
      ],
      "bn": [
        "১৪ বছর বয়সী রীনা পরীক্ষায় খারাপ করায় টেবিলের ল্যাম্প ভেঙে বোনকে মারতে উদ্যত হলো।",
        "তার বড় বোন হাত ধরে বলল: 'থামো, দুইবার গভীর শ্বাস নাও। খারাপ লাগা স্বাভাবিক, কিন্তু ভাঙচুর সমাধান নয়। আগে রাগটা শান্ত করো।'",
        "বয়ঃসন্ধিকালে হরমোনের পরিবর্তনের কারণে তীব্র আবেগ আসা স্বাভাবিক।",
        "থামা, শ্বাস নেওয়া, অনুভূতি চেনা এবং সঠিক কাজ বেছে নেওয়া—এই ৪টি ধাপ মনকে শান্ত রাখে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Reena feels overwhelming rage over low exam results.",
        "bn": "পরীক্ষার ফলে রীনা প্রচণ্ড রাগে ফেটে পড়ে।"
      },
      "choiceA": {
        "en": "Throw books, yell at her sister, and lock herself in a room.",
        "bn": "বইপত্র ছুড়ে ফেলা এবং ঘরে নিজেকে বন্দি করা।"
      },
      "resultA": {
        "en": "Escalates family conflict and damages self-esteem.",
        "bn": "পারিবারিক অশান্তি বাড়ে এবং মন খারাপ দীর্ঘস্থায়ী হয়।"
      },
      "choiceB": {
        "en": "Open the '4-Step Calming Tool' (Pause, Breathe, Name, Choose).",
        "bn": "'৪ ধাপের শান্ত হওয়া' পদ্ধতি প্রয়োগ করে গভীর শ্বাস নেওয়া।"
      },
      "resultB": {
        "en": "Lowers heart rate and enables constructive reflection.",
        "bn": "হৃৎস্পন্দন শান্ত হয় এবং পুনরায় পড়ার উদ্যম মেলে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "4-Step Calming Tool: Pause movement, Take 4-7-8 breaths, Name the feeling, Choose a constructive outlet.",
        "Personal Trigger Journal: Document recurring frustration triggers (academic pressure, noise).",
        "Constructive Outlets: Use brisk walking, drawing, or journaling when emotions rise."
      ],
      "bn": [
        "শান্ত হওয়ার ৪ ধাপ: নড়াচড়া থামাও, গভীর শ্বাস নাও, অনুভূতিকে নাম দাও, এবং নিরাপদ কাজ বেছে নাও।",
        "রাগের কারণ লেখা: কোন কথায় তোমার রাগ হয় তা লিখে রাখো।",
        "ইতিবাচক উপায়: রাগ হলে একটু হেঁটে এসো, ছবি আঁকো বা জল খাও।"
      ]
    },
    "keyTakeaway": {
      "en": "Pausing creates space between an emotional impulse and constructive action. Control your reactions.",
      "bn": "রাগ ওঠা স্বাভাবিক, কিন্তু তা প্রকাশ করার ইতিবাচক পথ বেছে নেওয়াই আসল বুদ্ধি।"
    }
  },
  {
    "id": 9,
    "phase": 3,
    "phaseTitle": {
      "en": "Emotion Regulation, Stress & Resilience",
      "bn": "আবেগ নিয়ন্ত্রণ, মানসিক চাপ ও সহনশীলতা"
    },
    "category": "resilience",
    "emoji": "⏳",
    "title": {
      "en": "Coping with Stress & Everyday Challenges",
      "bn": "মানসিক চাপ ও দৈনন্দিন চ্যালেঞ্জ মোকাবেলা"
    },
    "summary": {
      "en": "Develop practical coping strategies to navigate academic pressure, family duties, and social expectations.",
      "bn": "পড়ালেখার চাপ, সংসারের কাজ এবং সামাজিক প্রত্যাশার মধ্যে সুষম ভারসাম্য তৈরি করা।"
    },
    "content": {
      "en": [
        "16-year-old Anita feels crushed trying to wake up at 4 AM for chores, attend school, and study until midnight.",
        "She contemplates dropping out. Her Sakhi leader cautions: 'Dropping out is a permanent reaction to temporary pressure. Break your schedule into smaller blocks and ask family to share chores.'",
        "UNICEF life skills frameworks contrast positive coping (time management, support-seeking) with negative coping (dropping out, isolation).",
        "Segmenting tasks and asking for support are signs of strength that preserve educational progress."
      ],
      "bn": [
        "১৬ বছর বয়সী অনিতা ভোর ৪টায় উঠে ঘরের কাজ, তারপর স্কুল এবং রাতে পড়ার চাপে স্কুল ছেড়ে দেওয়ার কথা ভাবে।",
        "তার সখী লিডার বোঝাল: 'সাময়িক চাপের কারণে স্থায়ী ভুল সিদ্ধান্ত নিয়ো না। পড়ার সময় ভাগ করো এবং পরিবারের সাথে কাজ ভাগ করে নাও।'",
        "সঠিক পরিকল্পনা ও সাহায্য চাওয়া হলো ইতিবাচকভাবে চাপ সামলানোর সেরা উপায়।",
        "পড়াশোনা ছোট ছোট ধাপে ভাগ করলে মানসিক চাপ কমে যায়।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Anita feels overwhelmed by chores and exam prep.",
        "bn": "অনিতা পড়াশোনা ও ঘরের কাজের চাপে দিশেহারা হয়ে পড়ে।"
      },
      "choiceA": {
        "en": "Stop attending school and isolate at home.",
        "bn": "স্কুল যাওয়া বন্ধ করে ঘরে একা বসে থাকা।"
      },
      "resultA": {
        "en": "Permanent educational loss and increased vulnerability.",
        "bn": "পড়াশোনার ক্ষতি হয় এবং ভবিষ্যৎ অনিশ্চিত হয়ে পড়ে।"
      },
      "choiceB": {
        "en": "Use Daily Routine Planner to study in 30-minute blocks and ask siblings to share chores.",
        "bn": "৩০ মিনিটের পড়ার রুটিন তৈরি করা এবং ভাইবোনদের কাজে হাত লাগাতে বলা।"
      },
      "resultB": {
        "en": "Reduces anxiety, restores sleep, and preserves academic progress.",
        "bn": "উদ্বেগ কমে, পর্যাপ্ত ঘুম হয় এবং পড়াশোনা সুন্দরভাবে চলে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Time Structuring Grid: Allocate dedicated blocks for study, chores, rest, and sleep.",
        "Task Breakdown Checklist: Divide large academic topics into 15-minute manageable tasks.",
        "Peer Support Hub: Connect with peers to share stress-management tips."
      ],
      "bn": [
        "সময়সূচির তালিকা: পড়া, কাজ ও বিশ্রামের জন্য আলাদা সময় রাখো।",
        "ছোট ছোট ভাগে পড়া: বড় অধ্যায়কে ১৫ মিনিটের ছোট অংশে ভাগ করে পড়ো।",
        "বন্ধুদের সাথে আলোচনা: মানসিক চাপ হলে বন্ধুদের সাথে ভাগ করে নাও।"
      ]
    },
    "keyTakeaway": {
      "en": "Positive coping breaks big pressures into structured daily steps. Never sacrifice your education for temporary stress.",
      "bn": "সাময়িক চাপের কাছে হার মানবে না। কাজের সঠিক রুটিন ও বিশ্রামই সাফল্যের চাবিকাঠি।"
    }
  },
  {
    "id": 10,
    "phase": 3,
    "phaseTitle": {
      "en": "Emotion Regulation, Stress & Resilience",
      "bn": "আবেগ নিয়ন্ত্রণ, মানসিক চাপ ও সহনশীলতা"
    },
    "category": "resilience",
    "emoji": "🌱",
    "title": {
      "en": "Building Resilience & Overcoming Adversity",
      "bn": "সহনশীলতা ও প্রতিকূলতা জয়"
    },
    "summary": {
      "en": "Strengthen resilience to recover from adversity, calamity, or disruption and return to a stable state of agency.",
      "bn": "দুর্যোগ ও কঠিন পরিস্থিতিতে মানসিক শক্তি বজায় রেখে ঘুরে দাঁড়ানোর ক্ষমতা অর্জন।"
    },
    "content": {
      "en": [
        "15-year-old Pooja's family loses their roadside shop during a seasonal flood and relocates to a temporary shelter.",
        "Pooja weeps that her future is ruined. Her mentor reminds her: 'The flood destroyed the shop, but not your intelligence. Resilience means taking small daily steps to rebuild.'",
        "UNICEF India defines resilience as the psychosocial capacity to recover from calamity and regain stability through perseverance and community connection.",
        "Focusing on what you can control rather than what you lost restores hope and momentum."
      ],
      "bn": [
        "বন্যায় পূজা ও তার পরিবারের ছোট্ট দোকানটি ভেসে যাওয়ায় তারা আশ্রয়কেন্দ্রে আশ্রয় নেয়। পূজা কাঁদতে থাকে যে তার পড়াশোনা শেষ।",
        "তার মেন্টর বলে: 'বন্যা দোকান ভাসিয়ে নিয়েছে, কিন্তু তোমার মেধা ও স্বপ্নকে নয়। প্রতিদিন ছোট ছোট পদক্ষেপে আবার শুরু করো।'",
        "ইউনিসেফ অনুযায়ী সহনশীলতা হলো কঠিন পরিস্থিতি কাটিয়ে নতুন করে এগিয়ে যাওয়ার মানবিক ক্ষমতা।",
        "যা আমাদের নিয়ন্ত্রণে আছে তার ওপর মন দিলে সব প্রতিকূলতা জয় করা সম্ভব।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Pooja faces severe study disruptions in a flood shelter.",
        "bn": "আশ্রয়কেন্দ্রে পূজার পড়াশোনা ব্যাহত হচ্ছে।"
      },
      "choiceA": {
        "en": "Assume her educational journey is over and give up reading.",
        "bn": "ধরে নেওয়া পড়াশোনা শেষ এবং হাল ছেড়ে দেওয়া।"
      },
      "resultA": {
        "en": "Deepens helplessness and leads to long-term dropout.",
        "bn": "হতাশা বাড়ে এবং পড়ার সুযোগ নষ্ট হয়।"
      },
      "choiceB": {
        "en": "Apply 'Resilience Mindset Tool' (Focus on Controllables, organize Shelter Study Group).",
        "bn": "আশ্রয়কেন্দ্রে অন্য মেয়েদের নিয়ে পড়ার দল তৈরি করা।"
      },
      "resultB": {
        "en": "Adapts to crisis, maintains study habits, and builds peer support.",
        "bn": "সংকট মোকাবিলা করে পড়াশোনা চালু থাকে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Controllables vs. Uncontrollables Matrix: Separate worries into what you can influence (effort, study) vs. what you cannot (weather).",
        "Resilience Mindset Shift: Repeat: 'This setback is temporary, and I can take one small step today.'",
        "Crisis Resource Finder: Connect with local aid committees and school schemes."
      ],
      "bn": [
        "নিয়ন্ত্রণযোগ্য বিষয়ের ছক: যা তোমার হাতে আছে (চেষ্টা, বই পড়া) সেদিকে মন দাও।",
        "ইতিবাচক সংকল্প: 'এই কঠিন সময় সাময়িক, আমি আজ এক ধাপ এগোব।'—মনে রাখো।",
        "সাহায্য কেন্দ্র: সরকারি সাহায্য ও শিক্ষকদের সাথে যোগাযোগ রাখো।"
      ]
    },
    "keyTakeaway": {
      "en": "Resilience is taking small daily steps forward during hardship. Disruption cannot extinguish your potential.",
      "bn": "প্রতিকূলতার মাঝেও প্রতিদিন এক পা করে এগোনোই আসল সহনশীলতা। কোনো ঝড় তোমার মেধা কেড়ে নিতে পারে না।"
    }
  },
  {
    "id": 11,
    "phase": 4,
    "phaseTitle": {
      "en": "Decision Making, Goal Planning & Negotiation",
      "bn": "দূরদর্শী সিদ্ধান্ত, লক্ষ্য নির্ধারণ ও আলোচনা"
    },
    "category": "decision-making",
    "emoji": "🧭",
    "title": {
      "en": "Critical Thinking & Evaluating Choices",
      "bn": "গঠনমূলক চিন্তাভাবনা ও সিদ্ধান্ত মূল্যায়ন"
    },
    "summary": {
      "en": "Apply critical thinking to analyze information objectively, evaluate choices, and reject gender stereotypes.",
      "bn": "কুসংস্কার ও গুজবের বাইরে গিয়ে তথ্য বিশ্লেষণ করে সঠিক সিদ্ধান্ত নেওয়ার ক্ষমতা অর্জন।"
    },
    "content": {
      "en": [
        "15-year-old Suman's relatives insist completing Grade 10 is unnecessary for girls, while her teacher presents vocational education options.",
        "Her teacher shares facts: India's Female Labour Force Participation dropped partly because decisions were made for girls rather than by them. Secondary education protects health and independence.",
        "Suman asks how to know who to trust. Her teacher explains: 'Critical thinking means asking: Is this advice based on verified facts, or traditional stereotypes?'",
        "Analyzing pros, cons, and long-term autonomy helps girls make decisions that secure their future."
      ],
      "bn": [
        "সুমনকে আত্মীয়রা বলছিল দশম শ্রেণি পাসের কোনো দরকার নেই, কিন্তু শিক্ষক তাকে উচ্চশিক্ষা ও কাজের সুযোগের কথা বললেন।",
        "শিক্ষক দেখালেন যে পড়াশোনা সম্পন্ন করলে মেয়েদের স্বাধীনতা ও স্বাবলম্বী হওয়ার সুযোগ বহুগুণ বাড়ে।",
        "কীভাবে সিদ্ধান্ত নিতে হয় জানতে চাইলে শিক্ষক বললেন: গঠনমূলক চিন্তা মানে যাচাই করা—পরামর্শটি কি তথ্যের ওপর দাঁড়িয়ে নাকি অন্ধবিশ্বাসের ওপর?",
        "লাভ-ক্ষতি ও ভবিষ্যতের স্বাধীনতা বিচার করে সিদ্ধান্ত নেওয়াই দূরদর্শিতা।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Suman evaluates whether to drop out after Grade 8 or continue to secondary school.",
        "bn": "সুমন অষ্টম শ্রেণির পর পড়া ছাড়বে নাকি পড়াশোনা চালিয়ে যাবে তা নিয়ে দ্বিধায় পড়ে।"
      },
      "choiceA": {
        "en": "Accept relatives' advice without analyzing economic impacts.",
        "bn": "অর্থনৈতিক পরিণতি না ভেবে আত্মীয়দের কথায় পড়া ছাড়া।"
      },
      "resultA": {
        "en": "High risk of early marriage and financial dependence.",
        "bn": "বাল্যবিয়ে ও পরনির্ভরশীলতার ঝুঁকি বাড়ে।"
      },
      "choiceB": {
        "en": "Run choices through the 'Decision-Making Analysis Grid'.",
        "bn": "'সিদ্ধান্ত বিশ্লেষণ ছক' ব্যবহার করে দীর্ঘমেয়াদী লাভ দেখা।"
      },
      "resultB": {
        "en": "Identifies long-term independence benefits and builds rational choice.",
        "bn": "পড়াশোনা চালিয়ে যাওয়ার স্পষ্ট যুক্তি খুঁজে পায়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Decision Analysis Grid: Compare options across immediate pros, cons, and impact on autonomy.",
        "Bias Detector: Identify hidden gender stereotypes in everyday comments.",
        "Fact vs. Opinion Sorter: Distinguish between objective facts and cultural assumptions."
      ],
      "bn": [
        "সিদ্ধান্ত ছক: তাৎক্ষণিক আরাম বনাম ভবিষ্যতের স্বাধীনতার তুলনা করো।",
        "পক্ষপাতিত্ব চেনা: দৈনন্দিন কথায় লুকিয়ে থাকা লিঙ্গবৈষম্য চিহ্নিত করো।",
        "সত্য বনাম মতামত: বৈজ্ঞানিক সত্য আর লোকমুখের ধারণার পার্থক্য বোঝো।"
      ]
    },
    "keyTakeaway": {
      "en": "Critical thinking evaluates facts over stereotypes. Make decisions that protect your future independence.",
      "bn": "কুসংস্কার নয়, তথ্যের ওপর ভিত্তি করে সিদ্ধান্ত নাও। নিজের ভবিষ্যতের দায়িত্ব নিজেই নাও।"
    }
  },
  {
    "id": 12,
    "phase": 4,
    "phaseTitle": {
      "en": "Decision Making, Goal Planning & Negotiation",
      "bn": "দূরদর্শী সিদ্ধান্ত, লক্ষ্য নির্ধারণ ও আলোচনা"
    },
    "category": "decision-making",
    "emoji": "🚀",
    "title": {
      "en": "Goal Setting & Planning for the Future",
      "bn": "ভবিষ্যৎ লক্ষ্য নির্ধারণ ও পরিকল্পনা"
    },
    "summary": {
      "en": "Formulate realistic, actionable education and career goals using the SMART framework.",
      "bn": "SMART পদ্ধতির সাহায্যে সুনির্দিষ্ট লক্ষ্য স্থির করে স্বাবলম্বী হওয়ার পথে এগিয়ে চলা।"
    },
    "content": {
      "en": [
        "16-year-old Rekha dreams of becoming a solar equipment technician, but neighbors say technical repair is only for men.",
        "Her mentor shows her data that technical skills open real economic self-reliance. Rekha learns to turn her ambition into a SMART goal.",
        "SMART goals are Specific, Measurable, Achievable, Relevant, and Time-bound.",
        "Breaking broad ambitions into weekly milestones bridges current realities with financial independence."
      ],
      "bn": [
        "১৬ বছর বয়সী রেখা সোলার প্যানেল টেকনিশিয়ান হতে চায়, কিন্তু পাড়ার লোক বলে এটা মেয়েদের কাজ নয়।",
        "সখী মেন্টর তাকে বোঝায় যে প্রযুক্তি ও কারিগরি শিক্ষা মেয়েদের সবচেয়ে বেশি স্বনির্ভর করে।",
        "SMART লক্ষ্য হলো: নির্দিষ্ট, পরিমাপযোগ্য, অর্জনযোগ্য, প্রাসঙ্গিক এবং সময়সীমার সাথে যুক্ত।",
        "বড় স্বপ্নকে ছোট ছোট সাপ্তাহিক ধাপে ভাগ করলে লক্ষ্য ছোঁয়া সহজ হয়।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Rekha maps out her plan to enroll in a vocational training institute.",
        "bn": "রেখা কারিগরি প্রশিক্ষণ কোর্সে ভর্তির পরিকল্পনা করে।"
      },
      "choiceA": {
        "en": "Keep her ambition vague ('I want to work in tech someday') with no dates.",
        "bn": "কোনো তারিখ বা পরিকল্পনা ছাড়া স্বপ্ন দেখা।"
      },
      "resultA": {
        "en": "Progress stalls due to lack of structure.",
        "bn": "বাস্তবায়ন হয় না এবং স্বপ্ন অধরা থেকে যায়।"
      },
      "choiceB": {
        "en": "Input a structured SMART Goal template into the Sakhi App.",
        "bn": "SMART পদ্ধতিতে নির্দিষ্ট সময়সীমা দিয়ে রুটিন তৈরি করা।"
      },
      "resultB": {
        "en": "Creates clear weekly milestones for exam prep and enrollment.",
        "bn": "সঠিক সময়ে প্রস্তুতি নিয়ে কোর্সে ভর্তি হওয়া সম্ভব হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "SMART Goal Builder: S-Specific, M-Measurable, A-Achievable, R-Relevant, T-Time-bound.",
        "Milestone Roadmap: Track weekly targets with a progress bar.",
        "Resource Hub: Map vocational scholarships and computer centers in your area."
      ],
      "bn": [
        "SMART লক্ষ্য তৈরি: নির্দিষ্ট, পরিমাপযোগ্য, বাস্তবসম্মত ও সময়াবদ্ধ লক্ষ্য লেখো।",
        "মাইলফলক ট্র্যাকার: প্রতি সপ্তাহের লক্ষ্য পূরণ হলে টিক দাও।",
        "সুযোগের সন্ধান: সরকারি স্কলারশিপ ও স্থানীয় কম্পিউটার সেন্টারের খোঁজ রাখো।"
      ]
    },
    "keyTakeaway": {
      "en": "Turn broad dreams into specific, time-bound milestones. Concrete planning breaks down barriers.",
      "bn": "স্বপ্নকে সুনির্দিষ্ট সময়সীমায় ভাগ করো। পরিকল্পনা থাকলে যেকোনো বাধা অতিক্রম করা সম্ভব।"
    }
  },
  {
    "id": 13,
    "phase": 4,
    "phaseTitle": {
      "en": "Decision Making, Goal Planning & Negotiation",
      "bn": "দূরদর্শী সিদ্ধান্ত, লক্ষ্য নির্ধারণ ও আলোচনা"
    },
    "category": "decision-making",
    "emoji": "🗣️",
    "title": {
      "en": "Negotiation, Assertiveness & Saying No",
      "bn": "আলোচনা, অধিকার রক্ষা ও 'না' বলার দক্ষতা"
    },
    "summary": {
      "en": "Master logic, persuasion, and assertive refusal skills to negotiate personal choices, postpone marriage, and stay in school.",
      "bn": "যুক্তি ও সাহসের সাথে বাল্যবিয়ে ঠেকানো, পড়াশোনা চালিয়ে যাওয়ার অধিকার আদায় এবং ক্ষতিকর প্রস্তাবে 'না' বলা।"
    },
    "content": {
      "en": [
        "16-year-old Farida learns her family is arranging her marriage before age 18. She wishes to finish school and become a nurse.",
        "Her mentor advises: 'Aggression destroys negotiation, and staying silent surrenders your future. Use logic, economic facts, and trusted allies like your school principal.'",
        "UNICEF defines negotiation as reaching agreements through facts and empathetic persuasion.",
        "Saying 'No' firmly to illegal or harmful proposals protects your bodily safety and constitutional rights."
      ],
      "bn": [
        "১৬ বছর বয়সী ফরিদা জানতে পারে তার ১৮ বছর হওয়ার আগেই বিয়ের কথাবার্তা চলছে, কিন্তু সে নার্সিং পড়তে চায়।",
        "মেন্টর বলল: 'চেঁচামেচি করলে কাজ হবে না, আবার চুপ থাকলেও ভবিষ্যৎ নষ্ট হবে। যুক্তি, অর্থনৈতিক লাভ এবং স্কুলের প্রধান শিক্ষকের মতো বড়দের সাথে নিয়ে আলোচনা করো।'",
        "আলোচনা হলো যুক্তি ও সহমর্মিতার মাধ্যমে পরিবারকে বোঝানোর শিল্প।",
        "ক্ষতিকর বা অন্যায্য প্রস্তাবে স্পষ্ট 'না' বলা তোমার সাংবিধানিক অধিকার।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Farida negotiates with parents to postpone marriage until age 20.",
        "bn": "ফরিদা ২০ বছর বয়স পর্যন্ত বিয়ে পিছিয়ে দেওয়ার জন্য বাবা-মায়ের সাথে আলোচনা করে।"
      },
      "choiceA": {
        "en": "React aggressively or run away from home.",
        "bn": "উগ্র আচরণ করা বা বাড়ি থেকে পালিয়ে যাওয়ার চেষ্টা করা।"
      },
      "resultA": {
        "en": "Escalates family crisis and loses community support.",
        "bn": "বিপদ বাড়ে এবং নির্ভরযোগ্য সাহায্য হারিয়ে যায়।"
      },
      "choiceB": {
        "en": "Use Negotiation Dialogue Script and involve her school principal.",
        "bn": "অর্থনৈতিক যুক্তি তুলে ধরে প্রধান শিক্ষককে সাথে নিয়ে আলোচনা করা।"
      },
      "resultB": {
        "en": "Presents logical arguments leading to parental agreement to delay marriage.",
        "bn": "বাবা-মা রাজি হন এবং নার্সিং পড়ার অনুমতি মেলে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Negotiation Script Generator: Practice: 'I understand your concern, but my education allows me to earn and support our family.'",
        "Ally Engagement: Involve respected teachers or Panchayat members to assist in family discussions.",
        "Assertive Refusal: Say 'No' firmly, state your reason, and refuse without apologizing for protecting your rights."
      ],
      "bn": [
        "আলোচনার বাক্য: 'আমি আপনাদের চিন্তা বুঝি, কিন্তু পড়া শেষ করলে আমি নিজে আয় করে সংসার চালাতে পারব।'—এভাবে বলো।",
        "বিশ্বস্ত মধ্যস্থতাকারী: শিক্ষক বা সচেতন মুরুব্বিদের সাথে নাও।",
        "দৃঢ় 'না': অন্যায্য প্রস্তাবে কোনো দ্বিধা ছাড়া শান্তভাবে নিজের অবস্থান জানাও।"
      ]
    },
    "keyTakeaway": {
      "en": "Negotiate with logic, economic facts, and respected allies. Stand firm in protecting your right to an education.",
      "bn": "যুক্তি ও বুদ্ধি দিয়ে আলোচনা করো। নিজের পড়াশোনা ও জীবনের সিদ্ধান্তের সাথে আপস করবে না।"
    }
  },
  {
    "id": 14,
    "phase": 5,
    "phaseTitle": {
      "en": "Puberty, Menstrual Health & Nutrition",
      "bn": "বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টি"
    },
    "category": "health-hygiene",
    "emoji": "🌺",
    "title": {
      "en": "Understanding Puberty & Physical Growth",
      "bn": "বয়ঃসন্ধিকাল ও শারীরিক বিকাশ"
    },
    "summary": {
      "en": "Demystify biological body transitions, hormonal shifts, and physical changes during adolescent development.",
      "bn": "বয়ঃসন্ধিকালে শরীরের স্বাভাবিক বৃদ্ধি, হরমোনের পরিবর্তন ও স্বাস্থ্যবিধি সম্পর্কে স্পষ্ট ধারণা লাভ।"
    },
    "content": {
      "en": [
        "12-year-old Lata notices breast changes, hip widening, and body odor, wearing a heavy winter shawl in the summer heat because she feels ashamed.",
        "Her mentor reassures her: 'You are not sick. WHO guidelines explain that hormones naturally trigger pubertal maturation between ages 10 and 14.'",
        "Primary health risks for early adolescents center on water, sanitation, and hygiene (WASH) deficiencies.",
        "Daily bathing with clean water, wearing clean dry cotton innerwear, and staying hydrated keep the body healthy and comfortable."
      ],
      "bn": [
        "১২ বছর বয়সী লতা নিজের শারীরিক পরিবর্তন ও গন্ধ নিয়ে লজ্জা পেয়ে গরমেও ভারী চাদর জড়িয়ে ঘুরছিল।",
        "মেন্টর তাকে বোঝাল যে ১০ থেকে ১৪ বছর বয়সে হরমোনের কারণে এই পরিবর্তন হওয়া সম্পূর্ণ স্বাভাবিক ও সুস্থতার লক্ষণ।",
        "বয়ঃসন্ধিকালে পরিচ্ছন্নতা ও সুস্বাস্থ্যের দিকে নজর রাখা সবচেয়ে জরুরি।",
        "নিয়মিত স্নান, পরিষ্কার সুতির অন্তর্বাস এবং পর্যাপ্ত জল পান শরীরকে সুস্থ রাখে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Lata feels embarrassed by pubertal changes and wants to skip school.",
        "bn": "লতা শারীরিক পরিবর্তনের কারণে লজ্জা পেয়ে স্কুল কামাই করতে চায়।"
      },
      "choiceA": {
        "en": "Stay home, avoid bathing, and hide under heavy clothing.",
        "bn": "বাড়ি বসে থাকা এবং ভারী পোশাকে নিজেকে লুকিয়ে রাখা।"
      },
      "resultA": {
        "en": "Increases hygiene health risks, skin infections, and emotional distress.",
        "bn": "চর্মরোগের ঝুঁকি বাড়ে এবং মন খারাপ হয়।"
      },
      "choiceB": {
        "en": "Open the Puberty Guide, practice daily hygiene, and talk to a female health mentor.",
        "bn": "হাইজিন গাইড দেখে নিয়মিত পরিচ্ছন্ন থাকা এবং মেন্টরের পরামর্শ নেওয়া।"
      },
      "resultB": {
        "en": "Normalizes body growth and maintains active school attendance.",
        "bn": "লজ্জা দূর হয় এবং আনন্দে স্কুলে যাওয়া সম্ভব হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Puberty Tracker: Explore normal biological changes (growth spurts, sweat glands, hair).",
        "WASH Checklist: Wash body daily with clean water and mild soap, wear dry cotton innerwear.",
        "Myth-Buster Hub: Access scientific facts debunking superstitious body growth taboos."
      ],
      "bn": [
        "পরিবর্তনের তথ্য: শারীরিক বৃদ্ধি সম্পর্কে বৈজ্ঞানিক জ্ঞান রাখো।",
        "পরিচ্ছন্নতার রুটিন: সাবান ও পরিষ্কার জল দিয়ে স্নান এবং শুকনো পোশাক পরো।",
        "কুসংস্কার দূরীকরণ: বড় হওয়ার ব্যাপারে অবৈজ্ঞানিক ধারণা বিশ্বাস করবে না।"
      ]
    },
    "keyTakeaway": {
      "en": "Puberty is a natural biological growth phase. Daily hygiene and scientific understanding eliminate shame.",
      "bn": "বয়ঃসন্ধিকাল জীবনের স্বাভাবিক বৃদ্ধির ধাপ। পরিচ্ছন্নতা বজায় রাখলে কোনো ভয় থাকে না।"
    }
  },
  {
    "id": 15,
    "phase": 5,
    "phaseTitle": {
      "en": "Puberty, Menstrual Health & Nutrition",
      "bn": "বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টি"
    },
    "category": "health-hygiene",
    "emoji": "🩸",
    "title": {
      "en": "Menstrual Health, Hygiene & Safe Practices",
      "bn": "মাসিক স্বাস্থ্য, পরিচ্ছন্নতা ও সঠিক অভ্যাস"
    },
    "summary": {
      "en": "Master hygienic management of menstruation, track menstrual cycles, and dismantle harmful social taboos.",
      "bn": "মাসিকের বৈজ্ঞানিক কারণ জানা, প্যাড ও কাপড়ের পরিচ্ছন্ন ব্যবহার এবং ক্ষতিকর কুসংস্কার দূর করা।"
    },
    "content": {
      "en": [
        "13-year-old Asha experiences her first period at school, terrified by myths that menstruating girls are 'impure'.",
        "Her Sakhi audio guide clarifies: 'Menstruation is simply the monthly shedding of the uterine lining. It is proof of a healthy reproductive system.'",
        "Hygienic management requires changing sanitary pads or clean cloth every 4–6 hours, washing with clean water, and drying reusable cloth pads in direct, open sunlight to kill bacteria.",
        "Dismantling taboos (like not touching food or staying out of school) ensures continuous education and dignified self-care."
      ],
      "bn": [
        "১৩ বছর বয়সী আশা স্কুলে প্রথম মাসিকের রক্ত দেখে ভয় পেয়ে যায় কারণ সে শুনেছিল এটি 'অশুচি'।",
        "সখী অ্যাপের গাইড তাকে বোঝায় যে মাসিক একটি স্বাভাবিক শারীরবৃত্তীয় প্রক্রিয়া, যা প্রমাণ করে শরীর সুস্থ।",
        "প্রতি ৪ থেকে ৬ ঘণ্টা পর পর প্যাড বা পরিষ্কার কাপড় বদলানো এবং কাপড় সবসময় কড়া রোদে শুকানো জরুরি যাতে জীবাণু ধ্বংস হয়।",
        "আচার-অনুষ্ঠানের কুসংস্কার ভেঙে স্বাভাবিক পুষ্টিকর খাবার খাওয়া ও স্কুলে যাওয়া স্বাস্থ্যকর জীবনের জন্য আবশ্যক।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Asha needs to dry her washed reusable cloth pad at home.",
        "bn": "আশাকে বাড়িতে ধোয়া কাপড়ের প্যাড শুকাতে হবে।"
      },
      "choiceA": {
        "en": "Hide the wet cloth under a dark mattress or bed in secret.",
        "bn": "লজ্জায় ভিজে কাপড়টি খাটের তলায় অন্ধকারে লুকিয়ে রাখা।"
      },
      "resultA": {
        "en": "Traps dangerous bacteria, leading to severe reproductive tract infections.",
        "bn": "জীবাণু জন্ম নেয় এবং মারাত্মক ইনফেকশন হওয়ার ঝুঁকি থাকে।"
      },
      "choiceB": {
        "en": "Hang the washed cloth pad in direct, open sunlight as instructed.",
        "bn": "খোলা জায়গায় কড়া রোদের আলোয় কাপড়টি মেলে দেওয়া।"
      },
      "resultB": {
        "en": "Direct sunlight sterilizes the cloth, ensuring hygienic safety.",
        "bn": "রোদের আল্ট্রাভায়োলেট রশ্মি জীবাণু মেরে ফেলে এবং সুরক্ষা নিশ্চিত করে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Menstrual Hygiene Rules: Change pads/cloths every 4–6 hours; wash genital area with clean water.",
        "Sunlight Drying: Always dry reusable cloth pads in direct sunlight to eliminate bacteria.",
        "Menstrual Cycle Tracker: Log your start dates to predict cycles (21–35 days typical).",
        "Safe Disposal: Wrap disposable pads in paper and place in waste bins—never flush."
      ],
      "bn": [
        "প্যাড বদল: ৪-৬ ঘণ্টা অন্তর পরিষ্কার প্যাড বা কাপড় ব্যবহার করো।",
        "রোদে শুকানো: কাপড়ের প্যাড সবসময় কড়া রোদে মেলে জীবাণুমুক্ত করো।",
        "তারিখের হিসাব: প্রতি মাসের তারিখ লিখে রাখো (সাধারণত ২১-৩৫ দিন পর পর)।",
        "সঠিক বর্জন: ব্যবহৃত প্যাড কাগজে মুড়ে ডাস্টবিনে ফেলো, কখনো ড্রেনে ফেলবে না।"
      ]
    },
    "keyTakeaway": {
      "en": "Menstruation is a healthy biological process. Hygienic practices and open sunlight drying protect your health.",
      "bn": "মাসিক কোনো লজ্জা বা অপবিত্রতা নয়। সঠিক পরিচ্ছন্নতা তোমাকে সুস্থ ও আত্মবিশ্বাসী রাখে।"
    }
  },
  {
    "id": 16,
    "phase": 5,
    "phaseTitle": {
      "en": "Puberty, Menstrual Health & Nutrition",
      "bn": "বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টি"
    },
    "category": "health-hygiene",
    "emoji": "🥗",
    "title": {
      "en": "Nutrition, Physical Health & Anemia Prevention",
      "bn": "পুষ্টি, শারীরিক স্বাস্থ্য ও রক্তস্বল্পতা প্রতিরোধ"
    },
    "summary": {
      "en": "Understand balanced nutrition, iron-rich dietary habits, and exercise to combat high adolescent anemia rates.",
      "bn": "পুষ্টিকর খাবার, আয়রন ও ভিটামিন সি সমৃদ্ধ খাদ্যতালিকা এবং অ্যানিমিয়া বা রক্তস্বল্পতা প্রতিরোধের উপায়।"
    },
    "content": {
      "en": [
        "15-year-old Seema experiences constant fatigue and dizziness during school assembly. A local health worker diagnoses iron-deficiency anemia.",
        "In many homes, girls eat last and least, receiving less iron and protein. Paired with menstrual blood loss, this triggers severe anemia.",
        "Eating local iron-rich foods (spinach, chana, jaggery/gud, dal) paired with Vitamin C (lemon, amla) maximizes iron absorption.",
        "Active daily movement (brisk walking, sports, yoga) alongside Weekly Iron and Folic Acid Supplementation (WIFS) boosts cognitive focus."
      ],
      "bn": [
        "১৫ বছর বয়সী সীমা স্কুলে দুর্বলতা ও মাথা ঘোরার সমস্যায় ভুগছিল। স্বাস্থ্য পরীক্ষায় দেখা গেল তার মারাত্মক রক্তস্বল্পতা বা অ্যানিমিয়া হয়েছে।",
        "অনেক পরিবারে মেয়েরা সবার শেষে খায় এবং কম পুষ্টিকর খাবার পায়। মাসিকের রক্তক্ষরণের সাথে আয়রনের অভাবে অ্যানিমিয়া দেখা দেয়।",
        "শাকসবজি (পালং শাক), ছোলা, গুড় ও ডালের সাথে পাতিলেবু বা আমলকী (ভিটামিন সি) খেলে শরীর সহজেই আয়রন শুষে নিতে পারে।",
        "নিয়মিত খেলাধুলো এবং আয়রন বড়ি (WIFS) খাওয়ার মাধ্যমে ক্লান্তি দূর করে পড়ায় মনোযোগ আনা যায়।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Seema chooses her daily meal items at home.",
        "bn": "সীমা নিজের দুপুরের খাবারের পদ বেছে নেয়।"
      },
      "choiceA": {
        "en": "Eat only leftover plain white rice and tea.",
        "bn": "শুধু বাসি ভাত আর চা খাওয়া।"
      },
      "resultA": {
        "en": "Tea inhibits iron absorption, worsening fatigue and anemia.",
        "bn": "চা আয়রন শোষণ আটকে দেয় এবং দুর্বলতা বাড়িয়ে তোলে।"
      },
      "choiceB": {
        "en": "Add local spinach (palak), Bengal gram (chana), and a squeeze of fresh lemon juice.",
        "bn": "শাক ও ছোলার সাথে একটু লেবুর রস মিশিয়ে খাওয়া।"
      },
      "resultB": {
        "en": "Maximizes plant iron absorption and rapidly boosts energy levels.",
        "bn": "শরীরে দ্রুত রক্ত তৈরি হয় এবং ক্লান্তি দূর হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Iron-Rich Foods: Green leafy vegetables (palak, methi), Bengal gram (chana), lentils (dal), jaggery (gud).",
        "Vitamin C Boosters: Always squeeze lemon or amla over meals to maximize iron uptake.",
        "WIFS Tracker: Log your Weekly Iron and Folic Acid Supplements from school or Anganwadi.",
        "Daily Movement: Maintain 30 minutes of daily physical sports or brisk walking."
      ],
      "bn": [
        "আয়রনযুক্ত খাবার: শাকসবজি, ছোলা, ডাল ও গুড় বেশি করে খাও।",
        "ভিটামিন সি: খাবারের সাথে লেবু বা আমলকী খেলে আয়রন শরীরে সহজে কাজে লাগে।",
        "আয়রন বড়ি: স্কুল বা স্বাস্থ্যকেন্দ্র থেকে দেওয়া সাপ্তাহিক আয়রন বড়ি নিয়ম করে খাও।",
        "ব্যায়াম: প্রতিদিন অন্তত ৩০ মিনিট হাঁটাহাঁটি বা খেলাধুলো করো।"
      ]
    },
    "keyTakeaway": {
      "en": "Pair plant iron with Vitamin C to fight anemia. Your body needs proper fuel to learn and thrive.",
      "bn": "লেবু ও শাকসবজি দিয়ে রক্তস্বল্পতা দূর করো। সুস্থ ও পুষ্টিকর খাবার তোমার পড়াশোনার মূল শক্তি।"
    }
  },
  {
    "id": 17,
    "phase": 6,
    "phaseTitle": {
      "en": "Rights, Protection, Helplines & Cyber Safety",
      "bn": "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা"
    },
    "category": "rights-safety",
    "emoji": "⚖️",
    "title": {
      "en": "Understanding Child Rights & Gender Equality",
      "bn": "শিশু অধিকার ও লিঙ্গ সমতা"
    },
    "summary": {
      "en": "Understand fundamental legal rights to protection, education, health, and participation without discrimination.",
      "bn": "আইনি সুরক্ষা, অবৈতনিক শিক্ষা, স্বাস্থ্য এবং বৈষম্যহীন মত প্রকাশের ৪টি মৌলিক অধিকার জানা।"
    },
    "content": {
      "en": [
        "In 14-year-old Pinky's village, girls leave school at age 12 to work in agricultural fields while boys continue classes.",
        "Her Sakhi mentor explains: 'Education is not a gift adults can choose to withhold. Under Indian law and international treaties, education is a fundamental right for every child under 18.'",
        "The four pillars of child rights are: Protection, Education, Health, and Participation. Gender equality mandates identical entitlements for boys and girls.",
        "Knowing your legal protections gives you the power to resist exploitation and stay in school."
      ],
      "bn": [
        "১৪ বছর বয়সী পিংকির গ্রামে মেয়েদের ১২ বছর বয়সে মাঠের কাজে নামিয়ে দেওয়া হতো, অথচ ছেলেরা স্কুলে যেত।",
        "মেন্টর তাকে জানাল: 'শিক্ষা কোনো দয়া নয়, ১৮ বছর পর্যন্ত প্রতিটি শিশুর জন্য এটি একটি মৌলিক আইনি অধিকার।'",
        "শিশু অধিকারের ৪টি স্তম্ভ হলো: সুরক্ষা, শিক্ষা, স্বাস্থ্য এবং মত প্রকাশের স্বাধীনতা। ছেলে ও মেয়ে উভয়ের জন্য এই অধিকার সমান।",
        "অধিকারের সচেতনতা মেয়েদের শ্রমের শোষণ থেকে রক্ষা করে এবং স্কুলজীবন ধরে রাখে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Employers ask Pinky to drop out to work full-time in the crop fields.",
        "bn": "জমির মালিক পিংকিকে স্কুল ছেড়ে মাঠে কাজ করার নির্দেশ দেয়।"
      },
      "choiceA": {
        "en": "Assume children have no legal protection against school deprivation.",
        "bn": "মেনে নেওয়া যে শিশুদের কোনো আইনি সুরক্ষা নেই।"
      },
      "resultA": {
        "en": "Surrenders fundamental rights and traps in child labor cycles.",
        "bn": "পড়াশোনা চিরতরে বন্ধ হয়ে যায় এবং শিশুশ্রমের শিকার হতে হয়।"
      },
      "choiceB": {
        "en": "Reference the '4 Pillars of Child Rights' and inform school authorities.",
        "bn": "আইনি অধিকারের কথা উল্লেখ করে স্কুল শিক্ষককে জানানো।"
      },
      "resultB": {
        "en": "Activates child protection interventions, keeping Pinky in school.",
        "bn": "প্রশাসন হস্তক্ষেপ করে এবং পিংকির পড়ালেখা চালু থাকে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "4 Pillars of Child Rights: 1. Protection, 2. Education, 3. Health, 4. Participation.",
        "Rights Violation Reporting: Learn reporting steps to local School Management Committees.",
        "Equality Advocacy Toolkit: Share child rights awareness with Adolescent Circle peers."
      ],
      "bn": [
        "শিশু অধিকারের ৪ স্তম্ভ: সুরক্ষা, শিক্ষা, স্বাস্থ্য এবং মত প্রকাশ।",
        "অভিযোগ জানানোর নিয়ম: কোনো বাধা এলে স্কুলের শিক্ষক বা কমিটিকে জানাও।",
        "বন্ধুদের সচেতন করা: নিজের ক্লাসের সব মেয়েকে তাদের অধিকার সম্পর্কে বলো।"
      ]
    },
    "keyTakeaway": {
      "en": "Education and protection are legal rights, not privileges. Gender equality ensures identical rights for every child.",
      "bn": "শিক্ষা ও সুরক্ষা কোনো অনুগ্রহ নয়, তোমার জন্মগত অধিকার। ছেলে ও মেয়ে সবার অধিকার সমান।"
    }
  },
  {
    "id": 18,
    "phase": 6,
    "phaseTitle": {
      "en": "Rights, Protection, Helplines & Cyber Safety",
      "bn": "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা"
    },
    "category": "rights-safety",
    "emoji": "🛑",
    "title": {
      "en": "Child Marriage Laws & Postponing Marriage Age",
      "bn": "বাল্যবিয়ে বিরোধী আইন ও বয়স বৃদ্ধি"
    },
    "summary": {
      "en": "Understand the Prohibition of Child Marriage Act, minimum legal ages, and health benefits of delaying marriage past 18.",
      "bn": "বাল্যবিয়ে প্রতিরোধ আইন, মেয়েদের জন্য সর্বনিম্ন ১৮ বছর বয়স এবং অল্প বয়সে বিয়ের স্বাস্থ্যগত ঝুঁকি বোঝা।"
    },
    "content": {
      "en": [
        "15-year-old Sunita discovers her parents are planning her marriage during an upcoming festival to reduce dowry costs.",
        "Her mentor acts quickly: 'Under the Prohibition of Child Marriage Act, 18 is the strict minimum legal age for females. Arranging child marriage is a non-bailable criminal offense.'",
        "WHO global health data shows pregnancy complications and unsafe abortions are the leading cause of death among 15–19-year-old girls globally.",
        "Connecting with local Child Protection Committees or calling CHILDLINE (1098) / Women Helpline (181) provides immediate legal protection."
      ],
      "bn": [
        "১৫ বছর বয়সী সুনীতা জানতে পারে কম বয়সে যৌতুক কম লাগবে ভেবে তার পরিবার একটি উৎসবে তার বিয়ের ঠিক করেছে।",
        "মেন্টর তাকে সতর্ক করল: 'বাল্যবিয়ে প্রতিরোধ আইন অনুযায়ী মেয়েদের বিয়ের বয়স অন্তত ১৮ বছর হওয়া বাধ্যতামূলক। এর আগে বিয়ে দেওয়া শাস্তিযোগ্য অপরাধ।'",
        "বিশ্ব স্বাস্থ্য সংস্থা অনুযায়ী ১৫-১৯ বছর বয়সী কিশোরীদের মৃত্যুর প্রধান কারণ হলো অপরিণত বয়সে গর্ভধারণের জটিলতা।",
        "১০৯৮ (চাইল্ডলাইন) বা ১৮১ (নারী হেল্পলাইন)-এ ফোন করলে তৎক্ষণাৎ আইনি উদ্ধার পাওয়া যায়।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Sunita faces imminent forced child marriage.",
        "bn": "সুনীতাকে জোর করে অপ্রাপ্তবয়সে বিয়ে দেওয়ার চেষ্টা চলছে।"
      },
      "choiceA": {
        "en": "Yield silently and drop out of school.",
        "bn": "চুপচাপ মেনে নেওয়া এবং স্কুল ছেড়ে দেওয়া।"
      },
      "resultA": {
        "en": "Severe health risks, early pregnancy complications, and loss of independence.",
        "bn": "জীবন বিপন্ন হয় এবং শারীরিক ও মানসিক ক্ষতি হয়।"
      },
      "choiceB": {
        "en": "Connect with support networks, involve the Child Protection Committee, and call 1098.",
        "bn": "শিশু সুরক্ষা কমিটি ও চাইল্ডলাইন ১০৯৮-এ যোগাযোগ করা।"
      },
      "resultB": {
        "en": "Legal intervention halts marriage and secures Sunita's continued education.",
        "bn": "প্রশাসন বিয়ে বন্ধ করে এবং সুনীতার পড়ালেখা রক্ষা পায়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Legal Age Limits: 18 years for females, 21 years for males under Indian law.",
        "Non-Bailable Crime: Organizing, performing, or aiding child marriage is strictly punishable by law.",
        "Emergency Action: Dial 1098 (CHILDLINE) or 181 (Women Helpline) for immediate legal rescue.",
        "Health Awareness: Delaying marriage past 18 prevents pregnancy fatalities and secures education."
      ],
      "bn": [
        "আইনি বয়স: মেয়েদের বিয়ের বয়স অন্তত ১৮ বছর এবং ছেলেদের ২১ বছর।",
        "শাস্তিযোগ্য অপরাধ: বাল্যবিয়ে দেওয়া ও সহযোগিতা করা উভয়েই শাস্তিযোগ্য জেল-জরিমানা।",
        "জরুরি নম্বর: বিপদে পড়লে ১০৯৮ বা ১৮১ নম্বরে ফোন করো।",
        "স্বাস্থ্য সচেতনতা: ১৮ বছরের আগে বিয়ে হলে মৃত্যুর ঝুঁকি বাড়ে।"
      ]
    },
    "keyTakeaway": {
      "en": "Child marriage is illegal and dangerous. Call 1098 or 181 to protect your life, health, and schooling.",
      "bn": "বাল্যবিয়ে বেআইনি ও বিপজ্জনক। ১৮-র আগে বিয়ে রুখতে ১০৯৮ বা ১৮১-এ ফোন করে সাহায্য নাও।"
    }
  },
  {
    "id": 19,
    "phase": 6,
    "phaseTitle": {
      "en": "Rights, Protection, Helplines & Cyber Safety",
      "bn": "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা"
    },
    "category": "rights-safety",
    "emoji": "✋",
    "title": {
      "en": "Safe Touch, Unsafe Touch & Abuse Awareness",
      "bn": "নিরাপদ ও অনিরাপদ স্পর্শ এবং সচেতনতা"
    },
    "summary": {
      "en": "Identify safe versus unsafe touch, recognize abuse under the POCSO Act, and eliminate self-blame.",
      "bn": "নিরাপদ ও খারাপ স্পর্শের তফাত বোঝা, পকসো (POCSO) আইন জানা এবং 'না বলা-পালাও-বড়দের জানাও' নীতি শেখা।"
    },
    "content": {
      "en": [
        "13-year-old Meenu feels frightened when a neighbor gives her sweets and touches her inappropriately under her clothing, warning her to keep it a 'secret'.",
        "Her Sakhi mentor states firmly: 'Abuse is 100% the abuser's fault. You are NEVER to blame. A safe touch makes you feel cared for (like a handshake or hug). An unsafe touch causes hurt, confusion, or touches private body parts.'",
        "Private parts are areas covered by a swimsuit (mouth, chest, between legs, buttocks). No one has the right to touch them.",
        "Execute the NO-GO-TELL rule: Say NO firmly, GO away immediately to a safe populated place, and TELL a trusted adult or call 1098/181."
      ],
      "bn": [
        "১৩ বছর বয়সী মীনুকে মিষ্টি দিয়ে একজন প্রতিবেশী তাকে অনাকাঙ্ক্ষিত স্পর্শ করে এবং কাউকে না বলতে ভয় দেখায়।",
        "মেন্টর বলল: 'এতে তোমার কোনো দোষ নেই। দোষ সম্পূর্ণ ওই ব্যক্তির। ভালোবাসার স্পর্শ ভালো অনুভূতি দেয়, কিন্তু অনিরাপদ স্পর্শ অস্বস্তি ও ভয় তৈরি করে।'",
        "সাঁতারের পোশাকে ঢাকা শরীরের একান্ত স্থানগুলোতে (বুক, দুই পায়ের মাঝে, নিতম্ব) স্পর্শ করা আইনত নিষিদ্ধ।",
        "৩টি নিয়ম মনে রাখো: ১. জোরে 'না' বলো, ২. সেখান থেকে দ্রুত সরে যাও, ৩. বিশ্বস্ত বড়দের বা হেল্পলাইনে খুলে বলো।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "An acquaintance attempts an unsafe touch and demands secrecy.",
        "bn": "একজন পরিচিত ব্যক্তি খারাপভাবে স্পর্শ করে কাউকে না বলার ভয় দেখায়।"
      },
      "choiceA": {
        "en": "Stay silent, blame yourself, and keep the secret.",
        "bn": "লজ্জা পেয়ে চুপ থাকা এবং নিজেকে দোষ দেওয়া।"
      },
      "resultA": {
        "en": "Increases trauma and allows abuse to continue unchecked.",
        "bn": "ভয় বাড়ে এবং ব্যক্তিটি সুযোগ পেতেই থাকে।"
      },
      "choiceB": {
        "en": "Execute the NO-GO-TELL Rule immediately.",
        "bn": "সাথে সাথে 'না-পালাও-জানাও' নিয়ম প্রয়োগ করা।"
      },
      "resultB": {
        "en": "Rejects abuser, protects bodily safety, and triggers adult protection.",
        "bn": "অসদাচরণ বন্ধ হয় এবং পুলিশ ও বড়দের সাহায্যে নিরাপত্তা মেলে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "NO-GO-TELL Rule: 1. NO (loud & firm), 2. GO (to a safe place), 3. TELL (a trusted adult or 1098/181).",
        "Swimsuit Rule: Understand private body areas protected strictly under the POCSO Act.",
        "Zero Self-Blame: Remember that victims of abuse carry zero guilt; full responsibility rests on the perpetrator."
      ],
      "bn": [
        "না-পালাও-জানাও নিয়ম: জোরে না বলো, নিরাপদ জায়গায় যাও এবং বিশ্বস্ত অভিভাবককে জানাও।",
        "ব্যক্তিগত অঙ্গের সুরক্ষা: সাঁতারের পোশাকের অংশের স্পর্শের ব্যাপারে সতর্ক থাকো।",
        "নিজেকে দোষ দেবে না: এতে তোমার কোনো ভুল নেই, দোষী কেবল সেই ব্যক্তি।"
      ]
    },
    "keyTakeaway": {
      "en": "Your body belongs entirely to you. Follow NO-GO-TELL and remember that abuse is never your fault.",
      "bn": "তোমার শরীর একমাত্র তোমার। অনিরাপদ স্পর্শে সোজাসুজি 'না' বলো এবং বড়দের সাহায্য চাও।"
    }
  },
  {
    "id": 20,
    "phase": 6,
    "phaseTitle": {
      "en": "Rights, Protection, Helplines & Cyber Safety",
      "bn": "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা"
    },
    "category": "rights-safety",
    "emoji": "📞",
    "title": {
      "en": "Emergency Support, Helplines & Reporting Systems",
      "bn": "জরুরি সহায়তা, হেল্পলাইন ও উদ্ধার ব্যবস্থা"
    },
    "summary": {
      "en": "Memorize and navigate official Indian emergency helplines: 1098, 181, 112, and 14490.",
      "bn": "ভারতের সরকারি জরুরি হেল্পলাইন ১০৯৮, ১৮১, ১১২ এবং ১৪৪৯০ নম্বরের ব্যবহার ও বিনা খরচে সাহায্য পাওয়ার উপায়।"
    },
    "content": {
      "en": [
        "15-year-old Geeta learns a peer is trapped in an abusive domestic situation with immediate threats of physical violence.",
        "Her mentor explains: 'All official emergency shortcodes are 100% toll-free, operate 24/7, and require zero mobile talktime balance.'",
        "Key Helplines: 1098 (CHILDLINE for children under 18), 181 (Women Helpline linked to One Stop Sakhi Centres), 112 (Emergency Response for Police/Ambulance/Fire), and 14490 (National Commission for Women).",
        "These helplines connect directly to rescue teams, Child Welfare Committees, and legal protection officers."
      ],
      "bn": [
        "১৫ বছর বয়সী গীতা জানতে পারে তার এক বন্ধু পারিবারিক অত্যাচারে মারাত্মক বিপদে আছে।",
        "মেন্টর বোঝাল: 'সব সরকারি হেল্পলাইন নম্বর সম্পূর্ণ বিনামূল্যে এবং দিনরাত ২৪ ঘণ্টা কাজ করে, মোবাইলে কোনো ব্যালেন্স না থাকলেও ফোন যায়।'",
        "জরুরি নম্বরসমূহ: ১০৯৮ (১৮ বছরের কম বয়সীদের জন্য চাইল্ডলাইন), ১৮১ (নারী ও কিশোরী সহায়তা), ১১২ (পুলিশ, দমকল ও অ্যাম্বুলেন্স), এবং ১৪৪৯০ (মহিলা কমিশন)।",
        "এই নম্বরে ফোন করলে তৎক্ষণাৎ উদ্ধার দল ও পুলিশ এসে সুরক্ষা নিশ্চিত করে।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Geeta witnesses a child protection emergency.",
        "bn": "গীতা একটি কিশোরীর ওপর নির্যাতন দেখে উদ্ধার করতে চায়।"
      },
      "choiceA": {
        "en": "Panic and assume emergency calls require paid mobile balance.",
        "bn": "ভয় পাওয়া এবং ভাবা যে মোবাইলে টাকা না থাকলে ফোন যাবে না।"
      },
      "resultA": {
        "en": "Delays critical intervention, putting the child in grave danger.",
        "bn": "উদ্ধারে দেরি হয় এবং বিপদ বেড়ে যায়।"
      },
      "choiceB": {
        "en": "Use the Speed Dial Helpline Hub to connect to 1098 or 112 instantly.",
        "bn": "সরাসরি ১০৯৮ বা ১১২ নম্বরে ফোন করা।"
      },
      "resultB": {
        "en": "Triggers immediate emergency response and safe legal rescue.",
        "bn": "পুলিশ ও উদ্ধারকারী দল এসে শিশুটিকে নিরাপদে উদ্ধার করে।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "CHILDLINE (1098): 24/7 toll-free emergency rescue and counseling for children under 18.",
        "Women Helpline (181): Emergency response linked to One Stop Sakhi Centres under Mission Shakti.",
        "Emergency Response (112): Single nationwide emergency number for immediate police dispatch.",
        "NCW Helpline (14490): Psychological and legal counselors trained in mental health.",
        "Zero Balance Needed: All shortcodes work on any phone without talktime balance."
      ],
      "bn": [
        "১০৯৮ (চাইল্ডলাইন): ১৮ বছরের কম বয়সীদের জন্য বিনামূল্যে জরুরি উদ্ধার ও পরামর্শ।",
        "১৮১ (নারী হেল্পলাইন): নির্যাতন ও পারিবারিক সহিংসতার বিরুদ্ধে ওয়ান স্টপ সেন্টার।",
        "১১২ (জরুরি সেবা): পুলিশ, দমকল ও অ্যাম্বুলেন্সের জন্য দেশের সাধারণ নম্বর।",
        "১৪৪৯০ (মহিলা কমিশন): আইনি সহায়তা ও মানসিক স্বাস্থ্যের জন্য বিশেষজ্ঞ দল।",
        "টাকা ছাড়াই ফোন: সব ফোনে ব্যালেন্স ছাড়াই কল করা যায়।"
      ]
    },
    "keyTakeaway": {
      "en": "Emergency helplines (1098, 181, 112) are 24/7 toll-free lifelines. You never need money or balance to call for help.",
      "bn": "জরুরি নম্বর ১০৯৮, ১৮১, ১১২ সবসময় বিনামূল্যে খোলা থাকে। বিপদে পড়লে কোনো দ্বিধা ছাড়া ফোন করো।"
    }
  },
  {
    "id": 21,
    "phase": 6,
    "phaseTitle": {
      "en": "Rights, Protection, Helplines & Cyber Safety",
      "bn": "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা"
    },
    "category": "rights-safety",
    "emoji": "🌐",
    "title": {
      "en": "Cyber Safety, Digital Literacy & Online Well-being",
      "bn": "সাইবার নিরাপত্তা, ডিজিটাল জ্ঞান ও অনলাইন সুস্থতা"
    },
    "summary": {
      "en": "Safely navigate mobile devices, protect privacy, handle cyberbullying, and report threats to the Cyber Crime Portal.",
      "bn": "স্মার্টফোনে ব্যক্তিগত তথ্য ও ছবি সুরক্ষিত রাখা, সাইবার অপরাধ ও অনলাইন বুলিং প্রতিরোধ এবং সরকারি পোর্টালে অভিযোগ জানানো।"
    },
    "content": {
      "en": [
        "16-year-old Neha receives harassing messages from an unknown user demanding personal photos and threatening to alter her profile picture.",
        "Her digital safety instructor advises: 'Never comply with threats, and never delete evidence. Step 1: Take screenshots. Step 2: Block the user. Step 3: Set profiles to Private. Step 4: Report to the National Cyber Crime Portal (cybercrime.gov.in).'",
        "Practicing digital hygiene means strong passwords, keeping location settings private, and never sharing addresses or school locations publicly.",
        "Balancing screen time with physical rest preserves mental health while unlocking the positive learning power of the internet."
      ],
      "bn": [
        "১৬ বছর বয়সী নেহাকে ইন্টারনেটে একজন অপরিচিত ব্যক্তি ছবি চেয়ে ব্ল্যাকমেইল ও হুমকির বার্তা পাঠায়।",
        "ডিজিটাল শিক্ষক বোঝালেন: 'হুমকিতে ভয় পাবে না এবং প্রমাণ মুছে ফেলবে না। ১. স্ক্রিনশট রাখো, ২. অ্যাকাউন্ট ব্লক করো, ৩. প্রোফাইল প্রাইভেট করো, ৪. সাইবার ক্রাইম পোর্টালে (cybercrime.gov.in) অভিযোগ করো।'",
        "শক্তিশালী পাসওয়ার্ড রাখা এবং নিজের ঠিকানা, স্কুলের নাম বা ছবি অপরিচিতদের সাথে শেয়ার না করাই হলো সাইবার সুরক্ষা।",
        "সচেতন হয়ে ইন্টারনেট ব্যবহার করলে নতুন জ্ঞান ও ভবিষ্যতের সুযোগ খুলে যায়।"
      ]
    },
    "branchingScenario": {
      "scenario": {
        "en": "Neha receives an online blackmail threat demanding personal photographs.",
        "bn": "নেহার কাছে অনলাইনে ব্যক্তিগত ছবি চেয়ে হুমকি আসে।"
      },
      "choiceA": {
        "en": "Comply secretly or delete all messages without saving evidence.",
        "bn": "ভয়ে ছবি পাঠিয়ে দেওয়া অথবা সব মেসেজ মুছে ফেলা।"
      },
      "resultA": {
        "en": "Escalates extortion and destroys valuable legal evidence.",
        "bn": "ব্ল্যাকমেইল বাড়ে এবং আইনগত কোনো প্রমাণ থাকে না।"
      },
      "choiceB": {
        "en": "Take screenshots, block user, switch privacy to Private, and inform adult allies.",
        "bn": "স্ক্রিনশট রেখে তাকে ব্লক করা এবং বড়দের সাহায্যে সাইবার পোর্টালে জানানো।"
      },
      "resultB": {
        "en": "Preserves evidence, stops harassment, and enables official legal reporting.",
        "bn": "হয়রানি বন্ধ হয় এবং আইনি পদক্ষেপে অপরাধী চিহ্নিত হয়।"
      }
    },
    "actionableTakeaways": {
      "en": [
        "Digital Hygiene Rules: 1. Strong passwords (letters, numbers, symbols), 2. Keep location and accounts Private.",
        "Block & Report: Take screenshots of harassment, block senders, report via cybercrime.gov.in.",
        "Digital Well-being Timer: Use the in-app screen tracker to balance study with physical rest."
      ],
      "bn": [
        "পাসওয়ার্ড সুরক্ষা: অক্ষর ও সংখ্যার মিশ্রণে গোপন পাসওয়ার্ড রাখো এবং কাউকে বোলো না।",
        "ব্লক ও অভিযোগ: হুমকির স্ক্রিনশট রাখো, ব্লক করো এবং cybercrime.gov.in-এ জানাও।",
        "পর্দার সময়সীমা: মোবাইলে বেশি সময় না কাটিয়ে শরীরচর্চা ও পড়াশোনায় সময় দাও।"
      ]
    },
    "keyTakeaway": {
      "en": "Protect your privacy online, preserve evidence of harassment, and report threats to cybercrime.gov.in. Be bold and safe.",
      "bn": "ইন্টারনেটে সতর্ক ও সুরক্ষিত থাকো। কোনো হুমকি এলে প্রমাণ রেখে বড়দের ও সাইবার পোর্টালে জানাও।"
    }
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    "id": 1,
    "chapterId": 1,
    "question": {
      "en": "What is the primary benefit of developing self-awareness?",
      "bn": "আত্মসচেতনতা গড়ে তোলার প্রধান সুফল কী?"
    },
    "options": {
      "en": [
        "It allows you to change others' opinions about you instantly.",
        "It helps you accurately assess your feelings, values, and strengths to build self-worth.",
        "It guarantees that you will never experience negative emotions.",
        "It ensures automatic academic success without personal effort."
      ],
      "bn": [
        "এটি অন্যের মতামত এক নিমেষে পরিবর্তন করতে সাহায্য করে।",
        "এটি নিজের অনুভূতি, মূল্যবোধ ও শক্তিকে চিনে আত্মমর্যাদা গড়ে তুলতে সাহায্য করে।",
        "এটি নিশ্চিত করে যে তুমি কখনো কোনো খারাপ আবেগ অনুভব করবে না।",
        "এটি কোনো প্রচেষ্টা ছাড়াই পরীক্ষায় স্বয়ংক্রিয় সাফল্য আনে।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Self-awareness is the ability to accurately assess feelings, interests, values, and strengths within one's context, helping establish self-identity and self-worth.",
      "bn": "আত্মসচেতনতা হলো নিজের অনুভূতি, আগ্রহ, মূল্যবোধ ও শক্তিকে চেনার ক্ষমতা, যা নিজের আত্মমর্যাদা সুদৃঢ় করে।"
    }
  },
  {
    "id": 2,
    "chapterId": 1,
    "question": {
      "en": "When traditional expectations make an adolescent girl feel limited, self-awareness helps her to:",
      "bn": "যখন সামাজিক প্রত্যাশা একজন কিশোরীকে সীমিত করে, তখন আত্মসচেতনতা তাকে কীভাবে সাহায্য করে?"
    },
    "options": {
      "en": [
        "Accept those limitations as permanent personal failures.",
        "Ignore her feelings completely and conform to expectations.",
        "Understand that social disparities are external barriers and recognize her inherent capabilities.",
        "Blame herself for domestic pressures."
      ],
      "bn": [
        "সীমাবদ্ধতাগুলোকে নিজের চিরস্থায়ী ব্যর্থতা হিসেবে মেনে নেওয়া।",
        "নিজের অনুভূতিকে সম্পূর্ণ উপেক্ষা করে সবার কথামতো চলা।",
        "বোঝা যে সামাজিক বৈষম্য হলো বাইরের বাধা এবং নিজের ভেতরের সক্ষমতাকে চেনা।",
        "সংসারের সব চাপের জন্য নিজেকে দোষারোপ করা।"
      ]
    },
    "correctAnswerIndex": 2,
    "explanation": {
      "en": "Self-awareness empowers individuals to accept themselves, recognize that social barriers do not define their potential, and seek constructive solutions.",
      "bn": "আত্মসচেতনতা কিশোরীদের বোঝায় যে সামাজিক বাধানিষেধ তাদের মেধার সীমা নয়।"
    }
  },
  {
    "id": 3,
    "chapterId": 1,
    "question": {
      "en": "Which mobile app feature directly supports building self-identity?",
      "bn": "কোন মোবাইল ফিচারটি আত্মপরিচয় গঠনে সরাসরি সহায়তা করে?"
    },
    "options": {
      "en": [
        "Comparing your test scores with peers on social media.",
        "Utilizing an in-app Strength Inventory and Personal Values Journal daily.",
        "Relying entirely on peer approval to make personal choices.",
        "Hiding personal achievements to blend into group settings."
      ],
      "bn": [
        "সোশ্যাল মিডিয়ায় বন্ধুদের সাথে পরীক্ষার নম্বরের তুলনা করা।",
        "প্রতিদিন ব্যক্তিগত শক্তির তালিকা ও মূল্যবোধের ডায়েরি ব্যবহার করা।",
        "ব্যক্তিগত সিদ্ধান্তের জন্য সম্পূর্ণ বন্ধুদের সম্মতির ওপর নির্ভর করা।",
        "দলে মিশে যাওয়ার জন্য নিজের অর্জনকে লুকিয়ে রাখা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Daily reflection, logging personal values, and tracking individual strengths inside structured journal tools build a stable self-identity.",
      "bn": "প্রতিদিন নিজের শক্তি ও ভালো গুণগুলো লিখে রাখলে আত্মমর্যাদা সুদৃঢ় হয়।"
    }
  },
  {
    "id": 4,
    "chapterId": 2,
    "question": {
      "en": "Adolescence (ages 10–19) is defined globally by WHO as a developmental period marked by:",
      "bn": "বিশ্ব স্বাস্থ্য সংস্থা (WHO) অনুযায়ী বয়ঃসন্ধিকাল (১০–১৯ বছর) কী দ্বারা চিহ্নিত?"
    },
    "options": {
      "en": [
        "Complete physical stability with no biological shifts.",
        "Rapid physical, cognitive, and psychosocial growth.",
        "The final end of all cognitive learning.",
        "Identical growth rates for all individuals at the exact same age."
      ],
      "bn": [
        "কোনো পরিবর্তন ছাড়া সম্পূর্ণ শারীরিক স্থিতিশীলতা।",
        "দ্রুত শারীরিক, মানসিক ও সামাজিক বৃদ্ধি ও রূপান্তর।",
        "মানুষের নতুন কিছু শেখার চূড়ান্ত সমাপ্তি।",
        "একই বয়সের সবার ক্ষেত্রে হুবহু একই হারে বৃদ্ধি।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "WHO defines adolescence as a unique developmental stage characterized by rapid physical, cognitive, and psychosocial transitions.",
      "bn": "হু (WHO) অনুযায়ী বয়ঃসন্ধিকাল হলো দ্রুত শারীরিক ও মনস্তাত্ত্বিক পরিবর্তনের সময়।"
    }
  },
  {
    "id": 5,
    "chapterId": 2,
    "question": {
      "en": "Body positivity during puberty involves:",
      "bn": "বয়ঃসন্ধিকালে শারীরিক ইতিবাচকতা বলতে কী বোঝায়?"
    },
    "options": {
      "en": [
        "Comparing physical changes to peers daily.",
        "Criticizing oneself until fitting traditional media standards.",
        "Accepting normal biological changes and appreciating body functionality and health.",
        "Ignoring physical hygiene completely."
      ],
      "bn": [
        "প্রতিদিন বন্ধুদের সাথে নিজের শারীরিক পরিবর্তনের তুলনা করা।",
        "বিজ্ঞাপনের রূপের সাথে না মেলা পর্যন্ত নিজেকে ছোট ভাবা।",
        "স্বাভাবিক জৈবিক পরিবর্তন মেনে নেওয়া এবং শরীরের কার্যক্ষমতা ও স্বাস্থ্যের মূল্যায়ন করা।",
        "ব্যক্তিগত পরিচ্ছন্নতা সম্পূর্ণ উপেক্ষা করা।"
      ]
    },
    "correctAnswerIndex": 2,
    "explanation": {
      "en": "Body positivity means understanding normal developmental growth during puberty and honoring body functional capabilities.",
      "bn": "শারীরিক ইতিবাচকতা মানে রূপের চেয়ে শরীরের সুস্থতা ও শক্তির কদর করা।"
    }
  },
  {
    "id": 6,
    "chapterId": 2,
    "question": {
      "en": "How should an adolescent girl respond to negative peer comments about physical growth?",
      "bn": "শারীরিক বৃদ্ধি নিয়ে বন্ধুদের নেতিবাচক মন্তব্যে কীভাবে প্রতিক্রিয়া জানানো উচিত?"
    },
    "options": {
      "en": [
        "Internalize the comments and try to hide physical growth.",
        "Reframe negative self-talk and affirm that growth occurs at an individual pace.",
        "Stop eating nutritious meals to limit physical growth.",
        "Isolate completely from social groups."
      ],
      "bn": [
        "কথাগুলো মনে নিয়ে শরীরকে লুকিয়ে রাখার চেষ্টা করা।",
        "নেতিবাচক ভাবনা দূর করে মনে রাখা যে সবার বৃদ্ধি নিজস্ব স্বাভাবিক নিয়মে ঘটে।",
        "শারীরিক বৃদ্ধি থামাতে পুষ্টিকর খাবার খাওয়া বন্ধ করা।",
        "সবার থেকে নিজেকে সম্পূর্ণ আলাদা করে একাকী থাকা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Reframing self-talk and acknowledging individual growth paces counters body-shaming and protects self-esteem.",
      "bn": "ইতিবাচক ভাবনা কটূক্তি প্রতিহত করে আত্মমর্যাদা রক্ষা করে।"
    }
  },
  {
    "id": 7,
    "chapterId": 3,
    "question": {
      "en": "According to UNICEF's Comprehensive Life Skills Framework, individual empowerment begins with:",
      "bn": "ইউনিসেফের জীবনশৈলী শিক্ষা নির্দেশিকা অনুযায়ী আসল ক্ষমতায়ন শুরু হয় কোথা থেকে?"
    },
    "options": {
      "en": [
        "Acquiring material wealth before age 15.",
        "Recognizing one's inherent worth and fundamental human equality.",
        "Complying with traditional gender roles without question.",
        "Achieving higher marks than all classmates."
      ],
      "bn": [
        "১৫ বছর বয়সের আগেই প্রচুর ধনসম্পদ অর্জন করা।",
        "নিজের অন্তর্নিহিত মূল্য এবং মৌলিক মানবাধিকার ও সমতা উপলব্ধি করা।",
        "প্রশ্নহীনভাবে বাঁধাধরা লিঙ্গবৈষম্য মেনে চলা।",
        "ক্লাসের সবার চেয়ে সবসময় বেশি নম্বর পাওয়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Empowerment begins when an individual recognizes their inherent worth and equal rights regardless of gender or background.",
      "bn": "ক্ষমতায়ন শুরু হয় যখন একজন মানুষ নিজের সম্মান ও সমমর্যাদা বুঝতে শেখে।"
    }
  },
  {
    "id": 8,
    "chapterId": 3,
    "question": {
      "en": "Affirming personal dignity helps an adolescent girl to:",
      "bn": "ব্যক্তিগত আত্মমর্যাদা বজায় রাখা একজন কিশোরীকে কী করতে সাহায্য করে?"
    },
    "options": {
      "en": [
        "Accept lower investments in her health and schooling.",
        "Counter gender discrimination, build personal agency, and protect educational opportunities.",
        "Isolate herself from community life.",
        "Rely entirely on others to solve personal problems."
      ],
      "bn": [
        "নিজের স্বাস্থ্য ও শিক্ষার পেছনে কম গুরুত্ব দেওয়াকে মেনে নেওয়া।",
        "লিঙ্গবৈষম্যের প্রতিবাদ করা, নিজের নিয়ন্ত্রণ বাড়ানো এবং শিক্ষার সুযোগ রক্ষা করা।",
        "সামাজিক জীবন থেকে দূরে থাকা।",
        "সমস্যা সমাধানের জন্য সম্পূর্ণ অন্যের ওপর নির্ভর করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Internalizing dignity enables girls to challenge gender discrimination and advocate for their basic human rights.",
      "bn": "মর্যাদাবোধ অধিকারের জন্য লড়াই করার সাহস জোগায়।"
    }
  },
  {
    "id": 9,
    "chapterId": 3,
    "question": {
      "en": "Which practical step actively builds daily self-worth?",
      "bn": "কোন কাজটি প্রতিদিনের আত্মমর্যাদা বৃদ্ধিতে সহায়ক?"
    },
    "options": {
      "en": [
        "Completing an interactive Dignity Checklist and practicing self-affirmations.",
        "Avoiding new tasks to prevent failure.",
        "Accepting unfair household treatment in silence.",
        "Focusing exclusively on pleasing others at personal expense."
      ],
      "bn": [
        "মর্যাদার তালিকা মিলিয়ে দেখা এবং ইতিবাচক আত্মসংকল্প অনুশীলন করা।",
        "ব্যর্থতার ভয়ে নতুন কোনো কাজ না করা।",
        "পরিবারের অন্যায় আচরণ চুপচাপ সহ্য করা।",
        "নিজের ক্ষতি করে কেবল অন্যদের খুশি করার চেষ্টা করা।"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "Structured dignity checklists and positive affirmations reinforce self-worth and strengthen personal agency.",
      "bn": "ইতিবাচক সংকল্প নিজের অন্তর্নিহিত বিশ্বাস দৃঢ় করে।"
    }
  },
  {
    "id": 10,
    "chapterId": 4,
    "question": {
      "en": "Effective communication within life skills frameworks is defined as:",
      "bn": "জীবনশৈলী শিক্ষায় কার্যকর যোগাযোগ বলতে কী বোঝায়?"
    },
    "options": {
      "en": [
        "Demanding immediate agreement by speaking louder than others.",
        "Exchanging information, opinions, desires, needs, and feelings clearly and respectfully.",
        "Remaining quiet when personal rights are ignored.",
        "Communicating exclusively through text messages."
      ],
      "bn": [
        "চিৎকার করে অন্যদের বাধ্য করা।",
        "তথ্য, মতামত, প্রয়োজন ও অনুভূতি স্পষ্ট ও শ্রদ্ধার সাথে আদান-প্রদান করা।",
        "নিজের অধিকার লঙ্ঘিত হলেও চুপ করে থাকা।",
        "শুধুমাত্র টেক্সট মেসেজে কথা বলা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Communication involves exchanging information, thoughts, and emotions constructively across verbal and non-verbal modes.",
      "bn": "সম্মানজনক ও স্পষ্ট মতবিনিময়ই যোগাযোগের মূল কথা।"
    }
  },
  {
    "id": 11,
    "chapterId": 4,
    "question": {
      "en": "Assertive communication differs from aggressive communication because assertiveness:",
      "bn": "দৃঢ় যোগাযোগ আক্রমণাত্মক আচরণের থেকে আলাদা কারণ এটি:"
    },
    "options": {
      "en": [
        "Insults the listener to gain dominance.",
        "Respects both personal rights and the dignity of the listener.",
        "Concedes to all external demands passively.",
        "Avoids stating true personal desires."
      ],
      "bn": [
        "অন্যকে অপমান করে নিজের ক্ষমতা দেখায়।",
        "নিজের অধিকার ও অপরের সম্মান উভয়কেই রক্ষা করে।",
        "সবার সব অন্যায় দাবি মেনে নেয়।",
        "নিজের ইচ্ছা কখনো প্রকাশ করে না।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Assertiveness clearly conveys personal needs while maintaining full respect for others.",
      "bn": "দৃঢ় বক্তব্যের অর্থ হলো সম্মান দিয়ে নিজের দাবি তুলে ধরা।"
    }
  },
  {
    "id": 12,
    "chapterId": 4,
    "question": {
      "en": "Which non-verbal cue strengthens assertive speaking?",
      "bn": "কোন শারীরিক অঙ্গভঙ্গিটি আত্মবিশ্বাসী কথা বলতে সাহায্য করে?"
    },
    "options": {
      "en": [
        "Looking at the ground and mumbling.",
        "Crossing arms tightly and turning away.",
        "Maintaining an upright posture, clear tone, and comfortable eye contact.",
        "Speaking as fast as possible without pausing."
      ],
      "bn": [
        "মাটির দিকে তাকিয়ে অস্পষ্টভাবে বলা।",
        "হাত গুটিয়ে মুখ ফিরিয়ে নেওয়া।",
        "সোজা হয়ে দাঁড়ানো, স্পষ্ট গলার স্বর এবং চোখে চোখ রেখে কথা বলা।",
        "না থেমে খুব দ্রুত কথা বলা।"
      ]
    },
    "correctAnswerIndex": 2,
    "explanation": {
      "en": "Upright posture, clear vocal tone, and steady eye contact project confidence and reinforce verbal clarity.",
      "bn": "সোজা দাঁড়িয়ে শান্ত চোখে তাকালে কথার ওজন বাড়ে।"
    }
  },
  {
    "id": 13,
    "chapterId": 5,
    "question": {
      "en": "Active listening requires which key behaviors?",
      "bn": "সক্রিয়ভাবে শোনার প্রধান লক্ষণ কোনটি?"
    },
    "options": {
      "en": [
        "Formulating a counter-argument while the speaker is talking.",
        "Giving full attention, withholding judgment, and summarizing what was understood.",
        "Interrupting frequently to correct minor details.",
        "Agreeing with every statement without reflection."
      ],
      "bn": [
        "অন্যের কথা চলাকালেই মনে মনে জবাব তৈরি করা।",
        "পূর্ণ মনোযোগ দেওয়া, বিচার না করা এবং কথাটি গুছিয়ে পুনরাবৃত্তি করা।",
        "ছোটখাটো ভুলে বারবার মাঝপথে কথা কেটে দেওয়া।",
        "না ভেবেই সব কথায় অন্ধভাবে সায় দেওয়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Active listening requires undivided attention, empathetic focus, reflection, and withholding quick judgment.",
      "bn": "মন দিয়ে শোনার অর্থ হলো বিচার না করে বুঝতে চেষ্টা করা।"
    }
  },
  {
    "id": 14,
    "chapterId": 5,
    "question": {
      "en": "Respecting diversity in peer groups is essential because it:",
      "bn": "দলে বৈচিত্র্যকে সম্মান দেওয়া কেন জরুরি?"
    },
    "options": {
      "en": [
        "Allows one dominant group to set all rules.",
        "Fosters empathy, social cohesion, and peaceful conflict resolution across communities.",
        "Eliminates the need for group discussion.",
        "Standardizes all personal beliefs into one single viewpoint."
      ],
      "bn": [
        "একটি বিশেষ দলকে সব নিয়ম ঠিক করতে দেয়।",
        "সহমর্মিতা, সামাজিক ঐক্য ও শান্তিপূর্ণ সমাধান তৈরি করে।",
        "আলোচনা করার প্রয়োজনীয়তা শেষ করে দেয়।",
        "সবার মতামতকে জোর করে এক রকম করে ফেলে।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Respecting diversity builds empathy and enables individuals from varied backgrounds to collaborate effectively.",
      "bn": "বৈচিত্র্যের প্রতি শ্রদ্ধা সমাজকে একতাবদ্ধ করে।"
    }
  },
  {
    "id": 15,
    "chapterId": 5,
    "question": {
      "en": "When a peer from a different social background shares an opinion, an empathetic active listener should:",
      "bn": "ভিন্ন পটভূমির একজন বন্ধু মতামত দিলে কী করা উচিত?"
    },
    "options": {
      "en": [
        "Interrupt to change the topic to a familiar subject.",
        "Focus attentively, validate their perspective, and avoid pre-judging.",
        "Ignore the statement until someone else speaks.",
        "Correct their accent publicly."
      ],
      "bn": [
        "কথা থামিয়ে দিয়ে পরিচিত বিষয়ে চলে যাওয়া।",
        "মন দিয়ে শোনা, তার দৃষ্টিভঙ্গিকে মূল্যায়ন করা এবং আগেভাগে বিচার না করা।",
        "তার কথা সম্পূর্ণ উপেক্ষা করা।",
        "সবার সামনে তার উচ্চারণের ভুল ধরা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Empathetic active listening validates others and creates an inclusive space for all voices.",
      "bn": "মন দিয়ে শুনলে সবাই নিজেকে সম্মানিত মনে করে।"
    }
  },
  {
    "id": 16,
    "chapterId": 6,
    "question": {
      "en": "What is a primary benefit of participating in structured peer groups for adolescent girls?",
      "bn": "কিশোরী সভায় সক্রিয় অংশগ্রহণের প্রধান সুফল কী?"
    },
    "options": {
      "en": [
        "It removes individual accountability for personal choices.",
        "It builds social capital, collective strength, and shared problem-solving capabilities.",
        "It ensures that only the dominant member makes decisions.",
        "It reduces personal creativity."
      ],
      "bn": [
        "ব্যক্তিগত সিদ্ধান্তের দায় অন্যের ওপর চাপানো যায়।",
        "সামাজিক বন্ধন, যৌথ শক্তি এবং দলগত সমস্যা সমাধানের ক্ষমতা বাড়ে।",
        "শুধুমাত্র প্রভাবশালী ব্যক্তি সিদ্ধান্ত নেওয়ার সুযোগ পায়।",
        "সবার সৃজনশীলতা কমে যায়।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Group participation creates social support networks, enabling girls to pool skills and advocate collectively.",
      "bn": "দলগত কাজ একতাবদ্ধ শক্তির জন্ম দেয়।"
    }
  },
  {
    "id": 17,
    "chapterId": 6,
    "question": {
      "en": "In effective teamwork dynamics, the role of a 'Mediator' focuses on:",
      "bn": "দলের মধ্যে 'মধ্যস্থতাকারী'-র প্রধান দায়িত্ব কী?"
    },
    "options": {
      "en": [
        "Doing all the work independently.",
        "Helping team members resolve disagreements fairly and maintain collaboration.",
        "Directing others without listening to input.",
        "Observing group activities without participating."
      ],
      "bn": [
        "সব কাজ একা একা করা।",
        "মতবিরোধ মিটিয়ে দলের সবাইকে একসাথে কাজ করতে সাহায্য করা।",
        "কারও কথা না শুনে একনায়কত্ব চালানো।",
        "কোনো কাজ না করে শুধু তাকিয়ে দেখা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "A mediator facilitates conflict resolution, keeping the team aligned toward shared goals.",
      "bn": "মধ্যস্থতাকারী দলের ঐক্য বজায় রাখে।"
    }
  },
  {
    "id": 18,
    "chapterId": 6,
    "question": {
      "en": "High-performing teams maintain effective collaboration by:",
      "bn": "একটি সফল দল কীভাবে কাজ চালিয়ে যায়?"
    },
    "options": {
      "en": [
        "Allowing one member to perform all tasks silently.",
        "Establishing shared ground rules, respecting diverse contributions, and distributing tasks fairly.",
        "Excluding members who express differing opinions.",
        "Avoiding structured planning entirely."
      ],
      "bn": [
        "একজন সদস্যের ওপর সব কাজ চাপিয়ে দিয়ে।",
        "নির্দিষ্ট নিয়ম তৈরি করে, সবার মতামতকে শ্রদ্ধা জানিয়ে এবং সমানভাবে কাজ ভাগ করে।",
        "ভিন্ন মত পোষণকারীকে দল থেকে বাদ দিয়ে।",
        "কোনো রকম পরিকল্পনা না করে।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Clear ground rules, equitable task distribution, and mutual respect maintain productive team dynamics.",
      "bn": "কাজের ন্যায্য বণ্টন এবং পারস্পরিক শ্রদ্ধা দলকে সফল করে।"
    }
  },
  {
    "id": 19,
    "chapterId": 7,
    "question": {
      "en": "Personal boundaries are best defined as:",
      "bn": "ব্যক্তিগত সীমানা বলতে কী বোঝায়?"
    },
    "options": {
      "en": [
        "Rigid rules imposed by others to restrict personal choices.",
        "Clear limits established to protect physical space, emotional well-being, and personal privacy.",
        "Social barriers designed to prevent making new friends.",
        "Physical fences built around educational institutions."
      ],
      "bn": [
        "অন্যদের চাপিয়ে দেওয়া নিয়ম যা স্বাধীনতা কেড়ে নেয়।",
        "নিজের শরীর, মানসিক শান্তি ও গোপনীয়তা রক্ষার সুস্পষ্ট সীমা।",
        "নতুন বন্ধু বানাতে বাধা দেওয়া সামাজিক দেওয়াল।",
        "স্কুলের চারপাশের কাঁটাতারের বেড়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Personal boundaries define healthy limits regarding how others interact with one's physical body and privacy.",
      "bn": "ব্যক্তিগত সীমানা নিজের শরীর ও স্বাস্থ্যের সুরক্ষা নিশ্চিত করে।"
    }
  },
  {
    "id": 20,
    "chapterId": 7,
    "question": {
      "en": "When someone crosses a boundary and causes discomfort, the most appropriate immediate action is to:",
      "bn": "কেউ অস্বস্তিকরভাবে সীমানা লঙ্ঘন করলে সাথে সাথে কী করা উচিত?"
    },
    "options": {
      "en": [
        "Apologize for feeling uncomfortable and stay silent.",
        "State the boundary clearly, firmly, and direct the person to stop.",
        "Assume personal instincts are wrong and ignore the feeling.",
        "Violate the other person's boundaries in retaliation."
      ],
      "bn": [
        "চুপ থাকা এবং নিজের অস্বস্তির জন্য ক্ষমা চাওয়া।",
        "পরিষ্কার ও দৃঢ় গলায় নিজের আপত্তি জানিয়ে তাকে থামতে বলা।",
        "নিজের অনুভূতি ভুল ভেবে চুপ করে সহ্য করা।",
        "পাল্টা একই আচরণ করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Assertively stating boundaries and directing the individual to cease protects bodily autonomy and safety.",
      "bn": "স্পষ্ট ও দৃঢ়ভাবে আপত্তি জানানো নিজের নিরাপত্তা রক্ষা করে।"
    }
  },
  {
    "id": 21,
    "chapterId": 7,
    "question": {
      "en": "Saying 'No' to an uncomfortable physical situation or intrusion is:",
      "bn": "অস্বস্তিকর পরিস্থিতিতে 'না' বলা কী ধরনের পদক্ষেপ?"
    },
    "options": {
      "en": [
        "Always a disrespect to elders.",
        "A healthy, valid exercise of personal safety and bodily autonomy rights.",
        "Actionable only with prior written permission.",
        "An aggressive act that should be avoided."
      ],
      "bn": [
        "বড়দের প্রতি চরম অসম্মান।",
        "শারীরিক নিরাপত্তা ও স্বাধীনতার সম্পূর্ণ বৈধ ও স্বাভাবিক অধিকার।",
        "লিখিত অনুমতি ছাড়া করা নিষেধ।",
        "একটি খারাপ আক্রমণাত্মক আচরণ।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Refusing uncomfortable physical contact or privacy intrusions is a fundamental legal and personal right.",
      "bn": "'না' বলা তোমার মৌলিক শারীরিক অধিকার।"
    }
  },
  {
    "id": 22,
    "chapterId": 8,
    "question": {
      "en": "Adolescents frequently experience heightened emotional intensity due to:",
      "bn": "বয়ঃসন্ধিকালে তীব্র আবেগ বা মেজাজের ওঠানামা কেন দেখা যায়?"
    },
    "options": {
      "en": [
        "Permanent personality flaws.",
        "Rapid biological, cognitive, and psychosocial transitions during developmental growth.",
        "Poor academic intelligence.",
        "Dietary choices exclusively."
      ],
      "bn": [
        "স্থায়ী চরিত্রের দোষের কারণে।",
        "হরমোন ও মানসিক বিকাশের দ্রুত পরিবর্তনের কারণে।",
        "কম বুদ্ধিমত্তার কারণে।",
        "শুধুমাত্র খাবারের পছন্দের কারণে।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "WHO guidelines confirm that rapid developmental transitions in adolescence naturally increase emotional intensity.",
      "bn": "বয়ঃসন্ধিকালে হরমোনের প্রাকৃতিক পরিবর্তনের জন্য তীব্র আবেগ আসা স্বাভাবিক।"
    }
  },
  {
    "id": 23,
    "chapterId": 8,
    "question": {
      "en": "Which response represents a negative coping strategy for managing intense grief or anger?",
      "bn": "তীব্র রাগ সামলাতে কোনটি ক্ষতিকর পন্থা?"
    },
    "options": {
      "en": [
        "Taking deep belly breaths and pausing before speaking.",
        "Lashing out verbally at family members and isolating oneself completely.",
        "Writing about emotional triggers in a private journal.",
        "Discussing feelings with a trusted mentor."
      ],
      "bn": [
        "গভীর শ্বাস নেওয়া এবং কথা বলার আগে থামা।",
        "পরিবারের ওপর চিৎকার-ভাঙচুর করা এবং নিজেকে পুরোপুরি বন্দি করা।",
        "ডায়েরিতে অনুভূতির কথা লেখা।",
        "বিশ্বস্ত মানুষের সাথে আলোচনা করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Aggressive outbursts and total social isolation are destructive coping mechanisms that compound distress.",
      "bn": "ভাঙচুর ও রাগারাগি পরিস্থিতিকে আরও খারাপ করে।"
    }
  },
  {
    "id": 24,
    "chapterId": 8,
    "question": {
      "en": "What is the critical first step in the recommended 4-step emotional calming sequence?",
      "bn": "মন শান্ত করার ৪টি ধাপের প্রথম পদক্ষেপ কোনটি?"
    },
    "options": {
      "en": [
        "Reacting immediately to release tension.",
        "Pausing physical movement immediately.",
        "Explaining to everyone why your reaction is justified.",
        "Suppressing the emotion permanently."
      ],
      "bn": [
        "সাথে সাথে কিছু ভেঙে উত্তেজনা কমানো।",
        "শারীরিক নড়াচড়া তৎক্ষণাৎ থামিয়ে দেওয়া (Pause)।",
        "সবার সাথে নিজের রাগের সাফাই গাওয়া।",
        "চিরতরে অনুভূতি চেপে রাখা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Pausing creates a necessary gap between feeling an emotional impulse and taking constructive action.",
      "bn": "থামলে রাগের মাথায় কোনো ভুল পদক্ষেপ নেওয়া আটকানো যায়।"
    }
  },
  {
    "id": 25,
    "chapterId": 9,
    "question": {
      "en": "What distinguishes positive coping strategies from negative coping mechanisms?",
      "bn": "ইতিবাচক ও নেতিবাচক চাপ মোকাবিলার মধ্যে মূল পার্থক্য কী?"
    },
    "options": {
      "en": [
        "Positive strategies resolve stress immediately by abandoning all responsibilities.",
        "Positive strategies manage pressure constructively through support and planning without causing long-term harm.",
        "Negative strategies build permanent emotional resilience.",
        "Positive strategies are effective only for adults."
      ],
      "bn": [
        "ইতিবাচক কৌশল সব দায়িত্ব ত্যাগ করে চাপ কমায়।",
        "ইতিবাচক কৌশল পরিকল্পনা ও সাহায্যের মাধ্যমে ক্ষতি ছাড়া সমাধান আনে।",
        "নেতিবাচক কৌশল মানুষকে শক্তিশালী করে।",
        "ইতিবাচক কৌশল কেবল বড়দের জন্য।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Positive coping utilizes structured planning, support-seeking, and rest to navigate pressure without self-harm.",
      "bn": "পরিকল্পনা ও বিশ্রাম নিয়ে চাপ কমানোই ইতিবাচক পদ্ধতি।"
    }
  },
  {
    "id": 26,
    "chapterId": 9,
    "question": {
      "en": "When feeling overwhelmed by academic expectations and domestic demands, an adolescent should:",
      "bn": "পড়ালেখা ও ঘরের কাজের চাপে দিশেহারা হলে কী করা উচিত?"
    },
    "options": {
      "en": [
        "Drop out of school immediately to end expectations.",
        "Isolate completely and refuse to speak to anyone.",
        "Break tasks into smaller steps, structure daily routines, and seek help from adult allies.",
        "Suppress stress until physical breakdown occurs."
      ],
      "bn": [
        "স্কুল ছেড়ে দেওয়া।",
        "কারও সাথে কথা না বলে একা ঘরে থাকা।",
        "কাজ ছোট ছোট ধাপে ভাগ করা, রুটিন তৈরি করা এবং বড়দের সাহায্য নেওয়া।",
        "অসুস্থ না হওয়া পর্যন্ত কষ্ট চেপে রাখা।"
      ]
    },
    "correctAnswerIndex": 2,
    "explanation": {
      "en": "Segmenting tasks, organizing daily time, and seeking social support effectively reduce stress levels.",
      "bn": "কাজ ভাগ করে রুটিনমাফিক করলে পড়ার চাপ কমে যায়।"
    }
  },
  {
    "id": 27,
    "chapterId": 9,
    "question": {
      "en": "Which habit represents a healthy daily stress-busting routine?",
      "bn": "প্রতিদিনের মানসিক চাপ কমাতে কোন অভ্যাসটি সবচেয়ে ভালো?"
    },
    "options": {
      "en": [
        "Maintaining regular physical activity, structured study blocks, and consistent sleep.",
        "Eliminating sleep entirely to study continuously.",
        "Consuming excess caffeine or harmful substances to stay awake.",
        "Avoiding all social contact permanently."
      ],
      "bn": [
        "নিয়মিত শরীরচর্চা, সময় ভাগ করে পড়া এবং পর্যাপ্ত ঘুম।",
        "না ঘুমিয়ে সারারাত পড়া।",
        "জেগে থাকার জন্য অতিরিক্ত চা বা ক্ষতিকর পানীয় খাওয়া।",
        "সবার সাথে মেলামেশা বন্ধ করা।"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "Physical activity, structured rest, and social connection are empirically proven stress reducers.",
      "bn": "শরীরচর্চা ও পর্যাপ্ত ঘুম মন ও মস্তিষ্ককে সতেজ রাখে।"
    }
  },
  {
    "id": 28,
    "chapterId": 10,
    "question": {
      "en": "UNICEF India defines resilience as:",
      "bn": "ইউনিসেফ ইন্ডিয়া অনুযায়ী সহনশীলতা (Resilience) কী?"
    },
    "options": {
      "en": [
        "Avoiding all difficult life circumstances entirely.",
        "The psychosocial ability to cope with calamity or disruption and return to a stable state of health and agency.",
        "Suppressing all emotional expressions during a crisis.",
        "Relying entirely on external relief without personal engagement."
      ],
      "bn": [
        "কঠিন পরিস্থিতি পুরোপুরি এড়িয়ে চলা।",
        "বিপদ ও সংকট কাটিয়ে আবার সুস্থ স্বাভাবিক জীবনে ফিরে আসার মানসিক ক্ষমতা।",
        "বিপদের সময় সব কান্না ও অনুভূতি আটকে রাখা।",
        "নিজে কোনো চেষ্টা না করে শুধু অন্যের ত্রাণের অপেক্ষায় থাকা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Resilience is defined as the capacity to recover from adversity, calamity, or major life disruptions and regain personal agency.",
      "bn": "সহনশীলতা হলো বিপর্যয়ের মুখেও নিজের চেষ্টায় আবার দাঁড়ানোর শক্তি।"
    }
  },
  {
    "id": 29,
    "chapterId": 10,
    "question": {
      "en": "Psychological resilience is best understood as:",
      "bn": "মানসিক সহনশীলতা সম্পর্কে কোনটি সত্য?"
    },
    "options": {
      "en": [
        "An unchangeable genetic trait that individuals either possess or lack.",
        "A dynamic competency developed through adaptive coping skills, problem-solving, and social support networks.",
        "A temporary child emotion that disappears in adulthood.",
        "A skill required only during natural disasters."
      ],
      "bn": [
        "একটি জন্মগত গুণ যা সবার থাকে না।",
        "একটি শেখার মতো দক্ষতা যা নিয়মিত চর্চা ও সাহায্যের মাধ্যমে বাড়ানো যায়।",
        "ছোটদের একটি সাময়িক আবেগ যা বড় হলে থাকে না।",
        "শুধুমাত্র প্রাকৃতিক দুর্যোগের সময় দরকারি।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Resilience is a malleable life skill strengthened over time through practice, emotional regulation, and community connection.",
      "bn": "সহনশীলতা একটি দক্ষতা যা অনুশীলনের মাধ্যমে যে কেউ অর্জন করতে পারে।"
    }
  },
  {
    "id": 30,
    "chapterId": 10,
    "question": {
      "en": "Which cognitive mindset shift directly fosters psychological resilience during adversity?",
      "bn": "কঠিন সময়ে কোন মানসিকতা সহনশীলতা তৈরি করে?"
    },
    "options": {
      "en": [
        "Viewing temporary setbacks as permanent personal failures.",
        "Reframing challenges as temporary obstacles that offer learning and growth opportunities.",
        "Refusing support from community networks.",
        "Blaming peers for external crisis events."
      ],
      "bn": [
        "সাময়িক সমস্যাকে চিরস্থায়ী ব্যর্থতা ভাবা।",
        "বিপদকে সাময়িক বাধা হিসেবে দেখা যা থেকে নতুন শিক্ষা নেওয়া সম্ভব।",
        "কারও কাছ থেকে কোনো সাহায্য না নেওয়া।",
        "অন্যদের ওপর দোষ চাপিয়ে দেওয়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Reframing obstacles as temporary and manageable fosters adaptive problem-solving and emotional recovery.",
      "bn": "'এই সময় কেটে যাবে এবং আমি নতুন করে শুরু করব'—এই মনোভাবই জয় আনে।"
    }
  },
  {
    "id": 31,
    "chapterId": 11,
    "question": {
      "en": "Critical thinking is defined within life skills frameworks as the ability to:",
      "bn": "জীবনশৈলীতে গঠনমূলক চিন্তাভাবনা (Critical Thinking) কী?"
    },
    "options": {
      "en": [
        "Accept traditional social opinions without verification.",
        "Appropriately analyze information objectively to arrive at a reasoned judgment.",
        "Reject all peer advice automatically.",
        "Memorize textbooks quickly for exams."
      ],
      "bn": [
        "যাচাই না করে প্রচলিত সব কথা মেনে নেওয়া।",
        "তথ্য নিরপেক্ষভাবে বিশ্লেষণ করে সঠিক সিদ্ধান্তে পৌঁছানোর ক্ষমতা।",
        "সবার সব উপদেশ চোখ বন্ধ করে বাতিল করা।",
        "পরীক্ষার জন্য বই মুখস্থ করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Critical thinking involves objectively gathering, examining, and evaluating information to reach balanced, evidence-based judgments.",
      "bn": "তথ্য যাচাই করে যুক্তি দিয়ে সিদ্ধান্ত নেওয়াই গঠনমূলক চিন্তা।"
    }
  },
  {
    "id": 32,
    "chapterId": 11,
    "question": {
      "en": "According to national survey data (ASER), what happens to school enrolment between ages 14 and 18 in rural India?",
      "bn": "জাতীয় শিক্ষা সমীক্ষা (ASER) অনুযায়ী ১৪ থেকে ১৮ বছর বয়সে ভারতে মেয়েদের স্কুলে কী ঘটে?"
    },
    "options": {
      "en": [
        "Enrolment increases to 100%.",
        "Non-enrolment climbs from 5% at age 14 to 30% by age 18, disproportionately affecting females.",
        "All adolescents enter formal university education.",
        "Male non-enrolment becomes 80% higher than female non-enrolment."
      ],
      "bn": [
        "ভর্তির হার ১০০% হয়ে যায়।",
        "স্কুল ছাড়ার হার ৫% থেকে বেড়ে ১৮ বছর বয়সে ৩০% হয়ে যায়, যার শিকার মূলত মেয়েরা।",
        "সবাই কলেজে ভর্তি হয়।",
        "ছেলেদের স্কুল ছাড়ার হার মেয়েদের চেয়ে বহুগুণ বাড়ে।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "ASER data confirms that out-of-school rates rise sharply from 5% at age 14 to 30% at age 18 (32% for females), highlighting the critical need for decision-making skills.",
      "bn": "ASER তথ্য অনুযায়ী বয়ঃসন্ধিকালে বহু মেয়ে স্কুল ছেড়ে দেয়, তাই পড়াশোনা ধরে রাখার সিদ্ধান্ত খুব জরুরি।"
    }
  },
  {
    "id": 33,
    "chapterId": 11,
    "question": {
      "en": "When evaluating advice regarding leaving school early, critical thinking enables an adolescent girl to:",
      "bn": "পড়ালেখা ছাড়ার ব্যাপারে আত্মীয়দের কথায় গঠনমূলক চিন্তা একজন মেয়েকে কী সাহায্য করে?"
    },
    "options": {
      "en": [
        "Choose whichever option requires the least immediate physical effort.",
        "Identify underlying gender biases and evaluate long-term impacts on her rights and economic security.",
        "Follow the advice of whichever relative speaks loudest.",
        "Avoid making any decision."
      ],
      "bn": [
        "যেটিতে কম খাটনি হয় সেটি বেছে নেওয়া।",
        "লুকিয়ে থাকা লিঙ্গবৈষম্য চেনা এবং নিজের স্বাধীনতা ও আয়ের ওপর ভবিষ্যৎ প্রভাব মূল্যায়ন করা।",
        "যে সবচেয়ে জোরে কথা বলে তার কথা শোনা।",
        "কোনো সিদ্ধান্ত না নেওয়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Critical thinking exposes gender stereotypes and allows girls to evaluate choices based on long-term health, education, and legal rights.",
      "bn": "কুসংস্কার চিনে ভবিষ্যতের স্বাবলম্বী হওয়ার সুযোগ রক্ষা করা।"
    }
  },
  {
    "id": 34,
    "chapterId": 12,
    "question": {
      "en": "In the SMART goal framework, what does the acronym 'SMART' stand for?",
      "bn": "SMART লক্ষ্য নির্ধারণের সূত্রে প্রতিটি অক্ষরের অর্থ কী?"
    },
    "options": {
      "en": [
        "Simple, Meaningful, Actionable, Relevant, Timely.",
        "Specific, Measurable, Achievable, Relevant, Time-bound.",
        "Strict, Mandatory, Academic, Rigid, Tough.",
        "Social, Moral, Artistic, Rational, Technical."
      ],
      "bn": [
        "সহজ, অর্থপূর্ণ, কাজের, প্রাসঙ্গিক, সঠিক সময়ের।",
        "নির্দিষ্ট (Specific), পরিমাপযোগ্য (Measurable), অর্জনযোগ্য (Achievable), প্রাসঙ্গিক (Relevant), সময়াবদ্ধ (Time-bound)।",
        "কঠোর, বাধ্যতামূলক, পড়ালেখার, অনমনীয়, কঠিন।",
        "সামাজিক, নৈতিক, শিল্পকলার, যুক্তিবাদী, প্রযুক্তিগত।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "SMART stands for Specific, Measurable, Achievable, Relevant, and Time-bound.",
      "bn": "SMART মানে হলো নিখুঁত, পরিমাপযোগ্য ও সময়সীমাযুক্ত বাস্তবসম্মত পরিকল্পনা।"
    }
  },
  {
    "id": 35,
    "chapterId": 12,
    "question": {
      "en": "Why is structured goal setting particularly vital for adolescent girls in rural contexts?",
      "bn": "গ্রামাঞ্চলের কিশোরীদের জন্য সুনির্দিষ্ট লক্ষ্য নির্ধারণ কেন বিশেষ জরুরি?"
    },
    "options": {
      "en": [
        "It guarantees immediate government employment without training.",
        "It helps overcome gender-stereotyped occupational limits and maps concrete steps toward economic independence.",
        "It restricts personal ambitions to traditional domestic duties exclusively.",
        "It eliminates the need for daily educational effort."
      ],
      "bn": [
        "এটি বিনা পরিশ্রমে সরকারি চাকরি দেয়।",
        "এটি মেয়েদের সংকীর্ণ কাজ থেকে বের করে স্বাবলম্বী হওয়ার বাস্তব পথ তৈরি করে।",
        "এটি ঘরের কাজের বাইরে যেতে নিষেধ করে।",
        "এটি পড়াশোনা করার প্রয়োজন কমিয়ে দেয়।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Structured goal setting provides actionable steps that empower girls to challenge restrictive gender stereotypes and achieve economic agency.",
      "bn": "লক্ষ্য নির্ধারণ মেয়েদের অর্থনৈতিক স্বনির্ভরতা দেয়।"
    }
  },
  {
    "id": 36,
    "chapterId": 12,
    "question": {
      "en": "To turn a broad long-term career ambition into achievable reality, an adolescent should:",
      "bn": "বড় স্বপ্নকে বাস্তবে রূপ দিতে একজন কিশোরীর কী করা উচিত?"
    },
    "options": {
      "en": [
        "Wait until secondary education is entirely complete before planning.",
        "Break the long-term goal down into specific, time-bound weekly and monthly milestones.",
        "Keep goals completely secret to avoid social feedback.",
        "Change career aspirations every week."
      ],
      "bn": [
        "পড়াশোনা শেষ হওয়া পর্যন্ত কোনো পরিকল্পনা না করে বসে থাকা।",
        "বড় লক্ষ্যকে ছোট ছোট সাপ্তাহিক ও মাসিক মাইলফলকে ভাগ করে এগোতে থাকা।",
        "লক্ষ্য কাউকে না বলা।",
        "প্রতি সপ্তাহে ইচ্ছা বদলে ফেলা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Segmenting broad ambitions into measurable milestones ensures consistent progress and resource mobilization.",
      "bn": "ছোট ছোট ধাপে এগোলে বড় সাফল্য লাভ সম্ভব।"
    }
  },
  {
    "id": 37,
    "chapterId": 13,
    "question": {
      "en": "Within life skills frameworks, negotiation is defined as:",
      "bn": "জীবনশৈলীতে আলোচনা বা দরকষাকষি (Negotiation) কী?"
    },
    "options": {
      "en": [
        "Forcing compliance through physical or verbal aggression.",
        "The ability to reach an agreement with others using logic, reason, and empathetic persuasion.",
        "Yielding personal rights silently to avoid conflict.",
        "Tricking others into temporary agreements."
      ],
      "bn": [
        "জোর জবরদস্তি করে নিজের কথা মানানো।",
        "যুক্তি ও সহমর্মিতার সাহায্যে অপরের সাথে বোঝাপড়ায় পৌঁছানোর দক্ষতা।",
        "ঝগড়া এড়াতে নিজের অধিকার নিঃশব্দে ছেড়ে দেওয়া।",
        "মিথ্যা বলে সাময়িক কাজ হাসিল করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Negotiation relies on logic, factual reasoning, and empathetic communication to achieve constructive agreements.",
      "bn": "যুক্তি ও বুদ্ধি দিয়ে আলোচনা করাই সমঝোতার ভিত্তি।"
    }
  },
  {
    "id": 38,
    "chapterId": 13,
    "question": {
      "en": "How does mastering negotiation skills empower an adolescent girl within her family?",
      "bn": "আলোচনার দক্ষতা কীভাবে একজন মেয়েকে পরিবারে শক্তিশালী করে?"
    },
    "options": {
      "en": [
        "It allows her to advocate for continued schooling and delayed marriage through logical dialogue and allies.",
        "It guarantees she will never experience family disagreements.",
        "It forces parents to stop making any household decisions.",
        "It enables her to ignore all domestic responsibilities completely."
      ],
      "bn": [
        "যুক্তি ও শিক্ষক/মেন্টরদের সাহায্যে পড়াশোনা চালিয়ে যাওয়ার ও বিয়ে পেছানোর কথা বোঝানো যায়।",
        "পরিবারে কখনো কোনো বিষয়ে দ্বিমত হয় না।",
        "অভিভাবকদের সব সিদ্ধান্ত নেওয়া বন্ধ করে দেয়।",
        "কোনো কাজ না করার অজুহাত দেয়।"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "Negotiation skills enable girls to articulate the value of education and delayed marriage logically to family decision-makers.",
      "bn": "যুক্তি দিয়ে কথা বললে পরিবার শিক্ষার গুরুত্ব বুঝতে পারে।"
    }
  },
  {
    "id": 39,
    "chapterId": 13,
    "question": {
      "en": "When practicing assertive refusal ('Saying No') to risky or illegal demands, an adolescent should:",
      "bn": "ক্ষতিকর বা বেআইনি প্রস্তাবে 'না' বলার সঠিক নিয়ম কী?"
    },
    "options": {
      "en": [
        "Offer lengthy excuses and apologize repeatedly.",
        "State a firm, direct refusal backed by personal reasons, remaining calm and resolute.",
        "Agree initially and break the promise later.",
        "Respond with immediate physical aggression."
      ],
      "bn": [
        "বারবার ক্ষমা চাওয়া ও অজুহাত দেওয়া।",
        "শান্ত অথচ দৃঢ় গলায় সরাসরি 'না' বলা এবং নিজের সিদ্ধান্তে অটল থাকা।",
        "মুখে হ্যাঁ বলে পরে না করা।",
        "মারপিট করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Assertive refusal is clear, direct, respectful, and firm, protecting safety and personal autonomy.",
      "bn": "শান্ত ও দৃঢ় 'না' নিজের নিরাপত্তা ও স্বাধীনতা রক্ষা করে।"
    }
  },
  {
    "id": 40,
    "chapterId": 14,
    "question": {
      "en": "According to WHO adolescent health guidelines, puberty is best defined as:",
      "bn": "বিশ্ব স্বাস্থ্য সংস্থা অনুযায়ী বয়ঃসন্ধি (Puberty) কী?"
    },
    "options": {
      "en": [
        "A rare physical illness requiring pharmacological intervention.",
        "A natural biological transition of rapid physical maturation and hormonal changes between childhood and adulthood.",
        "A biological transition that occurs exclusively in males.",
        "An artificial shift caused entirely by environmental pollution."
      ],
      "bn": [
        "একটি রোগ যার জন্য ওষুধ খাওয়া প্রয়োজন।",
        "শৈশব থেকে প্রাপ্তবয়স্ক হওয়ার প্রাকৃতিক জৈবিক ও হরমোনের পরিবর্তনের পর্ব।",
        "কেবলমাত্র ছেলেদের ঘটে এমন একটি বিষয়।",
        "পরিবেশ দূষণের কারণে সৃষ্ট একটি কৃত্রিম সমস্যা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "WHO defines puberty as a universal biological growth phase driven by hormones during adolescence (ages 10–19).",
      "bn": "বয়ঃসন্ধি হলো হরমোন দ্বারা পরিচালিত জীবনের স্বাভাবিক বৃদ্ধির ধাপ।"
    }
  },
  {
    "id": 41,
    "chapterId": 14,
    "question": {
      "en": "For early adolescents aged 10–14, global health frameworks identify primary health risks as overwhelmingly tied to:",
      "bn": "১০ থেকে ১৪ বছর বয়সীদের প্রধান স্বাস্থ্যঝুঁকি কোনটির সাথে জড়িত?"
    },
    "options": {
      "en": [
        "Alcohol consumption and driving accidents.",
        "Water, sanitation, and hygiene (WASH) deficiencies and pubertal health gaps.",
        "Occupational workplace injuries in formal factories.",
        "Severe age-related bone density loss."
      ],
      "bn": [
        "গাড়ি দুর্ঘটনা।",
        "পরিষ্কার জল, স্যানিটেশন ও স্বাস্থ্যবিধির (WASH) ঘাটতি এবং বয়ঃসন্ধিকালীন যত্নের অভাব।",
        "কারখানায় কাজের আঘাত।",
        "বয়সজনিত হাড়ের ক্ষয়।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "WHO data confirms that health risks for 10–14-year-olds center on WASH factors and pubertal adjustments.",
      "bn": "এই বয়সে পরিচ্ছন্নতা ও পরিষ্কার জল ব্যবহার সবচেয়ে গুরুত্বপূর্ণ।"
    }
  },
  {
    "id": 42,
    "chapterId": 14,
    "question": {
      "en": "How does scientific understanding of pubertal development benefit adolescent mental well-being?",
      "bn": "বয়ঃসন্ধির বৈজ্ঞানিক তথ্য জানা কীভাবে মানসিক শান্তি দেয়?"
    },
    "options": {
      "en": [
        "It allows adolescents to stop physical growth entirely.",
        "It eliminates shame and fear by framing biological changes as normal, healthy development.",
        "It guarantees immunity from all infectious diseases.",
        "It removes the necessity for daily personal hygiene."
      ],
      "bn": [
        "এটি শরীরের বৃদ্ধি আটকে দেয়।",
        "লজ্জা ও ভয় দূর করে পরিবর্তনকে স্বাভাবিক বিকাশ হিসেবে গ্রহণ করতে শেখায়।",
        "সব রোগ থেকে সম্পূর্ণ মুক্তি দেয়।",
        "পরিচ্ছন্ন থাকার প্রয়োজন শেষ করে।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Understanding puberty demystifies physical shifts, replacing embarrassment with healthy bodily care and self-esteem.",
      "bn": "সঠিক জ্ঞান লজ্জা দূর করে আত্মবিশ্বাস বাড়ায়।"
    }
  },
  {
    "id": 43,
    "chapterId": 15,
    "question": {
      "en": "Biological menstruation is correctly defined as:",
      "bn": "মাসিক বা ঋতুস্রাবের সঠিক বৈজ্ঞানিক সংজ্ঞা কোনটি?"
    },
    "options": {
      "en": [
        "An internal infection caused by unhygienic food.",
        "The natural monthly shedding of the uterine lining in healthy females.",
        "A sign of physical impurity or bad luck.",
        "A temporary digestive dysfunction."
      ],
      "bn": [
        "খারাপ খাবারের কারণে পেটের ভেতরে হওয়া সংক্রমণ।",
        "সুস্থ নারীদের জরায়ুর আস্তরণ প্রতি মাসে স্বাভাবিক নিয়মে ভেঙে বেরিয়ে আসা।",
        "অপবিত্রতা বা দুর্ভাগ্যের লক্ষণ।",
        "হজমের একটি সাময়িক গোলমাল।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Menstruation is a healthy biological process wherein the body sheds the uterine lining monthly.",
      "bn": "মাসিক একটি স্বাভাবিক শারীরবৃত্তীয় প্রক্রিয়া, যা সুস্থতার লক্ষণ।"
    }
  },
  {
    "id": 44,
    "chapterId": 15,
    "question": {
      "en": "Which practice is essential for safe menstrual hygiene management?",
      "bn": "মাসিক চলাকালীন কোন অভ্যাসটি অপরিহার্য?"
    },
    "options": {
      "en": [
        "Changing sanitary pads or clean cloths every 4–6 hours and washing with clean water.",
        "Reusing damp cloths stored in dark, unventilated spaces.",
        "Refraining from bathing for the entire duration of the menstrual period.",
        "Restricting fluid intake completely during menstruation."
      ],
      "bn": [
        "প্রতি ৪–৬ ঘণ্টা অন্তর প্যাড বা কাপড় বদলানো এবং পরিষ্কার জল দিয়ে ধোয়া।",
        "অন্ধকারে রাখা স্যাঁতসেঁতে কাপড় বারবার ব্যবহার করা।",
        "মাসিক চলাকালীন কোনো স্নান না করা।",
        "জল খাওয়া একদম বন্ধ করে দেওয়া।"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "Regular pad or cloth changes (every 4–6 hours) and clean water washing prevent bacterial infections and reproductive tract complications.",
      "bn": "৪-৬ ঘণ্টা পর পর প্যাড বদলানো জীবাণু সংক্রমণ থেকে বাঁচায়।"
    }
  },
  {
    "id": 45,
    "chapterId": 15,
    "question": {
      "en": "How MUST reusable cloth menstrual pads be dried to ensure hygienic safety?",
      "bn": "কাপড়ের প্যাড জীবাণুমুক্ত রাখতে কীভাবে শুকানো বাধ্যতামূলক?"
    },
    "options": {
      "en": [
        "Hidden under mattress furniture away from light.",
        "Washed thoroughly with soap and dried completely in direct, open sunlight.",
        "Rinsed with cold water without soap and reused immediately.",
        "Stored inside plastic bags while damp."
      ],
      "bn": [
        "লজ্জায় খাটের নিচে অন্ধকারে লুকিয়ে রাখা।",
        "সাবান দিয়ে ভালো করে ধুয়ে খোলা কড়া রোদে সম্পূর্ণ শুকানো।",
        "সাবান ছাড়া শুধু জলে ধুয়ে সাথে সাথে পরা।",
        "ভিজে অবস্থায় পলিথিনে মুড়ে রাখা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Direct sunlight acts as a natural ultraviolet disinfectant, killing harmful bacteria on washed cloth pads.",
      "bn": "সূর্যের কড়া রোদ প্রাকৃতিক জীবাণুনাশক হিসেবে কাজ করে।"
    }
  },
  {
    "id": 46,
    "chapterId": 15,
    "question": {
      "en": "Dismantling harmful menstrual taboos (such as restrictions on touching food or attending school) benefits girls by:",
      "bn": "মাসিকের কুসংস্কার ভাঙলে কিশোরীদের কী উপকার হয়?"
    },
    "options": {
      "en": [
        "Allowing them to ignore personal hygiene rules entirely.",
        "Ensuring continuous school attendance, dignified self-care, and equal social participation.",
        "Eliminating the physical need for sanitary products.",
        "Reducing the length of the biological menstrual cycle."
      ],
      "bn": [
        "পরিচ্ছন্নতার নিয়ম না মানলেও চলে।",
        "স্কুলে নিয়মিত উপস্থিতি, আত্মসম্মান এবং স্বাভাবিক জীবনযাত্রা নিশ্চিত হয়।",
        "প্যাডের কোনো দরকার থাকে না।",
        "মাসিকের দিন সংখ্যা কমে যায়।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Countering taboos protects girls' rights to education, dignity, and full social participation during menstruation.",
      "bn": "কুসংস্কার দূর হলে মেয়েরা স্বাধীনভাবে পড়াশোনা ও জীবনে এগোতে পারে।"
    }
  },
  {
    "id": 47,
    "chapterId": 16,
    "question": {
      "en": "Adolescent girls in India face significantly high risks for nutritional anemia primarily due to:",
      "bn": "ভারতে কিশোরীদের অ্যানিমিয়া বা রক্তস্বল্পতার প্রধান কারণ কী?"
    },
    "options": {
      "en": [
        "Excessive physical sports participation.",
        "Iron-deficient diets, monthly menstrual blood loss, and gendered intra-household food disparities.",
        "Overconsumption of fresh citrus fruits.",
        "Spending extended hours studying in school."
      ],
      "bn": [
        "অতিরিক্ত খেলাধুলো করা।",
        "খাবারে আয়রনের ঘাটতি, মাসিকের রক্তক্ষরণ এবং পরিবারে মেয়েদের কম পুষ্টিকর খাবার দেওয়া।",
        "বেশি বেশি লেবু খাওয়া।",
        "বেশি সময় ধরে স্কুলে পড়ালেখা করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Female adolescent anemia is driven by inadequate dietary iron, monthly blood loss, and unequal food distribution favoring males.",
      "bn": "আয়রনের অভাব ও মাসিকের রক্তক্ষরণের কারণে কিশোরীদের রক্তস্বল্পতা বেশি হয়।"
    }
  },
  {
    "id": 48,
    "chapterId": 16,
    "question": {
      "en": "Which local food combination MAXIMIZES plant-based iron absorption in the body?",
      "bn": "কোন খাবারের মিশ্রণ শরীরে উদ্ভিজ্জ আয়রন শোষণ সবচেয়ে বেশি বাড়ায়?"
    },
    "options": {
      "en": [
        "Green leafy vegetables (spinach) paired with Vitamin C rich foods (lemon/amla).",
        "Deep-fried snacks paired with hot tea.",
        "Plain white rice paired exclusively with water.",
        "Sugary carbonated beverages paired with sweets."
      ],
      "bn": [
        "শাকসবজি বা ছোলার সাথে লেবুর রস বা আমলকী (ভিটামিন সি)।",
        "ভাজাপোড়ার সাথে কড়া গরম চা।",
        "শুধুমাত্র সাদা ভাত আর জল।",
        "মিষ্টির সাথে কোল্ড ড্রিঙ্কস।"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "Vitamin C (ascorbic acid) significantly enhances the body's biological absorption of non-heme iron from plant sources.",
      "bn": "ভিটামিন সি উদ্ভিজ্জ আয়রনকে রক্তে সহজে শোষিত হতে সাহায্য করে।"
    }
  },
  {
    "id": 49,
    "chapterId": 16,
    "question": {
      "en": "What are primary physical symptoms of nutritional anemia in adolescents?",
      "bn": "কিশোরীদের রক্তস্বল্পতার প্রধান শারীরিক লক্ষণ কোনটি?"
    },
    "options": {
      "en": [
        "Extreme fatigue, dizziness, pale skin, and impaired cognitive concentration.",
        "Rapid increase in muscle mass and bone height.",
        "Hyperactivity and permanent sleep reduction.",
        "Instant improvement in academic exam scores without study."
      ],
      "bn": [
        "চরম ক্লান্তি, মাথা ঘোরা, ফ্যাকাশে ত্বক এবং পড়ায় মনোযোগের অভাব।",
        "দ্রুত পেশি ও উচ্চতা বেড়ে যাওয়া।",
        "অতিরিক্ত চঞ্চলতা ও ঘুম না হওয়া।",
        "না পড়েই পরীক্ষায় প্রথম হওয়া।"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "Anemia reduces oxygen-carrying hemoglobin in the blood, leading to fatigue, dizziness, pale skin, and reduced focus.",
      "bn": "রক্তে হিমোগ্লোবিন কমে গেলে ক্লান্তি, মাথা ঘোরা ও ফ্যাকাশে ভাব দেখা দেয়।"
    }
  },
  {
    "id": 50,
    "chapterId": 17,
    "question": {
      "en": "The four core pillars of child rights established in international and national frameworks are:",
      "bn": "শিশু অধিকারের ৪টি প্রধান স্তম্ভ কী কী?"
    },
    "options": {
      "en": [
        "Wealth, Authority, Marriage, and Employment.",
        "Protection, Education, Health, and Participation.",
        "Silence, Domestic Labor, Obedience, and Isolation.",
        "Ownership, Competition, Travel, and Command."
      ],
      "bn": [
        "সম্পদ, ক্ষমতা, বিয়ে ও চাকরি।",
        "সুরক্ষা, শিক্ষা, স্বাস্থ্য এবং মত প্রকাশের স্বাধীনতা।",
        "নীরবতা, ঘরের কাজ, বাধ্যতা ও একাকীত্ব।",
        "মালিকানা, প্রতিযোগিতা, ভ্রমণ ও আদেশ।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "The child rights framework establishes Protection, Education, Health, and Participation as fundamental pillars.",
      "bn": "সুরক্ষা, শিক্ষা, স্বাস্থ্য ও মত প্রকাশ হলো শিশুদের ৪টি জন্মগত অধিকার।"
    }
  },
  {
    "id": 51,
    "chapterId": 17,
    "question": {
      "en": "Gender equality within child rights frameworks mandates that:",
      "bn": "শিশু অধিকারে লিঙ্গ সমতা কী নির্দেশ করে?"
    },
    "options": {
      "en": [
        "Boys receive priority access to secondary educational funding.",
        "Girls and boys possess identical legal entitlements to protection, schooling, health, and participation.",
        "Rights depend entirely on household financial status.",
        "Girls are exempt from all civic responsibilities."
      ],
      "bn": [
        "ছেলেরা পড়াশোনার খরচে অগ্রাধিকার পাবে।",
        "ছেলে ও মেয়ে সবার শিক্ষা, স্বাস্থ্য ও সুরক্ষার আইনি অধিকার হুবহু সমান।",
        "অধিকার সম্পূর্ণ পরিবারের আর্থিক অবস্থার ওপর নির্ভর করে।",
        "মেয়েদের কোনো নাগরিক অধিকারের প্রয়োজন নেই।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Gender equality asserts that all children, regardless of sex, hold equal legal rights to development and protection.",
      "bn": "আইন অনুযায়ী ছেলে ও মেয়ে উভয়ের অধিকার সমান।"
    }
  },
  {
    "id": 52,
    "chapterId": 17,
    "question": {
      "en": "How does rights literacy directly empower adolescent girls in rural settings?",
      "bn": "অধিকার সচেতনতা গ্রামের মেয়েদের কীভাবে সাহায্য করে?"
    },
    "options": {
      "en": [
        "It allows them to break local laws without legal consequences.",
        "It enables them to identify discrimination, claim legal protections, and access state support services.",
        "It renders community schools unnecessary.",
        "It guarantees immediate employment at age 12."
      ],
      "bn": [
        "আইন অমান্য করার ক্ষমতা দেয়।",
        "বৈষম্য চিনতে, আইনি সুরক্ষা দাবি করতে এবং সরকারি সাহায্য পেতে সহায়তা করে।",
        "স্কুল যাওয়ার প্রয়োজনীয়তা শেষ করে দেয়।",
        "১২ বছর বয়সে চাকরি এনে দেয়।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Understanding rights enables girls to identify violations, resist discrimination, and utilize legal protections.",
      "bn": "অধিকার জানলে শোষণ ও বঞ্চনা রুখে দাঁড়ানো যায়।"
    }
  },
  {
    "id": 53,
    "chapterId": 18,
    "question": {
      "en": "Under the Prohibition of Child Marriage Act in India, what is the minimum legal age of marriage for females?",
      "bn": "ভারতে বাল্যবিয়ে প্রতিরোধ আইন অনুযায়ী মেয়েদের জন্য বিয়ের সর্বনিম্ন আইনি বয়স কত?"
    },
    "options": {
      "en": [
        "14 years",
        "16 years",
        "18 years",
        "21 years"
      ],
      "bn": [
        "১৪ বছর",
        "১৬ বছর",
        "১৮ বছর",
        "২১ বছর"
      ]
    },
    "correctAnswerIndex": 2,
    "explanation": {
      "en": "The Prohibition of Child Marriage Act mandates a legal minimum age of 18 years for females.",
      "bn": "আইন অনুযায়ী ১৮ বছরের নিচে মেয়েদের বিয়ে দেওয়া কঠোরভাবে নিষিদ্ধ ও দণ্ডনীয়।"
    }
  },
  {
    "id": 54,
    "chapterId": 18,
    "question": {
      "en": "According to WHO global health data, what is the LEADING cause of death among adolescent girls aged 15–19 globally?",
      "bn": "বিশ্ব স্বাস্থ্য সংস্থা (WHO) অনুযায়ী বিশ্বজুড়ে ১৫–১৯ বছর বয়সী কিশোরীদের মৃত্যুর প্রধান কারণ কী?"
    },
    "options": {
      "en": [
        "Occupational industrial hazards.",
        "Pregnancy complications and unsafe abortions.",
        "Severe age-related heart failure.",
        "Infectious malaria exclusively."
      ],
      "bn": [
        "কারখানায় কাজের ঝুঁকি।",
        "অপরিণত বয়সে গর্ভধারণের জটিলতা ও অনিরাপদ গর্ভপাত।",
        "বার্ধক্যজনিত হৃদরোগ।",
        "ম্যালেরিয়া রোগ।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "WHO health data confirms that pregnancy complications and unsafe abortions are the leading mortality driver for girls aged 15–19 globally.",
      "bn": "অল্প বয়সে গর্ভধারণ কিশোরীদের জীবনের জন্য সবচেয়ে বড় ঝুঁকি।"
    }
  },
  {
    "id": 55,
    "chapterId": 18,
    "question": {
      "en": "If an adolescent girl faces the imminent threat of forced child marriage, she should immediately:",
      "bn": "জোরপূর্বক বাল্যবিয়ের মুখে পড়লে সাথে সাথে কী করা উচিত?"
    },
    "options": {
      "en": [
        "Accept the marriage silently without informing support networks.",
        "Contact CHILDLINE (1098), Women Helpline (181), or local Child Protection Committees.",
        "Run away alone without telling anyone.",
        "Drop out of school immediately."
      ],
      "bn": [
        "চুপচাপ মেনে নেওয়া।",
        "১০৯৮ (চাইল্ডলাইন), ১৮১ (নারী হেল্পলাইন) বা স্থানীয় শিশু সুরক্ষা কমিটিতে জানানো।",
        "কাউকে না জানিয়ে একা পালিয়ে যাওয়া।",
        "স্কুল ছেড়ে দেওয়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "National emergency helplines (1098/181) and local CPCs provide legal protection, rescue, and counseling.",
      "bn": "১০৯৮ বা ১৮১ নম্বরে ফোন করলে তৎক্ষণাৎ আইনি উদ্ধার ও সুরক্ষা পাওয়া যায়।"
    }
  },
  {
    "id": 56,
    "chapterId": 18,
    "question": {
      "en": "Postponing marriage past age 18 provides which major long-term benefits for young women?",
      "bn": "১৮ বছরের পর বিয়ে পিছিয়ে দিলে মেয়েদের কী দীর্ঘমেয়াদী লাভ হয়?"
    },
    "options": {
      "en": [
        "Lower chances of completing secondary education.",
        "Improved health outcomes, completion of education, and higher economic self-reliance.",
        "Guaranteed elimination of all future household chores.",
        "Complete loss of legal rights."
      ],
      "bn": [
        "পড়াশোনা শেষ হওয়ার সম্ভাবনা কমে যায়।",
        "উন্নত স্বাস্থ্য, পড়াশোনা সমাপ্তি এবং অর্থনৈতিক স্বাবলম্বী হওয়ার সুযোগ।",
        "কোনো কাজ না করার গ্যারান্টি।",
        "সব আইনি অধিকার হারিয়ে যাওয়া।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Delaying marriage past 18 protects reproductive health, enables high school/vocational completion, and builds economic agency.",
      "bn": "১৮-র পরে বিয়ে সুস্বাস্থ্য ও স্বাবলম্বী হওয়ার পথ খুলে দেয়।"
    }
  },
  {
    "id": 57,
    "chapterId": 19,
    "question": {
      "en": "Under Indian child protection laws (POCSO Act), an 'Unsafe Touch' is defined as any touch that:",
      "bn": "পকসো (POCSO) আইন অনুযায়ী 'অনিরাপদ স্পর্শ' (Unsafe Touch) কী?"
    },
    "options": {
      "en": [
        "Makes a child feel safe, cared for, and comfortable.",
        "Causes physical pain, discomfort, confusion, or involves private body parts.",
        "Occurs during a supervised sports match.",
        "Involves shaking hands during a formal greeting."
      ],
      "bn": [
        "নিরাপদ ও ভালোবাসার অনুভূতি দেয়।",
        "ভয়, অস্বস্তি বা দ্বিধা তৈরি করে অথবা গোপনাঙ্গে হাত দেওয়ার চেষ্টা করে।",
        "খেলাধুলোর সময় স্বাভাবিক স্পর্শ।",
        "কুশল বিনিময়ে হাত মেলানো।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Unsafe touch involves contact with private body areas or any physical contact causing fear, discomfort, or confusion.",
      "bn": "সাঁতারের পোশাকে ঢাকা অংশে হাত দেওয়া বা ভয় ও অস্বস্তি সৃষ্টি করা স্পর্শই অনিরাপদ।"
    }
  },
  {
    "id": 58,
    "chapterId": 19,
    "question": {
      "en": "If an adolescent girl experiences unsafe touch or sexual abuse, who carries full legal and moral responsibility?",
      "bn": "অনিরাপদ স্পর্শ বা যৌন নির্যাতনের শিকার হলে পুরো দোষ ও আইনি দায় কার?"
    },
    "options": {
      "en": [
        "The child for leaving her home.",
        "The abuser alone—the child is NEVER at fault under any circumstances.",
        "School teachers exclusively.",
        "Shared equal guilt between the child and adult."
      ],
      "bn": [
        "মেয়েটির নিজের, বাইরে বের হওয়ার কারণে।",
        "সম্পূর্ণ নির্যাতনকারীর—মেয়েটির এতে কোনো দোষ নেই।",
        "শুধুমাত্র স্কুল শিক্ষকের।",
        "উভয়ের সমান দোষ।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Under the law, victims of abuse carry zero guilt; full legal and moral responsibility rests entirely on the perpetrator.",
      "bn": "নির্যাতনের শিকার ব্যক্তির কোনো দোষ থাকে না, অপরাধ সম্পূর্ণ অপরাধীর।"
    }
  },
  {
    "id": 59,
    "chapterId": 19,
    "question": {
      "en": "What is the correct sequence of the standard child personal safety rule?",
      "bn": "শিশুদের আত্মরক্ষার আন্তর্জাতিক ৩টি নিয়মের সঠিক ক্রম কোনটি?"
    },
    "options": {
      "en": [
        "Hide - Keep Secret - Apologize",
        "NO - GO - TELL",
        "Ignore - Wait - Forget",
        "Agree - Stay Silent - Cry"
      ],
      "bn": [
        "লুকাও - গোপন রাখো - ক্ষমা চাও",
        "না বলো (NO) - সরে যাও (GO) - বড়দের জানাও (TELL)",
        "উপেক্ষা করো - অপেক্ষা করো - ভুলে যাও",
        "রাজি হও - চুপ থাকো - কাঁদো"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "The NO-GO-TELL rule directs children to say NO firmly, GO away safely, and TELL a trusted adult immediately.",
      "bn": "জোরে না বলো, নিরাপদ জায়গায় সরে যাও এবং সাথে সাথে বড়দের জানাও।"
    }
  },
  {
    "id": 60,
    "chapterId": 20,
    "question": {
      "en": "What is the official 24/7 national toll-free helpline shortcode for children under 18 in distress across India?",
      "bn": "ভারতে ১৮ বছরের কম বয়সী শিশুদের বিপদে ২৪ ঘণ্টা বিনামূল্যে ফোন করার জাতীয় হেল্পলাইন কোনটি?"
    },
    "options": {
      "en": [
        "100",
        "1098",
        "108",
        "14400"
      ],
      "bn": [
        "১০০",
        "১০৯৮",
        "১০৮",
        "১৪৪০০"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "CHILDLINE 1098 is the dedicated 24/7 national toll-free emergency phone service for children under 18.",
      "bn": "১০৯৮ হলো চাইল্ডলাইনের ২৪ ঘণ্টার জরুরি সেবা নম্বর।"
    }
  },
  {
    "id": 61,
    "chapterId": 20,
    "question": {
      "en": "The Women Helpline shortcode '181' is funded under which national component and linked to which key institutions?",
      "bn": "নারী ও কিশোরী হেল্পলাইন '১৮১' কোন সরকারি উদ্যোগের অধীনে পরিচালিত?"
    },
    "options": {
      "en": [
        "Funded under private corporate schemes; linked to commercial banks.",
        "Funded under the Sambal component of Mission Shakti; linked to One Stop Centres (Sakhi Centres) and Police.",
        "Funded under transport schemes; linked exclusively to bus terminals.",
        "Funded under sports councils; linked to gymnasiums."
      ],
      "bn": [
        "একটি বেসরকারি ব্যাংক উদ্যোগ।",
        "মিশন শক্তির সাম্বল প্রকল্পের অংশ; ওয়ান স্টপ সেন্টার (সখী সেন্টার) ও পুলিশের সাথে যুক্ত।",
        "পরিবহন বিভাগের অধীন।",
        "ক্রীড়া পরিষদের অধীন।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "WHL 181 is funded under the Sambal component of Mission Shakti and structurally linked to HEW, Sakhi Centres, and police networks.",
      "bn": "১৮১ নম্বর সখী সেন্টার ও নারী সুরক্ষার সাথে সরাসরি যুক্ত।"
    }
  },
  {
    "id": 62,
    "chapterId": 20,
    "question": {
      "en": "Which official emergency helpline operates from New Delhi premises and is staffed specifically by Psychological Counsellors trained in topmost Mental Health institutions?",
      "bn": "নতুন দিল্লির শীর্ষ মানসিক স্বাস্থ্য প্রতিষ্ঠানের বিশেষজ্ঞদের দ্বারা পরিচালিত হেল্পলাইন কোনটি?"
    },
    "options": {
      "en": [
        "NCW Helpline (14490)",
        "Fire Response (101)",
        "Traffic Police (103)",
        "Commercial Helpline (1800)"
      ],
      "bn": [
        "মহিলা কমিশন হেল্পলাইন (১৪৪৯০)",
        "দমকল সেবা (১০১)",
        "ট্রাফিক পুলিশ (১০৩)",
        "বিজ্ঞাপন হেল্পলাইন (১৮০০)"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "The NCW Helpline 14490 operates from New Delhi premises and employs expert psychological counselors trained in leading mental health institutions.",
      "bn": "জাতীয় মহিলা কমিশন হেল্পলাইন ১৪৪৯০ মানসিক ও আইনি পরামর্শ প্রদান করে।"
    }
  },
  {
    "id": 63,
    "chapterId": 20,
    "question": {
      "en": "All national emergency shortcodes (1098, 181, 112, 14490) share which vital operational feature?",
      "bn": "সরকারি জরুরি নম্বরগুলোর (১০৯৮, ১৮১, ১১২, ১৪৪৯০) সবচেয়ে বড় সুবিধা কী?"
    },
    "options": {
      "en": [
        "They require high-speed internet connections.",
        "They are completely toll-free, operating 24/7 without requiring mobile talktime balance.",
        "They operate only during regular daytime office hours.",
        "They require written parental consent prior to calling."
      ],
      "bn": [
        "এদের জন্য দ্রুতগতির ইন্টারনেট দরকার।",
        "এগুলো দিনরাত ২৪ ঘণ্টা সম্পূর্ণ বিনামূল্যে এবং মোবাইলে কোনো টাকা না থাকলেও কল করা যায়।",
        "শুধু দিনের বেলা অফিস চলাকালীন খোলা থাকে।",
        "অভিভাবকের অনুমতিপত্র ছাড়া ফোন করা যায় না।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "All national emergency shortcodes are toll-free, 24/7 services accessible from any mobile phone without talktime balance.",
      "bn": "কোনো ব্যালেন্স ছাড়াই যে কোনো ফোন থেকে ২৪ ঘণ্টা কল করা সম্ভব।"
    }
  },
  {
    "id": 64,
    "chapterId": 21,
    "question": {
      "en": "Which practice represents safe digital hygiene for mobile phone usage?",
      "bn": "স্মার্টফোন ব্যবহারে সাইবার সুরক্ষার সঠিক নিয়ম কোনটি?"
    },
    "options": {
      "en": [
        "Sharing account passwords with close school friends for trust.",
        "Maintaining private account settings and keeping location data confidential.",
        "Posting daily school schedules and home addresses publicly.",
        "Accepting friend requests from unknown strangers without verification."
      ],
      "bn": [
        "বন্ধুদের বিশ্বাসের খাতিরে পাসওয়ার্ড বলে দেওয়া।",
        "প্রোফাইল প্রাইভেট রাখা এবং নিজের লোকেশন ও ব্যক্তিগত তথ্য গোপন রাখা।",
        "বাড়ির ঠিকানা ও স্কুলের সময়সূচি ইন্টারনেটে পোস্ট করা।",
        "অপরিচিত কারও ফ্রেন্ড রিকোয়েস্ট যাচাই না করে গ্রহণ করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Restricting account privacy settings and keeping location data private prevents online harassment and cyber exploitation.",
      "bn": "গোপনীয়তা বজায় রাখলে ইন্টারনেটে অনিরাপদ পরিস্থিতি এড়ানো যায়।"
    }
  },
  {
    "id": 65,
    "chapterId": 21,
    "question": {
      "en": "If an adolescent girl receives harassment or blackmail threats online, her immediate action should be to:",
      "bn": "ইন্টারনেটে কেউ ব্ল্যাকমেইল বা হুমকির বার্তা পাঠালে সাথে সাথে কী করা উচিত?"
    },
    "options": {
      "en": [
        "Comply with the harasser's demands secretly.",
        "Take screenshots as evidence, block the user immediately, and report the incident to a trusted adult or helpline.",
        "Destroy her phone without saving evidence.",
        "Harass the abuser in return."
      ],
      "bn": [
        "ভয়ে তার সব দাবি মেনে নেওয়া।",
        "প্রমাণ হিসেবে স্ক্রিনশট রাখা, তাকে ব্লক করা এবং বড়দের ও হেল্পলাইনে জানানো।",
        "প্রমাণ না রেখেই ফোন ভেঙে ফেলা।",
        "পাল্টা গালিগালাজ করা।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Capturing screenshots preserves legal evidence, while blocking and reporting halts harassment and activates protective intervention.",
      "bn": "স্ক্রিনশট রাখা আইনি প্রমাণ দেয় এবং ব্লক করলে তাৎক্ষণিক সুরক্ষা মেলে।"
    }
  },
  {
    "id": 66,
    "chapterId": 21,
    "question": {
      "en": "Digital literacy empowers adolescent girls by:",
      "bn": "ডিজিটাল সাক্ষরতা বা সচেতনতা মেয়েদের কীভাবে সাহায্য করে?"
    },
    "options": {
      "en": [
        "Replacing physical schooling entirely.",
        "Providing safe access to learning, information, and life skills while protecting personal privacy online.",
        "Forcing them to spend 12 hours online daily.",
        "Guaranteeing immediate financial wealth."
      ],
      "bn": [
        "স্কুলে যাওয়ার প্রয়োজনীয়তা শেষ করে।",
        "নিরাপদে পড়াশোনা ও নতুন দক্ষতা শেখার সুযোগ দেয় এবং সাইবার বিপদ থেকে রক্ষা করে।",
        "সারাদিন ইন্টারনেটে সময় কাটাতে বাধ্য করে।",
        "হঠাৎ ধনী বানিয়ে দেয়।"
      ]
    },
    "correctAnswerIndex": 1,
    "explanation": {
      "en": "Digital literacy enables informed navigation of digital tools for education and agency while protecting online well-being.",
      "bn": "সচেতনভাবে ইন্টারনেট ব্যবহার করলে জ্ঞানের দরজা খুলে যায়।"
    }
  },
  {
    "id": 67,
    "chapterId": 21,
    "question": {
      "en": "Which official national portal allows citizens to report cybercrime, online harassment, and digital child exploitation in India?",
      "bn": "ভারতে অনলাইনে হয়রানি বা সাইবার অপরাধের অভিযোগ জানানোর জাতীয় ওয়েবসাইট কোনটি?"
    },
    "options": {
      "en": [
        "National Cyber Crime Reporting Portal (cybercrime.gov.in)",
        "General Postal Portal",
        "Commercial Sports Portal",
        "Public Weather Service Portal"
      ],
      "bn": [
        "ন্যাশনাল সাইবার ক্রাইম রিপোর্টিং পোর্টাল (cybercrime.gov.in)",
        "সাধারণ ডাক বিভাগ পোর্টাল",
        "খেলাধুলো পোর্টাল",
        "আবহাওয়া পোর্টাল"
      ]
    },
    "correctAnswerIndex": 0,
    "explanation": {
      "en": "The National Cyber Crime Reporting Portal (cybercrime.gov.in) is India's official platform for reporting online harassment, cyber fraud, and digital exploitation.",
      "bn": "cybercrime.gov.in হলো ভারত সরকারের সাইবার অপরাধে অভিযোগ জানানোর সরকারি মাধ্যম।"
    }
  }
];

export const BADGES: Badge[] = [
  {
    "id": "badge_first_chapter",
    "title": {
      "en": "First Lesson Completed 🎓",
      "bn": "প্রথম পাঠ সম্পন্ন 🎓"
    },
    "description": {
      "en": "Earned by completing your very first life skills educational module.",
      "bn": "জীবনের প্রথম শিক্ষামূলক অধ্যায় সফলভাবে শেষ করার জন্য অর্জিত!"
    },
    "emoji": "🎓"
  },
  {
    "id": "badge_phase1_master",
    "title": {
      "en": "Self-Awareness Champ 🌸",
      "bn": "আত্মসচেতনতা চ্যাম্পিয়ন 🌸"
    },
    "description": {
      "en": "Mastered Phase 1: Self-Awareness, Body Positivity & Dignity Affirmation.",
      "bn": "প্রথম পর্যায়: আত্মসচেতনতা ও আত্মমর্যাদা সফলভাবে সমাপ্ত করার জন্য অর্জিত!"
    },
    "emoji": "🌸"
  },
  {
    "id": "badge_phase2_master",
    "title": {
      "en": "Effective Communicator 💬",
      "bn": "দক্ষ যোগাযোগকারী 💬"
    },
    "description": {
      "en": "Mastered Phase 2: Communication, Teamwork & Personal Boundaries.",
      "bn": "দ্বিতীয় পর্যায়: কার্যকর যোগাযোগ ও সুস্থ সীমানা নির্ধারণের জন্য অর্জিত!"
    },
    "emoji": "💬"
  },
  {
    "id": "badge_phase3_master",
    "title": {
      "en": "Resilience Ambassador 🌱",
      "bn": "সহনশীলতা দূত 🌱"
    },
    "description": {
      "en": "Mastered Phase 3: Emotion Regulation, Stress Management & Overcoming Adversity.",
      "bn": "তৃতীয় পর্যায়: আবেগ নিয়ন্ত্রণ ও মানসিক চাপ মোকাবিলার জন্য অর্জিত!"
    },
    "emoji": "🌱"
  },
  {
    "id": "badge_phase4_master",
    "title": {
      "en": "Strategic Decision Maker 🧭",
      "bn": "দূরদর্শী সিদ্ধান্তগ্রাহক 🧭"
    },
    "description": {
      "en": "Mastered Phase 4: Critical Thinking, SMART Goals & Negotiation.",
      "bn": "চতুর্থ পর্যায়: গঠনমূলক চিন্তা ও লক্ষ্য নির্ধারণে পারদর্শিতার জন্য অর্জিত!"
    },
    "emoji": "🧭"
  },
  {
    "id": "badge_phase5_master",
    "title": {
      "en": "Health & Hygiene Pioneer 🌺",
      "bn": "স্বাস্থ্য ও হাইজিন অগ্রদূত 🌺"
    },
    "description": {
      "en": "Mastered Phase 5: Puberty, Menstrual Hygiene & Anemia Prevention.",
      "bn": "পঞ্চম পর্যায়: বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টির পাঠ সম্পূর্ণ করার জন্য অর্জিত!"
    },
    "emoji": "🌺"
  },
  {
    "id": "badge_phase6_master",
    "title": {
      "en": "Rights & Safety Guardian ⚖️",
      "bn": "অধিকার ও সুরক্ষা অভিভাবক ⚖️"
    },
    "description": {
      "en": "Mastered Phase 6: Child Rights, Child Marriage Laws, Helplines & Cyber Safety.",
      "bn": "ষষ্ঠ পর্যায়: শিশু অধিকার, বাল্যবিয়ে প্রতিরোধ ও সাইবার সুরক্ষার জন্য অর্জিত!"
    },
    "emoji": "⚖️"
  },
  {
    "id": "badge_all_chapters",
    "title": {
      "en": "21-Chapter Curriculum Graduate 👑",
      "bn": "২১ অধ্যায়ের পাঠক্রম গ্র্যাজুয়েট 👑"
    },
    "description": {
      "en": "Successfully finished all 21 chapters of the comprehensive Sakhi LSE curriculum!",
      "bn": "সখী ২১ অধ্যায়ের পূর্ণাঙ্গ পাঠক্রমের সবকটি পাঠ সফলভাবে শেষ করেছো!"
    },
    "emoji": "👑"
  },
  {
    "id": "badge_quiz_champion_a",
    "title": {
      "en": "Quiz Master 🏆",
      "bn": "কুইজ মাস্টার 🏆"
    },
    "description": {
      "en": "Scored 100% on a chapter quiz assessment.",
      "bn": "কুইজে শতভাগ নিখুঁত ফলাফল করার জন্য অর্জিত!"
    },
    "emoji": "🏆"
  },
  {
    "id": "badge_screen_pioneer",
    "title": {
      "en": "Balanced Digital Learner ⏳",
      "bn": "সচেতন মোবাইল ব্যবহারকারী ⏳"
    },
    "description": {
      "en": "Turned idle phone usage into focused education using the screen tracker.",
      "bn": "মোবাইলে অহেতুক সময় নষ্ট না করে ইতিবাচক শিক্ষায় সময় দেওয়ার জন্য অর্জিত!"
    },
    "emoji": "⏳"
  }
];

export const HELPLINES: Helpline[] = [
  {
    "name": {
      "en": "CHILDLINE (Ministry of Women & Child Dev)",
      "bn": "চাইল্ডলাইন (শিশু সুরক্ষা হেল্পলাইন)"
    },
    "number": "1098",
    "description": {
      "en": "24/7 toll-free emergency phone service for children under 18 in distress across India.",
      "bn": "১৮ বছরের কম বয়সী শিশুদের যে কোনো বিপদে ২৪ ঘণ্টা বিনামূল্যে উদ্ধারের জাতীয় নম্বর।"
    },
    "iconName": "Phone"
  },
  {
    "name": {
      "en": "Women Helpline (Mission Shakti)",
      "bn": "নারী হেল্পলাইন (মিশন শক্তি)"
    },
    "number": "181",
    "description": {
      "en": "24/7 toll-free emergency response for women/girls, linked to One Stop Sakhi Centres & police.",
      "bn": "নির্যাতন ও পারিবারিক সহিংসতার বিরুদ্ধে ২৪ ঘণ্টা বিনামূল্যে সহায়তা ও সখী সেন্টারের সাথে যুক্ত।"
    },
    "iconName": "Heart"
  },
  {
    "name": {
      "en": "Emergency Response Support System (ERSS)",
      "bn": "জরুরি সেবা (পুলিশ, দমকল ও অ্যাম্বুলেন্স)"
    },
    "number": "112",
    "description": {
      "en": "Single nationwide emergency dispatch for police, fire, or medical ambulance rescue.",
      "bn": "পুলিশ, দমকল এবং অ্যাম্বুলেন্সের জন্য দেশের একীভূত জরুরি হেল্পলাইন নম্বর।"
    },
    "iconName": "AlertTriangle"
  },
  {
    "name": {
      "en": "National Commission for Women (NCW)",
      "bn": "জাতীয় মহিলা কমিশন হেল্পলাইন"
    },
    "number": "14490",
    "description": {
      "en": "24/7 toll-free psychological & legal counseling staffed by mental health professionals in New Delhi.",
      "bn": "নতুন দিল্লির শীর্ষ মানসিক স্বাস্থ্য প্রতিষ্ঠানের বিশেষজ্ঞদের দ্বারা ২৪ ঘণ্টার মানসিক ও আইনি পরামর্শ।"
    },
    "iconName": "ShieldCheck"
  },
  {
    "name": {
      "en": "National Cyber Crime Reporting Portal",
      "bn": "সাইবার অপরাধ সেল ও সুরক্ষা"
    },
    "number": "1930",
    "description": {
      "en": "To report internet blackmail, online harassment, photo extortion or scams immediately.",
      "bn": "ইন্টারনেটে ছবি নিয়ে ব্ল্যাকমেইল বা সাইবার হয়রানির বিরুদ্ধে দ্রুত অভিযোগের নম্বর।"
    },
    "iconName": "Lock"
  },
  {
    "name": {
      "en": "Tele MANAS (Mental Health Support)",
      "bn": "টেলি মানস (মানসিক স্বাস্থ্য সহায়তা)"
    },
    "number": "14416",
    "description": {
      "en": "24/7 comprehensive digital mental health network for stress, depression and emotional crisis.",
      "bn": "তীব্র মানসিক চাপ ও হতাশা দূর করতে সরকারি ২৪ ঘণ্টার মানসিক স্বাস্থ্য পরামর্শ সেবা।"
    },
    "iconName": "Smile"
  }
];

export const DAILY_AFFIRMATIONS = [
  {
    "en": "I am deserving of respect, education, and safe space, just like every other child.",
    "bn": "অন্যান্য সমস্ত শিশুর মতোই আমিও সম্মান, সুযোগ এবং পড়ালেখার পূর্ণ অধিকার রাখি।"
  },
  {
    "en": "My body is strong, natural, and developing normally. I take pride in my health.",
    "bn": "আমার শরীর অত্যন্ত শক্তিশালী, স্বাভাবিক এবং সুন্দর। আমি সবসময় আমার পরিচ্ছন্নতার দিকে নজর দেব।"
  },
  {
    "en": "Assertive speaking conveys my needs clearly with calm respect. My voice matters.",
    "bn": "আমার চেঁচামেচি করার প্রয়োজন নেই। আমার শান্ত ও স্পষ্ট গলার কথাই যথেষ্ট।"
  },
  {
    "en": "Peer pressure cannot make choices for me. I am the ruler of my own values.",
    "bn": "বন্ধুদের অন্যায় চাপ আমার জীবনে সিদ্ধান্ত নিতে পারে না। আমি আমার নীতির ওপর অটল।"
  },
  {
    "en": "Education is my fundamental right. My dreams are valid and I will achieve them.",
    "bn": "শিক্ষা আমার জন্মগত অধিকার। আমার দেখা স্বপ্নগুলো সত্যি এবং আমি তা পূরণ করবোই।"
  },
  {
    "en": "Whenever I feel overwhelmed, I pause and take five deep breaths. I am safe and resilient.",
    "bn": "যখনই আমার ভয় করবে, আমি ৫ বার গভীর শ্বাস নেব। আমি সম্পূর্ণ নিরাপদ এবং সহনশীল।"
  }
];
