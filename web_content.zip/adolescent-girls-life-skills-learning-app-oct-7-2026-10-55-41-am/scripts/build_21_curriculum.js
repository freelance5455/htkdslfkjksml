import fs from 'fs';

const chapters = [
  {
    id: 1,
    phase: 1,
    phaseTitle: { en: "Self-Awareness & Body Positivity", bn: "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা" },
    category: "self-awareness",
    emoji: "🌸",
    title: {
      en: "Understanding Myself & Building Self-Identity",
      bn: "নিজেকে জানা ও আত্মপরিচয় গঠন"
    },
    summary: {
      en: "Accurately assess personal feelings, interests, values, and strengths to build self-worth and identity.",
      bn: "নিজের অনুভূতি, আগ্রহ, মূল্যবোধ এবং শক্তিকে চিনে আত্মমর্যাদা ও ইতিবাচক পরিচয় গড়ে তোলা।"
    },
    content: {
      en: [
        "13-year-old Priya excels at mathematics and loves organizing community games in her village. However, her relatives frequently remind her that girls should remain quiet and focus on domestic chores.",
        "Torn between societal expectations and her own capabilities, Priya attends a local Adolescent Circle session. 'Priya, when adults tell you to be quiet, do you feel like your thoughts don't matter?' asked her mentor, Sunita.",
        "'Sometimes I feel invisible,' Priya admitted quietly. 'I love solving math problems, but everyone says it won't help me run a household.' 'Your skills and passions are real, Priya,' Sunita affirmed. 'Self-awareness means looking inside yourself to recognize your true worth, separate from external stereotypes.'",
        "Self-awareness enables an adolescent girl to accept herself, recognize that social limitations are external barriers rather than personal shortcomings, and build a strong self-identity grounded in personal dignity."
      ],
      bn: [
        "১৩ বছর বয়সী প্রিয়া অঙ্কে খুব দক্ষ এবং গ্রামে বন্ধুদের নিয়ে খেলাধুলো আয়োজন করতে ভালোবাসে। কিন্তু আত্মীয়রা তাকে প্রায়ই বলে—মেয়েদের চুপচাপ থাকা উচিত এবং ঘরের কাজেই মন দেওয়া দরকার।",
        "সামাজিক প্রত্যাশা আর নিজের প্রতিভার দ্বন্দ্বে পড়ে প্রিয়া কিশোরী সভার একটি অধিবেশনে যায়। সেখানে মেন্টর সুনীতা তাকে জিজ্ঞেস করেন: 'প্রিয়া, যখন বড়রা তোমাকে চুপ থাকতে বলে, তখন কি মনে হয় তোমার কথার কোনো দাম নেই?'",
        "'মাঝে মাঝে নিজেকে অদৃশ্য মনে হয়,' প্রিয়া শান্তভাবে বলল। 'আমি অঙ্ক করতে ভালোবাসি, কিন্তু সবাই বলে এটা সংসার চালাতে কাজে লাগবে না।' সুনীতা বললেন: 'তোমার দক্ষতা বাস্তব, প্রিয়া। আত্মসচেতনতা মানে নিজের ভেতরের শক্তিকে চেনা, বাইরের বাঁধাধরা ধারণার বাইরে গিয়ে নিজের মূল্য বোঝা।'",
        "আত্মসচেতনতা একজন কিশোরীকে নিজেকে ভালোবাসতে শেখায়, সামাজিক বাধাকে নিজের অক্ষমতা না ভেবে বাহ্যিক প্রতিবন্ধকতা হিসেবে চিনতে সাহায্য করে এবং আত্মমর্যাদার সাথে নিজের পরিচয় তৈরি করে।"
      ]
    },
    branchingScenario: {
      scenario: {
        en: "Relatives tell Priya to put away her math books to clean the kitchen.",
        bn: "আত্মীয়রা প্রিয়াকে অঙ্কের বই সরিয়ে রান্নাঘর পরিষ্কার করতে নির্দেশ দেয়।"
      },
      choiceA: {
        en: "Hide her books and assume girls shouldn't pursue academics.",
        bn: "বই লুকিয়ে ফেলা এবং ধরে নেওয়া যে মেয়েদের পড়াশোনা করা সাজে না।"
      },
      resultA: {
        en: "Lowers self-esteem, reinforces external limits.",
        bn: "আত্মবিশ্বাস হ্রাস পায় এবং সীমাবদ্ধতাকে চিরস্থায়ী করে তোলে।"
      },
      choiceB: {
        en: "Open 'My Strengths Journal' and plan a structured daily schedule balancing study and chores.",
        bn: "'আমার শক্তির খাতা' খুলে পড়াশোনা ও ঘরের কাজের মধ্যে একটি সুষম সময়সূচি তৈরি করা।"
      },
      resultB: {
        en: "Builds internal agency, protects educational rights, and establishes self-identity.",
        bn: "নিজের ওপর নিয়ন্ত্রণ আনে, পড়ার অধিকার রক্ষা করে এবং আত্মপরিচয় সুদৃঢ় করে।"
      }
    },
    actionableTakeaways: {
      en: [
        "In-App Daily Strength Inventory: Log three specific accomplishments or personal qualities into your strength tracker every evening.",
        "Interactive Emotion Tracker: Use the app's visual emotion wheel twice daily to name and log current feelings without self-judgment.",
        "Digital Personal Values Journal: Complete daily 2-minute guided journaling prompts to document joy-bringing activities and academic goals."
      ],
      bn: [
        "দৈনিক শক্তির হিসাব: প্রতিদিন সন্ধ্যায় নিজের ৩টি ভালো গুণ বা অর্জন অ্যাপে লিখে রাখো।",
        "অনুভূতি চাকা (Emotion Wheel): দিনে দুবার নিজের মনের ভাব বিচার না করে সঠিকভাবে চিহ্নিত করো।",
        "ব্যক্তিগত লক্ষ্যের ডায়েরি: প্রতিদিন ২ মিনিট লিখে রাখো কোন কাজগুলো তোমাকে আনন্দ দেয় এবং তোমার লক্ষ্য কী।"
      ]
    },
    keyTakeaway: {
      en: "Self-awareness is recognizing your true worth, separate from external stereotypes. Your strengths define who you are.",
      bn: "আত্মসচেতনতা হলো সমাজের বাধানিষেধের বাইরে গিয়ে নিজের আসল মূল্য বোঝা। তোমার দক্ষতাই তোমার পরিচয়।"
    }
  },
  {
    id: 2,
    phase: 1,
    phaseTitle: { en: "Self-Awareness & Body Positivity", bn: "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা" },
    category: "self-awareness",
    emoji: "🌟",
    title: {
      en: "Embracing Strengths & Body Positivity",
      bn: "নিজের শক্তিকে গ্রহণ ও শারীরিক ইতিবাচকতা"
    },
    summary: {
      en: "Develop positive self-esteem, counter body-shaming, and affirm physical and mental growth during puberty.",
      bn: "আত্মমর্যাদা বাড়ানো, বডি-শেমিং বা শারীরিক কটূক্তি প্রতিরোধ করা এবং বয়ঃসন্ধিকালের পরিবর্তনকে স্বাভাবিকভাবে গ্রহণ করা।"
    },
    content: {
      en: [
        "14-year-old Sunita has grown much taller than her classmates over the past six months. At school, classmates tease her about her changing height and voice, leading her to slouch in an attempt to look smaller.",
        "'Sunita, why are you sitting all bent over?' asked her classmate Anita during recess. 'If I stand up straight, everyone laughs because I look like a palm tree,' Sunita replied, looking down.",
        "'Your growth spurt is a sign that your body is developing normally,' her teacher reminded her later. 'Your body is working hard to grow strong. You should honor it, not hide it.'",
        "WHO health guidelines define adolescence as a distinct developmental stage marked by rapid biological, cognitive, and psychosocial transitions. Body positivity involves recognizing that pubertal changes are normal, shifting focus from appearance standards to body functionality and health."
      ],
      bn: [
        "১৪ বছর বয়সী সুনীতা গত ছয় মাসে তার সহপাঠীদের চেয়ে অনেক লম্বা হয়ে গেছে। স্কুলে সবাই তার উচ্চতা ও কণ্ঠস্বরের পরিবর্তন নিয়ে মজা করায় সে নিজেকে খাটো দেখানোর জন্য কুঁজো হয়ে বসে থাকে।",
        "টিফিনের সময় অনিতা জিজ্ঞেস করল: 'সুনীতা, তুই এমন ঝুঁকে বসে আছিস কেন?' সুনীতা চোখ নামিয়ে বলল: 'সোজা হয়ে দাঁড়ালে সবাই আমাকে তালগাছ বলে হাসাহাসি করে।'",
        "পরে তার শিক্ষিকা বললেন: 'এই দ্রুত বৃদ্ধি প্রমাণ করে তোমার শরীর স্বাভাবিকভাবে বাড়ছে। তোমার শরীর শক্তিশালী হয়ে উঠছে। একে লুকানোর কিছু নেই, সম্মান জানাও।'",
        "বিশ্ব স্বাস্থ্য সংস্থা (WHO) অনুযায়ী বয়ঃসন্ধিকাল হলো দ্রুত শারীরিক ও মানসিক পরিবর্তনের সময়। শারীরিক ইতিবাচকতা মানে হলো বাইরের চেহারার সৌন্দর্যের চেয়ে শরীরের কার্যক্ষমতা ও সুস্থতাকে বেশি গুরুত্ব দেওয়া।"
      ]
    },
    branchingScenario: {
      scenario: {
        en: "Classmates tease Sunita about her height during lunch recess.",
        bn: "টিফিনের সময় সহপাঠীরা সুনীতার উচ্চতা নিয়ে ঠাট্টা-বিদ্রূপ করে।"
      },
      choiceA: {
        en: "Slouch, avoid eating lunch, and isolate indoors.",
        bn: "কুঁজো হয়ে থাকা, খাবার না খাওয়া এবং ঘরে একাকী বসে থাকা।"
      },
      resultA: {
        en: "Triggers negative self-talk, nutritional weakness, and fatigue.",
        bn: "নেতিবাচক চিন্তাভাবনা বাড়ে, শারীরিক দুর্বলতা ও ক্লান্তি দেখা দেয়।"
      },
      choiceB: {
        en: "Stand tall, tap 'Body Gratitude Affirmation', and state that growth happens naturally.",
        bn: "মাথা উঁচু করে দাঁড়ানো এবং মনে করিয়ে দেওয়া যে সবার শারীরিক বৃদ্ধি নিজস্ব গতিতে ঘটে।"
      },
      resultB: {
        en: "Reframes body image, dismantles teasing, and builds self-esteem.",
        bn: "শরীরের প্রতি ইতিবাচক দৃষ্টিভঙ্গি তৈরি হয় এবং আত্মবিশ্বাস বৃদ্ধি পায়।"
      }
    },
    actionableTakeaways: {
      en: [
        "In-App Body Gratitude Cards: Tap through daily visual cards affirming body functionality (e.g., 'My legs carry me to school; my brain solves problems').",
        "Self-Talk Reframing Tool: Use 'Thought Swap' to convert negative thoughts ('I look awkward') into positive affirmations ('My body is growing naturally').",
        "Peer Support Boundary Checklist: Practice respectful verbal responses to interrupt peer body-shaming."
      ],
      bn: [
        "শারীরিক কৃতজ্ঞতার কার্ড: প্রতিদিন স্মরণ করো তোমার শরীর তোমার জন্য কী কী করছে (যেমন: 'আমার পা আমাকে স্কুলে নিয়ে যায়, আমার মস্তিষ্ক অঙ্ক শেখে')।",
        "ইতিবাচক ভাবনা বদল: 'আমাকে দেখতে অদ্ভুত লাগছে'-র বদলে বলো 'আমার শরীর স্বাভাবিক নিয়মে বেড়ে উঠছে'।",
        "কটূক্তি প্রতিরোধের উপায়: বন্ধুদের কটূক্তিতে শান্ত ও দৃঢ়ভাবে নিজের সীমানা বুঝিয়ে দেওয়ার অভ্যাস করো।"
      ]
    },
    keyTakeaway: {
      en: "Pubertal changes are normal biological transitions. Honor what your body does rather than how it looks.",
      bn: "বয়ঃসন্ধিকালের পরিবর্তনগুলো সম্পূর্ণ স্বাভাবিক জৈবিক প্রক্রিয়া। বাহ্যিক রূপের চেয়ে শরীরের সুস্থতা ও শক্তির কদর করো।"
    }
  },
  {
    id: 3,
    phase: 1,
    phaseTitle: { en: "Self-Awareness & Body Positivity", bn: "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা" },
    category: "self-awareness",
    emoji: "👑",
    title: {
      en: "Cultivating Self-Worth & Dignity Affirmation",
      bn: "আত্মমর্যাদা ও অধিকার সচেতনতা"
    },
    summary: {
      en: "Recognize inherent human worth, fundamental legal rights, and gender equality aligning with UNICEF principles.",
      bn: "মানুষ হিসেবে নিজের অন্তর্নিহিত মূল্য, মৌলিক আইনি অধিকার এবং ইউনিসেফ নির্দেশিত লিঙ্গ সমতা উপলব্ধি করা।"
    },
    content: {
      en: [
        "In 15-year-old Meena's family, household funds are prioritized for her younger brother's private tutoring, while Meena is expected to manage domestic labor after school.",
        "'Why does Rahul get extra tuition while I clean the courtyard?' Meena asked her mother. 'He will earn for his family one day; a girl's main duty is in the household,' her aunt replied.",
        "'That is an unfair gender expectation,' her Sakhi peer mentor, Rekha, pointed out. 'UNICEF principles state that every girl has an equal right to education, health, and personal development. Your future is just as important as your brother's.'",
        "UNICEF's Comprehensive Life Skills Framework emphasizes that true empowerment begins when an adolescent girl recognizes her inherent worth and equal human rights, rejecting internalized gender discrimination."
      ],
      bn: [
        "১৫ বছর বয়সী মীনার পরিবারে তার ছোট ভাইয়ের গৃহশিক্ষকের জন্য টাকা খরচ করা হলেও মীনাকে স্কুল শেষে ঘরের সব কাজ করতে বলা হয়।",
        "'রাহুল যখন বাড়তি টিউশন পড়ে, তখন আমাকে কেন উঠোন ঝাঁট দিতে হবে?' মীনা মাকে জিজ্ঞেস করল। তার খালা বললেন: 'ও তো বড় হয়ে সংসারে আয় করবে, মেয়েদের আসল কাজ তো ঘরের ভেতর।'",
        "পরে সখী মেন্টর রেখা তাকে বলল: 'এটা ভুল লিঙ্গভিত্তিক বৈষম্য। ইউনিসেফের নীতি অনুযায়ী শিক্ষা, স্বাস্থ্য ও বিকাশের অধিকার ছেলে-মেয়ে সবার সমান। তোমার ভবিষ্যৎও তোমার ভাইয়ের মতোই মূল্যবান।'",
        "ইউনিসেফের জীবনশৈলী শিক্ষা নির্দেশিকা অনুযায়ী আসল ক্ষমতায়ন শুরু হয় যখন একজন কিশোরী নিজের অন্তর্নিহিত মর্যাদা ও মানবাধিকার উপলব্ধি করে বৈষম্যকে অস্বীকার করতে শেখে।"
      ]
    },
    branchingScenario: {
      scenario: {
        en: "Family asks Meena to drop out of evening study hours to handle extra domestic chores.",
        bn: "পরিবার মীনাকে সন্ধ্যার পড়া বাদ দিয়ে বাড়তি গৃহস্থালি কাজ করার জন্য চাপ দেয়।"
      },
      choiceA: {
        en: "Silently accept that her education is less important than domestic labor.",
        bn: "চুপচাপ মেনে নেওয়া যে মেয়েদের পড়াশোনার কোনো মূল্য নেই।"
      },
      resultA: {
        en: "Internalizes low dignity, increases school dropout risk.",
        bn: "আত্মমর্যাদা ক্ষুণ্ণ হয় এবং পড়াশোনা বন্ধ হওয়ার ঝুঁকি বেড়ে যায়।"
      },
      choiceB: {
        en: "Use the Sakhi 'Dignity Advocacy Script' to calmly state her right to study hours while offering a shared chore schedule.",
        bn: "সখী অধিকার স্ক্রিপ্ট ব্যবহার করে শান্ত গলায় পড়ার সময়ের অধিকার দাবি করা এবং কাজের যৌথ ভাগাভাগির প্রস্তাব দেওয়া।"
      },
      resultB: {
        en: "Asserts fundamental dignity, protects learning time, and sets healthy boundaries.",
        bn: "মৌলিক মর্যাদা রক্ষা পায় এবং পড়াশোনার সময় নিশ্চিত হয়।"
      }
    },
    actionableTakeaways: {
      en: [
        "Interactive Dignity Checklist: Complete weekly app self-checks: I treat my health, nutrition, and education as equal in value to anyone else's.",
        "Audio-Guided Daily Affirmations: Play 1-minute daily audio clips: 'I am worthy, I am capable, and my education is my fundamental right.'",
        "Ally Network Mapper: Map at least one trusted adult, teacher, or Anganwadi worker inside the app's support directory."
      ],
      bn: [
        "মর্যাদার সাপ্তাহিক তালিকা: নিয়মিত নিজেকে মনে করাও: আমার স্বাস্থ্য, পুষ্টি ও পড়াশোনার অধিকার সবার মতো সমান মূল্যবান।",
        "প্রতিদিনের অডিও বার্তা: 'আমি সক্ষম, আমি মর্যাদাপূর্ণ, এবং শিক্ষা আমার মৌলিক অধিকার।'—এই বার্তা শোনো।",
        "সহায়ক নেটওয়ার্ক: অন্তত একজন শিক্ষক, বড় বোন বা অঙ্গনওয়াড়ি কর্মীকে নিজের বিশ্বস্ত সহায়তাকারী হিসেবে চিহ্নিত করো।"
      ]
    },
    keyTakeaway: {
      en: "True empowerment begins when you recognize your inherent worth and reject gender discrimination. You deserve an equal future.",
      bn: "আসল ক্ষমতায়ন তখনই শুরু হয় যখন তুমি নিজের মর্যাদা চিনে বৈষম্য দূর করতে শেখো। তোমার স্বপ্নও সমান গুরুত্বপূর্ণ।"
    }
  },
  {
    id: 4,
    phase: 2,
    phaseTitle: { en: "Communication, Teamwork & Healthy Boundaries", bn: "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা" },
    category: "communication",
    emoji: "💬",
    title: {
      en: "Expressing Feelings & Effective Speaking",
      bn: "অনুভূতি প্রকাশ ও কার্যকর বক্তব্য"
    },
    summary: {
      en: "Master assertive verbal and non-verbal communication techniques to express thoughts, needs, and desires clearly.",
      bn: "দৃঢ় ও সুস্পষ্ট যোগাযোগের কৌশল আয়ত্ত করে নিজের ভাবনা, প্রয়োজন ও অধিকার নির্ভয়ে প্রকাশ করা।"
    },
    content: {
      en: [
        "15-year-old Radha wishes to join an after-school science club, but hesitates to inform her parents, fearing they will require her to return home immediately for domestic chores.",
        "'If I ask my father, he will just say science is useless for girls,' Radha told her friend. 'How do you plan to ask him?' her friend asked. 'I usually look down and whisper when I'm nervous,' Radha admitted.",
        "'Try standing tall, keeping your voice steady, and explaining how science club helps your school performance,' her friend suggested. 'Assertive speaking shows respect for yourself and your parents.'",
        "UNICEF defines communication as the exchange of information, feelings, and needs. Combining clear verbal expression with steady posture and eye contact enables adolescent girls to advocate for their education and health."
      ],
      bn: [
        "১৫ বছর বয়সী রাধা স্কুলের বিজ্ঞান ক্লাবে যোগ দিতে চায়, কিন্তু বাবাকে বলতে দ্বিধা করে—ভয় হয় বাবা হয়তো রেগে গিয়ে বলবেন মেয়েদের বিজ্ঞান শিখে কী লাভ।",
        "রাধার বন্ধু জিজ্ঞেস করল: 'তুই বাবাকে কীভাবে বলবি ভাবছিস?' রাধা বলল: 'আমি তো ভয় পেয়ে চোখ নিচু করে ফিসফিস করে বলি।'",
        "বন্ধু বোঝাল: 'মাথা সোজা রেখে, শান্ত গলায় চোখে চোখ রেখে বুঝিয়ে বল কীভাবে বিজ্ঞান ক্লাব তোর পরীক্ষার ফল ভালো করবে। স্পষ্ট ও আত্মবিশ্বাসী কথা নিজের এবং বড়দের প্রতিও সম্মান দেখায়।'",
        "যোগাযোগ মানে কেবল কথা বলা নয়, বরং নিজের ভাবনা ও প্রয়োজন স্পষ্টভাবে তুলে ধরা। শান্ত চোখের দৃষ্টি ও দৃঢ় কণ্ঠস্বর মেয়েদের পড়াশোনা ও অধিকার আদায়ে শক্তি জোগায়।"
      ]
    },
    branchingScenario: {
      scenario: {
        en: "Radha speaks to her father about joining the science club.",
        bn: "রাধা তার বাবার সাথে বিজ্ঞান ক্লাবে যোগ দেওয়ার বিষয়ে কথা বলে।"
      },
      choiceA: {
        en: "Whisper passively: 'It doesn't matter, but there is a club...'",
        bn: "অস্পষ্ট গলায় মিনমিন করে বলা: 'তেমন কিছু না, এমনি একটা ক্লাব আছে...'"
      },
      resultA: {
        en: "Request dismissed due to lack of clarity and confidence.",
        bn: "আত্মবিশ্বাসের অভাবে বাবা গুরুত্ব না দিয়ে না বলে দেন।"
      },
      choiceB: {
        en: "Use the 'I-Message Tool': 'I feel passionate about science, and joining this club will help me pass my high school exams.'",
        bn: "'আমি-বার্তা' ব্যবহার করে বলা: 'বিজ্ঞান আমার প্রিয় বিষয়, এবং এই ক্লাবে থাকলে আমার পরীক্ষার ফল অনেক ভালো হবে।'"
      },
      resultB: {
        en: "Demonstrates clear intent, respect, and opens constructive family dialogue.",
        bn: "সুস্পষ্ট যুক্তি ও আগ্রহ দেখে পরিবার আলোচনায় রাজি হয়।"
      }
    },
    actionableTakeaways: {
      en: [
        "In-App 'I-Message' Builder: Practice generating statements: 'I feel [emotion] when [situation], and I would like [desired action].'",
        "Non-Verbal Communication Checklist: Practice the 3-point posture check (upright spine, steady eye contact, calm vocal tone).",
        "Audio Speech Recorder: Record and play back practice requests inside the app to evaluate tone and clarity."
      ],
      bn: [
        "'আমি-বার্তা' অনুশীলন: অন্যদের দোষ না দিয়ে বলো: 'আমার [অনুভূতি] হচ্ছে যখন [পরিস্থিতি], আমি চাই [প্রয়োজনীয় পদক্ষেপ]।'",
        "শারীরিক ভাষার ৩ নিয়ম: সোজা হয়ে দাঁড়াও, শান্ত চোখে তাকাও এবং স্থির কণ্ঠে কথা বলো।",
        "অডিও স্পিচ রেকর্ডার: অ্যাপে নিজের কথা রেকর্ড করে শোনো তোমার গলার আওয়াজ কতটা আত্মবিশ্বাসী শোনায়।"
      ]
    },
    keyTakeaway: {
      en: "Assertive speaking balances clear personal needs with respect for others. Use 'I-messages' to be heard and understood.",
      bn: "দৃঢ় ও স্পষ্ট কথা বলার অর্থ হলো নিজের প্রয়োজন বুঝিয়ে বলা অথচ অপরকে অপমান না করা। শান্ত আত্মবিশ্বাসই সবচেয়ে বড় শক্তি।"
    }
  },
  {
    id: 5,
    phase: 2,
    phaseTitle: { en: "Communication, Teamwork & Healthy Boundaries", bn: "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা" },
    category: "communication",
    emoji: "👂",
    title: {
      en: "Active Listening & Respecting Diversity",
      bn: "মনোযোগ দিয়ে শোনা ও বৈচিত্র্যকে সম্মান"
    },
    summary: {
      en: "Cultivate empathy and active listening to construct inclusive relationships across diverse social backgrounds.",
      bn: "সহমর্মিতা ও গভীর মনোযোগ দিয়ে শোনার অভ্যাস গড়ে তুলে বিভিন্ন জাতি, ধর্ম ও পটভূমির মানুষের সাথে সৌহার্দ্য রক্ষা করা।"
    },
    content: {
      en: [
        "During a community sanitation drive, girls from various hamlets meet to assign tasks. When Salma, a girl from a minority community, offers a suggestion, another member interrupts her.",
        "14-year-old Kavita steps in. 'Wait, let's hear Salma's complete idea before deciding,' Kavita said calmly. 'Why bother? Her hamlet uses a different system anyway,' the other girl replied.",
        "'Listening to everyone gives us better ideas,' Kavita argued. 'Active listening means giving full attention without cutting people off, regardless of where they come from.'",
        "UNICEF guidelines stress empathy and tolerance as foundations for peaceful conflict resolution. Active listening involves giving full focus, withholding immediate judgment, and summarizing perspectives to build inclusive peer networks."
      ],
      bn: [
        "গ্রামের পরিবেশ পরিচ্ছন্নতা অভিযানে বিভিন্ন পাড়া থেকে মেয়েরা দায়িত্ব ভাগ করতে জড়ো হয়েছে। সালমা যখন একটি পরামর্শ দেয়, অন্য একজন তাকে মাঝপথে থামিয়ে দেয়।",
        "১৪ বছর বয়সী কবিতা এগিয়ে এসে বলল: 'থামো, আগে সালমার পুরো কথাটা শেষ করতে দাও।' অপর মেয়েটি বলল: 'ওর পাড়ায় তো নিয়ম আলাদা, শুনে কী হবে?'",
        "কবিতা বলল: 'সবার কথা শুনলে কাজ আরও ভালো হয়। সক্রিয়ভাবে শোনার অর্থ হলো কাউকে মাঝপথে না থামিয়ে মন দিয়ে তার দৃষ্টিভঙ্গি বোঝা। বিচার পরে করা যাবে।'",
        "ইউনিসেফ নির্দেশিকা অনুসারে সহমর্মিতা ও ধৈর্য হলো সামাজিক ঐক্যের ভিত্তি। মন দিয়ে শোনা বিভেদ দূর করে এবং পারস্পরিক সম্মান বাড়ায়।"
      ]
    },
    branchingScenario: {
      scenario: {
        en: "A peer from a different background speaks during a group planning meeting.",
        bn: "একটি পরিকল্পনা সভায় অন্য সামাজিক পটভূমির একজন কিশোরী কথা বলছে।"
      },
      choiceA: {
        en: "Interrupt her to push your own plan forward quickly.",
        bn: "তার কথা থামিয়ে দিয়ে নিজের মত সবার ওপর চাপিয়ে দেওয়া।"
      },
      resultA: {
        en: "Creates group division, mistrust, and excludes diverse ideas.",
        bn: "দলের মধ্যে দূরত্ব বাড়ে এবং ভালো পরামর্শ হাতছাড়া হয়।"
      },
      choiceB: {
        en: "Apply the '3-Step Active Listening Tool' (Focus, Summarize, Validate).",
        bn: "'৩ ধাপের সক্রিয় শোনা' পদ্ধতি ব্যবহার করে মন দিয়ে শোনা ও গুছিয়ে বোঝা।"
      },
      resultB: {
        en: "Builds empathy, strengthens group cohesion, and discovers innovative solutions.",
        bn: "পারস্পরিক আস্থা বাড়ে এবং সবাই মিলে চমৎকার সমাধান খুঁজে পায়।"
      }
    },
    actionableTakeaways: {
      en: [
        "In-App Active Listening Trainer: Practice the 3-step digital process: 1. Focus (no distractions), 2. Reflect ('What I hear you saying is...'), 3. Validate (acknowledge feelings).",
        "Inclusion Assessment Scale: Track monthly check-ins evaluating your interactions with peers from different social backgrounds.",
        "Empathy Scenario Exercises: Complete weekly app-guided role-play modules reflecting on diverse lived experiences."
      ],
      bn: [
        "সক্রিয় শোনার ৩ ধাপ: ১. সম্পূর্ণ মনোযোগ দাও, ২. পুনরাবৃত্তি করো ('তুমি যা বললে তা হলো...'), ৩. অনুভূতিকে সম্মান জানাও।",
        "অন্তর্ভুক্তির মূল্যায়ন: প্রতি মাসে যাচাই করো তুমি বিভিন্ন পটভূমির মানুষের সাথে কতটা আন্তরিক।",
        "সহমর্মিতার গল্প: অন্যের জায়গায় নিজেকে বসিয়ে পরিস্থিতি বোঝার অনুশীলন করো।"
      ]
    },
    keyTakeaway: {
      en: "Active listening requires undivided attention and withholding judgment. Respecting diversity enriches everyone.",
      bn: "মন দিয়ে শোনার অর্থ হলো বিচার না করে বুঝতে চেষ্টা করা। বৈচিত্র্যের প্রতি শ্রদ্ধা সমাজকে একতাবদ্ধ করে।"
    }
  }
];

console.log(`Loaded first ${chapters.length} core chapters into definition template.`);
fs.writeFileSync('src/curriculum_batch1.json', JSON.stringify(chapters, null, 2));
