import fs from 'fs';

const chapters = JSON.parse(fs.readFileSync('src/curriculum_21_chapters.json', 'utf8'));
const quizzes = JSON.parse(fs.readFileSync('src/curriculum_21_quizzes.json', 'utf8'));

const badges = [
  {
    id: "badge_first_chapter",
    title: { en: "First Lesson Completed 🎓", bn: "প্রথম পাঠ সম্পন্ন 🎓" },
    description: { en: "Earned by completing your very first life skills educational module.", bn: "জীবনের প্রথম শিক্ষামূলক অধ্যায় সফলভাবে শেষ করার জন্য অর্জিত!" },
    emoji: "🎓"
  },
  {
    id: "badge_phase1_master",
    title: { en: "Self-Awareness Champ 🌸", bn: "আত্মসচেতনতা চ্যাম্পিয়ন 🌸" },
    description: { en: "Mastered Phase 1: Self-Awareness, Body Positivity & Dignity Affirmation.", bn: "প্রথম পর্যায়: আত্মসচেতনতা ও আত্মমর্যাদা সফলভাবে সমাপ্ত করার জন্য অর্জিত!" },
    emoji: "🌸"
  },
  {
    id: "badge_phase2_master",
    title: { en: "Effective Communicator 💬", bn: "দক্ষ যোগাযোগকারী 💬" },
    description: { en: "Mastered Phase 2: Communication, Teamwork & Personal Boundaries.", bn: "দ্বিতীয় পর্যায়: কার্যকর যোগাযোগ ও সুস্থ সীমানা নির্ধারণের জন্য অর্জিত!" },
    emoji: "💬"
  },
  {
    id: "badge_phase3_master",
    title: { en: "Resilience Ambassador 🌱", bn: "সহনশীলতা দূত 🌱" },
    description: { en: "Mastered Phase 3: Emotion Regulation, Stress Management & Overcoming Adversity.", bn: "তৃতীয় পর্যায়: আবেগ নিয়ন্ত্রণ ও মানসিক চাপ মোকাবিলার জন্য অর্জিত!" },
    emoji: "🌱"
  },
  {
    id: "badge_phase4_master",
    title: { en: "Strategic Decision Maker 🧭", bn: "দূরদর্শী সিদ্ধান্তগ্রাহক 🧭" },
    description: { en: "Mastered Phase 4: Critical Thinking, SMART Goals & Negotiation.", bn: "চতুর্থ পর্যায়: গঠনমূলক চিন্তা ও লক্ষ্য নির্ধারণে পারদর্শিতার জন্য অর্জিত!" },
    emoji: "🧭"
  },
  {
    id: "badge_phase5_master",
    title: { en: "Health & Hygiene Pioneer 🌺", bn: "স্বাস্থ্য ও হাইজিন অগ্রদূত 🌺" },
    description: { en: "Mastered Phase 5: Puberty, Menstrual Hygiene & Anemia Prevention.", bn: "পঞ্চম পর্যায়: বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টির পাঠ সম্পূর্ণ করার জন্য অর্জিত!" },
    emoji: "🌺"
  },
  {
    id: "badge_phase6_master",
    title: { en: "Rights & Safety Guardian ⚖️", bn: "অধিকার ও সুরক্ষা অভিভাবক ⚖️" },
    description: { en: "Mastered Phase 6: Child Rights, Child Marriage Laws, Helplines & Cyber Safety.", bn: "ষষ্ঠ পর্যায়: শিশু অধিকার, বাল্যবিয়ে প্রতিরোধ ও সাইবার সুরক্ষার জন্য অর্জিত!" },
    emoji: "⚖️"
  },
  {
    id: "badge_all_chapters",
    title: { en: "21-Chapter Curriculum Graduate 👑", bn: "২১ অধ্যায়ের পাঠক্রম গ্র্যাজুয়েট 👑" },
    description: { en: "Successfully finished all 21 chapters of the comprehensive Sakhi LSE curriculum!", bn: "সখী ২১ অধ্যায়ের পূর্ণাঙ্গ পাঠক্রমের সবকটি পাঠ সফলভাবে শেষ করেছো!" },
    emoji: "👑"
  },
  {
    id: "badge_quiz_champion_a",
    title: { en: "Quiz Master 🏆", bn: "কুইজ মাস্টার 🏆" },
    description: { en: "Scored 100% on a chapter quiz assessment.", bn: "কুইজে শতভাগ নিখুঁত ফলাফল করার জন্য অর্জিত!" },
    emoji: "🏆"
  },
  {
    id: "badge_screen_pioneer",
    title: { en: "Balanced Digital Learner ⏳", bn: "সচেতন মোবাইল ব্যবহারকারী ⏳" },
    description: { en: "Turned idle phone usage into focused education using the screen tracker.", bn: "মোবাইলে অহেতুক সময় নষ্ট না করে ইতিবাচক শিক্ষায় সময় দেওয়ার জন্য অর্জিত!" },
    emoji: "⏳"
  }
];

const helplines = [
  {
    name: { en: "CHILDLINE (Ministry of Women & Child Dev)", bn: "চাইল্ডলাইন (শিশু সুরক্ষা হেল্পলাইন)" },
    number: "1098",
    description: { en: "24/7 toll-free emergency phone service for children under 18 in distress across India.", bn: "১৮ বছরের কম বয়সী শিশুদের যে কোনো বিপদে ২৪ ঘণ্টা বিনামূল্যে উদ্ধারের জাতীয় নম্বর।" },
    iconName: "Phone"
  },
  {
    name: { en: "Women Helpline (Mission Shakti)", bn: "নারী হেল্পলাইন (মিশন শক্তি)" },
    number: "181",
    description: { en: "24/7 toll-free emergency response for women/girls, linked to One Stop Sakhi Centres & police.", bn: "নির্যাতন ও পারিবারিক সহিংসতার বিরুদ্ধে ২৪ ঘণ্টা বিনামূল্যে সহায়তা ও সখী সেন্টারের সাথে যুক্ত।" },
    iconName: "Heart"
  },
  {
    name: { en: "Emergency Response Support System (ERSS)", bn: "জরুরি সেবা (পুলিশ, দমকল ও অ্যাম্বুলেন্স)" },
    number: "112",
    description: { en: "Single nationwide emergency dispatch for police, fire, or medical ambulance rescue.", bn: "পুলিশ, দমকল এবং অ্যাম্বুলেন্সের জন্য দেশের একীভূত জরুরি হেল্পলাইন নম্বর।" },
    iconName: "AlertTriangle"
  },
  {
    name: { en: "National Commission for Women (NCW)", bn: "জাতীয় মহিলা কমিশন হেল্পলাইন" },
    number: "14490",
    description: { en: "24/7 toll-free psychological & legal counseling staffed by mental health professionals in New Delhi.", bn: "নতুন দিল্লির শীর্ষ মানসিক স্বাস্থ্য প্রতিষ্ঠানের বিশেষজ্ঞদের দ্বারা ২৪ ঘণ্টার মানসিক ও আইনি পরামর্শ।" },
    iconName: "ShieldCheck"
  },
  {
    name: { en: "National Cyber Crime Reporting Portal", bn: "সাইবার অপরাধ সেল ও সুরক্ষা" },
    number: "1930",
    description: { en: "To report internet blackmail, online harassment, photo extortion or scams immediately.", bn: "ইন্টারনেটে ছবি নিয়ে ব্ল্যাকমেইল বা সাইবার হয়রানির বিরুদ্ধে দ্রুত অভিযোগের নম্বর।" },
    iconName: "Lock"
  },
  {
    name: { en: "Tele MANAS (Mental Health Support)", bn: "টেলি মানস (মানসিক স্বাস্থ্য সহায়তা)" },
    number: "14416",
    description: { en: "24/7 comprehensive digital mental health network for stress, depression and emotional crisis.", bn: "তীব্র মানসিক চাপ ও হতাশা দূর করতে সরকারি ২৪ ঘণ্টার মানসিক স্বাস্থ্য পরামর্শ সেবা।" },
    iconName: "Smile"
  }
];

const dailyAffirmations = [
  { en: "I am deserving of respect, education, and safe space, just like every other child.", bn: "অন্যান্য সমস্ত শিশুর মতোই আমিও সম্মান, সুযোগ এবং পড়ালেখার পূর্ণ অধিকার রাখি।" },
  { en: "My body is strong, natural, and developing normally. I take pride in my health.", bn: "আমার শরীর অত্যন্ত শক্তিশালী, স্বাভাবিক এবং সুন্দর। আমি সবসময় আমার পরিচ্ছন্নতার দিকে নজর দেব।" },
  { en: "Assertive speaking conveys my needs clearly with calm respect. My voice matters.", bn: "আমার চেঁচামেচি করার প্রয়োজন নেই। আমার শান্ত ও স্পষ্ট গলার কথাই যথেষ্ট।" },
  { en: "Peer pressure cannot make choices for me. I am the ruler of my own values.", bn: "বন্ধুদের অন্যায় চাপ আমার জীবনে সিদ্ধান্ত নিতে পারে না। আমি আমার নীতির ওপর অটল।" },
  { en: "Education is my fundamental right. My dreams are valid and I will achieve them.", bn: "শিক্ষা আমার জন্মগত অধিকার। আমার দেখা স্বপ্নগুলো সত্যি এবং আমি তা পূরণ করবোই।" },
  { en: "Whenever I feel overwhelmed, I pause and take five deep breaths. I am safe and resilient.", bn: "যখনই আমার ভয় করবে, আমি ৫ বার গভীর শ্বাস নেব। আমি সম্পূর্ণ নিরাপদ এবং সহনশীল।" }
];

const fileContent = `import { Chapter, QuizQuestion, Helpline, Badge } from './types';

export const LIFE_SKILLS_CHAPTERS: Chapter[] = ${JSON.stringify(chapters, null, 2)};

export const QUIZ_QUESTIONS: QuizQuestion[] = ${JSON.stringify(quizzes, null, 2)};

export const BADGES: Badge[] = ${JSON.stringify(badges, null, 2)};

export const HELPLINES: Helpline[] = ${JSON.stringify(helplines, null, 2)};

export const DAILY_AFFIRMATIONS = ${JSON.stringify(dailyAffirmations, null, 2)};
`;

fs.writeFileSync('src/chaptersData.ts', fileContent);
console.log("Successfully updated src/chaptersData.ts with all 21 chapters and 67 quizzes!");

// Also update firestore seed json
const seed = {
  version: "2.0.0",
  curriculum: "21-Chapter LSE Framework (UNICEF & WHO aligned)",
  chapters,
  quiz_questions: quizzes,
  badges,
  helplines,
  daily_affirmations: dailyAffirmations
};

fs.writeFileSync('firestore_shokhi_seed.json', JSON.stringify(seed, null, 2));
console.log("Successfully updated firestore_shokhi_seed.json!");
