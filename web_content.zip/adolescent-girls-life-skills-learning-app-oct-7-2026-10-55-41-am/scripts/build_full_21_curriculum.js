import fs from 'fs';

// All 21 Chapters extracted directly from NotebookLM LSE Curriculum Guide
const ALL_21_CHAPTERS = [
  {
    id: 1,
    phase: 1,
    phaseTitle: { en: "Self-Awareness & Body Positivity", bn: "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা" },
    category: "self-awareness",
    emoji: "🌸",
    title: { en: "Understanding Myself & Building Self-Identity", bn: "নিজেকে জানা ও আত্মপরিচয় গঠন" },
    summary: { en: "Accurately assess personal feelings, interests, values, and strengths to build self-worth and identity.", bn: "নিজের অনুভূতি, আগ্রহ, মূল্যবোধ এবং শক্তিকে চিনে আত্মমর্যাদা ও ইতিবাচক পরিচয় গড়ে তোলা।" },
    content: {
      en: [
        "13-year-old Priya excels at mathematics and loves organizing community games in her village. However, her relatives frequently remind her that girls should remain quiet and focus on domestic chores.",
        "Torn between societal expectations and her own capabilities, Priya attends an Adolescent Circle session. Her mentor Sunita reassures her: 'Self-awareness means looking inside yourself to recognize your true worth, separate from external stereotypes.'",
        "When relatives ask her to stop studying to clean, Priya learns to use her Strengths Journal and plan a balanced schedule.",
        "Self-awareness empowers girls to accept themselves, recognize social barriers as external obstacles, and build a strong identity grounded in personal dignity."
      ],
      bn: [
        "১৩ বছর বয়সী প্রিয়া অঙ্কে খুব ভালো কিন্তু আত্মীয়রা তাকে বলে মেয়েদের বেশি কথা না বলে ঘরের কাজে মন দেওয়া উচিত।",
        "কিশোরী সভায় গিয়ে প্রিয়া জানতে পারে যে আত্মসচেতনতার অর্থ হলো সমাজের বাঁধাধরা নিয়মের বাইরে নিজের আসল যোগ্যতা ও শক্তিকে চেনা।",
        "ঘরের কাজের সাথে নিজের পড়ার সময়সূচি সাজিয়ে সে নিজের শিক্ষার অধিকার রক্ষা করতে শেখে।",
        "আত্মসচেতনতা একজন কিশোরীকে নিজের মূল্য বুঝতে শেখায় এবং আত্মমর্যাদার সাথে নিজের পরিচয় গড়ে তুলতে সহায়তা করে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Relatives tell Priya to put away her math books to clean the kitchen.", bn: "আত্মীয়রা প্রিয়াকে অঙ্কের বই সরিয়ে রান্নাঘরের কাজ করতে বলে।" },
      choiceA: { en: "Hide her books and assume girls shouldn't pursue academics.", bn: "বই লুকিয়ে পড়ালেখা বন্ধ করে দেওয়া।" },
      resultA: { en: "Lowers self-esteem and reinforces external limitations.", bn: "আত্মবিশ্বাস কমে যায় এবং পরাধীনতা বাড়ে।" },
      choiceB: { en: "Open 'My Strengths Journal' and plan a daily schedule balancing study and chores.", bn: "'শক্তির খাতা' খুলে পড়াশোনা ও কাজের সুষম রুটিন করা।" },
      resultB: { en: "Builds internal agency, protects education, and establishes self-identity.", bn: "নিজের অধিকার রক্ষা পায় এবং আত্মবিশ্বাস বাড়ে।" }
    },
    actionableTakeaways: {
      en: [
        "Daily Strength Inventory: Log three specific accomplishments or personal qualities into your strength tracker every evening.",
        "Interactive Emotion Tracker: Use the visual emotion wheel twice daily to name current feelings without self-judgment.",
        "Digital Personal Values Journal: Complete daily 2-minute guided journaling prompts documenting your academic goals."
      ],
      bn: [
        "দৈনিক শক্তির হিসাব: প্রতিদিন সন্ধ্যায় নিজের ৩টি ভালো গুণ বা কাজের হিসাব রাখো।",
        "অনুভূতি চাকা: দিনে দুবার নিজের মনের ভাব সঠিকভাবে চিহ্নিত করো।",
        "ব্যক্তিগত লক্ষ্যের ডায়েরি: প্রতিদিন নিজের পড়ার লক্ষ্যগুলো লিখে রাখো।"
      ]
    },
    keyTakeaway: { en: "Self-awareness is recognizing your true worth separate from stereotypes. Your skills define your future.", bn: "আত্মসচেতনতা হলো সমাজের বাধানিষেধের বাইরে গিয়ে নিজের আসল মূল্য বোঝা।" }
  },
  {
    id: 2,
    phase: 1,
    phaseTitle: { en: "Self-Awareness & Body Positivity", bn: "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা" },
    category: "self-awareness",
    emoji: "🌟",
    title: { en: "Embracing Strengths & Body Positivity", bn: "নিজের শক্তিকে গ্রহণ ও শারীরিক ইতিবাচকতা" },
    summary: { en: "Develop positive self-esteem, counter body-shaming, and affirm physical and mental growth during puberty.", bn: "আত্মমর্যাদা বাড়ানো, শারীরিক কটূক্তি প্রতিরোধ করা এবং বয়ঃসন্ধিকালের বৃদ্ধি স্বাভাবিকভাবে গ্রহণ করা।" },
    content: {
      en: [
        "14-year-old Sunita has grown taller than her classmates and slouches to hide her height after peers tease her.",
        "Her teacher reminds her: 'Your growth spurt is a sign that your body is developing normally. Your body works hard to grow strong—honor it, do not hide it.'",
        "WHO health guidelines confirm adolescence is a biological transition. Body positivity means focusing on health and functionality rather than unrealistic media beauty standards.",
        "Learning to celebrate individual growth protects mental health and builds lifelong self-confidence."
      ],
      bn: [
        "১৪ বছর বয়সী সুনীতা বন্ধুদের চেয়ে লম্বা হয়ে যাওয়ায় লজ্জা পেয়ে ঝুঁকে হাঁটত।",
        "শিক্ষিকা তাকে বোঝালেন যে শরীরের বৃদ্ধি সম্পূর্ণ স্বাভাবিক এবং শক্তিশালী হওয়ার লক্ষণ। একে লুকানোর কিছু নেই।",
        "বিশ্ব স্বাস্থ্য সংস্থা অনুযায়ী বয়ঃসন্ধিকালে শারীরিক পরিবর্তন স্বাভাবিক নিয়মে ঘটে। বাহ্যিক চেহারার চেয়ে সুস্থতা বেশি গুরুত্বপূর্ণ।",
        "নিজের শরীরকে ভালোবাসা ও শ্রদ্ধা করা আত্মবিশ্বাসের মূল ভিত্তি।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Classmates tease Sunita about her height during lunch recess.", bn: "সহপাঠীরা সুনীতার উচ্চতা নিয়ে ঠাট্টা করে।" },
      choiceA: { en: "Slouch, avoid eating lunch, and stay indoors.", bn: "কুঁজো হয়ে থাকা ও খাবার না খাওয়া।" },
      resultA: { en: "Triggers negative self-talk, nutritional weakness, and fatigue.", bn: "মন খারাপ ও শারীরিক দুর্বলতা দেখা দেয়।" },
      choiceB: { en: "Stand tall, tap 'Body Gratitude Affirmation', and state that growth happens naturally.", bn: "সোজা হয়ে দাঁড়িয়ে স্বাভাবিক বৃদ্ধিকে স্বাগত জানানো।" },
      resultB: { en: "Reframes body image, stops teasing, and builds self-esteem.", bn: "শারীরিক ইতিবাচকতা তৈরি হয় এবং আত্মবিশ্বাস বাড়ে।" }
    },
    actionableTakeaways: {
      en: [
        "In-App Body Gratitude Cards: Affirm what your body does (e.g., 'My legs carry me to school; my brain solves problems').",
        "Self-Talk Reframing: Convert negative thoughts ('I look awkward') into positive affirmations ('My body is growing naturally').",
        "Peer Support Boundary Checklist: Practice respectful verbal responses to interrupt peer body-shaming."
      ],
      bn: [
        "শারীরিক কৃতজ্ঞতার কার্ড: শরীর তোমার জন্য কী করছে তা প্রতিদিন স্মরণ করো।",
        "ইতিবাচক ভাবনা বদল: নেতিবাচক চিন্তার জায়গায় নিজের বৃদ্ধির প্রশংসা করো।",
        "কটূক্তি মোকাবিলার উপায়: বন্ধুদের ঠাট্টায় শান্ত ও দৃঢ় গলায় উত্তর দাও।"
      ]
    },
    keyTakeaway: { en: "Pubertal changes are normal biological transitions. Honor what your body does rather than how it looks.", bn: "শারীরিক পরিবর্তন সম্পূর্ণ স্বাভাবিক। বাহ্যিক রূপের চেয়ে নিজের সুস্থতাকে বড় করে দেখো।" }
  },
  {
    id: 3,
    phase: 1,
    phaseTitle: { en: "Self-Awareness & Body Positivity", bn: "আত্মসচেতনতা ও শারীরিক ইতিবাচকতা" },
    category: "self-awareness",
    emoji: "👑",
    title: { en: "Cultivating Self-Worth & Dignity Affirmation", bn: "আত্মমর্যাদা ও অধিকার সচেতনতা" },
    summary: { en: "Recognize inherent human worth, fundamental legal rights, and gender equality aligning with UNICEF principles.", bn: "মানুষ হিসেবে নিজের অন্তর্নিহিত মূল্য, মৌলিক আইনি অধিকার এবং লিঙ্গ সমতা উপলব্ধি করা।" },
    content: {
      en: [
        "In 15-year-old Meena's family, household funds are prioritized for her brother's tutoring while Meena does domestic labor.",
        "Her Sakhi mentor Rekha points out: 'UNICEF principles state that every girl has an equal right to education, health, and personal development.'",
        "True empowerment begins when a girl recognizes her inherent worth and rejects internalized gender discrimination.",
        "Standing up for educational equality creates opportunities not just for oneself, but for the entire community."
      ],
      bn: [
        "১৫ বছর বয়সী মীনার পরিবারে ভাইয়ের পড়ালেখায় টাকা খরচ করা হলেও মীনাকে ঘরের কাজে আটকে রাখা হতো।",
        "সখী মেন্টর রেখা তাকে শেখায় যে শিক্ষা ও স্বাস্থ্যের অধিকার ছেলে ও মেয়ে উভয়ের সমান।",
        "মেয়েদের ক্ষমতায়ন তখনই শুরু হয় যখন তারা নিজেদের অধিকার চিনতে পারে এবং বৈষম্য দূর করতে কথা বলে।",
        "নিজের মর্যাদা জানা একটি সুন্দর ও স্বাধীন ভবিষ্যৎ গড়ে তোলে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Family asks Meena to drop evening study hours to do extra chores.", bn: "পরিবার মীনাকে পড়াশোনা বাদ দিয়ে বাড়তি কাজ করতে বলে।" },
      choiceA: { en: "Silently accept that her education is less important than domestic labor.", bn: "চুপচাপ মেনে নেওয়া যে পড়াশোনা জরুরি নয়।" },
      resultA: { en: "Internalizes low self-worth, increases dropout risk.", bn: "হতাশা বাড়ে এবং পড়াশোনা বন্ধের ঝুঁকি তৈরি হয়।" },
      choiceB: { en: "Use the 'Dignity Advocacy Script' to calmly claim study hours with a shared chore schedule.", bn: "শান্ত গলায় পড়ার অধিকার দাবি করা এবং কাজ ভাগ করে নেওয়ার প্রস্তাব দেওয়া।" },
      resultB: { en: "Asserts fundamental dignity and protects educational continuity.", bn: "মর্যাদা রক্ষা পায় এবং পড়াশোনার সময় নিশ্চিত হয়।" }
    },
    actionableTakeaways: {
      en: [
        "Interactive Dignity Checklist: Complete weekly app self-checks affirming equal rights to nutrition and education.",
        "Daily Affirmations: Listen to audio clips: 'I am worthy, I am capable, and my education is my fundamental right.'",
        "Ally Network Mapper: Identify trusted teachers or Anganwadi workers to assist when educational rights are overlooked."
      ],
      bn: [
        "মর্যাদার তালিকা: নিজের পুষ্টি ও পড়ার অধিকারের নিশ্চয়তা যাচাই করো।",
        "দৈনিক অডিও বার্তা: 'আমি সক্ষম এবং শিক্ষা আমার মৌলিক অধিকার'—অনুশীলন করো।",
        "সহায়তাকারীদের তালিকা: কোনো বাধার মুখে শিক্ষক বা সচেতন বড়দের পাশে নাও।"
      ]
    },
    keyTakeaway: { en: "True empowerment begins with knowing your inherent worth. Every girl has an equal right to an education.", bn: "আসল শক্তি আসে নিজের মর্যাদা চেনার মাধ্যমে। শিক্ষার অধিকার সবার সমান।" }
  },
  {
    id: 4,
    phase: 2,
    phaseTitle: { en: "Communication, Teamwork & Healthy Boundaries", bn: "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা" },
    category: "communication",
    emoji: "💬",
    title: { en: "Expressing Feelings & Effective Speaking", bn: "অনুভূতি প্রকাশ ও কার্যকর বক্তব্য" },
    summary: { en: "Master assertive verbal and non-verbal communication techniques to express thoughts, needs, and opinions clearly.", bn: "দৃঢ় ও সুস্পষ্ট যোগাযোগের কৌশল আয়ত্ত করে নিজের ভাবনা ও অধিকার নির্ভয়ে প্রকাশ করা।" },
    content: {
      en: [
        "15-year-old Radha wants to join an after-school science club but is afraid her father will refuse if she speaks passively.",
        "Her friend teaches her assertive posture: standing upright, maintaining steady eye contact, and using clear 'I-messages'.",
        "UNICEF defines communication as exchanging information, feelings, and needs with mutual respect.",
        "Assertive communication differs from aggression because it respects both personal rights and the listener's dignity."
      ],
      bn: [
        "১৫ বছর বয়সী রাধা বিজ্ঞান ক্লাবে যেতে চায় কিন্তু ভয়ে বাবাকে স্পষ্ট করে বলতে পারছিল না।",
        "তার বন্ধু তাকে সোজা হয়ে দাঁড়িয়ে, চোখে চোখ রেখে 'আমি-বার্তা' দিয়ে কথা বলতে শেখায়।",
        "যোগাযোগ মানে সম্মান বজায় রেখে নিজের প্রয়োজন ও অনুভূতি খোলাখুলি প্রকাশ করা।",
        "দৃঢ় বক্তব্য আক্রমণাত্মক না হয়েও নিজের মত প্রতিষ্ঠা করতে পারে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Radha speaks to her father about joining the science club.", bn: "রাধা বাবার কাছে বিজ্ঞান ক্লাবে যোগ দেওয়ার ইচ্ছা জানায়।" },
      choiceA: { en: "Whisper passively: 'It doesn't matter, but there is a club...'", bn: "মিনমিন করে অস্পষ্টভাবে বলা।" },
      resultA: { en: "Request dismissed due to lack of clarity and confidence.", bn: "আত্মবিশ্বাসের অভাবে বাবা গুরুত্ব দেন না।" },
      choiceB: { en: "Use 'I-Message Tool': 'I feel passionate about science, and joining will help my high school exams.'", bn: "'আমি-বার্তা' দিয়ে স্পষ্ট যুক্তি তুলে ধরা।" },
      resultB: { en: "Demonstrates clear purpose, opening constructive dialogue.", bn: "বাবা রাজি হন এবং পড়ার পথ খোলে।" }
    },
    actionableTakeaways: {
      en: [
        "In-App 'I-Message' Builder: Practice: 'I feel [emotion] when [situation], and I would like [desired action].'",
        "Non-Verbal Checklist: Upright posture, steady eye contact, and calm vocal tone.",
        "Audio Speech Recorder: Record and play back practice requests inside the app to test clarity."
      ],
      bn: [
        "'আমি-বার্তা' চর্চা: নিজের অনুভূতি ও প্রয়োজন শান্তভাবে প্রকাশ করো।",
        "শারীরিক অঙ্গভঙ্গি: সোজা দাঁড়াও এবং শান্ত দৃষ্টিতে তাকাও।",
        "রেকর্ড করে শোনা: নিজের কণ্ঠ কতটা আত্মবিশ্বাসী তা অ্যাপে রেকর্ড করে শোনো।"
      ]
    },
    keyTakeaway: { en: "Assertive speaking conveys personal needs with calm respect. Use 'I-messages' to be heard clearly.", bn: "শান্ত অথচ স্পষ্ট কথা নিজের আত্মসম্মান বাড়ায় এবং অপরকে সম্মান দেয়।" }
  },
  {
    id: 5,
    phase: 2,
    phaseTitle: { en: "Communication, Teamwork & Healthy Boundaries", bn: "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা" },
    category: "communication",
    emoji: "👂",
    title: { en: "Active Listening & Respecting Diversity", bn: "মনোযোগ দিয়ে শোনা ও বৈচিত্র্যকে সম্মান" },
    summary: { en: "Cultivate empathy and active listening to construct inclusive relationships across diverse backgrounds.", bn: "সহমর্মিতা ও গভীর মনোযোগ দিয়ে শোনার অভ্যাস গড়ে তুলে সৌহার্দ্য রক্ষা করা।" },
    content: {
      en: [
        "During a community project, Salma from a minority hamlet is interrupted, but 14-year-old Kavita steps in to ensure Salma is heard completely.",
        "Active listening involves giving undivided focus, withholding immediate judgment, and validating perspectives.",
        "UNICEF emphasizes empathy and tolerance as foundations for peaceful coexistence and strong friendships.",
        "Respecting diverse backgrounds enriches discussions and helps communities solve problems collectively."
      ],
      bn: [
        "একটি সামাজিক কাজে সালমার কথা মাঝপথে থামিয়ে দেওয়া হলে কবিতা সবার সামনে সালমার সম্পূর্ণ বক্তব্য শুনতে অনুরোধ করে।",
        "মন দিয়ে শোনার অর্থ হলো কাউকে বিচার না করে পুরো মনোযোগ দিয়ে তার কথা বোঝা।",
        "সহমর্মিতা বিভিন্ন পটভূমির মানুষের মধ্যে সেতু তৈরি করে।",
        "সবার মতামত শুনলে দল আরও শক্তিশালী হয় এবং নতুন সমাধান মেলে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "A peer from a different background speaks during a group meeting.", bn: "দলের বৈঠকে ভিন্ন পাড়ার একজন বন্ধু পরামর্শ দিচ্ছে।" },
      choiceA: { en: "Interrupt her to push your own plan forward.", bn: "তাকে থামিয়ে দিয়ে নিজের মত চাপিয়ে দেওয়া।" },
      resultA: { en: "Creates group division and excludes diverse ideas.", bn: "দলে বিভেদ সৃষ্টি হয় এবং ভালো আইডিয়া বাদ পড়ে।" },
      choiceB: { en: "Apply the '3-Step Active Listening Tool' (Focus, Summarize, Validate).", bn: "'মনোযোগ, সারসংক্ষেপ ও স্বীকৃতি' নীতি প্রয়োগ করা।" },
      resultB: { en: "Builds empathy, strengthens group cohesion, and discovers better plans.", bn: "বন্ধুত্ব বাড়ে এবং সেরা পরিকল্পনা তৈরি হয়।" }
    },
    actionableTakeaways: {
      en: [
        "Active Listening 3-Step: 1. Focus, 2. Reflect ('What I hear you saying is...'), 3. Validate feelings.",
        "Inclusion Assessment Scale: Evaluate your interactions with peers from different communities.",
        "Empathy Role-Play: Complete scenarios reflecting on diverse lived experiences."
      ],
      bn: [
        "সক্রিয় শোনার ৩ ধাপ: পুরো মন দাও, গুছিয়ে পুনরাবৃত্তি করো এবং অনুভূতিকে সম্মান দাও।",
        "অন্তর্ভুক্তির অভ্যাস: সব মানুষের সাথে সমান আন্তরিক থাকার চেষ্টা করো।",
        "সহমর্মিতার গল্প: অন্যের স্থানে নিজেকে বসিয়ে ভাবো।"
      ]
    },
    keyTakeaway: { en: "Active listening requires undivided attention. Respecting diversity enriches everyone's understanding.", bn: "মন দিয়ে শোনার অর্থ হলো সম্মান জানানো। বৈচিত্র্য সমাজকে সুন্দর করে।" }
  },
  {
    id: 6,
    phase: 2,
    phaseTitle: { en: "Communication, Teamwork & Healthy Boundaries", bn: "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা" },
    category: "communication",
    emoji: "🤝",
    title: { en: "Teamwork & Group Dynamics", bn: "দলগত কাজ ও যৌথ নেতৃত্ব" },
    summary: { en: "Develop collaborative competencies to participate effectively in Adolescent Circles, committees, and teams.", bn: "কিশোরী সভা, কমিটি ও সামাজিক কার্যক্রমে যৌথভাবে কাজ করার নেতৃত্ব দক্ষতা বৃদ্ধি।" },
    content: {
      en: [
        "When an Adolescent Circle gathers to solve mosquito breeding around a village tap, competing demands cause chaos.",
        "15-year-old Meera assigns distinct roles: Contributor (gathers facts), Supporter (encourages members), and Mediator (resolves disagreements).",
        "Working as a team converts isolated individual struggles into collective community advocacy.",
        "Clear ground rules, fair task distribution, and mutual respect produce impactful community results."
      ],
      bn: [
        "গ্রামের পানীয় জলের জায়গায় মশা বংশবৃদ্ধি রোধ করতে গিয়ে শুরুতে সবাই একসাথে চিৎকার করছিল।",
        "১৫ বছর বয়সী মীনা দায়িত্ব ভাগ করে দিল: তথ্য সংগ্রহকারী, দল সমর্থক ও মধ্যস্থতাকারী।",
        "একতাবদ্ধ দলগত প্রচেষ্টা যে কোনো বড় সমস্যা সমাধানে বড় শক্তি এনে দেয়।",
        "পরস্পরকে সম্মান দিয়ে কাজ করলে পুরো গ্রামের উন্নতি সম্ভব।"
      ]
    },
    branchingScenario: {
      scenario: { en: "The Adolescent Circle must present a clean water petition to village elders.", bn: "কিশোরী দলটিকে পঞ্চায়েতের কাছে পরিষ্কার জলের আবেদন করতে হবে।" },
      choiceA: { en: "Let one person do everything alone without telling the group.", bn: "সব কাজ একজনকে একা করতে দেওয়া।" },
      resultA: { en: "Task overload, stress, and uncompleted petition.", bn: "ক্লান্তি বাড়ে এবং আবেদন জমা পড়ে না।" },
      choiceB: { en: "Assign team roles using the Sakhi Task Allocation Tool.", bn: "দলে কাজের দায়িত্ব সমানভাবে বণ্টন করা।" },
      resultB: { en: "Organized advocacy leading to successful community action.", bn: "সফলভাবে আবেদন মঞ্জুর হয় এবং সমস্যার সমাধান হয়।" }
    },
    actionableTakeaways: {
      en: [
        "Team Role Selector: Assign structured roles (Contributor, Supporter, Mediator).",
        "Group Ground Rules: Establish equal airtime and zero put-downs before meetings.",
        "Collaborative Goal Tracker: Monitor progress on joint tasks using the shared checklist."
      ],
      bn: [
        "ভূমিকা নির্বাচন: দলে কাজের দায়িত্ব নির্দিষ্ট করে দাও।",
        "দলের নিয়ম: সবাইকে কথা বলার সুযোগ দাও এবং কাউকে ছোট করো না।",
        "যৌথ কাজের তালিকা: সবাই মিলে অগ্রগতি পরীক্ষা করো।"
      ]
    },
    keyTakeaway: { en: "Teamwork pools diverse strengths. Structured roles turn individual efforts into collective power.", bn: "একতায় বল। দায়িত্ব ভাগ করে কাজ করলে অসম্ভবও সম্ভব হয়।" }
  },
  {
    id: 7,
    phase: 2,
    phaseTitle: { en: "Communication, Teamwork & Healthy Boundaries", bn: "যোগাযোগ, দলগত কাজ ও সুস্থ সীমানা" },
    category: "communication",
    emoji: "🛡️",
    title: { en: "Setting Healthy Personal Boundaries", bn: "সুস্থ ব্যক্তিগত সীমানা নির্ধারণ" },
    summary: { en: "Identify personal boundaries and assertively protect physical, emotional, and digital personal space.", bn: "ব্যক্তিগত সীমানা চেনা এবং নিজের শরীর ও মানসিক শান্তি দৃঢ়ভাবে রক্ষা করা।" },
    content: {
      en: [
        "An older acquaintance sits uncomfortably close to 13-year-old Geeta on the bus and reaches for her notebook.",
        "Geeta feels sick with anxiety. Her mentor clarifies: 'Discomfort is your body's signal that a boundary is crossed. Protecting your safety is never disrespectful.'",
        "Setting boundaries means stating clearly what is acceptable and what must stop immediately.",
        "Adolescent girls possess full entitlement to bodily autonomy and emotional safety without guilt or apology."
      ],
      bn: [
        "বাসে একজন পরিচিত ব্যক্তি ১৩ বছর বয়সী গীতার খুব কাছাকাছি বসে তার নোটবুক নেওয়ার চেষ্টা করায় গীতা ভয় পেয়ে যায়।",
        "মেন্টর গীতাকে বোঝান: 'ভয় বা অস্বস্তি লাগা মানে তোমার ব্যক্তিগত সীমানা লঙ্ঘন হচ্ছে। নিজের সুরক্ষা রক্ষা করা কখনো বেয়াদবি নয়।'",
        "সীমানা নির্ধারণের অর্থ হলো কোনটি গ্রহণযোগ্য আর কোনটি বন্ধ করতে হবে তা স্পষ্ট করে বলা।",
        "নিজের শরীর ও ব্যক্তিগত জায়গার ওপর সম্পূর্ণ অধিকার একমাত্র তোমার নিজের।"
      ]
    },
    branchingScenario: {
      scenario: { en: "The acquaintance sits uncomfortably close and reaches for Geeta's notebook.", bn: "ব্যক্তিটি গীতার গা ঘেঁষে বসে তার ডায়েরি টানার চেষ্টা করে।" },
      choiceA: { en: "Move away quietly, stay silent, and blame yourself.", bn: "চুপচাপ সরে গিয়ে নিজেকে দোষ দেওয়া।" },
      resultA: { en: "Boundary violation continues unchecked and increases fear.", bn: "অসদাচরণ বাড়তেই থাকে এবং ভয় বৃদ্ধি পায়।" },
      choiceB: { en: "Execute the 3-Step Refusal Script: 'I am uncomfortable. This is my private space. Please move.'", bn: "দৃঢ় গলায় বলা: 'আমার অস্বস্তি হচ্ছে। এটা আমার ব্যক্তিগত জায়গা। দয়া করে সরে বসুন।'" },
      resultB: { en: "Asserts clear boundaries and deters further intrusion.", bn: "ব্যক্তিটি সরে যায় এবং নিজের নিরাপত্তা বজায় থাকে।" }
    },
    actionableTakeaways: {
      en: [
        "3-Step Refusal Script: 1. State the Boundary ('I am uncomfortable'), 2. State Reason ('This is private'), 3. Direct Action ('Step back').",
        "Body Warning Cues Tracker: Log physical discomfort cues (tight chest, butterfly feeling) to act early.",
        "Escalation Support Mapper: Save contacts to alert trusted adults if boundaries are breached."
      ],
      bn: [
        "৩ ধাপের না বলা: ১. অস্বস্তি প্রকাশ করো, ২. কারণ বলো, ৩. পরিষ্কার নির্দেশ দাও সরে যাওয়ার।",
        "শরীরের সংকেত: ভয় পেলে বা অস্বস্তি লাগলে সাথে সাথে সতর্ক হও।",
        "জরুরি নম্বর: কোনো সমস্যা হলে নির্ভরযোগ্য বড়দের ফোন করো।"
      ]
    },
    keyTakeaway: { en: "Your personal space belongs to you. Saying 'No' to discomfort is a healthy exercise of your rights.", bn: "তোমার শরীর তোমার নিজস্ব। অস্বস্তিকর পরিস্থিতিতে 'না' বলার পূর্ণ অধিকার তোমার আছে।" }
  },
  {
    id: 8,
    phase: 3,
    phaseTitle: { en: "Emotion Regulation, Stress & Resilience", bn: "আবেগ নিয়ন্ত্রণ, মানসিক চাপ ও সহনশীলতা" },
    category: "resilience",
    emoji: "🧘",
    title: { en: "Managing Emotions & Feelings", bn: "অনুভূতি ও তীব্র আবেগ নিয়ন্ত্রণ" },
    summary: { en: "Identify and regulate intense emotions, preventing destructive outlets such as lashing out or self-isolation.", bn: "তীব্র রাগ বা দুঃখ নিয়ন্ত্রণ করে নিজেকে আঘাত করা বা অন্যদের ওপর ক্ষোভ ঝাড়ার ক্ষতি থেকে রক্ষা পাওয়া।" },
    content: {
      en: [
        "14-year-old Reena scores poorly on an exam and has an immediate impulse to smash her desk lamp and scream at her sister.",
        "Her older sister calms her: 'Freeze. Take two slow breaths. Disappointment is natural, but throwing things hurts our family. Pause, name the emotion, and choose a safe outlet.'",
        "WHO mental health guidelines note that rapid adolescent growth frequently intensifies emotional reactions.",
        "Practicing the 4-step sequence (Pause, Breathe, Name, Choose) builds lasting emotional mastery."
      ],
      bn: [
        "১৪ বছর বয়সী রীনা পরীক্ষায় খারাপ করায় টেবিলের ল্যাম্প ভেঙে বোনকে মারতে উদ্যত হলো।",
        "তার বড় বোন হাত ধরে বলল: 'থামো, দুইবার গভীর শ্বাস নাও। খারাপ লাগা স্বাভাবিক, কিন্তু ভাঙচুর সমাধান নয়। আগে রাগটা শান্ত করো।'",
        "বয়ঃসন্ধিকালে হরমোনের পরিবর্তনের কারণে তীব্র আবেগ আসা স্বাভাবিক।",
        "থামা, শ্বাস নেওয়া, অনুভূতি চেনা এবং সঠিক কাজ বেছে নেওয়া—এই ৪টি ধাপ মনকে শান্ত রাখে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Reena feels overwhelming rage over low exam results.", bn: "পরীক্ষার ফলে রীনা প্রচণ্ড রাগে ফেটে পড়ে।" },
      choiceA: { en: "Throw books, yell at her sister, and lock herself in a room.", bn: "বইপত্র ছুড়ে ফেলা এবং ঘরে নিজেকে বন্দি করা।" },
      resultA: { en: "Escalates family conflict and damages self-esteem.", bn: "পারিবারিক অশান্তি বাড়ে এবং মন খারাপ দীর্ঘস্থায়ী হয়।" },
      choiceB: { en: "Open the '4-Step Calming Tool' (Pause, Breathe, Name, Choose).", bn: "'৪ ধাপের শান্ত হওয়া' পদ্ধতি প্রয়োগ করে গভীর শ্বাস নেওয়া।" },
      resultB: { en: "Lowers heart rate and enables constructive reflection.", bn: "হৃৎস্পন্দন শান্ত হয় এবং পুনরায় পড়ার উদ্যম মেলে।" }
    },
    actionableTakeaways: {
      en: [
        "4-Step Calming Tool: Pause movement, Take 4-7-8 breaths, Name the feeling, Choose a constructive outlet.",
        "Personal Trigger Journal: Document recurring frustration triggers (academic pressure, noise).",
        "Constructive Outlets: Use brisk walking, drawing, or journaling when emotions rise."
      ],
      bn: [
        "শান্ত হওয়ার ৪ ধাপ: নড়াচড়া থামাও, গভীর শ্বাস নাও, অনুভূতিকে নাম দাও, এবং নিরাপদ কাজ বেছে নাও।",
        "রাগের কারণ লেখা: কোন কথায় তোমার রাগ হয় তা লিখে রাখো।",
        "ইতিবাচক উপায়: রাগ হলে একটু হেঁটে এসো, ছবি আঁকো বা জল খাও।"
      ]
    },
    keyTakeaway: { en: "Pausing creates space between an emotional impulse and constructive action. Control your reactions.", bn: "রাগ ওঠা স্বাভাবিক, কিন্তু তা প্রকাশ করার ইতিবাচক পথ বেছে নেওয়াই আসল বুদ্ধি।" }
  },
  {
    id: 9,
    phase: 3,
    phaseTitle: { en: "Emotion Regulation, Stress & Resilience", bn: "আবেগ নিয়ন্ত্রণ, মানসিক চাপ ও সহনশীলতা" },
    category: "resilience",
    emoji: "⏳",
    title: { en: "Coping with Stress & Everyday Challenges", bn: "মানসিক চাপ ও দৈনন্দিন চ্যালেঞ্জ মোকাবেলা" },
    summary: { en: "Develop practical coping strategies to navigate academic pressure, family duties, and social expectations.", bn: "পড়ালেখার চাপ, সংসারের কাজ এবং সামাজিক প্রত্যাশার মধ্যে সুষম ভারসাম্য তৈরি করা।" },
    content: {
      en: [
        "16-year-old Anita feels crushed trying to wake up at 4 AM for chores, attend school, and study until midnight.",
        "She contemplates dropping out. Her Sakhi leader cautions: 'Dropping out is a permanent reaction to temporary pressure. Break your schedule into smaller blocks and ask family to share chores.'",
        "UNICEF life skills frameworks contrast positive coping (time management, support-seeking) with negative coping (dropping out, isolation).",
        "Segmenting tasks and asking for support are signs of strength that preserve educational progress."
      ],
      bn: [
        "১৬ বছর বয়সী অনিতা ভোর ৪টায় উঠে ঘরের কাজ, তারপর স্কুল এবং রাতে পড়ার চাপে স্কুল ছেড়ে দেওয়ার কথা ভাবে।",
        "তার সখী লিডার বোঝাল: 'সাময়িক চাপের কারণে স্থায়ী ভুল সিদ্ধান্ত নিয়ো না। পড়ার সময় ভাগ করো এবং পরিবারের সাথে কাজ ভাগ করে নাও।'",
        "সঠিক পরিকল্পনা ও সাহায্য চাওয়া হলো ইতিবাচকভাবে চাপ সামলানোর সেরা উপায়।",
        "পড়াশোনা ছোট ছোট ধাপে ভাগ করলে মানসিক চাপ কমে যায়।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Anita feels overwhelmed by chores and exam prep.", bn: "অনিতা পড়াশোনা ও ঘরের কাজের চাপে দিশেহারা হয়ে পড়ে।" },
      choiceA: { en: "Stop attending school and isolate at home.", bn: "স্কুল যাওয়া বন্ধ করে ঘরে একা বসে থাকা।" },
      resultA: { en: "Permanent educational loss and increased vulnerability.", bn: "পড়াশোনার ক্ষতি হয় এবং ভবিষ্যৎ অনিশ্চিত হয়ে পড়ে।" },
      choiceB: { en: "Use Daily Routine Planner to study in 30-minute blocks and ask siblings to share chores.", bn: "৩০ মিনিটের পড়ার রুটিন তৈরি করা এবং ভাইবোনদের কাজে হাত লাগাতে বলা।" },
      resultB: { en: "Reduces anxiety, restores sleep, and preserves academic progress.", bn: "উদ্বেগ কমে, পর্যাপ্ত ঘুম হয় এবং পড়াশোনা সুন্দরভাবে চলে।" }
    },
    actionableTakeaways: {
      en: [
        "Time Structuring Grid: Allocate dedicated blocks for study, chores, rest, and sleep.",
        "Task Breakdown Checklist: Divide large academic topics into 15-minute manageable tasks.",
        "Peer Support Hub: Connect with peers to share stress-management tips."
      ],
      bn: [
        "সময়সূচির তালিকা: পড়া, কাজ ও বিশ্রামের জন্য আলাদা সময় রাখো।",
        "ছোট ছোট ভাগে পড়া: বড় অধ্যায়কে ১৫ মিনিটের ছোট অংশে ভাগ করে পড়ো।",
        "বন্ধুদের সাথে আলোচনা: মানসিক চাপ হলে বন্ধুদের সাথে ভাগ করে নাও।"
      ]
    },
    keyTakeaway: { en: "Positive coping breaks big pressures into structured daily steps. Never sacrifice your education for temporary stress.", bn: "সাময়িক চাপের কাছে হার মানবে না। কাজের সঠিক রুটিন ও বিশ্রামই সাফল্যের চাবিকাঠি।" }
  },
  {
    id: 10,
    phase: 3,
    phaseTitle: { en: "Emotion Regulation, Stress & Resilience", bn: "আবেগ নিয়ন্ত্রণ, মানসিক চাপ ও সহনশীলতা" },
    category: "resilience",
    emoji: "🌱",
    title: { en: "Building Resilience & Overcoming Adversity", bn: "সহনশীলতা ও প্রতিকূলতা জয়" },
    summary: { en: "Strengthen resilience to recover from adversity, calamity, or disruption and return to a stable state of agency.", bn: "দুর্যোগ ও কঠিন পরিস্থিতিতে মানসিক শক্তি বজায় রেখে ঘুরে দাঁড়ানোর ক্ষমতা অর্জন।" },
    content: {
      en: [
        "15-year-old Pooja's family loses their roadside shop during a seasonal flood and relocates to a temporary shelter.",
        "Pooja weeps that her future is ruined. Her mentor reminds her: 'The flood destroyed the shop, but not your intelligence. Resilience means taking small daily steps to rebuild.'",
        "UNICEF India defines resilience as the psychosocial capacity to recover from calamity and regain stability through perseverance and community connection.",
        "Focusing on what you can control rather than what you lost restores hope and momentum."
      ],
      bn: [
        "বন্যায় পূজা ও তার পরিবারের ছোট্ট দোকানটি ভেসে যাওয়ায় তারা আশ্রয়কেন্দ্রে আশ্রয় নেয়। পূজা কাঁদতে থাকে যে তার পড়াশোনা শেষ।",
        "তার মেন্টর বলে: 'বন্যা দোকান ভাসিয়ে নিয়েছে, কিন্তু তোমার মেধা ও স্বপ্নকে নয়। প্রতিদিন ছোট ছোট পদক্ষেপে আবার শুরু করো।'",
        "ইউনিসেফ অনুযায়ী সহনশীলতা হলো কঠিন পরিস্থিতি কাটিয়ে নতুন করে এগিয়ে যাওয়ার মানবিক ক্ষমতা।",
        "যা আমাদের নিয়ন্ত্রণে আছে তার ওপর মন দিলে সব প্রতিকূলতা জয় করা সম্ভব।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Pooja faces severe study disruptions in a flood shelter.", bn: "আশ্রয়কেন্দ্রে পূজার পড়াশোনা ব্যাহত হচ্ছে।" },
      choiceA: { en: "Assume her educational journey is over and give up reading.", bn: "ধরে নেওয়া পড়াশোনা শেষ এবং হাল ছেড়ে দেওয়া।" },
      resultA: { en: "Deepens helplessness and leads to long-term dropout.", bn: "হতাশা বাড়ে এবং পড়ার সুযোগ নষ্ট হয়।" },
      choiceB: { en: "Apply 'Resilience Mindset Tool' (Focus on Controllables, organize Shelter Study Group).", bn: "আশ্রয়কেন্দ্রে অন্য মেয়েদের নিয়ে পড়ার দল তৈরি করা।" },
      resultB: { en: "Adapts to crisis, maintains study habits, and builds peer support.", bn: "সংকট মোকাবিলা করে পড়াশোনা চালু থাকে।" }
    },
    actionableTakeaways: {
      en: [
        "Controllables vs. Uncontrollables Matrix: Separate worries into what you can influence (effort, study) vs. what you cannot (weather).",
        "Resilience Mindset Shift: Repeat: 'This setback is temporary, and I can take one small step today.'",
        "Crisis Resource Finder: Connect with local aid committees and school schemes."
      ],
      bn: [
        "নিয়ন্ত্রণযোগ্য বিষয়ের ছক: যা তোমার হাতে আছে (চেষ্টা, বই পড়া) সেদিকে মন দাও।",
        "ইতিবাচক সংকল্প: 'এই কঠিন সময় সাময়িক, আমি আজ এক ধাপ এগোব।'—মনে রাখো।",
        "সাহায্য কেন্দ্র: সরকারি সাহায্য ও শিক্ষকদের সাথে যোগাযোগ রাখো।"
      ]
    },
    keyTakeaway: { en: "Resilience is taking small daily steps forward during hardship. Disruption cannot extinguish your potential.", bn: "প্রতিকূলতার মাঝেও প্রতিদিন এক পা করে এগোনোই আসল সহনশীলতা। কোনো ঝড় তোমার মেধা কেড়ে নিতে পারে না।" }
  },
  {
    id: 11,
    phase: 4,
    phaseTitle: { en: "Decision Making, Goal Planning & Negotiation", bn: "দূরদর্শী সিদ্ধান্ত, লক্ষ্য নির্ধারণ ও আলোচনা" },
    category: "decision-making",
    emoji: "🧭",
    title: { en: "Critical Thinking & Evaluating Choices", bn: "গঠনমূলক চিন্তাভাবনা ও সিদ্ধান্ত মূল্যায়ন" },
    summary: { en: "Apply critical thinking to analyze information objectively, evaluate choices, and reject gender stereotypes.", bn: "কুসংস্কার ও গুজবের বাইরে গিয়ে তথ্য বিশ্লেষণ করে সঠিক সিদ্ধান্ত নেওয়ার ক্ষমতা অর্জন।" },
    content: {
      en: [
        "15-year-old Suman's relatives insist completing Grade 10 is unnecessary for girls, while her teacher presents vocational education options.",
        "Her teacher shares facts: India's Female Labour Force Participation dropped partly because decisions were made for girls rather than by them. Secondary education protects health and independence.",
        "Suman asks how to know who to trust. Her teacher explains: 'Critical thinking means asking: Is this advice based on verified facts, or traditional stereotypes?'",
        "Analyzing pros, cons, and long-term autonomy helps girls make decisions that secure their future."
      ],
      bn: [
        "সুমনকে আত্মীয়রা বলছিল দশম শ্রেণি পাসের কোনো দরকার নেই, কিন্তু শিক্ষক তাকে উচ্চশিক্ষা ও কাজের সুযোগের কথা বললেন।",
        "শিক্ষক দেখালেন যে পড়াশোনা সম্পন্ন করলে মেয়েদের স্বাধীনতা ও স্বাবলম্বী হওয়ার সুযোগ বহুগুণ বাড়ে।",
        "কীভাবে সিদ্ধান্ত নিতে হয় জানতে চাইলে শিক্ষক বললেন: গঠনমূলক চিন্তা মানে যাচাই করা—পরামর্শটি কি তথ্যের ওপর দাঁড়িয়ে নাকি অন্ধবিশ্বাসের ওপর?",
        "লাভ-ক্ষতি ও ভবিষ্যতের স্বাধীনতা বিচার করে সিদ্ধান্ত নেওয়াই দূরদর্শিতা।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Suman evaluates whether to drop out after Grade 8 or continue to secondary school.", bn: "সুমন অষ্টম শ্রেণির পর পড়া ছাড়বে নাকি পড়াশোনা চালিয়ে যাবে তা নিয়ে দ্বিধায় পড়ে।" },
      choiceA: { en: "Accept relatives' advice without analyzing economic impacts.", bn: "অর্থনৈতিক পরিণতি না ভেবে আত্মীয়দের কথায় পড়া ছাড়া।" },
      resultA: { en: "High risk of early marriage and financial dependence.", bn: "বাল্যবিয়ে ও পরনির্ভরশীলতার ঝুঁকি বাড়ে।" },
      choiceB: { en: "Run choices through the 'Decision-Making Analysis Grid'.", bn: "'সিদ্ধান্ত বিশ্লেষণ ছক' ব্যবহার করে দীর্ঘমেয়াদী লাভ দেখা।" },
      resultB: { en: "Identifies long-term independence benefits and builds rational choice.", bn: "পড়াশোনা চালিয়ে যাওয়ার স্পষ্ট যুক্তি খুঁজে পায়।" }
    },
    actionableTakeaways: {
      en: [
        "Decision Analysis Grid: Compare options across immediate pros, cons, and impact on autonomy.",
        "Bias Detector: Identify hidden gender stereotypes in everyday comments.",
        "Fact vs. Opinion Sorter: Distinguish between objective facts and cultural assumptions."
      ],
      bn: [
        "সিদ্ধান্ত ছক: তাৎক্ষণিক আরাম বনাম ভবিষ্যতের স্বাধীনতার তুলনা করো।",
        "পক্ষপাতিত্ব চেনা: দৈনন্দিন কথায় লুকিয়ে থাকা লিঙ্গবৈষম্য চিহ্নিত করো।",
        "সত্য বনাম মতামত: বৈজ্ঞানিক সত্য আর লোকমুখের ধারণার পার্থক্য বোঝো।"
      ]
    },
    keyTakeaway: { en: "Critical thinking evaluates facts over stereotypes. Make decisions that protect your future independence.", bn: "কুসংস্কার নয়, তথ্যের ওপর ভিত্তি করে সিদ্ধান্ত নাও। নিজের ভবিষ্যতের দায়িত্ব নিজেই নাও।" }
  },
  {
    id: 12,
    phase: 4,
    phaseTitle: { en: "Decision Making, Goal Planning & Negotiation", bn: "দূরদর্শী সিদ্ধান্ত, লক্ষ্য নির্ধারণ ও আলোচনা" },
    category: "decision-making",
    emoji: "🚀",
    title: { en: "Goal Setting & Planning for the Future", bn: "ভবিষ্যৎ লক্ষ্য নির্ধারণ ও পরিকল্পনা" },
    summary: { en: "Formulate realistic, actionable education and career goals using the SMART framework.", bn: "SMART পদ্ধতির সাহায্যে সুনির্দিষ্ট লক্ষ্য স্থির করে স্বাবলম্বী হওয়ার পথে এগিয়ে চলা।" },
    content: {
      en: [
        "16-year-old Rekha dreams of becoming a solar equipment technician, but neighbors say technical repair is only for men.",
        "Her mentor shows her data that technical skills open real economic self-reliance. Rekha learns to turn her ambition into a SMART goal.",
        "SMART goals are Specific, Measurable, Achievable, Relevant, and Time-bound.",
        "Breaking broad ambitions into weekly milestones bridges current realities with financial independence."
      ],
      bn: [
        "১৬ বছর বয়সী রেখা সোলার প্যানেল টেকনিশিয়ান হতে চায়, কিন্তু পাড়ার লোক বলে এটা মেয়েদের কাজ নয়।",
        "সখী মেন্টর তাকে বোঝায় যে প্রযুক্তি ও কারিগরি শিক্ষা মেয়েদের সবচেয়ে বেশি স্বনির্ভর করে।",
        "SMART লক্ষ্য হলো: নির্দিষ্ট, পরিমাপযোগ্য, অর্জনযোগ্য, প্রাসঙ্গিক এবং সময়সীমার সাথে যুক্ত।",
        "বড় স্বপ্নকে ছোট ছোট সাপ্তাহিক ধাপে ভাগ করলে লক্ষ্য ছোঁয়া সহজ হয়।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Rekha maps out her plan to enroll in a vocational training institute.", bn: "রেখা কারিগরি প্রশিক্ষণ কোর্সে ভর্তির পরিকল্পনা করে।" },
      choiceA: { en: "Keep her ambition vague ('I want to work in tech someday') with no dates.", bn: "কোনো তারিখ বা পরিকল্পনা ছাড়া স্বপ্ন দেখা।" },
      resultA: { en: "Progress stalls due to lack of structure.", bn: "বাস্তবায়ন হয় না এবং স্বপ্ন অধরা থেকে যায়।" },
      choiceB: { en: "Input a structured SMART Goal template into the Sakhi App.", bn: "SMART পদ্ধতিতে নির্দিষ্ট সময়সীমা দিয়ে রুটিন তৈরি করা।" },
      resultB: { en: "Creates clear weekly milestones for exam prep and enrollment.", bn: "সঠিক সময়ে প্রস্তুতি নিয়ে কোর্সে ভর্তি হওয়া সম্ভব হয়।" }
    },
    actionableTakeaways: {
      en: [
        "SMART Goal Builder: S-Specific, M-Measurable, A-Achievable, R-Relevant, T-Time-bound.",
        "Milestone Roadmap: Track weekly targets with a progress bar.",
        "Resource Hub: Map vocational scholarships and computer centers in your area."
      ],
      bn: [
        "SMART লক্ষ্য তৈরি: নির্দিষ্ট, পরিমাপযোগ্য, বাস্তবসম্মত ও সময়াবদ্ধ লক্ষ্য লেখো।",
        "মাইলফলক ট্র্যাকার: প্রতি সপ্তাহের লক্ষ্য পূরণ হলে টিক দাও।",
        "সুযোগের সন্ধান: সরকারি স্কলারশিপ ও স্থানীয় কম্পিউটার সেন্টারের খোঁজ রাখো।"
      ]
    },
    keyTakeaway: { en: "Turn broad dreams into specific, time-bound milestones. Concrete planning breaks down barriers.", bn: "স্বপ্নকে সুনির্দিষ্ট সময়সীমায় ভাগ করো। পরিকল্পনা থাকলে যেকোনো বাধা অতিক্রম করা সম্ভব।" }
  },
  {
    id: 13,
    phase: 4,
    phaseTitle: { en: "Decision Making, Goal Planning & Negotiation", bn: "দূরদর্শী সিদ্ধান্ত, লক্ষ্য নির্ধারণ ও আলোচনা" },
    category: "decision-making",
    emoji: "🗣️",
    title: { en: "Negotiation, Assertiveness & Saying No", bn: "আলোচনা, অধিকার রক্ষা ও 'না' বলার দক্ষতা" },
    summary: { en: "Master logic, persuasion, and assertive refusal skills to negotiate personal choices, postpone marriage, and stay in school.", bn: "যুক্তি ও সাহসের সাথে বাল্যবিয়ে ঠেকানো, পড়াশোনা চালিয়ে যাওয়ার অধিকার আদায় এবং ক্ষতিকর প্রস্তাবে 'না' বলা।" },
    content: {
      en: [
        "16-year-old Farida learns her family is arranging her marriage before age 18. She wishes to finish school and become a nurse.",
        "Her mentor advises: 'Aggression destroys negotiation, and staying silent surrenders your future. Use logic, economic facts, and trusted allies like your school principal.'",
        "UNICEF defines negotiation as reaching agreements through facts and empathetic persuasion.",
        "Saying 'No' firmly to illegal or harmful proposals protects your bodily safety and constitutional rights."
      ],
      bn: [
        "১৬ বছর বয়সী ফরিদা জানতে পারে তার ১৮ বছর হওয়ার আগেই বিয়ের কথাবার্তা চলছে, কিন্তু সে নার্সিং পড়তে চায়।",
        "মেন্টর বলল: 'চেঁচামেচি করলে কাজ হবে না, আবার চুপ থাকলেও ভবিষ্যৎ নষ্ট হবে। যুক্তি, অর্থনৈতিক লাভ এবং স্কুলের প্রধান শিক্ষকের মতো বড়দের সাথে নিয়ে আলোচনা করো।'",
        "আলোচনা হলো যুক্তি ও সহমর্মিতার মাধ্যমে পরিবারকে বোঝানোর শিল্প।",
        "ক্ষতিকর বা অন্যায্য প্রস্তাবে স্পষ্ট 'না' বলা তোমার সাংবিধানিক অধিকার।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Farida negotiates with parents to postpone marriage until age 20.", bn: "ফরিদা ২০ বছর বয়স পর্যন্ত বিয়ে পিছিয়ে দেওয়ার জন্য বাবা-মায়ের সাথে আলোচনা করে।" },
      choiceA: { en: "React aggressively or run away from home.", bn: "উগ্র আচরণ করা বা বাড়ি থেকে পালিয়ে যাওয়ার চেষ্টা করা।" },
      resultA: { en: "Escalates family crisis and loses community support.", bn: "বিপদ বাড়ে এবং নির্ভরযোগ্য সাহায্য হারিয়ে যায়।" },
      choiceB: { en: "Use Negotiation Dialogue Script and involve her school principal.", bn: "অর্থনৈতিক যুক্তি তুলে ধরে প্রধান শিক্ষককে সাথে নিয়ে আলোচনা করা।" },
      resultB: { en: "Presents logical arguments leading to parental agreement to delay marriage.", bn: "বাবা-মা রাজি হন এবং নার্সিং পড়ার অনুমতি মেলে।" }
    },
    actionableTakeaways: {
      en: [
        "Negotiation Script Generator: Practice: 'I understand your concern, but my education allows me to earn and support our family.'",
        "Ally Engagement: Involve respected teachers or Panchayat members to assist in family discussions.",
        "Assertive Refusal: Say 'No' firmly, state your reason, and refuse without apologizing for protecting your rights."
      ],
      bn: [
        "আলোচনার বাক্য: 'আমি আপনাদের চিন্তা বুঝি, কিন্তু পড়া শেষ করলে আমি নিজে আয় করে সংসার চালাতে পারব।'—এভাবে বলো।",
        "বিশ্বস্ত মধ্যস্থতাকারী: শিক্ষক বা সচেতন মুরুব্বিদের সাথে নাও।",
        "দৃঢ় 'না': অন্যায্য প্রস্তাবে কোনো দ্বিধা ছাড়া শান্তভাবে নিজের অবস্থান জানাও।"
      ]
    },
    keyTakeaway: { en: "Negotiate with logic, economic facts, and respected allies. Stand firm in protecting your right to an education.", bn: "যুক্তি ও বুদ্ধি দিয়ে আলোচনা করো। নিজের পড়াশোনা ও জীবনের সিদ্ধান্তের সাথে আপস করবে না।" }
  },
  {
    id: 14,
    phase: 5,
    phaseTitle: { en: "Puberty, Menstrual Health & Nutrition", bn: "বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টি" },
    category: "health-hygiene",
    emoji: "🌺",
    title: { en: "Understanding Puberty & Physical Growth", bn: "বয়ঃসন্ধিকাল ও শারীরিক বিকাশ" },
    summary: { en: "Demystify biological body transitions, hormonal shifts, and physical changes during adolescent development.", bn: "বয়ঃসন্ধিকালে শরীরের স্বাভাবিক বৃদ্ধি, হরমোনের পরিবর্তন ও স্বাস্থ্যবিধি সম্পর্কে স্পষ্ট ধারণা লাভ।" },
    content: {
      en: [
        "12-year-old Lata notices breast changes, hip widening, and body odor, wearing a heavy winter shawl in the summer heat because she feels ashamed.",
        "Her mentor reassures her: 'You are not sick. WHO guidelines explain that hormones naturally trigger pubertal maturation between ages 10 and 14.'",
        "Primary health risks for early adolescents center on water, sanitation, and hygiene (WASH) deficiencies.",
        "Daily bathing with clean water, wearing clean dry cotton innerwear, and staying hydrated keep the body healthy and comfortable."
      ],
      bn: [
        "১২ বছর বয়সী লতা নিজের শারীরিক পরিবর্তন ও গন্ধ নিয়ে লজ্জা পেয়ে গরমেও ভারী চাদর জড়িয়ে ঘুরছিল।",
        "মেন্টর তাকে বোঝাল যে ১০ থেকে ১৪ বছর বয়সে হরমোনের কারণে এই পরিবর্তন হওয়া সম্পূর্ণ স্বাভাবিক ও সুস্থতার লক্ষণ।",
        "বয়ঃসন্ধিকালে পরিচ্ছন্নতা ও সুস্বাস্থ্যের দিকে নজর রাখা সবচেয়ে জরুরি।",
        "নিয়মিত স্নান, পরিষ্কার সুতির অন্তর্বাস এবং পর্যাপ্ত জল পান শরীরকে সুস্থ রাখে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Lata feels embarrassed by pubertal changes and wants to skip school.", bn: "লতা শারীরিক পরিবর্তনের কারণে লজ্জা পেয়ে স্কুল কামাই করতে চায়।" },
      choiceA: { en: "Stay home, avoid bathing, and hide under heavy clothing.", bn: "বাড়ি বসে থাকা এবং ভারী পোশাকে নিজেকে লুকিয়ে রাখা।" },
      resultA: { en: "Increases hygiene health risks, skin infections, and emotional distress.", bn: "চর্মরোগের ঝুঁকি বাড়ে এবং মন খারাপ হয়।" },
      choiceB: { en: "Open the Puberty Guide, practice daily hygiene, and talk to a female health mentor.", bn: "হাইজিন গাইড দেখে নিয়মিত পরিচ্ছন্ন থাকা এবং মেন্টরের পরামর্শ নেওয়া।" },
      resultB: { en: "Normalizes body growth and maintains active school attendance.", bn: "লজ্জা দূর হয় এবং আনন্দে স্কুলে যাওয়া সম্ভব হয়।" }
    },
    actionableTakeaways: {
      en: [
        "Puberty Tracker: Explore normal biological changes (growth spurts, sweat glands, hair).",
        "WASH Checklist: Wash body daily with clean water and mild soap, wear dry cotton innerwear.",
        "Myth-Buster Hub: Access scientific facts debunking superstitious body growth taboos."
      ],
      bn: [
        "পরিবর্তনের তথ্য: শারীরিক বৃদ্ধি সম্পর্কে বৈজ্ঞানিক জ্ঞান রাখো।",
        "পরিচ্ছন্নতার রুটিন: সাবান ও পরিষ্কার জল দিয়ে স্নান এবং শুকনো পোশাক পরো।",
        "কুসংস্কার দূরীকরণ: বড় হওয়ার ব্যাপারে অবৈজ্ঞানিক ধারণা বিশ্বাস করবে না।"
      ]
    },
    keyTakeaway: { en: "Puberty is a natural biological growth phase. Daily hygiene and scientific understanding eliminate shame.", bn: "বয়ঃসন্ধিকাল জীবনের স্বাভাবিক বৃদ্ধির ধাপ। পরিচ্ছন্নতা বজায় রাখলে কোনো ভয় থাকে না।" }
  },
  {
    id: 15,
    phase: 5,
    phaseTitle: { en: "Puberty, Menstrual Health & Nutrition", bn: "বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টি" },
    category: "health-hygiene",
    emoji: "🩸",
    title: { en: "Menstrual Health, Hygiene & Safe Practices", bn: "মাসিক স্বাস্থ্য, পরিচ্ছন্নতা ও সঠিক অভ্যাস" },
    summary: { en: "Master hygienic management of menstruation, track menstrual cycles, and dismantle harmful social taboos.", bn: "মাসিকের বৈজ্ঞানিক কারণ জানা, প্যাড ও কাপড়ের পরিচ্ছন্ন ব্যবহার এবং ক্ষতিকর কুসংস্কার দূর করা।" },
    content: {
      en: [
        "13-year-old Asha experiences her first period at school, terrified by myths that menstruating girls are 'impure'.",
        "Her Sakhi audio guide clarifies: 'Menstruation is simply the monthly shedding of the uterine lining. It is proof of a healthy reproductive system.'",
        "Hygienic management requires changing sanitary pads or clean cloth every 4–6 hours, washing with clean water, and drying reusable cloth pads in direct, open sunlight to kill bacteria.",
        "Dismantling taboos (like not touching food or staying out of school) ensures continuous education and dignified self-care."
      ],
      bn: [
        "১৩ বছর বয়সী আশা স্কুলে প্রথম মাসিকের রক্ত দেখে ভয় পেয়ে যায় কারণ সে শুনেছিল এটি 'অশুচি'।",
        "সখী অ্যাপের গাইড তাকে বোঝায় যে মাসিক একটি স্বাভাবিক শারীরবৃত্তীয় প্রক্রিয়া, যা প্রমাণ করে শরীর সুস্থ।",
        "প্রতি ৪ থেকে ৬ ঘণ্টা পর পর প্যাড বা পরিষ্কার কাপড় বদলানো এবং কাপড় সবসময় কড়া রোদে শুকানো জরুরি যাতে জীবাণু ধ্বংস হয়।",
        "আচার-অনুষ্ঠানের কুসংস্কার ভেঙে স্বাভাবিক পুষ্টিকর খাবার খাওয়া ও স্কুলে যাওয়া স্বাস্থ্যকর জীবনের জন্য আবশ্যক।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Asha needs to dry her washed reusable cloth pad at home.", bn: "আশাকে বাড়িতে ধোয়া কাপড়ের প্যাড শুকাতে হবে।" },
      choiceA: { en: "Hide the wet cloth under a dark mattress or bed in secret.", bn: "লজ্জায় ভিজে কাপড়টি খাটের তলায় অন্ধকারে লুকিয়ে রাখা।" },
      resultA: { en: "Traps dangerous bacteria, leading to severe reproductive tract infections.", bn: "জীবাণু জন্ম নেয় এবং মারাত্মক ইনফেকশন হওয়ার ঝুঁকি থাকে।" },
      choiceB: { en: "Hang the washed cloth pad in direct, open sunlight as instructed.", bn: "খোলা জায়গায় কড়া রোদের আলোয় কাপড়টি মেলে দেওয়া।" },
      resultB: { en: "Direct sunlight sterilizes the cloth, ensuring hygienic safety.", bn: "রোদের আল্ট্রাভায়োলেট রশ্মি জীবাণু মেরে ফেলে এবং সুরক্ষা নিশ্চিত করে।" }
    },
    actionableTakeaways: {
      en: [
        "Menstrual Hygiene Rules: Change pads/cloths every 4–6 hours; wash genital area with clean water.",
        "Sunlight Drying: Always dry reusable cloth pads in direct sunlight to eliminate bacteria.",
        "Menstrual Cycle Tracker: Log your start dates to predict cycles (21–35 days typical).",
        "Safe Disposal: Wrap disposable pads in paper and place in waste bins—never flush."
      ],
      bn: [
        "প্যাড বদল: ৪-৬ ঘণ্টা অন্তর পরিষ্কার প্যাড বা কাপড় ব্যবহার করো।",
        "রোদে শুকানো: কাপড়ের প্যাড সবসময় কড়া রোদে মেলে জীবাণুমুক্ত করো।",
        "তারিখের হিসাব: প্রতি মাসের তারিখ লিখে রাখো (সাধারণত ২১-৩৫ দিন পর পর)।",
        "সঠিক বর্জন: ব্যবহৃত প্যাড কাগজে মুড়ে ডাস্টবিনে ফেলো, কখনো ড্রেনে ফেলবে না।"
      ]
    },
    keyTakeaway: { en: "Menstruation is a healthy biological process. Hygienic practices and open sunlight drying protect your health.", bn: "মাসিক কোনো লজ্জা বা অপবিত্রতা নয়। সঠিক পরিচ্ছন্নতা তোমাকে সুস্থ ও আত্মবিশ্বাসী রাখে।" }
  },
  {
    id: 16,
    phase: 5,
    phaseTitle: { en: "Puberty, Menstrual Health & Nutrition", bn: "বয়ঃসন্ধি, মাসিক স্বাস্থ্য ও পুষ্টি" },
    category: "health-hygiene",
    emoji: "🥗",
    title: { en: "Nutrition, Physical Health & Anemia Prevention", bn: "পুষ্টি, শারীরিক স্বাস্থ্য ও রক্তস্বল্পতা প্রতিরোধ" },
    summary: { en: "Understand balanced nutrition, iron-rich dietary habits, and exercise to combat high adolescent anemia rates.", bn: "পুষ্টিকর খাবার, আয়রন ও ভিটামিন সি সমৃদ্ধ খাদ্যতালিকা এবং অ্যানিমিয়া বা রক্তস্বল্পতা প্রতিরোধের উপায়।" },
    content: {
      en: [
        "15-year-old Seema experiences constant fatigue and dizziness during school assembly. A local health worker diagnoses iron-deficiency anemia.",
        "In many homes, girls eat last and least, receiving less iron and protein. Paired with menstrual blood loss, this triggers severe anemia.",
        "Eating local iron-rich foods (spinach, chana, jaggery/gud, dal) paired with Vitamin C (lemon, amla) maximizes iron absorption.",
        "Active daily movement (brisk walking, sports, yoga) alongside Weekly Iron and Folic Acid Supplementation (WIFS) boosts cognitive focus."
      ],
      bn: [
        "১৫ বছর বয়সী সীমা স্কুলে দুর্বলতা ও মাথা ঘোরার সমস্যায় ভুগছিল। স্বাস্থ্য পরীক্ষায় দেখা গেল তার মারাত্মক রক্তস্বল্পতা বা অ্যানিমিয়া হয়েছে।",
        "অনেক পরিবারে মেয়েরা সবার শেষে খায় এবং কম পুষ্টিকর খাবার পায়। মাসিকের রক্তক্ষরণের সাথে আয়রনের অভাবে অ্যানিমিয়া দেখা দেয়।",
        "শাকসবজি (পালং শাক), ছোলা, গুড় ও ডালের সাথে পাতিলেবু বা আমলকী (ভিটামিন সি) খেলে শরীর সহজেই আয়রন শুষে নিতে পারে।",
        "নিয়মিত খেলাধুলো এবং আয়রন বড়ি (WIFS) খাওয়ার মাধ্যমে ক্লান্তি দূর করে পড়ায় মনোযোগ আনা যায়।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Seema chooses her daily meal items at home.", bn: "সীমা নিজের দুপুরের খাবারের পদ বেছে নেয়।" },
      choiceA: { en: "Eat only leftover plain white rice and tea.", bn: "শুধু বাসি ভাত আর চা খাওয়া।" },
      resultA: { en: "Tea inhibits iron absorption, worsening fatigue and anemia.", bn: "চা আয়রন শোষণ আটকে দেয় এবং দুর্বলতা বাড়িয়ে তোলে।" },
      choiceB: { en: "Add local spinach (palak), Bengal gram (chana), and a squeeze of fresh lemon juice.", bn: "শাক ও ছোলার সাথে একটু লেবুর রস মিশিয়ে খাওয়া।" },
      resultB: { en: "Maximizes plant iron absorption and rapidly boosts energy levels.", bn: "শরীরে দ্রুত রক্ত তৈরি হয় এবং ক্লান্তি দূর হয়।" }
    },
    actionableTakeaways: {
      en: [
        "Iron-Rich Foods: Green leafy vegetables (palak, methi), Bengal gram (chana), lentils (dal), jaggery (gud).",
        "Vitamin C Boosters: Always squeeze lemon or amla over meals to maximize iron uptake.",
        "WIFS Tracker: Log your Weekly Iron and Folic Acid Supplements from school or Anganwadi.",
        "Daily Movement: Maintain 30 minutes of daily physical sports or brisk walking."
      ],
      bn: [
        "আয়রনযুক্ত খাবার: শাকসবজি, ছোলা, ডাল ও গুড় বেশি করে খাও।",
        "ভিটামিন সি: খাবারের সাথে লেবু বা আমলকী খেলে আয়রন শরীরে সহজে কাজে লাগে।",
        "আয়রন বড়ি: স্কুল বা স্বাস্থ্যকেন্দ্র থেকে দেওয়া সাপ্তাহিক আয়রন বড়ি নিয়ম করে খাও।",
        "ব্যায়াম: প্রতিদিন অন্তত ৩০ মিনিট হাঁটাহাঁটি বা খেলাধুলো করো।"
      ]
    },
    keyTakeaway: { en: "Pair plant iron with Vitamin C to fight anemia. Your body needs proper fuel to learn and thrive.", bn: "লেবু ও শাকসবজি দিয়ে রক্তস্বল্পতা দূর করো। সুস্থ ও পুষ্টিকর খাবার তোমার পড়াশোনার মূল শক্তি।" }
  },
  {
    id: 17,
    phase: 6,
    phaseTitle: { en: "Rights, Protection, Helplines & Cyber Safety", bn: "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা" },
    category: "rights-safety",
    emoji: "⚖️",
    title: { en: "Understanding Child Rights & Gender Equality", bn: "শিশু অধিকার ও লিঙ্গ সমতা" },
    summary: { en: "Understand fundamental legal rights to protection, education, health, and participation without discrimination.", bn: "আইনি সুরক্ষা, অবৈতনিক শিক্ষা, স্বাস্থ্য এবং বৈষম্যহীন মত প্রকাশের ৪টি মৌলিক অধিকার জানা।" },
    content: {
      en: [
        "In 14-year-old Pinky's village, girls leave school at age 12 to work in agricultural fields while boys continue classes.",
        "Her Sakhi mentor explains: 'Education is not a gift adults can choose to withhold. Under Indian law and international treaties, education is a fundamental right for every child under 18.'",
        "The four pillars of child rights are: Protection, Education, Health, and Participation. Gender equality mandates identical entitlements for boys and girls.",
        "Knowing your legal protections gives you the power to resist exploitation and stay in school."
      ],
      bn: [
        "১৪ বছর বয়সী পিংকির গ্রামে মেয়েদের ১২ বছর বয়সে মাঠের কাজে নামিয়ে দেওয়া হতো, অথচ ছেলেরা স্কুলে যেত।",
        "মেন্টর তাকে জানাল: 'শিক্ষা কোনো দয়া নয়, ১৮ বছর পর্যন্ত প্রতিটি শিশুর জন্য এটি একটি মৌলিক আইনি অধিকার।'",
        "শিশু অধিকারের ৪টি স্তম্ভ হলো: সুরক্ষা, শিক্ষা, স্বাস্থ্য এবং মত প্রকাশের স্বাধীনতা। ছেলে ও মেয়ে উভয়ের জন্য এই অধিকার সমান।",
        "অধিকারের সচেতনতা মেয়েদের শ্রমের শোষণ থেকে রক্ষা করে এবং স্কুলজীবন ধরে রাখে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Employers ask Pinky to drop out to work full-time in the crop fields.", bn: "জমির মালিক পিংকিকে স্কুল ছেড়ে মাঠে কাজ করার নির্দেশ দেয়।" },
      choiceA: { en: "Assume children have no legal protection against school deprivation.", bn: "মেনে নেওয়া যে শিশুদের কোনো আইনি সুরক্ষা নেই।" },
      resultA: { en: "Surrenders fundamental rights and traps in child labor cycles.", bn: "পড়াশোনা চিরতরে বন্ধ হয়ে যায় এবং শিশুশ্রমের শিকার হতে হয়।" },
      choiceB: { en: "Reference the '4 Pillars of Child Rights' and inform school authorities.", bn: "আইনি অধিকারের কথা উল্লেখ করে স্কুল শিক্ষককে জানানো।" },
      resultB: { en: "Activates child protection interventions, keeping Pinky in school.", bn: "প্রশাসন হস্তক্ষেপ করে এবং পিংকির পড়ালেখা চালু থাকে।" }
    },
    actionableTakeaways: {
      en: [
        "4 Pillars of Child Rights: 1. Protection, 2. Education, 3. Health, 4. Participation.",
        "Rights Violation Reporting: Learn reporting steps to local School Management Committees.",
        "Equality Advocacy Toolkit: Share child rights awareness with Adolescent Circle peers."
      ],
      bn: [
        "শিশু অধিকারের ৪ স্তম্ভ: সুরক্ষা, শিক্ষা, স্বাস্থ্য এবং মত প্রকাশ।",
        "অভিযোগ জানানোর নিয়ম: কোনো বাধা এলে স্কুলের শিক্ষক বা কমিটিকে জানাও।",
        "বন্ধুদের সচেতন করা: নিজের ক্লাসের সব মেয়েকে তাদের অধিকার সম্পর্কে বলো।"
      ]
    },
    keyTakeaway: { en: "Education and protection are legal rights, not privileges. Gender equality ensures identical rights for every child.", bn: "শিক্ষা ও সুরক্ষা কোনো অনুগ্রহ নয়, তোমার জন্মগত অধিকার। ছেলে ও মেয়ে সবার অধিকার সমান।" }
  },
  {
    id: 18,
    phase: 6,
    phaseTitle: { en: "Rights, Protection, Helplines & Cyber Safety", bn: "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা" },
    category: "rights-safety",
    emoji: "🛑",
    title: { en: "Child Marriage Laws & Postponing Marriage Age", bn: "বাল্যবিয়ে বিরোধী আইন ও বয়স বৃদ্ধি" },
    summary: { en: "Understand the Prohibition of Child Marriage Act, minimum legal ages, and health benefits of delaying marriage past 18.", bn: "বাল্যবিয়ে প্রতিরোধ আইন, মেয়েদের জন্য সর্বনিম্ন ১৮ বছর বয়স এবং অল্প বয়সে বিয়ের স্বাস্থ্যগত ঝুঁকি বোঝা।" },
    content: {
      en: [
        "15-year-old Sunita discovers her parents are planning her marriage during an upcoming festival to reduce dowry costs.",
        "Her mentor acts quickly: 'Under the Prohibition of Child Marriage Act, 18 is the strict minimum legal age for females. Arranging child marriage is a non-bailable criminal offense.'",
        "WHO global health data shows pregnancy complications and unsafe abortions are the leading cause of death among 15–19-year-old girls globally.",
        "Connecting with local Child Protection Committees or calling CHILDLINE (1098) / Women Helpline (181) provides immediate legal protection."
      ],
      bn: [
        "১৫ বছর বয়সী সুনীতা জানতে পারে কম বয়সে যৌতুক কম লাগবে ভেবে তার পরিবার একটি উৎসবে তার বিয়ের ঠিক করেছে।",
        "মেন্টর তাকে সতর্ক করল: 'বাল্যবিয়ে প্রতিরোধ আইন অনুযায়ী মেয়েদের বিয়ের বয়স অন্তত ১৮ বছর হওয়া বাধ্যতামূলক। এর আগে বিয়ে দেওয়া শাস্তিযোগ্য অপরাধ।'",
        "বিশ্ব স্বাস্থ্য সংস্থা অনুযায়ী ১৫-১৯ বছর বয়সী কিশোরীদের মৃত্যুর প্রধান কারণ হলো অপরিণত বয়সে গর্ভধারণের জটিলতা।",
        "১০৯৮ (চাইল্ডলাইন) বা ১৮১ (নারী হেল্পলাইন)-এ ফোন করলে তৎক্ষণাৎ আইনি উদ্ধার পাওয়া যায়।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Sunita faces imminent forced child marriage.", bn: "সুনীতাকে জোর করে অপ্রাপ্তবয়সে বিয়ে দেওয়ার চেষ্টা চলছে।" },
      choiceA: { en: "Yield silently and drop out of school.", bn: "চুপচাপ মেনে নেওয়া এবং স্কুল ছেড়ে দেওয়া।" },
      resultA: { en: "Severe health risks, early pregnancy complications, and loss of independence.", bn: "জীবন বিপন্ন হয় এবং শারীরিক ও মানসিক ক্ষতি হয়।" },
      choiceB: { en: "Connect with support networks, involve the Child Protection Committee, and call 1098.", bn: "শিশু সুরক্ষা কমিটি ও চাইল্ডলাইন ১০৯৮-এ যোগাযোগ করা।" },
      resultB: { en: "Legal intervention halts marriage and secures Sunita's continued education.", bn: "প্রশাসন বিয়ে বন্ধ করে এবং সুনীতার পড়ালেখা রক্ষা পায়।" }
    },
    actionableTakeaways: {
      en: [
        "Legal Age Limits: 18 years for females, 21 years for males under Indian law.",
        "Non-Bailable Crime: Organizing, performing, or aiding child marriage is strictly punishable by law.",
        "Emergency Action: Dial 1098 (CHILDLINE) or 181 (Women Helpline) for immediate legal rescue.",
        "Health Awareness: Delaying marriage past 18 prevents pregnancy fatalities and secures education."
      ],
      bn: [
        "আইনি বয়স: মেয়েদের বিয়ের বয়স অন্তত ১৮ বছর এবং ছেলেদের ২১ বছর।",
        "শাস্তিযোগ্য অপরাধ: বাল্যবিয়ে দেওয়া ও সহযোগিতা করা উভয়েই শাস্তিযোগ্য জেল-জরিমানা।",
        "জরুরি নম্বর: বিপদে পড়লে ১০৯৮ বা ১৮১ নম্বরে ফোন করো।",
        "স্বাস্থ্য সচেতনতা: ১৮ বছরের আগে বিয়ে হলে মৃত্যুর ঝুঁকি বাড়ে।"
      ]
    },
    keyTakeaway: { en: "Child marriage is illegal and dangerous. Call 1098 or 181 to protect your life, health, and schooling.", bn: "বাল্যবিয়ে বেআইনি ও বিপজ্জনক। ১৮-র আগে বিয়ে রুখতে ১০৯৮ বা ১৮১-এ ফোন করে সাহায্য নাও।" }
  },
  {
    id: 19,
    phase: 6,
    phaseTitle: { en: "Rights, Protection, Helplines & Cyber Safety", bn: "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা" },
    category: "rights-safety",
    emoji: "✋",
    title: { en: "Safe Touch, Unsafe Touch & Abuse Awareness", bn: "নিরাপদ ও অনিরাপদ স্পর্শ এবং সচেতনতা" },
    summary: { en: "Identify safe versus unsafe touch, recognize abuse under the POCSO Act, and eliminate self-blame.", bn: "নিরাপদ ও খারাপ স্পর্শের তফাত বোঝা, পকসো (POCSO) আইন জানা এবং 'না বলা-পালাও-বড়দের জানাও' নীতি শেখা।" },
    content: {
      en: [
        "13-year-old Meenu feels frightened when a neighbor gives her sweets and touches her inappropriately under her clothing, warning her to keep it a 'secret'.",
        "Her Sakhi mentor states firmly: 'Abuse is 100% the abuser's fault. You are NEVER to blame. A safe touch makes you feel cared for (like a handshake or hug). An unsafe touch causes hurt, confusion, or touches private body parts.'",
        "Private parts are areas covered by a swimsuit (mouth, chest, between legs, buttocks). No one has the right to touch them.",
        "Execute the NO-GO-TELL rule: Say NO firmly, GO away immediately to a safe populated place, and TELL a trusted adult or call 1098/181."
      ],
      bn: [
        "১৩ বছর বয়সী মীনুকে মিষ্টি দিয়ে একজন প্রতিবেশী তাকে অনাকাঙ্ক্ষিত স্পর্শ করে এবং কাউকে না বলতে ভয় দেখায়।",
        "মেন্টর বলল: 'এতে তোমার কোনো দোষ নেই। দোষ সম্পূর্ণ ওই ব্যক্তির। ভালোবাসার স্পর্শ ভালো অনুভূতি দেয়, কিন্তু অনিরাপদ স্পর্শ অস্বস্তি ও ভয় তৈরি করে।'",
        "সাঁতারের পোশাকে ঢাকা শরীরের একান্ত স্থানগুলোতে (বুক, দুই পায়ের মাঝে, নিতম্ব) স্পর্শ করা আইনত নিষিদ্ধ।",
        "৩টি নিয়ম মনে রাখো: ১. জোরে 'না' বলো, ২. সেখান থেকে দ্রুত সরে যাও, ৩. বিশ্বস্ত বড়দের বা হেল্পলাইনে খুলে বলো।"
      ]
    },
    branchingScenario: {
      scenario: { en: "An acquaintance attempts an unsafe touch and demands secrecy.", bn: "একজন পরিচিত ব্যক্তি খারাপভাবে স্পর্শ করে কাউকে না বলার ভয় দেখায়।" },
      choiceA: { en: "Stay silent, blame yourself, and keep the secret.", bn: "লজ্জা পেয়ে চুপ থাকা এবং নিজেকে দোষ দেওয়া।" },
      resultA: { en: "Increases trauma and allows abuse to continue unchecked.", bn: "ভয় বাড়ে এবং ব্যক্তিটি সুযোগ পেতেই থাকে।" },
      choiceB: { en: "Execute the NO-GO-TELL Rule immediately.", bn: "সাথে সাথে 'না-পালাও-জানাও' নিয়ম প্রয়োগ করা।" },
      resultB: { en: "Rejects abuser, protects bodily safety, and triggers adult protection.", bn: "অসদাচরণ বন্ধ হয় এবং পুলিশ ও বড়দের সাহায্যে নিরাপত্তা মেলে।" }
    },
    actionableTakeaways: {
      en: [
        "NO-GO-TELL Rule: 1. NO (loud & firm), 2. GO (to a safe place), 3. TELL (a trusted adult or 1098/181).",
        "Swimsuit Rule: Understand private body areas protected strictly under the POCSO Act.",
        "Zero Self-Blame: Remember that victims of abuse carry zero guilt; full responsibility rests on the perpetrator."
      ],
      bn: [
        "না-পালাও-জানাও নিয়ম: জোরে না বলো, নিরাপদ জায়গায় যাও এবং বিশ্বস্ত অভিভাবককে জানাও।",
        "ব্যক্তিগত অঙ্গের সুরক্ষা: সাঁতারের পোশাকের অংশের স্পর্শের ব্যাপারে সতর্ক থাকো।",
        "নিজেকে দোষ দেবে না: এতে তোমার কোনো ভুল নেই, দোষী কেবল সেই ব্যক্তি।"
      ]
    },
    keyTakeaway: { en: "Your body belongs entirely to you. Follow NO-GO-TELL and remember that abuse is never your fault.", bn: "তোমার শরীর একমাত্র তোমার। অনিরাপদ স্পর্শে সোজাসুজি 'না' বলো এবং বড়দের সাহায্য চাও।" }
  },
  {
    id: 20,
    phase: 6,
    phaseTitle: { en: "Rights, Protection, Helplines & Cyber Safety", bn: "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা" },
    category: "rights-safety",
    emoji: "📞",
    title: { en: "Emergency Support, Helplines & Reporting Systems", bn: "জরুরি সহায়তা, হেল্পলাইন ও উদ্ধার ব্যবস্থা" },
    summary: { en: "Memorize and navigate official Indian emergency helplines: 1098, 181, 112, and 14490.", bn: "ভারতের সরকারি জরুরি হেল্পলাইন ১০৯৮, ১৮১, ১১২ এবং ১৪৪৯০ নম্বরের ব্যবহার ও বিনা খরচে সাহায্য পাওয়ার উপায়।" },
    content: {
      en: [
        "15-year-old Geeta learns a peer is trapped in an abusive domestic situation with immediate threats of physical violence.",
        "Her mentor explains: 'All official emergency shortcodes are 100% toll-free, operate 24/7, and require zero mobile talktime balance.'",
        "Key Helplines: 1098 (CHILDLINE for children under 18), 181 (Women Helpline linked to One Stop Sakhi Centres), 112 (Emergency Response for Police/Ambulance/Fire), and 14490 (National Commission for Women).",
        "These helplines connect directly to rescue teams, Child Welfare Committees, and legal protection officers."
      ],
      bn: [
        "১৫ বছর বয়সী গীতা জানতে পারে তার এক বন্ধু পারিবারিক অত্যাচারে মারাত্মক বিপদে আছে।",
        "মেন্টর বোঝাল: 'সব সরকারি হেল্পলাইন নম্বর সম্পূর্ণ বিনামূল্যে এবং দিনরাত ২৪ ঘণ্টা কাজ করে, মোবাইলে কোনো ব্যালেন্স না থাকলেও ফোন যায়।'",
        "জরুরি নম্বরসমূহ: ১০৯৮ (১৮ বছরের কম বয়সীদের জন্য চাইল্ডলাইন), ১৮১ (নারী ও কিশোরী সহায়তা), ১১২ (পুলিশ, দমকল ও অ্যাম্বুলেন্স), এবং ১৪৪৯০ (মহিলা কমিশন)।",
        "এই নম্বরে ফোন করলে তৎক্ষণাৎ উদ্ধার দল ও পুলিশ এসে সুরক্ষা নিশ্চিত করে।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Geeta witnesses a child protection emergency.", bn: "গীতা একটি কিশোরীর ওপর নির্যাতন দেখে উদ্ধার করতে চায়।" },
      choiceA: { en: "Panic and assume emergency calls require paid mobile balance.", bn: "ভয় পাওয়া এবং ভাবা যে মোবাইলে টাকা না থাকলে ফোন যাবে না।" },
      resultA: { en: "Delays critical intervention, putting the child in grave danger.", bn: "উদ্ধারে দেরি হয় এবং বিপদ বেড়ে যায়।" },
      choiceB: { en: "Use the Speed Dial Helpline Hub to connect to 1098 or 112 instantly.", bn: "সরাসরি ১০৯৮ বা ১১২ নম্বরে ফোন করা।" },
      resultB: { en: "Triggers immediate emergency response and safe legal rescue.", bn: "পুলিশ ও উদ্ধারকারী দল এসে শিশুটিকে নিরাপদে উদ্ধার করে।" }
    },
    actionableTakeaways: {
      en: [
        "CHILDLINE (1098): 24/7 toll-free emergency rescue and counseling for children under 18.",
        "Women Helpline (181): Emergency response linked to One Stop Sakhi Centres under Mission Shakti.",
        "Emergency Response (112): Single nationwide emergency number for immediate police dispatch.",
        "NCW Helpline (14490): Psychological and legal counselors trained in mental health.",
        "Zero Balance Needed: All shortcodes work on any phone without talktime balance."
      ],
      bn: [
        "১০৯৮ (চাইল্ডলাইন): ১৮ বছরের কম বয়সীদের জন্য বিনামূল্যে জরুরি উদ্ধার ও পরামর্শ।",
        "১৮১ (নারী হেল্পলাইন): নির্যাতন ও পারিবারিক সহিংসতার বিরুদ্ধে ওয়ান স্টপ সেন্টার।",
        "১১২ (জরুরি সেবা): পুলিশ, দমকল ও অ্যাম্বুলেন্সের জন্য দেশের সাধারণ নম্বর।",
        "১৪৪৯০ (মহিলা কমিশন): আইনি সহায়তা ও মানসিক স্বাস্থ্যের জন্য বিশেষজ্ঞ দল।",
        "টাকা ছাড়াই ফোন: সব ফোনে ব্যালেন্স ছাড়াই কল করা যায়।"
      ]
    },
    keyTakeaway: { en: "Emergency helplines (1098, 181, 112) are 24/7 toll-free lifelines. You never need money or balance to call for help.", bn: "জরুরি নম্বর ১০৯৮, ১৮১, ১১২ সবসময় বিনামূল্যে খোলা থাকে। বিপদে পড়লে কোনো দ্বিধা ছাড়া ফোন করো।" }
  },
  {
    id: 21,
    phase: 6,
    phaseTitle: { en: "Rights, Protection, Helplines & Cyber Safety", bn: "অধিকার, সুরক্ষা, হেল্পলাইন ও সাইবার নিরাপত্তা" },
    category: "rights-safety",
    emoji: "🌐",
    title: { en: "Cyber Safety, Digital Literacy & Online Well-being", bn: "সাইবার নিরাপত্তা, ডিজিটাল জ্ঞান ও অনলাইন সুস্থতা" },
    summary: { en: "Safely navigate mobile devices, protect privacy, handle cyberbullying, and report threats to the Cyber Crime Portal.", bn: "স্মার্টফোনে ব্যক্তিগত তথ্য ও ছবি সুরক্ষিত রাখা, সাইবার অপরাধ ও অনলাইন বুলিং প্রতিরোধ এবং সরকারি পোর্টালে অভিযোগ জানানো।" },
    content: {
      en: [
        "16-year-old Neha receives harassing messages from an unknown user demanding personal photos and threatening to alter her profile picture.",
        "Her digital safety instructor advises: 'Never comply with threats, and never delete evidence. Step 1: Take screenshots. Step 2: Block the user. Step 3: Set profiles to Private. Step 4: Report to the National Cyber Crime Portal (cybercrime.gov.in).'",
        "Practicing digital hygiene means strong passwords, keeping location settings private, and never sharing addresses or school locations publicly.",
        "Balancing screen time with physical rest preserves mental health while unlocking the positive learning power of the internet."
      ],
      bn: [
        "১৬ বছর বয়সী নেহাকে ইন্টারনেটে একজন অপরিচিত ব্যক্তি ছবি চেয়ে ব্ল্যাকমেইল ও হুমকির বার্তা পাঠায়।",
        "ডিজিটাল শিক্ষক বোঝালেন: 'হুমকিতে ভয় পাবে না এবং প্রমাণ মুছে ফেলবে না। ১. স্ক্রিনশট রাখো, ২. অ্যাকাউন্ট ব্লক করো, ৩. প্রোফাইল প্রাইভেট করো, ৪. সাইবার ক্রাইম পোর্টালে (cybercrime.gov.in) অভিযোগ করো।'",
        "শক্তিশালী পাসওয়ার্ড রাখা এবং নিজের ঠিকানা, স্কুলের নাম বা ছবি অপরিচিতদের সাথে শেয়ার না করাই হলো সাইবার সুরক্ষা।",
        "সচেতন হয়ে ইন্টারনেট ব্যবহার করলে নতুন জ্ঞান ও ভবিষ্যতের সুযোগ খুলে যায়।"
      ]
    },
    branchingScenario: {
      scenario: { en: "Neha receives an online blackmail threat demanding personal photographs.", bn: "নেহার কাছে অনলাইনে ব্যক্তিগত ছবি চেয়ে হুমকি আসে।" },
      choiceA: { en: "Comply secretly or delete all messages without saving evidence.", bn: "ভয়ে ছবি পাঠিয়ে দেওয়া অথবা সব মেসেজ মুছে ফেলা।" },
      resultA: { en: "Escalates extortion and destroys valuable legal evidence.", bn: "ব্ল্যাকমেইল বাড়ে এবং আইনগত কোনো প্রমাণ থাকে না।" },
      choiceB: { en: "Take screenshots, block user, switch privacy to Private, and inform adult allies.", bn: "স্ক্রিনশট রেখে তাকে ব্লক করা এবং বড়দের সাহায্যে সাইবার পোর্টালে জানানো।" },
      resultB: { en: "Preserves evidence, stops harassment, and enables official legal reporting.", bn: "হয়রানি বন্ধ হয় এবং আইনি পদক্ষেপে অপরাধী চিহ্নিত হয়।" }
    },
    actionableTakeaways: {
      en: [
        "Digital Hygiene Rules: 1. Strong passwords (letters, numbers, symbols), 2. Keep location and accounts Private.",
        "Block & Report: Take screenshots of harassment, block senders, report via cybercrime.gov.in.",
        "Digital Well-being Timer: Use the in-app screen tracker to balance study with physical rest."
      ],
      bn: [
        "পাসওয়ার্ড সুরক্ষা: অক্ষর ও সংখ্যার মিশ্রণে গোপন পাসওয়ার্ড রাখো এবং কাউকে বোলো না।",
        "ব্লক ও অভিযোগ: হুমকির স্ক্রিনশট রাখো, ব্লক করো এবং cybercrime.gov.in-এ জানাও।",
        "পর্দার সময়সীমা: মোবাইলে বেশি সময় না কাটিয়ে শরীরচর্চা ও পড়াশোনায় সময় দাও।"
      ]
    },
    keyTakeaway: { en: "Protect your privacy online, preserve evidence of harassment, and report threats to cybercrime.gov.in. Be bold and safe.", bn: "ইন্টারনেটে সতর্ক ও সুরক্ষিত থাকো। কোনো হুমকি এলে প্রমাণ রেখে বড়দের ও সাইবার পোর্টালে জানাও।" }
  }
];

fs.writeFileSync('src/curriculum_21_chapters.json', JSON.stringify(ALL_21_CHAPTERS, null, 2));
console.log(`Successfully written ${ALL_21_CHAPTERS.length} chapters.`);
