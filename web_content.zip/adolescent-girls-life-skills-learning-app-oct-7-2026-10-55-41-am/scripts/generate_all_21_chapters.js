// Generator script for all 21 chapters of Sakhi Life Skills Education curriculum
import fs from 'fs';

console.log("Writing curriculum generator...");
