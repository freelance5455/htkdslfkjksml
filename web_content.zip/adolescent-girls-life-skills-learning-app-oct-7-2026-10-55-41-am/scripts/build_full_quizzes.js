import fs from 'fs';

// All quizzes matching the 21 chapters from NotebookLM PDF
const quizzes = [
  // Chapter 1
  {
    id: 1,
    chapterId: 1,
    question: {
      en: "What is the primary benefit of developing self-awareness?",
      bn: "আত্মসচেতনতা গড়ে তোলার প্রধান সুফল কী?"
    },
    options: {
      en: [
        "It allows you to change others' opinions about you instantly.",
        "It helps you accurately assess your feelings, values, and strengths to build self-worth.",
        "It guarantees that you will never experience negative emotions.",
        "It ensures automatic academic success without personal effort."
      ],
      bn: [
        "এটি অন্যের মতামত এক নিমেষে পরিবর্তন করতে সাহায্য করে।",
        "এটি নিজের অনুভূতি, মূল্যবোধ ও শক্তিকে চিনে আত্মমর্যাদা গড়ে তুলতে সাহায্য করে।",
        "এটি নিশ্চিত করে যে তুমি কখনো কোনো খারাপ আবেগ অনুভব করবে না।",
        "এটি কোনো প্রচেষ্টা ছাড়াই পরীক্ষায় স্বয়ংক্রিয় সাফল্য আনে।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Self-awareness is the ability to accurately assess feelings, interests, values, and strengths within one's context, helping establish self-identity and self-worth.",
      bn: "আত্মসচেতনতা হলো নিজের অনুভূতি, আগ্রহ, মূল্যবোধ ও শক্তিকে চেনার ক্ষমতা, যা নিজের আত্মমর্যাদা সুদৃঢ় করে।"
    }
  },
  {
    id: 2,
    chapterId: 1,
    question: {
      en: "When traditional expectations make an adolescent girl feel limited, self-awareness helps her to:",
      bn: "যখন সামাজিক প্রত্যাশা একজন কিশোরীকে সীমিত করে, তখন আত্মসচেতনতা তাকে কীভাবে সাহায্য করে?"
    },
    options: {
      en: [
        "Accept those limitations as permanent personal failures.",
        "Ignore her feelings completely and conform to expectations.",
        "Understand that social disparities are external barriers and recognize her inherent capabilities.",
        "Blame herself for domestic pressures."
      ],
      bn: [
        "সীমাবদ্ধতাগুলোকে নিজের চিরস্থায়ী ব্যর্থতা হিসেবে মেনে নেওয়া।",
        "নিজের অনুভূতিকে সম্পূর্ণ উপেক্ষা করে সবার কথামতো চলা।",
        "বোঝা যে সামাজিক বৈষম্য হলো বাইরের বাধা এবং নিজের ভেতরের সক্ষমতাকে চেনা।",
        "সংসারের সব চাপের জন্য নিজেকে দোষারোপ করা।"
      ]
    },
    correctAnswerIndex: 2,
    explanation: {
      en: "Self-awareness empowers individuals to accept themselves, recognize that social barriers do not define their potential, and seek constructive solutions.",
      bn: "আত্মসচেতনতা কিশোরীদের বোঝায় যে সামাজিক বাধানিষেধ তাদের মেধার সীমা নয়।"
    }
  },
  {
    id: 3,
    chapterId: 1,
    question: {
      en: "Which mobile app feature directly supports building self-identity?",
      bn: "কোন মোবাইল ফিচারটি আত্মপরিচয় গঠনে সরাসরি সহায়তা করে?"
    },
    options: {
      en: [
        "Comparing your test scores with peers on social media.",
        "Utilizing an in-app Strength Inventory and Personal Values Journal daily.",
        "Relying entirely on peer approval to make personal choices.",
        "Hiding personal achievements to blend into group settings."
      ],
      bn: [
        "সোশ্যাল মিডিয়ায় বন্ধুদের সাথে পরীক্ষার নম্বরের তুলনা করা।",
        "প্রতিদিন ব্যক্তিগত শক্তির তালিকা ও মূল্যবোধের ডায়েরি ব্যবহার করা।",
        "ব্যক্তিগত সিদ্ধান্তের জন্য সম্পূর্ণ বন্ধুদের সম্মতির ওপর নির্ভর করা।",
        "দলে মিশে যাওয়ার জন্য নিজের অর্জনকে লুকিয়ে রাখা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Daily reflection, logging personal values, and tracking individual strengths inside structured journal tools build a stable self-identity.",
      bn: "প্রতিদিন নিজের শক্তি ও ভালো গুণগুলো লিখে রাখলে আত্মমর্যাদা সুদৃঢ় হয়।"
    }
  },

  // Chapter 2
  {
    id: 4,
    chapterId: 2,
    question: {
      en: "Adolescence (ages 10–19) is defined globally by WHO as a developmental period marked by:",
      bn: "বিশ্ব স্বাস্থ্য সংস্থা (WHO) অনুযায়ী বয়ঃসন্ধিকাল (১০–১৯ বছর) কী দ্বারা চিহ্নিত?"
    },
    options: {
      en: [
        "Complete physical stability with no biological shifts.",
        "Rapid physical, cognitive, and psychosocial growth.",
        "The final end of all cognitive learning.",
        "Identical growth rates for all individuals at the exact same age."
      ],
      bn: [
        "কোনো পরিবর্তন ছাড়া সম্পূর্ণ শারীরিক স্থিতিশীলতা।",
        "দ্রুত শারীরিক, মানসিক ও সামাজিক বৃদ্ধি ও রূপান্তর।",
        "মানুষের নতুন কিছু শেখার চূড়ান্ত সমাপ্তি।",
        "একই বয়সের সবার ক্ষেত্রে হুবহু একই হারে বৃদ্ধি।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "WHO defines adolescence as a unique developmental stage characterized by rapid physical, cognitive, and psychosocial transitions.",
      bn: "হু (WHO) অনুযায়ী বয়ঃসন্ধিকাল হলো দ্রুত শারীরিক ও মনস্তাত্ত্বিক পরিবর্তনের সময়।"
    }
  },
  {
    id: 5,
    chapterId: 2,
    question: {
      en: "Body positivity during puberty involves:",
      bn: "বয়ঃসন্ধিকালে শারীরিক ইতিবাচকতা বলতে কী বোঝায়?"
    },
    options: {
      en: [
        "Comparing physical changes to peers daily.",
        "Criticizing oneself until fitting traditional media standards.",
        "Accepting normal biological changes and appreciating body functionality and health.",
        "Ignoring physical hygiene completely."
      ],
      bn: [
        "প্রতিদিন বন্ধুদের সাথে নিজের শারীরিক পরিবর্তনের তুলনা করা।",
        "বিজ্ঞাপনের রূপের সাথে না মেলা পর্যন্ত নিজেকে ছোট ভাবা।",
        "স্বাভাবিক জৈবিক পরিবর্তন মেনে নেওয়া এবং শরীরের কার্যক্ষমতা ও স্বাস্থ্যের মূল্যায়ন করা।",
        "ব্যক্তিগত পরিচ্ছন্নতা সম্পূর্ণ উপেক্ষা করা।"
      ]
    },
    correctAnswerIndex: 2,
    explanation: {
      en: "Body positivity means understanding normal developmental growth during puberty and honoring body functional capabilities.",
      bn: "শারীরিক ইতিবাচকতা মানে রূপের চেয়ে শরীরের সুস্থতা ও শক্তির কদর করা।"
    }
  },
  {
    id: 6,
    chapterId: 2,
    question: {
      en: "How should an adolescent girl respond to negative peer comments about physical growth?",
      bn: "শারীরিক বৃদ্ধি নিয়ে বন্ধুদের নেতিবাচক মন্তব্যে কীভাবে প্রতিক্রিয়া জানানো উচিত?"
    },
    options: {
      en: [
        "Internalize the comments and try to hide physical growth.",
        "Reframe negative self-talk and affirm that growth occurs at an individual pace.",
        "Stop eating nutritious meals to limit physical growth.",
        "Isolate completely from social groups."
      ],
      bn: [
        "কথাগুলো মনে নিয়ে শরীরকে লুকিয়ে রাখার চেষ্টা করা।",
        "নেতিবাচক ভাবনা দূর করে মনে রাখা যে সবার বৃদ্ধি নিজস্ব স্বাভাবিক নিয়মে ঘটে।",
        "শারীরিক বৃদ্ধি থামাতে পুষ্টিকর খাবার খাওয়া বন্ধ করা।",
        "সবার থেকে নিজেকে সম্পূর্ণ আলাদা করে একাকী থাকা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Reframing self-talk and acknowledging individual growth paces counters body-shaming and protects self-esteem.",
      bn: "ইতিবাচক ভাবনা কটূক্তি প্রতিহত করে আত্মমর্যাদা রক্ষা করে।"
    }
  },

  // Chapter 3
  {
    id: 7,
    chapterId: 3,
    question: {
      en: "According to UNICEF's Comprehensive Life Skills Framework, individual empowerment begins with:",
      bn: "ইউনিসেফের জীবনশৈলী শিক্ষা নির্দেশিকা অনুযায়ী আসল ক্ষমতায়ন শুরু হয় কোথা থেকে?"
    },
    options: {
      en: [
        "Acquiring material wealth before age 15.",
        "Recognizing one's inherent worth and fundamental human equality.",
        "Complying with traditional gender roles without question.",
        "Achieving higher marks than all classmates."
      ],
      bn: [
        "১৫ বছর বয়সের আগেই প্রচুর ধনসম্পদ অর্জন করা।",
        "নিজের অন্তর্নিহিত মূল্য এবং মৌলিক মানবাধিকার ও সমতা উপলব্ধি করা।",
        "প্রশ্নহীনভাবে বাঁধাধরা লিঙ্গবৈষম্য মেনে চলা।",
        "ক্লাসের সবার চেয়ে সবসময় বেশি নম্বর পাওয়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Empowerment begins when an individual recognizes their inherent worth and equal rights regardless of gender or background.",
      bn: "ক্ষমতায়ন শুরু হয় যখন একজন মানুষ নিজের সম্মান ও সমমর্যাদা বুঝতে শেখে।"
    }
  },
  {
    id: 8,
    chapterId: 3,
    question: {
      en: "Affirming personal dignity helps an adolescent girl to:",
      bn: "ব্যক্তিগত আত্মমর্যাদা বজায় রাখা একজন কিশোরীকে কী করতে সাহায্য করে?"
    },
    options: {
      en: [
        "Accept lower investments in her health and schooling.",
        "Counter gender discrimination, build personal agency, and protect educational opportunities.",
        "Isolate herself from community life.",
        "Rely entirely on others to solve personal problems."
      ],
      bn: [
        "নিজের স্বাস্থ্য ও শিক্ষার পেছনে কম গুরুত্ব দেওয়াকে মেনে নেওয়া।",
        "লিঙ্গবৈষম্যের প্রতিবাদ করা, নিজের নিয়ন্ত্রণ বাড়ানো এবং শিক্ষার সুযোগ রক্ষা করা।",
        "সামাজিক জীবন থেকে দূরে থাকা।",
        "সমস্যা সমাধানের জন্য সম্পূর্ণ অন্যের ওপর নির্ভর করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Internalizing dignity enables girls to challenge gender discrimination and advocate for their basic human rights.",
      bn: "মর্যাদাবোধ অধিকারের জন্য লড়াই করার সাহস জোগায়।"
    }
  },
  {
    id: 9,
    chapterId: 3,
    question: {
      en: "Which practical step actively builds daily self-worth?",
      bn: "কোন কাজটি প্রতিদিনের আত্মমর্যাদা বৃদ্ধিতে সহায়ক?"
    },
    options: {
      en: [
        "Completing an interactive Dignity Checklist and practicing self-affirmations.",
        "Avoiding new tasks to prevent failure.",
        "Accepting unfair household treatment in silence.",
        "Focusing exclusively on pleasing others at personal expense."
      ],
      bn: [
        "মর্যাদার তালিকা মিলিয়ে দেখা এবং ইতিবাচক আত্মসংকল্প অনুশীলন করা।",
        "ব্যর্থতার ভয়ে নতুন কোনো কাজ না করা।",
        "পরিবারের অন্যায় আচরণ চুপচাপ সহ্য করা।",
        "নিজের ক্ষতি করে কেবল অন্যদের খুশি করার চেষ্টা করা।"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "Structured dignity checklists and positive affirmations reinforce self-worth and strengthen personal agency.",
      bn: "ইতিবাচক সংকল্প নিজের অন্তর্নিহিত বিশ্বাস দৃঢ় করে।"
    }
  },

  // Chapter 4
  {
    id: 10,
    chapterId: 4,
    question: {
      en: "Effective communication within life skills frameworks is defined as:",
      bn: "জীবনশৈলী শিক্ষায় কার্যকর যোগাযোগ বলতে কী বোঝায়?"
    },
    options: {
      en: [
        "Demanding immediate agreement by speaking louder than others.",
        "Exchanging information, opinions, desires, needs, and feelings clearly and respectfully.",
        "Remaining quiet when personal rights are ignored.",
        "Communicating exclusively through text messages."
      ],
      bn: [
        "চিৎকার করে অন্যদের বাধ্য করা।",
        "তথ্য, মতামত, প্রয়োজন ও অনুভূতি স্পষ্ট ও শ্রদ্ধার সাথে আদান-প্রদান করা।",
        "নিজের অধিকার লঙ্ঘিত হলেও চুপ করে থাকা।",
        "শুধুমাত্র টেক্সট মেসেজে কথা বলা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Communication involves exchanging information, thoughts, and emotions constructively across verbal and non-verbal modes.",
      bn: "সম্মানজনক ও স্পষ্ট মতবিনিময়ই যোগাযোগের মূল কথা।"
    }
  },
  {
    id: 11,
    chapterId: 4,
    question: {
      en: "Assertive communication differs from aggressive communication because assertiveness:",
      bn: "দৃঢ় যোগাযোগ আক্রমণাত্মক আচরণের থেকে আলাদা কারণ এটি:"
    },
    options: {
      en: [
        "Insults the listener to gain dominance.",
        "Respects both personal rights and the dignity of the listener.",
        "Concedes to all external demands passively.",
        "Avoids stating true personal desires."
      ],
      bn: [
        "অন্যকে অপমান করে নিজের ক্ষমতা দেখায়।",
        "নিজের অধিকার ও অপরের সম্মান উভয়কেই রক্ষা করে।",
        "সবার সব অন্যায় দাবি মেনে নেয়।",
        "নিজের ইচ্ছা কখনো প্রকাশ করে না।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Assertiveness clearly conveys personal needs while maintaining full respect for others.",
      bn: "দৃঢ় বক্তব্যের অর্থ হলো সম্মান দিয়ে নিজের দাবি তুলে ধরা।"
    }
  },
  {
    id: 12,
    chapterId: 4,
    question: {
      en: "Which non-verbal cue strengthens assertive speaking?",
      bn: "কোন শারীরিক অঙ্গভঙ্গিটি আত্মবিশ্বাসী কথা বলতে সাহায্য করে?"
    },
    options: {
      en: [
        "Looking at the ground and mumbling.",
        "Crossing arms tightly and turning away.",
        "Maintaining an upright posture, clear tone, and comfortable eye contact.",
        "Speaking as fast as possible without pausing."
      ],
      bn: [
        "মাটির দিকে তাকিয়ে অস্পষ্টভাবে বলা।",
        "হাত গুটিয়ে মুখ ফিরিয়ে নেওয়া।",
        "সোজা হয়ে দাঁড়ানো, স্পষ্ট গলার স্বর এবং চোখে চোখ রেখে কথা বলা।",
        "না থেমে খুব দ্রুত কথা বলা।"
      ]
    },
    correctAnswerIndex: 2,
    explanation: {
      en: "Upright posture, clear vocal tone, and steady eye contact project confidence and reinforce verbal clarity.",
      bn: "সোজা দাঁড়িয়ে শান্ত চোখে তাকালে কথার ওজন বাড়ে।"
    }
  },

  // Chapter 5
  {
    id: 13,
    chapterId: 5,
    question: {
      en: "Active listening requires which key behaviors?",
      bn: "সক্রিয়ভাবে শোনার প্রধান লক্ষণ কোনটি?"
    },
    options: {
      en: [
        "Formulating a counter-argument while the speaker is talking.",
        "Giving full attention, withholding judgment, and summarizing what was understood.",
        "Interrupting frequently to correct minor details.",
        "Agreeing with every statement without reflection."
      ],
      bn: [
        "অন্যের কথা চলাকালেই মনে মনে জবাব তৈরি করা।",
        "পূর্ণ মনোযোগ দেওয়া, বিচার না করা এবং কথাটি গুছিয়ে পুনরাবৃত্তি করা।",
        "ছোটখাটো ভুলে বারবার মাঝপথে কথা কেটে দেওয়া।",
        "না ভেবেই সব কথায় অন্ধভাবে সায় দেওয়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Active listening requires undivided attention, empathetic focus, reflection, and withholding quick judgment.",
      bn: "মন দিয়ে শোনার অর্থ হলো বিচার না করে বুঝতে চেষ্টা করা।"
    }
  },
  {
    id: 14,
    chapterId: 5,
    question: {
      en: "Respecting diversity in peer groups is essential because it:",
      bn: "দলে বৈচিত্র্যকে সম্মান দেওয়া কেন জরুরি?"
    },
    options: {
      en: [
        "Allows one dominant group to set all rules.",
        "Fosters empathy, social cohesion, and peaceful conflict resolution across communities.",
        "Eliminates the need for group discussion.",
        "Standardizes all personal beliefs into one single viewpoint."
      ],
      bn: [
        "একটি বিশেষ দলকে সব নিয়ম ঠিক করতে দেয়।",
        "সহমর্মিতা, সামাজিক ঐক্য ও শান্তিপূর্ণ সমাধান তৈরি করে।",
        "আলোচনা করার প্রয়োজনীয়তা শেষ করে দেয়।",
        "সবার মতামতকে জোর করে এক রকম করে ফেলে।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Respecting diversity builds empathy and enables individuals from varied backgrounds to collaborate effectively.",
      bn: "বৈচিত্র্যের প্রতি শ্রদ্ধা সমাজকে একতাবদ্ধ করে।"
    }
  },
  {
    id: 15,
    chapterId: 5,
    question: {
      en: "When a peer from a different social background shares an opinion, an empathetic active listener should:",
      bn: "ভিন্ন পটভূমির একজন বন্ধু মতামত দিলে কী করা উচিত?"
    },
    options: {
      en: [
        "Interrupt to change the topic to a familiar subject.",
        "Focus attentively, validate their perspective, and avoid pre-judging.",
        "Ignore the statement until someone else speaks.",
        "Correct their accent publicly."
      ],
      bn: [
        "কথা থামিয়ে দিয়ে পরিচিত বিষয়ে চলে যাওয়া।",
        "মন দিয়ে শোনা, তার দৃষ্টিভঙ্গিকে মূল্যায়ন করা এবং আগেভাগে বিচার না করা।",
        "তার কথা সম্পূর্ণ উপেক্ষা করা।",
        "সবার সামনে তার উচ্চারণের ভুল ধরা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Empathetic active listening validates others and creates an inclusive space for all voices.",
      bn: "মন দিয়ে শুনলে সবাই নিজেকে সম্মানিত মনে করে।"
    }
  },

  // Chapter 6
  {
    id: 16,
    chapterId: 6,
    question: {
      en: "What is a primary benefit of participating in structured peer groups for adolescent girls?",
      bn: "কিশোরী সভায় সক্রিয় অংশগ্রহণের প্রধান সুফল কী?"
    },
    options: {
      en: [
        "It removes individual accountability for personal choices.",
        "It builds social capital, collective strength, and shared problem-solving capabilities.",
        "It ensures that only the dominant member makes decisions.",
        "It reduces personal creativity."
      ],
      bn: [
        "ব্যক্তিগত সিদ্ধান্তের দায় অন্যের ওপর চাপানো যায়।",
        "সামাজিক বন্ধন, যৌথ শক্তি এবং দলগত সমস্যা সমাধানের ক্ষমতা বাড়ে।",
        "শুধুমাত্র প্রভাবশালী ব্যক্তি সিদ্ধান্ত নেওয়ার সুযোগ পায়।",
        "সবার সৃজনশীলতা কমে যায়।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Group participation creates social support networks, enabling girls to pool skills and advocate collectively.",
      bn: "দলগত কাজ একতাবদ্ধ শক্তির জন্ম দেয়।"
    }
  },
  {
    id: 17,
    chapterId: 6,
    question: {
      en: "In effective teamwork dynamics, the role of a 'Mediator' focuses on:",
      bn: "দলের মধ্যে 'মধ্যস্থতাকারী'-র প্রধান দায়িত্ব কী?"
    },
    options: {
      en: [
        "Doing all the work independently.",
        "Helping team members resolve disagreements fairly and maintain collaboration.",
        "Directing others without listening to input.",
        "Observing group activities without participating."
      ],
      bn: [
        "সব কাজ একা একা করা।",
        "মতবিরোধ মিটিয়ে দলের সবাইকে একসাথে কাজ করতে সাহায্য করা।",
        "কারও কথা না শুনে একনায়কত্ব চালানো।",
        "কোনো কাজ না করে শুধু তাকিয়ে দেখা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "A mediator facilitates conflict resolution, keeping the team aligned toward shared goals.",
      bn: "মধ্যস্থতাকারী দলের ঐক্য বজায় রাখে।"
    }
  },
  {
    id: 18,
    chapterId: 6,
    question: {
      en: "High-performing teams maintain effective collaboration by:",
      bn: "একটি সফল দল কীভাবে কাজ চালিয়ে যায়?"
    },
    options: {
      en: [
        "Allowing one member to perform all tasks silently.",
        "Establishing shared ground rules, respecting diverse contributions, and distributing tasks fairly.",
        "Excluding members who express differing opinions.",
        "Avoiding structured planning entirely."
      ],
      bn: [
        "একজন সদস্যের ওপর সব কাজ চাপিয়ে দিয়ে।",
        "নির্দিষ্ট নিয়ম তৈরি করে, সবার মতামতকে শ্রদ্ধা জানিয়ে এবং সমানভাবে কাজ ভাগ করে।",
        "ভিন্ন মত পোষণকারীকে দল থেকে বাদ দিয়ে।",
        "কোনো রকম পরিকল্পনা না করে।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Clear ground rules, equitable task distribution, and mutual respect maintain productive team dynamics.",
      bn: "কাজের ন্যায্য বণ্টন এবং পারস্পরিক শ্রদ্ধা দলকে সফল করে।"
    }
  },

  // Chapter 7
  {
    id: 19,
    chapterId: 7,
    question: {
      en: "Personal boundaries are best defined as:",
      bn: "ব্যক্তিগত সীমানা বলতে কী বোঝায়?"
    },
    options: {
      en: [
        "Rigid rules imposed by others to restrict personal choices.",
        "Clear limits established to protect physical space, emotional well-being, and personal privacy.",
        "Social barriers designed to prevent making new friends.",
        "Physical fences built around educational institutions."
      ],
      bn: [
        "অন্যদের চাপিয়ে দেওয়া নিয়ম যা স্বাধীনতা কেড়ে নেয়।",
        "নিজের শরীর, মানসিক শান্তি ও গোপনীয়তা রক্ষার সুস্পষ্ট সীমা।",
        "নতুন বন্ধু বানাতে বাধা দেওয়া সামাজিক দেওয়াল।",
        "স্কুলের চারপাশের কাঁটাতারের বেড়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Personal boundaries define healthy limits regarding how others interact with one's physical body and privacy.",
      bn: "ব্যক্তিগত সীমানা নিজের শরীর ও স্বাস্থ্যের সুরক্ষা নিশ্চিত করে।"
    }
  },
  {
    id: 20,
    chapterId: 7,
    question: {
      en: "When someone crosses a boundary and causes discomfort, the most appropriate immediate action is to:",
      bn: "কেউ অস্বস্তিকরভাবে সীমানা লঙ্ঘন করলে সাথে সাথে কী করা উচিত?"
    },
    options: {
      en: [
        "Apologize for feeling uncomfortable and stay silent.",
        "State the boundary clearly, firmly, and direct the person to stop.",
        "Assume personal instincts are wrong and ignore the feeling.",
        "Violate the other person's boundaries in retaliation."
      ],
      bn: [
        "চুপ থাকা এবং নিজের অস্বস্তির জন্য ক্ষমা চাওয়া।",
        "পরিষ্কার ও দৃঢ় গলায় নিজের আপত্তি জানিয়ে তাকে থামতে বলা।",
        "নিজের অনুভূতি ভুল ভেবে চুপ করে সহ্য করা।",
        "পাল্টা একই আচরণ করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Assertively stating boundaries and directing the individual to cease protects bodily autonomy and safety.",
      bn: "স্পষ্ট ও দৃঢ়ভাবে আপত্তি জানানো নিজের নিরাপত্তা রক্ষা করে।"
    }
  },
  {
    id: 21,
    chapterId: 7,
    question: {
      en: "Saying 'No' to an uncomfortable physical situation or intrusion is:",
      bn: "অস্বস্তিকর পরিস্থিতিতে 'না' বলা কী ধরনের পদক্ষেপ?"
    },
    options: {
      en: [
        "Always a disrespect to elders.",
        "A healthy, valid exercise of personal safety and bodily autonomy rights.",
        "Actionable only with prior written permission.",
        "An aggressive act that should be avoided."
      ],
      bn: [
        "বড়দের প্রতি চরম অসম্মান।",
        "শারীরিক নিরাপত্তা ও স্বাধীনতার সম্পূর্ণ বৈধ ও স্বাভাবিক অধিকার।",
        "লিখিত অনুমতি ছাড়া করা নিষেধ।",
        "একটি খারাপ আক্রমণাত্মক আচরণ।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Refusing uncomfortable physical contact or privacy intrusions is a fundamental legal and personal right.",
      bn: "'না' বলা তোমার মৌলিক শারীরিক অধিকার।"
    }
  },

  // Chapter 8
  {
    id: 22,
    chapterId: 8,
    question: {
      en: "Adolescents frequently experience heightened emotional intensity due to:",
      bn: "বয়ঃসন্ধিকালে তীব্র আবেগ বা মেজাজের ওঠানামা কেন দেখা যায়?"
    },
    options: {
      en: [
        "Permanent personality flaws.",
        "Rapid biological, cognitive, and psychosocial transitions during developmental growth.",
        "Poor academic intelligence.",
        "Dietary choices exclusively."
      ],
      bn: [
        "স্থায়ী চরিত্রের দোষের কারণে।",
        "হরমোন ও মানসিক বিকাশের দ্রুত পরিবর্তনের কারণে।",
        "কম বুদ্ধিমত্তার কারণে।",
        "শুধুমাত্র খাবারের পছন্দের কারণে।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "WHO guidelines confirm that rapid developmental transitions in adolescence naturally increase emotional intensity.",
      bn: "বয়ঃসন্ধিকালে হরমোনের প্রাকৃতিক পরিবর্তনের জন্য তীব্র আবেগ আসা স্বাভাবিক।"
    }
  },
  {
    id: 23,
    chapterId: 8,
    question: {
      en: "Which response represents a negative coping strategy for managing intense grief or anger?",
      bn: "তীব্র রাগ সামলাতে কোনটি ক্ষতিকর পন্থা?"
    },
    options: {
      en: [
        "Taking deep belly breaths and pausing before speaking.",
        "Lashing out verbally at family members and isolating oneself completely.",
        "Writing about emotional triggers in a private journal.",
        "Discussing feelings with a trusted mentor."
      ],
      bn: [
        "গভীর শ্বাস নেওয়া এবং কথা বলার আগে থামা।",
        "পরিবারের ওপর চিৎকার-ভাঙচুর করা এবং নিজেকে পুরোপুরি বন্দি করা।",
        "ডায়েরিতে অনুভূতির কথা লেখা।",
        "বিশ্বস্ত মানুষের সাথে আলোচনা করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Aggressive outbursts and total social isolation are destructive coping mechanisms that compound distress.",
      bn: "ভাঙচুর ও রাগারাগি পরিস্থিতিকে আরও খারাপ করে।"
    }
  },
  {
    id: 24,
    chapterId: 8,
    question: {
      en: "What is the critical first step in the recommended 4-step emotional calming sequence?",
      bn: "মন শান্ত করার ৪টি ধাপের প্রথম পদক্ষেপ কোনটি?"
    },
    options: {
      en: [
        "Reacting immediately to release tension.",
        "Pausing physical movement immediately.",
        "Explaining to everyone why your reaction is justified.",
        "Suppressing the emotion permanently."
      ],
      bn: [
        "সাথে সাথে কিছু ভেঙে উত্তেজনা কমানো।",
        "শারীরিক নড়াচড়া তৎক্ষণাৎ থামিয়ে দেওয়া (Pause)।",
        "সবার সাথে নিজের রাগের সাফাই গাওয়া।",
        "চিরতরে অনুভূতি চেপে রাখা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Pausing creates a necessary gap between feeling an emotional impulse and taking constructive action.",
      bn: "থামলে রাগের মাথায় কোনো ভুল পদক্ষেপ নেওয়া আটকানো যায়।"
    }
  },

  // Chapter 9
  {
    id: 25,
    chapterId: 9,
    question: {
      en: "What distinguishes positive coping strategies from negative coping mechanisms?",
      bn: "ইতিবাচক ও নেতিবাচক চাপ মোকাবিলার মধ্যে মূল পার্থক্য কী?"
    },
    options: {
      en: [
        "Positive strategies resolve stress immediately by abandoning all responsibilities.",
        "Positive strategies manage pressure constructively through support and planning without causing long-term harm.",
        "Negative strategies build permanent emotional resilience.",
        "Positive strategies are effective only for adults."
      ],
      bn: [
        "ইতিবাচক কৌশল সব দায়িত্ব ত্যাগ করে চাপ কমায়।",
        "ইতিবাচক কৌশল পরিকল্পনা ও সাহায্যের মাধ্যমে ক্ষতি ছাড়া সমাধান আনে।",
        "নেতিবাচক কৌশল মানুষকে শক্তিশালী করে।",
        "ইতিবাচক কৌশল কেবল বড়দের জন্য।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Positive coping utilizes structured planning, support-seeking, and rest to navigate pressure without self-harm.",
      bn: "পরিকল্পনা ও বিশ্রাম নিয়ে চাপ কমানোই ইতিবাচক পদ্ধতি।"
    }
  },
  {
    id: 26,
    chapterId: 9,
    question: {
      en: "When feeling overwhelmed by academic expectations and domestic demands, an adolescent should:",
      bn: "পড়ালেখা ও ঘরের কাজের চাপে দিশেহারা হলে কী করা উচিত?"
    },
    options: {
      en: [
        "Drop out of school immediately to end expectations.",
        "Isolate completely and refuse to speak to anyone.",
        "Break tasks into smaller steps, structure daily routines, and seek help from adult allies.",
        "Suppress stress until physical breakdown occurs."
      ],
      bn: [
        "স্কুল ছেড়ে দেওয়া।",
        "কারও সাথে কথা না বলে একা ঘরে থাকা।",
        "কাজ ছোট ছোট ধাপে ভাগ করা, রুটিন তৈরি করা এবং বড়দের সাহায্য নেওয়া।",
        "অসুস্থ না হওয়া পর্যন্ত কষ্ট চেপে রাখা।"
      ]
    },
    correctAnswerIndex: 2,
    explanation: {
      en: "Segmenting tasks, organizing daily time, and seeking social support effectively reduce stress levels.",
      bn: "কাজ ভাগ করে রুটিনমাফিক করলে পড়ার চাপ কমে যায়।"
    }
  },
  {
    id: 27,
    chapterId: 9,
    question: {
      en: "Which habit represents a healthy daily stress-busting routine?",
      bn: "প্রতিদিনের মানসিক চাপ কমাতে কোন অভ্যাসটি সবচেয়ে ভালো?"
    },
    options: {
      en: [
        "Maintaining regular physical activity, structured study blocks, and consistent sleep.",
        "Eliminating sleep entirely to study continuously.",
        "Consuming excess caffeine or harmful substances to stay awake.",
        "Avoiding all social contact permanently."
      ],
      bn: [
        "নিয়মিত শরীরচর্চা, সময় ভাগ করে পড়া এবং পর্যাপ্ত ঘুম।",
        "না ঘুমিয়ে সারারাত পড়া।",
        "জেগে থাকার জন্য অতিরিক্ত চা বা ক্ষতিকর পানীয় খাওয়া।",
        "সবার সাথে মেলামেশা বন্ধ করা।"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "Physical activity, structured rest, and social connection are empirically proven stress reducers.",
      bn: "শরীরচর্চা ও পর্যাপ্ত ঘুম মন ও মস্তিষ্ককে সতেজ রাখে।"
    }
  },

  // Chapter 10
  {
    id: 28,
    chapterId: 10,
    question: {
      en: "UNICEF India defines resilience as:",
      bn: "ইউনিসেফ ইন্ডিয়া অনুযায়ী সহনশীলতা (Resilience) কী?"
    },
    options: {
      en: [
        "Avoiding all difficult life circumstances entirely.",
        "The psychosocial ability to cope with calamity or disruption and return to a stable state of health and agency.",
        "Suppressing all emotional expressions during a crisis.",
        "Relying entirely on external relief without personal engagement."
      ],
      bn: [
        "কঠিন পরিস্থিতি পুরোপুরি এড়িয়ে চলা।",
        "বিপদ ও সংকট কাটিয়ে আবার সুস্থ স্বাভাবিক জীবনে ফিরে আসার মানসিক ক্ষমতা।",
        "বিপদের সময় সব কান্না ও অনুভূতি আটকে রাখা।",
        "নিজে কোনো চেষ্টা না করে শুধু অন্যের ত্রাণের অপেক্ষায় থাকা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Resilience is defined as the capacity to recover from adversity, calamity, or major life disruptions and regain personal agency.",
      bn: "সহনশীলতা হলো বিপর্যয়ের মুখেও নিজের চেষ্টায় আবার দাঁড়ানোর শক্তি।"
    }
  },
  {
    id: 29,
    chapterId: 10,
    question: {
      en: "Psychological resilience is best understood as:",
      bn: "মানসিক সহনশীলতা সম্পর্কে কোনটি সত্য?"
    },
    options: {
      en: [
        "An unchangeable genetic trait that individuals either possess or lack.",
        "A dynamic competency developed through adaptive coping skills, problem-solving, and social support networks.",
        "A temporary child emotion that disappears in adulthood.",
        "A skill required only during natural disasters."
      ],
      bn: [
        "একটি জন্মগত গুণ যা সবার থাকে না।",
        "একটি শেখার মতো দক্ষতা যা নিয়মিত চর্চা ও সাহায্যের মাধ্যমে বাড়ানো যায়।",
        "ছোটদের একটি সাময়িক আবেগ যা বড় হলে থাকে না।",
        "শুধুমাত্র প্রাকৃতিক দুর্যোগের সময় দরকারি।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Resilience is a malleable life skill strengthened over time through practice, emotional regulation, and community connection.",
      bn: "সহনশীলতা একটি দক্ষতা যা অনুশীলনের মাধ্যমে যে কেউ অর্জন করতে পারে।"
    }
  },
  {
    id: 30,
    chapterId: 10,
    question: {
      en: "Which cognitive mindset shift directly fosters psychological resilience during adversity?",
      bn: "কঠিন সময়ে কোন মানসিকতা সহনশীলতা তৈরি করে?"
    },
    options: {
      en: [
        "Viewing temporary setbacks as permanent personal failures.",
        "Reframing challenges as temporary obstacles that offer learning and growth opportunities.",
        "Refusing support from community networks.",
        "Blaming peers for external crisis events."
      ],
      bn: [
        "সাময়িক সমস্যাকে চিরস্থায়ী ব্যর্থতা ভাবা।",
        "বিপদকে সাময়িক বাধা হিসেবে দেখা যা থেকে নতুন শিক্ষা নেওয়া সম্ভব।",
        "কারও কাছ থেকে কোনো সাহায্য না নেওয়া।",
        "অন্যদের ওপর দোষ চাপিয়ে দেওয়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Reframing obstacles as temporary and manageable fosters adaptive problem-solving and emotional recovery.",
      bn: "'এই সময় কেটে যাবে এবং আমি নতুন করে শুরু করব'—এই মনোভাবই জয় আনে।"
    }
  },

  // Chapter 11
  {
    id: 31,
    chapterId: 11,
    question: {
      en: "Critical thinking is defined within life skills frameworks as the ability to:",
      bn: "জীবনশৈলীতে গঠনমূলক চিন্তাভাবনা (Critical Thinking) কী?"
    },
    options: {
      en: [
        "Accept traditional social opinions without verification.",
        "Appropriately analyze information objectively to arrive at a reasoned judgment.",
        "Reject all peer advice automatically.",
        "Memorize textbooks quickly for exams."
      ],
      bn: [
        "যাচাই না করে প্রচলিত সব কথা মেনে নেওয়া।",
        "তথ্য নিরপেক্ষভাবে বিশ্লেষণ করে সঠিক সিদ্ধান্তে পৌঁছানোর ক্ষমতা।",
        "সবার সব উপদেশ চোখ বন্ধ করে বাতিল করা।",
        "পরীক্ষার জন্য বই মুখস্থ করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Critical thinking involves objectively gathering, examining, and evaluating information to reach balanced, evidence-based judgments.",
      bn: "তথ্য যাচাই করে যুক্তি দিয়ে সিদ্ধান্ত নেওয়াই গঠনমূলক চিন্তা।"
    }
  },
  {
    id: 32,
    chapterId: 11,
    question: {
      en: "According to national survey data (ASER), what happens to school enrolment between ages 14 and 18 in rural India?",
      bn: "জাতীয় শিক্ষা সমীক্ষা (ASER) অনুযায়ী ১৪ থেকে ১৮ বছর বয়সে ভারতে মেয়েদের স্কুলে কী ঘটে?"
    },
    options: {
      en: [
        "Enrolment increases to 100%.",
        "Non-enrolment climbs from 5% at age 14 to 30% by age 18, disproportionately affecting females.",
        "All adolescents enter formal university education.",
        "Male non-enrolment becomes 80% higher than female non-enrolment."
      ],
      bn: [
        "ভর্তির হার ১০০% হয়ে যায়।",
        "স্কুল ছাড়ার হার ৫% থেকে বেড়ে ১৮ বছর বয়সে ৩০% হয়ে যায়, যার শিকার মূলত মেয়েরা।",
        "সবাই কলেজে ভর্তি হয়।",
        "ছেলেদের স্কুল ছাড়ার হার মেয়েদের চেয়ে বহুগুণ বাড়ে।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "ASER data confirms that out-of-school rates rise sharply from 5% at age 14 to 30% at age 18 (32% for females), highlighting the critical need for decision-making skills.",
      bn: "ASER তথ্য অনুযায়ী বয়ঃসন্ধিকালে বহু মেয়ে স্কুল ছেড়ে দেয়, তাই পড়াশোনা ধরে রাখার সিদ্ধান্ত খুব জরুরি।"
    }
  },
  {
    id: 33,
    chapterId: 11,
    question: {
      en: "When evaluating advice regarding leaving school early, critical thinking enables an adolescent girl to:",
      bn: "পড়ালেখা ছাড়ার ব্যাপারে আত্মীয়দের কথায় গঠনমূলক চিন্তা একজন মেয়েকে কী সাহায্য করে?"
    },
    options: {
      en: [
        "Choose whichever option requires the least immediate physical effort.",
        "Identify underlying gender biases and evaluate long-term impacts on her rights and economic security.",
        "Follow the advice of whichever relative speaks loudest.",
        "Avoid making any decision."
      ],
      bn: [
        "যেটিতে কম খাটনি হয় সেটি বেছে নেওয়া।",
        "লুকিয়ে থাকা লিঙ্গবৈষম্য চেনা এবং নিজের স্বাধীনতা ও আয়ের ওপর ভবিষ্যৎ প্রভাব মূল্যায়ন করা।",
        "যে সবচেয়ে জোরে কথা বলে তার কথা শোনা।",
        "কোনো সিদ্ধান্ত না নেওয়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Critical thinking exposes gender stereotypes and allows girls to evaluate choices based on long-term health, education, and legal rights.",
      bn: "কুসংস্কার চিনে ভবিষ্যতের স্বাবলম্বী হওয়ার সুযোগ রক্ষা করা।"
    }
  },

  // Chapter 12
  {
    id: 34,
    chapterId: 12,
    question: {
      en: "In the SMART goal framework, what does the acronym 'SMART' stand for?",
      bn: "SMART লক্ষ্য নির্ধারণের সূত্রে প্রতিটি অক্ষরের অর্থ কী?"
    },
    options: {
      en: [
        "Simple, Meaningful, Actionable, Relevant, Timely.",
        "Specific, Measurable, Achievable, Relevant, Time-bound.",
        "Strict, Mandatory, Academic, Rigid, Tough.",
        "Social, Moral, Artistic, Rational, Technical."
      ],
      bn: [
        "সহজ, অর্থপূর্ণ, কাজের, প্রাসঙ্গিক, সঠিক সময়ের।",
        "নির্দিষ্ট (Specific), পরিমাপযোগ্য (Measurable), অর্জনযোগ্য (Achievable), প্রাসঙ্গিক (Relevant), সময়াবদ্ধ (Time-bound)।",
        "কঠোর, বাধ্যতামূলক, পড়ালেখার, অনমনীয়, কঠিন।",
        "সামাজিক, নৈতিক, শিল্পকলার, যুক্তিবাদী, প্রযুক্তিগত।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "SMART stands for Specific, Measurable, Achievable, Relevant, and Time-bound.",
      bn: "SMART মানে হলো নিখুঁত, পরিমাপযোগ্য ও সময়সীমাযুক্ত বাস্তবসম্মত পরিকল্পনা।"
    }
  },
  {
    id: 35,
    chapterId: 12,
    question: {
      en: "Why is structured goal setting particularly vital for adolescent girls in rural contexts?",
      bn: "গ্রামাঞ্চলের কিশোরীদের জন্য সুনির্দিষ্ট লক্ষ্য নির্ধারণ কেন বিশেষ জরুরি?"
    },
    options: {
      en: [
        "It guarantees immediate government employment without training.",
        "It helps overcome gender-stereotyped occupational limits and maps concrete steps toward economic independence.",
        "It restricts personal ambitions to traditional domestic duties exclusively.",
        "It eliminates the need for daily educational effort."
      ],
      bn: [
        "এটি বিনা পরিশ্রমে সরকারি চাকরি দেয়।",
        "এটি মেয়েদের সংকীর্ণ কাজ থেকে বের করে স্বাবলম্বী হওয়ার বাস্তব পথ তৈরি করে।",
        "এটি ঘরের কাজের বাইরে যেতে নিষেধ করে।",
        "এটি পড়াশোনা করার প্রয়োজন কমিয়ে দেয়।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Structured goal setting provides actionable steps that empower girls to challenge restrictive gender stereotypes and achieve economic agency.",
      bn: "লক্ষ্য নির্ধারণ মেয়েদের অর্থনৈতিক স্বনির্ভরতা দেয়।"
    }
  },
  {
    id: 36,
    chapterId: 12,
    question: {
      en: "To turn a broad long-term career ambition into achievable reality, an adolescent should:",
      bn: "বড় স্বপ্নকে বাস্তবে রূপ দিতে একজন কিশোরীর কী করা উচিত?"
    },
    options: {
      en: [
        "Wait until secondary education is entirely complete before planning.",
        "Break the long-term goal down into specific, time-bound weekly and monthly milestones.",
        "Keep goals completely secret to avoid social feedback.",
        "Change career aspirations every week."
      ],
      bn: [
        "পড়াশোনা শেষ হওয়া পর্যন্ত কোনো পরিকল্পনা না করে বসে থাকা।",
        "বড় লক্ষ্যকে ছোট ছোট সাপ্তাহিক ও মাসিক মাইলফলকে ভাগ করে এগোতে থাকা।",
        "লক্ষ্য কাউকে না বলা।",
        "প্রতি সপ্তাহে ইচ্ছা বদলে ফেলা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Segmenting broad ambitions into measurable milestones ensures consistent progress and resource mobilization.",
      bn: "ছোট ছোট ধাপে এগোলে বড় সাফল্য লাভ সম্ভব।"
    }
  },

  // Chapter 13
  {
    id: 37,
    chapterId: 13,
    question: {
      en: "Within life skills frameworks, negotiation is defined as:",
      bn: "জীবনশৈলীতে আলোচনা বা দরকষাকষি (Negotiation) কী?"
    },
    options: {
      en: [
        "Forcing compliance through physical or verbal aggression.",
        "The ability to reach an agreement with others using logic, reason, and empathetic persuasion.",
        "Yielding personal rights silently to avoid conflict.",
        "Tricking others into temporary agreements."
      ],
      bn: [
        "জোর জবরদস্তি করে নিজের কথা মানানো।",
        "যুক্তি ও সহমর্মিতার সাহায্যে অপরের সাথে বোঝাপড়ায় পৌঁছানোর দক্ষতা।",
        "ঝগড়া এড়াতে নিজের অধিকার নিঃশব্দে ছেড়ে দেওয়া।",
        "মিথ্যা বলে সাময়িক কাজ হাসিল করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Negotiation relies on logic, factual reasoning, and empathetic communication to achieve constructive agreements.",
      bn: "যুক্তি ও বুদ্ধি দিয়ে আলোচনা করাই সমঝোতার ভিত্তি।"
    }
  },
  {
    id: 38,
    chapterId: 13,
    question: {
      en: "How does mastering negotiation skills empower an adolescent girl within her family?",
      bn: "আলোচনার দক্ষতা কীভাবে একজন মেয়েকে পরিবারে শক্তিশালী করে?"
    },
    options: {
      en: [
        "It allows her to advocate for continued schooling and delayed marriage through logical dialogue and allies.",
        "It guarantees she will never experience family disagreements.",
        "It forces parents to stop making any household decisions.",
        "It enables her to ignore all domestic responsibilities completely."
      ],
      bn: [
        "যুক্তি ও শিক্ষক/মেন্টরদের সাহায্যে পড়াশোনা চালিয়ে যাওয়ার ও বিয়ে পেছানোর কথা বোঝানো যায়।",
        "পরিবারে কখনো কোনো বিষয়ে দ্বিমত হয় না।",
        "অভিভাবকদের সব সিদ্ধান্ত নেওয়া বন্ধ করে দেয়।",
        "কোনো কাজ না করার অজুহাত দেয়।"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "Negotiation skills enable girls to articulate the value of education and delayed marriage logically to family decision-makers.",
      bn: "যুক্তি দিয়ে কথা বললে পরিবার শিক্ষার গুরুত্ব বুঝতে পারে।"
    }
  },
  {
    id: 39,
    chapterId: 13,
    question: {
      en: "When practicing assertive refusal ('Saying No') to risky or illegal demands, an adolescent should:",
      bn: "ক্ষতিকর বা বেআইনি প্রস্তাবে 'না' বলার সঠিক নিয়ম কী?"
    },
    options: {
      en: [
        "Offer lengthy excuses and apologize repeatedly.",
        "State a firm, direct refusal backed by personal reasons, remaining calm and resolute.",
        "Agree initially and break the promise later.",
        "Respond with immediate physical aggression."
      ],
      bn: [
        "বারবার ক্ষমা চাওয়া ও অজুহাত দেওয়া।",
        "শান্ত অথচ দৃঢ় গলায় সরাসরি 'না' বলা এবং নিজের সিদ্ধান্তে অটল থাকা।",
        "মুখে হ্যাঁ বলে পরে না করা।",
        "মারপিট করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Assertive refusal is clear, direct, respectful, and firm, protecting safety and personal autonomy.",
      bn: "শান্ত ও দৃঢ় 'না' নিজের নিরাপত্তা ও স্বাধীনতা রক্ষা করে।"
    }
  },

  // Chapter 14
  {
    id: 40,
    chapterId: 14,
    question: {
      en: "According to WHO adolescent health guidelines, puberty is best defined as:",
      bn: "বিশ্ব স্বাস্থ্য সংস্থা অনুযায়ী বয়ঃসন্ধি (Puberty) কী?"
    },
    options: {
      en: [
        "A rare physical illness requiring pharmacological intervention.",
        "A natural biological transition of rapid physical maturation and hormonal changes between childhood and adulthood.",
        "A biological transition that occurs exclusively in males.",
        "An artificial shift caused entirely by environmental pollution."
      ],
      bn: [
        "একটি রোগ যার জন্য ওষুধ খাওয়া প্রয়োজন।",
        "শৈশব থেকে প্রাপ্তবয়স্ক হওয়ার প্রাকৃতিক জৈবিক ও হরমোনের পরিবর্তনের পর্ব।",
        "কেবলমাত্র ছেলেদের ঘটে এমন একটি বিষয়।",
        "পরিবেশ দূষণের কারণে সৃষ্ট একটি কৃত্রিম সমস্যা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "WHO defines puberty as a universal biological growth phase driven by hormones during adolescence (ages 10–19).",
      bn: "বয়ঃসন্ধি হলো হরমোন দ্বারা পরিচালিত জীবনের স্বাভাবিক বৃদ্ধির ধাপ।"
    }
  },
  {
    id: 41,
    chapterId: 14,
    question: {
      en: "For early adolescents aged 10–14, global health frameworks identify primary health risks as overwhelmingly tied to:",
      bn: "১০ থেকে ১৪ বছর বয়সীদের প্রধান স্বাস্থ্যঝুঁকি কোনটির সাথে জড়িত?"
    },
    options: {
      en: [
        "Alcohol consumption and driving accidents.",
        "Water, sanitation, and hygiene (WASH) deficiencies and pubertal health gaps.",
        "Occupational workplace injuries in formal factories.",
        "Severe age-related bone density loss."
      ],
      bn: [
        "গাড়ি দুর্ঘটনা।",
        "পরিষ্কার জল, স্যানিটেশন ও স্বাস্থ্যবিধির (WASH) ঘাটতি এবং বয়ঃসন্ধিকালীন যত্নের অভাব।",
        "কারখানায় কাজের আঘাত।",
        "বয়সজনিত হাড়ের ক্ষয়।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "WHO data confirms that health risks for 10–14-year-olds center on WASH factors and pubertal adjustments.",
      bn: "এই বয়সে পরিচ্ছন্নতা ও পরিষ্কার জল ব্যবহার সবচেয়ে গুরুত্বপূর্ণ।"
    }
  },
  {
    id: 42,
    chapterId: 14,
    question: {
      en: "How does scientific understanding of pubertal development benefit adolescent mental well-being?",
      bn: "বয়ঃসন্ধির বৈজ্ঞানিক তথ্য জানা কীভাবে মানসিক শান্তি দেয়?"
    },
    options: {
      en: [
        "It allows adolescents to stop physical growth entirely.",
        "It eliminates shame and fear by framing biological changes as normal, healthy development.",
        "It guarantees immunity from all infectious diseases.",
        "It removes the necessity for daily personal hygiene."
      ],
      bn: [
        "এটি শরীরের বৃদ্ধি আটকে দেয়।",
        "লজ্জা ও ভয় দূর করে পরিবর্তনকে স্বাভাবিক বিকাশ হিসেবে গ্রহণ করতে শেখায়।",
        "সব রোগ থেকে সম্পূর্ণ মুক্তি দেয়।",
        "পরিচ্ছন্ন থাকার প্রয়োজন শেষ করে।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Understanding puberty demystifies physical shifts, replacing embarrassment with healthy bodily care and self-esteem.",
      bn: "সঠিক জ্ঞান লজ্জা দূর করে আত্মবিশ্বাস বাড়ায়।"
    }
  },

  // Chapter 15
  {
    id: 43,
    chapterId: 15,
    question: {
      en: "Biological menstruation is correctly defined as:",
      bn: "মাসিক বা ঋতুস্রাবের সঠিক বৈজ্ঞানিক সংজ্ঞা কোনটি?"
    },
    options: {
      en: [
        "An internal infection caused by unhygienic food.",
        "The natural monthly shedding of the uterine lining in healthy females.",
        "A sign of physical impurity or bad luck.",
        "A temporary digestive dysfunction."
      ],
      bn: [
        "খারাপ খাবারের কারণে পেটের ভেতরে হওয়া সংক্রমণ।",
        "সুস্থ নারীদের জরায়ুর আস্তরণ প্রতি মাসে স্বাভাবিক নিয়মে ভেঙে বেরিয়ে আসা।",
        "অপবিত্রতা বা দুর্ভাগ্যের লক্ষণ।",
        "হজমের একটি সাময়িক গোলমাল।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Menstruation is a healthy biological process wherein the body sheds the uterine lining monthly.",
      bn: "মাসিক একটি স্বাভাবিক শারীরবৃত্তীয় প্রক্রিয়া, যা সুস্থতার লক্ষণ।"
    }
  },
  {
    id: 44,
    chapterId: 15,
    question: {
      en: "Which practice is essential for safe menstrual hygiene management?",
      bn: "মাসিক চলাকালীন কোন অভ্যাসটি অপরিহার্য?"
    },
    options: {
      en: [
        "Changing sanitary pads or clean cloths every 4–6 hours and washing with clean water.",
        "Reusing damp cloths stored in dark, unventilated spaces.",
        "Refraining from bathing for the entire duration of the menstrual period.",
        "Restricting fluid intake completely during menstruation."
      ],
      bn: [
        "প্রতি ৪–৬ ঘণ্টা অন্তর প্যাড বা কাপড় বদলানো এবং পরিষ্কার জল দিয়ে ধোয়া।",
        "অন্ধকারে রাখা স্যাঁতসেঁতে কাপড় বারবার ব্যবহার করা।",
        "মাসিক চলাকালীন কোনো স্নান না করা।",
        "জল খাওয়া একদম বন্ধ করে দেওয়া।"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "Regular pad or cloth changes (every 4–6 hours) and clean water washing prevent bacterial infections and reproductive tract complications.",
      bn: "৪-৬ ঘণ্টা পর পর প্যাড বদলানো জীবাণু সংক্রমণ থেকে বাঁচায়।"
    }
  },
  {
    id: 45,
    chapterId: 15,
    question: {
      en: "How MUST reusable cloth menstrual pads be dried to ensure hygienic safety?",
      bn: "কাপড়ের প্যাড জীবাণুমুক্ত রাখতে কীভাবে শুকানো বাধ্যতামূলক?"
    },
    options: {
      en: [
        "Hidden under mattress furniture away from light.",
        "Washed thoroughly with soap and dried completely in direct, open sunlight.",
        "Rinsed with cold water without soap and reused immediately.",
        "Stored inside plastic bags while damp."
      ],
      bn: [
        "লজ্জায় খাটের নিচে অন্ধকারে লুকিয়ে রাখা।",
        "সাবান দিয়ে ভালো করে ধুয়ে খোলা কড়া রোদে সম্পূর্ণ শুকানো।",
        "সাবান ছাড়া শুধু জলে ধুয়ে সাথে সাথে পরা।",
        "ভিজে অবস্থায় পলিথিনে মুড়ে রাখা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Direct sunlight acts as a natural ultraviolet disinfectant, killing harmful bacteria on washed cloth pads.",
      bn: "সূর্যের কড়া রোদ প্রাকৃতিক জীবাণুনাশক হিসেবে কাজ করে।"
    }
  },
  {
    id: 46,
    chapterId: 15,
    question: {
      en: "Dismantling harmful menstrual taboos (such as restrictions on touching food or attending school) benefits girls by:",
      bn: "মাসিকের কুসংস্কার ভাঙলে কিশোরীদের কী উপকার হয়?"
    },
    options: {
      en: [
        "Allowing them to ignore personal hygiene rules entirely.",
        "Ensuring continuous school attendance, dignified self-care, and equal social participation.",
        "Eliminating the physical need for sanitary products.",
        "Reducing the length of the biological menstrual cycle."
      ],
      bn: [
        "পরিচ্ছন্নতার নিয়ম না মানলেও চলে।",
        "স্কুলে নিয়মিত উপস্থিতি, আত্মসম্মান এবং স্বাভাবিক জীবনযাত্রা নিশ্চিত হয়।",
        "প্যাডের কোনো দরকার থাকে না।",
        "মাসিকের দিন সংখ্যা কমে যায়।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Countering taboos protects girls' rights to education, dignity, and full social participation during menstruation.",
      bn: "কুসংস্কার দূর হলে মেয়েরা স্বাধীনভাবে পড়াশোনা ও জীবনে এগোতে পারে।"
    }
  },

  // Chapter 16
  {
    id: 47,
    chapterId: 16,
    question: {
      en: "Adolescent girls in India face significantly high risks for nutritional anemia primarily due to:",
      bn: "ভারতে কিশোরীদের অ্যানিমিয়া বা রক্তস্বল্পতার প্রধান কারণ কী?"
    },
    options: {
      en: [
        "Excessive physical sports participation.",
        "Iron-deficient diets, monthly menstrual blood loss, and gendered intra-household food disparities.",
        "Overconsumption of fresh citrus fruits.",
        "Spending extended hours studying in school."
      ],
      bn: [
        "অতিরিক্ত খেলাধুলো করা।",
        "খাবারে আয়রনের ঘাটতি, মাসিকের রক্তক্ষরণ এবং পরিবারে মেয়েদের কম পুষ্টিকর খাবার দেওয়া।",
        "বেশি বেশি লেবু খাওয়া।",
        "বেশি সময় ধরে স্কুলে পড়ালেখা করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Female adolescent anemia is driven by inadequate dietary iron, monthly blood loss, and unequal food distribution favoring males.",
      bn: "আয়রনের অভাব ও মাসিকের রক্তক্ষরণের কারণে কিশোরীদের রক্তস্বল্পতা বেশি হয়।"
    }
  },
  {
    id: 48,
    chapterId: 16,
    question: {
      en: "Which local food combination MAXIMIZES plant-based iron absorption in the body?",
      bn: "কোন খাবারের মিশ্রণ শরীরে উদ্ভিজ্জ আয়রন শোষণ সবচেয়ে বেশি বাড়ায়?"
    },
    options: {
      en: [
        "Green leafy vegetables (spinach) paired with Vitamin C rich foods (lemon/amla).",
        "Deep-fried snacks paired with hot tea.",
        "Plain white rice paired exclusively with water.",
        "Sugary carbonated beverages paired with sweets."
      ],
      bn: [
        "শাকসবজি বা ছোলার সাথে লেবুর রস বা আমলকী (ভিটামিন সি)।",
        "ভাজাপোড়ার সাথে কড়া গরম চা।",
        "শুধুমাত্র সাদা ভাত আর জল।",
        "মিষ্টির সাথে কোল্ড ড্রিঙ্কস।"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "Vitamin C (ascorbic acid) significantly enhances the body's biological absorption of non-heme iron from plant sources.",
      bn: "ভিটামিন সি উদ্ভিজ্জ আয়রনকে রক্তে সহজে শোষিত হতে সাহায্য করে।"
    }
  },
  {
    id: 49,
    chapterId: 16,
    question: {
      en: "What are primary physical symptoms of nutritional anemia in adolescents?",
      bn: "কিশোরীদের রক্তস্বল্পতার প্রধান শারীরিক লক্ষণ কোনটি?"
    },
    options: {
      en: [
        "Extreme fatigue, dizziness, pale skin, and impaired cognitive concentration.",
        "Rapid increase in muscle mass and bone height.",
        "Hyperactivity and permanent sleep reduction.",
        "Instant improvement in academic exam scores without study."
      ],
      bn: [
        "চরম ক্লান্তি, মাথা ঘোরা, ফ্যাকাশে ত্বক এবং পড়ায় মনোযোগের অভাব।",
        "দ্রুত পেশি ও উচ্চতা বেড়ে যাওয়া।",
        "অতিরিক্ত চঞ্চলতা ও ঘুম না হওয়া।",
        "না পড়েই পরীক্ষায় প্রথম হওয়া।"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "Anemia reduces oxygen-carrying hemoglobin in the blood, leading to fatigue, dizziness, pale skin, and reduced focus.",
      bn: "রক্তে হিমোগ্লোবিন কমে গেলে ক্লান্তি, মাথা ঘোরা ও ফ্যাকাশে ভাব দেখা দেয়।"
    }
  },

  // Chapter 17
  {
    id: 50,
    chapterId: 17,
    question: {
      en: "The four core pillars of child rights established in international and national frameworks are:",
      bn: "শিশু অধিকারের ৪টি প্রধান স্তম্ভ কী কী?"
    },
    options: {
      en: [
        "Wealth, Authority, Marriage, and Employment.",
        "Protection, Education, Health, and Participation.",
        "Silence, Domestic Labor, Obedience, and Isolation.",
        "Ownership, Competition, Travel, and Command."
      ],
      bn: [
        "সম্পদ, ক্ষমতা, বিয়ে ও চাকরি।",
        "সুরক্ষা, শিক্ষা, স্বাস্থ্য এবং মত প্রকাশের স্বাধীনতা।",
        "নীরবতা, ঘরের কাজ, বাধ্যতা ও একাকীত্ব।",
        "মালিকানা, প্রতিযোগিতা, ভ্রমণ ও আদেশ।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "The child rights framework establishes Protection, Education, Health, and Participation as fundamental pillars.",
      bn: "সুরক্ষা, শিক্ষা, স্বাস্থ্য ও মত প্রকাশ হলো শিশুদের ৪টি জন্মগত অধিকার।"
    }
  },
  {
    id: 51,
    chapterId: 17,
    question: {
      en: "Gender equality within child rights frameworks mandates that:",
      bn: "শিশু অধিকারে লিঙ্গ সমতা কী নির্দেশ করে?"
    },
    options: {
      en: [
        "Boys receive priority access to secondary educational funding.",
        "Girls and boys possess identical legal entitlements to protection, schooling, health, and participation.",
        "Rights depend entirely on household financial status.",
        "Girls are exempt from all civic responsibilities."
      ],
      bn: [
        "ছেলেরা পড়াশোনার খরচে অগ্রাধিকার পাবে।",
        "ছেলে ও মেয়ে সবার শিক্ষা, স্বাস্থ্য ও সুরক্ষার আইনি অধিকার হুবহু সমান।",
        "অধিকার সম্পূর্ণ পরিবারের আর্থিক অবস্থার ওপর নির্ভর করে।",
        "মেয়েদের কোনো নাগরিক অধিকারের প্রয়োজন নেই।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Gender equality asserts that all children, regardless of sex, hold equal legal rights to development and protection.",
      bn: "আইন অনুযায়ী ছেলে ও মেয়ে উভয়ের অধিকার সমান।"
    }
  },
  {
    id: 52,
    chapterId: 17,
    question: {
      en: "How does rights literacy directly empower adolescent girls in rural settings?",
      bn: "অধিকার সচেতনতা গ্রামের মেয়েদের কীভাবে সাহায্য করে?"
    },
    options: {
      en: [
        "It allows them to break local laws without legal consequences.",
        "It enables them to identify discrimination, claim legal protections, and access state support services.",
        "It renders community schools unnecessary.",
        "It guarantees immediate employment at age 12."
      ],
      bn: [
        "আইন অমান্য করার ক্ষমতা দেয়।",
        "বৈষম্য চিনতে, আইনি সুরক্ষা দাবি করতে এবং সরকারি সাহায্য পেতে সহায়তা করে।",
        "স্কুল যাওয়ার প্রয়োজনীয়তা শেষ করে দেয়।",
        "১২ বছর বয়সে চাকরি এনে দেয়।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Understanding rights enables girls to identify violations, resist discrimination, and utilize legal protections.",
      bn: "অধিকার জানলে শোষণ ও বঞ্চনা রুখে দাঁড়ানো যায়।"
    }
  },

  // Chapter 18
  {
    id: 53,
    chapterId: 18,
    question: {
      en: "Under the Prohibition of Child Marriage Act in India, what is the minimum legal age of marriage for females?",
      bn: "ভারতে বাল্যবিয়ে প্রতিরোধ আইন অনুযায়ী মেয়েদের জন্য বিয়ের সর্বনিম্ন আইনি বয়স কত?"
    },
    options: {
      en: [ "14 years", "16 years", "18 years", "21 years" ],
      bn: [ "১৪ বছর", "১৬ বছর", "১৮ বছর", "২১ বছর" ]
    },
    correctAnswerIndex: 2,
    explanation: {
      en: "The Prohibition of Child Marriage Act mandates a legal minimum age of 18 years for females.",
      bn: "আইন অনুযায়ী ১৮ বছরের নিচে মেয়েদের বিয়ে দেওয়া কঠোরভাবে নিষিদ্ধ ও দণ্ডনীয়।"
    }
  },
  {
    id: 54,
    chapterId: 18,
    question: {
      en: "According to WHO global health data, what is the LEADING cause of death among adolescent girls aged 15–19 globally?",
      bn: "বিশ্ব স্বাস্থ্য সংস্থা (WHO) অনুযায়ী বিশ্বজুড়ে ১৫–১৯ বছর বয়সী কিশোরীদের মৃত্যুর প্রধান কারণ কী?"
    },
    options: {
      en: [
        "Occupational industrial hazards.",
        "Pregnancy complications and unsafe abortions.",
        "Severe age-related heart failure.",
        "Infectious malaria exclusively."
      ],
      bn: [
        "কারখানায় কাজের ঝুঁকি।",
        "অপরিণত বয়সে গর্ভধারণের জটিলতা ও অনিরাপদ গর্ভপাত।",
        "বার্ধক্যজনিত হৃদরোগ।",
        "ম্যালেরিয়া রোগ।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "WHO health data confirms that pregnancy complications and unsafe abortions are the leading mortality driver for girls aged 15–19 globally.",
      bn: "অল্প বয়সে গর্ভধারণ কিশোরীদের জীবনের জন্য সবচেয়ে বড় ঝুঁকি।"
    }
  },
  {
    id: 55,
    chapterId: 18,
    question: {
      en: "If an adolescent girl faces the imminent threat of forced child marriage, she should immediately:",
      bn: "জোরপূর্বক বাল্যবিয়ের মুখে পড়লে সাথে সাথে কী করা উচিত?"
    },
    options: {
      en: [
        "Accept the marriage silently without informing support networks.",
        "Contact CHILDLINE (1098), Women Helpline (181), or local Child Protection Committees.",
        "Run away alone without telling anyone.",
        "Drop out of school immediately."
      ],
      bn: [
        "চুপচাপ মেনে নেওয়া।",
        "১০৯৮ (চাইল্ডলাইন), ১৮১ (নারী হেল্পলাইন) বা স্থানীয় শিশু সুরক্ষা কমিটিতে জানানো।",
        "কাউকে না জানিয়ে একা পালিয়ে যাওয়া।",
        "স্কুল ছেড়ে দেওয়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "National emergency helplines (1098/181) and local CPCs provide legal protection, rescue, and counseling.",
      bn: "১০৯৮ বা ১৮১ নম্বরে ফোন করলে তৎক্ষণাৎ আইনি উদ্ধার ও সুরক্ষা পাওয়া যায়।"
    }
  },
  {
    id: 56,
    chapterId: 18,
    question: {
      en: "Postponing marriage past age 18 provides which major long-term benefits for young women?",
      bn: "১৮ বছরের পর বিয়ে পিছিয়ে দিলে মেয়েদের কী দীর্ঘমেয়াদী লাভ হয়?"
    },
    options: {
      en: [
        "Lower chances of completing secondary education.",
        "Improved health outcomes, completion of education, and higher economic self-reliance.",
        "Guaranteed elimination of all future household chores.",
        "Complete loss of legal rights."
      ],
      bn: [
        "পড়াশোনা শেষ হওয়ার সম্ভাবনা কমে যায়।",
        "উন্নত স্বাস্থ্য, পড়াশোনা সমাপ্তি এবং অর্থনৈতিক স্বাবলম্বী হওয়ার সুযোগ।",
        "কোনো কাজ না করার গ্যারান্টি।",
        "সব আইনি অধিকার হারিয়ে যাওয়া।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Delaying marriage past 18 protects reproductive health, enables high school/vocational completion, and builds economic agency.",
      bn: "১৮-র পরে বিয়ে সুস্বাস্থ্য ও স্বাবলম্বী হওয়ার পথ খুলে দেয়।"
    }
  },

  // Chapter 19
  {
    id: 57,
    chapterId: 19,
    question: {
      en: "Under Indian child protection laws (POCSO Act), an 'Unsafe Touch' is defined as any touch that:",
      bn: "পকসো (POCSO) আইন অনুযায়ী 'অনিরাপদ স্পর্শ' (Unsafe Touch) কী?"
    },
    options: {
      en: [
        "Makes a child feel safe, cared for, and comfortable.",
        "Causes physical pain, discomfort, confusion, or involves private body parts.",
        "Occurs during a supervised sports match.",
        "Involves shaking hands during a formal greeting."
      ],
      bn: [
        "নিরাপদ ও ভালোবাসার অনুভূতি দেয়।",
        "ভয়, অস্বস্তি বা দ্বিধা তৈরি করে অথবা গোপনাঙ্গে হাত দেওয়ার চেষ্টা করে।",
        "খেলাধুলোর সময় স্বাভাবিক স্পর্শ।",
        "কুশল বিনিময়ে হাত মেলানো।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Unsafe touch involves contact with private body areas or any physical contact causing fear, discomfort, or confusion.",
      bn: "সাঁতারের পোশাকে ঢাকা অংশে হাত দেওয়া বা ভয় ও অস্বস্তি সৃষ্টি করা স্পর্শই অনিরাপদ।"
    }
  },
  {
    id: 58,
    chapterId: 19,
    question: {
      en: "If an adolescent girl experiences unsafe touch or sexual abuse, who carries full legal and moral responsibility?",
      bn: "অনিরাপদ স্পর্শ বা যৌন নির্যাতনের শিকার হলে পুরো দোষ ও আইনি দায় কার?"
    },
    options: {
      en: [
        "The child for leaving her home.",
        "The abuser alone—the child is NEVER at fault under any circumstances.",
        "School teachers exclusively.",
        "Shared equal guilt between the child and adult."
      ],
      bn: [
        "মেয়েটির নিজের, বাইরে বের হওয়ার কারণে।",
        "সম্পূর্ণ নির্যাতনকারীর—মেয়েটির এতে কোনো দোষ নেই।",
        "শুধুমাত্র স্কুল শিক্ষকের।",
        "উভয়ের সমান দোষ।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Under the law, victims of abuse carry zero guilt; full legal and moral responsibility rests entirely on the perpetrator.",
      bn: "নির্যাতনের শিকার ব্যক্তির কোনো দোষ থাকে না, অপরাধ সম্পূর্ণ অপরাধীর।"
    }
  },
  {
    id: 59,
    chapterId: 19,
    question: {
      en: "What is the correct sequence of the standard child personal safety rule?",
      bn: "শিশুদের আত্মরক্ষার আন্তর্জাতিক ৩টি নিয়মের সঠিক ক্রম কোনটি?"
    },
    options: {
      en: [
        "Hide - Keep Secret - Apologize",
        "NO - GO - TELL",
        "Ignore - Wait - Forget",
        "Agree - Stay Silent - Cry"
      ],
      bn: [
        "লুকাও - গোপন রাখো - ক্ষমা চাও",
        "না বলো (NO) - সরে যাও (GO) - বড়দের জানাও (TELL)",
        "উপেক্ষা করো - অপেক্ষা করো - ভুলে যাও",
        "রাজি হও - চুপ থাকো - কাঁদো"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "The NO-GO-TELL rule directs children to say NO firmly, GO away safely, and TELL a trusted adult immediately.",
      bn: "জোরে না বলো, নিরাপদ জায়গায় সরে যাও এবং সাথে সাথে বড়দের জানাও।"
    }
  },

  // Chapter 20
  {
    id: 60,
    chapterId: 20,
    question: {
      en: "What is the official 24/7 national toll-free helpline shortcode for children under 18 in distress across India?",
      bn: "ভারতে ১৮ বছরের কম বয়সী শিশুদের বিপদে ২৪ ঘণ্টা বিনামূল্যে ফোন করার জাতীয় হেল্পলাইন কোনটি?"
    },
    options: {
      en: [ "100", "1098", "108", "14400" ],
      bn: [ "১০০", "১০৯৮", "১০৮", "১৪৪০০" ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "CHILDLINE 1098 is the dedicated 24/7 national toll-free emergency phone service for children under 18.",
      bn: "১০৯৮ হলো চাইল্ডলাইনের ২৪ ঘণ্টার জরুরি সেবা নম্বর।"
    }
  },
  {
    id: 61,
    chapterId: 20,
    question: {
      en: "The Women Helpline shortcode '181' is funded under which national component and linked to which key institutions?",
      bn: "নারী ও কিশোরী হেল্পলাইন '১৮১' কোন সরকারি উদ্যোগের অধীনে পরিচালিত?"
    },
    options: {
      en: [
        "Funded under private corporate schemes; linked to commercial banks.",
        "Funded under the Sambal component of Mission Shakti; linked to One Stop Centres (Sakhi Centres) and Police.",
        "Funded under transport schemes; linked exclusively to bus terminals.",
        "Funded under sports councils; linked to gymnasiums."
      ],
      bn: [
        "একটি বেসরকারি ব্যাংক উদ্যোগ।",
        "মিশন শক্তির সাম্বল প্রকল্পের অংশ; ওয়ান স্টপ সেন্টার (সখী সেন্টার) ও পুলিশের সাথে যুক্ত।",
        "পরিবহন বিভাগের অধীন।",
        "ক্রীড়া পরিষদের অধীন।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "WHL 181 is funded under the Sambal component of Mission Shakti and structurally linked to HEW, Sakhi Centres, and police networks.",
      bn: "১৮১ নম্বর সখী সেন্টার ও নারী সুরক্ষার সাথে সরাসরি যুক্ত।"
    }
  },
  {
    id: 62,
    chapterId: 20,
    question: {
      en: "Which official emergency helpline operates from New Delhi premises and is staffed specifically by Psychological Counsellors trained in topmost Mental Health institutions?",
      bn: "নতুন দিল্লির শীর্ষ মানসিক স্বাস্থ্য প্রতিষ্ঠানের বিশেষজ্ঞদের দ্বারা পরিচালিত হেল্পলাইন কোনটি?"
    },
    options: {
      en: [ "NCW Helpline (14490)", "Fire Response (101)", "Traffic Police (103)", "Commercial Helpline (1800)" ],
      bn: [ "মহিলা কমিশন হেল্পলাইন (১৪৪৯০)", "দমকল সেবা (১০১)", "ট্রাফিক পুলিশ (১০৩)", "বিজ্ঞাপন হেল্পলাইন (১৮০০)" ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "The NCW Helpline 14490 operates from New Delhi premises and employs expert psychological counselors trained in leading mental health institutions.",
      bn: "জাতীয় মহিলা কমিশন হেল্পলাইন ১৪৪৯০ মানসিক ও আইনি পরামর্শ প্রদান করে।"
    }
  },
  {
    id: 63,
    chapterId: 20,
    question: {
      en: "All national emergency shortcodes (1098, 181, 112, 14490) share which vital operational feature?",
      bn: "সরকারি জরুরি নম্বরগুলোর (১০৯৮, ১৮১, ১১২, ১৪৪৯০) সবচেয়ে বড় সুবিধা কী?"
    },
    options: {
      en: [
        "They require high-speed internet connections.",
        "They are completely toll-free, operating 24/7 without requiring mobile talktime balance.",
        "They operate only during regular daytime office hours.",
        "They require written parental consent prior to calling."
      ],
      bn: [
        "এদের জন্য দ্রুতগতির ইন্টারনেট দরকার।",
        "এগুলো দিনরাত ২৪ ঘণ্টা সম্পূর্ণ বিনামূল্যে এবং মোবাইলে কোনো টাকা না থাকলেও কল করা যায়।",
        "শুধু দিনের বেলা অফিস চলাকালীন খোলা থাকে।",
        "অভিভাবকের অনুমতিপত্র ছাড়া ফোন করা যায় না।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "All national emergency shortcodes are toll-free, 24/7 services accessible from any mobile phone without talktime balance.",
      bn: "কোনো ব্যালেন্স ছাড়াই যে কোনো ফোন থেকে ২৪ ঘণ্টা কল করা সম্ভব।"
    }
  },

  // Chapter 21
  {
    id: 64,
    chapterId: 21,
    question: {
      en: "Which practice represents safe digital hygiene for mobile phone usage?",
      bn: "স্মার্টফোন ব্যবহারে সাইবার সুরক্ষার সঠিক নিয়ম কোনটি?"
    },
    options: {
      en: [
        "Sharing account passwords with close school friends for trust.",
        "Maintaining private account settings and keeping location data confidential.",
        "Posting daily school schedules and home addresses publicly.",
        "Accepting friend requests from unknown strangers without verification."
      ],
      bn: [
        "বন্ধুদের বিশ্বাসের খাতিরে পাসওয়ার্ড বলে দেওয়া।",
        "প্রোফাইল প্রাইভেট রাখা এবং নিজের লোকেশন ও ব্যক্তিগত তথ্য গোপন রাখা।",
        "বাড়ির ঠিকানা ও স্কুলের সময়সূচি ইন্টারনেটে পোস্ট করা।",
        "অপরিচিত কারও ফ্রেন্ড রিকোয়েস্ট যাচাই না করে গ্রহণ করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Restricting account privacy settings and keeping location data private prevents online harassment and cyber exploitation.",
      bn: "গোপনীয়তা বজায় রাখলে ইন্টারনেটে অনিরাপদ পরিস্থিতি এড়ানো যায়।"
    }
  },
  {
    id: 65,
    chapterId: 21,
    question: {
      en: "If an adolescent girl receives harassment or blackmail threats online, her immediate action should be to:",
      bn: "ইন্টারনেটে কেউ ব্ল্যাকমেইল বা হুমকির বার্তা পাঠালে সাথে সাথে কী করা উচিত?"
    },
    options: {
      en: [
        "Comply with the harasser's demands secretly.",
        "Take screenshots as evidence, block the user immediately, and report the incident to a trusted adult or helpline.",
        "Destroy her phone without saving evidence.",
        "Harass the abuser in return."
      ],
      bn: [
        "ভয়ে তার সব দাবি মেনে নেওয়া।",
        "প্রমাণ হিসেবে স্ক্রিনশট রাখা, তাকে ব্লক করা এবং বড়দের ও হেল্পলাইনে জানানো।",
        "প্রমাণ না রেখেই ফোন ভেঙে ফেলা।",
        "পাল্টা গালিগালাজ করা।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Capturing screenshots preserves legal evidence, while blocking and reporting halts harassment and activates protective intervention.",
      bn: "স্ক্রিনশট রাখা আইনি প্রমাণ দেয় এবং ব্লক করলে তাৎক্ষণিক সুরক্ষা মেলে।"
    }
  },
  {
    id: 66,
    chapterId: 21,
    question: {
      en: "Digital literacy empowers adolescent girls by:",
      bn: "ডিজিটাল সাক্ষরতা বা সচেতনতা মেয়েদের কীভাবে সাহায্য করে?"
    },
    options: {
      en: [
        "Replacing physical schooling entirely.",
        "Providing safe access to learning, information, and life skills while protecting personal privacy online.",
        "Forcing them to spend 12 hours online daily.",
        "Guaranteeing immediate financial wealth."
      ],
      bn: [
        "স্কুলে যাওয়ার প্রয়োজনীয়তা শেষ করে।",
        "নিরাপদে পড়াশোনা ও নতুন দক্ষতা শেখার সুযোগ দেয় এবং সাইবার বিপদ থেকে রক্ষা করে।",
        "সারাদিন ইন্টারনেটে সময় কাটাতে বাধ্য করে।",
        "হঠাৎ ধনী বানিয়ে দেয়।"
      ]
    },
    correctAnswerIndex: 1,
    explanation: {
      en: "Digital literacy enables informed navigation of digital tools for education and agency while protecting online well-being.",
      bn: "সচেতনভাবে ইন্টারনেট ব্যবহার করলে জ্ঞানের দরজা খুলে যায়।"
    }
  },
  {
    id: 67,
    chapterId: 21,
    question: {
      en: "Which official national portal allows citizens to report cybercrime, online harassment, and digital child exploitation in India?",
      bn: "ভারতে অনলাইনে হয়রানি বা সাইবার অপরাধের অভিযোগ জানানোর জাতীয় ওয়েবসাইট কোনটি?"
    },
    options: {
      en: [
        "National Cyber Crime Reporting Portal (cybercrime.gov.in)",
        "General Postal Portal",
        "Commercial Sports Portal",
        "Public Weather Service Portal"
      ],
      bn: [
        "ন্যাশনাল সাইবার ক্রাইম রিপোর্টিং পোর্টাল (cybercrime.gov.in)",
        "সাধারণ ডাক বিভাগ পোর্টাল",
        "খেলাধুলো পোর্টাল",
        "আবহাওয়া পোর্টাল"
      ]
    },
    correctAnswerIndex: 0,
    explanation: {
      en: "The National Cyber Crime Reporting Portal (cybercrime.gov.in) is India's official platform for reporting online harassment, cyber fraud, and digital exploitation.",
      bn: "cybercrime.gov.in হলো ভারত সরকারের সাইবার অপরাধে অভিযোগ জানানোর সরকারি মাধ্যম।"
    }
  }
];

fs.writeFileSync('src/curriculum_21_quizzes.json', JSON.stringify(quizzes, null, 2));
console.log(`Successfully written ${quizzes.length} quiz questions.`);
