COACH COMMAND — FULL OFFLINE GAME PROTOTYPE

GAME MODES
- Career start: manager name and club selection.
- Morocco Botola Pro fictional 10-club league.
- Squad: 25 sample players, first XI/bench toggling, player profile, player attributes.
- Tactics: formations 4-3-3, 4-4-2, 4-2-3-1, 3-5-2, 5-3-2; mentality, pressing, tempo, defensive line, attacking focus.
- Training: balanced, attack, defence, fitness and youth development.
- Match centre: simulated matches, AI opposing manager reactions, live score, match events, shots, possession, corners, selectable match duration and speed, pause/end, coach instructions and substitutions.
- Match field has directional arrows only; NO PLAYER DOTS.
- Fixtures/results, league table, transfer market, club finances, ledger, career save/import/export.
- Landscape preference is included in the PWA manifest.

IMPORTANT LIMITATIONS
This is a substantial playable offline web-game prototype, not a commercial-grade native APK and not an online multiplayer game. Opponent AI and match engine are local rule-based simulation. Player names and ratings are sample fictional data. Login is a local career profile, not a secure online account system. Saves stay in the same browser/device unless exported.
To install: extract ZIP, host the folder on HTTPS, open the link in Chrome, menu > Install app / Add to Home screen. For an APK, package index.html as an Android WebView app using an Android HTML-to-APK builder or Android Studio. This ZIP itself is not an APK.


UPDATE — LIVE MATCH VISUAL (v2)
- Match Centre now uses a broadcast-style 2D pitch layout with clear pitch markings, goals, score bar and a moving ball marker.
- Attack/defensive movement paths animate and switch between home and AI possession during simulation. Tactical instructions change the movement pattern.
- On supported Android browsers, starting a match requests landscape orientation. The match view is designed to fill the landscape screen.
- This remains a 2D coaching/live-match tracker, not a 3D eFootball game. There are no real-time 3D player models or licensed eFootball assets.
