# City Life — تطبيق مستقل

المجلد جاهز كتطبيق ويب تقدّمي (PWA): يُثبَّت على الشاشة الرئيسية، يعمل بملء الشاشة بالعرض، ويعمل بدون إنترنت بعد أول تشغيل.

## 1) تثبيته على الهاتف (أسرع طريق)
1. ارفع محتوى المجلد إلى استضافة تدعم HTTPS (Netlify أو GitHub Pages أو Cloudflare Pages).
2. افتح الرابط من الهاتف.
3. Android (Chrome): القائمة ثم «تثبيت التطبيق».
   iPhone (Safari): زر المشاركة ثم «إضافة إلى الشاشة الرئيسية».

ملاحظة: iPhone لا يلتزم دائماً بقفل الوضع الأفقي، فدوّر الهاتف يدوياً.

## 2) نشره على المتاجر (Google Play وApp Store)
يلزم لف التطبيق بحاوية أصلية باستخدام Capacitor:

    npm init -y
    npm i @capacitor/core @capacitor/cli @capacitor/android @capacitor/ios
    npx cap init "City Life" com.yourname.citylife --web-dir=www
    mkdir www && cp -r index.html manifest.webmanifest sw.js icons www/
    npx cap add android
    npx cap add ios
    npx cap sync
    npx cap open android   # يفتح Android Studio
    npx cap open ios       # يفتح Xcode (يحتاج Mac)

ثم اضبط الاتجاه على «أفقي» (Landscape) في إعدادات المشروعين، وأضف أيقونة وشاشة بداية، وانشره من حساب مطوّر في كل متجر (حساب Apple مدفوع سنوياً وحساب Google برسم تسجيل، والرسوم تتغيّر فتحقّق منها).

## 3) قبل النشر على المتاجر
- مكتبة three.js تُحمَّل حالياً من CDN وتُخزَّن بعد أول تشغيل. للنشر على المتاجر ضعها داخل المجلد وغيّر وسم script في index.html.
- اللعب الجماعي والأسلحة غير مضافين بعد، واللعب الجماعي يحتاج خادماً.
