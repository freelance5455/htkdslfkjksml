/* Make Your Player: 2 players (or you vs a bot). Every round each player gets a different random character and
   must place it in one of 7 categories. 10 seconds per round; no choice = auto-placed in its best free category.
   After 7 rounds the player whose 7 placed characters add up to the higher total wins.
   Host-authoritative over MQTT (topics mcmake1/...). Uses globals from the main script and guess.js (sRight). */
const MKCATS=["IQ","Battle IQ","Combat","Speed","Powers","Strength","Durability"],MKICON=["🧠","♟️","🥊","⚡","✨","💪","🛡️"];
const MKROUNDS=7,MKPICK_T=10,MKROLL_T=3,MKRES_T=4;
let kmq=null,khb=null,kjoinBeat=null,kjoined=false,kcode=null,K=null,kIsHost=false,kBotGame=false,kTimer=null,kseen={},klastN=0,
 kPick=[null,null],kPool=[],kElapsed=0,kBotAt=4,kKey="",kbq=null,kbrowseGen=0,kPub={},kNotice="",kpv=null,kRollT=null;

/* ---------- sounds (no narration) ---------- */
const sRollTick=i=>tn(260+i*38,0,.035,"square",.05);
const sLand=()=>{tn(90,0,.18,"sine",.35);tn(523,.02,.14,"triangle",.12);tn(784,.12,.22,"triangle",.12)};
const sLock=()=>{tn(660,0,.06,"triangle",.12);tn(990,.06,.1,"triangle",.12)};
const sPlaced=()=>{tn(180,0,.12,"square",.1);tn(720,.08,.15,"triangle",.12)};

/* ---------- helpers ---------- */
const mkVal=(k,c)=>MKST[PL[k].n][c];
function mkScore(p){let t=0;p.board.forEach((c,cat)=>{if(c)t+=mkVal(c.k,cat)});return t}
function mkBestFree(board,k,noise){const free=[];board.forEach((c,i)=>{if(!c)free.push(i)});if(!free.length)return -1;
 if(noise&&Math.random()<.15)return free[Math.random()*free.length|0];
 let best=free[0],bs=-1e9;for(const i of free){const s=mkVal(k,i)+(noise?(Math.random()*16-8):0);if(s>bs){bs=s;best=i}}return best}
const mkNew=()=>({host:uid,phase:"lobby",pub:false,members:[],kicked:[],players:[],r:0,t:0,cur:[],lock:[false,false],res:null,gameId:"",bot:false});
const mkTS=()=>"mcmake1/"+kcode+"/s",mkTA=()=>"mcmake1/"+kcode+"/a";
const mkMeIdx=()=>K?K.players.findIndex(p=>p.u===uid):-1;
function mkset(key,html){if(kKey===key)return false;kKey=key;app.innerHTML=html;return true}
function mkdyn(id,html){const el=document.getElementById(id);if(el&&el.innerHTML!==html)el.innerHTML=html}

/* ---------- home ---------- */
function makeHome(pre){kKey="";const ok=typeof mqtt!=="undefined",h=(typeof pre==="string"?pre:"").toUpperCase(),nt=kNotice;kNotice="";
 app.innerHTML=`<button class="g" onclick="toHub()">← All games</button><h1 style="margin-top:10px">Make Your Player</h1><p>An unofficial marvel fan game. Made by a 16yo 🥸</p>
 <div class="box"><label>Your name<input type="text" id="nm" maxlength="16" value="${esc(myName)}"></label>
 ${ok?`<label>Room type<select id="krt"><option value="0">Private (your friend joins with the code)</option><option value="1">Public (listed for everyone)</option></select></label><div class="bar" style="margin-top:10px"><button onclick="mkCreate()">Create room</button></div>
 <label>Room code<input type="text" id="krc" maxlength="6" value="${esc(h)}" placeholder="ABCDE"></label><button class="alt" onclick="mkJoin()">Join room</button>`:`<p>Multiplayer could not load. Check your internet and reload.</p>`}
 <div style="margin-top:10px"><button class="g" onclick="mkPlayBot()">Play with bot</button></div></div>
 ${ok?`<div class="box"><h2>Public rooms</h2><div id="kpubList">Looking for rooms…</div></div>`:""}<p>${esc(nt)}</p>
 <div class="box"><h2>Rules</h2><p>2 players. Every round you each get a different random character. Put it in one of 7 categories: ${MKCATS.join(", ")}. Each category can hold only one character, so choose wisely. You have ${MKPICK_T} seconds. If you do not choose, the character goes into the free category where it is strongest. After 7 rounds every category is filled and the player with the strongest overall team wins.</p></div>`;
 if(ok){mkBrowse();mkRenderPub()}}
function mkPlayBot(){readName();mkStopBrowse();kIsHost=true;kBotGame=true;kjoined=false;kseen={};K=mkNew();K.bot=true;K.members=[{u:uid,n:myName,t:Date.now()}];mkStart()}

/* ---------- connection ---------- */
function mkconnect(cb,fail,k,ns){k=k||0;if(k>=BROKERS.length)return fail();let done=false;
 const c=mqtt.connect(BROKERS[k],{connectTimeout:6000,reconnectPeriod:3000,clientId:"mk"+Math.random().toString(16).slice(2,12)});
 const bad=()=>{if(done)return;done=true;clearTimeout(t);try{c.end(true)}catch(e){}mkconnect(cb,fail,k+1,ns)};
 const t=setTimeout(bad,7000);
 c.on("connect",()=>{if(!done){done=true;clearTimeout(t);if(!ns)kmq=c;cb(c)}else if(kjoined&&!kIsHost)mkhello()});
 c.on("error",bad)}
function mkSetHash(){try{history.replaceState(null,"","#M_"+kcode)}catch(e){try{location.hash="M_"+kcode}catch(x){}}}
function mkCreate(){readName();mkStopBrowse();const pubSel=(document.getElementById("krt")||{}).value=="1";
 kKey="";app.innerHTML="<p>Creating room…</p>";kcode=Math.random().toString(36).slice(2,7).toUpperCase().replace(/[^A-Z0-9]/g,"X");kseen={};
 mkconnect(c=>{kIsHost=true;kBotGame=false;K=mkNew();K.pub=pubSel;K.members=[{u:uid,n:myName,t:Date.now()}];mkSetHash();c.subscribe(mkTA());
  c.on("message",(tp,pl)=>{let m;try{m=JSON.parse(pl)}catch(e){return}if(!m)return;if(m.kind=="hello"){mkRegister(m.u,m.name);mkSave();mkrender()}else mkApply(m.u,m)});
  khb=setInterval(()=>{mkSave();mkrender()},4000);mkrender();mkSave()},()=>{kNotice="Could not reach the game server. Check your internet and try again.";makeHome()})}
function mkhello(){if(kmq&&kmq.connected)kmq.publish(mkTA(),JSON.stringify({kind:"hello",u:uid,name:myName}))}
function mkJoin(pc){readName();const c0=(typeof pc==="string"&&pc)||((document.getElementById("krc")||{}).value||"").trim().toUpperCase();if(!c0)return;mkStopBrowse();
 kcode=c0;kKey="";app.innerHTML="<p>Joining room "+esc(c0)+"…</p>";let ok=false,tries=0,iv=null;
 const stop=()=>{clearTimeout(t);clearInterval(iv)};
 const t=setTimeout(()=>{if(!ok){stop();mkCleanup();kNotice="Host is offline or the code is wrong.";makeHome()}},12000);
 mkconnect(c=>{kjoined=true;c.subscribe(mkTS());
  c.on("message",(tp,pl)=>{let d;try{d=JSON.parse(pl)}catch(e){return}if(!d)return;if(!ok){ok=true;stop();mkSetHash()}
   const bye=m=>{stop();mkCleanup();kNotice=m;makeHome()};
   if(d.closed||d.phase==="closed")return bye("The host disbanded this room.");
   if((d.kicked||[]).includes(uid))return bye("The host removed you from this room.");
   const isM=(d.members||[]).some(m=>m.u===uid)||(d.players||[]).some(p=>p.u===uid);
   if(d.phase==="lobby"&&!isM&&(d.members||[]).length>=2)return bye("This room is full (2/2 players).");
   if(d.phase!=="lobby"&&!isM)return bye("This game has already started.");
   K=d;mkrender()});
  mkhello();iv=setInterval(()=>{if(!ok&&tries++<5)mkhello()},2000);kjoinBeat=setInterval(mkhello,4000)},()=>{clearTimeout(t);kNotice="Could not reach the game server. Check your internet and try again.";makeHome()})}
function mkact(kind,x){const n=Math.max(Date.now(),klastN+1);klastN=n;if(kmq&&kmq.connected)kmq.publish(mkTA(),JSON.stringify(Object.assign({u:uid,kind,n,name:myName},x||{})))}
function mkSave(){if(!kIsHost||kBotGame||!kmq||!kmq.connected)return;mkRefresh();kmq.publish(mkTS(),JSON.stringify(K));mkpubBeat()}
function mkRefresh(){if(!K||K.phase!=="lobby")return;const now=Date.now();K.members=K.members.filter(m=>now-(m.t||0)<14000||m.u===uid);const me=K.members.find(m=>m.u===uid);if(me){me.n=myName;me.t=now}}
function mkRegister(u,n){if(!u||!K||K.phase!=="lobby"||(K.kicked||[]).includes(u))return;const now=Date.now();
 K.members=K.members.filter(m=>now-(m.t||0)<14000||m.u===uid);let m=K.members.find(x=>x.u===u);
 if(!m){if(K.members.length>=2)return;K.members.push(m={u,n:"Player",t:now})}
 m.n=String(n||m.n||"Player").slice(0,16);m.t=now}
function mkApply(u,a){if(!kIsHost||!K||!a||!(a.n>(kseen[u]||0)))return;kseen[u]=a.n;
 if(a.kind==="pick"){const i=K.players.findIndex(p=>p.u===u);if(i>=0&&a.r===K.r)mkPickAction(i,a.cat)}
 else if(a.kind==="leave"){K.members=(K.members||[]).filter(m=>m.u!==u);mkSave();mkrender()}}
function mkKick(target){if(!kIsHost||!K||K.phase!=="lobby"||!target||target===uid)return;if(!confirm("Remove this player from the room?"))return;
 if(!K.kicked.includes(target))K.kicked.push(target);K.members=K.members.filter(m=>m.u!==target);mkSave();mkrender()}
function mkCleanup(){clearInterval(khb);clearInterval(kjoinBeat);clearInterval(kTimer);clearTimeout(kRollT);khb=null;kjoinBeat=null;kTimer=null;kRollT=null;try{if(kmq)kmq.end(true)}catch(e){}kmq=null;kjoined=false;kIsHost=false;kBotGame=false;K=null;kcode=null;kPick=[null,null];kPool=[];kpv=null;kKey="";try{history.replaceState(null,"",location.pathname+location.search)}catch(e){}}
function mkLeave(){if(!K)return;if(!confirm(kBotGame?"Quit this game?":"Leave this room?"))return;
 if(kBotGame||kIsHost){if(kIsHost&&!kBotGame&&kmq&&kmq.connected){try{const code=kcode;kmq.publish(mkTS(),JSON.stringify({closed:true,host:uid,phase:"closed",members:[]}));kmq.publish("mcmake1/pub/"+code,JSON.stringify({c:code,x:1}))}catch(e){}}
  const wait=kIsHost&&!kBotGame?400:0;setTimeout(()=>{mkCleanup();kNotice=kBotGame?"":"Room closed.";makeHome()},wait);return}
 let fin=false;const finish=()=>{if(fin)return;fin=true;mkCleanup();kNotice="You left the room.";makeHome()};
 if(kmq&&kmq.connected){const n=Math.max(Date.now(),klastN+1);klastN=n;kmq.publish(mkTA(),JSON.stringify({u:uid,kind:"leave",n}),{qos:1},finish);setTimeout(finish,1800)}else finish()}
function mkTogglePub(){if(!kIsHost||K.phase!=="lobby")return;K.pub=!K.pub;if(!K.pub)mkpubClose();mkSave();mkrender()}
function mkStartWithBot(){if(!kIsHost||!K||K.phase!=="lobby")return;K.bot=true;mkStart()}

/* ---------- game flow (host only) ---------- */
function mkStart(){if(!kIsHost||!K||K.phase!=="lobby")return;if(K.pub)mkpubClose();mkRefresh();
 const ms=K.members.slice(0,2);
 if(K.bot){K.players=[{u:ms[0].u,n:ms[0].n,bot:false,board:Array(7).fill(null)},{u:"bot",n:"Bot",bot:true,board:Array(7).fill(null)}]}
 else{if(ms.length<2)return;K.players=ms.map(m=>({u:m.u,n:m.n,bot:false,board:Array(7).fill(null)}))}
 K.gameId="m"+Date.now().toString(36);K.r=0;kPool=sh(PL.map((_,i)=>i)).slice(0,MKROUNDS*2);mkNextRound();clearInterval(kTimer);kTimer=setInterval(mkTick,1000)}
function mkNextRound(){K.r++;
 if(K.r>MKROUNDS){K.phase="done";K.t=0;K.cur=[];clearInterval(kTimer)}
 else{K.cur=[kPool[2*(K.r-1)],kPool[2*(K.r-1)+1]];K.lock=[false,false];kPick=[null,null];K.res=null;K.phase="roll";K.t=MKROLL_T;kElapsed=0;kBotAt=2+(Math.random()*5|0)}
 mkSave();mkrender()}
function mkTick(){if(!kIsHost||!K)return;
 if(K.phase==="roll"){K.t--;if(K.t<=0){K.phase="pick";K.t=MKPICK_T;kElapsed=0}}
 else if(K.phase==="pick"){K.t--;kElapsed++;
  const bi=K.players.findIndex(p=>p.bot);
  if(bi>=0&&!K.lock[bi]&&kElapsed>=kBotAt){const cat=mkBestFree(K.players[bi].board,K.cur[bi],true);mkPickAction(bi,cat);if(K.phase!=="pick"){return}}
  if(K.t<=0){mkResolve();return}}
 else if(K.phase==="result"){K.t--;if(K.t<=0){mkNextRound();return}}
 else return;
 mkSave();mkrender()}
function mkPickAction(i,cat){if(!K||K.phase!=="pick"||K.lock[i]||!(cat>=0&&cat<7)||K.players[i].board[cat])return;
 kPick[i]=cat;K.lock[i]=true;if(K.lock[0]&&K.lock[1]){mkResolve();return}mkSave();mkrender()}
function mkResolve(){const res=[];
 for(let i=0;i<2;i++){let cat=kPick[i],auto=false;if(cat==null||K.players[i].board[cat]){cat=mkBestFree(K.players[i].board,K.cur[i],false);auto=true}
  K.players[i].board[cat]={k:K.cur[i],auto};res.push({cat,auto,k:K.cur[i]})}
 K.res=res;K.phase="result";K.t=MKRES_T;mkSave();mkrender()}
function mkChoose(cat){const i=mkMeIdx();if(i<0||!K||K.phase!=="pick"||K.lock[i])return;sLock();
 if(kIsHost)mkPickAction(i,cat);else{K.lock=K.lock.slice();K.lock[i]=true;mkact("pick",{r:K.r,cat});mkrender()}}
function mkRematch(){if(!kIsHost||!K||K.phase!=="done")return;if(!confirm("Play again with the same players?"))return;
 const n=mkNew(),now=Date.now();n.pub=K.pub;n.bot=K.bot;n.kicked=K.kicked||[];n.members=(K.members||[]).map(m=>({u:m.u,n:m.n,t:now}));
 K=n;kseen={};kpv=null;kKey="";if(K.bot){mkStart()}else{mkSave();mkrender();if(K.pub)mkpubBeat()}}

/* ---------- sounds on state changes ---------- */
function mkfx(){const g=K,p=kpv;if(!g)return;
 if(g.phase==="roll"){/* rolling sounds come from the animation */}
 else if(g.phase==="pick"){if(p&&p.ph==="pick"&&p.r===g.r&&g.t<=3&&p.t!==g.t)sTick();
  if(p&&p.ph==="pick"&&p.r===g.r){const i=mkMeIdx(),o=1-i;if(i>=0&&g.lock[o]&&!p.lo)sBid()}}
 else if(g.phase==="result"){if(!p||p.ph!=="result"||p.r!==g.r){const i=mkMeIdx();if(i>=0&&g.res&&g.res[i]&&g.res[i].auto)sUn();else sPlaced()}}
 else if(g.phase==="done"){if(!p||p.ph!=="done"){sEnd();const i=mkMeIdx(),a=g.players[0],b=g.players[1];if(i>=0&&a&&b){const s=[mkScore(a),mkScore(b)];if(s[i]>s[1-i])setTimeout(sRight,500);else if(s[i]<s[1-i])setTimeout(sUn,500)}}}
 const i=mkMeIdx();kpv={ph:g.phase,r:g.r,t:g.t,lo:i>=0&&g.lock?!!g.lock[1-i]:false}}

/* ---------- views ---------- */
function mkrender(){if(!K||!app)return;mkfx();
 if(K.phase==="lobby")return mkLobby();if(K.phase==="roll"||K.phase==="pick")return mkRound();if(K.phase==="result")return mkResultView();if(K.phase==="done")return mkDone()}
const mkLeaveBtn=()=>kBotGame?`<button class="no" onclick="mkLeave()">Quit game</button>`:kIsHost?`<button class="no" onclick="mkLeave()">Disband room</button>`:`<button class="no" onclick="mkLeave()">Leave room</button>`;
function mkLobby(){const mem=K.members||[],key="L"+JSON.stringify([mem.map(m=>m.u+m.n),!!K.pub,kIsHost]);
 const html=`<div class="marvel-lobby"><div class="marvel-mark">MARVEL</div><h1>MAKE YOUR PLAYER</h1><p class="lobby-tagline">An unofficial marvel fan game. Made by a 16yo 🥸</p></div>
 <div class="box lobby-room"><p>Room code</p><div class="code">${esc(kcode||"")}</div><p>Send your friend this website's link and this code. This game is for 2 players. Keep this screen open until the game ends.</p>
 <h2 style="margin-top:8px">Players (${mem.length}/2)</h2>${mem.map(m=>`<div class="row" style="margin:5px 0"><span>${esc(m.n||"Player")}${m.u===K.host?" · Host":""}</span>${kIsHost&&m.u!==uid?`<button class="no" style="padding:5px 9px" onclick="mkKick('${esc(m.u)}')">Remove</button>`:""}</div>`).join("")||"<small>No players yet</small>"}</div>
 ${kIsHost?`<div class="box"><label><input type="checkbox" ${K.pub?"checked":""} onchange="mkTogglePub()"> Public room (listed for everyone)</label></div>
 <button ${mem.length<2?"disabled":""} onclick="mkStart()">Start game</button> <button class="g" onclick="mkStartWithBot()">Play with a bot instead</button><p>${mem.length<2?"Waiting for a second player to join.":""}</p>`:`<p>Waiting for the host to start.</p>`}<div style="margin-top:10px">${mkLeaveBtn()}</div>`;
 mkset(key,html)}
function mkBoardHtml(){const me=mkMeIdx(),a=me>=0?me:0,b=1-a,pa=K.players[a],pb=K.players[b];
 return `<table><tr><th></th><th>${esc(pa.n)}${me>=0?" (you)":""}</th><th>${esc(pb.n)}</th></tr>${MKCATS.map((c,i)=>`<tr><td>${MKICON[i]} ${c}</td><td>${pa.board[i]?esc(PL[pa.board[i].k].n)+(pa.board[i].auto?" ⏱":""):"—"}</td><td>${pb.board[i]?esc(PL[pb.board[i].k].n)+(pb.board[i].auto?" ⏱":""):"—"}</td></tr>`).join("")}</table>`}
function mkRoundHeader(){return `<div class="row"><small>Round ${K.r} of ${MKROUNDS}</small><small>${kBotGame?"vs Bot":"Room "+esc(kcode||"")}</small></div>`}
function mkRound(){const me=mkMeIdx(),isRoll=K.phase==="roll";
 if(me<0){const key="W"+K.r+K.phase;mkset(key,mkRoundHeader()+`<div class="box"><h2>You are watching</h2><p>Round ${K.r}</p></div>`);return}
 const op=1-me,mine=K.players[me],opp=K.players[op],myK=K.cur[me],opK=K.cur[op],locked=K.lock[me];
 const key=`${isRoll?"RL":"PK"}${K.r}:${locked?1:0}:${K.lock[op]?1:0}:${mine.board.filter(Boolean).length}`;
 if(!isRoll&&kRollT){clearTimeout(kRollT);kRollT=null}
 const grid=MKCATS.map((c,i)=>{const taken=mine.board[i];return `<button ${(isRoll||locked||taken)?"disabled":""} onclick="mkChoose(${i})">${MKICON[i]} ${c}${taken?`<small style="display:block;color:inherit;font-size:11px">${esc(PL[taken.k].n)}</small>`:""}</button>`}).join("");
 const html=`${mkRoundHeader()}
 <div class="box"><div class="row"><h2>${isRoll?"Rolling your characters…":locked?"Locked in ✔":"Pick a category!"}</h2><div class="big" id="kt">${K.t}</div></div><div class="gbar"><i id="kbar"></i></div>
 <div class="row" style="align-items:flex-start;gap:12px;margin-top:8px"><div style="flex:1;text-align:center;min-width:0"><small>YOUR CHARACTER</small><div class="gbig"><div id="kpic"></div></div><div class="hero" id="kname" style="font-size:30px;margin-top:6px">${isRoll?"…":esc(PL[myK].n)}</div></div>
 <div class="mksm" style="width:104px;text-align:center"><small>${esc(opp.n)}</small><div id="kopic"></div><b id="koname" style="display:block;font-size:12px">${isRoll?"…":esc(PL[opK].n)}</b><p id="kolock" style="margin:4px 0;font-size:12px"></p></div></div></div>
 <div class="grid">${grid}</div><p id="kmsg" style="min-height:22px">${isRoll?"Get ready…":locked?"Waiting for "+esc(opp.n)+"…":"Where does this character fit best?"}</p>
 <div class="box"><h2>Teams</h2><div id="kboard">${mkBoardHtml()}</div></div><div>${mkLeaveBtn()}</div>`;
 if(mkset(key,html)){
  if(isRoll)mkRollAnim(myK,opK);
  else{const a=document.getElementById("kpic");if(a)a.replaceWith(mkClean(pic(myK)));const b=document.getElementById("kopic");if(b)b.replaceWith(mkClean(pic(opK)))}}
 const tt=document.getElementById("kt");if(tt){tt.textContent=K.t;tt.style.color=(K.phase==="pick"&&K.t<=3)?"var(--r)":"var(--c)"}
 const bf=document.getElementById("kbar");if(bf){const tot=isRoll?MKROLL_T:MKPICK_T;bf.style.width=Math.max(0,K.t/tot*100)+"%";bf.style.background=(K.phase==="pick"&&K.t<=3)?"var(--r)":"var(--c)"}
 mkdyn("kolock",isRoll?"":K.lock[op]?"✔ locked in":"thinking…")}
// slot-machine style rolling animation: both reels spin and slow down, then land on the real characters
function mkClean(el){el.classList.remove("mkspin","mkland");return el}
function mkRollAnim(myK,opK){clearTimeout(kRollT);const mine=document.getElementById("kpic"),opp=document.getElementById("kopic"),nm=document.getElementById("kname"),on=document.getElementById("koname");if(!mine||!opp)return;
 const cand=sh(PL.map((_,i)=>i).filter(x=>x!==myK&&x!==opK)).slice(0,18);cand.forEach(k=>{try{pic(k)}catch(e){}});try{pic(myK);pic(opK)}catch(e){}
 mine.classList.add("mkspin");
 let a=mine,b=opp,i=0,d=70;
 const step=()=>{if(!K||K.phase!=="roll"){return}
  const ka=cand[(i*2)%cand.length],kb=cand[(i*2+1)%cand.length];
  const na=pic(ka),nb=pic(kb);a.replaceWith(na);a=na;b.replaceWith(nb);b=nb;a.classList.add("mkspin");b.classList.add("mkspin");
  if(nm)nm.textContent=PL[ka].n;if(on)on.textContent=PL[kb].n;sRollTick(i);i++;d=Math.round(d*1.13);
  if(d<330){kRollT=setTimeout(step,d)}
  else{const fa=pic(myK),fb=pic(opK);a.replaceWith(fa);b.replaceWith(fb);a=fa;b=fb;a.classList.remove("mkspin");b.classList.remove("mkspin");a.classList.add("mkland");if(nm)nm.textContent=PL[myK].n;if(on)on.textContent=PL[opK].n;sLand()}};
 step()}
function mkResultView(){const me=mkMeIdx(),key="RS"+K.r;
 const a=me>=0?me:0,b=1-a,line=(i)=>{const r=K.res[i],p=K.players[i];return `<div class="box ${i===me?"g2":""}"><b>${esc(p.n)}${i===me?" (you)":""}</b><p style="color:var(--t)">${esc(PL[r.k].n)} → <b style="color:var(--y)">${MKICON[r.cat]} ${MKCATS[r.cat]}</b>${r.auto?' <span class="un">⏱ auto-placed</span>':""}</p></div>`};
 const html=`${mkRoundHeader()}<h2 style="margin-top:8px">Round ${K.r} placed</h2>${line(a)}${line(b)}<p id="knext">${K.r>=MKROUNDS?"Final results in ":"Next round in "}${K.t}s</p><div class="box"><h2>Teams</h2>${mkBoardHtml()}</div><div>${mkLeaveBtn()}</div>`;
 mkset(key,html);mkdyn("knext",(K.r>=MKROUNDS?"Final results in ":"Next round in ")+K.t+"s")}
function mkDone(){const key="D"+K.gameId,me=mkMeIdx(),a=me>=0?me:0,b=1-a,pa=K.players[a],pb=K.players[b];
 const ta=mkScore(pa),tb=mkScore(pb);let wa=0,wb=0;MKCATS.forEach((c,i)=>{const x=mkVal(pa.board[i].k,i),y=mkVal(pb.board[i].k,i);if(x>y)wa++;else if(y>x)wb++});
 let win=ta>tb?0:tb>ta?1:wa>wb?0:wb>wa?1:-1;const nameOf=w=>w===0?pa:pb;
 const rows=MKCATS.map((c,i)=>{const x=mkVal(pa.board[i].k,i),y=mkVal(pb.board[i].k,i);return `<tr><td>${MKICON[i]} ${c}</td><td style="${x>y?"color:var(--y);font-weight:700":""}">${esc(PL[pa.board[i].k].n)} · <b>${x}</b></td><td style="${y>x?"color:var(--y);font-weight:700":""}">${esc(PL[pb.board[i].k].n)} · <b>${y}</b></td></tr>`}).join("");
 const html=`<h1>Final result</h1><div class="box g2" style="text-align:center"><p>${win<0?"It's a draw":"Best player"}</p><div class="hero" style="color:var(--y)">${win<0?"Draw!":esc(nameOf(win).n)}</div>${win>=0?`<p>${nameOf(win).u===uid?"That is you, congratulations!":"Better luck next time."}</p>`:""}<p>${esc(pa.n)} <b>${ta}</b> vs <b>${tb}</b> ${esc(pb.n)}${ta===tb?" · tie broken by category wins "+wa+"–"+wb:""}</p></div>
 <div class="box"><h2>Category by category</h2><table><tr><th></th><th>${esc(pa.n)}${me>=0?" (you)":""}</th><th>${esc(pb.n)}</th></tr>${rows}<tr><td><b>Total</b></td><td><b>${ta}</b></td><td><b>${tb}</b></td></tr></table><p>Each number is how strong that character is in that category.</p></div>
 ${kIsHost?`<button onclick="mkRematch()">Play again</button> ${kBotGame?"":'<button class="no" onclick="mkLeave()">Disband room</button>'}`:`<p>Waiting for the host to start a rematch.</p><button class="no" onclick="mkLeave()">Leave room</button>`} <button class="alt" onclick="mkBackHome()">Back to Make Your Player</button>`;
 mkset(key,html)}
function mkBackHome(){if(kIsHost&&!kBotGame&&!confirm("This will close the room for everyone. Leave?"))return;
 if(kIsHost&&!kBotGame&&kmq&&kmq.connected){const code=kcode;try{kmq.publish(mkTS(),JSON.stringify({closed:true,host:uid,phase:"closed",members:[]}));kmq.publish("mcmake1/pub/"+code,JSON.stringify({c:code,x:1}))}catch(e){}}
 setTimeout(()=>{mkCleanup();kNotice="";makeHome()},kIsHost&&!kBotGame?400:0)}

/* ---------- public rooms ---------- */
function mkpubBeat(){if(!kIsHost||kBotGame||!K||!K.pub||K.phase!="lobby"||!kmq||!kmq.connected)return;kmq.publish("mcmake1/pub/"+kcode,JSON.stringify({c:kcode,h:myName,n:(K.members||[]).length}))}
function mkpubClose(){if(kIsHost&&!kBotGame&&kmq&&kmq.connected)kmq.publish("mcmake1/pub/"+kcode,JSON.stringify({c:kcode,x:1}))}
function mkBrowse(){if(kbq||typeof mqtt==="undefined")return;const g=++kbrowseGen;
 mkconnect(c=>{if(g!==kbrowseGen){try{c.end(true)}catch(e){}return}kbq=c;c.subscribe("mcmake1/pub/#");
  c.on("message",(tp,pl)=>{let m;try{m=JSON.parse(pl)}catch(e){return}if(!m)return;
   const k=String(m.c||"").replace(/[^A-Z0-9]/g,"").slice(0,6);if(!k)return;
   if(m.x)delete kPub[k];else kPub[k]={c:k,h:String(m.h||"Player").slice(0,16),n:Math.max(0,Math.min(2,+m.n||0)),t:Date.now()};mkRenderPub()})},()=>{},0,true)}
function mkStopBrowse(){kbrowseGen++;if(kbq){try{kbq.end(true)}catch(e){}kbq=null}kPub={}}
function mkRenderPub(){const el=document.getElementById("kpubList");if(!el)return;const now=Date.now();
 for(const k in kPub)if(now-kPub[k].t>12000)delete kPub[k];
 const l=Object.values(kPub).filter(r=>r.n<2);
 el.innerHTML=l.length?l.map(r=>`<div class="row" style="margin:8px 0;gap:10px"><span>${esc(r.h)}’s room · ${r.n}/2 players</span><button class="alt" onclick="mkJoin('${r.c}')">Join</button></div>`).join(""):"<p>No public rooms right now. Create one to start!</p>"}
setInterval(mkRenderPub,3000);
