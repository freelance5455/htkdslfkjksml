import subprocess
import urllib.parse
import webbrowser

APP_PACKAGES = {
    "youtube": "com.google.android.youtube",
    "whatsapp": "com.whatsapp",
    "chrome": "com.android.chrome",
    "instagram": "com.instagram.android",
    "settings": "com.android.settings",
    "phone": "com.google.android.dialer",
    "camera": "com.android.camera2",
    "maps": "com.google.android.apps.maps",
}

def run_termux_api(args):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=12)
        return (p.stdout or p.stderr or "Command completed.").strip()
    except FileNotFoundError:
        return "Termux:API is not installed. Install the Termux:API Android app and `pkg install termux-api`."
    except Exception as exc:
        return f"Action failed: {exc}"

def open_app(name):
    key = name.lower().strip()
    if key not in APP_PACKAGES:
        return f"{name} is not in the allowed app list. Available: {', '.join(APP_PACKAGES)}."
    package = APP_PACKAGES[key]
    try:
        p = subprocess.run(
            ["am", "start", "-a", "android.intent.action.MAIN",
             "-c", "android.intent.category.LAUNCHER", "-p", package],
            capture_output=True, text=True, timeout=10
        )
        if p.returncode == 0:
            return f"Opening {key}."
        return f"Could not open {key}. Check whether it is installed."
    except Exception as exc:
        return f"Could not open app: {exc}"

def youtube_search(query):
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote(query)
    try:
        subprocess.Popen(["am", "start", "-a", "android.intent.action.VIEW", "-d", url])
        return f"Opened YouTube results for: {query}"
    except Exception:
        webbrowser.open(url)
        return f"Opened YouTube results for: {query}"

def battery_status():
    result = run_termux_api(["termux-battery-status"])
    return result

def torch(on):
    return run_termux_api(["termux-torch", "on" if on else "off"])

def vibrate():
    return run_termux_api(["termux-vibrate", "-d", "250"])

def clipboard():
    return run_termux_api(["termux-clipboard-get"])
