# Spend Smart — PWA + Android wrapper project

## Included
- `www/index.html`: latest Expense Tracker 3.0 with the navy/blue wallet icon branding.
- `www/manifest.webmanifest`: installable PWA metadata.
- `www/sw.js`: service worker for offline app-shell caching.
- `www/icons/`: 192px and 512px app icons generated from the supplied latest icon.
- Capacitor configuration and npm scripts for an Android WebView wrapper.

The tracker retains browser localStorage-based transaction persistence. The Excel export uses its existing SheetJS CDN dependency, so Excel export may need internet access; CSV export is local.

## Install as a PWA
1. Host the contents of `www/` on an HTTPS static host (or localhost for testing).
2. Open the hosted URL in Chrome on Android.
3. Use Chrome menu → Install app / Add to Home screen.

Service workers do not run from `file://`; the PWA must be served over HTTPS or localhost.

## Build the Android APK
Prerequisites: Node.js LTS, Android Studio, Android SDK, and a JDK supported by your installed Android Gradle Plugin.

From this project directory:
```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio, wait for Gradle sync, then choose Build → Build Bundle(s) / APK(s) → Build APK(s).
The debug APK is normally generated under `android/app/build/outputs/apk/debug/`.

For a command-line debug build after Android is added:
```bash
cd android
./gradlew assembleDebug
```
On Windows use:
```bat
cd android
gradlew.bat assembleDebug
```

## Important data note
The tracker currently stores records in browser/WebView localStorage. Android WebView data is local to that app installation and is not automatically synced to Chrome or another device. Uninstalling/clearing app storage can erase records. The requested Backup/Restore and Import features are not included.
