#!/data/data/com.termux/files/usr/bin/bash
# CINEMA GOLD local Android test server (Termux only; loopback access).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/backend-py"

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python نصب نیست. در Termux اجرا کنید: pkg install python -y"
  exit 1
fi

export APP_ENV=development
export HOST=127.0.0.1
export PORT=3000
mkdir -p data static/uploads
SECRET_FILE=".local_jwt_secret"
if [[ ! -s "$SECRET_FILE" ]]; then
  python3 - <<'PY' > "$SECRET_FILE"
import secrets
print(secrets.token_urlsafe(48))
PY
  chmod 600 "$SECRET_FILE"
fi
export JWT_SECRET="$(cat "$SECRET_FILE")"

if ! python3 - <<'PY'
from storage import initialize, load
initialize()
users = load('users')
raise SystemExit(0 if any(u.get('role') == 'admin' and u.get('password', '').startswith('pbkdf2_sha256$') and u.get('is_active', True) for u in users) else 1)
PY
then
  echo
  echo "ساخت حساب مدیر CINEMA GOLD"
  echo "نام کاربری و رمز را خودتان وارد کنید؛ رمز حداقل ۱۲ نویسه باشد."
  python3 setup_admin.py
fi

echo
echo "CINEMA GOLD روی همین گوشی اجرا شد."
echo "پنل مدیریت: http://127.0.0.1:3000/admin"
echo "برنامه کاربر: http://127.0.0.1:3000/"
echo "برای توقف سرور در Termux کلید Ctrl+C را بزنید."
echo "این سرور فقط روی همین گوشی قابل دسترسی است و عمومی نیست."
echo
exec python3 server.py
