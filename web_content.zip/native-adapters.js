function capacitorPlugin(name) {
  return window.Capacitor?.Plugins?.[name] || null;
}

function toBase64(value) {
  const bytes = new TextEncoder().encode(value);
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary);
}

export async function saveOrShareFile({ filename, content, mimeType }) {
  const filesystem = capacitorPlugin('Filesystem');
  const share = capacitorPlugin('Share');

  if (filesystem?.writeFile && share?.share) {
    const saved = await filesystem.writeFile({
      path: filename,
      directory: 'CACHE',
      data: toBase64(content),
      recursive: true
    });
    await share.share({ title: filename, text: filename, url: saved.uri });
    return;
  }

  const url = URL.createObjectURL(new Blob([content], { type: mimeType }));
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function shareOrPrintStatement(html, filename) {
  const filesystem = capacitorPlugin('Filesystem');
  const share = capacitorPlugin('Share');

  if (filesystem?.writeFile && share?.share) {
    const saved = await filesystem.writeFile({
      path: filename,
      directory: 'CACHE',
      data: toBase64(html),
      recursive: true
    });
    await share.share({ title: filename, url: saved.uri });
    return;
  }

  const printWindow = window.open('', '_blank');
  if (!printWindow) throw new Error('The browser blocked the statement window.');
  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
}

export async function signInWithNativeAuth(authInstance, provider) {
  const nativeAuth = window.KisanNativeAuth;
  if (nativeAuth?.signIn) return nativeAuth.signIn(authInstance);

  const { signInWithPopup } = await import('https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js');
  return signInWithPopup(authInstance, provider);
}

export function registerAndroidBackHandler(onBack) {
  const appPlugin = capacitorPlugin('App');
  if (appPlugin?.addListener) {
    appPlugin.addListener('backButton', onBack);
  }
}
