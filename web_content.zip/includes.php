<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$dbFile = __DIR__ . '/data/users.json';
$dataDir = dirname($dbFile);
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);
if (!file_exists($dbFile)) file_put_contents($dbFile, json_encode([], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
function h($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function is_logged_in() { return isset($_SESSION['user']); }
function users_read() {
    global $dbFile;
    $fp = fopen($dbFile, 'c+');
    if (!$fp) return [];
    flock($fp, LOCK_SH); $raw = stream_get_contents($fp); flock($fp, LOCK_UN); fclose($fp);
    $rows = json_decode($raw ?: '[]', true);
    return is_array($rows) ? $rows : [];
}
function users_write($rows) {
    global $dbFile;
    $fp = fopen($dbFile, 'c+');
    if (!$fp) return false;
    flock($fp, LOCK_EX); ftruncate($fp, 0); rewind($fp);
    $ok = fwrite($fp, json_encode($rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
    fflush($fp); flock($fp, LOCK_UN); fclose($fp); return $ok;
}
function require_login() { if (!is_logged_in()) { header('Location: login.php'); exit; } }
function csrf_token() { if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function csrf_valid() { return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']); }
