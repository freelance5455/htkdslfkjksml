/* blure v0.7.5 — unified IDE execution modes. No dependencies beyond existing editor. */
(()=>{'use strict';
const $=id=>document.getElementById(id), select=$('blure-run-mode'),run=$('run-btn'),debug=$('debug-btn'),output=$('program-output'),panel=$('console-panel');
if(!select||!run||!output)return;
let mode='js', answers=[],waiting=false,busy=false,requestId=0,phpReachable=true;
const code=()=>{const wrapper=document.querySelector('.CodeMirror');const cm=wrapper&&wrapper.CodeMirror;return cm?cm.getValue():$('blure-code').value};
const input=document.createElement('form');input.className='blure-php-input';input.hidden=true;input.innerHTML='<label id="blure-php-prompt" for="blure-php-answer">Program input</label><input id="blure-php-answer" autocomplete="off"><button type="submit">Submit answer</button><button type="button" id="blure-php-cancel">Cancel</button>';
$('output-view').append(input);
function display(value,error=false){output.textContent=String(value??'');output.style.color=error?'#ff9da7':'';panel.hidden=false;$('console-toggle')?.setAttribute('aria-expanded','true');if($('console-arrow'))$('console-arrow').textContent='▴';}
function update(){
 const status=$('blure-auto-mode');
 if(status)status.textContent=mode==='php'?'● PHP · Online (automatic)':'● JavaScript · Offline (automatic)';
 run.textContent=mode==='php'?'▶ Run PHP':'▶ Run Offline';
 debug.disabled=mode==='php';debug.title=mode==='php'?'Debugging is available in JavaScript mode':'Debug program';
 run.disabled=busy;select.disabled=busy;select.value=mode;
}
function setMode(next){if(next!=='js')return;requestId++;busy=false;waiting=false;input.hidden=true;answers=[];mode=next;update();}
function automatic(){setMode('js');}
window.addEventListener('online',()=>{phpReachable=true;automatic();});
window.addEventListener('offline',automatic);
automatic();
function runLocal(){
 // Dispatch through the editor's existing JavaScript run handler.
 mode='js';update();run.click();
}
async function phpRun(resume=false){if(busy)return;if(!navigator.onLine){automatic();runLocal();return}if(!resume)answers=[];
const ticket=++requestId;busy=true;waiting=false;input.hidden=true;update();display('Running with PHP server…');
try{const body=new URLSearchParams({code:code(),answers:JSON.stringify(answers)});
const res=await fetch('./php-playground.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body,credentials:'same-origin',cache:'no-store'});
if(!res.ok)throw Error('Server HTTP '+res.status);
const data=await res.json();if(ticket!==requestId)return;
display(data.ok?(data.output??''):(data.error||'Unknown PHP error'),!data.ok);
if(data.ok&&data.waiting){waiting=true;input.hidden=false;$('blure-php-prompt').textContent=data.prompt||('Enter '+data.key);const answer=$('blure-php-answer');answer.value='';answer.type=data.kind==='password'?'password':data.kind==='num'?'number':'text';answer.dataset.kind=data.kind||'text';answer.focus();}
}catch(e){if(ticket===requestId){phpReachable=false;display('PHP unavailable; switching to the local JavaScript interpreter…');setMode('js');runLocal();}}finally{if(ticket===requestId){busy=false;update();}}
}
run.addEventListener('click',e=>{if(mode!=='php')return;e.stopImmediatePropagation();e.preventDefault();phpRun();},true);
// Capture keyboard shortcuts before CodeMirror's offline handler.
document.addEventListener('keydown',e=>{if(mode!=='php'||e.key!=='Enter'||!(e.ctrlKey||e.metaKey))return;e.preventDefault();e.stopImmediatePropagation();phpRun();},true);
input.addEventListener('submit',e=>{e.preventDefault();if(!waiting||busy)return;const el=$('blure-php-answer'),v=el.value,kind=el.dataset.kind;if(v.length>10000){alert('Input is too long');return}if(kind==='num'&&(v.trim()===''||!Number.isFinite(Number(v)))){alert('Enter a number');return}if(kind==='yesno'&&!/^(yes|no|y|n|true|false|1|0)$/i.test(v.trim())){alert('Enter yes or no');return}if(answers.length>=100){alert('Input limit reached');return}answers.push(v);waiting=false;phpRun(true)});
$('blure-php-cancel').addEventListener('click',()=>{requestId++;waiting=false;busy=false;input.hidden=true;answers=[];update();});
})();
