blure Stage 3: modules, reusable UI components, and draggable OS windows

Upload ZIP contents into htdocs. Refresh IDE (clear old service worker cache if necessary).
In one IDE project create three files by copying these examples:
  os-demo-main.blu -> main.blu
  os-demo-components.blu -> os-demo-components.blu
  os-demo.css -> os-demo.css
Run main.blu in the graphical preview.

Syntax:
  use.module(other.blu)                 imports a .blu module once, rejects missing/cyclic imports
  ui.component(name) ... ui.end.component
  ui.use(name)                          inserts reusable component markup
  os.window.create(id) ... os.window.end
  os.window.title(id, "Window title")
  os.window.show(id) / close(id) / minimize(id) / maximize(id) / restore(id)
  ui.on.click(button) / run.fn(functionName)

Window controls work by pointer dragging the title bar and using minimize/maximize/close buttons.
OS windows run in browser UI preview, not the PHP terminal runtime or a native OS.
Components are expanded as markup, and imported module functions are shared.
Not yet implemented: module namespaces, component props, app isolation, true OS processes.
