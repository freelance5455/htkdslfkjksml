[app]
title = Pulguita IA
package.name = pulguitaia
package.domain = org.pulguita
source.dir = .
source.include_exts = py,html,css,js,json,txt,md
version = 1.2.0
requirements = python3,kivy,pyjnius
orientation = portrait
fullscreen = 0

android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.permissions = INTERNET

[buildozer]
log_level = 2
warn_on_root = 1
