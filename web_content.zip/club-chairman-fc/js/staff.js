window.StaffHub = (function () {
  let tab = "coach";

  const COACHES = [
    { id: "c1", tier: "PRO", name: "Shin Tae-yong", flag: "🇰🇷", bonusOvr: 2, price: 45000, desc: "Disiplin fisik & mental bertanding." },
    { id: "c2", tier: "PRO", name: "Xabi Alonso", flag: "🇪🇸", bonusOvr: 4, price: 180000, desc: "Penguasaan bola modern & transisi cepat." },
    { id: "c3", tier: "PRO", name: "Jürgen Klopp", flag: "🇩🇪", bonusOvr: 6, price: 450000, desc: "Gegenpressing intensitas tinggi." },
    { id: "c4", tier: "PRO", name: "Carlo Ancelotti", flag: "🇮🇹", bonusOvr: 7, price: 750000, desc: "Taktik fleksibel & spesialis juara." },
    { id: "c5", tier: "PRO", name: "Pep Guardiola", flag: "🇪🇸", bonusOvr: 8, price: 1200000, desc: "Tiki-taka & dominasi total lapangan." },
    { id: "c6", tier: "LEGEND", name: "👑 José Mourinho", flag: "🇵🇹", bonusOvr: 9, price: 1800000, desc: "The Special One · Pertahanan baja & mental juara." },
    { id: "c7", tier: "LEGEND", name: "👑 Arsène Wenger", flag: "🇫🇷", bonusOvr: 10, price: 2400000, desc: "Sepak bola menyerang & pengorbit pemain muda." },
    { id: "c8", tier: "LEGEND", name: "👑 Johan Cruyff", flag: "🇳🇱", bonusOvr: 11, price: 3200000, desc: "Bapak Total Football · Kreativitas tanpa batas." },
    { id: "c9", tier: "LEGEND", name: "👑 Sir Alex Ferguson", flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿", bonusOvr: 13, price: 4500000, desc: "Pelatih terhebat sepanjang masa · Mental comeback." }
  ];

  const ASSISTANTS = [
    { id: "a1", tier: "PRO", name: "Nova Arianto", flag: "🇮🇩", bonusOvr: 1, dailyBonus: 1500, price: 25000, desc: "Analisis lawan & latihan dasar skuad." },
    { id: "a2", tier: "PRO", name: "Pep Lijnders", flag: "🇳🇱", bonusOvr: 2, dailyBonus: 4000, price: 120000, desc: "Spesialis pressing & sesi latihan intensif." },
    { id: "a3", tier: "PRO", name: "Rui Faria", flag: "🇵🇹", bonusOvr: 3, dailyBonus: 8000, price: 320000, desc: "Tangan kanan taktik & kebugaran pemain." },
    { id: "a4", tier: "LEGEND", name: "👑 Pat Rice", flag: "🇬🇧", bonusOvr: 4, dailyBonus: 15000, price: 850000, desc: "Asisten legendaris dengan visi bertahan tajam." },
    { id: "a5", tier: "LEGEND", name: "👑 Carlos Queiroz", flag: "🇵🇹", bonusOvr: 5, dailyBonus: 25000, price: 1500000, desc: "Master strategi & pengembangan bakat elite." },
    { id: "a6", tier: "LEGEND", name: "👑 Tito Vilanova", flag: "🇪🇸", bonusOvr: 6, dailyBonus: 40000, price: 2500000, desc: "Arsitek permainan terbaik di era keemasan." }
  ];

  function ensureStaff(st) {
    if (!st.headCoach) st.headCoach = null;
    if (!st.assistantCoach) st.assistantCoach = null;
  }

  function setTab(t) { tab = t; App.render(); }

  function hire(type, id) {
    const st = GameEngine.getState();
    ensureStaff(st);
    const list = type === "coach" ? COACHES : ASSISTANTS;
    const item = list.find(function (x) { return x.id === id; });
    if (!item) return App.showToast("Staf tidak ditemukan.");

    const current = type === "coach" ? st.headCoach : st.assistantCoach;
    if (current && current.id === item.id) return App.showToast("Sudah melatih klubmu!");
    if (st.balance < item.price) return App.showToast("Saldo tidak cukup (" + GameEngine.formatMoney(item.price) + ")!");

    st.balance -= item.price;
    if (type === "coach") st.headCoach = item;
    else st.assistantCoach = item;

    st.inbox.unshift({
      day: st.day,
      title: (type === "coach" ? "Pelatih Baru: " : "Asisten Baru: ") + item.name,
      body: item.name + " resmi bergabung! Bonus +" + item.bonusOvr + " OVR untuk seluruh tim."
    });

    GameEngine.save();
    App.showToast("✅ " + item.name + " resmi dikontrak!");
    App.render();
  }

  function getTotalOvrBonus() {
    const st = GameEngine.getState();
    let bonus = 0;
    if (st.headCoach) bonus += st.headCoach.bonusOvr || 0;
    if (st.assistantCoach) bonus += st.assistantCoach.bonusOvr || 0;
    return bonus;
  }

  function getDailyBonus() {
    const st = GameEngine.getState();
    return (st.assistantCoach && st.assistantCoach.dailyBonus) ? st.assistantCoach.dailyBonus : 0;
  }

  function renderCard(item, type, activeObj, balance) {
    const isHired = !!(activeObj && activeObj.id === item.id);
    const badgeCls = item.tier === "LEGEND" ? "pot-elite" : "pot-great";
    const extraInfo = type === "assistant" ? " · +" + GameEngine.formatMoney(item.dailyBonus) + "/day" : "";
    const btnText = isHired ? "✓ Aktif" : "Kontrak (" + GameEngine.formatMoney(item.price) + ")";
    const dis = (isHired || balance < item.price) ? "disabled" : "";
    return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px;"><div><div style="font-size:15px;font-weight:900;">${item.flag} ${item.name}</div><span class="pot-badge ${badgeCls}">${item.tier} ${type === "coach" ? "COACH" : "ASSISTANT"}</span></div><div class="ovr-hex">+${item.bonusOvr} OVR</div></div><div style="font-size:11px;color:var(--text-muted);margin:8px 0;">${item.desc}${extraInfo}</div><button class="btn-gold" style="width:100%;" onclick="StaffHub.hire('${type}','${item.id}')" ${dis}>${btnText}</button></div>`;
  }

  function render() {
    const st = GameEngine.getState();
    ensureStaff(st);
    const list = tab === "coach" ? COACHES : ASSISTANTS;
    const activeObj = tab === "coach" ? st.headCoach : st.assistantCoach;
    const summary = `<div class="card" style="border-color:var(--gold);"><div class="section-title" style="margin-bottom:8px;">STAF PELATIH AKTIF (+${getTotalOvrBonus()} OVR)</div><div class="detail-grid"><div class="detail-item"><small>PELATIH KEPALA</small><strong>${st.headCoach ? st.headCoach.flag + " " + st.headCoach.name : "Belum Ada"}</strong></div><div class="detail-item"><small>ASISTEN PELATIH</small><strong>${st.assistantCoach ? st.assistantCoach.flag + " " + st.assistantCoach.name : "Belum Ada"}</strong></div></div></div>`;
    const tabs = `<div class="sub-tabs"><button class="tab-btn ${tab === "coach" ? "active" : ""}" onclick="StaffHub.setTab('coach')">👔 Pelatih Kepala</button><button class="tab-btn ${tab === "assistant" ? "active" : ""}" onclick="StaffHub.setTab('assistant')">📋 Asisten Pelatih</button></div>`;
    const cards = list.map(function (item) { return renderCard(item, tab, activeObj, st.balance); }).join("");
    return summary + tabs + cards;
  }

  return { render, setTab, hire, getTotalOvrBonus, getDailyBonus };
})();
