window.ExtraHub = (function () {
  let tab = "missions";

  const MISSIONS = [
    { id: "m1", title: "Debut Match", desc: "Mainkan minimal 1 pertandingan Live.", reward: 30000, check: function (st) { return st.matchHistory.length >= 1; } },
    { id: "m2", title: "Stadium Builder", desc: "Upgrade Stadium ke Level 2.", reward: 40000, check: function (st) { return st.facilities.stadium.level >= 2; } },
    { id: "m3", title: "Squad Depth", desc: "Miliki minimal 8 pemain di skuad.", reward: 50000, check: function (st) { return st.squad.length >= 8; } },
    { id: "m4", title: "Crypto Investor", desc: "Miliki aset Crypto (AVAX/BNB/ETH/BTC).", reward: 35000, check: function (st) { return st.crypto.some(function (c) { return c.owned > 0; }); } },
    { id: "m5", title: "Rising Club", desc: "Capai Club Reputation Level 3.", reward: 75000, check: function (st) { return st.reputation >= 3; } },
    { id: "m6", title: "Title Contender", desc: "Kumpulkan minimal 9 Poin di klasemen Liga.", reward: 150000, check: function (st) { const me = st.league.find(function (c) { return c.id === "me"; }); return !!(me && me.pts >= 9); } }
  ];

  function ensureFields(st) {
    if (!Array.isArray(st.claimedMissions)) st.claimedMissions = [];
    if (typeof st.bankDebt !== "number") st.bankDebt = 0;
  }

  function setTab(t) { tab = t; App.render(); }

  function claimMission(id) {
    const st = GameEngine.getState();
    ensureFields(st);
    const m = MISSIONS.find(function (x) { return x.id === id; });
    if (!m || !m.check(st)) return App.showToast("Syarat misi belum terpenuhi!");
    if (st.claimedMissions.indexOf(id) !== -1) return App.showToast("Hadiah sudah diklaim!");
    st.claimedMissions.push(id);
    st.balance += m.reward;
    GameEngine.save();
    App.showToast("🎯 Misi selesai! +" + GameEngine.formatMoney(m.reward));
    App.render();
  }

  function scoutNewPlayers() {
    const st = GameEngine.getState();
    if (st.balance < 15000) return App.showToast("Saldo tidak cukup (£15,000)!");
    st.balance -= 15000;

    const fNames = ["Lucas", "Rizky", "Thiago", "Kenji", "Marco", "Sven", "Diego", "Yusuf", "Noah", "Arjun"];
    const lNames = ["Silva", "Santoso", "Mendes", "Tanaka", "Rossi", "Lindqvist", "Vargas", "Demir", "Keller", "Pratama"];
    const nats = [{ flag: "🇮🇩", n: "Indonesia" }, { flag: "🇧🇷", n: "Brazil" }, { flag: "🇯🇵", n: "Japan" }, { flag: "🇪🇸", n: "Spain" }, { flag: "🇦🇷", n: "Argentina" }, { flag: "🇫🇷", n: "France" }];
    const posList = [{ pos: "ST", full: "Striker" }, { pos: "RW", full: "Right Winger" }, { pos: "CM", full: "Central Midfielder" }, { pos: "CB", full: "Centre Back" }, { pos: "GK", full: "Goalkeeper" }, { pos: "CAM", full: "Attacking Mid" }];

    for (let i = 0; i < 3; i++) {
      const nat = nats[Math.floor(Math.random() * nats.length)];
      const p = posList[Math.floor(Math.random() * posList.length)];
      const isWK = Math.random() < 0.2;
      const ovr = isWK ? (82 + Math.floor(Math.random() * 8)) : (58 + Math.floor(Math.random() * 18));
      const name = (isWK ? "🔥 " : "") + fNames[Math.floor(Math.random() * fNames.length)] + " " + lNames[Math.floor(Math.random() * lNames.length)];
      st.transferMarket.unshift({
        id: "sc_" + Date.now() + "_" + i,
        name: name, flag: nat.flag, nationality: nat.n, pos: p.pos, fullPos: p.full,
        ovr: ovr, potential: ovr >= 75 ? "ELITE" : "EXCELLENT",
        age: 17 + Math.floor(Math.random() * 11), height: 172 + Math.floor(Math.random() * 19),
        foot: Math.random() > 0.3 ? "Right" : "Left",
        wage: ovr * 25, value: ovr * (isWK ? 9500 : 1800),
        totalFootball: 55 + Math.floor(Math.random() * 30), pragmatic: 55 + Math.floor(Math.random() * 30)
      });
    }
    GameEngine.save();
    App.showToast("🔍 3 pemain baru ditambahkan ke Transfers!");
    App.render();
  }

  function takeLoan(amount) {
    const st = GameEngine.getState();
    ensureFields(st);
    if (st.bankDebt > 0) return App.showToast("Lunasi pinjaman sebelumnya dulu!");
    st.balance += amount;
    st.bankDebt = Math.round(amount * 1.15);
    GameEngine.save();
    App.showToast("🏦 Pinjaman " + GameEngine.formatMoney(amount) + " cair!");
    App.render();
  }

  function repayLoan() {
    const st = GameEngine.getState();
    ensureFields(st);
    if (st.bankDebt <= 0) return App.showToast("Tidak ada hutang aktif.");
    if (st.balance < st.bankDebt) return App.showToast("Saldo belum cukup!");
    st.balance -= st.bankDebt;
    st.bankDebt = 0;
    GameEngine.save();
    App.showToast("✅ Pinjaman bank lunas!");
    App.render();
  }

  function exportSave() {
    const raw = JSON.stringify(GameEngine.getState());
    const code = btoa(unescape(encodeURIComponent(raw)));
    const box = document.getElementById("save-code-box");
    if (box) {
      box.value = code;
      box.select();
      try { document.execCommand("copy"); App.showToast("📋 Kode Backup disalin!"); }
      catch (e) { App.showToast("Kode Backup siap disalin manual."); }
    }
  }

  function importSave() {
    const box = document.getElementById("save-code-box");
    const code = (box ? box.value : "").trim();
    if (!code) return App.showToast("Tempel kode backup dulu!");
    try {
      const json = decodeURIComponent(escape(atob(code)));
      const parsed = JSON.parse(json);
      if (!parsed || !Array.isArray(parsed.squad)) throw new Error("Invalid");
      localStorage.setItem("club_chairman_save_v1", json);
      GameEngine.load();
      App.showToast("✅ Data klub berhasil dipulihkan!");
      App.goHome();
    } catch (e) {
      App.showToast("❌ Kode backup tidak valid!");
    }
  }

  function render() {
    const st = GameEngine.getState();
    ensureFields(st);
    let body = "";

    if (tab === "missions") {
      body = MISSIONS.map(function (m) {
        const done = m.check(st), claimed = st.claimedMissions.indexOf(m.id) !== -1;
        const btn = claimed ? "✓ Selesai" : done ? "Claim " + GameEngine.formatMoney(m.reward) : "Belum Selesai";
        return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;"><div><strong>🎯 ${m.title}</strong><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${m.desc}</div></div><button class="btn-gold" onclick="ExtraHub.claimMission('${m.id}')" ${(!done || claimed) ? "disabled" : ""}>${btn}</button></div></div>`;
      }).join("");
    } else if (tab === "scout") {
      const loanBtn = st.bankDebt > 0
        ? `<button class="btn-gold" style="width:100%;" onclick="ExtraHub.repayLoan()" ${st.balance < st.bankDebt ? "disabled" : ""}>Lunasi Hutang (${GameEngine.formatMoney(st.bankDebt)})</button>`
        : `<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><button class="btn-outline" onclick="ExtraHub.takeLoan(100000)">Pinjam £100k</button><button class="btn-outline" onclick="ExtraHub.takeLoan(500000)">Pinjam £500k</button></div><div style="font-size:10px;color:var(--text-muted);margin-top:6px;">*Bunga flat 15% saat pelunasan.</div>`;
      body = `<div class="card"><div class="section-title">🔍 GLOBAL SCOUTING</div><div style="font-size:12px;color:var(--text-muted);margin:6px 0 12px;">Cari 3 pemain baru (termasuk peluang Wonderkid 🔥 OVR 82–89) ke Transfers.</div><button class="btn-gold" style="width:100%;" onclick="ExtraHub.scoutNewPlayers()" ${st.balance < 15000 ? "disabled" : ""}>Scout 3 Pemain (£15,000)</button></div>
        <div class="card"><div class="section-title">🏦 BANK LOAN</div><div style="font-size:12px;margin:6px 0 10px;">Hutang Aktif: <strong style="color:${st.bankDebt > 0 ? "#f87171" : "#4ade80"};">${GameEngine.formatMoney(st.bankDebt)}</strong></div>${loanBtn}</div>`;
    } else {
      body = `<div class="card"><div class="section-title">💾 BACKUP & RESTORE SAVE</div><div style="font-size:11px;color:var(--text-muted);margin:4px 0 8px;">Simpan kode ini agar progres tidak hilang saat ganti browser.</div><textarea id="save-code-box" rows="4" class="input-box" placeholder="Klik Export untuk membuat kode, atau paste kode di sini..."></textarea><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><button class="btn-gold" onclick="ExtraHub.exportSave()">Export Kode</button><button class="btn-outline" onclick="ExtraHub.importSave()">Import Kode</button></div></div>`;
    }

    return `<div class="sub-tabs"><button class="tab-btn ${tab === "missions" ? "active" : ""}" onclick="ExtraHub.setTab('missions')">🎯 Misi</button><button class="tab-btn ${tab === "scout" ? "active" : ""}" onclick="ExtraHub.setTab('scout')">🔍 Scout & Bank</button><button class="tab-btn ${tab === "backup" ? "active" : ""}" onclick="ExtraHub.setTab('backup')">💾 Backup</button></div>${body}`;
  }

  return { render, setTab, claimMission, scoutNewPlayers, takeLoan, repayLoan, exportSave, importSave };
})();
