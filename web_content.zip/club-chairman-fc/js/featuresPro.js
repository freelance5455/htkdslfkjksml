window.FeaturesPro = (function () {
  let tab = "lineup";
  let splashDismissed = false;

  function ensureData(st) {
    if (!Array.isArray(st.startingIds)) {
      st.startingIds = st.squad
        .filter(function (p) { return p.team === "first"; })
        .slice(0, 5)
        .map(function (p) { return p.id; });
    }
    if (typeof st.lastCampDay !== "number") st.lastCampDay = 0;
  }

  function renderSplashOverlay(clubName) {
    if (splashDismissed) return "";
    return `
      <div id="cc-splash" style="position:fixed;inset:0;z-index:200;background:radial-gradient(circle at top,#1b3b2c 0%,#090e14 68%);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:24px;text-align:center;">
        <div style="width:96px;height:96px;border-radius:24px;background:linear-gradient(145deg,#e7c976,#9e7624);display:flex;align-items:center;justify-content:center;box-shadow:0 0 36px rgba(217,182,92,0.35);margin-bottom:16px;font-size:42px;">👑⚽</div>
        <div style="font-size:20px;font-weight:900;letter-spacing:1.2px;color:#f3f6fa;">${clubName || "FIRST STEPS FC"}</div>
        <div style="font-size:11px;color:#d9b65c;letter-spacing:2px;margin-top:6px;font-weight:800;">CLUB CHAIRMAN LIVE</div>
        <div style="width:160px;height:5px;background:rgba(255,255,255,0.12);border-radius:99px;overflow:hidden;margin-top:20px;">
          <div style="width:100%;height:100%;background:linear-gradient(90deg,#22c55e,#d9b65c);"></div>
        </div>
        <button class="btn-outline" style="margin-top:18px;" onclick="FeaturesPro.dismissSplash()">Masuk Game ▸</button>
      </div>
    `;
  }
  function dismissSplash() {
    splashDismissed = true;
    const el = document.getElementById("cc-splash");
    if (el) el.remove();
  }

  function scheduleAutoSplash() {
    if (splashDismissed) return;
    setTimeout(function () {
      dismissSplash();
    }, 1800);
  }

  function setTab(t) {
    tab = t;
    if (window.App && App.render) App.render();
  }

  function toggleStarter(playerId) {
    const st = GameEngine.getState();
    ensureData(st);
    const idx = st.startingIds.indexOf(playerId);
    if (idx !== -1) {
      if (st.startingIds.length <= 3) {
        return App.showToast("Minimal 3 pemain inti (Starter)!");
      }
      st.startingIds.splice(idx, 1);
    } else {
      if (st.startingIds.length >= 11) {
        return App.showToast("Maksimal 11 pemain inti (Starter)!");
      }
      st.startingIds.push(playerId);
    }
    GameEngine.save();
    if (window.App && App.render) App.render();
  }
  function runTeamTrainingCamp() {
    const st = GameEngine.getState();
    ensureData(st);
    if (st.lastCampDay === st.day) {
      return App.showToast("Training Camp hari ini sudah dipakai! Lanjut Next Day.");
    }
    const cost = 20000;
    if (st.balance < cost) {
      return App.showToast("Saldo kurang dari £20,000!");
    }

    st.balance -= cost;
    st.lastCampDay = st.day;
    let upgraded = 0;

    st.squad.forEach(function (p) {
      if (p.team === "first" && p.ovr < 99 && Math.random() < 0.65) {
        p.ovr += 1;
        p.value = Math.round(p.value * 1.05);
        upgraded += 1;
      }
    });

    GameEngine.save();
    App.showToast("🏋️ Training Camp selesai! " + upgraded + " pemain naik +1 OVR.");
    if (window.App && App.render) App.render();
  }

  function quickSimMatch() {
    const st = GameEngine.getState();
    const rivals = st.league.filter(function (c) { return c.id !== "me"; });
    const opp = rivals[st.matchIndex % rivals.length];
    if (!opp) return App.showToast("Jadwal lawan tidak ditemukan.");

    const diff = GameEngine.getSquadStrength() - opp.rating;
    const myAtk = Math.max(0, 1.4 + diff * 0.05);
    const oppAtk = Math.max(0, 1.2 - diff * 0.04);

    const hg = Math.min(7, Math.floor(Math.random() * (myAtk + 1.4)));
    const ag = Math.min(6, Math.floor(Math.random() * (oppAtk + 1.2)));

    const rep = GameEngine.recordMatchResult("me", opp.id, hg, ag);
    App.showToast("⚡ Hasil: " + st.clubName + " " + hg + " - " + ag + " " + opp.name + " (+" + GameEngine.formatMoney(rep.totalMatchIncome) + ")");
    if (window.App && App.render) App.render();
  }
  function getHomeBannerNote() {
    const st = GameEngine.getState();
    const dailyExpense = GameEngine.getDailyWages() + GameEngine.getDailyUpkeep();
    if (st.balance < dailyExpense * 3) {
      return `<div class="card" style="border-color:#f87171;background:rgba(127,29,29,0.22);font-size:12px;">⚠️ <strong>Peringatan Kas:</strong> Saldo tersisa kurang dari biaya harian 3 hari (${GameEngine.formatMoney(dailyExpense)}/hari). Mainkan match, klaim bonus, atau buka misi!</div>`;
    }
    return "";
  }

  function render() {
    const st = GameEngine.getState();
    ensureData(st);

    const tabs = `
      <div class="sub-tabs">
        <button class="tab-btn ${tab === "lineup" ? "active" : ""}" onclick="FeaturesPro.setTab('lineup')">📋 Starter XI</button>
        <button class="tab-btn ${tab === "camp" ? "active" : ""}" onclick="FeaturesPro.setTab('camp')">🏋️ Training Camp</button>
        <button class="tab-btn ${tab === "sim" ? "active" : ""}" onclick="FeaturesPro.setTab('sim')">⚡ Quick Sim</button>
      </div>
    `;

    if (tab === "lineup") {
      const firstTeam = st.squad.filter(function (p) { return p.team === "first"; });
      const rows = firstTeam.map(function (p) {
        const isStart = st.startingIds.indexOf(p.id) !== -1;
        return `
          <div class="card" style="display:flex;justify-content:space-between;align-items:center;gap:10px;">
            <div>
              <strong>${p.flag} ${p.name}</strong>
              <div style="font-size:11px;color:var(--text-muted);">${p.pos} · OVR ${p.ovr}</div>
            </div>
            <button class="${isStart ? "btn-gold" : "btn-outline"}" onclick="FeaturesPro.toggleStarter('${p.id}')">
              ${isStart ? "★ Starter" : "Bench"}
            </button>
          </div>
        `;
      }).join("");

      return tabs + `
        <div class="card">
          <div class="section-title">STARTING LINEUP (${st.startingIds.length}/11)</div>
          <div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Tandai pemain inti yang diandalkan di pertandingan.</div>
        </div>
      ` + rows;
    }

    if (tab === "camp") {
      const usedToday = st.lastCampDay === st.day;
      return tabs + `
        <div class="card">
          <div class="section-title">🏋️ TEAM TRAINING CAMP</div>
          <div style="font-size:12px;color:var(--text-muted);margin:6px 0 12px;">
            Latih seluruh pemain First Team sekaligus (peluang naik +1 OVR per pemain). Sekali per hari dalam game.
          </div>
          <button class="btn-gold" style="width:100%;" onclick="FeaturesPro.runTeamTrainingCamp()" ${usedToday || st.balance < 20000 ? "disabled" : ""}>
            ${usedToday ? "✓ Sudah Latihan Hari Ini" : "Mulai Training Camp (£20,000)"}
          </button>
        </div>
      `;
    }

    const rivals = st.league.filter(function (c) { return c.id !== "me"; });
    const opp = rivals[st.matchIndex % rivals.length];
    return tabs + `
      <div class="card">
        <div class="section-title">⚡ QUICK MATCH SIMULATION</div>
        <div style="font-size:12px;color:var(--text-muted);margin:6px 0 12px;">
          Lawan berikutnya: <strong style="color:#fff;">${opp ? opp.name : "Opponent"}</strong> (OVR ${opp ? opp.rating : 55}). Hasil langsung masuk ke klasemen & kas stadion.
        </div>
        <button class="btn-gold" style="width:100%;" onclick="FeaturesPro.quickSimMatch()">Simulasikan Pertandingan Sekarang</button>
      </div>
    `;
  }

  return {
    render,
    setTab,
    toggleStarter,
    runTeamTrainingCamp,
    quickSimMatch,
    renderSplashOverlay,
    dismissSplash,
    scheduleAutoSplash,
    getHomeBannerNote
  };
})();
