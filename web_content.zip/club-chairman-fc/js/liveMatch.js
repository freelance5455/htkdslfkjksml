window.LiveMatch = (function () {
  let timer = null, match = null, onUpdateCb = null, speedMs = 450;
  const awayPlayers = ["Oscar van de Wal", "Laurent Dumas", "Ignazio Altera", "Marco Bellini", "Tomasz Nowak", "Liam Gallagher"];

  function stop() {
    if (timer !== null) { clearInterval(timer); timer = null; }
  }

  function start(opponent, onUpdate) {
    stop();
    const st = GameEngine.getState();
    const firstTeam = st.squad.filter(function (p) { return p.team === "first"; });
    match = {
      homeId: "me", awayId: opponent.id, homeName: st.clubName, awayName: opponent.name,
      homeRating: GameEngine.getSquadStrength(), awayRating: opponent.rating,
      tactic: st.tactic || "balanced",
      homePlayers: firstTeam.length ? firstTeam.map(function (p) { return p.name; }) : ["Nicklas Edman"],
      minute: 0, homeGoals: 0, awayGoals: 0, possessionHome: 50, pressureHome: 50,
      shotsHome: 0, shotsAway: 0, onTargetHome: 0, onTargetAway: 0, cornersHome: 0, cornersAway: 0,
      bannerTitle: "KICK OFF", bannerSub: "Taktik: " + (st.tactic || "balanced").toUpperCase(),
      bannerIsGoal: false, events: [], paused: false, finished: false, settlement: null
    };
    onUpdateCb = onUpdate;
    speedMs = 450;
    timer = setInterval(tick, speedMs);
    if (onUpdateCb) onUpdateCb(match);
  }

  function setSpeed(mult) {
    if (!match || match.finished) return;
    speedMs = mult === 4 ? 110 : mult === 2 ? 230 : 450;
    if (!match.paused) { stop(); timer = setInterval(tick, speedMs); }
  }

  function togglePause() {
    if (!match || match.finished) return;
    match.paused = !match.paused;
    if (match.paused) stop();
    else timer = setInterval(tick, speedMs);
    if (onUpdateCb) onUpdateCb(match);
  }

  function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

  function tick() {
    if (!match || match.paused || match.finished) { stop(); return; }
    match.minute += 1;

    const diff = match.homeRating - match.awayRating;
    const tacBonus = match.tactic === "attack" ? 0.04 : match.tactic === "defense" ? -0.02 : 0;
    const homeBias = Math.min(0.78, Math.max(0.25, 0.50 + diff * 0.014 + tacBonus));
    const goalRate = match.tactic === "attack" ? 0.21 : match.tactic === "defense" ? 0.10 : 0.15;

    const swing = (Math.random() < homeBias ? 1 : -1) * (4 + Math.floor(Math.random() * 8));
    match.pressureHome = Math.min(88, Math.max(12, match.pressureHome + swing));
    match.possessionHome = Math.round(match.possessionHome * 0.85 + match.pressureHome * 0.15);

    if (Math.random() < 0.28) {
      const isHome = Math.random() < homeBias;
      const teamName = isHome ? match.homeName : match.awayName;
      const actor = isHome ? pick(match.homePlayers) : pick(awayPlayers);
      const act = Math.random();

      if (act < goalRate) {
        if (isHome) { match.homeGoals += 1; match.shotsHome += 1; match.onTargetHome += 1; }
        else { match.awayGoals += 1; match.shotsAway += 1; match.onTargetAway += 1; }
        match.bannerTitle = "GOAL!";
        match.bannerSub = actor + " (" + teamName + ")";
        match.bannerIsGoal = true;
        match.events.unshift({ min: match.minute, type: "goal", icon: "⚽", text: actor + " mencetak gol spektakuler!", team: teamName });
      } else if (act < 0.45) {
        const onT = Math.random() < 0.55;
        if (isHome) { match.shotsHome += 1; if (onT) match.onTargetHome += 1; }
        else { match.shotsAway += 1; if (onT) match.onTargetAway += 1; }
        match.bannerTitle = onT ? "SAVE!" : "CHANCE";
        match.bannerSub = actor + " mengancam gawang lawan.";
        match.bannerIsGoal = false;
        match.events.unshift({ min: match.minute, type: "shot", icon: "🎯", text: actor + " melepaskan tembakan keras.", team: teamName });
      } else if (act < 0.68) {
        if (isHome) match.cornersHome += 1; else match.cornersAway += 1;
        match.bannerIsGoal = false;
        match.events.unshift({ min: match.minute, type: "corner", icon: "🚩", text: "Tendangan sudut untuk " + teamName + ".", team: teamName });
      } else {
        match.bannerIsGoal = false;
        match.events.unshift({ min: match.minute, type: "play", icon: "⚡", text: actor + " membangun serangan balik cepat.", team: teamName });
      }
    }

    if (match.minute === 45) {
      match.bannerTitle = "HALF TIME";
      match.bannerSub = match.homeName + " " + match.homeGoals + " - " + match.awayGoals + " " + match.awayName;
      match.bannerIsGoal = false;
      match.events.unshift({ min: 45, type: "info", icon: "⏱️", text: "Babak pertama berakhir.", team: "Match Official" });
    }

    if (match.minute >= 90) {
      match.finished = true;
      stop();
      match.bannerTitle = "FULL TIME";
      match.bannerSub = match.homeName + " " + match.homeGoals + " - " + match.awayGoals + " " + match.awayName;
      match.bannerIsGoal = match.homeGoals > match.awayGoals;
      match.events.unshift({ min: 90, type: "info", icon: "🏁", text: "Pertandingan selesai!", team: "Match Official" });
      match.settlement = GameEngine.recordMatchResult(match.homeId, match.awayId, match.homeGoals, match.awayGoals);
    }

    if (onUpdateCb) onUpdateCb(match);
  }

  return { start, stop, setSpeed, togglePause, getMatch: function () { return match; } };
})();
