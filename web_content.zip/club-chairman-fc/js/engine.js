window.GameEngine = (function () {
  const SAVE_KEY = "club_chairman_save_v1";
  let state = null;

  function load() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      state = raw ? JSON.parse(raw) : GameData.createInitialState();
      if (!state || !Array.isArray(state.squad)) state = GameData.createInitialState();
    } catch (e) {
      state = GameData.createInitialState();
    }

    if (typeof state.lastRealDate !== "string") state.lastRealDate = "";
    if (typeof state.lastClaimDate !== "string") state.lastClaimDate = "";
    if (typeof state.loginStreak !== "number") state.loginStreak = 0;
    if (typeof state.isOwner !== "boolean") state.isOwner = false;
    if (typeof state.tactic !== "string") state.tactic = "balanced";
    if (typeof state.sponsorLevel !== "number") state.sponsorLevel = 1;
    return state;
  }

  function save() {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(state)); } catch (e) {}
  }

  function reset() {
    localStorage.removeItem(SAVE_KEY);
    state = GameData.createInitialState();
    save();
    return state;
  }

  function getState() {
    if (!state) load();
    return state;
  }

  function formatMoney(num) {
    const n = Number(num) || 0;
    return (n < 0 ? "-" : "") + "£" + Math.abs(Math.round(n)).toLocaleString("en-US");
  }

  function getSquadStrength() {
    const first = getState().squad.filter(function (p) { return p.team === "first"; });
    if (!first.length) return 40;
    return Math.round(first.reduce(function (a, p) { return a + p.ovr; }, 0) / first.length);
  }

  function getDailyWages() {
    return getState().squad.reduce(function (a, p) { return a + p.wage; }, 0);
  }

  function getDailyUpkeep() {
    return getState().academies.reduce(function (a, x) { return a + x.upkeep; }, 0);
  }

  function getDailyPropertyIncome() {
    return getState().properties.reduce(function (a, x) { return a + x.owned * x.income; }, 0);
  }

  function getDailySponsorIncome() {
    const st = getState();
    return st.sponsorLevel * 4000 + st.reputation * 500;
  }

  function tickCryptoPrices() {
    getState().crypto.forEach(function (coin) {
      const swing = (Math.random() - 0.48) * 6;
      coin.price = Math.max(0.01, Number((coin.price * (1 + swing / 100)).toFixed(2)));
      coin.change = Number((coin.change * 0.6 + swing).toFixed(2));
    });
    save();
  }

  function advanceDay() {
    const st = getState();
    st.day += 1;
    const propIncome = getDailyPropertyIncome();
    const sponsorIncome = getDailySponsorIncome();
    const wages = getDailyWages();
    const upkeep = getDailyUpkeep();
    const net = propIncome + sponsorIncome - wages - upkeep;
    st.balance += net;
    tickCryptoPrices();

    if (st.day % 7 === 0 && st.academies.length > 0) {
      const ac = st.academies[Math.floor(Math.random() * st.academies.length)];
      const youthOvr = Math.min(72, 50 + ac.level * 3 + Math.floor(Math.random() * 5));
      const positions = [{ pos: "ST", fullPos: "Striker" }, { pos: "CM", fullPos: "Central Midfielder" }, { pos: "CB", fullPos: "Centre Back" }, { pos: "RW", fullPos: "Right Winger" }];
      const pick = positions[Math.floor(Math.random() * positions.length)];
      st.squad.push({
        id: "y_" + Date.now() + "_" + Math.floor(Math.random() * 999),
        name: ac.country + " Talent #" + st.day, flag: ac.flag, nationality: ac.country,
        pos: pick.pos, fullPos: pick.fullPos, ovr: youthOvr, potential: youthOvr >= 58 ? "ELITE" : "EXCELLENT",
        age: 17, height: 175 + Math.floor(Math.random() * 15), foot: Math.random() > 0.3 ? "Right" : "Left",
        wage: 220, value: youthOvr * 1100, team: "u20", goals: 0, apps: 0, totalFootball: 55, pragmatic: 55
      });
      st.inbox.unshift({ day: st.day, title: "Youth Intake (" + ac.country + ")", body: "Pemain muda U20 (" + youthOvr + " OVR) bergabung!" });
    }

    const me = st.league.find(function (c) { return c.id === "me"; });
    if (me) { me.name = st.clubName; me.rating = getSquadStrength(); }
    save();
    return { net, propIncome, sponsorIncome, wages, upkeep };
  }

  function syncRealWorldDays(todayStr) {
    const st = getState();
    if (!st.lastRealDate || st.lastRealDate === todayStr) {
      st.lastRealDate = todayStr;
      save();
      return { daysPassed: 0, totalNet: 0 };
    }
    const prev = new Date(st.lastRealDate + "T00:00:00");
    const curr = new Date(todayStr + "T00:00:00");
    let diffDays = Math.floor((curr - prev) / 86400000);
    if (isNaN(diffDays) || diffDays <= 0) {
      st.lastRealDate = todayStr;
      save();
      return { daysPassed: 0, totalNet: 0 };
    }
    diffDays = Math.min(14, diffDays);
    let totalNet = 0;
    for (let i = 0; i < diffDays; i++) totalNet += advanceDay().net;
    st.lastRealDate = todayStr;
    save();
    return { daysPassed: diffDays, totalNet };
  }

  function claimDailyReward(todayStr) {
    const st = getState();
    if (st.lastClaimDate === todayStr) return { ok: false, msg: "Bonus hari ini sudah diklaim!" };
    const y = new Date(todayStr + "T00:00:00");
    y.setDate(y.getDate() - 1);
    const yStr = y.getFullYear() + "-" + String(y.getMonth() + 1).padStart(2, "0") + "-" + String(y.getDate()).padStart(2, "0");
    st.loginStreak = (st.lastClaimDate === yStr) ? ((st.loginStreak % 7) + 1) : 1;
    const reward = 15000 + st.loginStreak * 10000;
    st.balance += reward;
    st.lastClaimDate = todayStr;
    save();
    return { ok: true, msg: "Bonus Hari ke-" + st.loginStreak + ": +" + formatMoney(reward) + "!" };
  }

  function activateOwnerMode(code) {
    const st = getState();
    if ((code || "").trim().toUpperCase() !== "OWNER2026") return { ok: false, msg: "Kode Owner salah!" };
    st.isOwner = true;
    st.balance = 500000000;
    st.reputation = Math.max(st.reputation, 10);
    st.inbox.unshift({ day: st.day, title: "👑 OWNER MODE AKTIF", body: "Saldo klub diatur ke £500,000,000!" });
    save();
    return { ok: true, msg: "👑 Owner Mode Aktif! Saldo £500,000,000" };
  }

  function addOwnerMoney() {
    const st = getState();
    if (!st.isOwner) return { ok: false, msg: "Khusus Owner!" };
    st.balance += 100000000;
    save();
    return { ok: true, msg: "+£100,000,000 ditambahkan!" };
  }

  function trainPlayer(playerId) {
    const st = getState();
    const p = st.squad.find(function (x) { return x.id === playerId; });
    if (!p) return { ok: false, msg: "Pemain tidak ditemukan." };
    if (p.ovr >= 99) return { ok: false, msg: "OVR pemain sudah maksimal (99)!" };
    const cost = p.ovr * 250;
    if (st.balance < cost) return { ok: false, msg: "Butuh " + formatMoney(cost) + " untuk latihan!" };
    st.balance -= cost;
    p.ovr += 1;
    p.value = Math.round(p.value * 1.08);
    save();
    return { ok: true, msg: p.name + " naik ke " + p.ovr + " OVR!" };
  }

  function setTactic(t) {
    const st = getState();
    st.tactic = t;
    save();
    return { ok: true, msg: "Taktik diubah ke " + t.toUpperCase() };
  }

  function upgradeSponsor() {
    const st = getState();
    if (st.sponsorLevel >= 10) return { ok: false, msg: "Sponsor sudah level maksimal!" };
    const cost = st.sponsorLevel * 45000;
    if (st.balance < cost) return { ok: false, msg: "Saldo tidak cukup (" + formatMoney(cost) + ")!" };
    st.balance -= cost;
    st.sponsorLevel += 1;
    save();
    return { ok: true, msg: "Sponsor naik ke Level " + st.sponsorLevel + "!" };
  }

  function buyTransferPlayer(id) {
    const st = getState();
    const idx = st.transferMarket.findIndex(function (p) { return p.id === id; });
    if (idx === -1) return { ok: false, msg: "Pemain tidak ditemukan." };
    const p = st.transferMarket[idx];
    if (st.balance < p.value) return { ok: false, msg: "Saldo tidak cukup!" };
    st.balance -= p.value;
    st.transferMarket.splice(idx, 1);
    st.squad.push({ ...p, team: "first", goals: 0, apps: 0 });
    save();
    return { ok: true, msg: p.name + " resmi direkrut!" };
  }

  function togglePlayerTeam(id) {
    const st = getState();
    const p = st.squad.find(function (x) { return x.id === id; });
    if (!p) return { ok: false, msg: "Pemain tidak ditemukan." };
    if (p.team === "first") {
      if (st.squad.filter(function (x) { return x.team === "first"; }).length <= 3) return { ok: false, msg: "Minimal 3 pemain di First Team." };
      p.team = "u20";
    } else p.team = "first";
    save();
    return { ok: true, msg: p.name + " dipindahkan ke " + (p.team === "first" ? "First Team" : "U20") };
  }

  function sellPlayer(id) {
    const st = getState();
    const idx = st.squad.findIndex(function (x) { return x.id === id; });
    if (idx === -1 || st.squad.length <= 4) return { ok: false, msg: "Tidak bisa menjual pemain ini." };
    const p = st.squad[idx];
    const price = Math.round(p.value * 0.85);
    st.balance += price;
    st.squad.splice(idx, 1);
    save();
    return { ok: true, msg: p.name + " terjual " + formatMoney(price) };
  }

  function upgradeFacility(key) {
    const st = getState(), f = st.facilities[key];
    if (!f || f.level >= f.maxLevel) return { ok: false, msg: "Sudah maksimal!" };
    if (st.balance < f.cost) return { ok: false, msg: "Saldo tidak cukup!" };
    st.balance -= f.cost;
    f.level += 1;
    if (key === "stadium") f.capacity += f.capacityStep;
    else f.perAttendee = Number((f.perAttendee + f.step).toFixed(2));
    f.cost = Math.round(f.cost * 1.45);
    save();
    return { ok: true, msg: f.name + " naik ke Level " + f.level + "!" };
  }

  function buyProperty(id) {
    const st = getState(), prop = st.properties.find(function (x) { return x.id === id; });
    if (!prop || st.balance < prop.price) return { ok: false, msg: "Saldo tidak cukup!" };
    st.balance -= prop.price;
    prop.owned += 1;
    save();
    return { ok: true, msg: "Berhasil membeli " + prop.name + "!" };
  }

  function tradeCrypto(sym, qtyRaw, act) {
    const st = getState(), coin = st.crypto.find(function (c) { return c.symbol === sym; }), qty = parseFloat(qtyRaw);
    if (!coin || isNaN(qty) || qty <= 0) return { ok: false, msg: "Jumlah tidak valid." };
    const total = coin.price * qty;
    if (act === "buy") {
      if (st.balance < total) return { ok: false, msg: "Saldo tidak cukup!" };
      st.balance -= total;
      coin.owned = Number((coin.owned + qty).toFixed(6));
      save();
      return { ok: true, msg: "Membeli " + qty + " " + sym };
    } else {
      if (coin.owned < qty) return { ok: false, msg: "Aset " + sym + " tidak cukup." };
      coin.owned = Number((coin.owned - qty).toFixed(6));
      st.balance += total;
      save();
      return { ok: true, msg: "Menjual " + qty + " " + sym };
    }
  }

  function upgradeAcademy(id) {
    const st = getState(), ac = st.academies.find(function (a) { return a.id === id; });
    if (!ac || ac.level >= ac.maxLevel || st.balance < ac.nextCost) return { ok: false, msg: "Saldo tidak cukup!" };
    st.balance -= ac.nextCost;
    ac.level += 1;
    ac.nextCost = Math.round(ac.nextCost * 1.6);
    ac.tier = ac.level >= 4 ? "Elite academy" : ac.level >= 2 ? "Standard academy" : "Poor academy";
    save();
    return { ok: true, msg: "Akademi " + ac.country + " Level " + ac.level + "!" };
  }

  function createAcademy(id) {
    const st = getState();
    if (st.academies.length >= 3) return { ok: false, msg: "Maksimal 3 akademi!" };
    const idx = st.availableAcademies.findIndex(function (a) { return a.id === id; });
    if (idx === -1) return { ok: false, msg: "Tidak tersedia." };
    const pick = st.availableAcademies[idx];
    if (st.balance < pick.cost) return { ok: false, msg: "Saldo tidak cukup!" };
    st.balance -= pick.cost;
    st.availableAcademies.splice(idx, 1);
    st.academies.push({ id: "ac_" + Date.now(), country: pick.country, flag: pick.flag, tier: "Poor academy", level: 1, maxLevel: 5, upkeep: pick.upkeep, nextCost: Math.round(pick.cost * 1.2) });
    save();
    return { ok: true, msg: "Akademi " + pick.country + " dibangun!" };
  }

  function recordMatchResult(homeId, awayId, hg, ag) {
    const st = getState();
    const home = st.league.find(function (c) { return c.id === homeId; });
    const away = st.league.find(function (c) { return c.id === awayId; });
    if (home && away) {
      home.p += 1; away.p += 1; home.gf += hg; home.ga += ag; away.gf += ag; away.ga += hg;
      if (hg > ag) { home.w += 1; home.pts += 3; away.l += 1; }
      else if (hg < ag) { away.w += 1; away.pts += 3; home.l += 1; }
      else { home.d += 1; away.d += 1; home.pts += 1; away.pts += 1; }
    }
    const others = st.league.filter(function (c) { return c.id !== homeId && c.id !== awayId; });
    for (let i = 0; i + 1 < others.length; i += 2) {
      const a = others[i], b = others[i + 1], ga = Math.floor(Math.random() * 4), gb = Math.floor(Math.random() * 4);
      a.p += 1; b.p += 1; a.gf += ga; a.ga += gb; b.gf += gb; b.ga += ga;
      if (ga > gb) { a.w += 1; a.pts += 3; b.l += 1; }
      else if (gb > ga) { b.w += 1; b.pts += 3; a.l += 1; }
      else { a.d += 1; b.d += 1; a.pts += 1; b.pts += 1; }
    }
    const attendance = Math.round(st.facilities.stadium.capacity * Math.min(0.98, 0.55 + st.reputation * 0.04));
    const totalMatchIncome = attendance * 14 + Math.round(attendance * st.facilities.foodStands.perAttendee) + Math.round(attendance * st.facilities.merchShops.perAttendee * (1 + st.reputation * 0.1)) + (hg > ag ? 25000 : hg === ag ? 10000 : 0);
    st.balance += totalMatchIncome;
    if (hg > ag) st.reputation += 1;
    st.matchIndex += 1;
    st.matchHistory.unshift({ day: st.day, home: home ? home.name : st.clubName, away: away ? away.name : "Opponent", score: hg + " - " + ag, income: totalMatchIncome });
    save();
    return { attendance, totalMatchIncome };
  }

  return {
    load, save, reset, getState, formatMoney, getSquadStrength,
    getDailyWages, getDailyUpkeep, getDailyPropertyIncome, getDailySponsorIncome,
    tickCryptoPrices, advanceDay, syncRealWorldDays, claimDailyReward,
    activateOwnerMode, addOwnerMoney, trainPlayer, setTactic, upgradeSponsor,
    buyTransferPlayer, togglePlayerTeam, sellPlayer, upgradeFacility,
    buyProperty, tradeCrypto, upgradeAcademy, createAcademy, recordMatchResult
  };
})();
