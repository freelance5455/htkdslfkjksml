window.GameData = {
  createInitialState: function () {
    return {
      clubName: "FIRST STEPS FC",
      slogan: "BUILD. COMPETE. DOMINATE.",
      year: 2026,
      day: 2,
      balance: 50000,
      isOwner: false,
      tactic: "balanced",
      sponsorLevel: 1,
      reputation: 1,
      matchIndex: 0,
      lastRealDate: "",
      lastClaimDate: "",
      loginStreak: 0,
      dailyMatchPlayedDate: "",

      squad: [
        { id: "p1", name: "Berat Zwijsen", flag: "🇳🇱", nationality: "Netherlands", pos: "CB", fullPos: "Centre Back", ovr: 56, potential: "EXCELLENT", age: 21, height: 190, foot: "Left", wage: 480, value: 78000, team: "first", goals: 0, apps: 1, totalFootball: 51, pragmatic: 51 },
        { id: "p2", name: "Nicklas Edman", flag: "🇸🇪", nationality: "Sweden", pos: "ST", fullPos: "Striker", ovr: 61, potential: "ELITE", age: 23, height: 184, foot: "Right", wage: 590, value: 95000, team: "first", goals: 1, apps: 1, totalFootball: 62, pragmatic: 58 },
        { id: "p3", name: "Andrés Gras", flag: "🇪🇸", nationality: "Spain", pos: "CM", fullPos: "Central Midfielder", ovr: 58, potential: "EXCELLENT", age: 22, height: 178, foot: "Right", wage: 510, value: 82000, team: "first", goals: 0, apps: 1, totalFootball: 67, pragmatic: 54 },
        { id: "p4", name: "Lukas Weber", flag: "🇩🇪", nationality: "Germany", pos: "GK", fullPos: "Goalkeeper", ovr: 57, potential: "GREAT", age: 25, height: 192, foot: "Right", wage: 460, value: 70000, team: "first", goals: 0, apps: 1, totalFootball: 48, pragmatic: 60 },
        { id: "p5", name: "Mateo Silva", flag: "🇧🇷", nationality: "Brazil", pos: "LW", fullPos: "Left Winger", ovr: 59, potential: "ELITE", age: 20, height: 175, foot: "Left", wage: 520, value: 88000, team: "first", goals: 0, apps: 1, totalFootball: 64, pragmatic: 49 },
        { id: "p6", name: "Kofi Mensah", flag: "🇬🇭", nationality: "Ghana", pos: "CDM", fullPos: "Defensive Mid", ovr: 55, potential: "EXCELLENT", age: 19, height: 182, foot: "Right", wage: 390, value: 64000, team: "first", goals: 0, apps: 1, totalFootball: 53, pragmatic: 61 },
        { id: "p7", name: "Dimas Pratama", flag: "🇮🇩", nationality: "Indonesia", pos: "RB", fullPos: "Right Back", ovr: 54, potential: "EXCELLENT", age: 18, height: 176, foot: "Right", wage: 350, value: 58000, team: "u20", goals: 0, apps: 0, totalFootball: 57, pragmatic: 52 }
      ],

      transferMarket: [
        // --- MEGA BINTANG ---
        { id: "ms1", name: "⭐ Cristiano Ronaldo (CR7)", flag: "🇵🇹", nationality: "Portugal", pos: "ST", fullPos: "Striker", ovr: 95, potential: "ELITE", age: 39, height: 187, foot: "Right", wage: 12000, value: 1800000, totalFootball: 92, pragmatic: 96 },
        { id: "ms2", name: "⭐ Lionel Messi", flag: "🇦🇷", nationality: "Argentina", pos: "RW", fullPos: "Right Winger", ovr: 95, potential: "ELITE", age: 37, height: 170, foot: "Left", wage: 12000, value: 1800000, totalFootball: 99, pragmatic: 90 },
        { id: "ms3", name: "⭐ Kylian Mbappé", flag: "🇫🇷", nationality: "France", pos: "ST", fullPos: "Striker", ovr: 93, potential: "ELITE", age: 27, height: 178, foot: "Right", wage: 10500, value: 2400000, totalFootball: 93, pragmatic: 91 },
        { id: "ms4", name: "⭐ Erling Haaland", flag: "🇳🇴", nationality: "Norway", pos: "ST", fullPos: "Striker", ovr: 92, potential: "ELITE", age: 26, height: 194, foot: "Left", wage: 9800, value: 2200000, totalFootball: 88, pragmatic: 95 },
        { id: "ms5", name: "⭐ Neymar Jr", flag: "🇧🇷", nationality: "Brazil", pos: "LW", fullPos: "Left Winger", ovr: 90, potential: "ELITE", age: 34, height: 175, foot: "Right", wage: 9000, value: 1350000, totalFootball: 96, pragmatic: 84 },
        { id: "ms6", name: "⭐ Jude Bellingham", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "CAM", fullPos: "Attacking Mid", ovr: 91, potential: "ELITE", age: 23, height: 186, foot: "Right", wage: 8800, value: 2100000, totalFootball: 92, pragmatic: 92 },

        // --- PEMAIN LEGEND ---
        { id: "lg1", name: "👑 Roberto Carlos [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "LB", fullPos: "Left Back", ovr: 93, potential: "ELITE", age: 28, height: 168, foot: "Left", wage: 8500, value: 1500000, totalFootball: 94, pragmatic: 92 },
        { id: "lg2", name: "👑 Ronaldinho [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "LW", fullPos: "Left Winger", ovr: 95, potential: "ELITE", age: 26, height: 182, foot: "Right", wage: 11000, value: 2100000, totalFootball: 99, pragmatic: 86 },
        { id: "lg3", name: "👑 Zinedine Zidane [LEGEND]", flag: "🇫🇷", nationality: "France", pos: "CAM", fullPos: "Attacking Mid", ovr: 95, potential: "ELITE", age: 29, height: 185, foot: "Right", wage: 11000, value: 2050000, totalFootball: 98, pragmatic: 93 },
        { id: "lg4", name: "👑 Ronaldo R9 [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "ST", fullPos: "Striker", ovr: 96, potential: "ELITE", age: 25, height: 183, foot: "Right", wage: 12500, value: 2600000, totalFootball: 96, pragmatic: 95 },
        { id: "lg5", name: "👑 Paolo Maldini [LEGEND]", flag: "🇮🇹", nationality: "Italy", pos: "CB", fullPos: "Centre Back", ovr: 94, potential: "ELITE", age: 30, height: 186, foot: "Left", wage: 9500, value: 1750000, totalFootball: 91, pragmatic: 99 },
        { id: "lg6", name: "👑 David Beckham [LEGEND]", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "RM", fullPos: "Right Midfielder", ovr: 91, potential: "ELITE", age: 28, height: 183, foot: "Right", wage: 8200, value: 1400000, totalFootball: 92, pragmatic: 90 },
        { id: "lg7", name: "👑 Pelé [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "ST", fullPos: "Striker", ovr: 97, potential: "ELITE", age: 24, height: 173, foot: "Right", wage: 14000, value: 3000000, totalFootball: 99, pragmatic: 96 },

        // --- PEMAIN REGULER ---
        { id: "t1", name: "Aitor Reyes", flag: "🇪🇸", nationality: "Spain", pos: "MR", fullPos: "Right Midfielder", ovr: 63, potential: "ELITE", age: 27, height: 180, foot: "Right", wage: 553, value: 83000, totalFootball: 65, pragmatic: 61 },
        { id: "t2", name: "Gianluigi Bandello", flag: "🇮🇹", nationality: "Italy", pos: "RW", fullPos: "Right Winger", ovr: 56, potential: "EXCELLENT", age: 26, height: 177, foot: "Left", wage: 537, value: 81000, totalFootball: 58, pragmatic: 55 },
        { id: "t3", name: "Håvard Henriksen", flag: "🇳🇴", nationality: "Norway", pos: "RW", fullPos: "Right Winger", ovr: 55, potential: "EXCELLENT", age: 18, height: 181, foot: "Right", wage: 613, value: 93000, totalFootball: 60, pragmatic: 50 },
        { id: "t4", name: "Victor Giraud", flag: "🇫🇷", nationality: "France", pos: "MR", fullPos: "Right Midfielder", ovr: 53, potential: "GREAT", age: 36, height: 179, foot: "Right", wage: 441, value: 65000, totalFootball: 54, pragmatic: 63 },
        { id: "t5", name: "Shaun Robinson", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "ML", fullPos: "Left Midfielder", ovr: 59, potential: "EXCELLENT", age: 25, height: 183, foot: "Left", wage: 533, value: 80000, totalFootball: 56, pragmatic: 59 }
      ],

      facilities: {
        stadium: { name: "Stadium", level: 1, maxLevel: 50, capacity: 2000, capacityStep: 1500, cost: 20500 },
        foodStands: { name: "Food Stands", level: 0, maxLevel: 10, perAttendee: 0, step: 0.30, cost: 100000 },
        merchShops: { name: "Merchandise Shops", level: 0, maxLevel: 10, perAttendee: 0, step: 0.20, cost: 125000 }
      },

      academies: [
        { id: "ac1", country: "Ghana", flag: "🇬🇭", tier: "Poor academy", level: 1, maxLevel: 5, upkeep: 2000, nextCost: 200000 }
      ],

      availableAcademies: [
        { id: "av_br", country: "Brazil", flag: "🇧🇷", cost: 250000, upkeep: 2500 },
        { id: "av_id", country: "Indonesia", flag: "🇮🇩", cost: 150000, upkeep: 1500 },
        { id: "av_es", country: "Spain", flag: "🇪🇸", cost: 300000, upkeep: 3000 },
        { id: "av_jp", country: "Japan", flag: "🇯🇵", cost: 220000, upkeep: 2200 }
      ],

      properties: [
        { id: "prop1", name: "House Portfolio", price: 2100000, income: 9209, owned: 0, icon: "🏡" },
        { id: "prop2", name: "Apartment Building", price: 7000000, income: 35794, owned: 0, icon: "🏢" },
        { id: "prop3", name: "Office Building", price: 16800000, income: 103171, owned: 0, icon: "🏙️" },
        { id: "prop4", name: "Shopping Mall", price: 42000000, income: 333608, owned: 0, icon: "🏬" }
      ],

      crypto: [
        { symbol: "AVAX", name: "Avalanche", price: 8.61, change: 20.94, owned: 0, icon: "🔺" },
        { symbol: "BNB", name: "BNB", price: 572.52, change: -1.37, owned: 0, icon: "🟡" },
        { symbol: "ETH", name: "Ethereum", price: 2410.80, change: 4.12, owned: 0, icon: "💎" },
        { symbol: "BTC", name: "Bitcoin", price: 68450.00, change: 2.35, owned: 0, icon: "₿" }
      ],

      league: [
        { id: "me", name: "FIRST STEPS FC", rating: 57, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 },
        { id: "c2", name: "Stoevie United", rating: 56, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 },
        { id: "c3", name: "Deirdre FC", rating: 59, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 },
        { id: "c4", name: "Northbridge Athletic", rating: 55, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 },
        { id: "c5", name: "Valoria City", rating: 60, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 },
        { id: "c6", name: "Ironwood Rovers", rating: 54, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 }
      ],

      matchHistory: [],
      inbox: [
        { day: 1, title: "Welcome Chairman!", body: "Mulai dari £50,000! Latih pemain, atur taktik, dan rekrut Legend & Mega Bintang." }
      ]
    };
  }
};
