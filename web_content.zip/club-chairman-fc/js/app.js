window.App = (function () {
  let view = "home", squadTab = "first", finTab = "overview", propTab = "available", facTab = "stadium", acTab = "owned", selPlayer = null, cTimer = null;

  function init() {
    GameEngine.load();
    if (window.SuperUpdate && SuperUpdate.ensureState) SuperUpdate.ensureState();
    LiveOnline.start(updateLiveBar);
    render();
    if (window.FeaturesPro && FeaturesPro.scheduleAutoSplash) FeaturesPro.scheduleAutoSplash();
  }

  function updateLiveBar(s) {
    const dot = document.getElementById("online-dot"), clk = document.getElementById("live-clock"), rst = document.getElementById("next-reset");
    if (dot) { dot.textContent = s.isOnline ? "● LIVE ONLINE" : "○ OFFLINE MODE"; dot.className = "status-pill " + (s.isOnline ? "online" : "offline"); }
    if (clk) clk.textContent = "🕒 " + s.clock;
    if (rst) rst.textContent = "Reset: " + s.countdownMidnight;
    if (view === "finances" && finTab === "crypto") refreshCryptoDom();
  }

  function refreshCryptoDom() {
    GameEngine.getState().crypto.forEach(function (c) {
      const pEl = document.getElementById("price-" + c.symbol), cEl = document.getElementById("chg-" + c.symbol);
      if (pEl) pEl.textContent = "£" + c.price.toFixed(2);
      if (cEl) { cEl.textContent = (c.change >= 0 ? "+" : "") + c.change.toFixed(2) + "%"; cEl.className = c.change >= 0 ? "pct-up" : "pct-down"; }
      updateCryptoPreview(c.symbol);
    });
  }

  function showToast(msg) {
    const el = document.getElementById("toast");
    if (!el) return;
    el.textContent = msg;
    el.classList.remove("hidden");
    clearTimeout(el._t);
    el._t = setTimeout(function () { el.classList.add("hidden"); }, 2500);
  }

  function stopTimers() { LiveMatch.stop(); if (cTimer) { clearInterval(cTimer); cTimer = null; } }
  function navigate(v) { stopTimers(); view = v; render(); window.scrollTo(0, 0); }
  function goHome() { navigate("home"); }

  function nextDay() {
    const r = GameEngine.advanceDay();
    showToast("Day " + GameEngine.getState().day + " | Cashflow: " + (r.net >= 0 ? "+" : "") + GameEngine.formatMoney(r.net));
    render();
  }

  function render() {
    const back = document.getElementById("btn-back"), title = document.getElementById("top-title"), box = document.getElementById("view-container");
    if (!box) return;
    if (back) back.classList.toggle("hidden", view === "home");
    const titles = { home: "CLUB CHAIRMAN", club: "CLUB & SPONSOR", squad: "SQUAD", player: "PLAYER", matchCenter: "MATCH CENTER", liveMatch: "CLUBCHAIRMAN LIVE", competitions: "COMPETITIONS", transfers: "TRANSFERS", finances: "FINANCES", facilities: "FACILITIES", boardroom: "BOARDROOM", extra: "MISSIONS & BANK", staff: "PELATIH & ASISTEN", featuresPro: "STARTER XI & SIM", superUpdate: "REDEEM & PACK", coolHub: "CUP, SPIN & LOGO" };
    if (title) title.textContent = titles[view] || "CLUB CHAIRMAN";

    if (view === "home") box.innerHTML = renderHome();
    else if (view === "club") box.innerHTML = renderClub();
    else if (view === "squad") box.innerHTML = renderSquad();
    else if (view === "player") box.innerHTML = renderPlayerDetail();
    else if (view === "matchCenter") box.innerHTML = renderMatchCenter();
    else if (view === "liveMatch") box.innerHTML = renderLiveMatch();
    else if (view === "competitions") box.innerHTML = renderCompetitions();
    else if (view === "transfers") box.innerHTML = renderTransfers();
    else if (view === "finances") { box.innerHTML = renderFinances(); if (finTab === "crypto") startCryptoTicker(); }
    else if (view === "facilities") box.innerHTML = renderFacilities();
    else if (view === "boardroom") box.innerHTML = renderBoardroom();
    else if (view === "extra") box.innerHTML = window.ExtraHub ? ExtraHub.render() : '<div class="card">extra.js belum dimuat.</div>';
    else if (view === "staff") box.innerHTML = window.StaffHub ? StaffHub.render() : '<div class="card">staff.js belum dimuat.</div>';
    else if (view === "featuresPro") box.innerHTML = window.FeaturesPro ? FeaturesPro.render() : '<div class="card">featuresPro.js belum dimuat.</div>';
    else if (view === "superUpdate") box.innerHTML = window.SuperUpdate ? SuperUpdate.render() : '<div class="card">superUpdate.js belum dimuat.</div>';
    else if (view === "coolHub") box.innerHTML = window.CoolHub ? CoolHub.render() : '<div class="card">coolFeatures.js belum dimuat.</div>';

    if (view === "home" && window.CoolHub && CoolHub.applyCrestStyle) CoolHub.applyCrestStyle();
  }
  function renderHome() {
    const st = GameEngine.getState(), str = GameEngine.getSquadStrength(), today = LiveOnline.getTodayDateStr();
    const canClaim = st.lastClaimDate !== today, streak = canClaim ? ((st.loginStreak % 7) + 1) : st.loginStreak, rew = 15000 + streak * 10000;
    const alertHtml = window.FeaturesPro && FeaturesPro.getHomeBannerNote ? FeaturesPro.getHomeBannerNote() : "";
    const splashHtml = window.FeaturesPro && FeaturesPro.renderSplashOverlay ? FeaturesPro.renderSplashOverlay(st.clubName) : "";
    return `<section class="club-banner">
      <div class="banner-top"><div class="club-identity"><div class="club-crest">${st.isOwner ? "👑" : "FC"}</div><div><div class="club-name">${st.clubName}</div><div class="club-slogan">— ${st.slogan}</div></div></div><div class="day-pill">📅 ${st.year} · Day ${st.day}</div></div>
      <div class="banner-stats">
        <div class="stat-box"><div class="stat-label">BALANCE</div><div class="stat-value">${GameEngine.formatMoney(st.balance)}</div></div>
        <div class="stat-box"><div class="stat-label">CLUB REP</div><div class="stat-value">🏅 ${st.reputation}</div></div>
        <div class="stat-box"><div class="stat-label">SQUAD STR</div><div class="ovr-inline"><span class="ovr-hex">${str}</span><span style="font-size:11px;color:#4ade80;">OVR</span></div></div>
      </div></section>
      ${alertHtml}
      <section class="daily-checkin-card">
        <div><div style="font-size:13px;font-weight:900;color:var(--gold);">🎁 DAILY ONLINE BONUS (Day ${streak}/7)</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">${canClaim ? "Klaim sponsor " + GameEngine.formatMoney(rew) : "Sudah diklaim hari ini!"}</div></div>
        <button class="btn-gold" onclick="App.handleClaimDaily()" ${canClaim ? "" : "disabled"}>${canClaim ? "Claim" : "✓ Done"}</button>
      </section>
      <div class="card" style="border-color:#f472b6;cursor:pointer;display:flex;justify-content:space-between;align-items:center;" onclick="App.navigate('superUpdate')">
        <div><div style="font-size:14px;font-weight:900;color:#f9a8d4;">🎁 Redeem Code, Bursa Pro, Pack &amp; Trofi</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">Klaim kode hadiah, filter pemain Pemula–Legenda, buka Pack &amp; Trofi Liga.</div></div><span style="font-size:18px;color:#f9a8d4;">▸</span>
      </div>
      <div class="card" style="border-color:#c084fc;cursor:pointer;display:flex;justify-content:space-between;align-items:center;" onclick="App.navigate('coolHub')">
        <div><div style="font-size:14px;font-weight:900;color:#d8b4fe;">🏆 Champions Cup, Lucky Spin, Media &amp; Logo</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">Turnamen knockout Eropa, roda hadiah, konferensi pers &amp; custom logo.</div></div><span style="font-size:18px;color:#d8b4fe;">▸</span>
      </div>
      <section class="menu-grid">
        <div class="menu-card" onclick="App.navigate('club')"><div class="menu-icon">🏛️</div><div class="menu-title">Club</div><div class="menu-desc">Identity &amp; daily sponsor.</div></div>
        <div class="menu-card green-tint" onclick="App.navigate('squad')"><div class="menu-icon">👕</div><div class="menu-title">Squad</div><div class="menu-desc">Roster, training &amp; youth.</div></div>
        <div class="menu-card green-tint" onclick="App.navigate('matchCenter')"><div class="menu-icon">📺</div><div class="menu-title">Match Center</div><div class="menu-desc">Tactics &amp; live games.</div></div>
        <div class="menu-card" onclick="App.navigate('competitions')"><div class="menu-icon">🏆</div><div class="menu-title">Competitions</div><div class="menu-desc">League standings.</div></div>
        <div class="menu-card highlight" onclick="App.navigate('transfers')"><span class="badge-count">${st.transferMarket.length}</span><div class="menu-icon">📝</div><div class="menu-title">Transfers</div><div class="menu-desc">Legends &amp; Mega Stars.</div></div>
        <div class="menu-card highlight green-tint" onclick="App.navigate('finances')"><span class="badge-count">${st.crypto.length}</span><div class="menu-icon">💵</div><div class="menu-title">Finances</div><div class="menu-desc">Property, crypto &amp; wages.</div></div>
        <div class="menu-card" onclick="App.navigate('facilities')"><div class="menu-icon">🏟️</div><div class="menu-title">Facilities</div><div class="menu-desc">Stadium &amp; academies.</div></div>
        <div class="menu-card green-tint" onclick="App.navigate('boardroom')"><span class="badge-count">${st.inbox.length}</span><div class="menu-icon">💼</div><div class="menu-title">Boardroom</div><div class="menu-desc">Owner code &amp; inbox.</div></div>
      </section>
      <div class="card" style="border-color:var(--gold);cursor:pointer;display:flex;justify-content:space-between;align-items:center;" onclick="App.navigate('extra')">
        <div><div style="font-size:14px;font-weight:900;color:var(--gold);">🎯 Missions, Scout, Bank &amp; Backup</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">Klaim hadiah misi, cari pemain baru, pinjaman bank &amp; backup save.</div></div><span style="font-size:18px;color:var(--gold);">▸</span>
      </div>
      <div class="card" style="border-color:#4ade80;cursor:pointer;display:flex;justify-content:space-between;align-items:center;" onclick="App.navigate('staff')">
        <div><div style="font-size:14px;font-weight:900;color:#4ade80;">👔 Pelatih &amp; Asisten (Pro – Legend)</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">Rekrut Pep, Klopp, Sir Alex Ferguson, Johan Cruyff &amp; Asisten Legend.</div></div><span style="font-size:18px;color:#4ade80;">▸</span>
      </div>
      <div class="card" style="border-color:#60a5fa;cursor:pointer;display:flex;justify-content:space-between;align-items:center;" onclick="App.navigate('featuresPro')">
        <div><div style="font-size:14px;font-weight:900;color:#93c5fd;">📋 Starter XI, Training Camp &amp; Quick Sim</div><div style="font-size:11px;color:var(--text-muted);margin-top:2px;">Atur pemain inti, latihan tim harian &amp; simulasi cepat.</div></div><span style="font-size:18px;color:#93c5fd;">▸</span>
      </div>
      ${splashHtml}`;
  }

  function renderSquad() {
    const st = GameEngine.getState();
    const fCnt = st.squad.filter(function (p) { return p.team === "first"; }).length;
    const uCnt = st.squad.filter(function (p) { return p.team === "u20"; }).length;
    const list = st.squad.filter(function (p) { return p.team === squadTab; });
    const cards = list.length ? list.map(function (p) {
      const pc = p.potential === "ELITE" ? "pot-elite" : p.potential === "EXCELLENT" ? "pot-excellent" : "pot-great";
      return `<div class="player-card" onclick="App.openPlayer('${p.id}')"><div class="player-avatar">🧑🏽‍🦱</div><div class="player-info"><div class="player-name">${p.flag} ${p.name}</div><span class="pot-badge ${pc}">${p.potential}</span><div class="player-meta"><span>Age ${p.age}</span><span>£${p.wage}/day</span></div></div><div class="player-right"><div class="ovr-shield"><span class="ovr-num">${p.ovr}</span><span class="ovr-txt">OVR</span></div><span class="pos-pill">${p.pos}</span></div></div>`;
    }).join("") : '<div class="card">Belum ada pemain.</div>';
    return `<div class="sub-tabs"><button class="tab-btn ${squadTab === "first" ? "active" : ""}" onclick="App.setSquadTab('first')">First Team (${fCnt})</button><button class="tab-btn ${squadTab === "u20" ? "active" : ""}" onclick="App.setSquadTab('u20')">U20 (${uCnt})</button></div>${cards}`;
  }

  function openPlayer(id) { selPlayer = id; view = "player"; render(); }

  function renderPlayerDetail() {
    const st = GameEngine.getState(), p = st.squad.find(function (x) { return x.id === selPlayer; });
    if (!p) return '<div class="card">Pemain tidak ditemukan.</div>';
    const trainCost = p.ovr * 250;
    return `<div class="card"><div style="display:flex;align-items:center;gap:12px;"><div class="player-avatar" style="width:68px;height:78px;font-size:34px;">🧑🏽‍🦱</div><div style="flex:1;"><div style="font-size:18px;font-weight:900;">${p.name}</div><div style="font-size:12px;color:var(--text-muted);margin-top:4px;">${p.flag} Age ${p.age} · ${p.fullPos}</div></div><div class="ovr-shield"><span class="ovr-num">${p.ovr}</span><span class="ovr-txt">OVR</span></div></div>
      <button class="btn-gold" style="width:100%;margin-top:12px;" onclick="App.handleTrainPlayer('${p.id}')" ${st.balance < trainCost || p.ovr >= 99 ? "disabled" : ""}>🏋️ Train +1 OVR (${GameEngine.formatMoney(trainCost)})</button>
      <div class="sub-tabs" style="margin-top:8px;margin-bottom:0;"><button class="btn-outline" onclick="App.handleToggleTeam('${p.id}')">${p.team === "first" ? "Move to U20" : "To First Team"}</button><button class="btn-danger" onclick="App.handleSellPlayer('${p.id}')">Sell (${GameEngine.formatMoney(p.value * 0.85)})</button></div></div>
      <div class="card"><div class="section-title" style="margin-bottom:8px;">PLAYER DETAILS</div><div class="detail-grid"><div class="detail-item"><small>AGE</small><strong>${p.age}</strong></div><div class="detail-item"><small>POSITION</small><strong>${p.fullPos}</strong></div><div class="detail-item"><small>HEIGHT</small><strong>${p.height} cm</strong></div><div class="detail-item"><small>FOOT</small><strong>${p.foot}</strong></div><div class="detail-item"><small>NATION</small><strong>${p.flag} ${p.nationality}</strong></div><div class="detail-item"><small>CLUB</small><strong>${st.clubName}</strong></div></div></div>`;
  }

  function renderTransfers() {
    const st = GameEngine.getState();
    const list = st.transferMarket.length ? st.transferMarket.map(function (p) {
      return `<div class="card"><div style="display:flex;align-items:center;gap:12px;"><div class="player-avatar">⚽</div><div class="player-info"><div class="player-name">${p.flag} ${p.name}</div><div class="player-meta"><span>Age ${p.age}</span><span>Wage £${p.wage}/d</span></div><div class="player-meta"><span>Clause: <strong style="color:#fff;">${GameEngine.formatMoney(p.value)}</strong></span></div></div><div class="player-right"><div class="ovr-shield"><span class="ovr-num">${p.ovr}</span><span class="ovr-txt">OVR</span></div><span class="pos-pill">${p.pos}</span></div></div><button class="btn-gold" style="width:100%;margin-top:10px;" onclick="App.handleBuyTransfer('${p.id}')" ${st.balance < p.value ? "disabled" : ""}>Sign (${GameEngine.formatMoney(p.value)})</button></div>`;
    }).join("") : '<div class="card">Semua target transfer telah direkrut.</div>';
    return `<div class="card" style="display:flex;justify-content:space-between;"><span>Transfer Budget</span><strong style="color:var(--gold);">${GameEngine.formatMoney(st.balance)}</strong></div>${list}`;
  }
  function getNextOpp() {
    const st = GameEngine.getState(), rivals = st.league.filter(function (c) { return c.id !== "me"; });
    return rivals[st.matchIndex % rivals.length];
  }

  function renderMatchCenter() {
    const st = GameEngine.getState(), opp = getNextOpp();
    const hist = st.matchHistory.length ? st.matchHistory.slice(0, 6).map(function (m) {
      return `<div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-subtle);font-size:12px;"><span>Day ${m.day}: <strong>${m.home}</strong> ${m.score} ${m.away}</span><span style="color:#4ade80;">+${GameEngine.formatMoney(m.income)}</span></div>`;
    }).join("") : '<div style="font-size:12px;color:var(--text-muted);">Belum ada pertandingan.</div>';
    return `<div class="card"><div class="section-title" style="margin-bottom:8px;">MATCH TACTIC</div>
      <div class="sub-tabs" style="margin-bottom:0;">
        <button class="tab-btn ${st.tactic === "attack" ? "active" : ""}" onclick="App.handleSetTactic('attack')">⚔️ Attack</button>
        <button class="tab-btn ${st.tactic === "balanced" ? "active" : ""}" onclick="App.handleSetTactic('balanced')">⚖️ Balanced</button>
        <button class="tab-btn ${st.tactic === "defense" ? "active" : ""}" onclick="App.handleSetTactic('defense')">🛡️ Defense</button>
      </div></div>
      <div class="card"><div class="section-title">NEXT FIXTURE</div><div style="display:flex;justify-content:space-between;align-items:center;margin:12px 0;padding:12px;background:rgba(0,0,0,0.35);border-radius:12px;"><div style="text-align:center;flex:1;"><div style="font-weight:900;color:#4ade80;">${st.clubName}</div><small>OVR ${GameEngine.getSquadStrength()}</small></div><div style="font-weight:900;color:var(--gold);">VS</div><div style="text-align:center;flex:1;"><div style="font-weight:900;color:#facc15;">${opp.name}</div><small>OVR ${opp.rating}</small></div></div><button class="btn-gold" style="width:100%;" onclick="App.startLiveMatch()">▶ Start Live Match</button></div>
      <div class="card"><div class="section-title" style="margin-bottom:8px;">LATEST MATCHES</div>${hist}</div>`;
  }

  function startLiveMatch() {
    view = "liveMatch";
    LiveMatch.start(getNextOpp(), function () {
      if (view === "liveMatch") { const b = document.getElementById("view-container"); if (b) b.innerHTML = renderLiveMatch(); }
    });
    render();
  }

  function renderLiveMatch() {
    const m = LiveMatch.getMatch();
    if (!m) return '<div class="card">Tidak ada pertandingan aktif.</div>';
    const ap = 100 - m.pressureHome, apos = 100 - m.possessionHome;
    const ctrl = m.finished ? '<button class="btn-gold" style="width:100%;" onclick="App.navigate(\'matchCenter\')">Selesai & Kembali</button>' : `<button class="tab-btn" onclick="LiveMatch.togglePause()">${m.paused ? "▶ Resume" : "⏸ Pause"}</button><button class="tab-btn" onclick="LiveMatch.setSpeed(1)">1x</button><button class="tab-btn" onclick="LiveMatch.setSpeed(2)">2x</button><button class="tab-btn" onclick="LiveMatch.setSpeed(4)">4x</button>`;
    const rev = m.settlement ? `<div class="card" style="border-color:var(--gold);"><div class="section-title" style="color:var(--gold);">MATCHDAY REVENUE</div><div style="font-size:12px;margin-top:4px;">Penonton: <strong>${m.settlement.attendance.toLocaleString()}</strong> · Pemasukan: <strong style="color:#4ade80;">+${GameEngine.formatMoney(m.settlement.totalMatchIncome)}</strong></div></div>` : "";
    const evs = m.events.length ? m.events.map(function (e) { return `<div class="event-row ${e.type === "goal" ? "goal" : ""}"><div class="event-min">${e.min}'</div><div><div>${e.icon} <strong>${e.text}</strong></div><div style="font-size:11px;color:var(--text-muted);">${e.team}</div></div></div>`; }).join("") : '<div style="font-size:12px;color:var(--text-muted);">Menunggu momen...</div>';
    return `<div class="live-scoreboard"><div class="team-side team-home">${m.homeName}</div><div class="score-center"><div class="match-min">${m.minute}'</div><div class="score-big">${m.homeGoals} - ${m.awayGoals}</div></div><div class="team-side team-away">${m.awayName}</div></div>
      <div style="display:flex;gap:8px;justify-content:center;">${ctrl}</div>
      <div class="commentary-banner ${m.bannerIsGoal ? "" : "normal"}"><div style="font-size:18px;">${m.bannerTitle}</div><div style="font-size:12px;margin-top:4px;">${m.bannerSub}</div></div>${rev}
      <div class="card"><div style="font-size:11px;color:var(--text-muted);font-weight:700;">LAST 5 MINUTES PRESSURE</div><div class="pressure-bar"><div class="pressure-home" style="width:${m.pressureHome}%"></div><div class="pressure-away" style="width:${ap}%"></div></div><div style="display:flex;justify-content:space-between;font-size:11px;font-weight:700;"><span>${m.pressureHome}% ${m.homeName}</span><span>${ap}% ${m.awayName}</span></div></div>
      <div class="live-stats-grid"><div class="live-stat-cell"><small>POSSESSION</small><strong>${m.possessionHome}%-${apos}%</strong></div><div class="live-stat-cell"><small>SHOTS</small><strong>${m.shotsHome}-${m.shotsAway}</strong></div><div class="live-stat-cell"><small>ON TARGET</small><strong>${m.onTargetHome}-${m.onTargetAway}</strong></div><div class="live-stat-cell"><small>CORNERS</small><strong>${m.cornersHome}-${m.cornersAway}</strong></div></div>
      <div class="card"><div class="section-title" style="margin-bottom:8px;">MATCH EVENTS</div><div class="event-feed">${evs}</div></div>`;
  }

  function renderCompetitions() {
    const sorted = GameEngine.getState().league.slice().sort(function (a, b) { return b.pts - a.pts || (b.gf - b.ga) - (a.gf - a.ga); });
    const rows = sorted.map(function (c, i) { return `<tr class="${c.id === "me" ? "me" : ""}"><td>${i + 1}</td><td>${c.name}</td><td>${c.p}</td><td>${c.w}</td><td>${c.d}</td><td>${c.l}</td><td>${c.gf - c.ga}</td><td><strong>${c.pts}</strong></td></tr>`; }).join("");
    return `<div class="card"><div class="section-title" style="margin-bottom:8px;">LEAGUE STANDINGS</div><table class="league-table"><thead><tr><th>#</th><th>Club</th><th>P</th><th>W</th><th>D</th><th>L</th><th>GD</th><th>PTS</th></tr></thead><tbody>${rows}</tbody></table></div>`;
  }

  function startCryptoTicker() {
    if (cTimer) clearInterval(cTimer);
    cTimer = setInterval(function () {
      if (view !== "finances" || finTab !== "crypto") { clearInterval(cTimer); cTimer = null; return; }
      if (LiveOnline.getStatus().cryptoSource !== "LIVE ONLINE") GameEngine.tickCryptoPrices();
      refreshCryptoDom();
    }, 4000);
  }

  function renderFinances() {
    const st = GameEngine.getState();
    let body = "";
    if (finTab === "overview") {
      const inc = GameEngine.getDailyPropertyIncome(), sp = GameEngine.getDailySponsorIncome(), w = GameEngine.getDailyWages(), u = GameEngine.getDailyUpkeep(), net = inc + sp - w - u;
      body = `<div class="card"><div class="section-title" style="margin-bottom:8px;">DAILY CASHFLOW</div><div class="detail-grid"><div class="detail-item"><small>SPONSOR & ASISTEN</small><strong style="color:#4ade80;">+${GameEngine.formatMoney(sp)}/d</strong></div><div class="detail-item"><small>PROPERTY</small><strong style="color:#4ade80;">+${GameEngine.formatMoney(inc)}/d</strong></div><div class="detail-item"><small>WAGES</small><strong style="color:#f87171;">-${GameEngine.formatMoney(w)}/d</strong></div><div class="detail-item"><small>UPKEEP</small><strong style="color:#f87171;">-${GameEngine.formatMoney(u)}/d</strong></div></div><div style="margin-top:10px;font-weight:800;">Net: <span style="color:${net >= 0 ? "#4ade80" : "#f87171"};">${net >= 0 ? "+" : ""}${GameEngine.formatMoney(net)}/day</span></div></div>`;
    } else if (finTab === "property") {
      const list = propTab === "owned" ? st.properties.filter(function (x) { return x.owned > 0; }) : st.properties;
      const items = list.length ? list.map(function (p) {
        return `<div class="card"><div style="display:flex;align-items:center;gap:10px;"><div class="player-avatar" style="width:46px;height:46px;">${p.icon}</div><div><div style="font-weight:800;">${p.name}</div><div style="font-size:11px;color:var(--text-muted);">Owned: ${p.owned}</div></div></div><div class="asset-row"><div class="metric-group"><div class="metric"><small>PRICE</small><strong>${GameEngine.formatMoney(p.price)}</strong></div><div class="metric"><small>INCOME</small><strong style="color:#4ade80;">${GameEngine.formatMoney(p.income)}/d</strong></div></div><button class="btn-gold" onclick="App.handleBuyProperty('${p.id}')" ${st.balance < p.price ? "disabled" : ""}>Buy &gt;</button></div></div>`;
      }).join("") : '<div class="card">Belum ada properti.</div>';
      body = `<div class="sub-tabs"><button class="tab-btn ${propTab === "available" ? "active" : ""}" onclick="App.setPropertyTab('available')">Available</button><button class="tab-btn ${propTab === "owned" ? "active" : ""}" onclick="App.setPropertyTab('owned')">Owned</button></div>${items}`;
    } else {
      const coins = st.crypto.map(function (c) {
        return `<div class="card"><div style="display:flex;justify-content:space-between;align-items:center;"><div><strong>${c.icon} ${c.name} (${c.symbol})</strong><div style="font-size:11px;color:var(--text-muted);">Owned: ${c.owned}</div></div><span id="chg-${c.symbol}" class="${c.change >= 0 ? "pct-up" : "pct-down"}">${c.change >= 0 ? "+" : ""}${c.change.toFixed(2)}%</span></div><div id="price-${c.symbol}" style="font-size:20px;font-weight:900;margin-top:6px;">£${c.price.toFixed(2)}</div><input id="qty-${c.symbol}" type="number" step="0.1" min="0.01" value="1" class="input-box" oninput="App.updateCryptoPreview('${c.symbol}')" /><div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:8px;"><span>Est. cost</span><strong id="est-${c.symbol}">£${c.price.toFixed(2)}</strong></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;"><button class="btn-gold" onclick="App.handleCrypto('${c.symbol}','buy')">Buy</button><button class="btn-outline" onclick="App.handleCrypto('${c.symbol}','sell')">Sell</button></div></div>`;
      }).join("");
      body = `<div class="card" style="display:flex;justify-content:space-between;"><span style="font-size:12px;color:#4ade80;">● ${LiveOnline.getStatus().cryptoSource}</span><strong style="color:var(--gold);">${GameEngine.formatMoney(st.balance)}</strong></div>${coins}`;
    }
    return `<div class="sub-tabs"><button class="tab-btn ${finTab === "overview" ? "active" : ""}" onclick="App.setFinanceTab('overview')">Overview</button><button class="tab-btn ${finTab === "property" ? "active" : ""}" onclick="App.setFinanceTab('property')">Property</button><button class="tab-btn ${finTab === "crypto" ? "active" : ""}" onclick="App.setFinanceTab('crypto')">Live Crypto</button></div>${body}`;
  }

  function updateCryptoPreview(sym) {
    const coin = GameEngine.getState().crypto.find(function (c) { return c.symbol === sym; });
    const inp = document.getElementById("qty-" + sym), est = document.getElementById("est-" + sym);
    if (coin && inp && est) est.textContent = "£" + (Math.max(0, parseFloat(inp.value) || 0) * coin.price).toFixed(2);
  }
  function renderFacilities() {
    const st = GameEngine.getState();
    let content = "";
    if (facTab === "stadium") {
      const f = st.facilities;
      content = `<div class="card"><strong>🏟️ ${f.stadium.name}</strong><div class="asset-row"><div class="metric-group"><div class="metric"><small>CAP</small><strong>${f.stadium.capacity.toLocaleString()}</strong></div><div class="metric"><small>LVL</small><strong>${f.stadium.level}/${f.stadium.maxLevel}</strong></div></div><button class="btn-gold" onclick="App.handleUpgradeFacility('stadium')" ${st.balance < f.stadium.cost ? "disabled" : ""}>Upgrade (${GameEngine.formatMoney(f.stadium.cost)})</button></div></div>
        <div class="card"><strong>🍔 ${f.foodStands.name}</strong><div class="asset-row"><div class="metric-group"><div class="metric"><small>LVL</small><strong>${f.foodStands.level}/${f.foodStands.maxLevel}</strong></div><div class="metric"><small>£/ATT</small><strong>£${f.foodStands.perAttendee.toFixed(2)}</strong></div></div><button class="btn-gold" onclick="App.handleUpgradeFacility('foodStands')" ${st.balance < f.foodStands.cost ? "disabled" : ""}>Upgrade (${GameEngine.formatMoney(f.foodStands.cost)})</button></div></div>
        <div class="card"><strong>🛍️ ${f.merchShops.name}</strong><div class="asset-row"><div class="metric-group"><div class="metric"><small>LVL</small><strong>${f.merchShops.level}/${f.merchShops.maxLevel}</strong></div><div class="metric"><small>£/ATT</small><strong>£${f.merchShops.perAttendee.toFixed(2)}</strong></div></div><button class="btn-gold" onclick="App.handleUpgradeFacility('merchShops')" ${st.balance < f.merchShops.cost ? "disabled" : ""}>Upgrade (${GameEngine.formatMoney(f.merchShops.cost)})</button></div></div>`;
    } else {
      const list = acTab === "owned" ? st.academies.map(function (a) {
        return `<div class="card"><strong>${a.flag} ${a.country}</strong> <small style="color:var(--text-muted);">(${a.tier})</small><div class="bar-track"><div class="bar-fill" style="width:${(a.level / a.maxLevel) * 100}%"></div></div><div class="asset-row"><div class="metric-group"><div class="metric"><small>LVL</small><strong>${a.level}/${a.maxLevel}</strong></div><div class="metric"><small>COST</small><strong>${GameEngine.formatMoney(a.nextCost)}</strong></div></div><button class="btn-gold" onclick="App.handleUpgradeAcademy('${a.id}')" ${st.balance < a.nextCost || a.level >= a.maxLevel ? "disabled" : ""}>Upgrade &gt;</button></div></div>`;
      }).join("") : st.availableAcademies.map(function (av) {
        return `<div class="card"><div class="asset-row" style="margin-top:0;"><div><strong>${av.flag} ${av.country}</strong><div style="font-size:11px;color:var(--text-muted);">Upkeep ${GameEngine.formatMoney(av.upkeep)}/d</div></div><button class="btn-gold" onclick="App.handleCreateAcademy('${av.id}')" ${st.balance < av.cost || st.academies.length >= 3 ? "disabled" : ""}>Build (${GameEngine.formatMoney(av.cost)})</button></div></div>`;
      }).join("");
      content = `<div class="card"><div class="section-title">Foreign Academies (${st.academies.length}/3)</div><div style="font-size:11px;color:var(--text-muted);margin-top:4px;">Upkeep: ${GameEngine.formatMoney(GameEngine.getDailyUpkeep())}/day · +${st.academies.length} youth/week</div></div><div class="sub-tabs"><button class="tab-btn ${acTab === "owned" ? "active" : ""}" onclick="App.setAcademyTab('owned')">Your Academies</button><button class="tab-btn ${acTab === "create" ? "active" : ""}" onclick="App.setAcademyTab('create')">Create</button></div>${list}`;
    }
    return `<div class="sub-tabs"><button class="tab-btn ${facTab === "stadium" ? "active" : ""}" onclick="App.setFacilityTab('stadium')">Stadium & Shops</button><button class="tab-btn ${facTab === "academies" ? "active" : ""}" onclick="App.setFacilityTab('academies')">Academies</button></div>${content}`;
  }

  function renderClub() {
    const st = GameEngine.getState(), spCost = st.sponsorLevel * 45000;
    return `<div class="card"><div class="section-title" style="margin-bottom:8px;">CLUB IDENTITY</div><input id="club-name-input" class="input-box" value="${st.clubName}" maxlength="24" /><button class="btn-gold" onclick="App.handleRenameClub()">Simpan Nama</button></div>
      <div class="card"><div class="section-title">🤝 SPONSOR CONTRACT (Lv.${st.sponsorLevel}/10)</div><div style="font-size:12px;color:#4ade80;margin:6px 0;">Pemasukan harian: +${GameEngine.formatMoney(GameEngine.getDailySponsorIncome())}/day</div><button class="btn-gold" style="width:100%;" onclick="App.handleUpgradeSponsor()" ${st.balance < spCost || st.sponsorLevel >= 10 ? "disabled" : ""}>Upgrade Sponsor (${GameEngine.formatMoney(spCost)})</button></div>`;
  }

  function renderBoardroom() {
    const st = GameEngine.getState();
    const msgs = st.inbox.slice(0, 12).map(function (m) { return `<div style="padding:8px 0;border-bottom:1px solid var(--border-subtle);"><div style="font-size:13px;font-weight:800;">Day ${m.day} · ${m.title}</div><div style="font-size:12px;color:var(--text-muted);">${m.body}</div></div>`; }).join("");
    const ownerBox = st.isOwner
      ? `<div class="card" style="border-color:var(--gold);"><div class="section-title" style="color:var(--gold);">👑 OWNER PANEL AKTIF</div><button class="btn-gold" style="width:100%;margin-top:8px;" onclick="App.handleOwnerTopup()">+ Tambah £100,000,000</button></div>`
      : `<div class="card"><div class="section-title">🔐 OWNER ACCESS</div><input id="owner-code-input" type="password" placeholder="Masukkan kode rahasia..." class="input-box" /><button class="btn-outline" style="width:100%;" onclick="App.handleOwnerLogin()">Aktifkan Mode Owner</button></div>`;
    return `${ownerBox}<div class="card"><div class="section-header"><div class="section-title">INBOX</div><button class="btn-danger" onclick="App.handleResetGame()">Reset Save</button></div>${msgs}</div>`;
  }

  function setSquadTab(t) { squadTab = t; render(); }
  function setFinanceTab(t) { stopTimers(); finTab = t; render(); }
  function setPropertyTab(t) { propTab = t; render(); }
  function setFacilityTab(t) { facTab = t; render(); }
  function setAcademyTab(t) { acTab = t; render(); }
  function handleClaimDaily() { const r = GameEngine.claimDailyReward(LiveOnline.getTodayDateStr()); showToast(r.msg); render(); }
  function handleBuyTransfer(id) { const r = GameEngine.buyTransferPlayer(id); showToast(r.msg); render(); }
  function handleToggleTeam(id) { const r = GameEngine.togglePlayerTeam(id); showToast(r.msg); render(); }
  function handleSellPlayer(id) { const r = GameEngine.sellPlayer(id); showToast(r.msg); if (r.ok) navigate("squad"); }
  function handleTrainPlayer(id) { const r = GameEngine.trainPlayer(id); showToast(r.msg); render(); }
  function handleSetTactic(t) { const r = GameEngine.setTactic(t); showToast(r.msg); render(); }
  function handleUpgradeSponsor() { const r = GameEngine.upgradeSponsor(); showToast(r.msg); render(); }
  function handleUpgradeFacility(k) { const r = GameEngine.upgradeFacility(k); showToast(r.msg); render(); }
  function handleBuyProperty(id) { const r = GameEngine.buyProperty(id); showToast(r.msg); render(); }
  function handleCrypto(s, a) { const i = document.getElementById("qty-" + s); const r = GameEngine.tradeCrypto(s, i ? i.value : 0, a); showToast(r.msg); render(); }
  function handleUpgradeAcademy(id) { const r = GameEngine.upgradeAcademy(id); showToast(r.msg); render(); }
  function handleCreateAcademy(id) { const r = GameEngine.createAcademy(id); showToast(r.msg); render(); }
  function handleOwnerLogin() { const i = document.getElementById("owner-code-input"); const r = GameEngine.activateOwnerMode(i ? i.value : ""); showToast(r.msg); render(); }
  function handleOwnerTopup() { const r = GameEngine.addOwnerMoney(); showToast(r.msg); render(); }
  function handleRenameClub() {
    const i = document.getElementById("club-name-input"), v = (i ? i.value : "").trim().toUpperCase();
    if (!v) return showToast("Nama klub kosong.");
    const st = GameEngine.getState(); st.clubName = v;
    const row = st.league.find(function (c) { return c.id === "me"; }); if (row) row.name = v;
    GameEngine.save(); showToast("Nama klub diperbarui!"); render();
  }
  function handleResetGame() { if (confirm("Reset semua progress?")) { GameEngine.reset(); showToast("Game di-reset."); goHome(); } }

  if (document.readyState === "loading") window.addEventListener("DOMContentLoaded", init);
  else init();

  return {
    navigate, goHome, nextDay, openPlayer, startLiveMatch, render, showToast,
    setSquadTab, setFinanceTab, setPropertyTab, setFacilityTab, setAcademyTab,
    updateCryptoPreview, handleBuyTransfer, handleToggleTeam, handleSellPlayer,
    handleTrainPlayer, handleSetTactic, handleUpgradeSponsor,
    handleUpgradeFacility, handleBuyProperty, handleCrypto, handleClaimDaily,
    handleUpgradeAcademy, handleCreateAcademy, handleRenameClub, handleResetGame,
    handleOwnerLogin, handleOwnerTopup
  };
})();
