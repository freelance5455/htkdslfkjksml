window.CoolHub = (function () {
  let tab = "cup";
  let lastSpinText = "";

  const CUP_ROUNDS = [
    { round: "Perempat Final", opp: "AC Milan", rating: 76, prize: 150000 },
    { round: "Semifinal", opp: "Bayern Munich", rating: 83, prize: 350000 },
    { round: "FINAL CHAMPIONS", opp: "Real Madrid", rating: 90, prize: 1000000 }
  ];

  const PRESS_QA = [
    {
      q: "Wartawan: Apa target utama klub musim ini, Chairman?",
      opts: [
        { label: "🔥 Sapu bersih semua trofi!", eff: "rep", val: 2, msg: "Fans membara! +2 Club Reputation." },
        { label: "💰 Fokus stabilkan finansial dulu.", eff: "money", val: 45000, msg: "Investor senang! Bonus sponsor +£45,000." },
        { label: "⚽ Percaya penuh pada perkembangan pemain!", eff: "ovr", val: 1, msg: "Skuad termotivasi! 1 pemain naik +1 OVR." }
      ]
    },
    {
      q: "Wartawan: Rival meremehkan kekuatan tim Anda. Tanggapan Anda?",
      opts: [
        { label: "😎 Kita buktikan di lapangan!", eff: "ovr", val: 1, msg: "Mental pemain naik! 1 pemain naik +1 OVR." },
        { label: "🤝 Kami hormati semua lawan.", eff: "rep", val: 1, msg: "Citra klub positif! +1 Club Reputation." },
        { label: "📢 Beli tiket stadion kami & lihat sendiri!", eff: "money", val: 60000, msg: "Penjualan tiket meroket! +£60,000." }
      ]
    },
    {
      q: "Wartawan: Apakah klub siap belanja pemain bintang lagi?",
      opts: [
        { label: "👑 Tentu, pintu selalu terbuka untuk Legend!", eff: "rep", val: 2, msg: "Media heboh! +2 Club Reputation." },
        { label: "💼 Kami cari sponsor baru dulu.", eff: "money", val: 55000, msg: "Sponsor lokal masuk! +£55,000." },
        { label: "🌱 Kami akan maksimalkan pemain yang ada.", eff: "ovr", val: 1, msg: "Pemain makin semangat latihan! +1 OVR acak." }
      ]
    }
  ];

  const COLORS = [
    { name: "Emas", bg: "linear-gradient(135deg,#f59e0b,#b45309)" },
    { name: "Merah", bg: "linear-gradient(135deg,#ef4444,#991b1b)" },
    { name: "Biru", bg: "linear-gradient(135deg,#3b82f6,#1e3a8a)" },
    { name: "Hijau", bg: "linear-gradient(135deg,#22c55e,#14532d)" },
    { name: "Ungu", bg: "linear-gradient(135deg,#a855f7,#581c87)" },
    { name: "Hitam", bg: "linear-gradient(135deg,#334155,#0f172a)" }
  ];

  const ICONS = ["FC", "🦁", "🦅", "🐉", "⚡", "👑", "🔥", "⚽"];
  function ensureState() {
    const st = GameEngine.getState();
    if (typeof st.cupStage !== "number") st.cupStage = 0;
    if (typeof st.cupWon !== "number") st.cupWon = 0;
    if (typeof st.lastPressDay !== "number") st.lastPressDay = 0;
    if (typeof st.lastFreeSpinDay !== "number") st.lastFreeSpinDay = 0;
    if (!st.clubColor) st.clubColor = COLORS[0].bg;
    if (!st.clubIcon) st.clubIcon = "FC";
    if (!Array.isArray(st.trophies)) st.trophies = [];
    return st;
  }

  function setTab(t) { tab = t; App.render(); }

  function playCupMatch() {
    const st = ensureState();
    if (st.cupStage >= 3) {
      st.cupStage = 0;
      GameEngine.save();
      App.showToast("🏆 Turnamen Champions baru dimulai!");
      return App.render();
    }

    const r = CUP_ROUNDS[st.cupStage];
    const myStr = GameEngine.getSquadStrength();
    const diff = myStr - r.rating;
    const winChance = Math.min(0.88, Math.max(0.18, 0.50 + diff * 0.025));
    const won = Math.random() < winChance;

    const myG = won ? (2 + Math.floor(Math.random() * 3)) : Math.floor(Math.random() * 2);
    const oppG = won ? Math.floor(Math.random() * myG) : (myG + 1 + Math.floor(Math.random() * 2));

    if (won) {
      st.balance += r.prize;
      st.cupStage += 1;
      if (st.cupStage === 3) {
        st.cupWon += 1;
        st.reputation += 3;
        st.trophies.unshift({ year: st.year, title: "🏆 Champions Cup #" + st.cupWon, pts: myG + "-" + oppG });
        st.inbox.unshift({ day: st.day, title: "🏆 JUARA CHAMPIONS CUP!", body: "Kalahkan " + r.opp + " (" + myG + "-" + oppG + ")! Hadiah +" + GameEngine.formatMoney(r.prize) });
        App.showToast("🏆 JUARA CHAMPIONS! " + myG + "-" + oppG + " (+" + GameEngine.formatMoney(r.prize) + ")");
      } else {
        App.showToast("✅ Menang " + myG + "-" + oppG + " vs " + r.opp + "! +" + GameEngine.formatMoney(r.prize));
      }
    } else {
      st.cupStage = 0;
      App.showToast("❌ Kalah " + myG + "-" + oppG + " vs " + r.opp + ". Coba lagi di turnamen berikutnya!");
    }

    GameEngine.save();
    App.render();
  }

  function spinWheel(isPaid) {
    const st = ensureState();
    if (!isPaid && st.lastFreeSpinDay === st.day) return App.showToast("Spin gratis hari ini sudah dipakai!");
    if (isPaid) {
      if (st.balance < 25000) return App.showToast("Saldo tidak cukup (£25,000)!");
      st.balance -= 25000;
    } else {
      st.lastFreeSpinDay = st.day;
    }

    const roll = Math.random();
    if (roll < 0.06) {
      st.balance += 500000;
      lastSpinText = "💎 JACKPOT! Kamu menang +£500,000!";
    } else if (roll < 0.22) {
      st.balance += 100000;
      lastSpinText = "💰 Mantap! Hadiah uang +£100,000!";
    } else if (roll < 0.45) {
      const p = st.squad[Math.floor(Math.random() * st.squad.length)];
      if (p && p.ovr < 99) { p.ovr += 1; lastSpinText = "⚡ Boost Latihan! " + p.name + " naik ke " + p.ovr + " OVR!"; }
      else { st.balance += 50000; lastSpinText = "💵 Bonus +£50,000!"; }
    } else if (roll < 0.65) {
      st.reputation += 1;
      lastSpinText = "🏅 Populer! +1 Club Reputation!";
    } else if (roll < 0.85) {
      st.balance += 35000;
      lastSpinText = "💵 Lumayan! Hadiah +£35,000!";
    } else {
      st.balance += 15000;
      lastSpinText = "🪙 Hadiah hiburan +£15,000!";
    }

    GameEngine.save();
    App.showToast(lastSpinText);
    App.render();
  }

  function answerPress(qIdx, oIdx) {
    const st = ensureState();
    if (st.lastPressDay === st.day) return App.showToast("Konferensi pers hari ini sudah selesai!");
    const opt = PRESS_QA[qIdx].opts[oIdx];
    st.lastPressDay = st.day;

    if (opt.eff === "money") st.balance += opt.val;
    else if (opt.eff === "rep") st.reputation += opt.val;
    else if (opt.eff === "ovr") {
      const p = st.squad[Math.floor(Math.random() * st.squad.length)];
      if (p && p.ovr < 99) p.ovr += 1;
    }

    GameEngine.save();
    App.showToast("🎙️ " + opt.msg);
    App.render();
  }

  function setStyle(type, val) {
    const st = ensureState();
    if (type === "color") st.clubColor = val;
    else st.clubIcon = val;
    GameEngine.save();
    App.showToast("👕 Tampilan klub diperbarui!");
    App.render();
  }
  function applyCrestStyle() {
    const st = ensureState();
    const el = document.querySelector(".club-crest");
    if (el) {
      el.style.background = st.clubColor;
      el.textContent = st.isOwner ? "👑" : st.clubIcon;
    }
  }

  function render() {
    const st = ensureState();
    const tabs = `<div class="sub-tabs">
      <button class="tab-btn ${tab === "cup" ? "active" : ""}" onclick="CoolHub.setTab('cup')">🏆 Cup</button>
      <button class="tab-btn ${tab === "spin" ? "active" : ""}" onclick="CoolHub.setTab('spin')">🎡 Spin</button>
      <button class="tab-btn ${tab === "press" ? "active" : ""}" onclick="CoolHub.setTab('press')">🎙️ Media</button>
      <button class="tab-btn ${tab === "jersey" ? "active" : ""}" onclick="CoolHub.setTab('jersey')">👕 Logo</button>
    </div>`;

    if (tab === "cup") {
      const done = st.cupStage >= 3;
      const cur = done ? null : CUP_ROUNDS[st.cupStage];
      return tabs + `<div class="card" style="border-color:var(--gold);">
        <div class="section-title" style="color:var(--gold);">🏆 CHAMPIONS CUP (Juara: ${st.cupWon}x)</div>
        ${done
          ? `<div style="font-size:13px;margin:10px 0;">🎉 Kamu adalah Juara Champions Cup saat ini!</div>
             <button class="btn-gold" style="width:100%;" onclick="CoolHub.playCupMatch()">Mulai Turnamen Baru</button>`
          : `<div style="font-size:12px;color:var(--text-muted);margin:6px 0;">Babak: <strong style="color:#fff;">${cur.round}</strong></div>
             <div style="padding:12px;background:rgba(0,0,0,0.35);border-radius:10px;margin:10px 0;display:flex;justify-content:space-between;align-items:center;">
               <div><strong style="color:#4ade80;">${st.clubName}</strong><br><small>OVR ${GameEngine.getSquadStrength()}</small></div>
               <strong style="color:var(--gold);">VS</strong>
               <div style="text-align:right;"><strong style="color:#facc15;">${cur.opp}</strong><br><small>OVR ${cur.rating}</small></div>
             </div>
             <div style="font-size:12px;margin-bottom:10px;">Hadiah Menang: <strong style="color:#4ade80;">+${GameEngine.formatMoney(cur.prize)}</strong></div>
             <button class="btn-gold" style="width:100%;" onclick="CoolHub.playCupMatch()">⚔️ Mainkan Babak ${cur.round}</button>`
        }
      </div>`;
    }

    if (tab === "spin") {
      const freeReady = st.lastFreeSpinDay !== st.day;
      return tabs + `<div class="card" style="text-align:center;">
        <div style="font-size:44px;margin-bottom:6px;">🎡</div>
        <div class="section-title" style="color:var(--gold);">LUCKY SPIN HARIAN</div>
        <div style="font-size:11px;color:var(--text-muted);margin:6px 0 12px;">Menangkan uang tunai, +1 OVR pemain, +Reputasi, hingga Jackpot £500,000!</div>
        ${lastSpinText ? `<div style="padding:10px;border-radius:10px;background:rgba(217,182,92,0.15);color:#facc15;font-size:12px;font-weight:800;margin-bottom:12px;">${lastSpinText}</div>` : ""}
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
          <button class="btn-gold" onclick="CoolHub.spinWheel(false)" ${freeReady ? "" : "disabled"}>${freeReady ? "🎁 Spin Gratis" : "✓ Terpakai"}</button>
          <button class="btn-outline" onclick="CoolHub.spinWheel(true)" ${st.balance < 25000 ? "disabled" : ""}>Spin (£25,000)</button>
        </div>
      </div>`;
    }

    if (tab === "press") {
      const done = st.lastPressDay === st.day;
      const qIdx = st.day % PRESS_QA.length;
      const qa = PRESS_QA[qIdx];
      const btns = qa.opts.map(function (o, i) {
        return `<button class="btn-outline" style="width:100%;margin-top:8px;text-align:left;" onclick="CoolHub.answerPress(${qIdx},${i})">${o.label}</button>`;
      }).join("");
      return tabs + `<div class="card">
        <div class="section-title">🎙️ KONFERENSI PERS HARIAN</div>
        ${done
          ? `<div style="font-size:12px;color:var(--text-muted);margin-top:8px;">✓ Kamu sudah menjawab wartawan hari ini. Lanjut <strong>Next Day</strong> untuk sesi berikutnya.</div>`
          : `<div style="font-size:13px;font-weight:800;margin:10px 0;">"${qa.q}"</div>${btns}`
        }
      </div>`;
    }

    const colBtns = COLORS.map(function (c) {
      return `<button onclick="CoolHub.setStyle('color','${c.bg}')" style="background:${c.bg};color:#fff;border:2px solid ${st.clubColor === c.bg ? "#fff" : "transparent"};padding:8px;border-radius:10px;font-size:11px;font-weight:800;">${c.name}</button>`;
    }).join("");
    const icoBtns = ICONS.map(function (ic) {
      return `<button class="tab-btn ${st.clubIcon === ic ? "active" : ""}" onclick="CoolHub.setStyle('icon','${ic}')" style="font-size:18px;">${ic}</button>`;
    }).join("");

    return tabs + `<div class="card" style="text-align:center;">
      <div class="section-title" style="margin-bottom:10px;">CUSTOM LOGO & WARNA KLUB</div>
      <div style="width:68px;height:68px;margin:0 auto 12px;border-radius:18px;background:${st.clubColor};display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:900;color:#fff;box-shadow:0 4px 16px rgba(0,0,0,0.4);">${st.clubIcon}</div>
      <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">Pilih Warna Klub</div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:14px;">${colBtns}</div>
      <div style="font-size:11px;color:var(--text-muted);margin-bottom:6px;">Pilih Ikon Emblem</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;">${icoBtns}</div>
    </div>`;
  }

  return { render, setTab, playCupMatch, spinWheel, answerPress, setStyle, applyCrestStyle };
})();
