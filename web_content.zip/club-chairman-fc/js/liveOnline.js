window.LiveOnline = (function () {
  let clockTimer = null;
  let cryptoApiTimer = null;
  let isOnline = navigator.onLine;
  let lastCryptoSource = "SIMULATED";
  let lastCryptoUpdate = "-";
  let onTickCallback = null;

  function getTodayDateStr() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }

  function getFormattedClock() {
    const d = new Date();
    return d.toLocaleTimeString("id-ID", { hour12: false });
  }

  function getTimeUntilMidnight() {
    const now = new Date();
    const tomorrow = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
    const diff = Math.max(0, Math.floor((tomorrow - now) / 1000));
    const h = String(Math.floor(diff / 3600)).padStart(2, "0");
    const m = String(Math.floor((diff % 3600) / 60)).padStart(2, "0");
    const s = String(diff % 60).padStart(2, "0");
    return `${h}:${m}:${s}`;
  }

  async function syncRealCryptoPrices() {
    if (!navigator.onLine) {
      isOnline = false;
      lastCryptoSource = "OFFLINE SIM";
      GameEngine.tickCryptoPrices();
      return false;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4500);

    try {
      const url = "https://api.coingecko.com/api/v3/simple/price?ids=avalanche-2,binancecoin,ethereum,bitcoin&vs_currencies=gbp&include_24hr_change=true";
      const res = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error("API limit");
      const data = await res.json();

      const map = {
        AVAX: data["avalanche-2"],
        BNB: data["binancecoin"],
        ETH: data["ethereum"],
        BTC: data["bitcoin"]
      };

      const st = GameEngine.getState();
      st.crypto.forEach((coin) => {
        const live = map[coin.symbol];
        if (live && typeof live.gbp === "number") {
          coin.price = Number(live.gbp.toFixed(2));
          coin.change = Number((live.gbp_24h_change || 0).toFixed(2));
        }
      });

      isOnline = true;
      lastCryptoSource = "LIVE ONLINE";
      lastCryptoUpdate = getFormattedClock();
      GameEngine.save();
      return true;
    } catch (err) {
      clearTimeout(timeoutId);
      lastCryptoSource = navigator.onLine ? "LIVE SIM" : "OFFLINE SIM";
      lastCryptoUpdate = getFormattedClock();
      GameEngine.tickCryptoPrices();
      return false;
    }
  }

  function checkRealDailyRollover() {
    const today = getTodayDateStr();
    const result = GameEngine.syncRealWorldDays(today);
    if (result && result.daysPassed > 0 && window.App && App.showToast) {
      const sign = result.totalNet >= 0 ? "+" : "";
      App.showToast(`🌐 Sync ${result.daysPassed} hari online! Cashflow: ${sign}${GameEngine.formatMoney(result.totalNet)}`);
      App.render();
    }
  }

  function start(onTick) {
    stop();
    onTickCallback = onTick;

    window.addEventListener("online", handleConnectionChange);
    window.addEventListener("offline", handleConnectionChange);

    checkRealDailyRollover();
    syncRealCryptoPrices();

    clockTimer = setInterval(() => {
      checkRealDailyRollover();
      if (onTickCallback) onTickCallback(getStatus());
    }, 1000);

    cryptoApiTimer = setInterval(() => {
      syncRealCryptoPrices().then(() => {
        if (onTickCallback) onTickCallback(getStatus());
      });
    }, 30000);
  }

  function stop() {
    if (clockTimer) { clearInterval(clockTimer); clockTimer = null; }
    if (cryptoApiTimer) { clearInterval(cryptoApiTimer); cryptoApiTimer = null; }
    window.removeEventListener("online", handleConnectionChange);
    window.removeEventListener("offline", handleConnectionChange);
  }

  function handleConnectionChange() {
    isOnline = navigator.onLine;
    if (isOnline) syncRealCryptoPrices();
    if (onTickCallback) onTickCallback(getStatus());
  }

  function getStatus() {
    return {
      isOnline,
      clock: getFormattedClock(),
      today: getTodayDateStr(),
      countdownMidnight: getTimeUntilMidnight(),
      cryptoSource: lastCryptoSource,
      lastCryptoUpdate
    };
  }

  return {
    start,
    stop,
    getStatus,
    getTodayDateStr,
    syncRealCryptoPrices
  };
})();
