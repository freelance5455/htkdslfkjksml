window.SuperUpdate = (function () {
  let tab = "redeem";
  let tierFilter = "all";

  const EXTRA_PLAYERS = [
    // --- PEMULA (OVR 48 - 59, Murah untuk Awal Game) ---
    { id: "pm1", tier: "pemula", name: "Budi Santoso", flag: "🇮🇩", nationality: "Indonesia", pos: "CM", fullPos: "Central Midfielder", ovr: 49, potential: "GREAT", age: 19, height: 173, foot: "Right", wage: 150, value: 12000, totalFootball: 50, pragmatic: 52 },
    { id: "pm2", tier: "pemula", name: "Alex Turner", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "ST", fullPos: "Striker", ovr: 51, potential: "GREAT", age: 20, height: 180, foot: "Right", wage: 180, value: 16000, totalFootball: 52, pragmatic: 50 },
    { id: "pm3", tier: "pemula", name: "Kenzo Sato", flag: "🇯🇵", nationality: "Japan", pos: "RW", fullPos: "Right Winger", ovr: 54, potential: "EXCELLENT", age: 18, height: 171, foot: "Left", wage: 220, value: 22000, totalFootball: 58, pragmatic: 51 },
    { id: "pm4", tier: "pemula", name: "Ernando Ari", flag: "🇮🇩", nationality: "Indonesia", pos: "GK", fullPos: "Goalkeeper", ovr: 56, potential: "EXCELLENT", age: 24, height: 179, foot: "Right", wage: 260, value: 28000, totalFootball: 54, pragmatic: 60 },
    { id: "pm5", tier: "pemula", name: "Ramadhan Sananta", flag: "🇮🇩", nationality: "Indonesia", pos: "ST", fullPos: "Striker", ovr: 57, potential: "EXCELLENT", age: 23, height: 182, foot: "Right", wage: 290, value: 32000, totalFootball: 56, pragmatic: 59 },
    { id: "pm6", tier: "pemula", name: "Pratama Arhan", flag: "🇮🇩", nationality: "Indonesia", pos: "LB", fullPos: "Left Back", ovr: 58, potential: "EXCELLENT", age: 24, height: 172, foot: "Left", wage: 310, value: 36000, totalFootball: 60, pragmatic: 58 },
    { id: "pm7", tier: "pemula", name: "Marselino Ferdinan", flag: "🇮🇩", nationality: "Indonesia", pos: "CAM", fullPos: "Attacking Mid", ovr: 59, potential: "ELITE", age: 21, height: 176, foot: "Right", wage: 350, value: 42000, totalFootball: 65, pragmatic: 57 },
    { id: "pm8", tier: "pemula", name: "Rizky Ridho", flag: "🇮🇩", nationality: "Indonesia", pos: "CB", fullPos: "Centre Back", ovr: 59, potential: "ELITE", age: 24, height: 183, foot: "Right", wage: 340, value: 40000, totalFootball: 61, pragmatic: 64 },

    // --- PRO (OVR 74 - 84) ---
    { id: "pr1", tier: "pro", name: "Maarten Paes", flag: "🇮🇩", nationality: "Indonesia", pos: "GK", fullPos: "Goalkeeper", ovr: 75, potential: "EXCELLENT", age: 28, height: 192, foot: "Right", wage: 1400, value: 180000, totalFootball: 72, pragmatic: 78 },
    { id: "pr2", tier: "pro", name: "Jay Idzes", flag: "🇮🇩", nationality: "Indonesia", pos: "CB", fullPos: "Centre Back", ovr: 76, potential: "EXCELLENT", age: 26, height: 190, foot: "Right", wage: 1600, value: 210000, totalFootball: 75, pragmatic: 79 },
    { id: "pr3", tier: "pro", name: "Kobbie Mainoo", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "CM", fullPos: "Central Midfielder", ovr: 78, potential: "ELITE", age: 21, height: 180, foot: "Right", wage: 2100, value: 310000, totalFootball: 80, pragmatic: 77 },
    { id: "pr4", tier: "pro", name: "Takefusa Kubo", flag: "🇯🇵", nationality: "Japan", pos: "RW", fullPos: "Right Winger", ovr: 80, potential: "ELITE", age: 25, height: 173, foot: "Left", wage: 2600, value: 420000, totalFootball: 84, pragmatic: 75 },
    { id: "pr5", tier: "pro", name: "Kaoru Mitoma", flag: "🇯🇵", nationality: "Japan", pos: "LW", fullPos: "Left Winger", ovr: 81, potential: "EXCELLENT", age: 29, height: 178, foot: "Right", wage: 2900, value: 480000, totalFootball: 85, pragmatic: 78 },
    { id: "pr6", tier: "pro", name: "Son Heung-min", flag: "🇰🇷", nationality: "South Korea", pos: "LW", fullPos: "Left Winger", ovr: 84, potential: "ELITE", age: 34, height: 183, foot: "Right", wage: 4200, value: 650000, totalFootball: 86, pragmatic: 85 },

    // --- MEGA BINTANG (OVR 87 - 91) ---
    { id: "mb1", tier: "bintang", name: "⭐ Cole Palmer", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "CAM", fullPos: "Attacking Mid", ovr: 87, potential: "ELITE", age: 24, height: 189, foot: "Left", wage: 6200, value: 1150000, totalFootball: 89, pragmatic: 85 },
    { id: "mb2", tier: "bintang", name: "⭐ Lamine Yamal", flag: "🇪🇸", nationality: "Spain", pos: "RW", fullPos: "Right Winger", ovr: 88, potential: "ELITE", age: 19, height: 180, foot: "Left", wage: 6800, value: 1450000, totalFootball: 93, pragmatic: 84 },
    { id: "mb3", tier: "bintang", name: "⭐ Jamal Musiala", flag: "🇩🇪", nationality: "Germany", pos: "CAM", fullPos: "Attacking Mid", ovr: 88, potential: "ELITE", age: 23, height: 184, foot: "Right", wage: 6900, value: 1400000, totalFootball: 92, pragmatic: 86 },
    { id: "mb4", tier: "bintang", name: "⭐ Bukayo Saka", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", nationality: "England", pos: "RW", fullPos: "Right Winger", ovr: 89, potential: "ELITE", age: 25, height: 178, foot: "Left", wage: 7400, value: 1550000, totalFootball: 90, pragmatic: 88 },
    { id: "mb5", tier: "bintang", name: "⭐ Thibaut Courtois", flag: "🇧🇪", nationality: "Belgium", pos: "GK", fullPos: "Goalkeeper", ovr: 90, potential: "ELITE", age: 34, height: 200, foot: "Left", wage: 7800, value: 1300000, totalFootball: 85, pragmatic: 94 },
    { id: "mb6", tier: "bintang", name: "⭐ Rodri", flag: "🇪🇸", nationality: "Spain", pos: "CDM", fullPos: "Defensive Mid", ovr: 91, potential: "ELITE", age: 30, height: 191, foot: "Right", wage: 8600, value: 1850000, totalFootball: 94, pragmatic: 93 },
    { id: "mb7", tier: "bintang", name: "⭐ Vinícius Jr", flag: "🇧🇷", nationality: "Brazil", pos: "LW", fullPos: "Left Winger", ovr: 91, potential: "ELITE", age: 26, height: 176, foot: "Right", wage: 8900, value: 1950000, totalFootball: 93, pragmatic: 87 },

    // --- LEGENDA (OVR 88 - 97) ---
    { id: "lg8", tier: "legenda", name: "👑 Bambang Pamungkas [LEGEND]", flag: "🇮🇩", nationality: "Indonesia", pos: "ST", fullPos: "Striker", ovr: 88, potential: "ELITE", age: 28, height: 171, foot: "Right", wage: 5500, value: 950000, totalFootball: 87, pragmatic: 90 },
    { id: "lg9", tier: "legenda", name: "👑 Andrea Pirlo [LEGEND]", flag: "🇮🇹", nationality: "Italy", pos: "CM", fullPos: "Central Midfielder", ovr: 92, potential: "ELITE", age: 30, height: 177, foot: "Right", wage: 8800, value: 1650000, totalFootball: 97, pragmatic: 90 },
    { id: "lg10", tier: "legenda", name: "👑 Kaká [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "CAM", fullPos: "Attacking Mid", ovr: 93, potential: "ELITE", age: 26, height: 186, foot: "Right", wage: 9400, value: 1850000, totalFootball: 95, pragmatic: 91 },
    { id: "lg11", tier: "legenda", name: "👑 Cafu [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "RB", fullPos: "Right Back", ovr: 93, potential: "ELITE", age: 29, height: 176, foot: "Right", wage: 9000, value: 1700000, totalFootball: 93, pragmatic: 94 },
    { id: "lg12", tier: "legenda", name: "👑 Sergio Ramos [LEGEND]", flag: "🇪🇸", nationality: "Spain", pos: "CB", fullPos: "Centre Back", ovr: 93, potential: "ELITE", age: 29, height: 184, foot: "Right", wage: 9200, value: 1750000, totalFootball: 90, pragmatic: 97 },
    { id: "lg13", tier: "legenda", name: "👑 Thierry Henry [LEGEND]", flag: "🇫🇷", nationality: "France", pos: "ST", fullPos: "Striker", ovr: 94, potential: "ELITE", age: 27, height: 188, foot: "Right", wage: 10500, value: 2150000, totalFootball: 96, pragmatic: 93 },
    { id: "lg14", tier: "legenda", name: "👑 Gianluigi Buffon [LEGEND]", flag: "🇮🇹", nationality: "Italy", pos: "GK", fullPos: "Goalkeeper", ovr: 95, potential: "ELITE", age: 29, height: 192, foot: "Right", wage: 10800, value: 2200000, totalFootball: 90, pragmatic: 99 },
    { id: "lg15", tier: "legenda", name: "👑 Johan Cruyff [LEGEND]", flag: "🇳🇱", nationality: "Netherlands", pos: "CF", fullPos: "Centre Forward", ovr: 96, potential: "ELITE", age: 27, height: 180, foot: "Right", wage: 12000, value: 2700000, totalFootball: 99, pragmatic: 94 },
    { id: "lg16", tier: "legenda", name: "👑 Diego Maradona [LEGEND]", flag: "🇦🇷", nationality: "Argentina", pos: "CAM", fullPos: "Attacking Mid", ovr: 97, potential: "ELITE", age: 26, height: 165, foot: "Left", wage: 13500, value: 3100000, totalFootball: 99, pragmatic: 95 }
  ];

  const REDEEM_CODES = {
    "WELCOME2026": { money: 50000, rep: 0, msg: "Bonus Pemain Baru +£50,000!" },
    "GARUDA2026": { money: 75000, rep: 1, player: { id: "rd_marselino", name: "🇮🇩 Marselino [SPECIAL]", flag: "🇮🇩", nationality: "Indonesia", pos: "CAM", fullPos: "Attacking Mid", ovr: 68, potential: "ELITE", age: 21, height: 176, foot: "Right", wage: 400, value: 95000, totalFootball: 72, pragmatic: 68 }, msg: "+£75,000 & Marselino Special!" },
    "MODAL500K": { money: 500000, rep: 2, msg: "Dana Segar +£500,000 & +2 Rep!" },
    "LEGENDCARLOS": { money: 0, rep: 1, player: { id: "rd_carlos", name: "👑 Roberto Carlos [LEGEND]", flag: "🇧🇷", nationality: "Brazil", pos: "LB", fullPos: "Left Back", ovr: 93, potential: "ELITE", age: 28, height: 168, foot: "Left", wage: 8500, value: 1500000, totalFootball: 94, pragmatic: 92 }, msg: "👑 Roberto Carlos resmi bergabung!" },
    "SIUUUCR7": { money: 0, rep: 1, player: { id: "rd_cr7", name: "⭐ Cristiano Ronaldo (CR7)", flag: "🇵🇹", nationality: "Portugal", pos: "ST", fullPos: "Striker", ovr: 95, potential: "ELITE", age: 39, height: 187, foot: "Right", wage: 12000, value: 1800000, totalFootball: 92, pragmatic: 96 }, msg: "⭐ CR7 resmi bergabung ke First Team!" },
    "GOATMESSI": { money: 0, rep: 1, player: { id: "rd_messi", name: "⭐ Lionel Messi", flag: "🇦🇷", nationality: "Argentina", pos: "RW", fullPos: "Right Winger", ovr: 95, potential: "ELITE", age: 37, height: 170, foot: "Left", wage: 12000, value: 1800000, totalFootball: 99, pragmatic: 90 }, msg: "⭐ Lionel Messi resmi bergabung!" },
    "PACKLEGEND": { money: 1500000, rep: 2, msg: "Hadiah Spesial +£1,500,000!" }
  };
  function ensureState() {
    const st = GameEngine.getState();
    if (!Array.isArray(st.redeemedCodes)) st.redeemedCodes = [];
    if (!Array.isArray(st.trophies)) st.trophies = [];
    syncExtraPlayers(st);
    return st;
  }

  function syncExtraPlayers(st) {
    let changed = false;
    EXTRA_PLAYERS.forEach(function (ep) {
      const inMarket = st.transferMarket.some(function (x) { return x.id === ep.id; });
      const inSquad = st.squad.some(function (x) { return x.id === ep.id; });
      if (!inMarket && !inSquad) {
        st.transferMarket.push({ ...ep });
        changed = true;
      }
    });
    if (changed) GameEngine.save();
  }

  function getPlayerTier(p) {
    if (p.tier) return p.tier;
    if (p.name.indexOf("[LEGEND]") !== -1) return "legenda";
    if (p.ovr >= 85) return "bintang";
    if (p.ovr >= 68) return "pro";
    return "pemula";
  }

  function setTab(t) { tab = t; App.render(); }
  function setFilter(f) { tierFilter = f; App.render(); }

  function claimCode() {
    const st = ensureState();
    const inp = document.getElementById("redeem-code-input");
    const code = (inp ? inp.value : "").trim().toUpperCase();
    if (!code) return App.showToast("Masukkan kode redeem dulu!");
    const reward = REDEEM_CODES[code];
    if (!reward) return App.showToast("❌ Kode redeem tidak valid!");
    if (st.redeemedCodes.indexOf(code) !== -1) return App.showToast("⚠️ Kode ini sudah pernah diklaim!");

    st.redeemedCodes.push(code);
    if (reward.money) st.balance += reward.money;
    if (reward.rep) st.reputation += reward.rep;
    if (reward.player) {
      const already = st.squad.some(function (p) { return p.id === reward.player.id; });
      if (!already) st.squad.push({ ...reward.player, team: "first", goals: 0, apps: 0 });
      else st.balance += 250000;
    }
    st.inbox.unshift({ day: st.day, title: "🎁 Redeem Berhasil (" + code + ")", body: reward.msg });
    GameEngine.save();
    App.showToast("🎁 " + reward.msg);
    App.render();
  }

  function openPack(packType) {
    const st = ensureState();
    const cfg = {
      starter: { cost: 15000, pool: ["pemula"] },
      pro: { cost: 150000, pool: ["pro"] },
      legend: { cost: 1200000, pool: ["bintang", "legenda"] }
    }[packType];
    if (!cfg) return;
    if (st.balance < cfg.cost) return App.showToast("Saldo tidak cukup (" + GameEngine.formatMoney(cfg.cost) + ")!");

    const candidates = EXTRA_PLAYERS.filter(function (p) { return cfg.pool.indexOf(p.tier) !== -1; });
    const pick = candidates[Math.floor(Math.random() * candidates.length)];
    if (!pick) return App.showToast("Pack kosong.");

    st.balance -= cfg.cost;
    st.squad.push({ ...pick, id: "pk_" + Date.now() + "_" + Math.floor(Math.random() * 999), team: "first", goals: 0, apps: 0 });
    st.inbox.unshift({ day: st.day, title: "📦 Pack Opened!", body: "Selamat! Kamu mendapatkan " + pick.name + " (OVR " + pick.ovr + ")." });
    GameEngine.save();
    App.showToast("🎉 Dapat " + pick.name + " (" + pick.ovr + " OVR)!");
    App.render();
  }

  function finishSeason() {
    const st = ensureState();
    const me = st.league.find(function (c) { return c.id === "me"; });
    if (!me || me.p < 5) return App.showToast("Mainkan minimal 5 laga di liga untuk menyelesaikan musim!");

    const sorted = st.league.slice().sort(function (a, b) { return b.pts - a.pts || (b.gf - b.ga) - (a.gf - a.ga); });
    const rank = sorted.findIndex(function (c) { return c.id === "me"; }) + 1;
    const prize = rank === 1 ? 500000 : rank === 2 ? 250000 : rank === 3 ? 120000 : 50000;

    st.balance += prize;
    if (rank === 1) {
      st.reputation += 3;
      st.trophies.unshift({ year: st.year, title: "🏆 Juara Liga Musim " + st.year, pts: me.pts });
    }
    st.year += 1;
    st.league.forEach(function (c) { c.p = 0; c.w = 0; c.d = 0; c.l = 0; c.gf = 0; c.ga = 0; c.pts = 0; });
    st.inbox.unshift({ day: st.day, title: "🏁 Akhir Musim (Peringkat #" + rank + ")", body: "Hadiah klasemen +" + GameEngine.formatMoney(prize) + ". Musim " + st.year + " dimulai!" });
    GameEngine.save();
    App.showToast("🏆 Peringkat #" + rank + "! Hadiah +" + GameEngine.formatMoney(prize));
    App.render();
  }
  function render() {
    const st = ensureState();
    const tabs = `<div class="sub-tabs">
      <button class="tab-btn ${tab === "redeem" ? "active" : ""}" onclick="SuperUpdate.setTab('redeem')">🎁 Redeem</button>
      <button class="tab-btn ${tab === "market" ? "active" : ""}" onclick="SuperUpdate.setTab('market')">🛒 Bursa</button>
      <button class="tab-btn ${tab === "packs" ? "active" : ""}" onclick="SuperUpdate.setTab('packs')">📦 Pack</button>
      <button class="tab-btn ${tab === "season" ? "active" : ""}" onclick="SuperUpdate.setTab('season')">🏆 Trofi</button>
    </div>`;

    if (tab === "redeem") {
      const used = st.redeemedCodes.length ? st.redeemedCodes.join(", ") : "Belum ada";
      return tabs + `<div class="card" style="border-color:var(--gold);">
        <div class="section-title" style="color:var(--gold);">🎁 KODE REDEEM HADIAH</div>
        <div style="font-size:11px;color:var(--text-muted);margin:4px 0 10px;">Masukkan kode promo untuk dapat uang tunai, reputasi, atau pemain Bintang & Legenda gratis!</div>
        <input id="redeem-code-input" class="input-box" placeholder="Contoh: WELCOME2026" />
        <button class="btn-gold" style="width:100%;" onclick="SuperUpdate.claimCode()">Klaim Hadiah</button>
        <div style="font-size:11px;color:var(--text-muted);margin-top:10px;">Kode terpakai: <strong>${used}</strong></div>
      </div>`;
    }

    if (tab === "market") {
      const filtered = st.transferMarket.filter(function (p) {
        return tierFilter === "all" || getPlayerTier(p) === tierFilter;
      });
      const filterBtns = `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px;">
        <button class="tab-btn ${tierFilter === "all" ? "active" : ""}" onclick="SuperUpdate.setFilter('all')">Semua</button>
        <button class="tab-btn ${tierFilter === "pemula" ? "active" : ""}" onclick="SuperUpdate.setFilter('pemula')">Pemula</button>
        <button class="tab-btn ${tierFilter === "pro" ? "active" : ""}" onclick="SuperUpdate.setFilter('pro')">Pro</button>
        <button class="tab-btn ${tierFilter === "bintang" ? "active" : ""}" onclick="SuperUpdate.setFilter('bintang')">Bintang</button>
        <button class="tab-btn ${tierFilter === "legenda" ? "active" : ""}" onclick="SuperUpdate.setFilter('legenda')">Legenda</button>
      </div>`;
      const cards = filtered.length ? filtered.map(function (p) {
        return `<div class="card"><div style="display:flex;align-items:center;gap:10px;">
          <div class="player-info"><div class="player-name">${p.flag} ${p.name}</div><div class="player-meta"><span>${p.pos} · Age ${p.age}</span><span>Wage £${p.wage}/d</span></div></div>
          <div class="ovr-shield"><span class="ovr-num">${p.ovr}</span><span class="ovr-txt">OVR</span></div>
        </div><button class="btn-gold" style="width:100%;margin-top:8px;" onclick="App.handleBuyTransfer('${p.id}')" ${st.balance < p.value ? "disabled" : ""}>Rekrut (${GameEngine.formatMoney(p.value)})</button></div>`;
      }).join("") : '<div class="card">Tidak ada pemain di kategori ini.</div>';
      return tabs + `<div class="card" style="display:flex;justify-content:space-between;"><span>Saldo Klub</span><strong style="color:var(--gold);">${GameEngine.formatMoney(st.balance)}</strong></div>` + filterBtns + cards;
    }

    if (tab === "packs") {
      return tabs + `
        <div class="card"><strong>📦 Starter Pack (Pemula)</strong><div style="font-size:11px;color:var(--text-muted);margin:4px 0 10px;">Dapatkan 1 pemain pemula potensial (OVR 49–59) langsung masuk tim.</div><button class="btn-gold" style="width:100%;" onclick="SuperUpdate.openPack('starter')" ${st.balance < 15000 ? "disabled" : ""}>Buka Pack (£15,000)</button></div>
        <div class="card"><strong>📦 Pro Pack (Bintang Asia & Eropa)</strong><div style="font-size:11px;color:var(--text-muted);margin:4px 0 10px;">Dapatkan 1 pemain Pro (OVR 75–84) seperti Son, Mitoma, Kubo, atau Jay Idzes.</div><button class="btn-gold" style="width:100%;" onclick="SuperUpdate.openPack('pro')" ${st.balance < 150000 ? "disabled" : ""}>Buka Pack (£150,000)</button></div>
        <div class="card" style="border-color:var(--gold);"><strong style="color:var(--gold);">👑 Legend & Mega Star Pack</strong><div style="font-size:11px;color:var(--text-muted);margin:4px 0 10px;">Peluang besar dapat Mega Bintang (OVR 87–91) atau Legenda Dunia (OVR 88–97)!</div><button class="btn-gold" style="width:100%;" onclick="SuperUpdate.openPack('legend')" ${st.balance < 1200000 ? "disabled" : ""}>Buka Pack (£1,200,000)</button></div>`;
    }

    const me = st.league.find(function (c) { return c.id === "me"; });
    const trophyList = st.trophies.length ? st.trophies.map(function (t) {
      return `<div style="padding:8px 0;border-bottom:1px solid var(--border-subtle);font-size:13px;"><strong>${t.title}</strong> · <span style="color:var(--gold);">${t.pts} Poin</span></div>`;
    }).join("") : '<div style="font-size:12px;color:var(--text-muted);">Belum ada trofi. Juara #1 di klasemen liga lalu selesaikan musim!</div>';

    return tabs + `<div class="card"><div class="section-title">🏁 AKHIRI MUSIM ${st.year}</div>
      <div style="font-size:12px;color:var(--text-muted);margin:6px 0 10px;">Pertandingan liga dimainkan: <strong>${me ? me.p : 0}/5</strong>. Juara #1 mendapat Trofi + £500,000!</div>
      <button class="btn-gold" style="width:100%;" onclick="SuperUpdate.finishSeason()" ${(!me || me.p < 5) ? "disabled" : ""}>Selesaikan Musim & Klaim Hadiah</button></div>
      <div class="card"><div class="section-title" style="margin-bottom:8px;">🏆 LEMARI TROFI (${st.trophies.length})</div>${trophyList}</div>`;
  }

  return { ensureState, render, setTab, setFilter, claimCode, openPack, finishSeason };
})();
