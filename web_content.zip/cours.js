const COURSES = [
  {
    id: "info-1",
    category: "Info Générale",
    level: "Universitaire L1",
    title: "Informatique Générale & Architecture",
    duration: "1h 15",
    description: "Manuel complet : architecture de Von Neumann, cycle CPU, hiérarchie des mémoires, binaire/hexadécimal et systèmes d'exploitation.",
    chapters: [
      {
        id: "info-c1",
        title: "Chapitre 1 : Architecture de Von Neumann & CPU",
        html: `
          <h3>1.1 Qu'est-ce que l'informatique ?</h3>
          <p>Le mot <strong>informatique</strong> (contraction d'<em>Information</em> et <em>Automatique</em>, proposé en 1962) désigne la science du traitement automatique et rationnel de l'information à l'aide de machines programmables.</p>
          <p>Tout système informatique suit le cycle : <strong>Entrée (Input) → Traitement (Process) → Sortie (Output)</strong>, accompagné d'un espace de <strong>Stockage</strong>.</p>

          <h3>1.2 Le modèle de Von Neumann (1945)</h3>
          <p>Avant 1945, pour changer le calcul d'une machine, il fallait recâbler ses fils manuellement. <strong>John Von Neumann</strong> a révolutionné l'informatique en proposant de stocker <em>le programme et les données dans la même mémoire</em>.</p>
          <div class="code-box">
            <div class="code-header"><span>Schéma — Architecture de Von Neumann</span></div>
<pre>      +-----------------------------------+
      |     PROCESSEUR (CPU)              |
      |  [Unité de Contrôle]  [UAL / ALU] |
      +-----------------+-----------------+
                        |  Bus (Données / Adresses / Contrôle)
      +-----------------+-----------------+
      |       MÉMOIRE CENTRALE (RAM)      |
      |   Instructions + Données actives  |
      +-----------------+-----------------+
                        |
      +-----------------+-----------------+
      |   PÉRIPHÉRIQUES D'ENTRÉE/SORTIE   |
      |  Clavier, Écran, Disque SSD, Réseau|
      +-----------------------------------+</pre>
          </div>
          <ul>
            <li><strong>L'Unité Arithmétique et Logique (UAL) :</strong> Effectue les calculs mathématiques (+, -, ×, ÷) et les comparaisons logiques (ET, OU, =, &lt;, &gt;).</li>
            <li><strong>L'Unité de Contrôle (UC) :</strong> Le chef d'orchestre qui lit les instructions en mémoire et dirige les autres composants.</li>
            <li><strong>Les Bus système :</strong> Autoroutes électriques transportant les <em>données</em>, les <em>adresses mémoire</em> et les signaux de <em>contrôle</em>.</li>
          </ul>

          <h3>1.3 Le cycle d'une instruction (Fetch - Decode - Execute)</h3>
          <p>Chaque seconde, un processeur moderne exécute des milliards de fois ce cycle en 3 étapes :</p>
          <ul>
            <li><strong>1. Fetch (Recherche) :</strong> L'UC lit la prochaine instruction dans la RAM (à l'adresse indiquée par le compteur ordinal <em>PC</em>).</li>
            <li><strong>2. Decode (Décodage) :</strong> L'UC traduit le code binaire de l'instruction pour savoir quelle opération effectuer.</li>
            <li><strong>3. Execute (Exécution) :</strong> L'UAL exécute l'opération et range le résultat dans un registre ou en RAM.</li>
          </ul>
          <div class="note-box">
            <strong>📌 À retenir :</strong> Une fréquence de <strong>3,5 GHz</strong> signifie que l'horloge du processeur bat 3,5 milliards de fois par seconde. Un processeur <strong>Quad-Core</strong> possède 4 unités de calcul capables de travailler en parallèle.
          </div>
        `
      },
      {
        id: "info-c2",
        title: "Chapitre 2 : Hiérarchie des Mémoires",
        html: `
          <h3>2.1 Pourquoi plusieurs types de mémoires ?</h3>
          <p>En informatique, il existe un compromis fondamental : <strong>plus une mémoire est rapide, plus elle coûte cher et plus sa capacité est petite</strong>. On organise donc les mémoires en pyramide.</p>
          <table>
            <tr><th>Mémoire</th><th>Vitesse</th><th>Capacité typique</th><th>Volatile ?</th></tr>
            <tr><td><strong>Registres CPU</strong></td><td>Instantanée (&lt; 1 ns)</td><td>Quelques octets</td><td>Oui</td></tr>
            <tr><td><strong>Cache (L1/L2/L3)</strong></td><td>Très rapide (1-10 ns)</td><td>Quelques Mo</td><td>Oui</td></tr>
            <tr><td><strong>RAM (DDR4/DDR5)</strong></td><td>Rapide (~50 ns)</td><td>8 à 64 Go</td><td>Oui</td></tr>
            <tr><td><strong>SSD (NVMe)</strong></td><td>Moyenne (~0,1 ms)</td><td>256 Go à 4 To</td><td>Non</td></tr>
            <tr><td><strong>Disque dur (HDD)</strong></td><td>Lente (~10 ms)</td><td>1 à 20 To</td><td>Non</td></tr>
          </table>

          <h3>2.2 RAM vs ROM (BIOS / UEFI)</h3>
          <p>La <strong>RAM</strong> (Random Access Memory) est votre espace de travail actif : elle est effacée à l'extinction. La <strong>ROM</strong> (Read-Only Memory) contient le microprogramme <strong>BIOS/UEFI</strong> soudé sur la carte mère : c'est lui qui démarre le PC, teste le matériel (POST) et charge le système d'exploitation depuis le SSD vers la RAM.</p>
          <div class="warn-box">
            <strong>⚠️ Piège d'examen :</strong> Ne confondez pas la <em>mémoire vive (RAM)</em> et l'<em>espace de stockage (SSD/HDD)</em>. Dire « mon téléphone a 128 Go de mémoire » désigne le stockage ; la RAM, elle, fait généralement 4 à 12 Go sur smartphone.
          </div>
        `
      },
      {
        id: "info-c3",
        title: "Chapitre 3 : Codage Binaire, Hexa & Caractères",
        html: `
          <h3>3.1 Du Bit à l'Octet et aux Puissances de 2</h3>
          <p>Un circuit électronique ne gère fiable­ment que deux tensions : <strong>0</strong> (basse) et <strong>1</strong> (haute). Chaque chiffre est un <strong>bit</strong> (Binary Digit). Un groupe de <strong>8 bits</strong> forme un <strong>octet</strong> (Byte).</p>
          <table>
            <tr><th>Position (2ⁿ)</th><td>2⁷</td><td>2⁶</td><td>2⁵</td><td>2⁴</td><td>2³</td><td>2²</td><td>2¹</td><td>2⁰</td></tr>
            <tr><th>Valeur</th><td><strong>128</strong></td><td><strong>64</strong></td><td><strong>32</strong></td><td><strong>16</strong></td><td><strong>8</strong></td><td><strong>4</strong></td><td><strong>2</strong></td><td><strong>1</strong></td></tr>
          </table>
          <p><strong>Méthode rapide Binaire → Décimal :</strong> Additionnez uniquement les valeurs des colonnes qui contiennent un <code>1</code>. Exemple : <code>01001101</code> = 64 + 8 + 4 + 1 = <strong>77</strong>.</p>

          <h3>3.2 Le système Hexadécimal (Base 16)</h3>
          <p>Lire des suites de 32 ou 64 bits est pénible pour un humain. On utilise la base 16 (chiffres <code>0</code> à <code>9</code> puis lettres <code>A=10, B=11, C=12, D=13, E=14, F=15</code>). <strong>Chaque chiffre hexadécimal correspond exactement à 4 bits !</strong></p>
          <div class="code-box">
            <div class="code-header"><span>Conversion rapide Binaire ↔ Hexadécimal</span></div>
<pre>Binaire (8 bits) :  1011  0110
Calcul par bloc  :  (8+2+1)=11   (4+2)=6
Hexadécimal      :    B            6   ==>  0xB6</pre>
          </div>

          <h3>3.3 Codage des textes : ASCII et UTF-8</h3>
          <p>L'ordinateur ne stocke que des nombres : une table de correspondance associe chaque caractère à un nombre.</p>
          <ul>
            <li><strong>ASCII (1963) :</strong> Code 128 caractères de base (anglais sans accents : <code>'A'=65</code>, <code>'a'=97</code>, <code>'0'=48</code>).</li>
            <li><strong>Unicode / UTF-8 :</strong> Standard universel actuel gérant plus de 140 000 caractères (accents français, arabe, chinois, symboles, emojis) sur 1 à 4 octets.</li>
          </ul>
        `
      },
      {
        id: "info-c4",
        title: "Chapitre 4 : Le Système d'Exploitation (OS)",
        html: `
          <h3>4.1 Rôle d'interface du Système d'Exploitation</h3>
          <p>Un ordinateur nu ne sait rien faire sans <strong>Système d'Exploitation (OS)</strong> comme Linux, Windows, macOS ou Android. L'OS sert d'intermédiaire entre vos applications et le matériel physique.</p>
          <h3>4.2 Les 5 fonctions vitales d'un OS</h3>
          <ul>
            <li><strong>1. Gestion du processeur (Ordonnancement) :</strong> Partager le CPU entre des dizaines de programmes ouverts simultanément (multitâche).</li>
            <li><strong>2. Gestion de la mémoire :</strong> Attribuer de la RAM à chaque programme en l'empêchant de lire la RAM d'un autre (isolation).</li>
            <li><strong>3. Système de fichiers :</strong> Organiser les données en dossiers et fichiers (NTFS, ext4, APFS).</li>
            <li><strong>4. Gestion des périphériques :</strong> Communiquer avec le matériel grâce aux <strong>pilotes (drivers)</strong>.</li>
            <li><strong>5. Sécurité & Utilisateurs :</strong> Gérer les comptes, mots de passe et permissions d'accès.</li>
          </ul>
          <div class="note-box">
            <strong>📌 Noyau (Kernel) :</strong> C'est le cœur critique de l'OS qui tourne en mode privilégié pour parler directement au matériel. Android utilise le noyau <strong>Linux</strong> !
          </div>
        `
      }
    ],
    exercises: [
      {
        title: "Conversion complète (Décimal ↔ Binaire ↔ Hexa)",
        prompt: "1) Convertissez <code>173</code> en binaire sur 8 bits à l'aide du tableau des puissances de 2.<br/>2) Déduisez-en immédiatement son écriture en hexadécimal.",
        solution: "<strong>1) Décimal → Binaire :</strong><br/>On soustrait les plus grandes puissances de 2 possibles :<br/>173 - 128 = 45 (bit 128 = <strong>1</strong>)<br/>45 &lt; 64 (bit 64 = <strong>0</strong>)<br/>45 - 32 = 13 (bit 32 = <strong>1</strong>)<br/>13 &lt; 16 (bit 16 = <strong>0</strong>)<br/>13 - 8 = 5 (bit 8 = <strong>1</strong>)<br/>5 - 4 = 1 (bit 4 = <strong>1</strong>)<br/>1 &lt; 2 (bit 2 = <strong>0</strong>)<br/>1 - 1 = 0 (bit 1 = <strong>1</strong>)<br/>Résultat binaire : <code>10101101</code>.<br/><br/><strong>2) Binaire → Hexa (blocs de 4 bits) :</strong><br/><code>1010</code> = 8+2 = 10 = <strong>A</strong> | <code>1101</code> = 8+4+1 = 13 = <strong>D</strong>.<br/>Résultat : <strong>0xAD</strong>."
      },
      {
        title: "Calcul de taille mémoire et ASCII",
        prompt: "Un fichier texte encodé en ASCII pur contient exactement 2 048 caractères. Quelle est sa taille en bits, en octets et en Kio (Kibioctets) ?",
        solution: "En ASCII standard (1 caractère = 1 octet = 8 bits) :<br/>• En octets : <strong>2 048 octets</strong><br/>• En bits : 2 048 × 8 = <strong>16 384 bits</strong><br/>• En Kio (1 Kio = 1 024 octets) : 2 048 ÷ 1 024 = <strong>2 Kio</strong>."
      },
      {
        title: "Comprendre le cycle d'exécution et l'OS",
        prompt: "Lorsqu'un utilisateur double-clique sur un programme stocké sur le SSD, expliquez dans l'ordre le rôle de l'OS, de la RAM et du CPU.",
        solution: "1) L'<strong>OS</strong> lit le fichier exécutable depuis le <strong>SSD</strong> et alloue un espace protégé en <strong>RAM</strong>.<br/>2) L'OS copie les instructions et données du programme dans la <strong>RAM</strong>.<br/>3) L'ordonnanceur de l'OS donne la main au <strong>CPU</strong>, qui exécute alors le cycle <em>Fetch → Decode → Execute</em> instruction après instruction."
      }
    ],
    quiz: [
      {
        q: "Quelle unité du processeur réalise les calculs mathématiques et les comparaisons ?",
        options: ["L'Unité de Contrôle", "L'UAL (ALU)", "La mémoire ROM", "Le bus d'adresses"],
        answer: 1,
        explanation: "L'UAL (Unité Arithmétique et Logique) exécute les opérations arithmétiques et logiques."
      },
      {
        q: "Quelle est la bonne suite d'étapes du cycle d'instruction d'un CPU ?",
        options: ["Execute - Decode - Fetch", "Decode - Fetch - Execute", "Fetch - Decode - Execute", "Store - Boot - Fetch"],
        answer: 2,
        explanation: "Le CPU va chercher l'instruction en mémoire (Fetch), la décode (Decode), puis l'exécute (Execute)."
      },
      {
        q: "Quel composant contient le programme BIOS/UEFI qui lance l'ordinateur au démarrage ?",
        options: ["La RAM", "Le Cache L1", "La mémoire ROM / Flash de la carte mère", "Le registre PC"],
        answer: 2,
        explanation: "Le BIOS/UEFI doit survivre sans électricité : il est stocké dans une mémoire non volatile (ROM/Flash) sur la carte mère."
      },
      {
        q: "Que vaut le nombre binaire 00111010 en décimal ?",
        options: ["42", "58", "62", "114"],
        answer: 1,
        explanation: "00111010 = 32 + 16 + 8 + 2 = 58."
      },
      {
        q: "Quel est l'encodage universel moderne permettant d'afficher accents, chinois et emojis ?",
        options: ["ASCII 7 bits", "Hexadécimal", "UTF-8 (Unicode)", "EBCDIC"],
        answer: 2,
        explanation: "UTF-8 (standard d'Unicode) est compatible avec ASCII tout en supportant plus de 140 000 caractères mondiaux."
      }
    ]
  }
];