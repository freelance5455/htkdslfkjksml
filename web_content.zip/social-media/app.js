const $=s=>document.querySelector(s);
const content=$('#content');

const SETTINGS_KEY='social_media_settings_v1';
const PROFILE_CACHE_KEY='social_media_profile_cache_v1';
const MIN_ROOM_AGE=13;
const defaultSettings={language:'bn',theme:'ocean',notifications:true,sounds:true,reducedMotion:false,profileVisibility:'public'};
const savedSettings=JSON.parse(localStorage.getItem(SETTINGS_KEY)||'null')||{};
const savedProfile=JSON.parse(localStorage.getItem(PROFILE_CACHE_KEY)||'null');
const appSettings={...defaultSettings,...savedSettings};

function t(bn,en){return appSettings.language==='bn'?bn:en;}
function calculateAge(dob){
  if(!dob)return null;
  const d=new Date(dob+'T00:00:00'); if(Number.isNaN(d.getTime()))return null;
  const now=new Date(); let age=now.getFullYear()-d.getFullYear();
  const m=now.getMonth()-d.getMonth(); if(m<0 || (m===0 && now.getDate()<d.getDate()))age--; return age;
}
function profileComplete(){
  const p=state.profile; return !!(p && p.name && p.email && Number.isFinite(Number(p.age)) && Number(p.age)>=0);
}
function ageToDob(age){
  const n=Number(age); if(!Number.isFinite(n)) return '';
  const now=new Date(); return `${now.getFullYear()-Math.floor(n)}-01-01`;
}
function roomAccessReason(){
  if(!state.auth)return 'login'; if(!profileComplete())return 'profile';
  const age=Number(state.profile.age ?? calculateAge(state.profile.dob)); if(age<MIN_ROOM_AGE)return 'age'; return null;
}
function saveSettings(){localStorage.setItem(SETTINGS_KEY,JSON.stringify(appSettings));}
function applySettings(){
  document.documentElement.dataset.theme=appSettings.theme;
  document.documentElement.dataset.motion=appSettings.reducedMotion?'reduced':'full';
  document.documentElement.lang=appSettings.language==='bn'?'bn':'en';
}
function saveProfileCache(){if(state.profile)localStorage.setItem(PROFILE_CACHE_KEY,JSON.stringify(state.profile));}
function clearProfileCache(){localStorage.removeItem(PROFILE_CACHE_KEY);}
function showAuth(mode='login'){
  $('#authGate')?.classList.remove('hidden'); $('#appShell').hidden=true; renderAuth(mode);
}
function renderAuth(mode='login'){
  const form=$('#authForm'); if(!form)return;
  $('#loginTab')?.classList.toggle('active',mode==='login'); $('#signupTab')?.classList.toggle('active',mode==='signup');
  if(window.socialFirebase && !window.socialFirebase.isConfigured()){
    form.innerHTML=`<div class="setup-warning"><b>${t('Firebase connection এখনো সেট করা হয়নি','Firebase connection is not configured yet')}</b><p>${t('এই অ্যাপের real account চালু করতে firebase-config.js-এ তোমার Firebase Web App config বসাতে হবে।','To enable real accounts, put your Firebase Web App config into firebase-config.js.')}</p><small>${t('Local account login ব্যবহার করা হচ্ছে না।','Local/demo login is intentionally disabled.')}</small></div>`;
    return;
  }
  form.innerHTML=mode==='login'
    ? `<button class="btn google-btn full-btn" onclick="googleLogin()">🌐 Continue with Google</button><div class="or-divider"><span>or</span></div><label>${t('Email','Email')}</label><input class="field" id="authEmail" type="email" autocomplete="email" placeholder="you@example.com"><label>${t('Password','Password')}</label><input class="field" id="authPassword" type="password" autocomplete="current-password" placeholder="••••••••"><button class="btn primary full-btn" onclick="loginReal()">${t('Login to Social Media','Login to Social Media')}</button><p class="auth-switch">${t('নতুন account?','New account?')} <button class="text-btn" onclick="renderAuth('signup')">${t('Create account','Create account')}</button></p>`
    : `<button class="btn google-btn full-btn" onclick="googleSignup()">🌐 Sign up with Google</button><div class="or-divider"><span>or use email</span></div><label>Email</label><input class="field" id="authEmail" type="email" autocomplete="email" placeholder="you@example.com"><label>Password</label><input class="field" id="authPassword" type="password" autocomplete="new-password" placeholder="${t('কমপক্ষে 6 characters','At least 6 characters')}"><label>${t('Confirm password','Confirm password')}</label><input class="field" id="authPassword2" type="password" autocomplete="new-password"><label>${t('Display name','Display name')}</label><input class="field" id="authName" maxlength="40" placeholder="MH MIRAZ"><label>Age</label><input class="field" id="authAge" type="number" inputmode="numeric" min="13" max="100" placeholder="13–100"><button class="btn primary full-btn" onclick="signupReal()">${t('Create real account','Create real account')}</button><p class="auth-switch">${t('আগে account আছে?','Already have an account?')} <button class="text-btn" onclick="renderAuth('login')">Login</button></p>`;
}
async function loginReal(){
  const email=$('#authEmail')?.value.trim().toLowerCase(), password=$('#authPassword')?.value;
  if(!email||!email.includes('@'))return alert(t('সঠিক email দিন।','Enter a valid email.'));
  if(!password)return alert(t('Password দিন।','Enter your password.'));
  try{await window.socialFirebase.signIn(email,password);}catch(e){alert(firebaseError(e));}
}
async function googleLogin(){try{await window.socialFirebase.signInWithGoogle();}catch(e){alert(firebaseError(e));}}
async function googleSignup(){try{await window.socialFirebase.signInWithGoogle();}catch(e){alert(firebaseError(e));}}
async function signupReal(){
  const email=$('#authEmail')?.value.trim().toLowerCase(), password=$('#authPassword')?.value, password2=$('#authPassword2')?.value;
  const name=$('#authName')?.value.trim(), age=Number($('#authAge')?.value), dob=ageToDob(age);
  if(!email||!email.includes('@'))return alert(t('সঠিক email দিন।','Enter a valid email.'));
  if(!password||password.length<6)return alert(t('Password কমপক্ষে 6 characters হতে হবে।','Password must be at least 6 characters.'));
  if(password!==password2)return alert(t('দুইটি password এক নয়।','Passwords do not match.'));
  if(!name)return alert(t('Display name দিন।','Enter a display name.'));
  if(!Number.isFinite(age)||age<MIN_ROOM_AGE||age>100)return alert(t(`বয়স ${MIN_ROOM_AGE} থেকে 100-এর মধ্যে দিন।`,`Enter an age between ${MIN_ROOM_AGE} and 100.`));
  try{await window.socialFirebase.signUp(email,password,{name,bio:'Connect • Talk • Learn • Share',dob,age});}catch(e){alert(firebaseError(e));}
}
function firebaseError(e){
  const code=e?.code||'';
  const map={'auth/invalid-credential':t('Email বা password ভুল।','Incorrect email or password.'),'auth/email-already-in-use':t('এই email দিয়ে account আগে থেকেই আছে।','An account already exists with this email.'),'auth/weak-password':t('Password আরও শক্ত করুন।','Choose a stronger password.'),'auth/too-many-requests':t('অনেকবার চেষ্টা হয়েছে। একটু পরে আবার চেষ্টা করুন।','Too many attempts. Try again later.'),'auth/popup-closed-by-user':t('Google login বন্ধ করা হয়েছে।','Google sign-in was cancelled.'),'auth/popup-blocked':t('Browser popup block করেছে। আবার চেষ্টা করুন।','The browser blocked the Google popup. Try again.'),'auth/operation-not-allowed':t('Firebase-এ এই sign-in method এখনো চালু হয়নি।','This sign-in method is not enabled in Firebase yet.')};
  return map[code]||t('Account তৈরি/লগইন করা যায়নি। Firebase setup ও internet connection পরীক্ষা করুন।','Could not sign in or create the account. Check Firebase setup and your internet connection.');
}
function enterApp(){$('#authGate')?.classList.add('hidden');$('#appShell').hidden=false;render();if(!profileComplete())setTimeout(openProfileEdit,180);}
async function logout(){try{await window.socialFirebase.logout();}catch(e){}state.auth=null;state.profile=null;clearProfileCache();showAuth('login');}


const roomNames=[
  'Night Talk Lounge','বন্ধুদের আড্ডা','Music & Chill','বাংলা Talk Zone','Late Night Vibes',
  'Open Mic Bangladesh','Story Corner','Gaming Adda','Islamic Reminder','Movie Talk',
  'Love & Life','Career Chat','Comedy Club','Voice Family','Travel Talk','Sports Lounge',
  'News Discussion','Poetry House','Study Circle','Friendship Zone'
];
const hosts=['MH MIRAZ','Roni','Suhag','Nila','Apon','Hridoy','Yasin','Mim','Sami','Rafi'];

const state={
  view:'home', name:savedProfile?.name||'MH MIRAZ', bio:savedProfile?.bio||'Connect • Talk • Learn • Share',
  auth:null, profile:savedProfile||{name:savedProfile?.name||'',bio:savedProfile?.bio||'',email:'',dob:''},
  theme:'ocean', banner:'assets/bg-main.jpg', avatar:'',
  following:new Set(), liked:new Set(),
  posts:[],
  chats:[],
  rooms:[],
  roomLimit:60,
  selectedRoom:null
};

function esc(s){
  return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function layout(){
  document.querySelectorAll('[data-view]').forEach(b=>{
    b.classList.toggle('active',b.dataset.view===state.view);
    b.onclick=()=>{state.view=b.dataset.view;render();}
  });
  render();
}
function render(){
  if(state.view==='home')home();
  if(state.view==='discover')discover();
  if(state.view==='messages')messages();
  if(state.view==='broadcast')broadcast();
  if(state.view==='profile')profile();
  if(state.view==='settings')settings();
}

function home(){
  content.innerHTML=`
  <div class="hero">
    <div class="hero-cover"></div>
    <div class="hero-info">
      <div class="hero-row">
        <div>
          <div class="avatar">${state.avatar?`<img src="${esc(state.avatar)}" alt="Profile photo">`:esc(state.name[0]||'U')}</div>
          <h1>${esc(state.name)}</h1>
          <p class="muted">${esc(state.bio)}</p>
        </div>
        <button class="btn" onclick="openProfileEdit()">Edit profile</button>
      </div>
      <div class="muted">Public profile · Follow people · Share moments</div>
    </div>
  </div>
  <div class="welcome-strip"><div><span class="eyebrow">SOCIAL MEDIA</span><h2>${t('Connect • Talk • Learn • Share','Connect • Talk • Learn • Share')}</h2><p>${t('বন্ধুত্বের সঙ্গে শেখা, কথা বলা আর নিজের কথা প্রকাশ করার জায়গা।','A place to learn, talk, connect and share your voice.')}</p></div><div class="welcome-mark">✦</div></div>
  <div class="study-card"><div><span class="eyebrow">📚 STUDY CORNER</span><h3>${t('আজ একটু শিখি','Learn something today')}</h3><p>${t('ছোট লক্ষ্য, নিয়মিত practice, আর নিজের ভাষায় শেখা।','Small goals, regular practice, and learning in your own words.')}</p></div><button class="btn" onclick="openStudy()">${t('Open study','Open study')}</button></div>
  <div class="section-head"><h2>Home Feed</h2><button class="btn" onclick="openCreate('post')">＋ Post</button></div>
  <div class="composer">
    <div class="composer-row"><div class="mini-avatar">${esc(state.name[0]||'U')}</div><button class="fake-input" onclick="openCreate('post')">What’s happening?</button></div>
    <div class="quick-actions tool-grid">
      <button class="btn tool" onclick="openCreate('post')"><span class="tool-icon">▧</span><span>Photo / Video</span></button>
      <button class="btn tool" onclick="state.view='broadcast';render()"><span class="tool-icon">◈</span><span>Voice Rooms</span></button>
      <button class="btn tool" onclick="openCreate('message')"><span class="tool-icon">✉</span><span>Message</span></button>
      <button class="btn tool" onclick="state.view='discover';render()"><span class="tool-icon">＋</span><span>Find People</span></button>
    </div>
  </div>${state.posts.map(postHTML).join('')}`;
}

function postHTML(p){
  return `<article class="post"><div class="post-head"><div class="mini-avatar">${esc(p.user[0])}</div><div><strong>${esc(p.user)}</strong><span class="muted">${esc(p.handle)} · Public</span></div><button class="icon-btn post-more" onclick="postMenu(${p.id})">⋯</button></div><p>${esc(p.text)}</p><div class="muted">${p.likes} likes · ${p.comments} comments</div><div class="post-actions"><button onclick="likePost(${p.id})">♡ Like</button><button onclick="commentPost(${p.id})">◌ Comment</button><button onclick="sharePost(${p.id})">↗ Share</button></div></article>`;
}

function discover(){
  content.innerHTML=`<div class="section-head"><h2>Discover People</h2><button class="btn" onclick="openCreate('post')">Create</button></div><div class="card"><p class="muted">Real profiles will appear here after Firebase user/profile data is connected.</p></div><div class="grid">${[].map(n=>`<div class="card"><div class="post-head"><div class="mini-avatar">${n[0]}</div><div><strong>${n}</strong><span class="muted">@${n.toLowerCase().replaceAll(' ','')}</span></div></div><p class="muted">Creator · Public profile</p><button class="btn ${state.following.has(n)?'primary':''}" onclick="toggleFollow('${n}')">${state.following.has(n)?'Following':'＋ Follow'}</button></div>`).join('')}</div>`;
}

function messages(){
  content.innerHTML=`<div class="section-head"><h2>Messages</h2><button class="btn primary" onclick="openCreate('message')">＋ New message</button></div><div class="card">${state.chats.map(c=>`<div class="chat" onclick="openChat('${esc(c.name)}')"><div class="mini-avatar">${esc(c.name[0])}</div><div style="flex:1"><strong>${esc(c.name)}</strong><div class="muted">${esc(c.last)}</div></div>${c.count?`<span class="tag">${c.count}</span>`:''}</div>`).join('')}</div>`;
}

function broadcast(){
  const reason=roomAccessReason();
  if(reason){
    content.innerHTML=`<div class="access-card"><div class="access-icon">🔐</div><span class="eyebrow">ROOM ACCESS</span><h2>${reason==='profile'?'আগে account profile সম্পূর্ণ করো':reason==='age'?'Age requirement পূরণ হয়নি':'আগে Login করো'}</h2><p class="muted">${reason==='profile'?'Room-এ যাওয়ার আগে name, email এবং date of birth দিতে হবে।':reason==='age'?`Voice room-এর জন্য minimum age ${MIN_ROOM_AGE}+ সেট করা আছে।`:'Email দিয়ে login করলে তারপর room access চালু হবে।'}</p><button class="btn primary" onclick="${reason==='profile'?'openProfileEdit()':'showAuth(\'login\')'}">${reason==='profile'?'Edit account':'Login'}</button></div>`;
    return;
  }
  content.innerHTML=`
  <div class="section-head room-title-row">
    <div><span class="eyebrow">LIVE VOICE</span><h2>Broadcast Voice Rooms</h2><p class="muted">Firebase-এ তৈরি real room এখানে দেখা যাবে।</p></div>
    <button class="btn primary" onclick="createRoom()">＋ Create room</button>
  </div>
  <div class="room-stats">
    <div class="room-stat"><strong>${state.rooms.length}</strong><span>Rooms</span></div>
    <div class="room-stat"><strong>${state.rooms.length}</strong><span>Live rooms</span></div>
    <div class="room-stat"><strong>15</strong><span>Target seats / room</span></div>
  </div>
  <div class="room-list-shell">
    <div class="room-list-head"><span>#</span><span>ROOM / TOPIC</span><span>HOST</span><span>LIVE</span><span>PEOPLE</span></div>
    <div id="roomList">${state.rooms.length ? roomRows() : '<div class="card" style="margin:16px">কোনো real voice room এখনো তৈরি হয়নি। প্রথমে Firebase room backend connect করতে হবে।</div>'}</div>
    <div class="load-more-wrap"><button class="btn" id="loadRoomsBtn" onclick="loadMoreRooms()" ${state.rooms.length?'':'style="display:none"'}>আরও রুম দেখাও ↓</button><span id="roomCount" class="muted">0 / ${state.rooms.length.toLocaleString()}</span></div>
  </div>`;
}

function roomRows(){
  return state.rooms.slice(0,state.roomLimit).map(r=>`
    <button class="room-row" onclick="openVoiceRoom(${r.id})">
      <span class="room-no">${r.id}</span>
      <span class="room-main"><span class="room-icon">🎙️</span><span><strong>${esc(r.name)}</strong><small>${esc(r.topic)}</small></span></span>
      <span class="room-host"><span class="host-dot"></span>${esc(r.host)}</span>
      <span class="live-pill">${esc(r.status)}</span>
      <span class="people-count">👥 ${r.listeners}/15</span>
    </button>`).join('');
}

function loadMoreRooms(){
  state.roomLimit=Math.min(state.roomLimit+60,state.rooms.length);
  const list=$('#roomList');
  if(list){list.innerHTML=roomRows();}
  const count=$('#roomCount');
  if(count)count.textContent=`১-${Math.min(state.roomLimit,state.rooms.length).toLocaleString()} / ${state.rooms.length.toLocaleString()}`;
  if(state.roomLimit>=state.rooms.length){const b=$('#loadRoomsBtn');if(b)b.style.display='none';}
}

function createRoom(){
  alert('Room backend এখনও connect করা হয়নি। Firebase room database এবং voice-media service connect করার পর এই button real room তৈরি করবে.');
}
function openRoomEditor(){
  $('#modalBody').innerHTML=`
    <h2>নতুন Voice Room</h2>
    <p class="muted">রুম তৈরি করলে তুই Host হিসেবে শুরু করবি।</p>
    <label>Room name</label><input class="field" id="newRoomName" placeholder="যেমন: MH MIRAZ Live Adda">
    <label>Topic</label><input class="field" id="newRoomTopic" placeholder="আড্ডা, গান, গল্প...">
    <label>Background</label><select class="field" id="newRoomBg"><option value="space">Space</option><option value="purple">Purple Glow</option><option value="sunset">Sunset</option><option value="forest">Forest</option><option value="ocean">Ocean</option></select>
    <button class="btn primary full-btn" onclick="saveNewRoom()">Create & Enter</button>`;
  $('#modal').classList.remove('hidden');
}
function saveNewRoom(){
  const name=$('#newRoomName').value.trim()||'MH MIRAZ Live Adda';
  const topic=$('#newRoomTopic').value.trim()||'Open voice chat';
  const bg=$('#newRoomBg').value;
  const room={id:state.rooms.length+1,name,host:state.name,listeners:1,status:'Live now',topic,bg};
  state.rooms.unshift(room);
  closeModal();
  openVoiceRoom(room.id);
}

function openVoiceRoom(id){
  const reason=roomAccessReason();
  if(reason){broadcast();return;}
  const room=state.rooms.find(r=>r.id===id);
  if(!room)return;
  state.selectedRoom=id;
  const seats=Array.from({length:15},(_,i)=>i===0?{name:room.host,role:'Host',muted:false,online:true}:{name:'',role:'Listener',muted:false,online:false});
  roomSeats=seats;
  roomBg=room.bg||['main','spacephone','cybercar','winter'][id%4];
  renderVoiceRoom(room);
}

let roomSeats=[];
let roomBg='space';
let musicOn=false;
let micOn=true;
let adminMode=true;
let currentUserRole='Host';

function renderVoiceRoom(room){
  const bgClass=`room-bg-${roomBg}`;
  content.innerHTML=`
  <div class="voice-room ${bgClass}">
    <div class="voice-room-top">
      <button class="room-back" onclick="state.view='broadcast';render()">← Rooms</button>
      <div class="live-room-label"><span class="pulse"></span> LIVE · ${esc(room.status)}</div>
      <button class="room-more" onclick="roomOptions()">⋯</button>
    </div>
    <div class="voice-room-hero">
      <span class="eyebrow">VOICE ROOM</span>
      <h1>${esc(room.name)}</h1>
      <p>${esc(room.topic)} · Host: <strong>${esc(room.host)}</strong></p>
      <div class="room-quick-stats"><span>👥 ${room.listeners}/15</span><span>🎙️ 15 seats</span><span>🛡️ Host + Moderators</span></div>
    </div>

    <div class="seat-stage">
      <div class="seat-grid">
        ${roomSeats.map((s,i)=>seatHTML(s,i)).join('')}
      </div>
    </div>

    <div class="room-tools">
      <button class="room-tool ${micOn?'on':''}" onclick="toggleMic()"><span>🎙️</span><b>${micOn?'Mic on':'Mic off'}</b></button>
      <button class="room-tool" onclick="emojiPanel()"><span>😊</span><b>Emoji</b></button>
      <button class="room-tool ${musicOn?'on':''}" onclick="toggleMusic()"><span>🎵</span><b>${musicOn?'Music on':'Music'}</b></button>
      <button class="room-tool" onclick="moderatorPanel()"><span>🛡️</span><b>Admins</b></button>
      <button class="room-tool" onclick="backgroundPanel()"><span>🖼️</span><b>Background</b></button>
    </div>

    <div class="room-chat-bar">
      <input class="field" id="roomChatInput" placeholder="রুমে মেসেজ লিখুন...">
      <button class="btn primary" onclick="sendRoomChat()">Send</button>
    </div>
    <div id="roomActivity" class="room-activity"><span>✨ ${esc(room.host)} room শুরু করেছে</span></div>
  </div>`;
}

function seatHTML(s,i){
  const muted=s.muted?'muted':'';
  const host=s.role==='Host';
  const moderator=s.role==='Moderator';
  return `<button class="seat ${s.online?'online':'empty'} ${host?'host-seat':''}" onclick="seatAction(${i})">
    <span class="seat-avatar">${s.online?esc(s.name[0]):'＋'}</span>
    <span class="seat-name">${s.online?esc(s.name):'Empty seat'}</span>
    <span class="seat-role">${host?'👑 Host':moderator?'🛡️ Moderator':s.online?'Listener':'Available'}</span>
    ${s.online?`<span class="seat-mic ${muted?'is-muted':''}">${muted?'🔇':'🎙️'}</span>`:''}
  </button>`;
}

function refreshSeats(){
  const grid=$('.seat-grid');
  if(grid)grid.innerHTML=roomSeats.map((s,i)=>seatHTML(s,i)).join('');
  const count=$('.room-quick-stats span');
  const online=roomSeats.filter(s=>s.online).length;
  if(count)count.textContent=`👥 ${online}/15`;
}

function seatAction(i){
  const s=roomSeats[i];
  if(!s.online){
    s.online=true;s.name='Guest '+(i+1);s.role='Listener';s.muted=false;
    addActivity(`${s.name} seat-এ ঢুকেছে`);
    refreshSeats();
    return;
  }
  // সাধারণ সদস্য নিজের mic নিজেই নিয়ন্ত্রণ করবে।
  if(i===0){
    toggleMic();
    return;
  }
  // অন্য সদস্যকে mute/unmute করার ক্ষমতা শুধু Host/Admin panel থেকে।
  if(currentUserRole==='Host' && adminMode){
    s.muted=!s.muted;
    addActivity(`${s.name} ${s.muted?'mute':'unmute'} করা হয়েছে`);
    refreshSeats();
  }
}

function toggleMic(){
  micOn=!micOn;
  addActivity(`তোমার mic ${micOn?'on':'off'}`);
  renderVoiceRoom(state.rooms.find(r=>r.id===state.selectedRoom));
}
function toggleMusic(){
  musicOn=!musicOn;
  addActivity(`Admin music ${musicOn?'চালু':'বন্ধ'} করেছে`);
  renderVoiceRoom(state.rooms.find(r=>r.id===state.selectedRoom));
}
function emojiPanel(){
  const emojis=['❤️','😂','🔥','👏','😍','🎉','😎','✨','🎙️','👍'];
  $('#modalBody').innerHTML=`<h2>Room Emoji</h2><div class="emoji-grid">${emojis.map(e=>`<button onclick="sendEmoji('${e}')">${e}</button>`).join('')}</div>`;
  $('#modal').classList.remove('hidden');
}
function sendEmoji(e){
  closeModal();addActivity(`${e} emoji পাঠানো হয়েছে`);
}
function moderatorPanel(){
  $('#modalBody').innerHTML=`
    <h2>Host & Moderators</h2>
    <p class="muted">Host/Admin-এর কাছেই room control থাকবে। সদস্যরা শুধু নিজের mic mute/unmute করতে পারবে।</p>
    <div class="admin-list">${roomSeats.filter(s=>s.online).map((s,i)=>`<div class="admin-row"><span><b>${esc(s.name)}</b><small>${s.role}</small></span>${s.role==='Host'?'<span class="tag">HOST</span>':`<button class="btn ${s.role==='Moderator'?'primary':''}" onclick="toggleModerator(${roomSeats.indexOf(s)})">${s.role==='Moderator'?'Moderator':'Make admin'}</button>`}</div>`).join('')}</div>`;
  $('#modal').classList.remove('hidden');
}
function toggleModerator(i){
  const s=roomSeats[i];
  if(!s||s.role==='Host')return;
  s.role=s.role==='Moderator'?'Listener':'Moderator';
  closeModal();refreshSeats();addActivity(`${s.name} ${s.role==='Moderator'?'কে moderator/admin করা হয়েছে':'এর admin role সরানো হয়েছে'}`);
  setTimeout(moderatorPanel,50);
}
function backgroundPanel(){
  const bgs=[
    ['main','Digital City'],
    ['spacephone','Galaxy Phone'],
    ['cybercar','Cyber Night'],
    ['winter','Winter Romance']
  ];
  $('#modalBody').innerHTML=`<h2>Room Background</h2><p class="muted">রুমের জন্য ছবির background বেছে নাও।</p><div class="bg-picker">${bgs.map(([k,n])=>`<button class="bg-choice room-bg-${k}" onclick="setRoomBackground('${k}')"><span>${n}</span></button>`).join('')}</div>`;
  $('#modal').classList.remove('hidden');
}
function setRoomBackground(k){
  roomBg=k;closeModal();renderVoiceRoom(state.rooms.find(r=>r.id===state.selectedRoom));
  addActivity(`${k} background selected`);
}
function roomOptions(){
  $('#modalBody').innerHTML=`<h2>Room options</h2><div class="menu-list"><button onclick="addActivity('Room link copied')">↗ Copy room link</button><button onclick="alert('Report options opened.')">⚑ Report room</button><button onclick="alert('Invite friends.')">＋ Invite friends</button></div>`;
  $('#modal').classList.remove('hidden');
}
function addActivity(text){
  const a=$('#roomActivity');
  if(a){a.innerHTML=`<span>✨ ${esc(text)}</span>`;a.classList.remove('activity-pop');void a.offsetWidth;a.classList.add('activity-pop');}
}
function sendRoomChat(){
  const input=$('#roomChatInput');
  if(!input||!input.value.trim())return;
  addActivity(`${state.name}: ${input.value.trim()}`);
  input.value='';
}

function profile(){
  const age=calculateAge(state.profile?.dob);
  content.innerHTML=`<div class="section-head"><h2>Your Profile</h2><button class="btn" onclick="openProfileEdit()">Edit account</button></div><div class="card profile-card"><div class="avatar">${esc(state.name[0]||'U')}</div><h2>${esc(state.name)}</h2><p class="muted">${esc(state.bio)}</p><div class="profile-meta"><span>✉ ${esc(state.profile?.email||'')}</span><span>🎂 ${age===null?'Age not set':age+' years'}</span><span>${age!==null&&age>=MIN_ROOM_AGE?'✓ Room access ready':'⚠ Complete age info'}</span></div><div class="grid"><div><div class="stat">${state.posts.length}</div><span class="muted">Posts</span></div><div><div class="stat">${state.following.size}</div><span class="muted">Following</span></div></div></div><h3>Your posts</h3>${state.posts.filter(p=>p.user===state.name).map(postHTML).join('')||'<div class="card muted">তোর নিজের পোস্ট এখানে দেখা যাবে।</div>'}`;
}
function settings(){
  content.innerHTML=`<div class="section-head"><div><span class="eyebrow">APP CONTROL</span><h2>${t('Settings','Settings')}</h2><p class="muted">${t('অ্যাপের ভাষা, চেহারা, নোটিফিকেশন ও account এখান থেকে নিয়ন্ত্রণ করো।','Control the app language, appearance, notifications and account here.')}</p></div></div>
  <div class="settings-grid">
    <div class="settings-section"><h3>🌐 ${t('Language','Language')}</h3><div class="setting-row"><span><b>${t('অ্যাপের ভাষা','App language')}</b><small>${t('Bangla বা English বেছে নাও','Choose Bangla or English')}</small></span><select class="field compact" onchange="changeLanguage(this.value)"><option value="bn" ${appSettings.language==='bn'?'selected':''}>বাংলা</option><option value="en" ${appSettings.language==='en'?'selected':''}>English</option></select></div></div>
    <div class="settings-section"><h3>🎨 ${t('Appearance','Appearance')}</h3><div class="setting-row"><span><b>${t('Theme','Theme')}</b><small>${t('অ্যাপের look পরিবর্তন করো','Change the app look')}</small></span><select class="field compact" onchange="changeTheme(this.value)"><option value="ocean" ${appSettings.theme==='ocean'?'selected':''}>Ocean</option><option value="dark" ${appSettings.theme==='dark'?'selected':''}>Dark</option><option value="light" ${appSettings.theme==='light'?'selected':''}>Light</option></select></div><div class="setting-row"><span><b>${t('Motion','Motion')}</b><small>${t('Animation কমাতে পারো','Reduce animations')}</small></span><button class="switch ${appSettings.reducedMotion?'on':''}" onclick="toggleSetting('reducedMotion')"><span></span></button></div></div>
    <div class="settings-section"><h3>🔔 ${t('Notifications & sound','Notifications & sound')}</h3><div class="setting-row"><span><b>${t('Notifications','Notifications')}</b><small>${t('নতুন message ও room alerts','New message and room alerts')}</small></span><button class="switch ${appSettings.notifications?'on':''}" onclick="toggleSetting('notifications')"><span></span></button></div><div class="setting-row"><span><b>${t('Sound effects','Sound effects')}</b><small>${t('Button ও room sound','Button and room sound')}</small></span><button class="switch ${appSettings.sounds?'on':''}" onclick="toggleSetting('sounds')"><span></span></button></div></div>
    <div class="settings-section"><h3>🔒 ${t('Privacy','Privacy')}</h3><div class="setting-row"><span><b>${t('Profile visibility','Profile visibility')}</b><small>${t('কে তোমার profile দেখতে পারবে','Who can see your profile')}</small></span><select class="field compact" onchange="changePrivacy(this.value)"><option value="public" ${appSettings.profileVisibility==='public'?'selected':''}>${t('Public','Public')}</option><option value="followers" ${appSettings.profileVisibility==='followers'?'selected':''}>${t('Followers','Followers')}</option><option value="private" ${appSettings.profileVisibility==='private'?'selected':''}>${t('Private','Private')}</option></select></div></div>
    <div class="settings-section"><h3>👤 ${t('Account','Account')}</h3><div class="menu-list"><button onclick="openProfileEdit()">◎ ${t('Edit account','Edit account')}</button><button onclick="alert(t('Security controls পরের backend stage-এ যুক্ত হবে।','Security controls will be connected in the backend stage.'))">▣ ${t('Security','Security')}</button><button onclick="logout()">⇥ ${t('Log out','Log out')}</button></div></div>
    <div class="settings-section about-settings"><h3>ℹ️ ${t('About SOCIAL MEDIA','About SOCIAL MEDIA')}</h3><p class="muted">${t('Connect • Talk • Learn • Share','Connect • Talk • Learn • Share')}</p><small>Version 0.2 • ${t('Real account integration stage','Real account integration stage')}</small></div>
  </div>`;
}
function changeLanguage(v){appSettings.language=v;saveSettings();applySettings();render();}
function changeTheme(v){appSettings.theme=v;saveSettings();applySettings();render();}
function changePrivacy(v){appSettings.profileVisibility=v;saveSettings();render();}
function toggleSetting(k){appSettings[k]=!appSettings[k];saveSettings();applySettings();render();}

function openStudy(){
  $('#modalBody').innerHTML=`<h2>📚 ${t('Study Corner','Study Corner')}</h2><div class="study-notes"><div><b>1.</b><span>${t('আজকের ১টি নতুন শব্দ শিখো এবং বাক্যে ব্যবহার করো।','Learn one new word today and use it in a sentence.')}</span></div><div><b>2.</b><span>${t('১০ মিনিট মনোযোগ দিয়ে পড়ো, তারপর ২ মিনিট বিরতি নাও।','Study with focus for 10 minutes, then take a 2-minute break.')}</span></div><div><b>3.</b><span>${t('যা শিখেছো, নিজের ভাষায় কাউকে বুঝিয়ে বলো।','Explain what you learned in your own words.')}</span></div></div><button class="btn primary full-btn" onclick="closeModal()">${t('Done','Done')}</button>`;
  $('#modal').classList.remove('hidden');
}
function openCreate(type){
  let title=type==='post'?'Create post':type==='broadcast'?'Create broadcast':'New message';
  $('#modalBody').innerHTML=`<h2>${title}</h2><label>${type==='message'?'Recipient':'Content'}</label>${type==='message'?'<input class="field" id="recipient" placeholder="Name">':''}<textarea id="body" rows="5" placeholder="Write something..."></textarea><button class="btn primary" onclick="submitCreate('${type}')">Publish / Send</button>`;
  $('#modal').classList.remove('hidden');
}
function submitCreate(type){
  const text=$('#body').value.trim();if(!text)return alert('কিছু লিখে নে।');
  if(type==='message')state.chats.unshift({name:$('#recipient').value||'New contact',last:text,count:0});
  else state.posts.unshift({id:Date.now(),user:state.name,handle:'@you',text,likes:0,comments:0});
  closeModal();render();
}
function openProfileEdit(){
  const p=state.profile||{};
  $('#modalBody').innerHTML=`<h2>Edit account</h2><p class="muted">Room access-এর আগে এই তথ্যগুলো সম্পূর্ণ করতে হবে।</p><label>Display name</label><input class="field" id="editName" value="${esc(p.name||state.name)}" maxlength="40"><label>Bio</label><textarea id="editBio" rows="3" maxlength="140" placeholder="নিজের সম্পর্কে ছোট করে লিখুন">${esc(p.bio||state.bio)}</textarea><label>Email</label><input class="field readonly-field" id="editEmail" value="${esc(p.email||state.auth?.email||'')}" type="email" readonly><label>Age</label><input class="field" id="editAge" value="${esc(p.age ?? calculateAge(p.dob) ?? '')}" type="number" inputmode="numeric" min="0" max="100"><p class="small-note">🎙️ Voice room access-এর জন্য minimum age ${MIN_ROOM_AGE}+। বয়স কম হলে room access বন্ধ থাকবে।</p><button class="btn primary full-btn" onclick="saveProfile()">Save account</button>`;
  $('#modal').classList.remove('hidden');
}
function saveProfile(){
  const name=$('#editName').value.trim();const bio=$('#editBio').value.trim();const email=$('#editEmail').value.trim().toLowerCase();const age=Number($('#editAge').value);const dob=ageToDob(age);
  if(!name)return alert('Display name দিন।');
  if(!email||!email.includes('@'))return alert('Email ঠিক আছে কি না দেখুন।');
  if(!Number.isFinite(age)||age<0||age>100)return alert('সঠিক বয়স দিন।');
  state.profile={name,bio:bio||'Connect • Talk • Learn • Share',email,dob,age:calculateAge(dob)};state.name=name;state.bio=state.profile.bio;saveProfileCache();if(state.auth?.uid) window.socialFirebase.saveProfile(state.auth.uid,state.profile).catch(e=>alert(firebaseError(e)));closeModal();render();
}
function openChat(name){alert(`Chat with ${name}\n\nMessage sending will be connected to the backend in the next stage.`);}
function toggleFollow(n){state.following.has(n)?state.following.delete(n):state.following.add(n);render();}
function likePost(id){const p=state.posts.find(x=>x.id===id);if(!p)return;if(state.liked.has(id)){p.likes--;state.liked.delete(id)}else{p.likes++;state.liked.add(id)}render();}
function commentPost(id){const p=state.posts.find(x=>x.id===id);const c=prompt('Comment লিখুন');if(c&&c.trim()){p.comments++;alert('Comment added.');render();}}
function sharePost(id){alert('Share options: Copy link, share to messages, share to broadcast.')}
function postMenu(id){$('#modalBody').innerHTML=`<h2>Post options</h2><div class="menu-list"><button onclick="alert('Save post')">▣ Save post</button><button onclick="alert('Report options')">⚑ Report</button><button onclick="alert('Copy post link')">↗ Copy link</button></div>`;$('#modal').classList.remove('hidden');}
function setTheme(t){state.theme=t;document.documentElement.dataset.theme=t;render();}
function closeModal(){$('#modal').classList.add('hidden');}
$('#closeModal').onclick=closeModal;
$('#modal').addEventListener('click',e=>{if(e.target.id==='modal')closeModal();});
$('#createBtn').onclick=()=>openCreate('post');
$('#searchBtn').onclick=()=>alert('Search people, posts and broadcasts.');
$('#notifyBtn').onclick=()=>alert('No new notifications.');
$('#topMenuBtn').onclick=()=>settings();
appSettings.theme=appSettings.theme||'ocean'; applySettings();
$('#loginTab')?.addEventListener('click',()=>renderAuth('login'));
$('#signupTab')?.addEventListener('click',()=>renderAuth('signup'));
window.addEventListener('firebase-auth-changed',async e=>{
  const user=e.detail.user;
  if(!user){state.auth=null;state.profile=savedProfile||{name:'',bio:'',email:'',dob:''};showAuth('login');return;}
  state.auth={uid:user.uid,email:user.email,loggedIn:true};
  try{const p=await window.socialFirebase.loadProfile(user.uid);if(p)state.profile=p;else state.profile={name:user.displayName||user.email.split('@')[0],bio:'Connect • Talk • Learn • Share',email:user.email,dob:''};saveProfileCache();state.name=state.profile.name;state.bio=state.profile.bio;enterApp();}catch(err){alert(firebaseError(err));}
});
window.__firebaseReady?.then(()=>{if(!window.socialFirebase.isConfigured())showAuth('login');});


document.addEventListener('click',e=>{
  const b=e.target.closest('button');
  if(!b)return;
  b.classList.remove('tap-pop');
  void b.offsetWidth;
  b.classList.add('tap-pop');
});
