// Firebase Web App configuration for MH MIRAZ / Miraz Voice.
// This is the public Web SDK config (not a service-account private key).
export const firebaseConfig = {
  apiKey: "AIzaSyAZVO-n5NfLImk7MU64GQP7br3uVvOerNo",
  authDomain: "miraz-voice.firebaseapp.com",
  projectId: "miraz-voice",
  storageBucket: "miraz-voice.firebasestorage.app",
  messagingSenderId: "676373661521",
  appId: "1:676373661521:web:3a2f82bf735763ccd6f570",
  measurementId: "G-3NHVYEXQP6"
};
