// Firebase Web App configuration for miraz-voice project.
// Do NOT put service-account private keys here.
export const firebaseConfig = {
  apiKey: "AIzaSyAZVO-n5NfLImk7MU64GQP7br3uVvOerNo",
  authDomain: "miraz-voice.firebaseapp.com",
  projectId: "miraz-voice",
  storageBucket: "miraz-voice.firebasestorage.app",
  messagingSenderId: "676373661521",
  appId: "1:676373661521:web:c0440d8b5dc005c8d6f570",
  measurementId: "G-XGZ89MC0NN"
};
