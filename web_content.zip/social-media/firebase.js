// SOCIAL MEDIA - Firebase runtime
// Replace the values in firebase-config.js with the Firebase Web App config
// from Firebase Console > Project settings > Your apps.
import { initializeApp } from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js';
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, updateProfile, GoogleAuthProvider,
  signInWithPopup
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js';
import {
  getFirestore, doc, getDoc, setDoc, updateDoc, serverTimestamp
} from 'https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js';
import { firebaseConfig } from './firebase-config.js';

const configured = firebaseConfig && firebaseConfig.apiKey && !String(firebaseConfig.apiKey).includes('PASTE_');
let auth = null;
let db = null;
let currentUser = null;

async function boot() {
  if (!configured) {
    window.__firebaseStatus = { configured: false, error: 'Firebase config is not filled in yet.' };
    return null;
  }
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  return new Promise(resolve => {
    let first = true;
    onAuthStateChanged(auth, async user => {
      currentUser = user || null;
      window.__firebaseUser = currentUser;
      window.dispatchEvent(new CustomEvent('firebase-auth-changed', { detail: { user: currentUser } }));
      if (first) { first = false; resolve(currentUser); }
    });
  });
}

window.__firebaseReady = boot();
window.socialFirebase = {
  isConfigured: () => configured,
  async signIn(email, password) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    return signInWithEmailAndPassword(auth, email, password);
  },
  async signInWithGoogle() {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    const existing = await getDoc(doc(db, 'users', cred.user.uid));
    if (!existing.exists()) {
      await setDoc(doc(db, 'users', cred.user.uid), {
        name: cred.user.displayName || cred.user.email?.split('@')[0] || 'User',
        bio: 'Connect • Talk • Learn • Share',
        email: cred.user.email || '',
        provider: 'google',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }, { merge: true });
    }
    return cred.user;
  },
  async signUp(email, password, profile) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    await updateProfile(cred.user, { displayName: profile.name });
    await setDoc(doc(db, 'users', cred.user.uid), {
      name: profile.name,
      bio: profile.bio || '',
      email: cred.user.email,
      dob: profile.dob,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    }, { merge: true });
    return cred.user;
  },
  async loadProfile(uid) {
    await window.__firebaseReady;
    if (!configured) return null;
    const snap = await getDoc(doc(db, 'users', uid));
    return snap.exists() ? snap.data() : null;
  },
  async saveProfile(uid, profile) {
    await window.__firebaseReady;
    if (!configured) throw new Error('FIREBASE_CONFIG_MISSING');
    await setDoc(doc(db, 'users', uid), {
      ...profile,
      email: currentUser?.email || profile.email,
      updatedAt: serverTimestamp()
    }, { merge: true });
    if (currentUser && currentUser.displayName !== profile.name) {
      await updateProfile(currentUser, { displayName: profile.name });
    }
  },
  async logout() {
    await window.__firebaseReady;
    if (auth) await signOut(auth);
  },
  onAuthChanged(fn) { window.addEventListener('firebase-auth-changed', e => fn(e.detail.user)); }
};
