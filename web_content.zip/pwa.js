// Student Hisab PWA Install Logic
(function(){
  let deferredPrompt = null;
  let installBtn = null;

  function createInstallUI(){
    // Prevent duplicate
    if(document.getElementById('pwaInstallContainer')) return;

    const style = document.createElement('style');
    style.textContent = `
      #pwaInstallContainer{
        position:fixed;
        left:50%;
        bottom:88px;
        transform:translateX(-50%) translateY(20px);
        z-index:999999;
        width:min(calc(100% - 24px), 420px);
        background:linear-gradient(135deg, #205A43 0%, #2E7D5B 55%, #43A879 100%);
        color:white;
        border-radius:18px;
        padding:14px 14px 14px 16px;
        display:flex;
        align-items:center;
        gap:12px;
        box-shadow:0 12px 30px rgba(46,125,91,.28);
        opacity:0;
        pointer-events:none;
        transition: all .35s cubic-bezier(.34,1.56,.64,1);
      }
      #pwaInstallContainer.show{
        opacity:1;
        pointer-events:auto;
        transform:translateX(-50%) translateY(0);
      }
      #pwaInstallIcon{
        width:44px;height:44px;flex:none;
        background:rgba(255,255,255,.15);
        border-radius:12px;
        display:grid;place-items:center;
        font-size:22px;
      }
      #pwaInstallText{flex:1;min-width:0}
      #pwaInstallText strong{display:block;font-size:13px;font-weight:900;line-height:1.2}
      #pwaInstallText span{display:block;margin-top:3px;font-size:10px;opacity:.85;line-height:1.4}
      #pwaInstallBtn{
        flex:none;
        background:white;
        color:#2E7D5B;
        border:0;
        border-radius:12px;
        padding:10px 14px;
        font-weight:900;
        font-size:12px;
        cursor:pointer;
        box-shadow:0 4px 12px rgba(0,0,0,.1);
        transition:transform .2s;
      }
      #pwaInstallBtn:active{transform:scale(.94)}
      #pwaInstallClose{
        flex:none;
        width:28px;height:28px;
        background:rgba(255,255,255,.15);
        border:0;
        border-radius:8px;
        color:white;
        cursor:pointer;
        display:grid;place-items:center;
        font-size:14px;
      }
      #pwaInstallClose:active{transform:scale(.9)}
      @media(max-width:360px){
        #pwaInstallContainer{bottom:78px;padding:12px}
        #pwaInstallText strong{font-size:12px}
        #pwaInstallText span{font-size:9px}
      }
    `;
    document.head.appendChild(style);

    const container = document.createElement('div');
    container.id = 'pwaInstallContainer';
    container.innerHTML = `
      <div id="pwaInstallIcon">📲</div>
      <div id="pwaInstallText">
        <strong>অ্যাপ ইনস্টল করুন</strong>
        <span>হোম স্ক্রিনে যোগ করুন, অফলাইনে ব্যবহার করুন</span>
      </div>
      <button id="pwaInstallBtn" type="button">Install</button>
      <button id="pwaInstallClose" type="button" aria-label="Close">✕</button>
    `;
    document.body.appendChild(container);

    installBtn = document.getElementById('pwaInstallBtn');
    const closeBtn = document.getElementById('pwaInstallClose');

    installBtn.addEventListener('click', async () => {
      if(!deferredPrompt) return;
      installBtn.textContent = '...';
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      console.log('[PWA] User choice:', outcome);
      deferredPrompt = null;
      hideInstallUI();
      if(outcome === 'accepted'){
        showToast('অ্যাপ ইনস্টল হচ্ছে... 🎉');
      }
    });

    closeBtn.addEventListener('click', () => {
      hideInstallUI();
      // Don't show again for 1 day
      localStorage.setItem('pwaInstallDismissed', Date.now().toString());
    });

    // Also show in header if exists
    const headerAction = document.querySelector('.header-action');
    if(headerAction){
      // Add small dot indicator
      headerAction.style.position = 'relative';
    }
  }

  function showInstallUI(){
    const dismissed = localStorage.getItem('pwaInstallDismissed');
    if(dismissed){
      const diff = Date.now() - parseInt(dismissed,10);
      if(diff < 24*60*60*1000) return; // 1 day
    }
    const container = document.getElementById('pwaInstallContainer');
    if(container){
      container.classList.add('show');
    }
  }

  function hideInstallUI(){
    const container = document.getElementById('pwaInstallContainer');
    if(container){
      container.classList.remove('show');
    }
  }

  function showToast(msg){
    let toast = document.getElementById('pwaToast');
    if(!toast){
      toast = document.createElement('div');
      toast.id = 'pwaToast';
      toast.style.cssText = 'position:fixed;left:50%;bottom:92px;transform:translate(-50%,20px);z-index:1000000;width:min(calc(100% - 30px),420px);padding:13px 16px;border-radius:14px;color:white;background:#25362E;box-shadow:0 12px 30px rgba(0,0,0,.18);font-size:12px;font-weight:700;opacity:0;pointer-events:none;transition:.25s ease;text-align:center;';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.style.opacity = '1';
    toast.style.transform = 'translate(-50%,0)';
    clearTimeout(toast._timer);
    toast._timer = setTimeout(()=>{
      toast.style.opacity = '0';
      toast.style.transform = 'translate(-50%,20px)';
    }, 3000);
  }

  // Service Worker Registration
  if('serviceWorker' in navigator){
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('/sw.js')
        .then(reg => {
          console.log('[PWA] SW registered', reg.scope);
        })
        .catch(err => {
          console.log('[PWA] SW failed', err);
        });
    });
  }

  // Install Prompt Handling
  window.addEventListener('beforeinstallprompt', (e) => {
    console.log('[PWA] beforeinstallprompt fired');
    e.preventDefault();
    deferredPrompt = e;
    createInstallUI();
    // Show after slight delay
    setTimeout(showInstallUI, 1500);
  });

  window.addEventListener('appinstalled', () => {
    console.log('[PWA] App installed');
    deferredPrompt = null;
    hideInstallUI();
    showToast('অ্যাপ সফলভাবে ইনস্টল হয়েছে! 🎉');
    localStorage.removeItem('pwaInstallDismissed');
  });

  // For iOS and browsers that don't support beforeinstallprompt, show manual instruction after 3s if not installed
  window.addEventListener('load', () => {
    createInstallUI();
    // Check if already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
    if(isStandalone){
      console.log('[PWA] Already in standalone mode');
      return;
    }
    // If after 4 seconds no prompt, show manual hint for iOS
    setTimeout(()=>{
      if(!deferredPrompt){
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        if(isIOS){
          const container = document.getElementById('pwaInstallContainer');
          if(container){
            container.querySelector('#pwaInstallText strong').textContent = 'হোম স্ক্রিনে যোগ করুন';
            container.querySelector('#pwaInstallText span').textContent = 'Safari এর Share → Add to Home Screen';
            container.querySelector('#pwaInstallBtn').style.display = 'none';
            container.classList.add('show');
          }
        }
      }
    }, 4000);
  });

  // Expose for manual trigger
  window.showPWAInstall = () => {
    if(deferredPrompt){
      showInstallUI();
    } else {
      showToast('ব্রাউজার মেনু থেকে "Add to Home Screen" / "Install App" সিলেক্ট করুন');
    }
  };
})();
