let installPrompt = null;
const installWrap = document.getElementById("installWrap");
const installButton = document.getElementById("installApp");

if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch(() => {});
  });
}
window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  installPrompt = event;
  if (installWrap) installWrap.hidden = false;
});
if (installButton) {
  installButton.addEventListener("click", async () => {
    if (!installPrompt) {
      alert("Chrome-এর মেনু (⋮) খুলে 'Add to Home screen' বা 'Install app' নির্বাচন করুন।");
      return;
    }
    installPrompt.prompt();
    await installPrompt.userChoice;
    installPrompt = null;
    if (installWrap) installWrap.hidden = true;
  });
}
window.addEventListener("appinstalled", () => {
  if (installWrap) installWrap.hidden = true;
});
