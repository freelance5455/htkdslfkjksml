# Sumrid Holidays Customer App

Customer-only HTML app. Admin app is NOT included.

## Firebase
The app is already coded to use Firebase Authentication (Anonymous) + Cloud Firestore. Your personal Firebase Web config is intentionally left as placeholders because it belongs to your Firebase project.

Open `firebase-config.js` and paste the `firebaseConfig` object from your Firebase Console.

Enable:
- Authentication → Anonymous
- Firestore Database

Apply `firestore.rules`.

Do NOT put your Google password, OTP, or Firebase service-account private key in this project.

## Customer features
- Welcome to Sumrid Holidays Adventure ®
- Daily Services first
- Exact Daily Service fares requested
- Popular routes
- Other taxi services
- First ride 15% offer
- Referral ₹150
- Round trip 15% offer
- 7 completed rides → 8th ride FREE offer display
- Group discounts
- Popular destinations
- Customer Care phone/email
- Booking form
- Google Maps route button
- Firebase anonymous sign-in
- Firestore online booking and customer booking-status listener

This package contains ONLY the Customer App. Admin will be built separately after this.
