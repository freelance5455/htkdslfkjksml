<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/workspace-entry.php';
anonymoux_workspace_entry('agent-studio.php', 'agent-studio.php', 'agents/');
