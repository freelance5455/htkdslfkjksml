<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/workspace-entry.php';
anonymoux_workspace_entry('agent-chat.php', 'agent-chat.php', 'agents/chat.php');
