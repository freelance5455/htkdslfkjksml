PhoneOSINT Lite — projet HTML prêt à convertir en APK
======================================================

Contenu:
- www/index.html : interface mobile HTML/CSS/JavaScript autonome.
- Ce ZIP n'est PAS un APK compilé. Il contient le code source prêt à intégrer dans un wrapper Android ou un outil HTML-to-APK.

Fonctions:
- Contrôle syntaxique basique d'un numéro (aucune identification de propriétaire).
- Générateur de recherches web OSINT publiques par pseudo, e-mail, téléphone, domaine et nom.
- Raccourcis de recherche publique.
- Aucun backend, aucune clé API, aucun stockage de recherche.

Conversion en APK:
1. Décompressez ce ZIP.
2. Importez www/index.html dans un convertisseur HTML vers APK fiable, ou copiez le dossier www dans le dossier assets/www d'un projet Android WebView/Capacitor.
3. Compilez et signez l'application dans votre outil de compilation Android.
4. Testez l'APK avant installation.

Important:
- Les recherches externes ont besoin d'Internet.
- Les informations affichées ne permettent pas d'identifier de façon fiable le propriétaire d'un numéro ni de le géolocaliser.
- Utilisez uniquement pour des recherches légales et autorisées.
