const $ = s => document.querySelector(s);
const PREMIUM_CODES = ['HISAAB-OWNER']; // change these codes
const PAY_LINK = ''; // paste your payment link here
const LIMIT = 30;
const CATS = ['Food', 'Transport', 'Bills', 'Shopping', 'Health', 'Salary', 'Other'];
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } };
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} };
let items = load('hisaab.items', []), pro = load('hisaab.pro', false);
const fmt = n => 'Rs ' + Math.round(n).toLocaleString('en-US');
const esc = s => String(s).replace(/[&<>"']/g, c => '&#' + c.charCodeAt(0) + ';');
const iso = d => new Date(d - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10);
const say = t => { $('#msg').textContent = t; };
const sum = (a, t) => a.filter(i => i.type === t).reduce((s, i) => s + i.amt, 0);

$('#cat').innerHTML = CATS.map(c => `<option>${c}</option>`).join('');
$('#date').value = iso(new Date());
$('#month').value = iso(new Date()).slice(0, 7);
$('#buy').href = PAY_LINK || '#act';
if (PAY_LINK) $('#buy').target = '_blank';

function render() {
  const now = iso(new Date()).slice(0, 7), m = $('#month').value || now;
  const cur = items.filter(i => i.date.startsWith(m)), mine = items.filter(i => i.date.startsWith(now));
  const inc = sum(cur, 'income'), out = sum(cur, 'expense');
  $('#sIn').textContent = fmt(inc); $('#sOut').textContent = fmt(out); $('#sNet').textContent = fmt(inc - out);
  $('#list').innerHTML = cur.sort((a, b) => b.date.localeCompare(a.date)).map(i =>
    `<li><span class="d">${i.date.slice(5)}</span><span class="n">${esc(i.cat)}${i.note ? ' – ' + esc(i.note) : ''}</span><b class="${i.type === 'income' ? 'in' : 'out'}">${i.type === 'income' ? '+' : '-'}${fmt(i.amt)}</b><button data-id="${esc(i.id)}" aria-label="Delete entry">×</button></li>`
  ).join('') || '<li class="muted">No entries for this month yet.</li>';
  const by = {};
  cur.filter(i => i.type === 'expense').forEach(i => by[i.cat] = (by[i.cat] || 0) + i.amt);
  $('#cats').innerHTML = Object.entries(by).sort((a, b) => b[1] - a[1]).map(([c, v]) =>
    `<li>${esc(c)} – ${fmt(v)}<i style="width:${v / out * 100}%"></i></li>`).join('') || '<li class="muted">Nothing spent yet.</li>';
  const mi = sum(mine, 'income'), mo = sum(mine, 'expense');
  $('#bal').textContent = fmt(mi - mo);
  $('#hd').textContent = mine.length ? `Spent ${fmt(mo)} of ${fmt(mi)} earned.` : 'Add your first entry below.';
  const days = [...Array(7)].map((_, k) => {
    const d = new Date(); d.setDate(d.getDate() - 6 + k); const s = iso(d);
    return items.filter(i => i.type === 'expense' && i.date === s).reduce((a, i) => a + i.amt, 0);
  });
  const mx = Math.max(...days, 1);
  document.querySelectorAll('.bars i').forEach((b, k) => { b.style.transitionDelay = k * 80 + 'ms'; b.style.height = Math.max(days[k] / mx * 100, 4) + '%'; });
  const st = pro ? 'Premium is active.' : `Free plan: ${mine.length} of ${LIMIT} entries used this month.`;
  $('#hp').textContent = st; $('#plan-status').textContent = pro ? 'Premium is active. Unlimited entries and all tools are unlocked.' : st;
  document.querySelectorAll('.pro-tool').forEach(b => b.classList.toggle('locked', !pro));
}

$('#f').addEventListener('submit', e => {
  e.preventDefault();
  const amt = parseFloat($('#amt').value), date = $('#date').value;
  if (!(amt > 0) || !date) return say('Enter an amount and a date.');
  const n = items.filter(i => i.date.slice(0, 7) === date.slice(0, 7)).length;
  if (!pro && n >= LIMIT) return say('Free plan allows 30 entries a month. Go Premium for unlimited entries.');
  items.push({ id: Date.now() + '-' + Math.random().toString(36).slice(2, 6), type: $('#type').value, amt, cat: $('#cat').value, note: $('#note').value.trim(), date });
  save('hisaab.items', items); $('#amt').value = ''; $('#note').value = ''; say('Entry added.'); render();
});
$('#list').addEventListener('click', e => {
  const b = e.target.closest('button'); if (!b) return;
  items = items.filter(i => i.id !== b.dataset.id); save('hisaab.items', items); render();
});
$('#month').addEventListener('change', render);

const dl = (name, text, type) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name; a.click(); URL.revokeObjectURL(a.href); };
const gate = fn => () => pro ? fn() : say('This is a Premium feature. See the Premium plan below.');
const q = v => { v = String(v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
$('#csv').onclick = gate(() => dl('hisaab-' + $('#month').value + '.csv',
  ['Date,Type,Category,Note,Amount', ...items.filter(i => i.date.startsWith($('#month').value)).map(i => [i.date, i.type, i.cat, q(i.note), i.amt].join(','))].join('\n'), 'text/csv'));
$('#bak').onclick = gate(() => dl('hisaab-backup.json', JSON.stringify(items), 'application/json'));
$('#rst').onclick = gate(() => $('#file').click());
$('#prt').onclick = gate(() => print());
$('#file').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  f.text().then(t => {
    const a = JSON.parse(t);
    if (!Array.isArray(a) || !a.every(i => i && i.date && i.amt > 0 && i.cat)) throw 0;
    items = a.map(i => ({ id: String(i.id || Date.now() + Math.random()), type: i.type === 'income' ? 'income' : 'expense', amt: +i.amt, cat: String(i.cat), note: String(i.note || ''), date: String(i.date) }));
    save('hisaab.items', items); say('Backup restored.'); render();
  }).catch(() => say('That file is not a valid Hisaab backup.'));
  e.target.value = '';
};

$('#act').addEventListener('submit', e => {
  e.preventDefault();
  if (PREMIUM_CODES.includes($('#code').value.trim())) { pro = true; save('hisaab.pro', true); $('#amsg').textContent = 'Premium activated.'; render(); }
  else $('#amsg').textContent = 'That code is not valid.';
});

const bill = document.querySelectorAll('.bill button');
bill.forEach(b => b.addEventListener('click', () => {
  bill.forEach(x => x.setAttribute('aria-pressed', x === b));
  const y = b.dataset.plan === 'year';
  $('#price').textContent = y ? 'Rs 2,999' : 'Rs 299';
  $('#per').textContent = y ? 'per year' : 'per month';
  $('#note').textContent = y ? 'About Rs 250 a month. Save 16%.' : 'Cancel any time.';
}));

requestAnimationFrame(() => requestAnimationFrame(render));
