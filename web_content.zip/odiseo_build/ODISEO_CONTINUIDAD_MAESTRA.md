# ODISEO — CONTINUIDAD MAESTRA

**Archivo de entrada único del proyecto**  
**Creado:** 4 de noviembre de 2026  
**Biblioteca:** raíz `/ODISEO_CONTINUIDAD_MAESTRA.md`  
**Propósito:** que la instrucción «Odiseo» recupere el estado, los experimentos, las pruebas, los resultados, los límites y los siguientes pasos sin empezar de cero.

---

## 0. Instrucción de continuidad: cuando el usuario diga «Odiseo»

Esta es la puerta de entrada. Al recibir «Odiseo», «continúa Odiseo», «avanza» o una referencia a una versión:

1. Buscar y leer este archivo maestro en la Biblioteca.
2. Leer la versión vigente de `ESTADO_ODISEO.json`; no fiarse de resúmenes antiguos de conversación.
3. Buscar y leer `DIARIO_ODISEO.json` y los registros de experimentos. Si no están localizables, declararlo y no inventar su contenido.
4. Abrir las auditorías y los resultados enlazados en la sección 4 que correspondan al último hito y a la tarea solicitada.
5. Si se necesita modificar código, recuperar el ZIP exacto de la versión base y comprobar su contenido antes de editarlo.
6. Continuar desde el último estado realmente verificado. No saltar versiones, no renombrar un paquete como si fuera una mejora y no declarar terminada una versión sin cambios y pruebas reales.
7. Al terminar cada avance real, actualizar este archivo, `ESTADO_ODISEO.json`, `DIARIO_ODISEO.json` (si está disponible) y el paquete versionado; conservar los anteriores.
8. Informar siempre: qué se cambió, qué se ejecutó, qué pasó, qué falló, qué queda pendiente y dónde está guardado.

**Regla de honestidad:** «guardado» significa que el archivo se escribió en la Biblioteca y se verificó su presencia. «Probado» significa que se ejecutó la prueba y se conserva su resultado. «Integrado» significa que existe una conexión ejecutada e instrumentada; compartir una página HTML o cargar un módulo no basta. «Validado» siempre debe llevar alcance y límites.

## 1. Estado de referencia al crear este archivo

### Estado estable
- **Versión estable global del software:** `53.2`.
- **Último hito de núcleo auditado:** Odiseo `53.2`, con semáforo fail-closed y cobertura de 25 motores dentro del alcance declarado.
- **Estado general de auditoría 53.2:** `GREEN_WITH_EXPLICIT_SCOPE_LIMITS`.
- **APK:** el generador se prepara correctamente, pero la APK no está compilada ni instalada. No afirmar prueba física Android.

### Rama experimental
- **Rama:** `53.3-alpha`, TIC `1.2-alpha`.
- **No es la versión estable global.** El propio estado de proyecto mantiene `software_version = 53.2` y describe 53.3-alpha como rama experimental.
- TIC 1.2-alpha añade PID Williams–Beer `I_min` para dos fuentes, transferencia de entropía condicionada a confusores observados, moving-block bootstrap e hipótesis nula por desplazamiento circular.
- **Pruebas registradas:** 13/13 aserciones específicas; 32/32 archivos `tests_*.js` con código de salida cero; sintaxis de 30/30 assets JavaScript; preparación APK superada con SHA-256 del módulo.
- **Límites:** pruebas sintéticas; `I_min` no es una PID universal; el nulo circular presupone estacionariedad aproximada; bootstrap y corrección son aproximados; no controla confusores ocultos ni retardos múltiples; no hay datos externos ni integración semántica instrumentada de TIC con los motores; APK no compilada ni instalada.

### Próximo objetivo documentado
Cerrar la auditoría de TIC 1.2-alpha con controles adversariales, comparación entre definiciones PID, retardos preregistrados y corrección por multiplicidad; instrumentar intercambios reales con Sherlock, Penélope, Judas Tadeo e Integrador E; mantener la prueba Android como tarea separada.

## 2. Principios que no se pueden romper

1. Sinceridad: no complacer a costa de la evidencia.
2. Separar hechos, hipótesis, cálculos, observaciones, pruebas y especulación.
3. Registrar resultados negativos, contraejemplos, errores y correcciones; no conservar solo los éxitos.
4. No declarar aprendizaje autónomo, conciencia, comprensión semántica o modificación del propio código sin evidencia específica.
5. No elevar coincidencias heurísticas a pruebas ni correlación/transferencia de entropía a causalidad.
6. No afirmar que una prueba se ejecutó si solo se diseñó o inspeccionó estáticamente.
7. Toda afirmación experimental debe conservar parámetros, semilla, datos, método, presupuesto, resultado, límites y huella cuando estén disponibles.
8. El usuario controla la aceptación de cambios y versiones; conservar originales y permitir reversión.
9. Los resultados finitos no demuestran propiedades universales ni resuelven por sí solos Collatz.
10. La preparación del generador APK no equivale a compilar, instalar o probar una APK.

## 3. Arquitectura resumida

- **Sherlock:** búsqueda de rastros, relaciones explícitas, referencias y candidatos; sus heurísticas no son pruebas.
- **Penélope:** contraste/desmontaje estructural de AST; conservar original y procedencia; no afirmar equivalencia semántica sin demostrarla.
- **OIE:** integrador de evidencias, procedencia, referencias y relaciones de apoyo/contradicción.
- **Judas Tadeo:** reencuadre deductivo, premisas tácitas y alternativas; sus propuestas no son demostraciones.
- **Integrador E:** verificación de tareas combinatorias acotadas, no descubrimiento general.
- **Controlador H:** presupuestos, conflictos y parada.
- **ODQ/ODA:** contrato estructurado de preguntas/respuestas; la validación estructural no demuestra verdad semántica.
- **TIC:** medidas de información, entropía, transferencia y PID en rama experimental; no atribuir causalidad sin diseño/intervención.
- **Núcleo Creador / Odiseo-Penélope / Duet:** creación simbólica y contraste estructural locales, con límites de runtime, gramática, presupuesto y evaluación semántica.
- **Espejo / Acelerador / Acertijos / Evolución / Interacción finita:** grafo de relaciones explícitas, colisiones enteras y expansión acotada; los patrones numéricos no implican significado.
- **Laboratorio de loterías:** simulación, Monte Carlo, corrección Holm y backtesting; no predice sorteos ni demuestra ventaja frente al azar.

## 4. Índice de archivos principales en la Biblioteca

Los archivos se encuentran principalmente en la raíz `/`. Existe también una carpeta `/Odiseo` con paquetes históricos. Los nombres son rutas de Biblioteca, no enlaces de descarga.

### Fuentes de verdad y continuidad
- `/ESTADO_ODISEO.json` — estado técnico, arquitectura, principios, verificaciones e historial. **Fuente prioritaria para versión y estado.**
- `/DIARIO_ODISEO.json` — diario operativo esperado por el protocolo ODISEO SAVE. **No se ha localizado como archivo independiente en la revisión que originó este índice; comprobar de nuevo antes de afirmar que existe.** Puede haber diarios dentro de paquetes o copias locales.
- `/ODISEO_CONTINUIDAD_MAESTRA.md` — este índice y protocolo de reanudación.
- `/Odiseo/Odiseo_2_1_Diario_del_proyecto.pdf` (si la Biblioteca conserva el nombre con espacios) — diario histórico de la etapa 2.1; no sustituye al diario JSON moderno.
- `/ODISEO_PROYECTO_TOTAL_12_0_1_ALPHA.pdf` — consolidación histórica de arquitectura, memoria y hoja de ruta 12.0.1-alpha; no confundir su numeración con la rama 49–53.

### Último bloque: 53.3-alpha / TIC 1.2
- `/AUDITORIA_TIC_1.2_ALPHA.md` — alcance, pruebas y límites de TIC 1.2-alpha.
- `/RESULTADOS_TIC_1.2_ALPHA.json` — resultados numéricos de controles sintéticos.
- `/ESTADO_ODISEO.json` — registra 53.3-alpha como experimental y 53.2 como versión estable global.
- Buscar el ZIP de 53.3-alpha y el código `tic_inferencia_odiseo.js`, `tests_odiseo_tic_inferencia.js` antes de modificar esta rama. No asumir que la auditoría aislada basta para reconstruir el paquete.

### 53.2 / comunicación y TIC 1.1
- `/ODISEO_53.2_TIC_1.1_EXPERIMENTAL_20261104.zip` — paquete experimental TIC 1.1.
- `/AUDITORIA_TIC_1.1.md` — 16 aserciones específicas; 31/31 suites de regresión; límites de validación sintética y falta de integración con orquestador.
- `/TIC_1.1_MODELO_EXPERIMENTAL.md` — definición matemática y operacional.
- `/RESULTADOS_TIC_1.1.json` — resultados de los cinco escenarios sintéticos.
- `/ODISEO_53.2_20261104T194805Z_auditoria_multiperspectiva_gpt6.zip`.
- `/AUDITORIA_MULTIPERSPECTIVA_GPT_53_2.md` y `/PATRON_RESULTADOS_AUDITORIA_53_2.json`.

### 53.1 y 53.0
- `/ODISEO_53.1_20261104T200500Z_lenguaje_comunicacion.zip`.
- `/LENGUAJE_COMUNICACION_53_1.md`, `/AUDITORIA_53_1.md`.
- `/ODISEO_53.0_20261104T193826Z_auditoria_comunicacion.zip`.
- `/AUDITORIA_53_0.md`, `/auditoria_integral_comunicacion_53_0.json`, `/tests_odiseo_auditoria_integral_53_0.js`.

### 52.x
- 52.9: `/ODISEO_52.9_20261104_evaluacion_adaptativa.zip`, `/AUDITORIA_52_9.md`, `/evaluacion_adaptativa_52_9.json` y SHA-256 asociado.
- 52.8: `/ODISEO_52.8_20261104T190414Z_patron_adaptativo_final.zip`, `/AUDITORIA_52_8.md`.
- 52.7: `/ODISEO_52.7_20261104T185731Z_biblioteca_activa_final.zip`, `/AUDITORIA_52_7.md`, `/AUDITORIA_COMPARATIVA_ODISEO_52_7_GPT_6.md`.
- 52.6: `/ODISEO_52.6_20261104T185536Z_nucleo_unificado_final.zip`, `/AUDITORIA_52_6.md`.
- 52.5: `/ODISEO_52.5_20261104T185217Z_ciclo_integrado_final.zip`, `/AUDITORIA_52_5.md`.
- 52.4: `/ODISEO_52.4_20261104_integrador_evidencias.zip`.
- 52.3: `/ODISEO_52.3_20261104_sherlock_falsos_positivos.zip`.
- 52.2: `/ODISEO_52.2_20261104_sherlock_evidence.zip`.
- 52.1: `/ODISEO_52.1_20261104_sherlock_adaptable.zip` y otros paquetes 52.1 de espacios/entropía e informe histórico; verificar cuál es la base antes de editar.
- 52.0: `/ODISEO_52.0_20261104_sherlock.zip` y `/ODISEO_52.0_CAMINOS_REVISIONABLES.zip`.

### 51.x y 50.x
- 51.9: `/ODISEO_51.9_20261104_loterias_pelayo.zip`.
- 51.8: `/ODISEO_51.8_20261104T144520Z_final_51_8_judas_loterias.zip` y SHA-256.
- 51.7: `/ODISEO_51.7_20261104_integrador_E.zip`.
- 51.6: `/ODISEO_51.6_20261104_prueba_independencia.zip`, `experimento_independencia_51_6.json`.
- 51.5: `/ODISEO_51.5_20261104T125203Z_pruebas_51_5.zip`.
- 51.4: `/ODISEO_51.4_20261104T124749Z_duelo_reciproco_51_4.zip`.
- 51.3: `/ODISEO_51.3_20261104T124052Z_odiseo_penelope_51_3_final.zip` — modelo de valores ya implementado y probado; no redefinirlo desde cero.
- 51.1: `/ODISEO_51.1_20261104T122030Z_ciclo_investigacion_51_1_final.zip`.
- 50.9: `/ODISEO_50.9_20261104T121035Z_sensibilidad_50_9.zip`.
- 50.8: `/ODISEO_50.8_20261104T120540Z_objetivo_evolutivo_50_8.zip`.
- 50.7: `/ODISEO_50.7_20261104T120229Z_objetivo_evolutivo_50_7.zip`.
- 50.6: `/ODISEO_50.6_20261104T120026Z_convergencia_50_6.zip`.
- 50.5: `/ODISEO_50.5_20261104T115257Z_interaccion_50_5.zip`.
- 50.4: `/ODISEO_50.4_20261104T113117Z_evolucion_50_4.zip`.
- 50.3: `/ODISEO_50.3_20261104T112827Z_acertijo_50_3_final.zip`.
- 50.2: `/Odiseo/ODISEO_ACELERADOR_MATEMATICO_50_2_ALPHA.zip`.
- 50.1: `/ODISEO_50.1_20261104T111857Z_espejo_50_1.zip`.
- 50.0: `/ODISEO_50.0_20261104T110839Z_abch_50_0_final.zip`.

### 49.x y material histórico
- 49.9: `/ODISEO_ANDROID_BUILDER_49_9_ALPHA.zip`.
- 49.8: `/ODISEO_ANDROID_SAVE_49_8_ALPHA.zip`, `/odiseo_49_8.py`, `README.md`.
- 49.7: `/ODISEO_49.7_20261104T105635Z_inicial.zip`, `/ODISEO_SAVE_49_7_ALPHA.zip`, `/COPIA_VERIFICADA_49_7_20261104.zip`.
- Material anterior y líneas de consolidación: `/ODISEO_ANDROID_1_0_PROYECTO.zip`, `/ODISEO_ANDROID_1_0_LEY_APRENDIZAJE.zip`, `/ODISEO_INDEPENDIENTE_1_0_ALPHA.zip`, `/ODISEO_INDEPENDIENTE_1_1_LEY_APRENDIZAJE.zip`, `/ODISEO_ANDROID_COMPILABLE.zip`, `/ODISEO_codigo_fuente_completo.txt` y duplicado histórico.

**Importante:** esta lista es un índice de los artefactos localizados durante la revisión, no una certificación de que cada ZIP haya sido reabierto y reejecutado hoy. Para una auditoría o modificación, materializar y verificar el paquete concreto.

## 5. Hitos y pruebas que conviene preservar

- **Syracuse acelerada:** se conserva la distinción entre identidad por definición y conjetura general. En el registro se documentó la auditoría de 50.000 impares; también se registró el contraejemplo `F(3)=5` a la hipótesis de descenso universal de un paso. No implica resolver Collatz.
- **51.6:** 17 comprobaciones nuevas; 244 regresiones en 15 baterías; 0 fallos; reto con semilla `20261104`, 25 entradas por motor e inyección de fallo detectada.
- **51.7:** 55 comprobaciones nuevas; 299 comprobaciones en 16 baterías; 0 fallos; integración de 10 soluciones combinatorias en el caso `n=20`, con límites de familia finita.
- **51.8:** 31 pruebas nuevas; 331 comprobaciones en 17 baterías; 0 fallos; laboratorio de loterías con Monte Carlo, Holm y walk-forward; sin ventaja predictiva demostrada.
- **52.4:** OIE con 10 aserciones específicas; FNV-1a 32-bit no es hash criptográfico; sin integración E2E completa.
- **52.5:** 17 aserciones del ciclo + 10 OIE; 21/21 baterías sin fallos; 386 comprobaciones registradas; APK no compilada/instalada.
- **52.6:** 22/22 smoke tests de módulos; los smoke tests no certifican cada función.
- **52.7:** Biblioteca Activa y propuestas revisables; no mutación automática de código; requiere revisión humana y rollback.
- **52.9:** corpus sintético de 28 casos: TP 19, FP 28, FN 0, TN 289; precisión micro 0,4043, recall 1,0 y F1 0,5758. Persistencia fallida reportada; umbrales no cambiados y enrutamiento automático desactivado. El alto número de falsos positivos debe seguir visible.
- **53.0:** auditor de comunicación; ciclo integrado 5 intercambios limpios; duelo 48 intercambios limpios; 23/23 módulos smoke test; 27 suites sin fallos; cobertura parcial instrumentada; huella FNV1a32 no criptográfica.
- **53.1:** 13/13 pruebas de lenguaje; 28/28 archivos de test; sin evaluación de verdad semántica.
- **53.2:** 25/25 motores con invocación/respuesta observada; 0 incidencias registradas; 15 aserciones del semáforo; 30/30 archivos de test sin fallos; ciclo 5 intercambios y duelo 48. La traza registra sobres y resúmenes, no todos los argumentos internos; no prueba verdad semántica ni adopción interna universal de ODQ/ODA.
- **TIC 1.1:** 16/16 aserciones; 31/31 archivos de test; cinco escenarios sintéticos. XOR: información conjunta cercana a 1 bit y MI individual cercana a cero; esto valida el control XOR, no una teoría general de emergencia.
- **TIC 1.2-alpha:** 13/13 pruebas específicas; regresión 32/32; sintaxis 30/30 assets; preparación APK correcta. Resultado de ejemplo inferencial: valor p 0,37 con 99 permutaciones; no significativo en ese ejemplo. El intervalo bootstrap y la corrección exploratoria tienen los límites descritos en la auditoría.

## 6. Registro de experimentos: plantilla obligatoria

Cada nuevo experimento debe añadirse al diario y resumirse aquí con un identificador único y enlace al resultado completo:

- ID y fecha/hora UTC:
- Versión base y hash del código:
- Pregunta operacional / hipótesis:
- Predicción que podría resultar falsa:
- Datos y procedencia (hash si procede):
- Método, parámetros, semilla y presupuesto:
- Baseline/control y holdout:
- Resultado observado:
- Pruebas y comandos ejecutados:
- Resultado de cada prueba (PASS/FAIL, conteos):
- Errores, anomalías y resultados negativos:
- Interpretación y límites:
- Estado: propuesto / implementado / ejecutado / validado en alcance / refutado / bloqueado:
- Archivos producidos y SHA-256:
- Próximo paso:

Nunca rellenar campos desconocidos con estimaciones presentadas como hechos.

## 7. Procedimiento de guardado por cada avance

1. Trabajar sobre una copia identificada del último ZIP base; conservarlo intacto.
2. Implementar el cambio y añadir pruebas específicas, controles negativos y regresión.
3. Ejecutar pruebas y guardar salida íntegra, configuración y semilla.
4. Revisar resultados adversarialmente; documentar falsos positivos y fallos.
5. Actualizar `ESTADO_ODISEO.json` y `DIARIO_ODISEO.json` sin borrar historia.
6. Generar ZIP fechado, manifiesto y SHA-256; verificar CRC y SHA-256 tras crearlo.
7. Preparar APK solo si procede; indicar claramente si se preparó, compiló, instaló y probó físicamente.
8. Subir los artefactos a la Biblioteca y comprobar que aparecen allí.
9. Actualizar este archivo maestro con enlaces/rutas y nuevo estado.
10. Informar al usuario con un resumen verificable y pendientes.

## 8. Qué no garantiza este archivo

- No sincroniza automáticamente todos los chats, dispositivos o archivos locales.
- No demuestra que todos los experimentos históricos estén ya volcados a un único diario. Hay paquetes y resultados distribuidos; deben consolidarse progresivamente.
- No ejecuta pruebas por sí mismo ni conserva código dentro de su texto; apunta a los artefactos fuente.
- No permite que el asistente trabaje en segundo plano entre conversaciones.
- No convierte las afirmaciones del proyecto en teoremas o verdades externas.

**Compromiso operativo:** cuando se diga «Odiseo», se empieza por este archivo y se contrasta con los originales. Si hay discrepancias, prevalecen los archivos y resultados verificables; la discrepancia se registra y se corrige, no se oculta.

## 9. Odiseo 53.4-alpha — Detector de inactividad Android (5-11-2026)

**Base real:** `ODISEO_53.3_ALPHA_TIC_1.2_20261104.zip`, inspeccionado y extraído antes de modificar.

**Alcance de privacidad:** solo registra marcas temporales de interacción dentro de Odiseo; no vigila ChatGPT ni otras apps, no captura texto ni usa un keylogger.

**Implementado en código fuente:**
- Umbral nativo de 30 minutos en `InactivityPolicy.java`.
- `InactivityStore.java`: persistencia del último evento, programación RTC_WAKEUP mediante `AlarmManager.setAndAllowWhileIdle`, marcador pendiente, JSONL y almacenamiento de informe SHA-256.
- `InactivityReceiver.java`: marca la inactividad cuando Android entrega la alarma.
- `InactivityBootReceiver.java`: recupera el temporizador después de reiniciar el dispositivo.
- `MainActivity.java`: puente de actividad WebView, comprobación al reabrir, comprobación periódica en primer plano y despacho de la auditoría.
- `index.html`: escucha interacciones; al reanudar valida cadena de hashes del diario, JSON local y presencia de APIs; muestra el informe y permite crear ZIP.
- `DIARIO_ODISEO.json` y `ESTADO_ODISEO.json` actualizados; se conserva `version_actual=53.2` como estable y `project_version=53.4-alpha` como rama experimental.

**Pruebas ejecutadas:** 8/8 comprobaciones de política Java; 32/32 suites `tests_*.js`; `node --check` para todos los assets; sintaxis de los dos bloques inline HTML; `py_compile`; JSON de estado/diario/manifiesto válido; `probar_generador.py` y `crear_apk_odiseo.py --solo-preparar` superados.

**Límites:** no se ha compilado APK porque este entorno no dispone de Gradle/Android SDK; no se ha instalado en teléfono. `setAndAllowWhileIdle` puede retrasarse por Doze y fabricantes. Si Android fuerza la detención, el alarm se cancela; el timestamp persistente permite detectar el intervalo al próximo inicio. La auditoría completa se ejecuta al volver a primer plano, no dentro del receptor en segundo plano.

**Próximo paso obligatorio:** compilar con JDK 17, Gradle 8.7 y Android SDK 35; instalar en dispositivo; comprobar 29:59/30:00, app en foreground, segundo plano, reinicio, ahorro de batería, exportación y restauración SAF. No declarar operativo en teléfono hasta pasar estas pruebas.

## Último incremento: 53.6-alpha — herramientas locales de independencia
- Archivo nuevo: `app/src/main/assets/herramientas_independencia_odiseo.js`.
- Registro `OdiseoCapabilityRegistry`: seis contratos allowlist para Sherlock, Penélope, Judas Tadeo, ESPEJO y Núcleo Unificado.
- Utilidades `OdiseoLocalTools`: normalización/tokenización, extracción numérica, similitud léxica, resumen extractivo, huella FNV no criptográfica y memoria local con procedencia obligatoria.
- Chat: comandos `Herramientas locales`, `Recuerda local:` y `Recupera local:`.
- Pruebas nuevas: `tests_herramientas_independencia.js` (13/13) y `tests_asistente_independencia_chat.js` (4/4). Regresión: 38/38 archivos `tests_*.js` ejecutados con código de salida cero; 32/32 assets JS y 2/2 bloques inline con sintaxis válida.
- Límites: router determinista, no LLM; comparación léxica no es comprensión semántica; memoria no verifica verdad; FNV no es criptográfico; registro solo valida forma/disponibilidad y no es sandbox. No se incorpora todavía un modelo neuronal local.
- Android: APK no compilada, no instalada ni probada físicamente.
- Siguiente fase: ampliar contratos, recuperación semántica local y benchmark LiteRT-LM frente a llama.cpp en el teléfono Android antes de elegir runtime/modelo.


## 53.7-alpha — Núcleo local de razonamiento simbólico (5-11-2026)

**Base:** paquete 53.6-alpha de independencia GPT, conservado como punto de partida.

**Implementado:** `app/src/main/assets/nucleo_razonamiento_local_odiseo.js`, API `OdiseoReasoningCore` sin red ni modelo remoto. Segmenta entradas, clasifica afirmaciones por reglas, extrae términos y números, calcula solapamientos léxicos, marca contradicciones candidatas y genera hipótesis exploratorias con posibles falsadores. Cargado desde `index.html` y conectado al chat mediante `razona local:`, `analiza local:` e `hipotesis local:`.

**Pruebas:** 10/10 específicas; 39/39 suites `tests_*.js` con código de salida cero.

**Límites:** no es un LLM ni comprensión semántica general; las relaciones léxicas no prueban significado, verdad ni causalidad. Las contradicciones requieren revisión de contexto. No se consulta GPT, API ni red. APK no compilada, instalada ni probada físicamente.

**Siguiente paso:** memoria semántica local con procedencia y estados epistemológicos (observación/hipótesis/inferencia/resultado), pruebas adversariales y benchmark de runtimes neuronales pequeños en Android antes de seleccionar un modelo.


## 53.8-alpha — Memoria semántica local tipada (5-11-2026)

**Base:** Odiseo 53.7-alpha; se conserva la rama estable global 53.2.

**Implementado:** `app/src/main/assets/memoria_semantica_local_odiseo.js`, API `OdiseoSemanticMemory`. Registros tipados (`observation`, `hypothesis`, `inference`, `result`, `source`, `note`), estados epistémicos (`unverified`, `supported`, `refuted`, `inconclusive`, `verified`), procedencia obligatoria, confianza opcional 0–1, contexto y etiquetas. Recuperación BM25 offline, revisión con contador de versión, borrado por ID, auditoría de candidatos de conflicto y exportación/importación JSON, con panel de copia de seguridad en la interfaz. Integrado en `index.html`, chat local y validación del generador APK.

**Comandos del chat:** `Memoria semántica local: tipo=observation; estado=unverified; fuente=usuario; texto=...`; `Busca memoria semántica local: ...`; `Estado memoria semántica`; `Exporta memoria semántica local`.

**Pruebas:** 14/14 memoria; 3/3 integración de chat; regresión 41/41 suites; sintaxis 34/34 assets JavaScript.

**Límites:** BM25 es búsqueda léxica, no embeddings ni comprensión semántica general; puede perder paráfrasis. `verified` y `supported` son etiquetas de registro, no verificación automática. Los conflictos son candidatos heurísticos. La persistencia depende de WebView `localStorage` y puede perderse si se borran los datos de la app. No hay sincronización entre dispositivos. Sin GPT ni red. APK no compilada, instalada ni probada físicamente.

**Siguiente paso:** ampliar controles adversariales de recuperación y paráfrasis; interfaz de exportación/importación revisable y pruebas de persistencia Android; después benchmark de runtimes neuronales pequeños en el dispositivo.


## 11. Rama experimental 54.0-alpha — modelo neuronal local (5-11-2026)

Se parte del ZIP 53.9-alpha recuperado de Biblioteca. Se conserva `software_version=53.2` como estable. Añadidos runtime Kotlin LiteRT-LM 0.18.0, importación SAF de `.litertlm`, hash SHA-256, puente WebView y ruta de fallback conversacional hacia inferencia local.

**Estado:** fuente añadida; compilación Android y validación del AAR pendientes. No se ha instalado ni probado en teléfono. No declarar 54.0 funcional hasta generar respuesta real sin red, comprobar fallback y medir recursos.


## 54.1-alpha — Cerebro cognitivo local integrado (5-11-2026)

**Base:** paquete 54.0-alpha basado en 53.9-alpha; estable global 53.2 intacta.

**Implementado:** `app/src/main/assets/cerebro_cognitivo_odiseo.js`, API `OdiseoCognitiveBrain`. Ciclo: clasificación heurística de objetivo → recuperación de memoria semántica BM25 con ID/tipo/estado/fuente → plan y selección de herramientas → ejecución acotada de `OdiseoReasoningCore.analyze` cuando está disponible (los demás motores solo quedan como candidatos) → construcción de prompt contextual para LiteRT-LM → auditoría heurística de salida → traza local persistida (máximo 120, borrado disponible). Integrado en `index.html` y en la ruta neuronal de `asistente_local_odiseo.js`. Comando: `Estado cerebro local`.

**Pruebas:** 12/12 específicas; 6/6 integración chat-cerebro con runtime simulado; 45/45 suites `tests_*.js`; 35/35 assets JavaScript con `node --check`.

**Límites:** la clasificación y selección son heurísticas; recuperación BM25 es léxica, no embeddings; solo el núcleo de razonamiento dispone de ejecución integrada; los otros motores quedan como candidatos; auditoría heurística no verifica verdad; las trazas no son aprendizaje de pesos. No hay conciencia ni autoentrenamiento. APK no compilada/instalada; compatibilidad del AAR LiteRT-LM y generación neuronal real pendientes de prueba Android. Se requiere importar un modelo `.litertlm` compatible.

**Siguiente paso obligatorio:** compilar con Gradle/JDK/Android SDK, resolver errores de API LiteRT-LM, importar modelo y probar completamente offline en el teléfono con medición de RAM/latencia/temperatura/batería y persistencia tras reinicio.


## Revisión de continuidad y auditoría — 6 de noviembre de 2026

**Rama experimental activa:** `55.1-alpha-cognitive-tool-dispatch`.  
**Versión estable global:** `53.2` (sin cambios).

### Hallazgos de la revisión 53.5.x
- Se reejecutaron las pruebas de 53.5.1 y 53.5.3.
- La comparación 53.5.1→53.5.3 encontró 4 archivos añadidos, 0 eliminados y 4 modificados.
- El ZIP fuente 53.5.2 no está disponible en Biblioteca ni en el entorno de trabajo; se conserva su informe dentro del paquete 53.5.3. No se afirma un diff de fuente que no se pudo hacer.
- El ZIP 53.5.3 tiene CRC correcto, pero su manifiesto está obsoleto: checkpoint 53.4, 148 entradas frente a 163 archivos, 15 archivos sin listar y 7 hashes/tamaños discrepantes. `ESTADO_ODISEO.json` sigue en 53.4; el diario sí llega a 53.5.3. Se conserva el artefacto histórico sin alterarlo.

### 54.1 — reejecución y corrección de metadatos
- Reproducido: 45/45 suites Node, 4/4 inventario CJS, 35/35 assets JS, 2/2 bloques inline, 34/34 JSON, XML de AndroidManifest y 191/191 hashes del manifiesto.
- `LocalModelRuntime.kt` compila sintácticamente con stubs de API; esto no es compilación contra el AAR real.
- Se alineó `app/build.gradle` a `versionCode 541` y `versionName 54.1-alpha-cognitive-brain`; se corrigió `version_actual`, se añadió la rama 54.1 al estado y se regeneraron manifiesto y sumas.
- No se modificó la lógica neuronal ni la versión estable.

### Alcance real del cerebro local
El cerebro cognitivo 54.1 es un orquestador heurístico local que clasifica objetivos, recupera memoria BM25 con procedencia, prepara un plan y construye el prompt. En ese ciclo solo se ejecuta el adaptador `OdiseoReasoningCore.analyze`; los demás motores son candidatos, no llamadas ejecutadas por el cerebro. La salida del modelo se audita heurísticamente, no se verifica como verdadera. No hay entrenamiento de pesos ni autonomía general.

### Comparativa de runtime Android
La recomendación provisional es mantener LiteRT-LM 0.18.0 como runtime principal de la APK porque 54.1 ya contiene el puente Kotlin/WebView y el selector `.litertlm`. `llama.cpp` se mantiene como contraste independiente en Termux, con GGUF. Primer modelo candidato: Gemma 4 E2B. No se elige backend GPU/NPU ni se promete rendimiento sin conocer el SoC y medir en el teléfono.

Documentos de esta revisión:
- `AUDITORIA_53_5_3_Y_54_1_20261106.md`
- `COMPARATIVA_LITERTLM_VS_LLAMACPP_ANDROID_20261106.md`

### Próximo trabajo obligatorio
1. Compilar 54.1 con Gradle, JDK y Android SDK y verificar el AAR LiteRT-LM real.
2. Identificar modelo exacto, SoC, GPU/NPU, Android/API, ABI, RAM y almacenamiento disponibles.
3. Importar Gemma 4 E2B `.litertlm` y ejecutar inferencia offline; medir carga, TTFT, tokens/s, memoria, temperatura y batería.
4. Probar `llama.cpp` + Gemma 4 E2B QAT Q4_0 GGUF en Termux con el mismo protocolo.
5. Corregir importación no atómica y verificación de hash del modelo antes de declararlo seguro.
6. Ejecutar E2E en Chromium y Android WebView. La prueba Chromium headless de esta revisión no llegó a completarse por limitaciones del contenedor.

**Dictamen:** 54.1 es fuente experimental con pruebas Node reproducibles; no es todavía una APK compilada ni un cerebro neuronal validado físicamente en el teléfono.

**Paquete de esta revisión:** 194/194 hashes de carga, 195/195 sumas y CRC ZIP verificados. El hash del ZIP se conserva en su sidecar `.sha256`.


## Revisión 54.2-alpha — endurecimiento del runtime neuronal (6-11-2026)

Se parte del ZIP auditado 54.1. Se implementa importación transaccional del modelo con rollback del anterior, verificación SHA-256/tamaño después de copiar y antes de cargar, exposición del estado de integridad y cierre del Engine candidato si falla la inicialización.

**Prueba reproducida:** `node --test tests_*.js`: 45/45 PASS.

**No probado:** build Gradle contra AAR LiteRT-LM real, APK, importación Gemma 4 E2B, inferencia en modo avión, métricas físicas. El contenedor no dispone de Gradle ni Android SDK.

**Checkpoint experimental:** 54.2-alpha-neural-runtime-hardening. **Estable:** 53.2 sin cambios.


## Reanudación 55.0-alpha — 12 de noviembre de 2026

- Base física recuperada: `ODISEO_54.2_ALPHA_ANDROID_SDK_PROJECT.zip` (577104 bytes; CRC ZIP íntegro).
- Versión estable preservada: 53.2. Base experimental anterior: 54.2. Rama actual: `55.0-alpha-functional-reconstruction`.
- Cambio verificado: detector adaptativo conservador en `app/src/main/assets/patron_adaptativo_odiseo.js`.
- Resultado del corpus sintético existente de 28 casos: TP=19, FP=0, FN=0, TN=317. Es un corpus pequeño usado para ajustar reglas; no estima generalización.
- Suites Node: 46/46 PASS; nuevas regresiones: 10/10 PASS; pruebas estáticas Android: 8/8 PASS; sintaxis JS: PASS.
- Pendiente: auditoría y ejecución real de adaptadores de motores, Gradle/Android SDK build, AAR LiteRT-LM real, APK instalada, modelo `.litertlm` e inferencia offline en dispositivo.
- No confundir motores presentes/cargados con motores invocados; solo declarar `EXECUTED` tras llamada real y resultado registrado.


## Reanudación 55.1-alpha — 12 de noviembre de 2026

- **Estable global:** 53.2, sin cambios. **Base experimental:** 55.0-alpha. **Rama activa:** `55.1-alpha-cognitive-tool-dispatch`.
- El cerebro cognitivo ahora despacha de forma asíncrona capacidades allowlisted mediante `OdiseoCapabilityRegistry.invoke`: Sherlock, Penélope, Judas Tadeo, ESPEJO (preguntas y auditoría) y núcleo unificado. `OdiseoReasoningCore.analyze` también ejecuta en el ciclo.
- Sherlock recibe solo registros reales recuperados de memoria con procedencia; Penélope exige AST JSON aportado; Judas recibe descripción de problema; ESPEJO usa el grafo local. Entradas insuficientes: `NEEDS_INPUT`. Las capacidades no conectadas se marcan `NOT_INTEGRATED`.
- Trazas ampliadas: capacidad, estado, duración, resumen y conteos de ejecución/necesidad de datos/error.
- Pruebas: 48/48 suites Node; 21/21 despacho; 8/8 integración con módulos reales en Node VM; 35/35 assets JS; 36/36 JSON; 8/8 metadatos Android; XML Android PASS.
- Pendiente: TIC, Laboratorio de loterías y OIE todavía no tienen adaptador cognitivo en este ciclo. No hay build Gradle/SDK, APK instalada, AAR LiteRT-LM real ni inferencia física offline.
- Artefactos: `AUDITORIA_55.1_ALPHA.md`, `VALIDACION_55.1_ALPHA.md`, `ESTADO_ODISEO.json`, `DIARIO_ODISEO.json`.
- **Dictamen:** rama fuente experimental con despacho real de cinco capacidades allowlisted en pruebas Node; no es APK validada ni LLM local probado.


## Reanudación 55.2-alpha — voz conversacional Android (18 de noviembre de 2026)

- **Estable global:** 53.2, preservada. **Base experimental:** 55.1-alpha. **Rama nueva:** `55.2-alpha-voice-chat`.
- Integrado en `MainActivity.java`: `SpeechRecognizer` en español (es-ES), permiso `RECORD_AUDIO`, preferencia `EXTRA_PREFER_OFFLINE`, y creación del reconocedor on-device cuando Android 13+ lo declara disponible; `TextToSpeech` con `Locale(es, ES)`.
- Integrado en `index.html`: botones de escucha y voz, callbacks de transcripción/estado y lectura automática de las respuestas del asistente. El asistente ya deriva al modelo LiteRT-LM si está cargado; sin modelo mantiene el enrutador determinista y sus límites documentados.
- Corregido `crear_apk_odiseo.py`: la versión del informe se lee de `ESTADO_ODISEO.json`; antes estaba fijada erróneamente en 53.9-alpha. Preparación verificada: `55.2-alpha-voice-chat`.
- Validación reproducida: 49/49 suites Node (55 subtests), 10/10 metadatos Android, XML de manifiesto PASS, sintaxis de los bloques inline HTML PASS y `--solo-preparar` PASS.
- **Pendiente crítico:** el entorno no tiene Gradle ni Android SDK; `assembleDebug` no se ejecutó, APK no generada ni instalada, AAR LiteRT-LM real y micrófono/TTS no probados físicamente. La preferencia offline de SpeechRecognizer no garantiza reconocimiento en modo avión; depende del servicio/paquete de idioma del teléfono.
- **Siguiente paso:** compilar con JDK 17, Gradle 8.13 y Android SDK 35 mediante AndroidIDE/Android Studio o GitHub Actions; instalar y probar permisos, reconocimiento, voz española e inferencia con un modelo `.litertlm` real.
