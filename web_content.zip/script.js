(() => {
'use strict';
const $ = id => document.getElementById(id);
const KEY = 'sakuku_transactions_v1';
let transactions = [];
let toastTimer;
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function load(){try{const raw=localStorage.getItem(KEY);if(!raw)return [];const data=JSON.parse(raw);return Array.isArray(data)?data.filter(x=>x&&typeof x==='object'):[]}catch(e){toast('Data tidak dapat dibaca. Data asli tidak dihapus.');return []}}
function save(){try{localStorage.setItem(KEY,JSON.stringify(transactions));return true}catch(e){toast('Penyimpanan gagal. Ekspor atau periksa ruang penyimpanan.');return false}}
function money(n){return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(Number(n)||0)}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function typeOf(t){return t.type==='income'||t.type==='expense'?t.type:(Number(t.amount)>=0?'income':'expense')}
function amountOf(t){return Math.abs(Number(t.amount)||0)}
function dateLabel(v){if(!v)return 'Tanggal tidak tersedia';const d=new Date(v+'T00:00:00');return isNaN(d)?v:new Intl.DateTimeFormat('id-ID',{day:'numeric',month:'short',year:'numeric'}).format(d)}
function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function render(){let inc=0,exp=0;transactions.forEach(t=>{if(typeOf(t)==='income')inc+=amountOf(t);else exp+=amountOf(t)});$('balance').textContent=money(inc-exp);$('income').textContent=money(inc);$('expense').textContent=money(exp);const f=$('filter').value;const list=transactions.filter(t=>f==='all'||typeOf(t)===f).slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))||Number(b.createdAt||0)-Number(a.createdAt||0));$('historyCount').textContent=`${list.length} transaksi`;if(!list.length){$('transactions').innerHTML='<div class="empty"><div class="empty-icon">↕</div><strong>Belum ada transaksi</strong><span>Transaksi tersimpan akan muncul di sini.</span></div>';return}$('transactions').innerHTML=list.map(t=>{const ty=typeOf(t),cat=esc(t.category||'Lainnya'),note=esc(t.note||t.description||'');return `<article class="transaction"><div class="tx-icon ${ty}">${ty==='income'?'↙':'↗'}</div><div class="tx-main"><strong>${cat}</strong><small>${dateLabel(t.date)}${note?' · '+note:''}</small></div><div class="tx-value ${ty}">${ty==='income'?'+':'−'}${money(amountOf(t)).replace('Rp','Rp ')}</div></article>`}).join('')}
$('date').value=today();transactions=load();render();
$('transactionForm').addEventListener('submit',e=>{e.preventDefault();const amount=Number($('amount').value);if(!Number.isSafeInteger(amount)||amount<=0){toast('Masukkan nominal rupiah yang valid.');return}const ty=document.querySelector('input[name="type"]:checked').value;const item={id:String(Date.now())+Math.random().toString(16).slice(2),type:ty,amount,category:$('category').value,date:$('date').value||today(),note:$('note').value.trim(),createdAt:Date.now()};transactions.push(item);if(!save()){transactions.pop();return}$('amount').value='';$('note').value='';$('date').value=today();render();toast('Transaksi berhasil disimpan.')});
$('filter').addEventListener('change',render);
$('exportBtn').addEventListener('click',()=>{const rows=[['Tanggal','Jenis','Kategori','Nominal','Catatan']];transactions.forEach(t=>rows.push([t.date||'',typeOf(t)==='income'?'Pemasukan':'Pengeluaran',t.category||'Lainnya',amountOf(t),t.note||t.description||'']));const csv='\uFEFF'+rows.map(row=>row.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='SakuKu-transaksi.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast('Ekspor CSV dimulai.')});
})();
