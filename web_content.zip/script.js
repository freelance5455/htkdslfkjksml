(() => {
  const defaults = { espBox: false, espLine: false, espBot: false, aimbot: false, aimLock: false, crosshairSize: 24, sensitivity: 50 };
  let settings = { ...defaults };
  let hits = 0, shots = 0, roundActive = false, toastTimer;
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const targets = $$('.dummy-target');
  const range = $('#range');
  const panel = $('#floatingPanel');

  function toast(message) {
    const node = $('#toast');
    node.textContent = message;
    node.classList.add('visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => node.classList.remove('visible'), 2100);
  }
  function syncControls() {
    $$('.switch').forEach(input => input.setAttribute('aria-checked', String(!!settings[input.dataset.key])));
    $$('.panel-toggle').forEach(input => { input.checked = !!settings[input.dataset.key]; });
    range.classList.toggle('esp-box', !!settings.espBox);
    range.classList.toggle('esp-line', !!settings.espLine);
    range.classList.toggle('esp-bot', !!settings.espBot);
    range.classList.toggle('headshot-sim', !!settings.headshot);
    $('#crosshairSize').value = settings.crosshairSize;
    $('#crosshairValue').textContent = `${settings.crosshairSize} px`;
    $('#crosshair').style.fontSize = `${settings.crosshairSize}px`;
    $('#sensitivity').value = settings.sensitivity;
    $('#sensitivityValue').textContent = `${settings.sensitivity}%`;
    updateAimFocus();
  }
  function updateAimFocus() {
    targets.forEach(target => target.classList.remove('aim-focus'));
    const crosshair = $('#crosshair');
    const active = targets.filter(target => target.classList.contains('active'));
    const area = range.getBoundingClientRect();
    const centerX = area.left + area.width / 2;
    const centerY = area.top + area.height / 2;
    crosshair.style.left = '50%';
    crosshair.style.top = '50%';
    if (!active.length || (!settings.aimbot && !settings.aimLock)) return;

    const nearest = active.reduce((best, target) => {
      const rect = target.getBoundingClientRect();
      const x = rect.left + rect.width / 2;
      const y = rect.top + rect.height / 2;
      const distance = Math.hypot(x - centerX, y - centerY);
      return !best || distance < best.distance ? { target, rect, x, y, distance } : best;
    }, null);
    if (!nearest) return;

    if (settings.aimLock) nearest.target.classList.add('aim-focus');
    if (settings.aimbot) {
      const strength = Number(settings.sensitivity) / 100;
      crosshair.style.left = `${area.width / 2 + (nearest.x - centerX) * strength}px`;
      crosshair.style.top = `${area.height / 2 + (nearest.y - centerY) * strength}px`;
    }
  }
  function setSetting(key, value, notify = false) {
    settings[key] = value;
    syncControls();
    if (notify) toast(`${key.replace(/([A-Z])/g, ' $1')} ${value ? 'enabled' : 'disabled'} for simulator.`);
  }
  function syncScore() {
    const percent = shots ? Math.round(hits / shots * 100) : 0;
    $('#hits').textContent = hits;
    $('#shots').textContent = shots;
    $('#accuracy').textContent = `${percent}%`;
  }
  function scatterTargets() {
    targets.forEach((target, index) => {
      target.style.left = `${7 + Math.random() * (82 - index * 2)}%`;
      target.style.top = `${15 + Math.random() * 45}%`;
    });
    updateAimFocus();
  }
  function startRound() {
    roundActive = true;
    $('#rangeCaption').hidden = true;
    targets.forEach(target => target.classList.add('active'));
    hits = 0; shots = 0; syncScore(); scatterTargets();
    $('#roundStatus').textContent = 'Practice round active — standalone simulation only.';
    toast('Simulator round started. Tap a target to score.');
  }
  function hitTarget(target) {
    if (!roundActive) startRound();
    shots++;
    hits++;
    syncScore();
    scatterTargets();
    $('#roundStatus').textContent = 'Simulated target hit — score updated.';
  }
  $$('.dummy-target').forEach(target => target.addEventListener('click', () => hitTarget(target)));
  range.addEventListener('click', event => {
    if (!roundActive || event.target.closest('.dummy-target')) return;
    shots++; syncScore();
    $('#roundStatus').textContent = 'Miss — keep practicing.';
  });
  $('#startRound').addEventListener('click', startRound);
  $('#resetScore').addEventListener('click', () => {
    hits = 0; shots = 0; syncScore();
    $('#roundStatus').textContent = 'Score reset. Trainer remains in standalone mode.';
    toast('Practice score reset.');
  });
  $$('.switch').forEach(button => button.addEventListener('click', () => setSetting(button.dataset.key, !settings[button.dataset.key], true)));
  $$('.panel-toggle').forEach(input => input.addEventListener('change', () => setSetting(input.dataset.key, input.checked, true)));
  $('#crosshairSize').addEventListener('input', event => { settings.crosshairSize = Number(event.target.value); syncControls(); });
  $('#sensitivity').addEventListener('input', event => { settings.sensitivity = Number(event.target.value); syncControls(); });

  function saveSettings() {
    try {
      localStorage.setItem('krishnaModVisualSettings', JSON.stringify(settings));
      $('#saveStatus').textContent = 'Saved on this device.';
      toast('Settings saved on this device.');
    } catch {
      $('#saveStatus').textContent = 'This browser could not save settings.';
      toast('Settings could not be saved by this browser.');
    }
  }
  function loadSettings() {
    try {
      const saved = localStorage.getItem('krishnaModVisualSettings');
      if (!saved) { toast('No saved settings found on this device.'); return; }
      const parsed = JSON.parse(saved);
      settings = { ...defaults, ...parsed };
      settings.crosshairSize = Math.max(12, Math.min(48, Number(settings.crosshairSize) || defaults.crosshairSize));
      settings.sensitivity = Math.max(1, Math.min(100, Number(settings.sensitivity) || defaults.sensitivity));
      syncControls();
      $('#saveStatus').textContent = 'Saved settings loaded.';
      toast('Saved simulator settings loaded.');
    } catch { toast('Saved settings could not be loaded.'); }
  }
  function resetSettings() {
    settings = { ...defaults };
    syncControls();
    $('#saveStatus').textContent = 'Settings reset. Save to keep these defaults.';
    toast('Simulator settings reset.');
  }
  $('#saveSettings').addEventListener('click', saveSettings);
  $('#panelSave').addEventListener('click', saveSettings);
  $('#loadSettings').addEventListener('click', loadSettings);
  $('#resetSettings').addEventListener('click', resetSettings);
  $('#panelReset').addEventListener('click', resetSettings);

  $('#launcher').addEventListener('click', () => {
    panel.classList.remove('hidden', 'minimized');
    $('#launcher').hidden = true;
  });
  $('#closePanel').addEventListener('click', () => {
    panel.classList.add('hidden');
    $('#launcher').hidden = false;
  });
  $('#minimizePanel').addEventListener('click', () => panel.classList.toggle('minimized'));
  $('#expandPanel').addEventListener('click', () => panel.classList.remove('minimized'));
  $$('.panel-nav').forEach(link => link.addEventListener('click', () => {
    panel.classList.add('minimized');
  }));

  // Keep the panel draggable within the webpage viewport; this is not a system overlay.
  const dragHandle = $('#dragHandle');
  let dragState = null;
  dragHandle.addEventListener('pointerdown', event => {
    if (event.target.closest('button')) return;
    const rect = panel.getBoundingClientRect();
    dragState = { x: event.clientX, y: event.clientY, left: rect.left, top: rect.top };
    panel.style.left = `${rect.left}px`;
    panel.style.top = `${rect.top}px`;
    panel.style.right = 'auto';
    panel.style.bottom = 'auto';
    dragHandle.setPointerCapture(event.pointerId);
  });
  dragHandle.addEventListener('pointermove', event => {
    if (!dragState) return;
    const width = panel.offsetWidth, height = panel.offsetHeight;
    const left = Math.min(window.innerWidth - width - 8, Math.max(8, dragState.left + event.clientX - dragState.x));
    const top = Math.min(window.innerHeight - Math.min(height, 100) - 8, Math.max(8, dragState.top + event.clientY - dragState.y));
    panel.style.left = `${left}px`;
    panel.style.top = `${top}px`;
  });
  const stopDrag = () => { dragState = null; };
  dragHandle.addEventListener('pointerup', stopDrag);
  dragHandle.addEventListener('pointercancel', stopDrag);
  window.addEventListener('resize', updateAimFocus);
  window.addEventListener('scroll', updateAimFocus, { passive: true });

  try {
    const stored = localStorage.getItem('krishnaModVisualSettings');
    if (stored) settings = { ...defaults, ...JSON.parse(stored) };
  } catch { /* Keep safe defaults when storage is unavailable. */ }
  syncControls();
  syncScore();
})();
