const tabsContainer = document.getElementById("tabs");
const newTabBtn = document.getElementById("newTabBtn");
let tabs = [];
let activeTabId = null;
let nextTabId = 1;

function createTab() {
  const tab = { id: nextTabId++, title: "New Tab", url: "", history: [], historyIndex: -1 };
  tabs.push(tab);
  activeTabId = tab.id;
  renderTabs();
  showWelcome();
}

function renderTabs() {
  tabsContainer.innerHTML = "";
  tabs.forEach(function(tab) {
    const tabElement = document.createElement("div");
    tabElement.className = "tab";
    if (tab.id === activeTabId) tabElement.classList.add("active");

    const title = document.createElement("span");
    title.className = "tab-title";
    title.textContent = tab.title;

    const closeButton = document.createElement("button");
    closeButton.className = "close-tab";
    closeButton.textContent = "✕";

    tabElement.appendChild(title);
    tabElement.appendChild(closeButton);

    tabElement.addEventListener("click", function() {
      activeTabId = tab.id;
      renderTabs();
      updateUrlBar();
      if (tab.url) displayWebsite(tab.url);
      else showWelcome();
    });

    closeButton.addEventListener("click", function(event) {
      event.stopPropagation();
      const index = tabs.findIndex(function(item) { return item.id === tab.id; });
      tabs = tabs.filter(function(item) { return item.id !== tab.id; });

      if (tabs.length === 0) {
        createTab();
        return;
      }

      if (activeTabId === tab.id) {
        const newIndex = Math.max(0, index - 1);
        activeTabId = tabs[newIndex].id;
      }
      renderTabs();
      updateUrlBar();
      const activeTab = tabs.find(function(item) { return item.id === activeTabId; });
      if (activeTab && activeTab.url) displayWebsite(activeTab.url);
      else showWelcome();
    });

    tabsContainer.appendChild(tabElement);
  });
}

newTabBtn.addEventListener("click", createTab);

const urlInput = document.getElementById("urlInput");
const goBtn = document.getElementById("goBtn");

function searchCurrentTab() {
  const value = urlInput.value.trim();
  if (!value) return;

  const activeTab = tabs.find(function(tab) { return tab.id === activeTabId; });
  if (!activeTab) return;

  let url = value;
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    if (url.includes(".") && !url.includes(" ")) {
      url = "https://" + url;
    } else {
      url = "https://www.google.com/search?q=" + encodeURIComponent(url);
    }
  }

  activeTab.title = value;
  activeTab.url = url;
  activeTab.history = activeTab.history.slice(0, activeTab.historyIndex + 1);
  activeTab.history.push(url);
  activeTab.historyIndex = activeTab.history.length - 1;

  renderTabs();
  displayWebsite(url);
}

goBtn.addEventListener("click", searchCurrentTab);
urlInput.addEventListener("keydown", function(event) {
  if (event.key === "Enter") searchCurrentTab();
});

const browserArea = document.getElementById("browserArea");

function showWelcome() {
  browserArea.innerHTML = '<div class="welcome"><div class="welcome-icon">🌐</div><h1>Welcome to JOJO</h1><p>Search for a website or enter a URL above.</p></div>';
}

function displayWebsite(url) {
  browserArea.innerHTML = "";
  const frame = document.createElement("iframe");
  frame.src = url;
  frame.style.width = "100%";
  frame.style.height = "calc(100vh - 160px)";
  frame.style.border = "none";
  browserArea.appendChild(frame);
  updateUrlBar();
}

function updateUrlBar() {
  const activeTab = tabs.find(function(tab) { return tab.id === activeTabId; });
  if (activeTab) urlInput.value = activeTab.url || "";
}

const backBtn = document.getElementById("backBtn");
const forwardBtn = document.getElementById("forwardBtn");
const reloadBtn = document.getElementById("reloadBtn");

backBtn.addEventListener("click", function() {
  const activeTab = tabs.find(function(tab) { return tab.id === activeTabId; });
  if (!activeTab) return;
  if (activeTab.historyIndex > 0) {
    activeTab.historyIndex--;
    activeTab.url = activeTab.history[activeTab.historyIndex];
    displayWebsite(activeTab.url);
  }
});

forwardBtn.addEventListener("click", function() {
  const activeTab = tabs.find(function(tab) { return tab.id === activeTabId; });
  if (!activeTab) return;
  if (activeTab.historyIndex < activeTab.history.length - 1) {
    activeTab.historyIndex++;
    activeTab.url = activeTab.history[activeTab.historyIndex];
    displayWebsite(activeTab.url);
  }
});

reloadBtn.addEventListener("click", function() {
  const activeTab = tabs.find(function(tab) { return tab.id === activeTabId; });
  if (activeTab && activeTab.url) displayWebsite(activeTab.url);
});

const bookmarkBtn = document.getElementById("bookmarkBtn");
const profileBookmarksBtn = document.getElementById("profileBookmarksBtn");
let bookmarks = JSON.parse(localStorage.getItem("jojoBookmarks") || "[]");

bookmarkBtn.addEventListener("click", function() {
  const activeTab = tabs.find(function(tab) { return tab.id === activeTabId; });
  if (!activeTab || !activeTab.url) {
    alert("Open a website first.");
    return;
  }
  if (!bookmarks.includes(activeTab.url)) {
    bookmarks.push(activeTab.url);
    localStorage.setItem("jojoBookmarks", JSON.stringify(bookmarks));
    alert("🔖 Bookmark saved!");
  } else {
    alert("This is already bookmarked.");
  }
});

profileBookmarksBtn.addEventListener("click", function() {
  if (bookmarks.length === 0) {
    alert("You don't have any bookmarks yet.");
    return;
  }
  alert("🔖 Your Bookmarks:\n\n" + bookmarks.join("\n"));
});

const profileBtn = document.getElementById("profileBtn");
const profileMenu = document.getElementById("profileMenu");
const loginBtn = document.getElementById("loginBtn");
const loginScreen = document.getElementById("loginScreen");
const closeLogin = document.getElementById("closeLogin");
const saveProfile = document.getElementById("saveProfile");
const loginName = document.getElementById("loginName");
const loginEmail = document.getElementById("loginEmail");
const profileName = document.getElementById("profileName");
const profileEmail = document.getElementById("profileEmail");

profileBtn.addEventListener("click", function(event) {
  event.stopPropagation();
  profileMenu.classList.toggle("open");
});

loginBtn.addEventListener("click", function() {
  profileMenu.classList.remove("open");
  loginScreen.classList.add("open");
});

closeLogin.addEventListener("click", function() {
  loginScreen.classList.remove("open");
});

saveProfile.addEventListener("click", function() {
  const name = loginName.value.trim();
  const email = loginEmail.value.trim();
  if (!name || !email) {
    alert("Please enter your username and email.");
    return;
  }
  profileName.textContent = name;
  profileEmail.textContent = email;
  localStorage.setItem("jojoProfile", JSON.stringify({ name: name, email: email }));
  loginScreen.classList.remove("open");
});

const savedProfile = localStorage.getItem("jojoProfile");
if (savedProfile) {
  const profile = JSON.parse(savedProfile);
  profileName.textContent = profile.name;
  profileEmail.textContent = profile.email;
}

const themeBtn = document.getElementById("themeBtn");
themeBtn.addEventListener("click", function() {
  document.body.classList.toggle("dark");
  const isDark = document.body.classList.contains("dark");
  themeBtn.textContent = isDark ? "☀️" : "🌙";
  localStorage.setItem("jojoDarkMode", isDark ? "true" : "false");
});

if (localStorage.getItem("jojoDarkMode") === "true") {
  document.body.classList.add("dark");
  themeBtn.textContent = "☀️";
}

const themesBtn = document.getElementById("themesBtn");
const themePanel = document.getElementById("themePanel");

themesBtn.addEventListener("click", function() {
  profileMenu.classList.remove("open");
  themePanel.classList.toggle("open");
});

document.querySelectorAll(".theme-main").forEach(function(button) {
  button.addEventListener("click", function() {
    const group = this.getAttribute("data-group");
    const shades = document.getElementById(group + "-shades");
    if (shades) shades.classList.toggle("open");
  });
});

const themeColors = {
  "yuji-soft":["#F6DDE0","#FBEDEF","#E9BFC4"],"yuji":["#DD969A","#F0D4D7","#E7C1C5"],"yuji-hot":["#FF5C8A","#FFD1DE","#FFB0C6"],"yuji-deep":["#A63D50","#E5A0AB","#C86A7A"],
  "jjk-lavender":["#B9A7E8","#E7DFFC","#D0C3F2"],"jjk":["#7656B8","#DDD2F4","#B9A7E8"],"jjk-violet":["#6C35C7","#DCC7F5","#9A70DD"],"jjk-deep":["#45206B","#B99AD8","#704293"],
  "onepiece-light":["#F5B66D","#FFE2BE","#F6C990"],"onepiece":["#E88924","#FFE0B0","#F4B15F"],"onepiece-bright":["#FF8C00","#FFE0A8","#FFB52E"],"onepiece-deep":["#A95013","#E8B37C","#C76D29"],
  "hxh-light":["#8BCF9A","#DDF4E2","#A9D9B1"],"hxh":["#4B9B58","#D7EEDB","#8CC995"],"hxh-forest":["#24613A","#B8D8C1","#4C8A5A"],"hxh-deep":["#173D26","#91B59C","#356B45"],
  "jojo-light":["#E98A8A","#F8D4D4","#F0B0B0"],"jojo":["#C83B3B","#F1C5C5","#DD7777"],"jojo-crimson":["#941F2D","#E9B2B9","#B94C59"],"jojo-deep":["#57151F","#C58B91","#7E3039"],
  "berserk-charcoal":["#555555","#D0D0D0","#888888"],"berserk":["#222222","#444444","#333333"],"berserk-gray":["#555B66","#D5D7DB","#858A93"],"berserk-red":["#641F28","#3A2528","#922F3C"],
  "bluelock-sky":["#69C7E8","#DDF6FC","#91DCEF"],"bluelock":["#287BC0","#D2E9F8","#5BA4D7"],"bluelock-electric":["#006DFF","#CBE1FF","#3B91FF"],"bluelock-deep":["#143E78","#B8CBE4","#2C5D96"],
  "pokemon-soft":["#F1D66A","#FFF6C7","#F7E89A"],"pokemon":["#E7C629","#FFF0A8","#F2D94E"],"pokemon-bright":["#FFD400","#FFF0A0","#FFE14A"],"pokemon-gold":["#C99700","#F1D77A","#DDB536"]
};

document.querySelectorAll(".shade-option").forEach(function(button) {
  button.addEventListener("click", function() {
    const theme = this.getAttribute("data-theme");
    const colors = themeColors[theme];
    if (!colors) return;
    document.documentElement.style.setProperty("--primary", colors[0]);
    document.documentElement.style.setProperty("--theme-light", colors[1]);
    document.documentElement.style.setProperty("--theme-tab", colors[2]);
    localStorage.setItem("jojoTheme", theme);
  });
});

const savedTheme = localStorage.getItem("jojoTheme");
if (savedTheme && themeColors[savedTheme]) {
  const colors = themeColors[savedTheme];
  document.documentElement.style.setProperty("--primary", colors[0]);
  document.documentElement.style.setProperty("--theme-light", colors[1]);
  document.documentElement.style.setProperty("--theme-tab", colors[2]);
}

document.getElementById("historyBtn").addEventListener("click", function() {
  alert("🕘 History will be added next.");
});
document.getElementById("savedTabsBtn").addEventListener("click", function() {
  alert("📑 Saved Tabs will be added next.");
});
document.getElementById("settingsBtn").addEventListener("click", function() {
  alert("⚙️ Settings will be added next.");
});

createTab();
