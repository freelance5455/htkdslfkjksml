/* Пули ман — ҳисобкунии даромад, хароҷот ва статистика */
(() => {
  "use strict";
  const STORAGE_KEY = "pulMan_transactions_v1";
  const THEME_KEY = "pulMan_theme_v1";
  const money = n => `${Number(n || 0).toLocaleString("tg-TJ",{minimumFractionDigits:2,maximumFractionDigits:2})} <small>с.</small>`;
  const plainMoney = n => `${Number(n || 0).toLocaleString("tg-TJ",{minimumFractionDigits:2,maximumFractionDigits:2})} с.`;
  const dateLabel = value => {
    const d = new Date(value);
    return d.toLocaleString("tg-TJ",{day:"2-digit",month:"short",year:"numeric",hour:"2-digit",minute:"2-digit"});
  };
  const dayKey = value => {
    const d = new Date(value);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  };
  const getTransactions = () => {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(data) ? data : [];
    } catch { return []; }
  };
  const saveTransactions = data => localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  const total = (items, type) => items.filter(x => !type || x.type === type).reduce((sum,x) => sum + Number(x.amount || 0), 0);
  const escapeHTML = value => String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
  const normalized = text => String(text || "").trim().toLocaleLowerCase("tg");
  function categoryFor(note) {
    const s = normalized(note);
    if (/chat\s?gpt|чат\s?гпт|openai|subscription|обуна/.test(s)) return "ChatGPT ва обуна";
    if (/food|хӯрок|хурок|нон|об|кафе|ресторан|ош|маҳсулот|махсулот/.test(s)) return "Хӯрок";
    if (/taxi|такси|автобус|маршрут|роҳкиро|роҳ|транспорт|бензин/.test(s)) return "Нақлиёт";
    if (/internet|интернет|телефон|мегафон|тселл|вагон|алоқа|алока/.test(s)) return "Алоқа";
    if (/учеб|китоб|дафтар|қалам|ручка|дониш|курс|обучение|универ/.test(s)) return "Таҳсил";
    if (/либос|пойафзол|одежда|куртка|футболка/.test(s)) return "Либос";
    if (/игра|бозӣ|game|steam|pubg|free fire/.test(s)) return "Бозӣ ва фароғат";
    if (/врач|дору|дорув|бемор|табобат|аптека/.test(s)) return "Саломатӣ";
    if (/хона|ижора|коммунал|барқ|цах|свет/.test(s)) return "Хона";
    return String(note || "").trim();
  }
  function categoryTotals(items) {
    const map = new Map();
    items.filter(x=>x.type==="expense").forEach(x=>{
      const key = categoryFor(x.note);
      const prev = map.get(key) || {name:key,total:0,count:0};
      prev.total += Number(x.amount); prev.count += 1; map.set(key,prev);
    });
    return [...map.values()].sort((a,b)=>b.total-a.total);
  }
  const colors = ["#5878f5","#f06a78","#24b47e","#a17be5","#f0ad4e","#32b8c5","#8090a8","#e47cbd","#7a9b57"];
  let charts = {};
  function isDark(){ return document.body.classList.contains("dark"); }
  function chartDefaults(){
    return {responsive:true,maintainAspectRatio:false,plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.dataset.label||ctx.label}: ${plainMoney(ctx.parsed.y ?? ctx.parsed)}`}}},scales:{x:{grid:{display:false},ticks:{color:isDark()?"#98a4bc":"#8b94a7",font:{family:"Inter",size:10}},border:{display:false}},y:{beginAtZero:true,grid:{color:isDark()?"#29334a":"#edf0f5"},ticks:{color:isDark()?"#98a4bc":"#8b94a7",font:{family:"Inter",size:10},callback:v=>v.toLocaleString("tg-TJ")},border:{display:false}}}};
  }
  function destroyChart(id){ if(charts[id]){charts[id].destroy();delete charts[id];} }
  function makeLine(id, labels, incomes, expenses) {
    const canvas=document.getElementById(id); if(!canvas||!window.Chart)return;
    destroyChart(id);
    charts[id]=new Chart(canvas,{type:"line",data:{labels,datasets:[{label:"Даромад",data:incomes,borderColor:"#24b47e",backgroundColor:"#24b47e18",fill:true,tension:.35,pointRadius:3,pointHoverRadius:5,borderWidth:2},{label:"Хароҷот",data:expenses,borderColor:"#f06a78",backgroundColor:"#f06a7815",fill:true,tension:.35,pointRadius:3,pointHoverRadius:5,borderWidth:2}]},options:{...chartDefaults(),interaction:{mode:"index",intersect:false}}});
  }
  function makeDoughnut(id, cats) {
    const canvas=document.getElementById(id); if(!canvas||!window.Chart)return;
    destroyChart(id);
    charts[id]=new Chart(canvas,{type:"doughnut",data:{labels:cats.map(x=>x.name),datasets:[{data:cats.map(x=>x.total),backgroundColor:cats.map((_,i)=>colors[i%colors.length]),borderWidth:0,hoverOffset:5}]},options:{responsive:true,maintainAspectRatio:false,cutout:"72%",plugins:{legend:{display:false},tooltip:{callbacks:{label:ctx=>`${ctx.label}: ${plainMoney(ctx.parsed)}`}}}}});
  }
  function setTheme(theme){
    document.body.classList.toggle("dark",theme==="dark");
    localStorage.setItem(THEME_KEY,theme);
    const btn=document.getElementById("themeToggle");
    if(btn)btn.innerHTML=(theme==="dark"?"☀":"☾")+" <span>"+(theme==="dark"?"Режими рӯзона":"Режими шабона")+"</span>";
    Object.keys(charts).forEach(id=>{
      const c=charts[id]; if(!c)return;
      if(c.options.scales){const opts=chartDefaults();c.options.scales=opts.scales;}
      c.update();
    });
  }
  function showToast(message){
    const el=document.getElementById("toast"); if(!el)return;
    el.textContent=message;el.classList.add("show");
    clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>el.classList.remove("show"),2800);
  }
  function updateSharedStats(){
    const tx=getTransactions(), incomes=total(tx,"income"), expenses=total(tx,"expense"), balance=incomes-expenses;
    const now=new Date(), month=tx.filter(x=>x.type==="expense"&&new Date(x.date).getMonth()===now.getMonth()&&new Date(x.date).getFullYear()===now.getFullYear());
    const put=(id,val)=>{const el=document.getElementById(id);if(el)el.innerHTML=val;};
    put("balance",money(balance));put("income",money(incomes));put("expense",money(expenses));put("monthExpense",money(total(month)));put("transactions",String(tx.length));
  }
  function transactionHTML(x, showType=true){
    const income=x.type==="income";
    return `<tr><td><div class="transaction-name"><span class="transaction-symbol ${income?"income":"expense"}">${income?"↗":"↙"}</span><span>${escapeHTML(x.note|| (income?"Даромад":"Хароҷот"))}<span class="subline">${income?"Воридшавии пул":"Категория: "+escapeHTML(categoryFor(x.note))}</span></span></div></td><td>${dateLabel(x.date)}</td>${showType?`<td><span class="type-pill ${income?"income":"expense"}">${income?"Даромад":"Хароҷот"}</span></td>`:""}<td class="align-right ${income?"money-positive":"money-negative"}">${income?"+":"−"}${plainMoney(x.amount)}</td></tr>`;
  }
  function renderRecent(){
    const body=document.getElementById("recentTransactions");if(!body)return;
    const tx=getTransactions().sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,7);
    body.innerHTML=tx.map(x=>transactionHTML(x,true)).join("");
    const empty=document.getElementById("emptyRecent");if(empty)empty.classList.toggle("hidden",tx.length>0);
  }
  function renderIncome(){
    const body=document.getElementById("incomeHistory");if(!body)return;
    const tx=getTransactions().filter(x=>x.type==="income").sort((a,b)=>new Date(b.date)-new Date(a.date));
    body.innerHTML=tx.map(x=>transactionHTML(x,false)).join("");
    const empty=document.getElementById("emptyIncome");if(empty)empty.classList.toggle("hidden",tx.length>0);
    const count=document.getElementById("incomeCount");if(count)count.textContent=`${tx.length} амалиёт`;
  }
  function renderExpenses(){
    const body=document.getElementById("expenseHistory");if(!body)return;
    const tx=getTransactions().filter(x=>x.type==="expense").sort((a,b)=>new Date(b.date)-new Date(a.date));
    body.innerHTML=tx.map(x=>transactionHTML(x,false)).join("");
    const empty=document.getElementById("emptyExpense");if(empty)empty.classList.toggle("hidden",tx.length>0);
    const count=document.getElementById("expenseCount");if(count)count.textContent=`${tx.length} амалиёт`;
  }
  function lastSevenDays(items){
    const labels=[],incs=[],exps=[];
    for(let i=6;i>=0;i--){const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-i);const key=dayKey(d);labels.push(d.toLocaleDateString("tg-TJ",{day:"2-digit",month:"short"}));const day=items.filter(x=>dayKey(x.date)===key);incs.push(total(day,"income"));exps.push(total(day,"expense"));}
    return {labels,incs,exps};
  }
  function renderOverviewCharts(){
    const tx=getTransactions(),flow=lastSevenDays(tx),cats=categoryTotals(tx);
    makeLine("overviewChart",flow.labels,flow.incs,flow.exps);makeDoughnut("categoryChart",cats);
    const legend=document.getElementById("categoryLegend");
    if(legend)legend.innerHTML=cats.slice(0,4).map((c,i)=>`<div class="legend-row"><span class="legend-label"><i class="legend-dot" style="background:${colors[i%colors.length]}"></i>${escapeHTML(c.name)}</span><span class="legend-amount">${plainMoney(c.total)}</span></div>`).join("")||'<p class="muted">Ҳоло маълумот нест.</p>';
  }
  function renderStatistics(){
    const tx=getTransactions(),fromEl=document.getElementById("dateFrom"),toEl=document.getElementById("dateTo");
    if(!fromEl||!toEl)return;
    const from=fromEl.value?new Date(fromEl.value+"T00:00:00"):null,to=toEl.value?new Date(toEl.value+"T23:59:59.999"):null;
    const filtered=tx.filter(x=>{const d=new Date(x.date);return(!from||d>=from)&&(!to||d<=to);});
    const incomes=total(filtered,"income"),expenses=total(filtered,"expense");
    const put=(id,val)=>{const el=document.getElementById(id);if(el)el.innerHTML=val;};
    put("statIncome",money(incomes));put("statExpense",money(expenses));put("statNet",money(incomes-expenses));
    const expCount=filtered.filter(x=>x.type==="expense").length;put("statCount",String(expCount));
    const flow=lastSevenDays(filtered);makeLine("statFlowChart",flow.labels,flow.incs,flow.exps);
    const cats=categoryTotals(filtered);makeDoughnut("statCategoryChart",cats);
    const body=document.getElementById("categoryTable");
    if(body)body.innerHTML=cats.map((c,i)=>`<tr><td><div class="transaction-name"><i class="legend-dot" style="background:${colors[i%colors.length]}"></i>${escapeHTML(c.name)}</div></td><td>${c.count}</td><td class="align-right money-negative">${plainMoney(c.total)}</td></tr>`).join("");
    const empty=document.getElementById("emptyStats");if(empty)empty.classList.toggle("hidden",cats.length>0||filtered.some(x=>x.type==="income"));
  }
  function initForms(){
    const incomeForm=document.getElementById("incomeForm");
    if(incomeForm)incomeForm.addEventListener("submit",e=>{
      e.preventDefault();const amount=Number(document.getElementById("incomeAmount").value),note=document.getElementById("incomeNote").value.trim();
      if(!Number.isFinite(amount)||amount<=0){showToast("Маблағ бояд аз сифр зиёд бошад.");return;}
      const tx=getTransactions();tx.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),type:"income",amount,note:note||"Даромад",date:new Date().toISOString()});saveTransactions(tx);incomeForm.reset();refresh();showToast("Даромад бо муваффақият сабт шуд ✓");
    });
    const expenseForm=document.getElementById("expenseForm");
    if(expenseForm)expenseForm.addEventListener("submit",e=>{
      e.preventDefault();const amount=Number(document.getElementById("expenseAmount").value),note=document.getElementById("expenseNote").value.trim();
      if(!Number.isFinite(amount)||amount<=0){showToast("Маблағ бояд аз сифр зиёд бошад.");return;}
      if(!note){showToast("Лутфан сабаби хароҷотро навис.");return;}
      const tx=getTransactions();tx.push({id:crypto.randomUUID?crypto.randomUUID():String(Date.now()),type:"expense",amount,note,date:new Date().toISOString()});saveTransactions(tx);expenseForm.reset();refresh();showToast("Хароҷот бо муваффақият сабт шуд ✓");
    });
  }
  function initStatistics(){
    const from=document.getElementById("dateFrom"),to=document.getElementById("dateTo");
    if(!from||!to)return;
    const now=new Date(),start=new Date(now.getFullYear(),now.getMonth(),1);
    from.value=dayKey(start);to.value=dayKey(now);
    document.getElementById("applyDates")?.addEventListener("click",()=>{
      if(from.value&&to.value&&from.value>to.value){showToast("Санаи оғоз набояд аз санаи анҷом дертар бошад.");return;}renderStatistics();
    });
    document.getElementById("allTime")?.addEventListener("click",()=>{from.value="";to.value="";renderStatistics();});
    renderStatistics();
  }
  function initNavigation(){
    document.getElementById("themeToggle")?.addEventListener("click",()=>setTheme(isDark()?"light":"dark"));
    document.getElementById("mobileMenu")?.addEventListener("click",()=>document.querySelector(".sidebar")?.classList.toggle("open"));
    document.addEventListener("click",e=>{const side=document.querySelector(".sidebar");if(side?.classList.contains("open")&&!side.contains(e.target)&&!e.target.closest("#mobileMenu"))side.classList.remove("open");});
    const year=document.getElementById("year");if(year)year.textContent=new Date().getFullYear();
    setTheme(localStorage.getItem(THEME_KEY)||"light");
  }
  function refresh(){updateSharedStats();renderRecent();renderIncome();renderExpenses();renderOverviewCharts();renderStatistics();}
  document.addEventListener("DOMContentLoaded",()=>{initNavigation();initForms();initStatistics();refresh();});
})();