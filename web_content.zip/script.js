
(() => {
  const grid = document.getElementById('mods-grid');
  const status = document.getElementById('status');
  const count = document.getElementById('mod-count');
  const search = document.getElementById('search');
  const category = document.getElementById('category');

  const API_URL =
    window.OSAMA_MODS_API ||
    'https://osama-mods-app-api.omhj123456.workers.dev/api/mods';

  let mods = [];

  // تبديل المظهر مع حفظ الاختيار على نفس الجهاز
  const savedTheme = (() => {
    try {
      return localStorage.getItem('osama-mods-theme');
    } catch (_) {
      return null;
    }
  })();

  const validThemes = ['normal', 'light', 'pink'];

  function setTheme(theme) {
    if (!validThemes.includes(theme)) theme = 'normal';

    document.body.dataset.theme = theme;

    document.querySelectorAll('[data-theme-choice]').forEach(button => {
      button.setAttribute(
        'aria-pressed',
        String(button.dataset.themeChoice === theme)
      );
    });

    try {
      localStorage.setItem('osama-mods-theme', theme);
    } catch (_) {}
  }

  document.querySelectorAll('[data-theme-choice]').forEach(button => {
    button.addEventListener('click', () => {
      setTheme(button.dataset.themeChoice);
    });
  });

  setTheme(savedTheme || 'normal');

  function safeText(value, fallback = '') {
    return typeof value === 'string' ? value.trim() : fallback;
  }

  function showStatus(message, isError = false) {
    status.hidden = false;
    status.className = isError ? 'status error' : 'status';
    status.textContent = message;
  }


  // نافذة تنزيل مناسبة لنسخة ZIP to APK المجانية: نسخ الرابط ثم فتحه يدويًا في Chrome.
  function showDownloadDialog(url, modName) {
    const existing = document.getElementById('download-dialog-overlay');
    if (existing) existing.remove();

    const overlay = document.createElement('div');
    overlay.id = 'download-dialog-overlay';
    overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.78);display:flex;align-items:center;justify-content:center;padding:18px;';

    const panel = document.createElement('div');
    panel.dir = 'rtl';
    panel.style.cssText = 'width:100%;max-width:440px;background:#17231b;color:#f3fff5;border:1px solid #35533e;border-radius:18px;padding:22px;box-shadow:0 18px 55px rgba(0,0,0,.4);font-family:inherit;';

    const heading = document.createElement('h3');
    heading.textContent = 'رابط تحميل ' + modName;
    heading.style.cssText = 'margin:0 0 10px;font-size:19px;';

    const instructions = document.createElement('p');
    instructions.textContent = 'اضغط «نسخ الرابط»، ثم افتح Google Chrome والصق الرابط في شريط العنوان لبدء التحميل.';
    instructions.style.cssText = 'margin:0 0 14px;color:#c5d8ca;line-height:1.8;font-size:14px;';

    const field = document.createElement('textarea');
    field.readOnly = true;
    field.value = url;
    field.setAttribute('aria-label', 'رابط التحميل');
    field.style.cssText = 'box-sizing:border-box;width:100%;min-height:82px;resize:vertical;direction:ltr;text-align:left;background:#0d1510;color:#e9ffed;border:1px solid #42604a;border-radius:10px;padding:11px;font-size:12px;';

    const actions = document.createElement('div');
    actions.style.cssText = 'display:flex;gap:9px;margin-top:14px;';

    const copyButton = document.createElement('button');
    copyButton.type = 'button';
    copyButton.textContent = 'نسخ الرابط';
    copyButton.style.cssText = 'flex:1;border:0;border-radius:10px;padding:12px;background:#35c76b;color:#07130a;font-weight:800;font-size:14px;';
    copyButton.addEventListener('click', async () => {
      let copied = false;
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          await navigator.clipboard.writeText(url);
          copied = true;
        }
      } catch (_) {}
      if (!copied) {
        field.focus();
        field.select();
        try { copied = document.execCommand('copy'); } catch (_) {}
      }
      copyButton.textContent = copied ? 'تم نسخ الرابط ✓' : 'حدّد الرابط وانسخه';
      if (!copied) field.select();
    });

    const closeButton = document.createElement('button');
    closeButton.type = 'button';
    closeButton.textContent = 'إغلاق';
    closeButton.style.cssText = 'border:1px solid #49634f;border-radius:10px;padding:12px 18px;background:#26372b;color:#fff;font-weight:700;font-size:14px;';
    closeButton.addEventListener('click', () => overlay.remove());

    actions.append(copyButton, closeButton);
    panel.append(heading, instructions, field, actions);
    overlay.appendChild(panel);
    overlay.addEventListener('click', event => {
      if (event.target === overlay) overlay.remove();
    });
    document.body.appendChild(overlay);
  }

  function makeCard(mod) {
    const card = document.createElement('article');
    card.className = 'mod-card';

    const imageUrl = safeText(mod.image);

    if (imageUrl && /^https?:\/\//i.test(imageUrl)) {
      const image = document.createElement('img');

      image.className = 'mod-image';
      image.referrerPolicy = 'no-referrer';
      image.src = imageUrl;
      image.alt = safeText(mod.name, 'صورة المود');
      image.loading = 'lazy';

      image.onerror = () => {
        const placeholder = document.createElement('div');
        placeholder.className = 'mod-image-placeholder';
        placeholder.textContent = 'OM';
        image.replaceWith(placeholder);
      };

      card.appendChild(image);
    } else {
      const placeholder = document.createElement('div');
      placeholder.className = 'mod-image-placeholder';
      placeholder.textContent = 'OM';
      card.appendChild(placeholder);
    }

    const content = document.createElement('div');
    content.className = 'mod-content';

    const badge = document.createElement('span');
    badge.className = 'mod-category';
    badge.textContent = safeText(mod.category, 'عام') || 'عام';

    const title = document.createElement('h3');
    title.textContent = safeText(mod.name, 'مود بدون اسم');

    const description = document.createElement('p');
    description.textContent = safeText(
      mod.description,
      'لا يوجد وصف لهذا المود.'
    );

    content.append(badge, title, description);

    const downloadUrl = safeText(mod.download);
    const link = document.createElement('a');

    link.className = 'download';
    link.textContent = 'تحميل المود';

    if (downloadUrl && /^https?:\/\//i.test(downloadUrl)) {
      link.href = '#';
      link.addEventListener('click', event => {
        event.preventDefault();
        showDownloadDialog(downloadUrl, safeText(mod.name, 'المود'));
      });
    } else {
      link.href = '#';
      link.setAttribute('aria-disabled', 'true');
      link.style.opacity = '.55';

      link.addEventListener('click', event => {
        event.preventDefault();
        showStatus(
          'رابط التحميل لهذا المود غير صحيح. عدّل رابط download من لوحة المشرفين.',
          true
        );
      });
    }

    content.appendChild(link);
    card.appendChild(content);

    return card;
  }

  function updateCategories() {
    const previousCategory = category.value;

    // إعادة بناء التصنيفات لمنع تكرارها أو إبقاء تصنيف محذوف
    category.replaceChildren();

    const allOption = document.createElement('option');
    allOption.value = '';
    allOption.textContent = 'كل التصنيفات';
    category.appendChild(allOption);

    const categories = [
      ...new Set(
        mods
          .map(mod => safeText(mod.category, 'عام') || 'عام')
          .filter(Boolean)
      )
    ].sort((a, b) => a.localeCompare(b));

    categories.forEach(name => {
      const option = document.createElement('option');
      option.value = name;
      option.textContent = name;
      category.appendChild(option);
    });

    // الاحتفاظ بالتصنيف المختار إذا كان ما زال موجودًا
    if (categories.includes(previousCategory)) {
      category.value = previousCategory;
    }
  }

  function render() {
    const query = search.value.trim().toLocaleLowerCase();
    const selectedCategory = category.value;

    const filtered = mods.filter(mod => {
      const haystack = [
        mod.name,
        mod.description,
        mod.category
      ]
        .map(value => safeText(value).toLocaleLowerCase())
        .join(' ');

      const modCategory = safeText(mod.category, 'عام') || 'عام';

      return (
        haystack.includes(query) &&
        (!selectedCategory || modCategory === selectedCategory)
      );
    });

    grid.replaceChildren();

    filtered.forEach(mod => {
      grid.appendChild(makeCard(mod));
    });

    count.textContent = `${filtered.length} مود`;

    if (!filtered.length) {
      const empty = document.createElement('div');
      empty.className = 'empty';

      empty.textContent = mods.length
        ? 'ما لقينا مود يطابق بحثك.'
        : 'لا توجد مودات منشورة حاليًا.';

      grid.appendChild(empty);
    }
  }

  async function loadMods() {
    count.textContent = 'جارٍ التحميل…';
    showStatus('جارٍ تحميل أحدث الإضافات...');

    try {
      const response = await fetch(API_URL, {
        method: 'GET',
        cache: 'no-store',
        headers: {
          Accept: 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const data = await response.json();

      if (!Array.isArray(data)) {
        throw new Error('استجابة API ليست قائمة مودات صحيحة.');
      }

      // البيانات تأتي مباشرة من قاعدة بيانات المتجر
      mods = data.filter(
        item => item &&
          typeof item === 'object' &&
          !Array.isArray(item)
      );

      updateCategories();
      render();

      if (mods.length) {
        status.hidden = true;
      } else {
        showStatus('لا توجد مودات منشورة حاليًا.');
      }
    } catch (error) {
      count.textContent = 'تعذّر التحميل';

      showStatus(
        'تعذّر تحميل المودات من الخادم. تحقق من الإنترنت وإعدادات CORS ورابط API، ثم أعد تحميل الصفحة.',
        true
      );

      console.error('OSAMA MODS: failed to load API data', error);
    }
  }

  search.addEventListener('input', render);
  category.addEventListener('change', render);

  // تحميل البيانات عند فتح المتجر
  loadMods();

  // تحديث البيانات عند العودة إلى صفحة المتجر
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) loadMods();
  });

  // إتاحة إعادة التحميل يدويًا من أدوات المتصفح عند الحاجة
  window.refreshOsamaMods = loadMods;
})();
