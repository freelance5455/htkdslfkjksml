let transactions = JSON.parse(localStorage.getItem("waisSarafi2026")) || [];

document.getElementById("date").value = new Date().toISOString().split("T")[0];

function saveTransaction() {
  const customer = document.getElementById("customer").value.trim();
  const bigMoney = Number(document.getElementById("bigMoney").value) || 0;
  const fifty = Number(document.getElementById("fifty").value) || 0;
  const twenty = Number(document.getElementById("twenty").value) || 0;
  const ten = Number(document.getElementById("ten").value) || 0;
  const date = document.getElementById("date").value;

  if (!customer) {
    alert("مهرباني وکړئ د مشتری نوم ولیکئ");
    return;
  }
  if (bigMoney <= 0) {
    alert("مهرباني وکړئ د غټو پیسو اندازه ولیکئ");
    return;
  }

  const received = fifty + twenty + ten;

  const transaction = {
    id: Date.now(), customer, bigMoney, fifty, twenty, ten, received, date
  };

  transactions.push(transaction);
  localStorage.setItem("waisSarafi2026", JSON.stringify(transactions));

  document.getElementById("customer").value = "";
  document.getElementById("bigMoney").value = "";
  document.getElementById("fifty").value = "";
  document.getElementById("twenty").value = "";
  document.getElementById("ten").value = "";

  renderTransactions();
  alert("معامله په بریالیتوب ثبت شوه ✅");
}

function renderTransactions() {
  const container = document.getElementById("transactions");
  container.innerHTML = "";
  document.getElementById("count").innerText = transactions.length;

  let totalBig = 0;
  let totalReceived = 0;
  transactions.forEach(t => {
    totalBig += t.bigMoney;
    totalReceived += t.received;
  });

  document.getElementById("totalBig").innerText = totalBig.toLocaleString();
  document.getElementById("totalReceived").innerText = totalReceived.toLocaleString();

  transactions.slice().reverse().forEach(t => {
    const difference = t.received - t.bigMoney;
    container.innerHTML += `
      <div class="transaction">
        <b>👤 مشتری:</b> ${t.customer}<br>
        <b>📅 تاریخ:</b> ${t.date}<br><br>
        <b>💵 غټې پیسې ورکړل شوې:</b> ${t.bigMoney.toLocaleString()} افغانۍ<br>
        <b>💰 ۵۰ګون:</b> ${t.fifty.toLocaleString()} افغانۍ<br>
        <b>💰 ۲۰ګون:</b> ${t.twenty.toLocaleString()} افغانۍ<br>
        <b>💰 ۱۰ګون:</b> ${t.ten.toLocaleString()} افغانۍ<br><br>
        <b>📊 ټولې ماتي پیسې:</b> ${t.received.toLocaleString()} افغانۍ<br>
        <b>⚖️ فرق:</b> ${difference.toLocaleString()} افغانۍ
        <button class="delete" onclick="deleteTransaction(${t.id})">🗑 حذف کړه</button>
      </div>`;
  });
}

function deleteTransaction(id) {
  if (!confirm("ایا دا معامله حذف کول غواړې؟")) return;
  transactions = transactions.filter(t => t.id !== id);
  localStorage.setItem("waisSarafi2026", JSON.stringify(transactions));
  renderTransactions();
}

renderTransactions();
