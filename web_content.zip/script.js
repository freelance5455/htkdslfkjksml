// Adrian Browser Logic - Smooth & Android 4 Optimized
document.addEventListener("DOMContentLoaded", function() {
    const urlInput = document.getElementById("url-input");
    const btnGo = document.getElementById("btn-go");
    const btnRefresh = document.getElementById("btn-refresh");
    const btnHome = document.getElementById("btn-home");
    const dashboard = document.getElementById("home-dashboard");
    const browserFrame = document.getElementById("browser-frame");
    const statusText = document.getElementById("status-text");
    const bookmarkBtns = document.querySelectorAll(".bookmark-btn");

    window.loadUrl = function(url) {
        if (!url) return;
        
        // Format URL if missing protocol
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            if (url.includes(".") && !url.includes(" ")) {
                url = "https://" + url;
            } else {
                url = "https://www.google.com/search?q=" + encodeURIComponent(url);
            }
        }

        urlInput.value = url;
        statusText.textContent = "Ładowanie: " + url;
        
        dashboard.style.display = "none";
        browserFrame.style.display = "block";
        browserFrame.src = url;

        browserFrame.onload = function() {
            statusText.textContent = "Załadowano pomyślnie • Adrian Browser";
        };
    };

    btnGo.addEventListener("click", function() {
        loadUrl(urlInput.value);
    });

    urlInput.addEventListener("keypress", function(e) {
        if (e.key === "Enter" || e.keyCode === 13) {
            loadUrl(urlInput.value);
        }
    });

    btnRefresh.addEventListener("click", function() {
        if (browserFrame.style.display === "block" && browserFrame.src !== "about:blank") {
            statusText.textContent = "Odświeżanie...";
            browserFrame.contentWindow.location.reload();
        } else {
            dashboard.style.display = "flex";
            browserFrame.style.display = "none";
        }
    });

    btnHome.addEventListener("click", function() {
        dashboard.style.display = "flex";
        browserFrame.style.display = "none";
        urlInput.value = "https://www.google.com";
        statusText.textContent = "Strona główna • Adrian Browser";
    });

    bookmarkBtns.forEach(function(btn) {
        btn.addEventListener("click", function() {
            const targetUrl = this.getAttribute("data-url");
            loadUrl(targetUrl);
        });
    });

    // Back / Forward simulation for iframe
    document.getElementById("btn-back").addEventListener("click", function() {
        try {
            if (browserFrame.contentWindow.history.length > 1) {
                browserFrame.contentWindow.history.back();
            } else {
                dashboard.style.display = "flex";
                browserFrame.style.display = "none";
            }
        } catch(err) {
            dashboard.style.display = "flex";
            browserFrame.style.display = "none";
        }
    });

    document.getElementById("btn-forward").addEventListener("click", function() {
        try {
            browserFrame.contentWindow.history.forward();
        } catch(err) {}
    });
});
