import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { getAuth, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile, sendPasswordResetEmail, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import { getDatabase, ref, set, push, onValue, remove } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-database.js";

const firebaseConfig={apiKey:"AIzaSyB94z3Z61QSz8zie9cL8g6Gayjsbp9LHSY",authDomain:"mealflow-56118.firebaseapp.com",databaseURL:"https://mealflow-56118-default-rtdb.asia-southeast1.firebasedatabase.app",projectId:"mealflow-56118",storageBucket:"mealflow-56118.firebasestorage.app",messagingSenderId:"274352422081",appId:"1:274352422081:web:a1739bf867e110d9f42840",measurementId:"G-XS71C9C8EN"};
const app=initializeApp(firebaseConfig),auth=getAuth(app),db=getDatabase(app);
const $=id=>document.getElementById(id), today=new Date().toISOString().slice(0,10), monthNow=today.slice(0,7);
$("mealDate").value=today;$("offDate").value=today;$("depositDate").value=today;$("reportMonth").value=monthNow;$("historyMonth").value=monthNow;
let uid=null,data={meals:{},deposits:{},offDays:{},settings:{mealPrice:0}},unsubs=[];

function toast(m){$("toast").textContent=m;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2500)}
function money(n){return "৳"+Number(n||0).toLocaleString("en-BD",{maximumFractionDigits:2})}
function path(p){return ref(db,`users/${uid}/${p}`)}
function calc(month=monthNow){
 let meals=Object.values(data.meals||{}).filter(x=>x.date?.startsWith(month)), deposits=Object.values(data.deposits||{}).filter(x=>x.date?.startsWith(month)), offs=Object.values(data.offDays||{}).filter(x=>x.date?.startsWith(month));
 let cost=meals.reduce((s,x)=>s+Number(x.price||0),0), dep=deposits.reduce((s,x)=>s+Number(x.amount||0),0);
 return {meals,deposits,offs,cost,dep,balance:dep-cost};
}
function render(){
 const c=calc(monthNow); $("dashMonth").textContent=new Date(monthNow+"-01").toLocaleDateString("en-US",{month:"long",year:"numeric"});
 $("totalMeals").textContent=c.meals.length;$("mealCost").textContent=money(c.cost);$("totalDeposit").textContent=money(c.dep);$("balance").textContent=money(c.balance);$("offDaysText").textContent=`${c.offs.length} off days`;
 $("mealBreakdown").innerHTML=["breakfast","lunch","dinner"].map(t=>`<div class="break-row"><span>${t[0].toUpperCase()+t.slice(1)}</span><b>${c.meals.filter(x=>x.type===t).length}</b></div>`).join("");
 $("mealPrice").value=data.settings?.mealPrice??0;
 renderDeposits();renderOffs();renderReport();renderHistory();
}
function renderDeposits(){let a=Object.entries(data.deposits||{}).sort((a,b)=>(b[1].date||"").localeCompare(a[1].date||""));$("depositList").innerHTML=a.length?a.map(([id,x])=>`<div class="list-item"><div><b>${money(x.amount)}</b><small> · ${x.date}${x.note?" · "+x.note:""}</small></div><button class="danger" data-del-deposit="${id}">Delete</button></div>`).join(""):"<p class='muted'>No deposits yet.</p>"}
function renderOffs(){let a=Object.entries(data.offDays||{}).sort((a,b)=>b[1].date.localeCompare(a[1].date));$("offList").innerHTML=a.length?a.map(([id,x])=>`<div class="list-item"><b>${x.date}</b><button class="danger" data-del-off="${id}">Remove</button></div>`).join(""):"<p class='muted'>No off days.</p>"}
function renderReport(){let m=$("reportMonth").value||monthNow,c=calc(m);$("reportMeals").textContent=c.meals.length;$("reportCost").textContent=money(c.cost);$("reportDeposit").textContent=money(c.dep);$("reportBalance").textContent=money(c.balance);$("reportBreakdown").innerHTML=["breakfast","lunch","dinner"].map(t=>`<div class="break-row"><span>${t[0].toUpperCase()+t.slice(1)}</span><b>${c.meals.filter(x=>x.type===t).length}</b></div>`).join("")}
function renderHistory(){
 let m=$("historyMonth").value||monthNow;
 let items=[
   ...Object.entries(data.meals||{}).filter(([id,x])=>x.date?.startsWith(m)).map(([id,x])=>({...x,id,kind:"Meal",label:x.type,cost:x.price})),
   ...Object.entries(data.deposits||{}).filter(([id,x])=>x.date?.startsWith(m)).map(([id,x])=>({...x,id,kind:"Deposit",label:"Money added",cost:x.amount}))
 ].sort((a,b)=>b.date.localeCompare(a.date));
 $("historyList").innerHTML=items.length?items.map(x=>`<div class="list-item"><div><b>${x.kind}: ${x.label}</b><small> · ${x.date}${x.note?" · "+x.note:""}</small></div><div style="display:flex;align-items:center;gap:12px"><strong>${x.kind==="Meal"?money(x.cost):"+"+money(x.cost)}</strong><button class="danger" data-del-${x.kind.toLowerCase()}="${x.id}">Delete</button></div></div>`).join(""): "<p class='muted'>No activity for this month.</p>";
}

function showPage(page){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));$("page-"+page).classList.add("active");document.querySelectorAll("[data-page]").forEach(x=>x.classList.toggle("active",x.dataset.page===page));$("pageTitle").textContent=page[0].toUpperCase()+page.slice(1);window.scrollTo(0,0)}
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>showPage(b.dataset.page));document.querySelectorAll("[data-page-jump]").forEach(b=>b.onclick=()=>showPage(b.dataset.pageJump));

$("showSignup").onclick=()=>{$("loginView").classList.add("hidden");$("signupView").classList.remove("hidden")};$("showLogin").onclick=()=>{$("signupView").classList.add("hidden");$("loginView").classList.remove("hidden")};
$("loginForm").onsubmit=async e=>{e.preventDefault();try{await signInWithEmailAndPassword(auth,$("loginEmail").value,$("loginPassword").value)}catch(err){toast(err.message)}};
$("signupForm").onsubmit=async e=>{e.preventDefault();try{let c=await createUserWithEmailAndPassword(auth,$("signupEmail").value,$("signupPassword").value);await updateProfile(c.user,{displayName:$("signupName").value});await set(ref(db,`users/${c.user.uid}/profile`),{name:$("signupName").value,email:c.user.email,createdAt:Date.now()});toast("Account created")}catch(err){toast(err.message)}};
$("googleBtn").onclick=async()=>{try{await signInWithPopup(auth,new GoogleAuthProvider())}catch(e){toast(e.message)}};
$("facebookBtn").onclick=async()=>{try{await signInWithPopup(auth,new FacebookAuthProvider())}catch(e){toast(e.message)}};
$("forgotBtn").onclick=async()=>{let e=$("loginEmail").value;if(!e)return toast("Enter your email first");try{await sendPasswordResetEmail(auth,e);toast("Password reset email sent")}catch(x){toast(x.message)}};
$("logoutBtn").onclick=()=>signOut(auth);

$("mealForm").onsubmit=async e=>{e.preventDefault();let price=Number(data.settings?.mealPrice||0);if(price<=0)return toast("Set meal price first");let x={date:$("mealDate").value,type:$("mealType").value,note:$("mealNote").value,price,createdAt:Date.now()};await set(push(path("meals")),x);$("mealNote").value="";toast("Meal added")};
$("depositForm").onsubmit=async e=>{e.preventDefault();await set(push(path("deposits")),{amount:Number($("depositAmount").value),date:$("depositDate").value,note:$("depositNote").value,createdAt:Date.now()});e.target.reset();$("depositDate").value=today;toast("Deposit added")};
$("offForm").onsubmit=async e=>{e.preventDefault();await set(push(path("offDays")),{date:$("offDate").value,createdAt:Date.now()});toast("Off day added")};
$("priceForm").onsubmit=async e=>{e.preventDefault();await set(path("settings"),{...data.settings,mealPrice:Number($("mealPrice").value)});toast("Meal price saved")};
$("reportMonth").onchange=renderReport;$("historyMonth").onchange=renderHistory;
document.addEventListener("click", async (event) => {
  const btn = event.target.closest("button");
  if (!btn) return;

  const depositId = btn.getAttribute("data-del-deposit");
  const mealId = btn.getAttribute("data-del-meal");
  const offId = btn.getAttribute("data-del-off");

  if (depositId) {
    event.preventDefault();
    if (!confirm("Delete this deposit?\nThis action cannot be undone.")) return;
    try {
      await remove(ref(db, `users/${uid}/deposits/${depositId}`));
      toast("Deposit deleted");
    } catch (err) {
      console.error("Deposit delete failed:", err);
      toast("Delete failed: " + (err?.message || "Permission denied"));
    }
    return;
  }

  if (mealId) {
    event.preventDefault();
    if (!confirm("Delete this meal?\nThis will update your meal cost and balance.")) return;
    try {
      await remove(ref(db, `users/${uid}/meals/${mealId}`));
      toast("Meal deleted");
    } catch (err) {
      console.error("Meal delete failed:", err);
      toast("Delete failed: " + (err?.message || "Permission denied"));
    }
    return;
  }

  if (offId) {
    event.preventDefault();
    if (!confirm("Remove this off day?")) return;
    try {
      await remove(ref(db, `users/${uid}/offDays/${offId}`));
      toast("Off day removed");
    } catch (err) {
      console.error("Off-day delete failed:", err);
      toast("Delete failed: " + (err?.message || "Permission denied"));
    }
  }
});

onAuthStateChanged(auth,user=>{
 unsubs.forEach(u=>u());unsubs=[];uid=user?.uid||null;
 if(!user){$("authScreen").classList.remove("hidden");$("appShell").classList.add("hidden");return}
 $("authScreen").classList.add("hidden");$("appShell").classList.remove("hidden");
 let name=user.displayName||user.email?.split("@")[0]||"User";$("userName").textContent=name;$("settingsName").textContent=name;$("settingsEmail").textContent=user.email||"";$("avatar").textContent=name[0].toUpperCase();$("settingsAvatar").textContent=name[0].toUpperCase();
 const uref=ref(db,`users/${uid}`);unsubs.push(onValue(uref,s=>{data=s.val()||{};data.meals=data.meals||{};data.deposits=data.deposits||{};data.offDays=data.offDays||{};data.settings=data.settings||{mealPrice:0};render()}));
});
