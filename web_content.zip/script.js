// Arreglo para almacenar los productos del carrito
let carrito = [];
let estrellaSeleccionada = 0;

// Verificar si es el primer pedido en este navegador
function esPrimerEnvio() {
    return localStorage.getItem('moonwhite_pedidos') === null;
}

// Inicializar la detección del primer envío al cargar
document.addEventListener('DOMContentLoaded', () => {
    actualizarBannerEnvio();
});

function actualizarBannerEnvio() {
    const banner = document.getElementById('promo-banner');
    const envioTexto = document.getElementById('envio-texto');

    if (!esPrimerEnvio()) {
        if (banner) banner.innerText = "🛵 ¡Realizamos envíos a toda La Paz!";
        if (envioTexto) envioTexto.innerHTML = "🛵 <strong>Costo de Envío: Se calculará al confirmar tu ubicación.</strong>";
    }
}

// Agregar cono al carrito
function agregarAlCarrito(nombreProducto, precioBase) {
    // Capturar toppings seleccionados
    const toppingsCB = document.querySelectorAll('.topping-cb:checked');
    let toppings = [];
    toppingsCB.forEach(cb => toppings.push(cb.value));

    // Capturar salsas seleccionadas
    const salsasCB = document.querySelectorAll('.salsa-cb:checked');
    let salsas = [];
    salsasCB.forEach(cb => salsas.push(cb.value));

    const item = {
        nombre: nombreProducto,
        precio: precioBase,
        toppings: toppings,
        salsas: salsas
    };

    carrito.push(item);
    actualizarCarrito();

    // Desmarcar selecciones tras agregar
    toppingsCB.forEach(cb => cb.checked = false);
    salsasCB.forEach(cb => cb.checked = false);
}

// Actualizar vista del carrito y calcular total
function actualizarCarrito() {
    const cartItemsContainer = document.getElementById('cart-items');
    const cartCount = document.getElementById('cart-count');
    const totalPrecioElem = document.getElementById('total-precio');

    cartCount.innerText = carrito.length;

    if (carrito.length === 0) {
        cartItemsContainer.innerHTML = '<p class="empty-cart">Tu carrito está vacío.</p>';
        totalPrecioElem.innerText = '0';
        return;
    }

    cartItemsContainer.innerHTML = '';
    let total = 0;

    carrito.forEach((item, index) => {
        total += item.precio;
        const div = document.createElement('div');
        div.classList.add('cart-item');

        let extras = [];
        if (item.toppings.length > 0) extras.push(`Toppings: ${item.toppings.join(', ')}`);
        if (item.salsas.length > 0) extras.push(`Salsas: ${item.salsas.join(', ')}`);

        let detalleExtras = extras.length > 0 ? `<br><small style="color: #666;">└ ${extras.join(' | ')}</small>` : '';
        let precioTxt = item.precio > 0 ? `${item.precio} Bs` : 'A consultar';

        div.innerHTML = `
            <div>
                <strong>${item.nombre}</strong> - ${precioTxt}
                ${detalleExtras}
            </div>
            <button onclick="eliminarDelCarrito(${index})" style="color: #E63946; background: none; border: none; cursor: pointer; font-weight: bold;">❌</button>
        `;

        cartItemsContainer.appendChild(div);
    });

    totalPrecioElem.innerText = total;
}

function eliminarDelCarrito(index) {
    carrito.splice(index, 1);
    actualizarCarrito();
}

// Lógica de Selección de Estrellas y Reseñas
function seleccionarEstrella(num) {
    estrellaSeleccionada = num;
    const estrellas = document.querySelectorAll('.star-selector .star');
    const feedback = document.getElementById('review-feedback');

    estrellas.forEach((star, index) => {
        if (index < num) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });

    if (num === 5) {
        feedback.innerText = "¡Muchas gracias por elegirnos y por tu apoyo a Moon White! 🥞✨";
        feedback.style.color = "#25D366";
    } else if (num >= 1 && num <= 3) {
        feedback.innerText = "Lamentamos tu experiencia. Por favor déjanos tus comentarios para saber en qué aspectos podemos mejorar. 📝";
        feedback.style.color = "#E63946";
    } else {
        feedback.innerText = "¡Gracias por tu valoración! 😊";
        feedback.style.color = "#D4AF37";
    }
}

function guardarReseña() {
    const textoReseña = document.getElementById('review-text').value.trim();
    const listado = document.getElementById('reviews-list');

    if (estrellaSeleccionada === 0) {
        alert("Por favor selecciona una cantidad de estrellas (1 a 5).");
        return;
    }

    const item = document.createElement('div');
    item.classList.add('review-item');
    item.innerHTML = `
        <strong>Calificación: ${'★'.repeat(estrellaSeleccionada)}</strong>
        <p>${textoReseña ? textoReseña : 'Sin comentario escrito.'}</p>
    `;

    listado.prepend(item);

    // Resetear formulario
    document.getElementById('review-text').value = '';
    seleccionarEstrella(0);
    document.getElementById('review-feedback').innerText = '';
    alert("¡Reseña publicada con éxito!");
}

// Enviar pedido a WhatsApp
function enviarPedidoWhatsApp() {
    if (carrito.length === 0) {
        alert("Tu carrito está vacío. Agrega al menos una crepa para continuar.");
        return;
    }

    const nombre = document.getElementById('nombre-cliente').value.trim();
    const direccion = document.getElementById('direccion-cliente').value.trim();

    if (!nombre || !direccion) {
        alert("Por favor, ingresa tu nombre completo y dirección de entrega.");
        return;
    }

    const primerPedido = esPrimerEnvio();
    const textoEnvio = primerPedido ? "¡SÍ! (Primer envío GRATIS)" : "No (Calcular costo de envío)";

    // Registrar que el usuario ya realizó un pedido
    localStorage.setItem('moonwhite_pedidos', 'realizado');
    actualizarBannerEnvio();

    const numeroWhatsApp = "59100000000"; // Reemplaza con tu número de WhatsApp real

    let mensaje = `👋 ¡Hola *Moon White*! Quiero realizar el siguiente pedido:\n\n`;
    mensaje += `👤 *Cliente:* ${nombre}\n`;
    mensaje += `📍 *Dirección:* ${direccion}\n`;
    mensaje += `🎁 *¿Primer Envío Gratis?:* ${textoEnvio}\n\n`;
    mensaje += `📋 *Detalle del Pedido:*\n`;

    let total = 0;
    carrito.forEach((item, i) => {
        total += item.precio;
        let extras = [];
        if (item.toppings.length > 0) extras.push(`Toppings: ${item.toppings.join(', ')}`);
        if (item.salsas.length > 0) extras.push(`Salsas: ${item.salsas.join(', ')}`);

        let extrasTxt = extras.length > 0 ? `\n   └ *Personalización:* ${extras.join(' | ')}` : '';
        let precioTxt = item.precio > 0 ? `${item.precio} Bs` : 'A consultar';

        mensaje += `${i + 1}. *${item.nombre}* (${precioTxt})${extrasTxt}\n`;
    });

    mensaje += `\n💰 *Total Productos:* ${total} Bs`;
    mensaje += `\n📌 *Nota:* Quedo a la espera de la confirmación del pedido. ¡Gracias!`;

    const url = `https://api.whatsapp.com/send?phone=${numeroWhatsApp}&text=${encodeURIComponent(mensaje)}`;
    window.open(url, '_blank');
}