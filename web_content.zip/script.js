/* ==========================================================
   Setu — Academia & Industry Bridge
   Front-end prototype: localStorage stands in for a real backend.
   ========================================================== */

   const DB_KEYS = {
    students: 'setu_students',
    companies: 'setu_companies',
    internships: 'setu_internships',
    session: 'setu_session'
  };
  
  /* ---------- tiny storage helpers ---------- */
  
  function loadList(key) {
    try {
      return JSON.parse(localStorage.getItem(key)) || [];
    } catch (e) {
      return [];
    }
  }
  
  function saveList(key, list) {
    localStorage.setItem(key, JSON.stringify(list));
  }
  
  function getSession() {
    try {
      return JSON.parse(localStorage.getItem(DB_KEYS.session));
    } catch (e) {
      return null;
    }
  }
  
  function setSession(session) {
    if (session)
      localStorage.setItem(DB_KEYS.session, JSON.stringify(session));
    else
      localStorage.removeItem(DB_KEYS.session);
  }
  
  function uid() {
    return Date.now().toString(36) +
      Math.random().toString(36).slice(2, 7);
  }
  
  /* ---------- seed data on first run ---------- */
  
  function seedIfEmpty() {
    if (loadList(DB_KEYS.internships).length) return;
    if (loadList(DB_KEYS.companies).length) return;
  
    const sampleCompany = {
      id: uid(),
      name: 'Bluepeak Systems',
      industry: 'Software Services',
      email: 'hr@bluepeak.example',
      password: 'demo1234'
    };
  
    saveList(DB_KEYS.companies, [sampleCompany]);
  
    saveList(DB_KEYS.internships, [
      {
        id: uid(),
        companyId: sampleCompany.id,
        companyName: sampleCompany.name,
        title: 'Frontend Development Intern',
        type: 'Internship',
        skills: ['HTML', 'CSS', 'JavaScript'],
        description: 'Work with the product team to build and ship UI components for a live student-facing app.',
        applicants: []
      },
      {
        id: uid(),
        companyId: sampleCompany.id,
        companyName: sampleCompany.name,
        title: 'Data Analyst — Graduate Program',
        type: 'Full-time',
        skills: ['SQL', 'Excel', 'Python'],
        description: 'Analyse placement and skill-gap data across partner colleges to guide hiring decisions.',
        applicants: []
      }
    ]);
  }
  
  /* ==========================================================
     Router
     ========================================================== */
  
  const PAGES = [
    'home',
    'student-auth',
    'company-auth',
    'dashboard',
    'internships'
  ];
  
  function navigate(pageId) {
    const session = getSession();
  
    // Guard private pages
    if (
      pageId === 'dashboard' &&
      !(session && session.type === 'student')
    ) {
      pageId = 'student-auth';
    }
  
    if (pageId === 'internships' && !session) {
      pageId = 'home';
    }
  
    PAGES.forEach(id => {
      const el = document.getElementById('page-' + id);
  
      if (el) {
        el.classList.toggle('is-active', id === pageId);
      }
    });
  
    renderNav();
  
    if (pageId === 'dashboard') {
      renderDashboard();
    }
  
    if (pageId === 'internships') {
      renderInternships();
    }
  
    window.scrollTo({
      top: 0,
      behavior: 'instant' in window ? 'instant' : 'auto'
    });
  
    document.getElementById('main-nav').classList.remove('is-open');
  }
  
  /* Delegate every [data-nav] click to the router */
  
  document.addEventListener('click', (e) => {
    const target = e.target.closest('[data-nav]');
  
    if (!target) return;
  
    e.preventDefault();
    navigate(target.getAttribute('data-nav'));
  });
  
  /* ==========================================================
     Nav bar (changes with session state)
     ========================================================== */
  
  function renderNav() {
    const nav = document.getElementById('main-nav');
    const session = getSession();
  
    let html = `<a href="#" data-nav="home">Home</a>`;
  
    if (!session) {
      html += `<a href="#" data-nav="student-auth">Student Login</a>`;
      html += `<a href="#" data-nav="company-auth">Company Login</a>`;
  
    } else if (session.type === 'student') {
      const s = loadList(DB_KEYS.students)
        .find(x => x.id === session.id);
  
      html += `<a href="#" data-nav="dashboard">Skill Dashboard</a>`;
      html += `<a href="#" data-nav="internships">Internships</a>`;
      html += `<span style="color:#A79A79;padding:8px 6px;">
        ${s ? s.name : ''}
      </span>`;
      html += `<button data-action="logout">Log out</button>`;
  
    } else if (session.type === 'company') {
      html += `<a href="#" data-nav="internships">Opportunities</a>`;
      html += `<span style="color:#A79A79;padding:8px 6px;">
        ${session.name || ''}
      </span>`;
      html += `<button data-action="logout">Log out</button>`;
    }
  
    nav.innerHTML = html;
  }
  
  document.addEventListener('click', (e) => {
    if (e.target.matches('[data-action="logout"]')) {
      setSession(null);
      showToast('Signed out.');
      navigate('home');
    }
  });
  
  const navToggle = document.getElementById('navToggle');
  
  navToggle.addEventListener('click', () => {
    document.getElementById('main-nav')
      .classList.toggle('is-open');
  });
  
  /* ==========================================================
     Auth: tabs (login / register)
     ========================================================== */
  
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const group = btn.closest('.wrap');
  
      group.querySelectorAll('.tab-btn')
        .forEach(b => b.classList.remove('is-active'));
  
      group.querySelectorAll('.panel-form')
        .forEach(p => p.classList.remove('is-active'));
  
      btn.classList.add('is-active');
  
      group.querySelector(
        `[data-panel="${btn.dataset.tab}"]`
      ).classList.add('is-active');
    });
  });
  
  /* ---------- Student register / login ---------- */
  
  document.getElementById('studentRegisterForm')
    .addEventListener('submit', (e) => {
  
      e.preventDefault();
  
      const f = e.target;
      const errorEl =
        document.getElementById('studentRegisterError');
  
      const email = f.email.value
        .trim()
        .toLowerCase();
  
      const students = loadList(DB_KEYS.students);
  
      if (students.some(s => s.email === email)) {
        errorEl.textContent =
          'An account with this email already exists.';
        return;
      }
  
      const student = {
        id: uid(),
        name: f.name.value.trim(),
        college: f.college.value.trim(),
        email,
        password: f.password.value,
        skills: [],
        certificates: [],
        projects: []
      };
  
      students.push(student);
      saveList(DB_KEYS.students, students);
  
      errorEl.textContent = '';
      f.reset();
  
      setSession({
        type: 'student',
        id: student.id
      });
  
      showToast(`Welcome, ${student.name}.`);
      navigate('dashboard');
    });
  
  document.getElementById('studentLoginForm')
    .addEventListener('submit', (e) => {
  
      e.preventDefault();
  
      const f = e.target;
      const errorEl =
        document.getElementById('studentLoginError');
  
      const email = f.email.value
        .trim()
        .toLowerCase();
  
      const student = loadList(DB_KEYS.students)
        .find(
          s =>
            s.email === email &&
            s.password === f.password.value
        );
  
      if (!student) {
        errorEl.textContent =
          'No matching account. Check your email and password.';
        return;
      }
  
      errorEl.textContent = '';
      f.reset();
  
      setSession({
        type: 'student',
        id: student.id
      });
  
      showToast(`Welcome back, ${student.name}.`);
      navigate('dashboard');
    });
  
  /* ---------- Company register / login ---------- */
  
  document.getElementById('companyRegisterForm')
    .addEventListener('submit', (e) => {
  
      e.preventDefault();
  
      const f = e.target;
  
      const errorEl =
        document.getElementById('companyRegisterError');
  
      const email = f.email.value
        .trim()
        .toLowerCase();
  
      const companies = loadList(DB_KEYS.companies);
  
      if (companies.some(c => c.email === email)) {
        errorEl.textContent =
          'An account with this email already exists.';
        return;
      }
  
      const company = {
        id: uid(),
        name: f.name.value.trim(),
        industry: f.industry.value.trim(),
        email,
        password: f.password.value
      };
  
      companies.push(company);
      saveList(DB_KEYS.companies, companies);
  
      errorEl.textContent = '';
      f.reset();
  
      setSession({
        type: 'company',
        id: company.id,
        name: company.name
      });
  
      showToast(`Welcome, ${company.name}.`);
      navigate('internships');
    });
  
  document.getElementById('companyLoginForm')
    .addEventListener('submit', (e) => {
  
      e.preventDefault();
  
      const f = e.target;
  
      const errorEl =
        document.getElementById('companyLoginError');
  
      const email = f.email.value
        .trim()
        .toLowerCase();
  
      const company = loadList(DB_KEYS.companies)
        .find(
          c =>
            c.email === email &&
            c.password === f.password.value
        );
  
      if (!company) {
        errorEl.textContent =
          'No matching account. Check your email and password.';
        return;
      }
  
      errorEl.textContent = '';
      f.reset();
  
      setSession({
        type: 'company',
        id: company.id,
        name: company.name
      });
  
      showToast(`Welcome back, ${company.name}.`);
      navigate('internships');
    });
  
  /* ==========================================================
     Skill Dashboard
     ========================================================== */
  
  function currentStudent() {
    const session = getSession();
  
    if (!session || session.type !== 'student') {
      return null;
    }
  
    const students = loadList(DB_KEYS.students);
  
    return students.find(
      s => s.id === session.id
    ) || null;
  }
  
  function saveStudent(updated) {
    const students = loadList(DB_KEYS.students);
  
    const idx = students.findIndex(
      s => s.id === updated.id
    );
  
    if (idx > -1) {
      students[idx] = updated;
      saveList(DB_KEYS.students, students);
    }
  }
  
  function renderDashboard() {
    const student = currentStudent();
  
    if (!student) return;
  
    document.getElementById('dashboardGreeting')
      .textContent = `${student.name}'s profile`;
  
    renderTagList(
      'skillList',
      student.skills,
      (i) => removeFromStudent('skills', i)
    );
  
    renderTagList(
      'certList',
      student.certificates,
      (i) => removeFromStudent('certificates', i)
    );
  
    renderTagList(
      'projectList',
      student.projects,
      (i) => removeFromStudent('projects', i)
    );
  
    renderMyApplications(student);
  }
  
  function renderTagList(elId, items, onRemove) {
    const el = document.getElementById(elId);
  
    if (!items.length) {
      el.innerHTML =
        `<li class="tag-empty">Nothing added yet.</li>`;
      return;
    }
  
    el.innerHTML = items.map((item, i) =>
      `<li>
        ${escapeHtml(item)}
        <button data-index="${i}" aria-label="Remove">
          &times;
        </button>
      </li>`
    ).join('');
  
    el.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('click', () =>
        onRemove(Number(btn.dataset.index))
      );
    });
  }
  
  function removeFromStudent(field, index) {
    const student = currentStudent();
  
    if (!student) return;
  
    student[field].splice(index, 1);
  
    saveStudent(student);
    renderDashboard();
  }
  
  ['skill', 'cert', 'project'].forEach(kind => {
  
    const fieldMap = {
      skill: 'skills',
      cert: 'certificates',
      project: 'projects'
    };
  
    document.getElementById(kind + 'Form')
      .addEventListener('submit', (e) => {
  
        e.preventDefault();
  
        const input =
          document.getElementById(kind + 'Input');
  
        const value = input.value.trim();
  
        if (!value) return;
  
        const student = currentStudent();
  
        if (!student) return;
  
        student[fieldMap[kind]].push(value);
  
        saveStudent(student);
  
        input.value = '';
  
        renderDashboard();
      });
  });
  
  function renderMyApplications(student) {
    const internships =
      loadList(DB_KEYS.internships);
  
    const applied = internships.filter(
      job => job.applicants.includes(student.id)
    );
  
    const el =
      document.getElementById('myApplications');
  
    if (!applied.length) {
      el.innerHTML =
        `<p class="empty-state">
          You haven't applied to anything yet.
          Browse
          <a href="#" data-nav="internships">
            open opportunities
          </a>.
        </p>`;
  
      return;
    }
  
    el.innerHTML = applied.map(job => `
      <div class="ledger-row">
        <h3>${escapeHtml(job.title)}</h3>
        <p>
          ${escapeHtml(job.companyName)}
          ·
          ${escapeHtml(job.type)}
        </p>
      </div>
    `).join('');
  }
  
  /* ==========================================================
     Internship & Placement
     ========================================================== */
  
  function renderInternships() {
    const session = getSession();
  
    const postForm =
      document.getElementById('postForm');
  
    const titleEl =
      document.getElementById('internshipsTitle');
  
    const isCompany =
      session && session.type === 'company';
  
    postForm.classList.toggle(
      'company-only',
      true
    );
  
    postForm.style.display =
      isCompany ? 'block' : 'none';
  
    titleEl.textContent = isCompany
      ? 'Your postings & candidates'
      : 'Open opportunities';
  
    const internships =
      loadList(DB_KEYS.internships);
  
    const list =
      document.getElementById('internshipList');
  
    const visible = isCompany
      ? internships.filter(
          job => job.companyId === session.id
        )
      : internships;
  
    if (!visible.length) {
      list.innerHTML =
        `<p class="empty-state">
          ${
            isCompany
              ? "You haven't posted an opportunity yet."
              : 'No opportunities are open right now — check back soon.'
          }
        </p>`;
  
      return;
    }
  
    const student =
      !isCompany ? currentStudent() : null;
  
    list.innerHTML = visible.map(job => {
  
      const skillsHtml = job.skills
        .map(
          s =>
            `<span class="skill-chip">
              ${escapeHtml(s)}
            </span>`
        )
        .join('');
  
      let sideHtml = '';
  
      if (isCompany) {
  
        sideHtml =
          `<span class="applicant-count">
            ${job.applicants.length}
            applicant${
              job.applicants.length === 1
                ? ''
                : 's'
            }
          </span>`;
  
      } else if (student) {
  
        const hasApplied =
          job.applicants.includes(student.id);
  
        sideHtml = hasApplied
          ? `<span class="applied-tag">Applied ✓</span>`
          : `<button
              class="btn btn-small"
              data-apply="${job.id}">
              Apply
            </button>`;
  
      } else {
  
        sideHtml =
          `<a
            href="#"
            class="btn btn-small"
            data-nav="student-auth">
            Log in to apply
          </a>`;
      }
  
      return `
        <div class="internship-row">
  
          <div class="internship-main">
  
            <h3>
              ${escapeHtml(job.title)}
            </h3>
  
            <p class="internship-meta">
              ${escapeHtml(job.companyName)}
              ·
              ${escapeHtml(job.type)}
            </p>
  
            <p class="internship-desc">
              ${escapeHtml(job.description)}
            </p>
  
            <div class="skill-chip-row">
              ${skillsHtml}
            </div>
  
          </div>
  
          <div class="internship-side">
            ${sideHtml}
          </div>
  
        </div>
      `;
    }).join('');
  
    list.querySelectorAll('[data-apply]')
      .forEach(btn => {
        btn.addEventListener('click', () =>
          applyToJob(
            btn.getAttribute('data-apply')
          )
        );
      });
  }
  
  function applyToJob(jobId) {
    const student = currentStudent();
  
    if (!student) return;
  
    const internships =
      loadList(DB_KEYS.internships);
  
    const job = internships.find(
      j => j.id === jobId
    );
  
    if (
      !job ||
      job.applicants.includes(student.id)
    ) {
      return;
    }
  
    job.applicants.push(student.id);
  
    saveList(
      DB_KEYS.internships,
      internships
    );
  
    showToast(`Applied to ${job.title}.`);
  
    renderInternships();
  }
  
  document.getElementById('postForm')
    .addEventListener('submit', (e) => {
  
      e.preventDefault();
  
      const session = getSession();
  
      if (
        !session ||
        session.type !== 'company'
      ) {
        return;
      }
  
      const f = e.target;
  
      const skills = f.skills.value
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);
  
      const internships =
        loadList(DB_KEYS.internships);
  
      internships.push({
        id: uid(),
        companyId: session.id,
        companyName: session.name,
        title: f.title.value.trim(),
        type: f.type.value,
        skills,
        description:
          f.description.value.trim(),
        applicants: []
      });
  
      saveList(
        DB_KEYS.internships,
        internships
      );
  
      f.reset();
  
      showToast('Opportunity posted.');
  
      renderInternships();
    });
  
  /* ==========================================================
     Small utilities
     ========================================================== */
  
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  
  let toastTimer = null;
  
  function showToast(message) {
  
    let toast =
      document.querySelector('.toast');
  
    if (!toast) {
      toast =
        document.createElement('div');
  
      toast.className = 'toast';
  
      document.body.appendChild(toast);
    }
  
    toast.textContent = message;
  
    toast.classList.add('is-visible');
  
    clearTimeout(toastTimer);
  
    toastTimer = setTimeout(
      () => toast.classList.remove('is-visible'),
      2600
    );
  }
  
  /* ==========================================================
     Init
     ========================================================== */
  
  seedIfEmpty();
  renderNav();
  navigate('home');