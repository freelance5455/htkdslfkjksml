const video = document.getElementById('webcam');
const canvas = document.getElementById('motion-canvas');
const ctx = canvas.getContext('2d', { willReadFrequently: true });

// Time-lapse canvas
const tlCanvas = document.getElementById('timelapse-canvas');
const tlCtx = tlCanvas.getContext('2d');

const startBtn = document.getElementById('start-cam-btn');
const nightBtn = document.getElementById('night-mode-btn');
const soundBtn = document.getElementById('sound-toggle-btn');

const recDot = document.getElementById('rec-dot');
const recStatus = document.getElementById('rec-status');
const liveClock = document.getElementById('live-clock');
const studyTimerEl = document.getElementById('study-timer');
const presenceStatus = document.getElementById('presence-status');
const alertCountEl = document.getElementById('alert-count');
const alertBanner = document.getElementById('alert-banner');
const liveActivityPill = document.getElementById('live-activity-pill');
const frameBadge = document.getElementById('frame-counter-badge');
const snapCountEl = document.getElementById('snap-count');
const nightOverlay = document.getElementById('night-vision-overlay');
const activityLog = document.getElementById('activity-log');

const summaryBox = document.getElementById('session-summary-box');
const summaryContent = document.getElementById('summary-content');
const tlGeneratingMsg = document.getElementById('tl-generating-msg');
const timelapseVideo = document.getElementById('timelapse-video');
const tlActions = document.getElementById('tl-actions');
const downloadTlBtn = document.getElementById('download-tl-btn');

let stream = null;
let isMonitoring = false;
let studySeconds = 0;
let awaySeconds = 0;
let totalSessionSeconds = 0;
let alertCount = 0;
let alarmEnabled = true;
let previousFrame = null;
let idleSeconds = 0;
let monitorInterval = null;
let timerInterval = null;
let snapshotInterval = null;

let sessionStartTime = "";
let timelineEvents = [];
let currentState = "NONE";
let capturedFrames = []; // Stores dataURLs of snapshots for time-lapse
let currentStatusLabel = "STUDYING";

// Live Clock
setInterval(() => {
    const now = new Date();
    liveClock.textContent = now.toTimeString().split(' ')[0];
}, 1000);

function getFormattedTime() {
    return new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function getEnglishTimestamp() {
    return new Date().toTimeString().split(' ')[0];
}

function formatDuration(sec) {
    const mins = Math.floor(sec / 60);
    const remSec = sec % 60;
    if (mins > 0) return `${mins} মিনিট ${remSec} সেকেন্ড`;
    return `${remSec} সেকেন্ড`;
}

// Add Log Entry
function addLog(msg, isWarn = false) {
    const li = document.createElement('li');
    const time = getFormattedTime();
    li.textContent = `[${time}] ${msg}`;
    if (isWarn) li.classList.add('warn');
    activityLog.prepend(li);
    timelineEvents.push({ time, msg, isWarn });
}

// Beep Sound
function playAlarmBeep() {
    if (!alarmEnabled) return;
    try {
        const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(880, audioCtx.currentTime);
        gainNode.gain.setValueAtTime(0.2, audioCtx.currentTime);
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.start();
        setTimeout(() => oscillator.stop(), 300);
    } catch (e) {}
}

// Capture a single frame with CCTV overlay for Time-Lapse
function captureTimelapseFrame() {
    if (video.readyState !== video.HAVE_ENOUGH_DATA) return;
    
    tlCanvas.width = 480;
    tlCanvas.height = 360;
    
    // Mirror horizontally like the live preview
    tlCtx.save();
    tlCtx.translate(tlCanvas.width, 0);
    tlCtx.scale(-1, 1);
    tlCtx.drawImage(video, 0, 0, tlCanvas.width, tlCanvas.height);
    tlCtx.restore();

    // Night vision tint if active
    if (!nightOverlay.classList.contains('hidden')) {
        tlCtx.fillStyle = "rgba(0, 255, 65, 0.25)";
        tlCtx.fillRect(0, 0, tlCanvas.width, tlCanvas.height);
    }

    // Add CCTV Timestamp & Status stamp onto the frame
    tlCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
    tlCtx.fillRect(0, 0, tlCanvas.width, 32);
    
    tlCtx.fillStyle = "#00ff41";
    tlCtx.font = "bold 14px monospace";
    tlCtx.fillText(`REC ● TIMELAPSE | ${getEnglishTimestamp()}`, 12, 21);

    // Bottom status bar on video
    tlCtx.fillStyle = "rgba(0, 0, 0, 0.65)";
    tlCtx.fillRect(0, tlCanvas.height - 28, tlCanvas.width, 28);
    tlCtx.fillStyle = currentStatusLabel === "AWAY / IDLE" ? "#ff5252" : "#00ff41";
    tlCtx.font = "bold 13px monospace";
    tlCtx.fillText(`STATUS: ${currentStatusLabel}`, 12, tlCanvas.height - 9);

    capturedFrames.push(tlCanvas.toDataURL('image/jpeg', 0.75));
    snapCountEl.textContent = capturedFrames.length;
}

// Compile captured frames into a playable Time-Lapse Video
async function buildTimelapseVideo() {
    if (capturedFrames.length < 2) {
        tlGeneratingMsg.textContent = "⚠️ টাইম-ল্যাপ্স তৈরির জন্য অন্তত ২ সেকেন্ড মনিটর চালু রাখুন।";
        return;
    }

    tlGeneratingMsg.classList.remove('hidden');
    tlGeneratingMsg.textContent = `⏳ ${capturedFrames.length}টি ফ্রেম দিয়ে টাইম-ল্যাপ্স ভিডিও তৈরি হচ্ছে...`;
    timelapseVideo.classList.add('hidden');
    tlActions.classList.add('hidden');

    const outCanvas = document.createElement('canvas');
    outCanvas.width = 480;
    outCanvas.height = 360;
    const outCtx = outCanvas.getContext('2d');

    // Stream at 8 FPS for smooth fast-motion time-lapse playback
    const streamOut = outCanvas.captureStream(8);
    let mimeType = 'video/webm';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = ''; // fallback to browser default
    }

    const recorder = mimeType ? new MediaRecorder(streamOut, { mimeType }) : new MediaRecorder(streamOut);
    const chunks = [];

    recorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) chunks.push(e.data);
    };

    recorder.onstop = () => {
        const blob = new Blob(chunks, { type: recorder.mimeType || 'video/webm' });
        const videoUrl = URL.createObjectURL(blob);
        timelapseVideo.src = videoUrl;
        downloadTlBtn.href = videoUrl;
        
        tlGeneratingMsg.classList.add('hidden');
        timelapseVideo.classList.remove('hidden');
        tlActions.classList.remove('hidden');
    };

    recorder.start();

    // Draw each captured snapshot sequentially into the recorder stream
    for (let i = 0; i < capturedFrames.length; i++) {
        await new Promise((resolve) => {
            const img = new Image();
            img.onload = () => {
                outCtx.drawImage(img, 0, 0, outCanvas.width, outCanvas.height);
                setTimeout(resolve, 125); // 125ms per frame = 8x speed time-lapse
            };
            img.src = capturedFrames[i];
        });
    }

    recorder.stop();
}

// Start / Stop Camera Monitoring
startBtn.addEventListener('click', async () => {
    if (!isMonitoring) {
        try {
            stream = await navigator.mediaDevices.getUserMedia({ 
                video: { facingMode: "user" }, 
                audio: false 
            });
            video.srcObject = stream;
            isMonitoring = true;
            
            // Reset session metrics
            studySeconds = 0;
            awaySeconds = 0;
            totalSessionSeconds = 0;
            alertCount = 0;
            idleSeconds = 0;
            timelineEvents = [];
            capturedFrames = [];
            currentState = "NONE";
            snapCountEl.textContent = "0";
            alertCountEl.textContent = "0";
            studyTimerEl.textContent = "00:00:00";
            summaryBox.classList.add('hidden');
            activityLog.innerHTML = "";
            
            sessionStartTime = getFormattedTime();
            startBtn.textContent = "⏹ STOP MONITOR";
            startBtn.classList.add('stop');
            recDot.classList.add('active');
            recStatus.textContent = "REC ● LIVE";
            presenceStatus.textContent = "চলছে...";
            presenceStatus.style.color = "#00ff41";
            liveActivityPill.textContent = "ক্যামেরা চালু হয়েছে...";
            frameBadge.classList.remove('hidden');
            
            addLog("মনিটরিং শুরু হয়েছে। টাইম-ল্যাপ্স রেকর্ডিং চলছে।");
            startTracking();
        } catch (err) {
            alert("ক্যামেরা পারমিশন পাওয়া যায়নি! অনুগ্রহ করে ক্যামেরা Allow করুন।");
            addLog("ত্রুটি: ক্যামেরা চালু করা যায়নি।", true);
        }
    } else {
        stopMonitoring();
    }
});

function stopMonitoring() {
    isMonitoring = false;
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
    clearInterval(monitorInterval);
    clearInterval(timerInterval);
    clearInterval(snapshotInterval);
    
    const sessionEndTime = getFormattedTime();
    addLog("মনিটরিং বন্ধ করা হয়েছে। টাইম-ল্যাপ্স ভিডিও প্রস্তুত করা হচ্ছে...");

    startBtn.textContent = "▶ START MONITOR";
    startBtn.classList.remove('stop');
    recDot.classList.remove('active');
    recStatus.textContent = "STANDBY";
    presenceStatus.textContent = "বন্ধ আছে";
    presenceStatus.style.color = "#aaa";
    liveActivityPill.textContent = "সেশন সমাপ্ত";
    frameBadge.classList.add('hidden');
    alertBanner.classList.add('hidden');

    // Show Summary Card & Generate Time-Lapse Video
    generateSessionPreview(sessionStartTime, sessionEndTime);
    buildTimelapseVideo();
}

// Generate Human-Readable Preview Report on Stop
function generateSessionPreview(startTime, endTime) {
    let focusPercent = 100;
    if (totalSessionSeconds > 0) {
        focusPercent = Math.round((studySeconds / totalSessionSeconds) * 100);
    }

    let behaviorComment = "";
    if (focusPercent >= 85 && alertCount === 0) {
        behaviorComment = "🌟 চমৎকার! স্টুডেন্ট পুরো সময়টা অত্যন্ত মনোযোগ দিয়ে পড়াশোনা করেছে।";
    } else if (focusPercent >= 60) {
        behaviorComment = "👍 মোটামুটি ভালো পড়েছে, তবে মাঝে মাঝে একটু অমনোযোগী হয়েছিল।";
    } else {
        behaviorComment = "⚠️ সতর্কতা: স্টুডেন্ট পড়াশোনায় কম সময় দিয়েছে এবং বারবার টেবিল ছেড়েছে বা নড়াচড়া করেনি।";
    }

    let eventsHtml = timelineEvents.map(ev => 
        `<div style="color: ${ev.isWarn ? '#ff7b72' : '#8b949e'};">• <b>${ev.time}:</b> ${ev.msg}</div>`
    ).join('');

    summaryContent.innerHTML = `
        <p>🕒 <b>সময়কাল:</b> ${startTime} থেকে ${endTime}</p>
        <p>📖 <b>মনোযোগ দিয়ে পড়েছে:</b> <span style="color:#00ff41; font-weight:bold;">${formatDuration(studySeconds)}</span></p>
        <p>🚶 <b>অমনোযোগী / টেবিলের বাইরে ছিল:</b> <span style="color:#ff7b72; font-weight:bold;">${formatDuration(awaySeconds)}</span></p>
        <p>🎯 <b>ফোকাস স্কোর:</b> ${focusPercent}% (মোট অ্যালার্ট: ${alertCount} বার)</p>
        <p style="margin-top:8px; color:#fff; background:#21262d; padding:6px 8px; border-radius:4px;">${behaviorComment}</p>
        <div class="summary-timeline">
            <div style="color:#fff; font-weight:bold; margin-bottom:4px;">সেশন চলাকালীন যা যা করেছে:</div>
            ${eventsHtml}
        </div>
    `;

    summaryBox.classList.remove('hidden');
}

// Motion & Behavior Detection Loop
function startTracking() {
    // Capture first frame right after video starts
    setTimeout(captureTimelapseFrame, 500);
    
    // Capture 1 snapshot every 1 second for Time-Lapse video
    snapshotInterval = setInterval(() => {
        captureTimelapseFrame();
    }, 1000);

    timerInterval = setInterval(() => {
        totalSessionSeconds++;
        if (idleSeconds < 7) {
            studySeconds++;
            const hrs = String(Math.floor(studySeconds / 3600)).padStart(2, '0');
            const mins = String(Math.floor((studySeconds % 3600) / 60)).padStart(2, '0');
            const secs = String(studySeconds % 60).padStart(2, '0');
            studyTimerEl.textContent = `${hrs}:${mins}:${secs}`;
        } else {
            awaySeconds++;
        }
    }, 1000);

    monitorInterval = setInterval(() => {
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width = 64;
            canvas.height = 48;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const currentFrame = ctx.getImageData(0, 0, canvas.width, canvas.height).data;

            if (previousFrame) {
                let diffPixels = 0;
                for (let i = 0; i < currentFrame.length; i += 4) {
                    const rDiff = Math.abs(currentFrame[i] - previousFrame[i]);
                    const gDiff = Math.abs(currentFrame[i+1] - previousFrame[i+1]);
                    const bDiff = Math.abs(currentFrame[i+2] - previousFrame[i+2]);
                    if (rDiff + gDiff + bDiff > 60) {
                        diffPixels++;
                    }
                }

                if (diffPixels < 15) {
                    idleSeconds++;
                    if (idleSeconds >= 7) {
                        currentStatusLabel = "AWAY / IDLE";
                        presenceStatus.textContent = "টেবিলে নেই!";
                        presenceStatus.style.color = "#ff3b30";
                        liveActivityPill.textContent = "⚠️ নিষ্ক্রিয় / টেবিল ছেড়েছে";
                        liveActivityPill.style.borderColor = "#ff3b30";
                        liveActivityPill.style.color = "#ff3b30";
                        alertBanner.classList.remove('hidden');
                        
                        if (currentState !== "IDLE") {
                            currentState = "IDLE";
                            alertCount++;
                            alertCountEl.textContent = alertCount;
                            addLog("স্টুডেন্ট টেবিল ছেড়ে চলে গেছে অথবা একদম স্থির হয়ে আছে!", true);
                        }
                        playAlarmBeep();
                    }
                } else if (diffPixels > 450) {
                    if (idleSeconds >= 7) {
                        addLog("স্টুডেন্ট আবার পড়ার টেবিলে ফিরে এসেছে।");
                    }
                    idleSeconds = 0;
                    currentStatusLabel = "RESTLESS / MOVING";
                    presenceStatus.textContent = "বেশি নড়াচড়া";
                    presenceStatus.style.color = "#ffab00";
                    liveActivityPill.textContent = "👀 বেশি নড়াচড়া করছে";
                    liveActivityPill.style.borderColor = "#ffab00";
                    liveActivityPill.style.color = "#ffab00";
                    alertBanner.classList.add('hidden');

                    if (currentState !== "RESTLESS") {
                        currentState = "RESTLESS";
                        addLog("স্টুডেন্ট টেবিলে বেশ নড়াচড়া করছে (খাতা/বই নাড়াচাড়া বা উঠে দাঁড়ানো)।");
                    }
                } else {
                    if (idleSeconds >= 7) {
                        addLog("স্টুডেন্ট আবার পড়ার টেবিলে ফিরে এসেছে।");
                    }
                    idleSeconds = 0;
                    currentStatusLabel = "STUDYING";
                    presenceStatus.textContent = "পড়াশোনা করছে";
                    presenceStatus.style.color = "#00ff41";
                    liveActivityPill.textContent = "✍️ মনোযোগ দিয়ে পড়ছে/লিখছে";
                    liveActivityPill.style.borderColor = "#00ff41";
                    liveActivityPill.style.color = "#00ff41";
                    alertBanner.classList.add('hidden');

                    if (currentState !== "STUDY") {
                        currentState = "STUDY";
                        addLog("স্টুডেন্ট স্থির হয়ে মনোযোগ দিয়ে পড়াশোনা করছে।");
                    }
                }
            }
            previousFrame = currentFrame;
        }
    }, 1000);
}

// Night Vision Toggle
nightBtn.addEventListener('click', () => {
    nightOverlay.classList.toggle('hidden');
    const isNight = !nightOverlay.classList.contains('hidden');
    nightBtn.textContent = isNight ? "☀️ NORMAL" : "🌙 NIGHT";
    addLog(isNight ? "নাইট ভিশন মোড চালু করা হয়েছে।" : "নরমাল ভিউ চালু করা হয়েছে।");
});

// Sound Alarm Toggle
soundBtn.addEventListener('click', () => {
    alarmEnabled = !alarmEnabled;
    soundBtn.textContent = alarmEnabled ? "🔊 ALARM: ON" : "🔇 ALARM: OFF";
});
