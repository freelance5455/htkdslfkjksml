const products=[
{id:1,name:"Wireless Headphones",cat:"Electronics",price:1499,emoji:"🎧"},
{id:2,name:"Smart Watch Pro",cat:"Electronics",price:2299,emoji:"⌚"},
{id:3,name:"Streetwear Hoodie",cat:"Fashion",price:999,emoji:"👕"},
{id:4,name:"Running Sneakers",cat:"Fashion",price:1799,emoji:"👟"},
{id:5,name:"Gaming Controller",cat:"Gaming",price:1599,emoji:"🎮"},
{id:6,name:"RGB Gaming Keyboard",cat:"Gaming",price:1299,emoji:"⌨️"},
{id:7,name:"Modern Table Lamp",cat:"Home",price:699,emoji:"💡"},
{id:8,name:"Coffee Maker",cat:"Home",price:2499,emoji:"☕"}
];
let cart=JSON.parse(localStorage.getItem("shopx-cart")||"[]");
let wishlist=JSON.parse(localStorage.getItem("shopx-wishlist")||"[]");
let category="All";

function money(n){return "₹"+n.toLocaleString("en-IN")}
function renderProducts(){
 const q=document.getElementById("searchInput").value.toLowerCase();
 let list=products.filter(p=>(category==="All"||p.cat===category)&&p.name.toLowerCase().includes(q));
 const sort=document.getElementById("sortSelect").value;
 if(sort==="low")list.sort((a,b)=>a.price-b.price); if(sort==="high")list.sort((a,b)=>b.price-a.price);
 document.getElementById("products").innerHTML=list.length?list.map(p=>`
 <article class="product">
  <button class="wish" onclick="toggleWish(${p.id})">${wishlist.includes(p.id)?"♥":"♡"}</button>
  <div class="pic" onclick="productDetails(${p.id})">${p.emoji}</div>
  <div class="cat">${p.cat}</div><h3>${p.name}</h3>
  <div class="bottom"><span class="price">${money(p.price)}</span><button class="add" onclick="addCart(${p.id})">Add</button></div>
 </article>`).join(""):`<div class="empty" style="grid-column:1/-1">No products found.</div>`;
 updateCount();
}
function filterCategory(c,btn){category=c;document.querySelectorAll(".nav button").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts()}
function addCart(id){cart.push(id);localStorage.setItem("shopx-cart",JSON.stringify(cart));updateCount();openCart()}
function updateCount(){document.getElementById("cartCount").textContent=cart.length}
function toggleWish(id){wishlist=wishlist.includes(id)?wishlist.filter(x=>x!==id):[...wishlist,id];localStorage.setItem("shopx-wishlist",JSON.stringify(wishlist));renderProducts()}
function showWishlist(){const items=products.filter(p=>wishlist.includes(p.id));openModal(`<h2>♡ Wishlist</h2>${items.length?items.map(p=>`<div class="cart-item"><span>${p.emoji} ${p.name}</span><b>${money(p.price)}</b></div>`).join(""):"<div class='empty'>Your wishlist is empty.</div>"}`)}
function openCart(){
 const counts={};cart.forEach(id=>counts[id]=(counts[id]||0)+1);
 const ids=Object.keys(counts).map(Number);let total=0;
 let body=ids.length?ids.map(id=>{const p=products.find(x=>x.id===id),qty=counts[id];total+=p.price*qty;return `<div class="cart-item"><span>${p.emoji} ${p.name} × ${qty}</span><b>${money(p.price*qty)}</b></div>`}).join(""):"<div class='empty'>Your cart is empty.</div>";
 openModal(`<h2>🛒 Your Cart</h2>${body}${ids.length?`<h3 style="margin-top:20px">Total: ${money(total)}</h3><button class="checkout" onclick="checkout()">Proceed to Checkout</button>`:""}`)
}
function productDetails(id){const p=products.find(x=>x.id===id);openModal(`<div style="text-align:center;font-size:90px">${p.emoji}</div><p class="eyebrow">${p.cat}</p><h2>${p.name}</h2><p style="margin:12px 0;color:#666">A quality ShopX pick, ready to add to your cart.</p><h2>${money(p.price)}</h2><button class="checkout" onclick="closeModal();addCart(${p.id})">Add to Cart</button>`)}
function checkout(){openModal(`<h2>Checkout</h2><p style="margin:15px 0;color:#666">Demo checkout — connect your payment gateway and backend to accept real orders.</p><input placeholder="Full name" style="width:100%;padding:12px;margin:6px 0;border:1px solid #ddd;border-radius:8px"><input placeholder="Delivery address" style="width:100%;padding:12px;margin:6px 0;border:1px solid #ddd;border-radius:8px"><button class="checkout" onclick="alert('Demo order placed!');cart=[];localStorage.setItem('shopx-cart','[]');closeModal();updateCount()">Place Demo Order</button>`)}
function openModal(content){document.getElementById("modalContent").innerHTML=content;document.getElementById("modal").classList.remove("hidden")}
function closeModal(){document.getElementById("modal").classList.add("hidden")}
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
renderProducts();
