"use strict";

/* Afghanistan Explorer
   Data sources:
   - Administrative divisions: open-admin-data / Afghanistan
   - Villages: matiullah-karimi / Afghanistan villages JSON
   Internet connection is required for live administrative datasets.
*/

const DATA_URLS = {
  admin: "https://raw.githubusercontent.com/matiullah-karimi/afghanistan-provinces-districts-villages-json/master/provinces-and-districts.json",
  villages: "https://raw.githubusercontent.com/matiullah-karimi/afghanistan-provinces-districts-villages-json/master/villages.json"
};

const provinceFallback = [
  ["بدخشان","Badakhshan","فیض‌آباد","شمال‌شرق"],["بادغیس","Badghis","قلعه‌نو","غرب"],
  ["بغلان","Baghlan","پلخمری","شمال‌شرق"],["بلخ","Balkh","مزارشریف","شمال"],
  ["بامیان","Bamyan","بامیان","مرکز"],["دایکندی","Daykundi","نیلی","مرکز"],
  ["فراه","Farah","فراه","غرب"],["فاریاب","Faryab","میمنه","شمال"],
  ["غزنی","Ghazni","غزنی","جنوب‌شرق"],["غور","Ghor","فیروزکوه","مرکز"],
  ["هلمند","Helmand","لشکرگاه","جنوب"],["هرات","Hirat","هرات","غرب"],
  ["جوزجان","Jawzjan","شبرغان","شمال"],["کابل","Kabul","کابل","مرکز"],
  ["کندهار","Kandahar","کندهار","جنوب"],["کاپیسا","Kapisa","محمودراقی","مرکز"],
  ["خوست","Khost","خوست","جنوب‌شرق"],["کنر","Kunar","اسعدآباد","شرق"],
  ["کندز","Kunduz","کندز","شمال‌شرق"],["لغمان","Laghman","مهترلام","شرق"],
  ["لوگر","Logar","پل‌علم","مرکز"],["ننگرهار","Nangarhar","جلال‌آباد","شرق"],
  ["نیمروز","Nimroz","زرنج","غرب"],["نورستان","Nuristan","پارون","شرق"],
  ["پکتیا","Paktya","گردیز","جنوب‌شرق"],["پکتیکا","Paktika","شرنه","جنوب‌شرق"],
  ["پنجشیر","Panjsher","بازارک","شمال‌شرق"],["پروان","Parwan","چاریکار","مرکز"],
  ["سمنگان","Samangan","ایبک","شمال"],["سرپل","Sar-e-Pul","سرپل","شمال"],
  ["تخار","Takhar","تالقان","شمال‌شرق"],["ارزگان","Uruzgan","ترینکوت","جنوب"],
  ["میدان وردک","Maidan Wardak","میدان‌شهر","مرکز"],["زابل","Zabul","قلات","جنوب"]
];

const $ = (id) => document.getElementById(id);
const state = {
  provinces: provinceFallback.map((p, i) => ({
    id: String(i + 1), local: p[0], en: p[1], capital: p[2], region: p[3],
    lat: "", lon: "", districts: [], sourceDistrictCount: 0
  })),
  villages: [],
  selectedProvince: null,
  selectedDistrict: null,
  villageMatches: [],
  villagePage: 1,
  villagePageSize: 25,
  adminLoaded: false,
  villagesLoaded: false
};

const regionByProvince = Object.fromEntries(provinceFallback.map(p => [normalize(p[1]), p[3]]));

function normalize(value) {
  return String(value ?? "").toLocaleLowerCase("en").normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\u0600-\u06FF]/g, "");
}
function faNumber(value) {
  return Number(value || 0).toLocaleString("fa-AF");
}
function safeText(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  })[ch]);
}
function showToast(message) {
  const toast = $("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 3600);
}
function setTheme(theme) {
  document.documentElement.dataset.theme = theme;
  localStorage.setItem("afg-explorer-theme", theme);
  $("themeToggle").textContent = theme === "dark" ? "☀" : "☾";
}
function initTheme() {
  let saved = "light";
  try { saved = localStorage.getItem("afg-explorer-theme") || "light"; } catch (_) {}
  setTheme(saved);
}

function renderProvinces() {
  const query = normalize($("provinceSearch").value);
  const region = $("regionFilter").value;
  const list = state.provinces.filter(p =>
    (!query || normalize(p.local).includes(query) || normalize(p.en).includes(query)) &&
    (!region || p.region === region)
  );
  $("provinceCount").textContent = faNumber(list.length);
  $("provinceEmpty").classList.toggle("hidden", list.length !== 0);
  $("provinceGrid").innerHTML = list.map((p, index) => `
    <button class="province-card ${state.selectedProvince?.id === p.id ? "selected" : ""}" data-province-id="${safeText(p.id)}" type="button">
      <div class="province-card-top"><span class="province-symbol">${["⌖","✧","⌂","◇"][index % 4]}</span><small>${safeText(p.region || "افغانستان")}</small></div>
      <h3>${safeText(p.local)}</h3><p>${safeText(p.en)}</p>
    </button>`).join("");
  document.querySelectorAll("[data-province-id]").forEach(button => {
    button.addEventListener("click", () => selectProvince(button.dataset.provinceId));
  });
}

function renderProvinceDetail(p) {
  $("detailName").textContent = p ? p.local : "یک ولایت را انتخاب کنید";
  $("detailEnglish").textContent = p ? p.en : "Select a province";
  $("detailCapital").textContent = p?.capital || "در منبع فعلی ثبت نشده";
  $("detailRegion").textContent = p?.region || "ثبت نشده";
  $("detailCoords").textContent = p?.lat && p?.lon ? `${p.lat}, ${p.lon}` : "ثبت نشده";
  $("detailDistrictCount").textContent = p ? faNumber(p.districts.length || p.sourceDistrictCount) : "—";
  $("detailDescription").textContent = p
    ? `ولایت ${p.local} با مرکز ${p.capital || "ثبت‌نشده"} در منطقه ${p.region || "نامشخص"} افغانستان قرار دارد. معلومات ولسوالی‌ها از مجموعه‌داده باز دریافت شده است. درباره تاریخ محلی، آب‌وهوا و نفوس تنها داده‌هایی باید افزوده شود که منبع و سال نشر آن روشن باشد.`
    : "برای دیدن معلومات، یکی از ولایت‌ها را از فهرست انتخاب کنید.";
  $("detailTags").innerHTML = p ? `<span>${safeText(p.region)}</span><span>افغانستان</span><span>معلومات اداری</span>` : "";
}

function renderDistricts(list) {
  const query = normalize($("districtSearch").value);
  const filtered = list.filter(d => !query || normalize(d.local).includes(query) || normalize(d.en).includes(query));
  $("districtBadge").textContent = `${faNumber(filtered.length)} ولسوالی`;
  $("districtList").innerHTML = filtered.length ? filtered.map(d => `
    <button class="district-item ${state.selectedDistrict?.id === d.id ? "selected" : ""}" type="button" data-district-id="${safeText(d.id)}">
      <span>${safeText(d.local || d.en)}</span><small>${safeText(d.en || "")}</small>
    </button>`).join("") : `<div class="placeholder">ولسوالی پیدا نشد یا معلومات آن در منبع موجود نیست.</div>`;
  document.querySelectorAll("[data-district-id]").forEach(button => {
    button.addEventListener("click", () => selectDistrict(button.dataset.districtId));
  });
}

function selectProvince(id) {
  const p = state.provinces.find(item => item.id === String(id));
  if (!p) return;
  state.selectedProvince = p;
  state.selectedDistrict = null;
  $("districtSearch").value = "";
  $("districtSearch").disabled = false;
  $("villageSearch").value = "";
  $("villageSearch").disabled = true;
  $("villageList").innerHTML = `<div class="placeholder">برای نمایش قریه‌ها، یک ولسوالی را انتخاب کنید.</div>`;
  $("villageBadge").textContent = "انتخاب ولسوالی";
  $("villagePagination").innerHTML = "";
  renderProvinceDetail(p);
  renderDistricts(p.districts);
  renderProvinces();
  $("provinceDetail").scrollIntoView({ behavior: "smooth", block: "start" });
  if (!state.villagesLoaded) loadVillages();
}

function selectDistrict(id) {
  const d = state.selectedProvince?.districts.find(item => item.id === String(id));
  if (!d) return;
  state.selectedDistrict = d;
  $("villageSearch").disabled = false;
  $("villageSearch").value = "";
  state.villagePage = 1;
  document.querySelectorAll(".district-item").forEach(el => el.classList.toggle("selected", el.dataset.districtId === String(id)));
  renderVillages();
  $("villageBadge").textContent = d.local || d.en;
}

function provinceAliases(p) {
  const aliases = [p.en, p.local];
  const map = {
    "Hirat":["Herat","Hirat"],"Jawzjan":["Jowzjan","Jawzjan"],"Uruzgan":["Urozgan","Uruzgan"],
    "Panjsher":["Panjshir","Panjsher"],"Paktya":["Paktia","Paktya"],"Maidan Wardak":["Wardak","Maidan Wardak"],
    "Sar-e-Pul":["Sari Pul","Sar-e-Pul"],"Helmand":["Hilmand","Helmand"],"Kunar":["Kunarha","Kunar"]
  };
  return aliases.concat(map[p.en] || []).map(normalize);
}
function villageProvinceMatches(v, p) {
  const key = normalize(v.Province || v.province || "");
  return provinceAliases(p).some(alias => alias === key || alias.includes(key) || key.includes(alias));
}
function villageDistrictMatches(v, d) {
  const key = normalize(v.District || v.district || "");
  const aliases = [d.en, d.local].map(normalize);
  const extras = {
    "Tarin Kowt":["Tirin Kot","Tarinkot"],"Faizabad":["Fayzabad","Faiz Abad"],
    "Kishim":["Kishim","Keshim"],"Yamgan":["Yamgan (Girwan)"]
  };
  (extras[d.en] || []).forEach(x => aliases.push(normalize(x)));
  return aliases.some(alias => alias === key || (alias.length > 3 && key.includes(alias)) || (key.length > 3 && alias.includes(key)));
}

function renderVillages() {
  if (!state.selectedProvince || !state.selectedDistrict) return;
  const q = normalize($("villageSearch").value);
  state.villageMatches = state.villages.filter(v =>
    villageProvinceMatches(v, state.selectedProvince) &&
    villageDistrictMatches(v, state.selectedDistrict) &&
    (!q || normalize(v["Village Name"] || v.name || "").includes(q))
  );
  state.villagePageSize = Number($("villagePageSize").value) || 25;
  const total = state.villageMatches.length;
  const pages = Math.max(1, Math.ceil(total / state.villagePageSize));
  state.villagePage = Math.min(state.villagePage, pages);
  const start = (state.villagePage - 1) * state.villagePageSize;
  const pageItems = state.villageMatches.slice(start, start + state.villagePageSize);
  $("villageBadge").textContent = `${faNumber(total)} قریه در این منبع`;
  $("villageList").innerHTML = pageItems.length ? pageItems.map(v => `
    <article class="village-item"><b>${safeText(v["Village Name"] || "نام ثبت نشده")}</b>
    <span>${safeText(v.Latitude ?? "—")} , ${safeText(v.Longitude ?? "—")}</span></article>`).join("")
    : `<div class="placeholder">${state.villagesLoaded ? "در این مجموعه‌داده برای این ولسوالی قریه‌ای پیدا نشد. این به معنی نبودن قریه در واقعیت نیست." : "در حال دریافت معلومات قریه‌ها..."}</div>`;
  $("villagePagination").innerHTML = total ? `
    <button type="button" id="prevVillage" ${state.villagePage <= 1 ? "disabled" : ""}>قبلی</button>
    <span>صفحه ${faNumber(state.villagePage)} از ${faNumber(pages)} — مجموع ${faNumber(total)}</span>
    <button type="button" id="nextVillage" ${state.villagePage >= pages ? "disabled" : ""}>بعدی</button>` : "";
  $("prevVillage")?.addEventListener("click", () => { state.villagePage--; renderVillages(); });
  $("nextVillage")?.addEventListener("click", () => { state.villagePage++; renderVillages(); });
}

async function fetchJSON(url) {
  const response = await fetch(url, { cache: "force-cache" });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

async function loadAdminData() {
  try {
    const raw = await fetchJSON(DATA_URLS.admin);
    if (!Array.isArray(raw) || !raw.length) throw new Error("ساختار داده اداری معتبر نیست");
    const byEnglish = new Map(state.provinces.map(p => [normalize(p.en), p]));
    const adminAliases = {
      "urozgan": "Uruzgan",
      "panjshir": "Panjsher",
      "wardak": "Maidan Wardak",
      "jowzjan": "Jawzjan",
      "herat": "Hirat",
      "hilmand": "Helmand",
      "sari pul": "Sar-e-Pul",
      "sar e pul": "Sar-e-Pul",
      "paktia": "Paktya"
    };
    raw.forEach(record => {
      const rawName = String(record.name || "");
      const aliasName = adminAliases[rawName.toLowerCase()] || rawName;
      const p = byEnglish.get(normalize(aliasName));
      if (!p) return;
      p.id = String(record.id);
      p.local = record.nameFa || p.local;
      p.lat = record.latitude || "";
      p.lon = record.longitude || "";
      p.districts = Array.isArray(record.districts) ? record.districts.map(d => ({
        id: String(d.id), local: d.nameFa || d.name, en: d.name || "",
        lat: d.latitude || "", lon: d.longitude || ""
      })) : [];
      p.sourceDistrictCount = p.districts.length;
    });
    state.adminLoaded = true;
    $("districtStat").textContent = faNumber(state.provinces.reduce((n,p) => n + p.districts.length, 0));
    renderProvinces();
    if (state.selectedProvince) {
      const updated = state.provinces.find(p => p.id === state.selectedProvince.id) || state.selectedProvince;
      state.selectedProvince = updated;
      renderProvinceDetail(updated);
      renderDistricts(updated.districts);
    }
  } catch (error) {
    console.warn("Admin data could not be loaded:", error);
    showToast("دریافت معلومات ولسوالی‌ها ناموفق بود؛ اتصال انترنت را بررسی کنید.");
    $("districtStat").textContent = "—";
  }
}

async function loadVillages() {
  if (state.villagesLoaded) return;
  $("villageList").innerHTML = `<div class="placeholder">در حال دریافت فهرست قریه‌ها از منبع باز...</div>`;
  try {
    const data = await fetchJSON(DATA_URLS.villages);
    if (!Array.isArray(data)) throw new Error("ساختار فهرست قریه‌ها درست نیست");
    state.villages = data;
    state.villagesLoaded = true;
    $("villageStat").textContent = faNumber(data.length);
    if (state.selectedDistrict) renderVillages();
    showToast(`معلومات ${faNumber(data.length)} قریه از منبع بارگذاری شد.`);
  } catch (error) {
    console.warn("Village data could not be loaded:", error);
    $("villageList").innerHTML = `<div class="placeholder">بارگذاری قریه‌ها ناموفق شد. انترنت و دسترسی به GitHub را بررسی کنید؛ سپس صفحه را دوباره باز کنید.</div>`;
    showToast("فهرست قریه‌ها بارگذاری نشد.");
  }
}

function initEvents() {
  $("provinceSearch").addEventListener("input", renderProvinces);
  $("regionFilter").addEventListener("change", renderProvinces);
  $("districtSearch").addEventListener("input", () => {
    if (state.selectedProvince) renderDistricts(state.selectedProvince.districts);
  });
  $("villageSearch").addEventListener("input", () => { state.villagePage = 1; renderVillages(); });
  $("villagePageSize").addEventListener("change", () => { state.villagePage = 1; renderVillages(); });
  $("clearProvince").addEventListener("click", () => {
    state.selectedProvince = null; state.selectedDistrict = null;
    $("districtSearch").value = ""; $("districtSearch").disabled = true;
    $("villageSearch").value = ""; $("villageSearch").disabled = true;
    $("districtList").innerHTML = `<div class="placeholder">ولایت مورد نظر را انتخاب کنید.</div>`;
    $("districtBadge").textContent = "ابتدا ولایت را انتخاب کنید";
    $("villageList").innerHTML = `<div class="placeholder">برای نمایش قریه‌ها، یک ولسوالی را انتخاب کنید.</div>`;
    $("villageBadge").textContent = "انتخاب ولسوالی"; $("villagePagination").innerHTML = "";
    renderProvinceDetail(null); renderProvinces();
  });
  $("themeToggle").addEventListener("click", () => setTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark"));
  $("menuToggle").addEventListener("click", () => $("mainNav").classList.toggle("open"));
  $("mainNav").querySelectorAll("a").forEach(a => a.addEventListener("click", () => $("mainNav").classList.remove("open")));
}

function init() {
  initTheme();
  initEvents();
  renderProvinces();
  renderProvinceDetail(null);
  loadAdminData();
}
document.addEventListener("DOMContentLoaded", init);
