const $ = id => document.getElementById(id);
const LAT = 48.7325, LON = 11.1872;
const api = `https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=temperature_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability,snowfall,snow_depth,weather_code&daily=temperature_2m_min,temperature_2m_max,snowfall_sum,precipitation_probability_max&forecast_days=7&timezone=Europe%2FBerlin`;
const weatherNames = {0:"Klarer Himmel",1:"Überwiegend klar",2:"Teilweise bewölkt",3:"Bedeckt",45:"Nebel",48:"Reifnebel",51:"Leichter Nieselregen",53:"Nieselregen",55:"Starker Nieselregen",61:"Leichter Regen",63:"Regen",65:"Starker Regen",71:"Leichter Schneefall",73:"Schneefall",75:"Starker Schneefall",77:"Schneegriesel",80:"Regenschauer",81:"Regenschauer",82:"Starke Regenschauer",85:"Leichte Schneeschauer",86:"Starke Schneeschauer",95:"Gewitter"};
function tick(){
 const now=new Date();
 $("clock").textContent=now.toLocaleTimeString("de-DE");
 $("date").textContent=now.toLocaleDateString("de-DE",{weekday:"short",day:"2-digit",month:"2-digit",year:"numeric"});
 let target=new Date(now.getFullYear(),11,24,0,0,0);
 if(now>=target) target=new Date(now.getFullYear()+1,11,24,0,0,0);
 let ms=target-now, days=Math.floor(ms/86400000);ms%=86400000;
 const h=String(Math.floor(ms/3600000)).padStart(2,"0");ms%=3600000;
 const m=String(Math.floor(ms/60000)).padStart(2,"0");const s=String(Math.floor(ms%60000/1000)).padStart(2,"0");
 $("christmasCountdown").textContent=`${days}T ${h}:${m}:${s}`;
}
function iconFor(code){if([71,73,75,77,85,86].includes(code))return "❄";if([61,63,65,80,81,82].includes(code))return "🌧";if([1,2,3,45,48].includes(code))return "☁";if(code===0)return "☀";if(code>=95)return "⛈";return "🌨";}
function setWarning(temp,code,wind){
 let title="Alles ruhig",msg="Aktuell keine besonderen Frost- oder Glättehinweise aus dieser Prognose.";
 if(temp<=0 || [71,73,75,77,85,86].includes(code)){title="Achtung: Frost möglich";msg="Bei Temperaturen um oder unter 0 °C kann es örtlich glatt werden. Bitte vorsichtig unterwegs sein.";}
 if(wind>=45){title="Windhinweis";msg="Erhöhte Windgeschwindigkeiten möglich. Aktuelle lokale Warnungen beachten.";}
 $("warningTitle").textContent=title;$("warningText").textContent=msg;
}
async function loadWeather(){
 $("status").textContent="• Lade Wetter …";
 try{
  const r=await fetch(api);if(!r.ok)throw new Error("Wetterdienst nicht erreichbar");
  const d=await r.json(),c=d.current,h=d.hourly;
  const temp=Math.round(c.temperature_2m), feels=Math.round(c.apparent_temperature), code=c.weather_code;
  $("temperature").textContent=`${temp}°C`;$("feels").textContent=`${feels}°C`;
  $("condition").textContent=weatherNames[code]||"Aktuelle Wetterlage";
  $("weatherIcon").textContent=iconFor(code);
  const now=new Date();let idx=0,best=Infinity;
  h.time.forEach((t,i)=>{const diff=Math.abs(new Date(t)-now);if(diff<best){best=diff;idx=i;}});
  const chance=Number(h.precipitation_probability?.[idx]??0);
  const snow=Number(h.snowfall?.[idx]??0);
  const snowChance=(snow>0 || [71,73,75,77,85,86].includes(code))?chance:0;
  $("snowChance").textContent=`${Math.round(snowChance)}%`;
  $("snowMeter").style.width=`${Math.max(0,Math.min(100,snowChance))}%`;
  $("snowNote").textContent=snowChance>0?"Schneefall laut Stundenprognose möglich":"Aktuell kein Schneefall signalisiert";
  const depth=Number(h.snow_depth?.[idx]??0);
  $("snowDepth").textContent=`Schneehöhe: ${Math.max(0,depth*100).toFixed(0)} cm`;
  $("snowStays").textContent=depth>0.005?"Ja":"Eher nein";
  setWarning(temp,code,Number(c.wind_speed_10m||0));
  let next=-1;
  for(let i=idx;i<h.time.length;i++){if(Number(h.snowfall?.[i]||0)>0){next=i;break;}}
  if(next>=0){const when=new Date(h.time[next]);$("nextSnow").textContent=when.toLocaleString("de-DE",{weekday:"short",hour:"2-digit",minute:"2-digit"});}
  else $("nextSnow").textContent="In den nächsten Stunden nicht vorhergesagt";
  $("updated").textContent=`Stand: ${new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})} · Open-Meteo`;
  $("status").textContent="• Wetter aktuell";
 }catch(e){
  $("condition").textContent="Wetterdaten gerade nicht verfügbar";
  $("snowNote").textContent="Bitte Internetverbindung prüfen";
  $("nextSnow").textContent="Keine Prognosedaten verfügbar";
  $("status").textContent="• Offline / Fehler";
 }
}
tick();setInterval(tick,1000);loadWeather();setInterval(loadWeather,15*60*1000);
$("refresh").addEventListener("click",loadWeather);
