/* =========================================================
   MATH QUEST — SCRIPT.JS
   Sistema completo de aventura matemática
========================================================= */

"use strict";

/* =========================================================
   CONFIGURAÇÕES
========================================================= */

const QUESTIONS_PER_LEVEL = 10;
const FINAL_TEST_QUESTIONS = 10;
const PASS_SCORE = 6;

let currentSubject = null;
let currentLevel = 1;
let currentDifficulty = "easy";

let quizQuestions = [];
let currentQuestion = 0;
let correctAnswers = 0;
let lives = 3;

let usedHint = false;
let usedRemove = false;
let usedExplain = false;

let quizMode = "level";

/* =========================================================
   BANCO DE ASSUNTOS
========================================================= */

const subjects = [
    {
        id: "basic",
        name: "Números e Operações",
        icon: "🔢",
        description: "Números naturais, inteiros, operações e cálculos.",
        color: "blue"
    },

    {
        id: "fractions",
        name: "Frações",
        icon: "🍕",
        description: "Frações, equivalência, comparação e operações.",
        color: "purple"
    },

    {
        id: "decimals",
        name: "Números Decimais",
        icon: "🔹",
        description: "Operações, comparação e transformação de decimais.",
        color: "cyan"
    },

    {
        id: "percentage",
        name: "Porcentagem",
        icon: "💯",
        description: "Porcentagem, descontos, aumentos e problemas.",
        color: "green"
    },

    {
        id: "ratio",
        name: "Razão e Proporção",
        icon: "⚖️",
        description: "Razões, proporções e regra de três.",
        color: "orange"
    },

    {
        id: "powers",
        name: "Potenciação",
        icon: "⚡",
        description: "Potências, propriedades e cálculos.",
        color: "yellow"
    },

    {
        id: "roots",
        name: "Radiciação",
        icon: "√",
        description: "Raízes quadradas e operações com radicais.",
        color: "pink"
    },

    {
        id: "algebra",
        name: "Álgebra",
        icon: "🧮",
        description: "Expressões algébricas e cálculo de valores.",
        color: "red"
    },

    {
        id: "equations",
        name: "Equações",
        icon: "📐",
        description: "Equações de primeiro e segundo grau.",
        color: "violet"
    },

    {
        id: "bhaskara",
        name: "Bhaskara",
        icon: "📝",
        description: "Equações do segundo grau usando a fórmula de Bhaskara.",
        color: "purple"
    },

    {
        id: "functions",
        name: "Funções",
        icon: "📊",
        description: "Função afim, função quadrática e gráficos.",
        color: "blue"
    },

    {
        id: "geometry",
        name: "Geometria",
        icon: "📐",
        description: "Formas, ângulos, perímetros e áreas.",
        color: "green"
    },

    {
        id: "pythagoras",
        name: "Teorema de Pitágoras",
        icon: "🔺",
        description: "Triângulos retângulos e relações métricas.",
        color: "orange"
    },

    {
        id: "statistics",
        name: "Estatística",
        icon: "📊",
        description: "Média, mediana, moda e interpretação de dados.",
        color: "cyan"
    },

    {
        id: "probability",
        name: "Probabilidade",
        icon: "🎲",
        description: "Chances, eventos e probabilidades.",
        color: "pink"
    },

    {
        id: "sequences",
        name: "Sequências",
        icon: "🔗",
        description: "Sequências numéricas, PA e padrões.",
        color: "yellow"
    },

    {
        id: "logic",
        name: "Raciocínio Lógico",
        icon: "🧠",
        description: "Problemas de lógica, padrões e estratégias.",
        color: "violet"
    },

    {
        id: "units",
        name: "Grandezas e Medidas",
        icon: "📏",
        description: "Comprimento, massa, tempo, área e volume.",
        color: "blue"
    }
];

/* =========================================================
   PROGRESSO
========================================================= */

let progress = loadProgress();

function defaultProgress() {
    const data = {
        xp: 0,
        stars: 0,
        questions: 0,
        correct: 0,
        completedLevels: {},
        finalTests: {},
        difficulties: {}
    };

    subjects.forEach(subject => {
        data.completedLevels[subject.id] = [];
        data.finalTests[subject.id] = {
            unlocked: false,
            passed: false,
            bestScore: 0
        };

        data.difficulties[subject.id] = "easy";
    });

    return data;
}

function loadProgress() {
    try {
        const saved = localStorage.getItem("mathQuestProgress");

        if (!saved) {
            return defaultProgress();
        }

        const data = JSON.parse(saved);
        const base = defaultProgress();

        return {
            ...base,
            ...data,
            completedLevels: {
                ...base.completedLevels,
                ...(data.completedLevels || {})
            },
            finalTests: {
                ...base.finalTests,
                ...(data.finalTests || {})
            },
            difficulties: {
                ...base.difficulties,
                ...(data.difficulties || {})
            }
        };
    } catch (error) {
        return defaultProgress();
    }
}

function saveProgress() {
    localStorage.setItem(
        "mathQuestProgress",
        JSON.stringify(progress)
    );
}

/* =========================================================
   UTILIDADES
========================================================= */

function $(id) {
    return document.getElementById(id);
}

function showScreen(id) {
    document.querySelectorAll(".screen").forEach(screen => {
        screen.classList.remove("active");
    });

    const screen = $(id);

    if (screen) {
        screen.classList.add("active");
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

    updateInterface();
}

function goHome() {
    showScreen("home");
}

function openPlay() {
    renderSubjects();
    showScreen("play");
}

function openLearn() {
    renderLearnTopics();
    showScreen("learn");
}

function openPractice() {
    renderPracticeSubjects();
    showScreen("practice");
}

function openProfile() {
    updateProfile();
    showScreen("profile");
}

/* =========================================================
   HOME
========================================================= */

function updateInterface() {
    updatePlayer();
    updateHomeStats();
    updateProfile();
}

function getPlayerLevel() {
    return Math.floor(progress.xp / 100) + 1;
}

function getCurrentLevelXP() {
    return progress.xp % 100;
}

function updatePlayer() {
    const level = getPlayerLevel();
    const xp = getCurrentLevelXP();

    if ($("playerLevel")) {
        $("playerLevel").textContent = `Nível ${level}`;
    }

    if ($("xpText")) {
        $("xpText").textContent = `${xp} / 100 XP`;
    }

    if ($("xpBar")) {
        $("xpBar").style.width = `${xp}%`;
    }

    if ($("profileLevel")) {
        $("profileLevel").textContent = `Nível ${level}`;
    }
}

function updateHomeStats() {
    if ($("homeStars")) {
        $("homeStars").textContent = progress.stars;
    }

    if ($("homeQuestions")) {
        $("homeQuestions").textContent = progress.questions;
    }

    const accuracy = progress.questions > 0
        ? Math.round((progress.correct / progress.questions) * 100)
        : 0;

    if ($("homeCorrect")) {
        $("homeCorrect").textContent = `${accuracy}%`;
    }
}

function updateProfile() {
    if ($("profileXP")) {
        $("profileXP").textContent = progress.xp;
    }

    if ($("profileStars2")) {
        $("profileStars2").textContent = progress.stars;
    }

    if ($("profileQuestions")) {
        $("profileQuestions").textContent = progress.questions;
    }

    const accuracy = progress.questions > 0
        ? Math.round((progress.correct / progress.questions) * 100)
        : 0;

    if ($("profileAccuracy")) {
        $("profileAccuracy").textContent = `${accuracy}%`;
    }

    let completed = 0;

    Object.values(progress.completedLevels).forEach(levels => {
        completed += levels.length;
    });

    if ($("profileProgress")) {
        $("profileProgress").textContent =
            `${completed} fases concluídas`;
    }
}

/* =========================================================
   ASSUNTOS
========================================================= */

function renderSubjects() {
    const container = $("subjectsContainer");

    if (!container) return;

    container.innerHTML = "";

    subjects.forEach((subject, index) => {
        const completed =
            progress.completedLevels[subject.id]?.length || 0;

        const card = document.createElement("button");

        card.className = "subject-card";
        card.innerHTML = `
            <div class="subject-icon">
                ${subject.icon}
            </div>

            <div class="subject-info">
                <strong>${index + 1}. ${subject.name}</strong>
                <small>${subject.description}</small>

                <div class="subject-progress">
                    <div>
                        <span>${completed}/10 fases</span>
                        <span>${completed * 10}%</span>
                    </div>

                    <div class="mini-progress">
                        <div style="width:${completed * 10}%"></div>
                    </div>
                </div>
            </div>

            <span class="subject-arrow">›</span>
        `;

        card.onclick = () => openSubject(subject.id);

        container.appendChild(card);
    });
}

/* =========================================================
   ASSUNTO
========================================================= */

function openSubject(subjectId) {
    const subject = subjects.find(s => s.id === subjectId);

    if (!subject) return;

    currentSubject = subject;

    currentDifficulty =
        progress.difficulties[subject.id] || "easy";

    if ($("levelsTitle")) {
        $("levelsTitle").textContent = subject.name;
    }

    if ($("levelSubjectName")) {
        $("levelSubjectName").textContent = subject.name;
    }

    if ($("levelSubjectIcon")) {
        $("levelSubjectIcon").textContent = subject.icon;
    }

    if ($("levelSubjectDescription")) {
        $("levelSubjectDescription").textContent =
            subject.description;
    }

    selectDifficulty(currentDifficulty, false);

    renderLevels();
    updateFinalTestButton();

    showScreen("levels");
}

function backToSubjects() {
    openPlay();
}

/* =========================================================
   DIFICULDADE
========================================================= */

function selectDifficulty(difficulty, save = true) {
    if (!["easy", "medium", "hard"].includes(difficulty)) {
        difficulty = "easy";
    }

    currentDifficulty = difficulty;

    if (currentSubject && save) {
        progress.difficulties[currentSubject.id] = difficulty;
        saveProgress();
    }

    document.querySelectorAll(".difficulty-btn").forEach(btn => {
        btn.classList.remove("selected");

        if (btn.dataset.difficulty === difficulty) {
            btn.classList.add("selected");
        }
    });

    if (currentSubject) {
        renderLevels();
        updateFinalTestButton();
    }
}

/* =========================================================
   FASES
========================================================= */

function renderLevels() {
    const container = $("levelsContainer");

    if (!container || !currentSubject) return;

    container.innerHTML = "";

    const completed =
        progress.completedLevels[currentSubject.id] || [];

    for (let i = 1; i <= 10; i++) {

        const isCompleted = completed.includes(i);
        const unlocked =
            i === 1 || completed.includes(i - 1);

        const button = document.createElement("button");

        button.className = "quest-level";

        if (isCompleted) {
            button.classList.add("completed");
        }

        if (!unlocked) {
            button.classList.add("locked");
        }

        const stars = isCompleted ? "⭐⭐⭐" : "☆";

        button.innerHTML = `
            <div class="quest-number">
                ${isCompleted ? "✓" : i}
            </div>

            <div class="quest-info">
                <strong>Fase ${i}</strong>

                <span>
                    ${isCompleted
                        ? "Concluída"
                        : unlocked
                            ? "Disponível"
                            : "Bloqueada"}
                </span>

                <small>
                    ${stars}
                </small>
            </div>

            <div class="quest-lock">
                ${isCompleted
                    ? "🏆"
                    : unlocked
                        ? "▶️"
                        : "🔒"}
            </div>
        `;

        if (unlocked) {
            button.onclick = () => startLevel(i);
        }

        container.appendChild(button);
    }
}

/* =========================================================
   INICIAR FASE
========================================================= */

function startLevel(level) {
    if (!currentSubject) return;

    const completed =
        progress.completedLevels[currentSubject.id] || [];

    if (level > 1 && !completed.includes(level - 1)) {
        alert("🔒 Complete a fase anterior primeiro!");
        return;
    }

    currentLevel = level;
    quizMode = "level";

    startQuiz(
        currentSubject.id,
        level,
        currentDifficulty
    );
}

/* =========================================================
   BANCO DE QUESTÕES
========================================================= */

function question(
    text,
    options,
    answer,
    explanation,
    hint,
    concept = ""
) {
    return {
        question: text,
        options,
        answer,
        explanation,
        hint,
        concept
    };
}

/* =========================================================
   GERADORES DE QUESTÕES
========================================================= */

function generateQuestions(subjectId, difficulty) {

    const generators = {

        basic: generateBasic,
        fractions: generateFractions,
        decimals: generateDecimals,
        percentage: generatePercentage,
        ratio: generateRatio,
        powers: generatePowers,
        roots: generateRoots,
        algebra: generateAlgebra,
        equations: generateEquations,
        bhaskara: generateBhaskara,
        functions: generateFunctions,
        geometry: generateGeometry,
        pythagoras: generatePythagoras,
        statistics: generateStatistics,
        probability: generateProbability,
        sequences: generateSequences,
        logic: generateLogic,
        units: generateUnits
    };

    const generator = generators[subjectId];

    if (!generator) {
        return generateBasic(difficulty);
    }

    return generator(difficulty);
}

/* =========================================================
   NÚMEROS E OPERAÇÕES
========================================================= */

function generateBasic(difficulty) {
    const questions = [];

    const operationsEasy = [
        [12, 8, "+", 20],
        [25, 7, "-", 18],
        [6, 7, "×", 42],
        [48, 6, "÷", 8],
        [15, 9, "+", 24],
        [30, 12, "-", 18],
        [9, 5, "×", 45],
        [72, 8, "÷", 9]
    ];

    const operationsMedium = [
        [125, 37, "+", 162],
        [200, 86, "-", 114],
        [24, 13, "×", 312],
        [144, 12, "÷", 12],
        [56, 18, "+", 74],
        [91, 27, "-", 64],
        [17, 8, "×", 136],
        [225, 15, "÷", 15]
    ];

    const operationsHard = [
        [345, 278, "+", 623],
        [900, 457, "-", 443],
        [36, 27, "×", 972],
        [936, 24, "÷", 39],
        [725, 389, "+", 1114],
        [1000, 637, "-", 363],
        [48, 19, "×", 912],
        [1296, 36, "÷", 36]
    ];

    let data =
        difficulty === "hard"
            ? operationsHard
            : difficulty === "medium"
                ? operationsMedium
                : operationsEasy;

    for (let i = 0; i < QUESTIONS_PER_LEVEL; i++) {

        const item = data[i % data.length];

        questions.push(
            makeCalculationQuestion(
                `${item[0]} ${item[2]} ${item[1]} = ?`,
                item[3],
                `Para resolver, fazemos a operação ${item[2]} entre ${item[0]} e ${item[1]}. O resultado é ${item[3]}.`,
                "Identifique primeiro qual operação matemática aparece na questão."
            )
        );
    }

    return questions;
}

/* =========================================================
   FRAÇÕES
========================================================= */

function generateFractions(difficulty) {

    const data = difficulty === "hard"
        ? [
            ["1/2 + 1/3", "5/6"],
            ["3/4 - 1/6", "7/12"],
            ["2/3 × 3/5", "2/5"],
            ["3/4 ÷ 2/3", "9/8"],
            ["5/6 - 1/4", "7/12"]
        ]
        : difficulty === "medium"
            ? [
                ["1/2 + 1/4", "3/4"],
                ["3/5 - 1/5", "2/5"],
                ["2/3 × 3/4", "1/2"],
                ["4/5 ÷ 2", "2/5"],
                ["1/3 + 1/6", "1/2"]
            ]
            : [
                ["1/2 + 1/2", "1"],
                ["1/4 + 1/4", "1/2"],
                ["3/4 - 1/4", "1/2"],
                ["1/2 × 2", "1"],
                ["2/3 - 1/3", "1/3"]
            ];

    return data.map((item, index) => {

        const correct = item[1];

        const wrong = makeFractionOptions(correct);

        return question(
            `Qual é o resultado de ${item[0]}?`,
            shuffle([
                correct,
                ...wrong
            ]),
            correct,
            `Resolva a operação respeitando as regras das frações. O resultado simplificado é ${correct}.`,
            "Observe os denominadores e veja se é necessário encontrar um denominador comum.",
            "Frações"
        );
    });
}

/* =========================================================
   DECIMAIS
========================================================= */

function generateDecimals(difficulty) {

    const data = difficulty === "hard"
        ? [
            ["12,5 × 4", 50],
            ["25,75 + 13,25", 39],
            ["100,5 - 27,75", 72.75],
            ["144,6 ÷ 6", 24.1],
            ["3,75 × 8", 30]
        ]
        : difficulty === "medium"
            ? [
                ["12,5 + 7,5", 20],
                ["30,5 - 12,5", 18],
                ["2,5 × 4", 10],
                ["25,5 ÷ 5", 5.1],
                ["7,2 + 2,8", 10]
            ]
            : [
                ["1,5 + 2,5", 4],
                ["5,5 - 2,5", 3],
                ["2,5 × 2", 5],
                ["8,4 ÷ 2", 4.2],
                ["1,2 + 0,8", 2]
            ];

    return data.map(item => {
        const correct = String(item[1]).replace(".", ",");

        return question(
            `${item[0]} = ?`,
            shuffle([
                correct,
                decimalWrong(correct, 1),
                decimalWrong(correct, -1),
                decimalWrong(correct, 0.5)
            ]),
            correct,
            `Realizando a operação corretamente, obtemos ${correct}. É importante alinhar corretamente as casas decimais quando necessário.`,
            "Preste atenção à posição da vírgula.",
            "Números decimais"
        );
    });
}

/* =========================================================
   PORCENTAGEM
========================================================= */

function generatePercentage(difficulty) {

    const data = difficulty === "hard"
        ? [
            [240, 15, 36],
            [350, 12, 42],
            [800, 7.5, 60],
            [1200, 18, 216],
            [450, 22, 99]
        ]
        : difficulty === "medium"
            ? [
                [200, 10, 20],
                [500, 20, 100],
                [300, 15, 45],
                [800, 25, 200],
                [400, 30, 120]
            ]
            : [
                [100, 10, 10],
                [200, 10, 20],
                [300, 10, 30],
                [50, 20, 10],
                [100, 25, 25]
            ];

    return data.map(item => {

        const base = item[0];
        const percent = item[1];
        const correct = item[2];

        return question(
            `Quanto é ${percent}% de ${base}?`,
            shuffle([
                String(correct),
                String(Math.round(correct * 0.5)),
                String(correct + 10),
                String(correct + 20)
            ]),
            String(correct),
            `${percent}% significa ${percent}/100. Então calculamos ${base} × ${percent}/100 = ${correct}.`,
            "Transforme a porcentagem em uma fração sobre 100.",
            "Porcentagem"
        );
    });
}

/* =========================================================
   RAZÃO E PROPORÇÃO
========================================================= */

function generateRatio(difficulty) {

    const data = difficulty === "hard"
        ? [
            [4, 6, 18, 27],
            [5, 8, 40, 64],
            [7, 9, 21, 27],
            [12, 15, 20, 25],
            [8, 12, 30, 45]
        ]
        : [
            [2, 3, 8, 12],
            [3, 4, 9, 12],
            [5, 2, 20, 8],
            [4, 5, 12, 15],
            [2, 5, 6, 15]
        ];

    return data.map(item => {

        const a = item[0];
        const b = item[1];
        const c = item[2];
        const d = item[3];

        return question(
            `As razões ${a}:${b} e ${c}:x são proporcionais. Qual é x?`,
            shuffle([
                String(d),
                String(d - 2),
                String(d + 2),
                String(d + 4)
            ]),
            String(d),
            `Montamos ${a}/${b} = ${c}/x. Multiplicando em cruz: ${a} × x = ${b} × ${c}. O valor que mantém a proporção é ${d}.`,
            "Monte uma proporção e faça a multiplicação cruzada.",
            "Razão e proporção"
        );
    });
}

/* =========================================================
   POTENCIAÇÃO
========================================================= */

function generatePowers(difficulty) {

    const data = difficulty === "hard"
        ? [
            ["2⁵", 32],
            ["3⁴", 81],
            ["5³", 125],
            ["10⁴", 10000],
            ["4³", 64]
        ]
        : [
            ["2²", 4],
            ["3²", 9],
            ["4²", 16],
            ["5²", 25],
            ["10²", 100]
        ];

    return data.map(item => {

        const correct = String(item[1]);

        return question(
            `Calcule ${item[0]}.`,
            shuffle([
                correct,
                String(item[1] + 1),
                String(item[1] - 1),
                String(item[1] * 2)
            ]),
            correct,
            `A potência representa multiplicações repetidas. O resultado correto é ${correct}.`,
            "Veja o expoente: ele indica quantas vezes a base será multiplicada por ela mesma.",
            "Potenciação"
        );
    });
}

/* =========================================================
   RADICIAÇÃO
========================================================= */

function generateRoots(difficulty) {

    const data = difficulty === "hard"
        ? [
            ["√144", 12],
            ["√169", 13],
            ["√225", 15],
            ["√196", 14],
            ["√256", 16]
        ]
        : [
            ["√4", 2],
            ["√9", 3],
            ["√16", 4],
            ["√25", 5],
            ["√36", 6]
        ];

    return data.map(item => {

        const correct = String(item[1]);

        return question(
            `Qual é o valor de ${item[0]}?`,
            shuffle([
                correct,
                String(item[1] + 1),
                String(item[1] - 1),
                String(item[1] + 2)
            ]),
            correct,
            `Precisamos encontrar o número que, multiplicado por ele mesmo, produz o número dentro da raiz. Esse número é ${correct}.`,
            "Procure o número que multiplicado por ele mesmo produz o radicando.",
            "Radiciação"
        );
    });
}

/* =========================================================
   ÁLGEBRA
========================================================= */

function generateAlgebra(difficulty) {

    const data = difficulty === "hard"
        ? [
            ["2x + 5x", "7x"],
            ["9a - 4a", "5a"],
            ["3x + 2x - x", "4x"],
            ["5y + 3 - 2y", "3y + 3"],
            ["4a + 2a - 3a", "3a"]
        ]
        : [
            ["2x + 3x", "5x"],
            ["7a - 2a", "5a"],
            ["4y + y", "5y"],
            ["8x - 3x", "5x"],
            ["6a + 2a", "8a"]
        ];

    return data.map(item => {

        const correct = item[1];

        return question(
            `Simplifique: ${item[0]}.`,
            shuffle([
                correct,
                "6x",
                "4x",
                "2x"
            ]),
            correct,
            `Juntamos apenas os termos semelhantes. Na expressão ${item[0]}, o resultado é ${correct}.`,
            "Só podemos juntar termos que possuem a mesma parte literal.",
            "Álgebra"
        );
    });
}

/* =========================================================
   EQUAÇÕES
========================================================= */

function generateEquations(difficulty) {

    const data = difficulty === "hard"
        ? [
            [3, 5, 20],
            [4, 7, 31],
            [5, 2, 27],
            [6, 4, 40],
            [7, 3, 38]
        ]
        : difficulty === "medium"
            ? [
                [2, 3, 15],
                [3, 4, 22],
                [4, 2, 18],
                [5, 1, 26],
                [2, 7, 25]
            ]
            : [
                [1, 5, 12],
                [1, 3, 10],
                [1, 7, 15],
                [1, 4, 9],
                [1, 8, 14]
            ];

    return data.map(item => {

        const a = item[0];
        const b = item[1];
        const total = item[2];

        const x = (total - b) / a;

        const correct = String(x);

        return question(
            `Resolva: ${a}x + ${b} = ${total}.`,
            shuffle([
                correct,
                String(x + 1),
                String(x - 1),
                String(x + 2)
            ]),
            correct,
            `Primeiro retiramos ${b} dos dois lados. Depois dividimos pelo coeficiente de x. Assim, x = ${correct}.`,
            "Isole o termo que contém x fazendo a mesma operação nos dois lados.",
            "Equação"
        );
    });
}

/* =========================================================
   BHASKARA
========================================================= */

function generateBhaskara(difficulty) {

    const data = difficulty === "hard"
        ? [
            [1, -5, 6, 2, 3],
            [1, -7, 12, 3, 4],
            [1, -9, 20, 4, 5],
            [1, -11, 30, 5, 6],
            [1, -13, 42, 6, 7]
        ]
        : [
            [1, -3, 2, 1, 2],
            [1, -5, 4, 1, 4],
            [1, -6, 5, 1, 5],
            [1, -7, 6, 1, 6],
            [1, -8, 7, 1, 7]
        ];

    return data.map(item => {

        const a = item[0];
        const b = item[1];
        const c = item[2];

        const x1 = item[3];
        const x2 = item[4];

        const correct = `x₁=${x1} e x₂=${x2}`;

        return question(
            `Resolva pela fórmula de Bhaskara: ${a}x² ${b < 0 ? "- " + Math.abs(b) : "+ " + b}x + ${c} = 0.`,
            shuffle([
                correct,
                `x₁=${x1 + 1} e x₂=${x2}`,
                `x₁=${x1} e x₂=${x2 + 1}`,
                `x₁=${x1 - 1} e x₂=${x2 - 1}`
            ]),
            correct,
            `Pela fórmula de Bhaskara, calculamos o discriminante Δ = b² − 4ac e depois x = (−b ± √Δ)/(2a). As raízes são ${correct}.`,
            "Primeiro calcule o Δ = b² − 4ac. Depois use as duas possibilidades do sinal ±.",
            "Fórmula de Bhaskara"
        );
    });
}

/* =========================================================
   FUNÇÕES
========================================================= */

function generateFunctions(difficulty) {

    const data = [
        ["f(x) = 2x + 3", 5, 13],
        ["f(x) = 3x + 1", 4, 13],
        ["f(x) = 5x - 2", 3, 13],
        ["f(x) = 4x + 2", 2, 10],
        ["f(x) = 6x - 1", 2, 11]
    ];

    return data.map(item => {

        const expression = item[0];
        const x = item[1];
        const correct = item[2];

        return question(
            `Dada ${expression}, qual é f(${x})?`,
            shuffle([
                String(correct),
                String(correct + 2),
                String(correct - 2),
                String(correct + 4)
            ]),
            String(correct),
            `Substituímos x por ${x}. Depois fazemos as operações indicadas na função. O resultado é ${correct}.`,
            "Substitua o valor de x na expressão da função.",
            "Função"
        );
    });
}

/* =========================================================
   GEOMETRIA
========================================================= */

function generateGeometry(difficulty) {

    const data = [
        ["um quadrado de lado 5 cm", 20, "perímetro"],
        ["um quadrado de lado 6 cm", 24, "perímetro"],
        ["um retângulo de lados 8 cm e 4 cm", 24, "perímetro"],
        ["um retângulo de 10 cm por 3 cm", 30, "perímetro"],
        ["um quadrado de lado 7 cm", 28, "perímetro"]
    ];

    return data.map(item => {

        const description = item[0];
        const correct = item[1];

        return question(
            `Qual é o ${item[2]} de ${description}?`,
            shuffle([
                `${correct} cm`,
                `${correct + 4} cm`,
                `${correct - 4} cm`,
                `${correct + 2} cm`
            ]),
            `${correct} cm`,
            `Para calcular o perímetro somamos todos os lados. O resultado é ${correct} cm.`,
            "Perímetro é o comprimento total da borda da figura.",
            "Geometria"
        );
    });
}

/* =========================================================
   PITÁGORAS
========================================================= */

function generatePythagoras(difficulty) {

    const data = [
        [3, 4, 5],
        [6, 8, 10],
        [5, 12, 13],
        [8, 15, 17],
        [7, 24, 25]
    ];

    return data.map(item => {

        const a = item[0];
        const b = item[1];
        const c = item[2];

        return question(
            `Um triângulo retângulo possui catetos ${a} e ${b}. Qual é a hipotenusa?`,
            shuffle([
                String(c),
                String(c + 1),
                String(c - 1),
                String(c + 2)
            ]),
            String(c),
            `Pelo Teorema de Pitágoras: a² + b² = c². Então ${a}² + ${b}² = ${c}², logo a hipotenusa mede ${c}.`,
            "Use a² + b² = c².",
            "Teorema de Pitágoras"
        );
    });
}

/* =========================================================
   ESTATÍSTICA
========================================================= */

function generateStatistics(difficulty) {

    const data = [
        [[2, 4, 6], 4],
        [[5, 10, 15], 10],
        [[4, 6, 8, 10], 7],
        [[10, 20, 30, 40], 25],
        [[3, 6, 9, 12], 7.5]
    ];

    return data.map(item => {

        const numbers = item[0];
        const correct = item[1];

        return question(
            `Qual é a média aritmética de ${numbers.join(", ")}?`,
            shuffle([
                String(correct),
                String(correct + 1),
                String(correct - 1),
                String(correct + 2)
            ]),
            String(correct),
            `Somamos os valores e dividimos pela quantidade de números. O resultado da média é ${correct}.`,
            "Some todos os valores e divida pela quantidade de números.",
            "Média aritmética"
        );
    });
}

/* =========================================================
   PROBABILIDADE
========================================================= */

function generateProbability(difficulty) {

    const data = [
        [1, 6, "1/6"],
        [2, 6, "1/3"],
        [3, 6, "1/2"],
        [1, 4, "1/4"],
        [2, 4, "1/2"]
    ];

    return data.map(item => {

        const favorable = item[0];
        const total = item[1];
        const correct = item[2];

        return question(
            `Um experimento possui ${total} resultados igualmente possíveis e ${favorable} resultado(s) favorável(is). Qual é a probabilidade?`,
            shuffle([
                correct,
                "1/2",
                "1/3",
                "1/4"
            ]),
            correct,
            `Probabilidade = casos favoráveis ÷ casos possíveis. Assim, ${favorable}/${total} = ${correct}.`,
            "Divida o número de resultados favoráveis pelo número total de resultados.",
            "Probabilidade"
        );
    });
}

/* =========================================================
   SEQUÊNCIAS
========================================================= */

function generateSequences(difficulty) {

    const data = [
        [[2, 4, 6, 8], 10],
        [[5, 10, 15, 20], 25],
        [[3, 6, 9, 12], 15],
        [[10, 20, 30, 40], 50],
        [[7, 14, 21, 28], 35]
    ];

    return data.map(item => {

        const sequence = item[0];
        const correct = item[1];

        return question(
            `Qual é o próximo número da sequência ${sequence.join(", ")}?`,
            shuffle([
                String(correct),
                String(correct + 2),
                String(correct - 2),
                String(correct + 5)
            ]),
            String(correct),
            `A sequência aumenta sempre pela mesma diferença. Continuando o padrão, o próximo número é ${correct}.`,
            "Compare a diferença entre números consecutivos.",
            "Sequências"
        );
    });
}

/* =========================================================
   LÓGICA
========================================================= */

function generateLogic(difficulty) {

    const data = [
        ["Se todos os gatos são animais e Mimi é um gato, Mimi é...", "um animal"],
        ["Se 2 + 2 = 4, então 4 + 4 = ...", "8"],
        ["Qual número completa: 2, 4, 6, 8, ...?", "10"],
        ["Qual número é maior: 15 ou 12?", "15"],
        ["Se hoje é segunda-feira, amanhã será...", "terça-feira"]
    ];

    return data.map(item => {

        const correct = item[1];

        return question(
            item[0],
            shuffle([
                correct,
                "uma planta",
                "um número menor",
                "domingo"
            ]),
            correct,
            `Aplicando diretamente as informações fornecidas, concluímos que a resposta é ${correct}.`,
            "Use somente as informações presentes na questão.",
            "Raciocínio lógico"
        );
    });
}

/* =========================================================
   UNIDADES
========================================================= */

function generateUnits(difficulty) {

    const data = [
        ["1 metro", "100 centímetros"],
        ["1 quilômetro", "1000 metros"],
        ["1 quilograma", "1000 gramas"],
        ["1 litro", "1000 mililitros"],
        ["1 hora", "60 minutos"]
    ];

    return data.map(item => {

        return question(
            `Qual equivalência está correta para ${item[0]}?`,
            shuffle([
                item[1],
                "10 unidades",
                "10000 unidades",
                "500 unidades"
            ]),
            item[1],
            `A equivalência matemática correta é ${item[1]}.`,
            "Lembre-se das relações básicas entre as unidades.",
            "Grandezas e medidas"
        );
    });
}

/* =========================================================
   FUNÇÕES AUXILIARES DE QUESTÕES
========================================================= */

function makeCalculationQuestion(
    text,
    answer,
    explanation,
    hint
) {

    const correct = String(answer);

    return question(
        text,
        shuffle([
            correct,
            String(answer + 1),
            String(answer - 1),
            String(answer + 2)
        ]),
        correct,
        explanation,
        hint,
        "Operações"
    );
}

function makeFractionOptions(correct) {

    const map = {
        "1": ["1/2", "2", "1/3"],
        "1/2": ["1/3", "2/3", "3/4"],
        "1/3": ["1/2", "2/3", "1/4"],
        "3/4": ["1/4", "2/4", "5/4"],
        "5/6": ["2/3", "3/4", "4/6"],
        "7/12": ["5/12", "2/3", "3/12"],
        "2/5": ["1/5", "3/5", "4/5"],
        "9/8": ["7/8", "8/9", "3/4"]
    };

    return map[correct] || ["1/2", "2/3", "3/4"];
}

function decimalWrong(correct, change) {

    const number = parseFloat(
        String(correct).replace(",", ".")
    );

    const value = number + change;

    return String(
        Number(value.toFixed(2))
    ).replace(".", ",");
}

/* =========================================================
   QUIZ
========================================================= */

function startQuiz(subjectId, level, difficulty) {

    quizQuestions = generateQuestions(
        subjectId,
        difficulty
    );

    quizQuestions = quizQuestions.slice(
        0,
        QUESTIONS_PER_LEVEL
    );

    currentQuestion = 0;
    correctAnswers = 0;
    lives = 3;

    usedHint = false;
    usedRemove = false;
    usedExplain = false;

    showScreen("quiz");

    updateQuizUI();
    renderQuestion();
}

function updateQuizUI() {

    const total = quizQuestions.length || 10;

    if ($("quizCounter")) {
        $("quizCounter").textContent =
            `${Math.min(currentQuestion + 1, total)}/${total}`;
    }

    if ($("quizXp")) {
        $("quizXp").textContent =
            quizMode === "final"
                ? "+20 XP"
                : "+10 XP";
    }

    if ($("quizBar")) {
        const percentage =
            total > 0
                ? (currentQuestion / total) * 100
                : 0;

        $("quizBar").style.width =
            `${Math.min(percentage, 100)}%`;
    }

    if ($("lives")) {
        $("lives").textContent = lives;
    }

    updateHelpCards();
}

function renderQuestion() {

    const box = $("questionBox");

    if (!box) return;

    const q = quizQuestions[currentQuestion];

    if (!q) {
        finishQuiz();
        return;
    }

    const letters = ["A", "B", "C", "D"];

    box.innerHTML = `
        <div class="question-card">

            <div class="question-category">
                ${currentSubject?.icon || "🧠"}
                ${currentSubject?.name || "Desafio"}
            </div>

            <h2 class="question-title">
                ${escapeHTML(q.question)}
            </h2>

            <div class="answers">
                ${q.options.map((option, index) => `
                    <button
                        class="answer-option"
                        data-index="${index}"
                        onclick="answerQuestion(${index})">

                        <span class="answer-letter">
                            ${letters[index]}
                        </span>

                        <span>
                            ${escapeHTML(String(option))}
                        </span>

                    </button>
                `).join("")}
            </div>

            <div class="question-tip">
                💡 Pense com calma antes de responder.
            </div>

        </div>
    `;

    updateQuizUI();
}

/* =========================================================
   RESPONDER
========================================================= */

function answerQuestion(index) {

    const q = quizQuestions[currentQuestion];

    if (!q) return;

    const buttons =
        document.querySelectorAll(".answer-option");

    buttons.forEach(button => {
        button.disabled = true;
    });

    const selected =
        String(q.options[index]);

    const correct =
        String(q.answer);

    const isCorrect =
        selected === correct;

    if (isCorrect) {

        correctAnswers++;
        progress.correct++;

        buttons[index]?.classList.add("correct");

        showAnswerExplanation(
            true,
            q,
            selected
        );

    } else {

        lives--;

        buttons[index]?.classList.add("wrong");

        buttons.forEach(button => {

            if (
                String(q.options[
                    Number(button.dataset.index)
                ]) === correct
            ) {
                button.classList.add("correct");
            }

        });

        showAnswerExplanation(
            false,
            q,
            selected
        );
    }

    progress.questions++;

    saveProgress();
    updateInterface();

    setTimeout(() => {

        if (lives <= 0) {

            finishQuiz(true);

            return;
        }

        currentQuestion++;

        if (currentQuestion >= quizQuestions.length) {
            finishQuiz();
        } else {
            renderQuestion();
        }

    }, 3500);
}

/* =========================================================
   EXPLICAÇÃO DA RESPOSTA
========================================================= */

function showAnswerExplanation(
    correct,
    q,
    selected
) {

    const box = $("questionBox");

    if (!box) return;

    const title = correct
        ? "🎉 Muito bem!"
        : "📚 Vamos entender";

    const intro = correct
        ? `Você respondeu ${selected} e acertou!`
        : `Você respondeu ${selected}. A resposta correta é ${q.answer}.`;

    const extra = q.explanation || 
        "Revise o conceito e tente novamente.";

    const concept = q.concept
        ? `<div class="concept-box">
                📖 Conceito: ${escapeHTML(q.concept)}
           </div>`
        : "";

    box.innerHTML = `
        <div class="answer-feedback ${correct ? "feedback-correct" : "feedback-wrong"}">

            <div class="feedback-icon">
                ${correct ? "✅" : "💡"}
            </div>

            <h2>
                ${title}
            </h2>

            <p>
                ${escapeHTML(intro)}
            </p>

            <div class="explanation-box">

                <strong>
                    📖 Explicação
                </strong>

                <p>
                    ${escapeHTML(extra)}
                </p>

            </div>

            ${concept}

            <div class="continue-text">
                Próxima questão em instantes...
            </div>

        </div>
    `;
}

/* =========================================================
   CARTAS DE AJUDA
========================================================= */

function updateHelpCards() {

    const hint = $("hintCard");
    const remove = $("removeCard");
    const explain = $("explainCard");

    if (hint) {
        hint.disabled = usedHint;
        hint.classList.toggle("used", usedHint);
    }

    if (remove) {
        remove.disabled = usedRemove;
        remove.classList.toggle("used", usedRemove);
    }

    if (explain) {
        explain.disabled = usedExplain;
        explain.classList.toggle("used", usedExplain);
    }
}

/* =========================================================
   CARTA — DICA
========================================================= */

function useHint() {

    if (usedHint) return;

    const q = quizQuestions[currentQuestion];

    if (!q) return;

    usedHint = true;

    updateHelpCards();

    showHelp(`
        <div class="help-icon">💡</div>

        <h2>Dica</h2>

        <p>
            ${escapeHTML(q.hint)}
        </p>

        <div class="help-note">
            A dica ajuda você a pensar, mas não entrega diretamente a resposta.
        </div>
    `);
}

/* =========================================================
   CARTA — ELIMINAR
========================================================= */

function useRemoveOption() {

    if (usedRemove) return;

    const q = quizQuestions[currentQuestion];

    if (!q) return;

    usedRemove = true;

    const buttons =
        document.querySelectorAll(".answer-option");

    const wrongIndexes = [];

    q.options.forEach((option, index) => {

        if (
            String(option) !== String(q.answer)
        ) {
            wrongIndexes.push(index);
        }

    });

    shuffle(wrongIndexes);

    const amount =
        Math.min(2, wrongIndexes.length);

    for (let i = 0; i < amount; i++) {

        const index = wrongIndexes[i];

        if (buttons[index]) {
            buttons[index].disabled = true;
            buttons[index].classList.add("removed");

            buttons[index].innerHTML +=
                `<span class="removed-text">Eliminada</span>`;
        }
    }

    updateHelpCards();
}

/* =========================================================
   CARTA — EXPLICAR
========================================================= */

function showConceptHelp() {

    if (usedExplain) return;

    const q = quizQuestions[currentQuestion];

    if (!q) return;

    usedExplain = true;

    updateHelpCards();

    showHelp(`
        <div class="help-icon">📖</div>

        <h2>Explicação do conceito</h2>

        <h3>
            ${escapeHTML(q.concept || "Matemática")}
        </h3>

        <p>
            ${escapeHTML(q.explanation)}
        </p>

        <div class="help-note">
            Leia com calma e tente resolver a questão usando essa ideia.
        </div>
    `);
}

/* =========================================================
   MODAL DE AJUDA
========================================================= */

function showHelp(content) {

    const modal = $("helpModal");
    const helpContent = $("helpContent");

    if (!modal || !helpContent) return;

    helpContent.innerHTML = content;

    modal.classList.remove("hidden");
}

function closeHelp() {

    const modal = $("helpModal");

    if (modal) {
        modal.classList.add("hidden");
    }
}

/* =========================================================
   APRENDER
========================================================= */

function renderLearnTopics() {

    const container = $("learnTopics");

    if (!container) return;

    container.innerHTML = "";

    subjects.forEach(subject => {

        const card = document.createElement("button");

        card.className = "learn-topic";

        card.innerHTML = `
            <span>${subject.icon}</span>

            <div>
                <strong>${subject.name}</strong>
                <small>${subject.description}</small>
            </div>

            <b>›</b>
        `;

        card.onclick = () => {
            showLearningContent(subject);
        };

        container.appendChild(card);
    });
}

function showLearningContent(subject) {

    const content = `
        <div class="learn-modal-icon">
            ${subject.icon}
        </div>

        <h2>${escapeHTML(subject.name)}</h2>

        <p>
            ${escapeHTML(subject.description)}
        </p>

        <div class="lesson-box">

            <h3>📚 Como estudar</h3>

            <p>
                Comece entendendo o significado dos números
                e das operações envolvidas. Depois observe
                exemplos resolvidos e tente fazer exercícios
                sozinho.
            </p>

            <h3>🧠 Dica</h3>

            <p>
                Não tenha pressa. Leia a questão, identifique
                o que ela está pedindo e escolha uma estratégia
                antes de começar os cálculos.
            </p>

        </div>

        <button class="big-button"
                onclick="closeLearnModal(); openSubject('${subject.id}')">

            🎮 PRATICAR ESTE ASSUNTO

        </button>
    `;

    const modal = $("learnModal");
    const learnContent = $("learnContent");

    if (!modal || !learnContent) return;

    learnContent.innerHTML = content;
    modal.classList.remove("hidden");
}

function closeLearnModal() {

    const modal = $("learnModal");

    if (modal) {
        modal.classList.add("hidden");
    }
}

/* =========================================================
   PRATICAR
========================================================= */

function renderPracticeSubjects() {

    const container = $("practiceSubjects");

    if (!container) return;

    container.innerHTML = "";

    subjects.forEach(subject => {

        const button = document.createElement("button");

        button.className = "practice-button";

        button.innerHTML = `
            ${subject.icon}
            ${subject.name}
        `;

        button.onclick = () => {
            startPractice(subject.id);
        };

        container.appendChild(button);
    });
}

function startPractice(subjectId) {

    const subject =
        subjects.find(s => s.id === subjectId);

    if (!subject) return;

    currentSubject = subject;
    currentDifficulty =
        progress.difficulties[subject.id] || "easy";

    quizMode = "practice";

    quizQuestions = generateQuestions(
        subject.id,
        currentDifficulty
    );

    quizQuestions = shuffle(quizQuestions)
        .slice(0, QUESTIONS_PER_LEVEL);

    currentQuestion = 0;
    correctAnswers = 0;
    lives = 3;

    usedHint = false;
    usedRemove = false;
    usedExplain = false;

    showScreen("quiz");
    renderQuestion();
}

/* =========================================================
   DESAFIO SURPRESA
========================================================= */

function startChallenge() {

    const subject =
        subjects[Math.floor(Math.random() * subjects.length)];

    currentSubject = subject;
    currentDifficulty = "hard";
    quizMode = "challenge";

    quizQuestions =
        generateQuestions(
            subject.id,
            "hard"
        ).slice(0, 1);

    currentQuestion = 0;
    correctAnswers = 0;
    lives = 1;

    usedHint = false;
    usedRemove = false;
    usedExplain = false;

    showScreen("quiz");
    renderQuestion();
}

/* =========================================================
   PROVA FINAL
========================================================= */

function updateFinalTestButton() {

    if (!currentSubject) return;

    const card =
        document.querySelector(".final-test-card");

    if (!card) return;

    const finalData =
        progress.finalTests[currentSubject.id];

    const completed =
        progress.completedLevels[currentSubject.id]?.length || 0;

    const unlocked =
        completed >= 10;

    const button =
        card.querySelector("button");

    if (!button) return;

    if (unlocked) {

        button.disabled = false;

        button.innerHTML =
            finalData?.passed
                ? "🏆"
                : "▶️";

        card.classList.add("unlocked");

    } else {

        button.disabled = true;
        button.innerHTML = "🔒";

        card.classList.remove("unlocked");
    }
}

function startFinalTest() {

    if (!currentSubject) return;

    const completed =
        progress.completedLevels[currentSubject.id]?.length || 0;

    if (completed < 10) {

        alert(
            "🔒 Complete as 10 fases deste assunto para liberar a Prova Final!"
        );

        return;
    }

    quizMode = "final";

    quizQuestions =
        generateQuestions(
            currentSubject.id,
            "hard"
        ).slice(0, FINAL_TEST_QUESTIONS);

    currentQuestion = 0;
    correctAnswers = 0;
    lives = 999;

    usedHint = false;
    usedRemove = false;
    usedExplain = false;

    showScreen("quiz");
    renderQuestion();
}

/* =========================================================
   FINALIZAR QUIZ
========================================================= */

function finishQuiz(noLives = false) {

    const total = quizQuestions.length;

    let passed = false;
    let xp = 0;
    let stars = 0;

    if (quizMode === "final") {

        passed = correctAnswers >= PASS_SCORE;

        if (passed) {
            xp = 200;
            stars = 10;

            progress.finalTests[currentSubject.id] = {
                unlocked: true,
                passed: true,
                bestScore: Math.max(
                    progress.finalTests[currentSubject.id]?.bestScore || 0,
                    correctAnswers
                )
            };

        } else {

            xp = correctAnswers * 10;
            stars = correctAnswers;
        }

    } else if (quizMode === "challenge") {

        passed = correctAnswers === 1;

        xp = passed ? 50 : 5;
        stars = passed ? 3 : 0;

    } else if (quizMode === "practice") {

        passed = correctAnswers >= Math.ceil(total / 2);

        xp = correctAnswers * 5;
        stars = passed ? 1 : 0;

    } else {

        passed = correctAnswers === total;

        if (passed) {

            xp = 100;
            stars = 3;

            const levels =
                progress.completedLevels[currentSubject.id] || [];

            if (!levels.includes(currentLevel)) {
                levels.push(currentLevel);
            }

            progress.completedLevels[
                currentSubject.id
            ] = levels;

        } else {

            xp = correctAnswers * 5;
            stars = correctAnswers >= 7 ? 1 : 0;
        }
    }

    progress.xp += xp;
    progress.stars += stars;

    saveProgress();

    showResult(
        total,
        correctAnswers,
        xp,
        stars,
        passed,
        noLives
    );
}

/* =========================================================
   RESULTADO
========================================================= */

function showResult(
    total,
    correct,
    xp,
    stars,
    passed,
    noLives
) {

    if ($("resultScore")) {
        $("resultScore").textContent =
            `${correct}/${total}`;
    }

    if ($("resultXp")) {
        $("resultXp").textContent =
            `+${xp}`;
    }

    if ($("resultStars")) {
        $("resultStars").textContent =
            `+${stars}`;
    }

    if ($("resultIcon")) {

        $("resultIcon").textContent =
            passed
                ? "🏆"
                : noLives
                    ? "❤️‍🩹"
                    : "📚";
    }

    if ($("resultTitle")) {

        if (quizMode === "final") {

            $("resultTitle").textContent =
                passed
                    ? "PROVA APROVADA!"
                    : "Continue estudando!";

        } else {

            $("resultTitle").textContent =
                passed
                    ? "Excelente!"
                    : "Boa tentativa!";
        }
    }

    if ($("resultLabel")) {

        $("resultLabel").textContent =
            quizMode === "final"
                ? passed
                    ? "PROVA FINAL CONCLUÍDA"
                    : "PROVA FINAL"
                : "FASE CONCLUÍDA";
    }

    if ($("resultMessage")) {

        let message = "";

        if (quizMode === "final") {

            message = passed
                ? `🎉 Você conseguiu ${correct}/10 e atingiu a nota mínima de 6/10. O assunto foi dominado!`
                : `📖 Você fez ${correct}/10. Para passar na prova final, precisa conseguir pelo menos 6/10. Estude novamente e tente outra vez!`;

        } else if (passed) {

            message =
                `Você acertou ${correct} de ${total}. Continue assim para desbloquear as próximas fases!`;

        } else {

            message =
                `Você acertou ${correct} de ${total}. Revise as explicações e tente novamente.`;
        }

        $("resultMessage").textContent = message;
    }

    showScreen("result");
}

/* =========================================================
   NAVEGAÇÃO DO RESULTADO
========================================================= */

function backToLevels() {

    if (!currentSubject) {
        goHome();
        return;
    }

    renderLevels();
    updateFinalTestButton();

    showScreen("levels");
}

function exitQuiz() {

    const confirmExit =
        window.confirm(
            "Sair da questão? Seu progresso desta tentativa será perdido."
        );

    if (!confirmExit) return;

    if (quizMode === "level" || quizMode === "final") {

        if (currentSubject) {
            openSubject(currentSubject.id);
        } else {
            goHome();
        }

    } else {

        goHome();
    }
}

/* =========================================================
   RESETAR PROGRESSO
========================================================= */

function resetProgress() {

    const confirmed =
        window.confirm(
            "Tem certeza que deseja apagar todo o progresso?"
        );

    if (!confirmed) return;

    progress = defaultProgress();

    saveProgress();

    currentSubject = null;

    updateInterface();

    alert("🗑️ Progresso resetado!");

    goHome();
}

/* =========================================================
   EMBARALHAR
========================================================= */

function shuffle(array) {

    const arr = [...array];

    for (
        let i = arr.length - 1;
        i > 0;
        i--
    ) {

        const j =
            Math.floor(Math.random() * (i + 1));

        [arr[i], arr[j]] =
            [arr[j], arr[i]];
    }

    return arr;
}

/* =========================================================
   ESCAPAR HTML
========================================================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/* =========================================================
   FECHAR MODAIS CLICANDO FORA
========================================================= */

document.addEventListener("click", event => {

    const helpModal = $("helpModal");
    const learnModal = $("learnModal");

    if (
        helpModal &&
        event.target === helpModal
    ) {
        closeHelp();
    }

    if (
        learnModal &&
        event.target === learnModal
    ) {
        closeLearnModal();
    }
});

/* =========================================================
   TECLADO
========================================================= */

document.addEventListener("keydown", event => {

    if (!$("quiz")?.classList.contains("active")) {
        return;
    }

    if (
        ["1", "2", "3", "4"].includes(event.key)
    ) {

        const index =
            Number(event.key) - 1;

        const button =
            document.querySelector(
                `.answer-option[data-index="${index}"]`
            );

        if (
            button &&
            !button.disabled
        ) {
            answerQuestion(index);
        }
    }

    if (event.key === "Escape") {
        closeHelp();
    }
});

/* =========================================================
   INICIALIZAÇÃO
========================================================= */

function initializeGame() {

    updateInterface();

    renderSubjects();
    renderLearnTopics();
    renderPracticeSubjects();

    showScreen("home");
}

document.addEventListener(
    "DOMContentLoaded",
    initializeGame
);