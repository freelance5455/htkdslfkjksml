
const form = document.getElementById("videoForm");
const input = document.getElementById("videoUrl");
const player = document.getElementById("videoPlayer");
const container = document.getElementById("playerContainer");
const status = document.getElementById("status");

function getVideoId(value) {
  try {
    const url = new URL(value.trim());
    const host = url.hostname.toLowerCase();
    let id = "";

    if (
      host === "youtu.be" ||
      host === "www.youtu.be"
    ) {
      id = url.pathname.split("/").filter(Boolean)[0] || "";
    } else if (
      ["youtube.com", "www.youtube.com", "m.youtube.com",
       "youtube-nocookie.com", "www.youtube-nocookie.com"]
        .includes(host)
    ) {
      if (url.pathname === "/watch") {
        id = url.searchParams.get("v") || "";
      } else {
        const match = url.pathname.match(
          /^\/(?:embed|shorts|live)\/([^/]+)/
        );
        if (match) id = match[1];
      }
    }

    return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
  } catch {
    return null;
  }
}

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const id = getVideoId(input.value);

  if (!id) {
    status.textContent = "الرابط غير صالح. تحقق من رابط يوتيوب.";
    container.classList.add("hidden");
    player.removeAttribute("src");
    return;
  }

  status.textContent = "";
  player.src =
    "https://www.youtube-nocookie.com/embed/" +
    id + "?autoplay=1&rel=0";

  container.classList.remove("hidden");
});
