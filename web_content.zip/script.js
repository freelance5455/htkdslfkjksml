const $ = (id) => document.getElementById(id);
const toggles = ["aim", "hs", "health", "line", "box"];

function refreshPanel() {
  const anyEnabled = toggles.some((id) => $(id).checked);
  $("demo").style.display = anyEnabled || $("fovEnabled")?.checked ? "block" : "none";
  $("espBox").style.display = $("box").checked ? "block" : "none";
  $("espLine").style.display = $("line").checked ? "block" : "none";
  $("espHealth").style.display = $("health").checked ? "block" : "none";

  const size = Number($("fov").value);
  $("fovCircle").style.width = size + "px";
  $("fovCircle").style.height = size + "px";
  $("fovValue").textContent = size + " px";

  const count = toggles.filter((id) => $(id).checked).length;
  $("status").textContent = "● " + count + " DEMONSTRAÇÕES ATIVAS";
}

toggles.forEach((id) => $(id).addEventListener("change", refreshPanel));
$("fov").addEventListener("input", refreshPanel);

$("all").addEventListener("click", () => {
  toggles.forEach((id) => { $(id).checked = true; });
  refreshPanel();
});
$("off").addEventListener("click", () => {
  toggles.forEach((id) => { $(id).checked = false; });
  $("demo").style.display = "none";
  refreshPanel();
});
$("minimize").addEventListener("click", () => {
  $("controls").hidden = !$("controls").hidden;
});

let dragging = false, offsetX = 0, offsetY = 0;
const panel = $("panel");
const handle = $("dragHandle");

handle.addEventListener("pointerdown", (event) => {
  dragging = true;
  const rect = panel.getBoundingClientRect();
  offsetX = event.clientX - rect.left;
  offsetY = event.clientY - rect.top;
  panel.style.transform = "none";
  handle.setPointerCapture(event.pointerId);
});
handle.addEventListener("pointermove", (event) => {
  if (!dragging) return;
  panel.style.left = (event.clientX - offsetX) + "px";
  panel.style.top = (event.clientY - offsetY) + "px";
});
function stopDragging() { dragging = false; }
handle.addEventListener("pointerup", stopDragging);
handle.addEventListener("pointercancel", stopDragging);

refreshPanel();
