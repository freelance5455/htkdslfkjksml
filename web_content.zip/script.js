/* =========================================================
   TOURNAMENT MANAGER
   Complete CodePen Prototype
========================================================= */

const KEY = "TM_COMPLETE_V1";

let db = JSON.parse(localStorage.getItem(KEY) || "null") || {
  tournaments: [],
  current: null
};

let audioCtx = null;
let cricketMatchId = null;
let footballMatchId = null;

/* ---------- BASIC HELPERS ---------- */

function save(){
  localStorage.setItem(KEY, JSON.stringify(db));
}

function uid(prefix="id"){
  return prefix + Date.now().toString(36) +
    Math.random().toString(36).slice(2,7);
}

function escapeHTML(s){
  return String(s ?? "")
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

function teamById(t,id){
  return t.teams.find(x=>x.id===id);
}

function toast(msg){
  const el=document.getElementById("toast");
  el.textContent=msg;
  el.style.position="fixed";
  el.style.bottom="25px";
  el.style.left="50%";
  el.style.transform="translateX(-50%)";
  el.style.zIndex="5000";
  el.style.padding="12px 18px";
  el.style.borderRadius="12px";
  el.style.background="#162b47";
  el.style.border="1px solid rgba(255,255,255,.15)";
  el.style.boxShadow="0 15px 40px #000";
  setTimeout(()=>el.textContent="",2500);
}

function openModal(html){
  document.getElementById("modal").innerHTML=html;
  document.getElementById("overlay").classList.remove("hidden");
}

function closeModal(){
  document.getElementById("overlay").classList.add("hidden");
}

document.getElementById("overlay").addEventListener("click",e=>{
  if(e.target.id==="overlay") closeModal();
});

/* ---------- SOUND ---------- */

function getAudio(){
  if(!audioCtx){
    audioCtx=new (window.AudioContext || window.webkitAudioContext)();
  }
  return audioCtx;
}

function beep(freq,duration,type="sine",volume=.08){
  try{
    const ctx=getAudio();
    const osc=ctx.createOscillator();
    const gain=ctx.createGain();

    osc.type=type;
    osc.frequency.value=freq;
    gain.gain.setValueAtTime(volume,ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(
      .001,
      ctx.currentTime+duration
    );

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime+duration);
  }catch(e){}
}

function soundGoal(){
  beep(440,.12,"triangle",.12);
  setTimeout(()=>beep(660,.15,"triangle",.12),100);
  setTimeout(()=>beep(880,.3,"triangle",.14),210);
}

function soundFour(){
  beep(330,.1,"square",.08);
  setTimeout(()=>beep(440,.1,"square",.08),90);
  setTimeout(()=>beep(660,.35,"square",.1),180);
}

function soundSix(){
  beep(440,.1,"sawtooth",.08);
  setTimeout(()=>beep(660,.1,"sawtooth",.08),90);
  setTimeout(()=>beep(880,.1,"sawtooth",.08),180);
  setTimeout(()=>beep(1100,.5,"triangle",.13),280);
}

function soundWicket(){
  beep(120,.25,"sawtooth",.13);
  setTimeout(()=>beep(70,.4,"sawtooth",.13),200);
}

function soundCard(){
  beep(180,.18,"square",.09);
}

/* ---------- ANIMATIONS ---------- */

function celebration(text){
  const wrap=document.createElement("div");
  wrap.className="event-overlay";

  const title=document.createElement("div");
  title.className="event-text";
  title.textContent=text;

  wrap.appendChild(title);

  for(let i=0;i<70;i++){
    const c=document.createElement("div");
    c.className="confetti";
    c.style.left=Math.random()*100+"%";
    c.style.top=(-Math.random()*30)+"%";
    c.style.animationDelay=Math.random()*.5+"s";
    c.style.transform=`rotate(${Math.random()*360}deg)`;
    c.style.background=
      ["#00d4ff","#7c4dff","#19e68c","#ffd21f","#ff4057","#ff8a00"]
      [Math.floor(Math.random()*6)];
    wrap.appendChild(c);
  }

  document.body.appendChild(wrap);

  setTimeout(()=>wrap.remove(),1800);
}

function cardAnimation(card){
  const x=document.createElement("div");
  x.className="card-event";
  x.textContent=card==="Y"?"🟨":"🟥";
  document.body.appendChild(x);
  setTimeout(()=>x.remove(),900);
}

/* ---------- HOME ---------- */

function goHome(){
  renderHome();
}

function renderHome(){
  document.getElementById("screen").innerHTML=`
    <section class="hero">
      <div class="hero-content">
        <div style="font-size:18px;color:#00d4ff;margin-bottom:15px">
          ⚡ PROFESSIONAL SPORTS TOURNAMENT PLATFORM
        </div>

        <h1>Tournament<br>Manager</h1>

        <p>
          Create tournaments • Manage matches • Track live scores •
          Find Champions
        </p>

        <div class="sports">

          <div class="sport-card">
            <div class="sport-icon">⚽</div>
            <h2>Football</h2>
            <p>
              Knockout, League, Goals, Cards,
              Scorers and Final.
            </p>
            <button class="btn" onclick="startSetup('football')">
              Create Football Tournament
            </button>
          </div>

          <div class="sport-card">
            <div class="sport-icon">🏏</div>
            <h2>Cricket</h2>
            <p>
              Overs, runs, wickets, batsmen,
              bowlers and live scoring.
            </p>
            <button class="btn" onclick="startSetup('cricket')">
              Create Cricket Tournament
            </button>
          </div>

        </div>
      </div>
    </section>
  `;
}

/* ---------- SETUP ---------- */

function startSetup(sport){
  document.getElementById("screen").innerHTML=`
    <div class="section-title">
      ${sport==="football"?"⚽":"🏏"} Create Tournament
    </div>

    <div class="section-sub">
      Customize your tournament
    </div>

    <div class="panel">

      <div class="grid grid2">

        <div>
          <label>Tournament Name</label>
          <input id="tName" value="${
            sport==="football"?"Football Championship":"Cricket Championship"
          }">
        </div>

        <div>
          <label>Format</label>
          <select id="format" onchange="toggleFormatHelp()">
            <option value="knockout">Knockout</option>
            <option value="league">League</option>
          </select>
        </div>

      </div>

      <br>

      <div class="grid grid2">

        <div>
          <label>Number of Teams</label>
          <input
            id="teamCount"
            type="number"
            min="2"
            max="32"
            value="8"
            onchange="generateTeamInputs()"
          >
        </div>

        ${
          sport==="cricket"
          ?`
          <div>
            <label>Overs per innings</label>
            <input id="overs" type="number" min="1" max="50" value="4">
          </div>
          `
          :`
          <div>
            <label>Football Match Duration (minutes)</label>
            <input id="duration" type="number" min="5" max="180" value="90">
          </div>
          `
        }

      </div>

      <div id="formatHelp" style="margin-top:15px;color:#9eb0c7"></div>

    </div>

    <div class="panel">
      <h3>Teams</h3>
      <p style="color:#9eb0c7;font-size:13px;margin:6px 0 18px">
        Team name + logo മാത്രം നൽകുക.
        Players പിന്നീട് match സമയത്ത് ചേർക്കാം.
      </p>

      <div id="teamInputs" class="grid grid2"></div>
    </div>

    <button class="btn" onclick="createTournament('${sport}')">
      🚀 Create Tournament
    </button>
  `;

  generateTeamInputs();
  toggleFormatHelp();
}

function toggleFormatHelp(){
  const f=document.getElementById("format").value;
  const h=document.getElementById("formatHelp");

  if(f==="knockout"){
    h.innerHTML=
      "🏆 Knockout: Winners automatically progress " +
      "through Quarter Final → Semi Final → Final.";
  }else{
    h.innerHTML=
      "📊 League: All teams play according to an automatic fixture schedule.";
  }
}

function generateTeamInputs(){
  const box=document.getElementById("teamInputs");
  if(!box) return;

  let n=Math.max(
    2,
    Math.min(32,
      Number(document.getElementById("teamCount").value)||8
    )
  );

  let html="";

  for(let i=1;i<=n;i++){
    html+=`
      <div class="team-card">
        <h4>Team ${i}</h4>

        <label>Team Name</label>
        <input id="teamName${i}" value="Team ${i}">

        <label style="margin-top:10px">
          Logo URL (optional)
        </label>
        <input
          id="teamLogo${i}"
          placeholder="https://..."
        >
      </div>
    `;
  }

  box.innerHTML=html;
}

/* ---------- CREATE TOURNAMENT ---------- */

function createTournament(sport){

  const name=document.getElementById("tName").value.trim() ||
    "Tournament";

  const format=document.getElementById("format").value;

  const count=Math.max(
    2,
    Math.min(32,
      Number(document.getElementById("teamCount").value)||8
    )
  );

  const teams=[];

  for(let i=1;i<=count;i++){
    teams.push({
      id:uid("team"),
      name:
        document.getElementById("teamName"+i).value.trim()
        ||"Team "+i,
      logo:
        document.getElementById("teamLogo"+i).value.trim()
        ||""
    });
  }

  const t={
    id:uid("t"),
    name,
    sport,
    format,
    teams,
    createdAt:new Date().toISOString(),
    cricketOvers:
      sport==="cricket"
      ?Number(document.getElementById("overs").value)||4
      :null,
    footballDuration:
      sport==="football"
      ?Number(document.getElementById("duration").value)||90
      :null,

    matches:[],
    bracket:null,

    stats:{
      football:{},
      cricket:{}
    },

    champion:null
  };

  if(format==="knockout"){
    buildKnockout(t);
  }else{
    buildLeague(t);
  }

  db.tournaments.push(t);
  db.current=t.id;

  save();

  renderTournament(t.id);
}

/* ---------- KNOCKOUT ---------- */

function nextPowerOfTwo(n){
  let p=1;
  while(p<n)p*=2;
  return p;
}

function buildKnockout(t){

  let size=nextPowerOfTwo(t.teams.length);

  const shuffled=[...t.teams]
    .sort(()=>Math.random()-.5);

  while(shuffled.length<size){
    shuffled.push(null);
  }

  const rounds=[];

  const firstRoundMatches=[];

  for(let i=0;i<size;i+=2){

    const a=shuffled[i];
    const b=shuffled[i+1];

    firstRoundMatches.push({
      id:uid("m"),
      round:roundName(size),
      home:a?a.id:null,
      away:b?b.id:null,
      homeScore:0,
      awayScore:0,
      status:"scheduled",
      winner:null,
      events:[],
      football:{
        goals:[],
        yellow:[],
        red:[]
      }
    });
  }

  rounds.push(firstRoundMatches);

  let current=size;

  while(current>2){

    current=current/2;

    const arr=[];

    for(let i=0;i<current;i++){

      arr.push({
        id:uid("m"),
        round:roundName(current*2),
        home:null,
        away:null,
        homeScore:0,
        awayScore:0,
        status:"waiting",
        winner:null,
        events:[],
        football:{
          goals:[],
          yellow:[],
          red:[]
        }
      });
    }

    rounds.push(arr);
  }

  rounds.push([{
    id:uid("m"),
    round:"Final",
    home:null,
    away:null,
    homeScore:0,
    awayScore:0,
    status:"waiting",
    winner:null,
    events:[],
    football:{
      goals:[],
      yellow:[],
      red:[]
    }
  }]);

  t.bracket=rounds;

  t.matches=rounds.flat();

  // byes / automatic advancement
  rounds[0].forEach(m=>{
    if(m.home && !m.away){
      m.winner=m.home;
      m.status="bye";
    }

    if(m.away && !m.home){
      m.winner=m.away;
      m.status="bye";
    }

    if(!m.home && !m.away){
      m.status="bye";
    }
  });

  propagateKnockout(t);
}

function roundName(size){
  if(size===2)return"Round of 2";
  if(size===4)return"Semi Final";
  if(size===8)return"Quarter Final";
  if(size===16)return"Round of 16";
  if(size===32)return"Round of 32";
  return"Round";
}

function propagateKnockout(t){

  const rounds=t.bracket;

  for(let r=0;r<rounds.length-1;r++){

    const current=rounds[r];
    const next=rounds[r+1];

    current.forEach((m,i)=>{

      if(!m.winner)return;

      const nextIndex=Math.floor(i/2);
      const slot=i%2===0?"home":"away";

      if(next[nextIndex]){
        next[nextIndex][slot]=m.winner;

        if(
          next[nextIndex].home &&
          next[nextIndex].away &&
          next[nextIndex].status==="waiting"
        ){
          next[nextIndex].status="scheduled";
        }
      }
    });
  }

  t.matches=t.bracket.flat();

  const final=t.bracket[t.bracket.length-1][0];

  if(final.winner){
    t.champion=final.winner;
  }
}

/* ---------- LEAGUE ---------- */

function buildLeague(t){

  const teams=[...t.teams];

  let list=[...teams];

  if(list.length%2!==0){
    list.push(null);
  }

  const n=list.length;
  const rounds=n-1;
  const half=n/2;

  for(let r=0;r<rounds;r++){

    for(let i=0;i<half;i++){

      const a=list[i];
      const b=list[n-1-i];

      if(a && b){

        t.matches.push({
          id:uid("m"),
          round:"League",
          home:a.id,
          away:b.id,
          homeScore:0,
          awayScore:0,
          status:"scheduled",
          winner:null,
          events:[],
          football:{
            goals:[],
            yellow:[],
            red:[]
          }
        });

      }
    }

    list=[
      list[0],
      list[n-1],
      ...list.slice(1,n-1)
    ];
  }
}

/* ---------- TOURNAMENT HOME ---------- */

function renderTournament(id){

  const t=db.tournaments.find(x=>x.id===id);

  if(!t)return goHome();

  db.current=id;
  save();

  let html=`

    <div class="section-title">
      ${t.sport==="football"?"⚽":"🏏"} ${escapeHTML(t.name)}
    </div>

    <div class="section-sub">
      ${t.teams.length} Teams •
      ${t.format==="knockout"?"Knockout":"League"}
    </div>

    <div class="actions">
      <button class="btn" onclick="renderFixtures('${t.id}')">
        🗓️ Fixtures
      </button>

      <button class="btn dark" onclick="renderPoints('${t.id}')">
        📊 Points Table
      </button>

      <button class="btn dark" onclick="renderStats('${t.id}')">
        🏅 Statistics
      </button>

      <button class="btn dark" onclick="showTournamentQR('${t.id}')">
        📱 QR Viewer
      </button>
    </div>
  `;

  if(t.format==="knockout"){
    html+=renderBracketHTML(t);
  }

  if(t.champion){
    const champ=teamById(t,t.champion);

    html+=`
      <div class="champion">
        <div class="cup">🏆</div>
        <div style="color:#ffd21f">TOURNAMENT CHAMPION</div>
        <h1>${escapeHTML(champ?.name||"Champion")}</h1>
      </div>
    `;
  }

  html+=`
    <div class="panel" style="margin-top:20px">
      <h3>Teams</h3>
      <div class="grid grid3" style="margin-top:15px">
        ${t.teams.map(x=>`
          <div class="team-card">
            ${
              x.logo
              ?`<img class="team-logo" src="${escapeHTML(x.logo)}">`
              :""
            }
            <div style="margin-top:8px;font-weight:800">
              ${escapeHTML(x.name)}
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `;

  document.getElementById("screen").innerHTML=html;
}

function renderBracketHTML(t){

  return`
    <div class="panel" style="margin-top:20px">
      <h3>🏆 Knockout Bracket</h3>

      <div class="bracket">

        ${t.bracket.map((round,i)=>`

          <div class="round">

            <div class="round-title">
              ${escapeHTML(round[0]?.round||"Round")}
            </div>

            ${round.map(m=>`

              <div class="bracket-match">

                <div class="
                  tm
                  ${m.winner===m.home?"winner":""}
                ">
                  <span>
                    ${escapeHTML(teamById(t,m.home)?.name || "TBD")}
                  </span>
                  <b>${m.status==="scheduled"||m.status==="finished"?m.homeScore:""}</b>
                </div>

                <div class="
                  tm
                  ${m.winner===m.away?"winner":""}
                ">
                  <span>
                    ${escapeHTML(teamById(t,m.away)?.name || "TBD")}
                  </span>
                  <b>${m.status==="scheduled"||m.status==="finished"?m.awayScore:""}</b>
                </div>

                ${
                  m.status==="scheduled"
                  ?`
                    <button
                      class="btn small"
                      style="width:100%;margin-top:8px"
                      onclick="openMatch('${t.id}','${m.id}')">
                      ⚽ Start Match
                    </button>
                  `
                  :""
                }

                ${
                  m.status==="finished"
                  ?`
                    <div style="text-align:center;margin-top:7px">
                      <span class="badge green">Winner advances</span>
                    </div>
                  `
                  :""
                }

                ${
                  m.status==="bye"
                  ?`
                    <div style="text-align:center;margin-top:7px">
                      <span class="badge">BYE / AUTO ADVANCE</span>
                    </div>
                  `
                  :""
                }

              </div>

            `).join("")}

          </div>

        `).join("")}

      </div>
    </div>
  `;
}

/* ---------- FIXTURES ---------- */

function renderFixtures(id){

  const t=db.tournaments.find(x=>x.id===id);

  if(!t)return;

  document.getElementById("screen").innerHTML=`

    <div class="section-title">🗓️ Fixtures</div>

    <div class="section-sub">
      ${escapeHTML(t.name)}
    </div>

    <div class="grid grid2">

      ${t.matches.map(m=>{

        const a=teamById(t,m.home);
        const b=teamById(t,m.away);

        if(!a || !b)return"";

        return`
          <div class="match-card">

            <div class="match-top">
              <span>${escapeHTML(m.round)}</span>
              <span>
                ${
                  m.status==="finished"
                  ?"FINISHED"
                  :m.status==="scheduled"
                  ?"SCHEDULED"
                  :"WAITING"
                }
              </span>
            </div>

            <div class="match-teams">

              <div>
                <div class="team-name">${escapeHTML(a.name)}</div>
              </div>

              <div>
                ${
                  m.status==="finished"
                  ?`
                    <b style="font-size:22px">
                      ${m.homeScore} - ${m.awayScore}
                    </b>
                  `
                  :"VS"
                }
              </div>

              <div>
                <div class="team-name">${escapeHTML(b.name)}</div>
              </div>

            </div>

            ${
              m.status==="scheduled"
              ?`
                <button
                  class="btn"
                  style="width:100%;margin-top:15px"
                  onclick="openMatch('${t.id}','${m.id}')">
                  ${t.sport==="football"?"⚽ Start Match":"🏏 Start Match"}
                </button>
              `
              :""
            }

          </div>
        `;

      }).join("")}

    </div>

    <button
      class="btn dark"
      style="margin-top:20px"
      onclick="renderTournament('${t.id}')">
      ← Back
    </button>
  `;
}

/* ---------- OPEN MATCH ---------- */

function openMatch(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  if(!m.home || !m.away){
    toast("Teams are not ready yet.");
    return;
  }

  if(t.sport==="football"){
    footballMatchId=mid;
    renderFootballMatch(tid,mid);
  }else{
    cricketMatchId=mid;
    prepareCricketMatch(tid,mid);
  }
}

/* =========================================================
   FOOTBALL
========================================================= */

function renderFootballMatch(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const a=teamById(t,m.home);
  const b=teamById(t,m.away);

  document.getElementById("screen").innerHTML=`

    <div class="section-title">⚽ Football Live Match</div>

    <div class="panel live-scoreboard">

      <div class="match-top">
        <span>${escapeHTML(m.round)}</span>
        <span class="live">LIVE</span>
      </div>

      <div class="match-teams">

        <div>
          <div class="team-name">${escapeHTML(a.name)}</div>
          <div class="score-big">${m.homeScore}</div>
        </div>

        <div style="font-size:28px;color:#778ba5">
          :
        </div>

        <div>
          <div class="team-name">${escapeHTML(b.name)}</div>
          <div class="score-big">${m.awayScore}</div>
        </div>

      </div>

      <div class="actions" style="justify-content:center">

        <button
          class="btn green"
          onclick="footballGoal('${tid}','${mid}')">
          ⚽ GOAL
        </button>

        <button
          class="btn yellow"
          onclick="footballCard('${tid}','${mid}','Y')">
          🟨 YELLOW CARD
        </button>

        <button
          class="btn red"
          onclick="footballCard('${tid}','${mid}','R')">
          🟥 RED CARD
        </button>

      </div>

    </div>

    <div class="grid grid2">

      <div class="panel">
        <h3>⚽ Goal Scorers</h3>

        <div style="margin-top:15px">
          ${
            m.football.goals.length
            ?
            m.football.goals.map(g=>`
              <div class="player-row">
                <span>
                  ${escapeHTML(g.player)}
                  <small style="color:#9eb0c7">
                    (${escapeHTML(
                      teamById(t,g.team)?.name||""
                    )})
                  </small>
                </span>
                <span class="badge green">GOAL</span>
              </div>
            `).join("")
            :
            `<div class="empty">No goals yet</div>`
          }
        </div>
      </div>

      <div class="panel">
        <h3>🟨🟥 Cards</h3>

        <div style="margin-top:15px">

          ${
            m.football.yellow.map(x=>`
              <div class="player-row">
                <span>${escapeHTML(x.player)}</span>
                <span class="badge yellow">YELLOW</span>
              </div>
            `).join("")
          }

          ${
            m.football.red.map(x=>`
              <div class="player-row">
                <span>${escapeHTML(x.player)}</span>
                <span class="badge red">RED</span>
              </div>
            `).join("")
          }

          ${
            !m.football.yellow.length &&
            !m.football.red.length
            ?`<div class="empty">No cards yet</div>`
            :""
          }

        </div>
      </div>

    </div>

    <div class="panel">

      <h3>Match Controls</h3>

      <div class="actions">

        <button class="btn dark"
          onclick="undoFootball('${tid}','${mid}')">
          ↩ Undo Last Goal
        </button>

        <button class="btn red"
          onclick="finishFootball('${tid}','${mid}')">
          🏁 End Match
        </button>

      </div>

    </div>

  `;
}

function footballGoal(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  openModal(`
    <div class="modal-head">
      <h3>⚽ Goal</h3>
      <button class="close" onclick="closeModal()">✕</button>
    </div>

    <label>Scoring Team</label>
    <select id="goalTeam">
      <option value="${m.home}">
        ${escapeHTML(teamById(t,m.home).name)}
      </option>
      <option value="${m.away}">
        ${escapeHTML(teamById(t,m.away).name)}
      </option>
    </select>

    <label style="margin-top:15px">
      Player Name
    </label>

    <input
      id="goalPlayer"
      placeholder="Enter goal scorer"
    >

    <button
      class="btn green"
      style="width:100%;margin-top:20px"
      onclick="saveGoal('${tid}','${mid}')">
      ⚽ Confirm Goal
    </button>
  `);
}

function saveGoal(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const team=document.getElementById("goalTeam").value;
  const player=
    document.getElementById("goalPlayer").value.trim()
    ||"Unknown Player";

  if(team===m.home)m.homeScore++;
  else m.awayScore++;

  m.football.goals.push({
    team,
    player,
    time:new Date().toISOString()
  });

  updateFootballStats(t,team,player);

  save();
  closeModal();

  soundGoal();
  celebration("⚽ GOAL!");

  renderFootballMatch(tid,mid);
}

function updateFootballStats(t,teamId,player){

  if(!t.stats.football[player]){
    t.stats.football[player]={
      player,
      team:teamId,
      goals:0,
      yellow:0,
      red:0
    };
  }

  t.stats.football[player].goals++;
}

function footballCard(tid,mid,type){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  openModal(`
    <div class="modal-head">
      <h3>${type==="Y"?"🟨 Yellow Card":"🟥 Red Card"}</h3>
      <button class="close" onclick="closeModal()">✕</button>
    </div>

    <label>Team</label>

    <select id="cardTeam">
      <option value="${m.home}">
        ${escapeHTML(teamById(t,m.home).name)}
      </option>

      <option value="${m.away}">
        ${escapeHTML(teamById(t,m.away).name)}
      </option>
    </select>

    <label style="margin-top:15px">
      Player
    </label>

    <input id="cardPlayer" placeholder="Player name">

    <button
      class="btn ${type==="Y"?"yellow":"red"}"
      style="width:100%;margin-top:20px"
      onclick="saveCard('${tid}','${mid}','${type}')">
      Confirm Card
    </button>
  `);
}

function saveCard(tid,mid,type){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const team=document.getElementById("cardTeam").value;

  const player=
    document.getElementById("cardPlayer").value.trim()
    ||"Unknown Player";

  const obj={team,player};

  if(type==="Y")m.football.yellow.push(obj);
  else m.football.red.push(obj);

  if(!t.stats.football[player]){
    t.stats.football[player]={
      player,
      team,
      goals:0,
      yellow:0,
      red:0
    };
  }

  if(type==="Y")t.stats.football[player].yellow++;
  else t.stats.football[player].red++;

  save();
  closeModal();

  soundCard();
  cardAnimation(type);

  renderFootballMatch(tid,mid);
}

function undoFootball(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const g=m.football.goals.pop();

  if(!g){
    toast("No goal to undo.");
    return;
  }

  if(g.team===m.home)m.homeScore=Math.max(0,m.homeScore-1);
  else m.awayScore=Math.max(0,m.awayScore-1);

  if(t.stats.football[g.player]){
    t.stats.football[g.player].goals=
      Math.max(0,t.stats.football[g.player].goals-1);
  }

  save();
  renderFootballMatch(tid,mid);
}

function finishFootball(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  if(m.homeScore===m.awayScore){

    openModal(`
      <div class="modal-head">
        <h3>⚠️ Match Draw</h3>
        <button class="close" onclick="closeModal()">✕</button>
      </div>

      <p style="color:#9eb0c7">
        Knockout match cannot end in a draw.
        Choose the winning team.
      </p>

      <div class="actions">

        <button class="btn"
          onclick="setFootballWinner('${tid}','${mid}','${m.home}')">
          ${escapeHTML(teamById(t,m.home).name)} Wins
        </button>

        <button class="btn"
          onclick="setFootballWinner('${tid}','${mid}','${m.away}')">
          ${escapeHTML(teamById(t,m.away).name)} Wins
        </button>

      </div>
    `);

    return;
  }

  const winner=
    m.homeScore>m.awayScore
    ?m.home
    :m.away;

  setFootballWinner(tid,mid,winner);
}

function setFootballWinner(tid,mid,winner){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  m.winner=winner;
  m.status="finished";

  propagateKnockout(t);

  save();
  closeModal();

  const team=teamById(t,winner);

  celebration("🏆 "+team.name);

  renderTournament(tid);
}

/* =========================================================
   CRICKET
========================================================= */

function prepareCricketMatch(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  if(!m.cricket){

    m.cricket={
      innings:1,
      inningsData:[
        makeInnings(m.home),
        makeInnings(m.away)
      ]
    };

    m.status="live";

    save();
  }

  showCricketSetup(tid,mid);
}

function makeInnings(teamId){

  return{
    team:teamId,
    score:0,
    wickets:0,
    balls:0,
    overs:0,
    striker:null,
    nonStriker:null,
    bowler:null,
    batsmen:{},
    bowlers:{},
    history:[],
    completed:false
  };
}

function showCricketSetup(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const inn=m.cricket.inningsData[m.cricket.innings-1];

  const striker=inn.striker?"":"";

  openModal(`
    <div class="modal-head">
      <h3>
        🏏 ${
          m.cricket.innings===1
          ?"1st Innings"
          :"2nd Innings"
        }
      </h3>

      <button class="close" onclick="closeModal()">✕</button>
    </div>

    <p style="color:#9eb0c7;margin-bottom:15px">
      Current batting team:
      <b style="color:white">
        ${escapeHTML(teamById(t,inn.team).name)}
      </b>
    </p>

    <label>Striker / Opening batsman</label>
    <input id="cStriker" placeholder="Player name">

    <label style="margin-top:12px">
      Non-striker
    </label>
    <input id="cNonStriker" placeholder="Player name">

    <label style="margin-top:12px">
      Bowler
    </label>
    <input id="cBowler" placeholder="Bowler name">

    <button
      class="btn"
      style="width:100%;margin-top:20px"
      onclick="startCricketInnings('${tid}','${mid}')">
      🏏 Start Innings
    </button>
  `);
}

function startCricketInnings(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);
  const inn=m.cricket.inningsData[m.cricket.innings-1];

  const striker=
    document.getElementById("cStriker").value.trim()
    ||"Batsman 1";

  const nonStriker=
    document.getElementById("cNonStriker").value.trim()
    ||"Batsman 2";

  const bowler=
    document.getElementById("cBowler").value.trim()
    ||"Bowler 1";

  inn.striker=striker;
  inn.nonStriker=nonStriker;
  inn.bowler=bowler;

  ensureBatsman(inn,striker);
  ensureBatsman(inn,nonStriker);
  ensureBowler(inn,bowler);

  save();
  closeModal();

  renderCricket(tid,mid);
}

function ensureBatsman(inn,name){

  if(!inn.batsmen[name]){
    inn.batsmen[name]={
      name,
      runs:0,
      balls:0,
      out:false
    };
  }
}

function ensureBowler(inn,name){

  if(!inn.bowlers[name]){
    inn.bowlers[name]={
      name,
      runs:0,
      wickets:0,
      balls:0
    };
  }
}

function renderCricket(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);
  const inn=m.cricket.inningsData[m.cricket.innings-1];

  const batting=teamById(t,inn.team);

  const target=
    m.cricket.innings===2
    ?m.cricket.inningsData[0].score+1
    :null;

  document.getElementById("screen").innerHTML=`

    <div class="section-title">🏏 Cricket Live Match</div>

    <div class="innings-banner">
      <div class="live">LIVE</div>

      <h2 style="margin-top:8px">
        ${m.cricket.innings===1?"1st":"2nd"} Innings
      </h2>

      <p style="color:#9eb0c7;margin-top:5px">
        ${escapeHTML(batting.name)}
      </p>
    </div>

    <div class="panel live-scoreboard">

      <div class="score-row">

        <div>
          <div class="team-name">
            ${escapeHTML(batting.name)}
          </div>

          <div class="score-big">
            ${inn.score}/${inn.wickets}
          </div>

          <div style="text-align:center;color:#9eb0c7">
            ${inn.overs}.${inn.balls%6}
            / ${t.cricketOvers} overs
          </div>
        </div>

      </div>

      ${
        target
        ?`
          <div style="text-align:center;margin-top:15px">
            Target:
            <b>${target}</b>
            <br>
            <span style="color:#9eb0c7">
              Need ${Math.max(0,target-inn.score)} runs
            </span>
          </div>
        `
        :""
      }

    </div>

    <div class="grid grid2">

      <div class="panel">

        <h3>🏏 Current Players</h3>

        <div class="player-row">
          <span>
            ⭐ ${escapeHTML(inn.striker)}
          </span>
          <b>
            ${inn.batsmen[inn.striker]?.runs||0}
          </b>
        </div>

        <div class="player-row">
          <span>
            ${escapeHTML(inn.nonStriker)}
          </span>
          <b>
            ${inn.batsmen[inn.nonStriker]?.runs||0}
          </b>
        </div>

        <div class="player-row">
          <span>🎯 Bowler</span>
          <b>${escapeHTML(inn.bowler||"-")}</b>
        </div>

      </div>

      <div class="panel">

        <h3>🎮 Match Controls</h3>

        <div class="match-controls">

          <button class="control-btn"
            onclick="cricketRun('${tid}','${mid}',0)">
            0
          </button>

          <button class="control-btn"
            onclick="cricketRun('${tid}','${mid}',1)">
            1
          </button>

          <button class="control-btn"
            onclick="cricketRun('${tid}','${mid}',2)">
            2
          </button>

          <button class="control-btn"
            onclick="cricketRun('${tid}','${mid}',3)">
            3
          </button>

          <button class="control-btn four"
            onclick="cricketRun('${tid}','${mid}',4)">
            4️⃣ FOUR
          </button>

          <button class="control-btn six"
            onclick="cricketRun('${tid}','${mid}',6)">
            6️⃣ SIX
          </button>

          <button class="control-btn wicket"
            onclick="cricketWicket('${tid}','${mid}')">
            ❌ WICKET
          </button>

          <button class="control-btn"
            onclick="cricketExtra('${tid}','${mid}','wide')">
            WIDE
          </button>

          <button class="control-btn"
            onclick="cricketExtra('${tid}','${mid}','noball')">
            NO BALL
          </button>

        </div>

      </div>

    </div>

    <div class="panel">

      <h3>📊 Current Scorecard</h3>

      <div class="table-wrap">

        <table>

          <thead>
            <tr>
              <th>Batsman</th>
              <th>R</th>
              <th>B</th>
              <th>Status</th>
            </tr>
          </thead>

          <tbody>

            ${Object.values(inn.batsmen).map(p=>`
              <tr>
                <td>${escapeHTML(p.name)}</td>
                <td>${p.runs}</td>
                <td>${p.balls}</td>
                <td>
                  ${
                    p.out
                    ?'<span class="badge red">OUT</span>'
                    :'<span class="badge green">NOT OUT</span>'
                  }
                </td>
              </tr>
            `).join("")}

          </tbody>

        </table>

      </div>

    </div>

    <div class="panel">

      <h3>🎯 Bowlers</h3>

      <div class="table-wrap">

        <table>

          <thead>
            <tr>
              <th>Bowler</th>
              <th>Overs</th>
              <th>Runs</th>
              <th>Wickets</th>
            </tr>
          </thead>

          <tbody>

            ${Object.values(inn.bowlers).map(p=>`
              <tr>
                <td>${escapeHTML(p.name)}</td>
                <td>${Math.floor(p.balls/6)}.${p.balls%6}</td>
                <td>${p.runs}</td>
                <td>${p.wickets}</td>
              </tr>
            `).join("")}

          </tbody>

        </table>

      </div>

    </div>

  `;

}

/* ---------- CRICKET RUN ---------- */

function cricketRun(tid,mid,runs){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);
  const inn=m.cricket.inningsData[m.cricket.innings-1];

  ensureBatsman(inn,inn.striker);
  ensureBowler(inn,inn.bowler);

  const bat=inn.batsmen[inn.striker];
  const bowl=inn.bowlers[inn.bowler];

  bat.runs+=runs;
  bat.balls++;

  bowl.runs+=runs;
  bowl.balls++;

  inn.score+=runs;
  inn.balls++;

  inn.history.push({
    type:"run",
    runs,
    striker:inn.striker
  });

  if(runs%2===1){
    swapStrike(inn);
  }

  if(runs===4){
    soundFour();
    celebration("4️⃣ FOUR!");
  }

  if(runs===6){
    soundSix();
    celebration("6️⃣ SIX!");
  }

  if(inn.balls>=6){
    completeOver(t,m,inn);
  }

  save();

  checkCricketEnd(tid,mid);
}

/* ---------- EXTRAS ---------- */

function cricketExtra(tid,mid,type){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);
  const inn=m.cricket.inningsData[m.cricket.innings-1];

  ensureBowler(inn,inn.bowler);

  inn.score++;
  inn.bowlers[inn.bowler].runs++;

  inn.history.push({
    type,
    runs:1
  });

  if(type==="wide"){
    toast("Wide +1");
  }else{
    toast("No Ball +1");
  }

  save();

  renderCricket(tid,mid);
}

/* ---------- WICKET ---------- */

function cricketWicket(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);
  const inn=m.cricket.inningsData[m.cricket.innings-1];

  openModal(`
    <div class="modal-head">
      <h3>❌ Wicket</h3>
      <button class="close" onclick="closeModal()">✕</button>
    </div>

    <label>Who is out?</label>

    <select id="outPlayer">

      <option value="${escapeHTML(inn.striker)}">
        ${escapeHTML(inn.striker)} (Striker)
      </option>

      <option value="${escapeHTML(inn.nonStriker)}">
        ${escapeHTML(inn.nonStriker)} (Non-striker)
      </option>

    </select>

    <label style="margin-top:15px">
      Incoming Batsman
    </label>

    <input id="incoming" placeholder="New batsman">

    <button
      class="btn red"
      style="width:100%;margin-top:20px"
      onclick="saveWicket('${tid}','${mid}')">
      ❌ Confirm Wicket
    </button>
  `);
}

function saveWicket(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);
  const inn=m.cricket.inningsData[m.cricket.innings-1];

  const out=document.getElementById("outPlayer").value;

  const incoming=
    document.getElementById("incoming").value.trim()
    ||"Batsman "+(Object.keys(inn.batsmen).length+1);

  ensureBatsman(inn,out);
  ensureBatsman(inn,incoming);
  ensureBowler(inn,inn.bowler);

  inn.batsmen[out].out=true;

  inn.wickets++;

  inn.balls++;

  inn.bowlers[inn.bowler].balls++;
  inn.bowlers[inn.bowler].wickets++;

  if(out===inn.striker){
    inn.striker=incoming;
  }else{
    inn.nonStriker=incoming;
  }

  inn.history.push({
    type:"wicket",
    out
  });

  closeModal();

  soundWicket();
  celebration("❌ WICKET!");

  if(inn.balls>=6){
    completeOver(t,m,inn);
  }

  save();

  checkCricketEnd(tid,mid);
}

/* ---------- OVER ---------- */

function completeOver(t,m,inn){

  inn.overs++;

  inn.balls=0;

  swapStrike(inn);

  if(inn.overs>=t.cricketOvers){

    inn.completed=true;

    checkCricketEnd(t.id,m.id);

    return;
  }

  openModal(`
    <div class="modal-head">
      <h3>🏏 Over Complete</h3>
    </div>

    <p style="color:#9eb0c7">
      ${inn.overs} over completed.
      Enter the next bowler.
    </p>

    <label style="margin-top:15px">
      Next Bowler
    </label>

    <input id="nextBowler" placeholder="Bowler name">

    <button
      class="btn"
      style="width:100%;margin-top:20px"
      onclick="setNextBowler('${t.id}','${m.id}')">
      Continue Over
    </button>
  `);
}

function setNextBowler(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const inn=m.cricket.inningsData[m.cricket.innings-1];

  const b=
    document.getElementById("nextBowler").value.trim()
    ||"Bowler "+(Object.keys(inn.bowlers).length+1);

  inn.bowler=b;

  ensureBowler(inn,b);

  save();
  closeModal();

  renderCricket(tid,mid);
}

function swapStrike(inn){

  const temp=inn.striker;
  inn.striker=inn.nonStriker;
  inn.nonStriker=temp;
}

/* ---------- END CRICKET ---------- */

function checkCricketEnd(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const idx=m.cricket.innings-1;
  const inn=m.cricket.inningsData[idx];

  const target=
    idx===1
    ?m.cricket.inningsData[0].score+1
    :null;

  let ended=false;

  if(inn.completed)ended=true;

  if(inn.wickets>=10)ended=true;

  if(idx===1 && inn.score>=target){
    ended=true;
  }

  if(!ended){
    renderCricket(tid,mid);
    return;
  }

  inn.completed=true;

  save();

  if(idx===0){

    openModal(`
      <div class="modal-head">
        <h3>🏏 1st Innings Complete</h3>
      </div>

      <div style="text-align:center">
        <div class="score-big">
          ${inn.score}/${inn.wickets}
        </div>

        <p style="color:#9eb0c7">
          ${t.cricketOvers} overs completed.
        </p>

        <button
          class="btn"
          style="margin-top:20px"
          onclick="startSecondInnings('${tid}','${mid}')">
          ▶️ Start 2nd Innings
        </button>
      </div>
    `);

  }else{

    finishCricketMatch(tid,mid);
  }
}

function startSecondInnings(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  m.cricket.innings=2;

  save();
  closeModal();

  showCricketSetup(tid,mid);
}

function finishCricketMatch(tid,mid){

  const t=db.tournaments.find(x=>x.id===tid);
  const m=t.matches.find(x=>x.id===mid);

  const a=m.cricket.inningsData[0];
  const b=m.cricket.inningsData[1];

  let winner=null;

  if(b.score>a.score){
    winner=b.team;
  }else if(a.score>b.score){
    winner=a.team;
  }

  if(!winner){

    openModal(`
      <div class="modal-head">
        <h3>🏏 Match Result</h3>
      </div>

      <p style="text-align:center">
        Match tied.
      </p>

      <button
        class="btn"
        style="width:100%;margin-top:20px"
        onclick="closeModal();renderTournament('${tid}')">
        Finish
      </button>
    `);

    return;
  }

  m.winner=winner;
  m.status="finished";

  if(t.format==="knockout"){
    propagateKnockout(t);
  }

  updateCricketStats(t,m);

  save();
  closeModal();

  celebration("🏆 "+teamById(t,winner).name);

  renderTournament(tid);
}

function updateCricketStats(t,m){

  m.cricket.inningsData.forEach(inn=>{

    Object.values(inn.batsmen).forEach(p=>{

      if(!t.stats.cricket[p.name]){
        t.stats.cricket[p.name]={
          player:p.name,
          team:inn.team,
          runs:0,
          wickets:0
        };
      }

      t.stats.cricket[p.name].runs+=p.runs;
    });

    Object.values(inn.bowlers).forEach(p=>{

      if(!t.stats.cricket[p.name]){
        t.stats.cricket[p.name]={
          player:p.name,
          team:inn.team,
          runs:0,
          wickets:0
        };
      }

      t.stats.cricket[p.name].wickets+=p.wickets;
    });

  });
}

/* =========================================================
   POINTS TABLE
========================================================= */

function renderPoints(id){

  const t=db.tournaments.find(x=>x.id===id);

  const rows={};

  t.teams.forEach(x=>{
    rows[x.id]={
      team:x,
      p:0,
      w:0,
      d:0,
      l:0,
      gf:0,
      ga:0,
      pts:0
    };
  });

  t.matches.forEach(m=>{

    if(m.status!=="finished")return;

    if(!rows[m.home]||!rows[m.away])return;

    rows[m.home].p++;
    rows[m.away].p++;

    rows[m.home].gf+=m.homeScore||0;
    rows[m.home].ga+=m.awayScore||0;

    rows[m.away].gf+=m.awayScore||0;
    rows[m.away].ga+=m.homeScore||0;

    if(m.homeScore>m.awayScore){
      rows[m.home].w++;
      rows[m.home].pts+=3;
      rows[m.away].l++;
    }else if(m.awayScore>m.homeScore){
      rows[m.away].w++;
      rows[m.away].pts+=3;
      rows[m.home].l++;
    }else{
      rows[m.home].d++;
      rows[m.away].d++;
      rows[m.home].pts++;
      rows[m.away].pts++;
    }
  });

  const arr=Object.values(rows)
    .sort((a,b)=>b.pts-a.pts);

  document.getElementById("screen").innerHTML=`

    <div class="section-title">📊 Points Table</div>

    <div class="panel table-wrap">

      <table>

        <thead>
          <tr>
            <th>#</th>
            <th>Team</th>
            <th>P</th>
            <th>W</th>
            <th>D</th>
            <th>L</th>
            <th>GF</th>
            <th>GA</th>
            <th>GD</th>
            <th>PTS</th>
          </tr>
        </thead>

        <tbody>

          ${arr.map((r,i)=>`
            <tr>
              <td class="rank">${i+1}</td>
              <td>${escapeHTML(r.team.name)}</td>
              <td>${r.p}</td>
              <td>${r.w}</td>
              <td>${r.d}</td>
              <td>${r.l}</td>
              <td>${r.gf}</td>
              <td>${r.ga}</td>
              <td>${r.gf-r.ga}</td>
              <td><b>${r.pts}</b></td>
            </tr>
          `).join("")}

        </tbody>

      </table>

    </div>

    <button
      class="btn dark"
      onclick="renderTournament('${id}')">
      ← Back
    </button>
  `;
}

/* =========================================================
   STATISTICS
========================================================= */

function renderStats(id){

  const t=db.tournaments.find(x=>x.id===id);

  document.getElementById("screen").innerHTML=`

    <div class="section-title">🏅 Tournament Statistics</div>

    ${
      t.sport==="football"
      ?footballStatsHTML(t)
      :cricketStatsHTML(t)
    }

    <button
      class="btn dark"
      style="margin-top:20px"
      onclick="renderTournament('${id}')">
      ← Back
    </button>
  `;
}

function footballStatsHTML(t){

  const arr=Object.values(t.stats.football)
    .sort((a,b)=>b.goals-a.goals);

  return`

    <div class="panel">

      <h3>⚽ Top Goal Scorers</h3>

      <div class="table-wrap">

        <table>

          <thead>
            <tr>
              <th>#</th>
              <th>Player</th>
              <th>Team</th>
              <th>Goals</th>
              <th>🟨</th>
              <th>🟥</th>
            </tr>
          </thead>

          <tbody>

            ${arr.map((p,i)=>`
              <tr>
                <td>${i+1}</td>
                <td>${escapeHTML(p.player)}</td>
                <td>${escapeHTML(teamById(t,p.team)?.name||"")}</td>
                <td><b>${p.goals}</b></td>
                <td>${p.yellow}</td>
                <td>${p.red}</td>
              </tr>
            `).join("")}

          </tbody>

        </table>

      </div>

      ${
        !arr.length
        ?`<div class="empty">
            No player statistics yet.
          </div>`
        :""
      }

    </div>
  `;
}

function cricketStatsHTML(t){

  const arr=Object.values(t.stats.cricket);

  const runs=[...arr].sort((a,b)=>b.runs-a.runs);
  const wickets=[...arr].sort((a,b)=>b.wickets-a.wickets);

  return`

    <div class="grid grid2">

      <div class="panel">

        <h3>🏏 Top Run Scorers</h3>

        ${runs.slice(0,10).map((p,i)=>`
          <div class="player-row">
            <span>
              <b>${i+1}.</b>
              ${escapeHTML(p.player)}
            </span>

            <b>${p.runs} runs</b>
          </div>
        `).join("")}

      </div>

      <div class="panel">

        <h3>🎯 Top Wicket Takers</h3>

        ${wickets.slice(0,10).map((p,i)=>`
          <div class="player-row">
            <span>
              <b>${i+1}.</b>
              ${escapeHTML(p.player)}
            </span>

            <b>${p.wickets} wickets</b>
          </div>
        `).join("")}

      </div>

    </div>
  `;
}

/* =========================================================
   TOURNAMENT LIST
========================================================= */

function showTournaments(){

  document.getElementById("screen").innerHTML=`

    <div class="section-title">🏆 My Tournaments</div>

    <div class="section-sub">
      Saved tournaments
    </div>

    <div class="grid grid2">

      ${
        db.tournaments.length
        ?
        db.tournaments.map(t=>`
          <div class="panel">

            <div style="font-size:35px">
              ${t.sport==="football"?"⚽":"🏏"}
            </div>

            <h3 style="margin-top:10px">
              ${escapeHTML(t.name)}
            </h3>

            <p style="color:#9eb0c7;margin:7px 0">
              ${t.teams.length} Teams •
              ${t.format}
            </p>

            <button
              class="btn"
              onclick="renderTournament('${t.id}')">
              Open Tournament
            </button>

          </div>
        `).join("")
        :
        `<div class="empty">
          No tournaments created yet.
        </div>`
      }

    </div>
  `;
}

/* =========================================================
   QR
========================================================= */

function showQR(){
  if(!db.current){
    toast("Create a tournament first.");
    return;
  }

  showTournamentQR(db.current);
}

function showTournamentQR(id){

  const t=db.tournaments.find(x=>x.id===id);

  if(!t)return;

  openModal(`
    <div class="modal-head">
      <h3>📱 Live Viewer QR</h3>
      <button class="close" onclick="closeModal()">✕</button>
    </div>

    <p style="color:#9eb0c7;text-align:center">
      Scan this QR to open the read-only viewer.
    </p>

    <div id="qrcode" class="qr-box"></div>

    <p style="
      color:#9eb0c7;
      font-size:11px;
      text-align:center;
      word-break:break-all;
    ">
      Viewer ID: ${escapeHTML(t.id)}
    </p>

    <button
      class="btn"
      style="width:100%;margin-top:15px"
      onclick="openViewer('${t.id}')">
      👁️ Open Viewer
    </button>
  `);

  setTimeout(()=>{

    const box=document.getElementById("qrcode");

    if(!box)return;

    const base=
      window.location.href.split("?")[0];

    const url=
      base+"?viewer="+encodeURIComponent(t.id);

    if(window.QRCode){

      new QRCode(box,{
        text:url,
        width:220,
        height:220
      });

    }else{
      box.innerHTML=
        "<b>QR library not loaded</b>";
    }

  },100);
}

function openViewer(id){

  closeModal();

  const base=
    window.location.href.split("?")[0];

  window.location.href=
    base+"?viewer="+encodeURIComponent(id);
}

/* =========================================================
   VIEWER MODE
========================================================= */

function checkViewerMode(){

  const params=new URLSearchParams(location.search);

  const id=params.get("viewer");

  if(!id){
    renderHome();
    return;
  }

  const t=db.tournaments.find(x=>x.id===id);

  if(!t){

    document.getElementById("screen").innerHTML=`
      <div class="empty">
        <h2>Tournament not found</h2>
        <p>Invalid or expired tournament.</p>
      </div>
    `;

    return;
  }

  renderViewer(t);
}

function renderViewer(t){

  const finished=
    t.matches.filter(x=>x.status==="finished").length;

  document.getElementById("screen").innerHTML=`

    <div class="section-title">
      👁️ Live Viewer
    </div>

    <div class="section-sub">
      ${escapeHTML(t.name)}
    </div>

    <div class="panel">

      <div style="text-align:center">

        <span class="badge green">
          READ ONLY
        </span>

        <h2 style="margin:12px">
          ${t.sport==="football"?"⚽":"🏏"}
          ${escapeHTML(t.name)}
        </h2>

        <p style="color:#9eb0c7">
          ${finished} matches completed
        </p>

      </div>

    </div>

    ${
      t.champion
      ?`
        <div class="champion">
          <div class="cup">🏆</div>
          <h2>Champion</h2>
          <h1>
            ${escapeHTML(teamById(t,t.champion)?.name||"")}
          </h1>
        </div>
      `
      :""
    }

    <div class="grid grid2" style="margin-top:20px">

      ${t.matches
        .filter(m=>m.status==="live"||m.status==="finished")
        .map(m=>viewerMatch(t,m))
        .join("")}

    </div>

    <div class="panel" style="margin-top:20px">
      <h3>Teams</h3>

      <div class="grid grid3" style="margin-top:15px">
        ${t.teams.map(x=>`
          <div class="team-card">
            <b>${escapeHTML(x.name)}</b>
          </div>
        `).join("")}
      </div>
    </div>

  `;
}

function viewerMatch(t,m){

  const a=teamById(t,m.home);
  const b=teamById(t,m.away);

  if(!a||!b)return"";

  if(t.sport==="football"){

    return`
      <div class="panel">

        <div class="match-top">
          <span>${escapeHTML(m.round)}</span>
          <span>
            ${
              m.status==="live"
              ?'<span class="live">LIVE</span>'
              :"FINISHED"
            }
          </span>
        </div>

        <div class="match-teams">

          <div>
            <div class="team-name">${escapeHTML(a.name)}</div>
            <div class="score-big">
              ${m.homeScore}
            </div>
          </div>

          <div>:</div>

          <div>
            <div class="team-name">${escapeHTML(b.name)}</div>
            <div class="score-big">
              ${m.awayScore}
            </div>
          </div>

        </div>

      </div>
    `;
  }

  return cricketViewerMatch(t,m);
}

function cricketViewerMatch(t,m){

  if(!m.cricket)return"";

  const inn=
    m.cricket.inningsData[m.cricket.innings-1];

  if(!inn)return"";

  const team=teamById(t,inn.team);

  return`
    <div class="panel">

      <div class="match-top">
        <span>Cricket</span>
        <span class="live">LIVE</span>
      </div>

      <h3>${escapeHTML(team?.name||"")}</h3>

      <div class="score-big">
        ${inn.score}/${inn.wickets}
      </div>

      <div style="text-align:center;color:#9eb0c7">
        ${inn.overs}.${inn.balls%6}
        / ${t.cricketOvers} overs
      </div>

    </div>
  `;
}

/* =========================================================
   DELETE / RESET
========================================================= */

function resetApp(){

  if(!confirm("Delete all tournaments?"))return;

  localStorage.removeItem(KEY);

  db={
    tournaments:[],
    current:null
  };

  renderHome();
}

/* ---------- START ---------- */

checkViewerMode();