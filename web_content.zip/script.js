const wifiCard = document.getElementById('wifiCard');
const statusMsg = document.getElementById('statusMsg');
const msgInput = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');
const chatBox = document.getElementById('chatBox');

let bluetoothSerial;
let isConnected = false;

// Wi-Fi bağlantısını yoxlamaq
function checkWifi() {
    if (navigator.onLine) {
        wifiCard.classList.add('connected');
        statusMsg.innerText = "Danışmağa başlaya bilərsiniz ✨";
        msgInput.disabled = false;
        sendBtn.disabled = false;
    } else {
        wifiCard.classList.remove('connected');
        statusMsg.innerText = "Lütfən Wi-Fi və ya Hotspot-a qoşulun!";
        msgInput.disabled = true;
        sendBtn.disabled = true;
    }
}

// Mesaj göndərmək
function sendMessage() {
    const text = msgInput.value.trim();
    if (text === "") return;

    // Ekrana öz mesajını əlavə et
    addMessageToChat(text, 'me');
    msgInput.value = "";

    // Əgər lokal şəbəkə/bluetooth vasitəsilə qoşulubsa qarşı tərəfə ötür
    if (typeof bluetoothSerial !== 'undefined' && isConnected) {
        bluetoothSerial.write(text + "\n", function() {}, function(err) {
            console.error("Göndərmə xətası:", err);
        });
    }
}

// Enter düyməsinə basanda mesajı göndər
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

// Ekrana mesaj çıxarmaq
function addMessageToChat(text, sender) {
    const msgDiv = document.createElement('div');
    msgDiv.classList.add('msg', sender);
    msgDiv.innerText = text;
    
    chatBox.appendChild(msgDiv);
    chatBox.scrollTop = chatBox.scrollHeight; // Avtomatik ən son mesaja sürüşdürür
}

// Qoşulma zamanı gələn mesajları dinləmək
document.addEventListener('deviceready', function() {
    if (window.bluetoothSerial) {
        bluetoothSerial = window.bluetoothSerial;
        bluetoothSerial.subscribe('\n', function(data) {
            if (data && data.trim() !== "") {
                addMessageToChat(data.trim(), 'other');
            }
        });
    }
}, false);

// İnternet/Wi-Fi vəziyyətini real-vaxtda izləmək
window.addEventListener('online', checkWifi);
window.addEventListener('offline', checkWifi);

// Səhifə açıldıqda şəbəkəni yoxla
checkWifi();
