const D=[[-1,0],[0,1],[1,0],[0,-1]],C=40,NS='http://www.w3.org/2000/svg';
const $=i=>document.getElementById(i),svg=$('svg');
const ls={get:(k,d)=>{try{return +localStorage.getItem(k)||d}catch(e){return d}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}}};
let level=ls.get('lv',1),hints=ls.get('hn',3),lives,rows,cols,occ,snakes,left,done;

function rng(a){return()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}

// Level jitna bada: grid bada, snakes lambe, board zyada bhara = zyada mushkil
function gen(){
  const R=rng(level*7919+13);
  cols=Math.min(4+(level/4|0),10);
  rows=Math.min(cols+Math.ceil(cols/3),14);
  const maxLen=Math.min(3+(level/2|0),16),fill=Math.min(.5+level*.006,.8);
  occ=Array.from({length:rows},()=>Array(cols).fill(-1));
  const rm=Array.from({length:rows},()=>Array(cols).fill(0));
  snakes=[];let used=0,tries=rows*cols*40;
  const ok=(r,c)=>r>=0&&c>=0&&r<rows&&c<cols&&occ[r][c]<0&&!rm[r][c];
  while(tries-->0&&used<fill*rows*cols){
    const r=R()*rows|0,c=R()*cols|0,d=R()*4|0;
    const pr=r-D[d][0],pc=c-D[d][1];
    if(!ok(r,c)||!ok(pr,pc))continue;
    const cells=[[pr,pc],[r,c]],len=2+(R()*(maxLen-1)|0);
    const has=(a,b)=>cells.some(x=>x[0]==a&&x[1]==b);
    while(cells.length<len){
      const [tr,tc]=cells[0],o=[0,1,2,3].sort(()=>R()-.5);let mv=false;
      for(const k of o){const a=tr+D[k][0],b=tc+D[k][1];if(ok(a,b)&&!has(a,b)){cells.unshift([a,b]);mv=true;break}}
      if(!mv)break;
    }
    const ray=[];let a=r+D[d][0],b=c+D[d][1];
    while(a>=0&&b>=0&&a<rows&&b<cols){ray.push([a,b]);a+=D[d][0];b+=D[d][1]}
    if(ray.some(x=>has(x[0],x[1])))continue;
    const id=snakes.length;
    cells.forEach(x=>occ[x[0]][x[1]]=id);ray.forEach(x=>rm[x[0]][x[1]]++);
    snakes.push({id,cells,d,ray,alive:true});used+=cells.length;
  }
  left=snakes.length;
}

// path model: snake ke points + seedha bahar tak extension
function mk(s){
  const pts=s.cells.map(x=>[(x[1]+.5)*C,(x[0]+.5)*C]),cum=[0];
  for(let i=1;i<pts.length;i++)cum.push(cum[i-1]+Math.hypot(pts[i][0]-pts[i-1][0],pts[i][1]-pts[i-1][1]));
  const L=cum[cum.length-1],h=pts[pts.length-1],far=C*(cols+rows+4)+L;
  pts.push([h[0]+D[s.d][1]*far,h[1]+D[s.d][0]*far]);cum.push(L+far);
  return{pts,cum,L,total:L+far};
}
function at(m,t){
  for(let i=1;i<m.pts.length;i++)if(t<=m.cum[i]||i==m.pts.length-1){
    const k=Math.min(1,(t-m.cum[i-1])/(m.cum[i]-m.cum[i-1])),a=m.pts[i-1],b=m.pts[i];
    return[a[0]+(b[0]-a[0])*k,a[1]+(b[1]-a[1])*k];
  }
}
function draw(s,o){
  const m=s.m,e=o+m.L,p=[at(m,o)];
  for(let i=1;i<m.pts.length;i++)if(m.cum[i]>o&&m.cum[i]<e)p.push(m.pts[i]);
  p.push(at(m,e));
  const str=p.map(q=>q[0].toFixed(1)+','+q[1].toFixed(1)).join(' ');
  s.g.children[0].setAttribute('points',str);s.g.children[1].setAttribute('points',str);
  const a=p[p.length-2],b=p[p.length-1];let dx=b[0]-a[0],dy=b[1]-a[1];const l=Math.hypot(dx,dy);
  if(l<.01){dx=D[s.d][1];dy=D[s.d][0]}else{dx/=l;dy/=l}
  const f=(k,w)=>(b[0]+dx*k-dy*w).toFixed(1)+','+(b[1]+dy*0+dy*k+dx*w).toFixed(1);
  s.g.children[2].setAttribute('points',[f(11,0),f(-3,8),f(-3,-8)].join(' '));
}
function build(){
  svg.setAttribute('viewBox',`0 0 ${cols*C} ${rows*C}`);
  let h='';
  for(let r=0;r<rows;r++)for(let c=0;c<cols;c++)h+=`<circle class="dot" cx="${(c+.5)*C}" cy="${(r+.5)*C}" r="2.5"/>`;
  svg.innerHTML=h;
  snakes.forEach(s=>{
    s.m=mk(s);
    const g=document.createElementNS(NS,'g');
    g.innerHTML='<polyline class="hit"/><polyline class="ln"/><polygon class="hd"/>';
    svg.appendChild(g);s.g=g;draw(s,0);
    g.addEventListener('pointerdown',e=>{e.preventDefault();tap(s)});
  });
}
function ui(){
  $('lvl').textContent='Level '+level;
  $('cnt').textContent='➚ '+left;
  $('hearts').textContent='❤️'.repeat(lives)+'🖤'.repeat(3-lives);
  $('hc').textContent=hints;
  const dn=level<8?'Easy':level<25?'Medium':level<60?'Hard':'Expert 🔥';
  $('diff').textContent=dn;
}
function tap(s){
  if(!s.alive||lives<=0||done)return;
  if(s.ray.some(x=>occ[x[0]][x[1]]>=0)){
    lives--;ui();s.g.classList.add('bad');
    setTimeout(()=>s.g.classList.remove('bad'),450);
    if(lives<=0)setTimeout(()=>over(false),500);
    return;
  }
  s.alive=false;s.cells.forEach(x=>occ[x[0]][x[1]]=-1);left--;ui();
  const E=s.m.total-s.m.L;let t0=null;
  (function f(t){if(!t0)t0=t;const o=(t-t0)/1000*1500;if(o>=E){s.g.remove();return}draw(s,o);requestAnimationFrame(f)})(performance.now());
  if(!left){done=true;setTimeout(()=>over(true),700)}
}
function over(win){
  done=true;
  if(win){level++;hints++;ls.set('lv',level);ls.set('hn',hints);$('ovt').textContent='🎉 Level Complete!';$('ovb').textContent='Next Level ▶'}
  else{$('ovt').textContent='Game Over 😢';$('ovb').textContent='Retry ↻'}
  $('ov').style.display='flex';
}
function start(){lives=3;done=false;$('ov').style.display='none';gen();build();ui()}
$('ovb').onclick=start;
$('grid').onclick=()=>svg.classList.toggle('nodots');
$('hint').onclick=()=>{
  if(hints<=0||done)return;
  const f=snakes.filter(s=>s.alive&&!s.ray.some(x=>occ[x[0]][x[1]]>=0));
  if(!f.length)return;
  const s=f[Math.random()*f.length|0];
  hints--;ls.set('hn',hints);ui();
  s.g.classList.add('hint');setTimeout(()=>s.g.classList.remove('hint'),2500);
};
start();
