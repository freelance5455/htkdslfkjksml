"use strict";

(() => {
  const $ = id => document.getElementById(id);

  const ui = {
    status: $("status"),
    hint: $("hint"),
    error: $("mapError"),
    main: $("mainBtn"),
    secondary: $("secondaryBtn"),
    undo: $("undoBtn"),
    finish: $("finishBtn"),
    points: $("pointsBtn"),
    export: $("exportBtn"),
    modal: $("exportModal"),
    close: $("closeBtn"),
    name: $("routeName"),
    generate: $("generateBtn"),
    result: $("result"),
    output: $("output"),
    copy: $("copyBtn"),
    copyStatus: $("copyStatus")
  };

  const CONFIG = {
    center: [-71.638, 10.654],
    bounds: [[-71.82, 10.49], [-71.43, 10.83]],
    router: "https://router.project-osrm.org"
  };

  const MAP_STYLE = {
    version: 8,
    sources: {
      osm: {
        type: "raster",
        tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
        tileSize: 256,
        minzoom: 0,
        maxzoom: 19,
        attribution: "© OpenStreetMap contributors"
      }
    },
    layers: [{ id: "osm-tiles", type: "raster", source: "osm" }]
  };

  const state = {
    mode: "main",
    showPoints: true,
    busy: false,
    main: { points: [], segments: [] },
    secondary: [],
    active: null,
    history: [],
    nextId: 1
  };

  let map = null;
  let mapReady = false;

  function status(message) { ui.status.textContent = message; }
  function hint(message) { ui.hint.textContent = message; }

  function insideBounds(coord) {
    const [[west, south], [east, north]] = CONFIG.bounds;
    return coord[0] >= west && coord[0] <= east &&
      coord[1] >= south && coord[1] <= north;
  }

  function clone(value) { return JSON.parse(JSON.stringify(value)); }

  function saveHistory() {
    state.history.push({
      main: clone(state.main),
      secondary: clone(state.secondary),
      active: clone(state.active),
      mode: state.mode,
      nextId: state.nextId
    });
    if (state.history.length > 150) state.history.shift();
  }

  function updateButtons() {
    ui.main.classList.toggle("selected", state.mode === "main");
    ui.secondary.classList.toggle("selected", state.mode === "secondary");
    ui.points.classList.toggle("selected", !state.showPoints);
    ui.points.textContent = state.showPoints ? "Puntos invisibles" : "Mostrar puntos";
    ui.undo.disabled = state.busy || !state.history.length;
    ui.finish.disabled = state.busy || !state.active;
    [ui.main, ui.secondary, ui.finish, ui.points, ui.export]
      .forEach(button => button.disabled = state.busy);
  }

  function setBusy(value, message) {
    state.busy = value;
    if (message) status(message);
    updateButtons();
  }

  function emptyCollection() { return { type: "FeatureCollection", features: [] }; }

  function lineFeature(segment, id) {
    return {
      type: "Feature",
      properties: { routeId: String(id) },
      geometry: { type: "LineString", coordinates: segment.geometry }
    };
  }

  function pointFeature(point, color, number, id) {
    return {
      type: "Feature",
      properties: { color, number, routeId: String(id) },
      geometry: { type: "Point", coordinates: point.coord }
    };
  }

  function redraw() {
    if (!mapReady) return;
    const mainLines = emptyCollection();
    const secondaryLines = emptyCollection();
    const markers = emptyCollection();

    state.main.segments.forEach(segment => mainLines.features.push(lineFeature(segment, "main")));
    state.main.points.forEach((point, index) =>
      markers.features.push(pointFeature(point, "#1976f3", index + 1, "main")));

    const routes = state.active ? [...state.secondary, state.active] : state.secondary;
    routes.forEach(route => {
      route.segments.forEach(segment =>
        secondaryLines.features.push(lineFeature(segment, route.id)));
      route.points.forEach((point, index) =>
        markers.features.push(pointFeature(point, "#ff941f", index + 1, route.id)));
    });

    map.getSource("main-lines").setData(mainLines);
    map.getSource("secondary-lines").setData(secondaryLines);
    map.getSource("route-points").setData(markers);

    const visibility = state.showPoints ? "visible" : "none";
    map.setLayoutProperty("route-points-circles", "visibility", visibility);
    map.setLayoutProperty("route-points-labels", "visibility", visibility);
  }

  function addRouteLayers() {
    map.addSource("main-lines", { type: "geojson", data: emptyCollection() });
    map.addSource("secondary-lines", { type: "geojson", data: emptyCollection() });
    map.addSource("route-points", { type: "geojson", data: emptyCollection() });

    map.addLayer({
      id: "main-line", type: "line", source: "main-lines",
      layout: { "line-cap": "round", "line-join": "round" },
      paint: { "line-color": "#35cfff", "line-width": 6 }
    });
    map.addLayer({
      id: "secondary-line", type: "line", source: "secondary-lines",
      layout: { "line-cap": "round", "line-join": "round" },
      paint: { "line-color": "#ff941f", "line-width": 5 }
    });
    map.addLayer({
      id: "main-arrows", type: "symbol", source: "main-lines",
      layout: {
        "symbol-placement": "line", "symbol-spacing": 110,
        "text-field": "➤", "text-size": 17,
        "text-rotation-alignment": "map", "text-keep-upright": false,
        "text-allow-overlap": true
      },
      paint: { "text-color": "#ffffff", "text-halo-color": "#1684a8", "text-halo-width": 1.5 }
    });
    map.addLayer({
      id: "secondary-arrows", type: "symbol", source: "secondary-lines",
      layout: {
        "symbol-placement": "line", "symbol-spacing": 110,
        "text-field": "➤", "text-size": 17,
        "text-rotation-alignment": "map", "text-keep-upright": false,
        "text-allow-overlap": true
      },
      paint: { "text-color": "#ffffff", "text-halo-color": "#b85b00", "text-halo-width": 1.5 }
    });
    map.addLayer({
      id: "route-points-circles", type: "circle", source: "route-points",
      paint: {
        "circle-radius": 6, "circle-color": ["get", "color"],
        "circle-stroke-color": "#ffffff", "circle-stroke-width": 2
      }
    });
    map.addLayer({
      id: "route-points-labels", type: "symbol", source: "route-points",
      layout: {
        "text-field": ["to-string", ["get", "number"]],
        "text-size": 10, "text-offset": [0, -1.3], "text-allow-overlap": true
      },
      paint: { "text-color": "#0b1930", "text-halo-color": "#ffffff", "text-halo-width": 2 }
    });
  }

  async function requestJSON(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    try {
      const response = await fetch(url, { signal: controller.signal });
      if (!response.ok) throw new Error("El servicio respondió con error HTTP " + response.status);
      return await response.json();
    } catch (error) {
      if (error.name === "AbortError") throw new Error("La solicitud tardó demasiado. Inténtalo otra vez.");
      if (error instanceof TypeError) throw new Error("Sin conexión al servicio de rutas. Comprueba Internet.");
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function snapToRoad(coord) {
    const url = CONFIG.router + "/nearest/v1/driving/" +
      coord[0] + "," + coord[1] + "?number=1";
    const data = await requestJSON(url);
    if (data.code !== "Ok" || !data.waypoints?.length) throw new Error("No se encontró una calle cercana.");
    const waypoint = data.waypoints[0];
    if (waypoint.distance > 100) throw new Error("Toca más cerca de una calle.");
    return { coord: waypoint.location, distanceToRoad: waypoint.distance };
  }

  async function routeBetween(start, end) {
    const url = CONFIG.router + "/route/v1/driving/" +
      start[0] + "," + start[1] + ";" + end[0] + "," + end[1] +
      "?overview=full&geometries=geojson&steps=true";
    const data = await requestJSON(url);
    if (data.code !== "Ok" || !data.routes?.length) throw new Error("No se encontró un recorrido vial.");
    const route = data.routes[0];
    const streets = [];
    (route.legs || []).forEach(leg => (leg.steps || []).forEach(step => {
      const name = (step.name || "").trim();
      if (name && streets[streets.length - 1] !== name) streets.push(name);
    }));
    return {
      geometry: route.geometry.coordinates,
      distanceMeters: route.distance,
      durationSeconds: route.duration,
      streets
    };
  }

  function closestMainVertex(screenPoint) {
    const features = map.queryRenderedFeatures(screenPoint, { layers: ["main-line"] });
    if (!features.length) return null;
    let best = null;
    let bestDistance = Infinity;
    state.main.segments.forEach(segment => segment.geometry.forEach(coord => {
      const pixel = map.project(coord);
      const distance = Math.hypot(pixel.x - screenPoint.x, pixel.y - screenPoint.y);
      if (distance < bestDistance) { bestDistance = distance; best = coord; }
    }));
    return bestDistance <= 35 ? best : null;
  }

  async function handleMapClick(event) {
    if (!mapReady || state.busy) return;
    const clicked = [event.lngLat.lng, event.lngLat.lat];
    if (!insideBounds(clicked)) { status("Punto fuera de la zona de trabajo."); return; }

    if (state.mode === "main") { await addMainPoint(clicked); return; }

    if (!state.active) {
      const anchor = closestMainVertex(event.point);
      if (!anchor) {
        status("Toca directamente la línea celeste para conectar la secundaria.");
        return;
      }
      saveHistory();
      state.active = { id: state.nextId++, anchor, points: [], segments: [], complete: false };
      redraw();
      updateButtons();
      status("Conexión seleccionada.");
      hint("Ahora toca las calles para trazar la ruta naranja.");
      return;
    }
    await addSecondaryPoint(clicked);
  }

  async function addMainPoint(clicked) {
    if (state.active) { status("Finaliza la secundaria antes de continuar."); return; }
    setBusy(true, "Buscando calle...");
    try {
      const snapped = await snapToRoad(clicked);
      if (!insideBounds(snapped.coord)) throw new Error("La calle detectada queda fuera de la zona permitida.");
      const previous = state.main.points[state.main.points.length - 1];
      let segment = null;
      if (previous) {
        status("Calculando recorrido...");
        segment = await routeBetween(previous.coord, snapped.coord);
        if (segment.geometry.some(coord => !insideBounds(coord))) {
          throw new Error("El recorrido sale de la zona de trabajo.");
        }
      }
      saveHistory();
      state.main.points.push(snapped);
      if (segment) state.main.segments.push(segment);
      redraw();
      status("Ruta principal: " + state.main.points.length + " puntos.");
      hint("Toca otra calle para continuar el trazado celeste.");
    } catch (error) {
      status(error.message || "No se pudo añadir el punto.");
    } finally { setBusy(false); }
  }

  async function addSecondaryPoint(clicked) {
    const route = state.active;
    if (!route) return;
    setBusy(true, "Calculando ruta secundaria...");
    try {
      const snapped = await snapToRoad(clicked);
      if (!insideBounds(snapped.coord)) throw new Error("La calle queda fuera de la zona permitida.");
      const previous = route.points.length ? route.points[route.points.length - 1].coord : route.anchor;
      const segment = await routeBetween(previous, snapped.coord);
      if (segment.geometry.some(coord => !insideBounds(coord))) throw new Error("El recorrido sale de la zona de trabajo.");
      saveHistory();
      route.points.push(snapped);
      route.segments.push(segment);
      redraw();
      status("Ruta secundaria " + route.id + ": " + route.points.length + " puntos.");
      hint("Continúa trazando o finaliza la ruta secundaria.");
    } catch (error) {
      status(error.message || "No se pudo añadir el punto.");
    } finally { setBusy(false); }
  }

  function undo() {
    if (state.busy || !state.history.length) return;
    const previous = state.history.pop();
    state.main = previous.main;
    state.secondary = previous.secondary;
    state.active = previous.active;
    state.mode = previous.mode;
    state.nextId = previous.nextId;
    redraw();
    updateButtons();
    status("Último movimiento deshecho.");
  }

  function setMode(mode) {
    if (state.busy) return;
    if (state.active && mode !== "secondary") {
      status("Finaliza la secundaria antes de cambiar de modo.");
      return;
    }
    state.mode = mode;
    updateButtons();
    if (mode === "main") {
      hint("Toca las calles para dibujar la ruta principal celeste.");
      status("Modo ruta principal.");
    } else {
      hint("Primero toca una línea celeste para conectar una secundaria.");
      status("Modo ruta secundaria.");
    }
  }

  function finishSecondary() {
    if (state.busy || !state.active) return;
    if (!state.active.points.length) {
      status("Añade al menos un punto naranja antes de finalizar.");
      return;
    }
    saveHistory();
    state.active.complete = true;
    state.secondary.push(state.active);
    state.active = null;
    state.mode = "secondary";
    redraw();
    updateButtons();
    status("Ruta secundaria guardada.");
    hint("Toca otro tramo celeste para crear una nueva secundaria.");
  }

  function togglePoints() {
    state.showPoints = !state.showPoints;
    redraw();
    updateButtons();
    status(state.showPoints ? "Puntos visibles." : "Puntos ocultos.");
  }

  function exportRoute(name) {
    const serialize = (route, type) => ({
      id: type === "main" ? "principal" : route.id,
      type,
      color: type === "main" ? "#35cfff" : "#ff941f",
      connection: route.anchor ? { type: "main_route_coordinate", coordinates: route.anchor } : null,
      points: route.points.map((point, index) => ({
        order: index + 1,
        coordinates: point.coord,
        snapDistanceMeters: point.distanceToRoad
      })),
      segments: route.segments.map((segment, index) => ({
        order: index + 1,
        distanceMeters: segment.distanceMeters,
        durationSeconds: segment.durationSeconds,
        streets: segment.streets,
        geometry: { type: "LineString", coordinates: segment.geometry }
      })),
      totalDistanceMeters: route.segments.reduce((sum, segment) => sum + segment.distanceMeters, 0)
    });

    return {
      schema: "maracaibo-transit-routes/v1",
      name,
      createdAt: new Date().toISOString(),
      coordinateSystem: "WGS84",
      coordinateOrder: ["longitude", "latitude"],
      mainRoute: serialize(state.main, "main"),
      secondaryRoutes: state.secondary.map(route => serialize(route, "secondary"))
    };
  }

  function openExport() {
    if (state.busy) return;
    if (state.main.points.length < 2) {
      status("Marca al menos dos puntos en la ruta principal.");
      return;
    }
    if (state.active) {
      status("Finaliza la ruta secundaria antes de exportar.");
      return;
    }
    ui.modal.classList.remove("hidden");
    ui.modal.setAttribute("aria-hidden", "false");
    ui.result.classList.add("hidden");
    ui.name.value = "";
    ui.copyStatus.textContent = "";
    ui.name.focus();
  }

  function closeExport() {
    ui.modal.classList.add("hidden");
    ui.modal.setAttribute("aria-hidden", "true");
  }

  function generateExport() {
    const name = ui.name.value.trim();
    if (!name) {
      ui.copyStatus.textContent = "Escribe el nombre de la ruta.";
      ui.name.focus();
      return;
    }
    ui.output.value = JSON.stringify(exportRoute(name), null, 2);
    ui.result.classList.remove("hidden");
  }

  async function copyExport() {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(ui.output.value);
      } else {
        ui.output.focus();
        ui.output.select();
        if (!document.execCommand("copy")) throw new Error("Copia manual");
      }
      ui.copyStatus.textContent = "Código copiado correctamente.";
    } catch {
      ui.output.focus();
      ui.output.select();
      ui.copyStatus.textContent = "Selecciona el texto y cópialo manualmente.";
    }
  }

  function initializeMap() {
    if (typeof maplibregl === "undefined") {
      status("No se cargó la librería del mapa.");
      ui.error.textContent = "MapLibre no se pudo cargar. Comprueba Internet y que APK Forge permita cargar bibliotecas externas.";
      ui.error.classList.remove("hidden");
      return;
    }

    try {
      map = new maplibregl.Map({
        container: "map",
        style: MAP_STYLE,
        center: CONFIG.center,
        zoom: 12.5,
        minZoom: 10,
        maxZoom: 19,
        maxBounds: CONFIG.bounds,
        renderWorldCopies: false,
        dragRotate: true,
        touchZoomRotate: true,
        pitchWithRotate: true,
        maxPitch: 60
      });

      map.addControl(new maplibregl.NavigationControl({
        showCompass: true, showZoom: true, visualizePitch: true
      }), "top-right");

      map.on("load", () => {
        try {
          addRouteLayers();
          mapReady = true;
          redraw();
          updateButtons();
          ui.error.classList.add("hidden");
          status("Maracaibo cargado.");
          hint("Ruta principal: toca una calle para colocar el primer punto.");
          map.resize();
        } catch (error) {
          console.error(error);
          status("Error al preparar las rutas.");
          ui.error.textContent = "Error preparando las capas del mapa: " + error.message;
          ui.error.classList.remove("hidden");
        }
      });

      map.on("error", event => console.error("Error cartográfico:", event.error || event));
      map.on("click", handleMapClick);
      window.addEventListener("resize", () => map && map.resize());
    } catch (error) {
      console.error(error);
      status("No se pudo iniciar el mapa.");
      ui.error.textContent = "Error al iniciar el mapa: " + error.message;
      ui.error.classList.remove("hidden");
    }
  }

  ui.main.addEventListener("click", () => setMode("main"));
  ui.secondary.addEventListener("click", () => setMode("secondary"));
  ui.undo.addEventListener("click", undo);
  ui.finish.addEventListener("click", finishSecondary);
  ui.points.addEventListener("click", togglePoints);
  ui.export.addEventListener("click", openExport);
  ui.generate.addEventListener("click", generateExport);
  ui.copy.addEventListener("click", copyExport);
  ui.close.addEventListener("click", closeExport);

  ui.modal.addEventListener("click", event => {
    if (event.target === ui.modal) closeExport();
  });
  ui.name.addEventListener("keydown", event => {
    if (event.key === "Enter") generateExport();
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") closeExport();
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "z") {
      event.preventDefault();
      undo();
    }
  });

  updateButtons();
  initializeMap();
})();
