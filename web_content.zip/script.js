/* JZst Games Chess Arena — standalone chess rules and interface, no libraries required. */
'use strict';

const FILES = 'abcdefgh';
const GLYPHS = {
  K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙',
  k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟'
};
const PIECE_VALUES = { p: 100, n: 315, b: 330, r: 500, q: 900, k: 20000 };
const PIECE_ASSETS = { k: 'k', q: 'q', r: 'r', b: 'b', n: 'n', p: 'p' };
function makePieceImage(piece, extraClass = '') {
  const image = document.createElement('img');
  const color = colorOf(piece) === 'w' ? 'w' : 'b';
  image.className = 'piece piece-image ' + (color === 'w' ? 'white-piece' : 'black-piece') + (extraClass ? ' ' + extraClass : '');
  image.src = 'assets/' + color + '-' + PIECE_ASSETS[pieceType(piece)] + '.png';
  image.alt = (color === 'w' ? 'White ' : 'Black ') + ({ p:'pawn', n:'knight', b:'bishop', r:'rook', q:'queen', k:'king' })[pieceType(piece)];
  image.draggable = false;
  return image;
}
const PROMOTION_TYPES = ['q', 'r', 'b', 'n'];
const boardElement = document.getElementById('chessboard');
const moveListElement = document.getElementById('moveList');
const gameMessage = document.getElementById('gameMessage');
const promotionModal = document.getElementById('promotionModal');
const promotionChoices = document.getElementById('promotionChoices');

let gameState = initialState();
let selectedSquare = null;
let selectedMoves = [];
let lastMove = null;
let boardFlipped = false;
let playMode = 'local';
let moveHistory = [];
let capturedPieces = { w: [], b: [] };
let undoStack = [];
let positionCounts = Object.create(null);
let gameResult = null;
let pendingPromotion = null;
let computerThinking = false;
let soundEnabled = true;
let audioContext = null;
let draggedFrom = null;

function initialState() {
  const board = Array(64).fill(null);
  const backRank = ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'];
  for (let file = 0; file < 8; file += 1) {
    board[file] = backRank[file];
    board[8 + file] = 'p';
    board[48 + file] = 'P';
    board[56 + file] = backRank[file].toUpperCase();
  }
  return { board, turn: 'w', castling: { K: true, Q: true, k: true, q: true }, ep: null, halfmove: 0, fullmove: 1 };
}

function cloneState(state) {
  return {
    board: state.board.slice(), turn: state.turn,
    castling: { ...state.castling }, ep: state.ep,
    halfmove: state.halfmove, fullmove: state.fullmove
  };
}

function colorOf(piece) {
  if (!piece) return null;
  return piece === piece.toUpperCase() ? 'w' : 'b';
}
function opposite(color) { return color === 'w' ? 'b' : 'w'; }
function pieceType(piece) { return piece ? piece.toLowerCase() : null; }
function rowOf(square) { return Math.floor(square / 8); }
function colOf(square) { return square % 8; }
function onBoard(row, col) { return row >= 0 && row < 8 && col >= 0 && col < 8; }
function squareName(square) { return FILES[colOf(square)] + (8 - rowOf(square)); }
function rankName(square) { return String(8 - rowOf(square)); }
function findKing(state, color) {
  const king = color === 'w' ? 'K' : 'k';
  return state.board.indexOf(king);
}

function isSquareAttacked(state, target, byColor) {
  const tr = rowOf(target), tc = colOf(target), board = state.board;
  // Pawn attacks point diagonally forward; look backward from the target.
  const pawnSourceRow = tr + (byColor === 'w' ? 1 : -1);
  for (const dc of [-1, 1]) {
    const pc = tc + dc;
    if (onBoard(pawnSourceRow, pc)) {
      const piece = board[pawnSourceRow * 8 + pc];
      if (piece && colorOf(piece) === byColor && pieceType(piece) === 'p') return true;
    }
  }
  const knightOffsets = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
  for (const [dr, dc] of knightOffsets) {
    const r = tr + dr, c = tc + dc;
    if (onBoard(r, c)) {
      const piece = board[r * 8 + c];
      if (piece && colorOf(piece) === byColor && pieceType(piece) === 'n') return true;
    }
  }
  for (let dr = -1; dr <= 1; dr += 1) {
    for (let dc = -1; dc <= 1; dc += 1) {
      if (dr === 0 && dc === 0) continue;
      const r = tr + dr, c = tc + dc;
      if (onBoard(r, c)) {
        const piece = board[r * 8 + c];
        if (piece && colorOf(piece) === byColor && pieceType(piece) === 'k') return true;
      }
    }
  }
  const rays = [
    { dr: -1, dc: -1, types: ['b', 'q'] }, { dr: -1, dc: 1, types: ['b', 'q'] },
    { dr: 1, dc: -1, types: ['b', 'q'] }, { dr: 1, dc: 1, types: ['b', 'q'] },
    { dr: -1, dc: 0, types: ['r', 'q'] }, { dr: 1, dc: 0, types: ['r', 'q'] },
    { dr: 0, dc: -1, types: ['r', 'q'] }, { dr: 0, dc: 1, types: ['r', 'q'] }
  ];
  for (const ray of rays) {
    let r = tr + ray.dr, c = tc + ray.dc;
    while (onBoard(r, c)) {
      const piece = board[r * 8 + c];
      if (piece) {
        if (colorOf(piece) === byColor && ray.types.includes(pieceType(piece))) return true;
        break;
      }
      r += ray.dr; c += ray.dc;
    }
  }
  return false;
}

function isInCheck(state, color) {
  const king = findKing(state, color);
  return king >= 0 && isSquareAttacked(state, king, opposite(color));
}

function pseudoMoves(state, from) {
  const board = state.board, piece = board[from];
  if (!piece) return [];
  const color = colorOf(piece), type = pieceType(piece);
  const row = rowOf(from), col = colOf(from), moves = [];
  const enemy = opposite(color);
  const add = (to, extra = {}) => {
    if (to < 0 || to >= 64) return;
    const target = board[to];
    if (target && colorOf(target) === color) return;
    moves.push({ from, to, ...extra });
  };
  const addPawnMove = (to, extra = {}) => {
    const promotionRow = color === 'w' ? 0 : 7;
    if (rowOf(to) === promotionRow) {
      for (const promotion of PROMOTION_TYPES) moves.push({ from, to, promotion, ...extra });
    } else {
      moves.push({ from, to, ...extra });
    }
  };

  if (type === 'p') {
    const direction = color === 'w' ? -1 : 1;
    const startRow = color === 'w' ? 6 : 1;
    const oneRow = row + direction;
    if (onBoard(oneRow, col) && !board[oneRow * 8 + col]) {
      addPawnMove(oneRow * 8 + col);
      const twoRow = row + direction * 2;
      if (row === startRow && !board[twoRow * 8 + col]) add(twoRow * 8 + col, { doublePawn: true });
    }
    for (const dc of [-1, 1]) {
      const r = row + direction, c = col + dc;
      if (!onBoard(r, c)) continue;
      const to = r * 8 + c, target = board[to];
      if (target && colorOf(target) === enemy) addPawnMove(to);
      else if (state.ep === to) moves.push({ from, to, enPassant: true });
    }
  } else if (type === 'n') {
    const jumps = [[-2, -1], [-2, 1], [-1, -2], [-1, 2], [1, -2], [1, 2], [2, -1], [2, 1]];
    for (const [dr, dc] of jumps) {
      const r = row + dr, c = col + dc;
      if (onBoard(r, c)) add(r * 8 + c);
    }
  } else if (type === 'b' || type === 'r' || type === 'q') {
    const directions = [];
    if (type === 'b' || type === 'q') directions.push([-1,-1],[-1,1],[1,-1],[1,1]);
    if (type === 'r' || type === 'q') directions.push([-1,0],[1,0],[0,-1],[0,1]);
    for (const [dr, dc] of directions) {
      let r = row + dr, c = col + dc;
      while (onBoard(r, c)) {
        const to = r * 8 + c;
        if (!board[to]) moves.push({ from, to });
        else {
          if (colorOf(board[to]) !== color) moves.push({ from, to });
          break;
        }
        r += dr; c += dc;
      }
    }
  } else if (type === 'k') {
    for (let dr = -1; dr <= 1; dr += 1) {
      for (let dc = -1; dc <= 1; dc += 1) {
        if (dr === 0 && dc === 0) continue;
        const r = row + dr, c = col + dc;
        if (onBoard(r, c)) add(r * 8 + c);
      }
    }
    const homeRow = color === 'w' ? 7 : 0;
    if (from === homeRow * 8 + 4 && !isInCheck(state, color)) {
      const kingSide = color === 'w' ? 'K' : 'k';
      const queenSide = color === 'w' ? 'Q' : 'q';
      if (state.castling[kingSide] && !board[homeRow * 8 + 5] && !board[homeRow * 8 + 6] &&
          board[homeRow * 8 + 7] === (color === 'w' ? 'R' : 'r') &&
          !isSquareAttacked(state, homeRow * 8 + 5, enemy) && !isSquareAttacked(state, homeRow * 8 + 6, enemy)) {
        moves.push({ from, to: homeRow * 8 + 6, castle: 'K' });
      }
      if (state.castling[queenSide] && !board[homeRow * 8 + 1] && !board[homeRow * 8 + 2] && !board[homeRow * 8 + 3] &&
          board[homeRow * 8] === (color === 'w' ? 'R' : 'r') &&
          !isSquareAttacked(state, homeRow * 8 + 3, enemy) && !isSquareAttacked(state, homeRow * 8 + 2, enemy)) {
        moves.push({ from, to: homeRow * 8 + 2, castle: 'Q' });
      }
    }
  }
  return moves;
}

function applyMove(state, move) {
  const next = cloneState(state);
  const board = next.board;
  const piece = board[move.from], color = colorOf(piece), type = pieceType(piece);
  const from = move.from, to = move.to;
  let captured = board[to];
  if (move.enPassant) {
    const capturedSquare = to + (color === 'w' ? 8 : -8);
    captured = board[capturedSquare];
    board[capturedSquare] = null;
  }
  board[from] = null;
  board[to] = move.promotion ? (color === 'w' ? move.promotion.toUpperCase() : move.promotion.toLowerCase()) : piece;

  if (move.castle) {
    const r = color === 'w' ? 7 : 0;
    if (move.castle === 'K') { board[r * 8 + 5] = board[r * 8 + 7]; board[r * 8 + 7] = null; }
    else { board[r * 8 + 3] = board[r * 8]; board[r * 8] = null; }
  }

  if (piece === 'K') { next.castling.K = false; next.castling.Q = false; }
  if (piece === 'k') { next.castling.k = false; next.castling.q = false; }
  if (from === 63 || to === 63) next.castling.K = next.castling.K && !(piece === 'R' || captured === 'R');
  if (from === 56 || to === 56) next.castling.Q = next.castling.Q && !(piece === 'R' || captured === 'R');
  if (from === 7 || to === 7) next.castling.k = next.castling.k && !(piece === 'r' || captured === 'r');
  if (from === 0 || to === 0) next.castling.q = next.castling.q && !(piece === 'r' || captured === 'r');

  next.ep = move.doublePawn ? (from + to) / 2 : null;
  next.halfmove = type === 'p' || captured ? 0 : next.halfmove + 1;
  if (state.turn === 'b') next.fullmove += 1;
  next.turn = opposite(state.turn);
  return next;
}

function legalMovesFrom(state, from) {
  const piece = state.board[from];
  if (!piece || colorOf(piece) !== state.turn) return [];
  const color = state.turn;
  return pseudoMoves(state, from).filter(move => !isInCheck(applyMove(state, move), color));
}

function allLegalMoves(state, color = state.turn) {
  const originalTurn = state.turn;
  const workingState = color === originalTurn ? state : { ...state, turn: color };
  const result = [];
  for (let square = 0; square < 64; square += 1) {
    const piece = workingState.board[square];
    if (piece && colorOf(piece) === color) result.push(...legalMovesFrom(workingState, square));
  }
  return result;
}

function positionKey(state) {
  const rights = ['K', 'Q', 'k', 'q'].filter(key => state.castling[key]).join('') || '-';
  return state.board.map(piece => piece || '.').join('') + ' ' + state.turn + ' ' + rights + ' ' + (state.ep === null ? '-' : squareName(state.ep));
}

function hasInsufficientMaterial(state) {
  const pieces = [];
  for (let i = 0; i < 64; i += 1) {
    const p = state.board[i];
    if (p && pieceType(p) !== 'k') pieces.push({ p, square: i, type: pieceType(p) });
  }
  if (pieces.length === 0) return true;
  if (pieces.some(item => ['p', 'r', 'q'].includes(item.type))) return false;
  if (pieces.length === 1 && ['b', 'n'].includes(pieces[0].type)) return true;
  if (pieces.every(item => item.type === 'b')) {
    const bishopSquareColors = pieces.map(item => (rowOf(item.square) + colOf(item.square)) % 2);
    return bishopSquareColors.every(color => color === bishopSquareColors[0]);
  }
  return false;
}

function formatSanBase(state, move, legalMoves) {
  const piece = state.board[move.from], type = pieceType(piece);
  if (move.castle === 'K') return 'O-O';
  if (move.castle === 'Q') return 'O-O-O';
  const isCapture = !!state.board[move.to] || !!move.enPassant;
  let san = '';
  if (type !== 'p') {
    san += type.toUpperCase();
    const competitors = legalMoves.filter(candidate => candidate.to === move.to && candidate.from !== move.from &&
      pieceType(state.board[candidate.from]) === type);
    if (competitors.length) {
      const sameFile = competitors.some(candidate => colOf(candidate.from) === colOf(move.from));
      const sameRank = competitors.some(candidate => rowOf(candidate.from) === rowOf(move.from));
      if (!sameFile) san += FILES[colOf(move.from)];
      else if (!sameRank) san += rankName(move.from);
      else san += FILES[colOf(move.from)] + rankName(move.from);
    }
  } else if (isCapture) {
    san += FILES[colOf(move.from)];
  }
  if (isCapture) san += 'x';
  san += squareName(move.to);
  if (move.promotion) san += '=' + move.promotion.toUpperCase();
  return san;
}

function saveSnapshot() {
  undoStack.push({
    state: cloneState(gameState), history: moveHistory.slice(),
    captured: { w: capturedPieces.w.slice(), b: capturedPieces.b.slice() },
    lastMove: lastMove ? { ...lastMove } : null,
    counts: { ...positionCounts }, result: gameResult
  });
  if (undoStack.length > 240) undoStack.shift();
}

function restoreSnapshot(snapshot) {
  gameState = cloneState(snapshot.state);
  moveHistory = snapshot.history.slice();
  capturedPieces = { w: snapshot.captured.w.slice(), b: snapshot.captured.b.slice() };
  lastMove = snapshot.lastMove ? { ...snapshot.lastMove } : null;
  positionCounts = Object.assign(Object.create(null), snapshot.counts);
  gameResult = snapshot.result;
  selectedSquare = null;
  selectedMoves = [];
  pendingPromotion = null;
  computerThinking = false;
  promotionModal.hidden = true;
}

function resultForPosition(state, replies) {
  const side = state.turn;
  const check = isInCheck(state, side);
  if (replies.length === 0) {
    if (check) return { type: 'checkmate', winner: opposite(side), message: (opposite(side) === 'w' ? 'White' : 'Black') + ' wins by checkmate.' };
    return { type: 'stalemate', winner: null, message: 'Draw by stalemate.' };
  }
  if (state.halfmove >= 100) return { type: 'fifty-move', winner: null, message: 'Draw by the 50-move rule.' };
  if ((positionCounts[positionKey(state)] || 0) >= 3) return { type: 'repetition', winner: null, message: 'Draw by threefold repetition.' };
  if (hasInsufficientMaterial(state)) return { type: 'material', winner: null, message: 'Draw — insufficient material.' };
  return null;
}

function commitMove(move) {
  if (gameResult || computerThinking) return;
  const legalNow = allLegalMoves(gameState, gameState.turn);
  if (!legalNow.some(item => item.from === move.from && item.to === move.to && (item.promotion || null) === (move.promotion || null))) return;

  saveSnapshot();
  const movingColor = gameState.turn;
  const movingPiece = gameState.board[move.from];
  const captureSquare = move.enPassant ? move.to + (movingColor === 'w' ? 8 : -8) : move.to;
  const capturedPiece = gameState.board[captureSquare];
  const sanBase = formatSanBase(gameState, move, legalNow);
  gameState = applyMove(gameState, move);
  if (capturedPiece) capturedPieces[movingColor].push(capturedPiece);
  lastMove = { from: move.from, to: move.to };
  const nextKey = positionKey(gameState);
  positionCounts[nextKey] = (positionCounts[nextKey] || 0) + 1;

  const replies = allLegalMoves(gameState, gameState.turn);
  const check = isInCheck(gameState, gameState.turn);
  gameResult = resultForPosition(gameState, replies);
  let san = sanBase;
  if (check) san += replies.length === 0 ? '#' : '+';
  moveHistory.push({ number: movingColor === 'w' ? gameState.fullmove : gameState.fullmove - 1, color: movingColor, san, move: { ...move } });

  selectedSquare = null;
  selectedMoves = [];
  pendingPromotion = null;
  promotionModal.hidden = true;
  playSound(gameResult ? (gameResult.type === 'checkmate' ? 'win' : 'draw') : (capturedPiece ? 'capture' : (check ? 'check' : 'move')));
  renderAll();
  if (gameResult) showResultModal();

  if (playMode === 'cpu' && !gameResult && gameState.turn === 'b') {
    computerThinking = true;
    document.getElementById('boardHint').textContent = 'CPU is thinking…';
    updatePlayerLabels();
    renderStatus();
    window.setTimeout(() => {
      if (playMode !== 'cpu' || gameState.turn !== 'b' || gameResult) { computerThinking = false; renderAll(); return; }
      const cpuMove = chooseComputerMove();
      computerThinking = false;
      if (cpuMove) commitMove(cpuMove);
      else renderAll();
    }, 280);
  }
}

function evaluatePosition(state) {
  let score = 0;
  for (let square = 0; square < 64; square += 1) {
    const piece = state.board[square];
    if (!piece) continue;
    const color = colorOf(piece), type = pieceType(piece), row = rowOf(square), col = colOf(square);
    const sign = color === 'w' ? 1 : -1;
    let value = PIECE_VALUES[type] || 0;
    const centerDistance = Math.abs(3.5 - row) + Math.abs(3.5 - col);
    if (type === 'n' || type === 'b') value += Math.round((7 - centerDistance) * (type === 'n' ? 5 : 2));
    if (type === 'p') value += (color === 'w' ? (6 - row) : (row - 1)) * 6 + (col > 1 && col < 6 ? 2 : 0);
    if (type === 'k' && state.fullmove < 15) value -= Math.round((7 - centerDistance) * 2);
    score += value * sign;
  }
  return score;
}

function minimax(state, depth, alpha, beta, ply) {
  const moves = allLegalMoves(state, state.turn);
  if (moves.length === 0) {
    if (isInCheck(state, state.turn)) return state.turn === 'w' ? -100000 + ply : 100000 - ply;
    return 0;
  }
  if (depth <= 0) return evaluatePosition(state);
  if (state.turn === 'w') {
    let best = -Infinity;
    for (const move of moves) {
      const score = minimax(applyMove(state, move), depth - 1, alpha, beta, ply + 1);
      if (score > best) best = score;
      if (best > alpha) alpha = best;
      if (beta <= alpha) break;
    }
    return best;
  }
  let best = Infinity;
  for (const move of moves) {
    const score = minimax(applyMove(state, move), depth - 1, alpha, beta, ply + 1);
    if (score < best) best = score;
    if (best < beta) beta = best;
    if (beta <= alpha) break;
  }
  return best;
}

function chooseComputerMove() {
  const moves = allLegalMoves(gameState, 'b');
  if (!moves.length) return null;
  let bestScore = Infinity, bestMoves = [], beta = Infinity;
  for (const move of moves) {
    const score = minimax(applyMove(gameState, move), 2, -Infinity, beta, 1);
    if (score < bestScore - 0.1) { bestScore = score; bestMoves = [move]; }
    else if (Math.abs(score - bestScore) < 0.1) bestMoves.push(move);
    if (score < beta) beta = score;
  }
  return bestMoves[Math.floor(Math.random() * bestMoves.length)] || moves[0];
}

function startNewGame(mode = playMode) {
  playMode = mode;
  gameState = initialState();
  selectedSquare = null;
  selectedMoves = [];
  lastMove = null;
  moveHistory = [];
  capturedPieces = { w: [], b: [] };
  undoStack = [];
  positionCounts = Object.create(null);
  positionCounts[positionKey(gameState)] = 1;
  gameResult = null;
  pendingPromotion = null;
  computerThinking = false;
  promotionModal.hidden = true;
  const resultModal = document.getElementById('resultModal');
  if (resultModal) resultModal.hidden = true;
  setModeButtons();
  renderAll();
}

function doUndo() {
  if (!undoStack.length || computerThinking) return;
  let snapshot = undoStack.pop();
  restoreSnapshot(snapshot);
  // In CPU mode, undo the player's last move and the CPU reply together.
  if (playMode === 'cpu') {
    while (undoStack.length && gameState.turn !== 'w') {
      snapshot = undoStack.pop();
      restoreSnapshot(snapshot);
    }
  }
  renderAll();
  playSound('move');
}

function handleSquareClick(square) {
  if (gameResult || computerThinking) return;
  const piece = gameState.board[square];
  const sideCanMove = playMode !== 'cpu' || gameState.turn === 'w';
  if (!sideCanMove) return;

  if (selectedSquare !== null) {
    const targetMoves = selectedMoves.filter(move => move.to === square);
    if (targetMoves.length) {
      if (targetMoves.some(move => move.promotion)) { showPromotionChoices(targetMoves); return; }
      commitMove(targetMoves[0]);
      return;
    }
  }
  if (piece && colorOf(piece) === gameState.turn) {
    selectedSquare = square;
    selectedMoves = legalMovesFrom(gameState, square);
    playSound('select');
  } else {
    selectedSquare = null;
    selectedMoves = [];
  }
  renderBoard();
  document.getElementById('boardHint').textContent = selectedSquare === null ? 'Tap a piece to see its moves' : 'Choose a glowing square';
}

function showPromotionChoices(moves) {
  pendingPromotion = moves;
  promotionChoices.innerHTML = '';
  const color = gameState.turn;
  for (const move of moves) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'promotion-choice';
    const promotedPiece = color === 'w' ? move.promotion.toUpperCase() : move.promotion;
    const glyph = makePieceImage(promotedPiece, 'promotion-piece-image');
    const label = document.createElement('small');
    label.textContent = ({ q: 'Queen', r: 'Rook', b: 'Bishop', n: 'Knight' })[move.promotion];
    button.append(glyph, label);
    button.addEventListener('click', () => { pendingPromotion = null; promotionModal.hidden = true; commitMove(move); });
    promotionChoices.appendChild(button);
  }
  promotionModal.hidden = false;
  const firstChoice = promotionChoices.querySelector('button');
  if (firstChoice) firstChoice.focus();
}

function setModeButtons() {
  const local = playMode === 'local';
  document.getElementById('localModeBtn').classList.toggle('active', local);
  document.getElementById('cpuModeBtn').classList.toggle('active', !local);
  document.getElementById('localModeBtn').setAttribute('aria-pressed', String(local));
  document.getElementById('cpuModeBtn').setAttribute('aria-pressed', String(!local));
  document.getElementById('modeDescription').textContent = local
    ? 'Play face-to-face on one device. White moves first.'
    : 'You play as White. A lightweight built-in CPU plays Black.';
}

function updatePlayerLabels() {
  const topColor = boardFlipped ? 'w' : 'b';
  const bottomColor = boardFlipped ? 'b' : 'w';
  const playerName = color => color === 'w' ? 'WHITE' : 'BLACK';
  const avatar = color => color === 'w' ? '♔' : '♚';
  const role = color => playMode === 'cpu' ? (color === 'w' ? 'YOU' : 'CPU') : (color === 'w' ? 'PLAYER 1' : 'PLAYER 2');
  for (const [position, color] of [['top', topColor], ['bottom', bottomColor]]) {
    document.getElementById(position + 'Avatar').textContent = avatar(color);
    document.getElementById(position + 'Avatar').className = 'player-avatar ' + (color === 'w' ? 'avatar-white' : 'avatar-black');
    document.getElementById(position + 'PlayerName').textContent = playerName(color);
    document.getElementById(position + 'PlayerRole').textContent = role(color);
  }
}

function renderBoard() {
  boardElement.innerHTML = '';
  const checkedKing = isInCheck(gameState, gameState.turn) ? findKing(gameState, gameState.turn) : -1;
  for (let displayRow = 0; displayRow < 8; displayRow += 1) {
    for (let displayCol = 0; displayCol < 8; displayCol += 1) {
      const row = boardFlipped ? 7 - displayRow : displayRow;
      const col = boardFlipped ? 7 - displayCol : displayCol;
      const square = row * 8 + col;
      const piece = gameState.board[square];
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'square ' + ((row + col) % 2 === 0 ? 'light' : 'dark');
      button.dataset.square = String(square);
      button.setAttribute('aria-label', squareName(square) + (piece ? ', ' + (colorOf(piece) === 'w' ? 'white ' : 'black ') + ({ p:'pawn', n:'knight', b:'bishop', r:'rook', q:'queen', k:'king' })[pieceType(piece)] : ', empty'));
      if (selectedSquare === square) button.classList.add('selected');
      if (lastMove && (lastMove.from === square || lastMove.to === square)) button.classList.add(lastMove.from === square ? 'last-from' : 'last-to');
      if (square === checkedKing) button.classList.add('in-check');
      const available = selectedMoves.find(move => move.to === square);
      if (available) {
        const hint = document.createElement('span');
        hint.className = 'move-hint' + ((piece || available.enPassant) ? ' capture-hint' : '');
        button.appendChild(hint);
      }
      if (displayCol === 0) {
        const rank = document.createElement('span');
        rank.className = 'coord coord-rank';
        rank.textContent = rankName(square);
        button.appendChild(rank);
      }
      if (displayRow === 7) {
        const file = document.createElement('span');
        file.className = 'coord coord-file';
        file.textContent = FILES[col];
        button.appendChild(file);
      }
      if (piece) {
        button.appendChild(makePieceImage(piece));
      }
      button.addEventListener('click', () => handleSquareClick(square));
      button.draggable = !!piece && !gameResult && !computerThinking && (playMode !== 'cpu' || gameState.turn === 'w') && colorOf(piece) === gameState.turn;
      button.addEventListener('dragstart', event => {
        if (!button.draggable) { event.preventDefault(); return; }
        draggedFrom = square;
        selectedSquare = square;
        selectedMoves = legalMovesFrom(gameState, square);
        if (event.dataTransfer) { event.dataTransfer.effectAllowed = 'move'; event.dataTransfer.setData('text/plain', String(square)); }
      });
      button.addEventListener('dragover', event => { if (draggedFrom !== null) event.preventDefault(); });
      button.addEventListener('drop', event => {
        event.preventDefault();
        if (draggedFrom === null) return;
        const from = draggedFrom;
        draggedFrom = null;
        const options = legalMovesFrom(gameState, from).filter(move => move.to === square);
        if (options.some(move => move.promotion)) showPromotionChoices(options);
        else if (options.length) commitMove(options[0]);
        else { selectedSquare = null; selectedMoves = []; renderBoard(); }
      });
      button.addEventListener('dragend', () => { draggedFrom = null; });
      boardElement.appendChild(button);
    }
  }
}

function renderMoveList() {
  const latestIndex = moveHistory.length - 1;
  document.getElementById('historyCount').textContent = moveHistory.length + (moveHistory.length === 1 ? ' MOVE' : ' MOVES');
  document.getElementById('moveCount').textContent = String(moveHistory.length).padStart(2, '0');
  if (!moveHistory.length) {
    moveListElement.innerHTML = '<div class="empty-history"><span class="empty-mark">♞</span><span>Your first move<br>starts the story.</span></div>';
    return;
  }
  moveListElement.innerHTML = '';
  for (let i = 0; i < moveHistory.length; i += 2) {
    const whiteMove = moveHistory[i];
    const blackMove = moveHistory[i + 1];
    const row = document.createElement('div');
    row.className = 'move-row';
    const number = document.createElement('span'); number.className = 'move-number'; number.textContent = whiteMove.number + '.';
    const white = document.createElement('span'); white.className = 'move-san' + (i === latestIndex ? ' latest' : ''); white.textContent = whiteMove.san;
    const black = document.createElement('span'); black.className = 'move-san' + (i + 1 === latestIndex ? ' latest' : ''); black.textContent = blackMove ? blackMove.san : '·';
    row.append(number, white, black);
    moveListElement.appendChild(row);
  }
  moveListElement.scrollTop = moveListElement.scrollHeight;
}

function renderCaptured() {
  for (const color of ['w', 'b']) {
    const targetId = color === 'w' ? 'capturedByWhite' : 'capturedByBlack';
    const countId = color === 'w' ? 'whiteCaptureCount' : 'blackCaptureCount';
    const target = document.getElementById(targetId);
    const pieces = capturedPieces[color].slice().sort((a, b) => (PIECE_VALUES[pieceType(b)] || 0) - (PIECE_VALUES[pieceType(a)] || 0));
    document.getElementById(countId).textContent = String(pieces.length);
    target.innerHTML = '';
    if (!pieces.length) { target.textContent = '—'; continue; }
    for (const piece of pieces) {
      const span = makePieceImage(piece, 'captured-piece-image');
      span.title = ({ p: 'Pawn', n: 'Knight', b: 'Bishop', r: 'Rook', q: 'Queen', k: 'King' })[pieceType(piece)];
      target.appendChild(span);
    }
  }
}

function renderStatus() {
  const badge = document.getElementById('turnBadge');
  const text = document.getElementById('turnText');
  badge.classList.remove('black-turn', 'check-turn');
  if (gameResult) {
    text.textContent = gameResult.type === 'checkmate' ? 'CHECKMATE' : 'GAME OVER';
    badge.classList.add('check-turn');
    gameMessage.hidden = false;
    gameMessage.textContent = gameResult.message + ' Start a new game to play again.';
    document.getElementById('boardHint').textContent = 'Match complete';
  } else {
    const side = gameState.turn === 'w' ? 'WHITE' : 'BLACK';
    const check = isInCheck(gameState, gameState.turn);
    text.textContent = computerThinking ? 'CPU THINKING…' : side + (check ? ' IN CHECK' : ' TO MOVE');
    if (gameState.turn === 'b') badge.classList.add('black-turn');
    if (check) badge.classList.add('check-turn');
    gameMessage.hidden = true;
    if (computerThinking) document.getElementById('boardHint').textContent = 'CPU is thinking…';
    else if (playMode === 'cpu') document.getElementById('boardHint').textContent = gameState.turn === 'w' ? 'Your move — White' : 'CPU controls Black';
    else document.getElementById('boardHint').textContent = 'Tap a piece to see its moves';
  }
  document.getElementById('undoBtn').disabled = undoStack.length === 0 || computerThinking;
  document.getElementById('flipBtn').disabled = computerThinking;
  document.getElementById('localModeBtn').disabled = computerThinking;
  document.getElementById('cpuModeBtn').disabled = computerThinking;
}

function renderAll() {
  setModeButtons();
  updatePlayerLabels();
  renderBoard();
  renderMoveList();
  renderCaptured();
  renderStatus();
}

function playSound(kind) {
  if (!soundEnabled) return;
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!audioContext) audioContext = new AudioCtx();
    if (audioContext.state === 'suspended') audioContext.resume();
    const now = audioContext.currentTime;
    // Short, layered arcade-chess cues generated locally; no sound files or internet needed.
    const patterns = {
      select:  [{ f: 740, t: 0, d: .065, v: .035, w: 'sine' }, { f: 980, t: .035, d: .07, v: .018, w: 'triangle' }],
      move:    [{ f: 390, t: 0, d: .055, v: .045, w: 'triangle' }, { f: 560, t: .025, d: .09, v: .04, w: 'sine' }, { f: 760, t: .07, d: .085, v: .018, w: 'triangle' }],
      capture: [{ f: 620, t: 0, d: .07, v: .055, w: 'square' }, { f: 390, t: .045, d: .12, v: .05, w: 'triangle' }, { f: 250, t: .10, d: .16, v: .04, w: 'sawtooth' }, { f: 180, t: .16, d: .12, v: .025, w: 'sine' }],
      check:   [{ f: 740, t: 0, d: .10, v: .05, w: 'triangle' }, { f: 988, t: .10, d: .12, v: .05, w: 'triangle' }, { f: 1318, t: .21, d: .18, v: .04, w: 'sine' }],
      win:     [{ f: 523, t: 0, d: .18, v: .045, w: 'triangle' }, { f: 659, t: .12, d: .20, v: .05, w: 'triangle' }, { f: 784, t: .25, d: .22, v: .055, w: 'triangle' }, { f: 1046, t: .39, d: .32, v: .055, w: 'sine' }, { f: 1318, t: .56, d: .42, v: .035, w: 'sine' }],
      draw:    [{ f: 440, t: 0, d: .16, v: .04, w: 'sine' }, { f: 392, t: .16, d: .2, v: .035, w: 'triangle' }, { f: 330, t: .34, d: .25, v: .03, w: 'sine' }]
    };    const pattern = patterns[kind] || patterns.move;
    pattern.forEach(note => {
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      const at = now + note.t;
      oscillator.type = note.w;
      oscillator.frequency.setValueAtTime(note.f, at);
      gain.gain.setValueAtTime(.0001, at);
      gain.gain.exponentialRampToValueAtTime(note.v, at + .012);
      gain.gain.exponentialRampToValueAtTime(.0001, at + note.d);
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start(at);
      oscillator.stop(at + note.d + .015);
    });
  } catch (_) { /* Audio is optional; the game still works without it. */ }
}

function showResultModal() {
  const modal = document.getElementById('resultModal');
  if (!modal || !gameResult) return;
  const isMate = gameResult.type === 'checkmate';
  const winner = gameState.turn === 'w' ? 'Black' : 'White';
  document.getElementById('resultTitle').textContent = isMate ? (winner + ' Wins!') : 'Game Over';
  document.getElementById('resultSubtitle').textContent = isMate
    ? 'Checkmate! What a finish. Celebrate the win and play again.'
    : (gameResult.message || 'A hard-fought game. Well played!');
  document.getElementById('resultIcon').textContent = isMate ? '★' : '🤝';
  document.getElementById('resultLabel').textContent = isMate ? 'VICTORY' : 'DRAW';
  document.getElementById('resultMoves').textContent = String(moveHistory.length);
  modal.hidden = false;
}

// Controls

document.getElementById('closeResult').addEventListener('click', () => { document.getElementById('resultModal').hidden = true; });
document.getElementById('reviewResult').addEventListener('click', () => { document.getElementById('resultModal').hidden = true; document.getElementById('boardHint').textContent = 'Game review — final position'; });
document.getElementById('newBotResult').addEventListener('click', () => startNewGame(playMode));
document.getElementById('resultModal').addEventListener('click', event => { if (event.target.id === 'resultModal') event.currentTarget.hidden = true; });
document.getElementById('newGameTop').addEventListener('click', () => startNewGame(playMode));
document.getElementById('localModeBtn').addEventListener('click', () => { if (playMode !== 'local') startNewGame('local'); });
document.getElementById('cpuModeBtn').addEventListener('click', () => { if (playMode !== 'cpu') startNewGame('cpu'); });
document.getElementById('undoBtn').addEventListener('click', doUndo);
document.getElementById('flipBtn').addEventListener('click', () => { boardFlipped = !boardFlipped; renderAll(); });
document.getElementById('soundBtn').addEventListener('click', () => {
  soundEnabled = !soundEnabled;
  document.getElementById('soundBtn').setAttribute('aria-pressed', String(soundEnabled));
  document.getElementById('soundText').textContent = soundEnabled ? 'Sound on' : 'Sound off';
  document.getElementById('soundIcon').textContent = soundEnabled ? '♫' : '♪';
  if (soundEnabled) playSound('select');
});
document.getElementById('cancelPromotion').addEventListener('click', () => { pendingPromotion = null; promotionModal.hidden = true; });
promotionModal.addEventListener('click', event => { if (event.target === promotionModal) { pendingPromotion = null; promotionModal.hidden = true; } });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && !promotionModal.hidden) { pendingPromotion = null; promotionModal.hidden = true; }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); doUndo(); }
});

// Initial render.
positionCounts[positionKey(gameState)] = 1;


// Offline-only local account demo. Profiles stay on this device; this is not a server account.
const accountModal = document.getElementById('accountModal');
const accountForm = document.getElementById('accountForm');
let accountMode = 'signup';
function accountStore() {
  try { return JSON.parse(localStorage.getItem('jzstLocalAccounts') || '{}'); } catch (_) { return {}; }
}
function simpleLocalHash(value) {
  // Local demo verifier only; do not reuse passwords from other services.
  let h1 = 0x811c9dc5;
  for (let i = 0; i < value.length; i++) { h1 ^= value.charCodeAt(i); h1 = Math.imul(h1, 0x01000193); }
  return (h1 >>> 0).toString(16);
}
function setAccountMode(mode) {
  accountMode = mode;
  document.getElementById('accountModalTitle').textContent = mode === 'signup' ? 'Create your account' : 'Welcome back';
  document.getElementById('accountSubmit').textContent = mode === 'signup' ? 'Sign up' : 'Sign in';
  document.getElementById('accountSwitchText').textContent = mode === 'signup' ? 'Already have an account?' : 'New to JZst Games?';
  document.getElementById('accountSwitch').textContent = mode === 'signup' ? 'Sign in' : 'Sign up';
  document.getElementById('accountMessage').textContent = 'Local demo account — saved only in this browser on this device.';
  document.getElementById('accountPassword').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
}
function openAccountModal() {
  setAccountMode('signup');
  document.getElementById('accountEmail').value = '';
  document.getElementById('accountPassword').value = '';
  accountModal.hidden = false;
}
document.getElementById('accountOpenBtn').addEventListener('click', openAccountModal);
document.getElementById('accountClose').addEventListener('click', () => { accountModal.hidden = true; });
document.getElementById('accountSwitch').addEventListener('click', () => setAccountMode(accountMode === 'signup' ? 'signin' : 'signup'));
accountModal.addEventListener('click', event => { if (event.target === accountModal) accountModal.hidden = true; });
accountForm.addEventListener('submit', event => {
  event.preventDefault();
  const email = document.getElementById('accountEmail').value.trim().toLowerCase();
  const password = document.getElementById('accountPassword').value;
  const message = document.getElementById('accountMessage');
  if (!email || password.length < 6) { message.textContent = 'Enter a valid email and a password with at least 6 characters.'; return; }
  const accounts = accountStore();
  if (accountMode === 'signup') {
    if (accounts[email]) { message.textContent = 'That email already has a local profile. Try signing in.'; return; }
    accounts[email] = { passwordHash: simpleLocalHash(password), displayName: email.split('@')[0] };
    try { localStorage.setItem('jzstLocalAccounts', JSON.stringify(accounts)); localStorage.setItem('jzstCurrentAccount', email); }
    catch (_) { message.textContent = 'Storage is unavailable in this preview. Try opening the project in your browser.'; return; }
    document.getElementById('accountOpenBtn').textContent = '♙ ' + accounts[email].displayName;
    message.textContent = 'Account created on this device. You are signed in!';
    setTimeout(() => { accountModal.hidden = true; }, 800);
  } else {
    if (!accounts[email] || accounts[email].passwordHash !== simpleLocalHash(password)) { message.textContent = 'Email or password is incorrect for this device.'; return; }
    try { localStorage.setItem('jzstCurrentAccount', email); } catch (_) {}
    document.getElementById('accountOpenBtn').textContent = '♙ ' + accounts[email].displayName;
    message.textContent = 'Signed in on this device!';
    setTimeout(() => { accountModal.hidden = true; }, 700);
  }
});
(function restoreLocalAccount() {
  try {
    const email = localStorage.getItem('jzstCurrentAccount');
    const profile = email && accountStore()[email];
    if (profile) document.getElementById('accountOpenBtn').textContent = '♙ ' + profile.displayName;
  } catch (_) {}
})();

renderAll();
