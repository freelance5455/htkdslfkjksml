
"use strict";

/* =========================================
   LITE TV GAME CENTER 4.0
   10 GAMES • 100 LEVELS EACH
   DIRECT TOUCHSCREEN CONTROLS
========================================= */

const $ = id => document.getElementById(id);
const canvas = $("board");
const ctx = canvas.getContext("2d");

const W = 800;
const H = 500;

const definitions = [
  ["Snake", "🐍", "snake"],
  ["Classic Ball", "🧱", "ball"],
  ["Tic Tac Toe", "❌", "ttt"],
  ["Memory Match", "🧠", "memory"],
  ["2048", "🔢", "2048"],
  ["Flappy Bird", "🐥", "flappy"],
  ["Space Shooter", "🚀", "shooter"],
  ["Minesweeper", "💣", "mines"],
  ["Pong", "🏓", "pong"],
  ["Number Puzzle", "🧩", "puzzle"]
];

let progress = {};
let current = null;
let level = 1;
let score = 0;
let best = 0;
let state = {};

let running = false;
let paused = false;
let raf = 0;
let lastTime = 0;
let snakeSpeed = 1;
let memoryTimer = null;

let pointerStart = null;
let pointerMoved = false;
let pointerLast = null;

const random = n => Math.floor(Math.random() * n);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

try {
  progress = JSON.parse(localStorage.getItem("liteProgress") || "{}");
  if (!progress || typeof progress !== "object") progress = {};
} catch {
  progress = {};
}

/* STORAGE */

function saveData() {
  try {
    localStorage.setItem("liteProgress", JSON.stringify(progress));
  } catch {
    $("message").textContent = "Storage unavailable!";
  }
}

function getProgress(type) {
  return progress[type] || {
    level: 1,
    passed: 0,
    best: 0
  };
}

/* HOME MENU */

function renderMenu() {
  const q = $("search").value.toLowerCase().trim();
  $("games").innerHTML = "";

  definitions.forEach(([name, icon, type]) => {
    if (!name.toLowerCase().includes(q)) return;

    const p = getProgress(type);
    const card = document.createElement("article");
    card.className = "game";

    const art = document.createElement("div");
    art.className = "art";
    art.textContent = icon;

    const info = document.createElement("div");
    info.className = "info";

    const title = document.createElement("h3");
    title.textContent = icon + " " + name;

    const desc = document.createElement("p");
    desc.textContent = "🎯 100 Levels";

    const count = document.createElement("p");
    count.textContent = "🏆 Completed: " + p.passed + "/100";

    const bar = document.createElement("div");
    bar.className = "progress";

    const fill = document.createElement("div");
    fill.style.width = clamp(p.passed, 0, 100) + "%";
    bar.appendChild(fill);

    const play = document.createElement("button");
    play.className = "play";
    play.textContent = "▶ PLAY NOW";
    play.onclick = () => startGame(type);

    info.append(title, desc, count, bar, play);
    card.append(art, info);
    $("games").appendChild(card);
  });

  const completed = definitions.reduce(
    (n, g) => n + clamp(getProgress(g[2]).passed, 0, 100),
    0
  );

  $("completed").innerHTML =
    completed + "<small>Completed</small>";
}

$("search").addEventListener("input", renderMenu);

/* GAME START */

function startGame(type) {
  clearTimeout(memoryTimer);

  current = type;
  const p = getProgress(type);

  level = clamp(p.level || 1, 1, 100);
  best = p.best || 0;

  $("home").hidden = true;
  $("gamePage").hidden = false;

  $("gameTitle").textContent =
    definitions.find(g => g[2] === type)[0];

  paused = false;
  renderLevels();
  newLevel();
}

function newLevel() {
  cancelAnimationFrame(raf);
  clearTimeout(memoryTimer);

  running = true;
  paused = false;
  score = 0;
  lastTime = 0;

  $("nextButton").hidden = true;
  $("pauseBtn").textContent = "Ⅱ";

  initialize();
  updateInfo();

  $("message").textContent =
    "LEVEL " + level + " - TOUCH TO PLAY!";

  raf = requestAnimationFrame(loop);
}

function initialize() {
  switch (current) {

    case "snake":
      state = {
        snake: [{ x: 10, y: 6 }],
        dir: { x: 1, y: 0 },
        food: { x: 15, y: 6 },
        tick: 0,
        eaten: 0,
        target: level * 2 + 3
      };
      break;

    case "ball":
      state = {
        x: 400, y: 420,
        dx: 2.5 + level * .015,
        dy: -3,
        paddle: 400,
        bricks: Array.from({ length: 27 }, (_, i) => ({
          x: 70 + (i % 9) * 74,
          y: 65 + Math.floor(i / 9) * 32,
          alive: true
        }))
      };
      break;

    case "ttt":
      state = {
        cells: Array(9).fill(""),
        turn: "X"
      };
      break;

    case "memory": {
      const pairs = Math.min(4 + Math.floor((level - 1) / 8), 12);
      const cards = Array.from({ length: pairs }, (_, i) => i + 1);
      state = {
        cards: shuffle(cards.concat(cards)),
        shown: [],
        matched: [],
        pairs
      };
      break;
    }

    case "2048":
      state = {
        grid: Array.from({ length: 4 }, () => Array(4).fill(0)),
        target: Math.pow(2, Math.min(11, level + 3))
      };
      addTile();
      addTile();
      break;

    case "flappy":
      state = {
        y: 250,
        vy: 0,
        pipes: [],
        ticks: 0,
        passed: 0,
        target: 3 + Math.floor(level / 5)
      };
      break;

    case "shooter":
      state = {
        x: 400,
        shots: [],
        enemies: [],
        ticks: 0,
        kills: 0,
        target: 5 + Math.floor(level / 3)
      };
      break;

    case "mines": {
      const n = 8 + Math.min(4, Math.floor(level / 20));
      state = {
        size: n,
        grid: Array.from({ length: n }, () => Array(n).fill(0)),
        open: [],
        mines: Math.min(10 + Math.floor(level / 5), n * n - 10),
        placed: false,
        lost: false
      };
      break;
    }

    case "pong":
      state = {
        x: 400, y: 250,
        dx: 3 + level * .015,
        dy: 2.5,
        paddle: 250,
        enemy: 250,
        hits: 0,
        target: 5 + Math.floor(level / 3)
      };
      break;

    case "puzzle": {
      const n = Math.min(6, 3 + Math.floor((level - 1) / 10));
      state = {
        size: n,
        moves: 0,
        tiles: Array.from({ length: n * n }, (_, i) =>
          (i + 1) % (n * n)
        )
      };
      shufflePuzzle();
      break;
    }
  }
}

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = random(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

/* SCORE */

function updateInfo() {
  $("levelText").textContent = level;
  $("scoreText").textContent = score;
  $("bestText").textContent = best;
}

function addScore(n = 1) {
  score += n;
  best = Math.max(best, score);
  updateInfo();
}

/* SAVE */

function save() {
  if (!current) return;

  const p = getProgress(current);
  p.level = Math.max(p.level, level);
  p.best = Math.max(p.best, best, score);
  progress[current] = p;

  saveData();
  renderMenu();
  $("message").textContent = "✓ PROGRESS SAVED!";
}

/* LEVEL SELECT */

function renderLevels() {
  $("levels").innerHTML = "";
  const unlocked = getProgress(current).level;

  for (let i = 1; i <= 100; i++) {
    const b = document.createElement("button");
    b.textContent = "LV " + i;

    if (i <= unlocked) b.classList.add("unlocked");
    if (i === level) b.classList.add("current");

    b.disabled = i > unlocked;

    b.onclick = () => {
      if (i > getProgress(current).level) return;
      level = i;
      renderLevels();
      newLevel();
    };

    $("levels").appendChild(b);
  }
}

/* WIN / LOSE */

function win() {
  if (!running) return;

  running = false;
  paused = false;

  cancelAnimationFrame(raf);
  clearTimeout(memoryTimer);

  const p = getProgress(current);
  p.passed = Math.max(p.passed, level);
  p.best = Math.max(p.best, best, score);
  p.level = Math.min(100, Math.max(p.level, level + 1));

  progress[current] = p;

  saveData();
  renderMenu();
  renderLevels();

  $("message").textContent =
    level === 100 ? "🏆 LEVEL 100 COMPLETE!" : "🎉 LEVEL COMPLETE!";

  $("nextButton").hidden = false;
  $("nextButton").textContent =
    level === 100 ? "PLAY LEVEL 100 AGAIN" : "NEXT LEVEL ▶";
}

function lose() {
  if (!running) return;

  running = false;
  paused = false;

  cancelAnimationFrame(raf);
  $("message").textContent = "GAME OVER! TOUCH THE SCREEN TO RETRY.";
}

function pauseGame() {
  if (!current) return;

  if (running) {
    running = false;
    paused = true;
    cancelAnimationFrame(raf);
    $("pauseBtn").textContent = "▶";
    $("message").textContent = "Ⅱ PAUSED";
  } else if (paused) {
    paused = false;
    running = true;
    lastTime = 0;
    $("pauseBtn").textContent = "Ⅱ";
    $("message").textContent = "PLAYING...";
    raf = requestAnimationFrame(loop);
  }
}

function exitGame() {
  running = false;
  paused = false;
  cancelAnimationFrame(raf);
  clearTimeout(memoryTimer);
  current = null;

  $("gamePage").hidden = true;
  $("home").hidden = false;
  renderMenu();
}

$("saveBtn").onclick = save;
$("pauseBtn").onclick = pauseGame;
$("exitBtn").onclick = exitGame;

$("nextButton").onclick = () => {
  if (level >= 100) level = 100;
  else level++;

  renderLevels();
  newLevel();
};

$("snakeSpeed").onchange = e => {
  snakeSpeed = Number(e.target.value);
};

/* DRAW HELPERS */

function rect(x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function txt(t, x, y, size = 24, color = "white") {
  ctx.fillStyle = color;
  ctx.font = "bold " + size + "px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "alphabetic";
  ctx.fillText(String(t), x, y);
}

function circle(x, y, r, color) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
}

/* MAIN LOOP */

function loop(time = 0) {
  if (!running) return;

  if (!lastTime) lastTime = time;

  const delta = Math.min(time - lastTime, 50);
  lastTime = time;

  ctx.clearRect(0, 0, W, H);
  rect(0, 0, W, H, "#10151e");

  drawGame(delta);

  if (running) raf = requestAnimationFrame(loop);
}

function drawGame(delta) {
  switch (current) {
    case "snake": drawSnake(delta); break;
    case "ball": drawBall(); break;
    case "ttt": drawTTT(); break;
    case "memory": drawMemory(); break;
    case "2048": draw2048(); break;
    case "flappy": drawFlappy(delta); break;
    case "shooter": drawShooter(delta); break;
    case "mines": drawMines(); break;
    case "pong": drawPong(); break;
    case "puzzle": drawPuzzle(); break;
  }
}

/* 1. SNAKE */

function drawSnake(delta) {
  const s = state;
  s.tick += delta;

  if (s.tick >= 140 / snakeSpeed) {
    s.tick = 0;

    const h = s.snake[0];
    const n = {
      x: (h.x + s.dir.x + 20) % 20,
      y: (h.y + s.dir.y + 12) % 12
    };

    if (s.snake.some(p => p.x === n.x && p.y === n.y)) {
      lose();
      return;
    }

    s.snake.unshift(n);

    if (n.x === s.food.x && n.y === s.food.y) {
      s.eaten++;
      addScore();

      if (s.eaten >= s.target) {
        win();
        return;
      }

      do {
        s.food = { x: random(20), y: random(12) };
      } while (s.snake.some(p =>
        p.x === s.food.x && p.y === s.food.y
      ));
    } else {
      s.snake.pop();
    }
  }

  s.snake.forEach((p, i) =>
    rect(p.x * 40, p.y * 40, 37, 37,
      i ? "#269b5b" : "#65f49a")
  );

  rect(s.food.x * 40, s.food.y * 40, 37, 37, "#ff4652");
  txt("FOOD " + s.eaten + "/" + s.target, 400, 25, 18);
}

/* 2. CLASSIC BALL / BREAKOUT */

function drawBall() {
  const s = state;

  s.x += s.dx;
  s.y += s.dy;

  if (s.x < 9 || s.x > 791) s.dx *= -1;
  if (s.y < 9) s.dy = Math.abs(s.dy);

  if (s.y + 9 >= 460 && s.y - 9 <= 474 &&
      s.dy > 0 &&
      s.x >= s.paddle - 70 &&
      s.x <= s.paddle + 70) {
    s.y = 450;
    s.dy = -Math.abs(s.dy);
    s.dx = (s.x - s.paddle) / 70 * 3;
  }

  if (s.y > 500) {
    lose();
    return;
  }

  for (const b of s.bricks) {
    if (b.alive && s.x + 9 > b.x &&
        s.x - 9 < b.x + 65 &&
        s.y + 9 > b.y &&
        s.y - 9 < b.y + 20) {
      b.alive = false;
      s.dy *= -1;
      addScore();
      break;
    }
  }

  s.bricks.forEach(b => {
    if (b.alive) rect(b.x, b.y, 65, 20, "#ed4855");
  });

  rect(s.paddle - 70, 460, 140, 13, "#68e6a1");
  circle(s.x, s.y, 9, "white");

  if (s.bricks.every(b => !b.alive)) win();
}

/* 3. TIC TAC TOE */

function checkTTT(player) {
  const c = state.cells;
  const lines = [
    [0,1,2], [3,4,5], [6,7,8],
    [0,3,6], [1,4,7], [2,5,8],
    [0,4,8], [2,4,6]
  ];

  return lines.some(a => a.every(i => c[i] === player));
}

function drawTTT() {
  for (let i = 1; i < 3; i++) {
    rect(i * 266 - 3, 90, 6, 320, "#657080");
    rect(130, 90 + i * 106, 540, 6, "#657080");
  }

  state.cells.forEach((v, i) => {
    txt(v, (i % 3) * 266 + 133,
      Math.floor(i / 3) * 106 + 165,
      65, v === "X" ? "#ff5360" : "#60d9ff");
  });

  txt("YOU ARE X - COMPUTER O", 400, 45, 18);
}

function tttClick(x, y) {
  if (!running) return;

  const col = clamp(Math.floor(x / (W / 3)), 0, 2);
  const row = clamp(Math.floor(y / (H / 3)), 0, 2);
  const i = row * 3 + col;

  if (state.cells[i]) return;

  state.cells[i] = "X";

  if (checkTTT("X")) {
    addScore(10);
    win();
    return;
  }

  if (state.cells.every(Boolean)) {
    win();
    return;
  }

  const choices = state.cells
    .map((v, i) => v ? null : i)
    .filter(v => v !== null);

  let choice = choices.find(i => {
    state.cells[i] = "O";
    const result = checkTTT("O");
    state.cells[i] = "";
    return result;
  });

  if (choice === undefined) {
    choice = choices.includes(4) ? 4 : choices[random(choices.length)];
  }

  state.cells[choice] = "O";

  if (checkTTT("O")) {
    lose();
    return;
  }

  if (state.cells.every(Boolean)) win();
}

/* 4. MEMORY MATCH */

function memoryGeometry() {
  const n = state.cards.length;
  const cols = n > 16 ? 6 : n > 8 ? 5 : 4;
  const rows = Math.ceil(n / cols);
  const w = Math.min(105, 650 / cols);
  const h = Math.min(95, 350 / rows);
  const gap = 8;
  const sx = (800 - cols * (w + gap) + gap) / 2;

  return { n, cols, rows, w, h, gap, sx };
}

function drawMemory() {
  const s = state;
  const g = memoryGeometry();

  s.cards.forEach((v, i) => {
    const x = g.sx + (i % g.cols) * (g.w + g.gap);
    const y = 65 + Math.floor(i / g.cols) * (g.h + g.gap);
    const show = s.shown.includes(i) || s.matched.includes(i);

    rect(x, y, g.w, g.h, show ? "#28654d" : "#344154");
    txt(show ? v : "?", x + g.w / 2, y + g.h * .65, 28);
  });

  txt("FIND MATCHING PAIRS", 400, 30, 18);
}

function drawStaticMemory() {
  if (!running || current !== "memory") return;
  ctx.clearRect(0, 0, W, H);
  rect(0, 0, W, H, "#10151e");
  drawMemory();
}

function memoryClick(x, y) {
  const s = state;
  const g = memoryGeometry();

  const c = Math.floor((x - g.sx) / (g.w + g.gap));
  const r = Math.floor((y - 65) / (g.h + g.gap));
  const i = r * g.cols + c;

  if (c < 0 || c >= g.cols || r < 0 ||
      r >= g.rows || i >= g.n ||
      s.matched.includes(i) ||
      s.shown.includes(i) ||
      s.shown.length >= 2) return;

  s.shown.push(i);
  drawStaticMemory();

  if (s.shown.length !== 2) return;

  const [a, b] = s.shown;

  if (s.cards[a] === s.cards[b]) {
    s.matched.push(a, b);
    s.shown = [];
    addScore(2);

    if (s.matched.length === s.n) win();
  } else {
    const pair = [a, b];

    clearTimeout(memoryTimer);
    memoryTimer = setTimeout(() => {
      if (current !== "memory" || !running) return;

      if (s.shown.length === 2 &&
          s.shown[0] === pair[0] &&
          s.shown[1] === pair[1]) {
        s.shown = [];
        drawStaticMemory();
      }
    }, 750);
  }
}

/* 5. 2048 */

function addTile() {
  const empty = [];

  state.grid.forEach((r, y) =>
    r.forEach((v, x) => {
      if (!v) empty.push({ x, y });
    })
  );

  if (empty.length) {
    const p = empty[random(empty.length)];
    state.grid[p.y][p.x] = Math.random() < .9 ? 2 : 4;
  }
}

function draw2048() {
  const colors = {
    2:"#66798e", 4:"#527e99", 8:"#e09c43",
    16:"#db7542", 32:"#db5542", 64:"#c63d42",
    128:"#c7a43d", 256:"#bca12c",
    512:"#9caa39", 1024:"#42a78a", 2048:"#42cfa5"
  };

  state.grid.forEach((row, y) => row.forEach((v, x) => {
    const px = 190 + x * 105;
    const py = 55 + y * 105;

    rect(px, py, 95, 95,
      v ? colors[v] || "#8c64c5" : "#29313e");

    if (v) txt(v, px + 47, py + 59, 28);
  }));

  txt("TARGET " + state.target, 400, 485, 16);
}

function slide(dir) {
  if (!running || current !== "2048") return;

  const g = state.grid;
  let changed = false;
  let gained = 0;

  for (let i = 0; i < 4; i++) {
    const line = Array.from({ length: 4 }, (_, j) =>
      dir === "left" ? g[i][j] :
      dir === "right" ? g[i][3-j] :
      dir === "up" ? g[j][i] : g[3-j][i]
    );

    const a = line.filter(Boolean);
    const out = [];

    for (let j = 0; j < a.length; j++) {
      if (a[j] === a[j + 1]) {
        out.push(a[j] * 2);
        gained += a[j] * 2;
        j++;
      } else {
        out.push(a[j]);
      }
    }

    while (out.length < 4) out.push(0);

    out.forEach((v, j) => {
      const x = dir === "left" ? j :
        dir === "right" ? 3-j : i;

      const y = dir === "up" ? j :
        dir === "down" ? 3-j : i;

      if (g[y][x] !== v) changed = true;
      g[y][x] = v;
    });
  }

  if (!changed) return;

  if (gained) addScore(gained);

  if (Math.max(...g.flat()) >= state.target) {
    win();
    return;
  }

  addTile();

  const hasMoves = g.some((row, y) =>
    row.some((v, x) =>
      !v ||
      (x < 3 && v === row[x + 1]) ||
      (y < 3 && v === g[y + 1][x])
    )
  );

  if (!hasMoves) lose();
}

/* 6. FLAPPY BIRD */

function drawFlappy(delta) {
  const s = state;
  const step = delta / 16.67;

  s.vy += .28 * step;
  s.y += s.vy * step;
  s.ticks += step;

  if (s.ticks >= 115) {
    s.ticks = 0;
    const gap = Math.max(125, 180 - level * .5);
    const top = 55 + random(230);

    s.pipes.push({
      x: 820,
      top,
      bottom: top + gap,
      passed: false
    });
  }

  s.pipes.forEach(p => {
    p.x -= (3 + level * .06) * step;

    rect(p.x, 0, 65, p.top, "#40bb6e");
    rect(p.x, p.bottom, 65, H - p.bottom, "#40bb6e");

    if (p.x < 130 && p.x + 65 > 100 &&
        (s.y < p.top || s.y > p.bottom)) {
      lose();
    }

    if (!p.passed && p.x + 65 < 100) {
      p.passed = true;
      s.passed++;
      addScore();

      if (s.passed >= s.target) win();
    }
  });

  s.pipes = s.pipes.filter(p => p.x > -70);

  if (s.y > 480 || s.y < 0) {
    lose();
    return;
  }

  circle(100, s.y, 17, "#ffe14d");
  txt("TAP TO FLY", 400, 30, 18);
  txt(s.passed + "/" + s.target, 400, 55, 17);
}

/* 7. SPACE SHOOTER */

function drawShooter(delta) {
  const s = state;
  const step = delta / 16.67;
  s.ticks += step;

  if (s.ticks > 45) {
    s.ticks = 0;
    s.enemies.push({
      x: 30 + random(740),
      y: -30,
      speed: 2 + level * .04
    });
  }

  s.shots.forEach(b => {
    b.y -= 8 * step;
    rect(b.x - 3, b.y, 6, 18, "#ffe65c");
  });

  s.enemies.forEach(e => {
    e.y += e.speed * step;
    txt("👾", e.x, e.y, 28);

    if (e.y > 440) {
      lose();
    }
  });

  for (let i = s.enemies.length - 1; i >= 0; i--) {
    const e = s.enemies[i];
    const hit = s.shots.findIndex(b =>
      Math.abs(b.x - e.x) < 25 &&
      Math.abs(b.y - e.y) < 25
    );

    if (hit !== -1) {
      s.shots.splice(hit, 1);
      s.enemies.splice(i, 1);
      s.kills++;
      addScore();

      if (s.kills >= s.target) win();
    }
  }

  s.shots = s.shots.filter(b => b.y > -20);
  s.enemies = s.enemies.filter(e => e.y < 520);

  txt("🚀", s.x, 470, 40);
  txt("DESTROY " + s.kills + "/" + s.target, 400, 30, 18);
}

/* 8. MINESWEEPER */

function placeMines(firstX, firstY) {
  const s = state;
  let placed = 0;

  while (placed < s.mines) {
    const x = random(s.size);
    const y = random(s.size);

    if (x === firstX && y === firstY) continue;
    if (s.grid[y][x] === -1) continue;

    s.grid[y][x] = -1;
    