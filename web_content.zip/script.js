
/* ==========================================
   NAIJABIZ - BUSINESS MANAGEMENT ENGINE
   Version 2.0
   ========================================== */

"use strict";

// ---------- STORAGE ----------

const STORAGE = {
  documents: "naijabiz_documents_v2",
  customers: "naijabiz_customers_v2",
  products: "naijabiz_products_v2",
  debts: "naijabiz_debts_v2",
  settings: "naijabiz_settings_v2"
};

function loadData(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved ? JSON.parse(saved) : fallback;
  } catch (error) {
    console.error("Could not load:", key, error);
    return fallback;
  }
}

let documents = loadData(STORAGE.documents, []);
let customers = loadData(STORAGE.customers, []);
let products = loadData(STORAGE.products, []);
let debts = loadData(STORAGE.debts, []);

let settings = loadData(STORAGE.settings, {
  name: "My Business",
  phone: "",
  email: "",
  address: "",
  currency: "NGN"
});

let currentPreviewId = null;

// ---------- GENERAL HELPERS ----------

const $ = id => document.getElementById(id);

function saveAll() {
  try {
    localStorage.setItem(STORAGE.documents, JSON.stringify(documents));
    localStorage.setItem(STORAGE.customers, JSON.stringify(customers));
    localStorage.setItem(STORAGE.products, JSON.stringify(products));
    localStorage.setItem(STORAGE.debts, JSON.stringify(debts));
    localStorage.setItem(STORAGE.settings, JSON.stringify(settings));
    return true;
  } catch (error) {
    console.error(error);
    showToast("Storage is full. Export your records and free some space.");
    return false;
  }
}

function makeId(prefix) {
  return prefix + "_" + Date.now().toString(36) +
    "_" + Math.random().toString(36).slice(2, 8);
}

function money(amount) {
  const currency = settings.currency || "NGN";
  const symbols = {
    NGN: "₦",
    USD: "$",
    GBP: "£",
    EUR: "€"
  };

  const symbol = symbols[currency] || "₦";
  const number = Number(amount) || 0;

  return symbol + number.toLocaleString("en-NG", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, character => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

function formatDate(value) {
  if (!value) return "-";

  const date = new Date(value + (value.length === 10 ? "T00:00:00" : ""));

  if (Number.isNaN(date.getTime())) return escapeHTML(value);

  return date.toLocaleDateString("en-NG", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });
}

function showToast(message) {
  const container = $("toastContainer");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  container.appendChild(toast);

  setTimeout(() => toast.remove(), 3500);
}

function openModal(id) {
  const modal = $(id);
  if (modal) modal.classList.add("show");
}

function closeModal(id) {
  const modal = $(id);
  if (modal) modal.classList.remove("show");
}

function today() {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  return new Date(now.getTime() - offset * 60000)
    .toISOString().slice(0, 10);
}

// ---------- NAVIGATION ----------

const pageNames = {
  dashboard: "Overview",
  documents: "Documents",
  customers: "Customers",
  products: "Products & Services",
  debts: "Debt tracking",
  analytics: "Business analytics",
  settings: "Business settings"
};

function navigate(page) {
  if (!pageNames[page]) return;

  document.querySelectorAll(".page").forEach(section => {
    section.classList.remove("active");
  });

  const target = $(page + "Page");
  if (target) target.classList.add("active");

  document.querySelectorAll(".nav-link").forEach(button => {
    button.classList.toggle(
      "active",
      button.dataset.page === page
    );
  });

  $("pageTitle").textContent =
    page === "dashboard" ? "Business overview" : pageNames[page];

  $("breadcrumbPage").textContent = pageNames[page];

  $("sidebar").classList.remove("open");

  refreshAll();
}

document.querySelectorAll("[data-page]").forEach(button => {
  button.addEventListener("click", () => {
    navigate(button.dataset.page);
  });
});

$("menuButton").addEventListener("click", () => {
  $("sidebar").classList.toggle("open");
});

// ---------- BUSINESS IDENTITY ----------

function updateBusinessIdentity() {
  const name = settings.name || "My Business";
  const initial = name.trim().charAt(0).toUpperCase() || "B";

  $("sidebarBusinessName").textContent = name;
  $("welcomeBusinessName").textContent = name;
  $("profileAvatar").textContent = initial;
  document.querySelector(".workspace-avatar").textContent = initial;

  $("businessName").value = settings.name || "";
  $("businessPhone").value = settings.phone || "";
  $("businessEmail").value = settings.email || "";
  $("businessAddress").value = settings.address || "";
  $("businessCurrency").value = settings.currency || "NGN";
}

$("businessSettingsForm").addEventListener("submit", event => {
  event.preventDefault();

  settings = {
    name: $("businessName").value.trim() || "My Business",
    phone: $("businessPhone").value.trim(),
    email: $("businessEmail").value.trim(),
    address: $("businessAddress").value.trim(),
    currency: $("businessCurrency").value
  };

  saveAll();
  updateBusinessIdentity();
  refreshAll();
  showToast("Business information saved successfully.");
});

// ---------- REVENUE AND DEBT CALCULATIONS ----------

function totalRevenue() {
  const receiptRevenue = documents
    .filter(doc => doc.type === "Receipt")
    .reduce((sum, doc) => sum + Number(doc.total || 0), 0);

  const debtPayments = debts
    .reduce((sum, debt) => sum + Number(debt.paid || 0), 0);

  return receiptRevenue + debtPayments;
}

function totalOutstanding() {
  return debts.reduce((sum, debt) => {
    return sum + Math.max(
      0,
      Number(debt.amount || 0) - Number(debt.paid || 0)
    );
  }, 0);
}

function debtBalance(debt) {
  return Math.max(
    0,
    Number(debt.amount || 0) - Number(debt.paid || 0)
  );
}

function getCustomerBalance(name) {
  return debts
    .filter(debt =>
      debt.customer.toLowerCase() === String(name).toLowerCase()
    )
    .reduce((sum, debt) => sum + debtBalance(debt), 0);
}

// ---------- DASHBOARD ----------

function refreshDashboard() {
  $("totalRevenue").textContent = money(totalRevenue());
  $("chartRevenue").textContent = money(totalRevenue());
  $("totalDebt").textContent = money(totalOutstanding());
  $("totalCustomers").textContent = customers.length;
  $("totalDocuments").textContent = documents.length;

  $("debtNavCount").textContent =
    debts.filter(debt => debtBalance(debt) > 0).length;

  renderRecentDocuments();
  renderRevenueChart();
}

function renderRecentDocuments() {
  const body = $("recentDocuments");

  const recent = [...documents]
    .sort((a, b) => b.createdAt - a.createdAt)
    .slice(0, 6);

  if (!recent.length) {
    body.innerHTML = `
      <tr>
        <td colspan="6" class="empty-cell">
          No documents created yet. Create your first document to get started.
        </td>
      </tr>`;
    return;
  }

  body.innerHTML = recent.map(doc => `
    <tr>
      <td><strong>${escapeHTML(doc.number)}</strong></td>
      <td>${escapeHTML(doc.customer)}</td>
      <td>${escapeHTML(doc.type)}</td>
      <td><strong>${money(doc.total)}</strong></td>
      <td><span class="status ${doc.status === "Paid" ? "" : "pending"}">
        ${escapeHTML(doc.status)}
      </span></td>
      <td>
        <button class="table-action" data-action="preview-document"
          data-id="${escapeHTML(doc.id)}">View</button>
      </td>
    </tr>
  `).join("");
}

// ---------- REVENUE CHART ----------

function renderRevenueChart() {
  const chart = $("revenueChart");

  const now = new Date();
  const months = [];

  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    months.push({
      year: date.getFullYear(),
      month: date.getMonth(),
      label: date.toLocaleDateString("en-NG", { month: "short" }),
      value: 0
    });
  }

  documents
    .filter(doc => doc.type === "Receipt")
    .forEach(doc => {
      const date = new Date(doc.date + "T00:00:00");
      const month = months.find(item =>
        item.year === date.getFullYear() &&
        item.month === date.getMonth()
      );
      if (month) month.value += Number(doc.total || 0);
    });

  debts.forEach(debt => {
    if (!debt.paid || !debt.paymentDate) return;
    const date = new Date(debt.paymentDate + "T00:00:00");
    const month = months.find(item =>
      item.year === date.getFullYear() &&
      item.month === date.getMonth()
    );
    if (month) month.value += Number(debt.paid || 0);
  });

  const max = Math.max(...months.map(item => item.value), 1);

  chart.style.display = "flex";
  chart.style.flexDirection = "row";
  chart.style.alignItems = "end";
  chart.style.justifyContent = "space-around";
  chart.style.gap = "10px";
  chart.style.padding = "15px 5px 0";

  chart.innerHTML = months.map(item => {
    const height = Math.max(5, item.value / max * 105);

    return `
      <div style="flex:1;display:flex;flex-direction:column;
        justify-content:flex-end;align-items:center;height:145px;
        min-width:0;">
        <small style="font-size:9px;color:#8794a3;margin-bottom:6px;
          overflow-wrap:anywhere;text-align:center;">
          ${item.value ? money(item.value) : ""}
        </small>
        <div style="height:${height}px;width:70%;max-width:42px;
          min-height:5px;border-radius:7px 7px 2px 2px;
          background:linear-gradient(180deg,#28c996,#07865f);">
        </div>
        <small style="font-size:10px;color:#8794a3;margin-top:9px;">
          ${escapeHTML(item.label)}
        </small>
      </div>`;
  }).join("");
}

// ---------- DOCUMENTS ----------

function nextDocumentNumber(type) {
  const prefix = {
    Invoice: "INV",
    Receipt: "RCT",
    Quotation: "QTN"
  }[type] || "DOC";

  const count = documents.length + 1;

  return prefix + "-" + String(Date.now()).slice(-6) +
    "-" + count;
}

function openDocumentForm(type = "Invoice") {
  $("documentForm").reset();

  $("documentType").value = type;
  $("documentDate").value = today();
  $("documentItems").innerHTML = `
    <div class="document-item">
      <input type="text" class="item-name"
        placeholder="Item description" required>
      <input type="number" class="item-quantity"
        placeholder="Qty" min="1" value="1" required>
      <input type="number" class="item-price"
        placeholder="Price" min="0" step="0.01" required>
    </div>`;

  $("documentModalTitle").textContent = "Create " + type.toLowerCase();
  updateDocumentTotal();
  openModal("documentModal");
}

$("createDocumentButton").addEventListener("click", () => {
  openDocumentForm();
});

$("documentsCreateButton").addEventListener("click", () => {
  openDocumentForm();
});

document.querySelectorAll("[data-create]").forEach(button => {
  button.addEventListener("click", () => {
    openDocumentForm(button.dataset.create);
  });
});

$("addDocumentItem").addEventListener("click", () => {
  const item = document.createElement("div");
  item.className = "document-item";
  item.innerHTML = `
    <input type="text" class="item-name"
      placeholder="Item description" required>
    <input type="number" class="item-quantity"
      placeholder="Qty" min="1" value="1" required>
    <input type="number" class="item-price"
      placeholder="Price" min="0" step="0.01" required>`;

  $("documentItems").appendChild(item);
});

$("documentItems").addEventListener("input", updateDocumentTotal);

function collectDocumentItems() {
  return [...document.querySelectorAll("#documentItems .document-item")]
    .map(row => ({
      name: row.querySelector(".item-name").value.trim(),
      quantity: Number(row.querySelector(".item-quantity").value),
      price: Number(row.querySelector(".item-price").value)
    }))
    .filter(item => item.name && item.quantity > 0 && item.price >= 0);
}

function calculateItemsTotal(items) {
  return items.reduce((sum, item) => {
    return sum + item.quantity * item.price;
  }, 0);
}

function updateDocumentTotal() {
  const items = collectDocumentItems();
  $("documentTotal").textContent = money(calculateItemsTotal(items));
}

$("documentForm").addEventListener("submit", event => {
  event.preventDefault();

  const type = $("documentType").value;
  const items = collectDocumentItems();

  if (!items.length) {
    showToast("Add at least one valid item.");
    return;
  }

  const total = calculateItemsTotal(items);

  const documentRecord = {
    id: makeId("doc"),
    number: nextDocumentNumber(type),
    type,
    date: $("documentDate").value,
    customer: $("documentCustomer").value.trim(),
    phone: $("documentPhone").value.trim(),
    email: $("documentEmail").value.trim(),
    notes: $("documentNotes").value.trim(),
    items,
    total,
    status: type === "Receipt" ? "Paid" :
      type === "Invoice" ? "Unpaid" : "Pending",
    createdAt: Date.now()
  };

  documents.push(documentRecord);

  if (documentRecord.customer) {
    saveCustomerIfNew({
      name: documentRecord.customer,
      phone: documentRecord.phone,
      email: documentRecord.email
    });
  }

  saveAll();
  closeModal("documentModal");
  refreshAll();
  showToast(type + " created successfully.");

  openPreview(documentRecord.id);
});

// ---------- DOCUMENT LIST AND SEARCH ----------

function renderDocuments() {
  const body = $("allDocuments");
  const search = $("documentSearch").value.toLowerCase();
  const filter = $("documentFilter").value;

  const filtered = [...documents]
    .filter(doc => filter === "all" || doc.type === filter)
    .filter(doc =>
      doc.customer.toLowerCase().includes(search) ||
      doc.number.toLowerCase().includes(search)
    )
    .sort((a, b) => b.createdAt - a.createdAt);

  if (!filtered.length) {
    body.innerHTML = `
      <tr><td colspan="6" class="empty-cell">
        No matching documents found.
      </td></tr>`;
    return;
  }

  body.innerHTML = filtered.map(doc => `
    <tr>
      <td><strong>${escapeHTML(doc.number)}</strong></td>
      <td>${escapeHTML(doc.customer)}</td>
      <td>${escapeHTML(doc.type)}</td>
      <td><strong>${money(doc.total)}</strong></td>
      <td><span class="status ${doc.status === "Paid" ? "" : "pending"}">
        ${escapeHTML(doc.status)}
      </span></td>
      <td>
        <button class="table-action" data-action="preview-document"
          data-id="${escapeHTML(doc.id)}">View</button>
        <button class="table-action danger-action"
          data-action="delete-document"
          data-id="${escapeHTML(doc.id)}">Delete</button>
      </td>
    </tr>
  `).join("");
}

$("documentSearch").addEventListener("input", renderDocuments);
$("documentFilter").addEventListener("change", renderDocuments);

// ---------- DOCUMENT PREVIEW ----------

function documentHTML(doc) {
  const itemRows = doc.items.map(item => `
    <tr>
      <td>${escapeHTML(item.name)}</td>
      <td>${item.quantity}</td>
      <td>${money(item.price)}</td>
      <td>${money(item.quantity * item.price)}</td>
    </tr>
  `).join("");

  return `
    <div class="invoice-paper" style="padding:22px;color:#253346;
      background:#fff;border:1px solid #e7ebef;border-radius:10px;">

      <div style="display:flex;justify-content:space-between;
        gap:15px;flex-wrap:wrap;border-bottom:2px solid #10a879;
        padding-bottom:17px;margin-bottom:20px;">

        <div>
          <h2 style="color:#07865f;font-size:23px;">
            ${escapeHTML(settings.name)}
          </h2>
          <p style="font-size:11px;color:#718095;margin-top:7px;">
            ${escapeHTML(settings.address)}
          </p>
          <p style="font-size:11px;color:#718095;">
            ${escapeHTML(settings.phone)}
          </p>
          <p style="font-size:11px;color:#718095;">
            ${escapeHTML(settings.email)}
          </p>
        </div>

        <div style="text-align:right;">
          <h1 style="font-size:22px;color:#17263a;">
            ${escapeHTML(doc.type.toUpperCase())}
          </h1>
          <p style="font-size:11px;margin-top:8px;">
            ${escapeHTML(doc.number)}
          </p>
          <p style="font-size:11px;color:#718095;margin-top:5px;">
            ${formatDate(doc.date)}
          </p>
        </div>

      </div>

      <div style="margin-bottom:20px;">
        <p style="font-size:10px;color:#8290a0;font-weight:bold;">
          BILL TO
        </p>
        <h3 style="font-size:15px;margin-top:5px;">
          ${escapeHTML(doc.customer)}
        </h3>
        <p style="font-size:11px;color:#718095;">
          ${escapeHTML(doc.phone)}
        </p>
        <p style="font-size:11px;color:#718095;">
          ${escapeHTML(doc.email)}
        </p>
      </div>

      <div style="overflow-x:auto;">
        <table style="min-width:400px;">
          <thead>
            <tr>
              <th>ITEM</th>
              <th>QTY</th>
              <th>PRICE</th>
              <th>TOTAL</th>
            </tr>
          </thead>
          <tbody>${itemRows}</tbody>
        </table>
      </div>

      <div style="text-align:right;padding:20px 0;
        border-bottom:1px solid #e9edf2;">
        <p style="font-size:11px;color:#718095;">
          Total amount
        </p>
        <h2 style="font-size:25px;color:#07865f;margin-top:5px;">
          ${money(doc.total)}
        </h2>
      </div>

      <div style="padding-top:15px;">
        <p style="font-size:10px;color:#8290a0;font-weight:bold;">
          STATUS: ${escapeHTML(doc.status.toUpperCase())}
        </p>
        <p style="font-size:11px;margin-top:10px;line-height:1.7;">
          ${escapeHTML(doc.notes)}
        </p>
        <p style="font-size:10px;color:#8290a0;margin-top:22px;">
          Thank you for doing business with us.
        </p>
      </div>

    </div>`;
}

function openPreview(id) {
  const doc = documents.find(item => item.id === id);
  if (!doc) return;

  currentPreviewId = id;
  $("documentPreview").innerHTML = documentHTML(doc);
  openModal("previewModal");
}

$("printDocumentButton").addEventListener("click", () => {
  const doc = documents.find(item => item.id === currentPreviewId);
  if (!doc) return;

  const printWindow = window.open("", "_blank");

  if (!printWindow) {
    showToast("Allow pop-ups in your browser to print this document.");
    return;
  }

  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>${escapeHTML(doc.number)}</title>
      <style>
        body{font-family:Arial,sans-serif;padding:25px;color:#253346}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left}
        th{background:#f1f5f7}
        @media print{body{padding:0}}
      </style>
    </head>
    <body>
      ${documentHTML(doc)}
      <script>
        window.onload = function(){
          setTimeout(function(){window.print();},300);
        };
      <\/script>
    </body>
    </html>
  `);

  printWindow.document.close();
});

$("shareDocumentButton").addEventListener("click", () => {
  const doc = documents.find(item => item.id === currentPreviewId);
  if (!doc) return;

  const message = [
    settings.name,
    doc.type + ": " + doc.number,
    "Customer: " + doc.customer,
    "Date: " + doc.date,
    "Total: " + money(doc.total),
    "Status: " + doc.status,
    "",
    "Thank you for your business."
  ].join("\n");

  const url = "https://wa.me/?text=" + encodeURIComponent(message);
  window.open(url, "_blank");
});

// ---------- DELETE DOCUMENT ----------

function deleteDocument(id) {
  const doc = documents.find(item => item.id === id);
  if (!doc) return;

  if (!confirm("Delete " + doc.number + "? This cannot be undone.")) return;

  documents = documents.filter(item => item.id !== id);
  saveAll();
  refreshAll();
  showToast("Document deleted.");
}

// ---------- CUSTOMERS ----------

function saveCustomerIfNew(data) {
  const existing = customers.find(customer =>
    customer.name.toLowerCase() === data.name.toLowerCase()
  );

  if (existing) {
    if (!existing.phone && data.phone) existing.phone = data.phone;
    if (!existing.email && data.email) existing.email = data.email;
    return;
  }

  customers.push({
    id: makeId("customer"),
    name: data.name,
    phone: data.phone || "",
    email: data.email || "",
    createdAt: Date.now()
  });
}

$("addCustomerButton").addEventListener("click", () => {
  $("customerForm").reset();
  openModal("customerModal");
});

$("customerForm").addEventListener("submit", event => {
  event.preventDefault();

  const name = $("newCustomerName").value.trim();

  if (customers.some(customer =>
    customer.name.toLowerCase() === name.toLowerCase()
  )) {
    showToast("This customer is already saved.");
    return;
  }

  customers.push({
    id: makeId("customer"),
    name,
    phone: $("newCustomerPhone").value.trim(),
    email: $("newCustomerEmail").value.trim(),
    createdAt: Date.now()
  });

  saveAll();
  closeModal("customerModal");
  refreshAll();
  showToast("Customer saved successfully.");
});

function renderCustomers() {
  const body = $("customerList");
  const search = $("customerSearch").value.toLowerCase();

  const filtered = customers.filter(customer =>
    customer.name.toLowerCase().includes(search) ||
    customer.phone.toLowerCase().includes(search) ||
    customer.email.toLowerCase().includes(search)
  );

  if (!filtered.length) {
    body.innerHTML = `
      <tr><td colspan="5" class="empty-cell">
        No customers found. Add your first customer.
      </td></tr>`;
  } else {
    body.innerHTML = filtered.map(customer => `
      <tr>
        <td><strong>${escapeHTML(customer.name)}</strong></td>
        <td>${escapeHTML(customer.phone || "-")}</td>
        <td>${escapeHTML(customer.email || "-")}</td>
        <td><strong>${money(getCustomerBalance(customer.name))}</strong></td>
        <td>
          <button class="table-action danger-action"
            data-action="delete-customer"
            data-id="${escapeHTML(customer.id)}">Delete</button>
        </td>
      </tr>
    `).join("");
  }

  $("customerPageCount").textContent = customers.length;

  $("customersWithDebt").textContent =
    customers.filter(customer => getCustomerBalance(customer.name) > 0).length;
}

$("customerSearch").addEventListener("input", renderCustomers);

function deleteCustomer(id) {
  const customer = customers.find(item => item.id === id);
  if (!customer) return;

  if (!confirm("Delete this customer from your directory?")) return;

  customers = customers.filter(item => item.id !== id);
  saveAll();
  refreshAll();
  showToast("Customer deleted. Existing transaction records remain.");
}

// ---------- PRODUCTS AND SERVICES ----------

$("addProductButton").addEventListener("click", () => {
  $("productForm").reset();
  openModal("productModal");
});

$("productForm").addEventListener("submit", event => {
  event.preventDefault();

  products.push({
    id: makeId("product"),
    name: $("newProductName").value.trim(),
    description: $("newProductDescription").value.trim(),
    price: Number($("newProductPrice").value),
    createdAt: Date.now()
  });

  saveAll();
  closeModal("productModal");
  refreshAll();
  showToast("Product or service saved.");
});

function renderProducts() {
  const body = $("productList");
  const search = $("productSearch").value.toLowerCase();

  const filtered = products.filter(product =>
    product.name.toLowerCase().includes(search) ||
    product.description.toLowerCase().includes(search)
  );

  if (!filtered.length) {
    body.innerHTML = `
      <tr><td colspan="4" class="empty-cell">
        No products or services saved yet.
      </td></tr>`;
    return;
  }

  body.innerHTML = filtered.map(product => `
    <tr>
      <td><strong>${escapeHTML(product.name)}</strong></td>
      <td>${escapeHTML(product.description || "-")}</td>
      <td><strong>${money(product.price)}</strong></td>
      <td>
        <button class="table-action" data-action="use-product"
          data-id="${escapeHTML(product.id)}">Use in invoice</button>
        <button class="table-action danger-action"
          data-action="delete-product"
          data-id="${escapeHTML(product.id)}">Delete</button>
      </td>
    </tr>
  `).join("");
}

$("productSearch").addEventListener("input", renderProducts);

function useProduct(id) {
  const product = products.find(item => item.id === id);
  if (!product) return;

  openDocumentForm("Invoice");

  const row = $("documentItems").querySelector(".document-item");
  row.querySelector(".item-name").value = product.name;
  row.querySelector(".item-quantity").value = 1;
  row.querySelector(".item-price").value = product.price;

  updateDocumentTotal();
}

function deleteProduct(id) {
  if (!confirm("Delete this saved product or service?")) return;

  products = products.filter(item => item.id !== id);
  saveAll();
  refreshAll();
  showToast("Item deleted.");
}

// ---------- DEBT TRACKING ----------

$("addDebtButton").addEventListener("click", () => {
  $("debtForm").reset();
  $("debtPaid").value = 0;
  openModal("debtModal");
});

$("debtForm").addEventListener("submit", event => {
  event.preventDefault();

  const amount = Number($("debtAmount").value);
  const paid = Number($("debtPaid").value);

  if (amount <= 0 || paid < 0 || paid > amount) {
    showToast("Check the debt amount and payment amount.");
    return;
  }

  const debt = {
    id: makeId("debt"),
    customer: $("debtCustomer").value.trim(),
    description: $("debtDescription").value.trim(),
    amount,
    paid,
    date: today(),
    paymentDate: paid > 0 ? today() : "",
    createdAt: Date.now()
  };

  debts.push(debt);

  saveCustomerIfNew({
    name: debt.customer,
    phone: "",
    email: ""
  });

  saveAll();
  closeModal("debtModal");
  refreshAll();
  showToast("Debt record saved.");
});

function renderDebts() {
  const body = $("debtList");

  const outstanding = debts.filter(debt => debtBalance(debt) > 0);

  $("debtPageTotal").textContent = money(totalOutstanding());
  $("unpaidDebtCount").textContent = outstanding.length;

  if (!debts.length) {
    body.innerHTML = `
      <tr><td colspan="6" class="empty-cell">
        No debt records yet.
      </td></tr>`;
    return;
  }

  body.innerHTML = [...debts]
    .sort((a, b) => b.createdAt - a.createdAt)
    .map(debt => `
      <tr>
        <td><strong>${escapeHTML(debt.customer)}</strong></td>
        <td>${escapeHTML(debt.description || "-")}</td>
        <td>${money(debt.amount)}</td>
        <td>${money(debt.paid)}</td>
        <td><strong>${money(debtBalance(debt))}</strong></td>
        <td>
          ${debtBalance(debt) > 0 ? `
            <button class="table-action" data-action="pay-debt"
              data-id="${escapeHTML(debt.id)}">Record payment</button>
          ` : `<span class="status">Paid</span>`}
          <button class="table-action danger-action"
            data-action="delete-debt"
            data-id="${escapeHTML(debt.id)}">Delete</button>
        </td>
      </tr>
    `).join("");
}

function recordDebtPayment(id) {
  const debt = debts.find(item => item.id === id);
  if (!debt) return;

  const balance = debtBalance(debt);
  const input = prompt(
    "Outstanding balance: " + money(balance) +
    "\nEnter the amount received:"
  );

  if (input === null) return;

  const amount = Number(input);

  if (!Number.isFinite(amount) || amount <= 0 || amount > balance) {
    showToast("Enter a valid payment not exceeding the balance.");
    return;
  }

  debt.paid = Number(debt.paid) + amount;
  debt.paymentDate = today();

  saveAll();
  refreshAll();
  showToast("Payment recorded successfully.");
}

function deleteDebt(id) {
  if (!confirm("Delete this debt record?")) return;

  debts = debts.filter(item => item.id !== id);
  saveAll();
  refreshAll();
  showToast("Debt record deleted.");
}

// ---------- ANALYTICS ----------

function renderAnalytics() {
  $("analyticsRevenue").textContent = money(totalRevenue());
  $("analyticsDocuments").textContent = documents.length;
  $("analyticsCustomers").textContent = customers.length;
  $("analyticsDebt").textContent = money(totalOutstanding());

  const invoiceTotal = documents
    .filter(doc => doc.type === "Invoice")
    .reduce((sum, doc) => sum + Number(doc.total), 0);

  const receiptTotal = documents
    .filter(doc => doc.type === "Receipt")
    .reduce((sum, doc) => sum + Number(doc.total), 0);

  const quotationTotal = documents
    .filter(doc => doc.type === "Quotation")
    .reduce((sum, doc) => sum + Number(doc.total), 0);

  $("analyticsSummary").innerHTML = `
    <p>Invoices created: <strong>${documents.filter(d => d.type === "Invoice").length}</strong></p>
    <p>Invoice value: <strong>${money(invoiceTotal)}</strong></p>
    <p>Receipts issued: <strong>${documents.filter(d => d.type === "Receipt").length}</strong></p>
    <p>Receipt value: <strong>${money(receiptTotal)}</strong></p>
    <p>Quotations prepared: <strong>${documents.filter(d => d.type === "Quotation").length}</strong></p>
    <p>Quotation value: <strong>${money(quotationTotal)}</strong></p>
    <p>Payments recorded against debts: <strong>${money(
      debts.reduce((sum, debt) => sum + Number(debt.paid || 0), 0)
    )}</strong></p>
  `;
}

// ---------- DATA EXPORT ----------

$("exportDataButton").addEventListener("click", () => {
  const backup = {
    app: "NaijaBiz",
    version: "2.0",
    exportedAt: new Date().toISOString(),
    settings,
    documents,
    customers,
    products,
    debts
  };

  const blob = new Blob(
    [JSON.stringify(backup, null, 2)],
    { type: "application/json" }
  );

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = "NaijaBiz-Backup-" + today() + ".json";
  document.body.appendChild(link);
  link.click();
  link.remove();

  URL.revokeObjectURL(url);
  showToast("Business data backup exported.");
});

// ---------- NOTIFICATION ----------

$("notificationButton").addEventListener("click", () => {
  const count = debts.filter(debt => debtBalance(debt) > 0).length;

  showToast(
    count
      ? "You have " + count + " outstanding debt record(s)."
      : "You're all caught up. No unpaid debt records."
  );
});

// ---------- MODAL CLOSING ----------

document.querySelectorAll("[data-close]").forEach(button => {
  button.addEventListener("click", () => {
    closeModal(button.dataset.close);
  });
});

document.querySelectorAll(".modal-overlay").forEach(modal => {
  modal.addEventListener("click", event => {
    if (event.target === modal) {
      modal.classList.remove("show");
    }
  });
});

// ---------- TABLE ACTIONS ----------

document.addEventListener("click", event => {
  const button = event.target.closest("[data-action]");
  if (!button) return;

  const id = button.dataset.id;
  const action = button.dataset.action;

  switch (action) {
    case "preview-document":
      openPreview(id);
      break;

    case "delete-document":
      deleteDocument(id);
      break;

    case "delete-customer":
      deleteCustomer(id);
      break;

    case "use-product":
      useProduct(id);
      break;

    case "delete-product":
      deleteProduct(id);
      break;

    case "pay-debt":
      recordDebtPayment(id);
      break;

    case "delete-debt":
      deleteDebt(id);
      break;
  }
});

// ---------- REFRESH EVERYTHING ----------

function refreshAll() {
  refreshDashboard();
  renderDocuments();
  renderCustomers();
  renderProducts();
  renderDebts();
  renderAnalytics();
  updateBusinessIdentity();
}

// ---------- INITIALISE APPLICATION ----------

function initialiseApp() {
  $("todayDate").textContent = new Date().toLocaleDateString("en-NG", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric"
  });

  $("documentDate").value = today();

  updateBusinessIdentity();
  refreshAll();

  console.log("NaijaBiz business engine is ready.");
}

initialiseApp();
