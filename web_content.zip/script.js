"use strict";

// ========================================
// 1. بيانات البرنامج وحماية البيانات
// ========================================
const seed = {
  currency: "ل.س",
  id: 10,
  devices: [
    { id: 1, name: "كمبيوتر 1", type: "كمبيوتر", rate: 0 },
    { id: 2, name: "كمبيوتر 2", type: "كمبيوتر", rate: 0 },
    { id: 3, name: "بلايستيشن 4", type: "PS4", rate: 0 }
  ],
  items: [],
  history: [],
  expenses: [],
  hourlyRates: {
    "كمبيوتر": 0,
    "بلايستيشن": 0,
    "فيشة": 0,
    "بلياردو": 0,
    "أخرى": 0
  },
  settings: {
    textColor: "#edf4ff",
    accentColor: "#52d8e7",
    backgroundColor: "#0b1222",
    fontSize: 15
  }
};

let db;

try {
  db = JSON.parse(localStorage.getItem("game-lounge-demo")) ||
       JSON.parse(JSON.stringify(seed));
} catch (e) {
  db = JSON.parse(JSON.stringify(seed));
}

db.devices = Array.isArray(db.devices) ? db.devices : [];
db.items = Array.isArray(db.items) ? db.items : [];
db.history = Array.isArray(db.history) ? db.history : [];
db.expenses = Array.isArray(db.expenses) ? db.expenses : [];

db.hourlyRates = Object.assign(
  {},
  seed.hourlyRates,
  db.hourlyRates || {}
);

db.settings = Object.assign(
  {},
  seed.settings,
  db.settings || {}
);

// إصلاح المعرّفات المكررة دون حذف السجلات أو الأسعار.
{
  const seen = new Set();
  let next = Math.max(
    Number(db.id) || 1,
    ...db.devices.map(d => Number(d.id) || 0),
    ...db.items.map(p => Number(p.id) || 0),
    ...db.expenses.map(e => Number(e.id) || 0)
  ) + 1;

  db.devices.forEach(d => {
    if (seen.has(String(d.id))) d.id = next++;
    seen.add(String(d.id));
  });

  db.id = Math.max(Number(db.id) || 1, next);
}

let current = "home";
let target = 0;
let deviceCategoryFilter = "الكل";
let reportMode = "daily";
let reportDate = localDate();
let reportMonth = localMonth();

// ========================================
// 2. الأدوات والحفظ
// ========================================
function localDate(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function localMonth(d = new Date()) {
  return localDate(d).slice(0, 7);
}

function save() {
  localStorage.setItem("game-lounge-demo", JSON.stringify(db));
}

function cash(n) {
  return Math.round(Number(n) || 0).toLocaleString("en-US") +
    " " + (db.currency || "ل.س");
}

function priceText(n) {
  return Number(n) > 0 ? cash(n) : "لم يُحدّد السعر بعد";
}

function esc(s) {
  return String(s ?? "").replace(/[&<>"]/g, c => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;"
  }[c]));
}

function time(ms) {
  const x = Math.max(0, Math.floor(ms / 1000));
  return [
    Math.floor(x / 3600),
    Math.floor(x % 3600 / 60),
    x % 60
  ].map(n => String(n).padStart(2, "0")).join(":");
}

function sum(s) {
  return (s?.orders || []).reduce(
    (a, o) => a + (Number(o.price) || 0) * (Number(o.qty) || 0),
    0
  );
}

function notify(message) {
  const el = document.getElementById("toast");
  if (!el) {
    alert(message);
    return;
  }

  el.textContent = message;
  el.classList.add("show");

  setTimeout(() => el.classList.remove("show"), 2500);
}

function page(p, button) {
  current = p;

  if (p === "devices") deviceCategoryFilter = "الكل";

  document.querySelectorAll(".nav button").forEach(b => {
    b.classList.toggle("active", b === button);
  });

  render();
}

const deviceGroups = [
  { key: "كمبيوتر", title: "🖥️ أجهزة الكمبيوتر" },
  { key: "بلايستيشن", title: "🎮 أجهزة البلايستيشن" },
  { key: "فيشة", title: "⚽ طاولات الفيشة" },
  { key: "بلياردو", title: "🎱 طاولات البلياردو" },
  { key: "أخرى", title: "🎯 أجهزة أخرى" }
];

function categoryOf(d) {
  const type = String(d.type || "").trim();

  if (type === "كمبيوتر") return "كمبيوتر";

  if (["PS5", "PS4", "PS3", "بلايستيشن"].includes(type)) {
    return "بلايستيشن";
  }

  if (type === "فيشة") return "فيشة";
  if (type === "بلياردو") return "بلياردو";

  return "أخرى";
}

function deviceCategory(name) {
  deviceCategoryFilter = name;
  render();
}

function openDeviceCategory(name) {
  current = "devices";
  deviceCategoryFilter = name;

  document.querySelectorAll(".nav button").forEach((b, i) => {
    b.classList.toggle("active", i === 2);
  });

  render();
}

function categoryMenuHtml() {
  return `<div class="category-tiles">
    ${deviceGroups.filter(g => g.key !== "أخرى").map(g => {
      const count = db.devices.filter(d => categoryOf(d) === g.key).length;

      return `<button class="category-tile"
        onclick="openDeviceCategory('${g.key}')">
        <span class="category-icon">${g.title.split(" ")[0]}</span>
        <span class="category-name">${g.title.replace(/^.*? /, "")}</span>
        <span class="category-total">${count} عنصر</span>
        <span class="category-open">فتح القائمة ←</span>
      </button>`;
    }).join("")}
  </div>`;
}

function deviceSort(a, b) {
  const number = d => {
    const m = String(d.name).match(/\d+/);
    return m ? Number(m[0]) : Number.MAX_SAFE_INTEGER;
  };

  return number(a) - number(b) ||
    String(a.name).localeCompare(String(b.name), "ar");
}

function deviceGroupHtml(key, title) {
  const list = db.devices
    .filter(d => categoryOf(d) === key)
    .sort(deviceSort);

  return `<section class="device-group">
    <h3>${title} <span class="group-count">${list.length}</span></h3>
    ${list.length
      ? `<div class="devices">${list.map(card).join("")}</div>`
      : `<p class="muted empty-group">لا توجد عناصر في هذا القسم حالياً.</p>`
    }
  </section>`;
}

// ========================================
// 3. عرض الصفحات
// ========================================
function render() {
  const c = document.getElementById("content");
  if (!c) return;

  if (current === "home" || current === "devices") {
    renderDevicesPage(c);
  } else if (current === "items") {
    renderItemsPage(c);
  } else if (current === "expenses") {
    renderExpensesPage(c);
  } else if (current === "reports") {
    renderReports(c);
  } else if (current === "settings") {
    renderSettings(c);
  }
}

function renderDevicesPage(c) {
  const busy = db.devices.filter(d => d.s && !d.s.end).length;

  c.innerHTML = `${current === "home" ? `
    <h2>Game Lounge</h2>
    <p class="muted">ملخص الصالة وحالة الأجهزة والطاولات.</p>

    <div class="stats">
      <div class="stat">
        <small>إجمالي الأجهزة والطاولات</small>
        <strong>${db.devices.length}</strong>
      </div>
      <div class="stat">
        <small>المشغولة</small>
        <strong style="color:#ff637c">${busy}</strong>
      </div>
      <div class="stat">
        <small>المتاحة</small>
        <strong style="color:#38d49d">${db.devices.length - busy}</strong>
      </div>
      <div class="stat">
        <small>الجلسات المغلقة</small>
        <strong>${db.history.length}</strong>
      </div>
    </div>` : ""}

    <div class="bar">
      <div>
        <h2>${current === "home" ? "الأجهزة والطاولات" : "إدارة الأجهزة والطاولات"}</h2>
        <p class="muted">اختر نوع الجهاز لفتح قائمته.</p>
      </div>
      <button class="primary" onclick="deviceForm()">＋ إضافة جهاز أو طاولة</button>
    </div>

    ${current === "home" || deviceCategoryFilter === "الكل"
      ? categoryMenuHtml()
      : `<div class="category-view-head">
          <button onclick="deviceCategory('الكل')">← رجوع إلى أنواع الأجهزة</button>
          <h3>${deviceGroups.find(g => g.key === deviceCategoryFilter)?.title || "أجهزة أخرى"}</h3>
        </div>
        ${deviceGroupHtml(
          deviceCategoryFilter,
          deviceGroups.find(g => g.key === deviceCategoryFilter)?.title || "أجهزة أخرى"
        )}`
    }`;
}

function card(d) {
  
const s = d.s;
const paused = !!(s && !s.end && s.pausedAt);
const busy = !!(s && !s.end);
const done = !!(s && s.end);
const ord = sum(s);


  const icon = categoryOf(d) === "كمبيوتر" ? "🖥️"
    : categoryOf(d) === "بلايستيشن" ? "🎮"
    : categoryOf(d) === "بلياردو" ? "🎱"
    : categoryOf(d) === "فيشة" ? "⚽" : "🎯";

  return `<article class="card device ${busy ? "busy" : done ? "done" : ""}">
    <div class="between">
      <div>
        <h3>${icon} ${esc(d.name)}</h3>
        <small class="muted">${esc(d.type)} · ${priceText(d.rate)} للساعة</small>
      </div>
     <span class="pill ${busy ? "status-unavailable" : done ? "status-unavailable" : "status-available"}">
  ${busy ? "مشغول" : done ? "انتهت الجلسة" : "متاح"}
</span>
    </div>

    ${busy ? `
      
<div class="mini">
  <small class="muted">${paused ? "الجلسة متوقفة مؤقتاً" : "الوقت المنقضي"}</small>
  <div class="timer" id="timer${d.id}">${
    time(Math.max(0, (s.pausedAt || Date.now()) - s.start - (s.pausedTotal || 0)))
  }</div>
  <small class="muted">المدة المحددة: ${s.minutes ? s.minutes + " دقيقة" : "مفتوحة"}</small>
</div>

      <div class="actions">
        <button onclick="orders(${d.id})">🛒 الطلبات (${s.orders.length})</button>
      
${paused
  ? `<button class="good" onclick="resumeSession(${d.id})">▶ استئناف</button>`
  : `<button onclick="pauseSession(${d.id})">⏸ إيقاف مؤقت</button>`
}
<button class="bad" onclick="stop(${d.id})">إنهاء وحساب</button>

        <button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
      </div>
      <div class="sum">
        <span class="muted">مجموع الطلبات</span>
        <b class="gold">${cash(ord)}</b>
      </div>
    ` : done ? `
<div class="session-billing">
  <div class="billing-row">
    <span>أجرة الجلسة</span>
    <strong>${cash(s.game)}</strong>
  </div>
  <div class="billing-row">
    <span>مجموع الطلبات</span>
    <strong>${cash(s.orderTotal)}</strong>
  </div>
  <div class="billing-total">
    <span>المبلغ الكامل</span>
    <strong>${cash(s.total)}</strong>
  </div>
</div>
      <div class="actions">
        <button class="good" onclick="finishSession(${d.id})">إنهاء</button>
        <button onclick="showOrders(${d.id})">عرض الطلبات</button>
        <button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
      </div>
    ` : `
      <div class="mini">
        <small class="muted">سعر الساعة</small>
        <h3>${priceText(d.rate)}</h3>
      </div>
      <div class="actions">
        <button class="good" onclick="startForm(${d.id})">▶ بدء الوقت</button>
        <button onclick="editDevice(${d.id})">تعديل</button>
        <button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
      </div>
    `}
  </article>`;
}

// ========================================
// 4. النوافذ المنبثقة
// ========================================
function modal(html) {
  document.getElementById("modal").innerHTML = html;
  document.getElementById("bg").classList.add("show");
}

function closemodal() {
  document.getElementById("bg").classList.remove("show");
}

// ========================================
// 5. أسعار ساعات اللعب
// ========================================
function rateForType(type) {
  const group = categoryOf({ type });
  return Number(db.hourlyRates[group]) || 0;
}

function deviceForm() {
  modal(`<h3>إضافة جهاز أو طاولة</h3>

    <div class="field">
      <label for="dn">اسم الجهاز أو الطاولة</label>
      <input id="dn" placeholder="مثلاً: كمبيوتر 3 أو بلياردو 1">
    </div>

    <div class="field">
      <label for="dt">نوع الجهاز</label>
      <select id="dt" onchange="fillDeviceRate()">
        <option value="كمبيوتر">كمبيوتر</option>
        <option value="PS5">بلايستيشن 5</option>
        <option value="PS4">بلايستيشن 4</option>
        <option value="PS3">بلايستيشن 3</option>
        <option value="بلياردو">بلياردو</option>
        <option value="فيشة">فيشة</option>
        <option value="آخر">أخرى</option>
      </select>
    </div>

    <div class="field">
      <label for="dr">سعر الساعة</label>
      <input id="dr" type="number" min="0" step="any"
        placeholder="يظهر السعر تلقائياً عند تحديد النوع">
      <small class="muted">يمكنك تعديل السعر لهذا الجهاز وحده.</small>
    </div>

    <button class="primary" onclick="addDevice()">حفظ الجهاز</button>
    <button onclick="closemodal()">إلغاء</button>`);

  fillDeviceRate();
}

function fillDeviceRate() {
  const type = document.getElementById("dt")?.value;
  const rateInput = document.getElementById("dr");
  if (!rateInput) return;

  rateInput.value = rateForType(type) || "";
}

function hourlyRatesForm() {
  const rates = db.hourlyRates;

  modal(`<h3>أسعار ساعات اللعب</h3>
    <p class="muted">حدد سعر الساعة لكل نوع. ستظهر هذه الأسعار تلقائياً عند إضافة جهاز جديد.</p>

    <div class="field">
      <label for="rateComputer">🖥️ سعر ساعة الكمبيوتر</label>
      <input id="rateComputer" type="number" min="0" step="any"
        value="${Number(rates["كمبيوتر"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="ratePlaystation">🎮 سعر ساعة البلايستيشن</label>
      <input id="ratePlaystation" type="number" min="0" step="any"
        value="${Number(rates["بلايستيشن"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="rateFisha">⚽ سعر ساعة الفيشة</label>
      <input id="rateFisha" type="number" min="0" step="any"
        value="${Number(rates["فيشة"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="rateBilliards">🎱 سعر ساعة البلياردو</label>
      <input id="rateBilliards" type="number" min="0" step="any"
        value="${Number(rates["بلياردو"]) || ""}" placeholder="أدخل السعر">
    </div>

    <div class="field">
      <label for="rateOther">🎯 سعر ساعة الأجهزة الأخرى</label>
      <input id="rateOther" type="number" min="0" step="any"
        value="${Number(rates["أخرى"]) || ""}" placeholder="أدخل السعر">
    </div>

    <button class="primary" onclick="saveHourlyRates()">حفظ أسعار الساعات</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveHourlyRates() {
  const fields = [
    ["كمبيوتر", "rateComputer"],
    ["بلايستيشن", "ratePlaystation"],
    ["فيشة", "rateFisha"],
    ["بلياردو", "rateBilliards"],
    ["أخرى", "rateOther"]
  ];

  const newRates = {};

  for (const [key, id] of fields) {
    const input = document.getElementById(id);
    const raw = input.value.trim();
    const value = Number(raw);

    if (raw !== "" && (!Number.isFinite(value) || value < 0)) {
      return notify("تحقق من أسعار الساعات المدخلة.");
    }

    newRates[key] = raw === "" ? 0 : value;
  }

  db.hourlyRates = newRates;

  try {
    save();
    closemodal();
    render();
    notify("تم حفظ أسعار ساعات اللعب");
  } catch (e) {
    notify("تعذّر حفظ الأسعار");
  }
}

// ========================================
// 6. إضافة الأجهزة وتعديلها وحذفها
// ========================================
function addDevice() {
  const n = document.getElementById("dn").value.trim();
  const raw = document.getElementById("dr").value;
  const r = Number(raw);
  const t = document.getElementById("dt").value;

  if (!n || raw === "" || !Number.isFinite(r) || r <= 0) {
    return notify("أدخل اسم الجهاز وسعر ساعة أكبر من صفر");
  }

  db.devices.push({
    id: db.id++,
    name: n,
    type: t,
    rate: r
  });

  save();
  closemodal();
  render();
  notify("تمت إضافة الجهاز بنجاح");
}

function editDevice(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  modal(`<h3>تعديل الجهاز</h3>
    <div class="field">
      <label for="dn">الاسم</label>
      <input id="dn" value="${esc(d.name)}">
    </div>
    <div class="field">
      <label for="dr">سعر الساعة</label>
      <input id="dr" type="number" min="0.01" step="any"
        value="${Number(d.rate) > 0 ? d.rate : ""}">
    </div>
    <button class="primary" onclick="saveDevice(${id})">حفظ التعديل</button>
    <button class="bad" onclick="delDevice(${id})">حذف الجهاز</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveDevice(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  const n = document.getElementById("dn").value.trim();
  const raw = document.getElementById("dr").value;
  const r = Number(raw);

  if (!n || raw === "" || !Number.isFinite(r) || r <= 0) {
    return notify("أدخل اسم الجهاز وسعر ساعة صحيحاً");
  }

  d.name = n;
  d.rate = r;

  save();
  closemodal();
  render();
  notify("تم حفظ التعديل");
}

function delDevice(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  if (d.s && !d.s.end) {
    return notify("لا يمكن حذف جهاز لديه جلسة جارية. أوقف الجلسة أولاً.");
  }

  if (!confirm(`هل تريد حذف «${d.name}»؟ ستبقى الجلسات السابقة في التقارير.`)) {
    return;
  }

  db.devices = db.devices.filter(x => x.id !== id);
  save();
  closemodal();
  render();
  notify("تم حذف الجهاز");
}

// ========================================
// 7. الجلسات والوقت
// ========================================
function startForm(id) {
  const d = db.devices.find(x => x.id === id);

  if (!d || !(Number(d.rate) > 0)) {
    return notify("أدخل سعر الساعة أولاً من تعديل الجهاز أو أسعار الساعات");
  }

  modal(`<h3>بدء جلسة</h3>
    <div class="field">
      <label for="customer">اسم الزبون (اختياري)</label>
      <input id="customer">
    </div>
    <div class="field">
      <label for="minutes">المدة بالدقائق</label>
      <input id="minutes" type="number" min="1"
        placeholder="اتركها فارغة لوقت مفتوح">
    </div>
    <p class="muted">تُحسب أجرة اللعب بحسب سعر الساعة والوقت المستهلك.</p>
    <button class="good" onclick="start(${id})">بدء الوقت</button>
    <button onclick="closemodal()">إلغاء</button>`);
}


function start(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d) return;

  const minutesRaw = document.getElementById("minutes").value;
  const n = Number(minutesRaw);

  if (minutesRaw !== "" && (!Number.isFinite(n) || n <= 0)) {
    return notify("أدخل مدة صحيحة أو اترك الحقل فارغاً");
  }

  if (d.s && !d.s.end) {
    return notify("هذه الجلسة تعمل بالفعل");
  }

  d.s = {
    start: Date.now(),
    pausedAt: null,
    pausedTotal: 0,
    customer: document.getElementById("customer").value.trim(),
    minutes: minutesRaw === "" ? null : n,
    orders: [],
    end: null
  };

  save();
  closemodal();
  render();
  notify("بدأت الجلسة");
}

function pauseSession(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;

  if (!s || s.end || s.pausedAt) return;

  s.pausedAt = Date.now();

  save();
  render();
  notify("تم إيقاف الجلسة مؤقتاً");
}

function resumeSession(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;

  if (!s || s.end || !s.pausedAt) return;

  s.pausedTotal = (s.pausedTotal || 0)
    + (Date.now() - s.pausedAt);

  s.pausedAt = null;

  save();
  render();
  notify("تم استئناف الجلسة");
}

function stop(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;

  if (!s || s.end) return;

  const now = Date.now();

  // إذا كانت الجلسة متوقفة مؤقتاً، نحسب الاستراحة حتى الآن
  if (s.pausedAt) {
    s.pausedTotal = (s.pausedTotal || 0)
      + (now - s.pausedAt);
    s.pausedAt = null;
  }

  s.end = now;

  // حساب وقت اللعب الفعلي بعد استبعاد الاستراحات
  const elapsed = Math.max(
    0,
    s.end - s.start - (s.pausedTotal || 0)
  );

  s.game = Math.ceil(
    elapsed / 3600000 * Number(d.rate)
  );

  s.orderTotal = sum(s);
  s.total = s.game + s.orderTotal;

  db.history.push({
    device: d.name,
    type: d.type,
    category: categoryOf(d),
    customer: s.customer,
    game: s.game,
    orders: s.orderTotal,
    total: s.total,
    start: s.start,
    end: s.end,
    date: localDate(new Date(s.end))
  });

  save();
  render();
  notify("تم إنهاء الجلسة وحفظ الحساب");
}


function finishSession(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d || !d.s || !d.s.end) return;

  d.s = null;
  save();
  render();
  notify("انتهت الجلسة وأصبح الجهاز متاحاً");
}

function showOrders(id) {
  const d = db.devices.find(x => x.id === id);
  const s = d && d.s;
  if (!s) return;

  modal(`<h3>طلبات ${esc(d.name)}</h3>
    <div class="summary">
      ${(s.orders || []).map(o => `
        <div class="sum">
          <span>${esc(o.name)} × ${o.qty}</span>
          <b>${cash(o.price * o.qty)}</b>
        </div>
      `).join("") || "لا توجد طلبات"}
      <hr>
      <div class="sum">
        <b>مجموع الطلبات</b>
        <b class="gold">${cash(s.orderTotal ?? sum(s))}</b>
      </div>
    </div>
    <button onclick="closemodal()">إغلاق</button>`);
}

// ========================================
// 8. إدارة الأصناف
// ========================================
function renderItemsPage(c) {
  c.innerHTML = `<div class="bar">
      <div>
        <h2>إدارة الطلبات والأسعار</h2>
        <p class="muted">أضف الأصناف وأسعارها.</p>
      </div>
      <button class="primary" onclick="itemForm()">＋ إضافة صنف</button>
    </div>

    <div class="items">
      ${db.items.length
        ? db.items.map(p => `
          <div class="card item">
            <div>
              <b>${esc(p.name)}</b>
              <p class="muted">${priceText(p.price)}</p>
            </div>
            <div>
              <button onclick="itemForm(${p.id})">تعديل</button>
              <button class="bad" onclick="delItem(${p.id})">حذف</button>
            </div>
          </div>
        `).join("")
        : `<p class="muted">لا توجد أصناف. اضغط «إضافة صنف» لإضافة أول طلب.</p>`
      }
    </div>`;
}

function itemForm(id) {
  const p = id
    ? db.items.find(x => x.id === id)
    : { name: "", price: "" };

  if (!p) return;

  modal(`<h3>${id ? "تعديل صنف" : "إضافة صنف"}</h3>
    <div class="field">
      <label for="iname">اسم الطلب</label>
      <input id="iname" value="${esc(p.name)}" placeholder="مثلاً: عصير">
    </div>
    <div class="field">
      <label for="iprice">سعر القطعة</label>
      <input id="iprice" type="number" min="0.01" step="any"
        value="${Number(p.price) > 0 ? p.price : ""}" placeholder="أدخل السعر">
    </div>
    <button class="primary" onclick="saveItem(${id || 0})">حفظ الصنف</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveItem(id) {
  const n = document.getElementById("iname").value.trim();
  const raw = document.getElementById("iprice").value;
  const p = Number(raw);

  if (!n || raw === "" || !Number.isFinite(p) || p <= 0) {
    return notify("أدخل اسم الصنف وسعره");
  }

  if (id) {
    const x = db.items.find(x => x.id === id);
    if (!x) return;
    x.name = n;
    x.price = p;
  } else {
    db.items.push({ id: db.id++, name: n, price: p });
  }

  save();
  closemodal();
  render();
  notify("تم حفظ الصنف والسعر");
}

function delItem(id) {
  if (!confirm("هل تريد حذف هذا الصنف؟")) return;

  db.items = db.items.filter(x => x.id !== id);
  save();
  render();
  notify("تم حذف الصنف");
}

// ========================================
// 9. طلبات الجلسات
// ========================================
function orders(id) {
  const d = db.devices.find(x => x.id === id);
  if (!d || !d.s || d.s.end) {
    return notify("ابدأ جلسة مفتوحة لإضافة الطلبات");
  }

  target = id;

  modal(`<h3>طلبات ${esc(d.name)}</h3>
    <div id="rows">${d.s.orders.map(orderRow).join("")}</div>
    <button onclick="addRow()">＋ إضافة صنف</button>
    <div class="summary">
      مجموع الطلبات: <b id="grand">${cash(sum(d.s))}</b>
    </div>
    <button class="primary" onclick="saveOrders()">حفظ الطلبات</button>
    <button onclick="closemodal()">إلغاء</button>`);

  if (!d.s.orders.length) addRow();
}

function orderRow(o = {}) {
  return `<div class="orderrow">
    <select onchange="calc()">
      <option value="">اختر الطلب</option>
      ${db.items.map(p => `
        <option value="${p.id}" ${o.id === p.id ? "selected" : ""}>
          ${esc(p.name)} · ${priceText(p.price)}
        </option>
      `).join("")}
    </select>
    <input type="number" min="1" value="${o.qty || 1}" onchange="calc()">
    <span>${cash((o.price || 0) * (o.qty || 1))}</span>
    <button class="bad" onclick="this.parentElement.remove();calc()">×</button>
  </div>`;
}

function addRow() {
  document.getElementById("rows")
    .insertAdjacentHTML("beforeend", orderRow());
  calc();
}

function calc() {
  let total = 0;

  document.querySelectorAll(".orderrow").forEach(row => {
    const p = db.items.find(
      x => x.id === Number(row.querySelector("select").value)
    );

    const q = Math.max(
      1,
      Number(row.querySelector("input").value) || 1
    );

    const amount = p ? Number(p.price) * q : 0;
    total += amount;
    row.querySelector("span").textContent = cash(amount);
  });

  const grand = document.getElementById("grand");
  if (grand) grand.textContent = cash(total);
}

function saveOrders() {
  const d = db.devices.find(x => x.id === target);
  if (!d || !d.s || d.s.end) return;

  const chosen = [...document.querySelectorAll(".orderrow")]
    .map(row => ({
      p: db.items.find(
        x => x.id === Number(row.querySelector("select").value)
      ),
      q: Math.max(1, Number(row.querySelector("input").value) || 1)
    }))
    .filter(x => x.p);

  if (chosen.some(x => !(Number(x.p.price) > 0))) {
    return notify("أدخل سعر كل صنف من صفحة الطلبات أولاً");
  }

  d.s.orders = chosen.map(x => ({
    id: x.p.id,
    name: x.p.name,
    price: Number(x.p.price),
    qty: x.q
  }));

  save();
  closemodal();
  render();
  notify("تم حفظ الطلبات");
}

// ========================================
// 10. صفحة المصروفات المستقلة
// ========================================
function expenseMatches(e) {
  const date = String(e.date || "");
  return reportMode === "daily"
    ? date === reportDate
    : date.startsWith(reportMonth);
}

function renderExpensesPage(c) {
  const list = db.expenses.slice().sort(
    (a, b) => String(b.date).localeCompare(String(a.date))
  );

  const total = list.reduce(
    (a, e) => a + (Number(e.amount) || 0), 0
  );

  c.innerHTML = `<div class="bar">
      <div>
        <h2>المصروفات</h2>
        <p class="muted">إدارة مصروفات الصالة وتحديثها.</p>
      </div>
      <button class="primary" onclick="expenseForm()">＋ إضافة مصروف</button>
    </div>

    <div class="stats">
      <div class="stat">
        <small>عدد المصروفات</small>
        <strong>${list.length}</strong>
      </div>
      <div class="stat">
        <small>إجمالي المصروفات</small>
        <strong>${cash(total)}</strong>
      </div>
    </div>

    <div class="card table">
      ${list.length ? `
        <table>
          <thead>
            <tr>
              <th>التاريخ</th>
              <th>البيان</th>
              <th>المبلغ</th>
              <th>الإجراء</th>
            </tr>
          </thead>
          <tbody>
            ${list.map(e => `
              <tr>
                <td>${esc(e.date)}</td>
                <td>${esc(e.note)}</td>
                <td>${cash(e.amount)}</td>
                <td>
                  <button onclick="expenseForm(${e.id})">تعديل</button>
                  <button class="bad" onclick="deleteExpense(${e.id})">حذف</button>
                </td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      ` : `<p class="muted">لا توجد مصروفات مسجلة حتى الآن.</p>`}
    </div>`;
}

function expenseForm(id) {
  const e = id
    ? db.expenses.find(x => x.id === id)
    : { date: localDate(), note: "", amount: "" };

  if (!e) return;

  modal(`<h3>${id ? "تعديل مصروف" : "إضافة مصروف"}</h3>
    <div class="field">
      <label for="expenseDate">تاريخ المصروف</label>
      <input id="expenseDate" type="date" value="${esc(e.date || localDate())}">
    </div>
    <div class="field">
      <label for="expenseNote">بيان المصروف</label>
      <input id="expenseNote" maxlength="120"
        value="${esc(e.note)}" placeholder="مثلاً: كهرباء أو صيانة">
    </div>
    <div class="field">
      <label for="expenseAmount">المبلغ</label>
      <input id="expenseAmount" type="number" min="0.01" step="any"
        value="${Number(e.amount) > 0 ? e.amount : ""}" placeholder="أدخل المبلغ">
    </div>
    <button class="primary" onclick="saveExpense(${id || 0})">حفظ المصروف</button>
    <button onclick="closemodal()">إلغاء</button>`);
}

function saveExpense(id = 0) {
  const date = document.getElementById("expenseDate").value;
  const note = document.getElementById("expenseNote").value.trim();
  const raw = document.getElementById("expenseAmount").value;
  const amount = Number(raw);

  if (!/^\d{4}-\d{2}-\d{2}$/.test(date) ||
      !note || raw === "" ||
      !Number.isFinite(amount) || amount <= 0) {
    return notify("أدخل التاريخ والبيان ومبلغاً أكبر من صفر");
  }

  if (id) {
    const e = db.expenses.find(x => x.id === id);
    if (!e) return;

    e.date = date;
    e.note = note;
    e.amount = amount;
  } else {
    db.expenses.push({
      id: db.id++,
      date,
      note,
      amount,
      createdAt: Date.now()
    });
  }

  try {
    save();
    closemodal();
    render();
    notify(id ? "تم تعديل المصروف" : "تم حفظ المصروف");
  } catch (e) {
    notify("تعذّر حفظ المصروف");
  }
}

function deleteExpense(id) {
  if (!confirm("هل تريد حذف هذا المصروف؟")) return;

  db.expenses = db.expenses.filter(e => e.id !== id);
  save();
  render();
  notify("تم حذف المصروف");
}

// ========================================
// 11. التقارير اليومية والشهرية
// ========================================
function reportCategory(h) {
  if (h.category) return h.category;

  const t = h.type || "";
  const device = String(h.device || "");

  if (t === "كمبيوتر" || device.includes("كمبيوتر")) return "كمبيوتر";

  if (["PS5", "PS4", "PS3", "بلايستيشن"].includes(t) ||
      device.includes("بلايستيشن")) return "بلايستيشن";

  if (t === "فيشة" || device.includes("فيشة")) return "فيشة";
  if (t === "بلياردو" || device.includes("بلياردو")) return "بلياردو";

  return "أخرى";
}

function reportHistoryDate(h) {
  if (h.date && /^\d{4}-\d{2}-\d{2}$/.test(h.date)) {
    return h.date;
  }

  const raw = Number(h.end) || Date.parse(h.end || "");
  return Number.isFinite(raw) && raw > 0
    ? localDate(new Date(raw))
    : "";
}

function reportMatches(h) {
  const date = reportHistoryDate(h);
  return reportMode === "daily"
    ? date === reportDate
    : date.startsWith(reportMonth);
}

function changeReportDate(value) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) reportDate = value;
  render();
}

function changeReportMonth(value) {
  if (/^\d{4}-\d{2}$/.test(value)) reportMonth = value;
  render();
}

function setReportMode(mode) {
  reportMode = mode;
  render();
}

function shiftReport(step) {
  if (reportMode === "daily") {
    const d = new Date(reportDate + "T12:00:00");
    d.setDate(d.getDate() + step);
    reportDate = localDate(d);
  } else {
    const d = new Date(reportMonth + "-01T12:00:00");
    d.setMonth(d.getMonth() + step);
    reportMonth = localMonth(d);
  }

  render();
}

function reportToday() {
  if (reportMode === "daily") {
    reportDate = localDate();
  } else {
    reportMonth = localMonth();
  }

  render();
}


function renderReports(c) {
  const histories = db.history.filter(reportMatches);
  const expenses = db.expenses.filter(expenseMatches);

  const categories = [
    ["كمبيوتر", "🖥️"],
    ["بلايستيشن", "🎮"],
    ["فيشة", "⚽"],
    ["بلياردو", "🎱"]
  ];

  const gameTotal = histories.reduce(
    (a, h) => a + (Number(h.game) || 0), 0
  );

  const ordersTotal = histories.reduce(
    (a, h) => a + (Number(h.orders) || 0), 0
  );

  const gross = histories.reduce(
    (a, h) => a + (
      Number(h.total) ||
      ((Number(h.game) || 0) + (Number(h.orders) || 0))
    ), 0
  );

  const expenseTotal = expenses.reduce(
    (a, e) => a + (Number(e.amount) || 0), 0
  );

  const net = gross - expenseTotal;

  const period = reportMode === "daily"
    ? reportDate
    : reportMonth;

  const categoryCards = categories.map(([key, icon]) => {
    const arr = histories.filter(
      h => reportCategory(h) === key
    );

    const amount = arr.reduce(
      (a, h) => a + (
        Number(h.total) ||
        ((Number(h.game) || 0) + (Number(h.orders) || 0))
      ), 0
    );

    return `
      <div class="report-stat card">
        <div class="report-stat-title">
          <span>${icon} ${key}</span>
          <span class="report-count">${arr.length}</span>
        </div>
        <small class="muted">عدد الجلسات</small>
        <strong>${arr.length}</strong>
        <div class="report-card-divider"></div>
        <small class="muted">إجمالي المبالغ</small>
        <strong class="report-amount">${cash(amount)}</strong>
      </div>
    `;
  }).join("");

  c.innerHTML = `
    <section class="reports-page">

      <div class="reports-heading">
        <div>
          <h2>📊 التقارير المالية</h2>
          <p class="muted">
            نظرة شاملة على الإيرادات والمصروفات وصافي الأرباح.
          </p>
        </div>
        <span class="report-period">
          ${reportMode === "daily" ? "تقرير يومي" : "تقرير شهري"}
        </span>
      </div>

      <div class="report-controls card">
        <div class="report-tabs">
          <button
            class="${reportMode === "daily" ? "primary" : ""}"
            onclick="setReportMode('daily')">
            📅 التقرير اليومي
          </button>

          <button
            class="${reportMode === "monthly" ? "primary" : ""}"
            onclick="setReportMode('monthly')">
            🗓️ التقرير الشهري
          </button>
        </div>

        <div class="report-date-navigation">
          <button onclick="shiftReport(-1)">→ السابق</button>
          <button onclick="reportToday()">اليوم / الشهر الحالي</button>
          <button onclick="shiftReport(1)">التالي ←</button>
        </div>

        <div class="field">
          <label for="${reportMode === "daily" ? "reportDate" : "reportMonth"}">
            ${reportMode === "daily" ? "تاريخ التقرير" : "شهر التقرير"}
          </label>

          ${
            reportMode === "daily"
              ? `<input id="reportDate" type="date"
                   value="${esc(reportDate)}"
                   onchange="changeReportDate(this.value)">`
              : `<input id="reportMonth" type="month"
                   value="${esc(reportMonth)}"
                   onchange="changeReportMonth(this.value)">`
          }
        </div>
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>ملخص الأقسام</h3>
          <p class="muted">أداء كل نوع من الأجهزة والطاولات.</p>
        </div>
      </div>

      <div class="report-grid">
        ${categoryCards}

        <div class="report-stat card">
          <div class="report-stat-title">
            <span>🛒 الطلبات</span>
          </div>
          <small class="muted">إجمالي مبالغ الطلبات</small>
          <strong class="report-amount">${cash(ordersTotal)}</strong>
          <div class="report-card-divider"></div>
          <small class="muted">هذه المبالغ محسوبة ضمن الإيرادات.</small>
        </div>

        <div class="report-stat card">
          <div class="report-stat-title">
            <span>💸 المصروفات</span>
            <span class="report-count">${expenses.length}</span>
          </div>
          <small class="muted">عدد المصروفات</small>
          <strong>${expenses.length}</strong>
          <div class="report-card-divider"></div>
          <small class="muted">إجمالي المصروفات</small>
          <strong class="report-amount">${cash(expenseTotal)}</strong>
        </div>
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>💰 الملخص المالي</h3>
          <p class="muted">نتيجة الفترة المحددة: ${esc(period)}</p>
        </div>
      </div>

      <div class="report-grid report-totals">
        <div class="card report-total-card">
          <span class="report-total-icon">🎮</span>
          <small class="muted">أجرة اللعب</small>
          <strong>${cash(gameTotal)}</strong>
        </div>

        <div class="card report-total-card">
          <span class="report-total-icon">📈</span>
          <small class="muted">إجمالي الإيرادات</small>
          <strong>${cash(gross)}</strong>
        </div>

        <div class="card report-total-card expense-card">
          <span class="report-total-icon">💸</span>
          <small class="muted">إجمالي المصروفات</small>
          <strong>${cash(expenseTotal)}</strong>
        </div>

        <div class="card report-total-card net-card">
          <span class="report-total-icon">✨</span>
          <small class="muted">الصافي بعد المصروفات</small>
          <strong>${cash(net)}</strong>
        </div>
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>🎮 تفاصيل الجلسات</h3>
          <p class="muted">عدد الجلسات المغلقة: ${histories.length}</p>
        </div>
      </div>

      <div class="card table report-table-card">
        ${
          histories.length
            ? `<div class="report-table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>التاريخ</th>
                      <th>القسم</th>
                      <th>الجهاز</th>
                      <th>الزبون</th>
                      <th>أجرة اللعب</th>
                      <th>الطلبات</th>
                      <th>الإجمالي</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${histories.slice().sort(
                      (a, b) => (Number(b.end) || 0) - (Number(a.end) || 0)
                    ).map(h => `
                      <tr>
                        <td>${esc(reportHistoryDate(h) || "—")}</td>
                        <td>${esc(reportCategory(h))}</td>
                        <td>${esc(h.device || "—")}</td>
                        <td>${esc(h.customer || "—")}</td>
                        <td>${cash(h.game)}</td>
                        <td>${cash(h.orders)}</td>
                        <td><strong>${cash(
                          h.total ?? (
                            (Number(h.game) || 0) +
                            (Number(h.orders) || 0)
                          )
                        )}</strong></td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>`
            : `<p class="muted report-empty">
                لا توجد جلسات مغلقة في هذه الفترة.
              </p>`
        }
      </div>

      <div class="reports-section-heading">
        <div>
          <h3>🧾 تفاصيل المصروفات</h3>
          <p class="muted">
            ${expenses.length} مصروف مسجل في الفترة المحددة.
          </p>
        </div>
      </div>

      <div class="card table report-table-card">
        ${
          expenses.length
            ? `<div class="report-table-scroll">
                <table>
                  <thead>
                    <tr>
                      <th>التاريخ</th>
                      <th>بيان المصروف</th>
                      <th>المبلغ</th>
                      <th>الإجراء</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${expenses.slice().sort(
                      (a, b) => String(b.date).localeCompare(String(a.date))
                    ).map(e => `
                      <tr>
                        <td>${esc(e.date)}</td>
                        <td>${esc(e.note)}</td>
                        <td><strong>${cash(e.amount)}</strong></td>
                        <td>
                          <div class="report-row-actions">
                            <button onclick="expenseForm(${e.id})">تعديل</button>
                            <button class="bad"
                              onclick="deleteExpense(${e.id})">حذف</button>
                          </div>
                        </td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              </div>`
            : `<p class="muted report-empty">
                لا توجد مصروفات في هذه الفترة.
              </p>`
        }
      </div>

    </section>
  `;
}


// ========================================
// 12. الإعدادات والتنسيقات
// ========================================


function passwordSettingsHTML() {
  const enabled = !!securityRead();

  return `
    <section class="card" style="margin-top:20px">
      <h3>🔐 الأمان وكلمة المرور</h3>

      <p>
        حالة الحماية:
        <strong style="color:${enabled ? '#22c55e' : '#f59e0b'}">
          ${enabled ? 'مفعّلة' : 'غير مفعّلة'}
        </strong>
      </p>

      ${
        enabled
          ? `
            <button class="bad" type="button"
              onclick="disablePasswordForm()">
              🔓 إلغاء كلمة المرور
            </button>

            <hr>

            <h4>تغيير كلمة المرور</h4>
            <form id="changePasswordForm">
              <label for="oldAppPassword">كلمة المرور الحالية</label>
              <input id="oldAppPassword" type="password" required>

              <label for="newAppPassword">كلمة المرور الجديدة</label>
              <input id="newAppPassword" type="password"
                minlength="4" required>

              <label for="confirmAppPassword">تأكيد كلمة المرور الجديدة</label>
              <input id="confirmAppPassword" type="password"
                minlength="4" required>

              <p id="passwordChangeMessage"></p>

              <button class="primary" type="submit">
                حفظ كلمة المرور الجديدة
              </button>
            </form>
          `
          : `
            <p class="muted">
              الحماية غير مفعّلة. يمكنك إعداد كلمة مرور لحماية البرنامج.
            </p>
            <button class="primary" type="button"
              onclick="enablePasswordSetup()">
              🔒 إضافة كلمة مرور
            </button>
          `
      }
    </section>
  `;
}

function renderSettings(c) {
  const st = db.settings;

  c.innerHTML = `<h2>الإعدادات</h2>

    <div class="card settings-card">
      <div class="field">
        <label for="currency">اسم العملة</label>
        <input id="currency" value="${esc(db.currency)}" maxlength="12">
      </div>

      <div class="settings-grid">
        <div class="field">
          <label for="textColor">لون الخط</label>
          <input id="textColor" type="color" value="${esc(st.textColor)}">
        </div>

        <div class="field">
          <label for="accentColor">اللون الرئيسي والأزرار</label>
          <input id="accentColor" type="color" value="${esc(st.accentColor)}">
        </div>

        <div class="field">
          <label for="backgroundColor">خلفية الصفحة</label>
          <input id="backgroundColor" type="color" value="${esc(st.backgroundColor)}">
        </div>

        <div class="field">
          <label for="fontSize">حجم الخط</label>
          <select id="fontSize">
            <option value="13" ${Number(st.fontSize) === 13 ? "selected" : ""}>صغير</option>
            <option value="15" ${Number(st.fontSize) === 15 ? "selected" : ""}>متوسط</option>
            <option value="17" ${Number(st.fontSize) === 17 ? "selected" : ""}>كبير</option>
            <option value="19" ${Number(st.fontSize) === 19 ? "selected" : ""}>كبير جداً</option>
          </select>
        </div>
      </div>

      <div class="actions">
        <button class="primary" onclick="saveSettings()">حفظ الإعدادات</button>
        <button onclick="resetStyleSettings()">إرجاع التنسيق الافتراضي</button>
      </div>

      <hr>

      <div class="bar">
        <div>
          <b>أسعار ساعات اللعب</b>
          <p class="muted">تحديد السعر الافتراضي لكل نوع جهاز.</p>
        </div>
        <button class="primary" onclick="hourlyRatesForm()">⚙️ أسعار الساعات</button>
      </div>

      <div class="actions">
        <button onclick="backup()">حفظ نسخة احتياطية</button>
        <button onclick="document.getElementById('file').click()">استعادة نسخة</button>
      </div>

      <p class="notice">
        البيانات محفوظة على هذا الجهاز. احتفظ بنسخة احتياطية بشكل دوري.
      </p>

      <hr>
      <button class="bad" onclick="resetDemo()">إعادة ضبط بيانات العرض</button>
      <p class="muted">هذا الزر يحذف بيانات البرنامج بعد تأكيدك.</p>
      <hr>
      ${passwordSettingsHTML()}
    </div>`;
}

function applySettings() {
  const s = db.settings || {};

  // أسماء المتغيرات متوافقة مع style.css.
  document.documentElement.style.setProperty(
    "--text", s.textColor || "#edf4ff"
  );

  document.documentElement.style.setProperty(
    "--accent", s.accentColor || "#52d8e7"
  );

  document.documentElement.style.setProperty(
    "--bg", s.backgroundColor || "#0b1222"
  );

  document.documentElement.style.setProperty(
    "--font-size", (Number(s.fontSize) || 15) + "px"
  );
}

function saveCurrency() {
  saveSettings();
}

function saveSettings() {
  const currencyEl = document.getElementById("currency");
  if (!currencyEl) return;

  const currency = currencyEl.value.trim();

  if (!currency) return notify("أدخل اسم العملة");

  const textColor = document.getElementById("textColor").value;
  const accentColor = document.getElementById("accentColor").value;
  const backgroundColor = document.getElementById("backgroundColor").value;
  const fontSize = Number(document.getElementById("fontSize").value);

  if (![textColor, accentColor, backgroundColor].every(
    color => /^#[0-9a-f]{6}$/i.test(color)
  ) || ![13, 15, 17, 19].includes(fontSize)) {
    return notify("تحقق من إعدادات التنسيق");
  }

  db.currency = currency;
  db.settings = { textColor, accentColor, backgroundColor, fontSize };

  try {
    save();
    applySettings();
    render();
    notify("تم حفظ الإعدادات");
  } catch (e) {
    notify("تعذّر حفظ الإعدادات");
  }
}

function resetStyleSettings() {
  if (!confirm("إرجاع ألوان وحجم الخط إلى الوضع الافتراضي؟")) return;

  db.settings = { ...seed.settings };
  save();
  applySettings();
  render();
  notify("تم إرجاع التنسيق الافتراضي");
}

function resetDemo() {
  if (!confirm("سيتم حذف الأجهزة والطلبات والجلسات والمصروفات وأسعار الساعات. هل تريد المتابعة؟")) {
    return;
  }

  db = JSON.parse(JSON.stringify(seed));
  save();
  applySettings();
  render();
  notify("تمت إعادة بيانات البداية");
}

// ========================================
// 13. النسخ الاحتياطي والاستعادة
// ========================================
function backup() {
  try {
    const blob = new Blob(
      [JSON.stringify(db, null, 2)],
      { type: "application/json" }
    );

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = "game-lounge-backup.json";
    a.click();

    setTimeout(() => URL.revokeObjectURL(url), 1000);
    notify("تم تجهيز النسخة الاحتياطية");
  } catch (e) {
    notify("تعذّر إنشاء النسخة الاحتياطية");
  }
}

function restore(e) {
  const file = e.target.files && e.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = () => {
    try {
      const x = JSON.parse(reader.result);

      if (!x || !Array.isArray(x.devices) ||
          !Array.isArray(x.items) || !Array.isArray(x.history)) {
        throw new Error("invalid backup");
      }

      if (!confirm("استعادة النسخة ستستبدل بيانات البرنامج الحالية. هل تريد المتابعة؟")) {
        e.target.value = "";
        return;
      }

      x.expenses = Array.isArray(x.expenses) ? x.expenses : [];
      x.hourlyRates = Object.assign({}, seed.hourlyRates, x.hourlyRates || {});
      x.settings = Object.assign({}, seed.settings, x.settings || {});
      x.id = Number(x.id) || 10;

      db = x;
      save();
      applySettings();
      render();
      notify("تمت استعادة النسخة الاحتياطية");
    } catch (err) {
      notify("الملف غير صالح أو غير متوافق");
    }

    e.target.value = "";
  };

  reader.readAsText(file);
}

// ========================================
// 14. تشغيل البرنامج وتحديث الوقت
// ========================================

/* ===== حماية Game Lounge ===== */
const SECURITY_KEY = "game-lounge-security-v1";

function securityRead() {
  try {
    return JSON.parse(localStorage.getItem(SECURITY_KEY) || "null");
  } catch {
    return null;
  }
}

async function securityHash(value, salt) {
  const data = new TextEncoder().encode(salt + ":" + value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest))
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

function securitySalt() {
  const bytes = crypto.getRandomValues(new Uint8Array(16));
  return Array.from(bytes)
    .map(b => b.toString(16).padStart(2, "0"))
    .join("");
}

function showLockMessage(message) {
  const el = document.getElementById("lockMessage");
  if (el) el.textContent = message;
}

function lockApp() {
  document.getElementById("lockScreen").style.display = "flex";
  document.querySelector(".app").style.visibility = "hidden";
}

function unlockApp() {
  document.getElementById("lockScreen").style.display = "none";
  document.querySelector(".app").style.visibility = "visible";
  applySettings();
  render();
}

function showFirstSetup() {
  const card = document.querySelector(".lock-card");
  card.innerHTML = `
    <div class="lock-logo">G</div>
    <h2>إعداد حماية البرنامج</h2>
    <p>أنشئ كلمة مرور وسؤال أمان للاستعادة</p>
    <form id="setupSecurityForm">
      <label>كلمة المرور الجديدة</label>
      <input id="newSecurityPassword" type="password"
        minlength="4" autocomplete="new-password" required>
      <label>تأكيد كلمة المرور</label>
      <input id="confirmSecurityPassword" type="password"
        minlength="4" autocomplete="new-password" required>
      <label>سؤال الأمان</label>
      <input id="securityQuestion" type="text"
        placeholder="مثلاً: ما اسم مدرستي؟" required>
      <label>جواب الأمان</label>
      <input id="securityAnswer" type="password" required>
      <p id="lockMessage" class="lock-message"></p>
      <button class="primary lock-button" type="submit">حفظ الحماية</button>
    </form>
  `;

  document.getElementById("setupSecurityForm").addEventListener("submit", async e => {
    e.preventDefault();

    const password = document.getElementById("newSecurityPassword").value;
    const confirm = document.getElementById("confirmSecurityPassword").value;
    const question = document.getElementById("securityQuestion").value.trim();
    const answer = document.getElementById("securityAnswer").value.trim();

    if (password !== confirm) {
      showLockMessage("كلمتا المرور غير متطابقتين.");
      return;
    }

    if (password.length < 4 || !question || !answer) {
      showLockMessage("أكمل جميع الحقول، واجعل كلمة المرور 4 أحرف أو أرقام على الأقل.");
      return;
    }

    try {
      const salt = securitySalt();
      const answerSalt = securitySalt();

      localStorage.setItem(SECURITY_KEY, JSON.stringify({
        salt,
        passwordHash: await securityHash(password, salt),
        question,
        answerSalt,
        answerHash: await securityHash(answer.toLowerCase(), answerSalt)
      }));

      unlockApp();
    } catch {
      showLockMessage("تعذر إعداد الحماية على هذا المتصفح.");
    }
  });
}

function showUnlockForm() {
  const card = document.querySelector(".lock-card");
  card.innerHTML = `
    <div class="lock-logo">G</div>
    <h2>Game Lounge</h2>
    <p>أدخل كلمة المرور لفتح البرنامج</p>
    <form id="unlockForm">
      <label>كلمة المرور</label>
      <input id="unlockPassword" type="password"
        autocomplete="current-password" required>
      <p id="lockMessage" class="lock-message"></p>
      <button class="primary lock-button" type="submit">فتح البرنامج</button>
      <button type="button" id="forgotPassword" class="lock-forgot">
        نسيت كلمة المرور؟
      </button>
    </form>
  `;

  document.getElementById("unlockForm").addEventListener("submit", async e => {
    e.preventDefault();
    const security = securityRead();
    if (!security) {
      showFirstSetup();
      return;
    }

    try {
      const password = document.getElementById("unlockPassword").value;
      const hash = await securityHash(password, security.salt);

      if (hash !== security.passwordHash) {
        showLockMessage("كلمة المرور غير صحيحة.");
        return;
      }

      unlockApp();
    } catch {
      showLockMessage("تعذر التحقق من كلمة المرور.");
    }
  });

  document.getElementById("forgotPassword").addEventListener("click", showRecoveryForm);
}

function showRecoveryForm() {
  const security = securityRead();
  if (!security) {
    showFirstSetup();
    return;
  }

  const card = document.querySelector(".lock-card");
  card.innerHTML = `
    <div class="lock-logo">G</div>
    <h2>استعادة كلمة المرور</h2>
    <p>${security.question.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</p>
    <form id="recoveryForm">
      <label>جواب الأمان</label>
      <input id="recoveryAnswer" type="password" required>
      <label>كلمة المرور الجديدة</label>
      <input id="recoveryNewPassword" type="password" minlength="4" required>
      <p id="lockMessage" class="lock-message"></p>
      <button class="primary lock-button" type="submit">إعادة تعيين كلمة المرور</button>
      <button type="button" id="backToUnlock" class="lock-forgot">رجوع</button>
    </form>
  `;

  document.getElementById("backToUnlock").addEventListener("click", showUnlockForm);

  document.getElementById("recoveryForm").addEventListener("submit", async e => {
    e.preventDefault();

    try {
      const answer = document.getElementById("recoveryAnswer").value.trim().toLowerCase();
      const newPassword = document.getElementById("recoveryNewPassword").value;

      if (newPassword.length < 4) {
        showLockMessage("كلمة المرور يجب أن تكون 4 أحرف أو أرقام على الأقل.");
        return;
      }

      const answerHash = await securityHash(answer, security.answerSalt);
      if (answerHash !== security.answerHash) {
        showLockMessage("جواب الأمان غير صحيح.");
        return;
      }

      const salt = securitySalt();
      security.salt = salt;
      security.passwordHash = await securityHash(newPassword, salt);
      localStorage.setItem(SECURITY_KEY, JSON.stringify(security));
      showUnlockForm();
      showLockMessage("تم تغيير كلمة المرور. أدخلها الآن.");
    } catch {
      showLockMessage("تعذرت استعادة كلمة المرور.");
    }
  });
}

/* ===== تشغيل البرنامج والمؤقتات ===== */
if (securityRead()) {
  lockApp();

  if (window.crypto && crypto.subtle) {
    showUnlockForm();
  } else {
    showLockMessage("الحماية غير مدعومة في بيئة التشغيل الحالية.");
  }
} else {
  // إذا لم تكن كلمة المرور مفعّلة، افتح البرنامج مباشرةً
  document.getElementById("lockScreen").style.display = "none";
  document.querySelector(".app").style.visibility = "visible";
  applySettings();
  render();
}


setInterval(() => {
  db.devices.forEach(d => {
    const s = d.s;
    if (!s || s.end) return;

    const now = Date.now();
    const timer = document.getElementById("timer" + d.id);

    // حساب وقت اللعب الفعلي دون الاستراحات
    const elapsed = Math.max(
      0,
      (s.pausedAt || now) - s.start - (s.pausedTotal || 0)
    );

    if (timer) {
      timer.textContent = time(elapsed);
    }

    // لا تنه الجلسة تلقائياً أثناء الاستراحة
    if (
      !s.pausedAt &&
      s.minutes &&
      elapsed >= s.minutes * 60000
    ) {
      playTimeUpSound(d.id);
      stop(d.id);
    }
  });
}, 500);

// صوت تنبيه عند انتهاء الوقت المحدد: نغمة قصيرة تتكرر حتى يضغط المستخدم إيقاف
const gameLoungeActiveAlarms = new Map();
function playTimeUpSound(deviceId) {
  if (gameLoungeActiveAlarms.has(deviceId)) return;

  // واجهة واضحة لإيقاف التنبيه
  let panel = document.getElementById("gameLoungeAlarmPanel");
  if (!panel) {
    panel = document.createElement("div");
    panel.id = "gameLoungeAlarmPanel";
    panel.setAttribute("role", "alertdialog");
    panel.style.cssText = "position:fixed;z-index:99999;left:16px;right:16px;bottom:20px;padding:18px;border-radius:16px;background:#171b2e;color:#fff;border:2px solid #8b5cf6;box-shadow:0 8px 30px #0009;text-align:center;font-family:inherit";
    document.body.appendChild(panel);
  }
  const device = db.devices.find(x => x.id === deviceId);
  panel.innerHTML = `<div style="font-size:18px;font-weight:700;margin-bottom:8px">🔔 انتهى الوقت المحدد${device ? ` — ${String(device.name).replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]))}` : ""}</div><div style="margin-bottom:12px">يرجى إيقاف التنبيه بعد الانتباه إليه.</div><button id="gameLoungeStopAlarm" style="padding:10px 22px;border:0;border-radius:10px;background:#8b5cf6;color:white;font-weight:700">إيقاف التنبيه</button>`;
  document.getElementById("gameLoungeStopAlarm").onclick = () => stopTimeUpAlarm(deviceId);

  const alarm = { timer: null, ctx: null };
  gameLoungeActiveAlarms.set(deviceId, alarm);
  const ring = () => {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      if (!alarm.ctx || alarm.ctx.state === "closed") alarm.ctx = new AudioCtx();
      if (alarm.ctx.state === "suspended") alarm.ctx.resume().catch(() => {});
      const ctx = alarm.ctx;
      // نغمة أوضح وأعلى: موجة مربعة مع مستوى صوت أعلى داخل حدود المتصفح
      [1046, 784, 1046].forEach((frequency, index) => {
        const oscillator = ctx.createOscillator();
        const gain = ctx.createGain();
        const at = ctx.currentTime + index * 0.24;
        oscillator.type = "square";
        oscillator.frequency.value = frequency;
        gain.gain.setValueAtTime(0.0001, at);
        gain.gain.exponentialRampToValueAtTime(0.72, at + 0.018);
        gain.gain.setValueAtTime(0.72, at + 0.14);
        gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.21);
        oscillator.connect(gain); gain.connect(ctx.destination);
        oscillator.start(at); oscillator.stop(at + 0.22);
      });
    } catch (error) { console.warn("تعذر تشغيل صوت انتهاء الوقت", error); }
  };
  ring();
  alarm.timer = setInterval(ring, 2500);
}

function stopTimeUpAlarm(deviceId) {
  const alarm = gameLoungeActiveAlarms.get(deviceId);
  if (alarm) {
    clearInterval(alarm.timer);
    if (alarm.ctx && alarm.ctx.state !== "closed") alarm.ctx.close().catch(() => {});
    gameLoungeActiveAlarms.delete(deviceId);
  }
  // إذا ما عاد في تنبيهات، أخفِ لوحة التنبيه
  if (gameLoungeActiveAlarms.size === 0) {
    const panel = document.getElementById("gameLoungeAlarmPanel");
    if (panel) panel.remove();
  } else {
    const panel = document.getElementById("gameLoungeAlarmPanel");
    if (panel) panel.querySelector("div").textContent = "🔔 انتهى الوقت المحدد";
  }
}

// تغيير كلمة المرور من صفحة الإعدادات
document.addEventListener("submit", async function (event) {
  if (!event.target || event.target.id !== "changePasswordForm") return;

  event.preventDefault();

  const message = document.getElementById("passwordChangeMessage");
  const saved = securityRead();

  if (!saved) {
    if (message) message.textContent = "الحماية غير مفعّلة.";
    return;
  }

  const oldPassword = document.getElementById("oldAppPassword").value;
  const newPassword = document.getElementById("newAppPassword").value;
  const confirmPassword = document.getElementById("confirmAppPassword").value;

  if (newPassword.length < 4) {
    if (message) message.textContent = "كلمة المرور الجديدة يجب أن تكون 4 أحرف أو أرقام على الأقل.";
    return;
  }

  if (newPassword !== confirmPassword) {
    if (message) message.textContent = "كلمتا المرور الجديدتان غير متطابقتين.";
    return;
  }

  try {
    const oldHash = await securityHash(oldPassword, saved.salt);

    if (oldHash !== saved.passwordHash) {
      if (message) message.textContent = "كلمة المرور الحالية غير صحيحة.";
      return;
    }

    const newSalt = securitySalt();
    saved.salt = newSalt;
    saved.passwordHash = await securityHash(newPassword, newSalt);
    localStorage.setItem(SECURITY_KEY, JSON.stringify(saved));

    notify("تم تغيير كلمة المرور بنجاح");
    render();
  } catch (error) {
    if (message) message.textContent = "تعذر تغيير كلمة المرور. حاول مرة أخرى.";
  }
});

function enablePasswordSetup() {
  if (!window.crypto || !crypto.subtle) {
    alert("ميزة كلمة المرور غير مدعومة في بيئة التشغيل الحالية.");
    return;
  }

  lockApp();
  showFirstSetup();
}

function disablePasswordForm() {
  modal(`
    <h3>🔓 إلغاء كلمة المرور</h3>
    <p>أدخل كلمة المرور الحالية لإلغاء الحماية.</p>

    <form id="disablePasswordForm">
      <input
        id="disableCurrentPassword"
        type="password"
        placeholder="كلمة المرور الحالية"
        required
      >

      <p id="disablePasswordMessage"></p>

      <button class="bad" type="submit">
        تأكيد إلغاء كلمة المرور
      </button>

      <button type="button" onclick="closemodal()">
        تراجع
      </button>
    </form>
  `);

  document.getElementById("disablePasswordForm")
    .addEventListener("submit", confirmDisablePassword);
}

async function confirmDisablePassword(event) {
  event.preventDefault();

  const password =
    document.getElementById("disableCurrentPassword").value;

  const saved = securityRead();

  if (!saved) {
    closemodal();
    render();
    return;
  }

  try {
    const hash = await securityHash(password, saved.salt);

    if (hash !== saved.passwordHash) {
      document.getElementById("disablePasswordMessage").textContent =
        "كلمة المرور غير صحيحة.";
      return;
    }

    if (!confirm("هل تريد إلغاء حماية البرنامج بكلمة المرور؟")) {
      return;
    }

    localStorage.removeItem(SECURITY_KEY);
    closemodal();

    document.getElementById("lockScreen").style.display = "none";
    document.querySelector(".app").style.visibility = "visible";

    applySettings();
    render();
  } catch (error) {
    alert("حدث خطأ أثناء التحقق من كلمة المرور.");
  }
}
