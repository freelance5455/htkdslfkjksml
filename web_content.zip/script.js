const $=id=>document.getElementById(id);
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
const save=()=>{localStorage.setItem("RGTOUR_TRIPS",JSON.stringify(trips));localStorage.setItem("RGTOUR_OWNER",JSON.stringify(owner))};
let trips=load("RGTOUR_TRIPS",[]),owner=load("RGTOUR_OWNER",{name:"",pixType:"CPF",pix:""}),current=null,seat=null,lastSale=null;
trips=trips.map(v=>({...v,id:String(v.id),occupied:v.occupied||[],sales:v.sales||[]}));

function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.remove("active"));$(id).classList.add("active");scrollTo(0,0)}
function money(n){return Number(n||0).toLocaleString("pt-BR",{style:"currency",currency:"BRL"})}
function dateBR(x){if(!x)return"";let[a,b,c]=x.split("-");return`${c}/${b}/${a}`}
function toast(t){$("toast").textContent=t;$("toast").style.display="block";setTimeout(()=>$("toast").style.display="none",2200)}
function code(){return"RG-"+Math.random().toString(36).slice(2,8).toUpperCase()}

function renderHome(){
 let a=[...trips].sort((x,y)=>String(x.date).localeCompare(String(y.date)));
 $("tripList").innerHTML=a.length?a.map(v=>`<article class="trip"><h2>${v.destination}</h2><p>📅 ${dateBR(v.date)}</p><p>🕐 ${v.time}</p><p>📍 ${v.departure}</p><div class="price">${money(v.price)}</div><p>${v.seats-v.occupied.length} poltrona(s) disponível(is)</p><button class="primary" data-open="${v.id}">Escolher viagem</button></article>`).join(""):`<div class="card"><h2>Nenhuma viagem</h2><p class="muted">O proprietário ainda não publicou viagens.</p></div>`;
}
$("tripList").onclick=e=>{let b=e.target.closest("[data-open]");if(b)openTrip(b.dataset.open)};

function openTrip(id){
 current=trips.find(v=>v.id===String(id));if(!current)return;
 seat=null;$("dDest").textContent=current.destination;$("dDate").textContent=dateBR(current.date);$("dTime").textContent=current.time;$("dDeparture").textContent=current.departure;$("dPrice").textContent=money(current.price);$("continueSeat").disabled=true;
 $("seats").innerHTML="";
 for(let i=1;i<=current.seats;i++){let b=document.createElement("button");b.className="seat";b.textContent=i;if(current.occupied.includes(i)){b.classList.add("busy");b.disabled=true}b.onclick=()=>{document.querySelectorAll(".seat").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");seat=i;$("continueSeat").disabled=false};$("seats").appendChild(b)}
 show("details")
}

$("continueSeat").onclick=()=>{if(!seat)return;$("pDest").textContent=current.destination;$("pSeat").textContent=seat;$("pPrice").textContent=money(current.price);$("passName").value="";$("passCpf").value="";show("passenger")};
$("passCpf").oninput=e=>{let v=e.target.value.replace(/\D/g,"").slice(0,11);if(v.length>9)v=v.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/,"$1.$2.$3-$4");else if(v.length>6)v=v.replace(/(\d{3})(\d{3})(\d{3})/,"$1.$2.$3");else if(v.length>3)v=v.replace(/(\d{3})(\d{3})/,"$1.$2");e.target.value=v};

$("goPayment").onclick=()=>{let name=$("passName").value.trim(),cpf=$("passCpf").value.replace(/\D/g,"");if(!name)return toast("Digite o nome.");if(cpf.length!==11)return toast("Digite um CPF válido.");if(!owner.pix)return toast("Cadastre a chave PIX no painel.");$("paymentPixType").textContent="PIX "+owner.pixType;$("paymentPix").textContent=owner.pix;show("payment")};
$("copyPix").onclick=async()=>{try{await navigator.clipboard.writeText(owner.pix);toast("PIX copiado!")}catch{toast("Não foi possível copiar.")}};

$("confirmPayment").onclick=()=>{
 current=trips.find(v=>v.id===current.id);if(!current)return;
 if(current.occupied.includes(seat))return toast("Poltrona já ocupada.");
 lastSale={id:String(Date.now()),code:code(),destination:current.destination,date:current.date,time:current.time,departure:current.departure,price:Number(current.price),seat,name:$("passName").value.trim(),cpf:$("passCpf").value,type:$("passType").value};
 current.occupied.push(seat);current.sales.push(lastSale);save();renderHome();renderAdmin();stats();receipt();show("receipt")
};

function receipt(){
 let r=lastSale;
 $("receiptData").innerHTML=[["Destino",r.destination],["Data",dateBR(r.date)],["Horário",r.time],["Saída",r.departure],["Passageiro",r.name],["CPF",r.cpf],["Tipo",r.type],["Poltrona",r.seat],["Valor",money(r.price)],["Código",r.code]].map(x=>`<div class="receiptLine"><span>${x[0]}</span><b>${x[1]}</b></div>`).join("")
}
function receiptText(){let r=lastSale;return`RGTOUR - COMPROVANTE DE PASSAGEM\n\nDestino: ${r.destination}\nData: ${dateBR(r.date)}\nHorário: ${r.time}\nSaída: ${r.departure}\nPassageiro: ${r.name}\nCPF: ${r.cpf}\nTipo: ${r.type}\nPoltrona: ${r.seat}\nValor: ${money(r.price)}\nCódigo: ${r.code}\nPagamento confirmado.`}
$("copyReceipt").onclick=async()=>{try{await navigator.clipboard.writeText(receiptText());toast("Comprovante copiado!")}catch{toast("Não foi possível copiar.")}};
$("shareReceipt").onclick=async()=>{if(navigator.share){try{await navigator.share({title:"Comprovante RGTOUR",text:receiptText()})}catch{}}else{try{await navigator.clipboard.writeText(receiptText());toast("Comprovante copiado!")}catch{toast("Compartilhamento indisponível.")}}};

function stats(){let p=0,o=0,m=0;trips.forEach(v=>{p+=v.sales.length;o+=v.occupied.length;v.sales.forEach(s=>m+=Number(s.price))});$("sTrips").textContent=trips.length;$("sPeople").textContent=p;$("sSeats").textContent=o;$("sMoney").textContent=money(m)}
function renderAdmin(){
 $("adminTrips").innerHTML=trips.length?trips.map(v=>`<div class="adminTrip"><h3>${v.destination}</h3><p>${dateBR(v.date)} • ${v.time} • ${v.departure}</p><p>${v.occupied.length}/${v.seats} ocupadas • ${money(v.price)}</p><div class="actions"><button class="primary" data-a-open="${v.id}">Visualizar</button><button class="secondary" data-a-people="${v.id}">Passageiros</button><button class="secondary" data-a-edit="${v.id}">Editar</button><button class="danger" data-a-del="${v.id}">Excluir</button></div></div>`).join(""):`<p class="muted">Nenhuma viagem cadastrada.</p>`
}
$("adminTrips").onclick=e=>{let b=e.target.closest("button");if(!b)return;if(b.dataset.aOpen)openTrip(b.dataset.aOpen);if(b.dataset.aPeople)people(b.dataset.aPeople);if(b.dataset.aEdit)editTrip(b.dataset.aEdit);if(b.dataset.aDel)deleteTrip(b.dataset.aDel)};

function clearForm(){$("editId").value="";$("destination").value="";$("date").value="";$("time").value="";$("departure").value="";$("price").value="";$("formTitle").textContent="Nova viagem";$("saveTrip").textContent="Criar viagem";$("cancelEdit").classList.add("hidden")}
$("saveTrip").onclick=()=>{
 let id=$("editId").value,d=$("destination").value.trim(),dt=$("date").value,t=$("time").value,dep=$("departure").value.trim(),p=Number($("price").value),s=Number($("seatCount").value);
 if(!d||!dt||!t||!dep||p<0)return toast("Preencha os dados da viagem.");
 if(id){let v=trips.find(x=>x.id===id);if(!v)return;if(s<v.occupied.length)return toast("A quantidade é menor que as poltronas ocupadas.");Object.assign(v,{destination:d,date:dt,time:t,departure:dep,price:p,seats:s});toast("Viagem atualizada!")}else{trips.push({id:String(Date.now()),destination:d,date:dt,time:t,departure:dep,price:p,seats:s,occupied:[],sales:[]});toast("Viagem criada!")}
 save();clearForm();renderHome();renderAdmin();stats()
};
function editTrip(id){let v=trips.find(x=>x.id===String(id));if(!v)return;$("editId").value=v.id;$("destination").value=v.destination;$("date").value=v.date;$("time").value=v.time;$("departure").value=v.departure;$("price").value=v.price;$("seatCount").value=v.seats;$("formTitle").textContent="Editar viagem";$("saveTrip").textContent="Salvar alterações";$("cancelEdit").classList.remove("hidden");scrollTo({top:0,behavior:"smooth"})}
$("cancelEdit").onclick=clearForm;

function deleteTrip(id){id=String(id);let i=trips.findIndex(v=>String(v.id)===id);if(i<0)return toast("Viagem não encontrada.");if(!confirm("Excluir a viagem para "+trips[i].destination+"?"))return;trips.splice(i,1);save();renderHome();renderAdmin();stats();toast("Viagem excluída!")}
function people(id){let v=trips.find(x=>x.id===String(id));if(!v)return;$("peopleTitle").textContent="Passageiros - "+v.destination;$("peopleList").innerHTML=v.sales.length?v.sales.map(p=>`<div class="person"><strong>${p.name}</strong><p>CPF: ${p.cpf}</p><p>Tipo: ${p.type} • Poltrona: ${p.seat}</p><p>Valor: ${money(p.price)} • Código: ${p.code}</p></div>`).join(""):"<p class='muted'>Nenhum passageiro.</p>";show("people")}

$("saveOwner").onclick=()=>{owner.name=$("ownerName").value.trim();owner.pixType=$("pixType").value;owner.pix=$("pixKey").value.trim();save();toast("Dados salvos!")};
$("adminBtn").onclick=()=>{ $("ownerName").value=owner.name;$("pixType").value=owner.pixType;$("pixKey").value=owner.pix;renderAdmin();stats();show("admin")};
$("homeFromAdmin").onclick=()=>show("home");$("backHome").onclick=()=>show("home");$("backDetails").onclick=()=>show("details");$("backPassenger").onclick=()=>show("passenger");$("backAdmin").onclick=()=>{renderAdmin();stats();show("admin")};$("newPurchase").onclick=()=>{renderHome();show("home")};

renderHome();renderAdmin();stats();
