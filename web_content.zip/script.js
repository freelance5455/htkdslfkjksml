
/* =========================================
   WORD ZENTO PUZZLE
   COMPLETE MAIN GAME JAVASCRIPT
========================================= */

const $ = selector => document.querySelector(selector);
const screens = [...document.querySelectorAll(".screen")];
const STORE = "wordZentoPuzzle_v1";

const defaults = {
    unlocked: 1,
    completed: [],
    coins: 0,
    hints: 0,
    hintAdsWatched: {},
    sound: true,
    music: true,
    theme: "dark"
};

let data = {
    ...defaults,
    ...JSON.parse(localStorage.getItem(STORE) || "{}")
};

let level = 1;
let puzzle = null;
let selected = [];
let found = [];
let pointerDown = false;
let toastTimer;
let pendingAdLevel = null;

/* SAVE GAME DATA */

function save() {
    localStorage.setItem(STORE, JSON.stringify(data));
    updateCoins();
}

/* UPDATE COINS AND HINT BUTTON */

function updateCoins() {

    ["#homeCoins", "#levelCoins", "#gameCoins"].forEach(selector => {
        const element = $(selector);
        if (element) element.textContent = data.coins;
    });

    const hintsLeft = $("#hintsLeft");
    if (hintsLeft) hintsLeft.textContent = data.hints;

    const hintButton = $("#hintBtn");

    if (hintButton) {
        const limit = getAdLimit(level);
        const watched = Number(data.hintAdsWatched[level] || 0);

        if (data.hints > 0) {
            hintButton.innerHTML = `
                <span class="hint-main"><span class="hint-icon">💡</span> HINT</span>
                <small class="hint-sub">${data.hints} saved</small>
            `;
            hintButton.classList.remove("ad-ready");
        } else {
            hintButton.innerHTML = `
                <span class="hint-main">
                    <span class="hint-icon">💡</span> HINT
                    <span class="hint-ad-tag">AD</span>
                </span>
                <small class="hint-sub">${watched}/${limit} ads this level</small>
            `;
            hintButton.classList.add("ad-ready");
        }

        hintButton.disabled = pendingAdLevel !== null ||
            (data.hints <= 0 && watched >= limit);
    }
}

/* SCREEN NAVIGATION */

function show(id) {
    screens.forEach(screen => {
        screen.classList.toggle("active", screen.id === id);
    });
}

/* TOAST MESSAGE */

function toast(message) {
    const t = $("#toast");
    t.textContent = message;
    t.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        t.classList.remove("show");
    }, 2200);
}

/* =========================================
   SOUND EFFECTS
========================================= */

let soundContext = null;

function beep(freq = 520, dur = 0.06) {

    if (!data.sound) return;

    try {

        if (!soundContext) {
            soundContext = new (
                window.AudioContext ||
                window.webkitAudioContext
            )();
        }

        if (soundContext.state === "suspended") {
            soundContext.resume();
        }

        let oscillator = soundContext.createOscillator();
        let gain = soundContext.createGain();

        oscillator.frequency.value = freq;
        gain.gain.value = 0.045;

        oscillator.connect(gain);
        gain.connect(soundContext.destination);

        const now = soundContext.currentTime;

        oscillator.start(now);

        gain.gain.exponentialRampToValueAtTime(
            0.001,
            now + dur
        );

        oscillator.stop(now + dur);

    } catch (error) {
        console.log("Sound could not play:", error);
    }
}

/* =========================================
   ORIGINAL BACKGROUND MUSIC SYSTEM
========================================= */

let musicContext = null;
let musicMaster = null;
let musicTimer = null;
let musicStep = 0;

const musicMelody = [
    523.25, 659.25, 783.99, 659.25,
    587.33, 698.46, 880.00, 698.46,
    523.25, 659.25, 783.99, 987.77,
    880.00, 783.99, 659.25, 587.33
];

function playMusicNote() {

    if (!musicContext || !musicMaster || !data.music) return;

    const frequency = musicMelody[musicStep];

    const oscillator = musicContext.createOscillator();
    const volume = musicContext.createGain();

    oscillator.type = "sine";
    oscillator.frequency.value = frequency;

    const now = musicContext.currentTime;

    volume.gain.setValueAtTime(0.001, now);
    volume.gain.linearRampToValueAtTime(0.045, now + 0.08);
    volume.gain.exponentialRampToValueAtTime(0.001, now + 0.48);

    oscillator.connect(volume);
    volume.connect(musicMaster);

    oscillator.start(now);
    oscillator.stop(now + 0.5);

    musicStep = (musicStep + 1) % musicMelody.length;
}

function startBackgroundMusic() {

    if (!data.music) return;

    try {

        if (!musicContext) {

            musicContext = new (
                window.AudioContext ||
                window.webkitAudioContext
            )();

            musicMaster = musicContext.createGain();

            musicMaster.gain.value = 0;

            musicMaster.connect(musicContext.destination);
        }

        if (musicContext.state === "suspended") {
            musicContext.resume();
        }

        if (musicTimer !== null) return;

        musicMaster.gain.cancelScheduledValues(
            musicContext.currentTime
        );

        musicMaster.gain.setTargetAtTime(
            0.50,
            musicContext.currentTime,
            0.3
        );

        playMusicNote();

        musicTimer = setInterval(() => {
            playMusicNote();
        }, 500);

    } catch (error) {

        console.log("Music could not start:", error);
    }
}

function stopBackgroundMusic() {

    if (musicTimer !== null) {

        clearInterval(musicTimer);

        musicTimer = null;
    }

    if (musicContext && musicMaster) {

        musicMaster.gain.cancelScheduledValues(
            musicContext.currentTime
        );

        musicMaster.gain.setTargetAtTime(
            0,
            musicContext.currentTime,
            0.15
        );
    }
}

/* WORD DATABASE */

const words = `
APPLE,ORANGE,BANANA,GRAPE,PEACH,CHERRY,MANGO,
LEMON,MELON,PLUM,PEAR,COCONUT,PLANET,ROCKET,
STAR,MOON,SUN,COMET,SPACE,ORBIT,EARTH,MARS,
VENUS,NEPTUNE,PUZZLE,GARDEN,FOREST,RIVER,OCEAN,
MOUNTAIN,DESERT,VALLEY,ISLAND,BRIDGE,CLOUD,
RAINBOW,THUNDER,WINTER,SUMMER,AUTUMN,SPRING,
MONDAY,TUESDAY,FRIDAY,SUNDAY,MORNING,EVENING,
MIDNIGHT,FRIEND,FAMILY,SCHOOL,TEACHER,STUDENT,
BOOK,PENCIL,MARKER,WINDOW,DOOR,TABLE,CHAIR,
DREAM,SMILE,LAUGH,ENERGY,POWER,BRIGHT,QUICK,
SMART,BRAVE,PEACE,HOPE,TRUST,FAITH,HEART,
MUSIC,PIANO,GUITAR,DRUM,VIOLIN,MELODY,RHYTHM,
DANCE,PAINT,CAMERA,PHOTO,MOVIE,STORY,POETRY,
LETTER,NUMBER,TRAVEL,FLIGHT,AIRPORT,TRAIN,
RAILWAY,BICYCLE,ENGINE,STATION,MARKET,BAKERY,
CASTLE,TOWER,PALACE,VILLAGE,CITY,COUNTRY,
TIGER,LION,ZEBRA,GIRAFFE,MONKEY,RABBIT,TURTLE,
DOLPHIN,SHARK,EAGLE,PARROT,PENGUIN,SPIDER,
BUTTERFLY,DRAGON,ROBOT,COMPUTER,KEYBOARD,
SCREEN,PHONE,INTERNET,PIXEL,SEARCH,SECRET,
ANSWER,CHALLENGE,VICTORY,LEVEL,COIN,HINT,
PLAYER,WINNER,CHAMPION,EXPLORE,DISCOVER,
CREATE,IMAGINE,LEARN,FOCUS,MEMORY,LOGIC,
SCIENCE,MATH,ART,SPORT,CRICKET,FOOTBALL,
TENNIS,HISTORY,GEOGRAPHY,CRYSTAL,DIAMOND,
SILVER,GOLD,COPPER,GALAXY,ASTEROID,
ASTRONAUT,SPACESHIP,ADVENTURE,MYSTERY,
TREASURE,COMPASS,ANCHOR,SAILOR,HARBOR,
SHIP,HELMET,UNIFORM,RIBBON,CANDLE,LANTERN,
MIRROR,PILLOW,BLANKET,CARPET,CURTAIN,
FLOWER,ROSE,TULIP,DAISY,SUNFLOWER,JASMINE,
LOTUS,CACTUS,BAMBOO,MAPLE,CEDAR,LEAF,ROOT,
BRANCH,SEED,FRUIT,VEGETABLE,CARROT,POTATO,
TOMATO,ONION,GARLIC,SPINACH,PUMPKIN,BREAD,
CHEESE,BUTTER,COOKIE,BISCUIT,CHOCOLATE,
VANILLA,HONEY,SUGAR,COFFEE,TEA,WATER,JUICE,
MILK,BREAKFAST,LUNCH,DINNER,SNACK,PLATE,
SPOON,FORK,KNIFE,BOTTLE,GLASS,CUP,KETTLE,
OVEN,RECIPE,FLAVOR,SPICY,SWEET,SOUR,FRESH,
MAGIC,FANTASY,HERO,QUEST,KINGDOM,PRINCESS,
KNIGHT,WIZARD,SHIELD,CROWN,JEWEL,FIREFLY,
SUNLIGHT,SHADOW,BREEZE,STORM,FROST,SNOWFLAKE,
WATERFALL,STREAM,POND,LAKE,BEACH,COAST,CLIFF,
CANYON,CAVE,JUNGLE,PRAIRIE,MEADOW,FIELD,FARM,
BARN,HORSE,DONKEY,SHEEP,GOAT,COW,CAMEL,DEER,
FOX,WOLF,BEAR,PANDA,KOALA,OTTER,WHALE,SEAL,
OCTOPUS,CRAB,LOBSTER,FALCON,OWL,SWAN,DUCK,
PEACOCK,FLAMINGO,SPARROW,ROBIN,FEATHER,WING,
CLAW,PAW,TAIL,FUR,SCALE,FIN,BEAK,HORN,ANT,
BEE,WASP,LADYBUG,SNAIL,SQUIRREL,HAMSTER,
KITTEN,PUPPY,NATURE,WILDLIFE,HABITAT,ECOLOGY,
RECYCLE,GREEN,SOLAR,WIND,HYDRO,BATTERY,
CIRCUIT,SENSOR,SIGNAL,NETWORK,DIGITAL,MOBILE,
TABLET,LAPTOP,PRINTER,SPEAKER,HEADPHONE,
MICROPHONE,CHARGER,CABLE,LENS,TOUCH,SWIPE,
CLICK,TYPE,SCROLL,APP,GAME,SCORE,TIMER,BONUS,
REWARD,TARGET,MISSION,JOURNEY,ROUTE,
DESTINATION,PASSPORT,TICKET,SUITCASE,
BACKPACK,HOTEL,RESORT,TOURIST,GUIDE,CULTURE,
FESTIVAL,PARADE,HOLIDAY,WEEKEND,VACATION,
PICNIC,CAMPING,TENT,BONFIRE,HIKE,TRAIL,
SUMMIT,CLIMB,RUNNER,SWIMMER,CYCLIST,ATHLETE,
COACH,TEAM,GOAL,MATCH,TROPHY,MEDAL,RACKET,
BALL,STADIUM,ARENA,REFEREE,WHISTLE,PRACTICE,
TRAINING,FITNESS,BALANCE,STRONG,ACTIVE,HEALTHY,
DOCTOR,NURSE,HOSPITAL,CLINIC,PHARMACY,DENTIST,
PATIENT,SCIENTIST,ENGINEER,ARTIST,WRITER,
DESIGNER,BUILDER,FARMER,BAKER,DRIVER,PILOT,
CAPTAIN,DETECTIVE,LIBRARIAN,MECHANIC,ACTOR,
SINGER,DANCER,DIRECTOR,PRODUCER,JOURNALIST,
REPORTER,EDITOR,AUTHOR,POET,NOVEL,CHAPTER,
PARAGRAPH,SENTENCE,GRAMMAR,SPELLING,
DICTIONARY,THESAURUS,VOCABULARY,PHRASE,
MEANING,QUESTION,RESPONSE,DISCUSSION,
CONVERSATION,MESSAGE,EMAIL,POSTCARD,JOURNAL,
DIARY,CALENDAR,SCHEDULE,CLOCK,WATCH,MINUTE,
SECOND,HOUR,MOMENT,FUTURE,PAST,PRESENT,
TOMORROW,YESTERDAY,TODAY,ALWAYS,NEVER,
SOMETIMES,OFTEN,RARELY,EARLY,LATE,QUICKLY,
SLOWLY,CAREFULLY,HAPPILY,KINDNESS,HONESTY,
COURAGE,PATIENCE,RESPECT,SUCCESS,FAILURE,
EFFORT,PROGRESS,PURPOSE,PASSION,TALENT,SKILL,
KNOWLEDGE,WISDOM,CURIOSITY,ATTENTION,
CONCENTRATE,THINKING,SOLUTION,PROBLEM,PATTERN,
SEQUENCE,SHAPE,CIRCLE,SQUARE,TRIANGLE,
RECTANGLE,SPIRAL,ANGLE,CORNER,EDGE,CENTER,
DIAGONAL,HORIZONTAL,VERTICAL,PARALLEL,SYMMETRY,
COLOR,PURPLE,YELLOW,BLUE,INDIGO,VIOLET,CRIMSON,
SCARLET,TURQUOISE,MAGENTA,BRONZE,BLACK,WHITE,
GREY,BROWN,PINK,MAROON,NAVY,TEAL,LAVENDER,
BEIGE,IVORY,AMBER,CORAL,MINT,PEARL
`.split(",").map(word => word.trim()).filter(Boolean);

const uniqueWords = [...new Set(words)].filter(word => word.length >= 3);

/* LEVEL DIFFICULTY */

function sizeFor(level) {
    return Math.min(
        14,
        Math.max(5, 5 + Math.floor((level - 1) / 4))
    );
}

function getLevelDifficulty(levelNumber) {
    const size = sizeFor(levelNumber);
    if (size >= 9) return "hard";
    if (size >= 7) return "medium";
    return "easy";
}

function getAdLimit(levelNumber) {
    const difficulty = getLevelDifficulty(levelNumber);
    if (difficulty === "hard") return 3;
    if (difficulty === "medium") return 2;
    return 1;
}

function countFor(level) {
    return Math.min(
        10,
        3 + Math.floor((level - 1) / 5)
    );
}

/* =========================================
   SEEDED RANDOM GENERATOR
========================================= */

function createLevelRandom(levelNumber, attempt = 0) {

    let seed = (
        Math.imul(levelNumber, 73856093) +
        Math.imul(attempt + 1, 19349663)
    ) >>> 0;

    return function () {

        seed = (seed + 0x6D2B79F5) >>> 0;

        let t = seed;

        t = Math.imul(t ^ (t >>> 15), t | 1);

        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);

        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
}

/* SELECT WORDS FOR LEVEL */

function pickWords(level, count, random) {

    let pool = [...uniqueWords];

    for (let i = pool.length - 1; i > 0; i--) {

        const j = Math.floor(random() * (i + 1));

        [pool[i], pool[j]] = [pool[j], pool[i]];
    }

    const gridSize = sizeFor(level);

    let maxLength = Math.min(
        7 + Math.floor(level / 15),
        12,
        gridSize
    );

    let minLength = Math.min(
        3 + Math.floor(level / 12),
        7,
        maxLength
    );

    return pool
        .filter(word =>
            word.length >= minLength &&
            word.length <= maxLength
        )
        .slice(0, count);
}

/* CREATE PUZZLE GRID */

function makePuzzle(levelNumber) {

    const size = sizeFor(levelNumber);
    const requiredCount = countFor(levelNumber);

    for (let attempt = 0; attempt < 100; attempt++) {

        const random = createLevelRandom(levelNumber, attempt);

        const chosen = pickWords(
            levelNumber,
            requiredCount,
            random
        );

        if (chosen.length < requiredCount) {
            throw new Error("Not enough words for this level.");
        }

        let grid = Array.from(
            { length: size },
            () => Array(size).fill("")
        );

        let directions = [
            [0, 1], [1, 0], [0, -1], [-1, 0],
            [1, 1], [1, -1], [-1, 1], [-1, -1]
        ];

        let placements = {};
        let failed = false;

        for (const word of chosen) {

            let placed = false;

            for (let tries = 0; tries < 500 && !placed; tries++) {

                let [dr, dc] = directions[
                    Math.floor(random() * directions.length)
                ];

                let r = Math.floor(random() * size);
                let c = Math.floor(random() * size);

                let er = r + dr * (word.length - 1);
                let ec = c + dc * (word.length - 1);

                if (
                    er < 0 || ec < 0 ||
                    er >= size || ec >= size
                ) {
                    continue;
                }

                let ok = true;

                for (let i = 0; i < word.length; i++) {

                    let letter = grid[
                        r + dr * i
                    ][
                        c + dc * i
                    ];

                    if (letter && letter !== word[i]) {
                        ok = false;
                        break;
                    }
                }

                if (ok) {

                    let cells = [];

                    for (let i = 0; i < word.length; i++) {

                        let rr = r + dr * i;
                        let cc = c + dc * i;

                        grid[rr][cc] = word[i];

                        cells.push(rr * size + cc);
                    }

                    placements[word] = cells;

                    placed = true;
                }
            }

            if (!placed) {
                failed = true;
                break;
            }
        }

        if (failed) continue;

        for (let r = 0; r < size; r++) {

            for (let c = 0; c < size; c++) {

                if (!grid[r][c]) {

                    grid[r][c] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[
                        Math.floor(random() * 26)
                    ];
                }
            }
        }

        return {
            size,
            words: Object.keys(placements),
            grid,
            placements
        };
    }

    throw new Error("Could not generate this level. Please try again.");
}

/* START LEVEL */

function startLevel(selectedLevel) {

    level = selectedLevel;

    if (!data.hintAdsWatched || typeof data.hintAdsWatched !== "object") {
        data.hintAdsWatched = {};
    }

    if (typeof data.hints !== "number") {
        data.hints = 0;
    }

    puzzle = makePuzzle(level);

    found = [];
    selected = [];
    pointerDown = false;

    $("#currentLevel").textContent = level;

    $("#nextBtn").disabled = true;

    $("#gameMessage").textContent =
        "Find the words in the grid.";

    renderGame();

    show("game");

    updateCoins();
}

/* =========================================
   DISPLAY GAME
========================================= */

function renderGame() {

    // Show only 5 unfound words at a time
    renderWordList();

    const board = $("#board");

    board.style.gridTemplateColumns =
        `repeat(${puzzle.size}, 1fr)`;

    board.innerHTML = "";

    puzzle.grid.flat().forEach((letter, index) => {

        let cell = document.createElement("div");

        cell.className = "cell";

        cell.textContent = letter;

        cell.dataset.i = index;

        board.appendChild(cell);
    });

    updateProgress();
}

/* =========================================
   WORD LIST - MAXIMUM 5 WORDS
========================================= */

function renderWordList() {

    const wordList = $("#wordList");

    // Get all words that have not been found
    const remainingWords = puzzle.words.filter(
        word => !found.includes(word)
    );

    // Display only the first 5 remaining words
    const visibleWords = remainingWords.slice(0, 5);

    wordList.innerHTML = visibleWords
        .map(word => `
            <span class="word-chip" data-word="${word}">
                ${word}
            </span>
        `)
        .join("");
}

/* UPDATE GAME PROGRESS */

function updateProgress() {

    let percentage =
        found.length / puzzle.words.length * 100;

    $("#progressBar").style.width =
        percentage + "%";

    if (found.length === puzzle.words.length) {

        $("#gameMessage").textContent =
            "🎉 Excellent! Level completed.";

        $("#nextBtn").disabled = false;

        beep(760, 0.18);

        if (!data.completed.includes(level)) {

            data.completed.push(level);

            data.unlocked = Math.max(
                data.unlocked,
                level + 1
            );

            data.coins += 2;

            save();

            toast("Level complete! +2 coins");
        }
    }
}

/* TOUCH AND MOUSE SELECTION */

const board = $("#board");

function cellIndexFromPoint(x, y) {

    let element = document
        .elementFromPoint(x, y)
        ?.closest(".cell");

    return element ? Number(element.dataset.i) : null;
}

function selectAt(index) {

    if (
        index === null ||
        selected.includes(index)
    ) return;

    selected.push(index);

    const cell = $(
        `#board .cell[data-i="${index}"]`
    );

    if (cell) {
        cell.classList.add("selected");
    }
}

function clearSelection() {

    selected.forEach(index => {

        let cell = $(
            `#board .cell[data-i="${index}"]`
        );

        if (
            cell &&
            !cell.classList.contains("found")
        ) {
            cell.classList.remove("selected");
        }
    });

    selected = [];
}

/* =========================================
   CHECK SELECTED WORD
========================================= */

function checkSelection() {

    if (selected.length < 2) {
        clearSelection();
        return;
    }

    let key = selected.join(",");

    let reverseKey = [...selected]
        .reverse()
        .join(",");

    let match = puzzle.words.find(word => {

        if (found.includes(word)) return false;

        let correct = puzzle.placements[word].join(",");

        return (
            correct === key ||
            correct === reverseKey
        );
    });

    if (match) {

        found.push(match);

        puzzle.placements[match].forEach(index => {

            let cell = $(
                `#board .cell[data-i="${index}"]`
            );

            cell.classList.remove("selected");

            cell.classList.add("found");
        });

        // Remove found word from visible list.
        // Automatically show the next unfound word.
        renderWordList();

        beep(680, 0.09);

        updateProgress();

    } else {

        beep(220, 0.05);

        clearSelection();
    }
}

/* POINTER EVENTS */

board.addEventListener("pointerdown", event => {

    let index = cellIndexFromPoint(
        event.clientX,
        event.clientY
    );

    if (index !== null) {

        pointerDown = true;

        clearSelection();

        selectAt(index);

        try {
            board.setPointerCapture(event.pointerId);
        } catch (error) {}
    }
});

board.addEventListener("pointermove", event => {

    if (pointerDown) {

        let index = cellIndexFromPoint(
            event.clientX,
            event.clientY
        );

        if (index !== null) {
            selectAt(index);
        }
    }
});

board.addEventListener("pointerup", () => {

    if (pointerDown) {

        pointerDown = false;

        checkSelection();
    }
});

board.addEventListener("pointercancel", () => {

    pointerDown = false;

    clearSelection();
});

/* LEVEL SELECTION */


/* =========================================
   LEVEL SELECTION - OPTIMIZED LAZY LOADING
========================================= */

let nextLevelToRender = 1;
const LEVEL_BATCH_SIZE = 100;
const TOTAL_LEVELS = 10000;

function createLevelCard(levelNumber) {

    const unlocked = levelNumber <= data.unlocked;
    const completed = data.completed.includes(levelNumber);

    const size = sizeFor(levelNumber);

    const difficulty =
        getLevelDifficulty(levelNumber).toUpperCase();

    const card = document.createElement("button");

    card.className = "level-card";

    if (!unlocked) card.classList.add("locked");
    if (completed) card.classList.add("completed");
    if (levelNumber === data.unlocked) {
        card.classList.add("current");
    }

    card.innerHTML = `
        <span class="level-number">
            ${String(levelNumber).padStart(2, "0")}
        </span>
        <span class="level-info">
            ${size}×${size} • ${difficulty}
        </span>
    `;

    if (unlocked) {
        card.onclick = () => startLevel(levelNumber);
    } else {
        card.disabled = true;
    }

    return card;
}

function loadMoreLevels() {

    const grid = $("#levelGrid");

    if (!grid || nextLevelToRender > TOTAL_LEVELS) {
        return;
    }

    const fragment = document.createDocumentFragment();

    const endLevel = Math.min(
        nextLevelToRender + LEVEL_BATCH_SIZE - 1,
        TOTAL_LEVELS
    );

    for (
        let levelNumber = nextLevelToRender;
        levelNumber <= endLevel;
        levelNumber++
    ) {

        fragment.appendChild(
            createLevelCard(levelNumber)
        );
    }

    grid.appendChild(fragment);

    nextLevelToRender = endLevel + 1;
}

function checkLevelScroll() {

    const grid = $("#levelGrid");

    if (!grid || nextLevelToRender > TOTAL_LEVELS) {
        return;
    }

    const gridBottom = grid.getBoundingClientRect().bottom;

    if (gridBottom <= window.innerHeight + 500) {
        loadMoreLevels();
    }
}

function renderLevels() {

    const grid = $("#levelGrid");

    if (!grid) return;

    // Clear old level cards
    grid.innerHTML = "";

    // Start again from level 1
    nextLevelToRender = 1;

    // Load only first 100 levels
    loadMoreLevels();

    // Check if more levels are needed while scrolling
    requestAnimationFrame(checkLevelScroll);
}

// Listen for scrolling in the levels section
window.addEventListener(
    "scroll",
    checkLevelScroll,
    true
);

window.addEventListener(
    "resize",
    checkLevelScroll
);



// function renderLevels() {

//     const grid = document.getElementById("levelGrid");
//     grid.innerHTML = "";

//     const totalLevels = 10000;

//     for (let level = 1; level <= totalLevels; level++) {

//         const unlocked = level <= data.unlocked;
//         const completed = data.completed.includes(level);

//         const size = sizeFor(level);

//         let difficulty = getLevelDifficulty(level).toUpperCase();

//         const card = document.createElement("button");

//         card.className = "level-card";

//         if (!unlocked) card.classList.add("locked");
//         if (completed) card.classList.add("completed");
//         if (level === data.unlocked) card.classList.add("current");

//         card.innerHTML = `
//             <span class="level-number">
//                 ${String(level).padStart(2, "0")}
//             </span>
//             <span class="level-info">
//                 ${size}×${size} • ${difficulty}
//             </span>
//         `;

//         if (unlocked) {
//             card.onclick = () => startLevel(level);
//         } else {
//             card.disabled = true;
//         }

//         grid.appendChild(card);
//     }
// }

/* HINT SYSTEM */

function hint() {

    if (!puzzle || found.length === puzzle.words.length) return;

    if (data.hints > 0) {

        const target = puzzle.words.find(word => !found.includes(word));

        if (!target) return;

        data.hints--;

        save();

        revealHint(target);

        toast("Saved hint used.");

        return;
    }

    const watched = Number(data.hintAdsWatched[level] || 0);
    const limit = getAdLimit(level);

    if (watched >= limit) {

        toast("This level's ad limit is complete.");

        updateCoins();

        return;
    }

    if (!navigator.onLine) {

        showModal(
            "You're Offline",
            "You're offline. Please connect your internet to watch a hint ad.",
            "OK",
            () => hideModal()
        );

        return;
    }

    if (pendingAdLevel !== null) return;

    if (
        window.AndroidAds &&
        typeof window.AndroidAds.showRewardedAd === "function"
    ) {

        pendingAdLevel = level;

        updateCoins();

        try {

            window.AndroidAds.showRewardedAd();

        } catch (error) {

            pendingAdLevel = null;

            updateCoins();

            showModal(
                "Ad Not Available",
                "The ad could not be started. Please try again later.",
                "OK",
                () => hideModal()
            );
        }

        return;
    }

    showModal(
        "Ad Not Connected",
        "Rewarded ads are not connected yet. Connect AdMob in the Android app to earn hints.",
        "OK",
        () => hideModal()
    );
}

/* REWARDED AD CALLBACKS */

window.onRewardedAdCompleted = function () {

    if (pendingAdLevel === null) return;

    const rewardedLevel = pendingAdLevel;

    pendingAdLevel = null;

    if (!data.hintAdsWatched || typeof data.hintAdsWatched !== "object") {
        data.hintAdsWatched = {};
    }

    const watched = Number(data.hintAdsWatched[rewardedLevel] || 0);
    const limit = getAdLimit(rewardedLevel);

    if (watched >= limit) {
        save();
        return;
    }

    data.hintAdsWatched[rewardedLevel] = watched + 1;

    data.hints += 1;

    save();

    toast("Reward earned! +1 hint");
};

window.onRewardedAdFailed = function () {

    pendingAdLevel = null;

    updateCoins();

    showModal(
        "Ad Not Available",
        "The ad was not completed or could not be loaded. No hint was added.",
        "OK",
        () => hideModal()
    );
};

/* REVEAL HINT */

function revealHint(word) {

    let index = puzzle.placements[word][0];

    let cell = $(
        `#board .cell[data-i="${index}"]`
    );

    cell.classList.add("selected");

    setTimeout(() => {
        cell.classList.remove("selected");
    }, 850);

    $("#gameMessage").textContent =
        "Hint: look for " + word[0] + "...";
}

/* MODAL SYSTEM */

function showModal(title, message, okText, okFunction) {

    $("#modalTitle").textContent = title;

    $("#modalText").textContent = message;

    $("#modalOk").textContent = okText;

    $("#modal").classList.remove("hidden");

    $("#modalOk").onclick = okFunction;
}

function hideModal() {

    $("#modal").classList.add("hidden");
}

$("#modalCancel").onclick = hideModal;

/* NAVIGATION BUTTONS */

$("#startBtn").onclick = () => {

    beep();

    startBackgroundMusic();

    renderLevels();

    show("levels");
};

$("#settingsBtn").onclick = () => {
    beep();
    show("settings");
};

$("#levelsBack").onclick = () => {
    beep();
    show("home");
};

$("#settingsBack").onclick = () => {
    beep();
    show("home");
};

$("#gameBack").onclick = () => {

    beep();

    renderLevels();

    show("levels");
};

$("#restartBtn").onclick = () => {
    beep();
    startLevel(level);
};

$("#nextBtn").onclick = () => {
    beep();
    startLevel(level + 1);
};

$("#hintBtn").onclick = hint;

/* SHARE BUTTON */

$("#homeShare").onclick = async () => {

    beep();

    let share = {
        title: "WORD ZENTO PUZZLE",
        text: "Play WORD ZENTO PUZZLE! Find words and solve puzzles."
    };

    if (navigator.share) {

        try {
            await navigator.share(share);
        } catch (error) {}

    } else {

        try {

            await navigator.clipboard.writeText(share.text);

            toast("Share text copied.");

        } catch (error) {

            toast("Sharing is available in the Android app.");
        }
    }
};

/* SOUND AND MUSIC SETTINGS */

document.querySelectorAll("[data-setting]")
    .forEach(button => {

        let key = button.dataset.setting;

        button.classList.toggle(
            "on",
            !!data[key]
        );

        button.textContent =
            data[key] ? "ON" : "OFF";

        button.onclick = () => {

            data[key] = !data[key];

            button.classList.toggle(
                "on",
                data[key]
            );

            button.textContent =
                data[key] ? "ON" : "OFF";

            if (key === "music") {

                if (data.music) {
                    startBackgroundMusic();
                } else {
                    stopBackgroundMusic();
                }
            }

            save();
        };
    });

/* DARK AND LIGHT THEME */

$("#themeBtn").textContent =
    data.theme.toUpperCase();

document.body.classList.toggle(
    "light",
    data.theme === "light"
);

$("#themeBtn").onclick = () => {

    beep();

    data.theme =
        data.theme === "dark" ? "light" : "dark";

    document.body.classList.toggle(
        "light",
        data.theme === "light"
    );

    $("#themeBtn").textContent =
        data.theme.toUpperCase();

    save();
};

/* RESET GAME DATA */

$("#resetBtn").onclick = () => {

    showModal(
        "Reset game data?",
        "All completed levels, coins and saved hints will be deleted. This action cannot be undone.",
        "OK",

        () => {

            stopBackgroundMusic();

            data = { ...defaults };

            save();

            document.body.classList.remove("light");

            $("#themeBtn").textContent = "DARK";

            document.querySelectorAll("[data-setting]")
                .forEach(button => {

                    button.classList.add("on");

                    button.textContent = "ON";
                });

            hideModal();

            renderLevels();

            show("home");

            if (data.music) {
                startBackgroundMusic();
            }

            toast("Game data has been reset.");
        }
    );
};

/* START GAME */

updateCoins();

document.body.classList.toggle(
    "light",
    data.theme === "light"
);

/* 10 SECOND INTRO LOADING */

let progress = 0;

let bar = $("#loadingBar");

let loadingText = $("#loadingText");

let loader = setInterval(() => {

    progress += 1;

    bar.style.width = progress + "%";

    loadingText.textContent =
        `Loading your word world... ${progress}%`;

    if (progress >= 100) {

        clearInterval(loader);

        setTimeout(() => {
            show("home");
        }, 250);
    }

}, 100);
