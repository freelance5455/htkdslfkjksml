(() => {
  "use strict";
  const $ = id => document.getElementById(id);
  const GLYPHS = {w:{k:"♔",q:"♕",r:"♖",b:"♗",n:"♘",p:"♙"},b:{k:"♚",q:"♛",r:"♜",b:"♝",n:"♞",p:"♟"}};
  const VALUES = {p:100,n:320,b:335,r:500,q:900,k:20000};
  const TIPS = [
    "Kuasai bagian tengah papan dan kembangkan kuda serta gajah lebih awal.",
    "Sebelum bergerak, tanyakan: apakah bidak ini bisa ditangkap lawan?",
    "Rokade membantu mengamankan raja dan mengaktifkan benteng.",
    "Jangan buru-buru mengeluarkan ratu jika bidak lain belum berkembang.",
    "Cari ancaman lawan terlebih dahulu sebelum memilih langkahmu."
  ];
  let game = new Chess();
  let mode = "ai", selected = null, legalTargets = [], flipped = false, gameOverRecorded = false;
  let pendingPromotion = null, lastMove = null, hintMove = null, soundOn = false, timerId = null;
  let initialSeconds = 600, clocks = {w:600,b:600}, clockRunning = false, lastTick = Date.now();
  let stats = loadJSON("cmx_stats", {games:0,wins:0,losses:0,draws:0});
  let history = loadJSON("cmx_history", []);
  let completedGames = 0;

  function loadJSON(key, fallback){ try { const v=JSON.parse(localStorage.getItem(key)); return v ?? fallback; } catch { return fallback; } }
  function saveData(){ localStorage.setItem("cmx_stats", JSON.stringify(stats)); localStorage.setItem("cmx_history", JSON.stringify(history)); }
  function toast(message){ const el=$("toast"); el.textContent=message; el.classList.add("show"); clearTimeout(toast._timer); toast._timer=setTimeout(()=>el.classList.remove("show"),2200); }
  function beep(freq=440,duration=.07){ if(!soundOn)return; try{const C=window.AudioContext||window.webkitAudioContext;const ctx=new C();const osc=ctx.createOscillator();const gain=ctx.createGain();osc.frequency.value=freq;gain.gain.value=.04;osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+duration);osc.onended=()=>ctx.close();}catch{} }
  function currentTurn(){return game.turn();}
  function prettyTime(seconds){if(!Number.isFinite(seconds))return "∞";seconds=Math.max(0,seconds);return `${Math.floor(seconds/60).toString().padStart(2,"0")}:${Math.floor(seconds%60).toString().padStart(2,"0")}`;}
  function getPieceColor(piece){return piece ? piece.color : null;}
  function legalFor(square){return game.moves({square,verbose:true}).map(m=>m.to);}
  function renderBoard(){
    const board=$("board"); board.innerHTML="";
    const files=flipped?["h","g","f","e","d","c","b","a"]:["a","b","c","d","e","f","g","h"];
    const ranks=flipped?[1,2,3,4,5,6,7,8]:[8,7,6,5,4,3,2,1];
    const verbose=game.history({verbose:true}); lastMove=verbose.length?verbose[verbose.length-1]:null;
    for(const rank of ranks) for(let fi=0;fi<8;fi++){
      const file=files[fi], sq=file+rank, piece=game.get(sq);
      const btn=document.createElement("button"); btn.type="button"; btn.className="square "+(((file.charCodeAt(0)-97+rank)%2===0)?"light":"dark");
      btn.dataset.square=sq; btn.setAttribute("role","gridcell"); btn.setAttribute("aria-label",`${sq}${piece?`, ${piece.color==="w"?"putih":"hitam"} ${piece.type}`:" kosong"}`);
      if(selected===sq)btn.classList.add("selected");
      if(lastMove&&(lastMove.from===sq||lastMove.to===sq))btn.classList.add("last-move");
      if(piece){const span=document.createElement("span");span.className="piece "+(piece.color==="w"?"white":"black");span.textContent=GLYPHS[piece.color][piece.type];btn.appendChild(span);}
      if(legalTargets.includes(sq)){const marker=document.createElement("span");marker.className=piece?"capture-ring":"legal-dot";btn.appendChild(marker);}
      if(fi===0){const c=document.createElement("span");c.className="coord rank";c.textContent=rank;btn.appendChild(c);}
      if(rank===(flipped?1:1)){const c=document.createElement("span");c.className="coord file";c.textContent=file;btn.appendChild(c);}
      btn.addEventListener("click",()=>onSquareClick(sq)); board.appendChild(btn);
    }
    renderMoves(); updateStatus();
  }
  function onSquareClick(sq){
    if(game.isGameOver()||pendingPromotion|| (mode==="ai"&&game.turn()==="b"))return;
    const piece=game.get(sq);
    if(selected && legalTargets.includes(sq)){
      const moves=game.moves({square:selected,verbose:true}).filter(m=>m.to===sq);
      const promotion=moves.find(m=>m.promotion);
      if(promotion){pendingPromotion={from:selected,to:sq};$("promotionModal").classList.remove("hidden");return;}
      makeMove({from:selected,to:sq}); return;
    }
    if(piece&&piece.color===game.turn()){
      selected=sq;legalTargets=legalFor(sq);hintMove=null;renderBoard();
    }else{selected=null;legalTargets=[];renderBoard();}
  }
  function makeMove(move){
    let result;
    try{result=game.move(move);}catch{result=null;}
    if(!result){toast("Langkah tidak legal.");return;}
    selected=null;legalTargets=[];hintMove=null;beep(result.captured?260:480); renderBoard();
    if(game.isGameOver()){finishGame();return;}
    if(mode==="ai"&&game.turn()==="b"){ $("gameMessage").textContent="Komputer sedang berpikir…";setTimeout(makeAIMove,220);}
    else $("gameMessage").textContent=game.turn()==="w"?"Giliran Putih. Pilih langkahmu.":"Giliran Hitam. Pilih langkahmu.";
    lastTick=Date.now();
  }
  function updateStatus(){
    const turn=game.turn()==="w"?"Putih":"Hitam";
    $("playerState").textContent=game.isCheck()?"Skak! Raja sedang terancam.":`Giliran ${turn}`;
    if(game.isCheckmate())$("gameMessage").textContent=`Skakmat! ${turn==="Putih"?"Hitam":"Putih"} menang.`;
    else if(game.isDraw())$("gameMessage").textContent="Permainan seri.";
    else if(game.isCheck())$("gameMessage").textContent=`Skak! ${turn} harus menyelamatkan rajanya.`;
    else if(hintMove)$("gameMessage").textContent=`Petunjuk: ${hintMove.from} → ${hintMove.to}`;
  }
  function renderMoves(){
    const list=$("moveList"), hist=game.history();
    $("moveCount").textContent=`${hist.length} langkah`;
    if(!hist.length){list.innerHTML='<div class="empty-moves">Belum ada langkah.<br>Langkahmu akan muncul di sini.</div>';return;}
    list.innerHTML="";
    for(let i=0;i<hist.length;i+=2){
      const row=document.createElement("div");row.className="move-row";
      const n=document.createElement("span");n.className="move-number";n.textContent=`${Math.floor(i/2)+1}.`;
      const w=document.createElement("span");w.className="move-notation"+(i===hist.length-1?" latest":"");w.textContent=hist[i];
      const b=document.createElement("span");b.className="move-notation"+(i+1===hist.length-1?" latest":"");b.textContent=hist[i+1]||"";
      row.append(n,w,b);list.appendChild(row);
    }
    list.scrollTop=list.scrollHeight;
  }
  function evaluatePosition(){
    if(game.isCheckmate())return game.turn()==="w"?-999999:999999;
    if(game.isDraw())return 0;
    const board=game.board();let score=0;
    for(let r=0;r<8;r++)for(let c=0;c<8;c++){
      const p=board[r][c];if(!p)continue;
      let value=VALUES[p.type];
      // Mild center and development preference.
      const center=(3.5-Math.abs(3.5-c))+(3.5-Math.abs(3.5-r));
      if(p.type==="p")value+=center*3+(p.color==="w"?(6-r):(r-1))*2;
      if(["n","b"].includes(p.type))value+=center*5;
      if(p.type==="k"&&game.history().length<16)value-=center*3;
      score+=p.color==="w"?value:-value;
    }
    return score;
  }
  function minimax(depth, alpha, beta, maximizing){
    if(depth===0||game.isGameOver())return evaluatePosition();
    const moves=game.moves({verbose:true});
    moves.sort((a,b)=>((b.captured?VALUES[b.captured]:0)-(a.captured?VALUES[a.captured]:0))+(b.promotion?800:0)-(a.promotion?800:0));
    if(maximizing){
      let best=-Infinity;
      for(const m of moves){game.move(m);const val=minimax(depth-1,alpha,beta,false);game.undo();best=Math.max(best,val);alpha=Math.max(alpha,best);if(beta<=alpha)break;}
      return best;
    }else{
      let best=Infinity;
      for(const m of moves){game.move(m);const val=minimax(depth-1,alpha,beta,true);game.undo();best=Math.min(best,val);beta=Math.min(beta,best);if(beta<=alpha)break;}
      return best;
    }
  }
  function chooseAIMove(){
    const moves=game.moves({verbose:true});if(!moves.length)return null;
    const level=Number($("difficulty").value),depth=level===1?1:level===2?2:3;
    // Small randomness at beginner level; stronger levels prioritize evaluation.
    if(level===1&&Math.random()<.25)return moves[Math.floor(Math.random()*moves.length)];
    let best=-Infinity, choices=[];
    for(const m of moves){
      game.move(m);const score=minimax(depth-1,-Infinity,Infinity,true);game.undo();
      const aiScore=-score;
      if(aiScore>best){best=aiScore;choices=[m];}else if(aiScore===best)choices.push(m);
    }
    return choices[Math.floor(Math.random()*choices.length)];
  }
  function makeAIMove(){
    if(mode!=="ai"||game.turn()!=="b"||game.isGameOver())return;
    const move=chooseAIMove();if(move)makeMove({from:move.from,to:move.to,promotion:move.promotion||"q"});
  }
  function finishGame(reason){
    stopClock();
    if(gameOverRecorded)return;gameOverRecorded=true;
    const result=game.isCheckmate()?(game.turn()==="w"?"Hitam":"Putih")+" menang": "Seri";
    let outcome="draw";
    if(game.isCheckmate()){
      const winner=game.turn()==="w"?"b":"w";
      outcome=(mode==="local"?(winner==="w"?"win":"loss"):(winner==="w"?"win":"loss"));
      if(mode==="ai"&&winner==="b")outcome="loss";
    } else if(clocks.w<=0||clocks.b<=0){outcome=mode==="ai"?(clocks.w<=0?"loss":"win"):(clocks.w<=0?"loss":"win");}
    if(outcome==="win")stats.wins++;else if(outcome==="loss")stats.losses++;else stats.draws++;
    stats.games++;
    history.unshift({date:new Date().toLocaleString("id-ID",{dateStyle:"short",timeStyle:"short"}),mode:mode==="ai"?"Lawan AI":"2 Pemain",result:reason||result,outcome,moves:game.history().length});
    history=history.slice(0,30);saveData();updateStats();toast(reason||result);$("gameMessage").textContent=reason||result;beep(660,.15);
  }
  function startClock(){
    stopClock();clockRunning=initialSeconds>0;lastTick=Date.now();if(!clockRunning){updateTimers();return;}
    timerId=setInterval(()=>{
      if(!clockRunning||game.isGameOver())return;
      const now=Date.now(),elapsed=(now-lastTick)/1000;lastTick=now;
      const side=game.turn();clocks[side]-=elapsed;
      if(clocks[side]<=0){clocks[side]=0;updateTimers();clockRunning=false;finishGame(`${side==="w"?"Putih":"Hitam"} kehabisan waktu.`);return;}
      updateTimers();
    },250);
  }
  function stopClock(){if(timerId)clearInterval(timerId);timerId=null;clockRunning=false;}
  function updateTimers(){
    $("playerTimer").textContent=initialSeconds===0?"∞":prettyTime(clocks.w);
    $("playerTimer").classList.toggle("low",clocks.w<30&&initialSeconds>0);
    // Opponent time is shown in its rating chip.
    $("opponentRating").textContent=initialSeconds===0?"∞":prettyTime(clocks.b);
  }
  function newGame(){
    stopClock();game=new Chess();selected=null;legalTargets=[];pendingPromotion=null;hintMove=null;gameOverRecorded=false;
    initialSeconds=Number($("timeControl").value);clocks={w:initialSeconds,b:initialSeconds};
    $("opponentName").textContent=mode==="ai"?"Komputer":"Pemain Hitam";
    $("opponentSub").textContent=mode==="ai"?`AI · ${$("difficulty").selectedOptions[0].text}`:"2 pemain · lokal";
    $("opponentAvatar").textContent=mode==="ai"?"♟":"♚";
    $("opponentRating").textContent=initialSeconds===0?"∞":prettyTime(clocks.b);
    $("gameMessage").textContent="Pilih bidak untuk melihat langkah legal.";
    $("promotionModal").classList.add("hidden");renderBoard();startClock();
    if(mode==="ai"&&game.turn()==="b")setTimeout(makeAIMove,200);
  }
  function showHint(){
    if(game.isGameOver()||(mode==="ai"&&game.turn()==="b"))return;
    const moves=game.moves({verbose:true});if(!moves.length)return;
    // Prefer a capture, check, or center/development move; otherwise pick a legal move.
    const ranked=moves.map(m=>({m,score:(m.captured?VALUES[m.captured]:0)+(m.san.includes("+")?70:0)+(m.san.includes("#")?10000:0)+(["d4","e4","d5","e5"].includes(m.to)?20:0)+(m.promotion?800:0)})).sort((a,b)=>b.score-a.score);
    const best=ranked[0].m;selected=best.from;legalTargets=[best.to];hintMove=best;renderBoard();toast(`Coba ${best.from} ke ${best.to}`);beep(600);
  }
  function updateStats(){
    $("statGames").textContent=stats.games;$("statWins").textContent=stats.wins;$("statLosses").textContent=stats.losses;$("statDraws").textContent=stats.draws;
    const list=$("historyList");
    if(!history.length){list.textContent="Belum ada pertandingan selesai.";return;}
    list.innerHTML="";
    history.slice(0,12).forEach(item=>{
      const row=document.createElement("div");row.className="history-row";
      const info=document.createElement("div");info.innerHTML=`<strong>${escapeHTML(item.mode)}</strong><div style="font-size:10px;color:#71839b;margin-top:4px">${escapeHTML(item.date)} · ${item.moves} langkah</div>`;
      const result=document.createElement("span");result.className="history-result "+(item.outcome==="loss"?"loss":item.outcome==="draw"?"draw":"");result.textContent=item.result;
      row.append(info,result);list.appendChild(row);
    });
  }
  function escapeHTML(str){return String(str).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
  function showPanel(panel){
    ["play","stats","learn"].forEach(p=>$(p+"Panel").classList.toggle("hidden",p!==panel));
    document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.panel===panel));
    $("pageTitle").textContent=panel==="play"?"Siap bertanding?":panel==="stats"?"Performa permainanmu":"Belajar jadi lebih kuat";
    if(panel==="stats")updateStats();
  }
  document.querySelectorAll(".nav-item").forEach(b=>b.addEventListener("click",()=>showPanel(b.dataset.panel)));
  document.querySelectorAll(".segment").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".segment").forEach(x=>x.classList.toggle("active",x===b));mode=b.dataset.mode;newGame();}));
  $("difficulty").addEventListener("change",()=>{if(mode==="ai"){$("opponentSub").textContent=`AI · ${$("difficulty").selectedOptions[0].text}`;}});
  $("timeControl").addEventListener("change",()=>newGame());
  $("startBtn").addEventListener("click",()=>{newGame();toast("Pertandingan baru dimulai.");});
  $("newGameBtn").addEventListener("click",()=>{newGame();toast("Papan diatur ulang.");});
  $("undoBtn").addEventListener("click",()=>{
    if(!game.history().length){toast("Belum ada langkah untuk dibatalkan.");return;}
    game.undo();if(mode==="ai"&&game.turn()==="b"&&game.history().length)game.undo();
    selected=null;legalTargets=[];hintMove=null;gameOverRecorded=false;renderBoard();startClock();toast("Langkah terakhir dibatalkan.");
  });
  $("hintBtn").addEventListener("click",showHint);
  $("flipBtn").addEventListener("click",()=>{flipped=!flipped;renderBoard();});
  $("soundBtn").addEventListener("click",()=>{soundOn=!soundOn;$("soundBtn").style.color=soundOn?"#59c7a1":"#e7c36f";toast(soundOn?"Suara aktif":"Suara nonaktif");beep();});
  $("copyMovesBtn").addEventListener("click",async()=>{
    const pgn=game.pgn();if(!pgn){toast("Belum ada langkah untuk disalin.");return;}
    try{await navigator.clipboard.writeText(pgn);toast("PGN berhasil disalin.");}catch{toast(pgn);}
  });
  $("clearHistoryBtn").addEventListener("click",()=>{if(confirm("Hapus seluruh riwayat pertandingan?")){history=[];stats={games:0,wins:0,losses:0,draws:0};saveData();updateStats();toast("Riwayat dihapus.");}});
  document.querySelectorAll("[data-promotion]").forEach(b=>b.addEventListener("click",()=>{
    if(!pendingPromotion)return;const {from,to}=pendingPromotion,promotion=b.dataset.promotion;
    $("promotionModal").classList.add("hidden");pendingPromotion=null;makeMove({from,to,promotion});
  }));
  $("promotionModal").addEventListener("click",e=>{if(e.target===$("promotionModal")){$("promotionModal").classList.add("hidden");pendingPromotion=null;}});
  $("tipText").textContent=TIPS[Math.floor(Math.random()*TIPS.length)];
  updateStats();newGame();
})();