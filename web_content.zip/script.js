(() => {
'use strict';
const canvas=document.getElementById('world'),ctx=canvas.getContext('2d');
const $=id=>document.getElementById(id);
const screens=['intro','menu','settings','story','pause','ending'];
const hideScreens=()=>screens.forEach(id=>$(id).classList.add('hidden'));
const chapters=[
 {name:'அத்தியாயம் 1 – மழை இரவு',title:'வீட்டை விட்டு வெளியே',text:'சென்னையில் பெய்த மழை இரவில், மிலோ தவறுதலாக வீட்டை விட்டு வெளியேறிவிட்டது. மழையிலிருந்து பாதுகாப்பான இடத்தைத் தேடி, பழக்கமில்லாத தெருவை ஆராய்க.',mission:'அருகிலுள்ள தங்குமிடத்தைத் தேடுக',hint:'தெருவிளக்கின் அருகே உள்ள தங்குமிடத்தை அடையவும்',target:{x:0,z:-18}},
 {name:'அத்தியாயம் 2 – தனிமையான தெருக்கள்',title:'புதிய நண்பன்',text:'தெருக்கள் அனைத்தும் புதிதாகத் தெரிகின்றன. வழியில் ஒரு நட்பான தெருநாய் மிலோவைச் சந்திக்கிறது. அது வீட்டை நோக்கிச் செல்ல ஒரு தடயத்தைக் காட்டுகிறது.',mission:'நட்பான நாயைச் சந்திக்கவும்',hint:'நாயை அணுகி செயல் பொத்தானை அழுத்தவும்',target:{x:16,z:-29}},
 {name:'அத்தியாயம் 3 – உணவைத் தேடும் பயணம்',title:'சந்தையின் வாசனை',text:'பசியால் சோர்ந்த மிலோ ஒரு சிறிய சந்தையை அடைகிறது. அங்கே கிடைக்கும் உணவும் மனிதர்களின் நினைவுகளும் வீட்டை நோக்கிய பாதையைத் திறக்கலாம்.',mission:'சந்தையில் உணவைத் தேடுக',hint:'சந்தைக் கடையின் அருகே உணவைப் பெறவும்',target:{x:-17,z:-43}},
 {name:'அத்தியாயம் 4 – ஆபத்தான நகரம்',title:'சாலையைக் கடக்க',text:'முன்னால் பரபரப்பான சாலை. வாகனங்கள் விரைந்து செல்கின்றன. பாதுகாப்பான இடைவெளியைத் தேர்ந்தெடுத்து மறுபுறம் செல்ல வேண்டும்.',mission:'பாதுகாப்பான கடப்பிடத்தை அடைக',hint:'சாலையின் மறுபுறம் உள்ள ஒளிரும் குறியீட்டை அடையவும்',target:{x:0,z:-59}},
 {name:'அத்தியாயம் 5 – உரிமையாளரின் நினைவுகள்',title:'அந்தப் புகைப்படம்',text:'ஒரு சுவரில் ஒட்டப்பட்டுள்ள காணாமல் போன பூனை அறிவிப்பு மிலோவின் கவனத்தை ஈர்க்கிறது. அதில் இருப்பது மிலோவின் புகைப்படம்!',mission:'காணாமல் போன பூனை அறிவிப்பைக் கண்டறிக',hint:'சுவரில் உள்ள அறிவிப்பை அணுகவும்',target:{x:17,z:-75}},
 {name:'அத்தியாயம் 6 – மீண்டும் வீடு',title:'அன்பின் குரல்',text:'தொலைவில் ஆதீராவின் குரல் கேட்கிறது. அது மிலோவின் வீட்டை நோக்கிய கடைசி அழைப்பு. அந்தக் குரலைப் பின்தொடர்ந்து ஓடுக.',mission:'ஆதீராவைச் சென்றடைக',hint:'வீட்டு வாசலில் ஆதீராவைச் சந்திக்கவும்',target:{x:0,z:-94}}
];
let W=innerWidth,H=innerHeight,dpr=1,player={x:0,z:0,y:0,vz:0},cameraOffset=0,move={x:0,y:0},running=false,playing=false,paused=false,chapter=0,complete=false,jumpV=0,toastTimer=0,sound=true,vibration=true,lastTime=0,elapsed=0;
let rain=[],traffic=[],audio=null;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
function resize(){W=innerWidth;H=innerHeight;dpr=Math.min(devicePixelRatio||1,1.7);canvas.width=W*dpr;canvas.height=H*dpr;canvas.style.width=W+'px';canvas.style.height=H+'px';ctx.setTransform(dpr,0,0,dpr,0,0);}
addEventListener('resize',resize);resize();
function toast(t){$('toast').textContent=t;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),2300);}
function intro(){setTimeout(()=>{if(!$('intro').classList.contains('hidden')){hideScreens();$('menu').classList.remove('hidden');}},2800);}
function showStory(i){chapter=i;complete=false;const c=chapters[i];$('chapterNumber').textContent=c.name;$('storyTitle').textContent=c.title;$('storyText').textContent=c.text;$('story').classList.remove('hidden');$('hud').classList.add('hidden');}
function startGame(){hideScreens();player={x:0,z:0,y:0,vz:0};chapter=0;localStorage.removeItem('lostCatSave');showStory(0);updateHud();}
function continueGame(){let s;try{s=JSON.parse(localStorage.getItem('lostCatSave'));}catch(e){}player={x:0,z:s?.z||0,y:0,vz:0};chapter=s?.chapter||0;hideScreens();$('hud').classList.remove('hidden');showStory(chapter);updateHud();}
function updateHud(){$('chapterName').textContent=chapters[chapter].name;$('missionText').textContent=chapters[chapter].mission;$('objective').textContent=chapters[chapter].hint;}
function beginChapter(){$('story').classList.add('hidden');$('hud').classList.remove('hidden');playing=true;paused=false;startAudio();}
function pauseGame(){if(!playing)return;playing=false;paused=true;$('pause').classList.remove('hidden');}
function resume(){paused=false;playing=true;$('pause').classList.add('hidden');}
function backMenu(){playing=false;paused=false;hideScreens();$('menu').classList.remove('hidden');}
function nextChapter(){if(complete)return;complete=true;const next=chapter+1;localStorage.setItem('lostCatSave',JSON.stringify({chapter:Math.min(next,5),z:player.z}));toast('புதிய தடயம் கிடைத்தது!');if(chapter===5){setTimeout(()=>{$('hud').classList.add('hidden');$('ending').classList.remove('hidden');playing=false;localStorage.removeItem('lostCatSave');},1300);}else setTimeout(()=>showStory(next),1100);}
function interact(){if(!playing)return;const t=chapters[chapter].target;const dist=Math.hypot(player.x-t.x,player.z-t.z);if(dist<5.3){nextChapter();if(vibration&&navigator.vibrate)navigator.vibrate(45);}else toast('ஒளிரும் குறியீட்டிற்கு இன்னும் அருகில் செல்லவும்.');}
function jump(){if(playing&&player.y<=0.01)jumpV=5.1;}
function startAudio(){if(!sound)return;try{if(!audio){audio=new(window.AudioContext||window.webkitAudioContext)();}if(audio.state==='suspended')audio.resume();}catch(e){}}
function toggleSound(){sound=!sound;toast(sound?'ஒலி இயக்கப்பட்டது':'ஒலி நிறுத்தப்பட்டது');}
function roundedRect(x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.stroke();}}
function drawBackground(){
 const sky=ctx.createLinearGradient(0,0,0,H*.58);sky.addColorStop(0,'#101d2a');sky.addColorStop(.55,'#344a59');sky.addColorStop(1,'#c18a69');ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
 // distant skyline and warm windows
 for(let i=0;i<15;i++){let x=((i*137-cameraOffset*.15)%(W+160))-80,h=70+(i*47%120),y=H*.43-h;ctx.fillStyle=i%2?'#26343b':'#304047';ctx.fillRect(x,y,65,h);for(let yy=y+12;yy<H*.42;yy+=19)for(let xx=x+9;xx<x+60;xx+=17){ctx.fillStyle='rgba(255,196,125,.5)';ctx.fillRect(xx,yy,5,7);}}
 // horizon
 ctx.fillStyle='#26343b';ctx.fillRect(0,H*.43,W,H*.07);
 // side buildings with perspective
 for(let side=0;side<2;side++){for(let i=0;i<7;i++){let z=(i*95+(elapsed*13)%95),scale=.4+z/150,x=side?W*.78+z*.48:W*.22-z*.48,y=H*.43+z*.23,w=70+z*.55,h=130+z*.65;ctx.fillStyle=['#725b4c','#536a68','#8a705c'][i%3];ctx.fillRect(x-w/2,y-h,w,h);ctx.fillStyle='#343c3d';ctx.fillRect(x-w/2-3,y-h-5,w+6,7);for(let wy=y-h+18;wy<y-15;wy+=28)for(let wx=x-w/2+12;wx<x+w/2-8;wx+=23){ctx.fillStyle='rgba(255,195,120,.65)';ctx.fillRect(wx,wy,9,13);}}}
 // road perspective
 ctx.beginPath();ctx.moveTo(W*.22,H*.43);ctx.lineTo(W*.78,H*.43);ctx.lineTo(W*1.18,H);ctx.lineTo(-W*.18,H);ctx.closePath();ctx.fillStyle='#303a40';ctx.fill();
 // wet reflections
 for(let i=0;i<26;i++){let y=H*.48+(i*i/(26*26))*H*.55;let width=(y-H*.4)*.35;let x=(i*83+elapsed*18)%(W+80)-40;ctx.fillStyle=`rgba(145,177,190,${.04+(i%4)*.015})`;ctx.fillRect(x,y,width,2+i%3);}
 // road dashes
 for(let i=0;i<8;i++){let y=H*.48+i*i*5+(elapsed*30%35);let x=W/2;let len=3+i*3;ctx.fillStyle='rgba(226,207,164,.6)';ctx.fillRect(x-len/2,y,len,2+i);}
 // sidewalks
 ctx.fillStyle='#77766d';ctx.beginPath();ctx.moveTo(0,H*.55);ctx.lineTo(W*.22,H*.43);ctx.lineTo(W*.25,H*.43);ctx.lineTo(0,H);ctx.fill();ctx.beginPath();ctx.moveTo(W,H*.55);ctx.lineTo(W*.78,H*.43);ctx.lineTo(W*.75,H*.43);ctx.lineTo(W,H);ctx.fill();
 // lamps
 for(let i=0;i<5;i++){let y=H*.48+i*70,x=i%2?W*.13:W*.87;ctx.strokeStyle='#252e32';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,y-70-i*4);ctx.lineTo(x+(i%2?15:-15),y-70-i*4);ctx.stroke();ctx.fillStyle='rgba(255,202,132,.8)';ctx.beginPath();ctx.arc(x+(i%2?15:-15),y-70-i*4,5+i,0,Math.PI*2);ctx.fill();}
}
function worldToScreen(wx,wz){let depth=Math.max(0,12+(wz-player.z));let scale=clamp(1.5/(1+depth*.055),.15,1.45);let x=W/2+(wx-player.x)*scale*30;let y=H*.48+depth*scale*3.4;return{x,y,scale};}
function drawCat(x,y,s,angle=0){
 ctx.save();ctx.translate(x,y);ctx.scale(s,s);ctx.rotate(angle);
 // shadow
 ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.ellipse(0,8,29,9,0,0,Math.PI*2);ctx.fill();
 // tail
 ctx.strokeStyle='#b9a58d';ctx.lineWidth=8;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(19,-18);ctx.quadraticCurveTo(42,-38,34,-55+Math.sin(elapsed*4)*4);ctx.stroke();
 // body
 const fur=ctx.createLinearGradient(-25,-35,25,5);fur.addColorStop(0,'#e1d1b8');fur.addColorStop(1,'#927f69');ctx.fillStyle=fur;ctx.beginPath();ctx.ellipse(0,-18,28,18,-.12,0,Math.PI*2);ctx.fill();
 // head and ears
 ctx.fillStyle='#c6b49a';ctx.beginPath();ctx.arc(0,-44,18,0,Math.PI*2);ctx.fill();
 ctx.beginPath();ctx.moveTo(-14,-55);ctx.lineTo(-19,-77);ctx.lineTo(-3,-63);ctx.fill();ctx.beginPath();ctx.moveTo(5,-63);ctx.lineTo(19,-78);ctx.lineTo(15,-53);ctx.fill();
 ctx.fillStyle='#9d786c';ctx.beginPath();ctx.moveTo(-15,-59);ctx.lineTo(-16,-70);ctx.lineTo(-7,-62);ctx.fill();ctx.beginPath();ctx.moveTo(10,-62);ctx.lineTo(17,-71);ctx.lineTo(14,-58);ctx.fill();
 // face
 ctx.fillStyle='#26302d';ctx.beginPath();ctx.arc(-7,-46,2.2,0,Math.PI*2);ctx.arc(7,-46,2.2,0,Math.PI*2);ctx.fill();
 ctx.fillStyle='#b97879';ctx.beginPath();ctx.arc(0,-39,2.5,0,Math.PI*2);ctx.fill();
 // legs
 ctx.strokeStyle='#b9a58d';ctx.lineWidth=7;ctx.beginPath();let step=Math.sin(elapsed*12)*4;ctx.moveTo(-16,-8);ctx.lineTo(-18+step,2);ctx.moveTo(15,-8);ctx.lineTo(17-step,2);ctx.stroke();
 ctx.restore();
}
function drawDog(){let p=worldToScreen(16,-29);if(p.scale<.2)return;ctx.save();ctx.translate(p.x,p.y);ctx.scale(p.scale,p.scale);ctx.fillStyle='#98704d';ctx.beginPath();ctx.ellipse(0,-18,25,15,0,0,7);ctx.fill();ctx.beginPath();ctx.arc(0,-43,15,0,7);ctx.fill();ctx.fillStyle='#49352a';ctx.beginPath();ctx.ellipse(-12,-54,5,12,-.3,0,7);ctx.ellipse(12,-54,5,12,.3,0,7);ctx.fill();ctx.restore();}
function drawMarket(){for(let i=0;i<4;i++){let p=worldToScreen(i%2?-17:17,-43-i*2);if(p.scale<.18)continue;ctx.save();ctx.translate(p.x,p.y);ctx.scale(p.scale,p.scale);ctx.fillStyle='#78543d';ctx.fillRect(-37,-62,74,62);ctx.fillStyle=i%2?'#a34c40':'#3e7973';ctx.fillRect(-43,-72,86,13);ctx.fillStyle='#d6b77f';ctx.fillRect(-31,-25,62,6);ctx.restore();}}
function drawTarget(){let t=chapters[chapter].target,p=worldToScreen(t.x,t.z);let pulse=1+Math.sin(elapsed*3)*.12;ctx.save();ctx.translate(p.x,p.y);ctx.scale(p.scale*pulse,p.scale*pulse);ctx.strokeStyle='#ffd18b';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(0,0,25,9,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle='rgba(255,209,139,.22)';ctx.beginPath();ctx.moveTo(-15,-3);ctx.lineTo(0,-95);ctx.lineTo(15,-3);ctx.fill();ctx.restore();}
function drawRain(dt){ctx.strokeStyle='rgba(177,211,231,.45)';ctx.lineWidth=1;for(let i=0;i<95;i++){let x=(i*97+elapsed*145)%(W+80)-40,y=(i*53+elapsed*270)%(H+80)-40;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-5,y+13);ctx.stroke();}}
function render(dt){elapsed+=dt;drawBackground();drawMarket();drawDog();drawTarget();let px=W/2+(player.x*.8),py=H*.82-player.y*55;drawCat(px,py,clamp(Math.min(W,H)/650,.55,1.15),Math.sin(move.x)*.08);drawRain(dt);
 // headlight / soft glow and cinematic rain glints
 const g=ctx.createRadialGradient(W*.5,H*.82,5,W*.5,H*.82,Math.max(W,H)*.55);g.addColorStop(0,'rgba(255,213,159,.06)');g.addColorStop(1,'rgba(0,0,0,.28)');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
}
function update(dt){if(!playing||paused)return;let speed=running?12:6;player.x+=move.x*speed*dt;player.z+=move.y*speed*dt;player.x=clamp(player.x,-23,23);player.z=clamp(player.z,-105,7);jumpV-=13*dt;player.y=Math.max(0,player.y+jumpV*dt);if(player.y===0)jumpV=0;
 const t=chapters[chapter].target,dist=Math.hypot(player.x-t.x,player.z-t.z);$('objective').textContent=dist<6?'செயல் பொத்தானை அழுத்தவும்':chapters[chapter].hint;
}
function loop(now){let dt=Math.min((now-lastTime)/1000||0,.04);lastTime=now;update(dt);render(dt);requestAnimationFrame(loop);}
function bindControls(){
 const joy=$('joystick'),stick=$('stick');let joyId=null;
 function joyMove(e){const r=joy.getBoundingClientRect(),dx=e.clientX-r.left-r.width/2,dy=e.clientY-r.top-r.height/2,len=Math.hypot(dx,dy),max=37,k=len>max?max/len:1;move.x=dx*k/max;move.y=-dy*k/max;stick.style.transform=`translate(${dx*k}px,${dy*k}px)`;}
 joy.addEventListener('pointerdown',e=>{joyId=e.pointerId;joy.setPointerCapture(e.pointerId);joyMove(e);});
 joy.addEventListener('pointermove',e=>{if(e.pointerId===joyId)joyMove(e);});
 function release(){joyId=null;move={x:0,y:0};stick.style.transform='translate(0,0)';}
 ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>joy.addEventListener(ev,release));
 let lookLast=null;$('lookPad').addEventListener('pointerdown',e=>{lookLast=e.clientX;});$('lookPad').addEventListener('pointermove',e=>{if(lookLast!==null){cameraOffset+=e.clientX-lookLast;lookLast=e.clientX;}});['pointerup','pointercancel','pointerleave'].forEach(ev=>$('lookPad').addEventListener(ev,()=>lookLast=null));
 $('interact').onclick=interact;$('jump').onclick=jump;
 $('run').addEventListener('pointerdown',()=>{running=true;$('run').classList.add('active');});['pointerup','pointercancel','pointerleave'].forEach(ev=>$('run').addEventListener(ev,()=>{running=false;$('run').classList.remove('active');}));
 addEventListener('keydown',e=>{if(e.key==='Escape')pauseGame();if(e.key==='e')interact();if(e.key==='ArrowLeft'||e.key==='a')move.x=-1;if(e.key==='ArrowRight'||e.key==='d')move.x=1;if(e.key==='ArrowUp'||e.key==='w')move.y=1;if(e.key==='ArrowDown'||e.key==='s')move.y=-1;if(e.key==='Shift')running=true;});
 addEventListener('keyup',e=>{if(['ArrowLeft','ArrowRight','a','d'].includes(e.key))move.x=0;if(['ArrowUp','ArrowDown','w','s'].includes(e.key))move.y=0;if(e.key==='Shift')running=false;});
}
$('newGame').onclick=startGame;$('continueGame').onclick=continueGame;$('settingsButton').onclick=()=>{hideScreens();$('settings').classList.remove('hidden');};$('settingsBack').onclick=backMenu;
$('exitButton').onclick=()=>toast('இந்த விளையாட்டை மூட உலாவியைப் பயன்படுத்தவும்.');
$('storyContinue').onclick=beginChapter;$('pauseButton').onclick=pauseGame;$('resume').onclick=resume;$('restart').onclick=startGame;$('pauseSound').onclick=toggleSound;$('mainMenu').onclick=backMenu;$('endingMenu').onclick=backMenu;
$('soundToggle').onchange=e=>sound=e.target.checked;$('vibrationToggle').onchange=e=>vibration=e.target.checked;
bindControls();
setTimeout(()=>{$('loading').classList.add('hidden');$('intro').classList.remove('hidden');intro();},500);
requestAnimationFrame(loop);
})();