(() => {
  "use strict";
  const STORAGE_KEY = "celengku_data_v1";
  const $ = (id) => document.getElementById(id);
  const today = () => new Date().toISOString().slice(0, 10);
  const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  const rupiah = (value) => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(Number(value) || 0);
  const dateLabel = (value) => {
    if (!value) return "Tanpa tenggat";
    const d = new Date(`${value}T00:00:00`);
    return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
  };
  const escapeHTML = (value) => String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
  const initialState = () => ({
    version: 1, jars: [], transactions: [], pin: "", missions: { date: today(), saved: false, reviewed: false },
    createdAt: new Date().toISOString(), lastSavedDay: "", savingDays: 0, achievementsSeen: []
  });
  let state = loadState();
  let toastTimer;
  let activePage = "dashboard";

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return initialState();
      const parsed = JSON.parse(raw);
      if (!parsed || !Array.isArray(parsed.jars) || !Array.isArray(parsed.transactions)) return initialState();
      return { ...initialState(), ...parsed, missions: { ...initialState().missions, ...(parsed.missions || {}) } };
    } catch (error) {
      console.error("Gagal membaca data:", error);
      return initialState();
    }
  }
  function saveState() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      return true;
    } catch (error) {
      console.error("Gagal menyimpan data:", error);
      showToast("Penyimpanan gagal. Ruang perangkat mungkin penuh.");
      return false;
    }
  }
  function showToast(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
  }
  function getJarBalance(jarId) {
    return state.transactions.reduce((sum, tx) => tx.jarId === jarId ? sum + (tx.type === "in" ? Number(tx.amount) : -Number(tx.amount)) : sum, 0);
  }
  function getTotals() {
    const income = state.transactions.filter(t => t.type === "in").reduce((s,t) => s + Number(t.amount), 0);
    const expense = state.transactions.filter(t => t.type === "out").reduce((s,t) => s + Number(t.amount), 0);
    return { income, expense, balance: income - expense };
  }
  function jarProgress(jar) {
    const target = Math.max(1, Number(jar.target) || 1);
    return Math.min(100, Math.max(0, Math.round(getJarBalance(jar.id) / target * 100)));
  }
  function navigate(page) {
    activePage = page;
    document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === `page-${page}`));
    document.querySelectorAll("[data-page]").forEach(b => b.classList.toggle("active", b.dataset.page === page));
    const titles = { dashboard: "Dashboard", jars: "Celengan", transactions: "Transaksi", missions: "Misi & Pencapaian", settings: "Pengaturan" };
    $("pageTitle").textContent = titles[page] || "CelengKu";
    renderAll();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function renderJarRow(jar) {
    const balance = getJarBalance(jar.id), progress = jarProgress(jar);
    return `<div class="jar-row"><div class="jar-emoji">${escapeHTML(jar.icon || "🎯")}</div><div class="jar-main"><div class="jar-title-line"><strong>${escapeHTML(jar.name)}</strong><span class="percent">${progress}%</span></div><div class="progress-track"><div class="progress-fill" style="width:${progress}%"></div></div><div class="jar-meta"><span>${rupiah(balance)} terkumpul</span><span>Target ${rupiah(jar.target)}</span></div></div></div>`;
  }
  function renderJarCard(jar) {
    const balance = getJarBalance(jar.id), progress = jarProgress(jar);
    const remaining = Math.max(0, Number(jar.target) - balance);
    return `<article class="jar-card"><div class="jar-card-top"><div class="jar-card-icon">${escapeHTML(jar.icon || "🎯")}</div><span class="percent">${progress}%</span></div><h3>${escapeHTML(jar.name)}</h3><div class="muted">${jar.deadline ? `Target tanggal ${dateLabel(jar.deadline)}` : "Tidak ada tenggat"}</div><div class="jar-saved">${rupiah(balance)}</div><div class="jar-target">dari ${rupiah(jar.target)}</div><div class="progress-track"><div class="progress-fill" style="width:${progress}%"></div></div><div class="jar-card-footer"><span class="muted">${remaining ? `Kurang ${rupiah(remaining)}` : "🎉 Target tercapai!"}</span><div class="jar-actions"><button class="mini-btn" data-action="add-money" data-id="${escapeHTML(jar.id)}">＋ Uang</button><button class="mini-btn" data-action="edit-jar" data-id="${escapeHTML(jar.id)}">Edit</button><button class="mini-btn delete" data-action="delete-jar" data-id="${escapeHTML(jar.id)}">Hapus</button></div></div></article>`;
  }
  function renderTransaction(tx) {
    const jar = state.jars.find(j => j.id === tx.jarId);
    const isIn = tx.type === "in";
    return `<div class="transaction-item"><div class="tx-icon ${isIn ? "in" : "out"}">${isIn ? "↙" : "↗"}</div><div class="tx-info"><strong>${escapeHTML(tx.note || (isIn ? "Menabung" : "Mengambil uang"))}</strong><small>${escapeHTML(jar ? jar.name : "Celengan dihapus")} • ${dateLabel(tx.date)}</small></div><div class="tx-amount ${isIn ? "in" : "out"}">${isIn ? "+" : "−"}${rupiah(tx.amount)}</div></div>`;
  }
  function renderTransactions(target, list) {
    $(target).innerHTML = list.length ? `<div class="transaction-list">${list.map(renderTransaction).join("")}</div>` : `<div class="empty-inline">Belum ada transaksi untuk ditampilkan.</div>`;
  }
  function renderChart() {
    const canvas = $("weeklyChart");
    if (!canvas || !canvas.offsetParent) return;
    const rect = canvas.getBoundingClientRect();
    const width = Math.max(260, rect.width), height = Math.max(150, rect.height);
    const dpr = window.devicePixelRatio || 1;
    canvas.width = width * dpr; canvas.height = height * dpr;
    const ctx = canvas.getContext("2d");
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, width, height);
    const days = [];
    for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(d); }
    const values = days.map(d => {
      const key = d.toISOString().slice(0,10);
      return {
        label: d.toLocaleDateString("id-ID", { weekday: "short" }).slice(0,3),
        in: state.transactions.filter(t => t.date === key && t.type === "in").reduce((s,t)=>s+Number(t.amount),0),
        out: state.transactions.filter(t => t.date === key && t.type === "out").reduce((s,t)=>s+Number(t.amount),0)
      };
    });
    const max = Math.max(1, ...values.flatMap(v => [v.in, v.out]));
    const pad = { left: 8, right: 8, top: 12, bottom: 25 };
    const plotH = height - pad.top - pad.bottom, plotW = width - pad.left - pad.right;
    ctx.strokeStyle = "#edf1f7"; ctx.lineWidth = 1;
    for (let i=0;i<4;i++){const y=pad.top+plotH*i/3;ctx.beginPath();ctx.moveTo(pad.left,y);ctx.lineTo(width-pad.right,y);ctx.stroke();}
    const groupW = plotW / 7, barW = Math.min(13, groupW * .25);
    values.forEach((v,i)=>{
      const center = pad.left + groupW*i + groupW/2;
      const hIn = v.in/max*(plotH*.85), hOut = v.out/max*(plotH*.85);
      ctx.fillStyle="#3478f6"; ctx.beginPath(); ctx.roundRect(center-barW-2,pad.top+plotH-hIn,barW,hIn,3); ctx.fill();
      ctx.fillStyle="#e46d89"; ctx.beginPath(); ctx.roundRect(center+2,pad.top+plotH-hOut,barW,hOut,3); ctx.fill();
      ctx.fillStyle="#8290a6"; ctx.font="10px Inter, sans-serif"; ctx.textAlign="center"; ctx.fillText(v.label,center,height-7);
    });
  }
  function getAchievements() {
    const totalIn = getTotals().income;
    const txCount = state.transactions.length;
    const jarsWithMoney = state.jars.filter(j => getJarBalance(j.id) > 0).length;
    const targetCount = state.jars.filter(j => getJarBalance(j.id) >= Number(j.target)).length;
    return [
      { id:"first-save", icon:"🌱", name:"Langkah pertama", desc:"Catat transaksi pertama", unlocked: state.transactions.some(t=>t.type==="in") },
      { id:"five-tx", icon:"🧾", name:"Rajin mencatat", desc:"Buat 5 transaksi", unlocked: txCount >= 5 },
      { id:"three-jars", icon:"🏺", name:"Punya rencana", desc:"Buat 3 celengan", unlocked: state.jars.length >= 3 },
      { id:"one-hundred", icon:"💵", name:"Seratus ribu", desc:"Uang masuk mencapai Rp100.000", unlocked: totalIn >= 100000 },
      { id:"first-goal", icon:"🎯", name:"Target tercapai", desc:"Selesaikan satu target", unlocked: targetCount >= 1 },
      { id:"all-active", icon:"✨", name:"Mulai konsisten", desc:"Isi 2 celengan berbeda", unlocked: jarsWithMoney >= 2 }
    ];
  }
  function updateMissions() {
    if (state.missions.date !== today()) state.missions = { date: today(), saved: false, reviewed: false };
    const todayTx = state.transactions.filter(t=>t.date===today());
    const saved = todayTx.some(t=>t.type==="in");
    const reviewed = todayTx.length > 0;
    state.missions.saved = saved;
    state.missions.reviewed = reviewed;
    saveState();
    return [
      { id:"save", title:"Sisihkan uang hari ini", desc:"Catat setidaknya satu transaksi uang masuk hari ini.", done:saved, reward:"+1 misi" },
      { id:"record", title:"Catat aktivitas tabungan", desc:"Buat transaksi apa pun agar catatanmu tetap rapi.", done:reviewed, reward:"+1 misi" }
    ];
  }
  function renderMissions() {
    const missions = updateMissions();
    $("dailyMissions").innerHTML = missions.map(m=>`<div class="mission-item ${m.done?"done":""}"><div class="mission-check">${m.done?"✓":"○"}</div><div class="mission-copy"><strong>${m.title}</strong><small>${m.desc}</small></div><span class="mission-reward">${m.done?"Selesai":m.reward}</span></div>`).join("");
    const achievements = getAchievements();
    $("achievements").innerHTML = achievements.map(a=>`<div class="achievement ${a.unlocked?"":"locked"}"><div class="achievement-icon">${a.icon}</div><strong>${a.name}</strong><small>${a.unlocked?"Terbuka":a.desc}</small></div>`).join("");
    $("achievementCount").textContent = `${achievements.filter(a=>a.unlocked).length}/${achievements.length}`;
    $("missionCount").textContent = `${missions.filter(m=>m.done).length}/2`;
    $("savingDays").textContent = new Set(state.transactions.filter(t=>t.type==="in").map(t=>t.date)).size;
  }
  function renderAll() {
    const totals = getTotals();
    $("totalBalance").textContent = rupiah(totals.balance);
    $("totalIncome").textContent = rupiah(totals.income);
    $("totalExpense").textContent = rupiah(totals.expense);
    $("jarCount").textContent = state.jars.length;
    $("dashboardJars").innerHTML = state.jars.length ? state.jars.slice(0,4).map(renderJarRow).join("") : `<div class="empty-inline">Belum ada celengan. <button class="text-button" data-action="add-jar">Buat sekarang →</button></div>`;
    $("allJars").innerHTML = state.jars.map(renderJarCard).join("");
    $("emptyJars").classList.toggle("hidden", state.jars.length > 0);
    renderTransactions("recentTransactions", [...state.transactions].sort((a,b)=>(b.createdAt||b.date).localeCompare(a.createdAt||a.date)).slice(0,5));
    const query = ($("transactionSearch")?.value || "").toLowerCase().trim();
    const filter = $("transactionFilter")?.value || "all";
    const txs = [...state.transactions].sort((a,b)=>(b.createdAt||b.date).localeCompare(a.createdAt||a.date)).filter(tx=>{
      const jar = state.jars.find(j=>j.id===tx.jarId);
      const matchesText = `${tx.note||""} ${jar?.name||""}`.toLowerCase().includes(query);
      return matchesText && (filter==="all" || tx.type===filter);
    });
    renderTransactions("allTransactions", txs);
    renderMissions();
    requestAnimationFrame(renderChart);
    const select = $("transactionJar");
    const previous = select.value;
    select.innerHTML = state.jars.map(j=>`<option value="${escapeHTML(j.id)}">${escapeHTML(j.icon||"🎯")} ${escapeHTML(j.name)}</option>`).join("");
    if (state.jars.some(j=>j.id===previous)) select.value = previous;
    else if (state.jars[0]) select.value = state.jars[0].id;
    $("addTransactionButton").disabled = state.jars.length === 0;
    $("addTransactionButton").title = state.jars.length ? "" : "Buat celengan terlebih dahulu";
  }
  function openJarDialog(jar = null) {
    $("jarForm").reset();
    $("jarId").value = jar?.id || "";
    $("jarDialogTitle").textContent = jar ? "Edit celengan" : "Buat celengan";
    $("jarName").value = jar?.name || "";
    $("jarTarget").value = jar?.target || "";
    $("jarDeadline").value = jar?.deadline || "";
    $("jarIcon").value = jar?.icon || "🎯";
    $("jarDialog").showModal();
  }
  function openTransactionDialog(type = "in", jarId = "") {
    if (!state.jars.length) { showToast("Buat celengan terlebih dahulu."); navigate("jars"); return; }
    $("transactionForm").reset();
    $("transactionType").value = type;
    $("transactionDate").value = today();
    $("transactionJar").value = jarId || state.jars[0].id;
    $("transactionDialog").showModal();
  }
  function saveJar(event) {
    event.preventDefault();
    const id = $("jarId").value;
    const name = $("jarName").value.trim();
    const target = Number($("jarTarget").value);
    if (!name || !Number.isFinite(target) || target <= 0) { showToast("Isi nama dan target yang valid."); return; }
    const existing = state.jars.find(j=>j.id===id);
    const jar = { id: id || uid(), name, target, deadline: $("jarDeadline").value, icon: $("jarIcon").value, createdAt: existing?.createdAt || new Date().toISOString() };
    if (existing) state.jars = state.jars.map(j=>j.id===id ? jar : j);
    else state.jars.unshift(jar);
    if (saveState()) { $("jarDialog").close(); renderAll(); showToast(existing ? "Celengan diperbarui." : "Celengan berhasil dibuat."); }
  }
  function saveTransaction(event) {
    event.preventDefault();
    const jarId = $("transactionJar").value;
    const type = $("transactionType").value;
    const amount = Number($("transactionAmount").value);
    const date = $("transactionDate").value;
    if (!state.jars.some(j=>j.id===jarId)) { showToast("Pilih celengan yang tersedia."); return; }
    if (!Number.isSafeInteger(amount) || amount <= 0) { showToast("Nominal harus berupa angka bulat lebih dari nol."); return; }
    if (!date) { showToast("Pilih tanggal transaksi."); return; }
    const balance = getJarBalance(jarId);
    if (type === "out" && amount > balance) { showToast(`Saldo celengan hanya ${rupiah(balance)}.`); return; }
    state.transactions.push({ id:uid(), jarId, type, amount, date, note:$("transactionNote").value.trim(), createdAt:new Date().toISOString() });
    if (type === "in" && date === today() && state.lastSavedDay !== today()) {
      state.lastSavedDay = today();
      state.savingDays = (Number(state.savingDays)||0) + 1;
    }
    if (saveState()) { $("transactionDialog").close(); renderAll(); showToast("Transaksi berhasil dicatat."); }
  }
  function deleteJar(id) {
    const jar = state.jars.find(j=>j.id===id);
    if (!jar) return;
    const hasTx = state.transactions.some(t=>t.jarId===id);
    const message = hasTx ? `Hapus "${jar.name}" beserta semua transaksi terkait?` : `Hapus celengan "${jar.name}"?`;
    if (!confirm(message)) return;
    state.jars = state.jars.filter(j=>j.id!==id);
    state.transactions = state.transactions.filter(t=>t.jarId!==id);
    saveState(); renderAll(); showToast("Celengan dihapus.");
  }
  function exportBackup() {
    const backup = { app:"CelengKu", exportedAt:new Date().toISOString(), data:state };
    const blob = new Blob([JSON.stringify(backup,null,2)], {type:"application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href=url; a.download=`celengku-backup-${today()}.json`; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1000);
    showToast("File backup dibuat. Periksa folder unduhan.");
  }
  async function importBackup(file) {
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      const incoming = parsed?.app === "CelengKu" ? parsed.data : parsed;
      if (!incoming || !Array.isArray(incoming.jars) || !Array.isArray(incoming.transactions)) throw new Error("Format file tidak cocok.");
      const jarIds = new Set(incoming.jars.map(j=>j.id));
      const validTx = incoming.transactions.every(t=>t && t.id && jarIds.has(t.jarId) && ["in","out"].includes(t.type) && Number(t.amount)>0);
      if (!validTx) throw new Error("Data transaksi di file tidak valid.");
      if (!confirm("Pulihkan backup? Data CelengKu saat ini akan diganti.")) return;
      state = { ...initialState(), ...incoming, missions:{...initialState().missions,...(incoming.missions||{})} };
      saveState(); renderAll(); showToast("Backup berhasil dipulihkan.");
    } catch (error) {
      showToast(error.message || "File backup tidak dapat dibaca.");
    } finally {
      $("importFile").value = "";
    }
  }
  function setupPin() {
    $("pinForm").addEventListener("submit", event=>{
      event.preventDefault();
      const pin = $("newPin").value, confirmPin = $("confirmPin").value;
      if (!/^\d{4,8}$/.test(pin)) { showToast("PIN harus terdiri dari 4–8 angka."); return; }
      if (pin !== confirmPin) { showToast("PIN yang dimasukkan belum sama."); return; }
      state.pin = pin;
      if (saveState()) { $("pinForm").reset(); showToast("PIN berhasil disimpan."); }
    });
    $("removePinButton").addEventListener("click", ()=>{
      if (!state.pin) { showToast("Belum ada PIN yang disetel."); return; }
      if (!confirm("Hapus PIN aplikasi?")) return;
      state.pin = ""; saveState(); showToast("PIN dihapus.");
    });
    $("lockButton").addEventListener("click", ()=>{
      if (!state.pin) { showToast("Atur PIN terlebih dahulu di Pengaturan."); navigate("settings"); return; }
      lockApp();
    });
    $("unlockForm").addEventListener("submit", event=>{
      event.preventDefault();
      if ($("unlockPin").value === state.pin) {
        $("lockScreen").classList.add("hidden"); $("appShell").classList.remove("hidden"); $("unlockPin").value=""; $("unlockError").textContent="";
      } else { $("unlockError").textContent="PIN salah. Coba lagi."; $("unlockPin").value=""; }
    });
  }
  function lockApp() {
    $("appShell").classList.add("hidden");
    $("lockScreen").classList.remove("hidden");
    $("unlockPin").value = "";
    $("lockMessage").textContent = "Masukkan PIN untuk membuka aplikasi";
    $("unlockPin").focus();
  }
  function bindEvents() {
    document.addEventListener("click", event=>{
      const pageButton = event.target.closest("[data-page]");
      if (pageButton) { navigate(pageButton.dataset.page); return; }
      const go = event.target.closest("[data-go]");
      if (go) { navigate(go.dataset.go); return; }
      const close = event.target.closest("[data-close]");
      if (close) { $(close.dataset.close).close(); return; }
      const action = event.target.closest("[data-action]");
      if (!action) return;
      const id = action.dataset.id;
      if (action.dataset.action==="add-jar") openJarDialog();
      if (action.dataset.action==="edit-jar") openJarDialog(state.jars.find(j=>j.id===id));
      if (action.dataset.action==="delete-jar") deleteJar(id);
      if (action.dataset.action==="add-money") openTransactionDialog("in",id);
    });
    $("jarForm").addEventListener("submit",saveJar);
    $("transactionForm").addEventListener("submit",saveTransaction);
    $("addJarButton").addEventListener("click",()=>openJarDialog());
    $("addTransactionButton").addEventListener("click",()=>openTransactionDialog());
    $("transactionSearch").addEventListener("input",()=>renderTransactions("allTransactions", filteredTransactions()));
    $("transactionFilter").addEventListener("change",()=>renderTransactions("allTransactions", filteredTransactions()));
    $("exportButton").addEventListener("click",exportBackup);
    $("importFile").addEventListener("change",event=>importBackup(event.target.files[0]));
    $("resetButton").addEventListener("click",()=>{
      if (!confirm("Yakin hapus semua celengan, transaksi, dan PIN? Tindakan ini tidak bisa dibatalkan.")) return;
      state=initialState(); saveState(); renderAll(); showToast("Semua data di perangkat ini telah direset.");
      navigate("dashboard");
    });
    window.addEventListener("resize",()=>requestAnimationFrame(renderChart));
    document.addEventListener("visibilitychange",()=>{ if (document.hidden) saveState(); });
  }
  function filteredTransactions() {
    const query = $("transactionSearch").value.toLowerCase().trim();
    const filter = $("transactionFilter").value;
    return [...state.transactions].sort((a,b)=>(b.createdAt||b.date).localeCompare(a.createdAt||a.date)).filter(tx=>{
      const jar = state.jars.find(j=>j.id===tx.jarId);
      return `${tx.note||""} ${jar?.name||""}`.toLowerCase().includes(query) && (filter==="all"||tx.type===filter);
    });
  }
  function init() {
    $("todayLabel").textContent = new Date().toLocaleDateString("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).toUpperCase();
    bindEvents(); setupPin(); renderAll();
    if (state.pin) lockApp();
    else $("lockScreen").classList.add("hidden");
  }
  init();
})();