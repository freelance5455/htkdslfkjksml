'use strict';
/* ===== داده‌ها و ثابت‌ها ===== */
const KEY='shonghul_v1',AV=['🦊','🐼','🐸','🦁','🐙','🦄','🐯','🐵','🐧','🐰'];
const MODES={blitz:['⚡','برق‌آسا','۳ تا ۵ کلمه، داستان سریع'],challenge:['🎯','چالش‌باز','کلمه + کارت چالش'],genre:['🎭','ژانر عوض‌کن','سبک داستان تصادفی'],chain:['🔗','داستان زنجیره‌ای','هر نفر یک بخش'],secret:['🕵️','کلمه مخفی','کلمه پنهان را لو نده'],scored:['🏆','داستان امتیازی','کلمات یکسان + رأی‌گیری'],lucky:['🎲','شونغول شانسی','ترکیب تصادفی قوانین']};
const HELP={blitz:'کلمه‌ها را بگیر و در زمان مشخص داستان بساز.',challenge:'علاوه بر کلمه‌ها، یک چالش را هم رعایت کن؛ گرداننده تأیید می‌کند.',genre:'داستان را در سبک ژانر تصادفی بگو.',chain:'هر نفر با یک کلمه اجباری داستان مشترک را ادامه می‌دهد.',secret:'کلمه مخفی را طبیعی در داستان بیاور؛ بقیه حدس می‌زنند.',scored:'همه با کلمات یکسان داستان می‌گویند و سپس مخفیانه رأی می‌دهند (رأی به خود ممنوع).',lucky:'ترکیب تصادفی از چالش، ژانر، تعداد کلمه و قانون ویژه؛ یک بار می‌شود دوباره انداخت.'};
const TABS={words:'کلمات',challenges:'چالش‌ها',genres:'ژانرها',rules:'قوانین ویژه',secrets:'کلمات مخفی',crit:'معیارهای رأی'};
const PL=[['word','هر کلمه'],['all','جایزه همه کلمات'],['ch','رعایت چالش/قانون'],['ge','رعایت ژانر'],['done','کامل شدن در زمان'],['vote','هر رأی'],['chain','هر نوبت زنجیره'],['ss','داستان‌گوی کلمه مخفی'],['sg','حدس درست']];
const TITLES={wiz:'بازی جدید',play:'در حال بازی',content:'مدیریت محتوا',scores:'امتیازها',settings:'تنظیمات',help:'راهنما'};
const uid=()=>Math.random().toString(36).slice(2,9);
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const mk=a=>a.map(x=>({id:uid(),on:1,t:[].concat(x)[0],tag:[].concat(x)[1]||'any'}));
const DS=()=>({theme:'violet',mode:'auto',big:0,anim:1,snd:0,nw:4,rounds:2,rerolls:1,time:{blitz:30,challenge:60,genre:60,chain:30,secret:60,scored:60,lucky:60},pts:{word:2,all:3,ch:2,ge:1,done:1,vote:2,chain:2,ss:3,sg:2}});
const seed=()=>({
 words:mk('گربه,فیل,زرافه,پنگوئن,خرگوش,دلفین,پیتزا,هلو,بستنی,کیک,هندوانه,نان,چتر,کلید,بادکنک,ساعت,آینه,کوله‌پشتی,پارک,کتابخانه,جزیره,قلعه,بازار,ایستگاه,جادوگر,فضانورد,پادشاه,روباه,نقاش,کارآگاه,ابر,رودخانه,کوه,رنگین‌کمان,جنگل,باران,معلم,تخته,مداد,زنگ,قطار,چمدان,نقشه,هواپیما,دوربین,شادی,ترس,تعجب,کنجکاوی,آشپز,خلبان,نانوا,باغبان,آتش‌نشان'.split(',')),
 challenges:mk([['داستان با جمله «من اصلاً مقصر نبودم» شروع شود'],['یک سوءتفاهم خنده‌دار رخ دهد'],['شخصیت اصلی خیلی ترسو باشد'],['داستان فقط سه جمله باشد','short'],['داستان با یک سؤال تمام شود'],['یک اتفاق غیرمنتظره رخ دهد']]),
 genres:mk('کمدی,ماجراجویی,پلیسی,تخیلی,فانتزی,معمایی,دوستی,مدرسه‌ای'.split(',')),
 rules:mk([['هر جمله را با «ناگهان» شروع کن'],['آخر داستان یک ضرب‌المثل بگو'],['داستان را آهسته و با صدای آرام بگو'],['داستان را مفصل و طولانی بگو','long'],['فقط با جمله‌های بسیار کوتاه حرف بزن','short']]),
 secrets:mk('ستاره,شکلات,دوچرخه,موز,کفش,گنج,بادبادک,پاندا,تاب,پروانه'.split(',')),
 crit:mk(['خلاقانه‌ترین','خنده‌دارترین','غیرمنتظره‌ترین','منسجم‌ترین'])});
const fresh=()=>({v:1,players:[],log:[],recent:[],m:null,set:DS(),C:seed()});

/* ===== ذخیره‌سازی ===== */
let memOnly=false;
try{localStorage.setItem(KEY+'_t','1')}catch(e){memOnly=true}
function load(){try{const j=JSON.parse(localStorage.getItem(KEY));if(j&&j.v===1){const f=fresh();j.set={...f.set,...j.set,time:{...f.set.time,...j.set.time},pts:{...f.set.pts,...j.set.pts}};j.C={...f.C,...j.C};return {...f,...j}}}catch(e){}return fresh()}
let S=load();
const U={scr:S.m?'play':'home',step:1,mode:'blitz',show:0,msg:memOnly?'ذخیره‌سازی مرورگر در دسترس نیست؛ داده‌ها فقط موقتاً نگه داشته می‌شوند.':''};
function save(){if(memOnly)return;try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){memOnly=true;U.msg='ذخیره‌سازی ممکن نشد؛ ادامه فقط در حافظه موقت.'}}

/* ===== ابزار DOM (ایمن در برابر XSS: فقط textContent) ===== */
const $=s=>document.querySelector(s);
const h=(t,a,...c)=>{const e=document.createElement(t);for(const k in a||{}){const v=a[k];if(k==='class')e.className=v;else if(k.startsWith('on'))e.addEventListener(k.slice(2),v);else if(k==='value'||k==='checked'||k==='disabled')e[k]=v;else if(v!=null&&v!==false)e.setAttribute(k,v)}c.flat(9).forEach(x=>{if(x!=null&&x!==false)e.append(x.nodeType?x:String(x))});return e};
const B=(t,f,c)=>h('button',{class:'btn '+(c||''),onclick:f},t);
const CK=(l,v,f)=>h('label',{class:'ck'},h('input',{type:'checkbox',checked:!!v,onchange:e=>{f(e.target.checked);save()}}),l);
const go=s=>{U.scr=s;render()};

/* ===== انتخاب محتوا (بدون DOM) ===== */
const shuf=a=>a.map(x=>[Math.random(),x]).sort((p,q)=>p[0]-q[0]).map(x=>x[1]);
const rnd=a=>a[Math.floor(Math.random()*a.length)];
function pick(list,k){const on=list.filter(x=>x.on),fr=on.filter(x=>!S.recent.includes(x.id)),old=on.filter(x=>S.recent.includes(x.id));const r=shuf(fr).concat(shuf(old)).slice(0,k);S.recent=S.recent.concat(r.map(x=>x.id)).slice(-30);return r}
function check(mo){const on=l=>S.C[l].filter(x=>x.on).length,e=[],N=mo==='lucky'?5:mo==='chain'?1:S.set.nw;
 if(on('words')<N)e.push('کلمه فعال کافی نیست؛ حداقل '+fa(N)+' کلمه لازم است');
 if((mo==='challenge'||mo==='lucky')&&!on('challenges'))e.push('هیچ چالش فعالی وجود ندارد');
 if((mo==='genre'||mo==='lucky')&&!on('genres'))e.push('هیچ ژانر فعالی وجود ندارد');
 if(mo==='secret'&&on('secrets')<4)e.push('حداقل ۴ کلمه مخفی فعال لازم است');
 if(mo==='scored'&&!on('crit'))e.push('حداقل یک معیار رأی‌گیری فعال لازم است');
 return e.join('. ')}
const compat=(a,b)=>!(a.tag!=='any'&&b.tag!=='any'&&a.tag!==b.tag);
function mkCfg(mo){
 const n=mo==='chain'?1:mo==='lucky'?3+Math.floor(Math.random()*3):mo==='blitz'?Math.min(5,Math.max(3,S.set.nw)):S.set.nw;
 const c={words:pick(S.C.words,n).map(x=>x.t)};
 if(mo==='challenge')c.ch=pick(S.C.challenges,1)[0].t;
 if(mo==='genre')c.ge=pick(S.C.genres,1)[0].t;
 if(mo==='secret'){const s=pick(S.C.secrets,4);c.sec=s[0].t;c.opts=shuf(s.map(x=>x.t))}
 if(mo==='lucky'){const ch=rnd(S.C.challenges.filter(x=>x.on)),ru=S.C.rules.filter(x=>x.on&&compat(ch,x));c.ch=ch.t;c.ge=rnd(S.C.genres.filter(x=>x.on)).t;if(ru.length)c.ru=rnd(ru).t}
 return c}

/* ===== امتیازدهی (متمرکز) ===== */
function calc(m,pid,f){const p=S.set.pts,c=m.cfg,r=[],add=(a,w)=>a>0&&r.push([pid,a,w]);
 const u=c.words.filter(w=>f.used&&f.used[w]).length;
 add(u*p.word,fa(u)+' کلمه استفاده‌شده');
 if(m.mode!=='chain'&&u===c.words.length)add(p.all,'جایزه استفاده از همه کلمات');
 if(c.ch&&f.ch)add(p.ch,'رعایت چالش');if(c.ru&&f.ru)add(p.ch,'رعایت قانون ویژه');if(c.ge&&f.ge)add(p.ge,'رعایت ژانر');
 if((m.mode==='blitz'||m.mode==='lucky')&&f.done)add(p.done,'کامل شدن داستان در زمان');
 if(m.mode==='chain'&&f.done){add(p.chain,'مشارکت در داستان زنجیره‌ای');r.push(['g',1,'امتیاز مشترک گروه'])}
 if(!r.length)r.push([pid,0,'بدون امتیاز']);return r}
function award(key,list){if(S.log.some(x=>x.k===key))return false;const rd=S.m?S.m.round+1:0;list.forEach(([pid,pts,why])=>S.log.push({k:key,pid,pts,why,r:rd}));return true}
const K=m=>m.round+'-'+m.turn+'-'+m.mode;
const totals=()=>{const t={};S.log.forEach(x=>t[x.pid]=(t[x.pid]||0)+x.pts);return t};
function rank(ps){const t=totals(),L=ps.map(p=>({p,s:t[p.id]||0})).sort((a,b)=>b.s-a.s);L.forEach((x,i)=>x.r=i&&x.s===L[i-1].s?L[i-1].r:i+1);return L}

/* ===== جریان مسابقه ===== */
function start(mo){const e=check(mo);if(e){U.msg=e;return render()}
 S.m={mode:mo,players:S.players.map(p=>({...p})),rounds:S.set.rounds,round:0,turn:0,ph:'pass',cfg:null,votes:{},vi:0,story:[],form:{},rr:0};
 S.log=[];S.recent=[];setup();U.scr='play';save();render()}
function setup(){const m=S.m,sh=m.mode==='scored'||m.mode==='lucky';
 if(!(sh&&m.turn>0))m.cfg=mkCfg(m.mode);
 if(m.turn===0)m.rr=0;
 m.ph=m.mode==='lucky'&&m.turn===0?'lucky':'pass';m.t=null;m.form={}}
function endRound(){const m=S.m;m.round++;m.turn=0;if(m.round>=m.rounds){m.ph='end'}else setup()}
function adv(){const m=S.m;m.turn++;if(m.turn>=m.players.length){if(m.mode==='scored'){m.ph='vpass';m.vi=0;m.votes={};return}endRound()}else setup()}
function tally(m){const crit=S.C.crit.filter(x=>x.on),res={},list=[];
 crit.forEach(c=>{res[c.id]={};m.players.forEach(p=>res[c.id][p.id]=0)});
 Object.values(m.votes).forEach(v=>crit.forEach(c=>{if(v[c.id]&&res[c.id][v[c.id]]!==undefined)res[c.id][v[c.id]]++}));
 crit.forEach(c=>m.players.forEach(p=>{const n=res[c.id][p.id];if(n)list.push([p.id,n*S.set.pts.vote,'رأی در «'+c.t+'» ('+fa(n)+' رأی)'])}));
 m.res=res;m.rc=crit;award('v'+m.round,list);m.ph='vres'}

/* ===== تایمر مبتنی بر زمان واقعی ===== */
const left=m=>m.t?(m.t.run?Math.max(0,m.t.end-Date.now()):m.t.rem):S.set.time[m.mode]*1000;
const fmt=ms=>{const s=Math.ceil(ms/1000);return fa(String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'))};
function beep(){if(!S.set.snd)return;try{const a=new(window.AudioContext||window.webkitAudioContext)(),o=a.createOscillator();o.connect(a.destination);o.frequency.value=660;o.start();o.stop(a.currentTime+.5)}catch(e){}}
setInterval(()=>{const m=S.m;if(U.scr!=='play'||!m||!m.t||!m.t.run)return;const l=left(m);if(l<=0){m.t.run=0;m.t.rem=0;beep();save();render()}else{const e=$('#tm');if(e)e.textContent=fmt(l)}},250);
function timer(m){const d=S.set.time[m.mode]*1000,t=m.t;
 const b=!t?B('▶ شروع تایمر',()=>{m.t={run:1,end:Date.now()+d,rem:d};save();render()},'pri'):t.run?B('⏸ توقف موقت',()=>{t.rem=Math.max(0,t.end-Date.now());t.run=0;save();render()}):t.rem>0?B('▶ ادامه',()=>{t.run=1;t.end=Date.now()+t.rem;save();render()},'pri'):h('b',0,'⏰ زمان تمام شد!');
 return h('div',{class:'card c'},h('div',{id:'tm',class:'tm',role:'timer'},fmt(left(m))),b)}

/* ===== رندر صفحه‌ها ===== */
function home(){return[h('div',{class:'hero'},h('div',{class:'logo'},'شونغول'),h('p',{class:'tag'},'سه کلمه؛ هزار داستان!')),
 S.m&&S.m.ph!=='end'?B('▶ ادامه مسابقه',()=>go('play'),'pri'):null,
 B('🎮 شروع بازی',()=>{U.step=1;go('wiz')},S.m?'':'pri'),B('📚 مدیریت محتوا',()=>go('content')),B('🏅 امتیازها',()=>go('scores')),B('⚙️ تنظیمات',()=>go('settings')),B('❓ راهنمای بازی',()=>go('help'))]}

function wiz(){const n=S.players.length,st=U.step,out=[h('div',{class:'bar'},h('span',0,'مرحله '+fa(st)+' از ۴'),h('span',0,['','بازیکن‌ها','حالت بازی','تعداد دور','شروع'][st]))];
 if(st===1){
  const add=()=>{const v=$('#np').value.trim();if(!v){U.msg='نام بازیکن را وارد کنید';return render()}if(S.players.length>=10){U.msg='حداکثر ۱۰ بازیکن مجاز است';return render()}
   if(S.players.some(p=>p.name===v))U.msg='نام تکراری است؛ با شناسه داخلی جدا نگه داشته شد.';S.players.push({id:uid(),name:v,av:AV[S.players.length%10]});save();render()};
  out.push(h('div',{class:'card'},S.players.length?null:h('p',{class:'empty'},'هنوز بازیکنی اضافه نشده (۲ تا ۱۰ نفر).'),
   S.players.map((p,i)=>h('div',{class:'row'},h('button',{class:'av','aria-label':'تغییر آواتار '+p.name,onclick:()=>{p.av=AV[(AV.indexOf(p.av)+1)%10];save();render()}},p.av),
    h('input',{value:p.name,maxlength:14,'aria-label':'نام بازیکن '+fa(i+1),onchange:e=>{const v=e.target.value.trim();if(v)p.name=v;else U.msg='نام نمی‌تواند خالی باشد';save();render()}}),
    h('button',{class:'btn sm','aria-label':'بالا',disabled:i===0,onclick:()=>{S.players.splice(i-1,0,S.players.splice(i,1)[0]);save();render()}},'↑'),
    h('button',{class:'btn sm','aria-label':'پایین',disabled:i===n-1,onclick:()=>{S.players.splice(i+1,0,S.players.splice(i,1)[0]);save();render()}},'↓'),
    h('button',{class:'btn sm','aria-label':'حذف '+p.name,onclick:()=>{if(confirm('«'+p.name+'» حذف شود؟')){S.players.splice(i,1);save();render()}}},'🗑'))),
   h('div',{class:'row'},h('input',{id:'np',placeholder:'نام بازیکن جدید',maxlength:14,'aria-label':'نام بازیکن جدید',onkeydown:e=>e.key==='Enter'&&add()}),h('button',{class:'btn sm pri',onclick:add},'➕ افزودن'))),
   h('p',{class:'note'},n<2?'برای شروع حداقل ۲ بازیکن لازم است.':'ترتیب نوبت همین فهرست است.'),
   h('button',{class:'btn pri',disabled:n<2,onclick:()=>{U.step=2;render()}},'بعدی ←'))}
 if(st===2){out.push(h('div',{class:'grid'},Object.entries(MODES).map(([k,v])=>h('button',{class:'mode'+(U.mode===k?' sel':''),'aria-pressed':U.mode===k,onclick:()=>{U.mode=k;render()}},h('div',{style:'font-size:2rem'},v[0]),v[1],h('small',0,v[2])))),B('بعدی ←',()=>{U.step=3;render()},'pri'),B('→ قبلی',()=>{U.step=1;render()}))}
 if(st===3){out.push(h('div',{class:'card'},h('p',0,U.mode==='chain'?'تعداد دورهای زنجیره (هر دور: هر نفر یک بخش)':'تعداد دورها'),h('label',{class:'fld'},'دور',h('input',{type:'number',min:1,max:10,value:S.set.rounds,onchange:e=>{S.set.rounds=Math.min(10,Math.max(1,+e.target.value||1));save();render()}})),h('p',{class:'note'},'زمان هر نوبت: '+fmt(S.set.time[U.mode]*1000)+' (قابل تغییر در تنظیمات)')),B('بعدی ←',()=>{U.step=4;render()},'pri'),B('→ قبلی',()=>{U.step=2;render()}))}
 if(st===4){const e=check(U.mode);out.push(h('div',{class:'card c'},h('div',{style:'font-size:3rem'},MODES[U.mode][0]),h('h3',0,MODES[U.mode][1]),h('p',0,S.players.map(p=>p.av+p.name).join(' · ')),h('p',0,fa(S.set.rounds)+' دور'),e?h('p',{class:'ex'},'⚠️ '+e):null),
  h('button',{class:'btn pri',disabled:!!e||n<2,onclick:()=>{if(S.m&&!confirm('مسابقه فعلی با شروع بازی جدید پاک می‌شود. ادامه می‌دهید؟'))return;start(U.mode)}},'🚀 شروع!'),e?B('📚 رفتن به مدیریت محتوا',()=>go('content')):null,B('→ قبلی',()=>{U.step=3;render()}))}
 return out}

const info=c=>h('div',{class:'card c'},h('div',{class:'chips',style:'justify-content:center'},c.words.map(w=>h('span',{class:'word'},w))),c.ch&&h('p',{class:'ex'},'🎯 چالش: '+c.ch),c.ge&&h('p',{class:'ex'},'🎭 ژانر: '+c.ge),c.ru&&h('p',{class:'ex'},'⭐ قانون ویژه: '+c.ru));

function board(ps){const L=rank(ps),t=totals(),out=[];
 if(L.length>1&&L[0].s===L[1].s)out.push(h('p',{class:'ex'},'🤝 تساوی در صدر؛ همه برنده‌اند!'));
 out.push(h('div',{class:'card'},L.map(x=>h('div',{class:'rk'},h('b',{class:'n'},fa(x.r)),h('span',0,x.p.av+' '+x.p.name),h('span',{class:'s'},fa(x.s)+' امتیاز')))));
 if(t.g!==undefined)out.push(h('div',{class:'card c'},'👥 امتیاز مشترک گروه: ',h('b',0,fa(t.g))));return out}

function play(){const m=S.m;if(!m)return[h('p',{class:'empty'},'مسابقه‌ای در جریان نیست.'),B('🎮 شروع بازی',()=>{U.step=1;go('wiz')},'pri')];
 const n=m.players.length,p=m.players[m.turn]||m.players[0],nx=m.players[(m.turn+1)%n],ph=m.ph,mo=MODES[m.mode],out=[];
 out.push(h('div',{class:'bar'},h('span',0,mo[0]+' '+mo[1]),h('span',0,ph==='end'?'پایان':'دور '+fa(m.round+1)+' از '+fa(m.rounds)+(ph[0]==='v'?' · رأی‌گیری':' · نوبت '+fa(m.turn+1)+'/'+fa(n)))));
 if(ph==='pass'||ph==='vpass'){const q=ph==='pass'?p:m.players[m.vi];
  out.push(h('div',{class:'card c pop'},h('div',{class:'av xl'},q.av),h('h2',0,'نوبت '+q.name+' است'),h('p',0,ph==='pass'?'گوشی را به او بده. نفر بعدی: '+nx.name:'گوشی را به او بده تا مخفیانه رأی بدهد.'),
   B(ph==='pass'?'آماده‌ام ✋':'رأی می‌دهم ✋',()=>{m.ph=ph==='pass'?(m.mode==='secret'?'peek':'turn'):'vote';m.vd={};save();render()},'pri')))}
 else if(ph==='lucky'){out.push(h('h2',0,'🎲 ترکیب این دور'),info(m.cfg),h('p',{class:'note'},'زمان هر نوبت: '+fmt(S.set.time.lucky*1000)+' · بازتصادفی باقی‌مانده: '+fa(S.set.rerolls-m.rr)),
   m.rr<S.set.rerolls?B('🔄 ترکیب جدید (یک‌بار)',()=>{m.rr++;m.cfg=mkCfg('lucky');save();render()}):null,B('شروع دور ✓',()=>{m.ph='pass';save();render()},'pri'))}
 else if(ph==='peek'){out.push(info({words:m.cfg.words}),h('div',{class:'card c'},h('h3',0,'🤫 فقط '+p.name+' نگاه کند!'),
   U.show?[h('div',{class:'secret'},m.cfg.sec),B('پنهان کن و شروع',()=>{U.show=0;m.ph='turn';save();render()},'pri')]:[h('p',0,'بقیه نگاه نکنند، بعد دکمه را بزن.'),B('👁 نمایش کلمه مخفی',()=>{U.show=1;render()})]))}
 else if(ph==='turn'){out.push(h('h2',0,p.av+' '+p.name+'، داستانت را بگو!'),info(m.cfg),
   m.mode==='secret'?h('p',{class:'note'},'کلمه مخفی را طبیعی داخل داستان بیاور!'):null,
   m.mode==='chain'&&m.story.length?h('p',{class:'note'},'تا اینجا: '+m.story.map(s=>s[0]+'←'+s[1]).join('، ')):null,
   timer(m),B('⏹ پایان داستان',()=>{m.ph='res';m.form={used:{}};save();render()},'pri'))}
 else if(ph==='res'){const f=m.form,c=m.cfg;f.used=f.used||{};
  out.push(h('h2',0,'ثبت نتیجه '+p.name),h('div',{class:'card'},h('h3',0,'کلمه‌هایی که استفاده شد'),c.words.map(w=>CK(w,f.used[w],v=>f.used[w]=v))),
   h('div',{class:'card'},h('h3',0,'تأیید گرداننده'),c.ch?CK('چالش رعایت شد',f.ch,v=>f.ch=v):null,c.ru?CK('قانون ویژه رعایت شد',f.ru,v=>f.ru=v):null,c.ge?CK('ژانر رعایت شد',f.ge,v=>f.ge=v):null,
    m.mode==='chain'?CK('بخش خودش را اضافه کرد',f.done,v=>f.done=v):null,(m.mode==='blitz'||m.mode==='lucky')?CK('داستان در زمان کامل شد',f.done,v=>f.done=v):null,
    !(c.ch||c.ru||c.ge||m.mode==='chain'||m.mode==='blitz'||m.mode==='lucky')?h('p',{class:'note'},'فقط کلمه‌ها امتیاز دارند.'):null),
   B('✅ ثبت امتیاز',()=>{const e=calc(m,p.id,f);
    if(m.mode==='chain'&&f.done&&f.used[c.words[0]])m.story.push([p.name,c.words[0]]);
    if(m.mode==='secret'){m.pend=e;m.ph='guess';m.form={g:{}}}else{award(K(m),e);adv()}save();render()},'pri'))}
 else if(ph==='guess'){const g=m.form.g;
  out.push(h('h2',0,'🤔 حالا حدس بزنید!'),h('p',0,p.name+' یک کلمه مخفی در داستان گذاشته بود. هر نفر یک گزینه را انتخاب کند:'),
   m.players.filter(o=>o.id!==p.id).map(o=>h('div',{class:'card'},h('b',0,o.av+' '+o.name),h('div',{class:'opts'},m.cfg.opts.map(op=>h('button',{class:'chip'+(g[o.id]===op?' sel':''),'aria-pressed':g[o.id]===op,onclick:()=>{g[o.id]=op;save();render()}},op))))),
   B('نمایش پاسخ و ثبت امتیاز',()=>{const e=m.pend.slice(),ok=[];m.players.forEach(o=>{if(o.id!==p.id&&g[o.id]===m.cfg.sec){ok.push(o.name);e.push([o.id,S.set.pts.sg,'حدس درست کلمه مخفی'])}});
    if(ok.length)e.push([p.id,S.set.pts.ss,'وارد کردن موفق کلمه مخفی']);award(K(m),e);m.rev=ok;m.ph='rev';save();render()},'pri'))}
 else if(ph==='rev'){out.push(h('div',{class:'card c pop'},h('p',0,'کلمه مخفی این بود:'),h('div',{class:'secret'},m.cfg.sec),h('p',0,m.rev.length?'درست حدس زدند: '+m.rev.join('، '):'کسی درست حدس نزد!'),B('ادامه ←',()=>{adv();save();render()},'pri')))}
 else if(ph==='vote'){const v=m.players[m.vi],crit=S.C.crit.filter(x=>x.on),opts=m.players.filter(x=>x.id!==v.id);m.vd=m.vd||{};
  const rd=(c,val,l)=>h('label',{class:'chip'},h('input',{type:'radio',name:'c'+c.id,checked:m.vd[c.id]===val,onchange:()=>{m.vd[c.id]=val;save()}}),l);
  out.push(h('h2',0,v.av+' '+v.name+'، رأی بده'),h('p',{class:'note'},'رأی به خودت ممنوع است و رأی‌ها تا پایان مخفی می‌مانند.'),
   crit.map(c=>h('div',{class:'card'},h('h3',0,'کدام داستان '+c.t+' بود؟'),h('div',{class:'opts'},opts.map(o=>rd(c,o.id,o.av+' '+o.name)),n===2?rd(c,'none','بدون رأی'):null))),
   B('🔒 تأیید نهایی رأی',()=>{if(crit.some(c=>!m.vd[c.id])){U.msg='برای همه معیارها یک گزینه انتخاب کنید';return render()}
    m.votes[v.id]=m.vd;m.vd={};m.vi++;if(m.vi>=n)tally(m);else m.ph='vpass';save();render()},'pri'))}
 else if(ph==='vres'){out.push(h('h2',0,'🏆 نتیجه رأی‌گیری'),m.rc.map(c=>{const r=m.res[c.id],mx=Math.max(...Object.values(r)),w=m.players.filter(q=>mx>0&&r[q.id]===mx);
   return h('div',{class:'card'},h('h3',0,c.t),m.players.map(q=>h('div',{class:'rk'},h('span',0,q.av+' '+q.name),h('span',{class:'s'},fa(r[q.id])+' رأی'))),h('p',{class:'ex'},mx?'🏆 برنده: '+w.map(q=>q.name).join(' و ')+(w.length>1?' (مساوی)':''):'رأیی ثبت نشد'))}),
   ...board(m.players),B('ادامه ←',()=>{endRound();save();render()},'pri'))}
 else if(ph==='end'){out.push(h('h2',0,'🎉 پایان مسابقه'),...board(m.players),B('🏅 جزئیات امتیازها',()=>go('scores')),B('🔁 مسابقه جدید',()=>{U.step=1;go('wiz')},'pri'))}
 return out}

function scores(){const ps=S.m?S.m.players:S.players,out=[];
 if(!ps.length)return[h('p',{class:'empty'},'هنوز بازیکنی نیست.')];
 out.push(...board(ps));
 out.push(h('div',{class:'card'},h('h3',0,'جزئیات'),ps.map(p=>{const l=S.log.filter(x=>x.pid===p.id);return h('details',0,h('summary',0,p.av+' '+p.name+' — '+fa(l.reduce((a,x)=>a+x.pts,0))+' امتیاز، '+fa(new Set(l.map(x=>x.k)).size)+' نوبت'),l.length?h('ul',{class:'l'},l.map(x=>h('li',0,h('span',0,'دور '+fa(x.r)+': '+x.why),h('b',0,'+'+fa(x.pts))))):h('p',{class:'note'},'هنوز امتیازی ثبت نشده'))}),
  S.log.some(x=>x.pid==='g')?h('details',0,h('summary',0,'👥 گروه'),h('ul',{class:'l'},S.log.filter(x=>x.pid==='g').map(x=>h('li',0,h('span',0,x.why),h('b',0,'+'+fa(x.pts)))))):null));
 out.push(B('↩ لغو آخرین تغییر امتیاز',()=>{if(!S.log.length){U.msg='چیزی برای لغو نیست';return render()}const k=S.log[S.log.length-1].k;if(confirm('آخرین ثبت امتیاز ('+S.log.filter(x=>x.k===k).length+' مورد) لغو شود؟')){S.log=S.log.filter(x=>x.k!==k);save();U.msg='لغو شد';render()}}),
  B('🔁 مسابقه جدید',()=>{if(confirm('مسابقه فعلی و امتیازها پاک شود؟')){S.m=null;S.log=[];S.recent=[];save();U.step=1;go('wiz')}}));return out}

function content(){const t=U.tab=U.tab||'words',L=S.C[t],out=[];
 out.push(h('div',{class:'tabs',role:'tablist'},Object.entries(TABS).map(([k,v])=>h('button',{class:'chip'+(k===t?' sel':''),role:'tab','aria-selected':k===t,onclick:()=>{U.tab=k;render()}},v))));
 const add=()=>{const ls=$('#nt').value.split('\n').map(s=>s.trim()).filter(Boolean);if(!ls.length){U.msg='متنی وارد نشده است';return render()}
  let ok=0,dup=0,bad=0;ls.forEach(s=>{if(s.length>80)bad++;else if(L.some(x=>x.t===s))dup++;else{L.push({id:uid(),t:s,on:1,tag:'any'});ok++}});save();U.msg=fa(ok)+' مورد افزوده شد'+(dup?'، '+fa(dup)+' تکراری ردشد':'')+(bad?'، '+fa(bad)+' مورد بیش از ۸۰ حرف بود':'');render()};
 out.push(h('div',{class:'card'},h('label',{for:'nt'},'افزودن (هر خط یک مورد)'),h('textarea',{id:'nt',rows:3,maxlength:2000}),B('➕ افزودن',add,'pri')));
 out.push(h('div',{class:'card'},h('div',{class:'row'},h('input',{type:'search','aria-label':'جست‌وجو',placeholder:'🔍 جست‌وجو...',oninput:e=>{const v=e.target.value.trim();document.querySelectorAll('#cl li').forEach(li=>li.hidden=!li.dataset.t.includes(v))}})),
  h('p',{class:'note'},'فعال: '+fa(L.filter(x=>x.on).length)+' از '+fa(L.length)),
  L.length?h('ul',{class:'l',id:'cl'},L.map(x=>h('li',{'data-t':x.t},CK('',x.on,v=>{x.on=v?1:0;render()}),h('span',{class:x.on?'':'off'},x.t),
   h('button',{class:'btn sm','aria-label':'ویرایش',onclick:()=>{const v=(prompt('ویرایش:',x.t)||'').trim();if(!v)return;if(v.length>80||L.some(y=>y!==x&&y.t===v)){U.msg='متن نامعتبر یا تکراری است';return render()}x.t=v;save();render()}},'✏️'),
   h('button',{class:'btn sm','aria-label':'حذف',onclick:()=>{if(confirm('«'+x.t+'» حذف شود؟')){S.C[t]=L.filter(y=>y!==x);save();render()}}},'🗑')))):h('p',{class:'empty'},'این فهرست خالی است.')));
 return out}

function settings(){const s=S.set,L=(t,...c)=>h('section',{class:'card'},h('h3',0,t),...c);
 const num=(l,o,k,mn,mx)=>h('label',{class:'fld'},l,h('input',{type:'number',min:mn,max:mx,value:o[k],onchange:e=>{o[k]=Math.min(mx,Math.max(mn,+e.target.value||mn));save();render()}}));
 const chips=(a,cur,f)=>h('div',{class:'chips'},a.map(([k,v])=>h('button',{class:'chip'+(k===cur?' sel':''),'aria-pressed':k===cur,onclick:()=>{f(k);save();render()}},v)));
 return[L('🎨 ظاهر',chips([['violet','بنفش/فیروزه‌ای'],['blue','آبی'],['green','سبز'],['orange','نارنجی'],['pink','صورتی']],s.theme,k=>s.theme=k),chips([['auto','پیروی از سیستم'],['light','روشن'],['dark','تیره']],s.mode,k=>s.mode=k),CK('متن بزرگ',s.big,v=>{s.big=+v;render()}),CK('انیمیشن‌ها',s.anim,v=>{s.anim=+v;render()}),CK('صدای پایان تایمر',s.snd,v=>s.snd=+v)),
  L('🎮 بازی',num('تعداد کلمات هر دور',s,'nw',3,6),num('تعداد دور مسابقه',s,'rounds',1,10),num('دفعات بازتصادفی شانسی',s,'rerolls',0,5),...Object.keys(MODES).map(k=>num('زمان «'+MODES[k][1]+'» (ثانیه)',s.time,k,10,300))),
  L('🏅 امتیازها',...PL.map(([k,l])=>num(l,s.pts,k,0,20))),
  B('♻️ بازگرداندن تنظیمات پیش‌فرض',()=>{if(confirm('همه تنظیمات به حالت اول برگردد؟')){S.set=DS();save();render()}}),
  B('🧹 پاک کردن همه داده‌ها',()=>{if(confirm('هشدار: بازیکن‌ها، امتیازها، محتوا و تنظیمات برای همیشه پاک می‌شوند. مطمئنید؟')){try{localStorage.removeItem(KEY)}catch(e){}S=fresh();U.scr='home';U.msg='همه داده‌ها پاک شد';render()}},'danger')]}

function help(){return[h('div',{class:'card'},h('h3',0,'شونغول چیست؟'),h('p',0,'با یک گوشی مشترک، کلمه‌ها را می‌گیرید و با آن‌ها داستان می‌سازید. گرداننده (بقیه بازیکن‌ها) تأیید می‌کند چه چیزی رعایت شد و امتیازها خودکار حساب می‌شود.')),
 ...Object.entries(MODES).map(([k,v])=>h('div',{class:'card'},h('b',0,v[0]+' '+v[1]),h('p',{style:'margin:4px 0 0'},HELP[k])))]}

const SCR={home,wiz,play,content,scores,settings,help};
function render(){const r=document.documentElement,s=S.set;r.dataset.theme=s.theme;r.dataset.dark=(s.mode==='dark'||(s.mode==='auto'&&matchMedia('(prefers-color-scheme: dark)').matches))?1:0;r.dataset.big=s.big?1:0;r.dataset.anim=s.anim?1:0;
 const k=U.scr+(S.m?S.m.ph+S.m.turn+S.m.round:'')+U.step+(U.tab||'');
 $('#app').replaceChildren(U.scr!=='home'?h('div',{class:'top'},h('button',{class:'btn sm',onclick:()=>go('home')},'→ خانه'),h('b',0,TITLES[U.scr])):null,U.msg?h('div',{class:'toast',role:'status'},U.msg):null,...SCR[U.scr]());
 U.msg='';if(k!==U.k){window.scrollTo(0,0);U.k=k}}
render();
