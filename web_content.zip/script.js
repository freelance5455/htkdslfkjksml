// आज की तारीख दिखाना
document.getElementById('date-display').innerText = new Date().toDateString();

let totalMinutes = 0;

// BMI कैलकुलेटर फंक्शन
function calculateBMI() {
    const weight = document.getElementById('weight').value;
    const height = document.getElementById('height').value / 100;

    if (weight > 0 && height > 0) {
        const bmi = (weight / (height * height)).toFixed(1);
        let category = "";

        if (bmi < 18.5) category = "(कम वजन)";
        else if (bmi < 25) category = "(सामान्य)";
        else category = "(ज्यादा वजन)";

        document.getElementById('bmi-result').innerText =
            `आपका BMI: ${bmi} ${category}`;
    } else {
        alert("कृपया सही वजन और लंबाई भरें");
    }
}

// वर्कआउट जोड़ने का फंक्शन
function addWorkout() {
    const name = document.getElementById('ex-name').value;
    const time = document.getElementById('ex-time').value;

    if (name === "" || time <= 0) {
        alert("कृपया सही एक्सरसाइज भरें");
        return;
    }

    const list = document.getElementById('workout-list');
    const li = document.createElement('li');
    li.innerHTML = `${name} <span>${time} min</span>`;
    list.appendChild(li);

    totalMinutes += parseInt(time);
    document.getElementById('total-min').innerText = totalMinutes;

    document.getElementById('ex-name').value = "";
    document.getElementById('ex-time').value = "";
}
