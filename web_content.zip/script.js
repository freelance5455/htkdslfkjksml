package com.custom.tvlauncher

import android.os.Bundle
import android.widget.Button
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // YouTube button click listener with fallback
        val btnYouTube = findViewById<Button>(R.id.btnOpenYouTube)
        btnYouTube.setOnClickListener {
            val intent = packageManager.getLaunchIntentForPackage("com.google.android.youtube.tv")
            if (intent != null) {
                startActivity(intent)
            } else {
                val fallbackIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                if (fallbackIntent != null) {
                    startActivity(fallbackIntent)
                }
            }
        }

        // Error-free modern back button restriction for Android TV Home Launcher
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Do nothing to keep the user locked in launcher
            }
        })
    }
}