document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       العناصر
    ===================================================== */

    const canvas =
        document.getElementById("gameCanvas");

    if (!canvas) return;

    const ctx =
        canvas.getContext("2d");

    if (!ctx) return;

    const $ = id =>
        document.getElementById(id);

    const startScreen =
        $("start-screen");

    const gameOverScreen =
        $("gameover-screen");

    const victoryScreen =
        $("victory-screen");

    const settingsPanel =
        $("settings-panel");

    const startBtn =
        $("start-btn");

    const settingsBtn =
        $("settings-btn");

    const closeSettings =
        $("close-settings");

    const restartBtn =
        $("restart-btn");

    const outBtn =
        $("out-btn");

    const victoryBtn =
        $("victory-btn");

    const victoryOutBtn =
        $("victory-out-btn");

    const pauseBtn =
        $("pause-btn");

    const scoreElement =
        $("score");

    const scoreDisplay =
        $("score-display");

    const finalScoreElement =
        $("final-score");

    const highScoreElement =
        $("high-score");

    const biomeNameElement =
        $("biome-name");

    const volumeSlider =
        $("music-volume");

    const volumeValue =
        $("volume-value");


    /* =====================================================
       المتغيرات
    ===================================================== */

    let animationId = null;

    let gameActive = false;

    let paused = false;

    let score = 0;

    let frame = 0;

    let floorY = 0;

    let gameSpeed = 5.5;

    const gravity = 0.65;

    let obstacles = [];

    let particles = [];

    let effects = [];

    let speedPads = [];

    let currentBiome = 0;

    let nextSpeedPad = 100;

    let speedBoost = false;

    let speedBoostTimer = 0;

    let lastInput = 0;

    let gameOverSoundPlayed = false;

    // ترتيب الفخاخ الخاص بكل جيم؛ يتغير عند بدء جيم جديد.
    let trapSequence = [];
    let trapSequenceIndex = 0;
    let previousTrapSequence = [];

    function createTrapSequence() {
        const types = ["spikes", "bomb", "acid"];
        let sequence;

        do {
            sequence = [...types].sort(() => Math.random() - 0.5);
        } while (
            previousTrapSequence.length === sequence.length &&
            sequence.every((type, index) => type === previousTrapSequence[index])
        );

        previousTrapSequence = [...sequence];
        trapSequence = sequence;
        trapSequenceIndex = 0;
    }


    /* =====================================================
       البيئات
    ===================================================== */

    const biomes = [

        {
            name: "كوكب الغابات النيونية",
            sky: "#020907",
            floor: "#071c12",
            accent: "#39ff14",
            obstacle: "#00ffcc",
            acid: "#39ff14"
        },

        {
            name: "أراضي الحمم البركانية",
            sky: "#130404",
            floor: "#2b0808",
            accent: "#ff3300",
            obstacle: "#ffcc00",
            acid: "#ff3b00"
        },

        {
            name: "المدينة السيبرانية المتجمدة",
            sky: "#020b13",
            floor: "#071a2a",
            accent: "#00e5ff",
            obstacle: "#ffffff",
            acid: "#00e5ff"
        },

        {
            name: "وادي البلورات البنفسجية",
            sky: "#09020f",
            floor: "#190628",
            accent: "#bd00ff",
            obstacle: "#ff00ff",
            acid: "#d100ff"
        }

    ];


    /* =====================================================
       الصوت
    ===================================================== */

    let audioContext = null;

    let musicGain = null;

    let musicStarted = false;

    let musicTimer = null;


    let musicVolume =
        Number(
            localStorage.getItem(
                "onezero_music_volume"
            )
        );

    if (!Number.isFinite(musicVolume)) {
        musicVolume = 0.35;
    }


    volumeSlider.value =
        Math.round(musicVolume * 100);


    function updateVolumeText() {

        volumeValue.textContent =
            Math.round(
                musicVolume * 100
            ) + "%";
    }

    updateVolumeText();


    volumeSlider.addEventListener(
        "input",
        () => {

            musicVolume =
                Number(
                    volumeSlider.value
                ) / 100;

            localStorage.setItem(
                "onezero_music_volume",
                String(musicVolume)
            );

            updateVolumeText();

            if (musicGain) {

                musicGain.gain.value =
                    musicVolume * 0.10;
            }
        }
    );


    function initAudio() {

        if (!audioContext) {

            const AudioClass =
                window.AudioContext ||
                window.webkitAudioContext;

            if (!AudioClass) return;

            audioContext =
                new AudioClass();

            musicGain =
                audioContext.createGain();

            musicGain.gain.value =
                musicVolume * 0.10;

            musicGain.connect(
                audioContext.destination
            );
        }


        if (
            audioContext.state ===
            "suspended"
        ) {
            audioContext.resume();
        }


        startMusic();
    }


    function startMusic() {

        if (
            musicStarted ||
            !audioContext
        ) return;


        musicStarted = true;


        const notes = [
            146.83,
            220,
            164.81,
            246.94,
            196,
            293.66,
            220,
            329.63
        ];


        let noteIndex = 0;


        musicTimer =
            setInterval(() => {

                if (
                    !gameActive ||
                    paused
                ) return;


                const osc =
                    audioContext.createOscillator();

                const gain =
                    audioContext.createGain();

                const now =
                    audioContext.currentTime;


                osc.type = "triangle";

                osc.frequency.value =
                    notes[
                        noteIndex %
                        notes.length
                    ];


                gain.gain.setValueAtTime(
                    0,
                    now
                );

                gain.gain.linearRampToValueAtTime(
                    0.16,
                    now + 0.04
                );

                gain.gain.exponentialRampToValueAtTime(
                    0.001,
                    now + 0.55
                );


                osc.connect(gain);

                gain.connect(musicGain);

                osc.start(now);

                osc.stop(now + 0.56);

                noteIndex++;

            }, 420);
    }


    function playSound(type) {

        if (!audioContext) return;


        const now =
            audioContext.currentTime;

        const osc =
            audioContext.createOscillator();

        const gain =
            audioContext.createGain();


        osc.connect(gain);

        gain.connect(
            audioContext.destination
        );


        if (type === "jump") {

            osc.type = "sine";

            osc.frequency.setValueAtTime(
                180,
                now
            );

            osc.frequency.exponentialRampToValueAtTime(
                520,
                now + 0.16
            );

            gain.gain.setValueAtTime(
                0.12,
                now
            );

            gain.gain.exponentialRampToValueAtTime(
                0.001,
                now + 0.18
            );

            osc.start(now);

            osc.stop(now + 0.18);
        }


        if (type === "speed") {

            osc.type = "sine";

            osc.frequency.setValueAtTime(
                250,
                now
            );

            osc.frequency.exponentialRampToValueAtTime(
                800,
                now + 0.25
            );

            gain.gain.setValueAtTime(
                0.12,
                now
            );

            gain.gain.exponentialRampToValueAtTime(
                0.001,
                now + 0.27
            );

            osc.start(now);

            osc.stop(now + 0.27);
        }


        if (type === "gameover") {

            osc.type = "sawtooth";

            osc.frequency.setValueAtTime(
                180,
                now
            );

            osc.frequency.exponentialRampToValueAtTime(
                45,
                now + 0.55
            );

            gain.gain.setValueAtTime(
                0.16,
                now
            );

            gain.gain.exponentialRampToValueAtTime(
                0.001,
                now + 0.55
            );

            osc.start(now);

            osc.stop(now + 0.55);
        }
    }


    /* =====================================================
       تغيير حجم Canvas
    ===================================================== */

    function resizeCanvas() {

        canvas.width =
            window.innerWidth;

        canvas.height =
            window.innerHeight;

        floorY =
            canvas.height * 0.75;

        if (player && !player.isJumping) {

            player.y =
                floorY -
                player.height;
        }
    }

    window.addEventListener(
        "resize",
        resizeCanvas
    );


    /* =====================================================
       الجزيئات
    ===================================================== */

    class Particle {

        constructor(
            x,
            y,
            color,
            force = 1,
            size = 2,
            gravityValue = 0.06
        ) {

            this.x = x;

            this.y = y;

            this.size = size;

            this.speedX =
                (
                    Math.random() - .5
                ) * 4 * force;

            this.speedY =
                (
                    Math.random() - .5
                ) * 4 * force;

            this.gravity =
                gravityValue;

            this.life = 1;

            this.color = color;

            this.shape = "circle";
            this.angle = Math.random() * Math.PI * 2;
            this.spin = (Math.random() - .5) * .25;
        }


        update() {

            this.x += this.speedX;

            this.y += this.speedY;

            this.speedY += this.gravity;

            this.angle += this.spin;

            this.life -= .035;
        }


        draw() {

            if (this.life <= 0)
                return;


            ctx.save();

            ctx.globalAlpha =
                this.life;

            ctx.shadowBlur = this.type === "spikes" ? 22 : 10;

            ctx.shadowColor =
                this.color;

            ctx.fillStyle =
                this.color;


            if (this.shape === "shard") {

                ctx.translate(this.x, this.y);
                ctx.rotate(this.angle);
                ctx.beginPath();
                ctx.moveTo(this.size * 1.5, 0);
                ctx.lineTo(-this.size * .7, -this.size * .75);
                ctx.lineTo(-this.size * .9, this.size * .25);
                ctx.lineTo(this.size * .15, this.size * .8);
                ctx.closePath();
                ctx.fill();

            } else {

                ctx.beginPath();

                ctx.arc(
                    this.x,
                    this.y,
                    this.size,
                    0,
                    Math.PI * 2
                );

                ctx.fill();
            }

            ctx.restore();
        }
    }


    function createParticles(
        x,
        y,
        color,
        amount = 8,
        force = 1,
        size = 2
    ) {

        for (
            let i = 0;
            i < amount;
            i++
        ) {

            particles.push(
                new Particle(
                    x,
                    y,
                    color,
                    force,
                    size
                )
            );
        }
    }


    /* =====================================================
       انفجار القنبلة
       قطرات حمراء وصفراء
    ===================================================== */

    function bombExplosion(
        x,
        y
    ) {

        for (
            let i = 0;
            i < 32;
            i++
        ) {

            const color =
                Math.random() < .5
                    ? "#ff2614"
                    : "#ffd21a";


            const p =
                new Particle(
                    x,
                    y,
                    color,
                    2.4,
                    Math.random() * 3 + 2,
                    0.08
                );


            /*
                قطرات/شرارات مائلة
            */

            p.speedX *= 1.4;

            p.speedY *= 1.15;

            particles.push(p);
        }


        effects.push({
            type: "bomb",
            x,
            y,
            life: 1,
            radius: 8,
            maxRadius: 150,
            flash: 1
        });
    }


    /* =====================================================
       ذوبان اللاعب داخل الحمض
    ===================================================== */

    function acidMeltEffect(
        x,
        y
    ) {

        /* يبدأ اللاعب بالذوبان والغوص داخل سطح الحمض */
        player.acidDissolving = true;
        player.acidDissolveProgress = 0;

        const acidColor = biomes[currentBiome].acid;

        for (let i = 0; i < 34; i++) {
            const p = new Particle(
                x + (Math.random() - .5) * 34,
                y + (Math.random() - .5) * 22,
                Math.random() < .75 ? acidColor : biomes[currentBiome].accent,
                1.4,
                Math.random() * 4 + 1.2,
                -0.04
            );
            p.speedX *= 1.15;
            p.speedY -= Math.random() * 1.5;
            particles.push(p);
        }

        effects.push({
            type: "acid",
            x,
            y: floorY - 3,
            life: 1,
            radius: 8,
            sink: 0
        });

        /* فقاعات حمض صغيرة حول مكان الغوص */
        for (let i = 0; i < 12; i++) {
            const p = new Particle(
                x + (Math.random() - .5) * 42,
                floorY - Math.random() * 12,
                acidColor,
                1.1,
                Math.random() * 2 + 1,
                -0.06
            );
            p.speedX *= .7;
            particles.push(p);
        }
    }

    /* =====================================================
       تفتيت اللاعب عند الأشواك
    ===================================================== */

    function spikeBreakEffect(
        x,
        y
    ) {

        /* تفتيت اللاعب إلى شظايا صغيرة عند الاصطدام بالشوكة */
        const colors = [
            "#07130d",
            "#10251b",
            "#00e5ff",
            "#39ff14",
            "#ffffff"
        ];

        for (let i = 0; i < 42; i++) {

            const p = new Particle(
                x + (Math.random() - .5) * 28,
                y + (Math.random() - .5) * 28,
                colors[Math.floor(Math.random() * colors.length)],
                3.0,
                Math.random() * 3.2 + 1.5,
                0.13
            );

            p.shape = "shard";
            p.speedX = (Math.random() - .5) * 11;
            p.speedY = (Math.random() - .5) * 11 - 2;
            p.spin = (Math.random() - .5) * .45;
            p.life = .9 + Math.random() * .25;
            particles.push(p);
        }

        /* وميض دائري سريع يبرز لحظة التفتت */
        effects.push({
            type: "spike",
            x,
            y,
            life: 1,
            radius: 5
        });

        /* شرارات نيون إضافية */
        createParticles(x, y, "#ffffff", 10, 2.2, 1.4);
    }


    /* =====================================================
       رسم التأثيرات
    ===================================================== */

    function updateEffects() {

        for (
            let i = effects.length - 1;
            i >= 0;
            i--
        ) {

            const effect =
                effects[i];


            effect.life -= .045;


            if (effect.type === "bomb") {

                effect.radius += 7;

                ctx.save();

                /* دائرة الانفجار الحمراء: نطاق واسع وواضح */
                ctx.globalAlpha = effect.life * 0.34;
                ctx.shadowBlur = 35;
                ctx.shadowColor = "#ff1a00";
                ctx.fillStyle = "#ff1a00";
                ctx.beginPath();
                ctx.arc(effect.x, effect.y, effect.radius, 0, Math.PI * 2);
                ctx.fill();

                /* قلب أصفر ساخن داخل الانفجار */
                const innerRadius = Math.max(5, effect.radius * 0.48);
                const gradient = ctx.createRadialGradient(
                    effect.x, effect.y, 2,
                    effect.x, effect.y, innerRadius
                );
                gradient.addColorStop(0, "#ffffff");
                gradient.addColorStop(0.18, "#fff36a");
                gradient.addColorStop(0.55, "#ffd21a");
                gradient.addColorStop(1, "#ff4b00");
                ctx.globalAlpha = effect.life * 0.95;
                ctx.shadowBlur = 28;
                ctx.shadowColor = "#ffd21a";
                ctx.fillStyle = gradient;
                ctx.beginPath();
                ctx.arc(effect.x, effect.y, innerRadius, 0, Math.PI * 2);
                ctx.fill();

                /* حافة حمراء متوهجة للنطاق */
                ctx.globalAlpha = effect.life;
                ctx.shadowBlur = 30;
                ctx.shadowColor = "#ff2600";
                ctx.strokeStyle = "#ff3b00";
                ctx.lineWidth = 5;
                ctx.beginPath();
                ctx.arc(effect.x, effect.y, effect.radius, 0, Math.PI * 2);
                ctx.stroke();

                /* وميض البداية */
                if (effect.flash > 0) {
                    ctx.globalAlpha = effect.flash * 0.85;
                    ctx.fillStyle = "#fff8b0";
                    ctx.shadowBlur = 45;
                    ctx.shadowColor = "#ffd21a";
                    ctx.beginPath();
                    ctx.arc(effect.x, effect.y, innerRadius * 0.72, 0, Math.PI * 2);
                    ctx.fill();
                    effect.flash -= 0.18;
                }

                ctx.restore();
            }


            if (effect.type === "acid") {

                effect.radius += 2.6;
                effect.sink = Math.min(1, effect.sink + .045);

                /* تقدم الغوص متزامن مع ذوبان اللاعب */
                player.acidDissolveProgress = effect.sink;

                ctx.save();

                const acidColor = biomes[currentBiome].acid;
                ctx.globalAlpha = effect.life * .78;
                ctx.shadowBlur = 24;
                ctx.shadowColor = acidColor;
                ctx.strokeStyle = acidColor;
                ctx.lineWidth = 4;

                ctx.beginPath();
                ctx.ellipse(
                    effect.x,
                    floorY - 4,
                    effect.radius * 1.45,
                    Math.max(5, effect.radius * .32),
                    0, 0, Math.PI * 2
                );
                ctx.stroke();

                /* حافة بيضاء سريعة توضح تموج الحمض */
                ctx.globalAlpha = effect.life * .42;
                ctx.shadowBlur = 10;
                ctx.strokeStyle = "#ffffff";
                ctx.lineWidth = 1.5;
                ctx.beginPath();
                ctx.ellipse(
                    effect.x,
                    floorY - 4,
                    effect.radius * 1.15,
                    Math.max(3, effect.radius * .22),
                    0, 0, Math.PI * 2
                );
                ctx.stroke();

                ctx.restore();
            }


            if (effect.type === "spike") {

                effect.radius += 6;

                ctx.save();

                ctx.globalAlpha =
                    effect.life * .55;

                ctx.shadowBlur = 18;

                ctx.shadowColor =
                    "#39ff14";

                ctx.strokeStyle =
                    "#ffffff";

                ctx.lineWidth = 2;


                ctx.beginPath();

                ctx.arc(
                    effect.x,
                    effect.y,
                    effect.radius,
                    0,
                    Math.PI * 2
                );

                ctx.stroke();

                ctx.restore();
            }


            if (effect.life <= 0) {

                effects.splice(
                    i,
                    1
                );
            }
        }
    }


    /* =====================================================
       اللاعب
    ===================================================== */

    const player = {

        x: 80,

        y: 0,

        width: 42,

        height: 42,

        velocityY: 0,

        isJumping: false,

        rotation: 0,

        rotationSpeed: 0,

        pulse: 0,

        blinkTimer: 120,

        blinking: false,

        acidDissolving: false,
        acidDissolveProgress: 0,


        reset() {

            this.y =
                floorY -
                this.height;

            this.velocityY = 0;

            this.isJumping = false;

            this.rotation = 0;

            this.rotationSpeed = 0;

            this.pulse = 0;

            this.blinkTimer = 120;

            this.blinking = false;
            this.acidDissolving = false;
            this.acidDissolveProgress = 0;
        },


        jump() {

            if (
                !gameActive ||
                paused ||
                this.isJumping
            ) return;


            this.velocityY =
                -11.2;

            this.isJumping = true;

            this.rotationSpeed =
                Math.PI * 2.3;


            createParticles(
                this.x +
                this.width / 2,

                this.y +
                this.height,

                "#39ff14",

                12,
                .8,
                2
            );


            playSound("jump");
        },


        update() {

            if (paused) return;


            this.y +=
                this.velocityY;

            this.velocityY +=
                gravity;


            if (this.isJumping) {

                this.rotation +=
                    this.rotationSpeed *
                    .035;

                this.rotationSpeed *=
                    .985;
            }


            if (
                this.y +
                this.height >=
                floorY
            ) {

                if (this.isJumping) {

                    createParticles(
                        this.x +
                        this.width / 2,

                        floorY,

                        "#39ff14",

                        9,
                        .6,
                        2
                    );
                }


                this.y =
                    floorY -
                    this.height;

                this.velocityY = 0;

                this.isJumping = false;

                this.rotation = 0;

                this.rotationSpeed = 0;
            }


            this.pulse += .08;

            this.blinkTimer--;


            if (
                this.blinkTimer <= 0 &&
                !this.blinking
            ) {

                this.blinking = true;

                this.blinkTimer = 5;
            }


            if (this.blinking) {

                this.blinkTimer--;

                if (
                    this.blinkTimer <= 0
                ) {

                    this.blinking = false;

                    this.blinkTimer =
                        100 +
                        Math.random() * 140;
                }
            }
        },


        draw() {

            const cx =
                this.x +
                this.width / 2;

            const cy =
                this.y +
                this.height / 2;

            const pulse =
                Math.sin(
                    this.pulse
                ) * 2;

            const w =
                this.width;

            const h =
                this.height;

            /* ذوبان وغوص اللاعب داخل الحمض */
            let dissolveScale = 1;
            let dissolveAlpha = 1;
            let dissolveY = 0;

            if (this.acidDissolving) {
                const p = Math.min(1, this.acidDissolveProgress);
                dissolveY = p * 58;
                dissolveScale = 1 - p * 0.48;
                dissolveAlpha = 1 - p * 0.78;
            }

            ctx.save();

            ctx.globalAlpha *= dissolveAlpha;

            ctx.translate(
                cx,
                cy + dissolveY
            );

            ctx.scale(
                dissolveScale,
                dissolveScale
            );

            ctx.rotate(
                this.rotation
            );


            /* توهج اللاعب */

            ctx.shadowBlur =
                24 + pulse;

            ctx.shadowColor =
                "#39ff14";


            /* جسم اللاعب */

            ctx.fillStyle =
                "#07130d";

            ctx.strokeStyle =
                "#39ff14";

            ctx.lineWidth = 2.5;


            ctx.beginPath();

            ctx.roundRect(
                -w / 2,
                -h / 2,
                w,
                h,
                6
            );

            ctx.fill();

            ctx.stroke();

            ctx.closePath();


            /* الجسم الداخلي */

            ctx.shadowBlur = 12;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#10251b";


            ctx.beginPath();

            ctx.roundRect(
                -w / 2 + 3,
                -h / 2 + 3,
                w - 6,
                h - 6,
                4
            );

            ctx.fill();

            ctx.closePath();


            /* العيون */

            ctx.shadowBlur = 12;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#00e5ff";


            if (!this.blinking) {

                ctx.fillRect(
                    -12,
                    -10,
                    8,
                    8
                );

                ctx.fillRect(
                    4,
                    -10,
                    8,
                    8
                );


                ctx.shadowBlur = 4;

                ctx.fillStyle =
                    "#d9ffff";


                ctx.fillRect(
                    -11,
                    -9,
                    2,
                    2
                );

                ctx.fillRect(
                    5,
                    -9,
                    2,
                    2
                );

            } else {

                ctx.shadowBlur = 7;

                ctx.strokeStyle =
                    "#00e5ff";

                ctx.lineWidth = 2;


                ctx.beginPath();

                ctx.moveTo(
                    -12,
                    -6
                );

                ctx.lineTo(
                    -4,
                    -6
                );

                ctx.moveTo(
                    4,
                    -6
                );

                ctx.lineTo(
                    12,
                    -6
                );

                ctx.stroke();

                ctx.closePath();
            }


            /* الفم */

            ctx.shadowBlur = 10;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#00e5ff";

            ctx.fillRect(
                -14,
                5,
                28,
                6
            );

            ctx.fillStyle =
                "#06100c";

            ctx.fillRect(
                -11,
                7,
                22,
                2
            );


            /* الخط السفلي */

            ctx.shadowBlur = 8;

            ctx.strokeStyle =
                "#39ff14";

            ctx.lineWidth = 1;


            ctx.beginPath();

            ctx.moveTo(
                -10,
                15
            );

            ctx.lineTo(
                10,
                15
            );

            ctx.stroke();

            ctx.closePath();


            /* لمعان */

            ctx.globalAlpha = .45;

            ctx.shadowBlur = 8;

            ctx.shadowColor =
                "#ffffff";

            ctx.strokeStyle =
                "#ffffff";

            ctx.lineWidth = 1;


            ctx.beginPath();

            ctx.moveTo(
                -w / 2 + 6,
                -h / 2 + 3
            );

            ctx.lineTo(
                w / 2 - 9,
                -h / 2 + 3
            );

            ctx.stroke();

            ctx.restore();
        }
    };


    /* =====================================================
       العقبات
    ===================================================== */

    class Obstacle {

        constructor() {

            this.x =
                canvas.width + 60;

            this.passed = false;


            /*
             * كل جيم له ترتيب فخاخ خاص به. نأخذ الفخ التالي من
             * الترتيب المخلوط بدل اختيار فخ عشوائي كل مرة، وعند بدء
             * جيم جديد يتم إنشاء ترتيب مختلف عن ترتيب الجيم السابق.
             */
            if (trapSequence.length === 0 || trapSequenceIndex >= trapSequence.length) {
                createTrapSequence();
            }

            this.type = trapSequence[trapSequenceIndex];
            trapSequenceIndex++;


            if (
                this.type === "spikes"
            ) {

                this.width = 56;

                this.height = 62;

                this.y =
                    floorY -
                    this.height;

            } else if (
                this.type === "bomb"
            ) {

                this.width = 30;

                this.height = 30;

                this.y =
                    floorY -
                    this.height;

            } else {

                this.width = 60;

                this.height =
                    canvas.height -
                    floorY;

                this.y = floorY;
            }
        }


        draw() {

            const biome =
                biomes[currentBiome];


            ctx.save();

            ctx.shadowBlur = 22;

            ctx.shadowColor =
                biome.obstacle;


            /* الأشواك */

            if (
                this.type === "spikes"
            ) {

                const baseY = floorY;
                const tipX = this.x + this.width / 2;
                const baseLeft = this.x;
                const baseRight = this.x + this.width;
                const tipY = this.y;

                /* شوكة واحدة مثلثية متساوية الساقين، بلون البايوم وتوهج نيون */
                const gradient = ctx.createLinearGradient(
                    tipX, tipY,
                    tipX, baseY
                );
                gradient.addColorStop(0, biome.obstacle);
                gradient.addColorStop(0.45, biome.obstacle);
                gradient.addColorStop(1, biome.obstacle);

                /* توهج نيون أخضر واضح للشوكة الجديدة */
                ctx.shadowColor = biome.obstacle;
                ctx.shadowBlur = 30;
                ctx.fillStyle = gradient;
                ctx.strokeStyle = biome.obstacle;
                ctx.lineWidth = 3;
                ctx.lineJoin = "round";

                ctx.beginPath();
                ctx.moveTo(baseLeft, baseY);
                ctx.lineTo(tipX, tipY);
                ctx.lineTo(baseRight, baseY);
                ctx.closePath();
                ctx.fill();
                ctx.stroke();

                /* حافة داخلية مضيئة تعطي مظهر النيون */
                ctx.shadowBlur = 12;
                ctx.strokeStyle = "#ffffff";
                ctx.globalAlpha = 0.38;
                ctx.lineWidth = 1.2;
                ctx.beginPath();
                ctx.moveTo(baseLeft + 3, baseY - 2);
                ctx.lineTo(tipX, tipY + 4);
                ctx.lineTo(baseRight - 3, baseY - 2);
                ctx.stroke();
            }


            /* القنبلة */

            else if (
                this.type === "bomb"
            ) {

                const r =
                    this.width / 2;

                const cx =
                    this.x + r;

                const cy =
                    this.y + r;


                ctx.fillStyle =
                    "#111916";

                ctx.strokeStyle =
                    biome.obstacle;

                ctx.lineWidth = 2;


                ctx.beginPath();

                ctx.arc(
                    cx,
                    cy,
                    r,
                    0,
                    Math.PI * 2
                );

                ctx.fill();

                ctx.stroke();

                ctx.closePath();


                ctx.strokeStyle =
                    "#84958d";

                ctx.beginPath();

                ctx.moveTo(
                    cx,
                    this.y
                );

                ctx.lineTo(
                    cx + 4,
                    this.y - 7
                );

                ctx.stroke();


                ctx.fillStyle =
                    "#ffcc00";

                ctx.beginPath();

                ctx.arc(
                    cx + 4,
                    this.y - 9,
                    3,
                    0,
                    Math.PI * 2
                );

                ctx.fill();

                ctx.closePath();
            }


            /* الحمض */

            else {

                ctx.fillStyle =
                    "#03100a";

                ctx.fillRect(
                    this.x,
                    floorY,
                    this.width,
                    this.height
                );


                ctx.shadowBlur = 22;

                ctx.shadowColor =
                    biome.acid;

                ctx.fillStyle =
                    biome.acid;


                ctx.fillRect(
                    this.x + 2,
                    floorY + 2,
                    this.width - 4,
                    this.height
                );


                ctx.beginPath();

                ctx.moveTo(
                    this.x,
                    floorY + 3
                );

                ctx.lineTo(
                    this.x + 10,
                    floorY - 1
                );

                ctx.lineTo(
                    this.x + 20,
                    floorY + 3
                );

                ctx.lineTo(
                    this.x + 31,
                    floorY - 1
                );

                ctx.lineTo(
                    this.x + 43,
                    floorY + 3
                );

                ctx.lineTo(
                    this.x + this.width,
                    floorY - 1
                );

                ctx.lineTo(
                    this.x + this.width,
                    floorY + 8
                );

                ctx.lineTo(
                    this.x,
                    floorY + 8
                );

                ctx.closePath();

                ctx.fill();

                /* لمعان الحمض يتبع لون البايوم */
                ctx.shadowBlur = 10;
                ctx.strokeStyle = "#ffffff";
                ctx.globalAlpha = 0.28;
                ctx.lineWidth = 1.2;
                ctx.stroke();
            }


            ctx.restore();
        }
    }


    /* =====================================================
       منصة السرعة
    ===================================================== */

    class SpeedPad {

        constructor() {

            this.width = 45;

            this.height = 7;

            this.x =
                canvas.width + 50;

            this.y =
                floorY -
                this.height;

            this.triggered = false;
        }


        draw() {

            ctx.save();

            ctx.shadowBlur = 12;

            ctx.shadowColor =
                "#00e5ff";

            ctx.fillStyle =
                "#071c28";

            ctx.strokeStyle =
                "#00e5ff";

            ctx.lineWidth = 2;


            ctx.beginPath();

            ctx.roundRect(
                this.x,
                this.y,
                this.width,
                this.height,
                3
            );

            ctx.fill();

            ctx.stroke();

            ctx.restore();
        }
    }


    /* =====================================================
       الخلفية
    ===================================================== */

    function drawEnvironment() {

        const biome =
            biomes[currentBiome];


        ctx.fillStyle =
            biome.sky;

        ctx.fillRect(
            0,
            0,
            canvas.width,
            canvas.height
        );


        ctx.fillStyle =
            biome.floor;

        ctx.fillRect(
            0,
            floorY,
            canvas.width,
            canvas.height -
            floorY
        );


        ctx.save();

        ctx.shadowBlur = 15;

        ctx.shadowColor =
            biome.accent;

        ctx.strokeStyle =
            biome.accent;

        ctx.lineWidth = 4;


        ctx.beginPath();

        ctx.moveTo(
            0,
            floorY
        );

        ctx.lineTo(
            canvas.width,
            floorY
        );

        ctx.stroke();

        ctx.restore();
    }


    /* =====================================================
       التصادم
    ===================================================== */

    function pointInTriangle(px, py, ax, ay, bx, by, cx, cy) {

        const v0x = cx - ax;
        const v0y = cy - ay;
        const v1x = bx - ax;
        const v1y = by - ay;
        const v2x = px - ax;
        const v2y = py - ay;

        const dot00 = v0x * v0x + v0y * v0y;
        const dot01 = v0x * v1x + v0y * v1y;
        const dot02 = v0x * v2x + v0y * v2y;
        const dot11 = v1x * v1x + v1y * v1y;
        const dot12 = v1x * v2x + v1y * v2y;

        const denom = dot00 * dot11 - dot01 * dot01;
        if (Math.abs(denom) < 0.000001) return false;

        const invDenom = 1 / denom;
        const u = (dot11 * dot02 - dot01 * dot12) * invDenom;
        const v = (dot00 * dot12 - dot01 * dot02) * invDenom;

        return u >= 0 && v >= 0 && u + v <= 1;
    }


    function checkCollision(obstacle) {

        const playerLeft = player.x + 5;
        const playerRight = player.x + player.width - 5;
        const playerTop = player.y + 4;
        const playerBottom = player.y + player.height - 3;

        const obstacleLeft = obstacle.x;
        const obstacleRight = obstacle.x + obstacle.width;

        /* الفخ المثلثي: لا يوجد اصطدام وهمي بسبب المربع المحيط بالمثلث. */
        if (obstacle.type === "spikes") {

            const tipX = obstacle.x + obstacle.width / 2;
            const tipY = obstacle.y;
            const baseY = floorY;

            if (playerRight <= obstacleLeft || playerLeft >= obstacleRight) {
                return false;
            }

            /* إذا كان أسفل اللاعب أعلى من رأس الفخ، فهو آمن. */
            if (playerBottom <= tipY + 2) {
                return false;
            }

            /* نقاط زوايا اللاعب مع اختبار مساحة المثلث. */
            const corners = [
                [playerLeft, playerTop],
                [playerRight, playerTop],
                [playerLeft, playerBottom],
                [playerRight, playerBottom]
            ];

            for (const [px, py] of corners) {
                if (pointInTriangle(
                    px, py,
                    obstacleLeft, baseY,
                    tipX, tipY,
                    obstacleRight, baseY
                )) {
                    return true;
                }
            }

            /* عند عبور الحافة، نتحقق من ارتفاع المثلث عند موضع اللاعب. */
            const sampleX = Math.max(
                obstacleLeft,
                Math.min(tipX, (playerLeft + playerRight) / 2)
            );

            const halfWidth = obstacle.width / 2;
            const normalizedX = Math.abs(sampleX - tipX) / halfWidth;
            const triangleYAtX =
                tipY + normalizedX * (baseY - tipY);

            return (
                playerBottom > triangleYAtX + 2 &&
                playerTop < baseY
            );
        }

        /* الأنواع القديمة لا تُنشأ الآن، لكن نُبقي التصادم الآمن لها. */
        if (obstacle.type === "acid") {
            return (
                playerRight > obstacleLeft &&
                playerLeft < obstacleRight &&
                playerBottom >= floorY - 6
            );
        }

        return (
            playerRight > obstacleLeft &&
            playerLeft < obstacleRight &&
            playerBottom > obstacle.y &&
            playerTop < obstacle.y + obstacle.height
        );
    }

    /* =====================================================
       تأثير الموت
    ===================================================== */

    function deathEffectFor(
        obstacle
    ) {

        const x =
            player.x +
            player.width / 2;

        const y =
            player.y +
            player.height / 2;


        if (
            obstacle.type === "bomb"
        ) {

            bombExplosion(
                x,
                y
            );

        } else if (
            obstacle.type === "acid"
        ) {

            acidMeltEffect(
                x,
                y
            );

        } else {

            spikeBreakEffect(
                x,
                y
            );
        }
    }


    /* =====================================================
       تحديث الجزيئات
    ===================================================== */

    function updateParticles() {

        for (
            let i =
                particles.length - 1;

            i >= 0;

            i--
        ) {

            particles[i].update();

            particles[i].draw();


            if (
                particles[i].life <= 0
            ) {

                particles.splice(
                    i,
                    1
                );
            }
        }
    }


    /* =====================================================
       زر التوقيف
    ===================================================== */

    function togglePause() {

        if (!gameActive)
            return;


        paused =
            !paused;


        pauseBtn.textContent =
            paused
                ? "استئناف"
                : "توقف";
    }


    /* =====================================================
       نهاية اللعبة
    ===================================================== */

    function gameOver(
        obstacle
    ) {

        if (!gameActive)
            return;


        gameActive = false;


        /*
            تشغيل تأثير واحد فقط
            ونترك حلقة الرسم تعمل حتى يكتمل الانفجار.
        */

        deathEffectFor(
            obstacle
        );

        /* بدء عرض تأثير الموت حتى بعد توقف اللعب */
        animationId = requestAnimationFrame(gameLoop);


        if (
            !gameOverSoundPlayed
        ) {

            gameOverSoundPlayed = true;

            playSound(
                "gameover"
            );
        }


        const oldHigh =
            Number(
                localStorage.getItem(
                    "onezero_highScore"
                )
            ) || 0;


        if (
            score > oldHigh
        ) {

            localStorage.setItem(
                "onezero_highScore",
                String(score)
            );
        }


        const high =
            Math.max(
                score,
                oldHigh
            );


        finalScoreElement.textContent =
            score;

        highScoreElement.textContent =
            high;


        /*
            إخفاء النتيجة من واجهة اللعبة
        */

        scoreDisplay.classList.add(
            "hidden"
        );

        pauseBtn.classList.add(
            "hidden"
        );

        biomeNameElement.classList.add(
            "hidden"
        );


        /*
            إظهار شاشة الخسارة
        */

        setTimeout(() => {

            gameOverScreen.classList.remove(
                "hidden"
            );

        }, 350);
    }


    /* =====================================================
       العودة للصفحة الرئيسية
    ===================================================== */

    function goHome() {

        gameActive = false;

        paused = false;


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );

            animationId = null;
        }


        obstacles = [];

        particles = [];

        effects = [];

        speedPads = [];


        gameOverScreen.classList.add(
            "hidden"
        );

        victoryScreen.classList.add(
            "hidden"
        );


        scoreDisplay.classList.add(
            "hidden"
        );

        pauseBtn.classList.add(
            "hidden"
        );

        biomeNameElement.classList.add(
            "hidden"
        );


        startScreen.classList.remove(
            "hidden"
        );
    }


    /* =====================================================
       الفوز
    ===================================================== */

    function victory() {

        gameActive = false;


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );

            animationId = null;
        }


        scoreDisplay.classList.add(
            "hidden"
        );

        pauseBtn.classList.add(
            "hidden"
        );

        biomeNameElement.classList.add(
            "hidden"
        );


        victoryScreen.classList.remove(
            "hidden"
        );
    }


    /* =====================================================
       بدء اللعبة
    ===================================================== */

    function startGame() {

        initAudio();


        if (animationId) {

            cancelAnimationFrame(
                animationId
            );
        }


        startScreen.classList.add(
            "hidden"
        );

        gameOverScreen.classList.add(
            "hidden"
        );

        victoryScreen.classList.add(
            "hidden"
        );


        scoreDisplay.classList.remove(
            "hidden"
        );

        pauseBtn.classList.remove(
            "hidden"
        );

        biomeNameElement.classList.remove(
            "hidden"
        );


        score = 0;

        frame = 0;

        gameSpeed = 5.5;

        obstacles = [];

        particles = [];

        effects = [];

        speedPads = [];

        currentBiome = 0;

        nextSpeedPad = 100;

        speedBoost = false;

        speedBoostTimer = 0;

        paused = false;

        gameActive = true;

        gameOverSoundPlayed = false;

        // بداية جيم جديد = ترتيب فخاخ جديد مختلف عن الجيم السابق.
        createTrapSequence();


        scoreElement.textContent =
            "0";


        biomeNameElement.textContent =
            biomes[0].name;


        pauseBtn.textContent =
            "توقف";


        resizeCanvas();

        player.reset();

        gameLoop();
    }


    /* =====================================================
       حلقة اللعبة
    ===================================================== */

    function gameLoop() {

        /* بعد الموت نكمل رسم الانفجار والجزيئات فقط حتى يكتمل التأثير. */
        if (!gameActive) {
            if (effects.length || particles.length) {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                drawEnvironment();
                if (player.acidDissolving) {
                    player.draw();
                }
                updateEffects();
                updateParticles();
                animationId = requestAnimationFrame(gameLoop);
            } else {
                animationId = null;
            }
            return;
        }


        ctx.clearRect(
            0,
            0,
            canvas.width,
            canvas.height
        );


        drawEnvironment();

        updateEffects();

        updateParticles();

        player.update();

        player.draw();


        if (
            score >= 1000
        ) {

            victory();

            return;
        }


        if (!paused) {

            if (speedBoost) {

                gameSpeed =
                    5.5 +
                    score * .08 +
                    4.5;

                speedBoostTimer--;


                if (
                    speedBoostTimer <= 0
                ) {

                    speedBoost = false;
                }

            } else {

                gameSpeed =
                    5.5 +
                    score * .08;
            }


            const newBiome =
                Math.floor(
                    score / 7
                ) %
                biomes.length;


            if (
                newBiome !==
                currentBiome
            ) {

                currentBiome =
                    newBiome;

                biomeNameElement.textContent =
                    biomes[
                        currentBiome
                    ].name;
            }


            if (
                score >=
                nextSpeedPad &&
                speedPads.length === 0
            ) {

                speedPads.push(
                    new SpeedPad()
                );

                nextSpeedPad += 100;
            }


            const obstacleDelay =
                Math.max(
                    62,
                    Math.floor(
                        130 -
                        gameSpeed * 3
                    )
                );


            if (
                frame %
                obstacleDelay ===
                0
            ) {

                obstacles.push(
                    new Obstacle()
                );
            }
        }


        /* منصات السرعة */

        for (
            let i =
                speedPads.length - 1;

            i >= 0;

            i--
        ) {

            const pad =
                speedPads[i];


            if (!paused) {

                pad.x -=
                    gameSpeed;
            }


            pad.draw();


            if (
                player.x +
                player.width >
                pad.x &&

                player.x <
                pad.x +
                pad.width &&

                player.y +
                player.height >=
                pad.y &&

                !pad.triggered
            ) {

                pad.triggered = true;

                speedBoost = true;

                speedBoostTimer = 90;

                playSound("speed");


                createParticles(
                    pad.x + 20,
                    floorY,
                    "#00e5ff",
                    12,
                    .8,
                    2
                );
            }


            if (
                pad.x +
                pad.width <
                0
            ) {

                speedPads.splice(
                    i,
                    1
                );
            }
        }


        /* العقبات */

        for (
            let i =
                obstacles.length - 1;

            i >= 0;

            i--
        ) {

            const obstacle =
                obstacles[i];


            if (!paused) {

                obstacle.x -=
                    gameSpeed;
            }


            obstacle.draw();


            /*
                اصطدام اللاعب
            */

            if (
                checkCollision(
                    obstacle
                )
            ) {

                /*
                    نحذف العقبة فورًا
                    لمنع تكرار التأثير
                */

                obstacles.splice(
                    i,
                    1
                );


                gameOver(
                    obstacle
                );

                return;
            }


            /*
                احتساب النقاط
            */

            if (
                obstacle.x +
                obstacle.width <
                player.x &&

                !obstacle.passed &&

                !paused
            ) {

                score++;

                obstacle.passed = true;

                scoreElement.textContent =
                    score;
            }


            if (
                obstacle.x +
                obstacle.width <
                0
            ) {

                obstacles.splice(
                    i,
                    1
                );
            }
        }


        if (!paused) {

            frame++;
        }


        animationId =
            requestAnimationFrame(
                gameLoop
            );
    }


    /* =====================================================
       منع تكرار الإدخال
    ===================================================== */

    function canInput() {

        const now =
            performance.now();


        if (
            now - lastInput <
            120
        ) {

            return false;
        }


        lastInput = now;

        return true;
    }


    /* =====================================================
       اللمس
    ===================================================== */

    canvas.addEventListener(
        "pointerdown",
        () => {

            if (!canInput())
                return;

            initAudio();

            player.jump();
        },
        {
            passive: true
        }
    );


    /* =====================================================
       لوحة المفاتيح
    ===================================================== */

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.code === "Space" ||
                event.code === "ArrowUp"
            ) {

                event.preventDefault();


                if (!canInput())
                    return;


                initAudio();

                player.jump();
            }


            if (
                event.code === "KeyP"
            ) {

                if (!canInput())
                    return;


                togglePause();
            }
        }
    );


    /* =====================================================
       زر ابدأ
    ===================================================== */

    startBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            startGame();
        }
    );


    /* =====================================================
       زر إعادة المحاولة
    ===================================================== */

    restartBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            startGame();
        }
    );


    /* =====================================================
       زر Out بعد الخسارة
    ===================================================== */

    outBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            goHome();
        }
    );


    /* =====================================================
       زر Out بعد الفوز
    ===================================================== */

    victoryOutBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            goHome();
        }
    );


    /* =====================================================
       زر الفوز
    ===================================================== */

    victoryBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            startGame();
        }
    );


    /* =====================================================
       زر الإعدادات
    ===================================================== */

    settingsBtn.addEventListener(
        "click",
        event => {

            event.stopPropagation();

            settingsPanel.classList.remove(
                "hidden"
            );
        }
    );


    closeSettings.addEventListener(
        "click",
        () => {

            settingsPanel.classList.add(
                "hidden"
            );
        }
    );


    settingsPanel.addEventListener(
        "click",
        event => {

            if (
                event.target ===
                settingsPanel
            ) {

                settingsPanel.classList.add(
                    "hidden"
                );
            }
        }
    );


    /* =====================================================
       زر التوقف
    ===================================================== */

    pauseBtn.addEventListener(
        "click",
        () => {

            if (!canInput())
                return;

            initAudio();

            togglePause();
        }
    );


    /* =====================================================
       منع القائمة
    ===================================================== */

    canvas.addEventListener(
        "contextmenu",
        event => {
            event.preventDefault();
        }
    );


    /* =====================================================
       البداية
    ===================================================== */

    resizeCanvas();

    player.reset();

    scoreDisplay.classList.add(
        "hidden"
    );

    pauseBtn.classList.add(
        "hidden"
    );

    biomeNameElement.classList.add(
        "hidden"
    );

});