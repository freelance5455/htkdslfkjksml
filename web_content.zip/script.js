const statusLabel = document.getElementById("status");

// Emits controllerinput events within this page.
// These events do not send input to other Android apps.
function emitInput(button, pressed) {
  const name = button.dataset.key;
  button.dispatchEvent(new CustomEvent("controllerinput", {
    bubbles: true,
    detail: { button: name, pressed }
  }));

  statusLabel.textContent = pressed ? `PRESSED: ${name}` : "CONTROLLER READY";
}

document.querySelectorAll("[data-key]").forEach(button => {
  let isPressed = false;

  function press(event) {
    event.preventDefault();
    if (isPressed) return;
    isPressed = true;
    button.classList.add("active");
    emitInput(button, true);
  }

  function release(event) {
    if (event) event.preventDefault();
    if (!isPressed) return;
    isPressed = false;
    button.classList.remove("active");
    emitInput(button, false);
  }

  button.addEventListener("pointerdown", event => {
    try { button.setPointerCapture(event.pointerId); } catch (_) {}
    press(event);
  });

  button.addEventListener("pointerup", release);
  button.addEventListener("pointercancel", release);
  button.addEventListener("lostpointercapture", release);
  button.addEventListener("contextmenu", event => event.preventDefault());
});

// Touch joysticks: return to the center when released.
document.querySelectorAll(".joystick").forEach(joystick => {
  const stick = joystick.querySelector(".stick");
  let activePointer = null;

  function move(event) {
    const rect = joystick.getBoundingClientRect();
    let x = event.clientX - rect.left - rect.width / 2;
    let y = event.clientY - rect.top - rect.height / 2;

    const max = Math.min(rect.width, rect.height) * 0.27;
    const distance = Math.hypot(x, y);

    if (distance > max) {
      x = (x / distance) * max;
      y = (y / distance) * max;
    }

    stick.style.left = `calc(50% + ${x}px)`;
    stick.style.top = `calc(50% + ${y}px)`;
  }

  function reset() {
    activePointer = null;
    stick.style.left = "50%";
    stick.style.top = "50%";
  }

  joystick.addEventListener("pointerdown", event => {
    event.preventDefault();
    activePointer = event.pointerId;
    try { joystick.setPointerCapture(event.pointerId); } catch (_) {}
    move(event);
  });

  joystick.addEventListener("pointermove", event => {
    if (event.pointerId === activePointer) move(event);
  });

  joystick.addEventListener("pointerup", event => {
    if (event.pointerId === activePointer) reset();
  });

  joystick.addEventListener("pointercancel", reset);
  joystick.addEventListener("lostpointercapture", reset);
});
