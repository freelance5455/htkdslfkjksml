let items = JSON.parse(localStorage.getItem("hesabaty_items")) || [];
let history = JSON.parse(localStorage.getItem("hesabaty_history")) || [];

let selectedItemId = null;
let editingItemId = null;
let deletingItemId = null;

const grandTotal = document.getElementById("grandTotal");
const itemsContainer = document.getElementById("itemsContainer");
const historyContainer = document.getElementById("historyContainer");
const searchInput = document.getElementById("searchInput");

const itemModal = document.getElementById("itemModal");
const unitPriceModal = document.getElementById("unitPriceModal");
const cartonModal = document.getElementById("cartonModal");
const confirmModal = document.getElementById("confirmModal");

const itemName = document.getElementById("itemName");
const itemQuantity = document.getElementById("itemQuantity");
const itemPrice = document.getElementById("itemPrice");
const itemUnit = document.getElementById("itemUnit");

const itemPreviewTotal = document.getElementById("itemPreviewTotal");
const modalTitle = document.getElementById("modalTitle");

const toast = document.getElementById("toast");


// =========================
// تشغيل التطبيق
// =========================

document.addEventListener("DOMContentLoaded", () => {

  renderItems();
  renderHistory();
  updateGrandTotal();

});


// =========================
// حفظ البيانات
// =========================

function saveItems() {

  localStorage.setItem(
    "hesabaty_items",
    JSON.stringify(items)
  );

}

function saveHistory() {

  localStorage.setItem(
    "hesabaty_history",
    JSON.stringify(history)
  );

}


// =========================
// الإجمالي
// =========================

function calculateItemTotal(item) {

  return Number(item.quantity) * Number(item.price);

}


function calculateAllTotal() {

  return items.reduce((total, item) => {

    return total + calculateItemTotal(item);

  }, 0);

}


function updateGrandTotal() {

  if (selectedItemId !== null) {

    const selectedItem = items.find(
      item => item.id === selectedItemId
    );

    if (selectedItem) {

      grandTotal.textContent =
        calculateItemTotal(selectedItem).toFixed(2);

      return;

    }

  }

  grandTotal.textContent =
    calculateAllTotal().toFixed(2);

}


// =========================
// عرض الأصناف
// =========================

function renderItems() {

  const searchText =
    searchInput.value.trim().toLowerCase();

  const filteredItems = items.filter(item =>
    item.name.toLowerCase().includes(searchText)
  );

  if (filteredItems.length === 0) {

    itemsContainer.innerHTML = `
      <div class="empty-message">
        ${
          searchText
            ? "لا يوجد صنف بهذا الاسم"
            : "لا توجد أصناف حتى الآن"
        }
      </div>
    `;

    updateGrandTotal();

    return;
  }


  itemsContainer.innerHTML = filteredItems.map(item => {

    const total = calculateItemTotal(item);

    const selected =
      item.id === selectedItemId
        ? "selected"
        : "";

    return `

      <div
        class="item-card ${selected}"
        data-id="${item.id}"
      >

        <div class="item-main">

          <div class="item-info">

            <div class="item-name">
              ${escapeHtml(item.name)}
            </div>

            <div class="item-details">
              الكمية: ${item.quantity}
              ${escapeHtml(item.unit)}
              <br>
              سعر الوحدة: ${Number(item.price).toFixed(2)} جنيه
            </div>

          </div>

          <div class="item-total">
            ${total.toFixed(2)} جنيه
          </div>

        </div>

        <div class="item-actions">

          <button
            class="edit-btn"
            data-action="edit"
            data-id="${item.id}"
          >
            تعديل
          </button>

          <button
            class="delete-btn"
            data-action="delete"
            data-id="${item.id}"
          >
            حذف
          </button>

        </div>

      </div>

    `;

  }).join("");


  updateGrandTotal();

}


// =========================
// الضغط على الأصناف
// =========================

itemsContainer.addEventListener("click", function(event) {

  const actionButton =
    event.target.closest("[data-action]");

  if (actionButton) {

    const id =
      Number(actionButton.dataset.id);

    const action =
      actionButton.dataset.action;

    if (action === "edit") {

      openEditModal(id);

    }

    if (action === "delete") {

      openDeleteModal(id);

    }

    return;
  }


  const card =
    event.target.closest(".item-card");

  if (!card) return;

  const id =
    Number(card.dataset.id);

  if (selectedItemId === id) {

    selectedItemId = null;

  } else {

    selectedItemId = id;

  }

  renderItems();

});


// =========================
// إضافة صنف
// =========================

document
  .getElementById("addItemBtn")
  .addEventListener("click", () => {

    editingItemId = null;

    modalTitle.textContent =
      "إضافة صنف";

    itemName.value = "";
    itemQuantity.value = "";
    itemPrice.value = "";
    itemUnit.value = "قطعة";

    updatePreview();

    openModal(itemModal);

  });


// =========================
// تعديل صنف
// =========================

function openEditModal(id) {

  const item =
    items.find(item => item.id === id);

  if (!item) return;

  editingItemId = id;

  modalTitle.textContent =
    "تعديل الصنف";

  itemName.value = item.name;
  itemQuantity.value = item.quantity;
  itemPrice.value = item.price;
  itemUnit.value = item.unit;

  updatePreview();

  openModal(itemModal);

}


// =========================
// حفظ الصنف
// =========================

document
  .getElementById("saveItemBtn")
  .addEventListener("click", saveItem);


function saveItem() {

  const name =
    itemName.value.trim();

  const quantity =
    Number(itemQuantity.value);

  const price =
    Number(itemPrice.value);

  const unit =
    itemUnit.value;


  if (!name) {

    showToast("اكتب اسم الصنف");

    return;

  }


  if (!quantity || quantity <= 0) {

    showToast("اكتب كمية صحيحة");

    return;

  }


  if (price < 0 || isNaN(price)) {

    showToast("اكتب سعر صحيح");

    return;

  }


  if (editingItemId !== null) {

    const item =
      items.find(item =>
        item.id === editingItemId
      );

    if (item) {

      item.name = name;
      item.quantity = quantity;
      item.price = price;
      item.unit = unit;

    }

    showToast("تم تعديل الصنف");

  } else {

    const newItem = {

      id: Date.now(),

      name: name,

      quantity: quantity,

      price: price,

      unit: unit

    };

    items.push(newItem);

    showToast("تمت إضافة الصنف");

  }


  saveItems();

  closeModal(itemModal);

  renderItems();

  updateGrandTotal();

}


// =========================
// الحساب أثناء الكتابة
// =========================

itemQuantity.addEventListener(
  "input",
  updatePreview
);

itemPrice.addEventListener(
  "input",
  updatePreview
);


function updatePreview() {

  const quantity =
    Number(itemQuantity.value) || 0;

  const price =
    Number(itemPrice.value) || 0;

  const total =
    quantity * price;

  itemPreviewTotal.textContent =
    total.toFixed(2) + " جنيه";

}


// =========================
// حذف صنف
// =========================

function openDeleteModal(id) {

  const item =
    items.find(item => item.id === id);

  if (!item) return;

  deletingItemId = id;

  document.getElementById("confirmText").textContent =
    `هل تريد حذف "${item.name}"؟`;

  openModal(confirmModal);

}


document
  .getElementById("confirmYes")
  .addEventListener("click", () => {

    if (deletingItemId === null) return;

    items =
      items.filter(
        item => item.id !== deletingItemId
      );

    if (selectedItemId === deletingItemId) {

      selectedItemId = null;

    }

    saveItems();

    closeModal(confirmModal);

    renderItems();

    updateGrandTotal();

    showToast("تم حذف الصنف");

    deletingItemId = null;

  });


document
  .getElementById("confirmNo")
  .addEventListener("click", () => {

    closeModal(confirmModal);

    deletingItemId = null;

  });


// =========================
// البحث
// =========================

searchInput.addEventListener(
  "input",
  renderItems
);


// =========================
// حفظ الحساب في السجل
// =========================

document
  .getElementById("saveHistoryBtn")
  .addEventListener("click", () => {

    if (items.length === 0) {

      showToast("لا توجد أصناف لحفظها");

      return;

    }


    const total =
      calculateAllTotal();

    const record = {

      id: Date.now(),

      total: total,

      itemsCount: items.length,

      date: new Date().toLocaleString("ar-EG")

    };


    history.unshift(record);

    saveHistory();

    renderHistory();

    showToast("تم حفظ الحساب");

  });


// =========================
// عرض السجل
// =========================

function renderHistory() {

  if (history.length === 0) {

    historyContainer.innerHTML = `
      <div class="empty-message">
        لا يوجد سجل
      </div>
    `;

    return;

  }


  historyContainer.innerHTML =
    history.map(record => {

      return `

        <div class="history-card">

          <strong>
            ${Number(record.total).toFixed(2)} جنيه
          </strong>

          <small>
            ${record.itemsCount} أصناف
            •
            ${escapeHtml(record.date)}
          </small>

        </div>

      `;

    }).join("");

}


// =========================
// مسح السجل
// =========================

document
  .getElementById("clearHistoryBtn")
  .addEventListener("click", () => {

    if (history.length === 0) {

      showToast("السجل فارغ");

      return;

    }


    const confirmed =
      confirm("هل تريد مسح سجل الحسابات؟");

    if (!confirmed) return;

    history = [];

    saveHistory();

    renderHistory();

    showToast("تم مسح السجل");

  });


// =========================
// سعر الوحدة
// =========================

document
  .getElementById("unitPriceBtn")
  .addEventListener("click", () => {

    document.getElementById(
      "totalPriceInput"
    ).value = "";

    document.getElementById(
      "unitsInput"
    ).value = "";

    document.getElementById(
      "unitResult"
    ).textContent =
      "سعر الوحدة: 0.00 جنيه";

    openModal(unitPriceModal);

  });


document
  .getElementById("calculateUnitBtn")
  .addEventListener("click", () => {

    const total =
      Number(
        document.getElementById(
          "totalPriceInput"
        ).value
      );

    const units =
      Number(
        document.getElementById(
          "unitsInput"
        ).value
      );


    if (!total || total < 0) {

      showToast("اكتب السعر الإجمالي");

      return;

    }


    if (!units || units <= 0) {

      showToast("اكتب عدد الوحدات");

      return;

    }


    const result =
      total / units;


    document.getElementById(
      "unitResult"
    ).textContent =
      `سعر الوحدة: ${result.toFixed(2)} جنيه`;

  });


// =========================
// حساب الكراتين
// =========================

document
  .getElementById("cartonBtn")
  .addEventListener("click", () => {

    document.getElementById(
      "piecesInput"
    ).value = "";

    document.getElementById(
      "piecesPerCartonInput"
    ).value = "";

    document.getElementById(
      "cartonResult"
    ).textContent =
      "عدد الكراتين: 0";

    openModal(cartonModal);

  });


document
  .getElementById("calculateCartonBtn")
  .addEventListener("click", () => {

    const pieces =
      Number(
        document.getElementById(
          "piecesInput"
        ).value
      );

    const piecesPerCarton =
      Number(
        document.getElementById(
          "piecesPerCartonInput"
        ).value
      );


    if (!pieces || pieces < 0) {

      showToast("اكتب إجمالي القطع");

      return;

    }


    if (!piecesPerCarton || piecesPerCarton <= 0) {

      showToast(
        "اكتب عدد القطع في الكرتونة"
      );

      return;

    }


    const cartons =
      Math.floor(
        pieces / piecesPerCarton
      );

    const remaining =
      pieces % piecesPerCarton;


    let result =
      `عدد الكراتين: ${cartons}`;


    if (remaining > 0) {

      result +=
        ` | المتبقي: ${remaining} قطعة`;

    }


    document.getElementById(
      "cartonResult"
    ).textContent = result;

  });


// =========================
// فتح وإغلاق النوافذ
// =========================

function openModal(modal) {

  modal.classList.add("show");

}


function closeModal(modal) {

  modal.classList.remove("show");

}


document
  .querySelectorAll("[data-close]")
  .forEach(button => {

    button.addEventListener("click", () => {

      const modalId =
        button.dataset.close;

      const modal =
        document.getElementById(modalId);

      closeModal(modal);

    });

  });


document
  .querySelectorAll(".modal")
  .forEach(modal => {

    modal.addEventListener("click", event => {

      if (event.target === modal) {

        closeModal(modal);

      }

    });

  });


// =========================
// رسالة صغيرة
// =========================

let toastTimer;


function showToast(message) {

  toast.textContent = message;

  toast.classList.add("show");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {

    toast.classList.remove("show");

  }, 2200);

}


// =========================
// حماية عرض النص
// =========================

function escapeHtml(text) {

  const div =
    document.createElement("div");

  div.textContent = text;

  return div.innerHTML;

}