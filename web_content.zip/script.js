// 1. የገጽ ባህሪያት (Open Feature)
function openFeature(featureName) {
    alert("ወደ " + featureName + " እንኳን በደህና መጡ! ይህ ክፍል በቅርብ ቀን ሙሉ በሙሉ ይከፈታል።");
}

// 2. የ GPA Calculator ክፍል
function addCourseRow() {
    const courseList = document.getElementById("course-list");
    const newRow = document.createElement("div");
    newRow.className = "course-row";
    
    newRow.innerHTML = `
        <input type="text" placeholder="የኮርስ ስም" class="course-name">
        <input type="number" placeholder="Credit" class="course-credit" min="1" max="6">
        <select class="course-grade">
            <option value="4.0">A+ / A</option>
            <option value="3.75">A-</option>
            <option value="3.5">B+</option>
            <option value="3.0">B</option>
            <option value="2.75">B-</option>
            <option value="2.5">C+</option>
            <option value="2.0">C</option>
            <option value="1.75">C-</option>
            <option value="1.0">D</option>
            <option value="0.0">F</option>
        </select>
    `;
    
    courseList.appendChild(newRow);
}

function calculateGPA() {
    const credits = document.querySelectorAll(".course-credit");
    const grades = document.querySelectorAll(".course-grade");
    
    let totalPoints = 0;
    let totalCredits = 0;

    for (let i = 0; i < credits.length; i++) {
        const creditValue = parseFloat(credits[i].value);
        const gradeValue = parseFloat(grades[i].value);

        if (!isNaN(creditValue) && creditValue > 0) {
            totalPoints += creditValue * gradeValue;
            totalCredits += creditValue;
        }
    }

    const resultBox = document.getElementById("gpa-result");

    if (totalCredits > 0) {
        const gpa = (totalPoints / totalCredits).toFixed(2);
        resultBox.innerHTML = `የእርስዎ GPA፦ <span style="color: #28a745;">${gpa}</span> (ከ ${totalCredits} ክሬዲት አወር)`;
    } else {
        resultBox.innerHTML = "<span style='color: red;'>እባክዎን የትክክለኛ ክሬዲት አወር ያስገቡ!</span>";
    }
}

// 3. ፋይል በቀጥታ የማውረድ (Download) ክፍል 📥
function addDocument() {
    const titleInput = document.getElementById("doc-title");
    const courseInput = document.getElementById("doc-course");
    const deptInput = document.getElementById("doc-dept");

    const title = titleInput.value.trim();
    const course = courseInput.value.trim();
    const dept = deptInput.value.trim();

    // መረጃዎቹ ሙሉ መሆናቸውን ማረጋገጥ
    if (title === "" || course === "" || dept === "") {
        alert("እባክዎን ሁሉንም መረጃዎች በትክክል ይሙሉ!");
        return;
    }

    // የፋይሉን ይዘት ማዘጋጀት 📝
    const fileContent = `የፋይል ስም፦ ${title}\nኮርስ፦ ${course}\nዲፓርትመንት፦ ${dept}`;

    // Blob ፋይል መፍጠር 📄
    const blob = new Blob([fileContent], { type: "text/plain;charset=utf-8" });

    // የማውረጃ Link ማዘጋጀት 🔗
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${title}.txt`;

    // ፋይሉን ማውረድ 📥
    link.click();

    // ሳጥኖቹን ባዶ ማድረግ 🧹
    titleInput.value = "";
    courseInput.value = "";
    deptInput.value = "";
}


// 4. የ Quiz ጥያቄዎችን በ LocalStorage የማስቀመጥ እና የማሳየት ክፍል 📝

// ገጹ ሲከፈት የተጠበቁ ጥያቄዎችን ማሳየት
function loadQuizQuestions() {
    const quizList = document.getElementById("quiz-list");
    if (!quizList) return;

    const savedQuizzes = JSON.parse(localStorage.getItem("studySyncQuizzes")) || [];
    quizList.innerHTML = "";

    savedQuizzes.forEach((quiz) => {
        const quizCard = document.createElement("div");
        quizCard.style.cssText = "background: #f9f9f9; padding: 10px; margin-top: 10px; border-radius: 8px; text-align: left;";
        
        quizCard.innerHTML = `
            <p style="font-weight: bold; margin-bottom: 5px;">❓ ${quiz.question}</p>
            <p style="margin: 3px 0;">A) ${quiz.optA}</p>
            <p style="margin: 3px 0;">B) ${quiz.optB}</p>
            <p style="margin: 3px 0;">C) ${quiz.optC}</p>
            <p style="color: #28a745; font-size: 13px; margin-top: 5px;">✅ ትክክለኛ መልስ፦ አማራጭ ${quiz.correct}</p>
        `;
        quizList.appendChild(quizCard);
    });
}

// አዲስ ጥያቄ ጨምሮ Storage ውስጥ ማስቀመጥ
function addQuizQuestion() {
    const questionInput = document.getElementById("quiz-question");
    const optionA = document.getElementById("option-a");
    const optionB = document.getElementById("option-b");
    const optionC = document.getElementById("option-c");
    const correctAnswer = document.getElementById("correct-answer");

    const qText = questionInput.value.trim();
    const optA = optionA.value.trim();
    const optB = optionB.value.trim();
    const optC = optionC.value.trim();
    const correct = correctAnswer.value;

    if (qText === "" || optA === "" || optB === "" || optC === "" || correct === "") {
        alert("እባክዎን ጥያቄውን፣ ሁሉንም አማራጮች እና ትክክለኛውን መልስ ይሙሉ!");
        return;
    }

    // አዲሱን ጥያቄ ወደ Object መቀየር
    const newQuiz = {
        question: qText,
        optA: optA,
        optB: optB,
        optC: optC,
        correct: correct
    };

    // የነበሩትን ጥያቄዎች ከ LocalStorage ማውጣት እና አዲሱን መጨመር
    const savedQuizzes = JSON.parse(localStorage.getItem("studySyncQuizzes")) || [];
    savedQuizzes.push(newQuiz);
    
    // በ LocalStorage ውስጥ መልሶ ማስቀመጥ 💾
    localStorage.setItem("studySyncQuizzes", JSON.stringify(savedQuizzes));

    // ገጹን አድሶ ማሳየት
    loadQuizQuestions();

    // ሳጥኖቹን ማጽዳት 🧹
    questionInput.value = "";
    optionA.value = "";
    optionB.value = "";
    optionC.value = "";
    correctAnswer.value = "";
}

// ገጹ ሲከፈት ጥያቄዎች እንዲመጡ ጥሪ ማድረግ
window.addEventListener("DOMContentLoaded", loadQuizQuestions);

// 5. የ Campus Marketplace ክፍል 🛒

// ገጹ ሲከፈት የተጠበቁ እቃዎችን ማሳየት
function loadMarketItems() {
    const marketList = document.getElementById("market-list");
    if (!marketList) return;

    const savedItems = JSON.parse(localStorage.getItem("studySyncMarket")) || [];
    marketList.innerHTML = "";

    savedItems.forEach((item) => {
        const itemCard = document.createElement("div");
        itemCard.style.cssText = "background: #fdfdfd; border: 1px solid #eee; padding: 10px; margin-top: 10px; border-radius: 8px; text-align: left;";
        
        itemCard.innerHTML = `
            <p style="font-weight: bold; margin-bottom: 5px;">📦 ${item.name}</p>
            <p style="margin: 3px 0; color: #28a745; font-weight: bold;">💵 ዋጋ፦ ${item.price} ብር</p>
            <p style="margin: 3px 0; font-size: 13px;">📞 ደውለው ይግዙ፦ <a href="tel:${item.phone}" style="color: #007bff; text-decoration: none;">${item.phone}</a></p>
        `;
        marketList.appendChild(itemCard);
    });
}

// አዲስ እቃ ጨምሮ Storage ውስጥ ማስቀመጥ
function addMarketItem() {
    const nameInput = document.getElementById("item-name");
    const priceInput = document.getElementById("item-price");
    const phoneInput = document.getElementById("item-phone");

    const name = nameInput.value.trim();
    const price = priceInput.value.trim();
    const phone = phoneInput.value.trim();

    if (name === "" || price === "" || phone === "") {
        alert("እባክዎን ሁሉንም የእቃ መረጃዎች ይሙሉ!");
        return;
    }

    const newItem = {
        name: name,
        price: price,
        phone: phone
    };

    const savedItems = JSON.parse(localStorage.getItem("studySyncMarket")) || [];
    savedItems.push(newItem);
    
    localStorage.setItem("studySyncMarket", JSON.stringify(savedItems));

    loadMarketItems();

    // ሳጥኖቹን ማጽዳት 🧹
    nameInput.value = "";
    priceInput.value = "";
    phoneInput.value = "";
}

// ገጹ ሲከፈት የእቃዎች ዝርዝር እንዲመጣ ማድረግ
window.addEventListener("DOMContentLoaded", () => {
    loadQuizQuestions();
    loadMarketItems();
});
