const cv = document.getElementById("c");
const ctx = cv.getContext("2d");
const W = Math.min(window.innerWidth - 36, 400);
const H = Math.round(W * 1.55);
const DPR = Math.min(window.devicePixelRatio || 1, 3);
cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
cv.style.width = W + "px"; cv.style.height = H + "px";
ctx.scale(DPR, DPR);
const TAU = Math.PI * 2;
const FONT = 'Tahoma, "Segoe UI", system-ui, Arial, sans-serif';
const cx = W / 2, cy = H * 0.3, R = W * 0.19;
const BL = R * 0.85, HL = R * 0.6, BW = W * 0.03, KLEN = BL + HL, START_Y = H - KLEN - 24;
const $ = function(id){ return document.getElementById(id); };
const lvlEl = $("lvl"), scoreEl = $("score"), bestEl = $("best"), coinsEl = $("coins");

function load(k, d){ try { const v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
function save(k, v){ try { localStorage.setItem(k, String(v)); } catch (e) {} }
let best = parseInt(load("knifeBest", "0"), 10) || 0;
let coins = parseInt(load("knifeCoins", "0"), 10) || 0;
let owned = []; try { owned = JSON.parse(load("cocOwned", "[]")) || []; } catch (e) { owned = []; }
let equipped = load("cocSkin", "classic"), logEq = load("cocLog", "wood");
let soundOn = load("cocSound", "1") !== "0", vibOn = load("cocVib", "1") !== "0", showFps = load("cocShowFps", "1") !== "0";
let fpsCap = parseInt(load("cocFps", "60"), 10); if ([15, 30, 60].indexOf(fpsCap) < 0) fpsCap = 60;
let lang = load("cocLang", "ar") === "en" ? "en" : "ar";

/* ---------- languages ---------- */
const L = {
  ar: { level: "المرحلة", score: "النقاط", best: "أعلى نتيجة", tag: "ارمي السكاكين في الخشبة من غير ما تخبط!", shopBtn: "🛒 المتجر", settingsBtn: "⚙️ الإعدادات", lost: "خسرت!", menu: "القائمة الرئيسية", settingsT: "الإعدادات", shopT: "المتجر", sound: "🔊 الصوت", vib: "📳 الاهتزاز", showFps: "📊 إظهار الفريمات في اللعبة", fpsCap: "⏱️ عدد الفريمات (FPS)", lang: "🌐 اللغة", quit: "إنهاء اللعبة والرجوع للقائمة", hint: "اضغط على الشاشة أو مسطرة المسافة للرمي", tabKnives: "🔪 السكاكين", tabLogs: "🪵 الخشب", buy: "شراء", equip: "جهّز", remove: "شيل", equipped: "مجهّزة", need: "محتاج {n} COC كمان", bought: "اشتريت {n}! دوس جهّز", didEquip: "جهّزت {n}", didRemoveK: "رجّعت السكينة الكلاسيك", didRemoveL: "رجّعت الخشب العادي", bLevel: "المرحلة {n}", bClear: "ممتاز! المرحلة {n}", result: "وصلت للمرحلة {l} وجمعت {s} نقطة", resultLost: " وخسرت {c} COC" },
  en: { level: "Level", score: "Score", best: "Best", tag: "Throw knives into the log without hitting another!", shopBtn: "🛒 Shop", settingsBtn: "⚙️ Settings", lost: "You lost!", menu: "Main menu", settingsT: "Settings", shopT: "Shop", sound: "🔊 Sound", vib: "📳 Vibration", showFps: "📊 Show FPS in game", fpsCap: "⏱️ Frame rate (FPS)", lang: "🌐 Language", quit: "Quit to main menu", hint: "Tap the screen or press Space to throw", tabKnives: "🔪 Knives", tabLogs: "🪵 Logs", buy: "Buy", equip: "Equip", remove: "Remove", equipped: "Equipped", need: "You need {n} more COC", bought: "You bought {n}! Tap Equip", didEquip: "Equipped {n}", didRemoveK: "Back to the classic knife", didRemoveL: "Back to plain wood", bLevel: "Level {n}", bClear: "Great! Level {n}", result: "You reached level {l} with {s} points", resultLost: " and lost {c} COC" }
};
function T(k, o){
  let s = (L[lang] && L[lang][k]) || L.en[k] || k;
  if (o) s = s.replace(/\{(\w+)\}/g, function(m, key){ return o[key] !== undefined ? o[key] : m; });
  return s;
}

/* ---------- coin icon (shape: milled edge, "COC" inside) ---------- */
function coinSvg(s){
  const pts = [];
  for (let i = 0; i < 24; i++) { const a = i / 24 * TAU, r = i % 2 ? 46 : 50; pts.push((50 + Math.cos(a) * r).toFixed(1) + "," + (50 + Math.sin(a) * r).toFixed(1)); }
  return '<svg viewBox="0 0 100 100" width="' + s + '" height="' + s + '" aria-hidden="true"><polygon points="' + pts.join(" ") + '" fill="#f6c230" stroke="#9a6a08" stroke-width="4"/><circle cx="50" cy="50" r="35" fill="#ffd95e" stroke="#b07a0a" stroke-width="3"/><text x="50" y="59" text-anchor="middle" font-family="Arial,sans-serif" font-weight="800" font-size="25" fill="#8a5a05">COC</text></svg>';
}
function coinEl(s){ const e = document.createElement("span"); e.className = "ci"; e.innerHTML = coinSvg(s); return e; }
Array.prototype.forEach.call(document.querySelectorAll(".ci"), function(e){ e.innerHTML = coinSvg(e.parentNode && e.parentNode.className === "meta" ? 20 : 26); });

function refreshTop(){
  bestEl.textContent = best; $("bestH").textContent = best;
  coinsEl.textContent = coins; $("coinsH").textContent = coins; $("shopCoins").textContent = coins;
}
function setSwitch(id, on){ $(id).setAttribute("aria-checked", on ? "true" : "false"); }
function segSet(id, v){ Array.prototype.forEach.call($(id).children, function(b){ b.classList.toggle("on", b.getAttribute("data-v") === String(v)); }); }
function vib(ms){ if (!vibOn) return; try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} }

/* ---------- knife skins: own blade shape, guard and pommel ---------- */
const SKINS = [
  { id: "classic", n: { ar: "كلاسيك", en: "Classic" }, price: 0, shape: "hunt", guard: "bar", pommel: "ball", blade: ["#f4f8fb", "#cfd9e0", "#8fa1ad", "#bccad3"], line: "rgba(40,55,66,.5)", gold: ["#f6d36b", "#a97622"], grip: ["#a8512f", "#4f2111"], wrap: "rgba(25,10,4,.6)" },
  { id: "fire", n: { ar: "نارية 🔥", en: "Fire 🔥" }, price: 70, fx: "fire", shape: "flame", guard: "wing", pommel: "spike", blade: ["#fff3b0", "#ffb02e", "#e8481c", "#9c1d0b"], line: "rgba(90,15,0,.55)", gold: ["#ffd166", "#c0392b"], grip: ["#3a1208", "#170504"], wrap: "rgba(255,140,40,.5)" },
  { id: "ice", n: { ar: "ثلجية ❄️", en: "Ice ❄️" }, price: 70, fx: "ice", shape: "ice", guard: "spike", pommel: "diamond", blade: ["#ffffff", "#d6f3ff", "#7cc8ee", "#b6e6fa"], line: "rgba(20,90,140,.45)", gold: ["#e6fbff", "#7fc4e0"], grip: ["#2b6f9c", "#123d5e"], wrap: "rgba(220,245,255,.5)" },
  { id: "gold", n: { ar: "ذهبية", en: "Gold" }, price: 40, shape: "dagger", guard: "round", pommel: "disc", blade: ["#fff6c8", "#f4d35e", "#b98a14", "#e6c24a"], line: "rgba(90,60,0,.5)", gold: ["#fff0a0", "#a07010"], grip: ["#5a3a10", "#2a1704"], wrap: "rgba(20,10,0,.5)" },
  { id: "emerald", n: { ar: "زمرد", en: "Emerald" }, price: 40, shape: "kunai", guard: "none", pommel: "ring", blade: ["#e6fff0", "#6fe0a0", "#1f9a5a", "#4cc58a"], line: "rgba(5,70,35,.5)", gold: ["#d9f7e6", "#2a8a55"], grip: ["#1b5a3a", "#0b2a1b"], wrap: "rgba(0,20,10,.5)" },
  { id: "ruby", n: { ar: "ياقوت", en: "Ruby" }, price: 40, shape: "scim", guard: "wing", pommel: "ball", blade: ["#ffe3e6", "#ff6b81", "#b0182f", "#e0405a"], line: "rgba(90,0,15,.5)", gold: ["#ffd6dc", "#a01830"], grip: ["#4a0d1a", "#1f0409"], wrap: "rgba(20,0,5,.5)" },
  { id: "amethyst", n: { ar: "جمشت", en: "Amethyst" }, price: 40, shape: "stil", guard: "bar", pommel: "ring", blade: ["#f3e6ff", "#c08cf0", "#7a3fc0", "#a96be0"], line: "rgba(50,15,90,.5)", gold: ["#eadbff", "#6b36a8"], grip: ["#2f1a4d", "#140a24"], wrap: "rgba(10,0,20,.5)" },
  { id: "neon", n: { ar: "نيون", en: "Neon" }, price: 40, shape: "tech", guard: "spike", pommel: "diamond", blade: ["#eaffff", "#44f0ff", "#0aa0c0", "#2ad0e8"], line: "rgba(0,70,90,.5)", gold: ["#b8fbff", "#0a8aa8"], grip: ["#101a2a", "#05090f"], wrap: "rgba(60,230,255,.5)" },
  { id: "obsidian", n: { ar: "سوداء", en: "Obsidian" }, price: 40, shape: "saw", guard: "round", pommel: "spike", blade: ["#8d96a6", "#4a5262", "#1b2029", "#2c3340"], line: "rgba(0,0,0,.6)", gold: ["#c0c6d2", "#5a6272"], grip: ["#2a2a2a", "#0a0a0a"], wrap: "rgba(150,150,150,.4)" },
  { id: "rose", n: { ar: "وردية", en: "Rose" }, price: 40, shape: "leaf", guard: "wing", pommel: "heart", blade: ["#fff0f6", "#ffb3d1", "#e0568f", "#f78cb4"], line: "rgba(120,20,70,.45)", gold: ["#ffe0ee", "#c23b78"], grip: ["#7a2850", "#3a1228"], wrap: "rgba(40,0,20,.5)" },
  { id: "bolt", n: { ar: "برق ⚡", en: "Lightning ⚡" }, price: 40, shape: "bolt", guard: "spike", pommel: "diamond", blade: ["#ffffff", "#fff59d", "#ffd600", "#ffb300"], line: "rgba(120,80,0,.55)", gold: ["#fff9c4", "#f9a825"], grip: ["#37474f", "#0b1114"], wrap: "rgba(255,235,59,.5)" }
];
const LOGS = [
  { id: "wood", n: { ar: "خشب", en: "Wood" }, price: 0 },
  { id: "tomato", n: { ar: "طماطم 🍅", en: "Tomato 🍅" }, price: 100 },
  { id: "cheese", n: { ar: "جبنة 🧀", en: "Cheese 🧀" }, price: 100 },
  { id: "apple", n: { ar: "تفاحة 🍎", en: "Apple 🍎" }, price: 100 }
];
if (equipped !== "classic" && owned.indexOf(equipped) < 0) equipped = "classic";
if (logEq !== "wood" && owned.indexOf(logEq) < 0) logEq = "wood";
function skinById(id){ for (let i = 0; i < SKINS.length; i++) if (SKINS[i].id === id) return SKINS[i]; return SKINS[0]; }
function curSkin(){ return skinById(equipped); }

const EXT = { hunt: [-0.52, 0.6], dagger: [-0.9, 0.9], flame: [-0.85, 0.85], ice: [-0.85, 0.85], kunai: [-0.9, 0.9], scim: [-0.7, 0.5], stil: [-0.3, 0.3], tech: [-0.7, 0.7], saw: [-0.5, 0.6], leaf: [-0.7, 0.7], bolt: [-0.75, 0.6] };
function poly(c, pts){ c.moveTo(pts[0][0] * BL, pts[0][1] * BW); for (let i = 1; i < pts.length; i++) c.lineTo(pts[i][0] * BL, pts[i][1] * BW); }
function bladePath(c, sh){
  c.beginPath();
  if (sh === "hunt") { c.moveTo(0, 0); c.quadraticCurveTo(BL * 0.12, -BW * 0.42, BL * 0.35, -BW * 0.52); c.lineTo(BL, -BW * 0.52); c.lineTo(BL, BW * 0.6); c.lineTo(BL * 0.32, BW * 0.6); c.quadraticCurveTo(BL * 0.1, BW * 0.5, 0, 0); }
  else if (sh === "dagger") { c.moveTo(0, 0); c.quadraticCurveTo(BL * 0.35, -BW * 0.95, BL, -BW * 0.5); c.lineTo(BL, BW * 0.5); c.quadraticCurveTo(BL * 0.35, BW * 0.95, 0, 0); }
  else if (sh === "flame") {
    c.moveTo(0, 0);
    for (let i = 1; i <= 18; i++) { const u = i / 18, w = Math.min(1, u * 3.2); c.lineTo(u * BL, -(BW * 0.6 * w + BW * 0.22 * Math.sin(u * 17) * Math.min(1, u * 3))); }
    for (let i = 18; i >= 1; i--) { const u = i / 18, w = Math.min(1, u * 3.2); c.lineTo(u * BL, BW * 0.6 * w + BW * 0.22 * Math.sin(u * 17 + 2.2) * Math.min(1, u * 3)); }
  }
  else if (sh === "ice") poly(c, [[0, 0], [0.18, -0.45], [0.3, -0.3], [0.5, -0.78], [0.62, -0.52], [0.8, -0.85], [1, -0.55], [1, 0.55], [0.8, 0.7], [0.64, 0.45], [0.48, 0.72], [0.34, 0.32], [0.2, 0.42]]);
  else if (sh === "kunai") { c.moveTo(0, 0); c.quadraticCurveTo(BL * 0.3, -BW * 1.1, BL * 0.68, -BW * 0.7); c.lineTo(BL, -BW * 0.22); c.lineTo(BL, BW * 0.22); c.lineTo(BL * 0.68, BW * 0.7); c.quadraticCurveTo(BL * 0.3, BW * 1.1, 0, 0); }
  else if (sh === "scim") { c.moveTo(0, 0); c.quadraticCurveTo(BL * 0.5, -BW * 1.0, BL, -BW * 0.4); c.lineTo(BL, BW * 0.45); c.quadraticCurveTo(BL * 0.55, BW * 0.3, 0, 0); }
  else if (sh === "stil") poly(c, [[0, 0], [1, -0.3], [1, 0.3]]);
  else if (sh === "tech") poly(c, [[0, 0], [0.25, -0.6], [0.45, -0.35], [0.62, -0.7], [1, -0.5], [1, 0.5], [0.62, 0.7], [0.45, 0.35], [0.25, 0.6]]);
  else if (sh === "saw") {
    c.moveTo(0, 0); c.lineTo(BL * 0.18, -BW * 0.5); c.lineTo(BL, -BW * 0.5); c.lineTo(BL, BW * 0.6);
    for (let i = 0; i < 8; i++) { const x = BL - i * BL * 0.1; c.lineTo(x - BL * 0.05, BW * 0.22); c.lineTo(x - BL * 0.1, BW * 0.6); }
    c.lineTo(BL * 0.12, BW * 0.5);
  }
  else if (sh === "leaf") { c.moveTo(0, 0); c.bezierCurveTo(BL * 0.2, -BW * 0.95, BL * 0.7, -BW * 0.95, BL, -BW * 0.3); c.lineTo(BL, BW * 0.3); c.bezierCurveTo(BL * 0.7, BW * 0.95, BL * 0.2, BW * 0.95, 0, 0); }
  else poly(c, [[0, 0], [0.2, -0.5], [0.34, -0.28], [0.55, -0.75], [0.7, -0.4], [0.9, -0.62], [1, -0.45], [1, 0.45], [0.88, 0.5], [0.7, 0.28], [0.52, 0.6], [0.36, 0.2], [0.18, 0.4]]);
  c.closePath();
}
function drawGuard(c, kind){
  if (kind === "wing") { c.beginPath(); c.moveTo(BL, -BW * 1.15); c.lineTo(BL + BW * 0.6, -BW * 0.45); c.lineTo(BL + BW * 0.6, BW * 0.45); c.lineTo(BL, BW * 1.15); c.lineTo(BL + BW * 0.2, 0); c.closePath(); c.fill(); }
  else if (kind === "round") { c.beginPath(); c.ellipse(BL + BW * 0.22, 0, BW * 0.24, BW * 1.0, 0, 0, TAU); c.fill(); }
  else if (kind === "spike") { c.beginPath(); c.moveTo(BL, 0); c.lineTo(BL + BW * 0.35, -BW * 1.05); c.lineTo(BL + BW * 0.7, 0); c.lineTo(BL + BW * 0.35, BW * 1.05); c.closePath(); c.fill(); }
  else if (kind === "none") c.fillRect(BL, -BW * 0.55, BW * 0.3, BW * 1.1);
  else c.fillRect(BL, -BW * 0.8, BW * 0.45, BW * 1.6);
}
function drawPommel(c, kind, gb, sk){
  const x = BL + HL - BW * 0.55;
  c.fillStyle = gb;
  if (kind === "ring") { c.strokeStyle = gb; c.lineWidth = BW * 0.28; c.beginPath(); c.arc(x + BW * 0.1, 0, BW * 0.62, 0, TAU); c.stroke(); }
  else if (kind === "diamond") { c.beginPath(); c.moveTo(x - BW * 0.5, 0); c.lineTo(x, -BW * 0.7); c.lineTo(x + BW * 0.7, 0); c.lineTo(x, BW * 0.7); c.closePath(); c.fill(); }
  else if (kind === "spike") { c.beginPath(); c.moveTo(x - BW * 0.3, -BW * 0.55); c.lineTo(x + BW * 0.8, 0); c.lineTo(x - BW * 0.3, BW * 0.55); c.closePath(); c.fill(); }
  else if (kind === "heart") {
    c.beginPath(); c.arc(x - BW * 0.05, -BW * 0.32, BW * 0.36, 0, TAU); c.fill();
    c.beginPath(); c.arc(x - BW * 0.05, BW * 0.32, BW * 0.36, 0, TAU); c.fill();
    c.beginPath(); c.moveTo(x - BW * 0.1, -BW * 0.62); c.lineTo(x + BW * 0.8, 0); c.lineTo(x - BW * 0.1, BW * 0.62); c.closePath(); c.fill();
  }
  else if (kind === "disc") { c.beginPath(); c.arc(x, 0, BW * 0.78, 0, TAU); c.fill(); c.fillStyle = sk.grip[1]; c.beginPath(); c.arc(x, 0, BW * 0.3, 0, TAU); c.fill(); }
  else { c.beginPath(); c.arc(x, 0, BW * 0.6, 0, TAU); c.fill(); c.fillStyle = sk.grip[1]; c.beginPath(); c.arc(x, 0, BW * 0.22, 0, TAU); c.fill(); }
}
function drawKnife(c, tx, ty, ang, sk){
  c.save(); c.translate(tx, ty); c.rotate(ang);
  const ex = EXT[sk.shape], g = c.createLinearGradient(0, ex[0] * BW, 0, ex[1] * BW);
  g.addColorStop(0, sk.blade[0]); g.addColorStop(0.45, sk.blade[1]); g.addColorStop(0.5, sk.blade[2]); g.addColorStop(1, sk.blade[3]);
  bladePath(c, sk.shape); c.fillStyle = g; c.fill();
  c.strokeStyle = sk.line; c.lineWidth = 1; c.stroke();
  c.beginPath();
  if (sk.shape === "hunt") { c.moveTo(BL * 0.3, -BW * 0.12); c.lineTo(BL * 0.96, -BW * 0.12); c.stroke(); c.beginPath(); c.moveTo(BL * 0.2, -BW * 0.4); c.lineTo(BL, -BW * 0.4); c.strokeStyle = "rgba(255,255,255,.7)"; c.stroke(); }
  else { c.moveTo(BL * 0.22, 0); c.lineTo(BL * 0.97, 0); c.stroke(); }
  const gb = c.createLinearGradient(0, -BW * 1.1, 0, BW * 1.1); gb.addColorStop(0, sk.gold[0]); gb.addColorStop(1, sk.gold[1]);
  c.fillStyle = gb; drawGuard(c, sk.guard);
  const gh = c.createLinearGradient(0, -BW * 0.5, 0, BW * 0.5); gh.addColorStop(0, sk.grip[0]); gh.addColorStop(1, sk.grip[1]);
  c.fillStyle = gh; c.fillRect(BL + BW * 0.45, -BW * 0.5, HL - BW, BW);
  c.strokeStyle = sk.wrap; c.lineWidth = 1;
  for (let k = 1; k < 5; k++) { const x = BL + BW * 0.45 + (HL - BW) * k / 5; c.beginPath(); c.moveTo(x, -BW * 0.5); c.lineTo(x, BW * 0.5); c.stroke(); }
  drawPommel(c, sk.pommel, gb, sk);
  c.restore();
}
function preview(sk){
  const p = document.createElement("canvas"), pw = 130, ph = 44;
  p.width = pw * DPR; p.height = ph * DPR;
  const c = p.getContext("2d"); c.scale(DPR, DPR);
  const s = (pw - 16) / (KLEN + BW); c.translate(8, ph / 2); c.scale(s, s);
  drawKnife(c, 0, 0, 0, sk);
  return p;
}
let iconCache = null, iconId = "";
function knifeIcon(){
  const sk = curSkin();
  if (iconCache && iconId === sk.id) return iconCache;
  const w = 18, h = 62, p = document.createElement("canvas");
  p.width = w * DPR; p.height = h * DPR;
  const c = p.getContext("2d"); c.scale(DPR, DPR);
  const s = (h - 6) / (KLEN + BW); c.translate(w / 2, 3); c.scale(s, s);
  drawKnife(c, 0, 0, Math.PI / 2, sk);
  iconCache = p; iconId = sk.id;
  return p;
}

/* ---------- sound ---------- */
let ac = null;
function audio(){
  if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ac = null; } }
  if (ac && ac.state === "suspended") ac.resume();
  return ac;
}
function tone(a, type, f0, f1, t0, dur, vol){
  const o = a.createOscillator(), g = a.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t0); o.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
  g.gain.setValueAtTime(vol, t0); g.gain.exponentialRampToValueAtTime(0.001, t0 + dur);
  o.connect(g); g.connect(a.destination); o.start(t0); o.stop(t0 + dur + 0.02);
}
function noise(a, t0, dur, cutoff, vol){
  const len = Math.floor(a.sampleRate * dur), buf = a.createBuffer(1, len, a.sampleRate), d = buf.getChannelData(0);
  for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
  const n = a.createBufferSource(), f = a.createBiquadFilter(), g = a.createGain();
  n.buffer = buf; f.type = "lowpass"; f.frequency.value = cutoff; g.gain.value = vol;
  n.connect(f); f.connect(g); g.connect(a.destination); n.start(t0);
}
function sfx(kind){
  if (!soundOn) return;
  const a = audio(); if (!a) return;
  const t0 = a.currentTime;
  if (kind === "hit") { noise(a, t0, 0.09, 1800, 0.8); tone(a, "triangle", 220, 70, t0, 0.14, 0.6); }
  else if (kind === "break") { noise(a, t0, 0.35, 2600, 1); tone(a, "triangle", 160, 40, t0, 0.3, 0.7); }
  else if (kind === "clink") { tone(a, "square", 1500, 900, t0, 0.18, 0.12); tone(a, "square", 2300, 1400, t0, 0.14, 0.08); }
  else if (kind === "coin") { tone(a, "square", 988, 988, t0, 0.08, 0.1); tone(a, "square", 1319, 1319, t0 + 0.08, 0.16, 0.1); }
  else if (kind === "whoosh") tone(a, "sawtooth", 500, 180, t0, 0.12, 0.03);
}

/* ---------- logs: wood (changes every level) + fruit skins ---------- */
const SHAPES = [
  function(){ return 1; },
  function(a){ return Math.sin(16 * a) > 0 ? 1 : 0.93; },
  function(a){ const s = TAU / 8, m = ((a % s) + s) % s - s / 2; return Math.cos(s / 2) / Math.cos(m); },
  function(a){ return 0.94 + 0.06 * Math.cos(8 * a); },
  function(a){ return 0.93 + 0.07 * Math.abs(Math.sin(5 * a)); }
];
const PALS = [
  { bark: ["#6b4426", "#33200f"], face: ["#efc684", "#d59a56", "#b97b3a"], ring: "120,70,28" },
  { bark: ["#5e2a24", "#2b0e0c"], face: ["#f4b3a3", "#da7660", "#ab4533"], ring: "125,40,28" },
  { bark: ["#34502d", "#16240f"], face: ["#d4eaa0", "#a2c966", "#75a03c"], ring: "55,95,25" },
  { bark: ["#4a3262", "#20122f"], face: ["#e0c4f4", "#b087d6", "#8458b0"], ring: "85,45,125" },
  { bark: ["#27465e", "#101f2d"], face: ["#c4e6f7", "#86bddf", "#5389b8"], ring: "30,75,115" }
];
let look = { s: SHAPES[0], p: PALS[0] };
function setLook(n){ look = { s: SHAPES[(n - 1) % 5], p: PALS[(n - 1 + Math.floor((n - 1) / 5)) % 5] }; }
function pth(c, rr, k, fn){
  c.beginPath();
  for (let i = 0; i <= 192; i++) { const a = i / 192 * TAU, r = rr * k * fn(a), x = Math.cos(a) * r, y = Math.sin(a) * r; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
  c.closePath();
}
function drawWood(c, rr, lk){
  const fn = lk.s;
  const bark = c.createRadialGradient(0, 0, rr * 0.8, 0, 0, rr);
  bark.addColorStop(0, lk.p.bark[0]); bark.addColorStop(1, lk.p.bark[1]);
  c.fillStyle = bark; pth(c, rr, 1, fn); c.fill();
  c.strokeStyle = "rgba(0,0,0,.45)"; c.lineWidth = 1.5;
  for (let i = 0; i < 48; i++) { const a = i / 48 * TAU, l = rr * (0.04 + 0.03 * Math.sin(i * 2.3)), r2 = rr * fn(a); c.beginPath(); c.moveTo(Math.cos(a) * (r2 - l), Math.sin(a) * (r2 - l)); c.lineTo(Math.cos(a) * r2, Math.sin(a) * r2); c.stroke(); }
  const face = c.createRadialGradient(0, 0, rr * 0.05, 0, 0, rr * 0.93);
  face.addColorStop(0, lk.p.face[0]); face.addColorStop(0.6, lk.p.face[1]); face.addColorStop(1, lk.p.face[2]);
  c.fillStyle = face; pth(c, rr, 0.93, fn); c.fill();
  c.save(); pth(c, rr, 0.93, fn); c.clip();
  c.lineWidth = 1.6;
  for (let k = 1; k <= 8; k++) {
    const r1 = rr * (0.08 + k * 0.1);
    c.strokeStyle = "rgba(" + lk.p.ring + (k % 2 ? ",.55)" : ",.3)");
    c.beginPath();
    for (let i = 0; i <= 64; i++) { const a = i / 64 * TAU, r = r1 * (1 + 0.03 * Math.sin(3 * a + k * 1.7) + 0.02 * Math.sin(5 * a + k)); const x = Math.cos(a) * r, y = Math.sin(a) * r; if (i) c.lineTo(x, y); else c.moveTo(x, y); }
    c.closePath(); c.stroke();
  }
  c.strokeStyle = "rgba(40,20,5,.65)"; c.lineWidth = 1.8;
  [0.7, 2.5, 4.3].forEach(function(a){
    c.beginPath(); c.moveTo(Math.cos(a) * rr * 0.12, Math.sin(a) * rr * 0.12);
    for (let s = 1; s <= 4; s++) { const r = rr * (0.12 + s * 0.17), o = (s % 2 ? 1 : -1) * 0.05; c.lineTo(Math.cos(a + o) * r, Math.sin(a + o) * r); }
    c.stroke();
  });
  c.save(); c.translate(Math.cos(1.6) * rr * 0.5, Math.sin(1.6) * rr * 0.5);
  c.fillStyle = "rgba(60,30,8,.55)"; c.beginPath(); c.ellipse(0, 0, rr * 0.1, rr * 0.07, 0.5, 0, TAU); c.fill();
  c.strokeStyle = "rgba(30,15,4,.8)"; c.lineWidth = 1.5; c.beginPath(); c.ellipse(0, 0, rr * 0.05, rr * 0.035, 0.5, 0, TAU); c.stroke();
  c.restore();
  c.fillStyle = "rgba(50,25,8,.7)"; c.beginPath(); c.arc(0, 0, rr * 0.04, 0, TAU); c.fill();
  c.restore();
  c.strokeStyle = "rgba(0,0,0,.5)"; c.lineWidth = 2.5; pth(c, rr, 0.93, fn); c.stroke();
}
function drawTomato(c, rr){
  c.beginPath();
  for (let i = 0; i <= 120; i++) { const a = i / 120 * TAU, r = rr * (0.965 + 0.035 * Math.cos(5 * a)); if (i) c.lineTo(Math.cos(a) * r, Math.sin(a) * r); else c.moveTo(Math.cos(a) * r, Math.sin(a) * r); }
  c.closePath();
  const g = c.createRadialGradient(-rr * 0.2, -rr * 0.25, rr * 0.1, 0, 0, rr);
  g.addColorStop(0, "#ff6f5c"); g.addColorStop(0.6, "#e0301f"); g.addColorStop(1, "#9c1a10");
  c.fillStyle = g; c.fill(); c.strokeStyle = "#7a1209"; c.lineWidth = 2.5; c.stroke();
  c.strokeStyle = "rgba(110,15,8,.35)"; c.lineWidth = 1.6;
  for (let i = 0; i < 5; i++) { const a = i / 5 * TAU + 0.3; c.beginPath(); c.moveTo(Math.cos(a) * rr * 0.3, Math.sin(a) * rr * 0.3); c.quadraticCurveTo(Math.cos(a + 0.25) * rr * 0.6, Math.sin(a + 0.25) * rr * 0.6, Math.cos(a) * rr * 0.9, Math.sin(a) * rr * 0.9); c.stroke(); }
  c.beginPath();
  for (let i = 0; i < 10; i++) { const a = i / 10 * TAU - Math.PI / 2, r = i % 2 ? rr * 0.13 : rr * 0.4; if (i) c.lineTo(Math.cos(a) * r, Math.sin(a) * r); else c.moveTo(Math.cos(a) * r, Math.sin(a) * r); }
  c.closePath(); c.fillStyle = "#46a83f"; c.fill(); c.strokeStyle = "#256b22"; c.lineWidth = 2; c.stroke();
  c.fillStyle = "#2c7a28"; c.beginPath(); c.arc(0, 0, rr * 0.08, 0, TAU); c.fill();
}
const HOLES = [[0.5, 0.55, 0.11], [1.8, 0.35, 0.08], [2.9, 0.62, 0.13], [4.0, 0.5, 0.09], [5.2, 0.68, 0.1], [0.1, 0.2, 0.07], [3.6, 0.22, 0.06], [1.2, 0.8, 0.07], [4.7, 0.82, 0.08]];
function drawCheese(c, rr){
  const g = c.createRadialGradient(0, 0, rr * 0.1, 0, 0, rr);
  g.addColorStop(0, "#ffe98a"); g.addColorStop(0.7, "#f6c445"); g.addColorStop(1, "#e5a41f");
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, rr, 0, TAU); c.fill();
  c.strokeStyle = "#c9801a"; c.lineWidth = rr * 0.08; c.beginPath(); c.arc(0, 0, rr * 0.95, 0, TAU); c.stroke();
  HOLES.forEach(function(h){
    const x = Math.cos(h[0]) * rr * h[1], y = Math.sin(h[0]) * rr * h[1], r = rr * h[2];
    c.fillStyle = "#c98a14"; c.beginPath(); c.arc(x, y, r, 0, TAU); c.fill();
    c.fillStyle = "rgba(255,236,150,.8)"; c.beginPath(); c.arc(x - r * 0.2, y - r * 0.2, r * 0.6, 0, TAU); c.fill();
  });
}
function drawApple(c, rr){
  c.beginPath();
  for (let i = 0; i <= 120; i++) { const a = i / 120 * TAU, r = rr * (0.97 + 0.03 * Math.cos(2 * a)); if (i) c.lineTo(Math.cos(a) * r, Math.sin(a) * r); else c.moveTo(Math.cos(a) * r, Math.sin(a) * r); }
  c.closePath();
  const g = c.createRadialGradient(-rr * 0.2, -rr * 0.25, rr * 0.1, 0, 0, rr);
  g.addColorStop(0, "#ff7a6b"); g.addColorStop(0.6, "#d62a2a"); g.addColorStop(1, "#8f1414");
  c.fillStyle = g; c.fill(); c.strokeStyle = "#6e0f0f"; c.lineWidth = 2.5; c.stroke();
  c.strokeStyle = "rgba(255,255,255,.14)"; c.lineWidth = 2;
  for (let i = 0; i < 8; i++) { const a = i / 8 * TAU; c.beginPath(); c.moveTo(Math.cos(a) * rr * 0.35, Math.sin(a) * rr * 0.35); c.quadraticCurveTo(Math.cos(a + 0.2) * rr * 0.65, Math.sin(a + 0.2) * rr * 0.65, Math.cos(a) * rr * 0.88, Math.sin(a) * rr * 0.88); c.stroke(); }
  const d = c.createRadialGradient(0, 0, 0, 0, 0, rr * 0.3);
  d.addColorStop(0, "rgba(60,0,0,.65)"); d.addColorStop(1, "rgba(60,0,0,0)");
  c.fillStyle = d; c.beginPath(); c.arc(0, 0, rr * 0.3, 0, TAU); c.fill();
  c.strokeStyle = "#6b4423"; c.lineWidth = rr * 0.1; c.lineCap = "round"; c.beginPath(); c.moveTo(0, 0); c.lineTo(rr * 0.28, -rr * 0.2); c.stroke(); c.lineCap = "butt";
  c.save(); c.translate(rr * 0.28, -rr * 0.2); c.rotate(-0.6);
  c.fillStyle = "#4caf50"; c.strokeStyle = "#2e7d32"; c.lineWidth = 1.5; c.beginPath(); c.ellipse(rr * 0.16, 0, rr * 0.17, rr * 0.08, 0, 0, TAU); c.fill(); c.stroke();
  c.restore();
}
function drawSkin(c, rr, id, lk){
  if (id === "tomato") drawTomato(c, rr);
  else if (id === "cheese") drawCheese(c, rr);
  else if (id === "apple") drawApple(c, rr);
  else drawWood(c, rr, lk);
}
function logPreview(it){
  const p = document.createElement("canvas"), s = 84;
  p.width = s * DPR; p.height = s * DPR; p.style.width = s + "px";
  const c = p.getContext("2d"); c.scale(DPR, DPR); c.translate(s / 2, s / 2);
  drawSkin(c, s * 0.43, it.id, { s: SHAPES[0], p: PALS[0] });
  return p;
}
function chipCols(){
  if (logEq === "tomato") return ["#e0301f", "#ff8a7a"];
  if (logEq === "cheese") return ["#f6c445", "#ffe27a"];
  if (logEq === "apple") return ["#d62a2a", "#f6f0d0"];
  return [look.p.face[1], look.p.bark[0]];
}
function logFn(){ return logEq === "wood" ? look.s : SHAPES[0]; }

/* ---------- game ---------- */
let state = "home", stuck = [], rot = 0, t = 0, remaining = 0, total = 0, level = 1, score = 0;
let flying = null, fv = 0, fall = null, dyingT = 0, rec = 0, flash = 0, spawn = 1, broken = false;
let bannerK = "", bannerN = 0, bannerT = 0, last = 0, lastRes = null;
let coinFx = null, parts = [], debris = [], fk = [], shopOpen = false, setOpen = false, tab = "knives";
let fpsVal = 0, fpsAcc = 0, fpsCount = 0;
const bubbles = [];
for (let i = 0; i < 16; i++) bubbles.push({ x: Math.random() * W, y: Math.random() * H, r: 6 + Math.random() * 22, v: 8 + Math.random() * 18, a: 0.05 + Math.random() * 0.1 });
function paused(){ return shopOpen || setOpen; }
function norm(a){ a = a % TAU; return a < 0 ? a + TAU : a; }
function angDist(a, b){ const d = Math.abs(norm(a) - norm(b)); return Math.min(d, TAU - d); }
function easeOutBack(x){ const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); }
function setCoins(n){ coins = Math.max(0, n); save("knifeCoins", coins); refreshTop(); }

function burst(x, y, col, n, sq){
  for (let i = 0; i < n; i++) { const a = Math.random() * TAU, s = 70 + Math.random() * 170; parts.push({ x: x, y: y, vx: Math.cos(a) * s, vy: -Math.abs(Math.sin(a)) * s * 0.9 - 30, l: 0.5 + Math.random() * 0.3, m: 0.8, c: col, r: 1.8 + Math.random() * 2.4, sq: sq }); }
}
function ringFx(x, y){ parts.push({ ring: true, x: x, y: y, vx: 0, vy: 0, l: 0.3, m: 0.3, r: 0, c: "#fff" }); }
function trail(x, y, fx){
  const cols = fx === "fire" ? ["#ffd166", "#ff8a2b", "#e8481c"] : ["#ffffff", "#bdeaff", "#7cc8ee"];
  parts.push({ x: x + (Math.random() - 0.5) * BW, y: y, vx: (Math.random() - 0.5) * 30, vy: 40 + Math.random() * 60, l: 0.35, m: 0.35, c: cols[Math.floor(Math.random() * 3)], r: 2 + Math.random() * 3 });
}
function demo(){
  setLook(1); stuck = []; flying = null; fall = null; parts = []; debris = []; fk = []; coinFx = null; bannerT = 0;
  remaining = total = 0; broken = false; spawn = 1; state = "home";
  const n = 7;
  for (let i = 0; i < n; i++) stuck.push({ a: i / n * TAU + 0.3, s: SKINS[i % SKINS.length].id, p: 1 });
}
function startLevel(n){
  level = n; lvlEl.textContent = n; setLook(n);
  stuck = []; rot = 0; t = 0; flying = null; fall = null; rec = 0; broken = false; spawn = 0;
  const pre = Math.min(1 + n, 6);
  let tries = 0;
  while (stuck.length < pre && tries < 200) {
    tries++;
    const a = Math.random() * TAU;
    if (stuck.every(function(s){ return angDist(s.a, a) > 0.7; })) stuck.push({ a: a, s: "classic", p: 1 });
  }
  remaining = total = Math.min(5 + n, 11);
  bannerK = "bLevel"; bannerN = n; bannerT = 1;
  ringFx(cx, cy);
  state = "play";
}
function start(){
  audio();
  score = 0; scoreEl.textContent = 0;
  $("home").classList.add("hidden"); $("over").classList.add("hidden");
  debris = []; fk = [];
  startLevel(1);
}
function toMenu(){
  demo(); lvlEl.textContent = 1; scoreEl.textContent = 0;
  $("over").classList.add("hidden"); $("home").classList.remove("hidden");
}
function speed(){
  const base = 1.7 + Math.min(level, 8) * 0.15;
  if (level <= 2) return (level % 2 ? 1 : -1) * base;
  if (level <= 4) return (level % 2 ? 1 : -1) * base * (1 + 0.55 * Math.sin(t * 1.7));
  return base * 1.3 * Math.sin(t * 1.1 + 1) + (level % 2 ? 0.6 : -0.6);
}
function throwKnife(){
  if (paused() || state !== "play" || flying !== null || spawn < 0.7) return;
  audio(); sfx("whoosh");
  flying = START_Y; fv = H * 1.5;
}
function breakLog(){
  const N = 8, cols = chipCols();
  debris = [];
  for (let i = 0; i < N; i++) {
    const l0 = i / N * TAU, l1 = (i + 1) / N * TAU, mid = rot + (l0 + l1) / 2, sp = 140 + Math.random() * 160;
    debris.push({ l0: l0, l1: l1, x: 0, y: 0, vx: Math.cos(mid) * sp, vy: Math.sin(mid) * sp - 220, r: 0, vr: (Math.random() - 0.5) * 7, c: cols });
  }
  fk = stuck.map(function(k){
    const th = k.a + rot, dep = R * 0.95 + (R * 0.6 - R * 0.95) * easeOutBack(k.p), sp = 120 + Math.random() * 120;
    return { x: cx + Math.cos(th) * dep, y: cy + Math.sin(th) * dep, ang: th, vx: Math.cos(th) * sp, vy: Math.sin(th) * sp - 260, va: (Math.random() - 0.5) * 10, s: k.s };
  });
  stuck = []; broken = true; flash = 1; rec = 1.8;
  burst(cx, cy, cols[0], 26, true); burst(cx, cy, cols[1], 14, true); ringFx(cx, cy);
  sfx("break"); vib(60);
}
function resolve(){
  const a = norm(Math.PI / 2 - rot);
  const hit = stuck.some(function(s){ return angDist(s.a, a) < 0.3; });
  if (hit) {
    sfx("clink");
    fall = { y: cy + R, r: Math.PI / 2, vy: -250, vr: 6 };
    ringFx(cx, cy + R * 0.95); burst(cx, cy + R * 0.95, "#ffffff", 6);
    flying = null; state = "dying"; dyingT = 0;
    vib(120);
    return;
  }
  const sk = curSkin(), cc = chipCols();
  stuck.push({ a: a, s: sk.id, p: 0 }); flying = null;
  score++; scoreEl.textContent = score; remaining--; rec = 1;
  sfx("hit");
  ringFx(cx, cy + R * 0.95);
  burst(cx, cy + R * 0.95, cc[0], 10, true);
  burst(cx, cy + R * 0.95, cc[1], 5, true);
  burst(cx, cy + R * 0.95, sk.blade[2], 8);
  vib(15);
  if (remaining === 0) {
    const gain = 10;
    setCoins(coins + gain);
    coinFx = { n: gain, t: 1 };
    setTimeout(function(){ sfx("coin"); }, 250);
    state = "clear"; bannerK = "bClear"; bannerN = level + 1; bannerT = 1;
    breakLog();
    setTimeout(function(){ if (state === "clear") startLevel(level + 1); }, 1400);
  }
}
function showOverText(){
  if (!lastRes) return;
  $("overText").textContent = T("result", { l: lastRes.l, s: lastRes.s }) + (lastRes.lost ? T("resultLost", { c: lastRes.lost }) : "");
}
function over(){
  state = "over";
  if (score > best) { best = score; save("knifeBest", best); }
  const lost = Math.min(5, coins);
  setCoins(coins - lost);
  lastRes = { l: level, s: score, lost: lost };
  showOverText();
  $("over").classList.remove("hidden");
}
function update(dt){
  if (state === "play" || state === "dying") { t += dt; rot += speed() * dt; }
  else if (state === "home" || state === "over") rot += 0.5 * dt;
  if (spawn < 1) spawn = Math.min(1, spawn + dt * 2.4);
  if (state === "play" && flying !== null) {
    fv += H * 10 * dt; flying -= fv * dt;
    const sk = curSkin();
    if (sk.fx) { trail(cx, flying + KLEN, sk.fx); if (Math.random() < 0.6) trail(cx, flying + KLEN * 0.9, sk.fx); }
    if (flying <= cy + R * 0.95) resolve();
  }
  if (state === "dying") {
    dyingT += dt;
    fall.vy += 2200 * dt; fall.y += fall.vy * dt; fall.r += fall.vr * dt;
    if (dyingT > 0.7) over();
  }
  stuck.forEach(function(k){ if (k.p < 1) k.p = Math.min(1, k.p + dt * 5); });
  if (rec > 0) rec = Math.max(0, rec - dt * 4.5);
  if (flash > 0) flash = Math.max(0, flash - dt * 3);
  if (bannerT > 0) bannerT -= dt * 0.6;
  if (coinFx) { coinFx.t -= dt * 0.7; if (coinFx.t <= 0) coinFx = null; }
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i];
    p.l -= dt; p.x += p.vx * dt; p.y += p.vy * dt;
    if (!p.ring) p.vy += 420 * dt;
    if (p.l <= 0) parts.splice(i, 1);
  }
  for (let i = debris.length - 1; i >= 0; i--) {
    const d = debris[i];
    d.x += d.vx * dt; d.y += d.vy * dt; d.vy += 1100 * dt; d.r += d.vr * dt;
    if (cy + d.y > H + R * 2) debris.splice(i, 1);
  }
  for (let i = fk.length - 1; i >= 0; i--) {
    const k = fk[i];
    k.x += k.vx * dt; k.y += k.vy * dt; k.vy += 1100 * dt; k.ang += k.va * dt;
    if (k.y > H + KLEN * 2) fk.splice(i, 1);
  }
  bubbles.forEach(function(b){ b.y -= b.v * dt; if (b.y < -b.r) { b.y = H + b.r; b.x = Math.random() * W; } });
}
function coin(x, y, r){
  ctx.beginPath();
  for (let i = 0; i < 24; i++) { const a = i / 24 * TAU, q = i % 2 ? r * 0.92 : r, px = x + Math.cos(a) * q, py = y + Math.sin(a) * q; if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); }
  ctx.closePath();
  const g = ctx.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r);
  g.addColorStop(0, "#fff2a8"); g.addColorStop(1, "#d9990f");
  ctx.fillStyle = g; ctx.fill(); ctx.strokeStyle = "#9a6a08"; ctx.lineWidth = 2; ctx.stroke();
  ctx.lineWidth = 1.4; ctx.beginPath(); ctx.arc(x, y, r * 0.68, 0, TAU); ctx.stroke();
  ctx.fillStyle = "#8a5a05"; ctx.font = "800 " + Math.round(r * 0.62) + "px Arial, sans-serif"; ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.direction = "ltr";
  ctx.fillText("COC", x, y + 1); ctx.direction = "inherit"; ctx.textBaseline = "alphabetic";
}
function wedgeDraw(d){
  const fn = logFn(), n = 14;
  ctx.save(); ctx.translate(cx + d.x, cy + d.y); ctx.rotate(rot + d.r);
  ctx.beginPath(); ctx.moveTo(0, 0);
  for (let i = 0; i <= n; i++) { const a = d.l0 + (d.l1 - d.l0) * i / n; ctx.lineTo(Math.cos(a) * R * 0.97 * fn(a), Math.sin(a) * R * 0.97 * fn(a)); }
  ctx.closePath();
  ctx.fillStyle = d.c[0]; ctx.fill(); ctx.strokeStyle = "rgba(0,0,0,.4)"; ctx.lineWidth = 2; ctx.stroke();
  ctx.strokeStyle = d.c[1]; ctx.lineWidth = 5; ctx.beginPath();
  for (let i = 0; i <= n; i++) { const a = d.l0 + (d.l1 - d.l0) * i / n, x = Math.cos(a) * R * 0.94 * fn(a), y = Math.sin(a) * R * 0.94 * fn(a); if (i) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
  ctx.stroke();
  ctx.restore();
}
function draw(){
  ctx.clearRect(0, 0, W, H);
  bubbles.forEach(function(b){ ctx.globalAlpha = b.a; ctx.fillStyle = "#e8ffff"; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, TAU); ctx.fill(); });
  ctx.globalAlpha = 1;
  const glow = ctx.createRadialGradient(cx, cy, R * 0.4, cx, cy, R * 2.1);
  glow.addColorStop(0, "rgba(255,255,255,.2)"); glow.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = glow; ctx.fillRect(0, 0, W, cy + R * 2.2);
  ctx.save();
  if (rec > 0) ctx.translate(Math.sin(rec * 45) * 1.6 * Math.min(rec, 1.2), -rec * 5);
  if (!broken) {
    const s = spawn < 1 ? Math.max(0.05, easeOutBack(spawn)) : 1;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(s, s); ctx.translate(-cx, -cy);
    stuck.forEach(function(k){
      const th = k.a + rot, dep = R * 0.95 + (R * 0.6 - R * 0.95) * easeOutBack(k.p), q = Math.sin(k.p * 30) * 0.07 * (1 - k.p);
      drawKnife(ctx, cx + Math.cos(th) * dep, cy + Math.sin(th) * dep, th + q, skinById(k.s));
    });
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(rot); drawSkin(ctx, R, logEq, look); ctx.restore();
    ctx.restore();
  }
  debris.forEach(wedgeDraw);
  fk.forEach(function(k){ drawKnife(ctx, k.x, k.y, k.ang, skinById(k.s)); });
  const sk = curSkin();
  if (flying !== null) {
    for (let i = 3; i >= 1; i--) { ctx.globalAlpha = 0.2 / i; drawKnife(ctx, cx, flying + i * 20, Math.PI / 2, sk); }
    ctx.globalAlpha = 1;
    drawKnife(ctx, cx, flying, Math.PI / 2, sk);
  } else if (state === "play") drawKnife(ctx, cx, START_Y, Math.PI / 2, sk);
  if (fall) drawKnife(ctx, cx + (fall.r - Math.PI / 2) * 20, fall.y, fall.r, sk);
  parts.forEach(function(p){
    ctx.globalAlpha = Math.max(0, p.l / p.m);
    if (p.ring) { ctx.strokeStyle = "#fff"; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(p.x, p.y, 6 + (1 - p.l / p.m) * 38, 0, TAU); ctx.stroke(); }
    else { ctx.fillStyle = p.c; if (p.sq) ctx.fillRect(p.x - p.r, p.y - p.r, p.r * 2, p.r * 2); else { ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, TAU); ctx.fill(); } }
  });
  ctx.globalAlpha = 1;
  ctx.restore();
  if (flash > 0) { ctx.globalAlpha = flash * 0.4; ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, W, H); ctx.globalAlpha = 1; }
  if (total > 0) {
    const ic = knifeIcon();
    for (let i = 0; i < total; i++) { ctx.globalAlpha = i < remaining ? 1 : 0.22; ctx.drawImage(ic, 8, H - 14 - (i + 1) * 24, 10, 34); }
    ctx.globalAlpha = 1;
  }
  if (bannerT > 0) {
    ctx.globalAlpha = Math.min(1, bannerT);
    ctx.font = "800 26px " + FONT; ctx.textAlign = "center";
    const txt = T(bannerK, { n: bannerN });
    ctx.lineWidth = 6; ctx.strokeStyle = "rgba(5,40,60,.85)"; ctx.strokeText(txt, W / 2, H * 0.62);
    ctx.fillStyle = "#fff"; ctx.fillText(txt, W / 2, H * 0.62);
    if (coinFx) {
      const rise = (1 - coinFx.t) * 24;
      coin(W / 2 - 30, H * 0.72 - rise, 18);
      ctx.direction = "ltr"; ctx.font = "800 24px " + FONT; ctx.textAlign = "left";
      ctx.lineWidth = 5; ctx.strokeStyle = "rgba(60,35,0,.8)"; ctx.strokeText("+" + coinFx.n, W / 2 - 6, H * 0.72 - rise + 8);
      ctx.fillStyle = "#ffd95e"; ctx.fillText("+" + coinFx.n, W / 2 - 6, H * 0.72 - rise + 8);
      ctx.textAlign = "center"; ctx.direction = "inherit";
    }
    ctx.globalAlpha = 1;
  }
  if (showFps && (state === "play" || state === "clear" || state === "dying")) {
    ctx.fillStyle = "rgba(0,0,0,.4)";
    if (ctx.roundRect) { ctx.beginPath(); ctx.roundRect(8, 8, 74, 22, 11); ctx.fill(); } else ctx.fillRect(8, 8, 74, 22);
    ctx.fillStyle = fpsVal >= fpsCap * 0.85 ? "#7dffa8" : "#ffd166";
    ctx.font = "700 13px Arial, sans-serif"; ctx.textAlign = "center"; ctx.direction = "ltr";
    ctx.fillText(fpsVal + " FPS", 45, 24); ctx.direction = "inherit";
  }
}
function loop(ts){
  requestAnimationFrame(loop);
  const minDt = 1000 / fpsCap;
  if (ts - last < minDt - 2) return;
  const dt = Math.min(0.1, (ts - last) / 1000 || 0);
  last = ts;
  fpsAcc += dt; fpsCount++;
  if (fpsAcc >= 0.5) { fpsVal = Math.round(fpsCount / fpsAcc); fpsAcc = 0; fpsCount = 0; }
  if (!paused()) update(dt);
  draw();
}

/* ---------- shop ---------- */
let toastTimer = null;
function toast(s){
  $("toast").textContent = s;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ $("toast").textContent = ""; }, 2600);
}
function renderShop(){
  const grid = $("grid"), st = grid.scrollTop, isK = tab === "knives";
  grid.innerHTML = "";
  $("tabK").classList.toggle("on", isK); $("tabL").classList.toggle("on", !isK);
  (isK ? SKINS : LOGS).forEach(function(it){
    const cur = isK ? equipped : logEq, has = it.price === 0 || owned.indexOf(it.id) >= 0, on = cur === it.id;
    const card = document.createElement("div"); card.className = "card" + (on ? " on" : "");
    card.appendChild(isK ? preview(it) : logPreview(it));
    const nm = document.createElement("b"); nm.textContent = it.n[lang]; card.appendChild(nm);
    const btn = document.createElement("button");
    if (!has) { btn.className = "buy" + (coins < it.price ? " poor" : ""); btn.textContent = T("buy") + " " + it.price; btn.appendChild(coinEl(18)); btn.onclick = function(){ buy(it); }; }
    else if (on) {
      if (it.price === 0) { btn.textContent = T("equipped"); btn.disabled = true; }
      else { btn.textContent = T("remove"); btn.onclick = function(){ equip(isK ? "classic" : "wood", T(isK ? "didRemoveK" : "didRemoveL")); }; }
    } else { btn.textContent = T("equip"); btn.onclick = function(){ equip(it.id, T("didEquip", { n: it.n[lang] })); }; }
    card.appendChild(btn); grid.appendChild(card);
  });
  grid.scrollTop = st;
}
function buy(it){
  if (coins < it.price) { toast(T("need", { n: it.price - coins })); return; }
  setCoins(coins - it.price); owned.push(it.id); save("cocOwned", JSON.stringify(owned));
  sfx("coin"); toast(T("bought", { n: it.n[lang] }));
  renderShop();
}
function equip(id, m){
  if (tab === "knives") { equipped = id; save("cocSkin", id); } else { logEq = id; save("cocLog", id); }
  toast(m); renderShop();
}
function closeSettings(){ setOpen = false; $("settings").classList.add("hidden"); }
function closeShop(){ shopOpen = false; $("shop").classList.add("hidden"); }
function openShop(){ closeSettings(); shopOpen = true; renderShop(); $("shop").classList.remove("hidden"); }
function openSettings(){
  closeShop(); setOpen = true;
  $("quit").classList.toggle("hidden", !(state === "play" || state === "clear" || state === "dying"));
  $("settings").classList.remove("hidden");
}
function applyLang(){
  const ar = lang === "ar", de = document.documentElement;
  de.setAttribute("lang", lang); de.setAttribute("dir", ar ? "rtl" : "ltr");
  Array.prototype.forEach.call(document.querySelectorAll("[data-i18n]"), function(e){ e.textContent = T(e.getAttribute("data-i18n")); });
  segSet("segLang", lang);
  showOverText();
  if (shopOpen) renderShop();
}

$("shopBtn").addEventListener("click", openShop);
$("closeShop").addEventListener("click", closeShop);
$("setBtn").addEventListener("click", openSettings);
$("closeSet").addEventListener("click", closeSettings);
$("quit").addEventListener("click", function(){ closeSettings(); toMenu(); });
$("tabK").addEventListener("click", function(){ tab = "knives"; renderShop(); });
$("tabL").addEventListener("click", function(){ tab = "logs"; renderShop(); });
$("swSound").addEventListener("click", function(){ soundOn = !soundOn; save("cocSound", soundOn ? "1" : "0"); setSwitch("swSound", soundOn); if (soundOn) sfx("hit"); });
$("swVib").addEventListener("click", function(){ vibOn = !vibOn; save("cocVib", vibOn ? "1" : "0"); setSwitch("swVib", vibOn); vib(40); });
$("swFps").addEventListener("click", function(){ showFps = !showFps; save("cocShowFps", showFps ? "1" : "0"); setSwitch("swFps", showFps); });
Array.prototype.forEach.call($("segFps").children, function(b){ b.addEventListener("click", function(){ fpsCap = parseInt(b.getAttribute("data-v"), 10); save("cocFps", fpsCap); segSet("segFps", fpsCap); }); });
Array.prototype.forEach.call($("segLang").children, function(b){ b.addEventListener("click", function(){ lang = b.getAttribute("data-v"); save("cocLang", lang); applyLang(); }); });
$("playBtn").addEventListener("click", start);
$("again").addEventListener("click", start);
$("toMenu").addEventListener("click", toMenu);
cv.addEventListener("pointerdown", function(e){ e.preventDefault(); throwKnife(); });
document.addEventListener("keydown", function(e){ if (e.code === "Space") { e.preventDefault(); throwKnife(); } });

setSwitch("swSound", soundOn); setSwitch("swVib", vibOn); setSwitch("swFps", showFps); segSet("segFps", fpsCap);
refreshTop(); applyLang(); demo();
requestAnimationFrame(loop);

/* offline support: register the service worker (works when served over http/https or inside an installed app) */
if ("serviceWorker" in navigator) { window.addEventListener("load", function(){ navigator.serviceWorker.register("sw.js").catch(function(){}); }); }
