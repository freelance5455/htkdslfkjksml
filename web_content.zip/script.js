
const country = document.getElementById("country");
const amount = document.getElementById("amount");
const result = document.getElementById("result");
const symbol = document.getElementById("currency-symbol");
const rateDisplay = document.getElementById("rate");
const updateDisplay = document.getElementById("last-update");
const button = document.getElementById("convert-btn");
const error = document.getElementById("error");
const description = document.getElementById("result-description");

let rates = {};
let lastUpdated = null;

const currencyNames = {
    DZD: "الدينار الجزائري",
    EGP: "الجنيه المصري",
    SAR: "الريال السعودي"
};

// جلب أسعار العملات
async function getRates() {
    try {
        button.disabled = true;
        error.textContent = "";

        const response = await fetch(
            "https://open.er-api.com/v6/latest/USD"
        );

        if (!response.ok) {
            throw new Error("Network error");
        }

        const data = await response.json();

        if (data.result !== "success") {
            throw new Error("Exchange rate unavailable");
        }

        rates = data.rates;
        lastUpdated = new Date(data.time_last_update_utc);

        updateRateInfo();
        convertCurrency();

    } catch (err) {
        error.textContent = "تعذر تحميل أسعار الصرف. تحقق من اتصال الإنترنت.";
        rateDisplay.textContent = "غير متاح";
        updateDisplay.textContent = "فشل الاتصال";
    } finally {
        button.disabled = false;
    }
}

// تحديث معلومات السعر
function updateRateInfo() {
    const selected = country.value;
    const rate = rates[selected];

    if (!rate) return;

    rateDisplay.textContent =
        `1 USD = ${rate.toLocaleString("en-US")} ${selected}`;

    updateDisplay.textContent = lastUpdated
        ? lastUpdated.toLocaleString("ar-DZ")
        : "غير معروف";
}

// تحويل العملة
function convertCurrency() {
    const selected = country.value;
    const value = Number(amount.value);

    symbol.textContent = selected;
    error.textContent = "";

    if (!rates[selected]) {
        result.textContent = "$0.00";
        description.textContent = "انتظر تحميل أسعار الصرف ✨";
        return;
    }

    if (amount.value.trim() === "" || !Number.isFinite(value)) {
        result.textContent = "$0.00";
        description.textContent = "أدخل مبلغًا للبدء ✨";
        return;
    }

    if (value < 0) {
        result.textContent = "$0.00";
        error.textContent = "الرجاء إدخال مبلغ موجب.";
        return;
    }

    const exchangeRate = rates[selected];
    const converted = value / exchangeRate;

    result.textContent = converted.toLocaleString("en-US", {
        style: "currency",
        currency: "USD",
        maximumFractionDigits: 4
    });

    description.textContent =
        `${value.toLocaleString("en-US")} ${selected} تساوي بالدولار`;
}

// تغيير الدولة
country.addEventListener("change", () => {
    updateRateInfo();
    convertCurrency();
});

// التحويل عند الضغط
button.addEventListener("click", convertCurrency);

// التحويل أثناء الكتابة
amount.addEventListener("input", convertCurrency);

// تحميل الأسعار عند فتح التطبيق
getRates();

// تحديث الأسعار كل ساعة
setInterval(getRates, 60 * 60 * 1000);
