const phone = "51903118208";
const cards = [...document.querySelectorAll(".product-card")];

document.querySelectorAll(".plus, .minus").forEach(button => {
  button.addEventListener("click", () => {
    const count = button.parentElement.querySelector("span");
    let value = Number(count.textContent);
    value = button.classList.contains("plus") ? value + 1 : Math.max(0, value - 1);
    count.textContent = value;
    updateOrder();
  });
});

function updateOrder() {
  let units = 0, total = 0;
  cards.forEach(card => {
    const qty = Number(card.querySelector(".qty span").textContent);
    units += qty;
    total += qty * Number(card.dataset.price);
  });
  document.getElementById("selectionSummary").textContent = `${units} ${units === 1 ? "producto seleccionado" : "productos seleccionados"}`;
  document.getElementById("totalPrice").textContent = `Total referencial: S/ ${total.toFixed(2)}`;
}

document.getElementById("categoryFilters").addEventListener("click", event => {
  const button = event.target.closest("button[data-filter]");
  if (!button) return;
  document.querySelectorAll(".filter").forEach(item => item.classList.remove("active"));
  button.classList.add("active");
  cards.forEach(card => card.hidden = button.dataset.filter !== "todos" && card.dataset.category !== button.dataset.filter);
});

document.getElementById("orderButton").addEventListener("click", () => {
  const selected = cards.map(card => {
    const qty = Number(card.querySelector(".qty span").textContent);
    return qty ? {name: card.dataset.name, qty, price: Number(card.dataset.price)} : null;
  }).filter(Boolean);
  if (!selected.length) {
    alert("Selecciona al menos un producto antes de enviar tu pedido.");
    return;
  }
  const total = selected.reduce((sum, item) => sum + item.qty * item.price, 0);
  const lines = selected.map(item => `• ${item.name}: ${item.qty} x S/ ${item.price.toFixed(2)} = S/ ${(item.qty * item.price).toFixed(2)}`);
  const message = `Hola, deseo realizar este pedido en ESTAMPADOS & MODA ELIAM & GAEL:\n\n${lines.join("\n")}\n\nTotal referencial: S/ ${total.toFixed(2)}\n\nPor favor, confirmen disponibilidad y detalles.`;
  window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, "_blank");
});

const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => nav.classList.toggle("open"));
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => nav.classList.remove("open")));

const notices = [
  "¡Bienvenidos! Personalizamos tus ideas con estilo.",
  "Polos, gorras, termos, tomatodos, platos y tazas.",
  "¡Cotiza tu diseño directamente por WhatsApp!"
];
let noticeIndex = 0;
setInterval(() => {
  noticeIndex = (noticeIndex + 1) % notices.length;
  document.getElementById("notice").textContent = notices[noticeIndex];
}, 4500);
