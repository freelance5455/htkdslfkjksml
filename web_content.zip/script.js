import { initializeApp, getApps, getApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";

import {
  getAuth,
  signInWithEmailAndPassword,
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";

import {
  getFirestore,
  collection,
  getDocs
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";

// ===============================
// FIREBASE CONFIG
// ===============================

const firebaseConfig = {
  apiKey: "AIzaSyBpCzg5iSBzrNiStukqHeCsuOY-hkixoXI",
  authDomain: "bharati-fashions.firebaseapp.com",
  projectId: "bharati-fashions",
  storageBucket: "bharati-fashions.firebasestorage.app",
  messagingSenderId: "934450441927",
  appId: "1:934450441927:web:4b0507c39d4730a00218e2",
  measurementId: "G-TMTE2L0RC3"
};

// ===============================
// FIREBASE INITIALIZATION
// ===============================

const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

// Keep this list in sync with the authorized admin list in admin.html.
const ADMIN_EMAILS = ["sarkar.chandan2012@gmail.com"].map(email => email.toLowerCase());

// ===============================
// VARIABLES
// ===============================

let products = [];
let cart = [];
let activeCategory = "all";
let searchQuery = "";

// ===============================
// HELPER FUNCTIONS
// ===============================

function getElement(id) {
  return document.getElementById(id);
}

function getPrice(product) {
  const price = Number(product.price);
  return Number.isFinite(price) && price >= 0 ? price : 0;
}

function formatPrice(price) {
  return new Intl.NumberFormat("en-IN", {
    maximumFractionDigits: 2
  }).format(price);
}

function createElement(tag, className, text) {
  const element = document.createElement(tag);

  if (className) {
    element.className = className;
  }

  if (text !== undefined) {
    element.textContent = text;
  }

  return element;
}

// ===============================
// LOAD PRODUCTS
// ===============================

async function loadProducts() {
  const productList = getElement("productList");

  if (!productList) {
    console.error('Missing HTML element: "productList"');
    return;
  }

  productList.replaceChildren(
    createElement("div", "empty", "Loading products...")
  );

  try {
    const snapshot = await getDocs(collection(db, "products"));

    products = snapshot.docs.map((document) => ({
      id: document.id,
      ...document.data()
    }));

    console.log("Products loaded:", products);

    renderProducts();

  } catch (error) {
    console.error("Failed to load products:", error);

    productList.replaceChildren(
      createElement(
        "div",
        "empty",
        "Products load করা যায়নি। Internet connection এবং Firebase Firestore Rules চেক করুন।"
      )
    );
  }
}

// ===============================
// FILTER PRODUCTS
// ===============================

function getFilteredProducts() {
  return products.filter((product) => {
    const name = String(product.name || "").toLowerCase();
    const category = String(product.category || "").toLowerCase();

    const matchesSearch =
      name.includes(searchQuery) ||
      category.includes(searchQuery);

    const matchesCategory =
      activeCategory === "all" ||
      category === activeCategory.toLowerCase();

    return matchesSearch && matchesCategory;
  });
}

// ===============================
// DISPLAY PRODUCTS
// ===============================

function renderProducts() {
  const productList = getElement("productList");

  if (!productList) return;

  const filteredProducts = getFilteredProducts();

  productList.replaceChildren();

  if (filteredProducts.length === 0) {
    productList.appendChild(
      createElement("div", "empty", "No products found.")
    );
    return;
  }

  filteredProducts.forEach((product) => {
    const card = createElement("div", "product");
    let image;
    if (product.image && /^https?:\\/\\//i.test(String(product.image))) {
      image = createElement("img", "product-photo");
      image.src = String(product.image);
      image.alt = String(product.name || "Fashion product");
      image.loading = "lazy";
      image.onerror = () => {
        const fallback = createElement("div", "product-image", String(product.emoji || "👗"));
        image.replaceWith(fallback);
      };
    } else {
      image = createElement("div", "product-image", String(product.emoji || "👗"));
    }

    const info = createElement("div", "product-info");

    const name = createElement(
      "div",
      "product-name",
      String(product.name || "Product")
    );

    const category = createElement(
      "div",
      "product-category",
      String(product.category || "")
    );

    const price = createElement(
      "div",
      "product-price",
      `₹${formatPrice(getPrice(product))}`
    );

    const button = createElement(
      "button",
      "add-cart",
      "Add to Cart"
    );

    button.type = "button";

    // Avoid inline onclick and unsafe HTML interpolation.
    button.addEventListener("click", () => {
      window.addToCart(product.id);
    });

    info.append(name, category, price, button);
    card.append(image, info);
    productList.appendChild(card);
  });
}

// ===============================
// ADD TO CART
// ===============================

window.addToCart = function (id) {
  const product = products.find((item) => item.id === id);

  if (!product) {
    alert("Product not found.");
    return;
  }

  const existingItem = cart.find((item) => item.id === id);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({
      ...product,
      quantity: 1
    });
  }

  updateCart();
};

// ===============================
// UPDATE CART
// ===============================

function updateCart() {
  const cartCount = getElement("cartCount");
  const cartItems = getElement("cartItems");
  const cartTotal = getElement("cartTotal");

  if (!cartItems || !cartCount || !cartTotal) {
    console.error("One or more cart HTML elements are missing.");
    return;
  }

  const totalQuantity = cart.reduce(
    (sum, item) => sum + item.quantity,
    0
  );

  const totalPrice = cart.reduce(
    (sum, item) => sum + getPrice(item) * item.quantity,
    0
  );

  cartCount.textContent = totalQuantity;
  cartTotal.textContent = formatPrice(totalPrice);

  cartItems.replaceChildren();

  if (cart.length === 0) {
    cartItems.appendChild(
      createElement("div", "empty", "Your cart is empty.")
    );
    return;
  }

  cart.forEach((item) => {
    const row = createElement("div", "cart-item");
    const details = createElement("div");

    const name = createElement(
      "strong",
      "",
      String(item.name || "Product")
    );

    const price = createElement(
      "div",
      "",
      `₹${formatPrice(getPrice(item))} × ${item.quantity}`
    );

    const controls = createElement("div", "cart-controls");

    const decreaseButton = createElement(
      "button",
      "quantity-btn",
      "−"
    );

    decreaseButton.type = "button";
    decreaseButton.setAttribute("aria-label", "Decrease quantity");

    decreaseButton.addEventListener("click", () => {
      window.decreaseCartQuantity(item.id);
    });

    const quantity = createElement(
      "span",
      "cart-quantity",
      String(item.quantity)
    );

    const increaseButton = createElement(
      "button",
      "quantity-btn",
      "+"
    );

    increaseButton.type = "button";
    increaseButton.setAttribute("aria-label", "Increase quantity");

    increaseButton.addEventListener("click", () => {
      window.addToCart(item.id);
    });

    const removeButton = createElement(
      "button",
      "remove-btn",
      "Remove"
    );

    removeButton.type = "button";

    removeButton.addEventListener("click", () => {
      window.removeFromCart(item.id);
    });

    details.append(name, price);
    controls.append(
      decreaseButton,
      quantity,
      increaseButton,
      removeButton
    );

    row.append(details, controls);
    cartItems.appendChild(row);
  });
}

// ===============================
// CHANGE QUANTITY
// ===============================

window.decreaseCartQuantity = function (id) {
  const item = cart.find((product) => product.id === id);

  if (!item) return;

  item.quantity -= 1;

  if (item.quantity <= 0) {
    cart = cart.filter((product) => product.id !== id);
  }

  updateCart();
};

// ===============================
// REMOVE FROM CART
// ===============================

window.removeFromCart = function (id) {
  cart = cart.filter((item) => item.id !== id);
  updateCart();
};

// ===============================
// OPEN CART
// ===============================

window.openCart = function () {
  getElement("cartPanel")?.classList.add("active");
  getElement("cartOverlay")?.classList.add("active");
};

// ===============================
// CLOSE CART
// ===============================

window.closeCart = function () {
  getElement("cartPanel")?.classList.remove("active");
  getElement("cartOverlay")?.classList.remove("active");
};

// ===============================
// SEARCH PRODUCTS
// ===============================

window.searchProducts = function () {
  searchQuery = String(
    getElement("searchInput")?.value || ""
  ).trim().toLowerCase();

  renderProducts();
};

// ===============================
// CATEGORY FILTER
// ===============================

window.filterCategory = function (category) {
  activeCategory = String(category || "all").toLowerCase();

  renderProducts();
  window.scrollToProducts();
};

// ===============================
// SHOW ALL PRODUCTS
// ===============================

window.showAllProducts = function () {
  activeCategory = "all";
  searchQuery = "";

  const searchInput = getElement("searchInput");

  if (searchInput) {
    searchInput.value = "";
  }

  renderProducts();
};

// ===============================
// SCROLL TO PRODUCTS
// ===============================

window.scrollToProducts = function () {
  getElement("productsSection")?.scrollIntoView({
    behavior: "smooth"
  });
};

// ===============================
// CHECKOUT
// ===============================

window.checkout = function () {
  if (cart.length === 0) {
    alert("Your cart is empty!");
    return;
  }

  alert(
    "Checkout system is not connected yet. Please integrate a secure order and payment system."
  );
};

// ===============================
// ACCOUNT SETTINGS / FIREBASE AUTH
// ===============================

function setAccountMessage(message, isError = false) {
  const el = getElement("accountMessage");
  if (!el) return;
  el.textContent = message || "";
  el.classList.toggle("error", Boolean(isError));
}

function renderAccountUser(user) {
  const form = getElement("accountLoginForm");
  const signedIn = getElement("accountSignedIn");
  const status = getElement("accountStatus");
  const emailEl = getElement("accountUserEmail");
  const loginBtn = getElement("accountLoginButton");

  if (!form || !signedIn || !status) return;
  if (user && ADMIN_EMAILS.includes((user.email || "").toLowerCase())) {
    form.hidden = true;
    signedIn.hidden = false;
    status.textContent = "Admin account connected to Firebase.";
    if (emailEl) emailEl.textContent = user.email || "Admin";
  } else {
    form.hidden = false;
    signedIn.hidden = true;
    status.textContent = user
      ? "Signed in account is not authorized as an admin. Please use the authorized admin account."
      : "Not signed in. Admins can log in below.";
    if (loginBtn) loginBtn.disabled = false;
  }
}

window.showAccount = function () {
  getElement("account-popup")?.classList.add("show");
  setAccountMessage("");
};

window.closeAccount = function () {
  getElement("account-popup")?.classList.remove("show");
};

const accountLoginForm = getElement("accountLoginForm");
if (accountLoginForm) {
  accountLoginForm.addEventListener("submit", async event => {
    event.preventDefault();
    const button = getElement("accountLoginButton");
    const email = getElement("accountEmail").value.trim().toLowerCase();
    const password = getElement("accountPassword").value;
    if (!ADMIN_EMAILS.includes(email)) {
      setAccountMessage("This email is not on the authorized admin list.", true);
      return;
    }
    button.disabled = true;
    button.textContent = "Logging in…";
    setAccountMessage("");
    try {
      await signInWithEmailAndPassword(auth, email, password);
      getElement("accountPassword").value = "";
      setAccountMessage("Admin login successful.");
    } catch (error) {
      const messages = {
        "auth/invalid-credential": "Email or password is incorrect.",
        "auth/invalid-email": "Please enter a valid email address.",
        "auth/too-many-requests": "Too many attempts. Please try again later.",
        "auth/network-request-failed": "Network error. Check your internet connection."
      };
      setAccountMessage(messages[error.code] || "Login failed. Check Firebase Authentication settings and try again.", true);
    } finally {
      button.disabled = false;
      button.textContent = "Admin Log In";
    }
  });
}

const accountLogoutButton = getElement("accountLogoutButton");
if (accountLogoutButton) {
  accountLogoutButton.addEventListener("click", async () => {
    accountLogoutButton.disabled = true;
    try {
      await signOut(auth);
      setAccountMessage("You have logged out successfully.");
    } catch (error) {
      setAccountMessage("Logout failed. Please try again.", true);
    } finally {
      accountLogoutButton.disabled = false;
    }
  });
}

onAuthStateChanged(auth, user => {
  if (user && !ADMIN_EMAILS.includes((user.email || "").toLowerCase())) {
    signOut(auth).catch(() => {});
    renderAccountUser(null);
    setAccountMessage("This account is not authorized for admin access.", true);
    return;
  }
  renderAccountUser(user);
});

// ===============================
// START APP
// ===============================

updateCart();
loadProducts();