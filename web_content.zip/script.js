// --- GT VENDAS SENSITIVITY GENERATOR & HEAD TRACKER ---
let appState = {
    sensitivity: {
        geral: 115,
        reddot: 105,
        mira2x: 98,
        mira4x: 92,
        awm: 55,
        olhadinha: 75
    },
    headtracker: {
        1: false,
        2: false,
        3: false,
        4: false,
        5: false
    },
    preferences: {
        visuals: true,
        animations: true
    }
};

// Load saved state on startup
window.addEventListener('DOMContentLoaded', () => {
    loadPreferences();
    loadSensitivity();
    loadHeadTracker();
    updateDashboardStats();
});

// --- NAVIGATION SYSTEM ---
function switchView(viewId) {
    document.querySelectorAll('.view-section').forEach(el => el.classList.add('hidden'));
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('text-red-500');
        btn.classList.add('text-zinc-500');
    });

    const targetView = document.getElementById(`view-${viewId}`);
    if (targetView) targetView.classList.remove('hidden');

    const targetNav = document.getElementById(`nav-${viewId}`);
    if (targetNav) {
        targetNav.classList.remove('text-zinc-500');
        targetNav.classList.add('text-red-500');
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// --- TOAST NOTIFICATION SYSTEM ---
function showToast(message, type = 'success') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast-enter pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-2xl glass-panel text-xs font-mono shadow-lg border ${
        type === 'success' ? 'border-emerald-500/40 text-emerald-300' :
        type === 'error' ? 'border-red-500/40 text-red-300' :
        'border-purple-500/40 text-purple-300'
    }`;

    let icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-triangle-exclamation';
    if (type === 'info') icon = 'fa-circle-info';

    toast.innerHTML = `
        <i class="fa-solid ${icon} text-base"></i>
        <span class="font-semibold">${message}</span>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.remove('toast-enter');
        toast.classList.add('toast-exit');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// --- SENSITIVITY CONTROLS & GENERATOR ---
function updateSliderVal(key, value) {
    appState.sensitivity[key] = parseInt(value);
    const valEl = document.getElementById(`val-${key}`);
    if (valEl) valEl.innerText = value;
    saveSensitivity();
}

function generateSensitivity() {
    appState.sensitivity.geral = Math.floor(Math.random() * (195 - 90 + 1)) + 90;
    appState.sensitivity.reddot = Math.floor(Math.random() * (190 - 85 + 1)) + 85;
    appState.sensitivity.mira2x = Math.floor(Math.random() * (180 - 80 + 1)) + 80;
    appState.sensitivity.mira4x = Math.floor(Math.random() * (175 - 75 + 1)) + 75;
    appState.sensitivity.awm = Math.floor(Math.random() * (120 - 30 + 1)) + 30;
    appState.sensitivity.olhadinha = Math.floor(Math.random() * (150 - 50 + 1)) + 50;

    for (const key in appState.sensitivity) {
        const slider = document.getElementById(`range-${key}`);
        const valEl = document.getElementById(`val-${key}`);
        if (slider) slider.value = appState.sensitivity[key];
        if (valEl) valEl.innerText = appState.sensitivity[key];
    }

    saveSensitivity();
    showToast("Sensibilidade gerada com sucesso!", "success");
}

function copySensitivity() {
    const s = appState.sensitivity;
    const text = `🔥 GT VENDAS - SENSITIVITY CONFIG 🔥\n` +
                 `• Geral: ${s.geral}\n` +
                 `• Ponto Vermelho: ${s.reddot}\n` +
                 `• Mira 2X: ${s.mira2x}\n` +
                 `• Mira 4X: ${s.mira4x}\n` +
                 `• Mira AWM: ${s.awm}\n` +
                 `• Olhadinha: ${s.olhadinha}\n` +
                 `#GTVendas #FreeFire`;

    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            showToast("Configuração copiada para a área de transferência!", "success");
        }).catch(() => fallbackCopy(text));
    } else {
        fallbackCopy(text);
    }
}

function fallbackCopy(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    document.body.appendChild(textArea);
    textArea.select();
    try {
        document.execCommand('copy');
        showToast("Configuração copiada com sucesso!", "success");
    } catch (err) {
        showToast("Erro ao copiar configuração.", "error");
    }
    document.body.removeChild(textArea);
}

function saveSensitivity() {
    localStorage.setItem('gt_vendas_sensitivity', JSON.stringify(appState.sensitivity));
}

function loadSensitivity() {
    const saved = localStorage.getItem('gt_vendas_sensitivity');
    if (saved) {
        try {
            appState.sensitivity = JSON.parse(saved);
            for (const key in appState.sensitivity) {
                const slider = document.getElementById(`range-${key}`);
                const valEl = document.getElementById(`val-${key}`);
                if (slider) slider.value = appState.sensitivity[key];
                if (valEl) valEl.innerText = appState.sensitivity[key];
            }
        } catch(e) {
            console.error(e);
        }
    }
}

// --- GT HEAD TRACKER SYSTEM ---
function toggleHeadTracker(id) {
    appState.headtracker[id] = !appState.headtracker[id];
    updateHeadTrackerUI();
    saveHeadTracker();

    const moduleNames = {
        1: "Calibrador",
        2: "Auxílio Head Tracker",
        3: "Aimbot",
        4: "Boneco Lento",
        5: "Diminuir Tremedeira"
    };

    const status = appState.headtracker[id] ? "ativado" : "desativado";
    showToast(`${moduleNames[id]} ${status}!`, appState.headtracker[id] ? "success" : "info");
    updateDashboardStats();
}

function toggleAllHeadTracker(state) {
    for (let i = 1; i <= 5; i++) {
        appState.headtracker[i] = state;
    }
    updateHeadTrackerUI();
    saveHeadTracker();
    updateDashboardStats();
    showToast(state ? "Todos os módulos Head Tracker ativados!" : "Todos os módulos desativados.", state ? "success" : "info");
}

function updateHeadTrackerUI() {
    let activeCount = 0;
    for (let i = 1; i <= 5; i++) {
        const isActive = appState.headtracker[i];
        if (isActive) activeCount++;

        const card = document.getElementById(`card-ht-${i}`);
        const btn = document.getElementById(`btn-ht-${i}`);
        if (!card || !btn) continue;

        const badge = card.querySelector('.status-badge');

        if (isActive) {
            card.classList.add('glass-panel-active', 'border-purple-500/40');
            card.classList.remove('bg-zinc-950/60', 'border-zinc-800/80');
            if (badge) {
                badge.innerText = 'ATIVADO';
                badge.className = 'status-badge text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-[0_0_10px_rgba(147,51,234,0.3)]';
            }
            btn.innerText = 'DESATIVAR MÓDULO';
            btn.className = 'w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold tracking-wider transition-all shadow-[0_0_15px_rgba(147,51,234,0.3)]';
        } else {
            card.classList.remove('glass-panel-active', 'border-purple-500/40');
            card.classList.add('bg-zinc-950/60', 'border-zinc-800/80');
            if (badge) {
                badge.innerText = 'DESATIVADO';
                badge.className = 'status-badge text-[10px] font-mono font-bold px-2.5 py-1 rounded-full bg-zinc-900 text-zinc-500 border border-zinc-800';
            }
            btn.innerText = 'ATIVAR MÓDULO';
            btn.className = 'w-full py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 text-xs font-semibold tracking-wider transition-all';
        }
    }

    const counterEl = document.getElementById('headtracker-counter');
    if (counterEl) {
        counterEl.innerText = `${activeCount} / 5 Ativados`;
    }
}

function saveHeadTracker() {
    localStorage.setItem('gt_vendas_headtracker', JSON.stringify(appState.headtracker));
}

function loadHeadTracker() {
    const saved = localStorage.getItem('gt_vendas_headtracker');
    if (saved) {
        try {
            appState.headtracker = JSON.parse(saved);
            updateHeadTrackerUI();
        } catch(e) {
            console.error(e);
        }
    }
}

// --- GAME LAUNCHER INTENT URI CORRIGIDO ---
function launchFreeFire() {
    const packageName = "com.dts.freefireth";
    const intentUrl = `intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${packageName};end`;
    
    showToast("Abrindo Free Fire...", "info");

    try {
        window.location.href = intentUrl;
    } catch(e) {
        showToast("Free Fire não encontrado no dispositivo.", "error");
    }
}

function launchFreeFireMax() {
    const packageName = "com.dts.freefiremax";
    const intentUrl = `intent://#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=${packageName};end`;
    
    showToast("Abrindo Free Fire MAX...", "info");

    try {
        window.location.href = intentUrl;
    } catch(e) {
        showToast("Free Fire MAX não encontrado no dispositivo.", "error");
    }
}

// --- PREFERENCES & CONFIGURATIONS ---
function savePreferences() {
    const visuals = document.getElementById('pref-visuals').checked;
    const animations = document.getElementById('pref-animations').checked;

    appState.preferences = { visuals, animations };
    localStorage.setItem('gt_vendas_preferences', JSON.stringify(appState.preferences));
    showToast("Preferências salvas com sucesso!", "success");
}

function loadPreferences() {
    const saved = localStorage.getItem('gt_vendas_preferences');
    if (saved) {
        try {
            appState.preferences = JSON.parse(saved);
            const vEl = document.getElementById('pref-visuals');
            const aEl = document.getElementById('pref-animations');
            if (vEl) vEl.checked = appState.preferences.visuals;
            if (aEl) aEl.checked = appState.preferences.animations;
        } catch(e) {
            console.error(e);
        }
    }
}

function restoreDefaults() {
    if (confirm("Deseja realmente restaurar todas as configurações e dados padrão?")) {
        localStorage.removeItem('gt_vendas_sensitivity');
        localStorage.removeItem('gt_vendas_headtracker');
        localStorage.removeItem('gt_vendas_preferences');
        location.reload();
    }
}

function updateDashboardStats() {
    let activeCount = 0;
    for (let i = 1; i <= 5; i++) {
        if (appState.headtracker[i]) activeCount++;
    }
    const statEl = document.getElementById('dash-active-head');
    if (statEl) statEl.innerText = `${activeCount}/5`;
}
