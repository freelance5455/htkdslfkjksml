(function(){
"use strict";
var $=function(id){return document.getElementById(id);};
var isDark=false;
$("menuBtn").onclick=function(){$("sidebar").classList.toggle("open");};
$("themeBtn").onclick=function(){isDark=!isDark;document.body.classList.toggle("dark",isDark);$("themeBtn").textContent=isDark?"☾":"☀";};

function fit(canvas){
  var r=canvas.getBoundingClientRect(),d=window.devicePixelRatio||1;
  canvas.width=Math.max(300,r.width*d);canvas.height=Math.max(140,r.height*d);
  var c=canvas.getContext("2d");c.setTransform(d,0,0,d,0,0);
  return {c:c,w:r.width,h:r.height};
}
function grid(c,w,h){
  c.strokeStyle="#e8edf5";c.lineWidth=1;
  for(var i=0;i<5;i++){var y=20+i*(h-40)/4;c.beginPath();c.moveTo(30,y);c.lineTo(w-12,y);c.stroke();}
}
function lineChart(id,data){
  var o=fit($(id)),c=o.c,w=o.w,h=o.h;grid(c,w,h);
  var max=600,p=30;c.strokeStyle="#1688ef";c.lineWidth=3;c.beginPath();
  for(var i=0;i<data.length;i++){var x=p+i*(w-p-15)/(data.length-1),y=h-25-data[i]/max*(h-55);if(i===0)c.moveTo(x,y);else c.lineTo(x,y);}
  c.stroke();c.fillStyle="#1688ef";
  for(var j=0;j<data.length;j++){var xx=p+j*(w-p-15)/(data.length-1),yy=h-25-data[j]/max*(h-55);c.beginPath();c.arc(xx,yy,3.5,0,Math.PI*2);c.fill();}
}
function bars(id,data,max){
  var o=fit($(id)),c=o.c,w=o.w,h=o.h;grid(c,w,h);var bw=(w-50)/data.length*.55;
  for(var i=0;i<data.length;i++){var bh=data[i]/max*(h-55),x=35+i*(w-45)/data.length,y=h-25-bh;c.fillStyle=i%2?"#f49329":"#1688ef";c.fillRect(x,y,bw,bh);}
}
function donut(id,a,b){
  var o=fit($(id)),c=o.c,w=o.w,h=o.h,cx=w/2,cy=h/2,r=Math.min(w,h)*.32,ir=r*.58;
  var start=-Math.PI/2,total=a+b;[[a,"#167cf0"],[b,"#ef4b82"]].forEach(function(v){
    var end=start+Math.PI*2*v[0]/total;c.beginPath();c.arc(cx,cy,r,start,end);c.arc(cx,cy,ir,end,start,true);c.closePath();c.fillStyle=v[1];c.fill();start=end;
  });
  c.fillStyle="#24406b";c.font="bold 18px Arial";c.textAlign="center";c.fillText("52%",cx,cy+6);
}
function feeChart(id){
  var o=fit($(id)),c=o.c,w=o.w,h=o.h;grid(c,w,h);var a=[7,9,12,11,13,15,13,14,16,15],b=[2,2,4,3,3,4,6,7,6,8];
  c.lineWidth=2;
  [[a,"#16a66e"],[b,"#ef4b68"]].forEach(function(z){c.strokeStyle=z[1];c.beginPath();for(var i=0;i<z[0].length;i++){var x=30+i*(w-45)/9,y=h-25-z[0][i]/20*(h-50);if(i===0)c.moveTo(x,y);else c.lineTo(x,y);}c.stroke();});
}
function draw(){lineChart("growth",[150,220,205,260,315,300,365,375,420,480]);bars("attendance",[82,80,75,80,86,87,86],100);donut("gender",251,231);bars("classes",[85,78,72,68,61,55],100);feeChart("fees");}
window.addEventListener("load",draw);window.addEventListener("resize",function(){draw();});

$("searchInput").addEventListener("input",function(){
  var q=this.value.toLowerCase(),links=document.querySelectorAll(".sidebar nav a");
  for(var i=0;i<links.length;i++)links[i].style.display=(!q||links[i].textContent.toLowerCase().indexOf(q)>=0)?"flex":"none";
});
$("aiBtn").onclick=function(){
  var q=$("aiInput").value.trim();
  if(!q){alert("مهرباني وکړئ خپله پوښتنه ولیکئ.");return;}
  alert("AI Insight:\nد «"+q+"» لپاره د ډیمو تحلیل: Mathematics د کمزوري مضمون په توګه ښکاري او د حاضري کچه 91٪ ده.");
};
function clock(){var d=new Date(),h=d.getHours(),m=d.getMinutes(),ap=h>=12?"PM":"AM";h=h%12||12;$("clock").textContent=h+":"+(m<10?"0":"")+m+" "+ap;}
clock();setInterval(clock,1000);
})();