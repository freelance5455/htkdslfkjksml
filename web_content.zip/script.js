let current='0',previous='',operator=null,reset=false;
const display=document.getElementById('display'),history=document.getElementById('history');
function render(){display.textContent=current;history.textContent=previous+(operator?' '+operator:'');}
function appendNumber(n){if(reset||current==='0'){current=String(n);reset=false}else if(current.length<16)current+=n;render()}
function appendDecimal(){if(reset){current='0.';reset=false}else if(!current.includes('.'))current+='.';render()}
function appendOperator(op){if(operator&&!reset)calculate();previous=current;operator=op;reset=true;render()}
function calculate(){if(!operator||reset)return;let a=Number(previous),b=Number(current),r;switch(operator){case '+':r=a+b;break;case '−':r=a-b;break;case '×':r=a*b;break;case '÷':r=b===0?'خطأ':a/b;break}current=typeof r==='number'?(Number.isFinite(r)?String(Number(r.toPrecision(12))):'خطأ'):r;previous='';operator=null;reset=true;render()}
function clearDisplay(){current='0';previous='';operator=null;reset=false;render()}
function toggleSign(){if(current!=='0'&&current!=='خطأ')current=String(-Number(current));render()}
function percent(){if(current!=='خطأ')current=String(Number(current)/100);render()}
document.addEventListener('keydown',e=>{if(/[0-9]/.test(e.key))appendNumber(e.key);else if(e.key==='.')appendDecimal();else if(e.key==='Enter'||e.key==='=')calculate();else if(e.key==='Escape')clearDisplay();else if(['+','-','*','/'].includes(e.key))appendOperator(({ '-':'−','*':'×','/':'÷'}[e.key]||e.key))});
