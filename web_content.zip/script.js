// Lista de fotos (o painel grava aqui)
const URL_LISTA = 'https://maistv-maker.github.io/mais-tv-dados/lista.json';

const telas = {
  menu: document.getElementById('telaMenu'),
  novidades: document.getElementById('telaNovidades'),
  suporte: document.getElementById('telaSuporte')
};
const foto = document.getElementById('foto');
const msg = document.getElementById('msg');
let imagens = [];
let indice = 0;
let atual = 'menu';

function ir(nome, focar) {
  Object.values(telas).forEach(t => t.classList.remove('ativa'));
  telas[nome].classList.add('ativa');
  atual = nome;
  if (nome === 'novidades') carregarNovidades();
  const alvo = focar || { menu: 'btnNovidades', novidades: 'voltarNov', suporte: 'voltarSup' }[nome];
  setTimeout(() => document.getElementById(alvo).focus(), 50);
}

// Chamado pelo botão voltar do controle (via app Android)
// Retorna true se voltou pro menu, false se já estava no menu (aí o app fecha)
window.voltar = function () {
  if (atual !== 'menu') { ir('menu', atual === 'suporte' ? 'btnSuporte' : 'btnNovidades'); return true; }
  return false;
};

async function carregarNovidades() {
  msg.style.display = 'block';
  msg.textContent = 'Carregando novidades...';
  foto.style.display = 'none';
  try {
    const r = await fetch(URL_LISTA + '?t=' + Date.now(), { cache: 'no-store' });
    imagens = await r.json();
    if (imagens.length > 0) { mostrar(0); }
    else { msg.textContent = 'Nenhuma novidade adicionada ainda'; }
  } catch (e) {
    msg.textContent = 'Erro ao carregar. Tente novamente mais tarde.';
    console.error(e);
  }
}

function mostrar(i) {
  if (imagens.length === 0) return;
  indice = (i + imagens.length) % imagens.length;
  foto.src = imagens[indice];
  foto.style.display = 'block';
  msg.style.display = 'none';
}

document.getElementById('btnNovidades').addEventListener('click', () => ir('novidades'));
document.getElementById('btnSuporte').addEventListener('click', () => ir('suporte'));
document.getElementById('voltarNov').addEventListener('click', () => ir('menu', 'btnNovidades'));
document.getElementById('voltarSup').addEventListener('click', () => ir('menu', 'btnSuporte'));
document.getElementById('setaEsq').addEventListener('click', () => mostrar(indice - 1));
document.getElementById('setaDir').addEventListener('click', () => mostrar(indice + 1));

// Controle remoto
document.addEventListener('keydown', (e) => {
  const k = e.key;
  if (atual === 'menu') {
    if (k === 'ArrowDown') { document.getElementById('btnSuporte').focus(); e.preventDefault(); }
    if (k === 'ArrowUp') { document.getElementById('btnNovidades').focus(); e.preventDefault(); }
  } else if (atual === 'novidades') {
    if (k === 'ArrowLeft') { mostrar(indice - 1); e.preventDefault(); }
    if (k === 'ArrowRight') { mostrar(indice + 1); e.preventDefault(); }
    if (k === 'ArrowUp') { document.getElementById('voltarNov').focus(); e.preventDefault(); }
  }
  if (k === 'Escape' || k === 'Backspace' || k === 'GoBack' || k === 'BrowserBack') {
    if (window.voltar()) e.preventDefault();
  }
});

ir('menu');
