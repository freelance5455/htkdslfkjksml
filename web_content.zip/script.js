const letters = [
  "ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش",
  "ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي"
];

const lettersBox = document.getElementById("letters");
const status = document.getElementById("status");
const repeatBtn = document.getElementById("repeatBtn");
let selected = "";

letters.forEach(letter => {
  const button = document.createElement("button");
  button.className = "letter";
  button.type = "button";
  button.textContent = letter;
  button.setAttribute("aria-label", "الحرف " + letter);

  button.addEventListener("click", () => {
    selected = letter;
    document.querySelectorAll(".letter").forEach(b => b.classList.remove("selected"));
    button.classList.add("selected");
    status.textContent = "الحرف المختار: " + letter;
    speak(letter);
  });

  lettersBox.appendChild(button);
});

function speak(text) {
  if (!("speechSynthesis" in window)) {
    status.textContent = "المتصفح لا يدعم النطق الصوتي.";
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "ar-SA";
  utterance.rate = 0.65;
  utterance.pitch = 1;
  window.speechSynthesis.speak(utterance);
}

repeatBtn.addEventListener("click", () => {
  if (selected) speak(selected);
  else status.textContent = "اختر حرفاً أولاً";
});
