const messagesDiv = document.getElementById("messages");

function sendMessage() {
  const input = document.getElementById("userInput");
  const userMessage = input.value.trim();

  if (userMessage === "") return;

  // Display user's message
  addMessage("user", userMessage);

  // Generate bot response dynamically
  const botResponse = generateUnfilteredResponse(userMessage);
  setTimeout(() => addMessage("bot", botResponse), 500);

  // Clear input
  input.value = "";
}

function addMessage(sender, text) {
  const messageDiv = document.createElement("div");
  messageDiv.className = `message ${sender}`;
  messageDiv.textContent = text;
  messagesDiv.appendChild(messageDiv);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function generateUnfilteredResponse(input) {
  // Logic reconstructed from the supplied screenshots.
  try {
    if (input.toLowerCase().includes("what")) {
      return "you asked 'what'--so let me break it down, no filters.";
    } else if (input.toLowerCase().includes("why")) {
      return "because that's just how it is. why not?";
    } else if (input.toLowerCase().includes("how")) {
      return "how? you just make it happen.";
    } else if (input.toLowerCase().includes("who")) {
      return "you already know 'who'. it's you.";
    } else {
      return "idk man, you tell me.";
    }
  } catch (error) {
    return "something went wrong, but i'm still here.";
  }
}

// Press Enter to send the message.
document.getElementById("userInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    sendMessage();
  }
});
