const input = document.getElementById("imageInput");
const gallery = document.getElementById("userGallery");
const clear = document.getElementById("clearGallery");
const STORAGE_KEY = "kbTextileImages";

function loadImages(){
  const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  gallery.innerHTML = "";
  saved.forEach(item => addFigure(item.name, item.data));
}
function addFigure(name, data){
  const fig = document.createElement("figure");
  const img = document.createElement("img");
  const cap = document.createElement("figcaption");
  img.src = data; img.alt = name; cap.textContent = name;
  fig.append(img, cap); gallery.appendChild(fig);
}
input.addEventListener("change", async (e)=>{
  const files = [...e.target.files];
  const current = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  for(const file of files){
    if(!file.type.startsWith("image/")) continue;
    const data = await new Promise(resolve=>{
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
    current.push({name:file.name,data});
    addFigure(file.name,data);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(current));
  input.value = "";
});
clear.addEventListener("click", ()=>{
  localStorage.removeItem(STORAGE_KEY);
  gallery.innerHTML = "";
});
document.getElementById("year").textContent = new Date().getFullYear();
loadImages();
