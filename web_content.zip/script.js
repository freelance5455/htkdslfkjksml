const districts={
"Naushehra Feroze":["Kandiaro","Naushahro Feroze","Bhiria","Moro"],
"Shaheed Benazirabad":["Nawabshah","Sakrand","Daur"],
"Sukkur":["Sukkur","Rohri","Pano Aqil"],
"Larkana":["Larkana","Ratodero","Dokri"],
"Khairpur":["Khairpur","Gambat","Kot Diji"]
};

const docs=[
["cnicFront","CNIC Front"],
["cnicBack","CNIC Back"],
["shopPicture","Shop Picture"],
["utilityBill","Electricity / Gas Bill"],
["paymentReceipt","Payment Receipt / Proof"],
["visitingCard","Visiting Card"]
];

document.addEventListener("DOMContentLoaded",()=>{
  setupStrictValidation();
  const d=document.getElementById("district");
  Object.keys(districts).forEach(x=>d.insertAdjacentHTML("beforeend",`<option>${x}</option>`));
  const box=document.getElementById("documents");
  docs.forEach(([id,title])=>{
    box.insertAdjacentHTML("beforeend",`
      <div class="doc">
        <div class="doc-title">${title}</div>
        <div class="doc-actions">
          <label class="btn camera">📷 Take Photo
            <input id="${id}Camera" type="file" accept="image/*" capture="environment" hidden onchange="picked('${id}','${id}Camera')">
          </label>
          <label class="btn">📁 Upload File
            <input id="${id}Upload" type="file" accept="image/*,.pdf" hidden onchange="picked('${id}','${id}Upload')">
          </label>
        </div>
        <div class="file-name" id="${id}Name"></div>
        <img class="preview" id="${id}Preview">
      </div>`);
  });
});


function setupStrictValidation(){
  const mobile=document.getElementById("mobile");
  const cnic=document.getElementById("cnic");
  const name=document.getElementById("fullName");
  const email=document.getElementById("email");

  [mobile,cnic].forEach(el=>{
    el.addEventListener("input",()=>{
      el.value=el.value.replace(/\D/g,"");
      if(el===mobile && el.value.length>11) el.value=el.value.slice(0,11);
      if(el===cnic && el.value.length>13) el.value=el.value.slice(0,13);
    });
  });

  name.addEventListener("input",()=>{
    name.value=name.value.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ\s.'-]/g,"").replace(/\s{2,}/g," ");
  });

  email.addEventListener("input",()=>{
    email.value=email.value.replace(/\s/g,"");
  });
}

function strictPersonalValidation(){
  const mobile=document.getElementById("mobile").value;
  const cnic=document.getElementById("cnic").value;
  const email=document.getElementById("email").value.trim();
  const name=document.getElementById("fullName").value.trim();

  if(!/^[A-Za-zÀ-ÖØ-öø-ÿ\s.'-]{2,}$/.test(name)){
    alert("Please enter a valid full name using letters only.");
    document.getElementById("fullName").focus(); return false;
  }
  if(!/^\d{11}$/.test(mobile)){
    alert("Mobile Number must contain exactly 11 digits.");
    document.getElementById("mobile").focus(); return false;
  }
  if(!/^03\d{9}$/.test(mobile)){
    alert("Please enter a valid Pakistani mobile number starting with 03.");
    document.getElementById("mobile").focus(); return false;
  }
  if(!/^\d{13}$/.test(cnic)){
    alert("CNIC must contain exactly 13 digits.");
    document.getElementById("cnic").focus(); return false;
  }
  if(!/^\d{5}-?\d{7}-?\d$/.test(cnic)){
    alert("Please enter a valid 13-digit CNIC number.");
    document.getElementById("cnic").focus(); return false;
  }
  if(!/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/.test(email)){
    alert("Please enter a valid email address, for example name@gmail.com.");
    document.getElementById("email").focus(); return false;
  }
  return true;
}

function updateCities(){
  const district=document.getElementById("district").value;
  const city=document.getElementById("city");
  city.innerHTML='<option value="">Select City</option>';
  (districts[district]||[]).forEach(x=>city.insertAdjacentHTML("beforeend",`<option>${x}</option>`));
}

function nextStep(n){
  if(n>1 && !validateCurrent()) return;
  if(n===2 && !strictPersonalValidation()) return;
  document.querySelectorAll(".section").forEach(s=>s.classList.remove("active"));
  document.querySelector(`[data-step="${n}"]`).classList.add("active");
  window.scrollTo({top:0,behavior:"smooth"});
}

function validateCurrent(){
  const current=document.querySelector(".section.active");
  const required=current.querySelectorAll("[required]");
  for(const el of required){
    if(!el.value.trim()){el.focus();alert("Please complete all required fields.");return false;}
  }
  return true;
}

function picked(id,inputId){
  const input=document.getElementById(inputId);
  const file=input.files[0];
  if(!file)return;
  document.getElementById(id+"Name").textContent="Selected: "+file.name;
  const preview=document.getElementById(id+"Preview");
  if(file.type.startsWith("image/")){
    preview.src=URL.createObjectURL(file);
    preview.style.display="block";
  }else{
    preview.style.display="none";
  }
}

function submitApplication(){
  if(!validateCurrent())return;
  for(const [id] of docs){
    const camera=document.getElementById(id+"Camera").files.length;
    const upload=document.getElementById(id+"Upload").files.length;
    if(!camera && !upload){const item=docs.find(x=>x[0]===id);alert("Please provide: "+item[1]);return;}
  }
  document.getElementById("formCard").classList.add("hidden");
  document.getElementById("statusCard").classList.remove("hidden");
  startTimer();
}

function startTimer(){
  let seconds=1800;
  const timer=document.getElementById("timer");
  const verified=document.getElementById("verified");
  const interval=setInterval(()=>{
    seconds--;
    const m=String(Math.floor(seconds/60)).padStart(2,"0");
    const s=String(seconds%60).padStart(2,"0");
    timer.textContent=`${m}:${s}`;
    if(seconds<=0){
      clearInterval(interval);
      timer.classList.add("hidden");
      verified.classList.remove("hidden");
    }
  },1000);
}