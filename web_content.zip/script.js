const lessons=[
{id:1,title:"Internet sans jargon",level:"Niveau 0",xp:30,body:`<p>Avant le code, on comprend le terrain. Un <b>site web</b> est une page que ton navigateur affiche. Le navigateur lit des fichiers comme HTML, CSS et JavaScript et les transforme en interface.</p><p>Imagine une maison : <b>HTML = la structure</b>, <b>CSS = la décoration</b>, <b>JavaScript = les mécanismes</b> qui la rendent interactive.</p>`,quiz:"Quel outil affiche généralement un site web ?",answers:["Le navigateur","Le clavier","Le câble USB"],correct:0},
{id:2,title:"HTML — Construire",level:"Niveau 1",xp:50,body:`<p>HTML décrit ce qui existe sur la page : titres, textes, images, boutons et liens.</p><pre class="code-example">&lt;h1&gt;Mon site&lt;/h1&gt;\n&lt;p&gt;Bienvenue !&lt;/p&gt;\n&lt;button&gt;Cliquer&lt;/button&gt;</pre><p>Tu n'as pas besoin de mémoriser tout le langage. Tu apprendras en construisant.</p>`,quiz:"Quelle balise représente généralement le titre principal ?",answers:["&lt;p&gt;","&lt;h1&gt;","&lt;img&gt;"],correct:1},
{id:3,title:"CSS — Donner une identité",level:"Niveau 1",xp:60,body:`<p>CSS change l'apparence d'une page : couleurs, tailles, espaces, positions et responsive.</p><pre class="code-example">h1 {\n color: purple;\n font-size: 40px;\n}</pre>`,quiz:"Quel langage sert principalement à styliser HTML ?",answers:["Python","CSS","SQL"],correct:1},
{id:4,title:"JavaScript — Faire agir",level:"Niveau 2",xp:80,body:`<p>JavaScript permet à ton interface de réagir. Un clic, un formulaire ou une donnée peuvent déclencher une action.</p><pre class="code-example">button.addEventListener("click", () => {\n alert("Salut !");\n});</pre>`,quiz:"Quel langage ajoute principalement de l'interactivité au site ?",answers:["JavaScript","HTML","CSS"],correct:0},
{id:5,title:"Ton premier mini-projet",level:"Niveau 2",xp:120,body:`<p>Tu vas maintenant réunir structure, style et comportement. Ouvre l'Atelier et modifie le titre, la couleur et le bouton.</p><p><b>Mission :</b> personnalise le projet avec ton propre texte puis lance-le.</p>`,quiz:"Quel espace de l'académie permet de tester ton code ?",answers:["Atelier","Profil","Communauté"],correct:0},
{id:6,title:"API — Faire communiquer",level:"Niveau 3",xp:120,body:`<p>Une API est une porte organisée qui permet à un logiciel de demander ou transmettre des informations à un autre service.</p><p>Exemple : une application météo peut demander la température à un service météo grâce à une API.</p>`,quiz:"Une API sert notamment à…",answers:["Faire communiquer des logiciels","Peindre un écran","Remplacer le clavier"],correct:0},
{id:7,title:"Publier ton projet",level:"Niveau 3",xp:150,body:`<p>Quand ton projet fonctionne, tu peux le mettre en ligne. Pour un site statique, des services comme Netlify peuvent héberger tes fichiers HTML/CSS/JS.</p><p>Ensuite, tu apprendras les applications, les bases de données et les architectures plus avancées.</p>`,quiz:"Que signifie généralement publier un site ?",answers:["Le rendre accessible en ligne","Éteindre le PC","Supprimer le HTML"],correct:0}
];

const videos=[
["Comprendre HTML","https://www.youtube.com/results?search_query=HTML+débutant+cours+français"],
["CSS pour débutant","https://www.youtube.com/results?search_query=CSS+débutant+cours+français"],
["JavaScript débutant","https://www.youtube.com/results?search_query=JavaScript+débutant+cours+français"],
["Créer une application web","https://www.youtube.com/results?search_query=créer+application+web+débutant+français"]
];

const DEFAULT={xp:0,done:[],streak:0,last:"",onboard:false,level:"zero",goal:"mixed",music:false,sound:true,aiEndpoint:""};
let state=loadState(), current=0, onboardingStep=1;
function loadState(){try{return {...DEFAULT,...JSON.parse(localStorage.getItem("ldy_v2")||"{}")}}catch(e){return {...DEFAULT}}}
function save(){localStorage.setItem("ldy_v2",JSON.stringify(state));updateStats()}
function toast(m){const t=document.querySelector("#toast");t.textContent=m;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
function page(id){document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));document.getElementById(id)?.classList.add("active");window.scrollTo(0,0)}
document.addEventListener("click",e=>{const p=e.target.closest("[data-page]");if(p)page(p.dataset.page)});

function onNext(){onboardingStep=Math.min(4,onboardingStep+1);renderOnboarding()}
function onPrev(){onboardingStep=Math.max(1,onboardingStep-1);renderOnboarding()}
function renderOnboarding(){
 document.querySelectorAll(".on-step").forEach(x=>x.classList.toggle("active",+x.dataset.step===onboardingStep));
 document.querySelectorAll(".step-dot i").forEach((x,i)=>x.classList.toggle("on",i<onboardingStep));
 if(onboardingStep===4){
   const names={zero:"Départ de zéro",beginner:"Débutant",curious:"Petite expérience"};
   const goals={site:"créer des sites web",app:"créer des applications",game:"créer des jeux",mixed:"explorer le développement"};
   document.querySelector("#welcomeTitle").textContent="Bienvenue, "+(names[state.level]||"créateur")+" 👋";
   document.querySelector("#welcomeText").textContent=`Ton premier parcours est orienté pour ${goals[state.goal]||"explorer le développement"}. On commence doucement et on augmente la difficulté seulement quand tu es prêt.`;
 }
}
function chooseLevel(el){document.querySelectorAll("[data-level]").forEach(x=>x.classList.remove("selected"));el.classList.add("selected");state.level=el.dataset.level;setTimeout(onNext,180)}
function chooseGoal(el){document.querySelectorAll("[data-goal]").forEach(x=>x.classList.remove("selected"));el.classList.add("selected");state.goal=el.dataset.goal;setTimeout(onNext,180)}
function finishOnboarding(){state.onboard=true;save();document.querySelector("#onboarding").classList.add("hidden");initApp();toast("Bienvenue dans ton académie 🚀")}
function restartOnboarding(){state.onboard=false;save();onboardingStep=1;document.querySelector("#onboarding").classList.remove("hidden");renderOnboarding()}
function updateStats(){
 const xp=state.xp, lvl=Math.floor(xp/200)+1, pct=Math.round(state.done.length/lessons.length*100);
 ["xpHome"].forEach(id=>document.getElementById(id)&&(document.getElementById(id).textContent=xp));
 document.getElementById("levelHome").textContent=lvl;document.getElementById("doneHome").textContent=state.done.length;
 document.getElementById("streak").textContent=state.streak;document.getElementById("streakHome").textContent=state.streak;
 document.getElementById("pathPercent").textContent=pct+"%";document.getElementById("pathProgress").style.width=pct+"%";
 document.getElementById("homeGreeting").textContent=state.done.length?`Tu as déjà validé ${state.done.length} mission${state.done.length>1?"s":""}. On continue ?`:"Bienvenue. Ta première mission prend moins de 5 minutes.";
 document.getElementById("dayLabel").textContent="JOUR "+Math.max(1,state.streak||1);
 document.getElementById("forestMessage").textContent=pct>=100?"La forêt est devenue un royaume.":pct>=50?"Les arbres grandissent. Continue.":"Chaque mission plante quelque chose.";
 document.getElementById("profileSummary").textContent=`Niveau choisi : ${({zero:"zéro",beginner:"débutant",curious:"petite expérience"})[state.level]||"zéro"} • Objectif : ${({site:"site web",app:"application",game:"jeu",mixed:"explorer"})[state.goal]||"explorer"} • ${state.xp} XP.`;
}
function updateStreak(){const today=new Date().toISOString().slice(0,10);if(state.last!==today){state.streak=state.last?Math.max(1,state.streak+1):1;state.last=today}}
function renderTrack(){
 const next=lessons.find(l=>!state.done.includes(l.id))||lessons[lessons.length-1];
 document.querySelector("#nextMission").innerHTML=`<div><span class="eyebrow">MISSION SUIVANTE</span><h2>${next.title}</h2><p>${next.level} • +${next.xp} XP • ${state.done.includes(next.id)?"Toutes les missions sont terminées.":"Une étape à la fois."}</p></div><button class="primary" onclick="page('learn');selectLesson(${next.id})">${state.done.includes(next.id)?"REVOIR":"COMMENCER"} →</button>`;
 document.querySelector("#forestRoad").innerHTML=lessons.map((l,i)=>`<div class="forest-node ${state.done.includes(l.id)?"done":""}${(!state.done.includes(l.id)&&l.id===next.id)?" current":""}${(!state.done.includes(l.id)&&l.id!==next.id)?" locked":""}"><span>${state.done.includes(l.id)?"🌲":l.id===next.id?"🌱":"🌿"}</span><small>J${i+1}</small></div>`).join("");
}
function renderList(){
 document.querySelector("#lessonList").innerHTML=lessons.map((l,i)=>`<button class="lesson-item ${i===current?"active ":""}${state.done.includes(l.id)?"done":""}" onclick="selectLesson(${l.id})">${l.id}. ${l.title}<small style="display:block;color:#666">${l.level} • ${l.xp} XP</small></button>`).join("");
}
function selectLesson(id){current=lessons.findIndex(x=>x.id===id);renderList();renderLesson();page("learn")}
function renderLesson(){
 const l=lessons[current], locked=l.id>1&&!state.done.includes(l.id-1)&&!state.done.includes(l.id);
 document.querySelector("#lessonCard").innerHTML=`<span class="eyebrow">${l.level} • +${l.xp} XP</span><h2>${l.title}</h2><div class="lesson-body">${l.body}</div><div class="quiz"><b>🎯 MINI-MISSION</b><p>${l.quiz}</p>${l.answers.map((a,i)=>`<button onclick="answer(${i})">${a}</button>`).join("")}<div id="quizResult"></div></div>`;
}
function answer(i){
 const l=lessons[current],r=document.querySelector("#quizResult");
 if(i===l.correct){
   if(!state.done.includes(l.id)){state.done.push(l.id);state.xp+=l.xp;updateStreak();save();renderList();renderTrack();renderForest();playTone(660,0.12)}
   r.innerHTML='<p style="color:#6be58a;font-weight:800">✅ Mission validée. Tu viens de planter un nouvel arbre.</p>';toast("+"+l.xp+" XP — Mission validée !");
 }else{r.innerHTML='<p style="color:#ff6c8b">❌ Pas grave. Relis l’explication et réessaie.</p>';playTone(180,0.08)}
}
function renderForest(){updateStats();renderTrack()}
function continueJourney(){const n=lessons.find(l=>!state.done.includes(l.id))||lessons[0];selectLesson(n.id)}
function renderVideos(){document.querySelector("#videoGrid").innerHTML=videos.map(v=>`<div class="video-mini"><b>${v[0]}</b> — <a href="${v[1]}" target="_blank" rel="noopener">ouvrir YouTube</a></div>`).join("")}

const localAI={
 rules:[
  {keys:["html","balise","h1"],reply:"HTML, c'est la structure de ta page. Imagine les murs d'une maison. Une balise comme <h1> indique un titre. Si tu veux, on peut faire ensemble ton premier mini-site dans l'Atelier."},
  {keys:["css","couleur","style"],reply:"CSS, c'est l'apparence. HTML construit la maison, CSS choisit la peinture, les tailles et la disposition. Dans l'Atelier, modifie par exemple `color: purple;` et relance."},
  {keys:["javascript","js","script","interact"],reply:"JavaScript ajoute du comportement. Par exemple, un clic peut déclencher une action. Tu n'as pas besoin de tout connaître : commence par les variables, conditions, fonctions et événements."},
  {keys:["api"],reply:"Une API est une porte de communication entre logiciels. Ton application demande une information à un service et reçoit une réponse. Exemple : une application météo demande la température à une API météo."},
  {keys:["application","app","apk"],reply:"Pour une application, on peut d'abord construire une version web. Ensuite elle peut être emballée en APK avec un outil comme celui que tu utilises. Attention : une clé API secrète ne doit jamais être mise directement dans le HTML de l'APK."},
  {keys:["site","web"],reply:"Pour créer un site, ton parcours est : comprendre Internet → HTML → CSS → JavaScript → mini-projet → publication. Je te conseille de commencer par la mission 1, même si tu penses déjà connaître un peu."},
  {keys:["erreur","bug","bloque","bloqué"],reply:"Un bug n'est pas un échec. Copie le message d'erreur ou le morceau de code qui bloque et donne-moi ce que tu voulais obtenir. Je vais chercher la cause avant de te donner la correction."},
  {keys:["début","zero","jamais","comprend rien","comprends rien"],reply:"Alors on ne va surtout pas te noyer dans le jargon. Commence par la mission « Internet sans jargon ». Après ça, HTML. Une seule notion à la fois."},
  {keys:["python"],reply:"Python est un langage très utile, notamment pour l'automatisation, la data et certains backends. Mais pour voir rapidement un résultat à l'écran, HTML/CSS/JavaScript est souvent plus motivant pour commencer."},
  {keys:["merci","thanks"],reply:"Avec plaisir. 😎 Maintenant, choisis une petite mission : apprendre, tester dans l'Atelier ou me poser une question."}
 ],
 fallback:"Je peux t'aider, mais je veux éviter de te donner une réponse au hasard. Dis-moi ce que tu essaies de créer, ce que tu ne comprends pas et, si tu as du code, colle-le ici. Je te guiderai étape par étape."
};
function localAnswer(q){
 const s=q.toLowerCase();
 const hit=localAI.rules.find(r=>r.keys.some(k=>s.includes(k)));
 let base=hit?hit.reply:localAI.fallback;
 if(state.level==="zero" && !hit) base+=" Comme tu as indiqué partir de zéro, je vais privilégier des explications sans jargon.";
 return base;
}
function addMsg(text,who="ai"){const box=document.querySelector("#chatMessages");const d=document.createElement("div");d.className="msg "+who;d.textContent=text;box.appendChild(d);box.scrollTop=box.scrollHeight}
async function askAI(q){
 q=(q||"").trim();if(!q)return;addMsg(q,"user");document.querySelector("#aiInput").value="";
 if(state.aiEndpoint){
  try{
   const res=await fetch(state.aiEndpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:q,context:{level:state.level,goal:state.goal,xp:state.xp,done:state.done}})});
   if(!res.ok)throw Error("endpoint");
   const data=await res.json();addMsg(data.reply||data.message||"Je n'ai pas reçu de réponse exploitable.");return;
  }catch(e){addMsg("Le serveur IA configuré ne répond pas. Je passe en mode local pour ne pas te laisser bloqué.");}
 }
 setTimeout(()=>addMsg(localAnswer(q)),220);
}
document.querySelector("#chatForm").addEventListener("submit",e=>{e.preventDefault();askAI(document.querySelector("#aiInput").value)});
function initAI(){if(!document.querySelector("#chatMessages").children.length)addMsg("Salut 👋 Je suis Yackuza AI. Je connais ton parcours. Dis-moi ce que tu veux apprendre ou ce qui te bloque.");}

function runCode(){const h=document.querySelector("#htmlCode").value,c=document.querySelector("#cssCode").value,j=document.querySelector("#jsCode").value;document.querySelector("#previewFrame").srcdoc=`<!doctype html><html><head><meta name="viewport" content="width=device-width"><style>${c}</style></head><body>${h}<script>${j.replace(/<\/script>/gi,"<\\/script>")}<\/script></body></html>`}
document.querySelector("#runCode").onclick=runCode;
document.querySelector("#shareBtn")?.addEventListener("click",async()=>{if(navigator.share)await navigator.share({title:"LDY Code Academy",text:"Apprends à créer des projets numériques.",url:location.href});else{await navigator.clipboard.writeText(location.href);toast("Lien copié")}});

let audioCtx=null,master=null,osc=[];
function startMusic(){
 try{
  audioCtx=audioCtx||new (window.AudioContext||window.webkitAudioContext)();if(master){master.gain.value=.04;return}
  master=audioCtx.createGain();master.gain.value=.035;master.connect(audioCtx.destination);
  const notes=[196,246.94,293.66,329.63];notes.forEach((f,i)=>{const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type="sine";o.frequency.value=f;g.gain.value=.12;o.connect(g);g.connect(master);o.start();osc.push(o);});
  state.music=true;save();document.querySelector("#musicBtn").textContent="⏸ COUPER LA MUSIQUE";toast("Ambiance activée 🎵");
 }catch(e){toast("Audio non disponible sur cet appareil")}
}
function stopMusic(){if(master){master.gain.value=0}state.music=false;save();document.querySelector("#musicBtn").textContent="▶ ACTIVER LA MUSIQUE"}
document.querySelector("#musicBtn").onclick=()=>state.music?stopMusic():startMusic();
function playTone(freq,dur){if(!state.sound)return;try{const c=new (window.AudioContext||window.webkitAudioContext)(),o=c.createOscillator(),g=c.createGain();o.frequency.value=freq;o.connect(g);g.connect(c.destination);g.gain.value=.04;o.start();setTimeout(()=>{o.stop();c.close()},dur*1000)}catch(e){}}
document.querySelector("#soundBtn").onclick=()=>{state.sound=!state.sound;save();document.querySelector("#soundBtn").textContent=state.sound?"🔊 SONS : ON":"🔇 SONS : OFF"};
document.querySelector("#resetBtn").onclick=()=>{if(confirm("Réinitialiser toute la progression ?")){state={...DEFAULT,onboard:true,level:state.level,goal:state.goal};save();current=0;initApp();toast("Progression réinitialisée")}};
function initApp(){renderVideos();renderList();renderLesson();renderForest();runCode();initAI();if(state.music)startMusic()}
if(!state.onboard){document.querySelector("#onboarding").classList.remove("hidden");renderOnboarding()}else{document.querySelector("#onboarding").classList.add("hidden");initApp()}
