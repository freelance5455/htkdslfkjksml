
/* ==========================================================
   VIRAL MATH CHALLENGE — NON-REPEATING QUESTION ENGINE
   Questions are generated randomly and remembered in localStorage.
   A question will NOT repeat until the local history is cleared.
   ========================================================== */

const canvas = document.getElementById('confetti-canvas');
const ctx = canvas.getContext('2d');
let confettiParticles = [], confettiAnimId = null;

function resizeCanvas(){
  canvas.width = canvas.parentElement.clientWidth;
  canvas.height = canvas.parentElement.clientHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

function launchConfetti(){
  resizeCanvas();
  const colors=['#22c55e','#3b82f6','#facc15','#f43f5e','#a855f7'];
  confettiParticles=[];
  for(let i=0;i<70;i++){
    confettiParticles.push({
      x:canvas.width*.5,y:canvas.height*.6,
      vx:(Math.random()-.5)*14,vy:Math.random()*-12-4,
      size:Math.random()*8+4,color:colors[Math.floor(Math.random()*colors.length)],
      rotation:Math.random()*360,vRot:(Math.random()-.5)*12,alpha:1
    });
  }
  animateConfetti();
}

function animateConfetti(){
  if(confettiAnimId) cancelAnimationFrame(confettiAnimId);
  function step(){
    ctx.clearRect(0,0,canvas.width,canvas.height);
    let active=false;
    for(const p of confettiParticles){
      p.x+=p.vx;p.y+=p.vy;p.vy+=.35;p.rotation+=p.vRot;p.alpha-=.012;
      if(p.alpha>0){
        active=true;ctx.save();ctx.globalAlpha=Math.max(0,p.alpha);
        ctx.translate(p.x,p.y);ctx.rotate(p.rotation*Math.PI/180);
        ctx.fillStyle=p.color;ctx.fillRect(-p.size/2,-p.size/2,p.size,p.size*.6);
        ctx.restore();
      }
    }
    if(active) confettiAnimId=requestAnimationFrame(step);
    else ctx.clearRect(0,0,canvas.width,canvas.height);
  }
  confettiAnimId=requestAnimationFrame(step);
}

class AudioEngine{
  constructor(){this.ctx=null}
  init(){
    try{
      if(!this.ctx){
        const AudioCtx=window.AudioContext||window.webkitAudioContext;
        if(AudioCtx)this.ctx=new AudioCtx();
      }
      if(this.ctx&&this.ctx.state==='suspended')this.ctx.resume().catch(()=>{});
    }catch(e){}
  }
  playTick(urgent){
    try{
      this.init();if(!this.ctx)return;
      const o=this.ctx.createOscillator(),g=this.ctx.createGain();
      o.type=urgent?'triangle':'sine';
      o.frequency.setValueAtTime(urgent?880:600,this.ctx.currentTime);
      o.frequency.exponentialRampToValueAtTime(120,this.ctx.currentTime+.05);
      g.gain.setValueAtTime(urgent?.14:.07,this.ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(.001,this.ctx.currentTime+.05);
      o.connect(g);g.connect(this.ctx.destination);o.start();o.stop(this.ctx.currentTime+.06);
    }catch(e){}
  }
  playChime(){
    try{
      this.init();if(!this.ctx)return;
      [523.25,659.25,783.99,1046.5].forEach((f,i)=>{
        const o=this.ctx.createOscillator(),g=this.ctx.createGain(),t=this.ctx.currentTime+i*.06;
        o.frequency.setValueAtTime(f,t);g.gain.setValueAtTime(.12,t);
        g.gain.exponentialRampToValueAtTime(.0001,t+.5);
        o.connect(g);g.connect(this.ctx.destination);o.start(t);o.stop(t+.55);
      });
    }catch(e){}
  }
}
const audio=new AudioEngine();

const CTAS=[
  'Can You Solve It?','What’s The Answer?','Are You a Genius?','Only 1% Can Solve!',
  'Test Your Brain Now!','Calculate in 15s!','Brain Teaser Time!','Can You Get This Right?',
  'Think Fast!','Beat The Clock!','Spot The Answer!','Are You Ready?','Fast Math Check!',
  'Find The Answer!','Challenge Your Brain!','Quick Math Test!','Can You Beat This?',
  'Solve It Before Time!','Brain Power On!','Your Turn!'
];

/* ---------- Persistent no-repeat system ---------- */
const STORAGE_KEY = 'mathChallengeUsedQuestions_v3';

function loadUsedQuestions(){
  try{
    const raw=localStorage.getItem(STORAGE_KEY);
    const data=raw?JSON.parse(raw):[];
    return new Set(Array.isArray(data)?data:[]);
  }catch(e){
    return new Set();
  }
}

let usedQuestions=loadUsedQuestions();

function saveUsedQuestions(){
  try{
    localStorage.setItem(STORAGE_KEY,JSON.stringify([...usedQuestions]));
  }catch(e){}
}

/* ---------- Random helpers ---------- */
function randInt(min,max){
  return Math.floor(Math.random()*(max-min+1))+min;
}

function shuffle(array){
  const a=[...array];
  for(let i=a.length-1;i>0;i--){
    const j=Math.floor(Math.random()*(i+1));
    [a[i],a[j]]=[a[j],a[i]];
  }
  return a;
}

function uniqueNumbers(answer){
  const values=new Set([answer]);
  let attempts=0;

  while(values.size<4 && attempts<500){
    attempts++;
    const spread=Math.max(5,Math.floor(Math.abs(answer)*0.12)+5);
    let wrong=answer+randInt(-spread,spread);
    if(wrong===answer || wrong<0) continue;
    values.add(wrong);
  }

  /* Guaranteed fallback values */
  let fallback=1;
  while(values.size<4){
    if(fallback!==answer) values.add(fallback);
    fallback++;
  }
  return shuffle([...values]);
}

/*
  Generate many different expressions.
  Signature is the actual displayed question, so even if the answer
  is the same, a different expression is treated as a new question.
*/
function generateQuestion(){
  const type=randInt(0,6);

  if(type===0){
    const a=randInt(10,99),b=randInt(10,99);
    return {cat:'ADDITION',display:`${a} + ${b}`,answer:a+b};
  }

  if(type===1){
    const a=randInt(100,999),b=randInt(10,99);
    return {cat:'SUBTRACTION',display:`${a} − ${b}`,answer:a-b};
  }

  if(type===2){
    const a=randInt(12,99),b=randInt(6,49);
    return {cat:'MULTIPLICATION',display:`${a} × ${b}`,answer:a*b};
  }

  if(type===3){
    const divisor=randInt(2,20);
    const answer=randInt(5,80);
    const dividend=divisor*answer;
    return {cat:'DIVISION',display:`${dividend} ÷ ${divisor}`,answer};
  }

  if(type===4){
    const a=randInt(10,80),b=randInt(2,20),c=randInt(2,10);
    return {cat:'BODMAS / PEMDAS',display:`${a} + ${b} × ${c}`,answer:a+b*c};
  }

  if(type===5){
    const a=randInt(20,100),b=randInt(2,20),c=randInt(2,10);
    return {cat:'BODMAS / PEMDAS',display:`${a} − ${b} × ${c}`,answer:a-b*c};
  }

  const divisor=randInt(2,12);
  const quotient=randInt(4,40);
  const add=randInt(5,50);
  const dividend=divisor*quotient;
  return {
    cat:'BODMAS / PEMDAS',
    display:`${add} + ${dividend} ÷ ${divisor}`,
    answer:add+quotient
  };
}

function getUniqueQuestion(){
  /*
    Try repeatedly until the exact displayed equation has never been used.
    This prevents the opening question from always being the same.
  */
  let question;
  let attempts=0;

  do{
    question=generateQuestion();
    attempts++;
  }while(usedQuestions.has(question.display) && attempts<1000);

  /*
    If the current history somehow contains every generated candidate,
    start a fresh cycle. This only happens after a very large number
    of questions.
  */
  if(usedQuestions.has(question.display)){
    usedQuestions.clear();
  }

  usedQuestions.add(question.display);
  saveUsedQuestions();

  return question;
}

/* Optional reset helper.
   Open browser console and run resetQuestionHistory() if you ever want
   to allow old questions again. */
window.resetQuestionHistory=function(){
  usedQuestions.clear();
  try{localStorage.removeItem(STORAGE_KEY)}catch(e){}
  qIndex=0;
  renderQuestion();
};

/* ---------- App state ---------- */
let qIndex=0;
let timer=15;
let timerId=null;
let locked=false;
let currentQuestion=null;

const ticker=document.getElementById('ticker-track');
const tickerItems=[
  '🔴 LIVE MATH CHALLENGE','⚡ NEW QUESTION EVERY 15 SECONDS',
  '🧠 TEST YOUR BRAIN','🏆 COMMENT YOUR ANSWER',
  '🔥 LIVE STREAM NEXT','💡 CAN YOU SOLVE IT?'
];

ticker.innerHTML=[...tickerItems,...tickerItems]
  .map(x=>`<span class="ticker-item">${x}<span class="ticker-dot">•</span></span>`)
  .join('');

function renderQuestion(){
  clearInterval(timerId);
  locked=false;
  timer=15;

  currentQuestion=getUniqueQuestion();

  document.getElementById('cat-pill').textContent=currentQuestion.cat;
  document.getElementById('timer-text').textContent='15s';
  document.getElementById('timer-badge').className='timer-badge';
  document.getElementById('dynamic-cta').textContent=CTAS[qIndex%CTAS.length];

  document.getElementById('equation-display').innerHTML=
    currentQuestion.display.replace(
      /([+−×÷])/g,
      '<span class="op-blue">$1</span>'
    );

  const options=uniqueNumbers(currentQuestion.answer);
  const grid=document.getElementById('options-grid');

  grid.innerHTML=options.map((v,i)=>
    `<div class="option-card" data-value="${v}">
      <div class="option-letter">${String.fromCharCode(65+i)}</div>
      <div class="option-val">${v}</div>
    </div>`
  ).join('');

  grid.querySelectorAll('.option-card').forEach(card=>{
    card.addEventListener('click',()=>{
      choose(Number(card.dataset.value),currentQuestion.answer,card);
    });
  });

  timerId=setInterval(()=>{
    timer--;
    document.getElementById('timer-text').textContent=timer+'s';

    if(timer<=5){
      document.getElementById('timer-badge').classList.add('urgent');
      audio.playTick(true);
    }else{
      audio.playTick(false);
    }

    if(timer<=0){
      clearInterval(timerId);
      reveal(currentQuestion.answer);
    }
  },1000);
}

function choose(value,answer,card){
  if(locked)return;
  audio.init();

  if(value===answer){
    reveal(answer);
  }else{
    card.style.animation='shake .25s';
    setTimeout(()=>card.style.animation='',300);
  }
}

function reveal(answer){
  if(locked)return;
  locked=true;
  clearInterval(timerId);

  document.getElementById('timer-badge').className='timer-badge revealed';
  document.getElementById('timer-text').textContent='✓ '+answer;

  document.querySelectorAll('.option-card').forEach(card=>{
    const v=Number(card.dataset.value);

    if(v===answer){
      card.classList.add('correct-revealed');
      card.querySelector('.option-letter').textContent='✓';
    }else{
      card.classList.add('dimmed');
    }
  });

  document.getElementById('equation-display').innerHTML+=
    `<span class="solved-inline">= <span class="solved-inline-val">${answer}</span></span>`;

  audio.playChime();
  launchConfetti();

  setTimeout(()=>{
    qIndex++;
    renderQuestion();
  },3500);
}

document.body.addEventListener('pointerdown',()=>audio.init(),{once:true});

/* IMPORTANT:
   The first question is generated randomly here.
   It is NOT hard-coded as 50 + 20 ÷ 2.
*/
renderQuestion();
