const display = document.getElementById("display");

let expression = "";
let finished = false;

function show(value) {
    display.textContent = value || "0";
}

function press(value) {
    const operators = ["+", "-", "*", "/"];

    if (finished) {
        if (!operators.includes(value)) {
            expression = "";
        }
        finished = false;
    }

    if (operators.includes(value)) {
        if (expression === "" && value !== "-") return;

        if (operators.includes(expression.slice(-1))) {
            expression = expression.slice(0, -1);
        }

        expression += value;
    } else if (value === ".") {
        const current = expression.split(/[+\-*/]/).pop();
        if (current.includes(".")) return;
        expression += current === "" ? "0." : ".";
    } else {
        expression += value;
    }

    show(expression.replace(/\*/g, "×").replace(/\//g, "÷"));
}

function clearAll() {
    expression = "";
    finished = false;
    show("0");
}

function deleteLast() {
    if (finished) {
        clearAll();
        return;
    }

    expression = expression.slice(0, -1);
    show(expression.replace(/\*/g, "×").replace(/\//g, "÷"));
}

function percent() {
    if (!expression || finished) return;

    const match = expression.match(/(\d*\.?\d+)$/);
    if (!match) return;

    const number = Number(match[0]) / 100;
    expression = expression.slice(0, -match[0].length) + number;
    show(expression);
}

function calculate() {
    if (!expression) return;

    try {
        // Only allow calculator characters in the expression.
        if (!/^[0-9+\-*/.() ]+$/.test(expression)) {
            throw new Error("Invalid expression");
        }

        if (!/[0-9)]$/.test(expression)) {
            throw new Error("Incomplete expression");
        }

        const result = Function('"use strict"; return (' + expression + ')')();

        if (typeof result !== "number" || !Number.isFinite(result)) {
            throw new Error("Invalid result");
        }

        expression = String(Number(result.toPrecision(12)));
        show(expression);
        finished = true;
    } catch (error) {
        show("Error");
        expression = "";
        finished = true;
    }
}

// Keyboard support on computers
document.addEventListener("keydown", function(event) {
    const key = event.key;

    if (/^[0-9.+\-*/]$/.test(key)) {
        press(key);
    } else if (key === "Enter" || key === "=") {
        calculate();
    } else if (key === "Backspace") {
        deleteLast();
    } else if (key === "Escape") {
        clearAll();
    } else if (key === "%") {
        percent();
    }
});
