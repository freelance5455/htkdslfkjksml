// MATYKA CHEATS — FREE FIRE ASSISTANT (PREMIUM EDITION)
// Comprehensive Application Controller & Auth / Admin Proxy

const STORAGE_KEYS_KEY = 'matykat_keys_db';
const STORAGE_AUTH_KEY = 'matykat_auth_session';
const STORAGE_DEVICES_KEY = 'matykat_devices_db';

// Initial Default Key as requested
const DEFAULT_KEY = "MATYKA-E43V-STU6-39CP";

// Database of Sensi models across 5 manufacturers (~25 models each)
const SENSI_DATABASE = {
    iphone: generateManufacturerModels("iPhone", [
        "iPhone 6", "iPhone 6 Plus", "iPhone 6s", "iPhone 6s Plus", "iPhone 7", "iPhone 7 Plus",
        "iPhone 8", "iPhone 8 Plus", "iPhone X", "iPhone XR", "iPhone XS", "iPhone XS Max",
        "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone SE (2020)", "iPhone 12",
        "iPhone 12 mini", "iPhone 12 Pro", "iPhone 12 Pro Max", "iPhone 13", "iPhone 13 mini",
        "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro",
        "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max"
    ]),
    samsung: generateManufacturerModels("Samsung", [
        "Galaxy A10", "Galaxy A10s", "Galaxy A20", "Galaxy A30", "Galaxy A32", "Galaxy A50",
        "Galaxy A51", "Galaxy A52", "Galaxy A53", "Galaxy A54", "Galaxy A70", "Galaxy A71",
        "Galaxy A72", "Galaxy A73", "Galaxy S10", "Galaxy S20", "Galaxy S20 FE", "Galaxy S21",
        "Galaxy S21+", "Galaxy S21 Ultra", "Galaxy S22", "Galaxy S22+", "Galaxy S22 Ultra",
        "Galaxy S23", "Galaxy S23 Ultra", "Galaxy S24", "Galaxy S24 Ultra", "Galaxy M12", "Galaxy M32"
    ]),
    xiaomi: generateManufacturerModels("Xiaomi", [
        "Redmi 9", "Redmi 9A", "Redmi 9C", "Redmi 10", "Redmi 10C", "Redmi Note 8",
        "Redmi Note 9", "Redmi Note 9S", "Redmi Note 10", "Redmi Note 10 Pro", "Redmi Note 11",
        "Redmi Note 11 Pro", "Redmi Note 12", "Redmi Note 12 Pro", "Redmi Note 13", "Redmi Note 13 Pro",
        "POCO X3", "POCO X3 Pro", "POCO X4 Pro", "POCO X5", "POCO X5 Pro", "POCO F3",
        "POCO F4", "POCO F5", "Xiaomi 11T", "Xiaomi 12", "Xiaomi 13", "Black Shark 4"
    ]),
    motorola: generateManufacturerModels("Motorola", [
        "Moto E6s", "Moto E7", "Moto E13", "Moto G6", "Moto G7", "Moto G8 Play",
        "Moto G8 Power", "Moto G9 Play", "Moto G9 Plus", "Moto G10", "Moto G20",
        "Moto G22", "Moto G24", "Moto G30", "Moto G31", "Moto G32", "Moto G41",
        "Moto G50", "Moto G52", "Moto G53", "Moto G54", "Moto G60", "Moto G71",
        "Moto G82", "Moto G06", "Moto Edge 30", "Moto Edge 40", "Moto Razr 40"
    ]),
    oppo: generateManufacturerModels("OPPO", [
        "OPPO A15", "OPPO A16", "OPPO A17", "OPPO A18", "OPPO A31", "OPPO A53",
        "OPPO A54", "OPPO A55", "OPPO A57", "OPPO A58", "OPPO A74", "OPPO A78",
        "OPPO A94", "OPPO A96", "OPPO F15", "OPPO F19", "OPPO F21 Pro", "OPPO Reno 5",
        "OPPO Reno 6", "OPPO Reno 7", "OPPO Reno 8", "OPPO Reno 10", "OPPO Find X3",
        "OPPO Find X5", "OPPO Find X6", "OPPO K10", "OPPO A38", "OPPO A79"
    ])
};

function generateManufacturerModels(prefix, list) {
    let map = {};
    list.forEach((model, idx) => {
        let baseGeral = 90 + (idx % 10);
        let baseRed = 88 + (idx % 12);
        let base2x = 92 + (idx % 8);
        let base4x = 94 + (idx % 6);
        let baseAwm = 50 + (idx % 25);
        let baseLook = 75 + (idx % 15);
        map[model] = {
            geral: baseGeral,
            redDot: baseRed,
            mira2x: base2x,
            mira4x: base4x,
            miraAwm: baseAwm,
            olhadinha: baseLook
        };
    });
    return map;
}

// Initialization & Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    initAuthSystem();
    initAdminSystem();
    initSensiSystem();
    initBoostSystems();
    initOptSystem();
    checkExistingSession();
});

// AUTHENTICATION SYSTEM
function initAuthSystem() {
    // Seed default key if not present
    let keysDB = getKeysDB();
    if (keysDB.length === 0) {
        keysDB.push({
            key: DEFAULT_KEY,
            status: 'active',
            expiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
            usages: 1
        });
        saveKeysDB(keysDB);
    }

    const btnValidate = document.getElementById('btn-validate');
    const inputKey = document.getElementById('access-key');
    const authStatus = document.getElementById('auth-status');

    btnValidate.addEventListener('click', () => {
        let enteredKey = inputKey.value.trim();
        if (!enteredKey) {
            showAuthError("Insira uma Key de acesso válida.");
            return;
        }

        authStatus.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Validando no servidor proxy...';
        authStatus.style.color = 'var(--text-muted)';

        setTimeout(() => {
            let result = validateKeyServerSide(enteredKey);
            if (result.success) {
                authStatus.innerHTML = '<i class="fa-solid fa-check-circle"></i> Acesso autorizado com sucesso!';
                authStatus.style.color = 'var(--success-green)';
                
                // Register device session
                registerDeviceSession(enteredKey);

                setTimeout(() => {
                    document.getElementById('auth-screen').classList.add('hidden');
                    document.getElementById('app-container').classList.remove('hidden');
                }, 800);
            } else {
                showAuthError(result.message);
            }
        }, 1000);
    });
}

function showAuthError(msg) {
    const authStatus = document.getElementById('auth-status');
    authStatus.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${msg}`;
    authStatus.style.color = 'var(--danger-red)';
}

function validateKeyServerSide(keyStr) {
    let keysDB = getKeysDB();
    let found = keysDB.find(k => k.key === keyStr);
    if (!found) {
        return { success: false, message: 'Key não encontrada no sistema de autenticação.' };
    }
    if (found.status !== 'active') {
        return { success: false, message: 'Esta Key foi revogada ou desativada pelo administrador.' };
    }
    let expiryDate = new Date(found.expiry);
    if (Date.now() > expiryDate.getTime()) {
        return { success: false, message: 'Esta Key está expirada.' };
    }
    found.usages = (found.usages || 0) + 1;
    saveKeysDB(keysDB);
    return { success: true };
}

function checkExistingSession() {
    let session = localStorage.getItem(STORAGE_AUTH_KEY);
    if (session) {
        try {
            let data = JSON.parse(session);
            let res = validateKeyServerSide(data.key);
            if (res.success) {
                document.getElementById('access-key').value = data.key;
                document.getElementById('auth-screen').classList.add('hidden');
                document.getElementById('app-container').classList.remove('hidden');
            }
        } catch(e) {}
    }
}

function registerDeviceSession(keyUsed) {
    localStorage.setItem(STORAGE_AUTH_KEY, JSON.stringify({ key: keyUsed, time: Date.now() }));
    let devices = getDevicesDB();
    let deviceId = 'DEV-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    devices.push({
        id: deviceId,
        name: navigator.userAgent.includes('Mobile') ? 'Smartphone Android (Moto G06)' : 'Dispositivo Web Client',
        keyUsed: keyUsed,
        connectedAt: new Date().toLocaleDateString('pt-BR')
    });
    saveDevicesDB(devices);
}

// ADMIN PANEL SYSTEM
function initAdminSystem() {
    const btnOpen = document.getElementById('btn-admin-open');
    const btnClose = document.getElementById('btn-admin-close');
    const modal = document.getElementById('admin-modal');

    btnOpen.addEventListener('click', () => {
        modal.classList.remove('hidden');
        renderAdminKeysTable();
        renderAdminDevicesList();
    });

    btnClose.addEventListener('click', () => {
        modal.classList.add('hidden');
    });

    document.getElementById('btn-generate-key').addEventListener('click', () => {
        let days = parseInt(document.getElementById('new-key-days').value) || 30;
        let newKeyStr = "MATYKA-" + Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase();
        let keysDB = getKeysDB();
        keysDB.push({
            key: newKeyStr,
            status: 'active',
            expiry: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString(),
            usages: 0
        });
        saveKeysDB(keysDB);
        renderAdminKeysTable();
    });
}

function switchAdminTab(tabName) {
    document.querySelectorAll('.admin-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.admin-tab-content').forEach(content => content.classList.remove('active'));

    if (tabName === 'keys') {
        document.querySelectorAll('.admin-tab-btn')[0].classList.add('active');
        document.getElementById('admin-tab-keys').classList.add('active');
        renderAdminKeysTable();
    } else {
        document.querySelectorAll('.admin-tab-btn')[1].classList.add('active');
        document.getElementById('admin-tab-devices').classList.add('active');
        renderAdminDevicesList();
    }
}

function getKeysDB() {
    try {
        let data = localStorage.getItem(STORAGE_KEYS_KEY);
        return data ? JSON.parse(data) : [];
    } catch(e) { return []; }
}

function saveKeysDB(db) {
    localStorage.setItem(STORAGE_KEYS_KEY, JSON.stringify(db));
}

function getDevicesDB() {
    try {
        let data = localStorage.getItem(STORAGE_DEVICES_KEY);
        return data ? JSON.parse(data) : [];
    } catch(e) { return []; }
}

function saveDevicesDB(db) {
    localStorage.setItem(STORAGE_DEVICES_KEY, JSON.stringify(db));
}

function renderAdminKeysTable() {
    let tbody = document.getElementById('keys-tbody');
    let keysDB = getKeysDB();
    tbody.innerHTML = '';

    if (keysDB.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color: var(--text-muted);">Nenhuma Key cadastrada.</td></tr>';
        return;
    }

    keysDB.forEach((item, index) => {
        let tr = document.createElement('tr');
        let statusBadge = item.status === 'active' ? '<span class="badge-active">Ativa</span>' : '<span class="badge-revoked">Inativa</span>';
        let expiryStr = new Date(item.expiry).toLocaleDateString('pt-BR');
        tr.innerHTML = `
            <td><code>${item.key}</code></td>
            <td>${statusBadge}</td>
            <td>${expiryStr}</td>
            <td>
                <button class="btn-small" onclick="toggleKeyStatus(${index})"><i class="fa-solid fa-power-off"></i></button>
                <button class="btn-small" onclick="deleteKey(${index})" style="color:var(--danger-red);"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function toggleKeyStatus(index) {
    let keysDB = getKeysDB();
    if (keysDB[index]) {
        keysDB[index].status = keysDB[index].status === 'active' ? 'revoked' : 'active';
        saveKeysDB(keysDB);
        renderAdminKeysTable();
    }
}

function deleteKey(index) {
    let keysDB = getKeysDB();
    keysDB.splice(index, 1);
    saveKeysDB(keysDB);
    renderAdminKeysTable();
}

function renderAdminDevicesList() {
    let list = document.getElementById('devices-list');
    let devices = getDevicesDB();
    list.innerHTML = '';

    if (devices.length === 0) {
        list.innerHTML = '<div class="device-item" style="justify-content:center; color: var(--text-muted);">Nenhum dispositivo registrado.</div>';
        return;
    }

    devices.forEach(dev => {
        let div = document.createElement('div');
        div.className = 'device-item';
        div.innerHTML = `
            <div>
                <strong>${dev.name}</strong><br>
                <small style="color:var(--text-muted);">Key: ${dev.keyUsed} | Conectado em: ${dev.connectedAt}</small>
            </div>
            <span class="badge-active">${dev.id}</span>
        `;
        list.appendChild(div);
    });
}

// NAVIGATION SYSTEM & TABS
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));

    let targetTab = document.getElementById('tab-' + tabId);
    if (targetTab) {
        targetTab.classList.add('active');
    }

    // Map tabId to nav index
    const navMap = { 'inicio': 0, 'sensi': 1, 'hz': 2, 'fps': 3, 'headtracker': 4, 'recoil': 5, 'opt': 6 };
    let navIndex = navMap[tabId];
    if (navIndex !== undefined) {
        let navItems = document.querySelectorAll('.nav-item');
        if (navItems[navIndex]) navItems[navIndex].classList.add('active');
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// SENSI GENERATOR SYSTEM
function initSensiSystem() {
    const selBrand = document.getElementById('select-brand');
    const selModel = document.getElementById('select-model');
    const btnGenerate = document.getElementById('btn-generate-sensi');

    selBrand.addEventListener('change', () => {
        let brand = selBrand.value;
        selModel.innerHTML = '<option value="">Selecione o Modelo...</option>';
        if (brand && SENSI_DATABASE[brand]) {
            selModel.disabled = false;
            Object.keys(SENSI_DATABASE[brand]).forEach(modelName => {
                let opt = document.createElement('option');
                opt.value = modelName;
                opt.textContent = modelName;
                selModel.appendChild(opt);
            });
        } else {
            selModel.disabled = true;
        }
        btnGenerate.disabled = true;
    });

    selModel.addEventListener('change', () => {
        btnGenerate.disabled = !selModel.value;
    });

    btnGenerate.addEventListener('click', () => {
        let brand = selBrand.value;
        let model = selModel.value;
        let profile = document.getElementById('select-profile').value;

        if (!brand || !model) return;

        let baseValues = SENSI_DATABASE[brand][model];
        let multiplier = 1.0;
        if (profile === 'precisao') multiplier = 0.95;
        if (profile === 'rapida') multiplier = 1.1;

        let calculated = {
            geral: Math.min(100, Math.round(baseValues.geral * multiplier)),
            redDot: Math.min(100, Math.round(baseValues.redDot * multiplier)),
            mira2x: Math.min(100, Math.round(baseValues.mira2x * multiplier)),
            mira4x: Math.min(100, Math.round(baseValues.mira4x * multiplier)),
            miraAwm: Math.min(100, Math.round(baseValues.miraAwm * multiplier)),
            olhadinha: Math.min(100, Math.round(baseValues.olhadinha * multiplier))
        };

        let container = document.getElementById('sensi-grid-values');
        container.innerHTML = `
            <div class="sensi-item"><span>GERAL</span><span>${calculated.geral}</span></div>
            <div class="sensi-item"><span>RED DOT</span><span>${calculated.redDot}</span></div>
            <div class="sensi-item"><span>MIRA 2X</span><span>${calculated.mira2x}</span></div>
            <div class="sensi-item"><span>MIRA 4X</span><span>${calculated.mira4x}</span></div>
            <div class="sensi-item"><span>MIRA AWM</span><span>${calculated.miraAwm}</span></div>
            <div class="sensi-item"><span>OLHADINHA</span><span>${calculated.olhadinha}</span></div>
        `;

        document.getElementById('sensi-results-container').classList.remove('hidden');

        // Copy button action
        document.getElementById('btn-copy-all').onclick = () => {
            let textToCopy = `MATYKA CHEATS — SENSI (${model})\nGeral: ${calculated.geral}\nRed Dot: ${calculated.redDot}\nMira 2X: ${calculated.mira2x}\nMira 4X: ${calculated.mira4x}\nMira AWM: ${calculated.miraAwm}\nOlhadinha: ${calculated.olhadinha}`;
            navigator.clipboard.writeText(textToCopy);
            alert('Valores de sensibilidade copiados para a área de transferência!');
        };
    });
}

// BOOST & INJECTOR SYSTEMS
function initBoostSystems() {
    // HZ options selector
    setupOptionsSelector('hz-options');
    // FPS options selector
    setupOptionsSelector('fps-options');

    // Headtracker slider
    const htSlider = document.getElementById('ht-intensity');
    const htDisplay = document.getElementById('ht-val-display');
    const htNum = document.getElementById('slider-val-num');
    htSlider.addEventListener('input', () => {
        htDisplay.textContent = htSlider.value + '%';
        htNum.textContent = htSlider.value + '%';
    });

    // Inject Buttons
    document.getElementById('btn-inject-hz').addEventListener('click', () => runInjectionSimulation("HZ BOOST", "Aplicando taxa de atualização de tela..."));
    document.getElementById('btn-inject-fps').addEventListener('click', () => runInjectionSimulation("FPS BOOST", "Otimizando pipeline gráfico do Free Fire..."));
    document.getElementById('btn-inject-ht').addEventListener('click', () => runInjectionSimulation("MATYKA HEADTRACKER", "Calibrando assistente de mira e fixação..."));
    document.getElementById('btn-inject-recoil').addEventListener('click', () => runInjectionSimulation("NO RECOIL 25%", "Aplicando compensação linear de dispersão..."));
}

function setupOptionsSelector(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const cards = container.querySelectorAll('.option-card');
    cards.forEach(card => {
        card.addEventListener('click', () => {
            cards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
        });
    });
}

function runInjectionSimulation(moduleName, subtitle) {
    const overlay = document.getElementById('injection-overlay');
    const titleEl = document.getElementById('injection-title');
    const descEl = document.getElementById('injection-desc');
    const fillEl = document.getElementById('injection-progress');
    const percentEl = document.getElementById('injection-percent');

    titleEl.textContent = `INJETANDO ${moduleName}...`;
    descEl.textContent = subtitle;
    fillEl.style.width = '0%';
    percentEl.textContent = '0%';
    overlay.classList.remove('hidden');

    let progress = 0;
    let interval = setInterval(() => {
        progress += Math.floor(Math.random() * 15) + 5;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            fillEl.style.width = '100%';
            percentEl.textContent = '100%';
            
            setTimeout(() => {
                overlay.classList.add('hidden');
                alert(`Módulo ${moduleName} injetado com sucesso! Mantenha o Free Fire aberto.`);
            }, 600);
        }
        fillEl.style.width = progress + '%';
        percentEl.textContent = progress + '%';
    }, 120);
}

// OTIMIZAÇÃO RÁPIDA SYSTEM
function initOptSystem() {
    const btnRunOpt = document.getElementById('btn-run-opt');
    const metricStorage = document.getElementById('metric-storage');
    const metricRam = document.getElementById('metric-ram');
    const recsList = document.getElementById('opt-recs-list');

    // Simulate initial checks
    setTimeout(() => {
        metricStorage.textContent = '1.8 GB Cache Encontrado';
        metricRam.textContent = '64% Em Uso (4.2GB / 6.0GB)';
        recsList.innerHTML = `
            <li><i class="fa-solid fa-triangle-exclamation"></i> 14 arquivos temporários residuais detectados.</li>
            <li><i class="fa-solid fa-triangle-exclamation"></i> Processos secundários em segundo plano consumindo RAM.</li>
            <li><i class="fa-solid fa-check"></i> Pipeline gráfico pronto para aceleração.</li>
        `;
    }, 500);

    btnRunOpt.addEventListener('click', () => {
        btnRunOpt.disabled = true;
        btnRunOpt.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Otimizando Sistema...';

        setTimeout(() => {
            metricStorage.textContent = '0 MB (Limpado com Sucesso)';
            metricRam.textContent = '42% Otimizado (2.5GB Livre)';
            recsList.innerHTML = `
                <li><i class="fa-solid fa-check-circle" style="color:var(--success-green);"></i> Cache temporário completamente limpo.</li>
                <li><i class="fa-solid fa-check-circle" style="color:var(--success-green);"></i> Memória RAM liberada para o Free Fire.</li>
                <li><i class="fa-solid fa-check-circle" style="color:var(--success-green);"></i> Latência de toque reduzida em 14ms.</li>
            `;

            let reportBox = document.getElementById('opt-report-box');
            let reportContent = document.getElementById('opt-report-content');
            reportContent.innerHTML = `
                <strong>Relatório Executado com Sucesso:</strong><br>
                • Cache Liberado: 1.8 GB<br>
                • RAM Otimizada: +1.7 GB disponíveis<br>
                • Estabilidade de FPS: Aumentada em 28%<br>
                • Status do Proxy: Conexão limpa e estabilizada.
            `;
            reportBox.classList.remove('hidden');

            btnRunOpt.disabled = false;
            btnRunOpt.innerHTML = '<span>OTIMIZAR NOVAMENTE</span> <i class="fa-solid fa-wand-magic-sparkles"></i>';
        }, 1500);
    });
}
