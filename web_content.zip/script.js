(function(){
'use strict';

/* ================= constants ================= */
let W=320;            /* logical width: adapts to the screen shape (height is fixed at 180) */
const H=180,T=8,ROWS=22,GRAV=900,STEP=1/60;
let COLS=40,WW=320,camX=0,camY=0; /* world width in tiles / pixels, camera position */
const S=2;              /* canvas is 2x resolution (640x360) so text and zoom stay crisp */
/* ================= PERFORMANCE SETTINGS (edit these in code) =================
   targetFps   : 0 = draw at your screen's full refresh rate (90 / 120 Hz phones and tablets get the smooth look).
                 60 = cap at 60 to save battery and heat.
   interpolate : true = motion is smoothed between the fixed 60 Hz game steps, so 90/120 Hz screens really look
                 90/120 fps. false = draw the raw 60 Hz positions.
   textCache   : true = HUD / menu text is drawn once and reused (much cheaper than redrawing it every frame).
   cull        : true = skip drawing characters, lava and other things that are off screen.
   maxParts    : the most particles allowed at once (sparks, smoke, confetti). Lower = faster.
   autoQuality : true = if the frame rate drops, the game automatically cuts particles and screen shake until it recovers. */
const PERF={targetFps:0,interpolate:true,textCache:true,cull:true,maxParts:420,autoQuality:true};
let lowQ=false;   /* set automatically by autoQuality */
/* ================= CAMERA SETTINGS (edit these in code) =================
   zoom : camera zoom for each mode (dm = Deathmatch, td = Touchdown, ch = Chaser).
          1.0 = the classic 320x180 view.  SMALLER number = camera further away (characters look smaller,
          you see more of the map).  BIGGER number = closer (characters look bigger).
   min / max : the limits the zoom is clamped to (lower min if you want to go below 0.4).
   celebZoom : the camera zooms in to this level and centres on whoever scores a touchdown (bigger = closer).
               Set it to 0 to turn the zoom-in off.
   allowBeyondMap : true = the camera may show past the edge of a map (the empty space is filled with rock and sky).
                    false = the camera never shows anything outside the map (this limits zoom-out on small maps). */
const CAM={zoom:{dm:0.7,td:0.7,ch:0.5},min:0.4,max:2.0,allowBeyondMap:true,celebZoom:1.8};
let camZoom=1;   /* current camera zoom (set from CAM.zoom when a match starts) */
let ZOOM=1;
let VW=W/ZOOM,VH=H/ZOOM;
const WH=ROWS*T;
const SHAKE=0.3;        /* screen shake strength (0 = off, 1 = original) */
const TS=0.7;           /* text scale: smaller, cleaner HUD text */
/* menus/panels are designed for a 320x180 box; UI says where that box sits inside the real canvas */
const UI={ox:0,oy:0,s:1,x0:0,y0:0,w:320,h:180};
const AR_MIN=1.3,AR_MAX=2.9;   /* screen shapes that fill edge to edge (4:3 tablets ... 21:9 monitors) */
let celZoomK=0;   /* 0..1: how far the touchdown close-up zoom has blended in */
function updateView(){ ZOOM=Math.max(CAM.min,Math.min(CAM.max,camZoom)); if(celZoomK>0&&CAM.celebZoom>ZOOM) ZOOM*=Math.pow(CAM.celebZoom/ZOOM,celZoomK); if(!CAM.allowBeyondMap) ZOOM=Math.max(ZOOM,W/WW,1); VW=W/ZOOM; VH=H/ZOOM; }
const KILLS_TO_WIN=10,GOALS_TO_WIN=5;
/* seconds a defeated player waits before respawning (Chaser has no respawns) */
const RESPAWN_SECS={dm:2.5,td:10};
/* seconds of 'get ready' countdown before a match starts (Chaser has its own intro) */
const START_COUNT={dm:5,td:5};
let cdT=0,goT=0,cdLast=0;
const BOTS_DM=9;   // Deathmatch: 9 bots + you = 10 players
const BOTS_CH=9;   // Chaser: 9 bots + you = 10 players
const BOTS_TD=3;   // Touchdown: you + 3 teammates vs 4 bots = 4v4
/* ================= MULTIPLAYER SETTINGS (edit these in code) =================
   snapHz   : how many times per second the host sends the game state to the other phones (30 = smooth, 20 = lighter on a weak hotspot).
   inputHz  : how many times per second a phone sends its controls to the host.
   interpMs : how far behind the host a joined phone draws other players. Bigger = smoother on bad Wi-Fi, but more delayed.
   tdPer    : (unused - teams are split evenly between the real players who joined).
   max      : room size (must match MAX_PLAYERS in server.js). */
const NET={snapHz:30,inputHz:30,interpMs:90,tdPer:5,max:10,hostId:0,
  on:false,host:false,client:false,id:-1,ws:null,welcomed:false,humans:null,roster:[],rin:{},my:{},ev:[],seq:0,snapT:0,rtt:0,lag:false,lastSnap:0,
  byG:null,buf:[],lastN:0,ie:{j:0,d:0,s:0,k:0,a:0},lastIn:0,wasAtk:false,pingT:0,starting:false,role:'',findId:0};
const NET_SFX={hit:1,die:1,boom:1};   /* sounds every phone hears from the host */
const cv=document.getElementById('game');
const ctx=cv.getContext('2d',{alpha:false});
ctx.imageSmoothingEnabled=false;
const FONT='"Press Start 2P", ui-monospace, Menlo, Consolas, monospace';
if(document.fonts&&document.fonts.load){ try{document.fonts.load('8px "Press Start 2P"').catch(function(){});}catch(e){} }

/* ================= audio (tiny synth) ================= */
let AC=null,muted=false,NBUF=null,sndN=0,sndT=0;
/* sound settings: master = overall volume, range = how far away (in pixels) you can still hear other players' guns and swords */
const SND={master:1,range:320,minVol:0.08,otherVol:0.85,maxPerTick:7};
/* [start Hz, end Hz, wave, seconds, tone volume, noise volume, noise lowpass Hz] - noise gives guns their "bang" and swords their "swoosh" */
const SFX={
  jump:[260,520,'square',0.09,0.04], dash:[520,140,'sawtooth',0.13,0.05,0.04,3000],
  shoot:[780,150,'square',0.11,0.07,0.06,4200], smg:[900,200,'square',0.07,0.055,0.05,5000], scat:[320,70,'sawtooth',0.15,0.08,0.11,2600],
  shot:[210,40,'sawtooth',0.24,0.11,0.2,1900], laser:[1500,260,'sawtooth',0.15,0.06,0.02,6000], rail:[1300,100,'sawtooth',0.3,0.08,0.07,6000],
  power:[520,90,'square',0.17,0.09,0.08,3500], flame:[130,80,'sawtooth',0.13,0.05,0.12,1300], launch:[250,55,'sawtooth',0.22,0.09,0.12,1500],
  slash:[520,150,'sawtooth',0.13,0.05,0.09,3800], slash2:[380,70,'sawtooth',0.22,0.075,0.15,2600], stab:[950,320,'triangle',0.1,0.06,0.05,5200],
  cannon:[170,40,'square',0.2,0.1,0.18,1600], snipe:[900,60,'sawtooth',0.4,0.1,0.14,5000], needle:[1800,700,'square',0.05,0.04,0.02,7000],
  bolt:[420,120,'triangle',0.14,0.07,0.07,2500], zap:[1200,200,'sawtooth',0.1,0.05,0.12,7000], plasma:[360,140,'sine',0.25,0.08,0.05,3000],
  scythe:[300,90,'sine',0.3,0.01], scythe2:[240,60,'sine',0.42,0.01], scythehit:[200,60,'sine',0.3,0.01],
  hit:[240,70,'square',0.11,0.08,0.09,2600], die:[320,40,'sawtooth',0.38,0.09,0.1,1800],
  pick:[500,900,'square',0.12,0.05], score:[420,1100,'square',0.4,0.06], start:[300,700,'square',0.2,0.05],
  boom:[150,28,'sawtooth',0.34,0.12,0.22,1000]
};
function sfxPlay(kind,vol){
  if(muted) return;
  try{
    if(!AC){ const C=window.AudioContext||window.webkitAudioContext; if(!C) return; AC=new C(); }
    if(AC.state==='suspended') AC.resume();
    const p=SFX[kind]; if(!p) return;
    const now=Date.now(); if(now-sndT>60){ sndT=now; sndN=0; }
    if(++sndN>SND.maxPerTick) return;                   /* a crowd of guns must not choke the phone */
    const v=(vol==null?1:vol)*SND.master;
    if(kind==='scythe'||kind==='scythe2'||kind==='scythehit'){ scytheSnd(kind,v); return; }
    const t=AC.currentTime,o=AC.createOscillator(),g=AC.createGain();
    o.type=p[2]; o.frequency.setValueAtTime(p[0],t); o.frequency.exponentialRampToValueAtTime(Math.max(20,p[1]),t+p[3]);
    g.gain.setValueAtTime(p[4]*v,t); g.gain.exponentialRampToValueAtTime(0.0001,t+p[3]+0.02);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t+p[3]+0.03);
    if(p[5]){
      if(!NBUF){ NBUF=AC.createBuffer(1,Math.floor(AC.sampleRate*0.5),AC.sampleRate); const d=NBUF.getChannelData(0); for(let i=0;i<d.length;i++) d[i]=Math.random()*2-1; }
      const ns=AC.createBufferSource(),fl=AC.createBiquadFilter(),ng=AC.createGain();
      ns.buffer=NBUF; fl.type='lowpass'; fl.frequency.value=p[6]||3000;
      ng.gain.setValueAtTime(p[5]*v,t); ng.gain.exponentialRampToValueAtTime(0.0001,t+p[3]+0.02);
      ns.connect(fl); fl.connect(ng); ng.connect(AC.destination); ns.start(t); ns.stop(t+p[3]+0.03);
    }
  }catch(e){}
}
/* the reaper's scythe: a breathy whoosh that sweeps past, a low 'whoom' under it, a ringing steel shimmer, and a ghostly tail */
function scytheSnd(kind,v){
  const t=AC.currentTime,heavy=kind==='scythe2',hit=kind==='scythehit';
  if(!NBUF){ NBUF=AC.createBuffer(1,Math.floor(AC.sampleRate*0.5),AC.sampleRate); const d=NBUF.getChannelData(0); for(let i=0;i<d.length;i++) d[i]=Math.random()*2-1; }
  const out=AC.createGain(); out.gain.value=1; out.connect(AC.destination);
  const tone=function(type,f0,f1,t0,dur,vol){ const o=AC.createOscillator(),g=AC.createGain(); o.type=type; o.frequency.setValueAtTime(f0,t+t0); o.frequency.exponentialRampToValueAtTime(Math.max(20,f1),t+t0+dur);
    g.gain.setValueAtTime(0.0001,t+t0); g.gain.exponentialRampToValueAtTime(vol*v,t+t0+0.012); g.gain.exponentialRampToValueAtTime(0.0001,t+t0+dur); o.connect(g); g.connect(out); o.start(t+t0); o.stop(t+t0+dur+0.03); };
  const noise=function(ft,f0,f1,q,t0,dur,vol,peak){ const ns=AC.createBufferSource(),fl=AC.createBiquadFilter(),g=AC.createGain(); ns.buffer=NBUF; ns.loop=true; fl.type=ft; fl.Q.value=q;
    fl.frequency.setValueAtTime(f0,t+t0); fl.frequency.exponentialRampToValueAtTime(f1,t+t0+dur);
    g.gain.setValueAtTime(0.0001,t+t0); g.gain.exponentialRampToValueAtTime(vol*v,t+t0+dur*(peak||0.35)); g.gain.exponentialRampToValueAtTime(0.0001,t+t0+dur);
    ns.connect(fl); fl.connect(g); g.connect(out); ns.start(t+t0); ns.stop(t+t0+dur+0.03); };
  if(hit){
    noise('bandpass',3200,900,1.2,0,0.12,0.16,0.1);            /* steel biting in */
    tone('square',620,180,0,0.1,0.06); tone('sine',150,45,0,0.2,0.16);
    tone('triangle',1560,1500,0.005,0.35,0.035); tone('triangle',2340,2280,0.005,0.3,0.02);   /* ring */
    noise('lowpass',900,200,0.7,0.02,0.3,0.06,0.2);
    return;
  }
  const d=heavy?0.36:0.26;
  noise('bandpass',500,3600,heavy?2.2:3.2,0,d*0.55,(heavy?0.2:0.15),0.5);     /* whoosh rising ... */
  noise('bandpass',3600,700,2,d*0.5,d*0.6,(heavy?0.15:0.1),0.3);               /* ... and falling away */
  tone('sine',heavy?140:200,heavy?38:60,0,d,heavy?0.2:0.14);                  /* low whoom */
  tone('sawtooth',heavy?420:600,heavy?110:180,0,d*0.8,0.04);
  tone('triangle',1760,1320,d*0.3,0.4,0.03); tone('triangle',2637,2100,d*0.35,0.34,0.018);   /* steel shimmer */
  noise('highpass',5200,2600,0.7,d*0.2,0.2,0.035,0.2);                         /* whisper */
  if(heavy){ tone('sine',90,32,d*0.55,0.3,0.12); noise('lowpass',1400,180,0.7,d*0.5,0.35,0.08,0.2); }   /* heavy finisher thump + tail */
}
function sfx(kind){
  if(NET.host&&NET_SFX[kind]) rec(['s',kind]);
  sfxPlay(kind,1);
}
/* a sound that happens somewhere in the arena (another player's gun or sword): quieter the further it is from the screen */
function sfxAt(kind,x,y,g){
  if(NET.host) rec(['sa',kind,Math.round(x),Math.round(y),g===undefined?-1:g]);
  sfxPlayAt(kind,x,y);
}
function sfxPlayAt(kind,x,y){
  const d=Math.hypot(x-(camX+VW/2),y-(camY+VH/2)),k=1-d/SND.range;
  if(k<SND.minVol) return;
  sfxPlay(kind,Math.min(1,k)*SND.otherVol);
}
/* which sound a weapon makes */
function gunSnd(wd,pw){
  if(wd.id==='rail') return 'rail';
  if(wd.id==='revolver') return 'cannon';
  if(wd.id==='sniper') return 'snipe';
  if(wd.id==='needler') return 'needle';
  if(wd.id==='crossbow') return 'bolt';
  if(wd.id==='arc') return 'zap';
  if(wd.id==='plasma') return 'plasma';
  if(wd.id==='minigun') return 'smg';
  if(wd.id==='sawedoff') return 'shot';
  if(wd.id==='shotgun') return 'shot';
  if(wd.id==='scatter') return 'scat';
  if(wd.id==='smg') return 'smg';
  if(wd.id==='laser') return 'laser';
  if(wd.flame) return 'flame';
  if(wd.boom) return 'launch';
  return pw?'power':'shoot';
}
function meleeSnd(wd,st){ return wd.claw?(st===2?'scythe2':'scythe'):wd.id==='whip'?'bolt':wd.thrust?'stab':((wd.big||st===2||wd.dmg>=40)?'slash2':'slash'); }

/* ================= maps ================= */
let map=null,bg=null,PLAT=[],DM_SP=[],BLUE_SP=[],RED_SP=[],HAZ=[],PADS=[],ICE=false,ZL=[9,120,16,40],ZR=[295,120,16,40];
let curIdx=0,mapSel=0;
/* every map is mirrored left/right automatically. rect = [col,row,w,h] (5th value 0 = carve out) */
const MAPS=[
  {name:'NEON CITY',tag:'CLASSIC ARENA - BALANCED',seed:20240607,ballY:90,ice:false,pads:[],haz:[],
   rects:[[0,20,40,2],[0,0,1,22],[4,16,6,1],[1,11,3,1],[6,7,6,1],[16,14,8,1],[15,8,10,1],[12,16,1,4]],
   theme:{style:'city',sky:['#170f3a','#1e1348','#271757','#311d66','#3d2374','#4b2a80'],stars:50,
     orb:{x:257,y:33,r:8,c:'#ffe9a8',cut:'#3d2374'},sk:'#120b2b',sk2:'#1a1140',win:['#f7c948','#ff6ec7'],
     tile:{base:'#2b2450',line:'#211b41',top:'#8a7cf0',top2:'#5d50b8',speck:'#3a3168'}}},
  {name:'LAVA PIT',tag:'FALL IN THE LAVA AND YOU BURN!',seed:777,ballY:50,ice:false,pads:[],haz:[[120,160,80,20]],
   rects:[[0,20,40,2],[15,20,5,2,0],[0,0,1,22],[4,16,5,1],[17,15,6,1],[9,12,5,1],[16,9,8,1],[1,10,3,1]],
   theme:{style:'peaks',sky:['#2a0d24','#4a1230','#7a1a30','#a52a2a','#d9552a','#f28b30'],stars:8,orb:null,
     sk:'#1a0a14',sk2:'#2b1020',cap:'#ff5a1f',
     tile:{base:'#3d2a3a',line:'#2b1c29',top:'#ff8a3d',top2:'#c94a1f',speck:'#553a4f'}}},
  {name:'SKY TOWERS',tag:'WALL-JUMP UP THE TOWERS!',seed:31337,ballY:60,ice:false,pads:[],haz:[],
   rects:[[0,20,40,2],[0,0,1,22],[3,16,4,1],[4,12,3,1],[9,11,3,9],[13,9,14,1],[15,15,10,1],[17,4,6,1]],
   theme:{style:'clouds',sky:['#4aa8ff','#5cb6ff','#75c4ff','#94d2ff','#b4e0ff','#d3ecff'],stars:0,
     orb:{x:262,y:30,r:9,c:'#fff3b0',cut:null},sk:'#ffffff',sk2:'#dcecff',
     tile:{base:'#c9c3d8',line:'#a9a2c0',top:'#7bd88f',top2:'#4faa63',speck:'#b6b0cc'}}},
  {name:'FROZEN PEAKS',tag:'SLIPPERY ICE - YOU SLIDE!',seed:4242,ballY:65,ice:true,pads:[],haz:[],
   rects:[[0,20,40,2],[0,0,1,22],[14,19,12,1],[16,18,8,1],[18,17,4,1],[4,16,6,1],[6,12,5,1],[17,11,6,1],[1,8,3,1],[15,6,10,1]],
   theme:{style:'peaks',sky:['#0f2a4a','#17416b','#22598c','#3b7fae','#6aa8cf','#a5cfe6'],stars:35,
     orb:{x:60,y:30,r:7,c:'#eaf8ff',cut:'#17416b'},sk:'#5b86ad',sk2:'#7fa6c8',cap:'#ffffff',
     tile:{base:'#9ccdf0',line:'#7fb6de',top:'#eaf8ff',top2:'#bfe6fb',speck:'#ffffff'}}},
  {name:'SPRING WORKS',tag:'BOUNCE PADS LAUNCH YOU SKYWARD!',seed:9001,ballY:70,ice:false,pads:[[96,160,16]],haz:[],
   rects:[[0,20,40,2],[0,0,1,22],[1,8,8,1],[4,15,5,1],[16,11,8,1],[18,5,4,1]],
   theme:{style:'city',chim:true,sky:['#0e2530','#123240','#173f4e','#1d4c5c','#255a6b','#2e6a7a'],stars:0,orb:null,
     sk:'#0a1a22',sk2:'#0f2630',win:['#ffb02e','#7ff0d0'],
     tile:{base:'#4a5a66',line:'#38464f',top:'#ffb02e',top2:'#c27a0d',speck:'#5c6e7b'}}}
];

/* ---- six large maps, Chaser mode only (cols = width in tiles, mirrored left/right automatically) ---- */
(function(){
  const th=function(i){ return MAPS[i].theme; };
  /* at(dx, rects): shift a cluster of obstacles dx tiles to the right */
  const at=function(dx,rs){ return rs.map(function(r){ const q=r.slice(); q[0]+=dx; return q; }); };
  const cat=function(){ return Array.prototype.concat.apply([],arguments); };
  MAPS.push(
    {name:'GRAND ARENA',tag:'HUGE CITY ARENA - ROOM TO RUN',only:'ch',cols:144,seed:111,ballY:60,ice:false,pads:[],haz:[],
     rects:cat([[0,20,144,2],[0,0,1,22]],
       at(6,[[1,16,8,1],[11,12,8,1],[0,8,7,1]]),
       at(36,[[0,16,10,1],[12,12,8,1],[2,8,8,1]]),
       [[64,16,16,1],[66,11,12,1],[69,6,6,1],[28,17,1,3],[58,17,2,3]]),
     theme:th(0)},
    {name:'LAVA CANYON',tag:'FIVE LAVA PITS - WATCH YOUR STEP',only:'ch',cols:144,seed:222,ballY:60,ice:false,pads:[],
     haz:[[192,160,32,20],[352,160,32,20],[544,160,64,20],[768,160,32,20],[928,160,32,20]],
     rects:[[0,20,144,2],[24,20,4,2,0],[44,20,4,2,0],[68,20,8,2,0],[0,0,1,22],
       [4,16,6,1],[10,12,6,1],[2,8,6,1],
       [22,16,8,1],[30,13,6,1],[36,9,6,1],
       [42,16,8,1],
       [53,16,6,1],[58,11,6,1],
       [64,16,16,1],[66,7,10,1]],
     theme:th(1)},
    {name:'SKY CITADEL',tag:'TOWERS AND CLOUD BRIDGES',only:'ch',cols:168,seed:333,ballY:60,ice:false,pads:[],haz:[],
     rects:[[0,20,168,2],[0,0,1,22],
       [14,15,6,1],[8,12,4,8],[16,11,5,1],[22,8,4,12],
       [46,16,8,1],[55,12,5,1],[62,8,5,1],
       [74,16,20,1],[77,11,14,1],[80,6,8,1]],
     theme:th(2)},
    {name:'FROZEN WASTES',tag:'WIDE SLIPPERY ICE FIELDS',only:'ch',cols:168,seed:444,ballY:60,ice:true,pads:[],haz:[],
     rects:[[0,20,168,2],[0,0,1,22],
       [4,16,7,1],[10,12,6,1],[2,8,5,1],
       [30,19,16,1],[32,18,12,1],[34,17,8,1],
       [52,16,8,1],[58,12,7,1],[64,8,6,1],
       [76,16,16,1],[78,11,12,1],[81,7,6,1]],
     theme:th(3)},
    {name:'SPRING FACTORY',tag:'BOUNCE PADS ACROSS A BIG MAP',only:'ch',cols:168,seed:555,ballY:60,ice:false,
     pads:[[96,160,16],[416,160,16]],haz:[],
     rects:[[0,20,168,2],[0,0,1,22],
       [2,15,5,1],[16,8,8,1],[24,12,6,1],[30,16,6,1],
       [58,8,8,1],[66,12,6,1],[72,16,5,1],
       [80,16,8,1],[78,11,12,1]],
     theme:th(4)},
    {name:'NEON METROPOLIS',tag:'THE BIGGEST MAP - RUN FOR YOUR LIFE',only:'ch',cols:200,seed:666,ballY:60,ice:false,pads:[],haz:[],
     rects:cat([[0,20,200,2],[0,0,1,22]],
       [[6,16,8,1],[16,12,7,1],[5,8,6,1]],
       [[38,16,8,1],[47,12,7,1],[55,8,8,1]],
       [[72,16,7,1],[30,17,1,3],[66,17,2,3]],
       [[88,16,24,1],[91,11,18,1],[94,6,12,1]]),
     theme:Object.assign({},th(0),{win:['#7ff0d0','#ff6ec7']})}
  );
})();

/* ---- wide TOUCHDOWN arenas (S4 League style): long field, an end zone at each side, a contested centre tower.
        Only the LEFT half is written here - the right half is mirrored automatically. ---- */
(function(){
  const th=function(i){ return MAPS[i].theme; };
  MAPS.push(
    {name:'TD STADIUM',tag:'BIG NEON STADIUM - FIGHT FOR MIDFIELD',only:'td',cols:160,seed:801,ballY:30,ice:false,pads:[],haz:[],
     rects:[[0,20,160,2],[0,0,1,22],
       [3,16,8,1],[13,12,8,1],[3,8,7,1],
       [22,17,1,3],[28,16,8,1],[37,12,8,1],[30,8,6,1],
       [45,18,2,2],[52,16,6,1],[58,12,7,1],
       [68,16,12,1],[70,11,10,1],[73,6,7,1]],
     theme:Object.assign({},th(0),{win:['#7ff0d0','#ff6ec7']})},
    {name:'TD FROZEN GRIDIRON',tag:'SLIPPERY ICE FIELD - CARRY WITH CARE',only:'td',cols:176,seed:802,ballY:30,ice:true,pads:[],haz:[],
     rects:[[0,20,176,2],[0,0,1,22],
       [4,16,7,1],[12,12,7,1],[2,8,6,1],
       [27,17,1,3],[32,16,9,1],[40,12,6,1],[34,8,5,1],
       [50,17,2,3],[56,16,8,1],[63,12,7,1],
       [76,16,12,1],[78,11,10,1],[81,6,7,1]],
     theme:th(3)},
    {name:'TD SPRING YARD',tag:'BOUNCE PADS LAUNCH YOU INTO THE PLAY',only:'td',cols:168,seed:803,ballY:30,ice:false,
     pads:[[216,160,16],[440,160,16]],haz:[],
     rects:[[0,20,168,2],[0,0,1,22],
       [4,16,6,1],[11,12,7,1],[3,8,6,1],
       [34,15,9,1],[42,10,8,1],
       [54,17,1,3],[60,16,6,1],
       [72,16,12,1],[74,11,10,1],[77,6,7,1]],
     theme:th(4)}
  );
})();

const BLK=[];   /* Block-skill walls: {x,y(bottom),w,h,hp,max,t,owner,flash} */
function blockAt(px,py){ for(const k of BLK){ if(px>=k.x-k.w/2&&px<=k.x+k.w/2&&py>=k.y-k.h&&py<=k.y) return k; } return null; }
function solidAt(px,py){
  if(BLK.length&&blockAt(px,py)) return true;
  const i=Math.floor(px/T),j=Math.floor(py/T);
  return i<0||j<0||i>=COLS||j>=ROWS||map[j][i]===1;
}
function boxHits(x,y,w,h){
  if(BLK.length){ for(const k of BLK){ if(x<k.x+k.w/2&&x+w>k.x-k.w/2&&y<k.y&&y+h>k.y-k.h) return true; } }
  const x0=Math.floor(x/T),x1=Math.floor((x+w-0.001)/T),y0=Math.floor(y/T),y1=Math.floor((y+h-0.001)/T);
  for(let j=y0;j<=y1;j++)for(let i=x0;i<=x1;i++){
    if(i<0||j<0||i>=COLS||j>=ROWS||map[j][i]===1) return true;
  }
  return false;
}
function lineClear(x0,y0,x1,y1){
  const d=Math.hypot(x1-x0,y1-y0),n=Math.ceil(d/4);
  for(let k=1;k<n;k++){ const t=k/n; if(solidAt(x0+(x1-x0)*t,y0+(y1-y0)*t)) return false; }
  return true;
}
function moveEntity(e,dt){
  const nx=e.x+e.vx*dt;
  if(boxHits(nx-e.w/2,e.y-e.h,e.w,e.h)){
    const d=Math.sign(e.vx)||1; let n=0;
    while(n<40&&!boxHits(e.x+d*0.5-e.w/2,e.y-e.h,e.w,e.h)){ e.x+=d*0.5; n++; }
    e.vx=e.bounce?-e.vx*e.bounce:0;
  } else e.x=nx;
  const ny=e.y+e.vy*dt;
  if(boxHits(e.x-e.w/2,ny-e.h,e.w,e.h)){
    const d=Math.sign(e.vy)||1; let n=0;
    while(n<60&&!boxHits(e.x-e.w/2,e.y+d*0.5-e.h,e.w,e.h)){ e.y+=d*0.5; n++; }
    if(e.bounce&&Math.abs(e.vy)>60) e.vy=-e.vy*e.bounce; else e.vy=0;
  } else e.y=ny;
}

/* ================= map builders ================= */
function pixDisc(g,cx,cy,r,c){
  g.fillStyle=c;
  for(let dy=-r;dy<=r;dy++){ const w=Math.floor(Math.sqrt(r*r-dy*dy+r*0.6)); g.fillRect(cx-w,cy+dy,w*2,1); }
}
function makeGrid(def){
  const cols=def.cols||40;
  const g=Array.from({length:ROWS},function(){return new Array(cols).fill(0);});
  for(const r of def.rects){
    const v=r.length>4?r[4]:1;
    for(let j=r[1];j<r[1]+r[3];j++)for(let i=r[0];i<r[0]+r[2];i++){
      if(j<0||j>=ROWS) continue;
      if(i>=0&&i<cols) g[j][i]=v;
      const m=cols-1-i; if(m>=0&&m<cols) g[j][m]=v;
    }
  }
  return g;
}
function surfaces(g){
  const segs=[],CC=g[0].length;
  for(let j=1;j<ROWS;j++){
    const ok=function(i){ return g[j][i]===1&&g[j-1][i]===0&&(j<2||g[j-2][i]===0); };
    let i=0;
    while(i<CC){
      if(ok(i)){ let k=i; while(k+1<CC&&ok(k+1)) k++; segs.push([i*T,(k+1)*T,j*T]); i=k+1; } else i++;
    }
  }
  return segs;
}
function buildBG(def,g){
  const CC=g[0].length,BW=CC*T;
  const c=document.createElement('canvas'); c.width=BW; c.height=H;
  const x=c.getContext('2d'),th=def.theme,t=th.tile;
  const nm=def.name,deco=/LAVA/.test(nm)?'lava':/FROZEN/.test(nm)?'ice':/SKY/.test(nm)?'sky':/SPRING/.test(nm)?'gear':'neon';
  let s=def.seed; const rnd=function(){ s=(s*1664525+1013904223)>>>0; return s/4294967296; };
  /* sky bands with dithered seams */
  const n=th.sky.length,bh=Math.ceil(H/n);
  th.sky.forEach(function(col,i){ x.fillStyle=col; x.fillRect(0,i*bh,BW,bh); });
  for(let i=1;i<n;i++){
    x.fillStyle=th.sky[i]; const by=i*bh;
    for(let px=0;px<BW;px++){ if((px&1)===0) x.fillRect(px,by-1,1,1); if(px%4===0) x.fillRect(px,by-2,1,1); }
  }
  /* stars */
  for(let i=0;i<Math.round(th.stars*BW/W);i++){
    const sx=Math.floor(rnd()*BW),sy=Math.floor(rnd()*90),a=0.25+rnd()*0.5;
    x.fillStyle='rgba(255,255,255,'+a.toFixed(2)+')'; x.fillRect(sx,sy,1,1);
    if(rnd()<0.12){ x.fillRect(sx-1,sy,3,1); x.fillRect(sx,sy-1,1,3); }
  }
  /* sun / moon with halo */
  if(th.orb){
    const o=th.orb;
    x.globalAlpha=0.08; pixDisc(x,o.x,o.y,o.r+10,o.c); x.globalAlpha=0.14; pixDisc(x,o.x,o.y,o.r+5,o.c); x.globalAlpha=1;
    pixDisc(x,o.x,o.y,o.r,o.c);
    if(o.cut) pixDisc(x,o.x+3,o.y-1,o.r-1,o.cut);
    else { x.fillStyle='rgba(255,170,60,0.18)'; x.fillRect(o.x-3,o.y-2,3,2); x.fillRect(o.x+2,o.y+2,3,2); }
  }
  /* far + near scenery */
  if(th.style==='city'){
    x.globalAlpha=0.5; x.fillStyle=th.sk2;
    for(let px=0;px<BW;){ const w=14+Math.floor(rnd()*14),h=30+Math.floor(rnd()*44); x.fillRect(px,160-h,w,h); px+=w+Math.floor(rnd()*4); }
    x.globalAlpha=1;
    let px=8;
    while(px<BW-8){
      const w=12+Math.floor(rnd()*14),h=24+Math.floor(rnd()*58),y=160-h;
      x.fillStyle=th.sk; x.fillRect(px,y,w,h); x.fillStyle=th.sk2; x.fillRect(px,y,2,h); x.fillRect(px,y,w,1);
      if(rnd()<0.35){ x.fillStyle=th.sk; x.fillRect(px+(w>>1),y-8,1,8); x.fillStyle=Math.floor(rnd()*2)?'#ff4d5e':th.win[0]; x.fillRect(px+(w>>1),y-9,1,1); }
      else if(rnd()<0.2){ x.fillStyle=th.sk2; x.fillRect(px+2,y-4,w-4,4); }
      if(th.chim&&rnd()<0.4){
        x.fillStyle=th.sk; x.fillRect(px+w-5,y-14,4,14);
        x.fillStyle='rgba(180,220,230,0.25)'; x.fillRect(px+w-6,y-19,6,4); x.fillRect(px+w-3,y-24,5,4);
      }
      for(let wy=y+4;wy<158;wy+=6)for(let wx=px+3;wx<px+w-2;wx+=4){
        if(rnd()<0.3){ x.fillStyle=th.win[rnd()<0.5?0:1]; x.fillRect(wx,wy,2,2); }
      }
      if(rnd()<0.18){ x.fillStyle=th.win[1]; x.fillRect(px+w-2,y+6,1,Math.min(20,h-10)); }
      px+=w+Math.floor(rnd()*3);
    }
  } else if(th.style==='peaks'){
    const peak=function(px,h,col,col2,cap,k){
      for(let r=0;r<h;r++){
        const hw=Math.floor(r*0.9),y=160-h+r;
        x.fillStyle=col; x.fillRect(px-hw,y,hw*2,1);
        x.fillStyle=col2; x.fillRect(px-hw,y,Math.max(1,Math.floor(hw*0.45)),1);
        if(cap&&r<(k||10)){ x.fillStyle=cap; x.fillRect(px-hw,y,hw*2,1); if(r>=(k||10)-3&&((px+r)&1)) { x.fillStyle=col; x.fillRect(px-hw+2,y,2,1); } }
      }
    };
    x.globalAlpha=0.55;
    for(let px=-20;px<BW+20;px+=60+Math.floor(rnd()*30)) peak(px,36+Math.floor(rnd()*30),th.sk2,th.sk2,null);
    x.globalAlpha=1;
    for(let px=-10;px<BW+10;px+=44+Math.floor(rnd()*22)) peak(px,48+Math.floor(rnd()*50),th.sk,th.sk2,th.cap,10);
    if(deco==='lava'){
      for(let r=0;r<22;r++){ x.fillStyle='rgba(255,110,30,'+(0.02+r*0.012).toFixed(3)+')'; x.fillRect(0,138+r,BW,1); }
      for(let i=0;i<Math.round(14*BW/W);i++){ x.fillStyle='rgba(255,170,60,'+(0.3+rnd()*0.5).toFixed(2)+')'; x.fillRect(Math.floor(rnd()*BW),60+Math.floor(rnd()*90),1,1); }
    }
  } else if(th.style==='clouds'){
    const cloud=function(cx,cy,sz,col,col2){
      x.fillStyle=col; pixDisc(x,cx,cy,Math.round(5*sz),col); pixDisc(x,cx+Math.round(9*sz),cy-Math.round(3*sz),Math.round(7*sz),col);
      pixDisc(x,cx+Math.round(19*sz),cy,Math.round(5*sz),col); pixDisc(x,cx+Math.round(26*sz),cy+1,Math.round(4*sz),col);
      x.fillStyle=col; x.fillRect(cx-Math.round(4*sz),cy+1,Math.round(34*sz),Math.round(4*sz));
      x.fillStyle=col2; x.fillRect(cx-Math.round(3*sz),cy+Math.round(4*sz),Math.round(33*sz),Math.max(1,Math.round(2*sz)));
    };
    x.globalAlpha=0.6;
    for(let i=0;i<Math.round(8*BW/W);i++) cloud(Math.floor(rnd()*BW),20+Math.floor(rnd()*110),0.6,th.sk2,th.sk2);
    x.globalAlpha=1;
    for(let i=0;i<Math.round(8*BW/W);i++) cloud(Math.floor(rnd()*BW),24+Math.floor(rnd()*125),1,th.sk,th.sk2);
  }
  /* low fog */
  const fg=th.sky[th.sky.length-1];
  x.fillStyle=fg;
  for(let r=0;r<16;r++){ x.globalAlpha=r*0.012; x.fillRect(0,146+r,BW,1); }
  x.globalAlpha=1;
  /* tiles */
  for(let ty=0;ty<ROWS;ty++)for(let tx=0;tx<CC;tx++){
    if(g[ty][tx]!==1) continue;
    const px=tx*T,py=ty*T;
    x.fillStyle=t.base; x.fillRect(px,py,T,T);
    x.fillStyle=t.line; x.fillRect(px,py+3,T,1); x.fillRect(px,py+7,T,1);
    x.fillRect(px+((ty%2)?2:6),py,1,3); x.fillRect(px+((ty%2)?6:2),py+4,1,3);
    /* per-brick tone variation + bevel */
    if(rnd()<0.5){ x.fillStyle=rnd()<0.5?'rgba(255,255,255,0.07)':'rgba(0,0,0,0.12)'; x.fillRect(px+(rnd()<0.5?0:4),py+(rnd()<0.5?0:4),4,3); }
    x.fillStyle='rgba(255,255,255,0.1)'; x.fillRect(px,py,1,T);
    x.fillStyle='rgba(0,0,0,0.18)'; x.fillRect(px+T-1,py,1,T);
    const topExp=ty>0&&g[ty-1][tx]!==1,botExp=ty<ROWS-1&&g[ty+1][tx]!==1;
    if(topExp){
      x.fillStyle=t.top; x.fillRect(px,py,T,2); x.fillStyle=t.top2; x.fillRect(px,py+2,T,1);
      if(deco==='sky'||deco==='ice'){ x.fillStyle='rgba(255,255,255,0.7)'; if(rnd()<0.35) x.fillRect(px+Math.floor(rnd()*6),py,2,1); }
      if(deco==='sky'){ x.fillStyle=t.top; for(let i=0;i<4;i++) if(rnd()<0.6) x.fillRect(px+i*2,py-1,1,1+Math.floor(rnd()*2)); if(rnd()<0.06){ x.fillStyle=['#ff6ec7','#ffe066','#ffffff'][Math.floor(rnd()*3)]; x.fillRect(px+3,py-2,1,1); } }
      if(deco==='neon'){ x.fillStyle=th.win[1]; x.globalAlpha=0.8; x.fillRect(px+1+((tx&1)*3),py+1,2,1); x.globalAlpha=1; }
      if(deco==='lava'){ x.fillStyle='#ffd23f'; if(rnd()<0.3) x.fillRect(px+Math.floor(rnd()*6),py,1,1); }
      if(deco==='gear'){ x.fillStyle=(tx&1)?'#2a2a2a':'#ffb02e'; x.fillRect(px,py+2,T,1); }
    }
    if(deco==='lava'&&rnd()<0.12){ x.fillStyle='#ff8a3d'; const cx=px+1+Math.floor(rnd()*5),cy=py+4+Math.floor(rnd()*2); x.fillRect(cx,cy,1,2); x.fillRect(cx+1,cy+2,1,1); }
    if(deco==='gear'){ x.fillStyle=t.top; x.fillRect(px+1,py+1,1,1); x.fillRect(px+T-2,py+T-2,1,1); }
    if(deco==='neon'&&!topExp&&rnd()<0.08){ x.fillStyle=th.win[0]; x.fillRect(px+2,py+5,4,1); }
    if(botExp){
      x.fillStyle='rgba(0,0,0,0.28)'; x.fillRect(px,py+T-1,T,1);
      if(deco==='ice'&&rnd()<0.55){
        const L=2+Math.floor(rnd()*3); x.fillStyle=t.top;
        x.fillRect(px+2,py+T,4,1); x.fillRect(px+3,py+T+1,2,1); if(L>2) x.fillRect(px+3,py+T+2,1,L-2);
      }
    }
    if(rnd()<0.1){ x.fillStyle=t.speck; x.fillRect(px+2+Math.floor(rnd()*4),py+4+Math.floor(rnd()*3),1,1); }
  }
  for(const h of def.haz){ x.fillStyle='#ff5a1f'; x.fillRect(h[0],h[1]+2,h[2],H-h[1]-2); x.fillStyle='#ffb02e'; x.fillRect(h[0],h[1],h[2],2); }
  for(const p of def.pads){ x.fillStyle='#ff5ec8'; x.fillRect(p[0],p[1]-4,p[2],4); x.fillRect(BW-p[0]-p[2],p[1]-4,p[2],4); }
  return c;
}
MAPS.forEach(function(def){
  def.grid=makeGrid(def); def.bg=buildBG(def,def.grid);
  const BW=(def.cols||40)*T;
  const segs=surfaces(def.grid);
  def.plat=segs.filter(function(sg){return sg[1]-sg[0]>=16;});
  const pts=[];
  for(const sg of segs){
    const w=sg[1]-sg[0]; if(w<24) continue;
    pts.push([Math.round((sg[0]+sg[1])/2),sg[2]]);
    if(w>=120){ pts.push([Math.round(sg[0]+w*0.25),sg[2]]); pts.push([Math.round(sg[0]+w*0.75),sg[2]]); }
    if(BW>W&&w>=64){ for(let px=sg[0]+32;px<sg[1]-16;px+=72) pts.push([px,sg[2]]); }
  }
  def.dm=pts;
  const isTd=def.only==='td';
  let left=pts.filter(function(q){return q[0]<(isTd?BW*0.2:(BW>W?BW*0.4:130));}).sort(function(a,b){return b[1]-a[1];});
  if(!left.length) left=pts.slice().sort(function(a,b){return a[0]-b[0];}).slice(0,4);
  const b3=[]; for(let i=0;i<(isTd?4:3);i++) b3.push(left[i%left.length]);
  def.blue=b3; def.red=b3.map(function(q){return [BW-q[0],q[1]];});
  let fy=160; for(let j=ROWS-1;j>0;j--){ if(def.grid[j][2]===1&&def.grid[j-1][2]===0){ fy=j*T; break; } }
  if(def.only==='td'){ def.zoneL=[9,fy-48,24,48]; def.zoneR=[BW-33,fy-48,24,48]; }
  else { def.zoneL=[9,fy-40,16,40]; def.zoneR=[BW-25,fy-40,16,40]; }
  def.padList=[];
  def.pads.forEach(function(q){ def.padList.push({x:q[0],y:q[1],w:q[2],sq:0}); def.padList.push({x:BW-q[0]-q[2],y:q[1],w:q[2],sq:0}); });
});
function loadMap(i){
  const d=MAPS[i]; curIdx=i; map=d.grid; bg=d.bg; PLAT=d.plat; DM_SP=d.dm; BLUE_SP=d.blue; RED_SP=d.red;
  HAZ=d.haz; PADS=d.padList; ICE=d.ice; ZL=d.zoneL; ZR=d.zoneR;
  COLS=d.cols||40; WW=COLS*T; camX=0; camY=0; updateView();
  for(const q of PADS) q.sq=0;
}
loadMap(0);

/* ================= state ================= */
let state='menu',mode='dm',diff=1,paused=false;
let fighters=[],bullets=[],parts=[],feed=[],ball=null,corpses=[],texts=[],rings=[],slashes=[],beams=[];
let scores={blue:0,red:0},time=0,shake=0,winner=null,winTeam=null,overT=0,menuT=0;
let earned=0,myGoals=0,lastResult=null;
let hitstop=0,flashT=0,flashCol='#ffffff',banner=null,streak=0,streakT=0,pendingMode='dm';
let celeb=null,fireworks=[],chTime=0,chaser=null,reaper=null;
const CH_TIME=300,CH_COUNT=5,CH_ROUNDS=10,CH_HP=600,CH_TAKE=0.7;   /* chaser: lots of HP, takes 70% damage, can be killed */
function fmax(f){ return f.role==='chaser'?CH_HP:f.maxhp; }
let chRound=0,chPhase='count',chPT=0,chLastN=0,chWinT=-1;   /* chWinT: seconds since the CHASER WIN popup started (-1 = hidden) */
let demo=[];
const DIFF=[
  {name:'EASY',jit:0.28,dash:0.10,fire:0.5,thk:0.45},
  {name:'NORMAL',jit:0.15,dash:0.2,fire:0.75,thk:0.3},
  {name:'HARD',jit:0.06,dash:0.35,fire:1,thk:0.18}
];

/* ================= weapons, characters, save data ================= */
const WEAP={
  pulse:{id:'pulse',slot:0,name:'PULSE BLADE',cost:0,desc:'BALANCED - 3RD HIT FIRES A WAVE',dmg:24,cd:0.34,dur:0.16,range:20,kb:150,color:'#bff3ff',big:false,wave:'finisher',lunge:120},
  fang:{id:'fang',slot:0,name:'TWIN FANG',cost:120,desc:'FAST DOUBLE-HITS',dmg:9,cd:0.2,dur:0.12,range:18,kb:90,color:'#a0ffd8',big:false,multi:true,lunge:110},
  katana:{id:'katana',slot:0,name:'KATANA',cost:220,desc:'QUICK DRAW - CRITS AFTER A PAUSE',dmg:25,cd:0.27,dur:0.12,range:22,kb:130,color:'#ffd1ec',big:false,crit:true,lunge:150},
  spear:{id:'spear',slot:0,name:'STAR SPEAR',cost:260,desc:'LONG THRUST PIERCES A LINE',dmg:22,cd:0.4,dur:0.14,range:36,kb:120,color:'#c6ff9e',big:false,thrust:true,lunge:170},
  cleaver:{id:'cleaver',slot:0,name:'GREAT CLEAVER',cost:300,desc:'SLOW, HEAVY, SHOCKWAVE FINISHER',dmg:42,cd:0.62,dur:0.2,range:27,kb:230,color:'#ffb27a',big:true,stun:0.3,quake:'finisher',lunge:90},
  hammer:{id:'hammer',slot:0,name:'THUNDER HAMMER',cost:380,desc:'GROUND-SLAM SHOCKWAVE ON EVERY HIT',dmg:50,cd:0.85,dur:0.24,range:26,kb:320,color:'#ffd23f',big:true,stun:0.4,quake:'all',lunge:80},
  vamp:{id:'vamp',slot:0,name:'VAMP BLADE',cost:500,desc:'HEALS YOU EVERY TIME IT HITS',dmg:22,cd:0.3,dur:0.14,range:22,kb:120,color:'#ff6b8a',big:false,steal:12,lunge:110},
  storm:{id:'storm',slot:0,name:'STORM BLADE',cost:550,desc:'LIGHTNING JUMPS TO NEARBY FOES',dmg:20,cd:0.3,dur:0.14,range:22,kb:120,color:'#8fd8ff',big:false,chain:true,lunge:110},
  ion:{id:'ion',slot:0,name:'ION SABER',cost:600,desc:'EVERY SLASH FIRES A PLASMA WAVE',dmg:20,cd:0.32,dur:0.14,range:22,kb:120,color:'#e070ff',big:false,wave:'all',lunge:110},
  blaster:{id:'blaster',slot:1,name:'BLASTER',cost:0,desc:'EVERY 4TH SHOT IS A POWER SHOT',dmg:9,cd:0.17,speed:290,life:0.9,pellets:1,spread:0,jit:0,pierce:false,color:'#3b3f55',bc:null,len:2,shell:true,power:{n:4,mul:1.7}},
  dual:{id:'dual',slot:1,name:'DUAL PISTOLS',cost:220,desc:'TWO SHOTS PER PULL',dmg:7,cd:0.2,speed:300,life:0.8,pellets:2,spread:0.07,jit:0.02,pierce:false,color:'#3b5a8a',bc:'#9fd0ff',len:2,shell:true},
  scatter:{id:'scatter',slot:1,name:'SCATTER GUN',cost:150,desc:'3 PELLETS - HURTS MOST UP CLOSE',dmg:6,cd:0.45,speed:270,life:0.4,pellets:3,spread:0.22,jit:0.03,pierce:false,color:'#a8561e',bc:'#ffb27a',len:4,fall:true},
  smg:{id:'smg',slot:1,name:'RAPID SMG',cost:200,desc:'SPINS UP - FIRES FASTER AS YOU HOLD',dmg:5,cd:0.12,speed:300,life:0.7,pellets:1,spread:0,jit:0.09,pierce:false,color:'#1f7a4d',bc:'#9dffb8',len:3,shell:true,spin:{from:0.12,to:0.055}},
  shotgun:{id:'shotgun',slot:1,name:'PUMP SHOTGUN',cost:300,desc:'5 PELLETS - HUGE CLOSE DAMAGE',dmg:6,cd:0.75,speed:280,life:0.35,pellets:5,spread:0.13,jit:0.02,pierce:false,color:'#7a4a22',bc:'#ffd08a',len:4,shell:true,kick:2,fall:true},
  ricochet:{id:'ricochet',slot:1,name:'RICOCHET GUN',cost:400,desc:'SHOTS BOUNCE OFF WALLS',dmg:11,cd:0.28,speed:260,life:1.6,pellets:1,spread:0,jit:0.02,pierce:false,color:'#1f6a7a',bc:'#8ff5ff',len:3,bounce:3},
  laser:{id:'laser',slot:1,name:'PULSE LASER',cost:480,desc:'INSTANT BEAM, NEVER MISSES',dmg:13,cd:0.32,hitscan:true,pierce:false,range:300,pellets:1,color:'#1f6a5a',bc:'#7dffea',len:3,kick:0.5},
  flame:{id:'flame',slot:1,name:'FLAMETHROWER',cost:450,desc:'SETS FOES ON FIRE',dmg:2,cd:0.05,speed:170,life:0.32,pellets:1,spread:0,jit:0.16,pierce:true,color:'#8a3a1a',bc:'#ff8a2e',len:4,burn:true,flame:true},
  grenade:{id:'grenade',slot:1,name:'GRENADE LAUNCHER',cost:420,desc:'BOUNCING BOMBS, BLAST ON CONTACT',dmg:30,cd:0.9,speed:190,life:1.4,pellets:1,spread:0,jit:0,pierce:false,color:'#3a5a3a',bc:'#b8ff8a',len:4,boom:true,radius:26,grav:true,bounce:99,kick:2},
  rail:{id:'rail',slot:1,name:'RAILGUN',cost:350,desc:'INSTANT BEAM PIERCES EVERYONE',dmg:32,cd:0.8,hitscan:true,pierce:true,range:420,pellets:1,color:'#5b3aa8',bc:'#e0c8ff',len:5,kick:1.5},
  rocket:{id:'rocket',slot:1,name:'ROCKET LAUNCHER',cost:520,desc:'EXPLODES ON IMPACT, ROCKET JUMP!',dmg:38,cd:1.1,speed:210,life:1.6,pellets:1,spread:0,jit:0,pierce:false,color:'#6a2a2a',bc:'#ff9a4d',len:6,boom:true,radius:30,kick:3}
};
/* ---- ten more melee weapons and ten more guns ---- */
Object.assign(WEAP,{
  dagger:{id:'dagger',slot:0,name:'SHADOW DAGGER',cost:100,desc:'LIGHTNING FAST - CRITS AFTER A PAUSE',dmg:8,cd:0.14,dur:0.09,range:15,kb:60,color:'#c9d3ff',big:false,crit:true,lunge:160},
  axe:{id:'axe',slot:0,name:'BATTLE AXE',cost:320,desc:'HEAVY CHOP WITH A LONG STUN',dmg:34,cd:0.5,dur:0.17,range:24,kb:200,color:'#e0a060',big:true,stun:0.3,lunge:100},
  flamesword:{id:'flamesword',slot:0,name:'FLAME SWORD',cost:420,desc:'SETS FOES ON FIRE',dmg:17,cd:0.3,dur:0.14,range:22,kb:110,color:'#ff7a2e',big:false,burn:true,lunge:110},
  sickle:{id:'sickle',slot:0,name:'BLOOD SICKLE',cost:520,desc:'WIDE ARC - STEALS LIFE',dmg:20,cd:0.32,dur:0.15,range:24,kb:130,color:'#ff3b5c',big:true,steal:8,lunge:110},
  halberd:{id:'halberd',slot:0,name:'HALBERD',cost:460,desc:'LONG REACH CHOP',dmg:30,cd:0.55,dur:0.16,range:40,kb:180,color:'#a8d8ff',big:true,thrust:true,stun:0.2,lunge:140},
  whip:{id:'whip',slot:0,name:'ENERGY WHIP',cost:400,desc:'VERY LONG LASH',dmg:13,cd:0.34,dur:0.15,range:46,kb:80,color:'#ff9ee0',big:false,lunge:60},
  mace:{id:'mace',slot:0,name:'WAR MACE',cost:440,desc:'CRUSHING BLOWS - QUAKE FINISHER',dmg:38,cd:0.6,dur:0.2,range:24,kb:250,color:'#ffd9a0',big:true,stun:0.35,quake:'finisher',lunge:90},
  trident:{id:'trident',slot:0,name:'STORM TRIDENT',cost:480,desc:'THRUST - LIGHTNING ARCS TO FOES',dmg:20,cd:0.4,dur:0.14,range:34,kb:120,color:'#5fd8ff',big:false,thrust:true,chain:true,lunge:150},
  crescent:{id:'crescent',slot:0,name:'CRESCENT BLADE',cost:580,desc:'EVERY SLASH THROWS A BIG WAVE',dmg:21,cd:0.36,dur:0.15,range:23,kb:140,color:'#ffe66d',big:true,wave:'all',lunge:110},
  iceblade:{id:'iceblade',slot:0,name:'FROST BLADE',cost:360,desc:'HEAVY STUN - FREEZES FOES IN PLACE',dmg:18,cd:0.34,dur:0.14,range:22,kb:60,color:'#aeeaff',big:false,stun:0.55,lunge:100},
  revolver:{id:'revolver',slot:1,name:'HAND CANNON',cost:260,desc:'SLOW, HEAVY HITTER',dmg:27,cd:0.55,speed:360,life:0.8,pellets:1,spread:0,jit:0.01,pierce:false,color:'#9aa5c4',bc:'#ffd08a',len:4,shell:true,kick:1.6},
  triburst:{id:'triburst',slot:1,name:'TRI-BURST',cost:280,desc:'3 SHOTS IN A LINE',dmg:7,cd:0.4,speed:330,life:0.8,pellets:3,spread:0,jit:0.01,line:true,pierce:false,color:'#3a6a8a',bc:'#9fe0ff',len:4,shell:true},
  sniper:{id:'sniper',slot:1,name:'SNIPER RIFLE',cost:540,desc:'LONG RANGE BEAM - ONE BIG HIT',dmg:48,cd:1.3,hitscan:true,pierce:false,range:640,pellets:1,color:'#3a3a4a',bc:'#fff3b0',len:9,kick:2.5,th:2},
  needler:{id:'needler',slot:1,name:'NEEDLER',cost:320,desc:'FAST NEEDLES PIERCE FOES',dmg:5,cd:0.09,speed:420,life:0.6,pellets:1,spread:0,jit:0.06,pierce:true,color:'#a02a6a',bc:'#ff9ee0',len:3,blen:7},
  crossbow:{id:'crossbow',slot:1,name:'CROSSBOW',cost:420,desc:'SLOW BOLT THAT PIERCES',dmg:30,cd:0.7,speed:300,life:1.1,pellets:1,spread:0,jit:0,pierce:true,color:'#7a4a22',bc:'#e6d2a8',len:4,blen:9,kick:0.8},
  minigun:{id:'minigun',slot:1,name:'MINIGUN',cost:600,desc:'SPINS UP TO INSANE SPEED',dmg:4,cd:0.1,speed:320,life:0.7,pellets:1,spread:0,jit:0.14,pierce:false,color:'#4a4a58',bc:'#ffcf6a',len:8,shell:true,spin:{from:0.1,to:0.032},kick:0.5},
  arc:{id:'arc',slot:1,name:'ARC CASTER',cost:500,desc:'SHORT RANGE LIGHTNING',dmg:9,cd:0.11,hitscan:true,pierce:false,range:150,pellets:1,color:'#2a4a8a',bc:'#8fd8ff',len:3,zig:true,kick:0.3},
  plasma:{id:'plasma',slot:1,name:'PLASMA CANNON',cost:560,desc:'BOUNCING ORB THAT EXPLODES',dmg:26,cd:0.85,speed:230,life:1.3,pellets:1,spread:0,jit:0.01,pierce:false,color:'#3a2a6a',bc:'#c28cff',len:5,boom:true,radius:24,bounce:2,kick:1.5},
  sawedoff:{id:'sawedoff',slot:1,name:'SAWED-OFF',cost:340,desc:'8 PELLETS - BRUTAL UP CLOSE',dmg:5,cd:0.95,speed:270,life:0.3,pellets:8,spread:0.1,jit:0.03,pierce:false,color:'#6a4a2a',bc:'#ffd08a',len:3,shell:true,kick:3,fall:true},
  cluster:{id:'cluster',slot:1,name:'CLUSTER BOMB',cost:580,desc:'EXPLODES INTO MORE BOMBLETS',dmg:22,cd:1.0,speed:200,life:1.2,pellets:1,spread:0,jit:0,pierce:false,color:'#4a5a2a',bc:'#ffb84d',len:4,boom:true,radius:20,grav:true,bounce:99,frag:true,kick:2}
});
const WEAP_LIST=['pulse','fang','katana','spear','cleaver','hammer','vamp','storm','ion','blaster','dual','scatter','smg','shotgun','ricochet','laser','flame','grenade','rail','rocket','dagger','axe','flamesword','sickle','halberd','whip','mace','trident','crescent','iceblade','revolver','triburst','sniper','needler','crossbow','minigun','arc','plasma','sawedoff','cluster'];
WEAP.claw={id:'claw',slot:0,name:'CHASER SCYTHE',cost:0,desc:'',dmg:28,cd:0.3,dur:0.15,range:32,kb:200,color:'#ff7a2e',big:true,lunge:180,stun:0.25,wave:'finisher',claw:true,burn:true,steal:6};
const CHARS={
  rush:{id:'rush',name:'RUSH',cost:0,desc:'BALANCED ALL-ROUNDER',hp:100,spd:1,jump:1,dcd:1,main:'#38b6ff',dark:'#1b62a8',hair:'#b6f0ff',style:'cap'},
  volt:{id:'volt',name:'VOLT',cost:150,desc:'FAST RUNNER, LOW HEALTH',hp:90,spd:1.12,jump:1,dcd:0.8,main:'#ffd23f',dark:'#a87a0d',hair:'#fff2b3',style:'spike'},
  brick:{id:'brick',name:'BRICK',cost:250,desc:'TOUGH BUT SLOWER',hp:130,spd:0.92,jump:1,dcd:1,main:'#8a93a8',dark:'#4b5468',hair:'#d0d6e6',style:'helm'},
  shade:{id:'shade',name:'SHADE',cost:300,desc:'HIGH JUMPS, QUICK DASH',hp:85,spd:1.04,jump:1.1,dcd:0.85,main:'#7a4bd6',dark:'#402080',hair:'#c9a8ff',style:'mask'},
  blaze:{id:'blaze',name:'BLAZE',cost:350,desc:'ALL YOUR HITS DEAL 12% MORE',hp:100,spd:1.05,jump:1,dcd:0.95,dm:1.12,main:'#ff5a1f',dark:'#a32a0d',hair:'#ffd23f',style:'flame'},
  frost:{id:'frost',name:'FROST',cost:400,desc:'SLOWLY REGENERATES HEALTH',hp:105,spd:0.98,jump:1.05,dcd:0.95,regen:3,main:'#7fdcff',dark:'#2f86b0',hair:'#eaffff',style:'hood'},
  aura:{id:'aura',name:'AURA',cost:500,desc:'BEST ALL-ROUND STATS',hp:110,spd:1.06,jump:1.05,dcd:0.85,main:'#ff9e2c',dark:'#a85a0d',hair:'#ffe08a',style:'crown'},
  ghost:{id:'ghost',name:'GHOST',cost:550,desc:'SUPER FAST AND FLOATY',hp:80,spd:1.12,jump:1.12,dcd:0.7,main:'#d6d2ee',dark:'#8a86aa',hair:'#ffffff',style:'ghost'},
  rex:{id:'rex',name:'REX',cost:600,desc:'HUGE HP, HARD TO KNOCK BACK',hp:150,spd:0.88,jump:0.95,dcd:1.1,kbr:0.5,main:'#5cc46a',dark:'#2b7a36',hair:'#c7f5a0',style:'horn'}
};
const CHAR_LIST=['rush','volt','brick','shade','blaze','frost','aura','ghost','rex'];
const REAPERS={
  rp_shadow:{id:'rp_shadow',name:'SHADOW REAPER',cost:0,desc:'THE CLASSIC HOODED SPIRIT',robe:'#1a1026',hi:'#3a1f55',inner:'#241338',rim:'#4a2a70',band:'#ff4d5e',face:'void',eye:'#ff2a3a',eyeHi:'#ffd0d0',haze:'#ff2a3a',pole:'#6a4a2a',blade:'#c8d0e0',edge:'#ffffff',trail:['#5a2a8a','#ff4d5e'],fx:'none'},
  rp_bone:{id:'rp_bone',name:'BONE LORD',cost:150,desc:'PALE ROBES AND A GRINNING SKULL',robe:'#d8d2c0',hi:'#f4f0e4',inner:'#b8b098',rim:'#ffffff',band:'#6a5a3a',face:'skull',eye:'#38f0ff',eyeHi:'#ffffff',haze:'#38f0ff',pole:'#e8e0c8',blade:'#e8e4d8',edge:'#ffffff',trail:['#cfc8b0','#38f0ff'],fx:'none'},
  rp_frost:{id:'rp_frost',name:'FROST WRAITH',cost:250,desc:'ICE BLADE AND A FREEZING MIST',robe:'#2a5a8a',hi:'#6ab8e8',inner:'#1d4468',rim:'#bfeaff',band:'#eaffff',face:'void',eye:'#7dffea',eyeHi:'#ffffff',haze:'#7fdcff',pole:'#8ab0c8',blade:'#a5e6ff',edge:'#ffffff',trail:['#7fdcff','#ffffff'],fx:'ice'},
  rp_plague:{id:'rp_plague',name:'PLAGUE REAPER',cost:300,desc:'BEAKED MASK AND TOXIC BUBBLES',robe:'#2a3a1a',hi:'#4a6a2a',inner:'#1d2a12',rim:'#7ab04a',band:'#c9b98a',face:'beak',eye:'#e8ff3a',eyeHi:'#ffffff',haze:'#a3e635',pole:'#5a4a2a',blade:'#9ab070',edge:'#e8ffb0',trail:['#4a6a2a','#a3e635'],fx:'toxic'},
  rp_blood:{id:'rp_blood',name:'BLOOD HARVESTER',cost:350,desc:'CRIMSON ROBE THAT KEEPS DRIPPING',robe:'#5a0a14',hi:'#a31a2a',inner:'#3a0610',rim:'#ff4d5e',band:'#1a0408',face:'void',eye:'#ffffff',eyeHi:'#ffd0d0',haze:'#ff2a3a',pole:'#2a1010',blade:'#b01a2a',edge:'#ff8a96',trail:['#a31a2a','#ff4d5e'],fx:'blood'},
  rp_gold:{id:'rp_gold',name:'GOLDEN DEATH',cost:450,desc:'ROYAL ROBES WITH A HOLY HALO',robe:'#2a2210',hi:'#c9992a',inner:'#3a2e12',rim:'#ffd23f',band:'#ffd23f',face:'skull',eye:'#ffb02e',eyeHi:'#ffffff',haze:'#ffd23f',pole:'#c9992a',blade:'#ffd23f',edge:'#fff3b0',trail:['#ffd23f','#fff3b0'],fx:'halo'},
  rp_void:{id:'rp_void',name:'VOID SPECTER',cost:500,desc:'A ROBE FULL OF DISTANT STARS',robe:'#0a0618',hi:'#2a1a5a',inner:'#120a2a',rim:'#7a4aff',band:'#ff6ec7',face:'void',eye:'#ff6ec7',eyeHi:'#ffffff',haze:'#7a4aff',pole:'#3a2a6a',blade:'#b088ff',edge:'#ffd1f0',trail:['#7a4aff','#ff6ec7'],fx:'stars'},
  rp_inferno:{id:'rp_inferno',name:'INFERNO REAPER',cost:600,desc:'BURNING HOOD AND A FLAMING SCYTHE',robe:'#3a1208',hi:'#a32a0d',inner:'#4a1a0a',rim:'#ff8a2e',band:'#ffd23f',face:'skull',eye:'#ffd23f',eyeHi:'#ffffff',haze:'#ff5a1f',pole:'#2a1a12',blade:'#ff8a2e',edge:'#fff3b0',trail:['#ff5a1f','#ffd23f'],fx:'fire'}
};
const REAP_LIST=Object.keys(REAPERS);
/* ---------- active skills (S4 League style): they use SP, which refills when you are not using a skill ---------- */
const SKILLS={
  sk_none:{id:'sk_none',kind:'none',name:'NO SKILL',cost:0,desc:'NO SKILL EQUIPPED'},
  sk_shield:{id:'sk_shield',kind:'shield',name:'SHIELD',cost:200,use:15,drain:9,hit:0.6,
    desc:'ENERGY SHIELD IN FRONT BLOCKS BULLETS AND BEAMS'},
  sk_block:{id:'sk_block',kind:'block',name:'BLOCK',cost:300,use:35,hp:150,life:10,
    desc:'RAISES A WALL IN FRONT. IT CAN BE DESTROYED'},
  sk_flying:{id:'sk_flying',kind:'fly',name:'FLYING',cost:450,use:15,drain:13,rise:12,
    desc:'GROW WINGS. HOLD JUMP TO RISE, TAP SKILL TO LAND'}
};
const SKILL_LIST=['sk_none','sk_shield','sk_block','sk_flying'];
const BOT_SKILLS=['sk_none','sk_shield','sk_block','sk_shield'];   /* what the bots may carry */
const SAVE_KEY='pixelrush.save.v1';
function defSave(){
  return {name:'YOU',coins:100,totalCoins:100,kills:0,deaths:0,matches:0,wins:0,losses:0,goals:0,bestKills:0,
    owned:['pulse','blaster','rush','rp_shadow','sk_none'],eq:{melee:'pulse',gun:'blaster',char:'rush',reaper:'rp_shadow',skill:'sk_none'},hist:[]};
}
let SV=defSave();
try{
  const raw=localStorage.getItem(SAVE_KEY);
  if(raw){
    const o=JSON.parse(raw); SV=Object.assign(defSave(),o);
    SV.eq=Object.assign(defSave().eq,o.eq||{});
    if(!Array.isArray(SV.owned)) SV.owned=defSave().owned;
    if(!Array.isArray(SV.hist)) SV.hist=[];
  }
}catch(e){}
if(SV.owned.indexOf('rp_shadow')<0) SV.owned.push('rp_shadow');
if(!REAPERS[SV.eq.reaper]) SV.eq.reaper='rp_shadow';
if(SV.owned.indexOf('sk_none')<0) SV.owned.push('sk_none');
if(!SKILLS[SV.eq.skill]) SV.eq.skill='sk_none';
function persist(){ try{ localStorage.setItem(SAVE_KEY,JSON.stringify(SV)); }catch(e){} }
function applyOne(f,eq){
  const c=CHARS[eq.char]||CHARS.rush,m=WEAP[eq.melee],g=WEAP[eq.gun];
  f.wd=[(m&&m.slot===0)?m:WEAP.pulse,(g&&g.slot===1)?g:WEAP.blaster];
  f.sk=SKILLS[eq.skill]?eq.skill:'sk_none';
  f.maxhp=c.hp; f.spd=c.spd; f.jmp=c.jump; f.dcdm=c.dcd; f.style=c.style; f.dmgMul=c.dm||1; f.regen=c.regen||0; f.kbRes=c.kbr||1;
  if(mode!=='td') f.pal={main:c.main,dark:c.dark,hair:c.hair};
  else f.pal={main:f.pal.main,dark:f.pal.dark,hair:c.hair};
}
function applyLoadouts(){
  applyOne(fighters[0],{char:SV.eq.char,melee:SV.eq.melee,gun:SV.eq.gun,skill:(SV.owned.indexOf(SV.eq.skill)>=0?SV.eq.skill:'sk_none')});
  const pool=WEAP_LIST.filter(function(id){return WEAP[id].cost<=(diff===2?999:250);});
  const ms=pool.filter(function(id){return WEAP[id].slot===0;}),gs=pool.filter(function(id){return WEAP[id].slot===1;});
  const styles=['spike','helm','horn','mask','hood'];
  for(let i=1;i<fighters.length;i++){
    const b=fighters[i];
    if(b.remote!=null){ const n=b.minfo||{}; applyOne(b,{char:n.c,melee:n.m,gun:n.g,skill:n.s}); continue; }
    b.wd=[WEAP[ms[Math.floor(Math.random()*ms.length)]],WEAP[gs[Math.floor(Math.random()*gs.length)]]];
    b.style=styles[(i-1)%styles.length];
    b.sk=BOT_SKILLS[Math.floor(Math.random()*BOT_SKILLS.length)];
  }
  skillBtnSync();
}

/* ================= input ================= */
const keys={left:false,right:false,down:false,jump:false,dash:false,attack:false,mouse:false,skill:false};
const edge={jump:false,dash:false,attack:false,switch:false,skill:false};
const AIMS={on:false,x:1,y:0,m:0};
let mouseOn=false,fullTried=false;
let aimX=1,aimY=0,aimOn=false;
const keyMap={ArrowLeft:'left',a:'left',ArrowRight:'right',d:'right',ArrowDown:'down',s:'down',ArrowUp:'jump',w:'jump',' ':'jump',Shift:'dash',l:'dash',j:'attack',z:'attack',k:'switch',q:'switch',x:'switch',e:'skill'};
function press(a){ if(a==='jump')edge.jump=true; else if(a==='dash')edge.dash=true; else if(a==='attack')edge.attack=true; else if(a==='switch')edge.switch=true; else if(a==='skill')edge.skill=true; }
window.addEventListener('keydown',function(e){
  const k=e.key.length===1?e.key.toLowerCase():e.key;
  const a=keyMap[k];
  if(a){ e.preventDefault(); if(!keys[a]) press(a); keys[a]=true; }
  if(k==='Tab'){ e.preventDefault(); showSB=true; }
  if(e.repeat) return;
  if(k==='m'&&state!=='name') muted=!muted;
  if(k==='f'&&state!=='name') toggleFull();
  if(state==='menu'){
    if(k==='1') openMaps('dm'); else if(k==='2') openMaps('td'); else if(k==='3') openMaps('ch'); else if(k==='4') diff=(diff+1)%3;
    else if(k==='5') openShop(); else if(k==='6') openStats(); else if(k==='7') openName(); else if(k==='8') openMP(); else if(k==='Enter') startGame(mode);
  } else if(state==='shop'){ shopKey(k); }
  else if(state==='name'){ nameKey(k); }
  else if(state==='maps'){ mapsKey(k); }
  else if(state==='stats'){ statsKey(k); }
  else if(state==='mp'){ mpKey(k); }
  else if(state==='over'){
    if(overT>0.8&&(k==='Enter'||k===' ')){ if(NET.on) mpBackToLobby(); else state='menu'; }
  } else if(state==='play'){
    if(k==='p'||k==='Escape') paused=!paused;
    else if(paused&&k==='Enter'){ paused=false; if(NET.on) mpLeave(); else state='menu'; }
  }
});
window.addEventListener('keyup',function(e){
  const k=e.key.length===1?e.key.toLowerCase():e.key;
  if(k==='Tab') showSB=false;
  const a=keyMap[k]; if(a) keys[a]=false;
});
window.addEventListener('blur',function(){ for(const k in keys) keys[k]=false; showSB=false; if(state==='play') paused=true; });
function setKey(a,v){ if(v&&!keys[a]) press(a); keys[a]=v; }
function buzz(){ try{ if(navigator.vibrate) navigator.vibrate(8); }catch(e){} }
function togglePause(){ if(state==='play') paused=!paused; }
(function(){
  try{
    const t=document.getElementById('touch'); if(!t||!t.appendChild) return;
    const b=document.createElement('button'); b.id='skillBtn'; b.className='skill'; b.setAttribute('data-k','skill'); b.textContent='SKILL'; b.style.display='none';
    const st=document.createElement('style');
    st.textContent='html.touch #touch .skill{right:calc(var(--mr) + var(--u)*3.7 + 20px);bottom:calc(var(--sb) + var(--u)*2.25);width:calc(var(--u)*.95);height:calc(var(--u)*.95);}'
      +'html.touch #touch .skill.act{background:rgba(56,182,255,.75);border-color:#fff;}'
      +'@media (orientation:portrait){html.touch #touch .skill{bottom:calc(var(--sb) + var(--u)*3.75);}}';
    document.head&&document.head.appendChild&&document.head.appendChild(st);
    t.appendChild(b);
  }catch(e){}
})();
let skLast=false;
function skillBtnSync(){
  try{ const b=document.getElementById('skillBtn'); if(!b||!b.style) return; b.style.display=(fighters[0]&&fighters[0].sk!=='sk_none')?'block':'none'; }catch(e){}
}
function skillBtnAct(on){
  if(on===skLast) return; skLast=on;
  try{ const b=document.getElementById('skillBtn'); if(b&&b.classList) b.classList.toggle('act',on); }catch(e){}
}
document.querySelectorAll('#touch [data-k]').forEach(function(b){
  const a=b.getAttribute('data-k'),ids=new Set();
  b.addEventListener('pointerdown',function(e){
    e.preventDefault(); try{ b.setPointerCapture(e.pointerId); }catch(_){}
    ids.add(e.pointerId); setKey(a,true); b.classList.add('on'); buzz();
  });
  const up=function(e){ ids.delete(e.pointerId); if(ids.size===0){ setKey(a,false); b.classList.remove('on'); } };
  b.addEventListener('pointerup',up); b.addEventListener('pointercancel',up); b.addEventListener('lostpointercapture',up);
  b.addEventListener('contextmenu',function(e){e.preventDefault();});
});
document.querySelectorAll('#touch [data-a]').forEach(function(b){
  const a=b.getAttribute('data-a');
  b.addEventListener('pointerdown',function(e){
    e.preventDefault(); buzz();
    if(a==='pause') togglePause(); else if(a==='score'){ showSB=true; b.classList.add('on'); }
  });
  const up=function(){ if(a==='score'){ showSB=false; b.classList.remove('on'); } };
  b.addEventListener('pointerup',up); b.addEventListener('pointercancel',up); b.addEventListener('pointerleave',up);
  b.addEventListener('contextmenu',function(e){e.preventDefault();});
});
/* slide-able move pad: drag your thumb left or right without lifting */
(function(){
  const pad=document.getElementById('pad'); let pid=null;
  function upd(e){
    const r=pad.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,dz=0.06;
    const l=x<0.5-dz,rt=x>0.5+dz,up=(e.clientY-r.top)<-r.height*0.35;
    setKey('left',l); setKey('right',rt); setKey('jump',up);
    pad.classList.toggle('l',l); pad.classList.toggle('r',rt);
  }
  function end(e){
    if(pid!==null&&e&&e.pointerId!==undefined&&e.pointerId!==pid) return;
    pid=null; setKey('left',false); setKey('right',false); setKey('jump',false); pad.classList.remove('l'); pad.classList.remove('r');
  }
  pad.addEventListener('pointerdown',function(e){ e.preventDefault(); try{ pad.setPointerCapture(e.pointerId); }catch(_){} pid=e.pointerId; buzz(); upd(e); });
  pad.addEventListener('pointermove',function(e){ if(e.pointerId===pid) upd(e); });
  pad.addEventListener('pointerup',end); pad.addEventListener('pointercancel',end); pad.addEventListener('lostpointercapture',end);
  pad.addEventListener('contextmenu',function(e){e.preventDefault();});
})();
/* aim stick: drag to aim 360 degrees, push past the outer ring to fire */
(function(){
  const st=document.getElementById('stick'),kn=document.getElementById('knob'); if(!st||!kn) return; let pid=null;
  function upd(e){
    const r=st.getBoundingClientRect(),rad=r.width/2,dx=e.clientX-(r.left+rad),dy=e.clientY-(r.top+r.height/2),d=Math.hypot(dx,dy);
    const m=Math.min(1,d/rad),k=Math.min(d,rad*0.62);
    if(d>0.001) kn.style.transform='translate('+(dx/d*k)+'px,'+(dy/d*k)+'px)';
    if(m<0.18||d<0.001){ AIMS.on=false; AIMS.m=m; }
    else { AIMS.on=true; AIMS.x=dx/d; AIMS.y=dy/d; AIMS.m=m; }
    st.classList.toggle('fire',AIMS.on&&m>0.55);
  }
  function end(e){
    if(pid!==null&&e&&e.pointerId!==undefined&&e.pointerId!==pid) return;
    pid=null; AIMS.on=false; AIMS.m=0; kn.style.transform='translate(0px,0px)'; st.classList.remove('fire');
  }
  st.addEventListener('pointerdown',function(e){ e.preventDefault(); try{ st.setPointerCapture(e.pointerId); }catch(_){} pid=e.pointerId; buzz(); upd(e); });
  st.addEventListener('pointermove',function(e){ if(e.pointerId===pid) upd(e); });
  st.addEventListener('pointerup',end); st.addEventListener('pointercancel',end); st.addEventListener('lostpointercapture',end);
  st.addEventListener('contextmenu',function(e){e.preventDefault();});
})();
/* fullscreen: first tap on a phone goes fullscreen + landscape, FULL button toggles */
function isFull(){ return !!(document.fullscreenElement||document.webkitFullscreenElement); }
function goFull(){
  try{
    const el=document.documentElement;
    if(isFull()) return;
    const rq=el.requestFullscreen||el.webkitRequestFullscreen;
    if(!rq) return;
    const p=rq.call(el,{navigationUI:'hide'});
    if(p&&p.then) p.then(function(){
      fullOk=true; lockLandscape(); refitSoon();
    }).catch(function(){ refitSoon(); });
    else { fullOk=true; refitSoon(); }
  }catch(e){}
}
let fullOk=false,fullOff=false;   /* fullOff: the player left fullscreen on purpose with the FULL button */
function lockLandscape(){ try{ if(screen.orientation&&screen.orientation.lock) screen.orientation.lock('landscape').catch(function(){}); }catch(e){} }
/* the screen size settles a moment AFTER fullscreen / rotation happens, so measure again a few times */
function refitSoon(){ [60,200,450,900,1600].forEach(function(t){ setTimeout(function(){ try{ fitCanvas(); }catch(e){} },t); }); }
function toggleFull(){
  if(isFull()){ fullOff=true; (document.exitFullscreen||document.webkitExitFullscreen).call(document); }
  else { fullOff=false; goFull(); }
}
(function(){
  const canFull=document.fullscreenEnabled||document.webkitFullscreenEnabled;
  const fsb=document.getElementById('fs');
  if(fsb&&canFull){
    fsb.hidden=false;
    fsb.addEventListener('click',toggleFull);
  }
  const coarse=document.documentElement.classList.contains('touch');
  if(canFull) window.addEventListener('pointerup',function(e){
    if(!fullOff&&!isFull()) goFull();     /* every tap puts the game back into fullscreen (the phone only allows it from a tap) */
  });
  if(canFull) window.addEventListener('touchend',function(){ if(!fullOff&&!isFull()) goFull(); },{passive:true});
})();
if(document.addEventListener) document.addEventListener('visibilitychange',function(){
  if(document.hidden){ for(const k in keys) keys[k]=false; showSB=false; if(state==='play') paused=true; }
});
let hoverX=-1,hoverY=-1;
function toGame(e){ const r=cv.getBoundingClientRect(); return [(e.clientX-r.left)/r.width*W,(e.clientY-r.top)/r.height*H]; }
cv.addEventListener('pointermove',function(e){ const p=toGame(e); hoverX=p[0]; hoverY=p[1]; if(e.pointerType==='mouse') mouseOn=true; });
cv.addEventListener('pointerleave',function(){ hoverX=hoverY=-1; });
cv.addEventListener('pointerup',function(e){ if(e.pointerType!=='mouse') hoverX=hoverY=-1; });
cv.addEventListener('pointerdown',function(e){
  const p=toGame(e),gx=p[0],gy=p[1];
  const ux=(gx-UI.ox)/UI.s,uy=(gy-UI.oy)/UI.s;   /* position inside the 320x180 menu box */
  if(state==='menu'){
    for(const b of MENU){ if(ux>=b.x&&ux<=b.x+b.w&&uy>=b.y&&uy<=b.y+b.h){ b.act(); break; } }
  } else if(state==='shop'){ shopClick(ux,uy); }
  else if(state==='name'){ nameClick(ux,uy); }
  else if(state==='maps'){ mapsClick(ux,uy); }
  else if(state==='stats'){ statsClick(ux,uy); }
  else if(state==='mp'){ mpClick(ux,uy); }
  else if(state==='over'){ if(overT>0.8){ if(NET.on) mpBackToLobby(); else state='menu'; } }
  else if(state==='play'){
    if(paused){ if(gy>118){ paused=false; if(NET.on) mpLeave(); else state='menu'; } else paused=false; return; }
    if(e.pointerType==='mouse'){ keys.mouse=true; edge.attack=true; }
  }
});
window.addEventListener('pointerup',function(){ keys.mouse=false; });
cv.addEventListener('contextmenu',function(e){e.preventDefault();});

/* ================= particles & feed ================= */
function burst(x,y,color,n,sp){
  if(NET.host) rec(['b',Math.round(x),Math.round(y),color,n,sp]);
  for(let i=0;i<n;i++){
    const a=Math.random()*6.283,s=sp*(0.3+Math.random()*0.7);
    parts.push({x:x,y:y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-20,life:0.4+Math.random()*0.3,max:0.7,c:color,s:Math.random()<0.3?2:1,g:300});
  }
  const cap=lowQ?Math.min(160,PERF.maxParts):PERF.maxParts;
  if(parts.length>cap) parts.splice(0,parts.length-cap);
}
function dust(x,y){
  if(NET.host) rec(['d',Math.round(x),Math.round(y)]);
  for(let i=0;i<4;i++) parts.push({x:x+(Math.random()-0.5)*6,y:y-1,vx:(Math.random()-0.5)*40,vy:-Math.random()*25,life:0.3,max:0.3,c:'#cfc8ff',s:1,g:0});
}
function say(m,c){ if(NET.host) rec(['say',m,c||'#ffffff']); feed.push({t:4,m:m,c:c||'#ffffff'}); if(feed.length>4) feed.shift(); }

/* ================= fighters ================= */
function mk(id,name,team,pal,isBot){
  return {id:id,name:name,team:team,pal:pal,isBot:isBot,x:0,y:0,vx:0,vy:0,w:8,h:14,face:1,hp:100,maxhp:100,spd:1,jmp:1,dcdm:1,style:'cap',wd:[WEAP.pulse,WEAP.blaster],swingDur:0.16,noBar:false,recoil:0,flash:0,aimA:0,aimT:0,dmgMul:1,regen:0,kbRes:1,combo:0,comboT:0,swingStep:0,swingMul:1,swingRange:20,swingKb:150,swingCrit:false,swingHit2:false,quaked:false,lungeT:0,idleT:9,burnT:0,burnBy:null,shots:0,spin:0,rel:-1,role:'',scale:1,cel:0,locked:false,score:0,dmgAcc:0,tint:null,base:null,
    onGround:false,wallL:false,wallR:false,sliding:false,jumps:0,coyote:0,dashT:0,dashCd:0,weapon:1,atkCd:0,swing:0,
    swingHit:new Set(),hurt:0,inv:0,stun:0,dead:false,respawn:0,kills:0,deaths:0,ball:false,placed:false,anim:Math.random(),sk:'sk_none',sp:100,maxsp:100,spR:0,skOn:false,flying:false,blkCd:0,flyG:0,shFl:0,
    ai:isBot?{think:0,goal:null,foe:null,los:false,wp:null,jcd:0,swcd:0,dcd:0,unstick:0,rev:1,stT:0,lx:-99}:null};
}
function isEnemy(a,b){ return a!==b&&a.team!==b.team; }
function pickSpawn(f){
  if(mode==='td'){ const l=f.team==='blue'?BLUE_SP:RED_SP; return l[Math.floor(Math.random()*l.length)]; }
  const sc=DM_SP.map(function(p){
    let md=1e9;
    for(const o of fighters){ if(o===f||o.dead||!o.placed) continue; md=Math.min(md,Math.hypot(o.x-p[0],o.y-p[1])); }
    return [md+Math.random()*40,p];
  });
  sc.sort(function(a,b){return b[0]-a[0];});
  return sc[Math.floor(Math.random()*3)][1];
}
function camTarget(){
  let p=fighters[0]; if(!p) return [0,0];
  if(mode==='ch'&&chaser&&(p.dead||chPhase==='count')) p=chaser;   /* reveal: watch the chaser, then return to you */
  if(celeb&&celeb.scorer){                                       /* touchdown: close-up, centred directly on whoever scored */
    const sc=celeb.scorer;
    return [sc.x-VW/2,Math.min(sc.y-8-VH/2,WH-VH+14)];
  }
  const me=p===fighters[0]&&aimOn;
  const lx=me?aimX*26:p.face*12, ly=me?aimY*14:0;
  const cx=p.x+lx-VW/2,cy=p.y-8+ly-VH/2;
  return [VW>=WW?(WW-VW)/2:Math.max(0,Math.min(WW-VW,cx)),VH>=H?(H-VH)/2:Math.max(0,Math.min(WH-VH,cy))];
}
function snapCam(){ const t=camTarget(); camX=t[0]; camY=t[1]; }
function updateCam(dt){ const t=camTarget(); camX+=(t[0]-camX)*Math.min(1,dt*8); camY+=(t[1]-camY)*Math.min(1,dt*6); }
function respawn(f){
  const p=pickSpawn(f);
  f.x=p[0]; f.y=p[1]; f.vx=0; f.vy=0; f.hp=f.maxhp; f.dead=false; f.inv=1.5; f.stun=0; f.dashT=0; f.swing=0; f.atkCd=0;
  f.ball=false; f.placed=true; f.face=f.x<WW/2?1:-1; f.burnT=0; f.comboT=0; f.spin=0;
  f.sp=f.maxsp; f.skOn=false; f.flying=false; f.blkCd=0; f.spR=0; f.flyG=0;
  if(f===fighters[0]) snapCam();
  burst(f.x,f.y-7,f.pal.hair,10,70);
}
function startGame(m){
  BLK.length=0; mode=m; camZoom=(CAM.zoom[m]!==undefined?CAM.zoom[m]:1); fighters=[]; bullets=[]; parts=[]; feed=[]; corpses=[]; texts=[]; rings=[]; slashes=[]; beams=[]; banner=null; hitstop=0; flashT=0; streak=0; streakT=0;
  scores={blue:0,red:0}; winner=null; winTeam=null; time=0; shake=0; paused=false;
  { const L=mapIdxs(m); let mi=mapSel; if(mi<MAPS.length&&((MAPS[mi].only&&MAPS[mi].only!==m)||(m==='td'&&!MAPS[mi].only))) mi=MAPS.length;
    loadMap(mi>=MAPS.length?L[Math.floor(Math.random()*L.length)]:mi); }
  if(m==='dm'||m==='ch'){
    const P=[{main:'#38b6ff',dark:'#1b62a8',hair:'#b6f0ff'},{main:'#ff4d5e',dark:'#9d1f2f',hair:'#ffd166'},
             {main:'#43d98b',dark:'#1d8a55',hair:'#eaffb0'},{main:'#ff6ec7',dark:'#a3286f',hair:'#ffd1ec'}];
    const N=['YOU','BOLT','NOVA','RIOT','ZED','ECHO','DASH','FLUX','ONYX','VEGA','APEX','JINX'];
    const total=NET.humans?NET.humans.length:1+(m==='ch'?BOTS_CH:BOTS_DM);   /* online: only real players, no bots */
    for(let i=0;i<total;i++){
      const hu=(i*47)%360;
      const pal=P[i]||{main:'hsl('+hu+',75%,58%)',dark:'hsl('+hu+',60%,32%)',hair:'hsl('+hu+',90%,82%)'};
      fighters.push(mk(i,N[i]||('BOT'+i),'p'+i,pal,i>0));
    }
    ball=null;
  } else {
    const bl={main:'#38b6ff',dark:'#1b62a8'},rd={main:'#ff4d5e',dark:'#9d1f2f'};
    const bh=['#b6f0ff','#ffffff','#a0ffd8','#c8e8ff','#e0f4ff','#9ff3ff'],rh=['#ffd166','#ffb3c1','#ffe9e9','#ffc27a','#ffd9d9','#ffe08a'];
    const bn=['YOU','ACE','KAI','LEO','MAX','SKY','OLLIE','ZANE'],rn=['BOLT','NOVA','RIOT','JET','RAY','DUKE','FOX','CODY'];
    const per=1+BOTS_TD,nb=NET.humans?Math.ceil(NET.humans.length/2):per,nr=NET.humans?Math.floor(NET.humans.length/2):per;
    for(let i=0;i<nb;i++) fighters.push(mk(i,bn[i]||('ALLY'+i),'blue',{main:bl.main,dark:bl.dark,hair:bh[i%bh.length]},i>0));
    for(let i=0;i<nr;i++) fighters.push(mk(nb+i,rn[i]||('FOE'+i),'red',{main:rd.main,dark:rd.dark,hair:rh[i%rh.length]},true));
    ball={x:WW/2,y:MAPS[curIdx].ballY,vx:0,vy:0,w:6,h:6,bounce:0.45,carrier:null,cool:0.5};
  }
  fighters.forEach(function(f,i){ f.gid=i; });
  fighters[0].name=SV.name||'YOU';
  if(NET.humans) mpAssign();
  applyLoadouts();
  if(m==='ch') for(const f of fighters){ f.team='run'; f.base={maxhp:f.maxhp,spd:f.spd,dmgMul:f.dmgMul,kbRes:f.kbRes,wd:f.wd}; f.score=0; f.dmgAcc=0; }
  for(const f of fighters){ f.weapon=Math.random()<0.5?0:1; respawn(f); f.inv=1; }
  fighters[0].weapon=1;
  chaser=null; reaper=null; celeb=null; fireworks=[]; chTime=CH_TIME; celZoomK=0; updateView();
  if(m==='ch'){ chRound=0; startRound(); }
  earned=0; myGoals=0; lastResult=null; showSB=false;
  edge.jump=edge.dash=edge.attack=edge.switch=false;
  state='play'; sfx('start');
  cdT=START_COUNT[m]||0; goT=0; cdLast=Math.ceil(cdT)+1;
}

/* ================= combat ================= */
function addText(x,y,m,c){ texts.push({x:x,y:y,vy:-34,t:0.75,m:m,c:c||'#ffffff'}); if(texts.length>24) texts.shift(); }
function hurt(e,dmg,by,kx,ky,stun){
  if(e.dead||e.inv>0) return false;
  if(mode==='ch'&&e.role==='chaser'){
    /* the chaser can be killed: lots of HP, takes reduced damage, short stun so it can't be chain-locked */
    const ckr=e.kbRes||1;
    if(by&&by.dmgMul) dmg*=by.dmgMul;
    dmg*=CH_TAKE;
    e.hp-=dmg; e.hurt=0.1; e.lastBy=by||null;
    burst(e.x,e.y-8,'#ffffff',4,70); burst(e.x,e.y-8,'#ff4d5e',3,60); sfx('hit');
    if(stun){ e.stun=Math.min(stun,0.12); e.inv=0.12; e.vx=kx*ckr; e.vy=ky*ckr; e.dashT=0; }   /* melee / blasts: real shove */
    else { e.vx+=kx*ckr*1.5; e.lungeT=Math.max(e.lungeT,0.06); }                              /* bullets: small nudge */
    if(by===fighters[0]||e===fighters[0]) addText(e.x,e.y-26,String(Math.round(dmg)),e===fighters[0]?'#ff8a8a':'#ffd23f');
    if(NET.host){ if(by&&by!==e&&by.remote!=null) pnote(by,['dmg',e.x,e.y-26,Math.round(dmg),0]); if(e.remote!=null) pnote(e,['dmg',e.x,e.y-26,Math.round(dmg),1]); }
    if(e.hp<=0){ e.hp=0; die(e,by); }
    return true;
  }
  if(by&&by.dmgMul) dmg*=by.dmgMul;
  const kr=e.kbRes||1;
  e.hp-=dmg; e.hurt=0.12;
  if(stun){ e.stun=stun; e.vx=kx*kr; e.vy=ky*kr; e.dashT=0; } else e.vx+=kx*kr;
  burst(e.x,e.y-7,'#ffffff',4,70); burst(e.x,e.y-7,e.pal.main,4,60);
  if(by===fighters[0]||e===fighters[0]) addText(e.x,e.y-18,String(Math.round(dmg)),e===fighters[0]?'#ff8a8a':'#ffffff');
  if(NET.host){ if(by&&by!==e&&by.remote!=null) pnote(by,['dmg',e.x,e.y-18,Math.round(dmg),0]); if(e.remote!=null) pnote(e,['dmg',e.x,e.y-18,Math.round(dmg),1]); }
  sfx('hit');
  if(e.hp<=0) die(e,by);
  return true;
}
function makeCorpse(e,by){
  if(NET.host) rec(['cp',e.gid,by&&by.gid!==undefined?by.gid:-1]);
  const dir=by&&by!==e?(Math.sign(e.x-by.x)||-e.face):(Math.random()<0.5?-1:1);
  const cf=mk(97,e.name,'c',e.pal,false);
  cf.style=e.style; cf.scale=e.scale||1; cf.wd=e.wd; cf.weapon=e.weapon; cf.face=e.face; cf.noBar=true; cf.placed=true;
  corpses.push({f:cf,x:e.x,y:e.y,vx:dir*(120+Math.random()*90)+e.vx*0.3,vy:-200-Math.random()*70,w:8,h:14,bounce:0.35,
    rot:0,vr:dir*(6+Math.random()*4),t:0,life:1.7,hurtT:0.14});
}
function dissolve(c){
  const cols=[c.f.pal.main,c.f.pal.dark,c.f.pal.hair,'#f4cfa5','#ffffff'];
  for(let i=0;i<28;i++){
    const a=Math.random()*6.283,sp=30+Math.random()*100;
    parts.push({x:c.x+(Math.random()-0.5)*6,y:c.y-7+(Math.random()-0.5)*8,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-50,
      life:0.6+Math.random()*0.5,max:1.0,c:cols[i%cols.length],s:Math.random()<0.4?2:1,g:260});
  }
  rings.push({x:c.x,y:c.y-7,r:2,max:22,t:0,life:0.3,c:'#ffffff'});
}
function updateCorpses(dt){
  for(let i=corpses.length-1;i>=0;i--){
    const c=corpses[i]; c.t+=dt;
    c.vy=Math.min(330,c.vy+GRAV*dt);
    moveEntity(c,dt);
    if(boxHits(c.x-4,c.y-c.h+1,c.w,c.h)){ c.vx*=0.9; c.vr*=0.85; }
    c.rot+=c.vr*dt;
    if(Math.random()<0.5) parts.push({x:c.x,y:c.y-7,vx:(Math.random()-0.5)*20,vy:-10,life:0.25,max:0.25,c:c.f.pal.main,s:1,g:0});
    if(c.t>=c.life){ dissolve(c); corpses.splice(i,1); }
  }
}
function die(e,by,cause){
  if(e.dead) return;
  e.dead=true; e.respawn=e.respTotal=(RESPAWN_SECS[mode]!==undefined?RESPAWN_SECS[mode]:2.5); e.deaths++; e.hp=0; e.dashT=0; e.skOn=false; e.flying=false;
  const p=fighters[0];
  if(by&&by!==e){
    by.kills++;
    if(by===p) myKill(e.name,by.pal.main);
    else if(by.remote!=null) pnote(by,['kill',e.name,by.pal.main]);
  }
  if(e===p){ flashCol='#ff3b3b'; flashT=0.2; streak=0; streakT=0; }
  else if(e.remote!=null) pnote(e,['died']);
  if(e.ball&&ball){ e.ball=false; ball.carrier=null; ball.x=e.x; ball.y=e.y-2; ball.vx=(Math.random()-0.5)*90; ball.vy=-150; ball.cool=0.5; }
  makeCorpse(e,by);
  if(mode==='ch'&&by&&by.role==='chaser') by.score+=1;
  burst(e.x,e.y-7,e.pal.main,22,130); burst(e.x,e.y-7,'#ffffff',10,90);
  if(mode==='ch'&&reaper&&by&&by.role==='chaser'&&by!==e){   /* the reaper drinks the soul */
    const rc=reaper.sk.haze;
    for(let n=0;n<10;n++){ const dx=reaper.x-e.x,dy=reaper.y-(e.y-8); parts.push({x:e.x+(Math.random()-0.5)*6,y:e.y-8+(Math.random()-0.5)*8,vx:dx*1.6+(Math.random()-0.5)*50,vy:dy*1.6-30-Math.random()*40,life:0.7,max:0.7,c:n&1?rc:'#ffffff',s:n%3?1:2,g:0}); }
    rings.push({x:reaper.x,y:reaper.y,r:2,max:20,t:0,life:0.3,c:rc});
  }
  rings.push({x:e.x,y:e.y-7,r:3,max:30,t:0,life:0.4,c:e.pal.main});
  shake=Math.max(shake,e.isBot?2.5:5);
  hitstop=Math.max(hitstop,(e===p||by===p)?0.08:0.035);
  if(by&&by!==e) say(by.name+' > '+e.name,by.pal.main); else say(e.name+(cause||' FELL'),'#ffffff');
  if(mode==='ch'&&e.role==='chaser'){   /* the chaser falls: big finish, the round is won by the runners */
    e.respawn=e.respTotal=1e9; e.lastBy=by||e.lastBy||null;
    burst(e.x,e.y-8,'#ff4d5e',40,170); burst(e.x,e.y-8,'#ffd23f',22,130); burst(e.x,e.y-8,'#ffffff',16,110);
    rings.push({x:e.x,y:e.y-8,r:3,max:48,t:0,life:0.6,c:'#ff4d5e'}); rings.push({x:e.x,y:e.y-8,r:2,max:30,t:0,life:0.45,c:'#ffd23f'}); rings.push({x:e.x,y:e.y-8,r:1,max:18,t:0,life:0.3,c:'#ffffff'});
    if(reaper){ burst(reaper.x,reaper.y,reaper.sk.haze,24,120); rings.push({x:reaper.x,y:reaper.y,r:3,max:34,t:0,life:0.5,c:reaper.sk.haze}); }
    shake=Math.max(shake,9); hitstop=Math.max(hitstop,0.15); flashCol='#ffffff'; flashT=0.18;
    say('CHASER DOWN!','#4ade80');
  }
  sfx('die');
}
function idleInp(){
  edge.jump=edge.dash=edge.attack=edge.switch=false;
  return {move:0,jump:false,jumpHeld:false,dash:false,attack:false,switch:false,down:false,face:0,aim:null};
}
function startRound(){
  BLK.length=0;
  chRound++; chPhase='count'; chPT=CH_COUNT; chLastN=0; chTime=CH_TIME; chWinT=-1;
  bullets=[]; corpses=[]; beams=[]; slashes=[]; rings=[]; texts=[]; hitstop=0; streak=0;
  for(const f of fighters){
    if(f.role==='chaser') unmakeChaser(f);
    f.role='runner'; f.team='run'; f.placed=false; f.dead=false; f.burnT=0; f.locked=false;
    f.weapon=(f===fighters[0])?1:(Math.random()<0.5?0:1);
  }
  const c=fighters[(chRound-1)%fighters.length];
  makeChaser(c); respawn(c);
  for(const f of fighters) if(f!==c) respawn(f);
  snapCam();   /* start the round already looking at the chaser */
}
function endRound(cw,ck){
  chPhase='end'; chPT=3.5;
  const p=fighters[0], surv=fighters.filter(function(f){return f.role==='runner'&&!f.dead;});
  const killer=ck&&chaser&&chaser.lastBy&&chaser.lastBy!==chaser?chaser.lastBy:null;
  if(cw){ chaser.score+=2; if(chaser===p) earned+=20; }
  else for(const s of surv){ s.score+=3; if(s===p) earned+=15; }
  if(killer){ killer.score+=4; if(killer===p) earned+=25; }
  chWinT=cw?0:-1;
  banner=cw?null:(ck?{t:3.2,a:'CHASER DOWN!',b:killer?killer.name+' TOOK IT OUT  +4':'THE TARGETS WIN',c:'#4ade80'}:{t:3,a:'TARGETS SURVIVE!',b:'TIME UP',c:'#4ade80'});
  flashCol=cw?'#ff4d5e':'#4ade80'; flashT=0.2; sfx(cw?'boom':'score');
}
function chTick(dt){
  if(chPhase==='count'){
    chPT-=dt; const n=Math.ceil(chPT);
    if(n!==chLastN&&n>0){ chLastN=n; sfx('pick'); }
    if(chPT<=0){ chPhase='run'; banner={t:1.2,a:'GO!',b:'',c:'#ffffff'}; sfx('start'); }
  } else if(chPhase==='run'){
    chTime-=dt;
    const alive=fighters.filter(function(f){return f.role==='runner'&&!f.dead;}).length;
    if(chaser&&chaser.dead&&alive>=0) endRound(false,true); else if(alive===0) endRound(true); else if(chTime<=0) endRound(false);
  } else {
    chPT-=dt; if(chWinT>=0) chWinT+=dt;
    if(chPT<=0){
      if(chRound>=CH_ROUNDS){
        winner=fighters.slice().sort(function(a,b){return (b.score-a.score)||(b.kills-a.kills);})[0];
        endGame();
      } else startRound();
    }
  }
}
function makeChaser(f){
  chaser=f; f.role='chaser'; f.team='chase'; f.scale=1.25;
  f.maxhp=CH_HP; f.hp=CH_HP; f.spd=f.base.spd*1.15; f.dmgMul=1.3; f.kbRes=0.5;
  f.wd=[WEAP.claw,WEAP.claw]; f.weapon=0; f.locked=true;
  burst(f.x,f.y-8,'#ff4d5e',30,150); burst(f.x,f.y-8,'#ffffff',10,100);
  rings.push({x:f.x,y:f.y-8,r:3,max:34,t:0,life:0.5,c:'#ff4d5e'}); rings.push({x:f.x,y:f.y-8,r:2,max:20,t:0,life:0.35,c:'#ffffff'});
  shake=Math.max(shake,5); flashCol='#ff4d5e'; flashT=0.15; sfx('boom');
  banner={t:2.4,a:f.name+' IS THE CHASER!',b:f===fighters[0]?'HUNT THEM DOWN!':'SURVIVE!',c:'#ff4d5e'};
  say(f.name+' BECAME THE CHASER','#ff4d5e');
  reaper={hist:[],x:f.x-f.face*17,y:f.y-28,t:0,atk:0,sk:f===fighters[0]?(REAPERS[SV.eq.reaper]||REAPERS.rp_shadow):REAPERS[REAP_LIST[Math.floor(Math.random()*REAP_LIST.length)]]};
  { const rs=reaper.sk; burst(reaper.x,reaper.y,rs.haze,20,110); rings.push({x:reaper.x,y:reaper.y,r:3,max:30,t:0,life:0.5,c:rs.haze}); rings.push({x:reaper.x,y:reaper.y,r:2,max:18,t:0,life:0.35,c:'#ffffff'}); }
  for(let i=0;i<18;i++) parts.push({x:reaper.x+(Math.random()-0.5)*14,y:reaper.y+Math.random()*14,vx:(Math.random()-0.5)*50,vy:-20-Math.random()*40,life:0.9,max:0.9,c:i%2?'#5a2a8a':'#ff4d5e',s:2,g:-20});
}
function unmakeChaser(f){
  const b=f.base; f.role='runner'; f.team='run'; f.scale=1;
  f.maxhp=b.maxhp; f.spd=b.spd; f.dmgMul=b.dmgMul; f.kbRes=b.kbRes; f.wd=b.wd; f.weapon=1; f.locked=false; if(reaper) reaper=null;
}
function boom(b){ if(b.boomed) return; b.boomed=true; explode(b); }
function explode(b){
  const R=b.rad||30;
  rings.push({x:b.x,y:b.y,r:3,max:R,t:0,life:0.35,c:'#ffb84d'}); rings.push({x:b.x,y:b.y,r:2,max:R*0.6,t:0,life:0.25,c:'#ffffff'});
  burst(b.x,b.y,'#ffb84d',22,150); burst(b.x,b.y,'#ff5a1f',16,110); burst(b.x,b.y,'#fff3b0',8,80);
  for(let i=0;i<8;i++) parts.push({x:b.x,y:b.y,vx:(Math.random()-0.5)*50,vy:-20-Math.random()*40,life:0.9,max:0.9,c:'#5a5a66',s:2,g:-30});
  const near=Math.hypot(b.x-fighters[0].x,b.y-fighters[0].y); shake=Math.max(shake,near<90?5:2);
  sfx('boom');
  if(BLK.length) for(const k of BLK.slice()){ const d=Math.hypot(k.x-b.x,(k.y-k.h/2)-b.y),rr=R+k.h/2; if(d<rr&&k.owner&&isEnemy(b.owner,k.owner)) damageBlock(k,b.dmg*(0.9-0.5*d/rr),b.owner); }
  for(const f of fighters){
    if(f.dead) continue;
    const dx=f.x-b.x,dy=(f.y-7)-b.y,d=Math.hypot(dx,dy);
    if(d>=R) continue;
    const k=1-d/R,nx=dx/(d||1),ny=dy/(d||1);
    if(f===b.owner){ f.vx+=nx*260*k; f.vy=Math.min(f.vy,-140*k-40); f.jumps=1; }
    else if(isEnemy(b.owner,f)) hurt(f,b.dmg*(0.45+0.55*k),b.owner,nx*240*k,-150*k-50,0.25);
  }
  if(b.frag) for(let i=0;i<7;i++){          /* cluster bomb: bomblets fly out of the blast */
    const a=-Math.PI*(0.1+0.8*Math.random()),sp=90+Math.random()*90;
    bullets.push({x:b.x,y:b.y-3,vx:Math.cos(a)*sp*(Math.random()<0.5?-1:1),vy:Math.sin(a)*sp,owner:b.owner,life:0.32,maxLife:0.32,dmg:8,pierce:false,hit:new Set(),c:'#ffb84d',bn:0,boom:false,trail:true,fall:true,grav:false});
  }
}
function slashImpact(e,f,wd){
  const x=e.x-f.face*3,y=e.y-8;
  burst(x,y,wd.color,7,110); burst(x,y,'#ffffff',3,80);
  rings.push({x:x,y:y,r:1,max:f.swingStep===2?16:10,t:0,life:0.18,c:'#ffffff'});
  for(let i=0;i<4;i++) parts.push({x:x,y:y,vx:f.face*(60+Math.random()*90),vy:(Math.random()-0.5)*80,life:0.2,max:0.2,c:wd.color,s:2,g:0});
}
function chainLightning(e,f,wd,dm){
  let best=null,bd=60;
  for(const o of fighters){
    if(o===e||o.dead||!isEnemy(f,o)) continue;
    const d=Math.hypot(o.x-e.x,o.y-e.y); if(d<bd){ bd=d; best=o; }
  }
  if(best){
    beams.push({x1:e.x,y1:e.y-7,x2:best.x,y2:best.y-7,t:0,life:0.22,c:wd.color,th:2,zig:true});
    hurt(best,dm*0.5,f,0,-40,0.12);
  } else burst(e.x,e.y-8,wd.color,6,90);
}
function quake(f,wd){
  const ox=f.x+f.face*(f.swingRange-4),oy=f.y;
  rings.push({x:ox,y:oy-2,r:2,max:30,t:0,life:0.3,c:'#ffd23f'});
  for(let i=0;i<10;i++) parts.push({x:ox+(Math.random()-0.5)*20,y:oy-1,vx:(Math.random()-0.5)*90,vy:-30-Math.random()*60,life:0.4,max:0.4,c:'#cfc8ff',s:2,g:200});
  shake=Math.max(shake,4);
  for(const e of fighters){
    if(e.dead||!isEnemy(f,e)||f.swingHit.has(e)) continue;
    if(Math.abs(e.x-ox)<30&&Math.abs(e.y-oy)<14) hurt(e,wd.dmg*0.4*f.swingMul,f,(Math.sign(e.x-f.x)||f.face)*120,-190,0.3);
  }
}
function hitscan(f,wd,ang){
  const dx=Math.cos(ang),dy=Math.sin(ang),ox=f.x+dx*8,oy=f.y-8+dy*8;
  let ex=ox,ey=oy; const seen=new Set();
  for(let d=0;d<wd.range;d+=3){
    ex=ox+dx*d; ey=oy+dy*d;
    if(solidAt(ex,ey)){ blockDamageAt(ex,ey,wd.dmg,f); burst(ex,ey,wd.bc,5,70); break; }
    { const shf=shieldAtPoint(f,ex,ey,dx); if(shf){ burst(ex,ey,'#7dffea',6,80); shieldHurt(shf,Math.max(3,wd.dmg*SKILLS.sk_shield.hit)); break; } }
    for(const e of fighters){
      if(e.dead||!isEnemy(f,e)||seen.has(e)) continue;
      if(Math.abs(ex-e.x)<=5&&ey>e.y-14&&ey<e.y){
        seen.add(e);
        if(e.inv<=0) hurt(e,wd.dmg,f,Math.sign(dx)*40,0,0);
        burst(ex,ey,wd.bc,5,70);
        if(!wd.pierce) d=1e9;
        break;
      }
    }
  }
  beams.push({x1:ox,y1:oy,x2:ex,y2:ey,t:0,life:wd.pierce?0.25:0.13,c:wd.bc,th:wd.th||(wd.pierce?3:2),zig:!!wd.zig});
  rings.push({x:ex,y:ey,r:1,max:wd.pierce?12:7,t:0,life:0.2,c:wd.bc});
}
function fire(f,inp){
  const wd=f.wd[f.weapon];
  if(f.weapon===0){
    f.combo=f.comboT>0?(f.combo+1)%3:0;
    const st=f.combo; f.swingStep=st;
    f.swingMul=st===2?1.4:1; f.swingRange=Math.round(wd.range*(st===2?1.2:1)); f.swingKb=wd.kb*(st===2?1.5:1);
    f.swingCrit=!!wd.crit&&f.idleT>1.0;
    const dur=wd.dur*(st===2?1.25:1);
    f.atkCd=wd.cd*(st===2?1.35:1); f.swing=dur; f.swingDur=dur; f.swingHit=new Set(); f.swingHit2=false; f.quaked=false;
    f.comboT=f.atkCd+0.4; f.idleT=0;
    const lg=(wd.lunge||100)*(st===2?1.4:1);
    if(f.onGround){ f.lungeT=0.1; f.vx=f.face*lg; } else { f.lungeT=0.08; f.vx=f.face*lg*0.6; f.vy=Math.min(f.vy,-40); }
    slashes.push({f:f,x:f.x+f.face*2,y:f.y-9,face:f.face,step:st,t:0,life:wd.thrust?0.14:0.2,r:Math.round(f.swingRange*0.85),color:wd.color,big:!!wd.big||st===2,thrust:!!wd.thrust,claw:!!wd.claw});
    if(wd.wave==='all'||(wd.wave==='finisher'&&st===2)){
      bullets.push({x:f.x+f.face*10,y:f.y-9,vx:f.face*240,vy:0,owner:f,life:0.45,dmg:wd.dmg*(st===2?0.8:0.5),pierce:true,hit:new Set(),c:wd.color,bn:0,boom:false,trail:false,wave:true});
    }
    dust(f.x,f.y);
    psfx(f,meleeSnd(wd,st));
  } else {
    f.shots++;
    const pw=!!wd.power&&f.shots%wd.power.n===0;
    let cd=wd.cd;
    if(wd.spin){ cd=wd.spin.from+(wd.spin.to-wd.spin.from)*f.spin; f.spin=Math.min(1,f.spin+0.13); }
    f.atkCd=cd;
    let ax=f.face,ay=0;
    if(inp.aim){ ax=inp.aim.x; ay=inp.aim.y; }
    else if(inp.down&&!f.onGround){ ax=f.face*0.7; ay=0.7; }
    const ang=Math.atan2(ay,ax);
    if(wd.hitscan) hitscan(f,wd,ang);
    else for(let i=0;i<wd.pellets;i++){
      const a=ang+(wd.pellets>1?(i-(wd.pellets-1)/2)*wd.spread:0)+(Math.random()-0.5)*2*wd.jit;
      const cx=Math.cos(a),cy=Math.sin(a);
      const lo=wd.line?-i*7:0;
      bullets.push({x:f.x+cx*(7+lo),y:f.y-8+cy*(7+lo),vx:cx*wd.speed,vy:cy*wd.speed,owner:f,life:wd.life,maxLife:wd.life,dmg:wd.dmg*(pw?wd.power.mul:1),
        pierce:wd.pierce,hit:new Set(),c:wd.bc,bn:wd.bounce||0,boom:!!wd.boom,rad:wd.radius,trail:!wd.pierce&&!wd.flame,
        big:pw,fall:!!wd.fall,burn:!!wd.burn,flame:!!wd.flame,grav:!!wd.grav,blen:wd.blen||0,frag:!!wd.frag});
    }
    f.recoil=1; f.flash=pw?0.1:0.06; f.aimA=Math.atan2(ay,Math.abs(ax)); f.aimT=0.28;
    const mo=Math.round((7+wd.len)*gunScale(wd))+3,mx=f.x+Math.cos(ang)*mo,my=f.y-8+Math.sin(ang)*mo;
    if(!wd.flame) burst(mx,my,'#fff59d',2,40);
    if(wd.shell) parts.push({x:f.x+f.face,y:f.y-9,vx:-f.face*(20+Math.random()*30),vy:-60-Math.random()*40,life:0.5,max:0.5,c:'#ffd166',s:1,g:400});
    if(wd.kick>=2||wd.boom) for(let i=0;i<3;i++) parts.push({x:mx,y:my,vx:Math.cos(ang)*30+(Math.random()-0.5)*20,vy:-10-Math.random()*20,life:0.5,max:0.5,c:'#8a8a99',s:2,g:-20});
    f.vx-=Math.cos(ang)*(wd.kick?wd.kick*8:(wd.flame?0.3:2));
    if(wd.kick&&!f.isBot) shake=Math.max(shake,wd.kick*0.6);
    if(!(wd.flame&&f.shots%4)) psfx(f,gunSnd(wd,pw));
  }
}
function swordHit(f){
  const wd=f.wd[0],rg=f.swingRange;
  const hx=f.face>0?f.x+2:f.x-2-rg,hy=f.y-20,hw=rg,hh=24;
  if(wd.multi&&!f.swingHit2&&f.swing<f.swingDur*0.5){ f.swingHit=new Set(); f.swingHit2=true; slashes.push({f:f,x:f.x+f.face*2,y:f.y-9,face:f.face,step:1,t:0,life:0.16,r:Math.round(rg*0.85),color:wd.color,big:false,thrust:false}); }
  if(wd.quake&&!f.quaked&&f.swing<f.swingDur*0.55&&(wd.quake==='all'||f.swingStep===2)){ f.quaked=true; quake(f,wd); }
  for(const e of fighters){
    if(e.dead||!isEnemy(f,e)||f.swingHit.has(e)) continue;
    if(e.x-4<hx+hw&&e.x+4>hx&&e.y-14<hy+hh&&e.y>hy){
      f.swingHit.add(e);
      const crit=f.swingCrit,dm=wd.dmg*f.swingMul*(crit?1.6:1);
      if(hurt(e,dm,f,f.face*f.swingKb,-100,wd.stun||0.2)){
        shake=Math.max(shake,(wd.big||f.swingStep===2)?4:2);
        slashImpact(e,f,wd);
        if(wd.claw) psfx(f,'scythehit');
        if(crit) addText(e.x,e.y-26,'CRIT!','#ffd23f');
        if(wd.steal){ const hv=wd.steal*(f.swingStep===2?2:1); f.hp=Math.min(f.maxhp,f.hp+hv); burst(f.x,f.y-8,'#7dffa0',6,50); addText(f.x,f.y-18,'+'+hv,'#7dffa0'); }
        if(wd.chain) chainLightning(e,f,wd,dm);
        if(wd.burn){ e.burnT=1.6; e.burnBy=f; }
        if(!f.isBot) hitstop=Math.max(hitstop,f.swingStep===2?0.07:0.04);
      }
    }
  }
  if(BLK.length) for(const k of BLK.slice()){
    if(f.swingHit.has(k)||!isEnemy(f,k.owner)) continue;
    if(hx<k.x+k.w/2&&hx+hw>k.x-k.w/2&&hy<k.y&&hy+hh>k.y-k.h){ f.swingHit.add(k); damageBlock(k,wd.dmg*f.swingMul*(f.swingCrit?1.6:1),f); shake=Math.max(shake,2); }
  }
  for(const b of bullets){
    if(b.owner===f||!isEnemy(f,b.owner)) continue;
    if(b.x>hx&&b.x<hx+hw&&b.y>hy&&b.y<hy+hh){ b.owner=f; b.vx=-b.vx; b.vy=-b.vy; b.life=b.maxLife||0.9; burst(b.x,b.y,'#9ff3ff',4,60); }
  }
}
function updateBullets(dt){
  for(let i=bullets.length-1;i>=0;i--){
    const b=bullets[i];
    b.life-=dt;
    let dead=b.life<=0;
    if(dead&&b.boom) boom(b);
    if(!dead){
      if(b.bn>0){
        if(b.grav) b.vy+=GRAV*0.75*dt;
        const nx=b.x+b.vx*dt;
        if(solidAt(nx,b.y)){ blockDamageAt(nx,b.y,b.dmg,b.owner); b.vx=-b.vx*(b.grav?0.55:1); b.bn--; if(!b.grav) burst(b.x,b.y,b.c||'#ffffff',3,50); } else b.x=nx;
        const ny=b.y+b.vy*dt;
        if(solidAt(b.x,ny)){
          blockDamageAt(b.x,ny,b.dmg,b.owner);
          b.vy=-b.vy*(b.grav?0.45:1);
          if(b.grav){ b.vx*=0.85; if(Math.abs(b.vy)<30) b.vy=0; }
          b.bn--; if(!b.grav) burst(b.x,b.y,b.c||'#ffffff',3,50);
        } else b.y=ny;
      } else {
        b.x+=b.vx*dt; b.y+=b.vy*dt;
        if(solidAt(b.x,b.y)){ dead=true; blockDamageAt(b.x,b.y,b.dmg,b.owner); if(b.boom) boom(b); else burst(b.x,b.y,'#ffe08a',3,50); }
      }
    }
    if(!dead&&b.trail){
      if(b.boom) parts.push({x:b.x-Math.sign(b.vx)*4,y:b.y,vx:(Math.random()-0.5)*15,vy:(Math.random()-0.5)*15,life:0.35,max:0.35,c:Math.random()<0.5?'#ffb84d':'#7a7a86',s:2,g:0});
      else parts.push({x:b.x,y:b.y,vx:0,vy:0,life:0.14,max:0.14,c:b.c||b.owner.pal.hair,s:1,g:0});
    }
    if(!dead&&b.flame&&Math.random()<0.6) parts.push({x:b.x,y:b.y,vx:(Math.random()-0.5)*14,vy:-15,life:0.25,max:0.25,c:Math.random()<0.5?'#ff8a2e':'#ffd23f',s:2,g:-40});
    if(!dead){
      const px=b.x-b.vx*dt,py=b.y-b.vy*dt;
      for(const sh of fighters){
        if(!sh.skOn||sh.dead||sh.sk!=='sk_shield'||!isEnemy(b.owner,sh)) continue;
        if(shieldCross(sh,px,py,b.x,b.y)){
          const sx=sh.x+sh.face*9;
          burst(sx,b.y,'#7dffea',5,70); rings.push({x:sx,y:b.y,r:1,max:8,t:0,life:0.15,c:'#7dffea'});
          shieldHurt(sh,Math.max(2,(b.dmg||8)*SKILLS.sk_shield.hit));
          if(b.boom){ b.x=sx; boom(b); }
          dead=true; break;
        }
      }
    }
    if(!dead) for(const f of fighters){
      if(f.dead||!isEnemy(b.owner,f)) continue;
      if(b.hit&&b.hit.has(f)) continue;
      if(Math.abs(b.x-f.x)<=5&&b.y>f.y-14&&b.y<f.y){
        if(f.inv>0){ if(!b.pierce) dead=true; break; }
        if(b.boom){ dead=true; boom(b); break; }
        const dm=b.fall?b.dmg*(0.5+0.5*Math.max(0,b.life)/(b.maxLife||1)):b.dmg;
        if(hurt(f,dm,b.owner,Math.sign(b.vx)*(b.flame?8:35),0,0)&&b.burn){ f.burnT=2; f.burnBy=b.owner; }
        if(b.pierce){ b.hit.add(f); if(!b.flame&&!b.wave) burst(b.x,b.y,b.c||'#ffffff',4,60); } else { dead=true; break; }
      }
    }
    if(dead) bullets.splice(i,1);
  }
}

/* ================= touchdown ball ================= */
function resetBall(){ ball.x=WW/2; ball.y=MAPS[curIdx].ballY; ball.vx=0; ball.vy=0; ball.carrier=null; ball.cool=0.6; ball.hidden=false; }
function grab(f){ ball.carrier=f; f.ball=true; sfx('pick'); say(f.name+' GOT THE BALL',f.pal.main); }
function confetti(n){
  const cols=[celeb?celeb.col:'#ffffff','#ffd23f','#ffffff','#ff6ec7','#7dffea','#a3e635'];
  for(let i=0;i<n;i++){
    if(parts.length>PERF.maxParts+120) return;
    parts.push({x:camX+Math.random()*VW,y:camY-4-Math.random()*20,vx:(Math.random()-0.5)*30,vy:20+Math.random()*30,life:2.6,max:2.6,c:cols[Math.floor(Math.random()*cols.length)],s:Math.random()<0.5?2:1,g:25});
  }
}
function launchFirework(){
  const cols=[celeb.col,'#ffd23f','#ffffff','#ff6ec7','#7dffea'];
  fireworks.push({x:camX+20+Math.random()*(VW-40),y:camY+VH-6,vy:-(170+Math.random()*60),c:cols[Math.floor(Math.random()*cols.length)],peak:camY+8+Math.random()*50});
}
function fanfare(){ sfx('score'); setTimeout(function(){sfx('pick');},160); setTimeout(function(){sfx('score');},320); setTimeout(function(){sfx('start');},520); }
function scoreGoal(team,c){
  scores[team]++;
  const p0=fighters[0]; if(c===p0){ earned+=30; myGoals++; } else if(c.team===p0.team) earned+=10;
  if(NET.host) for(const h of fighters){ if(h.remote==null) continue; if(c===h) pnote(h,['earn',30,1]); else if(c.team===h.team) pnote(h,['earn',10,0]); }
  const col=team==='blue'?'#38b6ff':'#ff4d5e';
  say((team==='blue'?'BLUE':'RED')+' SCORES!',col);
  c.ball=false; ball.carrier=null; ball.hidden=true; ball.x=c.x; ball.y=c.y-14; ball.vx=0; ball.vy=0;
  const win=scores[team]>=GOALS_TO_WIN; if(win) winTeam=team;
  celeb={t:0,dur:win?3.4:2.6,team:team,name:c.name,col:col,win:win,fw:0,scorer:c,c0x:camX+VW/2,c0y:camY+VH/2,pan:0.7+Math.min(0.5,Math.hypot(c.x-(camX+VW/2),c.y-(camY+VH/2))/2400)};
  bullets=[]; hitstop=0; flashCol=col; flashT=0.3; shake=Math.max(shake,7);
  const z=team==='blue'?ZR:ZL;
  burst(c.x,c.y-8,'#ffd23f',30,150); burst(c.x,c.y-8,'#ffffff',12,100);
  rings.push({x:c.x,y:c.y-8,r:3,max:40,t:0,life:0.5,c:col}); rings.push({x:z[0]+8,y:z[1]+z[3]-6,r:3,max:34,t:0,life:0.6,c:'#ffd23f'});
  confetti(90); fanfare();
}
/* touchdown close-up: one timed, eased move (pan + zoom) onto the scorer, then locked exactly on them;
   until everyone respawns (no zoom-out) */
function ease5(t){ return t*t*t*(t*(t*6-15)+10); }
function celebCam(){
  const c=celeb,s=c.scorer;
  const a=ease5(Math.min(1,c.t/c.pan));
  celZoomK=a; updateView();
  const cx=c.c0x+(s.x-c.c0x)*a,cy=c.c0y+((s.y-8)-c.c0y)*a;
  camX=cx-VW/2; camY=Math.min(cy-VH/2,WH-VH+14);
}
function updateCeleb(dt){
  celeb.t+=dt;
  const k=celeb.t<0.9?0.3:1,d=dt*k;
  updateParts(d); updateCorpses(d);
  celebCam();
  celeb.fw-=dt;
  if(celeb.fw<=0&&celeb.t<celeb.dur-0.8){ celeb.fw=0.2; launchFirework(); }
  if(celeb.t<1.2) confetti(3);
  for(let i=fireworks.length-1;i>=0;i--){
    const fw=fireworks[i]; fw.y+=fw.vy*d; fw.vy+=40*d;
    parts.push({x:fw.x,y:fw.y+4,vx:(Math.random()-0.5)*10,vy:20,life:0.3,max:0.3,c:'#ffd23f',s:1,g:0});
    if(fw.y<=fw.peak){
      for(let n=0;n<34;n++){
        const a=n/34*6.283,sp=50+Math.random()*50;
        parts.push({x:fw.x,y:fw.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,life:0.9+Math.random()*0.4,max:1.3,c:n%3?fw.c:'#ffffff',s:n%4?1:2,g:70});
      }
      rings.push({x:fw.x,y:fw.y,r:2,max:26,t:0,life:0.35,c:fw.c});
      sfx('hit'); fireworks.splice(i,1);
    }
  }
  if(celeb.scorer&&!celeb.scorer.dead) celeb.scorer.cel=Math.abs(Math.sin(celeb.t*9))*7;
  if(celeb.t>=celeb.dur&&!NET.client) endCeleb();
}
function endCeleb(){
  const win=celeb.win;
  for(const f of fighters) f.cel=0;
  celeb=null; fireworks=[]; edge.jump=edge.dash=edge.attack=edge.switch=false;
  celZoomK=0; updateView();
  if(win){ endGame(); return; }
  resetBall(); bullets=[];
  BLK.length=0;
  for(const f of fighters){ f.ball=false; respawn(f); f.inv=1.5; }
  say('GET READY!','#ffffff');
}
function updateBall(dt){
  if(mode!=='td'||!ball) return;
  ball.cool=Math.max(0,ball.cool-dt);
  if(ball.carrier){
    const c=ball.carrier;
    if(c.dead){ ball.carrier=null; }
    else {
      ball.x=c.x; ball.y=c.y-14; ball.vx=0; ball.vy=0;
      const z=c.team==='blue'?ZR:ZL;
      if(c.x>=z[0]&&c.x<=z[0]+z[2]&&c.y>=z[1]&&c.y<=z[1]+z[3]+2) scoreGoal(c.team,c);
      return;
    }
  }
  ball.vy=Math.min(300,ball.vy+GRAV*0.8*dt);
  moveEntity(ball,dt);
  for(const hz of HAZ){ if(ball.x>hz[0]&&ball.x<hz[0]+hz[2]&&ball.y>hz[1]+2){ burst(ball.x,ball.y,'#ff7a1f',14,110); resetBall(); say('BALL RESET','#ffd23f'); break; } }
  if(boxHits(ball.x-3,ball.y-5,6,6)) ball.vx*=0.94;
  if(ball.cool<=0) for(const f of fighters){
    if(f.dead) continue;
    if(Math.abs(f.x-ball.x)<8&&ball.y>f.y-18&&ball.y<f.y+4){ grab(f); break; }
  }
}

/* ================= fighter step ================= */
function approach(v,t,d){ return v<t?Math.min(v+d,t):Math.max(v-d,t); }
function stoneChips(x,y,n){
  const C=['#56699c','#3a4668','#8da0d0','#222a45'];
  for(let i=0;i<n;i++) parts.push({x:x+(Math.random()-0.5)*4,y:y,vx:(Math.random()-0.5)*110,vy:-30-Math.random()*70,life:0.55+Math.random()*0.3,max:0.8,c:C[Math.floor(Math.random()*4)],s:Math.random()<0.5?2:1,g:420});
}
function damageBlock(k,dmg,by){
  if(by&&k.owner&&!isEnemy(by,k.owner)) return;
  k.hp-=dmg; k.flash=0.08; burst(k.x,k.y-k.h*0.5,'#9aa5c4',3,60); k.shk=0.12;
  stoneChips(k.x,k.y-6-Math.random()*(k.h-10),2+Math.min(4,Math.floor(dmg/8)));
  if(k.hp<=0){
    const i=BLK.indexOf(k); if(i>=0) BLK.splice(i,1);
    burst(k.x,k.y-k.h*0.5,'#9aa5c4',16,110); burst(k.x,k.y-k.h*0.5,k.owner&&k.owner.pal?k.owner.pal.main:'#38b6ff',8,90);
    rings.push({x:k.x,y:k.y-k.h*0.5,r:2,max:16,t:0,life:0.3,c:'#cfe8ff'}); sfx('boom');
    for(let n=0;n<4;n++) stoneChips(k.x,k.y-4-n*7,4);
    for(let n=0;n<10;n++) parts.push({x:k.x+(Math.random()-0.5)*8,y:k.y-Math.random()*6,vx:(Math.random()-0.5)*70,vy:-10-Math.random()*30,life:0.8,max:0.8,c:'#8a8fa8',s:2,g:-12});
    rings.push({x:k.x,y:k.y-1,r:2,max:24,t:0,life:0.35,c:'#8a8fa8'}); shake=Math.max(shake,3);
  }
}
function blockDamageAt(px,py,dmg,by){ if(!BLK.length) return; const k=blockAt(px,py); if(k) damageBlock(k,dmg,by); }
function updateBlocks(dt){
  for(let i=BLK.length-1;i>=0;i--){
    const k=BLK[i]; k.t-=dt; k.flash=Math.max(0,k.flash-dt); if(k.shk>0) k.shk-=dt;
    if(k.t<=0){ burst(k.x,k.y-k.h*0.5,'#9aa5c4',10,60); BLK.splice(i,1); }
  }
}
function placeBlock(f,sk){
  const dir=f.face;
  for(const dist of [13,17,22,28]){
    const bx=f.x+dir*dist; let by=-1;
    for(let yy=Math.floor(f.y)-2;yy<=f.y+40;yy+=2){ if(solidAt(bx,yy+1)){ by=yy; break; } }
    if(by<0) continue;
    if(boxHits(bx-3,by-30,6,29)) continue;
    let clear=true;
    for(const o of fighters){ if(o.dead) continue; if(bx-3<o.x+o.w/2&&bx+3>o.x-o.w/2&&by-30<o.y&&by>o.y-o.h){ clear=false; break; } }
    if(ball&&!ball.carrier&&Math.abs(ball.x-bx)<7&&ball.y>by-34&&ball.y<by+2) clear=false;
    if(!clear) continue;
    BLK.push({x:bx,y:by,w:6,h:30,hp:sk.hp,max:sk.hp,t:sk.life,owner:f,flash:0});
    burst(bx,by-4,'#cfe8ff',10,70); rings.push({x:bx,y:by-2,r:2,max:14,t:0,life:0.3,c:'#7dffea'}); sfx('pick');
    rings.push({x:bx,y:by-1,r:2,max:22,t:0,life:0.35,c:'#8a8fa8'});
    for(let n=0;n<14;n++) parts.push({x:bx+(Math.random()-0.5)*10,y:by-Math.random()*3,vx:(Math.random()-0.5)*90,vy:-8-Math.random()*26,life:0.7,max:0.7,c:n&1?'#8a8fa8':'#c4cce0',s:Math.random()<0.4?2:1,g:-10});
    for(let n=0;n<5;n++) stoneChips(bx,by-2,1);
    if(f===fighters[0]) shake=Math.max(shake,2);
    return true;
  }
  return false;
}
function shieldCross(sh,x0,y0,x1,y1){
  const sx=sh.x+sh.face*9,dx=x1-x0;
  if(dx===0||dx*sh.face>=0) return false;
  if((x0-sx)*(x1-sx)>0) return false;
  const yc=y0+(y1-y0)*((sx-x0)/dx);
  return yc>=sh.y-23&&yc<=sh.y+2;
}
function shieldHurt(sh,cost){
  sh.sp-=cost; sh.shFl=0.12; sh.spR=0.8;
  { const bx=sh.x+sh.face*9; rings.push({x:bx,y:sh.y-8-Math.random()*8,r:1,max:9,t:0,life:0.2,c:'#ffffff'}); for(let n=0;n<4;n++) parts.push({x:bx,y:sh.y-12,vx:-sh.face*(20+Math.random()*60),vy:(Math.random()-0.5)*60,life:0.3,max:0.3,c:n&1?'#bffff5':'#ffffff',s:1,g:0}); }
  if(sh.sp<=0){ sh.sp=0; sh.skOn=false; sh.spR=1.5; burst(sh.x+sh.face*9,sh.y-10,'#7dffea',14,110); ptext(sh,'SHIELD BROKEN'); sfx('hit');
    for(let n=0;n<12;n++) parts.push({x:sh.x+sh.face*9+(Math.random()-0.5)*3,y:sh.y-22+Math.random()*24,vx:(Math.random()-0.5)*120,vy:-20-Math.random()*60,life:0.7,max:0.7,c:n%3?'#7dffea':'#ffffff',s:2,g:380});
    rings.push({x:sh.x+sh.face*9,y:sh.y-11,r:2,max:28,t:0,life:0.4,c:'#7dffea'}); shake=Math.max(shake,sh.isBot?1:3); }
}
function shieldAtPoint(owner,x,y,dirx){
  for(const sh of fighters){
    if(!sh.skOn||sh.dead||sh.sk!=='sk_shield'||!isEnemy(owner,sh)) continue;
    if(Math.abs(x-(sh.x+sh.face*9))<=3&&y>=sh.y-23&&y<=sh.y+2&&dirx*sh.face<0) return sh;
  }
  return null;
}
function featherBurst(f,n){
  for(let i=0;i<n;i++){ const a=Math.random()*6.283,sp=30+Math.random()*60; parts.push({x:f.x-f.face*4,y:f.y-10,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-20,life:0.9+Math.random()*0.5,max:1.2,c:i&1?'#ffffff':'#bfe8ff',s:2,g:40}); }
}
function skillOff(f){
  if(f.flying){ featherBurst(f,8); if(f.onGround) for(let n=0;n<6;n++) parts.push({x:f.x+(Math.random()-0.5)*8,y:f.y,vx:(Math.random()-0.5)*60,vy:-6-Math.random()*14,life:0.5,max:0.5,c:'#c4cce0',s:1,g:-10}); }
  f.skOn=false; f.flying=false; f.flyG=0; psfx(f,'dash');
}
function skillStep(f,inp,dt){
  f.spR=Math.max(0,f.spR-dt); f.blkCd=Math.max(0,f.blkCd-dt); f.shFl=Math.max(0,f.shFl-dt);
  const sk=SKILLS[f.sk];
  if(!sk||sk.kind==='none'){ f.skOn=false; f.flying=false; return; }
  if(inp.skill&&f.stun<=0){
    if(sk.kind==='shield'||sk.kind==='fly'){
      if(f.skOn) skillOff(f);
      else if(f.sp>=sk.use&&f.spR<=0){
        f.skOn=true; f.sp-=sk.use; sfx('pick');
        burst(f.x,f.y-8,sk.kind==='fly'?'#bfe8ff':'#7dffea',10,80);
        if(sk.kind==='fly'){ f.vy=Math.min(f.vy,-90); f.onGround=false; f.jumps=Math.max(f.jumps,1); featherBurst(f,14); rings.push({x:f.x,y:f.y-1,r:2,max:26,t:0,life:0.35,c:'#bfe8ff'}); rings.push({x:f.x,y:f.y-9,r:2,max:18,t:0,life:0.3,c:'#ffffff'}); }
        else if(sk.kind==='shield'){
          const bx=f.x+f.face*9;
          rings.push({x:bx,y:f.y-11,r:2,max:22,t:0,life:0.35,c:'#7dffea'}); rings.push({x:bx,y:f.y-11,r:2,max:13,t:0,life:0.25,c:'#ffffff'});
          for(let n=0;n<14;n++) parts.push({x:bx,y:f.y-22+n*1.7,vx:f.face*(10+Math.random()*50),vy:(Math.random()-0.5)*30,life:0.45,max:0.45,c:n&1?'#7dffea':'#ffffff',s:1,g:0});
        }
      } else { ptext(f,f.sp<sk.use?'NOT ENOUGH SP':'WAIT'); psfx(f,'hit'); }
    } else if(sk.kind==='block'){
      if(f.sp>=sk.use&&f.blkCd<=0){
        if(placeBlock(f,sk)){ f.sp-=sk.use; f.blkCd=0.7; f.spR=1.0; }
        else { ptext(f,'NO ROOM'); psfx(f,'hit'); }
      } else { ptext(f,'NOT ENOUGH SP'); psfx(f,'hit'); }
    }
  }
  if(f.skOn){
    let dr=sk.drain||0; if(sk.kind==='fly'&&inp.jumpHeld) dr+=sk.rise;
    f.sp-=dr*dt; f.spR=Math.max(f.spR,0.6);
    if(f.sp<=0){ f.sp=0; skillOff(f); f.spR=1.5; ptext(f,'OUT OF SP'); }
  } else if(f.spR<=0) f.sp=Math.min(f.maxsp,f.sp+14*dt);
  f.flying=f.skOn&&sk.kind==='fly';
  if(f.flying){
    f.jumps=Math.max(f.jumps,1);
    if(f.onGround&&!inp.jumpHeld){ f.flyG+=dt; if(f.flyG>0.35) skillOff(f); } else f.flyG=0;
    if(Math.random()<0.5) parts.push({x:f.x-f.face*5+(Math.random()-0.5)*4,y:f.y-9+Math.random()*4,vx:-f.face*8,vy:10+Math.random()*14,life:0.35,max:0.35,c:Math.random()<0.5?'#7dd3fc':'#ffffff',s:1,g:0});
    if(Math.random()<(inp.jumpHeld?0.22:0.1)) parts.push({x:f.x-f.face*7+(Math.random()-0.5)*8,y:f.y-12+Math.random()*6,vx:-f.face*(6+Math.random()*10),vy:6+Math.random()*10,life:1.0+Math.random()*0.6,max:1.4,c:Math.random()<0.5?'#ffffff':'#bfe8ff',s:2,g:8});
    if(inp.jumpHeld&&Math.random()<0.4) parts.push({x:f.x+(Math.random()-0.5)*6,y:f.y+1,vx:(Math.random()-0.5)*20,vy:30+Math.random()*30,life:0.3,max:0.3,c:'#e0f4ff',s:1,g:0});
  }
}
function stepFighter(f,inp,dt){
  f.hurt=Math.max(0,f.hurt-dt); f.inv=Math.max(0,f.inv-dt); f.stun=Math.max(0,f.stun-dt);
  f.atkCd-=dt; f.dashCd-=dt; f.swing=Math.max(0,f.swing-dt); f.anim+=dt;
  f.flash=Math.max(0,f.flash-dt); f.aimT=Math.max(0,f.aimT-dt); f.recoil=Math.max(0,f.recoil-dt*9);
  f.comboT=Math.max(0,f.comboT-dt); f.idleT+=dt; f.spin=Math.max(0,f.spin-dt*1.5);
  f.onGround=f.vy>=0&&boxHits(f.x-f.w/2,f.y-f.h+1,f.w,f.h);
  f.wallL=boxHits(f.x-f.w/2-1,f.y-f.h+2,1,f.h-4);
  f.wallR=boxHits(f.x+f.w/2,f.y-f.h+2,1,f.h-4);
  if(f.onGround){ f.coyote=0.09; f.jumps=0; } else f.coyote-=dt;
  if(!f.onGround&&f.coyote<=0&&f.jumps===0) f.jumps=1;
  const canAct=f.stun<=0;
  skillStep(f,inp,dt);
  if(inp.face&&canAct) f.face=inp.face;
  if(inp.switch&&canAct&&!f.locked){ f.weapon^=1; f.atkCd=Math.max(f.atkCd,0.1); f.swing=0; }
  /* dash */
  if(inp.dash&&f.dashCd<=0&&canAct){
    const d=inp.move||f.face; f.face=d; f.dashT=0.14; f.dashCd=0.75*f.dcdm;
    burst(f.x,f.y-6,f.pal.hair,6,60); psfx(f,'dash');
  }
  /* jump */
  if(inp.jump&&canAct&&!f.flying){
    let jumped=false;
    if(f.coyote>0){ f.vy=-262*f.jmp; f.jumps=1; f.coyote=0; dust(f.x,f.y); jumped=true; }
    else if(f.wallL||f.wallR){ const d=f.wallL?1:-1; f.vy=-245*f.jmp; f.vx=d*125; f.face=d; f.jumps=1; dust(f.x-d*4,f.y-6); jumped=true; }
    else if(f.jumps<2){ f.vy=-235*f.jmp; f.jumps=2; burst(f.x,f.y,'#cfc8ff',5,40); jumped=true; }
    if(jumped){ f.dashT=0; psfx(f,'jump'); }
  }
  /* movement */
  if(f.dashT>0){
    f.dashT-=dt; f.vx=f.face*235; f.vy=0;
    if(Math.random()<0.7) parts.push({x:f.x-f.face*3,y:f.y-3-Math.random()*8,vx:0,vy:0,life:0.2,max:0.2,c:f.pal.main,s:2,g:0});
  } else {
    if(f.lungeT>0) f.lungeT-=dt;
    if(canAct&&f.lungeT<=0){
      const sp=92*f.spd*(f.ball?(WW>400?0.97:0.85):1),acc=f.onGround?(ICE?320:900):550;
      if(inp.move){ f.face=inp.move; f.vx=approach(f.vx,inp.move*sp,acc*dt); }
      else f.vx=approach(f.vx,0,(f.onGround?(ICE?70:700):150)*dt);
    }
    if(f.flying){
      /* hold jump = rise, down = dive, otherwise glide down slowly */
      f.vy=approach(f.vy,inp.jumpHeld?-105:(inp.down?95:24),700*dt); f.sliding=false;
    } else {
      f.vy=Math.min(330,f.vy+GRAV*dt);
      if(f.vy<0&&!inp.jumpHeld) f.vy+=GRAV*0.9*dt;
      const wd=(f.wallL&&inp.move<0)?-1:(f.wallR&&inp.move>0)?1:0;
      f.sliding=!f.onGround&&wd!==0&&f.vy>0;
      if(f.sliding){ f.vy=Math.min(f.vy,38); if(Math.random()<0.25) dust(f.x+wd*4,f.y-4); }
    }
  }
  /* attack */
  if((!f.isBot||f.remote!=null)&&canAct){
    if(inp.aim&&f.weapon===1){ f.aimA=Math.atan2(inp.aim.y,Math.abs(inp.aim.x)); f.aimT=0.15; if(Math.abs(inp.aim.x)>0.05) f.face=inp.aim.x>0?1:-1; }
    else if(inp.attack&&inp.face) f.face=inp.face;
  }
  if(inp.attack&&f.atkCd<=0&&canAct&&f.dashT<=0) fire(f,inp);
  if(f.swing>0) swordHit(f);
  moveEntity(f,dt);
  for(const pd of PADS){
    if(f.vy>=0&&f.x>=pd.x&&f.x<=pd.x+pd.w&&f.y>=pd.y-2&&f.y<=pd.y+4){
      f.vy=-430; f.jumps=1; f.coyote=0; pd.sq=1; f.dashT=0;
      burst(f.x,f.y,'#ff9ee0',8,80); psfx(f,'jump');
    }
  }
  for(const hz of HAZ){
    if(f.x>hz[0]&&f.x<hz[0]+hz[2]&&f.y>hz[1]+2){
      if(f.role==='chaser'){ f.vy=-380; f.jumps=1; burst(f.x,f.y,'#ffb02e',6,80); continue; }
      f.hp-=170*dt; f.hurt=0.1;
      if(Math.random()<0.6) parts.push({x:f.x+(Math.random()-0.5)*6,y:f.y-Math.random()*8,vx:(Math.random()-0.5)*40,vy:-50-Math.random()*40,life:0.4,max:0.4,c:Math.random()<0.5?'#ffb02e':'#ff5a1f',s:1,g:100});
      if(f.hp<=0){ die(f,null,' BURNED'); return; }
    }
  }
  if(f.burnT>0){
    f.burnT-=dt; f.hp-=7*dt;
    if(Math.random()<0.5) parts.push({x:f.x+(Math.random()-0.5)*6,y:f.y-12,vx:(Math.random()-0.5)*20,vy:-40-Math.random()*30,life:0.35,max:0.35,c:Math.random()<0.5?'#ff8a2e':'#ffd23f',s:1,g:-20});
    if(f.hp<=0){ die(f,f.burnBy,' BURNED'); return; }
  }
  if(f.regen&&f.hp<f.maxhp) f.hp=Math.min(f.maxhp,f.hp+f.regen*dt);
}
function playerInput(){
  const p=fighters[0];
  const inp={move:(keys.right?1:0)-(keys.left?1:0),jump:edge.jump,jumpHeld:keys.jump,dash:edge.dash,
    attack:keys.attack||keys.mouse||edge.attack,switch:edge.switch,skill:edge.skill,down:keys.down,face:0,aim:null};
  edge.jump=edge.dash=edge.attack=edge.switch=edge.skill=false;
  if(p&&!p.dead){
    const gun=p.weapon===1;
    if(AIMS.on){
      /* touch aim stick */
      const ax=AIMS.x,ay=AIMS.y;
      if(gun) inp.aim={x:ax,y:ay};
      if(Math.abs(AIMS.x)>0.2) inp.face=AIMS.x>0?1:-1;
      if(AIMS.m>0.55) inp.attack=true;
      aimX=ax; aimY=ay; aimOn=true;
    } else if(mouseOn&&hoverX>=0){
      /* mouse aim: shoot / slash toward the cursor */
      const dx=camX+hoverX/ZOOM-p.x,dy=camY+hoverY/ZOOM-(p.y-8),d=Math.hypot(dx,dy);
      if(d>3){
        const ux=dx/d,uy=dy/d;
        if(gun) inp.aim={x:ux,y:uy};
        if(Math.abs(ux)>0.05) inp.face=ux>0?1:-1;
        aimX=ux; aimY=uy; aimOn=true;
      } else { aimX=p.face; aimY=0; aimOn=false; }
    } else { aimX=p.face; aimY=0; aimOn=false; }
  }
  return inp;
}

/* ================= bot AI ================= */
function wpTarget(p,f){
  const cx=(p[0]+p[1])/2;
  let ex=f.x<cx?p[0]-8:p[1]+8;
  if(ex<12||ex>WW-12) ex=f.x<cx?p[1]+8:p[0]-8;
  return [ex,p[2],cx];
}
function think(f){
  const b=f.ai,D=DIFF[diff];
  b.think=D.thk*(0.7+Math.random()*0.6);
  let near=null,nd=1e9;
  for(const e of fighters){
    if(e.dead||!isEnemy(f,e)) continue;
    const d=Math.hypot(e.x-f.x,e.y-f.y); if(d<nd){nd=d;near=e;}
  }
  let g=null,foe=near;
  if(mode!=='td'){ if(near) g={x:near.x,y:near.y,fight:true}; }
  else {
    const hz=f.team==='blue'?ZR:ZL;
    if(f.ball) g={x:hz[0]+hz[2]/2,y:hz[1]+hz[3]-2,run:true};
    else if(!ball.carrier){
      let best=null,bd=1e9;
      for(const m of fighters){
        if(m.dead||m.team!==f.team) continue;
        const d=Math.hypot(m.x-ball.x,m.y-ball.y)+(m.isBot?0:80);
        if(d<bd){bd=d;best=m;}
      }
      if(best===f) g={x:ball.x,y:ball.y,fetch:true};
      else if(near) g={x:near.x,y:near.y,fight:true};
    } else if(ball.carrier.team===f.team){
      const c=ball.carrier; g={x:c.x+(f.team==='blue'?24:-24),y:c.y,escort:true};
    } else { foe=ball.carrier; g={x:foe.x,y:foe.y,fight:true}; }
  }
  if(!g&&near) g={x:near.x,y:near.y,fight:true};
  b.goal=g; b.foe=foe;
  b.los=foe?lineClear(f.x,f.y-8,foe.x,foe.y-8):false;
  /* unstuck: if no progress toward the goal for a while, wander to a random spot */
  const dg=g?Math.hypot(g.x-f.x,g.y-f.y):0;
  if(b.lastD!==undefined&&!b.los&&dg>b.lastD-4) b.noProg=(b.noProg||0)+b.think; else b.noProg=0;
  b.lastD=dg;
  if(b.wanderT>0){ b.wanderT-=b.think; g=b.wg; b.goal=g; }
  else if(b.noProg>2.5&&DM_SP.length){
    const q=DM_SP[Math.floor(Math.random()*DM_SP.length)];
    b.wg={x:q[0],y:q[1],wander:true}; b.wanderT=3; g=b.wg; b.goal=g; b.noProg=0;
  }
  b.wp=null;
  if(g&&g.y-f.y<-24){
    let best=null,bs=1e9;
    for(const p of PLAT){
      if(p[2]<f.y-10&&p[2]>=f.y-70){
        const cx=(p[0]+p[1])/2;
        const s=Math.abs(p[2]-g.y)+0.5*Math.abs(cx-f.x)+0.3*Math.abs(cx-g.x);
        if(s<bs){bs=s;best=p;}
      }
    }
    b.wp=best;
  }
}
function botInput(f,dt){
  const b=f.ai,D=DIFF[diff];
  const inp={move:0,jump:false,jumpHeld:true,dash:false,attack:false,switch:false,down:false,face:0,aim:null};
  b.think-=dt; b.jcd-=dt; b.swcd-=dt; b.dcd-=dt;
  if(b.think<=0||!b.goal) think(f);
  const g=b.goal,foe=b.foe&&!b.foe.dead?b.foe:null;
  let tx=g?g.x:f.x,ty=g?g.y:f.y,jumpX=null;
  if(b.wp){ const t=wpTarget(b.wp,f); ty=t[1]; if(f.onGround){ tx=t[0]; jumpX=t[0]; } else tx=t[2]; }
  const dx=tx-f.x,dy=ty-f.y;
  const stop=(g&&g.fight&&!b.wp)?(f.weapon===0?10:56):6;
  let move=Math.abs(dx)>stop?Math.sign(dx):0;
  /* stuck handling */
  b.stT+=dt;
  if(b.stT>0.5){
    b.stT=0;
    if(move!==0&&Math.abs(f.x-b.lx)<2&&f.dashT<=0&&f.stun<=0){ b.unstick=0.5; b.rev=Math.random()<0.5?-move:move; }
    b.lx=f.x;
  }
  if(b.unstick>0){ b.unstick-=dt; move=b.rev; if(b.jcd<=0){ inp.jump=true; b.jcd=0.25; } }
  /* going up */
  if(b.wp||dy<-16){
    if(f.onGround&&b.jcd<=0&&(jumpX!==null?Math.abs(f.x-jumpX)<12:Math.abs(dx)<26)){ inp.jump=true; b.jcd=0.35; }
    else if(!f.onGround&&f.vy>0&&f.jumps<2&&f.y>ty-6&&b.jcd<=0){ inp.jump=true; b.jcd=0.2; }
  }
  /* blocked by wall */
  if(move!==0&&f.onGround&&b.jcd<=0&&((move<0&&f.wallL)||(move>0&&f.wallR))){ inp.jump=true; b.jcd=0.3; }
  /* dash */
  if(b.dcd<=0&&Math.abs(dx)>70&&move!==0&&Math.random()<D.dash*dt*3){ inp.dash=true; b.dcd=1.3; }
  inp.move=move;
  /* combat */
  if(foe){
    const fx=foe.x-f.x,fy=(foe.y-7)-(f.y-8),dist=Math.hypot(fx,fy);
    if(mode==='ch'&&f.role==='runner'&&foe.role==='chaser'&&dist<50){
      inp.move=-(Math.sign(fx)||1);
      if(f.dashCd<=0&&b.dcd<=0){ inp.dash=true; b.dcd=0.9; }
      if(((inp.move<0&&f.wallL)||(inp.move>0&&f.wallR))&&b.jcd<=0){ inp.jump=true; b.jcd=0.3; }
    }
    if(b.swcd<=0&&!f.locked){
      const want=(mode==='ch'&&f.role==='runner')?1:(dist<34?0:(dist>62?1:f.weapon));
      if(want!==f.weapon){ inp.switch=true; b.swcd=0.8; }
    }
    if(f.weapon===0){
      if(Math.abs(fx)<24&&Math.abs(fy)<16){ inp.face=Math.sign(fx)||f.face; if(Math.random()<0.4+D.fire*0.5) inp.attack=true; }
    } else if(dist<190&&b.los&&Math.random()<D.fire*0.09){
      const ang=Math.atan2(fy,fx)+(Math.random()-0.5)*2*D.jit;
      inp.aim={x:Math.cos(ang),y:Math.sin(ang)}; inp.face=Math.sign(fx)||f.face; inp.attack=true;
    }
  }
  /* skills */
  { const sk=SKILLS[f.sk];
    b.skcd=(b.skcd||0)-dt;
    if(sk&&sk.kind!=='none'&&f.stun<=0&&b.skcd<=0){
      const fx2=foe?foe.x-f.x:0,d2=foe?Math.hypot(fx2,(foe.y-f.y)):1e9;
      if(sk.kind==='shield'){
        const want=!!(foe&&b.los&&d2<190&&d2>26&&f.sp>22);
        if(want&&!f.skOn&&f.sp>=sk.use&&f.spR<=0){ inp.skill=true; b.skcd=0.6; if(foe) inp.face=Math.sign(fx2)||f.face; }
        else if(!want&&f.skOn){ inp.skill=true; b.skcd=0.6; }
      } else if(sk.kind==='block'){
        if(foe&&b.los&&d2>45&&d2<150&&f.sp>=sk.use&&f.blkCd<=0&&Math.random()<dt*0.7){ inp.skill=true; inp.face=Math.sign(fx2)||f.face; b.skcd=1.2; }
      }
    }
  }
  for(const hz of HAZ){
    const ahead=move!==0&&((move>0&&f.x<hz[0]&&hz[0]-f.x<26)||(move<0&&f.x>hz[0]+hz[2]&&f.x-(hz[0]+hz[2])<26))&&Math.abs(f.y-hz[1])<6;
    if(ahead&&f.onGround&&b.jcd<=0){ inp.jump=true; b.jcd=0.3; }
    const over=f.x>hz[0]-4&&f.x<hz[0]+hz[2]+4&&f.y<hz[1]+4;
    if(over&&!f.onGround){
      if(f.vy>0&&f.jumps<2&&b.jcd<=0){ inp.jump=true; b.jcd=0.2; }
      if(f.dashCd<=0&&b.dcd<=0&&move!==0){ inp.dash=true; b.dcd=0.6; }
    }
  }
  return inp;
}

/* ================= update ================= */
function checkWin(){
  if(mode==='dm'){
    for(const f of fighters) if(f.kills>=KILLS_TO_WIN){ winner=f; endGame(); return; }
  }
}
function endGame(){
  if(state==='over') return;
  state='over'; overT=0; keys.mouse=false;
  const p=fighters[0];
  const won=(mode==='dm'||mode==='ch')?winner===p:winTeam===p.team;
  const bonus=won?50:15; earned+=bonus;
  SV.coins+=earned; SV.totalCoins+=earned;
  SV.kills+=p.kills; SV.deaths+=p.deaths; SV.goals+=myGoals; SV.matches++;
  if(won) SV.wins++; else SV.losses++;
  SV.bestKills=Math.max(SV.bestKills,p.kills);
  SV.hist.push({m:mode,w:won?1:0,k:p.kills,d:p.deaths,c:earned});
  if(SV.hist.length>10) SV.hist.shift();
  lastResult={won:won,earned:earned,bonus:bonus};
  persist();
  hostOver();
}
function updateParts(dt){
  for(let i=parts.length-1;i>=0;i--){
    const p=parts[i]; p.life-=dt;
    if(p.life<=0){ parts[i]=parts[parts.length-1]; parts.pop(); continue; }
    p.x+=p.vx*dt; p.y+=p.vy*dt; p.vy+=p.g*dt;
  }
  for(let i=feed.length-1;i>=0;i--){ feed[i].t-=dt; if(feed[i].t<=0) feed.splice(i,1); }
  shake*=0.82; if(shake<0.3) shake=0;
  for(let i=texts.length-1;i>=0;i--){ const t=texts[i]; t.t-=dt; t.y+=t.vy*dt; t.vy*=0.95; if(t.t<=0) texts.splice(i,1); }
  for(let i=rings.length-1;i>=0;i--){ rings[i].t+=dt; if(rings[i].t>=rings[i].life) rings.splice(i,1); }
  flashT=Math.max(0,flashT-dt); streakT=Math.max(0,streakT-dt);
  if(banner){ banner.t-=dt; if(banner.t<=0) banner=null; }
  for(const pd of PADS) pd.sq=Math.max(0,pd.sq-dt*4);
  for(let i=slashes.length-1;i>=0;i--){
    const sl=slashes[i]; sl.t+=dt;
    if(sl.f&&!sl.f.dead){ sl.x=sl.f.x+sl.face*2; sl.y=sl.f.y-9; }
    if(sl.t>=sl.life) slashes.splice(i,1);
  }
  for(let i=beams.length-1;i>=0;i--){ beams[i].t+=dt; if(beams[i].t>=beams[i].life) beams.splice(i,1); }
}
function countdownStep(dt){
  cdT-=dt; edge.jump=edge.dash=edge.attack=edge.switch=edge.skill=false;
  for(const f of fighters) f.anim+=dt;
  if(cdT<=0){
    cdT=0; goT=0.9; cdLast=0; sfx('start'); shake=Math.max(shake,2);
    for(const f of fighters) f.inv=Math.max(f.inv,1.2);   /* short spawn protection once play begins */
    return;
  }
  const n=Math.ceil(cdT); if(n!==cdLast){ cdLast=n; sfx('pick'); }
  updateParts(dt); updateCam(dt);
}
function update(dt){
  if(NET.host) hitstop=0;   /* online matches never freeze */
  if(goT>0) goT=Math.max(0,goT-dt);
  if(cdT>0){ countdownStep(dt); return; }
  if(hitstop>0){ hitstop-=dt; return; }
  if(celeb){ updateCeleb(dt); return; }
  time+=dt;
  if(mode==='ch') chTick(dt);
  for(const f of fighters){
    if(f.dead){
      if(mode!=='ch'){ f.respawn-=dt; if(f.respawn<=0) respawn(f); }
      if(!f.isBot){ edge.jump=edge.dash=edge.attack=edge.switch=false; }
      else if(f.remote!=null&&NET.rin[f.remote]){ const e=NET.rin[f.remote].e; e.jump=e.dash=e.att=e.sw=e.sk=false; }
      continue;
    }
    stepFighter(f,(mode==='ch'&&chPhase!=='run')?idleInp():(f.remote!=null?remoteInput(f):f.isBot?botInput(f,dt):playerInput()),dt);
  }
  updateBullets(dt); updateBlocks(dt); updateBall(dt); updateCorpses(dt); updateParts(dt); updateCam(dt); updateReaper(dt);
  if(state==='play') checkWin();
}

/* ================= multiplayer over Wi-Fi / phone hotspot =================
   HOW IT WORKS: one device (the HOST) runs the whole game, bots included. Every other device sends its
   thumb inputs to the host and draws what the host sends back. server.js only relays messages.
   The tunable numbers live in the NET block near the top of this file. */
const BCOL=[],BCI={};
(function(){
  const add=function(c){ if(c&&BCI[c]===undefined){ BCI[c]=BCOL.length; BCOL.push(c); } };
  for(const id in WEAP){ add(WEAP[id].bc); add(WEAP[id].color); }
})();
const MP={view:'start',msg:'',mode:'dm',mapPos:0,mapName:'RANDOM',addrBuf:''};
const R10=function(v){ return Math.round(v*10); },R100=function(v){ return Math.round(v*100); };

function mpDefaultAddr(){ try{ if(location.protocol==='http:'&&location.host) return location.host; }catch(e){} return ''; }
function mpAddr(){ return (SV.mpAddr&&String(SV.mpAddr))||mpDefaultAddr(); }
function myInfo(){ const e=SV.eq; return {c:e.char,m:e.melee,g:e.gun,s:(SV.owned.indexOf(e.skill)>=0?e.skill:'sk_none')}; }
function wsSend(o){ try{ if(NET.ws&&NET.ws.readyState===1) NET.ws.send(typeof o==='string'?o:JSON.stringify(o)); }catch(e){} }
function sendD(d,to){ wsSend({t:'to',to:to==null?'all':to,d:d}); }

/* ---------- events recorded by the host for everybody (cosmetic only) ---------- */
function rec(ev){ if(NET.host&&NET.ev.length<70) NET.ev.push(ev); }
/* ---------- events for one player (their own kills, damage numbers, coin pickups ...) ---------- */
function pnote(f,ev){ if(!NET.host||!f||f.remote==null) return; const q=NET.my[f.remote]; if(!q) return; q.push(ev); if(q.length>30) q.shift(); }
function ptext(f,m,c){ if(!f.isBot) addText(f.x,f.y-26,m,c||'#ff8a8a'); else if(f.remote!=null) pnote(f,['txt',m,c||'#ff8a8a']); }
const ATK_SND={cannon:1,snipe:1,needle:1,bolt:1,zap:1,plasma:1,shoot:1,smg:1,scat:1,shot:1,laser:1,rail:1,power:1,flame:1,launch:1,slash:1,slash2:1,stab:1,scythe:1,scythe2:1,scythehit:1};
function psfx(f,k){
  if(!ATK_SND[k]){ if(!f.isBot) sfx(k); else if(f.remote!=null) pnote(f,['sfx',k]); return; }
  if(!f.isBot){ if(NET.host) rec(['sa',k,Math.round(f.x),Math.round(f.y),f.gid===undefined?-1:f.gid]); sfxPlay(k,1); return; }   /* your own weapon: full volume */
  if(f.remote!=null) pnote(f,['sfx',k]);     /* a phone player hears their own weapon at full volume... */
  sfxAt(k,f.x,f.y,f.gid);                    /* ...everyone else hears it from where it happened */
}
function myKill(name,col){
  earned+=10; streak=streakT>0?streak+1:1; streakT=3.2;
  const sm=streak>=4?'RAMPAGE!':streak===3?'TRIPLE KILL':streak===2?'DOUBLE KILL':'';
  banner={t:1.5,a:'ELIMINATED '+name,b:sm,c:col}; flashCol='#ffffff'; flashT=0.1;
}

/* ---------- connection ---------- */
function mpClearTimers(){ if(NET.pingT){ clearInterval(NET.pingT); NET.pingT=0; } }
function mpClose(){
  mpClearTimers(); NET.findId++;
  { const N=nat(); if(N){ try{ N.beacon(false,'',0); }catch(e){} } }
  const w=NET.ws; NET.ws=null;
  NET.on=NET.host=NET.client=false; NET.id=-1; NET.welcomed=false; NET.humans=null; NET.roster=[]; NET.rin={}; NET.my={}; NET.starting=false;
  if(w){ try{ w.onclose=w.onmessage=w.onerror=w.onopen=null; w.close(); }catch(e){} }
}
function mpResetWorld(){
  paused=false; celeb=null; fireworks=[]; celZoomK=0; bullets=[]; BLK.length=0; updateView();
}
function netDown(msg){
  const was=NET.on;
  mpClose(); mpResetWorld();
  if(state==='play'||state==='over'||state==='mp'){ state='mp'; MP.view='start'; MP.msg=msg||'DISCONNECTED'; }
  else if(was) MP.msg=msg||'DISCONNECTED';
}
function mpLeave(){ mpClose(); mpResetWorld(); state='mp'; MP.view='start'; MP.msg=''; sfx('pick'); }
/* inside the Android app, window.Native exists: the app runs the relay itself and finds games by itself */
function nat(){ try{ return window.Native||null; }catch(e){ return null; } }
function mpFind(N,id,cb){
  let tries=0;
  (function poll(){
    if(NET.findId!==id) return;
    let list=[]; try{ list=JSON.parse(N.hosts()||'[]'); }catch(e){}
    if(list.length){ cb(list[0].ip+':'+list[0].port); return; }
    if(++tries>=10){ let gw=''; try{ gw=N.gateway()||''; }catch(e){} cb(gw?gw+':8080':''); return; }   /* hotspot: the host is the gateway */
    setTimeout(poll,250);
  })();
}
function mpConnect(role){
  mpClose();
  rvCancel();
  if(isLR()){
    const code=pairMethod()==='code';
    if(role==='host'){ pairHostStart(); if(code) rvHostStart(); }
    else if(code){ MP.view='room'; MP.roomBuf=''; MP.msg=''; }
    else pairJoinUI();
    return;
  }
  const N=nat();
  if(N&&!SV.mpAddr){
    if(role==='host'){ let p=8080; try{ p=N.port(); }catch(e){} mpOpen('127.0.0.1:'+p,role); return; }
    MP.msg='LOOKING FOR GAMES...';
    const id=++NET.findId;
    mpFind(N,id,function(addr){ if(NET.findId!==id||state!=='mp') return; if(!addr){ MP.msg='NO GAME FOUND - IS THE HOST READY?'; return; } mpOpen(addr,role); });
    return;
  }
  const addr=mpAddr();
  if(!addr){ MP.msg='SET THE SERVER ADDRESS FIRST'; openAddr(); return; }
  try{ if(location.protocol==='https:'){ MP.msg='THIS PAGE IS HTTPS - OPEN http://'+addr; return; } }catch(e){}
  mpOpen(addr,role);
}
function mpOpen(addr,role){
  let ws;
  try{ ws=new WebSocket('ws://'+addr); }catch(e){ MP.msg='BAD ADDRESS'; return; }
  MP.msg='CONNECTING...';
  mpAttach(ws,role);
}
function mpAttach(ws,role){
  NET.ws=ws; NET.role=role;
  ws.onopen=function(){
    if(NET.ws!==ws) return;
    wsSend({t:role,name:SV.name||'YOU',info:myInfo()});
    mpClearTimers();
    NET.pingT=setInterval(function(){ wsSend({t:'ping',ts:performance.now()}); },2000);
  };
  ws.onmessage=function(e){ if(NET.ws!==ws) return; let m; try{ m=JSON.parse(e.data); }catch(_){ return; } netMsg(m); };
  ws.onclose=function(){ if(NET.ws===ws) netDown(NET.welcomed?'DISCONNECTED':'CANNOT REACH SERVER'); };
  ws.onerror=function(){};
}
function netMsg(m){
  switch(m.t){
    case 'welcome':
      NET.id=m.id; NET.welcomed=true; NET.host=!!m.host; NET.client=!m.host; NET.on=true;
      MP.view='lobby'; MP.msg=''; MP.mapName=''; NET.lastSnap=performance.now();
      if(NET.host){ mpSendCfg(); const N=nat(); if(N){ try{ N.beacon(true,SV.name||'HOST',(N.port()|0)||8080); }catch(e){} } }
      sfx('score'); break;
    case 'roster': NET.roster=m.list||[]; if(NET.host) mpSendCfg(); break;
    case 'err': { const msg=m.m||'ERROR'; mpClose(); MP.msg=msg; MP.view='start'; break; }
    case 'closed': netDown(m.m||'HOST LEFT'); break;
    case 'pong': NET.rtt=Math.max(0,Math.round(performance.now()-m.ts)); break;
    case 'left': if(NET.host) hostPeerLeft(m.id); break;
    case 'msg': if(NET.host) hostRecv(m.from,m.d); else clientRecv(m.d); break;
  }
}

/* ================= HOST ================= */
function mpMapLabel(){ const L=mapIdxs(MP.mode); return MP.mapPos<L.length?MAPS[L[MP.mapPos]].name:'RANDOM'; }
function mpSendCfg(){ MP.mapName=mpMapLabel(); sendD({k:'cfg',mode:MP.mode,map:MP.mapName}); }
function newRin(){ return {m:0,jh:false,att:false,dn:false,face:0,ax:0,ay:0,ha:false,t:performance.now(),e:{jump:false,dash:false,att:false,sw:false,sk:false}}; }
function mpStart(){
  if(!NET.host||NET.starting) return;
  if(NET.roster.length<2){ MP.msg='NEED AT LEAST 2 PLAYERS'; sfx('hit'); return; }
  MP.msg='';
  const L=mapIdxs(MP.mode); mapSel=MP.mapPos>=L.length?MAPS.length:L[MP.mapPos];
  const hs=NET.roster.slice().sort(function(a,b){ return a.id-b.id; });
  const seen={};
  NET.humans=hs.map(function(r){
    let n=String(r.name||'P'+r.id).slice(0,8); if(seen[n]){ n=n.slice(0,7)+seen[n]; seen[r.name]++; } else seen[n]=2;
    return {id:r.id,name:n,info:r.info||{}};
  });
  NET.rin={}; NET.my={};
  for(const h of NET.humans) if(h.id!==NET.id){ NET.rin[h.id]=newRin(); NET.my[h.id]=[]; }
  NET.starting=true; NET.ev=[]; NET.seq=0; NET.snapT=0;
  wsSend({t:'state',s:'play'});
  startGame(MP.mode);
  const fs=fighters.map(function(f){
    return [f.name,f.team,f.pal.main,f.pal.dark,f.pal.hair,f.style,f.wd[0].id,f.wd[1].id,f.sk,f.maxhp,f.spd,f.jmp,f.dcdm,R10(f.x)/10,R10(f.y)/10,f.face];
  });
  const slots={}; for(const f of fighters) if(f.remote!=null) slots[f.remote]=f.gid;
  sendD({k:'start',mode:mode,map:curIdx,fs:fs,slots:slots,cd:cdT});
}
/* called from startGame: put the connected humans into fighter slots */
function mpAssign(){
  const hs=NET.humans; let bi=0,ri=0;
  const per=Math.ceil(fighters.length/2);
  hs.forEach(function(h,k){
    let f;
    if(mode==='td'){ f=(k%2===0)?fighters[bi++]:fighters[per+ri++]; }
    else f=fighters[k];
    if(!f) return;
    f.name=h.name;
    if(h.id!==NET.id){ f.isBot=true; f.remote=h.id; f.minfo=h.info; f.weapon=1; }
  });
}
function hostPeerLeft(id){
  delete NET.rin[id]; delete NET.my[id];
  if(state!=='play'&&state!=='over') return;
  for(const f of fighters) if(f.remote===id){
    f.remote=null; f.gone=true; f.dead=true; f.respawn=f.respTotal=1e9; f.hp=0; f.skOn=false; f.flying=false;
    if(f.ball&&ball){ f.ball=false; ball.carrier=null; ball.x=f.x; ball.y=f.y-2; ball.vx=0; ball.vy=-120; ball.cool=0.5; }
    burst(f.x,f.y-7,f.pal.main,14,90); say(f.name+' LEFT','#ff8a8a');
  }
}
function hostRecv(from,d){
  if(!d||d.k!=='in'||!NET.rin[from]) return;
  const r=NET.rin[from],a=d.i; if(!a||a.length<13) return;
  r.m=a[0]>0?1:a[0]<0?-1:0;
  if(a[1]) r.e.jump=true; r.jh=!!a[2];
  if(a[3]) r.e.dash=true; r.att=!!a[4];
  if(a[5]) r.e.sw=true; if(a[6]) r.e.sk=true;
  r.dn=!!a[7]; r.face=a[8]>0?1:a[8]<0?-1:0;
  r.ax=Math.max(-1,Math.min(1,(a[9]||0)/100)); r.ay=Math.max(-1,Math.min(1,(a[10]||0)/100)); r.ha=!!a[11];
  if(a[12]) r.e.att=true;
  r.t=performance.now();
}
function remoteInput(f){
  const r=NET.rin[f.remote];
  if(!r) return {move:0,jump:false,jumpHeld:false,dash:false,attack:false,switch:false,skill:false,down:false,face:0,aim:null};
  const stale=performance.now()-r.t>700;   /* phone went quiet: stop holding its buttons */
  const inp={move:stale?0:r.m,jump:r.e.jump,jumpHeld:!stale&&r.jh,dash:r.e.dash,attack:(!stale&&r.att)||r.e.att,
    switch:r.e.sw,skill:r.e.sk,down:!stale&&r.dn,face:stale?0:r.face,aim:(!stale&&r.ha)?{x:r.ax,y:r.ay}:null};
  r.e.jump=r.e.dash=r.e.att=r.e.sw=r.e.sk=false;
  return inp;
}
function mpBackToLobby(){
  paused=false; state='mp'; MP.view='lobby'; sfx('pick');
  if(NET.host){ NET.starting=false; NET.humans=null; wsSend({t:'state',s:'lobby'}); sendD({k:'lobby'}); mpSendCfg(); }
  else wsSend({t:'info',name:SV.name||'YOU',info:myInfo()});
}
function hostOver(){
  if(!NET.host) return;
  sendD({k:'over',w:winner?winner.gid:-1,wt:winTeam||null,st:fighters.map(function(f){ return [f.kills,f.deaths,f.score]; })});
}
function hostSnap(){
  const F=new Array(fighters.length);
  for(let i=0;i<fighters.length;i++){
    const f=fighters[i];
    const fl=(f.dead?1:0)|(f.onGround?2:0)|(f.flying?4:0)|(f.skOn?8:0)|(f.ball?16:0)|(f.hurt>0?32:0)|(f.inv>0?64:0)|(f.burnT>0?128:0)|(f.shFl>0?256:0)|(f.dashT>0?512:0);
    F[i]=[R10(f.x),R10(f.y),Math.round(f.vx),Math.round(f.vy),f.face,Math.round(f.hp),fl,f.weapon,R100(f.swing),R100(f.swingDur),f.swingStep,Math.round(f.swingRange),
      R100(f.aimA),R100(f.aimT),R100(f.recoil),R100(f.flash),f.shots,Math.round(f.sp),Math.round(f.cel||0),R10(f.respawn>0?Math.min(f.respawn,999):0),f.kills,f.deaths,f.score,f.combo,R10(f.comboT),R10(Math.max(0,f.dashCd))];
  }
  const B=[]; const nb=Math.min(bullets.length,90);
  for(let i=0;i<nb;i++){
    const b=bullets[i];
    B.push([R10(b.x),R10(b.y),Math.round(b.vx),Math.round(b.vy),(b.wave?1:0)|(b.flame?2:0)|(b.grav?4:0)|(b.boom?8:0)|(b.big?16:0)|(b.trail?32:0),
      b.c&&BCI[b.c]!==undefined?BCI[b.c]:-1,R100(b.life),b.owner&&b.owner.gid!==undefined?b.owner.gid:-1]);
  }
  const K=BLK.map(function(k){ return [R10(k.x),R10(k.y),Math.round(k.hp),k.max,R10(k.t),k.owner?k.owner.gid:-1,R100(k.flash||0)]; });
  /* new rings / slashes / beams the host made since the last snapshot */
  for(const r of rings) if(!r.n){ r.n=1; rec(['r',R10(r.x)/10,R10(r.y)/10,r.r,r.max,r.life,r.c,Math.round(r.t*100)/100]); }
  for(const b of beams) if(!b.n){ b.n=1; rec(['bm',R10(b.x1)/10,R10(b.y1)/10,R10(b.x2)/10,R10(b.y2)/10,b.life,b.c||'#ffffff',b.th,b.zig?1:0]); }
  for(const s of slashes) if(!s.n){ s.n=1; if(s.f&&s.f.gid!==undefined) rec(['sl',s.f.gid,s.face,s.step,s.life,s.r,s.color,s.big?1:0,s.thrust?1:0,s.claw?1:0]); }
  const S={k:'snap',n:++NET.seq,t:R100(time),cd:R100(cdT),sc:[scores.blue,scores.red],f:F,b:B,kb:K,
    bl:ball?[R10(ball.x),R10(ball.y),ball.carrier?ball.carrier.gid:-1,ball.hidden?1:0]:0,
    ce:celeb&&celeb.scorer?[R100(celeb.t),celeb.dur,celeb.team==='blue'?1:0,celeb.win?1:0,celeb.scorer.gid]:0,
    sk:Math.round(shake*10)/10,ev:NET.ev};
  NET.ev=[];
  const my={}; let any=false;
  for(const id in NET.my){ const q=NET.my[id]; if(q.length){ my[id]=q.slice(); q.length=0; any=true; } }
  if(any) S.my=my;
  if(NET.ws&&NET.ws.readyState===1){
    if(NET.ws.bufferedAmount>250000) return;   /* slow uplink: skip this frame instead of building a queue */
    NET.ws.send('{"t":"to","to":"all","d":'+JSON.stringify(S)+'}');
  }
}
function hostTick(now){
  if(now-NET.snapT>=1000/NET.snapHz-2){ NET.snapT=now; hostSnap(); }
}

/* ================= CLIENT ================= */
function clientRecv(d){
  if(!d) return;
  switch(d.k){
    case 'cfg': MP.mode=d.mode; MP.mapName=d.map||''; break;
    case 'start': clientStart(d); break;
    case 'snap': clientSnap(d); break;
    case 'over': clientOver(d); break;
    case 'lobby': if(state==='mp') MP.view='lobby'; break;
  }
}
function clientStart(d){
  BLK.length=0; mode=d.mode; camZoom=(CAM.zoom[mode]!==undefined?CAM.zoom[mode]:1);
  loadMap(d.map);
  bullets=[]; parts=[]; feed=[]; corpses=[]; texts=[]; rings=[]; slashes=[]; beams=[]; banner=null; hitstop=0; flashT=0; streak=0; streakT=0;
  scores={blue:0,red:0}; winner=null; winTeam=null; time=0; shake=0; paused=false;
  const me=d.slots[NET.id]; if(me===undefined) return;
  const all=[];
  d.fs.forEach(function(a,g){
    const f=mk(g,a[0],a[1],{main:a[2],dark:a[3],hair:a[4]},g!==me);
    f.gid=g; f.style=a[5]; f.wd=[WEAP[a[6]]||WEAP.pulse,WEAP[a[7]]||WEAP.blaster]; f.sk=a[8]; f.maxhp=a[9]; f.hp=a[9]; f.spd=a[10]; f.jmp=a[11]; f.dcdm=a[12];
    f.x=a[13]; f.y=a[14]; f.face=a[15]; f.placed=true; f.weapon=g===me?1:0; f.respTotal=RESPAWN_SECS[mode]||2.5; f.ai=null;
    all.push(f);
  });
  NET.byG=all; const mine=all[me];
  fighters=[mine].concat(all.filter(function(f){ return f!==mine; }));
  ball=mode==='td'?{x:WW/2,y:MAPS[curIdx].ballY,vx:0,vy:0,w:6,h:6,bounce:0.45,carrier:null,cool:0,hidden:false}:null;
  chaser=null; reaper=null; celeb=null; fireworks=[]; celZoomK=0; updateView();
  earned=0; myGoals=0; lastResult=null; showSB=false; NET.buf=[]; NET.lastN=0; NET.lastSnap=performance.now(); NET.ie={j:0,d:0,s:0,k:0,a:0}; NET.lastIn=0; NET.lag=false;
  edge.jump=edge.dash=edge.attack=edge.switch=edge.skill=false;
  state='play'; sfx('start'); cdT=d.cd||0; goT=0; cdLast=Math.ceil(cdT)+1; chTime=0;
  skillBtnSync(); snapCam();
}
function clientOver(d){
  if(state!=='play') return;
  bullets=[]; celeb=null; fireworks=[]; celZoomK=0; updateView();
  if(d.st) d.st.forEach(function(a,g){ const f=NET.byG[g]; if(f){ f.kills=a[0]; f.deaths=a[1]; f.score=a[2]; } });
  winner=d.w>=0?NET.byG[d.w]:null; winTeam=d.wt;
  if(!winner&&mode!=='td') winner=fighters[0];
  endGame();
}
function clientSnap(d){
  if(state!=='play'||!NET.byG||d.n<=NET.lastN) return;
  NET.lastN=d.n;
  const now=performance.now(); NET.lastSnap=now;
  const me=fighters[0];
  const xs=[],ys=[];
  for(let g=0;g<d.f.length;g++){
    const a=d.f[g],f=NET.byG[g]; if(!f) continue;
    const wasDead=f.dead,fl=a[6];
    xs[g]=a[0]/10; ys[g]=a[1]/10;
    f.vx=a[2]; f.vy=a[3]; f.face=a[4]; f.hp=a[5];
    f.dead=!!(fl&1); f.onGround=!!(fl&2); f.flying=!!(fl&4); f.skOn=!!(fl&8); f.ball=!!(fl&16);
    f.hurt=(fl&32)?0.1:0; f.inv=(fl&64)?0.5:0; f.burnT=(fl&128)?1:0; f.shFl=(fl&256)?0.1:0; f.dashT=(fl&512)?0.1:0;
    f.weapon=a[7]; f.swing=a[8]/100; f.swingDur=a[9]/100||0.16; f.swingStep=a[10]; f.swingRange=a[11]; f.aimA=a[12]/100; f.aimT=a[13]/100; f.recoil=a[14]/100; f.flash=a[15]/100;
    f.shots=a[16]; f.sp=a[17]; f.cel=a[18]; f.respawn=a[19]/10; f.kills=a[20]; f.deaths=a[21]; f.score=a[22]; f.combo=a[23]; f.comboT=a[24]/10; f.dashCd=a[25]/10;
    if(f===me&&wasDead&&!f.dead) snapCam();
  }
  let bx=0,by=0;
  if(d.bl&&ball){ bx=d.bl[0]/10; by=d.bl[1]/10; ball.carrier=d.bl[2]>=0?NET.byG[d.bl[2]]:null; ball.hidden=!!d.bl[3]; }
  NET.buf.push({rt:now,x:xs,y:ys,bx:bx,by:by}); if(NET.buf.length>12) NET.buf.shift();
  bullets=d.b.map(function(a){
    return {x:a[0]/10,y:a[1]/10,vx:a[2],vy:a[3],wave:!!(a[4]&1),flame:!!(a[4]&2),grav:!!(a[4]&4),boom:!!(a[4]&8),big:!!(a[4]&16),trail:!!(a[4]&32),
      c:a[5]>=0?BCOL[a[5]]:null,life:a[6]/100,owner:NET.byG[a[7]]||fighters[0],hit:null};
  });
  BLK.length=0;
  for(const a of d.kb) BLK.push({x:a[0]/10,y:a[1]/10,w:6,h:30,hp:a[2],max:a[3],t:a[4]/10,owner:NET.byG[a[5]]||null,flash:a[6]/100});
  scores.blue=d.sc[0]; scores.red=d.sc[1];
  if(Math.abs(time-d.t/100)>0.3) time=d.t/100;
  if(d.cd>0){ if(Math.abs(cdT-d.cd/100)>0.25) cdT=d.cd/100; }
  else if(cdT>0){ cdT=0; goT=0.9; cdLast=0; sfx('start'); shake=Math.max(shake,2); }
  if(d.sk>shake) shake=d.sk*0.7;
  if(d.ce){
    const c=d.ce,scr=NET.byG[c[4]];
    if(!celeb&&scr){
      const col=c[2]?'#38b6ff':'#ff4d5e';
      celeb={t:c[0]/100,dur:c[1],team:c[2]?'blue':'red',name:scr.name,col:col,win:!!c[3],fw:0,scorer:scr,c0x:camX+VW/2,c0y:camY+VH/2,
        pan:0.7+Math.min(0.5,Math.hypot(scr.x-(camX+VW/2),scr.y-(camY+VH/2))/2400)};
      flashCol=col; flashT=0.3; confetti(90); fanfare();
    } else if(celeb&&Math.abs(celeb.t-c[0]/100)>0.3) celeb.t=c[0]/100;
  } else if(celeb){
    for(const f of fighters) f.cel=0;
    celeb=null; fireworks=[]; celZoomK=0; updateView(); snapCam();
  }
  for(const e of d.ev) clientEvent(e);
  if(d.my&&d.my[NET.id]) for(const e of d.my[NET.id]) clientEvent(e);
}
function clientEvent(e){
  switch(e[0]){
    case 'b': burst(e[1],e[2],e[3],e[4],e[5]); break;
    case 'd': dust(e[1],e[2]); break;
    case 's': sfxPlay(e[1],1); break;
    case 'sa': { const me=fighters[0]; if(!(me&&me.gid===e[4])) sfxPlayAt(e[1],e[2],e[3]); break; }
    case 'say': say(e[1],e[2]); break;
    case 'cp': { const f=NET.byG[e[1]]; if(f) makeCorpse(f,NET.byG[e[2]]||null); break; }
    case 'r': rings.push({x:e[1],y:e[2],r:e[3],max:e[4],t:e[7]||0,life:e[5],c:e[6]}); break;
    case 'bm': beams.push({x1:e[1],y1:e[2],x2:e[3],y2:e[4],t:0,life:e[5],c:e[6],th:e[7],zig:!!e[8]}); break;
    case 'sl': { const f=NET.byG[e[1]]; if(f) slashes.push({f:f,x:f.x+e[2]*2,y:f.y-9,face:e[2],step:e[3],t:0,life:e[4],r:e[5],color:e[6],big:!!e[7],thrust:!!e[8],claw:!!e[9]}); break; }
    case 'kill': myKill(e[1],e[2]); sfx('score'); break;
    case 'died': flashCol='#ff3b3b'; flashT=0.2; streak=0; streakT=0; break;
    case 'dmg': addText(e[1],e[2],String(e[3]),e[4]?'#ff8a8a':'#ffffff'); break;
    case 'txt': addText(fighters[0].x,fighters[0].y-26,e[1],e[2]); break;
    case 'earn': earned+=e[1]; if(e[2]) myGoals++; break;
  }
}
function clientSendInput(now){
  const inp=playerInput(),e=NET.ie;
  let fresh=false;
  if(inp.jump){ e.j=1; fresh=true; } if(inp.dash){ e.d=1; fresh=true; } if(inp.switch){ e.s=1; fresh=true; } if(inp.skill){ e.k=1; fresh=true; }
  if(inp.attack&&!NET.wasAtk){ e.a=1; fresh=true; } NET.wasAtk=!!inp.attack;
  const due=now-NET.lastIn>=1000/NET.inputHz;
  if(!(due||(fresh&&now-NET.lastIn>=10))) return;
  NET.lastIn=now;
  const a=inp.aim;
  sendD({k:'in',u:(e.j||e.d||e.s||e.k||e.a)?0:1,i:[inp.move,e.j,inp.jumpHeld?1:0,e.d,inp.attack?1:0,e.s,e.k,inp.down?1:0,inp.face,a?Math.round(a.x*100):0,a?Math.round(a.y*100):0,a?1:0,e.a]},NET.hostId);
  e.j=e.d=e.s=e.k=e.a=0;
}
function clientInterp(now){
  const buf=NET.buf; if(!buf.length) return;
  const last=buf[buf.length-1],rt=now-NET.interpMs;
  let a=null,b=null;
  for(let i=buf.length-1;i>=0;i--){ if(buf[i].rt<=rt){ a=buf[i]; b=buf[i+1]||null; break; } }
  if(!a){ a=buf[0]; b=null; }
  const me=fighters[0];
  for(const f of fighters){
    const g=f.gid; if(a.x[g]===undefined) continue;
    if(f===me){
      const age=Math.min(0.1,(now-last.rt)/1000);
      f.x=last.x[g]+f.vx*age; f.y=f.onGround?last.y[g]:last.y[g]+f.vy*age;
      continue;
    }
    if(b){
      const u=Math.max(0,Math.min(1,(rt-a.rt)/Math.max(1,b.rt-a.rt)));
      const dx=b.x[g]-a.x[g],dy=b.y[g]-a.y[g];
      if(dx*dx+dy*dy>2500){ f.x=b.x[g]; f.y=b.y[g]; } else { f.x=a.x[g]+dx*u; f.y=a.y[g]+dy*u; }
    } else {
      const ex=Math.max(0,Math.min(0.1,(rt-a.rt)/1000));
      f.x=a.x[g]+f.vx*ex; f.y=a.y[g];
    }
  }
  if(ball&&!ball.carrier){
    if(b){ const u=Math.max(0,Math.min(1,(rt-a.rt)/Math.max(1,b.rt-a.rt))); ball.x=a.bx+(b.bx-a.bx)*u; ball.y=a.by+(b.by-a.by)*u; }
    else { ball.x=a.bx; ball.y=a.by; }
  } else if(ball&&ball.carrier){ ball.x=ball.carrier.x; ball.y=ball.carrier.y-14; }
}
/* one frame of a client: no simulation, just smoothing what the host sent */
function clientStep(dt,now){
  clientSendInput(now);
  NET.lag=now-NET.lastSnap>1200;
  if(goT>0) goT=Math.max(0,goT-dt);
  if(cdT>0){ cdT=Math.max(0.001,cdT-dt); const n=Math.ceil(cdT); if(n!==cdLast){ cdLast=n; sfx('pick'); } }
  else if(!celeb) time+=dt;
  for(const f of fighters) f.anim+=dt;
  clientInterp(now);
  const k=Math.min(1,dt*60);
  for(let i=bullets.length-1;i>=0;i--){
    const b=bullets[i];
    if(b.grav) b.vy+=GRAV*0.75*dt;
    b.x+=b.vx*dt; b.y+=b.vy*dt; b.life-=dt;
    if(b.life<-0.2){ bullets.splice(i,1); continue; }
    if(b.trail&&parts.length<PERF.maxParts&&Math.random()<k){
      if(b.boom) parts.push({x:b.x-Math.sign(b.vx)*4,y:b.y,vx:(Math.random()-0.5)*15,vy:(Math.random()-0.5)*15,life:0.35,max:0.35,c:Math.random()<0.5?'#ffb84d':'#7a7a86',s:2,g:0});
      else parts.push({x:b.x,y:b.y,vx:0,vy:0,life:0.14,max:0.14,c:b.c||(b.owner&&b.owner.pal?b.owner.pal.hair:'#ffffff'),s:1,g:0});
    }
    if(b.flame&&parts.length<PERF.maxParts&&Math.random()<0.6*k) parts.push({x:b.x,y:b.y,vx:(Math.random()-0.5)*14,vy:-15,life:0.25,max:0.25,c:Math.random()<0.5?'#ff8a2e':'#ffd23f',s:2,g:-40});
  }
  for(const kb of BLK){ kb.flash=Math.max(0,kb.flash-dt); }
  updateParts(dt); updateCorpses(dt);
  if(celeb) updateCeleb(dt); else updateCam(dt);
}

/* ================= CODE PAIRING: multiplayer with NO server, NO Node and NO app =================
   The host's phone is the relay. To add a friend, the host sends them a code (WhatsApp, SMS, anything), the friend sends a
   reply code back, and the two phones connect straight to each other (WebRTC). All phones must be on the same hotspot / Wi-Fi.
   The rest of the game is identical to the server version: the host phone plays the role of server.js. */
const PAIR={pcs:[]};
const LR={room:null,conns:new Set(),dog:0};
function pairMethod(){ const m=SV.mpMethod; return (m==='code'||m==='pair'||m==='server')?m:(nat()?'server':'code'); }
function isLR(){ const m=pairMethod(); return m==='code'||m==='pair'; }   /* the host phone is the relay */
function hasRTC(){ return typeof RTCPeerConnection!=='undefined'; }

/* ---------- codes: compressed + base64 so they are short enough to paste ---------- */
function b64u(bytes){ let s=''; for(let i=0;i<bytes.length;i++) s+=String.fromCharCode(bytes[i]); return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
function unb64u(str){ str=str.replace(/-/g,'+').replace(/_/g,'/'); while(str.length%4) str+='='; const s=atob(str),a=new Uint8Array(s.length); for(let i=0;i<s.length;i++) a[i]=s.charCodeAt(i); return a; }
function pipeBytes(bytes,Ctor){
  const cs=new Ctor('deflate-raw'),w=cs.writable.getWriter(); w.write(bytes); w.close();
  return new Response(cs.readable).arrayBuffer().then(function(b){ return new Uint8Array(b); });
}
function encodeCode(type,sdp){
  const raw=new TextEncoder().encode(JSON.stringify([type,sdp]));
  const done=function(tag,bytes){ return 'PR'+tag+'-'+b64u(bytes); };
  if(typeof CompressionStream==='undefined') return Promise.resolve(done('0',raw));
  return pipeBytes(raw,CompressionStream).then(function(b){ return done('1',b); },function(){ return done('0',raw); });
}
function extractCode(text){
  const t=String(text||''),flat=t.replace(/\s+/g,'');
  if(/^PR[01]-[A-Za-z0-9_\-]+$/.test(flat)) return flat;      /* just the code (even if a chat app wrapped it onto several lines) */
  const m=/PR[01]-[A-Za-z0-9_\-]+/.exec(t); return m?m[0]:'';   /* code inside a longer message */
}
function decodeCode(text){
  const code=extractCode(text),m=/^PR([01])-(.+)$/.exec(code);
  if(!m) return Promise.reject(new Error('NOT A VALID CODE'));
  let bytes; try{ bytes=unb64u(m[2]); }catch(e){ return Promise.reject(new Error('NOT A VALID CODE')); }
  const fin=function(b){
    let a; try{ a=JSON.parse(new TextDecoder().decode(b)); }catch(e){ throw new Error('NOT A VALID CODE'); }
    if(!Array.isArray(a)||typeof a[1]!=='string') throw new Error('NOT A VALID CODE');
    return a;
  };
  if(m[1]==='1'){
    if(typeof DecompressionStream==='undefined') return Promise.reject(new Error('UPDATE YOUR BROWSER'));
    return pipeBytes(bytes,DecompressionStream).then(fin,function(){ throw new Error('NOT A VALID CODE'); });
  }
  try{ return Promise.resolve(fin(bytes)); }catch(e){ return Promise.reject(e); }
}
function newPC(){ return new RTCPeerConnection({iceServers:[]}); }   /* no internet servers: phones on the same network find each other directly */
function waitIce(pc){
  return new Promise(function(res){
    if(pc.iceGatheringState==='complete') return res();
    const t=setTimeout(res,3500);
    pc.addEventListener('icegatheringstatechange',function(){ if(pc.iceGatheringState==='complete'){ clearTimeout(t); res(); } });
  });
}

/* ---------- the host phone acts as the relay (a copy of server.js's room rules) ---------- */
function lrClean(s,n){ return String(s==null?'':s).replace(/[^\w \-]/g,'').slice(0,n||8); }
function lrInfo(i){ try{ const j=JSON.stringify(i&&typeof i==='object'?i:{}); return j.length<=600?JSON.parse(j):{}; }catch(e){ return {}; } }
function lrRoster(){ const l=[]; for(const p of LR.room.players.values()) l.push({id:p.id,name:p.name,info:p.info,host:p.id===0}); return l; }
function lrAll(o){ const s=JSON.stringify(o); for(const p of LR.room.players.values()) p.conn.send(s); }
function lrErr(conn,m){ conn.send(JSON.stringify({t:'err',m:m})); }
function lrCloseRoom(msg){
  const r=LR.room; if(!r) return; LR.room=null;
  const s=JSON.stringify({t:'closed',m:msg||'HOST LEFT'});
  for(const p of r.players.values()){ p.conn.send(s); p.conn.closeSoon(); }
}
function lrRecv(conn,text){
  conn.lastSeen=Date.now();
  let m; try{ m=JSON.parse(text); }catch(e){ return; }
  if(!m||typeof m.t!=='string') return;
  if(m.t==='ping'){ conn.send(JSON.stringify({t:'pong',ts:m.ts})); return; }
  const R=LR.room;
  if(!conn.me){
    if(m.t==='host'){
      if(R) return lrErr(conn,'A HOST ALREADY EXISTS - TAP JOIN');
      LR.room={players:new Map(),state:'lobby'};
      conn.me={id:0,name:lrClean(m.name)||'HOST',info:lrInfo(m.info),conn:conn};
      LR.room.players.set(0,conn.me);
      conn.send(JSON.stringify({t:'welcome',id:0,host:true,max:NET.max}));
      lrAll({t:'roster',list:lrRoster()});
    } else if(m.t==='join'){
      if(!R) return lrErr(conn,'NO HOST YET - ASK SOMEONE TO TAP HOST');
      if(R.state!=='lobby') return lrErr(conn,'MATCH ALREADY STARTED');
      let id=-1; for(let i=1;i<NET.max;i++) if(!R.players.has(i)){ id=i; break; }
      if(id<0) return lrErr(conn,'ROOM FULL ('+NET.max+' PLAYERS)');
      conn.me={id:id,name:lrClean(m.name)||('P'+id),info:lrInfo(m.info),conn:conn};
      R.players.set(id,conn.me);
      conn.send(JSON.stringify({t:'welcome',id:id,host:false,max:NET.max}));
      lrAll({t:'roster',list:lrRoster()});
    }
    return;
  }
  if(!R||R.players.get(conn.me.id)!==conn.me) return;
  const me=conn.me;
  if(m.t==='info'){ me.info=lrInfo(m.info); me.name=lrClean(m.name)||me.name; return lrAll({t:'roster',list:lrRoster()}); }
  if(m.t==='state'&&me.id===0){ R.state=m.s==='play'?'play':'lobby'; return; }
  if(m.t==='to'){
    const out=JSON.stringify({t:'msg',from:me.id,d:m.d});
    if(me.id===0){
      if(m.to==='all'||m.to==null){ for(const p of R.players.values()) if(p.id!==0) p.conn.send(out); }
      else { const p=R.players.get(m.to|0); if(p&&p!==me) p.conn.send(out); }
    } else { const h=R.players.get(0); if(h) h.conn.send(out); }
  }
}
function lrClose(conn){
  LR.conns.delete(conn);
  if(!conn.me||!LR.room||LR.room.players.get(conn.me.id)!==conn.me) return;
  if(conn.me.id===0) return lrCloseRoom('HOST LEFT');
  LR.room.players.delete(conn.me.id);
  lrAll({t:'roster',list:lrRoster()});
  const h=LR.room.players.get(0); if(h) h.conn.send(JSON.stringify({t:'left',id:conn.me.id}));
  conn.me=null;
}
/* what the host's own game sends: snapshots take a fast path (no JSON round trip) because they go out 30 times a second */
function lrHostSend(hc,t){
  if(t.indexOf('{"t":"to","to":"all","d":')===0&&LR.room){
    const d=t.slice(25,-1),out='{"t":"msg","from":0,"d":'+d+'}',snap=d.indexOf('{"k":"snap"')===0;
    for(const p of LR.room.players.values()){
      if(p.id===0) continue;
      if(snap&&p.conn.backlog()>96*1024) continue;   /* slow phone: skip stale frames instead of queueing them */
      p.conn.send(out);
    }
    return;
  }
  lrRecv(hc,t);
}
function lrShutdown(){
  rvStop();
  lrCloseRoom('HOST LEFT');
  for(const s of PAIR.pcs){ try{ s.pc.close(); }catch(e){} }
  PAIR.pcs=[]; LR.conns.clear();
  if(LR.dog){ clearInterval(LR.dog); LR.dog=0; }
}
function lrDog(){
  const now=Date.now();
  for(const c of Array.from(LR.conns)) if(now-c.lastSeen>15000) c.close();   /* a phone that went quiet */
}
function pairHostStart(){
  if(!hasRTC()){ MP.msg='THIS BROWSER CANNOT DO CODE PAIRING'; return; }
  LR.room=null; LR.conns=new Set();
  const hc={me:null,lastSeen:Date.now(),
    send:function(t){ setTimeout(function(){ if(NET.ws===ws&&ws.onmessage) ws.onmessage({data:t}); },0); },closeSoon:function(){},close:function(){},backlog:function(){ return 0; }};
  const ws={readyState:1,bufferedAmount:0,onmessage:null,onclose:null,onopen:null,onerror:null,
    send:function(t){ lrHostSend(hc,t); },close:function(){ lrShutdown(); }};
  mpAttach(ws,'host');
  LR.dog=setInterval(lrDog,3000);
  setTimeout(function(){ if(NET.ws===ws&&ws.onopen) ws.onopen(); },0);
}
function makePeerConn(slot){
  const c={me:null,lastSeen:Date.now(),slot:slot,
    send:function(t){
      try{
        const fast=slot.u.readyState==='open'&&t.indexOf('"from":0,"d":{"k":"snap"')>0&&t.indexOf('"my":')<0;   /* snapshots may be dropped; anything with coins/kills must not */
        if(fast){ if(slot.u.bufferedAmount<64*1024) slot.u.send(t); }
        else if(slot.r.readyState==='open') slot.r.send(t);
      }catch(e){}
    },
    closeSoon:function(){ setTimeout(function(){ try{ slot.pc.close(); }catch(e){} },80); },
    close:function(){ try{ slot.pc.close(); }catch(e){} lrClose(c); },
    backlog:function(){ return slot.r.bufferedAmount+slot.u.bufferedAmount; }};
  return c;
}
/* host step 1: make a code for one friend */
function pairOffer(){
  const pc=newPC(),r=pc.createDataChannel('r'),u=pc.createDataChannel('u',{ordered:false,maxRetransmits:0});
  const slot={pc:pc,r:r,u:u,conn:null,onUp:null,onFail:null};
  PAIR.pcs.push(slot);
  const up=function(){
    if(slot.conn||r.readyState!=='open'||u.readyState!=='open'||!LR.room) return;
    slot.conn=makePeerConn(slot); LR.conns.add(slot.conn);
    if(slot.onUp) slot.onUp();
  };
  r.onopen=up; u.onopen=up;
  r.onmessage=u.onmessage=function(e){ if(slot.conn) lrRecv(slot.conn,e.data); };
  r.onclose=function(){ if(slot.conn) lrClose(slot.conn); };
  pc.onconnectionstatechange=function(){
    if(pc.connectionState==='failed'||pc.connectionState==='closed'){ if(slot.conn) lrClose(slot.conn); else if(slot.onFail) slot.onFail(); }
  };
  return pc.createOffer().then(function(o){ return pc.setLocalDescription(o); }).then(function(){ return waitIce(pc); })
    .then(function(){ return encodeCode('o',pc.localDescription.sdp); }).then(function(code){ return {slot:slot,code:code}; });
}
/* host step 2: the friend's reply code */
function pairAccept(slot,text){
  return decodeCode(text).then(function(a){
    if(a[0]!=='a') throw new Error('THAT IS NOT A REPLY CODE');
    return slot.pc.setRemoteDescription({type:'answer',sdp:a[1]});
  });
}
/* friend: turn the host's code into a reply code; `ready` resolves with a socket-like object once connected */
function pairAnswer(text){
  return decodeCode(text).then(function(a){
    if(a[0]!=='o') throw new Error('THAT IS NOT A HOST CODE');
    const pc=newPC(),ch={r:null,u:null};
    const ws={readyState:1,onmessage:null,onclose:null,onopen:null,onerror:null,
      get bufferedAmount(){ return ch.r?ch.r.bufferedAmount:0; },
      send:function(t){ try{ if(ch.u&&ch.u.readyState==='open'&&t.indexOf('"u":1')>0) ch.u.send(t); else if(ch.r) ch.r.send(t); }catch(e){} },
      close:function(){ try{ pc.close(); }catch(e){} }};
    const ready=new Promise(function(res,rej){
      const t=setTimeout(function(){ rej(new Error('HOST NEVER ANSWERED - SAME HOTSPOT?')); },45000);
      const chk=function(){
        if(ch.r&&ch.u&&ch.r.readyState==='open'&&ch.u.readyState==='open'){
          clearTimeout(t);
          ch.r.onmessage=ch.u.onmessage=function(e){ if(ws.onmessage) ws.onmessage({data:e.data}); };
          ch.r.onclose=function(){ if(ws.onclose) ws.onclose(); };
          res(ws);
        }
      };
      pc.ondatachannel=function(e){ ch[e.channel.label]=e.channel; e.channel.onopen=chk; chk(); };
      pc.onconnectionstatechange=function(){ if(pc.connectionState==='failed'){ clearTimeout(t); if(NET.ws===ws&&ws.onclose) ws.onclose(); else rej(new Error('COULD NOT CONNECT')); } };
    });
    return pc.setRemoteDescription({type:'offer',sdp:a[1]}).then(function(){ return pc.createAnswer(); })
      .then(function(an){ return pc.setLocalDescription(an); }).then(function(){ return waitIce(pc); })
      .then(function(){ return encodeCode('a',pc.localDescription.sdp); }).then(function(code){ return {code:code,ready:ready,pc:pc}; });
  });
}

/* ---------- the paste / copy window (a normal HTML box above the game, so paste works everywhere) ---------- */
function pairBox(){
  const d=document.createElement('div');
  d.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;z-index:99999;background:rgba(8,6,20,0.96);color:#fff;font:12px monospace;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:10px;box-sizing:border-box;text-align:center';
  const ti=document.createElement('div'); ti.style.cssText='font-size:14px;color:#ffdd55;font-weight:bold';
  const hi=document.createElement('div'); hi.style.cssText='color:#c9c4ff;max-width:560px';
  const ta=document.createElement('textarea'); ta.style.cssText='width:92%;max-width:560px;height:84px;background:#1d1740;color:#fff;border:1px solid #8a7cf0;font:11px monospace;padding:6px;box-sizing:border-box';
  ta.setAttribute('autocomplete','off'); ta.setAttribute('autocapitalize','off'); ta.setAttribute('spellcheck','false');
  ['keydown','keyup','keypress'].forEach(function(n){ ta.addEventListener(n,function(e){ e.stopPropagation(); }); });
  const st=document.createElement('div'); st.style.cssText='color:#ffd23f;min-height:14px';
  const row=document.createElement('div'); row.style.cssText='display:flex;gap:8px;flex-wrap:wrap;justify-content:center';
  const mkb=function(label){ const b=document.createElement('button'); b.textContent=label; b.style.cssText='font:bold 13px monospace;padding:10px 16px;background:#2a2050;color:#fff;border:2px solid #8a7cf0;border-radius:4px'; return b; };
  const bCopy=mkb('COPY'),bPaste=mkb('PASTE'),bOk=mkb('NEXT'),bCancel=mkb('CANCEL');
  row.appendChild(bCopy); row.appendChild(bPaste); row.appendChild(bOk); row.appendChild(bCancel);
  [ti,hi,ta,st,row].forEach(function(x){ d.appendChild(x); });
  const box={okFn:null,cancelFn:null,el:d,ta:ta,
    set:function(o){
      ti.textContent=o.title||''; hi.textContent=o.hint||''; ta.value=o.text||''; ta.readOnly=!!o.ro; ta.style.height=o.ro?'110px':'84px';
      bCopy.style.display=o.ro?'':'none'; bPaste.style.display=o.ro?'none':''; bOk.style.display=o.ok?'':'none'; bOk.textContent=o.ok||'';
      if(o.ro) setTimeout(function(){ try{ ta.focus(); ta.select(); }catch(e){} },30);
    },
    status:function(s){ st.textContent=s||''; },
    close:function(){ if(d.parentNode) d.parentNode.removeChild(d); }};
  bCopy.onclick=function(){
    try{ ta.focus(); ta.select(); ta.setSelectionRange(0,ta.value.length); }catch(e){}
    let ok=false; try{ ok=document.execCommand('copy'); }catch(e){}
    if(!ok&&navigator.clipboard&&navigator.clipboard.writeText){ navigator.clipboard.writeText(ta.value).then(function(){ box.status('COPIED'); },function(){}); return; }
    box.status(ok?'COPIED - NOW SEND IT':'PRESS AND HOLD THE BOX, THEN TAP COPY');
  };
  bPaste.onclick=function(){
    if(navigator.clipboard&&navigator.clipboard.readText){ navigator.clipboard.readText().then(function(v){ ta.value=v; box.status(''); },function(){ box.status('PRESS AND HOLD THE BOX, THEN TAP PASTE'); }); }
    else box.status('PRESS AND HOLD THE BOX, THEN TAP PASTE');
  };
  bOk.onclick=function(){ if(box.okFn) box.okFn(ta.value); };
  bCancel.onclick=function(){ if(box.cancelFn) box.cancelFn(); box.close(); };
  document.body.appendChild(d);
  return box;
}
function pairHostAddUI(){
  if(!LR.room||LR.room.players.size>=NET.max) return;
  const box=pairBox(); let slot=null,timer=0;
  box.set({title:'ADD A PLAYER  1 OF 2',hint:'MAKING A CODE...',text:'',ro:true});
  box.cancelFn=function(){ clearTimeout(timer); if(slot&&!slot.conn){ try{ slot.pc.close(); }catch(e){} } };
  pairOffer().then(function(o){
    slot=o.slot;
    box.set({title:'ADD A PLAYER  1 OF 2',hint:'TAP COPY, SEND THIS CODE TO YOUR FRIEND (WHATSAPP ETC.), THEN TAP NEXT',text:o.code,ro:true,ok:'NEXT'});
    slot.onUp=function(){ clearTimeout(timer); box.close(); sfx('score'); };
    slot.onFail=function(){ box.status('CONNECTION FAILED - CLOSE THIS AND TRY AGAIN'); };
    box.okFn=function(){
      box.set({title:'ADD A PLAYER  2 OF 2',hint:'YOUR FRIEND PASTES YOUR CODE AND GETS A REPLY CODE. PASTE THAT REPLY HERE',text:'',ro:false,ok:'CONNECT'});
      box.okFn=function(txt){
        box.status('CONNECTING...');
        pairAccept(slot,txt).then(function(){
          clearTimeout(timer); timer=setTimeout(function(){ if(!slot.conn) box.status('NOT CONNECTED - ARE YOU ON THE SAME HOTSPOT? CLOSE AND TRY AGAIN'); },25000);
        }).catch(function(e){ box.status(e.message||'NOT A VALID CODE'); });
      };
    };
  }).catch(function(e){ box.status('ERROR: '+(e&&e.message||e)); });
}
function pairAttachReady(ws){ mpClose(); mpAttach(ws,'join'); if(ws.onopen) ws.onopen(); }
function pairJoinUI(){
  if(!hasRTC()){ MP.msg='THIS BROWSER CANNOT DO CODE PAIRING'; return; }
  const box=pairBox();
  box.set({title:'JOIN A GAME  1 OF 2',hint:'THE HOST SENDS YOU A CODE. PASTE IT HERE',text:'',ro:false,ok:'NEXT'});
  let pc=null;
  box.cancelFn=function(){ if(pc&&!NET.ws){ try{ pc.close(); }catch(e){} } };
  box.okFn=function(txt){
    box.status('MAKING YOUR REPLY CODE...');
    pairAnswer(txt).then(function(a){
      pc=a.pc;
      box.set({title:'JOIN A GAME  2 OF 2',hint:'TAP COPY AND SEND THIS REPLY CODE BACK TO THE HOST. KEEP THIS SCREEN OPEN',text:a.code,ro:true});
      box.status('WAITING FOR THE HOST...');
      a.ready.then(function(ws){ box.close(); pairAttachReady(ws); }).catch(function(e){ box.status(e.message||'FAILED'); });
    }).catch(function(e){ box.status(e.message||'NOT A VALID CODE'); });
  };
}

/* ================= ROOM CODE: the easy way in =================
   The host sees a short number (like 4821) and the friends just type it. Behind the scenes the two phones swap the same long
   pairing codes as above, automatically, through a free public MQTT message broker. That needs internet for a few seconds only
   (a phone hotspot normally shares its mobile data with everyone on it). After that the game runs phone-to-phone.
   If the brokers are unreachable the host can still use ADD PLAYER (CODE) = the long codes, which need no internet at all. */
const RVC={
  len:4,                    /* digits in the room code */
  topic:'pixelrush1',       /* change this to make your own private room namespace */
  brokers:['wss://broker.emqx.io:8084/mqtt','wss://broker.hivemq.com:8884/mqtt','wss://test.mosquitto.org:8081/mqtt'],   /* tried in order */
  connectMs:5000,           /* give up on one broker after this long */
  findMs:6000,              /* a friend waits this long for a room with that code */
  answerMs:12000,           /* ...and this long for the host to answer */
  linkMs:30000,             /* ...and this long for the phones to connect */
  pendingMax:9,             /* friends being connected at the same time */
  pendingMs:40000           /* a half-finished connection is dropped after this long */
};
const RV={mq:null,code:'',st:'',slots:new Map(),busy:0,cancel:null,down:0,tries:0};

/* a tiny MQTT 3.1.1 client (QoS 0 only) over a WebSocket */
function mqOpen(o){
  const enc=new TextEncoder(),dec=new TextDecoder(),H={ws:null,up:false,dead:false,pt:0};
  const S=function(t){ const b=Array.from(enc.encode(t)); return [b.length>>8,b.length&255].concat(b); };
  const VL=function(n){ const a=[]; do{ let d=n%128; n=Math.floor(n/128); if(n) d|=128; a.push(d); }while(n); return a; };
  const send=function(h,body){ if(!H.ws||H.ws.readyState!==1) return; try{ H.ws.send(Uint8Array.from([h].concat(VL(body.length),body))); }catch(e){} };
  let pid=0,ui=0;
  H.sub=function(t){ pid=(pid%60000)+1; send(0x82,[pid>>8,pid&255].concat(S(t),[0])); };
  H.pub=function(t,m,retain){ send(0x30|(retain?1:0),S(t).concat(Array.from(enc.encode(m)))); };
  H.close=function(keepWill){
    if(H.dead) return; H.dead=true; clearInterval(H.pt); clearTimeout(H.ct);
    if(H.up&&o.will&&!keepWill) H.pub(o.will,'',true);   /* a clean goodbye: clear what we published */
    send(0xe0,[]);
    const w=H.ws; H.ws=null; if(w){ w.onopen=w.onmessage=w.onclose=w.onerror=null; setTimeout(function(){ try{ w.close(); }catch(e){} },150); }
  };
  const next=function(){
    if(H.dead) return;
    if(ui>=o.urls.length){ H.dead=true; if(o.onFail) o.onFail(); return; }
    const url=o.urls[ui++]; let ws,buf=new Uint8Array(0),gone=false;
    const skip=function(){ if(gone) return; gone=true; clearTimeout(H.ct); if(ws){ ws.onopen=ws.onmessage=ws.onclose=ws.onerror=null; try{ ws.close(); }catch(e){} } H.ws=null; next(); };
    try{ ws=new WebSocket(url,'mqtt'); }catch(e){ return next(); }
    H.ws=ws; ws.binaryType='arraybuffer';
    H.ct=setTimeout(skip,RVC.connectMs);
    ws.onerror=function(){ if(!H.up) skip(); };
    ws.onclose=function(){ if(!H.up) return skip(); clearInterval(H.pt); if(!H.dead){ H.dead=true; if(o.onDown) o.onDown(); } };
    ws.onopen=function(){
      const cid='pr'+Math.random().toString(36).slice(2,10);
      let flags=2,body=S('MQTT').concat([4]);
      if(o.will) flags|=0x04|0x20;
      body=body.concat([flags,0,30],S(cid));
      if(o.will) body=body.concat(S(o.will),[0,0]);
      send(0x10,body);
    };
    ws.onmessage=function(e){
      let b=new Uint8Array(e.data);
      if(buf.length){ const n=new Uint8Array(buf.length+b.length); n.set(buf); n.set(b,buf.length); b=n; }
      let p=0;
      for(;;){
        if(b.length-p<2) break;
        let q=p+1,mult=1,len=0,d,ok=true;
        do{ if(q>=b.length){ ok=false; break; } d=b[q++]; len+=(d&127)*mult; mult*=128; }while(d&128);
        if(!ok||b.length-q<len) break;
        if(len>65536){ skip(); return; }
        const type=b[p]>>4;
        if(type===2){
          if(b[q+1]!==0){ skip(); return; }
          clearTimeout(H.ct); H.up=true;
          H.pt=setInterval(function(){ send(0xc0,[]); },20000);
          if(o.onReady) o.onReady(H);
        } else if(type===3){
          const tl=(b[q]<<8)|b[q+1],qos=(b[p]>>1)&3,off=q+2+tl+(qos?2:0);
          if(o.onMsg) o.onMsg(dec.decode(b.subarray(q+2,q+2+tl)),dec.decode(b.subarray(off,q+len)));
        }
        p=q+len;
      }
      buf=b.subarray(p);
    };
  };
  next();
  return H;
}
const rvBase=function(code){ return RVC.topic+'/'+code; };
function rvStop(){
  if(RV.mq){ const m=RV.mq; RV.mq=null; m.close(); }
  for(const sl of RV.slots.values()){ if(!sl.conn){ try{ sl.pc.close(); }catch(e){} } }
  RV.slots.clear(); RV.st=''; RV.code=''; clearTimeout(RV.down);
}
/* ----- host: pick a free code, announce it, and answer join requests ----- */
function rvPick(){ let c=''; for(let i=0;i<RVC.len;i++) c+=String(Math.floor(Math.random()*10)); return c; }
function rvHostStart(){
  rvStop(); RV.st='conn';
  const run=function(code,fresh,tries){
    const base=rvBase(code); let taken=false,mq;
    mq=mqOpen({urls:RVC.brokers,will:base+'/h',
      onFail:function(){ if(RV.mq===mq||!RV.mq){ RV.mq=null; RV.st='fail'; } },
      onDown:function(){ if(RV.mq!==mq) return; RV.mq=null; RV.st='conn'; clearTimeout(RV.down); RV.down=setTimeout(function(){ if(NET.host&&LR.room&&!RV.mq) run(code,false,0); },2000); },
      onReady:function(h){
        h.sub(base+'/h'); h.sub(base+'/q');
        if(!fresh){ h.pub(base+'/h','1',true); RV.st='ok'; return; }
        setTimeout(function(){
          if(RV.mq!==mq) return;
          if(taken){ RV.mq=null; mq.close(true); if(tries>8){ RV.st='fail'; return; } run(rvPick(),true,tries+1); return; }
          h.pub(base+'/h','1',true); RV.code=code; RV.st='ok';
        },1200);
      },
      onMsg:function(t,m){
        if(t===base+'/h'){ if(!RV.code&&m) taken=true; return; }
        if(t===base+'/q'&&m.length<5000) rvRequest(mq,base,m);
      }});
    RV.mq=mq; if(!fresh) RV.code=code;
  };
  run(rvPick(),true,0);
}
function rvRequest(mq,base,m){
  let r; try{ r=JSON.parse(m); }catch(e){ return; }
  if(!r||typeof r.tok!=='string'||!/^[a-z0-9]{4,12}$/.test(r.tok)) return;
  const tok=r.tok,reply=function(x){ mq.pub(base+'/o/'+tok,x); };
  if(r.k==='j'){
    if(RV.slots.has(tok)) return;
    if(!LR.room) return reply(JSON.stringify({err:'HOST IS NOT READY'}));
    if(LR.room.state!=='lobby') return reply(JSON.stringify({err:'MATCH ALREADY STARTED'}));
    let pend=0; for(const sl of RV.slots.values()) if(!sl.conn) pend++;
    if(LR.room.players.size+pend>=NET.max) return reply(JSON.stringify({err:'ROOM FULL ('+NET.max+' PLAYERS)'}));
    if(pend>=RVC.pendingMax) return reply(JSON.stringify({err:'HOST IS BUSY - TRY AGAIN'}));
    RV.slots.set(tok,{pending:1});
    pairOffer().then(function(o){
      if(!RV.slots.has(tok)){ try{ o.slot.pc.close(); }catch(e){} return; }
      RV.slots.set(tok,o.slot);
      o.slot.onUp=function(){ RV.slots.delete(tok); sfx('score'); };
      reply(o.code);
      setTimeout(function(){ const sl=RV.slots.get(tok); if(sl===o.slot&&!sl.conn){ try{ sl.pc.close(); }catch(e){} RV.slots.delete(tok); } },RVC.pendingMs);
    }).catch(function(){ RV.slots.delete(tok); });
  } else if(r.k==='a'&&typeof r.c==='string'&&r.c.length<4000){
    const sl=RV.slots.get(tok); if(sl&&sl.pc) pairAccept(sl,r.c).catch(function(){});
  }
}
/* ----- friend: type the code ----- */
function rvCancel(){ if(RV.cancel){ const c=RV.cancel; RV.cancel=null; c(); } RV.busy=0; }
function rvJoin(code){
  if(RV.busy||!hasRTC()){ if(!hasRTC()) MP.msg='THIS BROWSER CANNOT CONNECT'; return; }
  RV.busy=1; MP.msg='CONNECTING...';
  const base=rvBase(code),tok=Math.random().toString(36).slice(2,10).replace(/[^a-z0-9]/g,'x');
  let phase=0,mq=null,timer=0,pc=null;
  const end=function(){ clearTimeout(timer); RV.busy=0; RV.cancel=null; if(mq){ mq.close(); mq=null; } };
  const fail=function(m){ if(!RV.busy) return; if(pc){ try{ pc.close(); }catch(e){} } end(); MP.msg=m; sfx('hit'); };
  RV.cancel=function(){ if(pc&&!NET.ws){ try{ pc.close(); }catch(e){} } clearTimeout(timer); if(mq){ mq.close(); mq=null; } };
  mq=mqOpen({urls:RVC.brokers,
    onFail:function(){ fail('NO INTERNET - ASK HOST TO USE OFFLINE CODES'); },
    onDown:function(){ if(phase<3) fail('CONNECTION LOST - TRY AGAIN'); },
    onReady:function(h){
      h.sub(base+'/o/'+tok); h.sub(base+'/h');
      MP.msg='LOOKING FOR ROOM '+code+'...';
      timer=setTimeout(function(){ fail('NO ROOM WITH THAT CODE'); },RVC.findMs);
    },
    onMsg:function(t,m){
      if(!RV.busy) return;
      if(t===base+'/h'&&phase===0&&m){
        phase=1; clearTimeout(timer); MP.msg='ROOM FOUND - JOINING...';
        mq.pub(base+'/q',JSON.stringify({k:'j',tok:tok}));
        timer=setTimeout(function(){ fail('HOST DID NOT ANSWER'); },RVC.answerMs);
      } else if(t===base+'/o/'+tok&&phase===1){
        if(m.slice(0,2)!=='PR'){ let e='COULD NOT JOIN'; try{ e=String(JSON.parse(m).err||e).slice(0,40); }catch(x){} return fail(e); }
        phase=2; clearTimeout(timer);
        pairAnswer(m).then(function(a){
          if(!RV.busy){ try{ a.pc.close(); }catch(e){} return; }
          pc=a.pc; phase=3;
          mq.pub(base+'/q',JSON.stringify({k:'a',tok:tok,c:a.code}));
          timer=setTimeout(function(){ fail('COULD NOT CONNECT - SAME HOTSPOT?'); },RVC.linkMs);
          a.ready.then(function(ws){
            if(!RV.busy){ try{ ws.close(); }catch(e){} return; }
            pc=null; end(); MP.msg=''; pairAttachReady(ws);
          }).catch(function(e){ fail((e&&e.message)||'FAILED'); });
        }).catch(function(e){ fail((e&&e.message)||'FAILED'); });
      }
    }});
}

/* ================= lobby screens ================= */
const R_MPADDR=[236,52,72,12],R_MPHOST=[70,68,180,20],R_MPJOIN=[70,92,180,20],R_MPMETH=[70,32,180,14],R_MPADD=[172,98,136,16];
const R_MPMODE=[172,26,136,16],R_MPMAP=[172,46,136,16],R_MPGO=[172,70,136,22];
const ADDR_ROWS=['1234567890','.:'],ADDR_R=[];
ADDR_ROWS.forEach(function(row,ri){ for(let ci=0;ci<row.length;ci++) ADDR_R.push({ch:row[ci],r:[22+ci*28,62+ri*19,24,15]}); });
ADDR_R.push({ch:'DEL',r:[22+8*28,62+19,52,15]});
function openMP(){ if(NET.on){ state='mp'; MP.view='lobby'; return; } state='mp'; MP.view='start'; MP.msg=''; sfx('pick'); }
function openAddr(){ MP.addrBuf=SV.mpAddr||mpDefaultAddr(); MP.view='addr'; sfx('pick'); }
function addrDone(){
  const v=MP.addrBuf.trim();
  SV.mpAddr=(v&&v!==mpDefaultAddr())?v:''; persist();
  MP.view='start'; MP.msg=''; sfx('score');
}
function mpKey(k){
  if(k==='Escape'){ if(MP.view==='lobby') mpLeave(); else if(MP.view==='addr') MP.view='start'; else if(MP.view==='room'){ rvCancel(); MP.view='start'; MP.msg=''; } else state='menu'; return; }
  if(MP.view==='room'){
    if(k==='Backspace') MP.roomBuf=MP.roomBuf.slice(0,-1);
    else if(k==='Enter') roomGo();
    else if(k.length===1&&/[0-9]/.test(k)&&MP.roomBuf.length<RVC.len){ MP.roomBuf+=k; if(MP.roomBuf.length===RVC.len) roomGo(); }
    return;
  }
  if(MP.view==='addr'){
    if(k==='Enter') addrDone();
    else if(k==='Backspace') MP.addrBuf=MP.addrBuf.slice(0,-1);
    else if(k.length===1&&/[0-9.:]/.test(k)&&MP.addrBuf.length<21) MP.addrBuf+=k;
  }
}
function roomGo(){ if(RV.busy) return; if(MP.roomBuf.length!==RVC.len){ MP.msg='TYPE THE '+RVC.len+' DIGIT CODE'; return; } rvJoin(MP.roomBuf); }
function mpClick(x,y){
  if(inR(x,y,R_BACK)){ if(MP.view==='lobby') mpLeave(); else if(MP.view==='addr') MP.view='start'; else if(MP.view==='room'){ rvCancel(); MP.view='start'; MP.msg=''; } else state='menu'; sfx('pick'); return; }
  if(MP.view==='start'){
    if(inR(x,y,R_MPMETH)){ const ord=nat()?['server','code','pair']:['code','pair','server']; SV.mpMethod=ord[(ord.indexOf(pairMethod())+1)%3]; persist(); MP.msg=''; sfx('pick'); }
    else if(inR(x,y,R_MPADDR)&&pairMethod()==='server') openAddr();
    else if(inR(x,y,R_MPHOST)){ sfx('pick'); mpConnect('host'); }
    else if(inR(x,y,R_MPJOIN)){ sfx('pick'); mpConnect('join'); }
  } else if(MP.view==='room'){
    if(inR(x,y,R_NAMEOK)){ roomGo(); return; }
    for(const q of ADDR_R){ if(inR(x,y,q.r)&&(q.ch==='DEL'||/[0-9]/.test(q.ch))){
      if(q.ch==='DEL') MP.roomBuf=MP.roomBuf.slice(0,-1); else if(MP.roomBuf.length<RVC.len&&!RV.busy){ MP.roomBuf+=q.ch; if(MP.roomBuf.length===RVC.len) roomGo(); }
      sfx('pick'); return; } }
  } else if(MP.view==='addr'){
    if(inR(x,y,R_NAMEOK)){ addrDone(); return; }
    for(const q of ADDR_R){ if(inR(x,y,q.r)){ if(q.ch==='DEL') MP.addrBuf=MP.addrBuf.slice(0,-1); else if(MP.addrBuf.length<21) MP.addrBuf+=q.ch; sfx('pick'); return; } }
  } else if(MP.view==='lobby'&&NET.host){
    if(inR(x,y,R_MPMODE)){ MP.mode=MP.mode==='dm'?'td':'dm'; MP.mapPos=0; mpSendCfg(); sfx('pick'); }
    else if(inR(x,y,R_MPMAP)){ const n=mapIdxs(MP.mode).length+1; MP.mapPos=(MP.mapPos+1)%n; mpSendCfg(); sfx('pick'); }
    else if(inR(x,y,R_MPGO)) mpStart();
    else if(inR(x,y,R_MPADD)&&LR.room&&(pairMethod()==='pair'||(pairMethod()==='code'&&RV.st==='fail'))) pairHostAddUI();
  }
}
function drawMP(){
  ctx.fillStyle='rgba(10,8,25,0.92)'; ctx.fillRect(UI.x0,UI.y0,UI.w,UI.h);
  txt('MULTIPLAYER',12,6,'#ffdd55','left',16);
  btn(R_BACK,MP.view==='lobby'?'LEAVE':'BACK',false);
  if(MP.view==='start'){
    const addr=mpAddr(),pmm=pairMethod(),pm=pmm!=='server',auto=!!nat()&&!SV.mpAddr;
    txt('HOTSPOT / WI-FI - UP TO 10 PLAYERS',160,22,'#c9c4ff','center');
    btn(R_MPMETH,'CONNECT: '+(pmm==='code'?'ROOM CODE':(pmm==='pair'?'OFFLINE CODES':(nat()?'APP AUTO':'SERVER'))),false);
    if(!pm){ txt('SERVER',20,54,'#8f8bb0'); txt(auto?'AUTO':(addr||'NOT SET'),62,54,(auto||addr)?'#ffffff':'#ff8a8a'); btn(R_MPADDR,'CHANGE',false); }
    btn(R_MPHOST,'HOST A GAME',true); btn(R_MPJOIN,'JOIN A GAME',false);
    if(MP.msg) txt(MP.msg,160,118,'#ffd23f','center');
    if(pmm==='code'){
      txt('HOST TAPS HOST AND GETS A CODE',160,134,'#8f8bb0','center');
      txt('FRIENDS TAP JOIN AND TYPE THE CODE',160,144,'#8f8bb0','center');
      txt('EVERYONE ON THE SAME HOTSPOT',160,154,'#8f8bb0','center');
      txt('NEEDS INTERNET (HOTSPOT DATA) TO CONNECT',160,164,'#8f8bb0','center');
    } else if(pm){
      txt('HOST TAPS HOST, THEN ADD PLAYER',160,134,'#8f8bb0','center');
      txt('FRIENDS TAP JOIN AND PASTE THE CODE',160,144,'#8f8bb0','center');
      txt('SEND CODES BY WHATSAPP OR ANY CHAT',160,154,'#8f8bb0','center');
      txt('ALL ON THE SAME HOTSPOT OR WI-FI',160,164,'#8f8bb0','center');
    } else if(auto){
      txt('TURN ON A HOTSPOT ON ONE DEVICE',160,134,'#8f8bb0','center');
      txt('EVERYONE ELSE JOINS THAT HOTSPOT',160,144,'#8f8bb0','center');
      txt('ONE TAPS HOST, THE REST TAP JOIN',160,154,'#8f8bb0','center');
      txt('THE HOST SCREEN STAYS ON AUTOMATICALLY',160,164,'#8f8bb0','center');
    } else {
      txt('ONE DEVICE RUNS  node server.js',160,134,'#8f8bb0','center');
      txt('EVERYONE OPENS THE ADDRESS IT PRINTS',160,144,'#8f8bb0','center');
      txt('ONE TAPS HOST, THE REST TAP JOIN',160,154,'#8f8bb0','center');
      txt('KEEP THE HOST SCREEN ON DURING A MATCH',160,164,'#8f8bb0','center');
    }
  } else if(MP.view==='room'){
    txt('TYPE THE ROOM CODE',160,24,'#c9c4ff','center');
    ctx.fillStyle='#1d1740'; ctx.fillRect(100,34,120,20);
    ctx.fillStyle='#8a7cf0'; ctx.fillRect(100,34,120,1); ctx.fillRect(100,53,120,1); ctx.fillRect(100,34,1,20); ctx.fillRect(219,34,1,20);
    txt(MP.roomBuf+((Math.floor(menuT*2)%2)&&MP.roomBuf.length<RVC.len?'_':''),160,40,'#ffffff','center',16);
    for(const q of ADDR_R) if(q.ch==='DEL'||/[0-9]/.test(q.ch)) btn(q.r,q.ch,false);
    btn(R_NAMEOK,RV.busy?'WAIT...':'JOIN',true);
    if(MP.msg) txt(MP.msg,160,122,'#ffd23f','center');
    txt('THE HOST SEES THE CODE IN THE LOBBY',160,150,'#8f8bb0','center');
    txt('SAME HOTSPOT AS THE HOST',160,160,'#8f8bb0','center');
  } else if(MP.view==='addr'){
    txt('SERVER ADDRESS  (IP:PORT)',160,24,'#c9c4ff','center');
    ctx.fillStyle='#1d1740'; ctx.fillRect(60,34,200,20);
    ctx.fillStyle='#8a7cf0'; ctx.fillRect(60,34,200,1); ctx.fillRect(60,53,200,1); ctx.fillRect(60,34,1,20); ctx.fillRect(259,34,1,20);
    txt(MP.addrBuf+((Math.floor(menuT*2)%2)&&MP.addrBuf.length<21?'_':''),160,40,'#ffffff','center');
    for(const q of ADDR_R) btn(q.r,q.ch,false);
    btn(R_NAMEOK,'OK - SAVE',true);
    txt('EXAMPLE  192.168.43.1:8080',160,122,'#8f8bb0','center');
    txt('EMPTY = USE THE PAGE ADDRESS',160,164,'#8f8bb0','center');
  } else {
    const ro=NET.roster||[],td=MP.mode==='td';
    txt('PLAYERS '+ro.length+'/'+NET.max,16,24,'#c9c4ff');
    const hs=ro.slice().sort(function(a,b){ return a.id-b.id; });
    for(let i=0;i<NET.max;i++){
      const y=34+i*11,r=hs[i];
      if(r){
        ctx.fillStyle=td?(i%2===0?'#38b6ff':'#ff4d5e'):'#4ade80'; ctx.fillRect(16,y,6,7);
        txt(String(r.name||'?')+(r.host?'  HOST':'')+(r.id===NET.id?'  YOU':''),28,y,'#ffffff');
      } else { ctx.fillStyle='#3a3366'; ctx.fillRect(16,y,6,7); txt('EMPTY SLOT',28,y,'#5d58a0'); }
    }
    if(NET.host){
      btn(R_MPMODE,'MODE: '+(td?'TOUCHDOWN 5V5':'DEATHMATCH'),false);
      btn(R_MPMAP,'MAP: '+mpMapLabel(),false);
      btn(R_MPGO,'START MATCH',true);
      if(MP.msg) txt(MP.msg,240,140,'#ffd23f','center');
      if(pairMethod()==='code'){
        txt('ROOM CODE',240,96,'#8f8bb0','center');
        if(RV.st==='ok'&&RV.code) txt(RV.code,240,106,'#ffdd55','center',24);
        else if(RV.st==='fail') txt('NO INTERNET',240,106,'#ff8a8a','center');
        else txt('...',240,106,'#c9c4ff','center');
        if(RV.st==='fail'){ btn(R_MPADD,'ADD PLAYER (OFFLINE)',false); txt('OR SWITCH TO OFFLINE CODES',240,120,'#8f8bb0','center'); }
        else { txt('FRIENDS TAP JOIN, TYPE IT',240,124,'#8f8bb0','center'); txt('NO BOTS - REAL PLAYERS ONLY',240,134,'#8f8bb0','center'); }
      } else if(pairMethod()==='pair'){
        btn(R_MPADD,'ADD PLAYER (CODE)',false);
        txt('ONE CODE PER FRIEND',240,120,'#8f8bb0','center');
        txt('NO BOTS - REAL PLAYERS ONLY',240,130,'#8f8bb0','center');
      } else {
        txt('NO BOTS - REAL PLAYERS ONLY',240,102,'#8f8bb0','center');
        txt('PLAYERS JOIN BY TAPPING JOIN',240,112,'#8f8bb0','center');
        txt('ON THE SAME ADDRESS',240,122,'#8f8bb0','center');
      }
    } else {
      txt('WAITING FOR THE HOST...',240,36,'#ffd23f','center');
      txt(MP.mode==='td'?'TOUCHDOWN 5V5':'DEATHMATCH',240,56,'#ffffff','center');
      txt('MAP: '+(MP.mapName||'?'),240,68,'#c9c4ff','center');
    }
    txt(NET.host?'YOU ARE THE HOST':'PING '+NET.rtt+' MS',240,150,'#8f8bb0','center');
  }
}

/* ================= drawing ================= */
/* Text: big sizes are compressed so titles/banners stay readable but never dominate the screen.
   8 -> 5.6px, 16 -> ~7.6px, 24 -> ~9.5px (logical px, canvas is 2x). */
const TXC=new Map(),TXSEEN=new Set();
function txtDirect(str,x,y,c,al,eff){
  ctx.font=eff+'px '+FONT; ctx.textBaseline='top'; ctx.textAlign=al;
  const o=Math.max(0.6,eff/9);
  ctx.fillStyle='rgba(0,0,0,0.85)'; ctx.fillText(str,x+o,y+o);
  ctx.fillText(str,x+o,y); ctx.fillText(str,x,y+o);
  ctx.fillStyle=c; ctx.fillText(str,x,y);
}
function txtFontReady(){ try{ return !document.fonts||typeof document.fonts.check!=='function'||document.fonts.check('8px "Press Start 2P"'); }catch(e){ return true; } }
if(document.fonts&&document.fonts.addEventListener){ try{ document.fonts.addEventListener('loadingdone',function(){ TXC.clear(); TXSEEN.clear(); }); }catch(e){} }
function txtBuild(str,c,al,eff,ts){
  const cvs=document.createElement('canvas'),x2=cvs.getContext('2d'),fp=eff*ts,o=Math.max(0.6,eff/9)*ts;
  x2.font=fp+'px '+FONT;
  const tw=Math.ceil(x2.measureText(str).width),pad=Math.ceil(o)+2;
  cvs.width=tw+pad*2; cvs.height=Math.ceil(fp*1.3)+pad*2;
  x2.font=fp+'px '+FONT; x2.textBaseline='top'; x2.textAlign='left';
  x2.fillStyle='rgba(0,0,0,0.85)'; x2.fillText(str,pad+o,pad+o); x2.fillText(str,pad+o,pad); x2.fillText(str,pad,pad+o);
  x2.fillStyle=c; x2.fillText(str,pad,pad);
  return {cv:cvs,pad:pad,tw:tw};
}
function txt(s,x,y,c,al,size){
  const sz=size||8,eff=(sz<=8?sz:8+(sz-8)*0.35)*TS; al=al||'left';
  if(PERF.textCache){
    const m=ctx.getTransform?ctx.getTransform():null;
    if(m&&m.a){
      const ts=Math.max(0.5,Math.round(Math.hypot(m.a,m.b)*10)/10);
      const key=ts+'|'+eff+'|'+al+'|'+c+'|'+s;
      let e=TXC.get(key);
      if(!e){
        /* only cache a string the second time it is seen, so text that changes every frame never thrashes */
        if(TXSEEN.has(key)&&txtFontReady()){
          e=txtBuild(s,c,al,eff,ts);
          if(TXC.size>700){ let n=0; for(const k of TXC.keys()){ TXC.delete(k); if(++n>150) break; } }
          TXC.set(key,e);
        } else { if(TXSEEN.size>3000) TXSEEN.clear(); TXSEEN.add(key); }
      }
      if(e){
        const k=1/ts,ax=al==='center'?e.pad+e.tw/2:(al==='right'?e.pad+e.tw:e.pad);
        ctx.drawImage(e.cv,x-ax*k,y-e.pad*k,e.cv.width*k,e.cv.height*k);
        return;
      }
    }
  }
  txtDirect(s,x,y,c,al,eff);
}
function pixCircle(cx,cy,r,c){
  ctx.fillStyle=c;
  for(let dy=-r;dy<=r;dy++){ const w=Math.floor(Math.sqrt(r*r-dy*dy+r*0.6)); ctx.fillRect(cx-w,cy+dy,w*2,1); }
}
/* rel: 0 = you (gold), 1 = ally (green), 2 = enemy (red) */
function relColor(f){ return f.rel===0?'#ffe066':(f.rel===1?'#4ade80':'#ff4d5e'); }
function drawRelRing(f){
  const x=Math.round(f.x),y=Math.round(f.y)+1,c=relColor(f),w=f.rel===0?(Math.floor(time*4)%2?10:9):8;
  ctx.globalAlpha=f.rel===0?0.85:0.55; ctx.fillStyle=c;
  ctx.fillRect(x-w,y,w*2,1); ctx.fillRect(x-w+2,y+1,w*2-4,1); ctx.globalAlpha=1;
}
/* ---------- the Reaper: a hooded spirit that haunts the Chaser (skinnable) ---------- */
function updateReaper(dt){
  if(mode!=='ch'||!chaser||!reaper) return;
  const c=chaser,r=reaper; r.t+=dt;
  const tx=c.x-c.face*17,ty=c.y-28+Math.sin(r.t*3)*3,k=Math.min(1,dt*(c.dashT>0?12:5));
  r.x+=(tx-r.x)*k; r.y+=(ty-r.y)*k;
  if(r.hist){ r.hist.unshift([r.x,r.y]); if(r.hist.length>14) r.hist.length=14; }
  if(c.dashT>0&&Math.random()<0.8){ const rs=r.sk||REAPERS.rp_shadow; parts.push({x:r.x+(Math.random()-0.5)*10,y:r.y+(Math.random()-0.5)*12,vx:-c.face*30,vy:(Math.random()-0.5)*20,life:0.4,max:0.4,c:rs.haze,s:2,g:0}); }
  r.atk=c.swing>0?1-c.swing/(c.swingDur||0.15):0;
  const tr=(r.sk||REAPERS.rp_shadow).trail;
  if(Math.random()<0.5) parts.push({x:r.x+(Math.random()-0.5)*8,y:r.y+9+Math.random()*4,vx:-c.face*10,vy:10+Math.random()*12,life:0.6,max:0.6,c:tr[Math.random()<0.5?0:1],s:1,g:-15});
}
/* draws one Reaper at the current origin, facing +x (used in game and in the shop preview) */
function drawReaperAt(sk,t,atk,a){
  const fl=Math.floor(t*8)%2,tt=Math.floor(t*10);
  const OLC='#07040c',BONE='#e8e4d8',BONED='#b8b098';
  const robeD=mdark(sk.robe,0.6),robeL=mlit(sk.robe,0.18),innerD=mdark(sk.inner,0.55);
  ctx.globalAlpha=0.16*a; pixCircle(0,0,14,sk.haze); ctx.globalAlpha=0.07*a; pixCircle(0,0,19,sk.haze); ctx.globalAlpha=1;
  const sway=function(i,k){ return Math.round(Math.sin(t*4.2+i*0.55+k)*(i/14)*1.6); };
  /* everything except glows is drawn by paint(); it runs 4x in the outline colour, then once in colour */
  const paint=function(R,ol){
    const G=function(c){ return ol?OLC:c; };
    /* robe: tapered, with side light, fold lines and a ragged hem that waves */
    for(let i=0;i<14;i++){
      const w=4+Math.floor(i*0.36),sx=sway(i,0);
      R(-w+sx,i,w*2,1,G(sk.robe)); R(-w+sx,i,1,1,G(sk.hi)); R(w-1+sx,i,1,1,G(robeD));
      if(i>5&&!ol){ R(-2+sx,i,1,1,G(robeD)); if(i>8) R(2+sx,i,1,1,G(robeD)); }
    }
    for(let k=-9;k<=9;k+=3){ const hh=2+((k+fl*3+18)%4),sx=sway(14,k); R(k+sx,14,2,hh,G(k&1?sk.robe:robeD)); R(k+sx,14,1,1,G(sk.hi)); }
    R(-5,7,10,1,G(sk.band)); R(-5,8,10,1,G(robeD)); R(1,7,2,3,G(sk.band)); R(1,9,1,2,G(robeD));
    /* shoulders / cape */
    R(-7,-1,5,4,G(sk.robe)); R(-7,-1,5,1,G(sk.hi)); R(-8,0,1,3,G(sk.rim)); R(4,-1,4,3,G(sk.robe)); R(4,-1,4,1,G(sk.hi));
    /* sleeve + bony hand holding the scythe */
    R(3,1,6,3,G(sk.inner)); R(3,1,6,1,G(sk.hi)); R(8,2,4,3,G(BONE)); R(8,2,4,1,G('#ffffff')); R(9,4,1,2,G(BONED)); R(11,3,1,2,G(BONED)); R(10,5,1,1,G(BONED));
    /* hood: peaked, deep and with a bright rim */
    R(-6,-9,12,9,G(sk.inner)); R(-5,-12,10,3,G(sk.inner)); R(-3,-14,6,2,G(sk.inner)); R(-1,-16,3,2,G(sk.inner)); R(1,-17,2,1,G(sk.inner));
    R(-6,-9,1,9,G(sk.rim)); R(-5,-12,1,3,G(sk.rim)); R(-3,-14,2,1,G(sk.rim)); R(-1,-16,2,1,G(sk.rim)); R(-3,-3,2,1,G(sk.rim));
    R(5,-9,1,9,G(innerD)); R(4,-12,1,3,G(innerD));
    if(!ol){ R(-4,-8,9,1,innerD); }
    /* face in the shadow of the hood */
    if(!ol){
      if(sk.face==='skull'){
        R(0,-9,6,7,'#07040c'); R(1,-9,5,6,BONE); R(1,-9,5,1,'#ffffff'); R(5,-8,1,5,BONED); R(0,-7,1,3,innerD);
        R(1,-7,2,3,'#07040c'); R(4,-7,2,3,'#07040c'); R(2,-6,1,1,sk.eye); R(5,-6,1,1,sk.eye); R(2,-7,1,1,sk.eyeHi);
        R(3,-5,1,1,'#7a7468'); R(1,-3,5,1,BONED); R(2,-3,1,1,'#07040c'); R(4,-3,1,1,'#07040c'); R(3,-2,1,1,BONED);
      } else if(sk.face==='beak'){
        R(0,-9,6,7,'#050309'); R(1,-9,4,4,sk.rim); R(1,-9,4,1,mlit(sk.rim,0.4)); R(2,-7,2,2,'#050309'); R(2,-7,1,1,sk.eye); R(3,-7,1,1,sk.eyeHi);
        R(5,-6,5,2,sk.band); R(5,-6,5,1,mlit(sk.band,0.35)); R(9,-5,2,1,sk.band); R(9,-4,1,2,'#8a7a50'); R(5,-4,3,1,'#8a7a50');
      } else {
        R(0,-9,6,7,'#050309'); ctx.globalAlpha=0.28*a; R(0,-9,7,5,sk.eye); ctx.globalAlpha=1;
        R(1,-7,2,2,sk.eye); R(1,-7,1,1,sk.eyeHi); R(4,-7,2,2,sk.eye); R(4,-7,1,1,sk.eyeHi); R(1,-3,5,1,'#cfc8b0'); R(2,-3,1,1,'#050309'); R(4,-3,1,1,'#050309');
      }
    }
    /* scythe: wrapped pole and a curved, edged blade */
    ctx.save(); ctx.translate(9,4); ctx.rotate(-0.35+atk*2.0);
    R(-1,-20,3,34,G(OLC)); R(0,-19,1,32,G(sk.pole)); R(1,-19,1,32,G(mdark(sk.pole,0.6)));
    for(let k=-8;k<=8;k+=8) R(-1,k,3,1,G(sk.band));
    R(-1,12,3,2,G('#cfd6e6'));
    if(ol){ for(let k=0;k<12;k++){ const x=k+1,y=-22+Math.round(k*k*0.075); R(x-1,y-1,3,4,OLC); } }
    else {
      for(let k=0;k<12;k++){
        const x=k+1,y=-22+Math.round(k*k*0.075),th=Math.max(1,3-Math.floor(k/4));
        R(x,y,2,th+1,sk.blade); R(x,y,2,1,sk.edge); if(th>1) R(x,y+th,2,1,mdark(sk.blade,0.6));
      }
      R(-1,-22,3,3,sk.blade); R(0,-23,2,1,sk.edge); R(-1,-22,1,3,sk.edge);
      const gk=Math.floor((t*9)%16); if(gk<12){ const gy=-22+Math.round(gk*gk*0.075); R(gk+1,gy,1,1,'#ffffff'); }
      if(sk.fx==='fire'){ for(let k=0;k<6;k++){ const h=(k+fl)%3; R(2+k*2,-25-h+Math.round(k*k*0.2),1+(k&1),2+h,['#ff5a1f','#ffb02e','#fff3b0'][(k+fl)%3]); } }
      else if(sk.fx==='ice'){ R(2+((tt*3)%9),-24,1,1,'#ffffff'); R(10,-16+((tt*2)%4),1,1,'#ffffff'); }
      R(-1,-1,3,3,BONE); R(-1,-1,3,1,'#ffffff');
    }
    ctx.restore();
  };
  const OR=function(x,y,w,h,c){ ctx.fillStyle=OLC; ctx.fillRect(x,y,w,h); };
  const CR=function(x,y,w,h,c){ ctx.fillStyle=c; ctx.fillRect(x,y,w,h); };
  ctx.globalAlpha=0.95*a;
  for(const d of [[-1,0],[1,0],[0,-1],[0,1]]){ ctx.save(); ctx.translate(d[0],d[1]); paint(OR,true); ctx.restore(); }
  paint(CR,false);
  /* eye bloom */
  { const pu=0.55+0.45*Math.sin(t*5); ctx.globalAlpha=0.35*pu*a; pixCircle(3,-6,4,sk.eye); ctx.globalAlpha=0.5*pu*a; CR(1,-7,2,2,sk.eye); CR(4,-7,2,2,sk.eye); }
  /* scythe slash arc */
  if(atk>0.02&&atk<0.98){
    const a1=-Math.PI/2-0.35,a2=-Math.PI/2-0.35+atk*2.0;
    ctx.save(); ctx.translate(9,4); ctx.lineCap='butt';
    const arcs=[[24,5,0.35,sk.trail[0]],[24,3,0.7,sk.trail[1]],[24,1,1,'#ffffff']];
    for(const A of arcs){ ctx.globalAlpha=A[2]*(1-atk*0.6)*a; ctx.strokeStyle=A[3]; ctx.lineWidth=A[1]; ctx.beginPath(); ctx.arc(0,0,A[0],Math.max(a1,a2-1.5),a2); ctx.stroke(); }
    ctx.restore(); ctx.globalAlpha=0.95*a;
  }
  /* robe effects */
  ctx.globalAlpha=0.95*a;
  if(sk.fx==='stars'){ for(let k=0;k<7;k++) CR(-5+((k*5)%9),1+((k*3)%12),1,1,(fl+k)%2?'#ffffff':sk.eye); }
  else if(sk.fx==='ice'){ CR(-6,13,1,3,sk.rim); CR(-2,14,1,4,sk.rim); CR(3,14,1,3,sk.rim); CR(6,13,1,3,sk.rim); CR(-7+((tt*5)%14),-6+((tt*7)%18),1,1,'#ffffff'); }
  else if(sk.fx==='toxic'){ for(let k=0;k<4;k++) CR(-5+k*4,12-((tt+k*4)%12),1,1,'#b8ff8a'); }
  else if(sk.fx==='blood'){ for(const k of [-6,-1,4]) CR(k,16+((tt+k+8)%5),1,2,'#ff2a3a'); }
  else if(sk.fx==='fire'){ for(let k=-9;k<=9;k+=3) CR(k,13-((k+fl*3+18)%3),2,3,(k+fl)&1?'#ff7a1f':'#ffd23f'); CR(-3,-19-fl,1,3,'#ff7a1f'); CR(0,-20,1,3,'#ffd23f'); CR(2,-19-fl,1,3,'#ff7a1f'); }
  else if(sk.fx==='halo'){ CR(-3,-22,7,1,'#ffd23f'); CR(-4,-21,1,1,'#ffd23f'); CR(4,-21,1,1,'#ffd23f'); CR(-3,-20,7,1,'#c9992a'); }
  ctx.globalAlpha=1;
}
function drawReaper(){
  if(mode!=='ch'||!chaser||!reaper||chaser.dead) return;
  const r=reaper,c=chaser,a=Math.min(1,r.t/1.0),sc=1.1*(0.5+0.5*a);
  /* afterimages while the chaser dashes or swings */
  if(r.hist&&(c.dashT>0||r.atk>0)){
    for(let g=3;g>=1;g--){ const h=r.hist[g*3]; if(!h) continue; ctx.save(); ctx.translate(Math.round(h[0]),Math.round(h[1])); ctx.scale(c.face*sc,sc); ctx.globalAlpha=0.16*(4-g)/3*a; ctx.fillStyle=(r.sk||REAPERS.rp_shadow).haze; ctx.fillRect(-7,-14,14,28); ctx.restore(); }
    ctx.globalAlpha=1;
  }
  /* orbiting souls */
  { const rs=r.sk||REAPERS.rp_shadow;
    for(let k=0;k<4;k++){
      const an=r.t*2.2+k*1.5708,ox=Math.cos(an)*17,oy=Math.sin(an)*7-2+Math.sin(r.t*3+k)*2,front=Math.sin(an)>0;
      if(front) continue;
      ctx.globalAlpha=0.5*a; ctx.fillStyle=rs.haze; ctx.fillRect(Math.round(r.x+ox),Math.round(r.y+oy),2,2); ctx.fillStyle='#ffffff'; ctx.fillRect(Math.round(r.x+ox),Math.round(r.y+oy),1,1);
      for(let tl=1;tl<4;tl++){ const a2=an-tl*0.18; ctx.globalAlpha=(0.35-tl*0.09)*a; ctx.fillStyle=rs.haze; ctx.fillRect(Math.round(r.x+Math.cos(a2)*17),Math.round(r.y+Math.sin(a2)*7-2+Math.sin(r.t*3+k)*2),1,1); }
    }
    ctx.globalAlpha=1; }
  ctx.save(); ctx.translate(Math.round(r.x),Math.round(r.y)); ctx.scale(c.face*sc,sc);
  drawReaperAt(r.sk||REAPERS.rp_shadow,r.t,r.atk,a);
  ctx.restore(); ctx.globalAlpha=1;
  { const rs=r.sk||REAPERS.rp_shadow;
    for(let k=0;k<4;k++){
      const an=r.t*2.2+k*1.5708,ox=Math.cos(an)*17,oy=Math.sin(an)*7-2+Math.sin(r.t*3+k)*2;
      if(Math.sin(an)<=0) continue;
      ctx.globalAlpha=0.85*a; ctx.fillStyle=rs.haze; ctx.fillRect(Math.round(r.x+ox),Math.round(r.y+oy),2,2); ctx.fillStyle='#ffffff'; ctx.fillRect(Math.round(r.x+ox),Math.round(r.y+oy),1,1);
      for(let tl=1;tl<4;tl++){ const a2=an-tl*0.18; ctx.globalAlpha=(0.5-tl*0.12)*a; ctx.fillStyle=rs.haze; ctx.fillRect(Math.round(r.x+Math.cos(a2)*17),Math.round(r.y+Math.sin(a2)*7-2+Math.sin(r.t*3+k)*2),1,1); }
    }
    ctx.globalAlpha=1; }
}
function drawAura(f){
  const x=Math.round(f.x),y=Math.round(f.y)-8;
  if(TICK&&state==='play'&&!paused&&Math.random()<0.55) parts.push({x:f.x+f.face*(4+Math.random()*9),y:f.y-34+Math.random()*10,vx:(Math.random()-0.5)*14,vy:-26-Math.random()*26,life:0.5,max:0.5,c:Math.random()<0.5?'#ff8a2e':'#ffd23f',s:1,g:-30});
  for(let k=0;k<8;k++){ const a=time*3+k*0.785; ctx.fillStyle=k%2?'#ff4d5e':'#ffb02e'; ctx.fillRect(Math.round(x+Math.cos(a)*13),Math.round(y+Math.sin(a)*11),2,2); }
  if(TICK&&state==='play'&&!paused&&Math.random()<0.3) parts.push({x:f.x+(Math.random()-0.5)*8,y:f.y-16,vx:(Math.random()-0.5)*20,vy:-30-Math.random()*30,life:0.4,max:0.4,c:Math.random()<0.5?'#ff4d5e':'#ffb02e',s:1,g:-30});
}
function drawFighter(f){
  if(f.dead) return;
  const vis=!(f.inv>0&&(Math.floor(f.inv*16)%2));
  if(f.rel===0) drawRelRing(f);
  if(vis){
    if(f.rel>=0){
      f.tint=relColor(f);
      const o=[[-1,0],[1,0],[0,-1],[0,1]];
      for(const d of o) drawBody(f,d[0],d[1]);
      f.tint=null;
    }
    else {
      f.tint='#12111c'; f.noW=true;
      for(const d of [[-1,0],[1,0],[0,-1],[0,1]]) drawBody(f,d[0],d[1]);
      f.tint=null; f.noW=false;
    }
    drawBody(f,0,0);
  }
  if(f.role==='chaser') drawAura(f);
  drawShieldFx(f);
  drawOverlay(f);
}
/* ---------- weapons: ranged ---------- */
const GUN_SCALE_DEF=0.75,GUN_SCALE={minigun:0.62,rocket:0.66,sniper:0.66,rail:0.7,grenade:0.7,plasma:0.7,cluster:0.7,crossbow:0.76,scatter:0.72};
function gunScale(gd){ return GUN_SCALE[gd.id]||GUN_SCALE_DEF; }
function drawGun(f,R0){
  const gd=f.wd[1],ga=f.aimT>0?f.aimA:0,gs=gunScale(gd),kk=gd.kick||1.2,rcv=f.recoil*f.recoil,rc=rcv*kk*0.9+f.recoil*0.5,id=gd.id,fc=gd.bc||'#ffb84d',P=f.pal;
  const moving=f.onGround&&Math.abs(f.vx)>12;
  const bob=f.aimT>0?0:(moving?Math.round(Math.sin(f.anim*12)*0.6):Math.round(Math.sin(f.anim*3)*0.5));
  const climb=-Math.min(0.3,rcv*0.06*kk);
  const R=function(x,y,w,h,c){ const x0=Math.round(x*gs),y0=Math.round(y*gs),x1=Math.round((x+w)*gs),y1=Math.round((y+h)*gs); R0(x0,y0,Math.max(1,x1-x0),Math.max(1,y1-y0),c); };
  const MT='#9aa5c4',DK='#1c1c28',fl=Math.floor(f.anim*10)%2;
  ctx.save(); ctx.translate(2-Math.round(rc),-8+bob); ctx.rotate(ga+climb);
  R0(-1,0,3,2,P.main);
  const OL='#12111c',M0='#262a3e',M1='#4a5170',M2='#7d88ab',M3='#c4cde6',W1='#5a3a1c',W2='#8a5a2c',W3='#b27a42',DKc=DK;
  switch(id){
    case 'dual': {
      const pis=function(y,c1){ R(0,y-2,10,5,OL); R(1,y-1,8,3,c1); R(1,y-1,8,1,M3); R(1,y+1,8,1,M0); R(3,y,1,1,M0); R(9,y-1,1,2,M3); R(2,y+3,4,3,OL); R(3,y+3,2,2,M1); };
      pis(-2,gd.color); pis(2,'#2f4a72'); R(2,0,6,1,fc); break; }
    case 'scatter':
      R(-3,-2,5,5,OL); R(-2,-1,4,3,W2); R(-2,-1,4,1,W3);
      R(0,-3,9,7,OL); R(1,-2,7,5,gd.color); R(1,-2,7,1,'#e0904a'); R(1,2,7,1,'#6a3410'); R(3,-1,1,2,'#6a3410');
      R(8,-4,3,9,OL); R(9,-3,2,7,M0); R(10,-2,1,5,'#000000'); R(9,-3,1,1,M3);
      R(2,4,4,4,OL); R(3,4,2,3,W2); break;
    case 'smg':
      R(-5,-2,6,4,OL); R(-4,-1,5,2,M1); R(-4,-1,5,1,M2);
      R(0,-4,11,7,OL); R(1,-3,9,5,gd.color); R(1,-3,9,1,'#4ac98a'); R(1,1,9,1,'#0f3a24'); R(2,-5,7,1,M1); R(8,-5,1,1,M3);
      R(6,-2,1,3,'#0f3a24'); R(8,-2,1,3,'#0f3a24'); R(10,-2,2,2,M3); R(11,-2,1,1,'#ffffff');
      R(4,3,4,8,OL); R(5,3,2,7,'#0f3a24'); R(5,3,1,7,M1); R(5,9,2,1,fc);
      R(1,3,3,5,OL); R(2,3,1,4,M0); break;
    case 'shotgun':
      R(-5,-2,7,6,OL); R(-4,-1,6,4,W2); R(-4,-1,6,1,W3); R(-4,2,6,1,W1);
      R(1,-3,12,5,OL); R(2,-2,10,1,M3); R(2,-1,10,1,M1); R(2,0,10,1,M0);
      R(1,-3,6,6,OL); R(2,-2,5,4,gd.color); R(2,-2,5,1,'#a8703a');
      R(6,1,6,4,OL); R(7,2,4,2,'#6a3a18'); R(7,2,4,1,W3); R(12,-2,1,2,M3);
      R(3,3,3,3,OL); R(4,3,1,2,M0); break;
    case 'ricochet':
      R(0,-3,9,7,OL); R(1,-2,7,5,gd.color); R(1,-2,7,1,'#58c8d8'); R(1,2,7,1,'#0f3a44');
      R(3,-1,4,3,'#0f3a44'); R(3,-1,1,3,fc); R(5,-1,1,3,fc);
      R(8,-5,3,4,OL); R(8,2,3,4,OL); R(8,-4,2,2,M2); R(8,3,2,2,M2); R(9,-4,1,1,fc); R(9,3,1,1,fc); R(8,-1,3,3,OL); R(9,0,1,1,M3);
      R(2,4,3,4,OL); R(3,4,1,3,M0); break;
    case 'laser':
      R(0,-4,10,8,OL); R(1,-3,8,5,gd.color); R(1,-3,8,1,'#7fe8d0'); R(1,1,8,1,'#0f3a30');
      R(9,-3,2,5,OL); R(9,-2,2,3,fc); R(10,-1,1,1,'#ffffff'); R(3,-5,4,1,M3); R(4,-6,2,1,M3);
      R(3,-1,4,1,fc); R(2,4,3,4,OL); R(3,4,1,3,M0); R(5,1,1,1,fc); break;
    case 'flame':
      R(-7,-5,6,11,OL); R(-6,-4,4,9,'#8a3a1a'); R(-6,-4,1,9,'#d8703a'); R(-6,-5,4,1,'#ffd23f'); R(-3,-4,1,9,'#5a2410'); R(-5,0,2,1,'#ffd23f');
      R(-1,0,3,2,M1); R(1,-3,10,7,OL); R(2,-2,8,5,M1); R(2,-2,8,1,M2); R(2,2,8,1,M0);
      R(9,-2,3,5,OL); R(10,-1,2,3,'#22301f'); R(5,-2,1,5,M0);
      R(11,0,2,1,fl?'#ff8a2e':'#ffd23f'); R(12,-1,1,1,'#ffffff');
      R(3,4,3,4,OL); R(4,4,1,3,M0); break;
    case 'grenade':
      R(1,-6,9,12,OL); R(2,-5,7,10,gd.color); R(2,-5,7,1,'#7ab07a'); R(2,4,7,1,'#1f3a1f');
      R(5,-5,1,10,'#2a3a2a'); R(3,-2,3,4,M0); R(4,-1,1,2,fc);
      R(8,-3,5,6,OL); R(9,-2,4,4,M1); R(9,-2,4,1,M2); R(11,-3,1,6,M3);
      R(2,6,4,4,OL); R(3,6,2,3,M0); R(5,-8,1,2,M3); break;
    case 'rail':
      R(-4,-3,5,6,OL); R(-3,-2,4,4,'#3a2268'); R(-3,-1,2,2,'#7a5ae0');
      R(0,-4,12,8,OL); R(1,-3,10,5,gd.color); R(1,-3,10,1,'#9a7ae0'); R(1,1,10,1,'#2c1a58');
      R(3,-4,1,8,fc); R(6,-4,1,8,fc); R(9,-4,1,8,fc); R(3,-4,1,1,'#ffffff'); R(6,-4,1,1,'#ffffff'); R(9,-4,1,1,'#ffffff');
      R(11,-2,3,4,OL); R(11,-1,2,2,M3); R(13,-1,1,1,'#ffffff');
      R(2,4,3,4,OL); R(3,4,1,3,M0); break;
    case 'rocket':
      R(-6,-5,3,10,OL); R(-5,-4,1,8,M0); R(-4,-4,1,8,M1);
      R(-4,-5,16,10,OL); R(-3,-4,14,8,gd.color); R(-3,-4,14,1,'#c05050'); R(-3,3,14,1,'#3a1414');
      R(0,-4,1,8,'#ffd23f'); R(6,-4,1,8,'#ffd23f'); R(11,-3,2,6,OL); R(11,-2,2,4,'#aa3a2a'); R(13,-1,1,2,'#fff3b0');
      R(3,-8,4,3,OL); R(4,-7,1,1,'#7dffea'); R(3,5,4,4,OL); R(4,5,2,3,M0); break;
    case 'revolver':
      R(4,-3,8,5,OL); R(5,-2,6,1,M3); R(5,-1,6,1,M1); R(11,-4,1,1,M3);
      R(0,-4,7,9,OL); R(1,-3,5,7,M2); R(1,-3,5,1,M3);
      R(2,-4,4,7,OL); R(3,-3,3,5,M1); R(3,-3,3,1,M2); R(4,-2,1,1,OL); R(4,0,1,1,OL); R(5,-1,1,1,OL);
      R(0,-5,2,2,M1); R(-3,2,5,8,OL); R(-2,3,3,6,W2); R(-2,3,1,6,W3); R(1,2,2,1,M0); R(3,2,1,2,M0); break;
    case 'triburst':
      R(-4,-2,5,5,OL); R(-3,-1,4,3,M1); R(-3,-1,4,1,M2);
      R(0,-4,10,8,OL); R(1,-3,8,6,gd.color); R(1,-3,8,1,'#7ac8e8'); R(1,2,8,1,'#1c3a4a');
      R(9,-4,3,8,OL); R(10,-3,2,1,M3); R(10,-1,2,1,M3); R(10,1,2,1,M3); R(10,-2,2,1,M0); R(10,0,2,1,M0);
      R(3,-1,1,1,'#ffd23f'); R(5,-1,1,1,'#ffd23f'); R(7,-1,1,1,'#ffd23f');
      R(3,4,3,5,OL); R(4,4,1,4,M1); R(1,4,2,4,OL); R(1,4,1,3,M0); break;
    case 'sniper':
      R(-7,-3,8,6,OL); R(-6,-2,7,4,gd.color); R(-6,-2,7,1,M1); R(-6,1,7,1,M0);
      R(0,-4,12,7,OL); R(1,-3,10,5,gd.color); R(1,-3,10,1,M1);
      R(11,-3,7,5,OL); R(12,-2,6,2,M2); R(12,-2,6,1,M3); R(12,0,6,1,M0); R(16,-4,2,7,OL); R(16,-3,2,5,M1); R(17,-3,1,5,M2);
      R(3,-8,8,4,OL); R(4,-7,6,2,M2); R(4,-7,6,1,M3); R(3,-7,1,3,fc); R(10,-7,1,3,fc); R(5,-4,1,2,M1); R(9,-4,1,2,M1);
      R(0,-1,3,2,M3); R(12,3,1,5,M0); R(15,3,1,5,M0); R(2,3,3,5,OL); R(3,3,1,4,M0); break;
    case 'needler':
      R(0,-4,9,8,OL); R(1,-3,7,6,gd.color); R(1,-3,7,1,'#e060a8'); R(1,2,7,1,'#601040');
      R(2,-7,6,4,OL); R(3,-6,4,2,'#ff9ee0'); R(3,-6,1,1,'#ffffff'); R(5,-5,1,1,'#fff3fa');
      R(8,-2,3,4,OL); R(8,-1,3,2,M2); R(10,-1,1,1,'#ffffff');
      R(2,4,3,4,OL); R(3,4,1,3,M0); R(5,1,2,1,fc); break;
    case 'crossbow':
      R(-4,-2,12,5,OL); R(-3,-1,10,3,W2); R(-3,-1,10,1,W3); R(-3,1,10,1,W1);
      R(6,-9,4,19,OL); R(7,-8,2,17,W1); R(7,-8,1,17,W2); R(8,-10,3,3,OL); R(9,-9,2,1,M3); R(8,8,3,3,OL); R(9,9,2,1,M3);
      R(2,-8,1,17,'#e6d2a8'); R(1,0,11,1,W1); R(10,-1,2,3,OL); R(10,0,2,1,M3); R(2,3,3,3,OL); R(3,3,1,2,M0); break;
    case 'minigun': {
      const ph=Math.floor(f.anim*30)%4;
      R(-6,-1,6,8,OL); R(-5,0,4,6,'#6a5a2a'); R(-5,0,4,1,'#a08a3a'); R(-1,5,6,1,'#ffcf6a'); R(0,4,6,1,'#ffcf6a');
      R(0,-4,8,9,OL); R(1,-3,6,7,gd.color); R(1,-3,6,1,M2); R(1,3,6,1,M0);
      R(7,-6,8,12,OL); for(let k=0;k<5;k++) R(8,-5+k*2,6,1,((k+ph)&1)?M3:M1); R(14,-5,2,10,M0); R(14,-4,1,8,M2);
      R(2,-7,5,3,OL); R(3,-6,3,1,M1); R(2,5,3,4,OL); R(3,5,1,3,M0); break; }
    case 'arc':
      R(0,-4,8,8,OL); R(1,-3,6,6,gd.color); R(1,-3,6,1,'#5a8ae0'); R(1,2,6,1,'#142a50');
      R(7,-6,3,4,OL); R(7,2,3,4,OL); R(7,-5,2,2,M2); R(7,3,2,2,M2); R(8,-5,1,1,'#ffffff'); R(8,3,1,1,'#ffffff');
      R(8,-2,3,4,fl?'#ffffff':fc); R(9,-1,2,2,fl?fc:'#ffffff'); R(3,-1,3,2,fc); R(4,-1,1,1,'#ffffff');
      R(2,4,3,4,OL); R(3,4,1,3,M0); break;
    case 'plasma':
      R(-1,-6,10,12,OL); R(0,-5,8,10,gd.color); R(1,-4,6,8,'#5a3a98'); R(2,-3,4,6,fc); R(2,-3,2,2,'#ffffff'); R(5,2,1,1,'#fff3fa');
      R(8,-4,6,8,OL); R(9,-3,5,6,M1); R(9,-3,5,1,M2); R(12,-4,1,8,fc); R(13,-1,1,2,'#ffffff');
      R(2,6,4,4,OL); R(3,6,2,3,M0); R(1,-6,1,1,fc); R(6,-6,1,1,fc); break;
    case 'sawedoff':
      R(-4,-1,6,8,OL); R(-3,0,4,6,W2); R(-3,0,4,1,W3); R(-3,5,4,1,W1);
      R(0,-4,4,8,OL); R(1,-3,2,6,gd.color); R(1,-3,2,1,'#c08a4a');
      R(3,-4,9,9,OL); R(4,-3,8,3,M2); R(4,-3,8,1,M3); R(4,0,8,3,M1); R(4,0,8,1,M2); R(11,-2,1,1,OL); R(11,1,1,1,OL); R(4,-3,1,6,M0); break;
    case 'cluster':
      R(0,-6,9,12,OL); R(1,-5,7,10,gd.color); R(1,-5,7,1,'#8aa84a'); R(1,4,7,1,'#2a3a14');
      R(2,-4,3,4,'#ffb84d'); R(2,-4,1,1,'#ffffff'); R(5,-4,3,4,'#ffb84d'); R(5,-4,1,1,'#ffffff'); R(3,0,3,4,'#ffb84d'); R(3,0,1,1,'#ffffff');
      R(8,-3,4,6,OL); R(9,-2,3,4,M1); R(9,-2,3,1,M2); R(11,-3,1,6,M3); R(2,6,4,4,OL); R(3,6,2,3,M0); break;
    default: /* blaster */
      R(0,-4,10,7,OL); R(1,-3,8,5,gd.color); R(1,-3,8,1,M2); R(1,1,8,1,M0);
      R(3,-2,1,3,M0); R(5,-2,1,3,M0); R(9,-2,1,4,OL); R(9,-1,1,2,M3); R(10,-1,1,1,'#ffffff');
      R(2,3,4,5,OL); R(3,3,2,4,M0); R(3,3,1,4,M1); R(7,3,2,1,M0);
      R(5,-1,3,1,f.shots%4===3?'#ffd23f':'#7dffea'); R(8,-4,1,1,M3);
  }
  R(1,1,2,1,'#22203a');
  if(f.flash>0){
    const fx=Math.round((7+gd.len)*gs),big=f.flash>0.065,al=f.shots&1,fw=(big?6:4)+al;
    R0(fx,-1,fw,3,fc); R0(fx+1,-2,fw-2,5,fc); R0(fx,0,Math.max(2,fw-2),1,'#ffffff');
    R0(fx+fw-1,-3-al,1,1,fc); R0(fx+fw-1,3+al,1,1,fc); if(big){ R0(fx+1,-4,1,2,fc); R0(fx+1,3,1,2,fc); R0(fx+fw,0,2,1,'#ffffff'); }
  }
  ctx.restore();
}

/* ---------- weapons: melee ---------- */
/* every melee weapon is drawn once, pointing right from the hand, and then swung around the hand like a real swing */
const MOL='#12111c',MCM={};
function mlit(h,k){ const key='L'+h+k; if(MCM[key]) return MCM[key]; const c=h.replace('#',''),m=function(i){ const v=parseInt(c.slice(i,i+2),16); return Math.max(0,Math.min(255,Math.round(v+(255-v)*k))); },x=function(v){ return (v<16?'0':'')+v.toString(16); }; return MCM[key]='#'+x(m(0))+x(m(2))+x(m(4)); }
function mdark(h,k){ const key=h+k; if(MCM[key]) return MCM[key]; const c=h.replace('#',''),m=function(i){ return Math.max(0,Math.min(255,Math.round(parseInt(c.slice(i,i+2),16)*k))); },x=function(v){ return (v<16?'0':'')+v.toString(16); }; return MCM[key]='#'+x(m(0))+x(m(2))+x(m(4)); }
function mBlade(R,x,len,w,m,hi,lo){ const t=w>>1; R(x-1,-t-1,len+2,w+2,MOL); R(x,-t,len,w,m); R(x,-t,len,1,hi); R(x,-t+w-1,len,1,lo); R(x+len,-t+1,1,Math.max(1,w-2),m); R(x+len+1,-t+(w>>1),1,1,hi); }
function mEnergy(R,x,len,w,bc){ const t=w>>1; R(x-1,-t-2,len+3,w+4,MOL); R(x,-t-1,len,w+2,mdark(bc,0.6)); R(x,-t,len,w,bc); R(x,0,len,1,'#ffffff'); R(x+len,-t,1,w,bc); }
function mHilt(R,guard,grip){ R(-6,-2,7,4,MOL); R(-5,-1,6,2,grip); R(-4,-1,1,2,mdark(grip,0.55)); R(-2,-1,1,2,mdark(grip,0.55)); R(0,-4,2,8,MOL); R(0,-3,1,6,guard); R(-8,-2,3,4,MOL); R(-7,-1,1,2,guard); }
function mShaft(R,len,wood){ R(-6,-2,len+4,4,MOL); R(-6,-1,len+2,1,wood[0]); R(-6,0,len+2,1,wood[1]); R(-7,-1,2,2,'#98a3c4'); }
const WOOD=['#b08a50','#6a4a22'];
function drawMelee(f,R){
  const wd=f.wd[0],id=wd.id,bc=wd.color,P=f.pal,fl=Math.floor(f.anim*10)%2;
  const rangeNow=f.swing>0?f.swingRange:wd.range,Lraw=Math.max(8,rangeNow-9),MS=0.72;
  const Lt=Lraw>11?11+(Lraw-11)*0.4:Lraw,L=Math.round(Lt/MS);
  let q=0,p=0;
  if(f.swing>0){ p=1-f.swing/(f.swingDur||0.16); const st=f.swingStep; q=st===1?1-p:(st===2?(p<0.5?p*0.6:p):p); }
  const arm=function(x,y){ R(x,y,3,2,P.main); R(x+2,y,1,2,'#22203a'); };
  /* chaser scythe: long pole, curved steel blade wreathed in fire */
  if(id==='claw'){
    const ang=f.swing>0?-1.25+q*2.7:-0.14+Math.sin(f.anim*3)*0.04;
    ctx.save(); ctx.translate(2,-8); ctx.rotate(ang);
    R(0,-15,1,22,'#5a3a22'); R(0,-7,1,1,'#ff4d5e'); R(0,-2,1,1,'#ff4d5e'); R(-1,6,3,1,'#2a1a12');
    const bx=0,by=-17;
    R(bx-1,by+1,2,2,'#cfd6e6'); R(bx,by,4,2,'#cfd6e6'); R(bx+3,by+1,3,2,'#cfd6e6'); R(bx+5,by+2,2,3,'#cfd6e6'); R(bx+6,by+4,2,2,'#ffffff');
    R(bx,by+2,4,1,'#ffffff'); R(bx+1,by-1,2,1,'#7a2a1a');
    const FC=['#ff5a1f','#ffb02e','#fff3b0'];
    for(let k=0;k<4;k++){ const h=(k+fl)%3; R(bx+k*2,by-2-h,1+(k&1),2+h,FC[(k+fl)%3]); }
    R(bx+2+fl,by+3,2,1,'#ffb02e'); R(bx+5,by+5+fl,1,2,'#ff7a1f');
    ctx.restore();
    arm(1,-8); R(1,-10,3,3,'#2a0f18'); R(1,-10,3,1,'#ff4d5e');
    return;
  }
  /* where the hand is and which way the weapon points: windup -> fast strike -> overshoot -> settle */
  const stp=f.swingStep,heavy=stp===2;
  const lerp=function(a,b,t){ return a+(b-a)*t; };
  const swingC=function(t){
    const w=heavy?0.34:0.2,e=0.82;
    if(t<w){ const u=t/w; return -0.16*(1-(1-u)*(1-u)); }
    if(t<e){ const u=(t-w)/(e-w); return -0.16+1.26*(u*u*(3-2*u)*0.35+u*u*0.65); }
    const u=(t-e)/(1-e); return 1.10-0.10*u*(2-u);
  };
  const runN=f.onGround&&Math.abs(f.vx)>12;
  const idleA=(wd.thrust?-1.1:-1.0)+(runN?Math.sin(f.anim*12)*0.12:Math.sin(f.anim*3)*0.04);
  const idleY=-8+Math.round(Math.sin(f.anim*3)*0.5);
  const poseAt=function(pp){
    if(pp<0) return {hx:4,hy:idleY,ang:idleA};
    const bl=Math.max(0,(pp-0.9)/0.1);
    let hx,hy,ang;
    if(wd.thrust){
      let tx;
      if(pp<0.3) tx=lerp(4,0,1-(1-pp/0.3)*(1-pp/0.3));
      else if(pp<0.5){ const u=(pp-0.3)/0.2; tx=lerp(0,7,u*u); }
      else if(pp<0.8) tx=7;
      else tx=lerp(7,4,(pp-0.8)/0.2);
      hx=tx; hy=-9;
      ang=pp<0.15?lerp(idleA,0,pp/0.15):0;
    } else {
      const c=swingC(pp),qq=stp===1?1-c:c;
      const a0=-2.3+qq*2.45;
      ang=pp<0.12?lerp(idleA,a0,pp/0.12):a0;
      hx=2+qq*3; hy=-10+qq*2;
    }
    hx=lerp(hx,4,bl); hy=lerp(hy,idleY,bl); ang=lerp(ang,idleA,bl);
    return {hx:Math.round(hx),hy:Math.round(hy),ang:ang};
  };
  const ps=poseAt(f.swing>0?p:-1);
  const hx=ps.hx,hy=ps.hy,ang=ps.ang;
  /* sleeve from the shoulder to the hand */
  for(let t=0;t<=3;t++) R(Math.round(0+(hx-0)*t/3)-1,Math.round(-9+(hy+9)*t/3)-1,2,2,P.main);
  const col=function(c){ return f.tint||(f.hurt>0?'#ffffff':c); };
  const paintW=function(){
  switch(id){
    case 'fang':
      ctx.save(); ctx.translate(-3,3); mBlade(R,1,Math.max(7,L-3),2,bc,'#ffffff',mdark(bc,0.5)); R(-2,-2,3,5,MOL); R(-1,-1,2,3,'#2b6a55'); ctx.restore();
      mHilt(R,'#2b6a55','#1c3a30'); mBlade(R,2,L,2,bc,'#ffffff',mdark(bc,0.5)); R(2+L-1,-3,2,2,bc); break;
    case 'katana':
      mHilt(R,'#d9b24a','#2a1a22'); R(-4,-1,1,2,'#a02a3a'); R(-2,-1,1,2,'#a02a3a');
      mBlade(R,2,L+2,2,'#cdd3e6','#ffffff','#8a93b0'); R(4,0,L-3,1,bc); break;
    case 'spear':
      mShaft(R,L,WOOD);
      for(let i=0;i<10;i++){ const hh=Math.min(i,9-i,3); R(L-3+i,-hh-1,1,2*hh+2,MOL); R(L-3+i,-hh,1,hh,'#d9e2f7'); R(L-3+i,0,1,hh,'#8a93b0'); }
      R(L-3,-1,8,1,bc); R(L-7,1,2,4,'#ff5a4f'); R(L-6,4,1,2,'#c0302a'); break;
    case 'cleaver':
      mHilt(R,'#8a6a3a','#4a3a2a'); mBlade(R,2,L,6,'#7b869f','#cfd8ee','#3b4260'); R(2,3,L,1,bc); R(L-7,-1,2,2,MOL); R(L-3,-1,2,2,MOL); R(L+2,-2,2,5,'#7b869f'); break;
    case 'hammer':
      mShaft(R,L,WOOD);
      R(L-3,-7,11,14,MOL); R(L-2,-6,9,12,'#8c96b8'); R(L-2,-6,9,2,'#d8e0f4'); R(L-2,4,9,2,'#4a5170'); R(L-1,-5,1,1,MOL); R(L+5,-5,1,1,MOL);
      R(L+1,-3,4,6,bc); R(L+2,-3,1,3,'#ffffff'); R(L+3,0,1,3,mdark(bc,0.6)); break;
    case 'vamp':
      mHilt(R,'#c0243e','#3a1018'); R(-1,-1,2,2,'#ff2a5a'); mBlade(R,2,L,4,'#a01a34','#ff8aa0','#4a0a18'); R(4,0,L-4,1,'#2a0610'); R(L-2,2+fl,1,2,'#ff2a5a'); break;
    case 'storm': {
      mHilt(R,'#5a7ab0','#1c2a44'); mBlade(R,2,L,3,'#b8c8e6','#ffffff','#6a7aa0');
      for(let i=0;i<L-3;i+=3) R(4+i,((i/3)&1)?-1:0,2,1,bc);
      R(L+2,-1-fl,1,1,'#ffffff'); break; }
    case 'ion':
      mHilt(R,'#98a3c4','#2a1a44'); R(1,-3,2,7,'#e0dbff'); mEnergy(R,3,L,3,bc); R(L+3,-3,2,2,bc); R(L+3,2,2,2,bc); break;
    case 'dagger':
      mHilt(R,'#d9b24a','#3a2418'); mBlade(R,2,L,2,'#cdd3e6','#ffffff','#7a85a6'); R(2,0,L-2,1,mdark(bc,0.7)); break;
    case 'axe':
      mShaft(R,L,WOOD);
      R(L-6,-8,9,11,MOL); R(L-5,-7,7,9,'#8c96b8'); R(L-5,-7,7,1,'#d8e0f4'); R(L-5,1,7,1,'#4a5170'); R(L+2,-8,2,11,MOL); R(L+3,-7,1,9,'#ffffff'); R(L+3,-6,1,5,bc);
      R(L-3,2,5,3,MOL); R(L-2,2,3,1,'#8c96b8'); R(L-6,-1,2,2,MOL); break;
    case 'flamesword': {
      mHilt(R,'#c25a2a','#3a2418'); mBlade(R,2,L,3,'#e8a060','#ffe9b0','#a03a10');
      const FC=['#ff5a1f','#ffb02e','#fff3b0'];
      for(let k=0;k<Math.floor(L/3);k++){ const h=(k+fl)%3; R(3+k*3,-3-h,2,2+h,FC[(k+fl)%3]); }
      R(L+2,-1,2,2,'#ffb02e'); R(L+3,-2-fl,1,2,'#fff3b0'); break; }
    case 'sickle': {
      R(-5,-2,12,4,MOL); R(-4,-1,11,1,'#8a5a2c'); R(-4,0,11,1,'#4a2a10'); R(-7,-1,2,2,'#98a3c4');
      const pts=[[6,-1],[8,-3],[10,-5],[11,-8],[10,-11],[8,-13],[5,-14]];
      for(const q2 of pts) R(q2[0]-1,q2[1]-1,4,4,MOL);
      for(const q2 of pts){ R(q2[0],q2[1],2,2,'#cfd6e6'); R(q2[0],q2[1],1,1,'#ffffff'); }
      R(10,-8,1,3,bc); R(8,-12,2,1,bc); R(5,-13,2,1,bc); break; }
    case 'halberd':
      mShaft(R,L,WOOD);
      R(L-1,-1,8,3,MOL); R(L,0,7,1,'#d9e2f7'); R(L,1,7,1,'#8a93b0');
      R(L-7,-10,9,10,MOL); R(L-6,-9,7,8,'#98a3c4'); R(L-6,-9,7,1,'#e8f0ff'); R(L-6,-2,7,1,'#4a5170'); R(L+1,-10,2,10,MOL); R(L+2,-9,1,8,'#ffffff'); R(L+2,-7,1,4,bc);
      R(L-5,2,6,3,MOL); R(L-4,2,4,1,'#98a3c4'); break;
    case 'whip': {
      R(-6,-2,7,4,MOL); R(-5,-1,6,2,'#3a4060'); R(-1,-4,2,8,MOL); R(-1,-3,1,6,'#98a3c4');
      const A=f.swing>0?3:1.6,n=Math.floor(L/2)+2;
      for(let i=0;i<n;i++){ const x=2+i*2,y=Math.round(Math.sin(i*0.7+f.anim*14)*A*(0.3+i/n)); R(x-1,y-1,4,4,mdark(bc,0.5)); }
      for(let i=0;i<n;i++){ const x=2+i*2,y=Math.round(Math.sin(i*0.7+f.anim*14)*A*(0.3+i/n)); R(x,y,2,2,(i&1)?'#ffffff':bc); }
      R(2+n*2,Math.round(Math.sin(n*0.7+f.anim*14)*A*1.3)-1,2,3,'#ffffff'); break; }
    case 'mace':
      mShaft(R,L,WOOD);
      R(L-4,-6,9,13,MOL); R(L-5,-5,11,11,MOL); R(L-3,-5,7,11,'#8c96b8'); R(L-4,-4,9,9,'#8c96b8'); R(L-3,-5,5,2,'#d8e0f4'); R(L-3,3,7,2,'#4a5170');
      R(L-1,-9,3,3,MOL); R(L,-8,1,2,'#cfd6e6'); R(L-1,6,3,3,MOL); R(L,6,1,2,'#cfd6e6'); R(L+5,-1,3,3,MOL); R(L+5,0,2,1,'#cfd6e6'); R(L-8,-1,3,3,MOL);
      R(L-1,-1,3,3,bc); R(L-1,-1,1,1,'#ffffff'); break;
    case 'trident':
      mShaft(R,L-4,WOOD);
      R(L-5,-6,3,13,MOL); R(L-4,-5,1,11,'#8a93b0'); R(L-4,-5,1,1,'#ffffff');
      R(L-3,-1,10,3,MOL); R(L-2,0,9,1,'#d9e2f7'); R(L+6,-1,2,3,MOL); R(L+7,0,1,1,'#ffffff');
      R(L-3,-6,8,2,MOL); R(L-2,-5,7,1,'#d9e2f7'); R(L+4,-7,2,2,MOL); R(L-3,5,8,2,MOL); R(L-2,5,7,1,'#d9e2f7'); R(L+4,6,2,2,MOL);
      R(L+1,-2+fl,2,1,bc); R(L+3,1-fl,2,1,bc); R(L+6,-3,1,1,bc); R(L+6,5,1,1,bc); break;
    case 'crescent':
      mHilt(R,'#d9b24a','#3a2a18');
      ctx.fillStyle=MOL; ctx.beginPath(); ctx.arc(L+1,0,12,-Math.PI/2,Math.PI/2); ctx.arc(L-5,0,10.5,Math.PI/2,-Math.PI/2,true); ctx.closePath(); ctx.fill();
      ctx.fillStyle=col(bc); ctx.beginPath(); ctx.arc(L+1,0,11,-Math.PI/2,Math.PI/2); ctx.arc(L-5,0,10.5,Math.PI/2,-Math.PI/2,true); ctx.closePath(); ctx.fill();
      ctx.strokeStyle=col('#ffffff'); ctx.lineWidth=1; ctx.beginPath(); ctx.arc(L+1,0,10,-Math.PI/2+0.2,Math.PI/2-0.2); ctx.stroke();
      R(L-3,-1,4,2,'#ffffff'); break;
    case 'iceblade':
      mHilt(R,'#4a7ac0','#1c2a44'); mBlade(R,2,L,3,'#bfeeff','#ffffff','#4aa0c8');
      for(let k=0;k<Math.floor((L-3)/4);k++){ R(5+k*4,-3,2,2,'#e8fbff'); R(7+k*4,2,2,2,'#7ac8e8'); }
      R(L-2+fl*2,-4,1,1,'#ffffff'); R(L+1,1-fl,1,1,'#ffffff'); break;
    default: /* pulse blade */
      mHilt(R,'#ffd166','#3a4060'); R(1,-3,2,6,'#98a3c4'); mEnergy(R,3,L,3,bc);
  }
  };
  /* afterimages while the weapon is whipping through the strike */
  if(f.swing>0&&p>(heavy?0.34:0.2)&&p<0.88){
    for(let k=2;k>=1;k--){
      const g=poseAt(Math.max(0,p-k*0.055));
      ctx.save(); ctx.globalAlpha=(heavy?0.3:0.22)/k; ctx.translate(g.hx,g.hy); ctx.rotate(g.ang); ctx.scale(MS,MS); paintW(); ctx.restore();
    }
  }
  ctx.save(); ctx.translate(hx,hy); ctx.rotate(ang); ctx.scale(MS,MS); paintW(); ctx.restore();
  R(hx-2,hy-2,4,4,'#22203a'); R(hx-2,hy-2,4,1,P.main);
}

/* ---------- characters ---------- */
function drawWings(f,R){
  /* big feathered wing: three layers of feathers fanning out from the shoulder, flapping while flying */
  const fo=f.onGround?0:1,fp=Math.sin(f.anim*(f.vy<0?16:9)),flap=fo?fp*0.35:0.0;
  const layers=[{n:5,len:13,c:'#4aa8e8',h:'#bfe8ff',d:'#1a4a7a'},{n:4,len:10,c:'#7cc8f8',h:'#e8f8ff',d:'#2f78b0'},{n:3,len:6,c:'#c8ecff',h:'#ffffff',d:'#6aa8d8'}];
  for(let li=0;li<layers.length;li++){
    const L=layers[li];
    for(let j=L.n-1;j>=0;j--){
      const ang=-0.05-j*(0.95/L.n)-flap+(li*0.05);   /* radians above the horizontal, pointing backwards */
      const len=L.len-j*0.5-Math.abs(j-1)*0.3;
      for(let k=2;k<len;k++){
        const px=Math.round(-4-Math.cos(ang)*k),py=Math.round(-10+Math.sin(ang)*k);
        R(px,py,2,2,k>len-2?L.h:L.c); R(px,py+1,2,1,L.d);
        if(k===2) R(px,py,2,1,L.h);
      }
    }
  }
  R(-5,-11,3,4,'#e8f4ff'); R(-5,-11,3,1,'#ffffff'); R(-5,-8,3,1,'#7aa8d0');
}
function drawShieldFx(f){
  if(!f.skOn||f.sk!=='sk_shield') return;
  const sx=Math.round(f.x+f.face*9),y0=Math.round(f.y)-23,h=25,t=time*20+f.id;
  const hit=f.shFl>0,fr=Math.max(0,Math.min(1,f.sp/Math.max(1,f.maxsp))),low=fr<0.3;
  const flick=low&&(Math.floor(t*0.8)%3===0);
  ctx.save();
  /* soft glow */
  ctx.fillStyle=hit?'rgba(255,255,255,0.28)':'rgba(125,255,234,0.12)'; ctx.fillRect(sx-5,y0-1,10,h+2);
  ctx.fillStyle=hit?'rgba(255,255,255,0.35)':'rgba(125,255,234,0.2)'; ctx.fillRect(sx-3,y0,6,h);
  /* hex cells */
  for(let yy=0;yy<h;yy+=4){
    const off=((yy>>2)&1)?2:0,a=hit?0.9:0.55;
    ctx.fillStyle='rgba(180,255,246,'+a+')';
    ctx.fillRect(sx-3+off,y0+yy,1,1); ctx.fillRect(sx-2+off,y0+yy+1,1,2); ctx.fillRect(sx-1+off,y0+yy,1,1);
    ctx.fillRect(sx+1+off-(off?2:0),y0+yy+2,1,1);
  }
  /* bright core + scanning pulse */
  ctx.fillStyle=hit?'#ffffff':'#bffff5'; ctx.fillRect(sx,y0,1,h);
  const sy=Math.floor((t*1.4)%h); ctx.fillStyle='#ffffff'; ctx.fillRect(sx-3,y0+sy,7,1); ctx.fillStyle='rgba(255,255,255,0.5)'; ctx.fillRect(sx-2,y0+((sy+h-1)%h),5,1);
  /* emitters */
  ctx.fillStyle='#12111c'; ctx.fillRect(sx-4,y0-3,9,3); ctx.fillRect(sx-4,y0+h,9,3);
  ctx.fillStyle='#4a5a8a'; ctx.fillRect(sx-3,y0-2,7,1); ctx.fillRect(sx-3,y0+h+1,7,1);
  ctx.fillStyle=hit?'#ffffff':'#7dffea'; ctx.fillRect(sx-1,y0-2,3,1); ctx.fillRect(sx-1,y0+h+1,3,1);
  /* sparks rising along the barrier, and a ripple where it was hit */
  for(let k=0;k<5;k++){ const ph=((t*0.045+k*0.2+f.id*0.13)%1),yy=y0+h-Math.floor(ph*h),xx=sx+Math.round(Math.sin(t*0.3+k*2)*3); ctx.fillStyle='rgba(255,255,255,'+(0.9*(1-ph*0.5))+')'; ctx.fillRect(xx,yy,1,1); }
  if(hit){ const rr=Math.round((1-f.shFl/0.12)*9)+2,cy=y0+Math.round(h*0.5); ctx.strokeStyle='rgba(255,255,255,0.8)'; ctx.lineWidth=1; ctx.beginPath(); ctx.arc(sx,cy,rr,-1.2,1.2); ctx.stroke(); ctx.beginPath(); ctx.arc(sx,cy,rr,Math.PI-1.2,Math.PI+1.2); ctx.stroke(); }
  ctx.fillStyle='rgba(125,255,234,0.25)'; ctx.fillRect(sx-4,y0+h+3,9,1); ctx.fillStyle='rgba(125,255,234,0.12)'; ctx.fillRect(sx-6,y0+h+3,13,1);
  /* cracks when it is nearly spent */
  if(low&&!flick){ ctx.fillStyle='rgba(18,17,28,0.8)'; ctx.fillRect(sx-2,y0+6,2,1); ctx.fillRect(sx-1,y0+7,1,3); ctx.fillRect(sx,y0+14,2,1); ctx.fillRect(sx+1,y0+15,1,3); }
  if(flick){ ctx.fillStyle='rgba(18,17,28,0.5)'; ctx.fillRect(sx-3,y0,6,h); }
  ctx.restore();
}
function drawBlockSprite(k){
  const x=Math.round(k.x-k.w/2)+((k.shk>0&&Math.floor(time*60)%2)?1:0),y=Math.round(k.y-k.h),w=k.w,h=Math.round(k.h);
  if(h<=0) return;
  const pc=(k.owner&&k.owner.pal)?k.owner.pal.main:'#38b6ff',fr=Math.max(0,k.hp)/k.max,fl=k.flash>0;
  if(k.t<1.5&&Math.floor(k.t*10)%2) ctx.globalAlpha=0.45;
  const F=function(xx,yy,ww,hh,c){ ctx.fillStyle=fl?'#ffffff':c; ctx.fillRect(xx,yy,ww,hh); };
  F(x-1,y-1,w+2,h+2,'#0a0d1a');                       /* outline */
  F(x,y,w,h,'#3a4668');                               /* stone */
  F(x,y,2,h,'#6f82b8'); F(x+w-2,y,2,h,'#222a45');     /* bevel */
  /* staggered bricks */
  for(let yy=y+7,row=0;yy<y+h-1;yy+=8,row++){
    F(x,yy,w,1,'#161c30');
    const bx=x+(row&1?3:1); if(bx<x+w-2) F(bx,yy-7,1,7,'#161c30');
    if(!fl&&row%2===0) F(x+2,yy-6,w-4,1,'#566a9c');
  }
  /* glowing rune line */
  const g=Math.floor(time*6+k.x)%4;
  for(let yy=y+4;yy<y+h-3;yy+=8){ ctx.fillStyle=pc; ctx.globalAlpha=(ctx.globalAlpha>0.9?1:0.45)*(g===((yy-y)>>3)%4?1:0.65); ctx.fillRect(x+2,yy,w-4,1); ctx.globalAlpha=(k.t<1.5&&Math.floor(k.t*10)%2)?0.45:1; }
  /* crenellated top with glow */
  F(x,y,w,2,pc); F(x+1,y,w-2,1,'#ffffff');
  for(let cx=x;cx<x+w;cx+=3) F(cx,y-2,2,2,'#56699c');
  F(x,y-2,w,1,'#0a0d1a');
  F(x,y+h-2,w,2,'#161c30');
  ctx.fillStyle='#090c18';
  if(fr<0.7){ ctx.fillRect(x+1,y+Math.round(h*0.3),2,1); ctx.fillRect(x+2,y+Math.round(h*0.3)+1,1,3); ctx.fillRect(x+3,y+Math.round(h*0.3)+3,2,1); }
  if(fr<0.4){ ctx.fillRect(x+3,y+Math.round(h*0.6),2,1); ctx.fillRect(x+3,y+Math.round(h*0.6)+1,1,4); ctx.fillRect(x+1,y+Math.round(h*0.8),3,1); ctx.fillRect(x+4,y+Math.round(h*0.5),1,3); }
  if(fr<0.99&&k.max>0){ ctx.fillStyle='rgba(0,0,0,0.7)'; ctx.fillRect(x-1,y-6,w+2,3); ctx.fillStyle=fr>0.5?'#4ade80':fr>0.25?'#fbbf24':'#ef4444'; ctx.fillRect(x,y-5,Math.round(w*fr),1); }
  ctx.globalAlpha=1;
}
function drawBlocks(){ for(const k of BLK){ if(!offView(k.x-8,16,16)) drawBlockSprite(k); } }
function drawBody(f,ox,oy){
  const x=Math.round(f.x)+(ox||0),y=Math.round(f.y)+(oy||0)-(f.cel||0),sc=f.scale||1;
  ctx.save(); ctx.translate(x,y); ctx.scale(f.face*sc,sc);
  const hit=f.hurt>0,P=f.pal;
  const R=function(a,b,w,h,c){ ctx.fillStyle=f.tint||(hit?'#ffffff':c); ctx.fillRect(a,b,w,h); };
  if(f.flying) drawWings(f,R);
  const spdX=Math.abs(f.vx),moving=f.onGround&&spdX>12,ph=Math.floor(f.anim*(spdX>110?17:13))%4;
  const idleUp=!moving&&f.onGround&&(Math.floor(f.anim*2.3)%2===1);
  const by=moving?((ph&1)?-1:0):(idleUp?1:0);
  const SK='#f4cfa5',SKD='#d9a97c',SKH='#ffe3c4',LG='#25233f',LGD='#1a1830',LGH='#3a3760',BT=P.dark,BTH=mlit(P.dark,0.4),SOLE='#12111c';
  const HD=mdark(P.hair,0.7),HL=mlit(P.hair,0.55),MD=mdark(P.main,0.72),ML=mlit(P.main,0.4);
  const fl2=Math.floor(f.anim*14)%2;
  /* legs */
  const leg=function(hipX,footX,lift,far){
    const c=far?LGD:LG,h=far?LGD:LGH;
    R(hipX,-5,2,2,c); R(hipX,-5,1,2,h);
    const mx=Math.round((hipX+footX)/2); if(lift<2){ R(mx,-3,2,1,c); }
    const bw=far?3:4,bx=footX; const y0=-3-lift;
    R(bx,y0,bw,3,far?mdark(BT,0.8):BT); R(bx,y0,bw,1,far?BT:BTH); R(bx,y0+2,bw,1,SOLE);
  };
  if(!f.onGround){
    if(f.vy<0){ leg(-3,-4,2,true); leg(0,0,1,false); }
    else { leg(-3,-5,0,true); leg(0,2,1,false); }
  } else if(moving){
    const F=[[-5,3,0,0],[-2,0,1,0],[3,-5,0,0],[0,-2,0,1]][ph];
    leg(-3,F[0],F[2],true); leg(0,F[1],F[3],false);
  } else { leg(-3,-3,0,true); leg(0,1,0,false); }
  ctx.save(); ctx.translate(0,by);
  /* flowing scarf */
  const sw=f.dashT>0?-3:0;
  for(let i=0;i<4;i++){
    const wv=f.dashT>0?0:Math.round(Math.sin(f.anim*11+i*1.3)*1.2),sx=-5-i*2+(f.dashT>0?-i*0:0)+(sw&&i?sw:0);
    R(sx,-10+wv+(i>>1),3,2,i&1?mdark(P.hair,0.8):P.hair);
  }
  if(f.dashT>0){ R(-16,-10,7,1,P.hair); R(-14,-9,5,1,HD); }
  /* back arm */
  const asw=moving?[-2,0,2,0][ph]:0;
  R(-4+asw,-9,2,3,MD); R(-4+asw,-9,1,3,mdark(P.main,0.55)); R(-4+asw,-6,2,2,SKD);
  /* torso: shirt, shading, collar, chest light, belt */
  R(-3,-10,6,5,P.main); R(-3,-10,1,5,MD); R(2,-10,1,5,ML);
  R(-3,-10,6,1,ML); R(-2,-10,4,1,mlit(P.main,0.65));
  R(-4,-10,2,2,P.dark); R(-4,-10,2,1,mlit(P.dark,0.35));          /* shoulder pad */
  R(-1,-9,2,3,P.hair); R(-1,-9,1,3,HL); R(0,-6,1,1,MD);           /* chest panel */
  R(-3,-9,1,1,ML);
  R(-3,-5,6,1,LG); R(-3,-5,6,1,LGD); R(0,-5,2,1,'#ffd23f'); R(0,-5,1,1,'#fff3b0');
  if(f.rel>=0) R(-1,-8,1,1,f.tint?f.tint:relColor(f));
  /* neck + head */
  R(-1,-11,3,1,SKD);
  R(-3,-16,6,6,SK); R(-3,-11,6,1,SKD); R(-3,-16,1,6,SKD); R(2,-15,1,3,SKH);
  R(3,-13,1,1,SK);                                                 /* nose */
  R(-4,-14,1,2,SKD);                                               /* ear */
  const st=f.style;
  const hairBase=function(){ R(-4,-17,7,3,P.hair); R(-4,-17,7,1,HL); R(-4,-14,2,4,P.hair); R(-4,-11,1,1,HD); R(-3,-14,6,1,HD); R(0,-15,3,1,P.hair); R(3,-16,1,2,P.hair); };
  if(st==='spike'){ hairBase(); R(-3,-19,1,2,P.hair); R(-1,-21,1,4,P.hair); R(1,-19,1,3,P.hair); R(-1,-21,1,1,'#ffffff'); R(-3,-19,1,1,HL); R(1,-19,1,1,HL); R(-4,-16,1,1,HL); }
  else if(st==='helm'){ R(-4,-17,8,4,'#9aa5c4'); R(-4,-17,8,1,'#e6ecfa'); R(-4,-14,8,1,'#5a6480'); R(-4,-13,1,3,'#7d88ab'); R(0,-18,1,5,P.main); R(0,-18,1,1,mlit(P.main,0.5)); R(-1,-18,3,1,P.dark); R(1,-16,3,1,'#12111c'); R(3,-15,1,2,'#7d88ab'); }
  else if(st==='mask'){ hairBase(); R(-4,-17,8,4,P.dark); R(-4,-17,8,1,mlit(P.dark,0.4)); R(-4,-14,8,1,P.main); R(-4,-14,8,1,P.main); R(-3,-11,6,2,'#151322'); R(-3,-11,6,1,'#2a2842'); R(-8,-14,4,1,P.main); R(-9,-13+fl2,3,1,P.main); R(-8,-13+fl2,2,1,ML); }
  else if(st==='crown'){ hairBase(); R(-3,-19,6,3,'#ffd23f'); R(-3,-19,6,1,'#fff3b0'); R(-3,-17,6,1,'#c9992a'); R(-3,-21,1,2,'#ffd23f'); R(-1,-22,1,3,'#ffd23f'); R(1,-21,1,2,'#ffd23f'); R(-1,-18,1,1,'#ff4d5e'); R(-3,-18,1,1,'#38b6ff'); R(1,-18,1,1,'#7dffa0'); }
  else if(st==='flame'){ hairBase(); const FC=['#ff7a1f','#ffd23f','#fff3b0']; R(-3,-19-fl2,1,3,FC[0]); R(-1,-21,1,5,FC[1]); R(1,-19-fl2,1,3,FC[0]); R(0,-20+fl2,1,3,FC[2]); R(-2,-18,1,1,FC[1]); }
  else if(st==='hood'){ R(-4,-17,8,5,P.dark); R(-4,-17,8,1,mlit(P.dark,0.45)); R(-5,-14,2,6,P.dark); R(-5,-14,1,6,MD); R(-3,-13,1,1,mdark(P.dark,0.6)); R(-2,-18,3,1,'#e6faff'); R(-1,-19,1,1,'#ffffff'); R(2,-16,2,1,mlit(P.dark,0.3)); }
  else if(st==='ghost'){ R(-4,-17,8,5,'#f0f0ff'); R(-4,-17,8,1,'#ffffff'); R(-5,-14,2,6,'#dcdcf4'); R(-5,-9+fl2,1,2,'#f0f0ff'); R(-5,-8,1,1,'#c4c4e4'); R(-3,-14,7,1,'#c4c4e4'); }
  else if(st==='horn'){ hairBase(); R(-5,-21,1,5,'#e8e0c8'); R(3,-21,1,5,'#e8e0c8'); R(-5,-17,3,1,'#bfb698'); R(1,-17,3,1,'#bfb698'); R(-5,-21,1,1,'#ffffff'); R(3,-21,1,1,'#ffffff'); R(-4,-17,1,1,'#7a7258'); }
  else { /* cap: headband */ hairBase(); R(-4,-15,8,1,P.main); R(-4,-15,8,1,P.main); R(-4,-14,8,1,P.dark); R(3,-17,1,2,P.main); R(-7,-15,3,1,P.main); R(-8,-14+fl2,2,1,P.main); }
  /* eyes: white, pupil and brow; they blink now and then */
  const blink=(f.anim%3.4)<0.1&&f.hurt<=0;
  const ec=f.role==='chaser'?'#ff2a2a':'#1b1b2f';
  if(blink){ R(0,-12,3,1,SKD); }
  else { R(0,-13,3,2,'#ffffff'); R(2,-13,1,2,ec); R(1,-12,1,1,mlit('#d0d6ee',0)); if(f.role==='chaser') R(0,-13,3,2,'#ff2a2a'); R(2,-13,1,1,f.role==='chaser'?'#ffd0d0':'#3a3a5a'); }
  R(0,-14,3,1,HD); R(2,-14,1,1,mdark(P.hair,0.5));
  if(f.hurt>0) R(1,-10,2,1,'#7a2a2a'); else R(1,-11,2,1,'#c0734f');
  /* weapon */
  if(!f.noW){ if(f.weapon===1) drawGun(f,R); else drawMelee(f,R); }
  ctx.restore();
  ctx.restore();
  if(f.burnT>0&&!f.tint){ const fl2=Math.floor(f.anim*14)%3; ctx.fillStyle='#ff8a2e'; ctx.fillRect(x-3,y-16-fl2,2,3); ctx.fillStyle='#ffd23f'; ctx.fillRect(x+1,y-17+fl2,2,3); ctx.fillStyle='#ffffff'; ctx.fillRect(x,y-15,1,2); }
}
function drawOverlay(f){
  if(f.dead||f.noBar) return;
  const x=Math.round(f.x),y=Math.round(f.y),sc=f.scale||1,off=Math.round((sc-1)*14),c=f.rel>=0?relColor(f):'#8a7cf0';
  const hp=Math.max(0,f.hp)/fmax(f);
  if(f.rel===0||hp<0.995){
    ctx.fillStyle=c; ctx.fillRect(x-9,y-22-off,18,4);
    ctx.fillStyle='#000000'; ctx.fillRect(x-8,y-21-off,16,2);
    ctx.fillStyle=hp>0.5?'#4ade80':hp>0.25?'#fbbf24':'#ef4444'; ctx.fillRect(x-8,y-21-off,Math.round(16*hp),2);
  }
  if(f.rel>=0){
    const ty=Math.max(1,y-33-off);
    ctx.font=(8*TS)+'px '+FONT; const tw=Math.ceil(ctx.measureText(f.name).width)||24;
    ctx.fillStyle='rgba(8,6,20,0.6)'; ctx.fillRect(x-Math.round(tw/2)-2,ty-1,tw+4,Math.round(8*TS)+3);
    txt(f.name,x,ty,c,'center');
    if(f.rel===0){
      const b=Math.floor(time*4)%2,ay=Math.max(0,ty-10)+b;
      ctx.fillStyle='#ffe066'; ctx.fillRect(x-3,ay,7,1); ctx.fillRect(x-2,ay+1,5,1); ctx.fillRect(x-1,ay+2,3,1); ctx.fillRect(x,ay+3,1,1);
    }
    if(f.role==='chaser'){
      const cy=Math.max(0,ty-12);
      ctx.fillStyle='#ffd23f'; ctx.fillRect(x-4,cy+2,9,2); ctx.fillRect(x-4,cy,1,2); ctx.fillRect(x,cy-1,1,3); ctx.fillRect(x+4,cy,1,2);
    }
  }
}
function drawAim(){
  const p=fighters[0];
  if(!p||p.dead||p.weapon!==1) return;
  const ox=p.x,oy=p.y-8;
  ctx.fillStyle=aimOn?'#ffe066':'rgba(255,255,255,0.3)';
  for(let d=14;d<=(aimOn?90:34);d+=5){
    const x=ox+aimX*d,y=oy+aimY*d;
    if(solidAt(x,y)) break;
    ctx.fillRect(Math.round(x),Math.round(y),1,1);
  }
  if(aimOn){
    const d=(mouseOn&&!AIMS.on&&hoverX>=0)?Math.min(90,Math.hypot(camX+hoverX/ZOOM-ox,camY+hoverY/ZOOM-oy)):60;
    const cx=Math.round(ox+aimX*d),cy=Math.round(oy+aimY*d);
    ctx.fillStyle='#ff4d5e';
    ctx.fillRect(cx-3,cy,2,1); ctx.fillRect(cx+2,cy,2,1); ctx.fillRect(cx,cy-3,1,2); ctx.fillRect(cx,cy+2,1,2);
  }
}
function drawBall(){
  if(mode!=='td'||!ball||ball.hidden) return;
  const cx=Math.round(ball.x),cy=Math.round(ball.y-3);
  ctx.fillStyle='rgba(255,207,63,0.22)'; pixCircle(cx,cy,7,'rgba(255,207,63,0.22)');
  pixCircle(cx,cy,4,'#8a5200'); pixCircle(cx,cy,3,'#ffcf3f');
  ctx.fillStyle='#fff3b0'; ctx.fillRect(cx-2,cy-2,2,1); ctx.fillRect(cx-2,cy-2,1,2);
}
function drawGoals(){
  const pulse=0.16+0.08*Math.sin(time*4);
  const zones=[[ZL,'56,182,255'],[ZR,'255,77,94']];
  for(const zz of zones){
    const z=zz[0],col=zz[1];
    ctx.fillStyle='rgba('+col+','+pulse.toFixed(2)+')'; ctx.fillRect(z[0],z[1],z[2],z[3]);
    ctx.fillStyle='rgb('+col+')';
    const o=Math.floor(time*20)%4;
    for(let i=0;i<z[2];i+=4) ctx.fillRect(z[0]+i+o%4,z[1],2,1);
    ctx.fillRect(z[0],z[1],1,z[3]); ctx.fillRect(z[0]+z[2]-1,z[1],1,z[3]);
    const ay=Math.floor(time*6)%8;
    ctx.fillStyle='rgba('+col+',0.7)';
    for(let k=0;k<3;k++){ const yy=z[1]+z[3]-10-((ay+k*10)%30); if(yy>z[1]){ ctx.fillRect(z[0]+7,yy,2,1); ctx.fillRect(z[0]+6,yy+1,4,1); } }
  }
}
function drawBullet(b){
  const c=b.c||b.owner.pal.hair,x=Math.round(b.x),y=Math.round(b.y),dir=b.vx>=0?1:-1;
  if(b.wave){
    ctx.fillStyle=c;
    for(let i=-7;i<=7;i++){ const off=Math.floor(i*i/12); ctx.fillRect(x-dir*off-(dir>0?1:0),y+i,2,1); }
    ctx.fillStyle='#ffffff';
    for(let i=-5;i<=5;i++){ const off=Math.floor(i*i/12); ctx.fillRect(x-dir*off,y+i,1,1); }
    return;
  }
  if(b.flame){
    const sz=Math.min(5,2+Math.floor((0.32-Math.max(0,b.life))*8));
    ctx.fillStyle=Math.random()<0.5?'#ff8a2e':'#ffd23f'; ctx.fillRect(x-1,y-1,sz,sz); return;
  }
  if(b.grav){
    ctx.fillStyle='#22301f'; ctx.fillRect(x-2,y-2,5,5);
    ctx.fillStyle=(Math.floor(Math.max(0,b.life)*14)%2)?'#ff5a3d':'#b8ff8a'; ctx.fillRect(x-1,y-1,3,3); return;
  }
  if(b.boom){
    ctx.fillStyle='#ffe08a'; ctx.fillRect(x-3,y-1,6,3); ctx.fillStyle='#ff7a3d'; ctx.fillRect(x-4,y,2,1);
    ctx.fillStyle='#ffffff'; ctx.fillRect(x+1,y-1,2,1); return;
  }
  if(b.blen){ const BL=b.blen,x0=dir>0?x-BL+2:x-2; ctx.fillStyle=b.blen>=9?'#7a4a22':c; ctx.fillRect(x0,y,BL,1); ctx.fillStyle=c; ctx.fillRect(dir>0?x+1:x-3,y-1,3,3); ctx.fillStyle='#ffffff'; ctx.fillRect(dir>0?x+2:x-2,y,1,1); ctx.fillStyle=b.blen>=9?'#e6d2a8':'#ffffff'; ctx.fillRect(dir>0?x0:x0+BL-1,y-1,1,3); return; }
  const L=b.big?6:4,dx=dir>0?-L+2:-2;
  ctx.fillStyle=b.big?'#ffd23f':c; ctx.fillRect(x+dx,y-(b.big?2:1),L,b.big?4:2);
  ctx.fillStyle='#ffffff'; ctx.fillRect(x-1,y-1,2,1);
}
function drawParts(){
  for(const p of parts){
    ctx.globalAlpha=Math.max(0,Math.min(1,p.life/p.max*1.4));
    ctx.fillStyle=p.c; ctx.fillRect(Math.round(p.x),Math.round(p.y),p.s,p.s);
  }
  ctx.globalAlpha=1;
}
function drawMini(){
  const mw=120,mx=Math.round(W/2-mw/2),my=2,mh=6,vw=Math.min(mw,Math.max(3,Math.round(VW/WW*mw))),vx=mx+Math.round(Math.max(0,Math.min(Math.max(0,WW-VW),camX))/WW*mw);
  ctx.fillStyle='rgba(0,0,0,0.65)'; ctx.fillRect(mx-1,my-1,mw+2,mh+2);
  ctx.fillStyle='rgba(255,255,255,0.14)'; ctx.fillRect(mx,my,mw,mh);
  ctx.fillStyle='rgba(255,255,255,0.45)'; ctx.fillRect(vx,my,vw,1); ctx.fillRect(vx,my+mh-1,vw,1);
  if(mode==='td'){
    ctx.fillStyle='rgba(56,182,255,0.55)'; ctx.fillRect(mx,my,Math.max(2,Math.round(ZL[2]/WW*mw)+2),mh);
    ctx.fillStyle='rgba(255,77,94,0.55)'; const gw=Math.max(2,Math.round(ZR[2]/WW*mw)+2); ctx.fillRect(mx+mw-gw,my,gw,mh);
  }
  for(const f of fighters){
    if(f.dead) continue;
    const big=f.role==='chaser'||f===fighters[0],dx=mx+Math.round(f.x/WW*mw);
    ctx.fillStyle=mode==='td'?(f.team==='blue'?'#38b6ff':'#ff4d5e'):(f.role==='chaser'?'#ff4d5e':(f===fighters[0]?'#ffe066':'#4ade80'));
    if(mode==='td'&&f===fighters[0]){ ctx.fillStyle='#ffffff'; }
    ctx.fillRect(dx-(big?1:0),my+1,big?3:2,mh-2);
  }
  if(mode==='td'&&ball&&!ball.hidden){ const bx=mx+Math.round(ball.x/WW*mw); ctx.fillStyle='#ffd23f'; ctx.fillRect(bx-1,my,3,mh); ctx.fillStyle='#fff3b0'; ctx.fillRect(bx,my+1,1,mh-2); }
}
/* arrow + distance pointing at the chaser (or at the nearest target if you are the chaser) when off screen */
function drawOffscreen(){
  const p=fighters[0]; if(!p||p.dead) return;
  if(mode==='td'){
    if(!ball) return;
    let tx,ty,col,lab;
    if(p.ball){ const z=p.team==='blue'?ZR:ZL; tx=z[0]+z[2]/2; ty=z[1]+z[3]/2; col=p.team==='blue'?'#ff4d5e':'#38b6ff'; lab='GOAL'; }
    else if(!ball.hidden&&!(ball.carrier&&ball.carrier.team===p.team)){ tx=ball.x; ty=ball.y; col='#ffd23f'; lab='BALL'; }
    else return;
    const sx=(tx-camX)*ZOOM,sy=(ty-camY)*ZOOM;
    if(sx>=4&&sx<=W-4&&sy>=4&&sy<=H-4) return;
    const ax=Math.max(12,Math.min(W-12,sx)),ay=Math.max(28,Math.min(H-14,sy)),dx=sx-W/2,dy=sy-H/2;
    const ch=Math.abs(dx)*0.56>Math.abs(dy)?(dx<0?'<':'>'):(dy<0?'^':'v');
    txt(ch,ax,ay-5,col,'center',14);
    txt(lab+' '+Math.round(Math.hypot(tx-p.x,ty-p.y)/8)+'M',ax,ay+6,col,'center');
    return;
  }
  let tg=null,bd=1e9;
  for(const f of fighters){
    if(f===p||f.dead) continue;
    if(p.role==='chaser'||f.role==='chaser'){ const d=Math.hypot(f.x-p.x,f.y-p.y); if(d<bd){ bd=d; tg=f; } }
  }
  if(!tg) return;
  const sx=(tg.x-camX)*ZOOM,sy=(tg.y-8-camY)*ZOOM;
  if(sx>=4&&sx<=W-4&&sy>=4&&sy<=H-4) return;
  const col=tg.role==='chaser'?'#ff4d5e':'#4ade80';
  const ax=Math.max(12,Math.min(W-12,sx)),ay=Math.max(28,Math.min(H-14,sy));
  const dx=sx-W/2,dy=sy-H/2;
  const ch=Math.abs(dx)*0.56>Math.abs(dy)?(dx<0?'<':'>'):(dy<0?'^':'v');
  txt(ch,ax,ay-5,col,'center',14);
  txt(Math.round(bd/8)+'M',ax,ay+6,col,'center');
}
function drawCountdown(){
  if(cdT>0){
    const n=Math.ceil(cdT),fr=1-(n-cdT);                 /* 0 at the start of each second, 1 at the end */
    const sc=1.6-0.6*Math.min(1,fr*2.5);
    txt('GET READY',W/2,34,'#ffffff','center');
    ctx.save(); ctx.translate(W/2,66); ctx.scale(sc,sc); txt(String(n),0,-10,'#ffd23f','center',40); ctx.restore();
    txt(mode==='td'?'CARRY THE BALL TO THE ENEMY BASE - FIRST TO '+GOALS_TO_WIN:'FIRST TO '+KILLS_TO_WIN+' KILLS WINS',W/2,92,'#c9c4ff','center');
  } else if(goT>0){
    const k=goT/0.9; ctx.globalAlpha=Math.min(1,k*2);
    ctx.save(); ctx.translate(W/2,66); ctx.scale(1+(1-k)*0.5,1+(1-k)*0.5); txt('GO!',0,-10,'#7dffea','center',40); ctx.restore();
    ctx.globalAlpha=1;
  }
}
function drawHUD(){
  const p=fighters[0];
  txt('HP',12,11,'#ffffff');
  ctx.fillStyle='rgba(0,0,0,0.6)'; ctx.fillRect(29,11,58,5);
  const hp=Math.max(0,p.hp)/fmax(p);
  ctx.fillStyle=hp>0.5?'#4ade80':hp>0.25?'#fbbf24':'#ef4444'; ctx.fillRect(30,12,Math.round(56*hp),3);
  txt(p.wd[p.weapon].name,12,23,p.weapon===0?'#9ff3ff':'#ffd166');
  txt('+'+earned+' COINS',12,41,'#ffd23f');
  if(NET.on) txt(NET.client?'PING '+NET.rtt+' MS':'HOSTING '+(NET.humans?NET.humans.length:1)+' PLAYERS',12,86,'#8f8bb0');
  if(NET.client&&NET.lag) txt('CONNECTION LAG...',W/2,118,'#ff8a8a','center');
  { const skd=SKILLS[p.sk];
    if(skd&&skd.kind!=='none'){
      let touchUI=false; try{ touchUI=document.documentElement.classList.contains('touch'); }catch(e){}
      txt((touchUI?'':'[E] ')+skd.name+(p.skOn?' ON':''),12,62,p.skOn?'#7dffea':'#c9c4ff');
      ctx.fillStyle='rgba(0,0,0,0.6)'; ctx.fillRect(12,71,58,5);
      const sfr=Math.max(0,p.sp)/p.maxsp; ctx.fillStyle=sfr<0.2?'#ff6a6a':(p.skOn?'#7dffea':'#38b6ff'); ctx.fillRect(13,72,Math.round(56*sfr),3);
      skillBtnAct(!!p.skOn);
    } else skillBtnAct(false);
  }
  if(p.weapon===0){ const lit=p.comboT>0?p.combo+1:0; for(let i=0;i<3;i++){ ctx.fillStyle=i<lit?(i===2?'#ffd23f':'#9ff3ff'):'rgba(255,255,255,0.2)'; ctx.fillRect(12+i*8,52,6,4); } }
  ctx.fillStyle='rgba(0,0,0,0.6)'; ctx.fillRect(12,33,34,4);
  ctx.fillStyle=p.dashCd<=0?'#38b6ff':'#4b5d80'; ctx.fillRect(13,34,Math.round(32*(1-Math.max(0,p.dashCd)/(0.75*p.dcdm))),2);
  if(mode==='dm'){
    txt('KILLS '+p.kills+'/'+KILLS_TO_WIN,W/2,11,'#ffffff','center');
  } else if(mode==='ch'){
    const mm=Math.max(0,Math.ceil(chTime));
    txt(Math.floor(mm/60)+':'+String(mm%60).padStart(2,'0'),W/2,11,'#ffffff','center');
    txt('ROUND '+chRound+'/'+CH_ROUNDS+'   YOU '+p.score+' PTS',W/2,21,'#ffd23f','center');
    if(chaser){
      const left=fighters.filter(function(f){return f.role==='runner'&&!f.dead;}).length;
      txt('CHASER '+chaser.name+'   TARGETS LEFT '+left,W/2,32,'#ff8a8a','center');
      drawChaserBar(chaser);
    }
    if(chPhase==='count'&&chaser){
      ctx.fillStyle='rgba(8,6,20,0.5)'; ctx.fillRect(0,54,W,64);
      txt('CHASER: '+chaser.name,W/2,60,'#ff4d5e','center',16);
      txt(p===chaser?'HUNT THEM ALL DOWN!':'SURVIVE '+(CH_TIME/60)+' MINUTES!',W/2,78,'#ffffff','center');
      txt(String(Math.ceil(chPT)),W/2,92,'#ffd23f','center',24);
    }
  } else {
    txt('BLUE '+scores.blue,W/2-8,11,'#38b6ff','right');
    txt('-',W/2,11,'#ffffff','center');
    txt('RED '+scores.red,W/2+8,11,'#ff4d5e','left');
    if(p.ball&&Math.floor(time*3)%2) txt('TAKE IT TO THE '+(p.team==='blue'?'RED':'BLUE')+' BASE!',W/2,24,'#ffd23f','center');
  }
  drawMini(); drawOffscreen();
  let y=11;
  for(const m of feed){ ctx.globalAlpha=Math.min(1,m.t); txt(m.m,W-12,y,m.c,'right'); y+=9; }
  ctx.globalAlpha=1;
  if(time<1.2) txt('GO!',W/2,74,'#ffffff','center',16);
  if(time<2.4) txt(MAPS[curIdx].name,W/2,94,'#c9c4ff','center');
  if(time<3.5&&state==='play'){
    txt('YOU=GOLD',W/2-90,108,'#ffe066','center');
    if(mode!=='dm'&&!(mode==='ch'&&fighters[0].role==='chaser')) txt('ALLY=GREEN',W/2,108,'#4ade80','center');
    txt('ENEMY=RED',W/2+90,108,'#ff4d5e','center');
  }
  drawCountdown();
  if(banner){ ctx.globalAlpha=Math.min(1,banner.t*2.5); txt(banner.a,W/2,40,banner.c,'center'); if(banner.b) txt(banner.b,W/2,52,'#ffd23f','center',16); ctx.globalAlpha=1; }
  if(mode==='ch'&&chWinT>=0&&chaser) drawChaserWin(p);
  if(p.dead){
    if(mode==='ch') txt('ELIMINATED - WATCHING',W/2,84,'#ffffff','center');
    else {
      txt('RESPAWN IN '+Math.max(1,Math.ceil(p.respawn)),W/2,80,'#ffffff','center',16);
      const bw=64,tot=p.respTotal||RESPAWN_SECS[mode]||2.5,fr=Math.max(0,Math.min(1,1-p.respawn/tot)),bx=Math.round(W/2-bw/2);
      ctx.fillStyle='rgba(0,0,0,0.65)'; ctx.fillRect(bx-1,95,bw+2,4);
      ctx.fillStyle='#ffd23f'; ctx.fillRect(bx,96,Math.round(bw*fr),2);
    }
  }
  if(paused){
    ctx.fillStyle='rgba(8,6,20,0.7)'; ctx.fillRect(0,0,W,H);
    txt(NET.on?'MENU':'PAUSED',W/2,70,'#ffffff','center',16);
    txt(NET.on?'THE MATCH KEEPS RUNNING - TAP TO CLOSE':'P OR TAP TO RESUME',W/2,96,'#c9c4ff','center');
    txt(NET.on?'TAP HERE: LEAVE THE MATCH':'TAP HERE: QUIT',W/2,130,'#ff8a8a','center');
  }
}
/* the chaser's HP bar, always at the top of the screen so everybody can see how close it is to dying */
function drawChaserBar(c){
  const bw=170,bh=9,x=Math.round(W/2-bw/2),y=41;
  const fr=Math.max(0,Math.min(1,c.hp/CH_HP));
  const now=time,gt=Math.min(0.1,Math.max(0,now-(c._gt||now))); c._gt=now;
  if(c._gh===undefined||c._gh<fr) c._gh=fr; else c._gh=Math.max(fr,c._gh-gt*0.35);
  const hit=c.hurt>0,low=fr<0.25&&Math.floor(time*6)%2===0;
  ctx.fillStyle='#07040c'; ctx.fillRect(x-2,y-2,bw+4,bh+4);
  ctx.fillStyle='#2a0f18'; ctx.fillRect(x,y,bw,bh);
  ctx.fillStyle='#ffffff'; ctx.fillRect(x,y,Math.round(bw*c._gh),bh);                  /* trailing damage */
  const fw=Math.round(bw*fr);
  ctx.fillStyle=hit?'#ffffff':(low?'#ffd23f':(fr>0.5?'#e8314a':'#ff6a2a')); ctx.fillRect(x,y,fw,bh);
  ctx.fillStyle='rgba(255,255,255,0.35)'; ctx.fillRect(x,y,fw,2);
  ctx.fillStyle='rgba(0,0,0,0.35)'; ctx.fillRect(x,y+bh-2,fw,2);
  for(let k=1;k<CH_HP/100;k++){ ctx.fillStyle='rgba(7,4,12,0.7)'; ctx.fillRect(x+Math.round(bw*k*100/CH_HP),y,1,bh); }
  ctx.fillStyle='#ffd23f'; ctx.fillRect(x-4,y+1,3,bh-2); ctx.fillRect(x+bw+1,y+1,3,bh-2);   /* end caps */
  txt(Math.max(0,Math.ceil(c.hp))+' / '+CH_HP,W/2,y+bh+3,hit?'#ffffff':'#ffb0b0','center');
}
/* big popup when the chaser has eliminated every target */
function drawChaserWin(p){
  const t=chWinT,al=Math.max(0,Math.min(1,t*6,(3.5-t)*3));
  ctx.globalAlpha=0.6*al; ctx.fillStyle='#ff4d5e'; ctx.fillRect(0,52,W,52);
  ctx.globalAlpha=al; ctx.fillStyle='#000000'; ctx.fillRect(0,52,W,2); ctx.fillRect(0,102,W,2);
  const sc=1+Math.max(0,0.6-t*1.5)*1.2+0.04*Math.sin(t*12);
  ctx.save(); ctx.translate(W/2,68); ctx.scale(sc,sc); txt('CHASER WIN!',0,-8,'#ffffff','center',24); ctx.restore();
  txt(p===chaser?'YOU ELIMINATED EVERYONE':chaser.name+' ELIMINATED EVERYONE',W/2,94,'#ffe066','center');
  ctx.globalAlpha=1;
}
function drawOver(){
  ctx.fillStyle='rgba(8,6,20,0.78)'; ctx.fillRect(40,24,240,132);
  ctx.fillStyle='#8a7cf0'; ctx.fillRect(40,24,240,2); ctx.fillRect(40,154,240,2);
  const p=fighters[0]; let title,col;
  if(mode!=='td'){ const w=winner===p; title=w?'YOU WIN!':winner.name+' WINS'; col=w?'#ffd23f':'#ff8a8a'; }
  else { const w=winTeam===p.team; title=w?'VICTORY!':'DEFEAT'; col=w?'#ffd23f':'#ff8a8a'; }
  txt(title,W/2,34,col,'center',16);
  if(mode!=='td'){
    const l=fighters.slice().sort(function(a,b){return mode==='ch'?((b.score-a.score)||(b.kills-a.kills)):(b.kills-a.kills);});
    const stp=Math.min(11,Math.floor(74/l.length));
    l.forEach(function(f,i){ txt((i+1)+'. '+f.name+' '+(mode==='ch'?f.score+' PTS '+f.kills+' K':f.kills+' K '+f.deaths+' D'),W/2,46+i*stp,f.pal.main,'center'); });
  } else {
    txt('BLUE '+scores.blue+'  -  '+scores.red+' RED',W/2,68,'#ffffff','center');
    txt('YOUR KILLS '+p.kills+'  DEATHS '+p.deaths,W/2,88,'#c9c4ff','center');
  }
  if(lastResult) txt('+'+lastResult.earned+' COINS (BONUS '+lastResult.bonus+')',W/2,118,'#ffd23f','center');
  if(overT>0.8&&Math.floor(menuT*2)%2) txt('TAP TO CONTINUE',W/2,138,'#ffffff','center');
}
/* ---------- touchdown celebration drawing ---------- */
function drawCeleb(){
  if(!celeb) return;
  const t=celeb.t,col=celeb.col,z=celeb.team==='blue'?ZR:ZL;
  ctx.save(); ctx.scale(ZOOM,ZOOM); ctx.translate(-Math.round(camX),-Math.round(camY));
  ctx.globalAlpha=0.22+0.12*Math.sin(t*14); ctx.fillStyle=col; ctx.fillRect(z[0]+3,0,z[2]-6,z[1]+z[3]);
  ctx.globalAlpha=0.5; ctx.fillStyle='#ffffff'; ctx.fillRect(z[0]+7,0,z[2]-14,z[1]+z[3]); ctx.globalAlpha=1;
  for(const f of fireworks){ ctx.fillStyle=f.c; ctx.fillRect(Math.round(f.x),Math.round(f.y),2,4); ctx.fillStyle='#ffffff'; ctx.fillRect(Math.round(f.x),Math.round(f.y),2,1); }
  ctx.restore();
  const al=Math.min(Math.min(1,t*6),Math.max(0,Math.min(1,(celeb.dur-t)*4)));
  ctx.globalAlpha=0.55*al; ctx.fillStyle=col; ctx.fillRect(0,56,W,50);
  ctx.globalAlpha=al; ctx.fillStyle='#000000'; ctx.fillRect(0,56,W,2); ctx.fillRect(0,104,W,2);
  const sc=1+Math.max(0,0.6-t*1.5)*1.2+0.04*Math.sin(t*12);
  ctx.save(); ctx.translate(W/2,70); ctx.scale(sc,sc); txt(celeb.win?'VICTORY!':'TOUCHDOWN!',0,-8,'#ffffff','center',16); ctx.restore();
  txt(celeb.name+' SCORES FOR '+(celeb.team==='blue'?'BLUE':'RED'),W/2,90,'#ffffff','center');
  ctx.globalAlpha=1;
  txt('BLUE '+scores.blue+'  -  '+scores.red+' RED',W/2,112,'#ffffff','center');
}
/* ---------- slash arcs & beams ---------- */
function drawSlash(s){
  if(s.claw&&!s.sub){ drawSlash(Object.assign({},s,{r:s.r+3,color:'#ff5a1f',big:true,sub:1})); drawSlash(Object.assign({},s,{color:'#ffd23f',big:false,sub:1})); return; }
  const p=Math.min(1,s.t/s.life),grow=Math.min(1,s.t/(s.life*0.55));
  ctx.globalAlpha=Math.max(0,1-p*p);
  if(s.thrust){
    const L=Math.round(s.r*(0.5+0.6*grow)),x0=Math.round(s.x),y0=Math.round(s.y+2);
    for(let i=0;i<L;i++){
      const px=x0+s.face*(6+i),th=i>L*0.6?1:2;
      ctx.fillStyle=s.color; ctx.fillRect(px,y0-th,1,th*2);
      ctx.fillStyle='#ffffff'; ctx.fillRect(px,y0,1,1);
    }
    ctx.globalAlpha=1; return;
  }
  const A=s.step===1?[0.7,-1.2]:s.step===2?[-1.9,1.2]:[-1.4,0.6];
  const a1=A[0]+(A[1]-A[0])*grow,n=Math.max(4,Math.round(Math.abs(a1-A[0])*s.r*0.5));
  for(let i=0;i<=n;i++){
    const u=i/n,a=A[0]+(a1-A[0])*u,th=Math.max(1,Math.round((s.big?5:3)*(0.35+0.65*u)*(s.step===2?1.3:1)));
    for(let k=0;k<th;k++){
      const rr=s.r-k;
      const px=Math.round(s.x+s.face*Math.cos(a)*rr),py=Math.round(s.y+Math.sin(a)*rr);
      ctx.fillStyle=k===0?'#ffffff':s.color; ctx.fillRect(px,py,s.big?2:1,s.big?2:1);
    }
  }
  ctx.globalAlpha=1;
}
function drawSlashes(){ for(const s of slashes) drawSlash(s); }
function drawBeams(){
  for(const b of beams){
    const p=b.t/b.life; ctx.globalAlpha=Math.max(0,1-p);
    const dx=b.x2-b.x1,dy=b.y2-b.y1,len=Math.hypot(dx,dy),n=Math.max(1,Math.ceil(len/2));
    for(let i=0;i<=n;i++){
      const u=i/n; let x=b.x1+dx*u,y=b.y1+dy*u;
      if(b.zig){ y+=(Math.random()-0.5)*5; x+=(Math.random()-0.5)*3; }
      ctx.fillStyle=b.c; ctx.fillRect(Math.round(x)-(b.th>>1),Math.round(y)-(b.th>>1),b.th,b.th);
      if(!b.zig&&i%2===0){ ctx.fillStyle='#ffffff'; ctx.fillRect(Math.round(x),Math.round(y),1,1); }
    }
  }
  ctx.globalAlpha=1;
}
/* ---------- effects drawing ---------- */
function offView(x,w,m){ return PERF.cull&&(x+w<camX-m||x>camX+VW+m); }
function drawHazards(){
  for(const h of HAZ){
    if(offView(h[0],h[2],12)) continue;
    /* heat glow above the surface */
    for(let k=0;k<10;k++){ ctx.fillStyle='rgba(255,120,40,'+(0.012*(10-k)).toFixed(3)+')'; ctx.fillRect(h[0],h[1]-k-1,h[2],1); }
    ctx.fillStyle='#7a1608'; ctx.fillRect(h[0],h[1]+3,h[2],H-h[1]-3);
    ctx.fillStyle='#a82a0c'; ctx.fillRect(h[0],h[1]+8,h[2],H-h[1]-8);
    for(let px=0;px<h[2];px+=2){
      const o=Math.round(Math.sin(px*0.35+menuT*4)*1.5);
      ctx.fillStyle='#ff5a1f'; ctx.fillRect(h[0]+px,h[1]+o,2,H-h[1]-o);
      ctx.fillStyle='#ff8a2e'; ctx.fillRect(h[0]+px,h[1]+o+2,2,2);
      ctx.fillStyle='#ffb02e'; ctx.fillRect(h[0]+px,h[1]+o,2,2);
      if(((px>>1)+Math.floor(menuT*3))%7===0){ ctx.fillStyle='#fff3b0'; ctx.fillRect(h[0]+px,h[1]+o,2,1); }
    }
    if(TICK&&state==='play'&&!paused&&Math.random()<0.25) parts.push({x:h[0]+Math.random()*h[2],y:h[1],vx:(Math.random()-0.5)*20,vy:-40-Math.random()*50,life:0.6,max:0.6,c:Math.random()<0.5?'#ffb02e':'#ff5a1f',s:1,g:120});
  }
}
function drawPads(){
  for(const pd of PADS){
    const c=Math.round(pd.sq*3),mx=pd.x+Math.round(pd.w/2);
    /* base plate */
    ctx.fillStyle='#2a2f44'; ctx.fillRect(pd.x,pd.y-2,pd.w,2);
    ctx.fillStyle='#4a5070'; ctx.fillRect(pd.x,pd.y-2,pd.w,1);
    /* coil */
    ctx.fillStyle='#c9ced8';
    for(let k=0;k<3;k++){ const yy=pd.y-3-Math.round(k*(1-pd.sq*0.5)); ctx.fillRect(pd.x+3+(k%2)*2,yy+c,pd.w-6-(k%2)*2,1); }
    /* pad */
    ctx.fillStyle='#ff5ec8'; ctx.fillRect(pd.x,pd.y-6+c,pd.w,2);
    ctx.fillStyle='#ffd1f0'; ctx.fillRect(pd.x+1,pd.y-7+c,pd.w-2,1);
    ctx.fillStyle='#b02a8a'; ctx.fillRect(pd.x,pd.y-5+c,pd.w,1);
    /* bouncing arrow */
    const ay=Math.floor(menuT*6)%3;
    ctx.fillStyle='rgba(255,209,240,0.85)';
    ctx.fillRect(mx-1,pd.y-12-ay*3,2,1); ctx.fillRect(mx-2,pd.y-11-ay*3,4,1); ctx.fillRect(mx-3,pd.y-10-ay*3,6,1);
  }
}
function drawCorpses(){
  for(const c of corpses){
    const rem=c.life-c.t;
    if(rem<0.5&&Math.floor(rem*20)%2) continue;
    ctx.save(); ctx.translate(Math.round(c.x),Math.round(c.y-7)); ctx.rotate(c.rot);
    const f=c.f; f.x=0; f.y=7; f.hurt=c.t<c.hurtT?1:0; f.inv=0; f.anim=0; f.vx=0; f.onGround=false; f.dashT=0; f.swing=0; f.flash=0; f.recoil=0; f.aimT=0;
    drawFighter(f); ctx.restore();
  }
}
function drawRings(){
  for(const r of rings){
    const p=r.t/r.life,rad=r.r+(r.max-r.r)*p;
    ctx.globalAlpha=Math.max(0,1-p); ctx.fillStyle=r.c;
    const n=Math.max(8,Math.round(rad*1.4));
    for(let k=0;k<n;k++){ const a=k/n*6.283; ctx.fillRect(Math.round(r.x+Math.cos(a)*rad),Math.round(r.y+Math.sin(a)*rad),2,2); }
  }
  ctx.globalAlpha=1;
}
function drawTexts(){
  for(const t of texts){ ctx.globalAlpha=Math.min(1,t.t*3); txt(t.m,Math.round(t.x),Math.round(t.y),t.c,'center'); }
  ctx.globalAlpha=1;
}
/* ---------- shop ---------- */
let shopTab=0,shopSel=0,shopScroll=0,shopMsg='',shopMsgT=0,showSB=false,resetArm=false;
const SHOP_ROWS=8,SHOP_RH=12,SHOP_RW=210;
const R_BACK=[250,6,58,14],R_TAB0=[12,28,52,12],R_TAB1=[68,28,44,12],R_TAB2=[116,28,76,12],R_TAB3=[196,28,52,12],R_TAB4=[252,28,56,12],R_RESET=[170,148,138,14];
function inR(x,y,r){ return x>=r[0]&&x<=r[0]+r[2]&&y>=r[1]&&y<=r[1]+r[3]; }
function shopItems(){
  if(shopTab===4) return SKILL_LIST.map(function(i){return SKILLS[i];});
  if(shopTab===3) return REAP_LIST.map(function(i){return REAPERS[i];});
  if(shopTab===2) return CHAR_LIST.map(function(i){return CHARS[i];});
  return WEAP_LIST.map(function(i){return WEAP[i];}).filter(function(w){return w.slot===shopTab;});
}
function isOwned(id){ return SV.owned.indexOf(id)>=0; }
function isEquipped(it){ return shopTab===4?SV.eq.skill===it.id:shopTab===3?SV.eq.reaper===it.id:shopTab===2?SV.eq.char===it.id:(it.slot===0?SV.eq.melee===it.id:SV.eq.gun===it.id); }
function shopClamp(){
  const n=shopItems().length;
  shopSel=Math.max(0,Math.min(shopSel,n-1));
  if(shopSel<shopScroll) shopScroll=shopSel;
  if(shopSel>=shopScroll+SHOP_ROWS) shopScroll=shopSel-SHOP_ROWS+1;
  shopScroll=Math.max(0,Math.min(shopScroll,Math.max(0,n-SHOP_ROWS)));
}
function setTab(t){ shopTab=t; shopSel=0; shopScroll=0; }
function openShop(){ state='shop'; setTab(0); shopMsg=''; shopMsgT=0; sfx('pick'); }
function openStats(){ state='stats'; resetArm=false; sfx('pick'); }
function shopActivate(it){
  const own=isOwned(it.id);
  if(!own){
    if(SV.coins<it.cost){ shopMsg='NEED '+(it.cost-SV.coins)+' MORE COINS'; shopMsgT=2; sfx('hit'); return; }
    SV.coins-=it.cost; SV.owned.push(it.id); shopMsg='BOUGHT AND EQUIPPED '+it.name; shopMsgT=2.2; sfx('score');
  } else { shopMsg='EQUIPPED '+it.name; shopMsgT=1.6; sfx('pick'); }
  if(shopTab===4) SV.eq.skill=it.id; else if(shopTab===3) SV.eq.reaper=it.id; else if(shopTab===2) SV.eq.char=it.id; else if(it.slot===0) SV.eq.melee=it.id; else SV.eq.gun=it.id;
  persist();
}
function shopKey(k){
  const n=shopItems().length;
  if(k==='ArrowUp'||k==='w'){ shopSel=(shopSel+n-1)%n; shopClamp(); }
  else if(k==='ArrowDown'||k==='s'){ shopSel=(shopSel+1)%n; shopClamp(); }
  else if(k==='ArrowRight'||k==='d') setTab((shopTab+1)%5);
  else if(k==='ArrowLeft'||k==='a') setTab((shopTab+4)%5);
  else if(k==='Enter'||k===' ') shopActivate(shopItems()[shopSel]);
  else if(k==='Escape'||k==='Backspace') state='menu';
}
function shopClick(x,y){
  if(inR(x,y,R_BACK)){ state='menu'; return; }
  if(inR(x,y,R_TAB0)){ setTab(0); return; }
  if(inR(x,y,R_TAB1)){ setTab(1); return; }
  if(inR(x,y,R_TAB2)){ setTab(2); return; }
  if(inR(x,y,R_TAB3)){ setTab(3); return; }
  if(inR(x,y,R_TAB4)){ setTab(4); return; }
  const items=shopItems();
  if(inR(x,y,[214,44,14,40])){ shopSel=Math.max(0,shopSel-1); shopClamp(); return; }
  if(inR(x,y,[214,96,14,44])){ shopSel=Math.min(items.length-1,shopSel+1); shopClamp(); return; }
  for(let i=0;i<SHOP_ROWS;i++){
    const idx=shopScroll+i; if(idx>=items.length) break;
    if(inR(x,y,[12,44+i*SHOP_RH,SHOP_RW,SHOP_RH-1])){
      if(shopSel===idx) shopActivate(items[idx]); else { shopSel=idx; sfx('pick'); }
      return;
    }
  }
}
function btn(r,label,on){
  ctx.fillStyle=on?'#8a7cf0':'#2a2050'; ctx.fillRect(r[0],r[1],r[2],r[3]);
  ctx.fillStyle=on?'#e0dbff':'#5d50b8'; ctx.fillRect(r[0],r[1],r[2],1); ctx.fillRect(r[0],r[1]+r[3]-1,r[2],1);
  txt(label,r[0]+Math.round(r[2]/2),r[1]+Math.round((r[3]-8*TS)/2),'#ffffff','center');
}
function drawShop(){
  ctx.fillStyle='rgba(10,8,25,0.9)'; ctx.fillRect(UI.x0,UI.y0,UI.w,UI.h);
  txt('SHOP',12,6,'#ffdd55','left',16);
  txt('COINS '+SV.coins,244,10,'#ffd23f','right');
  btn(R_BACK,'BACK',false); btn(R_TAB0,'MELEE',shopTab===0); btn(R_TAB1,'GUNS',shopTab===1); btn(R_TAB2,'CHARACTERS',shopTab===2); btn(R_TAB3,'REAPER',shopTab===3); btn(R_TAB4,'SKILLS',shopTab===4);
  shopClamp();
  const items=shopItems();
  for(let i=0;i<SHOP_ROWS;i++){
    const idx=shopScroll+i; if(idx>=items.length) break;
    const it=items[idx],y=44+i*SHOP_RH,sel=idx===shopSel;
    ctx.fillStyle=sel?'#3b2f7a':'#1d1740'; ctx.fillRect(12,y,SHOP_RW,SHOP_RH-1);
    if(sel){ ctx.fillStyle='#8a7cf0'; ctx.fillRect(12,y,SHOP_RW,1); ctx.fillRect(12,y+SHOP_RH-2,SHOP_RW,1); ctx.fillRect(12,y,1,SHOP_RH-1); ctx.fillRect(12+SHOP_RW-1,y,1,SHOP_RH-1); }
    txt(it.name,18,y+2,'#ffffff');
    const eq=isEquipped(it),own=isOwned(it.id),rx=12+SHOP_RW-4;
    if(eq) txt('EQUIPPED',rx,y+2,'#4ade80','right');
    else if(own) txt('OWNED',rx,y+2,'#c9c4ff','right');
    else txt(it.cost+' COINS',rx,y+2,SV.coins>=it.cost?'#ffd23f':'#ff8a8a','right');
  }
  if(shopScroll>0) txt('^',218,46,'#ffffff','center');
  if(shopScroll+SHOP_ROWS<items.length) txt('v',218,128,'#ffffff','center');
  const it=items[shopSel]; let d2,pvSlash=null;
  const cc=shopTab===2?it:(CHARS[SV.eq.char]||CHARS.rush);
  const pv=mk(99,'P','pv',{main:cc.main,dark:cc.dark,hair:cc.hair},false);
  pv.style=cc.style; pv.noBar=true; pv.onGround=true; pv.placed=true; pv.anim=menuT; pv.face=1;
  pv.wd=[WEAP[SV.eq.melee]||WEAP.pulse,WEAP[SV.eq.gun]||WEAP.blaster]; pv.weapon=1;
  ctx.fillStyle='rgba(138,124,240,0.12)'; ctx.fillRect(232,44,76,96);
  if(shopTab===0){
    d2='DMG '+it.dmg+'  DELAY '+it.cd.toFixed(2)+'S  RANGE '+it.range+(it.steal?'  HEALS':'');
    pv.wd[0]=it; pv.weapon=0; const ph=menuT%1.3,stp=Math.floor(menuT/1.3)%3; pv.swingStep=stp; pv.swingRange=Math.round(it.range*(stp===2?1.2:1)); const du=it.dur*(stp===2?1.25:1); pv.swingDur=du; pv.swing=ph<du?du-ph:0;
    pvSlash=ph<0.22?{x:2,y:-9,face:1,step:stp,t:ph,life:it.thrust?0.14:0.2,r:Math.round(pv.swingRange*0.85),color:it.color,big:!!it.big||stp===2,thrust:!!it.thrust}:null;
  } else if(shopTab===1){
    d2='DMG '+it.dmg+(it.pellets>1?'X'+it.pellets:'')+'  DELAY '+it.cd.toFixed(2)+'S'+(it.pierce?'  PIERCES':'')+(it.bounce?'  BOUNCES':'')+(it.boom?'  EXPLODES':'');
    pv.wd[1]=it; pv.weapon=1; const ph=menuT%1.0; pv.recoil=Math.max(0,1-ph*7); pv.flash=ph<0.07?0.06:0; pv.aimT=0;
    if(ph<0.5){
      ctx.fillStyle=it.bc||'#ffffff';
      const bx=Math.round(284+ph*70);
      if(bx<304) for(let k=0;k<it.pellets;k++) ctx.fillRect(bx,Math.round(92+(k-(it.pellets-1)/2)*4),it.boom?5:4,2);
    }
  } else if(shopTab===2){
    d2='HP '+it.hp+'  SPEED '+Math.round(it.spd*100)+'%  DASH CD '+Math.round(it.dcd*100)+'%';
  } else if(shopTab===3){
    d2='LOOK ONLY - SHOWN WHEN YOU ARE THE CHASER';
  } else {
    d2=it.kind==='none'?'UNEQUIP YOUR SKILL':
       'COSTS '+it.use+' SP'+(it.drain?'  THEN '+it.drain+' SP/S':'')+(it.kind==='block'?'  '+it.hp+' HP WALL':'')+(it.kind==='fly'?'  JUMP = RISE':'');
    pv.sk=it.id; pv.skOn=it.kind==='shield'; pv.flying=it.kind==='fly'; pv.id=7;
    if(pv.flying) pv.y=-8+Math.round(Math.sin(menuT*4)*2);
  }
  ctx.fillStyle='#8a7cf0'; ctx.fillRect(240,118,60,3);
  if(shopTab===3){ const ph=menuT%1.6; ctx.save(); ctx.translate(268,104+Math.round(Math.sin(menuT*3)*2)); ctx.scale(2,2); drawReaperAt(it,menuT,ph<0.25?ph/0.25:0,1); ctx.restore(); }
  else { ctx.save(); ctx.translate(268,116); ctx.scale(3,3); drawFighter(pv); if(pvSlash) drawSlash(pvSlash);
    if(shopTab===4&&it.kind==='block'){ const ph2=menuT%2.4,q=Math.min(1,ph2/0.2); drawBlockSprite({x:10,y:0,w:6,h:Math.round(30*q),hp:ph2>1.4?60:150,max:150,flash:(ph2>1.4&&ph2<1.5)?1:0,t:9,owner:pv}); }
    ctx.restore(); }
  txt(it.desc,12,146,'#ffffff'); txt(d2,12,157,'#c9c4ff');
  if(shopMsgT>0) txt(shopMsg,12,168,'#ffd23f'); 
}
/* ---------- stats dashboard ---------- */
function doReset(){
  if(!resetArm){ resetArm=true; sfx('hit'); }
  else { SV=defSave(); persist(); resetArm=false; sfx('die'); }
}
function statsKey(k){
  if(k==='Escape'||k==='Backspace'||k==='Enter') state='menu';
  else if(k==='r') doReset();
}
function statsClick(x,y){
  if(inR(x,y,R_BACK)){ state='menu'; return; }
  if(inR(x,y,R_RESET)) doReset();
}
function drawStats(){
  ctx.fillStyle='rgba(10,8,25,0.88)'; ctx.fillRect(UI.x0,UI.y0,UI.w,UI.h);
  txt('STATS',12,6,'#ffdd55','left',16);
  txt('COINS '+SV.coins,244,10,'#ffd23f','right');
  btn(R_BACK,'BACK',false);
  const kd=SV.deaths?(SV.kills/SV.deaths).toFixed(2):SV.kills.toFixed(2);
  const wr=SV.matches?Math.round(SV.wins/SV.matches*100)+'%':'-';
  const rows=[['KILLS',SV.kills],['DEATHS',SV.deaths],['K/D',kd],['MATCHES',SV.matches],['WINS',SV.wins],['LOSSES',SV.losses],
    ['WIN RATE',wr],['GOALS',SV.goals],['BEST KILLS',SV.bestKills],['COINS EARNED',SV.totalCoins]];
  rows.forEach(function(r,i){ const y=30+i*12; txt(r[0],12,y,'#c9c4ff'); txt(String(r[1]),152,y,'#ffffff','right'); });
  txt('KILLS',170,30,'#c9c4ff');
  const h=SV.hist;
  if(!h.length){ txt('NO MATCHES YET',170,70,'#8f8bb0'); txt('PLAY ONE TO FILL',170,82,'#8f8bb0'); txt('THIS CHART',170,94,'#8f8bb0'); }
  else {
    let mx=5; for(const m of h) mx=Math.max(mx,m.k);
    txt('MAX '+mx,308,30,'#8f8bb0','right');
    ctx.fillStyle='#2a2050'; ctx.fillRect(170,112,138,1);
    h.forEach(function(m,i){
      const bh=Math.max(1,Math.round(m.k/mx*56)),bx=170+i*14;
      ctx.fillStyle=m.w?'#4ade80':'#ff6b7a'; ctx.fillRect(bx,112-bh,11,bh);
      txt(m.m==='dm'?'D':(m.m==='ch'?'C':'T'),bx+5,115,'#8f8bb0','center');
    });
    const l=h[h.length-1];
    txt('LAST '+(l.w?'WIN ':'LOSS ')+l.k+'/'+l.d+' +'+l.c,170,137,'#ffffff');
  }
  txt('GREEN WIN',170,126,'#4ade80'); txt('RED LOSS',250,126,'#ff6b7a');
  btn(R_RESET,resetArm?'CONFIRM RESET?':'RESET PROGRESS',resetArm);
}
/* ---------- in-game scoreboard ---------- */
function drawScoreboard(){
  ctx.fillStyle='rgba(8,6,20,0.84)'; ctx.fillRect(50,30,220,122);
  ctx.fillStyle='#8a7cf0'; ctx.fillRect(50,30,220,1); ctx.fillRect(50,151,220,1);
  txt(mode==='dm'?'SCOREBOARD  TO '+KILLS_TO_WIN:(mode==='ch'?'CHASER  ROUND '+chRound+'/'+CH_ROUNDS:'BLUE '+scores.blue+' - '+scores.red+' RED'),W/2,36,'#ffffff','center');
  txt('NAME',72,52,'#8f8bb0'); txt(mode==='ch'?'PTS':'K',200,52,'#8f8bb0','right'); txt('D',240,52,'#8f8bb0','right');
  const l=fighters.slice().sort(function(a,b){
    if(mode==='td'&&a.team!==b.team) return a.team==='blue'?-1:1;
    return mode==='ch'?(b.score-a.score):(b.kills-a.kills);
  });
  l.forEach(function(f,i){
    const y=60+i*Math.min(12,Math.floor(88/l.length));
    if(f===fighters[0]){ ctx.fillStyle='rgba(255,255,255,0.1)'; ctx.fillRect(56,y-2,208,11); }
    ctx.fillStyle=f.pal.main; ctx.fillRect(60,y,6,7);
    txt((f.role==='chaser'?'* ':'')+f.name,72,y,f.dead?'#8f8bb0':'#ffffff');
    txt(String(mode==='ch'?f.score:f.kills),200,y,'#ffffff','right'); txt(String(f.deaths),240,y,'#ffffff','right');
  });
}
/* ---------- nickname ---------- */
let nameBuf='';
/* an on-screen QWERTY keyboard: numbers on top, then the three letter rows (the last row is shifted in like a real keyboard) */
const NAME_ROWS=['1234567890','QWERTYUIOP','ASDFGHJKL-','ZXCVBNM_'],NAME_X0=[10,10,10,25],NAME_R=[];
NAME_ROWS.forEach(function(row,ri){ for(let ci=0;ci<row.length;ci++) NAME_R.push({ch:row[ci],r:[NAME_X0[ri]+ci*30,60+ri*18,27,16]}); });
NAME_R.push({ch:'DEL',r:[NAME_X0[3]+8*30,60+3*18,45,16]});
const R_NAMEOK=[22,140,276,16];
function openName(){ nameBuf=SV.name||'YOU'; state='name'; sfx('pick'); }
function nameAdd(ch){ if(nameBuf.length<8){ nameBuf+=ch; sfx('pick'); } }
function nameDone(){ const n=nameBuf.trim(); SV.name=n||'YOU'; persist(); state='menu'; sfx('score'); }
function nameKey(k){
  if(k==='Enter') nameDone();
  else if(k==='Escape') state='menu';
  else if(k==='Backspace'){ nameBuf=nameBuf.slice(0,-1); }
  else if(k.length===1){ const u=k.toUpperCase(); if(/[A-Z0-9\-_ ]/.test(u)) nameAdd(u); }
}
function nameClick(x,y){
  if(inR(x,y,R_BACK)){ state='menu'; return; }
  if(inR(x,y,R_NAMEOK)){ nameDone(); return; }
  for(const k of NAME_R){ if(inR(x,y,k.r)){ if(k.ch==='DEL') nameBuf=nameBuf.slice(0,-1); else nameAdd(k.ch); return; } }
}
function drawName(){
  ctx.fillStyle='rgba(10,8,25,0.92)'; ctx.fillRect(UI.x0,UI.y0,UI.w,UI.h);
  txt('NAME',12,6,'#ffdd55','left',16);
  btn(R_BACK,'BACK',false);
  ctx.fillStyle='#1d1740'; ctx.fillRect(80,28,160,26);
  ctx.fillStyle='#8a7cf0'; ctx.fillRect(80,28,160,1); ctx.fillRect(80,53,160,1); ctx.fillRect(80,28,1,26); ctx.fillRect(239,28,1,26);
  txt(nameBuf+((Math.floor(menuT*2)%2)&&nameBuf.length<8?'_':''),W/2,35,'#ffffff','center',16);
  for(const k of NAME_R) btn(k.r,k.ch,false);
  btn(R_NAMEOK,'OK - SAVE NAME',true);
  txt('TAP LETTERS  MAX 8',W/2,162,'#8f8bb0','center');
}
/* ---------- map select ---------- */
let mapsSel=0;
const MAPS_PER=6,R_PGL=[0,56,14,70],R_PGR=[306,56,14,70];
/* maps available for a mode (wide maps are chaser-only; Touchdown uses only its own wide arenas) */
function mapIdxs(m){ const a=[]; MAPS.forEach(function(d,i){ if(d.only===m) a.push(i); }); if(m!=='td') MAPS.forEach(function(d,i){ if(!d.only) a.push(i); }); return a; }
function MAP_CELL(i){ const p=i%MAPS_PER; return [16+(p%3)*100,28+Math.floor(p/3)*68,88,50]; }
function openMaps(m){
  pendingMode=m; mode=m; state='maps'; sfx('pick');
  const L=mapIdxs(m),pos=L.indexOf(mapSel);
  mapsSel=pos>=0?pos:(mapSel>=MAPS.length?L.length:0);
}
function mapsStart(){ const L=mapIdxs(pendingMode); mapSel=mapsSel>=L.length?MAPS.length:L[mapsSel]; startGame(pendingMode); }
function mapsPage(d){
  const n=mapIdxs(pendingMode).length+1,pg=Math.floor(mapsSel/MAPS_PER)+d;
  if(pg<0||pg*MAPS_PER>=n) return;
  mapsSel=pg*MAPS_PER; sfx('pick');
}
function mapsKey(k){
  const n=mapIdxs(pendingMode).length+1;
  if(k==='ArrowLeft'||k==='a') mapsSel=(mapsSel+n-1)%n;
  else if(k==='ArrowRight'||k==='d') mapsSel=(mapsSel+1)%n;
  else if(k==='ArrowUp'||k==='w') mapsSel=(mapsSel+n-3)%n;
  else if(k==='ArrowDown'||k==='s') mapsSel=(mapsSel+3)%n;
  else if(k==='PageUp') mapsPage(-1);
  else if(k==='PageDown') mapsPage(1);
  else if(k==='Enter'||k===' ') mapsStart();
  else if(k==='Escape'||k==='Backspace') state='menu';
}
function mapsClick(x,y){
  if(inR(x,y,R_BACK)){ state='menu'; return; }
  const n=mapIdxs(pendingMode).length+1,pg=Math.floor(mapsSel/MAPS_PER);
  if(pg>0&&inR(x,y,R_PGL)){ mapsPage(-1); return; }
  if((pg+1)*MAPS_PER<n&&inR(x,y,R_PGR)){ mapsPage(1); return; }
  for(let i=pg*MAPS_PER;i<Math.min(n,(pg+1)*MAPS_PER);i++){
    const c=MAP_CELL(i);
    if(inR(x,y,[c[0],c[1],c[2],c[3]+10])){ if(mapsSel===i) mapsStart(); else { mapsSel=i; sfx('pick'); } return; }
  }
}
function drawMaps(){
  const L=mapIdxs(pendingMode),n=L.length+1,pg=Math.floor(mapsSel/MAPS_PER),pages=Math.ceil(n/MAPS_PER);
  ctx.fillStyle='rgba(10,8,25,0.9)'; ctx.fillRect(UI.x0,UI.y0,UI.w,UI.h);
  txt('MAPS',12,6,'#ffdd55','left',16);
  txt(pendingMode==='dm'?'DEATHMATCH':(pendingMode==='ch'?'CHASER':'TOUCHDOWN'),244,10,'#ffd23f','right');
  if(pages>1) txt('PAGE '+(pg+1)+'/'+pages,136,10,'#c9c4ff','center');
  btn(R_BACK,'BACK',false);
  for(let i=pg*MAPS_PER;i<Math.min(n,(pg+1)*MAPS_PER);i++){
    const c=MAP_CELL(i),sel=i===mapsSel,isR=i===L.length,def=isR?null:MAPS[L[i]];
    if(isR){ ctx.fillStyle='#1d1740'; ctx.fillRect(c[0],c[1],c[2],c[3]); txt('?',c[0]+44,c[1]+17,'#ffffff','center',16); }
    else { ctx.imageSmoothingEnabled=true; ctx.drawImage(def.bg,0,0,def.bg.width,H,c[0],c[1],c[2],c[3]); ctx.imageSmoothingEnabled=false; }
    if(!sel){ ctx.fillStyle='rgba(10,8,25,0.45)'; ctx.fillRect(c[0],c[1],c[2],c[3]); }
    ctx.fillStyle=sel?'#ffdd55':'#5d50b8';
    const b=sel?2:1;
    ctx.fillRect(c[0]-b,c[1]-b,c[2]+b*2,b); ctx.fillRect(c[0]-b,c[1]+c[3],c[2]+b*2,b); ctx.fillRect(c[0]-b,c[1],b,c[3]); ctx.fillRect(c[0]+c[2],c[1],b,c[3]);
    if(def&&def.cols>40) txt('WIDE',c[0]+4,c[1]+4,'#ffd23f');
    txt(isR?'RANDOM':def.name,c[0]+44,c[1]+c[3]+4,sel?'#ffffff':'#8f8bb0','center');
  }
  if(pg>0) txt('<',7,88,'#ffffff','center',16);
  if((pg+1)*MAPS_PER<n) txt('>',313,88,'#ffffff','center',16);
  txt(mapsSel===L.length?'A SURPRISE EVERY MATCH':MAPS[L[mapsSel]].tag,W/2,161,'#ffd23f','center');
  txt(pages>1?'TAP TWICE TO START  < > MORE MAPS':'TAP TWICE TO START',W/2,171,'#8f8bb0','center');
}
const MENU=[
  {x:70,y:34,w:180,h:14,label:function(){return 'DEATHMATCH';},act:function(){openMaps('dm');}},
  {x:70,y:50,w:180,h:14,label:function(){return 'TOUCHDOWN';},act:function(){openMaps('td');}},
  {x:70,y:66,w:180,h:14,label:function(){return 'CHASER';},act:function(){openMaps('ch');}},
  {x:70,y:82,w:180,h:14,label:function(){return 'BOTS: '+DIFF[diff].name;},act:function(){diff=(diff+1)%3;}},
  {x:70,y:98,w:88,h:14,label:function(){return 'SHOP';},act:openShop},
  {x:162,y:98,w:88,h:14,label:function(){return 'STATS';},act:openStats},
  {x:70,y:114,w:180,h:14,label:function(){return 'NAME: '+(SV.name||'YOU');},act:openName},
  {x:70,y:130,w:180,h:14,label:function(){return 'MULTIPLAYER';},act:openMP}
];
function drawMenu(){
  ctx.fillStyle='rgba(10,8,25,0.55)'; ctx.fillRect(UI.x0,UI.y0,UI.w,UI.h);
  for(const f of demo){ f.anim+=0.016; drawFighter(f); }
  txt('PIXEL RUSH',W/2+2,6,'#7a1f5c','center',24);
  txt('PIXEL RUSH',W/2,4,'#ffdd55','center',24);
  txt('COINS '+SV.coins,10,169,'#ffd23f','left');
  txt('PLAYER: '+(SV.name||'YOU'),W-10,169,'#ffffff','right');
  const hx=(hoverX-UI.ox)/UI.s,hy=(hoverY-UI.oy)/UI.s;
  MENU.forEach(function(b,i){
    const hov=hx>=b.x&&hx<=b.x+b.w&&hy>=b.y&&hy<=b.y+b.h;
    ctx.fillStyle=hov?'#ff5a4f':'#2a2050'; ctx.fillRect(b.x,b.y,b.w,b.h);
    ctx.fillStyle=hov?'#ffd1cc':'#8a7cf0'; ctx.fillRect(b.x,b.y,b.w,1); ctx.fillRect(b.x,b.y+b.h-1,b.w,1);
    ctx.fillRect(b.x,b.y,1,b.h); ctx.fillRect(b.x+b.w-1,b.y,1,b.h);
    txt(b.label(),b.x+Math.round(b.w/2),b.y+Math.round((b.h-8*TS)/2),'#ffffff','center');
  });
}
/* backdrop for menus: fill the whole canvas (classic maps are 320 wide, so stretch them) */
function drawBGFill(){
  if(bg.width>=W) ctx.drawImage(bg,0,0,W,H,0,0,W,H);
  else ctx.drawImage(bg,0,0,bg.width,H,0,0,W,H);
}
/* draw a 320x180-designed screen centred (and shrunk on narrow screens) inside the real canvas */
function withUI(fn){
  const w0=W; W=320;
  ctx.save(); ctx.translate(UI.ox,UI.oy); ctx.scale(UI.s,UI.s);
  fn();
  ctx.restore(); W=w0;
}
let TICK=true,IALPHA=1,ICAM=[0,0,0,0],_ip=[];
function snapInterp(){
  for(const f of fighters){ f.px=f.x; f.py=f.y; }
  for(const b of bullets){ b.px=b.x; b.py=b.y; }
  for(const sl of slashes){ if(sl.f){ sl.px=sl.x; sl.py=sl.y; } }
  if(ball){ ball.px=ball.x; ball.py=ball.y; }
  if(reaper){ reaper.px=reaper.x; reaper.py=reaper.y; }
  ICAM[0]=camX; ICAM[1]=camY;
}
function interpOne(o,a){
  if(o.px===undefined) return;
  const dx=o.x-o.px,dy=o.y-o.py;
  if((dx===0&&dy===0)||dx*dx+dy*dy>900) return;   /* standing still, or teleported (respawn): do not glide */
  _ip.push(o,o.x,o.y); o.x=o.px+dx*a; o.y=o.py+dy*a;
}
function interpApply(a){
  _ip.length=0;
  for(const f of fighters) if(!f.dead) interpOne(f,a);
  for(const b of bullets) interpOne(b,a);
  for(const sl of slashes) if(sl.f) interpOne(sl,a);
  if(ball&&!ball.carrier) interpOne(ball,a);
  if(reaper) interpOne(reaper,a);
  ICAM[2]=camX; ICAM[3]=camY;
  camX=ICAM[0]+(camX-ICAM[0])*a; camY=ICAM[1]+(camY-ICAM[1])*a;
}
function interpRestore(){
  for(let i=0;i<_ip.length;i+=3){ _ip[i].x=_ip[i+1]; _ip[i].y=_ip[i+2]; }
  _ip.length=0; camX=ICAM[2]; camY=ICAM[3];
}
function render(){
  const doI=PERF.interpolate&&state==='play'&&!paused&&!NET.client&&IALPHA<1;
  if(doI) interpApply(IALPHA);
  renderScene();
  if(doI) interpRestore();
}
function renderScene(){
  ctx.setTransform(S,0,0,S,0,0);
  ctx.save();
  ctx.clearRect(0,0,W,H);
  if(state!=='menu'&&shake>0&&!lowQ){ const amp=Math.min(shake,5)*SHAKE; ctx.translate(Math.round((Math.random()-0.5)*amp*4)/2,Math.round((Math.random()-0.5)*amp*4)/2); }
  if(state==='play'||state==='over'){ ctx.scale(ZOOM,ZOOM); ctx.translate(-Math.round(camX),-Math.round(camY)); }
  if(state==='play'||state==='over'){
    const th=MAPS[curIdx].theme;
    const vx0=camX-24,vy0=camY-24,vw0=VW+48,vh0=VH+48;
    ctx.fillStyle=th.tile.base; ctx.fillRect(vx0,vy0,vw0,vh0);
    if(vy0<0){ ctx.fillStyle=th.sky[0]; ctx.fillRect(vx0,vy0,vw0,-vy0); }
    const sx=Math.max(0,Math.floor(camX)-12),sw=Math.min(bg.width-sx,Math.ceil(VW)+26);
    if(sw>0) ctx.drawImage(bg,sx,0,sw,bg.height,sx,0,sw,bg.height);
  } else drawBGFill();
  if(state==='menu'){ withUI(drawMenu); ctx.restore(); return; }
  if(state==='shop'){ withUI(drawShop); ctx.restore(); return; }
  if(state==='stats'){ withUI(drawStats); ctx.restore(); return; }
  if(state==='maps'){ withUI(drawMaps); ctx.restore(); return; }
  if(state==='name'){ withUI(drawName); ctx.restore(); return; }
  if(state==='mp'){ withUI(drawMP); ctx.restore(); return; }
  drawHazards(); drawPads();
  if(mode==='td') drawGoals();
  for(const b of bullets){ if(!offView(b.x-16,32,16)) drawBullet(b); }
  drawCorpses();
  for(const f of fighters) f.rel=(f===fighters[0])?0:(isEnemy(fighters[0],f)?2:1);
  drawBlocks();
  drawReaper();
  for(const f of fighters){ if(!offView(f.x-24,48,16)) drawFighter(f); }
  drawBall();
  if(state==='play'&&!paused) drawAim();
  drawSlashes(); drawBeams();
  drawParts(); drawRings(); drawTexts();
  ctx.restore();
  if(flashT>0){ ctx.globalAlpha=Math.min(0.45,flashT*2.5); ctx.fillStyle=flashCol; ctx.fillRect(0,0,W,H); ctx.globalAlpha=1; }
  drawCeleb();
  drawHUD();
  if(showSB&&state==='play'&&!paused) withUI(drawScoreboard);
  if(state==='over') withUI(drawOver);
}

/* ================= menu demo + loop ================= */
(function(){
  const a=mk(90,'A','a',{main:'#38b6ff',dark:'#1b62a8',hair:'#b6f0ff'},false);
  const b=mk(91,'B','b',{main:'#ff4d5e',dark:'#9d1f2f',hair:'#ffd166'},false);
  a.x=96; a.y=160; a.face=1; a.weapon=1; a.onGround=true; a.placed=true;
  b.x=224; b.y=160; b.face=-1; b.weapon=0; b.onGround=true; b.placed=true;
  demo=[a,b];
})();
/* ================= fit the canvas to the screen (no bars, no stretching) ================= */
let insetProbe=null;
function fitCanvas(){
  try{
    const vw=window.innerWidth||960,vh=window.innerHeight||540;
    let iT=0,iR=0,iB=0,iL=0;                       /* notch / rounded-corner safe areas */
    if(document.body&&window.getComputedStyle){
      if(!insetProbe){
        insetProbe=document.createElement('div');
        insetProbe.style.cssText='position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:env(safe-area-inset-top,0px) env(safe-area-inset-right,0px) env(safe-area-inset-bottom,0px) env(safe-area-inset-left,0px)';
        document.body.appendChild(insetProbe);
      }
      const cs=getComputedStyle(insetProbe);
      iT=parseFloat(cs.paddingTop)||0; iR=parseFloat(cs.paddingRight)||0; iB=parseFloat(cs.paddingBottom)||0; iL=parseFloat(cs.paddingLeft)||0;
    }
    const aw=Math.max(100,vw-iL-iR),ah=Math.max(100,vh-iT-iB);
    const ar=aw/ah,a=Math.min(AR_MAX,Math.max(AR_MIN,ar));
    let cw=aw,ch=ah;                                /* normal screens: fill the whole usable area */
    if(ar>AR_MAX) cw=Math.round(ah*AR_MAX);         /* extreme ultrawide: thin side bars */
    else if(ar<AR_MIN) ch=Math.round(aw/AR_MIN);    /* portrait: smaller box (the rotate hint shows) */
    cv.style.width=cw+'px'; cv.style.height=ch+'px';
    const nW=Math.round(H*a);                       /* logical width that matches the screen shape exactly */
    if(nW!==W||cv.width!==nW*S){
      W=nW; cv.width=W*S; cv.height=H*S; ctx.imageSmoothingEnabled=false;
    }
    UI.s=Math.min(1,W/320); UI.ox=(W-320*UI.s)/2; UI.oy=(H-180*UI.s)/2;
    UI.x0=-UI.ox/UI.s; UI.y0=-UI.oy/UI.s; UI.w=W/UI.s; UI.h=H/UI.s;
    updateView();
    if(state==='play'||state==='over') snapCam();
  }catch(e){}
}
window.addEventListener('resize',fitCanvas);
window.addEventListener('orientationchange',refitSoon);
document.addEventListener('fullscreenchange',function(){ if(isFull()) lockLandscape(); else try{ screen.orientation.unlock(); }catch(e){} refitSoon(); });
document.addEventListener('webkitfullscreenchange',function(){ refitSoon(); });
if(window.visualViewport) window.visualViewport.addEventListener('resize',fitCanvas);
fitCanvas();

let last=performance.now(),acc=0,dsPrev='',lastDraw=0,qAcc=0,qN=0,qBad=0,qGood=0;
function frame(now){
  requestAnimationFrame(frame);
  /* optional fps cap (PERF.targetFps) */
  if(PERF.targetFps>0&&now-lastDraw<1000/PERF.targetFps-2) return;
  lastDraw=now;
  const raw=(now-last)/1000;
  const dt=Math.min(0.05,raw); last=now; menuT+=dt; shopMsgT=Math.max(0,shopMsgT-dt);
  const ds=(state==='play'&&!paused)?'play':'other';
  if(ds!==dsPrev&&document.body){ dsPrev=ds; document.body.setAttribute('data-state',ds); }
  TICK=false; IALPHA=1;
  if(state==='play'&&NET.client){ acc=0; TICK=true; clientStep(dt,now); }
  else if(state==='play'&&(!paused||NET.on)){
    acc+=dt; let n=0;
    while(acc>=STEP){ if(PERF.interpolate) snapInterp(); update(STEP); acc-=STEP; TICK=true; if(state!=='play'||++n>=4){ if(n>=4) acc=0; break; } }
    IALPHA=PERF.interpolate?Math.min(1,acc/STEP):1;
    if(NET.host&&state==='play') hostTick(now);
  }
  else if(state==='over'){ overT+=dt; acc=0; updateParts(dt); updateBullets(dt); updateCorpses(dt); TICK=true; }
  else { acc=0; TICK=true; }
  render();
  /* auto quality: measured over 2 s windows */
  if(PERF.autoQuality&&state==='play'&&!paused){
    qAcc+=raw; qN++;
    if(qAcc>=2){
      const avg=qAcc/qN, want=PERF.targetFps>0?1/PERF.targetFps:0;
      if(avg>0.024){ qBad++; qGood=0; if(qBad>=1) lowQ=true; }
      else if(avg<0.0185||(want&&avg<want*1.3)){ qGood++; qBad=0; if(qGood>=3) lowQ=false; }
      qAcc=0; qN=0;
    }
  } else { qAcc=0; qN=0; }
}
/* Android back button (the app calls this): returns true when the game handled it */
window.__nativeBack=function(){
  if(state==='play'){ paused=!paused; return true; }
  if(state==='mp'){ mpKey('Escape'); return true; }
  if(state==='over'){ if(NET.on) mpBackToLobby(); else state='menu'; return true; }
  if(state!=='menu'){ state='menu'; return true; }
  return false;
};
if(window.__PR_TEST__){ window.__PR={RV:RV,RVC:RVC,mqOpen:mqOpen,rvHostStart:rvHostStart,rvJoin:rvJoin,isLR:isLR,pairAttachReady:pairAttachReady,pairOffer:pairOffer,pairAccept:pairAccept,pairAnswer:pairAnswer,pairHostStart:pairHostStart,encodeCode:encodeCode,decodeCode:decodeCode,LR:LR,PAIR:PAIR,setMethod:function(m){SV.mpMethod=m;},setNative:function(n){ window.Native=n; },mpBackToLobby:mpBackToLobby,get ZRv(){return ZR;},get ZLv(){return ZL;},NET:NET,MP:MP,openMP:openMP,mpClick:mpClick,mpConnect:mpConnect,mpStart:mpStart,mpLeave:mpLeave,frame:frame,clientStep:clientStep,mapIdxs:mapIdxs,get bulletsArr(){return bullets;},get shakeV(){return shake;},get earnedV(){return earned;},get modeV(){return mode;},get celebV(){return celeb;},get winnerV(){return winner;},get lastResultV(){return lastResult;},get cdTV(){return cdT;},get timeV(){return time;},get mapSelV(){return mapSel;},openName:openName,nameKey:nameKey,nameClick:nameClick,get celeb(){return celeb;},get chaser(){return chaser;},get chTime(){return chTime;},MAPS:MAPS,openMaps:openMaps,mapsKey:mapsKey,mapsClick:mapsClick,setMap:function(i){mapSel=i;},loadMap:loadMap,get HAZ(){return HAZ;},get PADS(){return PADS;},get corpses(){return corpses;},SVget:function(){return SV;},openShop:openShop,openStats:openStats,shopActivate:shopActivate,shopItems:shopItems,shopKey:shopKey,statsKey:statsKey,shopClick:shopClick,statsClick:statsClick,setTab:setTab,setSB:function(v){showSB=v;},WEAP:WEAP,CHARS:CHARS,startGame:startGame,update:update,render:render,get state(){return state;},get fighters(){return fighters;},get scores(){return scores;},setDiff:function(d){diff=d;},get ball(){return ball;},get camX(){return camX;},get camY(){return camY;},boxHits:boxHits,get WW(){return WW;},fit:fitCanvas,get W(){return W;},get UI(){return UI;},get ZOOM(){return ZOOM;},get VW(){return VW;},get celZoomK(){return celZoomK;},get cdT(){return cdT;},get goT(){return goT;},CAM:CAM,SKILLS:SKILLS,BLK:BLK,pressSkill:function(){edge.skill=true;},keys:keys,edge:edge,get bullets(){return bullets;},snapInterp:snapInterp,setAlpha:function(a){IALPHA=a;},get lowQ(){return lowQ;},PERF:PERF,txcSize:function(){return TXC.size;}}; }
else requestAnimationFrame(frame);
})();