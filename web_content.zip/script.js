const button = document.getElementById('previewBtn');
button.addEventListener('click', () => {
  const name = document.getElementById('appName').value.trim();
  const pkg = document.getElementById('packageName').value.trim();
  const valid = /^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+$/.test(pkg);
  document.getElementById('result').textContent = !name ? 'Қосымша атауын енгізіңіз.' : valid ? `Дайын: «${name}», package: ${pkg}. Бұл тек веб-үлгі.` : 'Package name пішімі қате. Мысалы: com.example.myapp';
});
