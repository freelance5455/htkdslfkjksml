(() => {
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const app = $('#app'), ta = $('#msg'), chat = $('#chat'), scr = $('#screens'), menuEl = $('#menu'), root = document.documentElement;
const P = {
home:'<path d="M3 10.5 12 3l9 7.5V21h-6v-6H9v6H3z"/>',
chat:'<path d="M21 12a8 8 0 0 1-11.6 7.1L3 21l1.9-5.4A8 8 0 1 1 21 12z"/>',
grid:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
gear:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/><circle cx="12" cy="12" r="7.5"/>',
bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9M10 21h4"/>',
code:'<path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/>',
compass:'<circle cx="12" cy="12" r="9"/><path d="m15.5 8.5-2 5-5 2 2-5z"/>',
bulb:'<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-4 10.5c1 1 1 2 1 2.5h6c0-.5 0-1.5 1-2.5A6 6 0 0 0 12 3z"/>',
image:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>',
arrow:'<path d="M5 12h14M13 6l6 6-6 6"/>',
clip:'<path d="m21 11-9 9a5 5 0 0 1-7-7l9-9a3.5 3.5 0 0 1 5 5l-9 9a2 2 0 0 1-3-3l8-8"/>',
dots:'<circle cx="5" cy="12" r="1.5" fill="currentColor"/><circle cx="12" cy="12" r="1.5" fill="currentColor"/><circle cx="19" cy="12" r="1.5" fill="currentColor"/>',
mic:'<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
send:'<path d="m22 2-7 20-4-9-9-4zM22 2 11 13"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
pen:'<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
book:'<path d="M4 5a2 2 0 0 1 2-2h5v17H6a2 2 0 0 0-2 2zM20 5a2 2 0 0 0-2-2h-5v17h5a2 2 0 0 1 2 2z"/>',
check:'<path d="m4 12 5 5L20 6"/>',
spark:'<path d="M12 3l2 6 6 2-6 2-2 6-2-6-6-2 6-2z"/>',
x:'<path d="M6 6l12 12M18 6 6 18"/>'
};
const ico = n => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]}</svg>`;
const paint = r => (r || document).querySelectorAll('[data-i]').forEach(e => e.innerHTML = ico(e.dataset.i));
const CARDS = [
 ['code','Explain this Code','Can you find the bug in this JavaScript snippet?'],
 ['compass','Plan a Trip','Create a 5-day budget-friendly itinerary for Kyoto.'],
 ['bulb','Brainstorm Ideas','I want to start a podcast about sustainable tech.'],
 ['image','Generate Images','Create a futuristic city at night.']];
const CATS = [
 ['pen','Writing','Emails, essays, and polished drafts.','Help me write a clear, friendly email to my team.'],
 ['code','Coding','Debug, explain, and build code.','Help me debug my JavaScript code.'],
 ['book','Learning','Understand any topic step by step.','Explain how black holes work in simple terms.'],
 ['check','Productivity','Plans, checklists, and routines.','Help me plan a focused work week.'],
 ['compass','Travel Planning','Itineraries and travel tips.','Create a 5-day budget-friendly itinerary for Kyoto.'],
 ['bulb','Creative Ideas','Brainstorm names, stories, and concepts.','Give me 10 creative ideas for a short story.'],
 ['image','Image Generation','Describe the image you want to create.','Create a futuristic city at night.']];
const SCHEMA = [
 ['Personalize',[
  ['bg','photo','Background photo'],['av','photo','Profile photo'],
  ['dim','range','Photo dim',[0,90]],['blur','range','Photo blur',[0,20]],
  ['accent','swatch','Accent color',['#8C7CF0','#7F8CFF','#4FB3A9','#E0829B','#D9A441','#EDEDF2']]]],
 ['Assistant',[['name','text','Assistant name'],['lang','select','Language',['English','Bahasa Indonesia','日本語','Español']],['style','select','Response style',['Balanced','Concise','Detailed','Friendly']]]],
 ['AI connection',[['key','password','API key'],['model','text','Model']]],
 ['Appearance',[['theme','seg','Theme',['dark','light','system']]]],
 ['Voice',[['vin','toggle','Voice input'],['vout','toggle','Voice output']]],
 ['Interface',[['anim','toggle','Animations'],['sfx','toggle','Sound effects'],['notif','toggle','Notifications']]]];
const DEF = {name:'Nebula',lang:'English',style:'Balanced',theme:'dark',accent:'#8C7CF0',dim:55,blur:0,key:'',model:'claude-sonnet-5-5',vin:1,vout:0,anim:1,sfx:0,notif:1};
const LANGS = {'English':'en-US','Bahasa Indonesia':'id-ID','日本語':'ja-JP','Español':'es-ES'};
let S = {...DEF};
try { Object.assign(S, JSON.parse(localStorage.getItem('nebula-settings') || '{}')); } catch (_) {}
const IMG = {bg:'', av:''};
try { IMG.bg = localStorage.getItem('nebula-bg') || ''; IMG.av = localStorage.getItem('nebula-av') || ''; } catch (_) {}
const save = () => { try { localStorage.setItem('nebula-settings', JSON.stringify(S)); } catch (_) {} };
const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let tT;
function toast(t) { const e = $('#toast'); e.textContent = t; e.classList.add('show'); clearTimeout(tT); tT = setTimeout(() => e.classList.remove('show'), 2600); }
let ac;
function beep() {
  if (!S.sfx) return;
  try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = 660; g.gain.value = .04; o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + .08); } catch (_) {}
}
function speak(t) {
  if (!S.vout || !('speechSynthesis' in window)) return;
  const u = new SpeechSynthesisUtterance(t); u.lang = LANGS[S.lang] || 'en-US'; speechSynthesis.speak(u);
}
const tm = () => new Date().toLocaleTimeString([], {hour: 'numeric', minute: '2-digit'});
const clock = () => { $('#clock').textContent = tm().replace(/\s?[AP]M/i, ''); };
const toBottom = () => scr.scrollTo({top: scr.scrollHeight, behavior: 'smooth'});
function fit() { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 120) + 'px'; }
const closeMenu = () => menuEl.classList.remove('open');
function shrink(file, max, q, square) {
  return new Promise((res, rej) => {
    const u = URL.createObjectURL(file), i = new Image();
    i.onload = () => {
      const s = Math.min(i.width, i.height);
      const sw = square ? s : i.width, sh = square ? s : i.height;
      const sx = square ? (i.width - s) / 2 : 0, sy = square ? (i.height - s) / 2 : 0;
      const k = Math.min(1, max / Math.max(sw, sh)), c = document.createElement('canvas');
      c.width = Math.round(sw * k); c.height = Math.round(sh * k);
      c.getContext('2d').drawImage(i, sx, sy, sw, sh, 0, 0, c.width, c.height);
      URL.revokeObjectURL(u); res(c.toDataURL('image/jpeg', q));
    };
    i.onerror = () => { URL.revokeObjectURL(u); rej(new Error('bad image')); };
    i.src = u;
  });
}
function apply() {
  const dark = S.theme === 'dark' || (S.theme === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.body.dataset.theme = dark ? 'dark' : 'light';
  document.body.classList.toggle('noanim', !S.anim);
  root.style.setProperty('--ac', S.accent);
  root.style.setProperty('--dim', S.dim);
  root.style.setProperty('--blur', S.blur + 'px');
  app.classList.toggle('has-bg', !!IMG.bg);
  $('#bg').style.backgroundImage = IMG.bg ? `url(${IMG.bg})` : '';
  $$('.avt').forEach(e => { e.style.backgroundImage = IMG.av ? `url(${IMG.av})` : ''; e.innerHTML = IMG.av ? '' : ico('spark'); });
  $$('.av').forEach(e => { e.style.backgroundImage = IMG.av ? `url(${IMG.av})` : ''; e.innerHTML = IMG.av ? '' : ico('spark'); });
  const n = S.name || 'Nebula';
  $('#brandName').textContent = n; $('#wName').textContent = n;
}
function sub() {
  const s = app.dataset.s;
  $('#brandSub').innerHTML = s === 'chat' ? `<i class="dot ${S.key ? 'on' : ''}"></i>${S.key ? 'Connected' : 'Not connected'}` : s === 'explore' ? 'Explore' : s === 'settings' ? 'Settings' : '';
}
function ctl(k, ty, lb, op) {
  if (ty === 'text') return `<input type="text" data-k="${k}" value="${esc(S[k])}" maxlength="40" aria-label="${lb}" autocapitalize="off" spellcheck="false">`;
  if (ty === 'password') return `<input type="password" data-k="${k}" value="${esc(S[k])}" placeholder="sk-ant-..." aria-label="${lb}" autocomplete="off">`;
  if (ty === 'select') return `<select data-k="${k}">${op.map(o => `<option${o === S[k] ? ' selected' : ''}>${o}</option>`).join('')}</select>`;
  if (ty === 'range') return `<input type="range" data-k="${k}" min="${op[0]}" max="${op[1]}" value="${S[k]}" aria-label="${lb}">`;
  if (ty === 'seg') return `<span class="seg">${op.map(o => `<button data-seg="${k}" data-v="${o}" class="${o === S[k] ? 'on' : ''}">${o}</button>`).join('')}</span>`;
  if (ty === 'swatch') return `<span class="sw">${op.map(c => `<button data-sw="${c}" class="${c === S.accent ? 'on' : ''}" style="background:${c}" aria-label="${c}"></button>`).join('')}</span>`;
  if (ty === 'photo') return `<span class="pb"><button class="mini" data-pick="${k}">Choose</button>${IMG[k] ? `<button class="mini" data-rm="${k}">Remove</button>` : ''}</span>`;
  return `<label class="swl"><input type="checkbox" data-k="${k}" ${S[k] ? 'checked' : ''}><i></i></label>`;
}
function renderSet() {
  $('#setBody').innerHTML = SCHEMA.map(([t, rows]) => `<h4>${t}</h4><div class="grp">${rows.map(([k, ty, lb, op]) => `<div class="row"><span>${lb}</span>${ctl(k, ty, lb, op)}</div>`).join('')}</div>`).join('');
}
$('#setBody').addEventListener('input', e => {
  const k = e.target.dataset.k; if (!k) return;
  S[k] = e.target.type === 'checkbox' ? +e.target.checked : e.target.type === 'range' ? +e.target.value : e.target.value.trim();
  save(); apply(); sub();
});
let pickT = '';
function pick(k) { pickT = k; $('#fPick').click(); }
$('#fPick').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f || !pickT) return;
  try {
    const d = await shrink(f, pickT === 'bg' ? 1400 : 320, .82, pickT === 'av');
    localStorage.setItem('nebula-' + pickT, d);
    IMG[pickT] = d; apply(); renderSet(); toast(pickT === 'bg' ? 'Background updated' : 'Profile photo updated');
  } catch (_) { toast('Could not save this photo. Try a smaller one.'); }
};
function removePhoto(k) {
  IMG[k] = ''; try { localStorage.removeItem('nebula-' + k); } catch (_) {}
  apply(); renderSet();
}
function go(n) {
  closeMenu();
  const id = n === 'chat' ? 'chatS' : n;
  app.dataset.s = n;
  $$('.screen').forEach(s => s.classList.toggle('on', s.id === id));
  $$('.dk').forEach(d => d.classList.toggle('on', d.dataset.go === n));
  sub();
  if (n === 'chat') setTimeout(() => scr.scrollTo({top: scr.scrollHeight}), 30); else scr.scrollTo({top: 0});
}
let hist = [], pend = null, busy = false;
function add(role, text, img) {
  const r = document.createElement('div');
  r.className = 'msg ' + role;
  r.innerHTML = (role === 'ai' ? '<span class="av"></span>' : '') + '<div class="bw"><div class="bub"></div><time></time></div>';
  const b = r.querySelector('.bub');
  if (img) b.append(img);
  if (text) b.append(document.createTextNode(text));
  r.querySelector('time').textContent = tm();
  chat.append(r); apply();
  if (app.dataset.s === 'chat') toBottom();
}
function typing() {
  const r = document.createElement('div');
  r.className = 'msg ai typing';
  r.innerHTML = '<span class="av"></span><div class="bw"><div class="bub"><i></i><i></i><i></i></div></div>';
  chat.append(r); apply(); toBottom(); return r;
}
async function ask() {
  const sys = `You are ${S.name || 'Nebula'}, a private personal AI assistant. Reply in ${S.lang}. Response style: ${S.style}.`;
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {'content-type': 'application/json', 'x-api-key': S.key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true'},
    body: JSON.stringify({model: S.model || DEF.model, max_tokens: 1024, system: sys, messages: hist.slice(-20)})
  });
  const d = await r.json();
  if (!r.ok) throw new Error((d.error && d.error.message) || 'Request failed (' + r.status + ')');
  return d.content.filter(b => b.type === 'text').map(b => b.text).join('\n');
}
async function send() {
  const v = ta.value.trim(); if ((!v && !pend) || busy) return;
  go('chat');
  const p = pend; pend = null; drawChip();
  ta.value = ''; fit(); beep();
  let content = v, img = null, shown = v;
  if (p && p.type === 'img') {
    img = new Image(); img.src = p.url; img.alt = p.name;
    content = [{type: 'image', source: {type: 'base64', media_type: 'image/jpeg', data: p.b64}}, {type: 'text', text: v || 'Describe this image.'}];
  } else if (p) {
    content = `File: ${p.name}\n\n${p.text}\n\n${v}`; shown = `Attached: ${p.name}\n${v}`.trim();
  }
  add('user', shown, img);
  if (!S.key) { add('ai', 'No AI connected yet. Add your API key in Settings → AI connection.'); return; }
  hist.push({role: 'user', content});
  busy = true; const t = typing();
  try {
    const a = await ask();
    hist.push({role: 'assistant', content: a});
    t.remove(); add('ai', a); speak(a); beep();
  } catch (err) {
    hist.pop(); t.remove(); add('ai', 'Could not get a response: ' + err.message);
  }
  busy = false;
}
function newChat() { hist = []; chat.innerHTML = ''; pend = null; drawChip(); ta.value = ''; fit(); go('chat'); }
function usePrompt(p) { go('chat'); ta.value = p; fit(); ta.focus(); }
function drawChip() {
  const c = $('#chip');
  if (!pend) { c.hidden = true; c.innerHTML = ''; return; }
  c.hidden = false;
  c.innerHTML = (pend.type === 'img' ? `<img src="${pend.url}" alt="">` : '') + `<span>${esc(pend.name)}</span><button data-i="x" data-act="unpend" aria-label="Remove attachment"></button>`;
  paint(c);
}
$('#fImg').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  try { const u = await shrink(f, 1024, .8, false); pend = {type: 'img', url: u, b64: u.split(',')[1], name: f.name}; drawChip(); }
  catch (_) { toast('Could not read this image.'); }
};
$('#fAny').onchange = e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  const ok = f.type.startsWith('text/') || /\.(txt|md|csv|json|js|ts|html|css|py|java|c|cpp|sql|xml|yml|yaml)$/i.test(f.name);
  if (!ok) return toast('Unsupported file. Use a text, code, or image file.');
  if (f.size > 200 * 1024) return toast('File is too large (max 200 KB).');
  const r = new FileReader();
  r.onload = () => { pend = {type: 'txt', name: f.name, text: String(r.result)}; drawChip(); };
  r.readAsText(f);
};
let rec, listening = false;
function mic() {
  if (!S.vin) return toast('Voice input is turned off in Settings.');
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return toast('Voice input is unavailable in this browser.');
  if (listening) { rec.stop(); return; }
  rec = new SR(); rec.lang = LANGS[S.lang] || 'en-US'; rec.interimResults = false;
  rec.onstart = () => { listening = true; $('#micBtn').classList.add('rec'); toast('Listening...'); };
  rec.onend = () => { listening = false; $('#micBtn').classList.remove('rec'); };
  rec.onerror = e => toast('Voice input error: ' + e.error);
  rec.onresult = e => { ta.value += (ta.value ? ' ' : '') + e.results[0][0].transcript; fit(); };
  try { rec.start(); } catch (_) { toast('Could not start the microphone.'); }
}
function menu(anchor, items) {
  menuEl.innerHTML = '';
  items.forEach(([l, f]) => { const b = document.createElement('button'); b.textContent = l; b.onclick = () => { closeMenu(); f(); }; menuEl.append(b); });
  menuEl.classList.add('open');
  const a = anchor.getBoundingClientRect(), h = app.getBoundingClientRect();
  menuEl.style.left = Math.max(8, Math.min(a.left - h.left, h.width - menuEl.offsetWidth - 8)) + 'px';
  menuEl.style.top = Math.max(8, a.top - h.top - menuEl.offsetHeight - 8) + 'px';
}
function sheet(t, html) { $('#sheetT').textContent = t; $('#sheetB').innerHTML = html; $('#sheet').classList.add('open'); paint($('#sheet')); }
const closeSheet = () => $('#sheet').classList.remove('open');
const notif = () => sheet('Notifications', `<div class="nt">${S.notif ? 'No new notifications.' : 'Notifications are turned off. Enable them in Settings → Interface.'}</div>`);
const A = {
  send, mic, notif, close: closeSheet,
  newchat: newChat,
  pickav: () => pick('av'),
  unpend: () => { pend = null; drawChip(); },
  attach: () => $('#fAny').click(),
  img: () => $('#fImg').click(),
  more: el => menu(el, [['New chat', newChat], ['Open settings', () => go('settings')]])
};
document.addEventListener('click', e => {
  if (!e.target.closest('#menu') && !e.target.closest('[data-act=more]')) closeMenu();
  if (e.target.id === 'sheet') closeSheet();
  const a = e.target.closest('[data-act]'); if (a && A[a.dataset.act]) { A[a.dataset.act](a); return; }
  const g = e.target.closest('[data-go]'); if (g) { go(g.dataset.go); return; }
  const c = e.target.closest('[data-c]'); if (c) { usePrompt(CARDS[c.dataset.c][2]); return; }
  const x = e.target.closest('[data-e]'); if (x) { usePrompt(CATS[x.dataset.e][3]); return; }
  const pk = e.target.closest('[data-pick]'); if (pk) { pick(pk.dataset.pick); return; }
  const rm = e.target.closest('[data-rm]'); if (rm) { removePhoto(rm.dataset.rm); return; }
  const sw = e.target.closest('[data-sw]'); if (sw) { S.accent = sw.dataset.sw; save(); apply(); renderSet(); return; }
  const sg = e.target.closest('[data-seg]'); if (sg) { S[sg.dataset.seg] = sg.dataset.v; save(); apply(); renderSet(); }
});
ta.addEventListener('input', fit);
ta.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey && !matchMedia('(pointer:coarse)').matches) { e.preventDefault(); send(); }
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeSheet(); closeMenu(); } });
$('#cards').innerHTML = CARDS.map((c, i) => `<button class="card" data-c="${i}"><span class="ci" data-i="${c[0]}"></span><h3>${c[1]}</h3><p>${c[2]}</p><span class="ar" data-i="arrow"></span></button>`).join('');
$('#cats').innerHTML = CATS.map((c, i) => `<button class="cat" data-e="${i}"><span class="ci" data-i="${c[0]}"></span><div><h3>${c[1]}</h3><p>${c[2]}</p></div><span class="ar" data-i="arrow"></span></button>`).join('');
const h = new Date().getHours();
$('#greet').textContent = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
renderSet(); paint(); apply(); clock(); setInterval(clock, 15000); go('home');
matchMedia('(prefers-color-scheme: dark)').addEventListener?.('change', apply);
})();