let products=JSON.parse(localStorage.getItem('b_products'))||[];let sales=JSON.parse(localStorage.getItem('b_sales'))||[];let expenses=JSON.parse(localStorage.getItem('b_expenses'))||[];let html5QrcodeScanner=null;const OWNER_PIN="1234";

function saveData(){localStorage.setItem('b_products',JSON.stringify(products));localStorage.setItem('b_sales',JSON.stringify(sales));localStorage.setItem('b_expenses',JSON.stringify(expenses));}

function switchRole(role){
 if(role==='owner'){
  const inputPin=prompt("እባክዎን የባለቤት PIN ያስገቡ:");
  if(inputPin!==OWNER_PIN){if(inputPin!==null)alert("የተሳሳተ PIN ነው!");return;}
 }
 document.getElementById('sales-section').classList.add('hidden');
 document.getElementById('owner-section').classList.add('hidden');
 document.getElementById('btn-sales-role').classList.remove('active');
 document.getElementById('btn-owner-role').classList.remove('active');
 if(role==='sales'){document.getElementById('sales-section').classList.remove('hidden');document.getElementById('btn-sales-role').classList.add('active');initScanner();}
 else{document.getElementById('owner-section').classList.remove('hidden');document.getElementById('btn-owner-role').classList.add('active');stopScanner();renderOwnerReport();}
}

function addProduct(){
 const code=document.getElementById('p-code').value.trim(),name=document.getElementById('p-name').value.trim();
 const cost=parseFloat(document.getElementById('p-cost').value),price=parseFloat(document.getElementById('p-price').value),qty=parseInt(document.getElementById('p-qty').value);
 if(!code||!name||isNaN(cost)||isNaN(price)||isNaN(qty)||qty<=0){alert('እባክዎን ሁሉንም መስኮች በትክክል ይሙሉ!');return;}
 const i=products.findIndex(p=>p.code===code);
 if(i>-1){products[i].qty+=qty;products[i].price=price;products[i].cost=cost;}else products.push({code,name,cost,price,qty});
 saveData();generateQR(code,name);renderOwnerReport();
 ['p-code','p-name','p-cost','p-price','p-qty'].forEach(id=>document.getElementById(id).value='');
}

function generateQR(code,name){const c=document.getElementById('qrcode');c.innerHTML='';new QRCode(c,{text:code,width:180,height:180});document.getElementById('qr-label').innerText=`${name} (${code})`;document.getElementById('qr-result').classList.remove('hidden');}

function processSale(code){
 const product=products.find(p=>p.code===code);
 if(!product){alert('ዕቃው በሲስተሙ ውስጥ አልተገኘም!');return;}
 if(product.qty<=0){alert(`የ"${product.name}" stock አልቋል!`);return;}
 product.qty-=1;
 sales.unshift({code:product.code,name:product.name,price:product.price,cost:product.cost,date:new Date().toLocaleString('am-ET')});
 saveData();renderSalesLog();renderOwnerReport();alert(`የተሸጠ: ${product.name} - ${product.price} ETB`);
}

function sellByManualCode(){const code=document.getElementById('manual-code').value.trim();if(code){processSale(code);document.getElementById('manual-code').value='';}}

function addExpense(){
 const desc=document.getElementById('exp-desc').value.trim(),amount=parseFloat(document.getElementById('exp-amount').value);
 if(!desc||isNaN(amount)||amount<0){alert('የወጪውን ምክንያት እና መጠን በትክክል ይሙሉ!');return;}
 expenses.push({desc,amount,date:new Date().toLocaleDateString('am-ET')});saveData();renderOwnerReport();
 document.getElementById('exp-desc').value='';document.getElementById('exp-amount').value='';
}

function renderOwnerReport(){
 const totalSales=sales.reduce((a,x)=>a+x.price,0),totalCost=sales.reduce((a,x)=>a+x.cost,0),totalExpense=expenses.reduce((a,x)=>a+x.amount,0),stock=products.reduce((a,x)=>a+x.qty,0);
 document.getElementById('total-sales-val').innerText=`${totalSales.toFixed(2)} ETB`;
 document.getElementById('total-expense-val').innerText=`${totalExpense.toFixed(2)} ETB`;
 document.getElementById('net-profit-val').innerText=`${(totalSales-totalCost-totalExpense).toFixed(2)} ETB`;
 document.getElementById('total-stock-val').innerText=stock;
 const body=document.getElementById('inventory-body');body.innerHTML='';
 products.forEach(p=>body.insertAdjacentHTML('beforeend',`<tr><td>${escapeHtml(p.code)}</td><td>${escapeHtml(p.name)}</td><td>${p.price.toFixed(2)} ETB</td><td><strong>${p.qty}</strong></td><td><button class="btn-danger" onclick="deleteProduct('${encodeURIComponent(p.code)}')">ሰርዝ</button></td></tr>`));
}

function deleteProduct(encoded){const code=decodeURIComponent(encoded);if(confirm('እርግጠኛ ነዎት ይህን ዕቃ መሰረዝ ይፈልጋሉ?')){products=products.filter(p=>p.code!==code);saveData();renderOwnerReport();}}

function renderSalesLog(){const body=document.getElementById('sales-log-body');body.innerHTML='';sales.slice(0,10).forEach(s=>body.insertAdjacentHTML('beforeend',`<tr><td>${escapeHtml(s.name)}</td><td>1</td><td>${s.price.toFixed(2)} ETB</td><td>${escapeHtml(s.date)}</td></tr>`));}

function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

function initScanner(){
 if(html5QrcodeScanner)return;
 html5QrcodeScanner=new Html5QrcodeScanner("reader",{fps:10,qrbox:{width:220,height:220}},false);
 html5QrcodeScanner.render(decodedText=>processSale(decodedText),()=>{});
}

function stopScanner(){if(html5QrcodeScanner){html5QrcodeScanner.clear().catch(()=>{}).finally(()=>{html5QrcodeScanner=null;});}}

document.addEventListener('DOMContentLoaded',()=>{renderSalesLog();initScanner();renderOwnerReport();});
