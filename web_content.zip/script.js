const initialNames = [
  "سیب زمینی", "پیاز سفید", "پیاز زرد", "پیاز قرمز", "گوجه",
  "بادمجان", "کدو", "خیارسبز", "کلم سفید", "کلم قرمز",
  "گل کلم", "کاهو", "کرفس", "هویج", "بامیه",
  "لوبیاسیز", "فلفل دلمه", "فلفل تند", "سیب زرد", "سیب قرمز",
  "کیوی", "انار", "نارنگی", "پرتقال", "موز خارجی",
  "موز ایرانی", "انگور سیاه", "انگور عسکری", "خرمالو", "هندانه",
  "شمام", "هشت خط", "هلو", "شلیل", "شمس", "به", "توت فرنگی"
];

let nextId = 1;
let products = initialNames.map(name => ({ id: nextId++, name, count: 0, active: true }));

const table = document.getElementById("fruit-table");
const totalCount = document.getElementById("total-count");
const fruitCount = document.getElementById("fruit-count");
const message = document.getElementById("message");

function showMessage(text) { message.textContent = text || ""; }

function render() {
  table.innerHTML = "";
  const active = products.filter(p => p.active);
  for (let i = 0; i < active.length; i += 4) {
    const tr = document.createElement("tr");
    active.slice(i, i + 4).forEach(product => {
      const td = document.createElement("td");
      const card = document.createElement("div");
      card.className = "fruit-cell";

      const nameButton = document.createElement("button");
      nameButton.className = "fruit-name";
      nameButton.textContent = product.name;
      nameButton.setAttribute("aria-label", product.name + "؛ افزایش تعداد");
      nameButton.addEventListener("click", () => {
        product.count += 1;
        render();
      });

      const bottom = document.createElement("div");
      bottom.className = "fruit-bottom";
      const count = document.createElement("span");
      count.className = "count";
      count.textContent = product.count;

      const minus = document.createElement("button");
      minus.className = "minus";
      minus.textContent = "−";
      minus.setAttribute("aria-label", "کم کردن " + product.name);
      minus.addEventListener("click", () => {
        product.count = Math.max(0, product.count - 1);
        render();
      });

      bottom.append(count, minus);
      card.append(nameButton, bottom);
      td.append(card);
      tr.append(td);
    });

    while (tr.children.length < 4) {
      const empty = document.createElement("td");
      tr.append(empty);
    }
    table.append(tr);
  }

  fruitCount.textContent = active.length;
  totalCount.textContent = active.reduce((sum, p) => sum + p.count, 0);
}

document.getElementById("add-fruit").addEventListener("click", () => {
  const name = prompt("نام میوه یا محصول جدید را وارد کنید:");
  if (!name || !name.trim()) return;
  if (products.filter(p => p.active).length >= 40) {
    showMessage("حداکثر ۴۰ محصول قابل نمایش است. ابتدا یک محصول را حذف کنید.");
    return;
  }
  if (products.some(p => p.active && p.name.trim() === name.trim())) {
    showMessage("این محصول در فهرست وجود دارد.");
    return;
  }
  products.push({ id: nextId++, name: name.trim(), count: 0, active: true });
  showMessage("محصول اضافه شد.");
  render();
});

document.getElementById("delete-fruit").addEventListener("click", () => {
  const name = prompt("نام دقیق محصولی را که می‌خواهید حذف شود وارد کنید:");
  if (!name) return;
  const product = products.find(p => p.active && p.name.trim() === name.trim());
  if (!product) {
    showMessage("محصولی با این نام پیدا نشد.");
    return;
  }
  product.active = false;
  showMessage("محصول حذف شد.");
  render();
});

document.getElementById("clear-all").addEventListener("click", () => {
  if (!confirm("همه محصولات از فهرست حذف شوند؟")) return;
  products.forEach(p => p.active = false);
  showMessage("فهرست خالی شد.");
  render();
});

document.getElementById("restore-all").addEventListener("click", () => {
  const activeNames = new Set(products.filter(p => p.active).map(p => p.name));
  initialNames.forEach(name => {
    if (!activeNames.has(name)) {
      const existing = products.find(p => p.name === name);
      if (existing) existing.active = true;
      else products.push({ id: nextId++, name, count: 0, active: true });
    }
  });
  if (products.filter(p => p.active).length > 40) {
    showMessage("برای افزودن همه محصولات، ابتدا چند محصول اضافی را حذف کنید.");
  } else {
    showMessage("فهرست اصلی اضافه شد.");
  }
  render();
});

render();
