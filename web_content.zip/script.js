document.getElementById('analyzeBtn').addEventListener('click', function() {
    const timeVal = document.getElementById('sessionTime').value;
    const coteVal = parseFloat(document.getElementById('refCote').value);

    if (!timeVal || isNaN(coteVal)) {
        alert('Veuillez renseigner tous les champs requis.');
        return;
    }

    const btn = document.getElementById('analyzeBtn');
    const loader = document.getElementById('loader');
    const panel = document.getElementById('resultPanel');

    btn.style.display = 'none';
    panel.style.display = 'none';
    loader.style.display = 'block';

    setTimeout(() => {
        loader.style.display = 'none';
        btn.style.display = 'block';
        panel.style.display = 'block';

        let seed = 0;
        for (let i = 0; i < timeVal.length; i++) {
            seed += timeVal.charCodeAt(i);
        }
        seed += coteVal * 7;

        const randomMod = (Math.sin(seed) + 1) / 2;

        // Calcul des 3 cibles : Minimum (x3), Moyenne (x5), Max (x10)
        let valMin = 3.00 + (randomMod * 1.50);
        let valMid = 5.00 + (randomMod * 2.50);
        let valMax = 10.00 + (randomMod * 5.00);

        if (coteVal > 5.0) {
            valMin *= 1.1;
            valMid *= 1.15;
            valMax *= 1.2;
        }
        if (valMax > 25.0) valMax = 24.50;

        const [hours, minutes] = timeVal.split(':').map(Number);

        function addMinutes(h, m, addM) {
            let totalM = m + addM;
            let totalH = h + Math.floor(totalM / 60);
            totalM %= 60;
            totalH %= 24;
            return String(totalH).padStart(2, '0') + ':' + String(totalM).padStart(2, '0');
        }

        let timeMinStr = addMinutes(hours, minutes, Math.floor(randomMod * 5) + 2);
        let timeMidStr = addMinutes(hours, minutes, Math.floor(randomMod * 8) + 8);
        let timeMaxStr = addMinutes(hours, minutes, Math.floor(randomMod * 12) + 16);

        let starCount = Math.floor((coteVal % 3) + 3);
        if (starCount > 5) starCount = 5;

        let starsStr = '';
        for (let s = 0; s < 5; s++) {
            starsStr += (s < starCount) ? '★' : '☆';
        }

        document.getElementById('targetMin').textContent = valMin.toFixed(2) + 'x';
        document.getElementById('timeMin').textContent = timeMinStr;

        document.getElementById('targetMid').textContent = valMid.toFixed(2) + 'x';
        document.getElementById('timeMid').textContent = timeMidStr;

        document.getElementById('targetMax').textContent = valMax.toFixed(2) + 'x';
        document.getElementById('timeMax').textContent = timeMaxStr;

        document.getElementById('starsOutput').textContent = starsStr;

    }, 1200);
});
