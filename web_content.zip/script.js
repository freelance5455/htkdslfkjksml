let pool=[],current=0,answers=[],marked=[],remaining=0,timerId=null,submitted=false;
const $=id=>document.getElementById(id);
const chapters=[...new Set(QUESTION_BANK.map(q=>q.chapter))];
const sections=[...new Set(QUESTION_BANK.map(q=>q.section))];
$("bankInfo").textContent=`${QUESTION_BANK.length} questions extracted from the uploaded Biology Module 01 PDF.`;
chapters.forEach(c=>{let o=document.createElement("option");o.value=c;o.textContent=c;$("chapterSelect").appendChild(o)});
function refreshSections(){
 const c=$("chapterSelect").value;$("sectionSelect").innerHTML='<option value="all">All sections</option>';
 [...new Set(QUESTION_BANK.filter(q=>c==="all"||q.chapter===c).map(q=>q.section))].forEach(s=>{let o=document.createElement("option");o.value=s;o.textContent=s;$("sectionSelect").appendChild(o)});
}
$("chapterSelect").onchange=refreshSections;
function updateTimer(){if(!$("timer"))return;if(remaining<=0){$("timer").textContent="No timer";return}let m=String(Math.floor(remaining/60)).padStart(2,"0"),s=String(remaining%60).padStart(2,"0");$("timer").textContent=`${m}:${s}`;}
function startTest(){
 const c=$("chapterSelect").value,s=$("sectionSelect").value,mode=$("modeSelect").value,count=$("countSelect").value;
 let filtered=QUESTION_BANK.filter(q=>(c==="all"||q.chapter===c)&&(s==="all"||q.section===s));
 if(mode==="random")filtered=filtered.slice().sort(()=>Math.random()-.5);
 pool=count==="all"?filtered:filtered.slice(0,Math.min(Number(count),filtered.length));
 if(!pool.length){alert("No questions found for this selection.");return}
 current=0;answers=Array(pool.length).fill(null);marked=Array(pool.length).fill(false);submitted=false;
 remaining=Number($("timeSelect").value)*60;clearInterval(timerId);
 if(remaining>0){updateTimer();timerId=setInterval(()=>{remaining--;updateTimer();if(remaining<=0){clearInterval(timerId);alert("Time is up. Test submitted automatically.");submitTest();}},1000)}else $("timer").textContent="No timer";
 $("setupScreen").classList.add("hidden");$("resultScreen").classList.add("hidden");$("testScreen").classList.remove("hidden");render();
}
function render(){
 const q=pool[current];$("questionCounter").textContent=`Question ${current+1} of ${pool.length}`;$("answeredCounter").textContent=`Answered: ${answers.filter(x=>x!==null).length}`;
 $("progressBar").style.width=((current+1)/pool.length*100)+"%";$("questionLabel").textContent=`${q.chapter} • ${q.section} • Q${q.number}`;
 $("questionText").textContent=q.question;$("options").innerHTML="";
 q.options.forEach((opt,i)=>{let b=document.createElement("button");b.className="option";if(answers[current]===i)b.classList.add("selected");b.textContent=String.fromCharCode(65+i)+". "+opt;b.onclick=()=>{answers[current]=i;render()};$("options").appendChild(b)});
 $("prevBtn").disabled=current===0;$("nextBtn").textContent=current===pool.length-1?"Finish":"Next";$("markBtn").textContent=marked[current]?"★ Marked":"☆ Mark";renderPalette();
}
function renderPalette(){$("palette").innerHTML="";pool.forEach((q,i)=>{let b=document.createElement("button");b.textContent=i+1;if(answers[i]!==null)b.classList.add("answered");if(i===current)b.classList.add("current");if(marked[i])b.classList.add("marked");b.onclick=()=>{current=i;render()};$("palette").appendChild(b)})}
function submitTest(){if(submitted)return;submitted=true;clearInterval(timerId);let correct=0,wrong=0,skipped=0;answers.forEach((a,i)=>{if(a===null)skipped++;else if(a===pool[i].answer)correct++;else wrong++});let score=correct*4-wrong;let attempted=correct+wrong;
 $("testScreen").classList.add("hidden");$("resultScreen").classList.remove("hidden");$("scoreText").textContent=`${score} / ${pool.length*4}`;$("correctCount").textContent=correct;$("wrongCount").textContent=wrong;$("skippedCount").textContent=skipped;$("accuracy").textContent=(attempted?Math.round(correct/attempted*100):0)+"%";$("resultMessage").textContent="Review the answers below and revise the related NCERT topics."; $("reviewList").innerHTML="";
}
function review(){$("reviewList").innerHTML="<h3>Answer Review</h3>";pool.forEach((q,i)=>{let d=document.createElement("div");d.className="review-item";let your=answers[i]===null?"Not answered":q.options[answers[i]];d.innerHTML=`<b>Q${i+1}. ${q.question}</b><div>Your answer: ${your}</div><div>Correct answer: ${q.options[q.answer]}</div><p>Source: ${q.chapter} • ${q.section} • PDF page ${q.sourcePage}</p>`;$("reviewList").appendChild(d)})}
$("startBtn").onclick=startTest;$("prevBtn").onclick=()=>{if(current>0){current--;render()}};$("nextBtn").onclick=()=>{if(current<pool.length-1){current++;render()}else if(confirm("Submit your test now?"))submitTest()};$("markBtn").onclick=()=>{marked[current]=!marked[current];render()};$("submitBtn").onclick=()=>{if(confirm("Are you sure you want to submit?"))submitTest()};$("reviewBtn").onclick=review;$("homeBtn").onclick=()=>{clearInterval(timerId);$("resultScreen").classList.add("hidden");$("setupScreen").classList.remove("hidden");$("timer").textContent="--:--"};
refreshSections();
