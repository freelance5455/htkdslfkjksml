(function () {
  var KEY = "classx-v1";

  // Бастапқы күй: бос. Оқушылар, бөлме, кесте және қоңырау уақытын әр адам өзі енгізеді.
  function todayISO() {
    var d = new Date();
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }
  var DEFAULTS = {
    startDate: todayISO(),
    startDesk: 1,
    desks: [],
    rooms: [],
    schedule: {
      1: { before: [], after: [] }, 2: { before: [], after: [] }, 3: { before: [], after: [] },
      4: { before: [], after: [] }, 5: { before: [], after: [] }
    },
    // Қоңырау уақыты (минутпен: [басталуы, аяқталуы])
    bells: { before: [], after: [] }
  };

  var DAYS_FULL = ["Жексенбі", "Дүйсенбі", "Сейсенбі", "Сәрсенбі", "Бейсенбі", "Жұма", "Сенбі"];
  var DAYS_SHORT = ["Жс", "Дс", "Сс", "Ср", "Бс", "Жм", "Сб"];
  var MONTHS = ["қаңтар", "ақпан", "наурыз", "сәуір", "мамыр", "маусым", "шілде", "тамыз", "қыркүйек", "қазан", "қараша", "желтоқсан"];

  function clone(x) { return JSON.parse(JSON.stringify(x)); }
  function pad2(n) { return (n < 10 ? "0" : "") + n; }
  function fmtT(min) { return pad2(Math.floor(min / 60)) + ":" + pad2(min % 60); }
  function parseRange(line) {
    var m = /^\s*(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})\s*$/.exec(line);
    if (!m) return null;
    var h1 = +m[1], m1 = +m[2], h2 = +m[3], m2 = +m[4];
    if (h1 > 23 || h2 > 23 || m1 > 59 || m2 > 59) return null;
    var a = h1 * 60 + m1, b = h2 * 60 + m2;
    return b > a ? [a, b] : null;
  }
  function dur(min) { return min >= 60 ? Math.floor(min / 60) + " сағ" + (min % 60 ? " " + (min % 60) + " мин" : "") : min + " мин"; }
  function el(id) { return document.getElementById(id); }
  function h(tag, props, kids) {
    var e = document.createElement(tag);
    if (props) {
      Object.keys(props).forEach(function (k) {
        var v = props[k];
        if (k === "class") e.className = v;
        else if (k === "text") e.textContent = v;
        else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), v);
        else e.setAttribute(k, v);
      });
    }
    (kids || []).forEach(function (c) {
      if (c) e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return e;
  }

  function valid(o) {
    if (!o || !Array.isArray(o.desks) || !Array.isArray(o.rooms) || !o.schedule) return false;
    if (typeof o.startDate !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(o.startDate) || typeof o.startDesk !== "number") return false;
    for (var d = 1; d <= 5; d++) {
      var s = o.schedule[d];
      if (!s || !Array.isArray(s.before) || !Array.isArray(s.after)) return false;
    }
    for (var i = 0; i < o.rooms.length; i++) {
      if (!o.rooms[i] || !o.rooms[i].days) return false;
    }
    return true;
  }
  function validBells(b) {
    if (!b || !Array.isArray(b.before) || !Array.isArray(b.after)) return false;
    return b.before.concat(b.after).every(function (r) { return Array.isArray(r) && r.length === 2 && typeof r[0] === "number" && typeof r[1] === "number"; });
  }
  function load() {
    try {
      var raw = localStorage.getItem(KEY);
      if (raw) {
        var o = JSON.parse(raw);
        if (valid(o)) { if (!validBells(o.bells)) o.bells = clone(DEFAULTS.bells); return o; }
      }
    } catch (e) {}
    return clone(DEFAULTS);
  }
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(S)); return true; } catch (e) { return false; }
  }

  var S = load();

  // Күн есептері
  function dayNumber(d) { return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 86400000); }
  function dow(n) { return (n + 4) % 7; } // 0 = жексенбі
  function isSchool(n) { var w = dow(n); return w !== 0 && w !== 6; }
  function step(n, dir) { do { n += dir; } while (!isSchool(n)); return n; }
  function startN() {
    var p = S.startDate.split("-");
    return Math.floor(Date.UTC(+p[0], +p[1] - 1, +p[2]) / 86400000);
  }
  function minView() { var s = startN(); return isSchool(s) ? s : step(s, 1); }
  function deskIndex(n) {
    var c = 0;
    for (var i = startN(); i < n; i++) { if (isSchool(i)) c++; }
    if (!S.desks.length) return -1;
    return ((S.startDesk - 1) + c) % S.desks.length;
  }
  function fmt(n) {
    var d = new Date(n * 86400000);
    return d.getUTCDate() + " " + MONTHS[d.getUTCMonth()];
  }
  function fmtFull(n) {
    return fmt(n) + " " + new Date(n * 86400000).getUTCFullYear();
  }

  var todayN = dayNumber(new Date());
  var viewN, ttDow = 1;
  function goToday() {
    viewN = todayN;
    if (viewN < minView()) viewN = minView();
  }
  goToday();
  ttDow = isSchool(viewN) ? dow(viewN) : dow(step(viewN, 1));

  // Сынып орналасуы: 3 баған, нөмірлер бағанмен жүреді (1–5, 6–10, 11–...). 0 = бос орын
  function layout(N) {
    var rows = Math.ceil(N / 3), out = [];
    for (var r = 0; r < rows; r++) {
      var row = [];
      for (var c = 0; c < 3; c++) { var k = c * rows + r + 1; row.push(k <= N ? k : 0); }
      out.push(row);
    }
    return out;
  }
  el("todayLabel").textContent = DAYS_FULL[dow(todayN)] + ", " + fmt(todayN);

  // Анимация көмекшілері (азайтылған қозғалыс қосулы болса, өшірулі)
  function cascade(nodes, step) {
    if (reduce) return;
    Array.prototype.forEach.call(nodes, function (n, i) {
      n.animate([{ opacity: 0, transform: "translateY(14px)" }, { opacity: 1, transform: "none" }],
        { duration: 420, delay: i * (step || 45), easing: "cubic-bezier(0.2, 0.8, 0.3, 1)", fill: "backwards" });
    });
  }
  function slideIn(nodes, dir) {
    if (reduce) return;
    nodes.forEach(function (n, i) {
      if (!n || n.hidden) return;
      n.animate([{ opacity: 0, transform: "translateX(" + (dir * 38) + "px)" }, { opacity: 1, transform: "none" }],
        { duration: 380, delay: i * 45, easing: "cubic-bezier(0.2, 0.8, 0.3, 1)", fill: "backwards" });
    });
  }
  function dutySwap(dir) {
    slideIn([el("dDesk"), el("dNames"), el("dRest")], dir);
    var cur = el("deskMap").querySelector(".dm.cur");
    if (cur && !reduce) cur.animate([{ transform: "scale(0.6)" }, { transform: "scale(1.2)", offset: 0.6 }, { transform: "scale(1)" }], { duration: 480, delay: 120, easing: "ease-out", fill: "backwards" });
    cascade(el("nextList").children, 40);
  }

  // Кезекші беті
  function renderDuty() {
    var idx = deskIndex(viewN);
    var isToday = viewN === todayN;
    var school = isSchool(viewN);
    var none = !S.desks.length;
    el("dEmpty").hidden = !none;
    ["dNav", "nextLabel", "nextList"].forEach(function (id) { el(id).hidden = none; });
    if (none) {
      ["dDesk", "dNames", "dMapLabel", "deskMap", "dRest", "dNote"].forEach(function (id) { el(id).hidden = true; });
      el("dEyebrow").textContent = isToday ? "Бүгін" : "Кезекші";
      el("dDate").textContent = DAYS_FULL[dow(viewN)] + ", " + fmt(viewN);
      return;
    }
    el("dEyebrow").textContent = school ? (isToday ? "Бүгінгі кезекші" : "Кезекші") : (isToday ? "Бүгін" : "Демалыс");
    ["dDesk", "dNames", "dMapLabel", "deskMap"].forEach(function (id) { el(id).hidden = !school; });
    el("dRest").hidden = school;
    if (!school) {
      var nx = step(viewN, 1);
      el("dRestSub").textContent = "Кезекшілік жоқ. Келесі оқу күні: " + DAYS_FULL[dow(nx)] + ", " + fmt(nx) + ".";
    }
    el("dDate").textContent = DAYS_FULL[dow(viewN)] + ", " + fmt(viewN);
    el("dNum").textContent = idx + 1;
    var names = el("dNames");
    names.textContent = "";
    S.desks[idx].forEach(function (name) { names.appendChild(h("li", { text: name })); });
    var map = el("deskMap");
    map.textContent = "";
    layout(S.desks.length).forEach(function (row) {
      row.forEach(function (k) {
        map.appendChild(k ? h("span", { class: "dm" + (school && k - 1 === idx ? " cur" : ""), text: String(k) }) : h("span", { class: "dm gap" }));
      });
    });
    var note = el("dNote");
    if (todayN < minView() && viewN === minView()) {
      note.textContent = "Кезекшілік " + fmt(minView()) + " күні басталады.";
      note.hidden = false;
    } else {
      note.hidden = true;
    }
    el("prevBtn").disabled = viewN <= minView();

    var list = el("nextList");
    list.textContent = "";
    var n = viewN;
    for (var i = 0; i < 5; i++) {
      n = step(n, 1);
      var di = deskIndex(n);
      var when = h("span", { class: "when", text: DAYS_FULL[dow(n)] }, [h("small", { text: fmt(n) })]);
      list.appendChild(h("li", null, [
        when,
        h("span", { class: "no", text: "№ " + (di + 1) }),
        h("span", { class: "who", text: S.desks[di].join(", ") })
      ]));
    }
  }
  el("dGo").addEventListener("click", function () { showTab("settings"); });
  el("prevBtn").addEventListener("click", function () {
    if (viewN > minView()) { viewN = step(viewN, -1); renderDuty(); dutySwap(-1); }
  });
  el("nextBtn").addEventListener("click", function () { viewN = step(viewN, 1); renderDuty(); dutySwap(1); });
  el("todayBtn").addEventListener("click", function () { var was = viewN; goToday(); renderDuty(); if (was !== viewN) dutySwap(viewN > was ? 1 : -1); });

  // Сабақ беті
  function periods(d) {
    var sc = S.schedule[d], out = [];
    ["before", "after"].forEach(function (part) {
      sc[part].forEach(function (name, i) {
        var b = S.bells[part][i];
        if (b) out.push({ part: part, i: i, name: name, start: b[0], end: b[1] });
      });
    });
    out.sort(function (a, b) { return a.start - b.start; });
    return out;
  }
  function plabel(p) { return (p.part === "after" ? "Түстен кейін " : "") + (p.i + 1) + "-сабақ"; }
  function nowState() {
    var now = new Date();
    var m = now.getHours() * 60 + now.getMinutes() + now.getSeconds() / 60;
    var ps = isSchool(todayN) ? periods(dow(todayN)) : [], idx = -1;
    for (var i = 0; i < ps.length; i++) if (m >= ps[i].start && m < ps[i].end) idx = i;
    return { m: m, ps: ps, idx: idx };
  }
  function renderNowInner() {
    var main = el("nowMain"), sub = el("nowSub"), bar = el("nowBar");
    bar.hidden = true;
    if (!isSchool(todayN)) {
      var nx0 = step(todayN, 1);
      main.textContent = "Бүгін демалыс күні";
      sub.textContent = "Келесі оқу күні: " + DAYS_FULL[dow(nx0)] + ", " + fmt(nx0);
      return;
    }
    var st = nowState(), ps = st.ps, m = st.m;
    if (!ps.length) { main.textContent = "Бүгін сабақ жоқ"; sub.textContent = ""; return; }
    if (st.idx >= 0) {
      var p = ps[st.idx], nx = ps[st.idx + 1];
      main.textContent = plabel(p) + " · " + p.name;
      sub.textContent = fmtT(p.start) + "–" + fmtT(p.end) + " · " + dur(Math.ceil(p.end - m)) + " қалды" + (nx ? " · Келесі: " + nx.name : "");
      bar.hidden = false;
      el("nowFill").style.width = Math.max(0, Math.min(100, (m - p.start) / (p.end - p.start) * 100)).toFixed(1) + "%";
      return;
    }
    var next = null, prev = null;
    for (var i = 0; i < ps.length; i++) {
      if (ps[i].start > m && !next) next = ps[i];
      if (ps[i].end <= m) prev = ps[i];
    }
    if (!next) {
      main.textContent = "Бүгінгі сабақ аяқталды";
      sub.textContent = "Соңғы сабақ " + fmtT(ps[ps.length - 1].end) + "-та біткен";
      return;
    }
    var wait = Math.ceil(next.start - m);
    if (!prev) {
      main.textContent = "Сабақ " + fmtT(next.start) + "-та басталады";
      sub.textContent = plabel(next) + ": " + next.name + " · " + dur(wait) + " қалды";
      return;
    }
    var lunch = prev.part === "before" && next.part === "after" && next.start - prev.end >= 30;
    main.textContent = lunch ? "Түскі үзіліс" : "Үзіліс";
    sub.textContent = "Келесі: " + plabel(next) + " · " + next.name + " · " + fmtT(next.start) + " (" + dur(wait) + ")";
  }

  var lastNowKey = null;
  function renderNow() {
    renderNowInner();
    var key = el("nowMain").textContent;
    if (lastNowKey !== null && key !== lastNowKey && !reduce) {
      var card = document.querySelector(".now-card");
      var base = getComputedStyle(card).boxShadow;
      card.animate([
        { transform: "scale(1)", boxShadow: base },
        { transform: "scale(1.04)", boxShadow: "0 0 0 4px rgba(91,155,255,0.55), 0 0 36px rgba(91,155,255,0.7)", offset: 0.35 },
        { transform: "scale(1)", boxShadow: base }
      ], { duration: 900, easing: "ease-out" });
      [el("nowMain"), el("nowSub")].forEach(function (n, i) {
        n.animate([{ opacity: 0, transform: "translateY(10px)" }, { opacity: 1, transform: "none" }], { duration: 500, delay: 150 + i * 90, easing: "ease-out", fill: "backwards" });
      });
    }
    lastNowKey = key;
  }

  function fillList(id, items, part, cur) {
    var ol = el(id);
    ol.textContent = "";
    items.forEach(function (name, i) {
      var b = S.bells[part][i];
      var isNow = cur && cur.part === part && cur.i === i;
      ol.appendChild(h("li", { class: isNow ? "now" : "" }, [
        h("span", { class: "ln", text: name }),
        h("span", { class: "lt", text: b ? fmtT(b[0]) + "–" + fmtT(b[1]) : "" })
      ]));
    });
  }
  function renderLessons() {
    el("ttTitle").textContent = DAYS_FULL[ttDow];
    var cur = null;
    if (isSchool(todayN) && ttDow === dow(todayN)) {
      var st = nowState();
      if (st.idx >= 0) cur = st.ps[st.idx];
    }
    fillList("ttBefore", S.schedule[ttDow].before, "before", cur);
    fillList("ttAfter", S.schedule[ttDow].after, "after", cur);
    var noLessons = !S.schedule[ttDow].before.length && !S.schedule[ttDow].after.length;
    el("ttEmpty").hidden = !noLessons;
    el("ttSheet").hidden = noLessons;
    var bb = S.bells.before, ba = S.bells.after;
    el("ttLunch").hidden = !(bb.length && ba.length);
    el("ttLunch").textContent = bb.length && ba.length ? "Түскі үзіліс · " + fmtT(bb[bb.length - 1][1]) + "–" + fmtT(ba[0][0]) : "Түскі үзіліс";
  }
  function renderTimetable() {
    var chips = el("chips");
    chips.textContent = "";
    for (var d = 1; d <= 5; d++) {
      (function (day) {
        var isT = isSchool(todayN) && dow(todayN) === day;
        chips.appendChild(h("button", {
          type: "button", role: "tab", class: "chip" + (isT ? " is-today" : ""),
          "aria-selected": day === ttDow ? "true" : "false", text: DAYS_SHORT[day],
          onclick: function () { ttDow = day; renderTimetable(); cascade(el("view-lesson").querySelectorAll(".lessons li"), 40); }
        }));
      })(d);
    }
    renderLessons();
    renderNow();
  }
  // Минут сайын жаңартып тұру (және түн ортасынан кейін күнді ауыстыру)
  function tick() {
    var tn = dayNumber(new Date());
    if (tn !== todayN) {
      todayN = tn;
      el("todayLabel").textContent = DAYS_FULL[dow(todayN)] + ", " + fmt(todayN);
      goToday();
      renderDuty();
      renderRooms();
      renderTimetable();
      return;
    }
    renderNow();
    renderLessons();
  }
  setInterval(tick, 15000);
  document.addEventListener("visibilitychange", function () { if (!document.hidden) tick(); });

  // Бөлме беті
  function roomCmp(a, b) {
    var x = parseFloat(a.r.no), y = parseFloat(b.r.no);
    if (!isNaN(x) && !isNaN(y) && x !== y) return x - y;
    var s = String(a.r.no).localeCompare(String(b.r.no));
    return s || a.i - b.i;
  }
  function sortedRooms() {
    return S.rooms.map(function (r, i) { return { r: r, i: i }; }).sort(roomCmp).map(function (x) { return x.r; });
  }
  function renderRooms() {
    var wrap = el("roomList");
    wrap.textContent = "";
    var sorted = sortedRooms();
    el("roomEmpty").hidden = sorted.length > 0;
    var todayDow = dow(todayN);
    sorted.forEach(function (room) {
      var ul = h("ul", { class: "room-days" });
      var any = false;
      for (var d = 1; d <= 5; d++) {
        var names = room.days[d] || [];
        if (!names.length) continue;
        any = true;
        ul.appendChild(h("li", { class: d === todayDow ? "is-today" : "" }, [
          h("span", { class: "day", text: DAYS_FULL[d] }),
          h("span", { class: "who", text: names.join(" және ") })
        ]));
      }
      if (!any) ul.appendChild(h("li", { class: "none", text: "Кезекші жоқ" }));
      wrap.appendChild(h("div", { class: "room" }, [h("div", { class: "room-no", text: room.no }), ul]));
    });
  }

  // Баптаулар
  var editing = false, draft = null, errorMsg = "", noticeMsg = "", noticeBad = false, confirmReset = false;

  function splitNames(s) {
    return String(s).split(/[,;\n]| және /).map(function (x) { return x.trim(); }).filter(Boolean);
  }
  function lines(s) {
    return String(s).split("\n").map(function (x) { return x.trim(); }).filter(Boolean);
  }
  function makeDraft() {
    var rooms = sortedRooms().map(function (r) {
      var days = {};
      for (var d = 1; d <= 5; d++) days[d] = (r.days[d] || []).join(", ");
      return { no: String(r.no), days: days };
    });
    var schedule = {};
    for (var d = 1; d <= 5; d++) {
      schedule[d] = { before: S.schedule[d].before.join("\n"), after: S.schedule[d].after.join("\n") };
    }
    return {
      startDate: S.startDate,
      startDesk: String(S.startDesk),
      desks: S.desks.map(function (p) { return [p[0] || "", p[1] || ""]; }),
      rooms: rooms,
      schedule: schedule,
      bells: {
        before: S.bells.before.map(function (r) { return fmtT(r[0]) + "-" + fmtT(r[1]); }).join("\n"),
        after: S.bells.after.map(function (r) { return fmtT(r[0]) + "-" + fmtT(r[1]); }).join("\n")
      }
    };
  }

  function commit() {
    var desks = draft.desks
      .map(function (p) { return [p[0].trim(), p[1].trim()].filter(Boolean); })
      .filter(function (p) { return p.length; });

    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(draft.startDate || "");
    if (!m) return "Кезекшілік басталатын күнді таңдаңыз.";
    var chk = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
    if (chk.getUTCMonth() !== +m[2] - 1) return "Кезекшілік басталатын күнді дұрыс таңдаңыз.";

    var sd = parseInt(draft.startDesk, 10);
    if (!desks.length) sd = 1;
    else if (!(sd >= 1 && sd <= desks.length)) return "Бірінші кезекші парта 1 мен " + desks.length + " аралығында болуы керек.";

    var rooms = [];
    for (var i = 0; i < draft.rooms.length; i++) {
      var r = draft.rooms[i];
      var no = r.no.trim();
      var days = {}, any = false;
      for (var d = 1; d <= 5; d++) { days[d] = splitNames(r.days[d]); if (days[d].length) any = true; }
      if (!no && !any) continue;
      if (!no) return "Бөлме нөмірін жазыңыз.";
      rooms.push({ no: no, days: days });
    }

    var schedule = {};
    for (var k = 1; k <= 5; k++) {
      schedule[k] = { before: lines(draft.schedule[k].before), after: lines(draft.schedule[k].after) };
    }

    var bells = { before: [], after: [] };
    var bp = ["before", "after"];
    for (var q = 0; q < bp.length; q++) {
      var bl = lines(draft.bells[bp[q]]);
      for (var w = 0; w < bl.length; w++) {
        var pr = parseRange(bl[w]);
        if (!pr) return "Қоңырау уақытын 08:20-09:05 түрінде жазыңыз: «" + bl[w] + "»";
        bells[bp[q]].push(pr);
      }
    }

    S = { startDate: draft.startDate, startDesk: sd, desks: desks, rooms: rooms, schedule: schedule, bells: bells };
    var ok = save();
    noticeMsg = ok ? "Сақталды." : "Өзгеріс қолданылды, бірақ браузер оны жадқа сақтай алмады. Бетті жапқанда жоғалады.";
    noticeBad = !ok;
    return "";
  }

  function bareInput(id, value, label, onInput, placeholder) {
    var inp = h("input", { id: id, type: "text", class: "field", value: value, "aria-label": label, autocomplete: "off" });
    if (placeholder) inp.setAttribute("placeholder", placeholder);
    inp.addEventListener("input", function () { onInput(inp.value); });
    return inp;
  }
  function labeled(id, label, control) {
    return h("label", { class: "fld", "for": id }, [h("span", { class: "eyebrow", text: label }), control]);
  }
  function card(title, kids, cls) {
    return h("div", { class: "card" + (cls ? " " + cls : "") }, (title ? [h("h3", { text: title })] : []).concat(kids));
  }

  function renderSettings() {
    var body = el("setBody");
    var actions = el("setActions");
    body.textContent = "";
    actions.textContent = "";

    if (!editing) {
      actions.appendChild(h("button", {
        id: "editBtn", type: "button", class: "btn primary", text: "Өзгерту",
        onclick: function () { editing = true; draft = makeDraft(); errorMsg = ""; noticeMsg = ""; confirmReset = false; renderSettings(); }
      }));
      if (noticeMsg) body.appendChild(h("p", { class: noticeBad ? "err" : "ok", text: noticeMsg }));

      body.appendChild(card("Кезекшілік", [
        h("div", { text: S.desks.length ? fmtFull(startN()) + " күні " + S.startDesk + "-парта кезекші. Әр оқу күні келесі партаға ауысады, демалыс күндері саналмайды." : "Әлі дерек енгізілген жоқ. «Өзгерту» батырмасын басып, партадағы оқушыларды енгізіңіз." })
      ]));

      var deskRows = S.desks.map(function (p, i) {
        return h("li", null, [h("span", { class: "k", text: String(i + 1) }), h("span", { class: "v", text: p.join(", ") })]);
      });
      body.appendChild(card("Партадағы оқушылар", deskRows.length ? [h("ul", { class: "kv" }, deskRows)] : [h("div", { text: "Әлі дерек енгізілген жоқ" })]));

      var roomRows = sortedRooms().map(function (r) {
        var parts = [];
        for (var d = 1; d <= 5; d++) { if ((r.days[d] || []).length) parts.push(DAYS_SHORT[d] + ": " + r.days[d].join(" және ")); }
        return h("li", null, [h("span", { class: "k", text: r.no }), h("span", { class: "v", text: parts.join(" · ") || "Кезекші жоқ" })]);
      });
      body.appendChild(card("Бөлмелер", roomRows.length ? [h("ul", { class: "kv" }, roomRows)] : [h("div", { text: "Әлі дерек енгізілген жоқ" })]));

      var cnt = [];
      for (var d = 1; d <= 5; d++) {
        var c = S.schedule[d].before.length + S.schedule[d].after.length;
        cnt.push(h("li", null, [h("span", { class: "k", text: DAYS_SHORT[d] }), h("span", { class: "v", text: c + " сабақ" })]));
      }
      body.appendChild(card("Сабақ кестесі", [h("ul", { class: "kv" }, cnt)]));

      function bellRows(list) {
        return list.map(function (r, i) { return h("li", null, [h("span", { class: "k", text: String(i + 1) }), h("span", { class: "v", text: fmtT(r[0]) + "–" + fmtT(r[1]) })]); });
      }
      body.appendChild(card("Қоңырау кестесі", (S.bells.before.length || S.bells.after.length) ? [
        h("div", { class: "eyebrow", text: "Түске дейін" }), h("ul", { class: "kv" }, bellRows(S.bells.before)),
        h("div", { class: "eyebrow", text: "Түстен кейін" }), h("ul", { class: "kv" }, bellRows(S.bells.after))
      ] : [h("div", { text: "Әлі дерек енгізілген жоқ" })]));

      var bk = h("textarea", { id: "bkText", class: "inp", rows: "4", placeholder: "Көшірме коды осында шығады немесе қалпына келтіру үшін осында қойыңыз" });
      body.appendChild(card("Көшірме (деректерді сақтап қою)", [
        h("div", { text: "Сайт мекенжайы өзгерсе немесе браузер тазаланса, деректер жоғалуы мүмкін. Алдын ала кодты көшіріп қойыңыз." }),
        bk,
        h("div", { class: "row" }, [
          h("button", { id: "bkMake", type: "button", class: "btn", text: "Көшірме алу", onclick: function () {
            bk.value = JSON.stringify(S);
            bk.focus(); bk.select();
            try { if (navigator.clipboard) navigator.clipboard.writeText(bk.value); } catch (e) {}
          } }),
          h("button", { id: "bkLoad", type: "button", class: "btn", text: "Қалпына келтіру", onclick: function () {
            var o = null;
            try { o = JSON.parse(bk.value); } catch (e) {}
            if (o && valid(o)) {
              if (!validBells(o.bells)) o.bells = clone(DEFAULTS.bells);
              S = o; var ok = save();
              noticeMsg = ok ? "Деректер қалпына келтірілді." : "Қалпына келтірілді, бірақ жадқа сақталмады."; noticeBad = !ok;
              goToday(); renderAll();
            } else {
              noticeMsg = "Код дұрыс емес."; noticeBad = true; renderSettings();
            }
          } })
        ])
      ]));

      if (confirmReset) {
        body.appendChild(card("", [
          h("div", { class: "confirm" }, [
            h("div", { text: "Барлық өзгеріс жойылып, алғашқы деректер қайтарылады. Жалғастырамыз ба?" }),
            h("div", { class: "row" }, [
              h("button", { id: "resetYes", type: "button", class: "btn danger", text: "Иә, қайтару", onclick: function () {
                S = clone(DEFAULTS);
                var ok = save();
                noticeMsg = ok ? "Алғашқы деректер қайтарылды." : "Алғашқы деректер қайтарылды, бірақ жадқа сақталмады.";
                noticeBad = !ok;
                confirmReset = false;
                goToday(); renderAll();
              } }),
              h("button", { id: "resetNo", type: "button", class: "btn", text: "Жоқ", onclick: function () { confirmReset = false; renderSettings(); } })
            ])
          ])
        ]));
      } else {
        body.appendChild(h("button", { id: "resetBtn", type: "button", class: "btn danger", text: "Алғашқы деректерге қайтару", onclick: function () { confirmReset = true; renderSettings(); } }));
      }
      return;
    }

    // Өзгерту режимі
    actions.appendChild(h("button", {
      id: "saveBtn", type: "button", class: "btn primary", text: "Сақтау",
      onclick: function () {
        errorMsg = commit();
        if (errorMsg) { renderSettings(); window.scrollTo(0, 0); return; }
        editing = false; draft = null; goToday(); renderAll(); window.scrollTo(0, 0);
      }
    }));
    actions.appendChild(h("button", {
      id: "cancelBtn", type: "button", class: "btn", text: "Болдырмау",
      onclick: function () { editing = false; draft = null; errorMsg = ""; renderSettings(); }
    }));

    if (errorMsg) body.appendChild(h("p", { class: "err", text: errorMsg }));

    // Кезекшілік
    body.appendChild(card("Кезекшілік басталуы", [
      h("div", { class: "two" }, [
        labeled("f-start", "Басталу күні", (function () {
          var i = h("input", { id: "f-start", type: "date", class: "field", value: draft.startDate });
          i.addEventListener("input", function () { draft.startDate = i.value; });
          return i;
        })()),
        labeled("f-startDesk", "Сол күні парта №", (function () {
          var i = h("input", { id: "f-startDesk", type: "number", min: "1", class: "field", value: draft.startDesk, inputmode: "numeric" });
          i.addEventListener("input", function () { draft.startDesk = i.value; });
          return i;
        })())
      ])
    ]));

    // Парталар
    var deskKids = [];
    draft.desks.forEach(function (p, i) {
      deskKids.push(h("div", { class: "desk-row" }, [
        h("span", { class: "desk-idx", text: String(i + 1) }),
        bareInput("d" + i + "a", p[0], (i + 1) + "-парта, бірінші оқушы", function (v) { draft.desks[i][0] = v; }, "Оқушы 1"),
        bareInput("d" + i + "b", p[1], (i + 1) + "-парта, екінші оқушы", function (v) { draft.desks[i][1] = v; }, "Оқушы 2"),
        h("button", { type: "button", class: "rm", "aria-label": (i + 1) + "-партаны жою", text: "×", onclick: function () { draft.desks.splice(i, 1); renderSettings(); } })
      ]));
    });
    deskKids.push(h("button", { id: "addDesk", type: "button", class: "btn", text: "+ Парта қосу", onclick: function () { draft.desks.push(["", ""]); renderSettings(); var rs = el("setBody").querySelectorAll(".desk-row"), lr = rs[rs.length - 1]; if (lr && !reduce) lr.animate([{ opacity: 0, transform: "scale(0.8)" }, { opacity: 1, transform: "scale(1.04)", offset: 0.6 }, { opacity: 1, transform: "none" }], { duration: 460, easing: "ease-out" }); } }));
    body.appendChild(card("Партадағы оқушылар", deskKids));

    // Бөлмелер
    var roomCards = draft.rooms.map(function (r, i) {
      var kids = [labeled("r" + i + "-no", "Бөлме нөмірі", bareInput("r" + i + "-no", r.no, "Бөлме нөмірі", function (v) { r.no = v; }, "Мысалы, 24"))];
      for (var d = 1; d <= 5; d++) {
        (function (day) {
          kids.push(h("div", { class: "day-row" }, [
            h("span", { text: DAYS_FULL[day] }),
            bareInput("r" + i + "-d" + day, r.days[day], DAYS_FULL[day] + " кезекшілері", function (v) { r.days[day] = v; }, "Аты, бірнешеу болса үтірмен")
          ]));
        })(d);
      }
      kids.push(h("button", { type: "button", class: "btn danger", text: "Бөлмені жою", onclick: function () { draft.rooms.splice(i, 1); renderSettings(); } }));
      return card("", kids, "sub");
    });
    roomCards.push(h("button", { id: "addRoom", type: "button", class: "btn", text: "+ Бөлме қосу", onclick: function () {
      draft.rooms.push({ no: "", days: { 1: "", 2: "", 3: "", 4: "", 5: "" } }); renderSettings();
    } }));
    body.appendChild(card("Бөлме кезекшілері", roomCards));

    // Сабақ кестесі
    var schedCards = [];
    for (var d = 1; d <= 5; d++) {
      (function (day) {
        var sb = h("textarea", { id: "s" + day + "-b", class: "field", "aria-label": DAYS_FULL[day] + ", түске дейін" }, []);
        sb.textContent = draft.schedule[day].before;
        sb.addEventListener("input", function () { draft.schedule[day].before = sb.value; });
        var sa = h("textarea", { id: "s" + day + "-a", class: "field", "aria-label": DAYS_FULL[day] + ", түстен кейін" }, []);
        sa.textContent = draft.schedule[day].after;
        sa.addEventListener("input", function () { draft.schedule[day].after = sa.value; });
        schedCards.push(card(DAYS_FULL[day], [
          labeled("s" + day + "-b", "Түске дейін (әр жолға бір сабақ)", sb),
          labeled("s" + day + "-a", "Түстен кейін (әр жолға бір сабақ)", sa)
        ], "sub"));
      })(d);
    }
    body.appendChild(card("Сабақ кестесі", schedCards));

    var bb = h("textarea", { id: "bells-b", class: "field", "aria-label": "Қоңырау, түске дейін", placeholder: "08:20-09:05\n09:15-10:00" }, []);
    bb.textContent = draft.bells.before;
    bb.addEventListener("input", function () { draft.bells.before = bb.value; });
    var ba = h("textarea", { id: "bells-a", class: "field", "aria-label": "Қоңырау, түстен кейін", placeholder: "15:00-15:45" }, []);
    ba.textContent = draft.bells.after;
    ba.addEventListener("input", function () { draft.bells.after = ba.value; });
    body.appendChild(card("Қоңырау кестесі", [
      labeled("bells-b", "Түске дейін (әр жолға бір сабақ: 08:20-09:05)", bb),
      labeled("bells-a", "Түстен кейін (әр жолға бір сабақ: 15:00-15:45)", ba)
    ]));
  }

  function renderAll() {
    renderDuty();
    renderTimetable();
    renderRooms();
    renderSettings();
  }

  // Бөлімдер
  var tabs = document.querySelectorAll(".tab");
  var current = "duty", lastMain = "duty";
  function showTab(name) {
    current = name;
    if (name !== "settings") lastMain = name;
    ["lesson", "duty", "room", "settings"].forEach(function (k) { el("view-" + k).hidden = k !== name; });
    Array.prototype.forEach.call(tabs, function (t) {
      t.setAttribute("aria-selected", t.getAttribute("data-tab") === name ? "true" : "false");
    });
    el("gearBtn").setAttribute("aria-pressed", name === "settings" ? "true" : "false");
    var v = el("view-" + name);
    v.classList.remove("enter");
    void v.offsetWidth;
    v.classList.add("enter");
    if (litReady) {
      if (name === "lesson") cascade(v.querySelectorAll(".lessons li"), 40);
      else if (name === "room") cascade(el("roomList").children, 70);
      else if (name === "duty") cascade(el("nextList").children, 40);
    }
    setLit(name, litReady);
    litReady = true;
  }
  Array.prototype.forEach.call(tabs, function (t) {
    t.addEventListener("click", function () { showTab(t.getAttribute("data-tab")); });
  });
  el("gearBtn").addEventListener("click", function () { showTab(current === "settings" ? lastMain : "settings"); });

  // Төменгі жолақ: белсенді батырма көк дөңгелек. Басқа батырманы басқанда көк жарықтар шығып, соған өтеді.
  var nav = document.querySelector(".tabs");
  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var litReady = false, litTimer = null;

  function tabEl(name) { return nav.querySelector('.tab[data-tab="' + name + '"]'); }
  function centerOf(t) {
    var r = t.querySelector(".bubble").getBoundingClientRect(), nr = nav.getBoundingClientRect();
    return { x: r.left - nr.left + r.width / 2, y: r.top - nr.top + r.height / 2 };
  }
  // Сағыз сияқты созылу: көк тамшы ескі батырмадан созылып, жаңа батырмаға жеткенде үзіледі
  var goo = null, gumRaf = 0, gumOn = false, gumHide = null;
  function ensureGoo() {
    if (goo) return goo;
    var NS = "http://www.w3.org/2000/svg";
    function s(tag, attrs, kids) {
      var e = document.createElementNS(NS, tag);
      Object.keys(attrs || {}).forEach(function (k) { e.setAttribute(k, attrs[k]); });
      (kids || []).forEach(function (c) { e.appendChild(c); });
      return e;
    }
    var filter = s("filter", { id: "gooF", x: "-20%", y: "-90%", width: "140%", height: "280%", "color-interpolation-filters": "sRGB" }, [
      s("feGaussianBlur", { "in": "SourceGraphic", stdDeviation: "5", result: "b" }),
      s("feColorMatrix", { "in": "b", mode: "matrix", values: "1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -10" })
    ]);
    var circles = [];
    for (var i = 0; i < 44; i++) circles.push(s("circle", { cx: 0, cy: 0, r: 0, style: "fill: var(--blue)" }));
    var svg = s("svg", { "class": "goo", "aria-hidden": "true" }, [s("defs", {}, [filter]), s("g", { filter: "url(#gooF)" }, circles)]);
    nav.insertBefore(svg, nav.firstChild);
    goo = { svg: svg, c: circles };
    return goo;
  }
  function ease(q) { return q < 0.5 ? 4 * q * q * q : 1 - Math.pow(-2 * q + 2, 3) / 2; }
  function gum(from, to, done) {
    var g = ensureGoo();
    g.svg.style.display = "block";
    var A = centerOf(from), B = centerOf(to), dist = Math.hypot(B.x - A.x, B.y - A.y);
    var n = Math.min(g.c.length, Math.max(10, Math.ceil(dist / 8)));
    var DUR = 860, SPLIT = 0.7, T0 = null;
    function frame(now) {
      if (T0 === null) T0 = now;
      var p = Math.min(1, (now - T0) / DUR);
      var stretch = p < SPLIT ? ease(p / SPLIT) : 1;
      var snap = p < SPLIT ? 0 : ease((p - SPLIT) / (1 - SPLIT));
      var hx = A.x + (B.x - A.x) * stretch, hy = A.y + (B.y - A.y) * stretch;
      var rT = 24 * (1 - 0.45 * stretch), rH = 22 + 2 * snap;
      for (var i = 0; i < g.c.length; i++) {
        var el = g.c[i];
        if (i >= n) { el.setAttribute("r", 0); continue; }
        var s = i / (n - 1);
        var rb = rT * (1 - s) + rH * s;
        var pinch = 1 - (0.78 * stretch + 0.2 * snap) * Math.pow(Math.sin(Math.PI * s), 0.7);
        var fade = snap > 0 ? (s < 0.5 ? 1 - snap : 1 - snap * (1 - (s - 0.5) * 2)) : 1;
        el.setAttribute("cx", (A.x + (hx - A.x) * s).toFixed(1));
        el.setAttribute("cy", (A.y + (hy - A.y) * s).toFixed(1));
        el.setAttribute("r", Math.max(0, rb * pinch * fade).toFixed(1));
      }
      if (p < 1) gumRaf = requestAnimationFrame(frame);
      else { gumRaf = 0; done(); }
    }
    gumRaf = requestAnimationFrame(frame);
  }
  function cancelGum() {
    if (gumRaf) { cancelAnimationFrame(gumRaf); gumRaf = 0; }
    gumOn = false;
    clearTimeout(gumHide);
    if (goo) goo.svg.style.display = "none";
  }
  function setLit(name, animate) {
    var prev = nav.querySelector(".tab.lit");
    var target = name === "settings" ? null : tabEl(name);
    if (prev === target && !gumOn) return;
    cancelGum();
    if (prev) prev.classList.remove("lit", "pop", "settle");
    if (!target) return;
    if (!animate || reduce || !prev) {
      target.classList.add("lit");
      if (animate && !reduce) { target.classList.add("pop"); setTimeout(function () { target.classList.remove("pop"); }, 600); }
      return;
    }
    gumOn = true;
    gum(prev, target, function () {
      gumOn = false;
      target.classList.add("lit", "settle");
      setTimeout(function () { target.classList.remove("settle"); }, 500);
      gumHide = setTimeout(function () { if (goo) goo.svg.style.display = "none"; }, 280);
    });
  }

  // Ұзақ басқанда көшіру мәзірі шықпасын (жазу өрістерінен басқа жерде)
  document.addEventListener("contextmenu", function (ev) {
    var t = ev.target;
    if (!(t && t.closest && t.closest("input, textarea"))) ev.preventDefault();
  });
  document.addEventListener("selectstart", function (ev) {
    var t = ev.target && (ev.target.nodeType === 1 ? ev.target : ev.target.parentElement);
    if (!(t && t.closest && t.closest("input, textarea"))) ev.preventDefault();
  });

  // Қараңғы режим (батырма баптау батырмасының сол жағында)
  (function () {
    var root = document.documentElement, btn = el("themeBtn");
    var mq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
    function isDark() {
      var t = root.getAttribute("data-theme");
      return t ? t === "dark" : !!(mq && mq.matches);
    }
    function sync() {
      var d = isDark();
      el("icoMoon").toggleAttribute("hidden", d);
      el("icoSun").toggleAttribute("hidden", !d);
      btn.setAttribute("aria-label", d ? "Жарық режимге өту" : "Қараңғы режимге өту");
    }
    btn.addEventListener("click", function () {
      var next = isDark() ? "light" : "dark";
      if (document.startViewTransition && !reduce) {
        var r0 = btn.getBoundingClientRect(), cx = r0.left + r0.width / 2, cy = r0.top + r0.height / 2;
        var rad = Math.hypot(Math.max(cx, innerWidth - cx), Math.max(cy, innerHeight - cy));
        var vt = document.startViewTransition(function () {
          root.setAttribute("data-theme", next);
          try { localStorage.setItem("classx-theme", next); } catch (e) {}
          sync();
        });
        vt.ready.then(function () {
          root.animate({ clipPath: ["circle(0px at " + cx + "px " + cy + "px)", "circle(" + rad + "px at " + cx + "px " + cy + "px)"] },
            { duration: 650, easing: "cubic-bezier(0.4, 0, 0.2, 1)", pseudoElement: "::view-transition-new(root)" });
        }).catch(function () {});
        return;
      }
      root.classList.add("theming");
      root.setAttribute("data-theme", next);
      try { localStorage.setItem("classx-theme", next); } catch (e) {}
      sync();
      setTimeout(function () { root.classList.remove("theming"); }, 450);
    });
    if (mq && mq.addEventListener) mq.addEventListener("change", sync);
    sync();
  })();

  // Кіріспе анимация: ClassX жазуынан көк жарықтар ұшып шығып, өз партасына қонады да партаға айналады
  (function () {
    var sp = el("splash");
    if (!sp) return;
    var seen = false;
    try { seen = sessionStorage.getItem("classx-splash") === "1"; sessionStorage.setItem("classx-splash", "1"); } catch (e) {}
    if (reduce || seen) { sp.remove(); return; }
    var idx = isSchool(viewN) ? deskIndex(viewN) : -1;
    var brandName = el("brandName");
    if (brandName) brandName.classList.add("wait");
    var wrap = el("spDesks");
    var n = S.desks.length;
    var STEP = 0.09, START = 1.1, FLY = 0.85;
    var empty = !n;
    var end = empty ? 0.9 : START + (n - 1) * STEP + FLY;
    sp.style.setProperty("--end", end.toFixed(2) + "s");

    var parts = [];
    layout(n).forEach(function (row) {
      row.forEach(function (k) {
        if (!k) { wrap.appendChild(h("div", { class: "sp-slot" })); return; }
        var desk = h("div", { class: "sp-desk" + (k - 1 === idx ? " on" : "") }, [h("i"), h("b", { text: String(k) }), h("i")]);
        var fly = h("div", { class: "sp-fly" }, [desk]);
        var slot = h("div", { class: "sp-slot" }, [fly]);
        slot.style.setProperty("--i", k - 1);
        wrap.appendChild(slot);
        parts.push({ slot: slot, fly: fly, desk: desk, on: k - 1 === idx });
      });
    });
    // ұшу жолы: тақтаның ортасынан өз партасына дейін (көлденең және тік қозғалыс әртүрлі жылдамдықпен, сондықтан доға болады)
    var bd = sp.querySelector(".sp-board").getBoundingClientRect();
    var bx = bd.left + bd.width / 2, by = bd.top + bd.height / 2;
    parts.forEach(function (o) {
      var r = o.slot.getBoundingClientRect();
      o.fly.style.setProperty("--fx", (bx - (r.left + r.width / 2)).toFixed(1) + "px");
      o.desk.style.setProperty("--fy", (by - (r.top + r.height / 2)).toFixed(1) + "px");
    });

    if (empty) { el("spCard").style.display = "none"; wrap.style.display = "none"; sp.style.setProperty("--end", "0.9s"); }
    el("spTop").textContent = idx < 0 ? "Бүгін демалыс күні" : (viewN === todayN ? "Бүгінгі кезекші" : DAYS_FULL[dow(viewN)] + " кезекшісі") + " · " + (idx + 1) + "-парта";
    el("spNames").textContent = idx < 0 ? "Кезекшілік жоқ" : S.desks[idx].join(" · ");
    // Тақтадағы ClassX жазуы жоғары сол жақтағы өз орнына ұшып барып қонады
    function flyBrand() {
      var done = function () { if (brandName) brandName.classList.remove("wait"); };
      try {
        var board = sp.querySelector(".sp-board");
        if (!brandName || !board || !brandName.animate) { done(); return; }
        var br = brandName.getBoundingClientRect();
        var bd = board.getBoundingClientRect();
        var bcs = getComputedStyle(board), ncs = getComputedStyle(brandName);
        var s = (parseFloat(bcs.fontSize) || 40) / (parseFloat(ncs.fontSize) || 20);
        var dx = (bd.left + bd.width / 2) - (br.left + br.width / 2);
        var dy = (bd.top + bd.height / 2) - (br.top + br.height / 2);
        var f = h("div", { class: "sp-flyer", text: brandName.textContent });
        f.style.left = br.left + "px"; f.style.top = br.top + "px";
        f.style.width = br.width + "px"; f.style.height = br.height + "px";
        f.style.fontFamily = ncs.fontFamily; f.style.fontWeight = ncs.fontWeight;
        f.style.fontSize = ncs.fontSize; f.style.lineHeight = br.height + "px";
        f.style.letterSpacing = ncs.letterSpacing;
        document.body.appendChild(f);
        sp.classList.add("leaving");
        var a = f.animate([
          { transform: "translate(" + dx.toFixed(1) + "px," + dy.toFixed(1) + "px) scale(" + s.toFixed(3) + ")", color: "#FFFFFF" },
          { transform: "translate(" + (dx * 0.25).toFixed(1) + "px," + (dy * 0.25 - 6).toFixed(1) + "px) scale(" + (1 + (s - 1) * 0.25).toFixed(3) + ")", color: "#FFFFFF", offset: 0.7 },
          { transform: "translate(0px,0px) scale(1)", color: ncs.color }
        ], { duration: 950, easing: "cubic-bezier(0.5, 0, 0.2, 1)", fill: "both" });
        a.onfinish = function () { done(); f.remove(); };
        setTimeout(function () { done(); f.remove(); }, 1600);
      } catch (e) { done(); }
    }
    var closed = false;
    function close() {
      if (closed) return;
      closed = true;
      flyBrand();
      sp.classList.add("out");
      setTimeout(function () { sp.remove(); }, 500);
    }
    sp.addEventListener("click", close);
    // Барлық парта қонғасын: кезекші парта жарқырап, жұлдыздар шашырайды, қалғаны күңгірттенеді
    function stars(slot) {
      var pts = "polygon(50% 0%,61% 35%,98% 35%,68% 57%,79% 91%,50% 70%,21% 91%,32% 57%,2% 35%,39% 35%)";
      for (var i = 0; i < 14; i++) {
        var st = h("span", { class: "sp-star" });
        st.style.clipPath = pts;
        slot.appendChild(st);
        var ang = (i / 14) * Math.PI * 2 + Math.random() * 0.4, dist = 46 + Math.random() * 56, sc = 0.7 + Math.random() * 1.1;
        var an = st.animate([
          { transform: "translate(0px,0px) scale(0) rotate(0deg)", opacity: 1 },
          { transform: "translate(" + (Math.cos(ang) * dist).toFixed(1) + "px," + (Math.sin(ang) * dist).toFixed(1) + "px) scale(" + sc.toFixed(2) + ") rotate(" + (Math.random() * 360).toFixed(0) + "deg)", opacity: 1, offset: 0.55 },
          { transform: "translate(" + (Math.cos(ang) * dist * 1.25).toFixed(1) + "px," + (Math.sin(ang) * dist * 1.25 + 14).toFixed(1) + "px) scale(0) rotate(200deg)", opacity: 0 }
        ], { duration: 1000 + Math.random() * 300, delay: Math.random() * 120, easing: "ease-out", fill: "both" });
        an.onfinish = (function (e) { return function () { e.remove(); }; })(st);
      }
    }
    if (idx >= 0) {
      setTimeout(function () {
        if (closed) return;
        parts.forEach(function (o) {
          if (o.on) { o.slot.classList.add("hero"); stars(o.slot); } else o.slot.classList.add("dim");
        });
      }, (end + 0.15) * 1000);
    }
    setTimeout(close, (empty ? 2.9 : end + 2.6) * 1000);
  })();

  renderAll();
  showTab("duty");

  // Телефонға орнату және офлайн жұмыс (тек сайт арқылы ашылғанда)
  if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener("load", function () { navigator.serviceWorker.register("sw.js").catch(function () {}); });
  }
})();
