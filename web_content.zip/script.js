const video = document.getElementById('webcam');
const canvas = document.getElementById('motion-canvas');
const ctx = canvas.getContext('2d', { willReadFrequently: true });

// Real-Time Time-Lapse Encoding Canvas
const tlCanvas = document.getElementById('timelapse-canvas');
const tlCtx = tlCanvas.getContext('2d');

const startBtn = document.getElementById('start-cam-btn');
const nightBtn = document.getElementById('night-mode-btn');
const soundBtn = document.getElementById('sound-toggle-btn');

// Top-Right Drawer Elements
const drawerToggleBtn = document.getElementById('drawer-toggle-btn');
const rightDrawer = document.getElementById('right-drawer');
const closeDrawerBtn = document.getElementById('close-drawer-btn');
const drawerSwitchCam = document.getElementById('drawer-switch-cam');
const drawerFlipMirror = document.getElementById('drawer-flip-mirror');
const drawerPinLock = document.getElementById('drawer-pin-lock');
const drawerMicToggle = document.getElementById('drawer-mic-toggle');
const drawerHistoryBtn = document.getElementById('drawer-history-btn');
const drawerExportPdfBtn = document.getElementById('drawer-export-pdf-btn');
const saveSettingsBtn = document.getElementById('save-settings-btn');

const recDot = document.getElementById('rec-dot');
const recStatus = document.getElementById('rec-status');
const camLabel = document.getElementById('cam-label');
const liveClock = document.getElementById('live-clock');
const studyTimerEl = document.getElementById('study-timer');
const presenceStatus = document.getElementById('presence-status');
const alertCountEl = document.getElementById('alert-count');
const alertBanner = document.getElementById('alert-banner');
const liveActivityPill = document.getElementById('live-activity-pill');
const frameBadge = document.getElementById('frame-counter-badge');
const snapCountEl = document.getElementById('snap-count');
const nightOverlay = document.getElementById('night-vision-overlay');
const activityLog = document.getElementById('activity-log');

// Audio Level Elements
const audioMeterBox = document.getElementById('audio-meter-box');
const audioBarFill = document.getElementById('audio-bar-fill');

// Goal Elements
const goalTargetText = document.getElementById('goal-target-text');
const goalPercentText = document.getElementById('goal-percent-text');
const goalFill = document.getElementById('goal-fill');

// Summary, Video & PDF Elements
const summaryBox = document.getElementById('session-summary-box');
const summaryContent = document.getElementById('summary-content');
const tlGeneratingMsg = document.getElementById('tl-generating-msg');
const timelapseVideo = document.getElementById('timelapse-video');
const tlActions = document.getElementById('tl-actions');
const downloadTlBtn = document.getElementById('download-tl-btn');
const shareTlBtn = document.getElementById('share-tl-btn');
const videoSaveHint = document.getElementById('video-save-hint');
const downloadPdfBtn = document.getElementById('download-pdf-btn');
const printPdfBtn = document.getElementById('print-pdf-btn');

// PIN Lock Elements
const pinLockOverlay = document.getElementById('pin-lock-overlay');
const pinInput = document.getElementById('pin-input');
const unlockConfirmBtn = document.getElementById('unlock-confirm-btn');
const unlockCancelBtn = document.getElementById('unlock-cancel-btn');
const pinError = document.getElementById('pin-error');

// History Elements
const historyToggleInline = document.getElementById('history-toggle-inline');
const histBadgeNum = document.getElementById('hist-badge-num');
const historyPanel = document.getElementById('history-panel');
const historyList = document.getElementById('history-list');
const clearHistoryBtn = document.getElementById('clear-history-btn');

// App State
let stream = null;
let micStream = null;
let audioContext = null;
let analyser = null;
let audioInterval = null;
let micMonitorActive = false;

let isMonitoring = false;
let facingMode = "user";
let isMirrored = true;
let isLocked = false;
let wakeLock = null;

let studySeconds = 0;
let awaySeconds = 0;
let totalSessionSeconds = 0;
let alertCount = 0;
let alarmEnabled = true;
let previousFrame = null;
let idleSeconds = 0;

let monitorInterval = null;
let timerInterval = null;
let snapshotInterval = null;

let sessionStartTime = "";
let sessionEndTime = "";
let timelineEvents = [];
let currentState = "NONE";
let currentStatusLabel = "STUDYING";
let frameCount = 0;
let lastReportData = null;

// Real-time MediaRecorder & Video Blob storage
let liveMediaRecorder = null;
let liveVideoChunks = [];
let canvasTrack = null;
let latestVideoBlob = null;
let latestVideoMime = "video/webm";

// Settings
let config = JSON.parse(localStorage.getItem('poralekha_cctv_v7_config')) || {
    goalMinutes: 60,
    idleThreshold: 8,
    frameIntervalSec: 2,
    parentPin: "1234"
};

document.getElementById('setting-goal').value = config.goalMinutes;
document.getElementById('setting-idle').value = config.idleThreshold;
document.getElementById('setting-interval').value = config.frameIntervalSec;
document.getElementById('setting-pin').value = config.parentPin;
goalTargetText.textContent = `${config.goalMinutes} মিনিট`;

// History
let sessionHistory = JSON.parse(localStorage.getItem('poralekha_cctv_v7_history')) || [];
updateHistoryUI();

// Drawer Toggle
drawerToggleBtn.addEventListener('click', () => {
    rightDrawer.classList.toggle('hidden');
});

closeDrawerBtn.addEventListener('click', () => {
    rightDrawer.classList.add('hidden');
});

// Live Clock
setInterval(() => {
    const now = new Date();
    liveClock.textContent = now.toTimeString().split(' ')[0];
}, 1000);

function getFormattedTime() {
    return new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function getEnglishTimestamp() {
    return new Date().toTimeString().split(' ')[0];
}

function formatDuration(sec) {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const remSec = sec % 60;
    if (hrs > 0) return `${hrs} ঘণ্টা ${mins} মিনিট`;
    if (mins > 0) return `${mins} মিনিট ${remSec} সেকেন্ড`;
    return `${remSec} সেকেন্ড`;
}

function formatDurationEn(sec) {
    const hrs = Math.floor(sec / 3600);
    const mins = Math.floor((sec % 3600) / 60);
    const remSec = sec % 60;
    if (hrs > 0) return `${hrs}h ${mins}m ${remSec}s`;
    if (mins > 0) return `${mins}m ${remSec}s`;
    return `${remSec}s`;
}

// Wake Lock
async function requestWakeLock() {
    try {
        if ('wakeLock' in navigator) {
            wakeLock = await navigator.wakeLock.request('screen');
        }
    } catch (err) {}
}

function releaseWakeLock() {
    if (wakeLock !== null) {
        wakeLock.release().then(() => { wakeLock = null; }).catch(() => {});
    }
}

// Log Entry
function addLog(msg, msgEn = "", isWarn = false) {
    const li = document.createElement('li');
    const time = getFormattedTime();
    const timeEn = getEnglishTimestamp();
    li.textContent = `[${time}] ${msg}`;
    if (isWarn) li.classList.add('warn');
    activityLog.prepend(li);
    if (activityLog.children.length > 60) {
        activityLog.removeChild(activityLog.lastChild);
    }
    timelineEvents.push({ time, timeEn, msg, msgEn: msgEn || msg, isWarn });
}

// Alarm Beep
function playAlarmBeep() {
    if (!alarmEnabled) return;
    try {
        const ctxAudio = new (window.AudioContext || window.webkitAudioContext)();
        const oscillator = ctxAudio.createOscillator();
        const gainNode = ctxAudio.createGain();
        oscillator.type = 'sawtooth';
        oscillator.frequency.setValueAtTime(880, ctxAudio.currentTime);
        gainNode.gain.setValueAtTime(0.2, ctxAudio.currentTime);
        oscillator.connect(gainNode);
        gainNode.connect(ctxAudio.destination);
        oscillator.start();
        setTimeout(() => oscillator.stop(), 300);
    } catch (e) {}
}

// Optional Microphone Sound Monitor
async function toggleMicMonitor() {
    if (!micMonitorActive) {
        try {
            micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            const source = audioContext.createMediaStreamSource(micStream);
            analyser = audioContext.createAnalyser();
            analyser.fftSize = 256;
            source.connect(analyser);

            const dataArray = new Uint8Array(analyser.frequencyBinCount);
            micMonitorActive = true;
            audioMeterBox.classList.remove('hidden');
            addLog("সাউন্ড মনিটর চালু হয়েছে।", "Sound monitor enabled.");

            let loudCounter = 0;
            audioInterval = setInterval(() => {
                analyser.getByteFrequencyData(dataArray);
                let sum = 0;
                for (let i = 0; i < dataArray.length; i++) sum += dataArray[i];
                const avg = sum / dataArray.length;
                const pct = Math.min(100, Math.round((avg / 100) * 100));
                audioBarFill.style.width = `${pct}%`;

                if (isMonitoring && avg > 45) {
                    loudCounter++;
                    if (loudCounter === 4) {
                        addLog("রুমে উচ্চ শব্দ বা কথা বলার আওয়াজ পাওয়া গেছে।", "High noise / talking detected in room.");
                    }
                } else {
                    loudCounter = 0;
                }
            }, 250);
        } catch (e) {
            alert("মাইক্রোফোন পারমিশন পাওয়া যায়নি!");
        }
    } else {
        stopMicMonitor();
        addLog("সাউন্ড মনিটর বন্ধ করা হয়েছে।", "Sound monitor disabled.");
    }
}

function stopMicMonitor() {
    micMonitorActive = false;
    clearInterval(audioInterval);
    if (micStream) {
        micStream.getTracks().forEach(t => t.stop());
        micStream = null;
    }
    if (audioContext) {
        audioContext.close().catch(() => {});
        audioContext = null;
    }
    audioMeterBox.classList.add('hidden');
    audioBarFill.style.width = "0%";
}

drawerMicToggle.addEventListener('click', () => {
    toggleMicMonitor();
    rightDrawer.classList.add('hidden');
});

// =========================================================================
// REAL-TIME TIME-LAPSE ENGINE + APK-SAFE VIDEO DOWNLOAD SYSTEM
// =========================================================================
function initLiveTimelapseRecorder() {
    tlCanvas.width = 400;
    tlCanvas.height = 300;
    liveVideoChunks = [];
    latestVideoBlob = null;
    frameCount = 0;

    const canvasStream = tlCanvas.captureStream(0);
    canvasTrack = canvasStream.getVideoTracks()[0];

    let mimeType = 'video/mp4';
    if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'video/webm;codecs=vp8';
        if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = 'video/webm';
            if (!MediaRecorder.isTypeSupported(mimeType)) {
                mimeType = '';
            }
        }
    }

    const options = mimeType ? { mimeType, videoBitsPerSecond: 600000 } : { videoBitsPerSecond: 600000 };
    liveMediaRecorder = new MediaRecorder(canvasStream, options);

    liveMediaRecorder.ondataavailable = (e) => {
        if (e.data && e.data.size > 0) {
            liveVideoChunks.push(e.data);
        }
    };

    liveMediaRecorder.onstop = () => {
        if (liveVideoChunks.length === 0) {
            tlGeneratingMsg.classList.remove('hidden');
            tlGeneratingMsg.textContent = "⚠️ ভিডিও রেকর্ড করার জন্য অন্তত কয়েক সেকেন্ড মনিটর চালু রাখুন।";
            timelapseVideo.classList.add('hidden');
            tlActions.classList.add('hidden');
            return;
        }

        latestVideoMime = liveMediaRecorder.mimeType || 'video/webm';
        latestVideoBlob = new Blob(liveVideoChunks, { type: latestVideoMime });
        const videoUrl = URL.createObjectURL(latestVideoBlob);
        timelapseVideo.src = videoUrl;

        tlGeneratingMsg.classList.add('hidden');
        timelapseVideo.classList.remove('hidden');
        tlActions.classList.remove('hidden');
        videoSaveHint.classList.add('hidden');
    };

    liveMediaRecorder.start(1000);
}

function pushSingleTimelapseFrame() {
    if (!isMonitoring || video.readyState !== video.HAVE_ENOUGH_DATA || !liveMediaRecorder) return;

    tlCtx.save();
    if (isMirrored) {
        tlCtx.translate(tlCanvas.width, 0);
        tlCtx.scale(-1, 1);
    }
    tlCtx.drawImage(video, 0, 0, tlCanvas.width, tlCanvas.height);
    tlCtx.restore();

    if (!nightOverlay.classList.contains('hidden')) {
        tlCtx.fillStyle = "rgba(34, 197, 94, 0.22)";
        tlCtx.fillRect(0, 0, tlCanvas.width, tlCanvas.height);
    }

    tlCtx.fillStyle = "rgba(0, 0, 0, 0.72)";
    tlCtx.fillRect(0, 0, tlCanvas.width, 26);
    tlCtx.fillStyle = "#22c55e";
    tlCtx.font = "bold 12px monospace";
    tlCtx.fillText(`REC ● TIMELAPSE | ${getEnglishTimestamp()}`, 10, 18);

    tlCtx.fillStyle = "rgba(0, 0, 0, 0.72)";
    tlCtx.fillRect(0, tlCanvas.height - 24, tlCanvas.width, 24);
    tlCtx.fillStyle = currentStatusLabel === "AWAY / IDLE" ? "#ef4444" : "#22c55e";
    tlCtx.font = "bold 11px monospace";
    tlCtx.fillText(`STATUS: ${currentStatusLabel} | STUDY: ${studyTimerEl.textContent}`, 10, tlCanvas.height - 8);

    if (canvasTrack && typeof canvasTrack.requestFrame === 'function') {
        canvasTrack.requestFrame();
    }

    frameCount++;
    snapCountEl.textContent = frameCount;
}

// Universal File Downloader (Converts Blob -> Base64 Data URI so Android APK WebView downloads properly!)
function triggerUniversalDownload(blob, filename) {
    const reader = new FileReader();
    reader.onloadend = function () {
        const base64DataUrl = reader.result;
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = base64DataUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(() => {
            document.body.removeChild(a);
        }, 1000);
    };
    reader.readAsDataURL(blob);
}

// Download Video Button (APK WebView Compatible)
downloadTlBtn.addEventListener('click', () => {
    if (!latestVideoBlob) {
        alert("ডাউনলোড করার মতো কোনো ভিডিও নেই!");
        return;
    }
    const ext = latestVideoMime.includes('mp4') ? 'mp4' : 'webm';
    const fileName = `poralekha_timelapse_${Date.now()}.${ext}`;
    
    triggerUniversalDownload(latestVideoBlob, fileName);
    videoSaveHint.textContent = "✅ ডাউনলোড শুরু হয়েছে! যদি আপনার APK অ্যাপে সরাসরি সেভ না হয়, তবে পাশের '📤 সেভ / শেয়ার' বাটনে চাপ দিয়ে Files বা Gallery-তে সেভ করুন।";
    videoSaveHint.classList.remove('hidden');
});

// Share / Save Video via Android Native Share Sheet
shareTlBtn.addEventListener('click', async () => {
    if (!latestVideoBlob) {
        alert("শেয়ার বা সেভ করার মতো কোনো ভিডিও নেই!");
        return;
    }
    const ext = latestVideoMime.includes('mp4') ? 'mp4' : 'webm';
    const fileName = `poralekha_timelapse_${Date.now()}.${ext}`;
    const videoFile = new File([latestVideoBlob], fileName, { type: latestVideoMime });

    if (navigator.canShare && navigator.canShare({ files: [videoFile] })) {
        try {
            await navigator.share({
                title: 'Poralekha Study Time-Lapse',
                text: 'Student study session time-lapse video.',
                files: [videoFile]
            });
        } catch (err) {}
    } else {
        triggerUniversalDownload(latestVideoBlob, fileName);
        videoSaveHint.textContent = "✅ ফাইলটি ডাউনলোড ফোল্ডারে পাঠানো হয়েছে।";
        videoSaveHint.classList.remove('hidden');
    }
});

// =========================================================================
// 100% OFFLINE REAL BINARY PDF GENERATOR (Creates valid .PDF file directly!)
// =========================================================================
function sanitizePdfText(str) {
    // Standard PDF Helvetica font supports ASCII cleanly; ensure safe ASCII encoding
    return String(str).replace(/[^ -~]/g, '').replace(/\/g, '\\').replace(/\(/g, '\(').replace(/\)/g, '\)');
}

function generateOfflinePdfBlob(report) {
    const lines = [];
    lines.push("PORALEKHA CC CAM - STUDENT ACTIVITY REPORT");
    lines.push("====================================================");
    lines.push(`Date: ${report.dateEn}`);
    lines.push(`Session Time: ${report.startTimeEn} - ${report.endTimeEn}`);
    lines.push(`Active Study Time: ${report.studyDurationEn}`);
    lines.push(`Away / Inactive Time: ${report.awayDurationEn}`);
    lines.push(`Focus Score: ${report.focusPercent}%`);
    lines.push(`Total Alerts Triggered: ${report.alertCount}`);
    lines.push(`Time-Lapse Frames Captured: ${report.frameCount}`);
    lines.push("----------------------------------------------------");
    lines.push(`Evaluation: ${report.evaluationEn}`);
    lines.push("====================================================");
    lines.push("ACTIVITY TIMELINE LOG:");
    lines.push("");

    const maxEvents = report.events.slice(-32);
    maxEvents.forEach(ev => {
        lines.push(`[${ev.timeEn}] ${sanitizePdfText(ev.msgEn)}`);
    });

    // Build PDF content stream
    let contentStream = "BT
/F1 14 Tf
50 780 Td
";
    contentStream += `(${sanitizePdfText(lines[0])}) Tj
`;
    contentStream += "/F1 10 Tf
0 -20 Td
";

    for (let i = 1; i < lines.length; i++) {
        const safeLine = sanitizePdfText(lines[i]);
        contentStream += `(${safeLine}) Tj
0 -15 Td
`;
    }
    contentStream += "ET";

    // Assemble valid PDF 1.4 structure with accurate byte offsets
    const objects = [];
    objects.push("1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
");
    objects.push("2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
");
    objects.push("3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
");
    objects.push(`4 0 obj
<< /Length ${contentStream.length} >>
stream
${contentStream}
endstream
endobj
`);
    objects.push("5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
");

    let pdf = "%PDF-1.4
";
    const offsets = [0];
    for (let i = 0; i < objects.length; i++) {
        offsets.push(pdf.length);
        pdf += objects[i];
    }

    const xrefStart = pdf.length;
    pdf += `xref
0 ${objects.length + 1}
`;
    pdf += "0000000000 65535 f 
";
    for (let i = 1; i < offsets.length; i++) {
        pdf += String(offsets[i]).padStart(10, '0') + " 00000 n 
";
    }

    pdf += `trailer
<< /Size ${objects.length + 1} /Root 1 0 R >>
startxref
${xrefStart}
%%EOF`;

    return new Blob([pdf], { type: "application/pdf" });
}

function downloadPdfReport() {
    if (!lastReportData) {
        alert("আগে একটি মনিটরিং সেশন শেষ করুন, তারপর PDF রিপোর্ট ডাউনলোড করতে পারবেন।");
        return;
    }
    const pdfBlob = generateOfflinePdfBlob(lastReportData);
    const fileName = `Poralekha_Study_Report_${Date.now()}.pdf`;
    triggerUniversalDownload(pdfBlob, fileName);
}

downloadPdfBtn.addEventListener('click', downloadPdfReport);
drawerExportPdfBtn.addEventListener('click', () => {
    downloadPdfReport();
    rightDrawer.classList.add('hidden');
});

printPdfBtn.addEventListener('click', () => {
    window.print();
});

// Start Camera Stream
async function startCameraStream() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
    stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: facingMode }, 
        audio: false 
    });
    video.srcObject = stream;
    updateMirrorVisual();
    camLabel.textContent = facingMode === "user" ? "FRONT-CAM [STUDY]" : "REAR-CAM [STUDY]";
}

function updateMirrorVisual() {
    if (isMirrored) {
        video.classList.add('mirrored');
    } else {
        video.classList.remove('mirrored');
    }
}

let sessionStartTimeEn = "";
let sessionEndTimeEn = "";

// Start / Stop Monitoring
startBtn.addEventListener('click', async () => {
    if (!isMonitoring) {
        try {
            await startCameraStream();
            isMonitoring = true;
            requestWakeLock();

            studySeconds = 0;
            awaySeconds = 0;
            totalSessionSeconds = 0;
            alertCount = 0;
            idleSeconds = 0;
            timelineEvents = [];
            currentState = "NONE";
            snapCountEl.textContent = "0";
            alertCountEl.textContent = "0";
            studyTimerEl.textContent = "00:00:00";
            goalFill.style.width = "0%";
            goalPercentText.textContent = "0%";
            summaryBox.classList.add('hidden');
            rightDrawer.classList.add('hidden');
            activityLog.innerHTML = "";
            
            sessionStartTime = getFormattedTime();
            sessionStartTimeEn = getEnglishTimestamp();
            startBtn.textContent = "⏹ STOP MONITOR";
            startBtn.classList.add('stop');
            recDot.classList.add('active');
            recStatus.textContent = "REC ● LIVE";
            presenceStatus.textContent = "চলছে...";
            presenceStatus.style.color = "#22c55e";
            liveActivityPill.textContent = "ক্যামেরা চালু হয়েছে...";
            frameBadge.classList.remove('hidden');

            initLiveTimelapseRecorder();
            addLog("মনিটরিং ও লাইভ টাইম-ল্যাপ্স রেকর্ডিং শুরু হয়েছে।", "Monitoring & live time-lapse started.");
            startTracking();
        } catch (err) {
            alert("ক্যামেরা পারমিশন পাওয়া যায়নি! অনুগ্রহ করে ক্যামেরা Allow করুন।");
            addLog("ত্রুটি: ক্যামেরা চালু করা যায়নি।", "Error: Camera access denied.", true);
        }
    } else {
        if (isLocked) {
            pinInput.value = "";
            pinError.classList.add('hidden');
            pinLockOverlay.classList.remove('hidden');
            return;
        }
        stopMonitoring();
    }
});

function stopMonitoring() {
    isMonitoring = false;
    isLocked = false;
    pinLockOverlay.classList.add('hidden');
    releaseWakeLock();

    clearInterval(monitorInterval);
    clearInterval(timerInterval);
    clearInterval(snapshotInterval);

    if (liveMediaRecorder && liveMediaRecorder.state !== "inactive") {
        liveMediaRecorder.stop();
    }

    if (stream) {
        stream.getTracks().forEach(track => track.stop());
    }
    
    sessionEndTime = getFormattedTime();
    sessionEndTimeEn = getEnglishTimestamp();
    addLog(`মনিটরিং বন্ধ হয়েছে। (${frameCount} ফ্রেমের ভিডিও রেডি!)`, `Monitoring stopped. (${frameCount} frames recorded)`);

    startBtn.textContent = "▶ START MONITOR";
    startBtn.classList.remove('stop');
    recDot.classList.remove('active');
    recStatus.textContent = "STANDBY";
    presenceStatus.textContent = "বন্ধ আছে";
    presenceStatus.style.color = "#9ca3af";
    liveActivityPill.textContent = "সেশন সমাপ্ত";
    frameBadge.classList.add('hidden');
    alertBanner.classList.add('hidden');

    generateSessionPreview(sessionStartTime, sessionEndTime);
}

// Drawer Actions
drawerSwitchCam.addEventListener('click', async () => {
    facingMode = (facingMode === "user") ? "environment" : "user";
    isMirrored = (facingMode === "user");
    if (isMonitoring) {
        try {
            await startCameraStream();
            previousFrame = null;
            addLog(facingMode === "user" ? "ফ্রন্ট ক্যামেরা চালু হয়েছে।" : "ব্যাক ক্যামেরা চালু হয়েছে।", "Camera switched.");
        } catch (e) {
            alert("এই ক্যামেরাটি চালু করা সম্ভব হচ্ছে না।");
        }
    } else {
        camLabel.textContent = facingMode === "user" ? "FRONT-CAM [STUDY]" : "REAR-CAM [STUDY]";
    }
    rightDrawer.classList.add('hidden');
});

drawerFlipMirror.addEventListener('click', () => {
    isMirrored = !isMirrored;
    updateMirrorVisual();
    addLog(isMirrored ? "মিরর ভিউ চালু করা হয়েছে।" : "নরমাল ভিউ চালু করা হয়েছে।", "Mirror view toggled.");
    rightDrawer.classList.add('hidden');
});

drawerPinLock.addEventListener('click', () => {
    rightDrawer.classList.add('hidden');
    if (!isMonitoring) {
        alert("আগে START MONITOR চালু করুন, তারপর লক করতে পারবেন।");
        return;
    }
    if (!isLocked) {
        isLocked = true;
        addLog("প্যারেন্ট পিন লক চালু করা হয়েছে।", "Parent PIN lock enabled.");
        alert("প্যারেন্ট পিন লক চালু হয়েছে! এখন পিন ছাড়া STOP করা যাবে না।");
    } else {
        pinInput.value = "";
        pinError.classList.add('hidden');
        pinLockOverlay.classList.remove('hidden');
    }
});

unlockConfirmBtn.addEventListener('click', () => {
    if (pinInput.value === config.parentPin) {
        isLocked = false;
        pinLockOverlay.classList.add('hidden');
        addLog("প্যারেন্ট পিন দিয়ে আনলক করা হয়েছে।", "Unlocked via Parent PIN.");
    } else {
        pinError.classList.remove('hidden');
    }
});

unlockCancelBtn.addEventListener('click', () => {
    pinLockOverlay.classList.add('hidden');
});

saveSettingsBtn.addEventListener('click', () => {
    const newGoal = parseInt(document.getElementById('setting-goal').value) || 60;
    const newIdle = parseInt(document.getElementById('setting-idle').value) || 8;
    const newInterval = parseInt(document.getElementById('setting-interval').value) || 2;
    const newPin = document.getElementById('setting-pin').value.trim() || "1234";

    config = {
        goalMinutes: Math.max(1, newGoal),
        idleThreshold: Math.max(2, newIdle),
        frameIntervalSec: Math.max(1, newInterval),
        parentPin: newPin
    };
    localStorage.setItem('poralekha_cctv_v7_config', JSON.stringify(config));
    goalTargetText.textContent = `${config.goalMinutes} মিনিট`;
    rightDrawer.classList.add('hidden');
    addLog(`সেটিংস সেভ করা হয়েছে।`, "Settings updated.");
});

// Generate Preview Report & Prepare PDF Data
function generateSessionPreview(startTime, endTime) {
    let focusPercent = 100;
    if (totalSessionSeconds > 0) {
        focusPercent = Math.round((studySeconds / totalSessionSeconds) * 100);
    }

    let behaviorComment = "";
    let evaluationEn = "";
    if (focusPercent >= 85 && alertCount === 0) {
        behaviorComment = "🌟 চমৎকার! স্টুডেন্ট পুরো সময়টা অত্যন্ত মনোযোগ দিয়ে পড়াশোনা করেছে।";
        evaluationEn = "Excellent! Student stayed focused throughout the entire session.";
    } else if (focusPercent >= 60) {
        behaviorComment = "👍 মোটামুটি ভালো পড়েছে, তবে মাঝে মাঝে একটু অমনোযোগী হয়েছিল।";
        evaluationEn = "Good effort, with minor distractions during the session.";
    } else {
        behaviorComment = "⚠️ সতর্কতা: স্টুডেন্ট পড়াশোনায় কম সময় দিয়েছে এবং বারবার টেবিল ছেড়েছে বা নড়াচড়া করেনি।";
        evaluationEn = "Warning: Low focus time. Student left the desk or remained inactive repeatedly.";
    }

    let eventsHtml = timelineEvents.slice(-30).map(ev => 
        `<div style="color: ${ev.isWarn ? '#f87171' : '#9ca3af'};">• <b>${ev.time}:</b> ${ev.msg}</div>`
    ).join('');

    summaryContent.innerHTML = `
        <p>🕒 <b>সময়কাল:</b> ${startTime} থেকে ${endTime}</p>
        <p>📖 <b>মনোযোগ দিয়ে পড়েছে:</b> <span style="color:#22c55e; font-weight:bold;">${formatDuration(studySeconds)}</span></p>
        <p>🚶 <b>অমনোযোগী / বাইরে ছিল:</b> <span style="color:#f87171; font-weight:bold;">${formatDuration(awaySeconds)}</span></p>
        <p>🎯 <b>ফোকাস স্কোর:</b> ${focusPercent}% (অ্যালার্ট: ${alertCount} বার | ফ্রেম: ${frameCount})</p>
        <p style="margin-top:8px; color:#f9fafb; background:#22262e; padding:6px 8px; border-radius:4px;">${behaviorComment}</p>
        <div class="summary-timeline">
            <div style="color:#f3f4f6; font-weight:bold; margin-bottom:4px;">সেশন অ্যাক্টিভিটি টাইমলাইন:</div>
            ${eventsHtml}
        </div>
    `;

    lastReportData = {
        dateEn: new Date().toISOString().split('T')[0],
        startTimeEn: sessionStartTimeEn,
        endTimeEn: sessionEndTimeEn,
        studyDurationEn: formatDurationEn(studySeconds),
        awayDurationEn: formatDurationEn(awaySeconds),
        focusPercent: focusPercent,
        alertCount: alertCount,
        frameCount: frameCount,
        evaluationEn: evaluationEn,
        events: timelineEvents
    };

    summaryBox.classList.remove('hidden');

    if (totalSessionSeconds >= 3) {
        const todayDate = new Date().toLocaleDateString('bn-BD');
        sessionHistory.unshift({
            date: todayDate,
            time: `${startTime} - ${endTime}`,
            study: formatDuration(studySeconds),
            focus: focusPercent,
            alerts: alertCount
        });
        if (sessionHistory.length > 25) sessionHistory.pop();
        localStorage.setItem('poralekha_cctv_v7_history', JSON.stringify(sessionHistory));
        updateHistoryUI();
    }
}

function updateHistoryUI() {
    histBadgeNum.textContent = sessionHistory.length;
    if (sessionHistory.length === 0) {
        historyList.innerHTML = `<p style="color:#888; font-size:12px;">এখনো কোনো রেকর্ড জমা হয়নি।</p>`;
        return;
    }
    historyList.innerHTML = sessionHistory.map(item => `
        <div class="history-item">
            <b>📅 ${item.date}</b> (${item.time})<br>
            📖 পড়া: <span style="color:#22c55e;">${item.study}</span> | 🎯 ফোকাস: ${item.focus}% | ⚠️ অ্যালার্ট: ${item.alerts}
        </div>
    `).join('');
}

historyToggleInline.addEventListener('click', () => {
    historyPanel.classList.toggle('hidden');
});

drawerHistoryBtn.addEventListener('click', () => {
    historyPanel.classList.remove('hidden');
    rightDrawer.classList.add('hidden');
});

clearHistoryBtn.addEventListener('click', () => {
    sessionHistory = [];
    localStorage.removeItem('poralekha_cctv_v7_history');
    updateHistoryUI();
});

// Motion & Tracking Loop
function startTracking() {
    setTimeout(pushSingleTimelapseFrame, 400);
    
    snapshotInterval = setInterval(() => {
        pushSingleTimelapseFrame();
    }, config.frameIntervalSec * 1000);

    timerInterval = setInterval(() => {
        totalSessionSeconds++;
        if (idleSeconds < config.idleThreshold) {
            studySeconds++;
            const hrs = String(Math.floor(studySeconds / 3600)).padStart(2, '0');
            const mins = String(Math.floor((studySeconds % 3600) / 60)).padStart(2, '0');
            const secs = String(studySeconds % 60).padStart(2, '0');
            studyTimerEl.textContent = `${hrs}:${mins}:${secs}`;

            const goalTotalSec = config.goalMinutes * 60;
            const pct = Math.min(100, Math.round((studySeconds / goalTotalSec) * 100));
            goalFill.style.width = `${pct}%`;
            goalPercentText.textContent = `${pct}%`;
        } else {
            awaySeconds++;
        }
    }, 1000);

    monitorInterval = setInterval(() => {
        if (video.readyState === video.HAVE_ENOUGH_DATA) {
            canvas.width = 64;
            canvas.height = 48;
            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            const currentFrame = ctx.getImageData(0, 0, canvas.width, canvas.height).data;

            if (previousFrame) {
                let diffPixels = 0;
                for (let i = 0; i < currentFrame.length; i += 4) {
                    const rDiff = Math.abs(currentFrame[i] - previousFrame[i]);
                    const gDiff = Math.abs(currentFrame[i+1] - previousFrame[i+1]);
                    const bDiff = Math.abs(currentFrame[i+2] - previousFrame[i+2]);
                    if (rDiff + gDiff + bDiff > 60) {
                        diffPixels++;
                    }
                }

                if (diffPixels < 15) {
                    idleSeconds++;
                    if (idleSeconds >= config.idleThreshold) {
                        currentStatusLabel = "AWAY / IDLE";
                        presenceStatus.textContent = "টেবিলে নেই!";
                        presenceStatus.style.color = "#ef4444";
                        liveActivityPill.textContent = "⚠️ নিষ্ক্রিয় / টেবিল ছেড়েছে";
                        liveActivityPill.style.borderColor = "#ef4444";
                        liveActivityPill.style.color = "#ef4444";
                        alertBanner.classList.remove('hidden');
                        
                        if (currentState !== "IDLE") {
                            currentState = "IDLE";
                            alertCount++;
                            alertCountEl.textContent = alertCount;
                            addLog("স্টুডেন্ট টেবিল ছেড়ে চলে গেছে অথবা একদম স্থির হয়ে আছে!", "ALERT: Student left desk or inactive.", true);
                        }
                        playAlarmBeep();
                    }
                } else if (diffPixels > 450) {
                    if (idleSeconds >= config.idleThreshold) {
                        addLog("স্টুডেন্ট আবার পড়ার টেবিলে ফিরে এসেছে।", "Student returned to desk.");
                    }
                    idleSeconds = 0;
                    currentStatusLabel = "RESTLESS / MOVING";
                    presenceStatus.textContent = "বেশি নড়াচড়া";
                    presenceStatus.style.color = "#f59e0b";
                    liveActivityPill.textContent = "👀 বেশি নড়াচড়া করছে";
                    liveActivityPill.style.borderColor = "#f59e0b";
                    liveActivityPill.style.color = "#f59e0b";
                    alertBanner.classList.add('hidden');

                    if (currentState !== "RESTLESS") {
                        currentState = "RESTLESS";
                        addLog("স্টুডেন্ট টেবিলে বেশ নড়াচড়া করছে।", "Student moving frequently / restless.");
                    }
                } else {
                    if (idleSeconds >= config.idleThreshold) {
                        addLog("স্টুডেন্ট আবার পড়ার টেবিলে ফিরে এসেছে।", "Student returned to desk.");
                    }
                    idleSeconds = 0;
                    currentStatusLabel = "STUDYING";
                    presenceStatus.textContent = "পড়াশোনা করছে";
                    presenceStatus.style.color = "#22c55e";
                    liveActivityPill.textContent = "✍️ মনোযোগ দিয়ে পড়ছে/লিখছে";
                    liveActivityPill.style.borderColor = "#22c55e";
                    liveActivityPill.style.color = "#22c55e";
                    alertBanner.classList.add('hidden');

                    if (currentState !== "STUDY") {
                        currentState = "STUDY";
                        addLog("স্টুডেন্ট স্থির হয়ে মনোযোগ দিয়ে পড়াশোনা করছে।", "Student studying / writing steadily.");
                    }
                }
            }
            previousFrame = currentFrame;
        }
    }, 1000);
}

// Night Vision Toggle
nightBtn.addEventListener('click', () => {
    nightOverlay.classList.toggle('hidden');
    const isNight = !nightOverlay.classList.contains('hidden');
    nightBtn.textContent = isNight ? "☀️ NORMAL" : "🌙 NIGHT";
    addLog(isNight ? "নাইট ভিশন মোড চালু করা হয়েছে।" : "নরমাল ভিউ চালু করা হয়েছে।", isNight ? "Night vision enabled." : "Normal view restored.");
});

// Sound Alarm Toggle
soundBtn.addEventListener('click', () => {
    alarmEnabled = !alarmEnabled;
    soundBtn.textContent = alarmEnabled ? "🔊 ALARM: ON" : "🔇 ALARM: OFF";
});
