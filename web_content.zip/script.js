(function () {
  "use strict";

  var STORAGE_KEY = "nuvcash:transactions:v1";

  var CATEGORIES = {
    income: ["Salário", "Freelance", "Investimentos", "Reembolso", "Vendas", "Outros"],
    expense: ["Alimentação", "Moradia", "Transporte", "Saúde", "Educação", "Lazer", "Compras", "Assinaturas", "Impostos", "Outros"]
  };

  var state = {
    transactions: [],
    filterMonth: "",
    editingId: null
  };

  var els = {};

  /* ---------- Storage ---------- */

  function loadTransactions() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return [];
      var data = JSON.parse(raw);
      if (!Array.isArray(data)) return [];
      return data.filter(function (tx) {
        return tx &&
          typeof tx.id === "string" &&
          typeof tx.description === "string" &&
          typeof tx.amountCents === "number" &&
          isFinite(tx.amountCents) &&
          (tx.type === "income" || tx.type === "expense") &&
          typeof tx.category === "string" &&
          typeof tx.date === "string";
      }).map(function (tx) {
        return {
          id: tx.id,
          description: tx.description,
          amountCents: Math.round(tx.amountCents),
          type: tx.type,
          category: tx.category,
          date: tx.date,
          createdAt: typeof tx.createdAt === "number" ? tx.createdAt : Date.now()
        };
      });
    } catch (err) {
      return [];
    }
  }

  function saveTransactions() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state.transactions));
    } catch (err) {
      showToast("Não foi possível salvar os dados.", "error");
    }
  }

  /* ---------- Utils ---------- */

  var brlFormatter = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL"
  });

  function formatBRL(cents) {
    return brlFormatter.format(cents / 100);
  }

  function parseAmountToCents(raw) {
    var input = String(raw == null ? "" : raw).trim();
    if (!input || input.indexOf("-") !== -1) return NaN;
    var s = input.replace(/[^\d.,]/g, "");
    if (!s) return NaN;

    var hasComma = s.indexOf(",") !== -1;
    var hasDot = s.indexOf(".") !== -1;
    var normalized;

    if (hasComma && hasDot) {
      normalized = s.lastIndexOf(",") > s.lastIndexOf(".")
        ? s.replace(/\./g, "").replace(",", ".")
        : s.replace(/,/g, "");
    } else if (hasComma) {
      var cParts = s.split(",");
      normalized = (cParts.length > 2 || (cParts[1].length === 3 && cParts[0].length <= 3))
        ? s.replace(/,/g, "")
        : s.replace(",", ".");
    } else if (hasDot) {
      var dParts = s.split(".");
      normalized = (dParts.length > 2 || (dParts[1].length === 3 && dParts[0].length <= 3))
        ? s.replace(/\./g, "")
        : s;
    } else {
      normalized = s;
    }

    var value = parseFloat(normalized);
    if (!isFinite(value) || value <= 0) return NaN;
    return Math.round(value * 100);
  }

  function formatCentsToInput(cents) {
    return (cents / 100).toFixed(2).replace(".", ",");
  }

  function todayISO() {
    var d = new Date();
    var m = String(d.getMonth() + 1).padStart(2, "0");
    var day = String(d.getDate()).padStart(2, "0");
    return d.getFullYear() + "-" + m + "-" + day;
  }

  function currentMonthISO() {
    return todayISO().slice(0, 7);
  }

  function formatDateBR(iso) {
    var parts = iso.split("-");
    if (parts.length !== 3) return iso;
    return parts[2] + "/" + parts[1] + "/" + parts[0];
  }

  function createId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") {
      return window.crypto.randomUUID();
    }
    return "tx-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 10);
  }

  function getCategoryLabel(type, category) {
    var list = CATEGORIES[type] || [];
    return list.indexOf(category) !== -1 ? category : category || "Sem categoria";
  }

  /* ---------- Filtering & totals ---------- */

  function getFilteredTransactions() {
    return state.transactions
      .filter(function (tx) {
        return !state.filterMonth || tx.date.slice(0, 7) === state.filterMonth;
      })
      .sort(function (a, b) {
        if (a.date !== b.date) return a.date < b.date ? 1 : -1;
        return b.createdAt - a.createdAt;
      });
  }

  function computeTotals(list) {
    var income = 0;
    var expense = 0;
    list.forEach(function (tx) {
      if (tx.type === "income") income += tx.amountCents;
      else expense += tx.amountCents;
    });
    return { income: income, expense: expense, balance: income - expense };
  }

  /* ---------- Rendering ---------- */

  function renderCategories() {
    var type = document.querySelector('input[name="txType"]:checked').value;
    var select = els.txCategory;
    var current = select.value;

    select.innerHTML = "";

    var placeholder = document.createElement("option");
    placeholder.value = "";
    placeholder.textContent = "Selecione…";
    select.appendChild(placeholder);

    CATEGORIES[type].forEach(function (cat) {
      var opt = document.createElement("option");
      opt.value = cat;
      opt.textContent = cat;
      select.appendChild(opt);
    });

    if (current && CATEGORIES[type].indexOf(current) !== -1) {
      select.value = current;
    }
  }

  function renderSummary() {
    var filtered = getFilteredTransactions();
    var totals = computeTotals(filtered);

    els.balanceValue.textContent = formatBRL(totals.balance);
    els.incomeValue.textContent = formatBRL(totals.income);
    els.expenseValue.textContent = formatBRL(totals.expense);

    els.balanceValue.parentElement.classList.toggle("is-negative", totals.balance < 0);

    var count = filtered.length;
    els.listCount.textContent = count === 1 ? "1 transação" : count + " transações";
  }

  function createTxItem(tx) {
    var li = document.createElement("li");
    li.className = "tx-item " + (tx.type === "income" ? "is-income" : "is-expense");

    var dot = document.createElement("span");
    dot.className = "tx-dot";
    dot.setAttribute("aria-hidden", "true");

    var info = document.createElement("div");
    info.className = "tx-info";

    var desc = document.createElement("p");
    desc.className = "tx-desc";
    desc.textContent = tx.description;
    desc.title = tx.description;

    var meta = document.createElement("p");
    meta.className = "tx-meta";
    meta.textContent = "";
    var cat = document.createElement("span");
    cat.textContent = getCategoryLabel(tx.type, tx.category);
    var sep1 = document.createElement("span");
    sep1.className = "sep";
    sep1.textContent = "·";
    var date = document.createElement("span");
    date.textContent = formatDateBR(tx.date);
    meta.appendChild(cat);
    meta.appendChild(sep1);
    meta.appendChild(date);

    info.appendChild(desc);
    info.appendChild(meta);

    var amount = document.createElement("span");
    amount.className = "tx-amount";
    amount.textContent = (tx.type === "income" ? "+ " : "− ") + formatBRL(tx.amountCents);

    var actions = document.createElement("div");
    actions.className = "tx-actions";

    var btnEdit = document.createElement("button");
    btnEdit.type = "button";
    btnEdit.className = "icon-btn";
    btnEdit.setAttribute("aria-label", "Editar " + tx.description);
    btnEdit.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>';
    btnEdit.addEventListener("click", function () {
      startEdit(tx.id);
    });

    var btnDelete = document.createElement("button");
    btnDelete.type = "button";
    btnDelete.className = "icon-btn danger";
    btnDelete.setAttribute("aria-label", "Excluir " + tx.description);
    btnDelete.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/></svg>';
    btnDelete.addEventListener("click", function () {
      removeTransaction(tx.id);
    });

    actions.appendChild(btnEdit);
    actions.appendChild(btnDelete);

    li.appendChild(dot);
    li.appendChild(info);
    li.appendChild(amount);
    li.appendChild(actions);
    return li;
  }

  function renderList() {
    var filtered = getFilteredTransactions();
    els.txList.innerHTML = "";

    var hasItems = filtered.length > 0;
    els.emptyState.hidden = hasItems;
    els.txList.hidden = !hasItems;

    if (!hasItems) {
      if (state.transactions.length > 0) {
        els.emptyTitle.textContent = "Sem movimentações neste mês";
        els.emptyText.textContent = "Escolha outro mês ou adicione uma nova transação.";
      } else {
        els.emptyTitle.textContent = "Nenhuma movimentação";
        els.emptyText.textContent = "Adicione uma receita ou despesa para começar.";
      }
      return;
    }

    els.emptyTitle.textContent = "Nenhuma movimentação";
    els.emptyText.textContent = "Adicione uma receita ou despesa para começar.";

    var fragment = document.createDocumentFragment();
    filtered.forEach(function (tx) {
      fragment.appendChild(createTxItem(tx));
    });
    els.txList.appendChild(fragment);
  }

  function render() {
    renderSummary();
    renderList();
  }

  /* ---------- Form ---------- */

  function clearErrors() {
    ["Description", "Value", "Date", "Category"].forEach(function (name) {
      var input = els["tx" + name];
      var error = els["error" + name];
      if (input) input.classList.remove("is-invalid");
      if (error) {
        error.hidden = true;
        error.textContent = "";
      }
    });
  }

  function setError(name, message) {
    var input = els["tx" + name];
    var error = els["error" + name];
    if (input) input.classList.add("is-invalid");
    if (error) {
      error.hidden = false;
      error.textContent = message;
    }
  }

  function resetForm() {
    els.form.reset();
    els.txId.value = "";
    els.txDate.value = todayISO();
    document.getElementById("typeExpense").checked = true;
    renderCategories();
    clearErrors();
    state.editingId = null;
    els.formTitle.textContent = "Nova transação";
    els.btnSubmit.textContent = "Adicionar";
    els.btnCancel.hidden = true;
  }

  function startEdit(id) {
    var tx = state.transactions.find(function (t) { return t.id === id; });
    if (!tx) return;

    state.editingId = id;
    els.txId.value = id;
    els.txDescription.value = tx.description;
    els.txValue.value = formatCentsToInput(tx.amountCents);
    els.txDate.value = tx.date;

    if (tx.type === "income") {
      document.getElementById("typeIncome").checked = true;
    } else {
      document.getElementById("typeExpense").checked = true;
    }

    renderCategories();
    els.txCategory.value = tx.category;
    clearErrors();

    els.formTitle.textContent = "Editar transação";
    els.btnSubmit.textContent = "Salvar";
    els.btnCancel.hidden = false;

    els.form.scrollIntoView({ behavior: "smooth", block: "center" });
    els.txDescription.focus();
  }

  function validateForm() {
    clearErrors();
    var valid = true;

    var description = els.txDescription.value.trim();
    if (!description) {
      setError("Description", "Informe uma descrição.");
      valid = false;
    }

    var amountCents = parseAmountToCents(els.txValue.value);
    if (isNaN(amountCents)) {
      setError("Value", "Informe um valor maior que zero.");
      valid = false;
    }

    var date = els.txDate.value;
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      setError("Date", "Informe uma data válida.");
      valid = false;
    }

    var category = els.txCategory.value;
    if (!category) {
      setError("Category", "Selecione uma categoria.");
      valid = false;
    }

    return valid;
  }

  function handleSubmit(event) {
    event.preventDefault();
    if (!validateForm()) return;

    var type = document.querySelector('input[name="txType"]:checked').value;
    var payload = {
      description: els.txDescription.value.trim(),
      amountCents: parseAmountToCents(els.txValue.value),
      type: type,
      category: els.txCategory.value,
      date: els.txDate.value
    };

    if (state.editingId) {
      var index = state.transactions.findIndex(function (t) { return t.id === state.editingId; });
      if (index !== -1) {
        state.transactions[index] = Object.assign({}, state.transactions[index], payload);
        saveTransactions();
        resetForm();
        render();
        showToast("Transação atualizada.", "success");
        return;
      }
    }

    state.transactions.push(Object.assign({ id: createId(), createdAt: Date.now() }, payload));
    saveTransactions();
    resetForm();
    render();
    showToast("Transação adicionada.", "success");
  }

  function removeTransaction(id) {
    var tx = state.transactions.find(function (t) { return t.id === id; });
    if (!tx) return;

    var confirmed = window.confirm('Excluir "' + tx.description + '"?');
    if (!confirmed) return;

    state.transactions = state.transactions.filter(function (t) { return t.id !== id; });
    saveTransactions();

    if (state.editingId === id) {
      resetForm();
    }

    render();
    showToast("Transação excluída.", "success");
  }

  /* ---------- Toast ---------- */

  var toastTimer = null;

  function showToast(message, kind) {
    els.toast.textContent = message;
    els.toast.className = "toast " + (kind || "");
    els.toast.hidden = false;

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () {
      els.toast.hidden = true;
    }, 2200);
  }

  /* ---------- Init ---------- */

  function cacheElements() {
    els.form = document.getElementById("transactionForm");
    els.formTitle = document.getElementById("formTitle");
    els.txId = document.getElementById("txId");
    els.txDescription = document.getElementById("txDescription");
    els.txValue = document.getElementById("txValue");
    els.txDate = document.getElementById("txDate");
    els.txCategory = document.getElementById("txCategory");
    els.btnSubmit = document.getElementById("btnSubmit");
    els.btnCancel = document.getElementById("btnCancel");
    els.filterMonth = document.getElementById("filterMonth");
    els.btnToday = document.getElementById("btnToday");
    els.balanceValue = document.getElementById("balanceValue");
    els.incomeValue = document.getElementById("incomeValue");
    els.expenseValue = document.getElementById("expenseValue");
    els.txList = document.getElementById("txList");
    els.emptyState = document.getElementById("emptyState");
    els.emptyTitle = els.emptyState.querySelector(".empty-title");
    els.emptyText = els.emptyState.querySelector(".empty-text");
    els.listCount = document.getElementById("listCount");
    els.toast = document.getElementById("toast");
    els.errorDescription = document.getElementById("errorDescription");
    els.errorValue = document.getElementById("errorValue");
    els.errorDate = document.getElementById("errorDate");
    els.errorCategory = document.getElementById("errorCategory");
  }

  function bindEvents() {
    els.form.addEventListener("submit", handleSubmit);
    els.btnCancel.addEventListener("click", resetForm);

    document.querySelectorAll('input[name="txType"]').forEach(function (radio) {
      radio.addEventListener("change", renderCategories);
    });

    els.filterMonth.addEventListener("change", function () {
      state.filterMonth = els.filterMonth.value;
      render();
    });

    els.btnToday.addEventListener("click", function () {
      els.filterMonth.value = currentMonthISO();
      state.filterMonth = currentMonthISO();
      render();
    });

    els.txValue.addEventListener("blur", function () {
      var cents = parseAmountToCents(els.txValue.value);
      if (!isNaN(cents)) {
        els.txValue.value = formatCentsToInput(cents);
      }
    });

    els.txDescription.addEventListener("input", function () {
      els.txDescription.classList.remove("is-invalid");
      els.errorDescription.hidden = true;
    });
    els.txDate.addEventListener("input", function () {
      els.txDate.classList.remove("is-invalid");
      els.errorDate.hidden = true;
    });
    els.txCategory.addEventListener("change", function () {
      els.txCategory.classList.remove("is-invalid");
      els.errorCategory.hidden = true;
    });
  }

  function init() {
    cacheElements();

    state.transactions = loadTransactions();
    state.filterMonth = currentMonthISO();

    els.filterMonth.value = state.filterMonth;
    els.txDate.value = todayISO();

    renderCategories();
    bindEvents();
    render();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
