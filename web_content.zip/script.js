const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORAGE_KEY = "universal_ai_frontend_v1";
// ====== AI SETTINGS ======
// Apne Cloudflare Worker ka link yahan quotes ke andar daalo (end mein / mat lagana).
const WORKER_URL = "https://universal-ai-api.nibrasansari179-e85.workers.dev";
// =========================

const state = { chats: [], projects: [], memory: [], activeId: null, profile: {name:"User",username:"",mobile:"",bio:"",photo:""}, page:"chat", showArchived:false, attachments:[], settings:{} };
let toastTimer;
function notify(message){const el=$("#toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2600)}
function save(){
 const ser=()=>JSON.stringify(state,function(k,v){return(k==="attachments"&&this===state)?undefined:v});
 try{localStorage.setItem(STORAGE_KEY,ser())}
 catch(e){
  const all=[];
  state.chats.forEach(c=>c.messages.forEach(m=>{if(m.atts&&m.atts.some(a=>a.thumb))all.push(m)}));
  all.sort((a,b)=>(a.at||0)-(b.at||0));
  for(const m of all){
   m.atts.forEach(a=>{a.thumb=""});
   try{localStorage.setItem(STORAGE_KEY,ser());return}catch(_){}
  }
 }
}
function makeId(){return "c_"+Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function activeChat(){return state.chats.find(c=>c.id===state.activeId)}
function escapeHtml(value){return String(value).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function openModal(title,html){$("#modalTitle").textContent=title;$("#modalBody").innerHTML=html;$("#modalLayer").classList.remove("hidden")}
function closeModal(){$("#modalLayer").classList.add("hidden");$("#modalBody").innerHTML=""}
function askText(title,value,cb){
 openModal(title,`<input class="modal-input" id="askInput" maxlength="80"><div class="modal-btns"><button class="modal-btn" id="askNo">Cancel</button><button class="modal-btn primary" id="askYes">Save</button></div>`);
 const inp=$("#askInput");inp.value=value||"";
 setTimeout(()=>{inp.focus();inp.select()},50);
 const done=()=>{const v=inp.value.trim();closeModal();if(v)cb(v)};
 $("#askYes").onclick=done;$("#askNo").onclick=closeModal;
 inp.onkeydown=e=>{if(e.key==="Enter")done()};
}
function askConfirm(title,msg,yesLabel,cb){
 openModal(title,`<p class="modal-copy">${escapeHtml(msg)}</p><div class="modal-btns"><button class="modal-btn" id="askNo">Cancel</button><button class="modal-btn primary" id="askYes">${escapeHtml(yesLabel)}</button></div>`);
 $("#askYes").onclick=()=>{closeModal();cb()};$("#askNo").onclick=closeModal;
}
(function(){const st=document.createElement("style");st.textContent=".modal-input{width:100%;border:1px solid var(--line);border-radius:10px;padding:12px;background:var(--bg);color:var(--fg);outline:none;font-size:14px}.modal-input:focus{border-color:var(--fg)}.modal-btns{display:flex;gap:8px;margin-top:14px}.modal-btn{flex:1;padding:11px;border:1px solid var(--line);border-radius:10px;background:var(--bg);color:var(--fg);font-size:13px;font-weight:650}.modal-btn.primary{background:var(--fg);color:var(--bg);border-color:var(--fg)}";document.head.appendChild(st)})();
function backendNotice(feature){openModal(feature,`<p class="modal-copy">${escapeHtml(feature)} requires a secure backend/API connection. This frontend is ready for integration, but no real account, payment, AI or cloud action has been performed.</p><button class="primary-btn modal-action" id="modalOkay">OK</button>`);$("#modalOkay").onclick=closeModal}
function renderChatList(){
 const list=$("#chatList");list.innerHTML="";
 const visible=state.chats.filter(c=>!!c.archived===state.showArchived).sort((a,b)=>(Number(!!b.pinned)-Number(!!a.pinned))||((b.updatedAt||b.createdAt)-(a.updatedAt||a.createdAt)));
 visible.forEach(chat=>{
  const row=document.createElement("div");row.className="chat-row";
  const b=document.createElement("button");b.className="chat-item"+(chat.id===state.activeId?" active":"");b.innerHTML=`<span style="flex:none;display:inline-flex">${ico("chat",16)}</span><span class="chat-title">${escapeHtml(chat.title||"New chat")}</span>`;
  b.onclick=()=>{state.activeId=chat.id;state.showArchived=false;$("#archiveToggle").classList.remove("active");showPage("chat");renderMessages();renderChatList();closeSidebar();save()};
  const more=document.createElement("button");more.className="chat-more";more.type="button";more.innerHTML=ico("more",20,2);more.setAttribute("aria-label","Chat options");more.onclick=e=>{e.stopPropagation();chatMenu(more,chat)};
  row.append(b,more);list.appendChild(row);
 });
 $("#archiveToggle").innerHTML=state.showArchived?ico("back",14)+" Back to Recent Chats":ico("archive",14)+" Archived Chats";
}
function chatMenu(anchor,chat){
 $$(".context-menu").forEach(x=>x.remove());
 const menu=document.createElement("div");menu.className="context-menu";
 const actions=[ [chat.pinned?"Unpin":"Pin",()=>{chat.pinned=!chat.pinned;save();renderChatList()}], [chat.archived?"Unarchive":"Archive",()=>{chat.archived=!chat.archived;if(chat.archived&&state.activeId===chat.id){state.activeId=null;renderMessages()}save();renderChatList()}], ["Rename",()=>askText("Rename chat",chat.title||"",v=>{chat.title=v;save();renderChatList()})], [chat.projectId?"Change project":"Add to project",()=>moveToProject(chat)], ["Delete",()=>askConfirm("Delete chat","This chat will be permanently deleted from this device.","Delete",()=>{state.chats=state.chats.filter(c=>c.id!==chat.id);if(state.activeId===chat.id)state.activeId=null;save();renderChatList();renderMessages()})] ];
 actions.forEach(([label,fn])=>{const b=document.createElement("button");b.textContent=label;b.onclick=()=>{menu.remove();fn()};menu.appendChild(b)});
 // Render the menu at viewport level so the scrollable chat list cannot clip or cover it.
 document.body.appendChild(menu);
 const rect=anchor.getBoundingClientRect();
 const menuWidth=170, menuHeight=214, gap=6, margin=8;
 const left=Math.max(margin,Math.min(rect.right-menuWidth,window.innerWidth-menuWidth-margin));
 let top=rect.bottom+gap;
 if(top+menuHeight>window.innerHeight-margin) top=Math.max(margin,rect.top-menuHeight-gap);
 menu.style.left=left+"px";menu.style.top=top+"px";
 const close=e=>{if(!menu.contains(e.target)&&e.target!==anchor){menu.remove();document.removeEventListener("click",close);document.removeEventListener("keydown",onKey)}};
 const onKey=e=>{if(e.key==="Escape"){menu.remove();document.removeEventListener("click",close);document.removeEventListener("keydown",onKey)}};
 setTimeout(()=>{document.addEventListener("click",close);document.addEventListener("keydown",onKey)},0);
}
function renderMessages(){
 const chat=activeChat(),welcome=$("#welcome"),messages=$("#messages");messages.innerHTML="";const items=chat?.messages||[];welcome.classList.toggle("hidden",items.length>0);
 items.forEach((m,index)=>{
  const wrap=document.createElement("div");wrap.className="message-wrap "+(m.role==="user"?"user-wrap":"assistant-wrap");
  const bubble=document.createElement("div");bubble.className="message "+(m.role==="user"?"user":"assistant");bubble.textContent=m.content;
   if(m.atts&&m.atts.length){
    const box=document.createElement("div");box.className="msg-atts";
    m.atts.forEach(a=>{
     const src=a._full||a.thumb;
     if(a.kind==="image"&&src){const img=document.createElement("img");img.className="msg-img";img.src=src;img.alt=a.name||"image";img.onclick=()=>openViewer(src,a.name);if(index===items.length-1)img.onload=()=>{messages.scrollTop=messages.scrollHeight};box.appendChild(img)}
     else{const c=document.createElement("div");c.className="msg-file";c.innerHTML=ico(a.kind==="image"?"image":"file",16)+"<span></span>";c.lastChild.textContent=a.name||"file";box.appendChild(c)}
    });
    bubble.insertBefore(box,bubble.firstChild);
   }
  wrap.appendChild(bubble);
  if(m.role==="assistant"&&!m.streaming){
   const actions=document.createElement("div");actions.className="message-actions";
   const ICONS={
    Regenerate:'<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
    Like:'<path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/>',
    Dislike:'<path d="M17 14V2"/><path d="M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z"/>',
    Share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" x2="15.42" y1="13.51" y2="17.49"/><line x1="15.41" x2="8.59" y1="6.51" y2="10.49"/>'
   };
   ["Regenerate","Like","Dislike","Share"].forEach(label=>{
    const b=document.createElement("button");b.className="message-action";
    b.innerHTML='<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+ICONS[label]+'</svg>';
    b.title=label;b.setAttribute("aria-label",label);
    if(m.feedback===label)b.classList.add("active");
    b.onclick=()=>{messageAction(label,index);if(label==="Like"||label==="Dislike"){actions.querySelectorAll("button").forEach(x=>x.classList.remove("active"));b.classList.add("active")}};
    actions.appendChild(b);
   });
   wrap.appendChild(actions);
  }
  messages.appendChild(wrap);
 });
 messages.scrollTop=messages.scrollHeight;
}
function messageAction(action,index){const chat=activeChat();if(!chat)return;const msg=chat.messages[index];if(action==="Like"||action==="Dislike"){msg.feedback=action;save();notify("Feedback saved on this device.")}else if(action==="Share"){const value=msg.content;if(navigator.share)navigator.share({text:value}).catch(()=>{});else if(navigator.clipboard?.writeText)navigator.clipboard.writeText(value).then(()=>notify("Message copied for sharing."),()=>notify("Sharing is not available in this browser."));else notify("Sharing is not available in this browser.")}else backendNotice("Regenerate response")}
function newChat(){const chat={id:makeId(),title:"New chat",messages:[],createdAt:Date.now(),updatedAt:Date.now()};state.chats.push(chat);state.activeId=chat.id;state.showArchived=false;save();renderChatList();renderMessages();showPage("chat");$("#messageInput").focus()}
function titleFrom(text){const clean=text.trim().replace(/\s+/g," ");return clean.length>34?clean.slice(0,34).trim()+"…":clean||"New chat"}
function addMessage(role,content,extra){
 const chat=activeChat();if(!chat)return;
 const m={role,content,at:Date.now()};
 if(extra&&extra.atts)m.atts=extra.atts.map(a=>{const o={kind:a.kind,name:a.name,thumb:a.thumb||""};if(a.full)Object.defineProperty(o,"_full",{value:a.full,enumerable:false});return o});
 if(extra&&extra.parts)Object.defineProperty(m,"_parts",{value:extra.parts,enumerable:false});
 chat.messages.push(m);chat.updatedAt=Date.now();
 if(role==="user"&&chat.title==="New chat")chat.title=titleFrom(content||"Attachment");
 save();renderMessages();renderChatList();return m;
}
function showPage(page){state.page=page;$("#chatPage").classList.toggle("hidden",page!=="chat");$("#settingsPage").classList.toggle("hidden",page!=="settings");$("#profilePage").classList.toggle("hidden",page!=="profile");$("#projectsPage").classList.toggle("hidden",page!=="projects");$("#pageTitle").textContent=page==="chat"?"UNIVERSAL AI":page==="settings"?"SETTINGS":page==="projects"?"PROJECTS":"PROFILE";if(page==="projects")renderProjects();$$('.nav-btn[data-page]').forEach(b=>b.classList.toggle("active",b.dataset.page===page));const tb=$("#topNewChat");if(tb){const home=page!=="chat";tb.innerHTML=ico(home?"arrowRight":"pen",home?23:21);tb.setAttribute("aria-label",home?"Back to home":"New chat")}}
function openSidebar(){$("#sidebar").classList.add("open");$("#overlay").classList.remove("hidden")}
function closeSidebar(){$("#sidebar").classList.remove("open");$("#overlay").classList.add("hidden")}
function fitTextarea(){
 const el=$("#messageInput");
 if(!el)return;
 const composer=el.closest(".composer");

 // When the field is empty, always return to its original compact size.
 if(!el.value){
  if(composer)composer.classList.remove("is-expanded");
  el.style.height="38px";
  return;
 }

 const expanded=el.value.length>15 || el.value.includes("\n");
 if(composer)composer.classList.toggle("is-expanded",expanded);
 el.style.height="auto";
 const contentHeight=el.scrollHeight;
 const targetHeight=expanded?66:56;
 el.style.height=Math.max(targetHeight,contentHeight)+"px";
}
let busy=false;
let activeGeneration=null;

function updateSendButton(){
 const button=$("#sendBtn");
 if(!button)return;
 button.innerHTML=ico(busy?"stop":"send",busy?19:21,busy?2.5:2.2);
 button.setAttribute("aria-label",busy?"Stop generating":"Send message");
 button.title=busy?"Stop generating":"Send message";
 button.classList.toggle("is-stop",busy);
}

function stopGeneration(){
 const run=activeGeneration;
 if(!run)return;

 run.stopped=true;
 try{run.controller.abort()}catch(e){}

 if(run.assistantMessage){
  run.assistantMessage.streaming=false;
  save();
  if(activeChat()===run.chat)renderMessages();
 }else if(run.chat){
  const stoppedMessage={
   role:"assistant",
   content:"Generation stopped before a reply arrived.",
   at:Date.now()
  };
  run.chat.messages.push(stoppedMessage);
  run.chat.updatedAt=Date.now();
  save();
  if(activeChat()===run.chat)renderMessages();
  renderChatList();
 }

 busy=false;
 activeGeneration=null;
 updateSendButton();
 if(window.speechSynthesis)speechSynthesis.cancel();
 notify("Response stopped.");
}

async function sendMessage(){
 if(busy)return;
 if(!speakNext&&window.speechSynthesis)speechSynthesis.cancel();
 const input=$("#messageInput"),text=input.value.trim();
 if(!text&&!state.attachments.length)return;
 if(!activeChat())newChat();
 const chat=activeChat();
 const files=state.attachments.slice();
 const atts=files.map(p=>({kind:p.kind,name:p.name,thumb:p.thumb||"",full:p.kind==="image"?"data:"+p.mime+";base64,"+p.data:""}));
 const parts=[];
 files.forEach(p=>{if(p.kind==="text")parts.push({text:"[File: "+p.name+"]\n"+p.text});else parts.push({inlineData:{mimeType:p.mime,data:p.data}})});
 addMessage("user",text,files.length?{atts,parts}:null);
 input.value="";fitTextarea();clearAttachments();

 const run={controller:new AbortController(),stopped:false,chat,assistantMessage:null};
 activeGeneration=run;
 busy=true;
 updateSendButton();
 notify("Soch raha hoon...");

 try{
  const img=files.length?"":imagePrompt(text);
  if(img){
   await makeImage(img,run);
  }else{
   const answer=await getReply(chat.messages,run.controller.signal);
   if(run.stopped)return;
   await typeReply(answer,run,chat);
   if(!files.length)extractMemory(text);
   if(speakNext&&!run.stopped)speak(answer);
  }
 }catch(e){
  if(!run.stopped&&e.name!=="AbortError")notify("Error: "+e.message);
 }finally{
  if(activeGeneration===run){
   activeGeneration=null;
   busy=false;
   updateSendButton();
  }
  speakNext=false;
 }
}
function setTheme(value){const dark=value==="Dark";document.body.classList.toggle("dark",dark);localStorage.setItem("universal_ai_theme",value);$$(".welcome-logo,.side-logo").forEach(el=>{el.src=dark?"universal-ai-logo-dark.png":"universal-ai-logo.jpg"})}
function makeUserId(){const c="ABCDEFGHJKLMNPQRSTUVWXYZ23456789",a=new Uint8Array(6);(window.crypto||{getRandomValues:x=>x.forEach((_,i)=>x[i]=Math.random()*256)}).getRandomValues(a);return "UA-"+[...a].map(n=>c[n%c.length]).join("")}
function closeProfileMenu(){
 const m=$("#profileMenu");if(m)m.remove();
 const card=$("#profileCard");if(card)card.classList.remove("open");
 document.removeEventListener("pointerdown",pmOutside,true);
 document.removeEventListener("keydown",pmEsc);
}
function pmOutside(e){if(!e.target.closest("#profileMenu")&&!e.target.closest("#profileCard"))closeProfileMenu()}
function pmEsc(e){if(e.key==="Escape")closeProfileMenu()}
function copyText(t){
 if(navigator.clipboard&&navigator.clipboard.writeText)return navigator.clipboard.writeText(t);
 return new Promise((res,rej)=>{try{const x=document.createElement("textarea");x.value=t;x.style.position="fixed";x.style.opacity="0";document.body.appendChild(x);x.select();document.execCommand("copy");x.remove();res()}catch(e){rej(e)}});
}
function openProfileMenu(){
 if($("#profileMenu")){closeProfileMenu();return}
 const card=$("#profileCard"),r=card.getBoundingClientRect(),dark=document.body.classList.contains("dark");
 const name=state.profile.name||"User",id=state.profile.userId||"";
 const m=document.createElement("div");m.id="profileMenu";m.setAttribute("role","menu");
 m.innerHTML='<div class="pm-head"><div class="avatar" id="pmAvatar"></div><div><strong></strong><small></small></div></div><div class="pm-sep"></div>'+
  '<button type="button" role="menuitem" data-pm="profile">'+ico("user",18)+'<span>Edit profile</span></button>'+
  '<button type="button" role="menuitem" data-pm="account">'+ico("settings",18)+'<span>Account settings</span></button>'+
  '<button type="button" role="menuitem" data-pm="memory">'+ico("sparkles",18)+'<span>Memory</span></button>'+
  '<button type="button" role="menuitem" data-pm="theme">'+ico(dark?"sun":"moon",18)+'<span>'+(dark?"Light mode":"Dark mode")+'</span></button>'+
  '<button type="button" role="menuitem" data-pm="copy">'+ico("copy",18)+'<span>Copy User ID</span></button>';
 m.querySelector("strong").textContent=name;m.querySelector("small").textContent="ID: "+id;
 const av=m.querySelector("#pmAvatar");
 if(state.profile.photo)av.innerHTML='<img src="'+state.profile.photo+'" alt="">';else av.textContent=name.charAt(0).toUpperCase();
 document.body.appendChild(m);
 const w=m.offsetWidth;
 m.style.left=Math.max(12,Math.min(r.left,window.innerWidth-w-12))+"px";
 m.style.bottom=(window.innerHeight-r.top+8)+"px";
 card.classList.add("open");
 m.addEventListener("click",e=>{
  const b=e.target.closest("[data-pm]");if(!b)return;
  const a=b.dataset.pm;closeProfileMenu();
  if(a==="profile"){showPage("profile");closeSidebar()}
  else if(a==="account"){showPage("settings");const t=$('.settings-tab[data-section="account"]');if(t)t.click();closeSidebar()}
  else if(a==="memory"){closeSidebar();openMemory()}
  else if(a==="theme"){const sel=$('[data-setting="theme"]');if(sel){sel.value=dark?"Light":"Dark";sel.dispatchEvent(new Event("change"))}else{setTheme(dark?"Light":"Dark")}}
  else if(a==="copy"){copyText(id).then(()=>notify("User ID copy ho gaya")).catch(()=>notify("Copy nahi ho paya"))}
 });
 setTimeout(()=>{document.addEventListener("pointerdown",pmOutside,true);document.addEventListener("keydown",pmEsc)},0);
}
function closeDropdown(){
 const d=$("#ddLayer");if(d)d.remove();
 document.removeEventListener("keydown",ddEsc);
}
function ddEsc(e){if(e.key==="Escape")closeDropdown()}
function openDropdown(sel,btn){
 closeDropdown();
 const row=sel.closest(".setting-row"),title=row&&row.querySelector("strong")?row.querySelector("strong").textContent:"Select";
 const layer=document.createElement("div");layer.id="ddLayer";
 layer.innerHTML='<div class="dd-back"></div><div class="dd-sheet" role="listbox"><div class="dd-grip"></div><div class="dd-title"></div><div class="dd-list"></div></div>';
 layer.querySelector(".dd-title").textContent=title;
 const list=layer.querySelector(".dd-list");
 [...sel.options].forEach(o=>{
  const b=document.createElement("button");b.type="button";b.className="dd-opt"+(o.value===sel.value?" on":"");
  b.setAttribute("role","option");b.setAttribute("aria-selected",o.value===sel.value?"true":"false");
  b.innerHTML="<span></span>"+(o.value===sel.value?ico("check",20,2.2):"");
  b.firstChild.textContent=o.textContent;
  b.onclick=()=>{
   if(sel.value!==o.value){sel.value=o.value;sel.dispatchEvent(new Event("change",{bubbles:true}))}
   syncDropdown(sel);closeDropdown();
  };
  list.appendChild(b);
 });
 layer.querySelector(".dd-back").onclick=closeDropdown;
 document.body.appendChild(layer);
 document.addEventListener("keydown",ddEsc);
 const on=list.querySelector(".on");if(on)on.scrollIntoView({block:"center"});
}
function syncDropdown(sel){
 const btn=sel.nextElementSibling;
 if(btn&&btn.classList.contains("dd-btn")){const o=sel.options[sel.selectedIndex];btn.querySelector(".dd-val").textContent=o?o.textContent:""}
}
function enhanceSelects(){
 $$("#settingsPage select").forEach(sel=>{
  if(sel.dataset.dd)return;sel.dataset.dd="1";
  sel.classList.add("dd-native");
  const btn=document.createElement("button");btn.type="button";btn.className="dd-btn";btn.setAttribute("aria-haspopup","listbox");
  btn.innerHTML='<span class="dd-val"></span>'+ico("chevDown",18,2);
  btn.onclick=()=>openDropdown(sel,btn);
  sel.insertAdjacentElement("afterend",btn);
  sel.addEventListener("change",()=>syncDropdown(sel));
  syncDropdown(sel);
 });
}
function setProfileUI(){const name=state.profile.name||"User";$("#miniName").textContent=name;if(!state.profile.userId){state.profile.userId=makeUserId();save()}$("#miniId").textContent="ID: "+state.profile.userId;$("#profileUserId").value=state.profile.userId;$("#miniAvatar").textContent=name.charAt(0).toUpperCase();$("#profileAvatar").textContent=name.charAt(0).toUpperCase();$("#profileName").value=state.profile.name||"";$("#profileUsername").value=state.profile.username||"";$("#profileMobile").value=state.profile.mobile||"";$("#profileBio").value=state.profile.bio||"";if(state.profile.photo){$("#miniAvatar").innerHTML='<img src="'+state.profile.photo+'" alt="">';$("#profileAvatar").innerHTML='<img src="'+state.profile.photo+'" alt="">'}}
function loadImg(file){return new Promise((res,rej)=>{const url=URL.createObjectURL(file),im=new Image();im.onload=()=>{URL.revokeObjectURL(url);res(im)};im.onerror=()=>{URL.revokeObjectURL(url);rej(new Error("Photo khul nahi payi"))};im.src=url})}
function drawScaled(im,max,q){const r=Math.min(1,max/Math.max(im.width,im.height)),c=document.createElement("canvas");c.width=Math.max(1,Math.round(im.width*r));c.height=Math.max(1,Math.round(im.height*r));c.getContext("2d").drawImage(im,0,0,c.width,c.height);return c.toDataURL("image/jpeg",q)}
async function shrink(dataUrl,max,q){const im=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=()=>rej(new Error("Photo khul nahi payi"));i.src=dataUrl});return drawScaled(im,max,q)}
function fileToB64(file){return new Promise((res,rej)=>{const r=new FileReader();r.onload=()=>res(String(r.result).split(",")[1]);r.onerror=()=>rej(new Error("File padh nahi payi"));r.readAsDataURL(file)})}
async function addAttachments(files){
 const incoming=[...files];
 for(const file of incoming){
  try{
   if(state.attachments.length>=5){notify("Ek message mein maximum 5 files");break}
   const name=file.name||"file";
   if(file.type.startsWith("image/")){
    const im=await loadImg(file);
    state.attachments.push({kind:"image",name,mime:"image/jpeg",data:drawScaled(im,1600,0.82).split(",")[1],thumb:drawScaled(im,640,0.7)});
   }else if(file.type==="application/pdf"||/\.pdf$/i.test(name)){
    if(file.size>10*1024*1024){notify("PDF 10MB se chhoti honi chahiye");continue}
    state.attachments.push({kind:"pdf",name,mime:"application/pdf",data:await fileToB64(file)});
   }else if(file.type.startsWith("text/")||/\.(txt|md|csv|json)$/i.test(name)){
    if(file.size>200*1024){notify("Text file 200KB se chhoti honi chahiye");continue}
    state.attachments.push({kind:"text",name,text:await file.text()});
   }else notify("Ye file type abhi support nahi hai (photo, PDF, text)");
  }catch(e){notify("File nahi khuli: "+e.message)}
 }
 renderAttachments();
}
function renderAttachments(){
 const box=$("#attachmentPreview");box.innerHTML="";
 if(!state.attachments.length){box.classList.add("hidden");return}
 box.classList.remove("hidden");
 state.attachments.forEach((p,i)=>{
  const item=document.createElement("div");item.className="att-item";
  if(p.kind==="image"){const img=document.createElement("img");img.src=p.thumb;img.alt=p.name;img.onclick=()=>openViewer("data:"+p.mime+";base64,"+p.data,p.name);item.appendChild(img)}
  else{item.innerHTML='<div class="att-file">'+ico("file",16)+"<span></span></div>";item.querySelector("span").textContent=p.name}
  const x=document.createElement("button");x.className="att-x";x.type="button";x.setAttribute("aria-label","Remove "+p.name);x.innerHTML=ico("close",12,2.6);
  x.onclick=()=>{state.attachments.splice(i,1);renderAttachments()};
  item.appendChild(x);box.appendChild(item);
 });
}
function attachmentMenu(){
 openModal("Add to message",'<div class="attach-cards"><button type="button" data-up="camera"><i>'+ico("camera",28,1.7)+'</i><span>Camera</span></button><button type="button" data-up="photos"><i>'+ico("image",28,1.7)+'</i><span>Photos</span></button><button type="button" data-up="files"><i>'+ico("fileUp",28,1.7)+'</i><span>Files</span></button></div><button type="button" class="attach-wide" data-up="gen">'+ico("sparkles",20,1.8)+'<span>Create image</span></button>');
 $$("[data-up]").forEach(b=>b.onclick=()=>{
  const t=b.dataset.up;closeModal();
  if(t==="camera")openCamera();
  if(t==="photos")$("#photoFilesInput").click();
  if(t==="files")$("#pdfInput").click();
  if(t==="gen"){const inp=$("#messageInput");inp.value="image: ";fitTextarea();inp.focus()}
 });
}
function clearAttachments(){state.attachments=[];renderAttachments()}
function load(){try{const saved=JSON.parse(localStorage.getItem(STORAGE_KEY)||"null");if(saved){state.chats=saved.chats||[];state.chats.forEach(c=>(c.messages||[]).forEach(m=>{if(m.streaming)m.streaming=false}));state.activeId=saved.activeId||null;state.profile={...state.profile,...saved.profile};state.settings=saved.settings||{};state.projects=saved.projects||[];state.memory=saved.memory||[] }}catch(e){}const theme=localStorage.getItem("universal_ai_theme")||"Light";setTheme(theme);state.activeId=null;renderChatList();renderMessages();setProfileUI();$$('[data-setting]').forEach(el=>{const key=el.dataset.setting;if(state.settings[key]!==undefined){if(el.type==="checkbox")el.checked=state.settings[key];else el.value=state.settings[key]}})}
$("#newChatBtn").addEventListener("click",newChat);$("#welcomeStartBtn").addEventListener("click",newChat);$("#topNewChat").addEventListener("click",()=>{if(state.page!=="chat")showPage("chat");else newChat()});$("#sendBtn").addEventListener("click",()=>{if(busy)stopGeneration();else sendMessage()});$("#messageInput").addEventListener("input",fitTextarea);$("#messageInput").addEventListener("keydown",e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();if(!busy)sendMessage()}});
$("#menuBtn").addEventListener("click",openSidebar);$("#closeSidebar").addEventListener("click",closeSidebar);$("#overlay").addEventListener("click",closeSidebar);$("#archiveToggle").addEventListener("click",()=>{state.showArchived=!state.showArchived;renderChatList()});
$$('.nav-btn[data-page]').forEach(b=>b.addEventListener("click",()=>{showPage(b.dataset.page);closeSidebar()}));
$("#settingsNav").addEventListener("click",e=>{const tab=e.target.closest("[data-section]");if(!tab)return;$$('.settings-tab').forEach(x=>x.classList.toggle("active",x===tab));$$('[data-settings-section]').forEach(s=>s.classList.toggle("hidden",s.dataset.settingsSection!==tab.dataset.section))});
$$('[data-setting]').forEach(el=>el.addEventListener("change",()=>{const key=el.dataset.setting,value=el.type==="checkbox"?el.checked:el.value;state.settings[key]=value;save();if(key==="theme")setTheme(value);notify("Setting saved on this device.")}));
$$('[data-action]').forEach(b=>b.addEventListener("click",()=>{if(b.dataset.action==="profile"){showPage("profile");return}if(b.dataset.action==="memory"){openMemory();return}const map={password:"Change password",security:"Account security", "2fa":"Two-step verification",connected:"Connected accounts",delete:"Delete account",memory:"Memory controls"};backendNotice(map[b.dataset.action]||"Account setting")}));
$("#profileCard").addEventListener("click",openProfileMenu);
$("#saveProfile").addEventListener("click",()=>{state.profile.name=$("#profileName").value.trim()||"User";state.profile.username=$("#profileUsername").value.trim();state.profile.mobile=$("#profileMobile").value.trim();state.profile.bio=$("#profileBio").value.trim();save();setProfileUI();notify("Profile saved on this device.")});
$("#photoInput").addEventListener("change",e=>{const file=e.target.files[0];if(!file)return;if(!file.type.startsWith("image/")){notify("Please select an image.");return}const reader=new FileReader();reader.onload=()=>{state.profile.photo=reader.result;save();setProfileUI()};reader.readAsDataURL(file)});
$("#attachBtn").addEventListener("click",attachmentMenu);$("#pdfInput").addEventListener("change",e=>addAttachments(e.target.files,"pdf"));$("#photoFilesInput").addEventListener("change",e=>addAttachments(e.target.files,"photo"));$("#cameraInput").addEventListener("change",e=>addAttachments(e.target.files,"photo"));
const IC={
 plus:'<path d="M12 5v14M5 12h14"/>',
 pen:'<path d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.4 2.6a2.1 2.1 0 0 1 3 3L12 15l-4 1 1-4Z"/>',
 menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
 close:'<path d="M6 6l12 12M18 6L6 18"/>',
 archive:'<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v9a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V9"/><path d="M10 13h4"/>',
 back:'<path d="M19 12H5M12 19l-7-7 7-7"/>',
 chat:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
 more:'<circle cx="5" cy="12" r="1.2"/><circle cx="12" cy="12" r="1.2"/><circle cx="19" cy="12" r="1.2"/>',
 settings:'<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
 user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
 send:'<path d="M12 19V5M5 12l7-7 7 7"/>',
 arrowRight:'<path d="M5 12h14M12 5l7 7-7 7"/>',
 camera:'<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
 image:'<rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/>',
 fileUp:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M12 12v6"/><path d="m9 15 3-3 3 3"/>',
 file:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>',
 sparkles:'<path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z"/><path d="M19 15l.7 1.8L21.5 17.5l-1.8.7L19 20l-.7-1.8-1.8-.7 1.8-.7z"/>',
 download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="M7 10l5 5 5-5"/><path d="M12 15V3"/>',
 flip:'<path d="M11 19H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/><path d="M13 5h7a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-5"/><circle cx="12" cy="12" r="3"/><path d="m18 22-3-3 3-3"/><path d="m6 2 3 3-3 3"/>',
  stop:'<rect x="6" y="6" width="12" height="12" rx="2"/>',
  chevDown:'<path d="m6 9 6 6 6-6"/>',
  check:'<path d="M20 6 9 17l-5-5"/>',
  moon:'<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41"/>',
  copy:'<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  updown:'<path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/>',
  folder:'<path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/>',
  trash:'<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>'
};
function ico(name,size,w){size=size||18;w=w||1.8;return '<svg viewBox="0 0 24 24" width="'+size+'" height="'+size+'" fill="none" stroke="currentColor" stroke-width="'+w+'" stroke-linecap="round" stroke-linejoin="round" style="display:inline-block;vertical-align:middle;flex:none">'+IC[name]+'</svg>'}
function applyIcons(){
 const set=(sel,html)=>{const el=$(sel);if(el)el.innerHTML=html};
 set("#menuBtn",ico("menu",22));
 set("#topNewChat",ico("pen",21));
 set("#closeSidebar",ico("close",22));
 set("#modalClose",ico("close",22));
 set("#attachBtn",ico("plus",22,2));
 set("#sendBtn",ico("send",21,2.2));
 set(".new-chat-btn span",ico("pen",18));
 set('.nav-btn[data-page="settings"] span',ico("settings",18));
 set('.nav-btn[data-page="projects"] span',ico("folder",19));
 set("#miniChev",ico("updown",16));
 const pi=$("#pdfInput");if(pi)pi.accept="application/pdf,.pdf,text/plain,.txt,.md,.csv,.json";
 ["#pdfInput","#photoFilesInput","#cameraInput"].forEach(sel=>{const el=$(sel);if(el)el.addEventListener("change",()=>{setTimeout(()=>{el.value=""},0)})});
}
(function(){const st=document.createElement("style");st.textContent=".brand-row{padding-bottom:16px}.brand-name{display:flex;align-items:center;letter-spacing:0}.side-logo{display:block;height:70px;width:auto;max-width:190px;object-fit:contain;mix-blend-mode:multiply}body.dark .side-logo{mix-blend-mode:screen}.nav-btn span svg,.new-chat-btn span svg{vertical-align:middle}.chat-more{display:grid;place-items:center}.profile-mini{border-radius:12px}.new-chat-row .archive-toggle{max-width:132px !important;padding:10px 8px !important;font-size:11px !important}#archiveToggle svg{margin-right:4px}.new-chat-row .new-chat-btn{padding:12px 10px !important;font-size:15px !important}";document.head.appendChild(st)})();
(function(){const st=document.createElement("style");st.textContent=".attach-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.attach-cards button{display:flex;flex-direction:column;align-items:center;gap:10px;padding:16px 4px 14px;border:1px solid var(--line);border-radius:20px;background:var(--bg);color:var(--fg);font-size:14px;font-weight:600}.attach-cards i{width:62px;height:62px;border-radius:50%;background:var(--soft);display:grid;place-items:center;font-style:normal}.attach-wide{width:100%;margin-top:10px;padding:14px;border:1px solid var(--line);border-radius:16px;background:var(--bg);color:var(--fg);font-size:14px;font-weight:600;display:flex;align-items:center;justify-content:center;gap:10px}.attachment-preview:not(.hidden){display:flex;flex-wrap:wrap;gap:8px;padding:0 6px 8px}.att-item{position:relative}.att-item img{display:block;width:64px;height:64px;object-fit:cover;border-radius:12px;border:1px solid var(--line);cursor:pointer}.att-x{position:absolute;top:-6px;right:-6px;width:22px;height:22px;border-radius:50%;border:0;background:var(--fg);color:var(--bg);display:grid;place-items:center;padding:0}.att-file{display:flex;align-items:center;gap:6px;padding:8px 10px;border:1px solid var(--line);border-radius:12px;font-size:12px;max-width:180px}.att-file span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.msg-atts{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px}.msg-img{display:block;width:min(260px,100%);max-height:340px;object-fit:cover;border-radius:14px;cursor:pointer}.msg-file{display:flex;align-items:center;gap:6px;padding:7px 10px;border-radius:10px;background:rgba(128,128,128,.18);font-size:12px}#viewer{position:fixed;inset:0;z-index:500;background:rgba(0,0,0,.94);display:flex;align-items:center;justify-content:center;touch-action:pinch-zoom}#viewer img{max-width:100%;max-height:86vh;object-fit:contain}.v-top{position:absolute;top:0;left:0;right:0;display:flex;justify-content:space-between;padding:calc(10px + env(safe-area-inset-top,0px)) 12px 10px}.v-top button{width:42px;height:42px;border-radius:50%;border:0;background:rgba(255,255,255,.14);color:#fff;display:grid;place-items:center}";document.head.appendChild(st)})();
(function(){const st=document.createElement("style");st.textContent="#camView{position:fixed;inset:0;z-index:600;background:#000;color:#fff;display:flex;align-items:center;justify-content:center}#camView video,#camView #camShot{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#000}#camView #camShot[hidden]{display:none}.cam-top{position:absolute;top:0;left:0;right:0;padding:calc(12px + env(safe-area-inset-top,0px)) 12px 12px;display:flex;z-index:2}.cam-top button,#camFlip{width:48px;height:48px;border-radius:50%;border:0;background:rgba(255,255,255,.2);color:#fff;display:grid;place-items:center;padding:0}#camMsg{position:absolute;left:24px;right:24px;top:40%;text-align:center;font-size:14px;line-height:1.5;color:#ddd;z-index:2}.cam-bar{position:absolute;left:0;right:0;bottom:calc(30px + env(safe-area-inset-bottom,0px));display:flex;align-items:center;justify-content:space-around;z-index:2}#camShutter{width:78px;height:78px;border-radius:50%;border:4px solid #fff;background:#fff;box-shadow:inset 0 0 0 5px #000;padding:0}.cam-bar.camx{display:none}.cam-bar.camx.on{display:flex}.cam-txt{padding:13px 24px;border-radius:28px;border:1px solid rgba(255,255,255,.5);background:rgba(255,255,255,.16);color:#fff;font-size:15px;font-weight:650}.cam-txt.primary{background:#fff;color:#000;border-color:#fff}";document.head.appendChild(st)})();
let speakNext=false;
const MIC_SVG='<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><line x1="12" y1="18" x2="12" y2="22"/></svg>';
function speak(text){
 if(!window.speechSynthesis)return;
 const clean=String(text).replace(/```[\s\S]*?```/g," ").replace(/https?:\/\/\S+/g," ").replace(/[*_#`>~|]/g,"").replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu,"").replace(/\s+/g," ").trim();
 if(!clean)return;
 speechSynthesis.cancel();
 clean.split(/(?<=[.!?\u0964])\s+/).forEach(part=>{
  if(!part.trim())return;
  const u=new SpeechSynthesisUtterance(part);
  u.lang=/[\u0900-\u097F]/.test(part)?"hi-IN":"en-IN";
  u.rate=1;
  speechSynthesis.speak(u);
 });
}
$("#micBtn").innerHTML=MIC_SVG;
let voice=null;
window.addEventListener("error",e=>{try{notify("JS error: "+e.message)}catch(_){}});
function encodeWav(chunks,inRate){
 let len=0;chunks.forEach(c=>len+=c.length);
 const data=new Float32Array(len);let o=0;chunks.forEach(c=>{data.set(c,o);o+=c.length});
 const outRate=16000,ratio=inRate/outRate,outLen=Math.floor(len/ratio),pcm=new Int16Array(outLen);
 for(let i=0;i<outLen;i++){
  const st=Math.floor(i*ratio),en=Math.min(Math.floor((i+1)*ratio),len);
  let sum=0,n=0;for(let j=st;j<en;j++){sum+=data[j];n++}
  const v=Math.max(-1,Math.min(1,n?sum/n:0));
  pcm[i]=v<0?v*0x8000:v*0x7FFF;
 }
 const buf=new ArrayBuffer(44+pcm.length*2),dv=new DataView(buf);
 const w=(off,str)=>{for(let i=0;i<str.length;i++)dv.setUint8(off+i,str.charCodeAt(i))};
 w(0,"RIFF");dv.setUint32(4,36+pcm.length*2,true);w(8,"WAVE");w(12,"fmt ");
 dv.setUint32(16,16,true);dv.setUint16(20,1,true);dv.setUint16(22,1,true);
 dv.setUint32(24,outRate,true);dv.setUint32(28,outRate*2,true);dv.setUint16(32,2,true);dv.setUint16(34,16,true);
 w(36,"data");dv.setUint32(40,pcm.length*2,true);
 new Int16Array(buf,44).set(pcm);
 const bytes=new Uint8Array(buf);let bin="";
 for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+0x8000));
 return btoa(bin);
}
async function transcribeAudio(b64){
 let res;
 try{res=await fetch(WORKER_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents:[{role:"user",parts:[{inlineData:{mimeType:"audio/wav",data:b64}},{text:"Transcribe this speech exactly as spoken, in the same language (Hindi in Devanagari script, or English). Output only the transcript and nothing else. If there is no speech, output NONE."}]}]})})}
 catch(e){throw new Error("Internet/network check karo")}
 const data=await res.json().catch(()=>({}));
 if(!res.ok)throw new Error(data.error?.message||("API error "+res.status));
 return (data.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("")||"").trim();
}
function closeVoice(){
 if(!voice)return;
 const v=voice;voice=null;
 cancelAnimationFrame(v.raf);clearTimeout(v.maxTimer);clearTimeout(v.waitTimer);
 try{v.proc&&v.proc.disconnect();v.src&&v.src.disconnect()}catch(e){}
 try{v.stream&&v.stream.getTracks().forEach(t=>t.stop())}catch(e){}
 try{v.ctx&&v.ctx.close()}catch(e){}
 v.panel.remove();
 return v;
}
async function finishVoice(){
 const v=voice;
 if(!v||v.busy)return;
 v.busy=true;
 cancelAnimationFrame(v.raf);clearTimeout(v.maxTimer);clearTimeout(v.waitTimer);
 try{v.proc&&v.proc.disconnect();v.src&&v.src.disconnect()}catch(e){}
 try{v.stream&&v.stream.getTracks().forEach(t=>t.stop())}catch(e){}
 const status=v.panel.querySelector("#vStatus"),canvas=v.panel.querySelector("#vWave");
 canvas.style.display="none";status.style.display="block";
 const secs=v.chunks.reduce((n,c)=>n+c.length,0)/(v.ctx?v.ctx.sampleRate:16000);
 if(secs<0.5){status.textContent="Awaaz record nahi hui ("+secs.toFixed(1)+" sec). Mic ya permission check karo, phir X dabakar dobara try karo.";return}
 status.textContent="Samajh raha hoon...";
 try{
  const text=await transcribeAudio(encodeWav(v.chunks,v.ctx.sampleRate));
  if(voice!==v)return;
  if(!text||/^NONE\.?$/i.test(text)){status.textContent="Kuch sunayi nahi diya. X dabakar dobara try karo.";return}
  closeVoice();
  $("#messageInput").value=text;fitTextarea();
  speakNext=true;sendMessage();
 }catch(e){
  if(voice===v)status.textContent="Error: "+e.message+" (X dabakar band karo)";
 }
}
async function startVoice(){
 if(voice)return;
 const panel=document.createElement("div");panel.id="voicePanel";
 panel.innerHTML='<button id="vCancel" aria-label="Cancel"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button><div id="vStatus">Mic shuru ho raha hai...</div><canvas id="vWave" style="display:none"></canvas><button id="vDone" aria-label="Send"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg></button>';
 document.body.appendChild(panel);
 const status=panel.querySelector("#vStatus"),canvas=panel.querySelector("#vWave");
 const v={panel,chunks:[],heard:false,lastLoud:Date.now(),lastPush:0,raf:0,frames:0,noise:0};
 voice=v;
 panel.querySelector("#vCancel").onclick=()=>{closeVoice()};
 panel.querySelector("#vDone").onclick=()=>{finishVoice()};
 const fail=msg=>{if(voice===v)status.textContent=msg};
 v.waitTimer=setTimeout(()=>fail("Mic ki permission ka jawab nahi aaya. OK / Allow dabao ya Chrome mein kholo."),8000);
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){fail("Is browser mein mic nahi chalta. Chrome mein kholo.");return}
 let stream;
 try{stream=await navigator.mediaDevices.getUserMedia({audio:true})}
 catch(e){fail("Mic nahi chala ("+(e.name||"error")+"). Permission ya Settings check karo.");return}
 clearTimeout(v.waitTimer);
 if(voice!==v){stream.getTracks().forEach(t=>t.stop());return}
 v.stream=stream;
 try{
  const AC=window.AudioContext||window.webkitAudioContext;
  const ctx=new AC();v.ctx=ctx;
  try{if(ctx.state==="suspended")await ctx.resume()}catch(e){}
  const src=ctx.createMediaStreamSource(stream);v.src=src;
  const analyser=ctx.createAnalyser();analyser.fftSize=512;
  const proc=ctx.createScriptProcessor(4096,1,1);v.proc=proc;
  const mute=ctx.createGain();mute.gain.value=0;
  proc.onaudioprocess=e=>{v.chunks.push(new Float32Array(e.inputBuffer.getChannelData(0)))};
  src.connect(analyser);src.connect(proc);proc.connect(mute);mute.connect(ctx.destination);
  status.style.display="none";canvas.style.display="block";
  const g=canvas.getContext("2d"),dpr=window.devicePixelRatio||1;
  const W=canvas.clientWidth||200,H=canvas.clientHeight||46;
  canvas.width=W*dpr;canvas.height=H*dpr;g.scale(dpr,dpr);
  const barW=3,gap=3,count=Math.max(10,Math.floor(W/(barW+gap)));
  const hist=new Array(count).fill(0.04),buf=new Uint8Array(analyser.fftSize);
  const color=getComputedStyle(panel).color;
  v.maxTimer=setTimeout(finishVoice,60000);
  const loop=()=>{
   if(voice!==v)return;
   analyser.getByteTimeDomainData(buf);
   let sum=0;for(let i=0;i<buf.length;i++){const x=(buf[i]-128)/128;sum+=x*x}
   const rms=Math.sqrt(sum/buf.length),now=Date.now();
   if(v.frames<15){v.noise=(v.noise||0)+rms/15;v.frames++}
   const th=Math.max(0.012,(v.noise||0)*2.5+0.006);
   if(v.frames>=15&&rms>th){v.heard=true;v.lastLoud=now}
   if(now-v.lastPush>55){hist.shift();hist.push(Math.min(1,0.05+rms*8));v.lastPush=now}
   g.clearRect(0,0,W,H);g.fillStyle=color;
   hist.forEach((h,i)=>{const bh=Math.max(3,h*H);g.fillRect(i*(barW+gap),(H-bh)/2,barW,bh)});
   if(v.heard&&now-v.lastLoud>1600){finishVoice();return}
   v.raf=requestAnimationFrame(loop);
  };
  v.raf=requestAnimationFrame(loop);
 }catch(e){
  canvas.style.display="none";status.style.display="block";
  fail("Recorder nahi bana: "+(e.message||e.name||"error"));
 }
}
$("#micBtn").addEventListener("click",()=>{
 if(window.speechSynthesis&&speechSynthesis.speaking){speechSynthesis.cancel();return}
 startVoice();
});
(function(){const st=document.createElement("style");st.textContent="#voicePanel{position:fixed;left:12px;right:12px;bottom:calc(14px + env(safe-area-inset-bottom,0px));height:66px;border-radius:33px;background:var(--bg);color:var(--fg);border:1px solid var(--line);box-shadow:var(--shadow);display:flex;align-items:center;gap:10px;padding:0 10px;z-index:300}#voicePanel button{width:46px;height:46px;flex:0 0 46px;border-radius:50%;border:0;background:var(--soft);color:var(--fg);display:grid;place-items:center}#voicePanel #vDone{background:var(--fg);color:var(--bg)}#voicePanel canvas{flex:1;min-width:0;height:46px}#vStatus{flex:1;min-width:0;font-size:13px;line-height:1.3;color:var(--muted);text-align:center}";document.head.appendChild(st)})();
$("#modalClose").addEventListener("click",closeModal);$("#modalLayer").addEventListener("click",e=>{if(e.target.id==="modalLayer")closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeModal();closeSidebar()}});
let cam=null;
function closeCamera(){
 if(!cam)return;
 const c=cam;cam=null;
 clearTimeout(c.timer);
 try{c.stream&&c.stream.getTracks().forEach(t=>t.stop())}catch(e){}
 document.removeEventListener("keydown",c.esc);
 c.el.remove();
}
async function openCamera(){
 if(cam)return;
 if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){$("#cameraInput").click();return}
 const el=document.createElement("div");el.id="camView";
 el.innerHTML='<video id="camVideo" playsinline muted autoplay></video><img id="camShot" alt="" hidden><div class="cam-top"><button type="button" id="camClose" aria-label="Close">'+ico("close",24)+'</button></div><div id="camMsg">Camera shuru ho raha hai...</div><div class="cam-bar" id="camBar"><button type="button" id="camFlip" aria-label="Switch camera">'+ico("flip",24)+'</button><button type="button" id="camShutter" aria-label="Take photo"></button><span style="width:48px"></span></div><div class="cam-bar camx" id="camBar2"><button type="button" id="camRetake" class="cam-txt">Retake</button><button type="button" id="camUse" class="cam-txt primary">Use photo</button></div>';
 document.body.appendChild(el);
 const esc=e=>{if(e.key==="Escape")closeCamera()};
 document.addEventListener("keydown",esc);
 const c=cam={el,stream:null,facing:"environment",blob:null,esc,timer:0};
 const video=el.querySelector("#camVideo"),shot=el.querySelector("#camShot"),msg=el.querySelector("#camMsg"),bar=el.querySelector("#camBar"),bar2=el.querySelector("#camBar2");
 const start=async()=>{
  try{c.stream&&c.stream.getTracks().forEach(t=>t.stop())}catch(e){}
  msg.style.display="block";msg.textContent="Camera shuru ho raha hai...";
  clearTimeout(c.timer);
  c.timer=setTimeout(()=>{if(cam===c&&msg.style.display!=="none")msg.textContent="Camera ki permission ka jawab nahi aaya. OK / Allow dabao."},8000);
  try{
   const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:c.facing},width:{ideal:1920},height:{ideal:1080}},audio:false});
   if(cam!==c){s.getTracks().forEach(t=>t.stop());return}
   c.stream=s;video.srcObject=s;
   video.style.transform=c.facing==="user"?"scaleX(-1)":"none";
   try{await video.play()}catch(e){}
   clearTimeout(c.timer);msg.style.display="none";
  }catch(e){
   clearTimeout(c.timer);
   if(cam!==c)return;
   msg.style.display="block";
   msg.innerHTML="Camera nahi chala ("+(e.name||"error")+").<br>Permission do ya phone ki Settings mein camera allow karo.<br><br><button type='button' id='camAlt' class='cam-txt'>Phone ke camera app se lo</button>";
   const alt=msg.querySelector("#camAlt");if(alt)alt.onclick=()=>{closeCamera();$("#cameraInput").click()};
  }
 };
 el.querySelector("#camClose").onclick=closeCamera;
 el.querySelector("#camFlip").onclick=()=>{c.facing=c.facing==="user"?"environment":"user";start()};
 el.querySelector("#camShutter").onclick=()=>{
  if(!video.videoWidth){notify("Camera abhi tayyar nahi hai");return}
  const cv=document.createElement("canvas");cv.width=video.videoWidth;cv.height=video.videoHeight;
  cv.getContext("2d").drawImage(video,0,0,cv.width,cv.height);
  cv.toBlob(b=>{
   if(!b||cam!==c){return}
   c.blob=b;shot.src=URL.createObjectURL(b);
   shot.hidden=false;video.style.visibility="hidden";bar.style.display="none";bar2.classList.add("on");
  },"image/jpeg",0.92);
 };
 el.querySelector("#camRetake").onclick=()=>{shot.hidden=true;video.style.visibility="visible";bar.style.display="flex";bar2.classList.remove("on")};
 el.querySelector("#camUse").onclick=()=>{
  if(!c.blob)return;
  const file=new File([c.blob],"camera-"+Date.now()+".jpg",{type:"image/jpeg"});
  closeCamera();addAttachments([file]);
 };
 start();
}
function openViewer(src,name){
 $$("#viewer").forEach(x=>x.remove());
 const v=document.createElement("div");v.id="viewer";
 v.innerHTML='<div class="v-top"><button type="button" id="vwClose" aria-label="Close">'+ico("close",24)+'</button><button type="button" id="vwSave" aria-label="Save">'+ico("download",22)+'</button></div><img alt="">';
 v.querySelector("img").src=src;
 document.body.appendChild(v);
 const close=()=>{v.remove();document.removeEventListener("keydown",esc)};
 const esc=e=>{if(e.key==="Escape")close()};
 document.addEventListener("keydown",esc);
 v.querySelector("#vwClose").onclick=close;
 v.onclick=e=>{if(e.target===v)close()};
 v.querySelector("#vwSave").onclick=()=>saveImage(src,name);
}
async function saveImage(src,name){
 const fname=(name||"image").replace(/\.[a-z0-9]+$/i,"").slice(0,30).replace(/[^a-z0-9]+/gi,"-").replace(/^-|-$/g,"")+".jpg";
 try{
  const blob=await (await fetch(src)).blob();
  const file=new File([blob],fname,{type:blob.type||"image/jpeg"});
  if(navigator.canShare&&navigator.canShare({files:[file]})){
   try{await navigator.share({files:[file]});return}
   catch(e){if(e.name==="AbortError")return}
  }
  const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=fname;
  document.body.appendChild(a);a.click();a.remove();
  notify("Photo download ho rahi hai");
 }catch(e){notify("Save nahi ho paya: "+e.message)}
}
function imagePrompt(t){
 const m=t.match(/^\s*(?:\/image|image|photo|pic|tasveer)\s*:\s*([\s\S]+)/i);
 if(m)return m[1].trim();
 if(/\b(image|photo|picture|tasveer)\b.*\b(bana|banao|generate|create)\b|\b(bana|banao|generate|create|draw)\b.*\b(image|photo|picture|tasveer)\b/i.test(t))return t.trim();
 return "";
}
async function toEnglishPrompt(p,signal){
 try{
  const out=await getReply([{role:"user",content:"Rewrite the following as one detailed English prompt for an AI image generator (subject, setting, lighting, style). Output only the prompt, with no quotes or extra text:\n"+p}],signal,{noContext:true});
  const t=out.trim();
  return(t.length>5&&t.length<1200)?t:p;
 }catch(e){
  if(e.name==="AbortError")throw e;
  return p;
 }
}
async function makeImage(prompt,run){
 notify("Photo bana raha hoon...");
 const signal=run?.controller?.signal;
 const en=await toEnglishPrompt(prompt,signal);
 if(run?.stopped)return;
 let res;
 try{
  res=await fetch(WORKER_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({image:en}),signal});
 }catch(e){
  if(e.name==="AbortError")throw e;
  throw new Error("Internet/network check karo");
 }
 const data=await res.json().catch(()=>({}));
 if(run?.stopped)return;
 if(!res.ok)throw new Error(data.error?.message||("API error "+res.status));
 const p=(data.candidates?.[0]?.content?.parts||[]).find(x=>x.inlineData||x.inline_data);
 const d=p&&(p.inlineData||p.inline_data);
 if(!d)throw new Error("Photo nahi bani, prompt badal kar try karo");
 const full="data:"+(d.mimeType||d.mime_type||"image/jpeg")+";base64,"+d.data;
 const thumb=await shrink(full,768,0.78);
 if(run?.stopped)return;
 addMessage("assistant","\u{1F5BC}\uFE0F "+prompt,{atts:[{kind:"image",name:"image.jpg",thumb,full}]});
}
async function typeReply(full,run,chat){
 const msg={role:"assistant",content:"",at:Date.now(),streaming:true};
 chat.messages.push(msg);
 chat.updatedAt=Date.now();
 run.assistantMessage=msg;
 save();

 const isVisible=()=>activeChat()===chat;
 if(isVisible())renderMessages();
 const bubble=isVisible()?$$("#messages .message.assistant").slice(-1)[0]:null;
 const box=$("#messages");
 let shown="";

 for(const part of full.split(/(\s+)/)){
  if(run.stopped)break;
  shown+=part;
  msg.content=shown;
  if(bubble){
   bubble.textContent=shown;
   box.scrollTop=box.scrollHeight;
  }
  if(part.trim()){
   const pause=/[.!?।]$/.test(part)?260:Math.min(160,Math.max(80,50+part.trim().length*5));
   await new Promise(resolve=>setTimeout(resolve,pause));
  }
 }

 if(!run.stopped){
  msg.content=full;
  msg.streaming=false;
  save();
  if(isVisible())renderMessages();
 }
}
let openProjectId=null;
function projectOf(chat){return chat&&chat.projectId?state.projects.find(p=>p.id===chat.projectId):null}
function newProjectChat(pid){newChat();const c=activeChat();if(c){c.projectId=pid;save();renderChatList()}}
function renderProjects(){
 const root=$("#projectsPage");if(!root)return;
 const proj=openProjectId&&state.projects.find(p=>p.id===openProjectId);
 if(!proj){
  openProjectId=null;
  let h='<div class="page-heading"><p class="eyebrow">WORKSPACE</p><h1>Projects</h1><p>Chats aur instructions ko ek jagah organize karo.</p></div><button type="button" class="primary-btn proj-new" id="projNew">'+ico("plus",16,2.2)+' New project</button><div class="proj-list">';
  if(!state.projects.length)h+='<p class="modal-copy proj-empty">Abhi koi project nahi hai. "New project" dabakar pehla project banao.</p>';
  state.projects.slice().sort((a,b)=>(b.createdAt||0)-(a.createdAt||0)).forEach(p=>{
   const n=state.chats.filter(c=>c.projectId===p.id).length;
   h+='<button type="button" class="proj-card" data-pid="'+p.id+'"><span class="proj-ic">'+ico("folder",20)+'</span><span class="proj-txt"><strong>'+escapeHtml(p.name)+'</strong><small>'+n+(n===1?' chat':' chats')+(p.instructions?' \u00b7 '+escapeHtml(p.instructions.slice(0,60)):'')+'</small></span></button>';
  });
  h+='</div>';
  root.innerHTML=h;
  $("#projNew").onclick=()=>projectForm();
  $$(".proj-card",root).forEach(b=>b.onclick=()=>{openProjectId=b.dataset.pid;renderProjects()});
  return;
 }
 const chats=state.chats.filter(c=>c.projectId===proj.id).sort((a,b)=>(b.updatedAt||b.createdAt)-(a.updatedAt||a.createdAt));
 let h='<button type="button" class="text-btn" id="projBack">'+ico("back",14)+' All projects</button><div class="page-heading"><p class="eyebrow">PROJECT</p><h1>'+escapeHtml(proj.name)+'</h1></div>';
 h+='<div class="profile-card"><label class="proj-lbl">Name<input class="modal-input" id="projName" maxlength="60"></label><label class="proj-lbl">Instructions<textarea class="modal-input proj-ta" id="projInstr" rows="5" placeholder="Is project ke chats mein AI kaise jawab de? (jaise: hamesha Hindi mein, chhote jawab...)"></textarea></label><button type="button" class="primary-btn" id="projSave">Save project</button></div>';
 h+='<button type="button" class="primary-btn proj-new" id="projChat">'+ico("pen",16,2)+' New chat in this project</button><div class="sidebar-label">CHATS IN THIS PROJECT</div><div class="proj-chats">';
 if(!chats.length)h+='<p class="modal-copy proj-empty">Is project mein abhi koi chat nahi hai.</p>';
 chats.forEach(c=>{h+='<button type="button" class="proj-chat" data-cid="'+c.id+'">'+ico("chat",16)+'<span>'+escapeHtml(c.title||"New chat")+'</span></button>'});
 h+='</div><button type="button" class="text-btn danger proj-del" id="projDel">'+ico("trash",14)+' Delete project</button>';
 root.innerHTML=h;
 $("#projName").value=proj.name;$("#projInstr").value=proj.instructions||"";
 $("#projBack").onclick=()=>{openProjectId=null;renderProjects()};
 $("#projSave").onclick=()=>{const n=$("#projName").value.trim();if(!n){notify("Project ka naam likho");return}proj.name=n;proj.instructions=$("#projInstr").value.trim();save();notify("Project save ho gaya");renderProjects()};
 $("#projChat").onclick=()=>newProjectChat(proj.id);
 $$(".proj-chat",root).forEach(b=>b.onclick=()=>{state.activeId=b.dataset.cid;showPage("chat");renderMessages();renderChatList();save()});
 $("#projDel").onclick=()=>askConfirm("Delete project","Project hat jayega. Uske chats bache rahenge, bas project se alag ho jayenge.","Delete",()=>{state.projects=state.projects.filter(p=>p.id!==proj.id);state.chats.forEach(c=>{if(c.projectId===proj.id)delete c.projectId});openProjectId=null;save();renderProjects();renderChatList()});
}
function projectForm(after){
 openModal("New project",'<input class="modal-input" id="npName" maxlength="60" placeholder="Project ka naam"><textarea class="modal-input proj-ta" id="npInstr" rows="4" placeholder="Instructions (optional): AI is project mein kaise jawab de?" style="margin-top:10px"></textarea><div class="modal-btns"><button type="button" class="modal-btn" id="npNo">Cancel</button><button type="button" class="modal-btn primary" id="npYes">Create</button></div>');
 setTimeout(()=>{const i=$("#npName");if(i)i.focus()},50);
 $("#npNo").onclick=closeModal;
 $("#npYes").onclick=()=>{
  const name=$("#npName").value.trim();
  if(!name){notify("Project ka naam likho");return}
  const p={id:makeId(),name,instructions:$("#npInstr").value.trim(),createdAt:Date.now()};
  state.projects.push(p);save();closeModal();
  if(after){after(p)}else{openProjectId=p.id;showPage("projects");renderProjects()}
 };
}
function moveToProject(chat){
 let h='<div class="modal-options">';
 state.projects.forEach(p=>{h+='<button type="button" data-pid="'+p.id+'">'+(chat.projectId===p.id?"\u2713 ":"")+escapeHtml(p.name)+'</button>'});
 if(chat.projectId)h+='<button type="button" data-pid="">Remove from project</button>';
 h+='<button type="button" data-new="1">+ New project</button></div>';
 openModal("Add to project",h);
 $$(".modal-options button").forEach(b=>b.onclick=()=>{
  if(b.dataset.new){projectForm(p=>{chat.projectId=p.id;save();renderChatList();notify("Chat project mein add ho gaya")});return}
  if(b.dataset.pid)chat.projectId=b.dataset.pid;else delete chat.projectId;
  save();closeModal();renderChatList();notify(b.dataset.pid?"Chat project mein add ho gaya":"Project se hata diya");
 });
}
function contextTurns(messages){
 const chat=state.chats.find(c=>c.messages===messages);
 const lines=[];
 const nm=(state.profile.name||"").trim();
 if(nm&&nm!=="User")lines.push("The user's name is "+nm+".");
 if(state.settings.memoryOn!==false)state.memory.forEach(m=>lines.push(m.text));
 let t="";
 if(lines.length)t+="Things you remember about the user from earlier conversations (use them naturally when relevant; do not list them unless asked):\n- "+lines.join("\n- ");
 const p=projectOf(chat);
 if(p&&p.instructions)t+=(t?"\n\n":"")+'Instructions for the project "'+p.name+'" (follow them in this chat):\n'+p.instructions;
 return t?[{role:"user",parts:[{text:t}]},{role:"model",parts:[{text:"Understood."}]}]:[];
}
async function extractMemory(text){
 if(state.settings.memoryOn===false)return;
 const t=(text||"").trim();
 if(t.length<10||t.length>1500)return;
 const existing=state.memory.map(m=>"- "+m.text).join("\n")||"(none)";
 const prompt='You maintain long-term memory about the user of a chat app.\n\nAlready remembered:\n'+existing+'\n\nUser\'s latest message:\n"""'+t+'"""\n\nReturn ONLY a JSON array of strings. Each string is ONE short, durable fact about the user that is worth remembering in future chats (name, age, city or country, nationality, languages, job or studies, family, hobbies, tastes, goals, or how they want the assistant to reply). Write each fact in English, third person (for example "The user\'s name is Nibras"). Do NOT include temporary requests, questions, or sensitive data such as passwords, card or ID numbers, OTPs. Do not repeat facts that are already remembered. If there is nothing new, return [].';
 try{
  const out=await getReply([{role:"user",content:prompt}],undefined,{noContext:true});
  const a=out.indexOf("["),b=out.lastIndexOf("]");
  if(a<0||b<a)return;
  const arr=JSON.parse(out.slice(a,b+1));
  if(!Array.isArray(arr))return;
  let added=0;
  arr.forEach(f=>{
   if(typeof f!=="string")return;
   const x=f.trim().replace(/\s+/g," ");
   if(x.length<4||x.length>200)return;
   if(state.memory.some(m=>m.text.toLowerCase()===x.toLowerCase()))return;
   state.memory.push({id:makeId(),text:x,at:Date.now()});added++;
  });
  if(added){state.memory=state.memory.slice(-80);save();notify("Memory updated")}
 }catch(e){}
}
function openMemory(){
 const on=state.settings.memoryOn!==false;
 let h='<label class="mem-toggle"><input type="checkbox" id="memOn"'+(on?" checked":"")+'><span>Chats ke beech cheezein yaad rakho</span></label><div class="mem-list">';
 if(!state.memory.length)h+='<p class="modal-copy">Abhi kuch yaad nahi hai. Chat mein apne baare mein batao (jaise naam, shehar, pasand) to AI yaad rakhega.</p>';
 state.memory.forEach(m=>{h+='<div class="mem-item"><span>'+escapeHtml(m.text)+'</span><button type="button" class="mem-x" data-mid="'+m.id+'" aria-label="Delete">'+ico("close",16,2)+'</button></div>'});
 h+='</div><div class="mem-add"><input class="modal-input" id="memNew" maxlength="160" placeholder="Kuch yaad rakhwana hai? Yahan likho"><button type="button" class="modal-btn primary" id="memAdd">Add</button></div>';
 if(state.memory.length)h+='<button type="button" class="modal-btn mem-clear" id="memClear">Clear all memory</button>';
 openModal("Memory",h);
 $("#memOn").onchange=e=>{state.settings.memoryOn=e.target.checked;save();notify(e.target.checked?"Memory on":"Memory off")};
 $$(".mem-x").forEach(b=>b.onclick=()=>{state.memory=state.memory.filter(m=>m.id!==b.dataset.mid);save();openMemory()});
 const add=()=>{const v=$("#memNew").value.trim();if(v.length<2)return;state.memory.push({id:makeId(),text:v,at:Date.now()});save();openMemory()};
 $("#memAdd").onclick=add;
 $("#memNew").onkeydown=e=>{if(e.key==="Enter")add()};
 const clr=$("#memClear");if(clr)clr.onclick=()=>askConfirm("Clear memory","AI ki saari yaad ki hui cheezein hat jayengi.","Clear",()=>{state.memory=[];save();openMemory()});
}
async function getReply(messages,signal,opts){
 const ctx=(opts&&opts.noContext)?[]:contextTurns(messages);
 const contents=ctx.concat(messages.slice(-20).map(m=>{
  const parts=[];
  if(m._parts)parts.push(...m._parts);
  let t=m.content||"";
  if(m.atts&&m.atts.length&&!m._parts)t=(t?t+"\n":"")+"[Attachment: "+m.atts.map(a=>a.name||a.kind).join(", ")+"]";
  if(!t.trim())t=m.atts&&m.atts.length?(m.role==="user"?"Is file/photo ko dekho aur batao isme kya hai.":"(image)"):" ";
  parts.push({text:t});
  return{role:m.role==="user"?"user":"model",parts};
 }));
 let res;
 try{
  res=await fetch(WORKER_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({contents}),signal});
 }catch(e){if(e.name==="AbortError")throw e;throw new Error("Internet/network check karo")}
 const data=await res.json().catch(()=>({}));
 if(!res.ok)throw new Error(data.error?.message||("API error "+res.status));
 const out=data.candidates?.[0]?.content?.parts?.map(p=>p.text||"").join("");
 if(!out)throw new Error("AI ne khaali jawab diya");
 return out;
}
applyIcons();
updateSendButton();
load();
enhanceSelects();
