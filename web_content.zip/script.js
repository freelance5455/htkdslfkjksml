const BANKS = [
  { id: 'CBE', name: 'Commercial Bank of Ethiopia', color: '#7e22ce', gradEnd: '#3b0764' },
  { id: 'Telebirr', name: 'Ethio Telecom Telebirr', color: '#059669', gradEnd: '#064e3b' },
  { id: 'M-Pesa', name: 'Safaricom M-Pesa', color: '#16a34a', gradEnd: '#14532d' },
  { id: 'Abyssinia', name: 'Bank of Abyssinia', color: '#d97706', gradEnd: '#78350f' },
  { id: 'Awash', name: 'Awash Bank', color: '#2563eb', gradEnd: '#1e3a8a' },
  { id: 'Dashen', name: 'Dashen Bank', color: '#4f46e5', gradEnd: '#1e1b4b' },
  { id: 'Cash', name: 'Physical Cash', color: '#475569', gradEnd: '#0f172a' }
];

let state = JSON.parse(localStorage.getItem('habib_financial_solution_v5')) || {
  profile: { name: 'Habib Yesuf', phone: '09', role: 'Financial Solution Suite' },
  balances: { CBE: 0, Telebirr: 0, 'M-Pesa': 0, Abyssinia: 0, Awash: 0, Dashen: 0, Cash: 0 },
  bankColors: {
    CBE: '#7e22ce',
    Telebirr: '#059669',
    'M-Pesa': '#16a34a',
    Abyssinia: '#d97706',
    Awash: '#2563eb',
    Dashen: '#4f46e5',
    Cash: '#475569'
  },
  excludedBanks: [],
  hiddenBanks: [],
  heroHidden: false,
  settingsOpenCards: [],
  notifications: [],
  notifEnabled: true,
  budgetLimit: 10000,
  budgetAlertPct: 90,
  transactions: [],
  processedHashes: []
};

let currentTopFilter = 'SUMMARY';
let analyticsTimeframe = 'month'; // 'day', 'week', 'month', 'year'

function saveState() {
  localStorage.setItem('habib_financial_solution_v5', JSON.stringify(state));
}

// =========================================================================
// 2-STEP APK INTRO & PUSH NOTIFICATION SYSTEM
// =========================================================================
function nextIntroStep(step) {
  document.getElementById('introStep1').style.display = step === 1 ? 'block' : 'none';
  document.getElementById('introStep2').style.display = step === 2 ? 'block' : 'none';
}

function finishIntroAndEnableNotifications() {
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }
  pushApkNotification(
    'Habib Financial Solution Active',
    'Background SMS listener and push alerts are enabled.'
  );
  const overlay = document.getElementById('apkIntroOverlay');
  if (overlay) {
    overlay.classList.add('hide');
    setTimeout(() => (overlay.style.display = 'none'), 400);
  }
}

function replayIntro() {
  const overlay = document.getElementById('apkIntroOverlay');
  overlay.style.display = 'flex';
  overlay.classList.remove('hide');
  nextIntroStep(1);
}

function pushApkNotification(title, body) {
  const item = {
    id: Date.now(),
    title,
    body,
    time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };
  state.notifications.unshift(item);
  if (state.notifications.length > 40) state.notifications.pop();
  saveState();
  updateNotifBadge();

  if (state.notifEnabled) {
    if (navigator.vibrate) navigator.vibrate([120, 60, 120]);
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(title, { body });
      } catch (e) {}
    }
  }
}

function triggerTestNotification() {
  pushApkNotification(
    '🔔 Habib Financial Solution Alert',
    'APK Notification System is active and synced with your accounts.'
  );
  showToast('🔔 APK Notification sent! Tap the bell icon at the top.');
}

function updateNotifBadge() {
  const badge = document.getElementById('notifBadgeCount');
  const count = state.notifications.length;
  if (count > 0) {
    badge.style.display = 'flex';
    badge.textContent = count > 9 ? '9+' : count;
  } else {
    badge.style.display = 'none';
  }
}

function toggleNotifModal() {
  const modal = document.getElementById('notifModal');
  modal.classList.toggle('open');
  renderNotifications();
}

function closeNotifModal(e) {
  if (e.target.id === 'notifModal') toggleNotifModal();
}

function clearNotifications() {
  state.notifications = [];
  saveState();
  updateNotifBadge();
  renderNotifications();
}

function renderNotifications() {
  const list = document.getElementById('notifList');
  list.innerHTML = state.notifications.length
    ? state.notifications
        .map(
          n => `
      <div class="notif-item">
        <div style="display:flex; justify-content:space-between; font-weight:700; color:#34d399; margin-bottom:3px;">
          <span>${n.title}</span>
          <span style="font-size:10px; color:var(--muted);">${n.time}</span>
        </div>
        <div style="color:#e2e8f0; font-size:11px;">${n.body}</div>
      </div>
    `
        )
        .join('')
    : `<div style="text-align:center; color:var(--muted); font-size:12px; padding:16px;">No notifications yet.</div>`;
}

function toggleNotifPref(cb) {
  state.notifEnabled = cb.checked;
  saveState();
}

// =========================================================================
// ANALYTICS TIMEFRAME SELECTOR
// =========================================================================
function setAnalyticsTimeframe(tf, btnEl) {
  analyticsTimeframe = tf;
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  if (btnEl) btnEl.classList.add('active');
  renderAll();
}

// =========================================================================
// UNIVERSITY STUDENT BUDGET PLANNER
// =========================================================================
function calcStudentBudget() {
  const allowance = parseFloat(document.getElementById('studentAllowance').value) || 0;
  const savePct = parseFloat(document.getElementById('studentSavePct').value) || 15;

  const savings = allowance * (savePct / 100);
  const remaining = Math.max(0, allowance - savings);
  const food = remaining * 0.60; // 60% for cafeteria/food
  const misc = remaining * 0.40; // 40% for photocopy/stationery/misc

  document.getElementById('stSaveOut').textContent = Number(savings).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  document.getElementById('stFoodOut').textContent = Number(food).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  document.getElementById('stMiscOut').textContent = Number(misc).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
}

// =========================================================================
// BANK CARD CONTROLS
// =========================================================================
function toggleHeroHide() {
  state.heroHidden = !state.heroHidden;
  saveState();
  renderAll();
}

function toggleBankHide(bankId, event) {
  event.stopPropagation();
  if (state.hiddenBanks.includes(bankId)) {
    state.hiddenBanks = state.hiddenBanks.filter(b => b !== bankId);
  } else {
    state.hiddenBanks.push(bankId);
  }
  saveState();
  renderAll();
}

function toggleCardSettings(bankId, event) {
  event.stopPropagation();
  if (state.settingsOpenCards.includes(bankId)) {
    state.settingsOpenCards = state.settingsOpenCards.filter(b => b !== bankId);
  } else {
    state.settingsOpenCards.push(bankId);
  }
  renderAll();
}

function formatBankMoney(bankId, amount) {
  if (state.hiddenBanks && state.hiddenBanks.includes(bankId)) {
    return '•••••• ETB';
  }
  return Number(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
}

function updateBankColor(bankId, color) {
  state.bankColors[bankId] = color;
  saveState();
  renderAll();
}

function toggleExcludeBank(bankId, checkbox) {
  if (checkbox.checked) {
    if (!state.excludedBanks.includes(bankId)) state.excludedBanks.push(bankId);
  } else {
    state.excludedBanks = state.excludedBanks.filter(b => b !== bankId);
  }
  saveState();
  renderAll();
}

// =========================================================================
// AUTO SMS PARSER & NATIVE ANDROID BRIDGE
// =========================================================================
function parseEthiopianBankSMS(sender, rawText) {
  const text = (rawText || '').trim();
  const lower = (sender + ' ' + text).toLowerCase();
  if (!text) return null;

  let bank = null;
  if (lower.includes('cbe') || lower.includes('commercial bank')) bank = 'CBE';
  else if (lower.includes('telebirr') || lower.includes('127')) bank = 'Telebirr';
  else if (lower.includes('m-pesa') || lower.includes('mpesa') || lower.includes('safaricom')) bank = 'M-Pesa';
  else if (lower.includes('abyssinia') || lower.includes('boa')) bank = 'Abyssinia';
  else if (lower.includes('awash')) bank = 'Awash';
  else if (lower.includes('dashen')) bank = 'Dashen';

  if (!bank) return null;

  const isCredit = /(credited|received|deposited|ገቢ|ተቀብለዋል|ገብቷል|added)/i.test(text);
  const isDebit = /(debited|transferred|paid|sent|withdrawn|deducted|ወጪ|ተቀንሷል|ልከዋል|ከፍለዋል)/i.test(text);
  if (!isCredit && !isDebit) return null;

  const type = isCredit && !isDebit ? 'INCOME' : 'EXPENSE';

  const amtMatch = text.match(/(?:ETB|Birr|ብር)\s*([0-9,]+(?:\.[0-9]{1,2})?)|([0-9,]+(?:\.[0-9]{1,2})?)\s*(?:ETB|Birr|ብር)/i);
  if (!amtMatch) return null;
  const amount = parseFloat((amtMatch[1] || amtMatch[2]).replace(/,/g, ''));
  if (isNaN(amount) || amount <= 0) return null;

  const balMatch = text.match(/(?:Current Balance|Available Balance|New Balance|Balance|ቀሪ ሂሳብ|ያለዎት ቀሪ ሂሳብ)\s*(?:is|:)?\s*(?:ETB|Birr|ብር)?\s*([0-9,]+(?:\.[0-9]{1,2})?)/i);
  const exactBalance = balMatch ? parseFloat(balMatch[1].replace(/,/g, '')) : null;

  return { bank, type, amount, exactBalance, raw: text };
}

window.onNativeSmsReceived = function(sender, messageBody) {
  const hash = btoa(unescape(encodeURIComponent((sender + '|' + messageBody).slice(0, 120))));
  if (state.processedHashes.includes(hash)) return false;

  const parsed = parseEthiopianBankSMS(sender, messageBody);
  if (!parsed) return false;

  state.processedHashes.push(hash);
  if (state.processedHashes.length > 300) state.processedHashes.shift();

  if (parsed.exactBalance !== null && !isNaN(parsed.exactBalance)) {
    state.balances[parsed.bank] = parsed.exactBalance;
  } else {
    state.balances[parsed.bank] = (state.balances[parsed.bank] || 0) + (parsed.type === 'INCOME' ? parsed.amount : -parsed.amount);
  }

  const tx = {
    id: Date.now() + Math.floor(Math.random() * 1000),
    bank: parsed.bank,
    type: parsed.type,
    amount: parsed.amount,
    note: parsed.type === 'INCOME' ? `${parsed.bank} Auto-Credit SMS` : `${parsed.bank} Auto-Debit SMS`,
    date: new Date().toISOString(),
    source: 'AUTO_SMS'
  };

  state.transactions.unshift(tx);
  saveState();
  renderAll();

  const sign = parsed.type === 'INCOME' ? '+' : '-';
  const alertTitle = `${parsed.bank} ${parsed.type === 'INCOME' ? 'Credit' : 'Debit'} Alert`;
  const alertBody = `${sign}${parsed.amount.toLocaleString()} ETB • Balance updated automatically.`;

  pushApkNotification(alertTitle, alertBody);
  showToast(`📩 ${alertTitle}: ${sign}${parsed.amount.toLocaleString()} ETB`);
  return true;
};

if (window.AndroidSmsBridge) {
  document.getElementById('bridgeStatusBadge').textContent = '🟢 Native APK Bridge Active';
  document.getElementById('bridgeStatusBadge').style.color = '#34d399';
}

function simulateIncomingBankSMS(sampleType) {
  const samples = {
    CBE_IN: {
      sender: 'CBE',
      body: 'Dear Customer, your Account 1000*****4521 has been Credited with ETB 5,200.00 on 14/11/2026. Your Current Balance is ETB 24,100.00.'
    },
    TELEBIRR_OUT: {
      sender: '127',
      body: 'Dear Customer, you have transferred ETB 450.00 to merchant via telebirr. Your current balance is ETB 1,890.50.'
    },
    MPESA_IN: {
      sender: 'M-PESA',
      body: 'Confirmed. You have received ETB 1,500.00 from Habib on M-PESA. New M-PESA balance is ETB 4,900.00.'
    }
  };
  const s = samples[sampleType];
  window.onNativeSmsReceived(s.sender, s.body + ' [Ref:' + Date.now().toString().slice(-4) + ']');
}

function showToast(msg) {
  const el = document.getElementById('smsToast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 3800);
}

// =========================================================================
// NAVIGATION & RENDERING
// =========================================================================
function switchPage(pageId, btnEl) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById('page-' + pageId).classList.add('active');

  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  if (btnEl) {
    btnEl.classList.add('active');
  } else {
    const target = document.querySelector(`.nav-btn[data-page="${pageId}"]`);
    if (target) target.classList.add('active');
  }
  renderAll();
}

function setTopFilter(filterKey, chipEl) {
  currentTopFilter = filterKey;
  document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
  if (chipEl) {
    chipEl.classList.add('active');
  } else {
    const target = document.querySelector(`.filter-chip[data-filter="${filterKey}"]`);
    if (target) target.classList.add('active');
  }
  renderAll();
}

function refreshApp(btn) {
  btn.classList.add('spin');
  setTimeout(() => btn.classList.remove('spin'), 600);
  renderAll();
  showToast('✅ Habib Financial Solution successfully refreshed');
}

function renderAll() {
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();
  const currentWeekNum = getWeekNumber(now);

  // Filter transactions based on top menu selection
  let filteredTx = state.transactions;
  if (currentTopFilter === 'TODAY') {
    filteredTx = state.transactions.filter(t => t.date.slice(0, 10) === todayStr);
  } else if (currentTopFilter !== 'SUMMARY') {
    filteredTx = state.transactions.filter(t => t.bank === currentTopFilter);
  }

  // Compute Hero Consolidated Balance
  let displayBalance = 0;
  if (currentTopFilter === 'SUMMARY' || currentTopFilter === 'TODAY') {
    displayBalance = Object.keys(state.balances).reduce((sum, bId) => {
      if (state.excludedBanks && state.excludedBanks.includes(bId)) return sum;
      return sum + Number(state.balances[bId] || 0);
    }, 0);
    document.getElementById('heroFilterLabel').textContent =
      currentTopFilter === 'TODAY' ? "Today's Consolidated Activity" : 'Total Consolidated Balance';
  } else {
    displayBalance = Number(state.balances[currentTopFilter] || 0);
    document.getElementById('heroFilterLabel').textContent = `${currentTopFilter} Account Balance`;
  }

  const totalInc = filteredTx.filter(t => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  const totalExp = filteredTx.filter(t => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);

  document.getElementById('heroTotalBalance').textContent = state.heroHidden
    ? '•••••• ETB'
    : Number(displayBalance).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  document.getElementById('heroIncome').textContent = '+' + Number(totalInc).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  document.getElementById('heroExpense').textContent = '-' + Number(totalExp).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';

  // Bank Cards Grid
  const bankGrid = document.getElementById('bankCardsGrid');
  bankGrid.innerHTML = BANKS.map(b => {
    const bal = state.balances[b.id] || 0;
    const isSel = currentTopFilter === b.id ? 'selected' : '';
    const baseColor = (state.bankColors && state.bankColors[b.id]) || b.color;
    const isExcluded = state.excludedBanks && state.excludedBanks.includes(b.id);
    const isSettingsOpen = state.settingsOpenCards && state.settingsOpenCards.includes(b.id);
    const cardGradient = `linear-gradient(135deg, ${baseColor} 0%, #0f172a 92%)`;

    return `
      <div class="bank-card ${isSel} ${isSettingsOpen ? 'show-settings' : ''}" style="background:${cardGradient};" onclick="setTopFilter('${b.id}')">
        <div class="bank-top">
          <span class="bank-badge">${b.id}</span>
          <button class="icon-btn-sm" onclick="toggleCardSettings('${b.id}', event)" title="Card Controls">⚙</button>
        </div>
        <div class="bank-bal">${formatBankMoney(b.id, bal)}</div>
        <div class="bank-sub">${b.name} ${isExcluded ? '• (Excluded)' : ''}</div>
        
        <div class="bank-controls" onclick="event.stopPropagation()">
          <div style="display:flex; justify-content:space-between; align-items:center;">
            <span>Hide / Show Balance:</span>
            <button class="icon-btn-sm" onclick="toggleBankHide('${b.id}', event)">👁</button>
          </div>
          <label style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
            <span>Card Gradient Theme:</span>
            <input type="color" value="${baseColor}" onchange="updateBankColor('${b.id}', this.value)" />
          </label>
          <label style="display:flex; justify-content:space-between; align-items:center; cursor:pointer;">
            <span>Exclude from Total:</span>
            <input type="checkbox" style="width:14px; height:14px;" ${isExcluded ? 'checked' : ''} onchange="toggleExcludeBank('${b.id}', this)" />
          </label>
        </div>
      </div>
    `;
  }).join('');

  // Home Recent Transactions
  const homeList = document.getElementById('homeTxList');
  homeList.innerHTML = filteredTx.length
    ? filteredTx.slice(0, 6).map(renderTxItem).join('')
    : `<div class="panel floating-card" style="text-align:center; color:var(--muted); font-size:12px;">No recorded transactions yet.</div>`;

  // Full Transactions & Search
  const q = (document.getElementById('txSearchInput')?.value || '').toLowerCase();
  const searched = filteredTx.filter(t =>
    t.bank.toLowerCase().includes(q) ||
    t.note.toLowerCase().includes(q) ||
    String(t.amount).includes(q)
  );
  document.getElementById('fullTxList').innerHTML = searched.length
    ? searched.map(renderTxItem).join('')
    : `<div class="panel floating-card" style="text-align:center; color:var(--muted); font-size:12px;">No matching transactions found.</div>`;

  // =========================================================================
  // ANALYTICS TIMEFRAME CALCULATIONS & GRADIENT BAR GRAPH
  // =========================================================================
  let tfTransactions = state.transactions.filter(t => {
    const tDate = new Date(t.date);
    if (analyticsTimeframe === 'day') {
      return t.date.slice(0, 10) === todayStr;
    } else if (analyticsTimeframe === 'week') {
      return getWeekNumber(tDate) === currentWeekNum && tDate.getFullYear() === currentYear;
    } else if (analyticsTimeframe === 'month') {
      return tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear;
    } else if (analyticsTimeframe === 'year') {
      return tDate.getFullYear() === currentYear;
    }
    return true;
  });

  const tfInc = tfTransactions.filter(t => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  const tfExp = tfTransactions.filter(t => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);

  document.getElementById('tfLabelTitle').textContent = `የተመረጠው ጊዜ (${analyticsTimeframe.toUpperCase()}) አጠቃላይ ገቢና ወጪ`;
  document.getElementById('tfIncomeOut').textContent = '+' + Number(tfInc).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  document.getElementById('tfExpenseOut',).textContent = '-' + Number(tfExp).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';

  // Render Gradient Bar Graph
  const maxVal = Math.max(1, tfInc, tfExp);
  const incWidth = Math.round((tfInc / maxVal) * 100);
  const expWidth = Math.round((tfExp / maxVal) * 100);

  document.getElementById('gradientBarGraphContainer').innerHTML = `
    <div class="gbar-item">
      <div class="gbar-info">
        <span style="color:#34d399;">총 ገቢ (Total Income)</span>
        <span style="color:#34d399;">${Number(tfInc).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB</span>
      </div>
      <div class="gbar-track"><div class="gbar-fill income" style="width:${incWidth}%"></div></div>
    </div>
    <div class="gbar-item" style="margin-top:6px;">
      <div class="gbar-info">
        <span style="color:#f87171;">총 ወጪ (Total Expense)</span>
        <span style="color:#f87171;">${Number(tfExp).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB</span>
      </div>
      <div class="gbar-track"><div class="gbar-fill expense" style="width:${expWidth}%"></div></div>
    </div>
  `;

  // Analytics Overall
  const allInc = state.transactions.filter(t => t.type === 'INCOME').reduce((s, t) => s + t.amount, 0);
  const allExp = state.transactions.filter(t => t.type === 'EXPENSE').reduce((s, t) => s + t.amount, 0);
  const rate = allInc > 0 ? Math.max(0, Math.min(100, Math.round(((allInc - allExp) / allInc) * 100))) : 0;
  document.getElementById('savingsRateVal').textContent = rate + '%';
  document.getElementById('savingsRateBar').style.width = rate + '%';

  const totalNet = Math.max(1, Object.values(state.balances).reduce((a, b) => a + Math.max(0, b), 0));
  document.getElementById('bankBreakdownList').innerHTML = BANKS.map(b => {
    const val = Math.max(0, state.balances[b.id] || 0);
    const pct = Math.round((val / totalNet) * 100);
    const col = (state.bankColors && state.bankColors[b.id]) || b.color;
    return `
      <div>
        <div style="display:flex; justify-content:space-between; font-size:12px;">
          <span>${b.name}</span>
          <span>${formatBankMoney(b.id, val)} (${pct}%)</span>
        </div>
        <div class="prog-bg"><div class="prog-fill" style="width:${pct}%; background:${col};"></div></div>
      </div>
    `;
  }).join('');

  // Budget
  const limit = Number(state.budgetLimit || 10000);
  const usedPct = Math.min(100, Math.round((allExp / Math.max(1, limit)) * 100));
  document.getElementById('budgetUsedText').textContent = 'Spent: ' + Number(allExp).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  document.getElementById('budgetLimitText').textContent = 'Limit: ' + Number(limit).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
  const bar = document.getElementById('budgetProgBar');
  bar.style.width = usedPct + '%';
  bar.style.background = usedPct > 85 ? 'var(--danger)' : 'var(--primary)';

  // Profile & Welcome Card Sync
  const userName = state.profile.name || 'Habib Yesuf';
  const userRole = state.profile.role || 'Financial Solution Suite';
  document.getElementById('headerUserGreeting').textContent = `Welcome, ${userName}`;
  document.getElementById('welcomeUserRole').textContent = `👤 ${userName} • ${userRole}`;

  if (document.activeElement.tagName !== 'INPUT') {
    document.getElementById('profName').value = state.profile.name || '';
    document.getElementById('profPhone').value = state.profile.phone || '';
    document.getElementById('profRole').value = state.profile.role || '';
    document.getElementById('monthlyBudgetInput').value = limit;
    document.getElementById('bankInitialInputs').innerHTML = BANKS.map(b => `
      <div class="input-group" style="margin:0;">
        <label>${b.id} (ETB)</label>
        <input type="number" id="init_${b.id}" value="${state.balances[b.id] || 0}" />
      </div>
    `).join('');
  }
  updateNotifBadge();
}

function getWeekNumber(d) {
  d = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  var yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  var weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
  return weekNo;
}

function renderTxItem(tx) {
  const isIn = tx.type === 'INCOME';
  const d = new Date(tx.date);
  const timeStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  return `
    <div class="tx-item">
      <div class="tx-left">
        <div class="tx-icon ${isIn ? 'tx-in' : 'tx-out'}">${isIn ? '↓' : '↑'}</div>
        <div>
          <div class="tx-title">${tx.note}</div>
          <div class="tx-meta">${tx.bank} • ${timeStr}</div>
        </div>
      </div>
      <div class="tx-amt ${isIn ? 'text-green' : 'text-red'}">
        ${isIn ? '+' : '-'}${Number(tx.amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ETB
      </div>
    </div>
  `;
}

// =========================================================================
// TOOLS & ACTIONS
// =========================================================================
function calcEthioTax() {
  const gross = parseFloat(document.getElementById('grossSalaryInput').value) || 0;
  const pension = gross * 0.07;
  let tax = 0;
  if (gross > 10900) tax = gross * 0.35 - 1500;
  else if (gross > 7800) tax = gross * 0.30 - 955;
  else if (gross > 5250) tax = gross * 0.25 - 565;
  else if (gross > 3200) tax = gross * 0.20 - 302.5;
  else if (gross > 1650) tax = gross * 0.15 - 142.5;
  else if (gross > 600) tax = gross * 0.10 - 60;

  const net = Math.max(0, gross - tax - pension);
  document.getElementById('taxOut').textContent = tax.toFixed(2) + ' ETB';
  document.getElementById('pensionOut').textContent = pension.toFixed(2) + ' ETB';
  document.getElementById('netSalaryOut').textContent = net.toFixed(2) + ' ETB';
}

function calcEqub() {
  const amt = parseFloat(document.getElementById('equbAmount').value) || 0;
  const mem = parseFloat(document.getElementById('equbMembers').value) || 0;
  document.getElementById('equbTotalOut').textContent = Number(amt * mem).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
}

function calcFX() {
  const amt = parseFloat(document.getElementById('fxAmount').value) || 0;
  const rate = parseFloat(document.getElementById('fxRate').value) || 0;
  document.getElementById('fxTotalOut').textContent = Number(amt * rate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' ETB';
}

function saveBudgetLimit() {
  const val = parseFloat(document.getElementById('monthlyBudgetInput').value);
  if (val > 0) {
    state.budgetLimit = val;
    saveState();
    renderAll();
    showToast('🎯 Monthly budget limit updated');
  }
}

function addManualTransaction() {
  const type = document.getElementById('manType').value;
  const bank = document.getElementById('manBank').value;
  const amount = parseFloat(document.getElementById('manAmount').value);
  const note = document.getElementById('manNote').value.trim() || `${bank} Manual ${type}`;
  if (!amount || amount <= 0) return showToast('⚠️ Please enter a valid amount');

  state.balances[bank] = (state.balances[bank] || 0) + (type === 'INCOME' ? amount : -amount);
  state.transactions.unshift({
    id: Date.now(),
    bank,
    type,
    amount,
    note,
    date: new Date().toISOString(),
    source: 'MANUAL'
  });
  document.getElementById('manAmount').value = '';
  document.getElementById('manNote').value = '';
  saveState();
  renderAll();
  pushApkNotification(`Manual ${type}`, `${bank}: ${amount.toLocaleString()} ETB (${note})`);
  showToast('✅ Transaction successfully added');
}

function saveProfile() {
  state.profile.name = document.getElementById('profName').value.trim() || 'Habib Yesuf';
  state.profile.phone = document.getElementById('profPhone').value.trim();
  state.profile.role = document.getElementById('profRole').value.trim();
  saveState();
  renderAll();
  showToast('👤 Profile credentials updated');
}

function saveInitialBalances() {
  BANKS.forEach(b => {
    const val = parseFloat(document.getElementById('init_' + b.id).value);
    if (!isNaN(val)) state.balances[b.id] = val;
  });
  saveState();
  renderAll();
  showToast('🏦 Bank balances successfully calibrated');
}

function exportCSV() {
  const rows = [['Date', 'Bank', 'Type', 'Amount (ETB)', 'Note', 'Source']];
  state.transactions.forEach(t => rows.push([t.date, t.bank, t.type, t.amount, `"${t.note}"`, t.source]));
  const csv = rows.map(r => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'habib_financial_history.csv';
  a.click();
}

function exportBackupJSON() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'habib_financial_backup.json';
  a.click();
}

function resetAllData() {
  if (confirm('Are you sure you want to perform a factory reset?')) {
    localStorage.removeItem('habib_financial_solution_v5');
    location.reload();
  }
}

calcFX();
renderAll();
