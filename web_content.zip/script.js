
/* ==========================================
   BLOCK MASTER - SMOOTH EDITION
   COMPLETE JAVASCRIPT
========================================== */

const $ = id => document.getElementById(id);

const SIZE = 8;
const boardEl = $("board");
const piecesEl = $("pieces");

let board = [];
let pieces = [];
let score = 0;
let best = Number(localStorage.getItem("bm_best") || 0);
let selected = -1;
let dragging = null;
let sound = true;
let gameActive = false;

let dragGhost = null;
let dragFrame = null;
let latestPointer = null;
let dragPreview = null;
let previewCells = [];

const COLORS = [
  "#ff3939", "#3472ff", "#ffcf25",
  "#24dca4", "#b45aff", "#ff8c25",
  "#29d5ec"
];

const SHAPES = [
  [[0,0]],
  [[0,0],[0,1]],
  [[0,0],[1,0]],
  [[0,0],[0,1],[0,2]],
  [[0,0],[1,0],[2,0]],
  [[0,0],[0,1],[1,0],[1,1]],
  [[0,0],[1,0],[2,0],[3,0]],
  [[0,0],[0,1],[0,2],[0,3]],
  [[0,0],[1,0],[2,0],[2,1]],
  [[0,0],[0,1],[0,2],[1,0]],
  [[0,0],[1,0],[1,1],[1,2]],
  [[0,2],[1,0],[1,1],[1,2]],
  [[0,0],[1,0],[2,0],[2,1],[2,2]],
  [[0,0],[0,1],[1,1],[2,1]],
  [[0,0],[1,0],[1,1],[2,1]],
  [[0,1],[1,0],[1,1],[2,0]],
  [[0,0],[0,1],[0,2],[1,1],[2,1]],
  [[0,0],[0,1],[1,0],[1,1],[2,0],[2,1]]
];

// ==========================================
// PERFORMANCE CSS
// ==========================================

const performanceCSS = document.createElement("style");

performanceCSS.textContent = `
  .piece-slot,
  .pieces,
  .piece-area,
  .mini-grid,
  .mini-cell,
  .board {
    touch-action: none !important;
    user-select: none !important;
    -webkit-user-select: none !important;
  }

  .drag-ghost {
    position: fixed;
    top: 0;
    left: 0;
    display: grid;
    pointer-events: none;
    z-index: 999999;
    transform-origin: top left;
    will-change: transform;
    contain: layout style paint;
    opacity: .97;
    filter: drop-shadow(0 5px 5px #0008);
  }

  .drag-ghost-cell {
    width: 100%;
    height: 100%;
    border: 2px solid #ffffff88;
    border-radius: 3px;
    box-shadow:
      inset 3px 3px 3px #ffffff66,
      inset -3px -3px 3px #00000030;
  }

  .cell.preview {
    background: #54cfff !important;
    box-shadow: inset 0 0 8px white;
  }

  .cell.invalid {
    background: #ff5151 !important;
  }
`;

document.head.appendChild(performanceCSS);

$("bestScore").textContent = best;

// ==========================================
// SOUND
// ==========================================

let audioContext;

function playSound(freq = 400) {
  if (!sound) return;

  try {
    audioContext ||= new (
      window.AudioContext || window.webkitAudioContext
    )();

    if (audioContext.state === "suspended") {
      audioContext.resume();
    }

    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();

    osc.connect(gain);
    gain.connect(audioContext.destination);

    osc.frequency.value = freq;

    gain.gain.setValueAtTime(
      0.07, audioContext.currentTime
    );

    gain.gain.exponentialRampToValueAtTime(
      0.001, audioContext.currentTime + 0.12
    );

    osc.start();
    osc.stop(audioContext.currentTime + 0.12);
  } catch (e) {}
}

// ==========================================
// MENU
// ==========================================

function startGame() {
  $("homeScreen").classList.add("hidden");
  $("gameScreen").classList.remove("hidden");
  $("gameOver").classList.add("hidden");
  $("settingsModal").classList.add("hidden");
  resetGame();
}

$("classicBtn").onclick = startGame;
$("adventureBtn").onclick = startGame;

$("moreBtn").onclick = () => {
  alert("More Games coming soon!");
};

$("medalBtn").onclick = () => {
  $("medalBest").textContent = best;
  $("medalModal").classList.remove("hidden");
};

$("closeMedal").onclick = () => {
  $("medalModal").classList.add("hidden");
};

$("settingsBtn").onclick = () => {
  $("settingsModal").classList.remove("hidden");
};

$("closeSettings").onclick = () => {
  $("settingsModal").classList.add("hidden");
};

$("soundToggle").onclick = () => {
  sound = !sound;

  $("soundToggle").textContent =
    sound ? "🔊 SOUND: ON" : "🔇 SOUND: OFF";

  if (sound) playSound(600);
};

function goHome() {
  gameActive = false;
  cancelDrag();

  $("homeScreen").classList.remove("hidden");
  $("gameScreen").classList.add("hidden");
  $("gameOver").classList.add("hidden");
  $("settingsModal").classList.add("hidden");
}

$("homeBtn").onclick = goHome;
$("exitGame").onclick = goHome;
$("gameOverHome").onclick = goHome;

// ==========================================
// BOARD
// ==========================================

function createBoard() {
  board = Array.from(
    { length: SIZE },
    () => Array(SIZE).fill(null)
  );

  boardEl.innerHTML = "";

  for (let r = 0; r < SIZE; r++) {
    for (let c = 0; c < SIZE; c++) {
      const cell = document.createElement("div");

      cell.className = "cell";
      cell.dataset.row = r;
      cell.dataset.col = c;

      boardEl.appendChild(cell);
    }
  }

  renderBoard();
}

function renderBoard() {
  for (let i = 0; i < boardEl.children.length; i++) {
    const cell = boardEl.children[i];
    const r = Math.floor(i / SIZE);
    const c = i % SIZE;

    cell.className = "cell";
    cell.style.background = board[r][c] || "";

    if (board[r][c]) {
      cell.classList.add("filled");
    }
  }
}

// ==========================================
// PIECES
// ==========================================

function randomPiece() {
  const shape = SHAPES[
    Math.floor(Math.random() * SHAPES.length)
  ];

  return {
    shape: shape.map(p => [...p]),
    color: COLORS[
      Math.floor(Math.random() * COLORS.length)
    ]
  };
}

function generatePieces() {
  pieces = [
    randomPiece(),
    randomPiece(),
    randomPiece()
  ];

  selected = -1;
  renderPieces();
}

function renderPieces() {
  piecesEl.innerHTML = "";

  pieces.forEach((piece, index) => {
    const slot = document.createElement("div");

    slot.className = "piece-slot";

    if (!piece) {
      slot.classList.add("used");
      piecesEl.appendChild(slot);
      return;
    }

    if (selected === index) {
      slot.classList.add("selected");
    }

    const mini = document.createElement("div");
    mini.className = "mini-grid";

    piece.shape.forEach(([r,c]) => {
      const cell = document.createElement("div");

      cell.className = "mini-cell";
      cell.style.gridRow = r + 1;
      cell.style.gridColumn = c + 1;
      cell.style.background = piece.color;

      cell.dataset.row = r;
      cell.dataset.col = c;

      mini.appendChild(cell);
    });

    slot.appendChild(mini);

    slot.addEventListener("pointerdown", e => {
      if (!gameActive || !pieces[index]) return;

      e.preventDefault();

      const touched = e.target.closest(".mini-cell");

      dragging = {
        index,
        startX: e.clientX,
        startY: e.clientY,
        moved: false,
        grabRow: touched ? Number(touched.dataset.row) : 0,
        grabCol: touched ? Number(touched.dataset.col) : 0
      };

      selected = index;

      latestPointer = {
        x: e.clientX,
        y: e.clientY
      };

      try {
        slot.setPointerCapture(e.pointerId);
      } catch (err) {}

      slot.classList.add("selected");
    });

    slot.addEventListener("click", () => {
      if (dragging || !gameActive) return;

      selected = index;
      renderPieces();
      playSound(350);
    });

    piecesEl.appendChild(slot);
  });
}

// ==========================================
// POSITION CHECK
// ==========================================

function canPlace(shape, row, col) {
  return shape.every(([r,c]) => {
    const y = row + r;
    const x = col + c;

    return (
      y >= 0 && y < SIZE &&
      x >= 0 && x < SIZE &&
      board[y][x] === null
    );
  });
}

function getBoardMetrics() {
  const style = getComputedStyle(boardEl);
  const rect = boardEl.getBoundingClientRect();

  const pl = parseFloat(style.paddingLeft) || 0;
  const pr = parseFloat(style.paddingRight) || 0;
  const pt = parseFloat(style.paddingTop) || 0;
  const pb = parseFloat(style.paddingBottom) || 0;

  const gx = parseFloat(style.columnGap) || 0;
  const gy = parseFloat(style.rowGap) || 0;

  const width = boardEl.clientWidth - pl - pr;
  const height = boardEl.clientHeight - pt - pb;

  const cw = (width - gx * 7) / 8;
  const ch = (height - gy * 7) / 8;

  return {
    left: rect.left + boardEl.clientLeft + pl,
    top: rect.top + boardEl.clientTop + pt,
    cw, ch,
    gx, gy,
    sx: cw + gx,
    sy: ch + gy,
    width,
    height
  };
}

function getBoardPosition(x, y, metrics) {
  const m = metrics || getBoardMetrics();

  const col = Math.floor((x - m.left) / m.sx);
  const row = Math.floor((y - m.top) / m.sy);

  return {
    row,
    col,
    inside:
      x >= m.left &&
      x < m.left + m.width &&
      y >= m.top &&
      y < m.top + m.height
  };
}

// ==========================================
// FLOATING DRAG BLOCK
// ==========================================

function createGhost(x, y) {
  removeGhost();

  const piece = pieces[dragging.index];
  if (!piece) return;

  const m = getBoardMetrics();

  const maxR = Math.max(...piece.shape.map(p => p[0]));
  const maxC = Math.max(...piece.shape.map(p => p[1]));

  const ghost = document.createElement("div");

  ghost.className = "drag-ghost";

  ghost.style.gridTemplateColumns =
    `repeat(${maxC + 1}, ${m.cw}px)`;

  ghost.style.gridTemplateRows =
    `repeat(${maxR + 1}, ${m.ch}px)`;

  ghost.style.columnGap = m.gx + "px";
  ghost.style.rowGap = m.gy + "px";

  piece.shape.forEach(([r,c]) => {
    const block = document.createElement("div");

    block.className = "drag-ghost-cell";
    block.style.gridRow = r + 1;
    block.style.gridColumn = c + 1;
    block.style.background = piece.color;

    ghost.appendChild(block);
  });

  document.body.appendChild(ghost);

  dragGhost = ghost;
  moveGhost(x, y, m);
}

function moveGhost(x, y, metrics) {
  if (!dragGhost || !dragging) return;

  const m = metrics || getBoardMetrics();

  const offsetX =
    dragging.grabCol * m.sx + m.cw / 2;

  const offsetY =
    dragging.grabRow * m.sy + m.ch / 2;

  dragGhost.style.transform =
    `translate3d(${x - offsetX}px, ${y - offsetY}px, 0)`;
}

function removeGhost() {
  if (dragGhost) {
    dragGhost.remove();
    dragGhost = null;
  }
}

// ==========================================
// PREVIEW
// ==========================================

function clearPreview() {
  previewCells.forEach(cell => {
    cell.classList.remove("preview", "invalid");
  });

  previewCells = [];
  dragPreview = null;
}

function updatePreview(x, y, metrics) {
  clearPreview();

  if (!dragging) return;

  const pos = getBoardPosition(x, y, metrics);

  if (!pos.inside) return;

  const piece = pieces[dragging.index];
  if (!piece) return;

  const row = pos.row - dragging.grabRow;
  const col = pos.col - dragging.grabCol;

  const valid = canPlace(piece.shape, row, col);

  piece.shape.forEach(([r,c]) => {
    const rr = row + r;
    const cc = col + c;

    if (
      rr < 0 || rr >= SIZE ||
      cc < 0 || cc >= SIZE
    ) return;

    const cell = boardEl.children[rr * SIZE + cc];

    if (!cell) return;

    cell.classList.add(valid ? "preview" : "invalid");
    previewCells.push(cell);
  });

  dragPreview = { row, col, valid };
}

// ==========================================
// ANIMATION FRAME
// ==========================================

function animateDrag() {
  dragFrame = null;

  if (!dragging || !latestPointer) return;

  const { x, y } = latestPointer;
  // Read layout once per animation frame instead of once per drag sub-operation.
  const metrics = getBoardMetrics();
  moveGhost(x, y, metrics);
  updatePreview(x, y, metrics);
}

// ==========================================
// POINTER MOVE
// ==========================================

document.addEventListener("pointermove", e => {
  if (!dragging) return;

  e.preventDefault();

  const distance = Math.hypot(
    e.clientX - dragging.startX,
    e.clientY - dragging.startY
  );

  if (distance > 3 && !dragging.moved) {
    dragging.moved = true;
    createGhost(e.clientX, e.clientY);
  }

  if (!dragging.moved) return;

  latestPointer = {
    x: e.clientX,
    y: e.clientY
  };

  if (dragFrame === null) {
    dragFrame = requestAnimationFrame(animateDrag);
  }

}, { passive: false });

// ==========================================
// POINTER UP
// ==========================================

document.addEventListener("pointerup", e => {
  if (!dragging) return;

  const drag = dragging;

  const metrics = getBoardMetrics();
  if (drag.moved) {
    moveGhost(e.clientX, e.clientY, metrics);
    updatePreview(e.clientX, e.clientY, metrics);
  }

  const result = dragPreview;
  const pos = getBoardPosition(e.clientX, e.clientY, metrics);

  dragging = null;

  if (dragFrame !== null) {
    cancelAnimationFrame(dragFrame);
    dragFrame = null;
  }

  removeGhost();
  clearPreview();

  if (!drag.moved) {
    selected = drag.index;
    renderPieces();
    playSound(350);
    return;
  }

  if (!pos.inside || !result || !result.valid) {
    renderPieces();
    playSound(150);
    return;
  }

  placePiece(drag.index, result.row, result.col);

});

document.addEventListener("pointercancel", () => {
  cancelDrag();
  renderPieces();
});

function cancelDrag() {
  dragging = null;
  latestPointer = null;

  if (dragFrame !== null) {
    cancelAnimationFrame(dragFrame);
    dragFrame = null;
  }

  removeGhost();
  clearPreview();
}

// ==========================================
// BOARD TAP
// ==========================================

boardEl.addEventListener("click", e => {
  const cell = e.target.closest(".cell");

  if (!cell || selected < 0 || !gameActive) return;

  placePiece(
    selected,
    Number(cell.dataset.row),
    Number(cell.dataset.col)
  );
});

// ==========================================
// PLACE BLOCK
// ==========================================

function placePiece(index, row, col) {
  if (!gameActive || !pieces[index]) return;

  const piece = pieces[index];

  if (!canPlace(piece.shape, row, col)) {
    playSound(150);
    return;
  }

  piece.shape.forEach(([r,c]) => {
    board[row+r][col+c] = piece.color;
  });

  score += piece.shape.length;

  pieces[index] = null;
  selected = -1;

  playSound(500);

  clearLines();
  updateScore();
  renderBoard();
  renderPieces();

  if (pieces.every(p => p === null)) {
    generatePieces();
  }

  if (!hasMove()) {
    endGame();
  }
}

// ==========================================
// CLEAR LINES
// ==========================================

function clearLines() {
  const rows = [];
  const cols = [];

  for (let r = 0; r < SIZE; r++) {
    if (board[r].every(v => v !== null)) {
      rows.push(r);
    }
  }

  for (let c = 0; c < SIZE; c++) {
    if (board.every(row => row[c] !== null)) {
      cols.push(c);
    }
  }

  const clear = new Set();

  rows.forEach(r => {
    for (let c = 0; c < SIZE; c++) {
      clear.add(r * SIZE + c);
    }
  });

  cols.forEach(c => {
    for (let r = 0; r < SIZE; r++) {
      clear.add(r * SIZE + c);
    }
  });

  if (!clear.size) return;

  clear.forEach(i => {
    const r = Math.floor(i / SIZE);
    const c = i % SIZE;

    board[r][c] = null;
  });

  score += clear.size +
    rows.length * 10 +
    cols.length * 10;

  playSound(800);
}

// ==========================================
// CHECK MOVES
// ==========================================

function hasMove() {
  for (const piece of pieces) {
    if (!piece) continue;

    for (let r = 0; r < SIZE; r++) {
      for (let c = 0; c < SIZE; c++) {
        if (canPlace(piece.shape, r, c)) {
          return true;
        }
      }
    }
  }

  return false;
}

// ==========================================
// SCORE
// ==========================================

function updateScore() {
  $("score").textContent = score;

  if (score > best) {
    best = score;

    localStorage.setItem("bm_best", best);
    $("bestScore").textContent = best;
  }
}

// ==========================================
// GAME OVER
// ==========================================

function endGame() {
  gameActive = false;

  $("finalScore").textContent = score;
  $("gameOver").classList.remove("hidden");

  playSound(180);
}

// ==========================================
// RESET
// ==========================================

function resetGame() {
  cancelDrag();

  score = 0;
  selected = -1;
  gameActive = true;

  $("score").textContent = "0";
  $("bestScore").textContent = best;
  $("gameOver").classList.add("hidden");

  createBoard();
  generatePieces();
}

// ==========================================
// INITIALIZE
// ==========================================

$("restartBtn").onclick = resetGame;
$("playAgain").onclick = resetGame;

$("streak").textContent =
  localStorage.getItem("bm_streak") || "0";

