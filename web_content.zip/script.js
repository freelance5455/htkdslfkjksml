const output = document.getElementById('output');
const keysBox = document.getElementById('keys');
const statusEl = document.getElementById('status');
const langBtn = document.getElementById('langBtn');
const shiftBtn = document.getElementById('shiftBtn');
const clipboardPanel = document.getElementById('clipboardPanel');
const clipItems = document.getElementById('clipItems');
const systemKeyboardToggle = document.getElementById('systemKeyboardToggle');

let lang = 'ar';
let shifted = false;
let symbols = false;
let clips = readSaved('zizal_clips', []);
let theme = Number(readSaved('zizal_theme', 0)) || 0;
let savedStart = 0;
let savedEnd = 0;

const layouts = {
  ar: ['ض ص ث ق ف غ ع ه خ ح ج', 'ش س ي ب ل ا ت ن م ك ط', 'ئ ء ؤ ر لا ى ة و ز ظ د'],
  en: ['q w e r t y u i o p', 'a s d f g h j k l', 'z x c v b n m']
};
const symbolsLayout = ['1 2 3 4 5 6 7 8 9 0', '@ # $ % & - + ( ) /', '* " : ; ! ? \' _ ='];
const themes = [
  ['#101827', '#1b2940', '#293a55', '#354966', '#4f8cff'],
  ['#24152f', '#392044', '#56345f', '#70477a', '#d17bd7'],
  ['#102c2a', '#17433e', '#245c54', '#32766b', '#4cc9a6'],
  ['#252525', '#353535', '#484848', '#5a5a5a', '#e0a84b']
];

function readSaved(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value === null ? fallback : JSON.parse(value);
  } catch (_) {
    return fallback;
  }
}
function saveValue(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
}
function updateStatus(message) { statusEl.textContent = message; }

function rememberCaret() {
  savedStart = output.selectionStart ?? output.value.length;
  savedEnd = output.selectionEnd ?? savedStart;
}
function insertText(text) {
  const start = Math.min(savedStart, output.value.length);
  const end = Math.min(Math.max(savedEnd, start), output.value.length);
  output.focus({ preventScroll: true });
  output.setRangeText(text, start, end, 'end');
  rememberCaret();
  updateStatus('تمت الكتابة');
}
function backspace() {
  let start = Math.min(savedStart, output.value.length);
  let end = Math.min(Math.max(savedEnd, start), output.value.length);
  if (start === end && start > 0) {
    // حذف وحدة Unicode كاملة، بما فيها الحروف المركبة والرموز التعبيرية.
    const before = Array.from(output.value.slice(0, start));
    const previous = before.pop() || '';
    start -= previous.length;
  }
  output.focus({ preventScroll: true });
  output.setRangeText('', start, end, 'end');
  rememberCaret();
}
function renderKeys() {
  keysBox.innerHTML = '';
  const rows = symbols ? symbolsLayout : layouts[lang];
  rows.forEach(line => {
    const row = document.createElement('div');
    row.className = 'key-row';
    line.split(' ').forEach(character => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'key';
      button.textContent = (lang === 'en' && shifted && !symbols)
        ? character.toUpperCase() : character;
      button.setAttribute('aria-label', `كتابة ${button.textContent}`);
      // منع فقدان موضع المؤشر عند لمس الزر على الهاتف.
      button.addEventListener('pointerdown', event => event.preventDefault());
      button.addEventListener('click', () => insertText(button.textContent));
      row.appendChild(button);
    });
    keysBox.appendChild(row);
  });
}
function applyTheme(index) {
  theme = ((index % themes.length) + themes.length) % themes.length;
  const [bg, panel, key, key2, accent] = themes[theme];
  const root = document.documentElement;
  root.style.setProperty('--bg', bg);
  root.style.setProperty('--panel', panel);
  root.style.setProperty('--key', key);
  root.style.setProperty('--key2', key2);
  root.style.setProperty('--accent', accent);
  document.body.style.background = `radial-gradient(circle at top,${key2},${bg} 62%)`;
  saveValue('zizal_theme', theme);
}
function renderClips() {
  clipItems.innerHTML = '';
  if (!clips.length) {
    const empty = document.createElement('span');
    empty.className = 'empty';
    empty.textContent = 'لا توجد عناصر منسوخة بعد';
    clipItems.appendChild(empty);
    return;
  }
  clips.forEach(text => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'clip-item';
    button.textContent = text.length > 90 ? text.slice(0, 90) + '…' : text;
    button.addEventListener('pointerdown', event => event.preventDefault());
    button.addEventListener('click', () => insertText(text));
    clipItems.appendChild(button);
  });
}
async function copyText() {
  const text = output.value;
  if (!text) { updateStatus('لا يوجد نص لنسخه'); return; }
  try {
    await navigator.clipboard.writeText(text);
  } catch (_) {
    output.focus();
    output.select();
    try { document.execCommand('copy'); } catch (_) {}
    output.setSelectionRange(savedStart, savedEnd);
  }
  clips = [text, ...clips.filter(item => item !== text)].slice(0, 15);
  saveValue('zizal_clips', clips);
  renderClips();
  updateStatus('تم نسخ النص وحفظه في سجل الحافظة');
}
async function pasteText() {
  try {
    const text = await navigator.clipboard.readText();
    if (text) insertText(text);
    else updateStatus('الحافظة فارغة');
  } catch (_) {
    updateStatus('تعذرت قراءة الحافظة. استخدم لصق الهاتف أو فعّل إذن الحافظة.');
  }
}

langBtn.addEventListener('click', () => {
  lang = lang === 'ar' ? 'en' : 'ar';
  symbols = false;
  langBtn.textContent = lang === 'ar' ? 'English' : 'العربية';
  shiftBtn.textContent = lang === 'en' ? (shifted ? '⇧ ABC' : '⇧ abc') : '⇧ ABC';
  renderKeys();
});
shiftBtn.addEventListener('click', () => {
  if (lang !== 'en') { updateStatus('اختر الإنجليزية لتبديل حالة الأحرف'); return; }
  shifted = !shifted;
  shiftBtn.textContent = shifted ? '⇧ ABC' : '⇧ abc';
  renderKeys();
});
document.getElementById('backspaceBtn').addEventListener('click', backspace);
document.getElementById('spaceBtn').addEventListener('click', () => insertText(' '));
document.getElementById('enterBtn').addEventListener('click', () => insertText('\n'));
document.getElementById('commaBtn').addEventListener('click', () => insertText(lang === 'ar' ? '،' : ','));
document.getElementById('periodBtn').addEventListener('click', () => insertText('.'));
document.getElementById('copyBtn').addEventListener('click', copyText);
document.getElementById('pasteBtn').addEventListener('click', pasteText);
document.getElementById('clearBtn').addEventListener('click', () => {
  output.value = '';
  savedStart = savedEnd = 0;
  output.focus({ preventScroll: true });
  updateStatus('تم مسح النص');
});
document.getElementById('clipboardBtn').addEventListener('click', () => {
  clipboardPanel.classList.toggle('hidden');
});
document.getElementById('clearClipsBtn').addEventListener('click', () => {
  clips = [];
  saveValue('zizal_clips', clips);
  renderClips();
  updateStatus('تم مسح سجل الحافظة');
});
document.getElementById('symbolsBtn').addEventListener('click', () => {
  symbols = !symbols;
  renderKeys();
});
document.getElementById('themeBtn').addEventListener('click', () => applyTheme(theme + 1));

systemKeyboardToggle.addEventListener('change', () => {
  output.setAttribute('inputmode', systemKeyboardToggle.checked ? 'text' : 'none');
  updateStatus(systemKeyboardToggle.checked
    ? 'لوحة الهاتف الأصلية مفعّلة'
    : 'الكتابة من لوحة الصفحة مفعّلة');
});
output.setAttribute('inputmode', 'none');
output.addEventListener('select', rememberCaret);
output.addEventListener('keyup', rememberCaret);
output.addEventListener('click', rememberCaret);
output.addEventListener('input', rememberCaret);
output.addEventListener('blur', rememberCaret);

applyTheme(theme);
renderKeys();
renderClips();
rememberCaret();
