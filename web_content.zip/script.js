
const expressionDisplay = document.getElementById("expression");
const resultDisplay = document.getElementById("result");
const keypad = document.querySelector(".keypad");
const historyPanel = document.getElementById("history-panel");
const historyList = document.getElementById("history-list");
const emptyHistory = document.getElementById("empty-history");

let expression = "";
let justCalculated = false;
let history = [];

try {
    const saved = JSON.parse(localStorage.getItem("calculator-history") || "[]");
    if (Array.isArray(saved)) history = saved.slice(0, 30);
} catch {
    history = [];
}

function pretty(text) {
    return text.replace(/\*/g, "×").replace(/\//g, "÷");
}

// Parse arithmetic safely without eval() or Function().
function calculate(source) {
    const tokens = source.match(
        /(?:\d+\.?\d*|\.\d+)|[+\-*/()]|\s+/g
    );

    if (!tokens || tokens.join("").replace(/\s/g, "") !== source.replace(/\s/g, "")) {
        throw new Error("Invalid expression");
    }

    const list = tokens.filter(token => !/^\s+$/.test(token));
    let position = 0;

    function primary() {
        const token = list[position];

        if (token === "+" || token === "-") {
            position++;
            const value = primary();
            return token === "-" ? -value : value;
        }

        if (token === "(") {
            position++;
            const value = addSub();
            if (list[position] !== ")") throw new Error("Missing )");
            position++;
            return value;
        }

        if (token && /^\d*\.?\d+$/.test(token)) {
            position++;
            return Number(token);
        }

        throw new Error("Invalid expression");
    }

    function multiplyDivide() {
        let value = primary();

        while (list[position] === "*" || list[position] === "/") {
            const operator = list[position++];
            const right = primary();

            if (operator === "/" && right === 0) {
                throw new Error("Cannot divide by zero");
            }

            value = operator === "*" ? value * right : value / right;
        }

        return value;
    }

    function addSub() {
        let value = multiplyDivide();

        while (list[position] === "+" || list[position] === "-") {
            const operator = list[position++];
            const right = multiplyDivide();
            value = operator === "+" ? value + right : value - right;
        }

        return value;
    }

    if (!list.length) throw new Error("Empty expression");

    const answer = addSub();

    if (position !== list.length || !Number.isFinite(answer)) {
        throw new Error("Invalid calculation");
    }

    return Number(answer.toPrecision(12));
}

function format(value) {
    return String(value);
}

function updateDisplay() {
    expressionDisplay.textContent = pretty(expression);

    if (!expression) {
        resultDisplay.textContent = "0";
        return;
    }

    try {
        // Allow an unfinished expression while typing.
        const answer = calculate(expression);
        resultDisplay.textContent = format(answer);
    } catch {
        resultDisplay.textContent = "…";
    }
}

function append(value) {
    if (justCalculated && /[\d.(]/.test(value)) {
        expression = "";
    }

    justCalculated = false;

    if (/^[+\-*/]$/.test(value)) {
        if (!expression) {
            if (value !== "-") return;
        } else if (/[+\-*/.]$/.test(expression)) {
            if (value === "-" && /[*/+]$/.test(expression)) {
                expression += value;
                updateDisplay();
                return;
            }

            expression = expression.slice(0, -1);
        }
    }

    if (/^\d$/.test(value)) {
        const current = expression.split(/[+\-*/()]/).pop();

        if (current === "0") {
            expression = expression.slice(0, -1) + value;
            updateDisplay();
            return;
        }
    }

    if (value === ".") {
        const current = expression.split(/[+\-*/()]/).pop();
        if (current.includes(".")) return;
        if (!current) expression += "0";
    }

    expression += value;
    updateDisplay();
}

function clearAll() {
    expression = "";
    justCalculated = false;
    updateDisplay();
}

function deleteLast() {
    expression = expression.slice(0, -1);
    justCalculated = false;
    updateDisplay();
}

function toggleSign() {
    const match = expression.match(/(\d*\.?\d+)$/);

    if (match) {
        const start = match.index;
        const before = expression.slice(0, start);
        const number = match[0];

        if (before.endsWith("-") &&
            (before.length === 1 || /[+\-*/(]$/.test(before.slice(0, -1)))) {
            expression = before.slice(0, -1) + number;
        } else {
            expression = before + "(-" + number + ")";
        }
    } else if (!expression) {
        expression = "-";
    }

    justCalculated = false;
    updateDisplay();
}

function percent() {
    const match = expression.match(/(\d*\.?\d+)$/);
    if (!match) return;

    const start = match.index;
    const number = Number(match[0]) / 100;
    expression = expression.slice(0, start) + format(number);

    justCalculated = false;
    updateDisplay();
}

function saveHistory(source, answer) {
    history.unshift({ source, answer });
    history = history.slice(0, 30);

    try {
        localStorage.setItem("calculator-history", JSON.stringify(history));
    } catch {
        // Calculator still works if browser storage is unavailable.
    }

    renderHistory();
}

function equals() {
    if (!expression) return;

    try {
        const source = expression;
        const answer = calculate(source);

        saveHistory(pretty(source), format(answer));

        expressionDisplay.textContent = pretty(source) + " =";
        resultDisplay.textContent = format(answer);
        expression = format(answer);
        justCalculated = true;
    } catch (error) {
        resultDisplay.textContent = error.message === "Cannot divide by zero"
            ? "Cannot divide by zero"
            : "Invalid expression";
        justCalculated = false;
    }
}

function renderHistory() {
    historyList.replaceChildren();
    emptyHistory.hidden = history.length > 0;

    history.forEach(item => {
        const li = document.createElement("li");
        li.append(document.createTextNode(item.source));

        const answer = document.createElement("span");
        answer.textContent = "= " + item.answer;
        li.append(answer);

        li.addEventListener("click", () => {
            expression = item.answer;
            justCalculated = true;
            updateDisplay();
            historyPanel.hidden = true;
        });

        historyList.append(li);
    });
}

keypad.addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button) return;

    if (button.dataset.value !== undefined) {
        append(button.dataset.value);
        return;
    }

    switch (button.dataset.action) {
        case "clear": clearAll(); break;
        case "delete": deleteLast(); break;
        case "decimal": append("."); break;
        case "sign": toggleSign(); break;
        case "percent": percent(); break;
        case "equals": equals(); break;
    }
});

document.getElementById("history-toggle").addEventListener("click", () => {
    historyPanel.hidden = !historyPanel.hidden;
    renderHistory();
});

document.getElementById("clear-history").addEventListener("click", () => {
    history = [];
    try {
        localStorage.removeItem("calculator-history");
    } catch {}
    renderHistory();
});

document.addEventListener("keydown", event => {
    if (/^\d$/.test(event.key)) append(event.key);
    else if (["+", "-", "*", "/"].includes(event.key)) append(event.key);
    else if (event.key === ".") append(".");
    else if (event.key === "Enter" || event.key === "=") {
        event.preventDefault();
        equals();
    } else if (event.key === "Backspace") deleteLast();
    else if (event.key === "Escape") clearAll();
    else if (event.key === "%") percent();
});

renderHistory();
updateDisplay();

