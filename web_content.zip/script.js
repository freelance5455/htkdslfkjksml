let completed = 0;

function showPage(pageId, element) {
  document.querySelectorAll(".page").forEach(page => page.classList.remove("active-page"));
  const page = document.getElementById(pageId);
  if (page) page.classList.add("active-page");

  document.querySelectorAll(".nav-item").forEach(item => item.classList.remove("active"));
  if (element) element.classList.add("active");
}

function completeHabit(element) {
  if (!element) return;

  if (element.classList.contains("completed")) {
    element.classList.remove("completed");
    completed = Math.max(0, completed - 1);
  } else {
    element.classList.add("completed");
    completed++;
  }

  updateProgress();
}

function updateProgress() {
  const total = document.querySelectorAll(".habit").length || 4;
  const percentage = Math.round((completed / total) * 100);

  const progressText = document.getElementById("progressText");
  const completedCount = document.getElementById("completedCount");
  const streak = document.getElementById("streak");

  if (progressText) progressText.textContent = percentage + "%";
  if (completedCount) completedCount.textContent = completed;
  if (streak) streak.textContent = completed;
}

function toggleDarkMode() {
  document.body.classList.toggle("dark");
  localStorage.setItem(
    "vidaFitDarkMode",
    document.body.classList.contains("dark") ? "true" : "false"
  );
}

function showAbout() {
  alert("VidaFit\n\nVersão 2.0\n\nUma aplicação para acompanhar hábitos saudáveis.");
}

function resetApp() {
  document.querySelectorAll(".habit").forEach(habit => habit.classList.remove("completed"));
  completed = 0;
  updateProgress();
  alert("O progresso de hoje foi reiniciado!");
}

document.addEventListener("DOMContentLoaded", () => {
  if (localStorage.getItem("vidaFitDarkMode") === "true") {
    document.body.classList.add("dark");
  }
  updateProgress();
});