const $ = id => document.getElementById(id);
const cv = $('game'), ctx = cv.getContext('2d');
const hpEl = $('hp'), scoreEl = $('score'), bestEl = $('best'), waveEl = $('wave');
const overlay = $('overlay'), titleEl = $('title'), msgEl = $('msg'), startBtn = $('start');
const stick = $('stick'), knob = $('knob'), fireBtn = $('fire');
const pauseBtn = $('pause'), sndBtn = $('snd'), rotBtn = $('rot'), noteEl = $('note');

let W, H, p;
function resize() {
  W = cv.width = innerWidth; H = cv.height = innerHeight;
  if (p) { p.x = Math.min(W - p.r, p.x); p.y = Math.min(H - p.r, p.y); }
}
addEventListener('resize', resize);
resize();

// ---------- आवाज़ें (कोड से बनी) ----------
let audioCtx = null, soundOn = true;
try { soundOn = localStorage.getItem('jsSound') !== '0'; } catch (e) {}
sndBtn.textContent = soundOn ? '🔊' : '🔇';

function ac() {
  if (!audioCtx) {
    const A = window.AudioContext || window.webkitAudioContext;
    if (A) audioCtx = new A();
  }
  if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
  return audioCtx;
}
function beep(freq, dur, type, vol, slide) {
  if (!soundOn) return;
  const a = ac(); if (!a) return;
  const o = a.createOscillator(), g = a.createGain(), t = a.currentTime;
  o.type = type;
  o.frequency.setValueAtTime(freq, t);
  if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq * slide), t + dur);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g); g.connect(a.destination);
  o.start(t); o.stop(t + dur);
}
const sfx = {
  shoot:   () => beep(520, 0.08, 'square', 0.04, 0.5),
  shotgun: () => beep(180, 0.18, 'sawtooth', 0.09, 0.4),
  hit:     () => beep(240, 0.06, 'sawtooth', 0.05, 0.6),
  kill:    () => beep(170, 0.2, 'sawtooth', 0.09, 0.3),
  hurt:    () => beep(120, 0.25, 'square', 0.12, 0.5),
  pick:    () => { beep(600, 0.1, 'sine', 0.1); setTimeout(() => beep(900, 0.12, 'sine', 0.1), 80); },
  wave:    () => beep(440, 0.3, 'triangle', 0.1, 1.5),
  efire:   () => beep(330, 0.1, 'triangle', 0.05, 0.6),
  over:    () => beep(300, 0.8, 'sawtooth', 0.12, 0.15)
};

// ---------- इनपुट ----------
const keys = {};
addEventListener('keydown', e => {
  const k = e.key.toLowerCase();
  keys[k] = true;
  if (k === 'p' && running && !choosing) pauseGame();
  if (choosing && (k === '1' || k === '2' || k === '3')) choose(+k - 1);
});
addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; });

const joy = { x: 0, y: 0 };
let stickActive = false, firing = false;
const STICK_MAX = 45;

function moveStick(e) {
  const r = stick.getBoundingClientRect();
  let dx = e.clientX - (r.left + r.width / 2);
  let dy = e.clientY - (r.top + r.height / 2);
  const len = Math.hypot(dx, dy);
  if (len > STICK_MAX) { dx = dx / len * STICK_MAX; dy = dy / len * STICK_MAX; }
  joy.x = dx / STICK_MAX; joy.y = dy / STICK_MAX;
  knob.style.transform = `translate(${dx}px, ${dy}px)`;
}
function releaseStick() {
  stickActive = false; joy.x = 0; joy.y = 0;
  knob.style.transform = 'translate(0, 0)';
}
stick.addEventListener('pointerdown', e => { stickActive = true; stick.setPointerCapture(e.pointerId); moveStick(e); });
stick.addEventListener('pointermove', e => { if (stickActive) moveStick(e); });
stick.addEventListener('pointerup', releaseStick);
stick.addEventListener('pointercancel', releaseStick);
fireBtn.addEventListener('pointerdown', e => { firing = true; fireBtn.setPointerCapture(e.pointerId); });
fireBtn.addEventListener('pointerup', () => { firing = false; });
fireBtn.addEventListener('pointercancel', () => { firing = false; });

// ---------- नोट, आवाज़ और लैंडस्केप बटन ----------
let noteTimer;
function note(text) {
  noteEl.textContent = text;
  noteEl.classList.add('show');
  clearTimeout(noteTimer);
  noteTimer = setTimeout(() => noteEl.classList.remove('show'), 3500);
}

sndBtn.addEventListener('click', () => {
  soundOn = !soundOn;
  sndBtn.textContent = soundOn ? '🔊' : '🔇';
  try { localStorage.setItem('jsSound', soundOn ? '1' : '0'); } catch (e) {}
  if (soundOn) sfx.pick();
});

rotBtn.addEventListener('click', async () => {
  try {
    if (!document.fullscreenElement) {
      await document.documentElement.requestFullscreen();
      if (screen.orientation && screen.orientation.lock) await screen.orientation.lock('landscape');
      else note('फ़ोन को घुमाइए, गेम लैंडस्केप में चलेगा।');
    } else {
      if (screen.orientation && screen.orientation.unlock) screen.orientation.unlock();
      await document.exitFullscreen();
    }
  } catch (e) {
    note('यहाँ लॉक नहीं हो पाया। फ़ोन का ऑटो-रोटेट चालू करके फ़ोन को घुमाइए।');
  }
});

// ---------- डेटा ----------
const GUNS = {
  pistol:  { rate: 0.2,  n: 1, sp: 0.04, life: 1.2 },
  shotgun: { rate: 0.7,  n: 5, sp: 0.5,  life: 0.45 },
  machine: { rate: 0.08, n: 1, sp: 0.1,  life: 1.0 }
};
const TYPES = {
  normal:  { r: 15, hp: 2,  sp: 1,   col: '#b8342a', pts: 10,  dmg: 10 },
  fast:    { r: 11, hp: 1,  sp: 1.8, col: '#e8a23c', pts: 15,  dmg: 8 },
  tank:    { r: 22, hp: 6,  sp: 0.6, col: '#6b2a5c', pts: 30,  dmg: 15 },
  shooter: { r: 13, hp: 3,  sp: 0.8, col: '#2a7ea8', pts: 25,  dmg: 8 },
  charger: { r: 17, hp: 4,  sp: 0.7, col: '#8a5a2b', pts: 30,  dmg: 16 },
  boss:    { r: 38, hp: 40, sp: 0.5, col: '#241a1a', pts: 200, dmg: 25 }
};
const DROPS = {
  hp:   { col: '#3fae5a', t: '+' },
  spd:  { col: '#3b8ee0', t: 'S' },
  shot: { col: '#e8643c', t: 'P' },
  mg:   { col: '#e8c93c', t: 'M' }
};
const UPG = {
  dmg:    { n: 'ज़्यादा ताक़त',    d: 'हर गोली +1 नुक़सान',        max: 4 },
  rate:   { n: 'तेज़ फ़ायर',       d: 'गोलियाँ 12% जल्दी',          max: 4 },
  spd:    { n: 'तेज़ चाल',         d: 'चलने की रफ़्तार +10%',       max: 4 },
  hp:     { n: 'ज़्यादा हेल्थ',    d: 'अधिकतम हेल्थ +25, और भरें',   max: 4 },
  heal:   { n: 'पूरा इलाज',        d: 'हेल्थ पूरी भर जाएगी',        max: 99 },
  multi:  { n: 'एक्स्ट्रा गोली',   d: 'एक बार में एक और गोली',      max: 2 },
  pierce: { n: 'आर-पार गोली',      d: 'गोली एक और दुश्मन के पार',   max: 2 },
  regen:  { n: 'धीरे-धीरे इलाज',   d: 'हर सेकंड हेल्थ +0.6',        max: 2 }
};

let best = 0;
try { best = +localStorage.getItem('jsBest') || 0; } catch (e) {}
function saveBest() {
  if (score > best) { best = score; try { localStorage.setItem('jsBest', best); } catch (e) {} }
}

// ---------- स्थिति ----------
let enemies, bullets, ebullets, drops, parts, score, wave, toSpawn, spawned, wait, bossPending, bannerT, shake;
let running = false, paused = false, last = 0, spawnT, shootT, time;
let choosing = false, cards = [], cardRects = [], lv = {};
const waveSize = w => 6 + w * 4;
const hpMult = w => 1 + w * 0.07 + w * w * 0.002;
const dmgMult = w => Math.min(2, 1 + w * 0.02);

function reset() {
  p = {
    x: W / 2, y: H / 2, r: 16, hp: 100, maxHp: 100, dx: 0, dy: -1, hurt: 0, spdT: 0,
    gun: 'pistol', gunT: 0, flash: 0,
    dmg: 1, rateMul: 1, speedMul: 1, extra: 0, pierce: 0, regen: 0
  };
  enemies = []; bullets = []; ebullets = []; drops = []; parts = [];
  score = 0; wave = 1; toSpawn = waveSize(1); spawned = 0;
  wait = 1.5; bossPending = false; bannerT = 2.5; shake = 0;
  spawnT = 0; shootT = 0; time = 0;
  choosing = false; cards = []; lv = {};
  updateHud();
}

function updateHud() {
  hpEl.style.width = Math.max(0, p.hp / p.maxHp * 100) + '%';
  scoreEl.textContent = 'स्कोर: ' + score;
  bestEl.textContent = 'सर्वश्रेष्ठ: ' + Math.max(best, score);
  waveEl.textContent = 'लहर ' + wave;
}

function burst(x, y, col, n, speed) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2, s = (0.3 + Math.random() * 0.7) * speed;
    const life = 0.3 + Math.random() * 0.4;
    parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life, max: life, col, r: 2 + Math.random() * 3 });
  }
}

function hurtPlayer(dmg) {
  p.hp -= dmg; p.hurt = 0.5; shake = 9;
  sfx.hurt(); burst(p.x, p.y, '#f2e3b8', 6, 140);
  updateHud();
}

function spawnEnemy(forceType) {
  let type = forceType;
  if (!type) {
    const r = Math.random();
    if (wave >= 7 && r < 0.10) type = 'charger';
    else if (wave >= 4 && r < 0.24) type = 'shooter';
    else if (wave >= 3 && r < 0.36) type = 'tank';
    else if (wave >= 2 && r < 0.62) type = 'fast';
    else type = 'normal';
  }
  const t = TYPES[type];
  const side = Math.floor(Math.random() * 4), m = 50;
  let x, y;
  if (side === 0) { x = Math.random() * W; y = -m; }
  else if (side === 1) { x = W + m; y = Math.random() * H; }
  else if (side === 2) { x = Math.random() * W; y = H + m; }
  else { x = -m; y = Math.random() * H; }

  let hp;
  if (type === 'boss') hp = Math.ceil((t.hp + wave * 6) * (1 + wave * 0.03));
  else hp = Math.ceil(t.hp * hpMult(wave));

  enemies.push({
    x, y, type, r: t.r, hp, max: hp,
    dmg: t.dmg * dmgMult(wave),
    cd: type === 'charger' ? 1.5 + Math.random() * 2 : (type === 'boss' ? 2.5 : 1 + Math.random()),
    state: '', wt: 0, dt2: 0, dirx: 0, diry: 0, rot: 0, inside: false
  });
}

function enemyShoot(e, ang, speed, dmg) {
  ebullets.push({ x: e.x, y: e.y, vx: Math.cos(ang) * speed, vy: Math.sin(ang) * speed, life: 4, dmg });
}

function nearestEnemy() {
  let bestE = null, bd = Infinity;
  for (const e of enemies) {
    const d = Math.hypot(e.x - p.x, e.y - p.y);
    if (d < bd) { bd = d; bestE = e; }
  }
  return bestE;
}

function dropItem(x, y, always) {
  if (!always && Math.random() > 0.12) return;
  const kinds = Object.keys(DROPS);
  drops.push({ x, y, kind: kinds[Math.floor(Math.random() * kinds.length)], life: 10 });
}

function pickUp(d) {
  if (d.kind === 'hp') p.hp = Math.min(p.maxHp, p.hp + 30);
  else if (d.kind === 'spd') p.spdT = 8;
  else { p.gun = d.kind === 'shot' ? 'shotgun' : 'machine'; p.gunT = 12; }
  sfx.pick();
  burst(d.x, d.y, DROPS[d.kind].col, 8, 120);
  updateHud();
}

// ---------- अपग्रेड ----------
function openChoice() {
  const pool = Object.keys(UPG).filter(k => (lv[k] || 0) < UPG[k].max);
  pool.sort(() => Math.random() - 0.5);
  cards = pool.slice(0, 3);
  if (!cards.length) { wait = 2; bannerT = 2.5; return; }
  choosing = true;
  firing = false;
}

function choose(i) {
  const k = cards[i];
  if (!k) return;
  lv[k] = (lv[k] || 0) + 1;
  if (k === 'dmg') p.dmg += 1;
  else if (k === 'rate') p.rateMul *= 0.88;
  else if (k === 'spd') p.speedMul *= 1.10;
  else if (k === 'hp') { p.maxHp += 25; p.hp = Math.min(p.maxHp, p.hp + 25); }
  else if (k === 'heal') p.hp = p.maxHp;
  else if (k === 'multi') p.extra += 1;
  else if (k === 'pierce') p.pierce += 1;
  else if (k === 'regen') p.regen += 0.6;
  sfx.pick();
  choosing = false;
  wait = 2; bannerT = 2.5;
  updateHud();
}

cv.addEventListener('pointerdown', e => {
  if (!choosing) return;
  for (let i = 0; i < cardRects.length; i++) {
    const r = cardRects[i];
    if (e.clientX >= r.x && e.clientX <= r.x + r.w && e.clientY >= r.y && e.clientY <= r.y + r.h) {
      choose(i);
      return;
    }
  }
});

function layoutCards() {
  cardRects = [];
  const n = cards.length;
  if (W > H * 1.15) {
    const w = Math.min(190, (W - 40) / 3), h = 120, gap = 12;
    const x0 = (W - (n * w + (n - 1) * gap)) / 2, y = H / 2 - h / 2 + 10;
    for (let i = 0; i < n; i++) cardRects.push({ x: x0 + i * (w + gap), y, w, h });
  } else {
    const w = Math.min(340, W - 40), h = 92, gap = 12;
    const y0 = H / 2 - (n * h + (n - 1) * gap) / 2 + 10, x = (W - w) / 2;
    for (let i = 0; i < n; i++) cardRects.push({ x, y: y0 + i * (h + gap), w, h });
  }
}

function drawCards() {
  layoutCards();
  ctx.fillStyle = 'rgba(20,32,18,.78)';
  ctx.fillRect(0, 0, W, H);
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  const top = cardRects.length ? cardRects[0].y : H / 2;
  ctx.fillStyle = '#fff7e0';
  ctx.font = 'bold 26px sans-serif';
  ctx.fillText('लहर पार! एक अपग्रेड चुनें', W / 2, Math.max(30, top - 30));
  cards.forEach((k, i) => {
    const r = cardRects[i], u = UPG[k], cx = r.x + r.w / 2;
    ctx.fillStyle = '#fff7e0';
    ctx.fillRect(r.x, r.y, r.w, r.h);
    ctx.strokeStyle = '#e8643c'; ctx.lineWidth = 3;
    ctx.strokeRect(r.x, r.y, r.w, r.h);
    ctx.fillStyle = '#2f4a2a'; ctx.font = 'bold 20px sans-serif';
    ctx.fillText(u.n, cx, r.y + r.h * 0.28, r.w - 16);
    ctx.fillStyle = '#4a4a3a'; ctx.font = '15px sans-serif';
    ctx.fillText(u.d, cx, r.y + r.h * 0.56, r.w - 16);
    if (k !== 'heal') {
      ctx.fillStyle = '#c74a24'; ctx.font = 'bold 14px sans-serif';
      ctx.fillText('स्तर ' + ((lv[k] || 0) + 1), cx, r.y + r.h * 0.82);
    }
  });
}

// ---------- अपडेट ----------
function update(dt) {
  time += dt;
  if (bannerT > 0) bannerT -= dt;
  if (shake > 0) shake = Math.max(0, shake - 40 * dt);
  if (p.flash > 0) p.flash -= dt;

  // इलाज (रीजेन)
  if (p.regen > 0 && p.hp < p.maxHp) {
    p.hp = Math.min(p.maxHp, p.hp + p.regen * dt);
    hpEl.style.width = (p.hp / p.maxHp * 100) + '%';
  }

  // चलना
  let ix = joy.x + (keys['d'] || keys['arrowright'] ? 1 : 0) - (keys['a'] || keys['arrowleft'] ? 1 : 0);
  let iy = joy.y + (keys['s'] || keys['arrowdown'] ? 1 : 0) - (keys['w'] || keys['arrowup'] ? 1 : 0);
  const il = Math.hypot(ix, iy);
  if (il > 1) { ix /= il; iy /= il; }
  if (il > 0.1) { p.dx = ix / Math.max(il, 1); p.dy = iy / Math.max(il, 1); }
  if (p.spdT > 0) p.spdT -= dt;
  const speed = (p.spdT > 0 ? 340 : 230) * p.speedMul;
  p.x = Math.min(W - p.r, Math.max(p.r, p.x + ix * speed * dt));
  p.y = Math.min(H - p.r, Math.max(p.r, p.y + iy * speed * dt));
  if (p.hurt > 0) p.hurt -= dt;
  if (p.gun !== 'pistol') { p.gunT -= dt; if (p.gunT <= 0) p.gun = 'pistol'; }

  // गोली चलाना
  shootT -= dt;
  if ((firing || keys[' ']) && shootT <= 0) {
    const g = GUNS[p.gun], t = nearestEnemy();
    let a = Math.atan2(p.dy, p.dx);
    if (t) a = Math.atan2(t.y - p.y, t.x - p.x);
    p.dx = Math.cos(a); p.dy = Math.sin(a);
    const n = g.n + p.extra;
    const spread = g.n > 1 ? g.sp : (n > 1 ? 0.14 : g.sp);
    for (let i = 0; i < n; i++) {
      const off = n > 1 ? (i / (n - 1) - 0.5) * spread : (Math.random() - 0.5) * spread;
      const ang = a + off;
      bullets.push({
        x: p.x, y: p.y, vx: Math.cos(ang) * 650, vy: Math.sin(ang) * 650,
        life: g.life, dmg: p.dmg, pierce: p.pierce, hit: []
      });
    }
    shootT = g.rate * p.rateMul;
    p.flash = 0.05;
    if (p.gun === 'shotgun') { sfx.shotgun(); shake = Math.max(shake, 3); } else sfx.shoot();
  }

  // लहरें
  if (wait > 0) {
    wait -= dt;
    if (wait <= 0 && bossPending) { spawnEnemy('boss'); bossPending = false; }
  } else if (spawned < toSpawn) {
    spawnT -= dt;
    if (spawnT <= 0) { spawnEnemy(); spawned++; spawnT = Math.max(0.18, 1 - wave * 0.05); }
  } else if (!enemies.length) {
    wave++; toSpawn = waveSize(wave); spawned = 0;
    bossPending = wave % 5 === 0;
    sfx.wave();
    updateHud();
    openChoice();
  }

  // दुश्मन
  const boost = Math.min(2.2, 1 + wave * 0.04);
  for (const e of enemies) {
    const t = TYPES[e.type];
    const d = Math.hypot(p.x - e.x, p.y - e.y) || 1;
    const ux = (p.x - e.x) / d, uy = (p.y - e.y) / d;
    let mx = ux, my = uy, s = 70 * t.sp * boost;

    if (e.type === 'shooter') {
      if (d < 180) { mx = -ux; my = -uy; }
      else if (d <= 260) s = 0;
      e.cd -= dt;
      if (e.cd <= 0 && d < 560) {
        enemyShoot(e, Math.atan2(uy, ux), 230 + wave * 3, 8 * dmgMult(wave));
        sfx.efire();
        e.cd = Math.max(1.1, 2.4 - wave * 0.03);
      }
    } else if (e.type === 'charger') {
      e.cd -= dt;
      if (e.state === 'wind') {
        s = 0; e.wt -= dt;
        if (e.wt <= 0) { e.state = 'dash'; e.dt2 = 0.5; e.dirx = ux; e.diry = uy; }
      } else if (e.state === 'dash') {
        mx = e.dirx; my = e.diry; s = 520;
        e.dt2 -= dt;
        if (e.dt2 <= 0) { e.state = ''; e.cd = 2.5 + Math.random() * 1.5; }
      } else if (e.cd <= 0 && d < 420) {
        e.state = 'wind'; e.wt = 0.6;
      }
    } else if (e.type === 'boss') {
      e.cd -= dt;
      if (e.cd <= 0) {
        const n = Math.min(16, 6 + Math.floor(wave / 5) * 2);
        for (let i = 0; i < n; i++) enemyShoot(e, e.rot + i / n * Math.PI * 2, 200 + wave * 2, 9 * dmgMult(wave));
        e.rot += 0.3;
        sfx.efire();
        e.cd = Math.max(1.6, 3.2 - wave * 0.03);
      }
    }

    e.x += mx * s * dt;
    e.y += my * s * dt;

    if (e.type === 'shooter') {
      if (e.x > 0 && e.x < W && e.y > 0 && e.y < H) e.inside = true;
      if (e.inside) {
        e.x = Math.min(W - 10, Math.max(10, e.x));
        e.y = Math.min(H - 10, Math.max(10, e.y));
      }
    }

    if (d < p.r + e.r && p.hurt <= 0) hurtPlayer(e.dmg);
  }

  // दुश्मन की गोलियाँ
  for (const b of ebullets) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    if (p.hurt <= 0 && Math.hypot(b.x - p.x, b.y - p.y) < p.r + 5) {
      b.life = 0;
      hurtPlayer(b.dmg);
    }
  }
  ebullets = ebullets.filter(b => b.life > 0 && b.x > -30 && b.x < W + 30 && b.y > -30 && b.y < H + 30);

  // हमारी गोलियाँ
  for (const b of bullets) {
    b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    for (const e of enemies) {
      if (e.hp <= 0 || b.hit.includes(e)) continue;
      if (Math.hypot(b.x - e.x, b.y - e.y) < e.r + 4) {
        e.hp -= b.dmg; b.hit.push(e);
        if (e.hp <= 0) {
          score += TYPES[e.type].pts;
          dropItem(e.x, e.y, e.type === 'boss');
          sfx.kill();
          burst(e.x, e.y, TYPES[e.type].col, e.type === 'boss' ? 36 : 12, e.type === 'boss' ? 260 : 180);
          if (e.type === 'boss') shake = 12;
          updateHud();
        } else {
          sfx.hit();
          burst(b.x, b.y, '#ffd85c', 3, 120);
        }
        if (b.pierce > 0) b.pierce--;
        else { b.life = 0; break; }
      }
    }
  }
  bullets = bullets.filter(b => b.life > 0);
  enemies = enemies.filter(e => e.hp > 0);

  // कण (particles)
  for (const q of parts) { q.x += q.vx * dt; q.y += q.vy * dt; q.life -= dt; }
  parts = parts.filter(q => q.life > 0);

  // पावर-अप
  for (const d of drops) {
    d.life -= dt;
    if (Math.hypot(d.x - p.x, d.y - p.y) < p.r + 14) { pickUp(d); d.life = 0; }
  }
  drops = drops.filter(d => d.life > 0);

  if (p.hp <= 0) gameOver();
}

// ---------- ड्रॉइंग ----------
function draw() {
  ctx.save();
  if (shake > 0) ctx.translate((Math.random() - 0.5) * shake, (Math.random() - 0.5) * shake);

  ctx.fillStyle = '#4c6b3a';
  ctx.fillRect(-20, -20, W + 40, H + 40);
  ctx.fillStyle = 'rgba(0,0,0,.08)';
  for (let x = 20; x < W; x += 60) for (let y = 20; y < H; y += 60) ctx.fillRect(x, y, 4, 4);

  // पावर-अप
  ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.font = 'bold 16px sans-serif';
  for (const d of drops) {
    if (d.life < 3 && Math.floor(d.life * 6) % 2) continue;
    ctx.fillStyle = DROPS[d.kind].col;
    ctx.beginPath(); ctx.arc(d.x, d.y, 14, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.fillText(DROPS[d.kind].t, d.x, d.y + 1);
  }

  // दुश्मन
  for (const e of enemies) {
    ctx.fillStyle = e.state === 'wind' && Math.floor(e.wt * 14) % 2 ? '#ffffff' : TYPES[e.type].col;
    ctx.beginPath(); ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2); ctx.fill();
    if (e.type === 'shooter') {
      ctx.strokeStyle = '#12303f'; ctx.lineWidth = 4;
      const a = Math.atan2(p.y - e.y, p.x - e.x);
      ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + Math.cos(a) * (e.r + 7), e.y + Math.sin(a) * (e.r + 7)); ctx.stroke();
    }
    if (e.max > 4) {
      ctx.fillStyle = 'rgba(0,0,0,.5)';
      ctx.fillRect(e.x - e.r, e.y - e.r - 10, e.r * 2, 5);
      ctx.fillStyle = '#e8643c';
      ctx.fillRect(e.x - e.r, e.y - e.r - 10, e.r * 2 * Math.max(0, e.hp / e.max), 5);
    }
  }

  // दुश्मन की गोलियाँ
  for (const b of ebullets) {
    ctx.fillStyle = '#ff7a3c';
    ctx.beginPath(); ctx.arc(b.x, b.y, 6, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#7a1f0a'; ctx.lineWidth = 2; ctx.stroke();
  }

  // हमारी गोलियाँ
  ctx.fillStyle = '#ffd85c';
  for (const b of bullets) { ctx.beginPath(); ctx.arc(b.x, b.y, 4, 0, Math.PI * 2); ctx.fill(); }

  // कण
  for (const q of parts) {
    ctx.globalAlpha = Math.max(0, q.life / q.max);
    ctx.fillStyle = q.col;
    ctx.fillRect(q.x - q.r / 2, q.y - q.r / 2, q.r, q.r);
  }
  ctx.globalAlpha = 1;

  // खिलाड़ी
  const tipX = p.x + p.dx * (p.r + 12), tipY = p.y + p.dy * (p.r + 12);
  ctx.strokeStyle = '#2b2b2b'; ctx.lineWidth = 6;
  ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(tipX, tipY); ctx.stroke();
  if (p.flash > 0) {
    ctx.fillStyle = '#fff3a0';
    ctx.beginPath(); ctx.arc(tipX + p.dx * 4, tipY + p.dy * 4, 8, 0, Math.PI * 2); ctx.fill();
  }
  if (p.spdT > 0) {
    ctx.strokeStyle = '#3b8ee0'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(p.x, p.y, p.r + 5, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.fillStyle = p.hurt > 0 && Math.floor(p.hurt * 20) % 2 ? '#ffffff' : '#f2e3b8';
  ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2); ctx.fill();

  ctx.restore();

  // लहर का बैनर
  if (bannerT > 0 && !choosing) {
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = 'rgba(255,247,224,' + Math.min(1, bannerT) + ')';
    ctx.font = 'bold 40px sans-serif';
    ctx.fillText('लहर ' + wave + (wave % 5 === 0 ? ' · बॉस आ रहा है!' : ''), W / 2, H / 3);
  }
}

// ---------- लूप और स्क्रीन ----------
function loop(t) {
  if (!running) return;
  const dt = Math.min(0.05, (t - last) / 1000);
  last = t;
  if (!choosing) update(dt);
  if (running) {
    draw();
    if (choosing) drawCards();
    requestAnimationFrame(loop);
  }
}

function startGame() {
  ac();
  reset();
  paused = false;
  overlay.classList.add('hidden');
  running = true;
  last = performance.now();
  requestAnimationFrame(loop);
}

function pauseGame() {
  running = false; paused = true; firing = false;
  titleEl.textContent = 'रुका हुआ';
  msgEl.textContent = 'लहर ' + wave + ' · स्कोर ' + score;
  startBtn.textContent = 'जारी रखें';
  overlay.classList.remove('hidden');
}

function gameOver() {
  running = false; paused = false; firing = false;
  sfx.over();
  saveBest(); updateHud();
  titleEl.textContent = 'गेम ओवर';
  msgEl.textContent = 'लहर ' + wave + ' · स्कोर ' + score + ' · सर्वश्रेष्ठ ' + best;
  startBtn.textContent = 'दोबारा खेलें';
  overlay.classList.remove('hidden');
  draw();
}

startBtn.addEventListener('click', () => {
  if (paused) {
    ac();
    paused = false;
    overlay.classList.add('hidden');
    running = true;
    last = performance.now();
    requestAnimationFrame(loop);
  } else startGame();
});
pauseBtn.addEventListener('click', () => { if (running) pauseGame(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && running) pauseGame(); });

reset();
draw();