// AlarmSimulator_Ukraine — локальна демонстраційна адмін-панель
// DEMO ONLY: не підключається до реальних систем оповіщення.
const ADMIN_PIN = '2468'; // Змініть PIN у цьому файлі за потреби. Це локальний демо-захист, не серверна авторизація.
const REGION_NAMES = ['Вінницька','Волинська','Дніпропетровська','Донецька','Житомирська','Закарпатська','Запорізька','Івано-Франківська','Київська','Кіровоградська','Луганська','Львівська','Миколаївська','Одеська','Полтавська','Рівненська','Сумська','Тернопільська','Харківська','Херсонська','Хмельницька','Черкаська','Чернівецька','Чернігівська','АР Крим','Київ','Севастополь'];
const EVENTS = [
 {id:'air',name:'Повітряна тривога',color:'#ff5268',start:'sound_start_air.mp3',end:'sound_end_air.mp3',desc:'Пройдіть до найближчого укриття'},
 {id:'artillery',name:'Артилерійська загроза',color:'#ff9b35',start:'sound_start_artillery.mp3',end:'sound_end_artillery.mp3',desc:'Увага! Артилерійська загроза! Негайно прямуйте до укриття!'},
 {id:'chemical',name:'Хімічна загроза',color:'#b47aff',start:'sound_start_chemical.mp3',end:'sound_end_chemical.mp3',desc:'Увага! Хімічна загроза! Увімкніть радіо або телебачення для отримання подальших інструкцій.'},
 {id:'radiation',name:'Радіаційна загроза',color:'#ff69b4',start:'sound_start_radiation.mp3',end:'sound_end_radiation.mp3',desc:'Увага! Радіаційна загроза! Залишайтеся в приміщенні та увімкніть радіо або телебачення для отримання подальших інструкцій.'},
 {id:'other',name:'Інша небезпека',color:'#45b8e8',start:'sound_start_danger.mp3',end:'sound_end_danger.mp3',desc:'Увага! Повідомлення про небезпеку. Стежте за подальшими інструкціями.'},
 {id:'street',name:'Вуличні бої',color:'#10c99a',start:'sound_start_street.mp3',end:'sound_end_street.mp3',desc:'Увага! Вуличні бої! Негайно залишайтеся в укритті! Не підходьте до вікон!'}
];
const QUICK = [
 {id:'air-card',title:'Повітряна тривога: червоний рівень небезпеки',short:'Пройдіть до найближчого укриття',icon:'✦',color:'#ff6f61'},
 {id:'art-card',title:'Артилерійський обстріл',short:'Пройдіть до найближчого укриття',icon:'✹',color:'#ff9c00'},
 {id:'street-card',title:'Вуличні бої',short:'Не виходьте на вулицю',icon:'◆',color:'#00b88a'},
 {id:'evac-card',title:'БЕЗКОШТОВНА ЕВАКУАЦІЯ',short:'Демонстраційне повідомлення про евакуацію',icon:'◀',color:'#aeb2b9'}
];
const DISTRICTS = {
'Вінницька':['Вінницький','Гайсинський','Жмеринський','Могилів-Подільський','Тульчинський','Хмільницький'],
'Волинська':['Володимирський','Камінь-Каширський','Ковельський','Луцький'],
'Дніпропетровська':['Дніпровський','Кам’янський','Криворізький','Нікопольський','Новомосковський','Павлоградський','Синельниківський'],
'Донецька':['Бахмутський','Волноваський','Горлівський','Донецький','Кальміуський','Краматорський','Маріупольський','Покровський'],
'Житомирська':['Бердичівський','Житомирський','Коростенський','Звягельський'],
'Закарпатська':['Берегівський','Мукачівський','Рахівський','Тячівський','Ужгородський','Хустський'],
'Запорізька':['Бердянський','Василівський','Запорізький','Мелітопольський','Пологівський'],
'Івано-Франківська':['Верховинський','Івано-Франківський','Калуський','Коломийський','Косівський','Надвірнянський'],
'Київська':['Білоцерківський','Бориспільський','Броварський','Бучанський','Вишгородський','Обухівський','Фастівський'],
'Кіровоградська':['Голованівський','Кропивницький','Новоукраїнський','Олександрійський'],
'Луганська':['Алчевський','Довжанський','Луганський','Ровеньківський','Сватівський','Сєвєродонецький','Старобільський','Щастинський'],
'Львівська':['Дрогобицький','Золочівський','Львівський','Самбірський','Стрийський','Шептицький','Яворівський'],
'Миколаївська':['Баштанський','Вознесенський','Миколаївський','Первомайський'],
'Одеська':['Березівський','Білгород-Дністровський','Болградський','Ізмаїльський','Одеський','Подільський','Роздільнянський'],
'Полтавська':['Кременчуцький','Лубенський','Миргородський','Полтавський'],
'Рівненська':['Вараський','Дубенський','Рівненський','Сарненський'],
'Сумська':['Конотопський','Охтирський','Роменський','Сумський','Шосткинський'],
'Тернопільська':['Кременецький','Тернопільський','Чортківський'],
'Харківська':['Богодухівський','Ізюмський','Красноградський','Куп’янський','Лозівський','Харківський','Чугуївський'],
'Херсонська':['Бериславський','Генічеський','Каховський','Скадовський','Херсонський'],
'Хмельницька':['Кам’янець-Подільський','Хмельницький','Шепетівський'],
'Черкаська':['Звенигородський','Золотоніський','Уманський','Черкаський'],
'Чернівецька':['Вижницький','Дністровський','Чернівецький'],
'Чернігівська':['Корюківський','Ніжинський','Новгород-Сіверський','Прилуцький','Чернігівський']
};
let map=null, geoLayer=null, selected=new Set(), activeEvents=[], activeQuick=new Set(), history=JSON.parse(localStorage.getItem('alarmSimulatorHistory')||'[]'), audio=null;
let myRegion=localStorage.getItem('alarmSimulatorMyRegion')||'', myDistrict=localStorage.getItem('alarmSimulatorMyDistrict')||'';
const $=s=>document.querySelector(s);
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function dateTime(d=new Date()){return d.toLocaleString('uk-UA',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});}
function stamp(){return dateTime();}
function durationText(start,end){const ms=Math.max(0,new Date(end)-new Date(start));const mins=Math.floor(ms/60000),hrs=Math.floor(mins/60),rest=mins%60;return hrs?`${hrs} год ${rest} хв`:`${mins} хв`;}
function log(kind,regions,detail=''){history.unshift({kind,regions:regions.join(', '),detail,time:stamp()});history=history.slice(0,250);localStorage.setItem('alarmSimulatorHistory',JSON.stringify(history));renderHistory();}
function speak(text){if(!('speechSynthesis' in window)||!text)return;window.speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='uk-UA';u.rate=.92;u.pitch=1;const voices=speechSynthesis.getVoices();u.voice=voices.find(v=>v.lang&&v.lang.toLowerCase().startsWith('uk'))||null; speechSynthesis.speak(u);}
function voiceText(item){if(item.id==='air'){const level=item.level||'red';return level==='yellow'?'Увага! Повітряна тривога! Жовтий рівень небезпеки! Пройдіть в найближче укриття!':'Увага! Повітряна тривога! Червоний рівень небезпеки! Пройдіть в найближче укриття!';}return item.message||item.defaultVoice||item.name+'. '+item.message;}
function play(file,voice=''){stopAudio();audio=new Audio(file);audio.onended=()=>{if(voice)speak(voice);};audio.play().catch(()=>{if(voice)speak(voice);else console.warn('Audio playback blocked:',file);});}

function stopAudio(){if(audio){audio.pause();audio.currentTime=0;audio=null;}}
function openAdmin(){$('#homeScreen').classList.add('hidden');$('#loginScreen').classList.remove('hidden');}
$('#openAdmin').onclick=openAdmin;$('#homeAdminButton').onclick=openAdmin;
document.querySelectorAll('[data-home-tab]').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('[data-home-tab]').forEach(x=>x.classList.toggle('active',x===b));const target=b.dataset.homeTab==='region'?$('#homeRegion'):b.dataset.homeTab==='info'?$('.home-info'):$('.home-status-card');target?.scrollIntoView({behavior:'smooth',block:'center'});}));
function login(){if($('#adminPin').value===ADMIN_PIN){$('#loginScreen').classList.add('hidden');$('#homeScreen').classList.add('hidden');$('#app').classList.remove('hidden');setTimeout(()=>map?.invalidateSize(),250);$('#loginError').textContent='';}else $('#loginError').textContent='Неправильний PIN-код. Для початкового демо: 2468.';}
$('#loginBtn').addEventListener('click',login);$('#adminPin').addEventListener('keydown',e=>{if(e.key==='Enter')login();});$('#logoutBtn').onclick=()=>{$('#app').classList.add('hidden');$('#homeScreen').classList.remove('hidden');$('#adminPin').value='';};
function fillHomeRegions(){const h=$('#homeRegion');if(!h)return;h.innerHTML='<option value="">Оберіть область</option>';REGION_NAMES.forEach(n=>h.add(new Option(n+' область',n)));h.value=REGION_NAMES.includes(myRegion)?myRegion:'';populateDistricts($('#homeDistrict'),myRegion,myDistrict);}
$('#homeRegion').addEventListener('change',()=>{myRegion=$('#homeRegion').value;myDistrict='';localStorage.setItem('alarmSimulatorMyRegion',myRegion);localStorage.removeItem('alarmSimulatorMyDistrict');populateDistricts($('#homeDistrict'),myRegion,'');$('#myRegion').value=myRegion;populateDistricts($('#myDistrict'),myRegion,'');renderHomeStatus();renderRegionStatuses();});
$('#homeDistrict').addEventListener('change',()=>{myDistrict=$('#homeDistrict').value;localStorage.setItem('alarmSimulatorMyDistrict',myDistrict);$('#myDistrict').value=myDistrict;renderHomeStatus();});
function populateDistricts(select,region,value){if(!select)return;select.innerHTML='';select.add(new Option('Уся область',''));(DISTRICTS[region]||[]).forEach(d=>select.add(new Option(d+' район',d)));if(value)select.value=value;}
function fillControls(){fillHomeRegions();const sel=$('#regionSelect');REGION_NAMES.forEach(n=>sel.add(new Option(n,n)));const mine=$('#myRegion');mine.add(new Option('Оберіть свою область',''));REGION_NAMES.forEach(n=>mine.add(new Option(n,n)));mine.value=REGION_NAMES.includes(myRegion)?myRegion:'';populateDistricts($('#myDistrict'),myRegion,myDistrict);populateDistricts($('#districtSelect'),[...selected][0]||'',[]);EVENTS.forEach(e=>$('#eventType').add(new Option(e.name,e.id)));renderRegionStatuses();renderHomeStatus();}
$('#myRegion').addEventListener('change',()=>{myRegion=$('#myRegion').value;$('#homeRegion').value=myRegion;myDistrict='';localStorage.setItem('alarmSimulatorMyRegion',myRegion);localStorage.removeItem('alarmSimulatorMyDistrict');populateDistricts($('#myDistrict'),myRegion,'');renderRegionStatuses();$('#notificationStatus').textContent=myRegion?'Обрана область: '+myRegion+'.':'Оберіть область.';});
$('#myDistrict').addEventListener('change',()=>{myDistrict=$('#myDistrict').value;localStorage.setItem('alarmSimulatorMyDistrict',myDistrict);});
$('#enableNotifications').onclick=async()=>{if(!('Notification' in window)){ $('#notificationStatus').textContent='Цей браузер не підтримує системні сповіщення.';return;}try{const permission=await Notification.requestPermission();$('#notificationStatus').textContent=permission==='granted'?'Сповіщення дозволені.':'Дозвіл на сповіщення не надано.';}catch(e){$('#notificationStatus').textContent='Не вдалося запросити дозвіл на сповіщення.';}};
function sendLocalAlert(item,isStart){
 if(!myRegion||!item.regions.some(t=>t===myRegion||t===`${myRegion} / ${myDistrict}`&&myDistrict))return;
 const now=new Date(), when=dateTime(now);
 const title=isStart?item.name:'Відбій: '+item.name;
 const body=isStart
  ? `Область: ${myRegion}\nРайон: ${item.regions.join(', ')}\nТип: ${item.name}\nПочаток: ${when}\nПовідомлення: ${item.message||''}\nDEMO / ТЕСТ`
  : `Область: ${myRegion}\nТип: ${item.name}\nПочаток: ${dateTime(new Date(item.startedAt))}\nВідбій: ${when}\nТривалість: ${durationText(item.startedAt,now)}\nDEMO / ТЕСТ`;
 if(navigator.vibrate)navigator.vibrate(isStart?[1000,250,1000,250,1000]:[500,180,500,180,500]);
 if('Notification' in window&&Notification.permission==='granted'){
  try{new Notification('DEMO · '+title,{body,tag:'alarm-'+item.id+'-'+myRegion,renotify:true});}
  catch(e){console.warn('Notification error',e);}
 }
 $('#notificationStatus').textContent=title+' · '+when;
}
function renderRegionStatuses(){const el=$('#regionStatuses');if(!el)return;el.innerHTML=REGION_NAMES.map(name=>{
 const items=activeEvents.filter(e=>e.regions.some(t=>t===name||t.startsWith(name+' / ')));
 const status=items.length?items.map(e=>`<span class="status-ball" title="${esc(e.name)}" style="background:${e.color};box-shadow:0 0 10px ${e.color}">${eventIcon(e.id)}</span>`).join(''):'<span class="status-ball clear-ball" title="Немає тривог">✓</span>';
 return `<div class="region-status ${items.length?'is-alert':'is-clear'}">${status}<span class="region-name">${esc(name)}</span>${name===myRegion?'<span class="my-region-tag">МОЯ</span>':''}</div>`;
 }).join('');}
function eventIcon(id){return ({air:'✈',artillery:'✹',chemical:'☣',radiation:'☢',other:'!',street:'⚔'})[id]||'!';}
function syncSelectedFromSelect(){selected=new Set([...$('#regionSelect').selectedOptions].map(o=>o.value));populateDistricts($('#districtSelect'),[...selected][0]||'','');updateSelectionUI();styleRegions();}
$('#districtSelect').addEventListener('change',()=>{});
function updateSelectionUI(){$('#selectedRegions').textContent=selected.size?[...selected].join(' · '):'Ще не вибрано';[...$('#regionSelect').options].forEach(o=>o.selected=selected.has(o.value));}
$('#regionSelect').addEventListener('change',syncSelectedFromSelect);
$('#clearSelection').onclick=()=>{selected.clear();updateSelectionUI();styleRegions();};
function matchRegion(props){const raw=[props.name,props.shapeName,props.NAME_1,props.name_uk,props.NAME_UK,props.shapeNameLocal,props.NAME].filter(Boolean).join(' ').toLowerCase();const aliases={
 'вінниць':'Вінницька','vinnyts':'Вінницька','vinnitsa':'Вінницька','волин':'Волинська','volyn':'Волинська','волын':'Волинська','дніпропетров':'Дніпропетровська','dnipro':'Дніпропетровська','dnepro':'Дніпропетровська','донец':'Донецька','donetsk':'Донецька','житомир':'Житомирська','zhytomyr':'Житомирська','zakarp':'Закарпатська','закарпат':'Закарпатська','запор':'Запорізька','zaporiz':'Запорізька','івано-франків':'Івано-Франківська','ivano-frank':'Івано-Франківська','київськ':'Київська','kyiv oblast':'Київська','kiev oblast':'Київська','кіровоград':'Кіровоградська','kirovo':'Кіровоградська','луган':'Луганська','luhansk':'Луганська','луганск':'Луганська','львів':'Львівська','lviv':'Львівська','микола':'Миколаївська','mykola':'Миколаївська','одес':'Одеська','odes':'Одеська','полтав':'Полтавська','poltav':'Полтавська','рівнен':'Рівненська','rivne':'Рівненська','ривнен':'Рівненська','сумськ':'Сумська','sumy':'Сумська','терноп':'Тернопільська','ternop':'Тернопільська','харків':'Харківська','khark':'Харківська','херсон':'Херсонська','kherson':'Херсонська','хмельниц':'Хмельницька','khmel':'Хмельницька','черкас':'Черкаська','cherkasy':'Черкаська','чернів':'Чернівецька','cherniv':'Чернівецька','черни':'Чернігівська','chernih':'Чернігівська','крим':'АР Крим','crimea':'АР Крим','sevastopol':'Севастополь','севастоп':'Севастополь','autonomous republic of crimea':'АР Крим','kyiv city':'Київ','київ':'Київ'};
 for(const [key,val] of Object.entries(aliases))if(raw.includes(key))return val;return null;}
function styleFor(feature){const name=matchRegion(feature.properties||{});const active=activeEvents.filter(e=>e.regions.some(t=>t===name||t.startsWith(name+' / ')));if(active.length)return {color:'#f3f7ff',weight:1.5,fillColor:active[active.length-1].color,fillOpacity:.82};if(selected.has(name))return {color:'#7be9ff',weight:2.5,fillColor:'#20bfe9',fillOpacity:.62};return {color:'#8299b8',weight:1,fillColor:'#1b304c',fillOpacity:.83};}
function styleRegions(){if(geoLayer)geoLayer.setStyle(styleFor);}
function onEachRegion(feature,layer){const name=matchRegion(feature.properties||{});if(!name)return;layer.bindTooltip(name,{sticky:true,direction:'auto'});layer.on('click',()=>{if(selected.has(name))selected.delete(name);else selected.add(name);updateSelectionUI();styleRegions();});}
async function loadMap(){if(!window.L){$('#mapStatus').textContent='Leaflet не завантажився';return;}
 map=L.map('map',{zoomControl:true,scrollWheelZoom:false,preferCanvas:true}).setView([48.8,31.2],5);
 L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:10,attribution:'© OpenStreetMap contributors'}).addTo(map);
 const sources=['https://cdn.jsdelivr.net/gh/darmat1/ukraine-geo-data@main/geodata/Ukraine.geojson','https://raw.githubusercontent.com/darmat1/ukraine-geo-data/main/geodata/Ukraine.geojson'];
 let data=null;for(const url of sources){try{const r=await fetch(url);if(!r.ok)throw new Error('HTTP '+r.status);data=await r.json();break;}catch(e){console.warn('GeoJSON source failed',url,e);}}
 if(!data)throw new Error('Не вдалося завантажити межі областей. Перевірте інтернет-з’єднання.');
 geoLayer=L.geoJSON(data,{style:styleFor,onEachFeature:onEachRegion}).addTo(map);const bounds=geoLayer.getBounds();if(bounds.isValid())map.fitBounds(bounds.pad(.06));$('#mapStatus').textContent='Мапу завантажено';
 const matched=new Set();geoLayer.eachLayer(l=>{const n=matchRegion(l.feature.properties||{});if(n)matched.add(n);});console.info('Mapped features',matched.size,[...matched]);
}
function selectedRegions(){return [...selected];}
function startEvent(){const areas=selectedRegions();const districts=[...$('#districtSelect').selectedOptions].map(o=>o.value).filter(Boolean);if(districts.length&&areas.length!==1){alert('Для вибору районів оберіть рівно одну область.');return;}const regions=districts.length?districts.map(d=>`${areas[0]} / ${d}`):areas;if(!regions.length){alert('Спочатку виберіть одну або декілька областей на мапі або у списку.');return;}const type=EVENTS.find(e=>e.id===$('#eventType').value);if(!type)return;const level=$('#airLevel')?.value||'red';const msg=$('#eventMessage').value.trim()|| (type.id==='air'?(level==='yellow'?'Жовтий рівень небезпеки. Пройдіть в найближче укриття!':'Червоний рівень небезпеки. Пройдіть в найближче укриття!'):type.desc);const existing=activeEvents.find(e=>e.id===type.id&&e.regions.join('|')===regions.join('|'));if(existing){alert('Така демонстраційна подія вже активна для вибраних областей.');return;}const startedAt=new Date().toISOString();const item={id:type.id,name:type.name,color:type.color,regions:[...regions],message:msg,startedAt,started:dateTime(new Date(startedAt)),soundEnd:type.end,level};activeEvents.unshift(item);log('Початок: '+type.name,regions,'Початок: '+item.started+(msg?' · '+msg:''));play(type.start,voiceText(item));sendLocalAlert(item,true);renderActive();renderRegionStatuses();styleRegions();}
function endEvent(){const areas=selectedRegions();const districts=[...$('#districtSelect').selectedOptions].map(o=>o.value).filter(Boolean);const regions=districts.length&&areas.length===1?districts.map(d=>`${areas[0]} / ${d}`):areas;if(!regions.length){alert('Виберіть області для відбою.');return;}const type=EVENTS.find(e=>e.id===$('#eventType').value);const idx=activeEvents.findIndex(e=>e.id===type.id&&e.regions.some(n=>regions.includes(n)));if(idx<0){alert('Для вибраних областей немає активної події цього типу.');return;}const item=activeEvents.splice(idx,1)[0];const endedAt=new Date();log('Відбій: '+item.name,item.regions,'Початок: '+item.started+' · Відбій: '+dateTime(endedAt)+' · Тривалість: '+durationText(item.startedAt,endedAt));play(type.end,'Відбій! '+item.name+'. Демонстраційна подія завершена.');sendLocalAlert(item,false);renderActive();renderRegionStatuses();styleRegions();}
$('#startEvent').onclick=startEvent;$('#endEvent').onclick=endEvent;
function renderHomeStatus(){const card=$('#homeStatusCard');if(!card)return;const relevant=activeEvents.filter(e=>e.regions.some(t=>t===myRegion||((t.startsWith(myRegion+' / '))&&(!myDistrict||t===myRegion+' / '+myDistrict))));if(relevant.length){const e=relevant[relevant.length-1];card.style.borderTop='4px solid '+e.color;$('#homeStatusIcon').textContent=eventIcon(e.id);$('#homeStatusIcon').style.background=e.color+'22';$('#homeStatusIcon').style.color=e.color;$('#homeStatusTitle').textContent=e.name;$('#homeStatusText').textContent=(myRegion?myRegion+' область · ':'')+'Демонстраційна подія активна';}else{card.style.borderTop='1px solid #e8edf1';$('#homeStatusIcon').textContent='✓';$('#homeStatusIcon').style.background='#e7f5ee';$('#homeStatusIcon').style.color='#20a36b';$('#homeStatusTitle').textContent='Немає активних подій';$('#homeStatusText').textContent=myRegion?myRegion+' область · демонстраційний стан':'Оберіть область, щоб переглядати її локальний стан';}}
function renderActive(){const el=$('#activeEvents');if(!activeEvents.length){el.className='empty-state';el.textContent='Активних демонстраційних подій немає.';renderHomeStatus();return;}el.className='';el.innerHTML=activeEvents.map((e,i)=>`<div class="event-row"><strong style="color:${e.color}">${esc(e.name)}</strong><p>${esc(e.regions.join(', '))}</p><p>Початок: ${esc(e.started)}</p><p>${esc(e.message)}</p><small class="demo-pill">DEMO / ТЕСТ</small><div class="event-actions"><button class="ghost" data-end-index="${i}">Завершити цю подію</button></div></div>`).join('');el.querySelectorAll('[data-end-index]').forEach(b=>b.onclick=()=>{const i=+b.dataset.endIndex,e=activeEvents.splice(i,1)[0],type=EVENTS.find(x=>x.id===e.id);const endedAt=new Date();log('Відбій: '+e.name,e.regions,'Початок: '+e.started+' · Відбій: '+dateTime(endedAt)+' · Тривалість: '+durationText(e.startedAt,endedAt));play(type.end);sendLocalAlert(e,false);renderActive();renderRegionStatuses();styleRegions();});renderHomeStatus();}
function renderQuick(){const el=$('#quickCards');el.innerHTML=QUICK.map(q=>`<button class="quick-card ${activeQuick.has(q.id)?'active':''}" data-quick="${q.id}"><span class="quick-icon" style="background:${q.color}">${q.icon}</span><span><b>${esc(q.title)}</b><small>${esc(q.short)}</small></span><span class="arrow">›</span></button>`).join('');el.querySelectorAll('[data-quick]').forEach(b=>b.onclick=()=>toggleQuick(b.dataset.quick));renderHomeStatus();}
function toggleQuick(id){if(!selected.size){alert('Спочатку виберіть область або декілька областей.');return;}const q=QUICK.find(x=>x.id===id);if(activeQuick.has(id)){activeQuick.delete(id);log('Завершено повідомлення: '+q.title,[...selected]);}else{activeQuick.add(id);log('Активовано повідомлення: '+q.title,[...selected]);}renderQuick();renderActiveQuick();}
function renderActiveQuick(){const el=$('#activeQuick');const items=QUICK.filter(q=>activeQuick.has(q.id));if(!items.length){el.className='empty-state';el.textContent='Немає активних повідомлень.';return;}el.className='';el.innerHTML=items.map(q=>`<div class="quick-active-row"><strong>${esc(q.title)}</strong><p>Демонстраційне повідомлення · натисніть картку вище, щоб вимкнути</p></div>`).join('');}
function renderHistory(){const el=$('#history');if(!history.length){el.className='empty-state';el.textContent='Історія поки порожня.';return;}el.className='';el.innerHTML=history.slice(0,40).map(x=>`<div class="history-item"><b>${esc(x.kind)}</b><div>${esc(x.regions)}</div><div>${esc(x.detail)}</div><time>${esc(x.time)}</time></div>`).join('');}
$('#clearHistory').onclick=()=>{if(confirm('Очистити журнал подій?')){history=[];localStorage.removeItem('alarmSimulatorHistory');renderHistory();}};
document.querySelectorAll('.play-pack').forEach(b=>b.onclick=()=>play(b.dataset.file));$('#stopAudio').onclick=stopAudio;
fillControls();renderHistory();renderQuick();loadMap().catch(err=>{$('#mapStatus').textContent='Мапа недоступна';$('#map').innerHTML='<div class="map-error">Не вдалося завантажити географічні межі. Підключіть інтернет і перезавантажте сторінку.<br><small>'+esc(err.message)+'</small></div>';console.error(err);});
