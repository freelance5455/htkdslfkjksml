const button = document.getElementById("okButton");
const toast = document.getElementById("toast");
button.addEventListener("click", () => {
  toast.classList.add("show");
  button.textContent = "WKWKWK 🤣";
  window.setTimeout(() => toast.classList.remove("show"), 2200);
});
