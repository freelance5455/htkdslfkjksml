// Helper function to convert RGB to HSL for hue shifting
// r, g, b are values from 0 to 255
// returns h, s, l as values from 0 to 1
import { rgbToHsl, hslToRgb, shiftHue } from './src/colorUtils.js';
import { applyComplexEffect, getPitchShiftForEffect } from './src/effects.js';

// FFmpeg wasm integration
import { createFFmpeg, fetchFile } from "@ffmpeg/ffmpeg";
const ffmpeg = createFFmpeg({ log: false });
let ffmpegReady = false;
async function ensureFFmpegReady() {
    if (ffmpegReady) return true;
    try {
        if (!ffmpeg.isLoaded()) {
            await ffmpeg.load();
        }
        ffmpegReady = true;
        return true;
    } catch (e) {
        console.warn("FFmpeg.wasm failed to load:", e);
        ffmpegReady = false;
        return false;
    }
}

// Convert arbitrary recorded Blob (webm/webm-vp8 etc.) to MP4 using ffmpeg.wasm
async function transcodeBlobToMp4(blob) {
    if (!(await ensureFFmpegReady())) return null;
    const inName = "input.webm";
    const outName = "output.mp4";
    try {
        const data = await fetchFile(blob);
        ffmpeg.FS('writeFile', inName, data);
        // Use a conservative fast MP4 transcode suitable for browser ffmpeg:
        // -c:v libx264 may not be available in wasm build; use default copy or mpeg4 fallback.
        // We'll try mp4 with libx264 style options; if it fails, fallback to remux.
        try {
            await ffmpeg.run(
                '-y',
                '-i', inName,
                '-c:v', 'libx264',
                '-preset', 'veryfast',
                '-crf', '23',
                '-c:a', 'aac',
                '-b:a', '128k',
                outName
            );
        } catch (e) {
            // fallback: try muxing to mp4 with mpeg4 codec which tends to be available
            try {
                await ffmpeg.run(
                    '-y',
                    '-i', inName,
                    '-c:v', 'mpeg4',
                    '-q:v', '5',
                    '-c:a', 'aac',
                    '-b:a', '128k',
                    outName
                );
            } catch (err2) {
                console.warn("FFmpeg mp4 transcode fallback failed, attempting simple remux...", err2);
                // final fallback: copy streams where possible
                await ffmpeg.run('-y', '-i', inName, '-c', 'copy', outName);
            }
        }

        const dataOut = ffmpeg.FS('readFile', outName);
        const outBlob = new Blob([dataOut.buffer], { type: 'video/mp4' });
        // cleanup
        try { ffmpeg.FS('unlink', inName); } catch (e) {}
        try { ffmpeg.FS('unlink', outName); } catch (e) {}
        return outBlob;
    } catch (e) {
        console.warn("FFmpeg transcode failed:", e);
        return null;
    }
}

// removed function rgbToHsl() {} // moved to src/colorUtils.js
// removed function hslToRgb() {} // moved to src/colorUtils.js
// removed function shiftHue() {} // moved to src/colorUtils.js

// --- Main Logic ---
// Get DOM elements
const videoFile = document.getElementById('videoFile');
const sourceVideo = document.getElementById('sourceVideo');
const effectSelect = document.getElementById('effect');
const powerSelect = document.getElementById('power');
const customTab = document.getElementById('customTab');
const customFisheyeStrength = document.getElementById('customFisheyeStrength');
const customFisheyeSize = document.getElementById('customFisheyeSize');
const customHueShift = document.getElementById('customHueShift');
const customPitchShift = document.getElementById('customPitchShift');
const customInvert = document.getElementById('customInvert');

const generateBtn = document.getElementById('generateBtn');
const statusDiv = document.getElementById('status');
const processingCanvas = document.getElementById('processingCanvas');
const outputArea = document.getElementById('outputArea');
const outputVideo = document.getElementById('outputVideo');
const downloadBtn = document.getElementById('downloadBtn');
// NEW: Stop button and diagnostics
const stopBtn = document.getElementById('stopBtn');
const debugLog = document.getElementById('debugLog');

// Layer UI elements
const layerSelect = document.getElementById('layerSelect');
const addLayerBtn = document.getElementById('addLayerBtn');
const layersList = document.getElementById('layersList');
// Simple layers stack
let layersStack = [];

// NEW overlay inputs
const overlay1Input = document.getElementById('overlay1');
const overlay2Input = document.getElementById('overlay2');

// Overlay video elements and URLs
let overlay1Video = null, overlay2Video = null;
let overlay1URL = null, overlay2URL = null;

// Built-in Fanny image (drawn for Fanny Major effect)
let fannyImg = new Image();
let fannyImgLoaded = false;
fannyImg.src = 'Fanny.webp';
fannyImg.onload = () => { fannyImgLoaded = true; };
// Add offscreen canvases for processing overlay frames with effects
let overlay1Canvas = document.createElement('canvas'), overlay1Ctx = overlay1Canvas.getContext('2d');
let overlay2Canvas = document.createElement('canvas'), overlay2Ctx = overlay2Canvas.getContext('2d');

// NEW: performance flags
let DEBUG_ENABLED = false;
 // Export target: Lower FPS capture for final videos to reduce CPU and avoid lag.
const MAX_FPS = 15; // target export FPS reduced from 30 -> 15 to lower processing frequency
const MIN_FRAME_INTERVAL_MS = Math.round(1000 / Math.max(1, MAX_FPS)); // minimum ms between processing frames
let lastProcessWallTimeMs = 0;

function logDebug(...args) {
    if (!DEBUG_ENABLED) return;
    const msg = args.map(a => (typeof a === 'object' ? JSON.stringify(a) : String(a))).join(' ');
    console.log(...args);
    if (debugLog) {
        const time = new Date().toISOString().split('T')[1].split('Z')[0];
        debugLog.textContent += `[${time}] ${msg}\n`;
        debugLog.scrollTop = debugLog.scrollHeight;
    }
}

 // Canvas globals for access across functions (processFrame uses these)
let canvasCtx = processingCanvas.getContext('2d');
let canvasWidth = 0;
let canvasHeight = 0;

 // Offscreen/scratch canvas used to downscale heavy frames for processing (reduces per-frame CPU)
const MAX_PROCESS_DIMENSION = 640; // lowered from 960 -> 640 to reduce per-frame pixel work
let offscreenCanvas = document.createElement('canvas');
let offscreenCtx = offscreenCanvas.getContext('2d');

// Track current object URL to revoke on new selection
let currentObjectURL = null;

// New: Cache for reversed AudioBuffer (for "reverse" effect)
let reversedAudioBuffer = null;

// New: overlay-specific loop counters (reset to 0; when active they start at 1)
let overlay1Loop = 0, overlay2Loop = 0;

// Add an event listener to the output video to ensure it pauses when it ends.
// Remove the ended handler that forced a pause to avoid decoder freeze
// outputVideo.addEventListener('ended', () => {
//     console.log("Output video ended. Ensuring it is paused.");
//     outputVideo.pause();
// });

let videoDuration = 0; // To store the original video duration
let frameBuffer = []; // For reverse effect buffering

// Store the MediaRecorder instance globally or accessible within scopes that need to stop it
let mediaRecorder = null;
let isGenerating = false; // Flag to indicate if generation is in progress
let currentLoop = 0; // Track the current loop number for multi-loop effects
let originalSourceMutedState = true; // Store the original muted state of the source video

  // New: Add a small delay for audio start to synchronize with video recording
 const AUDIO_START_DELAY_SECONDS = -0.01; // small scheduling offset to align audio start with canvas frame rendering (negative = audio starts 10ms earlier)

// State variable to track the last processed frame time for non-reverse effects
// This is mainly to avoid processing the *exact same* frame multiple multiple times from rVFC
let lastFrameTime = -1;

 // For Reverse effect buffering - estimated FPS needed for calculating time for effects
let estimatedFPS = 13; // Default estimate, updated after buffering (export fps set to 13)

// Web Audio API Context for audio processing
let audioContext = null;
// Node for audio processing graph destination (MediaRecorder input)
let destinationNode = null;
// New: Store the decoded audio buffer
let audioBuffer = null;
// New: Global array to hold current audio source nodes to manage their lifecycle
let activeAudioSourceNodes = [];
// NEW: cached overlay audio nodes
let overlay1AudioNode = null, overlay2AudioNode = null;

// New: Module-scoped variable for the reverse effect's frame drawing timeout
let frameDrawTimeoutId = null; // To keep track of the timeout for stopping

// New: Tone.js integration flag and buffer cache
let toneReady = false;
let toneAudioBuffer = null; // Cache a Tone-compatible buffer when possible

// Helper to initialize Tone.js on our existing AudioContext and prepare a buffer
async function ensureToneReady() {
    if (!window.Tone) {
        toneReady = false;
        return false;
    }
    try {
        // Bind Tone to the existing AudioContext, if not already bound
        const ctx = audioContext || new (window.AudioContext || window.webkitAudioContext)();
        audioContext = ctx;
        if (Tone.getContext().rawContext !== ctx) {
            Tone.setContext(ctx);
        }
        toneReady = true;

        // Build a Tone buffer once per loaded audioBuffer (if available)
        if (audioBuffer && !toneAudioBuffer) {
            try {
                // Tone.Player accepts either a ToneAudioBuffer or native AudioBuffer directly
                // We'll keep a reference to AudioBuffer and assign it directly to player.buffer later
                toneAudioBuffer = audioBuffer; 
            } catch (e) {
                console.warn("Failed to prepare Tone buffer from AudioBuffer. Will assign native AudioBuffer directly to Tone.Player.", e);
                toneAudioBuffer = audioBuffer;
            }
        }
        return true;
    } catch (e) {
        console.warn("Tone.js setup failed. Audio will be muted to avoid speed changes.", e);
        toneReady = false;
        toneAudioBuffer = null;
        return false;
    }
}

// Helper to sanitize and display semitone values (allow fractional for new effects)
function formatSemitoneList(pitches) {
    return (pitches || []).map(p => {
        const num = Number(p);
        if (!isFinite(num)) return '0';
        const s = Math.abs(num % 1) < 1e-6 ? num.toFixed(0) : num.toFixed(1);
        const signed = num > 0 ? `+${s}` : `${s}`;
        return signed;
    }).join(', ');
}

// Helper to create and start audio nodes for a given loop
function startAudioPlaybackForLoop(pitches, startAt = null) {
    // Clear any previous active nodes
    stopAllAudioPlayback();

    if (!audioContext || audioContext.state === 'closed' || !audioBuffer) {
        console.log("No audio context or buffer to play.");
        return;
    }

    let usePitches = Array.isArray(pitches) ? pitches.slice() : [];
    
    // Performance safety: Cap simultaneous pitch voices to avoid audio engine lag.
    // Increase the allowed voices but sample uniformly when there are more voices
    // so compounding continues beyond early renders without always taking only the lowest voices.
    // Raise cap to a higher value to honor user request while still protecting runtime.
    const MAX_VOICES_ALLOWED = 128;
    if (usePitches.length > MAX_VOICES_ALLOWED) {
        const sampled = [];
        const step = usePitches.length / MAX_VOICES_ALLOWED;
        for (let i = 0; i < MAX_VOICES_ALLOWED; i++) {
            sampled.push(usePitches[Math.floor(i * step)]);
        }
        usePitches = sampled;
    }

    // If no pitch shift requested, or Tone isn't ready, play original audio so export still has sound
    if (usePitches.length === 0 || !(window.Tone && toneReady && destinationNode)) {
        if (usePitches.length > 0) {
            console.warn("Tone.js not ready for pitch shift without speed change. Falling back to original audio (no pitch) to keep audio in export.");
        }
        startOriginalAudioForLoop(startAt);
        return;
    }

    // Create a master gain (native) to route Tone -> MediaStreamDestination cleanly.
    const masterGain = audioContext.createGain();
    // Use a conservative scalar to avoid clipping as voices multiply
    const voiceCount = Math.max(1, usePitches.length);
    const volumeScalar = Math.min(0.95, 1 / Math.pow(voiceCount, 0.45)); // slightly gentler attenuation for larger voice counts
    // Reduce overall master level slightly for export stability (scaled by 0.48)
    masterGain.gain.value = 0.48 * volumeScalar;

    // Mild dynamics compressor before the destination to reduce transients
    let compressor = null;
    try {
        compressor = audioContext.createDynamicsCompressor();
        compressor.threshold.setValueAtTime(-18, audioContext.currentTime);
        compressor.knee.setValueAtTime(12, audioContext.currentTime);
        compressor.ratio.setValueAtTime(3, audioContext.currentTime);
        compressor.attack.setValueAtTime(0.003, audioContext.currentTime);
        compressor.release.setValueAtTime(0.12, audioContext.currentTime);
    } catch (e) {
        compressor = null;
    }

    // Connect masterGain -> (compressor?) -> destinationNode
    if (compressor) {
        masterGain.connect(compressor);
        compressor.connect(destinationNode);
    } else {
        masterGain.connect(destinationNode);
    }

    // Use a precise preferred start time based on audioContext.currentTime to ensure tight sync.
    const preferredStart = (typeof startAt === 'number' && isFinite(startAt))
        ? startAt
        : (audioContext && typeof audioContext.currentTime === 'number' ? audioContext.currentTime + AUDIO_START_DELAY_SECONDS : (Tone && typeof Tone.now === 'function' ? Tone.now() + AUDIO_START_DELAY_SECONDS : 0));

    // Create a small deterministic micro-stagger array to avoid perfect phase alignment for large voice counts.
    // Values range 0..0.002 (0..2ms) based on index to keep timing tight but reduce combing.
    const microOffsets = usePitches.map((_, i) => (i % 16) * 0.05); // cycles every 16 voices, 0.05s chunks

    // Start each voice at exact offsets deterministically (no random jitter) to ensure sync
    usePitches.forEach((semitones, idx) => {
        // Player with preloaded buffer; preserve speed (no playbackRate change)
        const player = new Tone.Player({
            autostart: false,
            loop: false
        });

        // Assign native AudioBuffer directly
        player.buffer = toneAudioBuffer || audioBuffer;

        // High-quality PitchShift configuration tuned to emulate DAW/VEGAS-like behavior:
        // Use granular pitch params from UI when available
        const customParamsForShifter = getCustomParams();
        const desiredWindow = isFinite(customParamsForShifter.pitchWindow) ? customParamsForShifter.pitchWindow : 0.12;
        const desiredFft = isFinite(customParamsForShifter.fftSize) ? customParamsForShifter.fftSize : 1024;
        const desiredOverlap = isFinite(customParamsForShifter.overlap) ? customParamsForShifter.overlap : 4;

        const shifter = new Tone.PitchShift({
            pitch: semitones,
            windowSize: desiredWindow,
            feedback: 0,
            wet: 1
        });

        // Some implementations expose fftSize/overlap; set them if available
        try {
            if ('fftSize' in shifter && Number.isFinite(desiredFft)) shifter.fftSize = desiredFft;
            if ('overlap' in shifter && Number.isFinite(desiredOverlap)) shifter.overlap = desiredOverlap;
            // fallback for internal/private props if provider exposes different keys
            if (!('fftSize' in shifter) && shifter._fft) {
                try { shifter._fft.size = desiredFft; } catch(e){}
            }
        } catch (e) {
            // non-fatal if driver doesn't support these knobs
        }

        // Subtle deterministic stereo spread to reduce comb-filtering and widen texture.
        const panner = new Tone.Panner({
            pan: ((idx % 2 === 0) ? -0.06 : 0.06) * (1 + (idx % 8) * 0.01)
        });

        // Chain player -> shifter -> panner -> masterGain
        player.connect(shifter);
        shifter.connect(panner);
        panner.connect(masterGain);

        // Compute tight per-voice start time using audioContext currentTime mapped into Tone's timeline if needed.
        const deterministicOffset = microOffsets[idx] || 0;
        const voiceStart = preferredStart + deterministicOffset;

        try {
            // Use Tone's timeline when available; convert audioContext.currentTime -> Tone.now() offset deterministically.
            if (typeof Tone.now === 'function' && typeof player.start === 'function' && audioContext && typeof audioContext.currentTime === 'number') {
                const toneStart = Tone.now() + (voiceStart - audioContext.currentTime);
                try { player.start(toneStart); } catch (e) { player.start(voiceStart); }
            } else {
                player.start(voiceStart);
            }
        } catch (e) {
            try { player.start(); } catch (err) { console.warn("Failed to schedule Tone.Player start precisely, falling back to immediate start.", err); }
        }

        // Track Tone nodes for cleanup
        activeAudioSourceNodes.push({
            __toneNodes: { player, shifter, panner, compressor },
            stop: () => { try { player.stop(); } catch(e){} },
            disconnect: () => {
                try { player.disconnect(); } catch(e){}
                try { shifter.disconnect(); } catch(e){}
                try { panner.disconnect(); } catch(e){}
                try { compressor && compressor.disconnect(); } catch(e){}
            }
        });
    });

    console.log(`Started Tone.js pitch-shifted playback (speed preserved): ${formatSemitoneList(usePitches)} @${preferredStart}`);
}

// Play original, unmodified audio into the MediaStreamDestination for this loop
function startOriginalAudioForLoop(startAt = null) {
    stopAllAudioPlayback();
    if (!audioContext || audioContext.state === 'closed' || !audioBuffer || !destinationNode) {
        console.warn("Original audio playback unavailable (missing context/buffer/destination).");
        return;
    }
    const src = audioContext.createBufferSource();
    src.buffer = audioBuffer;
    // Ensure playbackRate is locked to 1 (no speed changes)
    try {
        if (src && src.playbackRate) {
            src.playbackRate.value = 1;
        }
    } catch (e) {
        // ignore if not supported
    }

    const gain = audioContext.createGain();
    gain.gain.value = 0.5;
    src.connect(gain);
    gain.connect(destinationNode);
    // Start at scheduled time if provided, otherwise start ASAP
    try {
        const when = (typeof startAt === 'number' && isFinite(startAt)) ? startAt : audioContext.currentTime;
        src.start(when);
        activeAudioSourceNodes.push({
            stop: () => { try { src.stop(); } catch(e){} },
            disconnect: () => {
                try { src.disconnect(); } catch(e){}
                try { gain.disconnect(); } catch(e){}
            }
        });
    } catch (e) {
        console.warn("Failed to start original audio source at scheduled time, starting immediately.", e);
        try { src.start(); } catch(e){}
        activeAudioSourceNodes.push({
            stop: () => { try { src.stop(); } catch(e){} },
            disconnect: () => {
                try { src.disconnect(); } catch(e){}
                try { gain.disconnect(); } catch(e){}
            }
        });
    }
}

/*
 * Play reversed audio into the MediaStreamDestination, optionally applying pitch-shift voices
 * using Tone.js when available. Accepts (pitchesArray, startAt).
 */
function startReversedOriginalAudioForLoop(pitches = [], startAt = null) {
    stopAllAudioPlayback();
    if (!audioContext || audioContext.state === 'closed' || !audioBuffer || !destinationNode) return;

    // Build reversedAudioBuffer once
    if (!reversedAudioBuffer) {
        reversedAudioBuffer = audioContext.createBuffer(audioBuffer.numberOfChannels, audioBuffer.length, audioBuffer.sampleRate);
        for (let ch = 0; ch < audioBuffer.numberOfChannels; ch++) {
            const src = audioBuffer.getChannelData(ch), dst = reversedAudioBuffer.getChannelData(ch);
            for (let i = 0, j = src.length - 1; i < src.length; i++, j--) dst[i] = src[j];
        }
    }

    // If Tone.js is available and pitches requested, use Tone's PitchShift chain on reversed buffer
    if (window.Tone && toneReady && Array.isArray(pitches) && pitches.length > 0) {
        // create master gain and compressor as in startAudioPlaybackForLoop to ensure consistent levels
        const masterGain = audioContext.createGain();
        const voiceCount = Math.max(1, pitches.length);
        const volumeScalar = Math.min(0.95, 1 / Math.pow(voiceCount, 0.45));
        masterGain.gain.value = 0.48 * volumeScalar;

        let compressor = null;
        try {
            compressor = audioContext.createDynamicsCompressor();
            compressor.threshold.setValueAtTime(-18, audioContext.currentTime);
            compressor.knee.setValueAtTime(12, audioContext.currentTime);
            compressor.ratio.setValueAtTime(3, audioContext.currentTime);
            compressor.attack.setValueAtTime(0.003, audioContext.currentTime);
            compressor.release.setValueAtTime(0.12, audioContext.currentTime);
        } catch (e) {
            compressor = null;
        }

        if (compressor) {
            masterGain.connect(compressor);
            compressor.connect(destinationNode);
        } else {
            masterGain.connect(destinationNode);
        }

        const preferredStart = (typeof startAt === 'number' && isFinite(startAt))
            ? startAt
            : (audioContext && typeof audioContext.currentTime === 'number' ? audioContext.currentTime + AUDIO_START_DELAY_SECONDS : (Tone && typeof Tone.now === 'function' ? Tone.now() + AUDIO_START_DELAY_SECONDS : 0));

        const microOffsets = pitches.map((_, i) => (i % 16) * 0.05);

        pitches.forEach((semitones, idx) => {
            const player = new Tone.Player({ autostart: false, loop: false });
            // assign native reversed AudioBuffer so playback is reversed content with pitch effect
            player.buffer = reversedAudioBuffer;

            // Use granular pitch params from UI when available for reversed playback too
            const customParamsForShifter = getCustomParams();
            const desiredWindow = isFinite(customParamsForShifter.pitchWindow) ? customParamsForShifter.pitchWindow : 0.12;
            const desiredFft = isFinite(customParamsForShifter.fftSize) ? customParamsForShifter.fftSize : 1024;
            const desiredOverlap = isFinite(customParamsForShifter.overlap) ? customParamsForShifter.overlap : 4;

            const shifter = new Tone.PitchShift({
                pitch: semitones,
                windowSize: desiredWindow,
                feedback: 0,
                wet: 1
            });

            try {
                if ('fftSize' in shifter && Number.isFinite(desiredFft)) shifter.fftSize = desiredFft;
                if ('overlap' in shifter && Number.isFinite(desiredOverlap)) shifter.overlap = desiredOverlap;
                if (!('fftSize' in shifter) && shifter._fft) {
                    try { shifter._fft.size = desiredFft; } catch(e){}
                }
            } catch (e) {
                // ignore if not supported
            }

            const panner = new Tone.Panner({
                pan: ((idx % 2 === 0) ? -0.06 : 0.06) * (1 + (idx % 8) * 0.01)
            });

            player.connect(shifter);
            shifter.connect(panner);
            panner.connect(masterGain);

            const deterministicOffset = microOffsets[idx] || 0;
            const voiceStart = preferredStart + deterministicOffset;

            try {
                if (typeof Tone.now === 'function' && typeof player.start === 'function' && audioContext && typeof audioContext.currentTime === 'number') {
                    const toneStart = Tone.now() + (voiceStart - audioContext.currentTime);
                    try { player.start(toneStart); } catch (e) { player.start(voiceStart); }
                } else {
                    player.start(voiceStart);
                }
            } catch (e) {
                try { player.start(); } catch (err) { console.warn("Failed to schedule reversed Tone.Player start, falling back.", err); }
            }

            activeAudioSourceNodes.push({
                __toneNodes: { player, shifter, panner, compressor },
                stop: () => { try { player.stop(); } catch(e){} },
                disconnect: () => {
                    try { player.disconnect(); } catch(e){}
                    try { shifter.disconnect(); } catch(e){}
                    try { panner.disconnect(); } catch(e){}
                    try { compressor && compressor.disconnect(); } catch(e){}
                }
            });
        });

        console.log(`Started Tone.js reversed pitch-shifted playback: ${formatSemitoneList(pitches)} @${preferredStart}`);
        return;
    }

    // Fallback path: play reversed buffer as a simple BufferSource (no pitch-shift)
    try {
        const srcNode = audioContext.createBufferSource();
        srcNode.buffer = reversedAudioBuffer;
        try { srcNode.playbackRate.value = 1; } catch (e) { /* ignore */ }

        const gain = audioContext.createGain(); gain.gain.value = 0.5;
        srcNode.connect(gain); gain.connect(destinationNode);

        const when = (typeof startAt === 'number' && isFinite(startAt)) ? startAt : audioContext.currentTime;
        srcNode.start(when);
        activeAudioSourceNodes.push({ stop: () => { try { srcNode.stop(); } catch(e){} }, disconnect: () => { try { srcNode.disconnect(); } catch(e){} try { gain.disconnect(); } catch(e){} } });
    } catch (e) {
        console.warn("Failed to schedule reversed audio start; starting immediately.", e);
        try {
            const srcNode2 = audioContext.createBufferSource();
            srcNode2.buffer = reversedAudioBuffer;
            srcNode2.connect(audioContext.destination);
            srcNode2.start();
            activeAudioSourceNodes.push({ stop: () => { try { srcNode2.stop(); } catch(e){} }, disconnect: () => { try { srcNode2.disconnect(); } catch(e){} } });
        } catch (err) {
            console.warn("Final fallback for reversed audio failed.", err);
        }
    }
}

// Helper for cleanup logic that happens after MediaRecorder.stop() or if stop fails
function manualCleanupAfterStopFailure() {
    logDebug("Performing manual cleanup after stop failure/completion.");
    stopAllAudioPlayback(); // Stop all active audio nodes

    // Clear any pending frame drawing timeout for reverse effect
    if (frameDrawTimeoutId) {
        clearTimeout(frameDrawTimeoutId);
        frameDrawTimeoutId = null;
        logDebug("Cleared frameDrawTimeoutId during manual cleanup.");
    }

    // Disconnect destination node but do NOT close the shared AudioContext to avoid audio freezes on restart
    if (destinationNode) {
        try {
            destinationNode.disconnect();
        } catch (e) {
            logDebug("Error disconnecting destinationNode during manual cleanup:", e);
        }
        destinationNode = null;
    }

    // NOTE: Keep audioContext open (don't close it) to avoid re-creation delays and audio freezing on subsequent generations.
    // If you truly need to tear down the AudioContext, do it explicitly elsewhere with user gesture.

    mediaRecorder = null; // Clear recorder reference
    // Restore state that onstop would handle
    isGenerating = false; // Ensure flag is false
    statusDiv.textContent = 'Generation stopped.'; // Or an error message if applicable
    generateBtn.disabled = false;
    stopBtn.disabled = true;
    sourceVideo.muted = originalSourceMutedState; // Restore original muted state
    frameBuffer = []; // Clear buffer
    currentLoop = 0; // Reset loop counter
    lastFrameTime = -1; // Reset frame time tracker
    estimatedFPS = 30; // Reset estimated FPS
    // The download button state should NOT be reset here, as it displays the final generated video.
    // It is reset when a new video is loaded or a new generation process begins.
    logDebug("Manual cleanup after stop failure/completion complete.");
}

// Function to stop generation gracefully
function stopGeneration() {
    logDebug("Attempting to stop generation...");
    // Clear any pending frame drawing timeout for reverse effect
    if (frameDrawTimeoutId) {
        clearTimeout(frameDrawTimeoutId);
        frameDrawTimeoutId = null;
        logDebug("Cleared pending frameDrawTimeoutId.");
    }

    // Check if there's an active generation, recorder, or audio context to clean up
    if (isGenerating || (mediaRecorder && mediaRecorder.state !== 'inactive') || (audioContext && audioContext.state !== 'closed')) {
        isGenerating = false; // Clear the flag immediately to prevent further processing
        stopAllAudioPlayback(); // Stop any currently playing audio nodes

        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            try {
                logDebug(`Attempting to stop MediaRecorder (state: ${mediaRecorder.state})...`);
                mediaRecorder.stop(); // This triggers onstop/onerror handlers which then call manualCleanupAfterStopFailure
            } catch (e) {
                logDebug("Error calling mediaRecorder.stop():", e);
                // If stop fails, proceed to manual cleanup directly
                manualCleanupAfterStopFailure();
            }
        } else {
            logDebug("MediaRecorder not active or already inactive. Performing manual cleanup directly.");
            manualCleanupAfterStopFailure(); // If no active recorder, cleanup directly
        }
    } else {
        logDebug("stopGeneration called but no active generation or recorder detected. Performing minimal cleanup (if any).");
        manualCleanupAfterStopFailure(); // Call cleanup anyway for consistency, it handles nulls
    }
}

// Re-attaching MediaRecorder handlers in one place
function attachMediaRecorderHandlers(recorder, options, originalMutedStateFlag, audioCaptureSuccessFlag) {
    logDebug("Attaching MediaRecorder handlers.");
    const recordedChunks = []; // Ensure chunks are local to this recording session

    recorder.onstart = () => {
        logDebug('MediaRecorder started. state=', recorder.state, 'mime=', options.mimeType);
    };

    recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
            recordedChunks.push(event.data);
        }
    };

    recorder.onstop = () => {
        DEBUG_ENABLED = true; // re-enable debug after generation
        logDebug("MediaRecorder onstop triggered. chunks=", recordedChunks.length);

        // NEW: Warm-up helper to prime the output video decoder to avoid initial freeze/lag
        const warmUpOutputVideo = async (videoEl, blobUrl, audioCaptured) => {
            try {
                // Apply attributes that help with decoder initialization
                videoEl.preload = 'auto';
                videoEl.playsInline = true;
                videoEl.crossOrigin = 'anonymous';
                videoEl.src = blobUrl;

                // Force load metadata and first frames
                videoEl.load();

                // Temporarily mute to allow autoplay-based warm-up in restrictive browsers
                const originalMuted = videoEl.muted;
                if (!audioCaptured) {
                    // If no audio was captured, ensure it's muted so autoplay play() won't be blocked
                    videoEl.muted = true;
                }

                // Try to play then pause to allocate decoder resources; swallow rejections
                const p = videoEl.play();
                if (p && typeof p.then === 'function') {
                    await p.then(() => {
                        try { videoEl.pause(); } catch (e) {}
                    }).catch(() => {
                        // Autoplay blocked; still likely primed on canplay
                    });
                }

                // Restore muted state appropriate for playback
                videoEl.muted = audioCaptured ? false : true;
            } catch (e) {
                logDebug("Warm-up of output video failed:", e);
            }
        };

        // NEW: Immediately stop any Web Audio / Tone.js playback to avoid audio tail after recording
        stopAllAudioPlayback();

        console.log(`Number of recorded chunks: ${recordedChunks.length}`);

        if (recordedChunks.length === 0) {
            statusDiv.textContent = 'Error: No video data was recorded.';
            logDebug("No data recorded.");
            manualCleanupAfterStopFailure(); // Ensure state is clean even if onstop fires with no data
            return;
        }

        logDebug("Creating Blob from recorded chunks.");
        const blob = new Blob(recordedChunks, { type: options.mimeType });
        let url = URL.createObjectURL(blob);
        logDebug(`Blob created. URL: ${url}`);

        // If the recorded mimeType is not an MP4 container, attempt to transcode to MP4 with ffmpeg.wasm
        (async () => {
            // prefer MP4 download when possible; only try when ffmpeg available and input is not already mp4
            const wantedExt = 'mp4';
            const isAlreadyMp4 = options.mimeType && options.mimeType.toLowerCase().includes('mp4');
            if (!isAlreadyMp4) {
                statusDiv.textContent = 'Converting recorded video to MP4 (this may take a moment)...';
                const converted = await transcodeBlobToMp4(blob);
                if (converted) {
                    try {
                        URL.revokeObjectURL(url);
                    } catch (e) {}
                    url = URL.createObjectURL(converted);
                    logDebug("FFmpeg conversion succeeded. New URL:", url);
                    // update download link to MP4
                    downloadBtn.href = url;
                    downloadBtn.download = `ihtx-${effectSelect.value}-power${powerSelect.value}.${wantedExt}`;
                    outputVideo.src = url;
                    outputVideo.muted = audioCaptureSuccessFlag ? false : true;
                    statusDiv.textContent = audioCaptureSuccessFlag
                        ? 'Generation complete! Your MP4 video with audio is ready. Tap Download to save it.'
                        : 'Generation complete! MP4 video is ready (no audio captured). Tap Download to save it.';
                    outputArea.style.display = 'block';
                    manualCleanupAfterStopFailure();
                    return;
                } else {
                    logDebug("FFmpeg conversion failed or returned null; keeping original recorded blob and URL.");
                    // fall through to use original blob/url
                    try {
                        outputVideo.src = url;
                        outputVideo.muted = audioCaptureSuccessFlag ? false : true;
                    } catch(e){}
                }
            } else {
                // already mp4, assign directly
                try {
                    outputVideo.src = url;
                    outputVideo.muted = audioCaptureSuccessFlag ? false : true;
                } catch(e){}
            }
        })();

        // Use the warm-up helper to set source and prime decoder (replaces direct src assignment + ad-hoc warmup)
        (async () => {
            try {
                await warmUpOutputVideo(outputVideo, url, audioCaptureSuccessFlag);
            } catch (e) {
                logDebug("Error during output warm-up:", e);
                // Fallback: assign src directly
                outputVideo.src = url;
                outputVideo.muted = audioCaptureSuccessFlag ? false : true;
            }
        })();

        // Ensure unmute state based on capture
        // NOTE: warmUpOutputVideo will set src and muted as appropriate; we still set as a fallback
        outputVideo.muted = audioCaptureSuccessFlag ? false : true;
        logDebug(`Output video muted state set to: ${outputVideo.muted}`);

        // PRIME / PRELOAD the output video to reduce playback lag on first play
        try {
            outputVideo.preload = 'auto';
            // Force the browser to load metadata + first frames so playback is responsive
            // (Warm-up helper already called, but also call load() defensively)
            outputVideo.load();
            // A tiny timeout to nudge the decoder to initialize currentTime without autoplay
            setTimeout(() => {
                try { outputVideo.currentTime = 0; } catch (e) { /* swallow */ }
            }, 50);

            // NEW: attempt to warm up the decoder by briefly playing then pausing when the video is ready
            const tryWarmup = () => {
                try {
                    // Attempt an unobtrusive play -> pause to force decoder initialization.
                    const p = outputVideo.play();
                    if (p && typeof p.then === 'function') {
                        p.then(() => {
                            try { outputVideo.pause(); } catch (e) {}
                        }).catch(() => {
                            /* autoplay prevented; decoder will still often have been primed on canplay */
                        });
                    }
                } catch (e) {
                    // Non-fatal if play() throws
                }
            };

            // If canplay already fired, run warmup immediately, otherwise attach one-shot listener.
            if (outputVideo.readyState >= HTMLMediaElement.HAVE_ENOUGH_DATA) {
                tryWarmup();
            } else {
                const onCanPlay = () => {
                    outputVideo.removeEventListener('canplay', onCanPlay);
                    tryWarmup();
                };
                outputVideo.addEventListener('canplay', onCanPlay);
            }
        } catch (e) {
            logDebug("Priming output video failed:", e);
        }

        downloadBtn.href = url;
        const extension = options.mimeType.toLowerCase().includes('mp4') ? 'mp4' : 'webm';
        downloadBtn.download = `ihtx-${effectSelect.value}-power${powerSelect.value}.${extension}`;

        statusDiv.textContent = audioCaptureSuccessFlag
            ? 'Generation complete! Your video with audio is ready. Tap Download to save it.'
            : 'Generation complete! Video is ready (no audio captured). Tap Download to save it.';
        outputArea.style.display = 'block';
        // downloadBtn.click();
        logDebug("Download link prepared (manual click required).");

        manualCleanupAfterStopFailure();
        logDebug("onstop processing complete.");
    };

    recorder.onerror = (event) => {
        DEBUG_ENABLED = true; // re-enable debug on error
        logDebug("MediaRecorder error:", event.error);
        console.error("MediaRecorder error:", event.error);
        statusDiv.textContent = `MediaRecorder error: ${event.error.name || event.error}. Generation failed.`;
        manualCleanupAfterStopFailure();
    };
    logDebug("MediaRecorder handlers attached.");
}

// removed function getPitchShiftForEffect() {} // now imported from ./src/effects.js

// Add event listener for video 'ended' event to handle looping for non-reverse effects
sourceVideo.addEventListener('ended', () => {
    logDebug(`Source video ended. isGenerating: ${isGenerating}, currentLoop: ${currentLoop}, power: ${powerSelect.value}`);
    const effect = effectSelect.value;
    const power = parseInt(powerSelect.value, 10);

    // Only proceed if generation is active and MediaRecorder is recording
    if (isGenerating && mediaRecorder && mediaRecorder.state === 'recording') {
        if (effect !== 'reverse') { // Logic for live-processed effects (not reverse)
            if (currentLoop < power - 1) { // If more loops are needed
                // don't stopAllAudioPlayback() here — updateAudioRoutingForLoop() will handle audio handoff
                currentLoop++; // Increment loop counter for the NEXT loop that is about to start

                // NEW: advance overlay loop counters for the upcoming loop
                const pwr = parseInt(powerSelect.value, 10);
                const o1Active = overlay1ActiveAtLoop(currentLoop, pwr);
                const o2Active = overlay2ActiveAtLoop(currentLoop, pwr);
                overlay1Loop = o1Active ? (overlay1Loop > 0 ? overlay1Loop + 1 : 1) : 0;
                overlay2Loop = o2Active ? (overlay2Loop > 0 ? overlay2Loop + 1 : 1) : 0;

                // Determine target pitch(es) for the next loop
                const targetPitches = getPitchShiftForEffect(effect, power, currentLoop, getCustomParams());
                // Update status
                const pitchDisplay = targetPitches.length > 5 ? `${targetPitches.length} voices` : formatSemitoneList(targetPitches);
                statusDiv.textContent = `Exporting Loop ${currentLoop + 1}/${power} (${pitchDisplay})`;

                // Seek to the beginning for the next loop
                sourceVideo.currentTime = 0;
                lastFrameTime = -1; // Reset last frame time tracker to ensure the first frame of the new loop is processed

                // Start playing again to resume processing via rVFC
                logDebug(`Attempting to play source video for loop ${currentLoop + 1}.`);

                let audioStarted = false;
                const startAudio = () => {
                    if (audioStarted) return;
                    audioStarted = true;
                    if (audioBuffer || overlay1Video || overlay2Video) {
                        const tp = getPitchShiftForEffect(effect, power, currentLoop);
                        updateAudioRoutingForLoop(effect, currentLoop, power, tp);
                    }
                };

                sourceVideo.play().then(() => {
                    logDebug(`Video reset and playing for loop ${currentLoop + 1}. Muted: ${sourceVideo.muted}`);

                    const onFirstFrame = (now, metadata) => {
                        if (!isGenerating) return;
                        logDebug(`Loop ${currentLoop + 1} first frame received, starting audio.`);
                        startAudio();
                        processFrame(now, metadata);
                    };

                    if ('requestVideoFrameCallback' in sourceVideo) {
                        sourceVideo.requestVideoFrameCallback(onFirstFrame);
                    } else {
                        requestAnimationFrame(() => onFirstFrame(performance.now()));
                    }
                }).catch(e => {
                    logDebug("Error restarting video playback for loop:", e);
                    stopGeneration(); // Use the generalized stop function
                    statusDiv.textContent = `Error restarting video for loop ${currentLoop + 1}: ${e.message}. Stopping generation.`;
                });
            } else { // All loops completed for this non-reverse effect
                logDebug(`Finished ${power} loops for non-reverse effect. Stopping MediaRecorder.`);
                stopAllAudioPlayback(); // Stop audio for the final time
                if (mediaRecorder.state !== 'inactive') {
                    mediaRecorder.stop(); // This triggers onstop
                    statusDiv.textContent = `Finalizing video...`;
                } else {
                    logDebug("MediaRecorder was already inactive when trying to stop after all non-reverse loops.");
                    stopGeneration(); // Defensive stop
                }
            }
        } else {
            logDebug("Source video ended, but Reverse effect is active. 'ended' event ignored for Reverse (buffering completed elsewhere).");
        }
    } else {
        logDebug("Video ended, but not generating. Standard video end.");
    }
});

// File input handling: load selected video into the video element
videoFile.addEventListener('change', async () => {
    const file = videoFile.files && videoFile.files[0];
    if (!file) {
        statusDiv.textContent = 'No file selected.';
        generateBtn.disabled = true;
        return;
    }
    if (!file.type || !file.type.startsWith('video/')) {
        statusDiv.textContent = 'Please select a valid video file.';
        generateBtn.disabled = true;
        return;
    }

    // If a generation is in progress, stop it
    if (isGenerating) {
        stopGeneration();
    }

    // Revoke previous object URL if any
    if (currentObjectURL) {
        URL.revokeObjectURL(currentObjectURL);
        currentObjectURL = null;
    }

    // Reset UI/output
    outputArea.style.display = 'none';
    outputVideo.removeAttribute('src');
    outputVideo.load();
    downloadBtn.href = '#';
    downloadBtn.removeAttribute('download');
    statusDiv.textContent = 'Loading video...';
    debugLog.textContent = ''; // clear diagnostics per new file

    // Assign new object URL
    const url = URL.createObjectURL(file);
    currentObjectURL = url;
    sourceVideo.src = url;
    sourceVideo.preload = 'metadata';
    sourceVideo.muted = true; // keep muted on load
    sourceVideo.playsInline = true;

    // Clear prior duration and disable generate until metadata arrives
    videoDuration = 0;
    generateBtn.disabled = true;
    stopBtn.disabled = true;

    // Reset overlays when a new main video is loaded
    resetOverlays();

    // Try to decode audio upfront so pitch (without speed) works and to avoid silent output
    audioBuffer = null;
    toneAudioBuffer = null;
    reversedAudioBuffer = null;
    try {
        if (!audioContext || audioContext.state === 'closed') {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            logDebug(`AudioContext created. State: ${audioContext.state}`);
        }
        // Ensure resume on user gesture may be needed later; decodeAudioData does not require running state.
        const arrayBuf = await file.arrayBuffer();
        try {
            // Safari requires callback form sometimes
            audioBuffer = await audioContext.decodeAudioData(arrayBuf.slice(0));
        } catch (e) {
            // Fallback to callback style
            audioBuffer = await new Promise((resolve, reject) => {
                audioContext.decodeAudioData(arrayBuf.slice(0), resolve, reject);
            });
        }
        logDebug('Audio decoded:', {
            duration: audioBuffer.duration,
            sampleRate: audioBuffer.sampleRate,
            channels: audioBuffer.numberOfChannels
        });
    } catch (e) {
        logDebug('Audio decode failed (will proceed muted):', e.message || e);
        audioBuffer = null;
    }

    // Handlers
    sourceVideo.onloadedmetadata = () => {
        try {
            // Read the actual duration but then override to the requested IHTX source duration (0.41s)
            let detectedDuration = sourceVideo.duration;
            if (!isFinite(detectedDuration) || detectedDuration <= 0) {
                statusDiv.textContent = 'Could not read video duration. Please try a different file.';
                generateBtn.disabled = true;
                stopBtn.disabled = true;
                return;
            }

            // Override duration for IHTX source workflows to a fixed 0.41s as requested
            videoDuration = 0.41;
            logDebug('Original detected duration:', detectedDuration, '-> overridden videoDuration:', videoDuration);

            // Prepare canvas sizes
            canvasWidth = processingCanvas.width = sourceVideo.videoWidth || 0;
            canvasHeight = processingCanvas.height = sourceVideo.videoHeight || 0;
            canvasCtx = processingCanvas.getContext('2d');

            if (canvasWidth === 0 || canvasHeight === 0) {
                statusDiv.textContent = 'Video metadata loaded, but size is 0. Try reloading the file.';
                generateBtn.disabled = true;
                stopBtn.disabled = true;
                return;
            }

            statusDiv.textContent = `Video loaded: ${Math.round(canvasWidth)}x${Math.round(canvasHeight)}, ${videoDuration.toFixed(2)}s (overridden).`;
            generateBtn.disabled = false;
            stopBtn.disabled = true;
            logDebug('Video readyState:', sourceVideo.readyState, 'duration (overridden):', videoDuration);
        } catch (e) {
            console.error('Error in onloadedmetadata:', e);
            statusDiv.textContent = 'Error while preparing the video. Please try again.';
            generateBtn.disabled = true;
            stopBtn.disabled = true;
        }
    };

    sourceVideo.onerror = (e) => {
        statusDiv.textContent = 'Failed to load the selected video. Please choose a different file.';
        generateBtn.disabled = true;
        stopBtn.disabled = true;
        logDebug('Video element error:', e?.message || e);
    };

    // If metadata is already available (some browsers), trigger handler
    setTimeout(() => {
        if (sourceVideo.readyState >= HTMLMediaElement.HAVE_METADATA && isFinite(sourceVideo.duration) && sourceVideo.duration > 0) {
            if (typeof sourceVideo.onloadedmetadata === 'function') {
                sourceVideo.onloadedmetadata();
            }
        }
    }, 0);
});

// Helper to get custom parameters from UI
function getCustomParams() {
    return {
        fisheyeStrength: parseFloat(customFisheyeStrength.value),
        fisheyeSize: parseFloat(customFisheyeSize.value),
        hueShift: parseFloat(customHueShift.value),
        pitch: parseFloat(customPitchShift.value),
        invert: customInvert.checked,
        // Granular pitch processing params (window size in seconds, fft size, overlap)
        pitchWindow: (typeof document !== 'undefined' && document.getElementById('pitchWindow')) ? parseFloat(document.getElementById('pitchWindow').value) : 0.12,
        fftSize: (typeof document !== 'undefined' && document.getElementById('pitchFft')) ? parseInt(document.getElementById('pitchFft').value, 10) : 1024,
        overlap: (typeof document !== 'undefined' && document.getElementById('pitchOverlap')) ? parseInt(document.getElementById('pitchOverlap').value, 10) : 4
    };
}



// Sync range/number labels and trigger preview updates (including granular pitch controls)
const granularWindow = document.getElementById('pitchWindow');
const granularFft = document.getElementById('pitchFft');
const granularOverlap = document.getElementById('pitchOverlap');

const syncInputs = [
    customFisheyeStrength,
    customFisheyeSize,
    customHueShift,
    customPitchShift,
    granularWindow,
    granularFft,
    granularOverlap
];

// Update corresponding value badges and trigger a preview update on change
syncInputs.forEach(input => {
    if (!input) return;
    const valDisplay = document.getElementById(input.id + 'Val');
    const handler = () => {
        if (valDisplay) {
            // normalize displayed formatting for integers vs floats
            if (input.type === 'number' || input.type === 'text') {
                valDisplay.textContent = input.value;
            } else {
                valDisplay.textContent = input.value;
            }
        }
        triggerSinglePreviewUpdate();
    };
    input.addEventListener('input', handler);
    input.addEventListener('change', handler);
    // initialize display
    handler();
});

customInvert.addEventListener('change', triggerSinglePreviewUpdate);

// --- Preview & Processing Loop ---
let isPreviewLoopRunning = false;

function processFrame(now, metadata) {
    // Throttle heavy processing to MIN_FRAME_INTERVAL_MS to avoid doing work more often than MAX_FPS.
    // 'now' may be a DOMHighResTimeStamp from rVFC; normalize to milliseconds.
    const wallNow = (typeof now === 'number') ? now : performance.now();
    if (lastProcessWallTimeMs && (wallNow - lastProcessWallTimeMs) < MIN_FRAME_INTERVAL_MS) {
        // schedule next frame without reprocessing to keep UI responsive
        scheduleNextFrame();
        return;
    }
    lastProcessWallTimeMs = wallNow;

    const effect = effectSelect.value;
    const isNormal = effect === 'normal';
    
    // Manage UI visibility for preview
    if (!isGenerating) {
        if (isNormal) {
            sourceVideo.style.display = 'inline-block';
            processingCanvas.style.display = 'none';
            document.getElementById('videoHeading').textContent = 'Source Video';
            document.getElementById('previewHint').style.display = 'none';
            isPreviewLoopRunning = false;
            return; // Stop loop if no effect
        } else {
            sourceVideo.style.display = 'none';
            processingCanvas.style.display = 'inline-block';
            document.getElementById('videoHeading').textContent = 'Effect Preview';
            document.getElementById('previewHint').style.display = 'block';
        }
    }

    // Check if we should continue the loop
    if (!isGenerating && isNormal) {
        isPreviewLoopRunning = false;
        return;
    }

    // Skip if we already processed this exact frame time during generation to avoid duplicate effort
    if (isGenerating && metadata && metadata.mediaTime === lastFrameTime) {
        scheduleNextFrame();
        return;
    }
    if (metadata) lastFrameTime = metadata.mediaTime;

    const power = parseInt(powerSelect.value, 10);
    const currentTime = sourceVideo.currentTime;

    // Draw video to canvas
    if (sourceVideo.readyState >= 2) {
        canvasCtx.drawImage(sourceVideo, 0, 0, canvasWidth, canvasHeight);

        // Apply visual effects if needed.
        // Performance optimization: only run the expensive per-pixel processing during actual generation.
        // For preview (when not recording), use a fast drawImage fallback to avoid getImageData / putImageData overhead.
        if (effect !== 'normal') {
            if (isGenerating) {
                // Full processing for export/recording
                // Downscale to offscreen canvas to limit pixel processing work on large frames.
                const longest = Math.max(canvasWidth, canvasHeight) || 1;
                const scale = Math.min(1, MAX_PROCESS_DIMENSION / longest);

                if (scale < 1) {
                    // configure offscreen to scaled dimensions
                    const sw = Math.max(1, Math.round(canvasWidth * scale));
                    const sh = Math.max(1, Math.round(canvasHeight * scale));
                    if (offscreenCanvas.width !== sw || offscreenCanvas.height !== sh) {
                        offscreenCanvas.width = sw;
                        offscreenCanvas.height = sh;
                    }
                    // draw scaled source into offscreen, process there, then upscale back
                    offscreenCtx.clearRect(0, 0, sw, sh);
                    offscreenCtx.drawImage(processingCanvas, 0, 0, canvasWidth, canvasHeight, 0, 0, sw, sh);

                    const originalImageData = offscreenCtx.getImageData(0, 0, sw, sh);
                    const processedImageData = applyComplexEffect(
                        originalImageData,
                        effect,
                        power,
                        currentLoop,
                        currentTime,
                        videoDuration,
                        getCustomParams()
                    );
                    // write processed small image then upscale to main canvas for capture
                    offscreenCtx.putImageData(processedImageData, 0, 0);
                    // draw back to main canvas at full size (this upsamples the processed result)
                    canvasCtx.clearRect(0, 0, canvasWidth, canvasHeight);
                    canvasCtx.drawImage(offscreenCanvas, 0, 0, sw, sh, 0, 0, canvasWidth, canvasHeight);
                } else {
                    // small enough, process in-place as before
                    const originalImageData = canvasCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                    const processedImageData = applyComplexEffect(
                        originalImageData,
                        effect,
                        power,
                        currentLoop, // during generation we use the real currentLoop
                        currentTime,
                        videoDuration,
                        getCustomParams()
                    );
                    canvasCtx.putImageData(processedImageData, 0, 0);
                }
            } else {
                // Fast preview path: draw raw frame (no heavy per-pixel ops) to keep preview smooth
            }
        }

        // Draw overlays on top (only for generation or if user wants to see them in preview)
        drawOverlays(canvasCtx, isGenerating ? currentLoop : 0, power, currentTime);
    }

    scheduleNextFrame();
}

function scheduleNextFrame() {
    if ('requestVideoFrameCallback' in sourceVideo) {
        sourceVideo.requestVideoFrameCallback(processFrame);
    } else {
        requestAnimationFrame(() => processFrame(performance.now()));
    }
}

// Ensure preview starts when effect is changed
effectSelect.addEventListener('change', () => {
    if (effectSelect.value === 'custom') {
        customTab.style.display = 'block';
    } else {
        customTab.style.display = 'none';
    }

    // Auto-populate custom params when selecting specific presets to make tweaking easier.
    if (effectSelect.value === 'c_major') {
        // C Major: large wave preset, hue rotate ~100.408°, invert, +2 semitone pitch
        customHueShift.value = '100.408';
        document.getElementById('customHueShiftVal').textContent = '100.408';
        customPitchShift.value = '2';
        document.getElementById('customPitchShiftVal').textContent = '2';
        // ensure custom tab is visible for quick adjustments
        customTab.style.display = 'block';
    }

    // Prefill controls for 1-DXI preset to make quick adjustments easier.
    if (effectSelect.value === '1-dxi') {
        // The effect uses a normalized HSL hue change ~0.800 (288°), but keep UI-safe values and open custom tab.
        // We'll preset the pitch to +7.5 (as requested) and show the custom panel.
        customPitchShift.value = '7.5';
        document.getElementById('customPitchShiftVal').textContent = '7.5';
        // Show custom tab so users can tweak jitter/fft/etc.
        customTab.style.display = 'block';
        // Leave hue slider unchanged (most presets that require >180° are handled in effects.js),
        // but provide a hint by not forcing an out-of-range hue value into the UI slider.
    }

    if (effectSelect.value !== 'normal' && !isPreviewLoopRunning && !isGenerating) {
        isPreviewLoopRunning = true;
        scheduleNextFrame();
    }
});

// Trigger a single frame update if video is paused but parameters change
function triggerSinglePreviewUpdate() {
    if (!isGenerating && effectSelect.value !== 'normal' && sourceVideo.paused) {
        processFrame(performance.now());
    }
}

// Added robustness: Check if processing is stuck every second during generation
let stuckCheckInterval = setInterval(() => {
    if (isGenerating && mediaRecorder && mediaRecorder.state === 'recording') {
        if (sourceVideo.paused && !sourceVideo.ended && effectSelect.value !== 'reverse') {
            logDebug("Detected video pause during generation. Attempting resume...");
            sourceVideo.play().catch(e => logDebug("Auto-resume failed:", e));
        }
    }
}, 1000);

generateBtn.addEventListener('click', async () => { // Keep async here
    DEBUG_ENABLED = false; // suppress debug spam during generation
    const effect = effectSelect.value;
    const power = parseInt(powerSelect.value, 10);

    if (!sourceVideo.src || videoDuration <= 0 || !isFinite(videoDuration)) {
        statusDiv.textContent = 'Please import a valid video first.';
        console.warn("Attempted generation without a valid video source.");
        return;
    }

    if (isGenerating) {
        console.warn("Generation already in progress. Ignoring click.");
        return;
    }

    // Basic MediaRecorder support check before doing heavy work
    if (typeof MediaRecorder === 'undefined') {
        statusDiv.textContent = 'MediaRecorder is not supported in this browser.';
        logDebug('MediaRecorder unsupported.');
        return;
    }

    logDebug(`Starting generation: Effect=${effect}, Power=${power}`);

    // Ensure any existing timeout for buffered frames is cleared on new generation start
    if (frameDrawTimeoutId) {
        clearTimeout(frameDrawTimeoutId);
        frameDrawTimeoutId = null;
    }

    // Ensure audio context is properly initialized before starting
    if (!audioContext || audioContext.state === 'closed') {
        try {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            logDebug(`AudioContext created. State: ${audioContext.state}`);
        } catch (e) {
            console.error("Failed to create AudioContext:", e);
            audioContext = null;
        }
    }

    // Ensure audio context is resumed on a user gesture for mobile/autoplay policies
    if (audioContext && audioContext.state === 'suspended') {
        try {
            await audioContext.resume();
            logDebug(`AudioContext resumed. State: ${audioContext.state}`);
        } catch (e) {
            console.error("Failed to resume AudioContext:", e);
            audioContext = null;
        }
    }

    // Prepare Tone.js if we have an audio buffer and plan to pitch shift without speed changes
    if (audioBuffer) {
        await ensureToneReady();
    } else {
        toneReady = false;
        toneAudioBuffer = null;
    }

    // Reset state for new generation
    isGenerating = true; // Set flag
    stopBtn.disabled = false;
    currentLoop = 0; // Reset loop counter for a new generation
    // NEW: reset overlay loop counters and initialize for loop 0
    overlay1Loop = 0; overlay2Loop = 0;
    {
        const pwr = parseInt(powerSelect.value, 10);
        if (overlay1ActiveAtLoop(0, pwr)) overlay1Loop = 1;
        if (overlay2ActiveAtLoop(0, pwr)) overlay2Loop = 1;
    }
    lastFrameTime = -1; // Reset frame time tracker for non-reverse
    frameBuffer = []; // Clear buffer
    estimatedFPS = 30; // Reset estimated FPS
    stopAllAudioPlayback(); // Ensure no lingering audio nodes
    
    // Initial status message - include integer semitone display
    const pitchesForLoop0 = getPitchShiftForEffect(effect, power, 0, getCustomParams());
    let initialStatusMessage = `Generating IHTX with ${effect} effect and power ${power}... This may take some time.`;
    if (pitchesForLoop0.length > 0) {
        const pitchDisplay = pitchesForLoop0.length > 5 ? `${pitchesForLoop0.length} voices` : formatSemitoneList(pitchesForLoop0);
        initialStatusMessage += ` (${pitchDisplay})`;
    }
    statusDiv.textContent = initialStatusMessage;

    generateBtn.disabled = true;
    outputArea.style.display = 'none';
    // Reset download link before starting new generation
    downloadBtn.href = '#';
    downloadBtn.removeAttribute('download');

    /*
     * Force export capture canvas to 360p (640x360) so MediaRecorder exports at 360p;
     * processing and previews continue to use the higher-resolution source where applicable,
     * but the recorded canvas will be 640x360 at MAX_FPS.
     */
    canvasWidth = processingCanvas.width = 640;
    canvasHeight = processingCanvas.height = 360;
    canvasCtx = processingCanvas.getContext('2d');
    // Keep a scaled preview/offscreen path available if we need to draw full-res previews elsewhere.

    // --- Audio Track Capture Setup ---
    let combinedStream; // Will hold the stream for MediaRecorder
    let audioTrackSuccessfullyCaptured = false;
    const videoStream = processingCanvas.captureStream(MAX_FPS); // use MAX_FPS for smoother final IHTX video
    logDebug("Canvas captureStream created.");

    // Mute the source video during processing. Its audio is now handled by AudioBufferSourceNode.
    originalSourceMutedState = sourceVideo.muted; // Re-capture state just before generation starts
    sourceVideo.muted = true; // Ensure source is muted during processing
    logDebug(`Source video muted for generation. Original state was: ${originalSourceMutedState}`);

    if (audioBuffer) { // Proceed with audio setup only if audio buffer was successfully loaded
        try {
            // Ensure audio context and destination node are properly set up
            if (!audioContext || audioContext.state === 'closed') {
                throw new Error("AudioContext is not available");
            }

            // Bind Tone to our audioContext once (ensureToneReady already attempted)
            if (window.Tone) {
                await ensureToneReady();
            }

            // Create a MediaStreamAudioDestinationNode to capture the processed/played audio
            destinationNode = audioContext.createMediaStreamDestination();
            logDebug("MediaStreamAudioDestinationNode created.");

            // Explicitly get the video track from the canvas stream
            const canvasVideoTrack = videoStream.getVideoTracks()[0];
            if (!canvasVideoTrack) {
                throw new Error("Canvas captureStream did not produce a video track.");
            }
            logDebug("Canvas video track obtained.");

            // Explicitly get the audio track from the MediaStreamAudioDestinationNode's stream
            const audioTracksFromDestination = destinationNode.stream.getAudioTracks();
            const destinationAudioTrack = audioTracksFromDestination[0];

            if (!destinationAudioTrack) {
                logDebug("MediaStreamAudioDestinationNode's stream has no audio tracks. This is unexpected.");
                throw new Error("MediaStreamAudioDestinationNode did not produce an audio track.");
            }
            logDebug("Audio destination track obtained.");
            
            // Create the combined stream by explicitly adding tracks
            combinedStream = new MediaStream();
            combinedStream.addTrack(canvasVideoTrack);
            combinedStream.addTrack(destinationAudioTrack);
            
            audioTrackSuccessfullyCaptured = true;
            logDebug("Combined stream created by adding canvas video track and audio destination's audio track.");
            logDebug(`Combined stream has ${combinedStream.getVideoTracks().length} video tracks and ${combinedStream.getAudioTracks().length} audio tracks.`); // Added logging

        } catch (e) {
            logDebug("Error during Web Audio setup with AudioBuffer:", e);
            logDebug("Could not capture or process audio track due to error. Output video will be muted.");
            combinedStream = videoStream; // Fallback to video-only stream
            audioTrackSuccessfullyCaptured = false; // Explicitly set false
            // Defensive cleanup if audioContext setup failed midway
            if (audioContext) {
                if (destinationNode) destinationNode.disconnect();
            }
            destinationNode = null;
            stopAllAudioPlayback(); // Ensure any stray nodes are cleared
        }
    } else {
        logDebug("No audio buffer available. Output video will be muted.");
        combinedStream = videoStream; // Just use the video stream
        audioTrackSuccessfullyCaptured = false; // Explicitly set false
        // Ensure audioContext and nodes are null if no audio processing is done
        destinationNode = null;
        stopAllAudioPlayback(); // Ensure any stray nodes are cleared
    }

    // --- MediaRecorder Setup ---
    // Options for MediaRecorder - prioritize MP4 formats for better compatibility
    const supportedTypes = [
        'video/mp4',
        'video/mp4;codecs=h264',
        'video/mp4;codecs=avc1',
        'video/mp4;codecs=hevc',
        'video/webm;codecs=h264',
        'video/webm;codecs=vp9',
        'video/webm;codecs=vp8',
        'video/webm'
    ];

    let selectedMimeType = null;
    for (const type of supportedTypes) {
        if (MediaRecorder.isTypeSupported(type)) {
            selectedMimeType = type;
            break;
        }
    }

    if (!selectedMimeType) {
        statusDiv.textContent = 'Your browser does not support any recognized video recording formats.';
        logDebug("No supported mimeType found for MediaRecorder.");
        stopGeneration();
        return;
    }

    const options = { mimeType: selectedMimeType };
    // Increase bitrates for clearer output while keeping the UI unchanged
    options.videoBitsPerSecond = 2 * 1024 * 1024; // 2 Mbps for lower processing load
    options.audioBitsPerSecond = 192 * 1024; // 192 Kbps for clearer audio while keeping CPU usage reasonable
    logDebug(`Using mimeType: ${options.mimeType} with videoBitsPerSecond: ${options.videoBitsPerSecond} and audioBitsPerSecond: ${options.audioBitsPerSecond}`);

    // Initialize mediaRecorder with the combined stream (video + audio if captured and processed)
    try {
        mediaRecorder = new MediaRecorder(combinedStream, options);
        logDebug("MediaRecorder initialized.");
        logDebug(`MediaRecorder stream has ${mediaRecorder.stream.getVideoTracks().length} video tracks and ${mediaRecorder.stream.getAudioTracks().length} audio tracks.`); // Added logging
        // Attach handlers BEFORE starting
        // Pass the initially captured muted state flag to the handlers
        attachMediaRecorderHandlers(mediaRecorder, options, originalSourceMutedState, audioTrackSuccessfullyCaptured);
    } catch (e) {
        console.error("Failed to initialize MediaRecorder:", e);
        statusDiv.textContent = `Failed to initialize MediaRecorder: ${e.message}. Generation failed.`;
        stopGeneration(); // Stop generation process
        return; // Stop generation process
    }

    // --- Effect Application Logic ---
    const currentEffect = effectSelect.value;

    if (currentEffect === 'reverse') {
        statusDiv.textContent = `Buffering video frames for Reverse effect (duration: ${videoDuration.toFixed(2)}s)...`;
        logDebug("Starting frame buffering for Reverse effect.");
        frameBuffer = [];
        sourceVideo.pause();
        logDebug("Source video paused and reset for buffering.");

        let bufferingComplete = false;
        let framesBuffered = 0;
        let currentBufferTime = 0;
        // Buffer fewer frames to reduce memory and CPU spikes; align to current MAX_FPS for consistency
        const timeIncrementHint = 1 / Math.max(1, MAX_FPS);

        const performBufferingStep = () => {
            if (!isGenerating || bufferingComplete) {
                logDebug(`Buffering sequence cancelled or complete. isGenerating=${isGenerating}, bufferingComplete=${bufferingComplete}`);
                if (!isGenerating) stopGeneration(); // Ensure full cleanup
                return;
            }

            // Check if we've buffered enough frames (or reached the end of the video)
            // Changed condition to ensure buffering proceeds up to or exactly at videoDuration
            if (currentBufferTime >= videoDuration) {
                bufferingComplete = true;
                logDebug(`Buffering complete. Buffered ${frameBuffer.length} frames.`);
                estimatedFPS = frameBuffer.length > 0 && videoDuration > 0 ? frameBuffer.length / videoDuration : 30; // Update estimated FPS based on actual frames captured

                // Now start MediaRecorder and the recording loop for buffered frames
                setTimeout(() => {
                    if (isGenerating) {
                        if (mediaRecorder && mediaRecorder.state === 'inactive') {
                            // NEW: Pre-paint the first processed (reverse) frame before starting the recorder to avoid initial black
                            try {
                                const isReverseFirstLoop = ((currentLoop + 1) % 2 === 1);
                                const idx = isReverseFirstLoop ? (frameBuffer.length - 1) : 0;
                                if (idx >= 0) {
                                    const effectType = effectSelect.value;
                                    const powerVal = parseInt(powerSelect.value, 10);

                                    // If we buffered ImageBitmaps and no per-pixel effect is needed, draw directly to avoid ImageData conversion
                                    if (effectType === 'normal') {
                                        const bmp = frameBuffer[idx];
                                        if (bmp && typeof canvasCtx.drawImage === 'function') {
                                            canvasCtx.drawImage(bmp, 0, 0, canvasWidth, canvasHeight);
                                            drawOverlays(canvasCtx, 0, powerVal, 0);
                                            logDebug("Pre-painted first reverse frame (ImageBitmap) before recorder start.");
                                        }
                                    } else {
                                        // For visual effects, convert to ImageData and process
                                        let srcImageData;
                                        try {
                                            // draw bitmap then grab ImageData for processing
                                            if (frameBuffer[idx]) {
                                                canvasCtx.drawImage(frameBuffer[idx], 0, 0, canvasWidth, canvasHeight);
                                                srcImageData = canvasCtx.getImageData(0, 0, canvasWidth, canvasHeight);
                                            }
                                        } catch (e) {
                                            logDebug("Failed to draw buffered bitmap for pre-paint:", e);
                                        }
                                        if (srcImageData) {
                                            const processedImageData = applyComplexEffect(
                                                srcImageData,
                                                effectType,
                                                powerVal,
                                                0, // loopIndex
                                                0  // frameTime
                                            );
                                            canvasCtx.putImageData(processedImageData, 0, 0);
                                            drawOverlays(canvasCtx, 0, powerVal, 0);
                                            logDebug("Pre-painted first reverse frame (processed ImageData) before recorder start.");
                                        }
                                    }
                                }
                            } catch (e) {
                                logDebug("Failed to pre-paint first reverse frame:", e);
                            }

                            mediaRecorder.start();
                            if (mediaRecorder.state === 'recording') {
                                // start recording buffered frames immediately without extra delay
                                recordBufferedFrames(canvasCtx, mediaRecorder, canvasWidth, canvasHeight, power, estimatedFPS);
                            } else {
                                logDebug("MediaRecorder failed to start for buffered frames record phase.");
                                stopGeneration();
                            }
                        } else {
                            logDebug(`MediaRecorder state was not 'inactive' before starting buffered frames record phase: ${mediaRecorder ? mediaRecorder.state : 'null'}`);
                            stopGeneration(); // Defensive stop
                        }
                    } else {
                        logDebug("Generation cancelled after buffering, skipping record phase.");
                    }
                }, 50); // Small delay to ensure MediaRecorder starts
                return; // Exit buffering sequence
            }

            // Set the currentTime and wait for 'seeked' event
            sourceVideo.currentTime = currentBufferTime;
            statusDiv.textContent = `Buffering frame ${framesBuffered + 1}... (${(currentBufferTime / videoDuration * 100).toFixed(1)}%)`;

            const onSeekedHandler = async () => {
                sourceVideo.removeEventListener('seeked', onSeekedHandler);
                sourceVideo.removeEventListener('error', onErrorHandler);

                if (!isGenerating || bufferingComplete) {
                    if (!isGenerating) stopGeneration();
                    return;
                }

                // Draw into canvas and capture frame
                canvasCtx.drawImage(sourceVideo, 0, 0, canvasWidth, canvasHeight);

                // Instead of getImageData (which converts video into pixel arrays), create an ImageBitmap for efficient buffering.
                // This avoids heavy per-pixel conversion unless we need to process pixels later.
                try {
                    const bitmap = await createImageBitmap(processingCanvas);
                    frameBuffer.push(bitmap);
                } catch (e) {
                    // Fallback: if createImageBitmap fails, use getImageData (legacy)
                    logDebug("createImageBitmap failed, falling back to getImageData:", e);
                    frameBuffer.push(canvasCtx.getImageData(0, 0, canvasWidth, canvasHeight));
                }

                framesBuffered++;

                currentBufferTime = Math.min(videoDuration, currentBufferTime + timeIncrementHint);
                setTimeout(performBufferingStep, 0); // Use setTimeout 0 for next iteration in event loop
            };

            const onErrorHandler = (e) => {
                sourceVideo.removeEventListener('seeked', onSeekedHandler);
                sourceVideo.removeEventListener('error', onErrorHandler);
                logDebug("Video error during buffering seek:", e);
                stopGeneration();
            };

            sourceVideo.addEventListener('seeked', onSeekedHandler);
            sourceVideo.addEventListener('error', onErrorHandler); // Add error listener for robustness
        };

        // Initial call to start the buffering sequence
        sourceVideo.currentTime = 0; // Ensure we start from the beginning
        sourceVideo.load(); // Ensure video data is loaded for seeking

        // Wait for video to be ready for seeking (onloadeddata means enough data for first frame)
        const onLoadedDataHandler = () => {
            sourceVideo.removeEventListener('loadeddata', onLoadedDataHandler);
            if (isGenerating) {
                performBufferingStep();
            } else {
                logDebug("Generation cancelled before buffering started (loadeddata handler).");
            }
        };
        sourceVideo.addEventListener('loadeddata', onLoadedDataHandler);

        // Fallback if loadeddata already fired (e.g. video was cached/loaded very quickly)
        if (sourceVideo.readyState >= 2) { // HAVE_CURRENT_DATA or higher
            sourceVideo.removeEventListener('loadeddata', onLoadedDataHandler); // Remove if already fired
            if (isGenerating) {
                performBufferingStep();
            }
        }

    } else {
        // Handle Normal, G Major 4, G Major 7, Luig Group, G Major 74, Crying, G Major 5, Wiggle Major, Navynus Major effects
        // These effects are applied frame by frame during recording, driven by video playback.

        // Ensure video is paused and reset for processing
        sourceVideo.currentTime = 0;
        sourceVideo.pause(); // Pause initially, playback starts after recorder starts
        currentLoop = 0; // Reset loop counter for a new generation
        lastFrameTime = -1; // Track last video frame time for processing
        estimatedFPS = 30; // Reset estimated FPS - not strictly needed for live processing but good practice
        logDebug("Source video paused and reset for live processing.");

        // NEW: Pre-paint first processed frame before starting the MediaRecorder to avoid initial black
        paintFirstProcessedFrame(effectSelect.value, currentLoop, 0);

        // MediaRecorder setup is already done before this if/else block

        // Start the MediaRecorder
        logDebug("Starting MediaRecorder for live processing.");
        if (mediaRecorder && mediaRecorder.state === 'inactive') {
            mediaRecorder.start();
            logDebug(`MediaRecorder state after start (live): ${mediaRecorder.state}`);
            // Proceed only if recorder started successfully
            if (mediaRecorder.state === 'recording') {
                const targetPitches = getPitchShiftForEffect(effect, power, 0, getCustomParams());
                
                let audioStarted = false;
                const startAudio = () => {
                    if (audioStarted) return;
                    audioStarted = true;
                    if (audioBuffer || overlay1Video || overlay2Video) {
                        updateAudioRoutingForLoop(effectSelect.value, currentLoop, power, targetPitches);
                    }
                };

                sourceVideo.play().then(() => {
                    logDebug("Initial video playback started for processing.");
                    logDebug(`Source video playing. Muted: ${sourceVideo.muted}`);

                    const onFirstFrame = (now, metadata) => {
                        if (!isGenerating) return;
                        logDebug("First video frame received, starting audio.");
                        startAudio();
                        processFrame(now, metadata);
                    };

                    if ('requestVideoFrameCallback' in sourceVideo) {
                        sourceVideo.requestVideoFrameCallback(onFirstFrame);
                    } else {
                        requestAnimationFrame(() => onFirstFrame(performance.now()));
                    }
                }).catch(e => {
                    logDebug("Error starting initial video playback:", e);
                    stopGeneration();
                    statusDiv.textContent = `Error starting initial video playback: ${e.message}. Cannot start generation.`;
                });
            } else {
                logDebug("MediaRecorder failed to start for live processing.");
                stopGeneration(); // Error state
            }
        } else {
            logDebug(`MediaRecorder state was not 'inactive' before starting for live processing: ${mediaRecorder ? mediaRecorder.state : 'null'}`);
            stopGeneration();
        }
    }
});

async function recordBufferedFrames(ctx, mediaRecorder, width, height, power, estimatedFPS) {
    // If recording isn't active, abort and clean up any pending timers
    if (!isGenerating || !mediaRecorder || mediaRecorder.state !== 'recording') {
        logDebug(`Stopping drawBufferedFrame loop. State: isGenerating=${isGenerating}, recorder=${!!mediaRecorder}, recorder.state=${mediaRecorder ? mediaRecorder.state : 'N/A'}`);
        if (frameDrawTimeoutId) { cancelAnimationFrame(frameDrawTimeoutId); frameDrawTimeoutId = null; }
        if (isGenerating) stopGeneration();
        return;
    }

    if (frameBuffer.length === 0) {
        statusDiv.textContent = 'Error: No frames buffered for Reverse effect.';
        logDebug("Frame buffer is empty for reverse effect.");
        stopGeneration();
        return;
    }

    logDebug("MediaRecorder started for buffered frames (RAF-driven sync).");

    const numFrames = frameBuffer.length;
    const reverseStart = ((currentLoop + 1) % 2 === 1);
    let frameIndex = reverseStart ? (numFrames - 1) : 0;

    // Calculate the intended interval between frames in ms (use estimatedFPS)
    const frameIntervalMs = 1000 / Math.max(1, estimatedFPS || 13);

    // Anchor points for timing: record when the renderer started so we can compute expected frame times
    const startWallTime = performance.now();
    let renderedFramesTotal = 0; // total frames rendered across loops to compute export timeline

    let audioStartedForThisLoop = false;
    let rafId = null;

    const step = (now) => {
        if (!isGenerating || !mediaRecorder || mediaRecorder.state !== 'recording') {
            if (rafId) { cancelAnimationFrame(rafId); rafId = null; frameDrawTimeoutId = null; }
            if (isGenerating) stopGeneration();
            return;
        }

        // Compute how many frames we "should" have rendered by now relative to the startWallTime
        const elapsed = now - startWallTime;
        const expectedTotalFrames = Math.floor(elapsed / frameIntervalMs);

        // If we've already rendered up to expectedTotalFrames, skip until next RAF to avoid bursts
        if (renderedFramesTotal > expectedTotalFrames) {
            rafId = requestAnimationFrame(step);
            frameDrawTimeoutId = rafId;
            return;
        }

        // Render one logical frame (keep pace with expected frames)
        if (currentLoop < power) {
            const reverseDir = ((currentLoop + 1) % 2 === 1);
            const inBounds = reverseDir ? (frameIndex >= 0) : (frameIndex < numFrames);

            if (inBounds) {
                if (!audioStartedForThisLoop) {
                    audioStartedForThisLoop = true;
                    statusDiv.textContent = `^${power} = ${currentLoop + 1} Export Loop (${reverseDir ? 'Reverse' : 'Normal'})`;
                    if (audioBuffer || overlay1Video || overlay2Video) {
                        const tp = getPitchShiftForEffect(effectSelect.value, power, currentLoop, getCustomParams());
                        updateAudioRoutingForLoop(reverseDir ? 'reverse' : effectSelect.value, currentLoop, power, tp);
                    }
                }

                // Compute an estimated export time for effects based on total rendered frames
                const frameInExportSequence = renderedFramesTotal;
                const estimatedExportTime = frameInExportSequence / (estimatedFPS || 30);

                // Draw buffered bitmap and then apply pixel effect only when necessary
                try {
                    // Use offscreen downscale processing to reduce CPU work on large frames
                    const longest = Math.max(width, height) || 1;
                    const scale = Math.min(1, MAX_PROCESS_DIMENSION / longest);

                    if (scale < 1) {
                        const sw = Math.max(1, Math.round(width * scale));
                        const sh = Math.max(1, Math.round(height * scale));
                        if (offscreenCanvas.width !== sw || offscreenCanvas.height !== sh) {
                            offscreenCanvas.width = sw;
                            offscreenCanvas.height = sh;
                        }
                        // draw scaled buffered frame into offscreen
                        offscreenCtx.clearRect(0, 0, sw, sh);
                        offscreenCtx.drawImage(frameBuffer[frameIndex], 0, 0, frameBuffer[frameIndex].width || width, frameBuffer[frameIndex].height || height, 0, 0, sw, sh);

                        const currentPowerValue = parseInt(powerSelect.value, 10);
                        const effectType = effectSelect.value;
                        if (effectType !== 'normal') {
                            try {
                                const imgData = offscreenCtx.getImageData(0, 0, sw, sh);
                                const processedImageData = applyComplexEffect(
                                    imgData,
                                    effectType,
                                    currentPowerValue,
                                    currentLoop,
                                    estimatedExportTime,
                                    videoDuration,
                                    getCustomParams()
                                );
                                offscreenCtx.putImageData(processedImageData, 0, 0);
                            } catch (e) {
                                logDebug("Applying complex effect failed for buffered frame (offscreen):", e);
                            }
                        }

                        // upscale back to main ctx
                        try { ctx.clearRect(0, 0, width, height); ctx.drawImage(offscreenCanvas, 0, 0, sw, sh, 0, 0, width, height); } catch(e){ logDebug("Upscale draw failed:", e); }

                        // Draw overlays positioned to the current loop/time
                        try { drawOverlays(ctx, currentLoop, currentPowerValue, estimatedExportTime); } catch (e) { logDebug("drawOverlays error:", e); }
                    } else {
                        // small enough: draw directly and process in-place
                        ctx.drawImage(frameBuffer[frameIndex], 0, 0, width, height);

                        const currentPowerValue = parseInt(powerSelect.value, 10);
                        const effectType = effectSelect.value;

                        if (effectType !== 'normal') {
                            try {
                                const imgData = ctx.getImageData(0, 0, width, height);
                                const processedImageData = applyComplexEffect(
                                    imgData,
                                    effectType,
                                    currentPowerValue,
                                    currentLoop,
                                    estimatedExportTime,
                                    videoDuration,
                                    getCustomParams()
                                );
                                ctx.putImageData(processedImageData, 0, 0);
                            } catch (e) {
                                logDebug("Applying complex effect failed for buffered frame:", e);
                            }
                        }
                        try { drawOverlays(ctx, currentLoop, currentPowerValue, estimatedExportTime); } catch (e) { logDebug("drawOverlays error:", e); }
                    }
                } catch (e) {
                    logDebug("drawImage on buffered frame failed:", e);
                }

                // Advance frame index and bookkeeping
                frameIndex += (reverseDir ? -1 : 1);
                renderedFramesTotal++;

                // Schedule next RAF
                rafId = requestAnimationFrame(step);
                frameDrawTimeoutId = rafId;
            } else {
                // Completed one loop pass — don't stop audio here to avoid cutting between loops.
                currentLoop++;
                const pwr = parseInt(powerSelect.value, 10);
                const o1ActiveNext = overlay1ActiveAtLoop(currentLoop, pwr);
                const o2ActiveNext = overlay2ActiveAtLoop(currentLoop, pwr);
                overlay1Loop = o1ActiveNext ? (overlay1Loop > 0 ? overlay1Loop + 1 : 1) : 0;
                overlay2Loop = o2ActiveNext ? (overlay2Loop > 0 ? overlay2Loop + 1 : 1) : 0;
                logDebug(`Buffered loop ${currentLoop}/${power} finished.`);

                if (currentLoop < power) {
                    // prepare next loop direction & frameIndex
                    const reverseNext = ((currentLoop + 1) % 2 === 1);
                    frameIndex = reverseNext ? (numFrames - 1) : 0;
                    audioStartedForThisLoop = false;
                    statusDiv.textContent = `^${power} = ${currentLoop + 1} Export Loop (${reverseNext ? 'Reverse' : 'Normal'})`;
                    // continue RAF-driven loop without delay
                    rafId = requestAnimationFrame(step);
                    frameDrawTimeoutId = rafId;
                } else {
                    // All loops finished
                    logDebug(`Finished ${power} buffered loops. Stopping MediaRecorder.`);
                    stopAllAudioPlayback();
                    if (rafId) { cancelAnimationFrame(rafId); rafId = null; frameDrawTimeoutId = null; }
                    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                        logDebug("Stopping MediaRecorder after buffered loops.");
                        mediaRecorder.stop();
                        statusDiv.textContent = `Finalizing video...`;
                    } else {
                        logDebug("MediaRecorder was already inactive when trying to stop after buffered loops.");
                        stopGeneration();
                    }
                }
            }
        } else {
            // Defensive: if currentLoop >= power, finish
            if (rafId) { cancelAnimationFrame(rafId); rafId = null; frameDrawTimeoutId = null; }
            if (mediaRecorder && mediaRecorder.state !== 'inactive') {
                mediaRecorder.stop();
            } else {
                stopGeneration();
            }
        }
    };

    // Start RAF-driven draw loop (anchor a tiny timeout to let recorder stabilize)
    setTimeout(() => {
        if (isGenerating && mediaRecorder && mediaRecorder.state === 'recording') {
            rafId = requestAnimationFrame(step);
            frameDrawTimeoutId = rafId;
            logDebug("RAF-driven drawBufferedFrame loop started.");
        } else {
            logDebug("MediaRecorder not ready for RAF-driven start. Aborting buffered record.");
            if (isGenerating) stopGeneration();
        }
    }, 30);
}

// NEW: Paint the first processed frame to the canvas before starting the recorder
function paintFirstProcessedFrame(effect, loopIdx, frameTimeSeconds) {
    try {
        canvasCtx.drawImage(sourceVideo, 0, 0, canvasWidth, canvasHeight);
        const originalImageData = canvasCtx.getImageData(0, 0, canvasWidth, canvasHeight);
        const currentPower = parseInt(powerSelect.value, 10);
        const processed = applyComplexEffect(
            originalImageData,
            effect,
            currentPower,
            loopIdx,
            frameTimeSeconds || 0,
            videoDuration,
            getCustomParams()
        );
        canvasCtx.putImageData(processed, 0, 0);
        drawOverlays(canvasCtx, loopIdx, currentPower, frameTimeSeconds || 0);
        logDebug("Pre-painted first processed frame to avoid initial black.");
    } catch (e) {
        logDebug("Failed to pre-paint first frame (will proceed):", e);
    }
}

// Function to determine if overlays are active for a given loop index
function loopHasOverlay(loopIdx, totalPower) {
    // Allow overlays for power >= 2 (including 50)
    if (totalPower < 2) return false;
    const loopNum = loopIdx + 1;
    const halfStart = Math.max(1, totalPower - Math.ceil(totalPower / 2) + 1);
    const quarterStart = Math.max(1, totalPower - Math.ceil(totalPower / 4) + 1);
    const firstQuarterEnd = Math.ceil(totalPower / 4);
    const lastQuarterStart = totalPower - Math.ceil(totalPower / 4) + 1;
    return totalPower === 50
        ? ((overlay1Video && loopNum <= firstQuarterEnd) || (overlay2Video && loopNum >= lastQuarterStart))
        : ((overlay1Video && loopNum >= halfStart) || (overlay2Video && loopNum >= quarterStart));
}

// NEW: Overlay-specific active helpers that scale with power
function overlay1ActiveAtLoop(loopIdx, totalPower) {
    if (!overlay1Video || totalPower < 2) return false;
    // Overlay A starts at final half (50%)
    const loopNum = loopIdx + 1;
    const trigger = Math.ceil(totalPower / 2);
    return loopNum >= trigger;
}
function overlay2ActiveAtLoop(loopIdx, totalPower) {
    if (!overlay2Video || totalPower < 2) return false;
    // Overlay B starts at final quarter (75%)
    const loopNum = loopIdx + 1;
    const trigger = Math.ceil(totalPower * 0.75);
    return loopNum >= trigger;
}

// Function to draw overlays on top of the processed frame
function drawOverlays(ctx, loopIdx, totalPower, frameTimeSec) {
    if (totalPower < 2) return;
    const w = canvasWidth, h = canvasHeight;
    const effect = effectSelect.value;
    const power = parseInt(powerSelect.value, 10);
    const t = Math.max(0, (typeof frameTimeSec === 'number' ? frameTimeSec : sourceVideo.currentTime) || 0);

    // Helper to process a video frame through effects into a given offscreen canvas
    const processOverlay = (video, offCanvas, offCtx, overlayLoopIdx) => {
        if (!video || !video.videoWidth || !video.videoHeight) return null;
        if (offCanvas.width !== video.videoWidth || offCanvas.height !== video.videoHeight) {
            offCanvas.width = video.videoWidth; offCanvas.height = video.videoHeight;
        }
        // Performance: draw raw overlay frame without per-pixel effects
        try { offCtx.drawImage(video, 0, 0, offCanvas.width, offCanvas.height); return offCanvas; } catch(e){ return null; }
    };

    // Sync overlay times roughly to main timeline
    try { if (overlay1Video && !isNaN(overlay1Video.duration)) overlay1Video.currentTime = Math.min(overlay1Video.duration, t % (overlay1Video.duration || 1)); } catch(e){}
    try { if (overlay2Video && !isNaN(overlay2Video.duration)) overlay2Video.currentTime = Math.min(overlay2Video.duration, t % (overlay2Video.duration || 1)); } catch(e){}

    // First selection: 50% opacity, full canvas
    const o1Active = overlay1ActiveAtLoop(loopIdx, totalPower);
    if (o1Active && overlay1Video) {
        const o1LoopIdx = Math.max(0, overlay1Loop - 1);
        const c = processOverlay(overlay1Video, overlay1Canvas, overlay1Ctx, o1LoopIdx);
        if (c) {
            ctx.save(); ctx.globalAlpha = 0.5;
            try { ctx.drawImage(c, 0, 0, w, h); } catch(e){}
            ctx.restore();
        }
    }

    // Second selection: 50% size, centered (full opacity)
    const o2Active = overlay2ActiveAtLoop(loopIdx, totalPower);
    if (o2Active && overlay2Video) {
        const o2LoopIdx = Math.max(0, overlay2Loop - 1);
        const c = processOverlay(overlay2Video, overlay2Canvas, overlay2Ctx, o2LoopIdx);
        if (c) {
            const ow = Math.floor(w * 0.5), oh = Math.floor(h * 0.5);
            const ox = Math.floor((w - ow) / 2), oy = Math.floor((h - oh) / 2);
            try { ctx.drawImage(c, 0, 0, c.width, c.height, ox, oy, ow, oh); } catch(e){}
        }
    }

    // Built-in Fanny overlay for 'fanny_major' effect: draw Fanny.webp at bottom-right (20% width)
    if (effect === 'fanny_major' && typeof fannyImg !== 'undefined' && fannyImgLoaded) {
        try {
            const scale = 0.20; // 20% of canvas width
            const fw = Math.floor(w * scale);
            const fh = Math.floor(fw * (fannyImg.naturalHeight / Math.max(1, fannyImg.naturalWidth)));
            const fx = w - fw - Math.max(8, Math.floor(w * 0.02)); // small margin from edges
            const fy = h - fh - Math.max(8, Math.floor(h * 0.02));
            ctx.save();
            ctx.globalAlpha = 1.0;
            ctx.drawImage(fannyImg, fx, fy, fw, fh);
            ctx.restore();
        } catch (e) {
            logDebug("Failed to draw built-in Fanny overlay:", e);
        }
    }
}

// Function to create an overlay video from a file
function createOverlayVideoFromFile(file) {
    const v = document.createElement('video');
    v.muted = true; v.playsInline = true; v.loop = true; v.preload = 'metadata';
    const url = URL.createObjectURL(file);
    v.src = url;
    v.onloadedmetadata = () => { try { v.play(); } catch(e){} }; // ensure frames advance
    return { video: v, url };
}

// Add event listeners for overlay file inputs
overlay1Input.addEventListener('change', () => {
    // reset only overlay1, not both
    resetOverlay1();
    const f = overlay1Input.files && overlay1Input.files[0];
    if (f && f.type.startsWith('video/')) {
        const { video, url } = createOverlayVideoFromFile(f);
        overlay1Video = video; overlay1URL = url;
    }
});

overlay2Input.addEventListener('change', () => {
    // reset only overlay2, not both
    resetOverlay2();
    const f = overlay2Input.files && overlay2Input.files[0];
    if (f && f.type.startsWith('video/')) {
        const { video, url } = createOverlayVideoFromFile(f);
        overlay2Video = video; overlay2URL = url;
    }
});

// Helper to revoke URLs
function revokeURL(url) { try { url && URL.revokeObjectURL(url); } catch(e){} }

// Function to reset overlay videos and URLs
function resetOverlays() {
    try {
        if (overlay1Video) { overlay1Video.src = ''; overlay1Video.load(); overlay1Video = null; }
        if (overlay2Video) { overlay2Video.src = ''; overlay2Video.load(); overlay2Video = null; }
        revokeURL(overlay1URL); overlay1URL = null;
        revokeURL(overlay2URL); overlay2URL = null;
    } catch(e) { /* noop */ }
}

// Add individual reset helpers so choosing one source doesn't clear the other
function resetOverlay1() {
    try { if (overlay1Video) { overlay1Video.src=''; overlay1Video.load(); overlay1Video=null; } revokeURL(overlay1URL); overlay1URL=null; } catch(e){}
}

function resetOverlay2() {
    try { if (overlay2Video) { overlay2Video.src=''; overlay2Video.load(); overlay2Video=null; } revokeURL(overlay2URL); overlay2URL=null; } catch(e){}
}

// Override console.error to surface in diagnostics too (non-destructive)
const _origConsoleError = console.error;
console.error = (...args) => { _origConsoleError(...args); logDebug('ERROR:', ...args); };

/*
 * Layer UI handling: add/remove layers to a simple stack displayed in the UI.
 * Layers here are stored as strings and can later be read by effect logic if needed.
 */
if (addLayerBtn && layerSelect && layersList) {
    addLayerBtn.addEventListener('click', () => {
        const val = layerSelect.value || layerSelect.options[layerSelect.selectedIndex].value;
        const label = layerSelect.options[layerSelect.selectedIndex].text || val;
        // push to stack
        layersStack.push({ id: val, label, time: Date.now() });
        // render list
        renderLayersList();
        statusDiv.textContent = `Layer "${label}" added (${layersStack.length} total).`;
    });
}

function renderLayersList() {
    if (!layersList) return;
    layersList.innerHTML = '';
    layersStack.forEach((layer, idx) => {
        const li = document.createElement('li');
        li.style.display = 'flex';
        li.style.justifyContent = 'space-between';
        li.style.alignItems = 'center';
        li.style.padding = '6px 8px';
        li.style.borderBottom = '1px solid #f1f3f5';
        li.style.fontSize = '0.95rem';
        li.textContent = `${idx + 1}. ${layer.label}`;
        const removeBtn = document.createElement('button');
        removeBtn.textContent = 'Remove';
        removeBtn.style.marginLeft = '8px';
        removeBtn.style.padding = '6px 8px';
        removeBtn.style.borderRadius = '6px';
        removeBtn.style.border = '1px solid #e6e9ee';
        removeBtn.style.background = '#fff';
        removeBtn.style.cursor = 'pointer';
        removeBtn.addEventListener('click', () => {
            layersStack.splice(idx, 1);
            renderLayersList();
            statusDiv.textContent = `Layer removed. ${layersStack.length} left.`;
        });
        // append remove button to a wrapper so text and button align
        const wrapper = document.createElement('div');
        wrapper.style.display = 'flex';
        wrapper.style.alignItems = 'center';
        wrapper.appendChild(removeBtn);
        li.appendChild(wrapper);
        layersList.appendChild(li);
    });
}

// Wire Stop button
stopBtn.addEventListener('click', () => {
    stopBtn.disabled = true;
    statusDiv.textContent = 'Stopping...';
    stopGeneration();
});

// FIX: Define stopAllAudioPlayback to prevent ReferenceError and clean up audio nodes
function stopAllAudioPlayback() {
    try {
        // Stop and dispose any tracked audio/Tone nodes
        activeAudioSourceNodes.forEach(entry => {
            try { if (entry.stop) entry.stop(); } catch (e) {}
            try { if (entry.disconnect) entry.disconnect(); } catch (e) {}

            // If Tone.js nodes were stored, stop and dispose them safely
            const toneNodes = entry.__toneNodes || {};
            try { toneNodes.player && toneNodes.player.stop(); } catch (e) {}
            try { toneNodes.player && toneNodes.player.disconnect(); } catch (e) {}
            try { toneNodes.player && typeof toneNodes.player.dispose === 'function' && toneNodes.player.dispose(); } catch (e) {}

            try { toneNodes.shifter && toneNodes.shifter.disconnect(); } catch (e) {}
            try { toneNodes.shifter && typeof toneNodes.shifter.dispose === 'function' && toneNodes.shifter.dispose(); } catch (e) {}
        });
    } finally {
        activeAudioSourceNodes = [];
    }
}

// NEW: choose active audio source by loop
function getActiveAudioSourceForLoop(loopIdx, totalPower) {
    if (overlay2ActiveAtLoop(loopIdx, totalPower)) return 'overlay2';
    if (overlay1ActiveAtLoop(loopIdx, totalPower)) return 'overlay1';
    return 'main';
}

// NEW: update audio routing per loop (priority: o2 > o1 > main)
function updateAudioRoutingForLoop(effect, loopIdx, totalPower, targetPitches) {
    stopAllAudioPlayback();
    if (!destinationNode || !audioContext) return;

    // 1. Always play the main audio (with compounding pitch/reverse effect)
    // Schedule audio a small offset into the future so timing is deterministic and aligns with canvas rendering.
    const audioStart = (audioContext && typeof audioContext.currentTime === 'number')
        ? (audioContext.currentTime + Math.max(0, AUDIO_START_DELAY_SECONDS))
        : null;

    // Special-case: USATVE2004's G Major 32 uses audio reversed on odd-numbered powers (1,3,5,...)
    if (effect === 'reverse' || (effect === 'usatve2004_g_major_32' && (((loopIdx + 1) % 2) === 1))) {
        // For USATVE2004's G Major 32 odd powers and reverse effect, play reversed audio
        // but still allow pitch-shift voices when available.
        startReversedOriginalAudioForLoop(targetPitches || [], audioStart);
    } else {
        startAudioPlaybackForLoop(targetPitches || [], audioStart);
    }

    // 2. Add Overlay A if active
    if (overlay1Video) {
        const o1Active = overlay1ActiveAtLoop(loopIdx, totalPower);
        if (o1Active) {
            overlay1Video.muted = false; 
            if (!overlay1AudioNode) {
                overlay1AudioNode = audioContext.createMediaElementSource(overlay1Video);
            }
            const g1 = audioContext.createGain(); 
            g1.gain.value = 0.5; // overlay level set to 0.5
            overlay1AudioNode.connect(g1); 
            g1.connect(destinationNode);
            activeAudioSourceNodes.push({
                stop: () => { try { overlay1Video.muted = true; } catch(e){} },
                disconnect: () => {
                    try { overlay1AudioNode.disconnect(); } catch (e) {}
                    try { g1.disconnect(); } catch (e) {}
                }
            });
        } else {
            overlay1Video.muted = true;
        }
    }

    // 3. Add Overlay B if active
    if (overlay2Video) {
        const o2Active = overlay2ActiveAtLoop(loopIdx, totalPower);
        if (o2Active) {
            overlay2Video.muted = false; 
            if (!overlay2AudioNode) {
                overlay2AudioNode = audioContext.createMediaElementSource(overlay2Video);
            }
            const g2 = audioContext.createGain(); 
            g2.gain.value = 0.5;
            overlay2AudioNode.connect(g2); 
            g2.connect(destinationNode);
            activeAudioSourceNodes.push({
                stop: () => { try { overlay2Video.muted = true; } catch(e){} },
                disconnect: () => {
                    try { overlay2AudioNode.disconnect(); } catch (e) {}
                    try { g2.disconnect(); } catch (e) {}
                }
            });
        } else {
            overlay2Video.muted = true;
        }
    }
}

// Initial state
generateBtn.disabled = true; // Disable generate until video is loaded
outputArea.style.display = 'none'; // Hide output area initially
downloadBtn.href = '#'; // Ensure download button is not linked initially

// Set sourceVideo muted to true initially so autoplay doesn't surprise the user
// We manage mute state programmatically during generation.
// The output video's mute state will be set based on audio capture success and original source mute state.
sourceVideo.muted = true; // Keep muted on load

// Add a check for captureStream support on video element
if (!('captureStream' in document.createElement('video'))) {
    statusDiv.textContent += " (Note: Browser may not support capturing video audio from source. Output video might be muted)";
    logDebug("video.captureStream() not supported in this browser. Audio from source video may not be captured.");
}

// Add check for requestVideoFrameCallback support
if (!('requestVideoFrameCallback' in document.createElement('video'))) {
    statusDiv.textContent += " (Note: Browser does not support requestVideoFrameCallback, frame sync may be less accurate)";
    logDebug("requestVideoFrameCallback not supported. Falling back to requestAnimationFrame/setTimeout for frame processing.");
}

// Update status hints for browser capability if Tone.js is missing
if (!window.Tone) {
    statusDiv.textContent += " (Note: Tone.js not found. Audio will be included without pitch shifting.)";
    logDebug("Tone.js not loaded. Falling back to original audio so exports still contain sound.");
}