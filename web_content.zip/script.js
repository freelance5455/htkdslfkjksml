let records = [];
let schedule = [];
let selectedClasses = new Set();
const $ = id => document.getElementById(id);
const daysAll = ['Wiixata','Kibxata','Roobii','Kamisa','Jimaata','Sanbata'];

function cleanRecords(rows) {
  return rows.map(r => ({
    Teacher: String(r.Teacher ?? r.teacher ?? '').trim(),
    Subject: String(r.Subject ?? r.subject ?? '').trim(),
    Class: String(r.Class ?? r.class ?? '').trim(),
    PeriodsPerWeek: Number(r.PeriodsPerWeek ?? r.periodsperweek ?? r['Periods Per Week'] ?? r['Periods/week'] ?? 0)
  })).filter(r => r.Teacher && r.Subject && r.Class && Number.isFinite(r.PeriodsPerWeek) && r.PeriodsPerWeek > 0);
}
function esc(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function showRecords() {
  const tb = $('dataTable').querySelector('tbody');
  tb.innerHTML = '';
  records.forEach(r => {
    const tr = document.createElement('tr');
    [r.Teacher,r.Subject,r.Class,r.PeriodsPerWeek].forEach(v => {
      const td = document.createElement('td'); td.textContent = v; tr.appendChild(td);
    });
    tb.appendChild(tr);
  });
  $('rowCount').textContent = `${records.length} ramaddii · ${new Set(records.map(r=>r.Teacher)).size} barsiisota · ${new Set(records.map(r=>r.Class)).size} kutaa`;
  const classes = [...new Set(records.map(r=>r.Class))].sort(classSort);
  selectedClasses = new Set(classes);
  renderClassChoices();
  renderClassFilter();
}
function classSort(a,b) {
  const na = Number((a.match(/\d+/)||['0'])[0]), nb = Number((b.match(/\d+/)||['0'])[0]);
  return na-nb || a.localeCompare(b);
}
function renderClassChoices() {
  const root = $('classChoices'); root.innerHTML = '';
  const classes = [...new Set(records.map(r=>r.Class))].sort(classSort);
  if (!classes.length) { root.innerHTML = '<span class="muted">Kutaan galmee keessa hin jiru.</span>'; return; }
  classes.forEach(c => {
    const label = document.createElement('label');
    label.className = 'class-choice';
    const input = document.createElement('input');
    input.type = 'checkbox'; input.value = c; input.checked = selectedClasses.has(c);
    input.addEventListener('change', () => {
      if (input.checked) selectedClasses.add(c); else selectedClasses.delete(c);
      renderClassFilter();
    });
    const span = document.createElement('span'); span.textContent = c;
    label.append(input,span); root.appendChild(label);
  });
}
function renderClassFilter() {
  const sel = $('classFilter'), previous = sel.value;
  const classes = [...selectedClasses].sort(classSort);
  sel.innerHTML = '<option value="ALL">Kutaa filataman hunda</option>';
  classes.forEach(c => { const o=document.createElement('option'); o.value=c; o.textContent=c; sel.appendChild(o); });
  sel.value = classes.includes(previous) ? previous : 'ALL';
}
const sample = [
 {Teacher:'Barsiisaa A',Subject:'Herrega',Class:'1A',PeriodsPerWeek:5},
 {Teacher:'Barsiisaa B',Subject:'Afaan Oromoo',Class:'1A',PeriodsPerWeek:5},
 {Teacher:'Barsiisaa C',Subject:'English',Class:'1A',PeriodsPerWeek:4},
 {Teacher:'Barsiisaa A',Subject:'Herrega',Class:'2A',PeriodsPerWeek:5},
 {Teacher:'Barsiisaa B',Subject:'Saayinsii',Class:'2A',PeriodsPerWeek:4},
 {Teacher:'Barsiisaa D',Subject:'Afaan Oromoo',Class:'2A',PeriodsPerWeek:5},
 {Teacher:'Barsiisaa E',Subject:'Herrega',Class:'3A',PeriodsPerWeek:5}
];
$('sampleBtn').onclick = () => {
  records = cleanRecords(sample); showRecords();
  $('importStatus').textContent = 'Fakkeenyi galfame. Sagantaa dhugaa uumuuf faayila barsiisota kee galchi.';
  $('scheduleStatus').textContent = 'Kutaa barbaadde filadhu, achiis sagantaa uumi.';
};
$('selectAllBtn').onclick = () => {
  selectedClasses = new Set(records.map(r=>r.Class)); renderClassChoices(); renderClassFilter();
};
$('clearAllBtn').onclick = () => {
  selectedClasses = new Set(); renderClassChoices(); renderClassFilter();
};
function parseCSV(text) {
  const lines = text.replace(/^\uFEFF/,'').trim().split(/\r?\n/);
  if (!lines.length || !lines[0]) return [];
  const parseLine = s => {
    const a=[]; let v='', q=false;
    for(let i=0;i<s.length;i++){const c=s[i];
      if(c==='"' && s[i+1]==='"' && q){v+='"';i++;}
      else if(c==='"') q=!q;
      else if(c===',' && !q){a.push(v.trim());v='';}
      else v+=c;
    }
    a.push(v.trim()); return a;
  };
  const headers = parseLine(lines.shift());
  return lines.filter(Boolean).map(line=>{const vals=parseLine(line),o={};headers.forEach((h,i)=>o[h]=vals[i]??'');return o;});
}
$('file').addEventListener('change', async e => {
  const f=e.target.files[0]; if(!f)return;
  try {
    let rows;
    if(f.name.toLowerCase().endsWith('.csv')) rows=parseCSV(await f.text());
    else {
      if(!window.XLSX) throw new Error('Excel library hin argamne. CSVtti jijjiirii galchi ykn internet bani.');
      const book=XLSX.read(await f.arrayBuffer(),{type:'array'});
      rows=XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames.includes('Teachers')?'Teachers':book.SheetNames[0]]);
    }
    records=cleanRecords(rows); schedule=[]; showRecords();
    $('importStatus').textContent=`Ramaddii ${records.length} faayila ${f.name} irraa galfame.`;
    if(!records.length) $('importStatus').textContent += ' Mata-dureewwan Teacher, Subject, Class, PeriodsPerWeek ilaali.';
    $('scheduleStatus').textContent='Galmeen qophaa’e. Kutaa filadhu, sagantaa uumi.';
  } catch(err) { $('importStatus').textContent='Faayila galchuun hin milkoofne: '+err.message; }
});

function generate() {
  schedule = [];
  const classes = [...selectedClasses].sort(classSort);
  if(!records.length){$('scheduleStatus').textContent='Dura faayila barsiisotaa galchi.';return;}
  if(!classes.length){$('scheduleStatus').textContent='Yoo xiqqaate kutaa tokko filadhu.';renderResult();return;}
  const nDays=Number($('days').value), ppd=Number($('periods').value), maxLoad=Number($('maxLoad').value)||30;
  const totalSlots=nDays*ppd;
  const chosen=records.filter(r=>classes.includes(r.Class));
  const teacherLoad={};
  chosen.forEach(r=>teacherLoad[r.Teacher]=(teacherLoad[r.Teacher]||0)+r.PeriodsPerWeek);
  const over=Object.entries(teacherLoad).filter(([t,n])=>n>maxLoad);
  const classLoad={};
  chosen.forEach(r=>classLoad[r.Class]=(classLoad[r.Class]||0)+r.PeriodsPerWeek);
  const tooMany=Object.entries(classLoad).filter(([c,n])=>n>totalSlots);
  if(tooMany.length) {
    $('scheduleStatus').textContent='Dogoggora: wayitii barnootaa dandeettii kutaa caale: '+tooMany.map(([c,n])=>`${c}: ${n}/${totalSlots}`).join(', ');
    renderResult(); return;
  }
  // Make one task per required lesson. Try constrained tasks first.
  const tasks=[];
  chosen.forEach((r,ri)=>{for(let i=0;i<r.PeriodsPerWeek;i++)tasks.push({...r,ri,taskNo:i});});
  tasks.sort((a,b)=>{
    const optionsA=chosen.filter(x=>x.Teacher===a.Teacher).length;
    const optionsB=chosen.filter(x=>x.Teacher===b.Teacher).length;
    return optionsA-optionsB || a.Class.localeCompare(b.Class) || a.Teacher.localeCompare(b.Teacher);
  });
  const slots=[];
  for(let d=0;d<nDays;d++)for(let p=1;p<=ppd;p++)slots.push({day:daysAll[d],d,p});
  let best=[], bestFailed=tasks.length;
  // Multiple attempts reduce avoidable greedy dead ends.
  for(let attempt=0;attempt<35;attempt++){
    const placed=[], classUsed=new Set(), teacherUsed=new Set(), dayTeacherCount={};
    const order=[...tasks].sort((a,b)=>{
      const countA=chosen.filter(x=>x.Teacher===a.Teacher).reduce((s,x)=>s+x.PeriodsPerWeek,0);
      const countB=chosen.filter(x=>x.Teacher===b.Teacher).reduce((s,x)=>s+x.PeriodsPerWeek,0);
      return countB-countA || Math.random()-.5;
    });
    let failed=0;
    for(const t of order){
      const options=slots.filter(s=>!classUsed.has(`${t.Class}|${s.d}|${s.p}`)&&!teacherUsed.has(`${t.Teacher}|${s.d}|${s.p}`));
      options.sort((a,b)=>{
        const ca=dayTeacherCount[`${t.Teacher}|${a.d}`]||0, cb=dayTeacherCount[`${t.Teacher}|${b.d}`]||0;
        return ca-cb || Math.random()-.5;
      });
      if(!options.length){failed++;continue;}
      const s=options[0];
      classUsed.add(`${t.Class}|${s.d}|${s.p}`);
      teacherUsed.add(`${t.Teacher}|${s.d}|${s.p}`);
      dayTeacherCount[`${t.Teacher}|${s.d}`]=(dayTeacherCount[`${t.Teacher}|${s.d}`]||0)+1;
      placed.push({...t,...s});
    }
    if(placed.length>best.length){best=placed;bestFailed=failed;}
    if(!failed)break;
  }
  schedule=best.sort((a,b)=>a.d-b.d||a.p-b.p||classSort(a.Class,b.Class));
  const unplaced=tasks.length-schedule.length;
  let msg=`Sagantaa kutaa ${classes.length}f: ${schedule.length}/${tasks.length} barnoota ramadame. Guyyaa ${nDays}, guyyaatti wayitii ${ppd}.`;
  if(unplaced) msg+=`\nAkeekkachiisa: barnoota ${unplaced} ramaduun hin danda'amne. Yeroo barsiisotaa walitti bu'uu ykn daangaa slotii irraa kan ka'e ta'uu danda'a.`;
  if(over.length) msg+=`\nBarsiisota wayitii ${maxLoad} ol qaban: `+over.map(([t,n])=>`${t} (${n})`).join(', ');
  if(tooMany.length) msg+=`\nKutaa wayitii caalan: `+tooMany.map(([c,n])=>`${c} (${n})`).join(', ');
  const under=classes.filter(c=>(classLoad[c]||0)<totalSlots);
  if(under.length) msg+=`\nHubachiisa: ${under.join(', ')} keessatti barnoonni galmaa'e ${totalSlots} slotii guutuuf hin ga'u. Iddoon hafan “Ramaddii hin qabu” jedhamee mul'ata.`;
  $('scheduleStatus').textContent=msg;
  $('csvBtn').disabled=!schedule.length; $('xlsxBtn').disabled=!schedule.length;
  renderResult();
}
function renderResult() {
  const classes=$('classFilter').value==='ALL'?[...selectedClasses].sort(classSort):[$('classFilter').value];
  if(!classes.length){$('result').innerHTML='<p class="muted">Kutaa hin filanne.</p>';return;}
  const nDays=Number($('days').value), ppd=Number($('periods').value);
  let html='<table class="timetable"><thead><tr><th>Guyyaa</th><th>Wayitii</th>'+classes.map(c=>`<th>${esc(c)}</th>`).join('')+'</tr></thead><tbody>';
  for(let d=0;d<nDays;d++)for(let p=1;p<=ppd;p++){
    html+=`<tr><td>${daysAll[d]}</td><td>${p}</td>`;
    classes.forEach(c=>{
      const x=schedule.find(x=>x.d===d&&x.p===p&&x.Class===c);
      html+=`<td>${x?`<b>${esc(x.Subject)}</b><br><small>${esc(x.Teacher)}</small>`:'<span class="empty">Ramaddii hin qabu</span>'}</td>`;
    });
    html+='</tr>';
  }
  html+='</tbody></table>'; $('result').innerHTML=html;
}
function download(data,name,type){
  const blob=new Blob([data],{type}),a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function exportCSV(){
  const rows=[['Guyyaa','Wayitii','Kutaa','Barnoota','Barsiisaa'],...schedule.map(x=>[x.day,x.p,x.Class,x.Subject,x.Teacher])];
  const csv=rows.map(r=>r.map(v=>'"'+String(v).replace(/"/g,'""')+'"').join(',')).join('\r\n');
  download('\uFEFF'+csv,'Smart_School_Timetable.csv','text/csv;charset=utf-8');
}
$('generateBtn').onclick=generate;
$('classFilter').onchange=renderResult;
$('csvBtn').onclick=exportCSV;
$('xlsxBtn').onclick=()=>{
  if(!window.XLSX){alert('Excel export için SheetJS library internet irraa barbaada. CSV buusiitii Excel keessatti bani.');return;}
  const wb=XLSX.utils.book_new();
  const ws=XLSX.utils.aoa_to_sheet([['Guyyaa','Wayitii','Kutaa','Barnoota','Barsiisaa'],...schedule.map(x=>[x.day,x.p,x.Class,x.Subject,x.Teacher])]);
  XLSX.utils.book_append_sheet(wb,ws,'Timetable');
  XLSX.writeFile(wb,'Smart_School_Timetable.xlsx');
};
// Excel import/export support when online; CSV remains available offline.
const sheetScript=document.createElement('script');
sheetScript.src='https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
sheetScript.onerror=()=>{};
document.head.appendChild(sheetScript);
