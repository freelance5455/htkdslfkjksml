let car = document.getElementById("car");
let enemy = document.getElementById("enemy");
let coin = document.getElementById("coin");
let boost = document.getElementById("boost");

let scoreText = document.getElementById("score");
let livesText = document.getElementById("lives");
let finalScore = document.getElementById("finalScore");
let highScoreText = document.getElementById("highScore");
let gameOver = document.getElementById("gameOver");

let carPosition = 125;
let enemyPosition = 125;
let enemyY = -60;

let coinPosition = 60;
let coinY = -100;

let boostPosition = 185;
let boostY = -300;

let score = 0;
let lives = 3;

let boostActive = false;
let boostTimer = 0;

let highScore = Number(localStorage.getItem("carRushHighScore")) || 0;
let gameRunning = false;

highScoreText.innerText = highScore;


// 🚗 CAR MOVEMENT

function moveLeft() {
    if (gameRunning && carPosition > 10) {
        carPosition -= 25;
        car.style.left = carPosition + "px";
    }
}

function moveRight() {
    if (gameRunning && carPosition < 240) {
        carPosition += 25;
        car.style.left = carPosition + "px";
    }
}


// 🔊 SOUND

let audioCtx = null;
let engineOscillator = null;
let engineGain = null;

function initSound() {
    if (audioCtx) {
        if (audioCtx.state === "suspended") {
            audioCtx.resume();
        }
        return;
    }

    audioCtx = new (window.AudioContext || window.webkitAudioContext)();

    engineOscillator = audioCtx.createOscillator();
    engineGain = audioCtx.createGain();

    engineOscillator.type = "sawtooth";
    engineOscillator.frequency.value = 90;

    engineGain.gain.value = 0.02;

    engineOscillator.connect(engineGain);
    engineGain.connect(audioCtx.destination);

    engineOscillator.start();
}

function coinSound() {
    if (!audioCtx) return;

    let osc = audioCtx.createOscillator();
    let gain = audioCtx.createGain();

    osc.type = "sine";
    osc.frequency.value = 800;

    gain.gain.value = 0.08;

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();

    osc.frequency.exponentialRampToValueAtTime(
        1400,
        audioCtx.currentTime + 0.12
    );

    gain.gain.exponentialRampToValueAtTime(
        0.001,
        audioCtx.currentTime + 0.15
    );

    osc.stop(audioCtx.currentTime + 0.15);
}

function crashSound() {
    if (!audioCtx) return;

    let osc = audioCtx.createOscillator();
    let gain = audioCtx.createGain();

    osc.type = "square";
    osc.frequency.value = 100;

    gain.gain.value = 0.12;

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.start();

    osc.frequency.exponentialRampToValueAtTime(
        40,
        audioCtx.currentTime + 0.3
    );

    gain.gain.exponentialRampToValueAtTime(
        0.001,
        audioCtx.currentTime + 0.3
    );

    osc.stop(audioCtx.currentTime + 0.3);
}

function stopEngineSound() {
    if (engineGain) {
        engineGain.gain.value = 0;
    }
}


// 🏁 GAME LOOP

function gameLoop() {

    if (!gameRunning) return;

    let speed = 4 + Math.floor(score / 10);

    // ⚡ BOOST SPEED
    if (boostActive) {
        speed += 4;
        boostTimer--;

        if (boostTimer <= 0) {
            boostActive = false;
        }
    }

    // Enemy movement
    enemyY += speed;
    enemy.style.top = enemyY + "px";


    // Coin movement
    coinY += 3;
    coin.style.top = coinY + "px";


    // Boost movement
    boostY += 3;
    boost.style.top = boostY + "px";


    // Enemy passed
    if (enemyY > 520) {

        enemyY = -60;

        enemyPosition =
            Math.floor(Math.random() * 10) * 25;

        enemy.style.left =
            enemyPosition + "px";

        score++;

        scoreText.innerText = score;
    }


    // Coin passed
    if (coinY > 520) {

        coinY = -100;

        coinPosition =
            Math.floor(Math.random() * 10) * 25;

        coin.style.left =
            coinPosition + "px";
    }


    // Boost passed
    if (boostY > 520) {

        boostY = -300;

        boostPosition =
            Math.floor(Math.random() * 10) * 25;

        boost.style.left =
            boostPosition + "px";
    }


    // 🚗💥 ENEMY COLLISION

    if (
        enemyY > 400 &&
        enemyY < 470 &&
        Math.abs(carPosition - enemyPosition) < 45
    ) {

        lives--;

        livesText.innerText = lives;

        crashSound();

        enemyY = -60;

        enemyPosition =
            Math.floor(Math.random() * 10) * 25;

        enemy.style.left =
            enemyPosition + "px";


        if (lives <= 0) {
            endGame();
            return;
        }
    }


    // 🪙 COIN COLLISION

    if (
        coinY > 400 &&
        coinY < 470 &&
        Math.abs(carPosition - coinPosition) < 45
    ) {

        score += 10;

        scoreText.innerText = score;

        coinSound();

        coinY = -100;

        coinPosition =
            Math.floor(Math.random() * 10) * 25;

        coin.style.left =
            coinPosition + "px";
    }


    // ⚡ BOOST COLLISION

    if (
        boostY > 400 &&
        boostY < 470 &&
        Math.abs(carPosition - boostPosition) < 45
    ) {

        boostActive = true;

        boostTimer = 180;

        boostY = -300;
    }


    requestAnimationFrame(gameLoop);
}


// 💥 GAME OVER

function endGame() {

    gameRunning = false;

    stopEngineSound();

    if (score > highScore) {

        highScore = score;

        localStorage.setItem(
            "carRushHighScore",
            highScore
        );
    }

    finalScore.innerText = score;

    highScoreText.innerText = highScore;

    gameOver.style.display = "block";
}


// 🔄 RESTART GAME

function restartGame() {

    carPosition = 125;

    enemyPosition = 125;
    enemyY = -60;

    coinPosition = 60;
    coinY = -100;

    boostPosition = 185;
    boostY = -300;

    score = 0;
    lives = 3;

    boostActive = false;
    boostTimer = 0;

    gameRunning = true;


    car.style.left =
        carPosition + "px";


    enemy.style.left =
        enemyPosition + "px";

    enemy.style.top =
        enemyY + "px";


    coin.style.left =
        coinPosition + "px";

    coin.style.top =
        coinY + "px";


    boost.style.left =
        boostPosition + "px";

    boost.style.top =
        boostY + "px";


    scoreText.innerText = score;

    livesText.innerText = lives;

    highScoreText.innerText = highScore;

    gameOver.style.display = "none";


    if (audioCtx) {

        if (audioCtx.state === "suspended") {
            audioCtx.resume();
        }

        if (engineGain) {
            engineGain.gain.value = 0.02;
        }
    }

    requestAnimationFrame(gameLoop);
}


// 🚦 START GAME

function startGame() {

    document.getElementById("startScreen").style.display = "none";

    initSound();

    restartGame();

    gameRunning = false;

    let countdown =
        document.getElementById("countdown");

    let red =
        document.querySelector("#trafficLight .red");

    let yellow =
        document.querySelector("#trafficLight .yellow");

    let green =
        document.querySelector("#trafficLight .green");

    red.style.opacity = "1";
    yellow.style.opacity = "0.25";
    green.style.opacity = "0.25";

    let count = 3;

    countdown.innerText = count;

    let timer = setInterval(function () {

        count--;

        if (count === 2) {

            red.style.opacity = "0.25";
            yellow.style.opacity = "1";

            countdown.innerText = count;
        }

        else if (count === 1) {

            yellow.style.opacity = "0.25";
            green.style.opacity = "1";

            countdown.innerText = count;
        }

        else {

            countdown.innerText = "GO!";

            setTimeout(function () {

                countdown.innerText = "";

                gameRunning = true;

                requestAnimationFrame(gameLoop);

            }, 500);

            clearInterval(timer);
        }

    }, 1000);
}


// ⏸️ PAUSE

function togglePause() {

    let pauseButton =
        document.getElementById("pauseButton");

    if (gameRunning) {

        gameRunning = false;

        pauseButton.innerText = "▶️ RESUME";

        stopEngineSound();

    } else {

        gameRunning = true;

        pauseButton.innerText = "⏸️ PAUSE";

        if (audioCtx && engineGain) {
            engineGain.gain.value = 0.02;
        }

        requestAnimationFrame(gameLoop);
    }
}