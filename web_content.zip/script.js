const subjects = [
 {name:"Mathématiques",icon:"∑",desc:"Suites, limites, dérivées, intégrales, complexes, probabilités..."},
 {name:"SVT",icon:"🌿",desc:"Génétique, immunologie, neurophysiologie, évolution, géologie"},
 {name:"Physique",icon:"⚡",desc:"Mécanique, électricité, ondes, physique nucléaire"},
 {name:"Chimie",icon:"⚗️",desc:"Chimie organique, cinétique, acido-basique, oxydoréduction"},
 {name:"Informatique",icon:"⌨️",desc:"Algorithmique, structures de données, bases de données, réseaux"}
];

const subjectsEl = document.getElementById("subjects");
subjects.forEach((s,i)=>{
 const b=document.createElement("button");
 b.className="subject";
 b.innerHTML=`<div class="icon">${s.icon}</div><strong>${s.name}</strong><span>${s.desc}</span>`;
 b.onclick=()=>showSubject(i);
 subjectsEl.appendChild(b);
});

function showSubject(i){
 document.getElementById("home").classList.add("hidden");
 document.getElementById("subjectPage").classList.remove("hidden");
 document.getElementById("subjectTitle").textContent=subjects[i].name;
 document.getElementById("subjectDescription").textContent=subjects[i].desc;
 document.getElementById("featureBox").innerHTML="<p>Choisis une fonctionnalité ci-dessus.</p>";
}

function showHome(){
 document.getElementById("subjectPage").classList.add("hidden");
 document.getElementById("home").classList.remove("hidden");
}

function openFeature(feature){
 const box=document.getElementById("featureBox");
 if(feature==="Tuteur IA"){
   box.innerHTML=`<h3>🤖 Tuteur IA</h3>
   <p>Pose une question sur la matière consultée. Cette première version prépare l'interface du tuteur.</p>
   <input id="question" placeholder="Écris ta question..." style="width:100%;padding:12px;border:1px solid #ddd;border-radius:10px">
   <button onclick="askTutor()" style="margin-top:10px;padding:11px 16px;border:0;border-radius:10px;background:#2d6cdf;color:white">Envoyer</button>
   <p id="answer"></p>`;
 } else {
   box.innerHTML=`<h3>${feature}</h3><p>Cette section sera remplie avec les cours, exercices et quiz du programme.</p>`;
 }
}

function askTutor(){
 const q=document.getElementById("question").value.trim();
 document.getElementById("answer").textContent=q ? "Le tuteur IA recevra cette question dans la prochaine étape de développement." : "Écris d'abord une question.";
}
