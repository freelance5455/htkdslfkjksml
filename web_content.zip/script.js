
"use strict";

/* =================================
   AVIJIT CALCULATOR
   JAVASCRIPT
================================= */

/* HTML ELEMENTS */

var expressionDisplay = /** @type {HTMLElement} */ (
    document.getElementById("expression")
);

var resultDisplay = /** @type {HTMLElement} */ (
    document.getElementById("result")
);

var historyToggle = /** @type {HTMLElement} */ (
    document.getElementById("historyToggle")
);

var historyPanel = /** @type {HTMLElement} */ (
    document.getElementById("historyPanel")
);

var historyList = /** @type {HTMLElement} */ (
    document.getElementById("historyList")
);

var clearHistoryButton = /** @type {HTMLElement} */ (
    document.getElementById("clearHistory")
);

var buttons = document.querySelectorAll(".btn");

var expression = "";

/** @type {string[]} */
var calculationHistory = [];

/* DISPLAY */

function updateDisplay() {
    expressionDisplay.textContent = expression || "0";
}

/* CLEAR */

function clearAll() {
    expression = "";
    resultDisplay.textContent = "0";
    updateDisplay();
}

/* DELETE */

function deleteLast() {
    expression = expression.slice(0, -1);
    updateDisplay();
}

/* ADD VALUE */

/** @param {string} value */
function addValue(value) {
    var operators = ["+", "-", "*", "/"];
    var last = expression.slice(-1);

    /* Parentheses button */

    if (value === "(") {
        var openCount = (expression.match(/\(/g) || []).length;
        var closeCount = (expression.match(/\)/g) || []).length;

        if (openCount > closeCount) {
            value = ")";
        } else {
            value = "(";
        }
    }

    /* Opening bracket */

    if (value === "(") {
        if (/[0-9.)%]$/.test(expression)) {
            expression += "*";
        }

        expression += "(";
        updateDisplay();
        return;
    }

    /* Closing bracket */

    if (value === ")") {
        var opens = (expression.match(/\(/g) || []).length;
        var closes = (expression.match(/\)/g) || []).length;

        if (opens <= closes || operators.indexOf(last) !== -1) {
            return;
        }

        expression += ")";
        updateDisplay();
        return;
    }

    /* Decimal point */

    if (value === ".") {
        var parts = expression.split(/[+\-*/()%]/);
        var lastNumber = parts[parts.length - 1];

        if (lastNumber.indexOf(".") !== -1) {
            return;
        }

        if (lastNumber === "") {
            expression += "0";
        }
    }

    /* Percentage */

    if (value === "%") {
        if (!/[0-9)]$/.test(expression)) {
            return;
        }

        expression += "%";
        updateDisplay();
        return;
    }

    /* Operators */

    if (operators.indexOf(value) !== -1) {
        if (expression === "" && value !== "-") {
            return;
        }

        if (operators.indexOf(last) !== -1) {
            if (value === "-" && last !== "-") {
                expression += "-";
                updateDisplay();
                return;
            }

            expression = expression.slice(0, -1);
        }
    }

    expression += value;
    updateDisplay();
}

/* CALCULATION ENGINE */

/** @param {string} input */
function simpleCalculate(input) {
    var position = 0;

    function skipSpaces() {
        while (input.charAt(position) === " ") {
            position++;
        }
    }

    /** @returns {number} */
    function parseNumber() {
        skipSpaces();

        var start = position;
        var decimalCount = 0;

        while (position < input.length) {
            var character = input.charAt(position);

            if (
                (character >= "0" && character <= "9") ||
                character === "."
            ) {
                if (character === ".") {
                    decimalCount++;
                }

                position++;
            } else {
                break;
            }
        }

        if (start === position || decimalCount > 1) {
            throw new Error("Invalid number");
        }

        var number = Number(input.slice(start, position));

        if (!Number.isFinite(number)) {
            throw new Error("Invalid number");
        }

        return number;
    }

    /** @returns {number} */
    function parseFactor() {
        skipSpaces();

        var sign = 1;

        if (input.charAt(position) === "-") {
            sign = -1;
            position++;
        } else if (input.charAt(position) === "+") {
            position++;
        }

        skipSpaces();

        /** @type {number} */
        var value;

        if (input.charAt(position) === "(") {
            position++;

            value = parseExpression();

            skipSpaces();

            if (input.charAt(position) !== ")") {
                throw new Error("Missing bracket");
            }

            position++;
        } else {
            value = parseNumber();
        }

        value *= sign;

        skipSpaces();

        while (input.charAt(position) === "%") {
            value /= 100;
            position++;
            skipSpaces();
        }

        return value;
    }

    /** @returns {number} */
    function parseTerm() {
        var value = parseFactor();

        while (true) {
            skipSpaces();

            var operator = input.charAt(position);

            if (operator !== "*" && operator !== "/") {
                break;
            }

            position++;

            var nextValue = parseFactor();

            if (operator === "*") {
                value *= nextValue;
            } else {
                if (nextValue === 0) {
                    throw new Error("Division by zero");
                }

                value /= nextValue;
            }
        }

        return value;
    }

    /** @returns {number} */
    function parseExpression() {
        var value = parseTerm();

        while (true) {
            skipSpaces();

            var operator = input.charAt(position);

            if (operator !== "+" && operator !== "-") {
                break;
            }

            position++;

            var nextValue = parseTerm();

            if (operator === "+") {
                value += nextValue;
            } else {
                value -= nextValue;
            }
        }

        return value;
    }

    var answer = parseExpression();

    skipSpaces();

    if (position !== input.length || !Number.isFinite(answer)) {
        throw new Error("Invalid expression");
    }

    return Number(answer.toPrecision(12));
}

/* HISTORY DISPLAY */

function showHistory() {
    historyList.innerHTML = "";

    if (calculationHistory.length === 0) {
        var emptyMessage = document.createElement("p");

        emptyMessage.className = "empty-history";
        emptyMessage.textContent = "No history yet";

        historyList.appendChild(emptyMessage);
        return;
    }

    for (var i = 0; i < calculationHistory.length; i++) {
        var item = document.createElement("div");

        item.className = "history-item";
        item.textContent = calculationHistory[i];

        historyList.appendChild(item);
    }
}

/* CALCULATE BUTTON */

function calculate() {
    if (expression === "") {
        return;
    }

    try {
        var oldExpression = expression;
        var answer = simpleCalculate(expression);

        resultDisplay.textContent = String(answer);

        calculationHistory.unshift(
            oldExpression + " = " + answer
        );

        if (calculationHistory.length > 30) {
            calculationHistory.pop();
        }

        showHistory();

        expression = String(answer);
        updateDisplay();

    } catch (error) {
        resultDisplay.textContent = "Error";
    }
}

/* KEYPAD BUTTONS */

for (var i = 0; i < buttons.length; i++) {
    let currentButton = buttons[i];

    currentButton.addEventListener("click", function () {
        var action = currentButton.getAttribute("data-action");
        var value = currentButton.getAttribute("data-value");

        if (action === "clear") {
            clearAll();

        } else if (action === "delete") {
            deleteLast();

        } else if (action === "calculate") {
            calculate();

        } else if (value !== null) {
            addValue(value);
        }
    });
}

/* HISTORY TOGGLE */

historyToggle.addEventListener("click", function () {
    historyPanel.hidden = !historyPanel.hidden;
    showHistory();
});

/* CLEAR HISTORY */

clearHistoryButton.addEventListener("click", function () {
    calculationHistory = [];
    showHistory();
});

/* START */

updateDisplay();
showHistory();
