let currentUser=null,currentGroup=null,debts=[];

function login(){
 const u=document.getElementById("username").value.trim(),p=document.getElementById("password").value.trim();
 if(!u||!p){alert("اكتب اسم المستخدم وكلمة المرور");return}
 currentUser=u;
 document.getElementById("loginPage").classList.add("hidden");
 document.getElementById("homePage").classList.remove("hidden");
 document.getElementById("welcome").textContent="أهلاً "+u;
 document.getElementById("debtDate").value=today();
 loadData();
}
function logout(){
 currentUser=null;currentGroup=null;debts=[];
 document.getElementById("homePage").classList.add("hidden");
 document.getElementById("loginPage").classList.remove("hidden");
}
function createGroup(){
 currentGroup=Math.random().toString(36).substring(2,8).toUpperCase();
 debts=[];updateGroupUI();saveData();
 alert("تم إنشاء المجموعة\nكود المجموعة: "+currentGroup);
}
function joinGroup(){
 const c=prompt("اكتب كود المجموعة:");
 if(!c)return;
 currentGroup=c.trim().toUpperCase();
 updateGroupUI();loadData();
 alert("تم الانضمام إلى المجموعة");
}
function updateGroupUI(){
 document.getElementById("groupCode").textContent="🔑 كود المجموعة: "+currentGroup;
 document.getElementById("groupInfo").textContent="المجموعة: "+currentGroup;
}
function addDebt(){
 if(!currentGroup){alert("أنشئ مجموعة أو انضم إلى مجموعة أولاً");return}
 const name=document.getElementById("debtName").value.trim();
 const amount=Number(document.getElementById("debtAmount").value);
 const reason=document.getElementById("debtReason").value.trim();
 const date=document.getElementById("debtDate").value;
 if(!name||!reason||amount<=0||!date){
   alert("تأكد من الاسم والمبلغ والسبب والتاريخ");return;
 }
 debts.push({
   id:Date.now(),name:name,amount:amount,paid:0,
   reason:reason,createdBy:currentUser,date:date
 });
 saveData();renderDebts();
 document.getElementById("debtName").value="";
 document.getElementById("debtAmount").value="";
 document.getElementById("debtReason").value="";
 document.getElementById("debtDate").value=today();
}
function payDebt(id){
 const d=debts.find(x=>x.id===id);if(!d)return;
 const rem=d.amount-d.paid;
 const v=Number(prompt("المتبقي لهذا الدين: "+money(rem)+" د.ع\nكم تريد تسديد؟"));
 if(!v||v<=0||v>rem){alert("مبلغ التسديد غير صحيح");return}
 d.paid+=v;saveData();renderDebts();
}
function deleteDebt(id){
 if(!confirm("هل تريد حذف هذا الدين؟"))return;
 debts=debts.filter(d=>d.id!==id);saveData();renderDebts();
}
function renderDebts(){
 const list=document.getElementById("debtList");
 if(!debts.length){
   list.innerHTML='<div class="empty">لا توجد ديون.</div>';
   updateStats();return;
 }
 const people={};
 debts.forEach(d=>{
   const key=d.name.trim().toLowerCase();
   if(!people[key])people[key]={name:d.name,records:[]};
   people[key].records.push(d);
 });
 list.innerHTML="";
 Object.values(people).forEach(person=>{
   const total=person.records.reduce((s,d)=>s+d.amount,0);
   const paid=person.records.reduce((s,d)=>s+d.paid,0);
   const box=document.createElement("div");
   box.className="person";
   box.innerHTML=
     '<div class="person-name">👤 '+escapeHtml(person.name)+'</div>'+
     '<div class="person-total">💰 مجموع الدين: <b>'+money(total)+' د.ع</b></div>'+
     '<div class="person-total">💳 مجموع المسدّد: <b>'+money(paid)+' د.ع</b></div>'+
     '<div class="person-total">📌 مجموع المتبقي: <b>'+money(total-paid)+' د.ع</b></div>';
   person.records.sort((a,b)=>a.date.localeCompare(b.date));
   person.records.forEach(d=>{
     const rem=d.amount-d.paid;
     const rec=document.createElement("div");
     rec.className="debt-record";
     rec.innerHTML=
       '<div class="debt-info">📅 التاريخ: <b>'+formatDate(d.date)+'</b></div>'+
       '<div class="debt-info">💵 مبلغ الدين: '+money(d.amount)+' د.ع</div>'+
       '<div class="debt-info">💳 المسدّد: '+money(d.paid)+' د.ع</div>'+
       '<div class="debt-info">📌 المتبقي: '+money(rem)+' د.ع</div>'+
       '<div class="debt-info">📝 السبب: '+escapeHtml(d.reason)+'</div>'+
       '<div class="debt-info">👨‍💼 سجله: '+escapeHtml(d.createdBy)+'</div>'+
       (rem>0?'<button class="pay-button" onclick="payDebt('+d.id+')">💵 تسديد هذا الدين</button>':'<button disabled>✅ تم تسديد هذا الدين</button>')+
       '<button class="delete-button" onclick="deleteDebt('+d.id+')">🗑️ حذف هذا الدين</button>';
     box.appendChild(rec);
   });
   list.appendChild(box);
 });
 updateStats();
}
function updateStats(){
 let td=0,tp=0;
 debts.forEach(d=>{td+=Number(d.amount);tp+=Number(d.paid)});
 document.getElementById("totalDebt").textContent=money(td);
 document.getElementById("totalPaid").textContent=money(tp);
 document.getElementById("totalRemaining").textContent=money(td-tp);
}
function saveData(){
 if(currentGroup)localStorage.setItem("debtBook_"+currentGroup,JSON.stringify({group:currentGroup,debts:debts}));
}
function loadData(){
 const s=currentGroup&&localStorage.getItem("debtBook_"+currentGroup);
 if(s){try{debts=JSON.parse(s).debts||[]}catch(e){debts=[]}}
 else debts=[];
 updateGroupUI();renderDebts();
}
function money(n){return Number(n).toLocaleString("ar-IQ")}
function today(){return new Date().toISOString().split("T")[0]}
function formatDate(s){
 const p=s.split("-");
 return p.length===3?p[2]+"/"+p[1]+"/"+p[0]:s;
}
function escapeHtml(t){
 const d=document.createElement("div");d.textContent=t;return d.innerHTML;
}
document.addEventListener("DOMContentLoaded",()=>{
 document.getElementById("debtDate").value=today();
 renderDebts();
});