const sobre = document.getElementById("sobre");

const inicio = document.getElementById("inicio");

const carta = document.getElementById("carta");

const cerrar = document.getElementById("cerrar");

const corazones = document.getElementById("corazones");


// -------------------------
// ABRIR CARTA
// -------------------------

sobre.addEventListener("click", function () {

    // Animación del sobre
    sobre.classList.add("abierto");

    // Esperar a que se vea la animación
    setTimeout(function () {

        inicio.style.display = "none";

        carta.classList.remove("oculta");

        crearCorazones();

    }, 700);

});


// -------------------------
// CERRAR CARTA
// -------------------------

cerrar.addEventListener("click", function () {

    carta.classList.add("oculta");

    setTimeout(function () {

        inicio.style.display = "flex";

        sobre.classList.remove("abierto");

    }, 400);

});


// -------------------------
// CREAR CORAZONES
// -------------------------

function crearCorazon() {

    const corazon =
        document.createElement("div");

    corazon.classList.add(
        "corazon-flotante"
    );

    const tipos = [
        "❤️",
        "💗",
        "💕",
        "💖",
        "💘"
    ];

    corazon.innerHTML =
        tipos[
            Math.floor(
                Math.random() * tipos.length
            )
        ];


    // Posición horizontal aleatoria

    corazon.style.left =
        Math.random() * 100 + "%";


    // Tamaño aleatorio

    const tamaño =
        15 + Math.random() * 25;

    corazon.style.fontSize =
        tamaño + "px";


    // Duración aleatoria

    const duracion =
        4 + Math.random() * 5;

    corazon.style.animationDuration =
        duracion + "s";


    corazones.appendChild(corazon);


    // Eliminar después de la animación

    setTimeout(function () {

        corazon.remove();

    }, duracion * 1000);

}


// Crear corazones periódicamente

function crearCorazones() {

    for (let i = 0; i < 15; i++) {

        setTimeout(
            crearCorazon,
            i * 150
        );

    }

}


// Corazones de fondo permanentes

setInterval(function () {

    crearCorazon();

}, 900);