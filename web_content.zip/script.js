const $ = id => document.getElementById(id);
const LAT = 48.7325, LON = 11.1872;
const api = `https://api.open-meteo.com/v1/forecast?latitude=${LAT}&longitude=${LON}&current=temperature_2m,apparent_temperature,is_day,precipitation,rain,showers,snowfall,weather_code,wind_speed_10m&hourly=temperature_2m,precipitation_probability,snowfall,snow_depth,weather_code&daily=temperature_2m_min,temperature_2m_max,snowfall_sum,precipitation_probability_max&forecast_days=7&timezone=Europe%2FBerlin`;
const names={0:"Klarer Himmel",1:"Überwiegend klar",2:"Teilweise bewölkt",3:"Bedeckt",45:"Nebel",48:"Reifnebel",51:"Leichter Nieselregen",53:"Nieselregen",55:"Starker Nieselregen",61:"Leichter Regen",63:"Regen",65:"Starker Regen",71:"Leichter Schneefall",73:"Schneefall",75:"Starker Schneefall",77:"Schneegriesel",80:"Regenschauer",81:"Regenschauer",82:"Starke Regenschauer",85:"Leichte Schneeschauer",86:"Starke Schneeschauer",95:"Gewitter"};
const snowCodes=[71,73,75,77,85,86];
const activities=["Mache einen kleinen Winter-Fotospaziergang und suche schöne Lichter.","Baue eine gemütliche Winter-Playlist.","Bereite dir einen warmen Kakao oder Tee zu.","Mache es dir gemütlich und schaue einen Winterfilm.","Bastle eine kleine Weihnachtsdekoration.","Beobachte den Schneefall vom Fenster aus.","Mache einen Spaziergang und entdecke festliche Dekorationen.","Räume deine Fotos auf und erstelle ein Winteralbum.","Schreibe eine kleine Wunschliste für den Winter.","Spiele ein Brett- oder Kartenspiel mit deiner Familie."];
function tick(){
 const n=new Date();$("clock").textContent=n.toLocaleTimeString("de-DE");
 $("date").textContent=n.toLocaleDateString("de-DE",{weekday:"short",day:"2-digit",month:"2-digit",year:"numeric"});
 let target=new Date(n.getFullYear(),11,31,23,59,59);if(n>target)target=new Date(n.getFullYear()+1,11,31,23,59,59);
 let ms=Math.max(0,target-n),d=Math.floor(ms/86400000);ms%=86400000;let h=Math.floor(ms/3600000);ms%=3600000;let m=Math.floor(ms/60000);let s=Math.floor(ms%60000/1000);
 $("newyearCountdown").textContent=`${d}T ${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
}
function nearestHour(times,now){let best=0,dist=Infinity;times.forEach((t,i)=>{let x=Math.abs(new Date(t)-now);if(x<dist){dist=x;best=i;}});return best;}
function sceneFor(code){
 let cls="cloudy",emoji="☁️";
 if(snowCodes.includes(code)){cls="snow";emoji="🌨️";}
 else if([0,1].includes(code)){cls="clear";emoji="☀️";}
 else if([51,53,55,61,63,65,80,81,82].includes(code)){cls="rain";emoji="🌧️";}
 else if(code>=95){cls="rain";emoji="⛈️";}
 $("weatherScene").className=`weather-scene ${cls}`;$("sceneEmoji").textContent=emoji;$("sceneCaption").textContent=names[code]||"Aktuelle Wetterlage";
}
function warning(temp,code,wind){
 let title="Wetterhinweis",msg="Aktuell keine besonderen Frosthinweise aus dieser Prognose.";
 if(temp<=0||snowCodes.includes(code)){title="Achtung: Frost / Glätte möglich";msg="Bei Temperaturen um oder unter 0 °C kann es örtlich glatt werden. Bitte vorsichtig unterwegs sein.";}
 if(wind>=45){title="Windhinweis";msg="Erhöhte Windgeschwindigkeiten möglich. Lokale Warnmeldungen beachten.";}
 $("warningTitle").textContent=title;$("warningText").textContent=msg;
}
function renderDaily(d){
 const days=d.daily.time, snow=d.daily.snowfall_sum, mins=d.daily.temperature_2m_min,maxs=d.daily.temperature_2m_max,probs=d.daily.precipitation_probability_max;
 $("dailyList").innerHTML="";$("temperatureList").innerHTML="";
 days.forEach((day,i)=>{
  const label=new Date(day+"T12:00:00").toLocaleDateString("de-DE",{weekday:"short",day:"2-digit",month:"2-digit"});
  const sr=document.createElement("div");sr.className="daily-row";sr.innerHTML=`<span>${label}</span><b>${Number(snow[i]||0).toFixed(1)} cm · ${probs[i]??0}%</b>`;$("dailyList").appendChild(sr);
  const tr=document.createElement("div");tr.className="daily-row";tr.innerHTML=`<span>${label}</span><b>${Math.round(mins[i])}° / ${Math.round(maxs[i])}°C</b>`;$("temperatureList").appendChild(tr);
 });
 const total=snow.reduce((a,b)=>a+Number(b||0),0);
 $("snowOutlook").textContent=total>0?`In den nächsten 7 Tagen werden insgesamt etwa ${total.toFixed(1)} cm Neuschnee modelliert.`:"In den nächsten 7 Tagen wird derzeit kein Neuschnee modelliert.";
}
async function loadWeather(){
 $("updated").textContent="Wetterdaten werden geladen …";
 try{
  const response=await fetch(api);if(!response.ok)throw Error("API nicht erreichbar");
  const d=await response.json(),c=d.current,h=d.hourly,now=new Date(),idx=nearestHour(h.time,now),temp=Math.round(c.temperature_2m),code=c.weather_code;
  $("temperature").textContent=`${temp}°C`;$("feels").textContent=`${Math.round(c.apparent_temperature)}°C`;$("condition").textContent=names[code]||"Aktuelle Wetterlage";
  $("weatherIcon").textContent=snowCodes.includes(code)?"❄":([0,1].includes(code)?"☀":([51,53,55,61,63,65,80,81,82].includes(code)?"🌧":"☁"));
  const snowNow=Number(h.snowfall[idx]||0),precip=Number(h.precipitation_probability[idx]||0),chance=snowNow>0||snowCodes.includes(code)?precip:0;
  $("snowChance").textContent=`${Math.round(chance)}%`;$("snowMeter").style.width=`${Math.max(0,Math.min(100,chance))}%`;
  $("snowNote").textContent=chance>0?"Schneefall laut Stundenprognose möglich":"Aktuell kein Schneefall signalisiert";
  const depth=Number(h.snow_depth[idx]||0)*100;$("snowDepth").textContent=`${depth.toFixed(0)} cm`;
  $("snowStays").textContent=depth>=1?"Ja":"Eher nein";$("snowStayNote").textContent=depth>=1?"Schneedecke modelliert":"Keine nennenswerte Schneedecke";
  warning(temp,code,Number(c.wind_speed_10m||0));sceneFor(code);
  let next=-1;for(let i=idx;i<h.time.length;i++){if(Number(h.snowfall[i]||0)>0){next=i;break;}}
  if(next>=0){
   const diff=Math.max(0,new Date(h.time[next])-now),hours=Math.floor(diff/3600000),mins=Math.floor((diff%3600000)/60000);
   $("nextSnowIn").textContent=hours>0?`${hours} h ${mins} min`:`${mins} min`;
   let total=0,end=next;for(let j=next;j<h.time.length&&Number(h.snowfall[j]||0)>0;j++){total+=Number(h.snowfall[j]||0);end=j;}
   $("arrivalAmount").textContent=`Neuschnee: ca. ${total.toFixed(1)} cm`;
   $("arrivalDuration").textContent=`Dauer: ca. ${Math.max(1,end-next+1)} h`;
   $("arrivalTemp").textContent=`Temperatur: ${Math.round(h.temperature_2m[next])}°C`;
  }else{
   $("nextSnowIn").textContent="Nicht vorhergesagt";$("arrivalAmount").textContent="Neuschnee: -- cm";$("arrivalDuration").textContent="Dauer: --";$("arrivalTemp").textContent="Temperatur: --°C";
  }
  renderDaily(d);$("updated").textContent=`Aktualisiert: ${new Date().toLocaleTimeString("de-DE",{hour:"2-digit",minute:"2-digit"})} · Open-Meteo`;
 }catch(e){
  $("condition").textContent="Wetterdaten nicht verfügbar";$("snowNote").textContent="Internetverbindung prüfen";$("nextSnowIn").textContent="Keine Prognosedaten";
  $("updated").textContent="Offline – Wetterdaten konnten nicht geladen werden.";
 }
}
$("activityButton").addEventListener("click",()=>{$("activityText").textContent=activities[Math.floor(Math.random()*activities.length)];});
$("refresh").addEventListener("click",loadWeather);
tick();setInterval(tick,1000);loadWeather();setInterval(loadWeather,15*60*1000);
