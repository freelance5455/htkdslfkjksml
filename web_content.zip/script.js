'use strict';
const N=40,$=i=>document.getElementById(i),cl=(v,a,b)=>Math.max(a,Math.min(b,v)),rnd=a=>a[Math.random()*a.length|0],
esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';'),
Fm=n=>{if(!isFinite(n))return'∞';n=Math.floor(n);const a=Math.abs(n);return a>=1e12?(n/1e12).toFixed(1)+'T':a>=1e9?(n/1e9).toFixed(1)+'B':a>=1e6?(n/1e6).toFixed(1)+'M':a>=1e4?(n/1e3).toFixed(1)+'K':n},
need=l=>Math.floor(50*l**2.3),pct=v=>Math.round(v*100)+'%',xpb=c=>Math.ceil(Math.sqrt(isFinite(c)?c:1e6)/2),
PD=s=>{const o={};s.split(' ').forEach(p=>{if(!p)return;const[k,v]=p.split('=');o[k]=v===undefined?1:isNaN(v)?v:+v});return o},
mulberry32=a=>()=>{a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
const IC={money:'<circle cx="12" cy="12" r="9"/><path d="M12 6v12M15 9c0-2-6-2-6 .8s6 1.4 6 4.2-6 2-6 0"/>',chart:'<path d="M3 20h18M5 16l4-5 4 3 6-8M15 6h4v4"/>',
people:'<circle cx="9" cy="8" r="3"/><path d="M3 20c0-4 3-6 6-6s6 2 6 6M16 5a3 3 0 010 6M18 14c2 1 3 3 3 6"/>',
f1:'<circle cx="12" cy="12" r="9"/><path d="M8 14c1 2.5 7 2.5 8 0M9 9.5v.5M15 9.5v.5"/>',f2:'<circle cx="12" cy="12" r="9"/><path d="M8 15h8M9 9.5v.5M15 9.5v.5"/>',f3:'<circle cx="12" cy="12" r="9"/><path d="M8 16.5c1-2.5 7-2.5 8 0M9 9.5v.5M15 9.5v.5"/>',
star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',home:'<path d="M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6"/>',
shop:'<path d="M4 9l1-5h14l1 5M4 9c0 2 3 2 4 0 1 2 3 2 4 0 1 2 3 2 4 0 1 2 4 2 4 0M5 11v9h14v-9M10 20v-5h4v5"/>',fact:'<path d="M3 20V11l6 4v-4l6 4V5h4v15zM7 20v-2M11 20v-2M15 20v-2"/>',
bolt:'<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',school:'<path d="M2 9l10-5 10 5-10 5zM6 11v5c3 3 9 3 12 0v-5M22 9v6"/>',tree:'<path d="M12 21v-6M12 3c4 3 6 6 3 9 3 0 3 4-3 4s-6-4-3-4c-3-3-1-6 3-9z"/>',
bus:'<rect x="4" y="4" width="16" height="13" rx="2"/><path d="M4 11h16M7 20v-3M17 20v-3"/>',road:'<path d="M8 3L4 21M16 3l4 18M12 4v3M12 10v4M12 17v3"/>',
trash:'<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
gear:'<circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="6.5"/><path d="M12 2v3.5M12 18.5V22M2 12h3.5M18.5 12H22M4.9 4.9l2.5 2.5M16.6 16.6l2.5 2.5M19.1 4.9l-2.5 2.5M7.4 16.6l-2.5 2.5"/>',
up:'<path d="M12 19V5M6 11l6-6 6 6"/>',down:'<path d="M12 5v14M6 13l6 6 6-6"/>',left:'<path d="M19 12H5M11 6l-6 6 6 6"/>',right:'<path d="M5 12h14M13 6l6 6-6 6"/>',
rot:'<path d="M20 12a8 8 0 11-3-6M20 4v5h-5"/>',check:'<path d="M4 12l5 5L20 6"/>',close:'<path d="M5 5l14 14M19 5L5 19"/>',plus:'<path d="M12 5v14M5 12h14"/>',minus:'<path d="M5 12h14"/>',
build:'<path d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM15 16.5h5M17.5 14v5"/>',target:'<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
lock:'<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 018 0v3"/>',drop:'<path d="M12 3c4 5 6 8 6 11a6 6 0 01-12 0c0-3 2-6 6-11z"/>',brief:'<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V5h6v3M3 13h18"/>',
upg:'<path d="M12 20V7M6 13l6-6 6 6M5 3h14"/>',phone:'<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 19h2"/>',tab:'<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M11 16h2"/>',
pc:'<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/>',sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
moon:'<path d="M20 14A8 8 0 1110 4a6.5 6.5 0 0010 10z"/>',play:'<path d="M7 4l13 8-13 8z"/>',
rail:'<path d="M7 3l-2 18M17 3l2 18M6 8h12M5.5 13h13M5 18h14"/>',path:'<path d="M6 21c0-5 12-5 12-10S10 7 10 3"/>',mount:'<path d="M2 20l7-13 4 7 3-4 6 10z"/>',
oil:'<path d="M12 3c4 5 6 8 6 11a6 6 0 01-12 0c0-3 2-6 6-11z"/><path d="M9 15a3 3 0 003 3"/>',island:'<path d="M3 19c3 2 6 2 9 0s6-2 9 0M12 16V7M12 7c-3-1-5 0-6 2M12 7c3-1 5 0 6 2"/>'},
ic=(n,c)=>`<svg viewBox="0 0 24 24"${c?` style="stroke:${c}"`:''}>${IC[n]}</svg>`;
const D={},def=(id,n,c,w,d,h,cost,lv,o)=>{D[id]=Object.assign({n,c,w,d,h,cost,lv,up:Math.round(cost*.01),k:'b'},o);D[id].mp=PD(o.m||'')};
def('house','Домик','res',1,1,1,100,1,{pop:4,tx:1.5,m:'f=b c=#e8c9a0 r=#b5483a t=g d ch ga=1'});
def('cott','Коттедж','res',1,1,1.2,400,2,{pop:9,tx:1.8,m:'f=w c=#d9a47a r=#7a4a3a t=g d ch bl ga=1'});
def('town','Таунхаус','res',2,1,1.5,1200,3,{pop:22,tx:1.8,m:'f=b c=#c9826a r=#5a3a32 t=g d bl ch ga=2'});
def('duplex','Дуплекс','res',2,1,1.2,1800,3,{pop:30,tx:2,m:'f=w c=#e0cfa8 r=#6a4a3a t=g d bl ch ga=2'});
def('villa','Вилла','res',2,2,1.5,6000,5,{pop:30,tx:4,m:'f=w c=#f0e6d2 r=#c0603a t=g d co ch ga=2'});
def('modern','Современный дом','res',2,1,1.2,9000,5,{pop:26,tx:4,m:'f=g c=#9ab8d0 d bl ga=1'});
def('apt','Многоэтажка','res',2,1,3,2500,4,{pop:70,tx:1.8,m:'f=b c=#c9a38a bl ac tk'});
def('court','Дом с двором','res',2,2,3,40000,7,{pop:500,tx:3,m:'f=b c=#c08868 bl ac ga=2'});
def('manor','Усадьба','res',2,2,1.6,50000,7,{pop:60,tx:6,m:'f=b c=#d8c8a0 r=#4a3a32 t=g co d ch ga=2'});
def('block','Жилой квартал','res',2,2,5,22000,6,{pop:350,tx:3,m:'f=w c=#cfc7b8 bl ac an'});
def('panel','Панельный дом','res',3,1,4,120000,8,{pop:800,tx:3,m:'f=w c=#b8b8b0 bl ac an'});
def('loft','Лофт-башня','res',2,2,6,250000,8,{pop:1100,tx:5,m:'f=i c=#8a6a5a bl ac'});
def('tower','Высотка','res',2,2,8,4e5,9,{pop:2000,tx:8,m:'f=g c=#6fa8d6 po cw an'});
def('elite','Элитный комплекс','res',3,2,10,6e6,13,{pop:8000,tx:28,m:'f=g c=#9ec9e8 po cw an bl'});
def('mega','Мегабашня','res',3,3,18,1.5e8,20,{pop:70000,tx:75,m:'f=g c=#7fb0e0 po cw an'});
def('shop','Магазин','com',1,1,1,150,1,{jobs:3,inc:8,m:'f=s c=#f2e2b0 a=#d94a3a sg=#ffb300 d ac'});
def('cafe','Кафе','com',1,1,1,400,2,{jobs:6,inc:24,m:'f=s c=#d9b08a a=#3a8a5a sg=#ff7043 d'});
def('bak','Пекарня','com',1,1,1,700,2,{jobs:5,inc:36,m:'f=s c=#f0c08a a=#e07a3a sg=#ffd54f d ch'});
def('cloth','Магазин одежды','com',1,1,1,1200,3,{jobs:5,inc:60,m:'f=s c=#f0d0e0 a=#c04080 sg=#ff80b0 d'});
def('pharm','Аптека','com',1,1,1,1500,3,{jobs:6,inc:90,m:'f=s c=#e8f0f0 a=#2e9e5a sg=#35d07f d'});
def('rest','Ресторан','com',2,1,1.2,3000,3,{jobs:12,inc:85,m:'f=s c=#d8b890 a=#8a2a2a sg=#ffb300 d'});
def('gas','Заправка','com',2,1,.5,4000,4,{jobs:8,inc:160,m:'f=s c=#e8e8e8 ct=#e53935 sg=#e53935 d'});
def('elec','Электроника','com',2,1,1,9000,4,{jobs:15,inc:300,m:'f=s c=#d0e0f0 a=#2a6fd6 sg=#40c0ff d'});
def('bank','Банк','com',2,1,1.5,2e4,5,{jobs:30,inc:420,m:'f=w c=#e6e0d0 co d sg=#2a6fd6'});
def('gym','Спортзал','com',2,1,1,2e4,5,{jobs:20,inc:520,m:'f=i c=#8a9ab0 sg=#ff6040 d'});
def('super','Супермаркет','com',2,2,1,12000,5,{jobs:40,inc:480,m:'f=s c=#e8e0c8 sg=#e53935 d ac'});
def('cardlr','Автосалон','com',2,1,.8,5e4,6,{jobs:20,inc:900,m:'f=g c=#c0d0e0 d sg=#e53935 ga=2'});
def('cine','Кинотеатр','com',2,2,1.5,9e4,7,{jobs:60,inc:2000,m:'f=i c=#4a4a6a sg=#ff4081 d an'});
def('mall','Торговый центр','com',3,2,2,1.5e5,8,{jobs:200,inc:5000,m:'f=s c=#e5b8c8 sg=#e57fa0 d ac cw'});
def('office','Офис','com',2,1,6,7e5,10,{jobs:500,inc:2e4,m:'f=g c=#7fb7c9 cw an'});
def('hotel','Отель','com',2,2,7,3e6,12,{jobs:800,inc:9e4,m:'f=w c=#e8d8f0 po sg=#c9a0dc bl cw'});
def('bizc','Бизнес-центр','com',2,2,9,1.2e7,13,{jobs:2500,inc:5e5,m:'f=g c=#6a9ac0 po cw an'});
def('sky','Небоскрёб','com',2,2,14,4e7,16,{jobs:6000,inc:1.1e6,m:'f=g c=#5f9fd0 po cw an'});
def('work','Мастерская','ind',1,1,1,300,2,{jobs:8,inc:25,pl:1,m:'f=i c=#a89a8a t=s ch sm'});
def('saw','Лесопилка','ind',2,1,1,1500,2,{jobs:12,inc:55,pl:1,m:'f=i c=#a88a5a t=s ch sm'});
def('farm','Ферма','ind',3,2,1,4000,2,{jobs:10,inc:90,k:'farm'});
def('fact','Завод','ind',2,2,1.5,2000,3,{jobs:40,inc:130,pl:3,m:'f=i c=#9a9a9a t=s ch sm ga=2'});
def('ware','Склад','ind',2,2,1,6000,5,{jobs:20,inc:300,pl:1,m:'f=i c=#8a9aa8 r=#6a7a88 ga=3'});
def('mine','Шахта','ind',2,2,1,8e4,5,{jobs:80,inc:2500,pl:2,k:'mine'});
def('pump','Нефтяная вышка','ind',1,1,1,3e4,5,{jobs:10,inc:1800,pl:2,k:'pump'});
def('brew','Пивоварня','ind',2,2,1.5,6e4,6,{jobs:60,inc:1500,pl:1,m:'f=b c=#b07a5a ch sm tk'});
def('comp','Производственный комплекс','ind',3,2,2,4e5,9,{jobs:500,inc:12000,pl:6,m:'f=i c=#8a8f98 t=s ch sm ga=3'});
def('ref','Нефтезавод','ind',3,3,1,1.2e7,14,{jobs:4000,inc:3.5e5,pl:12,k:'ref'});
def('coal','Угольная ЭС','inf',2,2,1,2000,1,{pw:150,pl:4,k:'power'});
def('wind','Ветряк','inf',1,1,1,3000,3,{pw:50,k:'wind'});
def('solar','Солнечная ферма','inf',2,2,1,10000,4,{pw:120,k:'solar'});
def('nuke','АЭС','inf',3,3,1,2e7,12,{pw:3000,pl:1,k:'nuke'});
def('water','Водонапорная башня','inf',1,1,1,300,1,{wt:80,k:'tank'});
def('treat','Очистные сооружения','inf',2,2,1,1e5,7,{wt:1200,k:'treat'});
def('waste','Мусорный завод','inf',2,2,1.5,5e4,6,{jobs:50,pl:-2,hp:3,m:'f=i c=#6a8a5a ch sm tk'});
def('school','Школа','pub',2,1,1,3000,2,{jobs:10,hp:5,m:'f=b c=#e0b070 r=#8a4a3a t=g fg d'});
def('kg','Детский сад','pub',2,1,1,8000,3,{jobs:8,hp:8,m:'f=w c=#ffd0a0 r=#e05050 t=g d fg'});
def('post','Почта','pub',1,1,1,6000,3,{jobs:6,hp:4,m:'f=w c=#e8e0d0 r=#3a5ac9 t=g d'});
def('hosp','Больница','pub',2,2,2.5,25000,4,{jobs:60,hp:12,m:'f=w c=#f4f4f4 cr d ac'});
def('fire','Пожарная станция','pub',2,1,1,20000,5,{jobs:20,hp:6,m:'f=w c=#d94a3a st=#ffffff ga=2'});
def('police','Полиция','pub',2,1,1.5,20000,5,{jobs:20,hp:6,m:'f=w c=#3a5ac9 st=#ffffff d an'});
def('lib','Библиотека','pub',2,1,1.5,6e4,6,{jobs:15,hp:20,m:'f=b c=#c9b08a co d'});
def('church','Церковь','pub',2,1,1.5,4e5,7,{jobs:10,hp:100,m:'f=w c=#efe8d8 r=#6a6a72 t=g sp d'});
def('univ','Университет','pub',3,2,2.5,1.5e6,9,{jobs:300,hp:80,m:'f=b c=#b09060 co d cw'});
def('theater','Театр','pub',2,2,2,2e6,9,{jobs:80,hp:200,inc:3e4,m:'f=w c=#c8a0a0 co d fg'});
def('hall','Мэрия','pub',2,2,2,8e6,11,{jobs:200,hp:200,m:'f=w c=#e8e0c8 t=d co d fg'});
def('cthouse','Суд','pub',2,2,2,3e6,10,{jobs:100,hp:120,m:'f=w c=#e6e0d0 co d fg'});
def('muse','Музей','pub',3,2,2,4e6,12,{jobs:100,hp:120,m:'f=w c=#e0dccc co d fg'});
def('stad','Стадион','pub',3,3,2,8e7,17,{jobs:1500,hp:1500,inc:3e5,up:2e5,k:'stad'});
def('tree','Дерево','dec',1,1,1,20,1,{hp:.5,pl:-.3,k:'tree'});
def('pine','Ель','dec',1,1,1,30,1,{hp:.5,pl:-.3,k:'tree',m:'v=1'});
def('hedge','Живая изгородь','dec',1,1,.4,80,1,{hp:.8,k:'hedge'});
def('flow','Клумба','dec',1,1,.3,60,1,{hp:1,k:'flow'});
def('pond','Пруд','dec',2,2,.1,2500,2,{hp:8,pl:-1,k:'pond'});
def('park','Парк','dec',2,2,1,1500,2,{hp:6,pl:-1,k:'park'});
def('fount','Фонтан','dec',1,1,1,6000,3,{hp:5,k:'fount'});
def('gaz','Беседка','dec',1,1,1,2500,3,{hp:4,k:'gaz'});
def('play','Детская площадка','dec',2,2,.2,15000,4,{hp:20,k:'play'});
def('sport','Спортплощадка','dec',2,2,.2,40000,5,{hp:30,k:'sport'});
def('rink','Каток','dec',2,2,.2,60000,6,{hp:40,k:'rink'});
def('stat','Скульптура','dec',1,1,1.5,1.5e5,6,{hp:60,k:'stat'});
def('mon','Памятник','dec',2,2,3,3e6,11,{hp:400,k:'mon'});
def('cpark','Центральный парк','dec',4,4,1,2.5e7,15,{hp:3000,pl:-6,k:'park'});
def('bus','Автобусная остановка','trans',1,1,1,500,2,{hp:2,k:'busst'});
def('lot','Парковка','trans',2,2,.1,5000,3,{hp:4,inc:40,k:'lot'});
def('depot','Автобусное депо','trans',3,2,1,8e4,4,{jobs:30,hp:5,k:'depot'});
def('cdep','Строительная база','trans',3,2,1,1.2e5,6,{jobs:30,k:'cdep'});
def('stn','Ж/д станция','trans',3,2,1,2e6,10,{jobs:200,hp:150,inc:6e4,rail:1,k:'stn'});
def('heli','Вертолётная площадка','trans',2,2,.1,6e6,14,{jobs:30,hp:50,k:'heli'});
def('air','Аэропорт','trans',4,3,1,9e8,22,{jobs:20000,hp:3000,inc:2e7,k:'air'});
const CATS=[['res','Жильё','home','#ff9f5a'],['com','Коммерция','shop','#ffd54f'],['ind','Промышленность','fact','#b0bec5'],['inf','Инфраструктура','bolt','#ffe94d'],['pub','Общественные','school','#7ec8ff'],['dec','Украшения','tree','#6adf7a'],['trans','Транспорт','bus','#9fa8ff']],
NT=[['road','Дорога','road',10],['path','Тропинка для людей','path',4],['rail','Железная дорога','rail',30]],NETT=['road','path','rail'],
LOC={flat:['Равнина','Ровная земля и немного лесов','home',0xffffff],river:['Речная долина','Река, мосты и зелёные берега','drop',0xf0ffe8],lakes:['Озёрный край','Озёра, леса и тишина','tree',0xe8ffe0],mount:['Горы и руда','Горы, шахты и месторождения руды','mount',0xd8e8d0],oil:['Пустыня и нефть','Песок, нефть и редкие горы','oil',0xe8d8a8],archi:['Архипелаг','Острова, мосты и открытое море','island',0xffffff]};
const Q=[['Построй 3 дома',()=>cnt('house')>=3,300],['Набери 20 жителей',()=>S.pop>=20,500],['Построй электростанцию и водонапорную башню',()=>cnt('coal')&&cnt('water'),800],
['Набери 100 жителей',()=>S.pop>=100,2000],['300 жителей и счастье 70%',()=>S.pop>=300&&S.hap>=70,5000],['Построй автобусное депо и остановку',()=>cnt('depot')&&cnt('bus'),12000],
['Набери 2000 жителей',()=>S.pop>=2000,40000],['Проложи рельсы и построй станцию',()=>cnt('stn')&&RT.length>5,3e5],['Набери 25 000 жителей',()=>S.pop>=25000,1e6],['Построй небоскрёб',()=>cnt('sky')>0,5e7],['Построй аэропорт',()=>cnt('air')>0,2e9],['Набери 1 000 000 жителей',()=>S.pop>=1e6,1e10]];
const DEF={pan:1,zoom:1,rot:1,mom:.9,smooth:.25,tilt:.9,dist:26,fov:50,inv:0,shd:1,bloom:.5,pr:1.35,sh:1,shq:1,fog:170,grid:1,cloud:1,den:1,dn:3,hour:12,ui:1,dps:1,op:.76,dpm:1,spd:1,hint:1,ql:2,asv:8},
OP=[[0,'pan','Скорость перемещения',.3,3,.1],[0,'zoom','Скорость зума',.3,3,.1],[0,'rot','Скорость вращения',.3,3,.1],[0,'tilt','Наклон камеры',.3,1.5,.05],[0,'dist','Дистанция камеры',6,70,1],
[1,'den','Оживлённость города',0,2,.1],[2,'spd','Скорость игры',.5,4,.5],[2,'dn','Сутки, мин (0 — стоп)',0,10,.5],[2,'hour','Время суток, ч',0,24,.5],[2,'ui','Размер интерфейса',.6,1.6,.05]],
TG=[[1,'shd','Шейдеры'],[1,'sh','Тени'],[1,'grid','Сетка на земле'],[2,'hint','Подсказки']],
DEVS={phone:{ui:.88,q:1},tab:{ui:1.1,q:2},pc:{ui:1,q:2,pr:1.75}},QP=[{pr:1,sh:0,shq:0,fog:100,cloud:0,shd:0},{pr:1.1,sh:1,shq:0,fog:140,cloud:1,shd:0},{pr:1.35,sh:1,shq:1,fog:170,cloud:1,shd:1}];
const S={slot:-1},SET=Object.assign({dev:''},DEF),C={x:0,z:0,gx:0,gz:0,d:26,gd:26,yaw:.8,gy:.8,pitch:.9,gp:.9,vx:0,vz:0,lt:0},T=new Uint8Array(N*N);
try{Object.assign(SET,JSON.parse(localStorage.getItem('mcs')))}catch(e){}
let blds=[],RL=[],RT=[],RP=[],grid=new Array(N*N).fill(null),mv=[],pt=[],PLN=[],HM=[],DST=[],STP=[],DEP=[],HG=[],tool=null,cur=null,openC=null,sel=null,gx=19,gz=19,grot=0,ghost=null,curOn=0,tab=0,last=0,acc=0,sa=0,ck=0,smT=0,paused=1,dirty=0,pend=null,CP=null,BL=null,fxLoading=0,ns={slot:0,mode:0,loc:'flat',seed:1},delArm=-1;
const cnt=id=>blds.filter(b=>b.id==id).length,isR=(x,z)=>x>=0&&z>=0&&x<N&&z<N&&grid[z*N+x]=='r',isT=(x,z)=>x>=0&&z>=0&&x<N&&z<N&&grid[z*N+x]=='t',isP=(x,z)=>x>=0&&z>=0&&x<N&&z<N&&grid[z*N+x]=='p',isW=(x,z)=>isR(x,z)||isP(x,z),dims=(d,r)=>r&1?[d.d,d.w]:[d.w,d.d];
const GC={},MTC={},G=(t,...a)=>{const k=t+a;return GC[k]||(GC[k]=new THREE[t](...a))},
Bx=(a,b,c)=>G('BoxGeometry',a,b,c),Cy=(a,b,c,s)=>G('CylinderGeometry',a,b,c,s||10),Sp=r=>G('SphereGeometry',r,10,8),Co=(r,h,s)=>G('ConeGeometry',r,h,s||8),
MT=c=>MTC[c]||(MTC[c]=new THREE.MeshLambertMaterial({color:c})),MB=c=>MTC['b'+c]||(MTC['b'+c]=new THREE.MeshBasicMaterial({color:c}));
const R=new THREE.WebGLRenderer({canvas:$('c'),antialias:true}),sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(50,1,.5,400);
R.shadowMap.enabled=true;R.shadowMap.type=THREE.PCFSoftShadowMap;sc.fog=new THREE.Fog(0xbfe3ff,50,170);
const hemi=new THREE.HemisphereLight(0xffffff,0x6a8a5a,.55),sun=new THREE.DirectionalLight(0xfff2d6,.75);sc.add(hemi,sun,sun.target);
Object.assign(sun.shadow.camera,{left:-36,right:36,top:36,bottom:-36,near:1,far:200});sun.shadow.camera.updateProjectionMatrix();sun.shadow.bias=-.0006;sun.shadow.normalBias=.03;
const SKY=new THREE.Mesh(new THREE.SphereGeometry(250,16,10),new THREE.ShaderMaterial({side:THREE.BackSide,depthWrite:false,fog:false,uniforms:{t:{value:new THREE.Color()},b:{value:new THREE.Color()}},
vertexShader:'varying float y;void main(){y=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
fragmentShader:'uniform vec3 t,b;varying float y;void main(){gl_FragColor=vec4(mix(b,t,pow(max(y,0.),.6)),1.);}'}));sc.add(SKY);
const sunD=new THREE.Mesh(Sp(9),new THREE.MeshBasicMaterial({color:0xfff0b0,fog:false})),moonD=new THREE.Mesh(Sp(5),new THREE.MeshBasicMaterial({color:0xdde6ff,fog:false}));sc.add(sunD,moonD);
const stg=new THREE.BufferGeometry(),spA=new Float32Array(600);for(let i=0;i<200;i++){const a=Math.random()*6.28,b=Math.random()*1.4+.05;spA[i*3]=Math.cos(a)*Math.cos(b)*235;spA[i*3+1]=Math.sin(b)*235;spA[i*3+2]=Math.sin(a)*Math.cos(b)*235}
stg.setAttribute('position',new THREE.BufferAttribute(spA,3));const stars=new THREE.Points(stg,new THREE.PointsMaterial({color:0xffffff,size:1.6,sizeAttenuation:false,transparent:true,opacity:0,fog:false}));sc.add(stars);
const clouds=new THREE.Group(),cmat=new THREE.MeshLambertMaterial({color:0xffffff,transparent:true,opacity:.88});
for(let i=0;i<9;i++){const c=new THREE.Group();for(let j=0;j<4;j++){const s=new THREE.Mesh(Sp(1),cmat);s.scale.set(7+Math.random()*5,2.5+Math.random(),5+Math.random()*3);s.position.set(j*6-9,Math.random()*2,Math.random()*4-2);c.add(s)}c.position.set(Math.random()*280-140,85+Math.random()*15,Math.random()*280-140);clouds.add(c)}sc.add(clouds);
const cNs=new THREE.Color(0x9fb4ff),cDs=new THREE.Color(0xfff2d6),cSs=new THREE.Color(0xff9a5a),tN=new THREE.Color(0x050a22),tD=new THREE.Color(0x3d8ee0),tS=new THREE.Color(0x5a6fb0),bN=new THREE.Color(0x16224a),bD=new THREE.Color(0xbfe3ff),bS=new THREE.Color(0xff9a63),
hN=new THREE.Color(0x6a7fb8),hD=new THREE.Color(0xffffff),gN=new THREE.Color(0x1f2a3a),gD=new THREE.Color(0x6a8a5a),v3b=new THREE.Vector3(),lampM=new THREE.MeshBasicMaterial({color:0x6f6f66}),FM=[];
function env(){const a=S.tm*Math.PI*2-Math.PI/2,sh=Math.sin(a),k=cl(sh*2.5+.35,0,1),du=cl(1-Math.abs(sh)*3.5,0,1),n=1-k;
sun.position.set(C.x+Math.cos(a)*50,14+Math.max(0,sh)*36,C.z+25);sun.target.position.set(C.x,0,C.z);
sun.color.copy(cNs).lerp(cDs,k).lerp(cSs,du*.6);sun.intensity=.28+.47*k;hemi.color.copy(hN).lerp(hD,k);hemi.groundColor.copy(gN).lerp(gD,k);hemi.intensity=.42+.13*k;
const t=SKY.material.uniforms.t.value,b=SKY.material.uniforms.b.value;t.copy(tN).lerp(tD,k).lerp(tS,du*.45);b.copy(bN).lerp(bD,k).lerp(bS,du*.7);sc.fog.color.copy(b);R.setClearColor(b);
FM.forEach(m=>m.emissiveIntensity=n*1.1);lampM.color.setHex(n>.45?0xffe9a0:0x6f6f66);cmat.color.setScalar(.35+.65*k);stars.material.opacity=cl(n*1.4-.3,0,1);
const d=v3b.set(Math.cos(a),sh,.3).normalize();sunD.position.copy(cam.position).addScaledVector(d,200);moonD.position.copy(cam.position).addScaledVector(d,-200);SKY.position.copy(cam.position);stars.position.copy(cam.position)}
function initFX(){if(CP||!THREE.EffectComposer||!THREE.UnrealBloomPass||!THREE.ShaderPass||!THREE.RenderPass)return;
try{CP=new THREE.EffectComposer(R);CP.addPass(new THREE.RenderPass(sc,cam));BL=new THREE.UnrealBloomPass(new THREE.Vector2(innerWidth/2,innerHeight/2),SET.bloom,.6,.92);CP.addPass(BL);
CP.addPass(new THREE.ShaderPass({uniforms:{tDiffuse:{value:null}},vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
fragmentShader:'uniform sampler2D tDiffuse;varying vec2 vUv;void main(){vec3 x=texture2D(tDiffuse,vUv).rgb*1.12;x=(x*(2.51*x+.03))/(x*(2.43*x+.59)+.14);float l=dot(x,vec3(.299,.587,.114));x=mix(vec3(l),x,1.2);vec2 d=vUv-.5;x*=1.-dot(d,d)*.8;gl_FragColor=vec4(x,1.);}'}));
CP.setPixelRatio(Math.min(devicePixelRatio,SET.pr));CP.setSize(innerWidth,innerHeight)}catch(e){CP=null;BL=null}}
const loadJS=u=>new Promise(r=>{const s=document.createElement('script');s.src=u;s.onload=()=>r(1);s.onerror=()=>r(0);document.head.appendChild(s)});
async function loadFX(){if(CP||fxLoading)return;if(THREE.EffectComposer&&THREE.UnrealBloomPass&&THREE.RenderPass&&THREE.ShaderPass){initFX();return}
fxLoading=1;const b='https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/';let ok=1;
for(const f of['shaders/CopyShader.js','shaders/LuminosityHighPassShader.js','postprocessing/EffectComposer.js'])if(ok&&!await loadJS(b+f))ok=0;
if(ok&&!THREE.Pass&&!await loadJS(b+'postprocessing/Pass.js'))ok=0;
for(const f of['postprocessing/RenderPass.js','postprocessing/ShaderPass.js','postprocessing/UnrealBloomPass.js'])if(ok&&!await loadJS(b+f))ok=0;
if(ok){fxLoading=0;initFX()}else toast('Шейдеры не загрузились: нужен интернет')}
function waterTex(rep){const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle='#4aa0e0';x.fillRect(0,0,128,128);x.strokeStyle='rgba(255,255,255,.28)';x.lineWidth=2;
for(let i=0;i<14;i++){const px=Math.random()*128,py=Math.random()*128;x.beginPath();x.moveTo(px,py);x.quadraticCurveTo(px+10,py-6,px+22,py);x.stroke()}
const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rep,rep);return t}
function grassTex(){const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.fillStyle='#62ad4f';x.fillRect(0,0,128,128);
for(let i=0;i<500;i++){x.fillStyle=Math.random()<.5?'rgba(255,255,255,.07)':'rgba(0,40,0,.08)';x.fillRect(Math.random()*128,Math.random()*128,2+Math.random()*3,2+Math.random()*3)}
const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(N/5,N/5);return t}
const WT=waterTex(1),ST=waterTex(60),WM=new THREE.MeshLambertMaterial({map:WT}),sea=new THREE.Mesh(new THREE.PlaneGeometry(800,800),new THREE.MeshLambertMaterial({map:ST}));sea.rotation.x=-Math.PI/2;sea.position.y=-.4;sc.add(sea);
const beach=new THREE.Mesh(Bx(N+3,.3,N+3),MT(0xe3d3a0));beach.position.y=-.2;sc.add(beach);
const land=new THREE.Mesh(Bx(N+1,.4,N+1),new THREE.MeshLambertMaterial({map:grassTex()}));land.position.y=-.2;land.receiveShadow=true;sc.add(land);
const gh=new THREE.GridHelper(N,N,0x4f9a40,0x4f9a40);gh.position.y=.01;gh.material.transparent=true;gh.material.opacity=.22;sc.add(gh);
const fp=new THREE.Mesh(new THREE.PlaneGeometry(1,1),new THREE.MeshBasicMaterial({transparent:true,opacity:.5,depthWrite:false}));fp.rotation.x=-Math.PI/2;fp.visible=false;sc.add(fp);
const tm4=new THREE.Matrix4(),tq=new THREE.Quaternion(),tv=new THREE.Vector3(),ts=new THREE.Vector3(),YA=new THREE.Vector3(0,1,0),tcol=new THREE.Color(),
M=(x,y,z,sx,sy,sz,ry)=>{tq.setFromAxisAngle(YA,ry||0);return tm4.compose(tv.set(x,y,z),tq,ts.set(sx||1,sy||1,sz||1))};
const lfC={},SWT={value:0},SWA={value:0};
function LF(c){if(lfC[c])return lfC[c];const m=new THREE.MeshLambertMaterial({color:c});
m.onBeforeCompile=s=>{s.uniforms.swT=SWT;s.uniforms.swA=SWA;s.vertexShader='uniform float swT;uniform float swA;\n'+s.vertexShader.replace('#include <begin_vertex>',`#include <begin_vertex>
#ifdef USE_INSTANCING
float ph=instanceMatrix[3][0]+instanceMatrix[3][2];
#else
float ph=modelMatrix[3][0]+modelMatrix[3][2];
#endif
float hw=max(transformed.y+.5,0.);
transformed.x+=sin(swT*2.+ph+hw*3.)*.05*swA*hw;
transformed.z+=cos(swT*1.7+ph+hw*3.)*.04*swA*hw;`)};return lfC[c]=m}
const RM=()=>new THREE.MeshPhongMaterial({color:0xffffff,flatShading:true,shininess:0});
const TM={w:new THREE.InstancedMesh(Bx(1,.05,1),WM,N*N),s:new THREE.InstancedMesh(Bx(1,.02,1),MT(0xe6d6a0),N*N),r:new THREE.InstancedMesh(Co(.8,1,6),RM(),N*N),n:new THREE.InstancedMesh(Co(.8,1,6),RM(),N*N),
t:new THREE.InstancedMesh(Cy(.04,.05,.25,5),MT(0x6a4a2a),N*N*3),l:new THREE.InstancedMesh(Co(.26,.7,6),LF(0xffffff),N*N*3),o:new THREE.InstancedMesh(Cy(.45,.45,.03,12),MT(0x14141a),N*N),e:new THREE.InstancedMesh(G('OctahedronGeometry',.16),new THREE.MeshLambertMaterial({color:0xffffff,emissive:0x1a2a3a}),N*N*2)};
Object.values(TM).forEach(m=>{m.frustumCulled=false;m.receiveShadow=true;sc.add(m)});TM.r.castShadow=TM.l.castShadow=TM.t.castShadow=true;
['r','n','l','e'].forEach(k=>TM[k].setColorAt(0,tcol.setHex(0xffffff)));
function setLand(k){land.material.color.setHex(LOC[k]?LOC[k][3]:0xffffff)}
function genMap(k,seed,A){A=A||T;A.fill(0);const r=mulberry32(seed),at=(x,z,v,o)=>{if(x<0||z<0||x>=N||z>=N)return;const i=z*N+x;if(o&&A[i])return;A[i]=v},
blob=(v,n,rad,o)=>{for(let i=0;i<n;i++){const cx=r()*N,cz=r()*N,rr=rad*(.6+r()*.8);for(let z=(-rr-2)|0;z<=rr+2;z++)for(let x=(-rr-2)|0;x<=rr+2;x++)if(Math.hypot(x,z)+Math.sin(x*1.7+z*2.3+i)*.7<rr)at((cx+x)|0,(cz+z)|0,v,o)}};
if(k=='archi'){A.fill(1);blob(0,7,6);for(let z=0;z<N;z++)for(let x=0;x<N;x++)if(Math.hypot(x-N/2+.5,z-N/2+.5)<12+Math.sin(x*.5)*1.5)A[z*N+x]=0;blob(3,6,3,1);blob(5,1,2,1)}
else if(k=='river'){const ph=r()*6;for(let x=0;x<N;x++){const zc=8+Math.sin(x*.22+ph)*4+Math.sin(x*.5)*1.5;for(let d=-1;d<=1;d++)at(x,(zc+d)|0,1)}blob(3,8,3,1)}
else if(k=='lakes'){blob(1,4,4.5);blob(3,9,3,1)}
else if(k=='mount'){blob(2,6,4);blob(5,3,2,1);blob(3,5,3,1)}
else if(k=='oil'){blob(4,3,2.2);blob(2,2,3,1);blob(3,2,2,1)}
else blob(3,6,3);
for(let z=0;z<N;z++)for(let x=0;x<N;x++)if(Math.abs(x-N/2+.5)<7&&Math.abs(z-N/2+.5)<7&&A[z*N+x]!=3)A[z*N+x]=0}
const PV={};
function preview(k,seed){const key=k+seed;if(PV[key])return PV[key];const A=new Uint8Array(N*N);genMap(k,seed,A);const c=document.createElement('canvas');c.width=c.height=N*3;const x=c.getContext('2d'),col=['','#3f8fd8','#7d7a74','#2f7a3a','#1b1b20','#40c4ff'],gr=k=='oil'?'#dccb94':'#62ad4f';
for(let z=0;z<N;z++)for(let q=0;q<N;q++){const v=A[z*N+q];x.fillStyle=v?col[v]:gr;x.fillRect(q*3,z*3,3,3)}
x.strokeStyle='#ffd54f';x.lineWidth=2;x.setLineDash([6,4]);x.strokeRect(13*3,13*3,14*3,14*3);return PV[key]=c.toDataURL()}
function rebuildTerrain(){const cn={w:0,s:0,r:0,n:0,t:0,l:0,o:0,e:0},sm=new Uint8Array(N*N),
ps=(k,m,col)=>{const I=TM[k],i=cn[k]++;I.setMatrixAt(i,m);if(col!=null)I.setColorAt(i,tcol.setHex(col))};
for(let z=0;z<N;z++)for(let x=0;x<N;x++){const i=z*N+x,v=T[i];if(!v)continue;const cx=x-N/2+.5,cz=z-N/2+.5,hv=((x*73856093)^(z*19349663))>>>0,f1=(hv%997)/997,f2=(hv%991)/991;
if(v==1){ps('w',M(cx,-.005,cz));[[1,0],[-1,0],[0,1],[0,-1]].forEach(([a,b])=>{const X=x+a,Z=z+b;if(X>=0&&Z>=0&&X<N&&Z<N)sm[Z*N+X]=1})}
else if(v==2){const h=1.2+f1*2.2,r=.65+f2*.35;ps('r',M(cx+(f2-.5)*.2,h/2,cz+(f1-.5)*.2,r,h,r,f1*6),[0x7d7a74,0x8a8680,0x6e6a66][hv%3]);if(h>2.5)ps('n',M(cx,h*.81,cz,r*.38,h*.38,r*.38,f1*6),0xffffff)}
else if(v==3){for(let k=0;k<3;k++){const ox=((hv>>>(k*5))%100/100-.5)*.7,oz=((hv>>>(k*5+2))%100/100-.5)*.7,s=.8+((hv>>>k)%50)/100;ps('t',M(cx+ox,.125*s,cz+oz,s,s,s));ps('l',M(cx+ox,.6*s,cz+oz,s,s,s),[0x2f8a3e,0x2a7a38,0x3a9a48][k])}}
else if(v==4)ps('o',M(cx,.02,cz,.8+f1*.3,1,.8+f2*.3));
else if(v==5){const c=[0x40c4ff,0xffb74d,0x9ccc65][hv%3];ps('e',M(cx-.15,.14,cz-.1,1,1+f1,1,f1*6),c);ps('e',M(cx+.15,.1,cz+.12,.8,1+f2*.6,.8,f2*6),c)}}
for(let i=0;i<N*N;i++)if(sm[i]&&T[i]!=1)ps('s',M((i%N)-N/2+.5,.011,((i/N)|0)-N/2+.5));
for(const k in TM){const I=TM[k];I.count=cn[k];I.instanceMatrix.needsUpdate=true;if(I.instanceColor)I.instanceColor.needsUpdate=true}}
const IM=[new THREE.InstancedMesh(Bx(1,.03,1),MT(0xbfc2c6),N*N),new THREE.InstancedMesh(Bx(1,.06,1),MT(0x44484d),N*N*3),new THREE.InstancedMesh(Bx(.3,.075,.05),MB(0xf5f5f5),N*N*2),new THREE.InstancedMesh(Cy(.02,.025,.45,6),MT(0x555a60),N*N),new THREE.InstancedMesh(Sp(.05),lampM,N*N),
new THREE.InstancedMesh(Bx(.9,.03,.9),MT(0x8a7f72),N*N),new THREE.InstancedMesh(Bx(1,.04,.05),MT(0x9a9ea4),N*N*4),new THREE.InstancedMesh(Bx(.06,.03,.46),MT(0x5a4630),N*N*6),new THREE.InstancedMesh(Bx(.4,.02,.4),MT(0xd8c590),N*N*3)];
IM.forEach(m=>{m.frustumCulled=false;m.receiveShadow=true;sc.add(m)});
function rebuildNet(){RL=[];RT=[];RP=[];const ct=IM.map(()=>0),put=(k,m)=>IM[k].setMatrixAt(ct[k]++,m);
for(let z=0;z<N;z++)for(let x=0;x<N;x++){const t=grid[z*N+x];if(!t||t.id)continue;const cx=x-N/2+.5,cz=z-N/2+.5;
if(t=='r'){RL.push([x,z]);put(0,M(cx,.015,cz));put(1,M(cx,.03,cz,.78,1,.78));
if(isR(x+1,z)){put(1,M(cx+.5,.03,cz,1,1,.78));put(2,M(cx+.5,.065,cz))}
if(isR(x,z+1)){put(1,M(cx,.03,cz+.5,.78,1,1));put(2,M(cx,.065,cz+.5,1,1,1,Math.PI/2))}
if((x*3+z*5)%4==0){const sx=(x+z)%2?-1:1;put(3,M(cx+.46*sx,.22,cz+.46));put(4,M(cx+.46*sx,.47,cz+.46))}}
else if(t=='t'){RT.push([x,z]);put(5,M(cx,.02,cz));const hh=isT(x+1,z)||isT(x-1,z),vv=isT(x,z+1)||isT(x,z-1),
ln=ry=>{[-.14,.14].forEach(o=>put(6,M(cx+(ry?o:0),.06,cz+(ry?0:o),1,1,1,ry)));for(let k=-1;k<=1;k++)put(7,M(cx+(ry?0:k*.3),.04,cz+(ry?k*.3:0),1,1,1,ry))};
if(hh||!vv)ln(0);if(vv)ln(Math.PI/2)}
else{RP.push([x,z]);put(8,M(cx,.02,cz));if(isW(x+1,z))put(8,M(cx+.5,.02,cz));if(isW(x,z+1))put(8,M(cx,.02,cz+.5))}}
IM.forEach((m,k)=>{m.count=ct[k];m.instanceMatrix.needsUpdate=true})}
const FC={},MC={};
function fac(f,c){const k=f+c;if(FC[k])return FC[k];const a=document.createElement('canvas'),b=document.createElement('canvas');a.width=a.height=b.width=b.height=64;const x=a.getContext('2d'),y=b.getContext('2d');
x.fillStyle=c;x.fillRect(0,0,64,64);y.fillStyle='#000';y.fillRect(0,0,64,64);
const W=(px,py,w,h,gl,lit)=>{x.fillStyle='rgba(0,0,0,.35)';x.fillRect(px-2,py-2,w+4,h+4);x.fillStyle=gl;x.fillRect(px,py,w,h);x.fillStyle='rgba(255,255,255,.35)';x.fillRect(px,py,w,3);if(lit){y.fillStyle='#ffd98a';y.fillRect(px,py,w,h)}};
if(f=='b'){x.fillStyle='rgba(0,0,0,.14)';for(let r=0;r<8;r++){x.fillRect(0,r*8,64,1);for(let q=(r%2)*8;q<64;q+=16)x.fillRect(q,r*8,1,8)}}
if(f=='i'){x.fillStyle='rgba(0,0,0,.16)';for(let q=0;q<64;q+=4)x.fillRect(q,0,1,64);W(10,10,44,12,'#8aa0b4',1)}
else if(f=='s'){x.fillStyle='rgba(0,0,0,.25)';x.fillRect(0,0,64,8);W(4,14,56,42,'#bfe6ff',1)}
else if(f=='g'){const g=x.createLinearGradient(0,0,64,64);g.addColorStop(0,c);g.addColorStop(1,'#1d3550');x.fillStyle=g;x.fillRect(0,0,64,64);x.fillStyle='rgba(255,255,255,.3)';x.fillRect(0,0,64,2);x.fillRect(0,0,2,64);x.fillRect(31,0,2,64);y.fillStyle='#ffd98a';if(Math.random()<.7)y.fillRect(3,3,28,28);if(Math.random()<.6)y.fillRect(35,3,28,28)}
else{W(8,14,18,30,'#9fd0f0',Math.random()<.7);W(38,14,18,30,'#9fd0f0',Math.random()<.7)}
x.fillStyle='rgba(0,0,0,.18)';x.fillRect(0,60,64,4);return FC[k]={a:new THREE.CanvasTexture(a),b:new THREE.CanvasTexture(b)}}
function fmat(f,c,rx,ry){const k=f+c+rx+ry;if(MC[k])return MC[k];const Tx=fac(f,c),t=Tx.a.clone(),e=Tx.b.clone();[t,e].forEach(q=>{q.wrapS=q.wrapT=THREE.RepeatWrapping;q.repeat.set(rx,ry);q.needsUpdate=true});
const m=new THREE.MeshLambertMaterial({map:t,emissiveMap:e,emissive:0xffffff,emissiveIntensity:0});FM.push(m);return MC[k]=m}
function plane(){const g=new THREE.Group(),P=(geo,c,x,y,z)=>{const o=new THREE.Mesh(geo,MT(c));o.position.set(x,y,z);o.castShadow=true;g.add(o);return o};
P(Cy(.09,.07,.9,10),0xf4f4f4,0,.18,0).rotation.x=Math.PI/2;P(Bx(1,.025,.2),0xe8e8e8,0,.17,.05);P(Bx(.34,.02,.12),0xe8e8e8,0,.2,-.38);P(Bx(.025,.2,.14),0xd32f2f,0,.3,-.38);
[-.25,.25].forEach(x=>P(Cy(.045,.045,.16,8),0x999999,x,.12,.1).rotation.x=Math.PI/2);P(Sp(.09),0xf4f4f4,0,.18,.45);return g}
function trainM(){const g=new THREE.Group(),P=(w,h,l,x,y,z,c)=>{const o=new THREE.Mesh(Bx(w,h,l),MT(c));o.position.set(x,y,z);o.castShadow=true;g.add(o);return o};
P(.3,.2,.55,0,.17,.62,0x2a6fd6);P(.28,.07,.3,0,.31,.66,0x20303f);P(.08,.05,.02,0,.17,.9,0xffffe0);
[0,-.6].forEach(z=>{P(.3,.2,.56,0,.17,z,0xdde3ea);P(.31,.06,.48,0,.2,z,0x2a3b4a);P(.3,.02,.56,0,.28,z,0x2a6fd6)});return g}
const CARS=['car','hatch','suv','sport','pick','van'],CC=[0xe53935,0x1e88e5,0x43a047,0xfdd835,0xeeeeee,0x222222,0x8e24aa,0xff7043,0x90a4ae,0x00acc1];
function veh(k){const g=new THREE.Group(),lt=[],P=(w,h,l,x,y,z,c,b)=>{const o=new THREE.Mesh(Bx(w,h,l),b?MB(c):MT(c));o.position.set(x,y,z);o.castShadow=true;g.add(o);return o},
W=(x,z)=>{const o=new THREE.Mesh(Cy(.06,.06,.05,10),MT(0x111111));o.rotation.z=Math.PI/2;o.position.set(x,.06,z);g.add(o)},
cb=(c,l,wd,cL,cH,cZ,bH)=>{P(wd,bH||.08,l,0,.1,0,c);P(wd*.92,cH,cL,0,.14+cH/2,cZ,0x2a3b4a);P(wd*.94,.02,cL*.95,0,.15+cH,cZ,c);
[-1,1].forEach(s=>{P(.05,.035,.02,s*wd*.3,.11,l/2+.005,0xfff4c0,1);P(.05,.035,.02,s*wd*.3,.11,-l/2-.005,0xff2020,1);W(s*wd*.5,l*.3);W(s*wd*.5,-l*.3)})},
c=rnd(CC),Lt=(x,y,z,col)=>{lt.push(P(.06,.03,.03,x,y,z,col,1))},
hl=z=>[-1,1].forEach(s=>P(.05,.035,.02,s*.08,.11,z,0xfff4c0,1));
if(k=='car')cb(c,.46,.24,.24,.07,-.04);
else if(k=='hatch')cb(c,.38,.23,.26,.08,-.03);
else if(k=='suv')cb(c,.48,.27,.34,.1,-.02,.1);
else if(k=='sport')cb(rnd([0xe53935,0xfdd835,0x1e88e5,0xff7043]),.5,.26,.2,.05,-.06,.06);
else if(k=='pick'){cb(c,.52,.26,.18,.08,.1);P(.24,.05,.2,0,.15,-.17,0x333840)}
else if(k=='van')cb(c,.5,.26,.4,.12,-.04,.1);
else if(k=='taxi'){cb(0xf6c90e,.46,.24,.24,.07,-.04);P(.08,.04,.05,0,.26,-.03,0xffffff)}
else if(k=='truck'){P(.25,.15,.14,0,.14,.2,c);P(.2,.07,.02,0,.2,.275,0x2a3b4a);P(.27,.21,.38,0,.2,-.1,0xe8e8e8);hl(.275);[.2,-.08,-.22].forEach(z=>[-1,1].forEach(s=>W(s*.12,z)))}
else if(k=='gar'){P(.25,.15,.14,0,.14,.2,0x2e8b57);P(.2,.07,.02,0,.2,.275,0x2a3b4a);P(.27,.21,.38,0,.2,-.1,0x3aa06a);P(.1,.1,.06,0,.14,-.32,0x555555);hl(.275);[.2,-.1].forEach(z=>[-1,1].forEach(s=>W(s*.12,z)))}
else if(k=='bus'){P(.27,.17,.82,0,.14,0,0x2a6fd6);P(.275,.05,.7,0,.18,0,0x20303f);P(.27,.02,.82,0,.24,0,0xf0f0f0);P(.28,.12,.02,0,.14,.18,0xcfe0ff);[.3,-.3].forEach(z=>[-1,1].forEach(s=>W(s*.14,z)));
[-1,1].forEach(s=>{P(.05,.035,.02,s*.09,.1,.415,0xfff4c0,1);P(.05,.035,.02,s*.09,.1,-.415,0xff2020,1)})}
else if(k=='police'){cb(0xf4f4f4,.46,.24,.24,.07,-.04);P(.245,.035,.28,0,.12,0,0x1a3a9a);Lt(-.05,.25,-.04,0xff2222);Lt(.05,.25,-.04,0x2266ff)}
else if(k=='fire'){P(.26,.16,.62,0,.14,-.05,0xd32f2f);P(.24,.12,.16,0,.2,.28,0xd32f2f);P(.1,.04,.5,0,.26,-.06,0xdddddd);Lt(-.06,.3,.28,0xff2222);Lt(.06,.3,.28,0x2266ff);hl(.37);[.26,-.2,-.05].forEach(z=>[-1,1].forEach(s=>W(s*.14,z)))}
else if(k=='amb'){P(.26,.19,.46,0,.15,0,0xffffff);P(.265,.05,.46,0,.15,0,0xe53935);P(.2,.05,.02,0,.2,.235,0x2a3b4a);Lt(-.05,.27,.1,0xff2222);Lt(.05,.27,.1,0x2266ff);hl(.235);[.15,-.15].forEach(z=>[-1,1].forEach(s=>W(s*.14,z)))}
else if(k=='dump'){P(.25,.14,.14,0,.13,.2,0xf2b01e);P(.2,.07,.02,0,.2,.275,0x2a3b4a);P(.26,.12,.36,0,.19,-.08,0x6a6a70);Lt(0,.24,.2,0xff9800);hl(.275);[.2,-.1,-.22].forEach(z=>[-1,1].forEach(s=>W(s*.12,z)))}
else if(k=='exc'){P(.3,.06,.4,0,.04,0,0x333333);P(.22,.14,.24,0,.14,0,0xf2b01e);P(.05,.05,.32,0,.28,.22,0xf2b01e).rotation.x=.5;P(.08,.06,.08,0,.2,.38,0x777777);Lt(0,.24,-.05,0xff9800)}
else{P(.07,.14,.07,-.025,.07,0,0x2a2f3a);P(.07,.14,.07,.025,.07,0,0x2a2f3a);P(.13,.15,.08,0,.2,0,rnd([0xff7043,0x42a5f5,0x66bb6a,0xab47bc,0xeeeeee,0x333333]));const h=new THREE.Mesh(Sp(.05),MT(0xf5cba7));h.position.y=.31;g.add(h)}
g.userData.lt=lt.length?lt:null;return g}
function mk(id,lv){const d=D[id],m=d.mp,g=new THREE.Group(),h=d.h*(1+.3*(lv-1)),w=d.w*.92,z=d.d*.92,k=d.k,
A=(geo,mat,x,y,zz)=>{const o=new THREE.Mesh(geo,mat);o.position.set(x,y,zz);o.castShadow=o.receiveShadow=true;g.add(o);return o},
body=(bw,hh,bz,y,f,c,ox,oz)=>{const fl=Math.max(1,Math.round(hh/.5)),sx=fmat(f,c,Math.max(1,Math.round(bz*1.4)),fl),sz=fmat(f,c,Math.max(1,Math.round(bw*1.4)),fl),rm=MT(m.r||'#555a60');return A(Bx(bw,hh,bz),[sx,sx,rm,rm,sz,sz],ox||0,y+hh/2,oz||0)},
gab=(ww,zz,y,col,ph,ox,oz)=>{const lng=zz>=ww,span=lng?ww:zz,len=lng?zz:ww,r=(span+.2)/1.732,p=new THREE.Group(),o=new THREE.Mesh(Cy(r,r,len+.2,3),MT(col));o.rotation.x=-Math.PI/2;o.scale.set(1,1,ph);o.castShadow=true;p.add(o);p.position.set(ox,y+r*.5*ph,oz);if(!lng)p.rotation.y=Math.PI/2;g.add(p)},
LFm=c=>LF(c),leaf=(x,y,zz,r,c)=>A(Sp(r),LFm(c),x,y,zz);
if(k=='b'){const fl=Math.max(1,Math.round(h/.5)),hh=fl*.5,ct=m.ct;let bw=w,bd=ct?z*.45:z,y0=0;const oz=ct?-z*.27:0;
if(m.po){body(bw,.8,bd,0,'s','#cfd8e0');y0=.8;bw*=.8;bd*=.8}
body(bw,hh-y0,bd,y0,m.f||'w',m.c||'#ccc',0,oz);let top=hh;
if(m.cw){body(bw*.62,.5,bd*.62,top,m.f||'w',m.c||'#ccc',0,oz);top+=.5}
const fz=oz+bd/2;
if(m.t=='g')gab(bw,bd,top,m.r||'#8a4a3a',.75,0,oz);
else if(m.t=='d'){A(Cy(bw*.28,bw*.3,.25,16),MT(0xe8e0c8),0,top+.12,oz);A(G('SphereGeometry',bw*.3,14,8,0,6.3,0,1.57),MT(0x9fb0c0),0,top+.25,oz)}
else if(m.t=='s')for(let i=0;i<3;i++)gab(bw,bd/3,top,m.r||'#666',.55,0,oz+(i-1)*bd/3);
else A(Bx(bw+.06,.07,bd+.06),MT(m.r||'#555a60'),0,top+.03,oz);
if(m.d)A(Bx(.2,.3,.05),MT(0x5a3a22),m.ga&&d.c=='res'?-bw*.3:0,.15,fz+.01);
if(m.a)A(Bx(bw*.85,.04,.26),MT(m.a),0,.3,fz+.1).rotation.x=.3;
if(m.sg)A(Bx(bw*.7,.13,.05),MT(m.sg),0,Math.min(hh,1)-.07,fz+.02);
if(m.bl)for(let i=1;i<fl;i++)A(Bx(bw*.85,.035,.14),MT(0x888888),0,i*.5,fz+.07);
if(m.st)A(Bx(bw+.02,.08,bd+.02),MT(m.st),0,hh*.35,oz);
if(m.ga){const n=m.ga,gh=Math.min(.45,hh*.55),rs=d.c=='res',gw=rs?bw*.5:bw*.8;for(let i=0;i<n;i++)A(Bx(gw/n*.92,gh,.04),MT(0xc8c8d0),(rs?bw*.22:0)+(i-(n-1)/2)*gw/n,gh/2,fz+.01)}
if(m.co){for(let i=0;i<4;i++)A(Cy(.05,.05,hh*.85),MT(0xf4f0e6),(i-1.5)*bw*.22,hh*.43,fz+.1);A(Bx(bw*.8,.07,.2),MT(0xf4f0e6),0,hh*.87,fz+.1)}
if(m.cr){A(Bx(.34,.1,.04),MT(0xe53935),0,hh*.72,fz+.02);A(Bx(.1,.34,.04),MT(0xe53935),0,hh*.72,fz+.02)}
if(m.fg){A(Cy(.01,.01,.7),MT(0xcccccc),bw*.4,top+.35,0);A(Bx(.2,.12,.01),MT(0xe53935),bw*.4+.1,top+.6,0)}
if(m.sp){body(bw*.3,.5,bd*.3,top,'w','#e8e0d0',-bw*.3,oz+bd*.2);A(Co(.14,.6,6),MT(0x555555),-bw*.3,top+.8,oz+bd*.2)}
if(m.ct){A(Bx(bw*1.05,.05,z*.5),MT(m.ct),0,.62,z*.23);[-1,1].forEach(s=>A(Cy(.03,.03,.6),MT(0xdddddd),s*bw*.42,.3,z*.45));[-.2,.2].forEach(x=>A(Bx(.08,.22,.06),MT(0xcc3333),x*bw,.11,z*.23))}
if(m.ac){A(Bx(.22,.14,.18),MT(0xb0b4b8),-bw*.25,top+.1,oz);A(Bx(.2,.12,.16),MT(0xb0b4b8),bw*.2,top+.09,oz+bd*.15)}
if(m.tk)A(Cy(.12,.12,.26),MT(0x8a6a4a),-bw*.2,top+.18,oz+bd*.15);
if(m.ch){const ch=m.sm?.8:.3;A(m.sm?Cy(.07,.09,ch):Bx(.1,ch,.1),MT(m.sm?0x8a5a4a:0x7a4a3a),bw*.25,top+ch/2,oz-bd*.2);if(m.sm)g.userData.sm=new THREE.Vector3(bw*.25,top+ch,oz-bd*.2)}
if(m.an){A(Cy(.01,.02,.7),MT(0xcccccc),0,top+.35,oz);A(Sp(.03),MB(0xff2222),0,top+.72,oz)}}
else if(k=='tree'){A(Cy(.05,.07,.4),MT(0x7a5230),0,.2,0);if(m.v){A(Co(.28,.8),LFm(0x2c7a3c),0,.8,0);A(Co(.2,.6),LFm(0x2f8f45),0,1.2,0);A(Co(.13,.45),LFm(0x34a04c),0,1.55,0)}else{leaf(0,.65,0,.32,0x3a9a48);leaf(.15,.92,.05,.22,0x46b055);leaf(-.15,.85,-.08,.2,0x2f8a3e)}}
else if(k=='hedge')A(Bx(.9,.32,.3),LFm(0x2a7a35),0,.16,0);
else if(k=='flow'){A(Bx(w,.08,z),MT(0x58b04a),0,.04,0);for(let i=0;i<9;i++)A(Sp(.07),MT([0xe86aa0,0xffe066,0xffffff][i%3]),Math.sin(i*2.4)*.32,.14,Math.cos(i*2.4)*.32)}
else if(k=='pond'){A(Cy(w*.5,w*.5,.05,24),MT(0xd8cfa8),0,.025,0);A(Cy(w*.42,w*.42,.07,24),MT(0x3d9be0),0,.04,0);for(let i=0;i<5;i++)A(Cy(.02,.02,.3,5),MT(0x4a7a3a),Math.sin(i*1.3)*w*.38,.15,Math.cos(i*1.3)*w*.38)}
else if(k=='park'){A(Bx(w,.08,z),MT(0x58b04a),0,.04,0);A(Bx(w*.18,.09,z),MT(0xd8cfa8),0,.05,0);A(Bx(w,.09,z*.18),MT(0xd8cfa8),0,.05,0);
for(let i=0;i<d.w*d.w+2;i++){const r=.55+(i%3)*.12,a=i*2.4,x=Math.sin(a)*w*.5*r*.95,y=Math.cos(a)*z*.5*r*.95;A(Cy(.05,.07,.3),MT(0x7a5230),x,.15,y);leaf(x,.5,y,.28+(i%2)*.06,i%2?0x2f9a45:0x3aa84f)}
if(d.w>3)A(Cy(w*.16,w*.16,.07,20),MT(0x3d9be0),0,.06,0);else A(Bx(.3,.1,.1),MT(0x8a5a3a),0,.1,w*.2)}
else if(k=='gaz'){A(Cy(.35,.35,.05,8),MT(0xd8c8a0),0,.025,0);[0,1,2,3].forEach(i=>A(Cy(.02,.02,.45),MT(0xf0e8d8),Math.cos(i*1.57+.78)*.27,.27,Math.sin(i*1.57+.78)*.27));A(Co(.45,.3,8),MT(0xb5483a),0,.62,0)}
else if(k=='play'){A(Bx(w,.07,z),MT(0x58b04a),0,.035,0);A(Bx(w*.9,.04,z*.5),MT(0xd9694a),0,.08,-z*.2);[-.45,.45].forEach(x=>A(Cy(.025,.025,.6),MT(0xdd4444),x*w*.5,.3,z*.25));A(Bx(w*.5,.03,.03),MT(0xdd4444),0,.6,z*.25);A(Bx(.35,.04,.5),MT(0x2e8bff),w*.3,.2,-z*.2).rotation.x=.5}
else if(k=='sport'){A(Bx(w,.05,z),MT(0x2e7d3a),0,.025,0);A(Bx(w*.85,.06,z*.85),MT(0x3a6fb0),0,.04,0);A(Bx(w*.85,.07,.03),MT(0xffffff),0,.05,0);[-1,1].forEach(s=>{A(Cy(.02,.02,.5),MT(0x888888),0,.25,s*z*.42);A(Bx(.18,.12,.02),MT(0xffffff),0,.5,s*z*.4)})}
else if(k=='rink'){A(Bx(w,.05,z),MT(0xcfe8f5),0,.025,0);[[0,-z/2,w,.06],[0,z/2,w,.06],[-w/2,0,.06,z],[w/2,0,.06,z]].forEach(([x,y,a,b])=>A(Bx(a,.14,b),MT(0xeeeeee),x,.07,y))}
else if(k=='fount'){A(Cy(.42,.46,.14,18),MT(0xbbbbbb),0,.07,0);A(Cy(.36,.36,.16,18),MT(0x4aa8e8),0,.1,0);A(Cy(.1,.14,.4,10),MT(0xcccccc),0,.3,0);A(Cy(.24,.24,.06,14),MT(0xbbbbbb),0,.46,0);A(Cy(.2,.2,.07,14),MT(0x4aa8e8),0,.48,0);A(Cy(.03,.03,.3),MT(0xddeeff),0,.65,0)}
else if(k=='stat'){A(Bx(.5,.4,.5),MT(0xaaaaaa),0,.2,0);A(Cy(.1,.16,.7),MT(0xd4af37),0,.75,0);A(Sp(.12),MT(0xd4af37),0,1.2,0)}
else if(k=='mon'){A(Bx(w*.8,.2,z*.8),MT(0xaaaaaa),0,.1,0);A(Cy(.12,.28,2.6,4),MT(0xd8d4c8),0,1.5,0);A(Co(.12,.4,4),MT(0xd4af37),0,3,0)}
else if(k=='busst'){A(Bx(w,.04,z),MT(0x9a9a9a),0,.02,0);[-.34,.34].forEach(x=>A(Cy(.025,.025,.5),MT(0x444444),x,.27,-.1));A(Bx(.84,.05,.4),MT(0x2a6fd6),0,.55,-.1);A(Bx(.8,.35,.02),MT(0xa8d8f0),0,.3,-.28);A(Bx(.5,.04,.14),MT(0x8a5a3a),0,.18,-.2);A(Cy(.02,.02,.9),MT(0x666666),.4,.45,.3);A(Bx(.18,.18,.03),MT(0x2a6fd6),.4,.9,.3)}
else if(k=='lot'){A(Bx(w,.05,z),MT(0x3c3f44),0,.025,0);for(let i=0;i<5;i++)A(Bx(.03,.06,.5),MT(0xffffff),-w*.42+i*w*.21,.03,0);[[-.37,0xe53935],[.05,0x1e88e5]].forEach(([x,c])=>{A(Bx(.2,.1,.4),MT(c),x,.1,-.2);A(Bx(.16,.07,.2),MT(0x2b3a4a),x,.18,-.2)})}
else if(k=='depot'){A(Bx(w,.04,z),MT(0x6a6e74),0,.02,0);body(w*.95,.8,z*.5,0,'i','#c8ccd2',0,-z*.25);A(Bx(w,.06,z*.55),MT(0x2a6fd6),0,.84,-z*.25);for(let i=0;i<3;i++)A(Bx(w*.24,.5,.03),MT(0x2a6fd6),(i-1)*w*.3,.25,.01);[-.5,.5].forEach(x=>{const b=veh('bus');b.position.set(x*w*.6,0,.34);g.add(b)})}
else if(k=='cdep'){A(Bx(w,.04,z),MT(0x8a7a5a),0,.02,0);body(w*.4,.5,z*.4,0,'i','#d8b840',-w*.28,-z*.28);A(Cy(.03,.03,1.4),MT(0xd8b840),w*.3,.7,-z*.25);A(Bx(.04,.04,.9),MT(0xd8b840),w*.3,1.4,-z*.25+.4);[-.3,.1].forEach(x=>{const b=veh('dump');b.position.set(x*w,0,.35);g.add(b)});for(let i=0;i<4;i++)A(Co(.05,.14,6),MT(0xff7043),-w*.35+i*.2,.07,z*.42)}
else if(k=='stn'){A(Bx(w,.04,z),MT(0x7a7a7a),0,.02,0);body(w,.7,z*.4,0,'w','#c9d0d8',0,-z*.3);A(Cy(z*.22,z*.22,w,14),MT(0x8a9aa8),0,.8,-z*.3).rotation.z=Math.PI/2;A(Bx(w,.04,.04),MT(0x444444),0,.06,z*.08);A(Bx(w,.04,.04),MT(0x444444),0,.06,z*.24);A(Bx(w*.55,.16,.2),MT(0x2a6fd6),0,.15,z*.16);A(Bx(w*.55,.05,.2),MT(0xeeeeee),0,.25,z*.16)}
else if(k=='heli'){A(Cy(w*.46,w*.46,.05,24),MT(0x555a60),0,.025,0);A(Bx(.1,.06,.7),MT(0xffffff),-.2,.06,.3);A(Bx(.1,.06,.7),MT(0xffffff),.2,.06,.3);A(Bx(.4,.06,.1),MT(0xffffff),0,.06,.3);A(Sp(.22),MT(0xd32f2f),0,.34,-.3);A(Bx(.06,.06,.45),MT(0xd32f2f),0,.36,-.6);g.userData.rt=A(Bx(.95,.015,.05),MT(0x222222),0,.6,-.3)}
else if(k=='air'){A(Bx(w,.04,z),MT(0x4a4d52),0,.02,0);A(Bx(w*.9,.05,.08),MT(0xffffff),0,.05,-z*.15);body(w*.45,.4,z*.22,0,'g','#9ac8e8',-w*.22,z*.38);A(Cy(.08,.1,.8),MT(0xaaaaaa),w*.3,.4,z*.38);A(Bx(.3,.18,.3),MT(0x66bbee),w*.3,.9,z*.38);
const p=plane();p.position.set(-w*.2,0,z*.18);p.rotation.y=Math.PI/2;g.add(p)}
else if(k=='stad'){const r=Math.min(w,z)/2;A(Cy(r,r*.85,h,24),MT(0xb8bcc2),0,h/2,0);A(Cy(r*.78,r*.78,h+.03,24),MT(0x4aa84a),0,h/2,0);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([a,b])=>{A(Cy(.03,.03,h+.8),MT(0xaaaaaa),a*r*.95,(h+.8)/2,b*r*.95);A(Bx(.2,.1,.1),MB(0xffffcc),a*r*.95,h+.8,b*r*.95)})}
else if(k=='wind'){A(Cy(.03,.07,1.9),MT(0xf0f0f0),0,.95,0);A(Bx(.1,.1,.22),MT(0xe0e0e0),0,1.9,.05);const bl=new THREE.Group();bl.position.set(0,1.9,.19);g.add(bl);for(let i=0;i<3;i++){const p=new THREE.Group(),b=new THREE.Mesh(Bx(.07,.8,.015),MT(0xffffff));b.position.y=.4;b.castShadow=true;p.rotation.z=i*2.094;p.add(b);bl.add(p)}g.userData.bl=bl}
else if(k=='solar'){for(let i=0;i<3;i++)for(let j=0;j<2;j++){A(Bx(w*.28,.03,z*.4),MT(0x1f3f7a),(i-1)*w*.32,.28,(j-.5)*z*.45).rotation.x=-.45;A(Cy(.02,.02,.28),MT(0x999999),(i-1)*w*.32,.14,(j-.5)*z*.45)}}
else if(k=='nuke'){A(Bx(w,.5,z*.5),MT(0x9aa0a8),0,.25,-z*.25);[[-.8,.6],[.8,.8]].forEach(([a,b])=>A(Cy(.42,.62,1.6,18),MT(0xcfd2d6),a,.8,b));A(Sp(.55),MT(0xaab0b8),.5,.6,-.7)}
else if(k=='treat'){A(Bx(w,.3,z),MT(0x8a9098),0,.15,0);[[-.4,-.4],[.4,.4],[-.4,.4],[.4,-.4]].forEach(([a,b])=>A(Cy(.32,.32,.12,14),MT(0x4aa8e8),a,.33,b))}
else if(k=='tank'){[[-.2,-.2],[.2,.2],[-.2,.2],[.2,-.2]].forEach(([a,b])=>A(Cy(.04,.04,.9),MT(0x888888),a,.45,b));A(Sp(.4),MT(0x5aa0d8),0,1.05,0)}
else if(k=='power'){body(w,.5,z*.5,0,'i','#8a8f98',0,-z*.2);[[-.45,.35],[.35,.4]].forEach(([a,b])=>A(Cy(.28,.4,1.2,16),MT(0xd8d8d8),a*w,.6,b*z));A(Cy(.07,.09,1.5),MT(0x7a4a3a),.4*w,.75,-.3*z);g.userData.sm=new THREE.Vector3(.4*w,1.5,-.3*z);A(Cy(.07,.09,1.2),MT(0x7a4a3a),.2*w,.6,-.3*z)}
else if(k=='ref'){A(Bx(w,.05,z),MT(0x6a6e74),0,.025,0);[[-.8,-.8],[0,-.8],[.8,-.8],[-.8,.2]].forEach(([a,b],i)=>{A(Cy(.32,.32,.6,16),MT(i%2?0xe8e8e8:0xcfd4da),a,.35,b);A(Sp(.3),MT(0xdadada),a,.65,b)});A(Cy(.03,.04,1.8),MT(0x888888),.9,.9,.9);A(Sp(.07),MB(0xff8a30),.9,1.85,.9);A(Cy(.07,.09,1),MT(0x8a5a4a),.8,.5,-.2);g.userData.sm=new THREE.Vector3(.8,1,-.2);A(Bx(2,.05,.05),MT(0x999999),0,.3,.7)}
else if(k=='mine'){A(Bx(w,.05,z),MT(0x6a5a4a),0,.025,0);body(w*.45,.5,z*.4,0,'i','#8a7a6a',-w*.22,-z*.25);[-1,1].forEach(s=>A(Bx(.05,1,.05),MT(0x5a4a3a),w*.2+s*.12,.5,z*.2).rotation.z=-s*.2);A(Cy(.1,.1,.04,10),MT(0xb08040),w*.2,1,z*.2).rotation.x=Math.PI/2;A(Co(.3,.35,7),MT(0x777777),w*.25,.18,-z*.25);A(Bx(.2,.1,.14),MT(0x8a5a3a),-w*.1,.1,z*.3)}
else if(k=='pump'){A(Bx(w,.04,z),MT(0x2a2a2e),0,.02,0);A(Bx(.1,.4,.1),MT(0x777777),0,.2,0);g.userData.bm=A(Bx(.8,.06,.06),MT(0xd9a010),0,.5,0);A(Cy(.2,.2,.05,10),MT(0xb08000),-.3,.2,.1).rotation.x=Math.PI/2;A(Cy(.03,.03,.5),MT(0x555555),.35,.25,0)}
else if(k=='farm'){A(Bx(w,.05,z),MT(0x9a7a3a),0,.025,0);for(let i=0;i<4;i++)A(Bx(w*.5,.07,.15),MT(i%2?0x7ab040:0xc8b040),-w*.2,.06,-z*.35+i*.22);body(.7,.45,.5,0,'b','#b04a3a',w*.25,z*.2);A(Cy(.14,.14,.7),MT(0xc8ccd0),w*.1,.35,-z*.3);A(Sp(.14),MT(0xaab0b8),w*.1,.7,-z*.3)}
return g}
function canPlace(id,x,z,r){const d=D[id],[w,dd]=dims(d,r);if(x<0||z<0||x+w>N||z+dd>N)return 0;let oil=0,ore=0;
for(let i=0;i<w;i++)for(let j=0;j<dd;j++){const k=(z+j)*N+x+i;if(grid[k]||T[k]==1||T[k]==2)return 0;if(T[k]==4)oil=1;if(T[k]==5)ore=1}
if(d.k=='pump'&&!oil||d.k=='mine'&&!ore)return 0;return 1}
function setPos(b){b.mesh.position.set(b.x-N/2+b.w/2,0,b.z-N/2+b.d/2);b.mesh.rotation.y=b.rot*Math.PI/2}
function addB(id,x,z,rot,lv,fx){const[w,d]=dims(D[id],rot),b={id,x,z,rot,lv,w,d,t:1};
for(let i=0;i<w;i++)for(let j=0;j<d;j++)grid[(z+j)*N+x+i]=b;
b.mesh=mk(id,lv);setPos(b);sc.add(b.mesh);if(fx){b.t=0;b.mesh.scale.setScalar(.05);puff(b.mesh.position.x,b.mesh.position.z)}blds.push(b);return b}
function delB(b){for(let i=0;i<b.w;i++)for(let j=0;j<b.d;j++)grid[(b.z+j)*N+b.x+i]=null;puff(b.mesh.position.x,b.mesh.position.z);sc.remove(b.mesh);blds.splice(blds.indexOf(b),1);S.m+=D[b.id].cost/2}
const access=(b,f=isR)=>{for(let i=0;i<b.w;i++)for(const z of[b.z-1,b.z+b.d])if(f(b.x+i,z))return[b.x+i,z];for(let j=0;j<b.d;j++)for(const x of[b.x-1,b.x+b.w])if(f(x,b.z+j))return[x,b.z+j];return 0},
upc=b=>Math.floor(D[b.id].cost*.7*b.lv);
function puff(x,z){const mt=puff.m||(puff.m=new THREE.MeshBasicMaterial({color:0xf0e2b0}));
for(let i=0;i<10;i++){const m=new THREE.Mesh(Bx(.1,.1,.1),mt);m.position.set(x,.2,z);sc.add(m);pt.push({m,vx:Math.random()*2-1,vy:Math.random()*2+1,vz:Math.random()*2-1,l:.7})}}
function smoke(b){const sm=b.mesh.userData.sm;if(!sm||pt.length>160)return;const m=new THREE.Mesh(Sp(.1),puff.s||(puff.s=new THREE.MeshBasicMaterial({color:0x9a9a9a,transparent:true,opacity:.6})));b.mesh.localToWorld(m.position.copy(sm));sc.add(m);pt.push({m,vx:.08,vy:.45,vz:.05,l:2.2,L:2.2,sm:1})}
const mkNb=f=>(x,z,ex,ez)=>[[1,0],[-1,0],[0,1],[0,-1]].map(([a,b])=>[x+a,z+b]).filter(([X,Z])=>f(X,Z)&&!(X==ex&&Z==ez)),nb=mkNb(isR),nbW=mkNb(isW),nbT=mkNb(isT);
function bfs(sx,sz,tx,tz,nf=nb){if(sx==tx&&sz==tz)return[];const prev=new Int16Array(N*N).fill(-1),s=sz*N+sx;prev[s]=s;const q=[s];
for(let i=0;i<q.length;i++){const c=q[i],x=c%N,z=c/N|0;if(x==tx&&z==tz)break;for(const[a,b]of nf(x,z,-1,-1)){const n=b*N+a;if(prev[n]<0){prev[n]=c;q.push(n)}}}
const t=tz*N+tx;if(prev[t]<0)return null;const p=[];for(let c=t;c!=s;c=prev[c])p.push([c%N,c/N|0]);return p.reverse()}
const KIND={car:'r',taxi:'r',truck:'r',gar:'r',hc:'h',bus:'b',police:'e',fire:'e',amb:'e',dump:'c',exc:'c',ped:'p',train:'t'},
SPD={car:2,taxi:2.1,truck:1.4,gar:1,hc:2,bus:1.4,police:2.2,fire:2.1,amb:2.3,dump:1.2,exc:.9,ped:.55,train:1.1},SV={police:'police',fire:'fire',amb:'hosp'};
function base(k,model,g){const o={k,g:g||KIND[k],st:'go',path:[],t:0,px:-1,pz:-1,w:0,back:0,leg:0,fast:0,sp:SPD[k]*(.85+Math.random()*.3),off:k=='ped'?(Math.random()<.5?.44:-.44):.17,ax:0,az:0,bx:0,bz:0,nf:k=='ped'?nbW:nb};
o.m=k=='train'?trainM():veh(model||(k=='car'?rnd(CARS):k));return o}
function add(o){sc.add(o.m);mv.push(o);return o}
function pose(o){const dx=o.bx-o.ax,dz=o.bz-o.az,off=o.off*(isR(o.ax,o.az)?1:.25);o.m.position.set(o.ax+.5-N/2+dx*o.t-dz*off,.06,o.az+.5-N/2+dz*o.t+dx*off);if(dx||dz)o.m.rotation.y=Math.atan2(dx,dz)}
function place(o){if(!RL.length)return;const c=rnd(RL),n=nb(c[0],c[1],-1,-1),b=n.length?rnd(n):c;o.ax=c[0];o.az=c[1];o.bx=b[0];o.bz=b[1];o.t=0;o.px=o.pz=-1}
function stay(o,w,vis){o.st='wait';o.w=w;o.bx=o.ax;o.bz=o.az;o.t=0;pose(o);o.m.visible=vis}
const kill=o=>{o.dead=1},
END={
p:o=>{o.leg^=1;const t=o.leg?o.home:rnd(DST);if(!t){kill(o);return 1}o.path=bfs(o.ax,o.az,t[0],t[1],nbW)||[];stay(o,1+Math.random()*3,false);return 1},
b:o=>{const s=STP.filter(x=>x.ac),t=s.length?rnd(s).ac:null;o.path=t?bfs(o.ax,o.az,t[0],t[1])||[]:[];stay(o,2.5,true);return 1},
e:o=>{if(!blds.includes(o.src)||!o.src.ac){kill(o);return 1}
if(!o.back){o.back=1;const h=o.src.ac;o.path=bfs(o.ax,o.az,h[0],h[1])||[];stay(o,o.g=='h'?3:4,o.g!='h');return 1}
o.back=0;o.fast=0;o.st='idle';o.w=o.g=='h'?20+Math.random()*40:15+Math.random()*25;o.m.visible=false;o.path=[];return 1},
c:o=>{if(!o.back){o.back=1;const r=rnd(RL);o.path=bfs(o.ax,o.az,r[0],r[1])||[];stay(o,6,true);return 1}kill(o);return 1}};
END.h=END.e;
function arrive(o,aw){if(!o.path.length&&!aw&&END[o.g]&&END[o.g](o))return;let n=o.path.shift();
if(!n){const c=o.nf(o.ax,o.az,o.px,o.pz),c2=c.length?c:o.nf(o.ax,o.az,-1,-1);n=c2.length?rnd(c2):[o.ax,o.az]}o.bx=n[0];o.bz=n[1]}
function mission(o){if(!blds.includes(o.src)||!o.src.ac){kill(o);return}const t=rnd(blds.filter(b=>b.ac&&b!=o.src&&(o.g=='e'||D[b.id].jobs)));if(!t){o.w=5;return}
const s=o.src.ac,p=bfs(s[0],s[1],t.ac[0],t.ac[1]);if(!p){o.w=8;return}o.ax=s[0];o.az=s[1];o.bx=o.ax;o.bz=o.az;o.path=p;o.back=0;o.fast=o.g=='e'?1:0;o.st='go';o.m.visible=true;o.t=0;o.px=o.pz=-1;arrive(o,1)}
function lost(o){if(o.g=='r'||o.g=='b'){place(o);o.path=[]}else if(o.g=='e'||o.g=='h'){o.st='idle';o.w=5;o.m.visible=false;o.path=[];o.back=0;o.fast=0}else kill(o)}
const stationNear=(x,z)=>[[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>{const X=x+a,Z=z+b;if(X<0||Z<0||X>=N||Z>=N)return 0;const q=grid[Z*N+X];return q&&q.id=='stn'});
function stepT(o,dt){if(!RT.length)return;
if(!isT(o.ax,o.az)||!isT(o.bx,o.bz)){const c=rnd(RT),n=nbT(c[0],c[1],-1,-1),b=n.length?rnd(n):c;o.ax=c[0];o.az=c[1];o.bx=b[0];o.bz=b[1];o.t=0;o.px=o.pz=-1;o.m.visible=true}
if(o.w>0){o.w-=dt;return}
o.t+=dt*o.sp;if(o.t>=1){o.t-=1;o.px=o.ax;o.pz=o.az;o.ax=o.bx;o.az=o.bz;let n=nbT(o.ax,o.az,o.px,o.pz);if(!n.length)n=nbT(o.ax,o.az,-1,-1);const c=n.length?rnd(n):[o.ax,o.az];o.bx=c[0];o.bz=c[1];if(stationNear(o.ax,o.az))o.w=4}
const dx=o.bx-o.ax,dz=o.bz-o.az;o.m.position.set(o.ax+.5-N/2+dx*o.t,.07,o.az+.5-N/2+dz*o.t);
if(dx||dz){let d=Math.atan2(dx,dz)-o.m.rotation.y;while(d>Math.PI)d-=2*Math.PI;while(d<-Math.PI)d+=2*Math.PI;o.m.rotation.y+=d*Math.min(1,dt*8)}}
function step(o,dt){if(o.g=='t'){stepT(o,dt);return}if(!RL.length&&o.g!='p')return;
if(o.st!='go'){o.w-=dt;if(o.w>0)return;if(o.st=='idle'){mission(o);return}o.st='go';o.m.visible=true;arrive(o,1);return}
const ok=o.g=='p'?isW:isR;if(!ok(o.ax,o.az)||!ok(o.bx,o.bz)){lost(o);return}
o.t+=dt*o.sp*(o.fast?1.35:1);if(o.t>=1){o.t-=1;o.px=o.ax;o.pz=o.az;o.ax=o.bx;o.az=o.bz;arrive(o,0)}pose(o)}
function stepPl(o,dt){o.u+=dt/o.dur;if(o.u>=1||!blds.includes(o.b)){o.dead=1;return}const u=o.u,s=o.s;let lx,ly;
if(o.arr){lx=s*(-40+41.5*u);ly=u<.925?.08+Math.pow(1-u/.925,1.2)*6:.08}else{lx=s*(-1.6+41.6*Math.pow(u,1.7));ly=u<.3?.08:.08+Math.pow((u-.3)/.7,1.3)*7}
o.b.mesh.localToWorld(o.m.position.set(lx,ly,-D.air.d*.92*.15));o.m.rotation.y=o.b.mesh.rotation.y+s*Math.PI/2}
function spawn(k){const g=KIND[k];if(!RL.length&&g!='p'&&g!='t')return 0;const o=base(k,k=='hc'?rnd(CARS):0);
if(g=='r')place(o);
else if(g=='h'){const s=rnd(HG);if(!s)return 0;o.src=s;o.ax=o.bx=s.ac[0];o.az=o.bz=s.ac[1];o.st='idle';o.w=2+Math.random()*12;o.m.visible=false}
else if(g=='b'){const s=rnd(DEP);if(!s||!s.ac)return 0;o.src=s;o.ax=o.bx=s.ac[0];o.az=o.bz=s.ac[1];END.b(o)}
else if(g=='e'){const l=blds.filter(b=>b.id==SV[k]&&b.ac);if(!l.length)return 0;o.src=l[mv.filter(x=>x.k==k).length%l.length];o.ax=o.bx=o.src.ac[0];o.az=o.bz=o.src.ac[1];o.st='idle';o.w=3+Math.random()*10;o.m.visible=false}
else if(g=='p'){const hb=rnd(HM),t=rnd(DST);if(!hb||!t)return 0;const c=hb.aw,p=bfs(c[0],c[1],t[0],t[1],nbW);if(!p)return 0;o.home=c;o.ax=o.bx=c[0];o.az=o.bz=c[1];o.path=p;arrive(o,1);pose(o)}
else if(g=='t'){if(!RT.length)return 0;o.ax=o.bx=-1;o.az=o.bz=-1;o.m.visible=false}
add(o);return 1}
function crew(b){const c=access(b);if(!c||!RL.length||mv.filter(o=>o.g=='c'&&!o.dead).length>=4)return;const bs=blds.find(x=>x.id=='cdep'&&access(x)),s=bs?access(bs):rnd(RL),p=bfs(s[0],s[1],c[0],c[1]);if(!p)return;
const o=base(rnd(['dump','exc']));o.ax=o.bx=s[0];o.az=o.bz=s[1];o.path=p;add(o);arrive(o,1);pose(o)}
function scan(){HM=[];DST=[];STP=[];DEP=[];HG=[];blds.forEach(b=>{const d=D[b.id];b.ac=access(b,isR);b.aw=access(b,isW);b.rc=d.rail?access(b,isT):0;
if(b.aw){if(d.c=='res')HM.push(b);else if(d.jobs||d.c=='dec'||d.c=='trans')DST.push(b.aw)}
if(b.ac){if(d.c=='res'&&d.mp.ga)HG.push(b);if(b.id=='bus')STP.push(b);if(b.id=='depot')DEP.push(b)}})}
function syncAll(){const ind=blds.filter(b=>'ind com'.includes(D[b.id].c)).length,rn=Math.min(24,RL.length>>2),dn=SET.den,
Tg={car:rn*dn,taxi:rn/6*dn,truck:Math.min(8,ind>>1)*dn,gar:Math.min(3,cnt('waste')),hc:Math.min(14,HG.length)*dn,bus:DEP.length&&STP.length?Math.min(6,DEP.length*2):0,police:Math.min(4,cnt('police')),fire:Math.min(4,cnt('fire')),amb:Math.min(4,cnt('hosp')),ped:HM.length&&DST.length?Math.min(70,S.pop/5)*dn:0,train:cnt('stn')&&RT.length>5?Math.min(2,RT.length>>3):0};
for(const k in Tg){const n=Math.round(Tg[k]);let a=mv.filter(o=>o.k==k&&!o.dead).length,i=0;
while(a<n&&i++<4){if(!spawn(k))break;a++}
while(a>n){const o=mv.find(x=>x.k==k&&!x.dead);if(!o)break;kill(o);a--}}}
function tick(){scan();let pw=0,wt=0,use=0,hp=0,pl=0,up=RL.length*.3+RT.length*.5,cap=0,tb=0,jobs=0,com=0,inc=0;
blds.forEach(b=>{const d=D[b.id],m=1+.5*(b.lv-1);if('res com ind pub'.includes(d.c))use+=b.w*b.d;pw+=(d.pw||0)*m;wt+=(d.wt||0)*m;up+=d.up*(1+.3*(b.lv-1));hp+=(d.hp||0)*m;pl+=d.pl||0;if(d.c=='com')com++;
if(b.ac){jobs+=(d.jobs||0)*m;if(d.pop){cap+=d.pop*m;tb+=d.pop*m*d.tx}}});
const eP=use?Math.min(1,pw/(use*1.5)):1,eW=use?Math.min(1,wt/use):1;
blds.forEach(b=>{const d=D[b.id];if(b.ac&&d.inc&&(!d.rail||b.rc))inc+=d.inc*(1+.5*(b.lv-1))*eP*eW});
cap=Math.floor(cap);const old=S.pop;
if(S.pop<cap&&S.hap>=30)S.pop=Math.min(cap,S.pop+Math.ceil(cap*.15*S.hap/100));else if(S.pop>cap)S.pop=Math.max(cap,S.pop-Math.ceil((S.pop-cap)*.3));
S.xp+=Math.max(0,S.pop-old)*.2;
const emp=S.pop?Math.min(1,jobs/S.pop):1,cov=Math.min(1,8*Math.sqrt(hp/(S.pop+1))),h=25+25*cov+15*eP+10*eW+15*emp+(com?10:0)-Math.min(25,Math.max(0,pl)*3);
if(S.pop)S.hap=cl(S.hap+(h-S.hap)*.5,0,100);
const tax=cap?tb*(S.pop/cap)*(.4+.6*emp)*Math.min(1,.4+S.hap/100):0;
S.net=inc+tax-up;S.m=Math.max(0,S.m+S.net);if(!S.m)toast('Бюджет пуст!');
Object.assign(S,{eP,eW,emp,pl});
S.adv=!RL.length?'Постройте дороги, а дома рядом с ними':blds.some(b=>D[b.id].c=='res'&&!b.ac)?'Есть дома без дороги рядом':eP<1?'Не хватает электричества — нужна электростанция':eW<1?'Не хватает воды — нужна водонапорная башня':S.pop&&emp<.8?'Мало рабочих мест — стройте магазины и заводы':S.pop&&cov<.6?'Нужны парки, школы и больницы':pl>3?'Загрязнение — сажайте деревья и парки':'Город процветает!';
const q=Q[S.q];if(q&&q[1]()){S.m+=q[2];S.xp+=xpb(q[2]);big('Задание выполнено!');toast('Награда: +'+Fm(q[2]));S.q++}
if(cnt('air')&&PLN.length<2){const b=blds.find(x=>x.id=='air'),o={m:plane(),b,u:0,s:Math.random()<.5?1:-1,arr:Math.random()<.5,dur:13};sc.add(o.m);PLN.push(o)}
checkLv();syncAll();
const e=$('fl');e.textContent=(S.net>=0?'+':'')+Fm(S.net);e.classList.remove('go');void e.offsetWidth;e.classList.add('go');ui();dirty=1}
function checkLv(){while(S.xp>=need(S.lv)){S.xp-=need(S.lv);S.lv++;S.m+=100*S.lv**3;big('Уровень '+S.lv+'!');const u=Object.values(D).filter(d=>d.lv==S.lv).map(d=>d.n).join(', ');toast('Открыто: '+(u||'новые награды'))}}
function ui(){const hp=S.pop?Math.round(S.hap):0;
$('m').innerHTML=ic('money','#ffd54f')+Fm(S.m);$('inc').innerHTML=ic('chart','#7cfc9a')+(S.net>=0?'+':'')+Fm(S.net);$('pop').innerHTML=ic('people','#8ec5ff')+Fm(S.pop);
$('hap').innerHTML=ic(hp>60?'f1':hp>35?'f2':'f3',hp>60?'#7cfc9a':hp>35?'#ffd54f':'#ff6b6b')+hp+'%';$('lv').innerHTML=ic('star','#ffb300')+S.lv;
$('xpb').style.width=Math.min(100,S.xp/need(S.lv)*100)+'%';$('q').innerHTML=ic('target','#ff8a65')+(Q[S.q]?Q[S.q][0]:'Все задания выполнены');clk()}
function clk(){const h=S.tm*24,hh=h|0,mm=(h-hh)*60|0,day=h>6&&h<19;$('clk').innerHTML=ic(day?'sun':'moon',day?'#ffd54f':'#aab8ff')+String(hh).padStart(2,'0')+':'+String(mm).padStart(2,'0')}
function toast(t){if(!t)return;const e=$('msg');e.textContent=t;e.style.opacity=1;clearTimeout(toast.h);toast.h=setTimeout(()=>e.style.opacity=0,2600)}
function big(t){const e=$('big');e.textContent=t;e.classList.remove('go');void e.offsetWidth;e.classList.add('go')}
function pay(c){if(S.sb)return 1;if(S.m<c){toast('Не хватает денег!');return 0}S.m-=c;return 1}
function fpv(){fp.visible=tool=='build'||!!sel||!!curOn}
function lay(){const nbr=document.body.classList.contains('nobar'),l=!nbr&&$('list').style.display=='block';document.body.classList.toggle('lo',l);document.documentElement.style.setProperty('--bo',(nbr?0:$('bar').offsetHeight)+8+'px')}
function lst(on){$('list').style.display=on?'block':'none';lay()}
function updGhost(){const d=D[cur],[w,dd]=dims(d,grot),ok=canPlace(cur,gx,gz,grot);fp.scale.set(w,dd,1);fp.position.set(gx-N/2+w/2,.05,gz-N/2+dd/2);fp.material.color.set(ok?0x30ff70:0xff3040);ghost.position.set(gx-N/2+w/2,0,gz-N/2+dd/2);ghost.rotation.y=grot*Math.PI/2}
function showCur(){if(tool=='build')updGhost();else if(curOn){fp.visible=true;fp.material.color.set(0xffffff);fp.scale.set(1,1,1);fp.position.set(gx-N/2+.5,.05,gz-N/2+.5)}}
function setGhost(){if(ghost){ghost.traverse(o=>{if(o.isMesh)[].concat(o.material).forEach(m=>m.dispose())});sc.remove(ghost);ghost=null}const on=tool=='build';$('cf').style.display=on?'flex':'none';if(!on){fpv();return}
const gm=x=>{x=x.clone();x.transparent=true;x.opacity=.65;return x};
ghost=mk(cur,1);ghost.traverse(o=>{if(o.isMesh){o.material=Array.isArray(o.material)?o.material.map(gm):gm(o.material);o.castShadow=false}});sc.add(ghost);fpv();
$('ct').innerHTML=D[cur].n+' · '+ic('money','#ffd54f')+Fm(D[cur].cost);updGhost()}
function mark(){const key=NETT.includes(tool)?'net':tool=='del'?'del':openC;document.querySelectorAll('#bar button').forEach(b=>b.classList.toggle('on',b.dataset.c==key))}
function clearTool(){tool=null;cur=null;openC=null;curOn=0;lst(0);setGhost();mark()}
function showInfo(h){$('info').innerHTML=h;$('info').style.display='block'}
function hideInfo(){$('info').style.display='none';sel=null;fpv()}
function infoB(){const b=sel,d=D[b.id],m=1+.5*(b.lv-1),u='res com ind'.includes(d.c)&&b.lv<5;
showInfo(`<b>${d.n}</b> · ур.${b.lv}<br>${d.pop?ic('people')+Fm(d.pop*m)+' ':''}${d.inc?ic('chart')+Fm(d.inc*m)+' ':''}${d.jobs?ic('brief')+Fm(d.jobs*m)+' ':''}${d.hp?ic('f1')+'+'+Fm(d.hp*m):''}<br>Содержание: ${Fm(d.up)} · Дорога: ${access(b)?'есть':'нет'}${d.rail?' · Рельсы: '+(access(b,isT)?'есть':'нет'):''}<br>${u?`<button onclick="upg()">${ic('upg')} ${Fm(upc(b))}</button>`:''}<button onclick="rm()">${ic('trash')} +${Fm(d.cost/2)}</button><button onclick="hideInfo()">${ic('close')}</button>`)}
function upg(){const b=sel,c=upc(b);if(!pay(c))return;b.lv++;sc.remove(b.mesh);b.mesh=mk(b.id,b.lv);setPos(b);sc.add(b.mesh);puff(b.mesh.position.x,b.mesh.position.z);S.xp+=xpb(c);checkLv();ui();infoB();dirty=1}
function rm(){delB(sel);hideInfo();ui();dirty=1}
function select(c){const b=grid[c[1]*N+c[0]];if(!b||!b.id){hideInfo();return}sel=b;fp.visible=true;fp.material.color.set(0xffd54f);fp.scale.set(b.w,b.d,1);
C.gx=b.x-N/2+b.w/2;C.gz=b.z-N/2+b.d/2;fp.position.set(C.gx,.05,C.gz);infoB()}
function paintCell(c){const i=c[1]*N+c[0],g=grid[i],t=T[i];
if(tool=='del'){if(g&&g.id)delB(g);else if(g){grid[i]=null;S.m+=3;rebuildNet()}else return}
else{if(g||t==2)return;if(tool=='path'&&t==1)return;const cost=({road:10,rail:30,path:4})[tool]*(t==1?6:1);if(!pay(cost))return;grid[i]={road:'r',rail:'t',path:'p'}[tool];if(t==3){T[i]=0;rebuildTerrain()}rebuildNet();S.xp+=1;checkLv()}
ui();dirty=1}
function act(){if(tool=='build'){const d=D[cur];if(!canPlace(cur,gx,gz,grot))return toast(d.k=='pump'?'Нужно нефтяное пятно':d.k=='mine'?'Нужна руда':'Здесь строить нельзя');if(!pay(d.cost))return;
const[w,dd]=dims(d,grot);let fr=0;for(let i=0;i<w;i++)for(let j=0;j<dd;j++){const k=(gz+j)*N+gx+i;if(T[k]==3){T[k]=0;fr=1}}if(fr)rebuildTerrain();
const b=addB(cur,gx,gz,grot,1,1);crew(b);S.xp+=xpb(d.cost);checkLv();ui();updGhost();dirty=1}
else if(tool)paintCell([gx,gz]);else select([gx,gz])}
function dir(a){const k=Math.round(C.gy/(Math.PI/2))*Math.PI/2,s=Math.round(Math.sin(k)),c=Math.round(Math.cos(k)),f=[-s,-c],r=[c,-s],v={u:f,d:[-f[0],-f[1]],r,l:[-r[0],-r[1]]}[a],
[w,dd]=tool=='build'?dims(D[cur],grot):[1,1];gx=cl(gx+v[0],0,N-w);gz=cl(gz+v[1],0,N-dd);if(tool!='build'){hideInfo();curOn=1}showCur();C.vx=C.vz=0;C.gx=gx-N/2+w/2;C.gz=gz-N/2+dd/2}
function hold(id,fn){const e=$(id);let h=0;const stop=()=>{clearInterval(h);h=0};e.onpointerdown=ev=>{ev.preventDefault();fn();clearInterval(h);h=setInterval(fn,130)};e.onpointerup=e.onpointerleave=e.onpointercancel=stop}
function showList(c){if(c=='net'){$('list').innerHTML=NT.map(([k,n,i,cost])=>`<div class="it" data-k="tool:${k}">${ic(i,'#cfd8dc')}<b>${n}</b><br>${ic('money','#ffd54f')}${cost}</div>`).join('');lst(1);return}
const ct=CATS.find(x=>x[0]==c);$('list').innerHTML=Object.keys(D).filter(k=>D[k].c==c).map(k=>{const d=D[k],lk=d.lv>S.lv&&!S.sb;
return `<div class="it${lk?' lk':''}" data-k="${k}">${ic(ct[2],ct[3])}<b>${d.n}</b><br>${lk?ic('lock')+'ур.'+d.lv:ic('money','#ffd54f')+Fm(d.cost)}<br>${d.w}×${d.d} ${d.pop?ic('people')+Fm(d.pop):d.inc?ic('chart')+Fm(d.inc):d.pw?ic('bolt')+d.pw:d.wt?ic('drop')+d.wt:d.hp?ic('f1')+Fm(d.hp):''}</div>`}).join('');lst(1)}
$('bar').innerHTML=CATS.map(c=>`<button data-c="${c[0]}">${ic(c[2],c[3])}</button>`).join('')+`<button data-c="net">${ic('road','#cfd8dc')}</button><button data-c="del">${ic('trash','#ff6b6b')}</button>`;
$('bar').onclick=e=>{const b=e.target.closest('button');if(!b)return;const c=b.dataset.c;hideInfo();
if(c=='del'){const t=tool==c;clearTool();if(!t){tool=c;mark();toast('Снос: касание или стрелки и галочка')}return}
const o=openC==c;clearTool();if(!o){openC=c;showList(c)}mark()};
$('list').onclick=e=>{const it=e.target.closest('.it');if(!it)return;const k=it.dataset.k;
if(k.startsWith('tool:')){clearTool();tool=k.slice(5);mark();toast(tool=='road'?'Рисуйте пальцем или стрелками и галочкой':tool=='rail'?'Рельсы и станция — поезда':'Тропинки для жителей');return}
const d=D[k];if(d.lv>S.lv&&!S.sb)return toast('Нужен уровень '+d.lv);
cur=k;tool='build';grot=0;openC=null;curOn=0;hideInfo();lst(0);const[w,dd]=dims(d,0);gx=cl(Math.round(C.gx+N/2-w/2),0,N-w);gz=cl(Math.round(C.gz+N/2-dd/2),0,N-dd);setGhost();mark();
if(SET.hint)toast('Выберите место стрелками или касанием, затем «Построить»')};
$('ok').onclick=$('ac').onclick=act;
$('rot').onclick=()=>{grot=(grot+1)&3;const[w,dd]=dims(D[cur],grot);gx=cl(gx,0,N-w);gz=cl(gz,0,N-dd);updGhost()};$('no').onclick=clearTool;
[['au','u'],['ad','d'],['al','l'],['ar','r']].forEach(([i,a])=>hold(i,()=>dir(a)));
$('tb').onclick=()=>{document.body.classList.toggle('nobar');if(document.body.classList.contains('nobar')){openC=null;lst(0);mark()}lay()};
$('zi').onclick=()=>C.gd=cl(C.gd*.8,6,70);$('zo').onclick=()=>C.gd=cl(C.gd*1.25,6,70);$('rc').onclick=()=>C.gy+=Math.PI/4;
$('hm').onclick=()=>{const n=blds.length||1;C.gx=blds.reduce((s,b)=>s+b.x+b.w/2,0)/n-N/2;C.gz=blds.reduce((s,b)=>s+b.z+b.d/2,0)/n-N/2;if(!blds.length)C.gx=C.gz=0;C.vx=C.vz=0};
$('top').onclick=()=>showInfo(`${ic('bolt','#ffe94d')}${pct(S.eP)} · ${ic('drop','#6ab8ff')}${pct(S.eW)} · ${ic('brief')}${pct(S.emp)}<br>${ic('road')}${RL.length} · загрязнение ${(S.pl||0).toFixed(1)}<br>${S.adv}<br><button onclick="hideInfo()">${ic('close')}</button>`);
function applyUI(){const s=document.documentElement.style;s.setProperty('--u',SET.ui);s.setProperty('--dps',SET.dps);s.setProperty('--op',SET.op);document.body.classList.toggle('dpr',SET.dpm==2);document.body.classList.toggle('nodp',SET.dpm==0);lay()}
function applySet(){const pr=Math.min(devicePixelRatio,SET.pr),key=pr+'|'+innerWidth+'|'+innerHeight;
if(applySet.k!=key){applySet.k=key;R.setPixelRatio(pr);R.setSize(innerWidth,innerHeight);if(CP){CP.setPixelRatio(pr);CP.setSize(innerWidth,innerHeight)}}
sun.castShadow=!!SET.sh;const ms=SET.shq?2048:1024;
if(sun.shadow.mapSize.x!=ms){sun.shadow.mapSize.set(ms,ms);if(sun.shadow.map){sun.shadow.map.dispose();sun.shadow.map=null}}
sc.fog.near=SET.fog*.3;sc.fog.far=SET.fog;gh.visible=!!SET.grid;clouds.visible=!!SET.cloud;cam.fov=SET.fov;cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix();
SWA.value=SET.shd?1:0;if(SET.shd)loadFX();if(BL)BL.strength=SET.bloom;
if(RL.length||HM.length)syncAll();lay();try{localStorage.setItem('mcs',JSON.stringify(SET))}catch(e){}}
function setQ(q){Object.assign(SET,QP[q],{ql:q})}
function pickDev(d){SET.dev=d;const v=DEVS[d];SET.ui=v.ui;setQ(v.q);if(v.pr)SET.pr=v.pr;applyUI();applySet();if(d=='pc')toast('ПК: ЛКМ — двигать, ПКМ — вращать, колесо — зум, WASD/Q/E, Enter — построить')}
function resetSet(){const dv=SET.dev;Object.assign(SET,DEF);if(dv){SET.dev=dv;pickDev(dv)}C.gp=SET.tilt;C.gd=SET.dist;applyUI();applySet();tabs();renderSet();toast('Настройки сброшены')}
function tabs(){$('tabs').innerHTML=['Камера','Графика','Игра'].map((t,i)=>`<button data-t="${i}" class="${i==tab?'on':''}">${t}</button>`).join('');
$('cbtn').innerHTML=tab==0?['top|Сверху','iso|Обзор','side|Сбоку','rl|Влево 90°','rr|Вправо 90°'].map(s=>{const[a,t]=s.split('|');return `<button data-a="${a}">${t}</button>`}).join(''):
tab==1?['Низкое','Среднее','Высокое'].map((t,i)=>`<button data-a="q${i}" class="${SET.ql==i?'cur':''}">${t}</button>`).join(''):
[['phone','Телефон'],['tab','Планшет'],['pc','ПК']].map(([a,t])=>`<button data-a="d:${a}" class="${SET.dev==a?'cur':''}">${ic(a)} ${t}</button>`).join('')}
function renderSet(){const r=OP.filter(o=>o[0]==tab).map(o=>`<label class="row">${o[2]}<b>${SET[o[1]]}</b><input type="range" data-k="${o[1]}" min="${o[3]}" max="${o[4]}" step="${o[5]}" value="${SET[o[1]]}"></label>`).join(''),
g=TG.filter(o=>o[0]==tab).map(o=>`<label class="row">${o[2]}<input type="checkbox" data-k="${o[1]}" ${SET[o[1]]?'checked':''}></label>`).join('');
$('sb').innerHTML=g+r+(tab==2?`<div class="row">Стрелки<div class="seg">${['Нет','Слева','Справа'].map((t,i)=>`<button data-v="${i}" class="${SET.dpm==i?'cur':''}">${t}</button>`).join('')}</div></div>`:'')}
$('sb').oninput=e=>{const k=e.target.dataset.k;if(!k)return;SET[k]=e.target.type=='checkbox'?+e.target.checked:+e.target.value;if(e.target.type=='range')e.target.previousElementSibling.textContent=SET[k];
if(k=='hour')S.tm=SET.hour/24%1;else if(k=='tilt')C.gp=SET.tilt;else if(k=='dist')C.gd=SET.dist;else if(k=='ui')applyUI();applySet()};
$('sb').onclick=e=>{const b=e.target.closest('.seg button');if(!b)return;SET.dpm=+b.dataset.v;applyUI();applySet();renderSet()};
function openMenu(){SET.tilt=+C.gp.toFixed(2);SET.dist=Math.round(C.gd);SET.hour=Math.round(S.tm*48)/2;$('menu').style.display='flex';paused=1;tabs();renderSet()}
$('ts').onclick=openMenu;$('sets').onclick=openMenu;
$('mb').onclick=e=>{const b=e.target.closest('button');if(!b)return;
if(b.dataset.t!=null){tab=+b.dataset.t;tabs();renderSet();return}
const a=b.dataset.a;if(!a)return;
if(a=='go'){$('menu').style.display='none';if(!document.body.classList.contains('mn'))paused=0}
else if(a=='save'){save();toast('Сохранено')}
else if(a=='quit')toMenu();
else if(a=='reset')resetSet();
else if(a=='rl')C.gy-=Math.PI/2;else if(a=='rr')C.gy+=Math.PI/2;
else if(/^q\d$/.test(a)){setQ(+a[1]);applySet();tabs();renderSet()}
else if(a.startsWith('d:')){pickDev(a.slice(2));tabs();renderSet()}
else{SET.tilt=a=='top'?1.45:a=='iso'?.9:.45;C.gp=SET.tilt;applySet();renderSet()}};
function upCam(rd){const l=1-Math.pow(1-SET.smooth,rd*60);
if(!PM.size&&(Math.abs(C.vx)>1e-4||Math.abs(C.vz)>1e-4)){C.gx=cl(C.gx+C.vx*rd*60,-N/2,N/2);C.gz=cl(C.gz+C.vz*rd*60,-N/2,N/2);const f=Math.pow(SET.mom,rd*60);C.vx*=f;C.vz*=f}
C.x+=(C.gx-C.x)*l;C.z+=(C.gz-C.z)*l;C.d+=(C.gd-C.d)*l;C.yaw+=(C.gy-C.yaw)*l;C.pitch+=(C.gp-C.pitch)*l;const cp=Math.cos(C.pitch);
cam.position.set(C.x+Math.sin(C.yaw)*cp*C.d,Math.sin(C.pitch)*C.d,C.z+Math.cos(C.yaw)*cp*C.d);cam.lookAt(C.x,0,C.z)}
function pan(dx,dy){const k=.93*C.d/innerHeight*SET.pan*(SET.inv?-1:1),s=Math.sin(C.yaw),c=Math.cos(C.yaw),wx=(-s*dy-c*dx)*k,wz=(-c*dy+s*dx)*k;
C.gx=cl(C.gx+wx,-N/2,N/2);C.gz=cl(C.gz+wz,-N/2,N/2);C.vx=wx;C.vz=wz;C.lt=performance.now()}
const rc=new THREE.Raycaster(),pl=new THREE.Plane(new THREE.Vector3(0,1,0),0),v3=new THREE.Vector3();
function cellAt(px,py){rc.setFromCamera({x:px/innerWidth*2-1,y:-py/innerHeight*2+1},cam);if(!rc.ray.intersectPlane(pl,v3))return null;const x=Math.floor(v3.x+N/2),z=Math.floor(v3.z+N/2);return x<0||z<0||x>=N||z>=N?null:[x,z]}
function tap(px,py){const c=cellAt(px,py);if(!c)return;
if(tool=='build'){const[w,d]=dims(D[cur],grot);gx=cl(c[0]-((w-1)>>1),0,N-w);gz=cl(c[1]-((d-1)>>1),0,N-d);updGhost()}
else{gx=c[0];gz=c[1];curOn=0;if(tool)paintCell(c);else select(c)}}
const cv=R.domElement,PM=new Map();let g0=null;
cv.addEventListener('webglcontextlost',e=>e.preventDefault());
const gest=()=>{const[a,b]=[...PM.values()];return{d:Math.hypot(a.x-b.x,a.y-b.y),a:Math.atan2(b.y-a.y,b.x-a.x),x:(a.x+b.x)/2,y:(a.y+b.y)/2}};
cv.addEventListener('pointerdown',e=>{cv.setPointerCapture(e.pointerId);C.vx=C.vz=0;PM.set(e.pointerId,{x:e.clientX,y:e.clientY,sx:e.clientX,sy:e.clientY,mv:e.button==2?2:0});if(PM.size==2){g0=gest();PM.forEach(p=>p.mv=2)}});
cv.addEventListener('pointermove',e=>{const p=PM.get(e.pointerId);if(!p)return;const dx=e.clientX-p.x,dy=e.clientY-p.y;p.x=e.clientX;p.y=e.clientY;
if(e.pointerType=='mouse'&&e.buttons==2){C.gy-=dx*.01*SET.rot;return}
if(PM.size==1){if(!p.mv&&Math.hypot(p.x-p.sx,p.y-p.sy)>8)p.mv=1;if(p.mv==1){if(NETT.includes(tool)||tool=='del'){const c=cellAt(p.x,p.y);if(c)paintCell(c)}else pan(dx,dy)}}
else if(PM.size==2&&g0){const g=gest();C.gd=cl(C.gd*Math.pow(g0.d/g.d,SET.zoom),6,70);let da=g.a-g0.a;if(da>Math.PI)da-=2*Math.PI;if(da<-Math.PI)da+=2*Math.PI;C.gy-=da*SET.rot;pan(g.x-g0.x,g.y-g0.y);C.vx=C.vz=0;g0=g}});
const pu=e=>{const p=PM.get(e.pointerId);PM.delete(e.pointerId);g0=null;if(performance.now()-C.lt>90)C.vx=C.vz=0;if(p&&!p.mv&&e.type=='pointerup')tap(p.x,p.y)};
cv.addEventListener('pointerup',pu);cv.addEventListener('pointercancel',pu);
cv.addEventListener('wheel',e=>{C.gd=cl(C.gd*(1+Math.sign(e.deltaY)*.1*SET.zoom),6,70);e.preventDefault()},{passive:false});
cv.addEventListener('contextmenu',e=>e.preventDefault());
const KB={};addEventListener('keydown',e=>{KB[e.key.toLowerCase()]=1;if(e.key=='Enter'&&!paused)act()});addEventListener('keyup',e=>KB[e.key.toLowerCase()]=0);
function keys(rd){const s=Math.sin(C.yaw),c=Math.cos(C.yaw),v=rd*C.d*.8*SET.pan;let fx=0,fz=0;
if(KB.w||KB.arrowup){fx-=s;fz-=c}if(KB.s||KB.arrowdown){fx+=s;fz+=c}if(KB.a||KB.arrowleft){fx-=c;fz+=s}if(KB.d||KB.arrowright){fx+=c;fz-=s}
if(fx||fz){C.vx=C.vz=0;C.gx=cl(C.gx+fx*v,-N/2,N/2);C.gz=cl(C.gz+fz*v,-N/2,N/2)}C.gy+=((KB.e?1:0)-(KB.q?1:0))*rd*1.5*SET.rot}
const SK=i=>'mc_s'+i,slotData=i=>{try{return JSON.parse(localStorage.getItem(SK(i)))}catch(e){return null}};
function save(){dirty=0;if(S.slot<0)return;try{localStorage.setItem(SK(S.slot),JSON.stringify({name:S.name,sb:S.sb,loc:S.loc,lv:S.lv,pop:S.pop,m:isFinite(S.m)?S.m:0,xp:S.xp,hap:S.hap,q:S.q,tm:S.tm,t:T.join(''),b:blds.map(b=>[b.id,b.x,b.z,b.rot,b.lv]),r:RL,l:RT,p:RP}))}catch(e){}}
function reset(){blds.forEach(b=>sc.remove(b.mesh));blds=[];grid.fill(null);T.fill(0);mv.forEach(o=>sc.remove(o.m));mv.length=0;PLN.forEach(o=>sc.remove(o.m));PLN.length=0;HM=[];DST=[];STP=[];DEP=[];HG=[];
Object.assign(S,{slot:-1,name:'',sb:0,loc:'flat',m:5000,xp:0,lv:1,pop:0,hap:50,net:0,q:0,tm:.42,eP:1,eW:1,emp:1,pl:0,adv:'Постройте дороги, а дома рядом с ними'});
setLand('flat');rebuildTerrain();rebuildNet();C.x=C.gx=C.z=C.gz=0;C.vx=C.vz=0;gx=gz=N/2-1;clearTool();hideInfo();ui()}
function buildDemo(){reset();Object.assign(S,{sb:1,m:Infinity,lv:999,q:99,tm:.27});
for(let z=0;z<N;z++)for(let x=0;x<N;x++){if(Math.hypot(x-4,z-36)<3.6)T[z*N+x]=1;else if(Math.hypot(x-2,z-2)<5)T[z*N+x]=2;else if(Math.hypot(x-36,z-4)<5&&(x*7+z*3)%5)T[z*N+x]=3}
rebuildTerrain();
const net=(x,z,t)=>{const i=z*N+x;if(x<0||z<0||x>=N||z>=N||grid[i]||T[i]==1||T[i]==2)return;if(T[i]==3)T[i]=0;grid[i]=t},put=(id,x,z,r,lv)=>{if(canPlace(id,x,z,r))addB(id,x,z,r,lv||1,0)};
[9,16,23,30].forEach(a=>{for(let k=6;k<=33;k++){net(k,a,'r');net(a,k,'r')}});for(let x=8;x<=37;x++)net(x,37,'t');
put('cpark',18,18,0);put('depot',10,10,2);put('fire',13,10,2);put('hosp',17,10,2);put('police',24,10,2);put('school',24,17,2);put('stn',17,35,0);put('bus',12,15,0);put('bus',26,22,0);put('bus',12,24,0);
const zone=(x,z)=>{const d=Math.hypot(x-19.5,z-19.5);return d<6?['tower','sky','bizc','office','hotel','tower','loft']:d<11?['apt','block','court','super','mall','cine','bank','rest','panel','loft','theater','univ','school','hotel']:['house','cott','town','duplex','villa','modern','shop','cafe','bak','manor','work','farm','saw','ware','house','cott','kg','post','pharm','cloth']},
front=(x,z,w,d,r)=>(r==0?Array.from({length:w},(_,i)=>[x+i,z+d]):r==1?Array.from({length:d},(_,i)=>[x+w,z+i]):r==2?Array.from({length:w},(_,i)=>[x+i,z-1]):Array.from({length:d},(_,i)=>[x-1,z+i])).some(([a,b])=>isR(a,b));
for(let z=6;z<=34;z++)for(let x=6;x<=34;x++){if(grid[z*N+x]||Math.random()<.1)continue;const id=rnd(zone(x,z)),dd=D[id],lv='res com ind'.includes(dd.c)?1+(Math.random()*3|0):1;
for(const r of[0,1,2,3].sort(()=>Math.random()-.5)){const[w,d]=dims(dd,r);if(canPlace(id,x,z,r)&&front(x,z,w,d,r)){addB(id,x,z,r,lv,0);break}}}
for(let z=6;z<=34;z++)for(let x=6;x<=34;x++){const i=z*N+x;if(grid[i]||T[i]==1||T[i]==2)continue;if([[1,0],[-1,0],[0,1],[0,-1]].some(([a,b])=>isR(x+a,z+b))&&Math.random()<.4)addB(rnd(['tree','tree','pine','flow','hedge']),x,z,0,1,0)}
rebuildNet();scan();syncAll();ui();C.x=C.gx=C.z=C.gz=0;C.d=C.gd=34;C.pitch=C.gp=.8;C.yaw=C.gy=.8}
function toMenu(){save();$('menu').style.display='none';buildDemo();document.body.classList.add('mn');$('start').style.display='flex';paused=1}
function loadSlot(i){const s=slotData(i);if(!s||!Array.isArray(s.b))return 0;reset();
Object.assign(S,{slot:i,name:s.name||'Город',sb:s.sb?1:0,loc:s.loc||'flat',m:s.sb?Infinity:+s.m||0,xp:+s.xp||0,lv:+s.lv||1,pop:+s.pop||0,hap:+s.hap||50,q:+s.q||0,tm:s.tm==null?.42:+s.tm});
if(typeof s.t=='string')for(let k=0;k<N*N;k++)T[k]=+s.t[k]||0;setLand(S.loc);rebuildTerrain();
const put=(a,v)=>(a||[]).forEach(([x,z])=>{if(x>=0&&z>=0&&x<N&&z<N)grid[z*N+x]=v});put(s.r,'r');put(s.l,'t');put(s.p,'p');
s.b.forEach(([id,x,z,r,l])=>{if(D[id]&&canPlace(id,x,z,r))addB(id,x,z,r,l||1,0)});rebuildNet();scan();syncAll();ui();return 1}
function migrate(){if(!slotData(0)&&localStorage.getItem('megacity')){try{const s=JSON.parse(localStorage.getItem('megacity'));s.name='Мой город';s.loc='flat';localStorage.setItem(SK(0),JSON.stringify(s))}catch(e){}}}
function newCity(){const sl=ns.slot;reset();Object.assign(S,{slot:sl,name:($('nm').value.trim()||'Город '+(sl+1)).slice(0,18),sb:ns.mode,loc:ns.loc});if(S.sb)S.m=Infinity;
genMap(ns.loc,ns.seed);setLand(ns.loc);rebuildTerrain();save();ui();start();toast('Постройте дорогу, затем дом рядом с ней')}
function start(){closeOv();document.body.classList.remove('mn');$('start').style.display='none';C.gd=SET.dist;C.gp=SET.tilt;C.gy=.8;paused=0;applyUI();ui()}
function closeOv(){$('slots').style.display='none';$('newg').style.display='none';document.body.classList.remove('ovr')}
function ovShow(id){closeOv();$(id).style.display='flex';document.body.classList.add('ovr')}
function slotsUI(){$('sl').innerHTML=[0,1,2].map(i=>{const s=slotData(i);return s?`<div class="card"><b>${esc(s.name)}</b><span>${ic('star')}${s.lv} ${ic('people')}${Fm(s.pop)} · ${s.sb?'Песочница':'Обычный'} · ${LOC[s.loc]?LOC[s.loc][0]:''}</span><div><button data-a="p${i}">Играть</button><button data-a="x${i}" class="alt">${delArm==i?'Точно удалить?':'Удалить'}</button></div></div>`:`<div class="card"><b>Слот ${i+1}</b><span>Пусто</span><div><button data-a="n${i}">Создать город</button></div></div>`}).join('')}
function ngUI(){$('md').innerHTML=['Обычный','Песочница'].map((t,i)=>`<button data-m="${i}" class="${ns.mode==i?'cur':''}">${t}</button>`).join('');
$('locs').innerHTML=Object.keys(LOC).map(k=>`<button data-l="${k}" class="${ns.loc==k?'cur':''}"><img class="pv" src="${preview(k,ns.seed)}" alt=""><b>${ic(LOC[k][2])}${LOC[k][0]}</b><span>${LOC[k][1]}</span></button>`).join('')}
$('sl').onclick=e=>{const b=e.target.closest('button');if(!b)return;const a=b.dataset.a,i=+a[1];
if(a[0]=='p'){if(loadSlot(i))start()}
else if(a[0]=='x'){if(delArm==i){localStorage.removeItem(SK(i));delArm=-1}else{delArm=i;setTimeout(()=>{delArm=-1;slotsUI()},3000)}slotsUI()}
else{ns={slot:i,mode:0,loc:'flat',seed:Math.random()*1e9|0};$('nm').value='';ngUI();ovShow('newg')}};
$('md').onclick=e=>{const b=e.target.closest('button');if(b){ns.mode=+b.dataset.m;ngUI()}};
$('locs').onclick=e=>{const b=e.target.closest('button');if(b){ns.loc=b.dataset.l;ngUI()}};
$('reroll').onclick=()=>{ns.seed=Math.random()*1e9|0;for(const k in PV)delete PV[k];ngUI()};
$('go1').onclick=newCity;$('back1').onclick=()=>{slotsUI();ovShow('slots')};$('slb').onclick=closeOv;
function needDev(f){if(SET.dev)f();else{pend=f;$('dev').style.display='flex'}}
$('dev').onclick=e=>{const b=e.target.closest('button');if(!b)return;pickDev(b.dataset.d);$('dev').style.display='none';const f=pend;pend=null;if(f)f()};
$('play').onclick=()=>needDev(()=>{migrate();slotsUI();ovShow('slots')});
addEventListener('pagehide',save);document.addEventListener('visibilitychange',()=>{if(document.hidden)save()});
addEventListener('resize',()=>{applySet();lay()});addEventListener('orientationchange',()=>setTimeout(()=>{applySet();lay()},200));
function loop(t){requestAnimationFrame(loop);const rd=Math.min(.1,(t-last)/1e3||0);last=t;const dt=rd*SET.spd,ph=(t/160|0)%2,mn=document.body.classList.contains('mn'),live=!paused||mn;
SWT.value=t/1e3;WT.offset.x+=rd*.03;WT.offset.y+=rd*.02;ST.offset.x+=rd*.01;
if(live){acc+=dt;if(acc>=5){acc=0;tick()}mv.forEach(o=>step(o,dt));PLN.forEach(o=>stepPl(o,dt))}
if(!paused){sa+=rd;if(sa>SET.asv){sa=0;if(dirty)save()}if(SET.dn>0)S.tm=(S.tm+dt/(SET.dn*60))%1;keys(rd)}
else if(mn)C.gy+=rd*.1;
for(let i=mv.length-1;i>=0;i--){const o=mv[i];if(o.dead){sc.remove(o.m);mv.splice(i,1)}else{const lt=o.m.userData.lt;if(lt&&o.m.visible){lt[0].visible=!ph;lt[lt.length-1].visible=!!ph}}}
for(let i=PLN.length-1;i>=0;i--)if(PLN[i].dead){sc.remove(PLN[i].m);PLN.splice(i,1)}
smT+=rd;const sm=smT>.6;if(sm)smT=0;
blds.forEach(b=>{if(b.t<1){b.t=Math.min(1,b.t+rd*3);b.mesh.scale.setScalar(.05+.95*(1-Math.pow(1-b.t,3)))}const u=b.mesh.userData;if(u.bl)u.bl.rotation.z+=rd*2;if(u.rt)u.rt.rotation.y+=rd*20;if(u.bm)u.bm.rotation.z=Math.sin(t/350)*.18;if(sm&&live)smoke(b)});
for(let i=pt.length-1;i>=0;i--){const p=pt[i];if(!p.sm)p.vy-=6*rd;p.m.position.x+=p.vx*rd;p.m.position.y+=p.vy*rd;p.m.position.z+=p.vz*rd;p.l-=rd;
if(p.sm)p.m.scale.setScalar(.2+Math.sin((1-p.l/p.L)*Math.PI)*1.3);if(p.l<=0||(!p.sm&&p.m.position.y<0)){sc.remove(p.m);pt.splice(i,1)}}
if(clouds.visible)clouds.children.forEach(c=>{c.position.x+=rd*1.5;if(c.position.x>150)c.position.x=-150});
ck+=rd;if(ck>.5){ck=0;clk()}
upCam(rd);env();if(SET.shd&&CP)CP.render();else R.render(sc,cam)}
document.querySelectorAll('[data-i]').forEach(e=>e.innerHTML=ic(e.dataset.i)+(e.dataset.t||''));
applyUI();applySet();
try{buildDemo()}catch(e){console.error(e)}
requestAnimationFrame(loop);