/* =====================================================
   BEE NOTE
   BEE SOFT.AI
   ===================================================== */

const $ = id => document.getElementById(id);


/* =========================
   STATE
========================= */

let notes =
  JSON.parse(localStorage.getItem("beeNotesV2")) || [];

let folders =
  JSON.parse(localStorage.getItem("beeFolders")) || [];

let currentId = null;
let currentPinned = false;
let currentFolder = null;

let currentView = "all";
let sortNewest = true;


/* =========================
   ELEMENTS
========================= */

const sidebar = $("sidebar");
const editor = $("editor");

const notesContainer = $("notesContainer");
const emptyState = $("emptyState");

const searchInput = $("searchInput");

const noteTitle = $("noteTitle");
const noteContent = $("noteContent");

const pinBtn = $("pinBtn");
const deleteBtn = $("deleteBtn");

const folderModal = $("folderModal");
const folderName = $("folderName");


/* =========================
   STORAGE
========================= */

function saveData() {
  localStorage.setItem(
    "beeNotesV2",
    JSON.stringify(notes)
  );

  localStorage.setItem(
    "beeFolders",
    JSON.stringify(folders)
  );
}


/* =========================
   ESCAPE HTML
========================= */

function escapeHTML(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}


/* =========================
   DATE
========================= */

function getDate() {
  return new Date().toLocaleString("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}


/* =========================
   RENDER
========================= */

function render() {

  let result = [...notes];

  const search =
    searchInput.value
      .toLowerCase()
      .trim();


  /* SEARCH */

  if (search) {
    result = result.filter(note =>
      note.title.toLowerCase().includes(search) ||
      note.content.toLowerCase().includes(search)
    );
  }


  /* VIEW */

  if (currentView === "pinned") {
    result = result.filter(note => note.pinned);
  }


  if (currentView.startsWith("folder:")) {

    const folderId =
      Number(currentView.split(":")[1]);

    result = result.filter(
      note => note.folderId === folderId
    );
  }


  /* SORT */

  result.sort((a, b) => {

    if (a.pinned !== b.pinned) {
      return b.pinned - a.pinned;
    }

    return sortNewest
      ? b.updated - a.updated
      : a.updated - b.updated;
  });


  notesContainer.innerHTML = "";


  /* EMPTY */

  if (result.length === 0) {

    emptyState.classList.remove("hidden");

    if (search) {

      $("emptyTitle").textContent =
        "No notes found";

      $("emptyText").textContent =
        "Try another search keyword.";

    } else if (currentView === "pinned") {

      $("emptyTitle").textContent =
        "No pinned notes";

      $("emptyText").textContent =
        "Pin important notes so you can find them quickly.";

    } else {

      $("emptyTitle").textContent =
        "Nothing here yet";

      $("emptyText").textContent =
        "Start capturing your ideas with BEE NOTE.";
    }

  } else {

    emptyState.classList.add("hidden");

    result.forEach(createNoteCard);
  }


  updateCounts();
  renderFolders();
}


/* =========================
   NOTE CARD
========================= */

function createNoteCard(note) {

  const card =
    document.createElement("article");

  card.className = "note-card";

  const preview =
    note.content || "Empty note";

  card.innerHTML = `

    <div class="note-card-top">

      <h3>
        ${escapeHTML(note.title || "Untitled note")}
      </h3>

      ${
        note.pinned
          ? '<span class="note-pin">★</span>'
          : ""
      }

    </div>

    <p class="note-preview">
      ${escapeHTML(preview)}
    </p>

    <div class="note-card-bottom">

      <span>
        ${escapeHTML(note.date)}
      </span>

      <span>
        ${countWords(note.content)} words
      </span>

    </div>
  `;


  card.addEventListener(
    "click",
    () => openEditor(note.id)
  );


  notesContainer.appendChild(card);
}


/* =========================
   COUNTS
========================= */

function updateCounts() {

  $("allCount").textContent =
    notes.length;

  $("pinnedCount").textContent =
    notes.filter(n => n.pinned).length;

  $("resultText").textContent =
    `${notes.length} ${
      notes.length === 1 ? "note" : "notes"
    }`;
}


/* =========================
   FOLDERS
========================= */

function renderFolders() {

  const container = $("folders");

  container.innerHTML = "";

  folders.forEach(folder => {

    const item =
      document.createElement("button");

    item.className =
      "folder-item" +
      (
        currentView === `folder:${folder.id}`
          ? " active"
          : ""
      );

    item.innerHTML = `
      <span>▱</span>
      <span>${escapeHTML(folder.name)}</span>
      <span class="folder-delete">×</span>
    `;


    item.addEventListener("click", event => {

      if (
        event.target.classList.contains(
          "folder-delete"
        )
      ) {

        deleteFolder(folder.id);

        return;
      }

      currentView =
        `folder:${folder.id}`;

      updatePageTitle();

      render();

      closeSidebarMobile();
    });


    container.appendChild(item);
  });
}


/* =========================
   CREATE FOLDER
========================= */

function openFolderModal() {

  folderName.value = "";

  folderModal.classList.remove(
    "hidden"
  );

  setTimeout(
    () => folderName.focus(),
    50
  );
}


function closeFolderModal() {

  folderModal.classList.add(
    "hidden"
  );
}


function createFolder() {

  const name =
    folderName.value.trim();

  if (!name) return;

  folders.push({
    id: Date.now(),
    name
  });

  saveData();

  render();

  closeFolderModal();
}


function deleteFolder(id) {

  const folder =
    folders.find(f => f.id === id);

  if (!folder) return;

  if (
    !confirm(
      `Delete folder "${folder.name}"?`
    )
  ) return;

  notes.forEach(note => {

    if (note.folderId === id) {
      note.folderId = null;
    }

  });

  folders =
    folders.filter(f => f.id !== id);

  if (
    currentView === `folder:${id}`
  ) {
    currentView = "all";
    updatePageTitle();
  }

  saveData();

  render();
}


/* =========================
   EDITOR
========================= */

function openEditor(id = null) {

  currentId = id;

  if (id === null) {

    noteTitle.value = "";
    noteContent.value = "";

    currentPinned = false;

    $("editorMode").textContent =
      "New note";

    $("noteMeta").textContent =
      "New note";

    deleteBtn.style.display =
      "none";

  } else {

    const note =
      notes.find(n => n.id === id);

    if (!note) return;

    noteTitle.value =
      note.title;

    noteContent.value =
      note.content;

    currentPinned =
      Boolean(note.pinned);

    $("editorMode").textContent =
      "Edit note";

    $("noteMeta").textContent =
      `Last edited ${note.date}`;

    deleteBtn.style.display =
      "block";
  }


  updatePinButton();
  updateWordCount();

  editor.classList.remove(
    "hidden"
  );

  document.body.style.overflow =
    "hidden";

  setTimeout(
    () => noteTitle.focus(),
    100
  );
}


function closeEditor() {

  editor.classList.add(
    "hidden"
  );

  document.body.style.overflow =
    "";

  currentId = null;
}


/* =========================
   SAVE
========================= */

function saveNote() {

  const title =
    noteTitle.value.trim();

  const content =
    noteContent.value.trim();


  if (!title && !content) {

    closeEditor();

    return;
  }


  if (currentId === null) {

    notes.push({

      id: Date.now(),

      title:
        title || "Untitled note",

      content,

      pinned:
        currentPinned,

      folderId:
        currentFolder,

      date:
        getDate(),

      updated:
        Date.now()
    });

  } else {

    const note =
      notes.find(
        n => n.id === currentId
      );

    if (!note) return;

    note.title =
      title || "Untitled note";

    note.content =
      content;

    note.pinned =
      currentPinned;

    note.date =
      getDate();

    note.updated =
      Date.now();
  }


  saveData();

  render();

  closeEditor();
}


/* =========================
   DELETE NOTE
========================= */

function deleteNote() {

  if (currentId === null)
    return;


  const confirmed =
    confirm(
      "Delete this note?"
    );


  if (!confirmed)
    return;


  notes =
    notes.filter(
      n => n.id !== currentId
    );


  saveData();

  render();

  closeEditor();
}


/* =========================
   PIN
========================= */

function updatePinButton() {

  pinBtn.textContent =
    currentPinned
      ? "★"
      : "☆";

  pinBtn.classList.toggle(
    "active",
    currentPinned
  );
}


pinBtn.addEventListener(
  "click",
  () => {

    currentPinned =
      !currentPinned;

    updatePinButton();
  }
);


/* =========================
   WORD COUNT
========================= */

function countWords(text = "") {

  const clean =
    text.trim();

  if (!clean)
    return 0;

  return clean.split(/\s+/).length;
}


function updateWordCount() {

  $("wordCount").textContent =
    `${countWords(
      noteContent.value
    )} words`;
}


noteContent.addEventListener(
  "input",
  updateWordCount
);


/* =========================
   SEARCH
========================= */

searchInput.addEventListener(
  "input",
  render
);


/* =========================
   NAVIGATION
========================= */

document.querySelectorAll(
  ".nav-item"
).forEach(button => {

  button.addEventListener(
    "click",
    () => {

      currentView =
        button.dataset.view;

      updatePageTitle();

      document
        .querySelectorAll(".nav-item")
        .forEach(btn =>
          btn.classList.remove(
            "active"
          )
        );

      button.classList.add(
        "active"
      );

      render();

      closeSidebarMobile();
    }
  );
});


function updatePageTitle() {

  if (currentView === "all") {

    $("pageTitle").textContent =
      "All Notes";

    $("pageSubtitle").textContent =
      "Your ideas, organized.";

    $("pageIcon").textContent =
      "▤";

    return;
  }


  if (currentView === "pinned") {

    $("pageTitle").textContent =
      "Pinned";

    $("pageSubtitle").textContent =
      "Your important notes.";

    $("pageIcon").textContent =
      "★";

    return;
  }


  if (
    currentView.startsWith("folder:")
  ) {

    const id =
      Number(
        currentView.split(":")[1]
      );

    const folder =
      folders.find(
        f => f.id === id
      );

    if (!folder) return;

    $("pageTitle").textContent =
      folder.name;

    $("pageSubtitle").textContent =
      "Folder";

    $("pageIcon").textContent =
      "▱";
  }
}


/* =========================
   SORT
========================= */

$("sortBtn").addEventListener(
  "click",
  () => {

    sortNewest =
      !sortNewest;

    $("sortBtn").innerHTML =
      sortNewest
        ? "<span>↕</span> Recent"
        : "<span>↕</span> Oldest";

    render();
  }
);


/* =========================
   THEME
========================= */

function loadTheme() {

  const theme =
    localStorage.getItem(
      "beeNoteTheme"
    ) || "dark";

  document.body.classList.toggle(
    "light",
    theme === "light"
  );

  $("themeBtn").textContent =
    theme === "light"
      ? "☾"
      : "☼";
}


$("themeBtn").addEventListener(
  "click",
  () => {

    const light =
      document.body.classList.toggle(
        "light"
      );

    localStorage.setItem(
      "beeNoteTheme",
      light
        ? "light"
        : "dark"
    );

    $("themeBtn").textContent =
      light ? "☾" : "☼";
  }
);


/* =========================
   MOBILE SIDEBAR
========================= */

$("menuBtn").addEventListener(
  "click",
  () => {
    sidebar.classList.add(
      "open"
    );
  }
);


$("closeSidebar").addEventListener(
  "click",
  closeSidebarMobile
);


function closeSidebarMobile() {

  sidebar.classList.remove(
    "open"
  );
}


/* =========================
   CREATE BUTTONS
========================= */

$("newNoteBtn").addEventListener(
  "click",
  () => {

    currentFolder =
      currentView.startsWith("folder:")
        ? Number(
            currentView.split(":")[1]
          )
        : null;

    openEditor();

    closeSidebarMobile();
  }
);


$("emptyCreateBtn").addEventListener(
  "click",
  () => openEditor()
);


$("closeEditor").addEventListener(
  "click",
  closeEditor
);


$("saveBtn").addEventListener(
  "click",
  saveNote
);


$("deleteBtn").addEventListener(
  "click",
  deleteNote
);


/* =========================
   FOLDER BUTTONS
========================= */

$("addFolderBtn").addEventListener(
  "click",
  openFolderModal
);


$("cancelFolder").addEventListener(
  "click",
  closeFolderModal
);


$("createFolder").addEventListener(
  "click",
  createFolder
);


folderName.addEventListener(
  "keydown",
  event => {

    if (event.key === "Enter") {
      createFolder();
    }

    if (event.key === "Escape") {
      closeFolderModal();
    }
  }
);


/* =========================
   KEYBOARD SHORTCUT
========================= */

document.addEventListener(
  "keydown",
  event => {

    if (
      (event.ctrlKey ||
       event.metaKey) &&
      event.key.toLowerCase() === "k"
    ) {

      event.preventDefault();

      searchInput.focus();
    }


    if (
      event.key === "Escape" &&
      !editor.classList.contains(
        "hidden"
      )
    ) {

      closeEditor();
    }
  }
);


/* =========================
   INIT
========================= */

loadTheme();

updatePageTitle();

render();