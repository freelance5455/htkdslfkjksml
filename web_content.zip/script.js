(() => {
  "use strict";

  const EVOLUTIONS = [
    "조약돌", "큰 조약돌", "뾰족돌", "감자 바위", "양말 바위", "뒤집힌 양말 바위",
    "화난 바위", "돌인 척하는 감자", "전설의 세탁물 암석", "우주를 짊어진 돌멩이",
    "억울한 화강암 과장", "초코맛 지각 변동", "돌고래 흉내 내는 현무암", "고대의 반쯤 익은 만두",
    "이사 가기 싫은 산", "월급 루팡 운석", "은하계 먼지 털이범", "시간을 씹는 돌솥",
    "차원문에 낀 발가락", "우주 최강 김치전 암석", "중력 퇴사 통보서", "고라니 왕국의 대리석 왕",
    "빅뱅을 밟고 선 쭈꾸미", "다중우주 빨래 바구니", "차원 초월 돌돌이", "태양계의 못생긴 보스",
    "블랙홀에 빠진 찐빵 신", "현실 패치 실패작", "은하수를 삼킨 고무신", "신화급 우주 감자 제국",
    "빅뱅 재택근무 팀장", "시간선 꼬임 방지용 돌핀", "차원 404: 바위 없음", "우주의 마지막 택배 상자",
    "무한대보다 큰 콧구멍", "전설의 영원한 돌멩이"
  ];
  const PALETTES = [
    ["#888078", "#aaa49a", "#514c46"], ["#77736d", "#b2a99d", "#504b45"],
    ["#87949a", "#c0c7c5", "#46535a"], ["#b88a58", "#e0b57a", "#765136"],
    ["#796b87", "#ad9cb8", "#51445e"], ["#ac7485", "#d9a1ad", "#6b4350"],
    ["#74726b", "#b5a66b", "#4c493e"], ["#b4925f", "#dfbf7e", "#785c37"],
    ["#71877a", "#9ab69f", "#42564a"], ["#5d718f", "#a5bbdb", "#36455e"],
    ["#9f6259", "#e59b7f", "#633b36"], ["#aa7747", "#e8ba72", "#704b2e"],
    ["#4f807d", "#8dd0c2", "#315451"], ["#b58f84", "#e8c7b3", "#755b55"],
    ["#566c48", "#9ab16c", "#39442f"], ["#7b5e91", "#c09cd1", "#4c3b62"],
    ["#395c80", "#73a9cf", "#233b57"], ["#a77738", "#e7bf55", "#69451f"],
    ["#5e4d7a", "#9b83c6", "#362c4a"], ["#a64a54", "#ed9c80", "#642e3b"],
    ["#485b68", "#a5c1c4", "#2e3b47"], ["#7e6d3f", "#c1ae66", "#4f462b"],
    ["#374766", "#819bd0", "#202c49"], ["#80608b", "#d19cc7", "#493a5a"],
    ["#416f79", "#88c4c4", "#284851"], ["#6e4852", "#bb7887", "#432d38"],
    ["#39344e", "#8271a8", "#211e37"], ["#706482", "#c6b0cf", "#44384e"],
    ["#386c75", "#81bfc6", "#26464d"], ["#81563f", "#d69d5b", "#503828"],
    ["#353e5a", "#8a9bc2", "#20283f"], ["#607a5b", "#afcb85", "#3a4c38"],
    ["#544f85", "#a49bdd", "#302c55"], ["#81518b", "#d49bcb", "#4b3156"],
    ["#293b64", "#7699dd", "#182344"], ["#3f334c", "#c29b75", "#211b2a"]
  ];
  const PATTERNS = ["speckles", "stripes", "cracks", "spots", "swirl", "stars"];
  const SAVE_KEY = "dol-kiugi-save-v1";
  const MAX_VALUE = 1e300;
  const $ = (id) => document.getElementById(id);
  const ui = {
    shell: $("gameShell"), arena: $("arena"), canvas: $("stoneCanvas"),
    name: $("stoneName"), stage: $("stageLabel"), power: $("powerAmount"),
    flavor: $("stageFlavor"), reward: $("throwReward"), cost: $("upgradeCost"),
    autoStatus: $("autoStatus"), throwButton: $("throwButton"),
    upgradeButton: $("upgradeButton"), autoButton: $("autoButton"),
    throwHint: $("throwButtonHint"), upgradeHint: $("upgradeButtonHint"),
    autoTitle: $("autoButtonTitle"), autoHint: $("autoButtonHint"),
    floating: $("floatingMessage"), particles: $("particleLayer"),
    toast: $("toast"), sound: $("soundButton")
  };
  const ctx = ui.canvas.getContext("2d");
  const state = loadState();
  const animation = { throwAt: 0, impactAt: 0, bob: 0, shake: 0, sound: false };
  let toastTimer = 0;
  let lastSaved = 0;
  let lastAuto = performance.now();
  let audioContext = null;

  function finite(value, fallback = 0) {
    return Number.isFinite(value) ? Math.min(MAX_VALUE, Math.max(0, value)) : fallback;
  }

  function loadState() {
    const base = { power: 0, stage: 0, autoLevel: 0 };
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return base;
      const data = JSON.parse(raw);
      if (!data || typeof data !== "object") return base;
      return {
        power: finite(Number(data.power)),
        stage: Number.isSafeInteger(data.stage) && data.stage >= 0 ? data.stage : 0,
        autoLevel: Number.isSafeInteger(data.autoLevel) && data.autoLevel >= 0 ? Math.min(data.autoLevel, 1000) : 0
      };
    } catch (error) {
      console.error("저장 데이터를 불러오지 못했습니다.", error);
      return base;
    }
  }

  function saveState(force = false) {
    const now = Date.now();
    if (!force && now - lastSaved < 1000) return;
    lastSaved = now;
    try {
      localStorage.setItem(SAVE_KEY, JSON.stringify(state));
    } catch (error) {
      console.error("게임 진행 상황을 저장하지 못했습니다.", error);
      showToast("저장 공간에 접근할 수 없어요. 브라우저 설정을 확인해 주세요.");
    }
  }

  function safeMultiply(a, b) {
    if (a <= 0 || b <= 0) return 0;
    if (a >= MAX_VALUE / b) return MAX_VALUE;
    return finite(a * b, MAX_VALUE);
  }

  function safeAdd(a, b) {
    if (a >= MAX_VALUE - b) return MAX_VALUE;
    return finite(a + b, MAX_VALUE);
  }

  function stageName(stage = state.stage) {
    if (stage < EVOLUTIONS.length) return EVOLUTIONS[stage];
    const extra = stage - EVOLUTIONS.length + 1;
    return `${EVOLUTIONS[EVOLUTIONS.length - 1]} · ${formatNumber(extra)}회차`;
  }

  function throwReward() {
    const stageFactor = Math.pow(1.48, Math.min(state.stage, 850));
    const result = safeMultiply(Math.max(1, stageFactor), 1 + state.stage * 0.18);
    return result;
  }

  function upgradeCost() {
    const exponent = Math.min(state.stage, 850);
    return Math.max(10, safeMultiply(10, Math.pow(1.62, exponent)));
  }

  function autoCost() {
    return Math.max(100, safeMultiply(100, Math.pow(2.15, Math.min(state.autoLevel, 600))));
  }

  function formatNumber(value) {
    const n = finite(value);
    if (n < 1000) return Math.floor(n).toLocaleString("ko-KR");
    const units = [
      [1e16, "경"], [1e12, "조"], [1e8, "억"], [1e4, "만"]
    ];
    for (const [size, label] of units) {
      if (n >= size) {
        const amount = n / size;
        if (amount < 1000) return `${trimDecimal(amount)}${label}`;
      }
    }
    return n.toExponential(2).replace(/\.?0+e/, "e").replace("e+", "e");
  }

  function trimDecimal(value) {
    return value >= 100 ? value.toFixed(0) : value >= 10 ? value.toFixed(1).replace(/\.0$/, "") : value.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
  }

  function updateUI() {
    const reward = throwReward();
    const cost = upgradeCost();
    const autoPrice = autoCost();
    ui.name.textContent = stageName();
    ui.stage.textContent = `${formatNumber(state.stage + 1)}단계`;
    ui.power.textContent = formatNumber(state.power);
    ui.reward.textContent = `+${formatNumber(reward)}`;
    ui.cost.textContent = formatNumber(cost);
    ui.autoStatus.textContent = state.autoLevel ? `레벨 ${formatNumber(state.autoLevel)}` : "꺼짐";
    ui.throwHint.textContent = state.autoLevel ? "던지면 파워 획득!" : "힘껏 날려!";
    ui.upgradeHint.textContent = `${formatNumber(cost)} 파워`;
    ui.upgradeButton.disabled = state.power < cost;
    ui.autoButton.disabled = state.power < autoPrice;
    ui.autoTitle.textContent = state.autoLevel ? `자동 강화 Lv.${formatNumber(state.autoLevel)}` : "자동 던지기";
    ui.autoHint.textContent = `구매: ${formatNumber(autoPrice)} 파워`;
    ui.flavor.textContent = flavorText();
  }

  function flavorText() {
    if (state.stage < 4) return "아직은 얌전한 돌이다.";
    if (state.stage < 10) return "이 돌, 세탁기에서 나온 것 같다.";
    if (state.stage < 20) return "주변 중력이 눈치를 보기 시작했다.";
    if (state.stage < 30) return "이제 돌인지 우주적 민원인지 모르겠다.";
    return "현실이 돌에게 자리를 양보했다.";
  }

  function showToast(text) {
    ui.toast.textContent = text;
    ui.toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => ui.toast.classList.remove("show"), 2100);
  }

  function showMessage(text) {
    ui.floating.textContent = text;
    ui.floating.classList.remove("show");
    void ui.floating.offsetWidth;
    ui.floating.classList.add("show");
  }

  function playTone(frequency, duration, type = "triangle", volume = 0.06) {
    if (!animation.sound) return;
    try {
      audioContext = audioContext || new (window.AudioContext || window.webkitAudioContext)();
      if (audioContext.state === "suspended") audioContext.resume();
      const oscillator = audioContext.createOscillator();
      const gain = audioContext.createGain();
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(Math.max(45, frequency * 0.55), audioContext.currentTime + duration);
      gain.gain.setValueAtTime(volume, audioContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
      oscillator.connect(gain);
      gain.connect(audioContext.destination);
      oscillator.start();
      oscillator.stop(audioContext.currentTime + duration);
    } catch (error) {
      console.warn("효과음을 재생하지 못했습니다.", error);
      animation.sound = false;
      ui.sound.textContent = "🔇";
    }
  }

  function throwStone(isAuto = false) {
    const gain = throwReward();
    state.power = safeAdd(state.power, gain);
    animation.throwAt = performance.now();
    animation.impactAt = performance.now() + 620;
    updateUI();
    saveState();
    if (!isAuto) {
      showMessage(`+${formatNumber(gain)} 파워!`);
      playTone(210, 0.28, "triangle");
    }
  }

  function upgradeStone() {
    const cost = upgradeCost();
    if (state.power < cost) {
      showToast("돌 파워가 부족해요. 먼저 돌을 던져 주세요!");
      return;
    }
    state.power = Math.max(0, state.power - cost);
    state.stage = Math.min(Number.MAX_SAFE_INTEGER, state.stage + 1);
    animation.shake = performance.now();
    updateUI();
    saveState(true);
    ui.shell.classList.remove("shake");
    void ui.shell.offsetWidth;
    ui.shell.classList.add("shake");
    ui.arena.classList.remove("impact");
    void ui.arena.offsetWidth;
    ui.arena.classList.add("impact");
    scatterParticles(26);
    showMessage("돌 진화!!");
    playTone(480, 0.42, "sawtooth", 0.045);
  }

  function buyAuto() {
    const cost = autoCost();
    if (state.power < cost) {
      showToast("자동 던지기 구매 파워가 부족해요!");
      return;
    }
    state.power = Math.max(0, state.power - cost);
    state.autoLevel = Math.min(1000, state.autoLevel + 1);
    updateUI();
    saveState(true);
    showToast(`자동 던지기 레벨 ${formatNumber(state.autoLevel)}! 이제 알아서 던져요.`);
    playTone(350, 0.2, "square", 0.035);
  }

  function scatterParticles(count) {
    const rect = ui.arena.getBoundingClientRect();
    const centerX = rect.width * (0.48 + Math.random() * 0.04);
    const centerY = rect.height * 0.58;
    const colors = ["#ffe06c", "#fff8dc", "#ff8b68", "#72bca4", "#e89bcc"];
    for (let i = 0; i < count; i++) {
      const particle = document.createElement("i");
      const angle = Math.random() * Math.PI * 2;
      const distance = 35 + Math.random() * Math.min(rect.width * 0.55, 160);
      particle.className = "particle";
      particle.style.left = `${centerX}px`;
      particle.style.top = `${centerY}px`;
      particle.style.background = colors[Math.floor(Math.random() * colors.length)];
      particle.style.setProperty("--dx", `${Math.cos(angle) * distance}px`);
      particle.style.setProperty("--dy", `${Math.sin(angle) * distance - 20}px`);
      ui.particles.appendChild(particle);
      particle.addEventListener("animationend", () => particle.remove(), { once: true });
    }
  }

  function seededRandom(seed) {
    let value = seed >>> 0;
    return () => {
      value = (value * 1664525 + 1013904223) >>> 0;
      return value / 4294967296;
    };
  }

  function drawStone(now) {
    const rect = ui.canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const width = Math.max(1, Math.floor(rect.width * dpr));
    const height = Math.max(1, Math.floor(rect.height * dpr));
    if (ui.canvas.width !== width || ui.canvas.height !== height) {
      ui.canvas.width = width;
      ui.canvas.height = height;
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, rect.width, rect.height);

    const stage = state.stage;
    const scaleProgress = Math.min(stage, 35);
    const baseSize = Math.min(rect.width * 0.39, rect.height * 0.33);
    const sizeMultiplier = 1 + scaleProgress * 0.045 + Math.pow(scaleProgress, 1.35) * 0.012;
    const radiusX = Math.min(rect.width * 0.47, baseSize * sizeMultiplier);
    const radiusY = Math.min(rect.height * 0.37, baseSize * 0.72 * sizeMultiplier);
    const centerX = rect.width * 0.5;
    const groundY = rect.height * 0.76;
    const elapsed = now / 1000;
    const throwing = animation.throwAt && now - animation.throwAt < 660;
    let x = centerX;
    let y = groundY - radiusY * 0.72 + Math.sin(elapsed * 2.2) * Math.min(4, stage * 0.15);
    let rotation = Math.sin(elapsed * 1.4) * Math.min(.06, stage * .002);
    let drawScale = 1;

    if (throwing) {
      const t = Math.max(0, Math.min(1, (now - animation.throwAt) / 660));
      x = centerX + (t - .5) * rect.width * .56;
      y = groundY - radiusY * .72 - Math.sin(t * Math.PI) * Math.min(rect.height * .5, 100 + stage * 5);
      rotation += t * Math.PI * 4;
      drawScale = 1 - Math.sin(t * Math.PI) * .08;
      if (t > .85 && now - animation.impactAt < 240) {
        const hit = Math.max(0, 1 - (now - animation.impactAt) / 240);
        drawScale *= 1 + Math.sin(hit * Math.PI) * .14;
        drawImpact(ctx, centerX, groundY - 2, hit, rect.width);
      }
    }

    ctx.save();
    ctx.globalAlpha = .22;
    ctx.fillStyle = "#395b45";
    ctx.beginPath();
    ctx.ellipse(centerX, groundY + 2, Math.max(18, radiusX * .72), Math.max(5, radiusY * .18), 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.scale(drawScale, drawScale);
    drawRock(ctx, radiusX, radiusY, stage);
    ctx.restore();
    drawStars(ctx, rect.width, rect.height, stage, elapsed);
    animation.bob = now;
    requestAnimationFrame(drawStone);
  }

  function drawImpact(context, x, y, strength, width) {
    context.save();
    context.globalAlpha = strength * .65;
    context.strokeStyle = "#fff1a6";
    context.lineWidth = 3;
    for (let i = 0; i < 3; i++) {
      context.beginPath();
      context.ellipse(x, y, 20 + i * 17 + (1 - strength) * 20, 5 + i * 4, 0, Math.PI, Math.PI * 2);
      context.stroke();
    }
    for (let i = 0; i < 5; i++) {
      const a = i * Math.PI * 2 / 5;
      context.beginPath();
      context.moveTo(x + Math.cos(a) * 18, y + Math.sin(a) * 6);
      context.lineTo(x + Math.cos(a) * (35 + width * .025), y + Math.sin(a) * 18 - 6);
      context.stroke();
    }
    context.restore();
  }

  function drawRock(context, rx, ry, stage) {
    const palette = PALETTES[stage % PALETTES.length];
    const random = seededRandom((stage + 1) * 2917);
    const count = 9 + (stage % 6);
    const points = [];
    const shapeVariant = stage % 8;
    for (let i = 0; i < count; i++) {
      const angle = -Math.PI / 2 + i * Math.PI * 2 / count;
      let shape = .79 + random() * .34;
      if (shapeVariant === 0 && i % 3 === 0) shape *= 1.18;
      if (shapeVariant === 1) shape *= i % 2 ? 1.18 : .77;
      if (shapeVariant === 2) shape *= .72 + Math.abs(Math.sin(angle * 2)) * .6;
      if (shapeVariant === 3) shape *= .88 + Math.abs(Math.cos(angle * 3)) * .35;
      if (shapeVariant === 4 && i === 2) shape *= 1.45;
      if (shapeVariant === 5) shape *= .86 + (Math.sin(angle * 3) + 1) * .17;
      if (shapeVariant === 6) shape *= i % 2 ? .72 : 1.28;
      if (shapeVariant === 7) shape *= .85 + random() * .3;
      points.push({ x: Math.cos(angle) * rx * shape, y: Math.sin(angle) * ry * shape });
    }

    const gradient = context.createLinearGradient(-rx, -ry, rx * .7, ry);
    gradient.addColorStop(0, palette[1]);
    gradient.addColorStop(.52, palette[0]);
    gradient.addColorStop(1, palette[2]);
    context.save();
    context.lineJoin = "round";
    context.lineWidth = Math.max(2, rx * .025);
    context.strokeStyle = "#40362f";
    context.fillStyle = gradient;
    context.beginPath();
    context.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) context.lineTo(points[i].x, points[i].y);
    context.closePath();
    context.fill();
    context.stroke();

    context.save();
    context.clip();
    drawPattern(context, rx, ry, stage, palette, random);
    drawHighlight(context, rx, ry);
    context.restore();
    drawFace(context, rx, ry, stage);
    drawAccessory(context, rx, ry, stage, palette);
    context.restore();
  }

  function drawPattern(context, rx, ry, stage, palette, random) {
    const pattern = PATTERNS[stage % PATTERNS.length];
    const amount = 5 + stage % 8;
    context.globalAlpha = .48;
    context.lineWidth = Math.max(1.5, rx * .018);
    context.strokeStyle = palette[2];
    context.fillStyle = palette[1];
    if (pattern === "stripes") {
      context.lineWidth = Math.max(4, rx * .075);
      for (let i = -3; i <= 3; i++) {
        context.beginPath();
        context.moveTo(-rx + i * rx * .4, -ry);
        context.lineTo(-rx * .2 + i * rx * .4, ry);
        context.stroke();
      }
    } else if (pattern === "cracks") {
      for (let i = 0; i < 5; i++) {
        const x = (random() - .5) * rx;
        const y = (random() - .5) * ry;
        context.beginPath();
        context.moveTo(x, y);
        context.lineTo(x + (random() - .5) * rx * .45, y + ry * .22);
        context.lineTo(x + (random() - .5) * rx * .6, y + ry * .36);
        context.stroke();
      }
    } else {
      for (let i = 0; i < amount; i++) {
        const x = (random() - .5) * rx * 1.45;
        const y = (random() - .5) * ry * 1.25;
        const r = Math.max(2, rx * (.025 + random() * .07));
        context.beginPath();
        if (pattern === "swirl") {
          context.arc(x, y, r * 1.8, random() * 3, random() * 5 + 3);
          context.stroke();
        } else {
          context.ellipse(x, y, r, r * (.6 + random()), random(), 0, Math.PI * 2);
          if (pattern === "stars" && i % 2 === 0) {
            context.fillStyle = "#fff2b2";
            context.fill();
          } else if (pattern === "speckles") {
            context.fill();
          } else context.stroke();
        }
      }
    }
    context.globalAlpha = 1;
  }

  function drawHighlight(context, rx, ry) {
    context.globalAlpha = .25;
    context.fillStyle = "#fff";
    context.beginPath();
    context.ellipse(-rx * .25, -ry * .42, rx * .35, ry * .16, -.35, 0, Math.PI * 2);
    context.fill();
    context.globalAlpha = 1;
  }

  function drawFace(context, rx, ry, stage) {
    const eyeY = -ry * .05;
    const spacing = rx * .25;
    const eyeRadius = Math.max(2.5, Math.min(8, rx * .075));
    const sillyFace = stage % 5;
    context.save();
    context.strokeStyle = "#302822";
    context.fillStyle = "#302822";
    context.lineWidth = Math.max(1.5, rx * .025);
    if (sillyFace === 3) {
      context.beginPath();
      context.ellipse(-spacing, eyeY, eyeRadius * 1.5, eyeRadius * .55, 0, 0, Math.PI * 2);
      context.stroke();
      context.beginPath();
      context.arc(spacing, eyeY, eyeRadius, 0, Math.PI * 2);
      context.fill();
    } else {
      for (const side of [-1, 1]) {
        context.beginPath();
        context.arc(side * spacing, eyeY, eyeRadius, 0, Math.PI * 2);
        context.fill();
      }
    }
    context.fillStyle = "#fff7dc";
    context.beginPath();
    context.ellipse(-spacing - eyeRadius * .22, eyeY - eyeRadius * .22, eyeRadius * .25, eyeRadius * .25, 0, 0, Math.PI * 2);
    context.fill();
    if (sillyFace === 1) {
      context.beginPath();
      context.arc(0, ry * .2, rx * .09, 0, Math.PI * 2);
      context.fillStyle = "#523039";
      context.fill();
    } else if (sillyFace === 4) {
      context.beginPath();
      context.moveTo(-rx * .12, ry * .2);
      context.lineTo(0, ry * .27);
      context.lineTo(rx * .13, ry * .18);
      context.stroke();
    } else {
      context.beginPath();
      context.arc(0, ry * .12, rx * .12, .15, Math.PI - .15);
      context.stroke();
    }
    context.restore();
  }

  function drawAccessory(context, rx, ry, stage, palette) {
    const kind = Math.floor(stage / 2) % 7;
    context.save();
    context.lineWidth = Math.max(2, rx * .025);
    context.strokeStyle = "#40362f";
    context.fillStyle = palette[1];
    if (kind === 1) {
      context.beginPath();
      context.moveTo(-rx * .4, -ry * .55);
      context.lineTo(-rx * .13, -ry * .93);
      context.lineTo(rx * .05, -ry * .53);
      context.closePath();
      context.fill();
      context.stroke();
    } else if (kind === 2) {
      context.fillStyle = "#ed7c68";
      context.fillRect(-rx * .36, -ry * .72, rx * .72, ry * .12);
      context.beginPath();
      context.moveTo(0, -ry * .6);
      context.lineTo(-rx * .12, -ry * .39);
      context.lineTo(rx * .12, -ry * .39);
      context.closePath();
      context.fill();
      context.stroke();
    } else if (kind === 3) {
      context.fillStyle = "#f4d265";
      context.beginPath();
      context.ellipse(0, -ry * .7, rx * .29, ry * .12, 0, Math.PI, 0);
      context.lineTo(rx * .29, -ry * .65);
      context.lineTo(-rx * .29, -ry * .65);
      context.closePath();
      context.fill();
      context.stroke();
    } else if (kind === 4) {
      context.strokeStyle = "#bdefff";
      context.lineWidth = Math.max(2, rx * .045);
      context.beginPath();
      context.ellipse(0, -ry * .08, rx * .75, ry * .43, -.25, 0, Math.PI * 2);
      context.stroke();
    } else if (kind === 5) {
      context.fillStyle = "#6c436f";
      context.beginPath();
      context.moveTo(-rx * .15, -ry * .48);
      context.lineTo(0, -ry * .9);
      context.lineTo(rx * .15, -ry * .48);
      context.closePath();
      context.fill();
      context.stroke();
    } else if (kind === 6) {
      context.font = `${Math.max(13, Math.min(27, rx * .25))}px sans-serif`;
      context.textAlign = "center";
      context.fillText("✦", rx * .64, -ry * .45);
      context.fillText("✦", -rx * .68, ry * .1);
    }
    context.restore();
  }

  function drawStars(context, width, height, stage, time) {
    if (stage < 10) return;
    const count = Math.min(12, Math.floor(stage / 2));
    context.save();
    context.fillStyle = "#fff8b0";
    context.globalAlpha = .45 + Math.sin(time * 2) * .15;
    for (let i = 0; i < count; i++) {
      const x = ((i * 83 + stage * 19) % Math.max(1, width));
      const y = 35 + ((i * 47 + stage * 13) % Math.max(1, height * .48));
      const r = 1.4 + (i % 3);
      context.beginPath();
      context.arc(x, y, r, 0, Math.PI * 2);
      context.fill();
    }
    context.restore();
  }

  ui.throwButton.addEventListener("click", () => throwStone());
  ui.upgradeButton.addEventListener("click", upgradeStone);
  ui.autoButton.addEventListener("click", buyAuto);
  ui.canvas.addEventListener("click", () => {
    if (!animation.throwAt || performance.now() - animation.throwAt > 660) throwStone();
  });
  ui.sound.addEventListener("click", () => {
    animation.sound = !animation.sound;
    ui.sound.textContent = animation.sound ? "🔊" : "🔇";
    ui.sound.setAttribute("aria-label", animation.sound ? "효과음 끄기" : "효과음 켜기");
    ui.sound.title = animation.sound ? "효과음 끄기" : "효과음 켜기";
    if (animation.sound) playTone(420, .12);
  });
  window.addEventListener("pagehide", () => saveState(true));
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) saveState(true);
    lastAuto = performance.now();
  });

  function tick(now) {
    if (state.autoLevel > 0) {
      const interval = Math.max(160, 1100 / Math.sqrt(state.autoLevel));
      if (now - lastAuto >= interval) {
        lastAuto = now;
        throwStone(true);
      }
    }
    requestAnimationFrame(tick);
  }

  updateUI();
  requestAnimationFrame(drawStone);
  requestAnimationFrame(tick);
})();
