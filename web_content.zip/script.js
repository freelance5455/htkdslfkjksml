const input=document.getElementById('input'),output=document.getElementById('output');
const from=document.getElementById('from'),to=document.getElementById('to'),status=document.getElementById('status');
document.getElementById('swap').onclick=()=>{[from.value,to.value]=[to.value,from.value];[input.value,output.value]=[output.value,input.value]};
document.getElementById('translate').onclick=async()=>{
 const text=input.value.trim(); if(!text){status.textContent='اكتب نصاً أولاً';return}
 status.textContent='جارٍ الترجمة...'; output.value='';
 try{
  const url='https://api.mymemory.translated.net/get?q='+encodeURIComponent(text)+'&langpair='+from.value+'|'+to.value;
  const r=await fetch(url); const d=await r.json();
  if(!d.responseData || !d.responseData.translatedText) throw new Error();
  output.value=d.responseData.translatedText; status.textContent='تمت الترجمة';
 }catch(e){status.textContent='تعذر الاتصال بخدمة الترجمة. تحقق من الإنترنت.'}
};
document.getElementById('copy').onclick=async()=>{
 if(!output.value)return;
 try{await navigator.clipboard.writeText(output.value);status.textContent='تم النسخ ✓'}
 catch(e){status.textContent='تعذر النسخ'}
};