"use strict";

const STORAGE_KEY="dailyEmployeeAttendance_v9";
const REMEMBER_KEY="dailyAttendanceRemember_v1";
const $=id=>document.getElementById(id);
const pad=n=>String(n).padStart(2,"0");

function localDate(d=new Date()){
 return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
}

function displayTime(d=new Date()){
 return d.toLocaleTimeString([],{
  hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:true
 });
}

function escapeHTML(v){
 return String(v??"").replace(/[&<>"']/g,c=>({
  "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
 }[c]));
}

function initialState(){
 return {
  adminPassword:"admin123",
  employees:[
   {id:"EMP001",name:"Ali",position:"",password:"ali123"},
   {id:"EMP002",name:"Aslam",position:"",password:"aslam123"}
  ],
  records:[]
 };
}

let state;
try{
 const stored=localStorage.getItem(STORAGE_KEY);
 state=stored?JSON.parse(stored):initialState();
 if(!state||!Array.isArray(state.employees)||!Array.isArray(state.records))
  state=initialState();
}catch(e){state=initialState()}

if(!state.adminPassword)state.adminPassword="admin123";

state.records.forEach(r=>{
 if(!r.status)r.status=r.timeIn||r.timeOut?"Present":"";
});

function save(){
 try{
  localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
  return true;
 }catch(e){
  alert("Unable to save. Browser storage may be full.");
  return false;
 }
}

function employeeById(id){
 return state.employees.find(e=>e.id===id);
}

function getRecord(id,date){
 return state.records.find(r=>r.employeeId===id&&r.date===date);
}

let loginRole="";
let loggedEmployeeId="";

function getRemembered(){
 try{return JSON.parse(localStorage.getItem(REMEMBER_KEY)||"null")}
 catch(e){return null}
}

function saveRemembered(){
 if(!$("rememberMe").checked){
  localStorage.removeItem(REMEMBER_KEY);
  return;
 }
 localStorage.setItem(REMEMBER_KEY,JSON.stringify({
  role:loginRole,
  employeeId:loginRole==="employee"
   ?$("loginEmployeeId").value.trim().toUpperCase():""
 }));
}

function clearRemembered(){
 localStorage.removeItem(REMEMBER_KEY);
}

function showPage(id){
 ["welcomePage","rolePage","loginPage"].forEach(p=>{
  $(p).classList.toggle("hidden",p!==id);
 });
 $("app").classList.toggle("hidden",id!=="app");
}

function updateClock(){
 const now=new Date();
 $("clock").textContent=displayTime(now);
 $("todayLabel").textContent=now.toLocaleDateString(undefined,{
  weekday:"long",year:"numeric",month:"long",day:"numeric"
 });
 $("welcomeDate").textContent=$("todayLabel").textContent;
 if(loginRole==="employee"&&!$("app").classList.contains("hidden")){
  $("employeeTodayDate").textContent="Today's Attendance Date: "+localDate();
 }
}
setInterval(updateClock,1000);
updateClock();

function setupLogin(role){
 loginRole=role;
 $("loginPassword").value="";
 $("loginMessage").textContent="";
 $("loginMessage").className="loginMessage";
 $("loginPassword").type="password";
 $("loginTitle").textContent=role==="employee"?"Employee Login":"Admin Login";
 $("loginDescription").textContent=role==="employee"
  ?"Enter your Employee ID and password.":"Enter administrator password.";
 $("employeeLoginField").classList.toggle("hidden",role!=="employee");

 const remembered=getRemembered();
 $("rememberMe").checked=!!remembered&&remembered.role===role;
 $("loginEmployeeId").value=
  role==="employee"&&remembered&&remembered.role==="employee"
  ?remembered.employeeId||"":"";
 showPage("loginPage");
}

$("startBtn").onclick=()=>showPage("rolePage");
$("backWelcome").onclick=()=>showPage("welcomePage");
$("adminChoice").onclick=()=>setupLogin("admin");
$("employeeChoice").onclick=()=>setupLogin("employee");
$("backRole").onclick=()=>showPage("rolePage");

$("toggleLoginPassword").onclick=()=>{
 const p=$("loginPassword");
 p.type=p.type==="password"?"text":"password";
};

function login(){
 const password=$("loginPassword").value;

 if(loginRole==="admin"){
  if(password!==state.adminPassword){
   $("loginMessage").textContent="Incorrect admin password. Please try again.";
   $("loginMessage").className="loginMessage error";
   return;
  }
  loggedEmployeeId="";
  saveRemembered();
  openApp("admin");
 }else{
  const id=$("loginEmployeeId").value.trim().toUpperCase();
  const emp=employeeById(id);
  if(!emp||emp.password!==password){
   $("loginMessage").textContent="Incorrect Employee ID or password. Please try again.";
   $("loginMessage").className="loginMessage error";
   return;
  }
  loggedEmployeeId=id;
  saveRemembered();
  openApp("employee");
 }
}
$("loginBtn").onclick=login;
$("loginPassword").addEventListener("keydown",e=>{if(e.key==="Enter")login()});
$("loginEmployeeId").addEventListener("keydown",e=>{if(e.key==="Enter")login()});

function showNotice(text,type=""){
 $("message").textContent=text;
 $("message").className="notice"+(type?" "+type:"");
}

function openApp(role){
 showPage("app");
 $("accountLabel").textContent=role==="admin"
  ?"Administrator":employeeById(loggedEmployeeId)?.name||"Employee";
 $("accountRole").textContent=role==="admin"?"Admin Account":"Employee Account";

 const isAdmin=role==="admin";
 $("adminQuickNav").classList.toggle("hidden",!isAdmin);
 $("attendancePage").classList.toggle("hidden",isAdmin);
 $("employeeManagementPanel").classList.add("hidden");
 $("passwordPanel").classList.add("hidden");
 $("recordsPanel").classList.add("hidden");

 $("employeeSelect").disabled=!isAdmin;
 $("workDate").value=localDate();
 $("remarks").value="";
 $("attendanceDateField").classList.toggle("hidden",!isAdmin);
 $("remarksField").classList.toggle("hidden",!isAdmin);
 $("employeeTodayDate").classList.toggle("hidden",isAdmin);

 fillSelects();
 $("employeeSelect").value=isAdmin?(state.employees[0]?.id||""):loggedEmployeeId;

 if(isAdmin){
  renderEmployees();
  renderReports();
 }else{
  renderEmployeeAttendance();
 }
 refreshStats();
 updateClock();
}

function showAppPage(id){
 const pages=["adminQuickNav","attendancePage","employeeManagementPanel","passwordPanel","recordsPanel"];
 pages.forEach(p=>$(p).classList.toggle("hidden",p!==id));
 if(id==="employeeManagementPanel")renderEmployees();
 if(id==="recordsPanel")renderReports();
}

document.querySelectorAll("[data-page]").forEach(button=>{
 button.addEventListener("click",()=>showAppPage(button.dataset.page));
});

function currentEmployee(){
 return loginRole==="employee"?loggedEmployeeId:$("employeeSelect").value;
}

function fillSelects(){
 $("employeeSelect").innerHTML="";
 $("filterEmployee").innerHTML='<option value="all">All Employees</option>';
 state.employees.forEach(e=>{
  $("employeeSelect").add(new Option(e.name+" ("+e.id+")",e.id));
  $("filterEmployee").add(new Option(e.name+" ("+e.id+")",e.id));
 });
}

function hoursBetween(a,b){
 if(!a||!b)return 0;
 const start=new Date(a).getTime();
 const end=new Date(b).getTime();
 if(!Number.isFinite(start)||!Number.isFinite(end)||end<start)return 0;
 return (end-start)/3600000;
}

function hoursText(r){
 return r.timeIn&&r.timeOut?hoursBetween(r.timeIn,r.timeOut).toFixed(2):"0.00";
}

function renderEmployeeAttendance(){
 const id=loggedEmployeeId;
 const records=state.records
  .filter(r=>r.employeeId===id)
  .sort((a,b)=>b.date.localeCompare(a.date))
  .slice(0,30);

 $("attendancePreviewBody").innerHTML=records.length?records.map(r=>{
  const emp=employeeById(r.employeeId);
  return `<tr>
   <td>${escapeHTML(r.date)}</td>
   <td>${escapeHTML(r.employeeId)}</td>
   <td>${escapeHTML(emp?.name||"")}</td>
   <td>${escapeHTML(r.timeIn||"-")}</td>
   <td>${escapeHTML(r.timeOut||"-")}</td>
   <td>${hoursText(r)}</td>
   <td>${escapeHTML(r.status||"")}</td>
  </tr>`;
 }).join(""):'<tr><td colspan="7" class="center">No attendance records yet.</td></tr>';

 updateAttendanceButtons();
}

function updateAttendanceButtons(){
 const id=currentEmployee();
 const date=loginRole==="employee"?localDate():$("workDate").value;
 const r=getRecord(id,date);
 $("timeInBtn").disabled=!!(r&&(r.timeIn||r.status==="Leave"||r.status==="Holiday"));
 $("timeOutBtn").disabled=!!(r&&(r.timeOut||!r.timeIn||r.status==="Leave"||r.status==="Holiday"));
 $("leaveBtn").disabled=!!(r&&(r.timeIn||r.timeOut||r.status));
}

function recordAttendance(action){
 const id=currentEmployee();
 const emp=employeeById(id);
 if(!emp){showNotice("Please select an employee.","error");return}

 const date=loginRole==="employee"?localDate():$("workDate").value;
 if(!date){showNotice("Please select an attendance date.","error");return}
 if(date>localDate()){showNotice("Future attendance dates are not allowed.","error");return}

 let r=getRecord(id,date);
 const now=displayTime();

 if(action==="in"){
  if(r&&(r.timeIn||r.status==="Leave"||r.status==="Holiday")){
   showNotice("Today's attendance has already been entered.","error");return;
  }
  if(!r){
   r={employeeId:id,date,timeIn:"",timeOut:"",status:"Present",remarks:""};
   state.records.push(r);
  }
  r.timeIn=now;
  r.status="Present";
 }else if(action==="out"){
  if(!r||!r.timeIn){
   showNotice("Please record Time In first.","error");return;
  }
  if(r.timeOut){
   showNotice("Time Out has already been recorded today.","error");return;
  }
  r.timeOut=now;
  r.status="Present";
 }else{
  if(r&&(r.timeIn||r.timeOut||r.status)){
   showNotice("Attendance has already been entered for this date.","error");return;
  }
  const choice=prompt("Enter Leave or Holiday:");
  if(!choice)return;
  const status=choice.trim().toLowerCase();
  if(status!=="leave"&&status!=="holiday"){
   showNotice("Please enter Leave or Holiday.","error");return;
  }
  r={employeeId:id,date,timeIn:"",timeOut:"",status:status==="leave"?"Leave":"Holiday",remarks:""};
  state.records.push(r);
 }

 if(loginRole==="admin")r.remarks=$("remarks").value.trim();
 if(!save())return;

 showNotice(action==="in"?"Time In recorded: "+now:
  action==="out"?"Time Out recorded: "+now:
  "Attendance status recorded successfully.","success");

 renderEmployeeAttendance();
 renderReports();
 refreshStats();
 updateAttendanceButtons();
}

$("timeInBtn").onclick=()=>recordAttendance("in");
$("timeOutBtn").onclick=()=>recordAttendance("out");
$("leaveBtn").onclick=()=>recordAttendance("leave");
$("employeeSelect").onchange=()=>{
 renderEmployeeAttendance();
 updateAttendanceButtons();
};
$("workDate").onchange=updateAttendanceButtons;

function renderEmployees(){
 $("employeeList").innerHTML=state.employees.length?state.employees.map(e=>`
  <div class="employeeRow">
   <div>
    <strong>${escapeHTML(e.name)}</strong><br>
    <span class="muted">${escapeHTML(e.id)} · ${escapeHTML(e.position||"Employee")}</span>
   </div>
   <button class="danger" data-delete-employee="${escapeHTML(e.id)}">Delete</button>
  </div>
 `).join(""):"<p>No employees found.</p>";

 document.querySelectorAll("[data-delete-employee]").forEach(btn=>{
  btn.onclick=()=>{
   const id=btn.dataset.deleteEmployee;
   if(!confirm("Delete this employee and all their attendance records?"))return;
   state.employees=state.employees.filter(e=>e.id!==id);
   state.records=state.records.filter(r=>r.employeeId!==id);
   if(!save())return;
   fillSelects();
   renderEmployees();
   renderReports();
  };
 });
}

$("addEmployeeBtn").onclick=()=>{
 const name=$("newName").value.trim();
 const position=$("newPosition").value.trim();
 const password=$("newPassword").value;

 if(!name||!password){
  alert("Enter employee name and password.");return;
 }
 if(password.length<4){
  alert("Password must contain at least 4 characters.");return;
 }

 const next=state.employees.reduce((max,e)=>{
  const n=parseInt(e.id.replace(/\D/g,""),10);
  return Number.isFinite(n)?Math.max(max,n):max;
 },0)+1;

 const id="EMP"+String(next).padStart(3,"0");
 state.employees.push({id,name,position,password});
 if(!save())return;

 $("newName").value="";
 $("newPosition").value="";
 $("newPassword").value="";
 fillSelects();
 renderEmployees();
 alert("Employee added successfully. Employee ID: "+id);
};

$("changeAdminPasswordBtn").onclick=()=>{
 const old=$("oldAdminPassword").value;
 const pass=$("newAdminPassword").value;
 const confirmPass=$("confirmAdminPassword").value;

 if(old!==state.adminPassword){
  $("passwordMessage").textContent="Current password is incorrect.";
  $("passwordMessage").className="notice error";return;
 }
 if(pass.length<4){
  $("passwordMessage").textContent="New password must contain at least 4 characters.";
  $("passwordMessage").className="notice error";return;
 }
 if(pass!==confirmPass){
  $("passwordMessage").textContent="New passwords do not match.";
  $("passwordMessage").className="notice error";return;
 }

 state.adminPassword=pass;
 if(!save())return;

 $("oldAdminPassword").value="";
 $("newAdminPassword").value="";
 $("confirmAdminPassword").value="";
 $("passwordMessage").textContent="Admin password changed successfully.";
 $("passwordMessage").className="notice success";
};

function reportRecords(){
 const filter=$("filterEmployee").value;
 const days=$("filterDays").value;
 const cutoff=new Date();
 cutoff.setDate(cutoff.getDate()-30);
 const minDate=localDate(cutoff);

 return state.records.filter(r=>{
  const matchEmployee=filter==="all"||r.employeeId===filter;
  const matchDays=days==="all"||r.date>=minDate;
  return matchEmployee&&matchDays;
 }).sort((a,b)=>b.date.localeCompare(a.date));
}

function renderReports(){
 if(!$("recordsBody"))return;
 const records=reportRecords();

 $("recordsBody").innerHTML=records.length?records.map((r,index)=>{
  const emp=employeeById(r.employeeId);
  return `<tr>
   <td>${escapeHTML(r.date)}</td>
   <td>${escapeHTML(r.employeeId)}</td>
   <td>${escapeHTML(emp?.name||"Deleted Employee")}</td>
   <td>${escapeHTML(r.timeIn||"-")}</td>
   <td>${escapeHTML(r.timeOut||"-")}</td>
   <td>${hoursText(r)}</td>
   <td>${escapeHTML(r.status||"")}</td>
   <td>${escapeHTML(r.remarks||"")}</td>
   <td><button class="danger" data-delete-record="${index}">Delete</button></td>
  </tr>`;
 }).join(""):'<tr><td colspan="9" class="center">No records found.</td></tr>';

 document.querySelectorAll("[data-delete-record]").forEach(btn=>{
  btn.onclick=()=>{
   const record=records[Number(btn.dataset.deleteRecord)];
   if(!confirm("Delete this attendance record?"))return;
   state.records=state.records.filter(r=>r!==record);
   if(!save())return;
   renderReports();
   renderEmployeeAttendance();
   refreshStats();
  };
 });
}

$("filterEmployee").onchange=renderReports;
$("filterDays").onchange=renderReports;

function refreshStats(){
 // Statistics are intentionally not displayed on the employee page.
 // This function is retained for compatibility with the app.
}

function downloadCSV(filename,rows){
 const csv=rows.map(row=>row.map(value=>{
  const s=String(value??"");
  return '"'+s.replace(/"/g,'""')+'"';
 }).join(",")).join("\r\n");

 const blob=new Blob(["\uFEFF"+csv],{type:"text/csv;charset=utf-8;"});
 const url=URL.createObjectURL(blob);
 const a=document.createElement("a");
 a.href=url;
 a.download=filename;
 document.body.appendChild(a);
 a.click();
 a.remove();
 URL.revokeObjectURL(url);
}

$("exportAttendance").onclick=()=>{
 const rows=[["Date","Employee ID","Name","Time In","Time Out","Hours","Status","Remarks"]];
 reportRecords().forEach(r=>{
  rows.push([
   r.date,r.employeeId,employeeById(r.employeeId)?.name||"",
   r.timeIn||"",r.timeOut||"",hoursText(r),r.status||"",r.remarks||""
  ]);
 });
 downloadCSV("Attendance_Report.csv",rows);
};

$("exportEmployees").onclick=()=>{
 const rows=[["Employee ID","Name","Position"]];
 state.employees.forEach(e=>rows.push([e.id,e.name,e.position]));
 downloadCSV("Employee_List.csv",rows);
};

$("printBtn").onclick=()=>window.print();

function logout(){
 clearRemembered();
 loginRole="";
 loggedEmployeeId="";
 $("loginPassword").value="";
 $("loginEmployeeId").value="";
 showPage("welcomePage");
}

$("logoutBtn").onclick=logout;
$("dashboardLogoutBtn").onclick=logout;

fillSelects();
showPage("welcomePage");
