const chat=document.getElementById('chat');const message=document.getElementById('message');const history=document.getElementById('history');
function toggleSidebar(){document.getElementById('sidebar').classList.toggle('open')}
function toggleTheme(){document.body.classList.toggle('dark')}
function addMessage(text,role){const el=document.createElement('div');el.className='message '+role;el.textContent=text;chat.appendChild(el);chat.scrollTop=chat.scrollHeight;return el}
function sendMessage(){const text=message.value.trim();if(!text)return;document.getElementById('welcome')?.remove();addMessage(text,'user');message.value='';history.innerHTML+='<div>'+escapeHtml(text.slice(0,35))+'</div>';setTimeout(()=>addMessage('This is the KIGO AI interface prototype. Connect a secure AI backend/API to generate real answers.', 'assistant'),400)}
function useSuggestion(text){message.value=text;sendMessage()}
function newChat(){chat.innerHTML='<div class="welcome" id="welcome"><div class="logo-mark">✦</div><h1>How can I help you today?</h1><p>Ask KIGO AI anything.</p></div>';document.getElementById('pageTitle').textContent='KIGO AI'}
function showFeature(name){document.getElementById('pageTitle').textContent=name;document.getElementById('welcome')?.remove();addMessage(name+' section selected. This is a frontend prototype; connect the required secure service to enable this feature.','assistant')}
function handleKey(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
