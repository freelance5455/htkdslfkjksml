
// ==========================================
// GREEN CONSTRUCTION
// MONTHLY RECORDS MANAGEMENT SYSTEM
// ==========================================

const STORAGE_KEY = "green_construction_worker_data";
const RECORDS_KEY = "green_construction_monthly_records";
const ACTIVE_KEY = "green_construction_active_month";

const workerTableBody = document.getElementById("workerTableBody");
const dateInput = document.getElementById("date");

const recordsSelect = document.getElementById("recordsSelect");
const recordsStatus = document.getElementById("recordsStatus");

let records = {};
let activeRecordId = "";


// 1. DATE HELPERS

function setTodayDate() {
    const today = new Date();
    dateInput.value = [
        today.getFullYear(),
        String(today.getMonth() + 1).padStart(2, "0"),
        String(today.getDate()).padStart(2, "0")
    ].join("-");
}

function getRecordId(month, date) {
    const year = date ? date.slice(0, 4) : new Date().getFullYear();
    return `${month.trim().toUpperCase()}-${year}`;
}


// 2. GENERATE WORKER ROWS

function generateWorkerRows() {
    workerTableBody.innerHTML = "";

    for (let i = 1; i <= 25; i++) {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${i}</td>
            <td><input type="text" class="worker-name"></td>
            <td><input type="number" class="present" min="0" step="any"></td>
            <td><input type="number" class="rate" min="0" step="any"></td>
            <td><input type="number" class="total-amount" readonly></td>
            <td><input type="number" class="advance" min="0" step="any"></td>
            <td><input type="number" class="due-balance" readonly></td>
            <td><input type="tel" class="mobile-number" maxlength="10"></td>
        `;

        workerTableBody.appendChild(row);
    }
}


// 3. CALCULATIONS

function calculateRow(row) {
    const present = Number(row.querySelector(".present").value) || 0;
    const rate = Number(row.querySelector(".rate").value) || 0;
    const advance = Number(row.querySelector(".advance").value) || 0;

    row.querySelector(".total-amount").value =
        (present * rate).toFixed(2);

    row.querySelector(".due-balance").value =
        (present * rate - advance).toFixed(2);
}


// 4. COLLECT FORM DATA

function collectData() {
    const workers = [];

    workerTableBody.querySelectorAll("tr").forEach(row => {
        workers.push({
            name: row.querySelector(".worker-name").value,
            present: row.querySelector(".present").value,
            rate: row.querySelector(".rate").value,
            advance: row.querySelector(".advance").value,
            mobile: row.querySelector(".mobile-number").value
        });
    });

    return {
        location: document.getElementById("location").value,
        month: document.getElementById("month").value,
        foreman: document.getElementById("foreman").value,
        date: dateInput.value,
        workers: workers
    };
}


// 5. RESTORE FORM DATA

function restoreData(data) {
    document.getElementById("location").value =
        data.location ?? "JOGESWARY";

    document.getElementById("month").value =
        data.month ?? "";

    document.getElementById("foreman").value =
        data.foreman ?? "JIYARUL HAQUE";

    dateInput.value = data.date || dateInput.value;

    generateWorkerRows();

    if (Array.isArray(data.workers)) {
        const rows = workerTableBody.querySelectorAll("tr");

        rows.forEach((row, index) => {
            const worker = data.workers[index];
            if (!worker) return;

            row.querySelector(".worker-name").value = worker.name ?? "";
            row.querySelector(".present").value = worker.present ?? "";
            row.querySelector(".rate").value = worker.rate ?? "";
            row.querySelector(".advance").value = worker.advance ?? "";
            row.querySelector(".mobile-number").value = worker.mobile ?? "";

            calculateRow(row);
        });
    }
}


// 6. AUTO SAVE CURRENT MONTH

function autoSave() {
    if (!activeRecordId) return;

    const data = collectData();

    records[activeRecordId] = data;

    try {
        localStorage.setItem(RECORDS_KEY, JSON.stringify(records));
        localStorage.setItem(ACTIVE_KEY, activeRecordId);
        localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        updateRecordsList();
        recordsStatus.textContent = "Auto-saved: " + activeRecordId;
    } catch (error) {
        recordsStatus.textContent = "Storage error! Please export your backup.";
        console.error(error);
    }
}


// DASHBOARD SUMMARY

function formatDashboardCurrency(value) {
    return new Intl.NumberFormat("en-IN", {
        style: "currency",
        currency: "INR",
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(value || 0);
}

function updateDashboard() {
    const allRecords = Object.entries(records || {});
    let workerEntries = 0;
    let totalCost = 0;
    let totalAdvance = 0;
    let totalDue = 0;

    const monthlyTotals = allRecords.map(([id, data]) => {
        let monthCost = 0;

        (Array.isArray(data.workers) ? data.workers : []).forEach(worker => {
            const present = Number(worker.present) || 0;
            const rate = Number(worker.rate) || 0;
            const advance = Number(worker.advance) || 0;
            const cost = present * rate;

            if (String(worker.name || "").trim()) workerEntries++;

            monthCost += cost;
            totalCost += cost;
            totalAdvance += advance;
            totalDue += cost - advance;
        });

        return {
            id,
            label: String(data.month || id).toUpperCase(),
            date: data.date || "",
            cost: monthCost
        };
    });

    document.getElementById("dashboardWorkers").textContent = workerEntries.toLocaleString("en-IN");
    document.getElementById("dashboardCost").textContent = formatDashboardCurrency(totalCost);
    document.getElementById("dashboardAdvance").textContent = formatDashboardCurrency(totalAdvance);
    document.getElementById("dashboardDue").textContent = formatDashboardCurrency(totalDue);

    const chart = document.getElementById("monthlyCostChart");
    chart.innerHTML = "";

    if (!monthlyTotals.length) {
        const empty = document.createElement("p");
        empty.className = "dashboard-empty";
        empty.textContent = "Your monthly cost chart will appear after records are saved.";
        chart.appendChild(empty);
        return;
    }

    monthlyTotals.sort((a, b) => {
        const dateA = a.date ? new Date(a.date + "T00:00:00").getTime() : 0;
        const dateB = b.date ? new Date(b.date + "T00:00:00").getTime() : 0;
        return dateA - dateB || a.id.localeCompare(b.id);
    });

    const visibleMonths = monthlyTotals.slice(-6);
    const maximum = Math.max(...visibleMonths.map(item => item.cost), 1);

    visibleMonths.forEach(item => {
        const column = document.createElement("div");
        column.className = "chart-column";

        const amount = document.createElement("span");
        amount.className = "chart-amount";
        amount.textContent = formatDashboardCurrency(item.cost);

        const track = document.createElement("div");
        track.className = "chart-bar-track";

        const bar = document.createElement("div");
        bar.className = "chart-bar";
        bar.style.height = (item.cost > 0 ? Math.max(5, item.cost / maximum * 100) : 0) + "%";
        bar.title = item.id + ": " + formatDashboardCurrency(item.cost);

        const label = document.createElement("span");
        label.className = "chart-month";
        label.textContent = item.label;

        track.appendChild(bar);
        column.append(amount, track, label);
        chart.appendChild(column);
    });
}


// UPDATE SAVED RECORD LIST

function updateRecordsList() {
    const selected = recordsSelect.value;

    recordsSelect.innerHTML =
        '<option value="">SELECT SAVED MONTH</option>';

    Object.keys(records).sort().forEach(id => {
        const option = document.createElement("option");
        option.value = id;
        option.textContent = id;

        recordsSelect.appendChild(option);
    });

    if (records[selected]) {
        recordsSelect.value = selected;
    }

    updateDashboard();
}


// 8. SAVE CURRENT MONTH BUTTON

document.getElementById("saveMonthBtn").addEventListener("click", () => {
    const month = document.getElementById("month").value.trim();

    if (!month) {
        alert("Please enter a month name.");
        return;
    }

    const newId = getRecordId(month, dateInput.value);

    if (newId !== activeRecordId && records[newId]) {
        if (!confirm("This month already exists. Overwrite its saved record?")) {
            return;
        }
    }

    activeRecordId = newId;
    autoSave();

    alert("Monthly record saved successfully!");
});


// 9. NEW MONTH BUTTON

document.getElementById("newMonthBtn").addEventListener("click", () => {
    const monthName = prompt(
        "Enter new month and year (Example: DECEMBER 2026):"
    );

    if (!monthName || !monthName.trim()) return;

    const match = monthName.trim().match(/^([A-Za-z]+)\s+(\d{4})$/);

    if (!match) {
        alert("Please enter month and year, e.g. DECEMBER 2026.");
        return;
    }

    const month = match[1].toUpperCase();
    const year = Number(match[2]);

    if (year < 2000 || year > 2100) {
        alert("Please enter a valid year.");
        return;
    }

    const newId = `${month}-${year}`;

    if (records[newId]) {
        alert("This month's record already exists. Open it from the list.");
        return;
    }

    autoSave();

    activeRecordId = newId;

    restoreData({
        location: "JOGESWARY",
        month: month,
        foreman: "JIYARUL HAQUE",
        date: `${year}-01-01`,
        workers: []
    });

    // Set date to the first day of the selected month
    const monthNumbers = {
        JANUARY: "01", FEBRUARY: "02", MARCH: "03",
        APRIL: "04", MAY: "05", JUNE: "06",
        JULY: "07", AUGUST: "08", SEPTEMBER: "09",
        OCTOBER: "10", NOVEMBER: "11", DECEMBER: "12"
    };

    if (monthNumbers[month]) {
        dateInput.value = `${year}-${monthNumbers[month]}-01`;
    }

    autoSave();
    updateRecordsList();

    recordsStatus.textContent = "New month created: " + newId;
});


// 10. OPEN OLD MONTH

document.getElementById("loadMonthBtn").addEventListener("click", () => {
    const id = recordsSelect.value;

    if (!id || !records[id]) {
        alert("Please select a saved month.");
        return;
    }

    if (!confirm("Open " + id + "? Unsaved changes will be replaced.")) {
        return;
    }

    autoSave();

    activeRecordId = id;
    restoreData(records[id]);

    localStorage.setItem(ACTIVE_KEY, activeRecordId);
    recordsStatus.textContent = "Opened: " + id;
});


// 11. DELETE MONTH

document.getElementById("deleteMonthBtn").addEventListener("click", () => {
    const id = recordsSelect.value;

    if (!id || !records[id]) {
        alert("Please select a record to delete.");
        return;
    }

    if (!confirm("Permanently delete " + id + "?")) return;

    delete records[id];

    localStorage.setItem(RECORDS_KEY, JSON.stringify(records));

    if (activeRecordId === id) {
        activeRecordId = "";
        localStorage.removeItem(ACTIVE_KEY);
        localStorage.removeItem(STORAGE_KEY);

        restoreData({
            location: "JOGESWARY",
            month: "",
            foreman: "JIYARUL HAQUE",
            date: "",
            workers: []
        });

        setTodayDate();
    }

    updateRecordsList();
    recordsStatus.textContent = "Record deleted: " + id;
});


// 12. AUTO SAVE INPUT CHANGES

document.addEventListener("input", event => {
    const target = event.target;

    if (target.classList.contains("mobile-number")) {
        target.value = target.value.replace(/\D/g, "");
    }

    const row = target.closest("tr");

    if (row && (
        target.classList.contains("present") ||
        target.classList.contains("rate") ||
        target.classList.contains("advance")
    )) {
        calculateRow(row);
    }

    if (
        target.matches("#location") ||
        target.matches("#month") ||
        target.matches("#foreman") ||
        target.matches("#workerTableBody input")
    ) {
        autoSave();
    }
});

dateInput.addEventListener("change", autoSave);


// 13. PDF

document.getElementById("saveBtn").addEventListener("click", () => {
    autoSave();
    window.print();
});


// 14. RESET CURRENT MONTH

document.getElementById("resetBtn").addEventListener("click", () => {
    if (!confirm("Clear all current month details?")) return;

    restoreData({
        location: "JOGESWARY",
        month: document.getElementById("month").value,
        foreman: "JIYARUL HAQUE",
        date: dateInput.value,
        workers: []
    });

    autoSave();
});


// 15. START APPLICATION

function startApp() {
    try {
        const savedRecords = localStorage.getItem(RECORDS_KEY);
        records = savedRecords ? JSON.parse(savedRecords) : {};

        // Migrate data from the previous Auto Save version
        const oldData = localStorage.getItem(STORAGE_KEY);

        if (Object.keys(records).length === 0 && oldData) {
            const previousData = JSON.parse(oldData);

            const id = getRecordId(
                previousData.month || "SEPTEMBER",
                previousData.date
            );

            records[id] = previousData;
            localStorage.setItem(RECORDS_KEY, JSON.stringify(records));
            activeRecordId = id;
        }

        generateWorkerRows();
        setTodayDate();

        const previousActive = localStorage.getItem(ACTIVE_KEY);

        if (previousActive && records[previousActive]) {
            activeRecordId = previousActive;
        }

        if (activeRecordId && records[activeRecordId]) {
            restoreData(records[activeRecordId]);
        } else if (Object.keys(records).length > 0) {
            const latest = Object.keys(records).sort().pop();
            activeRecordId = latest;
            restoreData(records[latest]);
        } else {
            restoreData({
                location: "JOGESWARY",
                month: "SEPTEMBER",
                foreman: "JIYARUL HAQUE",
                date: dateInput.value,
                workers: []
            });

            activeRecordId = getRecordId("SEPTEMBER", dateInput.value);
            autoSave();
        }

        updateRecordsList();

        recordsStatus.textContent =
            "Monthly Records System is ready!";

    } catch (error) {
        console.error("Application startup error:", error);
        alert("Unable to load saved records. Please check your browser storage.");
    }
}

startApp();

console.log("GREEN CONSTRUCTION MONTHLY RECORDS READY!");


/* =================================
   BACKUP & RESTORE SYSTEM
================================= */

const backupBtn = document.getElementById("backupBtn");
const importBackupBtn = document.getElementById("importBackupBtn");
const backupFileInput = document.getElementById("backupFileInput");
const backupStatus = document.getElementById("backupStatus");

// DOWNLOAD BACKUP
backupBtn.addEventListener("click", function () {
    try {
        // Save the latest changes first
        autoSave();

        const backupData = {
            app: "GREEN_CONSTRUCTION",
            version: 1,
            exportedAt: new Date().toISOString(),
            activeRecordId: activeRecordId,
            records: records
        };

        const file = new Blob(
            [JSON.stringify(backupData, null, 2)],
            { type: "application/json" }
        );

        const url = URL.createObjectURL(file);
        const link = document.createElement("a");

        link.href = url;
        link.download =
            "GREEN_CONSTRUCTION_BACKUP_" +
            new Date().toISOString().slice(0, 10) +
            ".json";

        document.body.appendChild(link);
        link.click();
        link.remove();

        URL.revokeObjectURL(url);

        backupStatus.textContent =
            "Backup downloaded successfully!";
    } catch (error) {
        console.error(error);
        backupStatus.textContent =
            "Backup failed. Please try again.";
    }
});

// OPEN FILE SELECTOR
importBackupBtn.addEventListener("click", function () {
    backupFileInput.click();
});

// RESTORE BACKUP
backupFileInput.addEventListener("change", async function (event) {
    const file = event.target.files[0];

    if (!file) return;

    try {
        const text = await file.text();
        const backupData = JSON.parse(text);

        // Validate backup
        if (
            backupData.app !== "GREEN_CONSTRUCTION" ||
            backupData.version !== 1 ||
            !backupData.records ||
            typeof backupData.records !== "object" ||
            Array.isArray(backupData.records)
        ) {
            throw new Error("Invalid backup file.");
        }

        const importedRecords = backupData.records;
        const importedIds = Object.keys(importedRecords);

        if (importedIds.length === 0) {
            throw new Error("No monthly records found.");
        }

        // Validate each record
        for (const id of importedIds) {
            const record = importedRecords[id];

            if (
                !record ||
                typeof record !== "object" ||
                !Array.isArray(record.workers)
            ) {
                throw new Error("Backup contains invalid records.");
            }
        }

        // Find existing record conflicts
        const conflicts = importedIds.filter(
            id => Object.prototype.hasOwnProperty.call(records, id)
        );

        let replaceConflicts = false;

        if (conflicts.length > 0) {
            replaceConflicts = confirm(
                conflicts.length +
                " matching month record(s) already exist.\n\n" +
                "OK = Replace matching records\n" +
                "Cancel = Keep existing records and import only new months."
            );
        }

        // Merge records safely
        let importedCount = 0;
        let skippedCount = 0;

        for (const id of importedIds) {
            const exists = Object.prototype.hasOwnProperty.call(records, id);

            if (exists && !replaceConflicts) {
                skippedCount++;
                continue;
            }

            records[id] = importedRecords[id];
            importedCount++;
        }

        // Save imported records
        localStorage.setItem(
            RECORDS_KEY,
            JSON.stringify(records)
        );

        // Keep the current active month if possible
        if (!activeRecordId || !records[activeRecordId]) {
            activeRecordId =
                backupData.activeRecordId &&
                records[backupData.activeRecordId]
                    ? backupData.activeRecordId
                    : importedIds[0];

            localStorage.setItem(ACTIVE_KEY, activeRecordId);

            restoreData(records[activeRecordId]);
        }

        // Refresh saved month dropdown
        const recordsSelect = document.getElementById("recordsSelect");
        recordsSelect.innerHTML =
            '<option value="">SELECT SAVED MONTH</option>';

        Object.keys(records).sort().forEach(id => {
            const option = document.createElement("option");
            option.value = id;

            const monthName = records[id].month || id;
            option.textContent = monthName;

            recordsSelect.appendChild(option);
        });

        backupStatus.textContent =
            "Restore complete! Imported: " + importedCount +
            " | Skipped: " + skippedCount;

        updateDashboard();

    } catch (error) {
        console.error(error);
        backupStatus.textContent =
            "Restore failed: " + error.message;
        alert("Invalid or damaged backup file.");
    }

    // Allow selecting the same file again
    backupFileInput.value = "";
});
