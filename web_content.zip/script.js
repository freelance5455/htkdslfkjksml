const questions = [
  // المستوى 1
  {q:"ما الكوكب المعروف بالكوكب الأحمر؟", a:["المريخ","الزهرة","المشتري","عطارد"], c:0, l:1},
  {q:"ما الغاز الذي يحتاجه الإنسان للتنفس؟", a:["النيتروجين","الأكسجين","الهيدروجين","الهيليوم"], c:1, l:1},
  {q:"ما العضو المسؤول عن ضخ الدم في الجسم؟", a:["الرئة","الكبد","القلب","المعدة"], c:2, l:1},
  {q:"ما وحدة قياس القوة؟", a:["جول","نيوتن","واط","فولت"], c:1, l:1},

  // المستوى 2
  {q:"ما الرمز الكيميائي للصوديوم؟", a:["So","S","Na","Sd"], c:2, l:2},
  {q:"أي جزء من الخلية يحتوي غالبًا على المادة الوراثية؟", a:["النواة","الغشاء","السيتوبلازم","الفجوة"], c:0, l:2},
  {q:"ما العملية التي تصنع بها النباتات غذاءها؟", a:["التنفس","البناء الضوئي","الهضم","الانتشار"], c:1, l:2},
  {q:"إذا كانت سرعة جسم 20 م/ث واستمر 5 ثوانٍ، فما المسافة؟", a:["4 م","25 م","100 م","200 م"], c:2, l:2},

  // المستوى 3
  {q:"ما الجسيم ذو الشحنة السالبة؟", a:["البروتون","النيوترون","الإلكترون","النواة"], c:2, l:3},
  {q:"أي قانون يربط القوة والكتلة والتسارع؟", a:["F = ma","V = IR","P = VI","E = mc²"], c:0, l:3},
  {q:"ما قيمة pH للمحلول المتعادل تقريبًا عند 25°C؟", a:["0","5","7","14"], c:2, l:3},
  {q:"أي عضية تُعرف بأنها موقع إنتاج معظم ATP في الخلية؟", a:["الريبوسوم","الميتوكوندريا","جهاز جولجي","الليسوسوم"], c:1, l:3},

  // المستوى 4
  {q:"ما عدد الكروموسومات في الخلايا الجسدية للإنسان عادةً؟", a:["23","44","46","48"], c:2, l:4},
  {q:"في دائرة كهربائية، إذا زادت المقاومة مع ثبات فرق الجهد، فالتيار:", a:["يزداد","يقل","يثبت","ينعدم دائمًا"], c:1, l:4},
  {q:"ما نوع الرابطة الناتجة غالبًا عن مشاركة الإلكترونات بين الذرات؟", a:["أيونية","تساهمية","فلزية","هيدروجينية"], c:1, l:4},
  {q:"أي نوع من الانقسام الخلوي ينتج خلايا جنسية أحادية المجموعة الكروموسومية؟", a:["الميتوزي","المييوزي","الثنائي","اللاجنسي"], c:1, l:4},

  // المستوى 5
  {q:"إذا كان نصف عمر مادة مشعة 10 سنوات، فما الكمية المتبقية بعد 30 سنة؟", a:["1/2","1/4","1/8","1/16"], c:2, l:5},
  {q:"أي مبدأ يفسر زيادة سرعة السائل عند تضييق الأنبوب مع ثبات معدل السريان؟", a:["مبدأ باسكال","معادلة الاستمرارية","قانون كولوم","قانون بويل"], c:1, l:5},
  {q:"في الاتزان الكيميائي، إضافة مادة متفاعلة تؤدي وفق مبدأ لوشاتيليه إلى اتجاه الاتزان نحو:", a:["المتفاعلات","النواتج","لا يتغير","يتوقف التفاعل"], c:1, l:5},
  {q:"أي طفرة تؤدي إلى استبدال قاعدة نيتروجينية بقاعدة أخرى؟", a:["استبدال نقطي","حذف كروموسوم كامل","تضاعف خلية","اندماج أنسجة"], c:0, l:5}
];

let index = 0;
let score = 0;
let timer = 20;
let interval;
const perLevel = 4;

const $ = id => document.getElementById(id);

function currentLevel() {
  return Math.min(5, Math.floor(index / perLevel) + 1);
}

function loadQuestion() {
  clearInterval(interval);
  const item = questions[index];
  const level = currentLevel();

  $("level").textContent = level;
  $("questionNumber").textContent = index + 1;
  $("totalQuestions").textContent = questions.length;
  $("difficulty").textContent = ["","سهل","متوسط","متقدم","صعب","خبير"][level];
  $("question").textContent = item.q;
  $("feedback").textContent = "";
  $("nextBtn").hidden = true;
  $("progressBar").style.width = `${((index) / questions.length) * 100}%`;

  const answers = $("answers");
  answers.innerHTML = "";

  item.a.forEach((answer, i) => {
    const btn = document.createElement("button");
    btn.className = "answer";
    btn.textContent = answer;
    btn.onclick = () => chooseAnswer(i, btn);
    answers.appendChild(btn);
  });

  timer = 20;
  $("timer").textContent = timer;
  interval = setInterval(() => {
    timer--;
    $("timer").textContent = timer;
    if (timer <= 0) {
      clearInterval(interval);
      reveal(-1);
    }
  }, 1000);
}

function chooseAnswer(choice, button) {
  clearInterval(interval);
  reveal(choice);
}

function reveal(choice) {
  const item = questions[index];
  const buttons = document.querySelectorAll(".answer");

  buttons.forEach((btn, i) => {
    btn.disabled = true;
    if (i === item.c) btn.classList.add("correct");
    if (i === choice && choice !== item.c) btn.classList.add("wrong");
  });

  if (choice === item.c) {
    const points = currentLevel() * 10;
    score += points;
    $("score").textContent = score;
    $("feedback").textContent = `✅ إجابة صحيحة! +${points} نقطة`;
    $("feedback").style.color = "#249457";
  } else if (choice === -1) {
    $("feedback").textContent = `⏰ انتهى الوقت! الإجابة الصحيحة: ${item.a[item.c]}`;
    $("feedback").style.color = "#d26b00";
  } else {
    $("feedback").textContent = `❌ إجابة غير صحيحة. الصحيحة: ${item.a[item.c]}`;
    $("feedback").style.color = "#d34b4b";
  }

  $("nextBtn").hidden = false;
}

$("nextBtn").onclick = () => {
  index++;
  if (index >= questions.length) showResult();
  else loadQuestion();
};

function showResult() {
  clearInterval(interval);
  $("quizBox").hidden = true;
  $("resultBox").hidden = false;
  $("finalScore").textContent = `${score} / 300`;

  const percent = score / 300 * 100;
  let msg;
  if (percent >= 85) msg = "ممتاز جدًا! معلوماتك العلمية قوية 🔥";
  else if (percent >= 65) msg = "شغل حلو جدًا! كمّلي تحدي نفسك 💪";
  else if (percent >= 45) msg = "بداية كويسة، ومع شوية مراجعة هتتحسني جدًا 📚";
  else msg = "ولا يهمك! أعيدي التحدي وحاولي تكسري رقمك السابق 🌟";

  $("resultMessage").textContent = msg;
  $("progressBar").style.width = "100%";
}

$("restartBtn").onclick = () => {
  index = 0;
  score = 0;
  $("score").textContent = "0";
  $("resultBox").hidden = true;
  $("quizBox").hidden = false;
  loadQuestion();
};

loadQuestion();
