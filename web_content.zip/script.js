/* VaultFiles — gerenciador de arquivos local, sem servidor. */
const DB_NAME = 'vaultfiles-db';
const DB_VERSION = 1;
const FILE_STORE = 'files';
const FOLDER_STORE = 'folders';
const MAX_STORAGE = 5 * 1024 * 1024 * 1024;

const state = {
  files: [], folders: [], view: 'all', folderId: null, search: '', sort: 'updated', layout: localStorage.getItem('vault-layout') || 'grid', dark: localStorage.getItem('vault-dark') === 'true'
};
let db;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(FILE_STORE)) {
        const files = database.createObjectStore(FILE_STORE, { keyPath: 'id' });
        files.createIndex('updatedAt', 'updatedAt');
        files.createIndex('folderId', 'folderId');
      }
      if (!database.objectStoreNames.contains(FOLDER_STORE)) database.createObjectStore(FOLDER_STORE, { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
function dbRequest(storeName, mode, action) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, mode);
    const request = action(transaction.objectStore(storeName));
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
const getAll = (store) => dbRequest(store, 'readonly', (s) => s.getAll());
const put = (store, value) => dbRequest(store, 'readwrite', (s) => s.put(value));
const remove = (store, key) => dbRequest(store, 'readwrite', (s) => s.delete(key));

async function init() {
  try {
    db = await openDatabase();
    [state.files, state.folders] = await Promise.all([getAll(FILE_STORE), getAll(FOLDER_STORE)]);
  } catch (error) { showToast('Não foi possível abrir o armazenamento local.', 'error'); }
  applyTheme(); bindEvents(); render();
}

function bindEvents() {
  $('#uploadButton').addEventListener('click', () => $('#fileInput').click());
  $('#newFileButton').addEventListener('click', () => $('#fileInput').click());
  $('#emptyUploadButton').addEventListener('click', () => $('#fileInput').click());
  $('#fileInput').addEventListener('change', (event) => { importFiles(event.target.files); event.target.value = ''; });
  $('#newFolderButton').addEventListener('click', openFolderModal);
  $('#modalClose').addEventListener('click', closeFolderModal);
  $('#modalCancel').addEventListener('click', closeFolderModal);
  $('#modalBackdrop').addEventListener('click', (event) => { if (event.target.id === 'modalBackdrop') closeFolderModal(); });
  $('#folderForm').addEventListener('submit', createFolder);
  $('#previewClose').addEventListener('click', closePreview);
  $('#previewBackdrop').addEventListener('click', (event) => { if (event.target.id === 'previewBackdrop') closePreview(); });
  $('#searchInput').addEventListener('input', (event) => { state.search = event.target.value.trim().toLowerCase(); renderFiles(); });
  $('#sortSelect').addEventListener('change', (event) => { state.sort = event.target.value; renderFiles(); });
  $('#themeButton').addEventListener('click', () => { state.dark = !state.dark; localStorage.setItem('vault-dark', state.dark); applyTheme(); });
  $('#menuButton').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  $$('.nav-item').forEach((button) => button.addEventListener('click', () => { state.view = button.dataset.view; state.folderId = null; setActiveNav(button); closeMobileMenu(); render(); }));
  $$('.view-button').forEach((button) => button.addEventListener('click', () => { state.layout = button.dataset.layout; localStorage.setItem('vault-layout', state.layout); updateLayoutButtons(); renderFiles(); }));
  setupDropZone();
  document.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#searchInput').focus(); } if (event.key === 'Escape') { closeFolderModal(); closePreview(); closeAllMenus(); } });
  document.addEventListener('click', (event) => { if (!event.target.closest('.file-card')) closeAllMenus(); });
}
function setupDropZone() {
  const zone = $('#dropZone'); const section = $('.files-section');
  ['dragenter', 'dragover'].forEach((eventName) => section.addEventListener(eventName, (event) => { event.preventDefault(); zone.classList.add('dragover'); }));
  ['dragleave', 'drop'].forEach((eventName) => section.addEventListener(eventName, (event) => { event.preventDefault(); if (eventName === 'drop') importFiles(event.dataTransfer.files); zone.classList.remove('dragover'); }));
}
async function importFiles(fileList) {
  if (!fileList || !fileList.length) return;
  const files = [...fileList];
  for (const file of files) {
    const record = { id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`, name: file.name, type: file.type || 'application/octet-stream', size: file.size, updatedAt: Date.now(), folderId: state.folderId || null, favorite: false, blob: file };
    await put(FILE_STORE, record); state.files.push(record);
  }
  showToast(`${files.length} arquivo${files.length > 1 ? 's' : ''} adicionado${files.length > 1 ? 's' : ''}.`, 'success'); render();
}
async function createFolder(event) {
  event.preventDefault(); const input = $('#folderName'); const name = input.value.trim(); if (!name) return;
  const folder = { id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`, name, createdAt: Date.now() };
  await put(FOLDER_STORE, folder); state.folders.push(folder); input.value = ''; closeFolderModal(); showToast('Pasta criada.', 'success'); renderFolders();
}
function openFolderModal() { $('#modalBackdrop').classList.remove('hidden'); setTimeout(() => $('#folderName').focus(), 50); }
function closeFolderModal() { $('#modalBackdrop').classList.add('hidden'); }
function closePreview() { $('#previewBackdrop').classList.add('hidden'); $('#previewContent').innerHTML = ''; }
function closeMobileMenu() { if (window.innerWidth <= 760) $('#sidebar').classList.remove('open'); }
function applyTheme() { document.body.classList.toggle('dark', state.dark); $('#themeButton').textContent = state.dark ? '☾' : '☼'; }
function setActiveNav(button) { $$('.nav-item').forEach((item) => item.classList.remove('active')); if (button) button.classList.add('active'); $$('.folder-item').forEach((item) => item.classList.remove('active')); }
function updateLayoutButtons() { $$('.view-button').forEach((button) => button.classList.toggle('active', button.dataset.layout === state.layout)); }

function render() { renderFolders(); renderHeader(); renderStats(); renderFiles(); updateLayoutButtons(); }
function renderHeader() {
  const names = { all: ['VISÃO GERAL', 'Todos os arquivos', 'Tudo o que você guardou, em um só lugar.'], recent: ['ÚLTIMAS ATUALIZAÇÕES', 'Arquivos recentes', 'Os arquivos que receberam atenção por último.'], favorites: ['SELEÇÃO PESSOAL', 'Favoritos', 'Seus arquivos mais importantes, sempre à mão.'], trash: ['RECUPERAÇÃO', 'Lixeira', 'Arquivos excluídos ficam aqui por enquanto.'] };
  const current = state.folderId ? state.folders.find((folder) => folder.id === state.folderId) : null;
  const copy = current ? ['PASTA', current.name, `Arquivos organizados em ${current.name}.`] : names[state.view];
  $('#currentEyebrow').textContent = copy[0]; $('#pageTitle').textContent = copy[1]; $('#pageSubtitle').textContent = copy[2]; $('#breadcrumbCurrent').textContent = copy[1];
  $('#sectionTitle').textContent = current ? current.name : (state.view === 'all' ? 'Seus arquivos' : copy[1]);
}
function renderStats() {
  const activeFiles = state.files.filter((file) => !file.trashed); const used = activeFiles.reduce((total, file) => total + file.size, 0); const favorites = activeFiles.filter((file) => file.favorite).length;
  $('#allCount').textContent = activeFiles.length; $('#favoriteCount').textContent = favorites; $('#trashCount').textContent = state.files.filter((file) => file.trashed).length;
  $('#statFiles').textContent = activeFiles.length; $('#statStorage').textContent = formatSize(used); $('#statFavorites').textContent = favorites; $('#storageUsed').textContent = `${formatSize(used)} usados`; $('#storageProgress').style.width = `${Math.min(100, used / MAX_STORAGE * 100)}%`;
}
function renderFolders() {
  const list = $('#folderList'); list.innerHTML = '';
  if (!state.folders.length) { list.innerHTML = '<span style="padding:0 12px;color:var(--muted);font-size:11px">Nenhuma pasta criada</span>'; return; }
  state.folders.forEach((folder) => { const button = document.createElement('button'); button.className = `folder-item ${state.folderId === folder.id ? 'active' : ''}`; button.innerHTML = `<span class="folder-icon">▰</span><span>${escapeHtml(folder.name)}</span><span class="folder-count">${state.files.filter((file) => file.folderId === folder.id && !file.trashed).length}</span>`; button.addEventListener('click', () => { state.folderId = folder.id; state.view = 'all'; setActiveNav(null); closeMobileMenu(); render(); }); list.appendChild(button); });
}
function getVisibleFiles() {
  let files = [...state.files];
  if (state.view === 'trash') files = files.filter((file) => file.trashed);
  else { files = files.filter((file) => !file.trashed); if (state.view === 'favorites') files = files.filter((file) => file.favorite); if (state.view === 'recent') files = files.filter((file) => file.updatedAt > Date.now() - 30 * 24 * 60 * 60 * 1000); if (state.folderId) files = files.filter((file) => file.folderId === state.folderId); }
  if (state.search) files = files.filter((file) => file.name.toLowerCase().includes(state.search) || getType(file).includes(state.search));
  files.sort((a, b) => state.sort === 'name' ? a.name.localeCompare(b.name) : state.sort === 'size' ? b.size - a.size : state.sort === 'type' ? getType(a).localeCompare(getType(b)) : b.updatedAt - a.updatedAt);
  return files;
}
function renderFiles() {
  const container = $('#filesContainer'); const files = getVisibleFiles(); container.className = `files-grid ${state.layout === 'list' ? 'list-layout' : ''}`; container.innerHTML = '';
  $('#fileCounter').textContent = `${files.length} ${files.length === 1 ? 'item' : 'itens'}`; $('#emptyState').classList.toggle('hidden', files.length > 0); $('#dropZone').classList.remove('dragover');
  if (!files.length) { $('#emptyTitle').textContent = state.search ? 'Nenhum resultado encontrado' : state.view === 'trash' ? 'A lixeira está vazia' : state.view === 'favorites' ? 'Nenhum favorito ainda' : 'Nenhum arquivo por aqui'; $('#emptyDescription').textContent = state.search ? 'Tente buscar usando outro nome ou tipo de arquivo.' : 'Comece adicionando um arquivo para deixar seu espaço organizado.'; return; }
  files.forEach((file) => container.appendChild(createFileCard(file)));
}
function createFileCard(file) {
  const card = document.createElement('article'); card.className = 'file-card'; const type = getType(file); const isImage = file.type.startsWith('image/');
  const preview = document.createElement('div'); preview.className = `file-preview type-${type}`; preview.title = 'Abrir visualização';
  if (isImage) { const img = document.createElement('img'); img.src = URL.createObjectURL(file.blob); img.alt = file.name; preview.appendChild(img); } else { const typeLabel = document.createElement('span'); typeLabel.className = 'file-type-big'; typeLabel.textContent = type.toUpperCase().slice(0, 4); preview.appendChild(typeLabel); }
  preview.addEventListener('click', () => previewFile(file));
  const info = document.createElement('div'); info.className = 'file-info'; info.innerHTML = `<span class="file-name" title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</span><span class="file-meta">${formatSize(file.size)} · ${formatDate(file.updatedAt)}</span>`;
  const footer = document.createElement('div'); footer.className = 'file-footer'; const folder = file.folderId ? state.folders.find((item) => item.id === file.folderId) : null; footer.innerHTML = `<span class="folder-tag">${folder ? `▰ ${escapeHtml(folder.name)}` : 'Meu espaço'}</span><div class="card-actions"><button class="icon-button favorite-button ${file.favorite ? 'is-favorite' : ''}" title="${file.favorite ? 'Remover dos favoritos' : 'Adicionar aos favoritos'}">${file.favorite ? '★' : '☆'}</button><button class="icon-button more-button" title="Mais opções">•••</button></div>`;
  footer.querySelector('.favorite-button').addEventListener('click', (event) => { event.stopPropagation(); toggleFavorite(file); }); footer.querySelector('.more-button').addEventListener('click', (event) => { event.stopPropagation(); toggleMenu(card, file); });
  card.append(preview, info, footer); return card;
}
function toggleMenu(card, file) { closeAllMenus(); const menu = document.createElement('div'); menu.className = 'file-menu'; const trashText = file.trashed ? 'Restaurar arquivo' : 'Mover para lixeira'; menu.innerHTML = `<button data-action="download">Baixar arquivo</button><button data-action="preview">Visualizar</button><button data-action="trash" class="danger">${trashText}</button>`; menu.querySelector('[data-action="download"]').addEventListener('click', () => downloadFile(file)); menu.querySelector('[data-action="preview"]').addEventListener('click', () => previewFile(file)); menu.querySelector('[data-action="trash"]').addEventListener('click', () => toggleTrash(file)); card.appendChild(menu); }
function closeAllMenus() { $$('.file-menu').forEach((menu) => menu.remove()); }
async function toggleFavorite(file) { file.favorite = !file.favorite; await put(FILE_STORE, file); render(); showToast(file.favorite ? 'Adicionado aos favoritos.' : 'Removido dos favoritos.', 'success'); }
async function toggleTrash(file) { if (file.trashed) { file.trashed = false; file.updatedAt = Date.now(); await put(FILE_STORE, file); showToast('Arquivo restaurado.', 'success'); } else { file.trashed = true; file.updatedAt = Date.now(); await put(FILE_STORE, file); showToast('Arquivo movido para a lixeira.', 'success'); } render(); }
function downloadFile(file) { const url = URL.createObjectURL(file.blob); const link = document.createElement('a'); link.href = url; link.download = file.name; link.click(); setTimeout(() => URL.revokeObjectURL(url), 500); showToast('Download iniciado.', 'success'); }
function previewFile(file) {
  const type = getType(file); const isImage = file.type.startsWith('image/'); const isText = file.type.startsWith('text/') || ['json', 'js', 'css', 'html', 'md'].includes(type); $('#previewContent').innerHTML = `<div class="preview-header"><div class="file-type-big type-${type}">${escapeHtml(type.toUpperCase().slice(0, 4))}</div><div><h2>${escapeHtml(file.name)}</h2><p>${formatSize(file.size)} · ${formatDate(file.updatedAt)}</p></div></div>`;
  if (isImage) { const img = document.createElement('img'); img.className = 'preview-image'; img.src = URL.createObjectURL(file.blob); img.alt = file.name; $('#previewContent').appendChild(img); } else if (isText && file.size < 2 * 1024 * 1024) { const reader = new FileReader(); reader.onload = () => { const text = document.createElement('pre'); text.className = 'preview-text'; text.textContent = reader.result; $('#previewContent').appendChild(text); }; reader.readAsText(file.blob); } else { const unavailable = document.createElement('div'); unavailable.className = 'preview-unavailable'; unavailable.textContent = 'A prévia deste formato não está disponível. Você pode baixar o arquivo abaixo.'; $('#previewContent').appendChild(unavailable); }
  const download = document.createElement('a'); download.className = 'primary-button preview-download'; download.href = URL.createObjectURL(file.blob); download.download = file.name; download.textContent = '↓ Baixar arquivo'; $('#previewContent').appendChild(download); $('#previewBackdrop').classList.remove('hidden');
}
function getType(file) { const extension = file.name.includes('.') ? file.name.split('.').pop().toLowerCase() : ''; if (/^[a-z0-9]{1,8}$/.test(extension)) return extension; if (file.type.includes('/')) { const mimeType = file.type.split('/')[1].toLowerCase(); return /^[a-z0-9]{1,8}$/.test(mimeType) ? mimeType : 'file'; } return 'file'; }
function formatSize(bytes) { if (!bytes) return '0 B'; const units = ['B', 'KB', 'MB', 'GB']; const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1); return `${(bytes / Math.pow(1024, index)).toFixed(index ? 1 : 0)} ${units[index]}`; }
function formatDate(timestamp) { return new Intl.DateTimeFormat('pt-BR', { day: '2-digit', month: 'short' }).format(new Date(timestamp)).replace('.', ''); }
function escapeHtml(value) { return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char])); }
function showToast(message, type = '') { const toast = document.createElement('div'); toast.className = `toast ${type}`; toast.textContent = message; $('#toastContainer').appendChild(toast); setTimeout(() => toast.remove(), 3000); }

init();
