const sensitivity = document.getElementById("sensitivity");
const fov = document.getElementById("fov");

const sensitivityValue = document.getElementById("sensitivityValue");
const fovValue = document.getElementById("fovValue");

const message = document.getElementById("message");

sensitivity.addEventListener("input", () => {
    sensitivityValue.textContent = sensitivity.value;
});

fov.addEventListener("input", () => {
    fovValue.textContent = fov.value;
});

document.getElementById("apply").addEventListener("click", () => {

    const config = {
        aim: document.getElementById("aim").checked,
        headshot: document.getElementById("headshot").checked,
        performance: document.getElementById("performance").checked,
        sensitivity: sensitivity.value,
        fov: fov.value
    };

    localStorage.setItem("NS_AIM_CONFIG", JSON.stringify(config));

    message.textContent = "Configurações guardadas com sucesso!";
});

document.getElementById("minimize").addEventListener("click", () => {
    document.getElementById("content").classList.toggle("hidden");
});

const saved = JSON.parse(localStorage.getItem("NS_AIM_CONFIG") || "null");

if (saved) {
    document.getElementById("aim").checked = saved.aim;
    document.getElementById("headshot").checked = saved.headshot;
    document.getElementById("performance").checked = saved.performance;

    sensitivity.value = saved.sensitivity;
    fov.value = saved.fov;

    sensitivityValue.textContent = saved.sensitivity;
    fovValue.textContent = saved.fov;
}

