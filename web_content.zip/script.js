(() => {
  const state = { fps:false, crosshair:false, sound:true, dark:false };
  const toast = document.getElementById('toast');
  const fill = document.getElementById('meterFill');
  const active = document.getElementById('activeCount');

  function render(){
    document.body.classList.toggle('dark', state.dark);
    for (const key of ['fps','crosshair','sound','dark']) {
      const el = document.getElementById(key + 'Switch');
      if (el) el.classList.toggle('on', state[key]);
    }
    const count = Object.values(state).filter(Boolean).length;
    active.textContent = count;
    fill.style.width = Math.max(8, count * 25) + '%';
  }

  function notify(message){
    toast.textContent = message;
    clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(() => toast.textContent = '', 1600);
  }

  document.querySelectorAll('[data-action]').forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.action;
      state[key] = !state[key];
      render();
      notify((state[key] ? 'Activado: ' : 'Desactivado: ') + btn.querySelector('b').textContent);
    });
  });

  document.getElementById('reset').addEventListener('click', () => {
    state.fps = false;
    state.crosshair = false;
    state.sound = true;
    state.dark = false;
    render();
    notify('Panel restaurado');
  });

  render();
})();