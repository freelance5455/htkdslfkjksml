document.addEventListener("DOMContentLoaded", () => {

    // ==========================================
    // CHRONOVA — MAIN ELEMENTS
    // ==========================================

    const countdown = document.getElementById("countdown");

    const startButton = document.getElementById("start");
    const resetButton = document.getElementById("reset");
    const setTimeButton = document.getElementById("set-time");

    const hoursInput = document.getElementById("hours");
    const minutesInput = document.getElementById("minutes");
    const secondsInput = document.getElementById("seconds");

    const progress = document.getElementById("progress");

    const menuButton = document.getElementById("menu-button");
    const menuPanel = document.getElementById("menu-panel");

    const settingsButton = document.getElementById("settings-button");
    const aboutButton = document.getElementById("about-button");

    const settingsModal = document.getElementById("settings-modal");
    const aboutModal = document.getElementById("about-modal");

    const closeSettings = document.getElementById("close-settings");
    const closeAbout = document.getElementById("close-about");

    const soundToggle = document.getElementById("sound-toggle");
    const vibrationToggle = document.getElementById("vibration-toggle");
    const effectsToggle = document.getElementById("effects-toggle");

    const defaultTimer = document.getElementById("default-timer");

    const alarmList = document.getElementById("alarm-list");
    const customAlarmInput = document.getElementById("custom-alarm-input");

    const completionModal = document.getElementById("completion-modal");
    const completedDuration = document.getElementById("completed-duration");
    const continueButton = document.getElementById("continue-button");

    const timerSphere = document.querySelector(".timer-3d");


    // ==========================================
    // IMMERSIVE FULL SCREEN
    // ==========================================

    const fullscreenButton = document.getElementById("fullscreen-button");
    const app = document.querySelector(".app");

    if (fullscreenButton && app) {

        fullscreenButton.addEventListener("click", () => {

            const isActive = app.classList.toggle("immersive-mode");

            fullscreenButton.textContent = isActive
                ? "✕ EXIT FULL SCREEN"
                : "⛶ FULL SCREEN";

            updateTimer();

        });

    }


    // ==========================================
    // TIMER VARIABLES
    // ==========================================

    let totalSeconds = 25 * 60;
    let remainingSeconds = totalSeconds;

    let timerInterval = null;
    let isRunning = false;

    const circumference = 2 * Math.PI * 130;

    if (progress) {
        progress.style.strokeDasharray = circumference;
        progress.style.strokeDashoffset = 0;
    }


    // ==========================================
    // TIME FORMAT
    // ==========================================

    function formatTime(seconds) {

        const h = Math.floor(seconds / 3600);
        const m = Math.floor((seconds % 3600) / 60);
        const s = seconds % 60;

        return (
            String(h).padStart(2, "0") + ":" +
            String(m).padStart(2, "0") + ":" +
            String(s).padStart(2, "0")
        );

    }


    // ==========================================
    // UPDATE TIMER
    // ==========================================

    function updateTimer() {

        const h = String(
            Math.floor(remainingSeconds / 3600)
        ).padStart(2, "0");

        const m = String(
            Math.floor((remainingSeconds % 3600) / 60)
        ).padStart(2, "0");

        const s = String(
            remainingSeconds % 60
        ).padStart(2, "0");


        if (countdown) {

            if (app.classList.contains("immersive-mode")) {

                countdown.innerHTML = `
                    <span class="time-part">${h}</span>
                    <span class="time-separator">:</span>
                    <span class="time-part">${m}</span>
                    <span class="time-separator">:</span>
                    <span class="time-part">${s}</span>
                `;

            } else {

                countdown.textContent = `${h}:${m}:${s}`;

            }

        }


        if (progress) {

            const percentage = totalSeconds > 0
                ? remainingSeconds / totalSeconds
                : 0;

            progress.style.strokeDashoffset =
                circumference * (1 - percentage);

        }

    }


    // ==========================================
    // ALARM SOUND STUDIO
    // ==========================================

    const alarmFiles = [

        {
            name: "Chicken on Tree",
            path: "sounds/Chicken on tree.mp3"
        },

        {
            name: "Chinese",
            path: "sounds/Chinese.mp3"
        },

        {
            name: "Classic Winner",
            path: "sounds/classic winner alarm 1997.wav"
        },

        {
            name: "Digital Clock",
            path: "sounds/digital clock digital alarm buzzer.wav"
        },

        {
            name: "Interface Hint",
            path: "sounds/interface hint notification.wav"
        },

        {
            name: "Kpola Dorja Khol",
            path: "sounds/Kpola Dorja Khol.mp3"
        }

    ];

    let selectedAlarm = Number(
        localStorage.getItem("chronoSelectedAlarm") || 0
    );

    let currentAudio = null;
    let preparedAlarm = null;
    let customAlarmURL = null;


    // ==========================================
    // STOP ALARM
    // ==========================================

    function stopAlarm() {

        if (currentAudio) {

            currentAudio.pause();
            currentAudio.currentTime = 0;
            currentAudio = null;

        }

        if (preparedAlarm) {

            preparedAlarm.pause();
            preparedAlarm.currentTime = 0;

        }

    }


    // ==========================================
    // PREPARE ALARM
    // ==========================================

    function prepareAlarm() {

        const alarm = alarmFiles[selectedAlarm];

        if (!alarm) return;

        if (preparedAlarm) {

            preparedAlarm.pause();
            preparedAlarm = null;

        }

        preparedAlarm = new Audio(alarm.path);

        preparedAlarm.preload = "auto";
        preparedAlarm.loop = true;
        preparedAlarm.muted = true;

        preparedAlarm.load();

        const playPromise = preparedAlarm.play();

        if (playPromise !== undefined) {

            playPromise.then(() => {

                if (!preparedAlarm) return;

                preparedAlarm.pause();
                preparedAlarm.currentTime = 0;
                preparedAlarm.muted = false;

            }).catch(() => {

                if (preparedAlarm) {
                    preparedAlarm.muted = false;
                }

            });

        }

    }


    // ==========================================
    // TIMER START / PAUSE
    // ==========================================

    function startTimer() {

        if (isRunning) {

            clearInterval(timerInterval);

            timerInterval = null;
            isRunning = false;

            startButton.textContent = "START";

            return;

        }

        if (remainingSeconds <= 0) {

            remainingSeconds = totalSeconds;
            updateTimer();

        }

        isRunning = true;

        startButton.textContent = "PAUSE";

        timerInterval = setInterval(() => {

            remainingSeconds--;

            updateTimer();

            if (remainingSeconds <= 0) {

                clearInterval(timerInterval);

                timerInterval = null;
                isRunning = false;

                startButton.textContent = "START";

                finishSession();

            }

        }, 1000);

    }


    // ==========================================
    // START BUTTON
    // ==========================================

    startButton.addEventListener("click", () => {

        if (!isRunning && soundToggle.checked) {
            prepareAlarm();
        }

        startTimer();

    });


    // ==========================================
    // RESET TIMER
    // ==========================================

    resetButton.addEventListener("click", () => {

        clearInterval(timerInterval);

        timerInterval = null;
        isRunning = false;

        remainingSeconds = totalSeconds;

        startButton.textContent = "START";

        stopAlarm();

        completionModal.classList.remove("active");

        if (navigator.vibrate) {
            navigator.vibrate(0);
        }

        updateTimer();

    });


    // ==========================================
    // CUSTOM TIMER
    // ==========================================

    setTimeButton.addEventListener("click", () => {

        const h = Number(hoursInput.value) || 0;
        const m = Number(minutesInput.value) || 0;
        const s = Number(secondsInput.value) || 0;

        if (
            h < 0 ||
            h > 99 ||
            m < 0 ||
            m > 59 ||
            s < 0 ||
            s > 59
        ) {

            alert("Please enter a valid time.");

            return;

        }

        const newTime = h * 3600 + m * 60 + s;

        if (newTime <= 0) {

            alert("Please set a time greater than zero.");

            return;

        }

        clearInterval(timerInterval);

        timerInterval = null;
        isRunning = false;

        totalSeconds = newTime;
        remainingSeconds = newTime;

        startButton.textContent = "START";

        stopAlarm();

        updateTimer();

    });


    // ==========================================
    // THREE DOT MENU
    // ==========================================

    menuButton.addEventListener("click", (e) => {

        e.stopPropagation();

        menuPanel.classList.toggle("active");

    });


    document.addEventListener("click", (e) => {

        if (
            !menuPanel.contains(e.target) &&
            !menuButton.contains(e.target)
        ) {

            menuPanel.classList.remove("active");

        }

    });


    // ==========================================
    // SETTINGS & ABOUT
    // ==========================================

    settingsButton.addEventListener("click", () => {

        settingsModal.classList.add("active");

        menuPanel.classList.remove("active");

    });


    aboutButton.addEventListener("click", () => {

        aboutModal.classList.add("active");

        menuPanel.classList.remove("active");

    });


    closeSettings.addEventListener("click", () => {

        settingsModal.classList.remove("active");

    });


    closeAbout.addEventListener("click", () => {

        aboutModal.classList.remove("active");

    });


    [settingsModal, aboutModal].forEach(modal => {

        modal.addEventListener("click", (e) => {

            if (e.target === modal) {
                modal.classList.remove("active");
            }

        });

    });


    // ==========================================
    // LOAD SETTINGS
    // ==========================================

    soundToggle.checked =
        localStorage.getItem("chronoSound") !== "false";

    vibrationToggle.checked =
        localStorage.getItem("chronoVibration") !== "false";

    effectsToggle.checked =
        localStorage.getItem("chronoEffects") !== "false";


    const savedDefault = localStorage.getItem("chronoDefault");

    if (savedDefault) {

        defaultTimer.value = savedDefault;

        const minutes = Number(savedDefault);

        if (minutes > 0) {

            totalSeconds = minutes * 60;
            remainingSeconds = totalSeconds;

        }

    }


    // ==========================================
    // SAVE SETTINGS
    // ==========================================

    soundToggle.addEventListener("change", () => {

        localStorage.setItem(
            "chronoSound",
            soundToggle.checked
        );

        if (!soundToggle.checked) {
            stopAlarm();
        }

    });


    vibrationToggle.addEventListener("change", () => {

        localStorage.setItem(
            "chronoVibration",
            vibrationToggle.checked
        );

    });


    effectsToggle.addEventListener("change", () => {

        localStorage.setItem(
            "chronoEffects",
            effectsToggle.checked
        );

        document.body.classList.toggle(
            "effects-off",
            !effectsToggle.checked
        );

    });


    // ==========================================
    // DEFAULT TIMER
    // ==========================================

    defaultTimer.addEventListener("change", () => {

        const minutes = Number(defaultTimer.value);

        if (!Number.isFinite(minutes) || minutes <= 0) return;

        localStorage.setItem("chronoDefault", minutes);

        clearInterval(timerInterval);

        timerInterval = null;
        isRunning = false;

        totalSeconds = minutes * 60;
        remainingSeconds = totalSeconds;

        startButton.textContent = "START";

        stopAlarm();

        updateTimer();

    });


    document.body.classList.toggle(
        "effects-off",
        !effectsToggle.checked
    );


    // ==========================================
    // RENDER ALARM LIST
    // ==========================================

    function renderAlarms() {

        alarmList.innerHTML = "";

        alarmFiles.forEach((alarm, index) => {

            const item = document.createElement("div");

            item.className = "alarm-item";

            if (selectedAlarm === index) {
                item.classList.add("selected");
            }

            const name = document.createElement("span");

            name.textContent = alarm.name;

            const buttons = document.createElement("div");

            buttons.className = "alarm-actions";


            // PREVIEW BUTTON

            const preview = document.createElement("button");

            preview.textContent = "▶";
            preview.type = "button";

            preview.addEventListener("click", () => {

                stopAlarm();

                currentAudio = new Audio(alarm.path);

                currentAudio.play().catch(() => {

                    alert("Unable to play this sound.");

                });

            });


            // SELECT BUTTON

            const select = document.createElement("button");

            select.type = "button";

            select.textContent =
                selectedAlarm === index
                    ? "✓ SELECTED"
                    : "SELECT";

            select.addEventListener("click", () => {

                stopAlarm();

                selectedAlarm = index;

                localStorage.setItem(
                    "chronoSelectedAlarm",
                    selectedAlarm
                );

                renderAlarms();

            });


            buttons.appendChild(preview);
            buttons.appendChild(select);

            item.appendChild(name);
            item.appendChild(buttons);

            alarmList.appendChild(item);

        });

    }


    renderAlarms();


    // ==========================================
    // CUSTOM ALARM UPLOAD
    // ==========================================

    customAlarmInput.addEventListener("change", () => {

        const file = customAlarmInput.files[0];

        if (!file) return;

        if (customAlarmURL) {
            URL.revokeObjectURL(customAlarmURL);
        }

        customAlarmURL = URL.createObjectURL(file);

        alarmFiles.push({

            name: file.name,
            path: customAlarmURL

        });

        selectedAlarm = alarmFiles.length - 1;

        localStorage.setItem(
            "chronoSelectedAlarm",
            selectedAlarm
        );

        stopAlarm();

        renderAlarms();

        alert("Custom alarm added!");

    });


    // ==========================================
    // SESSION COMPLETE
    // ==========================================

    function finishSession() {

        completedDuration.textContent =
            formatTime(totalSeconds);

        completionModal.classList.add("active");


        // PLAY ALARM

        if (soundToggle.checked) {

            stopAlarm();

            if (preparedAlarm) {

                currentAudio = preparedAlarm;

                currentAudio.muted = false;
                currentAudio.loop = true;
                currentAudio.currentTime = 0;

                currentAudio.play().catch(() => {

                    console.log("Alarm playback was blocked.");

                });

            } else {

                const alarm = alarmFiles[selectedAlarm];

                if (alarm) {

                    currentAudio = new Audio(alarm.path);

                    currentAudio.loop = true;

                    currentAudio.play().catch(() => {});

                }

            }

        }


        // VIBRATION

        if (
            vibrationToggle.checked &&
            navigator.vibrate
        ) {

            navigator.vibrate([
                500,
                200,
                500,
                200,
                800
            ]);

        }

    }


    // ==========================================
    // CONTINUE BUTTON
    // ==========================================

    continueButton.addEventListener("click", () => {

        completionModal.classList.remove("active");

        stopAlarm();

        if (navigator.vibrate) {
            navigator.vibrate(0);
        }

    });


    // ==========================================
    // TIMER SWIPE CONTROL
    // ==========================================

    let touchStartX = 0;
    let touchStartY = 0;

    if (timerSphere) {

        timerSphere.addEventListener("touchstart", (e) => {

            touchStartX = e.changedTouches[0].screenX;
            touchStartY = e.changedTouches[0].screenY;

        }, { passive: true });


        timerSphere.addEventListener("touchend", (e) => {

            const touchEndX = e.changedTouches[0].screenX;
            const touchEndY = e.changedTouches[0].screenY;

            const differenceX = touchEndX - touchStartX;
            const differenceY = touchEndY - touchStartY;

            if (
                Math.abs(differenceX) > 60 &&
                Math.abs(differenceX) > Math.abs(differenceY)
            ) {

                const change = differenceX > 0 ? 300 : -300;

                clearInterval(timerInterval);

                timerInterval = null;
                isRunning = false;

                totalSeconds = Math.max(
                    1,
                    totalSeconds + change
                );

                remainingSeconds = Math.max(
                    1,
                    remainingSeconds + change
                );

                startButton.textContent = "START";

                stopAlarm();

                updateTimer();

            }

        }, { passive: true });

    }


    // ==========================================
    // MAGICAL TOUCH EFFECT
    // ==========================================

    document.addEventListener("pointerdown", (e) => {

        if (!effectsToggle.checked) return;

        const ripple = document.createElement("span");

        ripple.className = "touch-ripple";

        ripple.style.left = e.clientX + "px";
        ripple.style.top = e.clientY + "px";

        document.body.appendChild(ripple);

        setTimeout(() => {

            ripple.remove();

        }, 800);

    });


    // ==========================================
    // INITIAL DISPLAY
    // ==========================================

      updateTimer();

});