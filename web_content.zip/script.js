import {
  auth,
  database,
  get,
  child,
  dbRef,
  set,
  ref,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from './firebase/firebase.js';

document.addEventListener('DOMContentLoaded', () => {
  const usernameInput = document.getElementById('user');
  const passwordInput = document.getElementById('password');
  const emailInput = document.getElementById('email');
  const submitButton = document.getElementById('submit');
  const visibilityButton = document.getElementById('visibility');

  if (visibilityButton && passwordInput) {
    visibilityButton.addEventListener('click', event => {
      event.preventDefault();
      passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
    });
  }

  async function saveUserProfile(username, email) {
    await set(ref(database, `users/${username}`), { username, email });
  }

  if (submitButton) {
    submitButton.addEventListener('click', async event => {
      event.preventDefault();
      const username = usernameInput?.value.trim();
      const password = passwordInput?.value || '';
      const email = emailInput?.value.trim();

      if (!username || !password || !email) {
        alert('Enter a username, email, and password.');
        return;
      }
      if (['.', '#', '$', '[', ']', '/'].some(character => username.includes(character))) {
        alert('Please choose a username without Firebase-reserved characters: . # $ [ ] or /.');
        return;
      }

      submitButton.disabled = true;
      try {
        let credential;
        try {
          credential = await createUserWithEmailAndPassword(auth, email, password);
        } catch (error) {
          if (error.code !== 'auth/email-already-in-use') throw error;
          credential = await signInWithEmailAndPassword(auth, email, password);
        }

        const existingProfile = await get(child(dbRef, `users/${username}`));
        if (!existingProfile.exists()) {
          await saveUserProfile(username, credential.user.email || email);
        } else if (existingProfile.val()?.email !== (credential.user.email || email)) {
          throw new Error('That username is already being used by a different account.');
        }

        localStorage.setItem('username', username);
        window.location.href = 'main.html';
      } catch (error) {
        console.error('Authentication failed:', error);
        const messages = {
          'auth/invalid-email': 'Please enter a valid email address.',
          'auth/weak-password': 'Your password must be at least 6 characters.',
          'auth/invalid-credential': 'That email or password is incorrect.',
          'auth/wrong-password': 'That email or password is incorrect.',
          'auth/user-not-found': 'No account was found for that email.',
          'auth/email-already-in-use': 'That email is already registered. Check your password.'
        };
        alert(messages[error.code] || error.message || 'Could not log in or create your account.');
      } finally {
        submitButton.disabled = false;
      }
    });
  }
});
