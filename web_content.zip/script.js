'use strict';
/* Boots AI - logique côté client (aucune dépendance, aucun chargement réseau au démarrage) */

// ---------- Utilitaires ----------
var norm = function (s) { return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim(); };
var $ = function (id) { return document.getElementById(id); };
var intentUrl = function (extra) { return 'intent:#Intent;' + extra + ';end'; };

var SETTINGS = [
  [['wifi', 'wi-fi'], 'les paramètres Wi-Fi', 'android.settings.WIFI_SETTINGS'],
  [['bluetooth'], 'les paramètres Bluetooth', 'android.settings.BLUETOOTH_SETTINGS'],
  [['luminosite', 'ecran', 'affichage'], "les paramètres d'affichage", 'android.settings.DISPLAY_SETTINGS'],
  [['son', 'volume'], 'les paramètres de son', 'android.settings.SOUND_SETTINGS'],
  [['batterie'], 'les paramètres de batterie', 'android.settings.BATTERY_SAVER_SETTINGS'],
  [['localisation', 'gps', 'position'], 'les paramètres de localisation', 'android.settings.LOCATION_SOURCE_SETTINGS'],
  [['applications'], 'les paramètres des applications', 'android.settings.APPLICATION_SETTINGS'],
  [['mode avion', 'avion'], 'les paramètres du mode avion', 'android.settings.AIRPLANE_MODE_SETTINGS']
];
// Le web ne peut pas lister les applis installées : liste d'applis connues (nom, libellé, package, lien web de secours)
var APPS = [
  ['whatsapp', 'WhatsApp', 'com.whatsapp', 'https://web.whatsapp.com'],
  ['youtube', 'YouTube', 'com.google.android.youtube', 'https://m.youtube.com'],
  ['chrome', 'Chrome', 'com.android.chrome', 'https://www.google.com'],
  ['gmail', 'Gmail', 'com.google.android.gm', 'https://mail.google.com'],
  ['maps', 'Google Maps', 'com.google.android.apps.maps', 'https://maps.google.com'],
  ['facebook', 'Facebook', 'com.facebook.katana', 'https://m.facebook.com'],
  ['instagram', 'Instagram', 'com.instagram.android', 'https://www.instagram.com'],
  ['telegram', 'Telegram', 'org.telegram.messenger', 'https://web.telegram.org'],
  ['tiktok', 'TikTok', 'com.zhiliaoapp.musically', 'https://www.tiktok.com'],
  ['camera', 'Appareil photo', 'com.android.camera', null],
  ['calculatrice', 'Calculatrice', 'com.google.android.calculator', null],
  ['play store', 'Play Store', 'com.android.vending', 'https://play.google.com/store'],
  ['telephone', 'Téléphone', 'com.google.android.dialer', null],
  ['messages', 'Messages', 'com.google.android.apps.messaging', null]
];

// Lance un lien "intent:" dans un iframe caché : si le WebView le refuse, la page principale reste intacte
// (naviguer directement vers un schéma inconnu provoque « Page Web non disponible »).
function launch(url) {
  var f = document.createElement('iframe');
  f.style.display = 'none';
  f.src = url;
  document.body.appendChild(f);
  setTimeout(function () { if (f.parentNode) f.parentNode.removeChild(f); }, 2000);
}

function parseCommand(raw) {
  var t = norm(raw);
  var verbs = ['ouvre ', 'ouvrir ', 'lance ', 'lancer ', 'demarre ', 'va dans ', 'va sur ', 'affiche '];
  var verb = verbs.filter(function (v) { return t.indexOf(v) === 0; })[0];
  var isSettingsWord = t.indexOf('parametre') >= 0 || t.indexOf('reglage') >= 0;
  if (!verb && !isSettingsWord) return null;

  var target = verb ? t.slice(verb.length) : t;
  ["l'application ", 'l application ', 'application ', 'appli ', 'les ', 'le ', 'la ', "l'", 'mon ', 'ma ', 'des ', 'du ', 'de '].forEach(function (p) {
    if (target.indexOf(p) === 0) target = target.slice(p.length);
  });
  target = target.replace(/^parametres? /, '').replace(/^reglages /, '').trim();

  for (var i = 0; i < SETTINGS.length; i++) {
    var keys = SETTINGS[i][0];
    if (keys.some(function (k) { return target.indexOf(k) >= 0; })) {
      var act = SETTINGS[i][2], lab = SETTINGS[i][1];
      return { label: 'Ouvrir ' + lab, run: function () { launch(intentUrl('action=' + act)); } };
    }
  }
  if (isSettingsWord && (!target || target === 'parametres' || target === 'reglages' || !verb)) {
    return { label: 'Ouvrir les paramètres', run: function () { launch(intentUrl('action=android.settings.SETTINGS')); } };
  }
  if (!verb || !target) return null;

  var app = APPS.filter(function (a) { return a[0] === target; })[0] ||
            APPS.filter(function (a) { return target.indexOf(a[0]) >= 0 || (a[0].indexOf(target) >= 0 && target.length > 2); })[0];
  if (!app) return null;
  return {
    label: "Ouvrir l'application « " + app[1] + ' »',
    run: function () {
      var fb = app[3] ? ';S.browser_fallback_url=' + encodeURIComponent(app[3]) : '';
      launch(intentUrl('action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;package=' + app[2] + fb));
    }
  };
}

// ---------- Configuration & historique (localStorage protégé) ----------
var GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta', GEMINI_MODEL = 'gemini-3.8-flash';
var GEMINI_FALLBACKS = ['gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-2.5-flash'];
var OPENAI_URL = 'https://api.groq.com/openai/v1', OPENAI_MODEL = 'llama-3.1-8b-instant';
var DEFAULTS = { provider: 'gemini', url: GEMINI_URL, key: '', model: GEMINI_MODEL, speak: true };
function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
function cfg() {
  var s = {}; try { s = JSON.parse(store('boots_cfg') || '{}'); } catch (e) {}
  var c = Object.assign({}, DEFAULTS, s);
  var key = String(c.key || '').trim();
  var legacy = !s.provider;                       // ancienne config (avant le choix du fournisseur)
  if (/^(AIza|AQ\.)/.test(key)) c.provider = 'gemini';   // clés Google (« AIza… » ou « AQ.… ») : jamais envoyées à un autre fournisseur
  else if (legacy) c.provider = (s.url || s.key) ? 'openai' : 'gemini';
  if (c.provider === 'gemini') {
    if (!String(c.url || '').trim() || legacy || /groq|openai/i.test(c.url)) c.url = GEMINI_URL;
    if (!/^gemini/i.test(String(c.model || ''))) c.model = GEMINI_MODEL;
  }
  return c;
}
function needsKey(c) { return c.provider === 'gemini' || !/localhost|127\.0\.0\.1|192\.168\./.test(c.url); }
var chatHistory = [];           // {role:'user'|'assistant', content}
function loadHistory() { try { chatHistory = JSON.parse(store('boots_hist') || '[]'); } catch (e) { chatHistory = []; } if (!Array.isArray(chatHistory)) chatHistory = []; }
function saveHistory() { chatHistory = chatHistory.slice(-30); store('boots_hist', JSON.stringify(chatHistory)); }

// ---------- Interface ----------
var busy = false;
function setStatus(txt, cls) { var s = $('status'); s.textContent = txt; s.className = 'status ' + (cls || ''); }
function scrollDown() { var c = $('chat'); c.scrollTop = c.scrollHeight; }
function hideWelcome() { $('welcome').hidden = true; }

function addMsg(kind, text) {
  hideWelcome();
  var d = document.createElement('div');
  d.className = 'msg ' + kind;
  d.textContent = text;
  $('messages').appendChild(d);
  scrollDown();
  return d;
}
function showTyping() {
  var d = document.createElement('div'); d.className = 'typing'; d.id = 'typing';
  d.innerHTML = '<i></i><i></i><i></i>';
  $('messages').appendChild(d); scrollDown();
}
function hideTyping() { var t = $('typing'); if (t) t.remove(); }

function speak(msg) {
  if (!cfg().speak || !('speechSynthesis' in window)) return;
  try { speechSynthesis.cancel(); var u = new SpeechSynthesisUtterance(msg.slice(0, 400)); u.lang = 'fr-FR'; speechSynthesis.speak(u); } catch (e) {}
}
function reply(text, kind) { addMsg(kind || 'ai', text); if (!kind) speak(text); }

function updateBanner() {
  var b = $('banner'), c = cfg();
  if (!navigator.onLine) {
    b.className = 'banner'; b.hidden = false;
    b.textContent = "Hors connexion : les commandes (ouvrir une appli ou les paramètres) marchent, mais pas les réponses de l'IA.";
    setStatus('Hors connexion', 'err');
  } else if (!c.key.trim() && needsKey(c)) {
    b.className = 'banner info'; b.hidden = false;
    b.innerHTML = 'Pour activer les réponses IA, ajoute ta clé API. <button type="button" id="bannerCfg">Configurer</button>';
    $('bannerCfg').onclick = showSettings;
    setStatus('API non configurée', '');
  } else { b.hidden = true; setStatus('Prêt', 'ok'); }
}

// ---------- Traitement d'une demande ----------
function handle(text) {
  text = (text || '').trim();
  if (!text || busy) return;
  addMsg('user', text);
  var action = parseCommand(text);
  if (action) return confirmAction(action);
  askAi(text);
}

function confirmAction(action) {
  hideWelcome();
  var d = document.createElement('div'); d.className = 'msg action';
  d.innerHTML = '<div class="q"></div><div class="btns"><button type="button" class="btn-no">Non</button><button type="button" class="btn-yes">Oui</button></div>';
  d.querySelector('.q').textContent = action.label + ' ?';
  var yes = d.querySelector('.btn-yes'), no = d.querySelector('.btn-no');
  var done = function (msg, kind) { yes.disabled = no.disabled = true; reply(msg, kind); };
  no.onclick = function () { done('Action annulée.'); };
  yes.onclick = function () {
    try {
      action.run();
      done("Demande envoyée à Android : " + action.label + ". Si rien ne s'ouvre, ton convertisseur HTML vers APK bloque cette action (voir README).");
    } catch (e) { done("Impossible d'exécuter l'action : " + e.message, 'err'); }
  };
  $('messages').appendChild(d); scrollDown();
}

function setBusy(b) { busy = b; $('btnSend').disabled = b; if (b) setStatus('Réflexion…', 'busy'); else updateBanner(); }

function apiError(status, txt) {
  var m = txt.slice(0, 300), reason = '';
  try { var j = JSON.parse(txt); if (j.error && j.error.message) m = j.error.message; reason = JSON.stringify(j.error && j.error.details || '') + (j.error && j.error.status || ''); } catch (e) {}
  var hint = '';
  var tokenType = /ACCESS_TOKEN_TYPE_UNSUPPORTED/.test(txt) || /ACCESS_TOKEN_TYPE_UNSUPPORTED/.test(reason);
  if (tokenType) hint = " Cette clé (format « AQ. ») est refusée par l'API Google : problème connu côté Google pour certains comptes/modèles. Essaie un autre modèle (bouton « Modèles »), crée une nouvelle clé dans Google AI Studio, ou utilise Groq (gratuit) via « Compatible OpenAI ».";
  else if (status === 400 && /api key/i.test(m)) hint = " Vérifie ta clé Gemini (« AIza… » ou « AQ.… »), sans espace ni retour à la ligne.";
  else if (status === 401 || status === 403) hint = ' Clé refusée, ou API non autorisée pour cette clé.';
  else if (status === 404) hint = " Modèle introuvable : utilise le bouton « Modèles » dans ⚙ pour choisir un modèle disponible.";
  else if (status === 429) hint = ' Quota dépassé (niveau gratuit) : réessaie dans un moment.';
  else if (status === 503) hint = ' Service Google surchargé : réessaie.';
  var e = new Error('Erreur API (' + status + ') : ' + m + hint);
  e.status = status; e.tokenType = tokenType;
  return e;
}
function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

async function httpJson(url, headers, body, timeoutMs) {
  var ctrl = new AbortController(), timer = setTimeout(function () { ctrl.abort(); }, timeoutMs);
  try {
    var r = await fetch(url, { method: 'POST', headers: headers, body: JSON.stringify(body), signal: ctrl.signal });
    var txt = await r.text();
    if (!r.ok) throw apiError(r.status, txt);
    return JSON.parse(txt);
  } catch (e) {
    if (e.name === 'AbortError') throw new Error("Délai dépassé : l'API n'a pas répondu.");
    if (e instanceof TypeError) throw new Error("Impossible de joindre l'API (" + e.message + "). Vérifie la connexion, l'URL, et que le service autorise les requêtes depuis une application web (CORS).");
    throw e;
  } finally { clearTimeout(timer); }
}

async function geminiOnce(c, model, messages) {
  var sys = messages.filter(function (m) { return m.role === 'system'; }).map(function (m) { return m.content; }).join('\n');
  var turns = messages.filter(function (m) { return m.role !== 'system'; });
  while (turns.length && turns[0].role !== 'user') turns.shift();
  var base = c.url.trim().replace(/\/+$/, '');
  // API Gemini native : POST /models/{modèle}:generateContent, clé dans l'en-tête x-goog-api-key
  var url = base + '/models/' + encodeURIComponent(model) + ':generateContent';
  var body = { contents: turns.map(function (m) { return { role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }; }) };
  if (sys) body.systemInstruction = { parts: [{ text: sys }] };
  var data = await httpJson(url, { 'Content-Type': 'application/json', 'x-goog-api-key': c.key.trim() }, body, 30000);
  var cand = data.candidates && data.candidates[0];
  var out = cand && cand.content && cand.content.parts ? cand.content.parts.map(function (p) { return p.text || ''; }).join('') : '';
  if (!out.trim()) {
    var why = (data.promptFeedback && data.promptFeedback.blockReason) || (cand && cand.finishReason) || 'réponse vide';
    var e = new Error("Gemini n'a renvoyé aucun texte (" + why + ').'); e.noFallback = !!(data.promptFeedback && data.promptFeedback.blockReason); throw e;
  }
  return out.trim();
}

// Gemini : réessaie une fois si surcharge/quota, puis bascule sur un autre modèle si le premier échoue
async function geminiCall(c, messages) {
  var okModel = store('boots_model_ok');
  var chain = [okModel, c.model.trim()].concat(GEMINI_FALLBACKS).filter(function (m, i, a) { return m && a.indexOf(m) === i; });
  var firstErr = null, tried = [];
  for (var i = 0; i < chain.length; i++) {
    var model = chain[i]; tried.push(model);
    for (var attempt = 0; attempt < 2; attempt++) {
      try {
        var out = await geminiOnce(c, model, messages);
        if (model !== okModel) store('boots_model_ok', model);
        return out;
      } catch (e) {
        if (!firstErr) firstErr = e;
        if ((e.status === 429 || e.status === 503) && attempt === 0) { await sleep(1500); continue; }
        var fatal = e.noFallback || !e.status && !/aucun texte/.test(e.message) ||
                    e.status === 400 || ((e.status === 401 || e.status === 403) && !e.tokenType);
        if (fatal) throw e;
        break; // essaie le modèle suivant
      }
    }
  }
  firstErr.message += ' (modèles essayés : ' + tried.join(', ') + ')';
  throw firstErr;
}

async function callApi(messages, maxTokens) {
  var c = cfg();
  if (c.provider === 'gemini') return geminiCall(c, messages);
  // API compatible OpenAI (Groq, OpenRouter, Ollama…)
  var key = c.key.trim(), headers = { 'Content-Type': 'application/json' };
  if (key) headers.Authorization = 'Bearer ' + key;
  var body = { model: c.model.trim(), messages: messages };
  if (maxTokens) body.max_tokens = maxTokens;
  var data = await httpJson(c.url.trim().replace(/\/+$/, '') + '/chat/completions', headers, body, 45000);
  return String(data.choices[0].message.content).trim();
}

async function askAi(question) {
  var c = cfg();
  if (!navigator.onLine) return reply("Pas de connexion Internet : je ne peux pas interroger l'IA. Les commandes d'ouverture d'applis restent disponibles.", 'err');
  if (!c.key.trim() && needsKey(c)) return reply("Aucune clé API. Touche l'icône ⚙ et colle ta clé Google Gemini (ou configure un autre fournisseur).", 'err');
  chatHistory.push({ role: 'user', content: question });
  setBusy(true); showTyping();
  try {
    var msgs = [{ role: 'system', content: "Tu es Boots AI, un assistant vocal Android. Réponds en français, de façon claire et concise." }].concat(chatHistory.slice(-10));
    var ans = await callApi(msgs);
    chatHistory.push({ role: 'assistant', content: ans }); saveHistory();
    hideTyping(); reply(ans);
  } catch (e) {
    chatHistory.pop(); hideTyping(); reply(e.message, 'err');
  }
  setBusy(false);
}

// ---------- Voix ----------
var rec = null;
function startVoice() {
  var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) return reply("Reconnaissance vocale indisponible ici (fréquent dans une APK). Utilise le micro du clavier Android dans le champ de saisie.", 'err');
  if (rec) { rec.stop(); return; }
  rec = new SR(); rec.lang = 'fr-FR'; rec.interimResults = false; rec.maxAlternatives = 1;
  rec.onstart = function () { $('btnMic').classList.add('on'); setStatus('Je t\'écoute…', 'busy'); };
  rec.onresult = function (e) { var t = e.results[0][0].transcript; if (t) handle(t); };
  rec.onerror = function (e) { reply('Erreur micro : ' + e.error + (e.error === 'not-allowed' ? " (autorise le micro pour l'application)" : ''), 'err'); };
  rec.onend = function () { $('btnMic').classList.remove('on'); rec = null; updateBanner(); };
  try { rec.start(); } catch (e) { rec = null; reply('Impossible de démarrer le micro : ' + e.message, 'err'); }
}

// ---------- Paramètres ----------
var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
function openSheet(html) { $('sheet').innerHTML = html; $('overlay').hidden = false; }
function closeSheet() { $('overlay').hidden = true; $('sheet').innerHTML = ''; }

function showSettings() {
  var c = cfg();
  openSheet('<h2>Paramètres API</h2><p class="hint">La clé reste sur ce téléphone et n\'est envoyée qu\'au service choisi ci-dessous.</p>' +
    '<label class="f" for="fProv">Fournisseur</label><select id="fProv"><option value="gemini"' + (c.provider === 'gemini' ? ' selected' : '') + '>Google Gemini</option><option value="openai"' + (c.provider === 'openai' ? ' selected' : '') + '>Compatible OpenAI (Groq, OpenRouter, Ollama…)</option></select>' +
    '<label class="f" for="fUrl">URL de l\'API</label><input id="fUrl" type="url" value="' + esc(c.url) + '">' +
    '<label class="f" for="fKey">Clé API</label><input id="fKey" type="password" autocomplete="off" value="' + esc(c.key) + '">' +
    '<label class="f" for="fModel">Modèle</label><input id="fModel" type="text" value="' + esc(c.model) + '">' +
    '<div id="modelList"></div>' +
    '<label class="chk"><input id="fSpeak" type="checkbox"' + (c.speak ? ' checked' : '') + '> Lire les réponses à voix haute</label>' +
    '<div id="testResult"></div>' +
    '<div class="row"><button type="button" id="fModels">Modèles</button><button type="button" id="fTest">Tester</button></div>' +
    '<div class="row"><button type="button" id="fCancel">Fermer</button><button type="button" class="primary" id="fSave">Enregistrer</button></div>');
  var read = function () { return { provider: $('fProv').value, url: $('fUrl').value.trim(), key: $('fKey').value.trim(), model: $('fModel').value.trim(), speak: $('fSpeak').checked }; };
  var persist = function () { store('boots_cfg', JSON.stringify(read())); try { localStorage.removeItem('boots_model_ok'); } catch (e) {} };
  $('fProv').onchange = function () {
    var g = $('fProv').value === 'gemini';
    $('fUrl').value = g ? GEMINI_URL : OPENAI_URL; $('fModel').value = g ? GEMINI_MODEL : OPENAI_MODEL;
  };
  $('fCancel').onclick = closeSheet;
  $('fSave').onclick = function () { persist(); closeSheet(); updateBanner(); reply('Configuration enregistrée.', 'ai'); };
  $('fTest').onclick = async function () {
    var out = $('testResult'); out.style.color = ''; out.textContent = 'Test en cours…';
    persist();
    try { var r = await callApi([{ role: 'user', content: 'Réponds uniquement : OK' }], 10); out.style.color = 'var(--ok)'; out.textContent = '✔ Connexion réussie : ' + r.slice(0, 60); }
    catch (e) { out.style.color = 'var(--danger)'; out.textContent = '✖ ' + e.message; }
  };
  $('fModels').onclick = async function () {
    var out = $('testResult'); out.style.color = '';
    var v = read();
    if (v.provider !== 'gemini') { out.textContent = 'La liste des modèles est disponible pour Google Gemini.'; return; }
    if (!v.key) { out.style.color = 'var(--danger)'; out.textContent = "Saisis d'abord ta clé."; return; }
    out.textContent = 'Chargement des modèles…';
    try {
      var r = await fetch(v.url.replace(/\/+$/, '') + '/models?pageSize=200', { headers: { 'x-goog-api-key': v.key } });
      var txt = await r.text();
      if (!r.ok) throw apiError(r.status, txt);
      var names = (JSON.parse(txt).models || []).filter(function (m) {
        return /gemini/i.test(m.name) && !/tts|image|embed|live|audio|robotics|computer/i.test(m.name) &&
               (m.supportedGenerationMethods || []).indexOf('generateContent') >= 0;
      }).map(function (m) { return m.name.replace(/^models\//, ''); }).slice(0, 30);
      if (!names.length) throw new Error('Aucun modèle Gemini utilisable avec cette clé.');
      out.style.color = 'var(--ok)'; out.textContent = '✔ ' + names.length + ' modèle(s) disponible(s) : choisis-en un.';
      var sel = document.createElement('select');
      sel.innerHTML = '<option value="">— choisir un modèle —</option>' + names.map(function (n) { return '<option>' + esc(n) + '</option>'; }).join('');
      sel.onchange = function () { if (sel.value) $('fModel').value = sel.value; };
      $('modelList').innerHTML = ''; $('modelList').appendChild(sel);
    } catch (e) {
      out.style.color = 'var(--danger)';
      out.textContent = '✖ ' + (e instanceof TypeError ? "Impossible de joindre l'API (" + e.message + ')' : e.message);
    }
  };
}

function newChat() {
  chatHistory = []; saveHistory(); $('messages').innerHTML = ''; $('welcome').hidden = false;
  try { speechSynthesis.cancel(); } catch (e) {}
}

// ---------- Démarrage ----------
function init() {
  loadHistory();
  chatHistory.forEach(function (m) { addMsg(m.role === 'user' ? 'user' : 'ai', m.content); });
  var input = $('input');
  var grow = function () { input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 120) + 'px'; };
  var send = function () { var t = input.value.trim(); if (!t) return; input.value = ''; grow(); handle(t); };
  input.addEventListener('input', grow);
  input.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } });
  $('btnSend').onclick = send;
  $('btnMic').onclick = startVoice;
  $('btnSettings').onclick = showSettings;
  $('btnNew').onclick = newChat;
  $('overlay').addEventListener('click', function (e) { if (e.target === $('overlay')) closeSheet(); });
  Array.prototype.forEach.call(document.querySelectorAll('.chip'), function (b) { b.onclick = function () { handle(b.getAttribute('data-q')); }; });
  window.addEventListener('online', updateBanner);
  window.addEventListener('offline', updateBanner);
  updateBanner();
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
}
if (typeof module !== 'undefined') module.exports = { parseCommand: parseCommand, norm: norm };
