const ok=document.getElementById("okButton"),toast=document.getElementById("toast");
ok.addEventListener("click",()=>{
  toast.textContent="WKWKWK 😂";
  toast.classList.add("show");
  ok.textContent="WKWKWK 🤣";
  setTimeout(()=>toast.classList.remove("show"),2000);
});
