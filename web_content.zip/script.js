document.getElementById('orderForm').addEventListener('submit', function(e){
  e.preventDefault();
  const msg=document.getElementById('message');
  msg.textContent='Demo order submitted successfully.';
  this.reset();
});