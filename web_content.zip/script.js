const input = document.getElementById("searchInput");
const searchBtn = document.getElementById("searchBtn");
const resultsSection = document.getElementById("resultsSection");
const loading = document.getElementById("loading");
const resultsLayout = document.getElementById("resultsLayout");
const resultList = document.getElementById("resultList");
const resultCount = document.getElementById("resultCount");
const resultsTitle = document.getElementById("resultsTitle");
const knowledge = document.getElementById("knowledge");
const home = document.getElementById("home");
const themeBtn = document.getElementById("themeBtn");
const brand = document.querySelector(".brand");

const TITULO_BASE = document.title;

// Evita "race conditions": só o pedido mais recente pode escrever resultados.
let pesquisaAtual = 0;
let ultimaPergunta = "";

async function pesquisar(pergunta) {
    pergunta = (pergunta ?? input.value).trim();

    if (!pergunta) {
        input.focus();
        return;
    }

    input.value = pergunta;
    ultimaPergunta = pergunta;

    const idPesquisa = ++pesquisaAtual;

    resultsSection.style.display = "block";
    home.style.minHeight = "auto";

    searchBtn.disabled = true;
    loading.style.display = "flex";
    resultsLayout.style.display = "none";

    resultList.innerHTML = "";
    knowledge.innerHTML = "";

    resultsTitle.textContent = `Resultados para "${pergunta}"`;
    resultCount.textContent = "";
    document.title = `${pergunta} — ${TITULO_BASE}`;

    setTimeout(() => {
        resultsSection.scrollIntoView({ behavior: "smooth" });
    }, 100);

    if (!navigator.onLine) {
        if (idPesquisa === pesquisaAtual) {
            mostrarErro("Estás offline. Verifica a tua ligação à Internet.");
        }
        searchBtn.disabled = false;
        return;
    }

    try {
        const searchURL =
            "https://pt.wikipedia.org/w/rest.php/v1/search/page" +
            "?q=" +
            encodeURIComponent(pergunta) +
            "&limit=10";

        const response = await fetch(searchURL);

        if (!response.ok) {
            throw new Error(`Erro HTTP: ${response.status}`);
        }

        const data = await response.json();
        const paginas = data.pages || [];

        // Se entretanto foi disparada outra pesquisa, ignora esta resposta.
        if (idPesquisa !== pesquisaAtual) return;

        if (paginas.length === 0) {
            mostrarVazio(pergunta);
            return;
        }

        resultCount.textContent =
            `${paginas.length} resultado(s) encontrado(s)`;

        await carregarConhecimento(paginas[0], idPesquisa);

        if (idPesquisa !== pesquisaAtual) return;

        paginas.forEach(criarResultado);

        loading.style.display = "none";
        resultsLayout.style.display = "grid";
    } catch (erro) {
        console.error(erro);
        if (idPesquisa === pesquisaAtual) {
            mostrarErro();
        }
    } finally {
        if (idPesquisa === pesquisaAtual) {
            searchBtn.disabled = false;
        }
    }
}

function criarResultado(pagina) {
    const card = document.createElement("article");
    card.className = "result-card";

    const title = escapeHTML(pagina.title || "Sem título");
    const description = escapeHTML(
        pagina.description || "Artigo da Wikipedia"
    );

    const excerpt = sanitizarExcerto(
        pagina.excerpt || "Sem descrição disponível."
    );

    const url =
        pagina.content_urls?.desktop?.page ||
        `https://pt.wikipedia.org/wiki/${encodeURIComponent(
            pagina.key || pagina.title
        )}`;

    card.innerHTML = `
        <h3>${title}</h3>

        <div class="result-description">
            ${description}
        </div>

        <div class="result-excerpt">
            ${excerpt}
        </div>

        <a
            class="result-link"
            href="${url}"
            target="_blank"
            rel="noopener noreferrer">
            Ler artigo completo →
        </a>
    `;

    resultList.appendChild(card);
}

async function carregarConhecimento(pagina, idPesquisa) {
    const title = pagina.title;

    try {
        const summaryURL =
            "https://pt.wikipedia.org/api/rest_v1/page/summary/" +
            encodeURIComponent(title);

        const response = await fetch(summaryURL);

        if (!response.ok) {
            throw new Error("Resumo indisponível");
        }

        const data = await response.json();

        // Se entretanto foi disparada outra pesquisa, não pisa os resultados dela.
        if (idPesquisa !== pesquisaAtual) return;

        const image = data.thumbnail?.source;
        const description =
            data.description || "Informação da Wikipedia.";
        const extract =
            data.extract || "Não foi possível obter um resumo.";

        const articleURL =
            data.content_urls?.desktop?.page ||
            pagina.content_urls?.desktop?.page ||
            "#";

        knowledge.innerHTML = `
            ${
                image
                    ? `<img
                        class="knowledge-image"
                        src="${image}"
                        alt="${escapeHTML(title)}"
                        loading="lazy">`
                    : ""
            }

            <div class="knowledge-content">
                <div class="knowledge-label">
                    Visão geral
                </div>

                <h2>${escapeHTML(title)}</h2>

                <div class="knowledge-description">
                    ${escapeHTML(description)}
                </div>

                <div class="knowledge-text">
                    ${escapeHTML(extract)}
                </div>

                <a
                    class="knowledge-link"
                    href="${articleURL}"
                    target="_blank"
                    rel="noopener noreferrer">
                    Ver na Wikipedia
                </a>
            </div>
        `;
    } catch (erro) {
        if (idPesquisa !== pesquisaAtual) return;

        knowledge.innerHTML = `
            <div class="knowledge-content">
                <div class="knowledge-label">
                    Visão geral
                </div>

                <h2>${escapeHTML(title)}</h2>

                <div class="knowledge-text">
                    O resumo detalhado não está disponível neste momento.
                </div>
            </div>
        `;
    }
}

function mostrarVazio(pergunta) {
    loading.style.display = "none";
    resultsLayout.style.display = "block";

    resultList.innerHTML = `
        <div class="message">
            <h3>Nenhum resultado encontrado</h3>
            <p>
                Não encontramos resultados para
                "${escapeHTML(pergunta)}".
                Tenta usar outras palavras.
            </p>
        </div>
    `;
}

function mostrarErro(mensagem) {
    loading.style.display = "none";
    resultsLayout.style.display = "block";

    resultList.innerHTML = `
        <div class="message">
            <h3>Não foi possível pesquisar</h3>
            <p>
                ${escapeHTML(
                    mensagem ||
                        "Verifica a tua ligação à Internet e tenta novamente."
                )}
            </p>
            <button class="retry-btn" type="button" id="retryBtn">
                Tentar novamente
            </button>
        </div>
    `;

    document
        .getElementById("retryBtn")
        ?.addEventListener("click", () => pesquisar(ultimaPergunta));
}

function escapeHTML(text) {
    const div = document.createElement("div");
    div.textContent = text || "";
    return div.innerHTML;
}

// O "excerpt" da API vem com <span class="searchmatch">termo</span> a
// marcar o termo pesquisado. Escapamos tudo (para não injetar HTML
// arbitrário) e só depois "reabrimos" esse padrão específico como <mark>,
// para manter o destaque em segurança.
function sanitizarExcerto(text) {
    const escapado = escapeHTML(text);
    return escapado
        .replace(/&lt;span class="searchmatch"&gt;/g, "<mark>")
        .replace(/&lt;\/span&gt;/g, "</mark>");
}

// localStorage pode lançar erro (ex.: Safari em modo privado) — nunca deve
// travar o resto do site por causa da preferência de tema.
function guardarPreferencia(chave, valor) {
    try {
        localStorage.setItem(chave, valor);
    } catch (erro) {
        console.warn("Não foi possível guardar a preferência:", erro);
    }
}

function lerPreferencia(chave) {
    try {
        return localStorage.getItem(chave);
    } catch (erro) {
        return null;
    }
}

input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        pesquisar();
    }
});

searchBtn.addEventListener("click", () => pesquisar());

document.querySelectorAll(".suggestion").forEach((botao) => {
    botao.addEventListener("click", () => {
        pesquisar(botao.textContent.trim());
    });
});

// Clicar na marca "Busca" volta ao ecrã inicial, sem recarregar a página.
brand?.addEventListener("click", () => {
    resultsSection.style.display = "none";
    resultsLayout.style.display = "none";
    home.style.minHeight = "";
    input.value = "";
    document.title = TITULO_BASE;
    pesquisaAtual++; // invalida qualquer pedido em curso
    window.scrollTo({ top: 0, behavior: "smooth" });
    input.focus();
});

themeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark");

    const dark =
        document.body.classList.contains("dark");

    guardarPreferencia("busca-theme", dark ? "dark" : "light");
});

if (lerPreferencia("busca-theme") === "dark") {
    document.body.classList.add("dark");
}
