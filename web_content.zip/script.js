const setup=document.getElementById('setup');
const callScreen=document.getElementById('callScreen');
const nameInput=document.getElementById('name');
const save=document.getElementById('save');
const callerName=document.getElementById('callerName');
const callerNumber=document.getElementById('callerNumber');
const timer=document.getElementById('timer');

let start=0;
let active=false;
let raf=0;

const saved=localStorage.getItem('callerName');
if(saved) nameInput.value=saved;

function randomIndianNumber(){
  let n=String(6+Math.floor(Math.random()*4));
  for(let i=0;i<9;i++) n+=Math.floor(Math.random()*10);
  return '+91 '+n.slice(0,5)+' '+n.slice(5);
}

function fmt(ms){
  const s=Math.max(0,Math.floor(ms/1000));
  const m=Math.floor(s/60);
  const sec=s%60;
  return String(m).padStart(2,'0')+':'+String(sec).padStart(2,'0');
}

function tick(){
  if(!active)return;
  timer.textContent=fmt(Date.now()-start);
  raf=requestAnimationFrame(tick);
}

function begin(){
  const n=nameInput.value.trim()||'Unknown';
  if(save.checked)localStorage.setItem('callerName',n);
  callerName.textContent=n;
  callerNumber.textContent=randomIndianNumber()+' India';
  start=Date.now();
  active=true;
  setup.classList.add('hidden');
  callScreen.classList.remove('hidden');
  cancelAnimationFrame(raf);
  tick();
}

function end(){
  active=false;
  cancelAnimationFrame(raf);
  timer.textContent='00:00';
  callScreen.classList.add('hidden');
  setup.classList.remove('hidden');
}

document.getElementById('call').addEventListener('click',begin);
document.getElementById('end').addEventListener('click',end);

document.addEventListener('visibilitychange',()=>{
  if(active) timer.textContent=fmt(Date.now()-start);
});
