/* =====================================================
   STAYFLOW HOTEL MANAGER
   SCRIPT.JS
   PART 1 — CORE + DATABASE + HELPERS
===================================================== */

"use strict";

/* =====================================================
   APP CONFIG
===================================================== */

const APP_NAME = "StayFlow Hotel Manager";

const TOTAL_ROOMS = 25;

const HOTEL_DAY_HOUR = 12;

const STORAGE_KEY =
    "stayflow_hotel_data_v1";


/* =====================================================
   SHORT DOM HELPER
===================================================== */

function $(id) {

    return document.getElementById(id);

}


/* =====================================================
   DEFAULT DATA
===================================================== */

function createDefaultData() {

    return {

        guests: [],

        printQueue: [],

        roomHistory: [],

        settings: {

            totalRooms: TOTAL_ROOMS,

            hotelDayHour: HOTEL_DAY_HOUR,

            autoDeleteAfterPrint: false

        }

    };

}


/* =====================================================
   APP DATA
===================================================== */

let data = createDefaultData();


/* =====================================================
   LOAD DATA
===================================================== */

function load() {

    try {

        const saved =
            localStorage.getItem(
                STORAGE_KEY
            );

        if (!saved) {

            data =
                createDefaultData();

            return;

        }

        const parsed =
            JSON.parse(saved);

        data = {

            ...createDefaultData(),

            ...parsed

        };

        if (!Array.isArray(data.guests)) {

            data.guests = [];

        }

        if (!Array.isArray(data.printQueue)) {

            data.printQueue = [];

        }

        if (!Array.isArray(data.roomHistory)) {

            data.roomHistory = [];

        }

        if (!data.settings) {

            data.settings =
                createDefaultData().settings;

        }

    }

    catch (error) {

        console.error(
            "StayFlow load error:",
            error
        );

        data =
            createDefaultData();

    }

}


/* =====================================================
   SAVE DATA
===================================================== */

function save() {

    try {

        localStorage.setItem(
            STORAGE_KEY,
            JSON.stringify(data)
        );

    }

    catch (error) {

        console.error(
            "StayFlow save error:",
            error
        );

        toast(
            "Storage Error",
            "Data save nahi ho paya."
        );

    }

}


/* =====================================================
   TOAST
===================================================== */

function toast(
    title,
    message
) {

    const box =
        $("toast");

    if (!box) {

        alert(
            title +
            "\n\n" +
            message
        );

        return;

    }

    const titleBox =
        box.querySelector(
            ".toast-title"
        );

    const messageBox =
        box.querySelector(
            ".toast-message"
        );

    if (titleBox) {

        titleBox.textContent =
            title;

    }

    if (messageBox) {

        messageBox.textContent =
            message;

    }

    box.classList.add(
        "show"
    );

    clearTimeout(
        window.__stayflowToastTimer
    );

    window.__stayflowToastTimer =
        setTimeout(
            function () {

                box.classList.remove(
                    "show"
                );

            },
            2800
        );

}


/* =====================================================
   TEXT ESCAPE
===================================================== */

function esc(value) {

    return String(
        value ?? ""
    )
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );

}


/* =====================================================
   INITIALS
===================================================== */

function initials(name) {

    const text =
        String(
            name || "Guest"
        ).trim();

    if (!text) {

        return "G";

    }

    const parts =
        text.split(/\s+/);

    if (parts.length === 1) {

        return parts[0]
            .substring(0, 2)
            .toUpperCase();

    }

    return (
        parts[0][0] +
        parts[1][0]
    ).toUpperCase();

}


/* =====================================================
   MONEY
===================================================== */

function money(value) {

    const amount =
        Number(value) || 0;

    return (
        "₹" +
        amount.toLocaleString(
            "en-IN",
            {
                minimumFractionDigits: 0,
                maximumFractionDigits: 2
            }
        )
    );

}


/* =====================================================
   DATE TEXT
===================================================== */

function dateText(value) {

    if (!value) {

        return "-";

    }

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "-";

    }

    return date.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =====================================================
   DATE + TIME TEXT
===================================================== */

function dateTimeText(value) {

    if (!value) {

        return "-";

    }

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "-";

    }

    return date.toLocaleString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


/* =====================================================
   TODAY DATE FOR INPUT
===================================================== */

function localDateTimeValue(
    date = new Date()
) {

    const pad =
        function (number) {

            return String(
                number
            ).padStart(
                2,
                "0"
            );

        };

    return (
        date.getFullYear() +
        "-" +
        pad(
            date.getMonth() + 1
        ) +
        "-" +
        pad(
            date.getDate()
        ) +
        "T" +
        pad(
            date.getHours()
        ) +
        ":" +
        pad(
            date.getMinutes()
        )
    );

}


/* =====================================================
   BOOKING ID
===================================================== */

function generateBookingId() {

    const now =
        new Date();

    const datePart =
        String(
            now.getFullYear()
        ).slice(-2) +
        String(
            now.getMonth() + 1
        ).padStart(2, "0") +
        String(
            now.getDate()
        ).padStart(2, "0");

    const randomPart =
        Math.floor(
            1000 +
            Math.random() * 9000
        );

    return (
        "BK" +
        datePart +
        randomPart
    );

}


/* =====================================================
   HOTEL DAY
===================================================== */

function hotelDayKey(
    value = new Date()
) {

    const date =
        new Date(value);

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {

        return "";

    }

    /*
       Hotel day changes at 12:00 PM.
       Before 12 PM = previous hotel day.
    */

    if (
        date.getHours() <
        HOTEL_DAY_HOUR
    ) {

        date.setDate(
            date.getDate() - 1
        );

    }

    const year =
        date.getFullYear();

    const month =
        String(
            date.getMonth() + 1
        ).padStart(
            2,
            "0"
        );

    const day =
        String(
            date.getDate()
        ).padStart(
            2,
            "0"
        );

    return (
        year +
        "-" +
        month +
        "-" +
        day
    );

}


/* =====================================================
   ACTIVE GUESTS
===================================================== */

function activeGuests() {

    return data.guests.filter(
        function (guest) {

            return (
                guest.status ===
                "active"
            );

        }
    );

}


/* =====================================================
   ROOM NUMBERS OF ONE GUEST
===================================================== */

function guestRooms(
    guest
) {

    if (
        Array.isArray(
            guest.roomNumbers
        )
    ) {

        return guest.roomNumbers
            .map(Number)
            .filter(
                function (room) {

                    return (
                        room >= 1 &&
                        room <= TOTAL_ROOMS
                    );

                }
            );

    }

    if (
        guest.roomNumber
    ) {

        return [
            Number(
                guest.roomNumber
            )
        ];

    }

    return [];

}


/* =====================================================
   ALL OCCUPIED ROOMS
===================================================== */

function occupiedRoomNumbers() {

    const rooms = [];

    activeGuests()
        .forEach(
            function (guest) {

                guestRooms(
                    guest
                )
                .forEach(
                    function (room) {

                        if (
                            rooms.indexOf(
                                room
                            ) === -1
                        ) {

                            rooms.push(
                                room
                            );

                        }

                    }
                );

            }
        );

    return rooms.sort(
        function (a, b) {

            return a - b;

        }
    );

}


/* =====================================================
   CHECK IF ROOM IS OCCUPIED
===================================================== */

function isRoomOccupied(
    roomNumber
) {

    return (
        occupiedRoomNumbers()
            .indexOf(
                Number(
                    roomNumber
                )
            ) !== -1
    );

}


/* =====================================================
   GET GUEST BY ROOM
===================================================== */

function guestByRoom(
    roomNumber
) {

    const room =
        Number(
            roomNumber
        );

    return activeGuests()
        .find(
            function (guest) {

                return (
                    guestRooms(
                        guest
                    ).indexOf(room) !== -1
                );

            }
        ) || null;

}


/* =====================================================
   NIGHTS CALCULATOR
===================================================== */

function calculateNights(
    checkIn,
    checkOut
) {

    if (
        !checkIn ||
        !checkOut
    ) {

        return 0;

    }

    const start =
        new Date(checkIn);

    const end =
        new Date(checkOut);

    if (
        Number.isNaN(
            start.getTime()
        ) ||
        Number.isNaN(
            end.getTime()
        )
    ) {

        return 0;

    }

    const startDate =
        new Date(
            start.getFullYear(),
            start.getMonth(),
            start.getDate()
        );

    const endDate =
        new Date(
            end.getFullYear(),
            end.getMonth(),
            end.getDate()
        );

    const difference =
        endDate.getTime() -
        startDate.getTime();

    const nights =
        Math.round(
            difference /
            86400000
        );

    return Math.max(
        1,
        nights
    );

}

function calculateNights(
    checkIn,
    checkOut
) {

    if (
        !checkIn ||
        !checkOut
    ) {

        return 0;

    }

    const start =
        new Date(checkIn);

    const end =
        new Date(checkOut);

    if (
        Number.isNaN(
            start.getTime()
        ) ||
        Number.isNaN(
            end.getTime()
        )
    ) {

        return 0;

    }

    const startDate =
        new Date(
            start.getFullYear(),
            start.getMonth(),
            start.getDate()
        );

    const endDate =
        new Date(
            end.getFullYear(),
            end.getMonth(),
            end.getDate()
        );

    const difference =
        endDate.getTime() -
        startDate.getTime();

    const nights =
        Math.round(
            difference /
            86400000
        );

    return Math.max(
        1,
        nights
    );

}
/* =====================================================
   STAYFLOW HOTEL MANAGER
   PART 2 — NAVIGATION + DASHBOARD + 25 ROOMS
===================================================== */


/* =====================================================
   PAGE NAVIGATION
===================================================== */

function navigate(pageName) {

    const pages = document.querySelectorAll(
        ".page"
    );

    pages.forEach(function (page) {

        page.classList.remove(
            "active"
        );

    });


    const target =
        $(pageName + "Page");

    if (target) {

        target.classList.add(
            "active"
        );

    }


    const navItems =
        document.querySelectorAll(
            ".nav-item"
        );

    navItems.forEach(function (item) {

        item.classList.remove(
            "active"
        );

        if (
            item.getAttribute(
                "data-page"
            ) === pageName
        ) {

            item.classList.add(
                "active"
            );

        }

    });

}


/* =====================================================
   NAVIGATION SETUP
===================================================== */

function navSetup() {

    document
        .querySelectorAll(
            "[data-page]"
        )
        .forEach(function (item) {

            item.addEventListener(
                "click",
                function (event) {

                    event.preventDefault();

                    const page =
                        item.getAttribute(
                            "data-page"
                        );

                    if (!page) {
                        return;
                    }

                    navigate(page);

                }
            );

        });

}


/* =====================================================
   ROOM HTML
===================================================== */

function createRoomElement(
    roomNumber
) {

    const occupied =
        isRoomOccupied(
            roomNumber
        );

    const button =
        document.createElement(
            "button"
        );

    button.type =
        "button";

    button.className =
        "room-item " +
        (
            occupied
                ? "occupied"
                : "available"
        );

    button.setAttribute(
        "data-room",
        roomNumber
    );


    const number =
        String(
            roomNumber
        ).padStart(
            2,
            "0"
        );


    button.innerHTML = `

        <span class="room-number">
            ${number}
        </span>

        <span class="room-status">
            ${
                occupied
                    ? "Occupied"
                    : "Available"
            }
        </span>

    `;


    button.addEventListener(
        "click",
        function () {

            roomDetails(
                roomNumber
            );

        }
    );


    return button;

}


/* =====================================================
   RENDER 25 ROOMS
===================================================== */

function renderRoomGrid(
    elementId
) {

    const container =
        $(elementId);

    if (!container) {
        return;
    }


    container.innerHTML =
        "";


    for (
        let room = 1;
        room <= TOTAL_ROOMS;
        room++
    ) {

        const element =
            createRoomElement(
                room
            );

        container.appendChild(
            element
        );

    }

}


/* =====================================================
   ROOM STATISTICS
===================================================== */

function updateRoomStatistics() {

    const occupied =
        occupiedRoomNumbers().length;


    const available =
        TOTAL_ROOMS -
        occupied;


    const percentage =
        Math.round(
            (
                occupied /
                TOTAL_ROOMS
            ) * 100
        );


    if (
        $("totalRooms")
    ) {

        $("totalRooms").textContent =
            TOTAL_ROOMS;

    }


    if (
        $("occupiedRooms")
    ) {

        $("occupiedRooms").textContent =
            occupied;

    }


    if (
        $("availableRooms")
    ) {

        $("availableRooms").textContent =
            available;

    }


    if (
        $("occupancyPercent")
    ) {

        $("occupancyPercent").textContent =
            percentage + "%";

    }


    if (
        $("roomCounterOccupied")
    ) {

        $("roomCounterOccupied").textContent =
            occupied;

    }


    if (
        $("roomsOccupiedStat")
    ) {

        $("roomsOccupiedStat").textContent =
            occupied;

    }


    if (
        $("roomsAvailableStat")
    ) {

        $("roomsAvailableStat").textContent =
            available;

    }


    if (
        $("roomsOccupancyStat")
    ) {

        $("roomsOccupancyStat").textContent =
            percentage + "%";

    }

}


/* =====================================================
   RENDER ALL ROOM SECTIONS
===================================================== */

function renderRooms() {

    renderRoomGrid(
        "dashboardRoomGrid"
    );


    renderRoomGrid(
        "fullRoomGrid"
    );


    updateRoomStatistics();

}


/* =====================================================
   ROOM DETAIL
===================================================== */

function roomDetails(
    roomNumber
) {

    const card =
        $("roomDetailCard");

    const title =
        $("selectedRoomNumber");

    const content =
        $("roomDetailContent");


    if (!card || !content) {
        return;
    }


    card.classList.remove(
        "hidden"
    );


    if (title) {

        title.textContent =
            "Room " +
            String(
                roomNumber
            ).padStart(
                2,
                "0"
            );

    }


    const guest =
        guestByRoom(
            roomNumber
        );


    if (!guest) {

        content.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">
                    <i class="fa-solid fa-key"></i>
                </div>

                <h4>
                    Room Available
                </h4>

                <p>
                    Room ${String(roomNumber)
                        .padStart(2, "0")}
                    is ready for the next guest.
                </p>

            </div>

        `;

        return;
    }


    const rooms =
        guestRooms(
            guest
        );


    content.innerHTML = `

        <div class="guest-card">

            <div class="guest-card-top">

                <div class="guest-avatar">
                    ${esc(
                        initials(
                            guest.name
                        )
                    )}
                </div>

                <div class="guest-info">

                    <strong>
                        ${esc(
                            guest.name
                        )}
                    </strong>

                    <span>
                        ${esc(
                            guest.bookingId
                        )}
                    </span>

                </div>

                <span class="guest-status">
                    Active
                </span>

            </div>


            <div class="guest-card-details">

                <div class="guest-detail">

                    <span>
                        Room
                    </span>

                    <strong>
                        ${rooms.join(", ")}
                    </strong>

                </div>


                <div class="guest-detail">

                    <span>
                        Check-in
                    </span>

                    <strong>
                        ${dateText(
                            guest.checkIn
                        )}
                    </strong>

                </div>


                <div class="guest-detail">

                    <span>
                        Payment
                    </span>

                    <strong>
                        ${money(
                            guest.total
                        )}
                    </strong>

                </div>

            </div>


            <button
                type="button"
                class="secondary-btn"
                id="roomCheckoutButton"
            >

                <i
                    class="fa-solid fa-door-open"
                ></i>

                Check Out

            </button>

        </div>

    `;


    const checkoutButton =
        $("roomCheckoutButton");


    if (checkoutButton) {

        checkoutButton.addEventListener(
            "click",
            function () {

                checkout(
                    guest.id
                );

            }
        );

    }

}


/* =====================================================
   CLOSE ROOM DETAIL
===================================================== */

function closeRoomDetails() {

    const card =
        $("roomDetailCard");

    if (!card) {
        return;
    }

    card.classList.add(
        "hidden"
    );

}


/* =====================================================
   DASHBOARD DATE
===================================================== */

function updateDashboardDate() {

    const dateElement =
        $("currentDate");


    if (!dateElement) {
        return;
    }


    const now =
        new Date();


    dateElement.textContent =
        now.toLocaleDateString(
            "en-IN",
            {
                weekday: "short",
                day: "2-digit",
                month: "short"
            }
        );

}


/* =====================================================
   DASHBOARD PAYMENT TOTALS
===================================================== */

function updateDashboardPayments() {

    const todayKey =
        hotelDayKey(
            new Date()
        );


    let online =
        0;

    let cash =
        0;


    data.guests.forEach(
        function (guest) {

            if (
                hotelDayKey(
                    guest.checkIn
                ) !== todayKey
            ) {

                return;

            }


            online +=
                Number(
                    guest.online
                ) || 0;


            cash +=
                Number(
                    guest.cash
                ) || 0;

        }
    );


    const total =
        online +
        cash;


    if (
        $("todayOnline")
    ) {

        $("todayOnline").textContent =
            money(
                online
            );

    }


    if (
        $("todayCash")
    ) {

        $("todayCash").textContent =
            money(
                cash
            );

    }


    if (
        $("todayTotal")
    ) {

        $("todayTotal").textContent =
            money(
                total
            );

    }

}


/* =====================================================
   DASHBOARD GUEST COUNT
===================================================== */

function updateDashboardGuestCount() {

    const todayKey =
        hotelDayKey(
            new Date()
        );


    const count =
        data.guests.filter(
            function (guest) {

                return (
                    hotelDayKey(
                        guest.checkIn
                    ) === todayKey
                );

            }
        ).length;


    const elements =
        document.querySelectorAll(
            "[data-today-guests]"
        );


    elements.forEach(
        function (element) {

            element.textContent =
                count;

        }
    );

}


/* =====================================================
   DASHBOARD RENDER
===================================================== */

function renderDashboard() {

    updateDashboardDate();

    renderRooms();

    updateDashboardPayments();

    updateDashboardGuestCount();

}


/* =====================================================
   ROOM DETAIL CLOSE EVENT
===================================================== */

function setupRoomDetailClose() {

    const closeButton =
        $("closeRoomDetail");


    if (!closeButton) {
        return;
    }


    closeButton.addEventListener(
        "click",
        closeRoomDetails
    );

}


/* =====================================================
   PART 2 TEST
===================================================== */

function part2Test() {

    console.log(
        "StayFlow PART 2 loaded successfully."
    );

}
/* =====================================================
   STAYFLOW HOTEL MANAGER
   PART 3 — GUEST + BOOKING + ROOM + PAYMENT
===================================================== */


/* =====================================================
   FILL ROOM SELECT
===================================================== */

function fillRoomSelect() {

    const select =
        $("guestRoom");

    if (!select) {
        return;
    }


    const current =
        select.value;


    const occupied =
        occupiedRoomNumbers();


    select.innerHTML =
        '<option value="">Select Room</option>';


    for (
        let room = 1;
        room <= TOTAL_ROOMS;
        room++
    ) {

        if (
            occupied.indexOf(room) !== -1
        ) {

            continue;

        }


        const option =
            document.createElement(
                "option"
            );

        option.value =
            room;

        option.textContent =
            "Room " +
            String(room)
                .padStart(2, "0");


        select.appendChild(
            option
        );

    }


    if (
        current &&
        occupied.indexOf(
            Number(current)
        ) === -1
    ) {

        select.value =
            current;

    }

}


/* =====================================================
   EXTRA ROOM SELECTORS
===================================================== */

function setupExtraRoomSelectors() {

    const numberInput =
        $("numberOfRooms");

    const firstSelect =
        $("guestRoom");

    if (
        !numberInput ||
        !firstSelect
    ) {

        return;

    }


    let count =
        Number(
            numberInput.value
        ) || 1;


    count =
        Math.max(
            1,
            Math.min(
                count,
                TOTAL_ROOMS
            )
        );


    let wrapper =
        $("dynamicRoomSelectors");


    if (!wrapper) {

        wrapper =
            document.createElement(
                "div"
            );

        wrapper.id =
            "dynamicRoomSelectors";

        wrapper.style.marginTop =
            "10px";

        firstSelect.parentNode
            .appendChild(
                wrapper
            );

    }


    wrapper.innerHTML =
        "";


    if (count <= 1) {

        return;

    }


    const occupied =
        occupiedRoomNumbers();


    for (
        let index = 2;
        index <= count;
        index++
    ) {

        const select =
            document.createElement(
                "select"
            );

        select.className =
            "form-control";

        select.dataset.roomSelector =
            "extra";


        const defaultOption =
            document.createElement(
                "option"
            );

        defaultOption.value =
            "";

        defaultOption.textContent =
            "Select Room " +
            index;

        select.appendChild(
            defaultOption
        );


        for (
            let room = 1;
            room <= TOTAL_ROOMS;
            room++
        ) {

            if (
                occupied.indexOf(room) !== -1
            ) {

                continue;

            }


            const alreadySelected =
                getSelectedRoomNumbers()
                    .indexOf(room) !== -1;


            if (
                alreadySelected
            ) {

                continue;

            }


            const option =
                document.createElement(
                    "option"
                );

            option.value =
                room;

            option.textContent =
                "Room " +
                String(room)
                    .padStart(2, "0");


            select.appendChild(
                option
            );

        }


        select.style.marginTop =
            "8px";


        wrapper.appendChild(
            select
        );

    }

}


/* =====================================================
   GET SELECTED ROOM NUMBERS
===================================================== */

function getSelectedRoomNumbers() {

    const rooms = [];


    const first =
        $("guestRoom");


    if (
        first &&
        first.value
    ) {

        rooms.push(
            Number(
                first.value
            )
        );

    }


    document
        .querySelectorAll(
            "#dynamicRoomSelectors select"
        )
        .forEach(
            function (select) {

                if (
                    select.value
                ) {

                    rooms.push(
                        Number(
                            select.value
                        )
                    );

                }

            }
        );


    return rooms;

}


/* =====================================================
   PAYMENT TOTAL
===================================================== */

function paymentTotal() {

    const online =
        Number(
            $("onlinePayment")
                ?.value
        ) || 0;


    const cash =
        Number(
            $("cashPayment")
                ?.value
        ) || 0;


    const total =
        online +
        cash;


    if (
        $("guestTotalPayment")
    ) {

        $("guestTotalPayment")
            .value =
            total;

    }

}


/* =====================================================
   OPEN GUEST MODAL
===================================================== */

function openGuestModal() {

    const modal =
        $("guestModal");


    if (!modal) {

        return;

    }


    modal.classList.remove(
        "hidden"
    );


    if ($("guestForm")) {

        $("guestForm").reset();

    }


    if ($("bookingId")) {

        $("bookingId").value =
            generateBookingId();

    }


    if ($("checkInDate")) {

        $("checkInDate").value =
            localDateTimeValue();

    }


    if ($("numberOfRooms")) {

        $("numberOfRooms").value =
            1;

    }


    fillRoomSelect();

    setupExtraRoomSelectors();

    paymentTotal();

}


/* =====================================================
   CLOSE GUEST MODAL
===================================================== */

function closeGuestModal() {

    const modal =
        $("guestModal");


    if (!modal) {

        return;

    }


    modal.classList.add(
        "hidden"
    );

}


/* =====================================================
   VALIDATE BOOKING ID
===================================================== */

function bookingIdExists(
    bookingId
) {

    const value =
        String(
            bookingId || ""
        )
        .trim()
        .toLowerCase();


    return data.guests.some(
        function (guest) {

            return (
                String(
                    guest.bookingId || ""
                )
                .trim()
                .toLowerCase() ===
                value
            );

        }
    );

}


/* =====================================================
   ADD GUEST
===================================================== */

function addGuest(
    event
) {

    event.preventDefault();


    const name =
        $("guestName")
            ?.value
            .trim();


    const bookingId =
        $("bookingId")
            ?.value
            .trim();


    const roomNumbers =
        getSelectedRoomNumbers();


    const numberOfRooms =
        Number(
            $("numberOfRooms")
                ?.value
        ) || 1;


    const idType =
        $("guestIdType")
            ?.value ||
        "Other";


    const checkIn =
        $("checkInDate")
            ?.value;


    const online =
        Number(
            $("onlinePayment")
                ?.value
        ) || 0;


    const cash =
        Number(
            $("cashPayment")
                ?.value
        ) || 0;


    const total =
        online +
        cash;


    /* NAME */

    if (!name) {

        toast(
            "Guest Name Required",
            "Guest ka naam enter karo."
        );

        return;

    }


    /* BOOKING ID */

    if (!bookingId) {

        toast(
            "Booking ID Required",
            "Booking ID enter karo."
        );

        return;

    }


    if (
        bookingIdExists(
            bookingId
        )
    ) {

        toast(
            "Booking ID Exists",
            "Ye Booking ID already use ho rahi hai."
        );

        return;

    }


    /* ROOMS */

    if (
        roomNumbers.length !==
        numberOfRooms
    ) {

        toast(
            "Room Selection",
            "Jitne rooms select kiye hain utne hi rooms choose karo."
        );

        return;

    }


    const uniqueRooms =
        [...new Set(
            roomNumbers
        )];


    if (
        uniqueRooms.length !==
        roomNumbers.length
    ) {

        toast(
            "Duplicate Room",
            "Same room do baar select nahi kar sakte."
        );

        return;

    }


    const occupied =
        occupiedRoomNumbers();


    const alreadyOccupied =
        roomNumbers.some(
            function (room) {

                return (
                    occupied.indexOf(
                        room
                    ) !== -1
                );

            }
        );


    if (
        alreadyOccupied
    ) {

        toast(
            "Room Occupied",
            "Selected room already occupied hai."
        );

        fillRoomSelect();

        setupExtraRoomSelectors();

        return;

    }


    /* CHECK-IN */

    if (!checkIn) {

        toast(
            "Check-in Required",
            "Check-in date/time select karo."
        );

        return;

    }


    /* PAYMENT */

    if (total < 0) {

        toast(
            "Payment Error",
            "Payment amount valid nahi hai."
        );

        return;

    }


    /* CREATE GUEST */

    const guest = {

        id:
            "guest_" +
            Date.now() +
            "_" +
            Math.floor(
                Math.random() *
                10000
            ),

        name:
            name,

        bookingId:
            bookingId,

        roomNumbers:
            uniqueRooms,

        roomNumber:
            uniqueRooms[0],

        numberOfRooms:
            uniqueRooms.length,

        idType:
            idType,

        idFront:
            null,

        idBack:
            null,

        checkIn:
            new Date(
                checkIn
            ).toISOString(),

        checkOut:
            null,

        online:
            online,

        cash:
            cash,

        total:
            total,

        nights:
            0,

        status:
            "active",

        createdAt:
            new Date().toISOString(),

        paymentHistory: [

            {

                date:
                    new Date().toISOString(),

                hotelDay:
                    hotelDayKey(
                        new Date()
                    ),

                online:
                    online,

                cash:
                    cash,

                total:
                    total

            }

        ],

        roomHistory: [

            {

                date:
                    new Date().toISOString(),

                rooms:
                    uniqueRooms.slice(),

                action:
                    "check_in"

            }

        ]

    };


    data.guests.push(
        guest
    );


    /* ROOM HISTORY */

    data.roomHistory.push({

        date:
            new Date().toISOString(),

        guestId:
            guest.id,

        bookingId:
            guest.bookingId,

        rooms:
            uniqueRooms.slice(),

        action:
            "check_in"

    });


    save();


    closeGuestModal();


    renderAll();


    toast(
        "Guest Added",
        name +
        " • Room " +
        uniqueRooms.join(", ") +
        " • " +
        bookingId
    );

}


/* =====================================================
   PART 3 TEST
===================================================== */

function part3Test() {

    console.log(
        "StayFlow PART 3 loaded successfully."
    );

}
/* =====================================================
   STAYFLOW HOTEL MANAGER
   PART 4 — GUEST LIST + SEARCH + CHECKOUT
===================================================== */


/* =====================================================
   GET ACTIVE GUESTS
===================================================== */

function getActiveGuests() {

    return data.guests.filter(
        function (guest) {

            return (
                guest.status === "active"
            );

        }
    );

}


/* =====================================================
   GET COMPLETED GUESTS
===================================================== */

function getCompletedGuests() {

    return data.guests.filter(
        function (guest) {

            return (
                guest.status === "completed"
            );

        }
    );

}


/* =====================================================
   FIND GUEST BY ID
===================================================== */

function getGuestById(
    guestId
) {

    return data.guests.find(
        function (guest) {

            return (
                guest.id === guestId
            );

        }
    );

}


/* =====================================================
   FIND GUEST BY BOOKING ID
===================================================== */

function getGuestByBookingId(
    bookingId
) {

    const value =
        String(
            bookingId || ""
        )
        .trim()
        .toLowerCase();


    return data.guests.find(
        function (guest) {

            return (
                String(
                    guest.bookingId || ""
                )
                .trim()
                .toLowerCase() ===
                value
            );

        }
    );

}


/* =====================================================
   FIND ACTIVE GUEST BY ROOM
===================================================== */

function guestByRoom(
    roomNumber
) {

    const room =
        Number(
            roomNumber
        );


    return getActiveGuests().find(
        function (guest) {

            return (
                guestRooms(
                    guest
                ).indexOf(room) !== -1
            );

        }
    ) || null;

}


/* =====================================================
   GET GUEST ROOMS
===================================================== */

function guestRooms(
    guest
) {

    if (!guest) {

        return [];

    }


    if (
        Array.isArray(
            guest.roomNumbers
        )
    ) {

        return guest.roomNumbers
            .map(
                Number
            )
            .filter(
                Boolean
            );

    }


    if (
        guest.roomNumber
    ) {

        return [
            Number(
                guest.roomNumber
            )
        ];

    }


    return [];

}


/* =====================================================
   RENDER GUEST LIST
===================================================== */

function renderGuestList(
    searchText
) {

    const container =
        $("guestList");


    if (!container) {

        return;

    }


    const search =
        String(
            searchText || ""
        )
        .trim()
        .toLowerCase();


    let guests =
        data.guests.slice();


    if (search) {

        guests =
            guests.filter(
                function (guest) {

                    const name =
                        String(
                            guest.name || ""
                        )
                        .toLowerCase();


                    const booking =
                        String(
                            guest.bookingId || ""
                        )
                        .toLowerCase();


                    const rooms =
                        guestRooms(
                            guest
                        )
                        .join(" ")
                        .toLowerCase();


                    return (
                        name.includes(
                            search
                        ) ||
                        booking.includes(
                            search
                        ) ||
                        rooms.includes(
                            search
                        )
                    );

                }
            );

    }


    guests.sort(
        function (a, b) {

            if (
                a.status ===
                b.status
            ) {

                return (
                    new Date(
                        b.createdAt
                    ) -
                    new Date(
                        a.createdAt
                    )
                );

            }


            return (
                a.status === "active"
                    ? -1
                    : 1
            );

        }
    );


    if (
        guests.length === 0
    ) {

        container.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">
                    <i class="fa-solid fa-users"></i>
                </div>

                <h4>
                    No Guests Found
                </h4>

                <p>
                    Guest list mein abhi koi record nahi hai.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        "";


    guests.forEach(
        function (guest) {

            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "guest-card";


            const rooms =
                guestRooms(
                    guest
                );


            const roomText =
                rooms.length
                    ? rooms
                        .map(
                            function (room) {

                                return (
                                    "Room " +
                                    String(room)
                                        .padStart(
                                            2,
                                            "0"
                                        )
                                );

                            }
                        )
                        .join(", ")
                    : "No Room";


            const active =
                guest.status ===
                "active";


            card.innerHTML = `

                <div class="guest-card-top">

                    <div class="guest-avatar">
                        ${esc(
                            initials(
                                guest.name
                            )
                        )}
                    </div>


                    <div class="guest-info">

                        <strong>
                            ${esc(
                                guest.name
                            )}
                        </strong>

                        <span>
                            ${esc(
                                guest.bookingId
                            )}
                        </span>

                    </div>


                    <span
                        class="guest-status
                        ${active
                            ? ""
                            : "completed"}"
                    >

                        ${
                            active
                                ? "Active"
                                : "Checked Out"
                        }

                    </span>

                </div>


                <div class="guest-card-details">

                    <div class="guest-detail">

                        <span>
                            Room
                        </span>

                        <strong>
                            ${esc(
                                roomText
                            )}
                        </strong>

                    </div>


                    <div class="guest-detail">

                        <span>
                            Check-in
                        </span>

                        <strong>
                            ${dateText(
                                guest.checkIn
                            )}
                        </strong>

                    </div>


                    <div class="guest-detail">

                        <span>
                            Payment
                        </span>

                        <strong>
                            ${money(
                                guest.total
                            )}
                        </strong>

                    </div>

                </div>


                ${
                    active
                        ? `

                        <button
                            type="button"
                            class="secondary-btn guest-checkout-btn"
                            data-guest-id="${esc(
                                guest.id
                            )}"
                        >

                            <i
                                class="fa-solid fa-door-open"
                            ></i>

                            Check Out

                        </button>

                        `
                        : `

                        <div class="guest-completed-info">

                            <span>
                                Nights:
                            </span>

                            <strong>
                                ${guest.nights || 0}
                            </strong>

                        </div>

                        `
                }

            `;


            container.appendChild(
                card
            );

        }
    );


    container
        .querySelectorAll(
            ".guest-checkout-btn"
        )
        .forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        const id =
                            button.getAttribute(
                                "data-guest-id"
                            );


                        checkout(
                            id
                        );

                    }
                );

            }
        );

}


/* =====================================================
   CHECKOUT GUEST
===================================================== */

function checkout(
    guestId
) {

    const guest =
        getGuestById(
            guestId
        );


    if (!guest) {

        toast(
            "Guest Not Found",
            "Guest record nahi mila."
        );

        return;

    }


    if (
        guest.status !== "active"
    ) {

        toast(
            "Already Checked Out",
            "Ye booking already closed hai."
        );

        return;

    }


    const roomText =
        guestRooms(
            guest
        )
        .map(
            function (room) {

                return (
                    "Room " +
                    String(room)
                        .padStart(
                            2,
                            "0"
                        )
                );

            }
        )
        .join(", ");


    const message =
        "Guest: " +
        guest.name +
        "\n" +
        "Booking: " +
        guest.bookingId +
        "\n" +
        "Room: " +
        roomText +
        "\n\n" +
        "Check-out karna hai?";


    if (
        typeof confirm ===
        "function"
    ) {

        if (
            !confirm(
                message
            )
        ) {

            return;

        }

    }


    const checkoutDate =
        new Date();


    guest.checkOut =
        checkoutDate.toISOString();


    guest.status =
        "completed";


    guest.nights =
        calculateNights(
            guest.checkIn,
            guest.checkOut
        );


    /* ROOM HISTORY */

    if (
        !Array.isArray(
            guest.roomHistory
        )
    ) {

        guest.roomHistory =
            [];

    }


    guest.roomHistory.push({

        date:
            checkoutDate.toISOString(),

        rooms:
            guestRooms(
                guest
            ).slice(),

        action:
            "check_out"

    });


    /* GLOBAL ROOM HISTORY */

    if (
        !Array.isArray(
            data.roomHistory
        )
    ) {

        data.roomHistory =
            [];

    }


    data.roomHistory.push({

        date:
            checkoutDate.toISOString(),

        guestId:
            guest.id,

        bookingId:
            guest.bookingId,

        rooms:
            guestRooms(
                guest
            ).slice(),

        action:
            "check_out"

    });


    save();


    closeRoomDetails();


    renderAll();


    toast(
        "Check-out Complete",
        guest.name +
        " • " +
        guest.nights +
        " night(s)"
    );

}


/* =====================================================
   SEARCH SETUP
===================================================== */

function setupGuestSearch() {

    const input =
        $("guestSearch");


    if (!input) {

        return;

    }


    input.addEventListener(
        "input",
        function () {

            renderGuestList(
                input.value
            );

        }
    );

}


/* =====================================================
   GUEST PAGE BUTTONS
===================================================== */

function setupGuestButtons() {

    const addButton =
        $("addGuestBtn");


    const emptyButton =
        $("emptyAddGuestBtn");


    const newBooking =
        $("newBookingBtn");


    if (addButton) {

        addButton.addEventListener(
            "click",
            openGuestModal
        );

    }


    if (emptyButton) {

        emptyButton.addEventListener(
            "click",
            openGuestModal
        );

    }


    if (newBooking) {

        newBooking.addEventListener(
            "click",
            openGuestModal
        );

    }

}


/* =====================================================
   PART 4 TEST
===================================================== */

function part4Test() {

    console.log(
        "StayFlow PART 4 loaded successfully."
    );

}
/* =====================================================
   STAYFLOW HOTEL MANAGER
   PART 5 — CONTINUE EXISTING BOOKING
===================================================== */


/* =====================================================
   CREATE CONTINUE BOOKING MODAL
===================================================== */

function createContinueBookingModal() {

    let modal =
        $("continueBookingModal");


    if (modal) {

        return modal;

    }


    modal =
        document.createElement(
            "div"
        );


    modal.id =
        "continueBookingModal";


    modal.className =
        "modal-overlay hidden";


    modal.innerHTML = `

        <div class="modal-sheet">

            <div class="modal-header">

                <div>

                    <h3>
                        Continue Existing Booking
                    </h3>

                    <p>
                        Active booking select karo
                    </p>

                </div>

                <button
                    type="button"
                    class="icon-btn"
                    id="closeContinueBooking"
                >

                    <i class="fa-solid fa-xmark"></i>

                </button>

            </div>


            <div class="form-group">

                <label>
                    Search Booking
                </label>

                <input
                    type="text"
                    id="continueBookingSearch"
                    class="form-control"
                    placeholder="Booking ID ya guest name..."
                    autocomplete="off"
                >

            </div>


            <div
                id="continueBookingList"
                class="guest-list"
            ></div>

        </div>

    `;


    document.body.appendChild(
        modal
    );


    const closeButton =
        $("closeContinueBooking");


    if (closeButton) {

        closeButton.addEventListener(
            "click",
            closeContinueBooking
        );

    }


    const search =
        $("continueBookingSearch");


    if (search) {

        search.addEventListener(
            "input",
            function () {

                renderContinueBookingList(
                    search.value
                );

            }
        );

    }


    return modal;

}


/* =====================================================
   OPEN CONTINUE BOOKING
===================================================== */

function openContinueBooking() {

    const modal =
        createContinueBookingModal();


    modal.classList.remove(
        "hidden"
    );


    const search =
        $("continueBookingSearch");


    if (search) {

        search.value =
            "";

    }


    renderContinueBookingList();

}


/* =====================================================
   CLOSE CONTINUE BOOKING
===================================================== */

function closeContinueBooking() {

    const modal =
        $("continueBookingModal");


    if (!modal) {

        return;

    }


    modal.classList.add(
        "hidden"
    );

}


/* =====================================================
   RENDER ACTIVE BOOKINGS
===================================================== */

function renderContinueBookingList(
    searchText
) {

    const container =
        $("continueBookingList");


    if (!container) {

        return;

    }


    const search =
        String(
            searchText || ""
        )
        .trim()
        .toLowerCase();


    let guests =
        getActiveGuests();


    if (search) {

        guests =
            guests.filter(
                function (guest) {

                    const name =
                        String(
                            guest.name || ""
                        )
                        .toLowerCase();


                    const booking =
                        String(
                            guest.bookingId || ""
                        )
                        .toLowerCase();


                    const room =
                        guestRooms(
                            guest
                        )
                        .join(" ")
                        .toLowerCase();


                    return (
                        name.includes(
                            search
                        ) ||
                        booking.includes(
                            search
                        ) ||
                        room.includes(
                            search
                        )
                    );

                }
            );

    }


    if (
        guests.length === 0
    ) {

        container.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">
                    <i class="fa-solid fa-calendar-xmark"></i>
                </div>

                <h4>
                    No Active Booking
                </h4>

                <p>
                    Active booking nahi mili.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        "";


    guests.forEach(
        function (guest) {

            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "guest-card";


            const rooms =
                guestRooms(
                    guest
                );


            const roomText =
                rooms
                    .map(
                        function (room) {

                            return (
                                "Room " +
                                String(room)
                                    .padStart(
                                        2,
                                        "0"
                                    )
                            );

                        }
                    )
                    .join(", ");


            card.innerHTML = `

                <div class="guest-card-top">

                    <div class="guest-avatar">
                        ${esc(
                            initials(
                                guest.name
                            )
                        )}
                    </div>


                    <div class="guest-info">

                        <strong>
                            ${esc(
                                guest.name
                            )}
                        </strong>

                        <span>
                            ${esc(
                                guest.bookingId
                            )}
                        </span>

                    </div>

                </div>


                <div class="guest-card-details">

                    <div class="guest-detail">

                        <span>
                            Room
                        </span>

                        <strong>
                            ${esc(
                                roomText
                            )}
                        </strong>

                    </div>


                    <div class="guest-detail">

                        <span>
                            Check-in
                        </span>

                        <strong>
                            ${dateText(
                                guest.checkIn
                            )}
                        </strong>

                    </div>


                    <div class="guest-detail">

                        <span>
                            Current Total
                        </span>

                        <strong>
                            ${money(
                                guest.total
                            )}
                        </strong>

                    </div>

                </div>


                <button
                    type="button"
                    class="primary-btn continue-select-btn"
                >

                    <i class="fa-solid fa-arrow-right"></i>

                    Continue This Booking

                </button>

            `;


            const button =
                card.querySelector(
                    ".continue-select-btn"
                );


            if (button) {

                button.addEventListener(
                    "click",
                    function () {

                        showContinueBookingForm(
                            guest.id
                        );

                    }
                );

            }


            container.appendChild(
                card
            );

        }
    );

}


/* =====================================================
   CONTINUE BOOKING PAYMENT FORM
===================================================== */

function showContinueBookingForm(
    guestId
) {

    const guest =
        getGuestById(
            guestId
        );


    if (!guest) {

        toast(
            "Booking Not Found",
            "Existing booking nahi mili."
        );

        return;

    }


    const modal =
        createContinueBookingModal();


    const container =
        $("continueBookingList");


    if (!container) {

        return;

    }


    container.innerHTML = `

        <div class="guest-card">

            <div class="guest-card-top">

                <div class="guest-avatar">
                    ${esc(
                        initials(
                            guest.name
                        )
                    )}
                </div>


                <div class="guest-info">

                    <strong>
                        ${esc(
                            guest.name
                        )}
                    </strong>

                    <span>
                        ${esc(
                            guest.bookingId
                        )}
                    </span>

                </div>

            </div>


            <div class="guest-card-details">

                <div class="guest-detail">

                    <span>
                        Room
                    </span>

                    <strong>
                        ${guestRooms(
                            guest
                        ).join(", ")}
                    </strong>

                </div>


                <div class="guest-detail">

                    <span>
                        Current Total
                    </span>

                    <strong>
                        ${money(
                            guest.total
                        )}
                    </strong>

                </div>

            </div>


            <div class="form-group">

                <label>
                    Today's Online Payment
                </label>

                <input
                    type="number"
                    id="continueOnline"
                    class="form-control"
                    min="0"
                    step="0.01"
                    value="0"
                    inputmode="decimal"
                >

            </div>


            <div class="form-group">

                <label>
                    Today's Cash Payment
                </label>

                <input
                    type="number"
                    id="continueCash"
                    class="form-control"
                    min="0"
                    step="0.01"
                    value="0"
                    inputmode="decimal"
                >

            </div>


            <div class="form-group">

                <label>
                    Today's Total
                </label>

                <input
                    type="number"
                    id="continueTotal"
                    class="form-control"
                    value="0"
                    readonly
                >

            </div>


            <button
                type="button"
                class="primary-btn"
                id="saveContinueBooking"
            >

                <i class="fa-solid fa-check"></i>

                Continue Booking

            </button>


            <button
                type="button"
                class="secondary-btn"
                id="backContinueBooking"
            >

                <i class="fa-solid fa-arrow-left"></i>

                Back

            </button>

        </div>

    `;


    const online =
        $("continueOnline");


    const cash =
        $("continueCash");


    const total =
        $("continueTotal");


    function updateContinueTotal() {

        const onlineValue =
            Number(
                online?.value
            ) || 0;


        const cashValue =
            Number(
                cash?.value
            ) || 0;


        if (total) {

            total.value =
                onlineValue +
                cashValue;

        }

    }


    if (online) {

        online.addEventListener(
            "input",
            updateContinueTotal
        );

    }


    if (cash) {

        cash.addEventListener(
            "input",
            updateContinueTotal
        );

    }


    const saveButton =
        $("saveContinueBooking");


    if (saveButton) {

        saveButton.addEventListener(
            "click",
            function () {

                continueExistingBooking(
                    guest.id
                );

            }
        );

    }


    const backButton =
        $("backContinueBooking");


    if (backButton) {

        backButton.addEventListener(
            "click",
            function () {

                renderContinueBookingList();

            }
        );

    }


    modal.classList.remove(
        "hidden"
    );

}


/* =====================================================
   CONTINUE EXISTING BOOKING
===================================================== */

function continueExistingBooking(
    guestId
) {

    const guest =
        getGuestById(
            guestId
        );


    if (!guest) {

        toast(
            "Booking Not Found",
            "Booking record nahi mila."
        );

        return;

    }


    if (
        guest.status !== "active"
    ) {

        toast(
            "Booking Closed",
            "Ye booking already checked out hai."
        );

        return;

    }


    const online =
        Number(
            $("continueOnline")
                ?.value
        ) || 0;


    const cash =
        Number(
            $("continueCash")
                ?.value
        ) || 0;


    const total =
        online +
        cash;


    const now =
        new Date();


    const today =
        hotelDayKey(
            now
        );


    if (
        !Array.isArray(
            guest.paymentHistory
        )
    ) {

        guest.paymentHistory =
            [];

    }


    guest.paymentHistory.push({

        date:
            now.toISOString(),

        hotelDay:
            today,

        online:
            online,

        cash:
            cash,

        total:
            total

    });


    guest.online =
        (
            Number(
                guest.online
            ) || 0
        ) +
        online;


    guest.cash =
        (
            Number(
                guest.cash
            ) || 0
        ) +
        cash;


    guest.total =
        (
            Number(
                guest.total
            ) || 0
        ) +
        total;


    /* CONTINUE HISTORY */

    if (
        !Array.isArray(
            guest.roomHistory
        )
    ) {

        guest.roomHistory =
            [];

    }


    guest.roomHistory.push({

        date:
            now.toISOString(),

        rooms:
            guestRooms(
                guest
            ).slice(),

        action:
            "continue_booking"

    });


    if (
        !Array.isArray(
            data.bookingHistory
        )
    ) {

        data.bookingHistory =
            [];

    }


    data.bookingHistory.push({

        date:
            now.toISOString(),

        hotelDay:
            today,

        guestId:
            guest.id,

        bookingId:
            guest.bookingId,

        rooms:
            guestRooms(
                guest
            ).slice(),

        action:
            "continue_booking",

        online:
            online,

        cash:
            cash,

        total:
            total

    });


    save();


    closeContinueBooking();


    renderAll();


    toast(
        "Booking Continued",
        guest.bookingId +
        " • " +
        guest.name
    );

}


/* =====================================================
   CONTINUE BUTTON SETUP
===================================================== */

function setupContinueBooking() {

    const button =
        $("continueBookingBtn");


    if (!button) {

        return;

    }


    button.addEventListener(
        "click",
        openContinueBooking
    );

}


/* =====================================================
   PART 5 TEST
===================================================== */

function part5Test() {

    console.log(
        "StayFlow PART 5 loaded successfully."
    );

}
/* =====================================================
   STAYFLOW HOTEL MANAGER
   PART 6 — ID CAPTURE + PRINT QUEUE
===================================================== */


/* =====================================================
   CURRENT ID DATA
===================================================== */

let currentIDData = {

    type: "Other",

    front: null,

    back: null

};


/* =====================================================
   RESET CURRENT ID
===================================================== */

function resetIDData() {

    currentIDData = {

        type: "Other",

        front: null,

        back: null

    };


    if ($("idType")) {

        currentIDData.type =
            $("idType").value ||
            "Other";

    }


    updateIDButtons();

}


/* =====================================================
   UPDATE ID TYPE
===================================================== */

function updateIDType() {

    const select =
        $("idType");


    if (!select) {

        return;

    }


    currentIDData.type =
        select.value ||
        "Other";

}


/* =====================================================
   CREATE CAMERA INPUT
===================================================== */

function createCameraInput(
    side
) {

    const input =
        document.createElement(
            "input"
        );


    input.type =
        "file";


    input.accept =
        "image/*";


    input.setAttribute(
        "capture",
        "environment"
    );


    input.style.display =
        "none";


    input.addEventListener(
        "change",
        function () {

            if (
                !input.files ||
                !input.files[0]
            ) {

                return;

            }


            handleIDFile(
                input.files[0],
                side
            );

        }
    );


    document.body.appendChild(
        input
    );


    input.click();


    setTimeout(
        function () {

            if (
                input.parentNode
            ) {

                input.parentNode
                    .removeChild(
                        input
                    );

            }

        },
        60000
    );

}


/* =====================================================
   READ ID IMAGE
===================================================== */

function handleIDFile(
    file,
    side
) {

    if (
        !file ||
        !file.type.startsWith(
            "image/"
        )
    ) {

        toast(
            "Invalid File",
            "Please image file select karo."
        );

        return;

    }


    const reader =
        new FileReader();


    reader.onload =
        function (event) {

            const imageData =
                event.target.result;


            if (
                side === "front"
            ) {

                currentIDData.front =
                    imageData;

            }


            if (
                side === "back"
            ) {

                currentIDData.back =
                    imageData;

            }


            updateIDButtons();

            showIDPreview();

            toast(
                "ID Captured",
                "ID " +
                side +
                " successfully captured."
            );

        };


    reader.onerror =
        function () {

            toast(
                "Capture Failed",
                "Image read nahi ho payi."
            );

        };


    reader.readAsDataURL(
        file
    );

}


/* =====================================================
   UPDATE FRONT / BACK BUTTONS
===================================================== */

function updateIDButtons() {

    const frontButton =
        $("idFrontBtn");


    const backButton =
        $("idBackBtn");


    if (frontButton) {

        frontButton.innerHTML =
            currentIDData.front

                ? `
                    <i class="fa-solid fa-check"></i>
                    Front Captured
                  `

                : `
                    <i class="fa-solid fa-camera"></i>
                    Capture Front
                  `;

    }


    if (backButton) {

        backButton.innerHTML =
            currentIDData.back

                ? `
                    <i class="fa-solid fa-check"></i>
                    Back Captured
                  `

                : `
                    <i class="fa-solid fa-camera"></i>
                    Capture Back
                  `;

    }

}


/* =====================================================
   ID PREVIEW CONTAINER
===================================================== */

function createIDPreviewContainer() {

    let box =
        $("idCapturePreview");


    if (box) {

        return box;

    }


    box =
        document.createElement(
            "div"
        );


    box.id =
        "idCapturePreview";


    box.style.marginTop =
        "14px";


    box.style.display =
        "grid";


    box.style.gridTemplateColumns =
        "repeat(2, minmax(0, 1fr))";


    box.style.gap =
        "10px";


    const front =
        document.createElement(
            "div"
        );


    front.id =
        "idFrontPreview";


    const back =
        document.createElement(
            "div"
        );


    back.id =
        "idBackPreview";


    box.appendChild(
        front
    );


    box.appendChild(
        back
    );


    const button =
        $("idFrontBtn");


    if (
        button &&
        button.parentNode
    ) {

        button.parentNode
            .appendChild(
                box
            );

    }


    return box;

}


/* =====================================================
   IMAGE PREVIEW CARD
===================================================== */

function previewImage(
    container,
    image,
    title
) {

    if (!container) {

        return;

    }


    if (!image) {

        container.innerHTML = `

            <div
                style="
                    padding:18px;
                    border:1px dashed var(--border);
                    border-radius:14px;
                    text-align:center;
                    color:var(--text-2);
                    font-size:11px;
                "
            >

                <i
                    class="fa-regular fa-image"
                    style="font-size:20px"
                ></i>

                <div style="margin-top:6px">
                    ${title}
                </div>

                <div
                    style="
                        font-size:9px;
                        margin-top:3px;
                    "
                >
                    Optional
                </div>

            </div>

        `;

        return;

    }


    container.innerHTML = `

        <div
            style="
                border:1px solid var(--border);
                border-radius:14px;
                padding:8px;
                background:var(--card);
            "
        >

            <div
                style="
                    font-size:10px;
                    font-weight:700;
                    margin-bottom:6px;
                "
            >
                ${title}
            </div>


            <img
                src="${image}"
                alt="${title}"
                style="
                    width:100%;
                    height:120px;
                    object-fit:contain;
                    border-radius:9px;
                    background:#f3f5f7;
                "
            >

        </div>

    `;

}


/* =====================================================
   SHOW ID PREVIEW
===================================================== */

function showIDPreview() {

    const box =
        createIDPreviewContainer();


    if (!box) {

        return;

    }


    previewImage(
        $("idFrontPreview"),
        currentIDData.front,
        "Front"
    );


    previewImage(
        $("idBackPreview"),
        currentIDData.back,
        "Back"
    );

}


/* =====================================================
   ADD ID TO PRINT QUEUE
===================================================== */

function addIDToPrintQueue() {

    updateIDType();


    if (
        !currentIDData.front
    ) {

        toast(
            "Front Required",
            "ID ka front capture karo."
        );

        return;

    }


    const item = {

        id:
            "print_" +
            Date.now() +
            "_" +
            Math.floor(
                Math.random() *
                10000
            ),

        type:
            currentIDData.type,

        front:
            currentIDData.front,

        back:
            currentIDData.back,

        createdAt:
            new Date().toISOString(),

        status:
            "waiting"

    };


    data.printQueue.push(
        item
    );


    /*
       Large ID images localStorage mein
       bahut space le sakti hain.
       Isliye abhi queue memory/local
       storage prototype ke liye save kar rahe hain.
    */

    save();


    renderPrintQueue();


    toast(
        "Added to Print Queue",
        currentIDData.type +
        " • A4 ready"
    );


    resetIDData();


    showIDPreview();

}


/* =====================================================
   RENDER PRINT QUEUE
===================================================== */

function renderPrintQueue() {

    const container =
        $("printQueue");


    const count =
        $("queueCount");


    if (count) {

        count.textContent =
            data.printQueue.length +
            " documents waiting";

    }


    if (!container) {

        return;

    }


    if (
        data.printQueue.length === 0
    ) {

        container.innerHTML = `

            <div class="empty-state">

                <div class="empty-icon">
                    <i class="fa-solid fa-print"></i>
                </div>

                <h4>
                    Print Queue Empty
                </h4>

                <p>
                    Captured IDs yaha appear honge.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        "";


    data.printQueue.forEach(
        function (item, index) {

            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "guest-card";


            const sides =
                item.back
                    ? "Front + Back"
                    : "Front Only";


            card.innerHTML = `

                <div class="guest-card-top">

                    <div class="guest-avatar">

                        <i
                            class="fa-solid fa-id-card"
                        ></i>

                    </div>


                    <div class="guest-info">

                        <strong>
                            ${esc(
                                item.type
                            )}
                        </strong>

                        <span>
                            ${sides}
                        </span>

                    </div>


                    <span class="guest-status">
                        Waiting
                    </span>

                </div>


                <button
                    type="button"
                    class="secondary-btn queue-remove-btn"
                    data-index="${index}"
                >

                    <i
                        class="fa-solid fa-trash"
                    ></i>

                    Remove

                </button>

            `;


            container.appendChild(
                card
            );

        }
    );


    container
        .querySelectorAll(
            ".queue-remove-btn"
        )
        .forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        const index =
                            Number(
                                button.getAttribute(
                                    "data-index"
                                )
                            );


                        removePrintQueueItem(
                            index
                        );

                    }
                );

            }
        );

}


/* =====================================================
   REMOVE PRINT QUEUE ITEM
===================================================== */

function removePrintQueueItem(
    index
) {

    if (
        index < 0 ||
        index >=
        data.printQueue.length
    ) {

        return;

    }


    data.printQueue.splice(
        index,
        1
    );


    save();

    renderPrintQueue();


    toast(
        "Removed",
        "Print queue se document remove ho gaya."
    );

}


/* =====================================================
   CLEAR PRINT QUEUE
===================================================== */

function clearPrintQueue() {

    if (
        data.printQueue.length === 0
    ) {

        toast(
            "Queue Empty",
            "Print queue already empty hai."
        );

        return;

    }


    if (
        !confirm(
            "Print queue ke saare documents remove karne hain?"
        )
    ) {

        return;

    }


    data.printQueue = [];

    save();

    renderPrintQueue();


    toast(
        "Queue Cleared",
        "Print queue empty kar di."
    );

}


/* =====================================================
   PRINT PREVIEW
===================================================== */

function showPrintPreview() {

    if (
        data.printQueue.length === 0
    ) {

        toast(
            "Queue Empty",
            "Pehle ID print queue mein add karo."
        );

        return;

    }


    const item =
        data.printQueue[0];


    let modal =
        $("printPreviewModal");


    if (!modal) {

        modal =
            document.createElement(
                "div"
            );


        modal.id =
            "printPreviewModal";


        modal.className =
            "modal-overlay";


        modal.innerHTML = `

            <div class="modal-sheet">

                <div class="modal-header">

                    <div>

                        <h3>
                            A4 Print Preview
                        </h3>

                        <p>
                            Single-sided A4
                        </p>

                    </div>

                    <button
                        type="button"
                        class="icon-btn"
                        id="closePrintPreview"
                    >

                        <i class="fa-solid fa-xmark"></i>

                    </button>

                </div>


                <div
                    id="a4PreviewArea"
                    style="
                        background:white;
                        color:#111;
                        width:100%;
                        aspect-ratio:210 / 297;
                        border:1px solid #ddd;
                        border-radius:10px;
                        padding:16px;
                        display:flex;
                        flex-direction:column;
                        gap:12px;
                        overflow:hidden;
                    "
                ></div>


                <button
                    type="button"
                    class="primary-btn"
                    id="printNowButton"
                >

                    <i
                        class="fa-solid fa-print"
                    ></i>

                    Print A4

                </button>

            </div>

        `;


        document.body.appendChild(
            modal
        );


        $("closePrintPreview")
            ?.addEventListener(
                "click",
                function () {

                    modal.classList.add(
                        "hidden"
                    );

                }
            );


        $("printNowButton")
            ?.addEventListener(
                "click",
                function () {

                    window.print();

                }
            );

    }


    const area =
        $("a4PreviewArea");


    if (!area) {

        return;

    }


    area.innerHTML =
        "";


    const front =
        document.createElement(
            "img"
        );


    front.src =
        item.front;


    front.style.width =
        "100%";


    front.style.maxHeight =
        item.back
            ? "46%"
            : "80%";


    front.style.objectFit =
        "contain";


    area.appendChild(
        front
    );


    if (item.back) {

        const back =
            document.createElement(
                "img"
            );


        back.src =
            item.back;


        back.style.width =
            "100%";


        back.style.maxHeight =
            "46%";


        back.style.objectFit =
            "contain";


        area.appendChild(
            back
        );

    }


    modal.classList.remove(
        "hidden"
    );

}


/* =====================================================
   ID EVENTS
===================================================== */

function setupIDEvents() {

    if ($("idType")) {

        $("idType").addEventListener(
            "change",
            updateIDType
        );

    }


    if ($("idFrontBtn")) {

        $("idFrontBtn").addEventListener(
            "click",
            function () {

                createCameraInput(
                    "front"
                );

            }
        );

    }


    if ($("idBackBtn")) {

        $("idBackBtn").addEventListener(
            "click",
            function () {

                createCameraInput(
                    "back"
                );

            }
        );

    }


    if ($("previewPrintBtn")) {

        $("previewPrintBtn").addEventListener(
            "click",
            showPrintPreview
        );

    }


    renderPrintQueue();

    updateIDButtons();

}


/* =====================================================
   PART 6 TEST
===================================================== */

function part6Test() {

    console.log(
        "StayFlow PART 6 loaded successfully."
    );

}
// ============================================================
// STAYFLOW HOTEL MANAGER
// PART 7A - REPORT CALCULATION SYSTEM
// ============================================================

let currentReportType = "daily";


// ------------------------------------------------------------
// REPORT DATE HELPERS
// ------------------------------------------------------------

function reportDateKey(dateValue) {

    if (!dateValue) {
        return hotelDayKey(new Date());
    }

    const d = new Date(dateValue);

    if (Number.isNaN(d.getTime())) {
        return hotelDayKey(new Date());
    }

    return hotelDayKey(d);
}


function dateFromHotelDayKey(key) {

    if (!key) {
        return new Date();
    }

    const parts = String(key).split("-");

    if (parts.length !== 3) {
        return new Date();
    }

    const year = Number(parts[0]);
    const month = Number(parts[1]) - 1;
    const day = Number(parts[2]);

    return new Date(
        year,
        month,
        day,
        12,
        0,
        0
    );
}


function formatReportDate(key) {

    const d =
        dateFromHotelDayKey(key);

    return d.toLocaleDateString(
        "en-IN",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );
}


function getTodayHotelDay() {

    return hotelDayKey(
        new Date()
    );
}


// ------------------------------------------------------------
// REPORT DATE RANGE
// ------------------------------------------------------------

function getReportRange(type) {

    const today =
        dateFromHotelDayKey(
            getTodayHotelDay()
        );

    let start;
    let end;


    // DAILY
    if (type === "daily") {

        start = new Date(today);
        end = new Date(today);

    }


    // WEEKLY
    else if (type === "weekly") {

        end = new Date(today);

        start = new Date(today);

        start.setDate(
            start.getDate() - 6
        );

    }


    // MONTHLY
    else {

        start = new Date(
            today.getFullYear(),
            today.getMonth(),
            1,
            12,
            0,
            0
        );

        end = new Date(
            today.getFullYear(),
            today.getMonth() + 1,
            0,
            12,
            0,
            0
        );

    }


    return {

        startKey:
            hotelDayKey(start),

        endKey:
            hotelDayKey(end)

    };
}


// ------------------------------------------------------------
// DATE RANGE CHECK
// ------------------------------------------------------------

function isKeyBetween(
    key,
    startKey,
    endKey
) {

    if (!key) {
        return false;
    }

    return (
        key >= startKey &&
        key <= endKey
    );
}


// ------------------------------------------------------------
// CHECK IF GUEST WAS OCCUPYING ROOM
// ------------------------------------------------------------

function guestOccupiedOnDay(
    guest,
    dayKey
) {

    if (!guest) {
        return false;
    }


    const checkInKey =
        reportDateKey(
            guest.checkIn
        );


    if (checkInKey > dayKey) {
        return false;
    }


    let endKey;


    if (
        guest.status === "completed" &&
        guest.checkOut
    ) {

        endKey =
            reportDateKey(
                guest.checkOut
            );

    } else {

        endKey =
            getTodayHotelDay();

    }


    return dayKey <= endKey;
}


// ------------------------------------------------------------
// GET PAYMENT FOR SPECIFIC DAY
// ------------------------------------------------------------

function getGuestPaymentForDay(
    guest,
    dayKey
) {

    let online = 0;
    let cash = 0;


    if (
        guest &&
        Array.isArray(
            guest.paymentHistory
        )
    ) {

        guest.paymentHistory.forEach(
            payment => {

                const paymentDay =
                    payment.hotelDay ||
                    reportDateKey(
                        payment.date
                    );


                if (
                    paymentDay === dayKey
                ) {

                    online +=
                        Number(
                            payment.online
                        ) || 0;

                    cash +=
                        Number(
                            payment.cash
                        ) || 0;

                }

            }
        );

    }


    return {

        online,

        cash,

        total:
            online + cash

    };
}


// ------------------------------------------------------------
// GET GUEST ROOM NUMBERS
// ------------------------------------------------------------

function reportGuestRooms(
    guest
) {

    if (!guest) {
        return [];
    }


    if (
        Array.isArray(
            guest.roomNumbers
        )
    ) {

        return guest.roomNumbers
            .map(Number)
            .filter(Boolean);

    }


    if (guest.roomNumber) {

        return [
            Number(
                guest.roomNumber
            )
        ];

    }


    return [];
}


// ------------------------------------------------------------
// ROOM COUNT FOR A DAY
// ------------------------------------------------------------

function getGuestRoomCountForDay(
    guest,
    dayKey
) {

    if (
        !guestOccupiedOnDay(
            guest,
            dayKey
        )
    ) {

        return 0;

    }


    return reportGuestRooms(
        guest
    ).length;
}


// ------------------------------------------------------------
// GET ALL GUESTS
// ------------------------------------------------------------

function getAllReportGuests() {

    if (
        !data ||
        !Array.isArray(data.guests)
    ) {

        return [];

    }

    return data.guests;
}


// ------------------------------------------------------------
// BUILD DAILY REPORT ROWS
// ------------------------------------------------------------

function buildDailyReportRows(
    dayKey
) {

    const guests =
        getAllReportGuests();

    const rows = [];


    guests.forEach(
        guest => {

            if (
                !guestOccupiedOnDay(
                    guest,
                    dayKey
                )
            ) {

                return;

            }


            const payment =
                getGuestPaymentForDay(
                    guest,
                    dayKey
                );


            const rooms =
                reportGuestRooms(
                    guest
                );


            rows.push({

                guestId:
                    guest.id,

                name:
                    guest.name ||
                    "Guest",

                bookingId:
                    guest.bookingId ||
                    "-",

                date:
                    dayKey,

                roomNumbers:
                    rooms,

                roomNumberText:
                    rooms.length
                        ? rooms.join(", ")
                        : "-",

                roomCount:
                    rooms.length,

                online:
                    payment.online,

                cash:
                    payment.cash,

                total:
                    payment.total,

                status:
                    guest.status ||
                    "active"

            });

        }
    );


    return rows;
}


// ------------------------------------------------------------
// BUILD REPORT ROWS
// ------------------------------------------------------------

function buildReportRows(
    type
) {

    const range =
        getReportRange(type);


    const rows = [];


    let current =
        dateFromHotelDayKey(
            range.startKey
        );


    const end =
        dateFromHotelDayKey(
            range.endKey
        );


    while (
        current <= end
    ) {

        const dayKey =
            hotelDayKey(
                current
            );


        const dailyRows =
            buildDailyReportRows(
                dayKey
            );


        dailyRows.forEach(
            row => {

                rows.push(row);

            }
        );


        current.setDate(
            current.getDate() + 1
        );

    }


    return rows;
}


// ------------------------------------------------------------
// UNIQUE GUEST COUNT
// ------------------------------------------------------------

function getReportGuestCount(
    rows
) {

    const ids =
        new Set();


    rows.forEach(
        row => {

            if (row.guestId) {

                ids.add(
                    row.guestId
                );

            }

        }
    );


    return ids.size;
}


// ------------------------------------------------------------
// CALCULATE NUMBER OF DAYS
// ------------------------------------------------------------

function calculateRoomDays(
    startKey,
    endKey
) {

    let count = 0;


    const start =
        dateFromHotelDayKey(
            startKey
        );


    const end =
        dateFromHotelDayKey(
            endKey
        );


    let current =
        new Date(start);


    while (
        current <= end
    ) {

        count++;


        current.setDate(
            current.getDate() + 1
        );

    }


    return count;
}


// ------------------------------------------------------------
// OCCUPANCY CALCULATION
// ------------------------------------------------------------

function calculateReportOccupancy(
    type
) {

    const range =
        getReportRange(type);


    const guests =
        getAllReportGuests();


    let occupiedRoomDays = 0;


    let current =
        dateFromHotelDayKey(
            range.startKey
        );


    const end =
        dateFromHotelDayKey(
            range.endKey
        );


    while (
        current <= end
    ) {

        const dayKey =
            hotelDayKey(
                current
            );


        guests.forEach(
            guest => {

                if (
                    guestOccupiedOnDay(
                        guest,
                        dayKey
                    )
                ) {

                    occupiedRoomDays +=
                        reportGuestRooms(
                            guest
                        ).length;

                }

            }
        );


        current.setDate(
            current.getDate() + 1
        );

    }


    const totalDays =
        calculateRoomDays(
            range.startKey,
            range.endKey
        );


    const availableRoomDays =
        TOTAL_ROOMS *
        totalDays;


    if (!availableRoomDays) {
        return 0;
    }


    return Math.min(
        100,
        (
            occupiedRoomDays /
            availableRoomDays
        ) * 100
    );
}


// ------------------------------------------------------------
// REPORT TOTALS
// ------------------------------------------------------------

function calculateReportTotals(
    rows
) {

    let online = 0;
    let cash = 0;
    let total = 0;
    let roomEntries = 0;


    rows.forEach(
        row => {

            online +=
                Number(row.online) || 0;

            cash +=
                Number(row.cash) || 0;

            total +=
                Number(row.total) || 0;

            roomEntries +=
                Number(row.roomCount) || 0;

        }
    );


    const guestCount =
        getReportGuestCount(
            rows
        );


    const onlinePercent =
        total > 0
            ? (
                online / total
            ) * 100
            : 0;


    const cashPercent =
        total > 0
            ? (
                cash / total
            ) * 100
            : 0;


    return {

        guests:
            guestCount,

        rooms:
            roomEntries,

        online,

        cash,

        total,

        onlinePercent,

        cashPercent

    };
}


// ------------------------------------------------------------
// REPORT TITLE
// ------------------------------------------------------------

function getReportTitle(
    type
) {

    if (type === "daily") {
        return "Daily Report";
    }


    if (type === "weekly") {
        return "Weekly Report";
    }


    return "Monthly Report";
}


// ------------------------------------------------------------
// REPORT SUBTITLE
// ------------------------------------------------------------

function getReportSubtitle(
    type
) {

    const range =
        getReportRange(type);


    if (type === "daily") {

        return formatReportDate(
            range.startKey
        );

    }


    return (
        formatReportDate(
            range.startKey
        ) +
        " - " +
        formatReportDate(
            range.endKey
        )
    );
}


// ------------------------------------------------------------
// PAYMENT PERCENTAGES
// ------------------------------------------------------------

function getPaymentPercentageText(
    rows
) {

    const totals =
        calculateReportTotals(
            rows
        );


    return {

        online:
            totals.onlinePercent
                .toFixed(1) + "%",

        cash:
            totals.cashPercent
                .toFixed(1) + "%"

    };
}


// ------------------------------------------------------------
// PART 7A TEST
// ------------------------------------------------------------

function part7ATest() {

    console.log(
        "Part 7A Reports Calculation loaded."
    );


    console.log(
        "Current Report:",
        currentReportType
    );


    console.log(
        "Report Range:",
        getReportRange(
            currentReportType
        )
    );


    const rows =
        buildReportRows(
            currentReportType
        );


    console.log(
        "Report Rows:",
        rows
    );


    console.log(
        "Report Totals:",
        calculateReportTotals(
            rows
        )
    );


    console.log(
        "Occupancy:",
        calculateReportOccupancy(
            currentReportType
        )
    );

}
// ============================================================
// STAYFLOW HOTEL MANAGER
// PART 7B - REPORT UI + EXPORT + PRINT
// ============================================================


// ------------------------------------------------------------
// RENDER REPORT TABLE
// ------------------------------------------------------------

function renderReportTable(rows) {

    const tableBody =
        $("reportTableBody");

    if (!tableBody) {
        return;
    }

    tableBody.innerHTML = "";


    if (!rows.length) {

        tableBody.innerHTML = `
            <tr>
                <td colspan="8"
                    style="
                        text-align:center;
                        padding:25px;
                    ">
                    No report data found
                </td>
            </tr>
        `;

        return;
    }


    rows.forEach(row => {

        const tr =
            document.createElement("tr");


        tr.innerHTML = `

            <td>
                ${esc(row.name)}
            </td>

            <td>
                ${esc(row.bookingId)}
            </td>

            <td>
                ${formatReportDate(row.date)}
            </td>

            <td>
                ${esc(row.roomNumberText)}
            </td>

            <td>
                ${row.roomCount}
            </td>

            <td>
                ${money(row.online)}
            </td>

            <td>
                ${money(row.cash)}
            </td>

            <td>
                <strong>
                    ${money(row.total)}
                </strong>
            </td>

        `;


        tableBody.appendChild(tr);

    });
}


// ------------------------------------------------------------
// UPDATE REPORT SUMMARY
// ------------------------------------------------------------

function updateReportSummary(
    rows,
    type
) {

    const totals =
        calculateReportTotals(
            rows
        );


    const occupancy =
        calculateReportOccupancy(
            type
        );


    const guestEl =
        $("reportGuests");

    const roomEl =
        $("reportRooms");

    const onlineEl =
        $("reportOnline");

    const cashEl =
        $("reportCash");

    const totalEl =
        $("reportTotal");

    const occupancyEl =
        $("reportOccupancy");


    if (guestEl) {

        guestEl.textContent =
            totals.guests;

    }


    if (roomEl) {

        roomEl.textContent =
            totals.rooms;

    }


    if (onlineEl) {

        onlineEl.textContent =
            money(
                totals.online
            );

    }


    if (cashEl) {

        cashEl.textContent =
            money(
                totals.cash
            );

    }


    if (totalEl) {

        totalEl.textContent =
            money(
                totals.total
            );

    }


    if (occupancyEl) {

        occupancyEl.textContent =
            occupancy.toFixed(1) +
            "%";

    }


    const titleEl =
        $("reportTitle");

    const subtitleEl =
        $("reportSubtitle");


    if (titleEl) {

        titleEl.textContent =
            getReportTitle(
                type
            );

    }


    if (subtitleEl) {

        subtitleEl.textContent =
            getReportSubtitle(
                type
            );

    }
}


// ------------------------------------------------------------
// RENDER COMPLETE REPORT
// ------------------------------------------------------------

function renderReport(
    type
) {

    currentReportType =
        type || "daily";


    const rows =
        buildReportRows(
            currentReportType
        );


    renderReportTable(
        rows
    );


    updateReportSummary(
        rows,
        currentReportType
    );


    return rows;
}


// ------------------------------------------------------------
// REPORT TABS
// ------------------------------------------------------------

function setupReportTabs() {

    const tabs =
        document.querySelectorAll(
            ".report-tab"
        );


    tabs.forEach(
        tab => {

            tab.addEventListener(
                "click",
                () => {

                    tabs.forEach(
                        item => {

                            item.classList.remove(
                                "active"
                            );

                        }
                    );


                    tab.classList.add(
                        "active"
                    );


                    const type =
                        tab.dataset.report ||
                        "daily";


                    renderReport(
                        type
                    );

                }
            );

        }
    );
}


// ------------------------------------------------------------
// CSV ESCAPE
// ------------------------------------------------------------

function csvEscape(
    value
) {

    const text =
        String(
            value === undefined ||
            value === null
                ? ""
                : value
        );


    if (
        text.includes(",") ||
        text.includes('"') ||
        text.includes("\n")
    ) {

        return (
            '"' +
            text.replace(
                /"/g,
                '""'
            ) +
            '"'
        );

    }


    return text;
}


// ------------------------------------------------------------
// CREATE CSV
// ------------------------------------------------------------

function createReportCSV(
    rows
) {

    const headers = [

        "Customer Name",

        "Booking ID",

        "Date",

        "Room No.",

        "No. of Rooms",

        "Online",

        "Cash",

        "Total"

    ];


    const lines = [];


    lines.push(
        headers
            .map(csvEscape)
            .join(",")
    );


    rows.forEach(
        row => {

            lines.push(

                [

                    row.name,

                    row.bookingId,

                    formatReportDate(
                        row.date
                    ),

                    row.roomNumberText,

                    row.roomCount,

                    row.online,

                    row.cash,

                    row.total

                ]
                    .map(csvEscape)
                    .join(",")

            );

        }
    );


    return lines.join(
        "\n"
    );
}


// ------------------------------------------------------------
// DOWNLOAD REPORT
// ------------------------------------------------------------

function downloadReportCSV() {

    const rows =
        buildReportRows(
            currentReportType
        );


    if (!rows.length) {

        toast(
            "No Data",
            "There is no report data to export."
        );

        return;
    }


    const csv =
        createReportCSV(
            rows
        );


    const blob =
        new Blob(
            [csv],
            {
                type:
                    "text/csv;charset=utf-8;"
            }
        );


    const url =
        URL.createObjectURL(
            blob
        );


    const link =
        document.createElement(
            "a"
        );


    link.href = url;


    link.download =
        "StayFlow_" +
        currentReportType +
        "_" +
        getTodayHotelDay() +
        ".csv";


    document.body.appendChild(
        link
    );


    link.click();


    link.remove();


    URL.revokeObjectURL(
        url
    );


    toast(
        "Export Complete",
        "Report file is ready."
    );
}


// ------------------------------------------------------------
// PRINT / PDF REPORT
// ------------------------------------------------------------

function printReport() {

    const rows =
        buildReportRows(
            currentReportType
        );


    if (!rows.length) {

        toast(
            "No Data",
            "There is no report data to print."
        );

        return;
    }


    const totals =
        calculateReportTotals(
            rows
        );


    const occupancy =
        calculateReportOccupancy(
            currentReportType
        );


    const title =
        getReportTitle(
            currentReportType
        );


    const subtitle =
        getReportSubtitle(
            currentReportType
        );


    const printWindow =
        window.open(
            "",
            "_blank"
        );


    if (!printWindow) {

        toast(
            "Print Blocked",
            "Allow pop-ups to print the report."
        );

        return;
    }


    const rowsHTML =
        rows.map(
            row => `

                <tr>

                    <td>
                        ${esc(row.name)}
                    </td>

                    <td>
                        ${esc(row.bookingId)}
                    </td>

                    <td>
                        ${formatReportDate(
                            row.date
                        )}
                    </td>

                    <td>
                        ${esc(
                            row.roomNumberText
                        )}
                    </td>

                    <td>
                        ${row.roomCount}
                    </td>

                    <td>
                        ${money(
                            row.online
                        )}
                    </td>

                    <td>
                        ${money(
                            row.cash
                        )}
                    </td>

                    <td>
                        ${money(
                            row.total
                        )}
                    </td>

                </tr>

            `
        ).join("");


    printWindow.document.write(`

        <!DOCTYPE html>

        <html>

        <head>

            <meta charset="UTF-8">

            <title>
                ${title} - StayFlow
            </title>

            <style>

                body {
                    font-family:
                        Arial,
                        sans-serif;

                    padding: 25px;

                    color: #111;
                }


                h1 {
                    margin-bottom: 5px;
                }


                h2 {
                    margin-bottom: 5px;
                }


                .subtitle {
                    color: #666;
                    margin-bottom: 20px;
                }


                .summary {

                    display: grid;

                    grid-template-columns:
                        repeat(3, 1fr);

                    gap: 10px;

                    margin-bottom: 20px;

                }


                .box {

                    border:
                        1px solid #ddd;

                    padding: 12px;

                    border-radius: 8px;

                }


                .label {

                    font-size: 12px;

                    color: #666;

                }


                .value {

                    font-size: 18px;

                    font-weight: bold;

                    margin-top: 4px;

                }


                table {

                    width: 100%;

                    border-collapse:
                        collapse;

                }


                th,
                td {

                    border:
                        1px solid #ccc;

                    padding: 8px;

                    font-size: 12px;

                    text-align: left;

                }


                th {

                    background:
                        #f2f2f2;

                }


                .footer {

                    margin-top: 20px;

                    font-size: 12px;

                    color: #666;

                }


                @media print {

                    body {
                        padding: 10px;
                    }

                }

            </style>

        </head>


        <body>

            <h1>
                StayFlow Hotel Manager
            </h1>


            <h2>
                ${title}
            </h2>


            <div class="subtitle">
                ${subtitle}
            </div>


            <div class="summary">


                <div class="box">

                    <div class="label">
                        Guests
                    </div>

                    <div class="value">
                        ${totals.guests}
                    </div>

                </div>


                <div class="box">

                    <div class="label">
                        Rooms
                    </div>

                    <div class="value">
                        ${totals.rooms}
                    </div>

                </div>


                <div class="box">

                    <div class="label">
                        Online
                    </div>

                    <div class="value">
                        ${money(
                            totals.online
                        )}
                    </div>

                </div>


                <div class="box">

                    <div class="label">
                        Cash
                    </div>

                    <div class="value">
                        ${money(
                            totals.cash
                        )}
                    </div>

                </div>


                <div class="box">

                    <div class="label">
                        Total
                    </div>

                    <div class="value">
                        ${money(
                            totals.total
                        )}
                    </div>

                </div>


                <div class="box">

                    <div class="label">
                        Occupancy
                    </div>

                    <div class="value">
                        ${occupancy.toFixed(1)}%
                    </div>

                </div>


            </div>


            <table>

                <thead>

                    <tr>

                        <th>
                            Customer Name
                        </th>

                        <th>
                            Booking ID
                        </th>

                        <th>
                            Date
                        </th>

                        <th>
                            Room No.
                        </th>

                        <th>
                            No. of Rooms
                        </th>

                        <th>
                            Online
                        </th>

                        <th>
                            Cash
                        </th>

                        <th>
                            Total
                        </th>

                    </tr>

                </thead>


                <tbody>

                    ${rowsHTML}

                </tbody>

            </table>


            <div class="footer">

                Online:
                ${totals.onlinePercent.toFixed(1)}%

                &nbsp;&nbsp; | &nbsp;&nbsp;

                Cash:
                ${totals.cashPercent.toFixed(1)}%

            </div>


        </body>

        </html>

    `);


    printWindow.document.close();


    printWindow.focus();


    setTimeout(
        () => {

            printWindow.print();

        },
        500
    );
}


// ------------------------------------------------------------
// REPORT BUTTON SETUP
// ------------------------------------------------------------

function setupReportButtons() {

    const downloadBtn =
        $("reportDownloadBtn");


    if (downloadBtn) {

        downloadBtn.addEventListener(
            "click",
            downloadReportCSV
        );

    }


    const pdfBtn =
        $("pdfReportBtn");


    if (pdfBtn) {

        pdfBtn.addEventListener(
            "click",
            printReport
        );

    }


    const excelBtn =
        $("excelReportBtn");


    if (excelBtn) {

        excelBtn.addEventListener(
            "click",
            downloadReportCSV
        );

    }
}


// ------------------------------------------------------------
// PART 7B TEST
// ------------------------------------------------------------

function part7BTest() {

    console.log(
        "Part 7B Report UI loaded."
    );


    const rows =
        buildReportRows(
            currentReportType
        );


    console.log(
        "Current Report Rows:",
        rows
    );


    console.log(
        "Current Report Totals:",
        calculateReportTotals(
            rows
        )
    );

}
// ============================================================
// STAYFLOW HOTEL MANAGER
// PART 8A - FINAL APP CONNECTION
// ============================================================


// ------------------------------------------------------------
// PAGE NAVIGATION SETUP
// ------------------------------------------------------------

function setupNavigation() {

    const navItems =
        document.querySelectorAll(
            ".nav-item[data-page]"
        );

    const pageButtons =
        document.querySelectorAll(
            "[data-page]"
        );


    function handleNavigation(event) {

        const page =
            event.currentTarget.dataset.page;

        if (!page) {
            return;
        }

        navigate(page);

    }


    navItems.forEach(
        item => {

            item.addEventListener(
                "click",
                handleNavigation
            );

        }
    );


    pageButtons.forEach(
        button => {

            if (
                button.classList.contains(
                    "nav-item"
                )
            ) {
                return;
            }

            button.addEventListener(
                "click",
                handleNavigation
            );

        }
    );
}


// ------------------------------------------------------------
// ADD GUEST BUTTON
// ------------------------------------------------------------

function setupAddGuestButton() {

    const addBtn =
        $("addGuestBtn");

    const emptyBtn =
        $("emptyAddGuestBtn");

    const newBookingBtn =
        $("newBookingBtn");


    if (addBtn) {

        addBtn.addEventListener(
            "click",
            openGuestModal
        );

    }


    if (emptyBtn) {

        emptyBtn.addEventListener(
            "click",
            openGuestModal
        );

    }


    if (newBookingBtn) {

        newBookingBtn.addEventListener(
            "click",
            openGuestModal
        );

    }
}


// ------------------------------------------------------------
// GUEST MODAL SETUP
// ------------------------------------------------------------

function setupGuestModal() {

    const closeBtn =
        $("closeGuestModal");

    const cancelBtn =
        $("cancelGuestBtn");

    const form =
        $("guestForm");


    if (closeBtn) {

        closeBtn.addEventListener(
            "click",
            closeGuestModal
        );

    }


    if (cancelBtn) {

        cancelBtn.addEventListener(
            "click",
            closeGuestModal
        );

    }


    if (form) {

        form.addEventListener(
            "submit",
            addGuest
        );

    }
}


// ------------------------------------------------------------
// BOOKING ID GENERATOR
// ------------------------------------------------------------

function setupBookingIdGenerator() {

    const button =
        $("generateBookingIdBtn");

    if (!button) {
        return;
    }


    button.addEventListener(
        "click",
        () => {

            const field =
                $("bookingId");

            if (!field) {
                return;
            }

            field.value =
                generateBookingId();

        }
    );
}


// ------------------------------------------------------------
// ROOM SELECTOR SETUP
// ------------------------------------------------------------

function setupRoomSelectors() {

    const roomCount =
        $("numberOfRooms");


    if (!roomCount) {
        return;
    }


    roomCount.addEventListener(
        "change",
        () => {

            setupExtraRoomSelectors();

        }
    );


    setupExtraRoomSelectors();
}


// ------------------------------------------------------------
// PAYMENT INPUT SETUP
// ------------------------------------------------------------

function setupPaymentInputs() {

    const online =
        $("onlinePayment");

    const cash =
        $("cashPayment");


    function updatePayment() {

        const total =
            paymentTotal();


        const totalField =
            $("guestTotalPayment");


        if (totalField) {

            totalField.value =
                total.toFixed(2);

        }

    }


    if (online) {

        online.addEventListener(
            "input",
            updatePayment
        );

    }


    if (cash) {

        cash.addEventListener(
            "input",
            updatePayment
        );

    }


    updatePayment();
}


// ------------------------------------------------------------
// GUEST SEARCH
// ------------------------------------------------------------

function setupGuestSearchEvents() {

    const search =
        $("guestSearch");


    if (!search) {
        return;
    }


    search.addEventListener(
        "input",
        event => {

            renderGuestList(
                event.target.value
            );

        }
    );
}


// ------------------------------------------------------------
// ID PRINT SETUP
// ------------------------------------------------------------

function setupIDPrintPage() {

    setupIDEvents();

}


// ------------------------------------------------------------
// CONTINUE BOOKING SETUP
// ------------------------------------------------------------

function setupContinueBookingPage() {

    setupContinueBooking();

}


// ------------------------------------------------------------
// ROOM DETAIL SETUP
// ------------------------------------------------------------

function setupRoomDetailsPage() {

    setupRoomDetailClose();

}


// ------------------------------------------------------------
// REPORT PAGE SETUP
// ------------------------------------------------------------

function setupReportsPage() {

    setupReportTabs();

    setupReportButtons();

}


// ------------------------------------------------------------
// INITIAL PAGE RENDER
// ------------------------------------------------------------

function renderInitialApp() {

    renderAll();

    renderGuestList("");

    renderReport("daily");

}


// ------------------------------------------------------------
// PART 8A TEST
// ------------------------------------------------------------

function part8ATest() {

    console.log(
        "Part 8A connection functions loaded."
    );

    console.log(
        "Navigation setup:",
        typeof setupNavigation
    );

    console.log(
        "Guest setup:",
        typeof setupAddGuestButton
    );

    console.log(
        "Report setup:",
        typeof setupReportsPage
    );

}
// ============================================================
// STAYFLOW HOTEL MANAGER
// PART 8B - APP STARTUP
// ============================================================


// ------------------------------------------------------------
// START APP
// ------------------------------------------------------------

function startStayFlowApp() {

    console.log(
        "Starting StayFlow Hotel Manager..."
    );


    // Load saved data
    if (typeof loadData === "function") {

        loadData();

    }


    // Navigation
    setupNavigation();


    // Guest section
    setupAddGuestButton();

    setupGuestModal();

    setupBookingIdGenerator();

    setupRoomSelectors();

    setupPaymentInputs();

    setupGuestSearchEvents();

    setupGuestButtons();


    // Continue Existing Booking
    setupContinueBookingPage();


    // ID Printing
    setupIDPrintPage();


    // Rooms
    setupRoomDetailsPage();


    // Reports
    setupReportsPage();


    // Initial UI
    renderInitialApp();


    // Set current page
    navigate("dashboardPage");


    console.log(
        "StayFlow Hotel Manager started successfully."
    );

}


// ------------------------------------------------------------
// SAFE STARTUP
// ------------------------------------------------------------

function safeStartStayFlow() {

    try {

        startStayFlowApp();

    } catch (error) {

        console.error(
            "StayFlow startup error:",
            error
        );


        if (
            typeof toast === "function"
        ) {

            toast(
                "Startup Error",
                "Some app features could not start."
            );

        }

    }

}


// ------------------------------------------------------------
// BROWSER STARTUP
// ------------------------------------------------------------

function initializeStayFlow() {

    if (
        typeof document === "undefined"
    ) {

        console.log(
            "Browser environment not ready."
        );

        return;

    }


    safeStartStayFlow();

}


// ------------------------------------------------------------
// START ONLY WHEN DOCUMENT IS READY
// ------------------------------------------------------------

if (
    typeof document !== "undefined"
) {

    if (
        document.readyState === "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initializeStayFlow,
            {
                once: true
            }
        );

    } else {

        initializeStayFlow();

    }

}


// ------------------------------------------------------------
// PART 8B TEST
// ------------------------------------------------------------

function part8BTest() {

    console.log(
        "================================"
    );

    console.log(
        "STAYFLOW STARTUP TEST"
    );

    console.log(
        "================================"
    );


    console.log(
        "App name:",
        typeof APP_NAME !== "undefined"
            ? APP_NAME
            : "StayFlow"
    );


    console.log(
        "Total rooms:",
        typeof TOTAL_ROOMS !== "undefined"
            ? TOTAL_ROOMS
            : "Unknown"
    );


    console.log(
        "Guests:",
        data &&
        Array.isArray(data.guests)
            ? data.guests.length
            : 0
    );


    console.log(
        "StayFlow is ready."
    );

}