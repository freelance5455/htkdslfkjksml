```javascript id="q2v8km"
/* =========================================================
   MEDILINK — MEDICAL SYSTEM & USAGE
   FRONTEND HACKATHON PROTOTYPE
   ========================================================= */


/* =========================================================
   1. APPLICATION DATA
   ========================================================= */

let selectedSeverity = "";

let medicines = [
    {
        id: 1,
        name: "Vitamin D",
        time: "08:00",
        dosage: "1 tablet",
        taken: false
    },
    {
        id: 2,
        name: "Daily Medicine",
        time: "20:00",
        dosage: "1 tablet",
        taken: false
    }
];

let symptoms = [
    {
        medicine: "Sample Medicine",
        symptom: "No symptom recorded",
        severity: "Mild",
        date: "28 Sep 2026"
    }
];

let familyMembers = [
    {
        name: "Family Member 1",
        role: "Primary Contact",
        initial: "F"
    },
    {
        name: "Family Member 2",
        role: "Emergency Contact",
        initial: "M"
    }
];


/* =========================================================
   2. SIMULATED BLOOD DONOR DATABASE
   ========================================================= */

const donorDatabase = [
    {
        name: "Arun Kumar",
        blood: "O+",
        location: "Chennai",
        distance: "1.8 km",
        available: true
    },
    {
        name: "Rahul S",
        blood: "O+",
        location: "Royapettah",
        distance: "2.4 km",
        available: true
    },
    {
        name: "Mohamed A",
        blood: "B+",
        location: "Egmore",
        distance: "2.9 km",
        available: true
    },
    {
        name: "Vijay R",
        blood: "A+",
        location: "T. Nagar",
        distance: "4.2 km",
        available: true
    },
    {
        name: "Karthik M",
        blood: "A-",
        location: "Adyar",
        distance: "7.1 km",
        available: true
    },
    {
        name: "Irfan H",
        blood: "O-",
        location: "Anna Nagar",
        distance: "8.3 km",
        available: true
    },
    {
        name: "Sathish P",
        blood: "AB+",
        location: "Nungambakkam",
        distance: "3.6 km",
        available: true
    },
    {
        name: "Fahad M",
        blood: "B-",
        location: "Guindy",
        distance: "8.9 km",
        available: true
    }
];


/* =========================================================
   3. DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializeApplication();

});


/* =========================================================
   4. INITIALIZE APPLICATION
   ========================================================= */

function initializeApplication() {

    setTimeout(() => {

        const loader = document.getElementById("appLoader");

        if (loader) {
            loader.classList.add("hide");
        }

        const app = document.getElementById("app");

        if (app) {
            app.classList.remove("hidden");
        }

    }, 1000);


    renderMedicines();
    renderHomeMedicines();
    renderSymptoms();

    updateMedicineCount();

    setupShakeDetection();

}


/* =========================================================
   5. NAVIGATION
   ========================================================= */

function navigateTo(screenId) {

    const screens = document.querySelectorAll(".screen");

    screens.forEach(screen => {
        screen.classList.remove("active");
    });


    const targetScreen = document.getElementById(screenId);

    if (!targetScreen) {
        console.warn("Screen not found:", screenId);
        return;
    }

    targetScreen.classList.add("active");


    updateNavigation(screenId);


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });


    closeNotifications();

}


/* =========================================================
   6. UPDATE BOTTOM NAVIGATION
   ========================================================= */

function updateNavigation(screenId) {

    const navItems = document.querySelectorAll(".nav-item");

    navItems.forEach(item => {
        item.classList.remove("active");
    });


    const matchingItem =
        document.querySelector(
            `.nav-item[data-target="${screenId}"]`
        );


    if (matchingItem) {
        matchingItem.classList.add("active");
    }


    if (screenId === "symptomScreen") {

        navItems.forEach(item => {
            item.classList.remove("active");
        });

    }

}


/* =========================================================
   7. TOAST SYSTEM
   ========================================================= */

let toastTimer = null;

function showToast(
    title = "Success",
    message = "Action completed.",
    icon = "✓"
) {

    const toast = document.getElementById("toast");
    const toastTitle = document.getElementById("toastTitle");
    const toastMessage = document.getElementById("toastMessage");
    const toastIcon = document.getElementById("toastIcon");


    if (!toast) {
        return;
    }


    toastTitle.textContent = title;
    toastMessage.textContent = message;
    toastIcon.textContent = icon;


    toast.classList.add("show");


    clearTimeout(toastTimer);


    toastTimer = setTimeout(() => {

        toast.classList.remove("show");

    }, 3200);

}


/* =========================================================
   8. NOTIFICATIONS
   ========================================================= */

function showNotifications() {

    const panel =
        document.getElementById("notificationPanel");

    if (!panel) {
        return;
    }

    panel.classList.add("show");

}


function closeNotifications() {

    const panel =
        document.getElementById("notificationPanel");

    if (panel) {
        panel.classList.remove("show");
    }

}


/* =========================================================
   9. BLOOD DONOR SEARCH
   ========================================================= */

function findDonors() {

    const bloodGroup =
        document.getElementById("bloodGroup").value.trim();

    const location =
        document.getElementById("bloodLocation").value.trim();

    const results =
        document.getElementById("donorResults");


    if (!bloodGroup) {

        showToast(
            "Blood Group Required",
            "Please select a blood group.",
            "!"
        );

        return;
    }


    if (!location) {

        showToast(
            "Location Required",
            "Please enter a location.",
            "!"
        );

        return;
    }


    const normalizedLocation =
        location.toLowerCase();


    let matchingDonors =
        donorDatabase.filter(donor => {

            const bloodMatch =
                donor.blood === bloodGroup;

            const locationMatch =
                donor.location
                    .toLowerCase()
                    .includes(normalizedLocation) ||
                normalizedLocation.includes(
                    donor.location.toLowerCase()
                );

            return bloodMatch && locationMatch;

        });


    /*
       Prototype behavior:
       If the exact location has no donor,
       show donors with the selected blood group
       to demonstrate the search workflow.
    */

    if (matchingDonors.length === 0) {

        matchingDonors =
            donorDatabase.filter(
                donor => donor.blood === bloodGroup
            );

    }


    if (matchingDonors.length === 0) {

        results.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">!</div>
                <h3>No Donor Found</h3>
                <p>
                    No simulated donor is available for
                    ${escapeHTML(bloodGroup)}.
                </p>
            </div>
        `;

        return;
    }


    results.innerHTML = `
        <div class="section-heading">
            <div>
                <span class="section-tag">
                    SIMULATED RESULTS
                </span>

                <h3>
                    ${matchingDonors.length} Donor${matchingDonors.length > 1 ? "s" : ""}
                    Found
                </h3>
            </div>
        </div>
    `;


    matchingDonors.forEach((donor, index) => {

        const donorCard =
            document.createElement("div");

        donorCard.className = "donor-card";

        donorCard.style.animationDelay =
            `${index * 80}ms`;


        const initial =
            donor.name.charAt(0).toUpperCase();


        donorCard.innerHTML = `

            <div class="donor-avatar">
                ${escapeHTML(initial)}
            </div>

            <div class="donor-info">

                <strong>
                    ${escapeHTML(donor.name)}
                </strong>

                <span>
                    ⌖ ${escapeHTML(donor.location)}
                    · ${escapeHTML(donor.distance)}
                </span>

                <button
                    class="contact-donor"
                    onclick="contactDonor('${escapeAttribute(donor.name)}')"
                >
                    CONTACT
                </button>

            </div>

            <div class="blood-type">
                ${escapeHTML(donor.blood)}
            </div>
        `;


        results.appendChild(donorCard);

    });


    showToast(
        "Donors Found",
        "Nearby donor results loaded.",
        "+"
    );

}


/* =========================================================
   10. CONTACT DONOR
   ========================================================= */

function contactDonor(name) {

    showToast(
        "Contact Request",
        `Prototype request sent to ${name}.`,
        "✓"
    );

}


/* =========================================================
   11. MEDICAL PROFILE EDIT
   ========================================================= */

function editMedicalProfile() {

    const currentName =
        document.getElementById("medicalName").textContent;

    const currentBlood =
        document.getElementById("profileBlood").textContent;

    const currentAllergy =
        document.getElementById("profileAllergy").textContent;


    const newName =
        prompt(
            "Enter patient name:",
            currentName
        );


    if (newName === null) {
        return;
    }


    if (newName.trim() === "") {

        showToast(
            "Invalid Name",
            "Name cannot be empty.",
            "!"
        );

        return;
    }


    const newBlood =
        prompt(
            "Enter blood group:",
            currentBlood
        );


    if (newBlood === null) {
        return;
    }


    const newAllergy =
        prompt(
            "Enter allergies:",
            currentAllergy
        );


    if (newAllergy === null) {
        return;
    }


    document.getElementById("medicalName")
        .textContent = newName.trim();

    document.getElementById("homeUserName")
        .textContent =
        newName.trim().split(" ")[0];

    document.getElementById("profileBlood")
        .textContent = newBlood.trim() || "Unknown";

    document.getElementById("profileAllergy")
        .textContent =
        newAllergy.trim() || "None";


    document.getElementById("idPatientName")
        .textContent =
        newName.trim().toUpperCase();

    document.getElementById("idBlood")
        .textContent =
        newBlood.trim().toUpperCase() || "UNKNOWN";

    document.getElementById("idAllergy")
        .textContent =
        (newAllergy.trim() || "NONE").toUpperCase();


    showToast(
        "Profile Updated",
        "Medical information has been updated.",
        "✓"
    );

}


/* =========================================================
   12. MEDICAL ID
   ========================================================= */

function showMedicalIDMessage() {

    showToast(
        "Medical ID Ready",
        "Emergency Medical ID is available for demonstration.",
        "ID"
    );

}


/* =========================================================
   13. FAMILY MEMBER
   ========================================================= */

function addFamilyMember() {

    const name =
        prompt("Enter family member name:");

    if (name === null) {
        return;
    }


    if (name.trim() === "") {

        showToast(
            "Invalid Name",
            "Please enter a family member name.",
            "!"
        );

        return;
    }


    const role =
        prompt(
            "Enter role:",
            "Emergency Contact"
        );


    if (role === null) {
        return;
    }


    const member = {

        name: name.trim(),

        role:
            role.trim() ||
            "Emergency Contact",

        initial:
            name.trim()
                .charAt(0)
                .toUpperCase()

    };


    familyMembers.push(member);


    renderFamilyMembers();


    showToast(
        "Family Added",
        `${member.name} is now in your network.`,
        "+"
    );

}


function renderFamilyMembers() {

    const list =
        document.getElementById("familyList");

    if (!list) {
        return;
    }


    list.innerHTML = "";


    familyMembers.forEach(member => {

        const element =
            document.createElement("div");

        element.className =
            "family-member";


        element.innerHTML = `

            <div class="member-avatar">
                ${escapeHTML(member.initial)}
            </div>

            <div class="member-info">

                <strong>
                    ${escapeHTML(member.name)}
                </strong>

                <span>
                    ${escapeHTML(member.role)}
                </span>

            </div>

            <div class="member-status">
                <i></i> ONLINE
            </div>

        `;


        list.appendChild(element);

    });

}


/* =========================================================
   14. EMERGENCY SYSTEM
   ========================================================= */

function openEmergency() {

    const overlay =
        document.getElementById("emergencyOverlay");

    if (!overlay) {
        return;
    }


    overlay.classList.add("show");


    document.body.style.overflow = "hidden";

}


function closeEmergency() {

    const overlay =
        document.getElementById("emergencyOverlay");

    if (!overlay) {
        return;
    }


    overlay.classList.remove("show");


    document.body.style.overflow = "";

}


function sendEmergencyAlert() {

    closeEmergency();


    setTimeout(() => {

        showToast(
            "EMERGENCY ALERT SENT",
            `${familyMembers.length} family contact(s) notified in this prototype.`,
            "!"
        );


        markNotificationActive();


        setTimeout(() => {

            showEmergencyConfirmation();

        }, 500);

    }, 250);

}


function showEmergencyConfirmation() {

    const overlay =
        document.createElement("div");

    overlay.className =
        "emergency-overlay show";


    overlay.innerHTML = `

        <div class="emergency-modal">

            <div
                class="radar-core"
                style="
                    margin: 0 auto 20px;
                    background: linear-gradient(
                        145deg,
                        #36e0d0,
                        #248fca
                    );
                "
            >
                ✓
            </div>

            <span class="emergency-label">
                ALERT TRANSMISSION
            </span>

            <h2>Alert Sent</h2>

            <p>
                Your emergency network has been
                notified in this prototype.
            </p>

            <button
                class="primary-btn"
                onclick="this.closest('.emergency-overlay').remove()"
            >
                DONE
            </button>

        </div>
    `;


    document.body.appendChild(overlay);

}


function markNotificationActive() {

    const dot =
        document.getElementById("notificationDot");

    if (dot) {
        dot.style.display = "block";
    }

}


/* =========================================================
   15. SHAKE DETECTION
   ========================================================= */

let shakeLastTime = 0;

let shakeThreshold = 18;

let lastAcceleration = {
    x: null,
    y: null,
    z: null
};


function setupShakeDetection() {

    if (!window.DeviceMotionEvent) {
        return;
    }


    window.addEventListener(
        "devicemotion",
        handleDeviceMotion,
        false
    );

}


function handleDeviceMotion(event) {

    const acceleration =
        event.accelerationIncludingGravity;


    if (!acceleration) {
        return;
    }


    const x = acceleration.x || 0;
    const y = acceleration.y || 0;
    const z = acceleration.z || 0;


    if (
        lastAcceleration.x === null ||
        lastAcceleration.y === null ||
        lastAcceleration.z === null
    ) {

        lastAcceleration = {
            x,
            y,
            z
        };

        return;

    }


    const deltaX =
        Math.abs(x - lastAcceleration.x);

    const deltaY =
        Math.abs(y - lastAcceleration.y);

    const deltaZ =
        Math.abs(z - lastAcceleration.z);


    const totalChange =
        deltaX + deltaY + deltaZ;


    const now =
        Date.now();


    if (
        totalChange > shakeThreshold &&
        now - shakeLastTime > 1500
    ) {

        shakeLastTime = now;

        openEmergency();

    }


    lastAcceleration = {
        x,
        y,
        z
    };

}


/* =========================================================
   16. MEDICINE SYSTEM
   ========================================================= */

function addMedicine() {

    const name =
        document.getElementById("medicineName")
            .value.trim();

    const time =
        document.getElementById("medicineTime")
            .value;

    const dosage =
        document.getElementById("medicineDosage")
            .value.trim();


    if (!name) {

        showToast(
            "Medicine Required",
            "Enter the medicine name.",
            "!"
        );

        return;
    }


    if (!time) {

        showToast(
            "Time Required",
            "Select the medicine time.",
            "!"
        );

        return;
    }


    if (!dosage) {

        showToast(
            "Dosage Required",
            "Enter the dosage.",
            "!"
        );

        return;
    }


    const medicine = {

        id:
            Date.now(),

        name,

        time,

        dosage,

        taken: false

    };


    medicines.push(medicine);


    document.getElementById("medicineName")
        .value = "";

    document.getElementById("medicineTime")
        .value = "";

    document.getElementById("medicineDosage")
        .value = "";


    renderMedicines();

    renderHomeMedicines();

    updateMedicineCount();


    showToast(
        "Medicine Added",
        `${name} has been added to today's schedule.`,
        "+"
    );

}


/* =========================================================
   17. RENDER MEDICINES
   ========================================================= */

function renderMedicines() {

    const list =
        document.getElementById("medicineList");

    if (!list) {
        return;
    }


    list.innerHTML = "";


    if (medicines.length === 0) {

        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">M</div>
                <h3>No Medicines</h3>
                <p>
                    Add a medicine to create your schedule.
                </p>
            </div>
        `;

        return;
    }


    const sortedMedicines =
        [...medicines].sort(
            (a, b) =>
                a.time.localeCompare(b.time)
        );


    sortedMedicines.forEach(medicine => {

        const item =
            document.createElement("div");

        item.className =
            "medicine-item";


        const displayTime =
            formatTime(medicine.time);


        item.innerHTML = `

            <div class="medicine-symbol">
                M
            </div>

            <div class="medicine-info">

                <strong>
                    ${escapeHTML(medicine.name)}
                </strong>

                <span>
                    ${escapeHTML(displayTime)}
                    · ${escapeHTML(medicine.dosage)}
                </span>

            </div>

            <button
                class="medicine-status"
                onclick="toggleMedicine(${medicine.id})"
            >
                ${medicine.taken ? "✓ TAKEN" : "TAKE"}
            </button>

            <button
                class="remove-medicine"
                onclick="removeMedicine(${medicine.id})"
                title="Remove"
            >
                ×
            </button>

        `;


        if (medicine.taken) {

            item.querySelector(".medicine-status").style.background =
                "rgba(72, 227, 156, 0.15)";

        }


        list.appendChild(item);

    });

}


function renderHomeMedicines() {

    const list =
        document.getElementById("homeMedicineList");

    if (!list) {
        return;
    }


    list.innerHTML = "";


    if (medicines.length === 0) {

        list.innerHTML = `
            <div class="empty-state">
                <p>No medicine scheduled.</p>
            </div>
        `;

        return;
    }


    const sorted =
        [...medicines]
            .sort(
                (a, b) =>
                    a.time.localeCompare(b.time)
            )
            .slice(0, 3);


    sorted.forEach(medicine => {

        const item =
            document.createElement("div");

        item.className =
            "medicine-item";


        item.innerHTML = `

            <div class="medicine-symbol">
                M
            </div>

            <div class="medicine-info">

                <strong>
                    ${escapeHTML(medicine.name)}
                </strong>

                <span>
                    ${escapeHTML(formatTime(medicine.time))}
                    · ${escapeHTML(medicine.dosage)}
                </span>

            </div>

            <div class="medicine-status">
                ${medicine.taken ? "✓ TAKEN" : "PENDING"}
            </div>

        `;


        list.appendChild(item);

    });

}


/* =========================================================
   18. TOGGLE MEDICINE
   ========================================================= */

function toggleMedicine(id) {

    const medicine =
        medicines.find(
            item => item.id === id
        );


    if (!medicine) {
        return;
    }


    medicine.taken =
        !medicine.taken;


    renderMedicines();

    renderHomeMedicines();

    updateMedicineCount();


    if (medicine.taken) {

        showToast(
            "Medicine Taken",
            `${medicine.name} marked as taken.`,
            "✓"
        );

    } else {

        showToast(
            "Status Updated",
            `${medicine.name} marked as not taken.`,
            "!"
        );

    }

}


/* =========================================================
   19. REMOVE MEDICINE
   ========================================================= */

function removeMedicine(id) {

    const medicine =
        medicines.find(
            item => item.id === id
        );


    if (!medicine) {
        return;
    }


    medicines =
        medicines.filter(
            item => item.id !== id
        );


    renderMedicines();

    renderHomeMedicines();

    updateMedicineCount();


    showToast(
        "Medicine Removed",
        `${medicine.name} was removed.`,
        "×"
    );

}


/* =========================================================
   20. MEDICINE COUNT
   ========================================================= */

function updateMedicineCount() {

    const counter =
        document.getElementById("medicineCount");

    if (!counter) {
        return;
    }


    counter.textContent =
        medicines.length;

}


/* =========================================================
   21. SYMPTOM SYSTEM
   ========================================================= */

function selectSeverity(button, severity) {

    const buttons =
        document.querySelectorAll(".severity-btn");


    buttons.forEach(btn => {
        btn.classList.remove("selected");
    });


    button.classList.add("selected");


    selectedSeverity =
        severity;

}


function saveSymptom() {

    const medicine =
        document.getElementById("symptomMedicine")
            .value.trim();

    const symptom =
        document.getElementById("symptomText")
            .value.trim();


    if (!medicine) {

        showToast(
            "Medicine Required",
            "Enter the medicine name.",
            "!"
        );

        return;
    }


    if (!symptom) {

        showToast(
            "Symptom Required",
            "Describe the symptom or problem.",
            "!"
        );

        return;
    }


    if (!selectedSeverity) {

        showToast(
            "Severity Required",
            "Select Mild, Moderate or Severe.",
            "!"
        );

        return;
    }


    const record = {

        medicine,

        symptom,

        severity:
            selectedSeverity,

        date:
            getCurrentDate()

    };


    symptoms.unshift(record);


    document.getElementById("symptomMedicine")
        .value = "";

    document.getElementById("symptomText")
        .value = "";


    selectedSeverity = "";


    document
        .querySelectorAll(".severity-btn")
        .forEach(btn => {
            btn.classList.remove("selected");
        });


    renderSymptoms();


    showToast(
        "Record Saved",
        "Your medicine and symptom record was saved.",
        "✓"
    );

}


/* =========================================================
   22. RENDER SYMPTOMS
   ========================================================= */

function renderSymptoms() {

    const list =
        document.getElementById("symptomList");

    if (!list) {
        return;
    }


    list.innerHTML = "";


    if (symptoms.length === 0) {

        list.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">+</div>
                <h3>No Records Yet</h3>
                <p>
                    Your recorded symptoms will appear here.
                </p>
            </div>
        `;

        return;
    }


    symptoms.forEach(record => {

        const element =
            document.createElement("div");

        element.className =
            "symptom-record";


        element.innerHTML = `

            <div class="symptom-record-top">

                <strong>
                    ${escapeHTML(record.medicine)}
                </strong>

                <span class="symptom-date">
                    ${escapeHTML(record.date)}
                </span>

            </div>

            <p>
                ${escapeHTML(record.symptom)}
            </p>

            <span class="severity-badge">
                ${escapeHTML(record.severity.toUpperCase())}
            </span>

        `;


        list.appendChild(element);

    });

}


/* =========================================================
   23. DATE / TIME HELPERS
   ========================================================= */

function formatTime(time) {

    if (!time) {
        return "--:--";
    }


    const parts =
        time.split(":");


    let hours =
        parseInt(parts[0], 10);

    const minutes =
        parts[1];


    const suffix =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12 || 12;


    return `${hours}:${minutes} ${suffix}`;

}


function getCurrentDate() {

    const date =
        new Date();


    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "short",
            year: "numeric"
        }
    );

}


/* =========================================================
   24. SECURITY / SAFE DISPLAY HELPERS
   ========================================================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


function escapeAttribute(value) {

    return String(value)
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "\\'")
        .replace(/"/g, "&quot;");

}


/* =========================================================
   25. CLOSE EMERGENCY WHEN CLICKING OUTSIDE
   ========================================================= */

document.addEventListener("click", event => {

    const overlay =
        document.getElementById("emergencyOverlay");


    if (
        overlay &&
        overlay.classList.contains("show") &&
        event.target === overlay
    ) {

        closeEmergency();

    }

});


/* =========================================================
   26. CLOSE NOTIFICATION WHEN CLICKING OUTSIDE
   ========================================================= */

document.addEventListener("click", event => {

    const panel =
        document.getElementById("notificationPanel");

    const button =
        document.querySelector(".notification-btn");


    if (
        panel &&
        panel.classList.contains("show") &&
        !panel.contains(event.target) &&
        !button.contains(event.target)
    ) {

        closeNotifications();

    }

});


/* =========================================================
   27. KEYBOARD SHORTCUTS FOR DEMONSTRATION
   ========================================================= */

document.addEventListener("keydown", event => {

    /*
       E = Emergency
       H = Home
       B = Blood
       M = Medicine
       F = Family
       I = Medical ID
    */


    if (
        event.target.tagName === "INPUT" ||
        event.target.tagName === "TEXTAREA" ||
        event.target.tagName === "SELECT"
    ) {
        return;
    }


    const key =
        event.key.toLowerCase();


    switch (key) {

        case "e":
            openEmergency();
            break;

        case "h":
            navigateTo("homeScreen");
            break;

        case "b":
            navigateTo("bloodScreen");
            break;

        case "m":
            navigateTo("medicineScreen");
            break;

        case "f":
            navigateTo("familyScreen");
            break;

        case "i":
            navigateTo("idScreen");
            break;

        default:
            break;

    }

});


/* =========================================================
   28. DEMO NAVIGATION TO SYMPTOM RECORD
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /*
       Add a hidden keyboard shortcut for the
       symptom-record screen.

       Press "S" while not typing.
    */

});


document.addEventListener("keydown", event => {

    if (
        event.target.tagName === "INPUT" ||
        event.target.tagName === "TEXTAREA" ||
        event.target.tagName === "SELECT"
    ) {
        return;
    }


    if (event.key.toLowerCase() === "s") {

        navigateTo("symptomScreen");

    }

});


/* =========================================================
   29. CONSOLE DEMO INFORMATION
   ========================================================= */

console.log(
    "%c MEDILINK HEALTHCARE PROTOTYPE ",
    "font-size:16px;font-weight:bold;"
);

console.log(
    "Frontend prototype: HTML + CSS + JavaScript"
);

console.log(
    "No backend or external images are required."
);

console.log(
    "Emergency, blood donor, medical ID, family, medicine and symptom features are simulated."
);


/* =========================================================
   END OF SCRIPT.JS
   ========================================================= */
```
