// ===============================
// ChatSBD — Galaxy LCD
// ===============================

// 1. CẤU HÌNH GEMINI
// Thay API_KEY bằng API key mới của bạn.
// Không chia sẻ key hoặc đăng mã nguồn chứa key công khai.
const API_KEY = "AQ.Ab8RN6J7r4L7Z6197gnzU0HDkhW_aVBOv1SaPMyVancy_B3ekQ";
const MODEL = "gemini-3.5-flash";
const API_URL =
  `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;

// 2. LẤY CÁC THÀNH PHẦN GIAO DIỆN
const $ = (selector) => document.querySelector(selector);

const chat = $("#chat");
const messages = $("#messages");
const welcome = $("#welcome");
const form = $("#bar");
const input = $("#message");
const sendButton = $("#sendButton");
const thinking = $("#thinking");

const menuToggle = $("#menuToggle");
const sidePanel = $("#sidePanel");
const panelScrim = $("#panelScrim");
const closeMenu = $("#closeMenu");
const historyList = $("#historyList");
const newChatButton = $("#newChat");
const newChatTop = $("#newChatTop");
const clearChatButton = $("#clearChat");
const animationToggle = $("#spaceAnimationToggle");
const animationStatus = $("#animationStatus");

// 3. DỮ LIỆU VÀ LƯU LỊCH SỬ
// Lưu trên trình duyệt của thiết bị đang sử dụng.
const STORAGE_KEY = "chatsbd_galaxy_history_v1";
const SETTINGS_KEY = "chatsbd_galaxy_settings_v1";
const MAX_CHATS = 30;
const MAX_HISTORY_MESSAGES = 80;

let conversations = loadConversations();
let currentChatId = null;
let busy = false;

function makeId() {
  return Date.now().toString(36) +
    Math.random().toString(36).slice(2, 8);
}

function loadConversations() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (!Array.isArray(saved)) return [];

    return saved
      .filter(item =>
        item &&
        typeof item.id === "string" &&
        Array.isArray(item.messages)
      )
      .map(item => ({
        id: item.id,
        title: String(item.title || "Cuộc trò chuyện mới"),
        updatedAt: Number(item.updatedAt) || Date.now(),
        messages: item.messages
          .filter(m =>
            m &&
            (m.role === "user" || m.role === "model") &&
            typeof m.text === "string"
          )
          .slice(-MAX_HISTORY_MESSAGES)
      }))
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, MAX_CHATS);
  } catch (error) {
    console.warn("Không thể đọc lịch sử:", error);
    return [];
  }
}

function saveConversations() {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(conversations.slice(0, MAX_CHATS))
    );
    return true;
  } catch (error) {
    console.warn("Không thể lưu lịch sử:", error);
    return false;
  }
}

function getCurrentChat() {
  return conversations.find(c => c.id === currentChatId) || null;
}

function createConversation() {
  const conversation = {
    id: makeId(),
    title: "Cuộc trò chuyện mới",
    updatedAt: Date.now(),
    messages: []
  };

  conversations.unshift(conversation);
  currentChatId = conversation.id;

  conversations = conversations.slice(0, MAX_CHATS);
  saveConversations();
  renderHistory();
  renderConversation();
  hideMenu();

  input.value = "";
  resizeInput();
  input.focus();

  return conversation;
}

function ensureConversation() {
  return getCurrentChat() || createConversation();
}

function updateConversation(conversation) {
  conversation.updatedAt = Date.now();

  conversations.sort((a, b) => b.updatedAt - a.updatedAt);
  conversations = conversations.slice(0, MAX_CHATS);

  saveConversations();
  renderHistory();
}

function formatDate(timestamp) {
  try {
    return new Date(timestamp).toLocaleString("vi-VN", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch {
    return "";
  }
}

function makeTitle(text) {
  const clean = text.replace(/\s+/g, " ").trim();
  return clean.length > 34 ? clean.slice(0, 34) + "…" : clean;
}

// 4. HIỂN THỊ LỊCH SỬ
function renderHistory() {
  historyList.replaceChildren();

  if (conversations.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-history";
    empty.textContent = "Chưa có cuộc trò chuyện nào.";
    historyList.appendChild(empty);
    return;
  }

  conversations.forEach(conversation => {
    const row = document.createElement("div");
    row.className = "history-item";

    const openButton = document.createElement("button");
    openButton.className =
      "history-open" +
      (conversation.id === currentChatId ? " active" : "");
    openButton.type = "button";

    const title = document.createElement("span");
    title.className = "history-title";
    title.textContent = conversation.title;

    const date = document.createElement("span");
    date.className = "history-date";
    date.textContent = formatDate(conversation.updatedAt);

    openButton.append(title, date);
    openButton.addEventListener("click", () => {
      if (busy) return;
      currentChatId = conversation.id;
      renderHistory();
      renderConversation();
      hideMenu();
    });

    const deleteButton = document.createElement("button");
    deleteButton.className = "history-delete";
    deleteButton.type = "button";
    deleteButton.textContent = "✕";
    deleteButton.setAttribute("aria-label", "Xóa " + conversation.title);

    deleteButton.addEventListener("click", () => {
      if (busy) return;

      const confirmed = confirm(
        `Xóa cuộc trò chuyện "${conversation.title}"?`
      );
      if (!confirmed) return;

      conversations = conversations.filter(
        c => c.id !== conversation.id
      );

      if (currentChatId === conversation.id) {
        currentChatId = null;
      }

      saveConversations();
      renderHistory();

      if (!getCurrentChat()) {
        if (conversations.length) {
          currentChatId = conversations[0].id;
        } else {
          createConversation();
          return;
        }
      }

      renderConversation();
    });

    row.append(openButton, deleteButton);
    historyList.appendChild(row);
  });
}

// 5. HIỂN THỊ TIN NHẮN
function addMessage(role, text, options = {}) {
  const wrapper = document.createElement("article");
  wrapper.className = "msg " + (role === "user" ? "user" : "assistant");

  const avatar = document.createElement("div");
  avatar.className = "avatar";
  avatar.textContent = role === "user" ? "●" : "✦";
  avatar.setAttribute("aria-hidden", "true");

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.textContent = text;

  if (options.error) bubble.classList.add("error");

  wrapper.append(avatar, bubble);
  messages.appendChild(wrapper);

  scrollToBottom();
  return wrapper;
}

function renderConversation() {
  messages.replaceChildren();

  const conversation = getCurrentChat();
  const hasMessages = !!conversation && conversation.messages.length > 0;

  welcome.hidden = hasMessages;

  if (conversation) {
    conversation.messages.forEach(message => {
      addMessage(message.role, message.text);
    });
  }

  scrollToBottom();
}

function scrollToBottom() {
  requestAnimationFrame(() => {
    chat.scrollTop = chat.scrollHeight;
  });
}

function setBusy(value) {
  busy = value;
  sendButton.disabled = value;
  input.disabled = value;
  thinking.hidden = !value;
  sendButton.textContent = value ? "…" : "➤";
  sendButton.setAttribute(
    "aria-label",
    value ? "Đang gửi tin nhắn" : "Gửi tin nhắn"
  );
}

function addToConversation(role, text) {
  const conversation = ensureConversation();

  conversation.messages.push({ role, text });
  conversation.messages =
    conversation.messages.slice(-MAX_HISTORY_MESSAGES);

  if (role === "user" && conversation.title === "Cuộc trò chuyện mới") {
    conversation.title = makeTitle(text);
  }

  updateConversation(conversation);
  return conversation;
}

// 6. GỌI GEMINI API
async function askGemini(conversation) {
  if (!API_KEY || API_KEY === "DAN_API_KEY_MOI_CUA_BAN_VAO_DAY") {
    throw new Error(
      "Bạn chưa nhập API key. Hãy mở script.js và thay API_KEY bằng key Gemini của bạn."
    );
  }

  const contents = conversation.messages.map(message => ({
    role: message.role,
    parts: [{ text: message.text }]
  }));

  const response = await fetch(`${API_URL}?key=${encodeURIComponent(API_KEY)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      systemInstruction: {
        parts: [{
          text: "Bạn là ChatSBD, trợ lý AI thân thiện, hữu ích. Trả lời bằng tiếng Việt khi phù hợp. Trình bày rõ ràng, dễ hiểu."
        }]
      },
      contents,
      generationConfig: {
        temperature: 0.8,
        topP: 0.95,
        maxOutputTokens: 4096
      }
    })
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const apiMessage = data?.error?.message;
    const apiStatus = data?.error?.status;

    if (response.status === 400 || response.status === 403) {
      throw new Error(
        "Gemini từ chối yêu cầu. Hãy kiểm tra API key, quyền sử dụng API và cấu hình dự án. " +
        (apiMessage || "")
      );
    }

    if (response.status === 404) {
      throw new Error(
        "Không tìm thấy model Gemini. Hãy kiểm tra tên model và các model được hỗ trợ cho API key của bạn. " +
        (apiMessage || "")
      );
    }

    if (response.status === 429) {
      throw new Error(
        "Gemini đang giới hạn số lượt gọi hoặc đã hết quota. Hãy đợi rồi thử lại. " +
        (apiMessage || "")
      );
    }

    throw new Error(
      `Lỗi Gemini (${response.status}${apiStatus ? ", " + apiStatus : ""}): ` +
      (apiMessage || "Không nhận được phản hồi hợp lệ.")
    );
  }

  const answer = data?.candidates?.[0]?.content?.parts
    ?.map(part => part.text || "")
    .join("")
    .trim();

  if (!answer) {
    const reason = data?.candidates?.[0]?.finishReason;
    throw new Error(
      "Gemini không trả về nội dung. " +
      (reason ? "Lý do: " + reason : "Hãy thử gửi lại câu hỏi.")
    );
  }

  return answer;
}

// 7. GỬI TIN NHẮN
async function sendMessage(text) {
  const prompt = text.trim();
  if (!prompt || busy) return;

  const conversation = ensureConversation();

  welcome.hidden = true;
  addToConversation("user", prompt);
  addMessage("user", prompt);

  input.value = "";
  resizeInput();
  setBusy(true);

  try {
    const answer = await askGemini(conversation);
    addToConversation("model", answer);
    addMessage("model", answer);
  } catch (error) {
    console.error(error);

    addMessage(
      "model",
      "Không thể kết nối Gemini.\n\n" +
      (error.message || "Đã xảy ra lỗi không xác định.") +
      "\n\nHãy kiểm tra kết nối mạng, API key và model rồi thử lại.",
      { error: true }
    );
  } finally {
    setBusy(false);
    input.focus();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendMessage(input.value);
});

input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

function resizeInput() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 130) + "px";
}

input.addEventListener("input", resizeInput);

// 8. MENU TRƯỢT
function showMenu() {
  sidePanel.classList.add("open");
  panelScrim.classList.add("visible");
  menuToggle.setAttribute("aria-expanded", "true");
}

function hideMenu() {
  sidePanel.classList.remove("open");
  panelScrim.classList.remove("visible");
  menuToggle.setAttribute("aria-expanded", "false");
}

menuToggle.addEventListener("click", () => {
  sidePanel.classList.contains("open") ? hideMenu() : showMenu();
});

closeMenu.addEventListener("click", hideMenu);
panelScrim.addEventListener("click", hideMenu);

document.addEventListener("keydown", event => {
  if (event.key === "Escape") hideMenu();
});

// 9. CUỘC TRÒ CHUYỆN MỚI VÀ XÓA
newChatButton.addEventListener("click", () => {
  if (busy) return;
  createConversation();
});

newChatTop.addEventListener("click", () => {
  if (busy) return;
  createConversation();
});

clearChatButton.addEventListener("click", () => {
  if (busy) return;

  const conversation = getCurrentChat();
  if (!conversation || conversation.messages.length === 0) {
    alert("Cuộc trò chuyện này chưa có tin nhắn.");
    return;
  }

  if (!confirm("Xóa toàn bộ tin nhắn trong cuộc trò chuyện này?")) {
    return;
  }

  conversation.messages = [];
  conversation.title = "Cuộc trò chuyện mới";
  conversation.updatedAt = Date.now();

  saveConversations();
  renderHistory();
  renderConversation();
  hideMenu();
});

// 10. NÚT GỢI Ý
document.querySelectorAll(".suggestion").forEach(button => {
  button.addEventListener("click", () => {
    if (busy) return;
    sendMessage(button.dataset.prompt || button.textContent);
  });
});

// 11. CÀI ĐẶT HIỆU ỨNG
function setAnimation(enabled) {
  document.body.classList.toggle("space-animation-off", !enabled);
  animationToggle.checked = enabled;
  animationStatus.textContent = enabled
    ? "Hiệu ứng đang bật"
    : "Hiệu ứng đã tắt";

  try {
    const settings = JSON.parse(
      localStorage.getItem(SETTINGS_KEY) || "{}"
    );
    settings.animation = enabled;
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (error) {
    console.warn("Không thể lưu cài đặt:", error);
  }
}

animationToggle.addEventListener("change", () => {
  setAnimation(animationToggle.checked);
});

// 12. KHỞI ĐỘNG
function init() {
  let animationEnabled = true;

  try {
    const settings = JSON.parse(
      localStorage.getItem(SETTINGS_KEY) || "{}"
    );
    if (typeof settings.animation === "boolean") {
      animationEnabled = settings.animation;
    }
  } catch (error) {
    console.warn("Không thể đọc cài đặt:", error);
  }

  setAnimation(animationEnabled);

  if (conversations.length > 0) {
    currentChatId = conversations[0].id;
  } else {
    const conversation = {
      id: makeId(),
      title: "Cuộc trò chuyện mới",
      updatedAt: Date.now(),
      messages: []
    };
    conversations.unshift(conversation);
    currentChatId = conversation.id;
    saveConversations();
  }

  renderHistory();
  renderConversation();
}

init();