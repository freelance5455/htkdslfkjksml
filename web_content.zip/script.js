
const rowCount = document.getElementById('rowCount');
const countLabel = document.getElementById('countLabel');
const tableBody = document.getElementById('tableBody');
const tableFoot = document.getElementById('tableFoot');
const statusEl = document.getElementById('status');

let solved = false;

const fmt = n =>
  Number.isFinite(n)
    ? (Math.round((n + Number.EPSILON) * 10000) / 10000).toString()
    : '—';

function setStatus(message, type = '') {
  statusEl.textContent = message;
  statusEl.className = 'status' + (type ? ' ' + type : '');
}

function escapeAttr(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('"', '&quot;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');
}

function resetResults() {
  tableFoot.innerHTML = '';

  for (const id of [
    'totalFResult',
    'totalFxResult',
    'meanResult',
    'medianResult',
    'modeResult'
  ]) {
    document.getElementById(id).textContent = '—';
  }

  document.getElementById('meanWork').textContent = 'Σfx ÷ N';
  document.getElementById('medianWork').textContent = 'Grouped-data median';
  document.getElementById('modeWork').textContent = 'Grouped-data mode';

  tableBody.querySelectorAll('[data-out]').forEach(cell => {
    cell.textContent = '—';
    cell.classList.add('empty');
  });

  solved = false;
}

function buildRows(keepValues = true) {
  let count = Number.parseInt(rowCount.value, 10);

  if (!Number.isFinite(count)) count = 5;

  count = Math.max(1, Math.min(15, count));
  rowCount.value = count;
  countLabel.textContent = count;

  const oldRows = [
    ...tableBody.querySelectorAll('tr')
  ].map(tr => ({
    interval: tr.querySelector('.interval').value,
    frequency: tr.querySelector('.frequency').value
  }));

  tableBody.innerHTML = '';
  tableFoot.innerHTML = '';

  for (let i = 0; i < count; i++) {
    const previous = keepValues ? (oldRows[i] || {}) : {};

    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td class="num">${i + 1}</td>
      <td>
        <input
          class="interval"
          type="text"
          inputmode="text"
          aria-label="Class interval ${i + 1}"
          placeholder="e.g. 1–4"
          value="${escapeAttr(previous.interval || '')}"
        >
      </td>
      <td>
        <input
          class="frequency"
          type="number"
          inputmode="decimal"
          min="0"
          step="any"
          aria-label="Frequency ${i + 1}"
          placeholder="Enter f"
          value="${escapeAttr(previous.frequency || '')}"
        >
      </td>
      <td class="output empty" data-out="mid">—</td>
      <td class="output empty" data-out="fx">—</td>
      <td class="output empty" data-out="cf">—</td>
    `;

    tableBody.appendChild(tr);
  }

  resetResults();
}

function parseInterval(raw) {
  const s = raw
    .trim()
    .replace(/[−–—]/g, '-')
    .replace(/\s+/g, '');

  const match = s.match(
    /^(-?\d+(?:\.\d+)?)-(-?\d+(?:\.\d+)?)$/
  );

  if (!match) return null;

  const low = Number(match[1]);
  const high = Number(match[2]);

  if (!Number.isFinite(low) ||
      !Number.isFinite(high) ||
      high <= low) {
    return null;
  }

  const integerLimits =
    Number.isInteger(low) && Number.isInteger(high);

  const width = integerLimits
    ? high - low + 1
    : high - low;

  return {
    low,
    high,
    mid: (low + high) / 2,
    width,
    boundaryLow: integerLimits ? low - 0.5 : low,
    boundaryHigh: integerLimits ? high + 0.5 : high
  };
}

function solve() {
  resetResults();

  const rows = [
    ...tableBody.querySelectorAll('tr')
  ].map((tr, i) => {
    const intervalRaw = tr.querySelector('.interval').value;
    const fRaw = tr.querySelector('.frequency').value;

    return {
      tr,
      i,
      intervalRaw,
      fRaw,
      interval: parseInterval(intervalRaw),
      f: fRaw.trim() === '' ? NaN : Number(fRaw)
    };
  });

  // Validate every class interval.
  for (const r of rows) {
    if (!r.interval) {
      setStatus(
        `Row ${r.i + 1}: enter a valid class interval, such as 1–4 or 10–19.`,
        'error'
      );
      return;
    }
  }

  // Validate frequencies.
  for (const r of rows) {
    if (
      r.fRaw.trim() === '' ||
      !Number.isFinite(r.f) ||
      r.f < 0
    ) {
      setStatus(
        `Row ${r.i + 1}: enter a frequency of 0 or greater.`,
        'error'
      );
      return;
    }
  }

  // Class intervals must be ordered and must not overlap.
  for (let i = 1; i < rows.length; i++) {
    const previous = rows[i - 1].interval;
    const current = rows[i].interval;

    if (
      current.boundaryLow <
      previous.boundaryHigh - 1e-9
    ) {
      setStatus(
        `Rows ${i} and ${i + 1} overlap or are out of order. Check your class intervals.`,
        'error'
      );
      return;
    }
  }

  const widths = rows.map(r => r.interval.width);
  const standardWidth = widths[0];

  const equalWidths = widths.every(
    w => Math.abs(w - standardWidth) < 1e-9
  );

  let cf = 0;
  let sumFx = 0;
  let N = 0;

  // Calculate midpoint, fx, and cumulative frequency.
  rows.forEach(r => {
    r.x = r.interval.mid;
    r.fx = r.x * r.f;

    N += r.f;
    sumFx += r.fx;
    cf += r.f;
    r.cf = cf;

    r.tr.querySelector('[data-out="mid"]').textContent =
      fmt(r.x);

    r.tr.querySelector('[data-out="fx"]').textContent =
      fmt(r.fx);

    r.tr.querySelector('[data-out="cf"]').textContent =
      fmt(r.cf);

    r.tr.querySelectorAll('.output').forEach(cell => {
      cell.classList.remove('empty');
    });
  });

  // Show totals.
  tableFoot.innerHTML = `
    <tr>
      <td colspan="2">TOTAL</td>
      <td>${fmt(N)}</td>
      <td>—</td>
      <td>${fmt(sumFx)}</td>
      <td>${fmt(cf)}</td>
    </tr>
  `;

  document.getElementById('totalFResult').textContent = fmt(N);
  document.getElementById('totalFxResult').textContent = fmt(sumFx);

  if (N <= 0) {
    setStatus(
      'The table is filled, but at least one frequency must be greater than zero to calculate the mean, median, and mode.',
      'error'
    );
    return;
  }

  // MEAN
  const mean = sumFx / N;

  document.getElementById('meanResult').textContent = fmt(mean);

  document.getElementById('meanWork').textContent =
    `Σfx ÷ N = ${fmt(sumFx)} ÷ ${fmt(N)}`;

  // MEDIAN
  // Median = L + [(N/2 - cf before) / f] × h
  let cumulativeBefore = 0;
  let medianRow = null;
  let beforeMedian = 0;

  for (const r of rows) {
    if (
      r.f > 0 &&
      cumulativeBefore + r.f >= N / 2
    ) {
      medianRow = r;
      beforeMedian = cumulativeBefore;
      break;
    }

    cumulativeBefore += r.f;
  }

  if (medianRow) {
    const L = medianRow.interval.boundaryLow;
    const h = medianRow.interval.width;
    const f = medianRow.f;

    const median =
      L + ((N / 2 - beforeMedian) / f) * h;

    document.getElementById('medianResult').textContent =
      fmt(median);

    document.getElementById('medianWork').textContent =
      `L + [(N/2 − cf before) ÷ f] × h = ${fmt(median)}`;
  }

  // MODE
  // Mode = L + [d1 / (d1 + d2)] × h
  const maxF = Math.max(...rows.map(r => r.f));

  // Use the first class with the highest positive frequency.
  const modeRow = rows.find(
    r => r.f === maxF && r.f > 0
  );

  if (modeRow) {
    const index = rows.indexOf(modeRow);

    const f0 = index > 0
      ? rows[index - 1].f
      : 0;

    const f2 = index < rows.length - 1
      ? rows[index + 1].f
      : 0;

    const d1 = modeRow.f - f0;
    const d2 = modeRow.f - f2;
    const denominator = d1 + d2;

    const L = modeRow.interval.boundaryLow;
    const h = modeRow.interval.width;

    if (denominator !== 0) {
      const mode = L + (d1 / denominator) * h;

      document.getElementById('modeResult').textContent =
        fmt(mode);

      document.getElementById('modeWork').textContent =
        `L + [d₁ ÷ (d₁ + d₂)] × h; modal class ${modeRow.intervalRaw}`;
    } else {
      document.getElementById('modeResult').textContent = 'N/A';

      document.getElementById('modeWork').textContent =
        'The grouped mode formula is undefined for these frequencies.';
    }
  } else {
    document.getElementById('modeResult').textContent = 'N/A';
  }

  solved = true;

  if (!equalWidths) {
    setStatus(
      'Solved. Note: class widths differ, so the standard median and mode formulas may not be appropriate.',
      'error'
    );
  } else {
    setStatus(
      'Solved successfully! All table values and answers are updated.',
      'success'
    );
  }
}

// Set the number of rows.
document.getElementById('applyCountBtn').addEventListener(
  'click',
  () => {
    buildRows(true);
    setStatus(
      `Ready. ${rowCount.value} interval rows are available.`
    );
  }
);

// Keep the displayed count within 1–15.
rowCount.addEventListener('change', () => {
  let count = Number.parseInt(rowCount.value, 10);

  if (!Number.isFinite(count)) count = 5;

  rowCount.value = Math.max(1, Math.min(15, count));
});

// Solve the table.
document.getElementById('solveBtn').addEventListener(
  'click',
  solve
);

// Clear all inputs and restore five empty rows.
document.getElementById('clearBtn').addEventListener(
  'click',
  () => {
    rowCount.value = 5;
    buildRows(false);

    setStatus(
      'Cleared. All input boxes are empty.'
    );
  }
);

// Invalidate previous answers when inputs change.
tableBody.addEventListener('input', event => {
  if (
    event.target.classList.contains('interval') ||
    event.target.classList.contains('frequency')
  ) {
    if (solved) {
      resetResults();

      setStatus(
        'Inputs changed. Press SOLVE TABLE to calculate again.'
      );
    }
  }
});

// Start with five empty rows.
buildRows(false);
setStatus('Ready. Enter your class intervals and frequencies.');
