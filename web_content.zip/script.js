// ===============================
// Medical Terminology Database
// ===============================

let medicalTerms =
    JSON.parse(localStorage.getItem("medicalTerms"));


// که مخکې معلومات نه وي موجود
if (!medicalTerms) {

    medicalTerms = defaultMedicalTerms;

    localStorage.setItem(
        "medicalTerms",
        JSON.stringify(medicalTerms)
    );
}


// Save Database
function saveDatabase() {

    localStorage.setItem(
        "medicalTerms",
        JSON.stringify(medicalTerms)
    );
}


// ===============================
// Search
// ===============================

const searchBox =
    document.getElementById("searchBox");

const results =
    document.getElementById("results");


searchBox.addEventListener("input", function () {

    const searchText =
        searchBox.value.trim().toLowerCase();

    results.innerHTML = "";

    if (searchText === "") {
        return;
    }


    const foundTerms = medicalTerms.filter(function (item) {

        return (

            item.term.toLowerCase()
                .includes(searchText)

            ||

            item.pashto.toLowerCase()
                .includes(searchText)

            ||

            item.pronunciation.toLowerCase()
                .includes(searchText)

            ||

            item.english.toLowerCase()
                .includes(searchText)

            ||

            item.category.toLowerCase()
                .includes(searchText)

        );

    });


    if (foundTerms.length === 0) {

        results.innerHTML = `
            <div class="term-card">
                <h3>هیڅ اصطلاح پیدا نه شوه.</h3>
            </div>
        `;

        return;
    }


    foundTerms.forEach(function (item) {

        results.innerHTML += `

            <div class="term-card">

                <h2>${item.term}</h2>

                <p>
                    <b>تلفظ:</b>
                    ${item.pronunciation}
                </p>

                <p>
                    <b>پښتو معنا:</b>
                    ${item.pashto}
                </p>

                <p>
                    <b>English Definition:</b>
                    ${item.english}
                </p>

                <p>
                    <b>Category:</b>
                    ${item.category}
                </p>

                <p>
                    <b>Word Root:</b>
                    ${item.root}
                </p>

                <p>
                    <b>Suffix:</b>
                    ${item.suffix}
                </p>

                <div class="card-buttons">

                    <button
                        onclick="editTerm(${item.id})"
                        class="edit-button">
                        ✏️ Edit
                    </button>

                    <button
                        onclick="deleteTerm(${item.id})"
                        class="delete-button">
                        🗑️ حذف
                    </button>

                </div>

            </div>
        `;
    });

});


// ===============================
// Side Menu
// ===============================

const menuButton =
    document.getElementById("menuButton");

const sideMenu =
    document.getElementById("sideMenu");

const closeMenu =
    document.getElementById("closeMenu");


menuButton.addEventListener("click", function () {

    sideMenu.classList.add("show");

});


closeMenu.addEventListener("click", function () {

    sideMenu.classList.remove("show");

});


// ===============================
// Add Term Page
// ===============================

const addButton =
    document.getElementById("addButton");

const addPage =
    document.getElementById("addPage");

const closeAdd =
    document.getElementById("closeAdd");


addButton.addEventListener("click", function () {

    sideMenu.classList.remove("show");

    addPage.classList.add("show");

});


closeAdd.addEventListener("click", function () {

    addPage.classList.remove("show");

});


// ===============================
// Save New Term
// ===============================

const saveButton =
    document.getElementById("saveButton");


saveButton.addEventListener("click", function () {

    const term =
        document.getElementById("termInput")
        .value.trim();

    const pronunciation =
        document.getElementById("pronunciationInput")
        .value.trim();

    const pashto =
        document.getElementById("pashtoInput")
        .value.trim();

    const english =
        document.getElementById("englishInput")
        .value.trim();

    const category =
        document.getElementById("categoryInput")
        .value.trim();

    const root =
        document.getElementById("rootInput")
        .value.trim();

    const suffix =
        document.getElementById("suffixInput")
        .value.trim();


    // Required fields
    if (!term || !pashto) {

        alert(
            "مهرباني وکړئ English Term او پښتو معنا ولیکئ."
        );

        return;
    }


    const newTerm = {

        id: Date.now(),

        term: term,

        pronunciation: pronunciation,

        pashto: pashto,

        english: english,

        category: category,

        root: root,

        suffix: suffix

    };


    medicalTerms.push(newTerm);


    saveDatabase();


    alert("اصطلاح په بریالیتوب سره اضافه شوه ✅");


    // Clear form
    document.getElementById("termInput").value = "";

    document.getElementById("pronunciationInput").value = "";

    document.getElementById("pashtoInput").value = "";

    document.getElementById("englishInput").value = "";

    document.getElementById("categoryInput").value = "";

    document.getElementById("rootInput").value = "";

    document.getElementById("suffixInput").value = "";


    addPage.classList.remove("show");

});


// ===============================
// Delete Term
// ===============================

function deleteTerm(id) {

    const confirmDelete =
        confirm("ایا غواړې دا اصطلاح حذف کړې؟");


    if (!confirmDelete) {
        return;
    }


    medicalTerms =
        medicalTerms.filter(function (item) {

            return item.id !== id;

        });


    saveDatabase();


    searchBox.dispatchEvent(
        new Event("input")
    );

}


// ===============================
// Edit Term
// ===============================

function editTerm(id) {

    const item =
        medicalTerms.find(function (term) {

            return term.id === id;

        });


    if (!item) {
        return;
    }


    const newTerm =
        prompt("English Term:", item.term);

    if (newTerm === null) {
        return;
    }


    const newPashto =
        prompt("پښتو معنا:", item.pashto);

    if (newPashto === null) {
        return;
    }


    const newPronunciation =
        prompt(
            "تلفظ:",
            item.pronunciation
        );


    item.term =
        newTerm.trim();

    item.pashto =
        newPashto.trim();

    item.pronunciation =
        newPronunciation.trim();


    saveDatabase();


    alert("اصطلاح تازه شوه ✅");


    searchBox.dispatchEvent(
        new Event("input")
    );

}


// ===============================
// Developer Information
// ===============================

const developerButton =
    document.getElementById("developerButton");

const developerInfo =
    document.getElementById("developerInfo");

const closeInfo =
    document.getElementById("closeInfo");


developerButton.addEventListener(
    "click",
    function () {

        sideMenu.classList.remove("show");

        developerInfo.classList.add("show");

    }
);


closeInfo.addEventListener(
    "click",
    function () {

        developerInfo.classList.remove("show");

    }
);