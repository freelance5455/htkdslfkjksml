const boxes = document.querySelectorAll(".box");

const statusText = document.getElementById("status");

const resetBtn = document.getElementById("resetBtn");

const resetScoreBtn =
    document.getElementById("resetScoreBtn");

const scoreX =
    document.getElementById("scoreX");

const scoreO =
    document.getElementById("scoreO");

const scoreDraw =
    document.getElementById("scoreDraw");


/* Game board */

let board = [
    "", "", "",
    "", "", "",
    "", "", ""
];


/* Current player */

let currentPlayer = "X";


/* Game finished or not */

let gameOver = false;


/* Score */

let scores = {

    X: 0,

    O: 0,

    draw: 0

};


/* Winning combinations */

const winningPatterns = [

    [0, 1, 2],

    [3, 4, 5],

    [6, 7, 8],

    [0, 3, 6],

    [1, 4, 7],

    [2, 5, 8],

    [0, 4, 8],

    [2, 4, 6]

];


/* Box click */

boxes.forEach(function(box) {

    box.addEventListener("click", function() {

        const index =
            Number(box.dataset.index);


        /* Agar game finish ho gaya */

        if (gameOver) {

            return;

        }


        /* Agar box already filled hai */

        if (board[index] !== "") {

            return;

        }


        /* Board me player save karo */

        board[index] = currentPlayer;


        /* Screen par X/O dikhao */

        box.textContent = currentPlayer;


        /* CSS class */

        box.classList.add(
            currentPlayer.toLowerCase()
        );


        /* Winner check */

        checkWinner();

    });

});


/* Winner check function */

function checkWinner() {

    for (const pattern of winningPatterns) {

        const a = pattern[0];

        const b = pattern[1];

        const c = pattern[2];


        if (
            board[a] !== "" &&
            board[a] === board[b] &&
            board[b] === board[c]
        ) {

            gameOver = true;


            /* Winning boxes highlight */

            pattern.forEach(function(index) {

                boxes[index]
                    .classList.add("winner");

            });


            /* Score increase */

            scores[currentPlayer]++;


            updateScore();


            statusText.textContent =
                "🎉 Player " +
                currentPlayer +
                " Wins!";


            return;
        }
    }


    /* Draw check */

    if (board.every(function(cell) {

        return cell !== "";

    })) {

        gameOver = true;

        scores.draw++;

        updateScore();

        statusText.textContent =
            "🤝 It's a Draw!";

        return;
    }


    /* Player change */

    if (currentPlayer === "X") {

        currentPlayer = "O";

    } else {

        currentPlayer = "X";

    }


    statusText.textContent =
        "Player " +
        currentPlayer +
        "'s Turn";

}


/* New Game */

function newGame() {

    board = [

        "", "", "",

        "", "", "",

        "", "", ""

    ];


    currentPlayer = "X";

    gameOver = false;


    boxes.forEach(function(box) {

        box.textContent = "";

        box.classList.remove(
            "x",
            "o",
            "winner"
        );

    });


    statusText.textContent =
        "Player X's Turn";

}


/* Update score */

function updateScore() {

    scoreX.textContent =
        scores.X;

    scoreO.textContent =
        scores.O;

    scoreDraw.textContent =
        scores.draw;

}


/* New Game button */

resetBtn.addEventListener(
    "click",
    newGame
);


/* Reset Score button */

resetScoreBtn.addEventListener(
    "click",
    function() {

        scores = {

            X: 0,

            O: 0,

            draw: 0

        };


        updateScore();

        newGame();

    }
);