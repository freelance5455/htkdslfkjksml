/*================================
      كشف حساب أبشواي
      Script Version 2.0
================================*/


// العناصر

const tableBody = document.getElementById("tableBody");

const dateInput = document.getElementById("dateInput");

const themeBtn = document.getElementById("themeBtn");

const newSheetBtn = document.getElementById("newSheetBtn");

const saveImageBtn = document.getElementById("saveImageBtn");


const dialogOverlay = document.getElementById("dialogOverlay");

const cancelBtn = document.getElementById("cancelBtn");

const confirmBtn = document.getElementById("confirmBtn");


const loadingOverlay = document.getElementById("loadingOverlay");





//================================
// إنشاء الصفوف
//================================


function createRows(){

    tableBody.innerHTML="";


    for(let i=1;i<=100;i++){


        const row=document.createElement("tr");


        row.innerHTML=`

        <td>${i}</td>

        <td>
            <input type="text" class="labName">
        </td>

        <td>
            <input type="number">
        </td>

        <td>
            <input type="number">
        </td>

        <td>
            <input type="number">
        </td>

        `;


        tableBody.appendChild(row);


    }


}



createRows();





//================================
// حفظ البيانات
//================================


function saveData(){


    const rows=[];


    document.querySelectorAll("#tableBody tr")
    .forEach(row=>{


        const data=[];


        row.querySelectorAll("input")
        .forEach(input=>{

            data.push(input.value);

        });


        rows.push(data);


    });



    localStorage.setItem(
        "accountRows",
        JSON.stringify(rows)
    );


    localStorage.setItem(
        "accountDate",
        dateInput.value
    );


}






// حفظ عند الكتابة

document.addEventListener(
"input",
saveData
);

/*================================
        تحميل البيانات
================================*/


function loadData(){


    const savedRows =
    JSON.parse(
        localStorage.getItem("accountRows")
    );


    const savedDate =
    localStorage.getItem("accountDate");



    if(savedDate){

        dateInput.value=savedDate;

    }



    if(savedRows){


        const rows =
        document.querySelectorAll("#tableBody tr");



        rows.forEach((row,index)=>{


            const inputs =
            row.querySelectorAll("input");



            if(savedRows[index]){


                savedRows[index]
                .forEach((value,i)=>{


                    inputs[i].value=value;


                });


            }


        });


    }


}



loadData();





//================================
// نظام الوضع
// الفاتح هو الافتراضي
//================================



function setTheme(theme){


    if(theme==="dark"){


        document.body.classList.add("dark");


        themeBtn.textContent="☀️";


    }else{


        document.body.classList.remove("dark");


        themeBtn.textContent="🌙";


    }



    localStorage.setItem(
        "theme",
        theme
    );


}




// قراءة الوضع المحفوظ

const savedTheme =
localStorage.getItem("theme");



if(savedTheme==="dark"){


    setTheme("dark");


}else{


    setTheme("light");


}





// زر التبديل


themeBtn.onclick=function(){



    if(
    document.body.classList.contains("dark")
    ){


        setTheme("light");


    }else{


        setTheme("dark");


    }


};

/*================================
        كشف جديد
================================*/


newSheetBtn.onclick=function(){

    dialogOverlay.style.display="flex";

};



cancelBtn.onclick=function(){

    dialogOverlay.style.display="none";

};



confirmBtn.onclick=function(){


    document
    .querySelectorAll("input")
    .forEach(input=>{

        input.value="";

    });



    saveData();


    dialogOverlay.style.display="none";


};





//================================
// حفظ الصورة
//================================



saveImageBtn.onclick=async function(){


    loadingOverlay.style.display="flex";



    // البحث عن آخر صف به بيانات

    const rows =
    [...document.querySelectorAll("#tableBody tr")];



    let lastRow=-1;



    rows.forEach((row,index)=>{


        const inputs =
        row.querySelectorAll("input");



        const filled =
        [...inputs].some(
            input=>input.value.trim()!=""
        );



        if(filled){

            lastRow=index;

        }


    });




    // إخفاء الصفوف الفارغة

    const hiddenRows=[];



    rows.forEach((row,index)=>{


        if(index>lastRow){


            row.style.display="none";


            hiddenRows.push(row);


        }


    });





    // إخفاء الأزرار أثناء التصوير

    const actions =
    document.querySelector(".actions");


    const header =
    document.querySelector(".header");



    actions.style.display="none";

    themeBtn.style.display="none";




    try{


        const canvas =
        await html2canvas(
            document.getElementById("captureArea"),
            {

                scale:2,

                backgroundColor:
                getComputedStyle(
                    document.body
                ).backgroundColor

            }

        );



        canvas.toBlob(function(blob){



            const url =
            URL.createObjectURL(blob);



            const link =
            document.createElement("a");



            link.href=url;



            link.download=
            "كشف حساب أبشواي.png";



            document.body.appendChild(link);



            link.click();



            document.body.removeChild(link);



            URL.revokeObjectURL(url);



        });



    }


    catch(error){


        alert(
        "حدث خطأ أثناء إنشاء الصورة"
        );


        console.log(error);


    }





    // إعادة كل شيء

    hiddenRows.forEach(row=>{


        row.style.display="";


    });



    actions.style.display="flex";


    themeBtn.style.display="block";



    loadingOverlay.style.display="none";



};