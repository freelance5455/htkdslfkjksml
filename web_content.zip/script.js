$("#hideBtn").click(function(){
    $("#content").hide();
});

$("#showBtn").click(function(){
    $("#content").show();
});

$("#toggleBtn").click(function(){
    $("#content").toggle();
});


var total = 0;

function addOrder(food, price) {

    var orderList = document.getElementById("orderList");

    if (orderList.innerHTML == "<p>No order yet.</p>") {
        orderList.innerHTML = "";
    }

    orderList.innerHTML += "<p>" + food + " - RM " + price.toFixed(2) + "</p>";

    total = total + price;

    document.getElementById("total").innerHTML = total.toFixed(2);
}

function confirmOrder() {

    if (total == 0) {
        alert("Please choose your food first.");
    } else {
        alert("Order confirmed! Total: RM " + total.toFixed(2));
    }
}




function validateForm() {

    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var message = document.getElementById("message").value;

    if (name == "") {
        alert("Please enter your name");
        return false;
    }

    if (email == "") {
        alert("Please enter your email");
        return false;
    }

    if (message == "") {
        alert("Please enter your message");
        return false;
    }

    alert("Message submitted successfully!");

    return true;
}