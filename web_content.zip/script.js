const $=s=>document.querySelector(s);
const EM=['🐱','🐶','🐰','🦊','🐼','🦄','🐻','🐸','🐥','🦋'];
const uid=()=>Math.random().toString(36).slice(2,9);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
let S=null;
try{S=JSON.parse(localStorage.getItem('starpals'))}catch(e){}
if(!S){const id=uid();S={kids:[{id,name:'Mia',emoji:'🐰',s:3,h:2,m:0,hist:[]}],kid:id,tab:'home',
tasks:[{id:uid(),n:'Wake up and wash up',e:'🪥'},{id:uid(),n:'Tidy toys',e:'🧸'},{id:uid(),n:'Homework',e:'📚'},{id:uid(),n:'Eat dinner nicely',e:'🍚'}],
bad:[{id:uid(),n:'Hitting or shouting',a:3},{id:uid(),n:'Lying',a:2},{id:uid(),n:'Not listening',a:1}]}}
const R={mode:'time',amt:''};let rem=0,pick=EM[0];
const save=()=>{try{localStorage.setItem('starpals',JSON.stringify(S))}catch(e){}};
const K=()=>S.kids.find(k=>k.id===S.kid)||S.kids[0];
const tot=k=>k.s+5*k.h+10*k.m;
const IC={s:'⭐',h:'❤️',m:'💖'};
const fd=t=>new Date(t).toLocaleString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'});
function dchip(d){const o=['m','h','s'].filter(x=>d[x]).map(x=>`<i class="${d[x]>0?'p':'n'}">${d[x]>0?'+':'−'}${Math.abs(d[x])}${IC[x]}</i>`);return o.length?o.join(''):'<i>0⭐</i>'}
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('on'),2200)}
/* sounds (synthesized, no audio files needed) */
let AC=null;
const SN={
earn:[[660,0,.12],[880,.1,.12],[1320,.2,.28]],
task:[[523,0,.1],[659,.1,.1],[784,.2,.1],[1047,.3,.35]],
zero:[[392,0,.25,'triangle']],
conv:[[784,0,.09,'triangle'],[988,.07,.09,'triangle'],[1175,.14,.09,'triangle'],[1568,.21,.35,'triangle']],
redeem:[[1568,0,.09,'square',.08],[2093,.1,.4,'square',.08],[1047,.1,.4,'sine',.15]],
bad:[[330,0,.2,'sawtooth',.1],[247,.18,.4,'sawtooth',.1]]};
function snd(name){if(S.mute)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();const t=AC.currentTime;
for(const [f,at,dur,type,vol] of SN[name]){const o=AC.createOscillator(),g=AC.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f,t+at);g.gain.setValueAtTime(.0001,t+at);g.gain.exponentialRampToValueAtTime(vol||.2,t+at+.015);g.gain.exponentialRampToValueAtTime(.0001,t+at+dur);o.connect(g);g.connect(AC.destination);o.start(t+at);o.stop(t+at+dur+.05)}}catch(e){}}
function open(h){$('#sh').innerHTML=h;$('#ov').classList.add('on')}
function shut(){$('#ov').classList.remove('on')}
function entry(k,i,t,d,note,ts){k.hist.push({id:uid(),i,t,d,note:note||'',ts:ts||Date.now()});}
function addD(k,d){k.s+=d.s||0;k.h+=d.h||0;k.m+=d.m||0}
function spend(k,n){const d={s:0,h:0,m:0};let r=Math.min(n,tot(k));
const x=Math.min(k.s,r);k.s-=x;d.s-=x;r-=x;
for(const [key,v] of [['h',5],['m',10]]){if(r<=0)break;const c=Math.min(k[key],Math.ceil(r/v));k[key]-=c;d[key]-=c;const u=Math.min(r,c*v);r-=u;const ch=c*v-u;k.s+=ch;d.s+=ch}
return d}
function undo(id){const k=K(),h=k.hist.find(x=>x.id===id);if(!h)return;
k.s=Math.max(0,k.s-(h.d.s||0));k.h=Math.max(0,k.h-(h.d.h||0));k.m=Math.max(0,k.m-(h.d.m||0));
k.hist=k.hist.filter(x=>x.id!==id);render();toast('Entry undone')}
const CV={sh:['s',5,'h'],hm:['h',2,'m'],sm:['s',10,'m']};
function conv(c){const k=K(),[f,n,t]=CV[c];if(k[f]<n)return;k[f]-=n;k[t]+=1;entry(k,'🔄','Converted '+n+IC[f]+' to '+IC[t],{[f]:-n,[t]:1});snd('conv');render();toast('Converted!')}
/* sheets */
function kidSheet(){pick=EM[0];open(`<h2>New child</h2><input id="kn" placeholder="Name" maxlength="20"><div class="emo">${EM.map((e,i)=>`<button class="${i?'':'on'}" onclick="pick='${e}';document.querySelectorAll('.emo button').forEach(b=>b.classList.toggle('on',b.textContent==='${e}'))">${e}</button>`).join('')}</div><button class="btn wide" onclick="kidAdd()">Add child</button>`)}
function kidAdd(){const n=$('#kn').value.trim();if(!n)return toast('Please enter a name');const id=uid();S.kids.push({id,name:n,emoji:pick,s:0,h:0,m:0,hist:[]});S.kid=id;shut();render()}
function taskSheet(id){rem=0;S.tid=id;const t=S.tasks.find(x=>x.id===id);
open(`<h2>${t.e} ${esc(t.n)}</h2><p class="lbl">How many times was ${esc(K().name)} reminded?</p><div class="step"><button onclick="remSet(-1)" aria-label="Less">−</button><b id="rv">0</b><button onclick="remSet(1)" aria-label="More">+</button></div><div class="prev" id="rp">+2 ⭐ all by themselves!</div><button class="btn wide" onclick="taskDo()">Give stars</button>`)}
const rs=()=>rem===0?2:rem===1?1:0;
function remSet(v){rem=Math.max(0,rem+v);$('#rv').textContent=rem;$('#rp').textContent=['+2 ⭐ all by themselves!','+1 ⭐ told once','0 ⭐ told more than once'][Math.min(rem,2)]}
function taskDo(){const k=K(),t=S.tasks.find(x=>x.id===S.tid),n=rs();k.s+=n;entry(k,t.e,t.n,{s:n},rem?'Reminded '+rem+'×':'');snd(n?'task':'zero');shut();render();toast(n?`+${n} ⭐ for ${k.name}!`:'No stars this time')}
function bonusSheet(){open(`<h2>🎁 One-off bonus</h2><input id="bn" placeholder="What for?"><div class="row"><input id="ba" type="number" min="1" value="1" style="flex:1"><select id="bu" style="flex:1"><option value="1">⭐ stars</option><option value="5">❤️ hearts</option><option value="10">💖 mega</option></select></div><button class="btn wide" onclick="bonusDo()">Give bonus</button>`)}
function bonusDo(){const k=K(),a=Math.floor(+$('#ba').value),u=+$('#bu').value,key=u==1?'s':u==5?'h':'m';if(!(a>0))return toast('Enter an amount');k[key]+=a;entry(k,'🎁',$('#bn').value.trim()||'Bonus',{[key]:a});snd('earn');shut();render();toast('Bonus added!')}
function badDo(id){const b=S.bad.find(x=>x.id===id);cut(b.n,b.a)}
function cut(n,a){const k=K(),d=spend(k,a);entry(k,'😿',n,d);snd('bad');shut();render();toast(`−${-d.s-5*-d.h-10*-d.m} ⭐ taken`)}
function badSheet(){open(`<h2>😿 Custom deduction</h2><input id="dn" placeholder="What happened?"><input id="da" type="number" min="1" value="1"><button class="btn wide alt" onclick="cut($('#dn').value.trim()||'Deduction',Math.floor(+$('#da').value)||0)">Take stars</button>`)}
function adjSheet(){const now=new Date(Date.now()-new Date().getTimezoneOffset()*6e4).toISOString().slice(0,16);
open(`<h2>✏️ Add missed stars</h2><p class="lbl">For times the phone wasn’t around.</p><div class="row"><div style="flex:1"><small>⭐ Stars</small><input id="as" type="number" min="0" value="0"></div><div style="flex:1"><small>❤️ Hearts</small><input id="ah" type="number" min="0" value="0"></div><div style="flex:1"><small>💖 Mega</small><input id="am" type="number" min="0" value="0"></div></div><input id="an" placeholder="Note (optional)"><small>When did it happen?</small><input id="ad" type="datetime-local" value="${now}"><button class="btn wide mint" onclick="adjDo()">Add to wallet</button>`)}
function adjDo(){const k=K(),d={s:Math.max(0,+$('#as').value|0),h:Math.max(0,+$('#ah').value|0),m:Math.max(0,+$('#am').value|0)};if(!d.s&&!d.h&&!d.m)return toast('Enter at least one amount');addD(k,d);entry(k,'✏️','Manual adjustment',d,$('#an').value.trim(),new Date($('#ad').value).getTime()||Date.now());snd('earn');shut();render();toast('Wallet updated')}
function rp(){const k=K(),a=Math.floor(+R.amt)||0,e=$('#rprev');if(!e)return;e.textContent=a>tot(k)?`Not enough! ${k.name} has ${tot(k)} ⭐`:!a?'Pick an amount':R.mode==='time'?`🎮 ${a} minutes of screen time`:`💵 ฿${a}`}
function redeem(){const k=K(),a=Math.floor(+R.amt)||0;if(a<1||a>tot(k))return toast(a?'Not enough stars':'Pick an amount');const d=spend(k,a);
entry(k,R.mode==='time'?'🎮':'💵',R.mode==='time'?`Screen time · ${a} min`:`Money · ฿${a}`,d);R.amt='';snd('redeem');render();toast('Redeemed!')}
function addTask(){const n=$('#tn').value.trim();if(!n)return;S.tasks.push({id:uid(),n,e:$('#te').value.trim()||'⭐'});render()}
function addBad(){const n=$('#bn2').value.trim(),a=Math.floor(+$('#ba2').value);if(!n||!(a>0))return;S.bad.push({id:uid(),n,a});render()}
function delK(id){const k=S.kids.find(x=>x.id===id);open(`<h2>Remove ${esc(k.name)}?</h2><p>Their wallet and history will be deleted.</p><button class="btn wide" onclick="S.kids=S.kids.filter(x=>x.id!=='${id}');S.kid=S.kids[0]?.id;shut();render()">Yes, remove</button><button class="btn ghost wide" onclick="shut()">Keep</button>`)}
/* views */
const V={
home(k){const t=tot(k);return `<div class="card hero"><div class="av">${k.emoji}</div><div class="lbl">${esc(k.name)}’s wallet</div><div class="big">${t} <span>⭐ total</span></div><div class="sub">= ${t} min screen time or ฿${t}</div>
<div class="coins"><div class="coin"><span>💖</span><b>${k.m}</b><small>Mega</small></div><div class="coin"><span>❤️</span><b>${k.h}</b><small>Hearts</small></div><div class="coin"><span>⭐</span><b>${k.s}</b><small>Stars</small></div></div></div>
<div class="card"><h3 style="margin-top:0">Turn into hearts</h3><div class="row"><button class="btn sm" ${k.s<5?'disabled':''} onclick="conv('sh')">5⭐ → ❤️</button><button class="btn sm" ${k.h<2?'disabled':''} onclick="conv('hm')">2❤️ → 💖</button><button class="btn sm" ${k.s<10?'disabled':''} onclick="conv('sm')">10⭐ → 💖</button></div></div>
<button class="btn alt wide" onclick="adjSheet()">✏️ Add missed stars</button>`},
log(k){return `<h3>Good things</h3>${S.tasks.length?`<div class="grid">${S.tasks.map(t=>`<button class="tile" onclick="taskSheet('${t.id}')"><span>${t.e}</span>${esc(t.n)}</button>`).join('')}</div>`:'<div class="card c">Add tasks in Setup 🎀</div>'}
<button class="btn mint wide" onclick="bonusSheet()">🎁 One-off bonus</button>
<h3>Oops moments</h3><div class="list">${S.bad.map(b=>`<button class="item" onclick="badDo('${b.id}')"><span>${esc(b.n)}</span><em>−${b.a} ⭐</em></button>`).join('')}</div><button class="btn ghost wide" onclick="badSheet()">Custom deduction</button>`},
redeem(k){return `<h3>Spend ${esc(k.name)}’s stars</h3><div class="seg"><button class="${R.mode==='time'?'on':''}" onclick="R.mode='time';render()">🎮 Screen time</button><button class="${R.mode==='money'?'on':''}" onclick="R.mode='money';render()">💵 Money</button></div>
<div class="card"><p class="lbl">${R.mode==='time'?'1 ⭐ = 1 minute (❤️ = 5 min)':'1 ⭐ = ฿1 (❤️ = ฿5)'}</p><input type="number" inputmode="numeric" min="1" placeholder="Stars to spend" value="${R.amt}" oninput="R.amt=this.value;rp()"><div class="row">${[5,10,15,30].map(n=>`<button class="btn ghost sm" onclick="R.amt=${n};render()">${n}⭐</button>`).join('')}</div><div class="prev" id="rprev"></div><button class="btn wide" onclick="redeem()">Redeem</button><p class="sub" style="text-align:center">Balance: ${tot(k)} ⭐</p></div>`},
hist(k){const l=k.hist.slice().sort((a,b)=>b.ts-a.ts);return `<h3>History</h3><div class="card">${l.length?l.map(h=>`<div class="h"><div class="hi">${h.i}</div><div class="hb"><b>${esc(h.t)}</b><small>${fd(h.ts)}${h.note?' · '+esc(h.note):''}</small></div><div class="hd">${dchip(h.d)}<button class="x" onclick="undo('${h.id}')">Undo</button></div></div>`).join(''):'<p class="c" style="text-align:center">Nothing yet. Time to earn some stars! 🌟</p>'}</div>`},
setup(){return `<h3>Children</h3><div class="card">${S.kids.map(k=>`<div class="edit"><span>${k.emoji} ${esc(k.name)}</span><button class="x" onclick="delK('${k.id}')">Remove</button></div>`).join('')}<button class="btn sm wide" onclick="kidSheet()">＋ Add child</button></div>
<h3>Tasks</h3><div class="card">${S.tasks.map(t=>`<div class="edit"><span>${t.e} ${esc(t.n)}</span><button class="x" onclick="S.tasks=S.tasks.filter(x=>x.id!=='${t.id}');render()">✕</button></div>`).join('')}<div class="row"><input id="te" placeholder="🙂" style="width:64px" maxlength="4"><input id="tn" placeholder="New task" style="flex:1;width:auto"></div><button class="btn sm wide mint" onclick="addTask()">Add task</button></div>
<h3>Oops list</h3><div class="card">${S.bad.map(b=>`<div class="edit"><span>${esc(b.n)} · −${b.a}⭐</span><button class="x" onclick="S.bad=S.bad.filter(x=>x.id!=='${b.id}');render()">✕</button></div>`).join('')}<div class="row"><input id="bn2" placeholder="Behavior" style="flex:1;width:auto"><input id="ba2" type="number" min="1" placeholder="⭐" style="width:76px"></div><button class="btn sm wide alt" onclick="addBad()">Add behavior</button></div>
<h3>Sound</h3><div class="card"><div class="edit"><span>${S.mute?'🔇':'🔊'} Sound effects</span><button class="x" onclick="S.mute=!S.mute;render();snd('earn')">${S.mute?'Off':'On'}</button></div></div>`}};
const TABS=[['home','🏠','Wallet'],['log','✅','Log'],['redeem','🎮','Spend'],['hist','📜','History'],['setup','⚙️','Setup']];
function render(){const k=K();
$('#kids').innerHTML=S.kids.map(x=>`<button class="chip ${x.id===S.kid?'on':''}" onclick="S.kid='${x.id}';render()">${x.emoji} ${esc(x.name)}</button>`).join('')+'<button class="chip add" onclick="kidSheet()" aria-label="Add child">＋</button>';
$('#nav').innerHTML=TABS.map(t=>`<button class="${S.tab===t[0]?'on':''}" onclick="S.tab='${t[0]}';render();scrollTo(0,0)"><span>${t[1]}</span>${t[2]}</button>`).join('');
$('#main').innerHTML=(k||S.tab==='setup')?V[S.tab](k):'<div class="card c"><div class="av">🌈</div><h3>Welcome!</h3><p>Add your first child to start collecting stars.</p><button class="btn wide" onclick="kidSheet()">Add child</button></div>';
if(S.tab==='redeem')rp();save()}
render();
