(function () {
  "use strict";

  /* =====================================================================
   * موتور اتصال
   * ---------------------------------------------------------------------
   * مرورگر نمی‌تواند تونل VPN بسازد. دکمه وسط صفحه از طریق یک «موتور اتصال»
   * کار می‌کند. به‌صورت پیش‌فرض DEMO_MODE روشن است تا ظاهر دکمه (روشن/خاموش)
   * را ببینید؛ در این حالت هیچ ترافیکی از تونل رد نمی‌شود و صفحه این را
   * صریحاً نشان می‌دهد.
   *
   * برای اتصال واقعی، قبل از این اسکریپت یک موتور تعریف کنید:
   *   window.PARSNET_ENGINE = {
   *     async connect(server) { ... },   // server.link, server.host, ...
   *     async disconnect() { ... }
   *   };
   * و DEMO_MODE را false کنید.
   * ===================================================================== */
  const DEMO_MODE = true;

  const demoEngine = {
    connect: () => new Promise((res) => setTimeout(res, 1500)),
    disconnect: () => Promise.resolve()
  };
  const missingEngine = {
    connect: () => Promise.reject(new Error("موتور اتصال هنوز به این نسخه متصل نشده است.")),
    disconnect: () => Promise.resolve()
  };
  const engine = window.PARSNET_ENGINE || (DEMO_MODE ? demoEngine : missingEngine);
  const isDemo = !window.PARSNET_ENGINE && DEMO_MODE;

  /* ---------- State ---------- */
  let me = null;            // { username, role } | null
  let servers = [];         // from /api/state
  let announcement = "";
  let adText = "";
  let selectedId = null;
  let vpnState = "off";     // off | connecting | on | error
  let connectToken = 0;
  let timerId = null;
  let connectedAt = 0;
  let authMode = "login";

  const $ = (id) => document.getElementById(id);
  const faNum = (n) => String(n).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
  const isAdmin = () => !!me && me.role === "admin";

  /* ---------- API ---------- */
  async function api(method, url, body) {
    try {
      const res = await fetch(url, {
        method,
        credentials: "same-origin",
        headers: { "X-PARSNET": "1", "Content-Type": "application/json" },
        body: body === undefined ? undefined : JSON.stringify(body)
      });
      let data = {};
      try { data = await res.json(); } catch (e) {}
      return { ok: res.ok, status: res.status, data };
    } catch (e) {
      console.warn("PARSNET: backend unreachable — is server.js running?");
      return { ok: false, status: 0, data: { error: "ارتباط با سرور برقرار نشد. اینترنت خود را بررسی کنید و دوباره تلاش کنید." } };
    }
  }

  async function loadState() {
    const r = await api("GET", "/api/state");
    if (r.status === 401) { me = null; servers = []; return; }
    if (r.ok) {
      me = r.data.user;
      servers = r.data.servers;
      announcement = r.data.announcement;
      adText = r.data.ad;
    }
  }

  async function init() {
    const r = await api("GET", "/api/me");
    if (r.status === 0) setStatus(r.data.error, true);
    if (r.ok) {
      announcement = r.data.announcement || "";
      adText = r.data.ad || "";
      if (r.data.user) { me = r.data.user; await loadState(); }
    }
    renderMain();
  }

  /* ---------- Status ---------- */
  const idleStatus = "سرورهای منتشرشده توسط مدیریت";
  const demoNote = "حالت نمایشی: ظاهر اتصال را می‌بینید، اما ترافیکی از تونل عبور نمی‌کند.";
  function setStatus(text, warn) {
    const el = $("status");
    el.textContent = text;
    el.classList.toggle("warn", !!warn);
  }

  /* ---------- Power button / VPN state ---------- */
  const activeServers = () => servers.filter((s) => s.enabled);
  const selectedServer = () => activeServers().find((s) => s.id === selectedId);

  function fmtTime(sec) {
    const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
    return faNum([h, m, s].map((n) => String(n).padStart(2, "0")).join(":"));
  }
  function tick() { $("timer").textContent = fmtTime(Math.floor((Date.now() - connectedAt) / 1000)); }

  function paintVpn() {
    const btn = $("powerBtn");
    btn.dataset.state = vpnState;
    btn.setAttribute("aria-pressed", vpnState === "on" ? "true" : "false");
    btn.setAttribute("aria-label",
      vpnState === "on" ? "قطع اتصال" : vpnState === "connecting" ? "لغو اتصال" : "اتصال به سرور");
    document.querySelector(".readout").dataset.state = vpnState;
    $("stateText").textContent =
      { off: "قطع", connecting: "در حال اتصال…", on: "متصل", error: "اتصال برقرار نشد" }[vpnState];
    $("timer").hidden = vpnState !== "on";
    const s = selectedServer();
    $("chosen").textContent = s ? "سرور: " + s.name : "سروری انتخاب نشده";
  }

  async function goOnline() {
    if (!me) { openDialog(); return; }
    const s = selectedServer();
    if (!s) { setStatus("ابتدا یک سرور از فهرست انتخاب کنید.", true); return; }
    const token = ++connectToken;
    vpnState = "connecting";
    setStatus("در حال برقراری اتصال به " + s.name + "…");
    paintVpn();
    try {
      await engine.connect(s);
      if (token !== connectToken) return;
      vpnState = "on";
      connectedAt = Date.now();
      tick();
      clearInterval(timerId);
      timerId = setInterval(tick, 1000);
      setStatus(isDemo ? demoNote : "اتصال برقرار است.");
    } catch (err) {
      if (token !== connectToken) return;
      vpnState = "error";
      setStatus(err && err.message ? err.message : "اتصال برقرار نشد.", true);
    }
    paintVpn();
  }

  async function goOffline(message) {
    connectToken++;
    clearInterval(timerId);
    const wasOn = vpnState === "on";
    vpnState = "off";
    setStatus(message || (wasOn ? "اتصال قطع شد." : idleStatus));
    paintVpn();
    try { await engine.disconnect(); } catch (e) {}
  }

  $("powerBtn").addEventListener("click", () => {
    if (vpnState === "on" || vpnState === "connecting") goOffline();
    else goOnline();
  });

  /* ---------- Main rendering ---------- */
  function renderMain() {
    $("announcement").textContent = announcement || "به پارس‌نت خوش آمدید";
    const ad = $("adText");
    ad.textContent = adText;
    ad.hidden = !adText.trim();

    const list = $("list");
    list.replaceChildren();

    $("serversSection").hidden = !me;
    if (!me) { paintVpn(); return; }

    const active = activeServers();
    $("count").textContent = faNum(active.length) + " سرور فعال";

    if (selectedId && !active.some((s) => s.id === selectedId)) {
      selectedId = null;
      if (vpnState !== "off") goOffline("سرور انتخاب‌شده دیگر در دسترس نیست.");
    }

    if (!active.length) {
      const p = document.createElement("div");
      p.className = "empty";
      p.textContent = "فعلاً سرور فعالی منتشر نشده است.";
      list.appendChild(p);
    }
    active.forEach((s) => {
      const b = document.createElement("button");
      b.type = "button";
      b.className = "server" + (s.id === selectedId ? " selected" : "");
      b.setAttribute("role", "radio");
      b.setAttribute("aria-checked", s.id === selectedId ? "true" : "false");
      b.innerHTML = '<span class="badge"></span><span class="info"><span class="name"></span><span class="meta"></span></span><span class="tick"></span>';
      b.querySelector(".badge").textContent = s.protocol;
      b.querySelector(".name").textContent = s.name;
      b.querySelector(".meta").textContent = s.host + ":" + s.port;
      b.addEventListener("click", () => {
        if (vpnState === "on" || vpnState === "connecting") {
          if (s.id !== selectedId) setStatus("برای تغییر سرور، ابتدا اتصال را قطع کنید.", true);
          return;
        }
        selectedId = s.id;
        if (vpnState === "error") vpnState = "off";
        setStatus(idleStatus);
        renderMain();
      });
      list.appendChild(b);
    });
    paintVpn();
  }

  /* ---------- Dialog ---------- */
  const dlg = $("accountDialog");

  function showView() {
    $("authView").hidden = !!me;
    $("userView").hidden = !(me && !isAdmin());
    $("panelView").hidden = !isAdmin();
    $("dlgTitle").textContent = !me ? "ثبت نام یا ورود کاربری" : isAdmin() ? "پنل مدیریت PARSNET" : "حساب کاربری";
    if (me && !isAdmin()) {
      $("whoUser").replaceChildren("خوش آمدید، ");
      const b = document.createElement("b"); b.textContent = me.displayName || me.username;
      $("whoUser").appendChild(b);
      $("uCur").value = ""; $("uNew").value = ""; $("uMsg").textContent = "";
    }
    if (isAdmin()) {
      $("annInput").value = announcement;
      $("adInput").value = adText;
      $("aName").value = me.username;
      $("aCur").value = ""; $("aNew").value = ""; $("aMsg").textContent = "";
      renderAdminList();
    }
  }
  function openDialog() { showView(); if (!dlg.open) dlg.showModal(); }

  $("adminBtn").addEventListener("click", openDialog);
  dlg.querySelectorAll("[data-close]").forEach((b) => b.addEventListener("click", () => dlg.close()));

  /* --- auth (login / signup) --- */
  document.querySelectorAll("#authView .tabs button").forEach((t) => {
    t.addEventListener("click", () => {
      authMode = t.dataset.mode;
      document.querySelectorAll("#authView .tabs button").forEach((b) => b.setAttribute("aria-selected", b === t ? "true" : "false"));
      const signup = authMode === "signup";
      $("signupFields").hidden = !signup;
      $("authNameLabel").textContent = signup ? "نام کاربری" : "نام کاربری یا ایمیل";
      $("authSubmit").textContent = signup ? "ثبت نام" : "ورود";
      $("authPass").setAttribute("autocomplete", authMode === "signup" ? "new-password" : "current-password");
      $("authError").textContent = "";
    });
  });

  async function submitAuth() {
    const signup = authMode === "signup";
    const payload = signup
      ? { displayName: $("authDisplay").value.trim(), username: $("authName").value.trim(), email: $("authEmail").value.trim(), password: $("authPass").value }
      : { identifier: $("authName").value.trim(), password: $("authPass").value };
    const r = await api("POST", signup ? "/api/signup" : "/api/login", payload);
    if (!r.ok) { $("authError").textContent = r.data.error || "خطا در ارتباط با سرور."; return; }
    $("authName").value = ""; $("authPass").value = ""; $("authDisplay").value = ""; $("authEmail").value = ""; $("authError").textContent = "";
    me = r.data.user;
    await loadState();
    setStatus(idleStatus);
    renderMain();
    if (isAdmin()) showView(); else dlg.close();
  }
  $("authSubmit").addEventListener("click", submitAuth);
  $("authPass").addEventListener("keydown", (e) => { if (e.key === "Enter") submitAuth(); });
  $("authName").addEventListener("keydown", (e) => { if (e.key === "Enter") $("authPass").focus(); });

  async function logout() {
    await api("POST", "/api/logout");
    if (vpnState !== "off") await goOffline();
    me = null; servers = []; selectedId = null;
    setStatus(idleStatus);
    renderMain();
    dlg.close();
  }
  $("uLogout").addEventListener("click", logout);
  $("aLogout").addEventListener("click", logout);

  /* --- account changes (user + admin) --- */
  async function saveAccount(curId, nameId, newId, msgId) {
    const msg = $(msgId);
    const body = { currentPassword: $(curId).value };
    if (nameId && $(nameId).value.trim()) body.username = $(nameId).value.trim();
    if ($(newId).value) body.password = $(newId).value;
    if (!body.currentPassword) { msg.className = "msg-error"; msg.textContent = "رمز فعلی را وارد کنید."; return; }
    const r = await api("PUT", "/api/account", body);
    if (!r.ok) { msg.className = "msg-error"; msg.textContent = r.data.error || "خطا"; return; }
    me = r.data.user;
    $(curId).value = ""; $(newId).value = "";
    msg.className = "msg-error ok"; msg.textContent = "تغییرات ذخیره شد.";
  }
  $("uSave").addEventListener("click", () => saveAccount("uCur", null, "uNew", "uMsg"));
  $("aSave").addEventListener("click", () => saveAccount("aCur", "aName", "aNew", "aMsg"));

  /* --- admin tabs --- */
  document.querySelectorAll("#panelTabs button").forEach((tabBtn) => {
    tabBtn.addEventListener("click", () => {
      const i = tabBtn.dataset.tab;
      document.querySelectorAll("#panelTabs button").forEach((b) => b.setAttribute("aria-selected", b === tabBtn ? "true" : "false"));
      document.querySelectorAll("#panelView [data-pane]").forEach((p) => { p.hidden = p.dataset.pane !== i; });
      if (i === "3") renderUsers();
    });
  });

  /* --- admin: servers --- */
  async function refreshAfterAdminChange() {
    await loadState();
    renderAdminList();
    renderMain();
  }

  function renderAdminList() {
    const box = $("adminList");
    box.replaceChildren();
    servers.forEach((s) => {
      const row = document.createElement("div");
      row.className = "admin-item";
      const cb = document.createElement("input");
      cb.type = "checkbox"; cb.checked = s.enabled;
      cb.setAttribute("aria-label", "فعال بودن " + s.name);
      cb.addEventListener("change", async () => {
        await api("PATCH", "/api/admin/servers/" + s.id, { enabled: cb.checked });
        refreshAfterAdminChange();
      });
      const label = document.createElement("span");
      label.textContent = s.name;
      const del = document.createElement("button");
      del.type = "button"; del.textContent = "حذف";
      del.setAttribute("aria-label", "حذف " + s.name);
      del.addEventListener("click", async () => {
        await api("DELETE", "/api/admin/servers/" + s.id);
        refreshAfterAdminChange();
      });
      row.append(cb, label, del);
      box.appendChild(row);
    });
  }

  $("publishBtn").addEventListener("click", async () => {
    const r = await api("POST", "/api/admin/servers", { link: $("newLink").value, name: $("newName").value });
    if (!r.ok) { setStatus(r.data.error || "خطا", true); return; }
    $("newName").value = ""; $("newLink").value = "";
    setStatus("سرور منتشر شد و برای همه کاربران نمایش داده می‌شود.");
    refreshAfterAdminChange();
  });

  $("importBtn").addEventListener("click", () => $("fileInput").click());
  $("fileInput").addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const r = await api("POST", "/api/admin/servers/bulk", { text: String(reader.result) });
      setStatus(r.ok ? faNum(r.data.added) + " کانفیگ به فهرست سرورها اضافه شد." : (r.data.error || "خطا"), !r.ok);
      refreshAfterAdminChange();
    };
    reader.readAsText(file);
    e.target.value = "";
  });

  /* --- admin: announcement / ad --- */
  async function saveSettings(payload) {
    const r = await api("PUT", "/api/admin/settings", payload);
    if (!r.ok) { setStatus(r.data.error || "خطا", true); return; }
    if ("announcement" in payload) announcement = payload.announcement;
    if ("ad" in payload) adText = payload.ad;
    setStatus("ذخیره شد.");
    renderMain();
  }
  $("annSave").addEventListener("click", () => saveSettings({ announcement: $("annInput").value }));
  $("adSave").addEventListener("click", () => saveSettings({ ad: $("adInput").value }));

  /* --- admin: users --- */
  async function renderUsers() {
    const box = $("usersList");
    const r = await api("GET", "/api/admin/users");
    box.replaceChildren();
    if (!r.ok) { $("usersCount").textContent = r.data.error || "خطا"; return; }
    const normal = r.data.users.filter((u) => u.role !== "admin");
    $("usersCount").textContent = normal.length
      ? faNum(normal.length) + " کاربر ثبت‌نام کرده است."
      : "هنوز کاربری ثبت نام نکرده است.";
    normal.forEach((u) => {
      const row = document.createElement("div");
      row.className = "admin-item";
      const name = document.createElement("span");
      name.className = "uname"; name.textContent = (u.displayName ? u.displayName + " — " : "") + u.username + (u.email ? " — " + u.email : "");
      const pill = document.createElement("span");
      pill.className = "pill" + (u.disabled ? " off" : "");
      pill.textContent = u.disabled ? "غیرفعال" : "فعال";
      const tog = document.createElement("button");
      tog.type = "button"; tog.className = "toggle";
      tog.textContent = u.disabled ? "فعال‌سازی" : "غیرفعال‌سازی";
      tog.addEventListener("click", async () => {
        await api("PATCH", "/api/admin/users/" + u.id, { disabled: !u.disabled });
        renderUsers();
      });
      const del = document.createElement("button");
      del.type = "button"; del.textContent = "حذف";
      del.setAttribute("aria-label", "حذف " + u.username);
      del.addEventListener("click", async () => {
        if (!confirm("کاربر «" + u.username + "» حذف شود؟")) return;
        await api("DELETE", "/api/admin/users/" + u.id);
        renderUsers();
      });
      row.append(name, pill, tog, del);
      box.appendChild(row);
    });
  }

  init();
})();
