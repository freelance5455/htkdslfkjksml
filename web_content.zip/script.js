// ========================================
// 1. بيانات البداية والبيانات المحفوظة
// ========================================
const seed={currency:'ل.س',id:10,devices:[{id:1,name:'كمبيوتر 1',type:'كمبيوتر',rate:0},{id:2,name:'كمبيوتر 2',type:'كمبيوتر',rate:0},{id:3,name:'بلايستيشن 5',type:'PS5',rate:0},{id:4,name:'بلايستيشن 4',type:'PS4',rate:0}],items:[],history:[]};
let db;
try{db=JSON.parse(localStorage.getItem('game-lounge-demo'))||JSON.parse(JSON.stringify(seed))}catch(e){db=JSON.parse(JSON.stringify(seed))}
// تنظيف الأسعار التجريبية والأصناف الجاهزة مرة واحدة، مع الاحتفاظ ببقية بياناتك.
if(!localStorage.getItem('game-lounge-prices-cleared-v1')){
  (db.devices||[]).forEach(d=>d.rate=0);
  db.items=(db.items||[]).filter(p=>!['ماء','مشروب غازي','قهوة'].includes(p.name));
  db.items.forEach(p=>p.price=0);
  localStorage.setItem('game-lounge-prices-cleared-v1','1');
  localStorage.setItem('game-lounge-demo',JSON.stringify(db));
}
let current='home',target=0,deviceCategoryFilter='الكل';

// ========================================
// 2. الحفظ والأدوات المساعدة
// ========================================
function save(){localStorage.setItem('game-lounge-demo',JSON.stringify(db))}
function cash(n){return Math.round(n||0).toLocaleString('en-US')+' '+db.currency}
function priceText(n){return Number(n)>0?cash(n):'لم يُحدّد السعر بعد'}
function esc(s){return String(s||'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function time(ms){let x=Math.max(0,Math.floor(ms/1000));return [Math.floor(x/3600),Math.floor(x%3600/60),x%60].map(n=>String(n).padStart(2,'0')).join(':')}
function sum(s){return(s?.orders||[]).reduce((a,o)=>a+o.price*o.qty,0)}
function notify(t){let x=document.getElementById('toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2200)}
function page(p,b){current=p;document.querySelectorAll('.nav button').forEach(x=>x.classList.toggle('active',x===b));render()}
function deviceCategory(name){deviceCategoryFilter=name;render()}
function openDeviceCategory(name){current='devices';deviceCategoryFilter=name;document.querySelectorAll('.nav button').forEach((x,i)=>x.classList.toggle('active',i===1));render()}
function categoryMenuHtml(){return `<div class="category-tiles">${deviceGroups.filter(g=>g.key!=='أخرى').map(g=>{const count=db.devices.filter(d=>categoryOf(d)===g.key).length;const icon=g.key==='كمبيوتر'?'🖥️':g.key==='بلايستيشن'?'🎮':g.key==='بلياردو'?'🎱':'⚽';return `<button class="category-tile" onclick="openDeviceCategory('${g.key}')"><span class="category-icon">${icon}</span><span class="category-name">${g.title.replace(/^.*? /,'')}</span><span class="category-total">${count} عنصر</span><span class="category-open">فتح القائمة ←</span></button>`}).join('')}</div>`}
function categoryOf(d){if(d.type==='كمبيوتر')return 'كمبيوتر';if(['PS5','PS4','PS3','بلايستيشن'].includes(d.type))return 'بلايستيشن';if(d.type==='بلياردو')return 'بلياردو';if(d.type==='فيشة')return 'فيشة';return 'أخرى'}
const deviceGroups=[{key:'كمبيوتر',title:'🖥️ أجهزة الكمبيوتر'},{key:'بلايستيشن',title:'🎮 أجهزة البلايستيشن'},{key:'بلياردو',title:'🎱 طاولات البلياردو'},{key:'فيشة',title:'⚽ طاولات الفيشة'},{key:'أخرى',title:'أجهزة أخرى'}];
function deviceGroupHtml(key,title){let list=db.devices.filter(d=>categoryOf(d)===key).sort(deviceSort);return list.length?`<section class="device-group"><h3>${title} <span class="group-count">${list.length}</span></h3><div class="devices">${list.map(card).join('')}</div></section>`:`<section class="device-group"><h3>${title} <span class="group-count">0</span></h3><p class="muted empty-group">لا توجد عناصر في هذا القسم حالياً.</p></section>`}
function deviceSort(a,b){const number=d=>{const m=String(d.name).match(/\d+/);return m?Number(m[0]):Number.MAX_SAFE_INTEGER};return number(a)-number(b)||a.name.localeCompare(b.name,'ar')}
// ========================================
// 3. عرض الصفحات ومحتوى البرنامج
// ========================================
function render(){
  const c=document.getElementById('content');
  if(current==='home'||current==='devices'){
    const busy=db.devices.filter(d=>d.s&&!d.s.end).length;
    c.innerHTML=`${current==='home'?`<h2>أهلاً بك 👋</h2>
      <p class="muted">ملخص الصالة وحالة الأجهزة والطاولات.</p>
      <div class="stats">
        <div class="stat"><small>إجمالي الأجهزة والطاولات</small><strong>${db.devices.length}</strong></div>
        <div class="stat"><small>المشغولة</small><strong style="color:#ff637c">${busy}</strong></div>
        <div class="stat"><small>المتاحة</small><strong style="color:#38d49d">${db.devices.length-busy}</strong></div>
        <div class="stat"><small>الجلسات المغلقة</small><strong>${db.history.length}</strong></div>
      </div>`:''}
      <div class="bar"><div><h2>${current==='home'?'الأجهزة والطاولات':'إدارة الأجهزة والطاولات'}</h2><p class="muted">اختر نوع الجهاز أو الطاولة لفتح قائمته الخاصة فقط.</p></div><button class="primary" onclick="deviceForm()">＋ إضافة جهاز أو طاولة</button></div>
      ${current==='home'||deviceCategoryFilter==='الكل'?categoryMenuHtml():`<div class="category-view-head"><button onclick="deviceCategory('الكل')">← رجوع إلى أنواع الأجهزة</button><h3>${deviceGroups.find(g=>g.key===deviceCategoryFilter)?.title||'أجهزة أخرى'}</h3></div>${deviceGroupHtml(deviceCategoryFilter,deviceGroups.find(g=>g.key===deviceCategoryFilter)?.title||'أجهزة أخرى')}`}`;
  }else if(current==='items'){
    c.innerHTML=`<div class="bar"><div><h2>إدارة الطلبات والأسعار</h2><p class="muted">أضف الأصناف وأسعارها مرة واحدة.</p></div><button class="primary" onclick="itemForm()">＋ إضافة صنف</button></div>
    <p class="notice">أضف أسماء الطلبات وأسعارها بنفسك. لن تظهر أسماء أو أسعار جاهزة.</p>
    <div class="items">${db.items.length?db.items.map(p=>`<div class="card item"><div><b>${esc(p.name)}</b><p class="muted">${priceText(p.price)}</p></div><div><button onclick="itemForm(${p.id})">تعديل</button><button class="bad" onclick="delItem(${p.id})">حذف</button></div></div>`).join(''):'<p class="muted">لا توجد طلبات مضافة. اضغط «إضافة صنف» لإضافة أول طلب.</p>'}</div>`;
  }else if(current==='reports'){
    c.innerHTML=`<h2>التقارير</h2><p class="muted">سجل الجلسات المغلقة.</p><div class="card table">${db.history.length?`<table><tr><th>الجهاز أو الطاولة</th><th>الزبون</th><th>أجرة الجلسة</th><th>الطلبات</th><th>الإجمالي</th></tr>${db.history.slice().reverse().map(h=>`<tr><td>${esc(h.device)}</td><td>${esc(h.customer||'—')}</td><td>${cash(h.game)}</td><td>${cash(h.orders)}</td><td>${cash(h.total)}</td></tr>`).join('')}</table>`:'لا توجد جلسات مغلقة بعد.'}</div>`;
  }else{
    c.innerHTML=`<h2>الإعدادات</h2><div class="card"><div class="field"><label>اسم العملة</label><input id="currency" value="${esc(db.currency)}"></div><button class="primary" onclick="saveCurrency()">حفظ</button><button class="bad" onclick="resetDemo()">إعادة ضبط بيانات العرض</button><p class="notice">استخدم النسخة الاحتياطية لحفظ بياناتك خارج المتصفح.</p></div>`;
  }
}
function card(d){let s=d.s,busy=s&&!s.end,done=s&&s.end,ord=sum(s);return `<article class="card device ${busy?'busy':done?'done':''}">
<div class="between">
<div>
<h3>${d.type==='كمبيوتر'?'🖥️':['PS5','PS4','PS3','بلايستيشن'].includes(d.type)?'🎮':d.type==='بلياردو'?'🎱':d.type==='فيشة'?'⚽':'🎯'} ${esc(d.name)}</h3>
<small class="muted">${esc(d.type)} · ${priceText(d.rate)} للساعة</small>
</div>
<span class="pill">${busy?'مشغول':done?'انتهت الجلسة':'متاح'}</span>
</div>${busy?`<div class="mini">
<small class="muted">الوقت المنقضي</small>
<div class="timer" id="timer${d.id}">${time(Date.now()-s.start)}</div>
<small class="muted">المدة المحددة: ${s.minutes?s.minutes+' دقيقة':'مفتوحة'}</small>
</div>
<div class="actions">
<button onclick="orders(${d.id})">🛒 الطلبات (${s.orders.length})</button>
<button class="bad" onclick="stop(${d.id})">إيقاف الوقت</button>
<button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
</div>
<div class="sum">
<span class="muted">مجموع الطلبات</span>
<b class="gold">${cash(ord)}</b>
</div>`:done?`<div class="summary">
<div class="sum">
<span>أجرة الجلسة</span>
<b>${cash(s.game)}</b>
</div>
<div class="sum">
<span>مجموع الطلبات</span>
<b>${cash(s.orderTotal)}</b>
</div>
<div class="sum">
<b>المبلغ الكامل</b>
<b class="gold">${cash(s.total)}</b>
</div>
</div>
<div class="actions">
<button class="good" onclick="finishSession(${d.id})">إنهاء</button>
<button onclick="showOrders(${d.id})">عرض الطلبات</button>
<button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
</div>`:`<div class="mini">
<small class="muted">سعر الساعة</small>
<h3>${priceText(d.rate)}</h3>
</div>
<div class="actions">
<button class="good" onclick="startForm(${d.id})">▶ بدء الوقت</button>
<button onclick="editDevice(${d.id})">تعديل</button>
<button class="bad" onclick="delDevice(${d.id})">حذف الجهاز</button>
</div>`}</article>`}
// ========================================
// 4. النوافذ المنبثقة وإدارة الأجهزة
// ========================================
function modal(h){document.getElementById('modal').innerHTML=h;document.getElementById('bg').classList.add('show')}
function closemodal(){document.getElementById('bg').classList.remove('show')}
function deviceForm(){modal(`<h3>إضافة جهاز أو طاولة</h3>
<div class="field">
<label>اسم الجهاز أو الطاولة</label>
<input id="dn" placeholder="مثلاً: كمبيوتر 3 أو بلياردو 1">
</div>
<div class="field">
<label>النوع</label>
<select id="dt">
<option>كمبيوتر</option>
<option>PS5</option>
<option>PS4</option>
<option>PS3</option>
<option>بلياردو</option>
<option>فيشة</option>
<option>آخر</option>
</select>
</div>
<div class="field">
<label>سعر الساعة</label>
<input id="dr" type="number" min="1" placeholder="أدخل سعر الساعة" value="">
</div>
<button class="primary" onclick="addDevice()">حفظ الجهاز</button> <button onclick="closemodal()">إلغاء</button>`)}
function addDevice(){let n=document.getElementById('dn').value.trim(),raw=document.getElementById('dr').value,r=Number(raw),t=document.getElementById('dt').value;if(!n||raw===''||!Number.isFinite(r)||r<=0)return notify('أدخل اسم الجهاز وسعر الساعة الذي تريده');db.devices.push({id:db.id++,name:n,type:t,rate:r});save();closemodal();render();notify('تمت إضافة العنصر إلى قسمه تلقائياً')}
function editDevice(id){let d=db.devices.find(x=>x.id===id);modal(`<h3>تعديل الجهاز</h3>
<div class="field">
<label>الاسم</label>
<input id="dn" value="${esc(d.name)}">
</div>
<div class="field">
<label>سعر الساعة</label>
<input id="dr" type="number" min="1" placeholder="أدخل سعر الساعة" value="${d.rate>0?d.rate:''}">
</div>
<button class="primary" onclick="saveDevice(${id})">حفظ</button>
<button class="bad" onclick="delDevice(${id})">حذف الجهاز</button>
<button onclick="closemodal()">إلغاء</button>`)}
function delDevice(id){
  const d=db.devices.find(x=>x.id===id);
  if(!d)return;
  if(d.s&&!d.s.end)return notify('لا يمكن حذف جهاز لديه جلسة جارية. أوقف الجلسة أولاً.');
  if(!confirm(`هل تريد حذف «${d.name}» من قائمة الأجهزة؟ سيبقى سجل الجلسات السابقة في التقارير.`))return;
  db.devices=db.devices.filter(x=>x.id!==id);
  save();closemodal();render();notify('تم حذف الجهاز من القائمة');
}
function saveDevice(id){let d=db.devices.find(x=>x.id===id),n=document.getElementById('dn').value.trim(),raw=document.getElementById('dr').value,r=Number(raw);if(!n||raw===''||!Number.isFinite(r)||r<=0)return notify('أدخل اسم الجهاز وسعر الساعة');d.name=n;d.rate=r;save();closemodal();render();notify('تم حفظ التعديل')}
// ========================================
// 5. بدء الجلسات وإيقافها وإنهاؤها
// ========================================
function startForm(id){let d=db.devices.find(x=>x.id===id);if(!d||!(Number(d.rate)>0))return notify('أدخل سعر الساعة أولاً من زر تعديل');modal(`<h3>بدء جلسة</h3>
<div class="field">
<label>اسم الزبون (اختياري)</label>
<input id="customer">
</div>
<div class="field">
<label>المدة بالدقائق (مثلاً 60)</label>
<input id="minutes" type="number" min="1" placeholder="اتركها فارغة لوقت مفتوح">
</div>
<p class="muted">عند انتهاء المدة يتوقف الوقت تلقائياً ويبقى المبلغ الكامل ظاهراً.</p>
<button class="good" onclick="start(${id})">بدء الوقت</button> <button onclick="closemodal()">إلغاء</button>`)}
function start(id){let d=db.devices.find(x=>x.id===id),n=+document.getElementById('minutes').value;if(n<0)return notify('المدة غير صحيحة');d.s={start:Date.now(),customer:document.getElementById('customer').value,minutes:n||null,orders:[],end:null};save();closemodal();render()}
function stop(id){let d=db.devices.find(x=>x.id===id),s=d.s;if(!s||s.end)return;s.end=Date.now();s.game=Math.ceil((s.end-s.start)/3600000*d.rate);s.orderTotal=sum(s);s.total=s.game+s.orderTotal;db.history.push({device:d.name,customer:s.customer,game:s.game,orders:s.orderTotal,total:s.total,end:s.end});save();render();notify('تم إيقاف الوقت، المبلغ الكامل ظاهر على الجهاز')}
function finishSession(id){let d=db.devices.find(x=>x.id===id);if(!d||!d.s||!d.s.end)return;d.s=null;save();render();notify('تم إنهاء الجلسة والجهاز أصبح متاحاً')}
function showOrders(id){let d=db.devices.find(x=>x.id===id),s=d&&d.s;if(!s)return;modal(`<h3>طلبات ${esc(d.name)}</h3>
<div class="summary">${(s.orders||[]).map(o=>`<div class="sum">
<span>${esc(o.name)} × ${o.qty}</span>
<b>${cash(o.price*o.qty)}</b>
</div>`).join('')||'لا توجد طلبات'}<hr>
<div class="sum">
<b>مجموع الطلبات</b>
<b class="gold">${cash(s.orderTotal??sum(s))}</b>
</div>
</div>
<button onclick="close()">إغلاق</button>`)}
// ========================================
// 6. إدارة الأصناف والأسعار
// ========================================
function itemForm(id){let p=id?db.items.find(x=>x.id===id):{name:'',price:''};modal(`<h3>${id?'تعديل صنف':'إضافة صنف'}</h3>
<div class="field">
<label>اسم الطلب</label>
<input id="iname" value="${esc(p.name)}" placeholder="مثلاً: عصير">
</div>
<div class="field">
<label>سعر القطعة</label>
<input id="iprice" type="number" min="1" placeholder="أدخل سعر الصنف" value="${p.price>0?p.price:''}">
</div>
<button class="primary" onclick="saveItem(${id||0})">حفظ الصنف</button> <button onclick="close()">إلغاء</button>`)}
function saveItem(id){let n=document.getElementById('iname').value.trim(),raw=document.getElementById('iprice').value,p=Number(raw);if(!n||raw===''||!Number.isFinite(p)||p<=0)return notify('أدخل اسم الصنف وسعره');if(id){let x=db.items.find(x=>x.id===id);x.name=n;x.price=p}else db.items.push({id:db.id++,name:n,price:p});save();close();render();notify('تم حفظ الصنف والسعر')}
function delItem(id){if(confirm('حذف الصنف؟')){db.items=db.items.filter(x=>x.id!==id);save();render()}}
// ========================================
// 7. تسجيل طلبات الجلسات
// ========================================
function orders(id){let d=db.devices.find(x=>x.id===id);if(!d.s||d.s.end)return notify('ابدأ جلسة مفتوحة لإضافة الطلبات');target=id;modal(`<h3>طلبات ${esc(d.name)}</h3>
<div id="rows">${d.s.orders.map(orderRow).join('')}</div>
<button onclick="addRow()">＋ إضافة صنف</button>
<div class="summary">مجموع الطلبات: <b id="grand">${cash(sum(d.s))}</b>
</div>
<button class="primary" onclick="saveOrders()">حفظ الطلبات</button> <button onclick="closemodal()">إلغاء</button>`);if(!d.s.orders.length)addRow()}
function orderRow(o={}){return `<div class="orderrow">
<select onchange="calc()">
<option value="">اختر الطلب</option>${db.items.map(p=>`<option value="${p.id}" ${o.id===p.id?'selected':''}>${esc(p.name)} · ${priceText(p.price)}</option>`).join('')}</select>
<input type="number" min="1" value="${o.qty||1}" onchange="calc()">
<span>${cash((o.price||0)*(o.qty||1))}</span>
<button class="bad" onclick="this.parentElement.remove();calc()">×</button>
</div>`}
function addRow(){document.getElementById('rows').insertAdjacentHTML('beforeend',orderRow());calc()}
function calc(){let t=0;document.querySelectorAll('.orderrow').forEach(r=>{let p=db.items.find(x=>x.id===+r.querySelector('select').value),q=Math.max(1,+r.querySelector('input').value||1),n=p?p.price*q:0;t+=n;r.querySelector('span').textContent=cash(n)});document.getElementById('grand').textContent=cash(t)}
function saveOrders(){let s=db.devices.find(x=>x.id===target).s,chosen=[...document.querySelectorAll('.orderrow')].map(r=>({r,p:db.items.find(x=>x.id===+r.querySelector('select').value),q:Math.max(1,+r.querySelector('input').value||1)})).filter(x=>x.p);if(chosen.some(x=>!(Number(x.p.price)>0)))return notify('أدخل سعر كل صنف من صفحة إدارة الطلبات أولاً');s.orders=chosen.map(x=>({id:x.p.id,name:x.p.name,price:x.p.price,qty:x.q}));save();closemodal();render();notify('تم حفظ الطلبات')}
// ========================================
// 8. الإعدادات والنسخ الاحتياطي والاستعادة
// ========================================
function saveCurrency(){let x=document.getElementById('currency').value.trim();if(x){db.currency=x;save();render()}}
function resetDemo(){if(confirm('إعادة بيانات البداية؟ ستُحذف الأجهزة والطلبات والجلسات المضافة.')){db=JSON.parse(JSON.stringify(seed));save();render();notify('تمت إعادة بيانات البداية')}}
function backup(){let a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(db)],{type:'application/json'}));a.download='game-lounge-backup.json';a.click()}
function restore(e){let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!x.devices||!x.items)throw 0;db=x;save();render();notify('تمت الاستعادة')}catch(_){notify('ملف غير صالح')}};r.readAsText(e.target.files[0])}
// ========================================
// 9. تحديث عدّاد الوقت تلقائياً
// ========================================
setInterval(()=>{db.devices.forEach(d=>{let s=d.s;if(!s||s.end)return;let ms=Date.now()-s.start,t=document.getElementById('timer'+d.id);if(t)t.textContent=time(ms);if(s.minutes&&ms>=s.minutes*60000)stop(d.id)})},500);render();
