(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const TZ = 'Asia/Kolkata';
  const STORAGE = {key:'raynox_gemini_key',model:'raynox_model',voice:'raynox_voice_replies',save:'raynox_save_history',history:'raynox_chat_history'};
  let messages = [];
  let listening = false;
  let recognition = null;
  let toastTimer;

  function updateClock(){
    const now = new Date();
    $('clock').textContent = new Intl.DateTimeFormat('en-IN',{timeZone:TZ,hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:true}).format(now);
    $('dateLine').textContent = new Intl.DateTimeFormat('en-IN',{timeZone:TZ,weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(now);
  }
  updateClock(); setInterval(updateClock,1000);

  function showToast(message){
    const toast=$('toast'); toast.textContent=message; toast.classList.add('show');
    clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.classList.remove('show'),3000);
  }
  function currentContext(){
    const now=new Date();
    return `Current date and time context (India Standard Time, Asia/Kolkata): ${new Intl.DateTimeFormat('en-IN',{dateStyle:'full',timeStyle:'long',timeZone:TZ}).format(now)}. Use this as the current time reference when relevant. If the user asks about live facts beyond this device clock, be transparent if you cannot verify them.`;
  }
  function escapeText(text){return String(text).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
  function basicFormat(text){
    // Small safe formatter: only converts common Markdown after escaping all HTML.
    let safe=escapeText(text);
    safe=safe.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>');
    return safe.split(/\n{2,}/).map(p=>'<p>'+p.replace(/\n/g,'<br>')+'</p>').join('');
  }
  function renderMessages(){
    const box=$('messages'); box.innerHTML='';
    messages.forEach(m=>{
      const row=document.createElement('div'); row.className='message '+(m.role==='user'?'user':'assistant')+(m.error?' message-error':'');
      const avatar=document.createElement('div'); avatar.className='avatar'; avatar.textContent=m.role==='user'?'Y':'R';
      const bubble=document.createElement('div'); bubble.className='bubble'; bubble.innerHTML=basicFormat(m.text);
      row.append(avatar,bubble); box.appendChild(row);
    });
    $('chatArea').scrollTop=$('chatArea').scrollHeight;
  }
  function addMessage(role,text,opts={}){
    messages.push({role,text,error:!!opts.error});
    if(messages.length>100)messages=messages.slice(-100);
    renderMessages(); saveHistory();
  }
  function saveHistory(){
    if(!$('saveHistory').checked)return;
    try{localStorage.setItem(STORAGE.history,JSON.stringify(messages));}catch(_){/* Storage may be unavailable in private mode. */}
  }
  function loadHistory(){
    if(!$('saveHistory').checked)return;
    try{const saved=JSON.parse(localStorage.getItem(STORAGE.history)||'[]');if(Array.isArray(saved)){messages=saved.filter(m=>m&&['user','assistant'].includes(m.role)&&typeof m.text==='string').slice(-100);}}
    catch(_){messages=[];}
    if(messages.length){$('welcome').classList.add('hidden');$('chatArea').classList.remove('hidden');renderMessages();}
  }
  function setBusy(busy){$('sendBtn').disabled=busy;$('promptInput').disabled=busy;$('sendBtn').textContent=busy?'…':'↑';}
  function showTyping(){
    const row=document.createElement('div');row.className='message assistant';row.id='typingRow';
    const avatar=document.createElement('div');avatar.className='avatar';avatar.textContent='R';
    const bubble=document.createElement('div');bubble.className='bubble';bubble.innerHTML='<div class="typing"><span></span><span></span><span></span></div>';
    row.append(avatar,bubble);$('messages').appendChild(row);$('chatArea').scrollTop=$('chatArea').scrollHeight;
  }
  function removeTyping(){const n=$('typingRow');if(n)n.remove();}
  async function sendMessage(textOverride){
    const text=(textOverride??$('promptInput').value).trim();if(!text)return;
    const key=localStorage.getItem(STORAGE.key)||'';
    $('welcome').classList.add('hidden');$('chatArea').classList.remove('hidden');
    addMessage('user',text);$('promptInput').value='';$('promptInput').style.height='auto';
    if(!key){addMessage('assistant','I’m ready, but Gemini is not connected yet. Open Settings ⚙ and add your Google AI Studio API key to enable real AI replies.',{error:true});showToast('Add your Gemini API key in Settings first.');return;}
    setBusy(true);showTyping();
    try{
      const model=localStorage.getItem(STORAGE.model)||'gemini-2.5-flash';
      const recent=messages.slice(-13,-1).map(m=>({role:m.role==='assistant'?'model':'user',parts:[{text:m.text}]}));
      const contents=[...recent,{role:'user',parts:[{text:`${currentContext()}\n\nUser message: ${text}`}]}];
      const response=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`,{
        method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({contents,generationConfig:{temperature:0.7,maxOutputTokens:2048}})
      });
      const data=await response.json().catch(()=>({}));
      if(!response.ok){const detail=data?.error?.message||`Request failed (${response.status})`;throw new Error(detail);}
      const answer=(data?.candidates?.[0]?.content?.parts||[]).map(p=>p.text||'').join('\n').trim();
      if(!answer)throw new Error('The model returned an empty answer. Try again.');
      removeTyping();addMessage('assistant',answer);
      if($('voiceReplies').checked)speak(answer);
    }catch(err){
      removeTyping();let message=err?.message||'Something went wrong.';
      if(/Failed to fetch|NetworkError/i.test(message))message='Network request failed. Check your internet connection and whether this converter/browser allows API requests.';
      addMessage('assistant',`I couldn’t get a reply: ${message}\n\nCheck your API key and model in Settings, then try again.`,{error:true});
    }finally{setBusy(false);$('promptInput').focus();}
  }
  function openSettings(){
    $('apiKey').value=localStorage.getItem(STORAGE.key)||'';
    $('modelSelect').value=localStorage.getItem(STORAGE.model)||'gemini-2.5-flash';
    $('voiceReplies').checked=localStorage.getItem(STORAGE.voice)==='true';
    $('saveHistory').checked=localStorage.getItem(STORAGE.save)!=='false';
    $('settingsMessage').textContent='';$('settingsOverlay').classList.remove('hidden');
  }
  function closeSettings(){$('settingsOverlay').classList.add('hidden');}
  $('settingsBtn').addEventListener('click',openSettings);$('openSettings').addEventListener('click',openSettings);$('closeSettings').addEventListener('click',closeSettings);
  $('settingsOverlay').addEventListener('click',e=>{if(e.target===$('settingsOverlay'))closeSettings();});
  $('toggleKey').addEventListener('click',()=>{const field=$('apiKey');field.type=field.type==='password'?'text':'password';$('toggleKey').textContent=field.type==='password'?'Show':'Hide';});
  $('saveSettings').addEventListener('click',()=>{
    const key=$('apiKey').value.trim();
    try{
      if(key)localStorage.setItem(STORAGE.key,key);else localStorage.removeItem(STORAGE.key);
      localStorage.setItem(STORAGE.model,$('modelSelect').value);localStorage.setItem(STORAGE.voice,String($('voiceReplies').checked));localStorage.setItem(STORAGE.save,String($('saveHistory').checked));
      if(!$('saveHistory').checked)localStorage.removeItem(STORAGE.history);else saveHistory();
      $('settingsMessage').textContent='Settings saved on this device.';showToast('Settings saved');setTimeout(closeSettings,650);
    }catch(_){$('settingsMessage').textContent='Could not save settings in this browser. Check browser storage permissions.';}
  });
  $('sendBtn').addEventListener('click',()=>sendMessage());
  $('promptInput').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage();}});
  $('promptInput').addEventListener('input',()=>{const t=$('promptInput');t.style.height='auto';t.style.height=Math.min(t.scrollHeight,150)+'px';});
  document.querySelectorAll('[data-prompt]').forEach(btn=>btn.addEventListener('click',()=>sendMessage(btn.dataset.prompt)));
  $('newChat').addEventListener('click',()=>{messages=[];$('messages').innerHTML='';$('chatArea').classList.add('hidden');$('welcome').classList.remove('hidden');if($('saveHistory').checked){try{localStorage.removeItem(STORAGE.history);}catch(_){}}if(window.innerWidth<=760)$('sidebar').classList.remove('open');$('promptInput').focus();});
  $('homeLink').addEventListener('click',()=>{$('welcome').classList.toggle('hidden',messages.length>0);$('chatArea').classList.toggle('hidden',messages.length===0);$('sidebar').classList.remove('open');});
  $('historyLink').addEventListener('click',()=>{if(messages.length){$('welcome').classList.add('hidden');$('chatArea').classList.remove('hidden');renderMessages();}else showToast('No recent messages yet.');$('sidebar').classList.remove('open');});
  $('menuBtn').addEventListener('click',()=>$('sidebar').classList.toggle('open'));
  function speak(text){if(!('speechSynthesis'in window)){showToast('Speech output is not supported by this browser.');return;}window.speechSynthesis.cancel();const utterance=new SpeechSynthesisUtterance(text);utterance.lang='en-IN';window.speechSynthesis.speak(utterance);}
  function stopListening(){if(recognition){try{recognition.stop();}catch(_){}}listening=false;$('voiceBtn').classList.remove('listening');$('voiceBtn').innerHTML='🎙 <span>Voice</span>';}
  $('voiceBtn').addEventListener('click',()=>{
    if(listening){stopListening();return;}
    const SpeechRecognition=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SpeechRecognition){showToast('Voice input needs a browser that supports speech recognition (often Chrome).');return;}
    recognition=new SpeechRecognition();recognition.lang='en-IN';recognition.interimResults=true;recognition.continuous=false;
    recognition.onstart=()=>{listening=true;$('voiceBtn').classList.add('listening');$('voiceBtn').innerHTML='● <span>Listening…</span>';showToast('Listening — speak now');};
    recognition.onresult=e=>{let finalText='';for(let i=e.resultIndex;i<e.results.length;i++)finalText+=e.results[i][0].transcript;if(finalText)$('promptInput').value=finalText;};
    recognition.onerror=e=>showToast(e.error==='not-allowed'?'Microphone permission was denied. Allow it in browser settings.':'Voice input error: '+e.error);
    recognition.onend=()=>{const hadText=$('promptInput').value.trim();stopListening();if(hadText)$('promptInput').focus();};
    try{recognition.start();}catch(_){showToast('Could not start microphone. Try again.');stopListening();}
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeSettings();$('sidebar').classList.remove('open');}});
  loadHistory();
})();
