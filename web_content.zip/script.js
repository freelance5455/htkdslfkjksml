"use strict";
const $ = s => document.querySelector(s);
const panel = $('#panel'), handle = $('#handle'), scrim = $('#scrim');
const wins = {};
let z = 100;

/* ---------- সংরক্ষিত অ্যাপ (offline, localStorage) ---------- */
const getUser = () => { try { return JSON.parse(localStorage.getItem('fs_apps') || '[]'); } catch (e) { return []; } };
const setUser = l => { try { localStorage.setItem('fs_apps', JSON.stringify(l)); } catch (e) {} };

const BUILTIN = [
  {id:'calc',  name:'ক্যালকুলেটর', icon:'🧮', render:calcApp,  w:290, h:420},
  {id:'voice', name:'ভয়েস চেঞ্জার', icon:'🎙️', render:voiceApp, w:300, h:300},
  {id:'note',  name:'নোট',          icon:'📝', render:noteApp,  w:300, h:340},
  {id:'clock', name:'ঘড়ি',          icon:'⏰', render:clockApp, w:260, h:220},
  {id:'web',   name:'ব্রাউজার',     icon:'🌐', render:webApp,   w:340, h:440}
];
const ADD = {id:'add', name:'অ্যাপ যোগ', icon:'＋', render:addApp, w:320, h:420};

function allApps(){
  const u = getUser().map(x => ({id:'u_'+x.id, name:x.name, icon:'🔗', w:340, h:440, render:el => frameApp(el, x.url)}));
  return BUILTIN.concat(u, [ADD]);
}

/* ---------- Sidebar ---------- */
function rebuild(){
  panel.innerHTML = '';
  allApps().forEach(a => {
    const b = document.createElement('button');
    b.className = 'app'; b.dataset.id = a.id;
    const i = document.createElement('i'); i.textContent = a.icon;
    const s = document.createElement('span'); s.textContent = a.name;
    b.append(i, s);
    b.onclick = () => { openApp(a); setPanel(false); };
    panel.appendChild(b);
  });
  mark();
}
function setPanel(on){
  panel.classList.toggle('open', on);
  scrim.classList.toggle('on', on);
  handle.classList.toggle('hide', on);
}
scrim.onpointerdown = () => setPanel(false);

handle.onpointerdown = e => {
  handle.setPointerCapture(e.pointerId);
  const sx = e.clientX, sy = e.clientY, top0 = handle.offsetTop;
  let moved = false, fired = false;
  const mv = ev => {
    if (fired) return;
    const dx = ev.clientX - sx, dy = ev.clientY - sy;
    if (dx < -18) { fired = true; setPanel(true); }
    else if (Math.abs(dy) > 8) {
      moved = true;
      handle.style.top = Math.min(innerHeight - 130, Math.max(10, top0 + dy)) + 'px';
    }
  };
  const up = () => {
    handle.removeEventListener('pointermove', mv);
    handle.removeEventListener('pointerup', up);
    if (!moved && !fired) setPanel(true);
  };
  handle.addEventListener('pointermove', mv);
  handle.addEventListener('pointerup', up);
};

/* ---------- Windows ---------- */
function drag(el, onStart, onMove){
  el.addEventListener('pointerdown', e => {
    if (e.target.closest('button')) return;
    el.setPointerCapture(e.pointerId);
    const sx = e.clientX, sy = e.clientY, st = onStart();
    const mv = ev => onMove(st, ev.clientX - sx, ev.clientY - sy);
    const up = () => { el.removeEventListener('pointermove', mv); el.removeEventListener('pointerup', up); };
    el.addEventListener('pointermove', mv);
    el.addEventListener('pointerup', up);
  });
}

function openApp(a){
  if (wins[a.id]) { const w = wins[a.id]; w.style.display = 'flex'; w.style.zIndex = ++z; mark(); return; }
  const n = Object.keys(wins).length;
  const w = document.createElement('div'); w.className = 'win';
  const ww = Math.min(a.w || 300, innerWidth - 24), hh = Math.min(a.h || 380, innerHeight - 80);
  Object.assign(w.style, {
    width: ww + 'px', height: hh + 'px',
    left: Math.max(8, (innerWidth - ww) / 2 - 20 + n * 18) + 'px',
    top: Math.max(40, (innerHeight - hh) / 3 + n * 18) + 'px',
    zIndex: ++z
  });
  w.innerHTML = '<div class="bar"><b></b><button data-a="min" title="ছোট করুন">–</button><button data-a="max" title="বড় করুন">▢</button><button data-a="x" class="x" title="বন্ধ করুন">✕</button></div><div class="body"></div><div class="rz"></div>';
  w.querySelector('b').textContent = a.icon + ' ' + a.name;
  document.body.appendChild(w); wins[a.id] = w;
  a.render(w.querySelector('.body'));
  w.addEventListener('pointerdown', () => { w.style.zIndex = ++z; });

  let saved = null;
  const bar = w.querySelector('.bar');
  bar.addEventListener('click', e => {
    const t = e.target.closest('button'); if (!t) return;
    if (t.dataset.a === 'x') { w.remove(); delete wins[a.id]; mark(); }
    if (t.dataset.a === 'min') { w.style.display = 'none'; mark(); }
    if (t.dataset.a === 'max') {
      if (w.classList.toggle('max')) {
        saved = {l:w.style.left, t:w.style.top, w:w.style.width, h:w.style.height};
        Object.assign(w.style, {left:0, top:0, width:'100%', height:'100%'});
      } else if (saved) Object.assign(w.style, {left:saved.l, top:saved.t, width:saved.w, height:saved.h});
    }
  });
  drag(bar, () => ({l:w.offsetLeft, t:w.offsetTop}), (s, dx, dy) => {
    if (w.classList.contains('max')) return;
    w.style.left = Math.min(innerWidth - 60, Math.max(-w.offsetWidth + 80, s.l + dx)) + 'px';
    w.style.top = Math.min(innerHeight - 40, Math.max(0, s.t + dy)) + 'px';
  });
  drag(w.querySelector('.rz'), () => ({w:w.offsetWidth, h:w.offsetHeight}), (s, dx, dy) => {
    w.style.width = Math.max(210, s.w + dx) + 'px';
    w.style.height = Math.max(170, s.h + dy) + 'px';
  });
  mark();
}
function mark(){
  document.querySelectorAll('.app').forEach(b => {
    const w = wins[b.dataset.id];
    b.classList.toggle('run', !!w && w.style.display !== 'none');
  });
}
const fixUrl = u => { u = u.trim(); return /^https?:\/\//i.test(u) ? u : 'https://' + u; };

/* ---------- অ্যাপগুলো ---------- */
function calcApp(el){
  const keys = ['C','⌫','%','÷','7','8','9','×','4','5','6','−','1','2','3','+','00','0','.','='];
  el.innerHTML = '<div class="calc"><div class="scr">0</div><div class="keys"></div></div>';
  const scr = el.querySelector('.scr'), kb = el.querySelector('.keys');
  let ex = '';
  keys.forEach(k => {
    const b = document.createElement('button'); b.textContent = k;
    if ('÷×−+%'.includes(k)) b.className = 'op';
    if (k === '=') b.className = 'eq';
    b.onclick = () => {
      if (k === 'C') ex = '';
      else if (k === '⌫') ex = ex.slice(0, -1);
      else if (k === '=') {
        try {
          const s = ex.replace(/×/g,'*').replace(/÷/g,'/').replace(/−/g,'-').replace(/%/g,'/100');
          if (!/^[\d+\-*/.() ]+$/.test(s)) throw 0;
          const r = Function('"use strict";return (' + s + ')')();
          if (!isFinite(r)) throw 0;
          ex = String(+r.toFixed(10));
        } catch (e) { ex = ''; scr.textContent = 'ভুল ইনপুট'; return; }
      } else ex += k;
      scr.textContent = ex || '0';
    };
    kb.appendChild(b);
  });
}

function noteApp(el){
  const t = document.createElement('textarea'); t.className = 'note'; t.placeholder = 'এখানে লিখুন…';
  el.appendChild(t);
  try { t.value = localStorage.getItem('fs_note') || ''; } catch (e) {}
  t.oninput = () => { try { localStorage.setItem('fs_note', t.value); } catch (e) {} };
}

function clockApp(el){
  el.innerHTML = '<div class="clock"><div class="t"></div><div class="d"></div></div>';
  const t = el.querySelector('.t'), d = el.querySelector('.d');
  const tick = () => {
    if (!el.isConnected) { clearInterval(id); return; }
    const n = new Date();
    t.textContent = n.toLocaleTimeString('bn-BD', {hour:'2-digit', minute:'2-digit', second:'2-digit'});
    d.textContent = n.toLocaleDateString('bn-BD', {weekday:'long', day:'numeric', month:'long'});
  };
  const id = setInterval(tick, 1000); tick();
}

function voiceApp(el){
  el.innerHTML = '<div class="vc"><button class="rec">🎙️ রেকর্ড শুরু করুন</button>' +
    '<label>ভয়েস ইফেক্ট<select><option value="1">স্বাভাবিক</option><option value="1.6">চিকন (চিপমাঙ্ক)</option>' +
    '<option value="1.3">হালকা চিকন</option><option value="0.75">ভারী</option><option value="0.55">খুব ভারী</option></select></label>' +
    '<button class="play" disabled>▶ চালান</button><p class="st"></p></div>';
  const rb = el.querySelector('.rec'), pb = el.querySelector('.play'), sel = el.querySelector('select'), st = el.querySelector('.st');
  let rec = null, chunks = [], blob = null;
  rb.onclick = async () => {
    if (rec && rec.state === 'recording') { rec.stop(); return; }
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({audio:true}); }
    catch (e) { st.textContent = 'মাইক্রোফোনের পারমিশন পাওয়া যায়নি'; return; }
    chunks = []; rec = new MediaRecorder(stream);
    rec.ondataavailable = e => chunks.push(e.data);
    rec.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      blob = new Blob(chunks, {type: rec.mimeType});
      pb.disabled = false; rb.textContent = '🎙️ আবার রেকর্ড করুন'; st.textContent = 'রেকর্ড হয়েছে';
    };
    rec.start(); rb.textContent = '⏹ থামান'; st.textContent = 'রেকর্ড হচ্ছে…';
  };
  pb.onclick = () => {
    if (!blob) return;
    const a = new Audio(URL.createObjectURL(blob));
    a.preservesPitch = a.mozPreservesPitch = a.webkitPreservesPitch = false;
    a.playbackRate = parseFloat(sel.value);
    a.play().catch(() => { st.textContent = 'চালানো যায়নি'; });
  };
}

function webApp(el){
  el.innerHTML = '<div class="web"><form><input value="wikipedia.org" inputmode="url" aria-label="ঠিকানা"><button>যান</button></form><iframe></iframe></div>';
  const f = el.querySelector('form'), i = el.querySelector('input'), fr = el.querySelector('iframe');
  const go = () => { if (i.value.trim()) fr.src = fixUrl(i.value); };
  f.onsubmit = e => { e.preventDefault(); go(); };
  go();
}
function frameApp(el, url){
  el.innerHTML = '<div class="frame"><iframe></iframe></div>';
  el.querySelector('iframe').src = url;
}

function addApp(el){
  el.innerHTML = '<div class="add"><form><input class="n" placeholder="অ্যাপের নাম" required maxlength="20">' +
    '<input class="u" placeholder="ওয়েবসাইটের ঠিকানা (যেমন example.com)" inputmode="url" required>' +
    '<button class="go">যোগ করুন</button></form><div class="list"></div></div>';
  const f = el.querySelector('form'), list = el.querySelector('.list');
  const draw = () => {
    list.innerHTML = '';
    const u = getUser();
    if (!u.length) { list.innerHTML = '<div class="empty">এখনো কোনো অ্যাপ যোগ করা হয়নি</div>'; return; }
    u.forEach(x => {
      const r = document.createElement('div'); r.className = 'row';
      const s = document.createElement('span'); s.textContent = x.name;
      const b = document.createElement('button'); b.textContent = '✕'; b.title = 'সরান';
      b.onclick = () => {
        setUser(getUser().filter(y => y.id !== x.id));
        const w = wins['u_' + x.id]; if (w) { w.remove(); delete wins['u_' + x.id]; }
        rebuild(); draw();
      };
      r.append(s, b); list.appendChild(r);
    });
  };
  f.onsubmit = e => {
    e.preventDefault();
    const name = f.querySelector('.n').value.trim(), url = fixUrl(f.querySelector('.u').value);
    if (!name) return;
    const l = getUser(); l.push({id: Date.now().toString(36), name, url}); setUser(l);
    f.reset(); rebuild(); draw();
  };
  draw();
}

rebuild();
