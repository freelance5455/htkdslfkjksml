const roomNumber = document.getElementById('roomNumber');
const roomLabel = document.getElementById('roomLabel');
const roomTarget = document.getElementById('roomTarget');
const backdoorTimer = document.getElementById('backdoorTimer');
const backdoorTimerValue = document.getElementById('backdoorTimerValue');
const objectiveText = document.getElementById('objectiveText');
const doorNumber = document.getElementById('doorNumber');
const roomType = document.getElementById('roomType');
const sceneTitle = document.getElementById('sceneTitle');
const sceneText = document.getElementById('sceneText');
const inventory = document.getElementById('inventory');
const condition = document.getElementById('condition');
const message = document.getElementById('message');
const scene = document.getElementById('scene');
const threatOverlay = document.getElementById('threatOverlay');
const jumpscare = document.getElementById('jumpscare');
const deathVerdict = document.getElementById('deathVerdict');
const deathCause = document.getElementById('deathCause');
const threatCountdown = document.getElementById('threatCountdown');
const searchButton = document.getElementById('searchButton');
const lootDrawersButton = document.getElementById('lootDrawersButton');
const breakStaticTVButton = document.getElementById('breakStaticTVButton');
const useBandageButton = document.getElementById('useBandageButton');
const hideButton = document.getElementById('hideButton');
const crossButton = document.getElementById('crossButton');
const subfloorButton = document.getElementById('subfloorButton');
const stairwellButton = document.getElementById('stairwellButton');
const fireAlarmButton = document.getElementById('fireAlarmButton');
const secondFloorButton = document.getElementById('secondFloorButton');
const atticButton = document.getElementById('atticButton');
const atticDoorVisual = document.getElementById('atticDoorVisual');
const staticTVVisual = document.getElementById('staticTVVisual');
const staticEntityVisual = document.getElementById('staticEntityVisual');
const outdoorDetourButton = document.getElementById('outdoorDetourButton');
const groundskeeperButton = document.getElementById('groundskeeperButton');
const repairAtticButton = document.getElementById('repairAtticButton');
const returnOutdoorButton = document.getElementById('returnOutdoorButton');
const backdoorSwitchButton = document.getElementById('backdoorSwitchButton');
const groundskeeperVisual = document.getElementById('groundskeeperVisual');
const doorButton = document.getElementById('doorButton');
const finalPuzzle = document.getElementById('finalPuzzle');
const firstFloorShop = document.getElementById('firstFloorShop');
const claimCrossButton = document.getElementById('claimCrossButton');
const claimSkeletonKeyButton = document.getElementById('claimSkeletonKeyButton');
const puzzleAnswers = document.querySelectorAll('.puzzle-answer');
const secondFloorPuzzle = document.getElementById('secondFloorPuzzle');
const secondFloorAnswers = document.querySelectorAll('.second-floor-answer');
const secondFloorShop = document.getElementById('secondFloorShop');
const shopCoins = document.getElementById('shopCoins');
const buyBandageButton = document.getElementById('buyBandageButton');
const stairwellTrashGame = document.getElementById('stairwellTrashGame');
const trashProgress = document.getElementById('trashProgress');
const trashItemButtons = document.querySelectorAll('.trash-item');
const gameShell = document.querySelector('.game-shell');
const startMenu = document.getElementById('startMenu');
const startButtons = document.querySelectorAll('.start-option');

let room = 1;
let subfloorLevel = 0;
let secondFloorLevel = 0;
let thirdFloorLevel = 0;
let atticLevel = 0;
let atticRelics = new Set();
let stairwellLevel = 0;
let backdoorLevel = 0;
let backdoorTime = 45;
let backdoorTimerInterval;
const activatedBackdoorSwitches = new Set();
let stairwellTrashCleared = false;
let trashItemsCleared = new Set();
let hasKey = false;
let silverKeyUses = 0;
let onSubfloor = false;
let onBackdoor = false;
let onSecondFloor = false;
let onThirdFloor = false;
let onAttic = false;
let onStairwell = false;
let onOutdoorDetour = false;
let hasGroundskeeperKey = false;
let groundskeeperMet = false;
let atticItemsRepaired = false;
let searched = false;
let drawersLooted = false;
let oldCoins = 0;
let bandages = 0;
let crossUses = 0;
let skeletonKeyUses = 0;
let crossClaimed = false;
let skeletonKeyClaimed = false;
let hammerUses = 0;
let hammerFound = false;
let health = 2;
let threatActive = false;
let reboundThreat = false;
let staticThreat = false;
const staticTVLevels = new Set([7, 17, 27, 37, 47, 57, 67]);
const brokenStaticTVs = new Set();
let gameOver = false;
let finalPuzzleShown = false;
let finalPuzzleSolved = false;
let secondFloorPuzzleShown = false;
let secondFloorPuzzleSolved = false;
let threatTimer;
let jumpscareTimer;

const padRoom = (number) => String(number).padStart(3, '0');
const lockedRooms = new Set([4, 8, 14, 18, 24, 28]);
const isLockedRoom = (number) => lockedRooms.has(number);
let audioContext;
let ambientNodes = [];
let ambientTimer;
let currentAmbient = '';

function stopAmbientMusic() {
  clearInterval(ambientTimer);
  ambientTimer = undefined;
  ambientNodes.forEach((node) => {
    try { node.stop(); } catch {}
  });
  ambientNodes = [];
  currentAmbient = '';
}

function startAmbientMusic(theme) {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return;
  audioContext ||= new AudioContextClass();
  if (audioContext.state === 'suspended') audioContext.resume();
  if (currentAmbient === theme) return;
  stopAmbientMusic();
  currentAmbient = theme;

  const master = audioContext.createGain();
  master.gain.setValueAtTime(0.0001, audioContext.currentTime);
  master.gain.exponentialRampToValueAtTime(0.035, audioContext.currentTime + 1.5);
  master.connect(audioContext.destination);

  const notes = theme === 'subfloor' ? [55, 65.41, 77.78, 65.41] : [110, 130.81, 164.81, 130.81];
  const oscillator = audioContext.createOscillator();
  const voiceGain = audioContext.createGain();
  oscillator.type = theme === 'subfloor' ? 'triangle' : 'sine';
  oscillator.frequency.value = notes[0];
  voiceGain.gain.value = theme === 'subfloor' ? 0.5 : 0.28;
  oscillator.connect(voiceGain);
  voiceGain.connect(master);
  oscillator.start();
  ambientNodes = [oscillator, master];

  let noteIndex = 0;
  ambientTimer = setInterval(() => {
    if (!audioContext || currentAmbient !== theme) return;
    noteIndex = (noteIndex + 1) % notes.length;
    oscillator.frequency.setTargetAtTime(notes[noteIndex], audioContext.currentTime, 0.8);
  }, theme === 'subfloor' ? 1800 : 2400);
}

function playSound(frequency, duration = 0.14, waveform = 'sine', volume = 0.07) {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return;

  audioContext ||= new AudioContextClass();
  if (audioContext.state === 'suspended') audioContext.resume();

  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();
  const now = audioContext.currentTime;
  oscillator.type = waveform;
  oscillator.frequency.setValueAtTime(frequency, now);
  gain.gain.setValueAtTime(volume, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
  oscillator.connect(gain);
  gain.connect(audioContext.destination);
  oscillator.start(now);
  oscillator.stop(now + duration);
}

function setMessage(text) {
  message.textContent = text;
}

function showJumpscare(enemy = 'lurker') {
  clearTimeout(jumpscareTimer);
  jumpscare.dataset.enemy = enemy;
  jumpscare.hidden = false;
  playSound(135, 0.42, 'sawtooth', 0.2);
  setTimeout(() => playSound(62, 0.34, 'square', 0.12), 65);
  jumpscareTimer = setTimeout(() => {
    jumpscare.hidden = true;
  }, 720);
}

function startBackdoorTimer() {
  clearInterval(backdoorTimerInterval);
  backdoorTimerInterval = setInterval(() => {
    if (!onBackdoor || gameOver) {
      clearInterval(backdoorTimerInterval);
      return;
    }

    backdoorTime -= 1;
    backdoorTimerValue.textContent = `${backdoorTime}s`;
    if (backdoorTime <= 0) {
      backdoorTime = 0;
      clearInterval(backdoorTimerInterval);
      endGame(false, 'The Backdoor timer runs out. The darkness catches up with you.');
    }
  }, 1000);
}

function activateBackdoorSwitch() {
  if (!onBackdoor || backdoorLevel === 0 || backdoorLevel % 5 !== 0 || activatedBackdoorSwitches.has(backdoorLevel) || gameOver) return;
  activatedBackdoorSwitches.add(backdoorLevel);
  backdoorTime += 15;
  backdoorTimerValue.textContent = `${backdoorTime}s`;
  playSound(620, 0.18, 'sine', 0.07);
  updateRoom();
  setMessage(`The switch clicks on. You gain 15 seconds (${backdoorTime}s left).`);
}

function updateInventory() {
  const items = [];
  if (hasKey) items.push('Old brass key');
  if (silverKeyUses > 0) items.push(`Silver key ×${silverKeyUses} uses`);
  if (hasGroundskeeperKey) items.push('Groundskeeper’s special key');
  if (crossUses) items.push(`Cross ×${crossUses} uses`);
  if (skeletonKeyUses) items.push(`Skeleton key ×${skeletonKeyUses} uses`);
  if (oldCoins) items.push(`Old coins ×${oldCoins}`);
  if (bandages) items.push(`Bandages ×${bandages}`);
  if (hammerUses) items.push(`Hammer ×${hammerUses} uses`);
  items.push(...atticRelics);
  inventory.textContent = items.length ? items.join(', ') : 'Empty';
}

function updateRoom() {
  const displayedRoom = onOutdoorDetour ? room : onStairwell ? stairwellLevel : onAttic ? atticLevel : onBackdoor ? backdoorLevel : onSubfloor ? subfloorLevel : onThirdFloor ? thirdFloorLevel : onSecondFloor ? secondFloorLevel : room;
  roomNumber.textContent = padRoom(displayedRoom);
  roomLabel.textContent = onOutdoorDetour ? 'GARDEN' : onStairwell ? 'STAIRWELL' : onAttic ? 'ATTIC' : onBackdoor ? 'BACKDOOR' : onSubfloor ? 'SUBFLOOR' : onThirdFloor ? '3RD FLOOR' : onSecondFloor ? '2ND FLOOR' : 'ROOM';
  doorNumber.textContent = padRoom(displayedRoom);
  roomTarget.textContent = onStairwell ? '070' : onAttic ? '050' : onBackdoor ? '033' : onSubfloor ? '050' : onThirdFloor ? '103' : onSecondFloor ? '055' : '030';
  objectiveText.textContent = onStairwell ? 'Climb 70 stair sets' : onAttic ? 'Explore all 50 attic rooms' : onBackdoor ? 'Complete Backdoor 033' : onSubfloor ? 'Reach Hollow Below 050' : onThirdFloor ? 'Reach Office 103' : onSecondFloor ? 'Reach Floor 055' : 'Reach room 030';
  backdoorTimer.hidden = !onBackdoor;
  backdoorTimerValue.textContent = `${backdoorTime}s`;

  if (onOutdoorDetour) {
    roomType.textContent = 'THE GROUNDSKEEPER’S GARDEN';
    sceneTitle.textContent = 'A quiet place outside.';
    sceneText.textContent = hasGroundskeeperKey
      ? 'The groundskeeper waves you back toward Room 030. His special key may open a way to him in the offices.'
      : 'An old groundskeeper waits beside a garden gate, holding a weathered key.';
  } else if (onThirdFloor && thirdFloorLevel === 53 && groundskeeperMet) {
    roomType.textContent = 'A FAMILIAR VISITOR';
    sceneTitle.textContent = 'The groundskeeper is here.';
    sceneText.textContent = atticItemsRepaired
      ? 'He has restored the keepsakes you found in the attic and is ready to fix any more you bring him.'
      : 'He checks his tools, ready to restore any strange keepsakes you bring from the attic.';
  } else if (onStairwell) {
    roomType.textContent = 'THE STAIRWELL';
    sceneTitle.textContent = stairwellLevel === 70 ? 'The top of the stairs.' : `Stairwell ${padRoom(stairwellLevel)}`;
    sceneText.textContent = stairwellLevel === 70
      ? 'The top landing is buried in debris. Clear it before you can get out.'
      : 'The stairwell spirals upward into the dark. Keep climbing.';
  } else if (onAttic) {
    roomType.textContent = atticLevel === 50 ? 'THE ATTIC EXIT' : 'THE ATTIC';
    sceneTitle.textContent = atticLevel === 50 ? 'The hatch is open.' : `Attic ${padRoom(atticLevel)}`;
    sceneText.textContent = atticLevel === 50
      ? 'The hatch leads back to the office corridor.'
      : 'Dust-choked rafters stretch into the dark. Search the drawers for strange keepsakes.';
  } else if (onBackdoor) {
    roomType.textContent = 'THE BACKDOOR';
    sceneTitle.textContent = backdoorLevel === 0 ? 'The backdoor waits.' : `Backdoor ${padRoom(backdoorLevel)}`;
    sceneText.textContent = 'A forgotten passage winds through the building. Reach switches every five rooms for 15 more seconds, and escape before time runs out.';
  } else if (onSubfloor) {
    roomType.textContent = 'THE HOLLOW BELOW';
    sceneTitle.textContent = `Hollow Below ${padRoom(subfloorLevel)}`;
    sceneText.textContent = 'The stairs descend into a colder, darker stretch of the hotel. Something hunts below.';
  } else if (onThirdFloor) {
    roomType.textContent = thirdFloorLevel === 103 ? 'THE OFFICE EXIT' : 'THE THIRD-FLOOR OFFICES';
    sceneTitle.textContent = thirdFloorLevel === 103 ? 'The office doors open.' : `Office ${padRoom(thirdFloorLevel)}`;
    sceneText.textContent = thirdFloorLevel === 103
      ? 'The final office door leads back into the morning light.'
      : 'Rows of abandoned desks and humming fluorescent lights stretch down the office corridor.';
  } else if (onSecondFloor) {
    roomType.textContent = secondFloorLevel === 55
      ? 'THE LAST LOCK'
      : secondFloorLevel === 3 ? 'THE SECOND-FLOOR SHOP' : 'THE SECOND FLOOR';
    sceneTitle.textContent = secondFloorLevel === 55 ? 'The way out is sealed.' : `Second Floor ${padRoom(secondFloorLevel)}`;
    sceneText.textContent = secondFloorLevel === 55
      ? 'A final sequence guards the route upstairs. Work out the pattern to reach the third floor.'
      : secondFloorLevel === 3
        ? 'A shopkeeper has set up beside the corridor. Trade old coins for supplies before moving on.'
        : 'The upper corridor is lined with boarded windows. Keep climbing; something prowls above.';
  } else if (room === 25) {
    roomType.textContent = 'SEALED SUBFLOOR ENTRANCE';
    sceneTitle.textContent = 'Something lies below.';
    sceneText.textContent = silverKeyUses > 0
      ? `Your silver key has ${silverKeyUses} use${silverKeyUses === 1 ? '' : 's'} left and fits the hidden lock.`
      : 'A hidden stairwell is sealed with a silver lock. Find its key to enter.';
  } else {
    roomType.textContent = room === 1 ? 'A QUIET ROOM' : (isLockedRoom(room + 1) ? 'SOMETHING IS LOCKED' : 'THE HOTEL HALLWAY');
    sceneTitle.textContent = room === 1 ? 'The hallway waits.' : `Room ${padRoom(room)}`;
    sceneText.textContent = room === 10
      ? 'Search carefully. Something silver may be hidden here.'
      : isLockedRoom(room + 1)
        ? 'The next door has a heavy lock. Search this room for a key.'
        : 'The air is still. Your next door is just ahead.';
  }

  searchButton.hidden = onOutdoorDetour;
  lootDrawersButton.hidden = onOutdoorDetour;
  searchButton.disabled = searched || threatActive || gameOver;
  lootDrawersButton.disabled = drawersLooted || threatActive || gameOver;
  useBandageButton.hidden = onOutdoorDetour || bandages === 0 || health >= 2 || gameOver;
  useBandageButton.disabled = threatActive || gameOver;
  const stairwellLandingBlocked = onStairwell && stairwellLevel > 0 && stairwellLevel % 10 === 0 && !stairwellTrashCleared;
  doorButton.disabled = threatActive || gameOver || stairwellLandingBlocked;
  doorButton.hidden = onOutdoorDetour || (!onAttic && !onStairwell && !onBackdoor && !onSubfloor && !onSecondFloor && !onThirdFloor && room === 30 && finalPuzzleSolved);
  doorButton.innerHTML = onAttic
    ? (atticLevel >= 50 ? 'Return to Office 052 <span>→</span>' : 'Open attic door <span>→</span>')
    : onThirdFloor
    ? (thirdFloorLevel >= 103 ? 'Leave the office floor <span>→</span>' : 'Open office door <span>→</span>')
    : onStairwell
    ? (stairwellLandingBlocked ? 'Clear trash to continue' : stairwellLevel === 70 ? 'Reach the top <span>↑</span>' : 'Climb stairs <span>↑</span>')
    : !onBackdoor && !onSubfloor && !onSecondFloor && room === 30
    ? (finalPuzzleSolved ? 'Open final door <span>→</span>' : 'Inspect final lock <span>→</span>')
    : onSecondFloor && secondFloorLevel === 55
      ? (secondFloorPuzzleSolved ? 'Enter the third floor <span>↑</span>' : 'Inspect final lock <span>→</span>')
      : !onBackdoor && !onSubfloor && !onSecondFloor && !onThirdFloor && isLockedRoom(room + 1) ? 'Unlock next door <span>→</span>' : 'Open door <span>→</span>';
  atticButton.hidden = !onThirdFloor || thirdFloorLevel !== 52 || threatActive || gameOver;
  atticDoorVisual.hidden = !onThirdFloor || thirdFloorLevel !== 52;
  outdoorDetourButton.hidden = onOutdoorDetour || room !== 30 || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || onAttic || onStairwell || gameOver;
  groundskeeperButton.hidden = !onOutdoorDetour || hasGroundskeeperKey || gameOver;
  repairAtticButton.hidden = !onThirdFloor || thirdFloorLevel !== 53 || !hasGroundskeeperKey || groundskeeperMet || threatActive || gameOver;
  returnOutdoorButton.hidden = !onOutdoorDetour || gameOver;
  backdoorSwitchButton.hidden = !onBackdoor || backdoorLevel === 0 || backdoorLevel % 5 !== 0 || gameOver;
  backdoorSwitchButton.disabled = activatedBackdoorSwitches.has(backdoorLevel) || threatActive || gameOver;
  groundskeeperVisual.hidden = !onOutdoorDetour && !(onThirdFloor && thirdFloorLevel === 53 && groundskeeperMet);
  const staticTVBroken = brokenStaticTVs.has(stairwellLevel);
  const onStaticTVFloor = onStairwell && staticTVLevels.has(stairwellLevel);
  staticTVVisual.hidden = !onStaticTVFloor || staticTVBroken;
  staticEntityVisual.hidden = !onStaticTVFloor || staticTVBroken || !staticThreat;
  breakStaticTVButton.hidden = !onStaticTVFloor || staticTVBroken || gameOver;
  breakStaticTVButton.disabled = hammerUses < 1 || (threatActive && !staticThreat) || gameOver;
  finalPuzzle.hidden = onOutdoorDetour || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || onAttic || room !== 30 || !finalPuzzleShown || finalPuzzleSolved || gameOver;
  firstFloorShop.hidden = onOutdoorDetour || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || onAttic || onStairwell || room !== 30 || gameOver;
  claimCrossButton.disabled = crossClaimed || gameOver;
  claimSkeletonKeyButton.disabled = skeletonKeyClaimed || gameOver;
  crossButton.hidden = crossUses < 1 || !threatActive || gameOver;
  crossButton.disabled = !threatActive || gameOver;
  crossButton.textContent = `Use cross (${crossUses} use${crossUses === 1 ? '' : 's'})`;
  secondFloorPuzzle.hidden = !onSecondFloor || secondFloorLevel !== 55 || !secondFloorPuzzleShown || secondFloorPuzzleSolved || gameOver;
  secondFloorShop.hidden = !onSecondFloor || secondFloorLevel !== 3 || gameOver;
  stairwellTrashGame.hidden = !onStairwell || stairwellLevel === 0 || stairwellLevel % 10 !== 0 || stairwellTrashCleared || gameOver;
  trashProgress.textContent = `${trashItemsCleared.size} / 3 cleared`;
  trashItemButtons.forEach((button) => {
    button.disabled = trashItemsCleared.has(Number(button.dataset.trash)) || gameOver;
  });
  shopCoins.textContent = `${oldCoins} old coins`;
  buyBandageButton.disabled = oldCoins < 3 || threatActive || gameOver;
  subfloorButton.hidden = room !== 25 || (silverKeyUses === 0 && skeletonKeyUses === 0) || onSubfloor || onSecondFloor || onThirdFloor || onAttic || onStairwell || gameOver;
  stairwellButton.hidden = !onSecondFloor || secondFloorLevel !== 30 || (silverKeyUses === 0 && skeletonKeyUses === 0) || threatActive || onStairwell || gameOver;
  stairwellButton.disabled = threatActive || gameOver;
  fireAlarmButton.hidden = !onStairwell || stairwellLevel !== 70 || !stairwellTrashCleared || gameOver;
  secondFloorButton.hidden = room !== 30 || !finalPuzzleSolved || onOutdoorDetour || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || onAttic || onStairwell || gameOver;
  secondFloorButton.disabled = threatActive || gameOver;
}

function startThreat(countdownSeconds = 5, enemy = 'lurker') {
  playSound(95, 0.65, 'sawtooth', 0.12);
  threatActive = true;
  reboundThreat = false;
  staticThreat = enemy === 'static';
  staticEntityVisual.hidden = !staticThreat;
  let seconds = countdownSeconds;
  threatOverlay.hidden = false;
  scene.classList.add('danger');
  hideButton.hidden = false;
  updateRoom();
  searchButton.disabled = true;
  doorButton.disabled = true;
  secondFloorButton.disabled = true;
  threatCountdown.textContent = staticThreat ? `STATIC ENTITY IN ${seconds}` : `IT ARRIVES IN ${seconds}`;
  setMessage(staticThreat
    ? 'The television spits out a figure made of static. Break the TV with a hammer or hide before it reaches you!'
    : 'You hear something rushing through the hall. Hide now!');

  threatTimer = setInterval(() => {
    seconds -= 1;
    threatCountdown.textContent = staticThreat
      ? (seconds > 0 ? `STATIC ENTITY IN ${seconds}` : 'THE STATIC ENTITY IS HERE')
      : (seconds > 0 ? `IT ARRIVES IN ${seconds}` : 'IT IS HERE');
    if (seconds <= 0) {
      clearInterval(threatTimer);
      health = 0;
      showJumpscare(enemy);
      condition.textContent = 'Dead';
      threatActive = false;
      staticThreat = false;
      threatOverlay.hidden = true;
      hideButton.hidden = true;
      scene.classList.remove('danger');
      const cause = enemy === 'static' ? 'The static entity' : 'The lurking enemy';
      endGame(false, `${cause} caught you in the open.`, cause);
    }
  }, 1000);
}

function playReboundSound() {
  const AudioContextClass = window.AudioContext || window.webkitAudioContext;
  if (!AudioContextClass) return;

  audioContext ||= new AudioContextClass();
  if (audioContext.state === 'suspended') audioContext.resume();
  const oscillator = audioContext.createOscillator();
  const gain = audioContext.createGain();
  const now = audioContext.currentTime;
  oscillator.type = 'triangle';
  oscillator.frequency.setValueAtTime(420, now);
  oscillator.frequency.exponentialRampToValueAtTime(85, now + 0.45);
  gain.gain.setValueAtTime(0.11, now);
  gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);
  oscillator.connect(gain);
  gain.connect(audioContext.destination);
  oscillator.start(now);
  oscillator.stop(now + 0.5);
}

function startReboundThreat() {
  threatActive = true;
  reboundThreat = true;
  let reboundsRemaining = 2;
  threatOverlay.hidden = false;
  scene.classList.add('danger');
  hideButton.hidden = false;
  updateRoom();
  searchButton.disabled = true;
  doorButton.disabled = true;
  secondFloorButton.disabled = true;
  threatCountdown.textContent = 'THE REBOUNDER APPROACHES';
  setMessage('A shape rushes past, then rebounds down the corridor twice. Hide until it is gone!');
  playReboundSound();

  threatTimer = setInterval(() => {
    if (reboundsRemaining > 0) {
      threatCountdown.textContent = `IT REBOUNDS ${reboundsRemaining === 2 ? 'ONCE' : 'TWICE'}`;
      playReboundSound();
      reboundsRemaining -= 1;
      return;
    }

    clearInterval(threatTimer);
    health = 0;
    showJumpscare('rebounder');
    condition.textContent = 'Dead';
    threatActive = false;
    reboundThreat = false;
    threatOverlay.hidden = true;
    hideButton.hidden = true;
    scene.classList.remove('danger');
    endGame(false, 'The Rebounder catches you in the corridor.', 'The Rebounder');
  }, 1800);
}

function hideFromThreat() {
  if (!threatActive || gameOver) return;
  const hidFromRebounder = reboundThreat;
  const hidFromStatic = staticThreat;
  playSound(520, 0.22, 'triangle', 0.08);
  clearInterval(threatTimer);
  threatActive = false;
  reboundThreat = false;
  staticThreat = false;
  threatOverlay.hidden = true;
  hideButton.hidden = true;
  scene.classList.remove('danger');
  sceneText.textContent = hidFromRebounder
    ? 'You hold your breath in the closet until the rush and both rebounds pass.'
    : hidFromStatic
      ? 'You stay hidden until the static figure flickers back into the television.'
      : 'You hold your breath in the closet as footsteps pass.';
  setMessage(hidFromRebounder
    ? 'You stayed hidden through all three passes. The Rebounder fades away.'
    : hidFromStatic
      ? 'You hide until the static entity retreats into the television.'
      : 'You stayed hidden. The footsteps fade away.');
  updateRoom();
}

function breakStaticTV() {
  if (!onStairwell || !staticTVLevels.has(stairwellLevel) || brokenStaticTVs.has(stairwellLevel) || hammerUses < 1 || gameOver) return;

  hammerUses -= 1;
  brokenStaticTVs.add(stairwellLevel);
  if (threatActive && staticThreat) {
    clearInterval(threatTimer);
    threatActive = false;
    staticThreat = false;
    threatOverlay.hidden = true;
    hideButton.hidden = true;
    scene.classList.remove('danger');
  }
  playSound(110, 0.24, 'square', 0.1);
  updateInventory();
  updateRoom();
  setMessage(hammerUses > 0
    ? `You smash the television. The static entity vanishes, and the hammer has ${hammerUses} use${hammerUses === 1 ? '' : 's'} left.`
    : 'You smash the television. The static entity vanishes, but the hammer breaks.');
}

function searchRoom() {
  if (searched || threatActive || gameOver) return;
  playSound(320, 0.12, 'triangle', 0.045);
  searched = true;
  searchButton.disabled = true;

  if (!onBackdoor && !onSubfloor && !onSecondFloor && !onThirdFloor && isLockedRoom(room + 1) && !hasKey) {
    hasKey = true;
    playSound(660, 0.18, 'sine', 0.08);
    updateInventory();
    setMessage('You found an old brass key. It should fit the next door.');
  } else if (!onBackdoor && !onSubfloor && !onSecondFloor && !onThirdFloor && room === 10) {
    if (Math.random() < 0.49) {
      silverKeyUses = 2;
      playSound(880, 0.22, 'sine', 0.08);
      updateInventory();
      setMessage('You found a silver key with two uses. It can unlock the subfloor and the stairwell.');
      updateRoom();
    } else {
      setMessage('You search every corner, but find no silver key this time.');
    }
  } else {
    const finds = [
      'Dusty drawers, a cold fireplace, and nothing useful.',
      'You find a few coins, but leave them behind. Better keep moving.',
      'A closet stands open. It might keep you safe if you hear a rush of wind.',
      'Nothing here but the smell of old wood and rain.'
    ];
    setMessage(finds[Math.floor(Math.random() * finds.length)]);
  }
}

function lootDrawers() {
  if (drawersLooted || threatActive || gameOver) return;
  drawersLooted = true;
  playSound(260, 0.18, 'triangle', 0.05);

  const specialAtticItems = atticItemsRepaired
    ? ['Restored attic lantern', 'Restored music box', 'Polished moonstone pendant']
    : ['Attic lantern', 'Cracked music box', 'Moonstone pendant'];
  const unclaimedAtticItems = specialAtticItems.filter((item) => !atticRelics.has(item));
  if (onAttic && unclaimedAtticItems.length) {
    const item = unclaimedAtticItems[Math.floor(Math.random() * unclaimedAtticItems.length)];
    atticRelics.add(item);
    playSound(820, 0.22, 'sine', 0.08);
    updateInventory();
    setMessage(`Among the dust, you find a strange keepsake: ${item}.`);
  } else if (onStairwell && (!hammerFound || (hammerUses === 0 && Math.random() < 0.25))) {
    hammerFound = true;
    hammerUses = 3;
    playSound(520, 0.18, 'triangle', 0.08);
    updateInventory();
    setMessage('Behind the drawer you find a sturdy hammer. It can smash three televisions.');
  } else if (Math.random() < 0.25) {
    bandages += 1;
    playSound(740, 0.2, 'sine', 0.07);
    updateInventory();
    setMessage('You rummage through the drawers and find a bandage. Use it when you are hurt.');
  } else {
    const coinsFound = Math.floor(Math.random() * 4) + 1;
    oldCoins += coinsFound;
    playSound(620, 0.16, 'sine', 0.06);
    updateInventory();
    setMessage(`You loot the drawers and find ${coinsFound} old ${coinsFound === 1 ? 'coin' : 'coins'}.`);
  }

  updateRoom();
}

function claimShopCross() {
  if (room !== 30 || crossClaimed || gameOver) return;
  crossClaimed = true;
  crossUses = 2;
  updateInventory();
  updateRoom();
  setMessage('You take the cross. Its two charges can banish entities when they appear.');
}

function claimShopSkeletonKey() {
  if (room !== 30 || skeletonKeyClaimed || gameOver) return;
  skeletonKeyClaimed = true;
  skeletonKeyUses = 6;
  updateInventory();
  updateRoom();
  setMessage('You take the skeleton key. It can open six locked doors, including puzzle locks.');
}

function useCross() {
  if (!threatActive || crossUses < 1 || gameOver) return;
  const enemy = staticThreat ? 'static entity' : reboundThreat ? 'the Rebounder' : 'the lurking entity';
  clearInterval(threatTimer);
  threatActive = false;
  reboundThreat = false;
  staticThreat = false;
  crossUses -= 1;
  threatOverlay.hidden = true;
  hideButton.hidden = true;
  scene.classList.remove('danger');
  staticEntityVisual.hidden = true;
  playSound(880, 0.28, 'sine', 0.1);
  updateInventory();
  updateRoom();
  setMessage(`The cross flashes and destroys ${enemy}. ${crossUses} cross use${crossUses === 1 ? '' : 's'} remaining.`);
}

function useBandage() {
  if (bandages < 1 || health >= 2 || threatActive || gameOver) return;
  bandages -= 1;
  health += 1;
  condition.textContent = health === 2 ? 'Unhurt' : 'Hurt';
  playSound(520, 0.16, 'triangle', 0.06);
  updateInventory();
  updateRoom();
  setMessage('You use a bandage and recover one point of health.');
}

function buyBandage() {
  if (!onSecondFloor || secondFloorLevel !== 3 || oldCoins < 3 || threatActive || gameOver) return;
  oldCoins -= 3;
  bandages += 1;
  playSound(660, 0.18, 'sine', 0.07);
  updateInventory();
  updateRoom();
  setMessage('You buy a bandage for 3 old coins.');
}

function visitGroundskeeperGarden() {
  if (room !== 30 || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || onAttic || onStairwell || gameOver) return;
  onOutdoorDetour = true;
  scene.classList.add('outdoor');
  updateRoom();
  setMessage('You step through the garden gate and find the groundskeeper. Speak with him, then return to Room 030.');
}

function speakWithGroundskeeper() {
  if (!onOutdoorDetour || hasGroundskeeperKey || gameOver) return;
  hasGroundskeeperKey = true;
  playSound(620, 0.2, 'sine', 0.07);
  updateInventory();
  updateRoom();
  setMessage('The groundskeeper gives you his special key. He says to find him at Office 053 if you need attic keepsakes repaired.');
}

function returnFromGarden() {
  if (!onOutdoorDetour || gameOver) return;
  onOutdoorDetour = false;
  scene.classList.remove('outdoor');
  updateRoom();
  setMessage('You return to Room 030 with the hallway exactly as you left it.');
}

function repairAtticKeepsakes() {
  if (!onThirdFloor || thirdFloorLevel !== 53 || !hasGroundskeeperKey || groundskeeperMet || gameOver) return;
  hasGroundskeeperKey = false;
  groundskeeperMet = true;
  atticItemsRepaired = true;
  const repairedNames = {
    'Attic lantern': 'Restored attic lantern',
    'Cracked music box': 'Restored music box',
    'Moonstone pendant': 'Polished moonstone pendant'
  };
  atticRelics = new Set([...atticRelics].map((item) => repairedNames[item] || item));
  playSound(740, 0.2, 'sine', 0.07);
  updateInventory();
  updateRoom();
  setMessage(atticRelics.size
    ? 'The groundskeeper appears and restores your attic keepsakes. Any more you find will be repaired too.'
    : 'The groundskeeper appears and offers to restore your attic keepsakes. Any you find from now on will be repaired.');
}

function unlockSubfloor() {
  if (room !== 25 || (silverKeyUses === 0 && skeletonKeyUses === 0) || onSubfloor || gameOver) return;
  playSound(180, 0.18, 'triangle', 0.08);
  setTimeout(() => playSound(420, 0.3, 'sine', 0.08), 160);
  if (silverKeyUses > 0) silverKeyUses -= 1;
  else skeletonKeyUses -= 1;
  subfloorLevel = 0;
  searched = false;
  drawersLooted = false;
  onSubfloor = true;
  startAmbientMusic('subfloor');
  updateInventory();
  scene.classList.add('subfloor');
  updateRoom();
  setMessage('The key turns. The hidden stairs open, leading down to the subfloor.');
}

function enterStairwell() {
  if (!onSecondFloor || secondFloorLevel !== 30 || (silverKeyUses === 0 && skeletonKeyUses === 0) || threatActive || gameOver) return;
  if (silverKeyUses > 0) silverKeyUses -= 1;
  else skeletonKeyUses -= 1;
  stairwellLevel = 0;
  stairwellTrashCleared = false;
  trashItemsCleared = new Set();
  searched = false;
  drawersLooted = false;
  onSecondFloor = false;
  onStairwell = true;
  startAmbientMusic('subfloor');
  updateInventory();
  scene.classList.remove('second-floor');
  scene.classList.add('stairwell');
  updateRoom();
  setMessage('The key unlocks a narrow stairwell. Climb all 70 sets of stairs to reach the top.');
}

function pullFireAlarm() {
  if (!onStairwell || stairwellLevel !== 70 || !stairwellTrashCleared || gameOver) return;
  playSound(880, 0.35, 'sawtooth', 0.12);
  scene.classList.add('stairwell-burning');
  endGame(true, 'You pull the alarm. Flames race through the stairwell from the top landing all the way down.');
  roomType.textContent = 'FIRE ALARM PULLED';
  sceneTitle.textContent = 'The stairwell is burning.';
  setMessage('The alarm blares as fire spreads through the entire stairwell.');
}

function enterSecondFloor() {
  if (room !== 30 || !finalPuzzleSolved || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || onAttic || onStairwell || threatActive || gameOver) return;
  playSound(360, 0.22, 'triangle', 0.07);
  secondFloorLevel = 0;
  searched = false;
  drawersLooted = false;
  onSecondFloor = true;
  scene.classList.add('second-floor');
  updateRoom();
  setMessage('You climb to the second floor. Reach floor 055 and solve the lock to continue to the third floor.');
}

function enterThirdFloor() {
  if (!onSecondFloor || secondFloorLevel !== 55 || !secondFloorPuzzleSolved || threatActive || gameOver) return;
  playSound(440, 0.24, 'triangle', 0.07);
  thirdFloorLevel = 1;
  searched = false;
  drawersLooted = false;
  onSecondFloor = false;
  onThirdFloor = true;
  scene.classList.remove('second-floor');
  scene.classList.add('office-floor');
  updateRoom();
  setMessage('The final lock opens onto the third-floor offices. Make your way through all 103 rooms.');
}

function enterAttic() {
  if (!onThirdFloor || thirdFloorLevel !== 52 || threatActive || gameOver) return;
  playSound(170, 0.22, 'triangle', 0.08);
  atticLevel = 1;
  searched = false;
  drawersLooted = false;
  onThirdFloor = false;
  onAttic = true;
  scene.classList.remove('office-floor');
  scene.classList.add('attic');
  updateRoom();
  setMessage('The strange door opens into the attic. Explore all 50 rooms and search the dusty drawers for keepsakes.');
}

function returnToOffice() {
  onAttic = false;
  onThirdFloor = true;
  thirdFloorLevel = 52;
  searched = false;
  drawersLooted = false;
  scene.classList.remove('attic');
  scene.classList.add('office-floor');
  updateRoom();
  setMessage('You climb through the hatch and return to Office 052.');
}

function returnToMainFloor(destinationRoom, text) {
  if (onBackdoor) clearInterval(backdoorTimerInterval);
  stopAmbientMusic();
  onSubfloor = false;
  onBackdoor = false;
  onSecondFloor = false;
  onThirdFloor = false;
  onAttic = false;
  onStairwell = false;
  room = destinationRoom;
  searched = false;
  drawersLooted = false;
  scene.classList.remove('subfloor', 'second-floor', 'stairwell', 'office-floor', 'attic');
  updateRoom();
  setMessage(text);
}

function returnToSecondFloor(destinationLevel, text) {
  stopAmbientMusic();
  onSubfloor = false;
  onBackdoor = false;
  onSecondFloor = true;
  onThirdFloor = false;
  onAttic = false;
  onStairwell = false;
  secondFloorLevel = destinationLevel;
  searched = false;
  drawersLooted = false;
  scene.classList.remove('subfloor', 'stairwell', 'office-floor', 'attic');
  scene.classList.add('second-floor');
  updateRoom();
  setMessage(text);
}

function openDoor() {
  if (threatActive || gameOver) return;
  if (onAttic) {
    if (atticLevel >= 50) {
      returnToOffice();
      return;
    }
    playSound(240, 0.16, 'triangle', 0.06);
    atticLevel += 1;
    searched = false;
    drawersLooted = false;
    updateRoom();
    setMessage(`You move deeper into Attic ${padRoom(atticLevel)}. Keep searching the drawers.`);
    return;
  }
  if (onStairwell && stairwellLevel > 0 && stairwellLevel % 10 === 0 && !stairwellTrashCleared) {
    setMessage('Clear all the trash on this landing before continuing.');
    return;
  }

  if (!onStairwell && !onAttic && !onBackdoor && !onSubfloor && !onSecondFloor && room === 30 && !finalPuzzleSolved && skeletonKeyUses > 0) {
    skeletonKeyUses -= 1;
    finalPuzzleSolved = true;
    updateInventory();
    updateRoom();
    setMessage(`The skeleton key bypasses the final lock. ${skeletonKeyUses} use${skeletonKeyUses === 1 ? '' : 's'} remaining.`);
    return;
  }

  if (!onStairwell && !onAttic && !onBackdoor && !onSubfloor && !onSecondFloor && room === 30 && !finalPuzzleSolved) {
    finalPuzzleShown = true;
    updateRoom();
    setMessage('The final door is sealed. Solve the sequence to unlock it.');
    return;
  }

  if (!onStairwell && !onAttic && !onBackdoor && !onSubfloor && !onSecondFloor && room === 30 && finalPuzzleSolved) {
    enterSecondFloor();
    return;
  }

  if (onStairwell) {
    if (stairwellLevel >= 70) {
      returnToSecondFloor(45, 'You reach the top of the stairwell and return to Second Floor 045.');
      return;
    }
    playSound(300, 0.16, 'triangle', 0.06);
    stairwellLevel += 1;
    searched = false;
    drawersLooted = false;
    if (stairwellLevel % 10 === 0) {
      stairwellTrashCleared = false;
      trashItemsCleared = new Set();
    }
    updateRoom();
    if (stairwellLevel % 10 === 0) {
      setMessage(`You reach landing ${padRoom(stairwellLevel)}. Clear the trash to continue.`);
    } else if (staticTVLevels.has(stairwellLevel)) {
      if (brokenStaticTVs.has(stairwellLevel)) {
        setMessage(`The broken television at stairwell ${padRoom(stairwellLevel)} is silent. Keep climbing.`);
      } else {
        setMessage(`A television crackles at stairwell ${padRoom(stairwellLevel)}. Something is pushing through the static!`);
        startThreat(5, 'static');
      }
    } else {
      setMessage(`You climb to stairwell landing ${padRoom(stairwellLevel)}. Keep going up.`);
    }
    return;
  }

  if (onBackdoor) {
    if (backdoorLevel >= 33) {
      returnToMainFloor(1, 'You complete the Backdoor and arrive at room 001 on the first floor.');
      return;
    }
    playSound(240, 0.16, 'triangle', 0.06);
    backdoorLevel += 1;
    searched = false;
    drawersLooted = false;
    updateRoom();
    if (backdoorLevel === 33) {
      returnToMainFloor(1, 'You complete the Backdoor and arrive at room 001 on the first floor.');
    } else if ([3, 6, 9, 15, 21, 27].includes(backdoorLevel)) {
      setMessage(`A presence stirs in Backdoor ${padRoom(backdoorLevel)}. Hide quickly!`);
      startThreat();
    } else {
      setMessage(`You step into Backdoor ${padRoom(backdoorLevel)}. Keep moving.`);
    }
    return;
  }

  if (onSubfloor) {
    if (subfloorLevel >= 50) {
      returnToMainFloor(30, 'You complete Hollow Below and return to the first floor at door 030.');
      return;
    }
    playSound(240, 0.16, 'triangle', 0.06);
    subfloorLevel += 1;
    searched = false;
    drawersLooted = false;
    updateRoom();
    if (subfloorLevel === 50) {
      returnToMainFloor(30, 'You complete Hollow Below and return to the first floor at door 030.');
      return;
    }
    if (subfloorLevel % 5 === 0) {
      setMessage(`A presence stirs at Hollow Below ${padRoom(subfloorLevel)}. Hide quickly!`);
      startThreat(3);
    } else {
      setMessage(`You descend to Hollow Below ${padRoom(subfloorLevel)}. Keep moving.`);
    }
    return;
  }

  if (onThirdFloor) {
    if (thirdFloorLevel >= 103) {
      endGame(true, 'You make it through all 103 office rooms and find your way outside.');
      return;
    }
    playSound(240, 0.16, 'triangle', 0.06);
    thirdFloorLevel += 1;
    searched = false;
    drawersLooted = false;
    updateRoom();
    if (thirdFloorLevel === 103) {
      setMessage('You reach Office 103. The way out is just ahead.');
    } else if (thirdFloorLevel % 10 === 0) {
      setMessage(`A rushing shape appears in Office ${padRoom(thirdFloorLevel)}. Hide from the Rebounder!`);
      startReboundThreat();
    } else if (thirdFloorLevel % 5 === 0) {
      setMessage(`A presence stirs in Office ${padRoom(thirdFloorLevel)}. Hide quickly!`);
      startThreat(3);
    } else {
      setMessage(`You enter Office ${padRoom(thirdFloorLevel)}. Keep moving.`);
    }
    return;
  }

  if (onSecondFloor) {
    if (secondFloorLevel === 55) {
      if (secondFloorPuzzleSolved) {
        enterThirdFloor();
      } else if (skeletonKeyUses > 0) {
        skeletonKeyUses -= 1;
        secondFloorPuzzleSolved = true;
        updateInventory();
        updateRoom();
        setMessage(`The skeleton key opens the final lock. ${skeletonKeyUses} use${skeletonKeyUses === 1 ? '' : 's'} remaining.`);
      } else {
        secondFloorPuzzleShown = true;
        updateRoom();
        setMessage('The route upstairs is sealed. Solve the final sequence to reach the third floor.');
      }
      return;
    }
    playSound(240, 0.16, 'triangle', 0.06);
    secondFloorLevel += 1;
    searched = false;
    drawersLooted = false;
    updateRoom();
    if (secondFloorLevel === 55) {
      setMessage('You reach the final door on floor 055. Inspect the lock and solve its sequence.');
    } else if (secondFloorLevel % 10 === 0) {
      setMessage(`A rushing shape appears on Second Floor ${padRoom(secondFloorLevel)}. Hide from the Rebounder!`);
      startReboundThreat();
    } else if (secondFloorLevel % 5 === 0) {
      setMessage(`A presence stirs on Second Floor ${padRoom(secondFloorLevel)}. Hide quickly!`);
      startThreat(3);
    } else {
      setMessage(`You climb to Second Floor ${padRoom(secondFloorLevel)}. Keep moving.`);
    }
    return;
  }

  if (isLockedRoom(room + 1)) {
    if (skeletonKeyUses > 0) {
      skeletonKeyUses -= 1;
      playSound(520, 0.16, 'triangle', 0.07);
      updateInventory();
      setMessage(`The skeleton key opens the door. ${skeletonKeyUses} use${skeletonKeyUses === 1 ? '' : 's'} remaining.`);
    } else if (hasKey) {
      hasKey = false;
      playSound(520, 0.16, 'triangle', 0.07);
      updateInventory();
      setMessage('The brass key turns. The lock clicks open.');
    } else {
      setMessage('The next door is locked. Search this room for a key.');
      return;
    }
  }

  playSound(220, 0.18, 'square', 0.045);
  if (room >= 30) {
    endGame(true, 'You made it out. The morning air has never felt so good.');
    return;
  }

  room += 1;
  searched = false;
  drawersLooted = false;
  updateRoom();

  if (room === 3 || room === 6 || room === 9 || room === 15 || room === 21 || room === 27) {
    startThreat();
  } else if (room === 25) {
    setMessage(silverKeyUses > 0
      ? `A silver lock glints beside a hidden stairwell. Your key has ${silverKeyUses} use${silverKeyUses === 1 ? '' : 's'} left.`
      : 'You find a sealed stairwell. A silver key may open the subfloor entrance.');
  } else if (isLockedRoom(room + 1)) {
    setMessage(`Room ${padRoom(room)} is quiet. Search carefully—the next door is locked.`);
  } else {
    setMessage(`You step into room ${padRoom(room)}. Keep your eyes on the door.`);
  }
}

function endGame(won, text, cause = '') {
  stopAmbientMusic();
  if (won) {
    playSound(523, 0.25, 'sine', 0.08);
    setTimeout(() => playSound(659, 0.35, 'sine', 0.08), 180);
  } else {
    playSound(75, 0.7, 'sawtooth', 0.1);
  }
  gameOver = true;
  clearInterval(threatTimer);
  threatActive = false;
  staticThreat = false;
  staticEntityVisual.hidden = true;
  threatOverlay.hidden = true;
  hideButton.hidden = true;
  crossButton.hidden = true;
  subfloorButton.hidden = true;
  stairwellButton.hidden = true;
  secondFloorButton.hidden = true;
  backdoorSwitchButton.disabled = true;
  clearInterval(backdoorTimerInterval);
  scene.classList.remove('danger');
  scene.classList.add(won ? 'won' : 'dead');
  deathVerdict.hidden = true;
  if (cause) {
    deathCause.textContent = `You died to ${cause}.`;
    setTimeout(() => {
      deathVerdict.hidden = false;
    }, 720);
  }
  roomType.textContent = won ? 'ESCAPED' : 'GAME OVER';
  sceneTitle.textContent = won ? 'You found the exit.' : 'The hallway got you.';
  sceneText.textContent = text;
  setMessage(won
    ? (onStairwell ? 'You climbed all 70 Stairwell sets.' : onSubfloor ? 'You survived all fifty Hollow Below levels.' : onThirdFloor ? 'You made it through all 103 office rooms.' : onSecondFloor ? 'You escaped the second floor.' : 'You survived all thirty rooms.')
    : 'Your journey ends here. Refresh the page to try again.');
  searchButton.disabled = true;
  doorButton.disabled = true;
}

puzzleAnswers.forEach((answerButton) => {
  answerButton.addEventListener('click', () => {
    if (room !== 30 || onBackdoor || onSubfloor || onSecondFloor || onThirdFloor || gameOver || finalPuzzleSolved) return;

    if (answerButton.dataset.answer === '32') {
      finalPuzzleSolved = true;
      playSound(880, 0.22, 'sine', 0.08);
      updateRoom();
      setMessage('Correct. The sequence doubles each time, and the final lock clicks open.');
    } else {
      playSound(180, 0.12, 'square', 0.05);
      setMessage('The lock rejects that answer. Try the sequence again.');
    }
  });
});

secondFloorAnswers.forEach((answerButton) => {
  answerButton.addEventListener('click', () => {
    if (!onSecondFloor || secondFloorLevel !== 55 || gameOver || secondFloorPuzzleSolved) return;

    if (answerButton.dataset.answer === '48') {
      secondFloorPuzzleSolved = true;
      playSound(740, 0.18, 'sine', 0.08);
      setTimeout(() => playSound(990, 0.22, 'sine', 0.07), 140);
      updateRoom();
      setMessage('Correct. The sequence doubles each time, and the door to the third floor unlocks.');
    } else {
      playSound(150, 0.14, 'square', 0.05);
      setMessage('The final lock rejects that answer. Try another number.');
    }
  });
});

trashItemButtons.forEach((button) => {
  button.addEventListener('click', () => {
    if (!onStairwell || stairwellTrashCleared || gameOver) return;
    trashItemsCleared.add(Number(button.dataset.trash));
    updateRoom();
    if (trashItemsCleared.size === 3) {
      stairwellTrashCleared = true;
      updateRoom();
      setMessage('The landing is clear. You can continue up the stairs.');
    } else {
      setMessage(`You clear away some debris (${trashItemsCleared.size} of 3 items removed).`);
    }
  });
});

searchButton.addEventListener('click', searchRoom);
lootDrawersButton.addEventListener('click', lootDrawers);
breakStaticTVButton.addEventListener('click', breakStaticTV);
useBandageButton.addEventListener('click', useBandage);
hideButton.addEventListener('click', hideFromThreat);
crossButton.addEventListener('click', useCross);
claimCrossButton.addEventListener('click', claimShopCross);
claimSkeletonKeyButton.addEventListener('click', claimShopSkeletonKey);
buyBandageButton.addEventListener('click', buyBandage);
subfloorButton.addEventListener('click', unlockSubfloor);
stairwellButton.addEventListener('click', enterStairwell);
secondFloorButton.addEventListener('click', enterSecondFloor);
atticButton.addEventListener('click', enterAttic);
outdoorDetourButton.addEventListener('click', visitGroundskeeperGarden);
groundskeeperButton.addEventListener('click', speakWithGroundskeeper);
repairAtticButton.addEventListener('click', repairAtticKeepsakes);
returnOutdoorButton.addEventListener('click', returnFromGarden);
backdoorSwitchButton.addEventListener('click', activateBackdoorSwitch);
doorButton.addEventListener('click', openDoor);

startMenu.addEventListener('click', () => startAmbientMusic('menu'), true);

startButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const startingFloor = button.dataset.start;
    onSubfloor = startingFloor === 'subfloor';
    onBackdoor = startingFloor === 'backdoor';
    onSecondFloor = startingFloor === 'second-floor';
    onThirdFloor = startingFloor === 'third-floor';
    onAttic = startingFloor === 'attic';
    onStairwell = startingFloor === 'stairwell';
    silverKeyUses = onSecondFloor ? 2 : 0;
    if (onThirdFloor) thirdFloorLevel = 1;
    if (onAttic) atticLevel = 1;

    if (onSubfloor) scene.classList.add('subfloor');
    if (onSecondFloor) scene.classList.add('second-floor');
    if (onThirdFloor) scene.classList.add('office-floor');
    if (onAttic) scene.classList.add('attic');
    if (onStairwell) scene.classList.add('stairwell');
    if (onBackdoor) {
      backdoorLevel = 0;
      backdoorTime = 45;
      activatedBackdoorSwitches.clear();
    }

    gameShell.classList.remove('game-not-started');
    startMenu.hidden = true;
    updateRoom();
    setMessage(onSubfloor
      ? 'You begin in the Hollow Below. Find a way through all fifty levels.'
      : onBackdoor
        ? 'You begin in the Backdoor with 45 seconds. Activate switches every five rooms for 15 more seconds, and reach the exit before time runs out.'
        : onSecondFloor
        ? 'You begin on the second floor. The silver key can unlock the stairwell at floor 030.'
        : onThirdFloor
          ? 'You begin in the third-floor offices. Find the strange door at Office 052 to enter the attic.'
          : onAttic
            ? 'You begin in the attic. Explore all 50 rooms and search the drawers for special keepsakes.'
            : onStairwell
              ? 'You begin in the stairwell. Climb all 70 sets of stairs to reach the top.'
              : 'The door is ahead. Search the room before moving on.');
    if (onSubfloor || onStairwell) startAmbientMusic('subfloor');
    if (onBackdoor) startBackdoorTimer();
  });
});

updateRoom();
