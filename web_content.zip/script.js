function calculer() {
    // Récuperer le volume saisi
    let v=parseFloat(document.getElementById("volume").value);
    // Vérifier si le volume est valide
    if ( isNaN(v)){
        alert("Veuillez entrer un volume.");
        return;}
        // Formule du chlorure Cl-
        let Cl =(v*0.025*35.5*1000)/50;
        // Formule du Sodium Na+
        let Na=(23/35.5)*Cl;
        // Afficher les résultats 
        document.getElementById("chlorure")
        .textContent =
                    Cl.toFixed(2);
        document.getElementById("sodium")
        .textContent =
                    Na.toFixed(2)
                    }
 function effacer() {

    // vider le volume

    document.getElementById("volume").value="";

    // Remettre les résultats à zéro

    document.getElementById(chlorure).textContent="---";

    document.getElementById("sodium").textContent="---";
 }