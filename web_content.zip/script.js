let documents=[],activeDocument=0,fontSize=16,fontFamily="Consolas",darkMode=false,wordWrap=false,autoSave=true,zoom=100;
const editor=()=>document.getElementById("textEditor");
const active=()=>documents[activeDocument];

function makeDoc(name="بدون عنوان",text=""){return {name,text,savedText:text,modified:false}}
function initialize(){
  try{documents=JSON.parse(localStorage.getItem("notepad_documents")||"[]")}catch(e){documents=[]}
  if(!documents.length)documents=[makeDoc()];
  try{let p=JSON.parse(localStorage.getItem("notepad_preferences")||"{}");fontSize=p.fontSize||16;fontFamily=p.fontFamily||"Consolas";darkMode=!!p.darkMode;wordWrap=!!p.wordWrap;autoSave=p.autoSave!==false;zoom=p.zoom||100}catch(e){}
  document.body.classList.toggle("dark",darkMode); applyEditorStyle(); renderTabs(); loadActive(); updateUI();
}
function persist(){if(autoSave)localStorage.setItem("notepad_documents",JSON.stringify(documents));localStorage.setItem("notepad_preferences",JSON.stringify({fontSize,fontFamily,darkMode,wordWrap,autoSave,zoom}))}
function renderTabs(){
 const box=document.getElementById("tabs");box.innerHTML="";
 documents.forEach((d,i)=>{let t=document.createElement("div");t.className="tab "+(i===activeDocument?"active":"");t.innerHTML=`<span>${esc(d.name)}${d.modified?" •":""}</span><button class="close" onclick="event.stopPropagation();closeDocument(${i})">×</button>`;t.onclick=()=>{activeDocument=i;loadActive()};box.appendChild(t)})
}
function esc(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function loadActive(){editor().value=active().text;editor().focus();applyEditorStyle();updateLineNumbers();updateUI()}
function sync(){active().text=editor().value;active().modified=active().text!==active().savedText;renderTabs();updateLineNumbers();updateUI();persist()}
function updateUI(){
 document.getElementById("titleText").textContent=(active().modified?"*":"")+active().name+" - مفكرة";
 document.getElementById("windowTitle").textContent=(active().modified?"*":"")+active().name+" - مفكرة";
 let v=editor().value, pos=editor().selectionStart, before=v.slice(0,pos),line=(before.match(/\n/g)||[]).length+1,col=pos-(before.lastIndexOf("\n")+1)+1;
 document.getElementById("cursorStatus").textContent=`السطر ${line}، العمود ${col}`;
 document.getElementById("selectionStatus").textContent=`${v.length} أحرف`;
 document.getElementById("wordStatus").textContent=`${v.trim()?v.trim().split(/\s+/).length:0} كلمات`;
 document.getElementById("zoomStatus").textContent=zoom+"%";
 document.getElementById("documentStatus").textContent=active().modified?"تم التعديل":"تم الحفظ";
}
function updateLineNumbers(){let n=editor().value.split("\n").length;document.getElementById("lineNumbers").textContent=Array.from({length:n},(_,i)=>i+1).join("\n")}
function applyEditorStyle(){editor().style.fontSize=(fontSize*zoom/100)+"px";editor().style.fontFamily=fontFamily;editor().classList.toggle("wrap",wordWrap);editor().wrap=wordWrap?"soft":"off"}
function newDocument(){documents.push(makeDoc());activeDocument=documents.length-1;closeMenus();loadActive()}
function closeDocument(i){if(documents[i].modified&&!confirm("هذا المستند غير محفوظ. هل تريد إغلاقه؟"))return;documents.splice(i,1);if(!documents.length)documents=[makeDoc()];activeDocument=Math.min(activeDocument,documents.length-1);loadActive()}
function openDocument(){document.getElementById("fileInput").click()}
document.getElementById("fileInput").addEventListener("change",e=>{let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{documents.push(makeDoc(f.name,r.result));activeDocument=documents.length-1;loadActive();persist()};r.readAsText(f);e.target.value=""})
function saveDocument(){let d=active();let blob=new Blob([d.text],{type:"text/plain;charset=utf-8"});let a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=d.name||"بدون عنوان.txt";a.click();URL.revokeObjectURL(a.href);d.savedText=d.text;d.modified=false;renderTabs();updateUI();persist()}
function saveAs(){let name=prompt("اسم الملف:",active().name);if(name){active().name=name;saveDocument()}}
function printDocument(){let w=window.open("","_blank");w.document.write("<pre style='white-space:pre-wrap;font-family:monospace'>"+esc(active().text)+"</pre>");w.document.close();w.print()}
function appClose(){if(documents.some(d=>d.modified)&&!confirm("هناك تغييرات غير محفوظة. إغلاق المفكرة؟"))return;document.body.innerHTML='<div style="padding:40px;font-family:Arial">تم إغلاق المفكرة. أعد تحميل الصفحة لتشغيلها.</div>'}
function undoText(){document.execCommand("undo")}
function redoText(){document.execCommand("redo")}
function cutText(){document.execCommand("cut")}
function copyText(){document.execCommand("copy")}
async function pasteText(){try{let t=await navigator.clipboard.readText();let s=editor().selectionStart,e=editor().selectionEnd;editor().setRangeText(t,s,e,"end");sync()}catch(e){alert("يرجى السماح بالوصول إلى الحافظة أو استخدام Ctrl+V")}}
function selectAllText(){editor().select()}
function showFind(){openDialog("findPanel");document.getElementById("findInput").focus()}
function showReplace(){openDialog("findPanel");document.getElementById("replaceInput").style.display="block";document.getElementById("findInput").focus()}
function findNext(){let q=document.getElementById("findInput").value;if(!q)return;let e=editor(),start=e.selectionEnd,i=e.value.indexOf(q,start);if(i<0)i=e.value.indexOf(q);if(i>=0){e.focus();e.setSelectionRange(i,i+q.length)}else alert("لم يتم العثور على النص")}
function replaceCurrent(){let q=document.getElementById("findInput").value,r=document.getElementById("replaceInput").value,e=editor();if(e.value.slice(e.selectionStart,e.selectionEnd)===q)e.setRangeText(r,e.selectionStart,e.selectionEnd,"end");else findNext();sync()}
function replaceAll(){let q=document.getElementById("findInput").value,r=document.getElementById("replaceInput").value;if(q){editor().value=editor().value.split(q).join(r);sync()}}
function toggleWordWrap(){wordWrap=!wordWrap;applyEditorStyle();persist();closeMenus()}
function toggleDarkMode(){darkMode=!darkMode;document.body.classList.toggle("dark",darkMode);persist();closeMenus()}
function zoomIn(){zoom=Math.min(200,zoom+10);applyEditorStyle();persist();updateUI()}
function zoomOut(){zoom=Math.max(50,zoom-10);applyEditorStyle();persist();updateUI()}
function resetZoom(){zoom=100;applyEditorStyle();persist();updateUI()}
function openSettings(){openDialog("settingsPanel");closeMenus()}
function changeFont(v){fontFamily=v;applyEditorStyle();persist()}
function changeFontSize(v){fontSize=Number(v);applyEditorStyle();persist()}
function toggleAutoSave(){autoSave=!autoSave;persist();closeMenus();alert(autoSave?"تم تفعيل الحفظ التلقائي":"تم إيقاف الحفظ التلقائي")}
function clearLocalData(){if(confirm("مسح جميع البيانات المحلية؟")){localStorage.clear();location.reload()}}
function showAbout(){openDialog("aboutPanel");closeMenus()}
function openDialog(id){document.getElementById("dialogOverlay").classList.add("open");document.querySelectorAll(".dialog").forEach(x=>x.classList.remove("open"));document.getElementById(id).classList.add("open")}
function closeDialogs(){document.getElementById("dialogOverlay").classList.remove("open")}
function closeMenus(){document.querySelectorAll(".menu-dropdown").forEach(x=>x.classList.remove("open"));document.querySelectorAll(".menu-bar>button").forEach(x=>x.classList.remove("active"))}

document.querySelectorAll(".menu-bar>button").forEach(b=>b.onclick=()=>{let id=b.dataset.menu+"Menu";let m=document.getElementById(id),was=m.classList.contains("open");closeMenus();if(!was){m.classList.add("open");b.classList.add("active")}})
document.addEventListener("click",e=>{if(!e.target.closest(".menu-bar"))closeMenus();if(e.target.id==="dialogOverlay")closeDialogs()})
editor().addEventListener("input",sync);editor().addEventListener("keyup",updateUI);editor().addEventListener("click",updateUI);editor().addEventListener("scroll",()=>document.getElementById("lineNumbers").scrollTop=editor().scrollTop)
document.addEventListener("keydown",e=>{
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="n"){e.preventDefault();newDocument()}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="o"){e.preventDefault();openDocument()}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="s"){e.preventDefault();saveDocument()}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="f"){e.preventDefault();showFind()}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="h"){e.preventDefault();showReplace()}
 if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="p"){e.preventDefault();printDocument()}
 if((e.ctrlKey||e.metaKey)&&e.key==="+"){e.preventDefault();zoomIn()}
 if((e.ctrlKey||e.metaKey)&&e.key==="-"){e.preventDefault();zoomOut()}
 if((e.ctrlKey||e.metaKey)&&e.key==="0"){e.preventDefault();resetZoom()}
})
window.addEventListener("beforeunload",()=>persist())
initialize()
