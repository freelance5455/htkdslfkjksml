"use strict";

const API_LIST = ["https://api.binance.com", "https://data-api.binance.vision"];
let busy = false;
const $ = id => document.getElementById(id);

function formatPrice(value) {
    if (!Number.isFinite(value)) return "--";
    return value.toLocaleString("en-US", {minimumFractionDigits:2, maximumFractionDigits:6});
}
function setConnection(message, color) {
    $("connection").textContent = message;
    $("connection").style.color = color;
}

async function fetchBinance(path) {
    let lastError;
    for (const base of API_LIST) {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 12000);
        try {
            const response = await fetch(base + path, {signal:controller.signal, cache:"no-store"});
            if (!response.ok) throw new Error("HTTP " + response.status);
            return await response.json();
        } catch (error) {
            lastError = error;
        } finally {
            clearTimeout(timer);
        }
    }
    throw lastError || new Error("Binance connection failed");
}

async function getCandles(symbol, interval) {
    const path = "/api/v3/klines?symbol=" + encodeURIComponent(symbol) +
        "&interval=" + encodeURIComponent(interval) + "&limit=200";
    const data = await fetchBinance(path);
    if (!Array.isArray(data) || data.length < 60) throw new Error("Insufficient candle data");
    return data.map(item => ({
        time:Number(item[0]), open:Number(item[1]), high:Number(item[2]),
        low:Number(item[3]), close:Number(item[4]), volume:Number(item[5])
    }));
}
async function getLivePrice(symbol) {
    const data = await fetchBinance("/api/v3/ticker/price?symbol=" + encodeURIComponent(symbol));
    const price = Number(data.price);
    if (!Number.isFinite(price) || price <= 0) throw new Error("Invalid live price");
    return price;
}

function EMA(data, period) {
    const k = 2 / (period + 1), result = [];
    let previous = data[0];
    result.push(previous);
    for (let i=1;i<data.length;i++) {
        previous = data[i] * k + previous * (1-k);
        result.push(previous);
    }
    return result;
}
function RSI(data, period=14) {
    const result = [];
    for (let i=0;i<data.length;i++) {
        if (i<period) { result.push(null); continue; }
        let gains=0, losses=0;
        for (let j=i-period+1;j<=i;j++) {
            const diff=data[j]-data[j-1];
            if (diff>0) gains+=diff; else losses+=Math.abs(diff);
        }
        const avgGain=gains/period, avgLoss=losses/period;
        result.push(avgLoss===0 ? 100 : 100-(100/(1+avgGain/avgLoss)));
    }
    return result;
}
function MACD(data) {
    const fast=EMA(data,12), slow=EMA(data,26);
    const line=data.map((_,i)=>fast[i]-slow[i]);
    const signal=EMA(line,9);
    return {line:line[line.length-1], signal:signal[signal.length-1]};
}
function ATR(candles, period=14) {
    const ranges=[];
    for(let i=1;i<candles.length;i++) {
        const c=candles[i], p=candles[i-1];
        ranges.push(Math.max(c.high-c.low,Math.abs(c.high-p.close),Math.abs(c.low-p.close)));
    }
    const recent=ranges.slice(-period);
    return recent.reduce((sum,v)=>sum+v,0)/recent.length;
}
function fibonacci(candles) {
    const recent=candles.slice(-100);
    const high=Math.max(...recent.map(c=>c.high));
    const low=Math.min(...recent.map(c=>c.low));
    const range=high-low;
    const levels=[["0%",0],["23.6%",.236],["38.2%",.382],["50%",.5],["61.8%",.618],["78.6%",.786],["100%",1]];
    return {
        high,low,range,
        levels:levels.map(x=>({name:x[0],price:high-range*x[1]})),
        extension:[{name:"127.2%",price:low+range*1.272},{name:"161.8%",price:low+range*1.618}]
    };
}
function bollinger(data,period=20) {
    const values=data.slice(-period);
    const mean=values.reduce((a,b)=>a+b,0)/values.length;
    const variance=values.reduce((a,b)=>a+Math.pow(b-mean,2),0)/values.length;
    const deviation=Math.sqrt(variance);
    return {middle:mean,upper:mean+2*deviation,lower:mean-2*deviation};
}

function analyze(candles,price) {
    const closes=candles.map(c=>c.close);
    const ema9=EMA(closes,9), ema21=EMA(closes,21), ema50=EMA(closes,50);
    const rsi=RSI(closes), macd=MACD(closes), atr=ATR(candles);
    const bb=bollinger(closes), fib=fibonacci(candles);
    const last=candles[candles.length-1];
    const e9=ema9[ema9.length-1], e21=ema21[ema21.length-1], e50=ema50[ema50.length-1];
    const r=rsi[rsi.length-1];
    const volumeAverage=candles.slice(-21,-1).reduce((sum,c)=>sum+c.volume,0)/20;
    const volumeStrong=last.volume>volumeAverage;
    let buy=0,sell=0;
    const checks=[];
    function check(name,condition) {
        if(condition==="buy") buy++;
        else if(condition==="sell") sell++;
        checks.push({name,result:condition==="buy"?"BULLISH":condition==="sell"?"BEARISH":"NEUTRAL"});
    }
    check("EMA 9 / EMA 21",e9>e21?"buy":e9<e21?"sell":"neutral");
    check("EMA 21 / EMA 50",e21>e50?"buy":e21<e50?"sell":"neutral");
    check("Price / EMA 21",price>e21?"buy":price<e21?"sell":"neutral");
    check("RSI",r>50&&r<70?"buy":r<50&&r>30?"sell":"neutral");
    check("MACD",macd.line>macd.signal?"buy":macd.line<macd.signal?"sell":"neutral");
    check("Volume",volumeStrong&&last.close>last.open?"buy":volumeStrong&&last.close<last.open?"sell":"neutral");
    check("Bollinger",price>bb.middle?"buy":price<bb.middle?"sell":"neutral");
    const bullish=buy>=5&&buy-sell>=3, bearish=sell>=5&&sell-buy>=3;
    const signal=bullish?"BUY":bearish?"SELL":"WAIT";
    const confidence=Math.round(Math.max(buy,sell)/checks.length*100);
    let entry=price,target1=0,target2=0,stop=0;
    if(signal==="BUY"){stop=entry-atr*1.5;target1=entry+atr*2;target2=entry+atr*3;}
    else if(signal==="SELL"){stop=entry+atr*1.5;target1=entry-atr*2;target2=entry-atr*3;}
    return {signal,confidence,buy,sell,entry,target1,target2,stop,e9,e21,e50,r,macd,atr,bb,fib,volumeStrong,checks};
}

function displayResults(result,price,symbol,interval) {
    $("price").textContent="$"+formatPrice(price);
    $("signal").textContent=result.signal;
    $("signal").className=result.signal.toLowerCase();
    $("confidence").textContent="Signal Strength: "+result.confidence+"%";
    $("entry").textContent=formatPrice(result.entry);
    $("target1").textContent=result.signal==="WAIT"?"--":formatPrice(result.target1);
    $("target2").textContent=result.signal==="WAIT"?"--":formatPrice(result.target2);
    $("stoploss").textContent=result.signal==="WAIT"?"--":formatPrice(result.stop);
    $("ema9").textContent=formatPrice(result.e9);
    $("ema21").textContent=formatPrice(result.e21);
    $("ema50").textContent=formatPrice(result.e50);
    $("rsi").textContent=result.r.toFixed(2);
    $("macd").textContent=result.macd.line.toFixed(5);
    $("atr").textContent=formatPrice(result.atr);
    $("volume").textContent=result.volumeStrong?"Above Average":"Below Average";
    $("trend").textContent=result.e9>result.e21?"BULLISH":result.e9<result.e21?"BEARISH":"SIDEWAYS";
    $("pair").textContent=symbol;
    $("tf").textContent=interval;
    $("updated").textContent=new Date().toLocaleTimeString();

    let fibHTML="";
    result.fib.levels.concat(result.fib.extension.map(x=>({name:"Extension "+x.name,price:x.price}))).forEach(level=>{
        fibHTML+=`<div class="fib-row"><span>${level.name}</span><b>${formatPrice(level.price)}</b></div>`;
    });
    $("fibonacci").innerHTML=fibHTML;
    $("confirmations").innerHTML=result.checks.map(item=>
        `<div class="confirm-row"><span>${item.name}</span><b>${item.result}</b></div>`
    ).join("");

    const trend=result.e9>result.e21&&result.e21>result.e50?"Strong bullish EMA alignment":
        result.e9<result.e21&&result.e21<result.e50?"Strong bearish EMA alignment":"Mixed EMA trend";
    const rsiText=result.r>70?"RSI indicates overbought conditions":
        result.r<30?"RSI indicates oversold conditions":"RSI is in a neutral range";
    const macdText=result.macd.line>result.macd.signal?"MACD bullish momentum":"MACD bearish momentum";
    const signalText=result.signal==="BUY"?"Bullish confirmation detected.":
        result.signal==="SELL"?"Bearish confirmation detected.":"No sufficiently strong trading confirmation.";
    $("analysis").innerHTML=`<p>📊 ${trend}</p><p>📈 ${rsiText}</p><p>⚡ ${macdText}</p>
        <p>📦 Volume: ${result.volumeStrong?"Above average":"Below average"}</p>
        <p>🌀 Fibonacci: Price ${price>result.fib.levels[4].price?"above":"below"} the 61.8% retracement level.</p>
        <p>🎯 Final Result: ${signalText}</p><p>BUY points: ${result.buy} | SELL points: ${result.sell}</p>`;
}

async function startAnalysis() {
    if(busy)return;
    busy=true;
    $("analyzeBtn").disabled=true;
    $("refreshBtn").disabled=true;
    const symbol=$("symbol").value, interval=$("interval").value;
    setConnection("Connecting...","#f0b90b");
    try {
        const candles=await getCandles(symbol,interval);
        const price=await getLivePrice(symbol);
        const result=analyze(candles,price);
        displayResults(result,price,symbol,interval);
        setConnection("● BINANCE CONNECTED","#00df83");
    } catch(error) {
        console.error("Analysis error:",error);
        setConnection("CONNECTION ERROR","#ff4b65");
        $("analysis").textContent="Data error: "+error.message+
            ". Check your internet connection or try again later.";
    } finally {
        busy=false;
        $("analyzeBtn").disabled=false;
        $("refreshBtn").disabled=false;
    }
}
$("analyzeBtn").addEventListener("click",startAnalysis);
$("refreshBtn").addEventListener("click",startAnalysis);
$("symbol").addEventListener("change",startAnalysis);
$("interval").addEventListener("change",startAnalysis);
window.addEventListener("load",startAnalysis);
setInterval(startAnalysis,15000);
