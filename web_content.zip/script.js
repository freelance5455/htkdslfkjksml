function submitOrder(){
  const uid=document.getElementById('uid').value.trim();
  const pkg=document.getElementById('package').value;
  const pay=document.getElementById('payment').value;
  const msg=document.getElementById('message');
  msg.style.display='block';
  if(!uid){msg.textContent='⚠️ আগে Player UID দিন।';return;}
  msg.textContent=`✅ Demo order তৈরি হয়েছে: ${pkg} — ${pay}. UID: ${uid}`;
}