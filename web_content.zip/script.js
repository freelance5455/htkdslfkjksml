
/* =========================================================
   حقوق الطبع والنشر - Yousef Osama
   هذا الكود يضيف وسائل ردع بسيطة ضد العبث من الواجهة.
   لا يمكن لـ HTML/CSS/JS وحدها منع شخص يملك ملفات التطبيق
   من تعديلها بشكل مطلق.
   ========================================================= */
(function(){
  "use strict";

  // منع قائمة الضغط المطول/الزر الأيمن.
  document.addEventListener("contextmenu", function(e){ e.preventDefault(); });

  // منع تحديد النص والسحب غير الضروري.
  document.addEventListener("selectstart", function(e){ e.preventDefault(); });
  document.addEventListener("dragstart", function(e){ e.preventDefault(); });

  // منع اختصارات شائعة لفتح أدوات المطور أو حفظ/عرض المصدر.
  document.addEventListener("keydown", function(e){
    const key = (e.key || "").toLowerCase();
    if (
      key === "f12" ||
      (e.ctrlKey && e.shiftKey && ["i","j","c"].includes(key)) ||
      (e.ctrlKey && ["u","s"].includes(key))
    ) {
      e.preventDefault();
      e.stopPropagation();
    }
  }, true);

  // علامة ملكية في DOM.
  document.documentElement.setAttribute("data-copyright", "Yousef Osama");
})();

const KEY="project_draft_web";
const els={name:document.getElementById("name"),description:document.getElementById("description"),category:document.getElementById("category"),budget:document.getElementById("budget"),deadline:document.getElementById("deadline"),count:document.getElementById("count"),error:document.getElementById("error"),summary:document.getElementById("summary")};
let projectType="تطبيق أندرويد";
try{const d=JSON.parse(localStorage.getItem(KEY)||"{}");if(d.name)els.name.value=d.name;if(d.description)els.description.value=d.description;if(d.category)els.category.value=d.category;if(d.budget)els.budget.value=d.budget;if(d.deadline)els.deadline.value=d.deadline;if(d.projectType)projectType=d.projectType}catch(e){}
document.querySelectorAll(".type").forEach(b=>{b.classList.toggle("active",b.dataset.type===projectType);b.addEventListener("click",()=>{projectType=b.dataset.type;document.querySelectorAll(".type").forEach(x=>x.classList.toggle("active",x===b));save();update()})});
function save(){localStorage.setItem(KEY,JSON.stringify({name:els.name.value,description:els.description.value,category:els.category.value,budget:els.budget.value,deadline:els.deadline.value,projectType}))}
function update(){els.count.textContent=els.description.value.length;els.summary.textContent=`${projectType} • ${els.category.value}`;save()}
["name","description","category","budget","deadline"].forEach(id=>els[id].addEventListener("input",update));
["category","budget","deadline"].forEach(id=>els[id].addEventListener("change",update));
document.getElementById("send").addEventListener("click",()=>{if(els.description.value.trim().length<20){els.error.textContent="اكتب وصفًا من 20 حرف على الأقل.";els.description.focus();return}els.error.textContent="";let m="أهلًا يا يوسف 👋\nحابب أطلب تنفيذ مشروع جديد.\n\n";if(els.name.value.trim())m+=`الاسم: ${els.name.value.trim()}\n`;m+=`نوع المشروع: ${projectType}\nالمجال: ${els.category.value}\nالميزانية المتوقعة: ${els.budget.value}\nموعد التنفيذ المطلوب: ${els.deadline.value}\n\nوصف المشروع:\n${els.description.value.trim()}`;(function(message){
  const encoded = encodeURIComponent(message);
  const intentUrl =
    "intent://send?phone=201066379432&text=" + encoded +
    "#Intent;scheme=whatsapp;package=com.whatsapp;end";
  const appUrl = "whatsapp://send?phone=201066379432&text=" + encoded;
  const webUrl = "https://api.whatsapp.com/send?phone=201066379432&text=" + encoded;

  let opened = false;

  // Android WebView may hand an intent:// URI to the installed app.
  try {
    window.location.href = intentUrl;
    opened = true;
  } catch(e) {}

  // Give the WebView a chance to launch WhatsApp, then try the app scheme.
  setTimeout(function(){
    try { window.location.href = appUrl; } catch(e) {}
  }, 350);

  // Last fallback: open the HTTPS endpoint in a separate browsing context.
  setTimeout(function(){
    try { window.open(webUrl, "_blank"); } catch(e) {
      window.location.href = webUrl;
    }
  }, 1000);
})(m)});
update();