const questionBank = [
  {category:'الجغرافيا',text:'ما عاصمة اليابان؟',answers:['بكين','طوكيو','سيول','بانكوك'],correct:1},
  {category:'الجغرافيا',text:'ما أكبر محيط في العالم؟',answers:['الأطلسي','الهندي','المتجمد الشمالي','الهادئ'],correct:3},
  {category:'الجغرافيا',text:'ما عاصمة أستراليا؟',answers:['سيدني','ملبورن','كانبرا','بيرث'],correct:2},
  {category:'الجغرافيا',text:'في أي قارة تقع دولة البرازيل؟',answers:['أفريقيا','أمريكا الجنوبية','آسيا','أوروبا'],correct:1},
  {category:'العلوم',text:'ما الكوكب المعروف بالكوكب الأحمر؟',answers:['الزهرة','المشتري','المريخ','عطارد'],correct:2},
  {category:'العلوم',text:'ما الغاز الذي تمتصه النباتات من الهواء؟',answers:['الأكسجين','ثاني أكسيد الكربون','النيتروجين','الهيدروجين'],correct:1},
  {category:'العلوم',text:'ما الرمز الكيميائي للماء؟',answers:['CO₂','O₂','H₂O','NaCl'],correct:2},
  {category:'العلوم',text:'ما العضو الذي يضخ الدم في جسم الإنسان؟',answers:['الرئة','الكبد','القلب','الكلية'],correct:2},
  {category:'التاريخ',text:'في أي قارة تقع مصر؟',answers:['آسيا فقط','أفريقيا','أوروبا','أمريكا الجنوبية'],correct:1},
  {category:'التاريخ',text:'ما الحضارة التي بنت الأهرامات في الجيزة؟',answers:['الرومانية','الفرعونية','الفينيقية','الإغريقية'],correct:1},
  {category:'التاريخ',text:'في أي عام انتهت الحرب العالمية الثانية؟',answers:['1939','1942','1945','1950'],correct:2},
  {category:'التاريخ',text:'ما المدينة التي كانت عاصمة الدولة العباسية؟',answers:['دمشق','بغداد','القاهرة','قرطبة'],correct:1},
  {category:'الرياضة',text:'كم عدد لاعبي فريق كرة القدم داخل الملعب؟',answers:['9','10','11','12'],correct:2},
  {category:'الرياضة',text:'كل كم سنة تقام الألعاب الأولمبية الصيفية عادة؟',answers:['سنتين','ثلاث سنوات','أربع سنوات','خمس سنوات'],correct:2},
  {category:'الرياضة',text:'ما الرياضة التي تستخدم فيها مضارب وكرة صفراء؟',answers:['السباحة','التنس','الملاكمة','الجمباز'],correct:1},
  {category:'الرياضة',text:'في أي رياضة يُستخدم مصطلح «كش مات»؟',answers:['الشطرنج','الكاراتيه','كرة السلة','المبارزة'],correct:0},
  {category:'التكنولوجيا',text:'ماذا تعني الأحرف WWW؟',answers:['شبكة الويب العالمية','نظام تشغيل','لغة برمجة','ذاكرة حاسوب'],correct:0},
  {category:'التكنولوجيا',text:'أي من هذه الأجهزة يُستخدم لإدخال النصوص إلى الحاسوب؟',answers:['الشاشة','الطابعة','لوحة المفاتيح','السماعة'],correct:2},
  {category:'التكنولوجيا',text:'ما الاسم الشائع للذكاء الاصطناعي باللغة الإنجليزية؟',answers:['AI','USB','GPS','CPU'],correct:0},
  {category:'التكنولوجيا',text:'أي وحدة تُستخدم عادة لقياس سعة تخزين الملفات؟',answers:['المتر','الغيغابايت','اللتر','الدرجة'],correct:1},
  {category:'الثقافة العامة',text:'كم عدد ألوان قوس قزح؟',answers:['خمسة','ستة','سبعة','ثمانية'],correct:2},
  {category:'الثقافة العامة',text:'كم عدد أيام السنة العادية؟',answers:['360','364','365','366'],correct:2},
  {category:'الثقافة العامة',text:'ما الحيوان المعروف بلقب سفينة الصحراء؟',answers:['الحصان','الجمل','الفيل','الغزال'],correct:1},
  {category:'الثقافة العامة',text:'ما المعدن السائل في درجة حرارة الغرفة؟',answers:['الحديد','النحاس','الزئبق','الفضة'],correct:2},
  {category:'الأدب واللغة',text:'ما جمع كلمة «كتاب»؟',answers:['كتابون','كتابات فقط','كتب','كتبة'],correct:2},
  {category:'الأدب واللغة',text:'من مؤلف رواية «البؤساء»؟',answers:['فيكتور هوغو','نجيب محفوظ','تولستوي','شكسبير'],correct:0},
  {category:'الأدب واللغة',text:'كم عدد حروف اللغة العربية؟',answers:['26','28','29','30'],correct:1},
  {category:'الأدب واللغة',text:'ما نوع كلمة «يكتب»؟',answers:['اسم','فعل','حرف','صفة'],correct:1},
  {category:'المعلومات الدينية',text:'كم عدد أركان الإسلام؟',answers:['أربعة','خمسة','ستة','سبعة'],correct:1},
  {category:'المعلومات الدينية',text:'ما الشهر الذي يصوم فيه المسلمون؟',answers:['محرم','رمضان','رجب','شعبان'],correct:1},
  {category:'المعلومات الدينية',text:'ما قبلة المسلمين في الصلاة؟',answers:['المسجد النبوي','المسجد الأقصى','الكعبة المشرفة','جبل عرفات'],correct:2},
  {category:'المعلومات الدينية',text:'كم عدد الصلوات المفروضة في اليوم والليلة؟',answers:['ثلاث','أربع','خمس','ست'],correct:2},
  {category:'الاختراعات والاكتشافات',text:'من يُنسب إليه اختراع الهاتف؟',answers:['توماس إديسون','ألكسندر غراهام بيل','إسحاق نيوتن','غاليليو'],correct:1},
  {category:'الاختراعات والاكتشافات',text:'من العالم المرتبط باكتشاف قانون الجاذبية؟',answers:['نيوتن','باستور','داروين','فاراداي'],correct:0},
  {category:'الاختراعات والاكتشافات',text:'أي اختراع ارتبط بالأخوان رايت؟',answers:['المصباح الكهربائي','الطائرة','الراديو','التلغراف'],correct:1},
  {category:'الاختراعات والاكتشافات',text:'من العالم الذي طوّر لقاح الجدري؟',answers:['إدوارد جينر','ألبرت أينشتاين','ماري كوري','لويس باستور'],correct:0}
];

const advancedQuestions = [
  {category:'العلوم',difficulty:'medium',text:'ما العنصر الأكثر وفرة في القشرة الأرضية؟',answers:['الحديد','الأكسجين','السيليكون','الألومنيوم'],correct:1},
  {category:'الجغرافيا',difficulty:'medium',text:'ما أكبر صحراء في العالم من حيث المساحة؟',answers:['الصحراء الكبرى','صحراء غوبي','صحراء القارة القطبية الجنوبية','صحراء الربع الخالي'],correct:2},
  {category:'التاريخ',difficulty:'medium',text:'في أي عام سقط جدار برلين؟',answers:['1985','1987','1989','1991'],correct:2},
  {category:'العلوم',difficulty:'medium',text:'ما وحدة قياس شدة التيار الكهربائي؟',answers:['الفولت','الأمبير','الواط','الأوم'],correct:1},
  {category:'الجغرافيا',difficulty:'medium',text:'ما المضيق الذي يفصل بين قارتي آسيا وأمريكا الشمالية؟',answers:['جبل طارق','البوسفور','بيرينغ','ملقا'],correct:2},
  {category:'الأدب واللغة',difficulty:'medium',text:'من صاحب كتاب «مقدمة ابن خلدون»؟',answers:['ابن بطوطة','ابن خلدون','الجاحظ','المسعودي'],correct:1},
  {category:'التكنولوجيا',difficulty:'medium',text:'ما لغة التنسيق الأساسية المستخدمة لتصميم صفحات الويب؟',answers:['HTML','CSS','SQL','Python'],correct:1},
  {category:'الرياضة',difficulty:'medium',text:'كم عدد الحلقات في الشعار الأولمبي؟',answers:['أربع','خمس','ست','سبع'],correct:1},
  {category:'العلوم',difficulty:'medium',text:'ما الجزء المسؤول عن إنتاج الطاقة في الخلية؟',answers:['النواة','الميتوكوندريا','الغشاء','الريبوسوم'],correct:1},
  {category:'التاريخ',difficulty:'medium',text:'ما عاصمة الدولة الأموية في الأندلس؟',answers:['إشبيلية','غرناطة','قرطبة','طليطلة'],correct:2},
  {category:'الثقافة العامة',difficulty:'medium',text:'كم ضلعًا للشكل السداسي؟',answers:['خمسة','ستة','سبعة','ثمانية'],correct:1},
  {category:'الاختراعات والاكتشافات',difficulty:'medium',text:'من اخترع شبكة الويب العالمية؟',answers:['تيم بيرنرز لي','بيل غيتس','ستيف جوبز','آلان تورنغ'],correct:0},
  {category:'العلوم',difficulty:'smart',text:'ما السرعة التقريبية للضوء في الفراغ؟',answers:['300 ألف كم/ث','30 ألف كم/ث','3 آلاف كم/ث','3 ملايين كم/ث'],correct:0},
  {category:'الجغرافيا',difficulty:'smart',text:'ما الدولة التي يمر بها كل من خط الاستواء وخط غرينتش؟',answers:['غانا','البرازيل','إندونيسيا','كينيا'],correct:0},
  {category:'التاريخ',difficulty:'smart',text:'ما المعاهدة التي أنهت الحرب العالمية الأولى رسميًا مع ألمانيا؟',answers:['معاهدة باريس','معاهدة فرساي','معاهدة روما','معاهدة لوزان'],correct:1},
  {category:'العلوم',difficulty:'smart',text:'ما اسم تحول المادة من الحالة الصلبة إلى الغازية مباشرة؟',answers:['التكاثف','التبخر','التسامي','التجمد'],correct:2},
  {category:'التكنولوجيا',difficulty:'smart',text:'ما النظام العددي الذي تعتمد عليه الحواسيب أساسًا؟',answers:['العشري','الثماني','الثنائي','السداسي عشر'],correct:2},
  {category:'الأدب واللغة',difficulty:'smart',text:'من الشاعر الملقب بأمير الشعراء؟',answers:['حافظ إبراهيم','أحمد شوقي','المتنبي','إيليا أبو ماضي'],correct:1},
  {category:'الجغرافيا',difficulty:'smart',text:'ما أعمق نقطة معروفة في محيطات العالم؟',answers:['خندق بورتوريكو','خندق ماريانا','خندق اليابان','خندق تونغا'],correct:1},
  {category:'العلوم',difficulty:'smart',text:'ما الغاز النبيل الذي رمزه الكيميائي Xe؟',answers:['النيون','الأرجون','الزينون','الكريبتون'],correct:2},
  {category:'التاريخ',difficulty:'smart',text:'في أي مدينة وُقّع ميثاق الأمم المتحدة عام 1945؟',answers:['نيويورك','جنيف','سان فرانسيسكو','لندن'],correct:2},
  {category:'الرياضة',difficulty:'smart',text:'ما الدولة التي فازت بأول بطولة لكأس العالم لكرة القدم عام 1930؟',answers:['البرازيل','إيطاليا','الأوروغواي','الأرجنتين'],correct:2},
  {category:'الثقافة العامة',difficulty:'smart',text:'ما اسم وحدة قياس المقاومة الكهربائية؟',answers:['الأمبير','الأوم','الفولت','الجول'],correct:1},
  {category:'الاختراعات والاكتشافات',difficulty:'smart',text:'من وضع أسس علم الوراثة من خلال تجاربه على نبات البازلاء؟',answers:['لويس باستور','غريغور مندل','تشارلز داروين','روبرت هوك'],correct:1},
  {category:'العلوم',difficulty:'genius',text:'ما الجسيم الحامل للقوة الكهرومغناطيسية؟',answers:['الغلوون','الفوتون','بوزون هيغز','النيوترينو'],correct:1},
  {category:'العلوم',difficulty:'genius',text:'ما قيمة عدد أفوغادرو تقريبًا؟',answers:['6.022 × 10²³','3.14 × 10⁸','9.81 × 10²','1.602 × 10⁻¹⁹'],correct:0},
  {category:'الجغرافيا',difficulty:'genius',text:'ما الدولة التي كانت تُعرف تاريخيًا باسم سيام؟',answers:['كمبوديا','تايلاند','ميانمار','لاوس'],correct:1},
  {category:'التاريخ',difficulty:'genius',text:'من الخليفة العباسي الذي أسس مدينة بغداد؟',answers:['هارون الرشيد','المأمون','أبو جعفر المنصور','المعتصم'],correct:2},
  {category:'العلوم',difficulty:'genius',text:'ما الإنزيم الذي يفكك النشا إلى سكريات أبسط في اللعاب؟',answers:['الليباز','الأميلاز','البيبسين','التربسين'],correct:1},
  {category:'التكنولوجيا',difficulty:'genius',text:'ما التعقيد الزمني للبحث الثنائي في قائمة مرتبة؟',answers:['O(1)','O(log n)','O(n)','O(n²)'],correct:1},
  {category:'الأدب واللغة',difficulty:'genius',text:'من مؤلف ملحمة «الكوميديا الإلهية»؟',answers:['دانتي أليغييري','غوته','هوميروس','سرفانتس'],correct:0},
  {category:'العلوم',difficulty:'genius',text:'ما الطبقة الجوية التي تحدث فيها معظم الظواهر الجوية؟',answers:['الستراتوسفير','الميزوسفير','التروبوسفير','الثرموسفير'],correct:2},
  {category:'التاريخ',difficulty:'genius',text:'ما اسم عاصمة الإمبراطورية البيزنطية؟',answers:['روما','القسطنطينية','الإسكندرية','أثينا'],correct:1},
  {category:'العلوم',difficulty:'genius',text:'ما العدد الذري لعنصر التنغستن؟',answers:['74','79','82','92'],correct:0},
  {category:'الجغرافيا',difficulty:'genius',text:'أي نهر يمر عبر مدينة بودابست؟',answers:['الراين','الدانوب','الفولغا','الإلبه'],correct:1},
  {category:'الاختراعات والاكتشافات',difficulty:'genius',text:'من العالم الذي صاغ مبدأ عدم اليقين في ميكانيكا الكم؟',answers:['نيلز بور','فيرنر هايزنبرغ','إرفين شرودنغر','ماكس بلانك'],correct:1},
  {category:'الثقافة العامة',difficulty:'genius',text:'ما اسم المقياس المستخدم لقياس صلادة المعادن؟',answers:['مقياس ريختر','مقياس موهس','مقياس بوفورت','مقياس ميركالي'],correct:1},
  {category:'العلوم',difficulty:'genius',text:'ما الحمض النووي الذي يحمل المعلومات الوراثية في معظم الكائنات؟',answers:['RNA','DNA','ATP','ADP'],correct:1},
  {category:'التاريخ',difficulty:'genius',text:'أي حضارة قديمة طورت الكتابة المسمارية في بلاد الرافدين؟',answers:['السومرية','الفينيقية','الحيثية','القرطاجية'],correct:0},
  {category:'العلوم',difficulty:'genius',text:'ما اسم الحد الفاصل الذي لا يستطيع الضوء بعده الإفلات من الثقب الأسود؟',answers:['الأفق الحدثي','النجم النيوتروني','السديم','الحزام الكويكبي'],correct:0},
  {category:'الجغرافيا',difficulty:'genius',text:'ما أعلى قمة جبلية في قارة أفريقيا؟',answers:['جبل كينيا','جبل كليمنجارو','جبل أطلس','جبل إلبروس'],correct:1},
  {category:'التكنولوجيا',difficulty:'genius',text:'ما وظيفة بروتوكول DNS على الإنترنت؟',answers:['تشفير الملفات','تحويل أسماء النطاقات إلى عناوين IP','ضغط الصور','إدارة البريد الوارد'],correct:1},
  {category:'العلوم',difficulty:'genius',text:'ما اسم العملية التي تنتج بها النجوم الطاقة بدمج نوى خفيفة؟',answers:['الانشطار النووي','الاندماج النووي','التحلل الإشعاعي','التأين'],correct:1},
  {category:'الأدب واللغة',difficulty:'genius',text:'من صاحب رواية «مئة عام من العزلة»؟',answers:['خورخي لويس بورخيس','غابرييل غارسيا ماركيز','بابلو نيرودا','ماريو بارغاس يوسا'],correct:1},
  {category:'التاريخ',difficulty:'genius',text:'ما اسم المدينة القديمة التي دفنها ثوران بركان فيزوف عام 79م؟',answers:['قرطاج','بومبي','طروادة','إسبرطة'],correct:1},
  {category:'العلوم',difficulty:'genius',text:'ما الجزيء الذي يخزن الطاقة القابلة للاستخدام مباشرة في الخلايا؟',answers:['ATP','DNA','الكولاجين','الهيموغلوبين'],correct:0}
];
questionBank.forEach(question=>{question.difficulty='beginner'});
questionBank.push(...advancedQuestions);
questionBank.push(
  {category:'التاريخ',difficulty:'medium',text:'ما اسم الطريق التجاري القديم الذي ربط الصين بالبحر المتوسط؟',answers:['طريق البخور','طريق الحرير','طريق التوابل','طريق الذهب'],correct:1},
  {category:'التاريخ',difficulty:'smart',text:'في أي مدينة ازدهرت مكتبة بيت الحكمة؟',answers:['بغداد','دمشق','القاهرة','قرطبة'],correct:0},
  {category:'التاريخ',difficulty:'genius',text:'من القائد الذي عبر جبال الألب بجيشه والفيلة خلال الحرب البونيقية الثانية؟',answers:['يوليوس قيصر','حنبعل','الإسكندر الأكبر','سكيبيو'],correct:1},
  {category:'الجغرافيا',difficulty:'medium',text:'ما عاصمة المغرب؟',answers:['الدار البيضاء','مراكش','الرباط','فاس'],correct:2},
  {category:'الجغرافيا',difficulty:'smart',text:'ما أكبر دولة في العالم من حيث المساحة؟',answers:['كندا','الصين','الولايات المتحدة','روسيا'],correct:3},
  {category:'الجغرافيا',difficulty:'genius',text:'ما البحر الذي لا تحده سواحل برية ويقع داخل المحيط الأطلسي؟',answers:['بحر العرب','بحر سارجاسو','بحر البلطيق','بحر قزوين'],correct:1},
  {category:'العلوم',difficulty:'medium',text:'ما القوة التي تجعل الأجسام تسقط نحو الأرض؟',answers:['المغناطيسية','الجاذبية','الاحتكاك','الطفو'],correct:1},
  {category:'العلوم',difficulty:'smart',text:'ما الجزء الأساسي الذي يحمل الصفات الوراثية في الخلية؟',answers:['DNA','النشا','الكالسيوم','الهيموغلوبين'],correct:0},
  {category:'العلوم',difficulty:'genius',text:'ما وحدة قياس التردد في النظام الدولي؟',answers:['الجول','الهرتز','النيوتن','الباسكال'],correct:1},
  {category:'الرياضة',difficulty:'medium',text:'كم عدد لاعبي فريق كرة السلة داخل الملعب؟',answers:['خمسة','ستة','سبعة','ثمانية'],correct:0},
  {category:'الرياضة',difficulty:'smart',text:'في أي رياضة تُمنح جائزة القميص الأصفر؟',answers:['التنس','سباق الدراجات','السباحة','كرة اليد'],correct:1},
  {category:'الرياضة',difficulty:'genius',text:'كم عدد المربعات على رقعة الشطرنج؟',answers:['56','64','72','81'],correct:1},
  {category:'المعلومات الدينية',difficulty:'medium',text:'ما اسم الكتاب المقدس عند المسلمين؟',answers:['الإنجيل','التوراة','القرآن الكريم','الزبور'],correct:2},
  {category:'المعلومات الدينية',difficulty:'smart',text:'في أي مدينة يقع المسجد النبوي؟',answers:['مكة المكرمة','المدينة المنورة','القدس','الطائف'],correct:1},
  {category:'المعلومات الدينية',difficulty:'genius',text:'ما اسم الغار الذي نزل فيه الوحي أول مرة؟',answers:['غار ثور','غار حراء','غار أحد','غار النور'],correct:1},
  {category:'الثقافة العامة',difficulty:'medium',text:'ما اللغة الأكثر انتشارًا في البرازيل؟',answers:['الإسبانية','البرتغالية','الفرنسية','الإنجليزية'],correct:1},
  {category:'الثقافة العامة',difficulty:'smart',text:'ما العملة الرسمية في اليابان؟',answers:['الوون','اليوان','الين','الروبية'],correct:2},
  {category:'الثقافة العامة',difficulty:'genius',text:'كم عدد عظام جسم الإنسان البالغ تقريبًا؟',answers:['186','206','226','246'],correct:1},
  {category:'التكنولوجيا',difficulty:'medium',text:'ما الجهاز الذي يوزع اتصال الإنترنت لاسلكيًا في المنزل؟',answers:['الماسح الضوئي','الموجّه (الراوتر)','الطابعة','المعالج'],correct:1},
  {category:'التكنولوجيا',difficulty:'smart',text:'ما الامتداد الشائع لملفات صفحات الويب؟',answers:['.mp3','.html','.jpg','.zip'],correct:1},
  {category:'التكنولوجيا',difficulty:'genius',text:'أي بنية بيانات تعمل بمبدأ آخر ما يدخل أول ما يخرج؟',answers:['طابور','مكدس','شجرة','جدول تجزئة'],correct:1}
);

const STORAGE_KEY = 'encyclopediaChallengeData';
const MUSIC_KEY = 'encyclopediaChallengeMusic';
const QUESTION_TIME = 20;
const QUESTION_COUNT = 20;
const DIFFICULTIES = [
  {id:'beginner',name:'مبتدئ'},
  {id:'medium',name:'متوسط'},
  {id:'smart',name:'ذكي'},
  {id:'genius',name:'عبقري'}
];
const LEVELS = [
  {name:'مبتدئ',points:0},{name:'متعلم',points:100},{name:'خبير',points:300},
  {name:'محترف',points:600},{name:'عبقري',points:1000},{name:'أسطورة المعرفة',points:1600}
];
const CATEGORIES = [...new Set(questionBank.map(question=>question.category))];
const CATEGORY_ART = {
  'الجغرافيا':{icon:'🌍',colors:['#137f78','#1953a0']},'العلوم':{icon:'🔬',colors:['#087f78','#1765a9']},
  'التاريخ':{icon:'🏺',colors:['#8b6534','#365b62']},'الرياضة':{icon:'⚽',colors:['#187c56','#2569a0']},
  'التكنولوجيا':{icon:'💻',colors:['#2455a0','#087c83']},'الثقافة العامة':{icon:'💡',colors:['#987432','#156d75']},
  'الأدب واللغة':{icon:'📚',colors:['#76549b','#245e84']},'المعلومات الدينية':{icon:'🕌',colors:['#147958','#236484']},
  'الاختراعات والاكتشافات':{icon:'⚙️',colors:['#226681','#53618c']}
};
const CATEGORY_FACTS = {
  'الجغرافيا':['تتغير الخرائط مع الزمن بفعل حركة الصفائح التكتونية وتغيّر السواحل.','خطوط الطول ودوائر العرض تساعد على تحديد المواقع بدقة على سطح الأرض.','تضم الأرض قارات ومحيطات متنوعة تؤثر في المناخ والحياة حولها.'],
  'العلوم':['تعتمد المعرفة العلمية على الملاحظة والتجربة والتحقق من النتائج.','تتكون المادة من ذرات، وتتحد الذرات لتشكّل الجزيئات والمواد المختلفة.','تتكامل أجهزة الجسم للحفاظ على وظائفه واتزانه.'],
  'التاريخ':['تساعد الآثار والوثائق على فهم حياة الشعوب والحضارات القديمة.','ساهمت طرق التجارة القديمة في انتقال السلع والأفكار والعلوم بين الشعوب.','تتطور المجتمعات عبر أحداث واختراعات وقرارات تترك أثرًا طويلًا.'],
  'الرياضة':['تساعد الممارسة المنتظمة على تطوير اللياقة والتركيز والعمل الجماعي.','لكل رياضة قواعدها الخاصة التي تضمن عدالة المنافسة وسلامة اللاعبين.','تُقام الألعاب الأولمبية الحديثة عادة كل أربع سنوات.'],
  'التكنولوجيا':['تتكون صفحات الويب غالبًا من HTML للبنية وCSS للتنسيق وJavaScript للتفاعل.','تساعد الخوارزميات على وصف خطوات حل المشكلات بوضوح وكفاءة.','تتصل الأجهزة الرقمية عبر بروتوكولات تنظم تبادل البيانات.'],
  'الثقافة العامة':['تختلف اللغات والعادات حول العالم، ويثري التعرف إليها فهمنا للثقافات.','تساعد القراءة المستمرة على توسيع المعرفة وتنمية القدرة على التفكير.','تتغير وحدات القياس والعملات باختلاف الدول والأنظمة المستخدمة.'],
  'الأدب واللغة':['تحتوي اللغة العربية على 28 حرفًا في الكتابة القياسية.','تنتقل الأفكار بين الأجيال عبر الشعر والقصص والكتب.','تمنح الصور البلاغية النصوص الأدبية معاني وإيحاءات أعمق.'],
  'المعلومات الدينية':['تحتل المعرفة الدينية مكانة مهمة في تاريخ وثقافة المجتمعات.','تختلف الشعائر والمناسبات الدينية، ويجمعها أثرها في حياة أتباعها.','تساعد قراءة المصادر الموثوقة على فهم المعلومات الدينية بدقة.'],
  'الاختراعات والاكتشافات':['تتراكم الاكتشافات العلمية غالبًا بفضل عمل أجيال من الباحثين.','غيّرت وسائل الاتصال الحديثة سرعة تبادل المعلومات بين الناس.','الاختراع يحول فكرة أو معرفة إلى أداة أو طريقة نافعة.']
};
const REWARDS = [
  {id:'first',icon:'🌱',name:'بداية الرحلة'},
  {id:'sharp',icon:'⚡',name:'ذهن متقد'},
  {id:'perfect',icon:'🏆',name:'إتقان كامل'},
  {id:'daily',icon:'☀️',name:'بطل اليوم'}
];
let saved = loadData();
let selectedCategory = 'all';
let game = null;
let timer = null;
let toastTimer = null;
let musicEnabled = localStorage.getItem(MUSIC_KEY) === 'true';


function loadData(){
  try {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return {name:typeof data.name === 'string' ? data.name : 'اللاعب',avatar:typeof data.avatar === 'string' ? data.avatar : '🧠',games:Array.isArray(data.games) ? data.games : [],badges:Array.isArray(data.badges) ? data.badges : [],totalXp:Number.isFinite(data.totalXp)?data.totalXp:null,coins:Number.isFinite(data.coins)?Math.max(0,data.coins):20,welcomeCoinsGranted:Boolean(data.welcomeCoinsGranted),sound:Boolean(data.sound)};
  } catch { return {name:'اللاعب',avatar:'🧠',games:[],badges:[],totalXp:null,coins:20,welcomeCoinsGranted:false,sound:false}; }
}
function saveData(){
  try { localStorage.setItem(STORAGE_KEY,JSON.stringify(saved)); }
  catch { showToast('تعذر الحفظ في هذا المتصفح.'); }
}
function $(id){return document.getElementById(id)}
function showScreen(id){
  document.querySelectorAll('.screen').forEach(screen=>screen.classList.toggle('active',screen.id===id));
  document.querySelectorAll('.nav-link').forEach(link=>link.classList.toggle('active',link.dataset.nav===id.replace('Screen','')));
  window.scrollTo({top:0,behavior:'smooth'});
}
function showToast(message){
  const toast=$('toast');toast.textContent=message;toast.classList.add('show');
  clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),2400);
}
function getLevel(points){return [...LEVELS].reverse().find(level=>points>=level.points)||LEVELS[0]}
function totalPoints(){return Number.isFinite(saved.totalXp)?saved.totalXp:saved.games.reduce((sum,entry)=>sum+(entry.playerScore||0)+(entry.rewardPoints||0),0)}
function updateCoinsDisplay(){
  const temporaryCoins=game&&!game.coinsCommitted?game.coinsEarned:0;
  $('coinCount').textContent=saved.coins+temporaryCoins;
}
function updateHome(){
  updateCoinsDisplay();
  $('headerName').textContent=saved.name;$('headerAvatar').textContent=saved.avatar;$('profileAvatar').textContent=saved.avatar;$('homeGames').textContent=saved.games.length;
  $('homeBest').textContent=saved.games.reduce((best,entry)=>Math.max(best,entry.playerScore||0),0);
  $('homeLevel').textContent=getLevel(totalPoints()).name;
}
function refreshProfile(){
  const points=totalPoints(),level=getLevel(points),next=LEVELS.find(item=>item.points>points);
  $('nicknameInput').value=saved.name;$('avatarSelect').value=saved.avatar;$('profileAvatar').textContent=saved.avatar;$('headerName').textContent=saved.name;$('headerAvatar').textContent=saved.avatar;
  $('profileLevel').textContent=level.name;$('profilePoints').textContent=points;$('profileGames').textContent=saved.games.length;$('profileCoins').textContent=saved.coins;
  $('soundToggle').checked=saved.sound;
  $('musicToggle').checked=musicEnabled;
  updateAudioControls();
  $('levelTrack').replaceChildren();
  LEVELS.forEach(item=>{const chip=document.createElement('span');chip.className=`level-chip${points>=item.points?' unlocked':''}`;chip.textContent=item.name;$('levelTrack').appendChild(chip)});
  $('levelProgress').textContent=next?`تحتاج إلى ${next.points-points} نقطة خبرة للوصول إلى مستوى ${next.name}.`:'وصلت إلى أعلى مستوى!';
  const paths=$('pathProgress');paths.replaceChildren();
  CATEGORIES.forEach(category=>{
    const rounds=saved.games.filter(entry=>entry.category===category||entry.categories?.includes(category));
    const card=document.createElement('div');card.className='path-card';
    const title=document.createElement('strong');title.textContent=category;
    const progress=document.createElement('span');progress.textContent=rounds.length?`${rounds.length} جولة · أفضل نتيجة ${Math.max(...rounds.map(entry=>entry.correct||0))}/${rounds[0].total||QUESTION_COUNT}`:'لم تبدأ بعد';
    card.append(title,progress);paths.appendChild(card);
  });
  const rewards=$('rewardTrack');rewards.replaceChildren();
  REWARDS.forEach(reward=>{
    const chip=document.createElement('span');chip.className=`reward-chip${saved.badges.includes(reward.id)?' unlocked':''}`;
    chip.textContent=`${reward.icon} ${reward.name}`;rewards.appendChild(chip);
  });
  $('rewardProgress').textContent=`فتحت ${saved.badges.length} من ${REWARDS.length} مكافآت.`;
}
function renderHistory(){
  const list=$('historyList');list.replaceChildren();
  if(!saved.games.length){const empty=document.createElement('div');empty.className='panel empty-state';empty.textContent='لا توجد جولات مسجلة بعد. ابدأ أول تحدٍ لك!';list.appendChild(empty);return}
  saved.games.slice().reverse().forEach(entry=>{
    const card=document.createElement('article');card.className='history-item panel';
    const details=document.createElement('div');const title=document.createElement('h3');title.textContent=entry.modeLabel;
    const info=document.createElement('p');info.textContent=`${entry.category} · ${entry.correct}/${entry.total} إجابة صحيحة · ${entry.date}`;
    const score=document.createElement('div');score.className='history-score';const points=document.createElement('strong');points.textContent=`${entry.playerScore} نقطة`;
    const level=document.createElement('span');level.textContent=entry.rewardPoints?`مكافأة +${entry.rewardPoints} XP`:'رحلة فردية';
    details.append(title,info);score.append(points,level);card.append(details,score);list.appendChild(card);
  });
}
function seededRandom(seed){let value=seed>>>0;return()=>{value=(value*1664525+1013904223)>>>0;return value/4294967296}}
function shuffle(items,random=Math.random){
  const copy=items.slice();for(let i=copy.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[copy[i],copy[j]]=[copy[j],copy[i]]}return copy;
}
function buildRoundQuestions(category,startDifficulty,random){
  let pool;
  if(category==='all') pool=shuffle(questionBank,random);
  else {
    const focused=shuffle(questionBank.filter(item=>item.category===category),random);
    const remaining=shuffle(questionBank.filter(item=>item.category!==category),random);
    pool=[...focused,...remaining];
  }
  const startRank=DIFFICULTIES.findIndex(item=>item.id===startDifficulty);
  const selected=[];
  const used=new Set();
  for(let index=0;index<QUESTION_COUNT;index++){
    const targetRank=Math.min(DIFFICULTIES.length-1,startRank+Math.floor(index/5));
    let candidates=pool.filter(item=>!used.has(item)&&DIFFICULTIES.findIndex(level=>level.id===item.difficulty)===targetRank);
    if(!candidates.length) candidates=pool.filter(item=>!used.has(item)&&DIFFICULTIES.findIndex(level=>level.id===item.difficulty)>targetRank);
    if(!candidates.length) candidates=pool.filter(item=>!used.has(item));
    const question=candidates[0];
    if(!question) break;
    selected.push(question);used.add(question);
  }
  return selected;
}
function beginRound(modeOverride){
  clearInterval(timer);
  const mode=modeOverride||$('modeSelect').value;
  const category=selectedCategory;
  const startDifficulty=$('difficultySelect').value;
  let random=Math.random;
  if(mode==='daily'){
    const dateKey=new Date().toISOString().slice(0,10);
    random=seededRandom(Number(dateKey.replaceAll('-','')));
  }
  const rounds=buildRoundQuestions(category,startDifficulty,random);
  game={mode,questions:rounds,index:0,player:{name:saved.name,score:0,correct:0},locked:false,category,startDifficulty,coinsEarned:0,coinsCommitted:false};
  $('gameModeLabel').textContent=mode==='daily'?'تحدي اليوم':'مسار المعرفة';
  showScreen('gameScreen');renderQuestion();
}
function renderScoreboard(){
  const board=$('scoreboard');board.replaceChildren();
  const card=document.createElement('div');card.className='score-player active-turn';
  const name=document.createElement('span');name.textContent='نقاط رحلتك';
  const score=document.createElement('strong');score.textContent=`${game.player.score} نقطة`;
  card.append(name,score);board.appendChild(card);
}
function makeQuestionArtwork(category,questionText){
  const art=CATEGORY_ART[category]||{icon:'✨',colors:['#176c77','#35528c']};
  const visualSeed=[...questionText].reduce((sum,char)=>sum+char.charCodeAt(0),0);
  const glowX=180+visualSeed%540,glowY=25+visualSeed%100,glowRadius=120+visualSeed%80;
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 300"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${art.colors[0]}"/><stop offset="1" stop-color="${art.colors[1]}"/></linearGradient><radialGradient id="glow"><stop stop-color="#ffffff" stop-opacity=".2"/><stop offset="1" stop-color="#ffffff" stop-opacity="0"/></radialGradient></defs><rect width="900" height="300" rx="32" fill="url(#g)"/><circle cx="${glowX}" cy="${glowY}" r="${glowRadius}" fill="url(#glow)"/><circle cx="165" cy="280" r="165" fill="#ffffff" opacity=".055"/><path d="M0 230 Q200 165 390 245 T900 205 V300 H0Z" fill="#061522" opacity=".2"/><text x="450" y="190" text-anchor="middle" font-size="125">${art.icon}</text><text x="450" y="260" text-anchor="middle" fill="#ffffff" opacity=".82" font-family="Arial,sans-serif" font-size="24">${category}</text></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
let gameAudioContext = null;
function getAudioContext(){
  const AudioContextClass=window.AudioContext||window.webkitAudioContext;
  if(!AudioContextClass)return null;
  if(!gameAudioContext||gameAudioContext.state==='closed')gameAudioContext=new AudioContextClass();
  return gameAudioContext;
}
function updateAudioControls(){
  const musicButton=$('musicButton'),effectsButton=$('effectsButton');
  if(musicButton){musicButton.classList.toggle('active',musicEnabled);musicButton.setAttribute('aria-pressed',String(musicEnabled));musicButton.innerHTML=musicEnabled?'♫ <span>الموسيقى تعمل</span>':'♫ <span>الموسيقى</span>';musicButton.title=musicEnabled?'إيقاف الموسيقى':'تشغيل الموسيقى';}
  if(effectsButton){effectsButton.classList.toggle('active',saved.sound);effectsButton.setAttribute('aria-pressed',String(saved.sound));effectsButton.innerHTML=saved.sound?'🔊 <span>المؤثرات تعمل</span>':'🔇 <span>المؤثرات</span>';effectsButton.title=saved.sound?'إيقاف المؤثرات الصوتية':'تشغيل المؤثرات الصوتية';}
}
function setSoundEnabled(enabled){
  saved.sound=Boolean(enabled);saveData();
  if($('soundToggle'))$('soundToggle').checked=saved.sound;
  updateAudioControls();
  showToast(saved.sound?'تم تفعيل المؤثرات الصوتية.':'تم إيقاف المؤثرات الصوتية.');
}
function startBackgroundMusic(){
  if(!musicEnabled)return;
  const music=$('backgroundMusic');if(!music)return;
  music.volume=0.22;
  const playback=music.play();
  if(playback&&typeof playback.catch==='function')playback.catch(error=>console.warn('تعذر تشغيل الموسيقى قبل تفاعل المستخدم:',error));
}
function stopBackgroundMusic(){
  const music=$('backgroundMusic');if(!music)return;
  music.pause();music.currentTime=0;
}
function setMusicEnabled(enabled){
  musicEnabled=Boolean(enabled);
  try{localStorage.setItem(MUSIC_KEY,String(musicEnabled));}catch(error){}
  if($('musicToggle'))$('musicToggle').checked=musicEnabled;
  updateAudioControls();
  if(musicEnabled){startBackgroundMusic();showToast('تم تشغيل موسيقى اللعبة.');}
  else{stopBackgroundMusic();showToast('تم إيقاف موسيقى اللعبة.');}
}
function playAnswerTone(correct){
  if(!saved.sound)return;
  try{
    const context=getAudioContext();if(!context)return;
    const play=()=>{
      const oscillator=context.createOscillator(),gain=context.createGain(),start=context.currentTime;
      oscillator.type='sine';oscillator.frequency.setValueAtTime(correct?660:220,start);
      gain.gain.setValueAtTime(.0001,start);gain.gain.exponentialRampToValueAtTime(.08,start+.015);gain.gain.exponentialRampToValueAtTime(.001,start+.2);
      oscillator.connect(gain);gain.connect(context.destination);oscillator.start(start);oscillator.stop(start+.22);
    };
    if(context.state==='suspended')context.resume().then(play).catch(()=>{});else play();
  }catch(error){console.warn('تعذر تشغيل المؤثر الصوتي:',error);}
}
function renderQuestion(){
  clearInterval(timer);game.locked=false;
  const question=game.questions[game.index];
  $('questionVisual').src=makeQuestionArtwork(question.category,question.text);
  $('questionVisual').alt=`رسم توضيحي لفئة ${question.category}`;
  $('factCard').classList.add('hidden');
  $('questionCounter').textContent=`السؤال ${game.index+1} من ${game.questions.length}`;
  $('categoryBadge').textContent=question.category;
  const difficulty=DIFFICULTIES.find(item=>item.id===question.difficulty)||DIFFICULTIES[0];
  $('difficultyBadge').textContent=difficulty.name;
  $('gameModeLabel').textContent=`${game.mode==='daily'?'تحدي اليوم':'مسار المعرفة'} · ${difficulty.name}`;
  $('progressBar').style.width=`${game.index/game.questions.length*100}%`;
  $('questionText').textContent=question.text;$('feedback').textContent='';$('feedback').className='feedback';
  $('nextQuestion').classList.add('hidden');renderScoreboard();
  const answers=$('answers');answers.replaceChildren();
  question.answers.forEach((answer,index)=>{
    const button=document.createElement('button');button.type='button';button.className='answer-btn';button.textContent=answer;
    button.addEventListener('click',()=>answerQuestion(index));answers.appendChild(button);
  });
  game.timeLeft=QUESTION_TIME;updateTimer();timer=setInterval(()=>{game.timeLeft--;updateTimer();if(game.timeLeft<=0)resolveQuestion(null)},1000);
}
function updateTimer(){
  $('timerText').textContent=game.timeLeft;$('timerBar').style.width=`${game.timeLeft/QUESTION_TIME*100}%`;
  $('timerBar').classList.toggle('urgent',game.timeLeft<=5);
}
function answerQuestion(index){if(game.locked)return;resolveQuestion(index)}
function resolveQuestion(answerIndex){
  if(game.locked)return;game.locked=true;clearInterval(timer);
  const question=game.questions[game.index],player=game.player,buttons=$('answers').querySelectorAll('button');
  buttons.forEach((button,index)=>{button.disabled=true;if(index===question.correct)button.classList.add('correct');if(index===answerIndex&&index!==question.correct)button.classList.add('wrong')});
  const feedback=$('feedback');
  if(answerIndex===question.correct){
    const bonus=Math.ceil(game.timeLeft/4);const earned=10+bonus;player.score+=earned;player.correct++;game.coinsEarned++;
    updateCoinsDisplay();
    feedback.textContent=`إجابة صحيحة! +${earned} نقطة و🪙 كوينز واحد (منها ${bonus} نقاط سرعة) ✨`;feedback.classList.add('good');
  }else if(answerIndex===null){feedback.textContent=`انتهى الوقت! الإجابة الصحيحة: ${question.answers[question.correct]}`;feedback.classList.add('neutral')}
  else{feedback.textContent=`ليست الإجابة الصحيحة. الإجابة الصحيحة: ${question.answers[question.correct]}`;feedback.classList.add('bad')}
  playAnswerTone(answerIndex===question.correct);
  const facts=CATEGORY_FACTS[question.category]||['تعلّم معلومة جديدة في كل جولة، فالمعرفة رحلة مستمرة.'];
  const factSeed=[...question.text].reduce((sum,char)=>sum+char.charCodeAt(0),0);
  $('factText').textContent=facts[factSeed%facts.length];
  $('factCard').classList.remove('hidden');
  renderScoreboard();
  $('nextQuestion').textContent=game.index===game.questions.length-1?'عرض حصاد الرحلة ←':'السؤال التالي ←';
  $('nextQuestion').classList.remove('hidden');
}
function advanceQuestion(){
  if(!game||!game.locked)return;
  game.index++;if(game.index>=game.questions.length){finishRound();return}renderQuestion();
}
function finishRound(){
  clearInterval(timer);$('progressBar').style.width='100%';
  const player=game.player,correct=player.correct,total=game.questions.length;
  const accuracy=Math.round(correct/total*100);
  const previousXp=totalPoints();
  const rewardPoints=(correct>=15?25:10)+(game.mode==='daily'?10:0)+(correct===total?20:0);
  $('finalScore').textContent=player.score;$('finalCorrect').textContent=`${correct} / ${total}`;
  $('finalAccuracy').textContent=`${accuracy}%`;
  const title=correct===total?'إتقان كامل! إجابات مذهلة':correct>=15?'تقدم رائع في مسارك!':'رحلة موفقة، واصل التعلّم';
  $('resultTitle').textContent=title;
  $('ratingStamp').textContent=accuracy>=90?'🏆 أسطورة الجولة':accuracy>=75?'⭐ أداء متميز':accuracy>=50?'🌟 أداء جيد':'🌱 بداية موفقة';
  $('ratingStamp').className=`rating-stamp ${accuracy>=75?'rating-high':accuracy>=50?'rating-mid':'rating-start'}`;
  const selectedDifficulty=DIFFICULTIES.find(item=>item.id===game.startDifficulty)||DIFFICULTIES[0];
  $('resultSubtitle').textContent=`${game.mode==='daily'?'تحدي اليوم':'مسار المعرفة'} · ${selectedDifficulty.name} · ${game.category==='all'?'كل الأقسام':game.category}`;
  const newBadges=[];
  const unlock=(id,condition)=>{
    if(condition&&!saved.badges.includes(id)){saved.badges.push(id);newBadges.push(REWARDS.find(reward=>reward.id===id))}
  };
  unlock('first',saved.games.length===0);
  unlock('sharp',correct>=15);
  unlock('perfect',correct===total);
  unlock('daily',game.mode==='daily');
  const details=$('resultDetails');details.replaceChildren();
  const xp=document.createElement('p');xp.textContent=`مكافأة الجولة: +${rewardPoints} نقطة خبرة 🎁`;
  const earnedCoins=game.coinsEarned+5;
  const coins=document.createElement('p');coins.textContent=`مكافأة العملات: +${earnedCoins} 🪙 (تشمل 5 كوينز لإكمال الجولة)`;
  const badges=document.createElement('p');badges.textContent=newBadges.length?`مكافآت جديدة: ${newBadges.map(item=>`${item.icon} ${item.name}`).join(' · ')}`:'استمر في اللعب لفتح مكافآت جديدة ✨';
  details.append(xp,coins,badges);
  saved.coins+=earnedCoins;game.coinsCommitted=true;
  saved.games.push({modeLabel:$('resultSubtitle').textContent,category:game.category==='all'?'كل الأقسام':game.category,categories:[...new Set(game.questions.map(question=>question.category))],playerScore:player.score,rewardPoints,correct,total,date:new Date().toLocaleDateString('ar')});
  saved.totalXp=previousXp+rewardPoints;saved.games=saved.games.slice(-100);saveData();updateHome();showScreen('resultScreen');
}
function openSetup(mode,category='all'){
  $('modeSelect').value=mode||'solo';
  selectedCategory=category;
  $('setupCategory').textContent=category==='all'?'كل الأقسام':category;
  showScreen('setupScreen');
}

document.querySelectorAll('[data-nav]').forEach(button=>button.addEventListener('click',()=>{
  const target=button.dataset.nav;
  if(target==='profile'){refreshProfile();showScreen('profileScreen')}
  else if(target==='history'){renderHistory();showScreen('historyScreen')}
  else if(target==='back')showScreen('homeScreen');
  else if(target==='home'){
    if(game&&$('gameScreen').classList.contains('active')){
      if(!confirm('هل تريد إنهاء الجولة؟ لن تُحفظ نتيجتها.'))return;
      clearInterval(timer);game=null;
    }
    showScreen('homeScreen');
  }
}));
document.querySelectorAll('.mode-card').forEach(button=>button.addEventListener('click',()=>openSetup(button.dataset.mode)));
document.querySelectorAll('.category-card').forEach(button=>button.addEventListener('click',()=>{
  openSetup('solo',button.dataset.category);
}));
$('startSetup').addEventListener('click',()=>openSetup('solo'));
$('beginGame').addEventListener('click',()=>beginRound());
$('nextQuestion').addEventListener('click',advanceQuestion);
$('playAgain').addEventListener('click',()=>{
  if(game){$('difficultySelect').value=game.startDifficulty;beginRound(game.mode)}
  else beginRound('solo');
});
$('backToSetup').addEventListener('click',()=>{
  if(confirm('العودة للإعدادات ستنهي الجولة الحالية دون حفظ نتيجتها. هل تريد المتابعة؟')){
    clearInterval(timer);game=null;openSetup($('modeSelect').value,selectedCategory);
  }
});
$('saveProfile').addEventListener('click',()=>{
  const name=$('nicknameInput').value.trim().slice(0,18);
  if(!name){$('profileNotice').textContent='اكتب اسمًا قبل الحفظ.';return}
  saved.name=name;saved.avatar=$('avatarSelect').value;saveData();updateHome();refreshProfile();$('profileNotice').textContent='تم حفظ ملفك الشخصي بنجاح.';
});
$('soundToggle').addEventListener('change',event=>setSoundEnabled(event.target.checked));
$('musicToggle').addEventListener('change',event=>setMusicEnabled(event.target.checked));
$('effectsButton').addEventListener('click',()=>setSoundEnabled(!saved.sound));
$('musicButton').addEventListener('click',()=>setMusicEnabled(!musicEnabled));
// Android WebView يشترط تفاعل المستخدم قبل السماح بتشغيل الصوت.
document.addEventListener('pointerdown',()=>{if(musicEnabled)startBackgroundMusic();},{passive:true});
$('resetData').addEventListener('click',()=>{
  if(confirm('سيتم حذف اسمك وسجل الجولات والمكافآت من هذا الجهاز. هل تريد المتابعة؟')){saved={name:'اللاعب',avatar:'🧠',games:[],badges:[],totalXp:0,coins:20,welcomeCoinsGranted:true,sound:false};setMusicEnabled(false);game=null;saveData();updateHome();refreshProfile();renderHistory();showToast('تم مسح البيانات المحفوظة، وتم تجهيز 20 كوينز للحساب الجديد.')}
});
if(!saved.welcomeCoinsGranted){saved.welcomeCoinsGranted=true;saveData();}
updateAudioControls();
updateHome();
