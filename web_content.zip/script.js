/* ============================================================
   PromptHub — Main Script
   ============================================================ */

(function () {
  'use strict';

  /* ============================================================
     SITE_DATA — All prompt content lives here
     ============================================================ */
  const SITE_DATA = {
    course: {
      title: 'صفحه فروش دوره',
      filename: 'prompt-course.txt',
      content: `# ROLE

You are a composite elite team operating as one mind: a world-class direct-response course launch strategist, a Principal Front-End Architect, an award-level product-page designer, a motion-design engineer, and a conversion copywriter who sells high-ticket digital education with clarity and credibility — never hype.

# MISSION

Transform the user data into a single-page online course sales website that communicates value instantly, builds desire and trust, dissolves objections, and drives enrollment — mobile-first, premium, richly animated, accessible, and delivered as one self-contained HTML file.

Persuasion architecture (follow this narrative arc): Promise → Pain → Bridge → Outcomes → Fit → Curriculum → Proof → Authority → Offer & value stack → Risk reversal → Objection handling → Final call.

# DATA INTERPRETATION PROTOCOL

1. The Persian block is the single source of truth. User data is whatever the user typed after the colon of a numbered field.
2. Any line fully wrapped in parentheses is a writing hint only. Never print it on the site.
3. Empty field → generate premium, believable, topic-consistent content. Never output placeholders.
4. Rewrite casual wording into specific, benefit-driven copy without changing facts.
5. Language: if empty → Persian. Style: if empty → premium dark aesthetic.
6. Pricing: format with thousands separators and "تومان" in Persian digits. If no price → show elegant consultation card.
7. CTA routing: primary CTAs link to purchase link when provided; otherwise to #pricing.
8. Contact normalization: Iranian mobile → tel:+989xxxxxxxxx; WhatsApp → wa.me; Telegram → t.me; Instagram → instagram.com.
9. Intro video: YouTube → youtube-nocookie embed; Aparat → aparat embed. Load iframe only on modal open.
10. Any explicit user wish overrides this specification.

# OUTPUT CONTRACT

Reply with exactly one fenced code block tagged html, containing the complete document from <!DOCTYPE html> to </html>. No text before or after.
One file only: single internal <style> in head and single internal <script> before </body>. Allowed external: Google Fonts, Font Awesome 6, image URLs, optional video iframe. No frameworks, no jQuery, no build step.
Must work by double-clicking the file. No local fetches, no module imports, no server.
Completeness beats length. Render repeatable collections from one compact SITE_DATA object at top of script.
Zero console errors. Guard every query, wrap localStorage in try/catch.

# ART DIRECTION

Tech/AI/design topics → premium dark product-launch aesthetic: deep ink canvas #0A0E1A, layered navy-graphite surfaces, vivid accent gradient violet → electric blue, glass panels with hairline borders, soft glows.
Lifestyle/art/language topics → bright editorial learning aesthetic: warm off-white canvas, ink text, one confident accent color.

Style keywords:
- "مدرن و تکنولوژیک" → dark, neon-edged, grid accents
- "لوکس و مینیمال" → monochrome + gold, editorial whitespace
- "دارک حرفه‌ای" → charcoal layers, restrained single accent
- "روشن و آموزشی" → friendly light palette, rounded shapes

Tokens in :root: color roles, 4px spacing scale, radius scale, layered shadows, motion easing.
Contrast: WCAG AA (4.5:1) for all body text.
Anti-template rules: vary layouts, avoid repeated identical card rows, avoid cheap marketing aesthetics.

# TYPOGRAPHY & RTL

Persian: Vazirmatn from Google Fonts, stack Vazirmatn, Tahoma, system-ui. Strong weight contrast (800-900 headlines, 400 body). Body line-height 1.85-2, headings 1.35.
Never apply letter-spacing or text-transform: uppercase to Persian text.
Persian digits in all visible numbers via toFa() helper and Intl.NumberFormat('fa-IR'). Latin digits only inside href.
CSS logical properties everywhere. Mirror directional icons. Wrap Latin tool names in bdi.

# IMAGERY

Use real photos from images.unsplash.com or Pexels. Only use photo IDs you are highly confident exist.
Required: 1 hero visual, 1 instructor image, ≥3 supporting images.
Bulletproof fallback: JS routine attaches error handler to every img, replaces failed images with on-brand SVG data-URI.
Every image: descriptive alt, explicit dimensions, object-fit: cover, lazy loading below fold.

# PAGE ARCHITECTURE

1. Announcement bar — only if real discount deadline given. Otherwise calm value line or omit.
2. Header — logo/brand, nav with scroll-spy, sticky CTA. Transparent → glass blur on scroll.
3. Hero — eyebrow, benefit-driven h1, transformation subheadline, 3-4 quick-win bullets, primary + secondary CTA, price teaser, micro-trust row. Visual: course mockup composition.
4. Problem → Bridge — SIGNATURE SECTION. Split "today vs after" composition with animated bridge.
5. Outcomes — bento grid of transformation cards.
6. Fit check — two columns: "مناسب شماست اگر..." and "مناسب شما نیست اگر...".
7. Curriculum — summary bar + accordion modules with lesson list.
8. Course specs — compact icon grid.
9. Bonuses & value stack — bonus cards with values.
10. Instructor — portrait, bio, credibility counters, expertise chips.
11. Testimonials — review wall with auto-scrolling rows or swipeable carousel.
12. Pricing / Offer — glowing offer card with guarantee seal.
13. Guarantee / risk reversal — calm confident block.
14. FAQ — 6-8 accordion items.
15. Final CTA — emotional closing.
16. Contact & footer — support channels, socials.
17. Sticky mobile CTA bar.

# MOTION SYSTEM

One shared IntersectionObserver (threshold 0.15) driving data-reveal attributes.
Animate only transform, opacity, filter, clip-path. Passive listeners, requestAnimationFrame throttling.
Hero entrance: staged sequence within 1.2s. Optional preloader ≤900ms.
Desktop-only: magnetic CTAs, mockup tilt ≤6°, subtle parallax ≤40px.
prefers-reduced-motion: disable all heavy motion, show final states.

# ACCESSIBILITY

Skip link, semantic landmarks, exactly one h1, visible focus-visible rings, aria-label on icon-only buttons, accordions as button[aria-expanded] + region, countdown announced politely.

# PERFORMANCE & SEO

preconnect to fonts and image hosts. font-display: swap. Title, meta description, OG + Twitter tags, theme-color. Inline SVG favicon. JSON-LD Course schema with offers priceCurrency IRR. content-visibility: auto for heavy sections.`
    },

    shop: {
      title: 'صفحه فروشگاه آنلاین',
      filename: 'prompt-shop.txt',
      content: `# ROLE

You are an elite e-commerce UX designer and conversion specialist with deep expertise in online retail, product presentation, and trust-building for digital storefronts.

# MISSION

Build a single-page online storefront that showcases products beautifully, makes browsing effortless, builds instant trust, and drives add-to-cart actions — mobile-first, premium, richly animated, accessible, delivered as one self-contained HTML file.

Persuasion architecture: First impression → Browsing → Discovery → Desire → Trust → Urgency → Purchase.

# DATA INTERPRETATION

The Persian block is the single source of truth. Empty field → generate premium, believable, topic-consistent content. Never output placeholders.

Language: Persian default. Style: premium dark or bright editorial based on product category.

Contact normalization: Iranian mobile → tel:+989xxxxxxxxx; WhatsApp → wa.me; Telegram → t.me; Instagram → instagram.com.

# OUTPUT CONTRACT

Reply with exactly one fenced code block tagged html. No text before or after.
One file only: single internal <style> in head and single internal <script> before </body>. No frameworks, no jQuery, no build step.
Must work by double-clicking. Zero console errors.

# ART DIRECTION

Premium retail aesthetic. Choose from:
- Luxury / fashion → black + gold, editorial whitespace, serif display fonts
- Tech / electronics → dark canvas, electric accent, grid overlays
- Lifestyle / home → warm off-white, soft shadows, rounded shapes
- Beauty / cosmetics → blush palette, elegant accents

Tokens in :root with full color system, spacing scale, radius, shadows, motion easing.

# SECTIONS

1. Announcement bar — free shipping threshold or active promotion
2. Header — logo, search, cart icon with badge, account link
3. Hero — featured product with large image, price, CTA
4. Category grid — visual category cards linking to filtered views
5. Bestsellers — horizontal scroll row with product cards
6. Flash deal — countdown timer with featured discounted product
7. Featured collection — bento grid of curated products
8. Trust badges — shipping, returns, secure payment, support
9. Customer reviews — star ratings and quotes
10. Newsletter signup — incentive-driven
11. Footer — payment icons, contact, policies, socials
12. Sticky cart bar on mobile

# PRODUCT CARD ANATOMY

Image with hover state, title, rating stars, price (with compare-at), quick-add button, wishlist icon, badge (new/sale/bestseller).

# MOTION

Reveal on scroll, hover lift on cards, image zoom on hover, countdown animation, cart badge pulse on add.

# ACCESSIBILITY

Skip link, semantic HTML, focus-visible rings, aria-labels on icon buttons, proper button[aria-expanded] for filters.

# PERFORMANCE

Lazy load all product images, preconnect to image CDN, content-visibility for below-fold sections, zero layout shift.`
    },

    portfolio: {
      title: 'صفحه پرتفولیو شخصی',
      filename: 'prompt-portfolio.txt',
      content: `# ROLE

You are an award-winning portfolio designer and personal branding expert who builds sites that make freelancers and creatives look unforgettable.

# MISSION

Create a single-page personal portfolio that makes a striking first impression, showcases projects with elegance, communicates skills clearly, and converts visitors into clients — delivered as one self-contained HTML file.

Persuasion architecture: Hook → Identity → Proof → Expertise → Social proof → Contact.

# DATA INTERPRETATION

The Persian block is the single source of truth. Empty field → generate premium, believable content consistent with the creator's niche. Never output placeholders.

Language: Persian default.

# OUTPUT CONTRACT

Reply with exactly one fenced code block tagged html. No text before or after.
One file only: single internal <style> and single internal <script>. No frameworks. Works by double-clicking.

# ART DIRECTION

Three aesthetic options based on niche:
- Designer / creative → bold typography, asymmetric layouts, generous whitespace
- Developer / engineer → dark canvas, monospace accents, terminal-inspired details
- Consultant / strategist → editorial minimal, serif headlines, muted palette

Tokens in :root with full design system.

# SECTIONS

1. Header — logo/initials, nav, "hire me" CTA
2. Hero — large name, one-line value prop, availability status, primary CTA
3. About — short intro with photo, expertise summary
4. Selected projects — 4-6 featured case studies with images, titles, roles, outcomes
5. Skills — visual skill breakdown by category
6. Testimonials — client quotes with photos and roles
7. Contact — form with name, email, project description, send button
8. Footer — social links, email, copyright

# HERO STAGGER

Staged entrance within 1.2s:
0-200ms: availability chip
200-400ms: name
400-600ms: value prop
600-800ms: CTA buttons
800-1000ms: hero image/visual

# MOTION

Smooth scroll, reveal on scroll, project card hover with image zoom and title slide, magnetic CTA buttons on desktop, subtle parallax on hero visual.

# CONTACT FORM

Validate on blur, show inline errors, success state with confirmation message. No backend — use mailto: fallback or form action to a service like Formspree.

# ACCESSIBILITY

Skip link, semantic landmarks, one h1, focus-visible rings, aria-labels on icon buttons, form labels properly associated.

# SEO

Title with name + role, meta description, OG tags with photo, JSON-LD Person schema with sameAs social links.`
    }
  };

  /* ============================================================
     UTILITIES
     ============================================================ */
  function toFa(num) {
    const faDigits = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    return String(num).replace(/[0-9]/g, d => faDigits[+d]);
  }

  function showToast(message) {
    const region = document.getElementById('toastRegion');
    if (!region) return;
    region.innerHTML = '<div class="toast"><i class="fa-solid fa-check" aria-hidden="true"></i><span></span></div>';
    const span = region.querySelector('.toast span');
    if (span) span.textContent = message;
    region.classList.add('show');
    clearTimeout(region._timer);
    region._timer = setTimeout(() => region.classList.remove('show'), 2600);
  }

  /* ============================================================
     PREVIEW RENDERING
     ============================================================ */
  function renderPreviews() {
    Object.keys(SITE_DATA).forEach(key => {
      const preview = document.getElementById('preview-' + key);
      if (!preview) return;
      const pre = preview.querySelector('pre');
      if (!pre) return;
      const lines = SITE_DATA[key].content.split('\n').slice(0, 30);
      const html = lines.map(line => {
        const trimmed = line.trim();
        if (trimmed.startsWith('#')) {
          return '<span class="hl">' + escapeHtml(line) + '</span>';
        }
        if (trimmed.match(/^(You are|Build|Create|Transform|Persuasion)/)) {
          return '<span class="hl2">' + escapeHtml(line) + '</span>';
        }
        return escapeHtml(line);
      }).join('\n');
      pre.innerHTML = html + '\n<span class="hl">...</span>';
    });
  }

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /* ============================================================
     COPY TO CLIPBOARD
     ============================================================ */
  async function copyPrompt(key) {
    const data = SITE_DATA[key];
    if (!data) return;
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(data.content);
      } else {
        const ta = document.createElement('textarea');
        ta.value = data.content;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      }
      showToast('پرامپت با موفقیت کپی شد');
    } catch (err) {
      showToast('کپی انجام نشد — لطفاً دستی امتحان کنید');
    }
  }

  /* ============================================================
     DOWNLOAD AS TXT
     ============================================================ */
  function downloadPrompt(key) {
    const data = SITE_DATA[key];
    if (!data) return;
    const blob = new Blob([data.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = data.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    showToast('فایل دانلود شد');
  }

  /* ============================================================
     TOGGLE PREVIEW
     ============================================================ */
  function initPreviewToggles() {
    document.querySelectorAll('.btn-toggle-preview').forEach(btn => {
      btn.addEventListener('click', () => {
        const targetId = btn.getAttribute('data-target');
        const preview = document.getElementById(targetId);
        if (!preview) return;
        const isExpanded = preview.classList.toggle('expanded');
        btn.setAttribute('aria-expanded', String(isExpanded));
        const icon = btn.querySelector('i');
        if (icon) {
          icon.className = isExpanded
            ? 'fa-solid fa-eye-slash'
            : 'fa-regular fa-eye';
        }
        btn.lastChild.textContent = isExpanded
          ? ' بستن پیش‌نمایش'
          : ' پیش‌نمایش کامل';
      });
    });
  }

  /* ============================================================
     BIND COPY & DOWNLOAD BUTTONS
     ============================================================ */
  function initActionButtons() {
    document.querySelectorAll('[data-copy]').forEach(btn => {
      btn.addEventListener('click', () => copyPrompt(btn.getAttribute('data-copy')));
    });
    document.querySelectorAll('[data-download]').forEach(btn => {
      btn.addEventListener('click', () => downloadPrompt(btn.getAttribute('data-download')));
    });
  }

  /* ============================================================
     FAQ ACCORDION
     ============================================================ */
  function initFAQ() {
    document.querySelectorAll('.faq-item').forEach(item => {
      const btn = item.querySelector('.faq-question');
      if (!btn) return;
      btn.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        document.querySelectorAll('.faq-item.open').forEach(other => {
          if (other !== item) {
            other.classList.remove('open');
            const otherBtn = other.querySelector('.faq-question');
            if (otherBtn) otherBtn.setAttribute('aria-expanded', 'false');
          }
        });
        item.classList.toggle('open', !isOpen);
        btn.setAttribute('aria-expanded', String(!isOpen));
      });
    });
  }

  /* ============================================================
     SCROLL REVEAL
     ============================================================ */
  function initReveal() {
    if (!('IntersectionObserver' in window)) {
      document.querySelectorAll('[data-reveal]').forEach(el => el.classList.add('revealed'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });

    document.querySelectorAll('[data-reveal]').forEach(el => observer.observe(el));
  }

  /* ============================================================
     HEADER SCROLL STATE + PROGRESS BAR + BACK TO TOP
     ============================================================ */
  function initScrollEffects() {
    const header = document.getElementById('siteHeader');
    const progress = document.getElementById('scrollProgress');
    const backToTop = document.getElementById('backToTop');
    let ticking = false;

    function update() {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const pct = docHeight > 0 ? (scrollY / docHeight) * 100 : 0;

      if (header) header.classList.toggle('scrolled', scrollY > 20);
      if (progress) {
        progress.style.width = pct + '%';
        progress.setAttribute('aria-valuenow', String(Math.round(pct)));
      }
      if (backToTop) backToTop.classList.toggle('visible', scrollY > 600);

      ticking = false;
    }

    window.addEventListener('scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(update);
        ticking = true;
      }
    }, { passive: true });

    update();

    if (backToTop) {
      backToTop.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  }

  /* ============================================================
     NAV ACTIVE STATE (SCROLL SPY)
     ============================================================ */
  function initScrollSpy() {
    const links = document.querySelectorAll('.nav-desktop a');
    if (!links.length) return;
    const sections = Array.from(links)
      .map(link => {
        const id = link.getAttribute('href');
        if (!id || !id.startsWith('#')) return null;
        return document.querySelector(id);
      })
      .filter(Boolean);

    if (!sections.length) return;

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          links.forEach(link => {
            link.classList.toggle('active', link.getAttribute('href') === '#' + entry.target.id);
          });
        }
      });
    }, { threshold: 0.3, rootMargin: '-20% 0px -60% 0px' });

    sections.forEach(s => observer.observe(s));
  }

  /* ============================================================
     MAGNETIC CTA (desktop only)
     ============================================================ */
  function initMagnetic() {
    const fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    if (!fine) return;
    document.querySelectorAll('.magnetic').forEach(el => {
      el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        el.style.transform = `translate(${x * 0.15}px, ${y * 0.15}px)`;
      });
      el.addEventListener('mouseleave', () => {
        el.style.transform = '';
      });
    });
  }

  /* ============================================================
     FOOTER YEAR
     ============================================================ */
  function initYear() {
    const yearEl = document.getElementById('year');
    if (!yearEl) return;
    const d = new Date();
    const fa = new Intl.DateTimeFormat('fa-IR', { year: 'numeric' }).format(d);
    yearEl.textContent = fa;
  }

  /* ============================================================
     INIT
     ============================================================ */
  document.addEventListener('DOMContentLoaded', () => {
    renderPreviews();
    initPreviewToggles();
    initActionButtons();
    initFAQ();
    initReveal();
    initScrollEffects();
    initScrollSpy();
    initMagnetic();
    initYear();
  });

})();