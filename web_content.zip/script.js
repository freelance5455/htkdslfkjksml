"use strict";

const $ = id => document.getElementById(id);
const state = {
  exchange: "binance", pair: "BTCUSDT", candles: {},
  socket: null, chart: null, series: null, busy: false,
  generation: 0, reconnectTimer: null, restTimer: null
};
const INTERVALS = ["3m", "5m", "15m"];
const SHARK = {
  // IMPORTANT: Replace these placeholders only with values from Shark's official docs.
  // A browser app cannot bypass CORS or private authentication requirements.
  restBase: "",
  websocketUrl: "",
  // Adapt these two functions to the exact official API contract if required.
  buildKlineUrl(pair, interval) {
    if (!this.restBase) throw new Error("Shark REST base URL is not configured. Add the verified official endpoint in script.js.");
    const url = new URL(this.restBase.replace(/\\/$/, "") + "/v1/market/klines");
    url.searchParams.set("priceType", "MARK_PRICE");
    url.searchParams.set("symbol", pair);
    url.searchParams.set("interval", interval);
    url.searchParams.set("limit", "300");
    return url.toString();
  },
  buildKlineRequest() {
    return { method: "GET", headers: { "Accept": "application/json" } };
  },
  // If Shark requires POST/body instead, change buildKlineUrl/buildKlineRequest using official docs.
  subscribeMessage(pair) {
    // Placeholder subscription format. Must be replaced with Shark's documented message.
    return null;
  }
};

function fmt(n) {
  if (!Number.isFinite(n)) return "--";
  return n.toLocaleString("en-IN", { maximumFractionDigits: 8 });
}
function ist(ms = Date.now()) {
  return new Date(ms).toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata", day: "2-digit", month: "short",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false
  }) + " IST";
}
function setConnection(text) { $("connection").textContent = text; }
function setSignal(type, reason) {
  $("signal").textContent = type;
  $("signal").className = "signal " + (type === "BUY" ? "buy" : type === "SELL" ? "sell" : "wait");
  $("reason").textContent = reason;
  $("signalTime").textContent = "Updated: " + ist();
}
function clearLevels() {
  ["entry", "sl", "t1", "t2", "t3", "rr"].forEach(id => { $(id).textContent = "--"; });
}
function initChart() {
  if (!window.LightweightCharts) {
    $("chart").textContent = "Chart library did not load. Check internet connection.";
    return;
  }
  const el = $("chart");
  state.chart = LightweightCharts.createChart(el, {
    width: el.clientWidth, height: 320,
    layout: { background: { color: "#111f31" }, textColor: "#dbe8f8" },
    grid: { vertLines: { color: "#263a52" }, horzLines: { color: "#263a52" } },
    timeScale: { timeVisible: true, secondsVisible: false },
    rightPriceScale: { borderColor: "#304763" }
  });
  state.series = state.chart.addSeries(LightweightCharts.CandlestickSeries, {
    upColor: "#38e39a", downColor: "#ff6277", borderVisible: false,
    wickUpColor: "#38e39a", wickDownColor: "#ff6277"
  });
  window.addEventListener("resize", () => state.chart && state.chart.applyOptions({ width: el.clientWidth }));
}
function candleFromArray(k, timestampIsMs = true) {
  const t = Number(k[0]);
  return { time: Math.floor(timestampIsMs ? t / 1000 : t), open:+k[1], high:+k[2], low:+k[3], close:+k[4], volume:+(k[5] || 0), closed:true };
}
function normalizeBinance(rows) {
  if (!Array.isArray(rows)) throw new Error("Unexpected Binance kline response.");
  return rows.map(k => ({
    time: Math.floor(Number(k[0]) / 1000), open:+k[1], high:+k[2], low:+k[3],
    close:+k[4], volume:+k[5], closed: Date.now() >= Number(k[6])
  })).filter(validCandle);
}
function normalizeShark(response) {
  let rows = response;
  if (response && !Array.isArray(response)) rows = response.data ?? response.result ?? response.klines ?? response.rows;
  if (rows && !Array.isArray(rows) && Array.isArray(rows.list)) rows = rows.list;
  if (!Array.isArray(rows)) throw new Error("Unknown Shark kline response. Check the official response JSON.");
  return rows.map(k => {
    if (Array.isArray(k)) {
      const t = Number(k[0]);
      return { time:Math.floor(t > 1e12 ? t/1000 : t), open:+k[1], high:+k[2], low:+k[3], close:+k[4], volume:+(k[5]||0), closed:true };
    }
    const rawTime = Number(k.time ?? k.openTime ?? k.startTime ?? k.timestamp ?? k.t);
    return {
      time:Math.floor(rawTime > 1e12 ? rawTime/1000 : rawTime),
      open:Number(k.open ?? k.o), high:Number(k.high ?? k.h), low:Number(k.low ?? k.l),
      close:Number(k.close ?? k.c), volume:Number(k.volume ?? k.v ?? 0),
      closed: k.closed !== undefined ? Boolean(k.closed) : (k.confirm !== undefined ? Boolean(k.confirm) : true)
    };
  }).filter(validCandle);
}
function validCandle(c) {
  return c.time > 0 && [c.open,c.high,c.low,c.close,c.volume].every(Number.isFinite) && c.high >= c.low;
}
async function fetchKlines(pair, interval, exchange) {
  if (exchange === "binance") {
    const url = "https://data-api.binance.vision/api/v3/klines?symbol=" +
      encodeURIComponent(pair.toUpperCase()) + "&interval=" + encodeURIComponent(interval) + "&limit=300";
    const response = await fetch(url);
    if (!response.ok) throw new Error(`Binance ${pair} ${interval}: HTTP ${response.status}`);
    return normalizeBinance(await response.json());
  }
  const url = SHARK.buildKlineUrl(pair, interval);
  const response = await fetch(url, SHARK.buildKlineRequest());
  if (!response.ok) throw new Error(`Shark ${interval}: HTTP ${response.status}. Verify endpoint, CORS and request method.`);
  return normalizeShark(await response.json());
}
function ema(values, period) {
  if (values.length < period) return null;
  const alpha = 2/(period+1);
  let result = values.slice(0,period).reduce((a,b)=>a+b,0)/period;
  for (let i=period;i<values.length;i++) result=values[i]*alpha+result*(1-alpha);
  return result;
}
function rsi(values, period=14) {
  if (values.length <= period) return null;
  let gains=0, losses=0;
  for(let i=1;i<=period;i++){const d=values[i]-values[i-1];if(d>=0)gains+=d;else losses-=d;}
  let ag=gains/period, al=losses/period;
  for(let i=period+1;i<values.length;i++){const d=values[i]-values[i-1];ag=(ag*(period-1)+Math.max(0,d))/period;al=(al*(period-1)+Math.max(0,-d))/period;}
  if(al===0)return 100;
  return 100-100/(1+ag/al);
}
function macd(values) {
  if(values.length<35)return null;
  const calcEmaSeries=(period)=>{
    const a=2/(period+1);let e=values[0];const out=[];
    for(const v of values){e=v*a+e*(1-a);out.push(e);}return out;
  };
  const e12=calcEmaSeries(12), e26=calcEmaSeries(26);
  const line=values.map((_,i)=>e12[i]-e26[i]);
  return {line:line.at(-1), signal:ema(line,9)};
}
function analyze(candles) {
  const closed=(candles||[]).filter(c=>c.closed).sort((a,b)=>a.time-b.time);
  if(closed.length<50)return {trend:"WAIT",reason:`Need 50 completed candles (have ${closed.length}).`};
  const closes=closed.map(c=>c.close), volumes=closed.map(c=>c.volume);
  const e9=ema(closes,9),e21=ema(closes,21),e34=ema(closes,34),r=rsi(closes,14),m=macd(closes);
  if([e9,e21,e34,r].some(v=>v===null)||!m||m.signal===null)return {trend:"WAIT",reason:"Indicators are warming up."};
  const last=closed.at(-1), recent=volumes.slice(-21,-1);
  const avgVol=recent.reduce((a,b)=>a+b,0)/(recent.length||1);
  const volumeOK=avgVol>0 && last.volume>=avgVol*0.8;
  const bullish=e9>e21&&e21>e34&&last.close>e9&&r>=50&&r<=70&&m.line>m.signal&&volumeOK;
  const bearish=e9<e21&&e21<e34&&last.close<e9&&r<=50&&r>=30&&m.line<m.signal&&volumeOK;
  return {trend:bullish?"BUY":bearish?"SELL":"WAIT",close:last.close,ema9:e9,ema21:e21,ema34:e34,rsi:r,macd:m.line,macdSignal:m.signal,volumeOK,last,
    reason:bullish?"EMA, RSI, MACD and volume align bullish.":bearish?"EMA, RSI, MACD and volume align bearish.":"Indicators do not agree strongly enough."};
}
function setLevels(direction, entry, stop) {
  if(!Number.isFinite(entry)||!Number.isFinite(stop)){clearLevels();return;}
  const risk=Math.abs(entry-stop); if(risk<=0){clearLevels();return;}
  const sign=direction==="BUY"?1:-1;
  $("entry").textContent=fmt(entry);$("sl").textContent=fmt(stop);
  $("t1").textContent=fmt(entry+sign*risk);$("t2").textContent=fmt(entry+sign*risk*2);$("t3").textContent=fmt(entry+sign*risk*3);
  $("rr").textContent="1:1 / 1:2 / 1:3";
}
function updateExtremes(candles) {
  if(!candles.length)return;
  const high=candles.reduce((a,b)=>b.high>a.high?b:a), low=candles.reduce((a,b)=>b.low<a.low?b:a);
  $("high").textContent=fmt(high.high);$("low").textContent=fmt(low.low);
  $("highTime").textContent=ist(high.time*1000);$("lowTime").textContent=ist(low.time*1000);
}
function updateSignal(results) {
  for(const tf of INTERVALS) {
    const r=results[tf];
    $("tf"+tf.replace("m","")).textContent=r.trend+" — "+r.reason;
  }
  $("indicators").replaceChildren();
  for(const tf of INTERVALS) {
    const r=results[tf], row=document.createElement("div");
    row.textContent=`${tf}: ${r.trend}; RSI: ${Number.isFinite(r.rsi)?r.rsi.toFixed(2):"--"}; EMA 9/21/34: ${[r.ema9,r.ema21,r.ema34].every(Number.isFinite)?[r.ema9,r.ema21,r.ema34].map(fmt).join(" / "):"--"}; Volume: ${r.volumeOK?"confirmed":"not confirmed"}`;
    $("indicators").appendChild(row);
  }
  const a3=results["3m"],a5=results["5m"],a15=results["15m"];
  let final="WAIT",reason="Timeframes do not agree; wait for confirmation.";
  if(a3.trend==="BUY"&&a5.trend==="BUY"&&a15.trend==="BUY"){final="BUY";reason="3m, 5m and 15m indicators agree bullish.";}
  else if(a3.trend==="SELL"&&a5.trend==="SELL"&&a15.trend==="SELL"){final="SELL";reason="3m, 5m and 15m indicators agree bearish.";}
  setSignal(final,reason);
  const base=a5.last;
  if(final==="BUY"&&base)setLevels("BUY",base.close,base.low);
  else if(final==="SELL"&&base)setLevels("SELL",base.close,base.high);
  else clearLevels();
}
function updatePrice(candle, source) {
  if(!candle)return;
  $("price").textContent=fmt(candle.close);
  $("priceTime").textContent="Live: "+ist();
  $("priceSource").textContent=source;
}
async function refreshAll() {
  if(state.busy)return;
  state.busy=true;const generation=++state.generation;
  state.exchange=$("exchange").value;state.pair=$("pair").value;
  try {
    setConnection("Loading "+state.exchange+" market data…");
    const entries=await Promise.all(INTERVALS.map(async tf=>[tf,await fetchKlines(state.pair,tf,state.exchange)]));
    if(generation!==state.generation)return;
    const results={};
    for(const [tf,candles] of entries){state.candles[tf]=candles;results[tf]=analyze(candles);}
    const main=state.candles["5m"],last=main.at(-1);
    if(last){updatePrice(last,state.exchange.toUpperCase()+" REST");updateExtremes(main);if(state.series)state.series.setData(main.map(c=>({time:c.time,open:c.open,high:c.high,low:c.low,close:c.close}))); }
    updateSignal(results);
    setConnection(state.exchange==="binance"?"Binance data loaded":"Shark REST data loaded (live socket status below)");
  } catch(err) {
    setConnection("Connection error");
    setSignal("WAIT",err.message);
    console.error(err);
  } finally {state.busy=false;}
}
function stopSocket() {
  if(state.reconnectTimer)clearTimeout(state.reconnectTimer);
  state.reconnectTimer=null;
  if(state.socket){state.socket.onclose=null;try{state.socket.close();}catch(_){}state.socket=null;}
}
function mergeLiveCandle(tf,candle) {
  const list=state.candles[tf]||[];
  const idx=list.findIndex(c=>c.time===candle.time);
  if(idx>=0)list[idx]=candle;else list.push(candle);
  list.sort((a,b)=>a.time-b.time);
  while(list.length>300)list.shift();
  state.candles[tf]=list;
}
function connectBinanceLive() {
  stopSocket();
  if(state.exchange!=="binance")return;
  const symbol=state.pair.toLowerCase();
  const ws=new WebSocket("wss://data-stream.binance.vision:443/ws/"+symbol+"@kline_5m");
  state.socket=ws;
  ws.onopen=()=>setConnection("Binance WebSocket connected");
  ws.onmessage=event=>{
    try{
      const msg=JSON.parse(event.data);if(!msg.k)return;
      const k=msg.k,c={time:Math.floor(k.t/1000),open:+k.o,high:+k.h,low:+k.l,close:+k.c,volume:+k.v,closed:Boolean(k.x)};
      mergeLiveCandle("5m",c);updatePrice(c,"BINANCE WebSocket");
      if(state.series)state.series.update({time:c.time,open:c.open,high:c.high,low:c.low,close:c.close});
      updateExtremes(state.candles["5m"]);
      updateSignal({"3m":analyze(state.candles["3m"]||[]),"5m":analyze(state.candles["5m"]||[]),"15m":analyze(state.candles["15m"]||[])});
    }catch(err){console.error("Binance live message:",err);}
  };
  ws.onerror=()=>setConnection("Binance WebSocket error; checking REST data");
  ws.onclose=()=>{if(state.socket===ws&&state.exchange==="binance"){setConnection("Live disconnected; retrying…");state.reconnectTimer=setTimeout(()=>{if(state.exchange==="binance")connectBinanceLive();},5000);}};
}
function connectSharkLive() {
  stopSocket();
  if(state.exchange!=="shark")return;
  if(!SHARK.websocketUrl){setConnection("Shark REST not configured / WebSocket URL missing");return;}
  const ws=new WebSocket(SHARK.websocketUrl);state.socket=ws;
  ws.onopen=()=>{
    setConnection("Shark WebSocket connected; subscription format must be verified");
    const msg=SHARK.subscribeMessage(state.pair);
    if(msg)ws.send(JSON.stringify(msg));
  };
  ws.onmessage=event=>{
    try{
      const msg=JSON.parse(event.data);
      // Generic parsing is intentionally conservative. Map fields to official format here.
      const k=msg.kline??msg.data?.kline??msg.data??msg;
      const rawTime=Number(k.time??k.openTime??k.startTime??k.t??k.timestamp);
      const candle={time:Math.floor(rawTime>1e12?rawTime/1000:rawTime),open:Number(k.open??k.o),high:Number(k.high??k.h),low:Number(k.low??k.l),close:Number(k.close??k.c),volume:Number(k.volume??k.v??0),closed:Boolean(k.closed??k.confirm??false)};
      if(!validCandle(candle)){console.warn("Unmapped Shark WebSocket message",msg);return;}
      const tf=k.interval??k.i??"5m";
      if(INTERVALS.includes(tf))mergeLiveCandle(tf,candle);else mergeLiveCandle("5m",candle);
      updatePrice(candle,"SHARK WebSocket");
      if(state.series&&(!tf||tf==="5m"))state.series.update({time:candle.time,open:candle.open,high:candle.high,low:candle.low,close:candle.close});
      updateSignal({"3m":analyze(state.candles["3m"]||[]),"5m":analyze(state.candles["5m"]||[]),"15m":analyze(state.candles["15m"]||[])});
    }catch(err){console.error("Shark live parse error:",err);}
  };
  ws.onerror=()=>setConnection("Shark WebSocket error; verify URL, CORS/auth and subscription docs");
  ws.onclose=()=>{if(state.socket===ws&&state.exchange==="shark")setConnection("Shark WebSocket disconnected");};
}
function connectLive() {
  if(state.exchange==="binance")connectBinanceLive();
  else connectSharkLive();
}
async function changeMarket() {
  stopSocket();
  state.candles={};
  clearLevels();
  await refreshAll();
  connectLive();
}
$("refresh").addEventListener("click",changeMarket);
$("exchange").addEventListener("change",changeMarket);
$("pair").addEventListener("change",changeMarket);
initChart();
refreshAll().then(connectLive);
// REST refresh every 60 seconds; do not repeatedly close/reopen a healthy socket.
setInterval(()=>{if(!state.busy){refreshAll();}},60000);
