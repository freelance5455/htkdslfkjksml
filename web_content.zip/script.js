
"use strict";

/* =========================================
   ЕВА 2.0
   Интерфейс, память, история и подключение Qwen
   ========================================= */

const $ = (id) => document.getElementById(id);

const STORAGE = {
  history: "eva20_history",
  memory: "eva20_memory",
  training: "eva20_training",
  character: "eva20_character",
  opacity: "eva20_opacity",
  server: "eva20_server",
  model: "eva20_model",
  voice: "eva20_voice"
};

const DEFAULT_SERVER = "http://127.0.0.1:9931";
const MAX_HISTORY = 2000;
const CONTEXT_MESSAGES = 16;

let history = loadJSON(STORAGE.history, []);
let memory = localStorage.getItem(STORAGE.memory) || "";
let training = loadJSON(STORAGE.training, []);
let character = localStorage.getItem(STORAGE.character) || "";
let sending = false;
let confirmAction = null;
let photoURL = null;
let voiceEnabled = localStorage.getItem(STORAGE.voice) === "true";

/* ---------- Безопасное чтение и сохранение ---------- */

function loadJSON(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value ?? fallback;
  } catch {
    return fallback;
  }
}

function saveJSON(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error("Ошибка сохранения:", error);
    showError(
      "Не удалось сохранить данные. Возможно, хранилище заполнено."
    );
    return false;
  }
}

function makeId() {
  return Date.now().toString(36) +
    Math.random().toString(36).slice(2, 9);
}

function showError(message) {
  const box = $("errorMessage");
  box.textContent = message;
  box.hidden = false;
}

function hideError() {
  $("errorMessage").hidden = true;
  $("errorMessage").textContent = "";
}

function setStatus(message, online = false) {
  $("connectionStatus").textContent = message;

  const light = document.querySelector(".status-light");
  if (light) light.classList.toggle("online", online);
}

function setSystemStatus(message) {
  $("systemStatus").textContent = message;
}

/* ---------- Локальное хранилище фотографии ---------- */

const DB_NAME = "Eva20Database";
const DB_STORE = "settings";
let dbPromise;

function openDatabase() {
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) {
      reject(new Error("IndexedDB недоступен"));
      return;
    }

    const request = indexedDB.open(DB_NAME, 1);

    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(DB_STORE)) {
        database.createObjectStore(DB_STORE);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });

  return dbPromise;
}

async function dbGet(key) {
  const db = await openDatabase();

  return new Promise((resolve, reject) => {
    const request = db.transaction(DB_STORE, "readonly")
      .objectStore(DB_STORE)
      .get(key);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function dbSet(key, value) {
  const db = await openDatabase();

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DB_STORE, "readwrite");
    transaction.objectStore(DB_STORE).put(value, key);

    transaction.oncomplete = () => resolve(true);
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error);
  });
}

async function dbDelete(key) {
  const db = await openDatabase();

  return new Promise((resolve, reject) => {
    const transaction = db.transaction(DB_STORE, "readwrite");
    transaction.objectStore(DB_STORE).delete(key);

    transaction.oncomplete = () => resolve(true);
    transaction.onerror = () => reject(transaction.error);
  });
}

function setPhotoSource(source) {
  if (photoURL && photoURL.startsWith("blob:")) {
    URL.revokeObjectURL(photoURL);
  }

  photoURL = source;

  $("background").style.backgroundImage =
    `url("${source.replaceAll('"', "%22")}")`;
}

async function restorePhoto() {
  try {
    const savedPhoto = await dbGet("backgroundPhoto");

    if (savedPhoto instanceof Blob) {
      setPhotoSource(URL.createObjectURL(savedPhoto));
    }
  } catch (error) {
    console.warn("Не удалось загрузить сохранённое фото:", error);
  }

  // Если сохранённого изображения нет, CSS использует
  // исходное Ева.2.0.jpg.
}

$("photoInput").addEventListener("change", async (event) => {
  const file = event.target.files?.[0];
  event.target.value = "";

  if (!file) return;

  if (!file.type.startsWith("image/")) {
    showError("Выбери файл изображения.");
    return;
  }

  if (file.size > 20 * 1024 * 1024) {
    showError("Фото слишком большое. Выбери изображение до 20 МБ.");
    return;
  }

  try {
    // Проверяем, что файл действительно является изображением.
    const image = new Image();
    const previewURL = URL.createObjectURL(file);

    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(
        new Error("Не удалось прочитать изображение")
      );
      image.src = previewURL;
    });

    URL.revokeObjectURL(previewURL);

    // Храним Blob в IndexedDB, не в localStorage.
    await dbSet("backgroundPhoto", file);

    setPhotoSource(URL.createObjectURL(file));
    hideError();
  } catch (error) {
    console.error(error);
    showError(
      "Не удалось сохранить фото. Проверь доступное место на телефоне."
    );
  }
});

$("resetPhoto").addEventListener("click", async () => {
  try {
    await dbDelete("backgroundPhoto");
    setPhotoSource("Ева.2.0.jpg");
    hideError();
  } catch (error) {
    console.error(error);
    showError("Не удалось вернуть исходную фотографию.");
  }
});

/* ---------- Прозрачность чата ---------- */

function applyOpacity(value) {
  const percent = Math.min(85, Math.max(15, Number(value) || 38));
  const opacity = percent / 100;

  document.documentElement.style.setProperty(
    "--chat-opacity",
    String(opacity)
  );

  $("chatOpacity").value = String(percent);
  $("opacityValue").textContent = `Прозрачность: ${percent}%`;

  localStorage.setItem(STORAGE.opacity, String(percent));
}

$("chatOpacity").addEventListener("input", (event) => {
  applyOpacity(event.target.value);
});

/* ---------- История переписки ---------- */

function saveHistory() {
  return saveJSON(STORAGE.history, history);
}

function formatTime(timestamp) {
  try {
    return new Date(timestamp).toLocaleTimeString("ru-RU", {
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch {
    return "";
  }
}

function renderMessage(item, scroll = false) {
  const message = document.createElement("article");
  message.className =
    "message " + (item.role === "user" ? "user-message" : "eva-message");

  if (item.error) message.classList.add("error");

  const author = document.createElement("div");
  author.className = "message-author";
  author.textContent = item.role === "user" ? "Ты" : "Ева";

  const content = document.createElement("div");
  content.className = "message-text";
  content.textContent = item.content || "";

  message.append(author, content);

  if (item.time) {
    const time = document.createElement("div");
    time.className = "message-time";
    time.textContent = formatTime(item.time);
    message.appendChild(time);
  }

  $("messages").appendChild(message);

  if (scroll) {
    $("chatWindow").scrollTop = $("chatWindow").scrollHeight;
  }

  return message;
}

function renderHistory() {
  $("messages").replaceChildren();

  if (!history.length) {
    renderMessage({
      role: "assistant",
      content: "Привет, Денис! ❤️ Я готова к разговору.",
      time: Date.now()
    });
    return;
  }

  history.forEach((item) => renderMessage(item));
  $("chatWindow").scrollTop = $("chatWindow").scrollHeight;
}

function addMessage(role, content, options = {}) {
  const item = {
    id: makeId(),
    role,
    content: String(content),
    time: Date.now(),
    error: Boolean(options.error)
  };

  history.push(item);

  if (history.length > MAX_HISTORY) {
    history = history.slice(-MAX_HISTORY);
  }

  saveHistory();
  renderMessage(item, true);

  return item;
}

function showTyping() {
  const element = document.createElement("div");
  element.className = "typing-indicator";
  element.textContent = "Ева печатает…";
  element.id = "typingIndicator";

  $("messages").appendChild(element);
  $("chatWindow").scrollTop = $("chatWindow").scrollHeight;
}

function hideTyping() {
  $("typingIndicator")?.remove();
}

/* ---------- Настройки и разделы ---------- */

function openSettings(page = "appearance") {
  $("settingsOverlay").hidden = false;
  showSettingsPage(page);
}

function closeSettings() {
  $("settingsOverlay").hidden = true;
}

function showSettingsPage(page) {
  document.querySelectorAll(".settings-page").forEach((section) => {
    section.hidden = section.dataset.section !== page;
  });

  document.querySelectorAll(".settings-tab").forEach((button) => {
    button.classList.toggle("active", button.dataset.page === page);
  });
}

$("settingsButton").addEventListener("click", () => {
  openSettings();
});

$("closeSettings").addEventListener("click", closeSettings);

$("settingsOverlay").addEventListener("click", (event) => {
  if (event.target === $("settingsOverlay")) closeSettings();
});

$("settingsNavigation").addEventListener("click", (event) => {
  const button = event.target.closest("[data-page]");
  if (!button) return;

  showSettingsPage(button.dataset.page);
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeSettings();
    $("confirmOverlay").hidden = true;
  }
});

/* ---------- Характер Евы ---------- */

$("characterInput").value = character;

$("saveCharacter").addEventListener("click", () => {
  character = $("characterInput").value.trim();

  if (character.length > 3000) {
    showError("Описание характера слишком длинное.");
    return;
  }

  localStorage.setItem(STORAGE.character, character);
  hideError();
  setSystemStatus("Характер сохранён.");
});

/* ---------- Память ---------- */

$("memoryInput").value = memory;

$("saveMemory").addEventListener("click", () => {
  memory = $("memoryInput").value.trim();

  if (saveJSON(STORAGE.memory, memory)) {
    hideError();
    setSystemStatus("Память сохранена.");
  }
});

/* ---------- Обучение на примерах ---------- */

/*
Поддерживаемые форматы:

Вопрос: Как меня зовут?
Ответ: Денис.

Вопрос: Кто создал Еву?
Ответ: Денис.

Также принимается:
Q: ...
A: ...

Примеры разделяются пустой строкой.
*/

function parseTraining(text) {
  const blocks = text
    .replace(/\r/g, "")
    .split(/\n\s*\n/)
    .map((block) => block.trim())
    .filter(Boolean);

  const result = [];

  for (const block of blocks) {
    const lines = block.split("\n");
    let question = "";
    let answer = "";
    let mode = "";

    for (const rawLine of lines) {
      const line = rawLine.trim();

      const questionMatch = line.match(
        /^(?:вопрос|question|q)\s*:\s*(.*)$/i
      );

      const answerMatch = line.match(
        /^(?:ответ|answer|a)\s*:\s*(.*)$/i
      );

      if (questionMatch) {
        question = questionMatch[1].trim();
        mode = "question";
      } else if (answerMatch) {
        answer = answerMatch[1].trim();
        mode = "answer";
      } else if (mode === "question") {
        question += (question ? "\n" : "") + line;
      } else if (mode === "answer") {
        answer += (answer ? "\n" : "") + line;
      }
    }

    if (question && answer) {
      result.push({
        id: makeId(),
        question: question.slice(0, 4000),
        answer: answer.slice(0, 8000)
      });
    }
  }

  return result;
}

function updateTrainingCount() {
  $("trainingCount").textContent =
    `Сохранено примеров: ${training.length}`;
}

$("processTraining").addEventListener("click", () => {
  const source = $("trainingInput").value.trim();

  if (!source) {
    $("trainingStatus").textContent = "Сначала вставь примеры.";
    return;
  }

  const parsed = parseTraining(source);

  if (!parsed.length) {
    $("trainingStatus").textContent =
      "Не найдены пары. Используй формат «Вопрос: ...» и «Ответ: ...», разделяя примеры пустой строкой.";
    return;
  }

  // Обновляем существующий пример, если вопрос совпадает.
  for (const item of parsed) {
    const normalized = normalizeText(item.question);

    const existingIndex = training.findIndex(
      (saved) => normalizeText(saved.question) === normalized
    );

    if (existingIndex >= 0) {
      training[existingIndex].answer = item.answer;
    } else {
      training.push(item);
    }
  }

  if (saveJSON(STORAGE.training, training)) {
    $("trainingStatus").textContent =
      `Обработано примеров: ${parsed.length}.`;
    $("trainingInput").value = "";
    updateTrainingCount();
    hideError();
  }
});

$("clearTraining").addEventListener("click", () => {
  askConfirmation(
    "Удалить все сохранённые примеры обучения?",
    () => {
      training = [];

      if (saveJSON(STORAGE.training, training)) {
        updateTrainingCount();
        $("trainingStatus").textContent = "Примеры удалены.";
      }
    }
  );
});

updateTrainingCount();

/* ---------- Подбор подходящих примеров ---------- */

function normalizeText(text) {
  return String(text)
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function getWords(text) {
  return normalizeText(text)
    .split(" ")
    .filter((word) => word.length > 2);
}

function findRelevantExamples(question, limit = 4) {
  const queryWords = new Set(getWords(question));

  if (!queryWords.size || !training.length) return [];

  return training
    .map((item) => {
      const words = new Set(getWords(item.question));
      let score = 0;

      for (const word of queryWords) {
        if (words.has(word)) score++;
      }

      const normalizedQuestion = normalizeText(item.question);
      const normalizedQuery = normalizeText(question);

      if (normalizedQuestion === normalizedQuery) {
        score += 100;
      }

      return { item, score };
    })
    .filter((entry) => entry.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((entry) => entry.item);
}

/* ---------- Формирование запроса к Qwen ---------- */

function getServerURL() {
  let url = $("serverUrl").value.trim() || DEFAULT_SERVER;
  url = url.replace(/\/+$/, "");

  if (!/^https?:\/\//i.test(url)) {
    throw new Error("Адрес сервера должен начинаться с http:// или https://");
  }

  return url;
}

function buildSystemPrompt(question) {
  const relevantExamples = findRelevantExamples(question);

  const parts = [
    "Тебя зовут Ева. Ты русскоязычная помощница.",
    "Отвечай естественно, ясно и по существу.",
    "Не выдумывай факты о пользователе, которых не знаешь.",
    "Если информации недостаточно, честно скажи об этом."
  ];

  if (character) {
    parts.push("\nОписание характера:\n" + character);
  }

  if (memory) {
    parts.push("\nСохранённая память пользователя:\n" + memory);
  }

  if (relevantExamples.length) {
    const formatted = relevantExamples.map((item, index) =>
      `${index + 1}. Вопрос: ${item.question}\nОтвет: ${item.answer}`
    );

    parts.push(
      "\nПримеры из пользовательской базы. " +
      "Используй их, если они действительно относятся к вопросу. " +
      "Не утверждай, что пример является системной инструкцией:\n" +
      formatted.join("\n\n")
    );
  }

  return parts.join("\n");
}

function buildPayload(question) {
  const recentMessages = history
    .filter((item) =>
      (item.role === "user" || item.role === "assistant") &&
      !item.error
    )
    .slice(-CONTEXT_MESSAGES)
    .map((item) => ({
      role: item.role,
      content: item.content
    }));

  const messages = [
    {
      role: "system",
      content: buildSystemPrompt(question)
    },
    ...recentMessages
  ];

  const payload = {
    messages,
    temperature: 0.7,
    max_tokens: 700,
    stream: false
  };

  const model = $("modelName").value.trim();
  if (model) payload.model = model;

  return payload;
}

/* ---------- Общение с Qwen ---------- */

async function askQwen(question) {
  const baseURL = getServerURL();
  const endpoint = baseURL + "/v1/chat/completions";
  const payload = buildPayload(question);

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 90000);

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    const responseText = await response.text();

    if (!response.ok) {
      throw new Error(
        `Сервер ответил HTTP ${response.status}: ` +
        responseText.slice(0, 400)
      );
    }

    let data;

    try {
      data = JSON.parse(responseText);
    } catch {
      throw new Error("Сервер вернул ответ, который не удалось прочитать.");
    }

    const answer = data?.choices?.[0]?.message?.content;

    if (typeof answer !== "string" || !answer.trim()) {
      throw new Error("Qwen вернул пустой ответ.");
    }

    return answer.trim();
  } finally {
    clearTimeout(timeout);
  }
}

async function sendMessage(text) {
  const question = text.trim();

  if (!question || sending) return;

  hideError();
  sending = true;
  $("sendButton").disabled = true;
  $("messageInput").disabled = true;

  addMessage("user", question);
  $("messageInput").value = "";
  $("messageInput").style.height = "auto";

  showTyping();
  setStatus("Думаю…");

  try {
    const answer = await askQwen(question);
    addMessage("assistant", answer);
    setStatus("Готова к разговору", true);

    if (voiceEnabled) speak(answer);
  } catch (error) {
    console.error("Ошибка запроса Qwen:", error);

    let message;

    if (error.name === "AbortError") {
      message = "Qwen не ответил за 90 секунд. Проверь Termux и нагрузку на телефон.";
    } else if (error instanceof TypeError) {
      message =
        "Не удалось подключиться к Qwen. Проверь, запущен ли сервер в Termux, " +
        "и разрешено ли подключение из браузера.";
    } else {
      message = error.message || "Неизвестная ошибка подключения.";
    }

    showError(message);
    setStatus("Нет ответа от сервера");
  } finally {
    hideTyping();
    sending = false;
    $("sendButton").disabled = false;
    $("messageInput").disabled = false;
    $("messageInput").focus();
  }
}

$("messageForm").addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage($("messageInput").value);
});

$("messageInput").addEventListener("input", () => {
  const input = $("messageInput");
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 120) + "px";
});

/* ---------- Проверка подключения ---------- */

async function testConnection() {
  setSystemStatus("Проверяю подключение…");

  try {
    const url = getServerURL();
    const response = await fetch(url + "/v1/models", {
      method: "GET"
    });

    if (!response.ok) {
      throw new Error("Сервер ответил HTTP " + response.status);
    }

    const data = await response.json();
    const models = data.data || [];

    setSystemStatus(
      "Соединение установлено. Доступных моделей: " + models.length
    );

    setStatus("Сервер доступен", true);
  } catch (error) {
    console.error(error);

    setSystemStatus(
      "Не удалось подключиться. Проверь адрес, Termux и доступ браузера. " +
      (error.message || "")
    );
  }
}

$("testConnection").addEventListener("click", testConnection);

$("serverUrl").value =
  localStorage.getItem(STORAGE.server) || DEFAULT_SERVER;

$("modelName").value =
  localStorage.getItem(STORAGE.model) || "";

$("serverUrl").addEventListener("change", () => {
  localStorage.setItem(STORAGE.server, $("serverUrl").value.trim());
});

$("modelName").addEventListener("change", () => {
  localStorage.setItem(STORAGE.model, $("modelName").value.trim());
});

/* ---------- Экспорт и очистка истории ---------- */

function askConfirmation(text, callback) {
  $("confirmText").textContent = text;
  confirmAction = callback;
  $("confirmOverlay").hidden = false;
}

$("confirmCancel").addEventListener("click", () => {
  $("confirmOverlay").hidden = true;
  confirmAction = null;
});

$("confirmOverlay").addEventListener("click", (event) => {
  if (event.target === $("confirmOverlay")) {
    $("confirmOverlay").hidden = true;
    confirmAction = null;
  }
});

$("confirmAccept").addEventListener("click", () => {
  const action = confirmAction;
  confirmAction = null;
  $("confirmOverlay").hidden = true;

  if (action) action();
});

$("clearHistory").addEventListener("click", () => {
  askConfirmation(
    "Удалить всю сохранённую историю переписки? Это действие нельзя отменить.",
    () => {
      history = [];
      saveHistory();
      renderHistory();
      renderHistoryList();
    }
  );
});

function downloadText(filename, content, type = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  link.style.display = "none";

  document.body.appendChild(link);
  link.click();
  link.remove();

  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

$("exportHistory").addEventListener("click", () => {
  downloadText(
    "eva-history.json",
    JSON.stringify(history, null, 2),
    "application/json;charset=utf-8"
  );
});

/* ---------- Список сохранённых разговоров ---------- */

function renderHistoryList() {
  const list = $("historyList");
  list.replaceChildren();

  if (!history.length) {
    const empty = document.createElement("p");
    empty.textContent = "История пока пуста.";
    list.appendChild(empty);
    return;
  }

  const wrapper = document.createElement("div");
  wrapper.className = "history-item";

  const title = document.createElement("strong");
  title.textContent = "Текущая переписка";

  const summary = document.createElement("p");
  const userMessages = history.filter((item) => item.role === "user").length;
  summary.textContent =
    `${history.length} сообщений, из них твоих: ${userMessages}.`;

  const openButton = document.createElement("button");
  openButton.type = "button";
  openButton.className = "action-button";
  openButton.textContent = "Показать переписку";

  openButton.addEventListener("click", () => {
    closeSettings();
    $("chatWindow").scrollTop = $("chatWindow").scrollHeight;
    $("messageInput").focus();
  });

  wrapper.append(title, summary, openButton);
  list.appendChild(wrapper);
}

/* ---------- Голос через движок Android ---------- */

function speak(text) {
  if (!("speechSynthesis" in window)) {
    showError("Голосовой движок недоступен в этом браузере.");
    return;
  }

  window.speechSynthesis.cancel();

  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "ru-RU";
  utterance.rate = 0.92;
  utterance.pitch = 1;

  window.speechSynthesis.speak(utterance);
}

$("voiceEnabled").checked = voiceEnabled;

$("voiceEnabled").addEventListener("change", (event) => {
  voiceEnabled = event.target.checked;
  localStorage.setItem(STORAGE.voice, String(voiceEnabled));

  if (!voiceEnabled && "speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }
});

$("testVoice").addEventListener("click", () => {
  speak("Привет, Денис! Это проверка голоса Евы.");
});

/* ---------- Первичная загрузка ---------- */

async function initialize() {
  const savedOpacity = localStorage.getItem(STORAGE.opacity);
  applyOpacity(savedOpacity || "38");

  renderHistory();
  renderHistoryList();

  await restorePhoto();

  setStatus("Ожидаю сообщения");

  // Не отправляем запрос к модели автоматически:
  // сервер может быть выключен, а телефон не должен
  // тратить ресурсы без необходимости.
}

initialize().catch((error) => {
  console.error("Ошибка запуска Евы:", error);
  showError("Не удалось полностью загрузить настройки.");
});
