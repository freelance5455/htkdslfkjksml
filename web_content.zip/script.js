/* =====================================================
   MATH QUEST — SCRIPT COMPLETO
   Banco de questões + Bhaskara + XP + fases + progresso
===================================================== */

"use strict";

/* =====================================================
   CONFIGURAÇÃO
===================================================== */

const QUESTIONS_PER_LEVEL = 10;
const QUESTIONS_PER_FINAL = 10;
const XP_PER_CORRECT = 10;
const XP_PER_LEVEL = 100;

let selectedSubject = null;
let selectedDifficulty = "easy";
let currentQuestions = [];
let currentQuestionIndex = 0;
let currentScore = 0;
let currentLives = 3;
let currentXP = 0;
let currentStars = 0;
let quizMode = "level";
let currentLevelNumber = 1;
let hintUsed = false;
let removeUsed = false;
let explainUsed = false;
let answerLocked = false;
let practiceMode = false;


/* =====================================================
   DADOS DO JOGADOR
===================================================== */

const defaultPlayer = {
    name: "Aventureiro",
    level: 1,
    xp: 0,
    stars: 0,
    questions: 0,
    correct: 0,
    completedLevels: {},
    completedFinal: {},
    accuracy: 0
};

let player = loadPlayer();


/* =====================================================
   BANCO DE ASSUNTOS
===================================================== */

const subjects = [

    {
        id: "bhaskara",
        name: "Bhaskara",
        icon: "🧮",
        description: "Δ, x₁, x₂ e equações do 2º grau",
        learn: `
            <h2>🧮 Bhaskara</h2>
            <p>
                Para resolver uma equação do 2º grau,
                primeiro identifique os valores de a, b e c.
            </p>

            <div class="math-expression">
                ax² + bx + c = 0
            </div>

            <p>
                Depois calcule o discriminante:
            </p>

            <div class="math-expression">
                Δ = b² − 4ac
            </div>

            <p>
                Por fim, encontre as raízes:
            </p>

            <div class="math-expression">
                x₁ = (−b + √Δ) / 2a
                <br><br>
                x₂ = (−b − √Δ) / 2a
            </div>

            <p>
                Se Δ for positivo, existem duas raízes reais.
                Se Δ for zero, existe uma raiz real.
                Se Δ for negativo, não existem raízes reais.
            </p>
        `
    },

    {
        id: "basic",
        name: "Operações",
        icon: "➕",
        description: "Adição, subtração, multiplicação e divisão",
        learn: `
            <h2>➕ Operações básicas</h2>
            <p>
                As quatro operações fundamentais são
                adição, subtração, multiplicação e divisão.
            </p>

            <div class="math-expression">
                8 + 5 = 13
                <br>
                12 − 7 = 5
                <br>
                6 × 4 = 24
                <br>
                20 ÷ 5 = 4
            </div>
        `
    },

    {
        id: "fractions",
        name: "Frações",
        icon: "🍕",
        description: "Operações e simplificação de frações",
        learn: `
            <h2>🍕 Frações</h2>
            <p>
                Uma fração representa uma parte de um todo.
            </p>

            <div class="math-expression">
                a / b
            </div>

            <p>
                O número de cima é o numerador e o de baixo
                é o denominador.
            </p>
        `
    },

    {
        id: "percentage",
        name: "Porcentagem",
        icon: "📊",
        description: "Descontos, aumentos e porcentagens",
        learn: `
            <h2>📊 Porcentagem</h2>
            <p>
                Porcentagem representa uma quantidade em relação
                a 100.
            </p>

            <div class="math-expression">
                25% = 25 / 100 = 0,25
            </div>
        `
    },

    {
        id: "rule3",
        name: "Regra de 3",
        icon: "⚖️",
        description: "Proporções simples",
        learn: `
            <h2>⚖️ Regra de 3</h2>
            <p>
                A regra de três permite encontrar um valor
                desconhecido em uma proporção.
            </p>

            <div class="math-expression">
                a / b = c / x
            </div>

            <p>
                Faça a multiplicação cruzada para encontrar x.
            </p>
        `
    },

    {
        id: "powers",
        name: "Potenciação",
        icon: "⚡",
        description: "Potências e propriedades",
        learn: `
            <h2>⚡ Potenciação</h2>
            <p>
                Potenciação representa uma multiplicação
                repetida.
            </p>

            <div class="math-expression">
                2³ = 2 × 2 × 2 = 8
            </div>
        `
    },

    {
        id: "roots",
        name: "Radiciação",
        icon: "√",
        description: "Raízes quadradas e cálculos",
        learn: `
            <h2>√ Radiciação</h2>
            <p>
                A raiz quadrada de um número é o valor que,
                multiplicado por ele mesmo, produz esse número.
            </p>

            <div class="math-expression">
                √49 = 7
            </div>
        `
    },

    {
        id: "equations",
        name: "Equações",
        icon: "📐",
        description: "Equações de primeiro grau",
        learn: `
            <h2>📐 Equações</h2>
            <p>
                Em uma equação, procuramos o valor desconhecido
                que torna a igualdade verdadeira.
            </p>

            <div class="math-expression">
                2x + 4 = 12
            </div>
        `
    },

    {
        id: "geometry",
        name: "Geometria",
        icon: "🔺",
        description: "Áreas, perímetros e formas",
        learn: `
            <h2>🔺 Geometria</h2>
            <p>
                A geometria estuda formas, medidas,
                áreas e perímetros.
            </p>

            <div class="math-expression">
                Área do retângulo = base × altura
            </div>
        `
    },

    {
        id: "averages",
        name: "Média",
        icon: "📈",
        description: "Média aritmética e problemas",
        learn: `
            <h2>📈 Média aritmética</h2>
            <p>
                Para calcular uma média aritmética,
                some os valores e divida pela quantidade
                de valores.
            </p>
        `
    }

];


/* =====================================================
   BANCO DE QUESTÕES
===================================================== */

const questionBank = {

    bhaskara: {

        easy: [

            q(
                "bhaskara",
                "Qual é o valor de Δ na equação x² − 5x + 6 = 0?",
                "Δ = b² − 4ac",
                ["1", "25", "−1", "49"],
                0,
                "Substitua a = 1, b = −5 e c = 6 na fórmula do discriminante."
            ),

            q(
                "bhaskara",
                "Na equação x² − 5x + 6 = 0, quais são x₁ e x₂?",
                "x₁ = 2 e x₂ = 3",
                ["x₁ = 1 e x₂ = 6", "x₁ = −2 e x₂ = −3", "x₁ = 2 e x₂ = 3", "x₁ = 3 e x₂ = 5"],
                2,
                "Depois de encontrar Δ, use a fórmula de Bhaskara para encontrar as duas raízes."
            ),

            q(
                "bhaskara",
                "Qual é o valor de Δ em  x² + 6x + 9 = 0?",
                "Δ = 0",
                ["Δ = 36", "Δ = 9", "Δ = −9", "Δ = 0"],
                3,
                "Observe que a = 1, b = 6 e c = 9."
            ),

            q(
                "bhaskara",
                "Quais são as raízes de x² − 9x + 20 = 0?",
                "x₁ = 4 e x₂ = 5",
                ["x₁ = 2 e x₂ = 10", "x₁ = 4 e x₂ = 5", "x₁ = −4 e x₂ = −5", "x₁ = 1 e x₂ = 20"],
                1,
                "Procure dois números cujo produto seja 20 e cuja soma seja 9."
            ),

            q(
                "bhaskara",
                "Na equação x² − 4x + 4 = 0, quantas raízes reais existem?",
                "Uma raiz real",
                ["Duas raízes reais diferentes", "Nenhuma raiz real", "Uma raiz real", "Três raízes reais"],
                2,
                "Calcule Δ e observe o que acontece quando ele é igual a zero."
            ),

            q(
                "bhaskara",
                "Qual é o valor de x₁ na equação x² − 7x + 12 = 0?",
                "x₁ = 3",
                ["x₁ = 2", "x₁ = 3", "x₁ = 4", "x₁ = 12"],
                1,
                "As duas raízes são números que multiplicados dão 12 e somados dão 7."
            ),

            q(
                "bhaskara",
                "Qual é o valor de x₂ na equação x² − 8x + 15 = 0?",
                "x₂ = 5",
                ["x₂ = 2", "x₂ = 3", "x₂ = 5", "x₂ = 15"],
                2,
                "Encontre as duas raízes da equação e identifique a maior."
            ),

            q(
                "bhaskara",
                "Qual é o valor de Δ em x² + 2x − 8 = 0?",
                "Δ = 36",
                ["Δ = 12", "Δ = 24", "Δ = 32", "Δ = 36"],
                3,
                "Use Δ = b² − 4ac."
            ),

            q(
                "bhaskara",
                "Quais são as raízes de x² + x − 6 = 0?",
                "x₁ = 2 e x₂ = −3",
                ["x₁ = 3 e x₂ = −2", "x₁ = 2 e x₂ = −3", "x₁ = −2 e x₂ = −3", "x₁ = 1 e x₂ = −6"],
                1,
                "Procure os números cujo produto seja −6 e cuja soma seja −1."
            ),

            q(
                "bhaskara",
                "Qual é o valor de x₁ na equação x² − 3x − 10 = 0?",
                "x₁ = 5",
                ["x₁ = −5", "x₁ = 2", "x₁ = 5", "x₁ = 10"],
                2,
                "Calcule o discriminante e depois aplique a fórmula."
            )

        ],

        medium: [

            q(
                "bhaskara",
                "Resolva 2x² − 7x + 3 = 0. Quais são as raízes?",
                "x₁ = 3 e x₂ = 1/2",
                ["x₁ = 2 e x₂ = 3/2", "x₁ = 3 e x₂ = 1/2", "x₁ = −3 e x₂ = −1/2", "x₁ = 7 e x₂ = 3"],
                1,
                "Calcule Δ primeiro e não esqueça que o denominador da fórmula é 2a."
            ),

            q(
                "bhaskara",
                "Qual é o Δ de 3x² + 2x − 8 = 0?",
                "Δ = 100",
                ["Δ = 68", "Δ = 84", "Δ = 100", "Δ = 112"],
                2,
                "Use a = 3, b = 2 e c = −8."
            ),

            q(
                "bhaskara",
                "Resolva 2x² + x − 6 = 0.",
                "x₁ = 3/2 e x₂ = −2",
                ["x₁ = 2 e x₂ = −3/2", "x₁ = 3/2 e x₂ = −2", "x₁ = −3/2 e x₂ = 2", "x₁ = 3 e x₂ = −2"],
                1,
                "Depois de encontrar Δ, simplifique as duas frações."
            ),

            q(
                "bhaskara",
                "Qual é o Δ de 4x² − 4x + 1 = 0?",
                "Δ = 0",
                ["Δ = 1", "Δ = 4", "Δ = −4", "Δ = 0"],
                3,
                "Observe que a = 4, b = −4 e c = 1."
            ),

            q(
                "bhaskara",
                "As raízes de 3x² − 12x + 9 = 0 são:",
                "x₁ = 3 e x₂ = 1",
                ["x₁ = 4 e x₂ = 3", "x₁ = 3 e x₂ = 1", "x₁ = −3 e x₂ = −1", "x₁ = 6 e x₂ = 3"],
                1,
                "Divida os coeficientes por 3 ou resolva diretamente pela fórmula."
            ),

            q(
                "bhaskara",
                "Qual é o Δ de 2x² − 4x − 6 = 0?",
                "Δ = 64",
                ["Δ = 40", "Δ = 48", "Δ = 56", "Δ = 64"],
                3,
                "Calcule b² e depois 4ac com atenção aos sinais."
            ),

            q(
                "bhaskara",
                "Resolva x² + 4x − 12 = 0.",
                "x₁ = 2 e x₂ = −6",
                ["x₁ = 6 e x₂ = −2", "x₁ = 2 e x₂ = −6", "x₁ = −2 e x₂ = −6", "x₁ = 3 e x₂ = −4"],
                1,
                "Encontre dois números cujo produto seja −12 e cuja soma seja 4."
            ),

            q(
                "bhaskara",
                "Em 5x² − 20x + 20 = 0, qual é a raiz?",
                "x = 2",
                ["x = 1", "x = 2", "x = 4", "x = 5"],
                1,
                "O discriminante é zero, então as duas raízes coincidem."
            ),

            q(
                "bhaskara",
                "Resolva 2x² − 5x − 3 = 0.",
                "x₁ = 3 e x₂ = −1/2",
                ["x₁ = 2 e x₂ = −3/2", "x₁ = 3 e x₂ = −1/2", "x₁ = −3 e x₂ = 1/2", "x₁ = 5 e x₂ = −3"],
                1,
                "Calcule Δ = b² − 4ac e depois divida por 2a."
            ),

            q(
                "bhaskara",
                "Qual é o valor de x₁ na equação 3x² − 5x − 2 = 0?",
                "x₁ = 2",
                ["x₁ = −2", "x₁ = 1/3", "x₁ = 2", "x₁ = 5/3"],
                2,
                "As raízes podem ser encontradas com a fórmula completa de Bhaskara."
            )

        ],

        hard: [

            q(
                "bhaskara",
                "Resolva 6x² − x − 2 = 0.",
                "x₁ = 2/3 e x₂ = −1/2",
                ["x₁ = 1/2 e x₂ = −2/3", "x₁ = 2/3 e x₂ = −1/2", "x₁ = −2/3 e x₂ = 1/2", "x₁ = 3/2 e x₂ = −1/3"],
                1,
                "Calcule Δ = 49 e use 2a = 12 no denominador."
            ),

            q(
                "bhaskara",
                "Resolva 5x² − 13x + 6 = 0.",
                "x₁ = 2 e x₂ = 3/5",
                ["x₁ = 3 e x₂ = 2/5", "x₁ = 2 e x₂ = 3/5", "x₁ = −2 e x₂ = −3/5", "x₁ = 5 e x₂ = 6/5"],
                1,
                "O discriminante é 49. Simplifique as raízes depois da divisão."
            ),

            q(
                "bhaskara",
                "Resolva 7x² − 9x + 2 = 0.",
                "x₁ = 1 e x₂ = 2/7",
                ["x₁ = 2 e x₂ = 1/7", "x₁ = 1 e x₂ = 2/7", "x₁ = −1 e x₂ = −2/7", "x₁ = 7 e x₂ = 2"],
                1,
                "Calcule o discriminante e divida as duas possibilidades por 14."
            ),

            q(
                "bhaskara",
                "Qual é o Δ de 8x² − 12x + 5 = 0?",
                "Δ = −16",
                ["Δ = 16", "Δ = −16", "Δ = −4", "Δ = 64"],
                1,
                "Calcule 144 − 4·8·5."
            ),

            q(
                "bhaskara",
                "A equação 9x² − 12x + 4 = 0 possui:",
                "Uma raiz real igual a 2/3",
                ["Duas raízes reais: 2/3 e −2/3", "Uma raiz real igual a 2/3", "Nenhuma raiz real", "Uma raiz real igual a 3/2"],
                1,
                "Calcule Δ e depois encontre a raiz repetida."
            ),

            q(
                "bhaskara",
                "Resolva 4x² + 4x − 15 = 0.",
                "x₁ = 3/2 e x₂ = −5/2",
                ["x₁ = 5/2 e x₂ = −3/2", "x₁ = 3/2 e x₂ = −5/2", "x₁ = −3/2 e x₂ = 5/2", "x₁ = 3 e x₂ = −5"],
                1,
                "O discriminante é 256. Lembre-se de que √256 = 16."
            ),

            q(
                "bhaskara",
                "Resolva 10x² − 7x − 12 = 0.",
                "x₁ = 3/2 e x₂ = −4/5",
                ["x₁ = 4/5 e x₂ = −3/2", "x₁ = 3/2 e x₂ = −4/5", "x₁ = −3/2 e x₂ = 4/5", "x₁ = 2 e x₂ = −6/5"],
                1,
                "Calcule Δ = 529 e observe que √529 = 23."
            ),

            q(
                "bhaskara",
                "Qual é o valor de Δ em 12x² + 4x − 5 = 0?",
                "Δ = 256",
                ["Δ = 196", "Δ = 224", "Δ = 256", "Δ = 276"],
                2,
                "Substitua os três coeficientes diretamente na fórmula."
            ),

            q(
                "bhaskara",
                "Resolva 9x² + 3x − 2 = 0.",
                "x₁ = 1/3 e x₂ = −2/3",
                ["x₁ = 2/3 e x₂ = −1/3", "x₁ = 1/3 e x₂ = −2/3", "x₁ = −1/3 e x₂ = 2/3", "x₁ = 1/9 e x₂ = −2/9"],
                1,
                "O discriminante é 81. Use 18 no denominador."
            ),

            q(
                "bhaskara",
                "Qual é o Δ de 15x² − 2x + 3 = 0?",
                "Δ = −176",
                ["Δ = 176", "Δ = −176", "Δ = −164", "Δ = −196"],
                1,
                "Calcule b² − 4ac mantendo o sinal negativo de 4ac."
            )

        ]

    },

    basic: {

        easy: [

            q("basic", "Quanto é 8 + 7?", "15", ["14", "15", "16", "17"], 1, "Some as duas parcelas."),
            q("basic", "Quanto é 20 − 8?", "12", ["10", "11", "12", "13"], 2, "Retire 8 de 20."),
            q("basic", "Quanto é 6 × 7?", "42", ["36", "40", "42", "48"], 2, "Multiplique 6 por 7."),
            q("basic", "Quanto é 81 ÷ 9?", "9", ["7", "8", "9", "10"], 2, "Pense em qual número multiplicado por 9 resulta em 81."),
            q("basic", "Quanto é 15 + 25?", "40", ["30", "35", "40", "45"], 2, "Some dezenas e unidades."),
            q("basic", "Quanto é 50 − 17?", "33", ["31", "32", "33", "34"], 2, "Faça a subtração por partes."),
            q("basic", "Quanto é 9 × 5?", "45", ["35", "40", "45", "50"], 2, "Multiplique 9 por 5."),
            q("basic", "Quanto é 72 ÷ 8?", "9", ["7", "8", "9", "10"], 2, "Procure o número que vezes 8 dá 72."),
            q("basic", "Quanto é 14 + 19?", "33", ["31", "32", "33", "34"], 2, "Some 14 e 19."),
            q("basic", "Quanto é 100 − 37?", "63", ["61", "62", "63", "64"], 2, "Subtraia 37 de 100.")

        ],

        medium: [

            q("basic", "Quanto é 125 + 378?", "503", ["493", "503", "513", "523"], 1, "Some centenas, dezenas e unidades."),
            q("basic", "Quanto é 804 − 367?", "437", ["427", "437", "447", "457"], 1, "Faça a subtração com empréstimos quando necessário."),
            q("basic", "Quanto é 24 × 15?", "360", ["340", "350", "360", "370"], 2, "Separe 15 em 10 + 5."),
            q("basic", "Quanto é 936 ÷ 12?", "78", ["68", "72", "78", "84"], 2, "Verifique qual número multiplicado por 12 resulta em 936."),
            q("basic", "Quanto é 45 + 67 − 28?", "84", ["74", "84", "94", "104"], 1, "Resolva da esquerda para a direita."),
            q("basic", "Quanto é 18 × 14?", "252", ["242", "252", "262", "272"], 1, "Calcule 18 × 10 e 18 × 4."),
            q("basic", "Quanto é 720 ÷ 15?", "48", ["38", "43", "48", "53"], 2, "Pense em 15 × 48."),
            q("basic", "Quanto é 300 − 125 + 40?", "215", ["205", "215", "225", "235"], 1, "Faça as operações na ordem."),
            q("basic", "Quanto é 32 × 9?", "288", ["278", "288", "298", "308"], 1, "Multiplique 32 por 9."),
            q("basic", "Quanto é 1440 ÷ 16?", "90", ["80", "90", "100", "110"], 1, "Procure o número que multiplicado por 16 dá 1440.")

        ],

        hard: [

            q("basic", "Quanto é 125 × 24?", "3000", ["2800", "2900", "3000", "3200"], 2, "Separe 24 em 20 + 4."),
            q("basic", "Quanto é 3456 ÷ 24?", "144", ["124", "134", "144", "154"], 2, "Verifique 144 × 24."),
            q("basic", "Quanto é 875 + 1296 − 438?", "1733", ["1633", "1733", "1833", "1933"], 1, "Some primeiro e depois subtraia."),
            q("basic", "Quanto é 48 × 37?", "1776", ["1676", "1776", "1876", "1976"], 1, "Faça 48 × 30 + 48 × 7."),
            q("basic", "Quanto é 6720 ÷ 28?", "240", ["220", "230", "240", "250"], 2, "Verifique 28 × 240."),
            q("basic", "Quanto é 9999 − 4567?", "5432", ["5332", "5432", "5532", "5632"], 1, "Organize os números por ordem de casa."),
            q("basic", "Quanto é 125 × 48?", "6000", ["5000", "5500", "6000", "6500"], 2, "Use 125 × 48 = 125 × (50 − 2)."),
            q("basic", "Quanto é 9876 ÷ 36?", "274", ["264", "274", "284", "294"], 1, "Confira multiplicando a resposta por 36."),
            q("basic", "Quanto é 75 × 64?", "4800", ["4600", "4700", "4800", "4900"], 2, "Calcule 75 × 64."),
            q("basic", "Quanto é 5000 − 1375 + 825?", "4450", ["4350", "4450", "4550", "4650"], 1, "Resolva as operações na ordem.")

        ]

    },

    fractions: {

        easy: [
            q("fractions", "Quanto é 1/2 + 1/2?", "1", ["1/2", "1", "2", "3/2"], 1, "As frações têm o mesmo denominador."),
            q("fractions", "Quanto é 1/4 + 1/4?", "1/2", ["1/4", "1/2", "3/4", "1"], 1, "Some os numeradores mantendo o denominador."),
            q("fractions", "Quanto é 3/5 − 1/5?", "2/5", ["1/5", "2/5", "3/5", "4/5"], 1, "Os denominadores são iguais."),
            q("fractions", "Qual fração representa metade?", "1/2", ["1/3", "1/2", "2/3", "3/4"], 1, "Metade significa uma de duas partes iguais."),
            q("fractions", "Qual é a forma simplificada de 2/4?", "1/2", ["1/4", "1/2", "2/3", "3/4"], 1, "Divida numerador e denominador pelo mesmo número."),
            q("fractions", "Quanto é 2/3 + 1/3?", "1", ["1/3", "2/3", "1", "4/3"], 2, "Os denominadores são iguais."),
            q("fractions", "Quanto é 4/7 − 2/7?", "2/7", ["1/7", "2/7", "3/7", "4/7"], 1, "Subtraia os numeradores."),
            q("fractions", "Qual é a forma simplificada de 6/8?", "3/4", ["1/2", "2/3", "3/4", "4/5"], 2, "Divida os dois termos por 2."),
            q("fractions", "Quanto é 1/3 + 1/3?", "2/3", ["1/3", "2/3", "3/3", "1/6"], 1, "Some os numeradores."),
            q("fractions", "Quanto é 5/6 − 2/6?", "1/2", ["1/3", "1/2", "2/3", "3/4"], 1, "Obtenha 3/6 e simplifique.")

        ],

        medium: [
            q("fractions", "Quanto é 1/2 + 1/3?", "5/6", ["2/5", "5/6", "3/5", "4/6"], 1, "Encontre o mínimo múltiplo comum de 2 e 3."),
            q("fractions", "Quanto é 3/4 − 1/6?", "7/12", ["5/12", "7/12", "8/12", "9/12"], 1, "Use 12 como denominador comum."),
            q("fractions", "Quanto é 2/5 × 3/4?", "3/10", ["1/5", "3/10", "2/9", "3/8"], 1, "Multiplique numeradores e denominadores e simplifique."),
            q("fractions", "Quanto é 3/4 ÷ 2/3?", "9/8", ["6/8", "8/9", "9/8", "3/2"], 2, "Dividir por uma fração equivale a multiplicar pelo inverso."),
            q("fractions", "Quanto é 5/6 + 1/4?", "13/12", ["11/12", "13/12", "14/12", "15/12"], 1, "Use 12 como denominador comum."),
            q("fractions", "Qual é a forma simplificada de 18/24?", "3/4", ["2/3", "3/4", "4/5", "5/6"], 1, "Divida numerador e denominador por 6."),
            q("fractions", "Quanto é 7/8 − 1/4?", "5/8", ["3/8", "4/8", "5/8", "6/8"], 2, "Transforme 1/4 em uma fração com denominador 8."),
            q("fractions", "Quanto é 2/3 × 9/10?", "3/5", ["2/5", "3/5", "4/5", "6/5"], 1, "Simplifique antes ou depois de multiplicar."),
            q("fractions", "Quanto é 5/8 ÷ 5/16?", "2", ["1", "2", "3", "4"], 1, "Multiplique 5/8 pelo inverso de 5/16."),
            q("fractions", "Quanto é 3/5 + 7/10?", "13/10", ["11/10", "12/10", "13/10", "14/10"], 2, "Transforme 3/5 em décimos.")

        ],

        hard: [
            q("fractions", "Quanto é 7/12 + 5/18?", "31/36", ["29/36", "31/36", "33/36", "35/36"], 1, "O MMC de 12 e 18 é 36."),
            q("fractions", "Quanto é 11/15 − 7/20?", "23/60", ["19/60", "21/60", "23/60", "25/60"], 2, "Use 60 como denominador comum."),
            q("fractions", "Quanto é 5/6 × 9/10 × 4/3?", "1", ["1/2", "2/3", "1", "4/3"], 2, "Simplifique fatores antes de multiplicar."),
            q("fractions", "Quanto é 7/9 ÷ 14/27?", "3/2", ["1/2", "3/2", "2", "5/2"], 1, "Multiplique 7/9 pelo inverso de 14/27."),
            q("fractions", "Quanto é 13/18 + 11/24?", "85/72", ["79/72", "83/72", "85/72", "87/72"], 2, "O MMC de 18 e 24 é 72."),
            q("fractions", "Quanto é 17/20 − 5/12?", "31/60", ["29/60", "31/60", "33/60", "35/60"], 1, "O denominador comum é 60."),
            q("fractions", "Quanto é 8/15 × 25/16?", "5/6", ["1/2", "2/3", "5/6", "7/6"], 2, "Simplifique 8 com 16 e 25 com 15."),
            q("fractions", "Quanto é 9/14 ÷ 27/28?", "2/3", ["1/3", "2/3", "3/4", "4/3"], 1, "Multiplique 9/14 pelo inverso de 27/28."),
            q("fractions", "Quanto é 5/8 + 7/12 − 1/6?", "25/24", ["21/24", "23/24", "25/24", "27/24"], 2, "Use 24 como denominador comum."),
            q("fractions", "Quanto é 15/28 ÷ 5/14?", "3/2", ["1/2", "1", "3/2", "2"], 2, "Multiplique 15/28 pelo inverso de 5/14.")

        ]

    },

    percentage: {

        easy: [
            q("percentage", "Quanto é 10% de 100?", "10", ["5", "10", "20", "25"], 1, "10% significa 10 de cada 100."),
            q("percentage", "Quanto é 50% de 80?", "40", ["20", "30", "40", "50"], 2, "50% corresponde à metade."),
            q("percentage", "Quanto é 25% de 200?", "50", ["25", "40", "50", "75"], 2, "25% é um quarto."),
            q("percentage", "Quanto é 20% de 50?", "10", ["5", "10", "15", "20"], 1, "Converta 20% para 0,20."),
            q("percentage", "Quanto é 5% de 200?", "10", ["5", "10", "15", "20"], 1, "Calcule 200 × 0,05."),
            q("percentage", "Quanto é 30% de 100?", "30", ["20", "30", "40", "50"], 1, "30% de 100 é 30."),
            q("percentage", "Quanto é 75% de 40?", "30", ["20", "25", "30", "35"], 2, "75% corresponde a três quartos."),
            q("percentage", "Quanto é 10% de 250?", "25", ["15", "20", "25", "30"], 2, "Calcule 250 × 0,10."),
            q("percentage", "Quanto é 40% de 90?", "36", ["26", "36", "46", "56"], 1, "Multiplique 90 por 0,40."),
            q("percentage", "Quanto é 50% de 250?", "125", ["100", "125", "150", "175"], 1, "Metade de 250 é o resultado.")

        ],

        medium: [
            q("percentage", "Quanto é 15% de 240?", "36", ["26", "36", "46", "56"], 1, "Calcule 240 × 0,15."),
            q("percentage", "Quanto é 35% de 200?", "70", ["60", "70", "80", "90"], 1, "Transforme 35% em decimal."),
            q("percentage", "Um produto de R$ 80 teve desconto de 25%. Qual o preço final?", "R$ 60", ["R$ 55", "R$ 60", "R$ 65", "R$ 70"], 1, "Calcule o desconto e retire-o do preço original."),
            q("percentage", "Um produto de R$ 120 aumentou 10%. Qual o novo preço?", "R$ 132", ["R$ 122", "R$ 130", "R$ 132", "R$ 140"], 2, "Some 10% de 120 ao preço original."),
            q("percentage", "Quanto é 12% de 500?", "60", ["50", "60", "70", "80"], 1, "Calcule 500 × 0,12."),
            q("percentage", "Quanto é 45% de 160?", "72", ["62", "72", "82", "92"], 1, "Calcule 160 × 0,45."),
            q("percentage", "Um preço de R$ 200 recebeu desconto de 15%. Qual o desconto?", "R$ 30", ["R$ 20", "R$ 30", "R$ 40", "R$ 50"], 1, "Calcule 15% de 200."),
            q("percentage", "Quanto é 22% de 300?", "66", ["56", "66", "76", "86"], 1, "Calcule 300 × 0,22."),
            q("percentage", "Quanto é 65% de 80?", "52", ["42", "52", "62", "72"], 1, "Calcule 80 × 0,65."),
            q("percentage", "Um valor de 400 aumentou 20%. Qual o novo valor?", "480", ["440", "460", "480", "500"], 2, "Calcule 20% de 400 e some ao valor inicial.")

        ],

        hard: [
            q("percentage", "Um produto de R$ 500 recebe descontos sucessivos de 10% e 20%. Qual o preço final?", "R$ 360", ["R$ 350", "R$ 360", "R$ 370", "R$ 380"], 1, "Aplique o primeiro desconto e depois o segundo sobre o novo preço."),
            q("percentage", "Um valor de R$ 800 aumenta 15% e depois diminui 10%. Qual o resultado?", "R$ 828", ["R$ 818", "R$ 828", "R$ 838", "R$ 848"], 1, "Faça cada alteração sobre o valor obtido na etapa anterior."),
            q("percentage", "60 corresponde a quantos por cento de 240?", "25%", ["20%", "25%", "30%", "35%"], 1, "Divida 60 por 240 e transforme em porcentagem."),
            q("percentage", "Um preço final de R$ 180 corresponde a um desconto de 10% sobre qual preço original?", "R$ 200", ["R$ 190", "R$ 200", "R$ 210", "R$ 220"], 1, "Se houve 10% de desconto, R$ 180 representa 90% do original."),
            q("percentage", "Um valor passou de 200 para 250. Qual foi o aumento percentual?", "25%", ["20%", "25%", "30%", "35%"], 1, "Calcule o aumento e compare com o valor inicial."),
            q("percentage", "Um produto de R$ 750 teve desconto de 18%. Qual o preço final?", "R$ 615", ["R$ 605", "R$ 615", "R$ 625", "R$ 635"], 1, "Calcule 18% de 750 e subtraia."),
            q("percentage", "Um valor de 1.200 aumentou 12,5%. Qual o novo valor?", "1.350", ["1.300", "1.350", "1.400", "1.450"], 1, "Calcule 12,5% de 1.200."),
            q("percentage", "Um produto custa R$ 640 após um desconto de 20%. Qual era o preço original?", "R$ 800", ["R$ 760", "R$ 800", "R$ 840", "R$ 880"], 1, "R$ 640 representa 80% do preço original."),
            q("percentage", "Um preço de R$ 400 sofre aumento de 25% e depois desconto de 20%. Qual o preço final?", "R$ 400", ["R$ 380", "R$ 400", "R$ 420", "R$ 440"], 1, "Aplique as duas porcentagens em sequência."),
            q("percentage", "75 é 30% de qual número?", "250", ["200", "225", "250", "275"], 2, "Monte a relação 0,30 × x = 75.")

        ]

    },

    rule3: {

        easy: [
            q("rule3", "Se 2 cadernos custam R$ 10, quanto custam 4 cadernos?", "R$ 20", ["R$ 15", "R$ 20", "R$ 25", "R$ 30"], 1, "Se a quantidade dobra, o preço também dobra."),
            q("rule3", "Se 3 maçãs custam R$ 6, quanto custam 6?", "R$ 12", ["R$ 8", "R$ 10", "R$ 12", "R$ 14"], 2, "Compare as duas quantidades."),
            q("rule3", "Se 5 canetas custam R$ 15, quanto custam 10?", "R$ 30", ["R$ 20", "R$ 25", "R$ 30", "R$ 35"], 2, "10 é o dobro de 5."),
            q("rule3", "4 litros de tinta pintam 20 m². Quantos m² com 8 litros?", "40 m²", ["30 m²", "35 m²", "40 m²", "45 m²"], 2, "A quantidade de tinta dobrou."),
            q("rule3", "Se 2 kg custam R$ 18, quanto custam 5 kg?", "R$ 45", ["R$ 35", "R$ 40", "R$ 45", "R$ 50"], 2, "Descubra o preço de 1 kg primeiro."),
            q("rule3", "Se 6 ingressos custam R$ 60, quanto custam 3?", "R$ 30", ["R$ 20", "R$ 30", "R$ 40", "R$ 50"], 1, "3 ingressos correspondem à metade de 6."),
            q("rule3", "8 garrafas custam R$ 24. Quanto custam 4?", "R$ 12", ["R$ 8", "R$ 10", "R$ 12", "R$ 14"], 2, "4 é metade de 8."),
            q("rule3", "Se 10 metros custam R$ 50, quanto custam 2 metros?", "R$ 10", ["R$ 5", "R$ 10", "R$ 15", "R$ 20"], 1, "Descubra o valor de 1 metro."),
            q("rule3", "3 caixas têm 18 lápis. Quantos lápis há em 5 caixas iguais?", "30", ["24", "27", "30", "36"], 2, "Descubra quantos lápis existem em uma caixa."),
            q("rule3", "4 funcionários fazem 20 peças. Quantas peças 8 funcionários fariam no mesmo ritmo?", "40", ["30", "35", "40", "45"], 2, "A quantidade de funcionários dobrou.")

        ],

        medium: [
            q("rule3", "5 máquinas produzem 400 peças. Quantas peças 8 máquinas produzem no mesmo tempo?", "640", ["560", "600", "640", "680"], 2, "Monte 5/400 = 8/x."),
            q("rule3", "3 trabalhadores fazem um serviço em 12 dias. Mantendo a proporção direta, 6 trabalhadores fariam em quantos dias?", "6 dias", ["4 dias", "6 dias", "8 dias", "10 dias"], 1, "Aqui mais trabalhadores significam menos dias; use proporcionalidade inversa."),
            q("rule3", "8 litros de combustível permitem 120 km. Quantos km com 14 litros?", "210 km", ["180 km", "195 km", "210 km", "225 km"], 2, "Descubra quantos quilômetros correspondem a 1 litro."),
            q("rule3", "12 livros custam R$ 180. Quanto custam 7 livros?", "R$ 105", ["R$ 95", "R$ 105", "R$ 115", "R$ 125"], 1, "Encontre o preço de um livro."),
            q("rule3", "4 torneiras enchem um reservatório em 6 horas. Mantendo a proporção inversa, 8 torneiras levam quanto tempo?", "3 horas", ["2 horas", "3 horas", "4 horas", "5 horas"], 1, "Dobrar o número de torneiras reduz o tempo pela metade."),
            q("rule3", "6 kg de arroz custam R$ 42. Quanto custam 15 kg?", "R$ 105", ["R$ 95", "R$ 105", "R$ 115", "R$ 125"], 1, "Calcule o preço por quilograma."),
            q("rule3", "9 funcionários produzem 540 unidades. Quantas produzem 12 no mesmo período?", "720", ["620", "670", "720", "770"], 2, "Use proporcionalidade direta."),
            q("rule3", "7 metros de tecido custam R$ 84. Quanto custam 11 metros?", "R$ 132", ["R$ 112", "R$ 122", "R$ 132", "R$ 142"], 2, "Descubra o preço por metro."),
            q("rule3", "10 pessoas consomem 30 litros em uma atividade. Nas mesmas condições, 15 pessoas consomem quanto?", "45 litros", ["35 litros", "40 litros", "45 litros", "50 litros"], 2, "A quantidade de pessoas aumentou 50%."),
            q("rule3", "4 caminhões transportam 200 toneladas. Quantas toneladas 7 caminhões transportam?", "350 toneladas", ["300 toneladas", "325 toneladas", "350 toneladas", "375 toneladas"], 2, "Use proporção direta.")

        ],

        hard: [
            q("rule3", "12 máquinas produzem 1.800 peças. Quantas peças 17 máquinas produzem no mesmo tempo?", "2.550", ["2.350", "2.450", "2.550", "2.650"], 2, "Calcule a produção de uma máquina e multiplique por 17."),
            q("rule3", "8 trabalhadores realizam um serviço em 15 dias. Mantendo a proporção inversa, 12 trabalhadores levam quantos dias?", "10 dias", ["8 dias", "10 dias", "12 dias", "14 dias"], 1, "O produto trabalhadores × dias permanece constante."),
            q("rule3", "15 litros de tinta cobrem 90 m². Quantos litros são necessários para 156 m²?", "26 litros", ["22 litros", "24 litros", "26 litros", "28 litros"], 2, "Descubra quantos m² um litro cobre."),
            q("rule3", "18 funcionários produzem 2.700 peças. Quantas peças 25 funcionários produzem?", "3.750", ["3.250", "3.500", "3.750", "4.000"], 2, "A relação é diretamente proporcional."),
            q("rule3", "6 máquinas realizam um trabalho em 20 horas. Quantas horas 10 máquinas levariam?", "12 horas", ["10 horas", "12 horas", "14 horas", "16 horas"], 1, "Use proporcionalidade inversa."),
            q("rule3", "14 kg de material custam R$ 238. Quanto custam 25 kg?", "R$ 425", ["R$ 375", "R$ 400", "R$ 425", "R$ 450"], 2, "Calcule primeiro o preço de 1 kg."),
            q("rule3", "16 pessoas precisam de 45 litros de água. Quantos litros para 28 pessoas?", "78,75 litros", ["68,75 litros", "73,75 litros", "78,75 litros", "83,75 litros"], 2, "Use 45/16 = x/28."),
            q("rule3", "9 máquinas produzem 1.350 unidades em 5 horas. Quantas unidades 12 máquinas produzem em 5 horas?", "1.800", ["1.600", "1.700", "1.800", "1.900"], 2, "A quantidade de horas é igual; varie apenas as máquinas."),
            q("rule3", "5 pessoas fazem uma tarefa em 18 dias. Quantos dias seriam necessários para 15 pessoas?", "6 dias", ["4 dias", "6 dias", "8 dias", "10 dias"], 1, "O número de pessoas triplicou."),
            q("rule3", "20 litros de combustível percorrem 280 km. Quantos quilômetros com 37 litros?", "518 km", ["498 km", "508 km", "518 km", "528 km"], 2, "Descubra a distância por litro.")

        ]

    },

    powers: {

        easy: [
            q("powers", "Quanto é 2³?", "8", ["4", "6", "8", "9"], 2, "Calcule 2 × 2 × 2."),
            q("powers", "Quanto é 5²?", "25", ["10", "20", "25", "30"], 2, "Multiplique 5 por 5."),
            q("powers", "Quanto é 10²?", "100", ["10", "20", "100", "1000"], 2, "10 × 10."),
            q("powers", "Quanto é 3²?", "9", ["6", "8", "9", "12"], 2, "Multiplique 3 por 3."),
            q("powers", "Quanto é 4³?", "64", ["16", "32", "64", "81"], 2, "Faça 4 × 4 × 4."),
            q("powers", "Quanto é 2⁴?", "16", ["8", "12", "16", "24"], 2, "Multiplique 2 quatro vezes."),
            q("powers", "Quanto é 7²?", "49", ["42", "49", "56", "63"], 1, "Calcule 7 × 7."),
            q("powers", "Quanto é 3³?", "27", ["9", "18", "27", "36"], 2, "Calcule 3 × 3 × 3."),
            q("powers", "Quanto é 1⁵?", "1", ["0", "1", "5", "10"], 1, "Qualquer potência positiva de 1 continua sendo 1."),
            q("powers", "Quanto é 10³?", "1000", ["100", "500", "1000", "3000"], 2, "10 × 10 × 10.")

        ],

        medium: [
            q("powers", "Quanto é 2⁶?", "64", ["32", "48", "64", "128"], 2, "Continue dobrando a potência de 2."),
            q("powers", "Quanto é 3⁴?", "81", ["27", "54", "81", "108"], 2, "3 × 3 × 3 × 3."),
            q("powers", "Quanto é 5³?", "125", ["75", "100", "125", "150"], 2, "5 × 5 × 5."),
            q("powers", "Quanto é 4⁴?", "256", ["128", "196", "256", "512"], 2, "Calcule 4² primeiro e depois eleve novamente ao quadrado."),
            q("powers", "Quanto é 10⁴?", "10000", ["1000", "5000", "10000", "100000"], 2, "Cada potência de 10 acrescenta um zero."),
            q("powers", "Simplifique 2³ × 2².", "2⁵", ["2⁴", "2⁵", "2⁶", "4⁵"], 1, "Na multiplicação de potências de mesma base, some os expoentes."),
            q("powers", "Simplifique 5⁶ ÷ 5².", "5⁴", ["5²", "5³", "5⁴", "5⁸"], 2, "Na divisão de potências de mesma base, subtraia os expoentes."),
            q("powers", "Quanto é (2³)²?", "64", ["16", "32", "64", "128"], 2, "Multiplique os expoentes."),
            q("powers", "Quanto é 6² + 4²?", "52", ["36", "48", "52", "56"], 2, "Calcule as duas potências antes de somar."),
            q("powers", "Quanto é 2⁵ − 3²?", "23", ["21", "23", "25", "27"], 1, "Calcule 32 − 9.")

        ],

        hard: [
            q("powers", "Simplifique 3⁵ × 3⁴ ÷ 3⁶.", "3³", ["3²", "3³", "3⁴", "3⁵"], 1, "Some os expoentes da multiplicação e depois subtraia o da divisão."),
            q("powers", "Quanto é (2³ × 2⁴) ÷ 2⁵?", "4", ["2", "4", "8", "16"], 1, "Reduza primeiro a expressão usando as propriedades."),
            q("powers", "Quanto é 5² × 5³?", "3125", ["625", "1250", "3125", "6250"], 2, "Some os expoentes e depois calcule."),
            q("powers", "Quanto é 2⁷ + 2⁵?", "160", ["144", "160", "176", "192"], 1, "Calcule 128 + 32."),
            q("powers", "Quanto é 3⁶ − 3⁴?", "648", ["540", "648", "729", "810"], 1, "Calcule 729 − 81."),
            q("powers", "Simplifique (5²)³ ÷ 5⁴.", "5²", ["5", "5²", "5³", "5⁴"], 1, "Na potência de potência, multiplique os expoentes."),
            q("powers", "Quanto é 4³ × 2⁴?", "1024", ["512", "768", "1024", "2048"], 2, "Calcule as potências separadamente."),
            q("powers", "Quanto é 10⁵ ÷ 10²?", "1000", ["100", "1000", "10000", "100000"], 1, "Subtraia os expoentes."),
            q("powers", "Quanto é 2⁸ − 2⁶?", "192", ["128", "160", "192", "224"], 2, "Calcule 256 − 64."),
            q("powers", "Quanto é (3²)³ + 3²?", "738", ["720", "729", "738", "747"], 2, "Calcule 3⁶ e depois some 9.")

        ]

    },

    roots: {

        easy: [
            q("roots", "Quanto é √25?", "5", ["3", "4", "5", "6"], 2, "Procure o número que multiplicado por ele mesmo dá 25."),
            q("roots", "Quanto é √36?", "6", ["4", "5", "6", "7"], 2, "6 × 6 = 36."),
            q("roots", "Quanto é √49?", "7", ["5", "6", "7", "8"], 2, "Procure o quadrado que resulta em 49."),
            q("roots", "Quanto é √64?", "8", ["6", "7", "8", "9"], 2, "8 × 8 = 64."),
            q("roots", "Quanto é √81?", "9", ["7", "8", "9", "10"], 2, "9 × 9 = 81."),
            q("roots", "Quanto é √100?", "10", ["8", "9", "10", "11"], 2, "10 × 10 = 100."),
            q("roots", "Quanto é √16?", "4", ["2", "3", "4", "5"], 2, "4 × 4 = 16."),
            q("roots", "Quanto é √121?", "11", ["9", "10", "11", "12"], 2, "11 × 11 = 121."),
            q("roots", "Quanto é √144?", "12", ["10", "11", "12", "13"], 2, "12 × 12 = 144."),
            q("roots", "Quanto é √9?", "3", ["2", "3", "4", "5"], 1, "3 × 3 = 9.")

        ],

        medium: [
            q("roots", "Quanto é √225?", "15", ["12", "13", "15", "18"], 2, "15 × 15 = 225."),
            q("roots", "Quanto é √256?", "16", ["14", "15", "16", "18"], 2, "16 × 16 = 256."),
            q("roots", "Quanto é √324?", "18", ["16", "18", "20", "22"], 1, "18 × 18 = 324."),
            q("roots", "Quanto é √400?", "20", ["18", "20", "22", "24"], 1, "20 × 20 = 400."),
            q("roots", "Quanto é √625?", "25", ["20", "25", "30", "35"], 1, "25 × 25 = 625."),
            q("roots", "Quanto é √900?", "30", ["20", "25", "30", "35"], 2, "30 × 30 = 900."),
            q("roots", "Quanto é √1024?", "32", ["28", "30", "32", "34"], 2, "32 × 32 = 1024."),
            q("roots", "Quanto é √1600?", "40", ["30", "35", "40", "45"], 2, "40 × 40 = 1600."),
            q("roots", "Quanto é √2025?", "45", ["40", "45", "50", "55"], 2, "45 × 45 = 2025."),
            q("roots", "Quanto é √2500?", "50", ["40", "45", "50", "55"], 2, "50 × 50 = 2500.")

        ],

        hard: [
            q("roots", "Simplifique √72.", "6√2", ["3√2", "4√2", "6√2", "8√2"], 2, "Separe 72 em 36 × 2."),
            q("roots", "Simplifique √98.", "7√2", ["5√2", "6√2", "7√2", "8√2"], 2, "Separe 98 em 49 × 2."),
            q("roots", "Simplifique √200.", "10√2", ["5√2", "10√2", "20√2", "25√2"], 1, "Separe 200 em 100 × 2."),
            q("roots", "Quanto é √50 + √50?", "10√2", ["5√2", "10√2", "15√2", "20√2"], 1, "Primeiro simplifique cada √50."),
            q("roots", "Simplifique √128.", "8√2", ["4√2", "6√2", "8√2", "10√2"], 2, "Separe 128 em 64 × 2."),
            q("roots", "Quanto é √12 × √3?", "6", ["3", "6", "9", "12"], 1, "Use √a × √b = √(ab)."),
            q("roots", "Quanto é √75?", "5√3", ["3√5", "5√3", "15√3", "25√3"], 1, "Separe 75 em 25 × 3."),
            q("roots", "Simplifique √180.", "6√5", ["3√5", "6√5", "9√5", "12√5"], 1, "Separe 180 em 36 × 5."),
            q("roots", "Quanto é √27 + √12?", "5√3", ["4√3", "5√3", "6√3", "7√3"], 1, "Simplifique as duas raízes antes de somar."),
            q("roots", "Quanto é √48 − √12?", "2√3", ["√3", "2√3", "3√3", "4√3"], 1, "Simplifique ambas as raízes.")

        ]

    },

    equations: {

        easy: [
            q("equations", "Resolva: x + 5 = 12.", "x = 7", ["x = 5", "x = 6", "x = 7", "x = 8"], 2, "Subtraia 5 dos dois lados."),
            q("equations", "Resolva: x − 8 = 4.", "x = 12", ["x = 10", "x = 12", "x = 14", "x = 16"], 1, "Some 8 aos dois lados."),
            q("equations", "Resolva: 2x = 18.", "x = 9", ["x = 7", "x = 8", "x = 9", "x = 10"], 2, "Divida os dois lados por 2."),
            q("equations", "Resolva: 3x = 21.", "x = 7", ["x = 6", "x = 7", "x = 8", "x = 9"], 1, "Divida 21 por 3."),
            q("equations", "Resolva: x + 9 = 20.", "x = 11", ["x = 9", "x = 10", "x = 11", "x = 12"], 2, "Subtraia 9."),
            q("equations", "Resolva: x − 6 = 10.", "x = 16", ["x = 14", "x = 15", "x = 16", "x = 17"], 2, "Some 6."),
            q("equations", "Resolva: 5x = 35.", "x = 7", ["x = 5", "x = 6", "x = 7", "x = 8"], 2, "Divida 35 por 5."),
            q("equations", "Resolva: x/4 = 6.", "x = 24", ["x = 18", "x = 20", "x = 24", "x = 28"], 2, "Multiplique os dois lados por 4."),
            q("equations", "Resolva: x + 13 = 25.", "x = 12", ["x = 10", "x = 11", "x = 12", "x = 13"], 2, "Subtraia 13."),
            q("equations", "Resolva: x − 15 = 5.", "x = 20", ["x = 15", "x = 18", "x = 20", "x = 25"], 2, "Some 15.")

        ],

        medium: [
            q("equations", "Resolva: 2x + 5 = 17.", "x = 6", ["x = 5", "x = 6", "x = 7", "x = 8"], 1, "Subtraia 5 e depois divida por 2."),
            q("equations", "Resolva: 3x − 4 = 20.", "x = 8", ["x = 6", "x = 7", "x = 8", "x = 9"], 2, "Some 4 e divida por 3."),
            q("equations", "Resolva: 5x + 10 = 35.", "x = 5", ["x = 4", "x = 5", "x = 6", "x = 7"], 1, "Subtraia 10 e divida por 5."),
            q("equations", "Resolva: 4x − 12 = 16.", "x = 7", ["x = 6", "x = 7", "x = 8", "x = 9"], 1, "Some 12 e divida por 4."),
            q("equations", "Resolva: 7x + 3 = 31.", "x = 4", ["x = 3", "x = 4", "x = 5", "x = 6"], 1, "Subtraia 3 e divida por 7."),
            q("equations", "Resolva: 6x − 5 = 31.", "x = 6", ["x = 4", "x = 5", "x = 6", "x = 7"], 2, "Some 5 e divida por 6."),
            q("equations", "Resolva: 2x + 8 = 30.", "x = 11", ["x = 9", "x = 10", "x = 11", "x = 12"], 2, "Subtraia 8 e divida por 2."),
            q("equations", "Resolva: 9x − 9 = 45.", "x = 6", ["x = 4", "x = 5", "x = 6", "x = 7"], 2, "Some 9 e divida por 9."),
            q("equations", "Resolva: 8x + 4 = 60.", "x = 7", ["x = 6", "x = 7", "x = 8", "x = 9"], 2, "Subtraia 4 e divida por 8."),
            q("equations", "Resolva: 10x − 20 = 50.", "x = 7", ["x = 5", "x = 6", "x = 7", "x = 8"], 2, "Some 20 e divida por 10.")

        ],

        hard: [
            q("equations", "Resolva: 3(x + 4) = 30.", "x = 6", ["x = 4", "x = 5", "x = 6", "x = 7"], 2, "Distribua o 3 ou divida ambos os lados por 3."),
            q("equations", "Resolva: 5(x − 2) = 40.", "x = 10", ["x = 8", "x = 9", "x = 10", "x = 12"], 2, "Divida por 5 e depois some 2."),
            q("equations", "Resolva: 2(x + 5) − 4 = 20.", "x = 7", ["x = 5", "x = 6", "x = 7", "x = 8"], 2, "Distribua o 2 e organize os termos."),
            q("equations", "Resolva: 4(x − 3) + 8 = 28.", "x = 8", ["x = 6", "x = 7", "x = 8", "x = 9"], 2, "Distribua o 4 e isole x."),
            q("equations", "Resolva: 7x + 5 = 3x + 29.", "x = 6", ["x = 5", "x = 6", "x = 7", "x = 8"], 1, "Coloque os termos com x de um lado e os números do outro."),
            q("equations", "Resolva: 9x − 7 = 5x + 21.", "x = 7", ["x = 5", "x = 6", "x = 7", "x = 8"], 2, "Subtraia 5x dos dois lados."),
            q("equations", "Resolva: 3x + 14 = x + 30.", "x = 8", ["x = 6", "x = 7", "x = 8", "x = 9"], 2, "Subtraia x e depois 14."),
            q("equations", "Resolva: 5x − 12 = 2x + 15.", "x = 9", ["x = 8", "x = 9", "x = 10", "x = 11"], 2, "Subtraia 2x e some 12."),
            q("equations", "Resolva: 4x + 6 = 2x + 24.", "x = 9", ["x = 7", "x = 8", "x = 9", "x = 10"], 2, "Subtraia 2x dos dois lados."),
            q("equations", "Resolva: 6(x + 2) = 3x + 30.", "x = 6", ["x = 4", "x = 5", "x = 6", "x = 7"], 1, "Distribua 6 e reúna os termos semelhantes.")

        ]

    },

    geometry: {

        easy: [
            q("geometry", "Qual é a área de um retângulo de 5 cm por 4 cm?", "20 cm²", ["9 cm²", "15 cm²", "20 cm²", "25 cm²"], 2, "Área do retângulo = base × altura."),
            q("geometry", "Qual é o perímetro de um quadrado de lado 6 cm?", "24 cm", ["18 cm", "24 cm", "30 cm", "36 cm"], 1, "Um quadrado possui quatro lados iguais."),
            q("geometry", "Qual é a área de um quadrado de lado 7 cm?", "49 cm²", ["14 cm²", "28 cm²", "49 cm²", "56 cm²"], 2, "Área do quadrado = lado × lado."),
            q("geometry", "Qual é o perímetro de um retângulo de 8 cm por 3 cm?", "22 cm", ["18 cm", "20 cm", "22 cm", "24 cm"], 2, "Some todos os quatro lados."),
            q("geometry", "Qual é a área de um triângulo com base 10 cm e altura 6 cm?", "30 cm²", ["20 cm²", "30 cm²", "40 cm²", "60 cm²"], 1, "Área do triângulo = base × altura ÷ 2."),
            q("geometry", "Qual é a área de um retângulo de 9 cm por 2 cm?", "18 cm²", ["11 cm²", "16 cm²", "18 cm²", "20 cm²"], 2, "Multiplique base por altura."),
            q("geometry", "Um quadrado tem lado 10 cm. Qual seu perímetro?", "40 cm", ["20 cm", "30 cm", "40 cm", "50 cm"], 2, "São quatro lados de 10 cm."),
            q("geometry", "Qual é a área de um quadrado de lado 12 cm?", "144 cm²", ["124 cm²", "134 cm²", "144 cm²", "154 cm²"], 2, "Calcule 12 × 12."),
            q("geometry", "Qual é o perímetro de um triângulo com lados 3, 4 e 5 cm?", "12 cm", ["10 cm", "12 cm", "14 cm", "16 cm"], 1, "Some os três lados."),
            q("geometry", "Qual é a área de um retângulo de 12 cm por 5 cm?", "60 cm²", ["50 cm²", "60 cm²", "70 cm²", "80 cm²"], 1, "Multiplique 12 por 5.")

        ],

        medium: [
            q("geometry", "Qual é a área de um triângulo de base 14 cm e altura 8 cm?", "56 cm²", ["48 cm²", "56 cm²", "64 cm²", "72 cm²"], 1, "Multiplique base e altura e divida por 2."),
            q("geometry", "Um círculo tem raio 5 cm. Usando π = 3,14, qual é sua área?", "78,5 cm²", ["62,8 cm²", "78,5 cm²", "94,2 cm²", "100 cm²"], 1, "Use A = πr²."),
            q("geometry", "Um retângulo tem área 96 cm² e base 12 cm. Qual sua altura?", "8 cm", ["6 cm", "8 cm", "10 cm", "12 cm"], 1, "Divida a área pela base."),
            q("geometry", "Um quadrado tem área 169 cm². Qual é o lado?", "13 cm", ["11 cm", "12 cm", "13 cm", "14 cm"], 2, "Procure a raiz quadrada de 169."),
            q("geometry", "Qual é o perímetro de um retângulo 15 cm × 7 cm?", "44 cm", ["34 cm", "44 cm", "54 cm", "64 cm"], 1, "Some 15 + 7 + 15 + 7."),
            q("geometry", "Um triângulo tem base 18 cm e altura 10 cm. Qual sua área?", "90 cm²", ["80 cm²", "90 cm²", "100 cm²", "180 cm²"], 2, "Use base × altura ÷ 2."),
            q("geometry", "Um círculo de raio 10 cm tem área, usando π = 3,14, igual a:", "314 cm²", ["300 cm²", "314 cm²", "328 cm²", "340 cm²"], 1, "Calcule 3,14 × 10²."),
            q("geometry", "Um quadrado possui perímetro 52 cm. Qual seu lado?", "13 cm", ["11 cm", "12 cm", "13 cm", "14 cm"], 2, "Divida o perímetro por 4."),
            q("geometry", "Qual é a área de um trapézio com bases 10 e 16 cm e altura 5 cm?", "65 cm²", ["55 cm²", "60 cm²", "65 cm²", "70 cm²"], 2, "Use A = (B + b) × h ÷ 2."),
            q("geometry", "Qual é a área de um paralelogramo com base 15 cm e altura 8 cm?", "120 cm²", ["100 cm²", "110 cm²", "120 cm²", "130 cm²"], 2, "Multiplique base pela altura.")

        ],

        hard: [
            q("geometry", "Um círculo tem raio 12 cm. Usando π = 3,14, qual é sua área?", "452,16 cm²", ["442,16 cm²", "452,16 cm²", "462,16 cm²", "472,16 cm²"], 1, "Use A = πr²."),
            q("geometry", "Um trapézio tem bases 18 cm e 30 cm e altura 12 cm. Qual sua área?", "288 cm²", ["268 cm²", "278 cm²", "288 cm²", "298 cm²"], 2, "Some as bases, multiplique pela altura e divida por 2."),
            q("geometry", "Um retângulo possui diagonal 13 cm e lado 5 cm. Qual é o outro lado?", "12 cm", ["10 cm", "11 cm", "12 cm", "13 cm"], 2, "Use o teorema de Pitágoras."),
            q("geometry", "Um triângulo retângulo tem catetos 9 cm e 12 cm. Qual é a hipotenusa?", "15 cm", ["13 cm", "14 cm", "15 cm", "16 cm"], 2, "Use a² + b² = c²."),
            q("geometry", "Um círculo tem diâmetro 20 cm. Usando π = 3,14, qual é a área?", "314 cm²", ["300 cm²", "314 cm²", "328 cm²", "340 cm²"], 1, "Primeiro encontre o raio."),
            q("geometry", "Um quadrado tem diagonal 10√2 cm. Qual é seu lado?", "10 cm", ["5 cm", "10 cm", "15 cm", "20 cm"], 1, "Em um quadrado, diagonal = lado × √2."),
            q("geometry", "Um triângulo tem área 84 cm² e base 14 cm. Qual sua altura?", "12 cm", ["10 cm", "12 cm", "14 cm", "16 cm"], 1, "Use 84 = 14 × h ÷ 2."),
            q("geometry", "Um retângulo tem área 180 cm² e perímetro 54 cm. Quais são suas dimensões?", "9 cm e 20 cm", ["8 cm e 22 cm", "9 cm e 20 cm", "10 cm e 18 cm", "12 cm e 15 cm"], 1, "As dimensões devem ter produto 180 e soma 27."),
            q("geometry", "Qual é a área de um losango com diagonais 16 cm e 10 cm?", "80 cm²", ["60 cm²", "70 cm²", "80 cm²", "90 cm²"], 2, "Área do losango = diagonal maior × diagonal menor ÷ 2."),
            q("geometry", "Um setor circular representa metade de um círculo de raio 8 cm. Usando π = 3,14, qual é a área?", "100,48 cm²", ["90,48 cm²", "100,48 cm²", "110,48 cm²", "120,48 cm²"], 1, "Calcule a área do círculo e divida por 2.")

        ]

    },

    averages: {

        easy: [
            q("averages", "Qual é a média de 4 e 8?", "6", ["5", "6", "7", "8"], 1, "Some os dois valores e divida por 2."),
            q("averages", "Qual é a média de 10, 20 e 30?", "20", ["10", "15", "20", "25"], 2, "Some os três valores e divida por 3."),
            q("averages", "Qual é a média de 5, 7 e 9?", "7", ["5", "6", "7", "8"], 2, "Some e divida pela quantidade de números."),
            q("averages", "Qual é a média de 2 e 10?", "6", ["4", "6", "8", "10"], 1, "Some 2 + 10 e divida por 2."),
            q("averages", "Qual é a média de 6, 6 e 9?", "7", ["6", "7", "8", "9"], 1, "Some os três valores."),
            q("averages", "Qual é a média de 12 e 18?", "15", ["12", "14", "15", "18"], 2, "Some e divida por 2."),
            q("averages", "Qual é a média de 3, 6 e 9?", "6", ["4", "5", "6", "7"], 2, "Some os três valores e divida por 3."),
            q("averages", "Qual é a média de 10, 10, 10 e 10?", "10", ["5", "8", "10", "12"], 2, "Todos os valores são iguais."),
            q("averages", "Qual é a média de 8 e 12?", "10", ["8", "9", "10", "12"], 2, "A média está exatamente entre os dois valores."),
            q("averages", "Qual é a média de 15, 20 e 25?", "20", ["15", "18", "20", "22"], 2, "Some e divida por 3.")

        ],

        medium: [
            q("averages", "Qual é a média de 12, 18, 20 e 30?", "20", ["18", "20", "22", "24"], 1, "Some os quatro valores e divida por 4."),
            q("averages", "A média de 5 números é 18. Qual é a soma deles?", "90", ["72", "80", "90", "100"], 2, "Soma = média × quantidade."),
            q("averages", "A média de 4 números é 25. Três deles são 20, 30 e 25. Qual é o quarto?", "25", ["20", "25", "30", "35"], 1, "A soma total precisa ser 100."),
            q("averages", "Qual é a média de 14, 16, 20, 22 e 28?", "20", ["18", "20", "22", "24"], 1, "Some os cinco valores."),
            q("averages", "A média de 6 valores é 15. Qual é a soma?", "90", ["75", "80", "90", "100"], 2, "Multiplique 15 por 6."),
            q("averages", "Qual é a média de 11, 15, 19 e 23?", "17", ["15", "17", "19", "21"], 1, "Some os valores e divida por 4."),
            q("averages", "Qual é a média de 30, 40, 50, 60 e 70?", "50", ["40", "45", "50", "55"], 2, "Os valores são igualmente espaçados."),
            q("averages", "A média de 3 notas é 8. Qual é a soma das notas?", "24", ["16", "20", "24", "28"], 2, "Multiplique média pela quantidade."),
            q("averages", "Qual é a média de 25, 30, 35 e 50?", "35", ["30", "35", "40", "45"], 1, "Some e divida por 4."),
            q("averages", "A média de 8 números é 12,5. Qual é a soma?", "100", ["90", "95", "100", "105"], 2, "Multiplique 12,5 por 8.")

        ],

        hard: [
            q("averages", "A média de 5 números é 24. Quatro são 18, 21, 27 e 30. Qual é o quinto?", "24", ["20", "22", "24", "26"], 2, "A soma total deve ser 120."),
            q("averages", "A média de 8 valores é 17,5. Qual é a soma?", "140", ["130", "135", "140", "145"], 2, "Multiplique 17,5 por 8."),
            q("averages", "A média de 6 números é 22. Cinco deles somam 101. Qual é o sexto?", "31", ["29", "30", "31", "32"], 2, "A soma total deve ser 132."),
            q("averages", "A média de 10 números é 14,6. Qual é a soma?", "146", ["136", "146", "156", "166"], 1, "Multiplique a média pela quantidade."),
            q("averages", "A média de 4 provas é 7,5. As três primeiras notas são 6, 8 e 7. Qual deve ser a quarta nota?", "9", ["8", "9", "10", "11"], 1, "A soma das quatro notas deve ser 30."),
            q("averages", "A média de 7 números é 16. Se um número 22 for retirado, qual será a média dos 6 restantes?", "15", ["14", "15", "16", "17"], 1, "Calcule a soma original e retire 22."),
            q("averages", "A média de 5 valores é 32. Se acrescentarmos um sexto valor 44, qual será a nova média?", "34", ["33", "34", "35", "36"], 1, "Some 160 + 44 e divida por 6."),
            q("averages", "A média de 3 números é 18 e dois deles são 12 e 25. Qual é o terceiro?", "17", ["15", "16", "17", "18"], 2, "A soma dos três deve ser 54."),
            q("averages", "A média de 9 números é 20. Se um número 12 for substituído por 30, qual será a nova média?", "22", ["20", "21", "22", "23"], 1, "A soma aumenta em 18."),
            q("averages", "A média de 12 números é 18,5. Qual é a soma?", "222", ["212", "222", "232", "242"], 1, "Multiplique 18,5 por 12.")

        ]

    }

};


/* =====================================================
   FUNÇÃO PARA CRIAR QUESTÕES
===================================================== */

function q(subject, question, correct, options, correctIndex, hint) {

    return {
        id: Math.random().toString(36).slice(2),
        subject,
        question,
        correct,
        options,
        correctIndex,
        hint,
        explanation: createExplanation(question, correct, subject)
    };

}


/* =====================================================
   EXPLICAÇÕES AUTOMÁTICAS
===================================================== */

function createExplanation(question, answer, subject) {

    if (subject === "bhaskara") {

        return `
            <h3>🧠 Como resolver</h3>

            <p>
                Na equação do 2º grau, identifique
                a, b e c.
            </p>

            <div class="math-expression">
                Δ = b² − 4ac
            </div>

            <p>
                Depois de encontrar Δ, use a fórmula
                de Bhaskara para descobrir x₁ e x₂.
            </p>

            <div class="math-expression">
                x₁ = (−b + √Δ) / 2a
                <br><br>
                x₂ = (−b − √Δ) / 2a
            </div>

            <p>
                Nesta questão, o resultado é:
                <strong>${answer}</strong>
            </p>
        `;

    }

    if (subject === "percentage") {

        return `
            <h3>📊 Resolução</h3>

            <p>
                Transforme a porcentagem em número decimal
                e aplique sobre o valor indicado.
            </p>

            <div class="math-expression">
                porcentagem ÷ 100
            </div>

            <p>
                Resultado: <strong>${answer}</strong>
            </p>
        `;

    }

    if (subject === "fractions") {

        return `
            <h3>🍕 Resolução</h3>

            <p>
                Observe os denominadores e, quando necessário,
                encontre um denominador comum.
            </p>

            <p>
                Resultado: <strong>${answer}</strong>
            </p>
        `;

    }

    if (subject === "powers") {

        return `
            <h3>⚡ Resolução</h3>

            <p>
                Potência representa multiplicações repetidas.
                Quando as bases são iguais, existem propriedades
                específicas para multiplicação e divisão.
            </p>

            <p>
                Resultado: <strong>${answer}</strong>
            </p>
        `;

    }

    if (subject === "roots") {

        return `
            <h3>√ Resolução</h3>

            <p>
                Procure o número que, multiplicado por ele mesmo,
                produz o radicando. Em raízes que podem ser
                simplificadas, procure fatores quadrados perfeitos.
            </p>

            <p>
                Resultado: <strong>${answer}</strong>
            </p>
        `;

    }

    return `
        <h3>🧠 Resolução</h3>

        <p>
            Analise os dados da questão e aplique
            a operação matemática correspondente.
        </p>

        <p>
            Resultado: <strong>${answer}</strong>
        </p>
    `;
}


/* =====================================================
   STORAGE
===================================================== */

function loadPlayer() {

    try {

        const saved = localStorage.getItem("mathQuestPlayer");

        if (!saved) {
            return { ...defaultPlayer };
        }

        return {
            ...defaultPlayer,
            ...JSON.parse(saved)
        };

    } catch (error) {

        return { ...defaultPlayer };

    }

}


function savePlayer() {

    localStorage.setItem(
        "mathQuestPlayer",
        JSON.stringify(player)
    );

}


/* =====================================================
   INICIALIZAÇÃO
===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    updatePlayerUI();
    renderSubjects();
    renderLearnTopics();
    renderPracticeSubjects();

});


/* =====================================================
   TELAS
===================================================== */

function showScreen(id) {

    document.querySelectorAll(".screen").forEach(screen => {

        screen.classList.remove("active");

    });

    const screen = document.getElementById(id);

    if (screen) {
        screen.classList.add("active");
    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


function goHome() {

    exitModalIfOpen();

    showScreen("home");

    updatePlayerUI();

}


function openPlay() {

    renderSubjects();

    showScreen("play");

}


function openLearn() {

    renderLearnTopics();

    showScreen("learn");

}


function openPractice() {

    renderPracticeSubjects();

    showScreen("practice");

}


function openProfile() {

    updateProfile();

    showScreen("profile");

}


function backToSubjects() {

    showScreen("play");

}


function backToLevels() {

    if (selectedSubject) {

        renderLevels();

        showScreen("levels");

    } else {

        openPlay();

    }

}


/* =====================================================
   ASSUNTOS
===================================================== */

function renderSubjects() {

    const container =
        document.getElementById("subjectsContainer");

    if (!container) return;

    container.innerHTML = "";

    subjects.forEach(subject => {

        const button = document.createElement("button");

        button.className = "subject-card";

        button.innerHTML = `

            <div class="subject-icon">
                ${subject.icon}
            </div>

            <strong>
                ${subject.name}
            </strong>

            <small>
                ${subject.description}
            </small>

        `;

        button.onclick = () => openSubject(subject.id);

        container.appendChild(button);

    });

}


function openSubject(subjectId) {

    selectedSubject =
        subjects.find(s => s.id === subjectId);

    if (!selectedSubject) return;

    selectedDifficulty = "easy";

    document.getElementById("levelsTitle").textContent =
        selectedSubject.name;

    document.getElementById("levelSubjectName").textContent =
        selectedSubject.name;

    document.getElementById("levelSubjectDescription").textContent =
        selectedSubject.description;

    document.getElementById("levelSubjectIcon").textContent =
        selectedSubject.icon;

    document.querySelectorAll(".difficulty-btn")
        .forEach(btn => {

            btn.classList.remove("selected");

        });

    document
        .querySelector('[data-difficulty="easy"]')
        ?.classList.add("selected");

    renderLevels();

    showScreen("levels");

}


/* =====================================================
   DIFICULDADE
===================================================== */

function selectDifficulty(difficulty) {

    selectedDifficulty = difficulty;

    document.querySelectorAll(".difficulty-btn")
        .forEach(btn => {

            btn.classList.toggle(
                "selected",
                btn.dataset.difficulty === difficulty
            );

        });

    renderLevels();

}


/* =====================================================
   FASES
===================================================== */

function renderLevels() {

    const container =
        document.getElementById("levelsContainer");

    if (!container || !selectedSubject) return;

    container.innerHTML = "";

    const progressKey =
        selectedSubject.id + "_" + selectedDifficulty;

    const completed =
        player.completedLevels[progressKey] || 0;

    for (let i = 1; i <= 10; i++) {

        const level = document.createElement("button");

        level.className = "quest-level";

        let locked = i > completed + 1;

        if (i <= completed) {
            level.classList.add("completed");
        }

        if (i === completed + 1) {
            level.classList.add("current");
        }

        if (locked) {
            level.classList.add("locked");
        }

        const stars =
            i <= completed
                ? "⭐⭐⭐"
                : i === completed + 1
                    ? "⭐"
                    : "🔒";

        level.innerHTML = `

            <strong>
                Fase ${i}
            </strong>

            <small>
                ${locked
                    ? "Bloqueada"
                    : i <= completed
                        ? "Concluída"
                        : "Começar fase"}
            </small>

            <span class="stars">
                ${stars}
            </span>

        `;

        if (!locked) {

            level.onclick = () => {
                startLevel(i);
            };

        }

        container.appendChild(level);

    }

    updateFinalTestButton();

}


/* =====================================================
   INICIAR FASE
===================================================== */

function startLevel(levelNumber) {

    if (!selectedSubject) return;

    quizMode = "level";
    practiceMode = false;

    currentLevelNumber = levelNumber;

    const source =
        questionBank[selectedSubject.id]?.[selectedDifficulty];

    if (!source || source.length === 0) {

        alert("Ainda não existem questões para este assunto.");

        return;

    }

    currentQuestions =
        shuffle([...source]).slice(
            0,
            Math.min(QUESTIONS_PER_LEVEL, source.length)
        );

    currentQuestionIndex = 0;
    currentScore = 0;
    currentLives = 3;

    hintUsed = false;
    removeUsed = false;
    explainUsed = false;
    answerLocked = false;

    resetHelpButtons();

    showScreen("quiz");

    renderQuestion();

}


/* =====================================================
   PRATICAR
===================================================== */

function renderPracticeSubjects() {

    const container =
        document.getElementById("practiceSubjects");

    if (!container) return;

    container.innerHTML = "";

    subjects.forEach(subject => {

        const button = document.createElement("button");

        button.className = "practice-button";

        button.innerHTML = `
            ${subject.icon}
            &nbsp;&nbsp;
            ${subject.name}
        `;

        button.onclick = () => startPractice(subject.id);

        container.appendChild(button);

    });

}


function startPractice(subjectId) {

    selectedSubject =
        subjects.find(s => s.id === subjectId);

    if (!selectedSubject) return;

    quizMode = "practice";
    practiceMode = true;

    const easy =
        questionBank[subjectId]?.easy || [];

    const medium =
        questionBank[subjectId]?.medium || [];

    const hard =
        questionBank[subjectId]?.hard || [];

    const all =
        shuffle([
            ...easy,
            ...medium,
            ...hard
        ]);

    currentQuestions =
        all.slice(0, QUESTIONS_PER_LEVEL);

    currentQuestionIndex = 0;
    currentScore = 0;
    currentLives = 3;

    hintUsed = false;
    removeUsed = false;
    explainUsed = false;
    answerLocked = false;

    resetHelpButtons();

    showScreen("quiz");

    renderQuestion();

}


/* =====================================================
   DESAFIO
===================================================== */

function startChallenge() {

    const all = [];

    Object.keys(questionBank).forEach(subject => {

        Object.keys(questionBank[subject]).forEach(diff => {

            all.push(
                ...questionBank[subject][diff]
            );

        });

    });

    if (!all.length) return;

    currentQuestions =
        [shuffle(all)[0]];

    currentQuestionIndex = 0;
    currentScore = 0;
    currentLives = 3;

    quizMode = "challenge";
    practiceMode = true;

    hintUsed = false;
    removeUsed = false;
    explainUsed = false;
    answerLocked = false;

    resetHelpButtons();

    showScreen("quiz");

    renderQuestion();

}


/* =====================================================
   QUESTÃO
===================================================== */

function renderQuestion() {

    if (!currentQuestions.length) return;

    const question =
        currentQuestions[currentQuestionIndex];

    if (!question) return;

    answerLocked = false;

    const total =
        currentQuestions.length;

    const number =
        currentQuestionIndex + 1;

    const counter =
        document.getElementById("quizCounter");

    const xp =
        document.getElementById("quizXp");

    const bar =
        document.getElementById("quizBar");

    if (counter) {
        counter.textContent =
            `${number}/${total}`;
    }

    if (xp) {
        xp.textContent =
            `+${XP_PER_CORRECT} XP`;
    }

    if (bar) {
        bar.style.width =
            `${((number - 1) / total) * 100}%`;
    }

    updateLives();

    const box =
        document.getElementById("questionBox");

    if (!box) return;

    const subject =
        subjects.find(
            s => s.id === question.subject
        );

    const topicName =
        subject
            ? subject.name
            : "Matemática";

    const optionsHTML =
        question.options.map(
            (option, index) => {

                const letter =
                    String.fromCharCode(65 + index);

                return `

                    <button
                        class="option"
                        data-index="${index}"
                        onclick="answerQuestion(${index})">

                        <span class="option-letter">
                            ${letter}
                        </span>

                        <span>
                            ${option}
                        </span>

                    </button>

                `;

            }
        ).join("");

    box.innerHTML = `

        <div class="question-card">

            <div class="question-topic">
                ${subject?.icon || "🧠"} ${topicName}
            </div>

            <h2 class="question-title">
                ${question.question}
            </h2>

        </div>

        <div class="options">
            ${optionsHTML}
        </div>

        <div id="questionFeedback"></div>

    `;

}


/* =====================================================
   RESPONDER
===================================================== */

function answerQuestion(index) {

    if (answerLocked) return;

    const question =
        currentQuestions[currentQuestionIndex];

    if (!question) return;

    const buttons =
        document.querySelectorAll(
            "#questionBox .option"
        );

    const chosen =
        buttons[index];

    if (!chosen) return;

    answerLocked = true;

    const isCorrect =
        index === question.correctIndex;

    buttons.forEach((button, i) => {

        button.disabled = true;

        if (i === question.correctIndex) {

            button.classList.add("correct");

        }

    });

    if (isCorrect) {

        chosen.classList.add("correct");

        currentScore++;

        showFeedback(
            true,
            question
        );

    } else {

        chosen.classList.add("wrong");

        currentLives--;

        showFeedback(
            false,
            question
        );

    }

    updateLives();

    if (currentLives <= 0) {

        setTimeout(() => {

            finishQuiz(false);

        }, 1200);

        return;

    }

    setTimeout(() => {

        nextQuestion();

    }, 1400);

}


/* =====================================================
   FEEDBACK
===================================================== */

function showFeedback(correct, question) {

    const feedback =
        document.getElementById(
            "questionFeedback"
        );

    if (!feedback) return;

    feedback.innerHTML = `

        <div class="feedback">

            <h3>
                ${correct
                    ? "🎉 Muito bem!"
                    : "💡 Quase!"}
            </h3>

            <p>
                ${correct
                    ? "Você acertou!"
                    : `A resposta correta é: <strong>${question.correct}</strong>`}
            </p>

        </div>

    `;

}


/* =====================================================
   PRÓXIMA QUESTÃO
===================================================== */

function nextQuestion() {

    currentQuestionIndex++;

    if (
        currentQuestionIndex >=
        currentQuestions.length
    ) {

        finishQuiz(true);

        return;

    }

    renderQuestion();

}


/* =====================================================
   FINALIZAR QUIZ
===================================================== */

function finishQuiz(completedNormally) {

    const total =
        currentQuestions.length;

    const score =
        currentScore;

    const passed =
        completedNormally &&
        score >= Math.ceil(total * 0.6);

    let earnedXP = 0;
    let earnedStars = 0;

    if (passed) {

        earnedXP =
            score * XP_PER_CORRECT;

        earnedStars =
            score >= total
                ? 3
                : score >= Math.ceil(total * 0.8)
                    ? 2
                    : 1;

    } else {

        earnedXP =
            Math.max(
                0,
                score * 5
            );

    }

    player.questions += total;
    player.correct += score;

    player.xp += earnedXP;
    player.stars += earnedStars;

    updatePlayerLevel();

    if (
        quizMode === "level" &&
        passed &&
        selectedSubject
    ) {

        const key =
            selectedSubject.id +
            "_" +
            selectedDifficulty;

        const old =
            player.completedLevels[key] || 0;

        if (currentLevelNumber > old) {

            player.completedLevels[key] =
                currentLevelNumber;

        }

    }

    savePlayer();

    showResult(
        passed,
        score,
        total,
        earnedXP,
        earnedStars
    );

}


/* =====================================================
   RESULTADO
===================================================== */

function showResult(
    passed,
    score,
    total,
    earnedXP,
    earnedStars
) {

    const icon =
        document.getElementById("resultIcon");

    const label =
        document.getElementById("resultLabel");

    const title =
        document.getElementById("resultTitle");

    const scoreElement =
        document.getElementById("resultScore");

    const xp =
        document.getElementById("resultXp");

    const stars =
        document.getElementById("resultStars");

    const message =
        document.getElementById("resultMessage");

    if (icon) {
        icon.textContent =
            passed ? "🏆" : "💪";
    }

    if (label) {
        label.textContent =
            passed
                ? "FASE CONCLUÍDA"
                : "TENTE NOVAMENTE";
    }

    if (title) {
        title.textContent =
            passed
                ? "Muito bem!"
                : "Você consegue!";
    }

    if (scoreElement) {
        scoreElement.textContent =
            `${score}/${total}`;
    }

    if (xp) {
        xp.textContent =
            `+${earnedXP}`;
    }

    if (stars) {
        stars.textContent =
            `+${earnedStars}`;
    }

    if (message) {

        const percentage =
            Math.round(
                (score / total) * 100
            );

        message.innerHTML =
            passed
                ? `
                    Você conseguiu ${percentage}% de acerto.
                    Continue avançando para desbloquear
                    novas fases!
                `
                : `
                    Você conseguiu ${percentage}%.
                    A prova/fase precisa de pelo menos
                    60% para ser concluída.
                    Tente novamente!
                `;

    }

    showScreen("result");

}


/* =====================================================
   VIDAS
===================================================== */

function updateLives() {

    const element =
        document.getElementById("lives");

    if (element) {

        element.textContent =
            currentLives;

    }

}


/* =====================================================
   DICA
===================================================== */

function useHint() {

    if (hintUsed) return;

    const question =
        currentQuestions[currentQuestionIndex];

    if (!question) return;

    hintUsed = true;

    const button =
        document.getElementById("hintCard");

    button?.classList.add("used");

    showHelp(`
        <h2>💡 Dica</h2>
        <p>${question.hint}</p>
    `);

}


/* =====================================================
   ELIMINAR ALTERNATIVA
===================================================== */

function useRemoveOption() {

    if (removeUsed || answerLocked) return;

    const question =
        currentQuestions[currentQuestionIndex];

    if (!question) return;

    removeUsed = true;

    const button =
        document.getElementById("removeCard");

    button?.classList.add("used");

    const options =
        [...document.querySelectorAll(
            "#questionBox .option"
        )];

    const wrong =
        options.filter(
            (_, index) =>
                index !== question.correctIndex
        );

    const toRemove =
        shuffle(wrong).slice(0, 2);

    toRemove.forEach(option => {

        option.classList.add("disabled");

        option.disabled = true;

    });

}


/* =====================================================
   EXPLICAR
===================================================== */

function showConceptHelp() {

    if (explainUsed) return;

    const question =
        currentQuestions[currentQuestionIndex];

    if (!question) return;

    explainUsed = true;

    const button =
        document.getElementById("explainCard");

    button?.classList.add("used");

    showHelp(question.explanation);

}


/* =====================================================
   MODAL HELP
===================================================== */

function showHelp(content) {

    const modal =
        document.getElementById("helpModal");

    const box =
        document.getElementById("helpContent");

    if (!modal || !box) return;

    box.innerHTML = content;

    modal.classList.remove("hidden");

}


function closeHelp() {

    document
        .getElementById("helpModal")
        ?.classList.add("hidden");

}


/* =====================================================
   APRENDIZADO
===================================================== */

function renderLearnTopics() {

    const container =
        document.getElementById("learnTopics");

    if (!container) return;

    container.innerHTML = "";

    subjects.forEach(subject => {

        const card =
            document.createElement("div");

        card.innerHTML = `

            <strong>
                ${subject.icon} ${subject.name}
            </strong>

            <p style="
                color:#9299b5;
                font-size:11px;
                margin-top:6px;
            ">
                ${subject.description}
            </p>

        `;

        card.style.cursor = "pointer";

        card.onclick = () => {

            showLearnModal(subject);

        };

        container.appendChild(card);

    });

}


function showLearnModal(subject) {

    const modal =
        document.getElementById("learnModal");

    const content =
        document.getElementById("learnContent");

    if (!modal || !content) return;

    content.innerHTML =
        subject.learn;

    modal.classList.remove("hidden");

}


function closeLearnModal() {

    document
        .getElementById("learnModal")
        ?.classList.add("hidden");

}


/* =====================================================
   BOTÕES DE AJUDA
===================================================== */

function resetHelpButtons() {

    document.querySelectorAll(
        ".help-cards button"
    ).forEach(button => {

        button.classList.remove("used");

    });

}


/* =====================================================
   PROVA FINAL
===================================================== */

function updateFinalTestButton() {

    const button =
        document.querySelector(
            ".final-test-card button"
        );

    if (!button || !selectedSubject) return;

    const key =
        selectedSubject.id +
        "_" +
        selectedDifficulty;

    const completed =
        player.completedLevels[key] || 0;

    if (completed >= 10) {

        button.textContent = "🏆";
        button.disabled = false;

    } else {

        button.textContent = "🔒";
        button.disabled = true;

    }

}


function startFinalTest() {

    if (!selectedSubject) return;

    const key =
        selectedSubject.id +
        "_" +
        selectedDifficulty;

    const completed =
        player.completedLevels[key] || 0;

    if (completed < 10) {

        alert(
            "Complete as 10 fases para liberar a prova final."
        );

        return;

    }

    const source =
        questionBank[selectedSubject.id]?.[selectedDifficulty];

    if (!source) return;

    currentQuestions =
        shuffle([...source]).slice(
            0,
            QUESTIONS_PER_FINAL
        );

    currentQuestionIndex = 0;
    currentScore = 0;
    currentLives = 3;

    quizMode = "final";
    practiceMode = false;

    hintUsed = false;
    removeUsed = false;
    explainUsed = false;

    resetHelpButtons();

    showScreen("quiz");

    renderQuestion();

}


/* =====================================================
   PERFIL
===================================================== */

function updateProfile() {

    const level =
        document.getElementById("profileLevel");

    const xp =
        document.getElementById("profileXP");

    const stars =
        document.getElementById("profileStars2");

    const questions =
        document.getElementById("profileQuestions");

    const accuracy =
        document.getElementById("profileAccuracy");

    const progress =
        document.getElementById("profileProgress");

    if (level) {

        level.textContent =
            `Nível ${player.level}`;

    }

    if (xp) {

        xp.textContent =
            player.xp;

    }

    if (stars) {

        stars.textContent =
            player.stars;

    }

    if (questions) {

        questions.textContent =
            player.questions;

    }

    if (accuracy) {

        accuracy.textContent =
            calculateAccuracy() + "%";

    }

    if (progress) {

        progress.textContent =
            `${countCompletedLevels()} fases concluídas`;

    }

}


/* =====================================================
   UI DO JOGADOR
===================================================== */

function updatePlayerUI() {

    updatePlayerLevel();

    const name =
        document.getElementById("playerName");

    const level =
        document.getElementById("playerLevel");

    const xpText =
        document.getElementById("xpText");

    const xpBar =
        document.getElementById("xpBar");

    const homeStars =
        document.getElementById("homeStars");

    const homeQuestions =
        document.getElementById("homeQuestions");

    const homeCorrect =
        document.getElementById("homeCorrect");

    if (name) {

        name.textContent =
            player.name;

    }

    if (level) {

        level.textContent =
            `Nível ${player.level}`;

    }

    const xpInsideLevel =
        player.xp %
        XP_PER_LEVEL;

    if (xpText) {

        xpText.textContent =
            `${xpInsideLevel} / ${XP_PER_LEVEL} XP`;

    }

    if (xpBar) {

        xpBar.style.width =
            `${xpInsideLevel}%`;

    }

    if (homeStars) {

        homeStars.textContent =
            player.stars;

    }

    if (homeQuestions) {

        homeQuestions.textContent =
            player.questions;

    }

    if (homeCorrect) {

        homeCorrect.textContent =
            calculateAccuracy() + "%";

    }

}


/* =====================================================
   NÍVEL
===================================================== */

function updatePlayerLevel() {

    player.level =
        Math.floor(
            player.xp / XP_PER_LEVEL
        ) + 1;

}


/* =====================================================
   ACERTOS
===================================================== */

function calculateAccuracy() {

    if (!player.questions) {

        return 0;

    }

    return Math.round(
        (player.correct /
            player.questions) *
        100
    );

}


/* =====================================================
   FASES CONCLUÍDAS
===================================================== */

function countCompletedLevels() {

    return Object.values(
        player.completedLevels
    ).reduce(
        (sum, value) =>
            sum + Number(value || 0),
        0
    );

}


/* =====================================================
   RESET
===================================================== */

function resetProgress() {

    const confirmReset =
        confirm(
            "Tem certeza que deseja apagar todo o progresso?"
        );

    if (!confirmReset) return;

    player = {
        ...defaultPlayer,
        completedLevels: {},
        completedFinal: {}
    };

    savePlayer();

    updatePlayerUI();

    updateProfile();

    if (selectedSubject) {

        renderLevels();

    }

    alert(
        "Progresso resetado!"
    );

}


/* =====================================================
   SAIR DO QUIZ
===================================================== */

function exitQuiz() {

    const confirmExit =
        confirm(
            "Deseja sair desta fase? O progresso desta tentativa será perdido."
        );

    if (!confirmExit) return;

    if (practiceMode || quizMode === "challenge") {

        openPractice();

    } else if (selectedSubject) {

        renderLevels();

        showScreen("levels");

    } else {

        goHome();

    }

}


/* =====================================================
   MODAIS
===================================================== */

function exitModalIfOpen() {

    closeHelp();
    closeLearnModal();

}


/* =====================================================
   EMBARALHAR
===================================================== */

function shuffle(array) {

    const result =
        [...array];

    for (
        let i = result.length - 1;
        i > 0;
        i--
    ) {

        const j =
            Math.floor(
                Math.random() * (i + 1)
            );

        [
            result[i],
            result[j]
        ] = [
            result[j],
            result[i]
        ];

    }

    return result;

}


/* =====================================================
   FECHAR MODAL CLICANDO FORA
===================================================== */

document.addEventListener(
    "click",
    event => {

        const help =
            document.getElementById("helpModal");

        const learn =
            document.getElementById("learnModal");

        if (
            event.target === help
        ) {

            closeHelp();

        }

        if (
            event.target === learn
        ) {

            closeLearnModal();

        }

    }
);


/* =====================================================
   TECLADO
===================================================== */

document.addEventListener(
    "keydown",
    event => {

        if (
            !document
                .getElementById("quiz")
                ?.classList.contains("active")
        ) {

            return;

        }

        if (
            answerLocked
        ) {

            return;

        }

        const key =
            event.key.toLowerCase();

        if (
            ["1", "2", "3", "4"].includes(key)
        ) {

            answerQuestion(
                Number(key) - 1
            );

        }

    }
);


/* =====================================================
   GARANTIR BANCO COMPLETO
===================================================== */

function validateQuestionBank() {

    let total = 0;

    Object.keys(questionBank).forEach(subject => {

        Object.keys(
            questionBank[subject]
        ).forEach(difficulty => {

            const list =
                questionBank[subject][difficulty];

            total += list.length;

        });

    });

    console.log(
        "Math Quest — questões carregadas:",
        total
    );

}


/* =====================================================
   ATUALIZAÇÃO FINAL
===================================================== */

validateQuestionBank();
updatePlayerUI();