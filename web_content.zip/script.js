let walletName = "";
let balance = 0;
let history = [];
let currentOperation = "";

function createWallet() {
  const input = document.getElementById("walletName");
  const name = input.value.trim();

  if (!name) {
    alert("اكتب اسم المحفظة أولاً");
    input.focus();
    return;
  }

  walletName = name;
  document.getElementById("walletTitle").textContent = walletName;
  document.getElementById("setupPage").classList.add("hidden");
  document.getElementById("appPage").classList.remove("hidden");
}

function addMoney() {
  openModal("add");
}

function withdrawMoney() {
  openModal("withdraw");
}

function openModal(type) {
  currentOperation = type;

  const modal = document.getElementById("modal");
  const title = document.getElementById("modalTitle");
  const text = document.getElementById("modalText");
  const icon = document.getElementById("modalIcon");
  const confirm = document.getElementById("confirmBtn");
  const input = document.getElementById("amountInput");

  if (type === "add") {
    title.textContent = "إضافة مبلغ";
    text.textContent = "أدخل المبلغ الذي تريد إضافته";
    icon.textContent = "＋";
    confirm.textContent = "إضافة إلى المحفظة";
    confirm.style.background = "#111827";
  } else {
    title.textContent = "سحب مبلغ";
    text.textContent = "أدخل المبلغ الذي تريد سحبه";
    icon.textContent = "−";
    confirm.textContent = "تأكيد السحب";
    confirm.style.background = "#e85d5d";
  }

  input.value = "";
  modal.classList.remove("hidden");

  setTimeout(() => input.focus(), 100);
}

function closeModal() {
  document.getElementById("modal").classList.add("hidden");
  currentOperation = "";
}

function confirmOperation() {
  const input = document.getElementById("amountInput");
  const amount = Number(input.value);

  if (!Number.isFinite(amount) || amount <= 0) {
    alert("أدخل مبلغًا صحيحًا");
    return;
  }

  if (currentOperation === "withdraw" && amount > balance) {
    alert("لا يمكنك سحب مبلغ أكبر من الرصيد الحالي");
    return;
  }

  if (currentOperation === "add") {
    balance += amount;
  } else {
    balance -= amount;
  }

  history.unshift({
    type: currentOperation,
    amount: amount,
    date: new Date()
  });

  updateBalance();
  updateHistory();
  closeModal();
}

function updateBalance() {
  document.getElementById("balance").textContent =
    formatMoney(balance) + " دج";
}

function formatMoney(value) {
  return Math.round(value).toLocaleString("ar-DZ");
}

function updateHistory() {
  const container = document.getElementById("history");
  const count = document.getElementById("operationCount");

  count.textContent = history.length + (history.length === 1 ? " عملية" : " عمليات");

  if (history.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">↕</div>
        <strong>لا توجد عمليات</strong>
        <p>ستظهر عمليات الإضافة والسحب هنا</p>
      </div>
    `;
    return;
  }

  container.innerHTML = history.map(operation => {
    const isAdd = operation.type === "add";
    const title = isAdd ? "إضافة مبلغ" : "سحب مبلغ";
    const sign = isAdd ? "+" : "-";
    const icon = isAdd ? "＋" : "−";

    return `
      <div class="operation ${isAdd ? "add-operation" : "withdraw-operation"}">
        <div class="operation-info">
          <div class="operation-icon">${icon}</div>
          <div>
            <div class="operation-title">${title}</div>
            <div class="operation-date">${formatDate(operation.date)}</div>
          </div>
        </div>
        <div class="operation-amount">${sign}${formatMoney(operation.amount)} دج</div>
      </div>
    `;
  }).join("");
}

function formatDate(date) {
  return new Date(date).toLocaleString("ar-DZ", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

document.getElementById("modal").addEventListener("click", function(event) {
  if (event.target === this) closeModal();
});

document.getElementById("walletName").addEventListener("keydown", function(event) {
  if (event.key === "Enter") createWallet();
});

document.getElementById("amountInput").addEventListener("keydown", function(event) {
  if (event.key === "Enter") confirmOperation();
});
