let score = 0;

let scoreDisplay = document.getElementById("score");
let tapButton = document.getElementById("tapButton");
let resetButton = document.getElementById("resetButton");

tapButton.onclick = function()
{
    score++;
    scoreDisplay.innerText = score;
};

resetButton.onclick = function()
{
    score = 0;
    scoreDisplay.innerText = score;
};
