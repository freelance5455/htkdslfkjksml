
const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");

const player = { x: 150, y: 200, r: 10, speed: 4 };
let score = 0;
let gameOver = false;
let bullets = [];
let enemies = [];
let keys = {};

function restart() {
  player.x = canvas.width / 2;
  player.y = canvas.height / 2;
  score = 0;
  gameOver = false;
  bullets = [];
  enemies = [];
  for (let i = 0; i < 3; i++) {
    enemies.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: 12
    });
  }
}

document.addEventListener("keydown", e => {
  keys[e.key.toLowerCase()] = true;
  if (e.code === "Space") shoot();
});

document.addEventListener("keyup", e => {
  keys[e.key.toLowerCase()] = false;
});

function move(dx, dy) {
  if (gameOver) return;
  player.x = Math.max(player.r, Math.min(canvas.width - player.r, player.x + dx));
  player.y = Math.max(player.r, Math.min(canvas.height - player.r, player.y + dy));
}

function shoot() {
  if (gameOver) return;
  bullets.push({ x: player.x, y: player.y - 12, r: 4 });
}

function update() {
  if (!gameOver) {
    if (keys.arrowup || keys.w) move(0, -player.speed);
    if (keys.arrowdown || keys.s) move(0, player.speed);
    if (keys.arrowleft || keys.a) move(-player.speed, 0);
    if (keys.arrowright || keys.d) move(player.speed, 0);

    bullets.forEach(b => b.y -= 6);

    bullets = bullets.filter(b => b.y > 0);

    for (const b of bullets) {
      for (const enemy of enemies) {
        if (Math.hypot(b.x - enemy.x, b.y - enemy.y) < b.r + enemy.r) {
          enemy.x = Math.random() * canvas.width;
          enemy.y = Math.random() * canvas.height;
          b.y = -100;
          score += 10;
        }
      }
    }

    for (const enemy of enemies) {
      const d = Math.hypot(player.x - enemy.x, player.y - enemy.y);
      if (d < player.r + enemy.r) gameOver = true;
    }
  }
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.fillStyle = "#ffd43b";
  ctx.beginPath();
  ctx.arc(canvas.width * 0.25, canvas.height * 0.2, 7, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#ff5263";
  enemies.forEach(e => {
    ctx.beginPath();
    ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.fillStyle = "#38c9ff";
  ctx.beginPath();
  ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "white";
  bullets.forEach(b => {
    ctx.beginPath();
    ctx.arc(b.x, b.y, b.r, 0, Math.PI * 2);
    ctx.fill();
  });

  requestAnimationFrame(loop);
}

function loop() {
  update();
  draw();
}

restart();
loop();
