'use strict';

/* =====================================================
   ✏️ এখানেই সব কাস্টমাইজ করো (নাম, তারিখ, মেসেজ, ছবি)
   ===================================================== */
const CONFIG = {
  // দুজনের নাম
  name1: 'ইসরাফিল',
  name2: 'জেসমিনা',          // ✏️ তার নাম এখানে লেখো

  // কবে থেকে একসাথে (বছর-মাস-দিন)
  startDate: '2025-08-14T00:00:00',   // ✏️ নিজের তারিখ বসাও

  // হোয়াটসঅ্যাপ নম্বর (দেশের কোড সহ, + ছাড়া)। 91 = ভারত
  whatsapp: '919112756851',
  waText: 'হ্যালো ❤️',

  // গান চালাতে চাইলে music ফোল্ডারে song.mp3 রাখো। না থাকলে গানের বাটন লুকিয়ে থাকবে
  music: 'music/song.mp3',

  // ১০টা ছবি: images ফোল্ডারে 1.jpg … 10.jpg রাখো
  photos: [
    { src: 'images/1.jpg',  caption: 'আমাদের প্রথম ছবি' },
    { src: 'images/2.jpg',  caption: 'তোমার হাসিটা' },
    { src: 'images/3.jpg',  caption: 'একসাথে ঘুরতে যাওয়া' },
    { src: 'images/4.jpg',  caption: 'সেই বিকেলটা' },
    { src: 'images/5.jpg',  caption: 'আমাদের খুনসুটি' },
    { src: 'images/6.jpg',  caption: 'প্রিয় মুহূর্ত' },
    { src: 'images/7.jpg',  caption: 'তুমি আর আমি' },
    { src: 'images/8.jpg',  caption: 'ভালোবাসার দিন' },
    { src: 'images/9.jpg',  caption: 'একসাথে স্বপ্ন দেখা' },
    { src: 'images/10.jpg', caption: 'চিরকালের জন্য' }
  ],

  // মুহূর্তের বাটন (১৪টা)। বাটন বাড়াতে একটা লাইন কপি করে বসাও
  // photo: কোন ছবি খুলবে | message: ট্যাপ করলে যে মেসেজ আসবে
  moments: [
    { icon: '👀', title: 'প্রথম দেখা',        photo: 'images/1.jpg',  message: 'সেদিন প্রথম তোমাকে দেখলাম আর মনে হলো সময়টা থমকে গেছে। ✏️ এখানে প্রথম দেখার গল্প লেখো।' },
    { icon: '💫', title: 'দ্বিতীয় দেখা',      photo: 'images/2.jpg',  message: 'দ্বিতীয়বার যখন দেখা হলো, বুঝলাম এটা শুধু কাকতালীয় না। ✏️ নিজের কথা লেখো।' },
    { icon: '💬', title: 'প্রথম কথা',          photo: 'images/3.jpg',  message: 'প্রথম যেদিন কথা হলো, বুক কাঁপছিল কিন্তু তোমার গলা শুনে সব ভয় চলে গেল। ✏️ কী কথা হয়েছিল লেখো।' },
    { icon: '😊', title: 'প্রথম হাসি',          photo: 'images/4.jpg',  message: 'তোমার হাসিটা আমার সবচেয়ে প্রিয় জিনিস। ওই হাসির জন্যই আমি সব করতে পারি।' },
    { icon: '🎁', title: 'প্রথম উপহার',        photo: 'images/5.jpg',  message: 'উপহারের দাম নয়, তার পেছনের ভালোবাসাটাই আসল। ✏️ কী উপহার ছিল লেখো।' },
    { icon: '🥺', title: 'প্রথম অভিমান',       photo: 'images/6.jpg',  message: 'সেদিন তুমি রাগ করেছিলে আর আমার মনটা খারাপ হয়ে গিয়েছিল। এখন ভাবলে হাসি পায়, কারণ ওই অভিমানেই বুঝেছি তুমি কত আপন।' },
    { icon: '📞', title: 'প্রথম ফোনকল',        photo: 'images/7.jpg',  message: 'ফোনে তোমার গলা শুনে রাত কেটে গিয়েছিল, টেরই পাইনি। ✏️ নিজের মতো করে লেখো।' },
    { icon: '💌', title: 'প্রথম "ভালোবাসি"',   photo: 'images/8.jpg',  message: 'ওই তিনটা শব্দ বলতে কত সাহস লেগেছিল, জানো? কিন্তু বলার পর মনে হলো পৃথিবীর সবচেয়ে সুন্দর কাজটা করলাম।' },
    { icon: '🤝', title: 'প্রথম হাত ধরা',      photo: 'images/9.jpg',  message: 'তোমার হাতটা ধরার সেই প্রথম মুহূর্তে মনে হয়েছিল, আমি আর কখনো ছাড়বো না।' },
    { icon: '🎵', title: 'আমাদের গান',        photo: 'images/10.jpg', message: 'কিছু গান শুনলেই তোমার মুখটা ভেসে ওঠে। ✏️ আমাদের প্রিয় গানের নাম লেখো।' },
    { icon: '⏳', title: 'অপেক্ষার দিন',       photo: 'images/3.jpg',  message: 'যেদিন দেখা হয়নি, সেদিন প্রতিটা ঘণ্টা বছরের মতো লেগেছে। অপেক্ষার পরের দেখাটা তাই এত মিষ্টি।' },
    { icon: '🏡', title: 'আমাদের স্বপ্ন',      photo: 'images/5.jpg',  message: 'একটা ছোট্ট ঘর, বারান্দায় দুটো চায়ের কাপ আর তুমি। আমার আর কিছু চাই না।' },
    { icon: '🌹', title: 'ক্ষমা ও ভরসা',      photo: 'images/7.jpg',  message: 'আমরা ভুল করেছি, ক্ষমাও করেছি। প্রতিবার আরও শক্ত হয়েছে আমাদের ভরসা।' },
    { icon: '💍', title: 'চিরকাল',            photo: 'images/8.jpg',  message: 'যতদিন বাঁচবো, তোমার হাত ধরেই বাঁচতে চাই। তুমি আমার আজ, আমার কাল, আমার সব।' }
  ],

  // "কেন তোমাকে ভালোবাসি" এর কারণ
  reasons: [
    'তোমার হাসি দেখলে আমার সব কষ্ট ভুলে যাই।',
    'তুমি আমার ভুলগুলো বুঝে নাও, তাও পাশে থাকো।',
    'তোমার গলার স্বর আমার কাছে সবচেয়ে সুন্দর গান।',
    'তুমি রাগ করলেও তোমাকে সুন্দর লাগে।',
    'তুমি আছো বলেই আমি আরও ভালো মানুষ হতে চাই।',
    'তোমার ছোট ছোট যত্নগুলো আমাকে সারাদিন ভালো রাখে।',
    'তুমি আমার সবচেয়ে ভালো বন্ধু।',
    'তোমার সাথে নীরবে বসে থাকাটাও আমার কাছে শান্তি।',
    'তুমি আমাকে স্বপ্ন দেখতে শিখিয়েছো।',
    'তোমার চোখের দিকে তাকালে নিজেকে ঘরে ফেরা মনে হয়।',
    'তুমি আমার কঠিন সময়ে সবচেয়ে বড় ভরসা ছিলে।',
    'তুমি তুমি, আর এটাই যথেষ্ট কারণ।'
  ],

  // ভালোবাসার কথা
  quotes: [
    'ভালোবাসা মানে একসাথে সব ঝড় পেরিয়ে একই ছাদের নিচে ফিরে আসা।',
    'তুমি পাশে থাকলে সাধারণ দিনও উৎসব হয়ে যায়।',
    'দূরত্ব ভালোবাসাকে কমায় না, শুধু অপেক্ষাকে মিষ্টি করে।',
    'সবচেয়ে সুন্দর গল্প সেটাই, যেটা দুজন মিলে লেখে।',
    'হাজার মানুষের ভিড়েও আমার চোখ খুঁজে নেয় শুধু তোমাকে।',
    'ভালোবাসা দিন গুনে না, মুহূর্ত জমায়।',
    'তোমার হাতটা ধরে থাকলে পৃথিবীটা ছোট মনে হয়।',
    'আমি কবি নই, তবু তোমাকে নিয়ে লিখতে ইচ্ছা করে।'
  ],

  // মিষ্টি মেসেজ
  sweetMessages: [
    'আজ কি তুমি জানো, তুমি আমার পৃথিবী? 🌍💖',
    'খেয়েছো? না খেলে কিন্তু আমি রাগ করবো! 🍚',
    'তোমাকে মিস করছি, এক্ষুনি জড়িয়ে ধরতে ইচ্ছা করছে 🤗',
    'আজকের দিনটা তোমার জন্য সুন্দর হোক ☀️',
    'তুমি হাসলে আমার দিন ভালো যায় 😊',
    'ঘুমানোর আগে একবার আমাকে মনে করো, আমি তোমার স্বপ্নে আসবো 🌙'
  ]
};

/* =====================================================
   এর নিচে কিছু না বদলালেও চলবে
   ===================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const rand = (a, b) => a + Math.random() * (b - a);
const pick = arr => arr[Math.floor(Math.random() * arr.length)];
const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
const bn = n => String(n).replace(/\d/g, d => '০১২৩৪৫৬৭৮৯'[d]);
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* কিছু করার নেই */ } }
};

/* নাম ও হোয়াটসঅ্যাপ লিংক বসানো */
$$('[data-name="1"]').forEach(e => e.textContent = CONFIG.name1);
$$('[data-name="2"]').forEach(e => e.textContent = CONFIG.name2);
document.title = CONFIG.name1 + ' ♥ ' + CONFIG.name2;
$$('[data-wa]').forEach(a => {
  a.href = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(CONFIG.waText);
});

/* টোস্ট মেসেজ */
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

/* =====================================================
   থিম (ডার্ক / লাইট)
   ===================================================== */
const root = document.documentElement;
function setTheme(t) {
  root.dataset.theme = t;
  $('#themeBtn').textContent = t === 'dark' ? '🌙' : '☀️';
  const meta = $('meta[name="theme-color"]');
  if (meta) meta.content = t === 'dark' ? '#2a0716' : '#ffeaf2';
  store.set('theme', t);
  readPetalColors();
}
$('#themeBtn').addEventListener('click', () => setTheme(root.dataset.theme === 'dark' ? 'light' : 'dark'));

/* =====================================================
   গোলাপের পাপড়ি পড়ছে
   ===================================================== */
const cv = $('#petals');
const ctx = cv.getContext('2d');
let W = 0, H = 0, petals = [], colors = ['#ff7fb0', '#c2185b'];

function readPetalColors() {
  const cs = getComputedStyle(root);
  colors = [cs.getPropertyValue('--petal1').trim(), cs.getPropertyValue('--petal2').trim(), '#ff3d85'];
}
function resizeCanvas() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  W = innerWidth; H = innerHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const target = reduce ? 10 : Math.min(55, Math.max(22, Math.floor(W / 24)));
  while (petals.length < target) petals.push(newPetal(true));
  petals.length = target;
}
function newPetal(anywhere) {
  return {
    x: rand(0, W), y: anywhere ? rand(-H, H) : rand(-60, -10),
    s: rand(7, 17), vy: rand(.5, 1.5), sway: rand(14, 48), ph: rand(0, 6.28), sp: rand(.008, .022),
    rot: rand(0, 6.28), vr: rand(-.025, .025), flip: rand(0, 6.28), vf: rand(.02, .05),
    c: Math.floor(rand(0, colors.length)), a: rand(.55, .95), baseX: 0
  };
}
function drawPetal(p) {
  const s = p.s;
  ctx.save();
  ctx.translate(p.x, p.y);
  ctx.rotate(p.rot);
  ctx.scale(1, .55 + .45 * Math.abs(Math.sin(p.flip)));
  ctx.globalAlpha = p.a;
  ctx.fillStyle = colors[p.c % colors.length];
  ctx.beginPath();
  ctx.moveTo(0, -s);
  ctx.bezierCurveTo(s * .95, -s * .55, s * .85, s * .65, 0, s);
  ctx.bezierCurveTo(-s * .85, s * .65, -s * .95, -s * .55, 0, -s);
  ctx.fill();
  ctx.restore();
}
function animatePetals() {
  ctx.clearRect(0, 0, W, H);
  for (const p of petals) {
    p.y += p.vy;
    p.ph += p.sp;
    p.x += Math.sin(p.ph) * .9;
    p.rot += p.vr;
    p.flip += p.vf;
    if (p.y > H + 30 || p.x < -60 || p.x > W + 60) Object.assign(p, newPetal(false));
    drawPetal(p);
  }
  requestAnimationFrame(animatePetals);
}

/* =====================================================
   ট্যাপ করলে ছোট ছোট হার্ট ছড়ায়
   ===================================================== */
const EMOJI = ['💖', '💕', '🌹', '💗', '✨', '💘', '🌸', '❤️'];
function burst(x, y, n = 8, dist = 70) {
  if (reduce) n = Math.min(n, 3);
  for (let i = 0; i < n; i++) {
    const s = document.createElement('span');
    s.className = 'pop';
    s.textContent = pick(EMOJI);
    const a = rand(0, Math.PI * 2), d = dist * rand(.45, 1.15);
    s.style.left = x + 'px';
    s.style.top = y + 'px';
    s.style.fontSize = rand(14, 24) + 'px';
    s.style.setProperty('--dx', Math.cos(a) * d + 'px');
    s.style.setProperty('--dy', Math.sin(a) * d - 30 + 'px');
    s.style.setProperty('--s', rand(.8, 1.5).toFixed(2));
    s.style.setProperty('--r', rand(-50, 50) + 'deg');
    document.body.appendChild(s);
    s.addEventListener('animationend', () => s.remove());
  }
}
document.addEventListener('pointerdown', e => {
  if (e.target.closest('input, textarea')) return;
  burst(e.clientX, e.clientY, 7, 62);
});

/* হার্ট বৃষ্টি */
function heartRain(n = 55) {
  if (reduce) n = 12;
  for (let i = 0; i < n; i++) {
    const s = document.createElement('span');
    s.className = 'fall';
    s.textContent = pick(['💗', '💖', '🌹', '💕', '🌸']);
    s.style.left = rand(0, 100) + 'vw';
    s.style.fontSize = rand(16, 34) + 'px';
    s.style.animationDuration = rand(3.2, 6.5) + 's';
    s.style.animationDelay = rand(0, 2.2) + 's';
    s.style.setProperty('--r', rand(-200, 200) + 'deg');
    document.body.appendChild(s);
    s.addEventListener('animationend', () => s.remove());
  }
}

/* আতশবাজি */
function fireworks() {
  for (let k = 0; k < 6; k++) {
    setTimeout(() => burst(rand(W * .15, W * .85), rand(H * .15, H * .6), 24, 150), k * 330);
  }
}

/* =====================================================
   স্ক্রল: রিভিল, প্রগ্রেস, উপরে যাও বাটন, হেডার
   ===================================================== */
const io = new IntersectionObserver(entries => {
  entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
  });
}, { threshold: .12, rootMargin: '0px 0px -40px 0px' });
function observeReveals() {
  $$('.reveal:not(.in)').forEach((el, i) => {
    el.style.setProperty('--d', (i % 4) * .08 + 's');
    io.observe(el);
  });
}

const progress = $('#progress'), topBtn = $('#topBtn');
function onScroll() {
  const h = document.documentElement;
  const max = h.scrollHeight - h.clientHeight;
  progress.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + '%';
  topBtn.classList.toggle('show', h.scrollTop > 600);
}
addEventListener('scroll', onScroll, { passive: true });
topBtn.addEventListener('click', () => scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }));

/* মোবাইল মেনু */
const nav = $('#nav'), menuBtn = $('#menuBtn');
menuBtn.addEventListener('click', e => {
  e.stopPropagation();
  const open = nav.classList.toggle('open');
  menuBtn.textContent = open ? '✕' : '☰';
});
nav.addEventListener('click', e => {
  if (e.target.closest('a')) { nav.classList.remove('open'); menuBtn.textContent = '☰'; }
});

/* =====================================================
   পপআপ (মুহূর্ত ও ছবি দুটোতেই কাজ করে)
   ===================================================== */
const modal = $('#modal');
let list = [], idx = 0;

function renderModal() {
  const it = list[idx];
  const box = $('#mPhoto'), img = $('#mImg');
  box.classList.remove('missing');
  img.onerror = () => box.classList.add('missing');
  img.src = it.photo;
  img.alt = it.title;
  $('#mPh').textContent = it.title;
  $('#mTitle').textContent = it.title;
  $('#mMsg').textContent = it.message;
  $('#mCount').textContent = bn(idx + 1) + ' / ' + bn(list.length);
}
function openModal(l, i) {
  list = l; idx = i;
  renderModal();
  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('lock');
  setTimeout(() => burst(W / 2, H / 2, 16, 170), 250);
}
function closeModal() {
  modal.classList.remove('open');
  modal.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('lock');
}
function step(d) {
  idx = (idx + d + list.length) % list.length;
  renderModal();
  burst(W / 2, H * .35, 8, 120);
}
$('#mClose').addEventListener('click', closeModal);
$('#modalBg').addEventListener('click', closeModal);
$('#mPrev').addEventListener('click', () => step(-1));
$('#mNext').addEventListener('click', () => step(1));
addEventListener('keydown', e => {
  if (!modal.classList.contains('open')) return;
  if (e.key === 'Escape') closeModal();
  if (e.key === 'ArrowLeft') step(-1);
  if (e.key === 'ArrowRight') step(1);
});
/* সোয়াইপ করে পরের/আগের */
let tx = null;
modal.addEventListener('touchstart', e => { tx = e.touches[0].clientX; }, { passive: true });
modal.addEventListener('touchend', e => {
  if (tx === null) return;
  const dx = e.changedTouches[0].clientX - tx;
  if (Math.abs(dx) > 60) step(dx < 0 ? 1 : -1);
  tx = null;
});

/* মুহূর্তের বাটন তৈরি */
const momentGrid = $('#momentGrid');
CONFIG.moments.forEach((m, i) => {
  const b = document.createElement('button');
  b.className = 'moment-btn reveal';
  b.innerHTML = '<span class="em">' + m.icon + '</span><span>' + m.title + '</span>';
  b.addEventListener('click', () => openModal(CONFIG.moments, i));
  b.addEventListener('pointermove', e => {
    const r = b.getBoundingClientRect();
    b.style.setProperty('--mx', ((e.clientX - r.left) / r.width * 100) + '%');
    b.style.setProperty('--my', ((e.clientY - r.top) / r.height * 100) + '%');
  });
  momentGrid.appendChild(b);
});

/* গ্যালারি তৈরি */
const galleryBox = $('#galleryBox');
const galleryItems = CONFIG.photos.map((p, i) => ({
  photo: p.src, title: p.caption, message: 'ছবি ' + bn(i + 1) + ': ' + p.caption + ' 💗'
}));
CONFIG.photos.forEach((p, i) => {
  const f = document.createElement('figure');
  f.className = 'photo reveal';
  f.tabIndex = 0;
  const img = document.createElement('img');
  img.src = p.src; img.alt = p.caption; img.loading = 'lazy';
  img.onerror = () => f.classList.add('missing');
  const cap = document.createElement('figcaption');
  cap.textContent = p.caption;
  const ph = document.createElement('span');
  ph.className = 'ph';
  ph.innerHTML = '💗<small>ছবি ' + bn(i + 1) + '</small>';
  f.append(img, ph, cap);
  f.addEventListener('click', () => openModal(galleryItems, i));
  f.addEventListener('keydown', e => { if (e.key === 'Enter') openModal(galleryItems, i); });
  galleryBox.appendChild(f);
});
$$('.tab').forEach(t => t.addEventListener('click', () => {
  $$('.tab').forEach(x => x.classList.remove('active'));
  t.classList.add('active');
  galleryBox.dataset.mode = t.dataset.mode;
  galleryBox.scrollLeft = 0;
  burst(t.getBoundingClientRect().left + t.offsetWidth / 2, t.getBoundingClientRect().top, 6, 50);
}));

/* =====================================================
   একসাথে কাটানো সময়
   ===================================================== */
function tick() {
  const start = new Date(CONFIG.startDate).getTime();
  let d = Date.now() - start;
  if (isNaN(d) || d < 0) d = 0;
  const days = Math.floor(d / 864e5);
  $('#cDays').textContent = bn(days);
  $('#cHours').textContent = bn(Math.floor(d / 36e5) % 24);
  $('#cMins').textContent = bn(Math.floor(d / 6e4) % 60);
  $('#cSecs').textContent = bn(Math.floor(d / 1e3) % 60);
  $('#statDays').textContent = bn(days);
}

/* =====================================================
   ফ্লিপ কার্ড
   ===================================================== */
$$('.flip').forEach(c => {
  const toggle = () => { c.classList.toggle('flipped'); };
  c.addEventListener('click', toggle);
  c.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
});

/* =====================================================
   চিঠি (টাইপ হয়ে লেখা আসবে)
   ===================================================== */
const envelope = $('#envelope');
const letterOut = $('#letterOut');
const letterText = $('#letterSrc').textContent.trim().split('\n').map(l => l.trim()).join('\n');
let typing = null, opened = false;
function openLetter() {
  if (!opened) {
    opened = true;
    envelope.classList.add('open');
    burst(envelope.getBoundingClientRect().left + envelope.offsetWidth / 2, envelope.getBoundingClientRect().top + 60, 14, 130);
    let i = 0;
    if (reduce) { letterOut.textContent = letterText; return; }
    typing = setInterval(() => {
      letterOut.textContent = letterText.slice(0, ++i);
      if (i >= letterText.length) { clearInterval(typing); typing = null; }
    }, 38);
  } else if (typing) {
    clearInterval(typing); typing = null;
    letterOut.textContent = letterText;
  }
}
envelope.addEventListener('click', openLetter);
envelope.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openLetter(); } });

/* =====================================================
   কেন ভালোবাসি (একই কারণ বারবার আসবে না)
   ===================================================== */
let bag = [];
$('#reasonBtn').addEventListener('click', e => {
  if (!bag.length) bag = [...CONFIG.reasons].sort(() => Math.random() - .5);
  const p = $('#reasonOut');
  p.textContent = bag.pop();
  p.classList.remove('swap'); void p.offsetWidth; p.classList.add('swap');
  burst(e.clientX, e.clientY, 10, 90);
});

/* =====================================================
   ভালোবাসার কথা (নিজে নিজে বদলায়)
   ===================================================== */
const qText = $('#quoteText');
let qi = 0;
function showQuote(next) {
  qText.classList.add('out');
  setTimeout(() => {
    if (next) qi = (qi + 1) % CONFIG.quotes.length;
    qText.textContent = CONFIG.quotes[qi];
    qText.classList.remove('out');
  }, reduce ? 0 : 450);
}
qText.textContent = CONFIG.quotes[0];
$('#quoteBox').addEventListener('click', () => showQuote(true));
$('#quoteBox').addEventListener('keydown', e => { if (e.key === 'Enter') showQuote(true); });
setInterval(() => showQuote(true), 7000);

/* =====================================================
   খুনসুটির জায়গা
   ===================================================== */
/* ১. ভালোবাসা মাপা */
const meter = $('#meter'), meterOut = $('#meterOut'), meterHeart = $('#meterHeart');
let meterFired = false;
function meterUpdate() {
  const v = +meter.value;
  let msg, em;
  if (v < 20) { msg = 'মাত্র এইটুকু? 😢 আরও টানো!'; em = '🤍'; }
  else if (v < 45) { msg = 'একটু একটু ভালোবাসা… আরও চাই!'; em = '💛'; }
  else if (v < 70) { msg = 'বেশ ভালোবাসা! কিন্তু আমার ভালোবাসা আরও বেশি 😏'; em = '💗'; }
  else if (v < 95) { msg = 'ওয়াও! প্রায় পৌঁছে গেছো ❤️'; em = '💖'; }
  else { msg = 'অসীম ভালোবাসা! 💞 এটাই আমাদের মাপ!'; em = '💝'; }
  meterOut.textContent = msg;
  meterHeart.textContent = em;
  meterHeart.style.transform = 'scale(' + (.8 + v / 100 * .9).toFixed(2) + ')';
  meterHeart.style.filter = 'drop-shadow(0 0 ' + Math.round(v / 4) + 'px var(--glow))';
  if (v === 100 && !meterFired) { meterFired = true; fireworks(); }
  if (v < 100) meterFired = false;
}
meter.addEventListener('input', meterUpdate);
meterUpdate();

/* ২. "না" বাটন পালিয়ে যায় */
const noBtn = $('#noBtn'), yesBtn = $('#yesBtn'), zone = $('#askZone');
let yesScale = 1, noCount = 0;
const noTexts = ['না 😤', 'ধরতে পারলে না! 😜', 'আবার চেষ্টা করো 😝', 'হিহি 🙈', 'হ্যাঁ বলে দাও 🥺', 'কাছে আসো না 🏃'];
function flee() {
  const zr = zone.getBoundingClientRect();
  noBtn.style.position = 'absolute';
  noBtn.style.left = rand(0, Math.max(0, zr.width - noBtn.offsetWidth)) + 'px';
  noBtn.style.top = rand(0, Math.max(0, zr.height - noBtn.offsetHeight)) + 'px';
  noCount++;
  noBtn.textContent = noTexts[noCount % noTexts.length];
  yesScale = Math.min(yesScale + .1, 1.7);
  yesBtn.style.transform = 'scale(' + yesScale + ')';
}
noBtn.addEventListener('pointerenter', flee);
noBtn.addEventListener('pointerdown', e => { e.preventDefault(); e.stopPropagation(); flee(); });
yesBtn.addEventListener('click', () => {
  $('#askOut').textContent = 'ধন্যবাদ সোনা! তুমি সবচেয়ে ভালো 🥰';
  toast('ক্ষমা পেয়ে গেলাম! 💖');
  fireworks();
});

/* ৩. জড়িয়ে ধরো */
let hugs = store.get('hugs', 0);
const hugTexts = ['উম্ম্ম্ম… 🤗', 'আরও জোরে! 💞', 'এত ভালো লাগছে 🥰', 'ছাড়বো না কিন্তু! 😚', 'তুমি আমার সবচেয়ে আরামের জায়গা 🏡', 'আরেকটা! আরেকটা! 💕'];
$('#hugCount').textContent = bn(hugs);
$('#hugBtn').addEventListener('click', () => {
  hugs++;
  store.set('hugs', hugs);
  $('#hugCount').textContent = bn(hugs);
  $('#hugOut').textContent = pick(hugTexts);
  if (hugs % 10 === 0) { toast(bn(hugs) + ' বার জড়িয়ে ধরেছো! 🎉'); heartRain(25); }
});

/* ৪. বৃষ্টি, আতশবাজি, মিষ্টি মেসেজ */
$('#rainBtn').addEventListener('click', () => { heartRain(); toast('ভালোবাসার বৃষ্টি শুরু! 💗'); });
$('#fireBtn').addEventListener('click', fireworks);
$('#msgBtn').addEventListener('click', e => {
  $('#msgOut').textContent = pick(CONFIG.sweetMessages);
  burst(e.clientX, e.clientY, 10, 90);
});

/* ৫. ইচ্ছার বোতল */
const wishList = $('#wishList');
let wishes = store.get('wishes', []);
function addWishChip(text) {
  const c = document.createElement('span');
  c.className = 'wish-chip';
  c.textContent = '✨ ' + text;
  wishList.appendChild(c);
}
wishes.forEach(addWishChip);
function addWish() {
  const inp = $('#wishInput');
  const v = inp.value.trim();
  if (!v) { toast('আগে একটা ইচ্ছা লেখো 😊'); return; }
  wishes.push(v);
  store.set('wishes', wishes);
  addWishChip(v);
  inp.value = '';
  heartRain(18);
  toast('ইচ্ছা বোতলে জমা হলো! 🍯');
}
$('#wishBtn').addEventListener('click', addWish);
$('#wishInput').addEventListener('keydown', e => { if (e.key === 'Enter') addWish(); });

/* =====================================================
   গান (music/song.mp3 থাকলে বাটন দেখা যাবে)
   ===================================================== */
const bgm = $('#bgm'), musicBtn = $('#musicBtn');
bgm.src = CONFIG.music;
bgm.addEventListener('loadedmetadata', () => { musicBtn.hidden = false; });
bgm.addEventListener('error', () => { musicBtn.hidden = true; });
musicBtn.addEventListener('click', () => {
  if (bgm.paused) { bgm.play().catch(() => toast('গান চালানো গেল না')); musicBtn.classList.add('playing'); }
  else { bgm.pause(); musicBtn.classList.remove('playing'); }
});

/* =====================================================
   শুরু করো
   ===================================================== */
setTheme(store.get('theme', 'dark'));
resizeCanvas();
addEventListener('resize', resizeCanvas);
animatePetals();
tick();
setInterval(tick, 1000);
observeReveals();
onScroll();

/* শুরুতে একটু হার্ট বৃষ্টি, স্বাগতম! */
setTimeout(() => heartRain(14), 900);
