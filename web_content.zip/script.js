const DB_NAME='my-photo-storage-db', STORE='photos';
let db, photos=[], albums=['সব ছবি'], activeAlbum='সব ছবি', selectedPhoto=null;
const $=id=>document.getElementById(id);
function openDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>req.result.createObjectStore(STORE,{keyPath:'id',autoIncrement:true});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
function request(req){return new Promise((resolve,reject)=>{req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error)})}
async function allPhotos(){return request(db.transaction(STORE).objectStore(STORE).getAll())}
async function savePhoto(item){return request(db.transaction(STORE,'readwrite').objectStore(STORE).add(item))}
async function removePhoto(id){return request(db.transaction(STORE,'readwrite').objectStore(STORE).delete(id))}
function getPin(){return localStorage.getItem('mps-pin')}
function showApp(){ $('lockScreen').classList.add('hidden');$('app').classList.remove('hidden');render()}
function initLock(){if(getPin()){$('lockMessage').textContent='তোমার PIN দাও';$('unlockBtn').classList.remove('hidden');$('setPinBtn').classList.add('hidden')}else{$('lockMessage').textContent='প্রথমে ৪–৮ সংখ্যার PIN তৈরি করো';$('unlockBtn').classList.add('hidden');$('setPinBtn').classList.remove('hidden')}}
$('setPinBtn').onclick=()=>{const p=$('pinInput').value;if(!/^\d{4,8}$/.test(p))return alert('৪–৮ সংখ্যার PIN দাও');localStorage.setItem('mps-pin',p);$('pinInput').value='';showApp()};
$('unlockBtn').onclick=()=>{if($('pinInput').value===getPin()){ $('pinInput').value='';showApp()}else alert('PIN মেলেনি')};
$('pinInput').addEventListener('keydown',e=>{if(e.key==='Enter')($('unlockBtn').classList.contains('hidden')?$('setPinBtn'):$('unlockBtn')).click()});
$('lockBtn').onclick=()=>{$('app').classList.add('hidden');$('lockScreen').classList.remove('hidden');initLock()};
$('photoPicker').onchange=async e=>{for(const file of e.target.files){if(!file.type.startsWith('image/'))continue;await savePhoto({name:file.name,type:file.type,blob:file,album:activeAlbum==='সব ছবি'?'সব ছবি':activeAlbum,created:Date.now()})}e.target.value='';await render()};
$('newAlbumBtn').onclick=()=>$('albumDialog').showModal();
$('albumForm').onsubmit=async e=>{e.preventDefault();const name=$('albumName').value.trim();if(!name)return;if(albums.includes(name))return alert('এই অ্যালবাম আগে থেকেই আছে');albums.push(name);activeAlbum=name;$('albumName').value='';$('albumDialog').close();render()};
function renderTabs(){const nav=$('albumTabs');nav.innerHTML='';['সব ছবি',...albums.filter(a=>a!=='সব ছবি')].forEach(a=>{const b=document.createElement('button');b.className='tab'+(a===activeAlbum?' active':'');b.textContent=a;b.onclick=()=>{activeAlbum=a;render()};nav.append(b)})}
async function render(){photos=await allPhotos();$('photoCount').textContent=photos.length;$('albumCount').textContent=albums.length-1;renderTabs();const grid=$('gallery');grid.innerHTML='';const shown=activeAlbum==='সব ছবি'?photos:photos.filter(p=>p.album===activeAlbum);if(!shown.length){grid.innerHTML='<div class="empty">এখনও কোনো ছবি নেই। “＋ ছবি যোগ করো” চাপ দিয়ে ছবি যোগ করো।</div>';return}shown.sort((a,b)=>b.created-a.created).forEach(p=>{const tile=document.createElement('button');tile.className='photo';tile.title=p.name;const img=document.createElement('img');img.src=URL.createObjectURL(p.blob);img.alt=p.name;tile.append(img);tile.onclick=()=>openPhoto(p);grid.append(tile)})}
function openPhoto(p){selectedPhoto=p;$('largePhoto').src=URL.createObjectURL(p.blob);$('photoInfo').textContent=p.name;$('photoDialog').showModal()}
$('closePhotoBtn').onclick=()=>$('photoDialog').close();
$('deletePhotoBtn').onclick=async()=>{if(!selectedPhoto||!confirm('এই ছবি মুছে ফেলবে?'))return;await removePhoto(selectedPhoto.id);$('photoDialog').close();render()};
(async()=>{try{db=await openDB();initLock()}catch(e){alert('এই ব্রাউজারে লোকাল স্টোরেজ চালু করা যাচ্ছে না।')}})();
