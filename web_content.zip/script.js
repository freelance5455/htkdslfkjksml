const API_KEY = "nc7NEgqqiUzKRQrpxT9EPPbKk30t1ckNW7L0xwtqhsGJy2679Bm6rS6D";
const HIGH_RES_LIMIT = 4000; 

const gallery = document.getElementById("gallery");
let unlockedPhotos = JSON.parse(localStorage.getItem("unlocked_photos")) || [];

// 1. إخفاء الشاشة الافتتاحية وجلب البيانات
document.addEventListener("DOMContentLoaded", () => {
    fetchWallpapers();

    // إخفاء الـ Splash Screen تلقائياً
    setTimeout(() => {
        const splash = document.getElementById("splashScreen");
        if (splash) {
            splash.style.opacity = "0";
            splash.style.visibility = "hidden";
        }
    }, 2500);
});

// 2. جلب الصور من API
async function fetchWallpapers(query = "") {
    if (!gallery) return;
    gallery.innerHTML = "<p style='grid-column: 1 / -1; color: #38bdf8; text-align: center;'>جاري التحميل...</p>";
    
    let url = "https://api.pexels.com/v1/curated?per_page=30";
    if (query && query !== 'all') {
        url = `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=30`;
    }

    try {
        const response = await fetch(url, { headers: { Authorization: API_KEY } });
        const data = await response.json();
        displayImages(data.photos);
    } catch (error) {
        gallery.innerHTML = "<p style='grid-column: 1 / -1; color: #ef4444; text-align: center;'>تحقق من الاتصال بالإنترنت.</p>";
    }
}

// 3. عرض الصور
function displayImages(photos) {
    if (!gallery) return;
    gallery.innerHTML = "";

    photos.forEach((photo) => {
        const card = document.createElement("div");
        card.className = "card";

        const img = document.createElement("img");
        img.src = photo.src.portrait;
        img.onclick = () => openPreview(photo);

        const btn = document.createElement("button");
        btn.className = "download-btn";
        btn.innerHTML = "⬇ حفظ الخلفية";
        btn.onclick = (e) => {
            e.stopPropagation();
            downloadImage(photo.src.original, photo.id);
        };

        card.appendChild(img);
        card.appendChild(btn);
        gallery.appendChild(card);
    });
}

// 4. المعاينة وتنزيل الخلفية
function openPreview(photo) {
    const previewModal = document.getElementById("previewModal");
    const modalImg = document.getElementById("modalImage");
    const setBgBtn = document.getElementById("setBgBtn");

    if (!previewModal || !modalImg) return;

    modalImg.src = photo.src.portrait;
    previewModal.style.display = "flex";

    if (setBgBtn) {
        setBgBtn.style.display = "block";
        setBgBtn.innerText = "تحميل وتعيين كخلفية";
        setBgBtn.onclick = () => downloadImage(photo.src.original, photo.id);
    }
}

function closePreview() {
    const previewModal = document.getElementById("previewModal");
    if (previewModal) previewModal.style.display = "none";
}

function downloadImage(url, id) {
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.download = `wallpaper-${id}.jpg`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function handleSearch() {
    const input = document.getElementById("searchInput");
    if (input && input.value.trim() !== "") fetchWallpapers(input.value.trim());
}

function filterCategory(category) {
    fetchWallpapers(category);
}
