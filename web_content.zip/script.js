// Switch App Bottom Tabs
function switchTab(tabName, btnElement) {
    document.querySelectorAll('.tab-view').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById('tab-' + tabName).classList.add('active');
    if (btnElement) {
        btnElement.classList.add('active');
    } else {
        const navButtons = document.querySelectorAll('.nav-item');
        if (tabName === 'admission') navButtons[2].classList.add('active');
    }
    window.scrollTo(0, 0);
}

// Auto-select course and open Admission tab
function selectCourseForAdmission(courseName) {
    document.getElementById('selectedCourse').value = courseName;
    switchTab('admission', null);
}

// Send Admission Form to WhatsApp
function sendToWhatsApp(event) {
    event.preventDefault();
    const name = document.getElementById('studentName').value;
    const father = document.getElementById('fatherName').value;
    const phone = document.getElementById('studentPhone').value;
    const course = document.getElementById('selectedCourse').value;
    const address = document.getElementById('studentAddress').value || 'Not Mentioned';

    const message = `*New App Admission - Dayal Computer Center*%0A%0A` +
                    `*Student Name:* ${name}%0A` +
                    `*Father's Name:* ${father}%0A` +
                    `*Mobile:* ${phone}%0A` +
                    `*Course:* ${course}%0A` +
                    `*Address:* ${address}`;

    window.open(`https://wa.me/919005281033?text=${message}`, '_blank');
}

// Register Service Worker for Installable App (PWA)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js').catch(() => {});
    });
}

// Custom App Install Prompt
let deferredPrompt;
const installBtn = document.getElementById('installBtn');

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installBtn.style.display = 'inline-block';
});

installBtn.addEventListener('click', async () => {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'accepted') {
            installBtn.style.display = 'none';
        }
        deferredPrompt = null;
    }
});
