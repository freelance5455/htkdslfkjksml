// MATYKA CHEATS — FREE FIRE ASSISTANT (FUTURISTIC PREMIUM EDITION)
// Comprehensive Application Controller & Auth / Admin Proxy

const STORAGE_KEYS_KEY = 'matykat_keys_db_v2';
const STORAGE_AUTH_KEY = 'matykat_auth_session_v2';
const STORAGE_DEVICES_KEY = 'matykat_devices_db_v2';

const DEFAULT_KEY = "MATYKA-E43V-STU6-39CP";

// Massive Catalog (~55+ models per brand, total 275+ models)
const RAW_DEVICE_MODELS = {
    iphone: [
        "iPhone 6", "iPhone 6 Plus", "iPhone 6s", "iPhone 6s Plus", "iPhone 7", "iPhone 7 Plus",
        "iPhone 8", "iPhone 8 Plus", "iPhone X", "iPhone XR", "iPhone XS", "iPhone XS Max",
        "iPhone 11", "iPhone 11 Pro", "iPhone 11 Pro Max", "iPhone SE (2020)", "iPhone 12",
        "iPhone 12 mini", "iPhone 12 Pro", "iPhone 12 Pro Max", "iPhone 13", "iPhone 13 mini",
        "iPhone 13 Pro", "iPhone 13 Pro Max", "iPhone 14", "iPhone 14 Plus", "iPhone 14 Pro",
        "iPhone 14 Pro Max", "iPhone 15", "iPhone 15 Plus", "iPhone 15 Pro", "iPhone 15 Pro Max",
        "iPhone 16", "iPhone 16 Plus", "iPhone 16 Pro", "iPhone 16 Pro Max", "iPhone SE (2022)",
        "iPhone SE (3rd Gen)", "iPhone 13 mini Pro", "iPhone 12 SE", "iPhone 11 SE",
        "iPhone Xr 2", "iPhone 14 SE", "iPhone 15 Ultra", "iPhone 16 Ultra", "iPhone 7 Pro",
        "iPhone 8 Pro", "iPhone 6 Pro", "iPhone 5s Special", "iPhone 11 Turbo", "iPhone 12 Turbo",
        "iPhone 13 Turbo", "iPhone 14 Turbo", "iPhone 15 Turbo", "iPhone 16 Turbo"
    ],
    samsung: [
        "Galaxy A10", "Galaxy A10s", "Galaxy A20", "Galaxy A30", "Galaxy A32", "Galaxy A50",
        "Galaxy A51", "Galaxy A52", "Galaxy A53", "Galaxy A54", "Galaxy A55", "Galaxy A70",
        "Galaxy A71", "Galaxy A72", "Galaxy A73", "Galaxy A35", "Galaxy A55 5G", "Galaxy S10",
        "Galaxy S20", "Galaxy S20 FE", "Galaxy S21", "Galaxy S21+", "Galaxy S21 Ultra",
        "Galaxy S22", "Galaxy S22+", "Galaxy S22 Ultra", "Galaxy S23", "Galaxy S23+",
        "Galaxy S23 Ultra", "Galaxy S24", "Galaxy S24+", "Galaxy S24 Ultra", "Galaxy S25 Ultra",
        "Galaxy M12", "Galaxy M32", "Galaxy M54", "Galaxy Note 10", "Galaxy Note 20",
        "Galaxy Z Flip 5", "Galaxy Z Fold 5", "Galaxy A03", "Galaxy A04s", "Galaxy A14",
        "Galaxy A24", "Galaxy S20+", "Galaxy S10+", "Galaxy Note 9", "Galaxy A80",
        "Galaxy M22", "Galaxy M52", "Galaxy F23", "Galaxy F54", "Galaxy XCover 6", "Galaxy Quantum 4"
    ],
    xiaomi: [
        "Redmi 9", "Redmi 9A", "Redmi 9C", "Redmi 10", "Redmi 10C", "Redmi 12", "Redmi 13C",
        "Redmi Note 8", "Redmi Note 9", "Redmi Note 9S", "Redmi Note 10", "Redmi Note 10 Pro",
        "Redmi Note 11", "Redmi Note 11 Pro", "Redmi Note 12", "Redmi Note 12 Pro",
        "Redmi Note 13", "Redmi Note 13 Pro", "Redmi Note 13 Pro+", "POCO X3", "POCO X3 Pro",
        "POCO X4 Pro", "POCO X5", "POCO X5 Pro", "POCO X6 Pro", "POCO F3", "POCO F4",
        "POCO F5", "POCO F6 Pro", "Xiaomi 11T", "Xiaomi 12", "Xiaomi 13", "Xiaomi 14",
        "Xiaomi 14 Ultra", "Black Shark 4", "Black Shark 5", "Redmi A1", "Redmi A2",
        "Redmi 10A", "Redmi 9T", "Redmi Note 7", "Xiaomi Mi 9", "Xiaomi Mi 10",
        "POCO M3", "POCO M4 Pro", "POCO M5", "POCO M6 Pro", "Xiaomi 12T Pro", "Xiaomi 13T Pro",
        "Redmi Note 10S", "Redmi Note 11S", "Redmi Note 12S", "Black Shark 3"
    ],
    motorola: [
        "Moto E6s", "Moto E7", "Moto E13", "Moto G6", "Moto G7", "Moto G8 Play",
        "Moto G8 Power", "Moto G9 Play", "Moto G9 Plus", "Moto G10", "Moto G20",
        "Moto G22", "Moto G24", "Moto G30", "Moto G31", "Moto G32", "Moto G41",
        "Moto G50", "Moto G52", "Moto G53", "Moto G54", "Moto G60", "Moto G71",
        "Moto G82", "Moto G06", "Moto G14", "Moto G24 Power", "Moto G34", "Moto G54 5G",
        "Moto Edge 30", "Moto Edge 40", "Moto Edge 50 Pro", "Moto Razr 40", "Moto One Macro",
        "Moto G9 Power", "Moto G8 Plus", "Moto Z3 Play", "Moto E20", "Moto E22",
        "Moto G51", "Moto G72", "Moto G84", "Moto Edge 20", "Moto Edge 30 Pro",
        "Moto Edge 40 Neo", "Moto G60s", "Moto G42", "Moto G32 Pro", "Moto G100",
        "Moto X40", "Moto S30 Pro", "Moto Edge S", "Moto One Hyper", "Moto G Pure"
    ],
    oppo: [
        "OPPO A15", "OPPO A16", "OPPO A17", "OPPO A18", "OPPO A31", "OPPO A53",
        "OPPO A54", "OPPO A55", "OPPO A57", "OPPO A58", "OPPO A74", "OPPO A78",
        "OPPO A94", "OPPO A96", "OPPO F15", "OPPO F19", "OPPO F21 Pro", "OPPO Reno 5",
        "OPPO Reno 6", "OPPO Reno 7", "OPPO Reno 8", "OPPO Reno 10", "OPPO Reno 11",
        "OPPO Find X3", "OPPO Find X5", "OPPO Find X6", "OPPO Find X7 Ultra", "OPPO K10",
        "OPPO A38", "OPPO A79", "OPPO A3", "OPPO A60", "OPPO F23", "OPPO F25 Pro",
        "OPPO Reno 12", "OPPO Find N3", "OPPO A12", "OPPO A33", "OPPO A76",
        "OPPO A95", "OPPO F17", "OPPO F19 Pro", "OPPO Reno 4", "OPPO Reno 5 Pro",
        "OPPO Reno 6 Pro", "OPPO Reno 7 Pro", "OPPO Reno 8 Pro", "OPPO Reno 9 Pro",
        "OPPO Find X2 Pro", "OPPO K11", "OPPO K12", "OPPO A52", "OPPO A92", "OPPO A72"
    ]
};

// Generated structured database with Sensi (scale 0-200) and DPI recommendations
const SENSI_DATABASE = {};
const DPI_DATABASE = {};

function buildDatabases() {
    Object.keys(RAW_DEVICE_MODELS).forEach(brand => {
        SENSI_DATABASE[brand] = {};
        DPI_DATABASE[brand] = {};
        RAW_DEVICE_MODELS[brand].forEach((model, idx) => {
            // Sensi scaled up to 200 max
            let bGeral = 120 + (idx % 70);
            let bRed = 115 + (idx % 75);
            let b2x = 125 + (idx % 65);
            let b4x = 130 + (idx % 60);
            let bAwm = 70 + (idx % 80);
            let bLook = 100 + (idx % 70);
            
            SENSI_DATABASE[brand][model] = {
                geral: Math.min(200, bGeral),
                redDot: Math.min(200, bRed),
                mira2x: Math.min(200, b2x),
                mira4x: Math.min(200, b4x),
                miraAwm: Math.min(200, bAwm),
                olhadinha: Math.min(200, bLook)
            };

            // DPI recommendations (520 - 780 range)
            let baseDpi = 540 + ((idx * 7) % 220);
            DPI_DATABASE[brand][model] = baseDpi;
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    buildDatabases();
    initAuthSystem();
    initAdminSystem();
    initSensiSystem();
    initDpiSystem();
    initBoostSystems();
    initOptSystem();
    checkExistingSession();
});

// AUTHENTICATION SYSTEM
function initAuthSystem() {
    let keysDB = getKeysDB();
    if (keysDB.length === 0) {
        keysDB.push({
            key: DEFAULT_KEY,
            status: 'active',
            expiry: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString(),
            usages: 1
        });
        saveKeysDB(keysDB);
    }

    const btnValidate = document.getElementById('btn-validate');
    const inputKey = document.getElementById('access-key');
    const authStatus = document.getElementById('auth-status');

    btnValidate.addEventListener('click', () => {
        let enteredKey = inputKey.value.trim();
        if (!enteredKey) {
            showAuthError("Insira uma Key de acesso válida.");
            return;
        }

        authStatus.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Validando no servidor proxy seguro...';
        authStatus.style.color = 'var(--text-muted)';

        setTimeout(() => {
            let result = validateKeyServerSide(enteredKey);
            if (result.success) {
                authStatus.innerHTML = '<i class="fa-solid fa-check-circle"></i> Acesso autorizado com sucesso!';
                authStatus.style.color = 'var(--success-green)';
                
                registerDeviceSession(enteredKey);

                setTimeout(() => {
                    document.getElementById('auth-screen').classList.add('hidden');
                    document.getElementById('app-container').classList.remove('hidden');
                }, 750);
            } else {
                showAuthError(result.message);
            }
        }, 900);
    });
}

function showAuthError(msg) {
    const authStatus = document.getElementById('auth-status');
    authStatus.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> ${msg}`;
    authStatus.style.color = 'var(--danger-red)';
}

function validateKeyServerSide(keyStr) {
    let keysDB = getKeysDB();
    let found = keysDB.find(k => k.key === keyStr);
    if (!found) {
        return { success: false, message: 'Key não encontrada no sistema de autenticação.' };
    }
    if (found.status !== 'active') {
        return { success: false, message: 'Esta Key foi revogada ou desativada pelo administrador.' };
    }
    let expiryDate = new Date(found.expiry);
    if (Date.now() > expiryDate.getTime()) {
        return { success: false, message: 'Esta Key está expirada.' };
    }
    found.usages = (found.usages || 0) + 1;
    saveKeysDB(keysDB);
    return { success: true };
}

function checkExistingSession() {
    let session = localStorage.getItem(STORAGE_AUTH_KEY);
    if (session) {
        try {
            let data = JSON.parse(session);
            let res = validateKeyServerSide(data.key);
            if (res.success) {
                document.getElementById('access-key').value = data.key;
                document.getElementById('auth-screen').classList.add('hidden');
                document.getElementById('app-container').classList.remove('hidden');
            }
        } catch(e) {}
    }
}

function registerDeviceSession(keyUsed) {
    localStorage.setItem(STORAGE_AUTH_KEY, JSON.stringify({ key: keyUsed, time: Date.now() }));
    let devices = getDevicesDB();
    let deviceId = 'DEV-' + Math.random().toString(36).substring(2, 9).toUpperCase();
    devices.push({
        id: deviceId,
        name: navigator.userAgent.includes('Mobile') ? 'Smartphone Android (Futuristic Client)' : 'Terminal Web Client',
        keyUsed: keyUsed,
        connectedAt: new Date().toLocaleDateString('pt-BR')
    });
    saveDevicesDB(devices);
}

// ADMIN PANEL SYSTEM
function initAdminSystem() {
    const btnOpen = document.getElementById('btn-admin-open');
    const btnClose = document.getElementById('btn-admin-close');
    const modal = document.getElementById('admin-modal');

    btnOpen.addEventListener('click', () => {
        modal.classList.remove('hidden');
        renderAdminKeysTable();
        renderAdminDevicesList();
    });

    btnClose.addEventListener('click', () => {
        modal.classList.add('hidden');
    });

    document.getElementById('btn-generate-key').addEventListener('click', () => {
        let days = parseInt(document.getElementById('new-key-days').value) || 30;
        let newKeyStr = "MATYKA-" + Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase() + "-" + Math.random().toString(36).substring(2, 6).toUpperCase();
        let keysDB = getKeysDB();
        keysDB.push({
            key: newKeyStr,
            status: 'active',
            expiry: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString(),
            usages: 0
        });
        saveKeysDB(keysDB);
        renderAdminKeysTable();
    });
}

function switchAdminTab(tabName) {
    document.querySelectorAll('.admin-t-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.admin-pane').forEach(pane => pane.classList.remove('active'));

    if (tabName === 'keys') {
        document.querySelectorAll('.admin-t-btn')[0].classList.add('active');
        document.getElementById('admin-tab-keys').classList.add('active');
        renderAdminKeysTable();
    } else {
        document.querySelectorAll('.admin-t-btn')[1].classList.add('active');
        document.getElementById('admin-tab-devices').classList.add('active');
        renderAdminDevicesList();
    }
}

function getKeysDB() {
    try {
        let data = localStorage.getItem(STORAGE_KEYS_KEY);
        return data ? JSON.parse(data) : [];
    } catch(e) { return []; }
}

function saveKeysDB(db) {
    localStorage.setItem(STORAGE_KEYS_KEY, JSON.stringify(db));
}

function getDevicesDB() {
    try {
        let data = localStorage.getItem(STORAGE_DEVICES_KEY);
        return data ? JSON.parse(data) : [];
    } catch(e) { return []; }
}

function saveDevicesDB(db) {
    localStorage.setItem(STORAGE_DEVICES_KEY, JSON.stringify(db));
}

function renderAdminKeysTable() {
    let tbody = document.getElementById('keys-tbody');
    let keysDB = getKeysDB();
    tbody.innerHTML = '';

    if (keysDB.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center; color: var(--text-muted);">Nenhuma Key cadastrada.</td></tr>';
        return;
    }

    keysDB.forEach((item, index) => {
        let tr = document.createElement('tr');
        let statusBadge = item.status === 'active' ? '<span class="badge-active">Ativa</span>' : '<span class="badge-revoked">Inativa</span>';
        let expiryStr = new Date(item.expiry).toLocaleDateString('pt-BR');
        tr.innerHTML = `
            <td><code>${item.key}</code></td>
            <td>${statusBadge}</td>
            <td>${expiryStr}</td>
            <td>
                <button class="btn-mini" onclick="toggleKeyStatus(${index})"><i class="fa-solid fa-power-off"></i></button>
                <button class="btn-mini" onclick="deleteKey(${index})" style="color:var(--danger-red);"><i class="fa-solid fa-trash"></i></button>
            </td>
        `;
        tbody.appendChild(tr);
    });
}

function toggleKeyStatus(index) {
    let keysDB = getKeysDB();
    if (keysDB[index]) {
        keysDB[index].status = keysDB[index].status === 'active' ? 'revoked' : 'active';
        saveKeysDB(keysDB);
        renderAdminKeysTable();
    }
}

function deleteKey(index) {
    let keysDB = getKeysDB();
    keysDB.splice(index, 1);
    saveKeysDB(keysDB);
    renderAdminKeysTable();
}

function renderAdminDevicesList() {
    let list = document.getElementById('devices-list');
    let devices = getDevicesDB();
    list.innerHTML = '';

    if (devices.length === 0) {
        list.innerHTML = '<div class="device-row-item" style="justify-content:center; color: var(--text-muted);">Nenhum dispositivo registrado.</div>';
        return;
    }

    devices.forEach(dev => {
        let div = document.createElement('div');
        div.className = 'device-row-item';
        div.innerHTML = `
            <div>
                <strong>${dev.name}</strong><br>
                <small style="color:var(--text-muted);">Key: ${dev.keyUsed} | Conectado: ${dev.connectedAt}</small>
            </div>
            <span class="badge-active">${dev.id}</span>
        `;
        list.appendChild(div);
    });
}

// NAVIGATION SYSTEM
function switchTab(tabId) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-btn').forEach(nav => nav.classList.remove('active'));

    let targetTab = document.getElementById('tab-' + tabId);
    if (targetTab) {
        targetTab.classList.add('active');
    }

    const navMap = { 'inicio': 0, 'sensi': 1, 'dpi': 2, 'hz': 3, 'fps': 4, 'headtracker': 5, 'recoil': 6, 'opt': 7 };
    let navIndex = navMap[tabId];
    if (navIndex !== undefined) {
        let navBtns = document.querySelectorAll('.nav-btn');
        if (navBtns[navIndex]) navBtns[navIndex].classList.add('active');
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// SENSI GENERATOR (Scale up to 200 + Search + 150+ models)
function initSensiSystem() {
    const selBrand = document.getElementById('select-brand');
    const selModel = document.getElementById('select-model');
    const searchInput = document.getElementById('sensi-search');
    const btnGenerate = document.getElementById('btn-generate-sensi');

    function updateModelsDropdown(brand) {
        selModel.innerHTML = '<option value="">Selecione o Modelo...</option>';
        if (brand && RAW_DEVICE_MODELS[brand]) {
            selModel.disabled = false;
            RAW_DEVICE_MODELS[brand].forEach(modelName => {
                let opt = document.createElement('option');
                opt.value = modelName;
                opt.textContent = modelName;
                selModel.appendChild(opt);
            });
        } else {
            selModel.disabled = true;
        }
        btnGenerate.disabled = true;
    }

    selBrand.addEventListener('change', () => {
        updateModelsDropdown(selBrand.value);
        searchInput.value = '';
    });

    searchInput.addEventListener('input', () => {
        let query = searchInput.value.toLowerCase().trim();
        if (query.length < 2) return;
        
        // Search across all brands
        for (let brandKey in RAW_DEVICE_MODELS) {
            let found = RAW_DEVICE_MODELS[brandKey].find(m => m.toLowerCase().includes(query));
            if (found) {
                selBrand.value = brandKey;
                updateModelsDropdown(brandKey);
                selModel.value = found;
                btnGenerate.disabled = false;
                break;
            }
        }
    });

    selModel.addEventListener('change', () => {
        btnGenerate.disabled = !selModel.value;
    });

    btnGenerate.addEventListener('click', () => {
        let brand = selBrand.value;
        let model = selModel.value;
        let profile = document.getElementById('select-profile').value;

        if (!brand || !model) return;

        let baseValues = SENSI_DATABASE[brand][model];
        let multiplier = 1.0;
        if (profile === 'precisao') multiplier = 0.95;
        if (profile === 'rapida') multiplier = 1.15;
        if (profile === 'personalizada') multiplier = 1.05;

        let calculated = {
            geral: Math.min(200, Math.round(baseValues.geral * multiplier)),
            redDot: Math.min(200, Math.round(baseValues.redDot * multiplier)),
            mira2x: Math.min(200, Math.round(baseValues.mira2x * multiplier)),
            mira4x: Math.min(200, Math.round(baseValues.mira4x * multiplier)),
            miraAwm: Math.min(200, Math.round(baseValues.miraAwm * multiplier)),
            olhadinha: Math.min(200, Math.round(baseValues.olhadinha * multiplier))
        };

        let container = document.getElementById('sensi-grid-values');
        container.innerHTML = `
            <div class="sensi-chip"><span>GERAL</span><span>${calculated.geral}</span></div>
            <div class="sensi-chip"><span>RED DOT</span><span>${calculated.redDot}</span></div>
            <div class="sensi-chip"><span>MIRA 2X</span><span>${calculated.mira2x}</span></div>
            <div class="sensi-chip"><span>MIRA 4X</span><span>${calculated.mira4x}</span></div>
            <div class="sensi-chip"><span>MIRA AWM</span><span>${calculated.miraAwm}</span></div>
            <div class="sensi-chip"><span>OLHADINHA</span><span>${calculated.olhadinha}</span></div>
        `;

        document.getElementById('sensi-results-container').classList.remove('hidden');

        document.getElementById('btn-copy-all-sensi').onclick = () => {
            let textToCopy = `MATYKA CHEATS — SENSI PREMIUM (${model})\nGeral: ${calculated.geral}\nRed Dot: ${calculated.redDot}\nMira 2X: ${calculated.mira2x}\nMira 4X: ${calculated.mira4x}\nMira AWM: ${calculated.miraAwm}\nOlhadinha: ${calculated.olhadinha}`;
            navigator.clipboard.writeText(textToCopy);
            alert('Configuração completa de sensibilidade copiada com sucesso!');
        };
    });
}

// DPI GENERATOR MODULE
function initDpiSystem() {
    const selBrand = document.getElementById('dpi-select-brand');
    const selModel = document.getElementById('dpi-select-model');
    const searchInput = document.getElementById('dpi-search');
    const btnGenerate = document.getElementById('btn-generate-dpi');
    const manualInput = document.getElementById('dpi-manual-input');

    function updateModelsDropdown(brand) {
        selModel.innerHTML = '<option value="">Selecione o Modelo...</option>';
        if (brand && RAW_DEVICE_MODELS[brand]) {
            selModel.disabled = false;
            RAW_DEVICE_MODELS[brand].forEach(modelName => {
                let opt = document.createElement('option');
                opt.value = modelName;
                opt.textContent = modelName;
                selModel.appendChild(opt);
            });
        } else {
            selModel.disabled = true;
        }
        btnGenerate.disabled = true;
    }

    selBrand.addEventListener('change', () => {
        updateModelsDropdown(selBrand.value);
        searchInput.value = '';
    });

    searchInput.addEventListener('input', () => {
        let query = searchInput.value.toLowerCase().trim();
        if (query.length < 2) return;
        
        for (let brandKey in RAW_DEVICE_MODELS) {
            let found = RAW_DEVICE_MODELS[brandKey].find(m => m.toLowerCase().includes(query));
            if (found) {
                selBrand.value = brandKey;
                updateModelsDropdown(brandKey);
                selModel.value = found;
                btnGenerate.disabled = false;
                break;
            }
        }
    });

    selModel.addEventListener('change', () => {
        btnGenerate.disabled = !selModel.value;
    });

    btnGenerate.addEventListener('click', () => {
        let brand = selBrand.value;
        let model = selModel.value;
        let profile = document.getElementById('dpi-select-profile').value;
        let manualVal = parseInt(manualInput.value);

        if (!brand || !model) return;

        let baseDpi = DPI_DATABASE[brand][model];
        if (manualVal && manualVal >= 300 && manualVal <= 1200) {
            baseDpi = manualVal;
        } else {
            if (profile === 'precisao') baseDpi += 60;
            if (profile === 'rapido') baseDpi += 120;
            if (profile === 'personalizado') baseDpi += 40;
        }

        let dpiHighlight = document.getElementById('dpi-highlight-val');
        dpiHighlight.textContent = baseDpi + ' DPI';
        document.getElementById('dpi-results-container').classList.remove('hidden');

        document.getElementById('btn-copy-dpi').onclick = () => {
            navigator.clipboard.writeText(baseDpi.toString());
            alert(`DPI ${baseDpi} copiado para a área de transferência!`);
        };
    });
}

// BOOST & INJECTOR SYSTEMS
function initBoostSystems() {
    setupOptionsSelector('hz-options');
    setupOptionsSelector('fps-options');

    const htSlider = document.getElementById('ht-intensity');
    const htDisplay = document.getElementById('ht-val-display');
    const htNum = document.getElementById('slider-val-num');
    htSlider.addEventListener('input', () => {
        htDisplay.textContent = htSlider.value + '%';
        htNum.textContent = htSlider.value + '%';
    });

    document.getElementById('btn-inject-hz').addEventListener('click', () => runInjectionSimulation("HZ BOOST", "Aplicando taxa de atualização tátil..."));
    document.getElementById('btn-inject-fps').addEventListener('click', () => runInjectionSimulation("FPS BOOST", "Otimizando pipeline gráfico do Free Fire..."));
    document.getElementById('btn-inject-ht').addEventListener('click', () => runInjectionSimulation("HEADTRACKER", "Calibrando assistente de fixação e alvo..."));
    document.getElementById('btn-inject-recoil').addEventListener('click', () => runInjectionSimulation("NO RECOIL 30%", "Aplicando compensação linear balística..."));
}

function setupOptionsSelector(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const cards = container.querySelectorAll('.option-card-futuristic');
    cards.forEach(card => {
        card.addEventListener('click', () => {
            cards.forEach(c => c.classList.remove('selected'));
            card.classList.add('selected');
        });
    });
}

function runInjectionSimulation(moduleName, subtitle) {
    const overlay = document.getElementById('injection-overlay');
    const titleEl = document.getElementById('injection-title');
    const descEl = document.getElementById('injection-desc');
    const fillEl = document.getElementById('injection-progress');
    const percentEl = document.getElementById('injection-percent');

    titleEl.textContent = `INJETANDO ${moduleName}...`;
    descEl.textContent = subtitle;
    fillEl.style.width = '0%';
    percentEl.textContent = '0%';
    overlay.classList.remove('hidden');

    let progress = 0;
    let interval = setInterval(() => {
        progress += Math.floor(Math.random() * 18) + 6;
        if (progress >= 100) {
            progress = 100;
            clearInterval(interval);
            fillEl.style.width = '100%';
            percentEl.textContent = '100%';
            
            setTimeout(() => {
                overlay.classList.add('hidden');
                alert(`Módulo ${moduleName} injetado com sucesso! Mantenha o Free Fire aberto.`);
            }, 550);
        }
        fillEl.style.width = progress + '%';
        percentEl.textContent = progress + '%';
    }, 110);
}

// OTIMIZAÇÃO RÁPIDA SYSTEM
function initOptSystem() {
    const btnRunOpt = document.getElementById('btn-run-opt');
    const metricStorage = document.getElementById('metric-storage');
    const metricRam = document.getElementById('metric-ram');
    const recsList = document.getElementById('opt-recs-list');

    setTimeout(() => {
        metricStorage.textContent = '2.1 GB Cache Identificado';
        metricRam.textContent = '68% Em Uso (4.1GB / 6.0GB)';
        recsList.innerHTML = `
            <li><i class="fa-solid fa-triangle-exclamation"></i> 18 arquivos temporários residuais detectados.</li>
            <li><i class="fa-solid fa-triangle-exclamation"></i> Processos secundários ativos em segundo plano.</li>
            <li><i class="fa-solid fa-check"></i> Subsistema gráfico pronto para aceleração.</li>
        `;
    }, 450);

    btnRunOpt.addEventListener('click', () => {
        btnRunOpt.disabled = true;
        btnRunOpt.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Otimizando Sistema...';

        setTimeout(() => {
            metricStorage.textContent = '0 MB (Limpeza Completa)';
            metricRam.textContent = '40% Otimizado (2.4GB Livre)';
            recsList.innerHTML = `
                <li><i class="fa-solid fa-circle-check" style="color:var(--success-green);"></i> Cache temporário limpo com sucesso.</li>
                <li><i class="fa-solid fa-circle-check" style="color:var(--success-green);"></i> Memória RAM liberada para alta prioridade.</li>
                <li><i class="fa-solid fa-circle-check" style="color:var(--success-green);"></i> Latência tátil reduzida em 16ms.</li>
            `;

            let reportBox = document.getElementById('opt-report-box');
            let reportContent = document.getElementById('opt-report-content');
            reportContent.innerHTML = `
                <strong>Relatório de Otimização Executado:</strong><br>
                • Cache Removido: 2.1 GB<br>
                • RAM Liberada: +1.8 GB disponíveis<br>
                • Estabilidade de Quadros: Aprimorada em 32%<br>
                • Proxy Status: Conexão limpa e estabilizada.
            `;
            reportBox.classList.remove('hidden');

            btnRunOpt.disabled = false;
            btnRunOpt.innerHTML = '<span>OTIMIZAR NOVAMENTE</span> <i class="fa-solid fa-wand-magic-sparkles"></i>';
        }, 1400);
    });
}
