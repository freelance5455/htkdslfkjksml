/* ==========================================================
   Setu — Academia & Industry Bridge
   Front-end prototype: localStorage stands in for a real backend.
========================================================== */

const DB_KEYS = {
  students: "setu_students",
  companies: "setu_companies",
  internships: "setu_internships",
  interviews: "setu_interviews",
  notifications: "setu_notifications",
  session: "setu_session"
};

/* ---------- Tiny Storage Helpers ---------- */

function loadList(key) {
  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch (e) {
    return [];
  }
}

function saveList(key, list) {
  localStorage.setItem(key, JSON.stringify(list));
}

function getSession() {
  try {
    return JSON.parse(localStorage.getItem(DB_KEYS.session));
  } catch (e) {
    return null;
  }
}

function setSession(session) {
  if (session) {
    localStorage.setItem(DB_KEYS.session, JSON.stringify(session));
  } else {
    localStorage.removeItem(DB_KEYS.session);
  }
}

function uid() {
  return (
    Date.now().toString(36) +
    Math.random().toString(36).slice(2, 7)
  );
}

/* ---------- Seed Data on First Run ---------- */

function seedIfEmpty() {
  if (loadList(DB_KEYS.internships).length) return;
  if (loadList(DB_KEYS.companies).length) return;

  const sampleCompany = {
    id: uid(),
    name: "Bluepeak Systems",
    industry: "Software Services",
    city: "Hyderabad",
    email: "hr@bluepeak.example",
    password: "demo1234"
  };

  saveList(DB_KEYS.companies, [sampleCompany]);

  saveList(DB_KEYS.internships, [
    {
      id: uid(),
      companyId: sampleCompany.id,
      companyName: sampleCompany.name,
      companyCity: sampleCompany.city,
      title: "Frontend Development Intern",
      type: "Internship",
      location: "Hyderabad",
      skills: ["HTML", "CSS", "JavaScript"],
      description:
        "Work with the product team to build and ship UI components for a live student-facing app.",
      applicants: []
    },
    {
      id: uid(),
      companyId: sampleCompany.id,
      companyName: sampleCompany.name,
      companyCity: sampleCompany.city,
      title: "Data Analyst — Graduate Program",
      type: "Full-time",
      location: "Remote",
      skills: ["SQL", "Excel", "Python"],
      description:
        "Analyse placement and skill-gap data across partner colleges to guide hiring decisions.",
      applicants: []
    }
  ]);
}

/* ==========================================================
   Router
========================================================== */

const PAGES = [
  "home",
  "student-auth",
  "company-auth",
  "dashboard",
  "internships",
  "resume"
];
function navigate(pageId) {
  const session = getSession();

  // Guard private pages
  if (
    (pageId === "dashboard" || pageId === "resume") &&
    !(session && session.type === "student")
  ) {
    pageId = "student-auth";
  }

  if (pageId === "internships" && !session) {
    pageId = "home";
  }

  PAGES.forEach((id) => {
    const el = document.getElementById("page-" + id);

    if (el) {
      el.classList.toggle("is-active", id === pageId);
    }
  });

  renderNav();
  renderHeaderTools();

  if (pageId === "dashboard") {
    renderDashboard();
  }

  if (pageId === "internships") {
    renderInternships();
  }

  if (pageId === "resume") {
    renderResume();
  }

  window.scrollTo({
    top: 0,
    behavior: "instant" in window ? "instant" : "auto"
  });

  document.getElementById("main-nav").classList.remove("is-open");
}

/* Delegate every [data-nav] click to the router */

document.addEventListener("click", (e) => {
  const target = e.target.closest("[data-nav]");

  if (!target) return;

  e.preventDefault();
  navigate(target.getAttribute("data-nav"));
});

/* ==========================================================
   Nav Bar (changes with session state)
========================================================== */

function renderNav() {
  const nav = document.getElementById("main-nav");
  const session = getSession();

  let html = `<a href="#" data-nav="home">Home</a>`;

  if (!session) {
    html += `<a href="#" data-nav="student-auth">Student Login</a>`;
    html += `<a href="#" data-nav="company-auth">Company Login</a>`;
  } else if (session.type === "student") {
    const s = loadList(DB_KEYS.students).find((x) => x.id === session.id);
    html += `<a href="#" data-nav="dashboard">Skill Dashboard</a>`;
    html += `<a href="#" data-nav="internships">Internships</a>`;
    html += `<span style="color:#A79A79;padding:8px 6px;">
      ${s ? escapeHtml(s.name) : ""}
    </span>`;
    html += `<button data-action="logout">Log out</button>`;

  } else if (session.type === "company") {

    html += `<a href="#" data-nav="internships">Opportunities</a>`;
    html += `<span style="color:#A79A79;padding:8px 6px;">
      ${escapeHtml(session.name || "")}
    </span>`;
    html += `<button data-action="logout">Log out</button>`;
  }

  nav.innerHTML = html;
}

/* ---------- Logout ---------- */

document.addEventListener("click", (e) => {
  if (e.target.matches('[data-action="logout"]')) {
    setSession(null);
    showToast("Signed out.");
    navigate("home");
  }
});

/* ---------- Mobile Navigation ---------- */

const navToggle = document.getElementById("navToggle");

navToggle.addEventListener("click", () => {
  document.getElementById("main-nav").classList.toggle("is-open");
});

/* ==========================================================
   Notifications
========================================================== */

function addNotification(userId, userType, message) {
  if (!userId) return;

  const list = loadList(DB_KEYS.notifications);

  list.unshift({
    id: uid(),
    userId,
    userType,
    message,
    read: false,
    createdAt: Date.now()
  });

  saveList(DB_KEYS.notifications, list.slice(0, 100));
}

function myNotifications() {
  const session = getSession();

  if (!session) return [];

  return loadList(DB_KEYS.notifications).filter(
    (n) =>
      n.userId === session.id &&
      n.userType === session.type
  );
}

function renderHeaderTools() {
  const el = document.getElementById("headerTools");
  const session = getSession();

  if (!session) {
    el.innerHTML = "";
    return;
  }

  const notes = myNotifications();
  const unread = notes.filter((n) => !n.read).length;

  el.innerHTML = `
    <div class="notif-wrap">
      <button class="notif-bell" id="notifBell" aria-label="Notifications">
        Alerts
        ${unread ? `<span class="notif-count">${unread}</span>` : ""}
      </button>

      <div class="notif-dropdown" id="notifDropdown">
        ${
          notes.length
            ? notes.slice(0, 12).map((n) => `
              <div class="notif-item ${n.read ? "" : "is-unread"}">
                <p>${escapeHtml(n.message)}</p>
                <span>${timeAgo(n.createdAt)}</span>
              </div>
            `).join("")
            : `<p class="notif-empty">No notifications yet.</p>`
        }
      </div>
    </div>
  `;
}
/* ---------- Notification Bell Events ---------- */

const bell = document.getElementById("notifBell");
const dropdown = document.getElementById("notifDropdown");

if (bell) {
  bell.addEventListener("click", (e) => {
    e.stopPropagation();

    dropdown.classList.toggle("is-open");

    if (dropdown.classList.contains("is-open")) {
      const all = loadList(DB_KEYS.notifications);

      all.forEach((n) => {
        if (
          n.userId === getSession().id &&
          n.userType === getSession().type
        ) {
          n.read = true;
        }
      });

      saveList(DB_KEYS.notifications, all);

      setTimeout(renderHeaderTools, 400);
    }
  });
}

document.addEventListener("click", () => {
  const dropdown = document.getElementById("notifDropdown");

  if (dropdown) {
    dropdown.classList.remove("is-open");
  }
});

/* ---------- Time Ago Helper ---------- */

function timeAgo(ts) {
  const diffMin = Math.max(
    1,
    Math.round((Date.now() - ts) / 60000)
  );

  if (diffMin < 60) {
    return `${diffMin}m ago`;
  }

  const diffHr = Math.round(diffMin / 60);

  if (diffHr < 24) {
    return `${diffHr}h ago`;
  }

  return `${Math.round(diffHr / 24)}d ago`;
}

/* ==========================================================
   Auth Tabs (Login / Register)
========================================================== */

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    const group = btn.closest(".wrap");

    group
      .querySelectorAll(".tab-btn")
      .forEach((b) => b.classList.remove("is-active"));

    group
      .querySelectorAll(".panel-form")
      .forEach((p) => p.classList.remove("is-active"));

    btn.classList.add("is-active");

    group
      .querySelector(`[data-panel="${btn.dataset.tab}"]`)
      .classList.add("is-active");
  });
});

/* ==========================================================
   Student Register / Login
========================================================== */
document
  .getElementById("studentRegisterForm")
  .addEventListener("submit", (e) => {
    e.preventDefault();

    const f = e.target;
    const errorEl = document.getElementById("studentRegisterError");

    const email = f.email.value.trim().toLowerCase();
    const students = loadList(DB_KEYS.students);

    if (students.some((s) => s.email === email)) {
      errorEl.textContent =
        "An account with this email already exists.";
      return;
    }

    const student = {
      id: uid(),
      name: f.name.value.trim(),
      college: f.college.value.trim(),
      city: f.city ? f.city.value.trim() : "",
      email,
      password: f.password.value,
      skills: [],
      certificates: [],
      projects: [],
      portfolio: {
        github: "",
        linkedin: "",
        website: ""
      }
    };

    students.push(student);
    saveList(DB_KEYS.students, students);

    errorEl.textContent = "";
    f.reset();

    setSession({
      type: "student",
      id: student.id
    });

    showToast(`Welcome, ${student.name}.`);
    navigate("dashboard");
  });

document
  .getElementById("studentLoginForm")
  .addEventListener("submit", (e) => {
    e.preventDefault();

    const f = e.target;
    const errorEl = document.getElementById("studentLoginError");

    const email = f.email.value.trim().toLowerCase();

    const student = loadList(DB_KEYS.students).find(
      (s) =>
        s.email === email &&
        s.password === f.password.value
    );

    if (!student) {
      errorEl.textContent =
        "No matching account. Check your email and password.";
      return;
    }

    errorEl.textContent = "";
    f.reset();

    setSession({
      type: "student",
      id: student.id
    });

    showToast(`Welcome back, ${student.name}.`);
    navigate("dashboard");
  });

/* ==========================================================
   Company Register / Login
========================================================== */
document
  .getElementById("companyRegisterForm")
  .addEventListener("submit", (e) => {
    e.preventDefault();

    const f = e.target;
    const errorEl = document.getElementById("companyRegisterError");

    const email = f.email.value.trim().toLowerCase();
    const companies = loadList(DB_KEYS.companies);

    if (companies.some((c) => c.email === email)) {
      errorEl.textContent =
        "An account with this email already exists.";
      return;
    }

    const company = {
      id: uid(),
      name: f.name.value.trim(),
      industry: f.industry.value.trim(),
      city: f.city ? f.city.value.trim() : "",
      email,
      password: f.password.value
    };

    companies.push(company);
    saveList(DB_KEYS.companies, companies);

    errorEl.textContent = "";
    f.reset();

    setSession({
      type: "company",
      id: company.id,
      name: company.name
    });

    showToast(`Welcome, ${company.name}.`);
    navigate("internships");
  });

document
  .getElementById("companyLoginForm")
  .addEventListener("submit", (e) => {
    e.preventDefault();

    const f = e.target;
    const errorEl = document.getElementById("companyLoginError");

    const email = f.email.value.trim().toLowerCase();

    const company = loadList(DB_KEYS.companies).find(
      (c) =>
        c.email === email &&
        c.password === f.password.value
    );

    if (!company) {
      errorEl.textContent =
        "No matching account. Check your email and password.";
      return;
    }

    errorEl.textContent = "";
    f.reset();

    setSession({
      type: "company",
      id: company.id,
      name: company.name
    });

    showToast(`Welcome back, ${company.name}.`);
    navigate("internships");
  });

/* ==========================================================
   Skill Dashboard
========================================================== */

function currentStudent() {
  const session = getSession();

  if (!session || session.type !== "student") {
    return null;
  }

  const students = loadList(DB_KEYS.students);

  return students.find((s) => s.id === session.id) || null;
}
function saveStudent(updated) {
  const students = loadList(DB_KEYS.students);

  const idx = students.findIndex(
    (s) => s.id === updated.id
  );

  if (idx > -1) {
    students[idx] = updated;
    saveList(DB_KEYS.students, students);
  }
}

function renderDashboard() {
  const student = currentStudent();

  if (!student) return;

  if (!student.portfolio) {
    student.portfolio = {
      github: "",
      linkedin: "",
      website: ""
    };
  }

  document.getElementById(
    "dashboardGreeting"
  ).textContent = `${student.name}'s profile`;

  renderTagList(
    "skillList",
    student.skills,
    (i) => removeFromStudent("skills", i)
  );

  renderTagList(
    "certList",
    student.certificates,
    (i) => removeFromStudent("certificates", i)
  );

  renderTagList(
    "projectList",
    student.projects,
    (i) => removeFromStudent("projects", i)
  );

  renderBadgePanel(student);
  renderPortfolioForm(student);
  renderMyApplications(student);
  renderMyInterviews(student);
}

function renderTagList(elId, items, onRemove) {
  const el = document.getElementById(elId);

  if (!items.length) {
    el.innerHTML =
      `<li class="tag-empty">Nothing added yet.</li>`;
    return;
  }

  el.innerHTML = items
    .map(
      (item, i) => `
      <li>
        ${escapeHtml(item)}
        <button data-index="${i}" aria-label="Remove">
          &times;
        </button>
      </li>
    `
    )
    .join("");

  el.querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () =>
      onRemove(Number(btn.dataset.index))
    );
  });
}

function removeFromStudent(field, index) {
  const student = currentStudent();

  if (!student) return;

  student[field].splice(index, 1);
  saveStudent(student);
  renderDashboard();
}

/* ---------- Add Skills, Certificates & Projects ---------- */

["skill", "cert", "project"].forEach((kind) => {
  const fieldMap = {
    skill: "skills",
    cert: "certificates",
    project: "projects"
  };
  document
  .getElementById(kind + "Form")
  .addEventListener("submit", (e) => {
    e.preventDefault();

    const input = document.getElementById(kind + "Input");
    const value = input.value.trim();

    if (!value) return;

    const student = currentStudent();
    if (!student) return;

    student[fieldMap[kind]].push(value);

    saveStudent(student);

    input.value = "";
    renderDashboard();
  });
});

/* ==========================================================
 Portfolio Links
========================================================== */

function renderPortfolioForm(student) {
document.getElementById("portfolioGithub").value =
  student.portfolio.github || "";

document.getElementById("portfolioLinkedin").value =
  student.portfolio.linkedin || "";

document.getElementById("portfolioWebsite").value =
  student.portfolio.website || "";
}

document
.getElementById("portfolioForm")
.addEventListener("submit", (e) => {
  e.preventDefault();

  const student = currentStudent();
  if (!student) return;

  student.portfolio = {
    github: document.getElementById("portfolioGithub").value.trim(),
    linkedin: document.getElementById("portfolioLinkedin").value.trim(),
    website: document.getElementById("portfolioWebsite").value.trim()
  };

  saveStudent(student);
  showToast("Portfolio links saved.");
});

/* ==========================================================
 Skill Badges & XP
========================================================== */

const BADGE_TIERS = [
{ min: 0, name: "Getting Started", next: 20 },
{ min: 20, name: "Skill Builder", next: 50 },
{ min: 50, name: "Portfolio Pro", next: 90 },
{ min: 90, name: "Placement Ready", next: null }
];

function studentXp(student) {
return (
  student.skills.length * 10 +
  student.certificates.length * 15 +
  student.projects.length * 20
);
}

function renderBadgePanel(student) {
const xp = studentXp(student);

let tier = BADGE_TIERS[0];

for (const t of BADGE_TIERS) {
  if (xp >= t.min) tier = t;
}

const progressPct = tier.next
  ? Math.min(
      100,
      Math.round(((xp - tier.min) / (tier.next - tier.min)) * 100)
    )
  : 100;
  const earnedBadges = [];

  if (student.skills.length >= 1)
    earnedBadges.push("First Skill Logged");

  if (student.skills.length >= 5)
    earnedBadges.push("Skill Explorer");

  if (student.certificates.length >= 1)
    earnedBadges.push("Certified");

  if (student.projects.length >= 1)
    earnedBadges.push("Builder");

  if (
    student.portfolio &&
    (student.portfolio.github || student.portfolio.website)
  ) {
    earnedBadges.push("Portfolio Live");
  }

  document.getElementById("badgePanel").innerHTML = `
    <div class="badge-summary">
      <div class="badge-current">
        <span class="badge-pill">${escapeHtml(tier.name)}</span>
        <span class="badge-xp">${xp} XP</span>
      </div>

      <div class="badge-bar">
        <div class="badge-bar-fill"
             style="width:${progressPct}%"></div>
      </div>

      <p class="badge-hint">
        ${
          tier.next
            ? `${Math.max(0, tier.next - xp)} XP to reach the next tier.`
            : `Top tier reached — you're demo-ready.`
        }
      </p>
    </div>

    <div class="badge-earned">
      ${
        earnedBadges.length
          ? earnedBadges
              .map(
                (b) =>
                  `<span class="skill-badge">${escapeHtml(b)}</span>`
              )
              .join("")
          : `<span class="tag-empty">
               Add a skill, certificate or project to earn your first badge.
             </span>`
      }
    </div>
  `;
}

/* ==========================================================
   Resume Builder
========================================================== */

function renderResume() {
  const student = currentStudent();

  if (!student) return;

  const p = student.portfolio || {};

  const linkRow = [
    p.github
      ? `<a href="${escapeHtml(p.github)}" target="_blank" rel="noopener">GitHub</a>`
      : "",
    p.linkedin
      ? `<a href="${escapeHtml(p.linkedin)}" target="_blank" rel="noopener">LinkedIn</a>`
      : "",
    p.website
      ? `<a href="${escapeHtml(p.website)}" target="_blank" rel="noopener">Portfolio</a>`
      : ""
  ]
    .filter(Boolean)
    .join(" &nbsp;·&nbsp; ");

  document.getElementById("resumeSheet").innerHTML = `
    <h1>${escapeHtml(student.name)}</h1>

    <p class="resume-meta">
      ${escapeHtml(student.college || "")}
      ${student.city ? " · " + escapeHtml(student.city) : ""}
      ${student.email ? " · " + escapeHtml(student.email) : ""}
    </p>

    ${linkRow ? `<p class="resume-links">${linkRow}</p>` : ""}
    <h2>Skills</h2>

    ${
      student.skills.length
        ? `
          <div class="skill-chip-row">
            ${student.skills
              .map(
                (s) =>
                  `<span class="skill-chip">${escapeHtml(s)}</span>`
              )
              .join("")}
          </div>
        `
        : `<p class="resume-empty">No skills added yet.</p>`
    }

    <h2>Certificates</h2>

    ${
      student.certificates.length
        ? `
          <ul>
            ${student.certificates
              .map((c) => `<li>${escapeHtml(c)}</li>`)
              .join("")}
          </ul>
        `
        : `<p class="resume-empty">No certificates added yet.</p>`
    }

    <h2>Projects</h2>

    ${
      student.projects.length
        ? `
          <ul>
            ${student.projects
              .map((p) => `<li>${escapeHtml(p)}</li>`)
              .join("")}
          </ul>
        `
        : `<p class="resume-empty">No projects added yet.</p>`
    }
  `;
}

/* ---------- Print Resume ---------- */

const printResumeBtn = document.getElementById("printResumeBtn");

if (printResumeBtn) {
  printResumeBtn.addEventListener("click", () => window.print());
}

/* ==========================================================
   Student Applications
========================================================== */

function renderMyApplications(student) {
  const internships = loadList(DB_KEYS.internships);

  const applied = internships.filter((job) =>
    job.applicants.includes(student.id)
  );

  const el = document.getElementById("myApplications");

  if (!applied.length) {
    el.innerHTML = `
      <p class="empty-state">
        You haven't applied to anything yet.
        Browse
        <a href="#" data-nav="internships">
          open opportunities
        </a>.
      </p>
    `;
    return;
  }

  el.innerHTML = applied
    .map((job) => {
      const status = latestInterviewStatus(job.id, student.id);

      return `
        <div class="ledger-row">
          <h3>${escapeHtml(job.title)}</h3>

          <p>
            ${escapeHtml(job.companyName)}
            · ${escapeHtml(job.type)}
            ${
              status
                ? ` · <span class="status-pill status-${status}">
                     ${statusLabel(status)}
                   </span>`
                : ""
            }
          </p>
        </div>
      `;
    })
    .join("");
}
/* ==========================================================
   Upcoming Interviews (Student Side)
========================================================== */

function renderMyInterviews(student) {
  const interviews = loadList(DB_KEYS.interviews)
    .filter((iv) => iv.studentId === student.id)
    .sort((a, b) => new Date(a.datetime) - new Date(b.datetime));

  const el = document.getElementById("myInterviews");

  if (!interviews.length) {
    el.innerHTML = `
      <p class="empty-state">
        No interviews scheduled yet.
      </p>
    `;
    return;
  }

  el.innerHTML = interviews
    .map(
      (iv) => `
      <div class="ledger-row">
        <h3>
          ${escapeHtml(iv.jobTitle)} — ${escapeHtml(iv.companyName)}
        </h3>

        <p>
          ${formatDateTime(iv.datetime)}
          ·
          <span class="status-pill status-${iv.status}">
            ${statusLabel(iv.status)}
          </span>

          ${
            iv.notes
              ? `<br>${escapeHtml(iv.notes)}`
              : ""
          }
        </p>
      </div>
    `
    )
    .join("");
}

function statusLabel(status) {
  return (
    {
      applied: "Applied",
      scheduled: "Interview Scheduled",
      selected: "Selected",
      rejected: "Not Selected"
    }[status] || status
  );
}

function formatDateTime(iso) {
  const d = new Date(iso);

  if (isNaN(d.getTime())) return iso;

  return d.toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function latestInterviewStatus(jobId, studentId) {
  const interviews = loadList(DB_KEYS.interviews)
    .filter(
      (iv) =>
        iv.jobId === jobId &&
        iv.studentId === studentId
    )
    .sort((a, b) => b.createdAt - a.createdAt);

  return interviews.length
    ? interviews[0].status
    : "applied";
}

/* ==========================================================
   AI Skill Match + Skill Gap + Course Recommendations
========================================================== */

function normSkills(list) {
  return (list || [])
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

function matchPercent(studentSkills, jobSkills) {
  const need = normSkills(jobSkills);

  if (!need.length) return 0;

  const have = new Set(normSkills(studentSkills));

  const matched = need.filter((s) => have.has(s));

  return Math.round((matched.length / need.length) * 100);
}
function missingSkills(studentSkills, jobSkills) {
  const have = new Set(normSkills(studentSkills));

  return (jobSkills || []).filter(
    (s) => !have.has(s.trim().toLowerCase())
  );
}

function courseLinksFor(skill) {
  const q = encodeURIComponent(skill + " tutorial");

  return `
    <span class="course-links">
      <a href="https://www.youtube.com/results?search_query=${q}" target="_blank" rel="noopener">
        YouTube
      </a>

      ·

      <a href="https://swayam.gov.in/explorer?searchText=${encodeURIComponent(skill)}" target="_blank" rel="noopener">
        NPTEL / Swayam
      </a>

      ·

      <a href="https://www.coursera.org/search?query=${encodeURIComponent(skill)}" target="_blank" rel="noopener">
        Coursera
      </a>
    </span>
  `;
}

/* ==========================================================
   Internship & Placement
========================================================== */

let internshipFilter = "all"; // all | remote | city

function renderInternships() {
  const session = getSession();

  const postForm = document.getElementById("postForm");
  const titleEl = document.getElementById("internshipsTitle");

  const isCompany =
    session && session.type === "company";

  postForm.style.display = isCompany ? "block" : "none";

  document.getElementById("analyticsPanel").style.display =
    isCompany ? "block" : "none";

  const filterRow = document.getElementById("internshipFilters");
  filterRow.style.display = isCompany ? "none" : "flex";

  titleEl.textContent = isCompany
    ? "Your postings & candidates"
    : "Open opportunities";

  const internships = loadList(DB_KEYS.internships);

  const list = document.getElementById("internshipList");

  const student = !isCompany ? currentStudent() : null;

  if (isCompany) {
    renderAnalyticsPanel(session, internships);
  } else {
    renderInternshipFilters(student);
  }

  let visible = isCompany
    ? internships.filter(
        (job) => job.companyId === session.id
      )
    : internships;

  if (!isCompany) {
    if (internshipFilter === "remote") {
      visible = visible.filter(
        (job) =>
          (job.location || "")
            .trim()
            .toLowerCase() === "remote"
      );
    } else if (
      internshipFilter === "city" &&
      student &&
      student.city
    ) {
      visible = visible.filter(
        (job) =>
          (job.location || "")
            .trim()
            .toLowerCase() ===
          student.city.trim().toLowerCase()
      );
    }
  }

  if (!visible.length) {
    list.innerHTML = `
      <p class="empty-state">
        ${
          isCompany
            ? "You haven't posted an opportunity yet."
            : "No opportunities match this filter right now — check back soon."
        }
      </p>
    `;
    return;
  }

  list.innerHTML = visible
    .map((job) => {
      const skillsHtml = job.skills
      .map(
        (s) => `<span class="skill-chip">${escapeHtml(s)}</span>`
      )
      .join("");

    let sideHtml = "";
    let extraHtml = "";

    if (isCompany) {
      sideHtml = `
        <button class="btn btn-small" data-toggle-applicants="${job.id}">
          ${job.applicants.length} applicant${
            job.applicants.length === 1 ? "" : "s"
          } — view
        </button>
      `;

      extraHtml = `
        <div class="applicant-panel"
             id="applicants-${job.id}"
             hidden>
        </div>
      `;

    } else if (student) {
      const hasApplied = job.applicants.includes(student.id);

      const pct = matchPercent(student.skills, job.skills);

      const gaps = missingSkills(student.skills, job.skills);

      sideHtml = `
        <span class="match-score"
              title="AI Skill Match Score">
          ${pct}% match
        </span>

        ${
          hasApplied
            ? `<span class="applied-tag">Applied ✓</span>`
            : `<button class="btn btn-small"
                       data-apply="${job.id}">
                  Apply
               </button>`
        }
      `;

      extraHtml = gaps.length
        ? `
          <div class="skill-gap">
            <p class="skill-gap-title">
              You need
              ${gaps
                .map((g) => `<strong>${escapeHtml(g)}</strong>`)
                .join(", ")}
              to fully qualify.
            </p>

            <div class="skill-gap-courses">
              ${gaps
                .map(
                  (g) => `
                    <div class="skill-gap-course">
                      <span>${escapeHtml(g)}:</span>
                      ${courseLinksFor(g)}
                    </div>
                  `
                )
                .join("")}
            </div>
          </div>
        `
        : `
          <p class="skill-gap-title skill-gap-clear">
            You already meet every listed skill for this role.
          </p>
        `;

    } else {
      sideHtml = `
        <a href="#"
           class="btn btn-small"
           data-nav="student-auth">
          Log in to apply
        </a>
      `;
    }

    return `
      <div class="internship-row">
        <div class="internship-main">
          <h3>${escapeHtml(job.title)}</h3>

          <p class="internship-meta">
            ${escapeHtml(job.companyName)}
            · ${escapeHtml(job.type)}
            ${job.location ? " · " + escapeHtml(job.location) : ""}
          </p>

          <p class="internship-desc">
            ${escapeHtml(job.description)}
          </p>

          <div class="skill-chip-row">
            ${skillsHtml}
          </div>

          ${extraHtml}
        </div>

        <div class="internship-side">
          ${sideHtml}
        </div>
      </div>
    `;
  })
  .join("");
  list.querySelectorAll("[data-apply]").forEach((btn) => {
    btn.addEventListener("click", () =>
      applyToJob(btn.getAttribute("data-apply"))
    );
  });

  list.querySelectorAll("[data-toggle-applicants]").forEach((btn) => {
    btn.addEventListener("click", () =>
      toggleApplicantPanel(
        btn.getAttribute("data-toggle-applicants")
      )
    );
  });
}

/* ==========================================================
   Internship Filters
========================================================== */

function renderInternshipFilters(student) {
  const el = document.getElementById("internshipFilters");

  if (!el) return;

  const chips = [
    { key: "all", label: "All" },
    { key: "remote", label: "Remote" }
  ];

  if (student && student.city) {
    chips.push({
      key: "city",
      label: `Near me (${student.city})`
    });
  }

  el.innerHTML = chips
    .map(
      (c) => `
      <button
        type="button"
        class="filter-chip ${
          internshipFilter === c.key ? "is-active" : ""
        }"
        data-filter="${c.key}">
        ${escapeHtml(c.label)}
      </button>
    `
    )
    .join("");

  el.querySelectorAll("[data-filter]").forEach((btn) => {
    btn.addEventListener("click", () => {
      internshipFilter = btn.getAttribute("data-filter");
      renderInternships();
    });
  });
}

/* ==========================================================
   Company Placement Analytics
========================================================== */

function renderAnalyticsPanel(session, internships) {
  const el = document.getElementById("analyticsPanel");

  if (!el) return;

  const myJobs = internships.filter(
    (job) => job.companyId === session.id
  );

  const totalApplicants = myJobs.reduce(
    (sum, j) => sum + j.applicants.length,
    0
  );

  const interviews = loadList(DB_KEYS.interviews).filter(
    (iv) => iv.companyId === session.id
  );

  const scheduled = interviews.filter(
    (iv) => iv.status === "scheduled"
  ).length;

  const selected = interviews.filter(
    (iv) => iv.status === "selected"
  ).length;

  const maxApplicants = Math.max(
    1,
    ...myJobs.map((j) => j.applicants.length)
  );

  el.innerHTML = `
    <h2 class="col-title">Placement Analytics</h2>

    <div class="stat-row">
      <div class="stat-card">
        <strong>${myJobs.length}</strong>
        <span>Postings</span>
      </div>

      <div class="stat-card">
        <strong>${totalApplicants}</strong>
        <span>Applicants</span>
      </div>

      <div class="stat-card">
        <strong>${scheduled}</strong>
        <span>Interviews Scheduled</span>
      </div>

      <div class="stat-card">
        <strong>${selected}</strong>
        <span>Selected</span>
      </div>
    </div>
    ${
      myJobs.length
        ? `
          <div class="bar-chart">
            ${myJobs
              .map(
                (j) => `
                  <div class="bar-chart-row">
                    <span class="bar-chart-label">${escapeHtml(j.title)}</span>

                    <div class="bar-chart-track">
                      <div
                        class="bar-chart-fill"
                        style="width:${Math.round(
                          (j.applicants.length / maxApplicants) * 100
                        )}%">
                      </div>
                    </div>

                    <span class="bar-chart-value">
                      ${j.applicants.length}
                    </span>
                  </div>
                `
              )
              .join("")}
          </div>
        `
        : ""
    }
  `;
}

/* ==========================================================
   Applicant Panel
========================================================== */

function toggleApplicantPanel(jobId) {
  const panel = document.getElementById("applicants-" + jobId);

  if (!panel) return;

  const willOpen = panel.hasAttribute("hidden");

  if (willOpen) {
    panel.removeAttribute("hidden");
    renderApplicantPanel(jobId);
  } else {
    panel.setAttribute("hidden", "");
  }
}

function renderApplicantPanel(jobId) {
  const panel = document.getElementById("applicants-" + jobId);

  if (!panel) return;

  const internships = loadList(DB_KEYS.internships);
  const job = internships.find((j) => j.id === jobId);

  if (!job) return;

  const students = loadList(DB_KEYS.students);

  if (!job.applicants.length) {
    panel.innerHTML = `
      <p class="empty-state">No applicants yet.</p>
    `;
    return;
  }

  panel.innerHTML = job.applicants
    .map((studentId) => {
      const student = students.find((s) => s.id === studentId);

      if (!student) return "";

      const pct = matchPercent(student.skills, job.skills);
      const status = latestInterviewStatus(job.id, student.id);

      return `
        <div class="applicant-card">
          <div class="applicant-info">
            <strong>${escapeHtml(student.name)}</strong>

            <span class="match-score">${pct}% Match</span>

            <span class="status-pill status-${status}">
              ${statusLabel(status)}
            </span>

            <p class="applicant-college">
              ${escapeHtml(student.college || "")}
            </p>
          </div>
        </div>
      `;
    })
    .join("");
}

/* ==========================================================
   Apply to Internship
========================================================== */

function applyToJob(jobId) {
  const student = currentStudent();

  if (!student) return;

  const internships = loadList(DB_KEYS.internships);
  const job = internships.find((j) => j.id === jobId);

  if (!job || job.applicants.includes(student.id)) return;

  job.applicants.push(student.id);
  saveList(DB_KEYS.internships, internships);

  addNotification(
    job.companyId,
    "company",
    `${student.name} applied to "${job.title}".`
  );

  showToast(`Applied to ${job.title}.`);
  renderInternships();
}

/* ==========================================================
   Company Posts Internship
========================================================== */

document
  .getElementById("postForm")
  .addEventListener("submit", (e) => {
    e.preventDefault();

    const session = getSession();

    if (!session || session.type !== "company") return;

    const f = e.target;

    const skills = f.skills.value
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    const companies = loadList(DB_KEYS.companies);

    const company = companies.find(
      (c) => c.id === session.id
    );

    const internships = loadList(DB_KEYS.internships);

    const newJob = {
      id: uid(),
      companyId: session.id,
      companyName: session.name,
      companyCity: company ? company.city : "",
      title: f.title.value.trim(),
      type: f.type.value,
      location:
        f.location.value.trim() ||
        (company ? company.city : ""),
      skills,
      description: f.description.value.trim(),
      applicants: []
    };

    internships.push(newJob);

    saveList(DB_KEYS.internships, internships);

    // Notify matching students
    loadList(DB_KEYS.students).forEach((student) => {
      const pct = matchPercent(
        student.skills,
        newJob.skills
      );

      if (pct > 0) {
        addNotification(
          student.id,
          "student",
          `New opportunity matches your skills (${pct}%): "${newJob.title}" at ${newJob.companyName}.`
        );
      }
    });

    f.reset();

    showToast("Opportunity posted.");
    renderInternships();
  });

/* ==========================================================
   AI Career Mentor Chatbot
========================================================== */

const mentorMessages =
  document.getElementById("mentorMessages");

function mentorSay(text, who = "bot") {
  const bubble = document.createElement("div");

  bubble.className = `mentor-msg mentor-msg-${who}`;
  bubble.textContent = text;

  mentorMessages.appendChild(bubble);
  mentorMessages.scrollTop = mentorMessages.scrollHeight;
}

function mentorReply(userText) {
  const text = userText.toLowerCase();

  const roleSkillMap = {
    "data science": [
      "Python",
      "SQL",
      "Statistics",
      "Pandas"
    ],
    "data analyst": [
      "SQL",
      "Excel",
      "Python"
    ],
    "web development": [
      "HTML",
      "CSS",
      "JavaScript",
      "React"
    ],
    frontend: [
      "HTML",
      "CSS",
      "JavaScript",
      "React"
    ],
    backend: [
      "Node.js",
      "SQL",
      "APIs"
    ],
    "app development": [
      "Java",
      "Kotlin",
      "Flutter"
    ],
    cloud: [
      "AWS",
      "Linux",
      "Docker"
    ],
    ai: [
      "Python",
      "Machine Learning",
      "Statistics"
    ],
    "machine learning": [
      "Python",
      "Statistics",
      "Machine Learning"
    ]
  };

  for (const role in roleSkillMap) {
    if (text.includes(role)) {
      return `For ${role}, focus on: ${roleSkillMap[
        role
      ].join(", ")}. Add these skills to your Skill Dashboard.`;
    }
  }

  if (
    text.includes("resume") ||
    text.includes("cv")
  ) {
    return `Go to your Skill Dashboard and click "Build My Resume".`;
  }

  if (text.includes("interview")) {
    return `Interview schedules appear under "Upcoming Interviews" on your dashboard.`;
  }

  if (
    text.includes("match") ||
    text.includes("score")
  ) {
    return `The AI Match Score compares your skills with job requirements.`;
  }

  const student = currentStudent();

  if (student && student.skills.length) {
    return `You've added ${student.skills.length} skills. Ask me what skills are needed for a specific career.`;
  }

  return `Ask me about web development, AI, data science, cloud, resumes, or interview preparation.`;
}

const mentorToggle =
  document.getElementById("mentorToggle");
const mentorPanel =
  document.getElementById("mentorPanel");
const mentorClose =
  document.getElementById("mentorClose");
const mentorForm =
  document.getElementById("mentorForm");
const mentorInput =
  document.getElementById("mentorInput");

let mentorOpened = false;

mentorToggle.addEventListener("click", () => {
  mentorPanel.classList.toggle("is-open");

  if (
    mentorPanel.classList.contains("is-open") &&
    !mentorOpened
  ) {
    mentorOpened = true;

    mentorSay(
      "Hi! I'm your AI Career Mentor. Ask me which skills or courses to learn for your target role."
    );
  }
});

mentorClose.addEventListener("click", () => {
  mentorPanel.classList.remove("is-open");
});

mentorForm.addEventListener("submit", (e) => {
  e.preventDefault();

  const value = mentorInput.value.trim();

  if (!value) return;

  mentorSay(value, "user");
  mentorInput.value = "";

  setTimeout(() => {
    mentorSay(mentorReply(value), "bot");
  }, 300);
});

/* ==========================================================
   Utilities
========================================================== */

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

let toastTimer = null;

function showToast(message) {
  let toast = document.querySelector(".toast");

  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast";
    document.body.appendChild(toast);
  }

  toast.textContent = message;
  toast.classList.add("is-visible");

  clearTimeout(toastTimer);

  toastTimer = setTimeout(() => {
    toast.classList.remove("is-visible");
  }, 2600);
}

/* ==========================================================
   Init
========================================================== */

seedIfEmpty();
renderNav();
renderHeaderTools();
navigate("home");
