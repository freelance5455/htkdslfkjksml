const home=document.getElementById("home"),lobby=document.getElementById("lobby"),airplane=document.getElementById("airplane"),game=document.getElementById("game"),gameUI=document.getElementById("gameUI");
const playBtn=document.getElementById("playBtn"),startBtn=document.getElementById("startBtn"),jumpBtn=document.getElementById("jumpBtn");
const googleBtn=document.getElementById("googleBtn"),dropZone=document.getElementById("dropZone");
const fireBtn=document.getElementById("fire"),glooBtn=document.getElementById("gloo"),carBtn=document.getElementById("car");
const joystick=document.getElementById("joystick"),stick=document.getElementById("stick");
const hpText=document.getElementById("hp"),damageText=document.getElementById("damage"),weaponName=document.getElementById("weaponName"),ammoText=document.getElementById("ammo"),locationName=document.getElementById("locationName"),zoneText=document.getElementById("zone");
let scene,camera,renderer,player,enemy,car,started=false,driving=false,moveX=0,moveY=0,playerHP=100,enemyHP=100,currentWeapon="AR-01",glooWalls=[],bullets=[];
const weapons={"AR-01":{damage:25,ammo:30,maxAmmo:120,range:45},"SMG-09":{damage:15,ammo:40,maxAmmo:160,range:30},"DMR-77":{damage:50,ammo:10,maxAmmo:60,range:80},"SG-12":{damage:70,ammo:6,maxAmmo:36,range:18}};

googleBtn.onclick=()=>{document.getElementById("loginStatus").innerText="Google Player";googleBtn.innerText="✓ GOOGLE CONNECTED";};
playBtn.onclick=()=>{home.classList.add("hidden");lobby.classList.remove("hidden");};
startBtn.onclick=()=>{lobby.classList.add("hidden");airplane.classList.remove("hidden");};
jumpBtn.onclick=()=>{airplane.classList.add("hidden");game.classList.remove("hidden");gameUI.classList.remove("hidden");startGame();};

function startGame(){
 if(started)return; started=true;
 scene=new THREE.Scene(); scene.background=new THREE.Color(0x79c9ee); scene.fog=new THREE.Fog(0x79c9ee,50,220);
 camera=new THREE.PerspectiveCamera(70,window.innerWidth/window.innerHeight,.1,600); camera.position.set(0,6,15);
 renderer=new THREE.WebGLRenderer({antialias:true}); renderer.setSize(window.innerWidth,window.innerHeight); renderer.setPixelRatio(Math.min(window.devicePixelRatio,2)); game.appendChild(renderer.domElement);
 const sun=new THREE.DirectionalLight(0xffffff,2.4); sun.position.set(40,70,30); scene.add(sun);
 scene.add(new THREE.HemisphereLight(0xbceaff,0x3c542b,1.2)); createIsland();
 player=new THREE.Mesh(new THREE.BoxGeometry(1.3,2.3,1.3),new THREE.MeshStandardMaterial({color:0x2459ff})); player.position.set(0,.15,10); scene.add(player);
 enemy=new THREE.Mesh(new THREE.BoxGeometry(1.3,2.3,1.3),new THREE.MeshStandardMaterial({color:0xe52424})); enemy.position.set(0,.15,-20); scene.add(enemy);
 createCar(12,4); animate();
}
function createIsland(){
 const ground=new THREE.Mesh(new THREE.BoxGeometry(200,1,200),new THREE.MeshStandardMaterial({color:0x438c38})); ground.position.y=-1; scene.add(ground);
 createRoad(0,0,190,8); createRoad(0,0,8,190);
 createMountain(-45,-40,20,18); createBuilding(-45,-40,10,7,8,0xeeeeee);
 createMountain(45,-42,17,14); createBuilding(45,-42,9,6,8,0x92704d);
 createBuilding(-45,35,20,9,14,0x777777); createBuilding(-28,35,8,6,8,0x555555);
 createBuilding(42,34,18,8,13,0x8b5938); createBuilding(55,34,8,5,8,0x63412d);
 [[-15,-25],[15,-25],[-15,30],[15,30],[-65,0],[65,0],[-60,60],[60,60]].forEach(p=>createBuilding(p[0],p[1],7,5,7,0xc48750));
 [[-10,-10],[10,-12],[-25,-5],[25,5],[-70,-20],[70,-20],[-70,25],[70,25],[-5,60],[20,60],[-20,70],[40,65]].forEach(p=>createTree(p[0],p[1]));
}
function createRoad(x,z,width,depth){const road=new THREE.Mesh(new THREE.BoxGeometry(width,.08,depth),new THREE.MeshStandardMaterial({color:0x343434}));road.position.set(x,-.45,z);scene.add(road);}
function createBuilding(x,z,w,h,d,color){
 const building=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshStandardMaterial({color})); building.position.set(x,h/2-1,z); scene.add(building);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(w+.5,.5,d+.5),new THREE.MeshStandardMaterial({color:0x49352b})); roof.position.set(x,h-.7,z); scene.add(roof);
}
function createMountain(x,z,radius,height){const mountain=new THREE.Mesh(new THREE.ConeGeometry(radius,height,8),new THREE.MeshStandardMaterial({color:0x56654d}));mountain.position.set(x,height/2-1,z);scene.add(mountain);}
function createTree(x,z){
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.35,.45,3,8),new THREE.MeshStandardMaterial({color:0x70441f}));trunk.position.set(x,.5,z);scene.add(trunk);
 const leaves=new THREE.Mesh(new THREE.SphereGeometry(2,10,10),new THREE.MeshStandardMaterial({color:0x166b2b}));leaves.position.set(x,3,z);scene.add(leaves);
}
function createCar(x,z){
 car=new THREE.Mesh(new THREE.BoxGeometry(3.5,1,2),new THREE.MeshStandardMaterial({color:0x1d4f9e}));car.position.set(x,0,z);scene.add(car);
 const roof=new THREE.Mesh(new THREE.BoxGeometry(2,.8,1.7),new THREE.MeshStandardMaterial({color:0x111111}));roof.position.set(x,.8,z);scene.add(roof);
}
carBtn.onclick=()=>{if(!player||!car)return;const distance=player.position.distanceTo(car.position);if(distance<10){driving=!driving;showDamage(driving?"VEHICLE ON":"VEHICLE OFF");}else showDamage("GO NEAR CAR");};
document.querySelectorAll(".weapon").forEach(button=>{button.onclick=()=>{document.querySelectorAll(".weapon").forEach(b=>b.classList.remove("active"));button.classList.add("active");currentWeapon=button.dataset.weapon;weaponName.innerText=currentWeapon;ammoText.innerText=weapons[currentWeapon].ammo+" / "+weapons[currentWeapon].maxAmmo;}});
fireBtn.onclick=()=>{
 if(!enemy)return; const weapon=weapons[currentWeapon]; if(weapon.ammo<=0){showDamage("RELOAD");return;}
 weapon.ammo--;ammoText.innerText=weapon.ammo+" / "+weapon.maxAmmo;
 const distance=player.position.distanceTo(enemy.position);
 if(distance<=weapon.range&&enemy.visible){enemyHP-=weapon.damage;showDamage("-"+weapon.damage);if(enemyHP<=0){enemyHP=0;enemy.visible=false;showDamage("ELIMINATED");}}else showDamage("MISS");
};
glooBtn.onclick=()=>{
 if(!player)return;
 const wall=new THREE.Mesh(new THREE.BoxGeometry(5,3.5,.7),new THREE.MeshStandardMaterial({color:0x55d9ff,transparent:true,opacity:.82}));
 wall.position.set(player.position.x,.75,player.position.z-3);scene.add(wall);glooWalls.push(wall);showDamage("GLOO WALL");
 setTimeout(()=>scene.remove(wall),20000);
};
function showDamage(text){damageText.innerText=text;damageText.style.opacity="1";setTimeout(()=>damageText.style.opacity="0",700);}
joystick.addEventListener("touchmove",function(e){
 e.preventDefault(); const touch=e.touches[0],rect=joystick.getBoundingClientRect();
 let x=touch.clientX-(rect.left+rect.width/2),y=touch.clientY-(rect.top+rect.height/2);
 const max=rect.width/2-28, distance=Math.sqrt(x*x+y*y);
 if(distance>max){x=x/distance*max;y=y/distance*max;}
 stick.style.left=(rect.width/2-28+x)+"px";
 stick.style.top=(rect.height/2-28+y)+"px";
 moveX=x/max;moveY=y/max;
},{passive:false});
joystick.addEventListener("touchend",resetJoystick);joystick.addEventListener("touchcancel",resetJoystick);
function resetJoystick(){moveX=0;moveY=0;stick.style.left="33px";stick.style.top="33px";}
function updatePlayer(){
 if(!player)return; let speed=driving?.35:.16;
 player.position.x+=moveX*speed;player.position.z+=moveY*speed;
 player.position.x=Math.max(-92,Math.min(92,player.position.x));player.position.z=Math.max(-92,Math.min(92,player.position.z));
 if(driving&&car){car.position.x=player.position.x;car.position.z=player.position.z;}
 camera.position.x=player.position.x;camera.position.z=player.position.z+11;camera.lookAt(player.position.x,1,player.position.z-12);updateLocation();
}
function updateLocation(){
 const x=player.position.x,z=player.position.z;let name="ISLAND";
 if(x<-30&&z<-25)name="PEAK";else if(x>30&&z<-25)name="OLD PEAK";else if(x<-30&&z>20)name="FACTORY";else if(x>30&&z>20)name="OLD FACTORY";
 locationName.innerText=name;
}
let temperature=28;
setInterval(()=>{if(!started)return;temperature+=Math.random()>.5?.2:-.1;temperature=Math.max(26,Math.min(40,temperature));zoneText.innerText="🌡️ "+temperature.toFixed(1)+"°C";},3000);
function animate(){requestAnimationFrame(animate);updatePlayer();renderer.render(scene,camera);}
window.addEventListener("resize",()=>{if(!camera||!renderer)return;camera.aspect=window.innerWidth/window.innerHeight;camera.updateProjectionMatrix();renderer.setSize(window.innerWidth,window.innerHeight);});
