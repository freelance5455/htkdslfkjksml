/* =========================================================
   SRI LAKSHMI SAI SURAT SAREES
   FINAL BILLING SYSTEM
   ========================================================= */

let currentBill = [];
let bills = [];
let products = [];

let currentLanguage = "en";
let salesChart = null;
let lastSavedBill = null;


/* =========================================================
   SHOP DETAILS
   ========================================================= */

const SHOP = {
  name: "SRI LAKSHMI SAI SURAT SAREES",
  address: "Your Shop Address",
  phone: "Your Phone Number",
  gstin: ""
};


/* =========================================================
   TRANSLATIONS
   ========================================================= */

const translations = {

  en: {

    newBill: "🧾 New Bill",
    products: "📦 Products",
    history: "📜 Bill History",
    report: "📊 Sales Report",

    welcome: "Welcome! 👋",
    selectOption: "Select an option above to get started.",

    newBillTitle: "🧾 New Bill",
    selectProduct: "Select Product",
    chooseProduct: "-- Select a product --",
    quantity: "Quantity",
    price: "Price per unit",
    unit: "Unit",
    addItem: "➕ Add Item",
    total: "Total",
    saveBill: "✅ Save Bill",
    printBill: "🖨️ Print Bill",

    productsTitle: "📦 Products",
    productName: "Product name",
    productPrice: "Price",
    stock: "Stock",
    addProduct: "➕ Add Product",

    noProducts: "No products added yet.",
    noProductSelected: "Please select a product.",

    edit: "✏️ Edit",
    delete: "🗑️ Delete",
    restock: "🔄 Restock",

    historyTitle: "📜 Bill History",
    noBills: "No bills yet.",

    totalBills: "Total Bills",
    totalSales: "Total Sales",
    salesReport: "📊 Sales Report",

    cash: "Cash",
    upi: "UPI",
    card: "Card",

    validDetails: "Please enter valid details.",
    addItemFirst: "Add an item first.",

    billSaved: "Bill saved successfully!",
    productSaved: "Product added successfully!",
    updated: "Product updated successfully!",

    confirmDelete: "Delete this product?",

    stockNotEnough: "Not enough stock for",

    restockQuestion: "How many units do you want to add?",

    printDemo: "Demo receipt created. Choose Print in the print dialog.",

    thankYou: "Thank you for shopping with us!",
    payment: "Payment",

    billNumber: "Bill No",
    date: "Date",

    day: "Day",

    zoomHint: "Pinch or scroll to zoom • Drag to move"
  },


  te: {

    newBill: "🧾 కొత్త బిల్లు",
    products: "📦 ఉత్పత్తులు",
    history: "📜 బిల్లుల చరిత్ర",
    report: "📊 అమ్మకాల నివేదిక",

    welcome: "స్వాగతం! 👋",
    selectOption: "ప్రారంభించడానికి పైన ఉన్న ఎంపికను ఎంచుకోండి.",

    newBillTitle: "🧾 కొత్త బిల్లు",
    selectProduct: "ఉత్పత్తిని ఎంచుకోండి",
    chooseProduct: "-- ఉత్పత్తిని ఎంచుకోండి --",
    quantity: "పరిమాణం",
    price: "ఒక్కొక్క ధర",
    unit: "యూనిట్",
    addItem: "➕ వస్తువు జోడించండి",
    total: "మొత్తం",
    saveBill: "✅ బిల్లు సేవ్ చేయండి",
    printBill: "🖨️ బిల్ ప్రింట్ చేయండి",

    productsTitle: "📦 ఉత్పత్తులు",
    productName: "ఉత్పత్తి పేరు",
    productPrice: "ధర",
    stock: "స్టాక్",
    addProduct: "➕ ఉత్పత్తిని జోడించండి",

    noProducts: "ఇంకా ఉత్పత్తులు జోడించలేదు.",
    noProductSelected: "దయచేసి ఒక ఉత్పత్తిని ఎంచుకోండి.",

    edit: "✏️ మార్చండి",
    delete: "🗑️ తొలగించండి",
    restock: "🔄 Restock",

    historyTitle: "📜 బిల్లుల చరిత్ర",
    noBills: "ఇంకా బిల్లులు లేవు.",

    totalBills: "మొత్తం బిల్లులు",
    totalSales: "మొత్తం అమ్మకాలు",
    salesReport: "📊 అమ్మకాల నివేదిక",

    cash: "Cash",
    upi: "UPI",
    card: "Card",

    validDetails: "దయచేసి సరైన వివరాలను నమోదు చేయండి.",
    addItemFirst: "ముందుగా ఒక వస్తువును జోడించండి.",

    billSaved: "బిల్లు విజయవంతంగా సేవ్ చేయబడింది!",
    productSaved: "ఉత్పత్తి విజయవంతంగా జోడించబడింది!",
    updated: "ఉత్పత్తి విజయవంతంగా మార్చబడింది!",

    confirmDelete: "ఈ ఉత్పత్తిని తొలగించాలా?",

    stockNotEnough: "ఈ ఉత్పత్తికి సరిపడా స్టాక్ లేదు:",

    restockQuestion: "ఎన్ని యూనిట్లు జోడించాలి?",

    printDemo: "డెమో రసీదు సిద్ధంగా ఉంది.",

    thankYou: "మాతో షాపింగ్ చేసినందుకు ధన్యవాదాలు!",
    payment: "చెల్లింపు",

    billNumber: "బిల్ నంబర్",
    date: "తేదీ",

    day: "రోజు",

    zoomHint: "జూమ్ చేయడానికి పించ్ చేయండి • కదల్చడానికి డ్రాగ్ చేయండి"
  }

};


function t(key) {
  return translations[currentLanguage][key] || key;
}


/* =========================================================
   LANGUAGE
   ========================================================= */

function changeLanguage() {

  const selector =
    document.getElementById("languageSelect");

  if (!selector) return;

  currentLanguage = selector.value;

  localStorage.setItem(
    "shopLanguage",
    currentLanguage
  );

  updateMenu();

  const page = document.body.dataset.page;

  if (page) {
    showPage(page);
  } else {
    showWelcome();
  }
}


function updateMenu() {

  const billBtn =
    document.getElementById("billBtn");

  const productsBtn =
    document.getElementById("productsBtn");

  const historyBtn =
    document.getElementById("historyBtn");

  const reportBtn =
    document.getElementById("reportBtn");


  if (billBtn)
    billBtn.textContent = t("newBill");

  if (productsBtn)
    productsBtn.textContent = t("products");

  if (historyBtn)
    historyBtn.textContent = t("history");

  if (reportBtn)
    reportBtn.textContent = t("report");
}


/* =========================================================
   PAGE NAVIGATION
   ========================================================= */

function showPage(page) {

  document.body.dataset.page = page;

  if (page === "bill") {
    showBill();
  }

  if (page === "products") {
    showProducts();
  }

  if (page === "history") {
    showHistory();
  }

  if (page === "report") {
    showReport();
  }
}


function showWelcome() {

  const content =
    document.getElementById("content");

  if (!content) return;

  content.innerHTML = `
    <h2>${t("welcome")}</h2>
    <p>${t("selectOption")}</p>
  `;
}


/* =========================================================
   DAILY BILL NUMBER
   Resets to 0001 every new day.
   ========================================================= */

function getTodayKey() {

  const now = new Date();

  return (
    now.getFullYear() +
    "-" +
    String(now.getMonth() + 1).padStart(2, "0") +
    "-" +
    String(now.getDate()).padStart(2, "0")
  );
}


function getNextBillNumber() {

  const today = getTodayKey();

  const savedDate =
    localStorage.getItem("billNumberDate");

  let number =
    Number(
      localStorage.getItem("dailyBillNumber")
    ) || 0;


  if (savedDate !== today) {

    number = 0;

    localStorage.setItem(
      "billNumberDate",
      today
    );
  }


  number++;

  localStorage.setItem(
    "dailyBillNumber",
    number
  );

  return String(number).padStart(4, "0");
}


/* =========================================================
   NEW BILL
   ========================================================= */

function showBill() {

  const content =
    document.getElementById("content");

  if (!content) return;


  let productOptions = `
    <option value="">
      ${t("chooseProduct")}
    </option>
  `;


  products.forEach(function(product) {

    productOptions += `
      <option value="${product.id}">
        ${escapeHTML(product.name)}
        — ₹${product.price}
        / ${escapeHTML(product.unit)}
        — Stock: ${product.stock}
      </option>
    `;

  });


  content.innerHTML = `

    <h2>${t("newBillTitle")}</h2>

    <label>
      ${t("selectProduct")}
    </label>

    <select
      id="selectedProduct"
      onchange="productSelected()"
    >
      ${productOptions}
    </select>

    <input
      id="quantity"
      type="number"
      min="1"
      placeholder="${t("quantity")}"
    >

    <input
      id="price"
      type="number"
      readonly
      placeholder="${t("price")}"
    >

    <input
      id="unit"
      readonly
      placeholder="${t("unit")}"
    >

    <p id="availableStock"></p>

    <button onclick="addItem()">
      ${t("addItem")}
    </button>

    <div id="billItems"></div>

    <h3>
      ${t("total")}:
      ₹<span id="total">0</span>
    </h3>

    <select id="payment">

      <option>${t("cash")}</option>
      <option>${t("upi")}</option>
      <option>${t("card")}</option>

    </select>

    <button onclick="saveBill()">
      ${t("saveBill")}
    </button>

    <div id="savedBillActions"></div>

  `;


  displayCurrentBill();


  if (lastSavedBill) {

    showPrintButton();

  }
}


/* =========================================================
   PRODUCT SELECTION
   ========================================================= */

function productSelected() {

  const select =
    document.getElementById("selectedProduct");

  const price =
    document.getElementById("price");

  const unit =
    document.getElementById("unit");

  const stock =
    document.getElementById("availableStock");


  if (!select) return;


  const product =
    products.find(function(product) {

      return String(product.id) ===
        String(select.value);

    });


  if (!product) {

    if (price) price.value = "";
    if (unit) unit.value = "";
    if (stock) stock.textContent = "";

    return;
  }


  price.value = product.price;
  unit.value = product.unit;

  stock.textContent =
    "📦 Stock available: " +
    product.stock;
}


/* =========================================================
   ADD ITEM
   ========================================================= */

function addItem() {

  const select =
    document.getElementById(
      "selectedProduct"
    );

  const quantity =
    Number(
      document.getElementById(
        "quantity"
      ).value
    );


  if (!select) return;


  const product =
    products.find(function(product) {

      return String(product.id) ===
        String(select.value);

    });


  if (!product) {

    alert(t("noProductSelected"));

    return;
  }


  if (
    !Number.isInteger(quantity) ||
    quantity <= 0
  ) {

    alert(t("validDetails"));

    return;
  }


  const alreadyInBill =
    currentBill
      .filter(function(item) {

        return item.productId ===
          product.id;

      })
      .reduce(function(sum, item) {

        return sum + item.quantity;

      }, 0);


  if (
    alreadyInBill + quantity >
    product.stock
  ) {

    alert(
      t("stockNotEnough") +
      " " +
      product.name +
      ". Available: " +
      product.stock
    );

    return;
  }


  currentBill.push({

    productId: product.id,
    name: product.name,
    quantity: quantity,
    unit: product.unit,
    price: product.price,
    total: quantity * product.price

  });


  document.getElementById(
    "selectedProduct"
  ).value = "";

  document.getElementById(
    "quantity"
  ).value = "";

  document.getElementById(
    "price"
  ).value = "";

  document.getElementById(
    "unit"
  ).value = "";

  document.getElementById(
    "availableStock"
  ).textContent = "";


  displayCurrentBill();
}


/* =========================================================
   DISPLAY CURRENT BILL
   ========================================================= */

function displayCurrentBill() {

  const list =
    document.getElementById(
      "billItems"
    );

  const totalElement =
    document.getElementById(
      "total"
    );


  if (!list || !totalElement)
    return;


  let total = 0;

  list.innerHTML = "";


  currentBill.forEach(
    function(item, index) {

      total += item.total;


      list.innerHTML += `

        <div>

          <p>

            ${escapeHTML(item.name)}
            —
            ${item.quantity}
            ${escapeHTML(item.unit)}
            × ₹${item.price}
            = ₹${item.total}

            <button
              onclick="removeItem(${index})"
            >
              ❌
            </button>

          </p>

        </div>

      `;

    }
  );


  totalElement.textContent = total;
}


function removeItem(index) {

  currentBill.splice(
    index,
    1
  );

  displayCurrentBill();
}


/* =========================================================
   SAVE BILL
   ========================================================= */

function saveBill() {

  if (currentBill.length === 0) {

    alert(t("addItemFirst"));

    return;
  }


  /* Final stock check */

  for (const item of currentBill) {

    const product =
      products.find(function(product) {

        return product.id ===
          item.productId;

      });


    if (
      !product ||
      item.quantity > product.stock
    ) {

      alert(
        t("stockNotEnough") +
        " " +
        item.name
      );

      return;
    }

  }


  let total = 0;


  currentBill.forEach(function(item) {

    total += item.total;

  });


  const payment =
    document.getElementById(
      "payment"
    ).value;


  /* Deduct stock */

  currentBill.forEach(function(item) {

    const product =
      products.find(function(product) {

        return product.id ===
          item.productId;

      });


    if (product) {

      product.stock -=
        item.quantity;

    }

  });


  /* Create daily bill number */

  const billNumber =
    getNextBillNumber();


  /* Save bill */

  const bill = {

    billNumber: billNumber,

    items: [...currentBill],

    total: total,

    payment: payment,

    date: new Date().toISOString()

  };


  bills.push(bill);

  lastSavedBill = bill;


  localStorage.setItem(
    "shopBills",
    JSON.stringify(bills)
  );


  saveProducts();


  currentBill = [];


  alert(t("billSaved"));


  showBill();

}


/* =========================================================
   PRINT BUTTON
   ========================================================= */

function showPrintButton() {

  const container =
    document.getElementById(
      "savedBillActions"
    );


  if (!container ||
      !lastSavedBill)
    return;


  container.innerHTML = `

    <div
      style="
        margin-top:20px;
        padding:15px;
        border:1px solid #ccc;
        border-radius:10px;
        text-align:center;
      "
    >

      <h3>
        🧾 Bill #${lastSavedBill.billNumber}
      </h3>

      <p>
        Total: ₹${lastSavedBill.total}
      </p>

      <button
        onclick="printBill()"
      >
        ${t("printBill")}
      </button>

    </div>

  `;
}


/* =========================================================
   DEMO PRINT
   ========================================================= */

function printBill() {

  if (!lastSavedBill) {

    alert(
      "There is no saved bill to print."
    );

    return;
  }


  const bill =
    lastSavedBill;


  const date =
    new Date(
      bill.date
    ).toLocaleString();


  let itemsHTML = "";


  bill.items.forEach(function(item) {

    itemsHTML += `

      <tr>

        <td>
          ${escapeHTML(item.name)}
        </td>

        <td>
          ${item.quantity}
        </td>

        <td>
          ₹${item.price}
        </td>

        <td>
          ₹${item.total}
        </td>

      </tr>

    `;

  });


  const printWindow =
    window.open(
      "",
      "_blank",
      "width=400,height=700"
    );


  if (!printWindow) {

    alert(
      "Please allow pop-ups to print the bill."
    );

    return;
  }


  printWindow.document.write(`

    <!DOCTYPE html>

    <html>

    <head>

      <meta charset="UTF-8">

      <title>
        Bill ${bill.billNumber}
      </title>

      <style>

        * {
          box-sizing: border-box;
        }

        body {

          width: 58mm;

          margin: 0 auto;

          padding: 5mm 3mm;

          font-family:
            Arial,
            sans-serif;

          font-size: 12px;

          color: #000;

        }

        .center {
          text-align: center;
        }

        .shop-name {

          font-size: 16px;

          font-weight: bold;

          margin-bottom: 5px;

        }

        .small {
          font-size: 10px;
        }

        .line {

          border-top:
            1px dashed #000;

          margin:
            8px 0;

        }

        table {

          width: 100%;

          border-collapse:
            collapse;

        }

        th,
        td {

          padding:
            3px 1px;

          text-align:
            left;

          vertical-align:
            top;

        }

        th {

          border-bottom:
            1px solid #000;

        }

        .right {
          text-align: right;
        }

        .total {

          font-size: 15px;

          font-weight: bold;

        }

        .footer {

          text-align: center;

          margin-top: 15px;

        }

        @media print {

          body {

            width: 58mm;

            margin: 0;

          }

        }

      </style>

    </head>

    <body>

      <div class="center">

        <div class="shop-name">
          ${escapeHTML(SHOP.name)}
        </div>

        <div class="small">
          ${escapeHTML(SHOP.address)}
        </div>

        <div class="small">
          ${escapeHTML(SHOP.phone)}
        </div>

      </div>


      <div class="line"></div>


      <div>

        <strong>
          ${t("billNumber")}:
        </strong>

        ${bill.billNumber}

        <br>

        <strong>
          ${t("date")}:
        </strong>

        ${date}

      </div>


      <div class="line"></div>


      <table>

        <thead>

          <tr>

            <th>
              Item
            </th>

            <th>
              Qty
            </th>

            <th>
              Price
            </th>

            <th>
              Amount
            </th>

          </tr>

        </thead>

        <tbody>

          ${itemsHTML}

        </tbody>

      </table>


      <div class="line"></div>


      <div class="total">

        ${t("total")}:
        ₹${bill.total}

      </div>


      <div>

        ${t("payment")}:
        ${escapeHTML(bill.payment)}

      </div>


      <div class="footer">

        ${t("thankYou")}

      </div>


      <script>

        window.onload = function() {

          window.print();

        };

      <\/script>

    </body>

    </html>

  `);


  printWindow.document.close();

}


/* =========================================================
   PRODUCTS
   ========================================================= */

function showProducts() {

  const content =
    document.getElementById(
      "content"
    );


  if (!content) return;


  content.innerHTML = `

    <h2>
      ${t("productsTitle")}
    </h2>

    <input
      id="productName"
      placeholder="${t("productName")}"
    >

    <input
      id="productPrice"
      type="number"
      min="0"
      placeholder="${t("productPrice")}"
    >

    <select id="productUnit">

      <option>Piece</option>
      <option>Metre</option>

    </select>

    <input
      id="productStock"
      type="number"
      min="0"
      placeholder="${t("stock")}"
    >

    <button
      onclick="addProduct()"
    >
      ${t("addProduct")}
    </button>

    <div id="productList"></div>

  `;


  displayProducts();
}


/* =========================================================
   ADD PRODUCT
   ========================================================= */

function addProduct() {

  const name =
    document.getElementById(
      "productName"
    ).value.trim();


  const price =
    Number(
      document.getElementById(
        "productPrice"
      ).value
    );


  const unit =
    document.getElementById(
      "productUnit"
    ).value;


  const stock =
    Number(
      document.getElementById(
        "productStock"
      ).value
    );


  if (
    !name ||
    price < 0 ||
    stock < 0
  ) {

    alert(
      t("validDetails")
    );

    return;
  }


  products.push({

    id: Date.now(),

    name: name,

    price: price,

    unit: unit,

    stock: stock

    });


  saveProducts();


  document.getElementById(
    "productName"
  ).value = "";

  document.getElementById(
    "productPrice"
  ).value = "";

  document.getElementById(
    "productStock"
  ).value = "";


  displayProducts();


  alert(
    t("productSaved")
  );
}


/* =========================================================
   DISPLAY PRODUCTS
   ========================================================= */

function displayProducts() {

  const list =
    document.getElementById(
      "productList"
    );


  if (!list) return;


  if (products.length === 0) {

    list.innerHTML =
      `<p>${t("noProducts")}</p>`;

    return;
  }


  list.innerHTML = "";


  products.forEach(function(product) {

    list.innerHTML += `

      <div
        style="
          border:1px solid #ddd;
          padding:12px;
          margin:10px 0;
          border-radius:10px;
        "
      >

        <h3>
          📦 ${escapeHTML(product.name)}
        </h3>

        <p>
          💰 ₹${product.price}
          / ${escapeHTML(product.unit)}
        </p>

        <p>
          📦 ${t("stock")}:
          <strong>
            ${product.stock}
          </strong>
        </p>

        <button
          onclick="restockProduct(${product.id})"
        >
          ${t("restock")}
        </button>

        <button
          onclick="editProduct(${product.id})"
        >
          ${t("edit")}
        </button>

        <button
          onclick="deleteProduct(${product.id})"
        >
          ${t("delete")}
        </button>

      </div>

    `;

  });
}


/* =========================================================
   RESTOCK
   ========================================================= */

function restockProduct(id) {

  const product =
    products.find(function(product) {

      return product.id === id;

    });


  if (!product) return;


  const amount =
    prompt(
      "How many " +
      product.unit +
      "s do you want to add?"
    );


  if (amount === null)
    return;


  const numberToAdd =
    Number(amount);


  if (
    !Number.isInteger(numberToAdd) ||
    numberToAdd <= 0
  ) {

    alert(
      "Please enter a valid whole number."
    );

    return;
  }


  product.stock +=
    numberToAdd;


  saveProducts();

  displayProducts();


  alert(
    "Restocked successfully! New stock: " +
    product.stock
  );
}


/* =========================================================
   EDIT PRODUCT
   ========================================================= */

function editProduct(id) {

  const product =
    products.find(function(product) {

      return product.id === id;

    });


  if (!product) return;


  const newName =
    prompt(
      "Product name:",
      product.name
    );


  if (newName === null)
    return;


  const newPrice =
    prompt(
      "Price:",
      product.price
    );


  if (newPrice === null)
    return;


  const newStock =
    prompt(
      "Stock:",
      product.stock
    );


  if (newStock === null)
    return;


  const price =
    Number(newPrice);

  const stock =
    Number(newStock);


  if (
    !newName.trim() ||
    isNaN(price) ||
    price < 0 ||
    isNaN(stock) ||
    stock < 0
  ) {

    alert(
      t("validDetails")
    );

    return;
  }


  product.name =
    newName.trim();

  product.price =
    price;

  product.stock =
    stock;


  saveProducts();

  displayProducts();


  alert(
    t("updated")
  );
}


/* =========================================================
   DELETE PRODUCT
   ========================================================= */

function deleteProduct(id) {

  if (
    !confirm(
      t("confirmDelete")
    )
  ) {

    return;
  }


  products =
    products.filter(function(product) {

      return product.id !== id;

    });


  saveProducts();

  displayProducts();
}


function saveProducts() {

  localStorage.setItem(
    "shopProducts",
    JSON.stringify(products)
  );
}


/* =========================================================
   HISTORY
   ========================================================= */

function showHistory() {

  const content =
    document.getElementById(
      "content"
    );


  if (!content) return;


  content.innerHTML = `

    <h2>
      ${t("historyTitle")}
    </h2>

    <div id="historyList"></div>

  `;


  displayHistory();
}


function displayHistory() {

  const list =
    document.getElementById(
      "historyList"
    );


  if (!list) return;


  if (bills.length === 0) {

    list.innerHTML =
      `<p>${t("noBills")}</p>`;

    return;
  }


  list.innerHTML = "";


  bills.forEach(function(bill, index) {

    const date =
      new Date(
        bill.date
      ).toLocaleString();


    list.innerHTML += `

      <div
        style="
          border:1px solid #ddd;
          padding:12px;
          margin:10px 0;
          border-radius:10px;
        "
      >

        <h3>
          🧾 Bill #${bill.billNumber}
        </h3>

        <p>
          📅 ${date}
        </p>

        <p>
          💰 ${t("total")}:
          ₹${bill.total}
        </p>

        <p>
          💳 ${bill.payment}
        </p>

        <button
          onclick="printHistoryBill(${index})"
        >
          🖨️ Print Bill
        </button>

      </div>

    `;

  });
}


/* =========================================================
   PRINT BILL FROM HISTORY
   ========================================================= */

function printHistoryBill(index) {

  if (!bills[index])
    return;


  lastSavedBill =
    bills[index];


  printBill();
}


/* =========================================================
   SALES REPORT
   ========================================================= */

function showReport() {

  const content =
    document.getElementById(
      "content"
    );


  if (!content) return;


  let totalSales = 0;


  bills.forEach(function(bill) {

    totalSales +=
      Number(bill.total) || 0;

  });


  content.innerHTML = `

    <h2>
      ${t("salesReport")}
    </h2>

    <h3>
      ${t("totalBills")}:
      ${bills.length}
    </h3>

    <h3>
      ${t("totalSales")}:
      ₹${totalSales}
    </h3>

    <div
      style="
        width:100%;
        max-width:900px;
        margin:auto;
      "
    >

      <canvas
        id="salesChart"
      ></canvas>

    </div>

    <p
      style="
        text-align:center;
      "
    >
      🔍 ${t("zoomHint")}
    </p>

  `;


  if (
    bills.length === 0
  ) {

    return;
  }


  loadChartLibraries()
    .then(function() {

      createZoomableSalesChart();

    })
    .catch(function(error) {

      console.error(
        "Chart loading error:",
        error
      );

    });
}


/* =========================================================
   CHART LIBRARIES
   ========================================================= */

function loadChartLibraries() {

  return new Promise(
    function(resolve, reject) {

      if (
        window.Chart &&
        window.ChartZoom
      ) {

        resolve();

        return;
      }


      const chartScript =
        document.createElement(
          "script"
        );


      chartScript.src =
        "https://cdn.jsdelivr.net/npm/chart.js";


      chartScript.onload =
        function() {

          const zoomScript =
            document.createElement(
              "script"
            );


          zoomScript.src =
            "https://cdn.jsdelivr.net/npm/chartjs-plugin-zoom";


          zoomScript.onload =
            function() {

              if (
                window.ChartZoom
              ) {

                Chart.register(
                  window.ChartZoom
                );

              }

              resolve();

            };


          zoomScript.onerror =
            reject;


          document.head.appendChild(
            zoomScript
          );

        };


      chartScript.onerror =
        reject;


      document.head.appendChild(
        chartScript
      );

    }
  );
}


/* =========================================================
   SALES CHART
   ========================================================= */

function createZoomableSalesChart() {

  const canvas =
    document.getElementById(
      "salesChart"
    );


  if (!canvas) return;


  if (salesChart) {

    salesChart.destroy();

  }


  const sales = {};


  bills.forEach(function(bill) {

    const date =
      new Date(bill.date);


    const key =
      date
        .toISOString()
        .slice(0, 10);


    if (!sales[key]) {

      sales[key] = 0;

    }


    sales[key] +=
      Number(bill.total) || 0;

  });


  const labels =
    Object.keys(sales).sort();


  const values =
    labels.map(function(label) {

      return sales[label];

    });


  salesChart =
    new Chart(
      canvas,
      {

        type: "line",

        data: {

          labels: labels,

          datasets: [

            {

              label: "₹ Sales",

              data: values,

              tension: 0.3,

              fill: false,

              pointRadius: 4

            }

          ]

        },

        options: {

          responsive: true,

          interaction: {

            intersect: false,

            mode: "index"

          },

          scales: {

            x: {

              title: {

                display: true,

                text: t("day")

              }

            },

            y: {

              beginAtZero: true,

              title: {

                display: true,

                text: "₹"

              }

            }

          },

          plugins: {

            zoom: {

              pan: {

                enabled: true,

                mode: "x"

              },

              zoom: {

                wheel: {

                  enabled: true

                },

                pinch: {

                  enabled: true

                },

                mode: "x"

              }

            }

          }

        }

      }
    );
}


/* =========================================================
   DATA LOADING
   ========================================================= */

function loadData() {

  const savedBills =
    localStorage.getItem(
      "shopBills"
    );


  const savedProducts =
    localStorage.getItem(
      "shopProducts"
    );


  const savedLanguage =
    localStorage.getItem(
      "shopLanguage"
    );


  if (savedBills) {

    try {

      bills =
        JSON.parse(savedBills);

    } catch {

      bills = [];

    }

  }


  if (savedProducts) {

    try {

      products =
        JSON.parse(savedProducts);

    } catch {

      products = [];

    }

  }


  if (savedLanguage) {

    currentLanguage =
      savedLanguage;

  }


  const languageSelect =
    document.getElementById(
      "languageSelect"
    );


  if (languageSelect) {

    languageSelect.value =
      currentLanguage;

  }


  updateMenu();

  showWelcome();
}


/* =========================================================
   SECURITY / TEXT SAFETY
   ========================================================= */

function escapeHTML(value) {

  return String(value)

    .replaceAll("&", "&amp;")

    .replaceAll("<", "&lt;")

    .replaceAll(">", "&gt;")

    .replaceAll('"', "&quot;")

    .replaceAll("'", "&#039;");
}


/* =========================================================
   START APP
   ========================================================= */

loadData();