function updateText(id, value, suffix) {
    document.getElementById(id).innerText = value + suffix;
}

function cetakLog(pesan) {
    const terminal = document.getElementById('terminal');
    const waktu = new Date().toLocaleTimeString('id-ID');
    terminal.innerHTML += `> [${waktu}] ${pesan}<br>`;
    terminal.scrollTop = terminal.scrollHeight;
}
