const $ = (id) => document.getElementById(id);

const screen = $("gameScreen");
const ctx = screen.getContext("2d");

let currentImage = null;
let cropScale = 1;
let cropX = 0;
let cropY = 0;
let dragging = false;
let lastX = 0;
let lastY = 0;

let game = null;
let animationFrame = null;
let previousTime = 0;

// -----------------------------
// IDIOMAS
// -----------------------------

const translations = {
  es: {
    settings: "⚙ Configuración",
    language: "Idioma",
    background: "Color de fondo",
    screenColor: "Color de pantalla",
    buttonsColor: "Color de botones",
    image: "🖼 Personalizar imagen de pantalla",
    chooseImage: "Elegir imagen",
    cropHelp: "Arrastra la imagen para acomodarla.",
    zoom: "Ampliación",
    apply: "Aplicar imagen",
    game: "📁 Cargar juego",
    gameHelp: "Selecciona el archivo JavaScript que contiene el motor del juego.",
    chooseGame: "Abrir archivos",
    noGame: "Ningún juego cargado.",
    loaded: "Juego cargado correctamente.",
    incompatible: "El archivo no tiene el formato de motor esperado.",
    error: "No se pudo cargar el juego.",
    waiting: "Esperando archivo del juego..."
  },

  en: {
    settings: "⚙ Settings",
    language: "Language",
    background: "Background color",
    screenColor: "Screen color",
    buttonsColor: "Button color",
    image: "🖼 Customize screen image",
    chooseImage: "Choose image",
    cropHelp: "Drag the image to position it.",
    zoom: "Zoom",
    apply: "Apply image",
    game: "📁 Load game",
    gameHelp: "Choose the JavaScript file containing the game engine.",
    chooseGame: "Open files",
    noGame: "No game loaded.",
    loaded: "Game loaded successfully.",
    incompatible: "The file does not have the expected game engine format.",
    error: "Could not load the game.",
    waiting: "Waiting for game file..."
  }
};

let language = "es";

function updateLanguage() {
  language = $("language").value;
  const t = translations[language];

  $("settingsTitle").textContent = t.settings;
  $("languageLabel").textContent = t.language;
  $("backgroundLabel").textContent = t.background;
  $("screenColorLabel").textContent = t.screenColor;
  $("buttonsColorLabel").textContent = t.buttonsColor;

  $("imageTitle").textContent = t.image;
  $("chooseImage").textContent = t.chooseImage;
  $("cropHelp").textContent = t.cropHelp;
  $("zoomLabel").textContent = t.zoom;
  $("applyImage").textContent = t.apply;

  $("gameTitle").textContent = t.game;
  $("gameHelp").textContent = t.gameHelp;
  $("chooseGame").textContent = t.chooseGame;

  if (!game) {
    $("fileStatus").textContent = t.noGame;
    $("screenMessage").textContent = t.waiting;
  }

  if (game && typeof game.setLanguage === "function") {
    game.setLanguage(language);
  }
}

$("language").addEventListener("change", updateLanguage);

// -----------------------------
// PERSONALIZACIÓN DE COLORES
// -----------------------------

function changeColor(inputId, variable) {
  $(inputId).addEventListener("input", (event) => {
    document.documentElement.style.setProperty(
      variable,
      event.target.value
    );
  });
}

changeColor("backgroundColor", "--background");
changeColor("screenColor", "--screen");
changeColor("buttonsColor", "--buttons");

// -----------------------------
// SELECCIÓN DE IMAGEN
// -----------------------------

$("chooseImage").addEventListener("click", () => {
  $("imageFile").click();
});

$("imageFile").addEventListener("change", (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const imageURL = URL.createObjectURL(file);
  const image = new Image();

  image.onload = () => {
    currentImage = image;

    const baseScale = Math.max(
      280 / image.width,
      280 / image.height
    );

    cropScale = baseScale;
    cropX = (280 - image.width * cropScale) / 2;
    cropY = (280 - image.height * cropScale) / 2;

    $("zoom").value = 1;
    $("cropTools").hidden = false;

    drawCrop();

    URL.revokeObjectURL(imageURL);
  };

  image.onerror = () => {
    URL.revokeObjectURL(imageURL);
  };

  image.src = imageURL;
  event.target.value = "";
});

// -----------------------------
// RECORTE Y ACOMODO DE IMAGEN
// -----------------------------

const cropCanvas = $("cropCanvas");
const cropCtx = cropCanvas.getContext("2d");

function drawCrop() {
  cropCtx.clearRect(0, 0, 280, 280);

  cropCtx.fillStyle = "#FFF0F5";
  cropCtx.fillRect(0, 0, 280, 280);

  if (!currentImage) return;

  const baseScale = Math.max(
    280 / currentImage.width,
    280 / currentImage.height
  );

  const scale = baseScale * Number($("zoom").value);

  const centerX = 140;
  const centerY = 140;

  const initialX = (280 - currentImage.width * baseScale) / 2;
  const initialY = (280 - currentImage.height * baseScale) / 2;

  const extraX = (280 - currentImage.width * scale) / 2;
  const extraY = (280 - currentImage.height * scale) / 2;

  const adjustedX = extraX + (cropX - initialX) * scale / baseScale;
  const adjustedY = extraY + (cropY - initialY) * scale / baseScale;

  cropCtx.drawImage(
    currentImage,
    adjustedX,
    adjustedY,
    currentImage.width * scale,
    currentImage.height * scale
  );
}

$("zoom").addEventListener("input", drawCrop);

cropCanvas.addEventListener("pointerdown", (event) => {
  dragging = true;
  lastX = event.offsetX * (280 / cropCanvas.clientWidth);
  lastY = event.offsetY * (280 / cropCanvas.clientHeight);
  cropCanvas.setPointerCapture(event.pointerId);
});

cropCanvas.addEventListener("pointermove", (event) => {
  if (!dragging) return;

  const x = event.offsetX * (280 / cropCanvas.clientWidth);
  const y = event.offsetY * (280 / cropCanvas.clientHeight);

  cropX += x - lastX;
  cropY += y - lastY;

  lastX = x;
  lastY = y;

  drawCrop();
});

cropCanvas.addEventListener("pointerup", () => {
  dragging = false;
});

cropCanvas.addEventListener("pointercancel", () => {
  dragging = false;
});

$("applyImage").addEventListener("click", () => {
  if (!currentImage) return;

  const baseScale = Math.max(
    280 / currentImage.width,
    280 / currentImage.height
  );

  const scale = baseScale * Number($("zoom").value);

  const initialX = (280 - currentImage.width * baseScale) / 2;
  const initialY = (280 - currentImage.height * baseScale) / 2;

  const adjustedX =
    (280 - currentImage.width * scale) / 2 +
    (cropX - initialX) * scale / baseScale;

  const adjustedY =
    (280 - currentImage.height * scale) / 2 +
    (cropY - initialY) * scale / baseScale;

  ctx.clearRect(0, 0, 280, 280);

  ctx.drawImage(
    currentImage,
    adjustedX,
    adjustedY,
    currentImage.width * scale,
    currentImage.height * scale
  );

  $("screenMessage").hidden = true;
  $("cropTools").hidden = true;
});

// -----------------------------
// CARGAR MOTOR DEL JUEGO
// -----------------------------

$("chooseGame").addEventListener("click", () => {
  $("gameFile").click();
});

function showScreenMessage(message) {
  $("screenMessage").textContent = message;
  $("screenMessage").hidden = false;
}

function getGameAPI() {
  return {
    canvas: screen,
    ctx: ctx,
    language: language,

    clear() {
      ctx.clearRect(0, 0, 280, 280);
    },

    setLanguage(newLanguage) {
      language = newLanguage;
    }
  };
}

$("gameFile").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const t = translations[language];

  try {
    if (!file.name.toLowerCase().endsWith(".js")) {
      throw new Error("invalid-file");
    }

    const codeURL = URL.createObjectURL(file);
    let module;

    try {
      module = await import(codeURL);
    } finally {
      URL.revokeObjectURL(codeURL);
    }

    const newGame = module.default;

    if (!newGame || typeof newGame.start !== "function") {
      throw new Error("invalid-engine");
    }

    if (animationFrame !== null) {
      cancelAnimationFrame(animationFrame);
      animationFrame = null;
    }

    game = newGame;

    ctx.clearRect(0, 0, 280, 280);
    $("screenMessage").hidden = true;

    const api = getGameAPI();

    await game.start(api);

    $("fileStatus").textContent = t.loaded;

    previousTime = 0;

    function gameLoop(time) {
      if (!game) return;

      if (previousTime === 0) previousTime = time;

      const delta = (time - previousTime) / 1000;
      previousTime = time;

      if (typeof game.update === "function") {
        try {
          game.update(delta, api);
        } catch (error) {
          console.error(error);
        }
      }

      animationFrame = requestAnimationFrame(gameLoop);
    }

    animationFrame = requestAnimationFrame(gameLoop);

  } catch (error) {
    console.error(error);

    game = null;
    $("fileStatus").textContent =
      error.message === "invalid-file" ||
      error.message === "invalid-engine"
        ? t.incompatible
        : t.error;

    showScreenMessage(t.waiting);

  } finally {
    event.target.value = "";
  }
});

// -----------------------------
// BOTONES DE LA CONSOLA
// -----------------------------

function pressButton(button) {
  if (!game || typeof game.onButton !== "function") return;

  try {
    game.onButton(button, getGameAPI());
  } catch (error) {
    console.error(error);
  }
}

$("leftButton").addEventListener("click", () => {
  pressButton("left");
});

$("middleButton").addEventListener("click", () => {
  pressButton("middle");
});

$("rightButton").addEventListener("click", () => {
  pressButton("right");
});

// -----------------------------
// INICIO
// -----------------------------

updateLanguage();
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js")
      .then(() => console.log("Tamagotchi listo"))
      .catch(error => console.error("Error:", error));
  });
}