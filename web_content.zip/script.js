/* =====================================================
   script.js —— 视觉小说引擎（视图 / 逻辑层）
   不依赖任何第三方库。剧本数据全部来自 story.js
   ===================================================== */
(() => {
'use strict';

const S = window.STORY;
if (!S || !Array.isArray(S.script)) {
  document.body.innerHTML = '<p style="color:#ddd;padding:24px;font:16px sans-serif">未找到剧本数据：请确认 story.js 与 index.html 在同一目录，并且在 script.js 之前加载。</p>';
  return;
}

const META  = S.meta || {};
const CHARS = S.characters || {};
const BGS   = S.backgrounds || {};
const CGS   = S.cgs || {};
const VIDS  = S.videos || {};
const AUD   = S.audio || {};
const steps = S.script;
const NS    = META.id || 'vn';

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const pad = (n, l = 3) => String(n).padStart(l, '0');

/* label → 下标 */
const labels = {};
steps.forEach((s, i) => { if (s && s.label) labels[s.label] = i; });

/* ---------- 本地存储 ---------- */
const store = {
  get(k) { try { return localStorage.getItem(NS + '.' + k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem(NS + '.' + k, v); } catch (e) { /* 隐私模式等 */ } }
};
const parseJSON = (s, d) => { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } };

/* ---------- 设置 ---------- */
const SPEEDS = [140, 100, 75, 55, 40, 30, 22, 15, 8, 0];   // 速度 1~10 对应每字毫秒数，0 = 瞬间
const DEFAULTS = { speed: 6, autoWait: 1.8, fontSize: 22, opacity: 0.82, bgm: 0.7, sfx: 0.8 };
const settings = Object.assign({}, DEFAULTS, parseJSON(store.get('settings'), {}));

/* ---------- 运行时状态 ---------- */
const game = $('#game');
const charLayer = $('#char-layer');
const els = {
  textbox: $('#textbox'), name: $('#name'), nameTitle: $('#name-title'),
  text: $('#text'), next: $('#next'), lineNo: $('#line-no')
};

const newState = () => ({ idx: 0, bg: null, chars: {}, cg: null, bgm: null, flags: {}, chapter: null });
let state = newState();
let history = [];

let started = false;     // 是否已进入游戏（离开标题页）
let running = false;     // 引擎正在执行指令（过渡 / 视频等），此时忽略点击
let typing = false;      // 打字机进行中
let waitingClick = false;// 文本已显示完，等待玩家点击
let fullText = '';
let autoMode = false, skipMode = false, ctrlSkip = false;
let typeTimer = null, autoTimer = null;
let token = 0;           // 每次重新开始执行 / 读档 / 回标题就 +1，用来作废旧的异步流程
let videoAbort = null;

const isSkipping = () => skipMode || ctrlSkip;
const panelOpen = () => !!$('.panel.show');
const choicesOpen = () => $('#choices').classList.contains('show');

/* 可被作废的 sleep：返回 false 表示流程已被打断 */
async function sleep(ms, t) {
  await new Promise(r => setTimeout(r, isSkipping() ? Math.min(ms, 60) : ms));
  return t === token;
}

/* ---------- 画面缩放 ---------- */
function fit() {
  const s = Math.min(window.innerWidth / 1280, window.innerHeight / 720);
  game.style.transform = `translate(-50%,-50%) scale(${s})`;
}
window.addEventListener('resize', fit);
fit();

/* =====================================================
   音频
   ===================================================== */
const bgmEl = new Audio();
bgmEl.loop = true;
let bgmId = null, bgmFade = null, ducked = false;
const bgmTarget = () => clamp(settings.bgm * (ducked ? 0.2 : 1), 0, 1);

function safePlay(a) {
  try { const p = a.play(); if (p && p.catch) p.catch(() => {}); return p; } catch (e) { return null; }
}
function playBgm(id) {
  id = id || null;
  state.bgm = id;
  if (id === bgmId) return;
  bgmId = id;
  clearInterval(bgmFade);
  let v = bgmEl.volume;
  bgmFade = setInterval(() => {
    v -= 0.1;
    if (v > 0) { bgmEl.volume = Math.max(0, v); return; }
    clearInterval(bgmFade);
    bgmEl.pause();
    const src = bgmId && AUD.bgm && AUD.bgm[bgmId];
    if (!src) return;
    bgmEl.src = src;
    bgmEl.volume = 0;
    safePlay(bgmEl);
    bgmFade = setInterval(() => {
      const t = bgmTarget();
      bgmEl.volume = Math.min(t, bgmEl.volume + 0.05);
      if (bgmEl.volume >= t) clearInterval(bgmFade);
    }, 40);
  }, 40);
}
function playSfx(id) {
  const src = AUD.sfx && AUD.sfx[id];
  if (!src) return;
  const a = new Audio(src);
  a.volume = clamp(settings.sfx, 0, 1);
  safePlay(a);
}

/* =====================================================
   图片工具 / 占位图
   ===================================================== */
const xmlEsc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]));
const probeCache = {};
function probe(src) {
  if (!probeCache[src]) {
    probeCache[src] = new Promise(res => {
      const i = new Image();
      i.onload = () => res(true);
      i.onerror = () => res(false);
      i.src = src;
    });
  }
  return probeCache[src];
}

/* 立绘占位图：素材缺失时显示，表情不同嘴型/眉形也会变化，方便调试差分逻辑 */
function placeholderSprite(def, expr) {
  const c = def.color || '#62d3e6';
  const e = String(expr).toLowerCase();
  let mouth = 'M138 262 L182 262';
  let brow = 'M120 190 L148 190 M172 190 L200 190';
  if (/smile|happy|smirk|laugh/.test(e)) mouth = 'M136 254 Q160 280 184 254';
  else if (/surpris|shock/.test(e)) mouth = 'M150 256 Q160 286 170 256 Q160 248 150 256';
  else if (/angry|serious|mad/.test(e)) brow = 'M116 184 L148 197 M172 197 L204 184';
  const svg =
`<svg xmlns="http://www.w3.org/2000/svg" width="320" height="660" viewBox="0 0 320 660">
<defs><pattern id="h" width="9" height="9" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
<line x1="0" y1="0" x2="0" y2="9" stroke="${c}" stroke-opacity=".2" stroke-width="3"/></pattern></defs>
<path d="M16 660 L16 470 Q16 384 118 352 L202 352 Q304 384 304 470 L304 660 Z" fill="url(#h)" stroke="${c}" stroke-width="2"/>
<rect x="138" y="292" width="44" height="64" fill="url(#h)" stroke="${c}" stroke-width="2"/>
<ellipse cx="160" cy="210" rx="78" ry="96" fill="#0b1219" fill-opacity=".6" stroke="${c}" stroke-width="2"/>
<ellipse cx="160" cy="210" rx="78" ry="96" fill="url(#h)"/>
<path d="${brow}" stroke="${c}" stroke-width="3" fill="none" stroke-linecap="round"/>
<path d="M124 216 L146 216 M174 216 L196 216" stroke="${c}" stroke-width="4" stroke-linecap="round"/>
<path d="${mouth}" stroke="${c}" stroke-width="3" fill="none" stroke-linecap="round"/>
<rect x="46" y="376" width="228" height="76" fill="#070b10" fill-opacity=".82" stroke="${c}" stroke-opacity=".7"/>
<text x="160" y="410" text-anchor="middle" font-family="sans-serif" font-size="26" font-weight="700" fill="${c}">${xmlEsc(def.name || '?')}</text>
<text x="160" y="436" text-anchor="middle" font-family="monospace" font-size="15" letter-spacing="3" fill="#9fb0bc">EXPR: ${xmlEsc(expr)}</text>
</svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}

const bgCss = def => {
  const base = def.color || 'linear-gradient(160deg,#0c131b,#1b2937)';
  return def.src ? `url("${def.src}") center/cover no-repeat, ${base}` : base;
};

/* =====================================================
   背景
   ===================================================== */
const bgEls = $$('#bg-layer .bg');
let bgIdx = 0;
function setBg(id, instant) {
  const def = BGS[id];
  if (!def) console.warn('[VN] 未定义的背景：', id);
  state.bg = id;
  const layer = $('#bg-layer');
  layer.classList.toggle('cut', !!instant);
  const back = bgEls[1 - bgIdx], front = bgEls[bgIdx];
  back.style.background = bgCss(def || {});
  void back.offsetWidth;
  back.classList.add('on');
  front.classList.remove('on');
  bgIdx = 1 - bgIdx;
}
async function changeBg(id, mode, t) {
  const fx = $('#fx-black');
  if (mode === 'cut') { setBg(id, true); return true; }
  if (mode === 'black') {
    fx.classList.add('on');
    if (!(await sleep(520, t))) return false;
    setBg(id, true);
    fx.classList.remove('on');
    return sleep(520, t);
  }
  setBg(id, false);
  return sleep(650, t);
}

/* =====================================================
   立绘
   ===================================================== */
const POS = { 'far-left': 14, left: 27, center: 50, right: 73, 'far-right': 86 };
function posToLeft(p) {
  if (typeof p === 'number') return p + '%';
  if (typeof p === 'string' && p.endsWith('%')) return p;
  return (POS[p] != null ? POS[p] : 50) + '%';
}
const charEl = id => charLayer.querySelector('.sprite[data-id="' + id + '"]:not(.leaving)');

function makeImg(cls) {
  const im = document.createElement('img');
  im.className = cls; im.alt = ''; im.draggable = false;
  return im;
}
function buildSprite(id) {
  const def = CHARS[id];
  const el = document.createElement('div');
  el.className = 'sprite';
  el.dataset.id = id;
  const inner = document.createElement('div');
  inner.className = 'sprite-inner';
  if (def.height) inner.style.setProperty('--h', def.height + 'px');
  if (def.base) {                                   // 差分模式：身体底图
    const body = makeImg('body');
    body.onerror = () => { body.onerror = null; body.src = placeholderSprite(def, 'BASE'); };
    body.src = def.base;
    inner.appendChild(body);
  }
  inner.appendChild(makeImg('f'));                  // 两层表情图，用于交叉淡入淡出
  inner.appendChild(makeImg('f'));
  el.appendChild(inner);
  return el;
}

/* 表情切换接口：整图替换 或 脸部差分叠加 */
function setExpr(el, def, expr, anim) {
  const layers = $$('.f', el);
  const cur = layers.find(l => l.classList.contains('on'));
  const nxt = layers.find(l => l !== cur);
  let src = null, face = null;

  if (def.base) {
    const f = def.faces && (def.faces[expr] || def.faces.normal);
    if (f) { face = f; src = f.src; }
  } else {
    const sp = def.sprites || {};
    src = sp[expr] || sp.normal || Object.values(sp)[0] || null;
    if (!src) src = placeholderSprite(def, expr);
  }

  if (el._src !== src) {
    el._src = src;
    if (!src) {
      if (cur) cur.classList.remove('on');
    } else {
      nxt.classList.toggle('face', !!face);
      nxt.style.left = face ? (face.x || '') : '';
      nxt.style.top = face ? (face.y || '') : '';
      nxt.style.width = face ? (face.w || '') : '';
      nxt.onload = () => { nxt.onload = null; nxt.classList.add('on'); if (cur) cur.classList.remove('on'); };
      nxt.onerror = () => {
        nxt.onerror = null;
        if (face) { nxt.onload = null; if (cur) cur.classList.remove('on'); }   // 缺脸部图：隐藏即可
        else nxt.src = placeholderSprite(def, expr);                            // 缺整图：占位图
      };
      nxt.src = src;
    }
  }
  if (anim) {
    ['nod', 'jump', 'shake'].forEach(a => el.classList.remove('anim-' + a));
    void el.offsetWidth;
    el.classList.add('anim-' + anim);
    setTimeout(() => el.classList.remove('anim-' + anim), 600);
  }
}

function showChar(spec, instant) {
  const id = spec.id, def = CHARS[id];
  if (!def) { console.warn('[VN] 未定义的角色：', id); return; }
  const rec = state.chars[id];
  const pos = spec.pos != null ? spec.pos : (rec && rec.pos) || 'center';
  const expr = spec.expr || (rec && rec.expr) || 'normal';
  let el = charEl(id);
  if (!el) {
    el = buildSprite(id);
    if (instant) el.classList.add('no-trans');
    el.style.left = posToLeft(pos);
    charLayer.appendChild(el);
    void el.offsetWidth;
    setExpr(el, def, expr);
    el.classList.add('in');
    if (instant) requestAnimationFrame(() => requestAnimationFrame(() => el.classList.remove('no-trans')));
  } else {
    el.style.left = posToLeft(pos);
    if (spec.expr || spec.anim) setExpr(el, def, expr, spec.anim);
  }
  state.chars[id] = { pos, expr };
}
function changeExpr(spec) {
  const rec = state.chars[spec.id], el = charEl(spec.id);
  if (!rec || !el) { console.warn('[VN] 角色不在场，无法切换表情：', spec.id); return; }
  if (spec.expr) rec.expr = spec.expr;
  setExpr(el, CHARS[spec.id], rec.expr, spec.anim);
}
function hideChar(id, instant) {
  if (id === 'all') { Object.keys(state.chars).forEach(k => hideChar(k, instant)); return; }
  const el = charEl(id);
  delete state.chars[id];
  if (!el) return;
  el.classList.add('leaving');
  el.classList.remove('in');
  setTimeout(() => el.remove(), instant ? 0 : 420);
}
/* 说话者高亮：有 who → 其他人变暗；有名字但无立绘（如主角）→ 全部变暗；旁白 → 全部正常 */
function setSpeaker(who, hasName) {
  $$('.sprite', charLayer).forEach(el => {
    const me = !!who && el.dataset.id === who;
    el.classList.toggle('dim', (!!who && !me) || (!who && hasName));
    el.classList.toggle('speaking', me);
  });
}

/* =====================================================
   CG / 视频 / 章节 / 特效
   ===================================================== */
function showCg(spec, instant) {
  const id = typeof spec === 'string' ? spec : spec.id;
  const def = CGS[id] || {};
  if (!CGS[id]) console.warn('[VN] 未定义的 CG：', id);
  state.cg = id;
  const layer = $('#cg-layer');
  layer.innerHTML = '';
  const img = document.createElement('div');
  img.className = 'cg-img';
  img.style.background = bgCss(def);
  layer.appendChild(img);
  const tag = () => {
    if (state.cg !== id) return;
    const t = document.createElement('div');
    t.className = 'cg-tag';
    t.textContent = 'CG · ' + id + ' · 素材未找到';
    layer.appendChild(t);
  };
  if (def.src) probe(def.src).then(ok => { if (!ok) tag(); }); else tag();
  layer.classList.toggle('kb', def.kenburns !== false);
  game.classList.toggle('cg-clean', !!def.hideUI);
  if (instant) layer.style.transition = 'none';
  void layer.offsetWidth;
  layer.classList.add('show');
  if (instant) requestAnimationFrame(() => { layer.style.transition = ''; });
}
function hideCg(instant) {
  const layer = $('#cg-layer');
  state.cg = null;
  game.classList.remove('cg-clean');
  if (instant) { layer.style.transition = 'none'; layer.classList.remove('show'); layer.innerHTML = ''; void layer.offsetWidth; layer.style.transition = ''; return; }
  layer.classList.remove('show');
  setTimeout(() => { if (!state.cg) layer.innerHTML = ''; }, 700);
}

function playVideo(spec, t) {
  const def = typeof spec === 'string' ? (VIDS[spec] || { src: spec }) : spec;
  return new Promise(resolve => {
    if (isSkipping()) { resolve(true); return; }
    const layer = $('#video-layer'), v = $('#video'), msg = $('#video-msg'), skipBtn = $('#video-skip');
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      v.onended = v.onerror = null;
      try { v.pause(); } catch (e) {}
      v.removeAttribute('src');
      try { v.load(); } catch (e) {}
      layer.classList.remove('show');
      msg.classList.remove('show');
      layer.onclick = null; skipBtn.onclick = null;
      ducked = false; bgmEl.volume = bgmTarget();
      videoAbort = null;
      resolve(true);
    };
    videoAbort = finish;
    layer.classList.add('show');
    msg.classList.remove('show');
    skipBtn.style.display = def.skippable === false ? 'none' : '';
    ducked = def.duckBgm !== false;
    bgmEl.volume = bgmTarget();
    v.muted = !!def.muted;
    v.style.objectFit = def.fit || 'contain';
    v.onended = finish;
    v.onerror = () => {
      if (done) return;
      msg.textContent = 'VIDEO NOT FOUND // ' + (def.src || '(未设置 src)');
      msg.classList.add('show');
      setTimeout(finish, 1800);
    };
    if (def.skippable !== false) { layer.onclick = finish; skipBtn.onclick = e => { e.stopPropagation(); finish(); }; }
    if (!def.src) { v.onerror(); return; }
    v.src = def.src;
    const p = safePlay(v);
    if (p && p.catch) p.catch(() => { v.muted = true; safePlay(v); });   // 浏览器拒绝带声音自动播放时，改静音播放
  });
}

async function showChapter(c, t) {
  state.chapter = c;
  $('#hud-chapter').textContent = [c.no, c.title].filter(Boolean).join(' // ');
  $('#cc-no').textContent = c.no || '';
  $('#cc-title').textContent = c.title || '';
  $('#cc-sub').textContent = c.sub || '';
  const card = $('#chapter-card');
  card.classList.remove('show');
  void card.offsetWidth;
  card.classList.add('show');
  const ok = await sleep(2600, t);
  card.classList.remove('show');
  return ok;
}

async function doEffect(name, t) {
  const stage = $('#stage'), white = $('#fx-white'), black = $('#fx-black');
  switch (name) {
    case 'shake': stage.classList.remove('shake'); void stage.offsetWidth; stage.classList.add('shake'); break;
    case 'flash': white.classList.remove('flash'); void white.offsetWidth; white.classList.add('flash'); break;
    case 'fadeOut': black.classList.add('on'); return sleep(550, t);
    case 'fadeIn': black.classList.remove('on'); return sleep(550, t);
    default: console.warn('[VN] 未知特效：', name);
  }
  return true;
}

/* =====================================================
   文本：打字机 / 历史
   ===================================================== */
function startTyping(text, instant) {
  clearTimeout(typeTimer);
  clearTimeout(autoTimer);
  fullText = String(text);
  const chars = Array.from(fullText);
  let i = 0;
  typing = true; waitingClick = false;
  els.next.classList.remove('show');
  els.textbox.classList.add('typing');
  els.text.textContent = '';
  const delay = SPEEDS[clamp(settings.speed, 1, 10) - 1];
  if (instant || delay === 0 || isSkipping()) { finishTyping(); return; }
  const tick = () => {
    i++;
    els.text.textContent = chars.slice(0, i).join('');
    if (i >= chars.length) { finishTyping(); return; }
    const extra = /[，。！？、；：…—,.!?;:]/.test(chars[i - 1]) ? delay * 4 : 0;   // 标点处稍作停顿
    typeTimer = setTimeout(tick, delay + extra);
  };
  typeTimer = setTimeout(tick, delay);
}
function finishTyping() {
  clearTimeout(typeTimer);
  els.text.textContent = fullText;
  typing = false; waitingClick = true;
  els.textbox.classList.remove('typing');
  els.next.classList.add('show');
  if (autoMode && !skipMode) scheduleAuto();
}
function scheduleAuto() {
  clearTimeout(autoTimer);
  const t = token;
  autoTimer = setTimeout(() => {
    if (t === token && autoMode && waitingClick && !panelOpen()) advance();
    else if (t === token && autoMode && waitingClick) scheduleAuto();
  }, settings.autoWait * 1000 + fullText.length * 35);
}

function showText(step, restore) {
  const def = step.who && CHARS[step.who];
  if (step.who && !def) console.warn('[VN] who 指向未定义角色：', step.who);
  const name = step.speaker != null ? step.speaker : (def ? def.name : '');
  const color = def ? def.color : null;
  setSpeaker(step.who, !!name);
  els.name.textContent = name;
  els.nameTitle.textContent = (step.speaker == null && def && def.title) || '';
  if (name) els.textbox.style.setProperty('--nc', color || 'var(--accent)');
  else els.textbox.style.removeProperty('--nc');          // 旁白用 CSS 里的灰色
  els.textbox.classList.toggle('narration', !name);
  els.lineNo.textContent = `ENTRY ${pad(state.idx + 1)} / ${pad(steps.length)}`;
  if (!restore) {
    history.push({ name, text: String(step.text), color });
    if (history.length > 300) history.shift();
  }
  startTyping(step.text, restore);
}

/* =====================================================
   选项 / 结束
   ===================================================== */
const cond = c => typeof c === 'string'
  ? (c[0] === '!' ? !state.flags[c.slice(1)] : !!state.flags[c])
  : Object.keys(c).every(k => state.flags[k] === c[k]);

function showChoices(step, restore) {
  setAuto(false); setSkip(false);
  if (step.text != null) {                 // 选项同时带一句提问文本：直接显示完整文字
    showText(step, restore);
    finishTyping();
    waitingClick = false;
    els.next.classList.remove('show');
    clearTimeout(autoTimer);
  }
  const box = $('#choice-list');
  box.innerHTML = '';
  step.choices.forEach((c, i) => {
    if (c.if && !cond(c.if)) return;
    const b = document.createElement('button');
    b.className = 'choice';
    b.dataset.n = pad(box.children.length + 1, 2);
    b.textContent = c.text;
    b.onclick = e => { e.stopPropagation(); pick(c); };
    box.appendChild(b);
  });
  $('#choices').classList.add('show');
}
function pick(c) {
  $('#choices').classList.remove('show');
  history.push({ name: '▸ 选择', text: c.text, color: 'var(--accent)' });
  if (c.set) Object.assign(state.flags, c.set);
  gotoLabel(c.jump);
  run();
}
function gotoLabel(l) {
  if (l == null) { state.idx++; return; }
  if (!(l in labels)) { console.warn('[VN] 找不到 label：', l); state.idx++; return; }
  state.idx = labels[l];
}
function showEnd(spec) {
  running = false; waitingClick = false;
  setAuto(false); setSkip(false);
  const o = (spec && typeof spec === 'object') ? spec : {};
  $('#end-title').textContent = o.title || 'TO BE CONTINUED';
  $('#end-sub').textContent = o.sub || '';
  $('#end-screen').classList.add('show');
}

/* =====================================================
   核心：指令执行
   ===================================================== */
async function exec(step, t) {
  if (step.if && !cond(step.if)) return 'next';
  if (step.set) Object.assign(state.flags, step.set);

  if (step.chapter && !(await showChapter(step.chapter, t))) return 'abort';
  if (step.bgm !== undefined) playBgm(step.bgm);
  if (step.hide) [].concat(step.hide).forEach(id => hideChar(id));
  if (step.bg && !(await changeBg(step.bg, step.transition || 'fade', t))) return 'abort';
  if (step.show) [].concat(step.show).forEach(s => showChar(s));
  if (step.expr) [].concat(step.expr).forEach(changeExpr);
  if (step.cg) showCg(step.cg);
  if (step.cgHide) hideCg();
  if (step.sfx) playSfx(step.sfx);
  if (step.effect) {
    for (const e of [].concat(step.effect)) if (!(await doEffect(e, t))) return 'abort';
  }
  if (step.video) { await playVideo(step.video, t); if (t !== token) return 'abort'; }
  if (step.wait && !(await sleep(step.wait, t))) return 'abort';

  if (step.jump) { gotoLabel(step.jump); return 'jump'; }
  if (step.end) { showEnd(step.end); return 'end'; }
  if (step.choices) { showChoices(step); return 'choice'; }
  if (step.text != null) { showText(step); return 'text'; }
  return 'next';
}

async function run() {
  const t = ++token;
  running = true;
  while (t === token) {
    const step = steps[state.idx];
    if (!step) { showEnd(); return; }
    const r = await exec(step, t);
    if (t !== token) return;               // 被读档 / 回标题打断
    if (r === 'text' || r === 'choice' || r === 'end') { running = false; return; }
    if (r === 'jump') continue;
    state.idx++;
  }
}

/* 推进：打字中 → 先补全；等待点击 → 下一步 */
function advance() {
  if (!started || running || panelOpen() || choicesOpen()) return;
  if (typing) { finishTyping(); return; }
  if (waitingClick) {
    waitingClick = false;
    clearTimeout(autoTimer);
    state.idx++;
    run();
  }
}

/* 快进驱动 */
setInterval(() => {
  if (!started || !isSkipping() || panelOpen() || choicesOpen()) return;
  if (typing) finishTyping();
  else if (waitingClick) advance();
}, 70);

/* =====================================================
   自动 / 快进 / 隐藏 UI
   ===================================================== */
const btn = n => $('[data-btn="' + n + '"]');
function setAuto(v) {
  autoMode = v;
  if (v && skipMode) { skipMode = false; btn('skip').classList.remove('active'); }
  btn('auto').classList.toggle('active', v);
  clearTimeout(autoTimer);
  if (v && waitingClick) scheduleAuto();
}
function setSkip(v) {
  skipMode = v;
  if (v && autoMode) { autoMode = false; btn('auto').classList.remove('active'); clearTimeout(autoTimer); }
  btn('skip').classList.toggle('active', v);
}
function toggleUI(v) {
  const hidden = v === undefined ? !game.classList.contains('ui-hidden') : v;
  game.classList.toggle('ui-hidden', hidden);
}

let toastTimer = null;
function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 1400);
}

/* =====================================================
   面板：历史 / 设置 / 存读档
   ===================================================== */
function openPanel(id) {
  $$('.panel').forEach(p => p.classList.remove('show'));
  $('#' + id).classList.add('show');
  setSkip(false);
}
function closePanels() {
  $$('.panel').forEach(p => p.classList.remove('show'));
  if (autoMode && waitingClick) scheduleAuto();
}

function openHistory() {
  const list = $('#history-list');
  list.innerHTML = '';
  if (!history.length) {
    const e = document.createElement('div');
    e.className = 'h-empty'; e.textContent = '— NO RECORDS —';
    list.appendChild(e);
  }
  history.forEach(h => {
    const row = document.createElement('div');
    row.className = 'h-row';
    if (h.name) {
      const n = document.createElement('span');
      n.className = 'h-name'; n.textContent = h.name;
      if (h.color) n.style.color = h.color;
      row.appendChild(n);
    }
    const t = document.createElement('div');
    t.className = 'h-text'; t.textContent = h.text;
    row.appendChild(t);
    list.appendChild(row);
  });
  openPanel('p-history');
  list.scrollTop = list.scrollHeight;
}

/* 设置 */
const SETTING_FMT = {
  speed: v => (v >= 10 ? '瞬间' : 'LV ' + v),
  autoWait: v => (+v).toFixed(1) + ' s',
  fontSize: v => v + ' px',
  opacity: v => Math.round(v * 100) + '%',
  bgm: v => Math.round(v * 100) + '%',
  sfx: v => Math.round(v * 100) + '%'
};
function applySettings() {
  game.style.setProperty('--tb', settings.opacity);
  game.style.setProperty('--fs', settings.fontSize + 'px');
  if (!ducked) bgmEl.volume = bgmTarget();
  $$('[data-key]').forEach(inp => {
    const k = inp.dataset.key;
    inp.value = settings[k];
    const out = $('[data-for="' + k + '"]');
    if (out) out.textContent = SETTING_FMT[k](settings[k]);
  });
}
$$('[data-key]').forEach(inp => {
  inp.addEventListener('input', () => {
    settings[inp.dataset.key] = parseFloat(inp.value);
    store.set('settings', JSON.stringify(settings));
    applySettings();
  });
});

/* 存读档 */
function canSave() { return started && !running && (waitingClick || typing || choicesOpen()); }
function saveSlot(n) {
  if (!canSave()) { toast('当前时机无法存档'); return false; }
  const step = steps[state.idx] || {};
  const data = {
    time: Date.now(),
    snippet: step.text != null ? String(step.text).replace(/\n/g, ' ').slice(0, 44) : '（选项）',
    state: JSON.parse(JSON.stringify(state)),
    history: history.slice(-80)
  };
  store.set('save.' + n, JSON.stringify(data));
  toast('已存入 SLOT ' + pad(n, 2));
  return true;
}
function renderSaves(mode) {
  $('#saves-title').textContent = mode === 'save' ? 'SAVE // 存档' : 'LOAD // 读档';
  const grid = $('#save-grid');
  grid.innerHTML = '';
  for (let n = 1; n <= 6; n++) {
    const d = parseJSON(store.get('save.' + n), null);
    const b = document.createElement('button');
    b.className = 'slot' + (d ? '' : ' empty');
    b.innerHTML = '<em></em><b></b><span></span>';
    b.children[0].textContent = 'SLOT ' + pad(n, 2);
    b.children[1].textContent = d ? d.snippet : '— EMPTY —';
    b.children[2].textContent = d ? new Date(d.time).toLocaleString('zh-CN', { hour12: false }) : '';
    b.onclick = () => {
      if (mode === 'save') { if (saveSlot(n)) renderSaves('save'); }
      else if (d) { closePanels(); loadSave(d); }
    };
    grid.appendChild(b);
  }
}
function openSaves(mode) {
  if (mode === 'save' && !canSave()) { toast('当前时机无法存档'); return; }
  renderSaves(mode);
  openPanel('p-saves');
}

/* =====================================================
   场景重置 / 新游戏 / 读档 / 回标题
   ===================================================== */
function clearScene() {
  token++;
  running = false; typing = false; waitingClick = false;
  clearTimeout(typeTimer); clearTimeout(autoTimer);
  if (videoAbort) videoAbort();
  setAuto(false); setSkip(false);
  $$('.sprite', charLayer).forEach(e => e.remove());
  hideCg(true);
  $('#fx-black').classList.remove('on');
  $('#chapter-card').classList.remove('show');
  $('#choices').classList.remove('show');
  $('#end-screen').classList.remove('show');
  bgEls.forEach(b => b.classList.remove('on'));
  game.classList.remove('ui-hidden', 'cg-clean');
  els.text.textContent = ''; els.name.textContent = ''; els.nameTitle.textContent = '';
  els.next.classList.remove('show');
  els.textbox.classList.remove('typing');
  els.textbox.classList.add('narration');
  $('#hud-chapter').textContent = 'ARCHIVE // STANDBY';
  playBgm(null);
}
function enterGame() {
  started = true;
  $('#title-screen').classList.add('hide');
  closePanels();
}
function newGame() {
  clearScene();
  state = newState();
  history = [];
  if (META.start && labels[META.start] != null) state.idx = labels[META.start];
  enterGame();
  run();
}
function loadSave(d) {
  clearScene();
  state = Object.assign(newState(), d.state);
  history = d.history || [];
  enterGame();
  if (state.bg) setBg(state.bg, true);
  Object.keys(state.chars).forEach(id => {
    const r = state.chars[id];
    showChar({ id, pos: r.pos, expr: r.expr }, true);
  });
  if (state.cg) showCg(state.cg, true);
  if (state.chapter) $('#hud-chapter').textContent = [state.chapter.no, state.chapter.title].filter(Boolean).join(' // ');
  playBgm(state.bgm);
  const step = steps[state.idx];
  if (!step) { showEnd(); return; }
  if (step.choices) showChoices(step, true);
  else if (step.text != null) showText(step, true);
  else run();
  toast('读档完成');
}
function toTitle() {
  clearScene();
  started = false;
  state = newState();
  $('#title-screen').classList.remove('hide');
}

/* =====================================================
   事件绑定
   ===================================================== */
function act(a) {
  switch (a) {
    case 'log':    openHistory(); break;
    case 'auto':   setAuto(!autoMode); break;
    case 'skip':   setSkip(!skipMode); break;
    case 'save':   openSaves('save'); break;
    case 'load':   openSaves('load'); break;
    case 'hide':   toggleUI(true); break;
    case 'config': openPanel('p-config'); break;
    case 'close':  closePanels(); break;
    case 'reset':  Object.assign(settings, DEFAULTS); store.set('settings', JSON.stringify(settings)); applySettings(); break;
    case 'new':    newGame(); break;
    case 'loadFromTitle': openSaves('load'); break;
    case 'title':  toTitle(); break;
  }
}
$$('[data-act]').forEach(b => b.addEventListener('click', e => {
  e.stopPropagation();
  act(b.dataset.act);
  b.blur();
}));

/* 点击舞台推进 */
game.addEventListener('click', e => {
  if (!started) return;
  if (e.target.closest('button, .panel, #choices, #video-layer, #title-screen, #end-screen, input')) return;
  if (game.classList.contains('ui-hidden')) { toggleUI(false); return; }
  if (autoMode) setAuto(false);
  if (skipMode) setSkip(false);
  advance();
});
game.addEventListener('contextmenu', e => {
  e.preventDefault();
  if (!started) return;
  if (panelOpen()) closePanels(); else toggleUI();
});
game.addEventListener('wheel', e => {
  if (started && e.deltaY < 0 && !panelOpen() && !choicesOpen()) openHistory();
}, { passive: true });

window.addEventListener('keydown', e => {
  if (e.target && e.target.matches && e.target.matches('input')) { if (e.key === 'Escape') closePanels(); return; }
  switch (e.key) {
    case ' ': case 'Enter':
      e.preventDefault();
      if (e.repeat || !started) break;
      if (game.classList.contains('ui-hidden')) { toggleUI(false); break; }
      if (autoMode) setAuto(false);
      if (skipMode) setSkip(false);
      advance();
      break;
    case 'Control': ctrlSkip = true; break;
    case 'a': case 'A': if (started) setAuto(!autoMode); break;
    case 's': case 'S': if (started) setSkip(!skipMode); break;
    case 'h': case 'H': if (started) { panelOpen() ? closePanels() : openHistory(); } break;
    case 'v': case 'V': if (started) toggleUI(); break;
    case 'Escape': if (panelOpen()) closePanels(); else if (game.classList.contains('ui-hidden')) toggleUI(false); break;
    default:
      if (/^[1-9]$/.test(e.key) && choicesOpen()) {
        const b = $$('.choice')[+e.key - 1];
        if (b) b.click();
      }
  }
});
window.addEventListener('keyup', e => { if (e.key === 'Control') ctrlSkip = false; });
window.addEventListener('blur', () => { ctrlSkip = false; });

/* =====================================================
   初始化
   ===================================================== */
if (META.title) { $('#ts-title').textContent = META.title; document.title = META.title; }
if (META.subtitle) $('#ts-sub').textContent = META.subtitle;
if (META.tag) $('#ts-tag').textContent = META.tag;
if (META.version) $('#ts-ver').textContent = META.version;
applySettings();

/* 调试入口：在浏览器控制台里可以用 VN.state() / VN.jump('label') */
window.VN = {
  state: () => state,
  jump: l => {
    clearScene();
    if (!started) { state = newState(); history = []; }
    enterGame();
    gotoLabel(l);
    run();
  }
};
})();
