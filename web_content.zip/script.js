const API_KEY = "nc7NEgqqiUzKRQrpxT9EPPbKk30t1ckNW7L0xwtqhsGJy2679Bm6rS6D";
const HIGH_RES_LIMIT = 4000; 

const gallery = document.getElementById("gallery");
let unlockedPhotos = JSON.parse(localStorage.getItem("unlocked_photos")) || [];
let selectedPlanId = 'weekly_access';

// --- 1. دالة البدء الرئيسية وإخفاء الشاشة الافتتاحية ---
document.addEventListener("DOMContentLoaded", () => {
    // جلب الخلفيات لشبكة التطبيق الرئيسية
    fetchWallpapers();

    // إخفاء الشاشة الافتتاحية بعد 3 ثوانٍ
    setTimeout(() => {
        const splash = document.getElementById("splashScreen");
        if (splash) {
            splash.style.opacity = "0";
            splash.style.visibility = "hidden";
        }
    }, 3000);
});

// --- 2. دالة جلب الصور من API Pexels ---
async function fetchWallpapers(query = "") {
    if (!gallery) return;
    
    gallery.innerHTML = "<p style='grid-column: 1 / -1; padding: 20px; color: #38bdf8; text-align: center;'>جاري تحميل الخلفيات...</p>";
    
    let url = "https://api.pexels.com/v1/curated?per_page=30";
    if (query && query !== 'all') {
        url = `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}&per_page=30`;
    }

    try {
        const response = await fetch(url, {
            headers: { Authorization: API_KEY }
        });
        
        if (!response.ok) throw new Error("API Error");
        
        const data = await response.json();
        displayImages(data.photos);
    } catch (error) {
        gallery.innerHTML = "<p style='grid-column: 1 / -1; color: #ef4444; text-align: center; padding: 20px;'>تأكد من الاتصال بالإنترنت ومفتاح API.</p>";
    }
}

// --- 3. دالة عرض شبكة الكروت ---
function displayImages(photos) {
    if (!gallery) return;
    gallery.innerHTML = "";

    if (!photos || photos.length === 0) {
        gallery.innerHTML = "<p style='grid-column: 1 / -1; text-align: center;'>لم يتم العثور على خلفيات.</p>";
        return;
    }

    photos.forEach((photo) => {
        const card = document.createElement("div");
        card.className = "card";

        const isHighResolution = (photo.width >= HIGH_RES_LIMIT || photo.height >= HIGH_RES_LIMIT);
        const isUnlocked = unlockedPhotos.includes(photo.id);
        const isPaid = isHighResolution && !isUnlocked;

        const img = document.createElement("img");
        img.src = photo.src.portrait;
        img.alt = photo.alt || "Wallpaper";

        if (isPaid) {
            img.style.filter = "blur(3px)";
        }

        img.onclick = () => openPreview(photo, isPaid);

        const actionBtn = document.createElement("button");

        if (isPaid) {
            card.innerHTML += `<span class="premium-badge">Ultra HD $1 👑</span>`;
            actionBtn.className = "download-btn buy-btn";
            actionBtn.innerHTML = `شراء (${photo.width}x${photo.height}) 👑`;
            actionBtn.onclick = (e) => {
                e.stopPropagation();
                openPreview(photo, true);
            };
        } else {
            actionBtn.className = "download-btn";
            actionBtn.innerHTML = isUnlocked ? "⬇ تنزيل Ultra HD" : "⬇ تنزيل مجاني";
            actionBtn.onclick = (e) => {
                e.stopPropagation();
                downloadProtectedImage(photo.id);
            };
        }

        card.appendChild(img);
        card.appendChild(actionBtn);
        gallery.appendChild(card);
    });
}

// --- 4. دالة المعاينة والاشتراكات ---
function openPreview(photo, isPaid) {
    const previewModal = document.getElementById("previewModal");
    const modalImg = document.getElementById("modalImage");
    const setBgBtn = document.getElementById("setBgBtn");
    const watermarkText = document.getElementById("watermarkText");
    const subscriptionContainer = document.getElementById("subscriptionContainer");

    if (!previewModal || !modalImg) return;

    modalImg.src = photo.src.portrait;
    previewModal.style.display = "flex";

    if (isPaid) {
        modalImg.style.filter = "blur(5px)";
        if (watermarkText) watermarkText.style.display = "block";
        if (setBgBtn) setBgBtn.style.display = "none";
        if (subscriptionContainer) subscriptionContainer.style.display = "block";
        window.currentPhotoToUnlock = photo.id;
    } else {
        modalImg.style.filter = "none";
        if (watermarkText) watermarkText.style.display = "none";
        if (subscriptionContainer) subscriptionContainer.style.display = "none";
        if (setBgBtn) {
            setBgBtn.style.display = "inline-block";
            setBgBtn.onclick = () => {
                setAsBackground(photo.src.portrait);
                closePreview();
            };
        }
    }
}

function closePreview() {
    const previewModal = document.getElementById("previewModal");
    if (previewModal) previewModal.style.display = "none";
}

function selectPlan(element, planId) {
    document.querySelectorAll('.plan-card').forEach(card => card.classList.remove('active'));
    element.classList.add('active');
    selectedPlanId = planId;
}

// --- 5. دالة تنفيذ الشراء بنظام Google Play Billing ---
function subscribeGooglePlay() {
    if (window.CdvPurchase && window.CdvPurchase.store) {
        const store = window.CdvPurchase.store;
        const product = store.get(selectedPlanId);
        if (product) {
            store.order(product).then(() => unlockImage(window.currentPhotoToUnlock));
        }
    } else {
        if (confirm(`طلب شراء عبر Google Play لخطة (${selectedPlanId}). تأكيد التفعيل؟`)) {
            unlockImage(window.currentPhotoToUnlock);
        }
    }
}

function unlockImage(photoId) {
    if (photoId && !unlockedPhotos.includes(photoId)) {
        unlockedPhotos.push(photoId);
        localStorage.setItem("unlocked_photos", JSON.stringify(unlockedPhotos));
    }
    closePreview();
    if (photoId) downloadProtectedImage(photoId);
    fetchWallpapers();
}

// --- 6. دالات التنزيل وتعيين الخلفية والبحث ---
async function downloadProtectedImage(photoId) {
    try {
        const res = await fetch(`https://api.pexels.com/v1/photos/${photoId}`, {
            headers: { Authorization: API_KEY }
        });
        const photoData = await res.json();
        const a = document.createElement("a");
        a.href = photoData.src.original;
        a.target = "_blank";
        a.download = `wallpaper-${photoId}.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    } catch (err) {
        alert("حدث خطأ أثناء التنزيل.");
    }
}

function setAsBackground(imageUrl) {
    document.body.style.backgroundImage = `url('${imageUrl}')`;
    alert("تم تعيين الصورة كخلفية بنجاح!");
}

function handleSearch() {
    const input = document.getElementById("searchInput");
    if (input && input.value.trim() !== "") fetchWallpapers(input.value.trim());
}

function filterCategory(category) {
    fetchWallpapers(category);
}
