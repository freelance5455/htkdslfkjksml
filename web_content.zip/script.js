/* =====================================================
   CODEX QUICK CALCULATOR V11.1
   FIXED BOOT ANIMATION
   ===================================================== */

let expressionValue = "";
let answerValue = "";
let memory = Number(localStorage.getItem("quickMemory") || 0);
let lastAnswer = Number(localStorage.getItem("quickAnswer") || 0);
let angleMode = localStorage.getItem("quickAngle") || "DEG";
let appMode = localStorage.getItem("quickMode") || "BASIC";
let historyData = JSON.parse(localStorage.getItem("quickHistory") || "[]");

const expressionEl = document.getElementById("expression");
const resultEl = document.getElementById("result");
const memoryIndicator = document.getElementById("memoryIndicator");
const ansIndicator = document.getElementById("ansIndicator");
const angleIndicator = document.getElementById("angleIndicator");

const scientificPanel = document.getElementById("scientificPanel");
const basicTab = document.getElementById("basicTab");
const scientificTab = document.getElementById("scientificTab");
const displayMode = document.getElementById("displayMode");

const splashScreen = document.getElementById("splashScreen");
const loadingBar = document.getElementById("loadingBar");
const loadingPercent = document.getElementById("loadingPercent");

const exitOverlay = document.getElementById("exitOverlay");
const toastEl = document.getElementById("toast");


/* ================= RANDOM BRAND COLOR ================= */

function randomBrandColor() {

  const colors = [
    ["#6d7cff", "#9b6dff"],
    ["#00d9ff", "#0077ff"],
    ["#00e676", "#00bfa5"],
    ["#ff4ecd", "#8e5cff"],
    ["#ff7a18", "#ff3158"],
    ["#ffe600", "#ff8a00"],
    ["#00f5a0", "#00c6ff"],
    ["#ff4b2b", "#ff416c"],
    ["#7f5cff", "#c86bff"],
    ["#00c9ff", "#92fe9d"],
    ["#f857a6", "#ff5858"],
    ["#36d1dc", "#5b86e5"]
  ];

  const color =
    colors[Math.floor(Math.random() * colors.length)];

  document.documentElement.style.setProperty(
    "--accent",
    color[0]
  );

  document.documentElement.style.setProperty(
    "--accent2",
    color[1]
  );
}


/* ================= DISPLAY ================= */

function updateDisplay() {

  expressionEl.textContent =
    expressionValue || "0";

  resultEl.textContent =
    answerValue || "";

  memoryIndicator.classList.toggle(
    "hidden",
    memory === 0
  );

  ansIndicator.classList.toggle(
    "hidden",
    lastAnswer === 0
  );

  angleIndicator.textContent = angleMode;
}


/* ================= INPUT ================= */

function addToExpression(value) {

  const operators = ["+", "-", "*", "/"];

  if (value === ".") {

    const parts =
      expressionValue.split(/[+\-*/()]/);

    const current =
      parts[parts.length - 1];

    if (current.includes(".")) return;

    if (
      !current ||
      operators.includes(expressionValue.slice(-1))
    ) {
      expressionValue += "0.";
    } else {
      expressionValue += ".";
    }

    answerValue = "";
    updateDisplay();
    return;
  }

  if (operators.includes(value)) {

    if (!expressionValue) {

      if (value === "-") {
        expressionValue = "-";
      }

      updateDisplay();
      return;
    }

    const last =
      expressionValue.slice(-1);

    if (operators.includes(last)) {

      expressionValue =
        expressionValue.slice(0, -1) + value;

    } else {

      expressionValue += value;
    }

    answerValue = "";
    updateDisplay();
    return;
  }

  expressionValue += value;
  answerValue = "";
  updateDisplay();
}


/* ================= CLEAR ================= */

function clearAll() {

  expressionValue = "";
  answerValue = "";

  updateDisplay();
}


function backspace() {

  expressionValue =
    expressionValue.slice(0, -1);

  answerValue = "";

  updateDisplay();
}


/* ================= SIGN ================= */

function toggleSign() {

  if (!expressionValue) return;

  try {

    const value =
      evaluateExpression(expressionValue);

    expressionValue =
      String(-value);

    updateDisplay();

  } catch {

    showToast("Invalid number");
  }
}


/* ================= PREPARE EXPRESSION ================= */

function prepareExpression(expr) {

  let e = expr;

  e = e.replace(/×/g, "*");
  e = e.replace(/÷/g, "/");
  e = e.replace(/−/g, "-");

  e = e.replace(/ANS/g, `(${lastAnswer})`);

  e = e.replace(/π/g, "Math.PI");

  e = e.replace(
    /(^|[^A-Za-z])e(?![A-Za-z])/g,
    "$1Math.E"
  );

  e = e.replace(/√/g, "Math.sqrt");

  e = e.replace(
    /\|([^|]+)\|/g,
    "Math.abs($1)"
  );

  /* ================= PERCENTAGE ================= */

  // 100 + 10% = 110
  e = e.replace(
    /(\d+(?:\.\d+)?)\s*\+\s*(\d+(?:\.\d+)?)%/g,
    "($1 + ($1 * $2 / 100))"
  );

  // 100 - 10% = 90
  e = e.replace(
    /(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)%/g,
    "($1 - ($1 * $2 / 100))"
  );

  // 200 * 10% = 20
  e = e.replace(
    /(\d+(?:\.\d+)?)\s*\*\s*(\d+(?:\.\d+)?)%/g,
    "($1 * ($2 / 100))"
  );

  // 200 / 10% = 2000
  e = e.replace(
    /(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)%/g,
    "($1 / ($2 / 100))"
  );

  // 50% = 0.5
  e = e.replace(
    /(\d+(?:\.\d+)?)%/g,
    "($1 / 100)"
  );

  /* ================= IMPLICIT MULTIPLICATION ================= */

  e = e.replace(
    /(\d|\)|Math\.PI|Math\.E)\s*(?=\()/g,
    "$1*"
  );

  e = e.replace(
    /\)\s*(?=\d|Math\.PI|Math\.E)/g,
    ")*"
  );

  e = e.replace(
    /(\d|\))\s*(?=Math\.)/g,
    "$1*"
  );

  e = e.replace(
    /(Math\.PI|Math\.E)\s*(?=\d)/g,
    "$1*"
  );

  return e;
}


/* ================= VALIDATION ================= */

function validateExpression(expr) {

  if (!expr) return false;

  if (/[{}[\];'"`<>:&|]/.test(expr)) {
    return false;
  }

  if (
    /(constructor|window|document|globalThis|eval|Function|prototype)/i
      .test(expr)
  ) {
    return false;
  }

  if (
!/^[0-9+\-*/().%\s×÷−π√ANSes]+$/i.test(expr)
  ) {
    return false;
  }

  return true;
}


/* ================= EVALUATE ================= */

function evaluateExpression(expr) {

  if (!validateExpression(expr)) {
    throw new Error("Invalid expression");
  }

  const prepared =
    prepareExpression(expr);

  const value =
    Function(
      `"use strict"; return (${prepared});`
    )();

  if (
    typeof value !== "number" ||
    !Number.isFinite(value)
  ) {
    throw new Error("Math error");
  }

  return value;
}


/* ================= FORMAT ================= */

function formatNumber(value) {

  if (Math.abs(value) < 1e-12) {
    value = 0;
  }

  if (Number.isInteger(value)) {
    return String(value);
  }

  return Number(
    value.toPrecision(12)
  ).toString();
}


/* ================= CALCULATE ================= */

function calculate() {

  if (!expressionValue) return;

  try {

    const value =
      evaluateExpression(expressionValue);

    answerValue =
      formatNumber(value);

    lastAnswer = value;

    localStorage.setItem(
      "quickAnswer",
      value
    );

    addHistory(
      expressionValue,
      answerValue
    );

    updateDisplay();

  } catch {

    answerValue = "Error";

    updateDisplay();

    showToast("Invalid calculation");
  }
}


/* ================= SCIENTIFIC ================= */

function getCurrentNumber() {

  if (!expressionValue) {
    return 0;
  }

  return evaluateExpression(
    expressionValue
  );
}


function toRadians(value) {

  return angleMode === "DEG"
    ? value * Math.PI / 180
    : value;
}


function fromRadians(value) {

  return angleMode === "DEG"
    ? value * 180 / Math.PI
    : value;
}


function factorial(n) {

  if (
    n < 0 ||
    !Number.isInteger(n) ||
    n > 170
  ) {
    throw new Error("Invalid factorial");
  }

  let result = 1;

  for (let i = 2; i <= n; i++) {
    result *= i;
  }

  return result;
}


function scientific(type) {

  try {

    let value;
    let result;

    switch (type) {

      case "sin":
        result =
          Math.sin(
            toRadians(getCurrentNumber())
          );
        break;

      case "cos":
        result =
          Math.cos(
            toRadians(getCurrentNumber())
          );
        break;

      case "tan":
        result =
          Math.tan(
            toRadians(getCurrentNumber())
          );
        break;

      case "asin":
        result =
          fromRadians(
            Math.asin(getCurrentNumber())
          );
        break;

      case "acos":
        result =
          fromRadians(
            Math.acos(getCurrentNumber())
          );
        break;

      case "atan":
        result =
          fromRadians(
            Math.atan(getCurrentNumber())
          );
        break;

      case "sqrt":
        result =
          Math.sqrt(getCurrentNumber());
        break;

      case "square":
        value = getCurrentNumber();
        result = value * value;
        break;

      case "power":
        expressionValue += "^";
        updateDisplay();
        return;

      case "factorial":
        result =
          factorial(getCurrentNumber());
        break;

      case "pi":
        addToExpression("π");
        return;

      case "e":
        addToExpression("e");
        return;

      case "log":
        result =
          Math.log10(getCurrentNumber());
        break;

      case "ln":
        result =
          Math.log(getCurrentNumber());
        break;

      case "exp":
        result =
          Math.exp(getCurrentNumber());
        break;

      case "10x":
        result =
          10 ** getCurrentNumber();
        break;

      case "inverse":
        result =
          1 / getCurrentNumber();
        break;

      case "cube":
        value = getCurrentNumber();
        result = value ** 3;
        break;

      case "abs":
        result =
          Math.abs(getCurrentNumber());
        break;

      case "percent":
        result =
          getCurrentNumber() / 100;
        break;

      case "floor":
        result =
          Math.floor(getCurrentNumber());
        break;

      case "ceil":
        result =
          Math.ceil(getCurrentNumber());
        break;

      case "round":
        result =
          Math.round(getCurrentNumber());
        break;

      case "sign":
        result =
          -getCurrentNumber();
        break;

      case "random":
        result = Math.random();
        break;

      case "ans":
        expressionValue =
          String(lastAnswer);

        answerValue = "";

        updateDisplay();
        return;

      default:
        return;
    }

    expressionValue =
      formatNumber(result);

    answerValue = "";

    updateDisplay();

  } catch {

    showToast("Invalid operation");
  }
}


/* ================= MEMORY ================= */

function memoryStore() {

  try {

    memory =
      getCurrentNumber();

    localStorage.setItem(
      "quickMemory",
      memory
    );

    updateDisplay();

    showToast("Memory stored");

  } catch {

    showToast("Invalid number");
  }
}


function memoryRecall() {

  expressionValue =
    formatNumber(memory);

  answerValue = "";

  updateDisplay();
}


function memoryAdd() {

  try {

    memory +=
      getCurrentNumber();

    localStorage.setItem(
      "quickMemory",
      memory
    );

    updateDisplay();

    showToast("Added to memory");

  } catch {

    showToast("Invalid number");
  }
}


function memorySubtract() {

  try {

    memory -=
      getCurrentNumber();

    localStorage.setItem(
      "quickMemory",
      memory
    );

    updateDisplay();

    showToast("Subtracted from memory");

  } catch {

    showToast("Invalid number");
  }
}


function memoryClear() {

  memory = 0;

  localStorage.setItem(
    "quickMemory",
    0
  );

  updateDisplay();

  showToast("Memory cleared");
}


/* ================= ANGLE ================= */

function toggleAngle() {

  angleMode =
    angleMode === "DEG"
      ? "RAD"
      : "DEG";

  localStorage.setItem(
    "quickAngle",
    angleMode
  );

  document.getElementById(
    "angleBtn"
  ).textContent = angleMode;

  angleIndicator.textContent =
    angleMode;
}


/* ================= MODE ================= */

function setMode(mode) {

  appMode = mode;

  localStorage.setItem(
    "quickMode",
    mode
  );

  if (mode === "SCIENTIFIC") {

    scientificPanel.classList.remove(
      "hidden"
    );

    scientificTab.classList.add(
      "active"
    );

    basicTab.classList.remove(
      "active"
    );

    displayMode.textContent =
      "SCIENTIFIC";

  } else {

    scientificPanel.classList.add(
      "hidden"
    );

    basicTab.classList.add(
      "active"
    );

    scientificTab.classList.remove(
      "active"
    );

    displayMode.textContent =
      "BASIC";
  }
}


basicTab.addEventListener(
  "click",
  () => setMode("BASIC")
);

scientificTab.addEventListener(
  "click",
  () => setMode("SCIENTIFIC")
);


/* ================= HISTORY ================= */

function addHistory(expression, result) {

  historyData.unshift({
    expression: expression,
    result: result,
    time: new Date().toLocaleTimeString(
      [],
      {
        hour: "2-digit",
        minute: "2-digit"
      }
    )
  });

  historyData =
    historyData.slice(0, 50);

  localStorage.setItem(
    "quickHistory",
    JSON.stringify(historyData)
  );

  renderHistory();
}


function renderHistory() {

  const list =
    document.getElementById(
      "historyList"
    );

  if (!historyData.length) {

    list.innerHTML = `
      <div style="
        text-align:center;
        color:var(--muted);
        padding:40px 10px;
      ">
        No calculations yet
      </div>
    `;

    return;
  }

  list.innerHTML =
    historyData.map(
      (item, index) => `
        <div
          class="history-item"
          onclick="useHistory(${index})"
        >
          <div class="history-expression">
            ${escapeHTML(item.expression)}
          </div>

          <div class="history-result">
            = ${escapeHTML(item.result)}
          </div>

          <div class="history-time">
            ${escapeHTML(item.time)}
          </div>
        </div>
      `
    ).join("");
}


function useHistory(index) {

  const item =
    historyData[index];

  if (!item) return;

  expressionValue =
    item.expression;

  answerValue =
    item.result;

  updateDisplay();

  closeHistory();
}


function clearHistory() {

  historyData = [];

  localStorage.setItem(
    "quickHistory",
    "[]"
  );

  renderHistory();

  showToast("History cleared");
}


/* ================= HISTORY DRAWER ================= */

function openHistory() {

  document.getElementById(
    "historyPanel"
  ).classList.add("open");

  document.getElementById(
    "historyBackdrop"
  ).classList.add("show");
}


function closeHistory() {

  document.getElementById(
    "historyPanel"
  ).classList.remove("open");

  document.getElementById(
    "historyBackdrop"
  ).classList.remove("show");
}


document.getElementById(
  "historyBtn"
).addEventListener(
  "click",
  openHistory
);


/* ================= THEME ================= */

function toggleTheme() {

  document.body.classList.toggle(
    "light"
  );

  const light =
    document.body.classList.contains(
      "light"
    );

  localStorage.setItem(
    "quickTheme",
    light ? "light" : "dark"
  );

  document.getElementById(
    "themeBtn"
  ).textContent =
    light ? "☀" : "☾";
}


document.getElementById(
  "themeBtn"
).addEventListener(
  "click",
  toggleTheme
);


/* ================= TOAST ================= */

let toastTimer;

function showToast(message) {

  toastEl.textContent =
    message;

  toastEl.classList.add(
    "show"
  );

  clearTimeout(toastTimer);

  toastTimer =
    setTimeout(() => {

      toastEl.classList.remove(
        "show"
      );

    }, 1800);
}


/* ================= HTML ESCAPE ================= */

function escapeHTML(value) {

  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}


/* ================= KEYBOARD ================= */

document.addEventListener(
  "keydown",
  event => {

    const key = event.key;

    if (/^[0-9.]$/.test(key)) {
      addToExpression(key);
      return;
    }

    if (
      ["+", "-", "*", "/"].includes(key)
    ) {
      addToExpression(key);
      return;
    }

    if (
      key === "Enter" ||
      key === "="
    ) {
      calculate();
      return;
    }

    if (key === "Backspace") {
      backspace();
      return;
    }

    if (key === "Escape") {
      clearAll();
    }
  }
);


/* ================= EXIT ================= */

function showExitDialog() {
  exitOverlay.classList.add("show");
}


function hideExitDialog() {
  exitOverlay.classList.remove("show");
}


document.getElementById(
  "stayBtn"
).addEventListener(
  "click",
  hideExitDialog
);


document.getElementById(
  "exitBtn"
).addEventListener(
  "click",
  () => {

    if (
      window.Android &&
      typeof window.Android.exitApp ===
        "function"
    ) {

      window.Android.exitApp();
      return;
    }

    window.close();

    showToast(
      "You can close the app now"
    );
  }
);


/* ================= BACK BUTTON ================= */

let backState = false;

try {

  history.pushState(
    { quick: true },
    "",
    window.location.href
  );

  window.addEventListener(
    "popstate",
    () => {

      if (!backState) {

        backState = true;

        showExitDialog();

        history.pushState(
          { quick: true },
          "",
          window.location.href
        );

      } else {

        history.pushState(
          { quick: true },
          "",
          window.location.href
        );
      }
    }
  );

} catch {
  /* Browser does not support history handling */
}


/* ================= SPLASH ================= */
/* ================= SPLASH ================= */

function startBootAnimation() {

  let progress = 0;

  const status =
    document.querySelector(".boot-status");

  const app =
    document.getElementById("app");

  const messages = [
    "INITIALIZING QUICK",
    "LOADING ENGINE",
    "LOADING SCIENTIFIC CORE",
    "RESTORING MEMORY",
    "RESTORING HISTORY",
    "CODEX SYSTEM READY"
  ];

  /* Make sure app is hidden during boot */
  app.classList.add("hidden");

  loadingBar.style.width = "0%";
  loadingPercent.textContent = "0%";

  const timer = setInterval(() => {

    progress += 2;

    if (progress > 100) {
      progress = 100;
    }

    loadingBar.style.width =
      progress + "%";

    loadingPercent.textContent =
      progress + "%";

    const messageIndex =
      Math.min(
        Math.floor(progress / 18),
        messages.length - 1
      );

    status.textContent =
      messages[messageIndex];

    /* ================= 100% ================= */

    if (progress >= 100) {

      clearInterval(timer);

      status.textContent =
        "CODEX SYSTEM READY";

      setTimeout(() => {

        /* SHOW CALCULATOR */
        app.classList.remove("hidden");

        /* START SPLASH FADE */
        splashScreen.classList.add("hide");

        /* Completely remove splash */
        setTimeout(() => {

          splashScreen.style.display = "none";

        }, 850);

      }, 500);
    }

  }, 50);
}
          


/* ================= STARTUP ================= */

function startup() {

  /* Random color FIRST */
  randomBrandColor();

  /* Theme */
  const savedTheme =
    localStorage.getItem(
      "quickTheme"
    );

  if (savedTheme === "light") {

    document.body.classList.add(
      "light"
    );

    document.getElementById(
      "themeBtn"
    ).textContent = "☀";
  }

  /* Mode */
  setMode(appMode);

  /* Angle */
  document.getElementById(
    "angleBtn"
  ).textContent = angleMode;

  /* History */
  renderHistory();

  /* Display */
  updateDisplay();

  /* Boot */
  startBootAnimation();
}


/* RUN */
startup();
