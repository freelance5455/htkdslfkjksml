const questions = [
    {
        question: "What does HTTPS provide?",
        answers: [
            "Secure communication",
            "Faster internet",
            "More storage",
            "Free Wi-Fi"
        ],
        correct: 0
    },
    {
        question: "What is a strong password?",
        answers: [
            "12345678",
            "password",
            "A8#kP2!zQ9",
            "abcdef"
        ],
        correct: 2
    },
    {
        question: "What does a firewall do?",
        answers: [
            "Blocks or allows network traffic",
            "Charges your phone",
            "Creates videos",
            "Increases screen brightness"
        ],
        correct: 0
    },
    {
        question: "What is phishing?",
        answers: [
            "A type of computer game",
            "A fake attempt to steal information",
            "A programming language",
            "A Wi-Fi standard"
        ],
        correct: 1
    },
    {
        question: "What does VPN stand for?",
        answers: [
            "Virtual Private Network",
            "Very Personal Number",
            "Virtual Program Node",
            "Verified Public Network"
        ],
        correct: 0
    }
];

let currentQuestion = 0;
let score = 0;
let answered = false;

let highScore =
    Number(localStorage.getItem("hackerTahsinHighScore")) || 0;

const startScreen = document.getElementById("startScreen");
const quizScreen = document.getElementById("quizScreen");
const startBtn = document.getElementById("startBtn");
const startHighScore = document.getElementById("startHighScore");

const questionElement = document.getElementById("question");
const answersElement = document.getElementById("answers");
const nextButton = document.getElementById("nextBtn");
const scoreElement = document.getElementById("score");
const highScoreElement = document.getElementById("highScore");

startHighScore.textContent = "High Score: " + highScore;
highScoreElement.textContent = "High Score: " + highScore;

function showQuestion() {
    answered = false;

    const current = questions[currentQuestion];

    questionElement.textContent =
        "Question " + (currentQuestion + 1) + ": " + current.question;

    answersElement.innerHTML = "";

    current.answers.forEach(function(answer, index) {
        const button = document.createElement("button");

        button.textContent = answer;

        button.addEventListener("click", function() {
            checkAnswer(index, button);
        });

        answersElement.appendChild(button);
    });
}

function checkAnswer(selectedIndex, selectedButton) {
    if (answered) return;

    answered = true;

    const current = questions[currentQuestion];
    const buttons = answersElement.querySelectorAll("button");

    buttons.forEach(function(button, index) {
        button.disabled = true;

        if (index === current.correct) {
            button.style.backgroundColor = "#064d32";
            button.style.color = "#00ff88";
            button.style.borderColor = "#00ff88";
        }
    });

    if (selectedIndex === current.correct) {
        score++;
        selectedButton.textContent += " ✓";
    } else {
        selectedButton.style.backgroundColor = "#5a1717";
        selectedButton.style.color = "#ff4444";
        selectedButton.style.borderColor = "#ff4444";
        selectedButton.textContent += " ✗";
    }

    scoreElement.textContent = "Score: " + score;
}

startBtn.addEventListener("click", function() {
    startScreen.classList.add("hidden");
    quizScreen.classList.remove("hidden");

    currentQuestion = 0;
    score = 0;

    scoreElement.textContent = "Score: 0";

    showQuestion();
});

nextButton.addEventListener("click", function() {
    if (currentQuestion < questions.length - 1) {
        currentQuestion++;
        showQuestion();
    } else {
        if (score > highScore) {
            highScore = score;

            localStorage.setItem(
                "hackerTahsinHighScore",
                highScore
            );
        }

        questionElement.textContent = "Quiz Complete!";
        answersElement.innerHTML = "";

        scoreElement.textContent =
            "Final Score: " + score + "/" + questions.length;

        highScoreElement.textContent =
            "High Score: " + highScore;

        startBtn.textContent = "PLAY AGAIN";

        startScreen.classList.remove("hidden");
        quizScreen.classList.add("hidden");

        startHighScore.textContent =
            "High Score: " + highScore;
    }
});
