const shops = [
  { name: "शिव किराना स्टोर", rating: 4.5, distance: "1.2 किमी", icon: "🏪" },
  { name: "युवा जनरल स्टोर", rating: 4.2, distance: "1.4 किमी", icon: "🛍️" },
  { name: "गुप्ता मोबाइल हाउस", rating: 4.7, distance: "1.8 किमी", icon: "📱" },
  { name: "शर्मा वस्त्रालय", rating: 4.3, distance: "2.1 किमी", icon: "👕" }
];

const products = [
  { name: "आटा (10kg)", price: 450, shop: "शिव किराना स्टोर", icon: "🌾", category: "किराना" },
  { name: "रिफाइंड तेल (1L)", price: 130, shop: "शिव किराना स्टोर", icon: "🛢️", category: "किराना" },
  { name: "चावल (10kg)", price: 520, shop: "युवा जनरल स्टोर", icon: "🍚", category: "किराना" },
  { name: "दाल (1kg)", price: 120, shop: "शिव किराना स्टोर", icon: "🫘", category: "किराना" },
  { name: "टी-शर्ट", price: 399, shop: "शर्मा वस्त्रालय", icon: "👕", category: "कपड़े" },
  { name: "मोबाइल कवर", price: 149, shop: "गुप्ता मोबाइल हाउस", icon: "📱", category: "मोबाइल" }
];

let cart = JSON.parse(localStorage.getItem("balrampurCart") || "[]");

const shopsEl = document.getElementById("shops");
const productsEl = document.getElementById("products");
const searchInput = document.getElementById("searchInput");
const cartCount = document.getElementById("cartCount");
const toast = document.getElementById("toast");

function renderShops(list = shops) {
  shopsEl.innerHTML = list.length
    ? list.map(shop => `
      <article class="shop">
        <div class="shop-icon">${shop.icon}</div>
        <div class="shop-info">
          <h3>${shop.name}</h3>
          <p>⭐ ${shop.rating} &nbsp; • &nbsp; ${shop.distance}</p>
          <p class="open">● अभी खुला है</p>
        </div>
        <div class="arrow">›</div>
      </article>
    `).join("")
    : "<p>कोई दुकान नहीं मिली।</p>";
}

function renderProducts(list = products) {
  productsEl.innerHTML = list.length
    ? list.map((product, index) => `
      <article class="product">
        <div class="product-image">${product.icon}</div>
        <h3>${product.name}</h3>
        <p class="shop-name">${product.shop}</p>
        <div class="price">₹${product.price}</div>
        <button class="add-btn" data-index="${products.indexOf(product)}">कार्ट में जोड़ें</button>
      </article>
    `).join("")
    : "<p>कोई सामान नहीं मिला।</p>";

  document.querySelectorAll(".add-btn").forEach(btn => {
    btn.addEventListener("click", () => addToCart(Number(btn.dataset.index)));
  });
}

function addToCart(index) {
  cart.push(products[index]);
  localStorage.setItem("balrampurCart", JSON.stringify(cart));
  updateCart();
  showToast(`${products[index].name} कार्ट में जोड़ दिया गया`);
}

function updateCart() {
  cartCount.textContent = cart.length;
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 1800);
}

searchInput.addEventListener("input", () => {
  const q = searchInput.value.trim().toLowerCase();

  const filteredProducts = products.filter(p =>
    `${p.name} ${p.shop} ${p.category}`.toLowerCase().includes(q)
  );

  const filteredShops = shops.filter(s =>
    s.name.toLowerCase().includes(q)
  );

  renderProducts(filteredProducts);
  renderShops(filteredShops);
});

document.querySelectorAll(".categories button").forEach(button => {
  button.addEventListener("click", () => {
    const category = button.dataset.category;
    const filtered = products.filter(p => p.category === category);
    renderProducts(filtered);
    document.querySelector(".product-grid").scrollIntoView({ behavior: "smooth" });
  });
});

document.querySelectorAll(".nav-item").forEach(item => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".nav-item").forEach(x => x.classList.remove("active"));
    item.classList.add("active");

    const page = item.dataset.page;
    if (page === "cart") {
      showToast(`कार्ट में ${cart.length} सामान है`);
    } else if (page === "shops") {
      document.querySelector(".shop-list").scrollIntoView({ behavior: "smooth" });
    } else if (page === "orders") {
      showToast("अभी कोई ऑर्डर नहीं है");
    } else if (page === "profile") {
      showToast("प्रोफाइल जल्द उपलब्ध होगी");
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  });
});

document.getElementById("profileBtn").addEventListener("click", () => {
  showToast("प्रोफाइल सेक्शन जल्द उपलब्ध होगा");
});

renderShops();
renderProducts();
updateCart();
