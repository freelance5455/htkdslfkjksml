// ER Med — Complete App Logic
// No external dependencies. All data and logic self-contained.

// ─────────────────────────────────────────
// MEDICINE DATABASE
// ─────────────────────────────────────────
const MEDS = [
  {id:1,name:'Acetaminophen',alt:'Paracetamol',cat:'Analgesic',tag:'Pain',desc:'Non-opioid analgesic and antipyretic. First-line for mild-moderate pain.',route:'IV / PO / PR',onset:'30–60 min (PO)',duration:'4–6 hours',halflife:'2–3 hours',calcType:'weight',dosePerKg:15,unit:'mg',maxDose:1000,maxLabel:'1000 mg single dose, 4 g/day',notes:'Reduce dose in hepatic impairment. Avoid in severe liver disease. Safe in pregnancy.',contra:'Severe hepatic impairment, known hypersensitivity.',vitals:['weight','age','creatinine'],checks:[{v:'creatinine',op:'>',val:2,msg:'Creatinine > 2 mg/dL — extend dosing interval to q8h.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: max 3 g/day recommended.'},{v:'creatinine',op:'>',val:2,note:'Renal impairment: extend interval to q8h.'}]},
  {id:2,name:'Adenosine',alt:null,cat:'Antiarrhythmic',tag:'Cardiac',desc:'Rapidly terminates SVT by blocking AV node conduction.',route:'IV rapid push',onset:'10–20 sec',duration:'10–30 sec',halflife:'< 10 sec',calcType:'weight',dosePerKg:0.1,unit:'mg',maxDose:6,maxLabel:'6 mg first dose; 12 mg subsequent',notes:'Must be rapid IV push followed by saline flush. Monitor ECG continuously.',contra:'2nd/3rd degree AV block, sick sinus syndrome, asthma (relative).',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'<',val:50,msg:'HR < 50 bpm — bradycardia. Adenosine may worsen. Reassess rhythm.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — haemodynamic instability. Consider cardioversion.'}],mods:[]},
  {id:3,name:'Albuterol',alt:'Salbutamol',cat:'Bronchodilator',tag:'Respiratory',desc:'Short-acting β2 agonist. Relieves bronchospasm in asthma and COPD.',route:'Nebulized / MDI / IV',onset:'5–15 min',duration:'4–6 hours',halflife:'3–8 hours',calcType:'fixed',fixedDose:'2.5–5 mg nebulized q20 min × 3 for severe asthma',notes:'Can cause tachycardia and hypokalemia.',contra:'Hypersensitivity to albuterol.',vitals:['hr','spo2','potassium'],checks:[{v:'hr',op:'>',val:130,msg:'HR > 130 bpm — albuterol may worsen tachycardia.'},{v:'spo2',op:'<',val:90,msg:'SpO₂ < 90% — consider IV magnesium and intubation planning.'},{v:'potassium',op:'<',val:3.0,msg:'K+ < 3.0 mEq/L — albuterol may further lower potassium.'}],mods:[]},
  {id:4,name:'Alteplase',alt:'tPA',cat:'Thrombolytic',tag:'Stroke/STEMI',desc:'Tissue plasminogen activator for acute ischemic stroke and STEMI.',route:'IV',onset:'Immediate',duration:'Ongoing',halflife:'5 min',calcType:'weight',dosePerKg:0.9,unit:'mg',maxDose:90,maxLabel:'90 mg max — 10% bolus over 1 min, rest over 60 min',notes:'Time window ≤ 4.5h for stroke.',contra:'Recent surgery, active bleeding, BP > 185/110, prior intracranial hemorrhage.',vitals:['weight','sbp','age','inr'],checks:[{v:'sbp',op:'>',val:185,msg:'SBP > 185 mmHg — ABSOLUTE CONTRAINDICATION. Lower BP before giving tPA.'},{v:'inr',op:'>',val:1.7,msg:'INR > 1.7 — anticoagulated. tPA contraindicated.'},{v:'age',op:'>',val:80,msg:'Age > 80 — increased bleeding risk. Consult neurology.'}],mods:[]},
  {id:5,name:'Amiodarone',alt:null,cat:'Antiarrhythmic',tag:'Cardiac',desc:'Class III antiarrhythmic for VF, VT, and AF rate control.',route:'IV / PO',onset:'Minutes (IV)',duration:'Variable',halflife:'40–55 days',calcType:'weight',dosePerKg:5,unit:'mg',maxDose:300,maxLabel:'300 mg IV bolus for VF/pulseless VT',notes:'VF/VT: 300 mg IV bolus. Monitor thyroid and LFTs long-term.',contra:'2nd/3rd degree AV block without pacemaker, iodine allergy.',vitals:['weight','hr','sbp','qtc'],checks:[{v:'qtc',op:'>',val:500,msg:'QTc > 500 ms — high risk of torsades de pointes.'},{v:'hr',op:'<',val:50,msg:'HR < 50 bpm — bradycardia. Amiodarone may worsen.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — IV amiodarone may lower BP further.'}],mods:[]},
  {id:6,name:'Aspirin',alt:'ASA',cat:'Antiplatelet',tag:'Cardiac',desc:'Inhibits platelet aggregation. Used immediately in ACS.',route:'PO / PR',onset:'30–60 min',duration:'7–10 days (platelet)',halflife:'15–20 min',calcType:'fixed',fixedDose:'162–325 mg PO — chew for fastest absorption',notes:'Give immediately in suspected MI.',contra:'Active GI bleeding, aspirin allergy, age < 12 years.',vitals:['sbp'],checks:[{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — evaluate for cardiogenic shock first.'}],mods:[]},
  {id:7,name:'Atropine',alt:null,cat:'Anticholinergic',tag:'Cardiac',desc:'Increases heart rate by blocking vagal tone. Used in symptomatic bradycardia.',route:'IV / IM / ET',onset:'1–2 min (IV)',duration:'2–6 hours',halflife:'2–3 hours',calcType:'weight',dosePerKg:0.02,unit:'mg',maxDose:3,maxLabel:'0.5–1 mg IV q3–5 min; max 3 mg total',notes:'Min dose 0.5 mg in adults — paradoxical bradycardia with lower doses.',contra:'Angle-closure glaucoma, obstructive uropathy, tachyarrhythmias.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'>',val:100,msg:'HR > 100 bpm — tachycardia. Atropine not indicated.'}],mods:[]},
  {id:8,name:'Calcium Gluconate',alt:null,cat:'Electrolyte',tag:'Metabolic',desc:'Stabilizes cardiac membrane in hyperkalemia. Also treats hypocalcemia.',route:'IV',onset:'1–3 min',duration:'30–60 min',halflife:'Variable',calcType:'fixed',fixedDose:'1–2 g (10–20 mL of 10%) IV over 5–10 min for hyperkalemia',notes:'Does NOT lower potassium — stabilizes myocardium only.',contra:'Hypercalcemia, digoxin toxicity (relative).',vitals:['potassium','hr'],checks:[{v:'potassium',op:'<',val:5.0,msg:'K+ < 5.0 mEq/L — hyperkalemia not confirmed. Reassess indication.'}],mods:[]},
  {id:9,name:'Ceftriaxone',alt:null,cat:'Antibiotic',tag:'Antibiotic',desc:'Broad-spectrum 3rd gen cephalosporin. One of the most common ER antibiotics.',route:'IV / IM',onset:'Immediate (IV)',duration:'24 hours',halflife:'6–9 hours',calcType:'weight',dosePerKg:50,unit:'mg',maxDose:2000,maxLabel:'1–2 g/day adult; 50–100 mg/kg/day pediatric',notes:'Excellent CNS penetration. IM painful — use lidocaine as diluent.',contra:'Penicillin or cephalosporin allergy.',vitals:['weight','age','creatinine'],checks:[],mods:[{v:'age',op:'<',val:12,note:'Pediatric: 50–100 mg/kg/day in 1–2 divided doses.'}]},
  {id:10,name:'Dexamethasone',alt:null,cat:'Corticosteroid',tag:'Anti-inflam.',desc:'Potent corticosteroid for anaphylaxis, croup, and cerebral edema.',route:'IV / IM / PO',onset:'1–2 hours',duration:'36–72 hours',halflife:'36–72 hours',calcType:'weight',dosePerKg:0.15,unit:'mg',maxDose:10,maxLabel:'8–10 mg adult; croup 0.6 mg/kg (max 16 mg)',notes:'Croup: 0.6 mg/kg. Cerebral edema: 4–8 mg q6h.',contra:'Systemic fungal infection, live vaccines.',vitals:['weight','age','glucose'],checks:[{v:'glucose',op:'>',val:250,msg:'Glucose > 250 mg/dL — dexamethasone may worsen hyperglycemia.'}],mods:[]},
  {id:11,name:'Dextrose',alt:'D50W',cat:'Metabolic',tag:'Metabolic',desc:'IV glucose for treatment of hypoglycemia.',route:'IV',onset:'1–3 min',duration:'30–60 min',halflife:'Variable',calcType:'weight',dosePerKg:0.5,unit:'g',maxDose:25,maxLabel:'25 g IV (50 mL of D50W) for adult',notes:'Recheck glucose 15 min after. Use D10W in neonates.',contra:'Hyperglycemia, hyperosmolar state.',vitals:['weight','glucose','age'],checks:[{v:'glucose',op:'>',val:180,msg:'Glucose > 180 mg/dL — hyperglycemia. Dextrose not indicated.'}],mods:[]},
  {id:12,name:'Diazepam',alt:'Valium',cat:'Benzodiazepine',tag:'Seizure',desc:'Long-acting benzodiazepine for seizure termination and anxiolysis.',route:'IV / IM / PR / IN',onset:'1–3 min (IV)',duration:'20–60 min',halflife:'20–100 hours',calcType:'weight',dosePerKg:0.1,unit:'mg',maxDose:10,maxLabel:'5–10 mg IV adult; 0.1–0.3 mg/kg pediatric',notes:'Respiratory depression risk. Have airway equipment ready.',contra:'Acute narrow-angle glaucoma, respiratory depression.',vitals:['weight','age','spo2','sbp'],checks:[{v:'spo2',op:'<',val:92,msg:'SpO₂ < 92% — have airway equipment ready.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — diazepam may worsen hypotension.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: start at 2.5 mg.'}]},
  {id:13,name:'Diltiazem',alt:'Cardizem',cat:'CCB',tag:'Cardiac',desc:'Rate control for atrial fibrillation and atrial flutter.',route:'IV / PO',onset:'3–5 min (IV)',duration:'1–3 hours',halflife:'3–4.5 hours',calcType:'weight',dosePerKg:0.25,unit:'mg',maxDose:25,maxLabel:'0.25 mg/kg IV bolus over 2 min; infusion 5–15 mg/h',notes:'Monitor HR and BP closely.',contra:'WPW syndrome, 2nd/3rd degree AV block, decompensated HF.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'<',val:60,msg:'HR < 60 bpm — diltiazem contraindicated.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — diltiazem will worsen hypotension.'}],mods:[]},
  {id:14,name:'Diphenhydramine',alt:'Benadryl',cat:'Antihistamine',tag:'Allergy',desc:'H1 antihistamine for allergic reactions and anaphylaxis adjunct.',route:'IV / IM / PO',onset:'15–30 min',duration:'4–6 hours',halflife:'2–10 hours',calcType:'weight',dosePerKg:1,unit:'mg',maxDose:50,maxLabel:'25–50 mg IV/IM adult; 1 mg/kg pediatric (max 50 mg)',notes:'Sedating. Anticholinergic effects in elderly.',contra:'Angle-closure glaucoma, neonates, MAOI use.',vitals:['weight','age'],checks:[],mods:[{v:'age',op:'>=',val:65,note:'Elderly: avoid — anticholinergic burden. Prefer cetirizine.'}]},
  {id:15,name:'Dobutamine',alt:null,cat:'Inotrope',tag:'Shock',desc:'Positive inotrope for cardiogenic shock and acute heart failure.',route:'IV infusion',onset:'1–2 min',duration:'10 min after stopping',halflife:'2 min',calcType:'weight',dosePerKg:5,unit:'mcg/kg/min',maxDose:20,maxLabel:'2.5–20 mcg/kg/min; titrate to effect',notes:'May cause tachycardia and arrhythmias.',contra:'Hypertrophic obstructive cardiomyopathy, uncorrected hypovolemia.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'>',val:130,msg:'HR > 130 bpm — dobutamine may worsen tachycardia.'}],mods:[]},
  {id:16,name:'Dopamine',alt:null,cat:'Vasopressor',tag:'Shock',desc:'Dose-dependent vasopressor and inotrope.',route:'IV infusion',onset:'2–4 min',duration:'10 min after stopping',halflife:'2 min',calcType:'weight',dosePerKg:5,unit:'mcg/kg/min',maxDose:20,maxLabel:'2–20 mcg/kg/min; low (renal), mid (cardiac), high (vasopressor)',notes:'More arrhythmogenic than norepinephrine.',contra:'Pheochromocytoma, ventricular fibrillation.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'>',val:130,msg:'HR > 130 bpm — highly arrhythmogenic. Consider norepinephrine.'}],mods:[]},
  {id:17,name:'Enoxaparin',alt:'Lovenox',cat:'LMWH',tag:'Cardiac',desc:'Low molecular weight heparin for ACS, DVT, and PE.',route:'SC / IV',onset:'3–5 hours (SC)',duration:'12–24 hours',halflife:'4.5 hours',calcType:'weight',dosePerKg:1,unit:'mg',maxDose:150,maxLabel:'1 mg/kg SC q12h treatment',notes:'Avoid in severe renal impairment — use UFH instead.',contra:'Active major bleeding, HIT, eGFR < 15.',vitals:['weight','creatinine','gfr'],checks:[{v:'gfr',op:'<',val:15,msg:'eGFR < 15 — enoxaparin contraindicated. Use UFH.'},{v:'gfr',op:'<',val:30,msg:'eGFR < 30 — reduce to 1 mg/kg q24h.'}],mods:[{v:'gfr',op:'<',val:30,note:'Reduce to 1 mg/kg SC q24h.'}]},
  {id:18,name:'Epinephrine',alt:'Adrenaline',cat:'Vasopressor',tag:'Anaphylaxis',desc:'First-line for anaphylaxis. Vasopressor in cardiac arrest.',route:'IM / IV / ET / Nebulized',onset:'< 1 min (IV)',duration:'5–15 min',halflife:'2–3 min',calcType:'weight',dosePerKg:0.01,unit:'mg',maxDose:0.5,maxLabel:'0.3–0.5 mg IM (1:1000) anaphylaxis; 1 mg IV (1:10000) cardiac arrest',notes:'Anaphylaxis: 0.3–0.5 mg IM lateral thigh.',contra:'No absolute contraindications in anaphylaxis or cardiac arrest.',vitals:['weight','sbp','hr'],checks:[{v:'hr',op:'>',val:150,msg:'HR > 150 bpm — epinephrine will further increase HR.'},{v:'sbp',op:'>',val:180,msg:'SBP > 180 mmHg — use lowest effective dose.'}],mods:[]},
  {id:19,name:'Esmolol',alt:'Brevibloc',cat:'Beta Blocker',tag:'Cardiac',desc:'Ultra-short-acting beta-1 blocker for rate control.',route:'IV infusion',onset:'60 sec',duration:'10–20 min after stopping',halflife:'9 min',calcType:'weight',dosePerKg:0.5,unit:'mg',maxDose:80,maxLabel:'500 mcg/kg bolus; maintenance 50–300 mcg/kg/min',notes:'Ideal for titration — very short duration.',contra:'Decompensated heart failure, bradycardia, asthma.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'<',val:60,msg:'HR < 60 bpm — esmolol contraindicated.'},{v:'sbp',op:'<',val:100,msg:'SBP < 100 mmHg — may cause dangerous hypotension.'}],mods:[]},
  {id:20,name:'Etomidate',alt:null,cat:'Induction Agent',tag:'RSI',desc:'Rapid-acting sedative-hypnotic for RSI. Minimal hemodynamic effect.',route:'IV',onset:'30–60 sec',duration:'5–15 min',halflife:'2.9–5.3 hours',calcType:'weight',dosePerKg:0.3,unit:'mg',maxDose:30,maxLabel:'0.3 mg/kg IV (typically 20–30 mg adult)',notes:'Adrenal suppression — avoid in septic shock. Myoclonus is common.',contra:'Relative: adrenal insufficiency, septic shock.',vitals:['weight','sbp','hr'],checks:[{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — consider ketamine instead.'}],mods:[]},
  {id:21,name:'Fentanyl',alt:null,cat:'Opioid',tag:'Pain/RSI',desc:'Potent short-acting synthetic opioid for pain and RSI premedication.',route:'IV / IM / IN / Transdermal',onset:'1–2 min (IV)',duration:'30–60 min',halflife:'2–4 hours',calcType:'weight',dosePerKg:1,unit:'mcg',maxDose:100,maxLabel:'1–2 mcg/kg IV pain; 3 mcg/kg RSI premedication',notes:'Chest wall rigidity at high doses. Have naloxone ready.',contra:'Respiratory depression, MAOI use within 14 days.',vitals:['weight','sbp','hr','spo2','age'],checks:[{v:'spo2',op:'<',val:94,msg:'SpO₂ < 94% — ensure airway support ready.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — fentanyl can cause hypotension.'},{v:'hr',op:'<',val:55,msg:'HR < 55 bpm — fentanyl may cause bradycardia.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: reduce dose by 50%.'}]},
  {id:22,name:'Flumazenil',alt:null,cat:'Antidote',tag:'Toxicology',desc:'Reverses benzodiazepine sedation. Use with extreme caution.',route:'IV',onset:'1–2 min',duration:'45–90 min',halflife:'40–80 min',calcType:'fixed',fixedDose:'0.2 mg IV over 30 sec; repeat 0.1 mg q60 sec up to 1 mg total',notes:'Duration shorter than benzodiazepines — re-sedation common. Can precipitate seizures.',contra:'TCA overdose, benzo-dependent seizure disorder, elevated ICP.',vitals:['hr','sbp'],checks:[],mods:[]},
  {id:23,name:'Furosemide',alt:'Lasix',cat:'Loop Diuretic',tag:'Cardiac',desc:'Potent loop diuretic for acute pulmonary edema and heart failure.',route:'IV / PO',onset:'5 min (IV)',duration:'2–3 hours',halflife:'2 hours',calcType:'weight',dosePerKg:1,unit:'mg',maxDose:80,maxLabel:'20–80 mg IV; repeat or double if no response in 1 hour',notes:'Monitor K+ and renal function. Ototoxicity with rapid high-dose infusion.',contra:'Anuria, sulfonamide allergy, severe electrolyte imbalance.',vitals:['weight','sbp','creatinine','potassium'],checks:[{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — correct volume first.'},{v:'potassium',op:'<',val:3.0,msg:'K+ < 3.0 mEq/L — replace K+ before or concurrently.'},{v:'creatinine',op:'>',val:3.0,msg:'Creatinine > 3.0 — reduced efficacy.'}],mods:[]},
  {id:24,name:'Glucagon',alt:null,cat:'Metabolic',tag:'Metabolic',desc:'Raises blood glucose via glycogenolysis. Used in hypoglycemia.',route:'IM / SC / IV',onset:'5–15 min (IM)',duration:'60–90 min',halflife:'3–6 min',calcType:'weight',dosePerKg:0.02,unit:'mg',maxDose:1,maxLabel:'1 mg IM/SC adult; 0.5 mg child < 20 kg',notes:'Follow with oral carbohydrates when patient can swallow.',contra:'Pheochromocytoma, insulinoma.',vitals:['weight','glucose','age'],checks:[{v:'glucose',op:'>',val:180,msg:'Glucose > 180 mg/dL — glucagon not indicated.'}],mods:[]},
  {id:25,name:'Haloperidol',alt:'Haldol',cat:'Antipsychotic',tag:'Agitation',desc:'First-generation antipsychotic for acute agitation and psychosis.',route:'IV / IM / PO',onset:'10–20 min (IM)',duration:'4–12 hours',halflife:'18–54 hours',calcType:'weight',dosePerKg:0.05,unit:'mg',maxDose:5,maxLabel:'2–5 mg IM/IV for agitation',notes:'QTc prolongation risk. EPS — have diphenhydramine ready.',contra:"Parkinson's, QTc > 500 ms, CNS depression.",vitals:['weight','age','qtc','sbp'],checks:[{v:'qtc',op:'>',val:500,msg:'QTc > 500 ms — CONTRAINDICATED. Use olanzapine instead.'},{v:'qtc',op:'>',val:450,msg:'QTc 450–500 ms — use lowest dose, monitor ECG.'},{v:'sbp',op:'<',val:100,msg:'SBP < 100 mmHg — may cause orthostatic hypotension.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: start at 0.5–1 mg.'}]},
  {id:26,name:'Heparin',alt:'UFH',cat:'Anticoagulant',tag:'Cardiac',desc:'Anticoagulant for ACS, PE, DVT, and thrombus prevention.',route:'IV infusion / SC',onset:'Immediate (IV)',duration:'Ongoing',halflife:'1.5 hours',calcType:'weight',dosePerKg:60,unit:'units',maxDose:5000,maxLabel:'Bolus 60–80 units/kg IV (max 5000 units); infusion 12–18 units/kg/h',notes:'Monitor aPTT q6h. Antidote: protamine sulfate.',contra:'Active major bleeding, HIT, hemorrhagic stroke.',vitals:['weight','sbp','inr'],checks:[{v:'sbp',op:'<',val:80,msg:'SBP < 80 mmHg — severe instability. Reassess anticoagulation.'}],mods:[]},
  {id:27,name:'Insulin',alt:null,cat:'Metabolic',tag:'Metabolic',desc:'Lowers blood glucose and shifts potassium intracellularly.',route:'IV / SC / IM',onset:'15–60 min (SC)',duration:'4–8 hours',halflife:'5–6 min (IV)',calcType:'weight',dosePerKg:0.1,unit:'units',maxDose:10,maxLabel:'DKA: 0.1 units/kg/h; Hyperkalemia: 10 units regular IV + D50',notes:'Always pair with dextrose when giving for hyperkalemia.',contra:'Hypoglycemia.',vitals:['weight','glucose','potassium'],checks:[{v:'glucose',op:'<',val:80,msg:'Glucose < 80 mg/dL — hypoglycemia! Do NOT give insulin.'}],mods:[]},
  {id:28,name:'Ketamine',alt:null,cat:'Dissociative Anesthetic',tag:'RSI/Pain',desc:'Dissociative anesthetic for RSI, procedural sedation, and analgesia.',route:'IV / IM',onset:'30–60 sec (IV)',duration:'10–20 min',halflife:'2–3 hours',calcType:'weight',dosePerKg:1.5,unit:'mg',maxDose:200,maxLabel:'1–2 mg/kg IV RSI; 0.3–0.5 mg/kg subanesthetic analgesia',notes:'Maintains airway reflexes. Increases secretions — consider glycopyrrolate.',contra:'Uncontrolled hypertension, active psychosis, elevated ICP (relative).',vitals:['weight','sbp','hr','age'],checks:[{v:'sbp',op:'>',val:180,msg:'SBP > 180 mmHg — ketamine raises BP further.'},{v:'hr',op:'>',val:130,msg:'HR > 130 bpm — ketamine is sympathomimetic.'}],mods:[]},
  {id:29,name:'Labetalol',alt:null,cat:'Alpha/Beta Blocker',tag:'HTN Crisis',desc:'Combined alpha and beta blocker for hypertensive emergencies.',route:'IV / PO',onset:'5 min (IV)',duration:'3–6 hours',halflife:'6–8 hours',calcType:'weight',dosePerKg:0.3,unit:'mg',maxDose:20,maxLabel:'20 mg slow IV over 2 min; repeat 40–80 mg q10 min to max 300 mg',notes:'Preferred in aortic dissection and eclampsia.',contra:'Decompensated heart failure, bradycardia, asthma.',vitals:['weight','sbp','hr'],checks:[{v:'hr',op:'<',val:60,msg:'HR < 60 bpm — CONTRAINDICATED. Labetalol will worsen bradycardia.'},{v:'sbp',op:'<',val:100,msg:'SBP < 100 mmHg — may cause dangerous hypotension.'}],mods:[]},
  {id:30,name:'Levetiracetam',alt:'Keppra',cat:'Antiepileptic',tag:'Seizure',desc:'Second-line antiepileptic for status epilepticus.',route:'IV / PO',onset:'< 5 min (IV)',duration:'12–24 hours',halflife:'6–8 hours',calcType:'weight',dosePerKg:60,unit:'mg',maxDose:4500,maxLabel:'1000–3000 mg IV over 15 min (max 60 mg/kg)',notes:'Minimal drug interactions. Increasingly preferred over phenytoin.',contra:'Hypersensitivity to levetiracetam.',vitals:['weight','age','gfr'],checks:[],mods:[{v:'gfr',op:'<',val:50,note:'eGFR < 50: reduce dose 25%.'},{v:'gfr',op:'<',val:30,note:'eGFR < 30: reduce dose 50%.'}]},
  {id:31,name:'Lidocaine',alt:'Lignocaine',cat:'Local Anesthetic',tag:'Anesthetic',desc:'Local anesthetic and antiarrhythmic for ventricular arrhythmias.',route:'Local / IV / ET',onset:'< 1 min (IV)',duration:'1–2 hours',halflife:'1.5–2 hours',calcType:'weight',dosePerKg:1.5,unit:'mg',maxDose:300,maxLabel:'Antiarrhythmic: 1–1.5 mg/kg IV; Local: max 4.5 mg/kg',notes:'CNS toxicity precedes cardiac toxicity.',contra:'2nd/3rd degree AV block, Stokes-Adams syndrome.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'<',val:50,msg:'HR < 50 bpm — lidocaine may worsen bradycardia.'}],mods:[]},
  {id:32,name:'Lorazepam',alt:'Ativan',cat:'Benzodiazepine',tag:'Seizure',desc:'First-line benzodiazepine for status epilepticus in adults.',route:'IV / IM',onset:'1–5 min (IV)',duration:'12–24 hours',halflife:'10–20 hours',calcType:'weight',dosePerKg:0.1,unit:'mg',maxDose:4,maxLabel:'4 mg IV adult; 0.05–0.1 mg/kg pediatric (max 4 mg)',notes:'Preferred over diazepam for status epilepticus.',contra:'Acute narrow-angle glaucoma, respiratory depression.',vitals:['weight','age','spo2','sbp'],checks:[{v:'spo2',op:'<',val:92,msg:'SpO₂ < 92% — have airway equipment ready.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — lorazepam may worsen hypotension.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: start with 0.5–1 mg.'}]},
  {id:33,name:'Magnesium Sulfate',alt:null,cat:'Electrolyte',tag:'Multi-use',desc:'Used in eclampsia, torsades, severe asthma, and hypomagnesemia.',route:'IV',onset:'Immediate',duration:'30 min – 3 hours',halflife:'Variable',calcType:'fixed',fixedDose:'Eclampsia: 4–6 g over 15–20 min; Torsades: 1–2 g over 5–10 min; Asthma: 2 g over 20 min',notes:'Monitor patellar reflexes. Have calcium gluconate ready.',contra:'Hypermagnesemia, heart block, renal failure (caution).',vitals:['sbp','hr','creatinine'],checks:[{v:'creatinine',op:'>',val:2.5,msg:'Creatinine > 2.5 — accumulation risk. Reduce dose.'}],mods:[]},
  {id:34,name:'Metoprolol',alt:'Lopressor',cat:'Beta Blocker',tag:'Cardiac',desc:'Selective beta-1 blocker for rate control in AF, SVT, and hypertension.',route:'IV / PO',onset:'5 min (IV)',duration:'3–8 hours',halflife:'3–7 hours',calcType:'fixed',fixedDose:'5 mg slow IV push q5 min × 3; max 15 mg IV total',notes:'Monitor HR and BP closely.',contra:'Bradycardia, 2nd/3rd degree AV block, decompensated HF, asthma.',vitals:['hr','sbp'],checks:[{v:'hr',op:'<',val:60,msg:'HR < 60 bpm — CONTRAINDICATED. Metoprolol will worsen bradycardia.'},{v:'sbp',op:'<',val:100,msg:'SBP < 100 mmHg — may cause dangerous hypotension.'}],mods:[]},
  {id:35,name:'Midazolam',alt:'Versed',cat:'Benzodiazepine',tag:'Sedation',desc:'Short-acting benzodiazepine for procedural sedation and RSI premedication.',route:'IV / IM / IN / PO',onset:'1–5 min (IV)',duration:'15–80 min',halflife:'1.5–2.5 hours',calcType:'weight',dosePerKg:0.05,unit:'mg',maxDose:5,maxLabel:'0.02–0.1 mg/kg IV; 0.2 mg/kg IN pediatric seizures',notes:'Intranasal route useful in pediatric seizures.',contra:'Acute narrow-angle glaucoma, respiratory depression, shock.',vitals:['weight','age','sbp','spo2'],checks:[{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — risk of cardiovascular collapse.'},{v:'spo2',op:'<',val:94,msg:'SpO₂ < 94% — secure airway before sedation.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: reduce dose by 50%.'}]},
  {id:36,name:'Morphine',alt:null,cat:'Opioid',tag:'Pain',desc:'Gold-standard opioid for severe pain and acute pulmonary edema.',route:'IV / IM / SC / PO',onset:'5 min (IV)',duration:'3–5 hours',halflife:'2–4 hours',calcType:'weight',dosePerKg:0.1,unit:'mg',maxDose:10,maxLabel:'0.1 mg/kg IV q3–4h; 2–5 mg IV titrated',notes:'Histamine release can cause hypotension.',contra:'Respiratory depression, paralytic ileus, MAOI use.',vitals:['weight','age','sbp','spo2','creatinine'],checks:[{v:'spo2',op:'<',val:94,msg:'SpO₂ < 94% — morphine may worsen respiratory compromise.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — high hypotension risk.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: start at 0.05 mg/kg.'},{v:'creatinine',op:'>',val:2,note:'Renal impairment: use fentanyl instead.'}]},
  {id:37,name:'N-Acetylcysteine',alt:'NAC',cat:'Antidote',tag:'Toxicology',desc:'Antidote for acetaminophen overdose. Replenishes glutathione.',route:'IV / PO',onset:'Immediate (IV)',duration:'21-hour protocol',halflife:'2 hours',calcType:'weight',dosePerKg:150,unit:'mg',maxDose:15000,maxLabel:'Loading: 150 mg/kg over 1h; 50 mg/kg over 4h; 100 mg/kg over 16h',notes:'Most effective within 8 hours of overdose.',contra:'Anaphylactoid reactions (slow infusion if reaction occurs).',vitals:['weight','age'],checks:[],mods:[]},
  {id:38,name:'Naloxone',alt:'Narcan',cat:'Antidote',tag:'Toxicology',desc:'Life-saving opioid reversal agent for opioid overdose.',route:'IV / IM / SC / IN',onset:'2–3 min (IV)',duration:'30–90 min',halflife:'60–90 min',calcType:'weight',dosePerKg:0.01,unit:'mg',maxDose:2,maxLabel:'0.4–2 mg IV/IM; repeat q2–3 min',notes:'Duration shorter than most opioids — repeat dosing often needed.',contra:'Hypersensitivity. Caution in opioid-dependent patients.',vitals:['weight','sbp','hr','spo2'],checks:[{v:'hr',op:'>',val:120,msg:'HR > 120 bpm — titrate slowly to avoid sympathetic surge.'},{v:'sbp',op:'<',val:80,msg:'SBP < 80 mmHg — secure airway and IV access first.'}],mods:[]},
  {id:39,name:'Nicardipine',alt:'Cardene',cat:'CCB',tag:'HTN Crisis',desc:'IV calcium channel blocker for hypertensive emergencies.',route:'IV infusion',onset:'5–15 min',duration:'4–6 hours',halflife:'8 hours',calcType:'fixed',fixedDose:'Start 5 mg/h IV; titrate by 2.5 mg/h q5–15 min; max 15 mg/h',notes:'Preferred in ischemic stroke and post-cardiac surgery.',contra:'Advanced aortic stenosis, decompensated heart failure.',vitals:['sbp','hr'],checks:[{v:'sbp',op:'<',val:100,msg:'SBP < 100 mmHg — may cause dangerous hypotension.'}],mods:[]},
  {id:40,name:'Nitroglycerin',alt:'GTN',cat:'Vasodilator',tag:'Cardiac',desc:'Vasodilator for ACS, hypertensive emergency, and pulmonary edema.',route:'SL / Spray / IV / Patch',onset:'1–3 min (SL)',duration:'20–30 min',halflife:'1–4 min',calcType:'fixed',fixedDose:'SL: 0.3–0.4 mg q5 min × 3; IV: 5–200 mcg/min infusion',notes:'Watch for hypotension. Do not use with PDE-5 inhibitors or in RV infarct.',contra:'SBP < 90 mmHg, PDE-5 inhibitor use within 24–48h, RV MI.',vitals:['sbp','hr'],checks:[{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — ABSOLUTE CONTRAINDICATION.'},{v:'hr',op:'>',val:120,msg:'HR > 120 bpm — reflex tachycardia may worsen ischemia.'}],mods:[]},
  {id:41,name:'Norepinephrine',alt:'Levophed',cat:'Vasopressor',tag:'Shock',desc:'First-line vasopressor in septic shock and distributive shock.',route:'IV infusion (central preferred)',onset:'1–2 min',duration:'1–2 min after stopping',halflife:'2.5 min',calcType:'weight',dosePerKg:0.01,unit:'mcg/kg/min',maxDose:3,maxLabel:'0.01–3 mcg/kg/min; titrate to MAP ≥ 65 mmHg',notes:'Preferred vasopressor in septic shock.',contra:'Uncorrected hypovolemia, mesenteric/peripheral vascular thrombosis.',vitals:['weight','sbp','hr'],checks:[{v:'sbp',op:'>',val:160,msg:'SBP > 160 mmHg — not hypotensive. Reassess vasopressor indication.'}],mods:[]},
  {id:42,name:'Ondansetron',alt:'Zofran',cat:'Antiemetic',tag:'GI',desc:'First-line antiemetic for nausea and vomiting in the ER.',route:'IV / IM / PO / ODT',onset:'30 min',duration:'4–8 hours',halflife:'3–6 hours',calcType:'weight',dosePerKg:0.15,unit:'mg',maxDose:8,maxLabel:'4–8 mg IV/PO adult; 0.15 mg/kg pediatric (max 8 mg)',notes:'QTc prolongation — caution with other QT-prolonging drugs.',contra:'Congenital long QT syndrome, concurrent apomorphine.',vitals:['weight','age','qtc'],checks:[{v:'qtc',op:'>',val:500,msg:'QTc > 500 ms — use metoclopramide instead.'},{v:'qtc',op:'>',val:450,msg:'QTc 450–500 ms — limit IV to 4 mg.'}],mods:[]},
  {id:43,name:'Oxytocin',alt:'Pitocin',cat:'Uterotonic',tag:'Obstetric',desc:'Stimulates uterine contraction. Used in postpartum hemorrhage.',route:'IV / IM',onset:'Immediate (IV)',duration:'1 hour',halflife:'1–6 min',calcType:'fixed',fixedDose:'10 units IM; IV: 10–40 units in 1L saline infused to effect',notes:'Rapid IV bolus causes hypotension. Always infuse slowly.',contra:'Fetal distress, abnormal fetal position (for induction).',vitals:['sbp','hr'],checks:[{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — use IM route or slow infusion.'}],mods:[]},
  {id:44,name:'Pantoprazole',alt:'Protonix',cat:'PPI',tag:'GI',desc:'Proton pump inhibitor for GI bleeds and peptic ulcer disease.',route:'IV / PO',onset:'1 hour',duration:'24 hours',halflife:'1 hour',calcType:'fixed',fixedDose:'40–80 mg IV bolus; 8 mg/h infusion for active upper GI bleed',notes:'High-dose infusion post-endoscopy for active bleeding.',contra:'Hypersensitivity to PPIs.',vitals:['sbp'],checks:[],mods:[]},
  {id:45,name:'Phenylephrine',alt:'Neo-Synephrine',cat:'Vasopressor',tag:'Shock',desc:'Pure alpha-1 agonist. Increases SVR without increasing HR.',route:'IV bolus / infusion',onset:'Immediate',duration:'15–20 min (bolus)',halflife:'2.5 hours',calcType:'weight',dosePerKg:1,unit:'mcg',maxDose:200,maxLabel:'50–200 mcg IV bolus; infusion 0.4–9.1 mcg/kg/min',notes:'Useful when tachycardia is undesirable.',contra:'Severe hypertension, severe coronary artery disease.',vitals:['weight','hr','sbp'],checks:[{v:'sbp',op:'>',val:160,msg:'SBP > 160 mmHg — not hypotensive. Reassess.'},{v:'hr',op:'<',val:55,msg:'HR < 55 bpm — phenylephrine may worsen bradycardia.'}],mods:[]},
  {id:46,name:'Potassium Chloride',alt:'KCl',cat:'Electrolyte',tag:'Metabolic',desc:'IV potassium replacement for hypokalemia.',route:'IV / PO',onset:'30–60 min',duration:'Ongoing',halflife:'Variable',calcType:'fixed',fixedDose:'10–20 mEq IV per bag over 1 hour; max 40 mEq/h via central line',notes:'NEVER give IV push — fatal arrhythmia.',contra:"Hyperkalemia, renal failure, Addison's disease.",vitals:['potassium','hr','gfr'],checks:[{v:'potassium',op:'>',val:5.0,msg:'K+ > 5.0 mEq/L — CONTRAINDICATED. Hyperkalemia present.'},{v:'gfr',op:'<',val:30,msg:'eGFR < 30 — reduce dose, monitor closely.'}],mods:[]},
  {id:47,name:'Procainamide',alt:'Pronestyl',cat:'Antiarrhythmic',tag:'Cardiac',desc:'Class IA antiarrhythmic for stable wide-complex tachycardia.',route:'IV',onset:'5–10 min',duration:'3–4 hours',halflife:'2.5–4.7 hours',calcType:'weight',dosePerKg:17,unit:'mg',maxDose:1000,maxLabel:'17 mg/kg IV at max 50 mg/min',notes:'Stop if hypotension, QRS widens > 50%, or QTc prolongation.',contra:'QTc prolongation, torsades, SLE, myasthenia gravis.',vitals:['weight','sbp','hr','qtc'],checks:[{v:'qtc',op:'>',val:500,msg:'QTc > 500 ms — procainamide contraindicated.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — procainamide is hypotensive. Contraindicated.'}],mods:[]},
  {id:48,name:'Propofol',alt:'Diprivan',cat:'Sedative-Hypnotic',tag:'RSI/Sedation',desc:'Short-acting IV anesthetic for RSI induction and procedural sedation.',route:'IV',onset:'30–45 sec',duration:'5–10 min',halflife:'30–60 min',calcType:'weight',dosePerKg:1.5,unit:'mg',maxDose:200,maxLabel:'1–2.5 mg/kg IV induction; 25–75 mcg/kg/min sedation infusion',notes:'Causes significant hypotension. Pain on injection — use large vein.',contra:'Egg or soy allergy, hemodynamic instability.',vitals:['weight','sbp','hr','age'],checks:[{v:'sbp',op:'<',val:100,msg:'SBP < 100 mmHg — high collapse risk. Use ketamine or etomidate.'},{v:'hr',op:'<',val:55,msg:'HR < 55 bpm — may worsen bradycardia. Have atropine ready.'}],mods:[{v:'age',op:'>=',val:65,note:'Elderly: reduce induction dose by 30–40%.'}]},
  {id:49,name:'Rocuronium',alt:null,cat:'NDMR Paralytic',tag:'RSI',desc:'Non-depolarizing paralytic for RSI. Fully reversible with sugammadex.',route:'IV',onset:'45–60 sec',duration:'30–60 min',halflife:'1.4–2.4 hours',calcType:'weight',dosePerKg:1.2,unit:'mg',maxDose:120,maxLabel:'1.2 mg/kg IV for RSI (max 120 mg)',notes:'Reversal: sugammadex 16 mg/kg.',contra:'Known hypersensitivity.',vitals:['weight','height','potassium'],checks:[],mods:[]},
  {id:50,name:'Sodium Bicarbonate',alt:'NaHCO3',cat:'Electrolyte',tag:'Metabolic',desc:'Treats metabolic acidosis, hyperkalemia, and TCA overdose.',route:'IV',onset:'Immediate',duration:'30–60 min',halflife:'Variable',calcType:'weight',dosePerKg:1,unit:'mEq',maxDose:100,maxLabel:'1 mEq/kg IV; TCA: boluses until QRS narrows',notes:'TCA overdose: give until QRS < 100 ms or pH > 7.55.',contra:'Metabolic alkalosis, hypocalcemia, hypernatremia.',vitals:['weight','sbp'],checks:[],mods:[]},
  {id:51,name:'Succinylcholine',alt:null,cat:'Depolarizing Paralytic',tag:'RSI',desc:'Fastest-onset paralytic for RSI. Gold standard for rapid intubation.',route:'IV / IM',onset:'30–60 sec (IV)',duration:'10–15 min',halflife:'< 1 min',calcType:'weight',dosePerKg:1.5,unit:'mg',maxDose:200,maxLabel:'1.5 mg/kg IV (max 200 mg); 4 mg/kg IM',notes:'Transient hyperkalemia — avoid in burns > 24h, crush injury.',contra:'Hyperkalemia, denervation injury, malignant hyperthermia history.',vitals:['weight','height','potassium'],checks:[{v:'potassium',op:'>',val:5.5,msg:'K+ > 5.5 mEq/L — CONTRAINDICATED. Risk of fatal cardiac arrest. Use rocuronium.'},{v:'potassium',op:'>',val:5.0,msg:'K+ 5.0–5.5 mEq/L — borderline. Strongly consider rocuronium.'}],mods:[]},
  {id:52,name:'Tenecteplase',alt:'TNKase',cat:'Thrombolytic',tag:'Stroke/STEMI',desc:'Single-bolus thrombolytic for STEMI.',route:'IV bolus',onset:'Immediate',duration:'Single dose',halflife:'20–24 min',calcType:'weight',dosePerKg:0.5,unit:'mg',maxDose:50,maxLabel:'< 60 kg → 30 mg; 60–69 → 35 mg; 70–79 → 40 mg; 80–89 → 45 mg; ≥ 90 kg → 50 mg',notes:'Given as single IV bolus over 5 sec.',contra:'Prior intracranial hemorrhage, active bleeding, recent major surgery.',vitals:['weight','sbp','age'],checks:[{v:'sbp',op:'>',val:185,msg:'SBP > 185 mmHg — CONTRAINDICATED. Lower BP first.'},{v:'age',op:'>',val:75,msg:'Age > 75 — increased intracranial hemorrhage risk.'}],mods:[]},
  {id:53,name:'Tramadol',alt:'Ultram',cat:'Opioid (weak)',tag:'Pain',desc:'Weak opioid agonist for moderate pain.',route:'IV / IM / PO',onset:'30–60 min (PO)',duration:'4–6 hours',halflife:'6–7 hours',calcType:'weight',dosePerKg:1,unit:'mg',maxDose:100,maxLabel:'50–100 mg IV/PO q4–6h; max 400 mg/day',notes:'Seizure risk at high doses or with SSRIs.',contra:'Seizure disorder, MAOI use, severe renal/hepatic impairment.',vitals:['weight','age','gfr'],checks:[],mods:[{v:'gfr',op:'<',val:30,note:'eGFR < 30: extend interval to q12h.'},{v:'age',op:'>=',val:75,note:'Age ≥ 75: max 300 mg/day.'}]},
  {id:54,name:'Tranexamic Acid',alt:'TXA',cat:'Antifibrinolytic',tag:'Bleeding',desc:'Prevents fibrin clot breakdown. Used in trauma hemorrhage and PPH.',route:'IV',onset:'Minutes',duration:'8 hours',halflife:'2 hours',calcType:'weight',dosePerKg:15,unit:'mg',maxDose:1000,maxLabel:'1 g IV over 10 min within 3 hours; then 1 g over 8 hours',notes:'CRASH-2 evidence. Most effective within 3 hours of trauma.',contra:'Active thromboembolic disease, subarachnoid hemorrhage (relative).',vitals:['weight','sbp','hr','gfr'],checks:[{v:'gfr',op:'<',val:30,msg:'eGFR < 30 — reduce dose by 50%.'}],mods:[]},
  {id:55,name:'Vancomycin',alt:null,cat:'Antibiotic',tag:'Antibiotic',desc:'Anti-MRSA antibiotic for serious gram-positive infections.',route:'IV',onset:'Immediate',duration:'12–24 hours',halflife:'4–6 hours',calcType:'weight',dosePerKg:25,unit:'mg',maxDose:3000,maxLabel:'25–30 mg/kg loading; 15–20 mg/kg q8–12h maintenance',notes:'Infuse over ≥ 60 min — rapid infusion causes Red Man Syndrome.',contra:'Hypersensitivity to vancomycin.',vitals:['weight','age','creatinine','gfr'],checks:[],mods:[{v:'gfr',op:'<',val:50,note:'eGFR < 50: extend interval to q24h.'},{v:'gfr',op:'<',val:30,note:'eGFR < 30: give loading dose then check level.'},{v:'age',op:'>=',val:65,note:'Elderly: monitor renal function every 48h.'}]},
  {id:56,name:'Vasopressin',alt:'ADH',cat:'Vasopressor',tag:'Shock',desc:'Non-catecholamine vasopressor used as adjunct in septic shock.',route:'IV infusion',onset:'Minutes',duration:'10–20 min after stopping',halflife:'10–35 min',calcType:'fixed',fixedDose:'0.03–0.04 units/min IV fixed dose (not titrated)',notes:'Fixed add-on to norepinephrine in septic shock.',contra:'Hypersensitivity; caution in CAD.',vitals:['sbp','hr'],checks:[{v:'sbp',op:'>',val:160,msg:'SBP > 160 mmHg — not hypotensive. Reassess vasopressor.'}],mods:[]},
  {id:57,name:'Verapamil',alt:'Calan',cat:'CCB',tag:'Cardiac',desc:'Calcium channel blocker for SVT rate control and PSVT termination.',route:'IV / PO',onset:'3–5 min (IV)',duration:'2–6 hours',halflife:'6–12 hours',calcType:'weight',dosePerKg:0.075,unit:'mg',maxDose:10,maxLabel:'5–10 mg IV over 2 min; repeat 10 mg after 15–30 min if needed',notes:'Avoid in WPW — can cause rapid ventricular response.',contra:'WPW syndrome, wide complex tachycardia, hypotension.',vitals:['weight','hr','sbp'],checks:[{v:'hr',op:'<',val:60,msg:'HR < 60 bpm — verapamil CONTRAINDICATED.'},{v:'sbp',op:'<',val:90,msg:'SBP < 90 mmHg — verapamil CONTRAINDICATED.'}],mods:[]},
  {id:58,name:'Vitamin K',alt:'Phytonadione',cat:'Coagulation',tag:'Bleeding',desc:'Reverses warfarin anticoagulation and vitamin K deficiency bleeding.',route:'IV / SC / PO',onset:'6–12 hours (IV)',duration:'12–24 hours',halflife:'1.5–3 hours',calcType:'fixed',fixedDose:'Urgent reversal: 5–10 mg IV slow infusion over 30 min',notes:'IV too rapidly causes anaphylaxis — infuse over minimum 30 min.',contra:'Hypersensitivity to vitamin K.',vitals:['inr','sbp'],checks:[{v:'inr',op:'<',val:2,msg:'INR < 2 — not supratherapeutic. Reassess reversal indication.'}],mods:[]},
];

// ─────────────────────────────────────────
// TAG COLOURS — new palette
// ─────────────────────────────────────────
const TAG_COLORS = {
  'Pain':        '#5d4e75',
  'Pain/RSI':    '#1B4332',
  'Cardiac':     '#8b1a1a',
  'Respiratory': '#1a4b6e',
  'Antibiotic':  '#40916C',
  'Seizure':     '#4a3728',
  'RSI':         '#1B4332',
  'RSI/Pain':    '#1B4332',
  'RSI/Sedation':'#1B4332',
  'Shock':       '#7b2d2d',
  'GI':          '#2d6a4f',
  'Metabolic':   '#52796f',
  'Toxicology':  '#6b2d6b',
  'Bleeding':    '#9b2226',
  'Obstetric':   '#6d4c7a',
  'HTN Crisis':  '#8b1a1a',
  'Anaphylaxis': '#1a4b6e',
  'Agitation':   '#4a3728',
  'Sedation':    '#1B4332',
  'Stroke/STEMI':'#8b1a1a',
  'Anti-inflam.':'#40916C',
  'Multi-use':   '#40916C',
  'Anesthetic':  '#1B4332',
  'Allergy':     '#1a4b6e',
};

const CATS = ['All','Pain','Cardiac','Respiratory','Antibiotic','Seizure',
  'RSI','Shock','GI','Metabolic','Toxicology','Bleeding','Obstetric',
  'HTN Crisis','Anaphylaxis','Agitation'];

// ─────────────────────────────────────────
// INLINE SVG ICONS (no external dependency)
// ─────────────────────────────────────────
const ICONS = {
  search:    `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  menu:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>`,
  back:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`,
  star:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  starFilled:`<svg viewBox="0 0 24 24" fill="#f5c842" stroke="#f5c842" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`,
  chevron:   `<svg class="chevron-icon" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`,
  calculator:`<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="8" y1="6" x2="16" y2="6"/><line x1="8" y1="10" x2="10" y2="10"/><line x1="12" y1="10" x2="14" y2="10"/><line x1="16" y1="10" x2="16" y2="10"/><line x1="8" y1="14" x2="10" y2="14"/><line x1="12" y1="14" x2="14" y2="14"/><line x1="16" y1="14" x2="16" y2="14"/><line x1="8" y1="18" x2="10" y2="18"/><line x1="12" y1="18" x2="16" y2="18"/></svg>`,
  shield:    `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`,
  info:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`,
  notes:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`,
  ban:       `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>`,
  alert:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
  check:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
  warn:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`,
  fn:        `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15.6 2H9a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.4"/><polyline points="13 2 13 8 19 8"/><text x="7" y="17" font-size="6" fill="#445E4F" stroke="none" font-family="monospace">f(x)</text></svg>`,
  list:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><line x1="9" y1="6" x2="20" y2="6"/><line x1="9" y1="12" x2="20" y2="12"/><line x1="9" y1="18" x2="20" y2="18"/><circle cx="4" cy="6" r="1" fill="currentColor"/><circle cx="4" cy="12" r="1" fill="currentColor"/><circle cx="4" cy="18" r="1" fill="currentColor"/></svg>`,
  clock:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  weight:    `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="7" r="4"/><path d="M6 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/></svg>`,
  heart:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>`,
  activity:  `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>`,
  lung:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M12 3v9"/><path d="M6.6 10.8c-1.5.8-2.6 2.3-2.6 4.2 0 2.4 1.8 4 4 4 1.5 0 3.2-.7 4-2"/><path d="M17.4 10.8c1.5.8 2.6 2.3 2.6 4.2 0 2.4-1.8 4-4 4-1.5 0-3.2-.7-4-2"/></svg>`,
  flask:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M9 3h6v9l5 8H4l5-8V3z"/></svg>`,
  droplet:   `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>`,
  resize:    `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>`,
  calendar:  `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
  wave:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M2 12 Q4 8 6 12 T10 12 T14 12 T18 12 T22 12"/></svg>`,
  stomach:   `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M12 3c-3 0-7 2-7 6 0 5 2 8 5 10h4c3-2 5-5 5-10 0-4-4-6-7-6z"/></svg>`,
  brain:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M9 4a3 3 0 0 0 0 6H7a3 3 0 0 0 0 6 3 3 0 0 0 2.83 4h4.34A3 3 0 0 0 17 16a3 3 0 0 0 0-6h-2a3 3 0 0 0 0-6H9z"/></svg>`,
  virus:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v4M12 18v4M2 12h4M18 12h4M4.93 4.93l2.83 2.83M16.24 16.24l2.83 2.83M19.07 4.93l-2.83 2.83M7.76 16.24l-2.83 2.83"/></svg>`,
  pill:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M10.5 20.5 3.5 13.5a5 5 0 0 1 7.07-7.07l7 7a5 5 0 0 1-7.07 7.07z"/><line x1="8.5" y1="11.5" x2="15.5" y2="11.5"/></svg>`,
  test:      `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M14.5 2v15a3.5 3.5 0 0 1-7 0V2"/><line x1="8" y1="2" x2="16" y2="2"/></svg>`,
  babycar:   `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><path d="M3 17h1m13 0h1M5 17H4l-1-6h6V7a4 4 0 0 1 8 0v4h3l-1 6H5z"/><circle cx="7.5" cy="20" r="1.5"/><circle cx="16.5" cy="20" r="1.5"/></svg>`,
  empty:     `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/></svg>`,
};

// Sidebar icon map
const SB_ICONS = {
  list: ICONS.list, star: ICONS.star, pill: ICONS.pill, heart: ICONS.heart,
  lung: ICONS.lung, virus: ICONS.virus, brain: ICONS.brain, stomach: ICONS.stomach,
  test: ICONS.test, alert: ICONS.warn, activity: ICONS.activity, droplet: ICONS.droplet,
  babycar: ICONS.babycar,
};

// ─────────────────────────────────────────
// STATE
// ─────────────────────────────────────────
let weightUnit = 'kg';
let activeTag  = 'All';
let searchQ    = '';
let currentId  = null;
let prevScreen = 'list';
let favourites = new Set();

// ─────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────
function tc(tag) { return TAG_COLORS[tag] || '#374836'; }

function grp(list) {
  const g = {};
  list.forEach(m => { const l = m.name[0]; if (!g[l]) g[l] = []; g[l].push(m); });
  return g;
}

function esc(str) {
  return String(str)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─────────────────────────────────────────
// BUILD SIDEBAR
// ─────────────────────────────────────────
function buildSidebar() {
  document.getElementById('sbScroll').innerHTML = `
    <div class="sb-title">Navigation</div>
    <div class="sb-item" onclick="closeSidebar();showTab('list');">${ICONS.list} All Medicines<span class="count-badge">${MEDS.length}</span></div>
    <div class="sb-item" onclick="closeSidebar();showTab('favs');">${ICONS.star} Favourites</div>
    <div class="sb-item" onclick="closeSidebar();showTab('recent');">${ICONS.clock} Recent</div>
    <div class="sb-sep"></div>
    <div class="sb-title">Categories</div>
    <div class="sb-item" onclick="filterCat('Pain');closeSidebar()">${ICONS.pill} Analgesics</div>
    <div class="sb-item" onclick="filterCat('Cardiac');closeSidebar()">${ICONS.heart} Cardiovascular</div>
    <div class="sb-item" onclick="filterCat('Respiratory');closeSidebar()">${ICONS.lung} Respiratory</div>
    <div class="sb-item" onclick="filterCat('Antibiotic');closeSidebar()">${ICONS.virus} Antibiotics</div>
    <div class="sb-item" onclick="filterCat('Seizure');closeSidebar()">${ICONS.brain} Neurological</div>
    <div class="sb-item" onclick="filterCat('RSI');closeSidebar()">${ICONS.activity} Sedation / RSI</div>
    <div class="sb-item" onclick="filterCat('GI');closeSidebar()">${ICONS.stomach} GI Tract</div>
    <div class="sb-item" onclick="filterCat('Metabolic');closeSidebar()">${ICONS.test} Metabolic</div>
    <div class="sb-item" onclick="filterCat('Toxicology');closeSidebar()">${ICONS.warn} Toxicology</div>
    <div class="sb-item" onclick="filterCat('Shock');closeSidebar()">${ICONS.activity} Shock / Vasopressors</div>
    <div class="sb-item" onclick="filterCat('Bleeding');closeSidebar()">${ICONS.droplet} Blood / Clotting</div>
    <div class="sb-item" onclick="filterCat('Obstetric');closeSidebar()">${ICONS.babycar} Obstetric</div>
  `;
}

// ─────────────────────────────────────────
// BUILD CATEGORY STRIP
// ─────────────────────────────────────────
function buildCats() {
  document.getElementById('catStrip').innerHTML = CATS.map(c =>
    `<button class="cat-btn${c === 'All' ? ' active' : ''}" onclick="filterCat('${esc(c)}')">${esc(c)}</button>`
  ).join('');
}

// ─────────────────────────────────────────
// FILTER & SEARCH
// ─────────────────────────────────────────
function filterCat(tag) {
  activeTag = tag;
  document.querySelectorAll('.cat-btn').forEach(b =>
    b.classList.toggle('active', b.textContent === tag)
  );
  renderList();
}

function onSearch(q) { searchQ = q; renderList(); }

function getFiltered() {
  return MEDS.filter(m => {
    const matchTag = activeTag === 'All' ||
      m.tag === activeTag ||
      m.cat.toLowerCase().includes(activeTag.toLowerCase());
    const q = searchQ.toLowerCase();
    const matchQ = !q ||
      m.name.toLowerCase().includes(q) ||
      (m.alt && m.alt.toLowerCase().includes(q)) ||
      m.cat.toLowerCase().includes(q) ||
      m.desc.toLowerCase().includes(q) ||
      m.tag.toLowerCase().includes(q);
    return matchTag && matchQ;
  });
}

// ─────────────────────────────────────────
// RENDER MEDICINE LIST
// ─────────────────────────────────────────
function renderList() {
  const el = document.getElementById('medList');
  const filtered = getFiltered();
  if (!filtered.length) {
    el.innerHTML = `<div class="empty-state">${ICONS.empty}<span>No medicines found</span></div>`;
    return;
  }
  const groups = grp(filtered);
  let html = '';
  Object.keys(groups).sort().forEach(l => {
    html += `<div class="alpha-pill">${l}</div>`;
    groups[l].forEach(m => {
      const starred = favourites.has(m.id);
      html += `<div class="med-row" onclick="openDetail(${m.id},'list')">
        <div style="flex:1;min-width:0;">
          <div class="med-name">${esc(m.name)}${m.alt ? ` <span class="med-alt">(${esc(m.alt)})</span>` : ''}</div>
          <div class="med-desc">${esc(m.desc)}</div>
        </div>
        <div class="med-row-right">
          <span class="med-tag" style="background:${tc(m.tag)}">${esc(m.tag)}</span>
          <div class="med-row-icons">
            ${starred ? `<svg class="star-sm" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="#f5c842" stroke="#f5c842" stroke-width="2"/></svg>` : ''}
            ${ICONS.chevron}
          </div>
        </div>
      </div>`;
    });
  });
  el.innerHTML = html;
}

// ─────────────────────────────────────────
// RENDER FAVOURITES
// ─────────────────────────────────────────
function renderFavs() {
  const el = document.getElementById('favList');
  const fm = MEDS.filter(m => favourites.has(m.id));
  if (!fm.length) {
    el.innerHTML = `<div class="fav-empty">
      <svg viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="#f5c842" stroke="#f5c842" stroke-width="2"/></svg>
      <p>No favourites yet.<br><br>Open any medicine and tap the ★ star to save it here.</p>
    </div>`;
    return;
  }
  let html = '';
  fm.sort((a, b) => a.name.localeCompare(b.name)).forEach(m => {
    html += `<div class="med-row" onclick="openDetail(${m.id},'favs')">
      <div style="flex:1;min-width:0;">
        <div class="med-name">${esc(m.name)}${m.alt ? ` <span class="med-alt">(${esc(m.alt)})</span>` : ''}</div>
        <div class="med-desc">${esc(m.desc)}</div>
      </div>
      <div class="med-row-right">
        <span class="med-tag" style="background:${tc(m.tag)}">${esc(m.tag)}</span>
        <svg class="star-sm" viewBox="0 0 24 24"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="#f5c842" stroke="#f5c842" stroke-width="2"/></svg>
      </div>
    </div>`;
  });
  el.innerHTML = html;
}

// ─────────────────────────────────────────
// TAB NAVIGATION
// ─────────────────────────────────────────
function showTab(tab) {
  document.getElementById('screenDetail').className = 'screen ahead';
  if (tab === 'list') {
    document.getElementById('screenList').className  = 'screen current';
    document.getElementById('screenFavs').className  = 'screen ahead';
    document.getElementById('tabDir').classList.add('active');
    document.getElementById('tabFav').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
  } else {
    renderFavs();
    document.getElementById('screenFavs').className  = 'screen current';
    document.getElementById('screenList').className  = 'screen behind';
    document.getElementById('tabFav').classList.add('active');
    document.getElementById('tabDir').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
  }
}

// ─────────────────────────────────────────
// OPEN MEDICINE DETAIL
// ─────────────────────────────────────────
function openDetail(id, from) {
  const m = MEDS.find(x => x.id === id);
  if (!m) return;
  currentId  = id;
  prevScreen = from || 'list';

  document.getElementById('dName').textContent  = m.name + (m.alt ? ` (${m.alt})` : '');
  document.getElementById('dClass').textContent = m.cat;
  const tg = document.getElementById('dTag');
  tg.textContent   = m.tag;
  tg.style.background = tc(m.tag);

  updateStarBtn();

  const vitalsHTML  = buildVitalsHTML(m);
  const calcSection = m.calcType === 'weight'
    ? `<div class="calc-card">
        <div class="icard-title">${ICONS.calculator} Dosage Calculator &amp; Safety Checks</div>
        <div class="warn-box">${ICONS.warn} Clinical guidance only. Always verify with current protocols.</div>
        <div class="legend">
          <div class="legend-item"><div class="legend-dot" style="background:#2471a3;"></div>Dose input</div>
          <div class="legend-item"><div class="legend-dot" style="background:#c0392b;"></div>Safety check</div>
        </div>
        ${vitalsHTML}
        <button class="calc-btn" onclick="calculate(${id})">${ICONS.fn} Calculate Dose &amp; Check Safety</button>
        <div class="result-box" id="rBox">
          <div class="result-main">
            <div class="result-lbl">Recommended Dose</div>
            <div class="result-val" id="rVal">—</div>
            <div class="result-note" id="rNote"></div>
          </div>
          <div id="rAlerts"></div>
        </div>
      </div>`
    : `<div class="calc-card">
        <div class="icard-title">${ICONS.shield} Safety Checks &amp; Standard Dosing</div>
        <div class="warn-box">${ICONS.warn} Clinical guidance only. Always verify with current protocols.</div>
        ${vitalsHTML}
        <button class="calc-btn" onclick="checkSafety(${id})">${ICONS.shield} Run Safety Check</button>
        <div class="std-dose-box">
          <div class="std-dose-lbl">Standard Dose</div>
          <div class="std-dose-val">${esc(m.fixedDose)}</div>
        </div>
        <div id="rAlerts" style="margin-top:8px;"></div>
      </div>`;

  document.getElementById('dBody').innerHTML = `
    <div class="icard">
      <div class="icard-title">${ICONS.info} Drug Information</div>
      <div class="irow"><span class="irow-lbl">Route</span><span class="irow-val">${esc(m.route)}</span></div>
      <div class="irow"><span class="irow-lbl">Onset</span><span class="irow-val">${esc(m.onset)}</span></div>
      <div class="irow"><span class="irow-lbl">Duration</span><span class="irow-val">${esc(m.duration)}</span></div>
      <div class="irow"><span class="irow-lbl">Half-life</span><span class="irow-val">${esc(m.halflife)}</span></div>
      <div class="irow"><span class="irow-lbl">Max dose</span><span class="irow-val">${esc(m.maxLabel || m.fixedDose || '—')}</span></div>
    </div>
    ${calcSection}
    <div class="icard">
      <div class="icard-title">${ICONS.notes} Clinical Notes</div>
      <div class="notes-text">${esc(m.notes)}</div>
    </div>
    <div class="icard">
      <div class="icard-title">${ICONS.ban} Contraindications</div>
      <div class="contra-text">${esc(m.contra)}</div>
    </div>
    <div class="detail-spacer"></div>`;

  if (prevScreen === 'favs') {
    document.getElementById('screenFavs').className = 'screen behind';
  } else {
    document.getElementById('screenList').className = 'screen behind';
  }
  document.getElementById('screenDetail').className = 'screen current';
  document.getElementById('dBody').scrollTop = 0;
  weightUnit = 'kg';
}

// ─────────────────────────────────────────
// GO BACK
// ─────────────────────────────────────────
function goBack() {
  document.getElementById('screenDetail').className = 'screen ahead';
  if (prevScreen === 'favs') {
    document.getElementById('screenFavs').className = 'screen current';
    document.getElementById('screenList').className = 'screen behind';
    document.getElementById('tabFav').classList.add('active');
    document.getElementById('tabDir').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
    renderFavs();
  } else {
    document.getElementById('screenList').className = 'screen current';
    document.getElementById('screenFavs').className = 'screen ahead';
    document.getElementById('tabDir').classList.add('active');
    document.getElementById('tabFav').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
    renderList();
  }
}

// ─────────────────────────────────────────
// FAVOURITES TOGGLE
// ─────────────────────────────────────────
function toggleFav() {
  if (currentId === null) return;
  if (favourites.has(currentId)) favourites.delete(currentId);
  else favourites.add(currentId);
  updateStarBtn();
  updateFavCount();
  renderList();
}

function updateStarBtn() {
  const btn = document.getElementById('starBtn');
  const starred = favourites.has(currentId);
  btn.className = 'star-btn' + (starred ? ' active' : '');
  btn.innerHTML = starred ? ICONS.starFilled : ICONS.star;
}

function updateFavCount() {
  const c = document.getElementById('favCount');
  if (favourites.size > 0) {
    c.textContent = favourites.size;
    c.classList.add('show');
  } else {
    c.classList.remove('show');
  }
}

// ─────────────────────────────────────────
// BUILD VITALS INPUT HTML
// ─────────────────────────────────────────
function buildVitalsHTML(m) {
  const needs = m.vitals || ['weight'];
  const doseF   = [];
  const safetyF = [];
  needs.forEach(v => {
    if (['weight','height','age','creatinine','gfr'].includes(v)) doseF.push(v);
    else safetyF.push(v);
  });

  const labels = {
    weight:'Patient Weight', height:'Height', age:'Age',
    sbp:'Blood Pressure', hr:'Heart Rate', spo2:'SpO₂',
    creatinine:'Serum Creatinine', glucose:'Blood Glucose',
    potassium:'Serum K+', qtc:'QTc Interval', inr:'INR', gfr:'eGFR',
  };
  const units = {
    height:'cm', age:'yrs', hr:'bpm', spo2:'%',
    creatinine:'mg/dL', glucose:'mg/dL', potassium:'mEq/L',
    qtc:'ms', gfr:'mL/min',
  };
  const placeholders = {
    height:'e.g. 170', age:'e.g. 45', hr:'e.g. 72', spo2:'e.g. 95',
    creatinine:'e.g. 1.1', glucose:'e.g. 100', potassium:'e.g. 4.0',
    qtc:'e.g. 440', inr:'e.g. 1.2', gfr:'e.g. 90',
  };
  const icons = {
    weight:ICONS.weight, height:ICONS.resize, age:ICONS.calendar,
    sbp:ICONS.heart, hr:ICONS.activity, spo2:ICONS.lung,
    creatinine:ICONS.flask, glucose:ICONS.droplet, potassium:ICONS.flask,
    qtc:ICONS.wave, inr:ICONS.droplet, gfr:ICONS.flask,
  };

  function fieldHTML(vk) {
    const isDose  = doseF.includes(vk);
    const badge   = `<span class="badge ${isDose ? 'dose' : 'safety'}">${isDose ? 'Dose' : 'Safety'}</span>`;
    const icon    = icons[vk] || ICONS.activity;

    if (vk === 'weight') {
      return `<div class="field-group">
        <div class="field-label">${icon}Patient Weight ${badge}</div>
        <div class="weight-row">
          <input type="number" id="v_weight" placeholder="e.g. 70" min="1" max="300" inputmode="decimal"/>
          <div class="unit-toggle">
            <button class="unit-btn active" id="btnKg" onclick="setUnit('kg')">kg</button>
            <button class="unit-btn" id="btnLbs" onclick="setUnit('lbs')">lbs</button>
          </div>
        </div>
      </div>`;
    }

    if (vk === 'sbp') {
      return `<div class="field-group">
        <div class="field-label">${icon}Blood Pressure ${badge}</div>
        <div class="bp-row">
          <input type="number" id="v_sbp" placeholder="Systolic" min="40" max="300" inputmode="numeric"/>
          <span class="bp-sep">/</span>
          <input type="number" id="v_dbp" placeholder="Diastolic" min="20" max="200" inputmode="numeric"/>
          <span class="bp-unit">mmHg</span>
        </div>
      </div>`;
    }

    return `<div class="field-group">
      <div class="field-label">${icon}${labels[vk] || vk} ${badge}</div>
      <div class="input-with-unit">
        <input type="number" class="full-input" id="v_${vk}" placeholder="${placeholders[vk] || ''}" inputmode="decimal"/>
        ${units[vk] ? `<span class="input-unit">${units[vk]}</span>` : ''}
      </div>
    </div>`;
  }

  let html = '';
  if (doseF.length) {
    html += `<div class="vitals-divider">${ICONS.calculator} Dose Calculation Inputs</div>`;
    doseF.forEach(v => { html += fieldHTML(v); });
  }
  if (safetyF.length) {
    html += `<div class="vitals-divider">${ICONS.shield} Safety Check Inputs</div>`;
    safetyF.forEach(v => { html += fieldHTML(v); });
  }
  return html;
}

// ─────────────────────────────────────────
// UNIT TOGGLE (stays active)
// ─────────────────────────────────────────
function setUnit(u) {
  weightUnit = u;
  const kg  = document.getElementById('btnKg');
  const lbs = document.getElementById('btnLbs');
  if (!kg || !lbs) return;
  if (u === 'kg') {
    kg.classList.add('active');    lbs.classList.remove('active');
    kg.style.cssText  = 'background:#374836!important;color:#FBFCF4!important;';
    lbs.style.cssText = '';
  } else {
    lbs.classList.add('active');   kg.classList.remove('active');
    lbs.style.cssText = 'background:#374836!important;color:#FBFCF4!important;';
    kg.style.cssText  = '';
  }
}

// ─────────────────────────────────────────
// READ VITALS FROM INPUTS
// ─────────────────────────────────────────
function getVitals(m) {
  const v = {};
  (m.vitals || []).forEach(vk => {
    if (vk === 'weight') {
      const r = parseFloat(document.getElementById('v_weight')?.value);
      if (!isNaN(r)) v.weight = weightUnit === 'lbs' ? r * 0.453592 : r;
    } else if (vk === 'sbp') {
      const s = parseFloat(document.getElementById('v_sbp')?.value);
      if (!isNaN(s)) v.sbp = s;
    } else {
      const val = parseFloat(document.getElementById('v_' + vk)?.value);
      if (!isNaN(val)) v[vk] = val;
    }
  });
  return v;
}

// ─────────────────────────────────────────
// SAFETY CHECKS
// ─────────────────────────────────────────
function runChecks(m, v) {
  return (m.checks || []).filter(c => {
    const val = v[c.v];
    if (val === undefined) return false;
    if (c.op === '>')  return val > c.val;
    if (c.op === '<')  return val < c.val;
    if (c.op === '>=') return val >= c.val;
    if (c.op === '<=') return val <= c.val;
    return false;
  }).map(c => c.msg);
}

function renderAlerts(warnings, container) {
  if (!warnings.length) {
    container.innerHTML = `<div class="safety-ok">${ICONS.check} No safety concerns detected with entered vitals.</div>`;
  } else {
    container.innerHTML = `<div class="safety-alerts">
      ${warnings.map(w => `<div class="safety-alert">${ICONS.alert}<span>${esc(w)}</span></div>`).join('')}
    </div>`;
  }
}

// ─────────────────────────────────────────
// CALCULATE DOSE
// ─────────────────────────────────────────
function calculate(id) {
  const m      = MEDS.find(x => x.id === id);
  const v      = getVitals(m);
  const rBox   = document.getElementById('rBox');
  const rVal   = document.getElementById('rVal');
  const rNote  = document.getElementById('rNote');
  const rAlerts = document.getElementById('rAlerts');

  if (!v.weight) {
    rBox.classList.add('show');
    rVal.textContent  = 'Enter weight';
    rNote.textContent = 'Patient weight is required to calculate dose.';
    rAlerts.innerHTML = '';
    return;
  }

  let dose   = v.weight * m.dosePerKg;
  let capped = false;
  if (m.maxDose && dose > m.maxDose) { dose = m.maxDose; capped = true; }

  const notes = [];
  if (capped) notes.push(`Capped at maximum — ${m.maxLabel}.`);

  (m.mods || []).forEach(mod => {
    const val = v[mod.v];
    if (val === undefined) return;
    let match = false;
    if (mod.op === '>=') match = val >= mod.val;
    else if (mod.op === '>') match = val > mod.val;
    else if (mod.op === '<') match = val < mod.val;
    else if (mod.op === '<=') match = val <= mod.val;
    if (match) notes.push(mod.note);
  });

  let doseStr = '';
  if      (m.unit === 'mcg/kg/min') doseStr = (v.weight * m.dosePerKg).toFixed(3) + ' mcg/kg/min';
  else if (m.unit === 'mcg')        doseStr = Math.round(dose) + ' mcg';
  else if (m.unit === 'units')      doseStr = Math.round(dose) + ' units';
  else if (m.unit === 'mEq')        doseStr = Math.round(dose) + ' mEq';
  else if (m.unit === 'g')          doseStr = dose.toFixed(1) + ' g';
  else                              doseStr = Math.round(dose) + ' mg';

  const warnings = runChecks(m, v);
  rBox.classList.add('show');
  rVal.textContent  = doseStr;
  rNote.textContent = notes.join(' ');
  renderAlerts(warnings, rAlerts);
}

function checkSafety(id) {
  const m = MEDS.find(x => x.id === id);
  const v = getVitals(m);
  renderAlerts(runChecks(m, v), document.getElementById('rAlerts'));
}

// ─────────────────────────────────────────
// SIDEBAR
// ─────────────────────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('overlay').classList.toggle('open');
}

function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('open');
}

// ─────────────────────────────────────────
// RECENT HISTORY
// Max 20 entries, most recent first, no duplicates
// ─────────────────────────────────────────
let recentIds = [];

function addToRecent(id) {
  recentIds = recentIds.filter(x => x !== id);
  recentIds.unshift(id);
  if (recentIds.length > 20) recentIds = recentIds.slice(0, 20);
}

function renderRecent() {
  const el = document.getElementById('favList'); // reuses the list body slot in screenFavs
  const recentMeds = recentIds.map(id => MEDS.find(m => m.id === id)).filter(Boolean);

  if (!recentMeds.length) {
    el.innerHTML = `<div class="fav-empty">
      <svg viewBox="0 0 24 24" width="48" height="48"><circle cx="12" cy="12" r="10" fill="none" stroke="#f5c842" stroke-width="2"/><polyline points="12 6 12 12 16 14" fill="none" stroke="#f5c842" stroke-width="2" stroke-linecap="round"/></svg>
      <p>No recent medicines yet.<br><br>Medicines you open will appear here.</p>
    </div>`;
    return;
  }

  let html = '';
  recentMeds.forEach((m, i) => {
    html += `<div class="med-row" onclick="openDetail(${m.id},'recent')">
      <div style="flex:1;min-width:0;">
        <div class="med-name">${esc(m.name)}${m.alt ? ` <span class="med-alt">(${esc(m.alt)})</span>` : ''}</div>
        <div class="med-desc">${esc(m.desc)}</div>
      </div>
      <div class="med-row-right">
        <span class="med-tag" style="background:${tc(m.tag)}">${esc(m.tag)}</span>
        <div class="med-row-icons" style="font-size:10px;color:var(--muted);">
          ${i === 0 ? '<span style="font-size:10px;color:#6b7c6a;">just now</span>' : ''}
          ${ICONS.chevron}
        </div>
      </div>
    </div>`;
  });
  el.innerHTML = html;
}

// ─────────────────────────────────────────
// HARDWARE BACK BUTTON (Android)
// Uses the History API to intercept the back gesture
// ─────────────────────────────────────────
function pushNavState(state) {
  history.pushState(state, '');
}

function handleBackButton() {
  // If sidebar is open, close it first
  if (document.getElementById('sidebar').classList.contains('open')) {
    closeSidebar();
    pushNavState({ screen: getCurrentScreen() });
    return;
  }

  // If on detail screen, go back to previous screen
  const detailScreen = document.getElementById('screenDetail');
  if (detailScreen.classList.contains('current')) {
    goBack();
    // Don't push state here — goBack already moved us back
    return;
  }

  // If on favs or recent screen, go back to directory
  const favsScreen = document.getElementById('screenFavs');
  if (favsScreen.classList.contains('current')) {
    showTab('list');
    return;
  }

  // Already on the list (home) — let the app close naturally
  // by going back one more time in history (exits app)
  history.go(-1);
}

function getCurrentScreen() {
  if (document.getElementById('screenDetail').classList.contains('current')) return 'detail';
  if (document.getElementById('screenFavs').classList.contains('current')) return 'secondary';
  return 'list';
}

// ─────────────────────────────────────────
// UPDATED showTab — handles recent tab too
// ─────────────────────────────────────────
const _origShowTab = showTab;
// Override showTab to handle the 'recent' tab properly
function showTab(tab) {
  document.getElementById('screenDetail').className = 'screen ahead';

  if (tab === 'list') {
    document.getElementById('screenList').className  = 'screen current';
    document.getElementById('screenFavs').className  = 'screen ahead';
    document.getElementById('tabDir').classList.add('active');
    document.getElementById('tabFav').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
  } else if (tab === 'favs') {
    renderFavs();
    document.getElementById('screenFavs').className  = 'screen current';
    document.getElementById('screenList').className  = 'screen behind';
    document.getElementById('tabFav').classList.add('active');
    document.getElementById('tabDir').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
    // Update header to show Favourites
    document.querySelector('.favs-title').innerHTML = `
      <svg viewBox="0 0 24 24" width="20" height="20">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
          fill="#f5c842" stroke="#f5c842" stroke-width="2"/>
      </svg>
      Favourites`;
    document.querySelector('.favs-sub').textContent = 'Medicines you\'ve starred';
  } else if (tab === 'recent') {
    renderRecent();
    document.getElementById('screenFavs').className  = 'screen current';
    document.getElementById('screenList').className  = 'screen behind';
    document.getElementById('tabRec').classList.add('active');
    document.getElementById('tabDir').classList.remove('active');
    document.getElementById('tabFav').classList.remove('active');
    // Update header to show Recent
    document.querySelector('.favs-title').innerHTML = `
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#f5c842" stroke-width="2" stroke-linecap="round">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>
      Recent`;
    document.querySelector('.favs-sub').textContent = 'Recently viewed medicines';
  }

  pushNavState({ screen: tab });
}

// ─────────────────────────────────────────
// UPDATED openDetail — tracks recent
// ─────────────────────────────────────────
const _origOpenDetail = openDetail;
function openDetail(id, from) {
  const m = MEDS.find(x => x.id === id);
  if (!m) return;
  currentId  = id;
  prevScreen = from || 'list';

  // Track in recent history
  addToRecent(id);

  document.getElementById('dName').textContent  = m.name + (m.alt ? ` (${m.alt})` : '');
  document.getElementById('dClass').textContent = m.cat;
  const tg = document.getElementById('dTag');
  tg.textContent      = m.tag;
  tg.style.background = tc(m.tag);

  updateStarBtn();

  const vitalsHTML  = buildVitalsHTML(m);
  const calcSection = m.calcType === 'weight'
    ? `<div class="calc-card">
        <div class="icard-title">${ICONS.calculator} Dosage Calculator &amp; Safety Checks</div>
        <div class="warn-box">${ICONS.warn} Clinical guidance only. Always verify with current protocols.</div>
        <div class="legend">
          <div class="legend-item"><div class="legend-dot" style="background:#2471a3;"></div>Dose input</div>
          <div class="legend-item"><div class="legend-dot" style="background:#c0392b;"></div>Safety check</div>
        </div>
        ${vitalsHTML}
        <button class="calc-btn" onclick="calculate(${id})">${ICONS.fn} Calculate Dose &amp; Check Safety</button>
        <div class="result-box" id="rBox">
          <div class="result-main">
            <div class="result-lbl">Recommended Dose</div>
            <div class="result-val" id="rVal">—</div>
            <div class="result-note" id="rNote"></div>
          </div>
          <div id="rAlerts"></div>
        </div>
      </div>`
    : `<div class="calc-card">
        <div class="icard-title">${ICONS.shield} Safety Checks &amp; Standard Dosing</div>
        <div class="warn-box">${ICONS.warn} Clinical guidance only. Always verify with current protocols.</div>
        ${vitalsHTML}
        <button class="calc-btn" onclick="checkSafety(${id})">${ICONS.shield} Run Safety Check</button>
        <div class="std-dose-box">
          <div class="std-dose-lbl">Standard Dose</div>
          <div class="std-dose-val">${esc(m.fixedDose)}</div>
        </div>
        <div id="rAlerts" style="margin-top:8px;"></div>
      </div>`;

  document.getElementById('dBody').innerHTML = `
    <div class="icard">
      <div class="icard-title">${ICONS.info} Drug Information</div>
      <div class="irow"><span class="irow-lbl">Route</span><span class="irow-val">${esc(m.route)}</span></div>
      <div class="irow"><span class="irow-lbl">Onset</span><span class="irow-val">${esc(m.onset)}</span></div>
      <div class="irow"><span class="irow-lbl">Duration</span><span class="irow-val">${esc(m.duration)}</span></div>
      <div class="irow"><span class="irow-lbl">Half-life</span><span class="irow-val">${esc(m.halflife)}</span></div>
      <div class="irow"><span class="irow-lbl">Max dose</span><span class="irow-val">${esc(m.maxLabel || m.fixedDose || '—')}</span></div>
    </div>
    ${calcSection}
    <div class="icard">
      <div class="icard-title">${ICONS.notes} Clinical Notes</div>
      <div class="notes-text">${esc(m.notes)}</div>
    </div>
    <div class="icard">
      <div class="icard-title">${ICONS.ban} Contraindications</div>
      <div class="contra-text">${esc(m.contra)}</div>
    </div>
    <div class="detail-spacer"></div>`;

  // Handle which screen to push behind
  if (prevScreen === 'favs' || prevScreen === 'recent') {
    document.getElementById('screenFavs').className = 'screen behind';
  } else {
    document.getElementById('screenList').className = 'screen behind';
  }
  document.getElementById('screenDetail').className = 'screen current';
  document.getElementById('dBody').scrollTop = 0;
  weightUnit = 'kg';

  pushNavState({ screen: 'detail', id });
}

// ─────────────────────────────────────────
// UPDATED goBack — handles recent origin
// ─────────────────────────────────────────
function goBack() {
  document.getElementById('screenDetail').className = 'screen ahead';

  if (prevScreen === 'favs') {
    document.getElementById('screenFavs').className = 'screen current';
    document.getElementById('screenList').className = 'screen behind';
    document.getElementById('tabFav').classList.add('active');
    document.getElementById('tabDir').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
    document.querySelector('.favs-title').innerHTML = `
      <svg viewBox="0 0 24 24" width="20" height="20">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
          fill="#f5c842" stroke="#f5c842" stroke-width="2"/>
      </svg>Favourites`;
    document.querySelector('.favs-sub').textContent = 'Medicines you\'ve starred';
    renderFavs();
  } else if (prevScreen === 'recent') {
    document.getElementById('screenFavs').className = 'screen current';
    document.getElementById('screenList').className = 'screen behind';
    document.getElementById('tabRec').classList.add('active');
    document.getElementById('tabDir').classList.remove('active');
    document.getElementById('tabFav').classList.remove('active');
    document.querySelector('.favs-title').innerHTML = `
      <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#f5c842" stroke-width="2" stroke-linecap="round">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>Recent`;
    document.querySelector('.favs-sub').textContent = 'Recently viewed medicines';
    renderRecent();
  } else {
    document.getElementById('screenList').className = 'screen current';
    document.getElementById('screenFavs').className = 'screen ahead';
    document.getElementById('tabDir').classList.add('active');
    document.getElementById('tabFav').classList.remove('active');
    document.getElementById('tabRec').classList.remove('active');
    renderList();
  }
}

// ─────────────────────────────────────────
// SETTINGS SCREEN
// ─────────────────────────────────────────
let settingsPrevScreen = 'list';

function openSettings() {
  settingsPrevScreen = getCurrentScreen();
  // push all current screens behind
  document.getElementById('screenList').className    = 'screen behind';
  document.getElementById('screenFavs').className    = 'screen behind';
  document.getElementById('screenDetail').className  = 'screen behind';
  document.getElementById('screenSettings').className = 'screen current';
  pushNavState({ screen: 'settings' });
}

function closeSettings() {
  document.getElementById('screenSettings').className = 'screen ahead';
  // restore whichever screen was showing
  if (settingsPrevScreen === 'detail') {
    document.getElementById('screenDetail').className = 'screen current';
  } else if (settingsPrevScreen === 'secondary') {
    document.getElementById('screenFavs').className = 'screen current';
    document.getElementById('screenList').className = 'screen behind';
  } else {
    document.getElementById('screenList').className = 'screen current';
    document.getElementById('screenFavs').className = 'screen ahead';
    document.getElementById('screenDetail').className = 'screen ahead';
  }
}

function saveSetting(key, value) {
  try { localStorage.setItem('ermed_' + key, JSON.stringify(value)); } catch(e) {}
}

function loadSetting(key, def) {
  try {
    const v = localStorage.getItem('ermed_' + key);
    return v !== null ? JSON.parse(v) : def;
  } catch(e) { return def; }
}

function clearRecent() {
  recentIds = [];
  if (confirm('Clear all recent history?')) {
    recentIds = [];
    try { localStorage.removeItem('ermed_recent'); } catch(e) {}
    renderRecent();
  }
}

function clearFavourites() {
  if (confirm('Clear all favourites?')) {
    favourites = new Set();
    updateFavCount();
    renderList();
    renderFavs();
  }
}

function setDefaultUnit(u) {
  weightUnit = u;
  saveSetting('defaultUnit', u);
  document.getElementById('setKg').style.cssText  = u === 'kg'
    ? 'padding:6px 14px;font-size:13px;font-weight:700;font-family:inherit;border:none;cursor:pointer;background:var(--dark);color:#fff;'
    : 'padding:6px 14px;font-size:13px;font-weight:700;font-family:inherit;border:none;cursor:pointer;background:var(--input-bg);color:var(--text-2);';
  document.getElementById('setLbs').style.cssText = u === 'lbs'
    ? 'padding:6px 14px;font-size:13px;font-weight:700;font-family:inherit;border:none;cursor:pointer;background:var(--dark);color:#fff;'
    : 'padding:6px 14px;font-size:13px;font-weight:700;font-family:inherit;border:none;cursor:pointer;background:var(--input-bg);color:var(--text-2);';
}

// ─────────────────────────────────────────
// THEME / DARK MODE
// ─────────────────────────────────────────
function applyTheme(theme) {
  const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  const useDark = theme === 'dark' || (theme === 'auto' && prefersDark);
  document.documentElement.setAttribute('data-theme', useDark ? 'dark' : 'light');

  // Update mode buttons
  ['modeLight','modeDark','modeAuto'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.classList.remove('active');
  });
  const activeId = theme === 'dark' ? 'modeDark' : theme === 'auto' ? 'modeAuto' : 'modeLight';
  const activeEl = document.getElementById(activeId);
  if (activeEl) activeEl.classList.add('active');

  // Update meta theme-color
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = useDark ? '#0d2218' : '#1B4332';
}

function setTheme(theme) {
  saveSetting('theme', theme);
  applyTheme(theme);
}

// ─────────────────────────────────────────
// UPDATED handleBackButton — includes settings
// ─────────────────────────────────────────
function handleBackButton() {
  if (document.getElementById('sidebar').classList.contains('open')) {
    closeSidebar();
    pushNavState({ screen: getCurrentScreen() });
    return;
  }
  if (document.getElementById('screenSettings').classList.contains('current')) {
    closeSettings();
    return;
  }
  if (document.getElementById('screenDetail').classList.contains('current')) {
    goBack();
    return;
  }
  if (document.getElementById('screenFavs').classList.contains('current')) {
    showTab('list');
    return;
  }
  history.go(-1);
}

function getCurrentScreen() {
  if (document.getElementById('screenSettings').classList.contains('current')) return 'settings';
  if (document.getElementById('screenDetail').classList.contains('current'))  return 'detail';
  if (document.getElementById('screenFavs').classList.contains('current'))    return 'secondary';
  return 'list';
}

// ─────────────────────────────────────────
// INIT
// ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  buildSidebar();
  buildCats();
  renderList();

  // Restore saved theme
  const savedTheme = loadSetting('theme', 'light');
  applyTheme(savedTheme);

  // Restore saved default weight unit
  const savedUnit = loadSetting('defaultUnit', 'kg');
  weightUnit = savedUnit;
  setDefaultUnit(savedUnit);

  // Seed history
  history.replaceState({ screen: 'list' }, '');
  history.pushState({ screen: 'list' }, '');

  // System dark mode change listener (for auto mode)
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    const theme = loadSetting('theme', 'light');
    if (theme === 'auto') applyTheme('auto');
  });

  // Hardware back button
  window.addEventListener('popstate', () => {
    handleBackButton();
    history.pushState({ screen: getCurrentScreen() }, '');
  });
});
