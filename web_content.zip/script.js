const profiles = {
  balanced:    "সমতুল্য মোড: ব্যাটারি ও পারফরম্যান্স মাঝামাঝি।",
  performance: "পারফরম্যান্স মোড: বেশি ফ্রেম, বেশি ব্যাটারি খরচ।",
  battery:     "ব্যাটারি মোড: কম ফ্রেম, বেশি সময় চার্জ থাকবে।"
};

const body = document.body;
document.getElementById("themeSelect").addEventListener("change", e => {
  body.setAttribute("data-theme", e.target.value);
});

const TOTAL = 3072;
let ramFree = 1100;
const ramNum = document.getElementById("ramNum");
const ramBar = document.getElementById("ramBar");
function renderRam() {
  ramNum.textContent = ramFree;
  ramBar.style.width = Math.round((1 - ramFree / TOTAL) * 100) + "%";
}
document.getElementById("ramBtn").addEventListener("click", () => {
  ramFree = Math.min(ramFree + 150, 2000);
  renderRam();
});
renderRam();

const profileText = document.getElementById("profileText");
document.querySelectorAll(".mode").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".mode").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    profileText.textContent = profiles[btn.dataset.mode];
  });
});
profileText.textContent = profiles.balanced;

const fpsNum = document.getElementById("fpsNum");
setInterval(() => {
  fpsNum.textContent = 25 + Math.floor(Math.random() * 20);
}, 1000);

const bars = document.querySelectorAll("#wave i");
const pitchText = document.getElementById("pitchText");
let pitch = 1.0;
function animateWave() {
  bars.forEach(b => {
    const h = 15 + Math.random() * 85 * (pitch > 1 ? 1 : 0.6);
    b.style.height = h + "%";
  });
}
setInterval(animateWave, 160);

document.querySelectorAll(".preset").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".preset").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    pitch = parseFloat(btn.dataset.pitch);
    pitchText.textContent = pitch.toFixed(2);
  });
});