(function(){
  const buttons=[...document.querySelectorAll('.nav-btn')];
  const screens=[...document.querySelectorAll('.screen')];
  const flipper=document.getElementById('flipper');
  const stage=document.getElementById('cardStage');
  let flipped=false,startX=0,startY=0,moved=false;

  function show(name){
    screens.forEach(screen=>{
      const active=screen.id===name;
      screen.classList.toggle('active',active);
      if(active) screen.scrollTop=0;
    });
    buttons.forEach(button=>button.classList.toggle('active',button.dataset.screen===name));
  }

  buttons.forEach(button=>button.addEventListener('click',()=>show(button.dataset.screen)));

  function flip(){
    flipped=!flipped;
    flipper.classList.toggle('flipped',flipped);
  }

  stage.addEventListener('click',()=>{
    if(!moved) flip();
    moved=false;
  });

  stage.addEventListener('touchstart',event=>{
    const touch=event.changedTouches[0];
    startX=touch.clientX;
    startY=touch.clientY;
    moved=false;
  },{passive:true});

  stage.addEventListener('touchmove',event=>{
    const touch=event.changedTouches[0];
    if(Math.abs(touch.clientX-startX)>12 || Math.abs(touch.clientY-startY)>12) moved=true;
  },{passive:true});

  stage.addEventListener('touchend',event=>{
    const touch=event.changedTouches[0];
    const dx=touch.clientX-startX;
    const dy=touch.clientY-startY;
    if(Math.abs(dx)>55 && Math.abs(dx)>Math.abs(dy)) flip();
    moved=true;
  },{passive:true});
})();
