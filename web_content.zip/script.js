const KEY='waisSarafiComplete',BACKUP='waisSarafiCompleteAutoBackup';
let data=JSON.parse(localStorage.getItem(KEY)||'null')||JSON.parse(localStorage.getItem(BACKUP)||'null')||[];
let editId=null;
const $=id=>document.getElementById(id);
const n=id=>Number($(id).value)||0;
const now=new Date();
$('date').value=now.toISOString().slice(0,10);
$('time').value=now.toTimeString().slice(0,5);

['bigMoney','fifty','twenty','ten'].forEach(id=>$(id).oninput=live);

function small(){return n('fifty')+n('twenty')+n('ten')}
function info(diff){
 if(diff>0)return ['وړې پیسې زیاتې دي: '+diff.toLocaleString()+' افغانۍ','smallmore'];
 if(diff<0)return ['غټې پیسې زیاتې دي: '+Math.abs(diff).toLocaleString()+' افغانۍ','bigmore'];
 return ['پیسې برابرې دي ✅','equal'];
}

function live(){
 let s=info(small()-n('bigMoney'));
 $('live').textContent='⚖️ '+s[0];$('live').className='status '+s[1];
}

function autoBackup(){
 localStorage.setItem(KEY,JSON.stringify(data));
 localStorage.setItem(BACKUP,JSON.stringify(data));
 localStorage.setItem(BACKUP+'_time',new Date().toLocaleString());
 updateBackupInfo();
}

function updateBackupInfo(){
 const t=localStorage.getItem(BACKUP+'_time');
 $('backupInfo').textContent=t?'✅ اتومات بیک اپ خوندي دی — وروستی بیک اپ: '+t:'ℹ️ لا بیک اپ نشته';
}

function saveTransaction(){
 let customer=$('customer').value.trim(),bigMoney=n('bigMoney');
 if(!customer)return alert('مهرباني وکړئ د مشتری نوم ولیکئ');
 if(bigMoney<=0)return alert('د غټو پیسو اندازه ولیکئ');

 let t={id:editId||Date.now(),customer,bigMoney,fifty:n('fifty'),twenty:n('twenty'),ten:n('ten'),
 received:small(),date:$('date').value,time:$('time').value,note:$('note').value.trim()};

 if(editId)data=data.map(x=>x.id===editId?t:x);else data.push(t);
 autoBackup();clearForm();render();alert('معامله ثبت او اتومات بیک اپ شوه ✅');
}

function clearForm(){
 ['customer','bigMoney','fifty','twenty','ten','note'].forEach(id=>$(id).value='');
 editId=null;$('formTitle').textContent='➕ نوې معامله';live();
}

function editTransaction(id){
 let t=data.find(x=>x.id===id);if(!t)return;editId=id;
 ['customer','bigMoney','fifty','twenty','ten','date','time','note'].forEach(k=>$(k).value=t[k]??'');
 $('formTitle').textContent='✏️ معامله ایدیت کړه';live();scrollTo({top:0,behavior:'smooth'});
}

function del(id){
 if(confirm('ایا دا معامله حذف کول غواړې؟')){
  data=data.filter(x=>x.id!==id);autoBackup();render();
 }
}

function deleteAll(){
 if(confirm('ایا ټولې معاملې حذف کول غواړې؟')){
  data=[];autoBackup();render();
 }
}

function clearSearch(){$('searchName').value='';$('searchDate').value='';render()}

function downloadBackup(){
 const backup={app:'Wais صرافي',version:'1.0',date:new Date().toISOString(),transactions:data};
 const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});
 const a=document.createElement('a');
 a.href=URL.createObjectURL(blob);
 a.download='Wais-Sarafi-Backup-'+new Date().toISOString().slice(0,10)+'.json';
 a.click();URL.revokeObjectURL(a.href);
}

function restoreBackup(e){
 const file=e.target.files[0];if(!file)return;
 const reader=new FileReader();
 reader.onload=function(){
  try{
   const obj=JSON.parse(reader.result);
   const restored=Array.isArray(obj)?obj:obj.transactions;
   if(!Array.isArray(restored))throw new Error();
   if(confirm('ایا بیک اپ Restore کول غواړې؟ اوسني معلومات به بدل شي.')){
    data=restored;autoBackup();render();alert('Restore په بریالیتوب ترسره شو ✅');
   }
  }catch(err){alert('دا سم Backup فایل نه دی ❌')}
 };
 reader.readAsText(file);
 e.target.value='';
}

function esc(x){return String(x||'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]))}

function render(){
 let q=$('searchName').value.toLowerCase(),d=$('searchDate').value;
 let list=data.filter(t=>(!q||t.customer.toLowerCase().includes(q))&&(!d||t.date===d)).slice().reverse();

 let tb=data.reduce((s,t)=>s+t.bigMoney,0);
 let ts=data.reduce((s,t)=>s+t.received,0);
 let diff=ts-tb,s=info(diff);

 $('count').textContent=data.length;
 $('totalBig').textContent=tb.toLocaleString();
 $('totalSmall').textContent=ts.toLocaleString();
 $('totalDiff').textContent=(diff>0?'+':'')+diff.toLocaleString();
 $('totalStatus').textContent=s[0];
 $('diffCard').className=s[1];

 $('transactions').innerHTML=list.length?list.map(t=>{
  let st=info(t.received-t.bigMoney);
  return `<div class="transaction">
   <div class="head"><b>👤 ${esc(t.customer)}</b><span>📅 ${t.date} 🕒 ${t.time||''}</span></div>
   <div class="items">
    <div class="item">💵 غټې پیسې<b>${t.bigMoney.toLocaleString()} AFN</b></div>
    <div class="item">🟠 ۵۰ ګون<b>${t.fifty.toLocaleString()} AFN</b></div>
    <div class="item">🔵 ۲۰ ګون<b>${t.twenty.toLocaleString()} AFN</b></div>
    <div class="item">🔴 ۱۰ ګون<b>${t.ten.toLocaleString()} AFN</b></div>
   </div>
   <div class="status ${st[1]}">⚖️ ${st[0]}</div>
   ${t.note?'<p>📝 '+esc(t.note)+'</p>':''}
   <div class="actions"><button onclick="editTransaction(${t.id})">✏️ ایدیت</button><button class="del" onclick="del(${t.id})">🗑 حذف</button></div>
  </div>`;
 }).join(''):'<p style="text-align:center;color:#667">هیڅ معامله نشته.</p>';
}

autoBackup();render();live();