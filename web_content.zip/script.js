$(function() {
  const STORAGE_KEY = "notekeeper.document.v2";
  const HISTORY_KEY = "notekeeper.history.v2";
  const HISTORY_INTERVAL = 3 * 60 * 60 * 1000;
  const $editor = $("#editor");
  let savedRange = null;
  let saveTimer;

  function escapeHtml(value) {
    return $("<div>").text(String(value ?? "")).html();
  }

  function rememberSelection() {
    const selection = window.getSelection();
    if (selection && selection.rangeCount && $editor[0].contains(selection.anchorNode)) {
      savedRange = selection.getRangeAt(0).cloneRange();
    }
  }
  document.addEventListener("selectionchange", rememberSelection);

  function restoreSelection() {
    if (!savedRange) return;
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(savedRange);
  }

  function focusEditor() {
    $editor.trigger("focus");
    restoreSelection();
  }

  function updateCounter() {
    const text = ($editor[0].innerText || "").replace(/\u00a0/g, " ");
    const trimmed = text.trim();
    const characters = text.length;
    const words = trimmed ? (trimmed.match(/\S+/g) || []).length : 0;
    const sentences = trimmed
      ? (trimmed.match(/[.!?]+(?:["'”’)\]]*)?(?=\s|$)/g) || []).length
      : 0;
    const paragraphs = sentences ? Math.ceil(sentences / 5.5) : (trimmed ? 1 : 0);

    $("#counter").html(
      `<span>${characters} characters</span>` +
      `<span>${words} words</span>` +
      `<span>${sentences} sentences</span>` +
      `<span>${paragraphs} paragraphs</span>`
    );
  }

  function getSnapshot() {
    return {
      title: $("#noteTitle").val(),
      html: $editor.html()
    };
  }

  function saveHistorySnapshot() {
    try {
      const snapshot = getSnapshot();
      const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
      const latest = history[0];

      // Avoid duplicate snapshots when nothing has changed.
      if (latest && latest.title === snapshot.title && latest.html === snapshot.html) {
        return false;
      }

      history.unshift({
        ...snapshot,
        date: new Date().toLocaleString(),
        timestamp: Date.now()
      });
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 7)));
      return true;
    } catch (error) {
      console.warn("Could not save version history.", error);
      return false;
    }
  }

  function saveDocument({ addHistory = false } = {}) {
    try {
      if (addHistory) saveHistorySnapshot();

      localStorage.setItem(STORAGE_KEY, JSON.stringify({
        ...getSnapshot(),
        theme: $("body").attr("data-theme") || "white",
        lineNumbers: $editor.hasClass("line-numbers"),
        updated: new Date().toISOString()
      }));

      $("#saveState").text("Saved locally");
      $("#lastSaved").text("Last saved " + new Date().toLocaleTimeString());
    } catch (_) {
      $("#saveState").text("Could not save — storage may be full");
    }
  }

  function scheduleSave() {
    $("#saveState").text("Saving…");
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => saveDocument(), 350);
    updateCounter();
  }

  function loadDocument() {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (data) {
        $("#noteTitle").val(data.title || "");
        $editor.html(data.html || "");
        const theme = data.theme || "white";
        $("body").attr("data-theme", theme);
        $("#themeSelect").val(theme);
        $editor.toggleClass("line-numbers", !!data.lineNumbers);
      }
    } catch (error) {
      console.warn("Could not load saved note.", error);
    }
    updateCounter();
  }

  function runCommand(command, value = null) {
    focusEditor();
    if (command === "increaseFont" || command === "decreaseFont") {
      const current = parseInt(document.queryCommandValue("fontSize"), 10) || 3;
      const next = Math.max(1, Math.min(7, current + (command === "increaseFont" ? 1 : -1)));
      document.execCommand("fontSize", false, String(next));
    } else {
      document.execCommand(command, false, value);
    }
    scheduleSave();
  }

  function insertHtml(html) {
    focusEditor();
    document.execCommand("insertHTML", false, html);
    scheduleSave();
  }

  function safeFilename(extension) {
    const title = ($("#noteTitle").val() || "Note-Keeper")
      .replace(/[^\w-]+/g, "-").replace(/^-|-$/g, "");
    return (title || "Note-Keeper") + extension;
  }

  function downloadFile(name, content, type) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function exportHtml() {
    const title = $("#noteTitle").val() || "Untitled note";
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<style>
body{max-width:900px;margin:40px auto;padding:0 24px;color:#333;font:12pt/1.35 "Times New Roman",Times,serif}
img{max-width:100%;height:auto}table{width:100%;border-collapse:collapse;table-layout:fixed}
th,td{padding:0;vertical-align:top;overflow-wrap:anywhere}
ul ul{list-style-type:circle}ul ul ul{list-style-type:square}
</style></head><body><h1>${escapeHtml(title)}</h1><main>${$editor.html()}</main></body></html>`;
    downloadFile(safeFilename(".html"), html, "text/html;charset=utf-8");
  }

  function exportMarkdown() {
    const markdown = $editor.html()
      .replace(/<h1[^>]*>(.*?)<\/h1>/gi, "# $1\n")
      .replace(/<h2[^>]*>(.*?)<\/h2>/gi, "## $1\n")
      .replace(/<h3[^>]*>(.*?)<\/h3>/gi, "### $1\n")
      .replace(/<strong>|<b>/gi, "**").replace(/<\/strong>|<\/b>/gi, "**")
      .replace(/<em>|<i>/gi, "*").replace(/<\/em>|<\/i>/gi, "*")
      .replace(/<br\s*\/?>/gi, "\n").replace(/<\/p>/gi, "\n\n")
      .replace(/<[^>]+>/g, "").replace(/&nbsp;/g, " ");
    downloadFile(safeFilename(".md"), markdown, "text/markdown;charset=utf-8");
  }

  async function exportPng() {
    try {
      const canvas = await html2canvas($editor[0], {
        backgroundColor: getComputedStyle($editor[0]).backgroundColor,
        scale: 2,
        useCORS: true
      });
      const link = document.createElement("a");
      link.download = safeFilename(".png");
      link.href = canvas.toDataURL("image/png");
      link.click();
    } catch (error) {
      console.error(error);
      alert("PNG export failed. An image from another website may block export.");
    }
  }

  function doFindReplace() {
    const find = prompt("Text to find:");
    if (!find) return;
    const replacement = prompt("Replace with:", "");
    if (replacement === null) return;
    const walker = document.createTreeWalker($editor[0], NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    const escaped = find.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(escaped, "gi");
    nodes.forEach(node => {
      if (!node.parentElement.closest("script,style")) {
        node.nodeValue = node.nodeValue.replace(regex, replacement);
      }
    });
    scheduleSave();
  }

  function eraseSelectedFormatting() {
    focusEditor();
    const selection = window.getSelection();
    if (!selection || !selection.rangeCount || selection.isCollapsed) {
      alert("Select content inside the note first.");
      return;
    }
    const range = selection.getRangeAt(0);
    if (!$editor[0].contains(range.commonAncestorContainer)) {
      alert("Select content inside the note first.");
      return;
    }
    const affected = [...$editor[0].querySelectorAll("*")].filter(element => {
      try { return range.intersectsNode(element); } catch (_) { return false; }
    });
    affected.forEach(element => {
      if (!element.isConnected) return;
      if (element.matches("a,.bookmark-target,.bookmark-link")) {
        element.replaceWith(...element.childNodes);
        return;
      }
      element.removeAttribute("style");
      if (element.matches("table,blockquote")) {
        element.className = "";
      } else {
        element.removeAttribute("class");
        element.removeAttribute("id");
        element.removeAttribute("data-bookmark-name");
        if (/^(B|STRONG|I|EM|U|S|STRIKE|FONT|MARK|SUB|SUP)$/.test(element.tagName)) {
          element.replaceWith(...element.childNodes);
        }
      }
    });
    document.execCommand("removeFormat", false, null);
    selection.removeAllRanges();
    scheduleSave();
  }

  function handleAction(action) {
    switch (action) {
      case "new":
        if (!confirm("Create a new note? Save the current note to version history?")) return;
        saveDocument({ addHistory: true });
        $("#noteTitle").val("");
        $editor.empty();
        scheduleSave();
        break;
      case "save":
        saveDocument({ addHistory: true });
        break;
      case "export-txt":
        downloadFile(safeFilename(".txt"), $editor.text(), "text/plain;charset=utf-8");
        break;
      case "export-md":
        exportMarkdown();
        break;
      case "export-html":
        exportHtml();
        break;
      case "export-doc":
        downloadFile(
          safeFilename(".doc"),
          `<!doctype html><html><head><meta charset="utf-8"></head><body><h1>${escapeHtml($("#noteTitle").val())}</h1>${$editor.html()}</body></html>`,
          "application/msword"
        );
        break;
      case "export-png":
        exportPng();
        break;
      case "print":
      case "preview":
        window.print();
        break;
      case "upload-text":
        $("#textUpload").click();
        break;
      case "select-all": {
        focusEditor();
        const range = document.createRange();
        range.selectNodeContents($editor[0]);
        window.getSelection().removeAllRanges();
        window.getSelection().addRange(range);
        rememberSelection();
        break;
      }
      case "copy": runCommand("copy"); break;
      case "cut": runCommand("cut"); break;
      case "undo": runCommand("undo"); break;
      case "redo": runCommand("redo"); break;
      case "find": doFindReplace(); break;
      case "erase-format": eraseSelectedFormatting(); break;
      case "indent-list": runCommand("indent"); break;
      case "outdent-list": runCommand("outdent"); break;
      case "paste":
        if (navigator.clipboard?.readText) {
          navigator.clipboard.readText()
            .then(text => insertHtml(escapeHtml(text).replace(/\n/g, "<br>")))
            .catch(() => alert("Clipboard access blocked. Use Ctrl/Cmd+V in the editor."));
        } else {
          alert("Use Ctrl/Cmd+V to paste.");
        }
        break;
      case "viewer":
        $("body").toggleClass("viewer");
        $editor.attr("contenteditable", $("body").hasClass("viewer") ? "false" : "true");
        break;
      case "html-view": {
        const win = window.open("", "_blank");
        if (win) {
          win.document.open();
          win.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>${escapeHtml($("#noteTitle").val())}</title></head><body><h1>${escapeHtml($("#noteTitle").val())}</h1>${$editor.html()}</body></html>`);
          win.document.close();
        }
        break;
      }
      case "history": {
        const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
        if (!history.length) {
          alert("No saved versions yet.");
          break;
        }
        const list = history.map((v, i) =>
          `${i + 1}. ${v.date} — ${v.title || "Untitled"}`
        ).join("\n");
        const version = history[Number(prompt(`${list}\n\nEnter version number:`)) - 1];
        if (version && confirm("Restore this version?")) {
          $("#noteTitle").val(version.title || "");
          $editor.html(version.html || "");
          scheduleSave();
        }
        break;
      }
      case "timestamp":
        insertHtml(`<span>${escapeHtml(new Date().toLocaleString())}</span>`);
        break;
      case "rule":
        insertHtml("<hr>");
        break;
      case "caption": {
        const figure = $editor.find("img").last().closest("figure");
        if (!figure.length) { alert("Insert an image first."); break; }
        figure.append("<figcaption contenteditable='true'>Image caption</figcaption>");
        scheduleSave();
        break;
      }
      case "bookmark": {
        focusEditor();
        const selectedText = window.getSelection().toString().trim();
        if (!selectedText) { alert("Select a section heading or text first."); break; }
        const id = "section-" + Date.now();
        const label = prompt("Bookmark name:", selectedText) || selectedText;
        insertHtml(`<span id="${id}" class="bookmark-target" data-bookmark-name="${escapeHtml(label)}">${escapeHtml(selectedText)}</span>`);
        break;
      }
      case "link-bookmark": {
        const bookmarks = [...$editor[0].querySelectorAll(".bookmark-target")];
        if (!bookmarks.length) { alert("Create a section bookmark first."); break; }
        const menu = bookmarks.map((b, i) =>
          `${i + 1}. ${b.dataset.bookmarkName || b.textContent}`
        ).join("\n");
        const target = bookmarks[Number(prompt(`Choose a section:\n${menu}\n\nEnter number:`)) - 1];
        if (!target) break;
        focusEditor();
        const selected = window.getSelection().toString().trim();
        const label = selected || prompt("Link text:", target.dataset.bookmarkName || target.textContent);
        if (label) insertHtml(`<a class="bookmark-link" href="#${target.id}">${escapeHtml(label)}</a>`);
        break;
      }
      case "insert-toc": {
        const bookmarks = [...$editor[0].querySelectorAll(".bookmark-target")];
        if (!bookmarks.length) { alert("Create section bookmarks first."); break; }
        const links = bookmarks.map(b =>
          `<li><a href="#${b.id}">${escapeHtml(b.dataset.bookmarkName || b.textContent)}</a></li>`
        ).join("");
        insertHtml(`<nav class="table-of-contents"><strong>Table of Contents</strong><ul>${links}</ul></nav><p><br></p>`);
        break;
      }
      case "remove-bookmark":
        $editor.find(".bookmark-target,.bookmark-link").each(function() {
          $(this).replaceWith(...this.childNodes);
        });
        scheduleSave();
        break;
      case "table": {
        const rows = Math.max(1, Math.min(20, Number(prompt("Rows:", "3")) || 3));
        const cols = Math.max(1, Math.min(12, Number(prompt("Columns:", "3")) || 3));
        const style = Math.max(1, Math.min(8, Number(prompt("Table style (1–8):", "2")) || 2));
        let html = `<table class="table-style-${style}" contenteditable="true"><thead><tr>`;
        for (let c = 0; c < cols; c++) html += `<th contenteditable="true">Header ${c + 1}</th>`;
        html += "</tr></thead><tbody>";
        for (let r = 0; r < rows; r++) {
          html += "<tr>";
          for (let c = 0; c < cols; c++) html += '<td contenteditable="true"><br></td>';
          html += "</tr>";
        }
        insertHtml(html + "</tbody></table><p><br></p>");
        break;
      }
      case "image":
        $("#imageUpload").click();
        break;
      case "link": {
        const url = prompt("Link URL:");
        if (!url) break;
        const text = prompt("Link text (blank uses selected text):", "");
        if (text) insertHtml(`<a href="${escapeHtml(url)}">${escapeHtml(text)}</a>`);
        else runCommand("createLink", url);
        break;
      }
      case "quote": {
        const styles = ["orange", "teal", "green", "tan", "black", "rose", "blue", "lavender", "slate"];
        const style = (prompt("Style: " + styles.join(", "), "teal") || "").toLowerCase();
        if (!styles.includes(style)) break;
        const title = prompt("Quote title:", "A thought to keep") || "";
        insertHtml(`<blockquote class="quote-${style}"><div class="quote-title">${escapeHtml(title)}</div><div class="quote-body" contenteditable="true">Write your comment here…</div></blockquote><p><br></p>`);
        break;
      }
    }
  }

  $(".menu-button").on("click", function(event) {
    event.stopPropagation();
    const $menu = $("#" + $(this).data("menu"));
    $(".dropdown").not($menu).removeClass("open");
    $menu.toggleClass("open");
  });
  $(document).on("click", () => $(".dropdown").removeClass("open"));
  $(".dropdown").on("click", "button", function() {
    handleAction($(this).data("action"));
  });

  $(".tool[data-command]").on("mousedown", event => event.preventDefault());
  $(".tool[data-command]").on("click", function() {
    $(this).toggleClass("active");
    runCommand($(this).data("command"));
  });
  $(".tool[data-action]").on("mousedown", event => event.preventDefault());
  $(".tool[data-action]").on("click", function() {
    handleAction($(this).data("action"));
  });

  $("#fontFamily").on("change", function() {
    runCommand("fontName", this.value);
  });

  $("#textStyle").on("change", function() {
    focusEditor();
    const value = this.value;
    if (["h1", "h2", "h3", "h4", "p"].includes(value)) {
      document.execCommand("formatBlock", false, value);
      if (value === "p") {
        let node = window.getSelection().anchorNode;
        if (node && node.nodeType === 3) node = node.parentElement;
        const paragraph = node && node.closest("p");
        if (paragraph) {
          paragraph.style.fontFamily = '"Times New Roman", Times, serif';
          paragraph.style.fontSize = "12pt";
          paragraph.style.color = "#333333";
          paragraph.style.lineHeight = "1.35";
        }
      }
    } else {
      document.execCommand("formatBlock", false, "p");
      let node = window.getSelection().anchorNode;
      if (node && node.nodeType === 3) node = node.parentElement;
      const block = node && node.closest("p");
      if (block) block.classList.add(value);
    }
    scheduleSave();
  });

  $("#textColor").on("input", function() {
    runCommand("foreColor", this.value);
  });
  $("#highlightColor").on("input", function() {
    focusEditor();
    if (!document.execCommand("hiliteColor", false, this.value)) {
      document.execCommand("backColor", false, this.value);
    }
    scheduleSave();
  });

  $("#listStyle").on("change", function() {
    const style = this.value;
    if (!style) return;
    focusEditor();
    const ordered = ["decimal", "upper-alpha", "lower-alpha", "upper-roman", "lower-roman"].includes(style);
    document.execCommand(ordered ? "insertOrderedList" : "insertUnorderedList");
    let node = window.getSelection().anchorNode;
    if (node && node.nodeType === 3) node = node.parentElement;
    const list = node && node.closest("ol,ul");
    if (list) list.style.listStyleType = style;
    this.value = "";
    scheduleSave();
  });

  $("#editor,#noteTitle").on("input", scheduleSave);
  $("#editor").on("keyup mouseup", rememberSelection);

  $("#themeSelect").on("change", function() {
    $("body").attr("data-theme", this.value);
    scheduleSave();
  });

  $("#textUpload").on("change", function() {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (/\.html?$/i.test(file.name)) $editor.html(reader.result);
      else $editor.text(reader.result);
      if (!$("#noteTitle").val()) {
        $("#noteTitle").val(file.name.replace(/\.[^.]+$/, ""));
      }
      scheduleSave();
      this.value = "";
    };
    reader.readAsText(file);
  });

  $("#imageUpload").on("change", function() {
    const file = this.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const alignmentInput = prompt("Image alignment: left, center, or right", "center") || "center";
      const width = Math.max(50, Math.min(1200, Number(prompt("Image width in pixels:", "500")) || 500));
      const alignment = ["left", "center", "right"].includes(alignmentInput) ? alignmentInput : "center";
      insertHtml(`<figure style="text-align:${alignment}"><img src="${reader.result}" style="width:${width}px"><figcaption contenteditable="true">Image caption</figcaption></figure>`);
      this.value = "";
    };
    reader.readAsDataURL(file);
  });

  loadDocument();

  // Autosave the current document every 15 seconds, without adding history.
  setInterval(() => saveDocument(), 15000);

  // Add a history snapshot only if the note changed since the last history snapshot.
  setInterval(() => saveDocument({ addHistory: true }), HISTORY_INTERVAL);

  // Unload saves the current document only; it does not create a history entry.
  window.addEventListener("beforeunload", () => saveDocument());
});