
/* =========================================
   WORD ZENTO PUZZLE - CORRECTED COMPLETE SCRIPT
========================================= */

(() => {
"use strict";

const STORE = "wordZentoPuzzle_v1";
const TOTAL_LEVELS = 1000;
const LEVEL_BATCH_SIZE = 1000;

const defaults = {
    unlocked: 1,
    completed: [],
    coins: 0,
    hints: 5,
    hintAdsWatched: {},
    sound: true,
    music: true,
    theme: "dark",
    gridTheme: "classic",
    alphabetStyle: "upper"
};

let data;

try {
    const saved = JSON.parse(localStorage.getItem(STORE) || "null");
    data = saved && typeof saved === "object"
        ? { ...defaults, ...saved }
        : { ...defaults };

    if (!Array.isArray(data.completed)) data.completed = [];
    if (!data.hintAdsWatched || typeof data.hintAdsWatched !== "object") {
        data.hintAdsWatched = {};
    }
    if (!Number.isFinite(data.hints)) data.hints = 5;
    if (!Number.isFinite(data.coins)) data.coins = 0;
    if (!Number.isFinite(data.unlocked)) data.unlocked = 1;
    if (!["dark", "light"].includes(data.theme)) data.theme = "dark";
    if (!["classic", "neon", "wood"].includes(data.gridTheme)) {
        data.gridTheme = "classic";
    }
    if (!["upper", "lower"].includes(data.alphabetStyle)) {
        data.alphabetStyle = "upper";
    }
} catch (error) {
    data = { ...defaults };
}

const $ = selector => document.querySelector(selector);
const $$ = selector => Array.from(document.querySelectorAll(selector));

let currentLevel = 1;
let currentPuzzle = null;
let foundWords = [];
let selectedCells = [];
let isSelecting = false;
let pendingRewardedHint = false;
let nextLevelToRender = 1;

let backgroundAudio = null;
let musicTimer = null;
let soundContext = null;
let toastTimer = null;

/* =========================================
   SAVE DATA
========================================= */

function saveData() {
    try {
        localStorage.setItem(STORE, JSON.stringify(data));
    } catch (error) {
        console.warn("Game data could not be saved.", error);
    }
}

function showElement(element) {
    if (element) element.classList.remove("hidden");
}

function hideElement(element) {
    if (element) element.classList.add("hidden");
}

function showScreen(screenId) {
    $$(".screen").forEach(screen => {
        screen.classList.remove("active");
        screen.classList.add("hidden");
    });

    const target = $("#" + screenId);

    if (target) {
        target.classList.remove("hidden");
        target.classList.add("active");
    }
}

function showToast(message) {
    const toast = $("#toast");
    if (!toast) return;

    toast.textContent = message;
    toast.classList.add("show");

    clearTimeout(toastTimer);

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 2200);
}

function showModal(title, message) {
    const modal = $("#modal");

    if (!modal) {
        alert(message);
        return;
    }

    $("#modalTitle").textContent = title;
    $("#modalText").textContent = message;
    showElement(modal);
}

function closeModal() {
    hideElement($("#modal"));
}

/* =========================================
   DISPLAY UPDATES
========================================= */

function updateCoinDisplays() {
    ["#homeCoins", "#levelCoins", "#gameCoins"].forEach(selector => {
        const element = $(selector);
        if (element) element.textContent = data.coins;
    });
}

function updateHintDisplay() {
    const hintSub = $("#hintBtn .hint-sub");

    if (data.hints > 0) {
        if (hintSub) {
            hintSub.innerHTML = `<b id="hintsLeft">${data.hints}</b> free`;
        } else {
            const element = $("#hintsLeft");
            if (element) element.textContent = data.hints;
        }
    } else if (hintSub) {
        hintSub.textContent = "AD";
    }
}

function updateBasicDisplays() {
    updateCoinDisplays();
    updateHintDisplay();
}

/* =========================================
   WORD DATABASE
========================================= */

const words = [
    // Add your own unique 3-to-6 letter A-Z puzzle words here.
    "CANYON", "GOBLET", "INK", "JUNGLE", "KAYAK", "MOSAIC", "WALNUT"
, "YOLK", "ZODIAC", "CLOVER", "DAGGER", "FALCON", "YELLOW", "JIGSAW", 
"TIGER", "HOUSE", "ZEBRA", "CLOUD", "BREAD", "MONKEY", "RIVER", "CHAIR", 
"PLANET", "GARDEN", "SHARK", "WINDOW", "FLOWER", "ROCKET", "BOTTLE", "CASTLE",
 "DONKEY", "FOREST", "HAMMER", "ISLAND", "JACKET", "KITTEN", "LADDER", "MIRROR", 
 "NEEDLE", "ORANGE", "PENCIL", "QUEEN", "RABBIT", "SCHOOL", "TURTLE", "WALLET", 
 "YOGURT", "ANCHOR", "BANANA", "CAMERA", "DRAGON", "ENGINE", "FINGER", "GUITAR", 
 "HELMET", "IGLOO", "KETTLE", "MAGNET", "NAPKIN", "OCEAN", "PILLOW", "QUARTZ", 
 "ROBOT", "XYLEM", "ZIPPER", "BUTTER", "CARPET", "GALAXY", "HONEY", "JELLY",
  "LEMON", "OYSTER", "PEANUT", "QUAIL", "SILVER", "TOMATO", "VIOLIN", "YOYO",
  "ZOO", "ACORN", "BASKET", "CANDLE", "DESERT", "EAGLE", "FARMER", "GRAPES",
  "INSECT", "RULER", "SPIDER", "TRAIN", "VACUUM", "WHALE", "YACHT", "ERASER",
  "FAMILY", "LIZARD", "MEADOW", "NUGGET", "OLIVE", "PARROT", "QUICK", "RIBBON",
  "SHELL", "TROPHY", "VALLEY", "WIZARD", "YOUNG", "ZEST", "ARTIST", "BUTTON",
  "DRUM", "HUNTER", "KIDNEY", "MARBLE", "NEST", "OFFICE", "PIRATE", "QUILT",
  "RAZOR", "TEMPLE", "VELVET", "WAGON", "YARD", "ABACUS", "BEACON", "CIRCUS",
  "DANCER", "EARTH", "FROG", "GLOVE", "HUNGRY", "IRON", "JUMPER", "KERNEL",
  "LAGOON", "MANGO", "NURSE", "ORBIT", "PEPPER", "QUARRY", "TICKET", "VIOLET",
  "WHEAT", "ZIGZAG", "PANDA", "BRIDGE", "COTTON", "DANGER", "FOSSIL", "GARLIC",
  "IGUANA", "OXYGEN", "RACKET", "SADDLE", "TUNNEL", "UMPIRE", "UPHILL", "SILK",
  "ZAPPER", "FROZEN", "GLOVES", "INCH", "JOKER", "BADGER", "DUST", "ELBOW",
  "OAR", "TROUT", "WHEEL", "YAWN", "ZINC", "GRAVEL", "HICCUP", "KIOSK",
  "NINJA", "OPERA", "RANCH", "SCARF", "WILLOW", "YOGI", "ZEPHYR", "ATTIC",
  "BAMBOO", "FROST", "NARROW", "RIDDLE", "WALRUS", "ALARM", "DRAWER", "ECHO",
  "ESCAPE", "TEACUP", "CAMPUS", "ANIMAL", "ENERGY", "DOCTOR", "ABHOR", "ABIDE",
  "ABODE", "ABRUPT", "ABSORB", "ACCENT", "AGATE", "ALCOVE", "ALGAE", "ALIAS",
  "ALIBI", "ALPACA", "AMBER", "AMULET", "ANISE", "ANNEX", "ANNUAL", "ANTLER",
  "APEX", "ARCADE", "ARMOR", "AROMA", "ARTERY", "ATLAS", "AURORA", "AUTUMN",
  "AWNING", "AXIOM", "AZALEA", "BABOON", "BACON", "BAFFLE", "BAGEL", "BALLET",
  "BALLOT", "BALSAM", "BANDIT", "BARN", "BARTER", "BASALT", "BASIL", "BASIN",
  "BASIS", "BAYOU", "BEAKER", "BEAUTY", "BEAVER", "BEETLE", "BELFRY", "BELUGA",
  "BENGAL", "BERET", "BETA", "BIRCH", "BLIMP", "BOBCAT", "BOILER", "BONSAI",
  "BOTANY", "BOUNCE", "BOUNTY", "BRONZE", "BROOK", "BRUNCH", "BUCKLE", "BUMPER",
  "BUNGEE", "BURLAP", "BURROW", "BUTLER", "CACAO", "CACTUS", "CAESAR", "CALICO",
  "CANARY", "CARBON", "CASHEW", "CASKET", "CAVERN", "CELLO", "CEMENT", "CEREAL",
  "CHERUB", "CHEST", "CHISEL", "CIDER", "CINEMA", "CITRUS", "CLERGY", "CLINIC",
  "CLOAK", "CLOTH", "CLUTCH", "COBALT", "COBRA", "CODING", "COFFEE", "COLUMN",
  "COMEDY", "COMET", "COMIC", "CONSUL", "COPPER", "COSMOS", "COUGAR", "CRADLE",
  "CRATER", "CRUISE", "CRUST", "CUPOLA", "CURRY", "CURSOR", "CUSTOM", "DAIRY",
  "DAMSEL", "DASH", "DEBATE", "DECADE", "DECOR", "DEGREE", "DELTA", "DERBY",
  "DESIGN", "DOSAGE", "LION", "LINEN", "KIWI", "LEGEND", "ICON", "FLINT",
  "GAMBIT", "LUMBER", "HUMOR", "FENCE", "GLOBE", "GEAR", "GHOST", "HOBBY",
  "GOLDEN", "LENGTH", "FABLE", "GRAPE", "FLUTE", "FUTURE", "GINGER", "HERO",
  "IDEA", "JERSEY", "HABIT", "EXPERT", "JUNIOR", "GARNET", "JAGUAR", "GENIUS",
  "IMPACT", "INCOME", "EXILE", "IVORY", "YEAST", "YONDER", "OASIS", "YODEL",
  "GIGGLE", "GADGET", "DENIM", "VOYAGE", "SANDAL", "RAVEN", "PAPER", "JIGGLE",
  "PEBBLE", "JERBOA", "UPLIFT", "NORTH", "UPROAR", "NOMAD", "KARATE", "JOLLY",
  "TANGLE", "MANTIS", "NICKEL", "PLANK", "OUTLET", "EMPIRE", "BREEZE", "ZONING",
  "LADLE", "TEAPOT", "NEBULA", "LOCKET", "URCHIN", "SHOVEL", "VAPOR", "RECIPE",
  "AVENUE", "PADDLE", "QUENCH", "KNOCK", "QUOTA", "QUILL", "RUSTIC", "UNION",
  "FIDDLE", "RAISIN", "ZINNIA", "NATURE", "BULLET", "ACE", "ANT", "APE",
  "ARM", "ART", "BAG", "BAT", "BED", "BEE", "BELL", "BIRD",
  "BOAT", "BOOK", "BOX", "BOY", "BUG", "BUS", "CAKE", "CAP",
  "CAT", "CLAP", "COAT", "COIN", "COLD", "COMB", "COOK", "CORN",
  "COW", "CRAB", "CUP", "DEER", "DESK", "DICE", "DISH", "DOG",
  "DOLL", "DOOR", "DUCK", "EAR", "EGG", "ELF", "EYE", "FACE",
  "FAN", "FARM", "FAST", "FEET", "FISH", "FLAG", "FOOT", "FORK",
  "FOX", "GAME", "GATE", "GIFT", "GIRL", "GOAT", "GOLD", "GOLF",
  "GOOD", "HAND", "HAT", "HEAD", "HEAT", "HEN", "HILL", "HOME",
  "HOOD", "HOOK", "HOOP", "HORN", "ICE", "JAM", "JAR", "JAW",
  "JET", "JOY", "JUG", "KEY", "KID", "KING", "KITE", "KNEE",
  "KNOT", "LAKE", "LAMB", "LAMP", "LEAF", "LEG", "LIME", "LINE",
  "LIP", "LOCK", "LOG", "LOOP", "LUCK", "MAP", "MASK", "MAT",
  "MEAL", "MEAT", "MILK", "MINT", "MOON", "MOP", "MOTH", "MUD",
  "MUG", "NAIL", "NAME", "NECK", "NET", "NEWS", "NOSE", "NUT",
  "OAK", "OWL", "PAGE", "PAIL", "PAIN", "PAIR", "PALM", "PAN",
  "PARK", "PATH", "PAW", "PEA", "PEAR", "PEN", "PET", "PIE",
  "PIG", "PIN", "PIPE", "PLAY", "PLUM", "POND", "POOL", "POT",
  "PUG", "PUP", "RAIN", "RAT", "RED", "RING", "ROAD", "ROCK",
  "ROOF", "ROOM", "ROOT", "ROPE", "ROSE", "RUG", "SALT", "SAND",
  "SEAL", "SEAT", "SEED", "SHIP", "SHOE", "SHOP", "SIGN", "SING",
  "SINK", "SKIP", "SKY", "SLED", "SOAP", "SOCK", "SOFA", "SONG",
  "SOUP", "STAR", "STEP", "STOP", "SUN", "SWAN", "SWIM", "TAIL",
  "TANK", "TAPE", "TEA", "TENT", "TOAD", "TOE", "TOY", "TREE",
  "TUB", "TWIN", "VAN", "VASE", "VEST", "WALL", "WAND", "WASH",
  "WAVE", "WEB", "WELL", "WEST", "WIG", "WIND", "WING", "WINK",
  "WISH", "WOLF", "WOOD", "WOOL", "WORM", "YAK", "YARN", "APRON",
  "BABY", "BAKERY", "BANNER", "BARBER", "BEACH", "BRANCH", "BROOM", "BUCKET",
  "BUNNY", "CANVAS", "CARROT", "CHALK", "CHEER", "CHEESE", "CLOWN", "COOKIE",
  "COUSIN", "COWBOY", "CRAYON", "DAISY", "DINNER", "DONUT", "DRESS", "DRIVER",
  "FRIEND", "GOPHER", "GREEN", "HELPER", "HIKING", "HORSE", "HOTDOG", "ICICLE",
  "KENNEL", "LAUGH", "LETTER", "MARKET", "MELODY", "MITTEN", "MUFFIN", "MUSEUM",
  "MUSIC", "NOODLE", "PARADE", "PARTY", "PEACH", "PICNIC", "PIGEON", "PIZZA",
  "POCKET", "POTATO", "PUPPY", "PUZZLE", "PYJAMA", "ROLLER", "SAILOR", "SALAD",
  "SEASON", "SHADOW", "SHEEP", "SHOWER", "SINGER", "SKATE", "SMILE", "SNAIL",
  "SNACK", "SOCCER", "SPONGE", "SPOON", "SPRING", "STAMP", "STORY", "STREAM",
  "STREET", "STRING", "SUMMER", "SUNSET", "SWING", "TABLET", "TEDDY", "TENNIS",
  "TOOTH", "TOWEL", "TRUCK", "TULIP", "TURKEY", "WAFFLE", "WATER", "WINTER",
  "WRITER", "PRINCE", "FRENCH", "STATES", "EYES", "PEOPLE", "LIFE", "ARMY",
  "COUNT", "PLACE", "STATE", "BONE", "TISSUE", "SKIN", "YEARS", "LAST",
  "ROUND", "POWER", "SIDE", "FORM", "MOMENT", "LOVE", "VOICE", "WORDS",
  "HANDS", "DAYS", "CASES", "BATTLE", "CASE", "OTHERS", "ORDER", "WOMEN",
  "COURSE", "RESULT", "NIGHT", "WORK", "JOINT", "CAUSE", "WIFE", "MATTER",
  "WORLD", "FRONT", "CHIEF", "ACTION", "WHITE", "MIND", "BODY", "LABOR",
  "MONEY", "WOMAN", "NERVE", "THINGS", "TROOPS", "HALF", "MOTHER", "YEAR",
  "THING", "NUMBER", "WORD", "TABLE", "PARTS", "ENEMY", "FACT", "SECOND",
  "LAND", "NEXT", "GLANDS", "FIRE", "HORSES", "BONES", "HEART", "FORMS",
  "ARMS", "SYSTEM", "RISE", "THIRD", "FORCE", "TIMES", "BLACK", "HAIR",
  "LAWS", "FELLOW", "PEACE", "GROWTH", "CROWD", "POINT", "PAST", "ORDERS",
  "SOUND", "SELF", "TRADE", "LIMB", "SHOW", "FIELD", "REST", "ANSWER",
  "PERIOD", "EVENTS", "LYMPH", "SPREAD", "MIDDLE", "REASON", "RETURN", "STEPS",
  "SILENT", "EFFECT", "PERSON", "SIZE", "HONOR", "CITY", "VIEW", "USUAL",
  "LADY", "FORMER", "CIVIL", "FORCES", "CHILD", "TOWN", "COURT", "AFRAID",
  "SIDES", "JOINTS", "GROUND", "NATION", "STRONG", "SOUL", "RIGHTS", "SPIRIT",
  "TONE", "REPLY", "HOURS", "PALE", "LATE", "MOUTH", "AREA", "NEED",
  "PLAN", "ULCER", "HOUR", "ATTACK", "MUSCLE", "DOUBT", "VOICES", "POWERS",
  "NERVES", "JOHN", "HOPE", "CAUSES", "TERMS", "UNABLE", "LIPS", "LIABLE",
  "STUDY", "STAFF", "SMOKE", "SISTER", "LOSS", "BLUE", "METHOD", "MASTER",
  "FIRM", "DIRECT", "GROUP", "CAMP", "VESSEL", "DUTY", "UNCLE", "MARCH",
  "MANNER", "VEINS", "TERM", "LINES", "LORD", "UPPER", "MONTHS", "EFFORT",
  "EAST", "CELLS", "SIGHT", "LATTER", "SERIES", "CORNER", "TARIFF", "FALL",
  "BALL", "RULE", "HEALTH", "CLOCK", "ULCERS", "QUIET", "LEGS", "WEEKS",
  "REGION", "POST", "HOUSES", "CHURCH", "VEIN", "POLICY", "GLASS", "AFFAIR",
  "TRUTH", "NOTE", "SLIGHT", "SENATE", "PAPERS", "TREATY", "ROYAL", "EVENT",
  "VOTE", "NONE", "MILES", "NORMAL", "BANK", "STAGE", "PLAIN", "EQUAL",
  "VALUE", "FLOOR", "CARE", "WRONG", "SENSE", "OBJECT", "LADIES", "FIGURE",
  "ENDS", "LESION", "MOVE", "MASS", "ISSUE", "FLUID", "FLANK", "WORKS",
  "EXTENT", "BILL", "SIGNS", "RANKS", "NOTICE", "SOURCE", "SAKE", "RAPID",
  "FIGHT", "DESIRE", "CHANCE", "CAVITY", "WEEK", "SHOT", "TODAY", "SOIL",
  "HILLS", "GUARDS", "BROAD", "BODIES", "AMOUNT", "SORT", "GLANCE", "BOOTS",
  "PORCH", "LOOSE", "PLACES", "HUGE", "GRAY", "ACTS", "TENDER", "ESTATE",
  "TYPE", "SHOCK", "REPORT", "REGARD", "RAYS", "MAID", "SNOW", "ROOMS",
  "LODGE", "DRIVE", "WEAK", "PLANS", "SUPPLY", "DUTIES", "SHARP", "POINTS",
  "MINUTE", "HALL", "CARTS", "SPEECH", "BALD", "VISIT", "SORE", "SECRET",
  "PRESS", "GRAND", "GOODS", "FAVOR", "SERFS", "THEORY", "SUITE", "SUDDEN",
  "MERE", "TOWNS", "REPAIR", "ORIGIN", "MARROW", "LIKELY", "FOURTH", "CIRCLE",
  "WEALTH", "SORRY", "ONES", "FIELDS", "DEMAND", "CITIES", "CENT", "TEETH",
  "SPOT", "LANDS", "RISK", "PITY", "FOOD", "DULL", "BARE", "USEFUL",
  "TRUNK", "CLASS", "BURST", "WALLS", "TOUCH", "STONE", "GUESTS", "FACTS",
  "CLAY", "CANAL", "BLOW", "SKULL", "SHAFT", "RUBLES", "GIRLS", "CURE",
  "CLUB", "BROWN", "WORTH", "WEIGHT", "SQUARE", "SOLE", "MASSES", "HEAVEN",
  "GAUZE", "EDGES", "CLOT", "CHARGE", "CENTER", "AUGUST", "SHEATH", "SHARE",
  "HEADS", "DEAL", "WRIST", "TRUST", "YOUTH", "THROAT", "LIMBS", "GROUPS",
  "CYST", "TONGUE", "CYSTS", "SPACE", "DEBT", "COST", "VIEWS", "SUPPER",
  "SHIPS", "NOTES", "MONTH", "LOUD", "FAITH", "ACTUAL", "TAXES", "MOIST",
  "ENTIRE", "ADVICE", "STOUT", "SHAPE", "MINE", "DOMAIN", "DEBTS", "ARMIES",
  "PIECE", "GRANT", "CROWN", "CREDIT", "ACID", "VOTES", "MOTION", "LIVES",
  "INNER", "HURRAH", "FIFTH", "EDGE", "ARREST", "SEARCH", "REFORM", "FAMOUS",
  "BOOKS", "VICE", "RULES", "ORGANS", "EARS", "BURNS", "BRAIN", "TRUSTS",
  "SMOOTH", "OFFER", "IDEAS", "COLONY", "VIRTUE", "GUARD", "GRAIN", "CLEVER",
  "CART", "ACCESS", "ABSENT", "SOLEMN", "MEMORY", "KNEES", "FAIR", "DRINK",
  "ASPECT", "APPEAL", "RECENT", "CAST", "BANKS", "BAND", "UNIONS", "TEST",
  "SICK", "SERUM", "LEVEL", "LEAGUE", "LEADER", "GOWN", "EXCUSE", "BASE",
  "WEARY", "WAYS", "LEGAL", "HOLY", "HOLLOW", "GLAND", "BONDS", "AUNT",
  "TREES", "TOXINS", "TOES", "THUMB", "SUGAR", "SIXTH", "REMARK", "MORAL",
  "MOOD", "LAYER", "WAGES", "TRUNKS", "SMELL", "SHIRT", "PRINT", "MILD",
  "MIDST", "MEMBER", "FAULT", "FANCY", "CORPS", "CENTRE", "BALLS", "TASK",
  "SEPTIC", "SCENE", "PULSE", "MODERN", "JOYFUL", "GLORY", "BAKER", "AGENTS",
  "VAST", "PROPER", "LIST", "FLOW", "FLIGHT", "DATE", "AIDE", "WORTHY",
  "WHEELS", "REVIEW", "OWING", "KISS", "DROP", "DOORS", "DELAY", "CHEEKS",
  "CARDS", "BORDER", "DUKE", "DEFEAT", "CORD", "COPY", "CHOICE", "TUBE",
  "STAGES", "SCALE", "ROUGH", "RANK", "PRICES", "PRICE", "JUDGE", "HURRY",
  "DREAM", "COUPLE", "VALET", "ROADS", "POWDER", "OWNERS", "MEDIUM", "LOUIS",
  "GAIN", "FEEBLE", "DENSE", "DAILY", "COURTS", "CLOUDS", "VOTERS", "THIRDS",
  "SORES", "SONS", "PORTS", "CLAIM", "CHINA", "CHEEK", "BEARD", "TRAP",
  "THRUST", "SABER", "ROLE", "RACE", "PRAYER", "MERCY", "LOVING", "HARM",
  "GUILTY", "GALLOP", "COLOR", "CATTLE", "BOTTOM", "ANGEL", "VITAL", "UTTER",
  "SOLID", "SOBS", "RECORD", "NAVAL", "MIST", "KNOLL", "FACTOR", "AREAS",
  "WHIP", "SPINAL", "PAUSE", "PACE", "MALE", "LIVER", "GRASS", "DANCE",
  "COAST", "CLAIMS", "VAGUE", "TITLE", "THANKS", "STRIKE", "SERENE", "RANGE",
  "NATIVE", "MILLS", "HAVEN", "HABITS", "GREY", "DOUBTS", "COATS", "COAL",
  "CAREER", "WAGONS", "TRIAL", "TEMPER", "SIGH", "SHOES", "REIGN", "PACES",
  "NOISE", "NAVY", "MARK", "LADS", "ISSUES", "FIRES", "DOGS", "DETAIL",
  "CHECK", "BREATH", "BOLD", "BELLS", "ANGLE", "WOODEN", "WONDER", "SUTURE",
  "SPACES", "SEAS", "SAFETY", "ONSET", "MENTAL", "FOLK", "FOCUS", "DEED",
  "COLLAR", "BONY", "AXIS", "TRACE", "STEADY", "JOKE", "HOUNDS", "HEIGHT",
  "HARE", "FRAME", "DOZEN", "ANKLE", "ACRES", "WILD", "TOTAL", "SPINE",
  "SHADE", "RUSH", "LIMIT", "HOMES", "FARMS", "CANALS", "YARDS", "TOPICS",
  "STRAIN", "SCOTCH", "PHRASE", "METAL", "GATES", "FLAT", "DIVINE", "CYSTIC",
  "CROWDS", "BURDEN", "BOARD", "BILLS", "TYPES", "TIDE", "STORM", "STOCK",
  "PALACE", "LACK", "JUDGES", "HOLDER", "CRISIS", "TRACK", "TONES", "SITE",
  "SHAME", "PRIEST", "PLUMP", "OWNER", "NAILS", "MILE", "GOOSE", "BROWS",
  "TIMID", "STROKE", "STARS", "STAIRS", "SPHERE", "SPEED", "PACK", "HUNT",
  "FRANK", "DUEL", "DINING", "CRIES", "CHARM", "WATERS", "VOLUME", "TIGHT",
  "SWIFT", "STORES", "STEEL", "STEAM", "STATUS", "ROSY", "REFUND", "REAR",
  "PROOF", "PELVIS", "MIGHTY", "MAIDS", "LOVELY", "LISE", "IODINE", "ILIAC",
  "HEARTS", "HASTE", "DRAFT", "DEPTH", "CHIN", "CHAIN", "CARD", "TRAVEL",
  "TOLL", "SHEET", "RUBBER", "PURPLE", "OUTER", "NAMES", "MOTOR", "LOFTY",
  "KINDS", "ICONS", "HEELS", "GROOM", "CHAIRS", "BUSHES", "AWFUL", "AUTHOR",
  "ACCORD", "ROWS", "PURSE", "PIECES", "MASON", "MARGIN", "GOAL", "GIANT",
  "GAZE", "DOSES", "DISTAL", "COARSE", "BIRTH", "WAKE", "SPARE", "SLEEVE",
  "PINK", "MINDS", "LUMEN", "LANE", "KINGS", "HUNGER", "FUNDS", "FLAP",
  "CONVOY", "BANDS", "AORTA", "ZONE", "THRONE", "TEXT", "SHOTS", "ROUTE",
  "ROLL", "REVOLT", "POUNDS", "OATH", "NEPHEW", "LOVER", "LOSSES", "IRONY",
  "HEROIC", "FLESH", "FAVOUR", "EXACT", "COPIES", "COACH", "BOND", "BENCH",
  "BEAST", "ADULTS", "ZEAL", "WISDOM", "SUIT", "SIGNAL", "SCHEME", "SCALP",
  "SALLOW", "SALINE", "SALE", "RODENT", "ROAR", "REMEDY", "PORTER", "NAIVE",
  "LARYNX", "JURY", "JOYOUS", "IDEAL", "HEROES", "HATRED", "GOUTY", "GOSSIP",
  "FUNNY", "EXCESS", "DOSE", "DAMAGE", "CLERK", "CADET", "BRIEF", "AGENT",
  "VODKA", "TIES", "SUBTLE", "STAKE", "REPEAL", "PROFIT", "MOVES", "MERIT",
  "MEDIAN", "HOOFS", "GUIDE", "FLEET", "ELBOWS", "CURLY", "CROPS", "CROP",
  "BEHALF", "BEES", "ADULT", "ABSURD", "WIRE", "TRACES", "TENSE", "TASTE",
  "STUMP", "STAIN", "SPURS", "SPASMS", "SORTS", "RUMORS", "RICE", "PLENTY",
  "OPIUM", "MADAM", "LUNGS", "LIMITS", "INDEX", "HOST", "FLAMES", "DRIFT",
  "DEFECT", "CORDS", "WOODS", "VERSES", "SPONGY", "SHOPS", "SHAWL", "RIGID",
  "RECTUM", "REALM", "RADIAL", "POSTS", "POLE", "NIGHTS", "MORROW", "MINES",
  "LIGHTS", "LAYERS", "HOTEL", "HOARSE", "GLOW", "EXTRA", "DUCT", "DEPTHS",
  "DAWN", "DARING", "CELLAR", "BOOT", "BIND", "BATH", "VOID", "TRAINS",
  "TENURE", "TALE", "STRAW", "SLOPE", "SEATS", "SACRED", "PHASE", "NIECE",
  "NASAL", "HIVE", "HEEL", "GRANTS", "GRACE", "FORMAL", "ENTRY", "EIGHTH",
  "DECREE", "BROW", "BREACH", "BOYS", "BOSOM", "BLUISH", "VALVES", "TINY",
  "SUMS", "STIFF", "SPOILS", "SLEEPY", "RIVERS", "REINS", "PLEA", "NOVEL",
  "MUTUAL", "INTACT", "HALT", "GAINS", "FRUIT", "FOUL", "DISMAY", "CRACK",
  "CHASE", "UNITY", "TENTH", "TABLES", "SHAVEN", "SENIOR", "RULERS", "RENT",
  "REMOTE", "PORT", "POETIC", "PLATE", "PARENT", "MUSKET", "MUDDY", "MINERS",
  "MARKS", "MANUAL", "LOTION", "LABORS", "KEEPER", "INSULT", "IDLE", "GENTRY",
  "FORT", "FOLLY", "FAINT", "DOLLAR", "DEVICE", "CLUE", "CAPS", "BUREAU",
  "AVAIL", "VICTIM", "UTMOST", "TRENCH", "TALENT", "STYLE", "STALLS", "SMILES",
  "SENILE", "ROOFS", "PURITY", "PUPIL", "PAGES", "MODE", "MISERY", "MINING",
  "MILL", "MICRO", "JAWS", "HONORS", "HOLE", "GRAFT", "GEESE", "FRIGHT",
  "FEMALE", "EXIT", "EXCISE", "ERROR", "DRAIN", "BRUSH", "BICEPS", "BATHS",
  "BASS", "YIELDS", "WAIST", "WAGE", "VIRGIN", "TUTOR", "TRUCE", "TRICK",
  "TRAIL", "TALES", "STOCKS", "SPASM", "SOULS", "SODA", "SKIRT", "SILL",
  "SCORE", "SCENT", "RUSTLE", "RINGS", "PETTY", "MOTIVE", "MALES", "LUNCH",
  "JEST", "INFANT", "IMPORT", "HEAP", "GUEST", "FOCI", "ESCORT", "EDITOR",
  "DATA", "CURVED", "COUNTY", "CALF", "ARTS", "AIDES", "WIVES", "WAVES",
  "VILE", "VEIL", "UTERUS", "UNSEEN", "TIPS", "THRILL", "THREAD", "TENS",
  "RIDER", "RIBS", "PUPILS", "PRAISE", "PITCH", "PIPES", "PALATE", "ORGAN",
  "NOTION", "MURMUR", "MENACE", "LAWYER", "LAWFUL", "JUMP", "INCHES", "HONOUR",
  "FLUIDS", "FIBRIN", "ERRORS", "EPOCH", "DUSTY", "DREAMS", "DIARY", "CLASH",
  "CHILL", "BOXES", "BLOWS", "BANKER", "AGES", "WRIT", "WOOLEN", "UNEASY",
  "TUNE", "TIMBER", "TILLED", "TALKS", "SPORES", "SHAGGY", "SAINT", "RUDE",
  "RUBLE", "RIVAL", "RANGES", "QUEST", "PROBE", "PLATES", "ONLINE", "OATS",
  "MORBID", "MOLE", "MAYOR", "MAIDEN", "LUCKY", "JOYS", "HERD", "HAIRS",
  "GRAINS", "GEMS", "FUTILE", "FOLDS", "FLAME", "FEUDAL", "FEES", "FAME",
  "CRAFT", "COUCH", "CLAUSE", "CIGAR", "CHEAP", "BRANDY", "BOARDS", "BIRDS",
  "ASYLUM", "ALTAR", "WITTY", "WHITES", "WHISKY", "UNIQUE", "TWIST", "TAVERN",
  "TACT", "SONGS", "SHREWD", "SEQUEL", "SCREEN", "SALTS", "ROUTES", "RISKS",
  "RIGOR", "RESCUE", "RAGGED", "PREY", "PATCH", "MORTAL", "MOROSE", "LIVID",
  "LAWN", "LATENT", "HAIRY", "GUILT", "GOSPEL", "GAIETY", "FUND", "FRUITS",
  "FLOUR", "FLOOD", "EXPORT", "DEEDS", "CREAM", "COUGH", "CHAINS", "BRICK",
  "BOOM", "BLOCK", "BAGS", "ARDENT", "AKIN", "WILLS", "VIGOR", "URGENT",
  "UNITS", "UNEVEN", "TUBES", "TOXIN", "TOOLS", "TIPSY", "THIRST", "STONES",
  "SLIM", "SILLY", "SHRILL", "SHAFTS", "SCURVY", "SALARY", "REFUGE", "READER",
  "PLAINS", "OUTSET", "OUTPUT", "OUNCE", "MODEST", "MODEL", "MANLY", "LORDS",
  "LONELY", "LOANS", "LIQUOR", "LINT", "LINKS", "LAKES", "KEYS", "JEWEL",
  "INTENT", "IDEALS", "HUMBLE", "HINT", "GULF", "FROCK", "EMAIL", "DIET",
  "DEVOID", "CODE", "BUNDLE", "BOUNDS", "BEDS", "AUREUS", "ARCH", "VISION",
  "VENT", "TRAMP", "TRAILS", "TOUR", "THRONG", "STORE", "STEEP", "SPOTS",
  "SCENES", "RULING", "ROOTS", "PRONE", "PLUMES", "PLOT", "PLIGHT", "PLANT",
  "PLANKS", "PICKET", "NASTY", "MIDDAY", "LUMP", "LINK", "LENS", "LEASH",
  "LEAN", "JOKES", "IODIDE", "HORRID", "HORNS", "THE", "AND", "THAT",
  "WAS", "HIS", "WITH", "HAD", "FOR", "NOT", "FROM", "BUT",
  "YOU", "HER", "HIM", "WHICH", "WERE", "ALL", "THIS", "SHE",
  "THEY", "ARE", "HAVE", "SAID", "ONE", "WHO", "WHAT", "THERE",
  "THEIR", "WHEN", "BEEN", "MAY", "THEM", "INTO", "MORE", "OUT",
  "PIERRE", "WOULD", "DID", "ONLY", "COULD", "NOW", "MAN", "ITS",
  "HAS", "WILL", "THEN", "SOME", "TIME", "AFTER", "OTHER", "ABOUT",
  "SUCH", "BEFORE", "VERY", "HOW", "SHOULD", "OVER", "YOUR", "THESE",
  "NEW", "THAN", "ANY", "THOSE", "OLD", "FIRST", "ANDREW", "MEN",
  "TWO", "DOWN", "UPON", "SEE", "CAN", "LIKE", "OUR", "SAME",
  "KNOW", "WENT", "MADE", "LITTLE", "LONG", "CAME", "WHERE", "UNDER",
  "MUST", "EVEN", "COME", "STILL", "BEING", "MOST", "AGAIN", "WAY",
  "AWAY", "LEFT", "DAY", "BEGAN", "GREAT", "OWN", "ALSO", "ASKED",
  "ROSTOV", "WHILE", "JUST", "LOOKED", "SAY", "BACK", "WHOLE", "SHALL",
  "MOSCOW", "RIGHT", "MARY", "PART", "FELT", "SEEMED", "HERE", "YES",
  "WHY", "HAVING", "MUCH", "THOUGH", "EVERY", "HEARD", "OFF", "TAKE",
  "MANY", "ALWAYS", "SAW", "NEVER", "THREE", "DON", "TOOK", "ONCE",
  "LOOK", "UNITED", "THINK", "FOUND", "TOO", "MET", "MIGHT", "BOTH",
  "SMALL", "GIVE", "LET", "MAKE", "DURING", "TURNED", "QUITE", "KNEW",
  "TELL", "TOLD", "WHOM", "YET", "LARGE", "GET", "HOLMES", "END",
  "FEW", "AMONG", "CALLED", "DEAR", "SONYA", "SEEN", "OFTEN", "GAVE",
  "TAKEN", "PUT", "LAW", "DONE", "SOON", "FREE", "KNOWN", "EACH",
  "BECOME", "FAR", "ALONG", "SAT", "BEHIND", "STOOD", "GOING", "PASSED",
  "LESS", "GIVEN", "GOD", "DOES", "SON", "ALONE", "LATER", "UNTIL",
  "SET", "OPEN", "ALMOST", "WANT", "RAN", "ACT", "USE", "FIG",
  "SENT", "SOUTH", "BECAME", "WITHIN", "WOUND", "TAKING", "LEAVE", "ADDED",
  "ABOVE", "LAY", "FIND", "ANNA", "NEAR", "EITHER", "BORIS", "HIGH",
  "FOUR", "PUBLIC", "TALK", "HELD", "COMMON", "CRIED", "NOR", "GOT",
  "FIVE", "LIGHT", "CANNOT", "USED", "EVER", "ITSELF", "TWENTY", "REALLY",
  "AROUND", "SAYING", "EARLY", "PETYA", "BEST", "FULL", "BETTER", "SPEAK",
  "MEANS", "KEPT", "ASK", "DUE", "MOVED", "VASILI", "GONE", "SHORT",
  "FORMED", "CLEAR", "LONGER", "READY", "HELP", "AIR", "RODE", "MYSELF",
  "TRIED", "BEYOND", "LOST", "TUMOUR", "ANYONE", "ACROSS", "TEN", "READ",
  "RATHER", "CLOSE", "SPOKE", "HAPPY", "BESIDE", "OPENED", "MAKING", "COMING",
  "TILL", "DEEP", "WANTED", "THUS", "RAISED", "WISHED", "SEEING", "TRUE",
  "OCCUR", "KIND", "WON", "ELSE", "ABLE", "CALL", "LOWER", "LED",
  "YORK", "LEAST", "RUSSIA", "LOCAL", "MERELY", "WHOSE", "TURN", "WOUNDS",
  "LAID", "GIVING", "SOFT", "HEAR", "PLACED", "TRYING", "DARK", "HARD",
  "DOING", "SIR", "FELL", "SIX", "NEARLY", "FINE", "ENOUGH", "CLOSED",
  "HARDLY", "PLEASE", "MEET", "HUMAN", "FRANCE", "THIN", "GREW", "HELENE",
  "BRING", "EXCEPT", "FACES", "FEEL", "FRESH", "SMILED", "PUS", "BAD",
  "PASS", "TAKES", "OCCURS", "EUROPE", "DREW", "GLAD", "GEORGE", "CHANGE",
  "APPEAR", "SHOWED", "FIXED", "DRAWN", "SAYS", "STRUCK", "RUN", "MOVING",
  "KEEP", "REMAIN", "SIMPLE", "INDEED", "HEAVY", "MARKED", "ILL", "LEAD",
  "AGE", "LIVING", "SEEMS", "SLOWLY", "SEVEN", "LOW", "DRY", "INJURY",
  "TENDON", "PAY", "LOVED", "LIVE", "EIGHT", "WAIT", "BROKEN", "THIRTY",
  "SURE", "KISSED", "EASY", "ASKING", "FILLED", "HOT", "LYING", "MAMMA",
  "FOLLOW", "SEEM", "OUGHT", "BELOW", "SEIZED", "RUSHED", "HOLD", "EASILY",
  "DROVE", "BRIGHT", "SLEEP", "SHOWN", "MEANT", "MARYA", "LIVED", "AID",
  "MISS", "SPENT", "SAVE", "MAIN", "AIM", "AGO", "ENTER", "WILSON",
  "PAID", "FORTY", "WIDE", "THANK", "TALKED", "ASIDE", "CARRY", "REAL",
  "KNOWS", "CAUSED", "LARGER", "WALKED", "LISTEN", "GROWN", "SEND", "HAPPEN",
  "MEAN", "BERG", "BENT", "AVOID", "BEGIN", "THREW", "MUCOUS", "CROSS",
  "ACTIVE", "MARRY", "HIGHER", "COLOUR", "BROKE", "BOUND", "UNLESS", "SOUNDS",
  "POLICE", "GAZED", "FIFTY", "THROWN", "SPOKEN", "RICH", "OHIO", "SIMPLY",
  "III", "COMES", "CALM", "ALLOW", "FIRING", "CAUGHT", "STAND", "SOUGHT",
  "SIT", "SCAR", "LOOKS", "GIVES", "TRY", "EBOOK", "ASLEEP", "WRITE",
  "RARELY", "PER", "KINDLY", "DIE", "BEAR", "REACH", "PRETTY", "APART",
  "TWICE", "TAX", "NEARER", "JAMES", "HUSSAR", "FORGET", "AMID", "WATSON",
  "RARE", "DIED", "TIKHON", "SEA", "PROVE", "FORTH", "BIG", "VOL",
  "SOCIAL", "PUSHED", "ADAMS", "PROVED", "PARIS", "HANDED", "DYING", "PRAY",
  "PAUSED", "NEEDED", "MAJOR", "THICK", "DEEPLY", "BURNED", "BUILT", "AGREE",
  "SELDOM", "LONDON", "JOINED", "FORCED", "ANTI", "WALK", "VERA", "TUSHIN",
  "MAINLY", "LIKED", "BURSA", "TALL", "STAY", "SHED", "SECURE", "LIT",
  "GROW", "WORN", "SAC", "FIRMLY", "CHOSEN", "OEDEMA", "LIFTED", "FALLEN",
  "RIDING", "ONTO", "BOWED", "BLAME", "ASSUME", "ALIVE", "SHOOK", "LAD",
  "MEXICO", "FULLY", "START", "RATE", "GAZING", "FREELY", "DIDN", "WORSE",
  "FINAL", "FEMUR", "DRIVEN", "WIDELY", "SLOW", "ADMIT", "SERVE", "NINE",
  "FIBRES", "FALSE", "BOSTON", "TEXAS", "SERVED", "FAILED", "CEASED", "BIT",
  "SPRANG", "MIXED", "JOIN", "WINE", "TIBIA", "FOND", "EXPECT", "EMPTY",
  "CLEAN", "WET", "TORN", "PLAYED", "GOES", "MRS", "WORE", "RAW",
  "ISSUED", "HUT", "GENTLE", "DEEPER", "ACTING", "VENOUS", "TERROR", "SIGHED",
  "PULLED", "DANIEL", "ACCEPT", "VARY", "TSAR", "SIMON", "PARTLY", "MERRY",
  "HELPED", "BEG", "BASED", "VARIES", "DRAW", "BUSY", "BOUGHT", "BADLY",
  "RIDE", "PURE", "MON", "MAKES", "HIGHLY", "EBOOKS", "EAT", "DRON",
  "CHOOSE", "ARMED", "ABROAD", "SUM", "REMOVE", "NICE", "MURAT", "FACED",
  "TEND", "SHOUTS", "RAISE", "PETER", "ISN", "FOUGHT", "FIT", "WATCH",
  "WAITED", "VIENNA", "URGED", "SEATED", "SAVED", "RADIUM", "PISTOL", "LOSE",
  "HENRY", "SHOWS", "SHAPED", "PAPA", "JUMPED", "EAGER", "BUY", "ATTAIN",
  "SOLD", "HART", "GRAVE", "FLEW", "FINISH", "DOUBLE", "THROW", "TENDS",
  "RATES", "NOBLE", "IRISH", "AROSE", "THY", "SAFE", "PFUEL", "MONROE",
  "HIP", "GAP", "EXTEND", "BITTER", "BEGINS", "BEATEN", "YOURS", "UNLIKE",
  "SEROUS", "POLISH", "NODDED", "LOUDLY", "INDIAN", "BORE", "BEAT", "OLDER",
  "NAMELY", "HUNG", "GAINED", "CATCH", "PROUD", "JUNE", "EXIST", "EASE",
  "TWELVE", "NEEDS", "MADAME", "INSIDE", "DARE", "BOW", "APPLY", "AHEAD",
  "WISHES", "TOP", "THOU", "SOFTLY", "SETTLE", "RID", "REFUSE", "OBTAIN",
  "JOSEPH", "HAY", "DAVOUT", "SHONE", "ROLLED", "NON", "MATCH", "HOPES",
  "FILL", "FASCIA", "FACING", "ELSON", "DEPEND", "WORKED", "TIRED", "TIED",
  "SIGNED", "SHUT", "RAY", "PACKED", "NEWLY", "JULY", "HIDE", "HEAL",
  "FLED", "FAIL", "ELDER", "DOESN", "BURN", "BORNE", "AET", "WANTS",
  "VIII", "THIGH", "STAYED", "SLEIGH", "PICKED", "OIL", "LEANED", "ILYIN",
  "FLY", "ENDED", "AFFECT", "WIN", "SWEPT", "SEEK", "PAYING", "NAMED",
  "LUPUS", "LEAVES", "LEARN", "HOPED", "GAILY", "FUR", "DIRTY", "COVER",
  "CEASE", "BURSAE", "BORN", "RECALL", "OREGON", "HEADED", "GENTLY", "AXILLA",
  "ALIKE", "ACTED", "YIELD", "WORST", "WHIGS", "UNITE", "TAFT", "STICK",
  "PACED", "NOBODY", "MAD", "GUMMA", "GROIN", "GRASP", "GRAFTS", "FIRED",
  "BOLDLY", "SWEET", "STIR", "SLEPT", "SCARS", "SANK", "OURS", "LOT",
  "INTRA", "FLYING", "CLOSER", "APT", "XVI", "VII", "STRICT", "SANG",
  "HURT", "CHOSE", "BEGGED", "ARTHUR", "VOUS", "VARIX", "THOMAS", "SOONER",
  "RIDDEN", "RHODE", "RESIST", "POURED", "PERI", "ILYA", "DECIDE", "DARED",
  "CAB", "APRIL", "VILNA", "SPEND", "SIRE", "SAVING", "RUBBED", "LOUDER",
  "LIPOMA", "LINED", "LIFT", "LEADS", "KEEN", "INFORM", "HENCE", "FLEXED",
  "ESAUL", "DRUNK", "CHRIST", "TREAT", "SUBMIT", "SEIZE", "RETAIN", "PERMIT",
  "LASTED", "HAIRED", "FEELS", "AGED", "WEAR", "SLOUGH", "SIXTY", "SELL",
  "RISEN", "MEDIAL", "HERS", "GROWS", "FLUNG", "EVE", "DENIED", "DAM",
  "CUBA", "WAVED", "STATED", "RETIRE", "RANG", "OBEY", "MINOR", "HTTP",
  "HIDDEN", "FETCH", "FEE", "EXISTS", "EST", "ELDEST", "DUTCH", "DEFEND",
  "DAMP", "CALLS", "ATTEND", "XIV", "XII", "WOULDN", "UHLANS", "SWAYED",
  "RESTED", "RENDER", "MISSED", "LOADED", "KANSAS", "HID", "HALTED", "GROSS",
  "DROPS", "CANADA", "CALMLY", "BRAVE", "BOWING", "ARRIVE", "ARISE", "ALOUD",
  "WEPT", "VOLS", "TEACH", "SUNK", "STABLE", "RUNS", "NAEVUS", "MANAGE",
  "LOCKED", "LEE", "LAYING", "KALUGA", "FORGOT", "FLOWED", "FIX", "FASTER",
  "ENDURE", "COLDLY", "CLAIR", "AMUSED", "ADD", "UPSET", "TURNS", "THEE",
  "SEES", "SAMUEL", "ROW", "ROBERT", "PUNISH", "PRAYED", "POLAND", "PLATON",
  "PACING", "ORG", "MOB", "MAVRA", "ITALY", "INN", "INDIA", "EASIER",
  "DRIED", "DEALT", "DANCED", "TURNER", "THINKS", "SHARED", "SELECT", "REPEAT",
  "PORTO", "LEST", "ILAGIN", "HUM", "HOSMER", "FUN", "FALLS", "FAIRLY",
  "ENSUES", "DRANK", "CHER", "BRYAN", "BAR", "WISE", "WEAKER", "TIPTOE",
  "SURELY", "STARED", "SMART", "SLIP", "SCOTT", "ROUSED", "RISES", "RICO",
  "RHETOR", "REGRET", "PANAMA", "OPENLY", "OCCUPY", "LINING", "LESSER", "JONES",
  "HOPING", "HIDING", "FOLDED", "FED", "ENJOY", "ENABLE", "EATING", "DIM",
  "CARIES", "BIER", "AWAKE", "ASSURE", "AIMS", "AFRICA", "WHENCE", "WASTE",
  "WASHED", "SUB", "STOLEN", "SHOUT", "PULL", "PAS", "NEURO", "LONGED",
  "INDUCE", "HONEST", "FROWN", "FOLD", "FOG", "FLEXOR", "FITTED", "FINDS",
  "DIMLY", "DASHED", "BURKE", "BLIND", "BELONG", "BAY", "XIII", "WAX",
  "VOTED", "RYAZAN", "PASSES", "PARTED", "OLMUTZ", "NEGRO", "MACK", "LATELY",
  "GETS", "FILE", "ENSUE", "DRISSA", "CATGUT", "ADDING", "VIEWED", "VEXED",
  "VESTED", "UTAH", "TAUGHT", "SMITH", "SHY", "RELATE", "REDUCE", "PREFER",
  "POSTED", "POSE", "PERISH", "PARDON", "OGG", "NIEMEN", "MINDED", "MAINE",
  "LOVES", "LENT", "JAPAN", "HIT", "HANDLE", "FOE", "ETC", "ELEVEN",
  "EIGHTY", "BURIED", "ATE", "ASKS", "WWW", "WRITES", "WOKE", "WASTED",
  "VYAZMA", "TELLS", "STUCK", "SAN", "PURELY", "PROVES", "POUR", "PLEXUS",
  "PICK", "PAD", "OWE", "ODOUR", "LOYAL", "LIVELY", "IOWA", "FAILS",
  "EYED", "DORSUM", "CARES", "BLEED", "BALAGA", "AFFORD", "XVIII", "WAKING",
  "VIVE", "THORAX", "SWEAT", "SUNDAY", "STONER", "STANDS", "SOLVED", "SOLELY",
  "SOB", "SCARED", "PUSH", "POLITE", "MAKAR", "JOKING", "INDIES", "HARDER",
  "GATHER", "DINED", "COMPLY", "BEHAVE", "AWOKE", "AREN", "AIMED", "ADVISE",
  "ABBE", "XVII", "WIPED", "WHIG", "WAVING", "VANITY", "TRULY", "TORE",
  "SPRAIN", "SOLVE", "SEMI", "RYE", "RECUR", "PITI", "LOSES", "LES",
  "KIEV", "JAY", "IRENE", "INVADE", "FIXING", "ENDING", "EATEN", "DAVIS",
  "DAKOTA", "CLUNG", "BORZOI", "BEND", "BEARS", "AWAIT", "ADOPT", "XIX",
  "WRUNG", "WRATH", "WIPING", "WIDER", "ULNAR", "TRACKS", "TORIES", "TOLLY",
  "SPLINT", "SOAKED", "SCHON", "RUM", "RESTS", "RATTLE", "PLAYS", "PAGET",
  "OWNED", "OSTEO", "NOTED", "MOUNT", "MOREL", "MONDAY", "MERGED", "LOWEST",
  "LATIN", "LATEST", "HANG", "GUIDED", "GUESS", "EVOKED", "ERECT", "ENSUED",
  "EMPLOY", "DIES", "DEN", "DANUBE", "CREATE", "COMMIT", "COMAN", "BUILD",
  "BOILS", "BOIL", "BET", "ALTER", "AIDED", "ZNAIM", "VASKA", "URGING",
  "TILSIT", "TESTED", "SLY", "SERF", "SCHOSS", "RHODES", "QUE", "PGLAF",
  "PAUL", "ORLOV", "MORRIS", "KARAY", "HEALED", "HANGED", "GAS", "FRO",
  "FREED", "FEWER", "EXPOSE", "ENTERS", "DULY", "DEWEY", "DERIVE", "BURSAL",
  "AROUSE", "ARGUED", "ANISYA", "AMAZED", "ADORED", "ADLER", "WIT", "WHOLLY",
  "WATTLE", "VALUED", "TYLER", "TOLLER", "TIE", "TERMED", "SUITED", "SHOOT",
  "SHAN", "SERVES", "SERGEY", "SEALED", "REVEAL", "REP", "PRE", "PITT",
  "PIT", "LANDED", "HUDSON", "HEED", "HEATED", "HAWAII", "FIBULA", "DUG",
  "DORSAL", "DIFFER", "BUYING", "BOILED", "BLUNT", "AWHILE", "ARISES", "ALBANY",
  "WASN", "TOIL", "THEIRS", "SWUNG", "SUPRA", "SPY", "SOFTEN", "SHAKE",
  "SCREAM", "SANTA", "SABERS", "RULED", "ROSS", "RENEW", "REGAIN", "QUIT",
  "PROOFS", "PROMPT", "POLK", "PITIED", "PENN", "PATTED", "OWED", "OPPOSE",
  "OFFERS", "MUSTN", "LONGUS", "LID", "KREMS", "KNIT", "KLAPP", "KELOID",
  "KEENLY", "JERKED", "HINDER", "GUT", "GROANS", "GOVERN", "FITS", "FISKE",
  "FIBRO", "ERIE", "ENSURE", "DONATE", "DIVIDE", "DIRT", "DINE", "DEEMED",
  "DEDUCE", "CYRIL", "CONFER", "CLAD", "CHOKED", "CARED", "BRODIE", "AMUSE",
  "XXI", "WAGED", "TUNICA", "TROYKA", "TRACED", "TOSSED", "THIERS", "TENO",
  "SOBBED", "PURSUE", "PIERCE", "NEVADA", "NAPLES", "MORAN", "MILKA", "MELTED",
  "LOWELL", "LASTLY", "LACKED", "IOGEL", "HORNER", "HERNIA", "EARN", "DOMO",
  "DMITRI", "DEFINE", "CURLED", "CONVEY", "COFFIN", "CLARK", "CEASES", "BOONE",
  "BLAMED", "BITTEN", "BERLIN", "ASSIST", "ALICE", "ALERT", "VARIED", "ULM",
  "TUCKED", "TREAD", "TOUT", "SPRUNG", "SPECIE", "SPARED", "SODDEN", "SHYLY",
  "RYDER", "ROME", "RIFLE", "RICHER", "RHINE", "QUINCY", "PLATOV", "PIPS",
  "OREL", "MOORE", "LODGED", "LINKED", "LASCAR", "KARP", "IMPLY", "HUE",
  "HINTS", "HEARTY", "HEALS", "HAYES", "HADN", "GOUT", "GLEAM", "FULLER",
  "FRAMED", "FORGE", "FLUSH", "FILLS", "FIGS", "ESTEEM", "EMBOLI", "ELECT",
  "EDMUND", "DRIVES", "DREAD", "DORAN", "DIEU", "DEVOTE", "DENSER", "DEITY",
  "COT", "CHART", "CELL", "BUSTLE", "BUREN", "BRUNN", "BLOWN", "BLISS",
  "BELT", "BELOVA", "BEINGS", "BAST", "BARON", "ANYHOW", "ALASKA", "YAKOV",
  "WRITS", "WOLVES", "WENS", "WATERY", "VON", "VIVID", "VISITS", "VEILED",
  "UNDULY", "TUT", "TRIFLE", "TRADES", "TOPIC", "TOKEN", "TINT", "THREAT",
  "TAYLOR", "SWAY", "STUFF", "STOKE", "STITCH", "STAIR", "SPLEEN", "SPEAKS",
  "SNUFF", "SMOKED", "SHORE", "SHAVED", "SHAKEN", "SETS", "SENSES", "SCREW",
  "SCAB", "SAFELY", "RURAL", "RIOT", "REVOIR", "RESUME", "RESORT", "RELY",
  "REIN", "RATIO", "RAIL", "RADIUS", "PUFF", "PSOAS", "PSEUDO", "PRIME",
  "POPE", "POLES", "PLEURA", "PINCH", "PAXSON", "PASTE", "PALLOR", "PACKET",
  "OXFORD", "OVAL", "OOZING", "OOH", "OFFSET", "NULL", "NOSED", "NEATLY",
  "MUTTON", "MOUTHS", "MOSTLY", "MERITS", "MATRIX", "MARIE", "LOGIC", "LODGES",
  "LESSON", "LEND", "LEGGED", "LAP", "LACE", "KEEPS", "JOB", "JESUS",
  "IRONIC", "HINTED", "HEMP", "HEARS", "GRUDGE", "GROOVE", "GROAN", "GRADE",
  "GLADLY", "GASPED", "FUSS", "FRIDAY", "FORBID", "FLEE", "FLARED", "FINEST",
  "FINELY", "FETE", "FAVORS", "ENACT", "DUC", "DRYING", "DRUMS", "DRED",
  "DRAM", "DOWRY", "DOINGS", "DISHES", "CREW", "COULDN", "CORTEX", "COOL",
  "COMBAT", "CENTS", "CASH", "BRIONY", "BRIDE", "BOATS", "BLEW", "BLADE",
  "BIBLE", "BETRAY", "BELLY", "BARRED", "AWE", "AVERT", "ASHES", "ASCII",
  "APPLE", "AGENCY", "AFRESH", "XXII", "WORRY", "WONT", "WINGS", "WIDOW",
  "WANDER", "WALKS", "VALID", "VACANT", "USAGE", "URGE", "UNJUST", "UNIT",
  "UNFAIR", "TRAUMA", "TIBIAL", "THUD", "THENCE", "TARTAR", "TAPPED", "TAP",
  "SURVEY", "SUNKEN", "STURDY", "STRODE", "STARK", "SPOIL", "SPARKS", "SOFTER",
  "SHRANK", "SEPSIS", "SCANTY", "SATIN", "SANTO", "SALES", "RUMOR", "ROPES",
  "ROD", "RIVALS", "RICHES", "REPAY", "REGIME", "RAPP", "QUEBEC", "PRIZE",
  "POROUS", "POLLS", "POETRY", "PLEDGE", "PLANTS", "PALMAR", "OVARY", "ORATOR",
  "NOTING", "NOISY", "NODULE", "NEY", "NAEVI", "MYXOMA", "MOAN", "MISTY",
  "MESS", "MEEKLY", "LOOPS", "LOAN", "LLOYD", "LIQUID", "LEAPED", "LASTS",
  "LADEN", "LABOUR", "KARL", "JUDGED", "JOLTED", "INVENT", "INTIMA", "INSIST",
  "HORACE", "HEY", "HEIR", "HATS", "HASTEN", "GIRTH", "GANG", "FURS",
  "FRIEZE", "FORMAT", "FOLKS", "FOES", "FLASH", "FEED", "FEEBLY", "EUSOL",
  "ERA", "ENTITY", "ENNS", "ELDERS", "ECZEMA", "EARNED", "DUSK", "DUCTS",
  "DRAG", "DISK", "DIAM", "DEW", "DES", "DENY", "DEAF", "DEACON",
  "DAVID", "CURLS", "CUBAN", "COVERS", "COSTLY", "CORPUS", "CORNS", "COCCI",
  "CLOTS", "CLAMOR", "CITED", "CALLUS", "BRUIT", "BRISK", "BRINGS", "BRED",
  "BOWELS", "BOSSES", "BORED", "BLESS", "BEGGAR", "BEEF", "BEAMED", "BATHED",
  "ANNE", "ANGLES", "ALLY", "ACRE", "ACHING", "ZAKHAR", "WOSTOV", "WORLDS",
  "WAIL", "VETO", "VALOR", "UVAROV", "USES", "UNWELL", "TUTORS", "TUGGED",
  "TRAGIC", "TRACT", "TOWER", "TONS", "TOAST", "TINTED"
];

const uniqueWords = [...new Set(
    words.map(word => String(word).toUpperCase().trim())
         .filter(word => /^[A-Z]{3,6}$/.test(word))
)];

/* =========================================
   RANDOM PUZZLE GENERATOR
========================================= */

function seededRandom(seed) {
    let value = seed >>> 0;

    return function() {
        value += 0x6D2B79F5;

        let result = value;
        result = Math.imul(result ^ (result >>> 15), result | 1);
        result ^= result + Math.imul(result ^ (result >>> 7), result | 61);

        return ((result ^ (result >>> 14)) >>> 0) / 4294967296;
    };
}

function shuffleArray(array, random = Math.random) {
    const result = [...array];

    for (let i = result.length - 1; i > 0; i--) {
        const j = Math.floor(random() * (i + 1));
        [result[i], result[j]] = [result[j], result[i]];
    }

    return result;
}

function sizeFor(level) {
    // Keep the board at 6 columns x 6 rows for every level.
    return 6;
}

function difficultyFor(level) {
    // Difficulty progresses by level, not by changing the grid size.
    if (level >= 501) return "hard";
    if (level >= 101) return "medium";

    return "easy";
}

function countFor(level) {
    return Math.min(10, 3 + Math.floor((level - 1) / 20));
}

function getAdLimit(level) {
    const difficulty = difficultyFor(level);

    return difficulty === "hard" ? 3 :
           difficulty === "medium" ? 2 : 1;
}

const directions = [
    [0,1], [0,-1], [1,0], [-1,0],
    [1,1], [-1,-1], [1,-1], [-1,1]
];

function createEmptyGrid(size) {
    return Array.from({ length: size }, () => Array(size).fill(""));
}

function canPlaceWord(grid, word, row, col, dr, dc) {
    const size = grid.length;

    for (let i = 0; i < word.length; i++) {
        const r = row + dr * i;
        const c = col + dc * i;

        if (r < 0 || c < 0 || r >= size || c >= size) {
            return false;
        }

        if (grid[r][c] !== "" && grid[r][c] !== word[i]) {
            return false;
        }
    }

    return true;
}

function placeWord(grid, word, random) {
    const size = grid.length;

    for (let attempt = 0; attempt < 500; attempt++) {
        const [dr, dc] = directions[
            Math.floor(random() * directions.length)
        ];

        const row = Math.floor(random() * size);
        const col = Math.floor(random() * size);

        if (!canPlaceWord(grid, word, row, col, dr, dc)) {
            continue;
        }

        const cells = [];

        for (let i = 0; i < word.length; i++) {
            const r = row + dr * i;
            const c = col + dc * i;

            grid[r][c] = word[i];
            cells.push({ row: r, col: c });
        }

        return cells;
    }

    return null;
}

function pickWords(level, size, random) {
    return shuffleArray(
        uniqueWords.filter(word => word.length <= size),
        random
    ).slice(0, countFor(level));
}

function fillEmptyCells(grid, random) {
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    for (let r = 0; r < grid.length; r++) {
        for (let c = 0; c < grid.length; c++) {
            if (!grid[r][c]) {
                grid[r][c] = alphabet[
                    Math.floor(random() * alphabet.length)
                ];
            }
        }
    }
}

function makePuzzle(level) {
    const size = sizeFor(level);
    const random = seededRandom(level * 7919 + 12345);

    const selectedWords = pickWords(level, size, random);
    const grid = createEmptyGrid(size);
    const placedWords = [];

    selectedWords.forEach(word => {
        const cells = placeWord(grid, word, random);

        if (cells) {
            placedWords.push({ word, cells });
        }
    });

    fillEmptyCells(grid, random);

    return {
        size,
        grid,
        words: placedWords
    };
}

/* =========================================
   RENDER GAME
========================================= */

function renderWordList() {
    const wordList = $("#wordList");

    if (!wordList || !currentPuzzle) return;

    wordList.innerHTML = "";

    currentPuzzle.words.forEach(item => {
        const chip = document.createElement("div");

        chip.className = "word-chip";

        if (foundWords.includes(item.word)) {
            chip.classList.add("found");
        }

        chip.textContent = item.word;
        wordList.appendChild(chip);
    });
}

function renderBoard() {
    const board = $("#board");

    if (!board || !currentPuzzle) return;

    const size = currentPuzzle.size;

    board.innerHTML = "";
    board.style.gridTemplateColumns =
        `repeat(${size}, minmax(0, 1fr))`;

    board.classList.remove(
        "grid-theme-classic",
        "grid-theme-neon",
        "grid-theme-wood"
    );

    board.classList.add("grid-theme-" + data.gridTheme);

    for (let row = 0; row < size; row++) {
        for (let col = 0; col < size; col++) {
            const cell = document.createElement("button");

            cell.type = "button";
            cell.className = "cell";
            cell.dataset.row = row;
            cell.dataset.col = col;

            const letter = currentPuzzle.grid[row][col];

            cell.textContent = data.alphabetStyle === "lower"
                ? letter.toLowerCase()
                : letter;

            board.appendChild(cell);
        }
    }

    renderWordList();
}

function startLevel(level) {
    currentLevel = Math.max(
        1,
        Math.min(TOTAL_LEVELS, Number(level) || 1)
    );

    if (currentLevel > data.unlocked) {
        currentLevel = data.unlocked;
    }

    foundWords = [];
    selectedCells = [];
    isSelecting = false;

    currentPuzzle = makePuzzle(currentLevel);

    $("#currentLevel").textContent = currentLevel;
    $("#gameMessage").textContent = uniqueWords.length
        ? "Find the words in the grid."
        : "Add your own 3-to-6 letter words in script.js to play.";
    $("#progressBar").style.width = "0%";
    $("#nextBtn").disabled = true;

    updateBasicDisplays();
    renderBoard();
    showScreen("game");
}

/* =========================================
   WORD SELECTION
========================================= */
function clearSelection() {
    $$(".cell.selected").forEach(cell => {
        cell.classList.remove("selected");
    });

    selectedCells = [];
}

function getCellElement(row, col) {
    return $(
        `#board .cell[data-row="${row}"][data-col="${col}"]`
    );
}

function selectCell(row, col) {
    const cell = getCellElement(row, col);
    if (!cell) return;

    if (selectedCells.some(item =>
        item.row === row && item.col === col
    )) return;

    selectedCells.push({ row, col });
    cell.classList.add("selected");
}

function checkSelectedWord() {
    if (!currentPuzzle || selectedCells.length < 2) {
        clearSelection();
        return;
    }

    const samePath = (a, b) =>
        a.length === b.length &&
        a.every((p, i) =>
            p.row === b[i].row &&
            p.col === b[i].col
        );

    const reversePath = [...selectedCells].reverse();

    const matched = currentPuzzle.words.find(item =>
        !foundWords.includes(item.word) &&
        (
            samePath(item.cells, selectedCells) ||
            samePath(item.cells, reversePath)
        )
    );

    if (matched) {
        foundWords.push(matched.word);

        matched.cells.forEach(position => {
            const cell = getCellElement(
                position.row,
                position.col
            );

            if (cell) cell.classList.add("found");
        });

        playClickSound();
        renderWordList();
        updateProgress();
    }

    clearSelection();
}

/* =========================================
   LEVEL PROGRESS AND COMPLETION
========================================= */

function updateProgress() {
    if (!currentPuzzle) return;

    const total = currentPuzzle.words.length;
    const found = foundWords.length;

    const percentage = total > 0
        ? (found / total) * 100
        : 0;

    const progressBar = $("#progressBar");

    if (progressBar) {
        progressBar.style.width = percentage + "%";
    }

    if (total > 0 && found >= total) {
        completeLevel();
    }
}

function completeLevel() {
    if (!data.completed.includes(currentLevel)) {
        data.completed.push(currentLevel);
        data.coins += 2;
    }

    if (currentLevel < TOTAL_LEVELS) {
        data.unlocked = Math.max(
            data.unlocked,
            currentLevel + 1
        );
    }

    saveData();
    updateBasicDisplays();

    showGameMessage("Level Completed! 🎉");

    const nextButton = $("#nextBtn");

    if (nextButton) {
        nextButton.disabled = currentLevel >= TOTAL_LEVELS;
    }

    showToast("Level completed! You earned 2 coins.");
}



/* =========================================
   LEVEL SELECTION
========================================= */

function renderLevels(reset = false) {
    const grid = $("#levelGrid");

    if (!grid) return;

    // Keep all 1,000 level buttons inside a scrollable area on mobile.
    grid.style.maxHeight = "calc(100dvh - 190px)";
    grid.style.overflowY = "auto";
    grid.style.overscrollBehavior = "contain";
    grid.style.alignContent = "start";

    if (reset) {
        grid.innerHTML = "";
        nextLevelToRender = 1;
    }

    const end = Math.min(
        TOTAL_LEVELS,
        nextLevelToRender + LEVEL_BATCH_SIZE - 1
    );

    for (
        let level = nextLevelToRender;
        level <= end;
        level++
    ) {
        const card = document.createElement("button");

        card.type = "button";
        card.className = "level-card";

        const unlocked = level <= data.unlocked;
        const completed = data.completed.includes(level);

        if (!unlocked) card.classList.add("locked");
        if (completed) card.classList.add("completed");

        card.textContent = completed
            ? `✓ ${level}`
            : unlocked ? level : `🔒 ${level}`;

        card.disabled = !unlocked;

        if (unlocked) {
            card.addEventListener("click", () => {
                startLevel(level);
            });
        }

        grid.appendChild(card);
    }

    nextLevelToRender = end + 1;
}

function loadMoreLevels() {
    if (nextLevelToRender <= TOTAL_LEVELS) {
        renderLevels(false);
    }
}

/* =========================================
   HINTS
========================================= */

function showGameMessage(message) {
    $("#gameMessage").textContent = message;
}

function revealHint() {
    if (!currentPuzzle) return;

    const remaining = currentPuzzle.words.filter(
        item => !foundWords.includes(item.word)
    );

    if (!remaining.length) return;

    const firstCell = remaining[0].cells[0];

    const cell = getCellElement(
        firstCell.row,
        firstCell.col
    );

    if (cell) {
        cell.classList.add("hint-highlight");

        setTimeout(() => {
            cell.classList.remove("hint-highlight");
        }, 1800);
    }

    showGameMessage(
        "Hint: Look for a word starting with " +
        remaining[0].word[0]
    );
}

function requestRewardedHint() {
    if (pendingRewardedHint) return;

    if (!navigator.onLine) {
        showModal(
            "You are Offline",
            "You're offline. Please connect to the internet to watch an ad and get a hint."
        );
        return;
    }

    const ads = window.AndroidAds;

    if (!ads || typeof ads.showRewardedAd !== "function") {
        showModal(
            "Ad Not Available",
            "Rewarded ad is not ready. Please try again later."
        );
        return;
    }

    const watched = Number(
        data.hintAdsWatched[currentLevel] || 0
    );

    if (watched >= getAdLimit(currentLevel)) {
        showModal(
            "Hint Limit Reached",
            "You have reached the ad hint limit for this level."
        );
        return;
    }

    pendingRewardedHint = true;

    try {
        ads.showRewardedAd();
    } catch (error) {
        pendingRewardedHint = false;

        showModal(
            "Ad Error",
            "The ad could not be opened. Please try again."
        );
    }
}

function useHint() {
    if (data.hints > 0) {
        data.hints--;

        saveData();
        updateHintDisplay();
        revealHint();
    } else {
        requestRewardedHint();
    }
}

window.onRewardedAdCompleted = function() {
    if (!pendingRewardedHint) return;

    pendingRewardedHint = false;

    data.hintAdsWatched[currentLevel] =
        Number(data.hintAdsWatched[currentLevel] || 0) + 1;

    data.hints += 1;

    saveData();
    updateHintDisplay();
    revealHint();

    showModal(
        "Hint Received!",
        "Your rewarded ad was completed. You received 1 hint."
    );
};

window.onRewardedAdFailed = function() {
    pendingRewardedHint = false;

    showModal(
        "Ad Not Completed",
        "You did not receive a hint. Please try again."
    );
};

/* =========================================
   THEMES AND SETTINGS
========================================= */

function applyTheme() {
    // CSS uses body.light, so JavaScript must use the same class.
    document.body.classList.toggle(
        "light",
        data.theme === "light"
    );

    const button = $("#themeBtn");

    if (button) {
        button.textContent = data.theme === "dark"
            ? "Switch to Light Mode"
            : "Switch to Dark Mode";
    }
}

function applyGridTheme() {
    const board = $("#board");

    if (!board) return;

    board.classList.remove(
        "grid-theme-classic",
        "grid-theme-neon",
        "grid-theme-wood"
    );

    board.classList.add("grid-theme-" + data.gridTheme);
}

function applyAlphabetStyle() {
    const board = $("#board");

    if (!board) return;

    $$("#board .cell").forEach(cell => {
        cell.textContent = data.alphabetStyle === "lower"
            ? cell.textContent.toLowerCase()
            : cell.textContent.toUpperCase();
    });
}

function updateSettingsButtons() {
    const soundButton = $('[data-setting="sound"]');
    const musicButton = $('[data-setting="music"]');

    if (soundButton) {
        soundButton.textContent = data.sound ? "ON" : "OFF";
        soundButton.classList.toggle("on", data.sound);
        soundButton.classList.toggle("off", !data.sound);
    }

    if (musicButton) {
        musicButton.textContent = data.music ? "ON" : "OFF";
        musicButton.classList.toggle("on", data.music);
        musicButton.classList.toggle("off", !data.music);
    }

    applyTheme();

    $$("[data-grid-theme]").forEach(button => {
        const selected =
            button.dataset.gridTheme === data.gridTheme;

        button.classList.toggle("selected", selected);

        const action = button.querySelector(".option-action");

        if (action) {
            action.textContent = selected
                ? "SELECTED"
                : button.dataset.gridTheme === "classic"
                    ? "FREE"
                    : "🪙 1,000";
        }
    });

    $$("[data-alphabet-style]").forEach(button => {
        const selected =
            button.dataset.alphabetStyle === data.alphabetStyle;

        button.classList.toggle("selected", selected);

        const action = button.querySelector(".option-action");

        if (action) {
            action.textContent = selected
                ? "SELECTED"
                : button.dataset.alphabetStyle === "upper"
                    ? "FREE"
                    : "🪙 500";
        }
    });
}

function selectGridTheme(theme) {
    if (
        !["classic", "neon", "wood"].includes(theme) ||
        data.gridTheme === theme
    ) {
        return;
    }

    const price = theme === "classic" ? 0 : 1000;

    if (data.coins < price) {
        showModal(
            "Not Enough Coins",
            `You need ${price} coins to unlock this theme.`
        );
        return;
    }

    data.coins -= price;
    data.gridTheme = theme;

    saveData();
    updateBasicDisplays();
    applyGridTheme();
    updateSettingsButtons();
}

function selectAlphabetStyle(style) {
    if (
        !["upper", "lower"].includes(style) ||
        data.alphabetStyle === style
    ) {
        return;
    }

    const price = style === "lower" ? 500 : 0;

    if (data.coins < price) {
        showModal(
            "Not Enough Coins",
            "You need 500 coins to unlock small letters."
        );
        return;
    }

    data.coins -= price;
    data.alphabetStyle = style;

    saveData();
    updateBasicDisplays();
    applyAlphabetStyle();
    updateSettingsButtons();
}

/* =========================================
   SOUND EFFECTS
========================================= */

function playClickSound() {
    if (!data.sound) return;

    try {
        const AudioContextClass =
            window.AudioContext || window.webkitAudioContext;

        if (!AudioContextClass) return;

        soundContext = soundContext || new AudioContextClass();

        if (soundContext.state === "suspended") {
            soundContext.resume().catch(() => {});
        }

        const oscillator = soundContext.createOscillator();
        const gain = soundContext.createGain();

        oscillator.type = "sine";
        oscillator.frequency.value = 620;

        gain.gain.setValueAtTime(
            0.07,
            soundContext.currentTime
        );

        gain.gain.exponentialRampToValueAtTime(
            0.001,
            soundContext.currentTime + 0.09
        );

        oscillator.connect(gain);
        gain.connect(soundContext.destination);

        oscillator.start();
        oscillator.stop(soundContext.currentTime + 0.09);

    } catch (error) {
        console.warn("Sound unavailable.", error);
    }
}

/* =========================================
   BACKGROUND MUSIC
========================================= */

async function startBackgroundMusic() {
    if (!data.music || document.hidden || backgroundAudio) {
        return;
    }

    const AudioContextClass =
        window.AudioContext || window.webkitAudioContext;

    if (!AudioContextClass) {
        console.warn("Web Audio is not supported.");
        return;
    }

    try {
        const context = new AudioContextClass();
        const master = context.createGain();

        master.gain.value = 0.50;
        master.connect(context.destination);

        backgroundAudio = {
            context,
            master
        };

        if (context.state === "suspended") {
            await context.resume();
        }

        if (!backgroundAudio || !data.music || document.hidden) {
            stopBackgroundMusic();
            return;
        }

        const notes = [
            261.63, 329.63, 392.00, 329.63,
            293.66, 349.23, 392.00, 349.23
        ];

        let noteIndex = 0;

        function playNote() {
            if (
                !backgroundAudio ||
                !data.music ||
                document.hidden ||
                context.state !== "running"
            ) {
                return;
            }

            const oscillator = context.createOscillator();
            const volume = context.createGain();

            oscillator.type = "sine";
            oscillator.frequency.value = notes[noteIndex];

            volume.gain.setValueAtTime(
                0.0001,
                context.currentTime
            );

            volume.gain.linearRampToValueAtTime(
                0.20,
                context.currentTime + 0.08
            );

            volume.gain.exponentialRampToValueAtTime(
                0.0001,
                context.currentTime + 0.48
            );

            oscillator.connect(volume);
            volume.connect(master);

            oscillator.start();
            oscillator.stop(context.currentTime + 0.5);

            noteIndex = (noteIndex + 1) % notes.length;
        }

        playNote();

        musicTimer = setInterval(playNote, 500);

    } catch (error) {
        console.warn("Music unavailable:", error);
        stopBackgroundMusic();
    }
}

function stopBackgroundMusic() {
    if (musicTimer) {
        clearInterval(musicTimer);
        musicTimer = null;
    }

    if (backgroundAudio) {
        const context = backgroundAudio.context;

        backgroundAudio = null;

        try {
            context.close().catch(() => {});
        } catch (error) {
            console.warn("Could not close audio context.", error);
        }
    }
}

/* =========================================
   MUSIC VISIBILITY EVENTS
========================================= */

document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
        stopBackgroundMusic();
    } else if (data.music) {
        startBackgroundMusic();
    }
});

window.addEventListener("pagehide", stopBackgroundMusic);

window.addEventListener("pageshow", () => {
    if (data.music && !document.hidden) {
        startBackgroundMusic();
    }
});

/* =========================================
   RESET GAME
========================================= */

function resetGame() {
    showModal(
        "Reset game data?",
        "This will erase completed levels and coins and restore 5 free hints."
    );

    const ok = $("#modalOk");

    if (ok) {
        ok.onclick = () => {
            data = {
                ...defaults,
                hints: 5,
                completed: [],
                hintAdsWatched: {}
            };

            currentLevel = 1;
            currentPuzzle = null;
            foundWords = [];
            selectedCells = [];
            pendingRewardedHint = false;

            stopBackgroundMusic();
            saveData();
            updateBasicDisplays();
            updateSettingsButtons();
            renderLevels(true);
            closeModal();
            showScreen("home");

            showToast("Game reset. You have 5 free hints.");
        };
    }
}

/* =========================================
   SHARE GAME
========================================= */

function shareGame() {
    const shareData = {
        title: "WORD ZENTO PUZZLE",
        text: "Play WORD ZENTO PUZZLE and challenge your mind!"
    };

    if (navigator.share) {
        navigator.share(shareData).catch(() => {});
    } else if (
        navigator.clipboard &&
        navigator.clipboard.writeText
    ) {
        navigator.clipboard.writeText(shareData.text)
            .then(() => showToast("Sharing text copied."))
            .catch(() => showModal("Share Game", shareData.text));
    } else {
        showModal("Share Game", shareData.text);
    }
}

/* =========================================
   BUTTON EVENTS
========================================= */

function on(selector, event, callback) {
    const element = $(selector);

    if (element) {
        element.addEventListener(event, callback);
    }
}

on("#startBtn", "click", () => {
    playClickSound();
    startBackgroundMusic();
    renderLevels(true);
    showScreen("levels");
});

on("#settingsBtn", "click", () => {
    playClickSound();
    updateSettingsButtons();
    showScreen("settings");
    startBackgroundMusic();
});

on("#homeShare", "click", shareGame);

on("#levelsBack", "click", () => {
    playClickSound();
    showScreen("home");
});

on("#settingsBack", "click", () => {
    playClickSound();
    showScreen("home");
});

on("#gameBack", "click", () => {
    playClickSound();
    renderLevels(true);
    showScreen("levels");
});

on("#restartBtn", "click", () => {
    playClickSound();
    startLevel(currentLevel);
});

on("#nextBtn", "click", () => {
    if (currentLevel < TOTAL_LEVELS) {
        playClickSound();
        startLevel(currentLevel + 1);
    }
});

on("#hintBtn", "click", () => {
    playClickSound();
    useHint();
});

/* =========================================
   SOUND ON/OFF
========================================= */

$$('[data-setting="sound"]').forEach(button => {
    button.addEventListener("click", () => {
        data.sound = !data.sound;

        saveData();
        updateSettingsButtons();

        if (data.sound) {
            playClickSound();
        }
    });
});

/* =========================================
   MUSIC ON/OFF - ONLY ONE EVENT
========================================= */

$$('[data-setting="music"]').forEach(button => {
    button.addEventListener("click", async () => {
        data.music = !data.music;

        saveData();
        updateSettingsButtons();

        if (data.music) {
            await startBackgroundMusic();
        } else {
            stopBackgroundMusic();
        }
    });
});

/* =========================================
   DARK / LIGHT THEME
========================================= */

on("#themeBtn", "click", () => {
    data.theme = data.theme === "dark" ? "light" : "dark";

    saveData();
    applyTheme();
    playClickSound();
});

/* =========================================
   RESET AND MODAL
========================================= */

on("#resetBtn", "click", resetGame);

on("#modalCancel", "click", closeModal);

on("#modalOk", "click", closeModal);

on("#modal", "click", event => {
    if (event.target.id === "modal") {
        closeModal();
    }
});

/* =========================================
   CUSTOMIZATION EVENTS
========================================= */

$$("[data-grid-theme]").forEach(button => {
    button.addEventListener("click", () => {
        selectGridTheme(button.dataset.gridTheme);
    });
});

$$("[data-alphabet-style]").forEach(button => {
    button.addEventListener("click", () => {
        selectAlphabetStyle(button.dataset.alphabetStyle);
    });
});

/* =========================================
   GRID WORD SELECTION
========================================= */

const boardElement = $("#board");

if (boardElement) {
    boardElement.style.touchAction = "none";

    boardElement.addEventListener("pointerdown", event => {
        const cell = event.target.closest(".cell");
        if (!cell) return;

        event.preventDefault();

        isSelecting = true;
        clearSelection();

        selectCell(
            Number(cell.dataset.row),
            Number(cell.dataset.col)
        );
    });

    document.addEventListener("pointermove", event => {
        if (!isSelecting) return;

        const element = document.elementFromPoint(
            event.clientX,
            event.clientY
        );

        const cell = element?.closest(".cell");

        if (!cell || !boardElement.contains(cell)) return;

        selectCell(
            Number(cell.dataset.row),
            Number(cell.dataset.col)
        );
    });

    document.addEventListener("pointerup", () => {
        if (!isSelecting) return;

        isSelecting = false;
        checkSelectedWord();
    });

    document.addEventListener("pointercancel", () => {
        isSelecting = false;
        clearSelection();
    });
}

/* =========================================
   INTRO SCREEN
========================================= */

function startIntro() {
    showScreen("intro");

    let progress = 0;

    const progressBar = $("#loadingBar");
    const loadingText = $("#loadingText");

    const interval = setInterval(() => {
        progress = Math.min(100, progress + 1);

        if (progressBar) {
            progressBar.style.width = progress + "%";
        }

        if (loadingText) {
            loadingText.textContent =
                `Loading your word world... ${progress}%`;
        }

        if (progress >= 100) {
            clearInterval(interval);

            updateBasicDisplays();
            updateSettingsButtons();
            renderLevels(true);
            showScreen("home");
        }
    }, 100);
}

/* =========================================
   INITIALIZE GAME
========================================= */

function initializeGame() {
    updateBasicDisplays();
    updateSettingsButtons();
    applyGridTheme();
    applyAlphabetStyle();
    renderLevels(true);
    startIntro();
}

if (document.readyState === "loading") {
    document.addEventListener(
        "DOMContentLoaded",
        initializeGame,
        { once: true }
    );
} else {
    initializeGame();
}

})();
