const $=s=>document.querySelector(s);
let currentTheme=null,playerName='名無し',ai=null,aiReady=false,themeBrain=null,judgeBrain=null,gameBrain=new EasukoGameBrain(),memoryBrain=new EasukoMemoryBrain();
const OFFLINE_FALLBACK={theme:'夕方の砂浜で、巨大な白い鹿ロボットが海に脚をつけて海水を飲んでいる。遠くに小さな人が立っている。',must_have:['夕方','砂浜','巨大な白い鹿ロボット','海に脚をつける','海水を飲む','小さな人'],important:['巨大さの対比','鹿の角','海辺'],optional:['オレンジ色の空','波しぶき'],forbidden_or_conflicting:['夜','森の中','鹿が普通の動物']};

async function enterFullscreen(){
  try{
    const el=document.documentElement;
    if(!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen({navigationUI:'hide'});
  }catch{}
}
function exitFullscreen(){try{if(document.fullscreenElement&&document.exitFullscreen)document.exitFullscreen()}catch{}}

function show(id){document.querySelectorAll('.screen').forEach(x=>x.classList.remove('active'));$(id).classList.add('active');$('#historyBtn').style.display=id==='#start'?'block':'none';$('#homeBtn').style.display=id==='#start'?'none':'block'}
function esc(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function setError(m=''){if($('#error'))$('#error').textContent=m}
async function bootAI(){
  $('#startBtn').disabled=true;$('#offlineBtn').disabled=true;$('#modeText').textContent='🧠 えーすこAIを準備中…';
  try{
    ai=new EasukoLocalAI(memoryBrain);await ai.load();
    let concepts=ai.concepts||{};
    if(!Object.keys(concepts).length){try{const cr=await fetch('ai/concepts.json?v=4');if(cr.ok)concepts=await cr.json()}catch{}}
    themeBrain=(concepts && Object.keys(concepts).length)?new EasukoThemeBrain(concepts):null;judgeBrain=new EasukoJudgeBrain(ai,memoryBrain);aiReady=true;
    $('#aiDot').classList.add('ok');updateLearningUI();
    $('#healthText').textContent=ai.offline?'Offline fallback / Memory Brain 起動OK・完全ローカル':'Theme / Judge / Game / Memory Brain 起動OK・完全ローカル';
    $('#modeText').textContent=ai.offline?'📱 APK互換モードで起動したよ！':'🌟 3つのAI Brainでゲームを動かせるよ！';
    $('#startBtn').disabled=false;$('#offlineBtn').disabled=false;
  }catch(e){
    // Even if model loading fails, start the game with the built-in fallback theme/judge.
    ai=new EasukoLocalAI(memoryBrain);ai.loaded=true;ai.offline=true;ai.concepts={};
    themeBrain=null;judgeBrain=new EasukoJudgeBrain(ai,memoryBrain);aiReady=true;
    $('#aiDot').classList.add('ok');updateLearningUI();$('#healthText').textContent='APK互換フォールバックで起動OK';$('#modeText').textContent='📱 オフラインモードで遊べるよ！';
    $('#startBtn').disabled=false;$('#offlineBtn').disabled=false;
  }
}
function newTheme(){return aiReady&&themeBrain?themeBrain.generate():OFFLINE_FALLBACK}
function startRound(){
  show('#game');setError('');$('#prompt').value='';$('#count').textContent='0';$('#submitBtn').disabled=false;$('#submitBtn').textContent='⚡ AI審査を受ける';
  currentTheme=newTheme();$('#theme').textContent=currentTheme.theme;
  $('#criteria').innerHTML=`<p><b>必須</b> ${esc(currentTheme.must_have.join(' / '))}</p><p><b>重要</b> ${esc(currentTheme.important.join(' / '))}</p><p class="offlineNote">🧠 Theme Brain v3.0：このお題をAIが考えました</p>`;
  $('#round').textContent=gameBrain.round;$('#streak').textContent=gameBrain.streak;
  gameBrain.startTimer(v=>{$('#timer').textContent=v;$('#timer').classList.toggle('danger',v<=10)},()=>submitScore(true));
}
async function submitScore(auto=false){
  if($('#submitBtn').disabled)return;gameBrain.stopTimer();$('#submitBtn').disabled=true;setError('');const prompt=$('#prompt').value.trim();
  if(!prompt){setError('プロンプトを書いてね！');$('#submitBtn').disabled=false;startRound();return}
  show('#judge');let status=0;const statuses=['お題の構成要素を解析しています','Judge Brainが意味の近さを確認しています','状態・関係を分析しています','構図と具体性をチェックしています','やさしい講評を準備しています'];$('#judgeStatus').textContent=statuses[0];const sid=setInterval(()=>{$('#judgeStatus').textContent=statuses[++status%statuses.length]},650);
  try{const r=judgeBrain.evaluate(currentTheme,prompt);clearInterval(sid);renderResult(r,auto);show('#result')}catch(e){clearInterval(sid);setError(e.message);$('#submitBtn').disabled=false;show('#game');startRound()}
}
function saveLocalScore(r){try{const key='easuko-v4-scores';const a=JSON.parse(localStorage.getItem(key)||'[]');a.unshift({created_at:new Date().toISOString(),name:playerName,score:r.total_score,theme:currentTheme.theme});localStorage.setItem(key,JSON.stringify(a.slice(0,100)))}catch{}}
function getLocalScores(){try{return JSON.parse(localStorage.getItem('easuko-v4-scores')||'[]')}catch{return[]}}
function renderResult(r,auto){
  saveLocalScore(r);updateLearningUI();const oldBest=gameBrain.best;gameBrain.record(r.total_score);$('#streak').textContent=gameBrain.streak;
  $('#total').textContent='000';let n=0;const target=r.total_score;const anim=setInterval(()=>{n=Math.min(target,n+Math.max(7,Math.ceil(target/28)));$('#total').textContent=String(n).padStart(3,'0');if(n>=target)clearInterval(anim)},25);
  const grade=target>=900?'S':target>=800?'A':target>=650?'B':target>=500?'C':'D';$('#grade').textContent=`GRADE ${grade}${auto?' ・ TIME UP':''}`;$('#recordText').textContent=target>oldBest?`🏆 NEW BEST! 自己ベスト ${target}点`:target===oldBest&&target>0?'自己ベストタイ記録！':`自己ベスト ${gameBrain.best}点`;
  const items=[['テーマ再現','theme_match',500],['状態・関係','state_relation',200],['構図','composition',150],['具体性','specificity',100],['矛盾管理','conflict_control',50]];
  $('#breakdown').innerHTML=items.map(([name,key,max])=>`<div class="barRow"><div><span>${name}</span><b>${Number(r[key]??0)} / ${max}</b></div><div class="bar"><i style="width:${Math.max(0,Math.min(100,(Number(r[key]??0)/max)*100))}%"></i></div></div>`).join('');
  $('#matched').innerHTML=(r.matched||[]).length?r.matched.map(x=>`<span class="tag good">✓ ${esc(x)}</span>`).join(''):'<span class="muted">なし</span>';
  $('#missing').innerHTML=((r.missing||[]).length||(r.conflicts||[]).length)?[...(r.missing||[]).map(x=>`<span class="tag bad">不足: ${esc(x)}</span>`),...(r.conflicts||[]).map(x=>`<span class="tag warn">矛盾: ${esc(x)}</span>`)].join(''):'<span class="tag good">大きな不足・矛盾なし</span>';
  $('#reason').textContent=r.reason||'';$('#advice').innerHTML=(r.advice||[]).map(x=>`<div class="advice">💡 ${esc(x)}</div>`).join('');
  const rv=r.review||{};$('#judgeReview').innerHTML=`<div class="reviewBubble"><b>🌸 えーすこちゃん</b><p>${esc(rv.opening||'講評をまとめたよ！')}</p><p>${esc(rv.goodText||'')}</p><p>${esc(rv.missText||'')}</p>${rv.conflictText?`<p>${esc(rv.conflictText)}</p>`:''}</div>`;
  const img=$('#resultJudge');if(img)img.src='assets/judge-girl.png';
}
$('#startBtn').onclick=()=>{enterFullscreen();playerName=($('#playerName').value.trim()||'名無し').slice(0,20);gameBrain.start();startRound()};
$('#offlineBtn').onclick=()=>{enterFullscreen();playerName=($('#playerName').value.trim()||'名無し').slice(0,20);gameBrain.start();startRound()};
$('#nextBtn').onclick=()=>{gameBrain.nextRound();startRound()};
$('#retryBtn').onclick=()=>{show('#game');$('#submitBtn').disabled=false;$('#submitBtn').textContent='⚡ AI審査を受ける';gameBrain.startTimer(v=>{$('#timer').textContent=v;$('#timer').classList.toggle('danger',v<=10)},()=>submitScore(true));$('#prompt').focus()};
$('#submitBtn').onclick=()=>submitScore(false);$('#prompt').addEventListener('input',()=>$('#count').textContent=$('#prompt').value.length);$('#leaderBtn').onclick=leaderboard;$('#leaderBack').onclick=()=>show('#start');$('#historyBtn').onclick=history;$('#backBtn').onclick=()=>show('#start');$('#homeBtn').onclick=()=>show('#start');$('#learnBtn').onclick=()=>{updateLearningUI();show('#learning')};$('#exportBtn').onclick=downloadLearning;$('#importBtn').onclick=openLearningFilePicker;$('#importFile').onchange=e=>e.target.files[0]&&importLearning(e.target.files[0]);$('#resetLearnBtn').onclick=resetLearning;
function leaderboard(){show('#leaderboard');const a=getLocalScores().sort((x,y)=>y.score-x.score).slice(0,50);$('#leaderList').innerHTML=a.length?a.map((x,i)=>`<div class="rank ${i<3?'top':''}"><span>#${i+1}</span><b>${esc(x.name)}</b><strong>${x.score}</strong><small>${esc(x.theme)}</small></div>`).join(''):'<p class="muted">まだランキングがありません。</p>'}
function updateLearningUI(){const x=memoryBrain.stats();if($('#learnStats'))$('#learnStats').textContent=`プレイ ${x.plays}回 / 高得点 ${x.wins}回 / 学習概念 ${x.concepts}個 / 保存例 ${x.examples}件`;}
async function downloadLearning(){
  const text=memoryBrain.exportJSON();
  const fileName='easuko-ai-learning-v4.json';
  try{
    const file=new File([text],fileName,{type:'application/json'});
    if(navigator.share && navigator.canShare && navigator.canShare({files:[file]})){
      await navigator.share({title:'えーすこ！学習データ',text:'えーすこ！AIの学習データ',files:[file]});
      return;
    }
  }catch(e){ if(e?.name==='AbortError')return; }
  try{
    const blob=new Blob([text],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');
    a.href=url;a.download=fileName;a.rel='noopener';document.body.appendChild(a);a.click();a.remove();
    setTimeout(()=>URL.revokeObjectURL(url),1500);return;
  }catch{}
  try{await navigator.clipboard.writeText(text);alert('ダウンロードできなかったので、学習データをクリップボードにコピーしたよ！🌸')}catch{alert('学習データの書き出しに失敗しました。')}
}
function openLearningFilePicker(){const input=$('#importFile');if(input){input.value='';input.click();}}
function importLearning(file){
  const r=new FileReader();
  r.onload=()=>{try{memoryBrain.importJSON(r.result);updateLearningUI();alert('学習データを取り込みました！🌸')}catch(e){alert(e.message)}};
  r.onerror=()=>alert('ファイルを読み込めませんでした。');r.readAsText(file);
}
function resetLearning(){if(confirm('えーすこAIのローカル学習データを全部消す？')){memoryBrain.reset();updateLearningUI();}}
function history(){show('#history');const a=getLocalScores();$('#historyList').innerHTML=a.length?a.map(x=>`<div class="hist"><b>${x.score}点</b><span>${esc(x.theme)}</span></div>`).join(''):'<p class="muted">まだ履歴がありません。</p>'}
bootAI();
