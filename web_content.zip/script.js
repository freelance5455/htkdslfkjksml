/*
    WATAMI US CORP
    Rice Acidification Log

    Local storage
    Excel export
    CSV export
    Local JSON backup
    Today's records
    Edit existing records
    2" x 2" Bluetooth print preparation
*/


const STORAGE_KEY = "watami_rice_acidification_records_v1";

let records = [];
let editingId = null;


/* -------------------------------------------------------
   START
------------------------------------------------------- */

document.addEventListener("DOMContentLoaded", () => {

    loadRecords();

    updateDateTime();

    setInterval(updateDateTime, 1000);

    renderTodayRecords();

    document
        .getElementById("saveBtn")
        .addEventListener("click", saveRecord);

    document
        .getElementById("printBtn")
        .addEventListener("click", printCurrentRecord);

    document
        .getElementById("cancelEditBtn")
        .addEventListener("click", cancelEdit);

    document
        .getElementById("exportCSVBtn")
        .addEventListener("click", exportCSV);

    document
        .getElementById("exportExcelBtn")
        .addEventListener("click", exportExcel);

    document
        .getElementById("backupBtn")
        .addEventListener("click", backupLocal);

    document
        .getElementById("ricePH")
        .addEventListener("blur", formatPH);

    document
        .getElementById("ricePH")
        .addEventListener("input", limitPH);

});


/* -------------------------------------------------------
   DATE / TIME
------------------------------------------------------- */

function updateDateTime() {

    const now = new Date();

    const date = formatDate(now);
    const time = formatTime(now);

    document.getElementById("recordDate").value = date;
    document.getElementById("recordTime").value = time;
}


function formatDate(date) {

    const year = date.getFullYear();

    const month = String(
        date.getMonth() + 1
    ).padStart(2, "0");

    const day = String(
        date.getDate()
    ).padStart(2, "0");

    return `${year}-${month}-${day}`;
}


function formatTime(date) {

    let hours = date.getHours();

    const minutes = String(
        date.getMinutes()
    ).padStart(2, "0");

    const seconds = String(
        date.getSeconds()
    ).padStart(2, "0");

    const ampm = hours >= 12 ? "PM" : "AM";

    hours = hours % 12;

    if (hours === 0) {
        hours = 12;
    }

    return `${String(hours).padStart(2, "0")}:${minutes}:${seconds} ${ampm}`;
}


/* -------------------------------------------------------
   LOCAL STORAGE
------------------------------------------------------- */

function loadRecords() {

    try {

        const saved = localStorage.getItem(STORAGE_KEY);

        if (saved) {
            records = JSON.parse(saved);
        } else {
            records = [];
        }

    } catch (error) {

        console.error(error);

        records = [];

        showStatus(
            "Unable to load saved records.",
            "error"
        );
    }
}


function saveToLocalStorage() {

    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(records)
    );
}


/* -------------------------------------------------------
   SAVE RECORD
------------------------------------------------------- */

function saveRecord() {

    const batchNumber =
        document.getElementById("batchNumber")
        .value
        .trim();

    const calibrationElement =
        document.querySelector(
            'input[name="calibration"]:checked'
        );

    const ricePHRaw =
        document.getElementById("ricePH")
        .value
        .trim();

    const correctiveAction =
        document.getElementById("correctiveAction")
        .value
        .trim();

    const documentedBy =
        document.getElementById("documentedBy")
        .value
        .trim();

    const verifiedBy =
        document.getElementById("verifiedBy")
        .value
        .trim();


    /* REQUIRED VALIDATION */

    if (!batchNumber) {

        showStatus(
            "Batch Number is required.",
            "error"
        );

        document.getElementById("batchNumber").focus();

        return;
    }


    if (!calibrationElement) {

        showStatus(
            "Please select Calibration Yes or No.",
            "error"
        );

        return;
    }


    if (!ricePHRaw) {

        showStatus(
            "Rice pH is required.",
            "error"
        );

        document.getElementById("ricePH").focus();

        return;
    }


    const ricePH = Number(ricePHRaw);

    if (
        Number.isNaN(ricePH) ||
        ricePH < 0 ||
        ricePH > 14
    ) {

        showStatus(
            "Rice pH must be between 0.00 and 14.00.",
            "error"
        );

        return;
    }


    if (!documentedBy) {

        showStatus(
            "Documented By is required.",
            "error"
        );

        document.getElementById("documentedBy").focus();

        return;
    }


    /* CREATE RECORD */

    const now = new Date();

    const record = {

        id:
            editingId ||
            `${Date.now()}-${Math.random()
                .toString(36)
                .substring(2, 9)}`,

        date:
            editingId
                ? getEditingDate()
                : formatDate(now),

        time:
            editingId
                ? getEditingTime()
                : formatTime(now),

        timestamp:
            editingId
                ? getEditingTimestamp()
                : now.toISOString(),

        batchNumber:
            batchNumber,

        calibration:
            calibrationElement.value,

        ricePH:
            ricePH.toFixed(2),

        correctiveAction:
            correctiveAction,

        documentedBy:
            documentedBy,

        verifiedBy:
            verifiedBy,

        updatedAt:
            new Date().toISOString()
    };


    if (editingId) {

        const index =
            records.findIndex(
                item => item.id === editingId
            );

        if (index !== -1) {

            records[index] = {
                ...records[index],
                ...record
            };
        }

    } else {

        records.push(record);
    }


    saveToLocalStorage();

    renderTodayRecords();

    showStatus(
        editingId
            ? "Record updated and saved locally."
            : "Record saved successfully.",
        "success"
    );


    resetForm();

}


/* -------------------------------------------------------
   EDIT
------------------------------------------------------- */

function editRecord(id) {

    const record =
        records.find(item => item.id === id);

    if (!record) {
        return;
    }

    editingId = id;

    document.getElementById("batchNumber").value =
        record.batchNumber || "";

    document.getElementById("ricePH").value =
        record.ricePH || "";

    document.getElementById("correctiveAction").value =
        record.correctiveAction || "";

    document.getElementById("documentedBy").value =
        record.documentedBy || "";

    document.getElementById("verifiedBy").value =
        record.verifiedBy || "";


    const calibrationRadio =
        document.querySelector(
            `input[name="calibration"][value="${record.calibration}"]`
        );

    if (calibrationRadio) {
        calibrationRadio.checked = true;
    }


    document.getElementById("recordDate").value =
        record.date;

    document.getElementById("recordTime").value =
        record.time;


    document
        .getElementById("editNotice")
        .classList.remove("hidden");

    document
        .getElementById("cancelEditBtn")
        .classList.remove("hidden");

    document
        .getElementById("saveBtn")
        .textContent = "Update Record";


    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });


    showStatus(
        "Editing selected record.",
        "success"
    );
}


/* -------------------------------------------------------
   EDIT DATE/TIME
------------------------------------------------------- */

function getEditingDate() {

    const record =
        records.find(item => item.id === editingId);

    return record
        ? record.date
        : formatDate(new Date());
}


function getEditingTime() {

    const record =
        records.find(item => item.id === editingId);

    return record
        ? record.time
        : formatTime(new Date());
}


function getEditingTimestamp() {

    const record =
        records.find(item => item.id === editingId);

    return record
        ? record.timestamp
        : new Date().toISOString();
}


/* -------------------------------------------------------
   CANCEL EDIT
------------------------------------------------------- */

function cancelEdit() {

    editingId = null;

    resetForm();

    showStatus(
        "Edit cancelled.",
        "success"
    );
}


/* -------------------------------------------------------
   RESET FORM
------------------------------------------------------- */

function resetForm() {

    editingId = null;

    document.getElementById("batchNumber").value = "";

    document.getElementById("ricePH").value = "";

    document.getElementById("correctiveAction").value = "";

    document.getElementById("documentedBy").value = "";

    document.getElementById("verifiedBy").value = "";


    document
        .querySelectorAll(
            'input[name="calibration"]'
        )
        .forEach(radio => {
            radio.checked = false;
        });


    document
        .getElementById("editNotice")
        .classList.add("hidden");

    document
        .getElementById("cancelEditBtn")
        .classList.add("hidden");

    document
        .getElementById("saveBtn")
        .textContent = "Save Record";


    updateDateTime();
}


/* -------------------------------------------------------
   TODAY'S RECORDS
------------------------------------------------------- */

function renderTodayRecords() {

    const today =
        formatDate(new Date());

    const todayRecords =
        records
            .filter(record => record.date === today)
            .sort(
                (a, b) =>
                    new Date(b.timestamp) -
                    new Date(a.timestamp)
            );


    const tbody =
        document.getElementById("recordsBody");

    tbody.innerHTML = "";


    todayRecords.forEach(record => {

        const row =
            document.createElement("tr");


        row.innerHTML = `

            <td>${escapeHTML(record.date)}</td>

            <td>${escapeHTML(record.time)}</td>

            <td>${escapeHTML(record.batchNumber)}</td>

            <td>${escapeHTML(record.calibration)}</td>

            <td>${escapeHTML(record.ricePH)}</td>

            <td>${escapeHTML(
                record.correctiveAction || ""
            )}</td>

            <td>${escapeHTML(record.documentedBy)}</td>

            <td>${escapeHTML(
                record.verifiedBy || ""
            )}</td>

            <td>
                <button
                    class="edit-btn"
                    onclick="editRecord('${record.id}')"
                >
                    Edit
                </button>
            </td>
        `;


        tbody.appendChild(row);

    });


    document.getElementById("recordCount").textContent =
        `${todayRecords.length} record${todayRecords.length === 1 ? "" : "s"}`;


    document.getElementById("noRecords")
        .style.display =
        todayRecords.length === 0
            ? "block"
            : "none";
}


/* -------------------------------------------------------
   PH VALIDATION
------------------------------------------------------- */

function limitPH(event) {

    let value = event.target.value;

    if (value === "") {
        return;
    }

    const number = Number(value);

    if (number > 14) {
        event.target.value = "14.00";
    }

    if (number < 0) {
        event.target.value = "0.00";
    }
}


function formatPH() {

    const input =
        document.getElementById("ricePH");

    if (input.value === "") {
        return;
    }

    const number = Number(input.value);

    if (
        Number.isNaN(number) ||
        number < 0 ||
        number > 14
    ) {
        return;
    }

    input.value =
        number.toFixed(2);
}


/* -------------------------------------------------------
   CSV EXPORT
------------------------------------------------------- */

function exportCSV() {

    if (records.length === 0) {

        showStatus(
            "There are no saved records to export.",
            "error"
        );

        return;
    }


    const headers = [

        "Date",
        "Time",
        "Batch Number",
        "Calibration",
        "Rice pH",
        "Corrective Action",
        "Documented By",
        "Verified By"

    ];


    const rows =
        records.map(record => [

            record.date,
            record.time,
            record.batchNumber,
            record.calibration,
            record.ricePH,
            record.correctiveAction,
            record.documentedBy,
            record.verifiedBy

        ]);


    let csv =
        headers.join(",") + "\n";


    rows.forEach(row => {

        csv +=
            row
                .map(csvEscape)
                .join(",") +
            "\n";

    });


    downloadFile(

        csv,

        `Watami_Rice_Acidification_Log_${formatDate(new Date())}.csv`,

        "text/csv;charset=utf-8;"

    );


    showStatus(
        "CSV file exported.",
        "success"
    );
}


function csvEscape(value) {

    const string =
        String(value ?? "");

    return `"${string.replace(/"/g, '""')}"`;
}


/* -------------------------------------------------------
   EXCEL EXPORT
------------------------------------------------------- */

function exportExcel() {

    if (records.length === 0) {

        showStatus(
            "There are no saved records to export.",
            "error"
        );

        return;
    }


    /*
       Spreadsheet-compatible HTML file.

       Excel opens this file directly.
       No external library is required.
    */

    let html = `

    <html>

    <head>

        <meta charset="UTF-8">

        <style>

            table {
                border-collapse: collapse;
            }

            th, td {
                border: 1px solid #000;
                padding: 6px;
            }

            th {
                background: #d9f0d9;
                font-weight: bold;
            }

        </style>

    </head>

    <body>

        <h2>WATAMI US CORP</h2>

        <h3>Rice Acidification Log</h3>

        <table>

            <tr>

                <th>Date</th>
                <th>Time</th>
                <th>Batch Number</th>
                <th>Calibration</th>
                <th>Rice pH</th>
                <th>Corrective Action</th>
                <th>Documented By</th>
                <th>Verified By</th>

            </tr>
    `;


    records.forEach(record => {

        html += `

            <tr>

                <td>${escapeHTML(record.date)}</td>

                <td>${escapeHTML(record.time)}</td>

                <td>${escapeHTML(record.batchNumber)}</td>

                <td>${escapeHTML(record.calibration)}</td>

                <td>${escapeHTML(record.ricePH)}</td>

                <td>${escapeHTML(record.correctiveAction)}</td>

                <td>${escapeHTML(record.documentedBy)}</td>

                <td>${escapeHTML(record.verifiedBy)}</td>

            </tr>
        `;

    });


    html += `

        </table>

    </body>

    </html>
    `;


    downloadFile(

        html,

        `Watami_Rice_Acidification_Log_${formatDate(new Date())}.xls`,

        "application/vnd.ms-excel"

    );


    showStatus(
        "Excel file exported.",
        "success"
    );
}


/* -------------------------------------------------------
   LOCAL BACKUP
------------------------------------------------------- */

function backupLocal() {

    const backup = {

        company:
            "WATAMI US CORP",

        log:
            "Rice Acidification Log",

        backupDate:
            new Date().toISOString(),

        recordCount:
            records.length,

        records:
            records

    };


    const json =
        JSON.stringify(
            backup,
            null,
            2
        );


    downloadFile(

        json,

        `Watami_Rice_Acidification_Backup_${formatDate(new Date())}.json`,

        "application/json;charset=utf-8;"

    );


    showStatus(
        "Local backup file created.",
        "success"
    );
}


/* -------------------------------------------------------
   DOWNLOAD
------------------------------------------------------- */

function downloadFile(
    content,
    filename,
    type
) {

    const blob =
        new Blob(
            [content],
            { type: type }
        );


    const url =
        URL.createObjectURL(blob);


    const link =
        document.createElement("a");


    link.href = url;

    link.download = filename;

    document.body.appendChild(link);

    link.click();

    document.body.removeChild(link);


    setTimeout(
        () => URL.revokeObjectURL(url),
        1000
    );
}


/* -------------------------------------------------------
   BLUETOOTH / 2" x 2" PRINT
------------------------------------------------------- */

function printCurrentRecord() {

    let record = null;


    /*
       If editing, print the selected record.
       Otherwise print the current form values.
    */

    if (editingId) {

        record =
            records.find(
                item => item.id === editingId
            );
    }


    if (!record) {

        const batchNumber =
            document.getElementById("batchNumber")
            .value
            .trim();

        const ricePH =
            document.getElementById("ricePH")
            .value
            .trim();

        const documentedBy =
            document.getElementById("documentedBy")
            .value
            .trim();


        if (
            !batchNumber ||
            !ricePH ||
            !documentedBy
        ) {

            showStatus(
                "Enter Batch Number, Rice pH, and Documented By before printing.",
                "error"
            );

            return;
        }


        record = {

            date:
                document.getElementById("recordDate").value,

            time:
                document.getElementById("recordTime").value,

            batchNumber:
                batchNumber,

            ricePH:
                Number(ricePH).toFixed(2),

            documentedBy:
                documentedBy
        };
    }


    /*
       2" x 2" receipt/label content.

       This is intentionally simple so it can be
       converted to ESC/POS or printer-specific
       commands in the Capacitor Android layer.
    */

    const printData = createBluetoothPrintData(record);


    /*
       Capacitor Android bridge.

       If the native Bluetooth plugin is installed,
       the Android side can receive this event/data.

       Browser mode falls back to the browser
       print dialog.
    */

    if (
        window.Capacitor &&
        window.Capacitor.Plugins &&
        window.Capacitor.Plugins.BluetoothPrinter
    ) {

        window.Capacitor.Plugins.BluetoothPrinter
            .print({
                width: 2,
                height: 2,
                content: printData
            })
            .then(() => {

                showStatus(
                    "Sent to Bluetooth printer.",
                    "success"
                );

            })
            .catch(error => {

                console.error(error);

                showStatus(
                    "Bluetooth printing failed.",
                    "error"
                );

            });

        return;
    }


    /*
       Browser fallback.
    */

    browserPrint(record);
}


/* -------------------------------------------------------
   BLUETOOTH PRINT DATA
------------------------------------------------------- */

function createBluetoothPrintData(record) {

    return [

        "WATAMI US CORP",

        "Rice Acidification Log",

        "--------------------",

        `Date: ${record.date}`,

        `Time: ${record.time}`,

        `Batch: ${record.batchNumber}`,

        `pH: ${Number(record.ricePH).toFixed(2)}`,

        `Documented By: ${record.documentedBy}`,

        "--------------------"

    ].join("\n");
}


/* -------------------------------------------------------
   BROWSER PRINT FALLBACK
------------------------------------------------------- */

function browserPrint(record) {

    const existing =
        document.getElementById("printArea");

    if (existing) {
        existing.remove();
    }


    const printArea =
        document.createElement("div");


    printArea.id =
        "printArea";


    printArea.style.width =
        "2in";

    printArea.style.height =
        "2in";

    printArea.style.padding =
        "0.08in";

    printArea.style.fontFamily =
        "Arial, sans-serif";

    printArea.style.fontSize =
        "9pt";

    printArea.style.lineHeight =
        "1.25";


    printArea.innerHTML = `

        <div style="
            text-align:center;
            font-weight:bold;
            font-size:11pt;
        ">
            WATAMI US CORP
        </div>

        <div style="
            text-align:center;
            font-weight:bold;
            margin-bottom:8px;
        ">
            Rice Acidification Log
        </div>

        <div>
            Date: ${escapeHTML(record.date)}
        </div>

        <div>
            Time: ${escapeHTML(record.time)}
        </div>

        <div>
            Batch: ${escapeHTML(record.batchNumber)}
        </div>

        <div>
            pH: ${escapeHTML(
                Number(record.ricePH).toFixed(2)
            )}
        </div>

        <div>
            Documented By:
        </div>

        <div>
            ${escapeHTML(record.documentedBy)}
        </div>

    `;


    document.body.appendChild(printArea);


    window.print();


    setTimeout(() => {

        printArea.remove();

    }, 1000);
}


/* -------------------------------------------------------
   STATUS
------------------------------------------------------- */

function showStatus(message, type) {

    const status =
        document.getElementById("statusMessage");

    status.textContent =
        message;

    status.className =
        `status-message ${type}`;


    setTimeout(() => {

        status.textContent = "";

        status.className =
            "status-message";

    }, 4000);
}


/* -------------------------------------------------------
   SECURITY / TABLE TEXT
------------------------------------------------------- */

function escapeHTML(value) {

    return String(value ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}