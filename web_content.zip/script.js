const API = "https://mp3quran.net/api/v3";

const reciterSelect = document.getElementById("reciter");
const surahListContainer = document.getElementById("surahList");
const searchInput = document.getElementById("searchInput");
const audio = document.getElementById("audio");
const playerTitle = document.getElementById("playerTitle");
const statusText = document.getElementById("status");
const downloadBtn = document.getElementById("downloadBtn");
const downloadList = document.getElementById("downloadList");

/* ربط أزرار التنقل */
const navHome = document.getElementById("navHome");
const navDownloads = document.getElementById("navDownloads");
const homePage = document.getElementById("homePage");
const downloadsPage = document.getElementById("downloadsPage");

navHome.addEventListener("click", () => {
    homePage.classList.add("active-page");
    downloadsPage.classList.remove("active-page");
    navHome.classList.add("active");
    navDownloads.classList.remove("active");
});

navDownloads.addEventListener("click", () => {
    downloadsPage.classList.add("active-page");
    homePage.classList.remove("active-page");
    navDownloads.classList.add("active");
    navHome.classList.remove("active");
    showDownloads();
});

let selectedReciter = null;
let selectedSurah = null;
let currentURL = "";

const reciters = [
    { id: 1, name: "عبد الباسط عبد الصمد", keywords: ["عبدالباسط", "basit"] },
    { id: 2, name: "عبد الرحمن السديس", keywords: ["السديس", "sudais"] },
    { id: 3, name: "ماهر المعيقلي", keywords: ["المعيقلي", "maher"] },
    { id: 4, name: "سعد الغامدي", keywords: ["الغامدي", "ghamdi"] },
    { id: 5, name: "مشاري العفاسي", keywords: ["العفاسي", "afasy"] },
    { id: 6, name: "ياسر الدوسري", keywords: ["الدوسري", "yasir"] },
    { id: 7, name: "محمد صديق المنشاوي", keywords: ["المنشاوي", "minshawi"] },
    { id: 8, name: "محمود خليل الحصري", keywords: ["الحصري", "husary"] },
    { id: 9, name: "مصطفى إسماعيل", keywords: ["مصطفى إسماعيل", "mustafa"] },
    { id: 10, name: "محمود علي البنا", keywords: ["البنا", "banna"] }
];

const surahNames = [
    "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
    "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
    "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
    "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
    "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
    "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
    "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
    "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
    "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
    "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
    "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
    "المسد", "الإخلاص", "الفلق", "الناس"
];

function loadReciters() {
    reciterSelect.innerHTML = `<option value="">اختر القارئ</option>`;
    reciters.forEach((r, index) => {
        const option = document.createElement("option");
        option.value = index;
        option.textContent = `${index + 1}. ${r.name}`;
        reciterSelect.appendChild(option);
    });
}

function renderSurahs(filterText = "") {
    surahListContainer.innerHTML = "";
    surahNames.forEach((name, index) => {
        if (filterText && !name.includes(filterText)) return;

        const surahNumber = index + 1;
        const item = document.createElement("div");
        item.className = "surah-item";
        item.innerHTML = `
            <span class="surah-number">${surahNumber}</span>
            <span class="surah-name">سورة ${name}</span>
        `;
        item.addEventListener("click", () => selectSurah(surahNumber, name, item));
        surahListContainer.appendChild(item);
    });
}

reciterSelect.addEventListener("change", () => {
    const val = reciterSelect.value;
    selectedReciter = val !== "" ? reciters[val] : null;
    if (selectedSurah) playSelectedAudio();
});

function selectSurah(number, name, element) {
    document.querySelectorAll(".surah-item").forEach(el => el.classList.remove("active"));
    element.classList.add("active");

    selectedSurah = { number, name };
    
    if (!selectedReciter) {
        playerTitle.textContent = `سورة ${name}`;
        statusText.textContent = "الرجاء اختيار القارئ أولاً للبدء.";
        downloadBtn.disabled = true;
        return;
    }

    playSelectedAudio();
}

async function playSelectedAudio() {
    if (!selectedReciter || !selectedSurah) return;

    playerTitle.textContent = `سورة ${selectedSurah.name} - ${selectedReciter.name}`;
    statusText.textContent = "🌐 جاري جلب الصوت...";
    downloadBtn.disabled = true;

    try {
        currentURL = await getAudioURL();
        audio.src = currentURL;
        audio.play();
        statusText.textContent = "جاري التشغيل...";
        downloadBtn.disabled = false;
    } catch (err) {
        console.error(err);
        statusText.textContent = "❌ تعذر جلب الصوت. تحقق من الإنترنت.";
    }
}

async function getAudioURL() {
    const res = await fetch(`${API}/reciters?language=ar`);
    if (!res.ok) throw new Error("API error");
    const data = await res.json();

    const wanted = selectedReciter.keywords;
    const found = data.reciters.find(r => {
        const name = normalize(r.name);
        return wanted.some(k => name.includes(normalize(k)));
    });

    if (!found) throw new Error("Reciter not found");

    const moshaf = found.moshaf?.find(m => m.server);
    if (!moshaf) throw new Error("No server found");

    const numStr = String(selectedSurah.number).padStart(3, "0");
    return moshaf.server + numStr + ".mp3";
}

function normalize(text) {
    return String(text || "")
        .toLowerCase()
        .replace(/[ًٌٍَُِّْـ]/g, "")
        .replace(/[أإآ]/g, "ا")
        .replace(/ى/g, "ي")
        .replace(/ة/g, "ه")
        .replace(/\s+/g, "")
        .trim();
}

/* IndexedDB */
const DB_NAME = "QuranDB", DB_VERSION = 1, STORE_NAME = "downloads";

function openDB() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = e => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "id" });
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

async function saveDownload(item) {
    const db = await openDB();
    return new Promise((res, rej) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).put(item);
        tx.oncomplete = res;
        tx.onerror = () => rej(tx.error);
    });
}

async function getDownloads() {
    const db = await openDB();
    return new Promise((res, rej) => {
        const req = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
        req.onsuccess = () => res(req.result);
        req.onerror = () => rej(req.error);
    });
}

async function deleteDownload(id) {
    const db = await openDB();
    return new Promise((res, rej) => {
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).delete(id);
        tx.oncomplete = res;
        tx.onerror = () => rej(tx.error);
    });
}

downloadBtn.addEventListener("click", async () => {
    if (!currentURL || !selectedReciter || !selectedSurah) return;

    try {
        downloadBtn.disabled = true;
        statusText.textContent = "⬇️ جاري تنزيل السورة للجهاز...";

        const response = await fetch(currentURL);
        if (!response.ok) throw new Error("Download failed");

        const blob = await response.blob();
        const id = `${selectedReciter.id}_${selectedSurah.number}`;

        await saveDownload({
            id: id,
            surah: selectedSurah.name,
            reciter: selectedReciter.name,
            blob: blob,
            date: Date.now()
        });

        statusText.textContent = "✅ تم حفظ السورة في التنزيلات بنجاح.";
    } catch (err) {
        console.error(err);
        statusText.textContent = "❌ فشل التنزيل. تحقق من الاتصال.";
    }
    downloadBtn.disabled = false;
});

async function showDownloads() {
    const downloads = await getDownloads();
    if (!downloads.length) {
        downloadList.innerHTML = "لا توجد سور محملة بعد.";
        return;
    }

    downloadList.innerHTML = "";
    downloads.sort((a, b) => b.date - a.date);

    downloads.forEach(item => {
        const div = document.createElement("div");
        div.className = "download-item";
        div.innerHTML = `
            <div class="download-info">
                <strong>سورة ${item.surah}</strong>
                <small>${item.reciter}</small>
            </div>
            <div class="download-actions">
                <button class="btn-play">▶️ تشغيل</button>
                <button class="btn-delete">🗑️</button>
            </div>
        `;

        div.querySelector(".btn-play").onclick = () => {
            const url = URL.createObjectURL(item.blob);
            audio.src = url;
            
            // الانتقال للرئيسية لتشغيل المقطع
            navHome.click();
            playerTitle.textContent = `سورة ${item.surah} - ${item.reciter}`;
            statusText.textContent = "📱 تشغيل أوفلاين من التنزيلات.";
            audio.play();
        };

        div.querySelector(".btn-delete").onclick = async () => {
            await deleteDownload(item.id);
            showDownloads();
        };

        downloadList.appendChild(div);
    });
}

searchInput.addEventListener("input", (e) => renderSurahs(e.target.value.trim()));

loadReciters();
renderSurahs();
